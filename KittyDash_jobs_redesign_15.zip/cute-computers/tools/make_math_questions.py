#!/usr/bin/env python3
"""Pet School: writes tools/school_q/algebra.txt and tools/school_q/geometry.txt (25 questions per class, ru + en).

The numbers are drawn from a fixed seed, so the files never change between runs, and every right answer is computed (and the
equations are checked by putting the answer back), so a wrong question cannot slip in. Run it, then run make_school_subjects.py:

    python3 tools/make_math_questions.py
    python3 tools/make_school_subjects.py

Only the letters of the cute font are used (digits, + - = / ( ) ? . ,), the signs x, / and the Latin-1 signs of the default font
(squared, cubed, degree, multiplication, division). "pi" is written as a word, the minus sign is a hyphen.
"""
import pathlib
import random
import re
from math import gcd

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "tools/school_q"
R = random.Random(20261029)
COUNT = 25
NEED = {"easy": 2, "medium": 2, "hard": 3}          # wrong answers per question (the class has 3, 3 or 4 answers)


def near(right, n=8, lo=None, extra=()):
    """Wrong numbers that look like the right one: the typical slips first, then the neighbours."""
    cand = list(extra) + [right + 1, right - 1, right + 2, right - 2, right * 2, right + 10, right - 10, right + 3, right - 3, right + 5, -right, right + 4]
    out = []
    for c in cand:
        if c != right and c not in out and (lo is None or c >= lo):
            out.append(c)
    return [str(x) for x in out[:n]]


def u(nums, unit):
    return [f"{x} {unit}" for x in nums]


class Q:
    """One question. right / wrongs are strings, or (en, ru) pairs for the answers that are words."""
    def __init__(self, en, ru, right, wrongs):
        self.en, self.ru, self.right, self.wrongs = en, ru, right, list(wrongs)

    def line(self, lang, need):
        i = 0 if lang == "en" else 1
        pick = lambda a: a[i] if isinstance(a, tuple) else a
        q = self.en if lang == "en" else self.ru
        right = pick(self.right)
        wrongs = []
        for w in self.wrongs:
            w = pick(w)
            if w != right and w not in wrongs:
                wrongs.append(w)
        if len(wrongs) < need:                       # two wrong answers came out equal to each other or to the right one: add neighbours
            m = re.fullmatch(r"(-?\d+)(.*)", right)
            if m:
                n, tail = int(m.group(1)), m.group(2)
                for c in (n + 1, n - 1, n + 2, n - 2, n * 2, n + 10, n - 10, n + 5):
                    cand = f"{c}{tail}"
                    if cand != right and cand not in wrongs and (n < 0 or c >= 0):
                        wrongs.append(cand)
                    if len(wrongs) >= need:
                        break
        assert len(wrongs) >= need, (q, right, wrongs)
        ans = [right] + wrongs[:need]
        assert len(set(ans)) == len(ans), (q, ans)
        assert "|" not in q and all("|" not in a for a in ans), q
        assert len(q) <= 150 and all(len(a) <= 60 for a in ans), (q, ans)
        return "|".join([q] + ans)


def t(n):
    """The number written with a hyphen as the minus sign."""
    return str(n)


# ------------------------------------------------------------------------------------------------ algebra
def a_add():
    x, a = R.randint(2, 12), R.randint(2, 9)
    return Q(f"Solve: x + {a} = {x + a}. What is x?", f"Реши: x + {a} = {x + a}. Чему равен x?", str(x), near(x, lo=0, extra=[x + a, a]))


def a_sub():
    x, a = R.randint(6, 16), R.randint(2, 5)
    return Q(f"Solve: x - {a} = {x - a}. What is x?", f"Реши: x - {a} = {x - a}. Чему равен x?", str(x), near(x, lo=0, extra=[x - 2 * a, a]))


def a_mul():
    a, x = R.randint(2, 6), R.randint(2, 9)
    return Q(f"Solve: {a}x = {a * x}. What is x?", f"Реши: {a}x = {a * x}. Чему равен x?", str(x), near(x, lo=0, extra=[a * x, a * x - a]))


def a_div():
    a, b = R.randint(2, 5), R.randint(2, 8)
    return Q(f"Solve: x ÷ {a} = {b}. What is x?", f"Реши: x ÷ {a} = {b}. Чему равен x?", str(a * b), near(a * b, lo=0, extra=[b, a + b]))


def a_order():
    a, b, c = R.randint(2, 9), R.randint(2, 6), R.randint(2, 6)
    return Q(f"What is {a} + {b} × {c}?", f"Чему равно {a} + {b} × {c}?", str(a + b * c), near(a + b * c, lo=0, extra=[(a + b) * c]))


def a_square():
    n = R.randint(3, 12)
    return Q(f"What is {n}²?", f"Чему равно {n}²?", str(n * n), near(n * n, lo=0, extra=[2 * n, n * n - n, n * n + n]))


def a_seq():
    s, d = R.randint(1, 9), R.randint(2, 7)
    shown = ", ".join(str(s + d * i) for i in range(4))
    return Q(f"What number comes next: {shown}, ...?", f"Какое число идёт следующим: {shown}, ...?", str(s + 4 * d), near(s + 4 * d, lo=0, extra=[s + 3 * d + 1, s + 5 * d]))


def a_eval():
    x, a, b = R.randint(2, 6), R.randint(2, 5), R.randint(1, 9)
    return Q(f"If x = {x}, what is {a}x + {b}?", f"Если x = {x}, чему равно {a}x + {b}?", str(a * x + b), near(a * x + b, lo=0, extra=[a + x + b, a * (x + b)]))


def a_neg():
    a = R.randint(2, 8)
    b = a + R.randint(1, 8)
    return Q(f"What is {a} - {b}?", f"Чему равно {a} - {b}?", t(a - b), near(a - b, extra=[b - a, a + b]))


def a_double():
    n = R.randint(3, 15)
    return Q(f"A number plus itself makes {2 * n}. What is the number?", f"Число плюс оно же даёт {2 * n}. Что это за число?", str(n), near(n, lo=0, extra=[2 * n, n * n]))


def a_bigger():
    a = R.randint(2, 9)
    b = a + R.randint(1, 6)
    return Q(f"Which is bigger: -{a} or -{b}?", f"Что больше: -{a} или -{b}?", f"-{a}", [f"-{b}", ("They are equal", "Они равны")])


def a_two_step():
    x, a, b = R.randint(2, 9), R.randint(2, 5), R.randint(1, 9)
    if R.random() < 0.5:
        c = a * x + b
        sign = "+"
    else:
        c = a * x - b
        sign = "-"
        if c <= 0:
            return None
    return Q(f"Solve: {a}x {sign} {b} = {c}. What is x?", f"Реши: {a}x {sign} {b} = {c}. Чему равен x?", str(x), near(x, lo=0, extra=[c - b, c + b, c // a + 1]))


def a_paren():
    x, a, b = R.randint(1, 8), R.randint(2, 4), R.randint(1, 5)
    c = a * (x + b)
    return Q(f"Solve: {a}(x + {b}) = {c}. What is x?", f"Реши: {a}(x + {b}) = {c}. Чему равен x?", str(x), near(x, lo=0, extra=[c // a, c - b, x + b]))


def a_frac():
    a, k, b = R.randint(2, 5), R.randint(2, 6), R.randint(1, 6)
    x = a * k
    return Q(f"Solve: x/{a} + {b} = {k + b}. What is x?", f"Реши: x/{a} + {b} = {k + b}. Чему равен x?", str(x), near(x, lo=0, extra=[k, x + b, k + b]))


def a_negmul():
    a, b = R.randint(2, 9), R.randint(2, 9)
    kind = R.randint(0, 2)
    if kind == 0:
        return Q(f"What is (-{a}) × (-{b})?", f"Чему равно (-{a}) × (-{b})?", str(a * b), [str(-a * b), str(a + b), str(-(a + b))])
    if kind == 1:
        return Q(f"What is (-{a}) × {b}?", f"Чему равно (-{a}) × {b}?", str(-a * b), [str(a * b), str(b - a), str(-(a + b))])
    return Q(f"What is -{a} + {a + b}?", f"Чему равно -{a} + {a + b}?", str(b), near(b, extra=[-b, a + b, a]))


def a_simplify():
    a, b = R.randint(2, 6), R.randint(2, 6)
    return Q(f"Simplify: {a}x + {b}x", f"Упрости: {a}x + {b}x", f"{a + b}x", [f"{a * b}x", f"{a + b}x²", f"x^{a + b}"])


def a_expand():
    a, b = R.randint(2, 5), R.randint(2, 7)
    return Q(f"Expand: {a}(x + {b})", f"Раскрой скобки: {a}(x + {b})", f"{a}x + {a * b}", [f"{a}x + {b}", f"x + {a * b}", f"{a + b}x"])


def a_power():
    base, n = R.choice([(2, 4), (2, 5), (2, 6), (3, 3), (3, 4), (5, 3), (10, 3), (4, 3), (2, 7), (6, 3)])
    r = base ** n
    return Q(f"What is {base} to the power of {n}?", f"Чему равно {base} в степени {n}?", str(r), near(r, lo=0, extra=[base * n, base ** (n - 1), base ** (n + 1)]))


def a_percent():
    p, n = R.choice([(10, 50), (20, 50), (25, 80), (50, 36), (10, 120), (25, 200), (20, 90), (50, 150), (75, 80), (20, 150)])
    r = p * n // 100
    return Q(f"What is {p}% of {n}?", f"Сколько будет {p}% от {n}?", str(r), near(r, lo=0, extra=[p, n - r]))


def a_subst():
    x, a = R.randint(2, 6), R.randint(1, 5)
    return Q(f"If x = {x}, what is x² + {a}x?", f"Если x = {x}, чему равно x² + {a}x?", str(x * x + a * x), near(x * x + a * x, lo=0, extra=[2 * x + a * x, x * x + a]))


def a_sqrteq():
    n = R.randint(3, 12)
    return Q(f"Find all solutions of x² = {n * n}.", f"Найди все решения уравнения x² = {n * n}.", (f"{n} or -{n}", f"{n} или -{n}"), [str(n), str(n * n), (f"-{n}", f"-{n}")])


def a_mean():
    a, b = R.randint(2, 9), R.randint(2, 9)
    c = (-(a + b)) % 3 + R.choice([3, 6, 9])
    s = a + b + c
    assert s % 3 == 0
    return Q(f"What is the average of {a}, {b} and {c}?", f"Чему равно среднее число для {a}, {b} и {c}?", str(s // 3), near(s // 3, lo=0, extra=[s, s // 3 + 1]))


def a_line():
    a, b, x = R.randint(2, 5), R.randint(1, 6), R.randint(2, 6)
    return Q(f"y = {a}x + {b}. What is y when x = {x}?", f"y = {a}x + {b}. Чему равно y при x = {x}?", str(a * x + b), near(a * x + b, lo=0, extra=[a + x + b, (a + b) * x]))


def a_sqrt():
    n = R.randint(3, 15)
    return Q(f"What is the square root of {n * n}?", f"Чему равен квадратный корень из {n * n}?", str(n), near(n, lo=0, extra=[n * n // 2, 2 * n]))


def a_roots():
    p, q = sorted(R.sample(range(1, 8), 2))
    b, c = p + q, p * q
    cands = [(-p, -q), (1, c), (p, -q), (-p, q), (p + 1, q - 1), (p, q + 1), (p + 1, q + 1), (p - 1, q)]
    wrong = []
    for u_, v_ in cands:
        if (u_, v_) != (p, q) and (u_, v_) not in wrong and u_ != v_:
            wrong.append((u_, v_))
    return Q(f"Solve: x² - {b}x + {c} = 0", f"Реши: x² - {b}x + {c} = 0", (f"{p} and {q}", f"{p} и {q}"),
             [(f"{u_} and {v_}", f"{u_} и {v_}") for u_, v_ in wrong[:4]])


def a_vieta():
    p, q = sorted(R.sample(range(1, 9), 2))
    b, c = p + q, p * q
    if R.random() < 0.5:
        return Q(f"The equation x² - {b}x + {c} = 0 has two roots. What is their sum?", f"У уравнения x² - {b}x + {c} = 0 два корня. Чему равна их сумма?", str(b), near(b, lo=0, extra=[c, b + 1]))
    return Q(f"The equation x² - {b}x + {c} = 0 has two roots. What is their product?", f"У уравнения x² - {b}x + {c} = 0 два корня. Чему равно их произведение?", str(c), near(c, lo=0, extra=[b, c + 1]))


def a_system():
    y = R.randint(1, 7)
    x = y + R.randint(1, 5)
    s, d = x + y, x - y
    return Q(f"Solve: x + y = {s}, x - y = {d}", f"Реши: x + y = {s}, x - y = {d}", f"x = {x}, y = {y}",
             [f"x = {y}, y = {x}", f"x = {x + 1}, y = {y - 1}", f"x = {s}, y = {d}"] if y - 1 != x else [f"x = {y}, y = {x}", f"x = {s}, y = {d}", f"x = {d}, y = {s}"])


def a_disc():
    a, b, c = R.randint(1, 3), R.randint(2, 6), R.randint(-4, 3)
    if c == 0:
        c = 1
    D = b * b - 4 * a * c
    cs = f"+ {c}" if c > 0 else f"- {-c}"
    return Q(f"What is the discriminant of {a}x² + {b}x {cs}?" if a != 1 else f"What is the discriminant of x² + {b}x {cs}?",
             f"Чему равен дискриминант {a}x² + {b}x {cs}?" if a != 1 else f"Чему равен дискриминант x² + {b}x {cs}?",
             str(D), near(D, extra=[b * b + 4 * a * c, 4 * a * c - b * b, b * b - 2 * a * c]))


def a_factor():
    a = R.randint(2, 9)
    return Q(f"Factor: x² - {a * a}", f"Разложи на множители: x² - {a * a}", f"(x - {a})(x + {a})", [f"(x - {a})²", f"(x + {a})²", f"(x - {a * a})(x + 1)"])


def a_square_expand():
    a = R.randint(2, 7)
    return Q(f"Expand: (x + {a})²", f"Раскрой скобки: (x + {a})²", f"x² + {2 * a}x + {a * a}", [f"x² + {a * a}", f"x² + {a}x + {a * a}", f"x² + {2 * a}x + {a}"])


def a_ineq():
    a, k, b = R.randint(2, 4), R.randint(2, 6), R.randint(1, 6)
    c = a * k - b
    return Q(f"Solve: {a}x - {b} > {c}", f"Реши: {a}x - {b} > {c}", f"x > {k}", [f"x < {k}", f"x > {-k}", f"x > {k + b}"])


def a_away():
    c, d = R.randint(2, 6), R.randint(2, 6)
    return Q(f"Which numbers are exactly {d} away from {c} on the number line?", f"Какие числа находятся ровно в {d} шагах от {c} на числовой прямой?",
             (f"{c + d} and {c - d}", f"{c + d} и {c - d}"), [(str(c + d), str(c + d)), (f"{d} and -{d}", f"{d} и -{d}"), (f"{c * d} and -{c * d}", f"{c * d} и -{c * d}")])


def a_exprule():
    a, b = R.randint(2, 4), R.randint(2, 4)
    right = f"x^{a + b}"
    wrong = []
    for w in (f"x^{a * b}", f"2x^{a + b}", f"x^{a + b + 1}", f"x^{a + b - 1}"):
        if w != right and w not in wrong:
            wrong.append(w)
    return Q(f"Simplify: x^{a} × x^{b}", f"Упрости: x^{a} × x^{b}", right, wrong)


def a_powerto():
    base, n = R.choice([(2, 5), (2, 6), (3, 4), (10, 3), (2, 7), (5, 3), (3, 3)])
    r = base ** n
    return Q(f"To what power must {base} be raised to get {r}?", f"В какую степень надо возвести {base}, чтобы получить {r}?", str(n), near(n, lo=1, extra=[r // base]))


def a_sumn():
    n = R.choice([6, 8, 10, 12, 15, 20])
    s = n * (n + 1) // 2
    return Q(f"What is 1 + 2 + 3 + ... + {n}?", f"Чему равна сумма 1 + 2 + 3 + ... + {n}?", str(s), near(s, lo=0, extra=[n * n, s + n, s - n]))


def a_geo():
    s, r = R.randint(1, 3), R.choice([2, 3])
    terms = [s * r ** i for i in range(4)]
    nxt = s * r ** 4
    return Q(f"What number comes next: {', '.join(map(str, terms))}, ...?", f"Какое число идёт следующим: {', '.join(map(str, terms))}, ...?", str(nxt),
             near(nxt, lo=0, extra=[terms[-1] + r, terms[-1] + terms[-1] - terms[-2]]))


def a_slope():
    m, x1, y1 = R.randint(2, 5), R.randint(0, 3), R.randint(0, 4)
    x2 = x1 + R.randint(1, 3)
    y2 = y1 + m * (x2 - x1)
    return Q(f"A line goes through ({x1}, {y1}) and ({x2}, {y2}). What is its slope?", f"Прямая проходит через ({x1}, {y1}) и ({x2}, {y2}). Чему равен её угловой коэффициент?",
             str(m), near(m, lo=1, extra=[y2 - y1, x2 - x1 + m]))


def a_fraceq():
    a, b = R.choice([(2, 3), (3, 6), (2, 4), (3, 4), (2, 5)])
    m = R.randint(1, 2)
    x = a * b // gcd(a, b) * m
    c = x // a + x // b
    return Q(f"Solve: x/{a} + x/{b} = {c}", f"Реши: x/{a} + x/{b} = {c}", str(x), near(x, lo=0, extra=[c, x + a, a * b]))


ALGEBRA = {
    "easy": dict(
        fixed=[
            Q("What is x + x + x?", "Чему равно x + x + x?", "3x", ["x³", "x + 3"]),
            Q("Any number multiplied by 0 gives...", "Любое число, умноженное на 0, даёт...", "0", ["1", ("the same number", "то же число")]),
            Q("What does the letter x mean in an equation?", "Что означает буква x в уравнении?", ("An unknown number", "Неизвестное число"), [("A kind of fraction", "Вид дроби"), ("A unit of length", "Единицу длины")]),
            Q("What do we call the answer of an addition?", "Как называется результат сложения?", ("The sum", "Сумма"), [("The factor", "Множитель"), ("The root", "Корень")]),
        ],
        gens=[a_add, a_sub, a_mul, a_div, a_order, a_square, a_seq, a_eval, a_neg, a_double, a_bigger]),
    "medium": dict(
        fixed=[
            Q("What sign does the product of two negative numbers have?", "Какой знак у произведения двух отрицательных чисел?", ("Plus", "Плюс"), [("Minus", "Минус"), ("It depends", "Зависит от чисел")]),
            Q("What is the value of any number to the power of 0?", "Чему равно любое число (кроме нуля) в степени 0?", "1", ["0", ("The number itself", "Само число")]),
            Q("What is the root of an equation?", "Что такое корень уравнения?", ("A value of x that makes it true", "Значение x, при котором уравнение верно"), [("The first number in it", "Первое число в нём"), ("The biggest number in it", "Самое большое число в нём")]),
        ],
        gens=[a_two_step, a_paren, a_frac, a_negmul, a_simplify, a_expand, a_power, a_percent, a_subst, a_sqrteq, a_mean, a_line, a_sqrt]),
    "hard": dict(
        fixed=[
            Q("How many solutions can a quadratic equation have at most?", "Сколько решений может иметь квадратное уравнение самое большее?", "2", ["1", "4", "3"]),
            Q("What is the discriminant of a quadratic equation used for?", "Для чего нужен дискриминант квадратного уравнения?", ("To find out how many roots there are", "Чтобы узнать, сколько у него корней"), [("To find the biggest value of x", "Чтобы найти наибольшее значение x"), ("To add the coefficients", "Чтобы сложить коэффициенты"), ("To draw the graph faster", "Чтобы быстрее нарисовать график")]),
        ],
        gens=[a_roots, a_vieta, a_system, a_disc, a_factor, a_square_expand, a_ineq, a_away, a_exprule, a_powerto, a_sumn, a_geo, a_slope, a_fraceq]),
}


# ------------------------------------------------------------------------------------------------ geometry
SHAPES = [("triangle", "треугольник", 3), ("square", "квадрат", 4), ("pentagon", "пятиугольник", 5), ("hexagon", "шестиугольник", 6), ("octagon", "восьмиугольник", 8)]
SHAPE_GEN = {"triangle": "треугольника", "square": "квадрата", "pentagon": "пятиугольника", "hexagon": "шестиугольника", "octagon": "восьмиугольника"}


def g_sides():
    en, ru, n = R.choice(SHAPES)
    return Q(f"How many sides does a {en} have?", f"Сколько сторон у {SHAPE_GEN[en]}?", str(n), near(n, lo=3, extra=[n + 1, n - 1]))


def g_perim_rect():
    a, b = R.randint(3, 9), R.randint(2, 7)
    if a == b:
        b += 1
    p = 2 * (a + b)
    return Q(f"A rectangle is {a} cm long and {b} cm wide. What is its perimeter?", f"Длина прямоугольника {a} см, ширина {b} см. Чему равен его периметр?",
             (f"{p} cm", f"{p} см"), [(f"{a * b} cm", f"{a * b} см"), (f"{a + b} cm", f"{a + b} см"), (f"{p + 2} cm", f"{p + 2} см")])


def g_perim_sq():
    a = R.randint(2, 12)
    return Q(f"A square has a side of {a} cm. What is its perimeter?", f"Сторона квадрата {a} см. Чему равен его периметр?",
             (f"{4 * a} cm", f"{4 * a} см"), [(f"{2 * a} cm", f"{2 * a} см"), (f"{a * a} cm", f"{a * a} см"), (f"{4 * a + 4} cm", f"{4 * a + 4} см")])


def g_area_sq():
    a = R.randint(2, 12)
    return Q(f"A square has a side of {a} cm. What is its area?", f"Сторона квадрата {a} см. Чему равна его площадь?",
             (f"{a * a} cm²", f"{a * a} см²"), [(f"{4 * a} cm²", f"{4 * a} см²"), (f"{2 * a} cm²", f"{2 * a} см²"), (f"{a * a + a} cm²", f"{a * a + a} см²")])


def g_area_rect():
    a, b = R.randint(3, 12), R.randint(2, 9)
    if a == b:
        b += 1
    return Q(f"A rectangle is {a} cm by {b} cm. What is its area?", f"Прямоугольник {a} см на {b} см. Чему равна его площадь?",
             (f"{a * b} cm²", f"{a * b} см²"), [(f"{2 * (a + b)} cm²", f"{2 * (a + b)} см²"), (f"{a + b} cm²", f"{a + b} см²"), (f"{a * b + a} cm²", f"{a * b + a} см²")])


def g_diam():
    r = R.randint(2, 15)
    return Q(f"A circle has a radius of {r} cm. What is its diameter?", f"Радиус круга {r} см. Чему равен его диаметр?",
             (f"{2 * r} cm", f"{2 * r} см"), [(f"{r} cm", f"{r} см"), (f"{r * r} cm", f"{r * r} см"), (f"{r + 2} cm", f"{r + 2} см")])


def g_tri_angle():
    a, b = R.choice([(60, 60), (90, 30), (50, 60), (40, 70), (30, 30), (45, 45), (20, 80), (100, 30)])
    c = 180 - a - b
    return Q(f"A triangle has angles of {a}° and {b}°. What is the third angle?", f"В треугольнике два угла {a}° и {b}°. Чему равен третий угол?",
             f"{c}°", [f"{c + 10}°", f"{180 - a}°", f"{c - 10 if c > 10 else c + 20}°"])


def g_compl():
    a = R.choice([20, 25, 30, 35, 40, 45, 55, 60, 65, 70])
    return Q(f"Two angles make a right angle. One is {a}°. What is the other?", f"Два угла вместе дают прямой угол. Один равен {a}°. Чему равен другой?",
             f"{90 - a}°", [f"{180 - a}°", f"{a}°", f"{90 - a + 10}°"])


def g_suppl():
    a = R.choice([100, 110, 120, 130, 140, 150, 65, 75, 85, 35])
    return Q(f"Two angles lie on a straight line. One is {a}°. What is the other?", f"Два угла лежат на одной прямой. Один равен {a}°. Чему равен другой?",
             f"{180 - a}°", [f"{90 - a if a < 90 else a - 90}°", f"{360 - a}°", f"{a}°"])


def g_tri_area():
    b, h = R.choice([(4, 3), (6, 4), (8, 5), (10, 6), (12, 5), (6, 7), (10, 8), (14, 6)])
    s = b * h // 2
    return Q(f"A triangle has a base of {b} cm and a height of {h} cm. What is its area?", f"Основание треугольника {b} см, высота {h} см. Чему равна его площадь?",
             (f"{s} cm²", f"{s} см²"), [(f"{b * h} cm²", f"{b * h} см²"), (f"{b + h} cm²", f"{b + h} см²"), (f"{s + b} cm²", f"{s + b} см²")])


def g_circle_area():
    r = R.randint(2, 9)
    return Q(f"A circle has a radius of {r} cm. What is its area? (pi = the number pi)", f"Радиус круга {r} см. Чему равна его площадь? (pi = число пи)",
             (f"{r * r} pi", f"{r * r} pi"), [(f"{2 * r} pi", f"{2 * r} pi"), (f"{r} pi", f"{r} pi"), (f"{2 * r * r} pi", f"{2 * r * r} pi")])


def g_circle_len():
    r = R.randint(2, 9)
    return Q(f"A circle has a radius of {r} cm. What is its circumference? (pi = the number pi)", f"Радиус круга {r} см. Чему равна длина окружности? (pi = число пи)",
             (f"{2 * r} pi", f"{2 * r} pi"), [(f"{r} pi", f"{r} pi"), (f"{r * r} pi", f"{r * r} pi"), (f"{4 * r} pi", f"{4 * r} pi")])


def g_pyth():
    a, b, c = R.choice([(3, 4, 5), (6, 8, 10), (5, 12, 13), (8, 15, 17), (9, 12, 15), (7, 24, 25), (12, 16, 20)])
    return Q(f"A right triangle has legs of {a} and {b}. What is the hypotenuse?", f"Катеты прямоугольного треугольника равны {a} и {b}. Чему равна гипотенуза?",
             str(c), near(c, lo=1, extra=[a + b, c + 1, c - 1]))


def g_regular():
    en, ru, n = R.choice([("square", "квадрата", 4), ("pentagon", "пятиугольника", 5), ("hexagon", "шестиугольника", 6), ("octagon", "восьмиугольника", 8), ("triangle", "треугольника", 3)])
    ang = (n - 2) * 180 // n
    return Q(f"What is one angle of a regular {en}?", f"Чему равен один угол правильного {ru}?", f"{ang}°", [f"{ang + 15}°", f"{ang - 15}°", f"{180 - ang}°"])


def g_cube():
    a = R.randint(2, 6)
    return Q(f"A cube has an edge of {a} cm. What is its volume?", f"Ребро куба {a} см. Чему равен его объём?",
             (f"{a ** 3} cm³", f"{a ** 3} см³"), [(f"{3 * a} cm³", f"{3 * a} см³"), (f"{a * a} cm³", f"{a * a} см³"), (f"{6 * a * a} cm³", f"{6 * a * a} см³")])


def g_box():
    a, b, c = R.randint(2, 6), R.randint(2, 6), R.randint(2, 5)
    v = a * b * c
    return Q(f"A box is {a} cm long, {b} cm wide and {c} cm high. What is its volume?", f"Коробка: длина {a} см, ширина {b} см, высота {c} см. Чему равен её объём?",
             (f"{v} cm³", f"{v} см³"), [(f"{a + b + c} cm³", f"{a + b + c} см³"), (f"{v + a} cm³", f"{v + a} см³"), (f"{2 * (a * b + b * c + a * c)} cm³", f"{2 * (a * b + b * c + a * c)} см³")])


def g_parallelogram():
    b, h = R.randint(3, 12), R.randint(2, 8)
    return Q(f"A parallelogram has a base of {b} cm and a height of {h} cm. What is its area?", f"Основание параллелограмма {b} см, высота {h} см. Чему равна его площадь?",
             (f"{b * h} cm²", f"{b * h} см²"), [(f"{b * h // 2 if b * h % 2 == 0 else b * h + 1} cm²", f"{b * h // 2 if b * h % 2 == 0 else b * h + 1} см²"), (f"{b + h} cm²", f"{b + h} см²"), (f"{2 * (b + h)} cm²", f"{2 * (b + h)} см²")])


def g_other_side():
    a, b = R.randint(3, 9), R.randint(2, 8)
    return Q(f"A rectangle has an area of {a * b} cm² and one side of {a} cm. What is the other side?", f"Площадь прямоугольника {a * b} см², одна сторона {a} см. Чему равна другая сторона?",
             (f"{b} cm", f"{b} см"), [(f"{a * b - a} cm", f"{a * b - a} см"), (f"{a + b} cm", f"{a + b} см"), (f"{b + 2} cm" if b + 2 != a else f"{b + 3} cm", f"{b + 2} см" if b + 2 != a else f"{b + 3} см")])


def g_isosceles():
    apex = R.choice([20, 30, 40, 50, 80, 100, 120])
    base = (180 - apex) // 2
    return Q(f"An isosceles triangle has an angle of {apex}° at the top. What is each angle at the base?", f"У равнобедренного треугольника угол при вершине {apex}°. Чему равен каждый угол при основании?",
             f"{base}°", [f"{180 - apex}°", f"{base + 10}°", f"{apex}°"])


def g_polysum():
    n = R.choice([5, 6, 7, 8, 9, 10, 12])
    s = (n - 2) * 180
    return Q(f"What is the sum of the angles of a polygon with {n} sides?", f"Чему равна сумма углов многоугольника с {n} сторонами?", f"{s}°", [f"{s + 180}°", f"{s - 180}°", f"{n * 90}°"])


def g_diag():
    n, name, ru = R.choice([(5, "pentagon", "пятиугольника"), (6, "hexagon", "шестиугольника"), (7, "heptagon", "семиугольника"), (8, "octagon", "восьмиугольника"), (10, "decagon", "десятиугольника")])
    d = n * (n - 3) // 2
    return Q(f"How many diagonals does a {name} have?", f"Сколько диагоналей у {ru}?", str(d), near(d, lo=1, extra=[n, n * (n - 3), d + n]))


def g_missing_leg():
    c, a, b = R.choice([(13, 5, 12), (10, 6, 8), (17, 8, 15), (15, 9, 12), (25, 7, 24), (20, 12, 16), (26, 10, 24), (41, 9, 40)])
    return Q(f"A right triangle has a hypotenuse of {c} and one leg of {a}. What is the other leg?", f"Гипотенуза прямоугольного треугольника равна {c}, один катет {a}. Чему равен другой катет?",
             str(b), near(b, lo=1, extra=[c - a, c + a, b + 1]))


def g_cylinder():
    r, h = R.choice([(2, 5), (3, 4), (3, 5), (2, 7), (4, 3), (5, 2)])
    v = r * r * h
    return Q(f"A cylinder has a radius of {r} cm and a height of {h} cm. What is its volume? (pi = the number pi)", f"Радиус цилиндра {r} см, высота {h} см. Чему равен его объём? (pi = число пи)",
             (f"{v} pi", f"{v} pi"), [(f"{2 * r * h} pi", f"{2 * r * h} pi"), (f"{r * h} pi", f"{r * h} pi"), (f"{v * 2} pi", f"{v * 2} pi")])


def g_sphere():
    r = R.choice([3, 6])
    v = 4 * r ** 3 // 3
    return Q(f"A ball has a radius of {r} cm. What is its volume? (pi = the number pi)", f"Радиус шара {r} см. Чему равен его объём? (pi = число пи)",
             (f"{v} pi", f"{v} pi"), [(f"{r ** 3} pi", f"{r ** 3} pi"), (f"{4 * r * r} pi", f"{4 * r * r} pi"), (f"{2 * v} pi", f"{2 * v} pi")])


def g_halfcircle():
    r = R.choice([2, 4, 6, 8, 10])
    return Q(f"What is the area of a half circle with a radius of {r} cm? (pi = the number pi)", f"Чему равна площадь полукруга с радиусом {r} см? (pi = число пи)",
             (f"{r * r // 2} pi", f"{r * r // 2} pi"), [(f"{r * r} pi", f"{r * r} pi"), (f"{r} pi", f"{r} pi"), (f"{r * r // 4} pi", f"{r * r // 4} pi")])


def g_heron():
    a, b, c, s = R.choice([(3, 4, 5, 6), (5, 12, 13, 30), (13, 14, 15, 84), (6, 8, 10, 24), (9, 10, 17, 36), (7, 15, 20, 42)])
    return Q(f"A triangle has sides of {a}, {b} and {c}. What is its area?", f"Стороны треугольника равны {a}, {b} и {c}. Чему равна его площадь?",
             str(s), near(s, lo=1, extra=[a * b // 2, s + a, s * 2]))


def g_scale():
    k, what = R.choice([(2, "square"), (3, "square"), (2, "cube"), (3, "cube"), (4, "square"), (5, "square")])
    if what == "square":
        return Q(f"Every side of a square becomes {k} times longer. How many times does its area grow?", f"Каждая сторона квадрата стала в {k} раз длиннее. Во сколько раз выросла его площадь?",
                 str(k * k), near(k * k, lo=1, extra=[k, 2 * k, k * k + 1]))
    return Q(f"Every edge of a cube becomes {k} times longer. How many times does its volume grow?", f"Каждое ребро куба стало в {k} раз длиннее. Во сколько раз вырос его объём?",
             str(k ** 3), near(k ** 3, lo=1, extra=[k * k, 3 * k, k * k * k + k]))


def g_inscribed():
    c = R.choice([40, 60, 80, 100, 120, 140, 160])
    return Q(f"A central angle of a circle is {c}°. What is the inscribed angle on the same arc?", f"Центральный угол окружности равен {c}°. Чему равен вписанный угол на той же дуге?",
             f"{c // 2}°", [f"{c}°", f"{c * 2}°", f"{180 - c}°"])


def g_trapezoid():
    a, b, h = R.choice([(4, 8, 5), (3, 7, 4), (6, 10, 3), (5, 9, 6), (2, 6, 7), (8, 12, 4)])
    s = (a + b) * h // 2
    return Q(f"A trapezoid has bases of {a} cm and {b} cm and a height of {h} cm. What is its area?", f"Основания трапеции {a} см и {b} см, высота {h} см. Чему равна её площадь?",
             (f"{s} cm²", f"{s} см²"), [(f"{a * b * h // 2} cm²", f"{a * b * h // 2} см²"), (f"{(a + b) * h} cm²", f"{(a + b) * h} см²"), (f"{s + h} cm²", f"{s + h} см²")])


def g_exterior():
    n = R.choice([3, 4, 5, 6, 8, 9, 10, 12])
    return Q(f"What is one outer angle of a regular polygon with {n} sides?", f"Чему равен один внешний угол правильного многоугольника с {n} сторонами?",
             f"{360 // n}°", [f"{180 - 360 // n}°", f"{360 // n + 10}°", f"{(n - 2) * 180 // n}°"])


def g_rect_diag():
    a, b, c = R.choice([(3, 4, 5), (6, 8, 10), (5, 12, 13), (9, 12, 15), (8, 15, 17)])
    return Q(f"A rectangle is {a} by {b}. What is its diagonal?", f"Прямоугольник {a} на {b}. Чему равна его диагональ?", str(c), near(c, lo=1, extra=[a + b, c + 1, c - 1]))


def g_dist():
    x1, y1, dx, dy, c = R.choice([(0, 0, 3, 4, 5), (1, 2, 3, 4, 5), (2, 1, 5, 12, 13), (0, 0, 6, 8, 10), (1, 1, 8, 6, 10), (3, 2, 5, 12, 13)])
    return Q(f"What is the distance between the points ({x1}, {y1}) and ({x1 + dx}, {y1 + dy})?", f"Чему равно расстояние между точками ({x1}, {y1}) и ({x1 + dx}, {y1 + dy})?",
             str(c), near(c, lo=1, extra=[dx + dy, c + 1, dx * dy // 2]))


def g_mid():
    x1, y1 = R.choice([(2, 4), (0, 2), (4, 6), (2, 8), (6, 2)])
    x2, y2 = x1 + 2 * R.randint(1, 4), y1 + 2 * R.randint(1, 4)
    mx, my = (x1 + x2) // 2, (y1 + y2) // 2
    return Q(f"What is the midpoint of the segment from ({x1}, {y1}) to ({x2}, {y2})?", f"Чему равна середина отрезка от ({x1}, {y1}) до ({x2}, {y2})?",
             f"({mx}, {my})", [f"({x1 + x2}, {y1 + y2})", f"({mx}, {my + 1})", f"({mx + 1}, {my})"])


GEOMETRY = {
    "easy": dict(
        fixed=[
            Q("How many degrees does a right angle have?", "Сколько градусов в прямом угле?", "90", ["45", "180"]),
            Q("How many degrees does a straight angle have?", "Сколько градусов в развёрнутом угле?", "180", ["90", "360"]),
            Q("What is the sum of the angles of a triangle?", "Чему равна сумма углов треугольника?", "180", ["90", "360"]),
            Q("What do we call a triangle with three equal sides?", "Как называется треугольник с тремя равными сторонами?", ("Equilateral", "Равносторонний"), [("Right-angled", "Прямоугольный"), ("Obtuse", "Тупоугольный")]),
            Q("A segment from the centre of a circle to its edge is called...", "Отрезок от центра круга до его края называется...", ("A radius", "Радиус"), [("A diameter", "Диаметр"), ("A chord", "Хорда")]),
            Q("How many faces does a cube have?", "Сколько граней у куба?", "6", ["4", "8"]),
            Q("How many corners (vertices) does a cube have?", "Сколько вершин у куба?", "8", ["6", "12"]),
            Q("How many edges does a cube have?", "Сколько рёбер у куба?", "12", ["8", "6"]),
            Q("Which shape has no corners?", "У какой фигуры нет углов?", ("A circle", "Круг"), [("A square", "Квадрат"), ("A triangle", "Треугольник")]),
            Q("Two lines that never meet are called...", "Две прямые, которые никогда не пересекаются, называются...", ("Parallel", "Параллельными"), [("Perpendicular", "Перпендикулярными"), ("Crossing", "Пересекающимися")]),
            Q("Lines that meet at a right angle are called...", "Прямые, которые пересекаются под прямым углом, называются...", ("Perpendicular", "Перпендикулярными"), [("Parallel", "Параллельными"), ("Curved", "Кривыми")]),
            Q("How many equal sides does a square have?", "Сколько равных сторон у квадрата?", "4", ["2", "3"]),
        ],
        gens=[g_sides, g_perim_rect, g_perim_sq, g_area_sq, g_area_rect, g_diam, g_tri_angle, g_compl, g_suppl]),
    "medium": dict(
        fixed=[
            Q("What is the longest side of a right triangle called?", "Как называется самая длинная сторона прямоугольного треугольника?", ("The hypotenuse", "Гипотенуза"), [("A leg", "Катет"), ("The base", "Основание")]),
            Q("What is the number pi approximately?", "Чему примерно равно число пи?", "3.14", ["2.17", "4.13"]),
            Q("An angle bigger than 90° but smaller than 180° is called...", "Угол больше 90°, но меньше 180°, называется...", ("Obtuse", "Тупым"), [("Acute", "Острым"), ("Right", "Прямым")]),
            Q("A line that touches a circle at one point is called...", "Прямая, которая касается окружности в одной точке, называется...", ("A tangent", "Касательной"), [("A chord", "Хордой"), ("A diameter", "Диаметром")]),
            Q("How many degrees are around a point (a full turn)?", "Сколько градусов в полном повороте вокруг точки?", "360", ["180", "270"]),
        ],
        gens=[g_tri_area, g_circle_area, g_circle_len, g_pyth, g_regular, g_cube, g_box, g_parallelogram, g_other_side, g_isosceles]),
    "hard": dict(
        fixed=[
            Q("What is the sum of the outer angles of any convex polygon?", "Чему равна сумма внешних углов любого выпуклого многоугольника?", "360", ["180", "720", "540"]),
            Q("Which theorem says that a² + b² = c² in a right triangle?", "Какая теорема говорит, что a² + b² = c² в прямоугольном треугольнике?", ("The Pythagorean theorem", "Теорема Пифагора"), [("The theorem of Thales", "Теорема Фалеса"), ("Vieta's theorem", "Теорема Виета"), ("The theorem of Euclid", "Теорема Евклида")]),
            Q("Where is the centre of the circle around a right triangle?", "Где находится центр окружности, описанной около прямоугольного треугольника?",
              ("In the middle of the hypotenuse", "В середине гипотенузы"), [("At the right-angle corner", "В вершине прямого угла"), ("In the middle of a leg", "В середине катета"), ("Outside the triangle", "Вне треугольника")]),
        ],
        gens=[g_polysum, g_diag, g_missing_leg, g_cylinder, g_sphere, g_halfcircle, g_heron, g_scale, g_inscribed, g_trapezoid, g_exterior, g_rect_diag, g_dist, g_mid]),
}


def build(spec, level):
    """25 different questions: the fixed ones first, then the generated ones in turn until the class is full."""
    s = spec[level]
    out, seen = [], set()

    def add(q):
        if q is None or q.en in seen:
            return False
        seen.add(q.en)
        out.append(q)
        return True

    for q in s["fixed"]:
        add(q)
    guard = 0
    while len(out) < COUNT:
        for gen in s["gens"]:
            if len(out) >= COUNT:
                break
            add(gen())
        guard += 1
        assert guard < 400, f"cannot fill {level}: {len(out)} questions"
    R.shuffle(out)
    return out[:COUNT]


def write(name, spec):
    parts = [f"# {name}: generated by tools/make_math_questions.py (do not edit by hand, edit the script and run it again)"]
    for level in ("easy", "medium", "hard"):
        qs = build(spec, level)
        for lang in ("ru", "en"):
            parts.append(f"[{level}.{lang}]")
            parts += [q.line(lang, NEED[level]) for q in qs]
    (OUT / f"{name}.txt").write_text("\n".join(parts) + "\n", encoding="utf-8")
    print(f"{name}.txt written")


if __name__ == "__main__":
    write("algebra", ALGEBRA)
    write("geometry", GEOMETRY)
