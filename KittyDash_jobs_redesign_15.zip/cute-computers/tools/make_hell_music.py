#!/usr/bin/env python3
"""The quiet music of the haunted site (address 666): a pit of sinners, heard from far away.

Layers (all built to wrap around, so the 48 second track loops with no gap and no click):
  - a sub drone: a root, a flat fifth, a minor second and a tritone, slowly breathing against each other;
  - the breath of the pit: dark filtered noise, rising and falling;
  - moaning choirs: several detuned human-like voices (a glottal source through vowel formants) that sink
    in pitch, like people giving up;
  - whispers: formant-filtered noise cut into syllables, going from ear to ear;
  - far screams: thin, high, soaked in reverb, very rare;
  - two tolls of a cracked bell and a slow, uneven heartbeat.
Everything goes through a long dark reverb (a circular convolution, so the loop stays seamless).

Needs numpy + scipy + ffmpeg (with libvorbis).
Output: src/main/resources/assets/cutemod/sounds/music/hell.ogg   (the sound event "music.hell" is in sounds.json)
"""
import os
import subprocess
import tempfile
import wave

import numpy as np
from scipy.signal import butter, sosfilt

SR = 32000
LEN_S = 48
L = SR * LEN_S
RNG = np.random.default_rng(666)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources",
                   "assets", "cutemod", "sounds", "music", "hell.ogg")


# ---------------------------------------------------------------- helpers
def snap(f):
    """A frequency that fits a whole number of times into the loop (so its phase wraps exactly)."""
    return max(1, round(f * LEN_S)) / LEN_S


def tt(n): return np.arange(n) / SR


def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo / (SR / 2), hi / (SR / 2)], btype="band", output="sos"), x)


def lp(x, fc, order=2):
    return sosfilt(butter(order, fc / (SR / 2), btype="low", output="sos"), x)


def hp(x, fc, order=2):
    return sosfilt(butter(order, fc / (SR / 2), btype="high", output="sos"), x)


def circ_noise(lo, hi, slope=0.0):
    """White noise of exactly one loop, band limited by an FFT mask (so it wraps seamlessly)."""
    spec = np.fft.rfft(RNG.standard_normal(L))
    f = np.fft.rfftfreq(L, 1 / SR)
    mask = np.zeros_like(f)
    inside = (f >= lo) & (f <= hi)
    mask[inside] = 1.0
    edge = max(8.0, lo * 0.3)
    mask = np.convolve(mask, np.hanning(int(edge * LEN_S) | 1) / np.hanning(int(edge * LEN_S) | 1).sum(), "same")
    mask *= (np.maximum(f, 1.0) / 100.0) ** slope
    x = np.fft.irfft(spec * mask, L)
    return x / (np.max(np.abs(x)) + 1e-9)


def add(buf, sig, start):
    """Add sig into the (L,) buffer from sample start, wrapping around the end."""
    start %= L
    n = len(sig)
    while n > 0:
        k = min(n, L - start)
        buf[start:start + k] += sig[:k]
        sig = sig[k:]
        n -= k
        start = 0


def pan(sig, p):
    """p in -1..1 -> (left, right) with constant power."""
    a = (p + 1) * np.pi / 4
    return sig * np.cos(a), sig * np.sin(a)


def env(n, a, r, curve=1.6):
    """An envelope with an attack and a release (seconds), smooth."""
    e = np.ones(n)
    na, nr = min(n // 2, int(a * SR)), min(n // 2, int(r * SR))
    if na > 0: e[:na] = np.linspace(0, 1, na) ** curve
    if nr > 0: e[-nr:] = np.linspace(1, 0, nr) ** curve
    return e


def smooth_noise(n, rate, depth=1.0):
    """A slowly wandering curve in -depth..depth (rate = changes per second)."""
    m = max(2, int(n / SR * rate) + 2)
    pts = RNG.uniform(-1, 1, m)
    return np.interp(np.linspace(0, m - 1, n), np.arange(m), pts) * depth


# ---------------------------------------------------------------- the human voice
VOWELS = {                       # formants (Hz) and their strengths
    "oh": ([500, 880, 2500], [1.0, 0.55, 0.20]),
    "ah": ([700, 1150, 2600], [1.0, 0.60, 0.22]),
    "oo": ([320, 800, 2250], [1.0, 0.40, 0.12]),
    "uh": ([600, 1000, 2400], [1.0, 0.50, 0.18]),
    "eh": ([530, 1840, 2480], [1.0, 0.45, 0.20]),
    "ee": ([300, 2200, 3000], [1.0, 0.30, 0.15]),
}


def formants(x, vowel, shift=1.0):
    fs, gs = VOWELS[vowel]
    out = np.zeros_like(x)
    for f, g in zip(fs, gs):
        f *= shift
        out += g * bp(x, f * 0.88, min(f * 1.14, SR * 0.45))
    return out


def voice(f0, vowel="oh", breath=0.15, jitter=0.012, shift=1.0, vib=5.2, vib_depth=0.012):
    """A throat: f0 is a curve in Hz (one value per sample). Returns a mono signal."""
    n = len(f0)
    t = tt(n)
    vibr = 1 + vib_depth * np.sin(2 * np.pi * vib * t + RNG.uniform(0, 6.28)) * np.minimum(1, t / 1.5)
    wob = 1 + jitter * smooth_noise(n, 9)
    f = f0 * vibr * wob
    ph = 2 * np.pi * np.cumsum(f) / SR
    top = float(np.max(f))
    kmax = int(min(40, 4200 / max(top, 60)))
    src = np.zeros(n)
    for k in range(1, kmax + 1):
        src += np.sin(k * ph + 0.3 * k) / k ** 1.35
    src += breath * RNG.standard_normal(n) * 0.5
    y = formants(src, vowel, shift)
    return y / (np.max(np.abs(y)) + 1e-9)


# ---------------------------------------------------------------- layers
def drone(Lb, Rb):
    notes = [(36.7, 0.9, -0.2), (54.6, 0.55, 0.2), (38.9, 0.42, 0.0), (51.9, 0.30, -0.1), (73.4, 0.22, 0.3)]
    t = tt(L)
    for k, (f, g, p) in enumerate(notes):
        s = np.zeros(L)
        for d in (-0.35, 0.0, 0.41):                         # slowly beating detune
            ff = snap(f + d)
            ph = 2 * np.pi * ff * t + RNG.uniform(0, 6.28)       # random phases: no sub-bass swell at the seam
            s += np.sin(ph) + 0.5 * np.sin(2 * ph + 0.7) + 0.25 * np.sin(3 * ph + 1.9)
        lfo = 0.55 + 0.45 * np.sin(2 * np.pi * snap(0.03 + 0.017 * k) * t + k * 1.3)
        a, b = pan(s * lfo * g, p)
        Lb += a; Rb += b
    # the breath of the pit
    for lo, hi, g, rate in ((40, 140, 0.9, 2), (200, 900, 0.5, 3)):
        for ch in (Lb, Rb):
            n = circ_noise(lo, hi)
            m = 0.5 + 0.5 * np.sin(2 * np.pi * snap(rate / 48) * t + RNG.uniform(0, 6.28))
            ch += n * (0.25 + 0.75 * m) * g * 0.6


def choir(Lb, Rb, t0, dur, base, p, vowels=("oh", "uh"), size=4, spread=0.35, sink=2.6, peak=0.9):
    """A group of sinners moaning together: detuned, out of time, every one slowly sinking."""
    for i in range(size):
        d = dur * RNG.uniform(0.75, 1.1)
        n = int(d * SR)
        t = np.linspace(0, 1, n)
        f0 = base * 2 ** (RNG.uniform(-spread, spread) / 12) * 2 ** (-sink * t ** 1.4 / 12)
        f0 *= 1 + 0.015 * smooth_noise(n, 3)
        y = voice(f0, vowel=vowels[i % len(vowels)], breath=RNG.uniform(0.1, 0.35),
                  jitter=RNG.uniform(0.01, 0.03), shift=RNG.uniform(0.92, 1.08), vib=RNG.uniform(4.2, 6.4))
        y *= env(n, d * 0.40, d * 0.45, 1.3) * (0.7 + 0.3 * np.sin(2 * np.pi * RNG.uniform(0.15, 0.5) * np.arange(n) / SR))
        a, b = pan(y * peak / size ** 0.5, np.clip(p + RNG.uniform(-0.5, 0.5), -1, 1))
        s = int((t0 + RNG.uniform(0, 1.8)) * SR)
        add(Lb, a, s); add(Rb, b, s)


def whisper(Lb, Rb, t0, p, words=6, level=0.5):
    """Whispered speech with no words: noise through changing vowels, cut into syllables."""
    pos = t0
    for _ in range(words):
        d = RNG.uniform(0.09, 0.26)
        n = int(d * SR)
        v = list(VOWELS)[RNG.integers(len(VOWELS))]
        x = RNG.standard_normal(n)
        y = formants(x, v, RNG.uniform(0.9, 1.25)) * 0.8 + hp(x, 4500) * 0.25 * RNG.random()   # a little "ss"
        y /= np.max(np.abs(y)) + 1e-9
        y *= env(n, d * 0.3, d * 0.5, 1.2)
        a, b = pan(y * level, p + RNG.uniform(-0.15, 0.15))
        s = int(pos * SR)
        add(Lb, a, s); add(Rb, b, s + int(RNG.uniform(0.0005, 0.0012) * SR))   # a hair of delay: the voice is "near an ear"
        pos += d + RNG.uniform(0.02, 0.22) + (0.6 if RNG.random() < 0.15 else 0)


def scream(Lb, Rb, t0, p, level=0.5):
    """A thin cry from very far away: it climbs, wavers and breaks."""
    d = RNG.uniform(2.0, 3.2)
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    f0 = 520 * 2 ** ((5 * np.sin(np.pi * t ** 0.8) - 3 * t) / 12) * (1 + 0.03 * smooth_noise(n, 12))
    y = voice(f0, vowel="ah", breath=0.45, jitter=0.05, shift=1.15, vib=6.8, vib_depth=0.03)
    y = lp(y, 3400)
    y *= env(n, d * 0.3, d * 0.6, 1.1)
    a, b = pan(y * level, p)
    s = int(t0 * SR)
    add(Lb, a, s); add(Rb, b, s)


def bell(Lb, Rb, t0, f, p, level=0.5):
    d = 9.0
    n = int(d * SR)
    t = tt(n)
    y = np.zeros(n)
    for r, a, dec in ((1.0, 1.0, 0.5), (2.01, 0.6, 0.8), (2.76, 0.5, 1.0), (4.07, 0.35, 1.4), (5.43, 0.3, 1.7), (6.9, 0.18, 2.4)):
        y += a * np.sin(2 * np.pi * f * r * t + RNG.uniform(0, 6.28)) * np.exp(-t * dec)
    y *= np.minimum(1, t / 0.004)
    a, b = pan(y * level, p)
    s = int(t0 * SR)
    add(Lb, a, s); add(Rb, b, s)


def heartbeat(Lb, Rb, t0, bpm=39):
    gap = 60 / bpm
    k = 0
    pos = t0
    while pos < t0 + LEN_S - 1:
        for off, lvl in ((0.0, 1.0), (0.34, 0.6)):
            n = int(0.5 * SR)
            t = tt(n)
            f = 46 * np.exp(-t * 8) + 28
            y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 9)
            s = int((pos + off + RNG.uniform(-0.01, 0.01)) * SR)
            add(Lb, y * lvl * 0.9, s); add(Rb, y * lvl * 0.9, s)
        pos += gap * RNG.uniform(0.92, 1.1)
        k += 1


def reverb(x, tau, cut, seed):
    """A long, dark room as a circular convolution (the loop stays seamless)."""
    r = np.random.default_rng(seed)
    n = int(SR * min(tau * 6.5, 14))
    t = tt(n)
    ir = r.standard_normal(n) * np.exp(-t / tau)
    ir = lp(ir, cut) * np.minimum(1, t / 0.05)
    ir = lp(ir, cut * 0.45) * 0.5 + ir * 0.5
    ir = np.concatenate([np.zeros(int(0.035 * SR)), ir])[:L]
    ir /= np.sqrt(np.sum(ir ** 2))
    return np.fft.irfft(np.fft.rfft(x) * np.fft.rfft(ir, L), L)


# ---------------------------------------------------------------- the score
def build():
    dL, dR = np.zeros(L), np.zeros(L)          # dry-ish: drone, breath, heartbeat
    vL, vR = np.zeros(L), np.zeros(L)          # voices, bells: they go into the reverb
    drone(dL, dR)
    heartbeat(dL, dR, 1.3)

    # (start second, duration, base pitch Hz, pan) -- D3 .. A3: a human chord that never settles
    choirs = [(1.0, 13, 146.8, -0.5, 4), (9.0, 12, 207.7, 0.5, 3), (17.5, 14, 110.0, 0.0, 5),
              (26.0, 13, 155.6, 0.6, 4), (33.5, 12, 220.0, -0.6, 3), (40.5, 13, 138.6, 0.1, 5)]
    for t0, d, f, p, sz in choirs:
        choir(vL, vR, t0, d, f, p, vowels=("oh", "uh", "oo", "ah"), size=sz, peak=0.85)
    # deeper, lonelier voices underneath
    for t0, d, f, p in ((5.0, 16, 87.3, -0.2), (22.0, 15, 98.0, 0.3), (38.0, 14, 82.4, 0.0)):
        choir(vL, vR, t0, d, f, p, vowels=("oo", "oh"), size=2, sink=1.5, peak=0.8)

    for t0, p in ((3.0, -0.8), (7.5, 0.7), (12.0, -0.4), (16.5, 0.9), (21.0, -0.9), (25.5, 0.3),
                  (30.0, -0.6), (34.0, 0.8), (38.5, -0.3), (43.0, 0.6), (46.0, -0.8)):
        whisper(vL, vR, t0 + RNG.uniform(0, 1.2), p, words=int(RNG.integers(4, 9)), level=0.5)

    for t0, p in ((11.0, 0.8), (28.0, -0.7), (43.5, 0.5)):
        scream(vL, vR, t0, p, level=0.45)

    bell(vL, vR, 14.5, 164.8, -0.2, 0.5)
    bell(vL, vR, 37.0, 155.6, 0.2, 0.5)

    wL = reverb(vL, 1.5, 3200, 1)
    wR = reverb(vR, 1.5, 3200, 2)
    L_ = dL * 0.55 + vL * 0.30 + wL * 1.25
    R_ = dR * 0.55 + vR * 0.30 + wR * 1.25
    # keep it all low and soft: nothing above 9 kHz, nothing under 22 Hz, a very slow overall breath
    t = tt(L)
    breath = 0.82 + 0.18 * np.sin(2 * np.pi * snap(1 / 24) * t)
    out = []
    f = np.fft.rfftfreq(L, 1 / SR)
    mask = np.clip((f - 14) / 16, 0, 1) * np.clip((10000 - f) / 2500, 0, 1)     # a circular filter: no start-up click at the seam
    for ch in (L_, R_):
        ch = np.fft.irfft(np.fft.rfft(ch) * mask, L) * breath
        out.append(ch)
    m = np.max(np.abs(np.stack(out)))
    out = [c / m * 0.72 for c in out]
    return np.stack(out, axis=1)


def write_ogg(stereo, path):
    pcm = (np.clip(stereo, -1, 1) * 32767).astype("<i2")
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, "hell.wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes(pcm.tobytes())
        os.makedirs(os.path.dirname(path), exist_ok=True)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "4", path], check=True)


if __name__ == "__main__":
    out = os.path.abspath(OUT)
    write_ogg(build(), out)
    print("wrote", out, os.path.getsize(out) // 1024, "KB")
