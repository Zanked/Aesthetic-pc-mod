#!/usr/bin/env python3
"""
Makes the sound effects of Pet School (SchoolApp): everything is synthesized here (no samples).

    python3 tools/make_school_audio.py     # writes sounds/school/<name>.ogg and registers school.<name> in sounds.json

  bell     a little hand school bell, three quick rings       (a class is picked)
  ding     a sparkly two-note chime                          (a right answer)
  boop     a soft, friendly "bu-bum", never harsh              (a wrong answer)
  chalk    chalk on the blackboard, a short quiet scratch      (the teacher starts to write)
  fanfare  a tiny cheerful jingle                              (4 or 5 right out of 5)
  aww      a gentle, sympathetic "awww" that slides down       (0 or 1 right out of 5)

(The voice of the teacher is "voice.owl", see make_voices.py; the school tunes are "music.school" and "music.school_quiz",
see make_music.py.) Needs numpy + scipy + ffmpeg (with libvorbis).
"""
import json
import os
import subprocess
import tempfile
import wave

import numpy as np
from scipy.signal import butter, sosfilt

SR = 44100
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "src/main/resources/assets/cutemod")
OUT = os.path.join(ASSETS, "sounds/school")


def T(n): return np.arange(n) / SR


def lp(x, fc, order=2): return sosfilt(butter(order, min(fc, SR * 0.45) / (SR / 2), output="sos"), x)


def bp(x, lo, hi): return sosfilt(butter(2, [lo / (SR / 2), min(hi, SR * 0.45) / (SR / 2)], btype="band", output="sos"), x)


def hz(m): return 440.0 * 2 ** ((m - 69) / 12.0)


def bell_tone(f, dur, decay=7.0):
    """A small bell: inharmonic partials, a quick attack, a ringing tail."""
    n = int(dur * SR); t = T(n); s = np.zeros(n)
    for r, a, d in ((1, 1.0, 1.0), (2.76, .5, 1.5), (5.40, .28, 2.2), (8.93, .12, 3.2)):
        if f * r < SR * 0.45: s += a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * decay * d)
    return s * np.minimum(1, t / 0.002)


def soft_tone(f, dur, glide=0.0, att=0.02, decay=6.0, vib=0.0):
    """A round, warm tone (a sine with a quiet second harmonic) that can slide."""
    n = int(dur * SR); t = T(n)
    fr = f * (1 + glide * t / dur) * (1 + vib * np.sin(2 * np.pi * 5.5 * t))
    p = 2 * np.pi * np.cumsum(fr) / SR
    s = np.sin(p) + 0.25 * np.sin(2 * p) + 0.06 * np.sin(3 * p)
    return s * np.minimum(1, t / att) * np.exp(-t * decay)


def put(buf, sig, at, gain=1.0):
    i = int(at * SR); e = min(len(buf), i + len(sig))
    if e > i: buf[i:e] += sig[:e - i] * gain


def finish(x, peak):
    x = x - np.mean(x)
    x = x / np.max(np.abs(x)) * peak
    fi, fo = int(0.002 * SR), int(0.02 * SR)
    x[:fi] *= np.linspace(0.0, 1.0, fi)
    x[-fo:] *= np.linspace(1.0, 0.0, fo)
    return x


def bell():
    buf = np.zeros(int(1.5 * SR))
    for k, at in enumerate((0.0, 0.17, 0.34)):
        put(buf, bell_tone(hz(88), 1.0, 5.5), at, 1.0 - 0.12 * k)       # E6: a small hand bell
        put(buf, bell_tone(hz(88) * 1.002, 1.0, 5.5), at + 0.004, 0.5)     # a slightly detuned twin: it shimmers
    return finish(lp(buf, 9000), 0.75)


def ding():
    buf = np.zeros(int(0.9 * SR))
    put(buf, bell_tone(hz(84), 0.6, 7.0), 0.0, 0.9)                        # C6
    put(buf, bell_tone(hz(91), 0.8, 6.0), 0.09, 1.0)                       # G6: up, like "yes!"
    put(buf, bell_tone(hz(96), 0.5, 9.0), 0.17, 0.35)                      # a tiny sparkle on top
    return finish(lp(buf, 10000), 0.75)


def boop():
    buf = np.zeros(int(0.55 * SR))
    put(buf, soft_tone(hz(64), 0.20, -0.05, 0.015, 7.0), 0.0, 1.0)         # "bu"
    put(buf, soft_tone(hz(59), 0.30, -0.06, 0.02, 6.0), 0.15, 0.9)         # "bum": a little lower, a gentle step down
    return finish(lp(buf, 2600), 0.60)


def chalk():
    n = int(0.32 * SR); t = T(n)
    rng = np.random.default_rng(5)
    x = bp(rng.standard_normal(n), 1800, 6500)
    # three short strokes: the chalk is dragged, lifted and dragged again
    stroke = np.zeros(n)
    for a, b in ((0.00, 0.10), (0.12, 0.21), (0.23, 0.32)):
        i, j = int(a * SR), min(n, int(b * SR))
        stroke[i:j] = np.sin(np.pi * np.linspace(0, 1, j - i)) ** 1.5
    grain = 0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 95 * t)) * rng.random(n)    # a rough, scratchy surface
    return finish(lp(x * stroke * grain, 6000), 0.45)


def fanfare():
    buf = np.zeros(int(1.8 * SR))
    for k, (m, at) in enumerate(((72, 0.0), (76, 0.11), (79, 0.22), (84, 0.33))):   # C-E-G-C arpeggio
        put(buf, bell_tone(hz(m), 0.9, 5.0), at, 0.9)
        put(buf, soft_tone(hz(m - 12), 0.25, 0, 0.01, 8.0), at, 0.35)
    for m in (72, 76, 79, 84):                                                       # then the whole chord rings together
        put(buf, bell_tone(hz(m), 1.2, 3.8), 0.52, 0.5)
        put(buf, bell_tone(hz(m + 12), 0.8, 7.0), 0.56, 0.18)                        # sparkles
    return finish(lp(buf, 10000), 0.75)


def aww():
    buf = np.zeros(int(1.2 * SR))
    put(buf, soft_tone(hz(67), 0.38, -0.05, 0.04, 3.5, 0.008), 0.0, 1.0)        # "aw"
    put(buf, soft_tone(hz(64), 0.62, -0.12, 0.04, 2.6, 0.012), 0.34, 0.9)       # "ww": it slides down and fades
    return finish(lp(buf, 2400), 0.60)


SOUNDS = {"bell": bell, "ding": ding, "boop": boop, "chalk": chalk, "fanfare": fanfare, "aww": aww}


def save_ogg(name, x):
    os.makedirs(OUT, exist_ok=True)
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, name + ".wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-c:a", "libvorbis", "-q:a", "4",
                        os.path.join(OUT, name + ".ogg")], check=True)


def main():
    sj = os.path.join(ASSETS, "sounds.json")
    data = json.load(open(sj, encoding="utf-8")) if os.path.exists(sj) else {}
    for name, fn in SOUNDS.items():
        x = fn()
        save_ogg(name, x)
        data["school." + name] = {"sounds": [{"name": "cutemod:school/" + name, "stream": False}]}
        print("%-8s %.2f s  %d KB" % (name, len(x) / SR, os.path.getsize(os.path.join(OUT, name + ".ogg")) // 1024 + 1))
    json.dump(data, open(sj, "w", encoding="utf-8"), indent=2)


if __name__ == "__main__":
    main()
