#!/usr/bin/env python3
"""The music of the deep site (scarystories.cute/???): quiet crying, a hush, and a scream.

Nothing here is a Minecraft sound: it is all made from a synthetic throat (the same one as in make_hell_music.py).
Layers (all built to wrap around, so the 48 second track loops with no gap and no click):
  - crying: a breath in, then several sobs sinking in pitch, then one long wail; they come from different sides;
  - a thin, slightly out-of-tune music box that plays a lullaby that does not end well;
  - a very low bed (the drone of the haunted site, only a shadow of it);
  - two close screams. Before each of them everything goes silent, after each the crying comes back slowly.
Everything but the screams goes through a long dark reverb (a circular convolution, so the loop stays seamless).

Needs numpy + scipy + ffmpeg (with libvorbis).  Run it from anywhere:  python3 tools/make_deep_music.py
Output: src/main/resources/assets/cutemod/sounds/music/deep.ogg   (the sound event "music.deep" is in sounds.json)
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_hell_music as mh   # the helpers: voice, reverb, add, pan, env ...

mh.RNG = np.random.default_rng(303)    # the helpers read this global: a different dice for a different track
RNG = mh.RNG
SR, L = mh.SR, mh.L
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources",
                   "assets", "cutemod", "sounds", "music", "deep.ogg")


def put(Lb, Rb, sig, t0, p):
    a, b = mh.pan(sig, p)
    s = int(t0 * SR)
    mh.add(Lb, a, s)
    mh.add(Rb, b, s)


# ---------------------------------------------------------------- crying
def inhale(Lb, Rb, t0, p, level):
    """A short wet breath in (filtered noise that swells)."""
    d = RNG.uniform(0.22, 0.35)
    n = int(d * SR)
    x = mh.bp(RNG.standard_normal(n), 1200, 4200)
    x = x / (np.max(np.abs(x)) + 1e-9) * mh.env(n, d * 0.7, d * 0.25, 1.2)
    put(Lb, Rb, x * level, t0, p)


def sob(Lb, Rb, t0, p, level, f_start, drop, d, vowel="ah"):
    """One sob: a thin voice that starts high and sinks, trembling like a hiccup of breath."""
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    f0 = f_start * 2 ** (-(drop * t ** 0.7) / 12) * (1 + 0.035 * mh.smooth_noise(n, 14))
    y = mh.voice(f0, vowel=vowel, breath=0.30, jitter=0.03, shift=1.25, vib=7.5, vib_depth=0.035)
    y = mh.lp(y, 4200) * mh.env(n, 0.06, d * 0.55, 1.4)
    y *= 0.75 + 0.25 * np.sin(2 * np.pi * RNG.uniform(9, 13) * np.arange(n) / SR)
    put(Lb, Rb, y * level, t0, p)


def cry(Lb, Rb, t0, p, level, base, n_sobs):
    t = t0
    inhale(Lb, Rb, t, p, level * 0.6)
    t += 0.3
    f = base
    for i in range(n_sobs):
        d = RNG.uniform(0.45, 0.75)
        sob(Lb, Rb, t, p, level * (1 - 0.08 * i), f, RNG.uniform(3, 6), d)
        t += d + RNG.uniform(0.05, 0.18)
        if RNG.random() < 0.5:
            inhale(Lb, Rb, t - 0.1, p, level * 0.4)
        f *= 2 ** (-RNG.uniform(0.2, 1.0) / 12)
    sob(Lb, Rb, t, p, level * 0.9, f * 1.05, 9, RNG.uniform(1.6, 2.4), vowel="oh")    # the last wail, sinking down


# ---------------------------------------------------------------- the music box
def box_note(Lb, Rb, t0, f, p, level):
    d = 3.2
    n = int(d * SR)
    t = np.arange(n) / SR
    y = np.zeros(n)
    for k, (mult, decay, g) in enumerate(((1.0, 1.1, 1.0), (2.0, 1.6, 0.45), (3.0, 2.4, 0.25), (4.2, 3.4, 0.12), (5.4, 4.6, 0.06))):
        y += g * np.sin(2 * np.pi * f * mult * t + RNG.uniform(0, 6.28)) * np.exp(-t * decay)
    y *= np.minimum(1, t / 0.004)
    put(Lb, Rb, y * level, t0, p)


def lullaby(Lb, Rb, t0, notes, step=1.25, level=0.35):
    """notes: pitches in Hz (a few of them a little flat on purpose); the last note rings longer."""
    for i, f in enumerate(notes):
        flat = 2 ** (-RNG.uniform(0, 28) / 1200)
        box_note(Lb, Rb, t0 + i * step * RNG.uniform(0.97, 1.05), f * flat, -0.3 + 0.12 * (i % 3), level)


# ---------------------------------------------------------------- the scream
def close_scream(Lb, Rb, t0, p, level):
    """A scream that is close: two throats a hair apart, it climbs, tears, and breaks up."""
    d = RNG.uniform(2.0, 2.6)
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    f0 = 760 * 2 ** ((6 * np.sin(np.pi * np.minimum(1, t * 1.4) ** 0.7) - 4 * t ** 2) / 12) * (1 + 0.04 * mh.smooth_noise(n, 16))
    y = mh.voice(f0, vowel="ah", breath=0.5, jitter=0.06, shift=1.2, vib=8.0, vib_depth=0.04)
    y = y + 0.7 * mh.voice(f0 * 1.015, vowel="eh", breath=0.5, jitter=0.06, shift=1.15, vib=7.4, vib_depth=0.04)
    y = np.tanh(2.2 * y / (np.max(np.abs(y)) + 1e-9))                 # it breaks up
    y = mh.lp(mh.hp(y, 220), 6000) * mh.env(n, 0.05, d * 0.5, 1.2)
    y /= np.max(np.abs(y)) + 1e-9
    put(Lb, Rb, y * level, t0, p)
    return d


def duck_curve(screams):
    """1 = normal, ~0 = hush: everything but the screams falls silent before a scream and creeps back after it."""
    xs, ys = [0.0], [1.0]
    for s in screams:
        xs += [s - 2.4, s - 1.5, s + 3.0, s + 6.0]
        ys += [1.0, 0.04, 0.04, 1.0]
    xs.append(48.0)
    ys.append(1.0)
    return np.interp(np.arange(L) / SR, xs, ys)


# ---------------------------------------------------------------- the score
def build():
    bL, bR = np.zeros(L), np.zeros(L)      # the bed
    cL, cR = np.zeros(L), np.zeros(L)      # crying + music box (ducked, then reverb)
    sL, sR = np.zeros(L), np.zeros(L)      # screams
    mh.drone(bL, bR)

    # (start s, pan, base Hz, sobs): the first two and the last two phrases are far, the middle ones close
    for t0, p, f, n in ((0.5, -0.3, 400, 4), (7.0, 0.5, 360, 3), (13.0, -0.6, 430, 5),
                        (29.5, 0.2, 380, 4), (35.0, -0.5, 350, 3)):
        cry(cL, cR, t0, p, 0.26, f, n)
    A4, B4, C5, D5, E5, G4s = 440.0, 493.88, 523.25, 587.33, 659.25, 415.3
    lullaby(cL, cR, 3.0, [E5, D5, C5, B4, A4], level=0.15)
    lullaby(cL, cR, 16.0, [C5, B4, A4, G4s, A4], step=1.4, level=0.15)           # a wrong note in the middle
    lullaby(cL, cR, 31.0, [E5, D5, C5, E5, A4], step=1.3, level=0.14)

    screams = (22.0, 41.0)
    for s, p in zip(screams, (-0.2, 0.25)):
        close_scream(sL, sR, s, p, 1.0)

    g = duck_curve(screams)
    cL *= g
    cR *= g
    wL = mh.reverb(cL, 2.0, 4200, 11)
    wR = mh.reverb(cR, 2.0, 4200, 12)
    swL = mh.reverb(sL, 1.1, 5200, 13)
    swR = mh.reverb(sR, 1.1, 5200, 14)

    L_ = bL * 0.12 + cL * 0.9 + wL * 0.8 + sL * 1.0 + swL * 0.5
    R_ = bR * 0.12 + cR * 0.9 + wR * 0.8 + sR * 1.0 + swR * 0.5
    t = mh.tt(L)
    breath = 0.88 + 0.12 * np.sin(2 * np.pi * mh.snap(1 / 24) * t)
    f = np.fft.rfftfreq(L, 1 / SR)
    mask = np.clip((f - 14) / 16, 0, 1) * np.clip((10500 - f) / 2500, 0, 1)    # a circular filter: no click at the seam
    out = [np.fft.irfft(np.fft.rfft(ch) * mask, L) * breath for ch in (L_, R_)]
    m = np.max(np.abs(np.stack(out)))
    return np.stack([c / m * 0.72 for c in out], axis=1)


if __name__ == "__main__":
    out = os.path.abspath(OUT)
    mh.write_ogg(build(), out)
    print("wrote", out, os.path.getsize(out) // 1024, "KB")
