#!/usr/bin/env python3
"""
Makes the little speech sounds of the eight judges of the talent show (four of them sit on the panel in every round) (like the babble of the animals of a cozy village):
every judge has his own voice, and 8 slightly different syllables, so the speech never sounds the same twice.
Everything is synthesized here (no samples, no Minecraft sounds).

    python3 tools/make_voices.py            # writes sounds/voice/<judge>_<0..7>.ogg, updates sounds.json
    python3 tools/make_voices.py --demo F.wav   # also writes a demo where every judge "talks" for two seconds
    python3 tools/make_voices.py owl            # only the named voices (the other files stay untouched)

  Mei   (panda)     high and sweet: a soft "pii" that glides up, with a tiny puff
  Boom  (creeper)   a little hiss and a round "bwoo": "ssbop"
  Void  (enderman)  deep and quiet: a slow, warm "mmoo" that wobbles
  Honey (bee)       bright and buzzy: a quick "bzi"
  Kit   (cat)       a soft round "mrrp" that rises a little
  Pip   (penguin)   a bouncy "pwip" chirp
  Fox               a bright nasal "yip"
  Lady  (ladybug)   a tiny bell, "ti-ling"
  Owl   (Teacher Owl of Pet School)  a warm, round, gentle "hoo" (every second syllable is a double "hu-hoo")
(The pets in the Tamagotchi app talk with these 8 voices: PetApp.VOICES. A panda uses Mei, a creeper Boom, an enderman Void, a bee Honey.)

Needs numpy + scipy + ffmpeg (with libvorbis). In the game, PetStage plays "voice.<judge>" (one event with the 8 syllables,
the game picks one at random) with a different pitch for every letter.
"""
import json
import math
import os
import subprocess
import sys
import tempfile
import wave
import random

import numpy as np
from scipy.signal import butter, sosfilt

SR = 44100
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "src/main/resources/assets/cutemod")
OUT = os.path.join(ASSETS, "sounds/voice")
JUDGES = ["mei", "boom", "void", "honey"]      # the first four judges of the show (ShowJudges, judge 0-3)
TEACHERS = ["owl"]                             # Teacher Owl of Pet School (SchoolApp plays "voice.owl")
PETS = ["kit", "pip", "fox", "lady"]           # the other four judges (4-7 are lady, fox, kit, pip); the pets of PetApp talk with all 8 voices
VARIANTS = 8


def T(n): return np.arange(n) / SR


def lp(x, fc, order=2): return sosfilt(butter(order, min(fc, SR * 0.45) / (SR / 2), output="sos"), x)


def bp(x, lo, hi): return sosfilt(butter(2, [lo / (SR / 2), min(hi, SR * 0.45) / (SR / 2)], btype="band", output="sos"), x)


def env(n, attack, tau, release=0.012):
    """Quick attack, soft exponential decay, a short fade at the very end (no clicks)."""
    t = T(n)
    e = np.minimum(1.0, t / attack) * np.exp(-t / tau)
    r = int(release * SR)
    e[-r:] *= np.linspace(1.0, 0.0, r)
    return e


def phase(freq):
    return 2 * np.pi * np.cumsum(freq) / SR


def finish(x, peak):
    x = x - np.mean(x)
    x = x / np.max(np.abs(x)) * peak
    fi, fo = int(0.002 * SR), int(0.010 * SR)             # a tiny fade in and out: never a click
    x[:fi] *= np.linspace(0.0, 1.0, fi)
    x[-fo:] *= np.linspace(1.0, 0.0, fo)
    return x


def mei(i, rng):
    dur = rng.uniform(0.10, 0.13); n = int(dur * SR); t = T(n)
    f0 = [523, 587, 659, 740, 784, 880, 988, 1047][i]
    f = f0 * (1 + 0.09 * (1 - np.exp(-t / 0.025)))                      # glides up a little: "pii?"
    p = phase(f)
    tone = np.sin(p) + 0.28 * np.sin(2 * p) + 0.06 * np.sin(3 * p)
    puff = bp(np.random.default_rng(i).standard_normal(n), 2500, 5500) * np.exp(-t / 0.012) * 0.10
    x = (tone * env(n, 0.006, 0.055) + puff)
    return finish(lp(x, 6000), 0.80)


def boom(i, rng):
    dur = rng.uniform(0.15, 0.18); n = int(dur * SR); t = T(n)
    hiss = bp(np.random.default_rng(100 + i).standard_normal(n), 3500, 8500) * env(n, 0.008, 0.028) * 0.55   # "ss"
    f0 = [196, 220, 233, 262, 247, 294, 262, 330][i]
    f = f0 * (1 - 0.14 * (1 - np.exp(-t / 0.05)))                                                              # "bwoo" falls a little
    p = phase(f)
    tone = np.sin(p) + 0.35 * np.sin(2 * p) + 0.12 * np.sin(3 * p)
    delay = int(0.022 * SR)
    body = np.zeros(n); body[delay:] = (tone * env(n, 0.012, 0.07))[delay:]       # "bwoo" starts a moment after the "ss"
    return finish(lp(hiss + body, 6500), 0.80)


def void(i, rng):
    dur = rng.uniform(0.18, 0.21); n = int(dur * SR); t = T(n)
    f0 = [110, 123, 131, 147, 165, 138, 123, 156][i]
    f = f0 * (1 + 0.02 * np.sin(2 * np.pi * 6 * t))                                                           # a slow wobble
    p = phase(f)
    tone = np.sin(p) + 0.45 * np.sin(2 * p) + 0.18 * np.sin(3 * p) + 0.25 * np.sin(0.5 * p)
    tone *= 1 - 0.25 * (0.5 + 0.5 * np.sin(2 * np.pi * 22 * t))                                               # soft "mmoo" purr
    air = lp(np.random.default_rng(200 + i).standard_normal(n), 700) * 0.05
    x = tone * env(n, 0.018, 0.09, 0.02) + air * env(n, 0.02, 0.08)
    return finish(lp(x, 1800), 0.60)                                                                           # quiet and warm


def honey(i, rng):
    dur = rng.uniform(0.08, 0.10); n = int(dur * SR); t = T(n)
    f0 = [880, 988, 1109, 1245, 1397, 1175, 1319, 1480][i]
    f = f0 * (1 + 0.06 * (1 - np.exp(-t / 0.012))) * (1 + 0.03 * np.sin(2 * np.pi * 28 * t))                  # a quick buzzing "bzi"
    p = phase(f)
    tone = np.sin(p + 0.7 * np.sin(2 * np.pi * f0 * 1.5 * t) * np.exp(-t / 0.03)) + 0.2 * np.sin(2 * p)
    tone *= 1 - 0.30 * (0.5 + 0.5 * np.sin(2 * np.pi * 60 * t))
    return finish(lp(tone * env(n, 0.004, 0.035), 7500), 0.75)


def kit(i, rng):
    """The cat: a soft, round "mrrp" that rises a little and purrs at the start."""
    dur = rng.uniform(0.12, 0.15); n = int(dur * SR); t = T(n)
    f0 = [587, 659, 698, 784, 740, 880, 831, 932][i]
    f = f0 * (1 + 0.10 * np.sin(np.pi * np.minimum(1, t / dur)))                                  # up and down: "mew"
    p = phase(f)
    tone = np.sin(p) + 0.30 * np.sin(2 * p) + 0.10 * np.sin(3 * p)
    tone *= 1 - 0.35 * (0.5 + 0.5 * np.sin(2 * np.pi * 26 * t)) * np.exp(-t / 0.05)             # a tiny purr at the start
    return finish(lp(tone * env(n, 0.010, 0.07), 5200), 0.75)


def pip(i, rng):
    """The penguin: a quick, bouncy "pwip" with a little honk."""
    dur = rng.uniform(0.07, 0.09); n = int(dur * SR); t = T(n)
    f0 = [698, 784, 880, 988, 932, 1047, 1175, 1319][i]
    f = f0 * (0.85 + 0.30 * (1 - np.exp(-t / 0.02)))                                              # a fast upward chirp
    p = phase(f)
    tone = np.sin(p + 0.5 * np.sin(2 * p) * np.exp(-t / 0.03)) + 0.15 * np.sin(3 * p)
    return finish(lp(tone * env(n, 0.003, 0.03), 6500), 0.75)


def fox(i, rng):
    """The fox: a bright, short, slightly nasal "yip"."""
    dur = rng.uniform(0.09, 0.11); n = int(dur * SR); t = T(n)
    f0 = [494, 554, 587, 659, 622, 698, 740, 831][i]
    f = f0 * (1 + 0.18 * np.exp(-t / 0.02) - 0.08 * (t / dur))                                    # starts high, falls: "yip!"
    p = phase(f)
    tone = np.sin(p) + 0.5 * np.sin(2 * p) + 0.3 * np.sin(3 * p) + 0.15 * np.sin(4 * p)
    tone = bp(tone, 700, 3200)                                                                      # a nasal formant
    return finish(tone * env(n, 0.004, 0.04), 0.80)


def lady(i, rng):
    """The ladybug: a tiny bell, "ti-ling", two quick notes."""
    dur = rng.uniform(0.10, 0.13); n = int(dur * SR); t = T(n)
    f0 = [1319, 1397, 1568, 1760, 1661, 1865, 2093, 2349][i]
    x = np.sin(2 * np.pi * f0 * t) + 0.35 * np.sin(2 * np.pi * f0 * 2.76 * t) * np.exp(-t / 0.02)   # a bell is not a pure tone
    h = int(0.045 * SR)
    y = np.zeros(n); y[h:] = (np.sin(2 * np.pi * f0 * 1.26 * t[:n - h]) * np.exp(-t[:n - h] / 0.04)) * 0.7    # the second note
    x = x * np.exp(-t / 0.03) + y
    return finish(lp(x * env(n, 0.002, 0.05), 9000), 0.70)


def owl(i, rng):
    """Teacher Owl: a warm, round, gentle "hoo". Even variants are one soft "hoo" that rises a little, odd ones are a
    quick double "hu-hoo". A tiny breath at the start, a slow wobble in the tone, and an "oo" vowel (formants near 300 and 850 Hz)."""
    f0 = [330, 349, 392, 415, 370, 440, 392, 466][i]

    def hoo(length, f, rise, seed):
        m = int(length * SR); t = T(m)
        fr = f * (1 + rise * (1 - np.exp(-t / 0.05))) * (1 + 0.012 * np.sin(2 * np.pi * 5.5 * t))
        p = phase(fr)
        s = sum(np.sin(k * p) / k ** 1.2 for k in range(1, 10))
        s = bp(s, 200, 450) + 0.35 * bp(s, 700, 1000) + 0.45 * lp(s, 500)             # the "oo"
        breath = bp(np.random.default_rng(seed).standard_normal(m), 800, 2400) * np.exp(-t / 0.022) * 0.16
        return s / np.max(np.abs(s)) * env(m, 0.02, 0.10, 0.02) + breath

    if i % 2 == 0:
        x = hoo(rng.uniform(0.18, 0.22), f0, 0.07, 300 + i)
    else:
        a = hoo(0.075, f0 * 1.06, 0.0, 310 + i) * 0.7                                   # "hu"
        b = hoo(rng.uniform(0.15, 0.18), f0, 0.09, 320 + i)                             # "hoo"
        x = np.concatenate([a, np.zeros(int(0.02 * SR)), b])
    return finish(lp(x, 3500), 0.70)


MAKERS = {"mei": mei, "boom": boom, "void": void, "honey": honey, "kit": kit, "pip": pip, "fox": fox, "lady": lady, "owl": owl}


def save_wav(path, x):
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())


def save_ogg(name, x):
    os.makedirs(OUT, exist_ok=True)
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, name + ".wav")
        save_wav(wav, x)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-c:a", "libvorbis", "-q:a", "4",
                        os.path.join(OUT, name + ".ogg")], check=True)


def main():
    args = [a for a in sys.argv[1:] if a in MAKERS]                  # python3 tools/make_voices.py owl -> only those
    names = args or JUDGES + PETS + TEACHERS
    ALL = JUDGES + PETS + TEACHERS
    voices = {}
    for j in names:
        voices[j] = [MAKERS[j](i, random.Random(1000 * ALL.index(j) + i)) for i in range(VARIANTS)]
        for i, x in enumerate(voices[j]): save_ogg("%s_%d" % (j, i), x)
    # register: one event per judge with the 8 syllables (the game picks one at random)
    sj = os.path.join(ASSETS, "sounds.json")
    data = json.load(open(sj, encoding="utf-8")) if os.path.exists(sj) else {}
    for j in names:
        data["voice." + j] = {"sounds": [{"name": "cutemod:voice/%s_%d" % (j, i), "stream": False} for i in range(VARIANTS)]}
    json.dump(data, open(sj, "w", encoding="utf-8"), indent=2)
    size = sum(os.path.getsize(os.path.join(OUT, f)) for f in os.listdir(OUT)) // 1024
    print("voices: %d new files (%s), %d KB in the folder" % (len(names) * VARIANTS, ", ".join(names), size))
    if len(sys.argv) > 2 and sys.argv[1] == "--demo":     # each judge "says" about 2 seconds, like the game does
        out = []
        gap = np.zeros(int(0.5 * SR))
        for j in names:
            r = random.Random(7)
            for k in range(11):
                x = voices[j][r.randrange(VARIANTS)]
                pitch = 0.92 + r.randrange(7) * 0.035
                idx = (np.arange(int(len(x) / pitch)) * pitch).astype(int)
                y = x[idx[idx < len(x)]]
                out.append(np.pad(y, (0, int(0.10 * SR) - len(y) if len(y) < int(0.10 * SR) else 0)) * 0.9)
            out.append(gap)
        save_wav(sys.argv[2], np.concatenate(out))
        print("demo:", sys.argv[2])


if __name__ == "__main__":
    main()
