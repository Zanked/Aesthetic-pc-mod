import math, random
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont

SC = 8  # supersample per unit (100 units -> 800px)

def new():
    im = Image.new('RGBA', (100*SC, 100*SC), (0,0,0,0))
    return im, ImageDraw.Draw(im)
def P(*v): return [x*SC for x in v]
def rect(d, x0,y0,x1,y1, fill, r=0, outline=None, w=0):
    d.rounded_rectangle(P(x0,y0,x1,y1), radius=r*SC, fill=fill, outline=outline, width=int(w*SC))
def ell(d, x0,y0,x1,y1, fill, outline=None, w=0):
    d.ellipse(P(x0,y0,x1,y1), fill=fill, outline=outline, width=int(w*SC))
def circ(d, cx,cy,r, fill, outline=None, w=0): ell(d,cx-r,cy-r,cx+r,cy+r,fill,outline,w)
def poly(d, pts, fill, outline=None):
    d.polygon([(x*SC,y*SC) for x,y in pts], fill=fill, outline=outline)
def line(d, pts, fill, w):
    d.line([(x*SC,y*SC) for x,y in pts], fill=fill, width=int(w*SC), joint='curve')
def rell(d, cx,cy,rx,ry,rot,fill,n=48):
    c,s=math.cos(math.radians(rot)),math.sin(math.radians(rot)); pts=[]
    for i in range(n):
        t=2*math.pi*i/n; x=rx*math.cos(t); y=ry*math.sin(t)
        pts.append((cx+x*c-y*s, cy+x*s+y*c))
    poly(d,pts,fill)
def clip(layer, maskfn):
    m = Image.new('L', layer.size, 0); md = ImageDraw.Draw(m); maskfn(md)
    out = Image.new('RGBA', layer.size, (0,0,0,0)); out.paste(layer,(0,0),m); return out
def hexa(c): c=c.lstrip('#'); return tuple(int(c[i:i+2],16) for i in (0,2,4))+(255,)
def shade(c,f):
    r,g,b,a=hexa(c) if isinstance(c,str) else c
    return (min(255,int(r*f)),min(255,int(g*f)),min(255,int(b*f)),255)

# ---------------- mascots ----------------
def creeper(d, im):
    rnd = random.Random(7); layer = Image.new('RGBA', im.size, (0,0,0,0)); ld = ImageDraw.Draw(layer)
    greens = ['#63c957','#54b84a','#72d663','#4aa843','#5dc050']
    for i in range(8):
        for j in range(8): rect(ld,10+i*10,10+j*10,20+i*10,20+j*10,greens[rnd.randrange(5)])
    layer = clip(layer, lambda m: m.rounded_rectangle(P(8,8,92,92), radius=14*SC, fill=255))
    im.alpha_composite(layer)
    d = ImageDraw.Draw(im)
    rect(d,8,8,92,92,None,14,'#2e7d32',3)
    k='#16301a'
    rect(d,19,27,41,49,k,2); rect(d,59,27,81,49,k,2)
    rect(d,25,31,31,37,'#ffffff',1); rect(d,65,31,71,37,'#ffffff',1)
    rect(d,40,48,60,66,k,2); rect(d,30,58,43,84,k,2); rect(d,57,58,70,84,k,2)
    ell(d,12,58,24,68,(255,140,160,150)); ell(d,76,58,88,68,(255,140,160,150))

def panda(d, im):
    circ(d,21,22,15,'#25252d'); circ(d,79,22,15,'#25252d')
    ell(d,8,14,92,92,'#ffffff','#b9bec7',2)
    rell(d,34,52,10.5,14,25,'#25252d'); rell(d,66,52,10.5,14,-25,'#25252d')
    circ(d,35,50,4,'#ffffff'); circ(d,65,50,4,'#ffffff'); circ(d,35,50.5,2.2,'#25252d'); circ(d,65,50.5,2.2,'#25252d')
    ell(d,43,61,57,69,'#25252d')
    line(d,[(50,69),(50,73),(44,77)],'#25252d',2); line(d,[(50,73),(56,77)],'#25252d',2)
    ell(d,15,66,29,76,(255,150,170,160)); ell(d,71,66,85,76,(255,150,170,160))

def penguin(d, im):
    ell(d,6,8,94,94,'#2c4d94','#1a2f66',2.5)
    ell(d,15,36,85,88,'#ffffff'); circ(d,37,48,21,'#ffffff'); circ(d,63,48,21,'#ffffff')
    circ(d,36,52,6,'#14213f'); circ(d,64,52,6,'#14213f'); circ(d,38,50,2.2,'#fff'); circ(d,66,50,2.2,'#fff')
    poly(d,[(41,62),(59,62),(50,76)],'#ff9a1f','#d9760a')
    ell(d,18,64,30,73,(255,140,160,150)); ell(d,70,64,82,73,(255,140,160,150))

def fox(d, im):
    poly(d,[(8,6),(42,26),(12,52)],'#ee7f1c','#a9500a'); poly(d,[(92,6),(58,26),(88,52)],'#ee7f1c','#a9500a')
    poly(d,[(16,16),(34,28),(17,40)],'#3a2218'); poly(d,[(84,16),(66,28),(83,40)],'#3a2218')
    ell(d,6,24,94,92,'#f58b25','#a9500a',2.5)
    layer=Image.new('RGBA',im.size,(0,0,0,0)); ld=ImageDraw.Draw(layer)
    poly(ld,[(6,64),(34,54),(50,70),(66,54),(94,64),(94,96),(6,96)],'#fff5e6')
    layer=clip(layer,lambda m:m.ellipse(P(7,25,93,91),fill=255)); im.alpha_composite(layer); d=ImageDraw.Draw(im)
    ell(d,6,24,94,92,None,'#a9500a',2.5)
    ell(d,28,46,40,62,'#2a1a12'); ell(d,60,46,72,62,'#2a1a12')
    circ(d,35,50,2.6,'#fff'); circ(d,67,50,2.6,'#fff')
    ell(d,43,68,57,77,'#2a1a12')
    ell(d,15,62,26,70,(255,120,140,140)); ell(d,74,62,85,70,(255,120,140,140))

def ender(d, im):
    rect(d,8,14,92,86,'#17111f',9,'#4b2f7a',3)
    rect(d,13,19,87,28,'#241a33',4)
    for x0,x1 in ((16,44),(56,84)):
        rect(d,x0,44,x1,58,'#e45cff',3); rect(d,x0+5,48,x1-5,54,'#ffe9ff',2)
    rect(d,40,70,60,73,'#2c2040',1.5)
    for (x,y,s) in ((4,26,4),(92,20,3),(90,76,4),(6,70,3),(20,6,3),(78,92,3)): rect(d,x,y,x+s,y+s,'#c26bff',1)

def bee(d, im):
    ell(d,10,2,38,24,(235,248,255,235),'#9ec6e6',1.5); ell(d,62,2,90,24,(235,248,255,235),'#9ec6e6',1.5)
    line(d,[(37,22),(31,6)],'#3a2a1a',2.5); line(d,[(63,22),(69,6)],'#3a2a1a',2.5)
    circ(d,31,5,4,'#3a2a1a'); circ(d,69,5,4,'#3a2a1a')
    ell(d,6,16,94,92,'#ffcf2e','#8a5a0c',2.5)
    layer=Image.new('RGBA',im.size,(0,0,0,0)); ld=ImageDraw.Draw(layer)
    rect(ld,0,25,100,34,'#3a2a1a'); rect(ld,0,40,100,44,'#3a2a1a')
    layer=clip(layer,lambda m:m.ellipse(P(7,17,93,91),fill=255)); im.alpha_composite(layer); d=ImageDraw.Draw(im)
    ell(d,26,52,42,72,'#2a1d10'); ell(d,58,52,74,72,'#2a1d10')
    circ(d,34,57,3.2,'#fff'); circ(d,66,57,3.2,'#fff')
    line(d,[(44,76),(50,81),(56,76)],'#2a1d10',2)
    ell(d,12,68,24,77,(255,130,150,150)); ell(d,76,68,88,77,(255,130,150,150))

def ladybug(d, im):
    line(d,[(40,14),(32,3)],'#222',2.5); line(d,[(60,14),(68,3)],'#222',2.5)
    ell(d,5,24,95,95,'#e2392f','#8f1b15',2.5)
    layer=Image.new('RGBA',im.size,(0,0,0,0)); ld=ImageDraw.Draw(layer)
    rect(ld,48.5,40,51.5,100,'#2a1414')
    for (x,y,r) in ((27,68,7),(73,68,7),(33,86,5),(67,86,5)): circ(ld,x,y,r,'#2a1414')
    layer=clip(layer,lambda m:m.ellipse(P(6,25,94,94),fill=255)); im.alpha_composite(layer); d=ImageDraw.Draw(im)
    ell(d,18,6,82,52,'#2a1b1b','#111',2)
    circ(d,38,30,8,'#fff'); circ(d,62,30,8,'#fff'); circ(d,39,32,4,'#222'); circ(d,63,32,4,'#222')
    circ(d,41,30,1.5,'#fff'); circ(d,65,30,1.5,'#fff')

MASCOTS = dict(green=creeper, white=panda, blue=penguin, orange=fox, purple=ender, yellow=bee, red=ladybug)

# ---------------- items / glyphs ----------------
def font(sz):
    try: return ImageFont.load_default(size=sz)
    except Exception: return ImageFont.load_default()
def tnt(d, im):
    rect(d,12,12,88,88,'#d93a2c',7,'#7d1a12',3)
    rect(d,12,36,88,64,'#f4f0e6'); 
    for y in (22,78): rect(d,18,y-2,82,y+2,'#a82a1f',1)
    d.text((50*SC,50*SC),'TNT',fill='#222',font=font(22*SC//1),anchor='mm')
def bamboo(d, im):
    for x,c in ((30,'#5fb85a'),(56,'#4ea64c')):
        rect(d,x-8,6,x+8,94,c,6,'#2d6b2e',2.5)
        for y in (30,58,84): rect(d,x-9,y-2,x+9,y+2,'#2d6b2e',1.5)
    poly(d,[(64,40),(94,24),(82,46)],'#7ccf6e','#2d6b2e'); poly(d,[(22,60),(2,44),(14,68)],'#7ccf6e','#2d6b2e')
def fish(d, im):
    poly(d,[(66,50),(96,26),(90,50),(96,74)],'#7ea9d8','#3a5f93')
    ell(d,4,26,76,74,'#9cc3ec','#3a5f93',2.5); ell(d,12,50,70,72,'#e9f4ff')
    poly(d,[(30,28),(44,10),(52,30)],'#7ea9d8','#3a5f93')
    circ(d,22,44,4.5,'#fff'); circ(d,22,44,2.5,'#12203a')
def acorn(d, im):
    ell(d,20,34,80,96,'#d9a35a','#7a4a1c',3)
    rect(d,16,18,84,52,'#7a4a1c',16,'#4a2b0e',2.5); rect(d,46,6,54,22,'#4a2b0e',2)
    for x in (28,44,60,72): line(d,[(x,28),(x+4,44)],'#a2682d',2)
def pearl(d, im):
    circ(d,50,50,42,'#1e8f78','#0d4d40',3); circ(d,50,50,32,'#2fbf9f'); circ(d,50,50,22,'#5fe3c0')
    circ(d,50,50,11,'#1a6f60'); circ(d,50,50,5,'#0b2f2b'); circ(d,34,32,6,(255,255,255,200))
def honey(d, im):
    def hx(cx,cy,r,f,o):
        poly(d,[(cx+r*math.cos(math.radians(60*i+30)), cy+r*math.sin(math.radians(60*i+30))) for i in range(6)],f,o)
    hx(50,30,24,'#ffc01f','#a86a05'); hx(28,66,24,'#f5a60f','#a86a05'); hx(72,66,24,'#ffd24d','#a86a05')
    for cx,cy in ((50,30),(28,66),(72,66)): circ(d,cx,cy,8,'#c97a08')
def leaf(d, im, col='#69c85a', edge='#2f7a2f'):
    rell(d,50,50,46,26,-45,edge); rell(d,50,50,43,23,-45,col)
    line(d,[(18,82),(82,18)],edge,2.5)
def leaf_o(d, im): leaf(d, im, '#f08a2c', '#8f4a0a')
def flower(d, im, col='#ffffff', mid='#ffb52e'):
    for i in range(6):
        a=math.radians(60*i); circ(d,50+27*math.cos(a),50+27*math.sin(a),19,col,'#00000030',1)
    circ(d,50,50,16,mid,'#c27a0a',2)
def flower_y(d, im): flower(d, im, '#fff4f8', '#ffb52e')
def flower_r(d, im): flower(d, im, '#ff8a9a', '#ffe14a')
def paw(d, im, col='#2a2a33'):
    ell(d,26,50,74,92,col)
    for x,y,rx,ry,r in ((20,40,8,11,-20),(40,24,8,12,-5),(60,24,8,12,5),(80,40,8,11,20)): rell(d,x,y,rx,ry,r,col)
def paw_o(d, im): paw(d, im, '#d9680f')
def snow(d, im):
    c='#e8f6ff'; o='#5a8fc8'
    for a in (0,60,120):
        r=math.radians(a); dx,dy=44*math.cos(r),44*math.sin(r)
        line(d,[(50-dx,50-dy),(50+dx,50+dy)],o,9); 
    for a in (0,60,120):
        r=math.radians(a); dx,dy=42*math.cos(r),42*math.sin(r)
        line(d,[(50-dx,50-dy),(50+dx,50+dy)],c,5)
    circ(d,50,50,9,c,o,2)
def diamond(d, im):
    poly(d,[(50,6),(90,36),(50,94),(10,36)],'#4fe3e8','#16808a')
    poly(d,[(10,36),(90,36),(50,94)],'#2cc1cf'); poly(d,[(30,36),(50,6),(70,36)],'#b6fbff')
    line(d,[(10,36),(90,36)],'#16808a',2)
def sparkle(d, im, col='#d28bff'):
    poly(d,[(50,2),(60,40),(98,50),(60,60),(50,98),(40,60),(2,50),(40,40)],col,'#00000030')
def sparkle_v(d, im): sparkle(d, im, '#d28bff')
def sparkle_g(d, im): sparkle(d, im, '#8be87c')
def hexa_g(d, im):
    poly(d,[(50+42*math.cos(math.radians(60*i+30)),50+42*math.sin(math.radians(60*i+30))) for i in range(6)],'#ffc01f','#a86a05')
    circ(d,50,50,14,'#c97a08')

GLY = dict(tnt=tnt,bamboo=bamboo,fish=fish,acorn=acorn,pearl=pearl,honey=honey,leaf=leaf,leaf_o=leaf_o,
 flower_y=flower_y,flower_r=flower_r,paw=paw,paw_o=paw_o,snow=snow,diamond=diamond,sparkle_v=sparkle_v,sparkle_g=sparkle_g,hexa=hexa_g)

# ---------------- rendering ----------------
def art(fn, size):
    """render fn into size x size RGBA (supersampled)"""
    im, d = new(); fn(d, im)
    return im.resize((size, size), Image.LANCZOS)

def sticker(fn, size, border=None, shadow=True):
    r = border if border is not None else (1 if size < 22 else 2)
    inner = max(4, size - 2*r)
    a = art(fn, inner)
    out = Image.new('RGBA', (size, size), (0,0,0,0)); out.alpha_composite(a, (r, r))
    al = np.array(out)[..., 3]
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2*r+1, 2*r+1))
    dil = cv2.dilate((al > 20).astype(np.uint8)*255, k)
    base = np.zeros((size, size, 4), np.uint8)
    if shadow:
        sh = np.roll(np.roll(dil, 1, 0), 1, 1); base[...,0:3] = (70,40,60); base[...,3] = (sh*0.28).astype(np.uint8)
    white = np.zeros_like(base); white[...,0:3] = 255; white[...,3] = dil
    res = Image.fromarray(base); res.alpha_composite(Image.fromarray(white)); res.alpha_composite(out)
    return res
