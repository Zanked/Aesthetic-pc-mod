import sys, os, json, shutil, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, cv2
from PIL import Image, ImageDraw
import matplotlib.colors as mc
from art import *

SRC = sys.argv[1]; OUT = sys.argv[2]  # usage: python build_textures.py <original-pack-dir> <output-dir>
TEX = 'assets/cutemod/textures/block/'

# name: (hue, sat_mul, val_mul, mascot, item, heart, star, paw, screen_center, screen_edge, spark)
THEMES = {
 'green':  dict(h=.34, s=1.15, v=.98, mascot='green',  item='tnt',    heart='MASCOT', star='diamond', paw='sparkle_g', c0='#4fa863', c1='#17402c', sp='#c8ffd0', name='Creeper'),
 'white':  dict(h=.58, s=.10, v=1.0,  mascot='white',  item='bamboo', heart='paw',    star='bamboo',  paw='paw',        c0='#9cc9aa', c1='#3b6a55', sp='#f2fff4', name='Panda'),
 'blue':   dict(h=.57, s=1.25,v=.98, mascot='blue',   item='fish',   heart='snow',   star='fish',    paw='snow',       c0='#74bfff', c1='#1b3f8f', sp='#e6f6ff', name='Penguin'),
 'orange': dict(h=.075,s=1.9, v=.98, mascot='orange', item='acorn',  heart='paw_o',  star='leaf_o',  paw='acorn',      c0='#ffb866', c1='#a8431c', sp='#fff0c8', name='Fox'),
 'purple': dict(h=.76, s=1.0, v=.42, mascot='purple', item='pearl',  heart='sparkle_v',star='pearl', paw='sparkle_v',  c0='#7d3fd8', c1='#150a2c', sp='#e8c8ff', name='Enderman'),
 'yellow': dict(h=.125,s=1.8, v=1.0,  mascot='yellow', item='honey',  heart='flower_y',star='hexa',   paw='flower_y',   c0='#ffd95e', c1='#b8741a', sp='#fff8d0', name='Bee'),
 'red':    dict(h=.0,  s=2.0, v=.90,  mascot='red',    item='leaf',   heart='MASCOT', star='leaf',    paw='flower_r',   c0='#9bd77a', c1='#2f6b3a', sp='#f4ffe0', name='Ladybug'),
}

# sticker regions on original textures: (x,y,w,h,role)
REG = {
 'misc': [(107,24,8,9,'star'),(85,41,14,13,'heart'),(36,51,14,15,'star'),(239,63,14,12,'heart'),(16,80,33,30,'mascot'),
          (16,216,19,17,'heart'),(32,225,10,11,'heart'),(125,218,14,14,'star')],
 'tower':[(27,32,17,15,'paw'),(51,48,16,15,'star'),(118,81,13,12,'heart'),(17,89,43,40,'mascot'),(74,90,33,37,'item'),(174,90,28,32,'item')],
 'monitor':[(6,8,17,16,'heart'),(131,11,23,20,'note'),(16,107,13,11,'heart'),(29,109,9,9,'paw')],
 'monitor2':[(24,75,16,16,'star')],
 'periph':[(209,20,11,10,'heart'),(72,75,8,7,'heart')],
}
SCREEN = (21, 19, 141, 89)   # x0,y0,x1,y1 of desktop area on monitor.png

def load(name): return np.array(Image.open(os.path.join(SRC, TEX+'pink_computer_%s.png'%name)).convert('RGBA'))

def inpaint(a, regs):
    rgb = np.ascontiguousarray(a[...,:3]); h = mc.rgb_to_hsv(rgb/255.)
    sel = np.zeros(a.shape[:2], bool)
    for x,y,w,hh,_ in regs:
        sub = np.zeros_like(sel); sub[max(0,y-3):y+hh+3, max(0,x-3):x+w+3] = True
        strong = ((h[...,1]>.42)&(h[...,2]>.5)) | ((h[...,0]>.07)&(h[...,0]<.45)&(h[...,1]>.25))
        sel |= sub & strong
    sel = cv2.dilate(sel.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(9,9)))
    # keep only inside expanded bboxes
    box = np.zeros_like(sel)
    for x,y,w,hh,_ in regs: box[max(0,y-6):y+hh+6, max(0,x-6):x+w+6] = 1
    sel &= box
    out = cv2.inpaint(rgb, sel*255, 5, cv2.INPAINT_TELEA)
    rnd = np.random.RandomState(1); noise = rnd.normal(0, 2.5, out.shape)
    out = np.where(sel[...,None]>0, np.clip(out+noise,0,255), out).astype(np.uint8)
    res = a.copy(); res[...,:3] = out; return res

def recolor(a, t):
    h = mc.rgb_to_hsv(a[...,:3]/255.)
    h[...,0] = t['h']; h[...,1] = np.clip(h[...,1]*t['s'],0,1); h[...,2] = np.clip(h[...,2]*t['v'],0,1)
    res = a.copy(); res[...,:3] = (mc.hsv_to_rgb(h)*255+.5).astype(np.uint8); return res

def place(img, spr, cx, cy):
    x = int(round(cx - spr.width/2)); y = int(round(cy - spr.height/2))
    img.alpha_composite(spr, (x, y)) if x>=0 and y>=0 else img.paste(spr,(max(x,0),max(y,0)),spr)

def gfn(t, key):
    k = t[key]
    return MASCOTS[t['mascot']] if k == 'MASCOT' else GLY[k]

def note_fn(t):
    face = MASCOTS[t['mascot']]
    def f(d, im):
        rect(d,6,10,94,92,'#fff6a8',8,'#c9a93a',3)
        rect(d,6,6,94,22,'#ffe27a',6,'#c9a93a',3)
        sub = art(face, 56); im.alpha_composite(sub.resize((56*SC//1, 56*SC//1), Image.LANCZOS), (22*SC, 30*SC))
    return f

def draw_screen(img, t):
    x0,y0,x1,y1 = SCREEN; w,h = x1-x0, y1-y0
    c0 = np.array(hexa(t['c0'])[:3],float); c1 = np.array(hexa(t['c1'])[:3],float)
    yy,xx = np.mgrid[0:h,0:w]; dx=(xx-w/2)/(w/2); dy=(yy-h/2)/(h/2)
    r = np.clip(np.sqrt(dx**2*0.8+dy**2*1.1),0,1)[...,None]
    g = c0*(1-r)+c1*r
    # diagonal glass gleam
    gl = np.clip(1-np.abs((xx+yy*0.6)-w*0.55)/16,0,1)[...,None]*0.07
    g = g*(1-gl)+255*gl
    scr = Image.fromarray(g.astype(np.uint8),'RGB').convert('RGBA')
    d = ImageDraw.Draw(scr); rnd = random.Random(5); sp = hexa(t['sp'])
    for _ in range(26):
        x,y = rnd.randrange(14,w-14), rnd.randrange(3,h-3)
        if abs(x-w/2)<28 and abs(y-h/2)<26: continue
        d.point((x,y), fill=sp[:3]+(rnd.choice([150,200,255]),))
        if rnd.random()<.3:
            for ddx,ddy in ((1,0),(-1,0),(0,1),(0,-1)): d.point((x+ddx,y+ddy), fill=sp[:3]+(110,))
    # halo
    halo = Image.new('RGBA',scr.size,(0,0,0,0)); hd = ImageDraw.Draw(halo)
    hd.ellipse((w/2-30,h/2-28,w/2+30,h/2+28), fill=(255,255,255,40)); scr.alpha_composite(halo)
    # mascot
    m = sticker(MASCOTS[t['mascot']], 46, 2); scr.alpha_composite(m, (w//2-23, h//2-24))
    # desktop icons (left/right columns)
    def icon(kind, cx, cy):
        if kind=='folder':
            sp_ = Image.new('RGBA',(11,9),(0,0,0,0)); dd=ImageDraw.Draw(sp_)
            dd.rectangle((0,1,4,3),fill='#f2c24a'); dd.rectangle((0,3,10,8),fill='#ffd96a',outline='#b8892a')
            place(scr, sp_, cx, cy)
        elif kind=='file':
            sp_ = Image.new('RGBA',(8,10),(0,0,0,0)); dd=ImageDraw.Draw(sp_)
            dd.rectangle((0,0,7,9),fill='#ffffff',outline='#9aa'); 
            for yy_ in (3,5,7): dd.line((1,yy_,6,yy_),fill='#aab')
            place(scr, sp_, cx, cy)
        else:
            place(scr, sticker(gfn(t,kind), 11, 1, False), cx, cy)
    L = ['folder','file','star','heart']; R = ['folder','star','paw','file']
    for i,k in enumerate(L): icon(k, 8, 9+i*16)
    for i,k in enumerate(R): icon(k, w-9, 9+i*16)
    # small decorative glyphs
    for (gx,gy,kk) in ((w//2-36,14,'heart'),(w//2+37,60,'star'),(w//2-38,52,'paw')):
        place(scr, sticker(gfn(t,kk), 9, 1, False), gx, gy)
    # rounded mask
    mask = Image.new('L',scr.size,0); ImageDraw.Draw(mask).rounded_rectangle((0,0,w-1,h-1),radius=4,fill=255)
    img.paste(scr,(x0,y0),mask)

def build(name, t):
    out = {}
    for tex in ('misc','tower','monitor','monitor2','periph','tower2','tower3'):
        a = load(tex); regs = REG.get(tex, [])
        if regs: a = inpaint(a, regs)
        a = recolor(a, t)
        img = Image.fromarray(a, 'RGBA')
        if tex == 'monitor': draw_screen(img, t)
        for x,y,w,h,role in regs:
            cx, cy = x+w/2, y+h/2; sz = max(w,h)
            if role == 'item':  fn = GLY[t['item']]
            elif role == 'mascot': fn = MASCOTS[t['mascot']]
            elif role == 'note': fn = note_fn(t); sz = max(w,h)
            else: fn = gfn(t, role)
            if role == 'note': spr = sticker(fn, sz+2, 1)
            else: spr = sticker(fn, sz+(0 if role in('mascot','item') else 0), 2 if sz>=22 else 1)
            place(img, spr, cx, cy)
        out[tex] = img
    return out

def main():
    if os.path.exists(OUT): shutil.rmtree(OUT)
    shutil.copytree(SRC, OUT)
    base = os.path.join(SRC,'assets/cutemod')
    for name,t in THEMES.items():
        imgs = build(name, t)
        for tex,img in imgs.items(): img.save(os.path.join(OUT, TEX+'%s_computer_%s.png'%(name,tex)))
        for sub,ext in (('blockstates','json'),('models/block','json'),('models/item','json')):
            s = open(os.path.join(base,sub,'pink_computer.json'),encoding='utf-8').read().replace('pink_computer','%s_computer'%name).replace('cute pink pc','cute %s pc (%s)'%(name,t['name']))
            open(os.path.join(OUT,'assets/cutemod',sub,'%s_computer.json'%name),'w',encoding='utf-8').write(s)
    # lang
    os.makedirs(os.path.join(OUT,'assets/cutemod/lang'),exist_ok=True)
    en={'block.cutemod.pink_computer':'Pink Computer'}; ru={'block.cutemod.pink_computer':'Розовый компьютер'}
    ru_n={'green':'Зелёный (крипер)','white':'Белый (панда)','blue':'Синий (пингвин)','orange':'Оранжевый (лиса)','purple':'Фиолетовый (эндермен)','yellow':'Жёлтый (пчела)','red':'Красный (божья коровка)'}
    for n,t in THEMES.items():
        en['block.cutemod.%s_computer'%n]='%s Computer (%s)'%(n.capitalize(),t['name']); ru['block.cutemod.%s_computer'%n]='Компьютер: '+ru_n[n]
    json.dump(en,open(os.path.join(OUT,'assets/cutemod/lang/en_us.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
    json.dump(ru,open(os.path.join(OUT,'assets/cutemod/lang/ru_ru.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
    pm = os.path.join(OUT,'pack.mcmeta'); json.dump({'pack':{'pack_format':34,'description':'Cute computers: pink + 7 colors (64x)'}},open(pm,'w'))
main()
