#!/usr/bin/env python3
"""The sound of the abyss: the 666 generated videos on the haunted site (address 666).

Nothing here is a Minecraft sound. It is all made from the synthetic throat of make_hell_music.py, but CLOSE, dry and
wrong, not "a pit heard from far away":
  - 8 beds (music/abyss0..7.ogg, 24 s loops): a dissonant drone that beats against itself, an irregular heart,
    close rasping breath, crying, whispers that go from ear to ear, clusters of detuned moaning voices, screams that
    break, backwards swells, and a "tape warp" that makes the whole thing drift and seasick;
  - one-shots (abyss/*.ogg) that the video throws at you at unpredictable moments:
      scream0-5, cry0-4, rasp0-4 (a rattling, wet breath), whisper0-5 (at the ear, some of them backwards or
      ring-modulated), rev0-3 (a scream played backwards: it sucks the air out), hit0-2 (a low impact and a screech).

Needs numpy + scipy + ffmpeg (with libvorbis).   Run it from anywhere:  python3 tools/make_abyss_audio.py
Output: src/main/resources/assets/cutemod/sounds/music/abyss*.ogg and sounds/abyss/*.ogg
        (the sound events "music.abyssN" and "abyss.<name>" are in sounds.json)
"""
import os
import subprocess
import sys
import tempfile
import wave

import numpy as np
from scipy.signal import fftconvolve

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_hell_music as mh   # the helpers: voice, whisper, choir, heartbeat, reverb, env, bp/lp/hp ...

SR = mh.SR
LEN_S = 24
mh.LEN_S = LEN_S               # the helpers read these globals when they are called: the beds are 24 s loops
mh.L = SR * LEN_S
L = mh.L
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "cutemod", "sounds")


def rng(): return mh.RNG


def norm(x): return x / (np.max(np.abs(x)) + 1e-9)


def dist(x, drive): return np.tanh(x * drive) / np.tanh(drive)


# ---------------------------------------------------------------- one voice-like things (return mono arrays)
def scream_sig(d, f_lo, f_hi, rough=0.6, drive=3.5):
    """A scream that rips: it shoots up, wavers, BREAKS an octave higher for a moment, and tears at the end."""
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    rise = np.clip(t * 4, 0, 1) ** 0.5
    f0 = f_lo * (f_hi / f_lo) ** rise
    brk = np.clip((t - rng().uniform(0.45, 0.65)) * 14, 0, 1) * np.clip((0.82 - t) * 12, 0, 1)   # a register break
    f0 = f0 * (1 + 0.55 * brk * (rng().random() < 0.8)) * (1 + 0.05 * mh.smooth_noise(n, 20)) * 2 ** (-0.9 * np.clip(t - 0.7, 0, 1))
    y = mh.voice(f0, vowel=rng().choice(["ah", "eh", "oh"]), breath=0.4, jitter=0.09, shift=rng().uniform(1.1, 1.3), vib=rng().uniform(6, 9), vib_depth=0.05)
    ts = np.arange(n) / SR
    y *= 1 - rough + rough * (0.5 + 0.5 * np.sin(2 * np.pi * rng().uniform(55, 90) * ts))           # vocal fry: it tears
    y = mh.lp(dist(y, drive), 7000)
    y = y + 0.18 * mh.bp(rng().standard_normal(n), 2500, 7000) * mh.env(n, 0.05, d * 0.6, 1.2)            # air through a ruined throat
    return norm(y) * mh.env(n, 0.025, d * 0.55, 1.1)


def sob_sig(d, f_start, drop):
    n = int(d * SR)
    t = np.linspace(0, 1, n)
    f0 = f_start * 2 ** (-(drop * t ** 0.7) / 12) * (1 + 0.04 * mh.smooth_noise(n, 14))
    y = mh.voice(f0, vowel=rng().choice(["ah", "oh", "eh"]), breath=0.35, jitter=0.035, shift=1.25, vib=7.5, vib_depth=0.04)
    y = mh.lp(y, 4200) * mh.env(n, 0.05, d * 0.55, 1.4)
    return norm(y * (0.72 + 0.28 * np.sin(2 * np.pi * rng().uniform(9, 14) * np.arange(n) / SR)))


def inhale_sig(d):
    n = int(d * SR)
    x = mh.bp(rng().standard_normal(n), 1200, 4200)
    return norm(x) * mh.env(n, d * 0.7, d * 0.25, 1.2)


def cry_sig(sobs, f_start, wail):
    """A breath in, a run of sobs that sink, and (maybe) one long wail that cracks."""
    parts = [inhale_sig(rng().uniform(0.25, 0.4))]
    f = f_start
    for _ in range(sobs):
        parts.append(sob_sig(rng().uniform(0.35, 0.7), f, rng().uniform(2, 6)))
        parts.append(np.zeros(int(rng().uniform(0.04, 0.2) * SR)))
        parts.append(inhale_sig(rng().uniform(0.1, 0.2)) * 0.6)
        f *= 2 ** (-rng().uniform(0.3, 1.6) / 12)
    if wail:
        d = rng().uniform(1.6, 2.6)
        n = int(d * SR)
        t = np.linspace(0, 1, n)
        f0 = f_start * 1.15 * 2 ** ((2.5 * np.sin(np.pi * t) - 5 * t ** 2) / 12) * (1 + 0.05 * mh.smooth_noise(n, 11))
        w = mh.voice(f0, vowel="oh", breath=0.4, jitter=0.05, shift=1.2, vib=6.2, vib_depth=0.05)
        parts.append(norm(mh.lp(w, 3800)) * mh.env(n, 0.2, d * 0.5, 1.2))
    return norm(np.concatenate(parts))


def rasp_sig(breaths):
    """A wet, rattling breath: air through something that should not be there, in... and out."""
    parts = []
    for _ in range(breaths):
        d_in, d_out = rng().uniform(0.7, 1.2), rng().uniform(0.9, 1.7)
        for d, up in ((d_in, True), (d_out, False)):
            n = int(d * SR)
            ts = np.arange(n) / SR
            x = mh.bp(rng().standard_normal(n), rng().uniform(500, 900), rng().uniform(2400, 3600))
            rattle = 0.45 + 0.55 * np.abs(np.sin(np.pi * ts * rng().uniform(22, 36) + 0.4 * mh.smooth_noise(n, 8)))   # the rattle in the chest
            x = x * rattle
            moan = mh.voice(np.full(n, rng().uniform(85, 130)) * (1 + 0.1 * mh.smooth_noise(n, 5)), vowel="uh", breath=0.8, jitter=0.1) * 0.3
            y = norm(x + moan)
            e = mh.env(n, d * (0.8 if up else 0.15), d * (0.2 if up else 0.8), 1.3)
            parts.append(y * e * (0.6 if up else 1.0))
        parts.append(np.zeros(int(rng().uniform(0.1, 0.5) * SR)))
    return norm(np.concatenate(parts))


def whisper_sig(words, backwards=False, ring=0.0):
    """Close whispered speech: no words, just syllables with an "s", right at the ear."""
    segs = []
    for _ in range(words):
        d = rng().uniform(0.09, 0.3)
        n = int(d * SR)
        v = list(mh.VOWELS)[rng().integers(len(mh.VOWELS))]
        x = rng().standard_normal(n)
        y = mh.formants(x, v, rng().uniform(0.9, 1.3)) * 0.8 + mh.hp(x, 4500) * 0.45 * rng().random()
        y = norm(y) * mh.env(n, d * 0.3, d * 0.5, 1.2)
        segs.append(y)
        segs.append(np.zeros(int((rng().uniform(0.02, 0.25) + (0.5 if rng().random() < 0.15 else 0)) * SR)))
    y = np.concatenate(segs)
    if ring > 0:                                                    # a metallic, inhuman voice
        y = y * (1 - ring + ring * np.sin(2 * np.pi * rng().uniform(70, 260) * np.arange(len(y)) / SR))
    if backwards:
        y = y[::-1]
    return norm(y)


# ---------------------------------------------------------------- finishing one-shots (stereo, with a dark reverb tail)
def room(x, tau, cut, wet):
    n = int(SR * min(tau * 5, 5))
    t = np.arange(n) / SR
    ir = rng().standard_normal(n) * np.exp(-t / tau)
    ir = mh.lp(ir, cut) * np.minimum(1, t / 0.03)
    ir /= np.sqrt(np.sum(ir ** 2))
    pad = np.concatenate([x, np.zeros(n)])
    w = fftconvolve(pad, ir)[:len(pad)]
    return pad * (1 - wet * 0.5) + w * wet * 1.5


def to_stereo(x, p, width=0.0):
    a, b = mh.pan(x, p)
    if width > 0:                                                   # decorrelate the two ears a little: the sound is "inside the head"
        k = int(0.0009 * SR)
        b = np.roll(b, k) * 0.9
    return np.stack([a, b], axis=1)


def write_ogg(stereo, path, q=2):
    pcm = (np.clip(stereo, -1, 1) * 32767).astype("<i2")
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, "a.wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes(pcm.tobytes())
        os.makedirs(os.path.dirname(path), exist_ok=True)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", str(q), path], check=True)


def finish(x, wet, tau=1.4, cut=3500, p=0.0, peak=0.92):
    x = room(x, tau, cut, wet)
    loud = np.nonzero(np.abs(x) > 0.012 * np.max(np.abs(x)))[0]          # cut the silent end of the reverb tail
    x = x[:min(len(x), int(loud[-1]) + int(0.1 * SR))]
    n = len(x)
    x = x * np.minimum(1, np.arange(n) / (0.004 * SR)) * mh.env(n, 0.0, 0.25, 1.0)
    st = to_stereo(x, p, width=1.0)
    return st / (np.max(np.abs(st)) + 1e-9) * peak


# ---------------------------------------------------------------- the one-shots
def make_oneshots():
    out = os.path.join(BASE, "abyss")
    k = 0
    for i in range(6):                                              # screams
        mh.RNG = np.random.default_rng(7000 + i)
        d = rng().uniform(1.3, 3.2)
        x = scream_sig(d, rng().uniform(380, 620), rng().uniform(750, 1250), rough=rng().uniform(0.4, 0.8), drive=rng().uniform(2.5, 5))
        write_ogg(finish(x, wet=rng().uniform(0.2, 0.5), tau=0.7, p=rng().uniform(-0.8, 0.8)), os.path.join(out, f"scream{i}.ogg")); k += 1
    for i in range(5):                                              # crying
        mh.RNG = np.random.default_rng(7100 + i)
        x = cry_sig(int(rng().integers(2, 6)), rng().uniform(300, 520), wail=i % 2 == 0)
        write_ogg(finish(x, wet=0.35, tau=1.2, p=rng().uniform(-0.7, 0.7)), os.path.join(out, f"cry{i}.ogg")); k += 1
    for i in range(5):                                              # rattling breath
        mh.RNG = np.random.default_rng(7200 + i)
        x = rasp_sig(int(rng().integers(1, 3)))
        write_ogg(finish(x, wet=0.18, tau=0.9, p=rng().uniform(-0.6, 0.6)), os.path.join(out, f"rasp{i}.ogg")); k += 1
    for i in range(6):                                              # whispers: two are backwards, two ring-modulated
        mh.RNG = np.random.default_rng(7300 + i)
        x = whisper_sig(int(rng().integers(5, 11)), backwards=i % 3 == 1, ring=0.8 if i % 3 == 2 else 0.0)
        write_ogg(finish(x, wet=0.12, tau=0.7, p=rng().choice([-0.9, 0.9]) * rng().uniform(0.6, 1)), os.path.join(out, f"whisper{i}.ogg")); k += 1
    for i in range(4):                                              # a scream played backwards
        mh.RNG = np.random.default_rng(7400 + i)
        x = scream_sig(rng().uniform(1.6, 3.0), rng().uniform(420, 600), rng().uniform(800, 1200))
        x = room(x, 1.6, 3000, 0.5)
        x = x[:int(np.nonzero(np.abs(x) > 0.004 * np.max(np.abs(x)))[0][-1])][::-1]
        n = len(x)
        x = x * mh.env(n, n / SR * 0.9, 0.05, 1.5)
        st = to_stereo(norm(x), rng().uniform(-0.5, 0.5), width=1.0)
        write_ogg(st / np.max(np.abs(st)) * 0.9, os.path.join(out, f"rev{i}.ogg")); k += 1
    for i in range(3):                                              # a hit: a low impact, then a screech
        mh.RNG = np.random.default_rng(7500 + i)
        n = int(0.9 * SR)
        t = np.arange(n) / SR
        thump = np.sin(2 * np.pi * np.cumsum(60 * np.exp(-t * 6) + 24) / SR) * np.exp(-t * 4.5)
        crack = norm(mh.bp(rng().standard_normal(n), 200, 5000)) * np.exp(-t * 30)
        s = scream_sig(rng().uniform(0.9, 1.6), 700, 1400, rough=0.8, drive=6)
        x = np.zeros(len(s) + n)
        x[:n] += thump * 1.0 + crack * 0.7
        x[int(0.05 * SR):int(0.05 * SR) + len(s)] += s * 0.85
        write_ogg(finish(x, wet=0.35, tau=1.2, p=0.0), os.path.join(out, f"hit{i}.ogg")); k += 1
    print("one-shots:", k)


# ---------------------------------------------------------------- the beds (24 s loops)
ROOTS = [41.2, 43.65, 46.25, 49.0, 38.9, 36.7, 51.9, 55.0]


def drone_bed(dL, dR, root):
    t = mh.tt(L)
    for k, (ratio, g, p) in enumerate([(1.0, 0.9, -0.2), (1.0595, 0.5, 0.2), (1.4142, 0.45, 0.0), (1.5, 0.3, -0.3), (2.0, 0.3, 0.3), (2.12, 0.22, 0.1)]):
        s = np.zeros(L)
        for d in (-0.5, 0.0, 0.6):                                  # beating, out of tune with itself
            ph = 2 * np.pi * mh.snap(root * ratio + d) * t + rng().uniform(0, 6.28)
            s += np.sin(ph) + 0.5 * np.sin(2 * ph + 0.7) + 0.3 * np.sin(3 * ph + 1.9)
        lfo = 0.5 + 0.5 * np.sin(2 * np.pi * mh.snap(0.04 + 0.021 * k) * t + k * 1.3)
        a, b = mh.pan(dist(s, 1.4) * lfo * g, p)
        dL += a; dR += b
    for lo, hi, g, rate in ((40, 160, 0.9, 2), (300, 1400, 0.4, 3)):
        for ch in (dL, dR):
            ch += mh.circ_noise(lo, hi) * (0.25 + 0.75 * (0.5 + 0.5 * np.sin(2 * np.pi * mh.snap(rate / LEN_S) * t + rng().uniform(0, 6.28)))) * g * 0.55


def put(bufL, bufR, sig, t0, p):
    a, b = mh.pan(sig, p)
    s = int(t0 * SR)
    mh.add(bufL, a, s)
    mh.add(bufR, b, s)


def warp(x, depth_s, rate):
    """Tape warp: the pitch of the whole bed drifts (a slowly varying delay, circular so the loop stays seamless)."""
    idx = np.arange(L) + depth_s * SR * np.sin(2 * np.pi * mh.snap(rate) * mh.tt(L))
    i0 = np.floor(idx).astype(int)
    fr = idx - i0
    return x[i0 % L] * (1 - fr) + x[(i0 + 1) % L] * fr


def make_bed(k):
    mh.RNG = np.random.default_rng(9000 + k)
    root = ROOTS[k]
    dL, dR = np.zeros(L), np.zeros(L)        # the drone and the heart
    vL, vR = np.zeros(L), np.zeros(L)        # voices that go into the reverb
    sL, sR = np.zeros(L), np.zeros(L)        # screams and rasps, close and dry
    drone_bed(dL, dR, root)
    mh.heartbeat(dL, dR, rng().uniform(0.5, 2), bpm=rng().uniform(58, 100))

    for _ in range(3):                                              # dissonant clusters of moaning voices
        mh.choir(vL, vR, rng().uniform(0, LEN_S - 8), rng().uniform(7, 11), rng().uniform(110, 330), rng().uniform(-0.7, 0.7),
                 vowels=("oh", "uh", "ah", "oo"), size=4, spread=0.9, sink=rng().uniform(2.5, 5), peak=0.9)
    for _ in range(int(rng().integers(2, 4))):                      # crying, from different sides
        c = cry_sig(int(rng().integers(2, 5)), rng().uniform(300, 520), wail=rng().random() < 0.5)
        put(vL, vR, c * 0.75, rng().uniform(0, LEN_S - 7), rng().uniform(-0.8, 0.8))
    for _ in range(int(rng().integers(3, 5))):                      # whispers at the ears
        w = whisper_sig(int(rng().integers(4, 9)), backwards=rng().random() < 0.25, ring=0.7 if rng().random() < 0.2 else 0.0)
        put(vL, vR, w * 0.8, rng().uniform(0, LEN_S - 4), rng().choice([-1, 1]) * rng().uniform(0.5, 1.0))
    for _ in range(int(rng().integers(2, 4))):                      # screams (close)
        s = scream_sig(rng().uniform(1.2, 2.6), rng().uniform(380, 600), rng().uniform(750, 1200), rough=rng().uniform(0.4, 0.8))
        put(sL, sR, s * 0.9, rng().uniform(1, LEN_S - 4), rng().uniform(-0.7, 0.7))
        put(vL, vR, s * 0.5, rng().uniform(1, LEN_S - 4), rng().uniform(-0.7, 0.7))      # and another one, far, in the reverb
    for _ in range(int(rng().integers(2, 4))):                      # rattling breath
        r = rasp_sig(1)
        put(sL, sR, r * 0.6, rng().uniform(0, LEN_S - 4), rng().uniform(-0.6, 0.6))
    for _ in range(2):                                              # backwards swells: something is drawn in
        s = scream_sig(rng().uniform(1.8, 3.0), rng().uniform(420, 600), rng().uniform(800, 1100))
        s = s[::-1] * mh.env(len(s), len(s) / SR * 0.85, 0.05, 1.5)
        put(vL, vR, s * 0.7, rng().uniform(0, LEN_S - 4), rng().uniform(-0.6, 0.6))

    wL = mh.reverb(vL, 1.8, 3200, 11 + k)
    wR = mh.reverb(vR, 1.8, 3200, 29 + k)
    A = dL * 0.5 + vL * 0.35 + wL * 1.1 + sL * 0.8
    B = dR * 0.5 + vR * 0.35 + wR * 1.1 + sR * 0.8
    depth, rate = rng().uniform(0.0015, 0.004), 3 / LEN_S * rng().integers(1, 4)
    A, B = warp(A, depth, rate), warp(B, depth, rate + 1 / LEN_S)         # the two ears warp differently: it is seasick
    f = np.fft.rfftfreq(L, 1 / SR)
    mask = np.clip((f - 14) / 16, 0, 1) * np.clip((11000 - f) / 2500, 0, 1)
    out = np.stack([np.fft.irfft(np.fft.rfft(c) * mask, L) for c in (A, B)], axis=1)
    out = out / np.max(np.abs(out)) * 0.85
    path = os.path.join(BASE, "music", f"abyss{k}.ogg")
    write_ogg(out, path, q=3)
    print("bed", k, os.path.getsize(path) // 1024, "KB")


if __name__ == "__main__":
    only = sys.argv[1] if len(sys.argv) > 1 else "all"
    if only in ("all", "shots"):
        make_oneshots()
    if only in ("all", "beds"):
        for i in range(8):
            make_bed(i)
