"""
Builds the 3D foods of CuteMarket: smooth little models (boxes + octagon prisms) with a DETAILED 64x64 texture each.

  python3 tools/food3d.py                  writes models/item/<food>.json and textures/item/<food>.png (64x64)
  python3 tools/food3d.py --preview F.png  also renders all 8 foods from the inventory angle (software renderer)

How a food is made
 * Every food has a 64x64 texture split into 4 x 4 swatches of 16 x 16 texels (a "big" swatch is 32 x 32). A swatch
   is one material (bun with sesame, patty with grill marks, rice grains, pleated paper cup...), painted in code.
 * A model element (box) shows a crop of a swatch on each face, about 2 texels per model unit, so the pictures
   keep their size and are not stretched. A round thing (a cup, a bun) is an octagon prism: two boxes, one of them
   turned by 45 degrees.
"""
import json, math, os, random, sys, zlib

# ============================================================ colors and swatches
def H(s): return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def lighter(c, t=.3): return mix(c, (255, 255, 255), t)
def darker(c, t=.2): return mix(c, (0, 0, 0), t)

class Sw:
    def __init__(self, n, base=(255, 0, 255)):
        self.n = n; self.p = [[base] * n for _ in range(n)]
    def set(self, x, y, c):
        if 0 <= x < self.n and 0 <= y < self.n: self.p[y][x] = c
    def get(self, x, y): return self.p[y][x]
    def fill(self, c):
        for y in range(self.n):
            for x in range(self.n): self.p[y][x] = c
    def vgrad(self, top, bot):
        for y in range(self.n):
            for x in range(self.n): self.p[y][x] = mix(top, bot, y / max(1, self.n - 1))
    def rect(self, x, y, w, h, c):
        for yy in range(y, y + h):
            for xx in range(x, x + w): self.set(xx, yy, c)
    def disc(self, cx, cy, r, c):
        for y in range(self.n):
            for x in range(self.n):
                if (x + .5 - cx) ** 2 + (y + .5 - cy) ** 2 <= r * r: self.p[y][x] = c
    def speck(self, rng, colors, count):
        for _ in range(count): self.set(rng.randrange(self.n), rng.randrange(self.n), rng.choice(colors))
    def each(self, f):
        for y in range(self.n):
            for x in range(self.n):
                c = f(x, y)
                if c is not None: self.p[y][x] = c

def plain(base, dark=None, light=None, speck=30, vtop=.0, vbot=.0):
    """A solid material with soft speckles and a lighter top / darker bottom."""
    def paint(rng):
        s = Sw(16); s.vgrad(lighter(base, vtop) if vtop else base, darker(base, vbot) if vbot else base)
        cols = [c for c in (dark or darker(base, .15), light or lighter(base, .18)) if c]
        s.speck(rng, cols, speck); return s
    return paint

def p_liner(rng):
    A, B = H('f58fb8'), H('ffb3d1'); s = Sw(16)
    s.each(lambda x, y: (A if (x // 2) % 2 else B))
    for x in range(0, 16, 4): s.rect(x, 0, 1, 16, H('e0709f'))
    for x in range(2, 16, 4): s.rect(x, 0, 1, 16, H('ffd0e4'))
    s.rect(0, 0, 16, 2, lighter(B, .5)); s.rect(0, 14, 16, 2, H('d85f92')); return s

def p_frost(sprinkles):
    def paint(rng):
        s = Sw(16)
        def f(x, y):
            v = (x * 2 + y * 3) % 8
            return H('fff0f6') if v < 2 else H('ffb3d1') if v == 2 else H('ffd0e4')
        s.each(f)
        if sprinkles:
            for _ in range(7):
                x, y = rng.randrange(1, 14), rng.randrange(1, 15); c = rng.choice([H('ffd84a'), H('6fb7e8'), H('66bb6a'), H('ffffff'), H('e53935')])
                s.set(x, y, c); s.set(x + (1 if rng.random() < .5 else 0), y + (0 if rng.random() < .5 else 1), c)
        return s
    return paint

def p_cherry(rng):
    s = Sw(16, H('e53935')); s.vgrad(H('ee4a45'), H('b71c1c'))
    s.rect(3, 3, 3, 2, H('ff8a80')); s.set(3, 3, (255, 255, 255)); s.rect(0, 12, 16, 4, H('9a1515')); return s

def p_waffle(base, line):
    def paint(rng):
        s = Sw(16, base)
        s.each(lambda x, y: line if ((x + y) % 4 == 0 or (x - y) % 4 == 0) else (lighter(base, .2) if (x % 4 == 2 and y % 4 == 0) else base))
        s.speck(rng, [darker(base, .1)], 14); return s
    return paint

def p_scoop(drip):
    def paint(rng):
        s = Sw(16, H('ffb3d1'))
        if not drip:
            s.vgrad(H('ffc2dd'), H('ff9fc4')); s.rect(3, 2, 4, 2, H('ffe0ee')); s.set(2, 3, (255, 255, 255))
            s.speck(rng, [H('a8505f'), H('ffd0e4')], 16)
        else:
            s.fill(H('ffb3d1')); s.rect(0, 0, 16, 7, H('ff8fb8'))
            for x in range(16): s.rect(x, 7, 1, 2 + (x * 5 % 4), H('ff8fb8'))
            s.rect(0, 0, 16, 1, H('ffa8c9'))
        return s
    return paint

def p_tea(rng):
    s = Sw(16); s.vgrad(H('dcb48c'), H('a8764a'))
    for y in range(16): s.set(2, y, lighter(s.get(2, y), .45)); s.set(3, y, lighter(s.get(3, y), .25)); s.set(14, y, darker(s.get(14, y), .2)); s.set(15, y, darker(s.get(15, y), .3))
    return s

def p_pearls(rng):
    s = Sw(16, H('a8764a')); s.vgrad(H('b07a50'), H('8a5a3a'))
    for (cx, cy) in [(2, 2), (7, 3), (12, 2), (4, 7), (10, 8), (14, 7), (2, 12), (7, 13), (12, 12)]:
        s.rect(cx - 1, cy - 1, 3, 3, H('3a2a30')); s.set(cx, cy, H('2a1c22')); s.set(cx - 1, cy - 1, H('6a5560'))
    return s

def p_foam(rng):
    s = Sw(16, H('fff3e6')); s.vgrad(H('ffffff'), H('f3e2cc'))
    for (cx, cy) in [(3, 3), (9, 2), (12, 8), (5, 10), (10, 13)]: s.disc(cx, cy, 1.6, H('fff9f0')); s.set(cx + 1, cy + 1, H('e8d4bb'))
    return s

def p_lid(rng):
    s = Sw(16, H('e8f4ff')); s.vgrad(H('f4faff'), H('c8dcee'))
    s.rect(0, 0, 16, 1, (255, 255, 255)); s.rect(0, 15, 16, 1, H('a8c4dc')); s.rect(3, 4, 2, 7, H('ffffff')); return s

def p_straw(rng):
    s = Sw(16); s.each(lambda x, y: H('ff6b9a') if ((x + y) // 3) % 2 else H('ffffff')); s.rect(0, 0, 2, 16, darker(H('ff6b9a'), .1)); return s

def p_bread(rng):
    s = Sw(16, H('f0c070')); s.vgrad(H('f6d088'), H('e8b45a')); s.speck(rng, [H('d9a450')] * 3 + [H('ffe0a0')], 26); return s

def p_honey(rng):
    s = Sw(16, H('ffc832')); s.vgrad(H('ffd24a'), H('f0b020'))
    for i in range(4): s.rect(2 + i * 3, 2 + i, 2, 1, H('fff3a0'))
    s.rect(9, 8, 3, 2, H('ffe680')); s.rect(0, 14, 16, 2, H('e0a010')); return s

def p_cream(rng):
    s = Sw(16, H('fff6e8')); s.vgrad(H('ffffff'), H('f0e0c8')); s.speck(rng, [H('c9a870'), H('e8d4b0')], 14); s.rect(3, 3, 3, 2, (255, 255, 255)); return s

def p_mint(rng):
    s = Sw(16, H('66bb6a')); s.rect(0, 7, 16, 2, H('a5d66f'))
    for i in range(1, 7): s.set(7 - i // 2 * 0 + i, 7 - i, H('a5d66f')); s.set(7 + i, 8 + i, H('a5d66f'))
    s.rect(0, 0, 16, 1, H('3f8f44')); s.rect(0, 15, 16, 1, H('3f8f44')); return s

def p_bun_top(rng):
    s = Sw(16, H('e0a458')); s.vgrad(H('f2bc6c'), H('d9a05a')); s.speck(rng, [H('f8cc88'), H('c78a3c')], 18)
    for _ in range(9):
        x, y = rng.randrange(1, 14), rng.randrange(1, 14)
        s.set(x, y, H('fff3e0')); s.set(x + 1, y, H('fff3e0')); s.set(x + 1, y + 1, H('9a6a34'))
    return s

def p_lettuce(rng):
    s = Sw(16, H('7fd068'))
    for y in range(16):
        for x in range(16):
            if int(3 * math.sin(x / 2.0 + y / 3.0) + y) % 4 == 0: s.set(x, y, H('9be07a'))
    s.speck(rng, [H('55a84c')], 22); s.rect(0, 0, 16, 1, H('4e9a46')); s.rect(0, 15, 16, 1, H('4e9a46')); return s

def p_cheese(rng):
    s = Sw(16, H('ffd84a')); s.rect(0, 0, 16, 2, H('fff0a0')); s.rect(0, 14, 16, 2, H('e8b82a'))
    for (x, y) in [(3, 6), (10, 5), (7, 9), (12, 10)]: s.rect(x, y, 2, 1, H('e8b82a'))
    return s

def p_patty(rng):
    s = Sw(16, H('7a4a2a')); s.vgrad(H('8a5430'), H('6a3e22'))
    s.each(lambda x, y: H('4a2a18') if (x + y) % 6 < 2 else None); s.speck(rng, [H('9a6238')], 26); return s

def p_tomato(rng):
    s = Sw(16, H('e53935')); s.vgrad(H('ee4a45'), H('c62828')); s.rect(2, 4, 12, 8, H('ff6659'))
    for (x, y) in [(4, 6), (8, 7), (11, 6), (6, 10), (10, 10)]: s.set(x, y, H('ffd84a'))
    return s

def p_pizza_crust(rng):
    s = Sw(16, H('e0a458')); s.vgrad(H('ecb868'), H('c78a3c')); s.speck(rng, [H('f4cd88'), H('a8702c'), H('7a4a2a')], 30); return s

def p_pizza_top(rng):
    s = Sw(32, H('ffd84a'))
    for _ in range(40): s.rect(rng.randrange(0, 30), rng.randrange(0, 30), 3, 2, rng.choice([H('ffe680'), H('f0b82a'), H('ffd84a')]))
    for y in range(32):
        for x in range(32):
            if (x + .5 - 16) ** 2 + (y + .5 - 16) ** 2 > 14.2 ** 2: s.set(x, y, H('e8602c'))
    for a in range(6):                                         # cuts into 6 slices
        ang = a * math.pi / 3 + .3
        for r in range(0, 15): s.set(int(16 + math.cos(ang) * r), int(16 + math.sin(ang) * r), H('e0a010'))
    s.speck(rng, [H('66bb6a'), H('ffffff')], 22); return s

def p_pep(rng):
    s = Sw(16, H('e53935')); s.vgrad(H('ee4a45'), H('c62828')); s.rect(0, 12, 16, 4, H('9a1515'))
    for (x, y) in [(3, 3), (9, 4), (6, 8), (12, 8), (2, 10)]: s.rect(x, y, 2, 2, H('ff8a80'))
    return s

def p_basil(rng):
    s = Sw(16, H('66bb6a')); s.rect(0, 7, 16, 1, H('a5d66f')); s.rect(0, 0, 16, 1, H('3f8f44')); s.speck(rng, [H('4e9a46')], 14); return s

def p_bowl(rng):
    s = Sw(16, H('f4f0ff')); s.vgrad(H('ffffff'), H('d8cde8'))
    for x in range(0, 16, 4): s.disc(x + 2, 8, 2.2, H('f58fb8')); s.disc(x + 2, 8, 1.0, H('ffd0e4'))
    s.rect(0, 0, 16, 1, (255, 255, 255)); return s

def p_rim(rng):
    s = Sw(16, H('ffffff')); s.rect(0, 11, 16, 2, H('f58fb8')); s.rect(0, 14, 16, 2, H('d8cde8')); return s

def p_ramen_top(rng):
    s = Sw(32, H('e8a040'))
    for y in range(32):
        for x in range(32):
            d = math.hypot(x + .5 - 16, y + .5 - 16)
            if d > 15.5: s.set(x, y, (255, 255, 255))
            elif d > 14.2: s.set(x, y, H('f58fb8'))
            elif d > 13.2: s.set(x, y, H('c9b8d8'))
    for k in range(7):                                          # wavy noodles
        for x in range(4, 28):
            y = int(5 + k * 3.6 + math.sin(x / 2.4 + k) * 1.4)
            for t in range(2):
                if math.hypot(x - 16, y + t - 16) < 13: s.set(x, y + t, H('ffe08a') if t == 0 else H('e0b860'))
    s.speck(rng, [H('f4c070'), H('d08a2c')], 30)
    for _ in range(10):
        x, y = rng.randrange(6, 26), rng.randrange(6, 26)
        if math.hypot(x - 16, y - 16) < 12: s.set(x, y, H('a5d66f'))
    return s

def p_egg(rng):
    s = Sw(16, H('ffffff')); s.vgrad((255, 255, 255), H('e8e4f0')); s.speck(rng, [H('f4f0e8')], 8); return s

def p_yolk(rng):
    s = Sw(16, H('ffc832')); s.vgrad(H('ffd24a'), H('f0a820')); s.rect(3, 3, 3, 2, H('fff3a0')); return s

def p_nori(rng):
    s = Sw(16, H('1f4d2b'))
    for x in range(0, 16, 3): s.rect(x, 0, 1, 16, H('2f6b3a'))
    s.speck(rng, [H('163a20'), H('2f6b3a')], 40); return s

def p_chop(rng):
    s = Sw(16, H('c78a3c'))
    for y in range(0, 16, 3): s.rect(0, y, 16, 1, H('a8702c'))
    s.rect(0, 1, 16, 1, H('e0a458')); return s

def p_rice(rng):
    s = Sw(16, H('ffffff'))
    for (x, y) in [(1, 1), (6, 2), (11, 1), (3, 5), (9, 6), (13, 5), (0, 9), (5, 10), (11, 10), (2, 13), (8, 14), (13, 13)]:
        s.rect(x, y, 3, 2, H('f4f0fa')); s.set(x + 2, y + 1, H('d8d4e4')); s.set(x, y, (255, 255, 255))
    return s

def p_salmon(side):
    def paint(rng):
        s = Sw(16, H('ff8a65')); s.vgrad(H('ff9a78'), H('ee7650'))
        for k in range(-2, 6):
            for t in range(16):
                x = k * 4 + t // 1
                if side: s.set(k * 4 + (t % 3), t, H('ffc0aa'))
                else: s.set(x % 16, t, H('ffd0c0')); s.set((x + 1) % 16, t, H('ffb8a0'))
        s.rect(0, 14, 16, 2, H('e8704a')); return s
    return paint

def p_wasabi(rng):
    s = Sw(16, H('a5d66f')); s.speck(rng, [H('c8ec8f'), H('7fb04a')], 36); return s

MATERIALS = {
    'liner': (16, p_liner), 'cake': (16, plain(H('8a5a3a'), speck=44)), 'frost': (16, p_frost(False)), 'frost_spr': (16, p_frost(True)),
    'cherry': (16, p_cherry),
    'waffle': (16, p_waffle(H('e0a458'), H('b87a34'))), 'waffle_dark': (16, p_waffle(H('c78a3c'), H('9a6228'))),
    'scoop': (16, p_scoop(False)), 'scoopdrip': (16, p_scoop(True)),
    'tea': (16, p_tea), 'pearls': (16, p_pearls), 'foam': (16, p_foam), 'lid': (16, p_lid), 'straw': (16, p_straw),
    'crust': (16, plain(H('c78a3c'), dark=H('a8702c'), light=H('e0a458'), speck=44, vtop=.0)), 'bread': (16, p_bread), 'honey': (16, p_honey),
    'cream': (16, p_cream), 'mint': (16, p_mint),
    'bun_bottom': (16, plain(H('d9a05a'), dark=H('b87a34'), light=H('ecc080'), speck=32, vbot=.18)),
    'bun_side': (16, plain(H('e0a458'), dark=H('c78a3c'), light=H('f0c070'), speck=32, vtop=.1, vbot=.12)), 'bun_top': (16, p_bun_top),
    'lettuce': (16, p_lettuce), 'cheese': (16, p_cheese), 'patty': (16, p_patty), 'tomato': (16, p_tomato),
    'pizza_crust': (16, p_pizza_crust), 'pizza_top': (32, p_pizza_top), 'pep': (16, p_pep), 'basil': (16, p_basil),
    'bowl': (16, p_bowl), 'rim': (16, p_rim), 'ramen_top': (32, p_ramen_top), 'egg': (16, p_egg), 'yolk': (16, p_yolk),
    'nori': (16, p_nori), 'chop': (16, p_chop), 'bowl_base': (16, plain(H('c9b8d8'), speck=16)),
    'rice': (16, p_rice), 'salmon': (16, p_salmon(False)), 'salmon_side': (16, p_salmon(True)), 'wasabi': (16, p_wasabi),
}

# ============================================================ geometry
FACES = ('north', 'south', 'west', 'east', 'up', 'down')

class Food:
    def __init__(self, name): self.name = name; self.els = []; self.used = []
    def _mat(self, m):
        if m not in self.used: self.used.append(m)
        return m

    def box(self, x0, y0, z0, x1, y1, z1, mat, top=None, bottom=None, rot=None, skip=(), tag='', uvspec=None):
        """A box. mat = the material of the sides, top / bottom = other materials for those faces.
        rot = (axis, angle, (ox, oy, oz)) turns the box (angle in steps of 22.5 degrees)."""
        dims = {'north': (x1 - x0, y1 - y0), 'south': (x1 - x0, y1 - y0), 'west': (z1 - z0, y1 - y0), 'east': (z1 - z0, y1 - y0),
                'up': (x1 - x0, z1 - z0), 'down': (x1 - x0, z1 - z0)}
        faces = {}
        for f in FACES:
            if f in skip: continue
            m = self._mat(top if f == 'up' and top else bottom if f == 'down' and bottom else mat)
            faces[f] = (m, dims[f], '%s%d%s' % (self.name, len(self.els), f + tag), (uvspec or {}).get(f))
        el = {'from': [round(x0, 3), round(y0, 3), round(z0, 3)], 'to': [round(x1, 3), round(y1, 3), round(z1, 3)], 'faces': faces}
        if rot: el['rotation'] = {'origin': list(rot[2]), 'axis': rot[0], 'angle': rot[1]}
        self.els.append(el)

    def prism(self, cx, cz, r, y0, y1, mat, top=None, down=False):
        """A round thing: a regular octagon made of 4 bars (two straight, two turned by 45 degrees) that cross in the middle.
        The bars end exactly on the 8 sides of the octagon; their tops are a hair apart so they never flicker."""
        a = r * 0.93; w = a * 0.41421356                      # a = distance to the sides, w = half of a side
        big = top is not None and MATERIALS[top][0] == 32      # a big top picture (pizza, ramen) is laid out exactly
        mid = (y0 + y1) / 2
        spec_x = {'up': ('exact', cx - a, cz - w, cx + a, cz + w, cx, cz, a)} if big else None
        spec_z = {'up': ('exact', cx - w, cz - a, cx + w, cz + a, cx, cz, a)} if big else None
        spec_r = {'up': ('corner',)} if big else None
        skip = () if down else ('down',)
        self.box(cx - a, y0, cz - w, cx + a, y1, cz + w, mat, top=top, skip=skip, tag='a', uvspec=spec_x)
        self.box(cx - w, y0 + .02, cz - a, cx + w, y1 - .02, cz + a, mat, top=top, skip=('down',), tag='b', uvspec=spec_z)
        self.box(cx - a, y0 + .04, cz - w, cx + a, y1 - .04, cz + w, mat, top=top, skip=('down',), rot=('y', 45, (cx, mid, cz)), tag='c', uvspec=spec_r)
        self.box(cx - a, y0 + .06, cz - w, cx + a, y1 - .06, cz + w, mat, top=top, skip=('down',), rot=('y', -45, (cx, mid, cz)), tag='d', uvspec=spec_r)

def cupcake():
    f = Food('cupcake')
    f.prism(8, 8, 3.2, 0, 1.8, 'liner', down=True); f.prism(8, 8, 3.9, 1.8, 3.5, 'liner'); f.prism(8, 8, 4.6, 3.5, 5.2, 'liner')
    f.prism(8, 8, 4.9, 5.2, 6.4, 'cake')
    f.prism(8, 8, 5.0, 6.4, 8.4, 'frost_spr'); f.prism(8, 8, 3.9, 8.4, 10.4, 'frost'); f.prism(8, 8, 2.8, 10.4, 12.1, 'frost'); f.prism(8, 8, 1.7, 12.1, 13.3, 'frost')
    f.prism(8, 8, 1.3, 13.3, 15.1, 'cherry'); f.box(8.1, 14.8, 7.8, 8.7, 16, 8.4, 'cake', rot=('z', 22.5, (8.4, 14.8, 8)))
    return f

def icecream():
    f = Food('icecream')
    for i, r in enumerate([0.9, 1.4, 1.9, 2.4, 2.9, 3.4]): f.prism(8, 8, r, i * 1.27, (i + 1) * 1.27 + (0.05 if i == 5 else 0), 'waffle', down=(i == 0))
    f.prism(8, 8, 3.9, 7.65, 8.65, 'waffle_dark')
    f.prism(8, 8, 4.9, 8.65, 9.85, 'scoopdrip'); f.prism(8, 8, 5.2, 9.85, 12.6, 'scoop'); f.prism(8, 8, 4.0, 12.6, 14.2, 'scoop'); f.prism(8, 8, 2.5, 14.2, 15.2, 'scoop')
    f.prism(8, 8, 1.0, 15.2, 16, 'cherry')
    return f

def bubbletea():
    f = Food('bubbletea')
    f.prism(8, 8, 4.3, 0, 2.4, 'pearls', down=True); f.prism(8, 8, 4.3, 2.4, 8.4, 'tea'); f.prism(8, 8, 4.3, 8.4, 9.6, 'foam')
    f.prism(8, 8, 4.8, 9.6, 10.8, 'lid'); f.prism(8, 8, 3.6, 10.8, 11.8, 'lid')
    f.box(9.0, 9.4, 7.4, 10.2, 15.4, 8.6, 'straw', rot=('z', -22.5, (9.6, 9.6, 8)))
    return f

def toast():
    f = Food('toast')
    f.box(3, 0, 3, 13, 5, 13, 'crust', top='bread', bottom='bread')
    f.box(2.9, 5, 2.9, 13.1, 5.9, 13.1, 'honey')
    f.box(2.7, 2.8, 5, 3.0, 5.2, 7, 'honey'); f.box(13.0, 2.2, 8, 13.3, 5.2, 10, 'honey'); f.box(6, 3.2, 2.7, 8, 5.2, 3.0, 'honey'); f.box(9, 2.6, 13.0, 11, 5.2, 13.3, 'honey')
    f.prism(8, 8, 2.8, 5.9, 7.7, 'cream'); f.prism(8, 8, 3.3, 7.7, 9.4, 'cream'); f.prism(8, 8, 2.6, 9.4, 10.6, 'cream')
    f.box(7, 10.6, 7.4, 9.6, 10.95, 8.6, 'mint', rot=('y', 22.5, (8.3, 10.6, 8))); f.box(8.2, 10.6, 8, 10.6, 10.95, 9, 'mint', rot=('y', -45, (9.4, 10.6, 8.5)))
    return f

def burger():
    f = Food('burger')
    f.prism(8, 8, 5.5, 0, 2.2, 'bun_bottom', down=True)
    f.prism(8, 8, 6.4, 2.2, 3.2, 'lettuce')
    f.box(3, 3.2, 3, 13, 3.9, 13, 'cheese')
    for (x, z) in [(3, 3), (12, 3), (3, 12), (12, 12)]: f.box(x, 2.5, z, x + 1, 3.2, z + 1, 'cheese')
    f.prism(8, 8, 5.8, 3.9, 6.1, 'patty'); f.prism(8, 8, 5.3, 6.1, 7.1, 'tomato'); f.prism(8, 8, 6.0, 7.1, 8.0, 'lettuce')
    f.prism(8, 8, 5.7, 8.0, 10.0, 'bun_side'); f.prism(8, 8, 5.2, 10.0, 11.6, 'bun_top'); f.prism(8, 8, 4.2, 11.6, 12.9, 'bun_top'); f.prism(8, 8, 2.9, 12.9, 13.8, 'bun_top')
    return f

def pizza():
    f = Food('pizza')
    f.prism(8, 8, 6.9, 0, 2.2, 'pizza_crust', down=True)
    f.prism(8, 8, 5.9, 2.2, 2.9, 'pizza_crust', top='pizza_top')
    for (x, z) in [(6, 6), (10, 6.5), (8, 9.5), (5.5, 10), (10.5, 10.5)]: f.prism(x, z, 1.4, 2.9, 3.5, 'pep')
    for (x, z, a) in [(7.5, 7.8, 45), (9.8, 8.4, -22.5), (7, 11.4, 22.5)]: f.box(x - .8, 2.9, z - .5, x + .8, 3.2, z + .5, 'basil', rot=('y', a, (x, 2.9, z)))
    return f

def ramen():
    f = Food('ramen')
    f.prism(8, 8, 3.2, 0, 1, 'bowl_base', down=True); f.prism(8, 8, 4.4, 1, 3, 'bowl'); f.prism(8, 8, 5.6, 3, 5, 'bowl'); f.prism(8, 8, 6.4, 5, 6.8, 'bowl')
    f.prism(8, 8, 6.7, 6.8, 7.8, 'rim', top='ramen_top')
    f.prism(6, 6, 1.9, 7.8, 8.9, 'egg'); f.prism(6, 6, 1.0, 8.9, 9.5, 'yolk')
    f.box(10.2, 7.8, 5, 10.7, 11.5, 9, 'nori', rot=('y', -22.5, (10.4, 7.8, 7)))
    for (x, z) in [(8, 10), (9.3, 9), (7, 9.4), (10, 10.6)]: f.box(x, 7.8, z, x + .8, 8.3, z + .8, 'basil')
    f.box(12.2, 7.8, 1.5, 13.2, 8.8, 15, 'chop'); f.box(13.8, 7.8, 2, 14.8, 8.8, 14.5, 'chop')
    return f

def sushi():
    f = Food('sushi')
    f.box(3, 0, 5, 13, 3.8, 11, 'rice')
    f.box(2.4, 3.8, 4.2, 13.6, 5.4, 11.8, 'salmon_side', top='salmon')
    f.box(2.4, 2.6, 4.2, 13.6, 3.8, 4.8, 'salmon_side'); f.box(2.4, 2.6, 11.2, 13.6, 3.8, 11.8, 'salmon_side')
    f.box(7, 0, 4.1, 9, 5.7, 11.9, 'nori')
    f.box(10.5, 5.4, 7, 12, 6.4, 8.6, 'wasabi')
    return f

FOODS = [cupcake, icecream, bubbletea, toast, burger, pizza, ramen, sushi]

# ============================================================ texture atlas + UV
def build_atlas(food):
    """Paint the swatches of one food into its 64x64 texture. Returns (rows of pixels, {material: (x, y, size)})."""
    img = [[(0, 0, 0, 0)] * 64 for _ in range(64)]
    cells = [[False] * 4 for _ in range(4)]; place = {}
    for m in sorted(food.used, key=lambda m: -MATERIALS[m][0]):
        n = MATERIALS[m][0]; k = n // 16
        for cy in range(0, 5 - k):
            ok = False
            for cx in range(0, 5 - k):
                if all(not cells[cy + j][cx + i] for i in range(k) for j in range(k)):
                    for i in range(k):
                        for j in range(k): cells[cy + j][cx + i] = True
                    place[m] = (cx * 16, cy * 16, n); ok = True; break
            if ok: break
        assert m in place, (food.name, 'no room for', m)
        sw = MATERIALS[m][1](random.Random(zlib.crc32((food.name + m).encode())))
        for y in range(n):
            for x in range(n): img[place[m][1] + y][place[m][0] + x] = sw.p[y][x] + (255,)
    return img, place

def face_uv(place, mat, dims, key, spec=None):
    """The crop of a swatch for one face: about 2 texels per model unit (4 for the big swatches), never stretched."""
    x, y, n = place[mat]; dens = n / 8.0
    if spec and spec[0] == 'exact':                       # lay the picture exactly over this part of the top
        _, fx0, fz0, fx1, fz1, cx, cz, a = spec
        k = n / (2 * a)
        u0 = (fx0 - (cx - a)) * k; u1 = (fx1 - (cx - a)) * k; v0 = (fz0 - (cz - a)) * k; v1 = (fz1 - (cz - a)) * k
        return [(x + u0) / 4.0, (y + v0) / 4.0, (x + u1) / 4.0, (y + v1) / 4.0]
    if spec and spec[0] == 'corner':                      # the corners of the big pictures are plain rim / sauce colors
        return [x / 4.0, y / 4.0, (x + 3) / 4.0, (y + 3) / 4.0]
    cw = max(2, min(n, int(round(dims[0] * dens)))); ch = max(2, min(n, int(round(dims[1] * dens))))
    h = zlib.crc32(key.encode())
    ox = x + (h % (n - cw + 1)); oy = y + ((h >> 8) % (n - ch + 1))
    return [ox / 4.0, oy / 4.0, (ox + cw) / 4.0, (oy + ch) / 4.0]

DISPLAY = {
    'gui': {'rotation': [30, 225, 0], 'translation': [0, -0.5, 0], 'scale': [0.66, 0.66, 0.66]},
    'ground': {'rotation': [0, 0, 0], 'translation': [0, 2, 0], 'scale': [0.28, 0.28, 0.28]},
    'fixed': {'rotation': [0, 0, 0], 'translation': [0, 0, 0], 'scale': [0.5, 0.5, 0.5]},
    'thirdperson_righthand': {'rotation': [75, 45, 0], 'translation': [0, 2.5, 0], 'scale': [0.34, 0.34, 0.34]},
    'thirdperson_lefthand': {'rotation': [75, 45, 0], 'translation': [0, 2.5, 0], 'scale': [0.34, 0.34, 0.34]},
    'firstperson_righthand': {'rotation': [0, 45, 0], 'translation': [0, 2, 0], 'scale': [0.4, 0.4, 0.4]},
    'firstperson_lefthand': {'rotation': [0, 225, 0], 'translation': [0, 2, 0], 'scale': [0.4, 0.4, 0.4]},
    'head': {'rotation': [0, 0, 0], 'translation': [0, 14, 0], 'scale': [0.9, 0.9, 0.9]},
}

def main():
    from PIL import Image
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    res = os.path.join(root, 'src/main/resources/assets/cutemod')
    built = {}; total = 0
    for make in FOODS:
        f = make(); img, place = build_atlas(f)
        im = Image.new('RGBA', (64, 64))
        for y in range(64):
            for x in range(64): im.putpixel((x, y), img[y][x])
        im.save(os.path.join(res, 'textures/item', f.name + '.png'))
        els = []
        for e in f.els:
            e2 = dict(e); e2['faces'] = {k: {'uv': face_uv(place, m, dims, key, spec), 'texture': '#p'} for k, (m, dims, key, spec) in e['faces'].items()}
            els.append(e2)
        model = {'gui_light': 'side', 'textures': {'p': 'cutemod:item/' + f.name, 'particle': 'cutemod:item/' + f.name}, 'elements': els, 'display': DISPLAY}
        json.dump(model, open(os.path.join(res, 'models/item', f.name + '.json'), 'w'), separators=(',', ':'))
        built[f.name] = (els, im); total += len(els)
    old = os.path.join(res, 'textures/item/food_palette.png')
    if os.path.exists(old): os.remove(old)
    print('foods: %d, boxes: %d, textures: 64x64 each' % (len(built), total))
    return built

# ============================================================ a small software renderer for the preview
def preview(path, built):
    import numpy as np
    from PIL import Image
    S, SZ = 17, 400
    def rot(p, rx, ry):
        x, y, z = p; c, s = math.cos(math.radians(ry)), math.sin(math.radians(ry))
        x, z = x * c + z * s, -x * s + z * c
        c, s = math.cos(math.radians(rx)), math.sin(math.radians(rx))
        y, z = y * c - z * s, y * s + z * c
        return (x, y, z)
    shade = {'up': 1.0, 'down': .5, 'north': .8, 'south': .8, 'west': .6, 'east': .6}
    sheet = Image.new('RGB', (4 * SZ, 2 * SZ), (255, 238, 246))
    for n, (name, (els, tim)) in enumerate(built.items()):
        tex = np.array(tim); zbuf = np.full((SZ, SZ), -1e9); out = np.zeros((SZ, SZ, 3), dtype=np.uint8); out[:] = (255, 238, 246)
        for el in els:
            fx, fy, fz = el['from']; tx, ty, tz = el['to']
            corners = {'north': [(tx, ty, fz), (fx, ty, fz), (fx, fy, fz), (tx, fy, fz)], 'south': [(fx, ty, tz), (tx, ty, tz), (tx, fy, tz), (fx, fy, tz)],
                       'west': [(fx, ty, fz), (fx, ty, tz), (fx, fy, tz), (fx, fy, fz)], 'east': [(tx, ty, tz), (tx, ty, fz), (tx, fy, fz), (tx, fy, tz)],
                       'up': [(fx, ty, fz), (tx, ty, fz), (tx, ty, tz), (fx, ty, tz)], 'down': [(fx, fy, tz), (tx, fy, tz), (tx, fy, fz), (fx, fy, fz)]}
            r = el.get('rotation')
            for face, fd in el['faces'].items():
                u1, v1, u2, v2 = fd['uv']; quad = corners[face]
                uvs = [(u1, v1), (u2, v1), (u2, v2), (u1, v2)]
                pts = []
                for p in quad:
                    if r:
                        o = r['origin']; a = math.radians(r['angle']); q = [p[i] - o[i] for i in range(3)]
                        ax = 'xyz'.index(r['axis']); i1, i2 = [(1, 2), (2, 0), (0, 1)][ax]
                        c, s = math.cos(a), math.sin(a); q[i1], q[i2] = q[i1] * c - q[i2] * s, q[i1] * s + q[i2] * c
                        p = tuple(q[i] + o[i] for i in range(3))
                    pc = rot((p[0] - 8, p[1] - 8, p[2] - 8), 30, 225)
                    pts.append((SZ / 2 + pc[0] * S, SZ / 2 - pc[1] * S + 12, pc[2]))
                for tri in ((0, 1, 2), (0, 2, 3)):
                    P = [pts[i] for i in tri]; U = [uvs[i] for i in tri]
                    x0, x1 = int(max(0, min(p[0] for p in P))), int(min(SZ - 1, max(p[0] for p in P) + 1)); y0, y1 = int(max(0, min(p[1] for p in P))), int(min(SZ - 1, max(p[1] for p in P) + 1))
                    den = (P[1][1] - P[2][1]) * (P[0][0] - P[2][0]) + (P[2][0] - P[1][0]) * (P[0][1] - P[2][1])
                    if abs(den) < 1e-9: continue
                    for y in range(y0, y1 + 1):
                        for x in range(x0, x1 + 1):
                            a = ((P[1][1] - P[2][1]) * (x + .5 - P[2][0]) + (P[2][0] - P[1][0]) * (y + .5 - P[2][1])) / den
                            b = ((P[2][1] - P[0][1]) * (x + .5 - P[2][0]) + (P[0][0] - P[2][0]) * (y + .5 - P[2][1])) / den
                            c = 1 - a - b
                            if a < -1e-6 or b < -1e-6 or c < -1e-6: continue
                            z = a * P[0][2] + b * P[1][2] + c * P[2][2]
                            if z <= zbuf[y, x]: continue
                            u = (a * U[0][0] + b * U[1][0] + c * U[2][0]) * 4; v = (a * U[0][1] + b * U[1][1] + c * U[2][1]) * 4
                            px = tim.getpixel((min(63, max(0, int(u))), min(63, max(0, int(v)))))
                            zbuf[y, x] = z; out[y, x] = tuple(int(px[k] * shade[face]) for k in range(3))
        sheet.paste(Image.fromarray(out), ((n % 4) * SZ, (n // 4) * SZ))
    sheet.save(path)

if __name__ == '__main__':
    b = main()
    if len(sys.argv) > 2 and sys.argv[1] == '--preview': preview(sys.argv[2], b)
