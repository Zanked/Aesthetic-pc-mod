#!/usr/bin/env python3
"""
Generates the sounds of the Fairy Tales book app (everything is synthesized here: no samples, no copyrighted material).

    python3 tools/make_tales_audio.py              # everything
    python3 tools/make_tales_audio.py page lullaby # only some of the sounds

Needs numpy + scipy + ffmpeg (with libvorbis). Output: src/main/resources/assets/cutemod/sounds/tales/<name>.ogg
and the "tales.*" events in sounds.json (the other events are kept).

 * page (3 variants), open, close, shelf    short effects: a rustle of paper, the book opening and closing, a soft knock
 * amb_forest, amb_meadow, amb_sea, amb_deep, amb_wind, amb_hall, amb_night, amb_rain    quiet loops that the app mixes by scene
 * lullaby                                  a music box melody (3/4, 12 bars), original
 * cue_wolf, cue_owl, cue_chime, cue_sparkle, cue_thunder, cue_bubble, cue_croak
                                            one-shot sounds of single scenes (TaleAudio.cues): a howl, an owl, a clock bell, a wand, ...
How the loops are seamless: noise is filtered in the frequency domain (so it is periodic by construction), every event
that runs past the end wraps around to the beginning and the reverb is a circular convolution.
"""
import json
import math
import os
import subprocess
import sys
import tempfile
import wave

import numpy as np
from scipy.signal import butter, sosfilt

SR = 32000
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "src/main/resources/assets/cutemod")
OUT = os.path.join(ASSETS, "sounds/tales")
rng = np.random.default_rng(20261027)


# ----------------------------------------------------------------------------- helpers
def T(n): return np.arange(n) / SR


def white(n): return rng.standard_normal(n)


def _fc(fc): return min(fc, SR * 0.45) / (SR / 2)


def bp(x, lo, hi): return sosfilt(butter(2, [_fc(lo), _fc(hi)], btype="band", output="sos"), x)


def lp(x, fc, order=2): return sosfilt(butter(order, _fc(fc), output="sos"), x)


def hp(x, fc, order=2): return sosfilt(butter(order, _fc(fc), btype="high", output="sos"), x)


def periodic_band(n, lo, hi, order=2):
    """White noise shaped in the frequency domain: a periodic texture (the end meets the beginning)."""
    X = np.fft.rfft(white(n))
    f = np.fft.rfftfreq(n, 1 / SR)
    f[0] = 1e-3
    H = 1 / np.sqrt(1 + (lo / f) ** (2 * order)) / np.sqrt(1 + (f / hi) ** (2 * order))
    x = np.fft.irfft(X * H, n)
    return x / (np.std(x) + 1e-9)


def plp(x, fc, order=2):
    """A low-pass in the frequency domain: keeps a periodic signal periodic."""
    f = np.fft.rfftfreq(len(x), 1 / SR)
    return np.fft.irfft(np.fft.rfft(x) / np.sqrt(1 + (f / fc) ** (2 * order)), len(x))


def lfo(n, cycles, phase=0.0): return np.sin(2 * np.pi * cycles * np.arange(n) / n + phase)


def add(buf, start, sig):
    """Mix sig into a periodic buffer at 'start' (samples); what runs past the end wraps around."""
    n = len(buf)
    idx = (start + np.arange(len(sig))) % n
    np.add.at(buf, idx, sig)


def reverb(x, seconds=1.6, wet=0.25, periodic=True):
    n = len(x)
    m = int(seconds * SR)
    t = np.arange(m) / SR
    ir = white(m) * np.exp(-t * 6.9 / seconds)
    ir = lp(ir, 5000)
    ir /= np.sqrt(np.sum(ir ** 2))
    if periodic:
        irp = np.zeros(n); irp[:m] = ir[:n]
        y = np.fft.irfft(np.fft.rfft(x) * np.fft.rfft(irp), n)
    else:
        y = np.convolve(x, ir)[:n]
    return x * (1 - wet) + y * wet


def finish(x, rms_db=None, peak=0.85):
    x = x - np.mean(x)
    if rms_db is not None:
        target = 10 ** (rms_db / 20)
        x = x * target / (np.sqrt(np.mean(x ** 2)) + 1e-9)
    m = np.max(np.abs(x))
    if m > peak: x = x * peak / m
    return x


def write_ogg(name, x):
    os.makedirs(OUT, exist_ok=True)
    pcm = (np.clip(x, -1, 1) * 32767).astype("<i2")
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, name + ".wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "2",
                        os.path.join(OUT, name + ".ogg")], check=True)


# ----------------------------------------------------------------------------- birds, crickets, drops
def chirp(f0, f1, dur, shape=1.0, vib=0.0):
    n = int(dur * SR)
    t = np.arange(n) / n
    f = f0 + (f1 - f0) * t ** shape + vib * np.sin(2 * np.pi * 28 * t * dur)
    ph = 2 * np.pi * np.cumsum(f) / SR
    env = np.sin(np.pi * t) ** 1.5
    return env * (np.sin(ph) + 0.18 * np.sin(2 * ph))


def bird(kind):
    if kind == "tweet":                                   # tweet-tweet-tweeet
        parts = [chirp(2900, 3700, 0.07), np.zeros(int(0.05 * SR)), chirp(2950, 3800, 0.07), np.zeros(int(0.05 * SR)), chirp(3000, 4100, 0.14)]
    elif kind == "trill":                                 # a fast trill
        parts = []
        for i in range(9):
            parts += [chirp(3600 + 250 * (i % 2), 4300 - 200 * (i % 2), 0.035), np.zeros(int(0.012 * SR))]
    elif kind == "warble":                                # a slow warble
        parts = [chirp(2400, 3300, 0.22, vib=380), chirp(3300, 2600, 0.30, vib=420), chirp(2700, 3500, 0.18, vib=300)]
    elif kind == "cuckoo":                                # two soft notes
        n = int(0.26 * SR); t = np.arange(n) / SR
        a = np.sin(2 * np.pi * 790 * t) * np.sin(np.pi * t / 0.26) ** 1.4
        b = np.sin(2 * np.pi * 640 * t) * np.sin(np.pi * t / 0.26) ** 1.4
        parts = [a, np.zeros(int(0.08 * SR)), b]
    else:                                                 # "pip"
        parts = [chirp(3300, 4400, 0.05)]
    return np.concatenate(parts)


def cricket(n, period_cycles, pitch, phase):
    """Chirps of pulses, repeated 'period_cycles' times over the loop (so the loop is seamless)."""
    x = np.zeros(n)
    per = n // period_cycles
    pulse_n = int(0.007 * SR)
    t = np.arange(pulse_n) / SR
    pulse = np.sin(2 * np.pi * pitch * t) * np.sin(np.pi * np.arange(pulse_n) / pulse_n)
    for c in range(period_cycles):
        base = c * per + int(phase * per)
        for k in range(4):
            add(x, base + int(k * 0.03 * SR), pulse * (0.7 + 0.1 * k))
    return x


def drop_event(kind, f=1.0):
    if kind == "bubble":
        n = int(rng.uniform(0.05, 0.12) * SR); t = np.arange(n) / n
        fr = (260 + rng.uniform(0, 260)) * f * (1 + 2.2 * t)
        ph = 2 * np.pi * np.cumsum(fr) / SR
        return np.sin(ph) * np.exp(-t * 5) * np.sin(np.pi * np.minimum(1, t * 8)) * 0.6
    n = int(0.003 * SR)
    return white(n) * np.exp(-np.arange(n) / (0.0007 * SR))


# ----------------------------------------------------------------------------- ambience loops
def amb_forest(L=20.0):
    n = int(L * SR)
    leaves = periodic_band(n, 700, 4200) * (0.35 + 0.25 * lfo(n, 4, 1.0) + 0.1 * lfo(n, 9))
    low = periodic_band(n, 60, 380) * (0.3 + 0.15 * lfo(n, 3))
    x = leaves * 0.5 + low * 0.35
    kinds = ["tweet", "trill", "warble", "pip", "tweet", "warble", "trill", "pip"]
    times = np.sort(rng.uniform(0.5, L - 1.5, 8))
    for k, tm in zip(kinds, times):
        add(x, int(tm * SR), bird(k) * rng.uniform(0.13, 0.28))
    add(x, int(13.2 * SR), bird("cuckoo") * 0.10)
    add(x, int(14.0 * SR), bird("cuckoo") * 0.10)
    return finish(reverb(x, 1.0, 0.18), -27)


def amb_meadow(L=20.0):
    n = int(L * SR)
    breeze = periodic_band(n, 250, 2200) * (0.3 + 0.2 * lfo(n, 5, 0.4))
    water = periodic_band(n, 900, 3200) * (0.12 + 0.05 * lfo(n, 17)) * (0.8 + 0.2 * lfo(n, 41, 2))
    x = breeze * 0.45 + water * 0.35
    kinds = ["tweet", "warble", "pip", "trill", "tweet", "pip", "warble", "tweet", "trill", "pip"]
    times = np.sort(rng.uniform(0.4, L - 1.2, 10))
    for k, tm in zip(kinds, times):
        add(x, int(tm * SR), bird(k) * rng.uniform(0.15, 0.3))
    for i in range(4):                                    # a bee passes by
        t0 = rng.uniform(1, L - 3)
        m = int(1.6 * SR); t = np.arange(m) / SR
        b = np.sin(2 * np.pi * 210 * t + 6 * np.sin(2 * np.pi * 3 * t)) * np.sin(np.pi * t / 1.6) ** 2
        add(x, int(t0 * SR), b * 0.035)
    return finish(reverb(x, 0.9, 0.15), -27)


def amb_sea(L=21.0):
    n = int(L * SR)
    t = np.arange(n) / n
    swell = (0.5 + 0.5 * np.sin(2 * np.pi * 3 * t - np.pi / 2)) ** 2.2             # 3 waves per loop
    swell2 = (0.5 + 0.5 * np.sin(2 * np.pi * 5 * t - np.pi / 3)) ** 3.0
    rush = periodic_band(n, 250, 2400) * (0.12 + 0.88 * swell)
    foam = periodic_band(n, 1600, 7500) * np.roll(0.1 + 0.9 * swell, int(0.35 * SR) % n) * 0.5
    far = periodic_band(n, 40, 220) * (0.4 + 0.3 * swell2)
    x = rush * 0.55 + foam * 0.3 + far * 0.35
    for tm in (4.0, 15.5):                                # a gull
        m = int(0.55 * SR); tt = np.arange(m) / m
        fr = 2300 - 900 * tt + 120 * np.sin(2 * np.pi * 14 * tt)
        g = np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.sin(np.pi * tt) ** 1.2
        add(x, int(tm * SR), g * 0.06)
    return finish(reverb(x, 1.2, 0.15), -26)


def amb_deep(L=20.0):
    n = int(L * SR)
    rumble = periodic_band(n, 30, 260) * (0.5 + 0.25 * lfo(n, 2))
    shimmer = periodic_band(n, 500, 1300) * (0.1 + 0.08 * lfo(n, 7, 1.0))
    x = rumble * 0.55 + shimmer * 0.25
    for tm in np.sort(rng.uniform(0.3, L - 0.5, 22)):
        add(x, int(tm * SR), drop_event("bubble") * rng.uniform(0.12, 0.3))
    m = int(5.0 * SR); t = np.arange(m) / m                       # a far away whale song
    fr = 150 + 130 * np.sin(np.pi * t) ** 2 + 22 * np.sin(2 * np.pi * 5 * t)
    whale = np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.sin(np.pi * t) ** 2
    add(x, int(11.0 * SR), whale * 0.05)
    return finish(plp(reverb(x, 1.8, 0.3), 2600), -27)


def amb_wind(L=20.0):
    n = int(L * SR)
    gust = 0.35 + 0.65 * np.clip(lfo(n, 3, 0.5) * 0.7 + lfo(n, 7, 2.0) * 0.3 + 0.2, 0, 1)
    howl = periodic_band(n, 120, 700) * gust
    mid = periodic_band(n, 500, 2000) * (0.15 + 0.5 * np.clip(lfo(n, 5, 1.3), 0, 1))
    whistle = periodic_band(n, 780, 980) * (0.05 + 0.5 * np.clip(lfo(n, 2, 0.2), 0, 1) ** 2)
    x = howl * 0.6 + mid * 0.3 + whistle * 0.12
    return finish(x, -25)


def amb_hall(L=20.0):
    n = int(L * SR)
    roar = periodic_band(n, 60, 520) * (0.3 + 0.15 * lfo(n, 6) + 0.1 * lfo(n, 13, 1))
    x = roar * 0.22
    for _ in range(190):                                          # the crackle of the fire
        tm = rng.uniform(0, L)
        a = rng.exponential(0.12)
        add(x, int(tm * SR), hp(drop_event("click"), 1500, 1) * min(a, 0.5) * 2.2)
    for tm in np.sort(rng.uniform(0.5, L - 0.5, 9)):               # now and then a pop
        m = int(0.025 * SR)
        pop = bp(white(m), 700, 2200) * np.exp(-np.arange(m) / (0.006 * SR))
        add(x, int(tm * SR), pop * rng.uniform(0.25, 0.5))
    for k in range(int(L)):                                       # a quiet clock: tick, tock
        m = int(0.008 * SR); t = np.arange(m) / SR
        f = 1900 if k % 2 == 0 else 1500
        tick = np.sin(2 * np.pi * f * t) * np.exp(-t / 0.0022)
        add(x, int((k + 0.5) * SR), tick * 0.07)
    x = reverb(x, 0.7, 0.2)
    return finish(np.tanh(x * 3.0) / 3.0, -31)


def amb_night(L=20.0):
    n = int(L * SR)
    x = periodic_band(n, 80, 600) * (0.25 + 0.1 * lfo(n, 3)) * 0.2
    for cycles, pitch, ph in ((40, 4300, 0.0), (36, 3900, 0.31), (44, 4650, 0.62), (33, 4100, 0.84)):
        x += cricket(n, cycles, pitch, ph) * 0.07
    m = int(1.9 * SR); t = np.arange(m) / SR                      # an owl: hoo-hoo-hooo
    owl = np.zeros(m)
    for st, du in ((0.0, 0.32), (0.5, 0.32), (1.0, 0.8)):
        i0 = int(st * SR); k = int(du * SR); tt = np.arange(k) / SR
        owl[i0:i0 + k] += (np.sin(2 * np.pi * 395 * tt) + 0.3 * np.sin(2 * np.pi * 790 * tt)) * np.sin(np.pi * tt / du) ** 1.6
    add(x, int(9.5 * SR), owl * 0.07)
    return finish(reverb(x, 1.2, 0.18), -28)


def amb_rain(L=20.0):
    n = int(L * SR)
    body = periodic_band(n, 700, 9000) * (0.8 + 0.1 * lfo(n, 6) + 0.05 * lfo(n, 23))
    roof = periodic_band(n, 100, 500) * 0.3
    x = body * 0.55 + roof * 0.2
    m = int(4.5 * SR); t = np.arange(m) / SR                      # distant thunder
    thunder = lp(white(m), 140, 3) * np.minimum(1, t / 0.5) * np.exp(-t / 1.3)
    thunder = thunder / (np.max(np.abs(thunder)) + 1e-9)
    add(x, int(7.0 * SR), thunder * 0.9)
    return finish(x, -25)


# ----------------------------------------------------------------------------- the music box lullaby
def hz(m): return 440.0 * 2 ** ((m - 69) / 12.0)


def tine(midi, vel, ring=1.0):
    dur = 2.4 * ring
    n = int(dur * SR); t = np.arange(n) / SR
    f = hz(midi)
    x = (np.sin(2 * np.pi * f * t) * np.exp(-t / (0.85 * ring)) +
         0.34 * np.sin(2 * np.pi * f * 2.0 * t + 0.3) * np.exp(-t / (0.40 * ring)) +
         0.17 * np.sin(2 * np.pi * f * 3.01 * t) * np.exp(-t / (0.22 * ring)) +
         0.10 * np.sin(2 * np.pi * f * 4.2 * t) * np.exp(-t / (0.12 * ring)))
    k = int(0.004 * SR)
    x[:k] += hp(white(k), 3000, 1) * 0.25 * np.exp(-np.arange(k) / (0.0012 * SR))      # the click of the comb
    x *= np.minimum(1, t / 0.002)
    return x * vel


def lullaby():
    bpm = 66
    beat = 60.0 / bpm
    bars = 12
    n = int(round(bars * 3 * beat * SR))
    x = np.zeros(n)
    chords = {"C": (48, (64, 67)), "Am": (45, (60, 64)), "F": (53, (60, 65)), "G": (55, (62, 67)), "Em": (52, (59, 64))}
    prog = ["C", "Am", "F", "C", "C", "Em", "F", "G", "C", "Am", "F", "G"]
    mel = [(76, 79, 84), (83, 81, 76), (77, 81, 84), (83, 79, None), (76, 79, 84), (86, 83, 79),
           (81, 77, 81), (79, 83, 86), (84, 88, 84), (81, 84, 88), (86, 84, 81), (83, 86, None)]
    for b in range(bars):
        bass, mids = chords[prog[b]]
        t0 = b * 3 * beat
        add(x, int(t0 * SR), tine(bass, 0.42, 1.3))
        add(x, int((t0 + beat) * SR), tine(mids[0], 0.22))
        add(x, int((t0 + 2 * beat) * SR), tine(mids[1], 0.22))
        for i, note in enumerate(mel[b]):
            if note is not None:
                add(x, int((t0 + i * beat) * SR + rng.integers(0, 90)), tine(note, 0.5 + 0.06 * (i == 0)))
    return finish(reverb(x, 1.7, 0.3), -22)


# ----------------------------------------------------------------------------- short effects
def rustle(dur=0.5, seed=0, lo=1500, hi=7500):
    r = np.random.default_rng(seed)
    n = int(dur * SR); t = np.arange(n) / SR
    noise = bp(r.standard_normal(n), lo, hi)
    env = np.minimum(1, t / 0.02) * np.exp(-t / (dur * 0.32)) * (0.65 + 0.35 * np.sin(2 * np.pi * (8 + seed % 4) * t + seed))
    crack = np.zeros(n)
    for _ in range(16):
        i = int(r.uniform(0, 0.55) * n); k = int(0.003 * SR)
        if i + k < n: crack[i:i + k] += r.standard_normal(k) * np.exp(-np.arange(k) / (0.0008 * SR)) * r.uniform(0.2, 0.8)
    flap = np.sin(2 * np.pi * (130 + 10 * seed) * t) * np.exp(-t / 0.03) * 0.28
    return noise * env * 0.9 + hp(crack, 2500, 1) * 0.5 + flap


def sfx_page(seed): return finish(rustle(0.5, seed), None, 0.8) * 0.9


def sfx_open():
    n = int(1.0 * SR); x = np.zeros(n); t = T(n)
    x += (np.sin(2 * np.pi * 85 * t) * np.exp(-t / 0.05) + lp(white(n), 380) * np.exp(-t / 0.04) * 1.5) * 0.7
    cr = bp(white(n), 240, 800) * np.sin(np.pi * np.clip((t - 0.04) / 0.5, 0, 1)) * (0.6 + 0.4 * np.sin(2 * np.pi * 19 * t)) * 0.45
    x += cr
    r = rustle(0.42, 5)
    x[int(0.3 * SR):int(0.3 * SR) + len(r)] += r * 0.9
    return finish(x, None, 0.8)


def sfx_close():
    n = int(0.8 * SR); x = np.zeros(n); t = T(n)
    r = rustle(0.22, 7)
    x[:len(r)] += r * 0.8
    s = int(0.17 * SR); tt = t[:n - s]
    x[s:] += (np.sin(2 * np.pi * 70 * tt) * np.exp(-tt / 0.07) + lp(white(len(tt)), 420) * np.exp(-tt / 0.06) * 1.6) * 0.9
    puff = lp(white(n), 700) * np.exp(-t / 0.2) * np.minimum(1, t / 0.15)
    x += puff * 0.18
    return finish(x, None, 0.8)


def sfx_shelf():
    n = int(0.45 * SR); t = T(n)
    x = (np.sin(2 * np.pi * 190 * t) * np.exp(-t / 0.07) + 0.6 * np.sin(2 * np.pi * 410 * t) * np.exp(-t / 0.035)) * 0.8
    x += lp(white(n), 900) * np.exp(-t / 0.012) * 1.2
    s = int(0.11 * SR)
    x[s:] += (np.sin(2 * np.pi * 220 * t[:n - s]) * np.exp(-t[:n - s] / 0.05)) * 0.35
    return finish(x, None, 0.7)



# ----------------------------------------------------------------------------- cues: sounds of single scenes
def cue_wolf():
    """A far away howl: a voice that rises, hangs, and slides down, breathy, in a big quiet room."""
    n = int(3.2 * SR); t = T(n)
    f = np.interp(t, [0, 0.35, 1.1, 2.3, 3.2], [260, 420, 470, 440, 300]) * (1 + 0.012 * np.sin(2 * np.pi * 5.2 * t))
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.28 * np.sin(3 * ph)
    x = bp(x, 300, 1900) + bp(white(n), 500, 2200) * 0.07
    env = np.minimum(1, t / 0.35) * np.clip((3.2 - t) / 1.0, 0, 1) ** 1.5
    return finish(reverb(x * env, 1.4, 0.35, periodic=False), None, 0.7)


def cue_owl():
    """Hoo-hoo-hooo: soft round tones."""
    n = int(1.9 * SR); x = np.zeros(n)
    for start, dur, f0 in [(0.05, 0.30, 360), (0.50, 0.28, 350), (0.95, 0.55, 340)]:
        m = int(dur * SR); t = np.arange(m) / SR
        f = f0 * (1 - 0.06 * t / dur)
        ph = 2 * np.pi * np.cumsum(f) / SR
        env = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 1.2
        x[int(start * SR):int(start * SR) + m] += (np.sin(ph) + 0.18 * np.sin(2 * ph)) * env
    return finish(reverb(lp(x, 1500), 1.2, 0.3, periodic=False), None, 0.7)


def cue_chime():
    """One strike of a clock bell: inharmonic partials with a long ring."""
    n = int(3.2 * SR); t = T(n)
    f = 392.0
    x = np.zeros(n)
    for ratio, amp, tau in [(1.0, 1.0, 1.1), (2.0, 0.55, 0.8), (2.76, 0.4, 0.55), (4.07, 0.25, 0.35), (5.4, 0.14, 0.2), (0.5, 0.35, 1.4)]:
        x += amp * np.sin(2 * np.pi * f * ratio * t + 0.3 * ratio) * np.exp(-t / tau)
    k = int(0.006 * SR)
    x[:k] += hp(white(k), 2500, 1) * 0.35 * np.exp(-np.arange(k) / (0.0015 * SR))
    x *= np.minimum(1, t / 0.002)
    return finish(reverb(x, 1.3, 0.2, periodic=False), None, 0.75)


def cue_sparkle():
    """A rising twinkle: a handful of bright pings, like a wand."""
    n = int(1.8 * SR); x = np.zeros(n)
    notes = [88, 91, 95, 98, 100, 103, 107]
    for i, m in enumerate(notes):
        a = int((0.05 + i * 0.075) * SR)
        sig = tine(m, 0.5 - 0.04 * i, 0.5)
        L = min(len(sig), n - a)
        if L > 0: x[a:a + L] += sig[:L]
    return finish(reverb(x, 1.2, 0.3, periodic=False), None, 0.7)


def cue_thunder():
    """Thunder: a crack and a long low rumble that rolls."""
    n = int(4.6 * SR); t = T(n)
    crack = hp(white(n), 800, 1) * np.exp(-t / 0.05) * 0.9
    rum = lp(white(n), 160, 2) * 6 * (0.6 + 0.4 * np.sin(2 * np.pi * 3.1 * t + 1)) * np.minimum(1, t / 0.12) * np.exp(-t / 1.3)
    rum += lp(white(n), 90, 2) * 5 * np.minimum(1, t / 0.4) * np.exp(-t / 1.8) * (0.7 + 0.3 * np.sin(2 * np.pi * 1.7 * t))
    return finish(crack + rum, None, 0.85)


def cue_bubble():
    """Three blooping bubbles: short sine sweeps that go up."""
    n = int(1.3 * SR); x = np.zeros(n)
    for start, f0, dur in [(0.05, 420, 0.09), (0.30, 560, 0.08), (0.52, 340, 0.12), (0.80, 620, 0.07)]:
        m = int(dur * SR); t = np.arange(m) / SR
        f = f0 * (1 + 2.2 * t / dur)
        ph = 2 * np.pi * np.cumsum(f) / SR
        x[int(start * SR):int(start * SR) + m] += np.sin(ph) * np.exp(-t / (dur * 0.5)) * np.minimum(1, t / 0.004)
    return finish(reverb(x, 0.5, 0.15, periodic=False), None, 0.6)


def cue_croak():
    """A toad: a low pulsed buzz, two croaks."""
    n = int(1.0 * SR); x = np.zeros(n)
    for start, dur in [(0.05, 0.28), (0.42, 0.34)]:
        m = int(dur * SR); t = np.arange(m) / SR
        f = 150 + 40 * np.sin(np.pi * t / dur)
        ph = 2 * np.pi * np.cumsum(f) / SR
        pulse = 0.55 + 0.45 * np.sign(np.sin(2 * np.pi * 38 * t))
        sig = (np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.3 * np.sin(3 * ph)) * pulse
        env = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 0.8
        x[int(start * SR):int(start * SR) + m] += bp(sig, 120, 1100) * env
    return finish(x, None, 0.65)


# ----------------------------------------------------------------------------- build
LOOPS = {"amb_forest": amb_forest, "amb_meadow": amb_meadow, "amb_sea": amb_sea, "amb_deep": amb_deep,
         "amb_wind": amb_wind, "amb_hall": amb_hall, "amb_night": amb_night, "amb_rain": amb_rain, "lullaby": lullaby}
CUES = {"cue_wolf": cue_wolf, "cue_owl": cue_owl, "cue_chime": cue_chime, "cue_sparkle": cue_sparkle,
        "cue_thunder": cue_thunder, "cue_bubble": cue_bubble, "cue_croak": cue_croak}
EVENTS = {"page": ["page1", "page2", "page3"], "open": ["open"], "close": ["close"], "shelf": ["shelf"]}
for _c in CUES: EVENTS[_c] = [_c]


def main():
    want = set(sys.argv[1:])
    def todo(*names): return not want or any(n in want for n in names)
    for name, fn in LOOPS.items():
        if not todo(name): continue
        x = fn()
        write_ogg(name, x)
        kb = os.path.getsize(os.path.join(OUT, name + ".ogg")) // 1024
        print(f"{name:11s} {len(x) / SR:5.1f}s  rms {20 * math.log10(np.sqrt(np.mean(x ** 2))):6.1f} dB  peak {np.max(np.abs(x)):.2f}  seam {abs(x[0] - x[-1]):.3f}  {kb} KB", flush=True)
    if todo("page"):
        for i in range(3): write_ogg(f"page{i + 1}", sfx_page(i + 1))
    if todo("open"): write_ogg("open", sfx_open())
    if todo("close"): write_ogg("close", sfx_close())
    if todo("shelf"): write_ogg("shelf", sfx_shelf())
    for name, fn in CUES.items():
        if todo(name, "cues"): write_ogg(name, fn())
    sj = os.path.join(ASSETS, "sounds.json")
    sounds = json.load(open(sj, encoding="utf-8")) if os.path.exists(sj) else {}
    for name in LOOPS: sounds[f"tales.{name}"] = {"sounds": [{"name": f"cutemod:tales/{name}"}]}
    for ev, files in EVENTS.items(): sounds[f"tales.{ev}"] = {"sounds": [{"name": f"cutemod:tales/{f}"} for f in files]}
    with open(sj, "w", encoding="utf-8") as f:
        json.dump(sounds, f, indent=2)
    print("sounds.json updated")


if __name__ == "__main__":
    main()
