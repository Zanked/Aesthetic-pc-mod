#!/usr/bin/env python3
"""
Makes the system and app sounds of Cute OS (AppSfx): pop-ups, new mail, windows opening and closing...
Everything is synthesized here (no samples). It reuses the helpers of make_jobs_audio.py.

    python3 tools/make_app_audio.py     # writes sounds/app/<name>.ogg and registers app.<name> in sounds.json

  notify   a soft "pling"                      (a pop-up)
  mail     a three-note chime                  (a new letter)
  send     a quick upward whoosh               (a letter is sent)
  parcel   two knocks and a "ding"             (a parcel arrived)
  open     a soft rising swish                 (an app opens)
  close    a soft falling swish                (an app is closed or minimized)
  achieve  a short bright arpeggio             (an achievement, a new level, a finished book)

(Coins, the cash register, brush strokes and so on reuse the "jobs.*" sounds of make_jobs_audio.py.)
Needs numpy + scipy + ffmpeg (with libvorbis).
"""
import json
import os
import subprocess
import sys
import tempfile
import wave

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_jobs_audio as J                      # noqa: E402
from make_jobs_audio import SR, T, hz, lp, bp, noise, put, finish, bell_tone, soft_tone, wood_tick   # noqa: E402

ROOT = J.ROOT
ASSETS = J.ASSETS
OUT = os.path.join(ASSETS, "sounds/app")


def notify():
    buf = np.zeros(int(0.7 * SR))
    put(buf, bell_tone(hz(91), 0.5, 9.0), 0.0, 0.8)                         # G6, then C7: a soft "pling"
    put(buf, bell_tone(hz(96), 0.6, 8.0), 0.09, 1.0)
    return finish(lp(buf, 9000), 0.5)


def mail():
    buf = np.zeros(int(1.2 * SR))
    for k, m in enumerate((76, 79, 84)):                                    # E5 G5 C6: "you've got mail"
        put(buf, bell_tone(hz(m), 0.8, 6.0), k * 0.13, 0.9)
        put(buf, soft_tone(hz(m - 12), 0.25, 0, 0.01, 9.0), k * 0.13, 0.25)
    return finish(lp(buf, 9000), 0.55)


def send():
    n = int(0.35 * SR); t = T(n)
    f0, f1 = 500.0, 3500.0                                                  # a whoosh that rises, like a letter flying off
    sweep_band = np.zeros(n)
    for k in range(0, n, 441):                                              # a band-passed noise whose band climbs
        c = f0 * (f1 / f0) ** (k / n)
        e = min(n, k + 441)
        sweep_band[k:e] = bp(noise(e - k + 200, k % 97), c * 0.7, c * 1.4)[:e - k]
    x = sweep_band * np.sin(np.pi * np.clip(t / 0.35, 0, 1)) ** 1.5
    buf = x * 0.8
    put(buf, bell_tone(hz(96), 0.3, 14.0), 0.22, 0.4)
    return finish(buf, 0.45)


def parcel():
    buf = np.zeros(int(1.2 * SR))
    put(buf, wood_tick(0.08, 600, 45.0), 0.0, 1.0)                           # knock, knock...
    put(buf, wood_tick(0.08, 560, 45.0), 0.16, 1.0)
    put(buf, bell_tone(hz(88), 0.8, 6.0), 0.4, 0.9)                          # ...ding!
    return finish(lp(buf, 9000), 0.6)


def _swish(f0, f1, dur, seed):
    n = int(dur * SR); t = T(n)
    x = np.zeros(n)
    step = 441
    for k in range(0, n, step):
        c = f0 * (f1 / f0) ** (k / n)
        e = min(n, k + step)
        x[k:e] = bp(noise(e - k + 200, seed + k % 89), c * 0.7, c * 1.5)[:e - k]
    return x * np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 1.3


def open_():
    buf = _swish(500, 2800, 0.2, 3)
    put(buf, soft_tone(hz(79), 0.12, 0, 0.004, 25.0), 0.1, 0.12 * np.max(np.abs(buf)))
    return finish(buf, 0.35)


def close():
    buf = _swish(2600, 450, 0.2, 5)
    return finish(buf, 0.3)


def achieve():
    buf = np.zeros(int(1.1 * SR))
    for k, m in enumerate((79, 84, 88, 91, 96)):                              # G5 C6 E6 G6 C7
        put(buf, bell_tone(hz(m), 0.7, 6.0), k * 0.07, 0.9)
    put(buf, bell_tone(hz(103), 0.6, 8.0), 0.36, 0.4)
    return finish(lp(buf, 11000), 0.55)


SOUNDS = {"notify": notify, "mail": mail, "send": send, "parcel": parcel, "open": open_, "close": close, "achieve": achieve}


def save_ogg(name, x):
    os.makedirs(OUT, exist_ok=True)
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, name + ".wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-c:a", "libvorbis", "-q:a", "4",
                        os.path.join(OUT, name + ".ogg")], check=True)


def main():
    sj = os.path.join(ASSETS, "sounds.json")
    data = json.load(open(sj, encoding="utf-8")) if os.path.exists(sj) else {}
    for name, fn in SOUNDS.items():
        x = fn()
        save_ogg(name, x)
        data["app." + name] = {"sounds": [{"name": "cutemod:app/" + name, "stream": False}]}
        print("%-8s %.2f s  peak %.2f  %d KB" % (name, len(x) / SR, np.max(np.abs(x)), os.path.getsize(os.path.join(OUT, name + ".ogg")) // 1024 + 1))
    json.dump(data, open(sj, "w", encoding="utf-8"), indent=2)


if __name__ == "__main__":
    main()
