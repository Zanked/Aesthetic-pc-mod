#!/usr/bin/env python3
"""
Makes the sound effects of CuteJobs (JobsApp): everything is synthesized here (no samples), so it is all original.

    python3 tools/make_jobs_audio.py     # writes sounds/jobs/<name>.ogg and registers jobs.<name> in sounds.json

  count     a short count-in tick                         (the last seconds before a shift)
  go        a bright "go!"                                (the shift starts)
  start     a time-clock stamp and a small bell           (a job is picked)
  tick      a dry clock tick                              (the last 10 seconds of a shift)
  end       a shift-end bell                              (time is up)
  good      a bright blip                                 (a right answer, a catch)
  great     a sparkly run                                 (gold, perfect, combo)
  bad       a soft, low "bup", never harsh                (a mistake)
  pop       a soft bubble pop                             (a word bursts, a parcel is picked up)
  swish     a quick paper swish                           (a letter flies into its box)
  pour      a short liquid pour                           (an ingredient goes into the cup)
  serve     a counter bell                                (a customer is served)
  honk      two toy-car beeps                             (a car on the road)
  bump      a dull thud                                   (a car hit, a rock)
  deliver   a doorbell "ding-dong"                        (a parcel is delivered)
  paint     a soft brush stroke                           (the artist paints a cell)
  star      a rising sparkle                              (a star is caught)
  ring      a whoosh with a chime                         (the ship flies through a ring)
  hurt      a crunch and a low note                       (the ship is hit)
  power     a rising shimmer                              (a shield or a slow-motion clock)
  scratch   a short record scratch                        (a missed DJ note)
  drop      a riser into a deep hit                       (the DJ "drop")
  dj0..dj3  the four DJ pads, in the key of the DJ tune (A major pentatonic: A, C#, E, F#; see make_music.py "job_dj")
  coin      one coin                                      (the pay is counted)
  payout    a cash register "cha-ching"                   (the pay is given)
  win       a short cheerful jingle                       (a good shift)
  rankup    a longer fanfare                              (a new rank)
  sad       a gentle, sympathetic "awww"                  (a poor shift)

(The music is "music.jobs" for the list and "music.job_<id>" for every shift, see make_music.py.)
Needs numpy + scipy + ffmpeg (with libvorbis).
"""
import json
import os
import subprocess
import tempfile
import wave

import numpy as np
from scipy.signal import butter, sosfilt

SR = 44100
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "src/main/resources/assets/cutemod")
OUT = os.path.join(ASSETS, "sounds/jobs")


# ----------------------------------------------------------------------------- helpers
def T(n): return np.arange(n) / SR


def hz(m): return 440.0 * 2 ** ((m - 69) / 12.0)


def lp(x, fc, order=2): return sosfilt(butter(order, min(fc, SR * 0.45) / (SR / 2), output="sos"), x)


def bp(x, lo, hi): return sosfilt(butter(2, [lo / (SR / 2), min(hi, SR * 0.45) / (SR / 2)], btype="band", output="sos"), x)


def noise(n, seed=1): return np.random.default_rng(seed).standard_normal(n)


def put(buf, sig, at, gain=1.0):
    i = int(at * SR); e = min(len(buf), i + len(sig))
    if e > i: buf[i:e] += sig[:e - i] * gain


def finish(x, peak):
    x = x - np.mean(x)
    x = x / np.max(np.abs(x)) * peak
    fi, fo = int(0.002 * SR), int(0.02 * SR)
    x[:fi] *= np.linspace(0.0, 1.0, fi)
    x[-fo:] *= np.linspace(1.0, 0.0, fo)
    return x


def bell_tone(f, dur, decay=7.0):
    """A small bell: inharmonic partials, a quick attack, a ringing tail."""
    n = int(dur * SR); t = T(n); s = np.zeros(n)
    for r, a, d in ((1, 1.0, 1.0), (2.76, .5, 1.5), (5.40, .28, 2.2), (8.93, .12, 3.2)):
        if f * r < SR * 0.45: s += a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * decay * d)
    return s * np.minimum(1, t / 0.002)


def soft_tone(f, dur, glide=0.0, att=0.02, decay=6.0, vib=0.0):
    """A round, warm tone (a sine with a quiet second harmonic) that can slide."""
    n = int(dur * SR); t = T(n)
    fr = f * (1 + glide * t / dur) * (1 + vib * np.sin(2 * np.pi * 5.5 * t))
    p = 2 * np.pi * np.cumsum(fr) / SR
    s = np.sin(p) + 0.25 * np.sin(2 * p) + 0.06 * np.sin(3 * p)
    return s * np.minimum(1, t / att) * np.exp(-t * decay)


def square_tone(f, dur, decay=10.0):
    """A soft chip tone (a band-limited square) for the blips."""
    n = int(dur * SR); t = T(n)
    s = np.zeros(n)
    for k in range(1, 12, 2):
        if f * k > SR * 0.4: break
        s += np.sin(2 * np.pi * f * k * t) / k
    return s * np.minimum(1, t / 0.003) * np.exp(-t * decay)


def sweep(f0, f1, dur, decay=5.0):
    """A sine that slides from f0 to f1."""
    n = int(dur * SR); t = T(n)
    ph = 2 * np.pi * np.cumsum(np.linspace(f0, f1, n)) / SR
    return np.sin(ph) * np.minimum(1, t / 0.004) * np.exp(-t * decay)


def thud(f=70, dur=0.25, decay=14.0):
    n = int(dur * SR); t = T(n)
    ph = 2 * np.pi * np.cumsum(f * (1 + 2.0 * np.exp(-t * 40))) / SR
    return np.sin(ph) * np.exp(-t * decay)


def wood_tick(dur=0.05, f=1800, decay=90.0):
    n = int(dur * SR); t = T(n)
    return (np.sin(2 * np.pi * f * t) + 0.5 * bp(noise(n, 3), 1200, 5000)) * np.exp(-t * decay)


# ----------------------------------------------------------------------------- the sounds
def count():
    buf = np.zeros(int(0.25 * SR))
    put(buf, square_tone(hz(76), 0.15, 22.0), 0.0, 1.0)                    # E5, a short soft beep
    put(buf, soft_tone(hz(88), 0.15, 0, 0.003, 25.0), 0.0, 0.4)
    return finish(lp(buf, 5000), 0.55)


def go():
    buf = np.zeros(int(0.9 * SR))
    put(buf, square_tone(hz(83), 0.12, 10.0), 0.0, 0.9)                    # B5, then up to E6: "go!"
    put(buf, square_tone(hz(88), 0.45, 7.0), 0.12, 1.0)
    put(buf, bell_tone(hz(95), 0.7, 6.0), 0.12, 0.6)
    put(buf, bell_tone(hz(100), 0.5, 9.0), 0.2, 0.25)                      # a sparkle on top
    return finish(lp(buf, 9000), 0.7)


def start():
    buf = np.zeros(int(1.0 * SR))
    put(buf, thud(110, 0.12, 30.0), 0.0, 1.0)                              # the time clock: "ka-chunk"
    put(buf, wood_tick(0.06, 1400, 80.0), 0.0, 0.8)
    put(buf, thud(85, 0.14, 28.0), 0.09, 1.0)
    put(buf, wood_tick(0.06, 1000, 80.0), 0.09, 0.7)
    put(buf, bell_tone(hz(88), 0.8, 7.0), 0.2, 0.7)                        # the small "ding" after it
    return finish(lp(buf, 9000), 0.7)


def tick():
    return finish(lp(wood_tick(0.07, 2300, 110.0), 6000), 0.45)


def end():
    buf = np.zeros(int(1.6 * SR))
    for k, at in enumerate((0.0, 0.24)):                                   # two clear strokes of a desk bell
        put(buf, bell_tone(hz(79), 1.2, 4.2), at, 1.0 - 0.15 * k)
        put(buf, bell_tone(hz(79) * 1.003, 1.2, 4.2), at + 0.003, 0.45)
    return finish(lp(buf, 9000), 0.7)


def good():
    buf = np.zeros(int(0.35 * SR))
    put(buf, square_tone(hz(79), 0.1, 18.0), 0.0, 0.7)                     # G5 -> C6, a little "yes"
    put(buf, square_tone(hz(84), 0.22, 12.0), 0.07, 0.8)
    put(buf, bell_tone(hz(91), 0.3, 12.0), 0.07, 0.35)
    return finish(lp(buf, 7000), 0.55)


def great():
    buf = np.zeros(int(0.9 * SR))
    put(buf, bell_tone(hz(84), 0.6, 7.0), 0.0, 0.9)                        # C6, G6, C7: a sparkly run
    put(buf, bell_tone(hz(91), 0.6, 7.0), 0.07, 0.9)
    put(buf, bell_tone(hz(96), 0.7, 6.0), 0.14, 0.8)
    put(buf, bell_tone(hz(103), 0.5, 10.0), 0.2, 0.3)
    return finish(lp(buf, 11000), 0.6)


def bad():
    buf = np.zeros(int(0.5 * SR))
    put(buf, soft_tone(hz(55), 0.18, -0.06, 0.012, 9.0), 0.0, 1.0)         # "bu"
    put(buf, soft_tone(hz(50), 0.28, -0.08, 0.015, 7.0), 0.11, 0.9)        # "bup": a step down
    return finish(lp(buf, 1800), 0.55)


def pop():
    n = int(0.16 * SR)
    x = sweep(260, 900, 0.16, 28.0) + 0.3 * bp(noise(n, 4), 1500, 4500) * np.exp(-T(n) * 60)
    return finish(lp(x, 6000), 0.55)


def swish():
    n = int(0.22 * SR); t = T(n)
    env = np.sin(np.pi * np.clip(t / 0.22, 0, 1)) ** 1.6
    x = bp(noise(n, 6), 1500, 7000) * env
    return finish(x, 0.4)


def pour():
    n = int(0.45 * SR); t = T(n)
    f = 700 + 500 * (t / 0.45)                                             # a rising "glug" as the cup fills
    gl = np.sin(2 * np.pi * np.cumsum(f * (1 + 0.5 * np.sin(2 * np.pi * 18 * t))) / SR)
    x = (0.5 * gl + 0.7 * bp(noise(n, 7), 900, 4500)) * np.sin(np.pi * np.clip(t / 0.45, 0, 1)) ** 0.7
    return finish(lp(x, 5500), 0.45)


def serve():
    buf = np.zeros(int(1.0 * SR))
    put(buf, bell_tone(hz(91), 0.9, 6.0), 0.0, 1.0)                        # a counter bell: one bright "ting"
    put(buf, bell_tone(hz(91) * 1.004, 0.9, 6.0), 0.002, 0.5)
    put(buf, wood_tick(0.04, 2600, 120.0), 0.0, 0.4)
    return finish(lp(buf, 11000), 0.65)


def honk():
    buf = np.zeros(int(0.5 * SR))
    for at in (0.0, 0.2):                                                  # a toy car: "beep-beep"
        put(buf, square_tone(hz(65), 0.14, 6.0), at, 0.8)
        put(buf, square_tone(hz(69), 0.14, 6.0), at, 0.6)
    return finish(lp(buf, 3200), 0.5)


def bump():
    buf = np.zeros(int(0.4 * SR))
    put(buf, thud(75, 0.3, 14.0), 0.0, 1.0)
    put(buf, lp(noise(int(0.12 * SR), 8), 2500) * np.exp(-T(int(0.12 * SR)) * 40), 0.0, 0.7)
    return finish(lp(buf, 3000), 0.7)


def deliver():
    buf = np.zeros(int(1.3 * SR))
    put(buf, bell_tone(hz(84), 0.9, 5.0), 0.0, 1.0)                        # "ding" (C6)...
    put(buf, bell_tone(hz(79), 1.1, 4.5), 0.3, 1.0)                        # ..."dong" (G5)
    return finish(lp(buf, 9000), 0.65)


def paint():
    n = int(0.2 * SR); t = T(n)
    env = np.sin(np.pi * np.clip(t / 0.2, 0, 1)) ** 1.4
    x = (bp(noise(n, 9), 600, 3500) + 0.4 * lp(noise(n, 10), 500)) * env     # a soft, wet brush
    return finish(x, 0.35)


def star():
    buf = np.zeros(int(0.4 * SR))
    for k, m in enumerate((84, 88, 91, 96)):                               # C6 E6 G6 C7, very quick
        put(buf, bell_tone(hz(m), 0.3, 12.0), k * 0.045, 0.8)
    return finish(lp(buf, 11000), 0.5)


def ring():
    n = int(0.6 * SR); t = T(n)
    env = np.sin(np.pi * np.clip(t / 0.35, 0, 1)) ** 2 * (t < 0.35)
    buf = bp(noise(n, 11), 800, 5000) * env * 0.6                          # a whoosh...
    put(buf, bell_tone(hz(91), 0.5, 7.0), 0.22, 0.9)                       # ...and a chime
    put(buf, bell_tone(hz(98), 0.4, 9.0), 0.3, 0.5)
    return finish(lp(buf, 10000), 0.6)


def hurt():
    buf = np.zeros(int(0.6 * SR))
    n = int(0.22 * SR)
    put(buf, bp(noise(n, 12), 300, 4000) * np.exp(-T(n) * 18), 0.0, 1.0)  # a crunch
    put(buf, thud(60, 0.4, 9.0), 0.0, 1.0)
    put(buf, sweep(220, 90, 0.35, 8.0), 0.05, 0.6)
    return finish(lp(buf, 4000), 0.7)


def power():
    n = int(0.7 * SR)
    x = sweep(330, 1320, 0.7, 2.5) + 0.5 * sweep(495, 1980, 0.7, 2.5)      # a rising shimmer
    x = x * (1 + 0.3 * np.sin(2 * np.pi * 14 * T(n)))
    buf = x.copy()
    put(buf, bell_tone(hz(96), 0.5, 8.0), 0.45, 0.6)
    return finish(lp(buf, 9000), 0.55)


def scratch():
    n = int(0.28 * SR); t = T(n)
    f = 500 + 300 * np.sin(2 * np.pi * 9 * t) + 900 * (t / 0.28)           # a record, pushed back and forth
    saw = 2 * ((np.cumsum(f) / SR) % 1.0) - 1
    x = lp(saw * 0.5 + bp(noise(n, 13), 1000, 6000) * 0.6, 5000) * np.sin(np.pi * np.clip(t / 0.28, 0, 1)) ** 0.8
    return finish(x, 0.5)


def drop():
    buf = np.zeros(int(1.6 * SR))
    n = int(0.8 * SR); t = T(n)
    put(buf, bp(noise(n, 14), 400, 9000) * (t / 0.8) ** 2, 0.0, 0.7)       # a riser...
    put(buf, sweep(200, 900, 0.8, 0.0) * (t / 0.8), 0.0, 0.5)
    put(buf, thud(55, 0.8, 5.0), 0.8, 1.2)                                 # ...into a deep hit
    put(buf, bell_tone(hz(81), 1.0, 4.0), 0.8, 0.5)
    put(buf, bell_tone(hz(88), 1.0, 4.0), 0.8, 0.4)
    return finish(lp(buf, 8000), 0.75)


def pad_tone(m):
    """A DJ pad: a short, warm synth pluck."""
    f = hz(m)
    s = soft_tone(f, 0.5, 0, 0.004, 7.0) + 0.25 * square_tone(f, 0.5, 14.0) + 0.25 * bell_tone(f * 2, 0.5, 14.0)
    return finish(lp(s, 6500), 0.6)


def coin():
    buf = np.zeros(int(0.5 * SR))
    put(buf, bell_tone(hz(95), 0.4, 12.0), 0.0, 0.8)                       # B6: a coin, then a higher one
    put(buf, bell_tone(hz(100), 0.45, 11.0), 0.06, 1.0)
    return finish(lp(buf, 12000), 0.5)


def payout():
    buf = np.zeros(int(1.4 * SR))
    put(buf, wood_tick(0.05, 1500, 90.0), 0.0, 0.7)                        # the register drawer: a ratchet, then "cha-ching"
    for k in range(5): put(buf, wood_tick(0.03, 2200 + k * 150, 140.0), 0.02 + k * 0.025, 0.4)
    put(buf, bell_tone(hz(91), 0.9, 5.5), 0.2, 1.0)
    put(buf, bell_tone(hz(96), 1.1, 4.5), 0.32, 1.0)
    put(buf, bell_tone(hz(103), 0.6, 9.0), 0.4, 0.35)
    put(buf, thud(90, 0.15, 25.0), 0.2, 0.5)
    return finish(lp(buf, 11000), 0.7)


def win():
    buf = np.zeros(int(1.4 * SR))
    for m, at in ((72, 0.0), (76, 0.1), (79, 0.2), (84, 0.3)):
        put(buf, bell_tone(hz(m), 0.8, 5.5), at, 0.9)
        put(buf, soft_tone(hz(m - 12), 0.2, 0, 0.01, 9.0), at, 0.3)
    for m in (72, 76, 79, 84):
        put(buf, bell_tone(hz(m), 1.0, 4.2), 0.48, 0.4)
    return finish(lp(buf, 10000), 0.7)


def rankup():
    buf = np.zeros(int(2.4 * SR))
    for m, at in ((67, 0.0), (72, 0.12), (76, 0.24), (79, 0.36), (84, 0.52), (88, 0.68)):    # a rising run to the top
        put(buf, bell_tone(hz(m), 0.9, 5.0), at, 0.9)
        put(buf, square_tone(hz(m - 12), 0.18, 14.0), at, 0.25)
    for m in (72, 79, 84, 88):                                                                # the chord rings out
        put(buf, bell_tone(hz(m), 1.6, 2.8), 0.9, 0.5)
        put(buf, bell_tone(hz(m + 12), 1.0, 6.0), 0.95, 0.16)
    put(buf, thud(70, 0.3, 10.0), 0.9, 0.5)
    return finish(lp(buf, 11000), 0.75)


def sad():
    buf = np.zeros(int(1.2 * SR))
    put(buf, soft_tone(hz(64), 0.38, -0.05, 0.04, 3.5, 0.008), 0.0, 1.0)
    put(buf, soft_tone(hz(60), 0.62, -0.12, 0.04, 2.6, 0.012), 0.34, 0.9)
    return finish(lp(buf, 2400), 0.55)


SOUNDS = {
    "count": count, "go": go, "start": start, "tick": tick, "end": end,
    "good": good, "great": great, "bad": bad, "pop": pop, "swish": swish, "pour": pour, "serve": serve,
    "honk": honk, "bump": bump, "deliver": deliver, "paint": paint, "star": star, "ring": ring, "hurt": hurt,
    "power": power, "scratch": scratch, "drop": drop,
    "dj0": lambda: pad_tone(69), "dj1": lambda: pad_tone(73), "dj2": lambda: pad_tone(76), "dj3": lambda: pad_tone(78),   # A4 C#5 E5 F#5
    "coin": coin, "payout": payout, "win": win, "rankup": rankup, "sad": sad,
}


def save_ogg(name, x):
    os.makedirs(OUT, exist_ok=True)
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, name + ".wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-c:a", "libvorbis", "-q:a", "4",
                        os.path.join(OUT, name + ".ogg")], check=True)


def main():
    sj = os.path.join(ASSETS, "sounds.json")
    data = json.load(open(sj, encoding="utf-8")) if os.path.exists(sj) else {}
    for name, fn in SOUNDS.items():
        x = fn()
        save_ogg(name, x)
        data["jobs." + name] = {"sounds": [{"name": "cutemod:jobs/" + name, "stream": False}]}
        print("%-8s %.2f s  peak %.2f  %d KB" % (name, len(x) / SR, np.max(np.abs(x)), os.path.getsize(os.path.join(OUT, name + ".ogg")) // 1024 + 1))
    json.dump(data, open(sj, "w", encoding="utf-8"), indent=2)


if __name__ == "__main__":
    main()
