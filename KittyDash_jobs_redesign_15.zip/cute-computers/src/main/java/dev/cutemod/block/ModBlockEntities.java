package dev.cutemod.block;

import dev.cutemod.CuteMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, CuteMod.MOD_ID);

    public static final Supplier<BlockEntityType<ComputerBlockEntity>> COMPUTER = BLOCK_ENTITIES.register("computer", () -> {
        Block[] blocks = new Block[0];
        java.util.List<Block> list = new java.util.ArrayList<>();
        for (DeferredHolder<Block, ComputerBlock> h : ModBlocks.all()) list.add(h.get());
        return BlockEntityType.Builder.of(ComputerBlockEntity::new, list.toArray(blocks)).build(null);
    });

    private ModBlockEntities() {}
}
