package dev.cutemod.block;

import dev.cutemod.ComputerColor;
import dev.cutemod.CuteMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.Map;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(CuteMod.MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CuteMod.MOD_ID);

    private static final Map<ComputerColor, DeferredBlock<ComputerBlock>> COMPUTERS = new EnumMap<>(ComputerColor.class);
    private static final Map<ComputerColor, DeferredItem<BlockItem>> COMPUTER_ITEMS = new EnumMap<>(ComputerColor.class);

    static {
        for (ComputerColor color : ComputerColor.values()) {
            DeferredBlock<ComputerBlock> block = BLOCKS.registerBlock(
                    color.blockName(),
                    props -> new ComputerBlock(props, color),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_PINK)
                            .strength(1.0F)
                            .sound(SoundType.METAL)
                            .noOcclusion());
            COMPUTERS.put(color, block);
            COMPUTER_ITEMS.put(color, ITEMS.registerSimpleBlockItem(block));
        }
    }

    public static DeferredBlock<ComputerBlock> get(ComputerColor color) {
        return COMPUTERS.get(color);
    }

    public static Iterable<DeferredBlock<ComputerBlock>> all() {
        return COMPUTERS.values();
    }

    private ModBlocks() {}
}
