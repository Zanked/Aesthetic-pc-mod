package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client: the talent show is coming (opensInSec seconds, 0 = the doors are open now) with this theme. */
public record ShowAlertPayload(int opensInSec, int theme) implements CustomPacketPayload {
    public static final Type<ShowAlertPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "show_alert"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ShowAlertPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ShowAlertPayload::opensInSec,
            ByteBufCodecs.VAR_INT, ShowAlertPayload::theme,
            ShowAlertPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ShowAlertPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onShowAlert(p));
    }
}
