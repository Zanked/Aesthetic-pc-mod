package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client: the talent show is over and your pet took this place; the coins are yours (0 = daily limit reached). */
public record ShowPrizePayload(int coins, int rank) implements CustomPacketPayload {
    public static final Type<ShowPrizePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "show_prize"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ShowPrizePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ShowPrizePayload::coins,
            ByteBufCodecs.VAR_INT, ShowPrizePayload::rank,
            ShowPrizePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ShowPrizePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onShowPrize(p));
    }
}
