package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import dev.cutemod.data.PlayerData;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.HashMap;
import java.util.Map;

/** Server -> client: everything the server has saved for this player (sent on login). */
public record SyncDataPayload(Map<String, String> data) implements CustomPacketPayload {
    public static final Type<SyncDataPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "sync"));

    private static final StreamCodec<ByteBuf, Map<String, String>> MAP = ByteBufCodecs.map(
            HashMap::new, ByteBufCodecs.stringUtf8(48), ByteBufCodecs.stringUtf8(PlayerData.MAX_CHARS * 2),
            PlayerData.MAX_BLOBS);

    public static final StreamCodec<RegistryFriendlyByteBuf, SyncDataPayload> STREAM_CODEC =
            StreamCodec.composite(MAP, SyncDataPayload::data, SyncDataPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(SyncDataPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onSync(payload.data()));
    }
}
