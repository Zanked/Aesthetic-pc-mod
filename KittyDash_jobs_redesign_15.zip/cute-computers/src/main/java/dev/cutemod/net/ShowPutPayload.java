package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "put my pet of this color on the pet show" (or refresh how it looks). */
public record ShowPutPayload(String color, boolean sick, PetLook look, int act, int skill) implements CustomPacketPayload {
    public static final Type<ShowPutPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "show_put"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ShowPutPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(16), ShowPutPayload::color,
            ByteBufCodecs.BOOL, ShowPutPayload::sick,
            PetLook.CODEC, ShowPutPayload::look,
            ByteBufCodecs.VAR_INT, ShowPutPayload::act,
            ByteBufCodecs.VAR_INT, ShowPutPayload::skill,
            ShowPutPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ShowPutPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) ShowServer.put(sp, p); });
    }
}
