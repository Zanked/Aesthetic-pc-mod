package dev.cutemod.net;

import dev.cutemod.data.TubeData;
import net.minecraft.server.level.ServerPlayer;
import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: action 0 = send me the list, 1 = open video id, 2 = like / unlike it, 3 = comment on it, 4 = delete my video. */
public record TubeActionPayload(int action, long id, String text) implements CustomPacketPayload {
    public static final Type<TubeActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "tube_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, TubeActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, TubeActionPayload::action,
            ByteBufCodecs.VAR_LONG, TubeActionPayload::id,
            ByteBufCodecs.stringUtf8(TubeData.MAX_COMMENT * 2), TubeActionPayload::text,
            TubeActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(TubeActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) TubeServer.action(sp, p.action(), p.id(), p.text()); });
    }
}
