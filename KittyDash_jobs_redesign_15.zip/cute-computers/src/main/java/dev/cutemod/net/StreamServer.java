package dev.cutemod.net;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The chat of the LIVE stream in CuteTube: one room for the whole server, kept in memory only (nothing is saved).
 * A player who opens the stream is a viewer; what a viewer says goes to every viewer, one message per 0.75 s,
 * 60 characters. The panda, the bots and "behind_you" are all drawn on the client, this is only the real players.
 */
public final class StreamServer {
    private StreamServer() {}

    public static final int MAX_TEXT = 60;
    private static final int MAX_LOG = 40;
    private static final long GAP_MS = 750L;

    private static MinecraftServer srv;                                  // the room belongs to one running server
    private static final Set<UUID> viewers = new LinkedHashSet<>();
    private static final Map<UUID, Long> last = new HashMap<>();
    private static final Deque<StreamSyncPayload.Msg> log = new ArrayDeque<>();

    public static void action(ServerPlayer sp, int action, String text) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        if (srv != server) {                                              // another world: start with an empty room
            srv = server;
            viewers.clear();
            last.clear();
            log.clear();
        }
        switch (action) {
            case 0 -> {
                viewers.add(sp.getUUID());
                PacketDistributor.sendToPlayer(sp, new StreamSyncPayload(viewers.size(), new ArrayList<>(log)));
                pushCount(sp.getUUID());
            }
            case 1 -> leave(sp.getUUID());
            case 2 -> say(sp, text == null ? "" : text);
            default -> { }
        }
    }

    /** A player left the stream or the game. */
    public static void leave(UUID id) {
        last.remove(id);
        if (viewers.remove(id)) pushCount(null);
    }

    private static void pushCount(UUID except) {
        StreamSyncPayload p = new StreamSyncPayload(viewers.size(), List.of());
        for (UUID u : viewers) {
            if (u.equals(except)) continue;
            ServerPlayer sp = srv == null ? null : srv.getPlayerList().getPlayer(u);
            if (sp != null) PacketDistributor.sendToPlayer(sp, p);
        }
    }

    private static String clean(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length() && sb.length() < MAX_TEXT; i++) {
            char c = s.charAt(i);
            sb.append(c == '\n' || c == '\r' || c == '\t' ? ' ' : c < 32 || c == 127 ? '?' : c);
        }
        return sb.toString().trim();
    }

    private static void say(ServerPlayer sp, String text) {
        if (!viewers.contains(sp.getUUID())) return;                     // only a viewer can talk
        String body = clean(text);
        if (body.isEmpty()) return;
        long now = System.currentTimeMillis();
        Long prev = last.get(sp.getUUID());
        if (prev != null && now - prev < GAP_MS) return;
        last.put(sp.getUUID(), now);
        StreamSyncPayload.Msg m = new StreamSyncPayload.Msg(sp.getGameProfile().getName(), body);
        log.addLast(m);
        while (log.size() > MAX_LOG) log.removeFirst();
        StreamSyncPayload p = new StreamSyncPayload(viewers.size(), List.of(m));
        for (UUID u : viewers) {                                          // the speaker gets it too: that is their echo
            ServerPlayer v = srv.getPlayerList().getPlayer(u);
            if (v != null) PacketDistributor.sendToPlayer(v, p);
        }
    }
}
