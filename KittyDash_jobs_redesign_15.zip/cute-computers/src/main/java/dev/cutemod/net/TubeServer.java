package dev.cutemod.net;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.cutemod.data.TubeData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The server side of the videos the players publish in CuteTube: publishing and its limits, likes, comments,
 * deleting, and the operator command /cutetube. A video is 2 to 12 Paint pictures, see {@link TubeData}.
 */
public final class TubeServer {
    private TubeServer() {}

    public static final int OK = 0, TOO_FAST = 1, LIMIT = 2, INVALID = 3, COMMENT_FAST = 4, NOT_FOUND = 5;
    private static final long PUBLISH_GAP_MS = 180_000L;       // one video every 3 minutes
    private static final long COMMENT_GAP_MS = 4_000L;         // one comment every 4 seconds
    private static final long REQUEST_GAP_MS = 400L;
    private static final int LIST_SIZE = 40;

    private static final Map<UUID, Long> lastPublish = new HashMap<>();
    private static final Map<UUID, Long> lastComment = new HashMap<>();
    private static final Map<UUID, Long> lastRequest = new HashMap<>();

    public static void leave(UUID id) {
        lastPublish.remove(id);
        lastComment.remove(id);
        lastRequest.remove(id);
    }

    /** Sends the list (and, if openId > 0, that video with its pictures and comments) to one player. */
    private static void push(ServerPlayer sp, int result, long openId) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        TubeData data = TubeData.get(server);
        UUID me = sp.getUUID();
        List<TubeSyncPayload.Entry> list = new ArrayList<>();
        for (TubeData.Video v : data.newest(LIST_SIZE)) {
            list.add(new TubeSyncPayload.Entry(v.id, v.authorName, v.title, v.fps, v.tune, v.frames.size(), v.likes.size(),
                    v.likes.contains(me), v.author.equals(me), v.comments.size(), v.frames.get(0)));
        }
        List<byte[]> frames = List.of();
        List<TubeSyncPayload.Comm> comments = List.of();
        long shown = 0;
        TubeData.Video open = openId > 0 ? data.find(openId) : null;
        if (open != null) {
            shown = open.id;
            frames = new ArrayList<>(open.frames);
            List<TubeSyncPayload.Comm> cs = new ArrayList<>();
            for (int i = open.comments.size() - 1; i >= 0; i--) {                      // newest first
                TubeData.Comment c = open.comments.get(i);
                cs.add(new TubeSyncPayload.Comm(c.name(), c.text()));
            }
            comments = cs;
        } else if (openId > 0 && result < 0) {
            result = NOT_FOUND;
        }
        PacketDistributor.sendToPlayer(sp, new TubeSyncPayload(result, shown, list, frames, comments));
    }

    private static boolean tooSoon(Map<UUID, Long> map, UUID id, long gap) {
        long now = System.currentTimeMillis();
        Long last = map.get(id);
        if (last != null && now - last < gap) return true;
        map.put(id, now);
        return false;
    }

    private static String clean(String s, int max) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length() && sb.length() < max; i++) {
            char c = s.charAt(i);
            sb.append(c == '\n' || c == '\r' || c == '\t' ? ' ' : c < 32 || c == 127 ? '?' : c);
        }
        return sb.toString().trim();
    }

    private static boolean validFrame(byte[] d) {
        if (d.length != TubeData.FRAME_BYTES) return false;
        for (byte b : d) if (((b >> 4) & 15) > TubeData.PALETTE || (b & 15) > TubeData.PALETTE) return false;
        return true;
    }

    public static void action(ServerPlayer sp, int action, long id, String text) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        TubeData data = TubeData.get(server);
        switch (action) {
            case 0 -> { if (!tooSoon(lastRequest, sp.getUUID(), REQUEST_GAP_MS)) push(sp, -1, 0); }
            case 1 -> { if (!tooSoon(lastRequest, sp.getUUID(), REQUEST_GAP_MS)) push(sp, -1, id); }
            case 2 -> {                                                                // like / unlike
                TubeData.Video v = data.find(id);
                if (v != null && !v.author.equals(sp.getUUID())) {                     // not your own video
                    if (!v.likes.remove(sp.getUUID())) v.likes.add(sp.getUUID());
                    data.setDirty();
                }
                push(sp, -1, id);
            }
            case 3 -> {                                                                // comment
                TubeData.Video v = data.find(id);
                String body = clean(text == null ? "" : text, TubeData.MAX_COMMENT);
                if (v == null) { push(sp, NOT_FOUND, 0); return; }
                if (body.isEmpty()) { push(sp, -1, id); return; }
                if (tooSoon(lastComment, sp.getUUID(), COMMENT_GAP_MS)) { push(sp, COMMENT_FAST, id); return; }
                v.comments.add(new TubeData.Comment(sp.getGameProfile().getName(), body));
                while (v.comments.size() > TubeData.MAX_COMMENTS) v.comments.remove(0);
                data.setDirty();
                push(sp, -1, id);
            }
            case 4 -> {                                                                // delete my own video
                TubeData.Video v = data.find(id);
                if (v != null && v.author.equals(sp.getUUID())) data.remove(id);
                push(sp, -1, 0);
            }
            default -> { }
        }
    }

    public static void publish(ServerPlayer sp, String title, int fps, int tune, List<byte[]> frames) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        TubeData data = TubeData.get(server);
        String name = clean(title == null ? "" : title, TubeData.MAX_TITLE);
        if (name.isEmpty() || frames.size() < TubeData.MIN_FRAMES || frames.size() > TubeData.MAX_FRAMES
                || fps < 2 || fps > 12 || tune < 0 || tune > 3) { push(sp, INVALID, 0); return; }
        for (byte[] f : frames) if (!validFrame(f)) { push(sp, INVALID, 0); return; }
        if (data.countBy(sp.getUUID()) >= TubeData.MAX_PER_PLAYER) { push(sp, LIMIT, 0); return; }
        if (tooSoon(lastPublish, sp.getUUID(), PUBLISH_GAP_MS)) { push(sp, TOO_FAST, 0); return; }
        TubeData.Video v = data.add(sp.getUUID(), sp.getGameProfile().getName(), name, fps, tune, frames);
        push(sp, OK, v.id);
    }

    /** /cutetube delete <id> and /cutetube clear <player>: an operator removes videos. */
    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("cutetube").requires(s -> s.hasPermission(2))
                .then(Commands.literal("delete").then(Commands.argument("id", LongArgumentType.longArg(1)).executes(ctx -> {
                    long id = LongArgumentType.getLong(ctx, "id");
                    boolean ok = TubeData.get(ctx.getSource().getServer()).remove(id);
                    if (!ok) { ctx.getSource().sendFailure(Component.translatable("cutemod.tube.cmd.none", id)); return 0; }
                    ctx.getSource().sendSuccess(() -> Component.translatable("cutemod.tube.cmd.deleted", id), true);
                    return 1;
                })))
                .then(Commands.literal("clear").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> {
                    String name = StringArgumentType.getString(ctx, "player");
                    int n = TubeData.get(ctx.getSource().getServer()).removeByName(name);
                    if (n == 0) { ctx.getSource().sendFailure(Component.translatable("cutemod.tube.cmd.nobody", name)); return 0; }
                    ctx.getSource().sendSuccess(() -> Component.translatable("cutemod.tube.cmd.cleared", n, name), true);
                    return n;
                }))));
    }
}
