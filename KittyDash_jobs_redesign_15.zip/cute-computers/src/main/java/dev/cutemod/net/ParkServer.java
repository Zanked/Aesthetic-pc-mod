package dev.cutemod.net;

import dev.cutemod.data.ParkData;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The Pet Park on the server: who is in the park right now and where, what the pets do with each other (play, dance, give a
 * treat, say a quick phrase), friendship and the small coin rewards. The park itself is not saved (only the friendship and the
 * daily totals are, in {@link ParkData}). The pets themselves are sent by the clients and cannot be verified.
 * <p>
 * The residents ({@link ParkBots}) are always there and are added to every answer; where they stand is computed from the clock.
 * The only things remembered about them are short: who is dancing, what a resident is about to say and who it has waved at.
 */
public final class ParkServer {
    private ParkServer() {}

    private record Member(String name, String color, boolean sick, PetLook look, int x, int y, int emote, long emoteUntil, long seen, long playUntil) {}

    public static final int MAX_PETS = 16, X_MAX = 300, Y_MIN = 70, Y_MAX = 150, NEAR = 110;
    private static final long ALIVE_MS = 6000, MOVE_GAP_MS = 80, EMOTE_MS = 3000, PLAY_MS = 2500, DANCE_MS = 4500, PAIR_GAP_MS = 15_000,
            TREAT_GAP_MS = 4000, SAY_MS = 4500, SAY_GAP_MS = 1500, GREET_GAP_MS = 150_000, GREET_MS = 3000;
    private static final int COINS_PER_PLAY = 2, DAILY_CAP = 20;

    private static final Map<UUID, Member> park = new LinkedHashMap<>();
    private static final Map<UUID, Long> lastMove = new HashMap<>();
    private static final Map<String, Long> lastPlay = new HashMap<>();             // pair or player|resident + "#" + kind -> time
    private static final Map<UUID, long[]> says = new HashMap<>();                 // player -> {phrase, until}
    private static final Map<UUID, Long> lastSay = new HashMap<>();
    private static final Map<String, long[]> botSays = new HashMap<>();            // resident -> {line number, from, until}
    private static final Map<String, Long> botPlay = new HashMap<>();              // resident -> plays or dances until
    private static final Map<String, Long> greeted = new HashMap<>();              // player|resident -> when it last waved

    private static String clean(String s, int max) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length() && sb.length() < max; i++) { char c = s.charAt(i); if (c >= 32 && c != 127) sb.append(c); }
        return sb.toString();
    }

    private static void expire(long now) {
        for (Iterator<Member> it = park.values().iterator(); it.hasNext(); ) if (now - it.next().seen() > ALIVE_MS) it.remove();
    }

    public static void move(ServerPlayer sp, ParkMovePayload p) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        long now = System.currentTimeMillis();
        Long last = lastMove.get(sp.getUUID());
        if (last != null && now - last < MOVE_GAP_MS) return;
        lastMove.put(sp.getUUID(), now);
        expire(now);
        UUID me = sp.getUUID();
        if (p.sick()) { park.remove(me); sync(sp, 0, "", 0, 0, 0); return; }               // a sick pet rests at home
        if (!park.containsKey(me) && park.size() >= MAX_PETS) { sync(sp, 2, "", 0, 0, 0); return; }
        Member old = park.get(me);
        int x = Math.max(0, Math.min(X_MAX, p.x())), y = Math.max(Y_MIN, Math.min(Y_MAX, p.y()));
        int emote = old == null ? 0 : old.emote();
        long until = old == null ? 0 : old.emoteUntil();
        if (p.emote() >= 1 && p.emote() <= 6) { emote = p.emote(); until = now + EMOTE_MS; }
        if (until < now) emote = 0;
        PetLook l = p.look();
        PetLook look = new PetLook(Math.max(0, Math.min(2, l.stage())), Math.max(0, Math.min(4, l.trait())), Math.max(0, l.ageMin()), clean(l.head(), 64), clean(l.body(), 64), clean(l.name(), 12), Math.max(0, Math.min(3, l.variant())));
        park.put(me, new Member(sp.getGameProfile().getName(), clean(p.color(), 16), false, look, x, y, emote, until, now, old == null ? 0 : old.playUntil()));
        sync(sp, 0, "", 0, 0, 0);
    }

    public static void leave(UUID id) {
        park.remove(id);
        lastMove.remove(id);
        says.remove(id);
        lastSay.remove(id);
    }

    /** Makes the pet dance or play (until the given time) and optionally shows an emote (emote -1 keeps the one it has). */
    private static void mark(UUID id, long until, int emote) {
        Member m = park.get(id);
        if (m == null) return;
        park.put(id, new Member(m.name(), m.color(), m.sick(), m.look(), m.x(), m.y(),
                emote >= 0 ? emote : m.emote(), emote >= 0 ? until : m.emoteUntil(), m.seen(), until));
    }

    /**
     * My pet does something with another pet, a player's or a resident's. kind 0 = play (coins for both, a player's daily limit
     * applies), 2 = give a treat (friendship counts double, the treat itself is taken and given by the clients), 3 = dance (friendship only).
     */
    public static void act(ServerPlayer sp, String targetId, int kind, int gift) {
        if (kind != 0 && kind != 2 && kind != 3) return;
        if (kind == 2 && (gift < 0 || gift >= ParkData.GIFTS.length)) return;
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        UUID me = sp.getUUID();
        long now = System.currentTimeMillis();
        expire(now);
        Member a = park.get(me);
        if (a == null) return;
        int bot = ParkBots.index(targetId);
        UUID target = null;
        String name;
        int tx, ty;
        if (bot >= 0) {
            ParkBots.Pos p = ParkBots.at(bot, now);
            tx = p.x();
            ty = p.y();
            name = ParkBots.ALL.get(bot).name();
        } else {
            try { target = UUID.fromString(targetId); } catch (IllegalArgumentException e) { return; }
            Member b = park.get(target);
            if (b == null || me.equals(target)) return;
            tx = b.x();
            ty = b.y();
            name = b.name();
        }
        if (Math.abs(a.x() - tx) > NEAR || Math.abs(a.y() - ty) > NEAR) return;             // too far from each other
        String gap = (bot >= 0 ? me + "|" + targetId : kind == 2 ? me + "|" + target : ParkData.pair(me, target)) + "#" + kind;
        Long last = lastPlay.get(gap);
        if (last != null && now - last < (kind == 2 ? TREAT_GAP_MS : PAIR_GAP_MS)) return;
        lastPlay.put(gap, now);

        ParkData data = ParkData.get(server);
        int step = kind == 2 ? 2 : 1;
        int total = bot >= 0 ? data.addBotPlay(me, targetId, step) : data.addPlay(me, target, step);
        int bonus = ParkData.bonusBetween(total - step, total);
        long day = now / 86_400_000L;
        int mine = bonus, theirs = bonus;
        if (kind == 0) {
            mine += data.pay(me, COINS_PER_PLAY, DAILY_CAP, day);
            if (bot < 0) theirs += data.pay(target, COINS_PER_PLAY, DAILY_CAP, day);
        }
        long until = now + (kind == 3 ? DANCE_MS : PLAY_MS);
        int emote = kind == 3 ? 4 : -1;
        mark(me, until, emote);
        if (bot >= 0) {
            botPlay.put(targetId, until);
            botSays.put(targetId, new long[]{100 + bot * 10 + (kind == 2 ? 9 : 0), now + 500, now + 500 + SAY_MS});
        } else mark(target, until, emote);

        int gave = kind == 2 ? gift : 0;
        sync(sp, kind == 0 ? 1 : kind == 2 ? 4 : 5, name, total, mine, gave);
        if (bot < 0) {
            ServerPlayer other = server.getPlayerList().getPlayer(target);
            if (other != null) sync(other, kind == 0 ? 1 : kind == 2 ? 3 : 5, a.name(), total, theirs, gave);
        }
    }

    /** My pet says a quick phrase: everybody sees the bubble, and the residents standing nearby answer one after another. */
    public static void say(ServerPlayer sp, int id) {
        if (id < 1 || id > ParkData.SAY_COUNT) return;
        UUID me = sp.getUUID();
        long now = System.currentTimeMillis();
        Member a = park.get(me);
        if (a == null) return;
        Long last = lastSay.get(me);
        if (last != null && now - last < SAY_GAP_MS) return;
        lastSay.put(me, now);
        says.put(me, new long[]{id, now + SAY_MS});
        int k = 0;
        for (int i = 0; i < ParkBots.ALL.size(); i++) {
            ParkBots.Pos p = ParkBots.at(i, now + 900);
            if (Math.abs(a.x() - p.x()) > 90 || Math.abs(a.y() - p.y()) > 70) continue;
            long from = now + 900 + (long) k++ * 900;
            botSays.put(ParkBots.ALL.get(i).id(), new long[]{100 + i * 10 + id, from, from + SAY_MS});
        }
    }

    private static void sync(ServerPlayer sp, int event, String with, int plays, int prize, int gift) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        long now = System.currentTimeMillis();
        ParkData data = ParkData.get(server);
        List<ParkSyncPayload.Pet> out = new ArrayList<>();
        for (Map.Entry<UUID, Member> e : park.entrySet()) {
            if (e.getKey().equals(sp.getUUID())) continue;
            Member m = e.getValue();
            long[] sy = says.get(e.getKey());
            out.add(new ParkSyncPayload.Pet(e.getKey().toString(), m.name(), m.color(), m.look(), m.sick(), m.x(), m.y(),
                    m.emoteUntil() > now ? m.emote() : 0, m.playUntil() > now, data.plays(sp.getUUID(), e.getKey()),
                    sy != null && sy[1] > now ? (int) sy[0] : 0));
        }
        Member me = park.get(sp.getUUID());
        for (int i = 0; i < ParkBots.ALL.size(); i++) out.add(botPet(sp, me, i, now, data));
        PacketDistributor.sendToPlayer(sp, new ParkSyncPayload(event, with, plays, prize, gift, out));
    }

    /** A resident as this player sees it: where it stands, its emote, what it says, and a wave if the player's pet comes close. */
    private static ParkSyncPayload.Pet botPet(ServerPlayer sp, Member me, int i, long now, ParkData data) {
        ParkBots.Bot b = ParkBots.ALL.get(i);
        ParkBots.Pos p = ParkBots.at(i, now);
        int plays = data.botPlays(sp.getUUID(), b.id());
        int emote = ParkBots.emote(i, p);
        int line = ParkBots.idleLine(i, p);
        int say = line > 0 ? 100 + i * 10 + line : 0;
        long[] bs = botSays.get(b.id());
        if (bs != null && bs[1] <= now && now < bs[2]) say = (int) bs[0];                    // an answer beats a remark
        if (me != null && Math.abs(me.x() - p.x()) < 50 && Math.abs(me.y() - p.y()) < 40) {
            String key = sp.getUUID() + "|" + b.id();
            Long g = greeted.get(key);
            if (g == null || now - g > GREET_GAP_MS) { greeted.put(key, now); g = now; }
            if (now - g < GREET_MS) emote = ParkData.level(plays) >= 2 ? 1 : 2;               // friends send a heart, the others a "Hi"
        }
        return new ParkSyncPayload.Pet(b.id(), b.name(), b.color(), b.look(), false, p.x(), p.y(), emote,
                botPlay.getOrDefault(b.id(), 0L) > now, plays, say);
    }
}
