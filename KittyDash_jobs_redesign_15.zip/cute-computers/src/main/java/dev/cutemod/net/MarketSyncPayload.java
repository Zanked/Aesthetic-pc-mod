package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import dev.cutemod.data.MarketData;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/** Server -> client: the parcels on their way, the server's clock, and coins to give back (0 if none). */
public record MarketSyncPayload(long serverNow, int refund, List<MarketData.Parcel> parcels) implements CustomPacketPayload {
    public static final Type<MarketSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "market_sync"));

    private static final StreamCodec<ByteBuf, MarketData.Parcel> PARCEL = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(24), MarketData.Parcel::id,
            ByteBufCodecs.VAR_INT, MarketData.Parcel::qty,
            ByteBufCodecs.VAR_LONG, MarketData.Parcel::ready,
            MarketData.Parcel::new);

    public static final StreamCodec<RegistryFriendlyByteBuf, MarketSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_LONG, MarketSyncPayload::serverNow,
            ByteBufCodecs.VAR_INT, MarketSyncPayload::refund,
            PARCEL.apply(ByteBufCodecs.list(64)), MarketSyncPayload::parcels,
            MarketSyncPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(MarketSyncPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onMarketSync(payload));
    }
}
