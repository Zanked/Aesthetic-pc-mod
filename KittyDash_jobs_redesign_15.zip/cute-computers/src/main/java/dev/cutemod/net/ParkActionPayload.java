package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: leave the park (target empty), or do something with another pet: {@code target} is the id of a player
 * (a UUID) or of a resident ("bot:..."); kind 0 = play (coins), 2 = give a treat (gift = the index in ParkData.GIFTS), 3 = dance.
 */
public record ParkActionPayload(String target, int kind, int gift) implements CustomPacketPayload {
    public static final Type<ParkActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "park_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ParkActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(40), ParkActionPayload::target,
            ByteBufCodecs.VAR_INT, ParkActionPayload::kind,
            ByteBufCodecs.VAR_INT, ParkActionPayload::gift,
            ParkActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ParkActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer sp)) return;
            if (p.target().isEmpty()) ParkServer.leave(sp.getUUID()); else ParkServer.act(sp, p.target(), p.kind(), p.gift());
        });
    }
}
