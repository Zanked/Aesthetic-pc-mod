package dev.cutemod.net;

import java.util.List;

/**
 * The residents of the Pet Park: pets that belong to nobody and live in the park all the time, so it is never empty.
 * <p>
 * They have no state of their own: where a resident stands, whether it waves and what it says is a pure function of the
 * clock, so every player sees the same resident in the same place and nothing has to be saved or ticked. Only the things
 * players do to them (a play, a treat, a chat answer) are remembered, by {@link ParkServer} (briefly) and
 * {@link dev.cutemod.data.ParkData} (the friendship).
 * <p>
 * A resident's id always starts with {@link #PREFIX}, which no player UUID does. The lines they say are the language keys
 * {@code cutemod.park.bot.<index>.<n>}: n = 0 after a play or a dance, 1-6 the answer to quick phrase 1-6, 7 and 8 idle
 * remarks, 9 thanks for a treat (the client builds the key from the number {@code 100 + index * 10 + n}).
 */
public final class ParkBots {
    private ParkBots() {}

    /** A resident: its id ("bot:..."), its name, the color of its species and how it looks (no name of its own, the park shows {@code name}). */
    public record Bot(String id, String name, String color, PetLook look) {}

    /** Where a resident is right now: {@code idleMs} is how long it has stood still, {@code seg} the number of its current errand. */
    public record Pos(int x, int y, boolean walking, long idleMs, long seg) {}

    public static final String PREFIX = "bot:";

    public static final List<Bot> ALL = List.of(
            new Bot("bot:mochi", "Mochi", "pink", new PetLook(2, 1, 900, "acc_bow", "acc_kimono", "", 0)),
            new Bot("bot:panko", "Panko", "white", new PetLook(1, 0, 400, "acc_sprout", "", "", 0)),
            new Bot("bot:waddle", "Waddle", "blue", new PetLook(2, 2, 1500, "acc_glasses+acc_hat", "acc_scarf", "", 1)),
            new Bot("bot:zippy", "Zippy", "yellow", new PetLook(1, 3, 300, "acc_flower", "acc_wings", "", 2)));

    /** One errand lasts this long: walk to a new spot, then stand there (at least 4 seconds). */
    private static final long SEG_MS = 9_000;
    /** Pixels per millisecond (a bit slower than the player's pet, so a player can always catch up). */
    private static final double SPEED = 0.03;
    private static final int X_MIN = 16, X_MAX = 284, Y_LO = 82, Y_HI = 146;
    private static final int BENCH_X = 136, BENCH_Y = 96, POND_X = 236, POND_Y = 142;

    /** The index of the resident with this id, or -1. */
    public static int index(String id) {
        for (int i = 0; i < ALL.size(); i++) if (ALL.get(i).id().equals(id)) return i;
        return -1;
    }

    private static int hash(int a, long b) {
        long h = a * 0x9E3779B97F4A7C15L + b * 0xC2B2AE3D27D4EB4FL;
        h ^= h >>> 29;
        h *= 0xBF58476D1CE4E5B9L;
        h ^= h >>> 32;
        return (int) (h & 0x7fffffff);
    }

    /** Where errand number {@code seg} of this resident leads: now and then the bench or the pond, otherwise a spot on the grass. */
    private static int[] waypoint(int bot, long seg) {
        int h = hash(bot * 31 + 7, seg);
        int pick = h % 7;
        if (pick == 0) return new int[]{BENCH_X - 8 + (h / 7) % 17, BENCH_Y};
        if (pick == 1) return new int[]{POND_X - 20 + (h / 7) % 41, POND_Y};
        return new int[]{X_MIN + (h / 7) % (X_MAX - X_MIN + 1), Y_LO + (h / 1999) % (Y_HI - Y_LO + 1)};
    }

    /** The position of resident {@code bot} at the time {@code now} (milliseconds). */
    public static Pos at(int bot, long now) {
        long t0 = now + bot * 4_100L;                           // every resident has its own rhythm
        long seg = Math.floorDiv(t0, SEG_MS);
        long t = t0 - seg * SEG_MS;
        int[] a = waypoint(bot, seg - 1), b = waypoint(bot, seg);
        double dist = Math.hypot(b[0] - a[0], b[1] - a[1]);
        double walkMs = Math.max(1, Math.min(SEG_MS - 4_000, dist / SPEED));
        double u = Math.min(1.0, t / walkMs);
        return new Pos((int) Math.round(a[0] + (b[0] - a[0]) * u), (int) Math.round(a[1] + (b[1] - a[1]) * u),
                u < 1.0, (long) Math.max(0, t - walkMs), seg);
    }

    /** The emote above a resident that has just arrived somewhere (0 none): sometimes it greets the world. */
    public static int emote(int bot, Pos p) {
        if (p.walking() || p.idleMs() > 3_000) return 0;
        int h = hash(bot + 101, p.seg());
        if (h % 3 != 0) return 0;
        return new int[]{1, 2, 4, 5, 6, 3}[(h / 3) % 6];
    }

    /** An idle remark while it stands (line 7 or 8), or 0. */
    public static int idleLine(int bot, Pos p) {
        if (p.walking() || p.idleMs() < 1_000 || p.idleMs() > 4_000) return 0;
        int h = hash(bot + 202, p.seg());
        return h % 4 == 0 ? 7 + (h / 4) % 2 : 0;
    }
}
