package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "block (or unblock) this player: their letters are refused". */
public record PostBlockPayload(String name, boolean block) implements CustomPacketPayload {
    public static final Type<PostBlockPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "post_block"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PostBlockPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(32), PostBlockPayload::name,
            ByteBufCodecs.BOOL, PostBlockPayload::block,
            PostBlockPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(PostBlockPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) PostServer.block(sp, p.name(), p.block()); });
    }
}
