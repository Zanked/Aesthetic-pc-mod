package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import dev.cutemod.data.PostData;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: your mailbox (newest first), the players you can write to, the ones you blocked, and the
 * answer to the last letter you sent (result: -1 none, 0 delivered, 1 no such player, 2 refused, 3 too fast,
 * 4 their mailbox is full, 5 invalid letter).
 */
public record PostSyncPayload(int result, List<Letter> inbox, List<String> players, List<String> blocked) implements CustomPacketPayload {
    public record Letter(long id, String from, String text, byte[] drawing, long sent) {}

    public static final Type<PostSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "post_sync"));

    private static final StreamCodec<ByteBuf, Letter> LETTER = StreamCodec.composite(
            ByteBufCodecs.VAR_LONG, Letter::id,
            ByteBufCodecs.stringUtf8(32), Letter::from,
            ByteBufCodecs.stringUtf8(PostData.MAX_TEXT * 2), Letter::text,
            ByteBufCodecs.byteArray(PostData.DRAWING_BYTES), Letter::drawing,
            ByteBufCodecs.VAR_LONG, Letter::sent,
            Letter::new);

    private static final StreamCodec<ByteBuf, String> NAME = ByteBufCodecs.stringUtf8(32);

    public static final StreamCodec<RegistryFriendlyByteBuf, PostSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, PostSyncPayload::result,
            LETTER.apply(ByteBufCodecs.list(PostData.MAX_BOX)), PostSyncPayload::inbox,
            NAME.apply(ByteBufCodecs.list(200)), PostSyncPayload::players,
            NAME.apply(ByteBufCodecs.list(100)), PostSyncPayload::blocked,
            PostSyncPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(PostSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onPostSync(p));
    }
}
