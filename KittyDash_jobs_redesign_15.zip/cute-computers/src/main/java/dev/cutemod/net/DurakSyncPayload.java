package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Server -> client: who is online (and free to play), the invitations, and the game you are in (if any).
 * You only get your own hand: of the other player you know how many cards there are.
 * notice: 0 nothing, 1 your invitation was declined, 2 that player is busy, 3 no such player, 4 your opponent left,
 * 5 the invitation ran out. result (for you): 0 playing, 1 you won, 2 you lost, 3 draw.
 * event: 0 nothing, 1 the round was beaten, 2 the defender took the cards. def: -1 = not beaten yet.
 */
public record DurakSyncPayload(int notice, List<String> players, String invitedBy, String invitedTo, String opponent,
                               boolean youAttack, boolean myTurn, List<Integer> hand, int oppCount, int deckCount,
                               int trumpCard, List<Integer> atk, List<Integer> def, int limit, int result, int event,
                               int seq) implements CustomPacketPayload {
    public static final Type<DurakSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "durak_sync"));

    private static final StreamCodec<io.netty.buffer.ByteBuf, List<String>> NAMES =
            ByteBufCodecs.stringUtf8(32).apply(ByteBufCodecs.list(100));
    private static final StreamCodec<io.netty.buffer.ByteBuf, List<Integer>> CARDS =
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(40));

    public static final StreamCodec<RegistryFriendlyByteBuf, DurakSyncPayload> STREAM_CODEC = StreamCodec.of((buf, p) -> {
        ByteBufCodecs.VAR_INT.encode(buf, p.notice());
        NAMES.encode(buf, p.players());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.invitedBy());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.invitedTo());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.opponent());
        ByteBufCodecs.BOOL.encode(buf, p.youAttack());
        ByteBufCodecs.BOOL.encode(buf, p.myTurn());
        CARDS.encode(buf, p.hand());
        ByteBufCodecs.VAR_INT.encode(buf, p.oppCount());
        ByteBufCodecs.VAR_INT.encode(buf, p.deckCount());
        ByteBufCodecs.VAR_INT.encode(buf, p.trumpCard());
        CARDS.encode(buf, p.atk());
        List<Integer> shifted = new ArrayList<>();
        for (int d : p.def()) shifted.add(d + 1);                  // -1 is stored as 0
        CARDS.encode(buf, shifted);
        ByteBufCodecs.VAR_INT.encode(buf, p.limit());
        ByteBufCodecs.VAR_INT.encode(buf, p.result());
        ByteBufCodecs.VAR_INT.encode(buf, p.event());
        ByteBufCodecs.VAR_INT.encode(buf, p.seq());
    }, buf -> {
        int notice = ByteBufCodecs.VAR_INT.decode(buf);
        List<String> players = NAMES.decode(buf);
        String by = ByteBufCodecs.stringUtf8(32).decode(buf);
        String to = ByteBufCodecs.stringUtf8(32).decode(buf);
        String opp = ByteBufCodecs.stringUtf8(32).decode(buf);
        boolean youAttack = ByteBufCodecs.BOOL.decode(buf);
        boolean myTurn = ByteBufCodecs.BOOL.decode(buf);
        List<Integer> hand = CARDS.decode(buf);
        int oppCount = ByteBufCodecs.VAR_INT.decode(buf);
        int deckCount = ByteBufCodecs.VAR_INT.decode(buf);
        int trump = ByteBufCodecs.VAR_INT.decode(buf);
        List<Integer> atk = CARDS.decode(buf);
        List<Integer> def = new ArrayList<>();
        for (int d : CARDS.decode(buf)) def.add(d - 1);
        int limit = ByteBufCodecs.VAR_INT.decode(buf);
        int result = ByteBufCodecs.VAR_INT.decode(buf);
        int event = ByteBufCodecs.VAR_INT.decode(buf);
        int seq = ByteBufCodecs.VAR_INT.decode(buf);
        return new DurakSyncPayload(notice, players, by, to, opp, youAttack, myTurn, hand, oppCount, deckCount, trump,
                atk, def, limit, result, event, seq);
    });

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(DurakSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onDurakSync(p));
    }
}
