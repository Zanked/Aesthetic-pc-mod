package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: do something with one pet of the show. kind 0 = take my own pet off the show, 1 = like it,
 * 2 = take the like back, 3 = give the golden flower of the audience. owner is the UUID (as text) of the pet's owner, color picks the pet.
 */
public record ShowActionPayload(int kind, String owner, String color) implements CustomPacketPayload {
    public static final int WITHDRAW = 0, LIKE = 1, UNLIKE = 2, FLOWER = 3;

    public static final Type<ShowActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "show_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ShowActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ShowActionPayload::kind,
            ByteBufCodecs.stringUtf8(36), ShowActionPayload::owner,
            ByteBufCodecs.stringUtf8(16), ShowActionPayload::color,
            ShowActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ShowActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) ShowServer.action(sp, p); });
    }
}
