package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.market.MarketServer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "give me the parcels that have arrived" (at the computer at pos). */
public record MarketPickupPayload(BlockPos pos) implements CustomPacketPayload {
    public static final Type<MarketPickupPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "market_pickup"));

    public static final StreamCodec<RegistryFriendlyByteBuf, MarketPickupPayload> STREAM_CODEC =
            StreamCodec.composite(BlockPos.STREAM_CODEC, MarketPickupPayload::pos, MarketPickupPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(MarketPickupPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) MarketServer.pickup(sp, payload.pos());
        });
    }
}
