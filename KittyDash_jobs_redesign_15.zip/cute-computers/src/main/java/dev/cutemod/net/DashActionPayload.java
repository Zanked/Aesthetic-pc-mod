package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: something the player did in online Kitty Dash.
 * action: 0 refresh (who is online, my race), 1 invite {@code name}, 2 accept the invitation of {@code name}, 3 decline it,
 * 4 progress (a = score, b = distance, c = lane x 100, d = flags: 1 hurt, 2 shield, 4 rocket, 8 in the air, 16 sliding),
 * 5 resign / leave the race, 6 cancel my invitation, 7 attack the opponent (a = kind: 1 barrier, 2 goo),
 * 8 my run is over (a = final score).
 */
public record DashActionPayload(int action, String name, int a, int b, int c, int d) implements CustomPacketPayload {
    public static final Type<DashActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "dash_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, DashActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, DashActionPayload::action,
            ByteBufCodecs.stringUtf8(32), DashActionPayload::name,
            ByteBufCodecs.VAR_INT, DashActionPayload::a,
            ByteBufCodecs.VAR_INT, DashActionPayload::b,
            ByteBufCodecs.VAR_INT, DashActionPayload::c,
            ByteBufCodecs.VAR_INT, DashActionPayload::d,
            DashActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(DashActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) DashServer.handle(sp, p); });
    }
}
