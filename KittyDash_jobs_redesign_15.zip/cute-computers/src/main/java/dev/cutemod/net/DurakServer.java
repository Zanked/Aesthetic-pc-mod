package dev.cutemod.net;

import dev.cutemod.data.DurakMatch;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * The server side of online Durak: the list of free players, invitations (they run out after a minute) and the games.
 * Games live in memory only. The rules are checked by {@link DurakMatch}; every player is sent only his own hand.
 */
public final class DurakServer {
    private DurakServer() {}

    private static final long INVITE_MS = 60_000L;
    private record Invite(UUID from, long until) {}

    private static final Map<UUID, DurakMatch> matches = new HashMap<>();
    private static final Map<UUID, Invite> invites = new HashMap<>();      // key = the player who was invited
    private static final Map<UUID, Long> lastRequest = new HashMap<>();
    private static final Random RND = new Random();
    private static MinecraftServer server;

    public static void handle(ServerPlayer sp, DurakActionPayload p) {
        server = sp.getServer();
        if (server == null) return;
        switch (p.action()) {
            case 0 -> request(sp);
            case 1 -> invite(sp, p.name());
            case 2 -> accept(sp, p.name());
            case 3 -> decline(sp, p.name());
            case 4, 5, 6, 7 -> play(sp, p);
            case 8 -> leaveGame(sp.getUUID());
            case 9 -> cancel(sp);
            default -> { }
        }
    }

    private static boolean playing(UUID id) {
        DurakMatch m = matches.get(id);
        return m != null && m.result == 0;
    }

    private static ServerPlayer online(UUID id) { return server == null ? null : server.getPlayerList().getPlayer(id); }

    private static String name(UUID id) {
        ServerPlayer p = online(id);
        return p == null ? "" : p.getGameProfile().getName();
    }

    private static Invite pending(UUID target) {
        Invite i = invites.get(target);
        if (i == null) return null;
        if (System.currentTimeMillis() > i.until()) {
            invites.remove(target);
            ServerPlayer from = online(i.from());
            if (from != null) push(from, 5);
            return null;
        }
        return i;
    }

    /** Sends a player the whole picture (and maybe one notice). */
    private static void push(ServerPlayer sp, int notice) {
        if (server == null) return;
        UUID me = sp.getUUID();
        List<String> free = new ArrayList<>();
        for (ServerPlayer o : server.getPlayerList().getPlayers()) {
            if (o.getUUID().equals(me) || playing(o.getUUID())) continue;
            free.add(o.getGameProfile().getName());
        }
        free.sort(String.CASE_INSENSITIVE_ORDER);
        String by = "", to = "";
        Invite in = pending(me);
        if (in != null) by = name(in.from());
        for (Map.Entry<UUID, Invite> e : new ArrayList<>(invites.entrySet())) {     // a copy: pending() may drop an old invitation
            if (e.getValue().from().equals(me) && pending(e.getKey()) != null) { to = name(e.getKey()); break; }
        }
        DurakMatch m = matches.get(me);
        String opp = "";
        boolean youAttack = false, myTurn = false;
        List<Integer> hand = new ArrayList<>(), atk = new ArrayList<>(), def = new ArrayList<>();
        int oppCount = 0, deckCount = 0, trumpCard = 0, limit = 0, result = 0, event = 0, seq = 0;
        if (m != null) {
            opp = name(m.other(me));
            if (opp.isEmpty()) opp = "?";
            youAttack = m.attacks(me);
            myTurn = m.myTurn(me);
            hand.addAll(m.hand(me));
            oppCount = m.hand(m.other(me)).size();
            deckCount = m.deck.size();
            trumpCard = m.trumpCard;
            for (int i = 0; i < m.n; i++) { atk.add(m.atk[i]); def.add(m.def[i]); }
            limit = m.limit;
            result = m.result == 0 ? 0 : m.result == 3 ? 3 : ((m.result == 1) == m.isA(me)) ? 1 : 2;
            event = m.lastEvent;
            seq = m.seq;
        }
        PacketDistributor.sendToPlayer(sp, new DurakSyncPayload(notice, free, by, to, opp, youAttack, myTurn, hand, oppCount,
                deckCount, trumpCard, atk, def, limit, result, event, seq));
    }

    private static void pushTo(UUID id, int notice) {
        ServerPlayer p = online(id);
        if (p != null) push(p, notice);
    }

    public static void request(ServerPlayer sp) {
        long now = System.currentTimeMillis();
        Long last = lastRequest.get(sp.getUUID());
        if (last != null && now - last < 500) return;
        lastRequest.put(sp.getUUID(), now);
        push(sp, 0);
    }

    private static void cancelFrom(UUID from) {
        List<UUID> targets = new ArrayList<>();
        for (Map.Entry<UUID, Invite> e : invites.entrySet()) if (e.getValue().from().equals(from)) targets.add(e.getKey());
        for (UUID t : targets) { invites.remove(t); pushTo(t, 0); }
    }

    public static void cancel(ServerPlayer sp) {
        cancelFrom(sp.getUUID());
        push(sp, 0);
    }

    private static void invite(ServerPlayer sp, String targetName) {
        ServerPlayer target = server.getPlayerList().getPlayerByName(targetName);
        if (target == null) { push(sp, 3); return; }
        if (target.getUUID().equals(sp.getUUID())) { push(sp, 0); return; }
        if (playing(sp.getUUID()) || playing(target.getUUID())) { push(sp, 2); return; }
        Invite back = pending(sp.getUUID());                              // they already invited us: this is a yes
        if (back != null && back.from().equals(target.getUUID())) { accept(sp, targetName); return; }
        Invite other = pending(target.getUUID());
        if (other != null && !other.from().equals(sp.getUUID())) { push(sp, 2); return; }
        cancelFrom(sp.getUUID());
        invites.put(target.getUUID(), new Invite(sp.getUUID(), System.currentTimeMillis() + INVITE_MS));
        target.displayClientMessage(Component.translatable("cutemod.durak.invite_msg", sp.getGameProfile().getName()), true);
        push(sp, 0);
        push(target, 0);
    }

    private static void accept(ServerPlayer sp, String fromName) {
        Invite in = pending(sp.getUUID());
        ServerPlayer from = in == null ? null : online(in.from());
        if (in == null || from == null || !from.getGameProfile().getName().equalsIgnoreCase(fromName)) { push(sp, 5); return; }
        if (playing(sp.getUUID()) || playing(from.getUUID())) { invites.remove(sp.getUUID()); push(sp, 2); return; }
        invites.remove(sp.getUUID());
        cancelFrom(from.getUUID());
        cancelFrom(sp.getUUID());
        DurakMatch m = RND.nextBoolean() ? new DurakMatch(from.getUUID(), sp.getUUID()) : new DurakMatch(sp.getUUID(), from.getUUID());
        matches.put(sp.getUUID(), m);
        matches.put(from.getUUID(), m);
        push(sp, 0);
        push(from, 0);
    }

    private static void decline(ServerPlayer sp, String fromName) {
        Invite in = pending(sp.getUUID());
        if (in != null) {
            invites.remove(sp.getUUID());
            pushTo(in.from(), 1);
        }
        push(sp, 0);
    }

    private static void play(ServerPlayer sp, DurakActionPayload p) {
        DurakMatch m = matches.get(sp.getUUID());
        if (m == null) { push(sp, 0); return; }
        UUID id = sp.getUUID();
        switch (p.action()) {
            case 4 -> { if (p.card() >= 0 && p.card() < 36) m.attack(id, p.card()); }
            case 5 -> { if (p.card() >= 0 && p.card() < 36) m.defend(id, p.card(), p.target()); }
            case 6 -> m.take(id);
            default -> m.done(id);
        }
        push(sp, 0);                                                       // also when the move was refused: the player sees the real table
        pushTo(m.other(id), 0);
    }

    /** The player gives up, finishes looking at a finished game, or has left the server. */
    public static void leaveGame(UUID id) {
        cancelFrom(id);
        invites.remove(id);
        DurakMatch m = matches.remove(id);
        if (m != null) {
            boolean wasPlaying = m.result == 0;
            m.resign(id);
            UUID other = m.other(id);
            if (matches.get(other) != m) matches.remove(other);           // nobody is left in it
            else pushTo(other, wasPlaying ? 4 : 0);
        }
        pushTo(id, 0);
    }

    public static void leave(UUID id) {
        leaveGame(id);
        lastRequest.remove(id);
    }
}
