package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.data.PlayerData;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "save this text under this name for me". The server only touches the sender's own data. */
public record SaveDataPayload(String name, String text) implements CustomPacketPayload {
    public static final Type<SaveDataPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "save"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SaveDataPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(48), SaveDataPayload::name,
            ByteBufCodecs.stringUtf8(PlayerData.MAX_CHARS), SaveDataPayload::text,
            SaveDataPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(SaveDataPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            var player = ctx.player();
            var server = player.getServer();
            if (server == null) return;
            PlayerData.get(server).put(player.getUUID(), payload.name(), payload.text());
        });
    }
}
