package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.data.PostData;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "send this letter (and this drawing, or none) to that player". */
public record PostSendPayload(String to, String text, byte[] drawing) implements CustomPacketPayload {
    public static final Type<PostSendPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "post_send"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PostSendPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(32), PostSendPayload::to,
            ByteBufCodecs.stringUtf8(PostData.MAX_TEXT * 2), PostSendPayload::text,
            ByteBufCodecs.byteArray(PostData.DRAWING_BYTES), PostSendPayload::drawing,
            PostSendPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(PostSendPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) PostServer.send(sp, p.to(), p.text(), p.drawing()); });
    }
}
