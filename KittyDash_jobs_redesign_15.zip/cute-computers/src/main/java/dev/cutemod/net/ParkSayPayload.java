package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.data.ParkData;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "my pet says quick phrase number {@code id}" (1 to {@link ParkData#SAY_COUNT}; a number, never free text). */
public record ParkSayPayload(int id) implements CustomPacketPayload {
    public static final Type<ParkSayPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "park_say"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ParkSayPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ParkSayPayload::id,
            ParkSayPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ParkSayPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) ParkServer.say(sp, p.id()); });
    }
}
