package dev.cutemod.net;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/**
 * What a pet looks like on the show and in the park: the growth stage (0-2), the character (0-4), its age in minutes and what it wears:
 * {@code head} is the list of the head and face layers, {@code body} the list of the body, outer and neck layers
 * (ids joined with '+', see PetWear.layers), {@code name} the name the player gave the pet (up to 12 characters, empty = none; only the park shows it),
 * {@code variant} the coat (0 = classic, 1-3 = other colors, see PetArt.VARIANTS).
 */
public record PetLook(int stage, int trait, int ageMin, String head, String body, String name, int variant) {
    /** A look in the classic coat. */
    public PetLook(int stage, int trait, int ageMin, String head, String body, String name) {
        this(stage, trait, ageMin, head, body, name, 0);
    }

    private static final StreamCodec<ByteBuf, String> HEAD = ByteBufCodecs.stringUtf8(64), NAME = ByteBufCodecs.stringUtf8(16);

    // seven fields do not fit StreamCodec.composite (it takes six), so the codec is written out
    public static final StreamCodec<ByteBuf, PetLook> CODEC = new StreamCodec<>() {
        @Override
        public PetLook decode(ByteBuf buf) {
            int stage = ByteBufCodecs.VAR_INT.decode(buf), trait = ByteBufCodecs.VAR_INT.decode(buf), age = ByteBufCodecs.VAR_INT.decode(buf);
            String head = HEAD.decode(buf), body = HEAD.decode(buf), name = NAME.decode(buf);
            return new PetLook(stage, trait, age, head, body, name, ByteBufCodecs.VAR_INT.decode(buf));
        }

        @Override
        public void encode(ByteBuf buf, PetLook l) {
            ByteBufCodecs.VAR_INT.encode(buf, l.stage());
            ByteBufCodecs.VAR_INT.encode(buf, l.trait());
            ByteBufCodecs.VAR_INT.encode(buf, l.ageMin());
            HEAD.encode(buf, l.head());
            HEAD.encode(buf, l.body());
            NAME.encode(buf, l.name());
            ByteBufCodecs.VAR_INT.encode(buf, l.variant());
        }
    };
}
