package dev.cutemod.net;

import net.minecraft.server.level.ServerPlayer;
import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server, the LIVE stream of CuteTube: action 0 = I am watching, 1 = I stopped, 2 = say this in the chat. */
public record StreamActionPayload(int action, String text) implements CustomPacketPayload {
    public static final Type<StreamActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "stream_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, StreamActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, StreamActionPayload::action,
            ByteBufCodecs.stringUtf8(StreamServer.MAX_TEXT * 2), StreamActionPayload::text,
            StreamActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(StreamActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) StreamServer.action(sp, p.action(), p.text()); });
    }
}
