package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: who is online (and free to play), the invitations, and the game you are in (if any).
 * notice: 0 nothing, 1 your invitation was declined, 2 that player is busy, 3 no such player, 4 your opponent left,
 * 5 the invitation ran out. result: 0 playing, 1 the first player won, 2 the second won, 3 draw.
 * The table is sent twice: {@code pre*} before the last shot plus the speed of the white ball ({@code shotVx/Vy}), so that
 * both clients can play the shot again with the same physics, and {@code post*} after it (the truth, the clients snap to it).
 * {@code shotSeq} is 0 while nobody has shot yet.
 */
public record BilliardsSyncPayload(int notice, List<String> players, String invitedBy, String invitedTo, String opponent,
                                   boolean youFirst, int turn, int score0, int score1, int result, int seq, int shotSeq,
                                   float[] preXy, int preMask, float shotVx, float shotVy, float[] postXy, int postMask)
        implements CustomPacketPayload {
    public static final Type<BilliardsSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "billiards_sync"));

    private static final StreamCodec<io.netty.buffer.ByteBuf, List<String>> NAMES =
            ByteBufCodecs.stringUtf8(32).apply(ByteBufCodecs.list(100));
    private static final int FLOATS = 22;

    private static void putFloats(io.netty.buffer.ByteBuf buf, float[] f) {
        for (int i = 0; i < FLOATS; i++) buf.writeFloat(i < f.length ? f[i] : 0f);
    }

    private static float[] getFloats(io.netty.buffer.ByteBuf buf) {
        float[] f = new float[FLOATS];
        for (int i = 0; i < FLOATS; i++) f[i] = buf.readFloat();
        return f;
    }

    public static final StreamCodec<RegistryFriendlyByteBuf, BilliardsSyncPayload> STREAM_CODEC = StreamCodec.of((buf, p) -> {
        ByteBufCodecs.VAR_INT.encode(buf, p.notice());
        NAMES.encode(buf, p.players());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.invitedBy());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.invitedTo());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.opponent());
        ByteBufCodecs.BOOL.encode(buf, p.youFirst());
        ByteBufCodecs.VAR_INT.encode(buf, p.turn());
        ByteBufCodecs.VAR_INT.encode(buf, p.score0());
        ByteBufCodecs.VAR_INT.encode(buf, p.score1());
        ByteBufCodecs.VAR_INT.encode(buf, p.result());
        ByteBufCodecs.VAR_INT.encode(buf, p.seq());
        ByteBufCodecs.VAR_INT.encode(buf, p.shotSeq());
        putFloats(buf, p.preXy());
        ByteBufCodecs.VAR_INT.encode(buf, p.preMask());
        buf.writeFloat(p.shotVx());
        buf.writeFloat(p.shotVy());
        putFloats(buf, p.postXy());
        ByteBufCodecs.VAR_INT.encode(buf, p.postMask());
    }, buf -> new BilliardsSyncPayload(
            ByteBufCodecs.VAR_INT.decode(buf),
            NAMES.decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.BOOL.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            getFloats(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            buf.readFloat(),
            buf.readFloat(),
            getFloats(buf),
            ByteBufCodecs.VAR_INT.decode(buf)));

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(BilliardsSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onBilliardsSync(p));
    }
}
