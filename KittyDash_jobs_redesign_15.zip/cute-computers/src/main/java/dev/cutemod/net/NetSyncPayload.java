package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import dev.cutemod.data.NetData;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/** Server -> client: the top of one game, your own place in it, and who is at a computer right now. */
public record NetSyncPayload(String game, List<NetData.Row> top, int myRank, int myScore, List<Online> online) implements CustomPacketPayload {
    public record Online(String name, int app, String game) {}

    public static final Type<NetSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "net_sync"));

    private static final StreamCodec<ByteBuf, NetData.Row> ROW = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(32), NetData.Row::name,
            ByteBufCodecs.VAR_INT, NetData.Row::score,
            NetData.Row::new);

    private static final StreamCodec<ByteBuf, Online> ONLINE = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(32), Online::name,
            ByteBufCodecs.VAR_INT, Online::app,
            ByteBufCodecs.stringUtf8(16), Online::game,
            Online::new);

    public static final StreamCodec<RegistryFriendlyByteBuf, NetSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(16), NetSyncPayload::game,
            ROW.apply(ByteBufCodecs.list(10)), NetSyncPayload::top,
            ByteBufCodecs.VAR_INT, NetSyncPayload::myRank,
            ByteBufCodecs.VAR_INT, NetSyncPayload::myScore,
            ONLINE.apply(ByteBufCodecs.list(40)), NetSyncPayload::online,
            NetSyncPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(NetSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onNetSync(p));
    }
}
