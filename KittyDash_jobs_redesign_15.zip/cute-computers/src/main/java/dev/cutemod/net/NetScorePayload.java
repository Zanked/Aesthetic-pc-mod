package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "I finished this game with this score" (CuteNet leaderboard). */
public record NetScorePayload(String game, int score) implements CustomPacketPayload {
    public static final Type<NetScorePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "net_score"));

    public static final StreamCodec<RegistryFriendlyByteBuf, NetScorePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(16), NetScorePayload::game,
            ByteBufCodecs.VAR_INT, NetScorePayload::score,
            NetScorePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(NetScorePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) NetServer.score(sp, p.game(), p.score()); });
    }
}
