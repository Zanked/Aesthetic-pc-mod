package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: who is online (and free to play), the invitations, and the game you are in (if any).
 * notice: 0 nothing, 1 your invitation was declined, 2 that player is busy, 3 no such player, 4 your opponent left,
 * 5 the invitation ran out. result: 0 playing, 1 white won, 2 black won, 3 draw.
 */
public record CheckersSyncPayload(int notice, List<String> players, String invitedBy, String invitedTo, String opponent,
                                  boolean youWhite, byte[] board, boolean whiteTurn, int lastFrom, int lastTo,
                                  int result, int seq) implements CustomPacketPayload {
    public static final Type<CheckersSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "checkers_sync"));

    private static final StreamCodec<io.netty.buffer.ByteBuf, List<String>> NAMES =
            ByteBufCodecs.stringUtf8(32).apply(ByteBufCodecs.list(100));

    public static final StreamCodec<RegistryFriendlyByteBuf, CheckersSyncPayload> STREAM_CODEC = StreamCodec.of((buf, p) -> {
        ByteBufCodecs.VAR_INT.encode(buf, p.notice());
        NAMES.encode(buf, p.players());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.invitedBy());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.invitedTo());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.opponent());
        ByteBufCodecs.BOOL.encode(buf, p.youWhite());
        ByteBufCodecs.byteArray(64).encode(buf, p.board());
        ByteBufCodecs.BOOL.encode(buf, p.whiteTurn());
        ByteBufCodecs.VAR_INT.encode(buf, p.lastFrom() + 1);      // -1 is stored as 0
        ByteBufCodecs.VAR_INT.encode(buf, p.lastTo() + 1);
        ByteBufCodecs.VAR_INT.encode(buf, p.result());
        ByteBufCodecs.VAR_INT.encode(buf, p.seq());
    }, buf -> new CheckersSyncPayload(
            ByteBufCodecs.VAR_INT.decode(buf),
            NAMES.decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.BOOL.decode(buf),
            ByteBufCodecs.byteArray(64).decode(buf),
            ByteBufCodecs.BOOL.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf) - 1,
            ByteBufCodecs.VAR_INT.decode(buf) - 1,
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf)));

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(CheckersSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onCheckersSync(p));
    }
}
