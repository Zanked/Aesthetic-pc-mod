package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.data.SeasonGifts;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.ChatFormatting;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.component.Unbreakable;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Client -> server: "I took this reward of the season pass on the computer, give me its item in the game".
 * The server knows the season and the item table itself, and remembers on the player what was already handed out,
 * so the same reward never comes twice (not even if the computer progress is reset).
 */
public record SeasonClaimPayload(int season, int level, boolean premium) implements CustomPacketPayload {
    public static final Type<SeasonClaimPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "season_claim"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SeasonClaimPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SeasonClaimPayload::season,
            ByteBufCodecs.VAR_INT, SeasonClaimPayload::level,
            ByteBufCodecs.BOOL, SeasonClaimPayload::premium,
            SeasonClaimPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(SeasonClaimPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) give(sp, p);
        });
    }

    private static void give(ServerPlayer sp, SeasonClaimPayload p) {
        if (p.season() != SeasonGifts.seasonNow()) return;                     // an old or invented season
        SeasonGifts.Gift gift = SeasonGifts.gift(p.level(), p.premium());
        if (gift == null) return;
        CompoundTag root = sp.getPersistentData();
        CompoundTag mine = root.getCompound("cutemod_season");
        String key = p.season() + "_" + p.level() + (p.premium() ? "p" : "f");
        if (mine.getBoolean(key)) return;                                      // already handed out
        ItemStack stack = create(gift, p.season());
        if (stack.isEmpty()) return;
        mine.putBoolean(key, true);
        root.put("cutemod_season", mine);
        if (!sp.getInventory().add(stack)) sp.drop(stack, false);              // a full inventory drops it at the feet
        sp.displayClientMessage(Component.translatable("cutemod.season.mc.got", stack.getHoverName()), true);
    }

    private static ItemStack create(SeasonGifts.Gift gift, int season) {
        if (!gift.unique()) {
            Item item = BuiltInRegistries.ITEM.get(ResourceLocation.withDefaultNamespace(gift.item()));
            return item == Items.AIR ? ItemStack.EMPTY : new ItemStack(item, Math.max(1, Math.min(64, gift.count())));
        }
        Item base = switch (gift.item()) {
            case "cute_charm" -> Items.HEART_OF_THE_SEA;
            case "cute_crown" -> Items.GOLDEN_HELMET;
            case "cute_pick" -> Items.GOLDEN_PICKAXE;
            default -> Items.NETHER_STAR;
        };
        ItemStack s = new ItemStack(base);
        s.set(DataComponents.CUSTOM_NAME, Component.translatable("cutemod.season.mc." + gift.item())
                .withStyle(style -> style.withItalic(false).withColor(ChatFormatting.LIGHT_PURPLE)));
        s.set(DataComponents.LORE, new ItemLore(List.of(
                Component.translatable("cutemod.season.mc.lore", season + 1).withStyle(style -> style.withItalic(false).withColor(ChatFormatting.GOLD)),
                Component.translatable("cutemod.season.mc.lore2").withStyle(style -> style.withItalic(false).withColor(ChatFormatting.GRAY)))));
        s.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
        if (base == Items.GOLDEN_HELMET || base == Items.GOLDEN_PICKAXE) s.set(DataComponents.UNBREAKABLE, new Unbreakable(true));
        return s;
    }
}
