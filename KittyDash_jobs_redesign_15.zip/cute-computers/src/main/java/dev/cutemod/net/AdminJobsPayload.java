package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client: an operator opened all jobs for this player ({@code /cutejobs unlock}). */
public record AdminJobsPayload() implements CustomPacketPayload {
    public static final Type<AdminJobsPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "admin_jobs"));

    public static final StreamCodec<RegistryFriendlyByteBuf, AdminJobsPayload> STREAM_CODEC =
            StreamCodec.unit(new AdminJobsPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(AdminJobsPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(ClientHooks::onAdminJobs);
    }
}
