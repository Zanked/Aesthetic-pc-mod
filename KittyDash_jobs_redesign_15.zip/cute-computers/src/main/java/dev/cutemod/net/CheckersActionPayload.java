package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Client -> server: something the player did in online checkers.
 * action: 0 refresh (who is online, my game), 1 invite {@code name}, 2 accept the invitation of {@code name}, 3 decline it,
 * 4 move (from, to = the landing squares), 5 resign / leave the game, 6 cancel my invitation.
 */
public record CheckersActionPayload(int action, String name, int from, List<Integer> to) implements CustomPacketPayload {
    public static final Type<CheckersActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "checkers_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, CheckersActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, CheckersActionPayload::action,
            ByteBufCodecs.stringUtf8(32), CheckersActionPayload::name,
            ByteBufCodecs.VAR_INT, CheckersActionPayload::from,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(16)), CheckersActionPayload::to,
            CheckersActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(CheckersActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) CheckersServer.handle(sp, p); });
    }
}
