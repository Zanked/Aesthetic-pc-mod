package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.block.ComputerBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "I finished a game with this score on the computer at pos". */
public record ScorePayload(BlockPos pos, int score) implements CustomPacketPayload {
    public static final Type<ScorePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "score"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ScorePayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, ScorePayload::pos,
            ByteBufCodecs.VAR_INT, ScorePayload::score,
            ScorePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ScorePayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            Player player = ctx.player();
            if (player.distanceToSqr(payload.pos().getCenter()) > 100) return; // too far away
            if (player.level().getBlockEntity(payload.pos()) instanceof ComputerBlockEntity be) {
                if (be.submitScore(payload.score(), player.getGameProfile().getName())) {
                    player.displayClientMessage(
                            Component.translatable("cutemod.new_record", payload.score()), true);
                }
            }
        });
    }
}
