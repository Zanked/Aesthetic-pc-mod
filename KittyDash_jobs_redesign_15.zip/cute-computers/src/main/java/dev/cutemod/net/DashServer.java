package dev.cutemod.net;

import dev.cutemod.data.DashMatch;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * The server side of online Kitty Dash: the list of free players, invitations (they run out after a minute) and the races.
 * Races live in memory only. The numbers of a race are kept and checked in {@link DashMatch}; the server hands them to the other player.
 */
public final class DashServer {
    private DashServer() {}

    private static final long INVITE_MS = 60_000L;
    private record Invite(UUID from, long until) {}

    private static final Map<UUID, DashMatch> matches = new HashMap<>();
    private static final Map<UUID, Invite> invites = new HashMap<>();      // key = the player who was invited
    private static final Map<UUID, Long> lastRequest = new HashMap<>();
    private static final Random RND = new Random();
    private static MinecraftServer server;

    public static void handle(ServerPlayer sp, DashActionPayload p) {
        server = sp.getServer();
        if (server == null) return;
        switch (p.action()) {
            case 0 -> request(sp);
            case 1 -> invite(sp, p.name());
            case 2 -> accept(sp, p.name());
            case 3 -> decline(sp);
            case 4 -> progress(sp, p.a(), p.b(), p.c(), p.d());
            case 5 -> leaveGame(sp.getUUID());
            case 6 -> cancel(sp);
            case 7 -> attack(sp, p.a());
            case 8 -> finish(sp, p.a());
            default -> { }
        }
    }

    private static boolean playing(UUID id) {
        DashMatch m = matches.get(id);
        return m != null && m.result == 0;
    }

    private static ServerPlayer online(UUID id) { return server == null ? null : server.getPlayerList().getPlayer(id); }

    private static String name(UUID id) {
        ServerPlayer p = online(id);
        return p == null ? "" : p.getGameProfile().getName();
    }

    private static Invite pending(UUID target) {
        Invite i = invites.get(target);
        if (i == null) return null;
        if (System.currentTimeMillis() > i.until()) {
            invites.remove(target);
            ServerPlayer from = online(i.from());
            if (from != null) push(from, 5, true);
            return null;
        }
        return i;
    }

    /** Sends a player the picture: the race they are in, and with {@code lobby} also the players and invitations (and maybe one notice). */
    private static void push(ServerPlayer sp, int notice, boolean lobby) {
        if (server == null) return;
        List<String> free = new ArrayList<>();
        String by = "", to = "";
        if (lobby) {
            for (ServerPlayer o : server.getPlayerList().getPlayers()) {
                if (o.getUUID().equals(sp.getUUID()) || playing(o.getUUID())) continue;
                free.add(o.getGameProfile().getName());
            }
            free.sort(String.CASE_INSENSITIVE_ORDER);
            Invite in = pending(sp.getUUID());
            if (in != null) by = name(in.from());
            for (Map.Entry<UUID, Invite> e : new ArrayList<>(invites.entrySet())) {     // a copy: pending() may drop an old invitation
                if (e.getValue().from().equals(sp.getUUID()) && pending(e.getKey()) != null) { to = name(e.getKey()); break; }
            }
        }
        DashMatch m = matches.get(sp.getUUID());
        String opp = "";
        boolean first = true, oppDone = false;
        int seed = 0, result = 0, os = 0, od = 0, ol = 0, of = 0, ofin = 0, aSeq = 0, aKind = 0;
        if (m != null) {
            int me = m.indexOf(sp.getUUID()), ot = 1 - me;
            opp = name(m.id[ot]);
            if (opp.isEmpty()) opp = "?";
            first = me == 0;
            seed = m.seed;
            result = m.result;
            os = m.score[ot];
            od = m.dist[ot];
            ol = m.lane[ot];
            of = m.flags[ot];
            oppDone = m.done[ot];
            ofin = m.finalScore[ot];
            aSeq = m.atkSeq[me];
            aKind = m.atkKind[me];
        }
        PacketDistributor.sendToPlayer(sp, new DashSyncPayload(notice, lobby, free, by, to, opp, first, seed, result, os, od, ol, of, oppDone, ofin, aSeq, aKind));
    }

    private static void pushTo(UUID id, int notice, boolean lobby) {
        ServerPlayer p = online(id);
        if (p != null) push(p, notice, lobby);
    }

    private static void pushBoth(DashMatch m, int notice) {
        pushTo(m.id[0], notice, false);
        pushTo(m.id[1], notice, false);
    }

    public static void request(ServerPlayer sp) {
        long now = System.currentTimeMillis();
        Long last = lastRequest.get(sp.getUUID());
        if (last != null && now - last < 500) return;
        lastRequest.put(sp.getUUID(), now);
        DashMatch m = matches.get(sp.getUUID());
        if (m != null && m.checkStale(now)) pushTo(m.other(sp.getUUID()), 0, false);   // the opponent has gone: this player now wins
        push(sp, 0, true);
    }

    private static void cancelFrom(UUID from) {
        List<UUID> targets = new ArrayList<>();
        for (Map.Entry<UUID, Invite> e : invites.entrySet()) if (e.getValue().from().equals(from)) targets.add(e.getKey());
        for (UUID t : targets) { invites.remove(t); pushTo(t, 0, true); }
    }

    public static void cancel(ServerPlayer sp) {
        cancelFrom(sp.getUUID());
        push(sp, 0, true);
    }

    private static void invite(ServerPlayer sp, String targetName) {
        ServerPlayer target = server.getPlayerList().getPlayerByName(targetName);
        if (target == null) { push(sp, 3, true); return; }
        if (target.getUUID().equals(sp.getUUID())) { push(sp, 0, true); return; }
        if (playing(sp.getUUID()) || playing(target.getUUID())) { push(sp, 2, true); return; }
        Invite back = pending(sp.getUUID());                              // they already invited us: this is a yes
        if (back != null && back.from().equals(target.getUUID())) { accept(sp, targetName); return; }
        Invite other = pending(target.getUUID());
        if (other != null && !other.from().equals(sp.getUUID())) { push(sp, 2, true); return; }
        cancelFrom(sp.getUUID());
        invites.put(target.getUUID(), new Invite(sp.getUUID(), System.currentTimeMillis() + INVITE_MS));
        target.displayClientMessage(Component.translatable("cutemod.dash.invite_msg", sp.getGameProfile().getName()), true);
        push(sp, 0, true);
        push(target, 0, true);
    }

    private static void accept(ServerPlayer sp, String fromName) {
        Invite in = pending(sp.getUUID());
        ServerPlayer from = in == null ? null : online(in.from());
        if (in == null || from == null || !from.getGameProfile().getName().equalsIgnoreCase(fromName)) { push(sp, 5, true); return; }
        if (playing(sp.getUUID()) || playing(from.getUUID())) { invites.remove(sp.getUUID()); push(sp, 2, true); return; }
        invites.remove(sp.getUUID());
        cancelFrom(from.getUUID());
        cancelFrom(sp.getUUID());
        boolean fromFirst = RND.nextBoolean();
        DashMatch m = fromFirst ? new DashMatch(from.getUUID(), sp.getUUID(), RND.nextInt(), System.currentTimeMillis())
                : new DashMatch(sp.getUUID(), from.getUUID(), RND.nextInt(), System.currentTimeMillis());
        matches.put(sp.getUUID(), m);
        matches.put(from.getUUID(), m);
        push(sp, 0, true);
        push(from, 0, true);
    }

    private static void decline(ServerPlayer sp) {
        Invite in = pending(sp.getUUID());
        if (in != null) {
            invites.remove(sp.getUUID());
            pushTo(in.from(), 1, true);
        }
        push(sp, 0, true);
    }

    private static void progress(ServerPlayer sp, int score, int dist, int lane, int flags) {
        DashMatch m = matches.get(sp.getUUID());
        if (m == null || m.result != 0) return;
        long now = System.currentTimeMillis();
        int me = m.indexOf(sp.getUUID());
        if (m.checkStale(now)) { pushBoth(m, 0); return; }
        if (!m.progress(me, now, score, dist, lane, flags)) return;
        pushTo(m.id[1 - me], 0, false);
    }

    private static void attack(ServerPlayer sp, int kind) {
        DashMatch m = matches.get(sp.getUUID());
        if (m == null) return;
        int me = m.indexOf(sp.getUUID());
        if (m.attack(me, kind, System.currentTimeMillis())) pushTo(m.id[1 - me], 0, false);
    }

    private static void finish(ServerPlayer sp, int score) {
        DashMatch m = matches.get(sp.getUUID());
        if (m == null) { push(sp, 0, true); return; }
        m.finish(m.indexOf(sp.getUUID()), score, System.currentTimeMillis());
        pushBoth(m, 0);
    }

    /** The player gives up, finishes looking at a finished race, or has left the server. */
    public static void leaveGame(UUID id) {
        cancelFrom(id);
        invites.remove(id);
        DashMatch m = matches.remove(id);
        if (m != null) {
            boolean wasPlaying = m.result == 0;
            m.resign(id);
            UUID other = m.other(id);
            if (matches.get(other) == m) pushTo(other, wasPlaying ? 4 : 0, false);
        }
        pushTo(id, 0, true);
    }

    public static void leave(UUID id) {
        leaveGame(id);
        lastRequest.remove(id);
    }
}
