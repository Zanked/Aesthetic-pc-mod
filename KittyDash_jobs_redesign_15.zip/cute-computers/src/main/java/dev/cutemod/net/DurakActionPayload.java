package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: something the player did in online Durak.
 * action: 0 refresh (who is online, my game), 1 invite {@code name}, 2 accept the invitation of {@code name}, 3 decline it,
 * 4 attack with {@code card}, 5 defend with {@code card} the card number {@code target} of the table, 6 take the cards,
 * 7 done (the round is beaten), 8 resign / leave the game, 9 cancel my invitation.
 */
public record DurakActionPayload(int action, String name, int card, int target) implements CustomPacketPayload {
    public static final Type<DurakActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "durak_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, DurakActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, DurakActionPayload::action,
            ByteBufCodecs.stringUtf8(32), DurakActionPayload::name,
            ByteBufCodecs.VAR_INT, DurakActionPayload::card,
            ByteBufCodecs.VAR_INT, DurakActionPayload::target,
            DurakActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(DurakActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) DurakServer.handle(sp, p); });
    }
}
