package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client: an operator changed this player's coins ({@code /cutecoins}). set = replace, otherwise add (may be negative). */
public record AdminCoinsPayload(boolean set, int amount) implements CustomPacketPayload {
    public static final Type<AdminCoinsPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "admin_coins"));

    public static final StreamCodec<RegistryFriendlyByteBuf, AdminCoinsPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, AdminCoinsPayload::set,
            ByteBufCodecs.VAR_INT, AdminCoinsPayload::amount,
            AdminCoinsPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(AdminCoinsPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onAdminCoins(payload));
    }
}
