package dev.cutemod.net;

import dev.cutemod.client.ClientHooks;
import dev.cutemod.data.TubeData;
import io.netty.buffer.ByteBuf;
import java.util.List;
import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Server -> client: the newest videos of the community (with the first picture of each as a thumbnail) and, if a
 * video is open, all its pictures and comments. result: -1 nothing, 0 published, 1 too fast, 2 you have too many
 * videos, 3 invalid video, 4 comment too fast, 5 no such video.
 */
public record TubeSyncPayload(int result, long openId, List<Entry> list, List<byte[]> frames, List<Comm> comments) implements CustomPacketPayload {
    public record Entry(long id, String author, String title, int fps, int tune, int frameCount, int likes, boolean liked,
                        boolean mine, int comments, byte[] thumb) {}

    public record Comm(String name, String text) {}

    public static final Type<TubeSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "tube_sync"));

    private static final StreamCodec<ByteBuf, String> NAME = ByteBufCodecs.stringUtf8(32);

    private static final StreamCodec<ByteBuf, Entry> ENTRY = StreamCodec.of(
            (buf, e) -> {
                buf.writeLong(e.id());
                NAME.encode(buf, e.author());
                NAME.encode(buf, e.title());
                buf.writeByte(e.fps());
                buf.writeByte(e.tune());
                buf.writeByte(e.frameCount());
                buf.writeInt(e.likes());
                buf.writeBoolean(e.liked());
                buf.writeBoolean(e.mine());
                buf.writeShort(e.comments());
                ByteBufCodecs.byteArray(TubeData.FRAME_BYTES).encode(buf, e.thumb());
            },
            buf -> new Entry(buf.readLong(), NAME.decode(buf), NAME.decode(buf), buf.readByte(), buf.readByte(), buf.readByte(),
                    buf.readInt(), buf.readBoolean(), buf.readBoolean(), buf.readShort(),
                    ByteBufCodecs.byteArray(TubeData.FRAME_BYTES).decode(buf)));

    private static final StreamCodec<ByteBuf, Comm> COMM = StreamCodec.composite(
            NAME, Comm::name,
            ByteBufCodecs.stringUtf8(TubeData.MAX_COMMENT * 2), Comm::text,
            Comm::new);

    public static final StreamCodec<RegistryFriendlyByteBuf, TubeSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, TubeSyncPayload::result,
            ByteBufCodecs.VAR_LONG, TubeSyncPayload::openId,
            ENTRY.apply(ByteBufCodecs.list(40)), TubeSyncPayload::list,
            ByteBufCodecs.byteArray(TubeData.FRAME_BYTES).apply(ByteBufCodecs.list(TubeData.MAX_FRAMES)), TubeSyncPayload::frames,
            COMM.apply(ByteBufCodecs.list(TubeData.MAX_COMMENTS)), TubeSyncPayload::comments,
            TubeSyncPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(TubeSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onTubeSync(p));
    }
}
