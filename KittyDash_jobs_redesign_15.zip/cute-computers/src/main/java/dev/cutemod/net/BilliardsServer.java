package dev.cutemod.net;

import dev.cutemod.data.BilliardsMatch;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * The server side of online billiards: the list of free players, invitations (they run out after a minute) and the games.
 * Games live in memory only. The rules and the physics are in {@link BilliardsMatch}: the server plays every shot itself, so nobody can cheat.
 */
public final class BilliardsServer {
    private BilliardsServer() {}

    private static final long INVITE_MS = 60_000L;
    private record Invite(UUID from, long until) {}

    private static final Map<UUID, BilliardsMatch> matches = new HashMap<>();
    private static final Map<UUID, Invite> invites = new HashMap<>();      // key = the player who was invited
    private static final Map<UUID, Long> lastRequest = new HashMap<>();
    private static final Random RND = new Random();
    private static MinecraftServer server;

    public static void handle(ServerPlayer sp, BilliardsActionPayload p) {
        server = sp.getServer();
        if (server == null) return;
        switch (p.action()) {
            case 0 -> request(sp);
            case 1 -> invite(sp, p.name());
            case 2 -> accept(sp, p.name());
            case 3 -> decline(sp, p.name());
            case 4 -> shoot(sp, p.dx(), p.dy(), p.power());
            case 5 -> leaveGame(sp.getUUID());
            case 6 -> cancel(sp);
            default -> { }
        }
    }

    private static boolean playing(UUID id) {
        BilliardsMatch m = matches.get(id);
        return m != null && m.result == 0;
    }

    private static ServerPlayer online(UUID id) { return server == null ? null : server.getPlayerList().getPlayer(id); }

    private static String name(UUID id) {
        ServerPlayer p = online(id);
        return p == null ? "" : p.getGameProfile().getName();
    }

    private static Invite pending(UUID target) {
        Invite i = invites.get(target);
        if (i == null) return null;
        if (System.currentTimeMillis() > i.until()) {
            invites.remove(target);
            ServerPlayer from = online(i.from());
            if (from != null) push(from, 5);
            return null;
        }
        return i;
    }

    /** Sends a player the whole picture (and maybe one notice). */
    private static void push(ServerPlayer sp, int notice) {
        if (server == null) return;
        List<String> free = new ArrayList<>();
        for (ServerPlayer o : server.getPlayerList().getPlayers()) {
            if (o.getUUID().equals(sp.getUUID()) || playing(o.getUUID())) continue;
            free.add(o.getGameProfile().getName());
        }
        free.sort(String.CASE_INSENSITIVE_ORDER);
        String by = "", to = "";
        Invite in = pending(sp.getUUID());
        if (in != null) by = name(in.from());
        for (Map.Entry<UUID, Invite> e : new ArrayList<>(invites.entrySet())) {     // a copy: pending() may drop an old invitation
            if (e.getValue().from().equals(sp.getUUID()) && pending(e.getKey()) != null) { to = name(e.getKey()); break; }
        }
        BilliardsMatch m = matches.get(sp.getUUID());
        String opp = "";
        boolean first = true;
        int turn = 0, s0 = 0, s1 = 0, result = 0, seq = 0, shotSeq = 0, preMask = 0, postMask = 0;
        float[] pre = new float[22], post = new float[22];
        float svx = 0, svy = 0;
        if (m != null) {
            opp = name(m.other(sp.getUUID()));
            if (opp.isEmpty()) opp = "?";
            first = m.indexOf(sp.getUUID()) == 0;
            turn = m.turn;
            s0 = m.score[0];
            s1 = m.score[1];
            result = m.result;
            seq = m.seq;
            shotSeq = m.shotSeq;
            pre = m.preXy;
            preMask = m.preMask;
            svx = m.shotVx;
            svy = m.shotVy;
            post = m.table.positions();
            postMask = m.table.aliveMask();
        }
        PacketDistributor.sendToPlayer(sp, new BilliardsSyncPayload(notice, free, by, to, opp, first, turn, s0, s1, result, seq, shotSeq, pre, preMask, svx, svy, post, postMask));
    }

    private static void pushTo(UUID id, int notice) {
        ServerPlayer p = online(id);
        if (p != null) push(p, notice);
    }

    public static void request(ServerPlayer sp) {
        long now = System.currentTimeMillis();
        Long last = lastRequest.get(sp.getUUID());
        if (last != null && now - last < 500) return;
        lastRequest.put(sp.getUUID(), now);
        push(sp, 0);
    }

    private static void cancelFrom(UUID from) {
        List<UUID> targets = new ArrayList<>();
        for (Map.Entry<UUID, Invite> e : invites.entrySet()) if (e.getValue().from().equals(from)) targets.add(e.getKey());
        for (UUID t : targets) { invites.remove(t); pushTo(t, 0); }
    }

    public static void cancel(ServerPlayer sp) {
        cancelFrom(sp.getUUID());
        push(sp, 0);
    }

    private static void invite(ServerPlayer sp, String targetName) {
        ServerPlayer target = server.getPlayerList().getPlayerByName(targetName);
        if (target == null) { push(sp, 3); return; }
        if (target.getUUID().equals(sp.getUUID())) { push(sp, 0); return; }
        if (playing(sp.getUUID()) || playing(target.getUUID())) { push(sp, 2); return; }
        Invite back = pending(sp.getUUID());                              // they already invited us: this is a yes
        if (back != null && back.from().equals(target.getUUID())) { accept(sp, targetName); return; }
        Invite other = pending(target.getUUID());
        if (other != null && !other.from().equals(sp.getUUID())) { push(sp, 2); return; }
        cancelFrom(sp.getUUID());
        invites.put(target.getUUID(), new Invite(sp.getUUID(), System.currentTimeMillis() + INVITE_MS));
        target.displayClientMessage(Component.translatable("cutemod.billiards.invite_msg", sp.getGameProfile().getName()), true);
        push(sp, 0);
        push(target, 0);
    }

    private static void accept(ServerPlayer sp, String fromName) {
        Invite in = pending(sp.getUUID());
        ServerPlayer from = in == null ? null : online(in.from());
        if (in == null || from == null || !from.getGameProfile().getName().equalsIgnoreCase(fromName)) { push(sp, 5); return; }
        if (playing(sp.getUUID()) || playing(from.getUUID())) { invites.remove(sp.getUUID()); push(sp, 2); return; }
        invites.remove(sp.getUUID());
        cancelFrom(from.getUUID());
        cancelFrom(sp.getUUID());
        boolean fromFirst = RND.nextBoolean();                            // who breaks is drawn by lot
        BilliardsMatch m = fromFirst ? new BilliardsMatch(from.getUUID(), sp.getUUID()) : new BilliardsMatch(sp.getUUID(), from.getUUID());
        matches.put(sp.getUUID(), m);
        matches.put(from.getUUID(), m);
        push(sp, 0);
        push(from, 0);
    }

    private static void decline(ServerPlayer sp, String fromName) {
        Invite in = pending(sp.getUUID());
        if (in != null) {
            invites.remove(sp.getUUID());
            pushTo(in.from(), 1);
        }
        push(sp, 0);
    }

    private static void shoot(ServerPlayer sp, float dx, float dy, float power) {
        BilliardsMatch m = matches.get(sp.getUUID());
        if (m == null) { push(sp, 0); return; }
        m.shoot(m.indexOf(sp.getUUID()), dx, dy, power);                  // refused if it is not their turn or the numbers are bad
        push(sp, 0);                                                       // also when the shot was refused: the player sees the real table
        pushTo(m.other(sp.getUUID()), 0);
    }

    /** The player gives up, finishes looking at a finished game, or has left the server. */
    public static void leaveGame(UUID id) {
        cancelFrom(id);
        invites.remove(id);
        BilliardsMatch m = matches.remove(id);
        if (m != null) {
            boolean wasPlaying = m.result == 0;
            m.resign(id);
            UUID other = m.other(id);
            if (matches.get(other) != m) matches.remove(other);           // nobody is left in it
            else pushTo(other, wasPlaying ? 4 : 0);
        }
        pushTo(id, 0);
    }

    public static void leave(UUID id) {
        leaveGame(id);
        lastRequest.remove(id);
    }
}
