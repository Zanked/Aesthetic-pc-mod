package dev.cutemod.net;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.cutemod.data.PlayerData;
import dev.cutemod.data.PostData;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Properties;
import java.util.UUID;

/**
 * Operator command (permission level 2) for CuteJobs:
 * <pre>
 * /cutejobs unlock            - open all jobs for yourself
 * /cutejobs unlock &lt;player&gt;   - open all jobs for a player
 * </pre>
 * "Open all jobs" = the top rank (so every job is available) and every cooldown cleared.
 * An online player's computer updates at once; an offline player (one the server has seen before) has the
 * saved data edited directly and sees it on the next login.
 */
public final class JobsCommand {
    /** Experience of the top rank (the last entry of Jobs.RANK_XP). */
    private static final int TOP_XP = 55;

    private JobsCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("cutejobs").requires(s -> s.hasPermission(2))
                .then(Commands.literal("unlock")
                        .executes(ctx -> {
                            CommandSourceStack src = ctx.getSource();
                            ServerPlayer self = src.getPlayerOrException();
                            return unlock(src, self.getGameProfile().getName(), self.getUUID());
                        })
                        .then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> {
                            CommandSourceStack src = ctx.getSource();
                            String name = StringArgumentType.getString(ctx, "player");
                            UUID id = resolve(src.getServer(), name);
                            if (id == null) {
                                src.sendFailure(Component.translatable("cutemod.post.cmd.unknown", name));
                                return 0;
                            }
                            return unlock(src, name, id);
                        }))));
    }

    private static int unlock(CommandSourceStack src, String name, UUID id) {
        MinecraftServer server = src.getServer();
        ServerPlayer online = server.getPlayerList().getPlayer(id);
        if (online != null) {
            PacketDistributor.sendToPlayer(online, new AdminJobsPayload());
        } else {
            unlockSaved(server, id);
        }
        src.sendSuccess(() -> Component.translatable("cutemod.jobs.cmd.unlock", name), true);
        return 1;
    }

    /** Edits the saved "jobs" data of an offline player. */
    private static void unlockSaved(MinecraftServer server, UUID id) {
        Properties p = new Properties();
        String text = PlayerData.get(server).copyOf(id).get("jobs");
        if (text != null) {
            try { p.load(new StringReader(text)); } catch (Exception ignored) { }
        }
        int xp = 0;
        try { xp = Integer.parseInt(p.getProperty("xp", "0").trim()); } catch (Exception ignored) { }
        p.setProperty("xp", Integer.toString(Math.max(xp, TOP_XP)));
        p.setProperty("gate", "0");
        for (String k : p.stringPropertyNames()) if (k.startsWith("until.")) p.remove(k);
        try {
            StringWriter w = new StringWriter();
            p.store(w, null);
            StringBuilder sb = new StringBuilder();
            for (String line : w.toString().split("\\R")) if (!line.startsWith("#")) sb.append(line).append('\n');
            PlayerData.get(server).put(id, "jobs", sb.toString());
        } catch (Exception ignored) { }
    }

    private static UUID resolve(MinecraftServer server, String name) {
        ServerPlayer online = server.getPlayerList().getPlayerByName(name);
        if (online != null) return online.getUUID();
        return PostData.get(server).findByName(name);
    }
}
