package dev.cutemod.net;

import dev.cutemod.client.ClientHooks;
import io.netty.buffer.ByteBuf;
import java.util.List;
import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client: how many players watch the stream, and new chat messages (the last ones when you join). */
public record StreamSyncPayload(int viewers, List<Msg> msgs) implements CustomPacketPayload {
    public record Msg(String name, String text) {}

    public static final Type<StreamSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "stream_sync"));

    private static final StreamCodec<ByteBuf, Msg> MSG = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(32), Msg::name,
            ByteBufCodecs.stringUtf8(StreamServer.MAX_TEXT * 2), Msg::text,
            Msg::new);

    public static final StreamCodec<RegistryFriendlyByteBuf, StreamSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, StreamSyncPayload::viewers,
            MSG.apply(ByteBufCodecs.list(60)), StreamSyncPayload::msgs,
            StreamSyncPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(StreamSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onStreamSync(p));
    }
}
