package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.market.MarketServer;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/** Client -> server: "order this food at the computer at pos". The server checks everything. */
public record MarketOrderPayload(BlockPos pos, List<Entry> items, boolean express) implements CustomPacketPayload {
    public record Entry(String id, int qty) {}

    public static final Type<MarketOrderPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "market_order"));

    private static final StreamCodec<ByteBuf, Entry> ENTRY = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(24), Entry::id,
            ByteBufCodecs.VAR_INT, Entry::qty,
            Entry::new);

    public static final StreamCodec<RegistryFriendlyByteBuf, MarketOrderPayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, MarketOrderPayload::pos,
            ENTRY.apply(ByteBufCodecs.list(MarketServer.MAX_LINES)), MarketOrderPayload::items,
            ByteBufCodecs.BOOL, MarketOrderPayload::express,
            MarketOrderPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(MarketOrderPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) MarketServer.order(sp, payload.pos(), payload.items(), payload.express());
        });
    }
}
