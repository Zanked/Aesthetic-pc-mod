package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "my computer screen is open (or closed) and I am in this app / game". Sent every few seconds. */
public record NetPingPayload(boolean open, int app, String game) implements CustomPacketPayload {
    public static final Type<NetPingPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "net_ping"));

    public static final StreamCodec<RegistryFriendlyByteBuf, NetPingPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, NetPingPayload::open,
            ByteBufCodecs.VAR_INT, NetPingPayload::app,
            ByteBufCodecs.stringUtf8(16), NetPingPayload::game,
            NetPingPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(NetPingPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) NetServer.ping(sp, p.open(), p.app(), p.game()); });
    }
}
