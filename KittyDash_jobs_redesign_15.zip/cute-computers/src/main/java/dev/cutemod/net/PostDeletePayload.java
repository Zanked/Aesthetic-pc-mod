package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "delete this letter from my mailbox". */
public record PostDeletePayload(long id) implements CustomPacketPayload {
    public static final Type<PostDeletePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "post_delete"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PostDeletePayload> STREAM_CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_LONG, PostDeletePayload::id, PostDeletePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(PostDeletePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) PostServer.delete(sp, p.id()); });
    }
}
