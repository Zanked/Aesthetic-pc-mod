package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: something the player did in online billiards.
 * action: 0 refresh (who is online, my game), 1 invite {@code name}, 2 accept the invitation of {@code name}, 3 decline it,
 * 4 shot (direction dx, dy and power 0..1), 5 resign / leave the game, 6 cancel my invitation.
 */
public record BilliardsActionPayload(int action, String name, float dx, float dy, float power) implements CustomPacketPayload {
    public static final Type<BilliardsActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "billiards_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BilliardsActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, BilliardsActionPayload::action,
            ByteBufCodecs.stringUtf8(32), BilliardsActionPayload::name,
            ByteBufCodecs.FLOAT, BilliardsActionPayload::dx,
            ByteBufCodecs.FLOAT, BilliardsActionPayload::dy,
            ByteBufCodecs.FLOAT, BilliardsActionPayload::power,
            BilliardsActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(BilliardsActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) BilliardsServer.handle(sp, p); });
    }
}
