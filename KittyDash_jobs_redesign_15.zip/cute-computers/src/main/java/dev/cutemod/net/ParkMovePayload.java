package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "my pet is in the park, here it stands" (about 6 times a second); emote is 0 unless it was just used. */
public record ParkMovePayload(String color, boolean sick, PetLook look, int x, int y, int emote) implements CustomPacketPayload {
    public static final Type<ParkMovePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "park_move"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ParkMovePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(16), ParkMovePayload::color,
            ByteBufCodecs.BOOL, ParkMovePayload::sick,
            PetLook.CODEC, ParkMovePayload::look,
            ByteBufCodecs.VAR_INT, ParkMovePayload::x,
            ByteBufCodecs.VAR_INT, ParkMovePayload::y,
            ByteBufCodecs.VAR_INT, ParkMovePayload::emote,
            ParkMovePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ParkMovePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) ParkServer.move(sp, p); });
    }
}
