package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.data.PlayerData;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "send me my saved data again" (if the login sync has not arrived yet). */
public record RequestDataPayload() implements CustomPacketPayload {
    public static final Type<RequestDataPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "request"));

    public static final StreamCodec<RegistryFriendlyByteBuf, RequestDataPayload> STREAM_CODEC =
            StreamCodec.unit(new RequestDataPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(RequestDataPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> sendTo(ctx.player()));
    }

    public static void sendTo(net.minecraft.world.entity.player.Player player) {
        if (player instanceof ServerPlayer sp && sp.getServer() != null) {
            PacketDistributor.sendToPlayer(sp, new SyncDataPayload(PlayerData.get(sp.getServer()).copyOf(sp.getUUID())));
            dev.cutemod.market.MarketServer.sync(sp, 0);
        }
    }
}
