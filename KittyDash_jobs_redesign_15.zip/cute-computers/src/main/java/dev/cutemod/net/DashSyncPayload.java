package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: the Kitty Dash lobby and the race you are in (if any).
 * {@code lobby} is true when {@code players}, {@code invitedBy} and {@code invitedTo} are filled in; progress messages leave them out
 * and the client keeps what it had. notice: 0 nothing, 1 your invitation was declined, 2 that player is busy, 3 no such player,
 * 4 your opponent left, 5 the invitation ran out. result: 0 running, 1 the first player won, 2 the second won, 3 draw.
 * {@code opp*} is the other player's last report; {@code atkSeq} goes up with every attack on you, {@code atkKind} is the last one.
 */
public record DashSyncPayload(int notice, boolean lobby, List<String> players, String invitedBy, String invitedTo, String opponent,
                              boolean youFirst, int seed, int result, int oppScore, int oppDist, int oppLane, int oppFlags,
                              boolean oppDone, int oppFinal, int atkSeq, int atkKind) implements CustomPacketPayload {
    public static final Type<DashSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "dash_sync"));

    private static final StreamCodec<io.netty.buffer.ByteBuf, List<String>> NAMES =
            ByteBufCodecs.stringUtf8(32).apply(ByteBufCodecs.list(100));

    public static final StreamCodec<RegistryFriendlyByteBuf, DashSyncPayload> STREAM_CODEC = StreamCodec.of((buf, p) -> {
        ByteBufCodecs.VAR_INT.encode(buf, p.notice());
        ByteBufCodecs.BOOL.encode(buf, p.lobby());
        NAMES.encode(buf, p.players());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.invitedBy());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.invitedTo());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.opponent());
        ByteBufCodecs.BOOL.encode(buf, p.youFirst());
        buf.writeInt(p.seed());
        ByteBufCodecs.VAR_INT.encode(buf, p.result());
        ByteBufCodecs.VAR_INT.encode(buf, p.oppScore());
        ByteBufCodecs.VAR_INT.encode(buf, p.oppDist());
        ByteBufCodecs.VAR_INT.encode(buf, p.oppLane());
        ByteBufCodecs.VAR_INT.encode(buf, p.oppFlags());
        ByteBufCodecs.BOOL.encode(buf, p.oppDone());
        ByteBufCodecs.VAR_INT.encode(buf, p.oppFinal());
        ByteBufCodecs.VAR_INT.encode(buf, p.atkSeq());
        ByteBufCodecs.VAR_INT.encode(buf, p.atkKind());
    }, buf -> new DashSyncPayload(
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.BOOL.decode(buf),
            NAMES.decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.BOOL.decode(buf),
            buf.readInt(),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.BOOL.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf)));

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(DashSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onDashSync(p));
    }
}
