package dev.cutemod.net;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.cutemod.data.PostData;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** The server side of the player mail: sending, the limits, mailboxes, block lists and the admin command. */
public final class PostServer {
    private PostServer() {}

    public static final int OK = 0, NO_PLAYER = 1, REFUSED = 2, TOO_FAST = 3, FULL = 4, INVALID = 5;
    private static final long MIN_GAP_MS = 15_000L;      // one letter every 15 seconds
    private static final int PER_DAY = 60;               // and at most 60 a day
    private static final Map<UUID, Long> lastSend = new HashMap<>();
    private static final Map<UUID, int[]> today = new HashMap<>();      // {day, count}
    private static final Map<UUID, Long> lastRequest = new HashMap<>();

    /** A player joined: remember their name (so others can write to them) and send them their mailbox. */
    public static void joined(ServerPlayer sp) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        PostData.get(server).rememberName(sp.getUUID(), sp.getGameProfile().getName());
        push(sp, -1);
    }

    public static void leave(UUID id) {
        lastSend.remove(id);
        lastRequest.remove(id);
    }

    private static void push(ServerPlayer sp, int result) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        PostData data = PostData.get(server);
        List<PostSyncPayload.Letter> inbox = new ArrayList<>();
        for (PostData.Letter l : data.box(sp.getUUID())) inbox.add(new PostSyncPayload.Letter(l.id(), l.fromName(), l.text(), l.drawing(), l.sent()));
        List<String> blocked = new ArrayList<>();
        for (UUID u : data.blockedOf(sp.getUUID())) blocked.add(data.nameOf(u));
        PacketDistributor.sendToPlayer(sp, new PostSyncPayload(result, inbox, data.knownNames(sp.getUUID(), 200), blocked));
    }

    public static void request(ServerPlayer sp) {
        long now = System.currentTimeMillis();
        Long last = lastRequest.get(sp.getUUID());
        if (last != null && now - last < 500) return;
        lastRequest.put(sp.getUUID(), now);
        push(sp, -1);
    }

    private static String clean(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length() && sb.length() < PostData.MAX_TEXT; i++) {
            char c = s.charAt(i);
            sb.append(c == '\n' || c == '\r' || c == '\t' ? ' ' : c < 32 || c == 127 ? '?' : c);
        }
        return sb.toString().trim();
    }

    private static boolean validDrawing(byte[] d) {
        if (d.length == 0) return true;
        if (d.length != PostData.DRAWING_BYTES) return false;
        for (byte b : d) if (((b >> 4) & 15) > PostData.PALETTE || (b & 15) > PostData.PALETTE) return false;
        return true;
    }

    public static void send(ServerPlayer sp, String toName, String text, byte[] drawing) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        PostData data = PostData.get(server);
        data.rememberName(sp.getUUID(), sp.getGameProfile().getName());
        String body = clean(text == null ? "" : text);
        if ((body.isEmpty() && drawing.length == 0) || !validDrawing(drawing) || toName.isBlank()) { push(sp, INVALID); return; }

        long now = System.currentTimeMillis();
        Long last = lastSend.get(sp.getUUID());
        int[] day = today.computeIfAbsent(sp.getUUID(), k -> new int[]{0, 0});
        int dayNo = (int) (now / 86_400_000L);
        if (day[0] != dayNo) { day[0] = dayNo; day[1] = 0; }
        if ((last != null && now - last < MIN_GAP_MS) || day[1] >= PER_DAY) { push(sp, TOO_FAST); return; }

        UUID to = data.findByName(toName.trim());
        if (to == null && server.getProfileCache() != null) {          // a player the server has seen but we have not
            var profile = server.getProfileCache().get(toName.trim());
            if (profile.isPresent()) {
                to = profile.get().getId();
                data.rememberName(to, profile.get().getName());
            }
        }
        if (to == null) { push(sp, NO_PLAYER); return; }
        if (to.equals(sp.getUUID())) { push(sp, INVALID); return; }
        if (data.isBlocked(to, sp.getUUID())) { push(sp, REFUSED); return; }
        if (!data.deliver(to, sp.getUUID(), sp.getGameProfile().getName(), body, drawing)) { push(sp, FULL); return; }

        lastSend.put(sp.getUUID(), now);
        day[1]++;
        push(sp, OK);
        ServerPlayer target = server.getPlayerList().getPlayer(to);
        if (target != null) {                                           // online: tell them right away
            target.displayClientMessage(Component.translatable("cutemod.post.new", sp.getGameProfile().getName()), true);
            push(target, -1);
        }
    }

    public static void delete(ServerPlayer sp, long id) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        PostData.get(server).delete(sp.getUUID(), id);
        push(sp, -1);
    }

    public static void block(ServerPlayer sp, String name, boolean on) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        PostData data = PostData.get(server);
        UUID who = data.findByName(name);
        if (who != null && !who.equals(sp.getUUID())) data.setBlocked(sp.getUUID(), who, on);
        push(sp, -1);
    }

    /** /cutemail clear <player>: an operator empties somebody's mailbox. */
    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("cutemail").requires(s -> s.hasPermission(2))
                .then(Commands.literal("clear").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> {
                    String name = StringArgumentType.getString(ctx, "player");
                    PostData data = PostData.get(ctx.getSource().getServer());
                    UUID id = data.findByName(name);
                    if (id == null) {
                        ctx.getSource().sendFailure(Component.translatable("cutemod.post.cmd.unknown", name));
                        return 0;
                    }
                    data.clear(id);
                    ServerPlayer online = ctx.getSource().getServer().getPlayerList().getPlayer(id);
                    if (online != null) push(online, -1);
                    ctx.getSource().sendSuccess(() -> Component.translatable("cutemod.post.cmd.cleared", name), true);
                    return 1;
                }))));
    }
}
