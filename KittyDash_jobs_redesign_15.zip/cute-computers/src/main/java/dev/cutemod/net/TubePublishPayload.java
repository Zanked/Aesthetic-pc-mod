package dev.cutemod.net;

import dev.cutemod.data.TubeData;
import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "publish this Paint animation on CuteTube" (title, frames per second, tune 0-3, 2 to 12 pictures). */
public record TubePublishPayload(String title, int fps, int tune, List<byte[]> frames) implements CustomPacketPayload {
    public static final Type<TubePublishPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "tube_publish"));

    public static final StreamCodec<RegistryFriendlyByteBuf, TubePublishPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(TubeData.MAX_TITLE * 2), TubePublishPayload::title,
            ByteBufCodecs.VAR_INT, TubePublishPayload::fps,
            ByteBufCodecs.VAR_INT, TubePublishPayload::tune,
            ByteBufCodecs.byteArray(TubeData.FRAME_BYTES).apply(ByteBufCodecs.list(TubeData.MAX_FRAMES)), TubePublishPayload::frames,
            TubePublishPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(TubePublishPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) TubeServer.publish(sp, p.title(), p.fps(), p.tune(), p.frames()); });
    }
}
