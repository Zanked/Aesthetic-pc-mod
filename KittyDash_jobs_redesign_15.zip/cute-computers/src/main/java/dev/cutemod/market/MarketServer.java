package dev.cutemod.market;

import dev.cutemod.block.ComputerBlockEntity;
import dev.cutemod.data.MarketData;
import dev.cutemod.net.MarketOrderPayload;
import dev.cutemod.net.MarketSyncPayload;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * The rules of CuteMarket, enforced on the server. The client pays with its own coins (those are not
 * checked), but it can only order real things from the {@link Catalog} through here: items must exist, amounts and the number of
 * parcels are limited, delivery time is the server's, and everything must happen next to a computer.
 */
public final class MarketServer {
    public static final int MAX_LINES = 8;        // different things in one order
    public static final int MAX_PENDING = 14;     // parcels waiting at the same time
    public static final int DAILY_ITEMS = 48;     // items per real day
    public static final int EXPRESS_PCT = 30, EXPRESS_SPEED = 3;

    private MarketServer() {}

    private static boolean nearComputer(ServerPlayer p, BlockPos pos) {
        return p.distanceToSqr(pos.getCenter()) <= 100 && p.level().getBlockEntity(pos) instanceof ComputerBlockEntity;
    }

    /** What the player paid for these items (used to refund an order that was refused). */
    private static int price(List<MarketOrderPayload.Entry> items, boolean express) {
        int sum = 0;
        for (MarketOrderPayload.Entry e : items) {
            Catalog.Entry c = Catalog.get(e.id());
            if (c != null && e.qty() > 0) sum += Deals.price(c.id(), c.price()) * Math.min(e.qty(), 1000);
        }
        return express ? (int) Math.ceil(sum * (100 + EXPRESS_PCT) / 100.0) : sum;
    }

    public static void order(ServerPlayer player, BlockPos pos, List<MarketOrderPayload.Entry> items, boolean express) {
        var server = player.getServer();
        if (server == null || items.isEmpty()) return;
        if (!nearComputer(player, pos)) return;
        MarketData data = MarketData.get(server);
        UUID me = player.getUUID();

        boolean ok = items.size() <= MAX_LINES;
        int count = 0;
        Set<String> seen = new HashSet<>();
        for (MarketOrderPayload.Entry e : items) {
            Catalog.Entry c = Catalog.get(e.id());
            if (!seen.add(e.id()) || c == null || e.qty() < 1 || e.qty() > c.maxQty()) ok = false;
            else count += e.qty() * Catalog.weight(c);
        }
        long now = System.currentTimeMillis();
        if (ok && data.pending(me) + items.size() > MAX_PENDING) ok = false;
        if (ok && !data.tryDaily(me, count, DAILY_ITEMS, now / 86_400_000L)) ok = false;

        if (!ok) { // refused: give the coins back
            sync(player, price(items, express));
            return;
        }
        for (MarketOrderPayload.Entry e : items) {
            long ready = now + Catalog.get(e.id()).secs() * 1000L / (express ? EXPRESS_SPEED : 1);
            data.add(me, new MarketData.Parcel(e.id(), e.qty(), ready));
        }
        sync(player, 0);
    }

    public static void pickup(ServerPlayer player, BlockPos pos) {
        var server = player.getServer();
        if (server == null || !nearComputer(player, pos)) return;
        MarketData data = MarketData.get(server);
        List<MarketData.Parcel> ready = data.takeReady(player.getUUID(), System.currentTimeMillis());
        for (MarketData.Parcel p : ready) {
            int left = p.qty();
            while (left > 0) {                                      // discs and gear do not stack: one item at a time
                ItemStack stack = Catalog.create(p.id(), player.level().registryAccess());
                if (stack.isEmpty()) break;
                int n = Math.min(left, stack.getMaxStackSize());
                stack.setCount(n);
                left -= n;
                player.getInventory().add(stack);
                if (!stack.isEmpty()) player.drop(stack, false);   // inventory full: it lands at the player's feet
            }
        }
        if (!ready.isEmpty()) player.displayClientMessage(Component.translatable("cutemod.market.picked", ready.size()), true);
        sync(player, 0);
    }

    /** Tell the player's client what is on its way, and coins to give back (0 if none). */
    public static void sync(ServerPlayer player, int refund) {
        var server = player.getServer();
        if (server == null) return;
        PacketDistributor.sendToPlayer(player, new MarketSyncPayload(System.currentTimeMillis(), refund,
                MarketData.get(server).of(player.getUUID())));
    }
}
