package dev.cutemod.market;

import java.time.LocalDate;
import java.time.ZoneOffset;

/**
 * The daily sales of CuteMarket (the courier shop and the Home tab). Every day about one item in twelve is cheaper,
 * by 20 to 50 percent. Which ones is a pure function of the id and the date (UTC), so every player sees the same
 * sales and the server can work out what a refused order really cost without any extra data.
 * Diamond and netherite gear and the medicine never go on sale (the real progression must stay worth it).
 */
public final class Deals {
    private static final int[] PERCENTS = {20, 25, 30, 40, 50};
    private static final int RATE = 8;       // percent of the items that are on sale on a given day

    private Deals() {}

    /** Today as a number of days (UTC, so the client and the server always agree). */
    public static long day() { return LocalDate.now(ZoneOffset.UTC).toEpochDay(); }

    private static boolean eligible(String id) {
        return !(id.contains("diamond") || id.contains("netherite") || id.contains("medicine"));
    }

    private static int hash(String id, long day) {
        int x = id.hashCode() * 0x9E3779B1 ^ (int) (day * 0x85EBCA6BL) ^ (int) (day >>> 32);
        x ^= x >>> 15; x *= 0x2C1B3C6D; x ^= x >>> 12; x *= 0x297A2D39; x ^= x >>> 15;
        return x & 0x7fffffff;
    }

    /** The discount of this item today in percent, or 0 when it is not on sale. */
    public static int percent(String id) {
        if (!eligible(id)) return 0;
        int v = hash(id, day());
        if (v % 100 >= RATE) return 0;
        return PERCENTS[(v / 100) % PERCENTS.length];
    }

    /** The price today (never below 1). */
    public static int price(String id, int base) {
        int p = percent(id);
        return p == 0 ? base : Math.max(1, (int) Math.ceil(base * (100 - p) / 100.0));
    }
}
