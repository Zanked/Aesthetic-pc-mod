package dev.cutemod.data;

/**
 * The billiard table: eleven balls (0 is the white one), the walls, the six pockets and the physics. No Minecraft classes, so the
 * client (to draw and to animate a shot), the server (to play a shot at once and judge it) and the bot (to try many shots) all run
 * exactly the same simulation. Java floats are strict, so the same start gives the same end on every machine.
 */
public final class BilliardsTable {
    public static final int L = 10, R = 210, T = 10, B = 130, CX = 110, CY = 70;
    public static final float BR = 4f, PR = 7.5f;
    public static final int N = 11, SUB = 4;
    public static final float FRICTION = 0.982f, STOP = 0.03f, MAX_PULL = 70f;
    public static final float[][] POCKETS = {{L, T}, {R, T}, {L, B}, {R, B}, {CX, T - 2}, {CX, B + 2}};
    /** Safety net: a shot that has not stopped after this many ticks is stopped by force (cannot really happen with the friction). */
    public static final int MAX_TICKS = 3000;

    /** What happened during a tick, for the sounds. The server and the bot pass null. */
    public interface Sink {
        void hit(float strength);          // two balls met, 0..1
        void wall();                       // a ball knocked the cushion
        void pocket(int ball, int pottedThisShot);
    }

    public final float[] x = new float[N], y = new float[N], vx = new float[N], vy = new float[N];
    public final boolean[] alive = new boolean[N];
    /** Balls potted since the last {@link #shoot}: bit i = ball i (bit 0 = the white ball dropped). */
    public int pottedMask;
    public int potShot;
    public boolean scratch;
    public Sink sink;
    private int hitCool, wallCool;

    public BilliardsTable() { rack(); }

    /** The start position: the white ball on the left, the ten others in a triangle on the right. */
    public void rack() {
        java.util.Arrays.fill(alive, true);
        java.util.Arrays.fill(vx, 0);
        java.util.Arrays.fill(vy, 0);
        x[0] = 60; y[0] = CY;
        float d = BR * 2 + 0.6f;
        int k = 1;
        for (int row = 0; row < 4; row++) {
            for (int j = 0; j <= row; j++) {
                x[k] = 150 + row * d * 0.866f;
                y[k] = CY + (j - row / 2f) * d;
                k++;
            }
        }
        pottedMask = 0; potShot = 0; scratch = false; hitCool = 0; wallCool = 0;
    }

    public void copyFrom(BilliardsTable o) {
        System.arraycopy(o.x, 0, x, 0, N);
        System.arraycopy(o.y, 0, y, 0, N);
        System.arraycopy(o.vx, 0, vx, 0, N);
        System.arraycopy(o.vy, 0, vy, 0, N);
        System.arraycopy(o.alive, 0, alive, 0, N);
        pottedMask = o.pottedMask; potShot = o.potShot; scratch = o.scratch;
        hitCool = o.hitCool; wallCool = o.wallCool;
    }

    public BilliardsTable copy() {
        BilliardsTable t = new BilliardsTable();
        t.copyFrom(this);
        t.sink = null;
        return t;
    }

    public float speedOf(int i) { return (float) Math.sqrt(vx[i] * vx[i] + vy[i] * vy[i]); }

    /** Number of coloured balls still on the table. */
    public int colouredLeft() {
        int n = 0;
        for (int i = 1; i < N; i++) if (alive[i]) n++;
        return n;
    }

    public int aliveMask() {
        int m = 0;
        for (int i = 0; i < N; i++) if (alive[i]) m |= 1 << i;
        return m;
    }

    /** Positions and the alive bits only (22 floats + the mask): all that a client needs to show a table at rest. */
    public void setResting(float[] xy, int mask) {
        for (int i = 0; i < N; i++) {
            x[i] = xy[i * 2]; y[i] = xy[i * 2 + 1];
            vx[i] = 0; vy[i] = 0;
            alive[i] = (mask & (1 << i)) != 0;
        }
        pottedMask = 0; potShot = 0; scratch = false;
    }

    public float[] positions() {
        float[] xy = new float[N * 2];
        for (int i = 0; i < N; i++) { xy[i * 2] = x[i]; xy[i * 2 + 1] = y[i]; }
        return xy;
    }

    /** Hits the white ball. (dx, dy) is the direction (any length but not zero), power 0..1. False if there is nothing to hit. */
    public boolean shoot(float dx, float dy, float power) {
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (!alive[0] || !(len > 0.0001f) || Float.isNaN(power)) return false;
        power = Math.max(0f, Math.min(1f, power));
        float speed = 1.2f + 5.3f * power;
        vx[0] = dx / len * speed; vy[0] = dy / len * speed;
        pottedMask = 0; potShot = 0; scratch = false;
        return true;
    }

    private void step(float dt) {
        for (int i = 0; i < N; i++) {
            if (!alive[i]) continue;
            x[i] += vx[i] * dt; y[i] += vy[i] * dt;
        }
        // pockets first, so a ball near a corner drops in instead of bouncing away
        for (int i = 0; i < N; i++) {
            if (!alive[i]) continue;
            for (float[] p : POCKETS) {
                float dx = x[i] - p[0], dy = y[i] - p[1];
                if (dx * dx + dy * dy < PR * PR) {
                    alive[i] = false; vx[i] = 0; vy[i] = 0;
                    pottedMask |= 1 << i;
                    if (i == 0) scratch = true; else potShot++;
                    if (sink != null) sink.pocket(i, potShot);
                    break;
                }
            }
        }
        for (int i = 0; i < N; i++) {
            if (!alive[i]) continue;
            boolean bump = false;
            if (x[i] < L + BR) { x[i] = L + BR; if (vx[i] < -0.8f) bump = true; vx[i] = Math.abs(vx[i]) * 0.92f; }
            if (x[i] > R - BR) { x[i] = R - BR; if (vx[i] > 0.8f) bump = true; vx[i] = -Math.abs(vx[i]) * 0.92f; }
            if (y[i] < T + BR) { y[i] = T + BR; if (vy[i] < -0.8f) bump = true; vy[i] = Math.abs(vy[i]) * 0.92f; }
            if (y[i] > B - BR) { y[i] = B - BR; if (vy[i] > 0.8f) bump = true; vy[i] = -Math.abs(vy[i]) * 0.92f; }
            if (bump && wallCool <= 0) { if (sink != null) sink.wall(); wallCool = 5; }
        }
        for (int i = 0; i < N; i++) {
            if (!alive[i]) continue;
            for (int j = i + 1; j < N; j++) {
                if (!alive[j]) continue;
                float dx = x[j] - x[i], dy = y[j] - y[i], d2 = dx * dx + dy * dy, min = BR * 2;
                if (d2 >= min * min || d2 < 0.0001f) continue;
                float d = (float) Math.sqrt(d2), nx = dx / d, ny = dy / d, push = (min - d) / 2;
                x[i] -= nx * push; y[i] -= ny * push; x[j] += nx * push; y[j] += ny * push;
                float rel = (vx[i] - vx[j]) * nx + (vy[i] - vy[j]) * ny;
                if (rel > 0) {
                    vx[i] -= rel * nx; vy[i] -= rel * ny; vx[j] += rel * nx; vy[j] += rel * ny;
                    if (rel > 0.5f && hitCool <= 0) {
                        if (sink != null) sink.hit(Math.min(1f, rel / 5f));
                        hitCool = 3;
                    }
                }
            }
        }
    }

    /** One tick of the game (60 per second). True while something is still moving. */
    public boolean tick() {
        if (hitCool > 0) hitCool--;
        if (wallCool > 0) wallCool--;
        for (int s = 0; s < SUB; s++) step(1f / SUB);
        boolean any = false;
        for (int i = 0; i < N; i++) {
            if (!alive[i]) continue;
            vx[i] *= FRICTION; vy[i] *= FRICTION;
            if (speedOf(i) < STOP) { vx[i] = 0; vy[i] = 0; } else any = true;
        }
        return any;
    }

    /** Plays the shot to the end at once (server, bot). */
    public void runToRest() {
        for (int t = 0; t < MAX_TICKS; t++) if (!tick()) return;
        java.util.Arrays.fill(vx, 0);
        java.util.Arrays.fill(vy, 0);
    }

    /** After the white ball dropped: it comes back on the head string, as far left as there is room. */
    public void respawnWhite() {
        alive[0] = true; vx[0] = 0; vy[0] = 0; y[0] = CY;
        for (float px = 60; px >= L + BR; px -= 3) {
            x[0] = px;
            boolean free = true;
            for (int i = 1; i < N; i++) if (alive[i] && Math.abs(x[i] - px) < BR * 2 + 1 && Math.abs(y[i] - CY) < BR * 2 + 1) free = false;
            if (free) break;
        }
    }
}
