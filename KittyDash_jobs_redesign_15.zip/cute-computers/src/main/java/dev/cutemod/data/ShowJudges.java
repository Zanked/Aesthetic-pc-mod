package dev.cutemod.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The cast of the talent show that is not a player: the judges (eight of them, four sit on the panel in every round)
 * and the "guest" pets that fill an empty stage.
 * Pure logic (no Minecraft classes). Everything is a function of the round number, so the server and a test
 * always agree and nothing has to be saved.
 */
public final class ShowJudges {
    private ShowJudges() {}

    /** The seats of the panel. A seat is a taste (0 cute, 1 style, 2 mystery, 3 effort): the stars come from the seat. */
    public static final int COUNT = 4;
    /** The star slots of a pet: the four seats and (in some rounds) the guest judge in the slot after them. */
    public static final int SLOTS = COUNT + 1;
    /** The slot of the guest judge, and how many guest judges there are (king, ghost, chef). The guest's stars count double. */
    public static final int GUEST = COUNT, GUESTS = 3, GUEST_WEIGHT = 2;
    /** The judges 8, 9, 10 are the guests: their look and the voice they borrow from the regular judges. */
    public static final String[] GUEST_COLOR = {"yellow", "white", "orange"};
    public static final String[] GUEST_HAT = {"acc_crown", "acc_ghost", "acc_chef"};
    public static final int[] GUEST_VOICE = {1, 2, 3};
    /** The judges of the pool: 2 for every seat. A judge is a seat plus 4 (persona = seat + 4 * alt, so persona % 4 is the seat). */
    public static final int PERSONAS = 8;
    /** The computer color of every judge: its animal is the judge (panda, creeper, enderman, bee, ladybug, fox, cat, penguin). */
    public static final String[] COLOR = {"white", "green", "purple", "yellow", "red", "orange", "pink", "blue"};
    /** What each judge wears in the picture. */
    public static final String[] HAT = {"acc_flower", "acc_party", "acc_witch", "acc_headphones", "acc_bow", "acc_beret", "acc_starclip", "acc_cap"};

    private static final String[] NAMES = {"Mochi", "Biscuit", "Pixel", "Nori", "Pudding", "Waffle", "Sprout", "Bean",
            "Cookie", "Pumpkin", "Luna", "Momo", "Kiwi", "Taco", "Peach", "Zephyr"};
    private static final String[] HATS = PetWear.botItems(false);
    private static final String[] BODIES = PetWear.botItems(true);
    private static final String[] COLORS = {"pink", "green", "white", "blue", "orange", "purple", "yellow", "red"};

    /** A guest pet: it is not a player, it only keeps the stage lively. hearts = the love of the crowd at the end (0-4). */
    public record Bot(String name, String color, int stage, int trait, int ageMin, String head, String body, int hearts) {}

    private static long mix(long x) {
        x += 0x9E3779B97F4A7C15L;
        x = (x ^ (x >>> 30)) * 0xBF58476D1CE4E5B9L;
        x = (x ^ (x >>> 27)) * 0x94D049BB133111EBL;
        return x ^ (x >>> 31);
    }

    /** A number in [-1, 1) that depends only on the inputs. */
    private static double noise(long a, long b, long c) {
        long h = mix(mix(mix(a) ^ b) ^ c);
        return ((h >>> 11) / (double) (1L << 53)) * 2 - 1;
    }

    private static long hash(String s) {
        long h = 1125899906842597L;
        for (int i = 0; i < s.length(); i++) h = 31 * h + s.charAt(i);
        return h;
    }

    /** The acts a pet can perform: 0 sweet song, 1 dance, 2 magic trick, 3 acrobatics. Act n is loved most by the judge on seat n. */
    public static final int ACTS = 4;
    public static final int MAX_SKILL = 3;
    /** The act that suits the theme of a round best (index = theme). */
    private static final int[] ACT_FOR_THEME = {0, 2, 1, 0, 1, 0, 3, 2, 3, 2};

    /** The act that fits a theme: it gives a little to every judge. */
    public static int bestActFor(int theme) { return ACT_FOR_THEME[Math.floorMod(theme, ACT_FOR_THEME.length)]; }

    /** What an act is worth to the judge on this seat: the seat that loves the act gives a lot (more for a rehearsed act), the theme adds a little for all. */
    public static double actBonus(int seat, int theme, int act, int skill) {
        if (act < 0 || act >= ACTS) return 0;
        double b = seat == act ? 0.8 + 0.2 * Math.max(0, Math.min(MAX_SKILL, skill)) : 0;
        if (bestActFor(theme) == act) b += 0.35;
        return b;
    }

    /** The favourite act of a guest pet: it never changes (so the guests can be recognised), see {@link #botAct}. */
    public static int favAct(String name) { return (int) Math.floorMod(mix(hash(name) * 5 + 3), (long) ACTS); }

    /** The act of a guest pet in a round: nearly always its favourite one (a pure function of the round and its name). */
    public static int botAct(long round, String name) {
        long h = mix(round * 7 + hash(name));
        return Math.floorMod(h, 5L) == 0 ? (int) Math.floorMod(h >>> 8, (long) ACTS) : favAct(name);
    }

    /** The names of the guest pets (the language files have a catch phrase for each of them). */
    public static String[] botNames() { return NAMES.clone(); }

    /** Which guest judge (0-2) sits at the table in a round, or -1: about one round in four. A pure function of the round. */
    public static int guestOf(long round) {
        long h = mix(round * 61 + 19);
        return Math.floorMod(h, 4L) == 0 ? (int) Math.floorMod(h >>> 9, (long) GUESTS) : -1;
    }

    /** The colour of a judge or guest (0-7 regular, 8-10 guest). */
    public static String colorOfJudge(int p) { return p >= 8 ? GUEST_COLOR[p - 8] : COLOR[p]; }

    /** The hat of a judge or guest (0-7 regular, 8-10 guest). */
    public static String hatOfJudge(int p) { return p >= 8 ? GUEST_HAT[p - 8] : HAT[p]; }

    /**
     * The stars (1-5) of the guest judge of this round, or 0 if there is no guest. The king loves crowns and capes and the
     * proud, the ghost the spooky and the mysterious, the chef the cooks and the hungry; each also loves one act.
     */
    public static int guestStars(long round, String key, String color, int stage, int trait, int ageMin, String head, String body, int act, int skill) {
        int g = guestOf(round);
        if (g < 0) return 0;
        double s = 1.7;
        switch (g) {
            case 0 -> {
                if (has(head, "acc_crown", "acc_champion")) s += 1.2; else if (has(head, "acc_hat", "acc_halo")) s += 0.5;
                if (has(body, "acc_cape", "acc_tux")) s += 0.6;
                if (stage == 2) s += 0.5;
                if (act == 1) s += 0.5 + 0.2 * skill;
            }
            case 1 -> {
                if (has(head, "acc_ghost", "acc_witch", "acc_horns")) s += 1.2;
                if (trait == 2) s += 0.7;
                if (stage >= 1) s += 0.2;
                if (act == 2) s += 0.5 + 0.2 * skill;
            }
            default -> {
                if (has(head, "acc_chef")) s += 1.0;
                if (has(body, "acc_apron")) s += 0.7;
                if (trait == 0) s += 0.6;
                if (act == 0) s += 0.5 + 0.2 * skill;
            }
        }
        s += 0.5 * themeBonus(themeOf(round), stage, trait, head, body);
        s += 0.8 * noise(round, 99 + g, hash(key + color));
        return Math.max(1, Math.min(5, (int) Math.round(s)));
    }

    /** The themes of the rounds. Every round has one; it gives a bonus to pets that fit it (see {@link #themeBonus}). */
    public static final int THEMES = 10;
    // 0 sweet and cute, 1 spooky night, 2 royal ball, 3 cozy winter, 4 rock star, 5 garden party,
    // 6 beach party, 7 space trip, 8 pirate adventure, 9 cooking show

    /** How many different panels there are: every seat has 2 judges to pick from, so 2^4. */
    public static final int PANELS = 1 << COUNT;

    /** One shuffle of all panels (same idea as {@link #block}). */
    private static int[] panelBlock(long b) {
        int[] p = new int[PANELS];
        for (int i = 0; i < PANELS; i++) p[i] = i;
        Random r = new Random(mix(b * 17 + 11));
        for (int i = PANELS - 1; i > 0; i--) {
            int k = r.nextInt(i + 1), t = p[i];
            p[i] = p[k];
            p[k] = t;
        }
        return p;
    }

    /**
     * Who sits on the panel in a round, as 4 bits: bit s set = the second judge of seat s. A pure function of the round
     * number (so the server, the client and a test always agree and nothing is saved). Every block of {@value #PANELS}
     * rounds shows each panel exactly once, in a shuffled order, and the panel is never the same twice in a row
     * (also not between two blocks), and two rounds in a row always differ in at least one judge.
     */
    public static int panelOf(long round) {
        long b = Math.floorDiv(round, (long) PANELS);
        int i = (int) Math.floorMod(round, (long) PANELS);
        int[] p = panelBlock(b);
        if (p[0] == panelBlock(b - 1)[PANELS - 1]) { int t = p[0]; p[0] = p[1]; p[1] = t; }
        return p[i];
    }

    /** The judge (0-7) that sits on a seat (0-3) of a panel (see {@link #panelOf}). */
    public static int persona(int panel, int seat) { return seat + COUNT * ((panel >> seat) & 1); }

    /** The seat (the taste) of a judge. */
    public static int seatOf(int persona) { return persona % COUNT; }

    /** One shuffle of all themes: every block of THEMES rounds shows each theme exactly once. */
    private static int[] block(long b) {
        int[] p = new int[THEMES];
        for (int i = 0; i < THEMES; i++) p[i] = i;
        Random r = new Random(mix(b * 13 + 5));
        for (int i = THEMES - 1; i > 0; i--) {
            int k = r.nextInt(i + 1), t = p[i];
            p[i] = p[k];
            p[k] = t;
        }
        return p;
    }

    /**
     * The theme of a round: a pure function of the round number. Every theme comes once in every {@value #THEMES}
     * rounds, in a shuffled order, and never the same twice in a row (also not between two blocks).
     */
    public static int themeOf(long round) {
        long b = Math.floorDiv(round, (long) THEMES);
        int i = (int) Math.floorMod(round, (long) THEMES);
        int[] p = block(b);
        if (p[0] == block(b - 1)[THEMES - 1]) { int t = p[0]; p[0] = p[1]; p[1] = t; }
        return p[i];
    }

    /** Up to +1.2 stars for a pet that fits the theme (a naked pet gets nothing, so clothes still matter most). */
    public static double themeBonus(int theme, int stage, int trait, String head, String body) {
        double b = 0;
        switch (theme) {
            case 0 -> { // sweet and cute
                if (has(head, "acc_bow", "acc_flower", "acc_halo")) b += 1.0;
                if (stage == 0) b += 0.4;
                if (trait == 3) b += 0.4;
            }
            case 1 -> { // spooky night
                if (has(head, "acc_ghost", "acc_horns", "acc_witch")) b += 1.0;
                if (has(body, "acc_cape")) b += 0.4;
                if (trait == 2) b += 0.3;
            }
            case 2 -> { // royal ball
                if (has(head, "acc_crown", "acc_champion")) b += 1.1;
                else if (has(head, "acc_hat", "acc_halo")) b += 0.6;
                if (has(body, "acc_cape")) b += 0.6;
                if (stage == 2) b += 0.3;
            }
            case 3 -> { // cozy winter
                if (has(head, "acc_ushanka")) b += 1.0;
                if (has(body, "acc_scarf")) b += 0.8;
                if (trait == 2) b += 0.2;
            }
            case 4 -> { // rock star
                if (has(head, "acc_headphones", "acc_glasses", "acc_cap")) b += 1.0;
                if (trait == 1) b += 0.5;
                if (has(body, "acc_cape")) b += 0.3;
            }
            case 5 -> { // garden party
                if (has(head, "acc_flower")) b += 1.0;
                else if (has(head, "acc_hat", "acc_cap", "acc_bow")) b += 0.6;
                if (trait == 0) b += 0.5;
            }
            case 6 -> { // beach party: the sunny and playful
                if (stage == 0) b += 0.2;
                if (trait == 0 || trait == 1) b += 0.3;
            }
            case 7 -> { // space trip: the mysterious and the grown-up
                if (trait == 2) b += 0.4;
                if (stage == 2) b += 0.3;
            }
            case 8 -> { // pirate adventure: the bold
                if (trait == 1) b += 0.4;
                if (stage >= 1) b += 0.2;
            }
            default -> { // cooking show: the hungry
                if (trait == 0) b += 0.5;
            }
        }
        b += PetWear.themeScore(theme, head, body);   // the clothes: every item says which themes it fits
        return Math.min(1.2, b);
    }

    /** True if the packed list of worn items holds one of these ids. */
    private static boolean has(String packed, String... ids) {
        for (String t : PetWear.layers(packed)) for (String i : ids) if (i.equals(t)) return true;
        return false;
    }

    /** A little extra for a layered look: +0.15 for every item beyond the first two, at most +0.45. */
    private static double layerBonus(String head, String body) {
        int n = PetWear.layers(head).length + PetWear.layers(body).length;
        return Math.min(0.45, 0.15 * Math.max(0, n - 2));
    }

    /**
     * Every seat gives this much for the character of the pet (age and nature) on average. A seat whose taste is rare
     * (style: only a bold or grown-up pet counts) gets a bigger base, a seat whose taste is common (effort: almost every
     * pet has some age) a smaller one, so no seat is harder or easier to please than another.
     */
    private static final double CHARACTER_MEAN = 0.8;

    /**
     * How many stars (1-5) a judge gives to a pet. {@code judge} is the SEAT (0-3). The seat decides what the judge
     * likes in the CHARACTER of the pet: seat 0 loves the young and sweet, seat 1 the bold and grown-up, seat 2 the
     * mysterious and seat 3 the hard-working and old hands (every seat gets the same average, so none is stricter). What the judge likes to see on the pet is decided by WHO sits there in this round (the eight judges
     * have eight different tastes in clothes, see {@link PetWear#clothesTaste}), and the clothes count the same for
     * everybody. A pet in clothes scores better than a naked one, and a pet that fits the theme of the round gets a bonus.
     * key = who it is (the player's UUID text or the name of a guest).
     */
    public static int stars(int judge, long round, String key, String color, int stage, int trait, int ageMin, String head, String body) {
        return stars(judge, round, key, color, stage, trait, ageMin, head, body, -1, 0);
    }

    /** The same with the act the pet performs (0-3, -1 = none) and how well it has rehearsed it (0-3). */
    public static int stars(int judge, long round, String key, String color, int stage, int trait, int ageMin, String head, String body, int act, int skill) {
        int who = persona(panelOf(round), judge);
        double ch, chMean;   // what the seat sees in the pet, and what it sees in an average pet
        switch (judge) {
            case 0 -> { ch = (stage == 0 ? 0.9 : stage == 1 ? 0.5 : 0.2) + (trait == 3 ? 0.7 : 0); chMean = 0.71; }
            case 1 -> { ch = (trait == 1 ? 0.5 : 0) + (stage == 2 ? 0.4 : 0); chMean = 0.26; }
            case 2 -> { ch = (trait == 2 ? 0.7 : 0) + (stage == 2 ? 0.6 : stage == 1 ? 0.3 : 0); chMean = 0.48; }
            default -> { ch = (trait == 0 || trait == 1 ? 0.7 : 0) + Math.min(ageMin, 1200) / 1200.0 + (stage >= 1 ? 0.3 : 0); chMean = 1.15; }
        }
        double s = 1.6 + ch + (CHARACTER_MEAN - chMean);
        s += PetWear.clothesTaste(who, head, body);           // this judge's own taste in clothes
        s += themeBonus(themeOf(round), stage, trait, head, body);
        s += PetWear.setBonus(head, body);                     // whole sets (chef hat + apron...) win every judge
        s += layerBonus(head, body);                           // and so does a layered look
        s += actBonus(judge, themeOf(round), act, skill);      // the act: the seat that loves it gives a lot
        s += 0.7 * noise(round, who, hash(key + color));
        return Math.max(1, Math.min(5, (int) Math.round(s)));
    }

    /** The guests of a round (always 4; the stage shows as many as it needs, from the front of the list). */
    public static List<Bot> bots(long round) {
        Random r = new Random(mix(round * 31 + 7));
        List<Bot> out = new ArrayList<>();
        List<Integer> names = new ArrayList<>();
        for (int i = 0; i < NAMES.length; i++) names.add(i);
        java.util.Collections.shuffle(names, r);
        for (int i = 0; i < 4; i++) {
            String head = r.nextInt(100) < 55 ? HATS[1 + r.nextInt(HATS.length - 1)] : "";
            String body = r.nextInt(100) < 35 ? BODIES[1 + r.nextInt(BODIES.length - 1)] : "";
            int stage = 1 + r.nextInt(2);
            out.add(new Bot(NAMES[names.get(i)], COLORS[r.nextInt(COLORS.length)], stage, r.nextInt(4),
                    stage == 1 ? 25 + r.nextInt(30) : 70 + r.nextInt(500), head, body, r.nextInt(5)));
        }
        return out;
    }
}
