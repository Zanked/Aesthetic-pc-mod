package dev.cutemod.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** CuteNet leaderboards: the best score of every player in every game (data/cutemod_net.dat), kept on the SERVER. */
public class NetData extends SavedData {
    public record Row(String name, int score) {}

    private static final int MAX_GAMES = 64;

    private final Map<String, Map<UUID, Row>> boards = new HashMap<>();

    public static NetData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(new SavedData.Factory<>(NetData::new, NetData::load, null), "cutemod_net");
    }

    /** The player holding first place, or null. */
    public UUID leader(String game) {
        Map<UUID, Row> b = boards.get(game);
        UUID best = null;
        int top = -1;
        if (b != null) for (Map.Entry<UUID, Row> e : b.entrySet()) if (e.getValue().score() > top) { top = e.getValue().score(); best = e.getKey(); }
        return best;
    }

    /** Stores the score if it beats the player's best. Returns true if it did. */
    public boolean submit(String game, UUID id, String name, int score) {
        if (!boards.containsKey(game) && boards.size() >= MAX_GAMES) return false;
        Map<UUID, Row> b = boards.computeIfAbsent(game, k -> new HashMap<>());
        Row old = b.get(id);
        if (old != null && old.score() >= score) {
            if (!old.name().equals(name)) { b.put(id, new Row(name, old.score())); setDirty(); }   // the player was renamed
            return false;
        }
        b.put(id, new Row(name, score));
        setDirty();
        return true;
    }

    public List<Row> top(String game, int n) {
        List<Row> out = new ArrayList<>();
        Map<UUID, Row> b = boards.get(game);
        if (b != null) out.addAll(b.values());
        out.sort((a, c) -> Integer.compare(c.score(), a.score()));
        return out.size() > n ? new ArrayList<>(out.subList(0, n)) : out;
    }

    /** 1 = first place, 0 = no score yet. */
    public int rank(String game, UUID id) {
        Map<UUID, Row> b = boards.get(game);
        if (b == null || !b.containsKey(id)) return 0;
        int mine = b.get(id).score(), better = 0;
        for (Row r : b.values()) if (r.score() > mine) better++;
        return better + 1;
    }

    public int best(String game, UUID id) {
        Map<UUID, Row> b = boards.get(game);
        Row r = b == null ? null : b.get(id);
        return r == null ? 0 : r.score();
    }

    public static NetData load(CompoundTag tag, HolderLookup.Provider registries) {
        NetData d = new NetData();
        ListTag games = tag.getList("games", Tag.TAG_COMPOUND);
        for (int i = 0; i < games.size(); i++) {
            CompoundTag g = games.getCompound(i);
            Map<UUID, Row> b = new HashMap<>();
            ListTag rows = g.getList("rows", Tag.TAG_COMPOUND);
            for (int k = 0; k < rows.size(); k++) {
                CompoundTag r = rows.getCompound(k);
                try {
                    b.put(UUID.fromString(r.getString("id")), new Row(r.getString("name"), r.getInt("score")));
                } catch (IllegalArgumentException ignored) {
                }
            }
            d.boards.put(g.getString("game"), b);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag games = new ListTag();
        boards.forEach((game, b) -> {
            CompoundTag g = new CompoundTag();
            g.putString("game", game);
            ListTag rows = new ListTag();
            b.forEach((id, r) -> {
                CompoundTag c = new CompoundTag();
                c.putString("id", id.toString());
                c.putString("name", r.name());
                c.putInt("score", r.score());
                rows.add(c);
            });
            g.put("rows", rows);
            games.add(g);
        });
        tag.put("games", games);
        return tag;
    }
}
