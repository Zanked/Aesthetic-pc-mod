package dev.cutemod.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Letters between players (data/cutemod_post.dat), kept on the SERVER: every player's mailbox, who is who
 * (the last name of every player the computers have seen) and every player's block list.
 */
public class PostData extends SavedData {
    public static final int MAX_BOX = 30, MAX_TEXT = 240, DRAWING_BYTES = 1152, PALETTE = 14;

    /** One letter. drawing is empty or DRAWING_BYTES long (two pixels per byte, 0 = empty, 1..14 = palette colour). */
    public record Letter(long id, UUID from, String fromName, String text, byte[] drawing, long sent) {}

    private final Map<UUID, List<Letter>> boxes = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private final Map<UUID, Set<UUID>> blocked = new HashMap<>();
    private long nextId = 1;

    public static PostData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(new SavedData.Factory<>(PostData::new, PostData::load, null), "cutemod_post");
    }

    // ---------- people ----------
    public void rememberName(UUID id, String name) {
        if (!name.equals(names.put(id, name))) setDirty();
    }

    public String nameOf(UUID id) { return names.getOrDefault(id, "?"); }

    /** Case-insensitive search among the players we know. */
    public UUID findByName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (Map.Entry<UUID, String> e : names.entrySet()) if (e.getValue().toLowerCase(Locale.ROOT).equals(n)) return e.getKey();
        return null;
    }

    public List<String> knownNames(UUID except, int max) {
        List<String> out = new ArrayList<>();
        for (Map.Entry<UUID, String> e : names.entrySet()) if (!e.getKey().equals(except)) out.add(e.getValue());
        out.sort(String.CASE_INSENSITIVE_ORDER);
        return out.size() > max ? out.subList(0, max) : out;
    }

    // ---------- mailboxes ----------
    /** The mailbox, newest first. */
    public List<Letter> box(UUID owner) {
        List<Letter> b = new ArrayList<>(boxes.getOrDefault(owner, List.of()));
        java.util.Collections.reverse(b);
        return b;
    }

    public int boxSize(UUID owner) { return boxes.getOrDefault(owner, List.of()).size(); }

    /** Puts a letter in a mailbox. Returns false if the mailbox is full. */
    public boolean deliver(UUID to, UUID from, String fromName, String text, byte[] drawing) {
        List<Letter> b = boxes.computeIfAbsent(to, k -> new ArrayList<>());
        if (b.size() >= MAX_BOX) return false;
        b.add(new Letter(nextId++, from, fromName, text, drawing, System.currentTimeMillis()));
        setDirty();
        return true;
    }

    public boolean delete(UUID owner, long id) {
        List<Letter> b = boxes.get(owner);
        if (b != null && b.removeIf(l -> l.id() == id)) { setDirty(); return true; }
        return false;
    }

    public void clear(UUID owner) {
        if (boxes.remove(owner) != null) setDirty();
    }

    // ---------- block lists ----------
    public boolean isBlocked(UUID owner, UUID sender) { return blocked.getOrDefault(owner, Set.of()).contains(sender); }

    public List<UUID> blockedOf(UUID owner) { return new ArrayList<>(blocked.getOrDefault(owner, Set.of())); }

    public void setBlocked(UUID owner, UUID target, boolean on) {
        Set<UUID> s = blocked.computeIfAbsent(owner, k -> new HashSet<>());
        if ((on ? s.add(target) : s.remove(target))) setDirty();
    }

    // ---------- save / load ----------
    public static PostData load(CompoundTag tag, HolderLookup.Provider registries) {
        PostData d = new PostData();
        d.nextId = Math.max(1, tag.getLong("next"));
        CompoundTag n = tag.getCompound("names");
        for (String k : n.getAllKeys()) {
            try { d.names.put(UUID.fromString(k), n.getString(k)); } catch (IllegalArgumentException ignored) { }
        }
        ListTag people = tag.getList("boxes", Tag.TAG_COMPOUND);
        for (int i = 0; i < people.size(); i++) {
            CompoundTag p = people.getCompound(i);
            try {
                UUID owner = UUID.fromString(p.getString("owner"));
                List<Letter> list = new ArrayList<>();
                ListTag ls = p.getList("letters", Tag.TAG_COMPOUND);
                for (int j = 0; j < ls.size(); j++) {
                    CompoundTag l = ls.getCompound(j);
                    list.add(new Letter(l.getLong("id"), UUID.fromString(l.getString("from")), l.getString("fromName"),
                            l.getString("text"), l.getByteArray("drawing"), l.getLong("sent")));
                }
                d.boxes.put(owner, list);
            } catch (IllegalArgumentException ignored) {
            }
        }
        ListTag bl = tag.getList("blocked", Tag.TAG_COMPOUND);
        for (int i = 0; i < bl.size(); i++) {
            CompoundTag p = bl.getCompound(i);
            try {
                Set<UUID> s = new HashSet<>();
                for (Tag t : p.getList("list", Tag.TAG_STRING)) s.add(UUID.fromString(t.getAsString()));
                d.blocked.put(UUID.fromString(p.getString("owner")), s);
            } catch (IllegalArgumentException ignored) {
            }
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putLong("next", nextId);
        CompoundTag n = new CompoundTag();
        names.forEach((k, v) -> n.putString(k.toString(), v));
        tag.put("names", n);
        ListTag people = new ListTag();
        boxes.forEach((owner, list) -> {
            if (list.isEmpty()) return;
            CompoundTag p = new CompoundTag();
            p.putString("owner", owner.toString());
            ListTag ls = new ListTag();
            for (Letter l : list) {
                CompoundTag c = new CompoundTag();
                c.putLong("id", l.id());
                c.putString("from", l.from().toString());
                c.putString("fromName", l.fromName());
                c.putString("text", l.text());
                c.putByteArray("drawing", l.drawing());
                c.putLong("sent", l.sent());
                ls.add(c);
            }
            p.put("letters", ls);
            people.add(p);
        });
        tag.put("boxes", people);
        ListTag bl = new ListTag();
        blocked.forEach((owner, set) -> {
            if (set.isEmpty()) return;
            CompoundTag p = new CompoundTag();
            p.putString("owner", owner.toString());
            ListTag l = new ListTag();
            for (UUID u : set) l.add(StringTag.valueOf(u.toString()));
            p.put("list", l);
            bl.add(p);
        });
        tag.put("blocked", bl);
        return tag;
    }
}
