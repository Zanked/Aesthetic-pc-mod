package dev.cutemod.data;

import dev.cutemod.data.CheckersEngine.Move;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * One online game of checkers between two players. The server keeps it and checks every move with {@link CheckersEngine},
 * so a player cannot cheat. No Minecraft classes in here, so it can be tested alone.
 * result: 0 playing, 1 white won, 2 black won, 3 draw.
 */
public final class CheckersMatch {
    public final UUID white, black;
    public int[] board = CheckersEngine.start();
    public boolean whiteTurn = true;
    public int quiet, plies, result, lastFrom = -1, lastTo = -1;
    /** Goes up with every change, so a client can tell that something new arrived. */
    public int seq;

    public CheckersMatch(UUID white, UUID black) {
        this.white = white;
        this.black = black;
    }

    public boolean has(UUID id) { return white.equals(id) || black.equals(id); }

    public UUID other(UUID id) { return white.equals(id) ? black : white; }

    public boolean isWhite(UUID id) { return white.equals(id); }

    /** Plays a move if it is this player's turn and the move is legal. True if it was played. */
    public boolean move(UUID who, int from, int[] to) {
        if (result != 0 || !has(who) || isWhite(who) != whiteTurn || to == null || to.length == 0) return false;
        Move found = null;
        for (Move m : CheckersEngine.moves(board, whiteTurn)) {
            if (m.from() == from && Arrays.equals(m.to(), to)) { found = m; break; }
        }
        if (found == null) return false;
        boolean wasMan = Math.abs(board[found.from()]) == 1;
        board = CheckersEngine.apply(board, found);
        lastFrom = found.from();
        lastTo = found.end();
        quiet = found.caps().length > 0 || wasMan ? 0 : quiet + 1;
        plies++;
        whiteTurn = !whiteTurn;
        List<Move> next = CheckersEngine.moves(board, whiteTurn);
        if (next.isEmpty()) result = whiteTurn ? 2 : 1;        // the side to move cannot move: the other side won
        else if (quiet >= 30 || plies >= 300) result = 3;
        seq++;
        return true;
    }

    /** This player gives up (or left): the other one wins. Does nothing if the game is over. */
    public void resign(UUID who) {
        if (result != 0 || !has(who)) return;
        result = isWhite(who) ? 2 : 1;
        seq++;
    }
}
