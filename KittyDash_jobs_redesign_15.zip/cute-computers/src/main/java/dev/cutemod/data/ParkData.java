package dev.cutemod.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * The Pet Park: how many times two players' pets played together (friendship), how often a player did something with a
 * resident of the park (the same numbers, under the key "playerUUID|bot:name") and the coins paid today (data/cutemod_park.dat).
 */
public class ParkData extends SavedData {
    /** Plays needed for friendship level 1, 2, 3 and 4 ("best friends"). */
    public static final int[] LEVEL_AT = {1, 5, 15, 40};
    /** Coins for reaching level 2, 3 and 4 (not counted in the daily limit). */
    public static final int[] LEVEL_BONUS = {0, 5, 10, 20};

    /** The treats a player can give to another pet, cheapest first (the ids of the stock; the number is what travels over the network). */
    public static final String[] GIFTS = {"treat_berry", "treat_lolly", "treat_cookie", "treat_fish", "treat_honey", "treat_milk", "treat_cake"};
    /** How many quick phrases the park has (language keys cutemod.park.say.1 and up). */
    public static final int SAY_COUNT = 6;

    private final Map<String, Integer> plays = new HashMap<>();
    private final Map<UUID, long[]> daily = new HashMap<>();     // {day, coins paid that day}

    public static ParkData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(new SavedData.Factory<>(ParkData::new, ParkData::load, null), "cutemod_park");
    }

    public static String pair(UUID a, UUID b) {
        String x = a.toString(), y = b.toString();
        return x.compareTo(y) < 0 ? x + "|" + y : y + "|" + x;
    }

    /** 0 (strangers) to 4 (best friends). */
    public static int level(int plays) {
        int l = 0;
        for (int i = 0; i < LEVEL_AT.length; i++) if (plays >= LEVEL_AT[i]) l = i + 1;
        return l;
    }

    public int plays(UUID a, UUID b) { return plays.getOrDefault(pair(a, b), 0); }

    /** Counts one more play of this pair and returns the new total. */
    public int addPlay(UUID a, UUID b) { return addPlay(a, b, 1); }

    /** Counts {@code n} more plays of this pair (a treat is worth 2) and returns the new total. */
    public int addPlay(UUID a, UUID b, int n) {
        int t = plays.merge(pair(a, b), n, Integer::sum);
        setDirty();
        return t;
    }

    /** How often this player's pet did something with the resident {@code bot} ("bot:..."). */
    public int botPlays(UUID a, String bot) { return plays.getOrDefault(a + "|" + bot, 0); }

    /** Counts {@code n} more plays with a resident and returns the new total. */
    public int addBotPlay(UUID a, String bot, int n) {
        int t = plays.merge(a + "|" + bot, n, Integer::sum);
        setDirty();
        return t;
    }

    /** The coins for the friendship levels crossed when the count goes from {@code before} to {@code after} (usually one level, a treat may skip one). */
    public static int bonusBetween(int before, int after) {
        int sum = 0;
        for (int l = level(before) + 1; l <= level(after); l++) sum += LEVEL_BONUS[l - 1];
        return sum;
    }

    /** Pays up to {@code want} coins within the daily cap; returns what was granted. */
    public int pay(UUID id, int want, int cap, long today) {
        long[] d = daily.computeIfAbsent(id, k -> new long[2]);
        if (d[0] != today) { d[0] = today; d[1] = 0; }
        int give = (int) Math.max(0, Math.min(want, cap - d[1]));
        if (give > 0) { d[1] += give; setDirty(); }
        return give;
    }

    public static ParkData load(CompoundTag tag, HolderLookup.Provider registries) {
        ParkData d = new ParkData();
        ListTag ps = tag.getList("plays", Tag.TAG_COMPOUND);
        for (int i = 0; i < ps.size(); i++) {
            CompoundTag c = ps.getCompound(i);
            d.plays.put(c.getString("pair"), c.getInt("n"));
        }
        ListTag ds = tag.getList("daily", Tag.TAG_COMPOUND);
        for (int i = 0; i < ds.size(); i++) {
            CompoundTag c = ds.getCompound(i);
            try { d.daily.put(UUID.fromString(c.getString("id")), new long[]{c.getLong("day"), c.getLong("coins")}); } catch (IllegalArgumentException ignored) { }
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag ps = new ListTag();
        plays.forEach((k, v) -> { CompoundTag c = new CompoundTag(); c.putString("pair", k); c.putInt("n", v); ps.add(c); });
        tag.put("plays", ps);
        ListTag ds = new ListTag();
        daily.forEach((k, v) -> {
            CompoundTag c = new CompoundTag();
            c.putString("id", k.toString());
            c.putLong("day", v[0]);
            c.putLong("coins", v[1]);
            ds.add(c);
        });
        tag.put("daily", ds);
        return tag;
    }
}
