package dev.cutemod.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * One online game of Durak between two players. The server keeps it and checks every move, so a player cannot cheat
 * and cannot see the other hand. No Minecraft classes in here, so it can be tested alone.
 * Cards 0..35: suit = card / 9 (0 spade, 1 heart, 2 diamond, 3 club), rank = card % 9 (6, 7, 8, 9, 10, J, Q, K, A).
 * The attacker plays a card, the defender beats it (a higher card of the same suit, or a trump) or takes everything.
 * When all cards are beaten the attacker may add a card of a rank that is already on the table, or say "done".
 * result: 0 playing, 1 player a won, 2 player b won, 3 draw. lastEvent: 0 nothing, 1 the round was beaten, 2 the defender took.
 */
public final class DurakMatch {
    public final UUID a, b;
    public final List<Integer> deck = new ArrayList<>(), handA = new ArrayList<>(), handB = new ArrayList<>();
    public final int[] atk = new int[6], def = new int[6];
    public int trumpCard, trump, attacker, n, limit, result, seq, lastEvent;
    private final Random rnd = new Random();

    public DurakMatch(UUID a, UUID b) {
        this.a = a;
        this.b = b;
        for (int i = 0; i < 36; i++) deck.add(i);
        Collections.shuffle(deck, rnd);
        trumpCard = deck.get(0);                                  // the bottom card shows the trump suit
        trump = suit(trumpCard);
        draw(handA);
        draw(handB);
        int la = lowestTrump(handA), lb = lowestTrump(handB);     // the lowest trump goes first, by lot if nobody has one
        attacker = (la < 0 && lb < 0) ? rnd.nextInt(2) : (la >= 0 && (lb < 0 || la < lb)) ? 0 : 1;
        startRound();
    }

    // ---------- helpers ----------
    public static int suit(int c) { return c / 9; }

    public static int rank(int c) { return c % 9; }

    private int lowestTrump(List<Integer> hand) {
        int best = -1;
        for (int c : hand) if (suit(c) == trump && (best < 0 || rank(c) < best)) best = rank(c);
        return best;
    }

    private void draw(List<Integer> hand) {
        while (hand.size() < 6 && !deck.isEmpty()) hand.add(deck.remove(deck.size() - 1));
    }

    private boolean canBeat(int d, int at) {
        if (suit(d) == suit(at)) return rank(d) > rank(at);
        return suit(d) == trump;
    }

    public boolean isA(UUID id) { return a.equals(id); }

    public UUID other(UUID id) { return isA(id) ? b : a; }

    public List<Integer> hand(UUID id) { return isA(id) ? handA : handB; }

    /** True if this player is the attacker of the round. */
    public boolean attacks(UUID id) { return (attacker == 0) == isA(id); }

    public int undefended() {
        for (int i = 0; i < n; i++) if (def[i] < 0) return i;
        return -1;
    }

    /** True if it is this player's move: the defender answers a card, the attacker plays or adds one. */
    public boolean myTurn(UUID id) {
        if (result != 0) return false;
        return undefended() >= 0 ? !attacks(id) : attacks(id);
    }

    private boolean rankOnTable(int r) {
        for (int i = 0; i < n; i++) {
            if (rank(atk[i]) == r) return true;
            if (def[i] >= 0 && rank(def[i]) == r) return true;
        }
        return false;
    }

    private List<Integer> attackerHand() { return attacker == 0 ? handA : handB; }

    private List<Integer> defenderHand() { return attacker == 0 ? handB : handA; }

    private void startRound() {
        n = 0;
        Arrays.fill(atk, -1);
        Arrays.fill(def, -1);
        limit = Math.min(6, defenderHand().size());
    }

    // ---------- moves (each returns whether it was allowed) ----------
    public boolean attack(UUID id, int card) {
        if (result != 0 || !attacks(id) || undefended() >= 0) return false;
        List<Integer> hand = hand(id);
        if (!hand.contains(card) || n >= limit) return false;
        if (n > 0 && !rankOnTable(rank(card))) return false;
        hand.remove((Integer) card);
        atk[n] = card;
        def[n] = -1;
        n++;
        lastEvent = 0;
        seq++;
        return true;
    }

    public boolean defend(UUID id, int card, int target) {
        if (result != 0 || attacks(id)) return false;
        if (target < 0 || target >= n || def[target] >= 0) return false;
        List<Integer> hand = hand(id);
        if (!hand.contains(card) || !canBeat(card, atk[target])) return false;
        hand.remove((Integer) card);
        def[target] = card;
        lastEvent = 0;
        seq++;
        if (undefended() < 0 && mustEnd()) finishRound(false, 1);
        return true;
    }

    /** All is beaten: nobody can add, so the round ends by itself. */
    private boolean mustEnd() {
        if (n >= limit || attackerHand().isEmpty() || defenderHand().isEmpty()) return true;
        for (int c : attackerHand()) if (rankOnTable(rank(c))) return false;
        return true;
    }

    public boolean take(UUID id) {
        if (result != 0 || attacks(id) || undefended() < 0) return false;
        List<Integer> hand = hand(id);
        for (int i = 0; i < n; i++) {
            hand.add(atk[i]);
            if (def[i] >= 0) hand.add(def[i]);
        }
        n = 0;
        finishRound(true, 2);
        return true;
    }

    /** The attacker has nothing more to add: the round is beaten. */
    public boolean done(UUID id) {
        if (result != 0 || !attacks(id) || n == 0 || undefended() >= 0) return false;
        finishRound(false, 1);
        return true;
    }

    public void resign(UUID id) {
        if (result != 0) return;
        result = isA(id) ? 2 : 1;
        seq++;
    }

    private void finishRound(boolean took, int event) {
        int old = attacker;
        n = 0;
        draw(old == 0 ? handA : handB);                           // the attacker draws first
        draw(old == 0 ? handB : handA);
        if (!took) attacker = 1 - old;
        lastEvent = event;
        seq++;
        if (deck.isEmpty() && (handA.isEmpty() || handB.isEmpty())) {
            result = handA.isEmpty() && handB.isEmpty() ? 3 : handA.isEmpty() ? 1 : 2;
            return;
        }
        startRound();
    }
}
