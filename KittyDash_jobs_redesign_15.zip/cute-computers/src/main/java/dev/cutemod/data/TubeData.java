package dev.cutemod.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * The videos the players have drawn and published in CuteTube (data/cutemod_tube.dat), kept on the SERVER:
 * a video is 2 to 12 Paint pictures (64 x 36, two pixels per byte, like the pictures of the mail), a title,
 * a speed and one of four tunes, plus the likes and the comments of the other players.
 */
public class TubeData extends SavedData {
    public static final int MIN_FRAMES = 2, MAX_FRAMES = 12, FRAME_BYTES = 1152, PALETTE = 14;
    public static final int MAX_TITLE = 24, MAX_COMMENT = 60, MAX_COMMENTS = 30, MAX_PER_PLAYER = 5, MAX_TOTAL = 150;

    public record Comment(String name, String text) {}

    public static final class Video {
        public final long id;
        public final UUID author;
        public final String authorName;
        public final String title;
        public final int fps, tune;
        public final List<byte[]> frames;
        public final long created;
        public final Set<UUID> likes = new HashSet<>();
        public final List<Comment> comments = new ArrayList<>();

        Video(long id, UUID author, String authorName, String title, int fps, int tune, List<byte[]> frames, long created) {
            this.id = id;
            this.author = author;
            this.authorName = authorName;
            this.title = title;
            this.fps = fps;
            this.tune = tune;
            this.frames = frames;
            this.created = created;
        }
    }

    private final List<Video> videos = new ArrayList<>();   // oldest first
    private long nextId = 1;

    public static TubeData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(new SavedData.Factory<>(TubeData::new, TubeData::load, null), "cutemod_tube");
    }

    /** The newest videos first. */
    public List<Video> newest(int max) {
        List<Video> out = new ArrayList<>();
        for (int i = videos.size() - 1; i >= 0 && out.size() < max; i--) out.add(videos.get(i));
        return out;
    }

    public Video find(long id) {
        for (Video v : videos) if (v.id == id) return v;
        return null;
    }

    public int countBy(UUID author) {
        int n = 0;
        for (Video v : videos) if (v.author.equals(author)) n++;
        return n;
    }

    /** Adds a video (the oldest one of everybody goes when the site is full). */
    public Video add(UUID author, String authorName, String title, int fps, int tune, List<byte[]> frames) {
        Video v = new Video(nextId++, author, authorName, title, fps, tune, new ArrayList<>(frames), System.currentTimeMillis());
        videos.add(v);
        while (videos.size() > MAX_TOTAL) videos.remove(0);
        setDirty();
        return v;
    }

    public boolean remove(long id) {
        boolean r = videos.removeIf(v -> v.id == id);
        if (r) setDirty();
        return r;
    }

    /** Removes every video of the author with this name (an operator command). Returns how many went. */
    public int removeByName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        int before = videos.size();
        videos.removeIf(v -> v.authorName.toLowerCase(Locale.ROOT).equals(n));
        if (videos.size() != before) setDirty();
        return before - videos.size();
    }

    // ---------- save / load ----------
    public static TubeData load(CompoundTag tag, HolderLookup.Provider registries) {
        TubeData d = new TubeData();
        d.nextId = Math.max(1, tag.getLong("next"));
        ListTag list = tag.getList("videos", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            try {
                List<byte[]> frames = new ArrayList<>();
                ListTag fl = c.getList("frames", Tag.TAG_COMPOUND);
                for (int k = 0; k < fl.size(); k++) {
                    byte[] b = fl.getCompound(k).getByteArray("d");
                    if (b.length == FRAME_BYTES) frames.add(b);
                }
                if (frames.size() < MIN_FRAMES) continue;
                Video v = new Video(c.getLong("id"), UUID.fromString(c.getString("author")), c.getString("authorName"),
                        c.getString("title"), c.getInt("fps"), c.getInt("tune"), frames, c.getLong("created"));
                for (Tag t : c.getList("likes", Tag.TAG_STRING)) {
                    try { v.likes.add(UUID.fromString(t.getAsString())); } catch (IllegalArgumentException ignored) { }
                }
                ListTag cl = c.getList("comments", Tag.TAG_COMPOUND);
                for (int k = 0; k < cl.size(); k++) v.comments.add(new Comment(cl.getCompound(k).getString("n"), cl.getCompound(k).getString("t")));
                d.videos.add(v);
            } catch (IllegalArgumentException ignored) {
            }
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putLong("next", nextId);
        ListTag list = new ListTag();
        for (Video v : videos) {
            CompoundTag c = new CompoundTag();
            c.putLong("id", v.id);
            c.putString("author", v.author.toString());
            c.putString("authorName", v.authorName);
            c.putString("title", v.title);
            c.putInt("fps", v.fps);
            c.putInt("tune", v.tune);
            c.putLong("created", v.created);
            ListTag fl = new ListTag();
            for (byte[] b : v.frames) {
                CompoundTag f = new CompoundTag();
                f.putByteArray("d", b);
                fl.add(f);
            }
            c.put("frames", fl);
            ListTag ll = new ListTag();
            for (UUID u : v.likes) ll.add(StringTag.valueOf(u.toString()));
            c.put("likes", ll);
            ListTag cl = new ListTag();
            for (Comment m : v.comments) {
                CompoundTag x = new CompoundTag();
                x.putString("n", m.name());
                x.putString("t", m.text());
                cl.add(x);
            }
            c.put("comments", cl);
            list.add(c);
        }
        tag.put("videos", list);
        return tag;
    }
}
