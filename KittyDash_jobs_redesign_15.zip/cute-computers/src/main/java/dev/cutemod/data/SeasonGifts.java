package dev.cutemod.data;

/**
 * What the season pass gives in the real game besides the reward on the computer: an item for the inventory.
 * One table for the client (to show it) and the server (to hand it out), pure logic, no Minecraft classes.
 * An id that starts with "cute_" is a unique item of the pass (renamed, shining, unbreakable); any other id is a
 * plain Minecraft item (minecraft:diamond ...).
 */
public final class SeasonGifts {
    private SeasonGifts() {}

    public static final int LEVELS = 30, LENGTH_DAYS = 28;

    public record Gift(String item, int count) {
        public boolean unique() { return item.startsWith("cute_"); }
    }

    /** The number of the running season (the same on the client and on the server: days since 1970 / 28). */
    public static int seasonNow() { return (int) (System.currentTimeMillis() / 86_400_000L / LENGTH_DAYS); }

    private static final Gift[] FREE = new Gift[LEVELS + 1];
    private static final Gift[] PREMIUM = new Gift[LEVELS + 1];

    private static void free(int level, String item, int n) { FREE[level] = new Gift(item, n); }

    private static void prem(int level, String item, int n) { PREMIUM[level] = new Gift(item, n); }

    static {
        free(3, "bread", 8);
        free(5, "iron_ingot", 6);
        free(8, "cookie", 8);
        free(10, "emerald", 2);
        free(13, "experience_bottle", 4);
        free(15, "gold_ingot", 4);
        free(18, "cake", 1);
        free(20, "diamond", 1);
        free(23, "golden_apple", 1);
        free(25, "diamond", 2);
        free(28, "emerald", 6);
        free(30, "diamond", 3);

        prem(1, "cookie", 6);
        prem(2, "cooked_beef", 8);
        prem(3, "golden_carrot", 8);
        prem(4, "experience_bottle", 6);
        prem(5, "honey_bottle", 2);
        prem(6, "emerald", 3);
        prem(7, "cake", 1);
        prem(8, "diamond", 1);
        prem(9, "name_tag", 1);
        prem(10, "cute_charm", 1);
        prem(11, "golden_apple", 1);
        prem(12, "emerald", 4);
        prem(13, "lapis_lazuli", 16);
        prem(14, "experience_bottle", 10);
        prem(15, "diamond", 2);
        prem(16, "golden_carrot", 16);
        prem(17, "emerald", 6);
        prem(18, "golden_apple", 2);
        prem(19, "diamond", 2);
        prem(20, "cute_crown", 1);
        prem(21, "experience_bottle", 16);
        prem(22, "emerald", 8);
        prem(23, "netherite_scrap", 1);
        prem(24, "diamond", 3);
        prem(25, "cute_pick", 1);
        prem(26, "golden_apple", 2);
        prem(27, "emerald", 10);
        prem(28, "totem_of_undying", 1);
        prem(29, "netherite_scrap", 1);
        prem(30, "cute_star", 1);
    }

    /** The item of this level and track, or null if the level has none. */
    public static Gift gift(int level, boolean premium) {
        if (level < 1 || level > LEVELS) return null;
        return premium ? PREMIUM[level] : FREE[level];
    }
}
