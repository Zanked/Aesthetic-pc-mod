package dev.cutemod.data;

import java.util.Random;

/**
 * The computer player of billiards. It tries many shots on a copy of the table (the same physics as the real game, see
 * {@link BilliardsTable}) and plays the best one, then adds a small aiming error that depends on the level. No Minecraft classes.
 * level: 0 easy, 1 normal, 2 hard.
 */
public final class BilliardsBot {
    private BilliardsBot() {}

    private static final int[] RANDOM_TRIES = {10, 24, 80};
    private static final float[][] POWERS = {{0.5f, 0.85f}, {0.45f, 0.7f, 1f}, {0.35f, 0.5f, 0.65f, 0.8f, 1f}};
    private static final double[] JITTER_DEG = {5.0, 1.6, 0.35};

    private record Shot(float dx, float dy, float power, float value) {}

    /** The shot to play: {dx, dy, power}. Never null: with the white ball gone it still returns a direction. */
    public static float[] best(BilliardsTable table, int who, int level, Random rnd) {
        level = Math.max(0, Math.min(2, level));
        BilliardsTable work = new BilliardsTable();
        Shot[] top = new Shot[3];
        int topN = level == 0 ? 3 : 1;                         // the easy bot takes one of its three best, the others the best
        float cx = table.x[0], cy = table.y[0];

        java.util.List<float[]> dirs = new java.util.ArrayList<>();
        for (int b = 1; b < BilliardsTable.N; b++) {
            if (!table.alive[b] || BilliardsMatch.owner(b) != who) continue;     // aim at our own balls only
            for (float[] p : BilliardsTable.POCKETS) {
                float tx = p[0] - table.x[b], ty = p[1] - table.y[b];
                float tl = (float) Math.sqrt(tx * tx + ty * ty);
                if (tl < 0.001f) continue;
                // the "ghost ball": where the white ball must be at the moment of the hit to send ball b to the pocket
                float gx = table.x[b] - tx / tl * BilliardsTable.BR * 2, gy = table.y[b] - ty / tl * BilliardsTable.BR * 2;
                float dx = gx - cx, dy = gy - cy;
                if (dx * dx + dy * dy < 1f) continue;
                dirs.add(new float[]{dx, dy});
            }
        }
        for (int i = 0; i < RANDOM_TRIES[level]; i++) {
            double a = rnd.nextDouble() * Math.PI * 2;
            dirs.add(new float[]{(float) Math.cos(a), (float) Math.sin(a)});
        }
        if (level == 0) java.util.Collections.shuffle(dirs, rnd);
        int limit = level == 0 ? 40 : Integer.MAX_VALUE;

        int tried = 0;
        for (float[] d : dirs) {
            if (tried++ >= limit) break;
            for (float pw : POWERS[level]) {
                work.copyFrom(table);
                if (!work.shoot(d[0], d[1], pw)) continue;
                work.runToRest();
                int own = 0, theirs = 0;
                for (int i = 1; i < BilliardsTable.N; i++) {
                    if ((work.pottedMask & (1 << i)) == 0) continue;
                    if (BilliardsMatch.owner(i) == who) own++; else theirs++;
                }
                float v = own * 10f - theirs * 12f - (work.scratch ? 18f : 0f) + (own > 0 && !work.scratch ? 3f : 0f)
                        + rnd.nextFloat() * 0.5f;
                if (own == 0 && !work.scratch && theirs == 0) v += 1f;       // a quiet miss is better than a gift
                insert(top, topN, new Shot(d[0], d[1], pw, v));
            }
        }
        Shot pick = null;
        int have = 0;
        for (int i = 0; i < topN; i++) if (top[i] != null) have++;
        if (have > 0) pick = top[rnd.nextInt(have)];
        float dx = 1, dy = 0, power = 0.5f;
        if (pick != null) { dx = pick.dx(); dy = pick.dy(); power = pick.power(); }
        double ang = Math.atan2(dy, dx) + Math.toRadians((rnd.nextDouble() * 2 - 1) * JITTER_DEG[level]);
        return new float[]{(float) Math.cos(ang), (float) Math.sin(ang), power};
    }

    private static void insert(Shot[] top, int n, Shot s) {
        for (int i = 0; i < n; i++) {
            if (top[i] == null || s.value() > top[i].value()) {
                for (int j = n - 1; j > i; j--) top[j] = top[j - 1];
                top[i] = s;
                return;
            }
        }
    }
}
