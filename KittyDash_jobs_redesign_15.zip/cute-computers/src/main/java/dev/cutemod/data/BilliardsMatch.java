package dev.cutemod.data;

import java.util.UUID;

/**
 * One game of billiards for two: the rules, shared by the online server ({@link UUID}s of the two players) and by the game against
 * the bot (the client uses the very same class, with no ids). No Minecraft classes, so it can be tested alone.
 * <p>
 * Rules: every player has five balls of their own (player 0 the odd numbers 1, 3, 5, 7, 9, player 1 the even ones, see
 * {@link #owner}). You shoot; if you pot at least one of YOUR balls you shoot again, otherwise the turn goes to the other player.
 * A ball of the other player that you pot is not lost: it counts for them. If the white ball drops, it comes back and the turn
 * goes to the other player. The first to have all five of their balls potted wins. After {@link #MAX_SHOTS} shots in all the
 * one with more balls potted wins (equal: a draw). score[p] = how many balls of player p are in the pockets.
 * result: 0 playing, 1 player 0 won, 2 player 1 won, 3 draw.
 */
public final class BilliardsMatch {
    public static final int MAX_SHOTS = 60, PER_PLAYER = 5;

    /** The player (0 or 1) who owns coloured ball {@code ball} (1..10). */
    public static int owner(int ball) { return (ball & 1) == 1 ? 0 : 1; }

    public final UUID p0, p1;
    public final BilliardsTable table = new BilliardsTable();
    public int turn;                       // 0 or 1: who shoots now
    public final int[] score = new int[2];
    public int result, shots;
    /** Goes up with every shot (and a resignation), so a client can tell that something new arrived. */
    public int seq;

    // the last shot, for the clients to replay: the table before it, the speed of the white ball, the table after it
    public float[] preXy = table.positions();
    public int preMask = table.aliveMask();
    public float shotVx, shotVy;
    public int shotSeq;                    // = seq of the last shot (0: none yet)
    public boolean lastScratch;
    public int lastPotted;                 // balls of the shooter that the last shot potted

    public BilliardsMatch(UUID p0, UUID p1) {
        this.p0 = p0;
        this.p1 = p1;
    }

    public boolean has(UUID id) { return p0 != null && p0.equals(id) || p1 != null && p1.equals(id); }

    public int indexOf(UUID id) { return p0 != null && p0.equals(id) ? 0 : 1; }

    public UUID other(UUID id) { return p0.equals(id) ? p1 : p0; }

    /** A player shoots. True if the shot was played (it was their turn and the numbers are sane). */
    public boolean shoot(int who, float dx, float dy, float power) {
        if (result != 0 || who != turn) return false;
        if (Float.isNaN(dx) || Float.isNaN(dy) || Float.isInfinite(dx) || Float.isInfinite(dy)) return false;
        BilliardsTable t = table;
        preXy = t.positions();
        preMask = t.aliveMask();
        if (!t.shoot(dx, dy, power)) return false;
        shotVx = t.vx[0]; shotVy = t.vy[0];
        t.runToRest();
        int own = 0;
        for (int i = 1; i < BilliardsTable.N; i++) {
            if ((t.pottedMask & (1 << i)) == 0) continue;
            score[owner(i)]++;
            if (owner(i) == who) own++;
        }
        lastPotted = own;
        lastScratch = t.scratch;
        shots++;
        if (t.scratch) t.respawnWhite();
        if (t.scratch || own == 0) turn = 1 - turn;
        if (score[0] >= PER_PLAYER || score[1] >= PER_PLAYER) {
            result = score[0] >= PER_PLAYER && score[1] >= PER_PLAYER ? 3 : score[0] >= PER_PLAYER ? 1 : 2;
        } else if (shots >= MAX_SHOTS) {
            result = score[0] > score[1] ? 1 : score[1] > score[0] ? 2 : 3;
        }
        seq++;
        shotSeq = seq;
        return true;
    }

    /** This player gives up (or left): the other one wins. Does nothing if the game is over. */
    public void resign(int who) {
        if (result != 0) return;
        result = who == 0 ? 2 : 1;
        seq++;
    }

    public void resign(UUID who) { if (has(who)) resign(indexOf(who)); }
}
