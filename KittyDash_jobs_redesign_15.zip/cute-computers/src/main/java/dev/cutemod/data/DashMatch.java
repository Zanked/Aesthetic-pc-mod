package dev.cutemod.data;

import java.util.UUID;

/**
 * One online Kitty Dash race between two players. No Minecraft classes, so it can be tested alone.
 * Both players run the same track (the same {@code seed}) at the same time. Every few ticks the client says how far it got,
 * the server keeps the numbers and forwards them to the other player, who sees them as a ghost kitty.
 * A run ends when the player crashes twice ({@link #finish}); when both are done the higher score wins.
 * A player who is still running can also finish early once they have passed the score of an opponent who is already done.
 * The server cannot replay a run, so it only keeps the numbers sane: score cannot grow faster than {@link #cap} allows,
 * attacks have a pause between them and there is a limit per race.
 */
public final class DashMatch {
    public static final long ATTACK_GAP_MS = 4_000L;
    public static final int MAX_ATTACKS = 12;
    public static final long STALE_MS = 12_000L;
    public static final int MAX_SCORE = 1_000_000;

    public final UUID[] id = new UUID[2];
    public final int seed;
    public final long start;
    /** 0 running, 1 the first player won, 2 the second won, 3 draw. */
    public int result;
    public final int[] score = new int[2], dist = new int[2], lane = new int[2], flags = new int[2], finalScore = new int[2];
    public final boolean[] done = new boolean[2];
    public final long[] seen = new long[2], lastProgress = new long[2], lastAttack = new long[2];
    /** Attacks that are coming TO player i. */
    public final int[] atkSeq = new int[2], atkKind = new int[2], atkCount = new int[2];

    public DashMatch(UUID a, UUID b, int seed, long now) {
        id[0] = a;
        id[1] = b;
        this.seed = seed;
        this.start = now;
        seen[0] = seen[1] = now;
    }

    public int indexOf(UUID u) { return id[0].equals(u) ? 0 : id[1].equals(u) ? 1 : -1; }

    public UUID other(UUID u) { return id[0].equals(u) ? id[1] : id[0]; }

    /** The most a score can be this long after the start (about four times what a good run earns). */
    public int cap(long now) {
        long sec = Math.max(0, now - start) / 1000L;
        return (int) Math.min(MAX_SCORE, 300 + 60 * sec);
    }

    /** Stores a progress report. False if it was ignored (too soon, or the race is over). */
    public boolean progress(int i, long now, int sc, int d, int l, int fl) {
        if (result != 0 || done[i] || now - lastProgress[i] < 80) return false;
        lastProgress[i] = now;
        seen[i] = now;
        score[i] = Math.max(score[i], Math.max(0, Math.min(sc, cap(now))));
        dist[i] = Math.max(dist[i], Math.max(0, Math.min(d, 5_000_000)));
        lane[i] = Math.max(0, Math.min(l, 200));
        flags[i] = fl & 31;
        return true;
    }

    /** An attack on the other player. False if it was refused. */
    public boolean attack(int i, int kind, long now) {
        int j = 1 - i;
        if (result != 0 || done[i] || done[j] || kind < 1 || kind > 2) return false;
        if (now - start < 4_000L || now - lastAttack[i] < ATTACK_GAP_MS || atkCount[i] >= MAX_ATTACKS) return false;
        lastAttack[i] = now;
        atkCount[i]++;
        atkSeq[j]++;
        atkKind[j] = kind;
        return true;
    }

    /** Player i is done with this score (crashed twice, or passed an opponent who was already done). */
    public void finish(int i, int sc, long now) {
        if (result != 0 || done[i]) return;
        done[i] = true;
        seen[i] = now;
        finalScore[i] = Math.max(0, Math.min(sc, cap(now)));
        score[i] = finalScore[i];
        if (done[0] && done[1]) result = finalScore[0] > finalScore[1] ? 1 : finalScore[1] > finalScore[0] ? 2 : 3;
    }

    /** The player gave up or left: the other one wins. */
    public void resign(UUID leaver) {
        int i = indexOf(leaver);
        if (i < 0 || result != 0) return;
        result = i == 0 ? 2 : 1;
    }

    /** A player who is not done and has said nothing for a long time has gone: the other wins. True if that changed the result. */
    public boolean checkStale(long now) {
        if (result != 0 || now - start < STALE_MS) return false;
        for (int i = 0; i < 2; i++) {
            if (!done[i] && now - seen[i] > STALE_MS) {
                result = i == 0 ? 2 : 1;
                return true;
            }
        }
        return false;
    }
}
