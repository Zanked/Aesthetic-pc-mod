package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Pong: you (pink plate, mouse) against a slime. Every return scores, every slime miss gives a bonus. */
public class SlimePong extends MiniGame {
    private static final int PW = 5, PH = 28, MARGIN = 6, BR = 3;

    private double py, ay, bx, by, vx, vy, speed;
    private int lives, rally, serveTimer, ticks;

    @Override
    public void reset() {
        score = 0; over = false; lives = 3; rally = 0; ticks = 0;
        speed = 1.8;
        py = ay = H / 2.0;
        serve(1);
    }

    private void serve(int dir) {
        bx = W / 2.0; by = H / 2.0;
        speed = 1.8;
        vx = dir * speed;
        vy = (rnd.nextDouble() - 0.5) * 1.6;
        serveTimer = 45;
    }

    @Override
    public void tick() {
        ticks++;
        double target = Math.max(PH / 2.0, Math.min(H - PH / 2.0, my));
        py += (target - py) * 0.4;
        if (serveTimer > 0) { serveTimer--; return; }

        // slime AI: limited speed, so steep fast balls get past it
        double aiSpeed = 1.1 + Math.min(rally, 10) * 0.06;
        double aim = vx > 0 ? by : H / 2.0;
        double d = aim - ay;
        ay += Math.max(-aiSpeed, Math.min(aiSpeed, d));
        ay = Math.max(PH / 2.0, Math.min(H - PH / 2.0, ay));

        for (int s = 0; s < 2; s++) {
            bx += vx / 2; by += vy / 2;
            if (by < BR) { by = BR; vy = Math.abs(vy); }
            if (by > H - BR) { by = H - BR; vy = -Math.abs(vy); }

            // player plate (left)
            if (vx < 0 && bx - BR <= MARGIN + PW && bx - BR >= MARGIN - 3
                    && Math.abs(by - py) <= PH / 2.0 + BR) {
                double rel = (by - py) / (PH / 2.0 + BR);
                speed = Math.min(3.6, speed + 0.12);
                double a = rel * 0.9;
                vx = speed * Math.cos(a);
                vy = speed * Math.sin(a);
                bx = MARGIN + PW + BR;
                score += 1; rally++;
                pling(1.0F + Math.min(rally, 10) * 0.05F);
            }
            // slime plate (right)
            if (vx > 0 && bx + BR >= W - MARGIN - PW && bx + BR <= W - MARGIN + 3
                    && Math.abs(by - ay) <= PH / 2.0 + BR) {
                double rel = (by - ay) / (PH / 2.0 + BR);
                double a = rel * 0.9;
                vx = -speed * Math.cos(a);
                vy = speed * Math.sin(a);
                bx = W - MARGIN - PW - BR;
                pling(0.8F);
            }
        }

        if (bx < -BR) {          // you missed
            lives--;
            beep();
            rally = 0;
            if (lives <= 0) over = true; else serve(1);
        } else if (bx > W + BR) { // the slime missed
            score += 10;
            pling(1.8F);
            serve(-1);
        }
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF1F3B2A, 0xFF2F6B45);
        for (int y = 4; y < H; y += 10) rect(g, W / 2 - 1, y, 2, 5, 0x44FFFFFF);

        // your plate
        rect(g, MARGIN, (int) py - PH / 2, PW, PH, 0xFFE58AAE);
        rect(g, MARGIN, (int) py - PH / 2, 1, PH, 0xFFFFB3CE);

        // the slime plate with eyes
        int sx = W - MARGIN - PW, sy = (int) ay - PH / 2;
        rect(g, sx - 1, sy, PW + 1, PH, 0xFF7ED957);
        rect(g, sx - 1, sy, 1, PH, 0xFFB6F59A);
        rect(g, sx, (int) ay - 5, 2, 2, 0xFF1B3A1B);
        rect(g, sx, (int) ay + 3, 2, 2, 0xFF1B3A1B);

        if (serveTimer > 0 && (serveTimer / 8) % 2 == 0) {
            disc(g, (int) bx, (int) by, BR + 1, 0x66FFFFFF);
        }
        disc(g, (int) bx, (int) by, BR, 0xFF3A2A3A);
        disc(g, (int) bx, (int) by, BR - 1, 0xFFFFFFFF);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public String hintKey() { return "cutemod.hint.pong"; }
}
