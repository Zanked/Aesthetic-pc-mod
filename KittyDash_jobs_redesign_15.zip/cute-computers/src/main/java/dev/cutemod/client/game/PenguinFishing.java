package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Blue computer: catch fish with the penguin, avoid pufferfish. */
public class PenguinFishing extends MiniGame {
    private double px;
    private int lives, spawn, t;
    private final List<double[]> items = new ArrayList<>(); // x, y, vy, type (0 fish, 1 puffer)

    @Override
    public void reset() {
        score = 0; over = false; lives = 3; spawn = 30; t = 0; px = W / 2.0;
        items.clear();
    }

    @Override
    public void tick() {
        t++;
        double target = Math.max(14, Math.min(W - 14, mx));
        px += (target - px) * 0.3;
        if (--spawn <= 0) {
            spawn = Math.max(18, 55 - score);
            boolean puffer = score >= 5 && rnd.nextInt(5) == 0;
            items.add(new double[]{12 + rnd.nextInt(W - 24), -8,
                    Math.min(2.6, 0.8 + score * 0.025 + rnd.nextDouble() * 0.4), puffer ? 1 : 0});
        }
        for (int i = items.size() - 1; i >= 0; i--) {
            double[] it = items.get(i);
            it[1] += it[2];
            boolean hit = it[1] > H - 34 && it[1] < H - 10 && Math.abs(it[0] - px) < 15;
            if (hit) {
                if (it[3] == 0) { score++; pling(1.3F); }
                else { lives--; beep(); }
                items.remove(i);
            } else if (it[1] > H - 4) {
                if (it[3] == 0) { lives--; beep(); }
                items.remove(i);
            }
        }
        if (lives <= 0) over = true;
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFFBFE6FF, 0xFF5AA8E8);
        for (int i = 0; i < 14; i++) { // snow
            int sx = (i * 37 + t / 2) % W, sy = (i * 53 + t) % H;
            rect(g, sx, sy, 2, 2, 0xCCFFFFFF);
        }
        rect(g, 0, H - 8, W, 8, 0xFFF4FBFF);
        rect(g, 0, H - 8, W, 2, 0xFFFFFFFF);
        for (double[] it : items) {
            int x = (int) it[0], y = (int) it[1];
            if (it[3] == 0) { // fish
                rect(g, x - 6, y - 3, 11, 6, 0xFFFF9B5E);
                rect(g, x + 5, y - 4, 3, 8, 0xFFE0753A);
                rect(g, x - 5, y - 2, 2, 2, 0xFF1A2A4A);
            } else { // pufferfish
                disc(g, x, y, 6, 0xFFE8D14A);
                for (int a = 0; a < 8; a++) {
                    int sx = (int) (Math.cos(a * Math.PI / 4) * 8), sy = (int) (Math.sin(a * Math.PI / 4) * 8);
                    rect(g, x + sx - 1, y + sy - 1, 2, 2, 0xFFB5481F);
                }
                rect(g, x - 3, y - 2, 2, 2, 0xFF1A2A4A);
                rect(g, x + 1, y - 2, 2, 2, 0xFF1A2A4A);
            }
        }
        // penguin
        int x = (int) px, y = H - 26;
        disc(g, x, y + 8, 11, 0xFF2C4D94);
        disc(g, x, y + 10, 7, 0xFFFFFFFF);
        rect(g, x - 5, y + 2, 3, 3, 0xFFFFFFFF);
        rect(g, x + 2, y + 2, 3, 3, 0xFFFFFFFF);
        rect(g, x - 4, y + 3, 2, 2, 0xFF14213F);
        rect(g, x + 2, y + 3, 2, 2, 0xFF14213F);
        rect(g, x - 2, y + 6, 4, 2, 0xFFFF9A1F);
        rect(g, x - 8, y + 18, 5, 2, 0xFFFF9A1F);
        rect(g, x + 3, y + 18, 5, 2, 0xFFFF9A1F);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public String hintKey() { return "cutemod.hint.penguin"; }
}
