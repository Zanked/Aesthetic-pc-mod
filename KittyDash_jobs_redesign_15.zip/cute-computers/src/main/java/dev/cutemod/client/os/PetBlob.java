package dev.cutemod.client.os;

/**
 * Reads the saved text of a pet (the blob "pet_&lt;color&gt;", written by PetApp.save) without opening the pet window,
 * so other apps can see how old it is, what character it has and whether it is sick.
 * Format: food fun energy sleeping age saved-at [feed play sleep pet [sick neglect]] (old saves are shorter).
 */
public final class PetBlob {
    private PetBlob() {}

    public record Info(long ageSec, int feed, int play, int sleep, int pet, boolean sick) {
        public int stage() { return PetArt.stageOf(ageSec); }
        public int trait() { return PetArt.traitOf(feed, play, sleep, pet); }
        public int ageMin() { return (int) Math.min(10_000_000L, ageSec / 60); }
    }

    /** The pet described by this text, or null if there is none (or the text is broken). */
    public static Info parse(String s) {
        if (s == null) return null;
        try {
            String[] a = s.trim().split("\\s+");
            if (a.length < 6) return null;
            long age = Math.max(0, Long.parseLong(a[4]));
            int feed = 0, play = 0, sleep = 0, pet = 0;
            if (a.length >= 10) {
                feed = Integer.parseInt(a[6]);
                play = Integer.parseInt(a[7]);
                sleep = Integer.parseInt(a[8]);
                pet = Integer.parseInt(a[9]);
            }
            boolean sick = a.length >= 12 && a[10].equals("1");
            return new Info(age, Math.max(0, feed), Math.max(0, play), Math.max(0, sleep), Math.max(0, pet), sick);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
