package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Cake Factory (in the spirit of the cake factory from the old Windows "Purble Place"). A cake rides a
 * conveyor belt through four stations: shape, batter, icing and topping. While the cake is inside a station
 * (it is lit up) click one of its three buttons, or press 1-2-3, to add that part. At the end of the belt the
 * cake is checked against the order in the top left corner. A right cake pays, a wrong or unfinished one costs
 * a heart. The belt gets faster with every cake. A shift is 90 seconds, three hearts.
 */
public class CakeFactory extends MiniGame {
    private static final int SHIFT = 5400;                       // 90 seconds
    private static final int[] ZX = {4, 58, 112, 166};          // left edge of every station
    private static final int ZW = 50;
    private static final int BELT_Y = 78;                        // top of the belt, the cakes stand on it
    private static final int BTN_Y = 98, BTN_W = 15, BTN_H = 28;
    private static final int[] FLAV = {0xFFF3E3B0, 0xFF7A4A2A, 0xFFF58FB8};
    private static final int[] ICING = {0xFFF58FB8, 0xFFFFFFFF, 0xFF8EC8F2};

    private final int[] want = new int[4];   // the order: shape, batter, icing, topping
    private final int[] have = new int[4];   // the cake on the belt, -1 = not added yet
    private final List<double[]> pops = new ArrayList<>(); // x, y, life, amount
    private boolean present, judged;
    private double cx, beltPhase;
    private int t, hearts, served, streak, gap, msgT;
    private String msg = "";
    private boolean msgGood;

    @Override
    public void reset() {
        score = 0;
        over = false;
        t = 0;
        hearts = 3;
        served = 0;
        streak = 0;
        gap = 30;
        msgT = 0;
        msg = "";
        present = false;
        judged = false;
        beltPhase = 0;
        pops.clear();
        Arrays.fill(have, -1);
        newOrder();
    }

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private static int mix(int argb, int target, float f) {
        int r = (int) (((argb >> 16) & 255) * (1 - f) + ((target >> 16) & 255) * f);
        int gr = (int) (((argb >> 8) & 255) * (1 - f) + ((target >> 8) & 255) * f);
        int b = (int) ((argb & 255) * (1 - f) + (target & 255) * f);
        return 0xFF000000 | r << 16 | gr << 8 | b;
    }

    private void say(String key, boolean good) { msg = tr(key); msgGood = good; msgT = 80; }

    private void newOrder() {
        for (int i = 0; i < 4; i++) want[i] = rnd.nextInt(3);
    }

    private double speed() { return Math.min(1.2, 0.5 + served * 0.035); }

    /** The station the cake is in right now, or -1 between two stations. */
    private int zoneOf() {
        if (!present || judged) return -1;
        for (int z = 0; z < 4; z++) if (cx >= ZX[z] + 6 && cx < ZX[z] + ZW - 6) return z;
        return -1;
    }

    // ---------- logic ----------
    @Override
    public void tick() {
        if (over) return;
        t++;
        if (msgT > 0) msgT--;
        if (gap > 0) {
            if (--gap == 0) {
                present = true;
                judged = false;
                cx = -16;
                served++;
                Arrays.fill(have, -1);
            }
        } else if (present) {
            double v = speed();
            cx += v;
            beltPhase += v;
            if (!judged && cx >= ZX[3] + ZW) judge();
            if (over) return;
            if (cx > W + 18) {
                present = false;
                gap = 40;
                newOrder();
            }
        }
        for (int i = pops.size() - 1; i >= 0; i--) {
            double[] p = pops.get(i);
            p[1] -= 0.4;
            if (--p[2] <= 0) pops.remove(i);
        }
        if (t >= SHIFT) over = true;
    }

    private void judge() {
        judged = true;
        boolean ok = true;
        for (int i = 0; i < 4; i++) if (have[i] != want[i]) ok = false;
        if (ok) {
            streak++;
            int pay = 10 + Math.min(5, streak - 1) + Math.min(5, served / 3);
            score += pay;
            pops.add(new double[]{ZX[3] + ZW / 2.0, BELT_Y - 36, 50, pay});
            say("cutemod.comfy.perfect", true);
            pling(1.2F + Math.min(streak, 10) * 0.05F);
        } else {
            hearts--;
            streak = 0;
            say("cutemod.comfy.wrong", false);
            beep();
            if (hearts <= 0) over = true;
        }
    }

    private void apply(int z, int k) {
        if (over) return;
        if (z < 0 || zoneOf() != z || have[z] != -1) { beep(); return; }
        have[z] = k;
        pling(0.9F + z * 0.15F + k * 0.1F);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        for (int z = 0; z < 4; z++) {
            for (int k = 0; k < 3; k++) {
                if (in(x, y, btnX(z, k), BTN_Y, BTN_W, BTN_H)) { apply(z, k); return true; }
            }
        }
        return false;
    }

    @Override
    public boolean key(int keyCode) {
        if (over) return false;
        if (keyCode >= 49 && keyCode <= 51) { apply(zoneOf(), keyCode - 49); return true; } // 1 2 3
        return false;
    }

    private static int btnX(int z, int k) { return ZX[z] + 1 + k * (BTN_W + 1); }

    // ---------- drawing ----------
    /** A cake standing on by. shape/flavor/icing/top = -1 means "not added yet". */
    private static void drawCake(GuiGraphics g, int cx, int by, int shape, int flavor, int icing, int top) {
        if (shape < 0) return;
        int body = flavor < 0 ? 0xFFE4DDD0 : FLAV[flavor];
        int dark = mix(body, 0x000000, 0.2F);
        int topY;
        int w;
        switch (shape) {
            case 0 -> { // round
                rect(g, cx - 11, by - 8, 22, 8, body);
                rect(g, cx - 9, by - 10, 18, 2, body);
                rect(g, cx - 11, by - 2, 22, 2, dark);
                topY = by - 10;
                w = 22;
            }
            case 1 -> { // square
                rect(g, cx - 13, by - 10, 26, 10, body);
                rect(g, cx - 13, by - 2, 26, 2, dark);
                topY = by - 10;
                w = 28;
            }
            default -> { // two tiers
                rect(g, cx - 13, by - 8, 26, 8, body);
                rect(g, cx - 13, by - 2, 26, 2, dark);
                rect(g, cx - 8, by - 16, 16, 8, body);
                rect(g, cx - 8, by - 10, 16, 2, dark);
                topY = by - 16;
                w = 18;
            }
        }
        if (icing >= 0) {
            int ic = ICING[icing];
            rect(g, cx - w / 2, topY - 3, w, 4, ic);
            rect(g, cx - w / 2 + 3, topY + 1, 2, 3, ic);
            rect(g, cx + w / 2 - 5, topY + 1, 2, 4, ic);
            topY -= 3;
        }
        if (top >= 0) drawTopping(g, cx, topY, top);
    }

    private static void drawTopping(GuiGraphics g, int cx, int y, int k) {
        switch (k) {
            case 0 -> { // cherry
                disc(g, cx, y - 2, 3, 0xFFE5484D);
                rect(g, cx, y - 7, 1, 3, 0xFF2A7A3A);
                rect(g, cx - 1, y - 3, 1, 1, 0xFFFFFFFF);
            }
            case 1 -> { // sprinkles
                rect(g, cx - 7, y, 3, 1, 0xFFE5484D);
                rect(g, cx - 3, y - 1, 3, 1, 0xFF2F7FD6);
                rect(g, cx + 1, y, 3, 1, 0xFFF3D46A);
                rect(g, cx + 5, y - 1, 3, 1, 0xFF5BBF6A);
            }
            default -> { // candle
                rect(g, cx - 1, y - 7, 2, 7, 0xFFF3E6FF);
                rect(g, cx - 1, y - 5, 2, 1, 0xFFE5484D);
                rect(g, cx - 1, y - 11, 2, 3, 0xFFFFA020);
                rect(g, cx, y - 12, 1, 1, 0xFFFFE680);
            }
        }
    }

    private void drawIcon(GuiGraphics g, int z, int k, int x, int y) {
        switch (z) {
            case 0 -> { // shapes
                int c = 0xFFE4DDD0;
                if (k == 0) { rect(g, x + 3, y + 10, 9, 6, c); rect(g, x + 4, y + 9, 7, 1, c); }
                else if (k == 1) rect(g, x + 2, y + 9, 11, 7, c);
                else { rect(g, x + 2, y + 12, 11, 4, c); rect(g, x + 4, y + 8, 7, 4, c); }
            }
            case 1 -> { // batter
                rect(g, x + 3, y + 7, 9, 9, FLAV[k]);
                rect(g, x + 3, y + 14, 9, 2, mix(FLAV[k], 0x000000, 0.2F));
            }
            case 2 -> { // icing
                rect(g, x + 2, y + 8, 11, 6, ICING[k]);
                rect(g, x + 3, y + 14, 2, 3, ICING[k]);
                rect(g, x + 9, y + 14, 2, 2, ICING[k]);
            }
            default -> drawTopping(g, x + 7, y + 17, k);
        }
    }

    @Override
    public void render(GuiGraphics g) {
        int zone = zoneOf();
        // the factory: pastel wall, stations, belt, button panel
        g.fillGradient(0, 0, W, BELT_Y, 0xFFFFE3EE, 0xFFFFC9DF);
        for (int x = 4; x < W; x += 22) rect(g, x, 2, 1, 44, 0x22FFFFFF);
        for (int z = 0; z < 4; z++) {
            rect(g, ZX[z] - 1, 48, 1, BELT_Y - 48, 0x33FFFFFF);
            if (zone == z && have[z] == -1) rect(g, ZX[z], 48, ZW, BELT_Y - 48, 0x44FFE680);
            else rect(g, ZX[z], 48, ZW, BELT_Y - 48, 0x18FFFFFF);
        }
        rect(g, 0, BELT_Y, W, 8, 0xFF4A4A5A);
        rect(g, 0, BELT_Y, W, 2, 0xFF6A6A7A);
        int off = (int) beltPhase % 12;
        for (int x = -12 + off; x < W; x += 12) rect(g, x, BELT_Y + 4, 5, 1, 0xFF8A8A9A);
        rect(g, 0, BELT_Y + 8, W, H - BELT_Y - 8, 0xFF5A3A28);
        rect(g, 0, BELT_Y + 8, W, 2, 0xFF7A5A40);

        // the order
        rect(g, 4, 2, 62, 44, 0xFF3A2A3A);
        rect(g, 5, 3, 60, 42, 0xFFFFFFFF);
        ctext(g, tr("cutemod.comfy.order"), 35, 4, 0xFF3A2A3A);
        drawCake(g, 35, 44, want[0], want[1], want[2], want[3]);

        if (present) drawCake(g, (int) Math.round(cx), BELT_Y, have[0], have[1], have[2], have[3]);

        // buttons
        for (int z = 0; z < 4; z++) {
            boolean live = zone == z && have[z] == -1;
            for (int k = 0; k < 3; k++) {
                int x = btnX(z, k);
                boolean on = in(mx, my, x, BTN_Y, BTN_W, BTN_H);
                int bg = have[z] == k && present && !judged ? 0xFFFFD866 : live ? (on ? 0xFF9A7A5A : 0xFF86664A) : on ? 0xFF7A5A40 : 0xFF6A4A34;
                rect(g, x, BTN_Y, BTN_W, BTN_H, bg);
                drawIcon(g, z, k, x, BTN_Y);
                ctext(g, Integer.toString(k + 1), x + BTN_W / 2, BTN_Y + 19, live ? 0xFFFFFFFF : 0xFFD8C0A0);
            }
            ctext(g, tr("cutemod.comfy.zone." + z), ZX[z] + ZW / 2, BTN_Y + BTN_H + 4, zone == z ? 0xFFFFE680 : 0xFFD8C0A0);
        }

        for (double[] p : pops) {
            ctext(g, "+" + (int) p[3], (int) p[0], (int) p[1], (int) p[2] < 12 ? 0xAAFFE680 : 0xFFFFE680);
        }
        if (msgT > 0) ctext(g, msg, 142, 20, msgGood ? 0xFF3FA85A : 0xFFE0566A);
        if (streak >= 2) ctext(g, "x" + streak, W - 14, 4, 0xFFE0566A);
    }

    @Override
    public Component status() {
        return Component.translatable("cutemod.comfy.status", score, Math.max(0, hearts), Math.max(0, (SHIFT - t + 59) / 60));
    }

    @Override
    public boolean isWin() { return over && hearts > 0; }

    @Override
    public Component endTitle() {
        return Component.translatable(hearts > 0 ? "cutemod.comfy.end_day" : "cutemod.comfy.end_closed");
    }

    @Override
    public String hintKey() { return "cutemod.hint.cakefactory"; }
}
