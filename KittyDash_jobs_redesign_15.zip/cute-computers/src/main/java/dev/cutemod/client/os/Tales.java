package dev.cutemod.client.os;

import java.util.List;

/**
 * The tales of the book app. The texts are in the lang files (cutemod.tale.<id>.title, .s1 ... .s5), the author is
 * cutemod.tale.author.<author>. Every scene has a picture, written for {@link BookArt}. All the texts are short retellings
 * in our own words; the stories themselves are old folk and literary tales that belong to everybody.
 */
public final class Tales {
    private Tales() {}

    public static final int SCENES = 5;

    /** cover = colour of the book, prop = the picture on the cover (size in percent). */
    public record Tale(String id, String author, int cover, String prop, int propSize, String[] pictures) {}

    public static final List<Tale> ALL = List.of(
            new Tale("duckling", "andersen", 0xFF4F8FC8, "swan", 120, new String[]{
                    "day;sun@102,14;cloud@34,16;reeds@106,62;duck@32,60,130;ducklings@62,60;duckling@92,60,115",
                    "day;cloud@82,14;bush@12,58;duckling@36,60,125;duck<@92,60,115;duck<@62,56,70",
                    "dusk;reeds@16,62;reeds@102,64;pond@60,68;duckling@58,64,115;star@20,10;star@96,16",
                    "snow;pine@16,60;pine@104,58;snowflakes@60,40;duckling@60,62,115",
                    "day;sun@102,14;cloud@28,16;tree@12,58;flower@106,60;pond@60,68;swan@60,64,150"}),
            new Tale("mermaid", "andersen", 0xFF2E8A9A, "mermaid", 120, new String[]{
                    "deep;castle@94,62,80;coral@14,62;seaweed@42,64;mermaid@58,60,120;fish@22,30;bubbles@78,34",
                    "sea;sun@100,22;cloud@30,12;ship@84,44;mermaid@32,54,110;foam@32,56;foam@10,58",
                    "sea;rock@100,52;prince@62,52;mermaid@34,56,110;foam@34,58;foam@74,56;cloud@50,12",
                    "deep;coral@104,62;seaweed@16,64;witch@80,62;mermaid@38,60,115;bubbles@60,30;shell@60,62",
                    "sea;sun@40,32;fairy@82,40;foam@58,57;foam@96,60;foam@20,60;cloud@100,12"}),
            new Tale("pea", "andersen", 0xFFA66AC0, "princess", 150, new String[]{
                    "day;castle@88,60,90;prince@32,60;tree@10,58;sun@104,14",
                    "night;castle@28,60,80;rain@64,50;rain@106,52;princess@86,60;cloud@84,12",
                    "room;bed@62,56,95;queen@22,60;pea@100,58,200",
                    "room;bed@44,56;princess@92,60;windowlight@108,36",
                    "hall;prince@42,64;princess@74,64;star@18,22;star@100,20"}),
            new Tale("thumbelina", "andersen", 0xFFD9689A, "bigflower", 100, new String[]{
                    "day;sun@102,14;cloud@24,14;bigflower@60,62;thumbelina@60,46,55",
                    "night;pond@72,68;toad@30,62,140;thumbelina@92,60,60;moon@100,16;star@20,10",
                    "day;pond@60,68;reeds@14,62;reeds@106,62;fish@28,64;thumbelina@62,60,60;cloud@80,12",
                    "snow;pine@102,58;swallow@44,60,170;thumbelina@76,58,60;snowflakes@60,40",
                    "day;sun@102,16;cloud@26,16;bigflower@100,62,80;swallow@50,42,200;thumbelina@54,36,50"}),
            new Tale("redhood", "grimm", 0xFFC0392B, "redhood", 130, new String[]{
                    "day;cottage@88,58;redhood@34,60;flower@14,60;flower@58,62;sun@104,12",
                    "forest;redhood@34,60;wolf<@88,60,110;bush@108,58",
                    "day;cottage@58,58,120;wolf<@100,60,90;flower@16,62;cloud@28,14",
                    "room;crowdbed@70,58,130;wolf@70,44,55;redhood@20,60;windowlight@104,34",
                    "day;cottage@82,58,110;redhood@30,60;grandma@52,60;flower@110,62;sun@16,14"}),
            new Tale("hansel", "grimm", 0xFFC8884A, "candyhouse", 90, new String[]{
                    "forest;hansel@34,60;gretel@54,60;crumbs@86,58;tree@110,58",
                    "night;pine@14,58;hansel@50,60;gretel@70,60;pine@106,58;moon@94,16",
                    "forest;candyhouse@72,58,115;hansel@22,60;gretel@42,60",
                    "room;oven@90,56;witch@38,58;gretel@62,58",
                    "day;cottage@80,58,110;hansel@28,60;gretel@50,60;sun@16,14;cloud@60,12"}),
            new Tale("snowwhite", "grimm", 0xFF3A6AB0, "apple", 220, new String[]{
                    "hall;queen@34,64;mirror@84,58",
                    "forest;snowwhite@50,60;bush@16,58;tree@104,58",
                    "forest;cottage@32,58,100;dwarf@62,60,70;dwarf@72,60,70;dwarf@82,60,70;dwarf@92,60,70;snowwhite@108,60",
                    "forest;oldwoman@32,60;snowwhite@80,60;apple@56,50,170",
                    "hall;prince@44,64;snowwhite@74,64;star@20,20;star@100,24"}),
            new Tale("bremen", "grimm", 0xFF6A7A5A, "donkey", 140, new String[]{
                    "day;donkey@42,60,125;tree@104,58;sun@100,14;cloud@30,14",
                    "day;donkey@24,60,90;dog@50,60,90;cat@78,60,90;rooster@102,60,90;cloud@60,12",
                    "night;glowhouse@92,58,100;donkey@38,60,105;dog@38,42,80;cat@38,30,65;rooster@38,19,55;moon@100,14",
                    "night;glowhouse@88,58,110;rooster@30,60,110;star@20,16;star@54,24;moon@100,14",
                    "day;cottage@62,58,110;donkey@20,60,75;dog@104,60,75;cat@36,60,70;sun@100,14"}),
            new Tale("cinderella", "perrault", 0xFF5FA0D8, "slipper", 260, new String[]{
                    "room;cinderella_rag@50,60;mouse@86,58;windowlight@104,34",
                    "night;pumpkin@38,60;fairy@82,60;star@20,16;star@100,20;moon@96,12",
                    "night;coach@46,58,115;mouse@88,58;fairy@104,60;star@16,18;moon@100,12",
                    "hall;prince@44,64;cinderella@74,64;clock@104,36;star@18,24",
                    "hall;slipper@60,58,210;prince@22,64;cinderella@98,64"}),
            new Tale("puss", "perrault", 0xFFD8782A, "puss", 150, new String[]{
                    "day;cottage@92,58;puss@42,60,115;sack@16,60;cloud@50,14",
                    "hall;king@78,64;puss@34,64,115;sack@56,62",
                    "day;pond@58,66;king@100,60;puss@28,60,115;cloud@44,14;sun@100,12",
                    "day;castle@98,60,92;ogre@62,60,110;puss@26,60,105",
                    "hall;king@22,64;prince@52,64;princess@76,64;puss@100,64,115"}),
            new Tale("fisherman", "pushkin", 0xFF2A5A8A, "goldfish", 170, new String[]{
                    "sea;boat@50,57,130;oldman@50,50,70;goldfish@92,60,100;foam@96,63;foam@20,62;cloud@40,12",
                    "room;oldwoman@40,60;trough@86,58,180;windowlight@106,34",
                    "day;cottage@62,58,125;oldwoman@24,60;oldman@100,60;sun@100,12",
                    "day;castle@70,60,92;oldwoman@24,60;cloud@36,12;sun@104,14",
                    "storm;oldman@26,60;goldfish@72,52,90;lightning@100,36;rain@60,50"}),
            new Tale("kolobok", "folk", 0xFFB8883A, "bun", 190, new String[]{
                    "room;grandma@40,60;bun@86,56,125;windowlight@106,34",
                    "day;bush@108,58;tree@12,58;bun@38,60,125;hare<@88,60,115;cloud@64,14",
                    "forest;bun@30,60,115;wolf<@72,60,105;bear<@102,60,90",
                    "day;bun@34,60,125;fox<@86,60,125;tree@110,58;cloud@44,14",
                    "dusk;fox@58,60,125;tree@102,58;sun@22,30"}));
}
