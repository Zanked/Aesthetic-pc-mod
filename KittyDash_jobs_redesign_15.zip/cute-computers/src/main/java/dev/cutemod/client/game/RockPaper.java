package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Rock Paper Scissors against the computer. Every win adds a point, a draw changes nothing, one loss ends the streak. */
public class RockPaper extends MiniGame {
    private static final int BW = 62, BH = 34, BY = 100, GAP = 10, BX = (W - 3 * BW - 2 * GAP) / 2;
    private int pick, bot, timer, result;   // result: 0 draw, 1 win, 2 loss

    @Override
    public void reset() {
        score = 0; over = false; pick = -1; bot = -1; timer = 0; result = 0;
    }

    private void choose(int p) {
        if (timer > 0 || over || p < 0 || p > 2) return;
        pick = p; bot = rnd.nextInt(3);
        result = pick == bot ? 0 : (pick - bot + 3) % 3 == 1 ? 1 : 2;
        timer = 45;
        if (result == 1) { score++; pling(1.3F); sound(net.minecraft.sounds.SoundEvents.AMETHYST_BLOCK_CHIME, 1.4F, 0.6F); }
        else if (result == 2) { beep(); sound(net.minecraft.sounds.SoundEvents.VILLAGER_NO, 1.1F, 0.5F); }
        else pling(0.9F);
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < 3; i++) if (in(x, y, BX + i * (BW + GAP), BY, BW, BH)) choose(i);
        return true;
    }

    @Override
    public boolean key(int keyCode) {
        if (keyCode >= 49 && keyCode <= 51) { choose(keyCode - 49); return true; }
        return false;
    }

    @Override
    public void tick() {
        if (timer > 0 && --timer == 0) {
            if (result == 2) over = true;
            pick = -1; bot = -1;
        }
    }

    /** A hand: 0 rock, 1 paper, 2 scissors, centred on cx, cy. */
    private static void hand(GuiGraphics g, int type, int cx, int cy, int r) {
        switch (type) {
            case 0 -> { disc(g, cx, cy, r, 0xFF8A8F9C); disc(g, cx - r / 3, cy - r / 3, r / 3, 0xFFB4B9C6); }
            case 1 -> { rect(g, cx - r, cy - r, r * 2, r * 2, 0xFFFFFFFF); for (int i = 0; i < 3; i++) rect(g, cx - r + 4, cy - r + 5 + i * (r * 2 - 10) / 3, r * 2 - 8, 2, 0xFFC8CCD8); }
            default -> {
                for (int k = -r; k <= r; k++) {
                    rect(g, cx + k - 1, cy + k * 7 / 10 - 1, 3, 3, 0xFFE0594F);
                    rect(g, cx + k - 1, cy - k * 7 / 10 - 1, 3, 3, 0xFFE0594F);
                }
                disc(g, cx, cy, 3, 0xFF3A2A3A);
            }
        }
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF4A3A78, 0xFF251C46);
        int lx = W / 4, rx = W * 3 / 4;
        rect(g, lx - 30, 14, 60, 60, 0x33000000); rect(g, rx - 30, 14, 60, 60, 0x33000000);
        if (pick >= 0) { hand(g, bot, lx, 44, 18); hand(g, pick, rx, 44, 18); }
        else { ctext(g, "?", lx, 40, 0xFFFFFFFF); ctext(g, "?", rx, 40, 0xFFFFFFFF); }
        ctext(g, "VS", W / 2, 40, 0xFFFFD866);
        if (pick >= 0) {
            String s = Component.translatable(result == 1 ? "cutemod.rps.win" : result == 2 ? "cutemod.rps.lose" : "cutemod.rps.draw").getString();
            ctext(g, s, W / 2, 80, result == 1 ? 0xFFB6FFC8 : result == 2 ? 0xFFFF9AA8 : 0xFFFFFFFF);
        }
        for (int i = 0; i < 3; i++) {
            int x = BX + i * (BW + GAP);
            boolean hov = in(mx, my, x, BY, BW, BH);
            rect(g, x, BY, BW, BH, hov ? 0xFF7A66C8 : 0xFF5A4AA0);
            rect(g, x, BY, BW, 2, 0x44FFFFFF);
            hand(g, i, x + BW / 2, BY + BH / 2, 10);
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score", score); }

    @Override
    public String hintKey() { return "cutemod.hint.rps"; }
}
