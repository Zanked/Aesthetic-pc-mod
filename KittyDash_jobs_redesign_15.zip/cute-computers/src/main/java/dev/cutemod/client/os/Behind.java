package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.core.Holder;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;

/**
 * Part 3, chapter 3 ("Look Back"): the player closes the computer at night, waits, and a sound comes from
 * BEHIND them (a vanilla sound played at a point three blocks behind the player). If they turn around to face it
 * in time, the chapter is done. Nothing is spawned and nothing is changed in the world, it is only a sound.
 * The client tick calls {@link #tick()} (see ClientHooks), ComputerScreen calls {@link #onLeave()}.
 */
public final class Behind {
    private static int timer = -1;            // ticks until the sound; -1 = nothing is going to happen
    private static int window;                // ticks left to turn around after the sound
    private static float soundYaw;            // where the player looked when the sound came
    private static double sx, sy, sz;         // where it came from

    private Behind() {}

    private static SoundEvent sv(SoundEvent e) { return e; }

    private static SoundEvent sv(Holder<SoundEvent> h) { return h.value(); }

    /** The player has closed the computer (not just a link dialog). */
    public static void onLeave() {
        timer = -1;
        window = 0;
        if (!Haunt.scary || !Progress.questDone() || Progress.step3() != 2) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        long dt = mc.level.getDayTime() % 24000L;
        if (dt < 13000L || dt > 23000L) return;          // only at night
        timer = 160 + mc.level.random.nextInt(120);      // 8 to 14 seconds of silence
    }

    public static void tick() {
        if (timer < 0 && window <= 0) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.screen instanceof dev.cutemod.client.ComputerScreen) {
            timer = -1;                                   // back at the computer: nothing happens
            window = 0;
            return;
        }
        if (timer > 0 && --timer == 0) {
            timer = -1;
            soundYaw = mc.player.getYRot();
            double rad = Math.toRadians(soundYaw);
            sx = mc.player.getX() + Math.sin(rad) * 3.0;  // forward is (-sin, cos), so behind is (+sin, -cos)
            sz = mc.player.getZ() - Math.cos(rad) * 3.0;
            sy = mc.player.getY();
            mc.level.playLocalSound(sx, sy, sz, sv(SoundEvents.AMBIENT_CAVE), SoundSource.AMBIENT, 1.0F, 0.6F, false);
            mc.level.playLocalSound(sx, sy, sz, sv(SoundEvents.ENDERMAN_AMBIENT), SoundSource.AMBIENT, 0.5F, 0.5F, false);
            window = 240;                                 // 12 seconds to look
            return;
        }
        if (window > 0) {
            window--;
            float turned = Math.abs(Mth.wrapDegrees(mc.player.getYRot() - soundYaw));
            if (turned >= 120F) {                         // they are facing the place the sound came from
                window = 0;
                mc.level.playLocalSound(sx, sy, sz, sv(SoundEvents.ENDERMAN_TELEPORT), SoundSource.AMBIENT, 0.4F, 0.5F, false);
                Progress.advance3(2);
            }
        }
    }
}
