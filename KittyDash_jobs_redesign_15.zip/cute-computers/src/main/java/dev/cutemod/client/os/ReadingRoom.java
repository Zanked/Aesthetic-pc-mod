package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.Level;

import java.time.LocalTime;

/**
 * The cosy room around the book of the Fairy Tales app: a wooden table, a warm lamp over the book, a breathing candle flame,
 * glowing dust in the air, a window with the sun or the moon, the blue of the night, and the little decorations of the pages
 * (flourishes, drop caps, corners). Everything is drawn with rectangles, like the rest of the computer.
 */
final class ReadingRoom {
    private ReadingRoom() {}

    private static void r(GuiGraphics g, int x, int y, int w, int h, int c) { g.fill(x, y, x + w, y + h, c); }

    private static int mix(int a, int b, float t) {
        int aa = a >>> 24, ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255;
        int ba = b >>> 24, br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
        return (int) (aa + (ba - aa) * t) << 24 | (int) (ar + (br - ar) * t) << 16 | (int) (ag + (bg - ag) * t) << 8 | (int) (ab + (bb - ab) * t);
    }

    static int argb(float alpha, int rgb) { return Math.max(0, Math.min(255, Math.round(alpha * 255F))) << 24 | (rgb & 0xFFFFFF); }

    /** An opaque colour between two RGB colours (the alpha of both is ignored). */
    static int tint(int from, int to, float t) {
        int fr = from >> 16 & 255, fg = from >> 8 & 255, fb = from & 255;
        int tr = to >> 16 & 255, tg = to >> 8 & 255, tb = to & 255;
        return 0xFF000000 | (int) (fr + (tr - fr) * t) << 16 | (int) (fg + (tg - fg) * t) << 8 | (int) (fb + (tb - fb) * t);
    }

    /** The look of a tale's pages: 0 = the sea, 1 = the forest, 2 = the palace, 3 = the garden and the pond, 4 = the folk tale (a sun). */
    static int themeOf(String id) {
        return switch (id) {
            case "mermaid", "fisherman" -> 0;
            case "redhood", "hansel", "snowwhite", "bremen" -> 1;
            case "pea", "cinderella", "puss" -> 2;
            case "thumbelina", "duckling" -> 3;
            default -> 4;
        };
    }

    /** A little emblem of a theme, 5x5 pixels around (cx, cy): a wave, a leaf, a star, a flower, a sun. */
    static void motif(GuiGraphics g, int theme, int cx, int cy, int color) {
        switch (theme) {
            case 0 -> {                                                                 // a wave and a bubble
                r(g, cx - 2, cy + 1, 1, 1, color); r(g, cx - 1, cy, 2, 1, color); r(g, cx + 1, cy + 1, 1, 1, color);
                r(g, cx + 2, cy, 1, 1, color); r(g, cx, cy - 2, 1, 1, color);
            }
            case 1 -> {                                                                 // a leaf
                r(g, cx, cy - 2, 1, 5, color); r(g, cx - 1, cy - 1, 1, 2, color); r(g, cx + 1, cy - 1, 1, 2, color);
            }
            case 2 -> {                                                                 // a four-pointed star
                r(g, cx - 2, cy, 5, 1, color); r(g, cx, cy - 2, 1, 5, color);
                r(g, cx - 1, cy - 1, 1, 1, color); r(g, cx + 1, cy - 1, 1, 1, color);
                r(g, cx - 1, cy + 1, 1, 1, color); r(g, cx + 1, cy + 1, 1, 1, color);
            }
            case 3 -> {                                                                 // a flower
                r(g, cx, cy - 2, 1, 1, color); r(g, cx, cy + 2, 1, 1, color); r(g, cx - 2, cy, 1, 1, color); r(g, cx + 2, cy, 1, 1, color);
                r(g, cx - 1, cy - 1, 1, 1, color); r(g, cx + 1, cy - 1, 1, 1, color);
                r(g, cx - 1, cy + 1, 1, 1, color); r(g, cx + 1, cy + 1, 1, 1, color);
                r(g, cx, cy, 1, 1, 0xFFFFC832);
            }
            default -> {                                                                // a sun
                r(g, cx - 1, cy - 1, 3, 3, color);
                r(g, cx, cy - 2, 1, 1, color); r(g, cx, cy + 2, 1, 1, color); r(g, cx - 2, cy, 1, 1, color); r(g, cx + 2, cy, 1, 1, color);
                r(g, cx - 2, cy - 2, 1, 1, color); r(g, cx + 2, cy - 2, 1, 1, color);
                r(g, cx - 2, cy + 2, 1, 1, color); r(g, cx + 2, cy + 2, 1, 1, color);
            }
        }
    }

    /** A dotted rule with the emblem of the tale in the middle: it runs along the top of every page. */
    static void runner(GuiGraphics g, int x, int y, int w, int color, int theme) {
        int mid = x + w / 2;
        for (int i = 0; i < w; i += 2) if (Math.abs(x + i - mid) > 5) r(g, x + i, y, 1, 1, color);
        motif(g, theme, mid, y, color);
    }

    /** A faint pattern of the theme inside a plate (waves, leaves, dots of a lattice, scattered flowers, dotted stripes). */
    static void pattern(GuiGraphics g, int theme, int x, int y, int w, int h, int c) {
        for (int yy = 2; yy < h - 2; yy++) {
            for (int xx = 2; xx < w - 2; xx++) {
                boolean on = switch (theme) {
                    case 0 -> (yy + (int) Math.round(Math.sin(xx * 0.9) * 1.2)) % 5 == 0;
                    case 1 -> Math.abs(xx % 6 - 3) == yy % 4;
                    case 2 -> (xx + yy) % 6 == 0 && (xx - yy + 60) % 6 == 0;
                    case 3 -> (xx * 7 + yy * 13) % 11 == 0;
                    default -> yy % 4 == 0 && xx % 2 == 0;
                };
                if (on) r(g, x + xx, y + yy, 1, 1, c);
            }
        }
    }

    static int hash(int n) {
        n ^= n >>> 15; n *= 0x2C1B3C6D; n ^= n >>> 12; n *= 0x297A2D39; n ^= n >>> 15;
        return n & 0x7FFFFFFF;
    }

    /** Time for the animations, about 60 steps per second whatever the tick rate is. */
    static float clock() { return (System.currentTimeMillis() % 3_600_000L) / 16.667F; }

    // ---------- day and night ----------
    /** 0 = day, 1 = night. By the time of the Minecraft world (dusk 11500-13500, dawn 22500-24000); without a world by the real clock. */
    static float nightness() {
        long dt;
        Level lvl = Minecraft.getInstance().level;
        if (lvl != null) dt = Math.floorMod(lvl.getDayTime(), 24000L);
        else {
            LocalTime now = LocalTime.now();
            dt = (((now.getHour() * 60L + now.getMinute()) * 24000L / 1440L) + 18000L) % 24000L;     // 6:00 = sunrise = tick 0
        }
        if (dt < 11500) return 0F;
        if (dt < 13500) return (dt - 11500) / 2000F;
        if (dt < 22500) return 1F;
        return 1F - (dt - 22500) / 1500F;
    }

    /** The breathing of a flame: about 0.9 .. 1.1, never still. */
    static float flame(float t) {
        float f = 1F + 0.05F * (float) Math.sin(t * 0.11) + 0.04F * (float) Math.sin(t * 0.37 + 1.3) + 0.025F * (float) Math.sin(t * 0.83 + 0.4);
        if ((hash((int) (t / 23F)) % 7) == 0) f -= 0.05F * (float) Math.sin((t % 23F) / 23F * Math.PI);        // now and then it dips
        return f;
    }

    // ---------- the table ----------
    /** Planks of a wooden table with grain, nails and a darker edge, under the book. night 0..1 darkens it to blue. */
    static void desk(GuiGraphics g, int w, int h, float night) {
        int[] wood = {0xFF76523A, 0xFF6C4A36, 0xFF7C583F, 0xFF684832};
        int plank = 13;
        for (int i = 0, y = 14; y < h; i++, y += plank) {
            int ph = Math.min(plank, h - y), base = wood[i % wood.length];
            r(g, 0, y, w, ph, base);
            for (int k = 0; k < 9; k++) {                                              // the grain
                int hv = hash(i * 131 + k * 17);
                int gx = hv % w, gy = y + 1 + (hv >> 8) % Math.max(1, ph - 2), gl = 14 + (hv >> 16) % 46;
                r(g, gx, gy, Math.min(gl, w - gx), 1, (k % 2 == 0) ? 0x1E000000 : 0x14FFFFFF);
            }
            r(g, 0, y, w, 1, 0x14FFFFFF);
            r(g, 0, y + ph - 1, w, 1, 0x55000000);
            r(g, 5, y + 5, 2, 2, 0x55000000); r(g, 5, y + 5, 1, 1, 0x44FFFFFF);        // nails
            r(g, w - 7, y + 5, 2, 2, 0x55000000); r(g, w - 7, y + 5, 1, 1, 0x44FFFFFF);
        }
        for (int i = 0; i < 18; i++) {                                                 // a soft vignette
            int a = (int) ((0x34 * (1F - i / 18F)) * (1F - i / 18F));
            r(g, 0, 14, 1 + i, h - 14, a << 24);
            r(g, w - 1 - i, 14, 1 + i, h - 14, a << 24);
        }
        if (night > 0.01F) r(g, 0, 14, w, h - 14, argb(0.36F * night, 0x0A1038));       // the blue of the night
    }

    // ---------- the bookcase of the shelf ----------
    /**
     * The bookcase behind the shelf of tales: walnut posts and a cornice with a gold line, striped wallpaper at the back (a deep
     * plum at night), a plank under every row of books (planks = the y of the top of each plank) and a cabinet base under the last
     * one. The area is w x h; the title bar of the app (14 pixels) stays above it.
     */
    static void bookcase(GuiGraphics g, int w, int h, int[] planks, float night) {
        float dim = 0.45F * night;
        int wood = tint(0xFF73503A, 0xFF1C1430, dim), woodL = tint(0xFF92694A, 0xFF2A2040, dim), woodD = tint(0xFF53382A, 0xFF120C22, dim);
        int gold = tint(0xFFE0B858, 0xFF70602E, 0.5F * night), top = 14;
        r(g, 0, top, w, h - top, tint(0xFF8A687C, 0xFF2B2344, 0.88F * night));            // the wallpaper
        for (int x = 8; x < w - 4; x += 12) r(g, x, top, 1, h - top, argb(0.07F, 0x000000));
        for (int y = top + 6; y < h; y += 12) for (int x = 14; x < w - 6; x += 12) r(g, x, y + (x / 12 % 2) * 6, 1, 1, argb(0.16F, 0xFFE8C8));
        for (int i = 0; i < 6; i++) {                                                     // shade under the cornice and beside the posts
            float f = 1F - i / 6F;
            r(g, 4, top + 4 + i, w - 8, 1, argb(0.24F * f * f, 0x000000));
            r(g, 4 + i, top + 4, 1, h - top - 4, argb(0.20F * f * f, 0x000000));
            r(g, w - 5 - i, top + 4, 1, h - top - 4, argb(0.20F * f * f, 0x000000));
        }
        for (int py : planks) {                                                           // the planks
            r(g, 4, py, w - 8, 3, woodL);                                                 // the top face, with grain
            for (int i = 0; i < 12; i++) {
                int hv = hash(py * 7 + i * 31);
                r(g, 4 + hv % (w - 20), py + 1 + (hv >> 9) % 2, 6 + (hv >> 15) % 14, 1, argb(0.10F, 0x000000));
            }
            r(g, 4, py, w - 8, 1, argb(0.20F, 0x000000));
            r(g, 4, py + 3, w - 8, 3, wood);                                              // the front lip
            r(g, 4, py + 3, w - 8, 1, argb(0.28F, 0xFFFFFF));
            r(g, 4, py + 5, w - 8, 1, woodD);
            for (int i = 0; i < 5; i++) {                                                 // the shadow it throws below
                float f = 1F - i / 5F;
                r(g, 4, py + 6 + i, w - 8, 1, argb(0.30F * f * f, 0x000000));
            }
        }
        int base = planks[planks.length - 1] + 6;                                         // the cabinet base under the last plank
        r(g, 0, base, w, h - base, wood);
        r(g, 6, base + 3, w - 12, h - base - 7, woodD);
        r(g, 6, base + 3, w - 12, 1, argb(0.35F, 0x000000));
        r(g, 7, base + 4, w - 14, 1, argb(0.12F, 0xFFFFFF));
        r(g, 6, h - 5, w - 12, 1, argb(0.14F, 0xFFFFFF));
        r(g, 0, top, w, 4, wood);                                                         // the cornice
        r(g, 0, top, w, 1, argb(0.30F, 0xFFFFFF));
        r(g, 0, top + 3, w, 1, woodD);
        r(g, 4, top + 2, w - 8, 1, gold);
        for (int x = 8; x < w - 6; x += 12) r(g, x, top + 1, 1, 1, gold);                 // a row of little studs
        for (int side = 0; side < 2; side++) {                                            // the posts
            int px = side == 0 ? 0 : w - 4;
            r(g, px, top + 4, 4, h - top - 4, wood);
            r(g, px + (side == 0 ? 0 : 3), top + 4, 1, h - top - 4, woodD);
            r(g, px + (side == 0 ? 1 : 2), top + 4, 1, h - top - 4, woodL);
        }
    }

    /** The light of two lamps hidden under the cornice of the bookcase: warm pools that breathe, warmer at night. */
    static void shelfLight(GuiGraphics g, int w, int bottom, float night, float t) {
        float k = (1F + 0.8F * night) * flame(t * 0.6F);
        int lamp = tint(0xFFC878, 0xFFA248, night);
        for (int i = 0; i < 2; i++) {
            int cx = i == 0 ? w / 4 : w * 3 / 4;
            glow(g, cx, 18, 125, 90, lamp, 0.026F * k, 7, 18, bottom);
            r(g, cx - 18, 17, 36, 1, argb(0.55F * Math.min(1F, k), 0xFFE8A8));             // the glowing strip of the lamp
        }
    }

    // ---------- light ----------
    private static void ellipse(GuiGraphics g, int cx, int cy, int rx, int ry, int top, int bottom, int argb) {
        for (int dy = Math.max(-ry, top - cy); dy <= Math.min(ry, bottom - cy); dy += 2) {
            int dx = (int) (rx * Math.sqrt(Math.max(0.0, 1.0 - (double) dy * dy / ((double) ry * ry))));
            if (dx > 0) g.fill(cx - dx, cy + dy, cx + dx, cy + dy + 2, argb);
        }
    }

    /** A warm pool of light: stacked ellipses, brightest in the middle. */
    private static void glow(GuiGraphics g, int cx, int cy, int rx, int ry, int rgb, float alphaEach, int steps, int top, int bottom) {
        for (int k = 0; k < steps; k++) {
            float fr = 1F - k / (float) steps;
            ellipse(g, cx, cy, Math.max(2, (int) (rx * fr)), Math.max(2, (int) (ry * fr)), top, bottom, argb(alphaEach, rgb));
        }
    }

    /** The lamp over the book (it burns brighter and warmer at night), the light of the candle and the cool beams of the moon. */
    static void light(GuiGraphics g, int w, int h, int bookCx, float night, float t) { light(g, w, h, bookCx, night, t, 0F, 0F); }

    /**
     * calm 0..1 = the reader has been away for a while (the light sinks and sleeps); pulse = a short change of the light
     * (-0.4 = the lamp flickers when a clock strikes, + = a flash).
     */
    static void light(GuiGraphics g, int w, int h, int bookCx, float night, float t, float calm, float pulse) {
        float fl = flame(t);
        float k = (1F + 0.7F * night) * fl * (1F - 0.35F * calm) * Math.max(0.2F, 1F + pulse);
        int lamp = tint(0xFFC878, 0xFFA248, night);
        glow(g, bookCx, 6, 190, 112, lamp, 0.030F * k, 7, 14, h);
        glow(g, w - 6, h - 20, 46, 44, 0xFFB050, 0.022F * k, 4, 14, h);
        if (night > 0.12F) {                                                            // beams from the window
            for (int y = 14; y < h; y++) {
                float shift = (y - 14) * 0.85F;
                int x0 = (int) (w - 70 - shift);
                r(g, x0, y, 9, 1, argb(0.045F * night, 0xBFD8FF));
                r(g, x0 + 17, y, 5, 1, argb(0.035F * night, 0xBFD8FF));
                r(g, x0 + 29, y, 3, 1, argb(0.03F * night, 0xBFD8FF));
            }
        }
    }

    /** The edges of the open book fall into shadow, the more so at night: the lamp is over the middle. */
    static void pageShade(GuiGraphics g, int bx, int by, int bw, int bh, float night) {
        float s = 0.10F + 0.26F * night;
        for (int i = 0; i < 16; i++) {
            float f = 1F - i / 16F;
            int c = argb(s * f * f, 0x1A1030);
            r(g, bx + i, by, 1, bh, c);
            r(g, bx + bw - 1 - i, by, 1, bh, c);
            if (i < 10) {
                float fb = 1F - i / 10F;
                r(g, bx + 16, by + bh - 1 - i, bw - 32, 1, argb(s * 0.8F * fb * fb, 0x1A1030));
            }
        }
    }

    /** A candle in a brass dish in the corner of the table, with a flame that sways and breathes. */
    static void candle(GuiGraphics g, int w, int h, float t) { candle(g, w, h, t, 0F, 1F); }

    /**
     * burn 0..1 = how much of the candle has gone (it gets shorter, wax runs down its side and gathers in the dish);
     * flameScale = the size of the flame (it sinks when the reader is away and gutters at the end of a tale).
     */
    static void candle(GuiGraphics g, int w, int h, float t, float burn, float flameScale) {
        int cx = w - 5, base = h - 2;
        int body = 12 - Math.round(7F * burn), top = base - 2 - body;
        r(g, cx - 4, base - 2, 8, 2, 0xFFB8883A);                                       // the dish
        r(g, cx - 4, base - 2, 8, 1, 0xFFE0B860);
        if (burn > 0.45F) r(g, cx - 3, base - 3, 6, 1, 0xFFF0E6CC);                     // wax in the dish
        r(g, cx - 2, top, 4, body, 0xFFF4ECD8);                                         // the candle
        r(g, cx - 2, top, 1, body, 0xFFFFFFFF);
        r(g, cx + 1, top, 1, body, 0xFFD8CCB0);
        if (burn > 0.12F) {                                                             // wax runs down its side
            int run = Math.min(body, 2 + Math.round(5F * burn));
            r(g, cx + 2, top, 1, run, 0xFFE8DCC0);
            r(g, cx + 2, top + run, 1, 1, 0xFFF4ECD8);
        }
        r(g, cx, top - 2, 1, 2, 0xFF3A2A2A);                                            // the wick
        float fl = flame(t);
        int sway = Math.round((float) Math.sin(t * 0.21) * 0.8F);
        int hgt = Math.max(2, Math.round((5F + (fl - 1F) * 18F) * flameScale));
        int fy = top - 2 - hgt;
        r(g, cx - 2 + sway, fy + 2, 5, hgt - 1, argb(0.45F * Math.min(1F, flameScale + 0.2F), 0xFF9A2A));   // the outer flame
        r(g, cx - 1 + sway, fy, 3, hgt + 1, 0xFFFF9A2A);
        r(g, cx - 1 + sway, fy + 2, 3, hgt - 1, 0xFFFFC84A);
        if (hgt > 3) r(g, cx + sway, fy + 3, 1, hgt - 3, 0xFFFFF4C0);                   // the bright core
    }

    /** Dust in the lamp light: tiny warm specks that drift and twinkle, brighter at night. */
    static void dust(GuiGraphics g, int w, int h, float night, float t) {
        for (int i = 0; i < 18; i++) {
            int hv = hash(i * 977 + 13);
            float sp = 0.012F + (hv % 7) * 0.003F;
            float x = (hv % w + t * sp * (i % 2 == 0 ? 1 : -0.7F) + (float) Math.sin(t * 0.013 + i) * 6F) % w;
            if (x < 0) x += w;
            float y = 16 + ((hv >> 9) % (h - 24)) + (float) Math.sin(t * 0.017 + i * 1.7) * 5F - (t * 0.004F * (1 + i % 3)) % 12F;
            float tw = 0.35F + 0.65F * Math.abs((float) Math.sin(t * 0.045 + i * 2.1));
            float near = 1F - Math.min(1F, (float) Math.hypot(x - w / 2F, y - 8F) / (w * 0.75F));         // brighter near the lamp
            float a = (0.18F + 0.5F * near) * tw * (0.7F + 0.6F * night);
            int px = (int) x, py = (int) y;
            r(g, px, py, 1, 1, argb(a, 0xFFF0C0));
            if (i % 5 == 0) {
                r(g, px - 1, py, 3, 1, argb(a * 0.35F, 0xFFF0C0));
                r(g, px, py - 1, 1, 3, argb(a * 0.35F, 0xFFF0C0));
            }
        }
    }

    /** A small window in the title bar: a sunny day or a moon and twinkling stars (a curtain at the side). */
    static void window(GuiGraphics g, int x, int y, float night, float t) {
        r(g, x - 1, y - 1, 18, 13, 0xFF8A5A3A);
        r(g, x - 1, y - 1, 18, 1, 0xFFB07A52);
        for (int i = 0; i < 11; i++) r(g, x, y + i, 16, 1, mix(mix(0xFF8FD3FF, 0xFFDDF4FF, i / 10F), mix(0xFF0E1236, 0xFF34437E, i / 10F), night));
        if (night < 0.5F) {
            r(g, x + 10, y + 2, 4, 4, 0xFFFFD84A);
            r(g, x + 11, y + 1, 2, 6, 0xFFFFD84A); r(g, x + 9, y + 3, 6, 2, 0xFFFFD84A);
            r(g, x + 2, y + 6, 6, 2, 0xFFFFFFFF); r(g, x + 3, y + 5, 4, 1, 0xFFFFFFFF);
        } else {
            for (int dy = -3; dy <= 3; dy++) {                                         // the moon
                int dx = (int) Math.floor(Math.sqrt(9 - dy * dy + 0.25));
                r(g, x + 11 - dx, y + 5 + dy, dx * 2 + 1, 1, 0xFFFFF3C0);
            }
            r(g, x + 10, y + 4, 1, 1, 0xFFE8D890);
            int[] st = {2, 2, 6, 7, 4, 9, 13, 1};
            for (int i = 0; i < st.length; i += 2) {
                float tw = 0.4F + 0.6F * Math.abs((float) Math.sin(t * 0.05 + i));
                r(g, x + st[i], y + st[i + 1], 1, 1, argb(tw, 0xFFFFF3B0));
            }
        }
        r(g, x + 7, y, 1, 11, 0xFF8A5A3A); r(g, x, y + 5, 16, 1, 0xFF8A5A3A);          // the frame bars
        r(g, x - 1, y - 1, 3, 12, 0x55E5484D);                                         // a curtain
    }

    // ---------- the decorations of the pages ----------
    /** A flourish centred on cx: a diamond, two tapering lines and a curl at each end. y = the middle of the ornament. */
    static void flourish(GuiGraphics g, int cx, int y, int color) {
        r(g, cx - 1, y - 2, 3, 5, color); r(g, cx - 2, y - 1, 5, 3, color); r(g, cx, y - 3, 1, 7, color); r(g, cx - 3, y, 7, 1, color);
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 14; i++) {                                              // the line, tapering into dots
                int px = cx + side * (6 + i);
                if (i < 8 || i % 2 == 0) r(g, px, y, 1, 1, i < 8 ? color : mix(color, 0x00FFFFFF & color, 0.4F));
            }
            for (int a = 0; a < 16; a++) {                                              // the curl: a little spiral going up
                double ang = a * 0.42, rad = 3.2 - a * 0.14;
                int px = cx + side * (22 + (int) Math.round(Math.cos(ang) * rad)), py = y - 2 + (int) Math.round(-Math.sin(ang) * rad);
                r(g, px, py, 1, 1, color);
            }
            r(g, cx + side * 28, y + 1, 1, 1, color);
        }
    }

    /** The big first letter of a tale: a small plate in the colour of the book with a gold frame. w x 18 pixels (two lines of text). */
    static void dropCap(GuiGraphics g, Font f, char ch, int x, int y, int w, int cover) { dropCap(g, f, ch, x, y, w, cover, 4); }

    /** The same with the pattern of the tale's theme on the plate (waves, leaves, stars, flowers or rays). */
    static void dropCap(GuiGraphics g, Font f, char ch, int x, int y, int w, int cover, int theme) {
        r(g, x, y, w, 18, cover);
        r(g, x + 1, y + 1, w - 2, 8, argb(0.14F, 0xFFFFFF));                            // the light of the lamp on the upper half
        r(g, x + 1, y + 11, w - 2, 6, argb(0.12F, 0x000000));
        pattern(g, theme, x, y, w, 18, argb(0.17F, 0xFFFFFF));
        r(g, x, y, w, 1, 0xFFFFD84A); r(g, x, y + 17, w, 1, 0xFFFFD84A);
        r(g, x, y, 1, 18, 0xFFFFD84A); r(g, x + w - 1, y, 1, 18, 0xFFFFD84A);
        r(g, x + 2, y + 2, 2, 2, 0xFFFFD84A); r(g, x + w - 4, y + 2, 2, 2, 0xFFFFD84A);
        r(g, x + 2, y + 14, 2, 2, 0xFFFFD84A); r(g, x + w - 4, y + 14, 2, 2, 0xFFFFD84A);
        String s = String.valueOf(Character.toUpperCase(ch));
        int cw = CuteFont.width(f, s);
        g.pose().pushPose();
        g.pose().translate(x + (w - cw * 2) / 2F + 1, y + 2, 0);                         // a soft shadow under the letter
        g.pose().scale(2F, 2F, 1F);
        CuteFont.draw(g, f, s, 0, 0, argb(0.35F, 0x000000), false);
        g.pose().popPose();
        g.pose().pushPose();
        g.pose().translate(x + (w - cw * 2) / 2F, y + 1, 0);
        g.pose().scale(2F, 2F, 1F);
        CuteFont.draw(g, f, s, 0, 0, 0xFFFFF0B8, false);
        g.pose().popPose();
    }

    /** Corner filigree of a page: two thin lines and two dots. right / bottom say which corner of the page it is. */
    static void corner(GuiGraphics g, int x, int y, boolean right, boolean bottom, int color) { corner(g, x, y, right, bottom, color, -1); }

    /** The same; the bottom corners of a themed page carry the emblem of the tale (a wave, a leaf, a star, a flower, a sun). */
    static void corner(GuiGraphics g, int x, int y, boolean right, boolean bottom, int color, int theme) {
        int sx = right ? -1 : 1, sy = bottom ? -1 : 1;
        for (int i = 0; i < 6; i++) {
            r(g, x + sx * i, y, 1, 1, color);
            r(g, x, y + sy * i, 1, 1, color);
        }
        if (theme >= 0 && bottom) {
            motif(g, theme, x + sx * 4, y + sy * 4, color);
        } else {
            r(g, x + sx * 2, y + sy * 2, 1, 1, color);
            r(g, x + sx * 3, y + sy * 3, 1, 1, color);
        }
    }
}
