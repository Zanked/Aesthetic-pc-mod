package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.Random;

/**
 * Cute Radio: four stations that never end. The music is made up as it plays (a random walk over a pentatonic
 * scale with a soft bass), so every hour sounds different. It keeps playing while the window is minimized; a sleep
 * timer (off, 10, 20 or 30 minutes) stops it by itself. Station and volume are remembered while the app is open.
 */
public class RadioApp extends KitApp {
    private static final int STATIONS = 4;
    // scale notes (note block numbers), lead instrument, ticks per step, rest chance in %, bass instrument is always 2
    private static final int[][] SCALE = {
            {6, 8, 10, 13, 15, 18, 20, 22},          // chill: major pentatonic
            {6, 8, 10, 11, 13, 15, 17, 18, 20},      // happy: major scale
            {6, 9, 11, 13, 16, 18, 21},              // night: minor pentatonic
            {6, 8, 11, 13, 15, 18, 20, 23}};         // adventure
    private static final int[] LEAD = {0, 3, 1, 0};
    private static final int[] STEP = {15, 8, 17, 10};
    private static final int[] REST = {30, 12, 45, 15};
    private static final int[] COLOR = {0xFF6FB8E8, 0xFFFFC24A, 0xFF8A7AE0, 0xFF5BBF6A};
    private static final int[] TIMER_MIN = {0, 10, 20, 30};

    private final Random rnd = new Random();
    private final float[] bars = new float[16];
    private int station, timerIdx, volume = 2, deg;
    private boolean playing;
    private int acc, stepNo;
    private long stopAt;                         // when the sleep timer ends (ms), 0 = never

    @Override protected int accent() { return 0xFF7A8AE8; }

    @Override protected String id() { return "radio"; }

    @Override public boolean background() { return playing; }

    @Override public boolean busy() { return playing; }

    @Override public void close() { playing = false; }

    private float vol() { return 0.25F + volume * 0.2F; }

    private void play(boolean on) {
        playing = on;
        acc = 99;
        stepNo = 0;
        if (on) { deg = SCALE[station].length / 2; stopAt = TIMER_MIN[timerIdx] == 0 ? 0 : System.currentTimeMillis() + TIMER_MIN[timerIdx] * 60_000L; }
    }

    @Override
    public void tick() {
        super.tick();
        for (int i = 0; i < bars.length; i++) bars[i] *= 0.9F;
        if (!playing) return;
        if (stopAt > 0 && System.currentTimeMillis() >= stopAt) { playing = false; say("cutemod.radio.msg.sleep"); return; }
        if (++acc < STEP[station]) return;
        acc = 0;
        int[] sc = SCALE[station];
        if (rnd.nextInt(100) >= REST[station]) {
            deg = Math.max(0, Math.min(sc.length - 1, deg + rnd.nextInt(5) - 2));          // a small step up or down
            if (rnd.nextInt(14) == 0) deg = rnd.nextInt(sc.length);                          // and now and then a leap
            int n = sc[deg];
            MusicApp.note(LEAD[station], n, vol() * 0.8F);
            bars[Math.floorMod(n + stepNo, bars.length)] = 1F;
            if (station == 1 && rnd.nextInt(4) == 0) MusicApp.note(0, sc[Math.min(sc.length - 1, deg + 2)], vol() * 0.5F);   // a happy second voice
        }
        int beat = station == 3 ? 2 : 4;
        if (stepNo % beat == 0) {                                                            // the bass follows the root of the bar
            int root = sc[(stepNo / 16) % 3 == 0 ? 0 : (stepNo / 16) % 3 == 1 ? 2 : 3] - 6;
            MusicApp.note(2, Math.max(0, root), vol());
            bars[stepNo % bars.length] = Math.max(bars[stepNo % bars.length], 0.6F);
        }
        stepNo++;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        header(g, f);
        rect(g, 0, 14, W, H - 14, 0xFF1E1A3E);
        // the stations
        for (int i = 0; i < STATIONS; i++) {
            int x = 8 + i * 71;
            boolean on = i == station, hov = in(mx, my, x, 20, 67, 30);
            rect(g, x, 20, 67, 30, on ? COLOR[i] : hov ? 0xFF3A3470 : 0xFF2C2756);
            rect(g, x, 48, 67, 2, 0x33000000);
            center(g, f, t("cutemod.radio.st." + i), x + 33, 26, on ? 0xFFFFFFFF : 0xFFC8C0F0);
            center(g, f, t("cutemod.radio.fm", 88 + i * 6 + (i == 2 ? 1 : 0)), x + 33, 38, on ? 0xFFFFFFFF : 0xFF8A82C0);
        }
        // the equalizer
        for (int i = 0; i < bars.length; i++) {
            int h = 4 + (int) (bars[i] * 46), x = 12 + i * 17;
            rect(g, x, 112 - h, 13, h, COLOR[station]);
            rect(g, x, 112 - h, 13, 2, 0x55FFFFFF);
        }
        center(g, f, playing ? t("cutemod.radio.on", t("cutemod.radio.st." + station)) : t("cutemod.radio.off"), W / 2, 58, 0xFFE4DCFF);
        // controls
        btn(g, f, mx, my, 8, 128, 60, playing ? t("cutemod.radio.stop") : t("cutemod.radio.play"), playing ? 0 : 1);
        btn(g, f, mx, my, 74, 128, 16, "-", 0);
        CuteFont.draw(g, f, t("cutemod.radio.vol", volume + 1), 94, 132, 0xFFE4DCFF, false);
        btn(g, f, mx, my, 138, 128, 16, "+", 0);
        String tm = TIMER_MIN[timerIdx] == 0 ? t("cutemod.radio.timer.off") : t("cutemod.radio.timer", TIMER_MIN[timerIdx]);
        if (playing && stopAt > 0) tm = t("cutemod.radio.left", (stopAt - System.currentTimeMillis()) / 60000 + 1);
        btn(g, f, mx, my, 164, 128, 126, tm, 0);
        footer(g, f);
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < STATIONS; i++) if (in(x, y, 8 + i * 71, 20, 67, 30)) { station = i; if (playing) play(true); return true; }
        if (in(x, y, 8, 128, 60, 16)) { play(!playing); return true; }
        if (in(x, y, 74, 128, 16, 16)) { volume = Math.max(0, volume - 1); return true; }
        if (in(x, y, 138, 128, 16, 16)) { volume = Math.min(4, volume + 1); return true; }
        if (in(x, y, 164, 128, 126, 16)) {
            timerIdx = (timerIdx + 1) % TIMER_MIN.length;
            if (playing) stopAt = TIMER_MIN[timerIdx] == 0 ? 0 : System.currentTimeMillis() + TIMER_MIN[timerIdx] * 60_000L;
            return true;
        }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (keyCode == 32) { play(!playing); return true; }
        return false;
    }
}
