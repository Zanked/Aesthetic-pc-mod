package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.util.Random;

/**
 * Sticker Book: 30 stickers (6 shapes in 5 colors) and one free pack a day with one sticker. Pink, yellow and mint are
 * common, blue is rare, purple with sparkles is legendary. A double is paid 2 coins; a full book pays 50 coins once.
 * Saved as "stickers": last day opened | book completed (0/1) | the 30 counts.
 */
public class StickersApp extends KitApp {
    private static final int SHAPES = 6, COLORS = 5, TOTAL = SHAPES * COLORS, COLS = 10, CELL = 28, GX = 10, GY = 22;
    private static final int[] COL = {0xFFFF8AB0, 0xFFFFD84A, 0xFF7ED9A0, 0xFF6FB8F0, 0xFFB57BD6};

    private final int[] have = new int[TOTAL];
    private int lastDay = -1, completed;
    private boolean loaded;
    private int reveal = -1, revealT;            // a pack that is opening: which sticker, ticks
    private boolean revealNew;
    private final Random rnd = new Random();

    @Override protected int accent() { return 0xFFE98AC8; }

    @Override protected String id() { return "stickers"; }

    @Override
    public void attach(Shell shell) { super.attach(shell); load(); }

    private void load() {
        loaded = true;
        try {
            String s = Store.read("stickers");
            if (s == null) return;
            String[] p = s.split("\\|");
            lastDay = Integer.parseInt(p[0]);
            completed = Integer.parseInt(p[1]);
            String[] c = p[2].split(",");
            for (int i = 0; i < TOTAL && i < c.length; i++) have[i] = Math.max(0, Math.min(99, Integer.parseInt(c[i])));
        } catch (Exception ignored) { }
    }

    private void save() {
        StringBuilder sb = new StringBuilder().append(lastDay).append('|').append(completed).append('|');
        for (int i = 0; i < TOTAL; i++) sb.append(i > 0 ? "," : "").append(have[i]);
        Store.write("stickers", sb.toString());
    }

    private int collected() {
        int n = 0;
        for (int v : have) if (v > 0) n++;
        return n;
    }

    private void open() {
        if (reveal >= 0) return;
        if (lastDay == today()) { say("cutemod.stickers.msg.today"); return; }
        int roll = rnd.nextInt(100);
        int color = roll < 70 ? rnd.nextInt(3) : roll < 95 ? 3 : 4;
        int id = color * SHAPES + rnd.nextInt(SHAPES);
        revealNew = have[id] == 0;
        have[id]++;
        lastDay = today();
        reveal = id;
        revealT = 0;
        if (!revealNew) Progress.earn(2);
        Season.add(8);
        if (completed == 0 && collected() == TOTAL) { completed = 1; Progress.earn(50); say("cutemod.stickers.msg.full"); }
        save();
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.0F + color * 0.25F, 0.6F);
    }

    @Override
    public void tick() {
        super.tick();
        if (reveal >= 0) revealT++;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        header(g, f);
        String cnt = t("cutemod.stickers.count", collected(), TOTAL);
        CuteFont.draw(g, f, cnt, W - 6 - f.width(cnt), 3, 0xFFFFFFFF, false);
        int hover = -1;
        for (int i = 0; i < TOTAL; i++) {
            int x = GX + i % COLS * CELL, y = GY + i / COLS * CELL;
            boolean over = in(mx, my, x, y, CELL - 2, CELL - 2);
            if (over) hover = i;
            rect(g, x, y, CELL - 2, CELL - 2, have[i] > 0 ? 0xFFFFFFFF : 0xFFEFE7F6);
            sticker(g, x + (CELL - 2) / 2, y + (CELL - 2) / 2, i % SHAPES, i / SHAPES, have[i] > 0, ticks + i * 5);
            if (have[i] > 1) CuteFont.draw(g, f, "x" + have[i], x + 2, y + CELL - 11, MUTED, false);
        }
        String line = hover >= 0 && have[hover] > 0 ? t("cutemod.stickers.rarity." + rarity(hover / SHAPES)) : t("cutemod.stickers.hint");
        CuteFont.draw(g, f, line, 10, 112, MUTED, false);
        boolean book = "1".equals(Store.read("tales_sticker"));                    // the reward of the Fairy Tales app
        rect(g, 10, 123, W - 20, 17, book ? 0xFFFFF3C8 : 0xFFEFE7F6);
        bookSticker(g, 21, 131, book, ticks);
        CuteFont.draw(g, f, CuteFont.cut(f, book ? t("cutemod.stickers.tales_got") : t("cutemod.stickers.tales_hint"), W - 54), 36, 127, book ? TEXT : MUTED, false);
        boolean can = lastDay != today() && reveal < 0;
        btn(g, f, mx, my, 70, 142, 160, can ? t("cutemod.stickers.open") : t("cutemod.stickers.tomorrow"), can ? 1 : 2);
        if (reveal >= 0) overlay(g, f);
        footer(g, f);
    }

    private static int rarity(int color) { return color < 3 ? 0 : color == 3 ? 1 : 2; }

    private void overlay(GuiGraphics g, Font f) {
        rect(g, 0, 14, W, H - 14, 0xCC1E1438);
        int cx = W / 2, cy = 74;
        if (revealT < 40) {                                          // the pack shakes
            int sh = (int) Math.round(Math.sin(revealT * 1.2) * 3);
            rect(g, cx - 20 + sh, cy - 26, 40, 52, 0xFFE98AC8); rect(g, cx - 20 + sh, cy - 26, 40, 8, 0xFFFFFFFF);
            center(g, f, "?", cx + sh, cy - 3, 0xFFFFFFFF);
        } else {
            rect(g, cx - 28, cy - 34, 56, 68, 0xFFFFFFFF);
            sticker(g, cx, cy - 6, reveal % SHAPES, reveal / SHAPES, true, ticks);
            center(g, f, t("cutemod.stickers.rarity." + rarity(reveal / SHAPES)), cx, cy + 20, TEXT);
            center(g, f, revealNew ? t("cutemod.stickers.new") : t("cutemod.stickers.double"), cx, cy + 46, 0xFFFFE08A);
            center(g, f, t("cutemod.stickers.close"), cx, 126, 0xFFB8A8D8);
        }
    }

    /** A sticker at (cx, cy), about 22 pixels wide. Not collected: a gray shape. */
    static void sticker(GuiGraphics g, int cx, int cy, int shape, int color, boolean got, int t) {
        int c = got ? COL[color] : 0xFFD9D0E4;
        int dark = got ? mix(c, 0x000000, 0.25F) : 0xFFC8BFD6;
        switch (shape) {
            case 0 -> {                                                   // heart
                disc(g, cx - 5, cy - 3, 5, c); disc(g, cx + 5, cy - 3, 5, c);
                for (int d = 0; d < 11; d++) rect(g, cx - 10 + d, cy + d - 1, 21 - d * 2, 1, c);
                if (got) rect(g, cx - 7, cy - 6, 3, 2, 0x88FFFFFF);
            }
            case 1 -> {                                                   // star
                for (int d = -10; d <= 10; d++) {
                    int w = (int) Math.round(4 * (1 - Math.abs(d) / 11.0));
                    rect(g, cx - 1 - w, cy + d, 2 + w * 2, 1, c);
                    rect(g, cx + d, cy - 1 - w, 1, 2 + w * 2, c);
                }
                rect(g, cx - 5, cy - 5, 10, 10, c);
            }
            case 2 -> {                                                   // smiley
                disc(g, cx, cy, 10, c); disc(g, cx, cy, 9, got ? mix(c, 0xFFFFFF, 0.25F) : c);
                if (got) { rect(g, cx - 5, cy - 4, 2, 3, 0xFF3A2A3A); rect(g, cx + 3, cy - 4, 2, 3, 0xFF3A2A3A); rect(g, cx - 4, cy + 3, 8, 1, 0xFF3A2A3A); rect(g, cx - 5, cy + 2, 1, 1, 0xFF3A2A3A); rect(g, cx + 4, cy + 2, 1, 1, 0xFF3A2A3A); }
            }
            case 3 -> {                                                   // flower
                disc(g, cx - 6, cy, 5, c); disc(g, cx + 6, cy, 5, c); disc(g, cx, cy - 6, 5, c); disc(g, cx, cy + 6, 5, c);
                disc(g, cx, cy, 4, got ? 0xFFFFF3B0 : 0xFFE8E0F0);
            }
            case 4 -> {                                                   // moon
                disc(g, cx, cy, 10, c);
                disc(g, cx + 5, cy - 3, 8, got ? 0xFFFFFFFF : 0xFFEFE7F6);
            }
            default -> {                                                  // gem
                for (int d = 0; d <= 10; d++) rect(g, cx - d, cy - 10 + d, 2 * d + 1, 1, c);
                for (int d = 1; d <= 10; d++) rect(g, cx - 10 + d, cy + d, 21 - 2 * d, 1, dark);
                if (got) rect(g, cx - 3, cy - 7, 2, 3, 0x88FFFFFF);
            }
        }
        if (got && color == 4 && (t / 8) % 3 != 2) {                      // legendary: sparkles
            int k = (t / 8) % 3;
            rect(g, cx + 8 - k * 14, cy - 10 + k * 3, 1, 3, 0xFFFFFFFF); rect(g, cx + 7 - k * 14, cy - 9 + k * 3, 3, 1, 0xFFFFFFFF);
        }
    }

    /** The Storyteller sticker (given for reading all twelve tales): a purple book with a gold frame and a ribbon. About 14 x 16 pixels. */
    static void bookSticker(GuiGraphics g, int cx, int cy, boolean got, int t) {
        int c = got ? 0xFFB57BD6 : 0xFFD9D0E4, dark = got ? 0xFF7A4FA0 : 0xFFC8BFD6, gold = got ? 0xFFFFD84A : 0xFFE0D8EA;
        rect(g, cx - 7, cy - 8, 14, 16, dark);
        rect(g, cx - 6, cy - 7, 12, 14, c);
        rect(g, cx - 7, cy - 8, 3, 16, dark);
        rect(g, cx - 4, cy - 7, 1, 14, mix(c, 0xFFFFFF, 0.3F));
        rect(g, cx - 2, cy - 5, 7, 1, gold); rect(g, cx - 2, cy + 4, 7, 1, gold);
        rect(g, cx - 2, cy - 5, 1, 10, gold); rect(g, cx + 4, cy - 5, 1, 10, gold);
        rect(g, cx + 1, cy - 3, 1, 7, gold); rect(g, cx - 2, cy, 7, 1, gold);          // a star on the cover
        if (got) rect(g, cx + 3, cy - 8, 2, 5, 0xFFE5484D);                              // the ribbon
        if (got && (t / 8) % 3 != 2) {
            int k = (t / 8) % 3;
            rect(g, cx + 8 - k * 14, cy - 10 + k * 3, 1, 3, 0xFFFFFFFF); rect(g, cx + 7 - k * 14, cy - 9 + k * 3, 3, 1, 0xFFFFFFFF);
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (reveal >= 0) { if (revealT > 45) reveal = -1; return true; }
        if (in(x, y, 70, 142, 160, 16)) { open(); return true; }
        return false;
    }
}
