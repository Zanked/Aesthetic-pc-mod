package dev.cutemod.client.os;

import dev.cutemod.CuteMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

import java.util.HashMap;
import java.util.Map;

/**
 * The sounds of the system and its apps: pop-ups, new mail, windows opening and closing, a parcel at the door, coins...
 * Our own sound events are "app.&lt;name&gt;" (tools/make_app_audio.py) and "jobs.&lt;name&gt;" (tools/make_jobs_audio.py);
 * everything goes through {@link Sfx}, so the Sounds switch and the system volume of the Settings apply.
 *
 * Pop-ups are the central place: {@link #toast} picks the sound from the key of the message (coins, a purchase, an
 * achievement...), so every app that shows a pop-up gets its sound without any code of its own.
 */
public final class AppSfx {
    private AppSfx() {}

    private static final Map<String, SoundEvent> SND = new HashMap<>();

    private static SoundEvent ev(String full) {
        return SND.computeIfAbsent(full, n -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, n)));
    }

    /** A sound of the system ("app.notify"...). */
    public static void app(String name, float pitch, float vol) { Sfx.ui(ev("app." + name), pitch, vol); }

    /** A sound of the jobs set ("jobs.coin"...), also used by other apps. */
    public static void jobs(String name, float pitch, float vol) { Sfx.ui(ev("jobs." + name), pitch, vol); }

    // ---------- windows ----------
    public static void open() { app("open", 1F, 0.5F); }

    public static void close() { app("close", 1F, 0.5F); }

    // ---------- pop-ups ----------
    private static boolean has(String key, String... parts) {
        for (String p : parts) if (key.contains(p)) return true;
        return false;
    }

    /** The sound of a pop-up, chosen by its message key. */
    public static void toast(String key) {
        if (has(key, ".coins", "daily_bonus", "admin_coins", "daily.done")) jobs("coin", 1F, 0.55F);
        else if (has(key, "toast.bought", "store_bought", "app_installing", "market.ordered")) jobs("payout", 1F, 0.5F);
        else if (has(key, "toast.ach", "season_level", "season_premium", "champion", "finale", "tale_book", "chapter",
                "scary_all", "tales_sticker", "skillup", "show.cup", "dest_done", "album_full")) app("achieve", 1F, 0.55F);
        else if (has(key, "market_arrived", "market.collected", "trip.back")) app("parcel", 1F, 0.6F);
        else if (has(key, "tube.err", "toast.cap", "refunded")) Sfx.error();
        else app("notify", 1F, 0.55F);
    }

    /** A new letter. */
    public static void mail() { app("mail", 1F, 0.6F); }

    /** A letter was sent. */
    public static void send() { app("send", 1F, 0.55F); }
}
