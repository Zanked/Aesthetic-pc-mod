package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayDeque;

/** Green computer: Minesweeper with creepers. Left click = dig, right click = flag. */
public class Minesweeper extends MiniGame {
    private static final int C = 14, R = 9, CELL = 15, OX = (W - C * CELL) / 2, OY = (H - R * CELL) / 2, MINES = 18;
    private static final int[] NUM = {0, 0xFF2B5FD9, 0xFF2E8B3A, 0xFFD93A3A, 0xFF6B2FA0, 0xFF8A3A1A, 0xFF1A8A8A, 0xFF222222, 0xFF666666};

    private final boolean[][] mine = new boolean[R][C];
    private final boolean[][] shown = new boolean[R][C];
    private final boolean[][] flag = new boolean[R][C];
    private final int[][] adj = new int[R][C];
    private boolean first, lost;
    private int ticks, revealed, flags, boomR, boomC;

    @Override
    public void reset() {
        score = 0; over = false; first = true; lost = false; ticks = 0; revealed = 0; flags = 0; boomR = -1; boomC = -1;
        for (int r = 0; r < R; r++) for (int c = 0; c < C; c++) { mine[r][c] = false; shown[r][c] = false; flag[r][c] = false; adj[r][c] = 0; }
    }

    private void placeMines(int safeR, int safeC) {
        int placed = 0;
        while (placed < MINES) {
            int r = rnd.nextInt(R), c = rnd.nextInt(C);
            if (mine[r][c] || (Math.abs(r - safeR) <= 1 && Math.abs(c - safeC) <= 1)) continue;
            mine[r][c] = true; placed++;
        }
        for (int r = 0; r < R; r++) for (int c = 0; c < C; c++) {
            int n = 0;
            for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
                int rr = r + dr, cc = c + dc;
                if ((dr != 0 || dc != 0) && rr >= 0 && cc >= 0 && rr < R && cc < C && mine[rr][cc]) n++;
            }
            adj[r][c] = n;
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        int c = (x - OX) / CELL, r = (y - OY) / CELL;
        if (x < OX || y < OY || c >= C || r >= R) return true;
        if (button == 1) {
            if (!shown[r][c]) { flag[r][c] = !flag[r][c]; flags += flag[r][c] ? 1 : -1; beep(); }
            return true;
        }
        if (flag[r][c] || shown[r][c]) return true;
        if (first) { first = false; placeMines(r, c); }
        if (mine[r][c]) { lost = true; over = true; boomR = r; boomC = c; score = 0; beep(); return true; }
        floodReveal(r, c);
        pling(1.2F);
        if (revealed == R * C - MINES) {
            over = true;
            score = Math.max(10, 500 - (ticks / 60) * 3);
            pling(1.9F);
        }
        return true;
    }

    private void floodReveal(int sr, int sc) {
        ArrayDeque<int[]> stack = new ArrayDeque<>();
        stack.push(new int[]{sr, sc});
        while (!stack.isEmpty()) {
            int[] p = stack.pop();
            int r = p[0], c = p[1];
            if (r < 0 || c < 0 || r >= R || c >= C || shown[r][c] || flag[r][c] || mine[r][c]) continue;
            shown[r][c] = true; revealed++;
            if (adj[r][c] == 0) {
                for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) stack.push(new int[]{r + dr, c + dc});
            }
        }
    }

    @Override
    public void tick() {
        if (!first) ticks++;
    }

    @Override
    public void render(GuiGraphics g) {
        g.fill(0, 0, W, H, 0xFF2A3A2A);
        for (int r = 0; r < R; r++) {
            for (int c = 0; c < C; c++) {
                int x = OX + c * CELL, y = OY + r * CELL;
                if (shown[r][c]) {
                    rect(g, x, y, CELL, CELL, ((r + c) & 1) == 0 ? 0xFFD9C29A : 0xFFCDB68A);
                    if (adj[r][c] > 0) ctext(g, String.valueOf(adj[r][c]), x + CELL / 2, y + 4, NUM[adj[r][c]]);
                } else {
                    rect(g, x, y, CELL, CELL, ((r + c) & 1) == 0 ? 0xFF6BBF59 : 0xFF5FB04F);
                    rect(g, x, y, CELL, 1, 0x66FFFFFF);
                    rect(g, x, y, 1, CELL, 0x66FFFFFF);
                    rect(g, x, y + CELL - 1, CELL, 1, 0x44000000);
                    if (flag[r][c]) {
                        rect(g, x + 7, y + 3, 1, 9, 0xFF3A2A1A);
                        rect(g, x + 3, y + 3, 5, 4, 0xFFE03A3A);
                    }
                }
                if (lost && mine[r][c] && !flag[r][c]) {
                    rect(g, x, y, CELL, CELL, (r == boomR && c == boomC) ? 0xFFE03A3A : 0xFF4FA848);
                    rect(g, x + 3, y + 3, 3, 3, 0xFF16301A);
                    rect(g, x + 9, y + 3, 3, 3, 0xFF16301A);
                    rect(g, x + 6, y + 6, 3, 4, 0xFF16301A);
                    rect(g, x + 4, y + 9, 2, 3, 0xFF16301A);
                    rect(g, x + 9, y + 9, 2, 3, 0xFF16301A);
                }
            }
        }
    }

    @Override
    public Component status() {
        return Component.translatable("cutemod.ui.mines", MINES - flags, ticks / 60);
    }

    @Override
    public String hintKey() { return "cutemod.hint.mines"; }
}
