package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Lights Out: a press flips a lamp and its four neighbours. Switch every lamp off. The puzzle is always solvable. */
public class LightsOut extends MiniGame {
    private static final int N = 5, CELL = 22, GAP = 3, OX = (W - (N * CELL + (N - 1) * GAP)) / 2, OY = 9;

    private final boolean[] lamp = new boolean[N * N];
    private int moves;
    private boolean won;

    @Override
    public void reset() {
        score = 0; over = false; won = false; moves = 0;
        java.util.Arrays.fill(lamp, false);
        int presses = 7 + rnd.nextInt(6);
        for (int k = 0; k < presses; k++) flip(rnd.nextInt(N * N));
        if (allOff()) flip(12);                                    // never start already solved
    }

    private void toggle(int x, int y) {
        if (x >= 0 && y >= 0 && x < N && y < N) lamp[y * N + x] = !lamp[y * N + x];
    }

    private void flip(int i) {
        int x = i % N, y = i / N;
        toggle(x, y); toggle(x - 1, y); toggle(x + 1, y); toggle(x, y - 1); toggle(x, y + 1);
    }

    private boolean allOff() {
        for (boolean b : lamp) if (b) return false;
        return true;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return true;
        for (int i = 0; i < N * N; i++) {
            if (in(x, y, OX + (i % N) * (CELL + GAP), OY + (i / N) * (CELL + GAP), CELL, CELL)) {
                flip(i); moves++;
                pling(lamp[i] ? 1.3F : 0.8F);
                if (allOff()) { won = true; over = true; score = Math.max(10, 120 - 4 * moves); sound(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, 1.0F, 0.6F); }
                break;
            }
        }
        return true;
    }

    @Override
    public void tick() {}

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF26305A, 0xFF141A38);
        for (int i = 0; i < N * N; i++) {
            int x = OX + (i % N) * (CELL + GAP), y = OY + (i / N) * (CELL + GAP);
            boolean on = lamp[i];
            if (on) rect(g, x - 1, y - 1, CELL + 2, CELL + 2, 0x44FFD84A);
            rect(g, x, y, CELL, CELL, on ? 0xFFFFD84A : 0xFF3A4478);
            rect(g, x + 2, y + 2, CELL - 4, CELL - 4, on ? 0xFFFFF0A8 : 0xFF2C3563);
            rect(g, x, y, CELL, 2, on ? 0x88FFFFFF : 0x22FFFFFF);
        }
    }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() { return Component.translatable("cutemod.lights.win"); }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.moves", moves); }

    @Override
    public String hintKey() { return "cutemod.hint.lights"; }
}
