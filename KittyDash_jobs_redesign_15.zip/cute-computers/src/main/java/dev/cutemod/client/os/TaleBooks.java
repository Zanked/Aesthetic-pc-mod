package dev.cutemod.client.os;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * The collection of the Fairy Tales app: the books have to be collected.
 * <ul>
 * <li>Two books are on the shelf from the start ({@link #STARTERS}); so are the tales that were read before the collection existed.</li>
 * <li>Any other tale is found as five pages, one for every scene. A page turns up by chance in other apps: while fishing, when a crop
 * is harvested, when the pet comes home from a trip and in the daily gift ({@link #find}); at most {@link #DAILY_PAGES} a day.
 * The fifth page makes the book whole.</li>
 * <li>A book can also be bought with coins: {@link #PAGE_PRICE} for every page that is still missing.</li>
 * </ul>
 * Saved on the server: "tales_own" (the books: ids with commas) and "tales_pages" (the pages of the books that are not whole yet:
 * id:mask, the mask has a bit for every scene).
 */
public final class TaleBooks {
    private TaleBooks() {}

    public static final String[] STARTERS = {"duckling", "kolobok"};
    public static final int PAGE_PRICE = 5, DAILY_PAGES = 3, FULL = (1 << Tales.SCENES) - 1;

    private static final Set<String> own = new LinkedHashSet<>();
    private static final Map<String, Integer> pages = new HashMap<>();
    private static int gen = -1;
    private static boolean loaded;

    private static boolean known(String id) {
        for (Tales.Tale t : Tales.ALL) if (t.id().equals(id)) return true;
        return false;
    }

    private static void ensure() {
        if (!Store.ready() || (loaded && gen == Store.gen())) return;
        loaded = true;
        gen = Store.gen();
        own.clear();
        pages.clear();
        String o = Store.read("tales_own");
        if (o == null) {                                              // the first time: the starters and everything that was read before
            for (String id : STARTERS) own.add(id);
            String done = Store.read("tales");
            if (done != null) for (String id : done.split(",")) if (known(id)) own.add(id);
            String m = Store.read("tales_mark");
            if (m != null && m.contains(":") && known(m.substring(0, m.indexOf(':')))) own.add(m.substring(0, m.indexOf(':')));
            saveOwn();
        } else {
            for (String id : o.split(",")) if (known(id)) own.add(id);
        }
        String p = Store.read("tales_pages");
        if (p == null) return;
        for (String e : p.split(",")) {
            int c = e.indexOf(':');
            if (c <= 0) continue;
            try {
                String id = e.substring(0, c);
                if (known(id) && !own.contains(id)) pages.put(id, Integer.parseInt(e.substring(c + 1)) & FULL);
            } catch (NumberFormatException ignored) {
                // a broken entry is just skipped
            }
        }
    }

    private static void saveOwn() { Store.write("tales_own", String.join(",", own)); }

    private static void savePages() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : pages.entrySet()) {
            if (e.getValue() == 0) continue;
            if (sb.length() > 0) sb.append(',');
            sb.append(e.getKey()).append(':').append(e.getValue());
        }
        Store.write("tales_pages", sb.toString());
    }

    // ---------- what the player has ----------
    public static boolean owns(String id) { ensure(); return own.contains(id); }

    public static int owned() { ensure(); return own.size(); }

    /** The scenes of this tale whose pages were found (a bit for every scene); 0 for a whole book too. */
    public static int mask(String id) { ensure(); return pages.getOrDefault(id, 0); }

    public static int found(String id) { return Integer.bitCount(mask(id)); }

    /** What it costs to buy the book now: every missing page is {@link #PAGE_PRICE} coins. */
    public static int price(String id) { return (Tales.SCENES - found(id)) * PAGE_PRICE; }

    private static void complete(String id) {
        own.add(id);
        pages.remove(id);
        saveOwn();
        savePages();
    }

    /** Buys the book for the coins; false if it is not for sale or there is not enough money. */
    public static boolean buy(String id) {
        ensure();
        if (!Store.ready() || own.contains(id) || !known(id)) return false;
        if (!Progress.spend(price(id))) return false;
        complete(id);
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.4F, 0.6F);
        return true;
    }

    // ---------- finding pages ----------
    /**
     * Called by the other apps when something good happens (a fish is caught, a crop is harvested, the pet is home, the daily
     * gift is taken): with this chance (percent) a page of a book that is not whole yet turns up. Pages of a book that has some
     * already come more often, so books get finished. At most {@link #DAILY_PAGES} a day. Returns true if a page was found.
     */
    public static boolean find(int percent) {
        ensure();
        if (!Store.ready() || own.size() >= Tales.ALL.size()) return false;
        if (Progress.dailyCount("tale_pages") >= DAILY_PAGES) return false;
        Random r = new Random();
        if (r.nextInt(100) >= percent) return false;
        List<Tales.Tale> need = new ArrayList<>();
        for (Tales.Tale t : Tales.ALL) if (!own.contains(t.id())) need.add(t);
        Tales.Tale pick = null;
        if (r.nextInt(100) < 60) {                                     // the book that is nearest to being whole
            int best = 0;
            for (Tales.Tale t : need) if (found(t.id()) > best) { best = found(t.id()); pick = t; }
        }
        if (pick == null) pick = need.get(r.nextInt(need.size()));
        int mk = mask(pick.id());
        List<Integer> free = new ArrayList<>();
        for (int s = 0; s < Tales.SCENES; s++) if ((mk & (1 << s)) == 0) free.add(s);
        if (!free.isEmpty()) mk |= 1 << free.get(r.nextInt(free.size()));
        Progress.bump("tale_pages");
        String title = Component.translatable("cutemod.tale." + pick.id() + ".title").getString();
        if (mk == FULL) {
            complete(pick.id());
            Progress.toast("cutemod.toast.tale_book", title);
        } else {
            pages.put(pick.id(), mk);
            savePages();
            Progress.toast("cutemod.toast.tale_page", title, Integer.bitCount(mk), Tales.SCENES);
        }
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.7F, 0.5F);
        return true;
    }
}
