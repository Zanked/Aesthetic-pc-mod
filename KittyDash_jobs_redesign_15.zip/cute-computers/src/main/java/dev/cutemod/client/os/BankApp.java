package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Coin Bank: a piggy bank. Put coins in (at most 300 in all); after 7 days you take them out with 10% more.
 * Take them out earlier and you get back only what you put in. Adding coins starts the 7 days again.
 * Saved as "bank": coins inside, time of the last deposit (seconds).
 * <p>
 * The pig is drawn by hand: it breathes, blinks, wags its tail, catches the falling coins in its slot, oinks when you
 * click it, shakes when coins are taken out and wears a crown when the interest is ready.
 */
public class BankApp extends KitApp {
    private static final int MAX = 300, WEEK_S = 7 * 86400, PERCENT = 10;
    private static final int[] STEPS = {10, 50, 100};

    // layout: the pig card on the left, the numbers and buttons on the right
    private static final int PX = 136, PW = 158;
    private static final int CARD_X = 6, CARD_Y = 19, CARD_W = 122, CARD_H = 122;
    private static final int PIG_X = 65, PIG_Y = 84, FLOOR = PIG_Y + 33;

    private static final int GOLD = 0xFFFFD34E, GOLD_DARK = 0xFFD68A10;
    private static final int BODY = 0xFFFFB6CB, SHADE = 0xFFF59AB6, LIGHT = 0xFFFFD8E4, LINE = 0xFFD9708C;
    private static final int SNOUT = 0xFFFF94B4, NOSTRIL = 0xFFB04A68, DARK = 0xFF3A2A3A;

    /** A little thing that flies around: kind 0 = a coin falling into the slot, 1 = sparkle, 2 = heart, 3 = a coin that jumps out. */
    private static final class Part {
        float x, y, vx, vy;
        int age, life, kind, color;

        Part(float x, float y, float vx, float vy, int age, int life, int kind, int color) {
            this.x = x; this.y = y; this.vx = vx; this.vy = vy;
            this.age = age; this.life = life; this.kind = kind; this.color = color;
        }
    }

    private final Random rnd = new Random();
    private final List<Part> parts = new ArrayList<>();
    private final List<int[]> queue = new ArrayList<>();     // sounds that wait for their turn: {delay, kind, pitch * 100, volume * 100}

    private int inside;
    private long since;
    private boolean loaded;
    private int hop, shake, oinkT, arrivals;
    private int idleOink = 700 + rnd.nextInt(900);

    @Override protected int accent() { return 0xFFF08A9A; }

    @Override protected String id() { return "bank"; }

    @Override
    public void attach(Shell shell) { super.attach(shell); load(); }

    private void load() {
        loaded = true;
        inside = 0;
        since = 0;
        try {
            String s = Store.read("bank");
            if (s != null) { String[] p = s.split(","); inside = Math.max(0, Math.min(MAX, Integer.parseInt(p[0]))); since = Long.parseLong(p[1]); }
        } catch (Exception ignored) { }
    }

    private void save() { Store.write("bank", inside + "," + since); }

    private static long now() { return System.currentTimeMillis() / 1000; }

    private long left() { return Math.max(0, since + WEEK_S - now()); }

    private boolean ripe() { return inside > 0 && left() == 0; }

    private int interest() { return inside * PERCENT / 100; }

    // ---------- words ----------

    /** "1 монета", "2 монеты", "5 монет" (English: "1 coin", "2 coins"). */
    private static String coins(int n) {
        String form;
        if ("ru".equals(t("cutemod.bank.lang"))) {
            int m10 = n % 10, m100 = n % 100;
            form = m10 == 1 && m100 != 11 ? "one" : (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) ? "few" : "many";
        } else {
            form = n == 1 ? "one" : "many";
        }
        return t("cutemod.bank.coins." + form, n);
    }

    /** Cuts a text into lines that fit maxW pixels; whatever does not fit in maxLines ends with "...". */
    private static List<String> wrap(Font f, String s, int maxW, int maxLines) {
        List<String> all = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : s.split(" ")) {
            String test = cur.length() == 0 ? w : cur + " " + w;
            if (cur.length() == 0 || CuteFont.width(f, test) <= maxW) {
                cur.setLength(0);
                cur.append(test);
            } else {
                all.add(cur.toString());
                cur.setLength(0);
                cur.append(w);
            }
        }
        if (cur.length() > 0) all.add(cur.toString());
        if (all.size() > maxLines) {
            StringBuilder rest = new StringBuilder();
            for (int i = maxLines - 1; i < all.size(); i++) rest.append(i > maxLines - 1 ? " " : "").append(all.get(i));
            List<String> cut = new ArrayList<>(all.subList(0, maxLines - 1));
            cut.add(CuteFont.cut(f, rest.toString(), maxW));
            return cut;
        }
        return all;
    }

    private static void lines(GuiGraphics g, Font f, List<String> lines, int x, int y, int color) {
        for (int i = 0; i < lines.size(); i++) CuteFont.draw(g, f, lines.get(i), x, y + i * 9, color, false);
    }

    // ---------- sounds ----------

    private void queueSound(int delay, int kind, float pitch, float vol) {
        queue.add(new int[]{delay, kind, Math.round(pitch * 100), Math.round(vol * 100)});
    }

    private static void play(int kind, float pitch, float vol) {
        switch (kind) {
            case 0 -> Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), pitch, vol);        // a coin clinks
            case 1 -> Sfx.ui(SoundEvents.PIG_AMBIENT, pitch, vol);                    // oink
            case 2 -> Sfx.ui(SoundEvents.AMETHYST_BLOCK_CHIME, pitch, vol);           // sparkle
            case 3 -> Sfx.ui(SoundEvents.PLAYER_LEVELUP, pitch, vol);                 // happy fanfare
            case 4 -> Sfx.ui(SoundEvents.EXPERIENCE_ORB_PICKUP, pitch, vol);          // coins pour out
            default -> Sfx.ui(SoundEvents.NOTE_BLOCK_BASS.value(), pitch, vol);       // a sad low note
        }
    }

    // ---------- actions ----------

    private int slotX() { return PIG_X + 14; }

    private int slotY() { return PIG_Y - 21; }

    private void sparkle(float x, float y, int color) {
        parts.add(new Part(x, y, (rnd.nextFloat() - 0.5F) * 1.2F, -0.3F - rnd.nextFloat() * 0.8F, 0, 18 + rnd.nextInt(10), 1, color));
    }

    private void heartAt(float x, float y) {
        parts.add(new Part(x, y, (rnd.nextFloat() - 0.5F) * 0.6F, -0.5F, 0, 42, 2, 0xFFFF5C8A));
    }

    private void oink(float vol, boolean love) {
        oinkT = 50;
        queueSound(0, 1, 1.0F + rnd.nextFloat() * 0.5F, vol);
        if (love) {
            hop = Math.max(hop, 12);
            heartAt(PIG_X - 12 + rnd.nextInt(30), PIG_Y - 38);
            heartAt(PIG_X - 12 + rnd.nextInt(30), PIG_Y - 38);
        }
    }

    private void deposit(int n) {
        int room = MAX - inside;
        n = Math.min(n, room);
        if (n <= 0) { say("cutemod.bank.msg.full", MAX); Sfx.error(); return; }
        if (!Progress.spend(n)) { say("cutemod.bank.msg.nocoins"); Sfx.error(); shake = 12; return; }
        inside += n;
        since = now();                                           // a new deposit starts the week again
        save();
        int c = n >= 100 ? 4 : n >= 50 ? 3 : 2;                  // a bigger deposit is more coins
        for (int i = 0; i < c; i++) parts.add(new Part(slotX() + rnd.nextInt(5) - 2, CARD_Y + 3, 0, 2.7F, -i * 5, 0, 0, 0));
        queueSound(5 * (c - 1) + 24, 1, 1.6F + rnd.nextFloat() * 0.3F, 0.4F);      // a happy little oink after the last coin
        if (inside >= MAX) {                                     // full to the brim
            queueSound(40, 2, 1.4F, 0.5F);
            queueSound(46, 2, 1.8F, 0.5F);
            queueSound(52, 2, 2.0F, 0.5F);
            for (int i = 0; i < 3; i++) heartAt(PIG_X - 14 + i * 14, PIG_Y - 38 - i * 2);
        }
        say("cutemod.bank.msg.in", coins(n));
    }

    private void withdraw() {
        if (inside <= 0) return;
        boolean early = !ripe();
        int back = inside + (early ? 0 : interest());
        Progress.earn(back);
        inside = 0;
        since = 0;
        save();
        shake = 22;
        hop = 20;
        int c = Math.min(14, 4 + back / 25);                     // the coins jump out of the slot
        for (int i = 0; i < c; i++) {
            parts.add(new Part(slotX(), slotY(), (rnd.nextFloat() - 0.5F) * 3.4F, -2.4F - rnd.nextFloat() * 2.2F, -i / 2, 46 + rnd.nextInt(14), 3, 0));
        }
        for (int i = 0; i < Math.min(6, c); i++) queueSound(i * 3, 0, 1.2F + rnd.nextFloat() * 0.9F, 0.5F);
        queueSound(0, 4, 1.0F, 0.5F);
        if (early) {                                             // a sad pig: nothing extra
            queueSound(10, 5, 0.7F, 0.6F);
            queueSound(16, 5, 0.55F, 0.6F);
            queueSound(22, 1, 0.6F, 0.5F);
        } else {                                                 // a happy pig with a crown
            queueSound(8, 3, 1.5F, 0.5F);
            queueSound(14, 2, 1.6F, 0.5F);
            queueSound(20, 2, 2.0F, 0.5F);
            queueSound(26, 1, 1.5F, 0.5F);
            for (int i = 0; i < 4; i++) heartAt(PIG_X - 24 + i * 14, PIG_Y - 36);
            for (int i = 0; i < 8; i++) sparkle(PIG_X - 30 + rnd.nextInt(60), PIG_Y - 30 + rnd.nextInt(30), GOLD);
        }
        oinkT = 60;
        say(early ? "cutemod.bank.msg.early" : "cutemod.bank.msg.out", coins(back));
    }

    @Override
    public void tick() {
        super.tick();
        if (hop > 0) hop--;
        if (shake > 0) shake--;
        if (oinkT > 0) oinkT--;
        if (--idleOink <= 0) { idleOink = 1500 + rnd.nextInt(2400); oink(0.3F, false); }
        if (loaded && ripe() && ticks % 16 == 0) sparkle(PIG_X - 30 + rnd.nextInt(60), PIG_Y - 22 - rnd.nextInt(16), GOLD);

        for (int i = parts.size() - 1; i >= 0; i--) {
            Part p = parts.get(i);
            if (++p.age < 0) continue;
            if (p.kind == 0) {                                   // falls until it is in the slot
                p.y += p.vy;
                if (p.y >= slotY()) {
                    parts.remove(i);
                    hop = Math.max(hop, 14);
                    queueSound(0, 0, 1.4F + 0.2F * (arrivals++ % 4), 0.55F);
                    sparkle(slotX(), slotY(), GOLD);
                    sparkle(slotX(), slotY(), 0xFFFFFFFF);
                }
                continue;
            }
            p.x += p.vx;
            p.y += p.vy;
            if (p.kind == 3) p.vy += 0.18F;
            if (p.age >= p.life || p.y > CARD_Y + CARD_H) parts.remove(i);
        }

        for (int i = queue.size() - 1; i >= 0; i--) {
            int[] s = queue.get(i);
            if (--s[0] <= 0) {
                play(s[1], s[2] / 100F, s[3] / 100F);
                queue.remove(i);
            }
        }
    }

    // ---------- drawing helpers ----------

    private static void ell(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            double q = 1.0 - (dy * (double) dy) / (ry * (double) ry);
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0, q)));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** A triangle pointing up: the tip at (tipX, tipY), h rows tall, the last row 2 * half + 1 wide and moved by shift. */
    private static void tri(GuiGraphics g, int tipX, int tipY, int half, int h, int shift, int argb) {
        for (int i = 0; i < h; i++) {
            double t = (i + 1) / (double) h;
            int hw = (int) Math.round(half * t);
            int c = tipX + (int) Math.round(shift * t);
            g.fill(c - hw, tipY + i, c + hw + 1, tipY + i + 1, argb);
        }
    }

    private static void coin(GuiGraphics g, int cx, int cy, int rx, int ry) {
        ell(g, cx, cy, rx, ry, GOLD_DARK);
        if (rx > 1) ell(g, cx, cy, rx - 1, ry - 1, GOLD);
        if (rx > 2) rect(g, cx - 1, cy - 1, 1, 2, 0xFFFFF2B0);
    }

    private static void star(GuiGraphics g, int x, int y, int argb) {
        rect(g, x - 1, y, 3, 1, argb);
        rect(g, x, y - 1, 1, 3, argb);
    }

    private static void heart(GuiGraphics g, int x, int y, int argb) {
        rect(g, x, y, 2, 1, argb);
        rect(g, x + 3, y, 2, 1, argb);
        rect(g, x, y + 1, 5, 2, argb);
        rect(g, x + 1, y + 3, 3, 1, argb);
        rect(g, x + 2, y + 4, 1, 1, argb);
    }

    private static void leg(GuiGraphics g, int x, int top, int bottom, int col, int hoof) {
        roundRect(g, x, top, 9, bottom - top, 3, col);
        roundRect(g, x, bottom - 5, 9, 5, 2, hoof);
    }

    // ---------- the screen ----------

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        header(g, f);
        String purse = t("cutemod.bank.purse", Progress.coins());
        CuteFont.draw(g, f, purse, W - 6 - CuteFont.width(f, purse), 3, 0xFFFFFFFF, false);
        card(g);
        pig(g, f, in(mx, my, PIG_X - 42, PIG_Y - 34, 84, 70));
        panel(g, f, mx, my);
        toast(g, f);
    }

    /** The soft pink box the pig lives in. */
    private void card(GuiGraphics g) {
        boolean r = ripe();
        roundRect(g, CARD_X, CARD_Y, CARD_W, CARD_H, 6, r ? 0xFFF5D88A : 0xFFF3C9DE);
        roundRect(g, CARD_X + 1, CARD_Y + 1, CARD_W - 2, CARD_H - 2, 5, r ? 0xFFFFF6D6 : 0xFFFFF0F7);
        roundRect(g, CARD_X + 1, FLOOR - 4, CARD_W - 2, CARD_Y + CARD_H - FLOOR + 3, 5, r ? 0xFFFFE9A8 : 0xFFFFDDEB);
        rect(g, CARD_X + 4, FLOOR - 4, CARD_W - 8, 1, r ? 0xFFF5D88A : 0xFFF3C9DE);
        int[][] sp = {{20, 31}, {113, 38}, {104, 62}, {17, 74}};
        for (int i = 0; i < sp.length; i++) {
            int ph = (ticks + i * 27) % 100;
            if (ph < 55) star(g, CARD_X + sp[i][0] - 6, sp[i][1], ph < 12 || ph > 43 ? 0x88FFFFFF : r ? 0xFFFFD34E : 0xFFFFC2D8);
        }
    }

    private void pig(GuiGraphics g, Font f, boolean hover) {
        int bob = (int) Math.round(Math.sin(ticks / 22.0) * 1.2);                         // it breathes
        int jump = hop > 0 ? (int) Math.round(Math.sin(hop / 20.0 * Math.PI) * 7) : 0;
        int sx = shake > 0 ? (int) Math.round(Math.sin(shake * 1.7) * 2.5) : 0;
        int cx = PIG_X + sx, cy = PIG_Y + bob - jump;
        boolean happy = hop > 0 || oinkT > 0 || hover || ripe();
        boolean blink = !happy && ticks % 230 < 7;

        ell(g, PIG_X, FLOOR + 1, 31 - jump * 2, 4, 0x40C0607A);                           // the shadow stays on the floor

        // the coins that lie around the pig: one more for every 50 inside
        int stacks = Math.min(6, (inside + 49) / 50);
        for (int i = 0; i < stacks; i++) coin(g, 107 + (i / 3) * 12, FLOOR - (i % 3) * 3, 5, 2);

        particles(g, true);                                                               // falling coins go in behind the body

        // legs: the far ones are darker; the feet stay on the floor while the body breathes
        int top = cy + 17, bottom = FLOOR - jump;
        leg(g, cx - 9, top, bottom, 0xFFE98BA8, 0xFFB85472);
        leg(g, cx + 21, top, bottom, 0xFFE98BA8, 0xFFB85472);
        leg(g, cx - 23, top, bottom, SHADE, 0xFFC9607F);
        leg(g, cx + 9, top, bottom, SHADE, 0xFFC9607F);

        // the ear (it twitches now and then); the body covers its base
        int ey = ticks % 220 < 6 ? 1 : 0;
        tri(g, cx - 19, cy - 34 + ey, 8, 14, 9, LINE);
        tri(g, cx - 19, cy - 33 + ey, 7, 13, 9, BODY);
        tri(g, cx - 18, cy - 30 + ey, 3, 8, 6, 0xFFFF8FB0);

        // the body: outline, shade below, fill, shine
        ell(g, cx, cy, 33, 27, LINE);
        ell(g, cx, cy, 31, 25, SHADE);
        ell(g, cx, cy - 2, 31, 23, BODY);
        ell(g, cx - 10, cy - 14, 10, 5, LIGHT);
        ell(g, cx + 9, cy - 17, 4, 2, LIGHT);

        // the curly tail wags (faster when the pig is happy)
        int wag = (int) Math.round(Math.sin(ticks / (happy ? 2.5 : 7.0)) * (happy ? 2 : 1));
        int[][] tail = {{31, -2}, {33, -4}, {35, -6}, {37, -6}, {39, -4}, {39, -2}, {37, 0}, {35, -2}};
        for (int[] t : tail) rect(g, cx + t[0], cy + t[1] + wag, 2, 2, 0xFFE8809C);

        // the face
        ell(g, cx - 23, cy + 5, 5, 3, 0x88FF6F95);                                        // cheek
        int sn = oinkT > 0 && (oinkT / 3) % 2 == 0 ? -1 : 0;                              // the snout twitches while it oinks
        int snx = cx - 33 + sn;
        ell(g, snx, cy + 5, 9, 8, LINE);
        ell(g, snx, cy + 5, 8, 7, SNOUT);
        rect(g, snx - 4, cy + 1, 3, 1, 0x88FFFFFF);
        ell(g, snx - 3, cy + 5, 1, 2, NOSTRIL);
        ell(g, snx + 2, cy + 5, 1, 2, NOSTRIL);
        int ex = cx - 17, ey2 = cy - 6;
        if (happy) {                                                                      // happy eye: ^
            rect(g, ex - 3, ey2 + 1, 2, 2, DARK);
            rect(g, ex - 1, ey2 - 1, 3, 2, DARK);
            rect(g, ex + 2, ey2 + 1, 2, 2, DARK);
        } else if (blink) {
            rect(g, ex - 3, ey2, 7, 1, DARK);
        } else {
            ell(g, ex, ey2, 3, 4, DARK);
            rect(g, ex - 2, ey2 - 3, 2, 2, 0xFFFFFFFF);
            rect(g, ex + 1, ey2 + 1, 1, 1, 0xCCFFFFFF);
            rect(g, ex + 3, ey2 - 4, 2, 1, DARK);                                         // lashes
            rect(g, ex + 4, ey2 - 2, 2, 1, DARK);
        }

        // the coin slot on the back
        if (hop > 0) rect(g, cx + 7, cy - 19, 15, 5, 0x55FFD34E);
        rect(g, cx + 8, cy - 18, 13, 3, NOSTRIL);
        rect(g, cx + 9, cy - 17, 11, 1, 0xFF6A2A40);

        // a bow, or a crown when the interest is ready
        if (ripe()) {
            rect(g, cx - 3, cy - 31, 13, 4, GOLD);
            tri(g, cx - 2, cy - 36, 2, 5, 0, GOLD);
            tri(g, cx + 3, cy - 38, 2, 7, 0, GOLD);
            tri(g, cx + 8, cy - 36, 2, 5, 0, GOLD);
            rect(g, cx + 3, cy - 30, 2, 2, 0xFFE8506E);
        } else {
            ell(g, cx - 2, cy - 28, 5, 4, 0xFFD93A5C);
            ell(g, cx + 8, cy - 28, 5, 4, 0xFFD93A5C);
            ell(g, cx - 2, cy - 28, 4, 3, 0xFFFF6F8C);
            ell(g, cx + 8, cy - 28, 4, 3, 0xFFFF6F8C);
            rect(g, cx - 4, cy - 30, 3, 1, 0xFFFFB3C4);
            rect(g, cx + 6, cy - 30, 3, 1, 0xFFFFB3C4);
            disc(g, cx + 3, cy - 28, 2, 0xFFD93A5C);
            rect(g, cx + 3, cy - 29, 1, 1, 0xFFFF9AB0);
        }

        particles(g, false);

        if (oinkT > 0) {                                                                  // "Oink!" in a bubble
            String s = t("cutemod.bank.oink");
            int tw = CuteFont.width(f, s) + 10, bx = CARD_X + 3, by = PIG_Y - 44;
            roundRect(g, bx - 1, by - 1, tw + 2, 15, 5, LINE);
            roundRect(g, bx, by, tw, 13, 4, 0xFFFFFFFF);
            rect(g, bx + tw - 10, by + 13, 5, 1, 0xFFFFFFFF);
            rect(g, bx + tw - 9, by + 14, 3, 1, 0xFFFFFFFF);
            rect(g, bx + tw - 8, by + 15, 1, 1, 0xFFFFFFFF);
            CuteFont.draw(g, f, s, bx + 5, by + 3, TEXT, false);
        }
    }

    private void particles(GuiGraphics g, boolean behind) {
        for (Part p : parts) {
            if (p.age < 0 || (p.kind == 0) != behind) continue;
            int px = Math.round(p.x), py = Math.round(p.y);
            int a = Math.max(8, Math.min(255, (int) ((1F - p.age / (float) Math.max(1, p.life)) * 400)));
            int rgb = p.color & 0xFFFFFF;
            switch (p.kind) {
                case 0 -> coin(g, px, py, Math.max(1, (int) Math.round(4 * Math.abs(Math.cos(p.age * 0.45)))), 4);
                case 1 -> star(g, px, py, (a << 24) | rgb);
                case 2 -> heart(g, px - 2, py - 2, (a << 24) | rgb);
                default -> coin(g, px, py, Math.max(1, (int) Math.round(3 * Math.abs(Math.cos(p.age * 0.5)))), 3);
            }
        }
    }

    /** The numbers, the week bar and the buttons. */
    private void panel(GuiGraphics g, Font f, int mx, int my) {
        CuteFont.draw(g, f, t("cutemod.bank.inside"), PX, 19, MUTED, false);
        coin(g, PX + 6, 37, 5, 5);
        g.pose().pushPose();                                                              // the big number
        g.pose().translate(PX + 16, 31, 0);
        g.pose().scale(1.5F, 1.5F, 1F);
        CuteFont.draw(g, f, inside + " / " + MAX, 0, 0, TEXT, false);
        g.pose().popPose();

        if (inside > 0) {
            long l = left();
            float p = Math.max(0F, Math.min(1F, 1F - l / (float) WEEK_S));
            rect(g, PX, 47, PW, 6, 0xFFEBDDF7);
            rect(g, PX, 47, Math.round(PW * p), 6, ripe() ? 0xFF5BBF6A : accent());
            String st;
            if (ripe()) st = t("cutemod.bank.ripe", interest());
            else if (l >= 3600 * 24) st = t("cutemod.bank.wait", l / 86400, l / 3600 % 24);
            else st = t("cutemod.bank.wait.short", l / 3600, l / 60 % 60);
            lines(g, f, wrap(f, st, PW, 2), PX, 56, ripe() ? 0xFF3E9A4A : MUTED);
        } else {
            lines(g, f, wrap(f, t("cutemod.bank.empty", PERCENT), PW, 2), PX, 50, MUTED);
        }

        for (int i = 0; i < STEPS.length; i++) {
            btn(g, f, mx, my, PX + i * 54, 78, 50, "+" + STEPS[i], Progress.coins() >= STEPS[i] && inside < MAX ? 0 : 2);
        }
        String take = inside > 0 ? (ripe() ? t("cutemod.bank.take", inside + interest()) : t("cutemod.bank.takeearly", inside)) : t("cutemod.bank.nothing");
        btn(g, f, mx, my, PX, 98, PW, take, inside > 0 ? (ripe() ? 1 : 0) : 2);
        lines(g, f, wrap(f, t("cutemod.bank.rule", PERCENT), PW, 2), PX, 120, MUTED);
    }

    /** The message at the bottom: it fades out. */
    private void toast(GuiGraphics g, Font f) {
        if (msgT <= 0) return;
        String m = CuteFont.cut(f, msg, W - 24);
        int a = Math.min(255, msgT * 12);
        int tw = CuteFont.width(f, m) + 14, tx = (W - tw) / 2;
        roundRect(g, tx, 146, tw, 14, 5, (a << 24) | 0x3A2A3A);
        CuteFont.draw(g, f, m, tx + 7, 149, (a << 24) | 0xFFFFFF, false);
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < STEPS.length; i++) if (in(x, y, PX + i * 54, 78, 50, 16)) { deposit(STEPS[i]); return true; }
        if (in(x, y, PX, 98, PW, 16)) { withdraw(); return true; }
        if (in(x, y, PIG_X - 42, PIG_Y - 34, 84, 70)) { oink(0.7F, true); return true; }   // pet the pig
        return false;
    }
}
