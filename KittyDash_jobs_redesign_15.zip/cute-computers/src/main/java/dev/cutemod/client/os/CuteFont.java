package dev.cutemod.client.os;

import dev.cutemod.CuteMod;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

/**
 * The cute pixel font of the computer (assets/cutemod/font/cute.json, Latin and Cyrillic, rounded and friendly).
 * Every text of the OS is drawn through here instead of {@code g.drawString}. A character the font does not have
 * (for example a dash or a symbol) falls back to the normal game font. Set {@link #ENABLED} to false to go back
 * to the normal font everywhere. The player picks the weight (cute / bold / normal) in Settings.
 */
public final class CuteFont {
    public static final boolean ENABLED = true;
    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "cute");
    public static final ResourceLocation BOLD_ID = ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "cute_bold");
    /** The fonts of both weights in three sizes: small (glyphs 7 px high), normal (9, the original) and large (11). Each size is its own font file. */
    private static final Style[][] STYLES = {
            {font("cute_s"), font("cute"), font("cute_l")},
            {font("cute_bold_s"), font("cute_bold"), font("cute_bold_l")}};

    private static Style font(String name) { return Style.EMPTY.withFont(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, name)); }

    /** The weight of the font (Settings > Other > Font): 0 = cute, 1 = cute bold, 2 = the normal game font. Kept in the computer's data. */
    public static final int REGULAR_W = 0, BOLD_W = 1, SYSTEM_W = 2;
    /** The size (Settings > Other > Font size): 0 = small, 1 = normal, 2 = large. It belongs to the cute fonts; the game's own font has one size. */
    public static final int SMALL = 0, NORMAL = 1, LARGE = 2;
    private static int weight, size = NORMAL;
    private static long readAt;

    private static void refresh() {
        long now = System.currentTimeMillis();
        if (now - readAt <= 500) return;
        readAt = now;                                               // look at the saved values now and then (they arrive after the login)
        if (!Store.ready()) return;
        try { weight = sane(Integer.parseInt(String.valueOf(Store.read("fontweight")).trim())); }
        catch (NumberFormatException ignored) { weight = REGULAR_W; }
        try { size = Math.max(SMALL, Math.min(LARGE, Integer.parseInt(String.valueOf(Store.read("fontsize")).trim()))); }
        catch (NumberFormatException ignored) { size = NORMAL; }
    }

    public static int weight() { refresh(); return weight; }

    public static int size() { refresh(); return size; }

    public static void setSize(int s) {
        size = Math.max(SMALL, Math.min(LARGE, s));
        readAt = System.currentTimeMillis();
        Store.write("fontsize", Integer.toString(size));
    }

    /** Only the three weights exist. A saved "modern" (3, a font that was removed) becomes the cute one. */
    private static int sane(int w) { return w < 0 || w > SYSTEM_W ? REGULAR_W : w; }

    public static void setWeight(int w) {
        weight = sane(w);
        readAt = System.currentTimeMillis();
        Store.write("fontweight", Integer.toString(weight));
    }

    /** The style to draw with, or null for the normal game font. */
    private static Style style() {
        if (!ENABLED) return null;
        int w = weight();
        return w == SYSTEM_W ? null : STYLES[w][size()];
    }

    private CuteFont() {}

    private static Component cute(String s, Style st) { return Component.literal(s).withStyle(st); }

    private static Component cute(Component s, Style st) {
        MutableComponent root = Component.empty().withStyle(st);   // the parts inherit the font, keep their own colours
        return root.append(s);
    }

    public static int draw(GuiGraphics g, Font f, String s, int x, int y, int argb, boolean shadow) {
        Style st = style();
        return st != null ? g.drawString(f, cute(s, st), x, y, argb, shadow) : g.drawString(f, s, x, y, argb, shadow);
    }

    public static int draw(GuiGraphics g, Font f, String s, int x, int y, int argb) { return draw(g, f, s, x, y, argb, true); }

    public static int draw(GuiGraphics g, Font f, Component s, int x, int y, int argb, boolean shadow) {
        Style st = style();
        return st != null ? g.drawString(f, cute(s, st), x, y, argb, shadow) : g.drawString(f, s, x, y, argb, shadow);
    }

    public static int draw(GuiGraphics g, Font f, Component s, int x, int y, int argb) { return draw(g, f, s, x, y, argb, true); }

    /** s as a component in the picked font (plain when the normal game font is picked): for code that measures or wraps text itself. */
    public static Component styled(String s) {
        Style st = style();
        return st != null ? cute(s, st) : Component.literal(s);
    }

    public static Component styled(Component s) {
        Style st = style();
        return st != null ? cute(s, st) : s;
    }

    /** A ready line of text keeps the font it has. */
    public static int draw(GuiGraphics g, Font f, FormattedCharSequence s, int x, int y, int argb, boolean shadow) {
        return g.drawString(f, s, x, y, argb, shadow);
    }

    public static int draw(GuiGraphics g, Font f, FormattedCharSequence s, int x, int y, int argb) { return draw(g, f, s, x, y, argb, true); }

    /** The width of a line exactly as {@link #draw} draws it (the picked font, weight and size). Use this, not font.width, to lay text out. */
    public static int width(Font f, String s) {
        Style st = style();
        return st != null ? f.width(cute(s, st)) : f.width(s);
    }

    public static int width(Font f, Component s) {
        Style st = style();
        return st != null ? f.width(cute(s, st)) : f.width(s);
    }

    /** s cut to at most maxW pixels (measured like {@link #width}), with "..." where something was cut off. */
    public static String cut(Font f, String s, int maxW) {
        if (width(f, s) <= maxW) return s;
        for (int n = s.length() - 1; n > 0; n--) {
            String t = s.substring(0, n).stripTrailing() + "...";
            if (width(f, t) <= maxW) return t;
        }
        return "";
    }

    // ---------- the small size, whatever size the player picked: for dense panels (the notification centre) ----------

    private static Style smallStyle() {
        if (!ENABLED) return null;
        int w = weight();
        return w == SYSTEM_W ? null : STYLES[w][SMALL];
    }

    /** A line in the small size, without a shadow. */
    public static int drawSmall(GuiGraphics g, Font f, String s, int x, int y, int argb) {
        Style st = smallStyle();
        return st != null ? g.drawString(f, cute(s, st), x, y, argb, false) : g.drawString(f, s, x, y, argb, false);
    }

    public static int widthSmall(Font f, String s) {
        Style st = smallStyle();
        return st != null ? f.width(cute(s, st)) : f.width(s);
    }

    /** s cut to at most maxW pixels in the small size, with "..." when something was cut off. */
    public static String cutSmall(Font f, String s, int maxW) {
        if (widthSmall(f, s) <= maxW) return s;
        for (int n = s.length() - 1; n > 0; n--) {
            String t = s.substring(0, n).stripTrailing() + "...";
            if (widthSmall(f, t) <= maxW) return t;
        }
        return "";
    }

    /** s wrapped into at most maxLines lines of at most maxW pixels in the small size; what does not fit ends the last line with "...". */
    public static List<String> wrapSmall(Font f, String s, int maxW, int maxLines) {
        List<String> out = new ArrayList<>();
        String rest = s.trim();
        while (!rest.isEmpty() && out.size() < maxLines) {
            if (widthSmall(f, rest) <= maxW) { out.add(rest); break; }
            if (out.size() == maxLines - 1) { out.add(cutSmall(f, rest, maxW)); break; }
            int cut = rest.length();
            while (cut > 1 && widthSmall(f, rest.substring(0, cut)) > maxW) cut--;
            int sp = rest.lastIndexOf(' ', cut);                    // break at the last space that fits
            int at = sp > 0 ? sp : cut;
            out.add(rest.substring(0, at).trim());
            rest = rest.substring(at).trim();
        }
        return out;
    }
}
