package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Five animated wallpapers (numbers 30-34): a girl at a window under the moon, a girl under the sakura, a magic forest
 * with fireflies, a misty pine morning and a campfire night. The girls are original anime-style characters drawn with
 * rectangles and discs: their hair sways, they blink, the stars twinkle and the petals fall.
 * <p>
 * Everything is drawn in a design space of 160 x 100 units, scaled to the box by its height and centered
 * (the sky and the ground fill the whole box), and clipped to the box by hand (no scissor, see WallpapersExtra).
 */
final class AnimeWallpapers {
    private static GuiGraphics gg;
    private static int bx, by, bw, bh;
    private static float s;          // pixels per design unit
    private static int ox;           // screen x of design x = 0
    private static int t;            // time: 20 steps a second
    private static float lo, hi, vw;  // the left and right edge of the box and its width, in design units (the scenery fills all of it)

    private AnimeWallpapers() {}

    static void draw(GuiGraphics g, int x, int y, int w, int h, int idx) {
        gg = g; bx = x; by = y; bw = Math.max(1, w); bh = Math.max(1, h);
        s = bh / 100F;
        ox = bx + Math.round((bw - 160 * s) / 2F);
        vw = bw / s; lo = (bx - ox) / s; hi = lo + vw;
        t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        switch (idx) {
            case 30 -> moonWindow();
            case 31 -> sakuraGirl();
            case 32 -> magicForest();
            case 33 -> mistyPines();
            default -> campfire();
        }
        gg = null;
    }

    // ---------- drawing helpers (design units) ----------
    private static int X(float v) { return ox + Math.round(v * s); }

    private static int Y(float v) { return by + Math.round(v * s); }

    /** A filled box in screen pixels, cut to the wallpaper box. */
    private static void px(int x0, int y0, int x1, int y1, int argb) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fill(x0, y0, x1, y1, argb);
    }

    /** A filled box in design units (at least one pixel). */
    private static void R(float x0, float y0, float x1, float y1, int argb) {
        int a = X(x0), b = Y(y0), c = Math.max(X(x1), a + 1), d = Math.max(Y(y1), b + 1);
        px(a, b, c, d, argb);
    }

    private static void D(float cx, float cy, float rad, int argb) {
        int r = Math.max(1, Math.round(rad * s)), pcx = X(cx), pcy = Y(cy);
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            px(pcx - dx, pcy + dy, pcx + dx + 1, pcy + dy + 1, argb);
        }
    }

    /** A triangle with its tip up, base width w, height h (design units). */
    private static void T(float cx, float top, float w, float h, int argb) {
        int rows = Math.max(1, Math.round(h * s)), pcx = X(cx), pw = Math.max(1, Math.round(w * s)), y0 = Y(top);
        for (int row = 0; row < rows; row++) {
            int ww = Math.max(1, pw * (row + 1) / rows);
            px(pcx - ww / 2, y0 + row, pcx - ww / 2 + ww, y0 + row + 1, argb);
        }
    }

    private static void sky(int top, int bottom) { gg.fillGradient(bx, by, bx + bw, by + bh, top, bottom); }

    private static int mix(int a, int b, float f) {
        f = Math.max(0F, Math.min(1F, f));
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
        return 0xFF000000 | (int) (ar + (br - ar) * f) << 16 | (int) (ag + (bg - ag) * f) << 8 | (int) (ab + (bb - ab) * f);
    }

    private static int alpha(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }

    private static float wave(float speed, float phase) { return (float) Math.sin(t * speed + phase); }

    private static void stars(int count, int seed) {
        for (int i = 0; i < count; i++) {
            float sx = lo + (i * 53 + seed * 17) % vw, sy = (i * 29 + seed * 7) % 70;
            boolean on = (t / 6 + i * 3) % 9 != 0;
            R(sx, sy, sx + 1.2F, sy + 1.2F, on ? 0xFFFFF6C8 : 0x66FFF6C8);
        }
    }

    // ---------- the girl ----------
    /**
     * An original anime-style girl, seen from the front, head radius 12 units. (cx, cy) is the middle of the face.
     * style 0: long dark hair and pajamas (lavender); style 1: long pink hair, a ribbon and a school uniform;
     * style 2: a ponytail and a warm jacket.
     */
    private static void girl(float cx, float cy, int style) {
        int hair = style == 0 ? 0xFF2A2440 : style == 1 ? 0xFFF08AB8 : 0xFF8A4A2A;
        int shade = mix(hair, 0xFF000000, 0.25F);
        int shine = mix(hair, 0xFFFFFFFF, 0.35F);
        int eye = style == 0 ? 0xFF7A5AE0 : style == 1 ? 0xFF3AA0E8 : 0xFF3A9A5A;
        int skin = 0xFFFFE3D0;
        float sway = wave(0.09F, style) * 1.6F;
        // hair behind: a big shape and the long locks that swing
        D(cx, cy - 1, 15, hair);
        int locks = style == 2 ? 14 : 40;
        for (int yy = 0; yy < locks; yy += 1) {
            float off = wave(0.12F, yy / 9F + style) * 2.2F * yy / locks + sway * yy / locks;
            float half = style == 2 ? 11 : 15 - yy * 0.04F;
            R(cx - half + off, cy + 2 + yy, cx + half + off, cy + 3 + yy, yy % 7 < 2 ? shade : hair);
        }
        if (style == 2) {                                                              // the ponytail swings to one side
            for (int yy = 0; yy < 30; yy++) {
                float off = 13 + wave(0.13F, yy / 7F) * 3F * yy / 30 + yy * 0.25F;
                R(cx + off - 3F + yy * 0.05F, cy - 6 + yy, cx + off + 3F - yy * 0.06F, cy - 5 + yy, yy % 6 < 2 ? shade : hair);
            }
        }
        // the body
        int dress = style == 0 ? 0xFFB8A8F0 : style == 1 ? 0xFFFFFFFF : 0xFFE87A4A;
        for (int yy = 0; yy < 26; yy++) {
            float half = 6 + yy * (style == 1 ? 0.22F : 0.12F);
            int c = style == 1 && yy > 12 ? 0xFF3A5AA8 : dress;
            R(cx - half, cy + 13 + yy, cx + half, cy + 14 + yy, yy < 2 ? skin : c);
        }
        if (style == 1) { R(cx - 3, cy + 15, cx + 3, cy + 17, 0xFFE5486F); R(cx - 1, cy + 17, cx + 1, cy + 22, 0xFFE5486F); }     // the bow of the uniform
        // the face and the fringe
        D(cx, cy + 1, 12, skin);
        D(cx, cy - 7, 13, hair);
        for (int tuft = -3; tuft <= 3; tuft++) {
            float tx = cx + tuft * 3.6F + wave(0.1F, tuft) * 0.4F;
            R(tx - 1.8F, cy - 8, tx + 1.8F, cy - 3 + (tuft % 2 == 0 ? 3 : 1), hair);
            R(tx - 0.6F, cy - 8, tx + 0.2F, cy - 4, shine);
        }
        R(cx - 13, cy - 8, cx - 10, cy + 12, hair);                                       // the side locks along the face
        R(cx + 10, cy - 8, cx + 13, cy + 12, hair);
        // the eyes (they blink)
        boolean blink = t % 90 < 4;
        for (int side = -1; side <= 1; side += 2) {
            float ex = cx + side * 5.2F - 2.4F;
            if (blink) { R(ex, cy + 1.2F, ex + 4.8F, cy + 2.2F, 0xFF3A2A3A); continue; }
            R(ex, cy - 2, ex + 4.8F, cy + 4.5F, 0xFFFFFFFF);
            R(ex + 0.6F, cy - 1.5F, ex + 4.2F, cy + 4.5F, eye);
            R(ex + 1.4F, cy - 0.5F, ex + 3.4F, cy + 3.2F, 0xFF1E1A30);
            R(ex + 0.9F, cy - 1.2F, ex + 2.2F, cy + 0.4F, 0xFFFFFFFF);                      // the shine in the eye
            R(ex, cy - 2.6F, ex + 4.8F, cy - 1.8F, 0xFF3A2A3A);                              // the lashes
        }
        R(cx - 8.5F, cy + 5.5F, cx - 5.5F, cy + 6.5F, 0x88FF7A9A);                         // the blush
        R(cx + 5.5F, cy + 5.5F, cx + 8.5F, cy + 6.5F, 0x88FF7A9A);
        R(cx - 1, cy + 7.5F, cx + 1, cy + 8.3F, 0xFFC0605A);                               // the little smile
        // an accessory
        if (style == 1) { D(cx - 10, cy - 12, 3, 0xFFE5486F); D(cx - 5, cy - 12, 3, 0xFFE5486F); D(cx - 7.5F, cy - 12, 1.6F, 0xFFFF9AB8); }
        if (style == 0) { R(cx + 8, cy - 11, cx + 9.4F, cy - 9.6F, (t / 8) % 2 == 0 ? 0xFFFFE066 : 0xFFFFF6C8); }              // a twinkling clip
        if (style == 2) { R(cx + 9, cy - 9, cx + 12, cy - 7, 0xFFE87A4A); }
    }

    // ---------- 30: the girl at the window ----------
    private static void moonWindow() {
        sky(0xFF0E1230, 0xFF2E2A5C);
        stars(34, 3);
        float mx = hi - 38;
        D(mx, 28, 17, alpha(0xFFF0B0, 36)); D(mx, 28, 14, 0xFFFFF0B0); D(mx + 5, 25, 12, 0xFF2A2A5A);
        if (t % 260 < 22) {                                                              // a shooting star now and then
            int k = t % 260;
            for (int i = 0; i < 8; i++) R(hi - 20 - k * 3.2F + i * 2.2F, 8 + k * 1.4F - i, hi - 18 - k * 3.2F + i * 2.2F, 9 + k * 1.4F - i, alpha(0xFFFFFF, 220 - i * 25));
        }
        R(lo, 82, hi, 100, 0xFF2A1E3A); R(lo, 80, hi, 83, 0xFF4A3A5A);                   // the window sill
        int houses = Math.max(6, (int) (vw / 16));
        for (int i = 0; i < houses; i++) { float hx = lo + 4 + i * vw / houses; R(hx, 70 + (i * 5) % 8, hx + 8, 80, 0xFF14102A); }   // the roofs of the town below
        for (int i = 0; i < houses; i++) if ((t / 30 + i) % 5 != 0) { float hx = lo + 6 + i * vw / houses; R(hx, 73 + (i * 5) % 8, hx + 2, 75 + (i * 5) % 8, 0xFFFFE08A); }
        girl(52, 52, 0);
        // a cat on the sill: its tail swings
        float c0 = hi - 58;
        R(c0, 70, c0 + 14, 80, 0xFF14102A); D(c0 + 7, 66, 5, 0xFF14102A); T(c0 + 3.5F, 58, 4, 5, 0xFF14102A); T(c0 + 10.5F, 58, 4, 5, 0xFF14102A);
        for (int i = 0; i < 9; i++) R(c0 + 14 + i * 0.7F + wave(0.1F, i / 3F) * 2F * i / 9, 78 - i * 1.4F, c0 + 16 + i * 0.7F + wave(0.1F, i / 3F) * 2F * i / 9, 80 - i * 1.4F, 0xFF14102A);
        if (t % 120 < 90) { R(c0 + 5, 65, c0 + 6.2F, 66.2F, 0xFFFFE066); R(c0 + 9, 65, c0 + 10.2F, 66.2F, 0xFFFFE066); }
    }

    // ---------- 31: the girl under the sakura ----------
    private static void sakuraGirl() {
        sky(0xFFFFD3E6, 0xFFFFF4F8);
        D(lo + 30, 22, 12, 0x66FFFFFF); D(lo + 30, 22, 8, 0xAAFFFFFF);
        R(lo, 84, hi, 100, 0xFFA8DFA0); R(lo, 84, hi, 86, 0xFF8ACF88);
        for (int i = 0; i < (int) (vw / 8); i++) R(lo + 6 + i * 8, 88 + (i * 3) % 9, lo + 8 + i * 8, 90 + (i * 3) % 9, 0xFF8ACF88);
        // two sakura trees
        for (int tree = 0; tree < 2; tree++) {
            float x = tree == 0 ? lo + 18 : hi - 18;
            R(x - 3, 40, x + 3, 86, 0xFF7A4A3A); R(x - 1, 45, x + 1, 86, 0xFF8A5A48);
            for (int i = 0; i < 9; i++) {
                float cx = x + (i % 3 - 1) * 12 + wave(0.04F, i) * 1.2F, cy = 22 + (i / 3) * 10 + (i % 2) * 4;
                D(cx, cy, 10, i % 2 == 0 ? 0xFFFFB6D0 : 0xFFFFA0C0);
                D(cx - 2, cy - 2, 5, 0xFFFFD0E2);
            }
        }
        girl(82, 50, 1);
        // falling petals
        for (int i = 0; i < 26; i++) {
            float fall = (t * (0.5F + (i % 5) * 0.12F) + i * 37) % 120;
            float x = lo + (i * 41) % vw + wave(0.05F + (i % 4) * 0.01F, i) * 8F, y = fall - 10;
            int c = i % 3 == 0 ? 0xFFFFFFFF : 0xFFFFA8C8;
            R(x, y, x + 2.4F, y + 1.6F, c);
            R(x + 0.6F, y + 0.4F, x + 3F, y + 1.2F, alpha(c, 200));
        }
    }

    // ---------- 32: the magic forest ----------
    private static void magicForest() {
        sky(0xFF081A18, 0xFF1C4A38);
        // light rays from the top left
        for (int i = 0; i < 4; i++) {
            float k = 0.5F + 0.5F * wave(0.03F, i * 1.7F);
            for (int row = 0; row < 90; row += 2) R(lo + 20 + i * vw / 4.5F + row * 0.35F, row, lo + 30 + i * vw / 4.5F + row * 0.55F, row + 2, alpha(0xE8FFB0, (int) (14 + 14 * k)));
        }
        // trees: three layers of trunks and crowns; the far ones are darker and sway less
        for (int layer = 0; layer < 3; layer++) {
            int col = mix(0xFF0A2A20, 0xFF030E0C, layer / 2F);
            int n = 6 + layer * 2;
            for (int i = 0; i < n; i++) {
                float x = lo + (i * vw / n) + (layer * 13) % 17 + 6, w = 4 + (2 - layer) * 2.5F;
                float sw = wave(0.03F, i + layer) * (0.8F + (2 - layer) * 0.5F);
                R(x - w / 2, 0, x + w / 2, 100, col);
                for (int b = 0; b < 4; b++) D(x + sw + (b % 2 == 0 ? -1 : 1) * (4 + layer), 14 + b * 18 + layer * 4, 8 + (2 - layer) * 2, mix(col, 0xFF2A7A4A, 0.18F));
            }
        }
        R(lo, 90, hi, 100, 0xFF06120E);
        // glowing mushrooms
        for (int i = 0; i < 6; i++) {
            float x = lo + 12 + i * (vw - 24) / 6 + (i * 7) % 9, h = 4 + (i % 3) * 2;
            int c = i % 2 == 0 ? 0xFF6AD8FF : 0xFFFF8AD8;
            D(x, 90 - h + 1, 6, alpha(c, 30 + (int) (20 * wave(0.07F, i))));
            R(x - 0.8F, 90 - h, x + 0.8F, 91, 0xFFE8F0E8);
            D(x, 90 - h, 3.2F, c);
        }
        // fireflies
        for (int i = 0; i < 22; i++) {
            float x = lo + (i * 47) % vw + wave(0.021F + i * 0.0013F, i) * 14F, y = 20 + (i * 31) % 62 + wave(0.027F + i * 0.001F, i * 2F) * 8F;
            float glow = 0.5F + 0.5F * wave(0.08F, i * 1.3F);
            D(x, y, 3.2F, alpha(0xE8FF60, (int) (30 * glow)));
            R(x - 0.7F, y - 0.7F, x + 0.7F, y + 0.7F, alpha(0xF8FFA0, (int) (120 + 135 * glow)));
        }
        // mist at the bottom
        for (int i = 0; i < 3; i++) R(lo + (t * (0.2F + i * 0.1F) + i * 60) % (vw + 60) - 60, 78 + i * 5, lo + (t * (0.2F + i * 0.1F) + i * 60) % (vw + 60) + 40, 84 + i * 5, 0x1AFFFFFF);
    }

    // ---------- 33: the misty pines ----------
    private static void mistyPines() {
        sky(0xFFFFD8B0, 0xFFE8F0F4);
        D(hi - 48, 38, 16, alpha(0xFFF0C8, 60)); D(hi - 48, 38, 11, 0xFFFFF4D8);
        // pine ridges: the farther, the paler
        for (int layer = 0; layer < 4; layer++) {
            int col = mix(0xFFB8C8CC, 0xFF1E4A3C, layer / 3F);
            float base = 56 + layer * 10;
            int n = 9 + layer * 3;
            for (int i = 0; i < n; i++) {
                float x = lo + i * vw / n + (layer * 11) % 7 + wave(0.02F + layer * 0.005F, i) * (0.4F + layer * 0.3F);
                float h = 16 + (i * 7 + layer * 5) % 9 + layer * 3, w = 9 + layer * 2;
                R(x - 0.7F, base + h - 3, x + 0.7F, base + h + 12, col);
                T(x, base, w, h, col);
                T(x, base - 7, w * 0.7F, h * 0.7F, col);
            }
            R(lo, base + 22 + layer * 3, hi, 100, col);
            // a band of mist between the layers
            float drift = lo + (t * (0.12F + layer * 0.07F) + layer * 50) % (vw + 80) - 80;
            R(drift, base + 12, drift + 110, base + 18, 0x40FFFFFF);
            R(drift - 60, base + 16, drift + 30, base + 21, 0x30FFFFFF);
        }
        // birds
        for (int i = 0; i < 3; i++) {
            float x = lo + (t * (0.5F + i * 0.15F) + i * 60) % (vw + 30) - 15, y = 14 + i * 7 + wave(0.05F, i) * 2F;
            boolean up = (t / 5 + i) % 2 == 0;
            R(x, y + (up ? 0 : 1), x + 3, y + (up ? 1 : 2), 0xFF4A4A5A); R(x + 3, y + (up ? 1 : 0), x + 6, y + (up ? 2 : 1), 0xFF4A4A5A);
        }
    }

    // ---------- 34: the campfire ----------
    private static void campfire() {
        sky(0xFF081A2E, 0xFF1E3A4A);
        stars(30, 5);
        for (int i = 0; i < (int) (vw / 20) + 1; i++) {                                    // pines in the dark
            float x = lo + i * 20 - 4, h = 30 + (i * 7) % 14;
            T(x, 70 - h, 18, h, 0xFF0A1A1E); T(x, 70 - h * 0.6F, 20, h * 0.6F, 0xFF0A1A1E);
        }
        R(lo, 76, hi, 100, 0xFF16302A); R(lo, 76, hi, 77.5F, 0xFF1E4A3C);
        float tx = hi - 36;
        T(tx, 52, 34, 26, 0xFFE8B86A); R(tx - 1.5F, 66, tx + 1.5F, 78, 0xFF3A2A1A);    // the tent
        T(tx, 58, 4, 20, 0xFF3A2A1A);
        float fire = 0.5F + 0.5F * wave(0.35F, 0);                                      // the warm light flickers
        D(72, 72, 34, alpha(0xFF9A30, (int) (14 + 10 * fire)));
        D(72, 72, 20, alpha(0xFF9A30, (int) (18 + 14 * fire)));
        girl(44, 52, 2);
        // logs and flames
        R(62, 76, 82, 79, 0xFF4A2A1A); R(64, 73, 80, 76, 0xFF5A3A22);
        for (int i = 0; i < 5; i++) {
            float fl = 8 + 5 * wave(0.4F + i * 0.07F, i * 2F), x = 66 + i * 3.2F;
            T(x, 74 - fl, 5, fl, i % 2 == 0 ? 0xFFFF8A2A : 0xFFFFC040);
        }
        T(72, 66, 3, 6, 0xFFFFF0A0);
        // sparks rising
        for (int i = 0; i < 12; i++) {
            float k = (t * (0.6F + (i % 3) * 0.2F) + i * 23) % 50;
            float x = 72 + wave(0.1F, i) * 6F + (i % 5 - 2) * 2F, y = 66 - k;
            R(x, y, x + 1.1F, y + 1.1F, alpha(0xFFC040, (int) Math.max(0, 255 - k * 5)));
        }
    }
}
