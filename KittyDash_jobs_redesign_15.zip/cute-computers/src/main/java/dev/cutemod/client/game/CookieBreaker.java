package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Breakout: bounce the ball off the plate and eat all the cookies. */
public class CookieBreaker extends MiniGame {
    private static final int COLS = 10, ROWS = 5, BW = 20, BH = 8, PAD_W = 40, PAD_H = 5, PY = H - 14;
    private static final int[] ROW_COLORS = {0xFFF58FB8, 0xFFF5A623, 0xFFE0B46A, 0xFFC98B5A, 0xFF9B6B45};

    private final boolean[][] bricks = new boolean[ROWS][COLS];
    private double px, bx, by, vx, vy, speed;
    private int lives, level, bricksLeft;
    private boolean launched;

    @Override
    public void reset() {
        score = 0; over = false; lives = 3; level = 1; speed = 2.2;
        px = W / 2.0;
        fillBricks();
        resetBall();
    }

    private void fillBricks() {
        for (boolean[] row : bricks) java.util.Arrays.fill(row, true);
        bricksLeft = ROWS * COLS;
    }

    private void resetBall() {
        launched = false;
        bx = px; by = PY - 4; vx = 0; vy = 0;
    }

    private void launch() {
        if (launched) return;
        launched = true;
        double a = (rnd.nextDouble() - 0.5) * 0.8;
        vx = speed * Math.sin(a);
        vy = -speed * Math.cos(a);
        pling(1.5F);
    }

    @Override
    public boolean click(int x, int y, int button) { launch(); return true; }

    @Override
    public boolean key(int k) {
        if (k == KEY_SPACE || k == KEY_UP) { launch(); return true; }
        return false;
    }

    private boolean hit(double x, double y) {
        int c = (int) Math.floor((x - 1) / 22.0), r = (int) Math.floor((y - 14) / 10.0);
        if (c < 0 || c >= COLS || r < 0 || r >= ROWS || !bricks[r][c]) return false;
        if ((x - 1) - c * 22 >= BW || (y - 14) - r * 10 >= BH) return false;
        bricks[r][c] = false;
        bricksLeft--;
        score += 5 * (ROWS - r);
        pling(1.1F + r * 0.1F);
        return true;
    }

    @Override
    public void tick() {
        double target = Math.max(PAD_W / 2.0, Math.min(W - PAD_W / 2.0, mx));
        px += (target - px) * 0.35;
        if (!launched) { bx = px; by = PY - 4; return; }
        int n = (int) Math.ceil(speed);
        for (int s = 0; s < n; s++) {
            bx += vx / n;
            if (bx < 3) { bx = 3; vx = Math.abs(vx); }
            if (bx > W - 3) { bx = W - 3; vx = -Math.abs(vx); }
            if (hit(bx, by)) vx = -vx;
            by += vy / n;
            if (by < 3) { by = 3; vy = Math.abs(vy); }
            if (hit(bx, by)) vy = -vy;
            if (vy > 0 && by + 3 >= PY && by - 3 <= PY + PAD_H && Math.abs(bx - px) <= PAD_W / 2.0 + 3) {
                double a = (bx - px) / (PAD_W / 2.0 + 3);
                vx = speed * Math.sin(a);
                vy = -speed * Math.cos(a);
                by = PY - 3;
                pling(1.0F);
            }
        }
        if (by > H + 4) {
            lives--;
            beep();
            if (lives <= 0) over = true; else resetBall();
        }
        if (bricksLeft == 0) {
            level++;
            speed = Math.min(3.6, speed + 0.25);
            fillBricks();
            resetBall();
        }
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFFFFF0D8, 0xFFF5C890);
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (!bricks[r][c]) continue;
                int x = c * 22 + 1, y = r * 10 + 14;
                rect(g, x, y, BW, BH, ROW_COLORS[r]);
                rect(g, x, y, BW, 1, 0x66FFFFFF);
                rect(g, x + 4, y + 3, 2, 2, 0xFF5A3A28); // chips
                rect(g, x + 12, y + 2, 2, 2, 0xFF5A3A28);
            }
        }
        rect(g, (int) px - PAD_W / 2, PY, PAD_W, PAD_H, 0xFFE58AAE);
        rect(g, (int) px - PAD_W / 2, PY, PAD_W, 1, 0xFFFFB3CE);
        disc(g, (int) bx, (int) by, 3, 0xFF3A2A3A);
        disc(g, (int) bx, (int) by, 2, 0xFFFFFFFF);
        if (!launched) ctext(g, "click / space", W / 2, H - 34, 0xFF7A4A2A);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public String hintKey() { return "cutemod.hint.breakout"; }
}
