package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Yellow computer: click the bee when it pops out of a flower. 3 misses = game over. */
public class WhackBee extends MiniGame {
    private static final int CW = 64, CH = 40, GX = 8, GY = 6, OX = 6, OY = 4;

    private int active, life, wait, lastCell, misses, t;

    @Override
    public void reset() {
        score = 0; over = false; active = -1; wait = 40; lastCell = -1; misses = 0; t = 0;
    }

    private static int cellX(int i) { return OX + (i % 3) * (CW + GX); }
    private static int cellY(int i) { return OY + (i / 3) * (CH + GY); }

    @Override
    public boolean click(int x, int y, int button) {
        if (active >= 0 && in(x, y, cellX(active), cellY(active), CW, CH)) {
            score++;
            pling(1.0F + Math.min(score, 25) * 0.03F);
            active = -1;
            wait = 12;
        }
        return true;
    }

    @Override
    public void tick() {
        t++;
        if (active >= 0) {
            if (--life <= 0) {
                active = -1; wait = 20; misses++; beep();
                if (misses >= 3) over = true;
            }
        } else if (--wait <= 0) {
            int c;
            do { c = rnd.nextInt(9); } while (c == lastCell);
            active = c; lastCell = c;
            life = Math.max(26, 80 - score * 2);
        }
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF8ED36A, 0xFF5FB04F);
        for (int i = 0; i < 9; i++) {
            int x = cellX(i), y = cellY(i);
            rect(g, x, y, CW, CH, 0xFF6BC25A);
            rect(g, x + 10, y + CH - 14, CW - 20, 10, 0xFF5A3A1C);
            rect(g, x + 12, y + CH - 16, CW - 24, 3, 0xFF7A5230);
            if (i == active) {
                int pop = Math.min(14, (80 - life) / 2 + 4);
                int bx = x + CW / 2, by = y + CH - 14 - pop;
                // wings
                rect(g, bx - 14, by - 6, 9, 6, 0xDDEAF8FF);
                rect(g, bx + 5, by - 6, 9, 6, 0xDDEAF8FF);
                // body
                rect(g, bx - 10, by, 20, 14, 0xFFFFCF2E);
                rect(g, bx - 10, by + 3, 20, 2, 0xFF3A2A1A);
                rect(g, bx - 10, by + 8, 20, 2, 0xFF3A2A1A);
                rect(g, bx - 6, by + 5, 3, 3, 0xFF2A1D10);
                rect(g, bx + 3, by + 5, 3, 3, 0xFF2A1D10);
                rect(g, bx - 1, by - 5, 1, 5, 0xFF3A2A1A);
            }
            rect(g, x + 10, y + CH - 8, CW - 20, 4, 0xFF4A2E14); // front rim hides the bee's lower part
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, 3 - misses); }

    @Override
    public String hintKey() { return "cutemod.hint.bee"; }
}
