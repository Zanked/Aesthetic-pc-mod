package dev.cutemod.client.os;

import dev.cutemod.data.PetWear;

/**
 * The season pass: every 28 days a new season starts. Playing (games, feeding and petting the pet, daily tasks,
 * achievements, the daily login) gives pass XP; every 80 XP is a level, 30 levels in all. Each level has a free
 * reward and a premium reward (premium costs coins once per season). Rewards are claimed by hand in the app.
 * <p>
 * Nothing is stored here: the state lives in {@link Progress} counters (c.season_*), so it is saved and synced to
 * the server together with the rest of the player's progress.
 */
public final class Season {
    private Season() {}

    public static final int LEVELS = 30, XP_PER_LEVEL = 80, LENGTH_DAYS = 28, DAILY_XP_CAP = 140, PREMIUM_PRICE = 120;
    public static final int NAMES = 4;

    /** kind: 0 coins, 1 treat (id = treat id), 2 outfit (id = item id). */
    public record Reward(int kind, String id, int n) {}

    /** Outfits that the premium track hands out; a season takes 5 of them in turn. */
    private static final String[] WEAR = {"acc_catears", "acc_hoodie", "acc_wings", "acc_tux", "acc_kimono", "acc_bunny",
            "acc_tutu", "acc_pirate", "acc_coat", "acc_chef", "acc_beret", "acc_sweater", "acc_pajamas", "acc_hawaiian", "acc_apron"};

    private static final java.util.List<Integer> TREAT_LEVELS = java.util.List.of(3, 5, 7, 13, 17, 23, 27);
    private static final String[] TREATS = {"treat_cookie", "treat_honey", "treat_fish", "treat_milk"};

    /** The item that comes to the inventory in the game with this reward (see SeasonGifts), or null. */
    public static dev.cutemod.data.SeasonGifts.Gift gift(int level, boolean prem) { return dev.cutemod.data.SeasonGifts.gift(level, prem); }

    public static String giftName(dev.cutemod.data.SeasonGifts.Gift g) {
        String name = g.unique() ? tr("cutemod.season.mc." + g.item()) : tr("item.minecraft." + g.item());
        return g.count() > 1 ? name + " x" + g.count() : name;
    }

    // ---------- the calendar ----------
    private static long today() { return System.currentTimeMillis() / 86_400_000L; }

    /** The number of the running season. */
    public static int id() { return (int) (today() / LENGTH_DAYS); }

    /** The look of this season's name (cutemod.season.name.N). */
    public static int nameIndex() { return id() % NAMES; }

    public static int daysLeft() { return LENGTH_DAYS - (int) (today() % LENGTH_DAYS); }

    /** A new season wipes the old pass (xp, claimed rewards, premium). */
    private static void sync() {
        if (Progress.count("season_id") == id() + 1) return;
        Progress.setCount("season_id", id() + 1);
        for (String k : new String[]{"season_xp", "season_free", "season_prem_c", "season_prem", "season_today", "season_day"})
            Progress.setCount(k, 0);
    }

    // ---------- xp and levels ----------
    public static int xp() { sync(); return Progress.count("season_xp"); }

    public static int level() { return Math.min(LEVELS, xp() / XP_PER_LEVEL); }

    /** XP inside the current level (0..XP_PER_LEVEL - 1); a full bar at the last level. */
    public static int xpInLevel() { return level() >= LEVELS ? XP_PER_LEVEL : xp() % XP_PER_LEVEL; }

    public static boolean premium() { sync(); return Progress.count("season_prem") > 0; }

    /** Pass XP left that can still be earned today. */
    public static int roomToday() {
        sync();
        int day = (int) today();
        if (Progress.count("season_day") != day) { Progress.setCount("season_day", day); Progress.setCount("season_today", 0); }
        return Math.max(0, DAILY_XP_CAP - Progress.count("season_today"));
    }

    public static void add(int n) {
        sync();
        if (n <= 0) return;
        n = Math.min(n, roomToday());
        if (n <= 0) return;
        int before = level();
        int max = LEVELS * XP_PER_LEVEL;
        int now = Math.min(max, Progress.count("season_xp") + n);
        Progress.setCount("season_today", Progress.count("season_today") + n);
        Progress.setCount("season_xp", now);
        int after = level();
        if (after > before) Progress.toast("cutemod.toast.season_level", after);
    }

    /** What a counter that goes up (see {@link Progress#bump}) is worth in pass XP. */
    public static void onBump(String key) {
        switch (key) {
            case "games" -> add(15);
            case "feed" -> add(4);
            case "pet" -> add(2);
            default -> { }
        }
    }

    // ---------- rewards ----------
    public static Reward reward(int level, boolean prem) {
        if (prem) {
            if (level % 5 == 0 && level >= 10) return new Reward(2, WEAR[(id() * 5 + level / 5 - 2) % WEAR.length], 1);
            int t = TREAT_LEVELS.indexOf(level);
            if (t >= 0) return new Reward(1, TREATS[t % TREATS.length], 3);
            return new Reward(0, "", 12);
        }
        return switch (level) {
            case 5 -> new Reward(1, "treat_cookie", 3);
            case 10 -> new Reward(1, "treat_fish", 3);
            case 15 -> new Reward(0, "", 15);
            case 20 -> new Reward(1, "treat_milk", 3);
            case 25 -> new Reward(0, "", 20);
            case 30 -> new Reward(0, "", 30);
            default -> new Reward(0, "", 4);
        };
    }

    public static String rewardName(Reward r) {
        return switch (r.kind()) {
            case 0 -> tr("cutemod.season.r.coins", r.n());
            case 1 -> tr("cutemod.season.r.treat", tr("cutemod.shop.item." + r.id()), r.n());
            default -> tr("cutemod.shop.item." + r.id());
        };
    }

    private static String tr(String key, Object... args) {
        return net.minecraft.network.chat.Component.translatable(key, args).getString();
    }

    private static String maskKey(boolean prem) { return prem ? "season_prem_c" : "season_free"; }

    public static boolean claimed(int level, boolean prem) {
        sync();
        return (Progress.count(maskKey(prem)) & (1 << (level - 1))) != 0;
    }

    public static boolean canClaim(int level, boolean prem) {
        return level >= 1 && level <= level() && !claimed(level, prem) && (!prem || premium());
    }

    public static boolean claim(int level, boolean prem) {
        if (!canClaim(level, prem)) return false;
        Progress.setCount(maskKey(prem), Progress.count(maskKey(prem)) | (1 << (level - 1)));
        Reward r = reward(level, prem);
        if (gift(level, prem) != null)                                           // the same reward in the real game
            net.neoforged.neoforge.network.PacketDistributor.sendToServer(new dev.cutemod.net.SeasonClaimPayload(id(), level, prem));
        switch (r.kind()) {
            case 0 -> Progress.earn(r.n());
            case 1 -> Progress.giveTreat(r.id(), r.n());
            default -> {
                if (PetWear.get(r.id()) == null || Progress.owned(r.id())) Progress.earn(25);   // already have it: coins instead
                else Progress.grantWear(r.id());
            }
        }
        Progress.save();
        return true;
    }

    /** Claims everything that can be claimed. Returns how many rewards were taken. */
    public static int claimAll() {
        int n = 0;
        for (int l = 1; l <= level(); l++) {
            if (claim(l, false)) n++;
            if (claim(l, true)) n++;
        }
        return n;
    }

    public static int waiting() {
        int n = 0;
        for (int l = 1; l <= level(); l++) {
            if (canClaim(l, false)) n++;
            if (canClaim(l, true)) n++;
        }
        return n;
    }

    public static boolean buyPremium() {
        if (premium() || !Progress.spend(PREMIUM_PRICE)) return false;
        Progress.setCount("season_prem", 1);
        Progress.toast("cutemod.toast.season_premium");
        Progress.save();
        return true;
    }
}
