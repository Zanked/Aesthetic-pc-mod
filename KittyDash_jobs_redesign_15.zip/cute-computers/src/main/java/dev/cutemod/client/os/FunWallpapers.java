package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Six more animated wallpapers (numbers 35-40): an aquarium, outer space, a rainy neon city, a sunset beach, a retro
 * arcade and a cloud kingdom. Same method as AnimeWallpapers: a design space of 160 x 100 units scaled by the box
 * height, scenery that fills the whole width, everything clipped to the box by hand.
 */
final class FunWallpapers {
    private static GuiGraphics gg;
    private static int bx, by, bw, bh;
    private static float s;
    private static int ox;
    private static int t;
    private static float lo, hi, vw;

    private FunWallpapers() {}

    static void draw(GuiGraphics g, int x, int y, int w, int h, int idx) {
        gg = g; bx = x; by = y; bw = Math.max(1, w); bh = Math.max(1, h);
        s = bh / 100F;
        ox = bx + Math.round((bw - 160 * s) / 2F);
        vw = bw / s; lo = (bx - ox) / s; hi = lo + vw;
        t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        switch (idx) {
            case 35 -> aquarium();
            case 36 -> space();
            case 37 -> rainyCity();
            case 38 -> sunsetBeach();
            case 39 -> arcade();
            default -> cloudKingdom();
        }
        gg = null;
    }

    // ---------- drawing helpers (design units) ----------
    private static int X(float v) { return ox + Math.round(v * s); }

    private static int Y(float v) { return by + Math.round(v * s); }

    /** A filled box in screen pixels, cut to the wallpaper box. */
    private static void px(int x0, int y0, int x1, int y1, int argb) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fill(x0, y0, x1, y1, argb);
    }

    /** A filled box in design units (at least one pixel). */
    private static void R(float x0, float y0, float x1, float y1, int argb) {
        int a = X(x0), b = Y(y0), c = Math.max(X(x1), a + 1), d = Math.max(Y(y1), b + 1);
        px(a, b, c, d, argb);
    }

    private static void D(float cx, float cy, float rad, int argb) {
        int r = Math.max(1, Math.round(rad * s)), pcx = X(cx), pcy = Y(cy);
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            px(pcx - dx, pcy + dy, pcx + dx + 1, pcy + dy + 1, argb);
        }
    }

    /** A triangle with its tip up, base width w, height h (design units). */
    private static void T(float cx, float top, float w, float h, int argb) {
        int rows = Math.max(1, Math.round(h * s)), pcx = X(cx), pw = Math.max(1, Math.round(w * s)), y0 = Y(top);
        for (int row = 0; row < rows; row++) {
            int ww = Math.max(1, pw * (row + 1) / rows);
            px(pcx - ww / 2, y0 + row, pcx - ww / 2 + ww, y0 + row + 1, argb);
        }
    }

    private static void sky(int top, int bottom) { gg.fillGradient(bx, by, bx + bw, by + bh, top, bottom); }

    private static int mix(int a, int b, float f) {
        f = Math.max(0F, Math.min(1F, f));
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
        return 0xFF000000 | (int) (ar + (br - ar) * f) << 16 | (int) (ag + (bg - ag) * f) << 8 | (int) (ab + (bb - ab) * f);
    }

    private static int alpha(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }

    private static float wave(float speed, float phase) { return (float) Math.sin(t * speed + phase); }

    private static void stars(int count, int seed) {
        for (int i = 0; i < count; i++) {
            float sx = lo + (i * 53 + seed * 17) % vw, sy = (i * 29 + seed * 7) % 70;
            boolean on = (t / 6 + i * 3) % 9 != 0;
            R(sx, sy, sx + 1.2F, sy + 1.2F, on ? 0xFFFFF6C8 : 0x66FFF6C8);
        }
    }

    // ---------- 35: the aquarium ----------
    private static void fish(float x, float y, float size, int col, boolean right) {
        int dark = mix(col, 0xFF000000, 0.2F);
        float d = right ? 1 : -1, flap = wave(0.4F, x) * 1.2F;
        for (int i = 0; i < 5; i++) R(x - d * size * 0.9F + (d < 0 ? -size * 0.5F : 0) + i * d * size * 0.2F, y - size * 0.45F, x - d * size * 0.9F + (d < 0 ? -size * 0.5F : 0) + (i + 1) * d * size * 0.2F, y + size * 0.45F, i < 3 ? col : dark);
        D(x, y, size * 0.55F, col);
        T(x - d * size * 0.75F, y - size * 0.55F + flap, size * 0.7F, size * 0.5F, dark);
        R(x + d * size * 0.25F - 0.5F, y - size * 0.2F - 0.5F, x + d * size * 0.25F + 0.5F, y - size * 0.2F + 0.5F, 0xFF1E1A30);
    }

    private static void aquarium() {
        sky(0xFF1E8AD8, 0xFF0A3A7A);
        for (int i = 0; i < 5; i++) {                                                   // light beams from the surface
            float k = 0.5F + 0.5F * wave(0.03F, i * 2F);
            for (int row = 0; row < 80; row += 2) R(lo + 10 + i * vw / 5F + row * 0.3F, row, lo + 22 + i * vw / 5F + row * 0.5F, row + 2, alpha(0xFFFFFF, (int) (8 + 10 * k)));
        }
        R(lo, 90, hi, 100, 0xFFE8D090); R(lo, 90, hi, 92, 0xFFF4E4A8);                    // the sand
        for (int i = 0; i < 9; i++) {                                                   // seaweed that sways
            float x = lo + 8 + i * (vw - 16) / 8F;
            for (int k = 0; k < 18; k++) R(x + wave(0.07F, i + k / 4F) * (k * 0.25F), 90 - k * 1.7F, x + 2 + wave(0.07F, i + k / 4F) * (k * 0.25F), 92 - k * 1.7F, i % 2 == 0 ? 0xFF3AB86A : 0xFF2A9A5A);
        }
        float rx = lo + vw * 0.15F;                                                      // a coral and a shell
        D(rx, 88, 5, 0xFFFF7A9A); D(rx + 5, 86, 4, 0xFFFF9AB8); D(rx - 5, 87, 3.5F, 0xFFFFB0C8);
        int[] cols = {0xFFFFA24A, 0xFFFFD84A, 0xFFFF6A8A, 0xFF8AE0FF, 0xFFB57BD6};
        for (int i = 0; i < 7; i++) {                                                   // fish that swim in loops
            boolean right = i % 2 == 0;
            float sp = 0.25F + (i % 3) * 0.12F, span = vw + 40;
            float x = right ? lo - 20 + (t * sp + i * 55) % span : hi + 20 - (t * sp + i * 55) % span;
            fish(x, 18 + (i * 11) % 54 + wave(0.05F, i) * 3F, 4 + (i % 3) * 1.6F, cols[i % cols.length], right);
        }
        float jx = lo + vw * 0.7F, jy = 30 + wave(0.04F, 0) * 8F;                         // a jellyfish pulses
        float pulse = 1F + 0.12F * wave(0.12F, 0);
        D(jx, jy, 7 * pulse, alpha(0xFFB0F0, 190)); R(jx - 7 * pulse, jy, jx + 7 * pulse, jy + 2, alpha(0xFFB0F0, 190));
        for (int i = -2; i <= 2; i++) for (int k = 0; k < 9; k++) R(jx + i * 2.6F + wave(0.1F, k / 2F + i) * 1.4F, jy + 2 + k, jx + i * 2.6F + 1 + wave(0.1F, k / 2F + i) * 1.4F, jy + 3 + k, alpha(0xFFC8F0, 140));
        for (int i = 0; i < 16; i++) {                                                   // bubbles rise
            float k = (t * (0.35F + (i % 4) * 0.1F) + i * 31) % 110;
            float x = lo + (i * 37) % vw + wave(0.06F, i) * 3F;
            D(x, 95 - k, 0.9F + (i % 3) * 0.5F, 0x66FFFFFF);
        }
    }

    // ---------- 36: outer space ----------
    private static void space() {
        sky(0xFF05061A, 0xFF1A0E3A);
        for (int i = 0; i < 60; i++) {
            float x = lo + (i * 53) % vw, y = (i * 29) % 100;
            boolean on = (t / 5 + i * 3) % 11 != 0;
            R(x, y, x + (i % 7 == 0 ? 1.8F : 1F), y + (i % 7 == 0 ? 1.8F : 1F), on ? 0xFFFFFFFF : 0x66FFFFFF);
        }
        D(lo + vw * 0.8F, 30, 26, alpha(0x6A4AD0, 40)); D(lo + vw * 0.8F, 30, 22, 0xFF6A4AD0);          // a big ringed planet
        D(lo + vw * 0.8F - 6, 24, 12, 0xFF8A6AE8);
        for (int i = -34; i <= 34; i++) R(lo + vw * 0.8F + i, 30 + i * 0.22F + (i * i) * 0.002F - 1, lo + vw * 0.8F + i + 1, 30 + i * 0.22F + (i * i) * 0.002F + 0.6F, 0xAAFFD8A0);
        D(lo + 22, 70, 9, 0xFFE8704A); D(lo + 19, 67, 4, 0xFFF0A070);                                    // a small red planet
        float k = (t * 0.7F) % 220;                                                                       // a comet
        for (int i = 0; i < 14; i++) R(lo + k - 40 - i * 2.4F, 8 + (k - 40) * 0.24F + i * 0.5F, lo + k - 38 - i * 2.4F, 9.5F + (k - 40) * 0.24F + i * 0.5F, alpha(0xA0E8FF, 200 - i * 14));
        D(lo + k - 40, 8 + (k - 40) * 0.24F, 2F, 0xFFFFFFFF);
        // a cute rocket that flies in a slow loop
        float rx = lo + vw * 0.42F + wave(0.02F, 0) * vw * 0.22F, ry = 58 + wave(0.035F, 1) * 12F;
        for (int i = 0; i < 7; i++) T(rx, ry + 14 + i * 2, 5 - i * 0.5F, 6, alpha(i % 2 == 0 ? 0xFFA030 : 0xFF5A20, 220 - i * 28));
        R(rx - 3, ry - 8, rx + 3, ry + 14, 0xFFF0F0FF); T(rx, ry - 17, 6, 9, 0xFFE5486F);
        D(rx, ry - 1, 2.4F, 0xFF6AD0FF); R(rx - 6, ry + 8, rx - 3, ry + 15, 0xFFE5486F); R(rx + 3, ry + 8, rx + 6, ry + 15, 0xFFE5486F);
    }

    // ---------- 37: the rainy neon city ----------
    private static void rainyCity() {
        sky(0xFF1A1030, 0xFF3A1A4A);
        for (int layer = 0; layer < 2; layer++) {                                       // two rows of buildings
            int col = layer == 0 ? 0xFF1E1438 : 0xFF120A24;
            int n = (int) (vw / (layer == 0 ? 14 : 18)) + 1;
            for (int i = 0; i < n; i++) {
                float x = lo + i * vw / n, w = vw / n + 0.5F, h = (layer == 0 ? 34 : 50) + (i * 13 + layer * 7) % (layer == 0 ? 22 : 26);
                R(x, 88 - h, x + w, 100, col);
                for (int wy = 0; wy < h - 6; wy += 6) for (int wx = 0; wx < w - 3; wx += 5)
                    if ((i * 7 + wy / 6 * 3 + wx / 5 + (t / 70)) % (layer == 0 ? 4 : 3) == 0) R(x + 2 + wx, 90 - h + wy, x + 4 + wx, 92 - h + wy, layer == 0 ? 0xFFFFD880 : 0xFFE88AB8);
            }
        }
        // neon signs that flicker
        float sx = lo + vw * 0.25F;
        boolean on = (t / 4) % 17 != 0;
        R(sx, 40, sx + 24, 50, 0xFF14102A); R(sx + 1, 41, sx + 23, 49, on ? 0xFFFF4AB8 : 0xFF6A2A5A);
        for (int i = 0; i < 4; i++) R(sx + 4 + i * 5, 44, sx + 6 + i * 5, 47, 0xFFFFFFFF);
        float sy = lo + vw * 0.65F;
        R(sy, 30, sy + 8, 54, 0xFF14102A); R(sy + 1, 31, sy + 7, 53, (t / 9) % 2 == 0 ? 0xFF4AE0FF : 0xFF2A8AA8);
        R(lo, 90, hi, 100, 0xFF0C0818);                                                 // the wet street with neon reflections
        for (int i = 0; i < 6; i++) R(sx + wave(0.05F, i) * 2F, 92 + i * 1.4F, sx + 24 + wave(0.05F, i) * 2F, 93 + i * 1.4F, alpha(0xFF4AB8, 60 - i * 8));
        for (int i = 0; i < 5; i++) { float k = (t * 0.7F + i * 29) % 40; R(lo + (i * 47) % vw + k * 0, 94 + i, lo + (i * 47) % vw + 8, 94.8F + i, alpha(0xFFFFFF, 30)); }
        // rain
        for (int i = 0; i < 70; i++) {
            float fall = (t * (2.2F + (i % 4) * 0.4F) + i * 17) % 110;
            float x = lo + (i * 37) % vw - fall * 0.12F, y = fall - 8;
            R(x, y, x + 0.6F, y + 4, 0x66C8D8FF);
        }
        for (int i = 0; i < 6; i++) {                                                   // ripples on the street
            float k = (t * 0.5F + i * 20) % 30;
            float x = lo + (i * 61) % vw;
            R(x - k / 3, 96 + (i % 3) * 1.2F, x + k / 3, 96.6F + (i % 3) * 1.2F, alpha(0xFFFFFF, (int) Math.max(0, 80 - k * 3)));
        }
    }

    // ---------- 38: the sunset beach ----------
    private static void sunsetBeach() {
        for (int i = 0; i < 8; i++) R(lo, i * 7, hi, i * 7 + 7, new int[]{0xFF5A3A8A, 0xFF8A4A9A, 0xFFC8508A, 0xFFF0705A, 0xFFF8985A, 0xFFFFB86A, 0xFFFFD890, 0xFFFFE8B0}[i]);
        float sun = 56 + wave(0.01F, 0) * 1.5F;
        D(lo + vw * 0.5F, sun, 17, alpha(0xFFE8A0, 60)); D(lo + vw * 0.5F, sun, 13, 0xFFFFF0B8);
        R(lo, 56, hi, 100, 0xFF2A5A9A);                                                  // the sea
        for (int i = 0; i < 14; i++) {                                                  // glitter on the water and waves
            float x = lo + vw * 0.5F + wave(0.06F, i) * (6 + i * 1.2F), y = 58 + i * 2.2F;
            R(x - 6 + i * 0.4F, y, x + 6 - i * 0.4F, y + 0.9F, alpha(0xFFE8A0, 150 - i * 8));
        }
        for (int i = 0; i < 6; i++) R(lo + (i * 41 + t * 0.15F * (1 + i % 3)) % vw, 62 + i * 4, lo + (i * 41 + t * 0.15F * (1 + i % 3)) % vw + 10, 62.8F + i * 4, 0x66FFFFFF);
        R(lo, 84, hi, 100, 0xFFF0D8A0);                                                  // the sand with a foam line
        float foam = wave(0.05F, 0) * 2F;
        R(lo, 82 + foam, hi, 84 + foam, 0xAAFFFFFF);
        float px = hi - 28;                                                              // a palm tree
        for (int i = 0; i < 26; i++) R(px + i * 0.08F - 1 + wave(0.03F, i / 8F) * 0.3F, 86 - i, px + i * 0.08F + 1.4F, 87 - i, i % 4 < 2 ? 0xFF7A4A2A : 0xFF8A5A3A);
        for (int leaf = 0; leaf < 6; leaf++) {
            float dir = (leaf - 2.5F) * 0.5F, sw = wave(0.06F, leaf) * 1.5F;
            for (int k = 0; k < 14; k++) R(px + 2 + dir * k * 1.2F + sw * k / 14, 60 + k * (0.55F + Math.abs(dir) * 0.3F) - 2, px + 4 + dir * k * 1.2F + sw * k / 14, 61 + k * (0.55F + Math.abs(dir) * 0.3F) - 1, 0xFF2A9A4A);
        }
        for (int i = 0; i < 2; i++) {                                                   // gulls
            float x = lo + (t * (0.4F + i * 0.2F) + i * 70) % (vw + 30) - 15, y = 22 + i * 9 + wave(0.05F, i) * 2F;
            boolean up = (t / 6 + i) % 2 == 0;
            R(x, y + (up ? 0 : 1), x + 3, y + (up ? 1 : 2), 0xFFFFFFFF); R(x + 3, y + (up ? 1 : 0), x + 6, y + (up ? 2 : 1), 0xFFFFFFFF);
        }
    }

    // ---------- 39: the retro arcade ----------
    private static void arcade() {
        sky(0xFF14082E, 0xFF3A0E5A);
        for (int i = 0; i < 40; i++) R(lo + (i * 53) % vw, (i * 29) % 60, lo + (i * 53) % vw + 1, (i * 29) % 60 + 1, (t / 6 + i) % 5 == 0 ? 0xFFFFFFFF : 0x66FFFFFF);
        float horizon = 60;
        R(lo, horizon, hi, 100, 0xFF1A0838);
        for (int i = -12; i <= 12; i++) {                                               // the perspective grid
            float cx = lo + vw / 2, x1 = cx + i * 4, x2 = cx + i * 24;
            for (int k = 0; k < 40; k++) { float f = k / 40F; float x = x1 + (x2 - x1) * f; R(x, horizon + f * 40, x + 0.8F, horizon + f * 40 + 1.2F, 0x88FF4AD8); }
        }
        for (int i = 0; i < 10; i++) { float f = ((i + (t * 0.03F) % 1F) / 10F); float y = horizon + f * f * 40; R(lo, y, hi, y + 0.9F, alpha(0xFF4AD8, (int) (60 + 120 * f))); }
        D(lo + vw / 2, horizon - 6, 18, 0xFFFFA24A);                                    // a striped sun
        for (int i = 0; i < 6; i++) R(lo + vw / 2 - 18, horizon - 6 + i * 3, lo + vw / 2 + 18, horizon - 6 + i * 3 + 0.8F + i * 0.3F, 0xFF3A0E5A);
        R(lo, horizon, hi, horizon + 1, 0xFF4AE8FF);
        // pixel invaders march
        float march = ((t / 20) % 2) * 3 + wave(0.01F, 0) * 6;
        for (int row = 0; row < 3; row++) for (int col = 0; col < 7; col++) {
            float x = lo + vw * 0.12F + col * 14 + march + (row % 2) * 4, y = 8 + row * 10;
            int c = row == 0 ? 0xFF4AE8FF : row == 1 ? 0xFFFF4AB8 : 0xFF8AFF6A;
            boolean legs = (t / 10) % 2 == 0;
            R(x + 1, y, x + 7, y + 4, c); R(x, y + 1, x + 8, y + 3, c);
            R(x + 2, y + 1, x + 3, y + 2, 0xFF14082E); R(x + 5, y + 1, x + 6, y + 2, 0xFF14082E);
            R(legs ? x : x + 1, y + 4, legs ? x + 2 : x + 3, y + 5.5F, c); R(legs ? x + 6 : x + 5, y + 4, legs ? x + 8 : x + 7, y + 5.5F, c);
        }
        float shipX = lo + vw / 2 + wave(0.03F, 0) * vw * 0.3F;                          // a ship that shoots now and then
        R(shipX - 4, 54, shipX + 4, 57, 0xFFFFFFFF); R(shipX - 1, 51, shipX + 1, 54, 0xFFFFFFFF);
        int shot = t % 40;
        if (shot < 30) R(shipX - 0.5F, 50 - shot * 1.4F, shipX + 0.5F, 53 - shot * 1.4F, 0xFFFFE066);
    }

    // ---------- 40: the cloud kingdom ----------
    private static void cloud(float x, float y, float size, int col) {
        D(x, y, size, col); D(x - size * 0.9F, y + size * 0.3F, size * 0.7F, col); D(x + size * 0.9F, y + size * 0.3F, size * 0.7F, col);
        R(x - size * 1.5F, y + size * 0.3F, x + size * 1.6F, y + size, col);
    }

    private static void cloudKingdom() {
        sky(0xFF7AC8FF, 0xFFE8F6FF);
        for (int i = 0; i < 7; i++) R(lo, 14 + i * 3, hi, 15 + i * 3, 0x00000000);
        for (int i = 0; i < 6; i++) {                                                   // a rainbow arc
            int[] rc = {0xFFFF6A6A, 0xFFFFA24A, 0xFFFFE066, 0xFF8AE08A, 0xFF6AB8FF, 0xFFB57BD6};
            float rad = 44 - i * 2.2F;
            for (int a = 0; a <= 180; a += 3) { double ang = Math.toRadians(a); R(lo + vw * 0.35F - (float) Math.cos(ang) * rad, 74 - (float) Math.sin(ang) * rad, lo + vw * 0.35F - (float) Math.cos(ang) * rad + 2.4F, 76 - (float) Math.sin(ang) * rad, alpha(rc[i], 150)); }
        }
        for (int i = 0; i < 6; i++) {                                                   // clouds drifting by
            float x = lo + (t * (0.1F + (i % 3) * 0.06F) + i * 53) % (vw + 60) - 30;
            cloud(x, 14 + (i * 17) % 48, 5 + (i % 3) * 2, i % 2 == 0 ? 0xFFFFFFFF : 0xE8F4FF);
        }
        // floating islands that bob
        for (int i = 0; i < 3; i++) {
            float x = lo + vw * (0.2F + i * 0.3F), y = 52 + i * 6 + wave(0.04F, i * 2F) * 3F, w = 18 - i * 2;
            for (int k = 0; k < 10; k++) R(x - w + k * 0.9F, y + 4 + k, x + w - k * 0.9F, y + 5 + k, k % 3 == 0 ? 0xFF8A6A4A : 0xFF9A7A5A);
            R(x - w - 1, y, x + w + 1, y + 5, 0xFF5BD06A); R(x - w - 1, y, x + w + 1, y + 1.5F, 0xFF8AE88A);
            if (i != 1) { R(x - 1, y - 8, x + 1, y, 0xFF7A4A2A); D(x, y - 11, 6, 0xFF3AB86A); D(x - 2, y - 13, 3, 0xFF5BD06A); }
            else { R(x - 5, y - 8, x + 5, y, 0xFFFFF0F0); T(x, y - 17, 14, 9, 0xFFE5486F); R(x - 1.5F, y - 5, x + 1.5F, y, 0xFF7A4A2A); }
        }
        // hot-air balloons
        for (int i = 0; i < 2; i++) {
            float x = lo + (t * (0.12F + i * 0.05F) + i * 90) % (vw + 40) - 20, y = 22 + i * 14 + wave(0.05F, i) * 3F;
            D(x, y, 7, i == 0 ? 0xFFFF6A9A : 0xFFFFC040); R(x - 7, y, x + 7, y + 2, i == 0 ? 0xFFFF6A9A : 0xFFFFC040);
            for (int k = 0; k < 5; k++) R(x - 4 + k * 2, y + 2 + k * 0.5F, x - 3 + k * 2, y + 8, 0x00000000);
            R(x - 1.5F, y - 7, x + 1.5F, y + 7, 0x33FFFFFF); R(x - 3, y + 9, x + 3, y + 12, 0xFF8A5A32); R(x - 3, y + 7, x - 2.4F, y + 9, 0xFF3A2A1A); R(x + 2.4F, y + 7, x + 3, y + 9, 0xFF3A2A1A);
        }
        for (int i = 0; i < 12; i++) {                                                  // sparkles
            float x = lo + (i * 47) % vw, y = (i * 31) % 80;
            if ((t / 6 + i) % 4 < 2) { R(x - 1.5F, y, x + 1.5F, y + 0.8F, 0xFFFFFFFF); R(x - 0.4F, y - 1.4F, x + 0.4F, y + 2.2F, 0xFFFFFFFF); }
        }
    }
}
