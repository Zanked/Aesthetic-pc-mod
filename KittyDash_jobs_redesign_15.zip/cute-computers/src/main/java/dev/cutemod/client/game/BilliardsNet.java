package dev.cutemod.client.game;

import dev.cutemod.net.BilliardsActionPayload;
import dev.cutemod.net.BilliardsSyncPayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** The client side of online billiards: what the server last told us, and the messages we send to it. */
public final class BilliardsNet {
    private BilliardsNet() {}

    /** A shot to replay: the table before it, the speed of the white ball, and how the game stands after it. */
    public record Shot(int seq, float[] preXy, int preMask, float vx, float vy, float[] postXy, int postMask,
                       int turn, int score0, int score1, int result) {}

    /** Free players, the invitations, and the game we are in (opponent is empty if there is none). */
    public static List<String> players = new ArrayList<>();
    public static String invitedBy = "", invitedTo = "", opponent = "";
    public static boolean youFirst = true;
    public static int turn, score0, score1, result, seq;
    public static float[] xy = new float[22];
    public static int mask;
    /** Shots that arrived and have not been shown yet, oldest first. */
    public static final ArrayDeque<Shot> shots = new ArrayDeque<>();
    /** Goes up with every message from the server. */
    public static int version;
    private static int notice, lastShotSeq;
    private static long ignoreUntil;       // right after we left a game, an old message must not bring it back

    public static void apply(BilliardsSyncPayload p) {
        players = new ArrayList<>(p.players());
        invitedBy = p.invitedBy();
        invitedTo = p.invitedTo();
        boolean ignore = System.currentTimeMillis() < ignoreUntil;
        String opp = ignore ? "" : p.opponent();
        if (opp.isEmpty() || !opp.equals(opponent)) { shots.clear(); lastShotSeq = p.shotSeq(); }   // another game: its shots are not ours to replay
        else if (p.shotSeq() != 0 && p.shotSeq() != lastShotSeq) {
            shots.add(new Shot(p.shotSeq(), p.preXy().clone(), p.preMask(), p.shotVx(), p.shotVy(), p.postXy().clone(), p.postMask(),
                    p.turn(), p.score0(), p.score1(), p.result()));
            lastShotSeq = p.shotSeq();
        }
        opponent = opp;
        youFirst = p.youFirst();
        turn = p.turn();
        score0 = p.score0();
        score1 = p.score1();
        result = p.result();
        seq = p.seq();
        xy = p.postXy().clone();
        mask = p.postMask();
        if (p.notice() != 0) notice = p.notice();
        version++;
    }

    public static void clear() {
        players = new ArrayList<>();
        invitedBy = invitedTo = opponent = "";
        result = 0;
        notice = 0;
        shots.clear();
        lastShotSeq = 0;
        version++;
    }

    public static boolean inMatch() { return !opponent.isEmpty(); }

    /** True if it is our turn on the server. */
    public static boolean myTurn() { return turn == (youFirst ? 0 : 1); }

    public static int myScore() { return youFirst ? score0 : score1; }

    public static int oppScore() { return youFirst ? score1 : score0; }

    /** The last notice (declined, busy, ...), only once. */
    public static int takeNotice() {
        int n = notice;
        notice = 0;
        return n;
    }

    private static void send(int action, String name, float dx, float dy, float power) {
        PacketDistributor.sendToServer(new BilliardsActionPayload(action, name, dx, dy, power));
    }

    public static void request() { send(0, "", 0, 0, 0); }

    public static void invite(String name) { send(1, name, 0, 0, 0); }

    public static void accept(String name) { send(2, name, 0, 0, 0); }

    public static void decline(String name) { send(3, name, 0, 0, 0); }

    public static void cancelInvite() { send(6, "", 0, 0, 0); }

    public static void shoot(float dx, float dy, float power) { send(4, "", dx, dy, power); }

    /** Give up, or leave a finished game. We forget the game at once, the server confirms later. */
    public static void leaveGame() {
        send(5, "", 0, 0, 0);
        ignoreUntil = System.currentTimeMillis() + 1500;
        opponent = "";
        result = 0;
        shots.clear();
        version++;
    }
}
