package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** The drawings of the blue screen, the recovery menu, the update screen and the "what's new" window. */
final class Crash {
    private Crash() {}

    static final int BSOD_TICKS = 340, RECOVERY_TICKS = 600, UPDATE_TICKS = 520;
    static final String[] CODES = {"PANDA_ATE_THE_BAMBOO", "BEE_STUCK_IN_THE_WINDOW", "CREEPER_IN_THE_RAM",
            "COOKIE_JAR_OVERFLOW", "FOX_LOST_THE_PAIR", "SLIME_ON_THE_KEYBOARD"};

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    /** A progress that stalls here and there, like the real thing: {tick, percent} pairs. */
    private static int percent(int t, int[][] keys) {
        for (int i = 1; i < keys.length; i++) {
            if (t <= keys[i][0]) {
                int[] a = keys[i - 1], b = keys[i];
                return a[1] + (b[1] - a[1]) * (t - a[0]) / Math.max(1, b[0] - a[0]);
            }
        }
        return keys[keys.length - 1][1];
    }

    static int bsodPercent(int t) {
        return percent(t, new int[][]{{0, 0}, {40, 3}, {90, 9}, {150, 9}, {190, 41}, {250, 41}, {290, 87}, {330, 100}});
    }

    static int updatePercent(int t) {
        return percent(t, new int[][]{{0, 0}, {60, 12}, {150, 30}, {230, 30}, {300, 68}, {380, 68}, {420, 99}, {480, 99}, {520, 100}});
    }

    private static void wrapped(GuiGraphics g, Font f, String s, int x, int y, int width, int argb) {
        for (var l : f.split(Component.literal(s), width)) {
            CuteFont.draw(g, f, l, x, y, argb, false);
            y += 10;
        }
    }

    // ---------- the blue screen ----------
    static void bsod(GuiGraphics g, Font f, int x, int y, int w, int h, int t, int code) {
        g.fill(x, y, x + w, y + h, 0xFF1465BF);
        g.pose().pushPose();
        g.pose().translate(x + 14, y + 12, 0);
        g.pose().scale(4f, 4f, 1f);
        CuteFont.draw(g, f, ":(", 0, 0, 0xFFFFFFFF, false);
        g.pose().popPose();
        int tx = x + 16, ty = y + 56, tw = w - 32;
        wrapped(g, f, t("cutemod.bsod.title"), tx, ty, tw, 0xFFFFFFFF);
        wrapped(g, f, t("cutemod.bsod.collect"), tx, ty + 24, tw, 0xFFDCEBFF);
        int pct = bsodPercent(t);
        CuteFont.draw(g, f, pct + "% " + t("cutemod.bsod.complete"), tx, ty + 50, 0xFFFFFFFF, false);
        // a made-up QR code
        int qx = tx, qy = y + h - 58;
        g.fill(qx - 2, qy - 2, qx + 34, qy + 34, 0xFFFFFFFF);
        java.util.Random r = new java.util.Random(code * 31L + 5);
        for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) if (r.nextInt(100) < 50) g.fill(qx + i * 4, qy + j * 4, qx + i * 4 + 4, qy + j * 4 + 4, 0xFF1465BF);
        for (int[] c : new int[][]{{0, 0}, {28, 0}, {0, 28}}) {
            g.fill(qx + c[0], qy + c[1], qx + c[0] + 8, qy + c[1] + 8, 0xFF1465BF);
            g.fill(qx + c[0] + 2, qy + c[1] + 2, qx + c[0] + 6, qy + c[1] + 6, 0xFFFFFFFF);
        }
        wrapped(g, f, t("cutemod.bsod.more"), qx + 42, qy, tw - 44, 0xFFDCEBFF);
        wrapped(g, f, t("cutemod.bsod.code", CODES[code % CODES.length]), qx + 42, qy + 22, tw - 44, 0xFFFFFFFF);
        if (pct >= 100 && (t / 30) % 2 == 0) CuteFont.draw(g, f, t("cutemod.bsod.key"), tx, y + h - 14, 0xFFFFFFFF, false);
    }

    // ---------- the recovery menu (a black text screen, as in the old days) ----------
    static void recovery(GuiGraphics g, Font f, int x, int y, int w, int h, int t, int sel) {
        g.fill(x, y, x + w, y + h, 0xFF000000);
        g.fill(x, y + 6, x + w, y + 18, 0xFFC8C8C8);
        String title = t("cutemod.recovery.title");
        CuteFont.draw(g, f, title, x + (w - f.width(title)) / 2, y + 8, 0xFF000000, false);
        wrapped(g, f, t("cutemod.recovery.text"), x + 14, y + 32, w - 28, 0xFFC8C8C8);
        String[] items = {t("cutemod.recovery.normal"), t("cutemod.recovery.safe")};
        for (int i = 0; i < items.length; i++) {
            int iy = y + 84 + i * 14;
            if (i == sel) g.fill(x + 14, iy - 2, x + w - 14, iy + 10, 0xFFC8C8C8);
            CuteFont.draw(g, f, items[i], x + 20, iy, i == sel ? 0xFF000000 : 0xFFC8C8C8, false);
        }
        int left = Math.max(0, (RECOVERY_TICKS - t + 59) / 60);
        wrapped(g, f, t("cutemod.recovery.hint", left), x + 14, y + 128, w - 28, 0xFF8A8A8A);
    }

    // ---------- installing an update ----------
    static void updating(GuiGraphics g, Font f, int x, int y, int w, int h, int t) {
        g.fillGradient(x, y, x + w, y + h, 0xFF0D4D8C, 0xFF3C9BE0);
        int cx = x + w / 2, cy = y + h / 2 - 26;
        for (int i = 0; i < 8; i++) {                                // the spinning dots
            double a = i * Math.PI / 4 - Math.PI / 2;
            int k = Math.floorMod(t / 4 - i, 8);
            int v = 255 - k * 28;
            int dx = (int) Math.round(Math.cos(a) * 14), dy = (int) Math.round(Math.sin(a) * 14);
            g.fill(cx + dx - 2, cy + dy - 2, cx + dx + 2, cy + dy + 2, 0xFF000000 | (v << 16) | (v << 8) | 255);
        }
        String l1 = t("cutemod.updating.title"), l2 = Crash.updatePercent(t) + "% " + t("cutemod.bsod.complete"), l3 = t("cutemod.updating.dont");
        CuteFont.draw(g, f, l1, cx - f.width(l1) / 2, cy + 30, 0xFFFFFFFF, false);
        CuteFont.draw(g, f, l2, cx - f.width(l2) / 2, cy + 42, 0xFFFFFFFF, false);
        CuteFont.draw(g, f, l3, cx - f.width(l3) / 2, y + h - 18, 0xFFCFE8FF, false);
    }

    // ---------- "what's new" after an update ----------
    static void news(GuiGraphics g, Font f, int x, int y, int w, int h, int t, int body, int index) {
        Wallpaper.draw(g, x, y, w, h, body, Wallpaper.shown());
        g.fill(x, y, x + w, y + h, 0xB0140E1C);
        Updates.Update u = Updates.ALL.get(Math.max(0, Math.min(Updates.ALL.size() - 1, index)));
        int pw = 230, ph = 136, px = x + (w - pw) / 2, py = y + (h - ph) / 2;
        g.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, 0xFFB9D8F0);
        g.fillGradient(px, py, px + pw, py + 16, 0xFF8FD0FF, 0xFF4A9BE0);
        g.fill(px, py + 16, px + pw, py + ph, 0xFFF4F9FF);
        CuteFont.draw(g, f, t("cutemod.whatsnew.title", "1." + (index + 1)), px + 6, py + 4, 0xFF0E3A5E, false);
        CuteFont.draw(g, f, t("cutemod.update." + u.id() + ".name"), px + 8, py + 22, 0xFF1A66C8, false);
        for (int i = 1; i <= 3; i++) CuteFont.draw(g, f, "\u2022 " + t("cutemod.update." + u.id() + ".l" + i), px + 8, py + 32 + i * 11, 0xFF3A2A3A, false);
        CuteFont.draw(g, f, t("cutemod.whatsnew.saver", t("cutemod.saver." + u.saver())), px + 8, py + 78, 0xFF2E7D4F, false);
        CuteFont.draw(g, f, t("cutemod.whatsnew.outfit"), px + 8, py + 90, 0xFF2E7D4F, false);
        CuteFont.draw(g, f, t("cutemod.whatsnew.place", t("cutemod.trip.dest." + u.place())), px + 8, py + 101, 0xFF2E7D4F, false);
        CuteFont.draw(g, f, t("cutemod.whatsnew.park", t("cutemod.park.decor." + Math.max(0, Math.min(Updates.ALL.size() - 1, index)))), px + 8, py + 112, 0xFF2E7D4F, false);
        String go = t("cutemod.whatsnew.go");
        CuteFont.draw(g, f, go, px + (pw - f.width(go)) / 2, py + ph - 12, (t / 25) % 2 == 0 ? 0xFF1A66C8 : 0xFF7FB0E0, false);
    }
}
