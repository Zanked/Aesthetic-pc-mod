package dev.cutemod.client.os;

import dev.cutemod.data.ShowBoard;
import dev.cutemod.net.PetLook;
import dev.cutemod.net.ShowActionPayload;
import dev.cutemod.net.ShowPutPayload;
import dev.cutemod.net.ShowRequestPayload;
import dev.cutemod.net.ShowSyncPayload;
import net.neoforged.neoforge.network.PacketDistributor;

/** The talent show on the client: sends what the player does and keeps the last stage the server sent. */
public final class Show {
    private Show() {}

    private static ShowSyncPayload last;

    public static void apply(ShowSyncPayload p) {
        last = p;
        // ten gold cups: the champion's laurels are yours for good (they cannot be bought)
        if (p.fame().gold() >= ShowBoard.OUTFIT_GOLD && Progress.grant("acc_champion")) Progress.toast("cutemod.toast.champion");
        // the knight's helmet and armor: gold cups on the way to the laurels
        for (dev.cutemod.data.PetWear.Item w : dev.cutemod.data.PetWear.ALL) {
            if (w.src() == dev.cutemod.data.PetWear.Src.SHOW && !w.id().equals("acc_champion") && p.fame().gold() >= w.at() && Progress.grant(w.id()))
                Progress.toast("cutemod.toast.newwear", net.minecraft.network.chat.Component.translatable("cutemod.shop.item." + w.id()).getString());
        }
        if (p.head().phase() == ShowBoard.RESULTS && p.me().entered() && p.me().rank() > 0) { writeLetter(p); checkDaily(p); }
    }

    // ---------- the alert: the show is coming ----------
    private static long alertUntil, alertOpensAt;
    private static int alertTheme;

    /** The server says the show is coming (sec = 0: the doors are open now). The Pet icon of the Dock gets a badge until the doors close. */
    public static void alert(int sec, int theme) {
        long now = System.currentTimeMillis();
        alertOpensAt = now + sec * 1000L;
        alertUntil = alertOpensAt + ShowBoard.OPEN_MS;
        alertTheme = theme;
        Progress.toast(sec <= 0 ? "cutemod.show.alert.open" : "cutemod.show.alert.soon", net.minecraft.network.chat.Component.translatable("cutemod.show.theme." + theme).getString());
        Sfx.ui(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_BELL.value(), 1.0F, 0.7F);          // a little fanfare
        Sfx.ui(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_BELL.value(), 1.26F, 0.7F);
        Sfx.ui(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_BELL.value(), 1.5F, 0.7F);
        Sfx.ui(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.6F);
    }

    /** True while the alert is on (for the badge on the Pet icon). */
    public static boolean alertOn() { return System.currentTimeMillis() < alertUntil; }

    /** Seconds until the doors open (0 = they are open), -1 = no alert. */
    public static int alertOpensIn() {
        long now = System.currentTimeMillis();
        if (now >= alertUntil) return -1;
        return (int) Math.max(0, (alertOpensAt - now + 999) / 1000);
    }

    public static int alertTheme() { return alertTheme; }

    // ---------- acts and rehearsals ----------
    public static final int ACTS = dev.cutemod.data.ShowJudges.ACTS;
    public static final int REHEARSAL_COST = 3;
    private static final long REHEARSAL_GAP_MIN = 4;
    private static final int[] SKILL_AT = {2, 5, 9};          // rehearsals needed for skill 1, 2, 3

    /** The act the player performs (kept between shows). */
    public static int act() { return Math.max(0, Math.min(ACTS - 1, Progress.count("show_act"))); }

    public static void setAct(int a) { Progress.setCount("show_act", Math.max(0, Math.min(ACTS - 1, a))); }

    public static int rehearsals(int act) { return Progress.count("show_xp" + act); }

    /** How well the act has been rehearsed: 0 to 3. */
    public static int skill(int act) {
        int n = rehearsals(act), s = 0;
        for (int need : SKILL_AT) if (n >= need) s++;
        return s;
    }

    /** Rehearsals still needed for the next skill level (0 = the top). */
    public static int toNext(int act) {
        int n = rehearsals(act);
        for (int need : SKILL_AT) if (n < need) return need - n;
        return 0;
    }

    private static int nowMin() { return (int) (System.currentTimeMillis() / 60_000L); }

    /** Minutes until this act can be rehearsed again (0 = now). */
    public static int rehearsalWait(int act) {
        int w = Progress.count("show_cd" + act) + (int) REHEARSAL_GAP_MIN - nowMin();
        return Math.max(0, w);
    }

    /** 0 done, 1 too soon, 2 no coins, 3 already a master. */
    public static int rehearse(int act) {
        if (act < 0 || act >= ACTS) return 3;
        if (skill(act) >= dev.cutemod.data.ShowJudges.MAX_SKILL) return 3;
        if (rehearsalWait(act) > 0) return 1;
        if (!Progress.spend(REHEARSAL_COST)) return 2;
        Progress.setCount("show_cd" + act, nowMin());
        int before = skill(act);
        Progress.setCount("show_xp" + act, rehearsals(act) + 1);
        Progress.bump("show_rehearsals");
        if (skill(act) > before) Progress.toast("cutemod.show.skillup", net.minecraft.network.chat.Component.translatable("cutemod.show.act." + act).getString(), skill(act));
        return 0;
    }

    // ---------- the task of the day ----------
    private static int today() { return (int) (System.currentTimeMillis() / 86_400_000L); }

    /** 0 take part in a show, 1 finish in the top three, 2 perform the act of the day. */
    public static int dailyKind() { return Math.floorMod(today(), 3); }

    public static int dailyAct() { return Math.floorMod(today() / 3, ACTS); }

    public static boolean dailyDone() { return Progress.count("show_dq") == today(); }

    public static final int DAILY_REWARD = 8;

    private static void checkDaily(ShowSyncPayload p) {
        if (dailyDone()) return;
        String me = net.minecraft.client.Minecraft.getInstance().player == null ? "" : net.minecraft.client.Minecraft.getInstance().player.getUUID().toString();
        ShowSyncPayload.Entry mine = null;
        for (ShowSyncPayload.Entry e : p.pets()) if (!e.bot() && e.who().owner().equals(me)) mine = e;
        if (mine == null) return;
        boolean ok = switch (dailyKind()) {
            case 0 -> true;
            case 1 -> p.me().rank() <= 3;
            default -> mine.who().act() == dailyAct();
        };
        if (!ok) return;
        Progress.setCount("show_dq", today());
        Progress.toast("cutemod.show.daily.done");
        Progress.earn(DAILY_REWARD);
    }

    /** Give the golden flower of the audience to this pet. */
    public static void flower(String owner, String colorId) { PacketDistributor.sendToServer(new ShowActionPayload(ShowActionPayload.FLOWER, owner, colorId)); }

    /** After the results of a round we took part in, one judge writes to us (once per round). */
    private static void writeLetter(ShowSyncPayload p) {
        int round = (int) ShowBoard.roundOf(System.currentTimeMillis());
        var player = net.minecraft.client.Minecraft.getInstance().player;
        if (player == null || Progress.count("show_lr") == round) return;
        String me = player.getUUID().toString();
        ShowSyncPayload.Entry mine = null;
        for (ShowSyncPayload.Entry e : p.pets()) if (!e.bot() && e.who().owner().equals(me)) mine = e;
        if (mine == null || mine.score().stars().size() < 4) return;
        var stars = mine.score().stars();
        int best = 0, weak = 0;                                   // who liked it most / least
        for (int j = 1; j < dev.cutemod.data.ShowJudges.COUNT; j++) {   // the four seats (the guest judge writes no letters)
            if (stars.get(j) > stars.get(best)) best = j;
            if (stars.get(j) < stars.get(weak)) weak = j;
        }
        Progress.setCount("show_lr", round);
        int panel = p.head().panel();                              // the judges of that round: the letter is from the one who sat on the best seat
        Mail.showLetter(dev.cutemod.data.ShowJudges.persona(panel, best), stars.get(best), mine.score().total(), p.me().rank(), p.head().theme(),
                dev.cutemod.data.ShowJudges.persona(panel, weak));
    }

    /** Your cups and the hall of fame (null before the first answer of the server). */
    public static ShowSyncPayload.Fame fame() { return last == null ? null : last.fame(); }

    /** The title your gold cups give you ("" if none yet). */
    public static String myTitle() {
        ShowSyncPayload.Fame f = fame();
        int lvl = f == null ? 0 : ShowBoard.titleLevel(f.gold());
        return lvl > 0 ? net.minecraft.network.chat.Component.translatable("cutemod.show.rank." + lvl).getString() : "";
    }

    /** The last stage (null before the first answer). */
    public static ShowSyncPayload last() { return last; }

    public static void clear() { last = null; }

    /** Ask the server for the stage as it is now. */
    public static void request() { PacketDistributor.sendToServer(new ShowRequestPayload()); }

    /** The show has paid us: the coins are ours (0 = the daily limit of the show is used up). */
    public static void prize(int coins, int rank) {
        if (coins > 0) Progress.earn(coins);
        if (rank >= 1 && rank <= 3) Progress.toast("cutemod.show.cup." + rank);   // a cup for the shelf
        request();                                                                // and the shelf learns about it
    }

    /** Put the pet of this computer color on the stage, as it is right now (or refresh it). False if that pet does not exist yet. */
    public static boolean exhibit(String colorId) {
        PetBlob.Info i = PetBlob.parse(Store.read("pet_" + colorId));
        if (i == null) return false;
        PacketDistributor.sendToServer(new ShowPutPayload(colorId, i.sick(),
                new PetLook(i.stage(), i.trait(), i.ageMin(), short24(Progress.equipped()), short24(Progress.equippedBody()), ""), act(), skill(act())));
        return true;
    }

    public static void withdraw(String colorId) { PacketDistributor.sendToServer(new ShowActionPayload(ShowActionPayload.WITHDRAW, "", colorId)); }

    public static void like(String owner, String colorId) { PacketDistributor.sendToServer(new ShowActionPayload(ShowActionPayload.LIKE, owner, colorId)); }

    public static void unlike(String owner, String colorId) { PacketDistributor.sendToServer(new ShowActionPayload(ShowActionPayload.UNLIKE, owner, colorId)); }

    private static String short24(String s) { return s == null || s.length() > 64 ? "" : s; }
}
