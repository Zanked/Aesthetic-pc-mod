package dev.cutemod.client.os;

import java.time.LocalDate;
import java.util.List;

/**
 * The OS updates: each one has a date (the real date of the player's computer). From that day it can be installed
 * in Settings, the helper bee tells about it, and it brings something new (a screensaver and a bee outfit).
 * The names and texts are in the lang files: cutemod.update.<id>.name / .l1 / .l2 / .l3.
 */
public final class Updates {
    private Updates() {}

    /**
     * saver = the screensaver it unlocks (index in {@link Savers}), outfit = the bee outfit it brings (1..5),
     * place = the new place for pet trips it opens (see {@link Trip}). Every update also adds a decoration to the
     * Pet Park (the one with the number of the update, see PetPark).
     */
    public record Update(String id, LocalDate date, int saver, int outfit, int place) {}

    public static final List<Update> ALL = List.of(
            new Update("honeycomb", LocalDate.of(2026, 11, 1), 4, 1, 6),
            new Update("skyline", LocalDate.of(2026, 12, 1), 5, 2, 7),
            new Update("frost", LocalDate.of(2027, 1, 15), 6, 3, 8),
            new Update("blossom", LocalDate.of(2027, 3, 1), 7, 4, 9),
            new Update("sunset", LocalDate.of(2027, 5, 1), 8, 5, 10));

    /** The update that can be installed now (its date has come), or -1. */
    public static int available() {
        int v = Retro.version();
        return v < ALL.size() && !LocalDate.now().isBefore(ALL.get(v).date()) ? v : -1;
    }

    /** The next update that is not out yet (null if all are installed or one is waiting). */
    public static Update upcoming() {
        int v = Retro.version();
        return v < ALL.size() && available() < 0 ? ALL.get(v) : null;
    }

    /** "1.0" for a fresh system, then "1.1", "1.2"... */
    public static String versionLabel() { return "1." + Retro.version(); }

    public static boolean unlocksSaver(int saver) {
        for (int i = 0; i < Retro.version(); i++) if (ALL.get(i).saver() == saver) return true;
        return false;
    }

    /** True if update number i (0-4) is installed. */
    public static boolean has(int i) { return i >= 0 && i < Retro.version(); }

    /** True if this pet trip place can be visited: the first 6 always, the others once their update is installed. */
    public static boolean placeOpen(int dest) {
        if (dest < Trip.BASE) return true;
        for (int i = 0; i < Retro.version(); i++) if (ALL.get(i).place() == dest) return true;
        return false;
    }

    /** The update that brings this place (null for the first 6 places). */
    public static Update placeUpdate(int dest) {
        for (Update u : ALL) if (u.place() == dest) return u;
        return null;
    }

    /** The outfit of the helper bee: the one of the newest installed update (0 = none). */
    public static int outfit() {
        int v = Retro.version();
        return v == 0 ? 0 : ALL.get(v - 1).outfit();
    }
}
