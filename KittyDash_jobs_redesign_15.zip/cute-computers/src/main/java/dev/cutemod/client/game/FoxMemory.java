package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Orange computer: find the pairs. */
public class FoxMemory extends MiniGame {
    private static final int CW = 44, CH = 28, GAP = 6, OX = 13, OY = 5;
    private static final int[] COLORS = {0xFFE0594F, 0xFF4A8FE0, 0xFF52B85A, 0xFFE0A93A, 0xFF9B5FD0, 0xFF3CB8B0, 0xFFD9689A, 0xFF8A6A4A};
    private static final String SYMBOLS = "ABCDEFGH";

    private final int[] cards = new int[16];
    private final boolean[] open = new boolean[16];
    private final boolean[] done = new boolean[16];
    private int first, second, timer, moves, pairs;

    @Override
    public void reset() {
        score = 0; over = false; first = -1; second = -1; timer = 0; moves = 0; pairs = 0;
        for (int i = 0; i < 16; i++) { cards[i] = i / 2; open[i] = false; done[i] = false; }
        for (int i = 15; i > 0; i--) { int j = rnd.nextInt(i + 1); int tmp = cards[i]; cards[i] = cards[j]; cards[j] = tmp; }
    }

    private int cardAt(int x, int y) {
        for (int i = 0; i < 16; i++) {
            int cx = OX + (i % 4) * (CW + GAP), cy = OY + (i / 4) * (CH + GAP);
            if (in(x, y, cx, cy, CW, CH)) return i;
        }
        return -1;
    }

    private void flipBack() {
        if (first >= 0) open[first] = false;
        if (second >= 0) open[second] = false;
        first = -1; second = -1; timer = 0;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (timer > 0) flipBack();
        int i = cardAt(x, y);
        if (i < 0 || open[i] || done[i]) return true;
        open[i] = true;
        pling(0.9F + cards[i] * 0.08F);
        if (first < 0) { first = i; return true; }
        second = i; moves++;
        if (cards[first] == cards[second]) {
            done[first] = true; done[second] = true; pairs++;
            first = -1; second = -1;
            if (pairs == 8) { score = Math.max(10, 200 - 8 * moves); over = true; }
        } else {
            timer = 50;
        }
        return true;
    }

    @Override
    public void tick() {
        if (timer > 0 && --timer == 0) flipBack();
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF7A3A1C, 0xFF4A2210);
        for (int i = 0; i < 16; i++) {
            int cx = OX + (i % 4) * (CW + GAP), cy = OY + (i / 4) * (CH + GAP);
            if (open[i] || done[i]) {
                rect(g, cx, cy, CW, CH, done[i] ? 0xFFFFF3DC : 0xFFFFFFFF);
                rect(g, cx + 2, cy + 2, CW - 4, CH - 4, COLORS[cards[i]]);
                ctext(g, String.valueOf(SYMBOLS.charAt(cards[i])), cx + CW / 2, cy + CH / 2 - 4, 0xFFFFFFFF);
            } else {
                rect(g, cx, cy, CW, CH, 0xFFF58B25);
                rect(g, cx + 2, cy + 2, CW - 4, CH - 4, 0xFFFFB866);
                rect(g, cx + CW / 2 - 4, cy + CH / 2 - 3, 8, 6, 0xFFFFF3DC); // little fox muzzle
                rect(g, cx + CW / 2 - 8, cy + 4, 4, 5, 0xFFC96A10);
                rect(g, cx + CW / 2 + 4, cy + 4, 4, 5, 0xFFC96A10);
            }
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.moves", moves); }

    @Override
    public String hintKey() { return "cutemod.hint.memory"; }
}
