package dev.cutemod.client.os;

import dev.cutemod.net.PostBlockPayload;
import dev.cutemod.net.PostDeletePayload;
import dev.cutemod.net.PostRequestPayload;
import dev.cutemod.net.PostSendPayload;
import dev.cutemod.net.PostSyncPayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Mail between players on the client: a copy of the mailbox the server sent, plus which letters were read. */
public final class Post {
    private Post() {}

    private static List<PostSyncPayload.Letter> inbox = List.of();
    private static List<String> players = List.of(), blocked = List.of();
    private static int result = -1;
    private static long resultAt;
    private static boolean loaded;

    public static void apply(PostSyncPayload p) {
        inbox = p.inbox();
        players = p.players();
        blocked = p.blocked();
        loaded = true;
        if (p.result() >= 0) { result = p.result(); resultAt = System.currentTimeMillis(); }
    }

    public static void clear() { inbox = List.of(); players = List.of(); blocked = List.of(); result = -1; loaded = false; read = null; }

    public static boolean loaded() { return loaded; }

    public static List<PostSyncPayload.Letter> inbox() { return inbox; }

    public static List<String> players() { return players; }

    public static boolean isBlocked(String name) {
        for (String b : blocked) if (b.equalsIgnoreCase(name)) return true;
        return false;
    }

    /** The answer to the last sent letter (-1 = nothing new). Reading it again returns -1 until the next answer. */
    public static int takeResult() {
        int r = result;
        result = -1;
        return r;
    }

    public static boolean hasResult() { return result >= 0; }

    // ---------- read marks (saved on the server with the rest of your computer) ----------
    private static Set<Long> read;
    private static int readGen = -1;

    private static Set<Long> read() {
        if (read == null || readGen != Store.gen()) {
            read = new HashSet<>();
            readGen = Store.gen();
            String s = Store.read("post_read");
            if (s != null) for (String part : s.trim().split(",")) {
                try { if (!part.isBlank()) read.add(Long.parseLong(part.trim())); } catch (NumberFormatException ignored) { }
            }
        }
        return read;
    }

    public static boolean unread(PostSyncPayload.Letter l) { return !read().contains(l.id()); }

    public static int unreadCount() {
        int n = 0;
        for (PostSyncPayload.Letter l : inbox) if (unread(l)) n++;
        return n;
    }

    public static void markRead(PostSyncPayload.Letter l) {
        Set<Long> r = read();
        if (!r.add(l.id())) return;
        Set<Long> live = new HashSet<>();                       // forget marks of letters that are gone
        for (PostSyncPayload.Letter x : inbox) live.add(x.id());
        r.retainAll(live);
        StringBuilder sb = new StringBuilder();
        for (long id : r) sb.append(id).append(',');
        Store.write("post_read", sb.toString());
    }

    // ---------- requests ----------
    public static void request() { PacketDistributor.sendToServer(new PostRequestPayload()); }

    public static void send(String to, String text, byte[] drawing) {
        PacketDistributor.sendToServer(new PostSendPayload(to, text, drawing));
    }

    public static void delete(long id) { PacketDistributor.sendToServer(new PostDeletePayload(id)); }

    public static void block(String name, boolean on) { PacketDistributor.sendToServer(new PostBlockPayload(name, on)); }
}
