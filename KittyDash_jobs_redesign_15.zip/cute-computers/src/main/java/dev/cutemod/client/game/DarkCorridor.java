package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * First-person horror. A random dark maze (a classic "raycaster": one ray per screen column).
 * Find 5 keys, then reach the green door. A pale figure walks the corridors and follows you.
 * It is slower than you, but it never stops, and you can only see it when it is close.
 * <ul>
 *   <li><b>F</b>: the flashlight. Its beam scares the monster (it runs away and forgets you for a while), shows the
 *       way and makes false keys vanish, but the battery lasts about 18 seconds. Batteries lie in the maze.</li>
 *   <li><b>E</b>: hide in a closet. If the monster did not see you go in, it only checks the closet now and then (and
 *       may or may not find you); if it did see you, it comes straight for it.</li>
 *   <li>Not everything is real: false keys that wake the monster when you touch them, pale apparitions that vanish in
 *       the light, whispers, and a screen that shakes when it is close.</li>
 * </ul>
 */
public class DarkCorridor extends MiniGame {
    private static final int N = 15, KEYS = 5;          // maze is N x N tiles (walls included)
    private static final int BATT = 4, FAKES = 2, WARD = 4;   // batteries, false keys and closets (wardrobes)
    private static final int COLS = 110, CW = W / COLS; // one ray per 2 px
    private static final double PLANE = 0.75;           // field of view (bigger = wider)

    // tiny sprites: one char = one pixel (see pal())
    private static final String[] MONSTER = {
            "..kkkk..", ".kwwwwk.", ".kwrwrk.", ".kwwwwk.", "..kwwk..", "kkkkkkkk", "k.kkkk.k", "k.kkkk.k",
            "k.kkkk.k", "k.kkkk.k", "k.kkkk.k", "..kkkk..", "..k..k..", "..k..k..", "..k..k..", "..k..k.."};
    private static final String[] KEY = {
            "..yyyy..", ".y....y.", ".y....y.", "..yyyy..", "...yy...", "...yyy..", "...yy...", "...yyy.."};
    private static final String[] DOOR = {
            "dddddd", "dggggd", "dggggd", "dggggd", "dggggd", "dggggd", "dggggd", "dgggyd", "dggggd", "dggggd", "dggggd", "dggggd"};
    private static final String[] BAT = {
            "..EE..", ".eeee.", ".eyye.", ".eyye.", ".eeee.", ".eeee.", ".eEEe."};
    private static final String[] CLOSET = {
            "NNNNNNNN", "nnnnnnnn", "nNNnnNNn", "nNNnnNNn", "nNNnnNNn", "nNNyyNNn", "nNNnnNNn", "nNNnnNNn", "nNNnnNNn",
            "nnnnnnnn", "NNNNNNNN", "n......n"};
    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    private final int[][] map = new int[N][N];          // 1 = wall
    private final boolean[][] seen = new boolean[N][N]; // for the little map
    private final double[] zbuf = new double[COLS];     // wall distance per column (hides sprites behind walls)
    private final double[] kx = new double[KEYS], ky = new double[KEYS];
    private final boolean[] got = new boolean[KEYS];
    private final double[] bx = new double[BATT], by = new double[BATT];      // batteries
    private final boolean[] bgot = new boolean[BATT];
    private final double[] fx = new double[FAKES], fy = new double[FAKES];    // false keys
    private final boolean[] fgone = new boolean[FAKES];
    private final double[] wx = new double[WARD], wy = new double[WARD];      // closets

    private double px, py, ang, ex, ey, tx, ty, light, battery = 1, gx, gy;   // gx, gy: an apparition
    private int ox, oy;                                 // where the monster last heard you
    private int keys, ticks, msgT, scareT, deafT, hideCd, inHide, checkT, gT, nextGhost, whisperT;
    private boolean won, awake, lamp, hidden, compromised;
    private String msg = "";

    @Override
    public void reset() {
        score = 0; over = false; won = false; awake = false; ex = ey = tx = ty = -100; keys = 0; ticks = 0; msgT = 0; light = 1;
        battery = 1; lamp = false; hidden = false; compromised = false;
        scareT = 0; deafT = 0; hideCd = 0; inHide = 0; checkT = 0; gT = 0;
        nextGhost = 600 + rnd.nextInt(600);
        whisperT = 900 + rnd.nextInt(900);
        Arrays.fill(got, false);
        Arrays.fill(bgot, false);
        Arrays.fill(fgone, false);
        for (boolean[] r : seen) Arrays.fill(r, false);
        build();
        px = 1.5; py = 1.5;
        ox = 1; oy = 1;
        ang = map[1][2] == 0 ? 0 : Math.PI / 2;
        say("cutemod.maze.start");
    }

    /** Random maze: carve corridors with a depth-first walk, then knock out a few walls to make loops. */
    private void build() {
        for (int[] r : map) Arrays.fill(r, 1);
        ArrayDeque<int[]> st = new ArrayDeque<>();
        map[1][1] = 0;
        st.push(new int[]{1, 1});
        while (!st.isEmpty()) {
            int[] c = st.peek();
            List<int[]> opts = new ArrayList<>();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0] * 2, ny = c[1] + d[1] * 2;
                if (nx > 0 && ny > 0 && nx < N - 1 && ny < N - 1 && map[ny][nx] == 1) opts.add(d);
            }
            if (opts.isEmpty()) { st.pop(); continue; }
            int[] d = opts.get(rnd.nextInt(opts.size()));
            map[c[1] + d[1]][c[0] + d[0]] = 0;
            map[c[1] + d[1] * 2][c[0] + d[0] * 2] = 0;
            st.push(new int[]{c[0] + d[0] * 2, c[1] + d[1] * 2});
        }
        for (int i = 0; i < 14; i++) {
            int x = 1 + rnd.nextInt(N - 2), y = 1 + rnd.nextInt(N - 2);
            if ((x + y) % 2 == 1) map[y][x] = 0;
        }
        // everything stands in the middle of random tiles: the keys far from the start, the rest closer
        List<int[]> cells = new ArrayList<>();
        for (int y = 1; y < N - 1; y += 2) for (int x = 1; x < N - 1; x += 2) {
            if (!(x == 1 && y == 1) && !(x == N - 2 && y == N - 2)) cells.add(new int[]{x, y});
        }
        for (int i = 0; i < KEYS; i++) { int[] c = take(cells, 8); kx[i] = c[0] + 0.5; ky[i] = c[1] + 0.5; }
        for (int i = 0; i < BATT; i++) { int[] c = take(cells, 4); bx[i] = c[0] + 0.5; by[i] = c[1] + 0.5; }
        for (int i = 0; i < FAKES; i++) { int[] c = take(cells, 6); fx[i] = c[0] + 0.5; fy[i] = c[1] + 0.5; }
        for (int i = 0; i < WARD; i++) { int[] c = take(cells, 3); wx[i] = c[0] + 0.5; wy[i] = c[1] + 0.5; }
    }

    /** A random free tile at least minSum steps (x + y) from the start; it is removed from the list. */
    private int[] take(List<int[]> cells, int minSum) {
        List<int[]> ok = new ArrayList<>();
        for (int[] c : cells) if (c[0] + c[1] >= minSum) ok.add(c);
        int[] c = ok.isEmpty() ? cells.get(0) : ok.get(rnd.nextInt(ok.size()));
        cells.remove(c);
        return c;
    }

    /** A tile at least 10 steps (Manhattan) from you. */
    private int[] farCell() {
        List<int[]> far = new ArrayList<>();
        for (int y = 1; y < N - 1; y += 2) for (int x = 1; x < N - 1; x += 2) {
            if (Math.abs(x - (int) px) + Math.abs(y - (int) py) >= 10) far.add(new int[]{x, y});
        }
        return far.get(rnd.nextInt(far.size()));
    }

    /** After 8 seconds something wakes up, far away from you. */
    private void spawn() {
        int[] m = farCell();
        ex = tx = m[0] + 0.5;
        ey = ty = m[1] + 0.5;
        ox = (int) px;
        oy = (int) py;
        awake = true;
        say("cutemod.maze.wake");
        pling(0.5F);
        growl(G_ROAR);
    }

    private void say(String key) { msg = key; msgT = 150; }

    // ---------- the flashlight ----------
    /** The beam works when the lamp is on, has charge (and is not in its last flicker) and you are not in a closet. */
    private boolean lampOn() { return lamp && battery > 0 && !hidden && !(battery < 0.2 && ticks % 14 < 4); }

    /** Can you see from (ax, ay) to (bx, by) without a wall in between? */
    private boolean visible(double ax, double ay, double bx, double by) {
        double d = Math.hypot(bx - ax, by - ay);
        int n = (int) (d / 0.2) + 1;
        for (int i = 1; i < n; i++) {
            double t = i / (double) n;
            if (map[(int) (ay + (by - ay) * t)][(int) (ax + (bx - ax) * t)] == 1) return false;
        }
        return true;
    }

    /** Is the point inside the cone of the flashlight (about 23 degrees to each side) and in the open? */
    private boolean inBeam(double x, double y, double range) {
        if (!lampOn()) return false;
        double dx = x - px, dy = y - py, d = Math.hypot(dx, dy);
        if (d > range || d < 0.1) return false;
        double diff = Math.atan2(dy, dx) - ang;
        diff = Math.atan2(Math.sin(diff), Math.cos(diff));
        return Math.abs(diff) < 0.4 && visible(px, py, x, y);
    }

    // ---------- the closets ----------
    private int nearCloset() {
        int near = -1;
        double best = 1.0;
        for (int i = 0; i < WARD; i++) {
            double d = Math.hypot(wx[i] - px, wy[i] - py);
            if (d < best) { best = d; near = i; }
        }
        return near;
    }

    private void toggleHide() {
        if (hidden) { leaveCloset(); return; }
        int near = nearCloset();
        if (near < 0 || hideCd > 0) return;
        int fromX = (int) px, fromY = (int) py, inX = (int) wx[near], inY = (int) wy[near];
        compromised = awake && Math.hypot(ex - wx[near], ey - wy[near]) < 8 && visible(ex, ey, px, py);   // it saw you go in
        hidden = true;
        lamp = false;
        px = wx[near];
        py = wy[near];
        inHide = 0;
        checkT = 0;
        if (awake) {
            if (compromised) { ox = inX; oy = inY; }                       // it comes for the closet
            else if (fromX == inX && fromY == inY) {                      // it heard you right here: send it to a tile beside the closet
                for (int[] d : DIRS) if (map[inY + d[1]][inX + d[0]] == 0) { ox = inX + d[0]; oy = inY + d[1]; break; }
            } else { ox = fromX; oy = fromY; }
        }
        say("cutemod.maze.hidden");
        pling(0.8F);
    }

    private void leaveCloset() {
        hidden = false;
        compromised = false;
        hideCd = 90;
        inHide = 0;
        checkT = 0;
        pling(1.2F);
    }

    /** The monster stands next to your closet: after 2 seconds it opens it (45 %) or gives up and wanders off. */
    private void peek(double md) {
        if (md >= 1.6) { checkT = 0; return; }
        if (++checkT < 120) return;
        if (compromised || rnd.nextInt(100) < 45) { over = true; pling(0.5F); beep(); growl(G_SCREAM); return; }
        int[] far = farCell();
        ox = far[0];
        oy = far[1];
        deafT = 420;
        checkT = 0;
        say("cutemod.maze.leave");
    }

    /** A pale figure shows up a few steps ahead of you for a moment. It is not real: the light makes it vanish. */
    private void spawnGhost() {
        for (int tries = 0; tries < 12; tries++) {
            double a = ang + (rnd.nextDouble() - 0.5) * 0.9, d = 2.5 + rnd.nextDouble() * 3;
            double x = px + Math.cos(a) * d, y = py + Math.sin(a) * d;
            int ix = (int) x, iy = (int) y;
            if (ix > 0 && iy > 0 && ix < N - 1 && iy < N - 1 && map[iy][ix] == 0 && visible(px, py, x, y)) {
                gx = ix + 0.5;
                gy = iy + 0.5;
                gT = 50;
                pling(0.4F);
                return;
            }
        }
    }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private void move(double dx, double dy) {
        double r = 0.22;
        if (map[(int) py][(int) (px + dx + Math.signum(dx) * r)] == 0) px += dx;
        if (map[(int) (py + dy + Math.signum(dy) * r)][(int) px] == 0) py += dy;
    }

    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        if (hideCd > 0) hideCd--;
        if (scareT > 0) scareT--;
        if (deafT > 0) deafT--;
        double md = Math.hypot(ex - px, ey - py);
        light = ((md < 4 && ticks % 11 < 2) || ticks % 500 > 492) ? 0.35 : 1.0;   // the light flickers

        // the flashlight scares the monster, and it eats its battery fast
        if (lamp && !hidden) {
            battery -= 0.0009;                                                    // about 18 seconds from a full battery
            if (awake && inBeam(ex, ey, 8)) battery -= 0.0015;                    // shining at the monster costs even more
            if (battery <= 0) { battery = 0; lamp = false; say("cutemod.maze.dead"); beep(); }
        }
        if (awake && scareT == 0 && inBeam(ex, ey, 7.5)) {
            scareT = 150;                                                         // it runs away for 2.5 seconds ...
            deafT = 360;                                                          // ... and does not hear you for 6
            ox = (int) ex;
            oy = (int) ey;
            say("cutemod.maze.scare");
            pling(1.9F);
        }

        // walk: W/S or up/down, turn: A/D or left/right (in a closet you stand still; W/S gets you out)
        double turn = (down(68) || down(KEY_RIGHT) ? 1 : 0) - (down(65) || down(KEY_LEFT) ? 1 : 0);
        double walk = (down(87) || down(KEY_UP) ? 1 : 0) - (down(83) || down(KEY_DOWN) ? 1 : 0);
        if (hidden) {
            inHide++;
            if (inHide > 30 && walk != 0) leaveCloset();
            turn = 0;
            walk = 0;
        }
        ang += turn * 0.05;
        move(Math.cos(ang) * walk * 0.05, Math.sin(ang) * walk * 0.05);
        for (int dy = -2; dy <= 2; dy++) for (int dx = -2; dx <= 2; dx++) {   // little map: remember what we saw
            int cx = (int) px + dx, cy = (int) py + dy;
            if (cx >= 0 && cy >= 0 && cx < N && cy < N) seen[cy][cx] = true;
        }

        if (!hidden && deafT == 0 && (ticks % 120 == 0 || md < 3)) { ox = (int) px; oy = (int) py; }   // it hears you every 2 s (always, when close)
        if (ticks == 480) spawn();
        if (awake) chase();
        md = Math.hypot(ex - px, ey - py);
        if (hidden && awake) peek(md);
        if (over) return;
        if (md < 0.55 && (!hidden || compromised)) { over = true; pling(0.5F); beep(); growl(G_SCREAM); return; }
        if (md < 7 && ticks % (int) (14 + md * 6) == 0) pling(0.5F);   // heartbeat, faster when it is close
        if (md < 6 && ticks % 100 == 0) growl(G_DEEP);                  // it growls when it is near

        for (int i = 0; i < KEYS; i++) {
            if (!got[i] && Math.hypot(kx[i] - px, ky[i] - py) < 0.5) {
                got[i] = true;
                keys++;
                score += 100;
                if (awake) { ox = (int) px; oy = (int) py; deafT = 0; }       // "...it heard that": it knows where you are
                pling(1.8F);
                say("cutemod.maze.key");
            }
        }
        for (int i = 0; i < BATT; i++) {
            if (!bgot[i] && Math.hypot(bx[i] - px, by[i] - py) < 0.5) {
                bgot[i] = true;
                battery = Math.min(1, battery + 0.5);
                pling(1.4F);
                say("cutemod.maze.battery");
            }
        }
        for (int i = 0; i < FAKES; i++) {                                     // false keys: touch one and it wakes the monster
            if (fgone[i]) continue;
            if (Math.hypot(fx[i] - px, fy[i] - py) < 1.1) {
                fgone[i] = true;
                if (awake) { ox = (int) px; oy = (int) py; deafT = 0; }
                say("cutemod.maze.fake");
                pling(0.4F);
            } else if (inBeam(fx[i], fy[i], 6)) {                             // ... but the light shows what they are
                fgone[i] = true;
                battery = Math.max(0, battery - 0.02);
                say("cutemod.maze.fake_light");
                pling(0.9F);
            }
        }

        if (!hidden) {                                                        // things that are not there
            if (gT > 0) { gT--; if (inBeam(gx, gy, 8)) gT = 0; }
            else if (--nextGhost <= 0) { spawnGhost(); nextGhost = 900 + rnd.nextInt(1200); }
            if (--whisperT <= 0) {
                whisperT = 1200 + rnd.nextInt(1500);
                if (msgT == 0) say("cutemod.maze.whisper." + rnd.nextInt(5));
            }
        }

        if (Math.hypot(N - 1.5 - px, N - 1.5 - py) < 0.8) {
            if (keys == KEYS) {
                won = true;
                over = true;
                score += 500 + Math.max(0, 600 - ticks / 30);      // faster = more points
                pling(1.0F); pling(1.5F); pling(2.0F);
            } else if (msgT == 0) say("cutemod.maze.locked");
        }
    }

    // ---------- the monster: walks tile to tile along the shortest way to you ----------
    private void chase() {
        double sp = scareT > 0 ? 0.034 : 0.017 + 0.003 * keys;     // gets faster with every key (you walk 0.05); scared by the light: it runs
        double dx = tx - ex, dy = ty - ey, d = Math.hypot(dx, dy);
        if (d <= sp) { ex = tx; ey = ty; if (scareT > 0) flee(); else next(); }
        else { ex += dx / d * sp; ey += dy / d * sp; }
    }

    /** Scared by the light: the next tile is the neighbour that is farthest from you. */
    private void flee() {
        int[][] dist = new int[N][N];
        for (int[] r : dist) Arrays.fill(r, -1);
        ArrayDeque<int[]> q = new ArrayDeque<>();
        int sx = (int) px, sy = (int) py;
        dist[sy][sx] = 0;
        q.add(new int[]{sx, sy});
        while (!q.isEmpty()) {
            int[] c = q.poll();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0], ny = c[1] + d[1];
                if (map[ny][nx] == 0 && dist[ny][nx] < 0) { dist[ny][nx] = dist[c[1]][c[0]] + 1; q.add(new int[]{nx, ny}); }
            }
        }
        int cx = (int) ex, cy = (int) ey, best = dist[cy][cx];
        tx = cx + 0.5;
        ty = cy + 0.5;
        for (int[] d : DIRS) {
            int nx = cx + d[0], ny = cy + d[1];
            if (map[ny][nx] == 0 && dist[ny][nx] > best) { best = dist[ny][nx]; tx = nx + 0.5; ty = ny + 0.5; }
        }
    }

    private void next() {
        int cx = (int) ex, cy = (int) ey;
        if (cx == (int) px && cy == (int) py) { tx = px; ty = py; return; }   // right on top of you
        if (cx == ox && cy == oy) { tx = cx + 0.5; ty = cy + 0.5; return; }   // reached the last heard spot: waits there
        int[][] dist = new int[N][N];
        for (int[] r : dist) Arrays.fill(r, -1);
        ArrayDeque<int[]> q = new ArrayDeque<>();
        dist[oy][ox] = 0;
        q.add(new int[]{ox, oy});
        while (!q.isEmpty()) {                                     // distance from every tile to where it heard you
            int[] c = q.poll();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0], ny = c[1] + d[1];
                if (map[ny][nx] == 0 && dist[ny][nx] < 0) { dist[ny][nx] = dist[c[1]][c[0]] + 1; q.add(new int[]{nx, ny}); }
            }
        }
        int best = dist[cy][cx];
        tx = cx + 0.5;
        ty = cy + 0.5;
        for (int[] d : DIRS) {
            int nx = cx + d[0], ny = cy + d[1];
            if (map[ny][nx] == 0 && dist[ny][nx] >= 0 && dist[ny][nx] < best) { best = dist[ny][nx]; tx = nx + 0.5; ty = ny + 0.5; }
        }
    }

    // ---------- drawing ----------
    private static int shade(int rgb, double b) {
        b = Math.max(0, Math.min(1.4, b));
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * b));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * b));
        int bl = Math.min(255, (int) ((rgb & 255) * b));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int pal(char c, boolean open) {
        return switch (c) {
            case 'k' -> 0xFF14101A;
            case 'w' -> 0xFFE8E4EC;
            case 'r' -> 0xFFFF2A2A;
            case 'y' -> 0xFFFFD84A;
            case 'e' -> 0xFF4AC8FF;
            case 'E' -> 0xFF2A78A8;
            case 'n' -> 0xFF7A5230;
            case 'N' -> 0xFF4A3018;
            case 'g' -> open ? 0xFF3CFF7A : 0xFFFF4A4A;
            default -> 0xFF2A2A3A;
        };
    }

    @Override
    public void render(GuiGraphics g) {
        if (over && !won) { jumpScare(g); return; }
        double md0 = Math.hypot(ex - px, ey - py);
        double shake = awake && !hidden && md0 < 2.5 ? (2.5 - md0) * 0.8 : 0;      // the whole picture trembles when it is close
        g.pose().pushPose();
        if (shake > 0) g.pose().translate((rnd.nextDouble() - 0.5) * shake * 2, (rnd.nextDouble() - 0.5) * shake * 2, 0);
        g.fillGradient(0, 0, W, H / 2, 0xFF1A1418, 0xFF050405);    // ceiling
        g.fillGradient(0, H / 2, W, H, 0xFF050405, 0xFF2A2220);    // floor
        double dirX = Math.cos(ang), dirY = Math.sin(ang), plX = -dirY * PLANE, plY = dirX * PLANE;
        boolean on = lampOn();
        double range = on ? 8.5 : 5.5, focus = on ? 0.45 : 0.2, focusRange = on ? 11 : 8;   // the flashlight lights farther and brighter

        for (int c = 0; c < COLS; c++) {                           // walls: one ray per column
            double cam = 2.0 * (c + 0.5) / COLS - 1;
            double rdx = dirX + plX * cam, rdy = dirY + plY * cam;
            int mapX = (int) px, mapY = (int) py;
            double ddx = Math.abs(1 / rdx), ddy = Math.abs(1 / rdy), sdx, sdy;
            int stepX, stepY;
            if (rdx < 0) { stepX = -1; sdx = (px - mapX) * ddx; } else { stepX = 1; sdx = (mapX + 1 - px) * ddx; }
            if (rdy < 0) { stepY = -1; sdy = (py - mapY) * ddy; } else { stepY = 1; sdy = (mapY + 1 - py) * ddy; }
            boolean side = false;
            while (map[mapY][mapX] == 0) {                         // walk the grid until a wall is hit
                if (sdx < sdy) { sdx += ddx; mapX += stepX; side = false; }
                else { sdy += ddy; mapY += stepY; side = true; }
            }
            double dist = Math.max(0.05, side ? sdy - ddy : sdx - ddx);
            zbuf[c] = dist;
            double wallX = (side ? px + dist * rdx : py + dist * rdy);
            wallX -= Math.floor(wallX);
            double b = (on ? 1.1 : 0.85) * Math.max(0, 1 - dist / range) + (1 - Math.abs(cam)) * focus * Math.max(0, 1 - dist / focusRange);
            b *= light * (side ? 0.72 : 1) * ((int) (wallX * 8) % 4 == 0 ? 0.85 : 1);   // side shade, panel lines
            int lh = (int) (H / dist), y0 = Math.max(0, H / 2 - lh / 2), y1 = Math.min(H, H / 2 + lh / 2);
            rect(g, c * CW, y0, CW, y1 - y0, shade(0xB8A850, b));
        }

        List<double[]> things = new ArrayList<>();                 // sprites, far ones first
        for (int i = 0; i < KEYS; i++) if (!got[i]) things.add(new double[]{sq(kx[i] - px) + sq(ky[i] - py), kx[i], ky[i], 0});
        for (int i = 0; i < BATT; i++) if (!bgot[i]) things.add(new double[]{sq(bx[i] - px) + sq(by[i] - py), bx[i], by[i], 3});
        for (int i = 0; i < FAKES; i++) {                          // a false key shimmers: it blinks now and then
            if (!fgone[i] && (ticks / 4 + i * 3) % 9 != 0) things.add(new double[]{sq(fx[i] - px) + sq(fy[i] - py), fx[i], fy[i], 0});
        }
        for (int i = 0; i < WARD; i++) things.add(new double[]{sq(wx[i] - px) + sq(wy[i] - py), wx[i], wy[i], 4});
        if (gT > 0 && (ticks / 3) % 3 != 0) things.add(new double[]{sq(gx - px) + sq(gy - py), gx, gy, 5});
        things.add(new double[]{sq(N - 1.5 - px) + sq(N - 1.5 - py), N - 1.5, N - 1.5, 1});
        if (awake) things.add(new double[]{sq(ex - px) + sq(ey - py), ex, ey, 2});
        things.sort((a, b) -> Double.compare(b[0], a[0]));
        for (double[] s : things) {
            switch ((int) s[3]) {
                case 0 -> sprite(g, s[1], s[2], KEY, 0.28, 0.06 + Math.sin(ticks / 12.0) * 0.03, 0.6, 9);
                case 1 -> sprite(g, s[1], s[2], DOOR, 0.9, 0, 0.45, 9);
                case 3 -> sprite(g, s[1], s[2], BAT, 0.24, 0.05 + Math.sin(ticks / 10.0) * 0.02, 0.6, 9);
                case 4 -> sprite(g, s[1], s[2], CLOSET, 0.95, 0, 0.3, 8);
                case 5 -> sprite(g, s[1], s[2], MONSTER, 0.85, 0, 0.45, 8);   // an apparition
                default -> sprite(g, s[1], s[2], MONSTER, 0.85, 0, 0, 6);
            }
        }
        g.pose().popPose();

        double md = md0;
        if (md < 3 && awake) {                                     // it is close: red edges and static
            rect(g, 0, 0, W, H, ((int) ((3 - md) / 3 * 80) << 24) | 0x900000);
            for (int k = 0; k < 6; k++) rect(g, rnd.nextInt(W), rnd.nextInt(H), 40, 1, 0x40FFFFFF);
        }
        for (int i = 0; i < 4; i++) {                              // dark vignette
            int a = (0x70 - i * 0x1C) << 24;
            rect(g, i * 6, 0, 6, H, a);
            rect(g, W - 6 - i * 6, 0, 6, H, a);
        }
        if (hidden) {                                              // you look out through the slits of the closet door
            int s1 = W / 2 - 26, s2 = W / 2 + 20;
            rect(g, 0, 0, W, 34, 0xFF120A06);
            rect(g, 0, H - 34, W, 34, 0xFF120A06);
            rect(g, 0, 34, s1, H - 68, 0xFF120A06);
            rect(g, s1 + 6, 34, s2 - s1 - 6, H - 68, 0xFF120A06);
            rect(g, s2 + 6, 34, W - s2 - 6, H - 68, 0xFF120A06);
            for (int y = 40; y < H - 36; y += 14) rect(g, 0, y, W, 1, 0x30FFFFFF);
        }
        minimap(g);
        // the flashlight and its battery (F)
        rect(g, 6, 6, 34, 9, 0xAA000000);
        rect(g, 7, 7, 32, 7, 0xFF1A1A22);
        rect(g, 7, 7, (int) Math.round(32 * battery), 7, battery > 0.5 ? 0xFF5BD97A : battery > 0.2 ? 0xFFFFD84A : 0xFFFF4A4A);
        text(g, "F", 43, 7, lamp && battery > 0 ? 0xFFFFE9A0 : 0xFF8A7A60);
        if (msgT > 0) ctext(g, Component.translatable(msg).getString(), W / 2, H - 14, msgT < 30 ? 0xFF9A8A60 : 0xFFFFE9A0);
        else if (hidden) ctext(g, Component.translatable("cutemod.maze.unhide").getString(), W / 2, H - 14, 0xFFC9B07A);
        else if (hideCd == 0 && nearCloset() >= 0) ctext(g, Component.translatable("cutemod.maze.hide").getString(), W / 2, H - 14, 0xFFC9B07A);
        if (won) rect(g, 0, 0, W, H, 0x40FFFFFF);
    }

    private static double sq(double v) { return v * v; }

    /** A billboard: a tiny picture that always faces you. Columns behind walls are skipped. */
    private void sprite(GuiGraphics g, double sx, double sy, String[] bmp, double size, double lift, double minB, double range) {
        double rx = sx - px, ry = sy - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);          // how far in front of us
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);         // how far to the right
        if (f < 0.15) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f), sh = (int) (full * size), sw = sh * bmp[0].length() / bmp.length;
        int left = (int) (W / 2.0 * (1 + cam)) - sw / 2, top = H / 2 + full / 2 - sh - (int) (full * lift);
        double b = (Math.max(minB, 1 - f / range) + (Math.abs(cam) < 0.35 ? 0.25 : 0)) * light;
        if (b <= 0.02) return;
        boolean open = keys == KEYS;
        for (int x = Math.floorDiv(left, CW) * CW; x < left + sw; x += CW) {
            int c = x / CW;
            if (x < 0 || c >= COLS || f >= zbuf[c]) continue;
            int u = Math.max(0, Math.min(bmp[0].length() - 1, (x + CW / 2 - left) * bmp[0].length() / sw));
            for (int row = 0; row < bmp.length; row++) {
                char ch = bmp[row].charAt(u);
                if (ch == '.') continue;
                int y0 = top + row * sh / bmp.length, y1 = Math.max(y0 + 1, top + (row + 1) * sh / bmp.length);
                rect(g, x, y0, CW, y1 - y0, shade(pal(ch, open), b));
            }
        }
    }

    /** Top-right: only the places you have already been to. */
    private void minimap(GuiGraphics g) {
        int s = 3, x0 = W - N * s - 6, y0 = 6;
        rect(g, x0 - 2, y0 - 2, N * s + 4, N * s + 4, 0x99000000);
        for (int y = 0; y < N; y++) for (int x = 0; x < N; x++) {
            if (!seen[y][x]) continue;
            rect(g, x0 + x * s, y0 + y * s, s, s, map[y][x] == 1 ? 0xFF5A5A6A : 0xFF24242E);
        }
        if (seen[N - 2][N - 2]) rect(g, x0 + (N - 2) * s, y0 + (N - 2) * s, s, s, keys == KEYS ? 0xFF3CFF7A : 0xFFFF4A4A);
        for (int i = 0; i < WARD; i++) if (seen[(int) wy[i]][(int) wx[i]]) rect(g, x0 + (int) wx[i] * s, y0 + (int) wy[i] * s, s, s, 0xFFA0703A);   // closets
        rect(g, x0 + (int) (px * s) - 1, y0 + (int) (py * s) - 1, 2, 2, 0xFFFFFFFF);
        rect(g, x0 + (int) ((px + Math.cos(ang) * 1.2) * s), y0 + (int) ((py + Math.sin(ang) * 1.2) * s), 1, 1, 0xFFFFD866);
    }

    /** You were caught. (The "Game over" box of the computer is drawn on top of the middle.) */
    private void jumpScare(GuiGraphics g) {
        rect(g, 0, 0, W, H, (System.currentTimeMillis() / 80) % 2 == 0 ? 0xFF200000 : 0xFF000000);
        rect(g, 50, 6, 120, 128, 0xFFE8E4EC);
        rect(g, 62, 14, 40, 28, 0xFF000000);
        rect(g, 118, 14, 40, 28, 0xFF000000);
        rect(g, 76, 22, 12, 12, 0xFFFF2A2A);
        rect(g, 132, 22, 12, 12, 0xFFFF2A2A);
        rect(g, 70, 98, 80, 30, 0xFF000000);
        for (int k = 0; k < 8; k++) {
            rect(g, 72 + k * 10, 98, 5, 8, 0xFFE8E4EC);
            rect(g, 77 + k * 10, 120, 5, 8, 0xFFE8E4EC);
        }
    }

    @Override
    public boolean key(int keyCode) {
        if (over) return false;
        if (keyCode == 70) {                                       // F: the flashlight
            if (hidden) return true;
            if (battery <= 0) { say("cutemod.maze.dead"); beep(); return true; }
            lamp = !lamp;
            pling(lamp ? 1.6F : 1.0F);
            return true;
        }
        if (keyCode == 69) { toggleHide(); return true; }          // E: a closet
        return false;
    }

    @Override
    public String hintKey() { return "cutemod.hint.maze"; }

    @Override
    public Component status() { return Component.translatable("cutemod.maze.status", keys, KEYS, Math.round(battery * 100) + "%"); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return Component.translatable(won ? "cutemod.maze.win" : "cutemod.ui.gameover");
    }
}
