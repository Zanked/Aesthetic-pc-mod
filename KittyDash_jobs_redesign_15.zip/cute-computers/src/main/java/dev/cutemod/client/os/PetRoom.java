package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/** The furniture shop of the pet's room: five places (tabs), a card for every piece. Buy it, then place or remove it. */
final class PetRoom {
    private static final int W = App.W, H = App.H, HEAD = 17;
    private static final int CARD_X = 6, CARD_Y = 24, CARD_W = 54, CARD_GAP = 2, CARD_H = 134;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;

    private final Runnable back;
    private int zone, ticks;

    PetRoom(Runnable back) { this.back = back; }

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    void tick() { ticks++; }

    private static int tabX(int z) { return 52 + z * 48; }

    private static boolean overButton(int mx, int my, int i) {
        int x = CARD_X + i * (CARD_W + CARD_GAP);
        return App.in(mx, my, x + 2, CARD_Y + CARD_H - 18, CARD_W - 4, 14);
    }

    void render(GuiGraphics g, int mx, int my) {
        Font f = net.minecraft.client.Minecraft.getInstance().font;
        Skin.rect(g, 0, 0, W, H, 0xFFF6F0FA);
        Skin.rect(g, 0, 0, W, HEAD, 0xFF5A4A86);
        boolean bh = App.in(mx, my, 3, 3, 44, 12);
        Skin.rect(g, 3, 3, 44, 12, bh ? 0xFFFFFFFF : 0xE0F6F0FA);
        Skin.str(g, f, "< " + t("cutemod.trip.back_btn"), 7, 5, TEXT, false);
        for (int z = 0; z < Furniture.ZONES; z++) {
            boolean on = z == zone, hov = App.in(mx, my, tabX(z), 2, 46, 13);
            Skin.rect(g, tabX(z), 2, 46, 13, on ? 0xFFF6F0FA : hov ? 0xFF8A6AC6 : 0xFF6E5CA0);
            String s = t("cutemod.room.zone." + z);
            Skin.str(g, f, s, tabX(z) + (46 - f.width(s)) / 2, 5, on ? TEXT : 0xFFFFFFFF, false);
        }

        List<Furniture.Item> items = Furniture.zone(zone);
        for (int i = 0; i < items.size(); i++) {
            Furniture.Item it = items.get(i);
            int x = CARD_X + i * (CARD_W + CARD_GAP);
            boolean own = Progress.owned(it.id()), placed = Furniture.isPlaced(zone, i);
            Skin.rect(g, x, CARD_Y, CARD_W, CARD_H, placed ? ACCENT : 0xFFE9DDF2);
            Skin.rect(g, x + 1, CARD_Y + 1, CARD_W - 2, CARD_H - 2, 0xFFFFFFFF);
            // the picture, on a little wall / floor
            Skin.rect(g, x + 2, CARD_Y + 2, CARD_W - 4, 60, 0xFFF3ECF8);
            Skin.rect(g, x + 2, CARD_Y + 50, CARD_W - 4, 12, 0xFFE3D2B4);
            float s = Math.min(1f, Math.min(48f / it.w(), 56f / it.h()));
            int cx = x + CARD_W / 2, cy = zone >= 3 ? CARD_Y + 56 : zone == 0 ? CARD_Y + 54 : CARD_Y + 30;
            g.pose().pushPose();
            g.pose().translate(cx, cy, 0);
            g.pose().scale(s, s, 1f);
            Furniture.draw(g, it.id(), 0, 0, ticks);
            g.pose().popPose();
            // the name (up to 2 lines)
            List<FormattedCharSequence> nm = f.split(FormattedText.of(t("cutemod.shop.item." + it.id())), CARD_W - 4);
            for (int k = 0; k < Math.min(2, nm.size()); k++) {
                Skin.str(g, f, nm.get(k), x + 3, CARD_Y + 66 + k * 10, TEXT, false);
            }
            String note = own ? (placed ? t("cutemod.room.here") : t("cutemod.room.owned")) : "";
            if (!note.isEmpty()) Skin.str(g, f, note, x + 3, CARD_Y + 88, MUTED, false);
            // the button
            boolean afford = own || Progress.coins() >= it.price();
            boolean hov = afford && overButton(mx, my, i);
            int bc = !afford ? 0xFFD8CCE2 : placed ? (hov ? 0xFFFFC2C2 : 0xFFF5B0B0) : own ? (hov ? 0xFFD8F5D0 : 0xFFC4EDB8) : (hov ? 0xFFFFD866 : 0xFFFFC832);
            Skin.rect(g, x + 2, CARD_Y + CARD_H - 18, CARD_W - 4, 14, bc);
            if (own) {
                String s2 = t(placed ? "cutemod.room.remove" : "cutemod.room.place");
                Skin.str(g, f, s2, x + (CARD_W - f.width(s2)) / 2, CARD_Y + CARD_H - 15, TEXT, false);
            } else {
                String p = Integer.toString(it.price());
                int w = f.width(p) + 9;
                Skin.str(g, f, p, x + (CARD_W - w) / 2, CARD_Y + CARD_H - 15, afford ? TEXT : 0xFFFFFFFF, false);
                Progress.drawCoin(g, x + (CARD_W - w) / 2 + f.width(p) + 2, CARD_Y + CARD_H - 15);
            }
        }
    }

    boolean click(int mx, int my, int button) {
        if (App.in(mx, my, 3, 3, 44, 12)) { back.run(); return true; }
        for (int z = 0; z < Furniture.ZONES; z++) {
            if (App.in(mx, my, tabX(z), 2, 46, 13)) { zone = z; return true; }
        }
        List<Furniture.Item> items = Furniture.zone(zone);
        for (int i = 0; i < items.size(); i++) {
            if (!overButton(mx, my, i)) continue;
            Furniture.Item it = items.get(i);
            if (!Progress.owned(it.id()) && !Progress.buy(it.id(), it.price())) return true;
            Progress.setCount("room_" + zone, Furniture.isPlaced(zone, i) ? 0 : i + 1);
            return true;
        }
        return true;
    }

    boolean scroll(double amount) { return true; }

    boolean key(int keyCode) {
        if (keyCode == 256) { back.run(); return true; }
        return false;
    }
}
