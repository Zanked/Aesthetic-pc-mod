package dev.cutemod.client.game;

import dev.cutemod.net.DashActionPayload;
import dev.cutemod.net.DashSyncPayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** The client side of online Kitty Dash: what the server last told us, and the messages we send to it. */
public final class DashNet {
    private DashNet() {}

    /** Free players, the invitations, and the race we are in (opponent is empty if there is none). */
    public static List<String> players = new ArrayList<>();
    public static String invitedBy = "", invitedTo = "", opponent = "";
    public static boolean youFirst = true, oppDone;
    /** The track seed of the race, how it stands (0 running, 1 first won, 2 second won, 3 draw) and the opponent's last report. */
    public static int seed, result, oppScore, oppDist, oppLane = 100, oppFlags, oppFinal;
    /** Goes up with every new race, so the game knows when to start one. */
    public static int matchNo;
    /** Attacks that arrived and have not been applied yet (kind 1 barrier, 2 goo). */
    public static final ArrayDeque<Integer> attacks = new ArrayDeque<>();
    /** Goes up with every message from the server. */
    public static int version;
    private static int notice, lastAtkSeq;
    private static long ignoreUntil;       // right after we left a race, an old message must not bring it back

    public static void apply(DashSyncPayload p) {
        if (p.lobby()) {
            players = new ArrayList<>(p.players());
            invitedBy = p.invitedBy();
            invitedTo = p.invitedTo();
        }
        boolean ignore = System.currentTimeMillis() < ignoreUntil;
        String opp = ignore ? "" : p.opponent();
        if (!opp.isEmpty() && (!opp.equals(opponent) || p.seed() != seed)) {            // another race
            attacks.clear();
            lastAtkSeq = p.atkSeq();
            matchNo++;
        } else if (!opp.isEmpty() && p.atkSeq() != lastAtkSeq) {
            attacks.add(p.atkKind());
            lastAtkSeq = p.atkSeq();
        }
        opponent = opp;
        youFirst = p.youFirst();
        seed = p.seed();
        result = ignore ? 0 : p.result();
        oppScore = p.oppScore();
        oppDist = p.oppDist();
        oppLane = p.oppLane();
        oppFlags = p.oppFlags();
        oppDone = p.oppDone();
        oppFinal = p.oppFinal();
        if (p.notice() != 0) notice = p.notice();
        version++;
    }

    public static void clear() {
        players = new ArrayList<>();
        invitedBy = invitedTo = opponent = "";
        result = 0;
        notice = 0;
        attacks.clear();
        lastAtkSeq = 0;
        ignoreUntil = 0;
        version++;
    }

    public static boolean inMatch() { return !opponent.isEmpty(); }

    /** 1 you won, 2 you lost, 3 draw, 0 still running. */
    public static int myResult() {
        if (result == 0 || result == 3) return result;
        return (result == 1) == youFirst ? 1 : 2;
    }

    /** The last notice (declined, busy, ...), only once. */
    public static int takeNotice() {
        int n = notice;
        notice = 0;
        return n;
    }

    private static void send(int action, String name, int a, int b, int c, int d) {
        PacketDistributor.sendToServer(new DashActionPayload(action, name, a, b, c, d));
    }

    public static void request() { send(0, "", 0, 0, 0, 0); }

    public static void invite(String name) { send(1, name, 0, 0, 0, 0); }

    public static void accept(String name) { send(2, name, 0, 0, 0, 0); }

    public static void decline(String name) { send(3, name, 0, 0, 0, 0); }

    public static void cancelInvite() { send(6, "", 0, 0, 0, 0); }

    public static void progress(int score, int dist, int lane100, int flags) { send(4, "", score, dist, lane100, flags); }

    public static void attack(int kind) { send(7, "", kind, 0, 0, 0); }

    public static void finish(int score) { send(8, "", score, 0, 0, 0); }

    /** Give up, or leave a finished race. We forget the race at once, the server confirms later. */
    public static void leaveGame() {
        send(5, "", 0, 0, 0, 0);
        ignoreUntil = System.currentTimeMillis() + 1500;
        opponent = "";
        result = 0;
        oppDone = false;
        attacks.clear();
        version++;
    }
}
