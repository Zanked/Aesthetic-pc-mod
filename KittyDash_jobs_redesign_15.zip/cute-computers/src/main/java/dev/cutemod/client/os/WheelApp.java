package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.util.Random;

/**
 * Lucky Wheel: one spin every 4 hours, free, and there is always a prize (no bets). Eight sectors: coins and treats
 * for the pet. The result is drawn first and the wheel just turns to it. Saved as "wheel" (the time of the last spin).
 */
public class WheelApp extends KitApp {
    private static final int SECTORS = 8, R = 52, CX = 92, CY = 84, COOLDOWN_S = 4 * 3600;
    // kind 0 coins n, kind 1 treat; weights add up to 100
    private static final int[][] PRIZE = {{0, 5, 24}, {1, 0, 12}, {0, 10, 20}, {0, 3, 16}, {0, 15, 12}, {1, 1, 8}, {0, 8, 6}, {0, 30, 2}};
    private static final String[] TREAT = {"treat_cookie", "treat_honey"};
    private static final int[] COL = {0xFFFFB6C8, 0xFFFFE08A, 0xFFB8E0A8, 0xFFA8D8F0, 0xFFD8B8F0, 0xFFFFC8A0, 0xFFA8E8D8, 0xFFFFD84A};

    private final Random rnd = new Random();
    private double angle, speed;                 // radians; the pointer is at the top
    private double target;
    private boolean spinning;
    private int result = -1;

    @Override protected int accent() { return 0xFFFF9A4A; }

    @Override protected String id() { return "wheel"; }

    private long last() {
        try { String s = Store.read("wheel"); return s == null ? 0 : Long.parseLong(s.trim()); } catch (NumberFormatException e) { return 0; }
    }

    private static long now() { return System.currentTimeMillis() / 1000; }

    private long waitS() { return Math.max(0, last() + COOLDOWN_S - now()); }

    private void spin() {
        if (spinning) return;
        if (waitS() > 0) { say("cutemod.wheel.msg.wait"); return; }
        int roll = rnd.nextInt(100), acc = 0;
        result = 0;
        for (int i = 0; i < SECTORS; i++) { acc += PRIZE[i][2]; if (roll < acc) { result = i; break; } }
        double sector = Math.PI * 2 / SECTORS;
        // the middle of sector `result` must end up under the pointer (top = -pi/2), after a few full turns
        double want = Math.PI * 1.5 - (result + 0.5) * sector;
        double turns = Math.PI * 2 * (4 + rnd.nextInt(2));
        double cur = angle % (Math.PI * 2);
        target = angle - cur + turns + (want % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) + (rnd.nextDouble() - 0.5) * sector * 0.6;
        spinning = true;
        Store.write("wheel", Long.toString(now()));
    }

    @Override
    public void tick() {
        super.tick();
        if (!spinning) return;
        double left = target - angle;
        double v = Math.max(0.004, left * 0.02);
        angle += Math.min(v, left);
        if ((int) (angle * SECTORS / (Math.PI * 2)) != (int) ((angle - v) * SECTORS / (Math.PI * 2)))
            Sfx.ui(SoundEvents.NOTE_BLOCK_HAT.value(), 1.6F, 0.3F);
        if (target - angle < 0.002) { spinning = false; angle = target; award(); }
    }

    private void award() {
        int[] p = PRIZE[result];
        if (p[0] == 0) { Progress.earn(p[1]); say("cutemod.wheel.msg.coins", p[1]); }
        else { Progress.giveTreat(TREAT[p[1]], 2); say("cutemod.wheel.msg.treat", t("cutemod.shop.item." + TREAT[p[1]])); }
        Season.add(8);
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.7F);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        header(g, f);
        wheel(g, f);
        // the pointer
        for (int d = 0; d < 9; d++) rect(g, CX - 5 + d / 2, CY - R - 10 + d, 10 - d, 1, 0xFFE5486F);
        disc(g, CX, CY, 7, 0xFFFFFFFF); disc(g, CX, CY, 4, 0xFFFF9A4A);
        long w = waitS();
        center(g, f, t("cutemod.wheel.title"), 220, 26, TEXT);
        if (w > 0 && !spinning) {
            center(g, f, t("cutemod.wheel.next"), 220, 50, MUTED);
            center(g, f, String.format("%d:%02d:%02d", w / 3600, w / 60 % 60, w % 60), 220, 62, TEXT);
        } else if (!spinning) center(g, f, t("cutemod.wheel.ready"), 220, 56, 0xFF4FAE5E);
        btn(g, f, mx, my, 170, 90, 100, spinning ? t("cutemod.wheel.spinning") : t("cutemod.wheel.spin"), w == 0 && !spinning ? 1 : 2);
        footer(g, f);
    }

    /** The wheel: each pixel row is cut into runs of one sector color. */
    private void wheel(GuiGraphics g, Font f) {
        double sector = Math.PI * 2 / SECTORS;
        for (int dy = -R; dy <= R; dy++) {
            int half = (int) Math.floor(Math.sqrt(R * R - dy * dy));
            int runStart = -half, runCol = -1;
            for (int dx = -half; dx <= half + 1; dx++) {
                int col;
                if (dx > half) col = -2;
                else {
                    double a = Math.atan2(dy, dx) - angle;
                    a = ((a % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
                    double ar = Math.hypot(dx, dy);
                    col = ar > R - 2 ? 8 : (int) (a / sector) % SECTORS;
                }
                if (col != runCol) {
                    if (runCol >= 0) rect(g, CX + runStart, CY + dy, dx - runStart, 1, runCol == 8 ? 0xFFFFFFFF : COL[runCol]);
                    runStart = dx;
                    runCol = col;
                }
            }
        }
        for (int i = 0; i < SECTORS; i++) {                     // the prize of each sector, in the middle of it
            double a = (i + 0.5) * sector + angle;
            int px = CX + (int) Math.round(Math.cos(a) * R * 0.66), py = CY + (int) Math.round(Math.sin(a) * R * 0.66);
            int[] p = PRIZE[i];
            if (p[0] == 0) center(g, f, "+" + p[1], px, py - 3, TEXT);
            else if (p[1] == 0) { disc(g, px, py, 4, 0xFFD08A5A); rect(g, px - 1, py - 1, 2, 2, 0xFF6A4228); }
            else { rect(g, px - 3, py - 4, 6, 8, 0xFFE8A817); rect(g, px - 2, py - 5, 4, 2, 0xFFB07A10); }
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (in(x, y, 170, 90, 100, 16)) { spin(); return true; }
        return false;
    }
}
