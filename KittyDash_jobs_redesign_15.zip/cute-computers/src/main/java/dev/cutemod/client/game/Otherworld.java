package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import dev.cutemod.client.os.Progress;
import net.minecraft.network.chat.Component;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * First-person horror with TWO WORLDS on one map. You start in the crimson Otherworld (rusty maze, flesh, a siren, and a
 * faceless warden that hunts you). Press SPACE to cross into the quiet living world (grey-green stone). The two worlds
 * have different walls: a wall in one may be a corridor in the other, so you can cut through the maze by crossing, and
 * you can lose the warden by crossing, but only if the place you stand on is open in the other world too.
 * Find 3 seals (each one lies in a certain world, the other world shows only a faint echo of it), then reach the gate,
 * which is in the living world. The living world is safe but it does not hold you: your grip slips and after about
 * 20 seconds you are pulled back into the Otherworld.
 */
public class Otherworld extends MiniGame {
    private static final int N = 15, SEALS = 3;          // the house is N x N tiles (walls included)
    private static final int GRIP_MAX = 1200, FLIP_CD = 45; // ticks in the living world before you are pulled back, and the pause between two crossings
    private static final int COLS = 110, CW = W / COLS;  // one ray per 2 px
    private static final double PLANE = 0.75;            // field of view (bigger = wider)

    // tiny sprites: one char = one pixel (see pal())
    private static final String[] SEAL = {      // a ring with a cross: the seal
            "..rrrr..", ".r.pp.r.", "r..pp..r", "rppppppr", "r..pp..r", "r..pp..r", ".r.pp.r.", "..rrrr.."};
    private static final String[] GATE = {      // an iron gate: dark bars, and a glow in the gaps (brighter once it can be opened)
            "bbbbbb", "bgbbgb", "bgbbgb", "bgbbgb", "bbbbbb", "bgbbgb", "bgbbgb", "bgpbgb", "bgbbgb", "bbbbbb", "bgbbgb", "bgbbgb"};
    private static final String[] DOLL = {       // a cracked porcelain doll with a red bow
            "..rkkr..", ".kkkkkk.", ".kppppk.", ".kpkkpk.", ".kppdpk.", ".kpkkpk.", "..pppp..", "..rrrr..",
            ".rddddr.", "pdddddrp", "p.dddd.p", "p.dddd.p", "..dddd..", ".dddddd.", "..p..p..", "..p..p.."};
    private static final String[] MASTER = {     // the stationmaster: a red cap, a pale face, a long dark coat with brass buttons
            "..rrrr..", ".rrrrrr.", ".kkkkkk.", ".kppppk.", ".kpkkpk.", ".kppppk.", "..pppp..", "..yyyy..",
            ".dddddd.", "pdyddydp", "p.dddd.p", "p.dyyd.p", "..dddd..", ".dddddd.", "..k..k..", "..k..k.."};
    private static final String[] LEVER = {      // a signal lever with a red knob
            "..rr..", "..rr..", "...m..", "...m..", "...m..", "..mm..", ".mmmm.", "mmmmmm"};
    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    // ---------- level 2: the station ----------
    private static final int TRAIN_LEN = 4, WARN = 180;       // a train is 4 tiles long; the horn sounds 3 seconds before it enters
    private static final int[] TRACK = {5, 7};                // the row of the rails: in the living world and in the Otherworld
    private static final double[] LEVER_X = {3.5, 11.5}, LEVER_Y = {6.5, 6.5};     // on the strip between the rails

    private final int[][] mapA = new int[N][N], mapB = new int[N][N];   // 1 = wall. A = the living world, B = the Otherworld
    private int[][] map = mapB;                         // the world you are in now
    private int world = 1;                              // 0 = living world, 1 = Otherworld
    private final boolean[][][] seen = new boolean[2][N][N]; // for the little map, one per world
    private final int[] sealWorld = new int[SEALS];     // the world each seal lies in
    private final double[] zbuf = new double[COLS];     // wall distance per column (hides sprites behind walls)
    private final double[] sx = new double[SEALS], sy = new double[SEALS];
    private final boolean[] got = new boolean[SEALS];

    private double px, py, ang, ex, ey, tx, ty, light;
    private int ox, oy;                                 // where the warden last heard you
    private double grip = GRIP_MAX;
    private int seals, ticks, msgT, flipCd, flashT;
    private boolean won, awake;
    private String msg = "";

    private int level = 1;                              // 1 = the house, 2 = the station
    private boolean choosing, squashed;                 // the level menu is on screen / a train ran you over
    private int dollBack;                               // ticks until the doll comes back after a train crushed it
    private final Hunter master = new Hunter();         // the stationmaster (level 2 only)
    private final double[] tpos = {Double.NaN, Double.NaN};   // per world: the x of the left end of the train (NaN: no train now)
    private final int[] tdir = new int[2], tnext = new int[2], holdT = new int[2], leverCd = new int[2];

    @Override
    public void reset() {
        level = 1;
        choosing = Progress.count("ow_win1") > 0;           // once the house is beaten, the station is open
        startLevel();
    }

    private void startLevel() {
        score = 0; over = false; won = false; awake = false; ex = ey = tx = ty = -100; seals = 0; ticks = 0; msgT = 0; light = 1;
        world = 1; map = mapB; grip = GRIP_MAX; flipCd = 0; flashT = 0;
        squashed = false; dollBack = 0;
        master.reset();
        Arrays.fill(got, false);
        for (boolean[][] w : seen) for (boolean[] r : w) Arrays.fill(r, false);
        for (int w = 0; w < 2; w++) {                       // the first trains come after 10 and 15 seconds
            tpos[w] = Double.NaN;
            tnext[w] = w == 0 ? 600 : 900;
            tdir[w] = rnd.nextBoolean() ? 1 : -1;
            holdT[w] = 0;
            leverCd[w] = 0;
        }
        build();
        px = 1.5; py = 1.5;
        ox = 1; oy = 1;
        ang = map[1][2] == 0 ? 0 : Math.PI / 2;
        say(level == 2 ? "cutemod.otherworld.start2" : "cutemod.otherworld.start");
    }

    // Furniture (x, y) of the two worlds. Never on a cell centre (odd, odd), because you cross between the worlds there.
    private static final int[][] FURNITURE_A = {{2, 4}, {4, 2}, {8, 2}, {10, 2}, {12, 2}, {9, 4}, {11, 4}, {2, 8}, {4, 8}, {2, 12},
            {8, 8}, {8, 12}, {12, 8}, {12, 10}};
    private static final int[][] FURNITURE_B = {{2, 2}, {4, 4}, {8, 4}, {10, 4}, {12, 4}, {9, 2}, {11, 2}, {2, 10}, {4, 10}, {4, 12},
            {8, 10}, {10, 8}, {12, 12}, {12, 8}};

    /**
     * The house: four rooms (hall top left, library top right, kitchen bottom left, bedroom bottom right).
     * The doors and the furniture are different in the two worlds: in the living world you go hall - library - bedroom,
     * in the Otherworld hall - kitchen - bedroom, so you have to cross between the worlds to visit every room.
     */
    private void house(int[][] m, boolean other) {
        for (int[] r : m) Arrays.fill(r, 0);
        for (int i = 0; i < N; i++) { m[0][i] = 1; m[N - 1][i] = 1; m[i][0] = 1; m[i][N - 1] = 1; }
        for (int i = 1; i < N - 1; i++) { m[6][i] = 1; m[i][6] = 1; }          // the walls between the rooms
        if (!other) { m[3][6] = 0; m[6][10] = 0; }                              // living world doors: hall-library, library-bedroom
        else { m[6][3] = 0; m[10][6] = 0; }                                     // Otherworld doors: hall-kitchen, kitchen-bedroom
        for (int[] t : other ? FURNITURE_B : FURNITURE_A) m[t[1]][t[0]] = 1;
    }

    // Level 2 furniture (never on a cell centre (odd, odd)). The benches on the strip between the rails block both safe rows of a
    // world at some columns, so you have to step onto the rails there.
    private static final int[][] ST_A = {{2, 2}, {4, 2}, {8, 2}, {12, 2}, {4, 6}, {4, 7}, {8, 6}, {8, 7}, {2, 10}, {4, 12}, {8, 10}, {12, 10}, {8, 12}, {12, 12}};
    private static final int[][] ST_B = {{2, 2}, {4, 2}, {10, 2}, {12, 2}, {6, 5}, {6, 6}, {10, 5}, {10, 6}, {2, 12}, {4, 10}, {10, 10}, {8, 12}, {10, 12}, {12, 12}};

    /**
     * The station. Walls are on even rows and columns (so every cell centre (odd, odd) is free in both worlds, as the engine needs).
     * Top: a hall (left) and an office (right), wall on row 4. Middle: the zone with the rails (rows 5-7): the train of the living
     * world runs on row 5, the train of the Otherworld on row 7, row 6 is the strip between them. Wall on row 8. Bottom: a platform
     * room (left) and a luggage room with the last carriage door (right).
     * Doors: living world hall - zone and zone - luggage room; Otherworld zone - office and zone - platform room.
     */
    private void station(int[][] m, boolean other) {
        for (int[] r : m) Arrays.fill(r, 0);
        for (int i = 0; i < N; i++) { m[0][i] = 1; m[N - 1][i] = 1; m[i][0] = 1; m[i][N - 1] = 1; }
        for (int i = 1; i < N - 1; i++) { m[4][i] = 1; m[8][i] = 1; }               // above and below the rails
        for (int y = 1; y < 4; y++) m[y][6] = 1;                                     // hall | office
        for (int y = 9; y < N - 1; y++) m[y][6] = 1;                                 // platform room | luggage room
        if (!other) { m[4][3] = 0; m[8][11] = 0; } else { m[4][11] = 0; m[8][3] = 0; }
        for (int[] t : other ? ST_B : ST_A) m[t[1]][t[0]] = 1;
    }

    private void build() {
        if (level == 2) { station(mapA, false); station(mapB, true); } else { house(mapA, false); house(mapB, true); }
        // a seal in the library (living world), one in the kitchen (Otherworld) and one in the bedroom (either world)
        sealWorld[0] = 0;
        sealWorld[1] = 1;
        sealWorld[2] = rnd.nextInt(2);
        int[][] rooms = level == 2 ? new int[][]{{7, 9, 13, 13}, {7, 1, 13, 3}, {1, 9, 5, 13}}       // luggage room, office, platform room
                : new int[][]{{7, 1, 13, 5}, {1, 7, 5, 13}, {7, 7, 13, 13}};       // x0, y0, x1, y1 of the room of each seal
        for (int i = 0; i < SEALS; i++) {
            List<int[]> cells = new ArrayList<>();
            for (int y = rooms[i][1]; y <= rooms[i][3]; y += 2) for (int x = rooms[i][0]; x <= rooms[i][2]; x += 2) {
                if (!(x == N - 2 && y == N - 2) && !(level == 1 && i == 2 && x + y < 16)) cells.add(new int[]{x, y});   // not at the front door, nor at the doors of the bedroom
            }
            int[] c = cells.get(rnd.nextInt(cells.size()));
            sx[i] = c[0] + 0.5;
            sy[i] = c[1] + 0.5;
        }
    }

    /** After 10 seconds the doll wakes up, far away from you, in a room it can walk to in the Otherworld. */
    private void spawn() {
        growl(G_ROAR);
        boolean[][] reach = reachable();
        List<int[]> far = new ArrayList<>(), any = new ArrayList<>();
        for (int y = 1; y < N - 1; y += 2) for (int x = 1; x < N - 1; x += 2) {
            if (!reach[y][x]) continue;
            any.add(new int[]{x, y});
            if (Math.abs(x - (int) px) + Math.abs(y - (int) py) >= 10) far.add(new int[]{x, y});
        }
        List<int[]> pool = far.isEmpty() ? any : far;
        int[] m = pool.get(rnd.nextInt(pool.size()));
        ex = tx = m[0] + 0.5;
        ey = ty = m[1] + 0.5;
        ox = (int) px;
        oy = (int) py;
        awake = true;
        say("cutemod.otherworld.wake");
        pling(0.5F);
    }

    private void say(String key) { msg = key; msgT = 150; }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    @Override
    public boolean key(int keyCode) {
        if (choosing) {
            if (keyCode == 49 || keyCode == 50) { pick(keyCode - 48); return true; }
            return false;
        }
        if (keyCode == KEY_SPACE) { cross(false); return true; }
        if (keyCode == 69 && level == 2) { lever(); return true; }                 // E
        return false;
    }

    private void pick(int lvl) {
        level = lvl;
        choosing = false;
        startLevel();
        pling(lvl == 2 ? 1.4F : 1.0F);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (!choosing) return false;
        if (in(x, y, 20, 62, W - 40, 26)) { pick(1); return true; }
        if (in(x, y, 20, 94, W - 40, 26)) { pick(2); return true; }
        return true;
    }

    /** E near a signal lever: the next train of THIS world waits 15 seconds. The lever clanks through the whole building. */
    private void lever() {
        for (int i = 0; i < 2; i++) {
            if (Math.hypot(LEVER_X[i] - px, LEVER_Y[i] - py) > 0.9) continue;
            if (leverCd[i] > 0) { say("cutemod.otherworld.lever_wait"); return; }
            leverCd[i] = 2400;
            holdT[world] = 900;
            ox = (int) px; oy = (int) py;                                           // the doll and the stationmaster hear it
            master.hear();
            flashT = 8;
            say("cutemod.otherworld.lever");
            pling(0.4F); pling(1.2F);
            return;
        }
    }

    private static boolean open(int[][] m, double x, double y) {
        int ix = (int) x, iy = (int) y;
        return ix > 0 && iy > 0 && ix < N - 1 && iy < N - 1 && m[iy][ix] == 0;
    }

    /** Cross into the other world. It only works if you have room there (the spot is not inside a wall of that world). */
    private void cross(boolean forced) {
        int[][] other = world == 0 ? mapB : mapA;
        if (!forced) {
            if (flipCd > 0) return;
            double r = 0.25;
            if (!(open(other, px, py) && open(other, px + r, py + r) && open(other, px - r, py + r)
                    && open(other, px + r, py - r) && open(other, px - r, py - r))) {
                say("cutemod.otherworld.blocked");
                flipCd = 20;
                pling(0.6F);
                return;
            }
        } else {                                                   // the Otherworld pulls you back: you land in the middle of the cell
            if (other[(int) py | 1][(int) px | 1] != 0) return;    // a train stands there: the pull waits for it to pass
            px = ((int) px | 1) + 0.5;
            py = ((int) py | 1) + 0.5;
        }
        world ^= 1;
        map = world == 0 ? mapA : mapB;
        flipCd = FLIP_CD;
        flashT = 16;
        say(forced ? "cutemod.otherworld.pulled" : world == 0 ? "cutemod.otherworld.world.0" : "cutemod.otherworld.world.1");
        pling(world == 0 ? 1.7F : 0.5F);
        if (world == 1) { ox = (int) px; oy = (int) py; }          // the warden feels you come back
    }

    private void move(double dx, double dy) {
        double r = 0.22;
        if (map[(int) py][(int) (px + dx + Math.signum(dx) * r)] == 0) px += dx;
        if (map[(int) (py + dy + Math.signum(dy) * r)][(int) px] == 0) py += dy;
    }

    /** 0 most of the time; every 40 seconds a siren sounds for 5 seconds and this swells to 1 and back. */
    private double siren() {
        int p = ticks % 2400;
        return p < 2100 ? 0 : Math.sin((p - 2100) / 300.0 * Math.PI);
    }

    @Override
    public void tick() {
        if (choosing) return;
        ticks++;
        if (msgT > 0) msgT--;
        if (flipCd > 0) flipCd--;
        if (flashT > 0) flashT--;
        for (int i = 0; i < 2; i++) if (leverCd[i] > 0) leverCd[i]--;
        if (level == 2) {
            updateTrains();
            if (map[(int) py][(int) px] == 2) { squashed = true; over = true; pling(0.3F); beep(); return; }   // the train ran you over
        }
        double md = Math.hypot(ex - px, ey - py);
        light = world == 1 && ((md < 4 && ticks % 11 < 2) || ticks % 500 > 494) ? 0.4 : 1.0;   // the light of the Otherworld flickers
        if (ticks % 2400 == 2100 && world == 1) pling(0.5F);                       // the siren
        if (world == 0) { grip -= 1; if (grip <= 0) { grip = 0; cross(true); } }   // the living world does not hold you for long
        else if (grip < GRIP_MAX) grip = Math.min(GRIP_MAX, grip + 0.6);

        // walk: W/S or up/down, turn: A/D or left/right
        double turn = (down(68) || down(KEY_RIGHT) ? 1 : 0) - (down(65) || down(KEY_LEFT) ? 1 : 0);
        double walk = (down(87) || down(KEY_UP) ? 1 : 0) - (down(83) || down(KEY_DOWN) ? 1 : 0);
        ang += turn * 0.05;
        move(Math.cos(ang) * walk * 0.05, Math.sin(ang) * walk * 0.05);
        for (int dy = -2; dy <= 2; dy++) for (int dx = -2; dx <= 2; dx++) {   // little map: remember what we saw
            int cx = (int) px + dx, cy = (int) py + dy;
            if (cx >= 0 && cy >= 0 && cx < N && cy < N) seen[world][cy][cx] = true;
        }

        // it hears you every 2 s in the Otherworld (always, when close), but only every 10 s when you hide in the living world
        if (world == 1 ? (ticks % 120 == 0 || md < 3) : ticks % 600 == 0) { ox = (int) px; oy = (int) py; }
        double mdm = master.awake ? Math.hypot(master.x - px, master.y - py) : 1e9;
        if (world == 1 ? (ticks % 120 == 0 || mdm < 3) : ticks % 600 == 0) master.hear();
        if (ticks == 600 || (dollBack > 0 && --dollBack == 0)) spawn();
        if (level == 2 && ticks == 2100) master.spawn();                      // the stationmaster wakes after 35 seconds
        if (awake) chase();
        if (master.awake) master.chase(0.009 + 0.002 * seals + (world == 1 ? 0.004 * siren() : 0));
        if (level == 2) crush();
        md = Math.hypot(ex - px, ey - py);
        mdm = master.awake ? Math.hypot(master.x - px, master.y - py) : 1e9;
        if ((md < 0.55 || mdm < 0.55) && world == 1) { over = true; pling(0.5F); beep(); growl(G_SCREAM); return; }   // the warden cannot touch you in the living world
        md = Math.min(md, mdm);
        if (md < 7 && ticks % (int) (14 + md * 6) == 0) pling(world == 1 ? 0.5F : 0.3F);   // heartbeat, faster when it is close
        if (md < 6 && world == 1 && ticks % 100 == 0) growl(G_DEEP);                       // it growls when it is near

        for (int i = 0; i < SEALS; i++) {
            if (!got[i] && sealWorld[i] == world && Math.hypot(sx[i] - px, sy[i] - py) < 0.5) {
                got[i] = true;
                seals++;
                score += 100;
                pling(1.8F);
                say("cutemod.otherworld.seal");
            }
        }
        if (Math.hypot(N - 1.5 - px, N - 1.5 - py) < 0.8) {
            if (world == 1) { if (msgT == 0) say("cutemod.otherworld.gate_echo"); }     // the gate only opens in the living world
            else if (seals == SEALS) {
                won = true;
                over = true;
                score += level == 2 ? 700 + Math.max(0, 800 - ticks / 30) : 500 + Math.max(0, 600 - ticks / 30);      // faster = more points
                Progress.setCount(level == 2 ? "ow_win2" : "ow_win1", 1);                                           // level 1 opens the station
                pling(1.0F); pling(1.5F); pling(2.0F);
            } else if (msgT == 0) say("cutemod.otherworld.locked");
        }
    }

    // ---------- trains ----------
    /** A hunter does not know about trains: a train tile (2) is a free tile for him, so he can walk right under one. */
    private static boolean passable(int v) { return v == 0 || v == 2; }

    /** The tiles the hunters can walk to in the Otherworld, from the start tile of the level. */
    private boolean[][] reachable() {
        boolean[][] reach = new boolean[N][N];
        ArrayDeque<int[]> q = new ArrayDeque<>();
        int sy = level == 2 ? 5 : 1;
        reach[sy][1] = true;
        q.add(new int[]{1, sy});
        while (!q.isEmpty()) {
            int[] c = q.poll();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0], ny = c[1] + d[1];
                if (passable(mapB[ny][nx]) && !reach[ny][nx]) { reach[ny][nx] = true; q.add(new int[]{nx, ny}); }
            }
        }
        return reach;
    }

    /** Moves the train of each world (a train is a row of wall tiles with the value 2) and counts down to the next one. */
    private void updateTrains() {
        for (int w = 0; w < 2; w++) {
            int[][] m = w == 0 ? mapA : mapB;
            int row = TRACK[w];
            for (int x = 1; x < N - 1; x++) if (m[row][x] == 2) m[row][x] = 0;        // take the train off, put it back below
            if (holdT[w] > 0) holdT[w]--;
            if (Double.isNaN(tpos[w])) {
                if (holdT[w] > 0) continue;                                           // the signal is held: nothing starts
                if (--tnext[w] <= 0) {
                    tpos[w] = tdir[w] > 0 ? -TRAIN_LEN : N - 1;
                    if (w == world) pling(0.45F);
                } else if (tnext[w] == WARN && w == world) { pling(0.3F); pling(0.6F); say("cutemod.otherworld.train_warn"); }   // the horn
                continue;
            }
            tpos[w] += tdir[w] * (w == 0 ? 0.045 : 0.07);                             // the ghost train is faster
            int l = (int) Math.floor(tpos[w]);
            for (int k = 0; k < TRAIN_LEN; k++) {
                int x = l + k;
                if (x >= 1 && x <= N - 2) m[row][x] = 2;
            }
            if (tdir[w] > 0 ? tpos[w] >= N - 1 : tpos[w] <= -TRAIN_LEN) {             // it left through the other tunnel
                tpos[w] = Double.NaN;
                tnext[w] = (w == 0 ? 1080 : 840) + rnd.nextInt(w == 0 ? 300 : 240);
                tdir[w] = rnd.nextBoolean() ? 1 : -1;
            }
        }
    }

    /** A train that runs into a hunter crushes him: he is gone for 25 seconds. */
    private void crush() {
        if (awake && mapB[(int) ey][(int) ex] == 2) {
            awake = false; ex = ey = tx = ty = -100; dollBack = 1500; score += 50;
            say("cutemod.otherworld.crushed"); pling(0.35F); pling(0.9F);
        }
        if (master.awake && mapB[(int) master.y][(int) master.x] == 2) {
            master.awake = false; master.x = master.y = master.tx = master.ty = -100; master.back = 1500; score += 50;
            say("cutemod.otherworld.crushed"); pling(0.35F); pling(0.9F);
        }
        if (master.back > 0 && --master.back == 0) master.spawn();
    }

    /** The stationmaster: a second hunter of level 2. Same way of walking as the doll, a little slower, and he wakes later. */
    private final class Hunter {
        double x = -100, y = -100, tx = -100, ty = -100;
        int ox = 1, oy = 5, back;
        boolean awake;

        void reset() { x = y = tx = ty = -100; ox = 1; oy = 5; back = 0; awake = false; }

        void hear() { ox = (int) px; oy = (int) py; }

        void spawn() {
            boolean[][] reach = reachable();
            List<int[]> far = new ArrayList<>(), any = new ArrayList<>();
            for (int cy = 1; cy < N - 1; cy += 2) for (int cx = 1; cx < N - 1; cx += 2) {
                if (!reach[cy][cx]) continue;
                any.add(new int[]{cx, cy});
                if (Math.abs(cx - (int) px) + Math.abs(cy - (int) py) >= 10 && Math.hypot(cx + 0.5 - ex, cy + 0.5 - ey) > 5) far.add(new int[]{cx, cy});
            }
            List<int[]> pool = far.isEmpty() ? any : far;
            int[] m = pool.get(rnd.nextInt(pool.size()));
            x = tx = m[0] + 0.5;
            y = ty = m[1] + 0.5;
            hear();
            awake = true;
            say("cutemod.otherworld.wake2");
            pling(0.4F);
        }

        void chase(double sp) {
            double dx = tx - x, dy = ty - y, d = Math.hypot(dx, dy);
            if (d <= sp) { x = tx; y = ty; next(); }
            else { x += dx / d * sp; y += dy / d * sp; }
        }

        void next() {
            int cx = (int) x, cy = (int) y;
            if (cx == (int) px && cy == (int) py) { tx = px; ty = py; return; }
            if (cx == ox && cy == oy) { tx = cx + 0.5; ty = cy + 0.5; return; }
            int[][] dist = new int[N][N];
            for (int[] r : dist) Arrays.fill(r, -1);
            ArrayDeque<int[]> q = new ArrayDeque<>();
            dist[oy][ox] = 0;
            q.add(new int[]{ox, oy});
            while (!q.isEmpty()) {
                int[] c = q.poll();
                for (int[] d : DIRS) {
                    int nx = c[0] + d[0], ny = c[1] + d[1];
                    if (passable(mapB[ny][nx]) && dist[ny][nx] < 0) { dist[ny][nx] = dist[c[1]][c[0]] + 1; q.add(new int[]{nx, ny}); }
                }
            }
            int best = dist[cy][cx];
            tx = cx + 0.5;
            ty = cy + 0.5;
            for (int[] d : DIRS) {
                int nx = cx + d[0], ny = cy + d[1];
                if (passable(mapB[ny][nx]) && dist[ny][nx] >= 0 && dist[ny][nx] < best) { best = dist[ny][nx]; tx = nx + 0.5; ty = ny + 0.5; }
            }
        }
    }

    // ---------- the warden: walks tile to tile along the shortest way to you ----------
    private void chase() {
        double sp = 0.013 + 0.0025 * seals + (world == 1 ? 0.004 * siren() : 0);       // slow (you walk 0.05); a little faster with every seal
        double dx = tx - ex, dy = ty - ey, d = Math.hypot(dx, dy);
        if (d <= sp) { ex = tx; ey = ty; next(); }
        else { ex += dx / d * sp; ey += dy / d * sp; }
    }

    private void next() {
        int cx = (int) ex, cy = (int) ey;
        if (cx == (int) px && cy == (int) py) { tx = px; ty = py; return; }   // right on top of you
        if (cx == ox && cy == oy) { tx = cx + 0.5; ty = cy + 0.5; return; }   // reached the last heard spot: waits there
        int[][] dist = new int[N][N];
        for (int[] r : dist) Arrays.fill(r, -1);
        ArrayDeque<int[]> q = new ArrayDeque<>();
        dist[oy][ox] = 0;
        q.add(new int[]{ox, oy});
        while (!q.isEmpty()) {                                     // distance from every tile to where it heard you
            int[] c = q.poll();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0], ny = c[1] + d[1];
                if (passable(mapB[ny][nx]) && dist[ny][nx] < 0) { dist[ny][nx] = dist[c[1]][c[0]] + 1; q.add(new int[]{nx, ny}); }
            }
        }
        int best = dist[cy][cx];
        tx = cx + 0.5;
        ty = cy + 0.5;
        for (int[] d : DIRS) {
            int nx = cx + d[0], ny = cy + d[1];
            if (passable(mapB[ny][nx]) && dist[ny][nx] >= 0 && dist[ny][nx] < best) { best = dist[ny][nx]; tx = nx + 0.5; ty = ny + 0.5; }
        }
    }

    // ---------- the crimson walls ----------
    private static int shade(int rgb, double b) {
        b = Math.max(0, Math.min(1.5, b));
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * b));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * b));
        int bl = Math.min(255, (int) ((rgb & 255) * b));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int mixc(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static double frac(double x) { return x - Math.floor(x); }

    /**
     * The color of one spot of a wall. u = along the wall (0-1), v = up the wall (0-1), t = seconds, ph = a number
     * that is different for every tile. Everything moves, so the walls never lie still: they shimmer between red and black.
     * Three kinds of wall: living flesh with glowing veins, a rusty grate with a red glow behind it, bloody iron plates.
     */
    private static int wall(int type, double u, double v, double t, double ph) {
        switch (type) {
            case 0 -> {                                              // flesh: slow waves, bright veins
                double n = Math.sin(u * 10 + Math.sin(v * 6 + t * 0.9) * 1.8 + t * 0.6 + ph)
                        + Math.sin(v * 8 - u * 3 - t * 1.2 + ph * 2) + Math.sin(u * 4 + v * 7 + t * 0.45);
                n = (n + 3) / 6;
                int c = mixc(0xFF060103, 0xFF9C1020, n * n * (3 - 2 * n));
                return n > 0.8 ? mixc(c, 0xFFFF4050, (n - 0.8) / 0.2 * 0.85) : c;
            }
            case 1 -> {                                              // grate: rusty bars, the holes glow and fade
                double gu = frac(u * 5 + ph), gv = frac(v * 5);
                if (gu < 0.2 || gv < 0.2) return mixc(0xFF1A0305, 0xFF5A0C10, 0.5 + 0.5 * Math.sin(u * 40 + v * 30));
                double pulse = 0.5 + 0.5 * Math.sin(t * 1.6 + Math.floor(u * 5 + ph) * 0.9 + Math.floor(v * 5) * 1.3);
                return mixc(0xFF050102, 0xFFC81C28, pulse * pulse);
            }
            default -> {                                             // iron plates: seams, rivets, red streaks that creep down
                double pu = frac(u * 2 + ph), pv = frac(v * 3);
                if (pu < .06 || pu > .94 || pv < .06 || pv > .94) return 0xFF1F0406;
                if ((pu < .15 || pu > .85) && (pv < .15 || pv > .85)) return 0xFF7A2024;
                double drip = 0.5 + 0.5 * Math.sin(u * 31 + ph * 5) * Math.sin(v * 3 + 0.5 * Math.sin(u * 17) - t * 0.4);
                double sh = 0.5 + 0.5 * Math.sin(t * 1.3 + u * 8 + v * 5);
                return mixc(0xFF22060A, 0xFFB82424, 0.25 * drip + 0.6 * sh * sh);
            }
        }
    }

    /** The living world: calm grey-green stone. Bricks, moss, and cracked plaster. A slow breath of light, nothing more. */
    private static int wallLiving(int type, double u, double v, double t, double ph) {
        double breath = 0.5 + 0.5 * Math.sin(t * 0.7 + ph);
        switch (type) {
            case 0 -> {                                              // bricks
                int row = (int) Math.floor(v * 4);
                double bu = frac(u * 3 + (row % 2) * 0.5 + ph), bv = frac(v * 4);
                if (bu < 0.07 || bv < 0.1) return 0xFF0A1416;
                double n = 0.5 + 0.5 * Math.sin(Math.floor(u * 3 + (row % 2) * 0.5 + ph) * 3.1 + row * 1.7);
                return mixc(mixc(0xFF16282A, 0xFF4C7872, n), 0xFF6CA39A, 0.12 * breath);
            }
            case 1 -> {                                              // moss
                double n = (Math.sin(u * 7 + ph) + Math.sin(v * 9 + u * 3) + Math.sin(t * 0.4 + u * 5 + v * 2) + 3) / 6;
                return mixc(0xFF08160F, 0xFF3C7A56, n * n * (3 - 2 * n) + 0.08 * breath);
            }
            default -> {                                             // pale plaster with cracks
                if (Math.abs(Math.sin(u * 23 + ph * 3 + Math.sin(v * 9) * 2)) < 0.06) return 0xFF0E1A1E;
                double n = 0.5 + 0.5 * Math.sin(u * 5 + v * 3 + ph);
                return mixc(mixc(0xFF2A3C42, 0xFF688A90, n), 0xFF9CC8C8, 0.1 * breath);
            }
        }
    }

    /** A sprite colour seen from the living world: the same picture in cold teal. */
    private static int teal(int c) {
        int gray = (((c >> 16) & 255) * 3 + ((c >> 8) & 255) * 6 + (c & 255)) / 10;
        return mixc(0xFF04100E, 0xFF7EF0D8, gray / 255.0);
    }

    private static int pal(char c, boolean open) {
        return switch (c) {
            case 'k' -> 0xFF14030A;
            case 'd' -> 0xFF5A0A14;
            case 'r' -> 0xFFFF2A3A;
            case 'p' -> 0xFFFF9AA0;
            case 'b' -> 0xFF3A0810;
            case 'g' -> open ? 0xFFFF6A6A : 0xFF7A1018;
            case 'y' -> 0xFFFFD84A;
            case 'm' -> 0xFF8A94A0;
            default -> 0xFF2A0A10;
        };
    }

    @Override
    public void render(GuiGraphics g) {
        if (choosing) { menu(g); return; }
        if (over && !won) { if (squashed) trainScare(g); else jumpScare(g); return; }
        boolean living = world == 0;
        double t = ticks / 60.0, sir = living ? 0 : siren();
        if (living) {
            g.fillGradient(0, 0, W, H / 2, 0xFF0A1C22, 0xFF000000);    // ceiling
            g.fillGradient(0, H / 2, W, H, 0xFF000000, 0xFF14303A);    // floor
            int mist = (int) (30 + 14 * Math.sin(t * 0.9));           // a soft mist on the floor
            g.fillGradient(0, H - 34, W, H, 0x0060C0B0, (mist << 24) | 0x60C0B0);
        } else {
            g.fillGradient(0, 0, W, H / 2, 0xFF1C0408, 0xFF000000);    // ceiling
            g.fillGradient(0, H / 2, W, H, 0xFF000000, 0xFF3E060A);    // floor
            int glow = (int) (36 + 26 * Math.sin(t * 2.0) + 70 * sir);  // the floor pulses
            g.fillGradient(0, H - 34, W, H, 0x00700010, (Math.min(140, glow) << 24) | 0x700010);
        }

        double dirX = Math.cos(ang), dirY = Math.sin(ang), plX = -dirY * PLANE, plY = dirX * PLANE;
        for (int c = 0; c < COLS; c++) {                           // walls: one ray per column
            double cam = 2.0 * (c + 0.5) / COLS - 1;
            double rdx = dirX + plX * cam, rdy = dirY + plY * cam;
            int mapX = (int) px, mapY = (int) py;
            double ddx = Math.abs(1 / rdx), ddy = Math.abs(1 / rdy), sdx, sdy;
            int stepX, stepY;
            if (rdx < 0) { stepX = -1; sdx = (px - mapX) * ddx; } else { stepX = 1; sdx = (mapX + 1 - px) * ddx; }
            if (rdy < 0) { stepY = -1; sdy = (py - mapY) * ddy; } else { stepY = 1; sdy = (mapY + 1 - py) * ddy; }
            boolean side = false;
            while (map[mapY][mapX] == 0) {                         // walk the grid until a wall is hit
                if (sdx < sdy) { sdx += ddx; mapX += stepX; side = false; }
                else { sdy += ddy; mapY += stepY; side = true; }
            }
            double dist = Math.max(0.05, side ? sdy - ddy : sdx - ddx);
            zbuf[c] = dist;
            double wallX = (side ? px + dist * rdx : py + dist * rdy);
            wallX -= Math.floor(wallX);
            double fog = Math.pow(Math.max(0, 1 - dist / 6.5), 1.2);
            double b = (0.95 * fog + 0.09) * light * (side ? 0.72 : 1) * (1 + 0.4 * sir * (0.6 + 0.4 * Math.sin(t * 9)));
            int type = Math.floorMod(mapX * 3 + mapY * 7, 3);
            double ph = mapX * 0.37 + mapY * 0.61;
            int lh = (int) (H / dist), top = H / 2 - lh / 2;
            int y0 = Math.max(0, top), y1 = Math.min(H, top + lh);
            int seg = Math.max(2, Math.min(8, (y1 - y0) / 12));
            boolean tr = map[mapY][mapX] == 2;                     // a train: the tile is a car (the head has lights or eyes)
            double[] ti = tr ? trainInfo(mapY) : null;
            boolean head = ti != null && !side && stepX == -(int) ti[0] && mapX == (int) ti[1];
            for (int y = y0; y < y1; y += seg) {                   // the wall is drawn in pieces, each with its own color
                int h = Math.min(seg, y1 - y);
                double v = (y + h * 0.5 - top) / (double) lh;
                int col = tr ? trainColor(living, wallX, v, t, head, ti == null ? 0 : ti[2])
                        : living ? wallLiving(type, wallX, v, t, ph) : wall(type, wallX, v, t, ph);
                rect(g, c * CW, y, CW, h, shade(col, b));
            }
        }

        List<double[]> things = new ArrayList<>();                 // sprites, far ones first
        for (int i = 0; i < SEALS; i++) if (!got[i]) things.add(new double[]{sq(sx[i] - px) + sq(sy[i] - py), sx[i], sy[i], sealWorld[i] == world ? 0 : 3});
        things.add(new double[]{sq(N - 1.5 - px) + sq(N - 1.5 - py), N - 1.5, N - 1.5, living ? 1 : 4});
        if (awake && !living) things.add(new double[]{sq(ex - px) + sq(ey - py), ex, ey, 2});
        if (master.awake && !living) things.add(new double[]{sq(master.x - px) + sq(master.y - py), master.x, master.y, 6});
        if (level == 2) for (int i = 0; i < 2; i++) things.add(new double[]{sq(LEVER_X[i] - px) + sq(LEVER_Y[i] - py), LEVER_X[i], LEVER_Y[i], 5});
        things.sort((a, b) -> Double.compare(b[0], a[0]));
        for (double[] s : things) {
            switch ((int) s[3]) {
                case 0 -> sprite(g, s[1], s[2], SEAL, 0.3, 0.12 + Math.sin(ticks / 12.0) * 0.04, 0.8, 10, living);
                case 1 -> sprite(g, s[1], s[2], GATE, 0.9, 0, 0.5, 10, living);
                case 3 -> sprite(g, s[1], s[2], SEAL, 0.3, 0.12 + Math.sin(ticks / 12.0) * 0.04, 0.0, 5, !living, 0.35);   // an echo from the other world
                case 4 -> sprite(g, s[1], s[2], GATE, 0.9, 0, 0.0, 5, true, 0.3);
                case 5 -> sprite(g, s[1], s[2], LEVER, 0.45, 0, 0.35, 8, living);
                case 6 -> sprite(g, s[1], s[2], MASTER, 0.95, 0, 0.12, 6, false);
                default -> sprite(g, s[1], s[2], DOLL, 0.9, 0, 0.12, 6, false);
            }
        }

        double md = Math.min(Math.hypot(ex - px, ey - py), master.awake ? Math.hypot(master.x - px, master.y - py) : 1e9);
        if (md < 3 && !living) {                                   // it is close: red edges and static
            rect(g, 0, 0, W, H, ((int) ((3 - md) / 3 * 90) << 24) | 0x900010);
            for (int k = 0; k < 6; k++) rect(g, rnd.nextInt(W), rnd.nextInt(H), 40, 1, 0x40FF6060);
        }
        if (sir > 0) rect(g, 0, 0, W, H, ((int) (sir * 46) << 24) | 0xFF0010);   // the siren washes the screen red
        if (level == 2) {
            double tn = trainNear();
            if (tn < 4) rect(g, 0, 0, W, H, ((int) ((4 - tn) / 4 * 70) << 24) | (living ? 0xFFF0C0 : 0xFF2010));   // a train is right next to you
        }
        for (int i = 0; i < 4; i++) {                              // dark vignette (red in the Otherworld, teal in the living world)
            int a = (0x78 - i * 0x1E) << 24;
            int vc = living ? 0x02100E : 0x100004;
            rect(g, i * 6, 0, 6, H, a | vc);
            rect(g, W - 6 - i * 6, 0, 6, H, a | vc);
        }
        if (flashT > 0) rect(g, 0, 0, W, H, ((int) (flashT / 16.0 * 150) << 24) | (living ? 0xC8FFF0 : 0xFF2030));   // crossing flash
        hud(g);
        minimap(g);
        if (msgT > 0) small(g, Component.translatable(msg).getString(), msgT < 30 ? 0xFF8A3A40 : 0xFFFFA0A8);
        if (won) rect(g, 0, 0, W, H, 0x50FF8090);
    }

    private static double sq(double v) { return v * v; }

    /** A message at the bottom in small type (3/4 size); a long one is split into two centred lines that stay inside the screen. */
    private static void small(GuiGraphics g, String s, int argb) {
        final float k = 0.75F;
        int maxW = Math.round((W - 16) / k);
        java.util.List<String> lines = new java.util.ArrayList<>();
        String rest = s;
        while (!rest.isEmpty() && lines.size() < 2) {
            if (font().width(rest) <= maxW || lines.size() == 1) { lines.add(font().plainSubstrByWidth(rest, maxW)); break; }
            String head = font().plainSubstrByWidth(rest, maxW);
            int cut = head.lastIndexOf(' ');
            if (cut > 0) head = head.substring(0, cut);
            lines.add(head);
            rest = rest.substring(head.length()).trim();
        }
        int y = H - 19 - (lines.size() - 1) * 8;
        for (String l : lines) {
            g.pose().pushPose();
            g.pose().translate(W / 2f, y, 0);
            g.pose().scale(k, k, 1F);
            g.drawString(font(), l, -font().width(l) / 2, 0, argb, false);
            g.pose().popPose();
            y += 8;
        }
    }

    /** Top-left: the three seals (a lit ring for every one you hold, the colour of the ring is the world it lies in). Bottom: grip. */
    private void hud(GuiGraphics g) {
        for (int i = 0; i < SEALS; i++) {
            int x = 10 + i * 12;
            disc(g, x, 9, 4, sealWorld[i] == 0 ? 0xFF0E2A28 : 0xFF2A0610);
            disc(g, x, 9, 3, got[i] ? (sealWorld[i] == 0 ? 0xFF40E0C8 : 0xFFFF3040) : 0xFF0A0A0C);
            if (got[i]) rect(g, x - 1, 8, 2, 2, 0xFFE8FFFF);
        }
        String wn = Component.translatable("cutemod.otherworld.world." + world).getString();
        g.pose().pushPose();
        g.pose().translate(10, 17, 0);
        g.pose().scale(0.75F, 0.75F, 1F);
        text(g, wn, 0, 0, world == 0 ? 0xFF7EF0D8 : 0xFFFF6A72);
        g.pose().popPose();
        if (world == 0 || grip < GRIP_MAX) {                       // how long the living world still holds you
            int w = 60, x = 10, y = H - 8;
            rect(g, x - 1, y - 1, w + 2, 5, 0x99000000);
            double f = grip / GRIP_MAX;
            boolean low = f < 0.25 && ticks / 8 % 2 == 0;
            rect(g, x, y, (int) (w * f), 3, low ? 0xFFFFFFFF : 0xFF40E0C8);
        }
        if (flipCd > 0 && flipCd <= FLIP_CD) rect(g, 10, H - 13, flipCd * 60 / FLIP_CD, 1, 0x88FFFFFF);
        if (level == 2) {
            g.pose().pushPose();
            g.pose().translate(10, 25, 0);
            g.pose().scale(0.6F, 0.6F, 1F);
            text(g, Component.translatable("cutemod.otherworld.level.2").getString(), 0, 0, 0xFFB8A8D8);
            g.pose().popPose();
            trainHud(g);
        }
    }

    /** The signal on top: the horn warns 3 seconds ahead, the arrows show which way the train of THIS world goes. */
    private void trainHud(GuiGraphics g) {
        int w = world;
        String s;
        int col;
        boolean blink = ticks / 8 % 2 == 0;
        if (!Double.isNaN(tpos[w])) {
            s = (tdir[w] > 0 ? ">>> " : "<<< ") + Component.translatable("cutemod.otherworld.train").getString() + (tdir[w] > 0 ? " >>>" : " <<<");
            col = blink ? 0xFFFF4A4A : 0xFFFFB0B0;
        } else if (holdT[w] > 0) {
            s = Component.translatable("cutemod.otherworld.held", (holdT[w] + 59) / 60).getString();
            col = 0xFF7EF0A0;
        } else if (tnext[w] <= WARN) {
            s = (tdir[w] > 0 ? ">> " : "<< ") + Component.translatable("cutemod.otherworld.train_soon").getString();
            col = blink ? 0xFFFFD84A : 0xFFB89A30;
        } else {
            return;
        }
        rect(g, W / 2 - font().width(s) / 2 - 3, 1, font().width(s) + 6, 10, 0xAA000000);
        ctext(g, s, W / 2, 2, col);
    }

    /** The level menu (it appears once the house has been beaten). */
    private void menu(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0xFF100408);
        for (int i = 0; i < 4; i++) rect(g, i * 5, 0, 5, H, ((0x50 - i * 0x14) << 24) | 0x600010);
        ctext(g, Component.translatable("cutemod.otherworld.choose").getString(), W / 2, 30, 0xFFFF6A72);
        for (int i = 0; i < 2; i++) {
            int y = 62 + i * 32;
            rect(g, 20, y, W - 40, 26, 0xFF2A0A12);
            rect(g, 20, y, W - 40, 1, 0xFFFF3040);
            ctext(g, (i + 1) + "  -  " + Component.translatable("cutemod.otherworld.level." + (i + 1)).getString(), W / 2, y + 9, 0xFFFFC0C4);
        }
        ctext(g, Component.translatable("cutemod.otherworld.choose_hint").getString(), W / 2, H - 14, 0xFF8A5A60);
    }

    /** The texture of a train car. The head (the front) has lights, or eyes and teeth; the windows slide with the train. */
    private static int trainColor(boolean living, double u, double v, double t, boolean head, double off) {
        if (v > 0.88) return living ? 0xFF0A1014 : 0xFF050102;                    // the undercarriage
        if (v < 0.08) return living ? 0xFF1E2A34 : 0xFF140306;                    // the edge of the roof
        if (head) {
            if (living) {
                if (Math.hypot(u - 0.25, v - 0.64) < 0.09 || Math.hypot(u - 0.75, v - 0.64) < 0.09) return 0xFFFFF6C8;   // the headlights
                if (v > 0.18 && v < 0.5 && u > 0.12 && u < 0.88) return 0xFF0E1A22;                                      // the driver's window
                return 0xFF3E5C78;
            }
            double pulse = 0.6 + 0.4 * Math.sin(t * 6);
            if (Math.hypot(u - 0.28, v - 0.4) < 0.12 || Math.hypot(u - 0.72, v - 0.4) < 0.12) return mixc(0xFF6A0A14, 0xFFFF2A3A, pulse);   // the eyes
            if (v > 0.68 && v < 0.84 && Math.sin(u * 42) > -0.2) return 0xFFE8D0C0;                                                         // the teeth
            return 0xFF3A0A10;
        }
        if (u < 0.04 || u > 0.96) return living ? 0xFF0E161C : 0xFF080204;        // the gap between two cars
        double uw = ((u - off) % 1 + 1) % 1;
        if (v > 0.2 && v < 0.5 && uw > 0.14 && uw < 0.86) {
            if (living) return mixc(0xFFE8B860, 0xFFFFF0B8, 0.2 + 0.2 * Math.sin(t * 3 + Math.floor(u * 2)));       // a lit window
            return Math.abs(v - 0.35) < 0.05 ? mixc(0xFF8A0A14, 0xFFFF2A3A, 0.5 + 0.5 * Math.sin(t * 5 + uw * 6)) : 0xFF1A0508;   // a glowing slit
        }
        return living ? (v < 0.62 ? 0xFF4A6E90 : 0xFF34506C) : mixc(0xFF2A0508, 0xFF5A1018, 0.5 + 0.5 * Math.sin(uw * 18 + v * 9));
    }

    /** {direction, the tile of the head, the part of a tile the train has moved} of the train of this world on that row (or null). */
    private double[] trainInfo(int row) {
        int w = world;
        if (TRACK[w] != row || Double.isNaN(tpos[w])) return null;
        double l = Math.floor(tpos[w]);
        return new double[]{tdir[w], tdir[w] > 0 ? l + TRAIN_LEN - 1 : l, tpos[w] - l};
    }

    /** How far away the nearest tile of a train of this world is (a big number if there is none). */
    private double trainNear() {
        double best = 1e9;
        int row = TRACK[world];
        for (int x = 1; x < N - 1; x++) if (map[row][x] == 2) best = Math.min(best, Math.hypot(x + 0.5 - px, row + 0.5 - py));
        return best;
    }

    /** You were run over: two headlights fill the screen. */
    private void trainScare(GuiGraphics g) {
        boolean flick = (System.currentTimeMillis() / 70) % 2 == 0;
        rect(g, 0, 0, W, H, flick ? 0xFFE8F0F0 : 0xFF101820);
        rect(g, 20, 30, W - 40, 100, 0xFF1A2430);
        rect(g, 20, 30, W - 40, 6, 0xFF0A1014);
        disc(g, 66, 78, 24, 0xFFFFF6C8);
        disc(g, W - 66, 78, 24, 0xFFFFF6C8);
        disc(g, 66, 78, 14, 0xFFFFFFFF);
        disc(g, W - 66, 78, 14, 0xFFFFFFFF);
        rect(g, W / 2 - 26, 70, 52, 22, 0xFF0E1A22);
    }

    /** A billboard: a tiny picture that always faces you. Columns behind walls are skipped. */
    private void sprite(GuiGraphics g, double spx, double spy, String[] bmp, double size, double lift, double minB, double range, boolean teal) {
        sprite(g, spx, spy, bmp, size, lift, minB, range, teal, 1.0);
    }

    /** dim = 1 for a real thing, less for an echo of something that lies in the other world (you see it, but you cannot touch it). */
    private void sprite(GuiGraphics g, double spx, double spy, String[] bmp, double size, double lift, double minB, double range, boolean teal, double dim) {
        double rx = spx - px, ry = spy - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);          // how far in front of us
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);         // how far to the right
        if (f < 0.15) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f), sh = (int) (full * size), sw = sh * bmp[0].length() / bmp.length;
        int left = (int) (W / 2.0 * (1 + cam)) - sw / 2, top = H / 2 + full / 2 - sh - (int) (full * lift);
        double b = (Math.max(minB, 1 - f / range) + (Math.abs(cam) < 0.35 ? 0.25 : 0)) * light * dim;
        if (b <= 0.02) return;
        boolean open = seals == SEALS;
        for (int x = Math.floorDiv(left, CW) * CW; x < left + sw; x += CW) {
            int c = x / CW;
            if (x < 0 || c >= COLS || f >= zbuf[c]) continue;
            int u = Math.max(0, Math.min(bmp[0].length() - 1, (x + CW / 2 - left) * bmp[0].length() / sw));
            for (int row = 0; row < bmp.length; row++) {
                char ch = bmp[row].charAt(u);
                if (ch == '.') continue;
                int y0 = top + row * sh / bmp.length, y1 = Math.max(y0 + 1, top + (row + 1) * sh / bmp.length);
                int base = pal(ch, open);
                rect(g, x, y0, CW, y1 - y0, shade(teal ? teal(base) : base, b));
            }
        }
    }

    /** Top-right: only the places you have already been to. A tile that is open in BOTH worlds is lighter: there you can cross safely. */
    private void minimap(GuiGraphics g) {
        int s = 3, x0 = W - N * s - 6, y0 = 6;
        boolean living = world == 0;
        int[][] other = living ? mapB : mapA;
        rect(g, x0 - 2, y0 - 2, N * s + 4, N * s + 4, 0x99000000);
        for (int y = 0; y < N; y++) for (int x = 0; x < N; x++) {
            if (!seen[world][y][x]) continue;
            int c;
            if (map[y][x] == 2) c = living ? 0xFFFFD84A : 0xFFFF5A2A;                // a train
            else if (map[y][x] == 1) c = living ? 0xFF2A5A56 : 0xFF7A1C24;
            else if (level == 2 && y == TRACK[world]) c = living ? 0xFF8A6A2A : 0xFF8A3A1A;   // the rails
            else if (other[y][x] == 0) c = living ? 0xFF4A8A82 : 0xFF6A2A30;   // open in both
            else c = living ? 0xFF0E2A28 : 0xFF2A0A10;
            rect(g, x0 + x * s, y0 + y * s, s, s, c);
        }
        if (level == 2) for (int i = 0; i < 2; i++) if (seen[world][(int) LEVER_Y[i]][(int) LEVER_X[i]]) rect(g, x0 + (int) (LEVER_X[i] * s) - 1, y0 + (int) (LEVER_Y[i] * s) - 1, 2, 2, leverCd[i] > 0 ? 0xFF6A6A70 : 0xFFFFD84A);
        if (seen[world][N - 2][N - 2]) rect(g, x0 + (N - 2) * s, y0 + (N - 2) * s, s, s, living ? (seals == SEALS ? 0xFFE8FFFF : 0xFF40A090) : 0xFF8A2028);
        rect(g, x0 + (int) (px * s) - 1, y0 + (int) (py * s) - 1, 2, 2, living ? 0xFFE8FFFF : 0xFFFFC0C4);
        rect(g, x0 + (int) ((px + Math.cos(ang) * 1.2) * s), y0 + (int) ((py + Math.sin(ang) * 1.2) * s), 1, 1, living ? 0xFF7EF0D8 : 0xFFFF8A90);
    }

    /** You were caught: the warden's triangle head fills the screen. (The "Game over" box is drawn on top of the middle.) */
    private void jumpScare(GuiGraphics g) {
        boolean flick = (System.currentTimeMillis() / 80) % 2 == 0;
        rect(g, 0, 0, W, H, flick ? 0xFF3A0008 : 0xFF000000);
        rect(g, 24, 84, 172, 56, 0xFF14030A);                      // shoulders
        for (int r = 0; r < 76; r++) {                             // the head: a big triangle
            int ww = 8 + r * 2;
            rect(g, W / 2 - ww / 2, 8 + r, ww, 1, r % 6 < 3 ? 0xFF4A0A14 : 0xFF3A0610);
        }
        rect(g, W / 2 - 34, 58, 68, 7, 0xFFFF2A3A);                // the glowing slit
        rect(g, W / 2 - 34, 61, 68, 1, 0xFFFFC0C4);
        for (int k = 0; k < 9; k++) rect(g, 30 + k * 20, 84, 3, 10 + (k * 7) % 14, 0xFF8A0A16);   // blood
    }

    @Override
    public String hintKey() { return "cutemod.hint.otherworld"; }

    @Override
    public Component status() { return Component.translatable("cutemod.otherworld.status", seals, SEALS); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return Component.translatable(won ? "cutemod.otherworld.win" : squashed ? "cutemod.otherworld.train_hit" : "cutemod.ui.gameover");
    }
}
