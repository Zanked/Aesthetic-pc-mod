package dev.cutemod.client.game;

import dev.cutemod.data.CheckersEngine;
import dev.cutemod.data.CheckersEngine.Move;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Checkers (Russian draughts, "shashki"): against the computer at three levels, two players on one computer, or
 * ONLINE against another player on the server (invite someone from the list; the server keeps the game and checks every
 * move, see {@link CheckersNet} and dev.cutemod.net.CheckersServer).
 * The rules and the computer player are in {@link CheckersEngine}. The computer thinks in a worker thread, so the
 * game never freezes.
 * <p>
 * How to move: click a piece, then a highlighted square. A capture with several jumps is made jump by jump (click
 * every landing square). Capturing is a must. The side that cannot move loses. A draw after 15 moves of kings
 * each without a capture or a man's move (or after 300 moves).
 */
public class Checkers extends MiniGame {
    private static final int BX = 4, BY = 6, CELL = 16, PX = 138;
    /** Score of a win against the computer (easy / normal / hard) and of a draw. */
    private static final int[] WIN_SCORE = {50, 75, 100}, DRAW_SCORE = {10, 25, 40};
    private static final int MENU = 0, PLAY = 1, LOBBY = 2;
    /** Score of an online win and of a draw (a win against a person is worth about a win at the normal level). */
    private static final int ONLINE_WIN = 60, ONLINE_DRAW = 20;

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "cutemod-checkers-ai");
        t.setDaemon(true);
        return t;
    });

    private int state = MENU;
    private boolean vsAi = true, humanWhite = true;
    private int level = 1;

    private int[] board = CheckersEngine.start();
    private boolean whiteTurn = true;
    private List<Move> legal = new ArrayList<>();
    private boolean forced;
    private int sel = -1;
    private final int[] path = new int[16];
    private int pathLen;
    private int lastFrom = -1, lastTo = -1;
    private int quiet, plies, wait, anim;
    private int resultKind;                 // 0 none, 1 you won, 2 you lost, 3 draw, 4 white won, 5 black won
    private Future<Move> thinking;

    // online play
    private boolean online, netWhite, awaiting;
    private String oppName = "";
    private int seenVersion = -1, noticeT, resignT;
    private String noticeKey = "";

    // ---------- helpers ----------
    private static String tr(String key) { return Component.translatable(key).getString(); }

    private boolean humanTurn() {
        if (online) return !over && !awaiting && whiteTurn == netWhite;
        return !vsAi || whiteTurn == humanWhite;
    }

    private boolean flip() { return online ? !netWhite : vsAi && !humanWhite; }

    private int sqX(int s) { int c = s % 8; return BX + (flip() ? 7 - c : c) * CELL; }

    private int sqY(int s) { int r = s / 8; return BY + (flip() ? 7 - r : r) * CELL; }

    /** The dark square under this point, or -1. */
    private int squareAt(int x, int y) {
        if (!in(x, y, BX, BY, CELL * 8, CELL * 8)) return -1;
        int dc = (x - BX) / CELL, dr = (y - BY) / CELL;
        int c = flip() ? 7 - dc : dc, r = flip() ? 7 - dr : dr;
        return (r + c) % 2 == 0 ? -1 : r * 8 + c;
    }

    // ---------- game flow ----------
    @Override
    public void reset() {
        score = 0;
        over = false;
        resultKind = 0;
        state = MENU;
        cancelThinking();
        if (CheckersNet.inMatch() && CheckersNet.result != 0) CheckersNet.leaveGame();   // a finished online game: we are done with it
        online = false;
        awaiting = false;
        noticeT = 0;
        resignT = 0;
        CheckersNet.request();            // maybe a game is still running on the server: tick() brings us back to it
    }

    private void cancelThinking() {
        if (thinking != null) thinking.cancel(true);
        thinking = null;
    }

    private void startGame(boolean ai, int lvl) {
        vsAi = ai;
        level = lvl;
        board = CheckersEngine.start();
        whiteTurn = true;
        plies = 0;
        quiet = 0;
        sel = -1;
        pathLen = 0;
        lastFrom = -1;
        lastTo = -1;
        resultKind = 0;
        legal = CheckersEngine.moves(board, true);
        forced = CheckersEngine.mustCapture(legal);
        wait = 25;
        state = PLAY;
        pling(1.2F);
    }

    @Override
    public void tick() {
        anim++;
        if (noticeT > 0) noticeT--;
        if (resignT > 0) resignT--;
        netTick();
        if (state != PLAY || over || !vsAi || humanTurn()) return;
        if (thinking == null) {
            if (--wait > 0) return;
            final int[] copy = board.clone();
            final boolean side = whiteTurn;
            final int lvl = level;
            thinking = POOL.submit(() -> CheckersEngine.best(copy, side, lvl, new Random()));
        } else if (thinking.isDone()) {
            Move m = null;
            try {
                m = thinking.get();
            } catch (Exception ignored) {
                // cancelled or failed: play the first legal move so that the game goes on
                if (!legal.isEmpty()) m = legal.get(0);
            }
            thinking = null;
            if (m != null) doMove(m);
        }
    }

    // ---------- online ----------
    private void netTick() {
        int n = CheckersNet.takeNotice();
        if (n != 0) { noticeKey = "cutemod.checkers.notice." + n; noticeT = 240; }
        if (state == LOBBY && anim % 120 == 0) CheckersNet.request();
        if (CheckersNet.inMatch()) {
            if (!online || state != PLAY) startOnline();
            else if (CheckersNet.version != seenVersion) syncOnline();
        }
    }

    private void startOnline() {
        online = true;
        vsAi = false;
        cancelThinking();
        netWhite = CheckersNet.youWhite;
        oppName = CheckersNet.opponent;
        over = false;
        resultKind = 0;
        score = 0;
        clearSel();
        lastFrom = lastTo = -1;
        state = PLAY;
        syncOnline();
        pling(1.2F);
    }

    /** The server told us how the game stands: take the board, the turn and the result from it. */
    private void syncOnline() {
        seenVersion = CheckersNet.version;
        boolean fresh = !java.util.Arrays.equals(board, CheckersNet.board);
        board = CheckersNet.board.clone();
        whiteTurn = CheckersNet.whiteTurn;
        lastFrom = CheckersNet.lastFrom;
        lastTo = CheckersNet.lastTo;
        awaiting = false;
        clearSel();
        legal = CheckersEngine.moves(board, whiteTurn);
        forced = CheckersEngine.mustCapture(legal);
        if (fresh && lastTo >= 0) pling(whiteTurn == netWhite ? 0.8F : 0.55F);
        int r = CheckersNet.result;
        if (r != 0 && !over) {
            over = true;
            resultKind = r == 3 ? 3 : (r == 1) == netWhite ? 1 : 2;
            score = resultKind == 1 ? ONLINE_WIN : resultKind == 3 ? ONLINE_DRAW : 0;
            pling(resultKind == 2 ? 0.5F : 1.6F);
        }
    }

    private void doMove(Move m) {
        int piece = board[m.from()];
        boolean wasMan = Math.abs(piece) == 1;
        board = CheckersEngine.apply(board, m);
        lastFrom = m.from();
        lastTo = m.end();
        boolean crowned = wasMan && Math.abs(board[m.end()]) == 2;
        quiet = m.caps().length > 0 || wasMan ? 0 : quiet + 1;
        plies++;
        if (crowned) pling(1.6F);
        else if (m.caps().length > 0) pling(0.7F + 0.12F * m.caps().length);
        else pling(0.55F);
        whiteTurn = !whiteTurn;
        sel = -1;
        pathLen = 0;
        wait = 18;
        legal = CheckersEngine.moves(board, whiteTurn);
        forced = CheckersEngine.mustCapture(legal);
        if (legal.isEmpty()) finish(!whiteTurn);            // the side to move cannot move: the other side won
        else if (quiet >= 30 || plies >= 300) finishDraw();
    }

    private void finish(boolean whiteWon) {
        over = true;
        if (vsAi) {
            boolean youWon = whiteWon == humanWhite;
            resultKind = youWon ? 1 : 2;
            score = youWon ? WIN_SCORE[level] : 0;
        } else {
            resultKind = whiteWon ? 4 : 5;
            score = 0;                                      // no coins for playing against yourself
        }
    }

    private void finishDraw() {
        over = true;
        resultKind = 3;
        score = vsAi ? DRAW_SCORE[level] : 0;
    }

    // ---------- input ----------
    private boolean matches(Move m) {
        if (m.from() != sel || m.to().length < pathLen) return false;
        for (int i = 0; i < pathLen; i++) if (m.to()[i] != path[i]) return false;
        return true;
    }

    private boolean hasMoveFrom(int s) {
        for (Move m : legal) if (m.from() == s) return true;
        return false;
    }

    private void clearSel() {
        sel = -1;
        pathLen = 0;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        if (state == MENU) return menuClick(x, y);
        if (state == LOBBY) return lobbyClick(x, y);
        if (in(x, y, PX + 4, 118, 70, 14)) {                 // the Menu button (online: Resign, asks twice)
            if (online) {
                if (resignT <= 0) { resignT = 180; pling(0.7F); return true; }
                CheckersNet.leaveGame();
                online = false;
                resignT = 0;
                state = MENU;
                return true;
            }
            cancelThinking();
            state = MENU;
            return true;
        }
        if (!humanTurn()) return true;
        int s = squareAt(x, y);
        if (s < 0) { clearSel(); return true; }
        if (sel >= 0 && s != sel) {
            for (Move m : legal) {
                if (matches(m) && m.to().length > pathLen && m.to()[pathLen] == s) {
                    path[pathLen++] = s;
                    for (Move done : legal) {
                        if (matches(done) && done.to().length == pathLen) {
                            clearSel();
                            if (online) { awaiting = true; CheckersNet.move(done.from(), done.to()); pling(0.9F); }   // the server plays it and tells both of us
                            else doMove(done);
                            return true;
                        }
                    }
                    pling(0.9F);
                    return true;
                }
            }
        }
        if (s == sel && pathLen > 0) { pathLen = 0; return true; }   // take the unfinished jumps back
        boolean own = whiteTurn ? board[s] > 0 : board[s] < 0;
        if (own && hasMoveFrom(s)) { sel = s; pathLen = 0; pling(1.0F); }
        else { if (own || sel >= 0) beep(); clearSel(); }
        return true;
    }

    private boolean menuClick(int x, int y) {
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 12 + i * 66, 40, 64, 18)) { startGame(true, i); return true; }
        }
        if (in(x, y, 12, 64, 196, 18)) { humanWhite = !humanWhite; pling(1.0F); return true; }
        if (in(x, y, 12, 88, 196, 18)) { state = LOBBY; CheckersNet.request(); pling(1.0F); return true; }
        if (in(x, y, 12, 110, 196, 18)) { startGame(false, 0); return true; }
        return false;
    }

    // ---------- the online lobby ----------
    private int listY() { return !CheckersNet.invitedBy.isEmpty() ? 56 : !CheckersNet.invitedTo.isEmpty() ? 52 : 30; }

    private boolean lobbyClick(int x, int y) {
        if (in(x, y, 12, 120, 60, 14)) {                     // Back
            if (!CheckersNet.invitedTo.isEmpty()) CheckersNet.cancelInvite();
            state = MENU;
            return true;
        }
        if (!CheckersNet.invitedBy.isEmpty()) {
            if (in(x, y, 12, 36, 94, 14)) { CheckersNet.accept(CheckersNet.invitedBy); pling(1.4F); return true; }
            if (in(x, y, 114, 36, 94, 14)) { CheckersNet.decline(CheckersNet.invitedBy); return true; }
        } else if (!CheckersNet.invitedTo.isEmpty()) {
            if (in(x, y, 12, 34, 196, 14)) { CheckersNet.cancelInvite(); return true; }
        }
        int ly = listY();
        for (int i = 0; i < Math.min(CheckersNet.players.size(), (112 - ly) / 16); i++) {
            if (in(x, y, 12, ly + i * 16, 196, 14)) {
                CheckersNet.invite(CheckersNet.players.get(i));
                pling(1.1F);
                return true;
            }
        }
        return true;
    }

    // ---------- drawing ----------
    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean accent) {
        boolean hover = in(mx, my, x, y, w, h);
        rect(g, x, y, w, h, hover ? 0xFFFFFFFF : accent ? 0xFFFFE8F4 : 0xFFF6F0FA);
        rect(g, x, y + h - 2, w, 2, 0xFFB9A8C8);
        ctext(g, label, x + w / 2, y + (h - 8) / 2, 0xFF3A2A3A);
    }

    private static int a(int argb, boolean ghost) { return (ghost ? 0x66000000 : 0xFF000000) | (argb & 0xFFFFFF); }

    private static void piece(GuiGraphics g, int cx, int cy, int p, boolean ghost) {
        boolean white = p > 0;
        disc(g, cx, cy + 1, 6, ghost ? 0x22000000 : 0x55000000);
        disc(g, cx, cy, 6, a(white ? 0xD9B8CC : 0x9A7ABA, ghost));
        disc(g, cx, cy, 5, a(white ? 0xFFFFFF : 0x3E2456, ghost));
        rect(g, cx - 3, cy - 3, 2, 1, a(white ? 0xFFE0F0 : 0x8A6AAA, ghost));
        if (Math.abs(p) == 2) {                                  // a golden crown
            int gold = 0xFFD84A;
            rect(g, cx - 3, cy, 7, 3, a(gold, ghost));
            rect(g, cx - 3, cy - 2, 1, 2, a(gold, ghost));
            rect(g, cx, cy - 3, 1, 3, a(gold, ghost));
            rect(g, cx + 3, cy - 2, 1, 2, a(gold, ghost));
            rect(g, cx, cy + 1, 1, 1, a(0xE5484D, ghost));
        }
    }

    @Override
    public void render(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0xFF4A2D63);
        if (state == MENU) { renderMenu(g); return; }
        if (state == LOBBY) { renderLobby(g); return; }
        rect(g, BX - 2, BY - 2, CELL * 8 + 4, CELL * 8 + 4, 0xFF5A3A5A);
        for (int dr = 0; dr < 8; dr++) for (int dc = 0; dc < 8; dc++) {
            rect(g, BX + dc * CELL, BY + dr * CELL, CELL, CELL, (dr + dc) % 2 == 0 ? 0xFFFFF0F6 : 0xFFC48BB0);
        }
        if (lastFrom >= 0) {                                     // the last move
            rect(g, sqX(lastFrom), sqY(lastFrom), CELL, CELL, 0x66FFE680);
            rect(g, sqX(lastTo), sqY(lastTo), CELL, CELL, 0x66FFE680);
        }
        // the piece that is being moved sits on its last landing square; the pieces it jumped fade out
        int movingTo = sel >= 0 && pathLen > 0 ? path[pathLen - 1] : -1;
        boolean[] jumped = new boolean[64];
        if (movingTo >= 0) for (Move m : legal) if (matches(m)) { for (int i = 0; i < pathLen && i < m.caps().length; i++) jumped[m.caps()[i]] = true; break; }
        for (int s = 0; s < 64; s++) {
            int p = board[s];
            if (p == 0 || (s == sel && movingTo >= 0)) continue;
            piece(g, sqX(s) + CELL / 2, sqY(s) + CELL / 2, p, jumped[s]);
        }
        if (movingTo >= 0) piece(g, sqX(movingTo) + CELL / 2, sqY(movingTo) + CELL / 2, board[sel], false);
        if (!over && humanTurn()) {
            if (sel < 0 && forced) {                              // these pieces have to capture
                boolean[] seen = new boolean[64];
                for (Move m : legal) if (!seen[m.from()]) { seen[m.from()] = true; rect(g, sqX(m.from()) + 1, sqY(m.from()) + 1, 3, 3, 0xFFE5484D); }
            }
            if (sel >= 0) {
                int sx = sqX(movingTo >= 0 ? movingTo : sel), sy = sqY(movingTo >= 0 ? movingTo : sel);
                rect(g, sx, sy, CELL, 1, 0xFFFFE680); rect(g, sx, sy + CELL - 1, CELL, 1, 0xFFFFE680);
                rect(g, sx, sy, 1, CELL, 0xFFFFE680); rect(g, sx + CELL - 1, sy, 1, CELL, 0xFFFFE680);
                for (Move m : legal) {
                    if (matches(m) && m.to().length > pathLen) {
                        int t = m.to()[pathLen];
                        disc(g, sqX(t) + CELL / 2, sqY(t) + CELL / 2, 3, 0xDD5BBF6A);
                    }
                }
            }
        }
        renderPanel(g);
    }

    private void renderPanel(GuiGraphics g) {
        int cx = PX + 39;
        String turn;
        if (over) turn = tr("cutemod.checkers.over");
        else if (online) turn = humanTurn() ? tr("cutemod.checkers.turn.you")
                : awaiting ? tr("cutemod.checkers.turn.wait") : Component.translatable("cutemod.checkers.turn.opp", oppName).getString();
        else if (vsAi) turn = humanTurn() ? tr("cutemod.checkers.turn.you") : tr("cutemod.checkers.turn.ai") + ".".repeat(1 + anim / 15 % 3);
        else turn = tr(whiteTurn ? "cutemod.checkers.turn.white" : "cutemod.checkers.turn.black");
        ctext(g, font().plainSubstrByWidth(turn, 80), cx, 10, 0xFFFFE9A8);
        piece(g, cx, 30, whiteTurn ? 1 : -1, false);
        piece(g, PX + 18, 56, 1, false);
        text(g, "x" + CheckersEngine.count(board, true), PX + 28, 52, 0xFFFFFFFF);
        piece(g, PX + 18, 74, -1, false);
        text(g, "x" + CheckersEngine.count(board, false), PX + 28, 70, 0xFFFFFFFF);
        if (!over && forced && humanTurn()) ctext(g, tr("cutemod.checkers.capture"), cx, 94, 0xFFFF8A8A);
        if (online) ctext(g, font().plainSubstrByWidth(oppName, 78), cx, 104, 0xFFFFC8F0);
        button(g, PX + 4, 118, 70, 14, tr(online ? (resignT > 0 ? "cutemod.checkers.resign_sure" : "cutemod.checkers.resign") : "cutemod.checkers.menu"), online && resignT > 0);
    }

    private void renderLobby(GuiGraphics g) {
        ctext(g, tr("cutemod.checkers.lobby.title"), W / 2, 8, 0xFFFFE9A8);
        String by = CheckersNet.invitedBy, to = CheckersNet.invitedTo;
        if (!by.isEmpty()) {                                     // someone invited us
            rect(g, 8, 20, 204, 34, 0xFF6A3F86);
            ctext(g, Component.translatable("cutemod.checkers.invite.from", by).getString(), W / 2, 24, 0xFFFFFFFF);
            button(g, 12, 36, 94, 14, tr("cutemod.checkers.accept"), true);
            button(g, 114, 36, 94, 14, tr("cutemod.checkers.decline"), false);
        } else if (!to.isEmpty()) {                              // we invited someone
            ctext(g, Component.translatable("cutemod.checkers.waiting", to).getString() + ".".repeat(1 + anim / 20 % 3), W / 2, 22, 0xFFFFFFFF);
            button(g, 12, 34, 196, 14, tr("cutemod.checkers.cancel"), false);
        } else {
            ctext(g, tr("cutemod.checkers.lobby.hint"), W / 2, 20, 0xFFC8B0DC);
        }
        int ly = listY(), rows = Math.min(CheckersNet.players.size(), (112 - ly) / 16);
        if (CheckersNet.players.isEmpty()) ctext(g, tr("cutemod.checkers.lobby.none"), W / 2, ly + 10, 0xFF9A82B4);
        for (int i = 0; i < rows; i++) {
            String n = CheckersNet.players.get(i);
            boolean sel = n.equals(to);
            button(g, 12, ly + i * 16, 196, 14, font().plainSubstrByWidth(n, 188), sel);
        }
        if (CheckersNet.players.size() > rows) ctext(g, "+" + (CheckersNet.players.size() - rows), W / 2, 112, 0xFF9A82B4);
        if (noticeT > 0) ctext(g, tr(noticeKey), W / 2, 108, 0xFFFF9A9A);
        button(g, 12, 120, 60, 14, tr("cutemod.checkers.back"), false);
    }

    private void renderMenu(GuiGraphics g) {
        ctext(g, tr("cutemod.checkers.title"), W / 2, 8, 0xFFFFE9A8);
        ctext(g, tr("cutemod.checkers.vs_pc"), W / 2, 28, 0xFFFFFFFF);
        for (int i = 0; i < 3; i++) button(g, 12 + i * 66, 40, 64, 18, tr("cutemod.checkers.lvl." + i), false);
        button(g, 12, 64, 196, 18, tr(humanWhite ? "cutemod.checkers.side.white" : "cutemod.checkers.side.black"), true);
        button(g, 12, 88, 196, 18, tr("cutemod.checkers.online"), true);
        button(g, 12, 110, 196, 18, tr("cutemod.checkers.two"), false);
        piece(g, 20, 12, 1, false);
        piece(g, 34, 12, -1, false);
        piece(g, W - 34, 12, 2, false);
        piece(g, W - 20, 12, -2, false);
        if (CheckersNet.inMatch()) ctext(g, tr("cutemod.checkers.resume"), W / 2, 132, 0xFFFFC8F0);
    }

    // ---------- the shell ----------
    @Override
    public Component status() {
        if (state != PLAY || over) return Component.translatable("cutemod.checkers.title");
        if (online) return humanTurn() ? Component.translatable("cutemod.checkers.turn.you") : Component.translatable("cutemod.checkers.turn.opp", oppName);
        if (vsAi) return Component.translatable(humanTurn() ? "cutemod.checkers.turn.you" : "cutemod.checkers.turn.ai");
        return Component.translatable(whiteTurn ? "cutemod.checkers.turn.white" : "cutemod.checkers.turn.black");
    }

    @Override
    public boolean isWin() { return resultKind == 1; }

    @Override
    public Component endTitle() { return Component.translatable("cutemod.checkers.end." + resultKind); }

    @Override
    public String hintKey() { return "cutemod.hint.checkers"; }
}
