package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.Arrays;

/**
 * A GuiGraphics that draws nowhere on the screen: fill and fillGradient (the only things the wallpapers, the covers and the
 * lights use) paint into an int[] of ARGB pixels instead. {@link TexCache} then turns the result into ONE texture, so a scene
 * of 5000 rectangles costs one quad on the screen instead of 5000.
 */
final class SoftCanvas extends GuiGraphics {
    private int[] px = new int[0];
    private int w, h, ox, oy;

    SoftCanvas(Minecraft mc) { super(mc, mc.renderBuffers().bufferSource()); }

    /** Clears the canvas. Pixel (0, 0) of it is the point (ox, oy) of the drawing (so a drawing may use negative coordinates). */
    void begin(int w, int h, int ox, int oy) {
        this.w = w; this.h = h; this.ox = ox; this.oy = oy;
        if (px.length < w * h) px = new int[w * h]; else Arrays.fill(px, 0, w * h, 0);
    }

    int[] pixels() { return px; }

    @Override
    public void fill(int x0, int y0, int x1, int y1, int argb) {
        if (x0 > x1) { int t = x0; x0 = x1; x1 = t; }
        if (y0 > y1) { int t = y0; y0 = y1; y1 = t; }
        x0 = Math.max(x0 - ox, 0); x1 = Math.min(x1 - ox, w);
        y0 = Math.max(y0 - oy, 0); y1 = Math.min(y1 - oy, h);
        if (x0 >= x1 || y0 >= y1) return;
        int a = argb >>> 24;
        if (a == 0) return;
        for (int y = y0; y < y1; y++) {
            int i = y * w + x0, end = y * w + x1;
            if (a == 255) { Arrays.fill(px, i, end, argb); continue; }
            for (; i < end; i++) px[i] = over(argb, px[i]);
        }
    }

    /** A vertical gradient, top colour to bottom colour, like the real one. */
    @Override
    public void fillGradient(int x0, int y0, int x1, int y1, int from, int to) {
        if (y0 > y1) { int t = y0; y0 = y1; y1 = t; }
        int hh = y1 - y0;
        for (int y = y0; y < y1; y++) {
            float f = (y - y0 + 0.5F) / hh;
            int a = lerp(from >>> 24, to >>> 24, f), r = lerp(from >> 16 & 255, to >> 16 & 255, f);
            int g = lerp(from >> 8 & 255, to >> 8 & 255, f), b = lerp(from & 255, to & 255, f);
            fill(x0, y, x1, y + 1, a << 24 | r << 16 | g << 8 | b);
        }
    }

    private static int lerp(int a, int b, float f) { return Math.round(a + (b - a) * f); }

    /** Source over destination, both ARGB with straight (not premultiplied) alpha. */
    private static int over(int s, int d) {
        int sa = s >>> 24, da = d >>> 24;
        if (da == 0) return s;
        int den = sa * 255 + da * (255 - sa);
        int oa = (den + 127) / 255;
        int r = ((s >> 16 & 255) * sa * 255 + (d >> 16 & 255) * da * (255 - sa)) / den;
        int g = ((s >> 8 & 255) * sa * 255 + (d >> 8 & 255) * da * (255 - sa)) / den;
        int b = ((s & 255) * sa * 255 + (d & 255) * da * (255 - sa)) / den;
        return oa << 24 | r << 16 | g << 8 | b;
    }
}
