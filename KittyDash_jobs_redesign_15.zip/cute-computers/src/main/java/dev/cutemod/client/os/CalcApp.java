package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Calculator with mouse and keyboard input. */
public class CalcApp extends App {
    private static final char[][] KEYS = {
            {'C', '<', '%', '/'},
            {'7', '8', '9', '*'},
            {'4', '5', '6', '-'},
            {'1', '2', '3', '+'},
            {'~', '0', '.', '='}};
    private static final int BW = 36, BH = 21, GAP = 4;
    private static final int GRID_W = 4 * BW + 3 * GAP;
    private static final int X0 = (W - GRID_W) / 2, DISP_Y = 3, DISP_H = 30, Y0 = DISP_Y + DISP_H + 4;

    private final CalcLogic calc = new CalcLogic();

    @Override
    public Component title() { return Component.translatable("cutemod.os.calc"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.calc"); }

    private static int bx(int c) { return X0 + c * (BW + GAP); }

    private static int by(int r) { return Y0 + r * (BH + GAP); }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        int body = shell.color().bodyColor;
        Skin.rect(g, 0, 0, W, H, mix(body, 0xFFFFFF, 0.7f));
        // display
        Skin.rect(g, X0 - 1, DISP_Y - 1, GRID_W + 2, DISP_H + 2, 0xFF3A2A3A);
        Skin.rect(g, X0, DISP_Y, GRID_W, DISP_H, 0xFFEFF7E8);
        String pending = calc.pending();
        if (!pending.isEmpty()) {
            Skin.str(g, font(), pending, X0 + GRID_W - 4 - font().width(pending), DISP_Y + 3, 0xFF7A8A70, false);
        }
        String shown = calc.display();
        int scale = font().width(shown) * 2 <= GRID_W - 8 ? 2 : 1;
        int textW = font().width(shown) * scale;
        g.pose().pushPose();
        g.pose().translate(X0 + GRID_W - 4 - textW, DISP_Y + (scale == 2 ? 13 : 17), 0);
        g.pose().scale(scale, scale, 1f);
        Skin.str(g, font(), shown, 0, 0, 0xFF3A2A3A, false);
        g.pose().popPose();
        // buttons
        for (int r = 0; r < KEYS.length; r++) {
            for (int c = 0; c < 4; c++) {
                char k = KEYS[r][c];
                boolean op = k == '/' || k == '*' || k == '-' || k == '+';
                int base = k == '=' ? 0xFFF58FB8 : (op ? mix(body, 0xFFFFFF, 0.2f) : (Character.isDigit(k) || k == '.' ? 0xFFFFFFFF : 0xFFE9DDF2));
                boolean hover = in(mx, my, bx(c), by(r), BW, BH);
                Skin.rect(g, bx(c), by(r), BW, BH, 0xFF3A2A3A);
                Skin.rect(g, bx(c) + 1, by(r) + 1, BW - 2, BH - 2, hover ? mix(base & 0xFFFFFF, 0xFFFFFF, 0.5f) : base);
                String label = switch (k) { case '<' -> "<-"; case '~' -> "+/-"; default -> String.valueOf(k); };
                Skin.str(g, font(), label, bx(c) + (BW - font().width(label)) / 2, by(r) + (BH - 8) / 2, 0xFF3A2A3A, false);
            }
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int r = 0; r < KEYS.length; r++) {
            for (int c = 0; c < 4; c++) {
                if (in(x, y, bx(c), by(r), BW, BH)) { calc.press(KEYS[r][c]); return true; }
            }
        }
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        if ((c >= '0' && c <= '9') || c == '+' || c == '-' || c == '*' || c == '/' || c == '%' || c == '=') {
            calc.press(c);
            return true;
        }
        if (c == '.' || c == ',') { calc.press('.'); return true; }
        if (c == 'c' || c == 'C') { calc.press('C'); return true; }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        switch (keyCode) {
            case 257, 335 -> calc.press('=');
            case 259 -> calc.press('<');
            case 261 -> calc.press('C');
            default -> { return false; }
        }
        return true;
    }
}
