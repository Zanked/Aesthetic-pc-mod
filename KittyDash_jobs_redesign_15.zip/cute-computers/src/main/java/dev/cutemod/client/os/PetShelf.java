package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The shelf tab of the trips screen: the finds from the album stand on a shelf with 3 boards x 6 places.
 * Click a place: the next find that is not on the shelf yet (the last click empties the place). Right click empties it.
 * The shelf has 6 looks, two are free and the others are bought with coins. Saved in the Progress counters:
 * shelf_style (0-5), shelf_own (bits of the bought looks), shelf_0 .. shelf_17 (find number + 1, 0 = empty).
 */
final class PetShelf {
    static final int COLS = 6, ROWS = 3, SLOTS = COLS * ROWS, STYLES = 6;
    private static final int SX = 8, SY = 24, CELL = 32, ROW_H = 40, BOARD_H = 4;
    private static final int PX = 212, PY = 36, SW_W = 40, SW_H = 24;
    private static final int[] PRICE = {0, 0, 15, 25, 35, 60};
    //                                wall        board       edge
    private static final int[][] LOOK = {
            {0xFFF3E3C8, 0xFFB07A44, 0xFF7A4E28},   // wood
            {0xFFFFE3EE, 0xFFF58FB8, 0xFFC85A88},   // pink
            {0xFFE3F6EA, 0xFF7FCB9A, 0xFF4A9A6A},   // mint
            {0xFFDDF0FF, 0xFF9AD0F0, 0xFF5A9AC8},   // sky glass
            {0xFF1E1A3A, 0xFF4A3F7A, 0xFF2A2250},   // night
            {0xFFFFF4C8, 0xFFF0B90B, 0xFFB8860B}};  // gold
    /** A colour for each place of the trips (11). */
    private static final int[] PAL = {0xFFF58FB8, 0xFF4AA8F0, 0xFF4CAF50, 0xFF9A8AA8, 0xFF8A8AA0, 0xFFB9A8E0,
            0xFFF0B90B, 0xFF6AC8E8, 0xFFA8D8F0, 0xFFF4A0C0, 0xFFE5534B};

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    static int style() { return Math.max(0, Math.min(STYLES - 1, Progress.count("shelf_style"))); }

    static boolean owned(int s) { return PRICE[s] == 0 || (Progress.count("shelf_own") & (1 << s)) != 0; }

    private static int item(int slot) { return Progress.count("shelf_" + slot) - 1; }

    static int placed() {
        int n = 0;
        for (int i = 0; i < SLOTS; i++) if (item(i) >= 0) n++;
        return n;
    }

    private static boolean valid(int it) {
        return it >= 0 && it < Trip.DESTS * Trip.FINDS && Trip.found(it / Trip.FINDS, it % Trip.FINDS);
    }

    private static boolean onShelf(int it) {
        for (int i = 0; i < SLOTS; i++) if (item(i) == it) return true;
        return false;
    }

    /** Click on a place: the next find that is free (or the one that stands here now), after the last one the place is empty. */
    private static void cycle(int slot) {
        int cur = item(slot);
        List<Integer> cand = new ArrayList<>();
        for (int it = 0; it < Trip.DESTS * Trip.FINDS; it++) {
            if (valid(it) && (!onShelf(it) || it == cur)) cand.add(it);
        }
        int next = 0;                                                       // 0 = empty
        if (cur < 0) { if (!cand.isEmpty()) next = cand.get(0) + 1; }
        else {
            int pos = cand.indexOf(cur);
            if (pos >= 0 && pos + 1 < cand.size()) next = cand.get(pos + 1) + 1;
        }
        Progress.setCount("shelf_" + slot, next);
    }

    private static int slotAt(int mx, int my) {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (App.in(mx, my, SX + c * CELL + 2, SY + r * ROW_H, CELL - 2, ROW_H - 4)) return r * COLS + c;
            }
        }
        return -1;
    }

    private static int styleAt(int mx, int my) {
        for (int i = 0; i < STYLES; i++) {
            if (App.in(mx, my, PX + (i % 2) * (SW_W + 4), PY + (i / 2) * (SW_H + 8), SW_W, SW_H)) return i;
        }
        return -1;
    }

    private static boolean overClear(int mx, int my) { return App.in(mx, my, PX, 140, 2 * SW_W + 4, 14); }

    boolean click(int mx, int my, int button) {
        int s = slotAt(mx, my);
        if (s >= 0) {
            if (button == 1) Progress.setCount("shelf_" + s, 0); else cycle(s);
            return true;
        }
        int st = styleAt(mx, my);
        if (st >= 0 && button == 0) {
            if (owned(st)) Progress.setCount("shelf_style", st);
            else if (Progress.spend(PRICE[st])) {
                Progress.setCount("shelf_own", Progress.count("shelf_own") | (1 << st));
                Progress.setCount("shelf_style", st);
            }
            return true;
        }
        if (overClear(mx, my) && button == 0) {
            for (int i = 0; i < SLOTS; i++) Progress.setCount("shelf_" + i, 0);
            return true;
        }
        return true;
    }

    void render(GuiGraphics g, Font f, int mx, int my, int ticks) {
        int st = style();
        int[] look = LOOK[st];
        boolean night = st == 4;
        // the cabinet: a wall behind three boards
        Skin.rect(g, SX - 2, SY - 4, COLS * CELL + 6, ROWS * ROW_H + 8, look[2]);
        Skin.rect(g, SX, SY - 2, COLS * CELL + 2, ROWS * ROW_H, look[0]);
        if (night) {
            for (int i = 0; i < 14; i++) {
                if ((ticks / 20 + i) % 5 == 0) continue;                       // twinkle
                Skin.rect(g, SX + 4 + (i * 41) % (COLS * CELL - 6), SY + (i * 23) % (ROWS * ROW_H - 8), 1, 1, 0xFFFFFFFF);
            }
        } else if (st == 3) {
            for (int i = 0; i < 5; i++) Skin.rect(g, SX + 10 + i * 8, SY - 2, 3, ROWS * ROW_H, 0x30FFFFFF);   // glass shine
        }
        int hover = slotAt(mx, my);
        String tip = "";
        for (int r = 0; r < ROWS; r++) {
            int by = SY + r * ROW_H + (ROW_H - 4) - BOARD_H + 4;
            Skin.rect(g, SX - 2, by, COLS * CELL + 6, BOARD_H, look[1]);
            Skin.rect(g, SX - 2, by + BOARD_H, COLS * CELL + 6, 2, look[2]);
            Skin.rect(g, SX - 2, by, COLS * CELL + 6, 1, App.mix(look[1], 0xFFFFFFFF, 0.4f));
            for (int c = 0; c < COLS; c++) {
                int slot = r * COLS + c;
                int x = SX + c * CELL + 2, y = SY + r * ROW_H;
                boolean over = hover == slot;
                if (over) Skin.rect(g, x, y, CELL - 2, ROW_H - 4, night ? 0x28FFFFFF : 0x22000000);
                int it = item(slot);
                if (it >= 0 && !valid(it)) it = -1;
                if (it >= 0) {
                    int d = it / Trip.FINDS, k = it % Trip.FINDS;
                    int bob = over ? -1 : 0;
                    Skin.rect(g, x + 5, by - 1, CELL - 12, 1, 0x22000000);        // a little shadow
                    icon(g, x + (CELL - 2) / 2, by - 18 + bob, d, k, ticks, slot);
                    if (over) tip = t("cutemod.trip.find." + d + "." + k) + "  (" + t("cutemod.trip.dest." + d) + ")";
                } else if (over && Trip.albumCount() > placed()) {
                    Skin.rect(g, x + 10, by - 11, 10, 1, 0x88FFFFFF);
                    Skin.rect(g, x + 14, by - 15, 1, 9, 0x88FFFFFF);               // a plus: there is something to put here
                }
            }
        }

        // the right side: the looks of the shelf
        Skin.str(g, f, t("cutemod.trip.shelf.looks"), PX, 24, 0xFF5A4A86, false);
        int hs = styleAt(mx, my);
        for (int i = 0; i < STYLES; i++) {
            int x = PX + (i % 2) * (SW_W + 4), y = PY + (i / 2) * (SW_H + 8);
            int[] lk = LOOK[i];
            if (i == st) Skin.rect(g, x - 2, y - 2, SW_W + 4, SW_H + 4, 0xFF4A7BD0);
            else if (hs == i) Skin.rect(g, x - 1, y - 1, SW_W + 2, SW_H + 2, 0xFFB9A3D6);
            Skin.rect(g, x, y, SW_W, SW_H, lk[0]);
            Skin.rect(g, x, y + SW_H - 7, SW_W, 4, lk[1]);
            Skin.rect(g, x, y + SW_H - 3, SW_W, 3, lk[2]);
            Skin.rect(g, x + 6, y + SW_H - 15, 8, 8, App.mix(lk[1], 0xFFFFFFFF, 0.2f));   // a tiny item
            Skin.rect(g, x + 24, y + SW_H - 12, 6, 5, App.mix(lk[2], 0xFFFFFFFF, 0.2f));
            if (!owned(i)) {
                Skin.rect(g, x, y, SW_W, SW_H, 0xB0F6F0FA);
                String p = Integer.toString(PRICE[i]);
                int w = f.width(p) + 9;
                Skin.str(g, f, p, x + (SW_W - w) / 2, y + 8, 0xFF3A2A3A, false);
                Progress.drawCoin(g, x + (SW_W - w) / 2 + f.width(p) + 2, y + 8);
            }
            if (hs == i) tip = t("cutemod.trip.shelf.style." + i) + (owned(i) ? "" : "  (" + PRICE[i] + ")");
        }
        boolean oc = overClear(mx, my);
        Skin.rect(g, PX, 140, 2 * SW_W + 4, 14, oc ? 0xFFFFD866 : 0xFFE9DDF2);
        String cl = t("cutemod.trip.shelf.clear");
        Skin.str(g, f, cl, PX + (2 * SW_W + 4 - f.width(cl)) / 2, 143, 0xFF3A2A3A, false);

        // bottom line: a name or a hint
        String line = tip.isEmpty() ? t(Trip.albumCount() == 0 ? "cutemod.trip.shelf.none" : "cutemod.trip.shelf.hint") : tip;
        Skin.str(g, f, f.plainSubstrByWidth(line, W_TEXT), 8, 154, tip.isEmpty() ? 0xFF8A7AA8 : 0xFF3A2A3A, false);
    }

    private static final int W_TEXT = 200;

    // ---------- the little things ----------
    private static int dark(int c) { return App.mix(c, 0xFF000000, 0.35f); }

    private static int light(int c) { return App.mix(c, 0xFFFFFFFF, 0.5f); }

    /** One find, about 16 x 16 pixels around (cx, base-8). The shape tells how rare it is, the colour tells the place. */
    private static void icon(GuiGraphics g, int cx, int top, int d, int k, int ticks, int slot) {
        int c = PAL[d % PAL.length], dk = dark(c), lt = light(c);
        int cy = top + 8;
        switch (k) {
            case 0 -> {                                                      // a round thing: pebble, shell, ball
                Skin.disc(g, cx, cy, 7, dk);
                Skin.disc(g, cx, cy, 6, c);
                Skin.disc(g, cx - 2, cy - 2, 2, lt);
            }
            case 1 -> {                                                      // a little gift box
                Skin.rect(g, cx - 7, cy - 6, 14, 13, dk);
                Skin.rect(g, cx - 6, cy - 5, 12, 11, c);
                Skin.rect(g, cx - 1, cy - 6, 2, 13, 0xFFFFFFFF);
                Skin.rect(g, cx - 7, cy - 1, 14, 2, 0xFFFFFFFF);
                Skin.rect(g, cx - 3, cy - 8, 3, 2, 0xFFFFFFFF); Skin.rect(g, cx + 1, cy - 8, 3, 2, 0xFFFFFFFF);
            }
            case 2 -> {                                                      // a gem
                for (int dy = -8; dy <= 8; dy++) {
                    int half = 8 - Math.abs(dy);
                    Skin.rect(g, cx - half, cy + dy, half * 2 + 1, 1, dk);
                    if (half > 1) Skin.rect(g, cx - half + 1, cy + dy, half * 2 - 1, 1, dy < 0 ? lt : c);
                }
                Skin.rect(g, cx - 2, cy - 5, 2, 2, 0xFFFFFFFF);
            }
            default -> {                                                     // the rare find: a golden crown with a gem
                Skin.rect(g, cx - 8, cy + 2, 16, 5, 0xFFB8860B);
                Skin.rect(g, cx - 7, cy + 3, 14, 3, 0xFFFFC832);
                for (int s = -1; s <= 1; s++) {
                    Skin.rect(g, cx + s * 6 - 1, cy - 6, 3, 8, 0xFFFFC832);
                    Skin.rect(g, cx + s * 6, cy - 7, 1, 1, 0xFFFFC832);
                }
                Skin.rect(g, cx - 1, cy + 3, 3, 3, c);
                int sp = (ticks / 14 + slot) % 6;                            // a sparkle that walks around
                if (sp < 3) Skin.rect(g, cx - 8 + sp * 7, cy - 8 + (sp % 2) * 3, 2, 2, 0xFFFFFFFF);
            }
        }
    }
}
