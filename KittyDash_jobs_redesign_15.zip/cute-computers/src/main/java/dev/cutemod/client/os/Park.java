package dev.cutemod.client.os;

import dev.cutemod.data.ParkData;
import dev.cutemod.net.ParkActionPayload;
import dev.cutemod.net.ParkMovePayload;
import dev.cutemod.net.ParkSayPayload;
import dev.cutemod.net.ParkSyncPayload;
import dev.cutemod.net.PetLook;
import net.neoforged.neoforge.network.PacketDistributor;

/** The Pet Park on the client: sends where our pet stands, keeps the last answer and the news (we played, danced, gave or got a treat). */
public final class Park {
    private Park() {}

    private static ParkSyncPayload last;
    private static boolean full;
    private static int played, treat, plays, gift;       // played: 0 / 1 played / 5 danced; treat: 0 / 4 our treat arrived
    private static String with = "";

    public static void apply(ParkSyncPayload p) {
        last = p;
        int ev = p.event();
        if (ev == 2) full = true;
        if (p.prize() > 0) Progress.earn(p.prize());
        if (ev == 1 || ev == 3 || ev == 4 || ev == 5) {
            with = p.with();
            plays = p.plays();
            gift = Math.max(0, Math.min(ParkData.GIFTS.length - 1, p.gift()));
            if (ev == 1 || ev == 5) played = ev;
            if (ev == 3 || ev == 4) {
                String id = ParkData.GIFTS[gift];
                if (ev == 3) {                                                                // somebody gave us a treat: a pop-up, wherever we are
                    Progress.setCount("stock_" + id, Progress.stock(id) + 1);
                    Progress.toast("cutemod.park.got", with, net.minecraft.network.chat.Component.translatable("cutemod.shop.item." + id).getString());
                } else {                                                                      // the treat we gave has arrived
                    treat = 4;
                    Progress.useTreat(id);
                }
            }
            int step = ev == 1 || ev == 5 ? 1 : 2;
            int lvl = ParkData.level(plays);
            if (lvl >= 2 && lvl > ParkData.level(plays - step)) Progress.toast("cutemod.park.friend." + lvl, with);
        }
    }

    public static ParkSyncPayload last() { return last; }

    /** 1 or 5 (played, danced) once after we did it with somebody, otherwise 0. */
    public static int takePlayed() { int r = played; played = 0; return r; }

    /** 4 once after the treat we gave has arrived, otherwise 0 (a treat we got shows a pop-up at once). */
    public static int takeTreat() { int r = treat; treat = 0; return r; }

    public static boolean takeFull() { boolean r = full; full = false; return r; }

    public static String with() { return with; }

    public static int plays() { return plays; }

    /** The index in {@link ParkData#GIFTS} of the last treat that was given or received. */
    public static int gift() { return gift; }

    public static void clear() { last = null; played = 0; treat = 0; full = false; }

    /** Tell the server where the pet of this color stands. False if there is no such pet. */
    public static boolean move(String colorId, int x, int y, int emote) {
        PetBlob.Info i = PetBlob.parse(Store.read("pet_" + colorId));
        if (i == null) return false;
        PacketDistributor.sendToServer(new ParkMovePayload(colorId, i.sick(),
                new PetLook(i.stage(), i.trait(), i.ageMin(), s24(Progress.equipped()), s24(Progress.equippedBody()), PetName.custom(colorId), PetArt.ownVariant(PetShow.colorOf(colorId))), x, y, emote));
        return true;
    }

    public static void leave() {
        PacketDistributor.sendToServer(new ParkActionPayload("", 0, 0));
        clear();
    }

    /** Do something with the pet of this owner (a player's UUID or a resident's "bot:..." id): 0 play, 2 give the treat ParkData.GIFTS[gift], 3 dance. */
    public static void act(String ownerId, int kind, int gift) { PacketDistributor.sendToServer(new ParkActionPayload(ownerId, kind, gift)); }

    /** Say quick phrase number {@code id} (1 to ParkData.SAY_COUNT). */
    public static void say(int id) { PacketDistributor.sendToServer(new ParkSayPayload(id)); }

    private static String s24(String s) { return s == null || s.length() > 64 ? "" : s; }
}
