package dev.cutemod.client.os;

import dev.cutemod.net.SaveDataPayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * The client's copy of what the SERVER has saved for this player. Reading is local; every write is
 * also sent to the server, which keeps it in the world save. {@link #gen()} changes whenever the
 * copy is replaced (joining another server or world), so the apps know to load again.
 */
public final class Store {
    private Store() {}

    private static final Map<String, String> data = new HashMap<>();
    private static boolean ready;
    private static int gen;

    public static void apply(Map<String, String> m) {
        data.clear();
        data.putAll(m);
        ready = true;
        gen++;
    }

    public static void clear() {
        data.clear();
        ready = false;
        gen++;
    }

    public static boolean ready() { return ready; }

    public static int gen() { return gen; }

    public static String read(String name) { return data.get(name); }

    /** Save text under a name (an empty text deletes it). Nothing is sent if it did not change. */
    public static void write(String name, String text) {
        if (!ready) return;
        String old = data.get(name);
        if (text.equals(old == null ? "" : old)) return;
        if (text.isEmpty()) data.remove(name);
        else data.put(name, text);
        PacketDistributor.sendToServer(new SaveDataPayload(name, text));
    }

    public static Properties readProps(String name) {
        String s = read(name);
        if (s == null) return null;
        try {
            Properties p = new Properties();
            p.load(new StringReader(s));
            return p;
        } catch (Exception e) {
            return null;
        }
    }

    public static void writeProps(String name, Properties p) {
        try {
            StringWriter w = new StringWriter();
            p.store(w, null);
            StringBuilder sb = new StringBuilder();
            for (String line : w.toString().split("\\R")) if (!line.startsWith("#")) sb.append(line).append('\n');   // no date comment: the text only changes when the data does
            write(name, sb.toString());
        } catch (Exception ignored) {
        }
    }
}
