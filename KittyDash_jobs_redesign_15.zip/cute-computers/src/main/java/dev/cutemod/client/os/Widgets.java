package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;

/**
 * Desktop widgets. Left column: a music player (while a song plays), the parcels of CuteMarket on their way
 * and a timer. Right column: a calendar and a clock. Right-click the empty desktop to add or remove them
 * (right-click a widget removes it). The choice is saved on the server. The cards are rounded and take their colours from the look that is on (see Theme.pal).
 */
public final class Widgets {
    private Widgets() {}

    public static final int PLAYER = 1, ORDERS = 2, TIMER = 4, CALENDAR = 8, CLOCK = 16, ALL = 31;
    public static final int NONE = 0, USED = 1, OPEN_MARKET = 2, REMOVED = 3;
    private static final int X = 8, WW = 120, GAP = 4;
    private static final int CAL_W = 46, CAL_H = 48, CLK_H = 22;

    private static int mask = ALL, gen = -1;
    private static boolean timerRun;
    private static long timerEnd, timerLeft;

    // where each left-column widget is this frame (-1 = not shown)
    private static int yPlayer = -1, yOrders = -1, yTimer = -1, hOrders;

    private static int mask() {
        if (gen != Store.gen()) {
            gen = Store.gen();
            mask = ALL;
            String s = Store.read("widgets");
            if (s != null && !s.isBlank()) {
                try { mask = Integer.parseInt(s.trim()) & ALL; } catch (NumberFormatException ignored) { }
            }
        }
        return mask;
    }

    public static boolean on(int bit) { return (mask() & bit) != 0; }

    public static void toggle(int bit) {
        mask();
        mask ^= bit;
        Store.write("widgets", Integer.toString(mask));
    }

    // ---------- the timer keeps running when the desktop is not in front ----------
    private static long left() { return timerRun ? Math.max(0, timerEnd - System.currentTimeMillis()) : timerLeft; }

    public static void tick() {
        if (timerRun && System.currentTimeMillis() >= timerEnd) {
            timerRun = false;
            timerLeft = 0;
            Progress.toast("cutemod.widget.timer_done");
            Sfx.powerOn();
        }
    }

    private static void addTime(long ms) {
        long l = Math.min(99 * 60_000L, left() + ms);
        if (timerRun) timerEnd = System.currentTimeMillis() + l; else timerLeft = l;
    }

    // ---------- look: colours and shapes come from the palette of the look that is on (Theme.pal), cards are rounded ----------
    private static void box(GuiGraphics g, int x, int y, int w, int h) { Theme.card(g, x, y, w, h); }

    private static int text() { return Theme.pal().text(); }

    private static int muted() { return Theme.pal().muted(); }

    private static int accent() { return Theme.pal().label(); }      // the small titles on the cards

    private static int good() { return Theme.pal().good(); }

    /** A pill-shaped button with a soft gloss (Retro 98: a square grey one with raised edges, sunken while the mouse is on it). */
    private static void button(GuiGraphics g, Font f, int x, int y, int w, int h, String s, boolean hov) {
        Theme.Pal p = Theme.pal();
        int face = hov ? p.buttonHover() : p.button();
        int ink;
        if (p.bevel()) {
            Theme.bevel(g, x, y, w, h, !hov, face);
            ink = p.text();
        } else {
            Theme.rrect(g, x, y + 1, w, h, h / 2, 0x26000000);                                        // a hint of shadow
            Theme.rgrad(g, x, y, w, h, h / 2, Theme.blend(face, 0xFFFFFFFF, 0.28f), face);
            Theme.rgrad(g, x + 2, y + 1, w - 4, Math.max(2, h / 2 - 1), h / 4, 0x40FFFFFF, 0x00FFFFFF);   // the gloss
            ink = 0xFFFFFFFF;
        }
        CuteFont.draw(g, f, s, x + (w - f.width(s)) / 2, y + (h - 8) / 2 + 1, ink, false);
    }

    /** A rounded progress bar: a track and a fill up to frac (0..1). */
    private static void bar(GuiGraphics g, int x, int y, int w, int h, float frac) {
        Theme.Pal p = Theme.pal();
        int r = p.bevel() ? 0 : h / 2;
        Theme.rrect(g, x, y, w, h, r, p.field());
        int fw = Math.round(w * Math.max(0f, Math.min(1f, frac)));
        if (fw > 0) Theme.rrect(g, x, y, Math.max(fw, Math.min(w, h)), h, r, p.bar());
    }

    private static boolean in(int px, int py, int x, int y, int w, int h) { return px >= x && py >= y && px < x + w && py < y + h; }

    // ---------- layout ----------
    private static void layout(MusicApp music) {
        int y = 8;
        yPlayer = yOrders = yTimer = -1;
        if (on(PLAYER) && music != null && music.active()) { yPlayer = y; y += 32 + GAP; }
        int parcels = on(ORDERS) ? Market.active() : 0;
        if (parcels > 0) { yOrders = y; hOrders = 13 + Math.min(3, parcels) * 10; y += hOrders + GAP; }
        if (on(TIMER)) yTimer = y;
    }

    private static int calX() { return App.W - 56; }

    private static int clockY() { return 8 + (on(CALENDAR) ? CAL_H + GAP : 0); }

    // ---------- drawing ----------
    public static void render(GuiGraphics g, MusicApp music, int mx, int my) {
        Font f = Minecraft.getInstance().font;
        layout(music);
        if (yPlayer >= 0) {
            int y = yPlayer;
            box(g, X, y, WW, 32);
            g.fill(X + 5, y + 5, X + 7, y + 10, accent()); g.fill(X + 7, y + 4, X + 9, y + 5, accent()); g.fill(X + 3, y + 8, X + 5, y + 11, accent());
            CuteFont.draw(g, f, f.plainSubstrByWidth(music.trackName(), WW - 24), X + 13, y + 3, text(), false);
            bar(g, X + 6, y + 14, WW - 12, 4, music.progress());
            button(g, f, X + 8, y + 20, 24, 10, "<<", in(mx, my, X + 8, y + 20, 24, 10));
            button(g, f, X + 48, y + 20, 24, 10, music.isPlaying() ? "||" : ">", in(mx, my, X + 48, y + 20, 24, 10));
            button(g, f, X + 88, y + 20, 24, 10, ">>", in(mx, my, X + 88, y + 20, 24, 10));
        }
        if (yOrders >= 0) {
            int y = yOrders;
            box(g, X, y, WW, hOrders);
            CuteFont.draw(g, f, Component.translatable("cutemod.widget.orders", Market.active()), X + 5, y + 3, accent(), false);
            List<Market.Order> list = Market.orders();
            for (int i = 0; i < list.size() && i < 3; i++) {
                Market.Order o = list.get(i);
                int ry = y + 13 + i * 10;
                CuteFont.draw(g, f, f.plainSubstrByWidth(MarketApp.name(o.id), 66), X + 5, ry, text(), false);
                String right;
                int col;
                if (Market.arrived(o)) { right = Component.translatable("cutemod.widget.arrived").getString(); col = good(); }
                else { int s = Market.secondsLeft(o); right = (s / 60) + ":" + String.format("%02d", s % 60); col = muted(); }
                CuteFont.draw(g, f, right, X + WW - 5 - f.width(right), ry, col, false);
            }
        }
        if (yTimer >= 0) {
            int y = yTimer;
            box(g, X, y, WW, 34);
            long l = left();
            String time = (l / 60000) + ":" + String.format("%02d", (l / 1000) % 60);
            g.pose().pushPose();
            g.pose().translate(X + 6, y + 4, 0);
            g.pose().scale(1.6f, 1.6f, 1f);
            CuteFont.draw(g, f, time, 0, 0, l == 0 && !timerRun ? muted() : (timerRun ? good() : accent()), false);
            g.pose().popPose();
            Component name = Component.translatable("cutemod.widget.timer");
            CuteFont.draw(g, f, name, X + WW - 5 - f.width(name), y + 3, muted(), false);
            button(g, f, X + 6, y + 22, 24, 10, "+1", in(mx, my, X + 6, y + 22, 24, 10));
            button(g, f, X + 33, y + 22, 24, 10, "+5", in(mx, my, X + 33, y + 22, 24, 10));
            button(g, f, X + 60, y + 22, 26, 10, timerRun ? "||" : ">", in(mx, my, X + 60, y + 22, 26, 10));
            button(g, f, X + 89, y + 22, 26, 10, "0", in(mx, my, X + 89, y + 22, 26, 10));
        }
        if (on(CALENDAR)) calendar(g, f);
        if (on(CLOCK)) clock(g, f);
    }

    private static void calendar(GuiGraphics g, Font f) {
        LocalDate d = LocalDate.now();
        int x = calX(), y = 8, w = CAL_W, h = CAL_H;
        Theme.Pal p = Theme.pal();
        int hh = 13;                                                                  // the height of the coloured header
        if (p.bevel()) {
            Theme.bevel(g, x, y, w, h, true, p.paper());
            g.fill(x + 2, y + 2, x + w - 2, y + hh, p.head());
        } else {
            int r = p.radius();
            Theme.rrect(g, x + 1, y + 2, w, h, r, 0x30000000);                         // a soft shadow
            Theme.rrect(g, x - 1, y - 1, w + 2, h + 2, r + 1, 0x77FFFFFF);
            Theme.rgrad(g, x, y, w, h, r, p.paper(), Theme.blend(p.paper(), p.head(), 0.14f));
            Theme.rgradTop(g, x, y, w, hh, r, Theme.blend(p.head(), 0xFFFFFFFF, 0.22f), p.head());
            Theme.rgradTop(g, x + 1, y + 1, w - 2, hh / 2, Math.max(0, r - 1), 0x33FFFFFF, 0x00FFFFFF);
        }
        String month = d.getMonth().getDisplayName(TextStyle.SHORT, Locale.getDefault()).toUpperCase(Locale.ROOT);
        CuteFont.draw(g, f, month, x + (w - f.width(month)) / 2, y + 3, 0xFFFFFFFF, false);
        String day = Integer.toString(d.getDayOfMonth());
        g.pose().pushPose();
        g.pose().translate(x + w / 2f, y + 20, 0);
        g.pose().scale(2.2f, 2.2f, 1f);
        CuteFont.draw(g, f, day, -f.width(day) / 2, 0, p.ink(), false);
        g.pose().popPose();
        String dow = d.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.getDefault());
        CuteFont.draw(g, f, dow, x + (w - f.width(dow)) / 2, y + h - 10, p.inkSoft(), false);
    }

    private static void clock(GuiGraphics g, Font f) {
        LocalTime now = LocalTime.now();
        int x = calX(), y = clockY(), w = CAL_W;
        box(g, x, y, w, CLK_H);
        String s = String.format("%02d:%02d", now.getHour(), now.getMinute());
        g.pose().pushPose();
        g.pose().translate(x + (w - f.width(s) * 1.3f) / 2f, y + 3, 0);
        g.pose().scale(1.3f, 1.3f, 1f);
        CuteFont.draw(g, f, s, 0, 0, text(), false);
        g.pose().popPose();
        bar(g, x + 5, y + CLK_H - 6, w - 10, 3, now.getSecond() / 60f);
    }

    /** Is this point on a widget? Returns which one (a bit), 0 if none. */
    private static int hit(MusicApp music, int x, int y) {
        layout(music);
        if (yPlayer >= 0 && in(x, y, X, yPlayer, WW, 32)) return PLAYER;
        if (yOrders >= 0 && in(x, y, X, yOrders, WW, hOrders)) return ORDERS;
        if (yTimer >= 0 && in(x, y, X, yTimer, WW, 34)) return TIMER;
        if (on(CALENDAR) && in(x, y, calX(), 8, CAL_W, CAL_H)) return CALENDAR;
        if (on(CLOCK) && in(x, y, calX(), clockY(), CAL_W, CLK_H)) return CLOCK;
        return 0;
    }

    /** A click on the desktop: NONE if no widget was hit. A right click removes the widget. */
    public static int click(MusicApp music, int x, int y, int button) {
        int h = hit(music, x, y);
        if (h == 0) return NONE;
        if (button == 1) { toggle(h); return REMOVED; }
        switch (h) {
            case PLAYER -> {
                if (in(x, y, X + 8, yPlayer + 20, 24, 10)) music.prevTrack();
                else if (in(x, y, X + 48, yPlayer + 20, 24, 10)) music.toggle();
                else if (in(x, y, X + 88, yPlayer + 20, 24, 10)) music.nextTrack();
            }
            case ORDERS -> { return OPEN_MARKET; }
            case TIMER -> {
                if (in(x, y, X + 6, yTimer + 22, 24, 10)) addTime(60_000L);
                else if (in(x, y, X + 33, yTimer + 22, 24, 10)) addTime(300_000L);
                else if (in(x, y, X + 60, yTimer + 22, 26, 10)) {
                    if (timerRun) { timerLeft = left(); timerRun = false; }
                    else if (timerLeft > 0) { timerEnd = System.currentTimeMillis() + timerLeft; timerRun = true; }
                } else if (in(x, y, X + 89, yTimer + 22, 26, 10)) { timerRun = false; timerLeft = 0; }
            }
            default -> { }
        }
        return USED;
    }

    // ---------- the "add widgets" menu (right click on the empty desktop) ----------
    private static final int[] MENU_BITS = {PLAYER, ORDERS, TIMER, CALENDAR, CLOCK};
    private static final String[] MENU_KEYS = {"cutemod.widget.player", "cutemod.widget.orders_name", "cutemod.widget.timer", "cutemod.widget.calendar", "cutemod.widget.clock"};
    private static final int MW = 100, MROW = 12, MHEAD = 12;

    public static int menuH() { return MHEAD + (MENU_BITS.length + 1) * MROW + 2; }    // the first row makes a new folder

    public static int menuW() { return MW; }

    public static void renderMenu(GuiGraphics g, int mx, int my, int px, int py) {
        Font f = Minecraft.getInstance().font;
        Theme.Pal p = Theme.pal();
        Theme.card(g, px, py, MW, menuH());
        CuteFont.draw(g, f, Component.translatable("cutemod.widget.menu"), px + 6, py + 2, muted(), false);
        int ny = py + MHEAD;                                                   // "New folder"
        boolean hovNew = in(mx, my, px, ny, MW, MROW);
        if (hovNew) menuRow(g, p, px, ny);
        int plus = hovNew ? p.onAccent() : accent();
        g.fill(px + 8, ny + 3, px + 10, ny + 9, plus);
        g.fill(px + 6, ny + 5, px + 12, ny + 7, plus);
        CuteFont.draw(g, f, Component.translatable("cutemod.folder.new"), px + 16, ny + 2, hovNew ? p.onAccent() : text(), false);
        for (int i = 0; i < MENU_BITS.length; i++) {
            int y = py + MHEAD + (i + 1) * MROW;
            boolean hov = in(mx, my, px, y, MW, MROW);
            if (hov) menuRow(g, p, px, y);
            boolean on = on(MENU_BITS[i]);
            Theme.rrect(g, px + 6, y + 2, 8, 8, p.bevel() ? 0 : 3, on ? good() : p.field());
            CuteFont.draw(g, f, Component.translatable(MENU_KEYS[i]), px + 18, y + 2, hov ? p.onAccent() : text(), false);
        }
    }

    /** The highlight of the row under the mouse in the add-widgets menu: a rounded bar (Retro 98: a navy one). */
    private static void menuRow(GuiGraphics g, Theme.Pal p, int px, int y) {
        Theme.rrect(g, px + 3, y, MW - 6, MROW, p.bevel() ? 0 : 4, p.accent());
    }

    /** A click inside the menu toggles the row under it; any click closes the menu. True: the "New folder" row was hit. */
    public static boolean clickMenu(int x, int y, int px, int py) {
        if (in(x, y, px, py + MHEAD, MW, MROW)) return true;
        for (int i = 0; i < MENU_BITS.length; i++) {
            if (in(x, y, px, py + MHEAD + (i + 1) * MROW, MW, MROW)) { toggle(MENU_BITS[i]); return false; }
        }
        return false;
    }

    /** Is a widget drawn on this point of the desktop? (A folder is not dropped under a widget.) */
    public static boolean covers(MusicApp music, int x, int y) { return hit(music, x, y) != 0; }
}
