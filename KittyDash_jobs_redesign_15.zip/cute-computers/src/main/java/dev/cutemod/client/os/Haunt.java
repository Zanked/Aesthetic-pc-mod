package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Things that happen on their own while you use the computer: annoying pop-up "ads" and a few
 * creepy events (eyes, glitches, whispers, a haunted record). Everything is display-only,
 * nothing is saved or changed. Both parts can be switched off in Settings.
 */
public class Haunt {
    public static boolean scary = true;
    public static boolean popups = true;

    private static final int W = App.W, H = App.H;
    private static final int POP_W = 160, POP_H = 70, MAX_POPUPS = 5;
    /** The room for the message of a pop-up: between the title bar and the buttons. */
    private static final int MSG_Y = 17, MSG_H = 36;
    private static final int[] TITLE_COLORS = {0xFFF5C518, 0xFFE5484D, 0xFF5BBF6A};

    private static final class Popup {
        int x, y, type, slot, dodges;
    }

    private final Random rnd = new Random();
    private final List<Popup> pops = new ArrayList<>();
    private int mx = -100, my = -100;
    private boolean game;
    private boolean browser;   // pop-up ads live only in the in-game browser
    private boolean cursed;    // ... and on the haunted site (666) they are crimson

    private int nextPopup = 900 + rnd.nextInt(900);   // first pop-up after 15-30 s in the browser
    private int eventTimer = 2400 + rnd.nextInt(3600); // creepy event every 40-100 s
    private int event = -1, evTimer, evTotal, evA, evB, evSeed;
    private int recordTimer;

    // ---------- helpers ----------
    private static Font font() { return Minecraft.getInstance().font; }

    private static String t(String key) { return Component.translatable(key).getString(); }

    private static void rect(GuiGraphics g, int x, int y, int w, int h, int argb) { g.fill(x, y, x + w, y + h, argb); }

    private static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && py >= y && px < x + w && py < y + h;
    }

    private static void sound(float pitch, float volume) {
        Sfx.ui(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_CHIME.value(), pitch, volume);
    }

    private static int closeX(int slot) { return slot == 0 ? POP_W - 13 : slot == 1 ? 2 : POP_W / 2 - 5; }

    /** The "record" in the footer is replaced by a creepy one for a few seconds. */
    public boolean recordHaunted() { return scary && recordTimer > 0; }

    // ---------- logic (60 times a second) ----------
    public void tick(App app) {
        game = app instanceof GameApp;
        boolean web = app instanceof BrowserApp;
        browser = web;
        cursed = web && ((BrowserApp) app).cursedSite();
        if (!web || !popups) pops.clear();   // leave the browser (or switch ads off) and the ads are gone

        if (popups && web && --nextPopup <= 0) {
            spawnPopup();
            nextPopup = 1800 + rnd.nextInt(2400); // next one in 30-70 s
        }

        // the "x" of a pop-up runs away from the mouse a few times
        if (!game) {
            for (Popup p : pops) {
                if (p.type == 3 || p.dodges >= 4) continue;
                int cx = p.x + closeX(p.slot) + 5, cy = p.y + 7;
                if (Math.abs(mx - cx) < 14 && Math.abs(my - cy) < 12) {
                    p.slot = (p.slot + 1 + rnd.nextInt(2)) % 3;
                    p.dodges++;
                }
            }
        }

        if (!scary) return;
        if (event < 0) {
            if (--eventTimer <= 0) startEvent(rnd.nextInt(3));
        } else if (--evTimer <= 0) {
            event = -1;
            eventTimer = 3600 + rnd.nextInt(3600);
        }
        if (recordTimer > 0) recordTimer--;
        else if (app.showRecord() && rnd.nextInt(2400) == 0) { recordTimer = 300; sound(0.5F, 0.5F); }
    }

    private void startEvent(int type) {
        event = type;
        evTotal = evTimer = type == 0 ? 150 : type == 1 ? 30 : 200;
        evA = 10 + rnd.nextInt(W - 50);
        evB = type == 0 ? (rnd.nextBoolean() ? 8 : H - 16) : rnd.nextInt(4);
        evSeed = rnd.nextInt();
        if (type != 1) sound(0.5F, 0.5F);
    }

    private void spawnPopup() {
        if (pops.size() >= MAX_POPUPS) return;
        Popup p = new Popup();
        p.type = (scary && rnd.nextInt(6) == 0) ? 3 : rnd.nextInt(3);
        p.x = rnd.nextInt(W - POP_W);
        p.y = 4 + rnd.nextInt(H - POP_H - 8);
        pops.add(p);
        sound(1.8F, 0.3F);
    }

    // ---------- render ----------
    public void render(GuiGraphics g, int mouseX, int mouseY) {
        mx = mouseX;
        my = mouseY;
        if (scary && event >= 0) renderEvent(g);
        if (browser) renderPopups(g);
    }

    private void renderEvent(GuiGraphics g) {
        Font f = font();
        int a = Math.min(255, Math.min(evTimer, evTotal - evTimer) * 10);
        switch (event) {
            case 0 -> { // eyes in the dark
                boolean blink = (evTimer % 70) < 5;
                rect(g, evA - 3, evB - 3, 24, 9, ((a / 5) << 24) | 0xFF0000);
                if (a < 8) return;
                if (!blink) {
                    rect(g, evA, evB, 7, 3, (a << 24) | 0xFF2A2A);
                    rect(g, evA + 13, evB, 7, 3, (a << 24) | 0xFF2A2A);
                    rect(g, evA + 3, evB + 1, 2, 1, a << 24);
                    rect(g, evA + 16, evB + 1, 2, 1, a << 24);
                } else {
                    rect(g, evA, evB + 1, 7, 1, (a << 24) | 0x7A1010);
                    rect(g, evA + 13, evB + 1, 7, 1, (a << 24) | 0x7A1010);
                }
            }
            case 1 -> { // the picture glitches
                Random r = new Random(evSeed + (evTimer / 3) * 7919L);
                if (evTimer > evTotal - 3 || r.nextInt(5) == 0) rect(g, 0, 0, W, H, 0x88000000);
                int[] cols = {0x66FF00FF, 0x6600FFFF, 0xAA000000, 0x66FFFF00};
                for (int i = 0; i < 7; i++) {
                    int y = r.nextInt(H), h = 1 + r.nextInt(6), x = r.nextInt(W / 2), w = 40 + r.nextInt(W);
                    rect(g, x, y, w, h, cols[r.nextInt(cols.length)]);
                }
            }
            default -> { // a whisper on the screen
                if (a < 8) return;
                String s = t("cutemod.haunt.whisper." + evB);
                rect(g, 0, H - 19, W, 14, ((a / 2) << 24));
                CuteFont.draw(g, f, s, (W - f.width(s)) / 2, H - 16, (a << 24) | 0xD9302A, false);
            }
        }
    }

    private void renderPopups(GuiGraphics g) {
        Font f = font();
        int n = 0;
        for (Popup p : pops) {
            boolean ghost = p.type == 3;                 // the "System" one that stares back
            boolean dark = ghost || cursed;              // on the haunted site every ad is crimson and black
            int x = p.x, y = p.y;
            g.pose().pushPose();
            g.pose().translate(0, 0, 8 * n++);           // each ad above the one below it (its text too)
            rect(g, x - 1, y - 1, POP_W + 2, POP_H + 2, dark ? (cursed ? 0xFF8A0A14 : 0xFF5A0F15) : 0xFF3A2A4A);
            rect(g, x, y, POP_W, POP_H, dark ? (cursed ? 0xFF140203 : 0xFF0D0A10) : 0xFFF6F0FA);   // opaque: nothing shines through
            rect(g, x, y, POP_W, 14, dark ? (cursed ? 0xFF4A0710 : 0xFF5A0F15) : TITLE_COLORS[p.type]);
            if (cursed) {                                // blood running from the title bar
                for (int k = 0; k < 5; k++) {
                    int h = 2 + (p.x * 7 + p.y * 3 + k * 13) % 5;
                    rect(g, x + 20 + k * 31, y + 14, 1, h, 0xFFA01018);
                }
            }
            String pre = cursed && !ghost ? "cutemod.pop.hell." : "cutemod.pop.";
            int ink = cursed ? 0xFFEBCFC8 : dark ? 0xFFD9534F : 0xFF3A2A3A;
            // the title takes the room the "x" leaves free (the "x" jumps between the right, the left and the middle)
            int tx = x + 16, tw = POP_W - 32;
            if (!ghost && p.slot == 1) tw = POP_W - 20;
            else if (!ghost && p.slot == 2) { tx = x + closeX(2) + 14; tw = POP_W - closeX(2) - 18; }
            fitLine(g, f, t(pre + "title." + p.type), tx, y + 3, tw, cursed ? 0xFFFFD0D0 : dark ? 0xFFD9534F : 0xFF3A2A3A);
            if (!ghost) { // close button (it runs away)
                boolean hv = in(mx, my, x + closeX(p.slot), y + 2, 11, 11);
                rect(g, x + closeX(p.slot), y + 2, 11, 11, cursed ? (hv ? 0xFFD01828 : 0xFF7A0C14) : hv ? 0xFFFFFFFF : 0xCCFFFFFF);
                CuteFont.draw(g, f, "x", x + closeX(p.slot) + 3, y + 3, cursed ? 0xFFFFE0E0 : 0xFF3A2A3A, false);
            }
            drawMessage(g, f, t(pre + "msg." + p.type), x + 6, y + MSG_Y, POP_W - 12, ink);
            if (ghost) {
                button(g, x + (POP_W - 70) / 2, y + POP_H - 16, t("cutemod.pop.ok.3"), 0xFF5A0F15, 0xFFD9534F);
            } else if (cursed) {
                button(g, x + 6, y + POP_H - 16, t("cutemod.pop.bad." + p.type), 0xFF8A1018, 0xFFFFE0E0);
                button(g, x + POP_W - 76, y + POP_H - 16, t("cutemod.pop.ok." + p.type), 0xFF3A0508, 0xFFC06A68);
            } else {
                button(g, x + 6, y + POP_H - 16, t("cutemod.pop.bad." + p.type), 0xFF2F9BFF, 0xFFFFFFFF);
                button(g, x + POP_W - 76, y + POP_H - 16, t("cutemod.pop.ok." + p.type), 0xFFB9A8C8, 0xFF3A2A3A);
            }
            g.pose().popPose();
        }
    }

    private void button(GuiGraphics g, int x, int y, String label, int bg, int fg) {
        Font f = font();
        boolean hv = in(mx, my, x, y, 70, 12);
        rect(g, x, y, 70, 12, hv ? App.mix(bg & 0xFFFFFF, 0xFFFFFF, 0.3f) : bg);
        fitCenter(g, f, label, x + 2, y + (CuteFont.size() == CuteFont.LARGE ? 1 : 2), 66, fg);
    }

    // ---------- text that always fits (measured with the font it is drawn with) ----------
    /** One line in at most maxW pixels: smaller (down to 60 %) when it is too wide, cut with "..." only after that. */
    private static void fitLine(GuiGraphics g, Font f, String s, int x, int y, int maxW, int color) {
        fitDraw(g, f, s, x, y, maxW, color, false);
    }

    /** The same, centred in the box that starts at x and is maxW wide. */
    private static void fitCenter(GuiGraphics g, Font f, String s, int x, int y, int maxW, int color) {
        fitDraw(g, f, s, x, y, maxW, color, true);
    }

    private static void fitDraw(GuiGraphics g, Font f, String s, int x, int y, int maxW, int color, boolean center) {
        int w = CuteFont.width(f, s);
        if (w <= maxW) {
            CuteFont.draw(g, f, s, center ? x + (maxW - w) / 2 : x, y, color, false);
            return;
        }
        float k = Math.max(0.6F, maxW / (float) w);
        String cut = w * k > maxW + 0.5F ? CuteFont.cut(f, s, (int) (maxW / k)) : s;
        float cw = CuteFont.width(f, cut) * k;
        g.pose().pushPose();
        g.pose().translate(center ? x + (maxW - cw) / 2F : x, y + (1F - k) * 4F, 0);
        g.pose().scale(k, k, 1F);
        CuteFont.draw(g, f, cut, 0, 0, color, false);
        g.pose().popPose();
    }

    /** The height of one line of text in the font the player picked (Settings > Font size). */
    private static int lineStep() {
        int sz = CuteFont.size();
        return sz == CuteFont.SMALL ? 8 : sz == CuteFont.LARGE ? 12 : 10;
    }

    /** The words of s wrapped into lines of at most maxW pixels (measured with the picked font); a word wider than a line is broken. */
    private static List<String> wrapLines(Font f, String s, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String word : s.split(" ")) {
            if (word.isEmpty()) continue;
            String tryLine = cur.length() == 0 ? word : cur + " " + word;
            if (CuteFont.width(f, tryLine) <= maxW) {
                cur.setLength(0);
                cur.append(tryLine);
                continue;
            }
            if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); }
            String rest = word;
            while (rest.length() > 1 && CuteFont.width(f, rest) > maxW) {
                int n = rest.length() - 1;
                while (n > 1 && CuteFont.width(f, rest.substring(0, n)) > maxW) n--;
                out.add(rest.substring(0, n));
                rest = rest.substring(n);
            }
            cur.append(rest);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    /** A message in the room MSG_H high: if it does not fit in the picked size it is drawn a little smaller, never over the buttons. */
    private static void drawMessage(GuiGraphics g, Font f, String msg, int x, int y, int w, int color) {
        int step = lineStep();
        float k = 1F;
        List<String> lines = wrapLines(f, msg, w);
        for (float c : new float[]{1F, 0.9F, 0.8F, 0.7F}) {
            k = c;
            lines = wrapLines(f, msg, (int) (w / c));
            if (lines.size() * step * c <= MSG_H + 0.5F) break;
        }
        int n = Math.min(lines.size(), Math.max(1, (int) (MSG_H / (step * k) + 0.01F)));
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        if (k < 0.999F) g.pose().scale(k, k, 1F);
        for (int i = 0; i < n; i++) {
            String line = lines.get(i);
            if (i == n - 1 && n < lines.size()) line = CuteFont.cut(f, line + " " + lines.get(i + 1), (int) (w / k));   // more text than room: the last line ends with "..."
            CuteFont.draw(g, f, line, 0, i * step, color, false);
        }
        g.pose().popPose();
    }

    // ---------- input ----------
    /** Returns true if a pop-up swallowed the click. */
    public boolean click(int x, int y, int button) {
        if (!browser) return false;
        for (int i = pops.size() - 1; i >= 0; i--) {
            Popup p = pops.get(i);
            if (!in(x, y, p.x, p.y, POP_W, POP_H)) continue;
            boolean dark = p.type == 3;
            if (!dark && in(x, y, p.x + closeX(p.slot), p.y + 2, 11, 11)) { // the "x"
                pops.remove(i);
                Progress.onPopupClosed();
                return true;
            }
            int by = p.y + POP_H - 16;
            if (dark) {
                if (in(x, y, p.x + (POP_W - 70) / 2, by, 70, 12)) {
                    pops.remove(i);
                    Progress.onPopupClosed();
                    if (scary) startEvent(0); // closing it did not help
                    return true;
                }
            } else if (in(x, y, p.x + 6, by, 70, 12)) { // the "bad" button: more pop-ups!
                pops.remove(i);
                Progress.onPopupClosed();
                spawnPopup();
                spawnPopup();
                return true;
            } else if (in(x, y, p.x + POP_W - 76, by, 70, 12)) {
                pops.remove(i);
                Progress.onPopupClosed();
                return true;
            }
            pops.remove(i); // click on the window: bring it to the front
            pops.add(p);
            return true;
        }
        return false;
    }
}
