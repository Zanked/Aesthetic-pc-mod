package dev.cutemod.client.os;

import dev.cutemod.CuteMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The sounds of the Fairy Tales book app (made by tools/make_tales_audio.py):
 * <ul>
 * <li>effects: a rustle of a page, the book opening and closing, a soft knock when it goes back on the shelf. They follow the
 * Sounds switch and the system volume of the computer's Settings;</li>
 * <li>quiet loops that play under the story: a forest, a meadow, the sea, the deep, a blizzard, a room with a fire, a night with
 * crickets, rain, and a music box lullaby in every tale. Which ones play depends on the scene ({@link #mood}): the night is quieter,
 * a storm is louder. The loops cross-fade into each other when the page is turned. They follow the Music switch and the Music slider.</li>
 * <li>cues: one-shot sounds that belong to a single scene (a howl, a clock that strikes twelve, thunder, an owl, ...), see {@link #cues}.</li>
 * </ul>
 * TalesApp calls {@link #keep} on every tick. When the calls stop (the book is closed, the app is minimized, the computer is left)
 * every loop fades out by itself.
 */
public final class TaleAudio {
    private TaleAudio() {}

    private static final float MASTER = 0.55F;        // the loops are quiet by design
    private static final Map<String, Layer> live = new HashMap<>();

    private static SoundEvent event(String name) {
        return SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, name));
    }

    private static final SoundEvent PAGE = event("tales.page"), OPEN = event("tales.open"),
            CLOSE = event("tales.close"), SHELF = event("tales.shelf");

    // ---------- effects ----------
    /** A page turns: a rustle of paper (three recordings, a little different pitch each time). */
    public static void page() { Sfx.ui(PAGE, 0.94F + (float) Math.random() * 0.12F, 0.55F); }

    public static void open() { Sfx.ui(OPEN, 1.0F, 0.6F); }

    public static void close() { Sfx.ui(CLOSE, 1.0F, 0.6F); }

    /** The book is put back: a soft knock of wood. */
    public static void shelf() { Sfx.ui(SHELF, 1.0F, 0.55F); }

    // ---------- cues: the sounds of single scenes ----------
    /**
     * A one-shot sound of a scene. delay = ticks after the picture came on the page, sound = the event, fx = what the
     * picture does with it: "flash" and "flash2" (lightning, strong and weak), "dim" (the lamp flickers), "" (nothing).
     */
    public record Cue(int delay, String sound, float pitch, float vol, String fx) {}

    private static final Map<String, SoundEvent> CUE_EVENTS = new HashMap<>();

    private static Cue c(int delay, String sound, float pitch, float vol, String fx) { return new Cue(delay, "tales." + sound, pitch, vol, fx); }

    private static Cue knock(int delay) { return c(delay, "shelf", 1.25F, 0.8F, ""); }

    private static List<Cue> sparkle(int delay, float vol) { return List.of(c(delay, "cue_sparkle", 1F, vol, "")); }

    /** The cues of a scene (the picture of a tale, 0-based). Empty for the scenes that are quiet. */
    public static List<Cue> cues(String tale, int scene) {
        return switch (tale + ":" + scene) {
            case "redhood:1" -> List.of(c(30, "cue_wolf", 1F, 0.7F, ""));                                        // the wolf in the forest
            case "redhood:2" -> List.of(knock(26), knock(42), knock(58));                                        // knock-knock-knock at the door
            case "hansel:1" -> List.of(c(36, "cue_owl", 1F, 0.6F, ""), c(110, "cue_owl", 0.88F, 0.45F, ""));    // a night in the forest
            case "bremen:2" -> List.of(c(50, "cue_owl", 0.95F, 0.5F, ""));
            case "snowwhite:0" -> sparkle(34, 0.5F);                                                             // the magic mirror
            case "snowwhite:4", "duckling:4" -> sparkle(30, 0.55F);
            case "mermaid:4" -> sparkle(30, 0.6F);
            case "cinderella:1" -> List.of(c(20, "cue_sparkle", 1F, 0.7F, ""), c(48, "cue_sparkle", 1.12F, 0.6F, ""));      // the pumpkin becomes a coach
            case "cinderella:2" -> sparkle(26, 0.5F);
            case "cinderella:3" -> {                                                                             // the clock strikes twelve
                Cue[] k = new Cue[12];
                for (int i = 0; i < 12; i++) k[i] = c(50 + i * 22, "cue_chime", 1F, i == 11 ? 0.8F : 0.6F, "dim");
                yield List.of(k);
            }
            case "mermaid:1" -> List.of(c(34, "cue_chime", 1.6F, 0.4F, ""), c(60, "cue_chime", 1.6F, 0.35F, ""));  // the bell of the ship
            case "mermaid:0", "mermaid:3" -> List.of(c(24, "cue_bubble", 1F, 0.55F, ""));
            case "fisherman:0" -> List.of(c(40, "cue_bubble", 1.1F, 0.5F, ""));                                  // the goldfish
            case "pea:1" -> List.of(c(26, "cue_thunder", 1.1F, 0.4F, "flash2"));                                 // a storm outside the castle
            case "thumbelina:1" -> List.of(c(30, "cue_croak", 1F, 0.55F, ""), c(78, "cue_croak", 0.85F, 0.5F, ""));
            case "fisherman:4" -> List.of(c(16, "cue_thunder", 1F, 0.8F, "flash"), c(120, "cue_thunder", 0.82F, 0.6F, "flash2"));
            default -> List.of();
        };
    }

    /** Plays one cue (it follows the Sounds switch and the system volume, like the page rustle). */
    public static void cue(Cue cue) {
        Sfx.ui(CUE_EVENTS.computeIfAbsent(cue.sound(), TaleAudio::event), cue.pitch(), cue.vol());
    }

    // ---------- the mood of a scene ----------
    private static final Map<String, String> BASE = Map.ofEntries(
            Map.entry("duckling", "meadow"), Map.entry("mermaid", "sea"), Map.entry("pea", "hall"),
            Map.entry("thumbelina", "meadow"), Map.entry("redhood", "forest"), Map.entry("hansel", "forest"),
            Map.entry("snowwhite", "forest"), Map.entry("bremen", "forest"), Map.entry("cinderella", "hall"),
            Map.entry("puss", "meadow"), Map.entry("fisherman", "sea"), Map.entry("kolobok", "forest"));

    /** The loops (name, volume 0..1) that go with a scene. scene -1 = the title and the last page: a calm room. */
    public static Map<String, Float> mood(Tales.Tale tl, int scene) { return mood(tl, scene, false); }

    /** The same, and ending = the last page of the tale: the room goes quiet and the lullaby slowly dies away. */
    public static Map<String, Float> mood(Tales.Tale tl, int scene, boolean ending) {
        Map<String, Float> m = new HashMap<>();
        String base = BASE.getOrDefault(tl.id(), "meadow");
        String outdoors = base.equals("hall") ? "meadow" : base;
        String spec = scene >= 0 && scene < tl.pictures().length ? tl.pictures()[scene] : "";
        String bg = spec.isEmpty() ? "" : spec.split(";")[0];
        float lull = 0.34F;
        if (spec.isEmpty()) {
            m.put(base, 0.3F);
            lull = 0.42F;
        } else {
            switch (bg) {
                case "forest" -> m.put("forest", 0.8F);
                case "night" -> { m.put("night", 0.8F); m.put(outdoors, 0.2F); lull = 0.26F; }          // the night is quieter
                case "sea" -> m.put("sea", 0.8F);
                case "deep" -> { m.put("deep", 0.9F); lull = 0.3F; }
                case "snow" -> { m.put("wind", 0.7F); lull = 0.3F; }
                case "room", "hall" -> m.put("hall", 0.8F);
                case "storm" -> { m.put("rain", 1.0F); m.put("sea", 0.6F); m.put("wind", 0.4F); lull = 0.2F; }   // a storm is louder
                default -> m.put(outdoors, 0.7F);                                                        // day, dusk
            }
            if (spec.contains("rain@") && !m.containsKey("rain")) m.put("rain", 0.55F);
            if (spec.contains("snowflakes@") && !m.containsKey("wind")) m.put("wind", 0.4F);
        }
        if (ending) {
            m.replaceAll((k, v) -> v * 0.5F);
            lull = 0.12F;
        }
        m.put("lullaby", lull);
        return m;
    }

    /** On the shelf: only the lullaby and a hint of a quiet room. */
    public static Map<String, Float> shelfMood() { return Map.of("lullaby", 0.3F, "hall", 0.1F); }

    // ---------- the loops ----------
    /** Called on every tick while the book app is on screen: loop name to volume (0..1). The loops that are not named fade out. */
    public static void keep(Map<String, Float> want) {
        if (!Sfx.music() || Sfx.musicVol() <= 0F) { stop(); return; }
        Minecraft mc = Minecraft.getInstance();
        for (Map.Entry<String, Float> e : want.entrySet()) {
            Layer l = live.get(e.getKey());
            if (l != null && l.isStopped()) { live.remove(e.getKey()); l = null; }
            if (l == null && e.getValue() > 0.01F) {
                l = new Layer(e.getKey());
                live.put(e.getKey(), l);
                mc.getSoundManager().play(l);
                mc.getMusicManager().stopPlaying();
            }
            if (l != null) l.want(e.getValue());
        }
        for (Layer l : live.values()) if (!want.containsKey(l.name)) l.want(0F);
        live.values().removeIf(l -> l.isStopped());
    }

    /** Fade everything out (the book was closed). */
    public static void stop() {
        for (Layer l : live.values()) l.fadeOut();
        live.clear();
    }

    private static final class Layer extends AbstractTickableSoundInstance {
        final String name;
        private float goal;
        private int idle, duck;
        private boolean out;

        Layer(String name) {
            super(event("tales." + (name.equals("lullaby") ? name : "amb_" + name)), SoundSource.MASTER, RandomSource.create());
            this.name = name;
            this.looping = true;                 // not streamed, so OpenAL loops it without a gap
            this.delay = 0;
            this.volume = 0.01F;                 // a sound that starts at exactly 0 is skipped
            this.relative = true;
            this.attenuation = SoundInstance.Attenuation.NONE;
        }

        void want(float v) { goal = v; idle = 0; }

        void fadeOut() { out = true; }

        @Override
        public void tick() {
            float g = (out || ++idle > 10 || !Sfx.music()) ? 0F : Math.min(1F, goal * MASTER * Sfx.musicVol());
            float step = g > volume ? 0.012F : 0.02F;                 // a slow cross-fade
            volume = volume < g ? Math.min(g, volume + step) : Math.max(g, volume - step);
            if (g == 0F && volume <= 0.005F) { stop(); return; }
            if (volume > 0.05F && duck++ % 60 == 0) Minecraft.getInstance().getMusicManager().stopPlaying();   // the vanilla music waits
        }
    }
}
