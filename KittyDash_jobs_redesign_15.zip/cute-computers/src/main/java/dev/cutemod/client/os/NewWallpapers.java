package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Three more wallpapers for CuteMarket (numbers 45-47): golden autumn, a dark blue forest and rain on a window with the
 * lights of the city. Drawn from fractions of the box, so they fit the tiny shop icon and the whole desktop alike, and
 * they move. Clipped by hand like {@link WallpapersExtra} (no scissor).
 */
final class NewWallpapers {
    private static GuiGraphics gg;
    private static int bx, by, bw, bh, t;

    private NewWallpapers() {}

    static void draw(GuiGraphics g, int x, int y, int w, int h, int idx) {
        gg = g; bx = x; by = y; bw = Math.max(1, w); bh = Math.max(1, h);
        t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        switch (idx) {
            case 45 -> autumn();
            case 46 -> darkForest();
            default -> rainWindow();
        }
        gg = null;
    }

    // ---------- helpers ----------
    private static void r(int x0, int y0, int x1, int y1, int argb) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fill(x0, y0, x1, y1, argb);
    }

    private static void grad(int y0, int y1, int top, int bottom) {
        y0 = Math.max(y0, by); y1 = Math.min(y1, by + bh);
        if (y1 > y0) gg.fillGradient(bx, y0, bx + bw, y1, top, bottom);
    }

    private static void disc(int cx, int cy, int rad, int argb) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            r(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    private static void tri(int cx, int topY, int w, int h, int argb) {
        for (int row = 0; row < h; row++) {
            int ww = Math.max(1, w * (row + 1) / h);
            r(cx - ww / 2, topY + row, cx - ww / 2 + ww, topY + row + 1, argb);
        }
    }

    private static int px(double f) { return bx + (int) Math.round(bw * f); }

    private static int py(double f) { return by + (int) Math.round(bh * f); }

    /** One pixel unit: a hundredth of the height (at least 1). */
    private static int u(double n) { return Math.max(1, (int) Math.round(bh * n / 100.0)); }

    private static int lerp(int a, int b, float f) {
        f = Math.max(0f, Math.min(1f, f));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * f) << 16) | ((int) (ag + (bg - ag) * f) << 8) | (int) (ab + (bb - ab) * f);
    }

    private static void stars(int n, int maxY, int col) {
        for (int i = 0; i < n; i++) {
            int sx = bx + (i * 53 + 11) % Math.max(1, bw - 2), sy = by + (i * 29 + 5) % Math.max(1, maxY);
            boolean on = ((t / 8 + i * 3) % 9) != 0;
            r(sx, sy, sx + (on ? 2 : 1), sy + (on ? 2 : 1), on ? col : (col & 0x00FFFFFF) | 0x55000000);
        }
    }

    // ---------- 46: a dark blue forest ----------
    private static void darkForest() {
        grad(by, by + bh, 0xFF050A24, 0xFF12306A);
        stars(20, bh / 2, 0xFFCFE0FF);
        int mx = px(0.74), my = py(0.22), mr = u(10);
        disc(mx, my, mr + u(8), 0x1A8AB8FF);
        disc(mx, my, mr + u(4), 0x2A9ACBFF);
        disc(mx, my, mr, 0xFFE6F0FF);
        int[] cols = {0xFF16306A, 0xFF0E2250, 0xFF08163A, 0xFF040C24};          // three rows of pines, the nearer the darker
        int[] base = {70, 82, 94, 108};
        int[] size = {26, 34, 44, 58};
        int[] step = {14, 19, 26, 36};
        for (int row = 0; row < 4; row++) {
            for (int i = -1; i * u(step[row]) < bw + u(step[row]); i++) {
                int cx = bx + i * u(step[row]) + ((row * 7 + i * 5) % 6) * u(1);
                int h = u(size[row] + ((i * 13 + row * 5) % 9));
                int w = Math.max(3, h * 6 / 10);
                int top = by + bh * base[row] / 100 - h;
                for (int k = 0; k < 3; k++) tri(cx, top + k * h / 4, w - k * w / 6 + 2, h / 2 + 1, cols[row]);
                r(cx, top + h * 3 / 4, cx + Math.max(1, w / 8), by + bh, cols[row]);
            }
            if (row == 1) grad(by + bh * 78 / 100, by + bh * 92 / 100, 0x00AAD0FF, 0x33AAD0FF);   // mist between the rows
        }
        for (int i = 0; i < 14; i++) {                                              // fireflies
            double a = t / 30.0 + i * 1.7;
            int fx = bx + (int) ((i * 61 + 20) % Math.max(1, bw)) + (int) (Math.sin(a) * u(5)), fy = by + bh * 55 / 100 + (int) ((i * 37) % Math.max(1, bh * 40 / 100)) + (int) (Math.cos(a * 0.8) * u(3));
            boolean on = ((t / 6 + i * 5) % 12) < 8;
            r(fx - 1, fy - 1, fx + 2, fy + 2, on ? 0x449AF0E0 : 0x00000000);
            r(fx, fy, fx + 1, fy + 1, on ? 0xFFCFFFF0 : 0x558AD8D0);
        }
    }

    // ---------- 45: golden autumn ----------
    private static void autumn() {
        grad(by, by + bh, 0xFFFFD9A0, 0xFFF08A4A);
        disc(px(0.66), py(0.30), u(12), 0x55FFF0C0);
        disc(px(0.66), py(0.30), u(8), 0xFFFFF6D8);
        r(bx, by + bh * 86 / 100, bx + bw, by + bh, 0xFF6A3A1E);
        r(bx, by + bh * 86 / 100, bx + bw, by + bh * 86 / 100 + 2, 0xFF8A4A24);
        int[] lc = {0xFFE5501E, 0xFFF08A1E, 0xFFF2B41E, 0xFFC03A1E};
        for (int k = 0; k < 3; k++) {
            int tx = px(0.18 + k * 0.32), h = u(52 + k * 6), w = Math.max(2, u(3 + k));
            int top = py(0.88) - h;
            r(tx, top, tx + w, py(0.88), 0xFF4A2A1A);
            r(tx - u(10), top + h / 3, tx, top + h / 3 + Math.max(1, u(1.5)), 0xFF4A2A1A);
            r(tx + w, top + h / 2, tx + w + u(10), top + h / 2 + Math.max(1, u(1.5)), 0xFF4A2A1A);
            for (int j = 0; j < 7; j++) disc(tx + w / 2 + ((j * 13 + k * 5) % 21 - 10) * u(1), top + ((j * 7) % 14) * u(1), u(7 + (j % 3)), lc[(j + k) % 4]);
        }
        for (int i = 0; i < 18; i++) {                                              // falling leaves
            double a = t / 25.0 + i;
            int x = bx + (int) ((i * 59 + t * 0.5) % (bw + 20)) - 10 + (int) (Math.sin(a) * u(4)), y = by + (int) ((i * 31 + t * (0.9 + (i % 3) * 0.2)) % (bh * 90 / 100));
            r(x, y, x + Math.max(1, u(2.5)), y + Math.max(1, u(1.8)), lc[i % 4]);
        }
        for (int i = 0; i < 10; i++) r(bx + (i * 41 + 7) % Math.max(1, bw - 3), by + bh * 88 / 100 + (i * 13) % Math.max(1, bh * 10 / 100), bx + (i * 41 + 7) % Math.max(1, bw - 3) + Math.max(1, u(2)), by + bh * 88 / 100 + (i * 13) % Math.max(1, bh * 10 / 100) + 1, lc[i % 4]);
    }

    // ---------- 47: rain on a window with the lights of the city ----------
    private static void rainWindow() {
        grad(by, by + bh, 0xFF14122E, 0xFF2A3A6A);
        int[] glow = {0xFFFFB84A, 0xFFFF6A8A, 0xFF6AD0FF, 0xFFB78AFF, 0xFFFFE680};
        for (int i = 0; i < 16; i++) {                                              // the blurred lights (bokeh)
            int cx = bx + (i * 97 + 13) % Math.max(1, bw), cy = by + bh * 40 / 100 + (i * 131 + 17) % Math.max(1, bh * 55 / 100), rad = u(5 + (i % 4) * 2);
            int c = glow[i % 5] & 0x00FFFFFF;
            disc(cx, cy, rad, 0x28000000 | c);
            disc(cx, cy, Math.max(1, rad * 2 / 3), 0x30000000 | c);
        }
        for (int i = 0; i < 30; i++) {                                              // drops running down the glass
            int x = bx + (i * 37 + 11) % Math.max(1, bw), len = u(5 + (i % 5) * 3);
            int y = by + (int) ((i * 53 + t * (0.5 + (i % 4) * 0.25)) % (bh + len)) - len;
            r(x, y, x + 1, y + len, 0x33FFFFFF);
            r(x, y + len - 1, x + 2, y + len + 1, 0x88FFFFFF);
        }
        for (int i = 0; i < 10; i++) {                                              // still drops
            int x = bx + (i * 71 + 5) % Math.max(1, bw - 2), y = by + (i * 47 + 9) % Math.max(1, bh - 2);
            disc(x, y, Math.max(1, u(1.4)), 0x44FFFFFF);
        }
        r(bx, by + bh * 97 / 100, bx + bw, by + bh, 0xFF0A0A1C);                    // the window sill
    }
}
