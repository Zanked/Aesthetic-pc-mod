package dev.cutemod.client.os;

import dev.cutemod.market.Deals;
import net.minecraft.client.resources.language.I18n;

/**
 * The name the player gave the pet and the character it started with, saved under "petn_&lt;species&gt;":
 * name, the day of the last rename (a pet can get a new name once a day) and the start character
 * (0 foodie, 1 playful, 2 sleepy, 3 cuddly, -1 none). An older pet has no entry and is called by its species until renamed.
 */
final class PetName {
    private PetName() {}

    static final int MAX = 12;

    record Rec(String name, long renameDay, int trait) {}

    static String clean(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) if (c >= 32 && c != 127 && c != ';') b.append(c);
        String t = b.toString().trim().replaceAll("\\s+", " ");
        return t.length() > MAX ? t.substring(0, MAX).trim() : t;
    }

    static Rec get(String speciesId) {
        try {
            String s = Store.read("petn_" + speciesId);
            if (s == null || s.isBlank()) return null;
            String[] a = s.split(";", -1);
            if (a.length < 3) return null;
            return new Rec(a[0], Long.parseLong(a[1]), Integer.parseInt(a[2]));
        } catch (Exception e) {
            return null;
        }
    }

    static void put(String speciesId, Rec r) { Store.write("petn_" + speciesId, clean(r.name()) + ";" + r.renameDay() + ";" + r.trait()); }

    /** The given name, or "" when there is none. */
    static String custom(String speciesId) {
        Rec r = get(speciesId);
        return r == null ? "" : clean(r.name());
    }

    /** The name to show: the given one, or the name of the species. */
    static String display(String speciesId) {
        String n = custom(speciesId);
        return n.isEmpty() ? I18n.get("cutemod.pet.name." + speciesId) : n;
    }

    /** True if the name was already changed today. */
    static boolean changedToday(String speciesId) {
        Rec r = get(speciesId);
        return r != null && r.renameDay() == Deals.day();
    }
}
