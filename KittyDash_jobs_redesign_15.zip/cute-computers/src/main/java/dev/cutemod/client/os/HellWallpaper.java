package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The "echo" of the video 666: for a couple of minutes after the video is watched to the end the desktop falls into a red
 * tunnel (see {@link Wallpaper#startEcho}). Drawn from the real clock, so it moves on every computer in the same way.
 */
final class HellWallpaper {
    private HellWallpaper() {}

    /** One ring of the tunnel: a ring of thickness th round (cx, cy), cut to the box. */
    private static void ring(GuiGraphics g, int x, int y, int w, int h, int cx, int cy, int r, int th, int argb) {
        th = Math.max(1, Math.min(th, r));
        for (int dy = Math.max(-r, y - cy); dy <= Math.min(r, y + h - 1 - cy); dy++) {
            int a = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            int b = (int) Math.round(Math.sqrt(Math.max(0, (r - th) * (r - th) - dy * dy)));
            if (a - b < 1) a = b + 1;
            int l0 = Math.max(x, cx - a), l1 = Math.min(x + w, cx - b);
            int r0 = Math.max(x, cx + b), r1 = Math.min(x + w, cx + a);
            if (l1 > l0) g.fill(l0, cy + dy, l1, cy + dy + 1, argb);
            if (r1 > r0) g.fill(r0, cy + dy, r1, cy + dy + 1, argb);
        }
    }

    static void draw(GuiGraphics g, int x, int y, int w, int h) {
        double tm = System.currentTimeMillis() * 0.06;                                   // 60 steps a second
        g.fillGradient(x, y, x + w, y + h, 0xFF120004, 0xFF3A0610);
        int cx = x + w / 2 + (int) Math.round(Math.sin(tm / 90) * w / 16.0), cy = y + h / 2 + (int) Math.round(Math.cos(tm / 70) * h / 16.0);
        int maxR = (int) (Math.hypot(w, h) * 0.6);
        double phase = (tm * 0.0035) % 1.0;
        int n = 11;
        for (int k = 0; k < n; k++) {
            double u = (k + phase) / n;                                                  // 0 far away .. 1 right in front of you
            int r = Math.max(2, (int) (u * u * maxR));
            int th = 1 + (int) (u * 6);
            int a = (int) (0x30 + u * 0x70);
            int rgb = k % 3 == 0 ? 0xA0102A : k % 3 == 1 ? 0xE0301A : 0x6A1070;          // crimson, flame, bruise
            ring(g, x, y, w, h, cx, cy, r, th, (a << 24) | rgb);
        }
        int pulse = (int) (tm % 70);
        g.fill(cx - 2, cy - 2, cx + 3, cy + 3, 0xFF000000);                              // the hole at the end of it
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, pulse < 12 ? 0xFFB01020 : 0xFF000000);    // that beats
    }
}
