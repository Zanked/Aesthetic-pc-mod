package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/** Four simple, cheap wallpapers (numbers 26-29): peach dots, sky stripes, lemon checks and a starry night. */
final class CheapWallpapers {
    private static GuiGraphics gg;
    private static int bx, by, bw, bh;

    private CheapWallpapers() {}

    static void draw(GuiGraphics g, int x, int y, int w, int h, int idx) {
        gg = g; bx = x; by = y; bw = Math.max(1, w); bh = Math.max(1, h);
        switch (idx) {
            case 26 -> peachDots();
            case 27 -> skyStripes();
            case 28 -> lemonChecks();
            default -> starryNight();
        }
        gg = null;
    }

    private static void r(int x0, int y0, int x1, int y1, int argb) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fill(x0, y0, x1, y1, argb);
    }

    private static void disc(int cx, int cy, int rad, int argb) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            r(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** 26: a peach gradient with white polka dots. */
    private static void peachDots() {
        gg.fillGradient(bx, by, bx + bw, by + bh, 0xFFFFE3D1, 0xFFFFB8A0);
        int step = Math.max(8, Math.min(bw, bh) / 5), rad = Math.max(1, step / 5);
        for (int row = 0; row * step < bh + step; row++) {
            for (int col = 0; col * step < bw + step; col++) {
                int ox = (row % 2 == 0) ? 0 : step / 2;
                disc(bx + col * step + ox + step / 2, by + row * step + step / 2, rad, 0xAAFFFFFF);
            }
        }
    }

    /** 27: soft blue and white vertical stripes. */
    private static void skyStripes() {
        int sw = Math.max(3, bw / 18);
        for (int i = 0; i * sw < bw; i++) r(bx + i * sw, by, bx + (i + 1) * sw, by + bh, i % 2 == 0 ? 0xFFCFE8FF : 0xFFEAF6FF);
        r(bx, by + bh - Math.max(2, bh / 12), bx + bw, by + bh, 0x55FFFFFF);
    }

    /** 28: a yellow checkerboard. */
    private static void lemonChecks() {
        int c = Math.max(4, Math.min(bw, bh) / 6);
        for (int row = 0; row * c < bh; row++) {
            for (int col = 0; col * c < bw; col++) {
                r(bx + col * c, by + row * c, bx + (col + 1) * c, by + (row + 1) * c, (row + col) % 2 == 0 ? 0xFFFFF3A8 : 0xFFFFE066);
            }
        }
    }

    /** 29: a dark blue night with twinkling stars and a small moon. */
    private static void starryNight() {
        gg.fillGradient(bx, by, bx + bw, by + bh, 0xFF14183A, 0xFF2B2F6B);
        int t = (int) (System.currentTimeMillis() / 400L % 1_000_000L);
        for (int i = 0; i < 18; i++) {
            int sx = bx + (i * 53 + 11) % Math.max(1, bw - 2), sy = by + (i * 29 + 5) % Math.max(1, bh - 2);
            boolean on = ((t + i * 3) % 7) != 0;
            r(sx, sy, sx + 2, sy + 2, on ? 0xFFFFF6C8 : 0x66FFF6C8);
        }
        int mr = Math.max(3, bh / 8);
        disc(bx + bw * 78 / 100, by + bh * 24 / 100, mr, 0xFFFFF0B0);
        disc(bx + bw * 78 / 100 + mr / 2, by + bh * 24 / 100 - 1, mr, 0xFF1E2250);
    }
}
