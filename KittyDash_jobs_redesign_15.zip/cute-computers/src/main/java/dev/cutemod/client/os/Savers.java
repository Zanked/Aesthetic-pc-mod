package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.Random;

/** The screensavers. Each one is drawn from the tick counter alone (no state), so it can start anywhere. */
public final class Savers {
    private Savers() {}

    public static final int COUNT = 9, BASE = 4;

    public static boolean unlocked(int id) { return id < BASE || Updates.unlocksSaver(id); }

    /** The next unlocked screensaver in this direction (wraps around). */
    public static int step(int from, int dir) {
        int s = from;
        for (int i = 0; i < COUNT; i++) {
            s = Math.floorMod(s + dir, COUNT);
            if (unlocked(s)) return s;
        }
        return from;
    }

    public static void render(GuiGraphics g, int id, int x, int y, int w, int h, int t, int body) {
        switch (id) {
            case 1 -> warp(g, x, y, w, h, t);
            case 2 -> marquee(g, x, y, w, h, t);
            case 3 -> mystify(g, x, y, w, h, t);
            case 4 -> honeycomb(g, x, y, w, h, t);
            case 5 -> bees(g, x, y, w, h, t);
            case 6 -> bubbles(g, x, y, w, h, t);
            case 7 -> aquarium(g, x, y, w, h, t);
            case 8 -> pipes(g, x, y, w, h, t);
            default -> hearts(g, x, y, w, h, t);
        }
    }

    // ---------- helpers ----------
    private static double fr(double v) { return v - Math.floor(v); }

    private static double rnd(int i, int k) { return fr(Math.sin(i * 12.9898 + k * 78.233) * 43758.5453); }

    private static double wrap(double v, double len) { return v - Math.floor(v / len) * len; }

    private static int bounce(double v, int max) {
        double m = wrap(v, 2.0 * max);
        return (int) Math.round(m < max ? m : 2.0 * max - m);
    }

    private static int hsv(float h, float s, float v) {
        h = (h - (float) Math.floor(h)) * 6f;
        int i = (int) h;
        float f = h - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    private static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    private static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        int n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        if (n == 0) { g.fill(x0, y0, x0 + 2, y0 + 2, c); return; }
        for (int i = 0; i <= n; i += 2) g.fill(x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, x0 + (x1 - x0) * i / n + 2, y0 + (y1 - y0) * i / n + 2, c);
    }

    private static String playerName() {
        try {
            return Minecraft.getInstance().getUser().getName();
        } catch (Exception e) {
            return "Cute OS";
        }
    }

    // ---------- 0: a heart that bounces around ----------
    private static void heart(GuiGraphics g, int x, int y, int s, int c) {
        g.fill(x + s, y, x + 3 * s, y + s, c);
        g.fill(x + 4 * s, y, x + 6 * s, y + s, c);
        g.fill(x, y + s, x + 7 * s, y + 3 * s, c);
        g.fill(x + s, y + 3 * s, x + 6 * s, y + 4 * s, c);
        g.fill(x + 2 * s, y + 4 * s, x + 5 * s, y + 5 * s, c);
        g.fill(x + 3 * s, y + 5 * s, x + 4 * s, y + 6 * s, c);
    }

    private static void hearts(GuiGraphics g, int x, int y, int w, int h, int t) {
        g.fill(x, y, x + w, y + h, 0xFF05030A);
        for (int i = 0; i < 28; i++) {
            if (((t / 12) + i) % 5 != 0) g.fill(x + (i * 97 + 13) % w, y + (i * 53 + 7) % h, x + (i * 97 + 13) % w + 1, y + (i * 53 + 7) % h + 1, 0xFF8F86AA);
        }
        int s = 3;
        int[] cols = {0xFFFFB3D9, 0xFFB3E0FF, 0xFFFFE680, 0xFFC9B3FF};
        heart(g, x + bounce(t * 0.6, w - 7 * s), y + bounce(t * 0.45 + 30, h - 6 * s), s, cols[(t / 120) % cols.length]);
    }

    // ---------- 1: flying through the stars ----------
    private static void warp(GuiGraphics g, int x, int y, int w, int h, int t) {
        g.fill(x, y, x + w, y + h, 0xFF03030A);
        double cx = x + w / 2.0, cy = y + h / 2.0, maxR = Math.hypot(w, h) / 2;
        for (int i = 0; i < 110; i++) {
            double a = rnd(i, 1) * Math.PI * 2, p = fr(t * 0.005 + rnd(i, 2));
            double r = p * p * maxR;
            int px = (int) (cx + Math.cos(a) * r), py = (int) (cy + Math.sin(a) * r);
            if (px < x || py < y || px >= x + w - 2 || py >= y + h - 2) continue;
            int s = p > 0.85 ? 3 : p > 0.6 ? 2 : 1;
            int v = (int) (90 + 165 * p);
            g.fill(px, py, px + s, py + s, 0xFF000000 | (v << 16) | (v << 8) | Math.min(255, v + 30));
        }
    }

    // ---------- 2: a wavy rainbow text that scrolls past ----------
    private static void marquee(GuiGraphics g, int x, int y, int w, int h, int t) {
        g.fillGradient(x, y, x + w, y + h, 0xFF0A1630, 0xFF1B2F5C);
        var f = Minecraft.getInstance().font;
        String text = playerName() + "   \u2665   Cute OS   \u2665   ";
        int sc = 2, tw = f.width(text) * sc;
        double left = w - wrap(t * 1.3, w + tw);
        int px = 0;
        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            int cw = f.width(ch) * sc;
            int cx = (int) (x + left + px);
            int cy = (int) (y + h / 2.0 - 8 + Math.sin((t + i * 9) * 0.07) * 14);
            if (cx > x - cw && cx < x + w) {
                g.pose().pushPose();
                g.pose().translate(cx, cy, 0);
                g.pose().scale(sc, sc, 1f);
                CuteFont.draw(g, f, ch, 0, 0, hsv((float) (t * 0.004 + i * 0.06), 0.45f, 1f), false);
                g.pose().popPose();
            }
            px += cw;
        }
    }

    // ---------- 3: two shapes that stretch around and leave trails ----------
    private static void mystify(GuiGraphics g, int x, int y, int w, int h, int t) {
        g.fill(x, y, x + w, y + h, 0xFF000000);
        for (int poly = 0; poly < 2; poly++) {
            for (int k = 7; k >= 0; k--) {
                int tt = t - k * 7;
                int[] px = new int[4], py = new int[4];
                for (int i = 0; i < 4; i++) {
                    px[i] = x + bounce(tt * (0.6 + 0.23 * i + 0.11 * poly) + i * 40 + poly * 90, w - 3);
                    py[i] = y + bounce(tt * (0.45 + 0.19 * i + 0.07 * poly) + i * 25 + poly * 50, h - 3);
                }
                float v = 1f - k / 9f;
                int c = hsv((float) (poly * 0.5 + 0.55 + t * 0.001), 0.6f, v);
                for (int i = 0; i < 4; i++) line(g, px[i], py[i], px[(i + 1) % 4], py[(i + 1) % 4], c);
            }
        }
    }

    // ---------- 4: a honeycomb that glows in waves ----------
    private static void hex(GuiGraphics g, int cx, int cy, int r, int c) {
        for (int dy = -r; dy <= r; dy++) {
            double hw = Math.abs(dy) <= r / 2.0 ? r * 0.866 : r * 0.866 * (r - Math.abs(dy)) / (r / 2.0);
            int wi = (int) Math.round(hw);
            if (wi > 0) g.fill(cx - wi, cy + dy, cx + wi, cy + dy + 1, c);
        }
    }

    private static void honeycomb(GuiGraphics g, int x, int y, int w, int h, int t) {
        g.fillGradient(x, y, x + w, y + h, 0xFF1B1204, 0xFF3A2606);
        int r = 10;
        double dx = r * 1.732, dy = r * 1.5;
        for (int row = -1; row * dy < h + r; row++) {
            for (int col = -1; col * dx < w + r; col++) {
                int cx = x + (int) (col * dx + (row % 2 != 0 ? dx / 2 : 0)), cy = y + (int) (row * dy);
                double dist = Math.hypot(cx - x - w / 2.0, cy - y - h / 2.0);
                float v = (float) (0.5 + 0.5 * Math.sin(t * 0.045 - dist / 22.0));
                hex(g, cx, cy, r - 1, App.mix(0x3A2A06, 0xFFC832, v * v));
            }
        }
    }

    // ---------- 5: little bees flying across a sky ----------
    private static void bee(GuiGraphics g, int x, int y, int t, int dir) {
        int flap = (t / 3) % 2;
        g.fill(x + 3, y - 3 - flap, x + 7, y, 0xCCFFFFFF);
        g.fill(x + 8, y - 3 - (1 - flap), x + 12, y, 0xCCFFFFFF);
        g.fill(x, y, x + 14, y + 8, 0xFFFFD23C);
        g.fill(x + 4, y, x + 6, y + 8, 0xFF3A2A3A);
        g.fill(x + 9, y, x + 11, y + 8, 0xFF3A2A3A);
        int ex = dir > 0 ? x + 12 : x + 1;
        g.fill(ex, y + 2, ex + 1, y + 4, 0xFF3A2A3A);
        int sx = dir > 0 ? x - 2 : x + 14;
        g.fill(sx, y + 4, sx + 2, y + 5, 0xFF3A2A3A);
    }

    private static void bees(GuiGraphics g, int x, int y, int w, int h, int t) {
        g.fillGradient(x, y, x + w, y + h, 0xFF8FD0FF, 0xFFE6F6FF);
        for (int i = 0; i < 5; i++) {
            int cx = x + (int) wrap(t * (0.15 + 0.05 * i) + rnd(i, 3) * (w + 80), w + 80) - 40;
            int cy = y + 12 + (int) (rnd(i, 4) * (h - 70));
            g.fill(cx, cy + 4, cx + 36, cy + 10, 0xCCFFFFFF);
            g.fill(cx + 6, cy, cx + 26, cy + 6, 0xCCFFFFFF);
        }
        for (int i = 0; i < 7; i++) {
            int dir = i % 2 == 0 ? 1 : -1;
            double sp = 0.8 + rnd(i, 5) * 0.9;
            double pos = wrap(t * sp * dir + rnd(i, 6) * (w + 60), w + 60);
            int bx = x + (int) pos - 30, by = y + 20 + (int) (rnd(i, 7) * (h - 60)) + (int) (Math.sin(t * 0.05 + i) * 12);
            for (int k = 1; k <= 4; k++) g.fill(bx - dir * k * 6, by + 9 + (int) (Math.sin((t - k * 4) * 0.05 + i) * 2), bx - dir * k * 6 + 2, by + 10 + (int) (Math.sin((t - k * 4) * 0.05 + i) * 2), 0x88FFFFFF);
            bee(g, bx, by, t + i * 5, dir);
        }
    }

    // ---------- 6: glossy bubbles rising (Frutiger Aero) ----------
    private static void bubbles(GuiGraphics g, int x, int y, int w, int h, int t) {
        g.fillGradient(x, y, x + w, y + h, 0xFF1A66C8, 0xFF86DCFF);
        for (int i = 0; i < 30; i++) {
            int r = 4 + (int) (rnd(i, 1) * 14);
            double sp = 0.35 + rnd(i, 2) * 0.7;
            int by = y + h + r - (int) wrap(t * sp + rnd(i, 3) * (h + 2 * r), h + 2 * r);
            int bx = x + (int) (rnd(i, 4) * w) + (int) (Math.sin(t * 0.02 + i) * 9);
            disc(g, bx, by, r, 0x40FFFFFF);
            disc(g, bx, by, Math.max(1, r - 2), 0x26B8E8FF);
            g.fill(bx - r / 2, by - r / 2, bx - r / 2 + Math.max(2, r / 3), by - r / 2 + 2, 0xCCFFFFFF);
        }
    }

    // ---------- 7: an aquarium ----------
    private static void aquarium(GuiGraphics g, int x, int y, int w, int h, int t) {
        g.fillGradient(x, y, x + w, y + h, 0xFF0B5C9E, 0xFF083A66);
        g.fill(x, y + h - 14, x + w, y + h, 0xFFD9C48E);
        for (int i = 0; i < 9; i++) {                              // seaweed
            int sx = x + 10 + i * (w / 9), sh = 24 + (int) (rnd(i, 1) * 26);
            for (int k = 0; k < sh; k += 3) {
                int off = (int) (Math.sin(t * 0.04 + i + k * 0.12) * (2 + k / 10.0));
                g.fill(sx + off, y + h - 14 - k, sx + off + 3, y + h - 11 - k, 0xFF2E9E5B);
            }
        }
        for (int i = 0; i < 9; i++) {                              // fish
            int dir = i % 2 == 0 ? 1 : -1;
            double sp = 0.35 + rnd(i, 2) * 0.55;
            int fx = x + (int) wrap(t * sp * dir + rnd(i, 3) * (w + 60), w + 60) - 30;
            int fy = y + 14 + (int) (rnd(i, 4) * (h - 70)) + (int) (Math.sin(t * 0.04 + i) * 6);
            int c = hsv((float) rnd(i, 5), 0.65f, 1f);
            int r = 4 + i % 3;
            disc(g, fx, fy, r, c);
            disc(g, fx - dir * 3, fy, r - 1, c);
            g.fill(dir > 0 ? fx - r - 7 : fx + r + 3, fy - 3, dir > 0 ? fx - r - 3 : fx + r + 7, fy + 4, App.mix(c & 0xFFFFFF, 0x000000, 0.2f));
            g.fill(fx + dir * (r - 2), fy - 2, fx + dir * (r - 2) + 1, fy - 1, 0xFFFFFFFF);
        }
        for (int i = 0; i < 14; i++) {                             // bubbles
            int by = y + h - (int) wrap(t * (0.5 + rnd(i, 6) * 0.5) + rnd(i, 7) * h, h);
            disc(g, x + (int) (rnd(i, 8) * w) + (int) (Math.sin(t * 0.05 + i) * 3), by, 1 + i % 3, 0x77DFF4FF);
        }
    }

    // ---------- 8: the classic pipes, drawn as a growing maze of tubes ----------
    private static void pipes(GuiGraphics g, int x, int y, int w, int h, int t) {
        g.fill(x, y, x + w, y + h, 0xFF08080F);
        int cycle = t / 1500, steps = (t % 1500) / 3;
        Random r = new Random(cycle * 7919L + 13);
        int cell = 12, cols = w / cell, rows = h / cell;
        int[] dx = {1, 0, -1, 0}, dy = {0, 1, 0, -1};
        int[] colors = {0xFFE5484D, 0xFF5BBF6A, 0xFF2F7FD6, 0xFFF3C45A, 0xFFB57BD6};
        int cx = cols / 2, cy = rows / 2, dir = r.nextInt(4), pipeColor = 0;
        for (int s = 0; s < steps; s++) {
            if (s % 45 == 0 && s > 0) {                            // a new pipe starts somewhere else
                cx = 2 + r.nextInt(Math.max(1, cols - 4));
                cy = 2 + r.nextInt(Math.max(1, rows - 4));
                dir = r.nextInt(4);
                pipeColor = (pipeColor + 1) % colors.length;
            }
            if (r.nextInt(100) < 28) dir = (dir + (r.nextBoolean() ? 1 : 3)) % 4;
            int nx = cx + dx[dir], ny = cy + dy[dir];
            if (nx < 1 || ny < 1 || nx >= cols - 1 || ny >= rows - 1) {
                dir = (dir + 1) % 4;
                nx = cx + dx[dir];
                ny = cy + dy[dir];
                if (nx < 1 || ny < 1 || nx >= cols - 1 || ny >= rows - 1) { dir = (dir + 2) % 4; nx = cx + dx[dir]; ny = cy + dy[dir]; }
            }
            int c = colors[pipeColor];
            int x0 = x + Math.min(cx, nx) * cell + cell / 2 - 3, y0 = y + Math.min(cy, ny) * cell + cell / 2 - 3;
            int x1 = x + Math.max(cx, nx) * cell + cell / 2 + 3, y1 = y + Math.max(cy, ny) * cell + cell / 2 + 3;
            g.fill(x0, y0, x1, y1, c);
            g.fill(x0, y0, x1, y0 + 1, 0x66FFFFFF);
            g.fill(x0, y0, x0 + 1, y1, 0x44FFFFFF);
            g.fill(x + nx * cell + cell / 2 - 4, y + ny * cell + cell / 2 - 4, x + nx * cell + cell / 2 + 4, y + ny * cell + cell / 2 + 4, c);
            g.fill(x + nx * cell + cell / 2 - 3, y + ny * cell + cell / 2 - 3, x + nx * cell + cell / 2 - 1, y + ny * cell + cell / 2 - 1, 0xAAFFFFFF);
            cx = nx;
            cy = ny;
        }
    }
}
