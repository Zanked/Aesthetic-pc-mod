package dev.cutemod.client.os;

import java.util.ArrayList;
import java.util.List;

/**
 * Everything that can sit in the Dock, in the Start menu, on the desktop or in a folder has one number:
 * <ul>
 *   <li>2 .. {@link Desktop#ICONS} - 1: a system or store app (the old Dock numbers; 0 and 1 are gone: the own-game
 *       icon and the Games folder do not exist any more, every game is an app of its own now);</li>
 *   <li>{@link #GAME_BASE} + n: the game number n of {@link Library#GAMES};</li>
 *   <li>{@link #FOLDER_BASE} + n: a folder made by the player (see {@link Folders}).</li>
 * </ul>
 */
public final class Items {
    private Items() {}

    public static final int GAME_BASE = 100, FOLDER_BASE = 1000;

    public static boolean isApp(int id) { return id >= 2 && id < Desktop.ICONS; }

    public static boolean isGame(int id) { return id >= GAME_BASE && id < GAME_BASE + Library.GAMES.size(); }

    public static boolean isFolder(int id) { return id >= FOLDER_BASE; }

    public static boolean valid(int id) { return isApp(id) || isGame(id) || isFolder(id); }

    /** The game id ("pink", "craft"...) of a game number, or null. */
    public static String gameId(int id) { return isGame(id) ? Library.GAMES.get(id - GAME_BASE).id() : null; }

    /** The number of a game id, or -1. */
    public static int ofGame(String gameId) {
        for (int i = 0; i < Library.GAMES.size(); i++) if (Library.GAMES.get(i).id().equals(gameId)) return GAME_BASE + i;
        return -1;
    }

    /** Apps first, then games: the installed things that fit into a folder. */
    public static List<Integer> pickable() {
        List<Integer> l = new ArrayList<>();
        for (int i = 2; i < Desktop.ICONS; i++) if (Library.available(i)) l.add(i);
        for (int i = 0; i < Library.GAMES.size(); i++) if (Library.available(GAME_BASE + i)) l.add(GAME_BASE + i);
        return l;
    }

    /** What the Start menu lists: folders, apps, games. */
    public static List<Integer> startList() {
        List<Integer> l = new ArrayList<>();
        for (int f : Folders.all()) if (Library.available(f)) l.add(f);
        l.addAll(pickable());
        return l;
    }
}
