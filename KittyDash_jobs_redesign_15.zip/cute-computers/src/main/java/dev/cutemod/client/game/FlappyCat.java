package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/** Pink computer: tap to flap, fly between the pipes. */
public class FlappyCat extends MiniGame {
    private static final double BX = 50, GRAVITY = 0.16, FLAP = -3.0, SPEED = 1.3;
    private static final int PIPE_W = 24, GAP = 52, SPACING = 100;

    private double y, vy;
    private boolean started;
    private int t;
    private final List<double[]> pipes = new ArrayList<>(); // x, gapCenterY, scored(0/1)

    @Override
    public void reset() {
        score = 0; over = false; started = false; t = 0;
        y = H / 2.0; vy = 0;
        pipes.clear();
    }

    private void flap() {
        started = true;
        vy = FLAP;
        pling(1.6F);
    }

    @Override
    public boolean click(int x, int yy, int button) { flap(); return true; }

    @Override
    public boolean key(int k) {
        if (k == KEY_SPACE || k == KEY_UP) { flap(); return true; }
        return false;
    }

    @Override
    public void tick() {
        t++;
        if (!started) { y = H / 2.0 + Math.sin(t * 0.06) * 4; return; }
        vy += GRAVITY;
        y += vy;
        if (pipes.isEmpty() || pipes.get(pipes.size() - 1)[0] < W - SPACING) {
            pipes.add(new double[]{W + 4, 34 + rnd.nextInt(H - 68), 0});
        }
        for (double[] p : pipes) {
            p[0] -= SPEED;
            if (p[2] == 0 && p[0] + PIPE_W < BX - 6) { p[2] = 1; score++; pling(1.2F + Math.min(score, 20) * 0.03F); }
            boolean overlapX = BX + 6 > p[0] && BX - 6 < p[0] + PIPE_W;
            if (overlapX && (y - 5 < p[1] - GAP / 2.0 || y + 5 > p[1] + GAP / 2.0)) over = true;
        }
        pipes.removeIf(p -> p[0] < -PIPE_W - 2);
        if (y < 2 || y > H - 11) over = true;
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFFFFE3F1, 0xFFFFB9D8);
        for (int i = 0; i < 3; i++) { // clouds
            int cx = (int) ((i * 90 - t * 0.3 % 270 + 270) % 270) - 30;
            rect(g, cx, 20 + i * 22, 28, 8, 0xAAFFFFFF);
            rect(g, cx + 6, 16 + i * 22, 16, 6, 0xAAFFFFFF);
        }
        for (double[] p : pipes) {
            int x = (int) p[0], top = (int) (p[1] - GAP / 2.0), bot = (int) (p[1] + GAP / 2.0);
            rect(g, x, 0, PIPE_W, top, 0xFF4E9F5E);
            rect(g, x + 2, 0, 5, top, 0xFF7CCF8A);
            rect(g, x - 2, top - 8, PIPE_W + 4, 8, 0xFF3E8450);
            rect(g, x, bot, PIPE_W, H - bot, 0xFF4E9F5E);
            rect(g, x + 2, bot, 5, H - bot, 0xFF7CCF8A);
            rect(g, x - 2, bot, PIPE_W + 4, 8, 0xFF3E8450);
        }
        rect(g, 0, H - 8, W, 8, 0xFFE58AAE);
        rect(g, 0, H - 8, W, 2, 0xFFFFB3CE);
        // the cat
        int cx = (int) BX - 7, cy = (int) y - 6;
        rect(g, cx, cy, 14, 12, 0xFFF58FB8);
        rect(g, cx, cy - 3, 3, 3, 0xFFF58FB8);
        rect(g, cx + 11, cy - 3, 3, 3, 0xFFF58FB8);
        rect(g, cx + 3, cy + 4, 2, 2, 0xFF3A2A3A);
        rect(g, cx + 9, cy + 4, 2, 2, 0xFF3A2A3A);
        rect(g, cx + 6, cy + 7, 2, 1, 0xFFC04A7A);
        rect(g, cx - 3, cy + 7, 3, 1, 0xFFFFFFFF);
        rect(g, cx + 14, cy + 7, 3, 1, 0xFFFFFFFF);
        if (!started) ctext(g, "click / space", W / 2, H - 28, 0xFF7A3A5A);
    }

    @Override
    public String hintKey() { return "cutemod.hint.flappy"; }
}
