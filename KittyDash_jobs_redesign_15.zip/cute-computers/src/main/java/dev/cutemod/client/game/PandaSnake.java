package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** White computer: a panda snake eating bamboo. */
public class PandaSnake extends MiniGame {
    private static final int CELL = 10, COLS = W / CELL, ROWS = H / CELL;

    private final List<int[]> body = new ArrayList<>(); // index 0 = head
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();
    private int dx, dy, fx, fy, counter;
    private boolean started;

    @Override
    public void reset() {
        score = 0; over = false; started = false; counter = 0;
        body.clear(); queue.clear();
        for (int i = 0; i < 3; i++) body.add(new int[]{8 - i, ROWS / 2});
        dx = 1; dy = 0;
        placeFood();
    }

    private void placeFood() {
        while (true) {
            fx = rnd.nextInt(COLS); fy = rnd.nextInt(ROWS);
            boolean free = true;
            for (int[] s : body) if (s[0] == fx && s[1] == fy) { free = false; break; }
            if (free) return;
        }
    }

    @Override
    public boolean key(int k) {
        int ndx, ndy;
        switch (k) {
            case KEY_UP, 87 -> { ndx = 0; ndy = -1; }
            case KEY_DOWN, 83 -> { ndx = 0; ndy = 1; }
            case KEY_LEFT, 65 -> { ndx = -1; ndy = 0; }
            case KEY_RIGHT, 68 -> { ndx = 1; ndy = 0; }
            default -> { return false; }
        }
        int ldx = queue.isEmpty() ? dx : queue.peekLast()[0];
        int ldy = queue.isEmpty() ? dy : queue.peekLast()[1];
        if (ndx == -ldx && ndy == -ldy) return true; // no reversing
        if (ndx == ldx && ndy == ldy) { started = true; return true; }
        if (queue.size() < 3) queue.add(new int[]{ndx, ndy});
        started = true;
        return true;
    }

    @Override
    public void tick() {
        if (!started) return;
        int interval = Math.max(5, 11 - score / 3);
        if (++counter < interval) return;
        counter = 0;
        if (!queue.isEmpty()) { int[] d = queue.poll(); dx = d[0]; dy = d[1]; }
        int nx = body.get(0)[0] + dx, ny = body.get(0)[1] + dy;
        if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS) { over = true; return; }
        boolean eat = nx == fx && ny == fy;
        int limit = eat ? body.size() : body.size() - 1; // tail moves away
        for (int i = 0; i < limit; i++) {
            if (body.get(i)[0] == nx && body.get(i)[1] == ny) { over = true; return; }
        }
        body.add(0, new int[]{nx, ny});
        if (eat) { score++; pling(1.0F + Math.min(score, 24) * 0.04F); placeFood(); }
        else body.remove(body.size() - 1);
    }

    @Override
    public void render(GuiGraphics g) {
        for (int x = 0; x < COLS; x++)
            for (int y = 0; y < ROWS; y++)
                rect(g, x * CELL, y * CELL, CELL, CELL, ((x + y) & 1) == 0 ? 0xFFCDE8C6 : 0xFFC0DDB8);
        // bamboo
        rect(g, fx * CELL + 3, fy * CELL + 1, 4, 8, 0xFF3E9A4A);
        rect(g, fx * CELL + 3, fy * CELL + 1, 1, 8, 0xFF7CD58A);
        rect(g, fx * CELL + 2, fy * CELL + 4, 6, 1, 0xFF2A6B33);
        // snake
        for (int i = body.size() - 1; i >= 1; i--) {
            int[] s = body.get(i);
            rect(g, s[0] * CELL + 1, s[1] * CELL + 1, CELL - 2, CELL - 2, (i & 1) == 0 ? 0xFF3A3A44 : 0xFFFFFFFF);
        }
        int[] h = body.get(0);
        int hx = h[0] * CELL, hy = h[1] * CELL;
        rect(g, hx, hy, CELL, CELL, 0xFFFFFFFF);
        rect(g, hx, hy, 3, 3, 0xFF25252D);
        rect(g, hx + 7, hy, 3, 3, 0xFF25252D);
        rect(g, hx + 2, hy + 4, 2, 2, 0xFF25252D);
        rect(g, hx + 6, hy + 4, 2, 2, 0xFF25252D);
        rect(g, hx + 4, hy + 7, 2, 2, 0xFF25252D);
        if (!started) ctext(g, "WASD / ←↑↓→", W / 2, H - 24, 0xFF2A5A33);
    }

    @Override
    public String hintKey() { return "cutemod.hint.snake"; }
}
