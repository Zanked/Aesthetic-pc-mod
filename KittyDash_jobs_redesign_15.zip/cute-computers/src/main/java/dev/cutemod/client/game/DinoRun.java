package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The "no connection" runner of the browser: a panda-saur runs along the ground, jumps over bamboo and creepers
 * and ducks under bees. It is not in the Games folder: the browser draws it on its not-found page, so it has its own
 * size (the whole page area) instead of the usual 220 x 140.
 */
public class DinoRun extends MiniGame {
    private final int vw, vh, ground;

    private static final int DX = 28, DW = 18, DH = 20, DUCK_H = 11, DUCK_W = 22;
    private static final float GRAVITY = 0.4F, JUMP = -6.4F;

    private record Obs(int kind, float x, int w, int h, int y) {} // kind 0 bamboo, 1 creeper, 2 bee; y = top

    private final List<Obs> obs = new ArrayList<>();
    private boolean started;
    private float dy, vy;          // height above the ground (0 = standing) and its speed (up is negative)
    private int duck;              // ticks left of the ducking
    private float speed, dist;
    private int t, overTicks, milestone;
    private float gap;            // distance (px) until the next obstacle appears
    private float night, nightGoal;
    private final int[] cloudX = new int[4], cloudY = new int[4];
    private static int hi;         // the best score of this session

    public DinoRun(int vw, int vh) {
        this.vw = vw;
        this.vh = vh;
        this.ground = vh - 26;
        for (int i = 0; i < cloudX.length; i++) { cloudX[i] = 30 + i * (vw / 3); cloudY[i] = 30 + (i * 17) % 28; }
        reset();
    }

    @Override
    public void reset() {
        score = 0; over = false;
        obs.clear();
        started = false;
        dy = 0; vy = 0; duck = 0;
        speed = 2.1F; dist = 0;
        t = 0; overTicks = 0; milestone = 0;
        night = 0; nightGoal = 0;
        gap = 200;
    }

    public boolean isRunning() { return started && !over; }

    // ---------- input ----------
    private void jump() {
        if (dy == 0 && vy == 0) {
            vy = JUMP;
            duck = 0;
            pling(1.5F);
        }
    }

    @Override
    public boolean key(int k) {
        if (over) {
            if ((k == KEY_SPACE || k == KEY_UP || k == 257 || k == 87) && overTicks > 20) { reset(); started = true; jump(); }
            return true;
        }
        if (k == KEY_SPACE || k == KEY_UP || k == 87) {
            if (!started) started = true;
            jump();
            return true;
        }
        if (k == KEY_DOWN || k == 83) {
            if (!started) return true;
            if (dy > 0) vy = Math.max(vy, 3.5F);      // in the air: drop faster
            else duck = 30;                           // on the ground: duck for half a second
            return true;
        }
        return false;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) { if (overTicks > 20) { reset(); started = true; jump(); } return true; }
        if (!started) started = true;
        jump();
        return true;
    }

    // ---------- game ----------
    private int curH() { return duck > 0 && dy == 0 ? DUCK_H : DH; }

    private int curW() { return duck > 0 && dy == 0 ? DUCK_W : DW; }

    @Override
    public void tick() {
        if (over) { overTicks++; return; }
        t++;
        if (!started) return;

        // the panda-saur
        if (duck > 0) duck--;
        if (vy != 0 || dy > 0) {
            vy += GRAVITY;
            dy -= vy;
            if (dy <= 0) { dy = 0; vy = 0; }
        }
        // the world
        speed = Math.min(4.8F, 2.1F + score / 60 * 0.14F);
        dist += speed;
        score = (int) (dist / 8);
        if (score / 100 > milestone) { milestone = score / 100; pling(2.0F); }
        nightGoal = (score / 350) % 2 == 1 ? 1F : 0F;
        night += (nightGoal - night) * 0.02F;
        for (int i = 0; i < cloudX.length; i++) {
            cloudX[i] -= (t % 3 == 0) ? 1 : 0;
            if (cloudX[i] < -20) { cloudX[i] = vw + rnd.nextInt(40); cloudY[i] = 24 + rnd.nextInt(34); }
        }
        // obstacles
        for (int i = obs.size() - 1; i >= 0; i--) {
            Obs o = obs.get(i);
            Obs m = new Obs(o.kind(), o.x() - speed, o.w(), o.h(), o.y());
            if (m.x() + m.w() < 0) obs.remove(i); else obs.set(i, m);
        }
        gap -= speed;
        if (gap <= 0) {
            spawn();
            gap = 100 + 26 * speed + rnd.nextInt(120);
        }
        // a hit (the boxes are a little smaller than the pictures, so it feels fair)
        int px = DX + 2, pw = curW() - 5, ph = curH() - 3, py = ground - Math.round(dy) - curH() + 2;
        for (Obs o : obs) {
            int ox = Math.round(o.x()) + 2, ow = o.w() - 4, oy = o.y() + 2, oh = o.h() - 3;
            if (px < ox + ow && px + pw > ox && py < oy + oh && py + ph > oy) {
                over = true;
                overTicks = 0;
                if (score > hi) hi = score;
                return;
            }
        }
    }

    private void spawn() {
        int r = rnd.nextInt(100);
        if (score > 250 && r < 28) {              // a bee: low (jump) or at the head (duck)
            boolean low = rnd.nextBoolean();
            obs.add(new Obs(2, vw + 10, 14, 10, ground - (low ? 12 : 24)));
        } else if (r < 55) {                      // a creeper
            obs.add(new Obs(1, vw + 10, 12, 20, ground - 20));
        } else {                                  // bamboo: 1 to 3 stalks, tall or short
            int n = 1 + rnd.nextInt(score > 120 ? 3 : 2);
            int h = rnd.nextBoolean() ? 16 : 24;
            obs.add(new Obs(0, vw + 10, n * 6 - 2, h, ground - h));
        }
    }

    // ---------- drawing ----------
    private static int lerp(int a, int b, float f) {
        int r = Math.round(((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = Math.round(((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = Math.round((a & 255) * (1 - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    @Override
    public void render(GuiGraphics g) {
        int skyTop = lerp(0xFFDDF1FF, 0xFF15122A, night), skyBot = lerp(0xFFF6FBFF, 0xFF3A2F5A, night);
        g.fillGradient(0, 0, vw, ground, skyTop, skyBot);
        int ink = lerp(0xFF4A4A5E, 0xFFE8E4F4, night);

        // stars / sun / moon and clouds
        if (night > 0.3F) {
            int a = (int) (255 * Math.min(1F, night));
            for (int i = 0; i < 14; i++) rect(g, (i * 61 + 13) % vw, 4 + (i * 23) % 60, 1, 1, (a << 24) | 0xFFFFFF);
            disc(g, vw - 44, 30, 7, (a << 24) | 0xF3EEC8);
            disc(g, vw - 41, 28, 6, lerp(skyTop, skyBot, 0.4F));
        } else {
            disc(g, vw - 44, 30, 7, lerp(0xFFFFE27A, 0xFFFFE27A, 0));
        }
        int cloud = lerp(0xFFFFFFFF, 0xFF4A4468, night);
        for (int i = 0; i < cloudX.length; i++) {
            rect(g, cloudX[i], cloudY[i], 16, 4, cloud);
            rect(g, cloudX[i] + 3, cloudY[i] - 3, 9, 3, cloud);
        }

        // the ground
        rect(g, 0, ground, vw, vh - ground, lerp(0xFFB9E3A0, 0xFF2B3A2E, night));
        rect(g, 0, ground, vw, 2, lerp(0xFF6BB35A, 0xFF4A6A4A, night));
        int off = (int) (dist % 40);
        for (int x = -off; x < vw; x += 40) {
            rect(g, x + 8, ground + 8, 5, 1, lerp(0xFF8CCB78, 0xFF3E5A44, night));
            rect(g, x + 27, ground + 14, 3, 1, lerp(0xFF8CCB78, 0xFF3E5A44, night));
        }

        for (Obs o : obs) drawObs(g, o);
        drawPanda(g);

        // title (before the first jump) and scores
        if (!started) {
            ctextAt(g, Component.translatable("cutemod.dino.title").getString(), vw / 2, 10, ink);
            ctextAt(g, Component.translatable("cutemod.dino.sub").getString(), vw / 2, 24, lerp(0xFF7A7A90, 0xFFB8B0C8, night));
            ctextAt(g, Component.translatable("cutemod.dino.start").getString(), vw / 2, ground - 40, ink);
        } else {
            String s = String.format("%05d", score);
            String h = hi > 0 ? "HI " + String.format("%05d", hi) + "  " : "";
            g.drawString(font(), h + s, vw - 8 - font().width(h + s), 6, ink, false);
        }
        if (over) {
            int w = 150, bh = 36, x = (vw - w) / 2, y = 22;
            g.fill(x - 1, y - 1, x + w + 1, y + bh + 1, 0xFFFFFFFF);
            g.fill(x, y, x + w, y + bh, 0xE0201828);
            g.drawCenteredString(font(), Component.translatable("cutemod.dino.over"), x + w / 2, y + 6, 0xFFFFD866);
            g.drawCenteredString(font(), Component.translatable("cutemod.ui.score", score), x + w / 2, y + 16, 0xFFFFFFFF);
            g.drawCenteredString(font(), Component.translatable("cutemod.ui.restart"), x + w / 2, y + 26, 0xFFB8B0C8);
        }
    }

    private void ctextAt(GuiGraphics g, String s, int cx, int y, int argb) {
        g.drawString(font(), s, cx - font().width(s) / 2, y, argb, false);
    }

    private void drawObs(GuiGraphics g, Obs o) {
        int x = Math.round(o.x()), y = o.y();
        switch (o.kind()) {
            case 0 -> {   // bamboo stalks
                int n = (o.w() + 2) / 6;
                for (int i = 0; i < n; i++) {
                    int sx = x + i * 6, sh = (i % 2 == 0) ? o.h() : o.h() - 6, sy = ground - sh;
                    rect(g, sx, sy, 4, sh, 0xFF5DB04A);
                    rect(g, sx + 3, sy, 1, sh, 0xFF3F8A36);
                    for (int j = 4; j < sh; j += 8) rect(g, sx - 1, sy + j, 6, 1, 0xFF2F6A2A);
                    rect(g, sx + 4, sy + 2, 4, 2, 0xFF7ACB5E);   // a leaf
                }
            }
            case 1 -> {   // creeper
                rect(g, x, y, 12, 14, 0xFF4CAF50);
                rect(g, x + 1, y + 1, 10, 12, 0xFF5FC25A);
                rect(g, x + 2, y + 3, 3, 3, 0xFF1B3A1E); rect(g, x + 7, y + 3, 3, 3, 0xFF1B3A1E);
                rect(g, x + 5, y + 6, 2, 3, 0xFF1B3A1E); rect(g, x + 3, y + 9, 6, 3, 0xFF1B3A1E);
                rect(g, x + 1, y + 14, 4, 6, 0xFF4CAF50); rect(g, x + 7, y + 14, 4, 6, 0xFF4CAF50);
            }
            default -> {  // a bee
                boolean up = (t / 5) % 2 == 0;
                rect(g, x + 3, y + (up ? 0 : 2), 4, 4, 0xDDEAF8FF);
                rect(g, x + 8, y + (up ? 0 : 2), 4, 4, 0xDDEAF8FF);
                rect(g, x, y + 3, 14, 7, 0xFFFFCF2E);
                rect(g, x + 4, y + 3, 2, 7, 0xFF3A2A1A); rect(g, x + 9, y + 3, 2, 7, 0xFF3A2A1A);
                rect(g, x, y + 5, 2, 2, 0xFF2A1D10);
            }
        }
    }

    private void drawPanda(GuiGraphics g) {
        int white = 0xFFFFFFFF, black = 0xFF2A2433, green = 0xFF5DB04A;
        int bottom = ground - Math.round(dy);
        boolean ducking = duck > 0 && dy == 0;
        int y = bottom - (ducking ? DUCK_H : DH);
        boolean step = dy == 0 && started && !over && (t / 5) % 2 == 0;
        if (ducking) {
            rect(g, DX - 2, y + 4, 4, 3, white);                       // tail
            rect(g, DX, y + 3, 18, 8, white);                          // body
            rect(g, DX + 3, y + 1, 2, 3, green); rect(g, DX + 8, y, 2, 4, green);
            rect(g, DX + 12, y, 10, 8, white);                         // head, stretched forward
            rect(g, DX + 12, y - 2, 3, 3, black); rect(g, DX + 19, y - 2, 3, 3, black);
            rect(g, DX + 16, y + 2, 3, 3, black);
            rect(g, DX + 20, y + 5, 2, 2, black);
            rect(g, DX + 3, y + 9, 4, 2, black); rect(g, DX + 11, y + 9, 4, 2, black);
        } else {
            rect(g, DX - 2, y + 11, 4, 3, white);                      // tail
            rect(g, DX + 1, y + 9, 14, 8, white);                      // body
            rect(g, DX + 3, y + 7, 2, 3, green); rect(g, DX + 7, y + 6, 2, 4, green); rect(g, DX + 11, y + 7, 2, 3, green);
            rect(g, DX + 6, y, 12, 10, white);                         // head
            rect(g, DX + 6, y - 2, 3, 3, black); rect(g, DX + 15, y - 2, 3, 3, black);   // ears
            rect(g, DX + 10, y + 3, 4, 3, black);                      // eye patch
            if (over) { rect(g, DX + 10, y + 3, 1, 1, white); rect(g, DX + 13, y + 5, 1, 1, white); }
            else rect(g, DX + 12, y + 4, 1, 1, white);
            rect(g, DX + 15, y + 6, 3, 2, black);                      // nose
            rect(g, DX + 3, y + 17 - (step ? 2 : 0), 4, 3, black);     // legs
            rect(g, DX + 10, y + 17 - (step ? 0 : 2), 4, 3, black);
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score", score); }

    @Override
    public String hintKey() { return "cutemod.dino.hint"; }

    @Override
    public Component endTitle() { return Component.translatable("cutemod.dino.over"); }
}
