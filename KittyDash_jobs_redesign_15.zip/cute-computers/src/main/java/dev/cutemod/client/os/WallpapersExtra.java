package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The six newer wallpapers of CuteMarket (numbers 13-18): sakura, aurora, synthwave sunset, neon grid,
 * winter forest and a summer meadow. Most of them move (petals, snow, lights, butterflies).
 * Everything is clipped to the box by hand: no scissor, because the box can sit inside an app that
 * already moved the pose (the shop icons) and a scissor ignores the pose.
 */
final class WallpapersExtra {
    // the box that is being drawn (the game renders on one thread, so plain statics are fine)
    private static GuiGraphics gg;
    private static int bx, by, bw, bh;

    private WallpapersExtra() {}

    static void draw(GuiGraphics g, int x, int y, int w, int h, int idx) {
        gg = g; bx = x; by = y; bw = Math.max(1, w); bh = Math.max(1, h);
        int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        switch (idx) {
            case 13 -> sakura(t);
            case 14 -> aurora(t);
            case 15 -> synthwave(t);
            case 16 -> neon(t);
            case 17 -> winter(t);
            default -> meadow(t);
        }
        gg = null;
    }

    // ---------- clipped drawing helpers ----------
    /** A filled rectangle (x0,y0 inclusive, x1,y1 exclusive), cut to the box. */
    private static void r(int x0, int y0, int x1, int y1, int argb) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fill(x0, y0, x1, y1, argb);
    }

    private static void grad(int x0, int y0, int x1, int y1, int top, int bottom) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fillGradient(x0, y0, x1, y1, top, bottom);
    }

    private static void disc(int cx, int cy, int rad, int argb) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            r(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** A ring: outer radius rad, thickness th. */
    private static void ring(int cx, int cy, int rad, int th, int argb) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dxo = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            int in = rad - th;
            if (Math.abs(dy) >= in) {
                r(cx - dxo, cy + dy, cx + dxo + 1, cy + dy + 1, argb);
            } else {
                int dxi = (int) Math.floor(Math.sqrt(in * in - dy * dy + 0.25));
                r(cx - dxo, cy + dy, cx - dxi, cy + dy + 1, argb);
                r(cx + dxi + 1, cy + dy, cx + dxo + 1, cy + dy + 1, argb);
            }
        }
    }

    /** A triangle with its tip up. */
    private static void tri(int cx, int topY, int w, int h, int argb) {
        for (int row = 0; row < h; row++) {
            int ww = Math.max(1, w * (row + 1) / h);
            r(cx - ww / 2, topY + row, cx - ww / 2 + ww, topY + row + 1, argb);
        }
    }

    private static int lerp(int a, int b, float f) {
        f = Math.max(0f, Math.min(1f, f));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * f) << 16) | ((int) (ag + (bg - ag) * f) << 8) | (int) (ab + (bb - ab) * f);
    }

    private static int unit() { return Math.max(1, Math.min(bw, bh) / 40); }

    // ---------- 13: sakura ----------
    private static void sakura(int t) {
        grad(bx, by, bx + bw, by + bh, 0xFFFFE6F0, 0xFFF4A3C4);
        int th = unit();
        // a branch from the top left corner with blossoms
        int len = bw * 11 / 12;
        for (int xx = 0; xx <= len; xx++) {                 // one column per pixel: the branch has no gaps
            double f = xx * 22.0 / Math.max(1, len);
            int py = by + bh / 12 + (int) (f * bh / 90) + (int) (Math.sin(f * 0.4) * bh * 0.03);
            r(bx + xx, py, bx + xx + 1, py + th * 2, 0xFF6B4A3A);
        }
        for (int i = 2; i <= 22; i += 4) {                  // blossoms along the branch
            int px = bx + i * len / 22;
            int py = by + bh / 12 + i * bh / 90 + (int) (Math.sin(i * 0.4) * bh * 0.03);
            int br = Math.max(1, Math.min(bw, bh) / 22);
            disc(px, py - th, br, 0xFFFFB3CF);
            disc(px, py - th, Math.max(1, br / 2), 0xFFFFF0F6);
        }
        // falling petals
        int[] cols = {0xFFFFFFFF, 0xFFFFC0D8, 0xFFF58FB8};
        int ps = Math.max(1, Math.min(bw, bh) / 45 + 1);
        for (int i = 0; i < 18; i++) {
            int fall = (i * 53 + t * (1 + i % 3) / 2) % (bh + ps * 4);
            int py = by + fall - ps * 2;
            int px = bx + (i * 61) % bw + (int) (Math.sin(t * 0.05 + i) * bw * 0.03);
            r(px, py, px + ps + 1, py + ps, cols[i % 3]);
            r(px + 1, py + ps, px + ps + 2, py + ps + 1, cols[(i + 1) % 3]);
        }
    }

    // ---------- 14: aurora ----------
    private static void aurora(int t) {
        grad(bx, by, bx + bw, by + bh, 0xFF070B24, 0xFF1B2A55);
        for (int i = 0; i < 22; i++) {      // stars
            int sx = bx + (i * 53 + 11) % bw, sy = by + (i * 29 + 5) % Math.max(1, bh * 6 / 10);
            r(sx, sy, sx + 1, sy + 1, ((t / 6 + i) % 5 == 0) ? 0x66FFFFFF : 0xCCFFFFFF);
        }
        int[] top = {0x8840FFB0, 0x77B070FF, 0x6640E0FF};
        int step = Math.max(2, bw / 70);
        for (int band = 0; band < 3; band++) {
            int base = by + bh * (24 + band * 11) / 100;
            int tall = bh * 34 / 100;
            for (int xx = 0; xx < bw; xx += step) {
                int off = (int) (Math.sin(xx * 0.045 + t * 0.03 + band * 1.7) * bh * 0.07);
                int y0 = base + off;
                int c = top[band];
                grad(bx + xx, y0, bx + xx + step, y0 + tall, c, c & 0x00FFFFFF);
            }
        }
        // dark hills at the bottom
        for (int xx = 0; xx < bw; xx += 2) {
            int hy = by + bh * 88 / 100 - (int) (Math.sin(xx * 0.03) * bh * 0.04);
            r(bx + xx, hy, bx + xx + 2, by + bh, 0xFF0A1022);
        }
    }

    // ---------- 15: synthwave sunset with a palm ----------
    private static void synthwave(int t) {
        int hz = by + bh * 55 / 100;
        grad(bx, by, bx + bw, hz, 0xFF1D0A3D, 0xFFFF5FA2);
        r(bx, hz, bx + bw, by + bh, 0xFF14062B);
        int cx = bx + bw / 2, sr = Math.min(bw, bh) * 28 / 100;
        int scy = hz - sr / 4;
        int slat = Math.max(1, sr / 10);
        for (int dy = -sr; dy <= sr; dy++) {
            int yy = scy + dy;
            if (yy >= hz) continue;
            if (dy > sr / 5 && ((yy / slat) % 2 == 0)) continue;     // stripes in the lower half of the sun
            int dx = (int) Math.floor(Math.sqrt(sr * sr - dy * dy + 0.25));
            r(cx - dx, yy, cx + dx + 1, yy + 1, lerp(0xFFFFE066, 0xFFFF4F9A, (dy + sr) / (2f * sr)));
        }
        // the grid on the ground: lines run towards you
        int gh = by + bh - hz;
        for (int k = 1; k <= 8; k++) {
            float f = (k + (t % 20) / 20f) / 8.5f;
            int yy = hz + (int) (f * f * gh);
            r(bx, yy, bx + bw, yy + 1, 0xCCFF4FD8);
        }
        for (int j = -8; j <= 8; j++) {
            for (int yy = hz; yy < by + bh; yy += 2) {
                float f = (yy - hz) / (float) Math.max(1, gh);
                int xx = cx + (int) (j * f * bw / 12f);
                r(xx, yy, xx + 1, yy + 2, 0x99FF4FD8);
            }
        }
        r(bx, hz, bx + bw, hz + 1, 0xFFFFA0E8);
        if (bw >= 80) palm(bx + bw * 82 / 100, hz + bh / 10, bh);
    }

    private static void palm(int px, int baseY, int h) {
        int sil = 0xFF0D0420;
        int trunkH = h * 38 / 100, segs = 12, sh = Math.max(1, trunkH / segs);
        int tx = px, ty = baseY;
        for (int i = 0; i < segs; i++) {
            tx = px - i * i / 14 - i * 2 / 3;
            ty = baseY - i * sh;
            r(tx, ty, tx + Math.max(2, h / 40), ty + sh + 1, sil);
        }
        int[][] dirs = {{-3, -1}, {-3, 1}, {-2, -3}, {3, -2}, {3, 1}, {1, -3}, {-1, 3}};
        for (int[] d : dirs) {
            for (int s = 1; s <= 10; s++) {
                int fx = tx + d[0] * s * Math.max(1, h / 90 + 1) / 2;
                int fy = ty + d[1] * s / 2 + s * s / 9;
                r(fx, fy, fx + 2, fy + 2, sil);
            }
        }
    }

    // ---------- 16: neon grid ----------
    private static void neon(int t) {
        grad(bx, by, bx + bw, by + bh, 0xFF0A0A1C, 0xFF1C0A30);
        int gs = Math.max(4, bw / 12);
        for (int xx = 0; xx < bw; xx += gs) r(bx + xx, by, bx + xx + 1, by + bh, 0x2200E5FF);
        for (int yy = 0; yy < bh; yy += gs) r(bx, by + yy, bx + bw, by + yy + 1, 0x2200E5FF);
        int m = Math.min(bw, bh);
        int th = Math.max(1, m / 40);
        float pulse = 0.5f + 0.5f * (float) Math.sin(t * 0.08);
        int c1x = bx + bw * 28 / 100, c1y = by + bh * 45 / 100, r1 = m * 28 / 100;
        disc(c1x, c1y, r1, 0x1500E5FF);
        ring(c1x, c1y, r1, th, 0xFF00E5FF);
        ring(c1x, c1y, Math.max(2, r1 * 6 / 10), th, lerp(0xFF0080A0, 0xFF00E5FF, pulse));
        if ((t / 7) % 11 != 0) {            // this sign flickers now and then
            int c2x = bx + bw * 68 / 100, c2y = by + bh * 55 / 100, r2 = m * 20 / 100;
            disc(c2x, c2y, r2, 0x15FF2BD6);
            ring(c2x, c2y, r2, th, 0xFFFF2BD6);
        }
        int ty0 = by + bh * 18 / 100;
        tri(bx + bw * 74 / 100, ty0, m * 18 / 100, m * 16 / 100, 0xFFFFE600);
        tri(bx + bw * 74 / 100, ty0 + th * 2, Math.max(2, m * 18 / 100 - th * 4), Math.max(2, m * 16 / 100 - th * 3), 0xFF140A2A);
        r(bx + bw * 10 / 100, by + bh * 85 / 100, bx + bw * 45 / 100, by + bh * 85 / 100 + th, 0xFFFF2BD6);
        r(bx + bw * 14 / 100, by + bh * 91 / 100, bx + bw * 38 / 100, by + bh * 91 / 100 + th, 0xFF00E5FF);
        int sy = by + (t * 2) % bh;         // a scan line moving down
        r(bx, sy, bx + bw, sy + Math.max(1, bh / 60), 0x3300E5FF);
    }

    // ---------- 17: winter forest ----------
    private static void winter(int t) {
        grad(bx, by, bx + bw, by + bh, 0xFF14213D, 0xFFA9C7E8);
        int m = Math.min(bw, bh);
        disc(bx + bw * 78 / 100, by + bh * 22 / 100, Math.max(2, m / 9), 0xFFFFF6D8);
        for (int i = 0; i < 12; i++) {
            int sx = bx + (i * 47 + 13) % bw, sy = by + (i * 31 + 7) % Math.max(1, bh / 2);
            r(sx, sy, sx + 1, sy + 1, 0xBBFFFFFF);
        }
        int ground = by + bh * 82 / 100;
        for (int i = 0; i < 6; i++) {
            int cx = bx + i * bw / 6 + bw / 12;
            int th = bh * (30 + (i * 13) % 18) / 100, tw = th * 2 / 3;
            int base = by + bh * 85 / 100;
            for (int layer = 0; layer < 3; layer++) {
                int lh = th * 5 / 10, lw = tw * (6 + layer * 2) / 8;
                int ly = base - th + layer * th * 22 / 100;
                tri(cx, ly, lw, lh, layer % 2 == 0 ? 0xFF1E4A3A : 0xFF2A6049);
                tri(cx, ly, Math.max(2, lw / 2), Math.max(2, lh / 3), 0xFFFFFFFF);    // snow on top of each layer
            }
            r(cx - 1, base, cx + 2, base + Math.max(1, bh / 30), 0xFF4A3426);
        }
        r(bx, ground, bx + bw, by + bh, 0xFFEAF4FF);
        r(bx, ground, bx + bw, ground + 1, 0xFFFFFFFF);
        int fs = Math.max(1, m / 40);
        for (int i = 0; i < 22; i++) {      // snowflakes
            int fall = (i * 47 + t * (1 + i % 2)) % (bh + fs * 2);
            int fy = by + fall - fs;
            int fx = bx + (i * 59) % bw + (int) (Math.sin(t * 0.06 + i) * bw * 0.02);
            r(fx, fy, fx + fs + (i % 2), fy + fs + (i % 2), 0xFFFFFFFF);
        }
    }

    // ---------- 18: summer meadow with butterflies ----------
    private static void meadow(int t) {
        grad(bx, by, bx + bw, by + bh, 0xFF8FD8FF, 0xFFEFFAFF);
        int m = Math.min(bw, bh);
        int sx = bx + bw * 18 / 100, sy = by + bh * 20 / 100, sr = Math.max(2, m / 8);
        disc(sx, sy, sr * 2, 0x33FFF3A0);
        disc(sx, sy, sr, 0xFFFFF3A0);
        for (int i = 0; i < 2; i++) {       // clouds drift to the right
            int cx = bx + ((t / 3 + i * bw / 2) % (bw + 40)) - 20, cy = by + bh * (24 + i * 12) / 100;
            int cr = Math.max(2, m / 12);
            disc(cx, cy, cr, 0xEEFFFFFF);
            disc(cx + cr, cy + 1, cr * 8 / 10, 0xEEFFFFFF);
            disc(cx - cr, cy + 1, cr * 7 / 10, 0xEEFFFFFF);
        }
        int y0 = by + bh * 62 / 100, y1 = by + bh * 78 / 100;
        for (int xx = 0; xx < bw; xx += 2) {
            int hy = y0 + (int) (Math.sin(xx * 0.035) * bh * 0.07);
            r(bx + xx, hy, bx + xx + 2, by + bh, 0xFF7ED67A);
        }
        for (int xx = 0; xx < bw; xx += 2) {
            int hy = y1 + (int) (Math.sin(xx * 0.05 + 2) * bh * 0.06);
            r(bx + xx, hy, bx + xx + 2, by + bh, 0xFF4FBF5C);
        }
        int[] fc = {0xFFFF8AC0, 0xFFFFD84A, 0xFFFFFFFF, 0xFFB57BD6};
        int fs = m >= 60 ? 2 : 1;
        for (int i = 0; i < 18; i++) {
            int fx = bx + (i * 37 + 5) % bw, fy = y1 + bh / 12 + (i * 29) % Math.max(1, bh * 14 / 100);
            r(fx, fy, fx + fs, fy + fs, fc[i % 4]);
        }
        int[] wc = {0xFFFF8AC0, 0xFFFFD84A, 0xFFB57BD6};
        int s = Math.max(1, m / 60 + 1);
        for (int i = 0; i < 3; i++) {       // butterflies
            int fx = bx + bw / 2 + (int) (Math.sin(t * 0.03 + i * 2.1) * bw * 0.35);
            int fy = by + bh * 48 / 100 + (int) (Math.cos(t * 0.05 + i) * bh * 0.12);
            int wing = ((t / 4 + i) % 2 == 0) ? 3 : 1;
            r(fx - wing * s, fy - s, fx, fy + s, wc[i]);
            r(fx + s, fy - s, fx + s + wing * s, fy + s, wc[i]);
            r(fx, fy - s, fx + s, fy + 2 * s, 0xFF3A2A3A);
        }
    }
}
