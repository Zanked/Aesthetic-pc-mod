package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Anime-style catcher: a chibi girl with a pink parasol (follows the mouse) catches falling sakura petals
 * and onigiri. Storm clouds take a heart. Catch petals in a row for a bigger combo bonus.
 */
public class SakuraCatch extends MiniGame {
    private static final int UY = H - 50, HALF = 18;
    private static final int PETAL = 0, ONIGIRI = 1, STORM = 2;

    private static final class Item {
        double x, y, vy, phase;
        int type;
    }

    private final List<Item> items = new ArrayList<>();
    private final double[] bgx = new double[14], bgy = new double[14];
    private double px;
    private int lives, spawnT, t, combo, flash, blink;

    @Override
    public void reset() {
        score = 0; over = false; lives = 3; combo = 0; flash = 0; t = 0; spawnT = 30; blink = 0;
        px = W / 2.0;
        items.clear();
        for (int i = 0; i < bgx.length; i++) { bgx[i] = rnd.nextInt(W); bgy[i] = rnd.nextInt(H); }
    }

    private int mult() { return 1 + Math.min(3, combo / 5); }

    @Override
    public void tick() {
        t++;
        if (flash > 0) flash--;
        if (blink > 0) blink--; else if (rnd.nextInt(200) == 0) blink = 6;
        px += (Math.max(HALF, Math.min(W - HALF, mx)) - px) * 0.35;
        for (int i = 0; i < bgx.length; i++) {
            bgy[i] += 0.3 + (i % 3) * 0.1;
            bgx[i] += Math.sin((t + i * 20) / 40.0) * 0.2;
            if (bgy[i] > H) { bgy[i] = -3; bgx[i] = rnd.nextInt(W); }
        }
        if (--spawnT <= 0) {
            Item it = new Item();
            it.x = 10 + rnd.nextInt(W - 20);
            it.y = -6;
            it.phase = rnd.nextDouble() * 6;
            double stormP = Math.min(0.28, 0.08 + t / 9000.0);
            double r = rnd.nextDouble();
            it.type = r < stormP ? STORM : r < stormP + 0.08 ? ONIGIRI : PETAL;
            it.vy = 0.9 + rnd.nextDouble() * 0.5 + Math.min(t / 3600.0, 1) * 0.9;
            items.add(it);
            spawnT = Math.max(14, 36 - t / 200);
        }
        for (int i = items.size() - 1; i >= 0; i--) {
            Item it = items.get(i);
            it.y += it.vy;
            it.x += Math.sin(it.phase + it.y / 14.0) * (it.type == PETAL ? 0.6 : 0.2);
            if (it.y >= UY - 2 && it.y <= UY + 8 && Math.abs(it.x - px) <= HALF + 2) {
                items.remove(i);
                if (it.type == STORM) {
                    lives--; combo = 0; flash = 12; beep();
                    if (lives <= 0) over = true;
                } else {
                    combo++;
                    score += (it.type == ONIGIRI ? 5 : 1) * mult();
                    pling(it.type == ONIGIRI ? 1.6F : 1.0F + Math.min(combo, 15) * 0.03F);
                }
            } else if (it.y > H - 6) {
                items.remove(i);
                if (it.type == PETAL) combo = 0;
            }
        }
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFFFFC9DF, 0xFFC9B6F2);
        // a big pale sun and far mountains
        disc(g, 160, 40, 24, 0x66FFFFFF);
        disc(g, 160, 40, 16, 0x88FFFFFF);
        for (int x = 0; x < W; x++) {
            int h = 14 + (int) (10 * Math.sin(x / 22.0) + 6 * Math.sin(x / 9.0));
            rect(g, x, H - 14 - h, 1, h, 0xFFB79AD8);
        }
        // a torii gate
        rect(g, 22, H - 52, 3, 38, 0xFFE0566A);
        rect(g, 44, H - 52, 3, 38, 0xFFE0566A);
        rect(g, 18, H - 56, 33, 4, 0xFFE0566A);
        rect(g, 22, H - 48, 25, 2, 0xFFE0566A);
        rect(g, 0, H - 14, W, 14, 0xFF8FD39A);
        rect(g, 0, H - 14, W, 2, 0xFFB8EAC0);
        for (int i = 0; i < bgx.length; i++) rect(g, (int) bgx[i], (int) bgy[i], 2, 2, 0xAAFFFFFF);

        for (Item it : items) drawItem(g, it);
        drawGirl(g);
        if (flash > 0) rect(g, 0, 0, W, H, 0x33FFFFFF);
        if (combo >= 5) ctext(g, "x" + mult() + "  combo " + combo, W / 2, 4, 0xFFFFFFFF);
    }

    private void drawItem(GuiGraphics g, Item it) {
        int x = (int) it.x, y = (int) it.y;
        switch (it.type) {
            case PETAL -> {
                rect(g, x - 2, y - 1, 5, 3, 0xFFFF8FB8);
                rect(g, x - 1, y - 2, 3, 5, 0xFFFFB6D2);
                rect(g, x, y - 1, 1, 1, 0xFFFFFFFF);
            }
            case ONIGIRI -> {
                rect(g, x - 1, y - 6, 3, 2, 0xFFFFFFFF);
                rect(g, x - 3, y - 4, 7, 3, 0xFFFFFFFF);
                rect(g, x - 5, y - 1, 11, 3, 0xFFFFFFFF);
                rect(g, x - 5, y + 2, 11, 3, 0xFFF0F0F0);
                rect(g, x - 3, y + 1, 7, 4, 0xFF2A3A2A);
            }
            default -> {
                rect(g, x - 7, y - 4, 15, 6, 0xFF55506A);
                rect(g, x - 5, y - 6, 11, 3, 0xFF55506A);
                rect(g, x - 9, y - 2, 19, 3, 0xFF6A6584);
                rect(g, x - 1, y + 2, 3, 3, 0xFFFFE066);
                rect(g, x - 3, y + 4, 3, 2, 0xFFFFE066);
                rect(g, x, y + 6, 2, 3, 0xFFFFE066);
            }
        }
    }

    private void drawGirl(GuiGraphics g) {
        int x = (int) px;
        int by = H - 4;
        // parasol
        for (int r = 0; r < 8; r++) {
            int w = Math.min(HALF, 8 + r * 3);
            rect(g, x - w, UY + r, w * 2, 1, (r % 2 == 0) ? 0xFFF58FB8 : 0xFFFFB6D2);
        }
        rect(g, x - 1, UY + 8, 2, 14, 0xFF9A6A4A);
        // twin tails + hair
        rect(g, x - 11, by - 28, 4, 14, 0xFFF58FB8);
        rect(g, x + 7, by - 28, 4, 14, 0xFFF58FB8);
        rect(g, x - 8, by - 32, 16, 9, 0xFFF58FB8);
        // face
        rect(g, x - 6, by - 26, 12, 10, 0xFFFFE0CC);
        rect(g, x - 7, by - 27, 14, 3, 0xFFF58FB8);
        rect(g, x - 1, by - 27, 2, 4, 0xFFF58FB8);
        if (blink > 0) {
            rect(g, x - 5, by - 21, 3, 1, 0xFF3A2A3A);
            rect(g, x + 2, by - 21, 3, 1, 0xFF3A2A3A);
        } else {
            rect(g, x - 5, by - 22, 3, 4, 0xFF3A2A5A);
            rect(g, x + 2, by - 22, 3, 4, 0xFF3A2A5A);
            rect(g, x - 5, by - 22, 1, 1, 0xFFFFFFFF);
            rect(g, x + 2, by - 22, 1, 1, 0xFFFFFFFF);
        }
        rect(g, x - 6, by - 18, 2, 1, 0xFFFF9FA8);
        rect(g, x + 4, by - 18, 2, 1, 0xFFFF9FA8);
        // body: sailor uniform
        rect(g, x - 6, by - 16, 12, 9, 0xFF4A6FC8);
        rect(g, x - 6, by - 16, 12, 2, 0xFFFFFFFF);
        rect(g, x - 1, by - 14, 2, 2, 0xFFE0566A);
        rect(g, x - 5, by - 8, 10, 3, 0xFF3A5AA8);
        rect(g, x - 4, by - 5, 3, 4, 0xFFFFE0CC);
        rect(g, x + 1, by - 5, 3, 4, 0xFFFFE0CC);
        rect(g, x - 5, by - 1, 4, 1, 0xFF3A2A3A);
        rect(g, x + 1, by - 1, 4, 1, 0xFF3A2A3A);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public String hintKey() { return "cutemod.hint.sakura"; }
}
