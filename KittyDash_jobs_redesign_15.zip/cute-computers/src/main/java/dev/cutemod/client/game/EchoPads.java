package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Echo Pads: four glowing pads play a tune, repeat it. Every round adds one more note. One mistake ends the game. */
public class EchoPads extends MiniGame {
    private static final int PW = 84, PH = 50, GAP = 8, OX = (W - 2 * PW - GAP) / 2, OY = 6;
    private static final int[] COL = {0xFFF06AAE, 0xFF4A8FE0, 0xFF52B85A, 0xFFE0A93A};

    private final int[] seq = new int[120];
    private int len, showIdx, timer, inputIdx, lit, litTimer;
    private boolean showing;

    @Override
    public void reset() {
        score = 0; over = false; len = 0; litTimer = 0;
        addStep();
    }

    private void addStep() {
        seq[len++] = rnd.nextInt(4);
        showing = true; showIdx = 0; timer = 50; inputIdx = 0; lit = -1;
    }

    private static float pitch(int pad) { return 0.7F + pad * 0.25F; }

    private static int padAt(int x, int y) {
        for (int i = 0; i < 4; i++) {
            if (in(x, y, OX + (i % 2) * (PW + GAP), OY + (i / 2) * (PH + GAP), PW, PH)) return i;
        }
        return -1;
    }

    private void press(int pad) {
        if (showing || over || pad < 0 || len >= seq.length) return;
        lit = pad; litTimer = 12;
        pling(pitch(pad));
        if (pad == seq[inputIdx]) {
            if (++inputIdx == len) { score = len; if (len < seq.length - 1) addStep(); else over = true; }
        } else {
            over = true; beep();
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        press(padAt(x, y));
        return true;
    }

    @Override
    public boolean key(int keyCode) {
        if (keyCode >= 49 && keyCode <= 52) { press(keyCode - 49); return true; }
        return false;
    }

    @Override
    public void tick() {
        if (!showing) {
            if (litTimer > 0 && --litTimer == 0) lit = -1;
            return;
        }
        if (--timer > 0) return;
        if (lit >= 0) { lit = -1; timer = 10; }
        else if (showIdx < len) {
            lit = seq[showIdx++];
            pling(pitch(lit));
            timer = Math.max(16, 34 - len * 2);
        } else {
            showing = false;
        }
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF2A2048, 0xFF171030);
        for (int i = 0; i < 4; i++) {
            int x = OX + (i % 2) * (PW + GAP), y = OY + (i / 2) * (PH + GAP);
            int c = COL[i];
            boolean on = lit == i;
            int face = on ? 0xFF000000 | (((c & 0xFEFEFE) >> 1) + 0x7F7F7F) : 0xFF000000 | ((c & 0xFEFEFE) >> 1);
            if (on) rect(g, x - 2, y - 2, PW + 4, PH + 4, (c & 0x00FFFFFF) | 0x66000000);   // a glow
            rect(g, x, y, PW, PH, face);
            rect(g, x, y, PW, 3, on ? 0x88FFFFFF : 0x22FFFFFF);
            ctext(g, String.valueOf(i + 1), x + PW / 2, y + PH / 2 - 4, on ? 0xFF3A2A3A : 0x88FFFFFF);
        }
        String s = Component.translatable(showing ? "cutemod.echo.watch" : "cutemod.echo.go").getString();
        ctext(g, s, W / 2, H - 12, showing ? 0xFFFFD866 : 0xFFB6FFC8);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score", score); }

    @Override
    public String hintKey() { return "cutemod.hint.echo"; }
}
