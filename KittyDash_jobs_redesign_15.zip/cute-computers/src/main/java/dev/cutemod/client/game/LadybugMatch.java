package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Red computer: classic match-3. 20 moves. */
public class LadybugMatch extends MiniGame {
    private static final int C = 8, R = 7, CELL = 18, OX = (W - C * CELL) / 2, OY = (H - R * CELL) / 2;
    private static final int[] COLORS = {0xFFE04848, 0xFF4A8FE0, 0xFF52C45A, 0xFFF2C94C, 0xFFA66BE0};

    private final int[][] grid = new int[R][C];
    private int selR, selC, moves;

    @Override
    public void reset() {
        score = 0; over = false; moves = 20; selR = -1; selC = -1;
        fillBoard();
    }

    private void fillBoard() {
        do {
            for (int r = 0; r < R; r++) for (int c = 0; c < C; c++) grid[r][c] = rnd.nextInt(COLORS.length);
        } while (countMatches(markMatches()) > 0 || !anyMove());
    }

    private boolean[][] markMatches() {
        boolean[][] m = new boolean[R][C];
        for (int r = 0; r < R; r++) {
            for (int c = 0; c < C - 2; c++) {
                int v = grid[r][c];
                if (v >= 0 && v == grid[r][c + 1] && v == grid[r][c + 2]) { m[r][c] = true; m[r][c + 1] = true; m[r][c + 2] = true; }
            }
        }
        for (int c = 0; c < C; c++) {
            for (int r = 0; r < R - 2; r++) {
                int v = grid[r][c];
                if (v >= 0 && v == grid[r + 1][c] && v == grid[r + 2][c]) { m[r][c] = true; m[r + 1][c] = true; m[r + 2][c] = true; }
            }
        }
        return m;
    }

    private static int countMatches(boolean[][] m) {
        int n = 0;
        for (boolean[] row : m) for (boolean b : row) if (b) n++;
        return n;
    }

    private void swap(int r1, int c1, int r2, int c2) {
        int t = grid[r1][c1]; grid[r1][c1] = grid[r2][c2]; grid[r2][c2] = t;
    }

    private boolean anyMove() {
        for (int r = 0; r < R; r++) {
            for (int c = 0; c < C; c++) {
                if (c + 1 < C) { swap(r, c, r, c + 1); boolean ok = countMatches(markMatches()) > 0; swap(r, c, r, c + 1); if (ok) return true; }
                if (r + 1 < R) { swap(r, c, r + 1, c); boolean ok = countMatches(markMatches()) > 0; swap(r, c, r + 1, c); if (ok) return true; }
            }
        }
        return false;
    }

    /** Clears matches, drops gems, refills; returns the points gained. */
    private int resolve() {
        int total = 0, chain = 0;
        while (true) {
            boolean[][] m = markMatches();
            int n = countMatches(m);
            if (n == 0) break;
            chain++;
            total += n * 10 * chain;
            for (int r = 0; r < R; r++) for (int c = 0; c < C; c++) if (m[r][c]) grid[r][c] = -1;
            for (int c = 0; c < C; c++) {
                int write = R - 1;
                for (int r = R - 1; r >= 0; r--) if (grid[r][c] >= 0) grid[write--][c] = grid[r][c];
                for (int r = write; r >= 0; r--) grid[r][c] = rnd.nextInt(COLORS.length);
            }
        }
        return total;
    }

    @Override
    public boolean click(int x, int y, int button) {
        int c = (x - OX) / CELL, r = (y - OY) / CELL;
        if (x < OX || y < OY || c >= C || r >= R) { selR = -1; return true; }
        if (selR < 0) { selR = r; selC = c; return true; }
        if (selR == r && selC == c) { selR = -1; return true; }
        if (Math.abs(selR - r) + Math.abs(selC - c) != 1) { selR = r; selC = c; return true; }
        swap(selR, selC, r, c);
        if (countMatches(markMatches()) == 0) {
            swap(selR, selC, r, c); // not a valid move
            beep();
        } else {
            moves--;
            int gained = resolve();
            score += gained;
            pling(1.0F + Math.min(gained, 200) / 250F);
            if (moves <= 0) over = true;
            else if (!anyMove()) fillBoard();
        }
        selR = -1;
        return true;
    }

    @Override
    public void tick() {}

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF3F8F4A, 0xFF225C32);
        rect(g, OX - 2, OY - 2, C * CELL + 4, R * CELL + 4, 0xFF173F22);
        for (int r = 0; r < R; r++) {
            for (int c = 0; c < C; c++) {
                int x = OX + c * CELL, y = OY + r * CELL;
                rect(g, x, y, CELL, CELL, ((r + c) & 1) == 0 ? 0xFF2F7A3E : 0xFF2A7038);
                int v = grid[r][c];
                if (v >= 0) {
                    disc(g, x + CELL / 2, y + CELL / 2, 7, 0xFF1A1A1A);
                    disc(g, x + CELL / 2, y + CELL / 2, 6, COLORS[v]);
                    rect(g, x + 5, y + 5, 3, 2, 0x99FFFFFF);
                }
                if (r == selR && c == selC) {
                    rect(g, x, y, CELL, 1, 0xFFFFFFFF); rect(g, x, y + CELL - 1, CELL, 1, 0xFFFFFFFF);
                    rect(g, x, y, 1, CELL, 0xFFFFFFFF); rect(g, x + CELL - 1, y, 1, CELL, 0xFFFFFFFF);
                }
            }
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_moves", score, moves); }

    @Override
    public String hintKey() { return "cutemod.hint.match"; }
}
