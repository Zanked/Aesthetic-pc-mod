package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Cute Quiz: 5 questions a day about Minecraft and the cute world, 3 answers each. Every right answer pays 4 coins,
 * all five right pay 6 more. The questions of a day are the same all day (picked by the date); once the five are
 * answered, the quiz is over until tomorrow. The texts are in the language files (cutemod.quiz.q.N, .a.N.0..2);
 * ANSWER[N] is the number of the right one. Saved as "quiz" (day, how many answered, how many right).
 */
public class QuizApp extends KitApp {
    private static final int QUESTIONS = 15, PER_DAY = 5;
    private static final int[] ANSWER = {1, 0, 2, 1, 0, 2, 1, 0, 1, 2, 0, 1, 2, 0, 1};

    private List<Integer> today = new ArrayList<>();
    private int done, right, picked = -1, nextT;
    private boolean loaded;

    @Override protected int accent() { return 0xFF7ACB8A; }

    @Override protected String id() { return "quiz"; }

    @Override
    public void attach(Shell shell) { super.attach(shell); load(); }

    private void load() {
        loaded = true;
        List<Integer> all = new ArrayList<>();
        for (int i = 0; i < QUESTIONS; i++) all.add(i);
        Collections.shuffle(all, new Random(today() * 31L + 7));
        today = new ArrayList<>(all.subList(0, PER_DAY));
        done = 0;
        right = 0;
        try {
            String s = Store.read("quiz");
            if (s != null) {
                String[] p = s.split(",");
                if (Integer.parseInt(p[0]) == today()) { done = Math.min(PER_DAY, Integer.parseInt(p[1])); right = Integer.parseInt(p[2]); }
            }
        } catch (Exception ignored) { }
    }

    private void save() { Store.write("quiz", today() + "," + done + "," + right); }

    @Override
    public void tick() {
        super.tick();
        if (nextT > 0 && --nextT == 0) {
            picked = -1;
            if (done >= PER_DAY) finishDay();
        }
    }

    private void finishDay() {
        int pay = right * 4 + (right == PER_DAY ? 6 : 0);
        if (pay > 0) Progress.earn(pay);
        Season.add(10);
        say("cutemod.quiz.msg.paid", right, PER_DAY, pay);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        header(g, f);
        String score = t("cutemod.quiz.score", Math.min(done + 1, PER_DAY), PER_DAY);
        CuteFont.draw(g, f, score, W - 6 - f.width(score), 3, 0xFFFFFFFF, false);
        if (done >= PER_DAY && nextT == 0) {
            center(g, f, t("cutemod.quiz.over", right, PER_DAY), W / 2, 50, TEXT);
            center(g, f, t("cutemod.quiz.tomorrow"), W / 2, 66, MUTED);
            for (int i = 0; i < PER_DAY; i++) { star(g, 90 + i * 30, 100, i < right); }
            footer(g, f);
            return;
        }
        int q = today.get(Math.min(done, PER_DAY - 1));
        rect(g, 8, 20, W - 16, 30, 0xFFEAF6EC);
        wrapped(g, f, t("cutemod.quiz.q." + q), 14, 24, W - 28);
        for (int a = 0; a < 3; a++) {
            int y = 58 + a * 24;
            boolean hov = picked < 0 && in(mx, my, 8, y, W - 16, 20);
            int bg = 0xFFFFFFFF;
            if (picked >= 0) bg = a == ANSWER[q] ? 0xFFBFEFC4 : a == picked ? 0xFFF7B8B8 : 0xFFF1EAF8;
            else if (hov) bg = 0xFFFFF3B0;
            rect(g, 8, y, W - 16, 20, bg);
            rect(g, 8, y + 18, W - 16, 2, 0xFFB9A8C8);
            CuteFont.draw(g, f, (char) ('A' + a) + "  " + f.plainSubstrByWidth(t("cutemod.quiz.a." + q + "." + a), W - 50), 14, y + 6, TEXT, false);
        }
        footer(g, f);
    }

    private void wrapped(GuiGraphics g, Font f, String text, int x, int y, int w) {
        StringBuilder line = new StringBuilder();
        int yy = y;
        for (String word : text.split(" ")) {
            if (f.width(line + word) > w && line.length() > 0) { CuteFont.draw(g, f, line.toString(), x, yy, TEXT, false); yy += 11; line.setLength(0); }
            line.append(word).append(' ');
        }
        CuteFont.draw(g, f, line.toString(), x, yy, TEXT, false);
    }

    private static void star(GuiGraphics g, int cx, int cy, boolean on) {
        int c = on ? 0xFFF0B020 : 0xFFD9D0E4;
        rect(g, cx - 5, cy - 5, 10, 10, c); rect(g, cx - 8, cy - 2, 16, 4, c); rect(g, cx - 2, cy - 8, 4, 16, c);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (done >= PER_DAY || picked >= 0) return false;
        for (int a = 0; a < 3; a++) {
            if (!in(x, y, 8, 58 + a * 24, W - 16, 20)) continue;
            int q = today.get(done);
            picked = a;
            boolean ok = a == ANSWER[q];
            if (ok) right++;
            done++;
            save();
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), ok ? 2.0F : 0.7F, 0.5F);
            say(ok ? "cutemod.quiz.msg.right" : "cutemod.quiz.msg.wrong");
            nextT = 70;
            return true;
        }
        return false;
    }
}
