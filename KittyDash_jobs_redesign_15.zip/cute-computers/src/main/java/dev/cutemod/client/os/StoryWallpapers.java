package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Four more animated wallpapers (numbers 41-44): a fairy-tale castle with a dragon, a blocky voxel-style meadow,
 * a koi pond and a candy land. Same method as FunWallpapers (design space 160 x 100, scenery fills the whole width).
 */
final class StoryWallpapers {
    private static GuiGraphics gg;
    private static int bx, by, bw, bh;
    private static float s;
    private static int ox;
    private static int t;
    private static float lo, hi, vw;

    private StoryWallpapers() {}

    static void draw(GuiGraphics g, int x, int y, int w, int h, int idx) {
        gg = g; bx = x; by = y; bw = Math.max(1, w); bh = Math.max(1, h);
        s = bh / 100F;
        ox = bx + Math.round((bw - 160 * s) / 2F);
        vw = bw / s; lo = (bx - ox) / s; hi = lo + vw;
        t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        switch (idx) {
            case 41 -> fairyTale();
            case 42 -> blockWorld();
            case 43 -> koiPond();
            default -> candyLand();
        }
        gg = null;
    }

    // ---------- drawing helpers (design units) ----------
    private static int X(float v) { return ox + Math.round(v * s); }

    private static int Y(float v) { return by + Math.round(v * s); }

    /** A filled box in screen pixels, cut to the wallpaper box. */
    private static void px(int x0, int y0, int x1, int y1, int argb) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fill(x0, y0, x1, y1, argb);
    }

    /** A filled box in design units (at least one pixel). */
    private static void R(float x0, float y0, float x1, float y1, int argb) {
        int a = X(x0), b = Y(y0), c = Math.max(X(x1), a + 1), d = Math.max(Y(y1), b + 1);
        px(a, b, c, d, argb);
    }

    private static void D(float cx, float cy, float rad, int argb) {
        int r = Math.max(1, Math.round(rad * s)), pcx = X(cx), pcy = Y(cy);
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            px(pcx - dx, pcy + dy, pcx + dx + 1, pcy + dy + 1, argb);
        }
    }

    /** A triangle with its tip up, base width w, height h (design units). */
    private static void T(float cx, float top, float w, float h, int argb) {
        int rows = Math.max(1, Math.round(h * s)), pcx = X(cx), pw = Math.max(1, Math.round(w * s)), y0 = Y(top);
        for (int row = 0; row < rows; row++) {
            int ww = Math.max(1, pw * (row + 1) / rows);
            px(pcx - ww / 2, y0 + row, pcx - ww / 2 + ww, y0 + row + 1, argb);
        }
    }

    private static void sky(int top, int bottom) { gg.fillGradient(bx, by, bx + bw, by + bh, top, bottom); }

    private static int mix(int a, int b, float f) {
        f = Math.max(0F, Math.min(1F, f));
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
        return 0xFF000000 | (int) (ar + (br - ar) * f) << 16 | (int) (ag + (bg - ag) * f) << 8 | (int) (ab + (bb - ab) * f);
    }

    private static int alpha(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }

    private static float wave(float speed, float phase) { return (float) Math.sin(t * speed + phase); }

    private static void stars(int count, int seed) {
        for (int i = 0; i < count; i++) {
            float sx = lo + (i * 53 + seed * 17) % vw, sy = (i * 29 + seed * 7) % 70;
            boolean on = (t / 6 + i * 3) % 9 != 0;
            R(sx, sy, sx + 1.2F, sy + 1.2F, on ? 0xFFFFF6C8 : 0x66FFF6C8);
        }
    }

    // ---------- 41: the fairy tale ----------
    private static void fairyTale() {
        sky(0xFF1A1448, 0xFF6A3A8A);
        for (int i = 0; i < 40; i++) {
            float x = lo + (i * 53) % vw, y = (i * 29) % 50;
            R(x, y, x + 1.2F, y + 1.2F, (t / 6 + i * 3) % 8 == 0 ? 0x66FFFFFF : 0xFFFFF6D8);
        }
        D(lo + 30, 24, 12, alpha(0xFFF0B0, 40)); D(lo + 30, 24, 9, 0xFFFFF0C0);
        // far hills and the hill of the castle
        for (int i = 0; i < 80; i++) R(lo + i * vw / 80, 70 - (float) Math.sin(i * 0.2) * 5, lo + (i + 1) * vw / 80 + 0.5F, 100, 0xFF2A1E5A);
        float cx = lo + vw * 0.68F;
        for (int i = -40; i <= 40; i++) R(cx + i, 64 + Math.abs(i) * 0.3F, cx + i + 1, 100, 0xFF1E1448);
        // the castle
        int stone = 0xFF3A2E6A, roof = 0xFFB0507A;
        R(cx - 14, 40, cx + 14, 64, stone);
        float[] tx = {-18, -8, 8, 18};
        float[] th = {26, 38, 38, 26};
        for (int i = 0; i < 4; i++) {
            R(cx + tx[i] - 4, 64 - th[i], cx + tx[i] + 4, 64, stone);
            T(cx + tx[i], 64 - th[i] - 10, 11, 11, roof);
            R(cx + tx[i] + 0.5F, 64 - th[i] - 16, cx + tx[i] + 1.2F, 64 - th[i] - 10, 0xFFE8D8F8);
            float fl = wave(0.2F, i) * 1.2F;
            R(cx + tx[i] + 1.2F, 64 - th[i] - 16, cx + tx[i] + 5 + fl, 64 - th[i] - 13, 0xFFFF6AA8);    // a flag in the wind
        }
        R(cx - 3, 54, cx + 3, 64, 0xFF14102A); D(cx, 54, 3, 0xFF14102A);                                 // the gate
        for (int i = 0; i < 4; i++) if ((t / 40 + i) % 6 != 0) R(cx + tx[i] - 1, 64 - th[i] + 6, cx + tx[i] + 1, 64 - th[i] + 9, 0xFFFFD880);
        for (int i = 0; i < 3; i++) if ((t / 55 + i * 2) % 7 != 0) R(cx - 10 + i * 9, 46, cx - 8 + i * 9, 49, 0xFFFFD880);
        // the winding path and a magic sparkle trail
        for (int k = 0; k < 30; k++) { float f = k / 30F; R(cx - 4 + wave(0.0F, 0) + (float) Math.sin(f * 6) * 12 * (1 - f), 64 + f * 34, cx + 4 - f * 3 + (float) Math.sin(f * 6) * 12 * (1 - f), 65 + f * 34, 0xFF5A4A8A); }
        // the dragon: a body of round segments that wave, with flapping wings
        float dx = lo + (t * 0.55F) % (vw + 60) - 30, dy = 26 + wave(0.04F, 0) * 6F;
        for (int k = 9; k >= 0; k--) {
            float sx = dx - k * 3.6F, sy = dy + wave(0.18F, k * 0.6F) * 3F;
            D(sx, sy, 3.4F - k * 0.2F, k % 2 == 0 ? 0xFF4AB86A : 0xFF3A9A5A);
            if (k > 0 && k < 6) T(sx, sy - 5 - (6 - k) * 0.3F, 2.6F, 3, 0xFFFFC040);
        }
        D(dx + 3, dy - 1, 3.8F, 0xFF4AB86A); R(dx + 5, dy - 0.5F, dx + 9, dy + 2, 0xFF4AB86A); R(dx + 3.5F, dy - 3, dx + 5, dy - 1.5F, 0xFFFFFFFF);
        float flap = wave(0.35F, 0);
        for (int k = 0; k < 9; k++) {
            R(dx - 4 - k * 0.4F, dy - 3 - k * 1.1F * (0.6F + 0.4F * flap), dx - 1 - k * 0.4F, dy - 2 - k * 1.1F * (0.6F + 0.4F * flap), 0xFF8A5AD8);
            R(dx - 4 - k * 0.4F, dy - 3 - k * 1.1F * (0.6F + 0.4F * flap), dx - 3.4F - k * 0.4F, dy - 1.5F, 0xFF6A3AB8);
        }
        if (t % 70 < 14) for (int k = 0; k < 6; k++) D(dx + 10 + k * 2.2F, dy + 1 + wave(0.3F, k) * 1.2F, 1.6F - k * 0.15F, alpha(k % 2 == 0 ? 0xFFA030 : 0xFFE060, 230 - k * 30));   // a little puff of fire
        // fireflies
        for (int i = 0; i < 14; i++) {
            float x = lo + (i * 47) % vw + wave(0.02F, i) * 9F, y = 60 + (i * 13) % 34 + wave(0.03F, i * 2) * 5F;
            float g = 0.5F + 0.5F * wave(0.09F, i);
            R(x - 0.7F, y - 0.7F, x + 0.7F, y + 0.7F, alpha(0xFFF8A0, (int) (90 + 160 * g)));
        }
    }

    // ---------- 42: the block world ----------
    private static int hash(int a, int b) { int h = a * 374761393 + b * 668265263; h = (h ^ (h >>> 13)) * 1274126177; return (h ^ (h >>> 16)) & 255; }

    private static void block(float x, float y, int kind) {                       // 8 x 8 units
        int[] base = {0xFF6AB04A, 0xFF8A6038, 0xFF8A8A8A, 0xFF6A4A28};
        int col = base[kind];
        R(x, y, x + 8, y + 8, col);
        for (int i = 0; i < 6; i++) {
            int h = hash((int) (x * 3) + i, (int) y + kind);
            R(x + (h % 8), y + ((h / 8) % 8), x + (h % 8) + 2, y + ((h / 8) % 8) + 2, h % 2 == 0 ? mix(col, 0xFF000000, 0.14F) : mix(col, 0xFFFFFFFF, 0.1F));
        }
        if (kind == 0) { R(x, y, x + 8, y + 2.5F, 0xFF7ACB52); R(x, y + 2.5F, x + 8, y + 3.4F, 0xFF4A8A32); }
    }

    private static void blockWorld() {
        sky(0xFF7ACBFF, 0xFFCDEBFF);
        float sunX = lo + vw * 0.8F;
        R(sunX - 7, 10, sunX + 7, 24, 0xFFFFF0A0); R(sunX - 5, 12, sunX + 5, 22, 0xFFFFFFD0);
        for (int i = 0; i < 4; i++) {                                                  // square clouds drift
            float x = lo + (t * (0.1F + i * 0.04F) + i * 70) % (vw + 60) - 30, y = 10 + (i * 19) % 34;
            for (int k = 0; k < 4; k++) R(x + k * 5, y + (k % 2) * -3, x + k * 5 + 8, y + 5 + (k % 2) * -3, 0xE6FFFFFF);
        }
        // the ground: columns of blocks with a rolling height
        int cols = (int) (vw / 8) + 2;
        float[] top = new float[cols + 1];
        for (int c = 0; c <= cols; c++) top[c] = 62 + (float) Math.round(Math.sin(c * 0.45) * 1.6 + Math.sin(c * 0.17 + 1) * 2.2) * 8 / 2;
        for (int c = 0; c < cols; c++) {
            float x = lo + c * 8, h = (float) (Math.floor(top[c] / 8) * 8);
            for (float y = h; y < 100; y += 8) block(x, y, y == h ? 0 : y < h + 24 ? 1 : 2);
        }
        // trees of blocks
        for (int i = 0; i < 3; i++) {
            int c = 4 + i * (cols - 8) / 2;
            float x = lo + c * 8, h = (float) (Math.floor(top[c] / 8) * 8);
            for (int k = 1; k <= 3; k++) block(x, h - k * 8, 3);
            for (int dxl = -1; dxl <= 1; dxl++) for (int dyl = 0; dyl < 2; dyl++) { R(x + dxl * 8, h - 40 + dyl * 8, x + dxl * 8 + 8, h - 32 + dyl * 8, 0xFF3A8A32); R(x + dxl * 8 + 1, h - 39 + dyl * 8, x + dxl * 8 + 4, h - 36 + dyl * 8, 0xFF4AA03A); }
            R(x, h - 48, x + 8, h - 40, 0xFF3A8A32);
        }
        // an original blocky bunny that hops along the grass
        float cxp = lo + vw * 0.38F + wave(0.02F, 0) * 8F;
        float ty = (float) Math.floor(top[(int) ((cxp - lo) / 8)] / 8) * 8;
        float hop = Math.max(0F, wave(0.2F, 0)) * 7F;
        float by0 = ty - hop;
        R(cxp - 6, by0 - 9, cxp + 5, by0 - 2, 0xFFFFFFFF); R(cxp - 6, by0 - 3, cxp + 5, by0 - 2, 0xFFE0E0E8);          // body
        R(cxp + 2, by0 - 15, cxp + 8, by0 - 8, 0xFFFFFFFF);                                                             // head
        R(cxp + 2.5F, by0 - 23, cxp + 4.5F, by0 - 15, 0xFFFFFFFF); R(cxp + 5.5F, by0 - 23, cxp + 7.5F, by0 - 15, 0xFFFFFFFF);   // ears
        R(cxp + 3, by0 - 21, cxp + 4, by0 - 16, 0xFFFFB0C8); R(cxp + 6.5F, by0 - 21, cxp + 7, by0 - 16, 0xFFFFB0C8);
        R(cxp + 5.5F, by0 - 13, cxp + 7, by0 - 11.5F, 0xFF3A2A3A); R(cxp + 7.4F, by0 - 11, cxp + 8.6F, by0 - 10, 0xFFFF8AA8);
        R(cxp - 8, by0 - 7, cxp - 5, by0 - 4, 0xFFFFFFFF);                                                              // the tail
        R(cxp - 3, by0 - 2, cxp + 1, by0, 0xFFE0E0E8); R(cxp + 2, by0 - 2, cxp + 6, by0, 0xFFE0E0E8);
        // a torch with a flicker
        float tx2 = lo + vw * 0.14F, tty = (float) (Math.floor(top[2] / 8) * 8);
        R(tx2 - 1, tty - 12, tx2 + 1, tty, 0xFF7A4A28); R(tx2 - 1.5F, tty - 15, tx2 + 1.5F, tty - 12, (t / 3) % 2 == 0 ? 0xFFFFC040 : 0xFFFF8A2A);
        for (int i = 0; i < 4; i++) R(tx2 - 0.6F + wave(0.3F, i) * 1.5F, tty - 17 - i * 2 - (t % 12) * 0.3F, tx2 + 0.6F + wave(0.3F, i) * 1.5F, tty - 16 - i * 2 - (t % 12) * 0.3F, alpha(0xFFC040, 200 - i * 45));
    }

    // ---------- 43: the koi pond ----------
    private static void koiFish(float x, float y, float dir, int body, int spot) {
        float ang = dir;
        for (int k = 0; k < 8; k++) {
            float sx = x - (float) Math.cos(ang) * k * 2.4F + wave(0.2F, k * 0.5F) * 0.8F * k / 4, sy = y - (float) Math.sin(ang) * k * 2.4F + wave(0.2F, k * 0.5F) * 1.2F * k / 4;
            D(sx, sy, 3.2F - k * 0.28F, k == 2 || k == 3 ? spot : body);
        }
        D(x, y, 3.4F, body);
        float tx = x - (float) Math.cos(ang) * 20F, ty = y - (float) Math.sin(ang) * 20F + wave(0.25F, 0) * 1.5F;
        D(tx, ty, 2.4F, alpha(body, 200)); D(tx - (float) Math.cos(ang) * 2.5F, ty - (float) Math.sin(ang) * 2.5F, 1.6F, alpha(body, 150));
        D(x + (float) Math.cos(ang) * 1.5F - (float) Math.sin(ang) * 1.5F, y + (float) Math.sin(ang) * 1.5F + (float) Math.cos(ang) * 1.5F, 0.7F, 0xFF1E1A30);
    }

    private static void koiPond() {
        sky(0xFF1E6A7A, 0xFF0E3A4A);
        for (int i = 0; i < 18; i++) {                                                  // light patterns on the water
            float x = lo + (i * 43) % vw + wave(0.02F, i) * 6F, y = (i * 29) % 100;
            R(x, y, x + 12, y + 0.8F, alpha(0xFFFFFF, 18));
        }
        int[][] fishes = {{0xFFFF8A2A, 0xFFFFFFFF}, {0xFFFFFFFF, 0xFFFF4A3A}, {0xFFFFC040, 0xFFFF6A2A}, {0xFF2A2A30, 0xFFFFFFFF}};
        for (int i = 0; i < 4; i++) {
            float ph = t * (0.012F + i * 0.004F) + i * 1.7F;
            float x = lo + vw / 2 + (float) Math.cos(ph) * vw * 0.36F, y = 50 + (float) Math.sin(ph * 1.3F) * 28F;
            float dir = (float) Math.atan2(Math.cos(ph * 1.3F) * 28F * 1.3F, -Math.sin(ph) * vw * 0.36F);
            koiFish(x, y, dir, fishes[i][0], fishes[i][1]);
        }
        for (int i = 0; i < 5; i++) {                                                   // lily pads and lotus flowers
            float x = lo + 10 + (i * 71) % (vw - 20), y = 14 + (i * 37) % 76 + wave(0.04F, i) * 1.2F;
            D(x, y, 7, 0xFF3AA85A); D(x, y, 5.5F, 0xFF4AC06A); R(x, y - 7, x + 7, y, alpha(0xFF0E3A4A, 255));
            D(x, y, 5.5F, 0xFF4AC06A); R(x, y - 6, x + 7, y - 0.4F, 0xFF1E6A7A);
            if (i % 2 == 0) { for (int p = -2; p <= 2; p++) T(x - 1 + p * 1.6F, y - 7 - (2 - Math.abs(p)) * 0.7F, 3, 5, p == 0 ? 0xFFFFC8E0 : 0xFFFF9AC0); D(x, y - 3, 1.2F, 0xFFFFE066); }
        }
        for (int i = 0; i < 5; i++) {                                                   // ripples
            float k = (t * 0.35F + i * 16) % 28;
            float x = lo + (i * 59 + 20) % vw, y = 20 + (i * 41) % 60;
            for (int a = 0; a < 360; a += 12) { double r = Math.toRadians(a); R(x + (float) Math.cos(r) * k * 1.3F, y + (float) Math.sin(r) * k * 0.6F, x + (float) Math.cos(r) * k * 1.3F + 1F, y + (float) Math.sin(r) * k * 0.6F + 0.8F, alpha(0xFFFFFF, (int) Math.max(0, 120 - k * 4))); }
        }
        for (int i = 0; i < 12; i++) {                                                  // petals on the water
            float x = lo + (i * 53 + t * 0.15F) % vw, y = 6 + (i * 31 + t * 0.1F * (1 + i % 3)) % 92;
            R(x, y, x + 2.2F, y + 1.4F, i % 2 == 0 ? 0xFFFFC0D8 : 0xFFFFFFFF);
        }
        R(lo, 0, lo + 7, 100, 0xFF3A3A44); D(lo + 5, 30, 8, 0xFF4A4A56); D(lo + 4, 76, 10, 0xFF3A3A46);    // stones at the shore
        R(hi - 6, 0, hi, 100, 0xFF3A3A44); D(hi - 4, 52, 9, 0xFF4A4A56);
    }

    // ---------- 44: the candy land ----------
    private static void candyLand() {
        sky(0xFFFFC8E8, 0xFFD8F4FF);
        for (int i = 0; i < 5; i++) {                                                   // cotton candy clouds
            float x = lo + (t * (0.08F + (i % 3) * 0.04F) + i * 50) % (vw + 60) - 30, y = 10 + (i * 17) % 32;
            int c = i % 2 == 0 ? 0xFFFFE8F4 : 0xFFE8F4FF;
            D(x, y, 6, c); D(x - 6, y + 2, 4.5F, c); D(x + 6, y + 2, 4.5F, c); R(x - 9, y + 2, x + 9, y + 6, c);
        }
        for (int layer = 0; layer < 2; layer++) {                                       // hills with stripes
            int c1 = layer == 0 ? 0xFFC8F0D0 : 0xFFA0E0B8, c2 = layer == 0 ? 0xFFFFFFFF : 0xFFE8FFF0;
            for (int i = 0; i < 100; i++) {
                float x = lo + i * vw / 100, y = 66 + layer * 10 + (float) Math.sin(i * 0.11 + layer * 2) * 6;
                R(x, y, x + vw / 100 + 0.5F, 100, c1);
                R(x, y, x + vw / 100 + 0.5F, y + 1.6F, c2);
            }
        }
        R(lo, 90, hi, 100, 0xFFFFD0E8);
        for (int i = 0; i < 9; i++) R(lo + i * vw / 9, 90, lo + i * vw / 9 + vw / 18, 100, 0xFFFFB0D8);
        // lollipops that sway
        for (int i = 0; i < 6; i++) {
            float x = lo + 10 + i * (vw - 20) / 5, sw = wave(0.04F, i) * 1.5F;
            for (int k = 0; k < 22; k++) R(x + sw * k / 22, 90 - k, x + 1.2F + sw * k / 22, 91 - k, 0xFFFFFFFF);
            float cx = x + sw, cy = 66;
            int[] cc = {0xFFFF6A9A, 0xFF6AB8FF, 0xFFFFD84A, 0xFF9A6AE8, 0xFF6AE0A0, 0xFFFF9A4A};
            D(cx, cy, 7, cc[i % 6]); D(cx, cy, 4.8F, 0xFFFFFFFF); D(cx, cy, 3.2F, cc[i % 6]); D(cx, cy, 1.4F, 0xFFFFFFFF);
        }
        // gumdrops and a candy cane
        for (int i = 0; i < 5; i++) {
            float x = lo + 22 + i * (vw - 30) / 4, y = 84 + (i % 2) * 3;
            int c = new int[]{0xFFFF7AA8, 0xFF7AD8FF, 0xFFFFE066, 0xFFB890FF, 0xFF8AF0B0}[i];
            D(x, y, 5, c); R(x - 5, y, x + 5, y + 4, c); R(x - 3, y - 3, x - 1, y - 1, alpha(0xFFFFFF, 160));
        }
        float cane = lo + vw * 0.9F;
        for (int k = 0; k < 18; k++) R(cane, 88 - k, cane + 2.4F, 89 - k, k % 4 < 2 ? 0xFFFF4A6A : 0xFFFFFFFF);
        for (int k = 0; k < 6; k++) R(cane - k * 0.9F, 70 - k * 0.5F, cane + 2.4F - k * 0.9F, 71.4F - k * 0.5F, k % 2 == 0 ? 0xFFFF4A6A : 0xFFFFFFFF);
        // sprinkles falling and sparkles
        for (int i = 0; i < 30; i++) {
            float fall = (t * (0.4F + (i % 4) * 0.12F) + i * 29) % 110, x = lo + (i * 41) % vw + wave(0.04F, i) * 3F;
            int c = new int[]{0xFFFF6A9A, 0xFF6AB8FF, 0xFFFFD84A, 0xFF9A6AE8, 0xFF6AE0A0}[i % 5];
            R(x, fall - 8, x + 2.4F, fall - 7, c);
        }
        for (int i = 0; i < 10; i++) {
            float x = lo + (i * 61) % vw, y = (i * 23) % 60;
            if ((t / 7 + i) % 4 < 2) { R(x - 1.5F, y, x + 1.5F, y + 0.8F, 0xFFFFFFFF); R(x - 0.4F, y - 1.4F, x + 0.4F, y + 2.2F, 0xFFFFFFFF); }
        }
    }
}
