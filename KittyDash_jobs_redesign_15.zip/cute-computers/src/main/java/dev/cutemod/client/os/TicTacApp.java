package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.util.Random;

/**
 * Tic-Tac-Toe with your pet. You are the hearts, the pet plays the stars. Three levels: easy (random), normal
 * (wins and blocks when it can) and hard (never loses). A win pays 2 / 4 / 6 coins, at most 30 coins a day.
 */
public class TicTacApp extends KitApp {
    private static final int BX = 100, BY = 24, CELL = 30;
    private static final int[][] LINES = {{0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, {0, 4, 8}, {2, 4, 6}};
    private static final int CAP = 30;

    private final int[] b = new int[9];            // 0 empty, 1 you, 2 the pet
    private final Random rnd = new Random();
    private int level = 1, wins, losses, draws;
    private int over;                              // 0 playing, 1 you won, 2 pet won, 3 draw
    private int petWait;                           // ticks until the pet moves
    private int[] winLine;

    @Override protected int accent() { return 0xFF6FB8E8; }

    @Override protected String id() { return "tictac"; }

    private void reset() {
        java.util.Arrays.fill(b, 0);
        over = 0;
        winLine = null;
        petWait = rnd.nextBoolean() ? 25 : 0;      // sometimes the pet starts
    }

    @Override
    public void attach(Shell shell) { super.attach(shell); reset(); }

    private int winner() {
        for (int[] l : LINES) if (b[l[0]] != 0 && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) { winLine = l; return b[l[0]]; }
        for (int v : b) if (v == 0) return 0;
        return 3;
    }

    private void finish() {
        int w = winner();
        if (w == 0) return;
        over = w;
        if (w == 1) {
            wins++;
            int pay = Math.min(level == 0 ? 2 : level == 1 ? 4 : 6, CAP - paidToday("ttt"));
            if (pay > 0) { Progress.earn(pay); addPaid("ttt", pay); }
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.6F);
            say(pay > 0 ? "cutemod.ttt.msg.win" : "cutemod.ttt.msg.wincap", pay);
        } else if (w == 2) { losses++; say("cutemod.ttt.msg.lose"); }
        else { draws++; say("cutemod.ttt.msg.draw"); }
    }

    private int pick() {
        if (level == 0) return randomFree();
        int m = finishing(2); if (m >= 0) return m;
        m = finishing(1); if (m >= 0) return m;
        if (level == 2) return best();
        return b[4] == 0 && rnd.nextInt(3) > 0 ? 4 : randomFree();
    }

    private int finishing(int who) {
        for (int[] l : LINES) {
            int n = 0, free = -1;
            for (int c : l) { if (b[c] == who) n++; else if (b[c] == 0) free = c; }
            if (n == 2 && free >= 0) return free;
        }
        return -1;
    }

    private int randomFree() {
        int n = 0;
        for (int v : b) if (v == 0) n++;
        int k = rnd.nextInt(Math.max(1, n));
        for (int i = 0; i < 9; i++) if (b[i] == 0 && k-- == 0) return i;
        return -1;
    }

    /** Perfect play (minimax): the best cell for the pet. */
    private int best() {
        int bestCell = -1, bestScore = -2;
        for (int i = 0; i < 9; i++) {
            if (b[i] != 0) continue;
            b[i] = 2;
            int sc = -search(1);
            b[i] = 0;
            if (sc > bestScore || (sc == bestScore && rnd.nextInt(3) == 0)) { bestScore = sc; bestCell = i; }
        }
        return bestCell;
    }

    /** Score for the player to move (who): 1 win, 0 draw, -1 loss. */
    private int search(int who) {
        int w = lineWinner();
        if (w != 0) return w == who ? 1 : -1;
        boolean any = false;
        int best = -2;
        for (int i = 0; i < 9; i++) {
            if (b[i] != 0) continue;
            any = true;
            b[i] = who;
            best = Math.max(best, -search(3 - who));
            b[i] = 0;
        }
        return any ? best : 0;
    }

    private int lineWinner() {
        for (int[] l : LINES) if (b[l[0]] != 0 && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) return b[l[0]];
        return 0;
    }

    @Override
    public void tick() {
        super.tick();
        if (over == 0 && petWait > 0 && --petWait == 0) {
            int c = pick();
            if (c >= 0) { b[c] = 2; Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 1.2F, 0.4F); }
            finish();
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        header(g, f);
        rect(g, BX - 4, BY - 4, CELL * 3 + 8, CELL * 3 + 8, 0xFFE4F1FB);
        for (int i = 0; i < 9; i++) {
            int x = BX + i % 3 * CELL, y = BY + i / 3 * CELL;
            boolean hov = over == 0 && petWait == 0 && b[i] == 0 && in(mx, my, x, y, CELL - 2, CELL - 2);
            rect(g, x, y, CELL - 2, CELL - 2, hov ? 0xFFFFFFFF : 0xFFF6FAFE);
            if (b[i] == 1) heart(g, x + (CELL - 2) / 2, y + (CELL - 2) / 2);
            if (b[i] == 2) star(g, x + (CELL - 2) / 2, y + (CELL - 2) / 2);
        }
        if (winLine != null) for (int c : winLine) rect(g, BX + c % 3 * CELL, BY + c / 3 * CELL, CELL - 2, 3, 0xFFFFD84A);
        // left: level and score
        CuteFont.draw(g, f, t("cutemod.ttt.level"), 8, 22, MUTED, false);
        for (int l = 0; l < 3; l++) btn(g, f, mx, my, 8, 34 + l * 19, 80, t("cutemod.ttt.lv." + l), l == level ? 1 : 0);
        CuteFont.draw(g, f, t("cutemod.ttt.score", wins, losses, draws), 8, 96, TEXT, false);
        CuteFont.draw(g, f, t("cutemod.ttt.today", paidToday("ttt"), CAP), 8, 108, MUTED, false);
        // right: you and the pet
        CuteFont.draw(g, f, t("cutemod.ttt.you"), 200, 30, 0xFFE0508A, false);
        heart(g, 222, 52);
        CuteFont.draw(g, f, t("cutemod.ttt.pet"), 200, 70, 0xFFE0A020, false);
        star(g, 222, 92);
        String st = over == 0 ? (petWait > 0 ? t("cutemod.ttt.thinks") : t("cutemod.ttt.yourmove")) : t("cutemod.ttt.over." + over);
        center(g, f, st, BX + CELL * 3 / 2, BY + CELL * 3 + 6, TEXT);
        btn(g, f, mx, my, 100, 142, 90, t("cutemod.ttt.again"), over != 0 ? 1 : 0);
        footer(g, f);
    }

    static void heart(GuiGraphics g, int cx, int cy) {
        rect(g, cx - 9, cy - 8, 8, 8, 0xFFE0508A); rect(g, cx + 1, cy - 8, 8, 8, 0xFFE0508A);
        rect(g, cx - 10, cy - 5, 20, 6, 0xFFE0508A);
        for (int d = 0; d < 9; d++) rect(g, cx - 9 + d, cy + 1 + d, 18 - d * 2, 1, 0xFFE0508A);
        rect(g, cx - 6, cy - 6, 3, 2, 0xFFFFA0C0);
    }

    static void star(GuiGraphics g, int cx, int cy) {
        for (int d = -10; d <= 10; d++) {
            int w = (int) Math.round(3.5 * (1 - Math.abs(d) / 11.0));
            rect(g, cx - 1 - w, cy + d, 2 + w * 2, 1, 0xFFF0B020);
            rect(g, cx + d, cy - 1 - w, 1, 2 + w * 2, 0xFFF0B020);
        }
        rect(g, cx - 5, cy - 5, 10, 10, 0xFFF0B020);
        rect(g, cx - 2, cy - 3, 3, 2, 0xFFFFE890);
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int l = 0; l < 3; l++) if (in(x, y, 8, 34 + l * 19, 80, 16)) { level = l; reset(); return true; }
        if (in(x, y, 100, 142, 90, 16)) { reset(); return true; }
        if (over == 0 && petWait == 0) {
            for (int i = 0; i < 9; i++) {
                if (b[i] == 0 && in(x, y, BX + i % 3 * CELL, BY + i / 3 * CELL, CELL - 2, CELL - 2)) {
                    b[i] = 1;
                    Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.5F, 0.4F);
                    finish();
                    if (over == 0) petWait = 22;
                    return true;
                }
            }
        }
        return false;
    }
}
