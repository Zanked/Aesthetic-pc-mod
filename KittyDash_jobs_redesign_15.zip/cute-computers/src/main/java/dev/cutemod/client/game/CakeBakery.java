package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Cake Bakery (in the spirit of the old Windows cake shop games). Customers walk up and order a cake: a
 * flavor and a topping. Click a bowl to put batter into an oven, take the cake out when it is ready (before it
 * burns!), put it on a plate, pick a topping and click the cake, then click the cake and the customer.
 * Happy customers tip more the faster you are, quick serves in a row give a bonus. A customer who waits too
 * long leaves angry and takes a heart; with no hearts left the bakery closes. A day is 90 seconds.
 */
public class CakeBakery extends MiniGame {
    private static final int DAY = 5400;                 // 90 seconds
    private static final int BAKE = 180, BURN = 780;     // ticks until the cake is ready / burnt
    private static final int[] SLOT_X = {38, 110, 182};  // centers of the three customer places
    private static final int[] FLAV = {0xFFF3E3B0, 0xFF7A4A2A, 0xFFF58FB8};
    private static final int OV_Y = 58, OV_W = 44, OV_H = 30;
    private static final int[] OV_X = {6, 54};
    private static final int PL_Y = 62, PL_W = 30;
    private static final int[] PL_X = {112, 146, 180};
    private static final int TB_Y = 98, TB_H = 36;       // bottom row of buttons
    private static final int TRASH_X = 108, TOP_X = 140;
    private static final int[] SKIN = {0xFFFFE0CC, 0xFFF3C9A8, 0xFFD9A57E, 0xFFFFE9D6};
    private static final int[] HAIR = {0xFF3A2A3A, 0xFFB8651B, 0xFFF3D46A, 0xFFF58FB8};
    private static final int[] SHIRT = {0xFF4A6FC8, 0xFF5BBF6A, 0xFFE0566A, 0xFF8A6AC6};

    private static final class Cust {
        boolean present;
        int flavor, topping, pat, maxPat, look;
    }

    private final Cust[] cust = {new Cust(), new Cust(), new Cust()};
    private final int[] ovState = new int[2], ovFlavor = new int[2], ovT = new int[2]; // 0 empty, 1 baking, 2 burnt
    private final int[] plFlavor = {-1, -1, -1}, plTop = {-1, -1, -1};
    private final List<double[]> pops = new ArrayList<>(); // x, y, life, amount
    private int t, hearts, spawnT, tool, selPlate, streak, msgT, hover;
    private String msg = "";

    @Override
    public void reset() {
        score = 0;
        over = false;
        t = 0;
        hearts = 5;
        spawnT = 90;
        tool = -1;
        selPlate = -1;
        streak = 0;
        msgT = 0;
        msg = "";
        pops.clear();
        for (Cust c : cust) c.present = false;
        for (int i = 0; i < 2; i++) { ovState[i] = 0; ovT[i] = 0; ovFlavor[i] = 0; }
        for (int i = 0; i < 3; i++) { plFlavor[i] = -1; plTop[i] = -1; }
    }

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private static int mix(int argb, int target, float f) {
        int r = (int) (((argb >> 16) & 255) * (1 - f) + ((target >> 16) & 255) * f);
        int gr = (int) (((argb >> 8) & 255) * (1 - f) + ((target >> 8) & 255) * f);
        int b = (int) ((argb & 255) * (1 - f) + (target & 255) * f);
        return 0xFF000000 | r << 16 | gr << 8 | b;
    }

    private void say(String key) { msg = tr(key); msgT = 90; }

    // ---------- logic ----------
    @Override
    public void tick() {
        if (over) return;
        t++;
        if (msgT > 0) msgT--;
        for (int i = 0; i < 2; i++) {
            if (ovState[i] != 1) continue;
            ovT[i]++;
            if (ovT[i] == BAKE) pling(1.8F);
            if (ovT[i] >= BURN) { ovState[i] = 2; beep(); }
        }
        if (--spawnT <= 0) {
            List<Integer> free = new ArrayList<>();
            for (int s = 0; s < 3; s++) if (!cust[s].present) free.add(s);
            if (!free.isEmpty()) {
                Cust c = cust[free.get(rnd.nextInt(free.size()))];
                c.present = true;
                c.flavor = rnd.nextInt(3);
                c.topping = rnd.nextInt(3);
                c.look = rnd.nextInt(4);
                c.maxPat = Math.max(1300, 1800 - t / 20);
                c.pat = c.maxPat;
            }
            spawnT = Math.max(300, 520 - t / 30);
        }
        for (Cust c : cust) {
            if (c.present && --c.pat <= 0) {
                c.present = false;
                hearts--;
                streak = 0;
                say("cutemod.cakes.angry");
                beep();
                if (hearts <= 0) over = true;
            }
        }
        for (int i = pops.size() - 1; i >= 0; i--) {
            double[] p = pops.get(i);
            p[1] -= 0.4;
            if (--p[2] <= 0) pops.remove(i);
        }
        if (t >= DAY) over = true;
    }

    private void bake(int f) {
        for (int i = 0; i < 2; i++) {
            if (ovState[i] == 0) {
                ovState[i] = 1;
                ovFlavor[i] = f;
                ovT[i] = 0;
                pling(0.9F + f * 0.2F);
                return;
            }
        }
        say("cutemod.cakes.ovens_full");
    }

    private void takeOven(int i) {
        if (ovState[i] == 2) { ovState[i] = 0; say("cutemod.cakes.burnt"); beep(); return; }
        if (ovState[i] != 1 || ovT[i] < BAKE) return;
        for (int p = 0; p < 3; p++) {
            if (plFlavor[p] == -1) {
                plFlavor[p] = ovFlavor[i];
                plTop[p] = -1;
                ovState[i] = 0;
                pling(1.4F);
                return;
            }
        }
        say("cutemod.cakes.no_plate");
    }

    private void clickPlate(int p) {
        if (plFlavor[p] == -1) { selPlate = -1; return; }
        if (tool >= 0) {
            if (plTop[p] == -1) {
                plTop[p] = tool;
                tool = -1;
                selPlate = p; // ready to serve: just click the customer
                pling(1.2F + plTop[p] * 0.2F);
            } else {
                say("cutemod.cakes.decorated");
            }
            return;
        }
        selPlate = selPlate == p ? -1 : p;
    }

    private void serve(int s) {
        if (selPlate < 0) { say("cutemod.cakes.pick_cake"); return; }
        int p = selPlate;
        if (plTop[p] == -1) { say("cutemod.cakes.not_decorated"); return; }
        Cust c = cust[s];
        if (c.flavor == plFlavor[p] && c.topping == plTop[p]) {
            int tip = Math.round(5f * c.pat / c.maxPat);
            streak++;
            int pay = 10 + tip + Math.min(5, streak - 1);
            score += pay;
            pops.add(new double[]{SLOT_X[s], 30, 50, pay});
            c.present = false;
            pling(1.2F + Math.min(streak, 10) * 0.05F);
        } else {
            c.pat = Math.max(1, c.pat - c.maxPat * 15 / 100);
            streak = 0;
            say("cutemod.cakes.wrong");
            beep();
        }
        plFlavor[p] = -1;
        plTop[p] = -1;
        selPlate = -1;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        for (int s = 0; s < 3; s++) {
            if (cust[s].present && in(x, y, SLOT_X[s] - 34, 0, 68, 50)) { serve(s); return true; }
        }
        for (int i = 0; i < 2; i++) {
            if (in(x, y, OV_X[i], OV_Y, OV_W, OV_H)) { takeOven(i); return true; }
        }
        for (int p = 0; p < 3; p++) {
            if (in(x, y, PL_X[p], PL_Y - 8, PL_W, 30)) { clickPlate(p); return true; }
        }
        for (int f = 0; f < 3; f++) {
            if (in(x, y, 6 + f * 34, TB_Y, 30, TB_H)) { bake(f); return true; }
        }
        if (in(x, y, TRASH_X, TB_Y, 24, TB_H)) {
            if (selPlate >= 0) { plFlavor[selPlate] = -1; plTop[selPlate] = -1; selPlate = -1; beep(); }
            tool = -1;
            return true;
        }
        for (int k = 0; k < 3; k++) {
            if (in(x, y, TOP_X + k * 26, TB_Y, 24, TB_H)) { tool = tool == k ? -1 : k; return true; }
        }
        return false;
    }

    @Override
    public boolean key(int keyCode) {
        if (over) return false;
        if (keyCode >= 49 && keyCode <= 51) { bake(keyCode - 49); return true; }            // 1 2 3: bake
        if (keyCode == 81) { tool = tool == 0 ? -1 : 0; return true; }                       // Q W E: toppings
        if (keyCode == 87) { tool = tool == 1 ? -1 : 1; return true; }
        if (keyCode == 69) { tool = tool == 2 ? -1 : 2; return true; }
        return false;
    }

    // ---------- drawing ----------
    /** A small cake. by = the bottom of it. Not frosted = a plain sponge; frosted = cream and a topping. */
    private static void drawCake(GuiGraphics g, int cx, int by, int flavor, int topping, boolean frosted) {
        int c = FLAV[flavor];
        rect(g, cx - 9, by - 8, 18, 8, c);
        rect(g, cx - 9, by - 2, 18, 2, mix(c, 0x000000, 0.2F));
        if (!frosted) { rect(g, cx - 9, by - 9, 18, 2, mix(c, 0xFFFFFF, 0.3F)); return; }
        rect(g, cx - 10, by - 11, 20, 4, 0xFFFFFFFF);
        rect(g, cx - 8, by - 8, 2, 3, 0xFFFFFFFF);
        rect(g, cx + 3, by - 8, 2, 4, 0xFFFFFFFF);
        drawTopping(g, cx, by - 12, topping);
    }

    private static void drawTopping(GuiGraphics g, int cx, int y, int k) {
        switch (k) {
            case 0 -> { // cherry
                disc(g, cx, y - 2, 3, 0xFFE5484D);
                rect(g, cx, y - 7, 1, 3, 0xFF2A7A3A);
                rect(g, cx - 1, y - 3, 1, 1, 0xFFFFFFFF);
            }
            case 1 -> { // sprinkles
                rect(g, cx - 7, y, 3, 1, 0xFFE5484D);
                rect(g, cx - 3, y - 1, 3, 1, 0xFF2F7FD6);
                rect(g, cx + 1, y, 3, 1, 0xFFF3D46A);
                rect(g, cx + 5, y - 1, 3, 1, 0xFF5BBF6A);
            }
            default -> { // candle
                rect(g, cx - 1, y - 7, 2, 7, 0xFFF3E6FF);
                rect(g, cx - 1, y - 5, 2, 1, 0xFFE5484D);
                rect(g, cx - 1, y - 11, 2, 3, 0xFFFFA020);
                rect(g, cx, y - 12, 1, 1, 0xFFFFE680);
            }
        }
    }

    @Override
    public void render(GuiGraphics g) {
        // the shop: pastel wall, wooden counter, kitchen, button panel
        g.fillGradient(0, 0, W, 48, 0xFFFFE3EE, 0xFFFFC9DF);
        for (int x = 4; x < W; x += 22) rect(g, x, 6, 1, 38, 0x22FFFFFF);
        rect(g, 0, 48, W, 8, 0xFFB98F5E);
        rect(g, 0, 48, W, 2, 0xFFD9B98A);
        rect(g, 0, 56, W, 42, 0xFFFFF3DC);
        rect(g, 0, 92, W, 1, 0xFFE8D3B0);
        rect(g, 0, 96, W, H - 96, 0xFF5A3A28);
        rect(g, 0, 96, W, 2, 0xFF7A5A40);
        rect(g, 0, 50, Math.round(W * Math.max(0, DAY - t) / (float) DAY), 3, 0xFFFFE680); // the day runs out

        for (int s = 0; s < 3; s++) if (cust[s].present) drawCustomer(g, s);
        for (int i = 0; i < 2; i++) drawOven(g, i);
        for (int p = 0; p < 3; p++) drawPlate(g, p);
        drawButtons(g);

        for (double[] p : pops) {
            ctext(g, "+" + (int) p[3], (int) p[0], (int) p[1], (int) p[2] < 12 ? 0xAAFFE680 : 0xFFFFE680);
        }
        if (msgT > 0) ctext(g, msg, W / 2, 88, 0xFFE0566A);
        else if (hover != 0) ctext(g, hoverText(), W / 2, 88, 0xFF7A5A40);
        if (streak >= 2) ctext(g, "x" + streak, W - 14, 58, 0xFFE0566A);
    }

    private void drawCustomer(GuiGraphics g, int s) {
        Cust c = cust[s];
        int cx = SLOT_X[s];
        // the order in a speech bubble
        rect(g, cx - 27, 0, 54, 24, 0xFF3A2A3A);
        rect(g, cx - 26, 0, 52, 23, 0xFFFFFFFF);
        rect(g, cx - 1, 23, 2, 3, 0xFF3A2A3A);
        drawCake(g, cx, 21, c.flavor, c.topping, true);
        // patience
        float f = Math.max(0f, c.pat / (float) c.maxPat);
        rect(g, cx - 20, 27, 40, 3, 0xFF3A2A3A);
        rect(g, cx - 20, 27, Math.round(40 * f), 3, f > 0.5f ? 0xFF5BD97A : f > 0.25f ? 0xFFF5C518 : 0xFFE5484D);
        // the customer behind the counter
        rect(g, cx - 7, 43, 14, 6, SHIRT[c.look]);
        disc(g, cx, 38, 6, SKIN[c.look]);
        rect(g, cx - 6, 32, 12, 4, HAIR[c.look]);
        rect(g, cx - 2, 37, 1, 2, 0xFF3A2A3A);
        rect(g, cx + 2, 37, 1, 2, 0xFF3A2A3A);
        if (f < 0.3f) { // angry
            rect(g, cx - 3, 35, 3, 1, 0xFF3A2A3A);
            rect(g, cx + 1, 35, 3, 1, 0xFF3A2A3A);
            rect(g, cx - 2, 42, 5, 1, 0xFF3A2A3A);
        } else {
            rect(g, cx - 2, 41, 5, 1, 0xFF3A2A3A);
        }
    }

    private void drawOven(GuiGraphics g, int i) {
        int x = OV_X[i];
        rect(g, x, OV_Y, OV_W, OV_H, 0xFF6A6A7A);
        rect(g, x, OV_Y, OV_W, 2, 0xFF8A8A9A);
        int st = ovState[i];
        boolean ready = st == 1 && ovT[i] >= BAKE;
        boolean late = st == 1 && ovT[i] >= BURN - 100;
        rect(g, x + 4, OV_Y + 8, OV_W - 8, OV_H - 12, ready ? 0xFF8A6030 : 0xFF2A2030);
        if (st == 1) {
            drawCake(g, x + OV_W / 2, OV_Y + OV_H - 6, ovFlavor[i], 0, false);
            int col = ovT[i] < BAKE ? 0xFFFFA040 : late ? ((t / 6) % 2 == 0 ? 0xFFE5484D : 0xFF7A2A2A) : 0xFF5BD97A;
            rect(g, x + 4, OV_Y + 3, OV_W - 8, 3, 0xFF3A3A4A);
            rect(g, x + 4, OV_Y + 3, Math.round((OV_W - 8) * Math.min(1f, ovT[i] / (float) BURN)), 3, col);
        } else if (st == 2) {
            rect(g, x + OV_W / 2 - 9, OV_Y + OV_H - 14, 18, 8, 0xFF222222);
            for (int k = 0; k < 3; k++) {
                int sy = OV_Y + 4 - ((t / 2 + k * 9) % 18);
                rect(g, x + 10 + k * 12 + (int) Math.round(Math.sin((t + k * 20) / 12.0) * 2), sy + 12, 4, 4, 0x88C0C0C0);
            }
        }
        rect(g, x + 6, OV_Y + OV_H - 3, 5, 3, 0xFF3A3A4A);
        rect(g, x + OV_W - 11, OV_Y + OV_H - 3, 5, 3, 0xFF3A3A4A);
    }

    private void drawPlate(GuiGraphics g, int p) {
        int x = PL_X[p], cx = x + PL_W / 2, by = PL_Y + 16;
        if (selPlate == p) rect(g, x - 1, PL_Y - 12, PL_W + 2, 36, 0xFFFFD866);
        rect(g, x + 1, by, PL_W - 2, 3, 0xFFFFFFFF);
        rect(g, x + 4, by + 3, PL_W - 8, 1, 0xFFD8D0E0);
        if (plFlavor[p] >= 0) drawCake(g, cx, by, plFlavor[p], plTop[p], plTop[p] >= 0);
        if (tool >= 0 && plFlavor[p] >= 0 && plTop[p] < 0 && (t / 15) % 2 == 0) {
            rect(g, x, PL_Y - 11, PL_W, 1, 0xFFFFFFFF);
            rect(g, x, PL_Y + 22, PL_W, 1, 0xFFFFFFFF);
        }
    }

    private void drawButtons(GuiGraphics g) {
        for (int f = 0; f < 3; f++) { // bowls of batter
            int x = 6 + f * 34;
            boolean on = in(mx, my, x, TB_Y, 30, TB_H);
            rect(g, x, TB_Y + 2, 30, TB_H - 2, on ? 0xFF7A5A40 : 0xFF6A4A34);
            disc(g, x + 15, TB_Y + 15, 11, 0xFFE8E0F0);
            disc(g, x + 15, TB_Y + 13, 9, FLAV[f]);
            rect(g, x + 11, TB_Y + 10, 3, 2, 0x66FFFFFF);
            ctext(g, Integer.toString(f + 1), x + 15, TB_Y + 27, 0xFFD8C0A0);
        }
        boolean onTrash = in(mx, my, TRASH_X, TB_Y, 24, TB_H);
        rect(g, TRASH_X, TB_Y + 2, 24, TB_H - 2, onTrash ? 0xFF7A5A40 : 0xFF6A4A34);
        rect(g, TRASH_X + 6, TB_Y + 12, 12, 14, 0xFFA0A0B0);
        rect(g, TRASH_X + 4, TB_Y + 9, 16, 3, 0xFFB8B8C8);
        rect(g, TRASH_X + 10, TB_Y + 7, 4, 2, 0xFFB8B8C8);
        rect(g, TRASH_X + 9, TB_Y + 14, 1, 9, 0xFF70708A);
        rect(g, TRASH_X + 14, TB_Y + 14, 1, 9, 0xFF70708A);
        for (int k = 0; k < 3; k++) { // toppings
            int x = TOP_X + k * 26;
            boolean on = in(mx, my, x, TB_Y, 24, TB_H);
            rect(g, x, TB_Y + 2, 24, TB_H - 2, tool == k ? 0xFFFFD866 : on ? 0xFF7A5A40 : 0xFF6A4A34);
            rect(g, x + 2, TB_Y + 4, 20, 20, 0xFFFFFFFF);
            drawTopping(g, x + 12, TB_Y + 19, k);
            ctext(g, "QWE".substring(k, k + 1), x + 12, TB_Y + 27, tool == k ? 0xFF3A2A3A : 0xFFD8C0A0);
        }
        hover = 0;
        for (int f = 0; f < 3; f++) if (in(mx, my, 6 + f * 34, TB_Y, 30, TB_H)) hover = 1 + f;
        if (onTrash) hover = 4;
        for (int k = 0; k < 3; k++) if (in(mx, my, TOP_X + k * 26, TB_Y, 24, TB_H)) hover = 5 + k;
    }

    private String hoverText() {
        return switch (hover) {
            case 1, 2, 3 -> tr("cutemod.cakes.flavor." + (hover - 1));
            case 4 -> tr("cutemod.cakes.trash");
            default -> tr("cutemod.cakes.top." + (hover - 5));
        };
    }

    @Override
    public Component status() {
        return Component.translatable("cutemod.cakes.status", score, Math.max(0, hearts), Math.max(0, (DAY - t + 59) / 60));
    }

    @Override
    public boolean isWin() { return over && hearts > 0; }

    @Override
    public Component endTitle() {
        return Component.translatable(hearts > 0 ? "cutemod.cakes.end_day" : "cutemod.cakes.end_closed");
    }

    @Override
    public String hintKey() { return "cutemod.hint.cakes"; }
}
