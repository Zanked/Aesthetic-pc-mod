package dev.cutemod.client.os;

import java.math.BigDecimal;
import java.math.MathContext;

/** Calculator state machine (no Minecraft code, so it is easy to test). */
public class CalcLogic {
    private String entry = "0";
    private double acc = 0;
    private char op = 0;
    private boolean fresh = false, error = false;

    public String display() { return entry; }

    /** Small line above the display, e.g. "12 +". */
    public String pending() { return op == 0 ? "" : fmt(acc) + " " + op; }

    private double parse() {
        try { return Double.parseDouble(entry); } catch (NumberFormatException e) { return 0; }
    }

    static String fmt(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d)) return "Error";
        String s = new BigDecimal(d).round(new MathContext(10)).stripTrailingZeros().toPlainString();
        if (s.length() > 13) s = new BigDecimal(d).round(new MathContext(6)).stripTrailingZeros().toString();
        return s;
    }

    private void compute() {
        double b = parse();
        double r = switch (op) {
            case '+' -> acc + b;
            case '-' -> acc - b;
            case '*' -> acc * b;
            case '/' -> b == 0 ? Double.NaN : acc / b;
            default -> b;
        };
        entry = fmt(r);
        if (entry.equals("Error")) { error = true; op = 0; }
        acc = r;
    }

    /** Keys: 0-9 . + - * / = % C < ~ (~ = plus/minus). */
    public void press(char k) {
        if (error && k != 'C') { entry = "0"; acc = 0; op = 0; fresh = false; error = false; }
        if (k >= '0' && k <= '9') {
            if (fresh) { entry = "0"; fresh = false; }
            if (entry.equals("0")) entry = String.valueOf(k);
            else if (entry.length() < 12) entry += k;
        } else if (k == '.') {
            if (fresh) { entry = "0"; fresh = false; }
            if (!entry.contains(".")) entry += ".";
        } else if (k == 'C') {
            entry = "0"; acc = 0; op = 0; fresh = false; error = false;
        } else if (k == '<') {
            if (fresh) return;
            entry = entry.length() > 1 ? entry.substring(0, entry.length() - 1) : "0";
            if (entry.equals("-")) entry = "0";
        } else if (k == '~') {
            if (entry.startsWith("-")) entry = entry.substring(1);
            else if (!entry.equals("0")) entry = "-" + entry;
        } else if (k == '%') {
            entry = fmt(parse() / 100);
            fresh = true;
        } else if (k == '+' || k == '-' || k == '*' || k == '/') {
            if (op != 0 && !fresh) compute();
            else if (op == 0) acc = parse();
            if (!error) { op = k; fresh = true; }
        } else if (k == '=') {
            if (op != 0) { compute(); if (!error) op = 0; fresh = true; }
        }
    }
}
