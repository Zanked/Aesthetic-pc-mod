package dev.cutemod.client.os;

import dev.cutemod.net.TubeSyncPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

/**
 * The "People" tab of CuteTube: the animations the players drew in Paint and published. A list of cards (the first
 * picture is the thumbnail), and a player with the pictures, the tune, likes and the comments of other players.
 * Everything lives on the server (see TubeServer); this class only draws what TubeNet received and sends requests.
 * TubeApp draws this view and forwards the input, like it does for the LIVE view.
 */
final class TubeCommunity {
    private static final int TH = TubeApp.TH;
    private static final int PX = 4, PY = 4, PW = 146, PH = 82;
    private static final int BAR_Y = 89, BTN_Y = 98, VX = 102, VW = 46;
    private static final int CX = 156, CY = 16, CW = 136, CH = 100;
    private static final int[] NAME_COL = {0xFFE0A800, 0xFF7A5AC8, 0xFF3AA860, 0xFFD2762A, 0xFF2F7FD6, 0xFF3A2A3A, 0xFFC04A7A, 0xFF2A9AA8};

    /** The four tunes of the publish window: {instrument, ticks per unit, note, length, note, length...} (-1 = a rest). */
    private static final int[][] TUNE = {
            {0, 14, 6, 1, 6, 1, 13, 1, 13, 1, 15, 1, 15, 1, 13, 2, 11, 1, 11, 1, 10, 1, 10, 1, 8, 1, 8, 1, 6, 2},
            {0, 7, 10, 2, 10, 2, 11, 2, 13, 2, 13, 2, 11, 2, 10, 2, 8, 2, 6, 2, 6, 2, 8, 2, 10, 2, 10, 3, 8, 1, 8, 4},
            {1, 6, 13, 1, 15, 1, 18, 2, 15, 1, 13, 1, 10, 2, 13, 1, 15, 1, 18, 2, 20, 4, 18, 1, 15, 1, 13, 2, 10, 4},
            {3, 12, 6, 6, 10, 6, 13, 6, 18, 10, 15, 6, 13, 6, 10, 6, 8, 10}};
    private static final int[] TOTAL = new int[TUNE.length];

    static {
        for (int i = 0; i < TUNE.length; i++) {
            int sum = 0;
            for (int k = 3; k < TUNE[i].length; k += 2) sum += TUNE[i][k];
            TOTAL[i] = Math.max(1, sum * TUNE[i][1]);
        }
    }

    private record CLine(FormattedCharSequence seq, int y, int color) {}

    private static SoundEvent sv(SoundEvent e) { return e; }

    private static SoundEvent sv(Holder<SoundEvent> h) { return h.value(); }

    private int sub;                       // 0 = the list, 1 = a video
    private int ticks, lScroll, cScroll, cH, t, cool, wantT, ghostT, seenGen = -1;
    private long wantId, vid;
    private TubeSyncPayload.Entry cur;     // the video that is open
    private boolean playing, typing, confirmDel, leave;
    private String draft = "";
    private float vol = 0.6F;
    private final List<CLine> cl = new ArrayList<>();

    // ---------- open / close ----------
    void open() {
        sub = 0;
        lScroll = 0;
        wantId = 0;
        playing = false;
        typing = false;
        leave = false;
        TubeNet.request();
    }

    void close() {
        playing = false;
        typing = false;
        wantId = 0;
    }

    boolean wantsLeave() {
        boolean r = leave;
        leave = false;
        return r;
    }

    private void startWatch() {
        sub = 1;
        t = 0;
        playing = true;
        typing = false;
        draft = "";
        cScroll = 0;
        confirmDel = false;
        seenGen = -1;
        ghostT = 0;
    }

    private void backToList() {
        sub = 0;
        playing = false;
        typing = false;
        wantId = 0;
        TubeNet.request();
    }

    // ---------- logic ----------
    void tick() {
        ticks++;
        if (cool > 0) cool--;
        if (sub == 0) {
            if (ticks % 600 == 0) TubeNet.request();                         // the list refreshes now and then
            if (wantId > 0) {
                if (TubeNet.openId() == wantId) {
                    vid = wantId;
                    wantId = 0;
                    cur = TubeNet.find(vid);
                    if (cur != null) startWatch();
                } else if (++wantT > 300) wantId = 0;                        // no answer: give up
            }
            return;
        }
        if (TubeNet.openId() != vid) { backToList(); return; }               // it was deleted
        if (seenGen != TubeNet.gen()) {
            seenGen = TubeNet.gen();
            TubeSyncPayload.Entry f = TubeNet.find(vid);
            if (f != null) cur = f;
            buildComments();
        }
        if (playing) {
            t++;
            music();
        }
        if (Haunt.scary && Progress.questDone() && Progress.step3() == 3 && ownGhostVideo() && ++ghostT == 360) {   // 6 seconds on your own video
            Sfx.ui(sv(SoundEvents.AMBIENT_CAVE), 0.5F, 0.8F);
            Progress.advance3(3);                                              // his comment appears (only on your screen)
            seenGen = -1;
        }
    }

    /** Part 3: is the open video the one this player published for chapter 4? */
    private boolean ownGhostVideo() {
        int g = Progress.count("q3_vid");
        return g > 0 && vid == g;
    }

    /** His comments on that video are drawn here and never sent to the server, so only this player sees them. */
    private int ghostCount() {
        if (!Haunt.scary || !Progress.questDone() || !ownGhostVideo() || Progress.step3() < 4) return 0;
        return Progress.step3() >= 5 ? 2 : 1;
    }

    private int tuneNo() { return cur == null ? 0 : Math.max(0, Math.min(TUNE.length - 1, cur.tune())); }

    private int fps() { return cur == null ? 6 : Math.max(2, Math.min(12, cur.fps())); }

    private void music() {
        int[] m = TUNE[tuneNo()];
        int unit = m[1], p = t % TOTAL[tuneNo()], at = 0;
        for (int k = 2; k < m.length; k += 2) {
            if (at == p && m[k] >= 0) MusicApp.note(m[0], m[k], vol * 0.8F);
            at += m[k + 1] * unit;
        }
        int bar = unit * 4;
        if (p % bar == 0) MusicApp.note(2, (p / bar) % 2 == 0 ? 6 : 13, vol);
    }

    private void buildComments() {
        cl.clear();
        int y = 0;
        String me = Minecraft.getInstance().getUser().getName();
        for (int k = ghostCount() - 1; k >= 0; k--) {                          // the newest of his comments first
            for (FormattedCharSequence line : App.font().split(FormattedText.of(TubeLive.HIM + ": " + App.t("cutemod.q3.ghost." + k, me)), CW - 6)) {
                cl.add(new CLine(line, y, 0xFFC0302A));
                y += 9;
            }
            y += 3;
        }
        for (TubeSyncPayload.Comm c : TubeNet.comments()) {
            int col = NAME_COL[Math.floorMod(c.name().hashCode(), NAME_COL.length)];
            for (FormattedCharSequence line : App.font().split(FormattedText.of(c.name() + ": " + c.text()), CW - 6)) {
                cl.add(new CLine(line, y, col));
                y += 9;
            }
            y += 3;
        }
        cH = y;
        cScroll = Math.min(cScroll, maxC());
    }

    private int maxC() { return Math.max(0, cH - CH); }

    private int listMax() { return Math.max(0, 19 + (TubeNet.list().size() + 1) / 2 * 42 - TH); }

    // ---------- render ----------
    void render(GuiGraphics g, int mx, int my, int ax, int ay) {
        if (sub == 0) renderList(g, mx, my, ax, ay); else renderWatch(g, mx, my, ax, ay);
    }

    private static void heart(GuiGraphics g, int x, int y, int col) {
        Skin.rect(g, x + 1, y, 2, 1, col);
        Skin.rect(g, x + 4, y, 2, 1, col);
        Skin.rect(g, x, y + 1, 7, 1, col);
        Skin.rect(g, x + 1, y + 2, 5, 1, col);
        Skin.rect(g, x + 2, y + 3, 3, 1, col);
        Skin.rect(g, x + 3, y + 4, 1, 1, col);
    }

    private void button(GuiGraphics g, int mx, int my, int x, int y, int w, String s) {
        App.roundRect(g, x, y, w, 14, 6, App.in(mx, my, x, y, w, 14) ? 0xFFDDE2F3 : 0xFFEEF0F8);
        Skin.str(g, App.font(), s, x + (w - App.font().width(s)) / 2, y + 3, 0xFF3A2A3A, false);
    }

    private void renderList(GuiGraphics g, int mx, int my, int ax, int ay) {
        List<TubeSyncPayload.Entry> list = TubeNet.list();
        lScroll = Math.min(lScroll, listMax());
        Skin.rect(g, 0, 0, App.W, 16, 0xFFFFFFFF);
        Skin.rect(g, 0, 16, App.W, 1, 0xFFE4E6EE);
        boolean bh = my < 16 && App.in(mx, my, 4, 1, 18, 14);
        App.roundRect(g, 4, 1, 18, 14, 6, bh ? 0xFFDDE2F3 : 0xFFEEF0F8);
        Skin.str(g, App.font(), "<", 4 + (18 - App.font().width("<")) / 2, 4, 0xFF3A2A3A, false);
        Skin.str(g, App.font(), App.t("cutemod.tube.people.title"), 28, 4, 0xFF3A2A3A, false);
        String hint = App.t("cutemod.tube.people.hint");
        Skin.str(g, App.font(), hint, App.W - 6 - App.font().width(hint), 4, 0xFF8A7AA8, false);

        if (!TubeNet.loaded() || list.isEmpty()) {
            String s = App.t(TubeNet.loaded() ? "cutemod.tube.people.empty" : "cutemod.tube.people.loading");
            int y = 50;
            for (FormattedCharSequence line : App.font().split(FormattedText.of(s), 220)) {
                Skin.str(g, App.font(), line, (App.W - App.font().width(line)) / 2, y, 0xFF8A7AA8, false);
                y += 10;
            }
            return;
        }
        g.enableScissor(ax, ay + 17, ax + App.W, ay + TH);
        for (int i = 0; i < list.size(); i++) {
            TubeSyncPayload.Entry e = list.get(i);
            int x = 3 + (i % 2) * 148, y = 19 + (i / 2) * 42 - lScroll;
            if (y < -40 || y > TH) continue;
            boolean hover = my >= 17 && App.in(mx, my, x, y, 146, 40);
            App.roundRect(g, x, y, 146, 40, 5, hover ? 0xFFF4A3B5 : e.mine() ? 0xFFF9C6DA : 0xFFE6E8F0);
            App.roundRect(g, x + 1, y + 1, 144, 38, 5, 0xFFFFFFFF);
            PaintApp.drawPacked(g, e.thumb(), x + 3, y + 2, 1, 1);
            List<FormattedCharSequence> tl = App.font().split(FormattedText.of(e.title()), 72);
            for (int l = 0; l < tl.size() && l < 2; l++) Skin.str(g, App.font(), tl.get(l), x + 72, y + 3 + l * 9, 0xFF3A2A3A, false);
            Skin.str(g, App.font(), App.font().plainSubstrByWidth(e.author(), 70), x + 72, y + 22, 0xFF8A7AA8, false);
            heart(g, x + 72, y + 32, e.liked() ? 0xFFE02A2A : 0xFF8A7AA8);
            Skin.str(g, App.font(), String.valueOf(e.likes()), x + 81, y + 31, 0xFF8A7AA8, false);
            Skin.str(g, App.font(), App.t("cutemod.tube.cmt.short", e.comments()), x + 102, y + 31, 0xFF8A7AA8, false);
        }
        g.disableScissor();
        if (listMax() > 0) {
            Skin.rect(g, App.W - 3, 17, 2, TH - 17, 0xFFE9DDF2);
            int th = Math.max(12, (TH - 17) * (TH - 17) / (TH - 17 + listMax()));
            Skin.rect(g, App.W - 3, 17 + (TH - 17 - th) * lScroll / listMax(), 2, th, 0xFFB57BD6);
        }
    }

    private void renderWatch(GuiGraphics g, int mx, int my, int ax, int ay) {
        List<byte[]> frames = TubeNet.frames();
        App.roundRect(g, 1, 1, PX + PW, 144, 6, 0xFFFFFFFF);
        App.roundRect(g, CX - 3, 1, App.W - CX + 1, 144, 6, 0xFFFFFFFF);
        App.roundRect(g, PX - 1, PY - 1, PW + 2, PH + 2, 3, 0xFF3A2A3A);
        g.enableScissor(ax + PX, ay + PY, ax + PX + PW, ay + PY + PH);
        g.pose().pushPose();
        g.pose().translate(PX, PY, 0);
        Skin.rect(g, 0, 0, PW, PH, 0xFF2A2440);
        int n = Math.max(1, frames.size());
        if (!frames.isEmpty()) PaintApp.drawPacked(g, frames.get((t * fps() / 60) % n), 9, 5, 2, 1);
        if (!playing) {
            Skin.disc(g, 73, 41, 11, 0xAA000000);
            for (int k = 0; k < 6; k++) Skin.rect(g, 69 + k, 35 + k, 1, 12 - 2 * k, 0xFFFFFFFF);
        }
        g.pose().popPose();
        g.disableScissor();

        int loop = Math.max(1, n * 60 / fps());
        int fill = PW * (t % loop) / loop;
        App.roundRect(g, PX, BAR_Y, PW, 4, 2, 0xFFE3E6F0);
        if (fill > 0) App.roundRect(g, PX, BAR_Y, Math.max(4, fill), 4, 2, 0xFFE02A2A);
        Skin.disc(g, PX + fill, BAR_Y + 2, 3, 0xFFE02A2A);

        button(g, mx, my, PX, BTN_Y, 22, playing ? "||" : ">");
        button(g, mx, my, PX + 25, BTN_Y, 20, "<");
        boolean lk = cur != null && cur.liked(), mine = cur != null && cur.mine();
        App.roundRect(g, PX + 48, BTN_Y, 44, 14, 6, lk ? 0xFFF9C6DA : (!mine && App.in(mx, my, PX + 48, BTN_Y, 44, 14) ? 0xFFDDE2F3 : 0xFFEEF0F8));
        heart(g, PX + 53, BTN_Y + 4, lk ? 0xFFE02A2A : 0xFF8A7AA8);
        Skin.str(g, App.font(), String.valueOf(cur == null ? 0 : cur.likes()), PX + 63, BTN_Y + 3, 0xFF3A2A3A, false);
        App.roundRect(g, VX, BTN_Y + 5, VW, 4, 2, 0xFFE3E6F0);
        App.roundRect(g, VX, BTN_Y + 5, Math.max(4, (int) (VW * vol)), 4, 2, 0xFFB57BD6);
        Skin.disc(g, VX + (int) (VW * vol), BTN_Y + 7, 3, 0xFFB57BD6);

        String title = cur == null ? "" : cur.title(), author = cur == null ? "" : cur.author();
        Skin.str(g, App.font(), App.font().plainSubstrByWidth(title, PW), PX, 116, 0xFF3A2A3A, false);
        Skin.str(g, App.font(), App.font().plainSubstrByWidth(App.t("cutemod.tube.people.by", author), mine ? PW - 48 : PW), PX, 126, 0xFF8A7AA8, false);
        Skin.str(g, App.font(), App.t("cutemod.tube.people.frames", frames.size(), fps()), PX, 135, 0xFF8A7AA8, false);
        if (mine) {                                                           // you can remove your own video (a second click confirms)
            String d = App.t(confirmDel ? "cutemod.tube.people.sure" : "cutemod.tube.people.delete");
            int dw = App.font().width(d) + 8;
            boolean hv = App.in(mx, my, PX + PW - dw, 123, dw, 12);
            App.roundRect(g, PX + PW - dw, 123, dw, 12, 5, confirmDel ? 0xFFF9C6DA : hv ? 0xFFDDE2F3 : 0xFFEEF0F8);
            Skin.str(g, App.font(), d, PX + PW - dw + 4, 125, confirmDel ? 0xFFC0302A : 0xFF3A2A3A, false);
        }

        // comments of the other players
        Skin.str(g, App.font(), App.t("cutemod.tube.comments", TubeNet.comments().size() + ghostCount()), CX, 4, 0xFF3A2A3A, false);
        Skin.rect(g, CX, CY - 2, CW, 1, 0xFFE0D4EA);
        g.enableScissor(ax + CX, ay + CY, ax + CX + CW, ay + CY + CH);
        for (CLine l : cl) {
            int y = CY + l.y() - cScroll;
            if (y < CY - 10 || y > CY + CH) continue;
            Skin.str(g, App.font(), l.seq(), CX + 2, y, l.color(), false);
        }
        g.disableScissor();
        if (cH > CH) {
            Skin.rect(g, CX + CW + 1, CY, 3, CH, 0xFFE9DDF2);
            int th = Math.max(12, CH * CH / cH);
            Skin.rect(g, CX + CW + 1, CY + (CH - th) * cScroll / maxC(), 3, th, 0xFFB57BD6);
        }
        App.roundRect(g, CX - 1, 119, CW + 2, 18, 8, typing ? 0xFF4A7BD0 : 0xFFD3D8E6);
        App.roundRect(g, CX, 120, CW, 16, 8, 0xFFFFFFFF);
        String shown = draft.isEmpty() && !typing ? App.t("cutemod.tube.add") : draft;
        while (shown.length() > 1 && App.font().width(shown) > CW - 8) shown = shown.substring(1);
        Skin.str(g, App.font(), shown, CX + 4, 124, draft.isEmpty() && !typing ? 0xFF9A8FA8 : 0xFF3A2A3A, false);
        if (typing && (ticks / 30) % 2 == 0) Skin.rect(g, CX + 4 + App.font().width(shown), 123, 1, 10, 0xFF3A2A3A);
    }

    // ---------- input ----------
    private void setVol(int x) { vol = Math.max(0.05F, Math.min(1F, (x - VX) / (float) VW)); }

    boolean click(int x, int y, int button) {
        if (sub == 0) {
            if (y < 16) { if (App.in(x, y, 4, 1, 18, 14)) leave = true; return true; }
            List<TubeSyncPayload.Entry> list = TubeNet.list();
            for (int i = 0; i < list.size(); i++) {
                int cx = 3 + (i % 2) * 148, cy = 19 + (i / 2) * 42 - lScroll;
                if (y >= 17 && App.in(x, y, cx, cy, 146, 40)) {
                    wantId = list.get(i).id();
                    wantT = 0;
                    TubeNet.open(wantId);
                    return true;
                }
            }
            return true;
        }
        typing = false;
        if (App.in(x, y, CX - 1, 119, CW + 2, 18)) { typing = true; return true; }
        if (App.in(x, y, PX, PY, PW, PH)) { playing = !playing; return true; }
        if (App.in(x, y, PX, BTN_Y, 22, 14)) { playing = !playing; return true; }
        if (App.in(x, y, PX + 25, BTN_Y, 20, 14)) { backToList(); return true; }
        if (App.in(x, y, PX + 48, BTN_Y, 44, 14)) { if (cur != null && !cur.mine()) TubeNet.like(vid); return true; }
        if (App.in(x, y, VX - 3, BTN_Y, VW + 6, 14)) { setVol(x); return true; }
        if (cur != null && cur.mine()) {
            int dw = App.font().width(App.t(confirmDel ? "cutemod.tube.people.sure" : "cutemod.tube.people.delete")) + 8;
            if (App.in(x, y, PX + PW - dw, 123, dw, 12)) {
                if (confirmDel) { TubeNet.delete(vid); confirmDel = false; } else confirmDel = true;
                return true;
            }
        }
        confirmDel = false;
        return true;
    }

    boolean drag(int x, int y, int button) {
        if (sub == 1 && App.in(x, y, VX - 8, BTN_Y - 4, VW + 16, 22)) { setVol(x); return true; }
        return false;
    }

    boolean key(int keyCode, int modifiers) {
        if (sub == 1 && typing) {
            switch (keyCode) {
                case 257, 335 -> sendComment();
                case 256 -> typing = false;
                case 259 -> { if (!draft.isEmpty()) draft = draft.substring(0, draft.length() - 1); }
                case 86 -> {
                    if (!Screen.hasControlDown()) return false;
                    String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                    if (clip != null) {
                        String s = draft + clip.replace("\n", " ").replace("\r", "");
                        draft = s.length() > 60 ? s.substring(0, 60) : s;
                    }
                }
                default -> { return false; }
            }
            return true;
        }
        if (keyCode == 256) {                                                  // escape: one step back
            if (sub == 1) backToList(); else leave = true;
            return true;
        }
        if (sub == 1 && keyCode == 32) { playing = !playing; return true; }
        return false;
    }

    private void sendComment() {
        String s = draft.trim();
        if (s.isEmpty() || cool > 0) return;
        TubeNet.comment(vid, s);
        draft = "";
        cool = 240;                                                            // the server also lets one comment through every 4 s
        cScroll = 0;
    }

    boolean charTyped(char c) {
        if (sub != 1 || !typing || c < 32 || c == 127) return false;
        if (draft.length() < 60) draft += c;
        return true;
    }

    boolean scroll(double amount) {
        if (sub == 0) lScroll = Math.max(0, Math.min(listMax(), lScroll - (int) Math.round(amount * 20)));
        else cScroll = Math.max(0, Math.min(maxC(), cScroll - (int) Math.round(amount * 14)));
        return true;
    }
}
