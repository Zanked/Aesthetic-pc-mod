package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The mood of the scary-stories site (scarystories.cute): quiet sounds that belong to each story, a flashlight that
 * follows the mouse, a vignette and film grain that grow as you read, and what the site remembers about you.
 * All the effects follow the "scary things" switch (Haunt.scary); during the Halloween event they are stronger.
 *
 * What the site remembers (the computer's data): scary_read = the numbers of the stories you have read,
 * scary_reward = the prize for reading all eight was given. After four stories a ninth one appears in the list
 * ("Someone is reading with you", it knows your name and the time); once you have read it the link goes dead.
 */
public final class ScaryStories {
    private final Random rnd = new Random();
    private int story, t, next, step;

    // ---------- what the site remembers ----------
    public static boolean isRead(int n) {
        String s = Store.read("scary_read");
        return s != null && n >= 1 && n <= 9 && s.indexOf(Character.forDigit(n, 10)) >= 0;
    }

    public static int readCount() {
        int c = 0;
        for (int n = 1; n <= 8; n++) if (isRead(n)) c++;
        return c;
    }

    public static boolean ninthDone() { return isRead(9); }

    public static boolean ninthUnlocked() { return readCount() >= 4 || ninthDone(); }

    // ---------- the deep site (scarystories.cute/???) ----------
    /** The deep site opens when all eight stories and the ninth one have been read. */
    public static boolean deepUnlocked() { return readCount() >= 8 && ninthDone(); }

    public static boolean deepSeen(int n) {
        String s = Store.read("scary_deep");
        return s != null && n >= 1 && n <= 9 && s.indexOf(Character.forDigit(n, 10)) >= 0;
    }

    /** A page of the deep site was opened (the numbers are kept in the computer's data). */
    public static void markDeep(int n) {
        if (n < 1 || n > 9 || deepSeen(n)) return;
        String cur = Store.read("scary_deep");
        Store.write("scary_deep", (cur == null ? "" : cur) + n);
    }

    public static String deepName() { return playerName(); }

    public static String deepTime() {
        return java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
    }

    /** The story was read to the end (or skipped to the end). The eighth one gives a prize: candy in the event, coins otherwise. */
    public static void markRead(int n) {
        if (n < 1 || n > 9 || isRead(n)) return;
        String cur = Store.read("scary_read");
        Store.write("scary_read", (cur == null ? "" : cur) + n);
        if (n == 9 || readCount() < 8 || "1".equals(Store.read("scary_reward"))) return;
        Store.write("scary_reward", "1");
        if (Halloween.active()) Halloween.addCandy(12);
        else Progress.earn(40);
        Progress.toast("cutemod.toast.scary_all");
    }

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private static String playerName() {
        var p = Minecraft.getInstance().player;
        return p == null ? "Player" : p.getGameProfile().getName();
    }

    /** The list of stories: a ninth link appears (and later goes dead), and at the end the site thanks you by name. */
    public static String index(String raw) {
        String out = raw;
        if (ninthUnlocked()) {
            Matcher m = Pattern.compile("(?m)^> cute://scary8 \\|.*$").matcher(out);
            if (m.find()) out = out.substring(0, m.end()) + "\n" + tr(ninthDone() ? "cutemod.page.scary.link9dead" : "cutemod.page.scary.link9") + out.substring(m.end());
        }
        if (readCount() >= 8) out += "\n\n" + tr("cutemod.page.scary.all", playerName());
        if (deepUnlocked()) out += "\n" + tr("cutemod.page.scary.deephint");
        return out;
    }

    /** The ninth page: it knows your name and the time. After you have read it, there is nothing there. */
    public static String ninth() {
        if (ninthDone()) return tr("cutemod.page.scary9gone");
        String time = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
        return tr("cutemod.page.scary9", playerName(), time);
    }

    // ---------- sound ----------
    public void enter(int n) {
        story = n;
        t = 0;
        step = 0;
        next = 100 + rnd.nextInt(80);
    }

    public void leave() { story = 0; }

    private static void snd(Object e, float pitch, float vol) {
        SoundEvent ev = e instanceof Holder<?> h ? (SoundEvent) h.value() : (SoundEvent) e;
        Sfx.ui(ev, pitch, vol);
    }

    /** Every tick on a story page: the quiet sounds of that story. progress 0..1 is how far the reading has gone. */
    public void tick(boolean event, float progress) {
        if (story <= 0 || !Haunt.scary) return;
        t++;
        if (progress > 0.3F) {                                               // a heartbeat that speeds up as the story goes on
            int period = Math.max(26, (int) (72 - 46 * progress) - (event ? 6 : 0));
            float vol = 0.10F + 0.14F * progress;
            if (t % period == 0) snd(SoundEvents.NOTE_BLOCK_BASEDRUM, 0.5F, vol);
            else if (t % period == 9) snd(SoundEvents.NOTE_BLOCK_BASEDRUM, 0.45F, vol * 0.7F);
        }
        if (story == 7 && step < 15 && t >= 90 && t % 70 == 0) {            // fifteen steps, one by one, and then it is quiet
            snd(SoundEvents.STONE_STEP, 0.65F + 0.02F * step, 0.28F);
            step++;
            return;
        }
        if (t < next) return;
        next = t + (int) ((200 + rnd.nextInt(320)) / (event ? 1.6F : 1F));
        switch (story) {
            case 1 -> {                                                      // the creeper that kept silent
                snd(SoundEvents.GRASS_STEP, 0.6F, 0.25F);
                if (rnd.nextInt(3) == 0) snd(SoundEvents.CREEPER_PRIMED, 0.5F, 0.08F);
            }
            case 2 -> snd(rnd.nextBoolean() ? SoundEvents.NOTE_BLOCK_BASS : SoundEvents.NOTE_BLOCK_BELL, 0.5F + rnd.nextFloat() * 0.4F, 0.14F);   // an off-key tune
            case 3 -> {                                                      // the bee at the window
                snd(SoundEvents.BEE_LOOP, 0.9F, 0.16F);
                if (rnd.nextInt(2) == 0) snd(SoundEvents.GLASS_HIT, 0.8F, 0.16F);
            }
            case 4 -> {                                                      // the letter from the future
                snd(SoundEvents.BOOK_PAGE_TURN, 0.6F, 0.22F);
                snd(SoundEvents.NOTE_BLOCK_HAT, 1.6F, 0.10F);
            }
            case 5 -> snd(rnd.nextBoolean() ? SoundEvents.WOODEN_DOOR_OPEN : SoundEvents.WOODEN_DOOR_CLOSE, 0.55F, 0.2F);   // a door far away
            case 6 -> {                                                      // the mirror that is late
                snd(SoundEvents.NOTE_BLOCK_CHIME, 0.5F, 0.10F);
                snd(SoundEvents.AMBIENT_CAVE, 0.6F, 0.3F);
            }
            case 8 -> {                                                      // the villager who knew my name
                snd(SoundEvents.VILLAGER_AMBIENT, 0.5F, 0.16F);
                if (rnd.nextInt(4) == 0) snd(SoundEvents.VILLAGER_NO, 0.6F, 0.14F);
            }
            default -> snd(SoundEvents.AMBIENT_CAVE, 0.5F, 0.3F);
        }
        if (story != 6 && rnd.nextInt(3) == 0) snd(SoundEvents.AMBIENT_CAVE, 0.8F, 0.25F);
    }

    // ---------- the picture: flashlight, vignette, grain ----------
    /** Drawn over the page: only a soft circle around the mouse is lit; the edges darken and the grain thickens as p grows. */
    public void renderFx(GuiGraphics g, int mx, int my, int w, int viewY, int viewH, float progress, boolean event, int ticks) {
        float p = Math.max(0F, Math.min(1F, progress));
        boolean over = my >= viewY && my < viewY + viewH && mx >= 0 && mx < w;
        int lx = over ? mx : w / 2, ly = over ? my : viewY + viewH / 2;
        float flick = 1F + (float) Math.sin(ticks * 0.37) * 0.03F + (ticks % 97 < 2 ? -0.18F : 0F);   // the light trembles, now and then it dips
        float r0 = (24 + 8 * (1 - p)) * flick, r1 = (70 + 14 * (1 - p)) * flick;                      // and it gets weaker as the story goes on
        int maxA = event ? 0xD0 : 0xB8;
        int cell = 4;
        for (int cy = viewY; cy < viewY + viewH; cy += cell) {
            int runStart = 0, runA = -1;
            for (int cx = 0; cx <= w; cx += cell) {
                int a = -2;
                if (cx < w) {
                    float d = (float) Math.hypot(cx + 2 - lx, cy + 2 - ly);
                    float k = Math.max(0F, Math.min(1F, (d - r0) / (r1 - r0)));
                    k = k * k * (3F - 2F * k);
                    a = ((int) (k * maxA)) & 0xF8;
                }
                if (a != runA) {
                    if (runA > 0) Skin.rect(g, runStart, cy, cx - runStart, Math.min(cell, viewY + viewH - cy), runA << 24);
                    runStart = cx;
                    runA = a;
                }
            }
        }
        int steps = 10 + (int) (18 * p) + (event ? 4 : 0);                   // the vignette: the edges close in
        for (int i = 0; i < steps; i++) {
            float k = 1F - i / (float) steps;
            int c = ((int) (k * k * (0x40 + 0x70 * p))) << 24;
            Skin.rect(g, 0, viewY + i, w, 1, c);
            Skin.rect(g, 0, viewY + viewH - 1 - i, w, 1, c);
            Skin.rect(g, i, viewY, 1, viewH, c);
            Skin.rect(g, w - 1 - i, viewY, 1, viewH, c);
        }
        Random r = new Random((ticks / 2L) * 7919L);                         // grain
        int n = 30 + (int) (70 * p) + (event ? 30 : 0);
        for (int i = 0; i < n; i++) {
            int x = r.nextInt(w), y = viewY + r.nextInt(viewH);
            int a = 0x10 + r.nextInt(0x20);
            Skin.rect(g, x, y, 1, 1, (a << 24) | (r.nextBoolean() ? 0xFFFFFF : 0x000000));
        }
    }
}
