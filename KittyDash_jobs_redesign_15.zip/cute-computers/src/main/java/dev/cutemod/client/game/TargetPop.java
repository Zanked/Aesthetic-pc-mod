package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Target Pop: targets bloom and shrink, click them before they vanish. The smaller the target, the more points. 30 seconds. */
public class TargetPop extends MiniGame {
    private static final int MAX = 5, TOTAL = 30 * 60, GROW = 10, R_MAX = 14, R_MIN = 4;

    private final int[] tx = new int[MAX], ty = new int[MAX], age = new int[MAX], life = new int[MAX];
    private final boolean[] live = new boolean[MAX];
    private int time, spawn, pop;     // pop = the last hit (a little flash)
    private int popX, popY;

    @Override
    public void reset() {
        score = 0; over = false; time = TOTAL; spawn = 20; pop = 0;
        java.util.Arrays.fill(live, false);
    }

    private float radius(int i) {
        if (age[i] < GROW) return 2f + age[i] * (R_MAX - 2f) / GROW;
        return R_MAX - (age[i] - GROW) / (float) Math.max(1, life[i] - GROW) * (R_MAX - R_MIN);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return true;
        for (int i = MAX - 1; i >= 0; i--) {
            if (!live[i]) continue;
            float r = radius(i) + 2;
            float dx = x - tx[i], dy = y - ty[i];
            if (dx * dx + dy * dy <= r * r) {
                float rr = radius(i);
                int pts = rr < 8 ? 3 : rr < 12 ? 2 : 1;
                score += pts;
                live[i] = false;
                pop = 10; popX = tx[i]; popY = ty[i];
                pling(0.9F + pts * 0.2F);
                sound(net.minecraft.sounds.SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 1.2F + pts * 0.15F, 0.8F);       // pop
                return true;
            }
        }
        sound(net.minecraft.sounds.SoundEvents.STONE_BUTTON_CLICK_OFF, 1.3F, 0.4F);                               // a miss
        return true;
    }

    @Override
    public void tick() {
        if (over) return;
        if (--time <= 0) { over = true; return; }
        if (pop > 0) pop--;
        for (int i = 0; i < MAX; i++) {
            if (live[i] && ++age[i] >= life[i]) live[i] = false;
        }
        if (--spawn <= 0) {
            int slot = -1;
            for (int i = 0; i < MAX; i++) if (!live[i]) { slot = i; break; }
            if (slot >= 0) {
                live[slot] = true; age[slot] = 0;
                life[slot] = Math.max(40, 85 - (TOTAL - time) / 40);
                tx[slot] = R_MAX + 2 + rnd.nextInt(W - 2 * (R_MAX + 2));
                ty[slot] = R_MAX + 2 + rnd.nextInt(H - 2 * (R_MAX + 2) - 8);
            }
            spawn = Math.max(14, 30 - (TOTAL - time) / 90);
        }
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF3A5A7A, 0xFF1E3248);
        for (int i = 0; i < MAX; i++) {
            if (!live[i]) continue;
            int r = Math.round(radius(i));
            disc(g, tx[i], ty[i], r, 0xFFE0594F);
            disc(g, tx[i], ty[i], Math.max(1, r * 2 / 3), 0xFFFFFFFF);
            disc(g, tx[i], ty[i], Math.max(1, r / 3), 0xFFE0594F);
        }
        if (pop > 0) disc(g, popX, popY, 16 - pop, 0x44FFFFFF);
        rect(g, 0, H - 5, W, 5, 0x66000000);
        rect(g, 0, H - 5, W * Math.max(0, time) / TOTAL, 5, time < 600 ? 0xFFE5486F : 0xFF5BD97A);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.targets.status", score, Math.max(0, time) / 60); }

    @Override
    public String hintKey() { return "cutemod.hint.targets"; }
}
