package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Four original genre-mood wallpapers (numbers 22-25): neon rain city, retro pop diamonds, crimson gothic night
 * and a punk stage. Clipped by hand like the other extras, no scissor.
 */
final class StyleWallpapers {
    private static GuiGraphics gg;
    private static int bx, by, bw, bh;

    private StyleWallpapers() {}

    static void draw(GuiGraphics g, int x, int y, int w, int h, int idx) {
        gg = g; bx = x; by = y; bw = Math.max(1, w); bh = Math.max(1, h);
        int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        switch (idx) {
            case 22 -> neonCity(t);
            case 23 -> popDiamonds(t);
            case 24 -> crimsonNight(t);
            default -> punkStage(t);
        }
        gg = null;
    }

    private static void r(int x0, int y0, int x1, int y1, int argb) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fill(x0, y0, x1, y1, argb);
    }

    private static void grad(int x0, int y0, int x1, int y1, int top, int bottom) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fillGradient(x0, y0, x1, y1, top, bottom);
    }

    private static void disc(int cx, int cy, int rad, int argb) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            r(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** Scale a design coordinate (0..100) to the box. */
    private static int px(int p) { return bx + bw * p / 100; }
    private static int py(int p) { return by + bh * p / 100; }

    // ---------- 22: neon rain city ----------
    private static void neonCity(int t) {
        grad(bx, by, bx + bw, by + bh, 0xFF1A0B3B, 0xFF0A1F3F);
        // hazy magenta sun
        disc(px(70), py(38), Math.max(3, bh / 5), 0xFF7A1D8F);
        disc(px(70), py(38), Math.max(2, bh / 7), 0xFFD6338E);
        // skyline: building columns of different heights
        int[] hs = {42, 58, 36, 66, 48, 72, 40, 60, 52, 68};
        int n = hs.length;
        for (int i = 0; i < n; i++) {
            int x0 = px(i * 100 / n), x1 = px((i + 1) * 100 / n) - 1;
            int top = py(100 - hs[i]);
            r(x0, top, x1, by + bh, i % 2 == 0 ? 0xFF0D0B24 : 0xFF14123A);
            // lit windows
            for (int wy = top + 3; wy < by + bh - 3; wy += 4) {
                for (int wx = x0 + 2; wx < x1 - 1; wx += 4) {
                    int hsh = (wx * 31 + wy * 17 + i * 7) & 15;
                    if (hsh < 4) r(wx, wy, wx + 2, wy + 2, hsh < 2 ? 0xFFFFE066 : 0xFF38E8FF);
                }
            }
            // neon roof edge
            r(x0, top, x1, top + 1, i % 3 == 0 ? 0xFFFF2A9D : 0xFF21E6FF);
        }
        // a flickering neon sign
        boolean on = (t / 6) % 9 != 0;
        if (on) {
            r(px(8), py(30), px(24), py(30) + 2, 0xFFFF2A9D);
            r(px(8), py(30) + 4, px(20), py(30) + 6, 0xFF21E6FF);
        }
        // rain
        for (int i = 0; i < 26; i++) {
            int x = bx + (i * 37 + 11) % bw;
            int y = by + ((t * (3 + i % 3) + i * 29) % (bh + 8)) - 4;
            r(x, y, x + 1, y + 4, 0x6689D8FF);
        }
        // wet street glow
        grad(bx, by + bh - Math.max(2, bh / 10), bx + bw, by + bh, 0x00FF2A9D, 0x88FF2A9D);
    }

    // ---------- 23: retro pop diamonds ----------
    private static void popDiamonds(int t) {
        grad(bx, by, bx + bw, by + bh, 0xFF5B2BD6, 0xFFE0378F);
        // sweeping sunburst stripes
        int cx = px(50), cy = py(50);
        int cell = Math.max(6, bh / 4);
        int shift = (t / 2) % (cell * 2);
        for (int gy = -1; gy <= bh / cell + 1; gy++) {
            for (int gx = -1; gx <= bw / cell + 2; gx++) {
                int ox = bx + gx * cell * 2 + ((gy & 1) * cell) - shift;
                int oy = by + gy * cell;
                int rad = cell / 2;
                int col = ((gx + gy) & 1) == 0 ? 0xFFFFD23F : 0xFF33E1D1;
                // diamond = stack of rows
                for (int d = -rad; d <= rad; d++) {
                    int half = rad - Math.abs(d);
                    r(ox - half, oy + d, ox + half + 1, oy + d + 1, col);
                }
            }
        }
        // bold frame lines
        r(bx, by + 1, bx + bw, by + 3, 0xFF14091F);
        r(bx, by + bh - 3, bx + bw, by + bh - 1, 0xFF14091F);
        // a pulsing starburst in the middle
        int pr = Math.max(2, bh / 8) + (int) (Math.sin(t / 5.0) * 2);
        disc(cx, cy, pr + 2, 0xFF14091F);
        disc(cx, cy, pr, 0xFFFFFFFF);
    }

    // ---------- 24: crimson gothic night ----------
    private static void crimsonNight(int t) {
        grad(bx, by, bx + bw, by + bh, 0xFF0B0207, 0xFF3B0610);
        // big pale moon with red halo
        int mx = px(30), my = py(36), mr = Math.max(4, bh / 4);
        disc(mx, my, mr + 3, 0xFF4A0A14);
        disc(mx, my, mr, 0xFFE9DCC8);
        disc(mx - mr / 3, my - mr / 4, Math.max(1, mr / 5), 0xFFCDBFA9);
        // gothic castle silhouette with spires
        int base = by + bh;
        int[][] tw = {{58, 40}, {66, 62}, {74, 34}, {82, 56}, {90, 44}};
        r(px(54), py(66), bx + bw, base, 0xFF050105);
        for (int[] s : tw) {
            int x = px(s[0]), top = py(100 - s[1]);
            int ww = Math.max(3, bw / 22);
            r(x - ww / 2, top, x + ww / 2 + 1, base, 0xFF050105);
            for (int k = 0; k < ww; k++) r(x - (ww - k) / 2, top - k, x + (ww - k) / 2 + 1, top - k + 1, 0xFF050105);
            // a window that sometimes glows
            if ((t / 20 + s[0]) % 5 != 0) r(x, top + 6, x + 2, top + 9, 0xFFFF3B3B);
        }
        // bats
        for (int i = 0; i < 3; i++) {
            int bxp = bx + (int) ((t * (1 + i) / 2 + i * 70) % (bw + 20)) - 10;
            int byp = py(20 + i * 14) + (int) (Math.sin(t / 4.0 + i) * 3);
            boolean up = ((t / 3 + i) & 1) == 0;
            r(bxp, byp, bxp + 2, byp + 2, 0xFF000000);
            r(bxp - 3, byp + (up ? -1 : 1), bxp, byp + (up ? 1 : 2), 0xFF000000);
            r(bxp + 2, byp + (up ? -1 : 1), bxp + 5, byp + (up ? 1 : 2), 0xFF000000);
        }
        // blood-red ground mist
        grad(bx, base - Math.max(3, bh / 6), bx + bw, base, 0x00C0102A, 0x88C0102A);
    }

    // ---------- 25: punk stage ----------
    private static void punkStage(int t) {
        grad(bx, by, bx + bw, by + bh, 0xFF1B1B1F, 0xFF2B1218);
        // torn poster stripes
        for (int i = 0; i < 6; i++) {
            int x0 = px(i * 17 - 4);
            r(x0, by, x0 + Math.max(2, bw / 20), by + bh, i % 2 == 0 ? 0x22FFFFFF : 0x14FF3B6B);
        }
        // stage spotlights sweeping
        for (int k = 0; k < 2; k++) {
            double ang = Math.sin(t / 14.0 + k * 2.4) * 0.5;
            int sx = px(k == 0 ? 20 : 80);
            for (int d = 0; d < bh; d += 2) {
                int cx = sx + (int) (Math.tan(ang) * d);
                int half = 2 + d / 5;
                r(cx - half, by + d, cx + half, by + d + 2, k == 0 ? 0x1AFFE066 : 0x1A66E0FF);
            }
        }
        // checker floor
        int fy = py(76), c = Math.max(3, bw / 16);
        for (int y = fy; y < by + bh; y += c) {
            for (int x = bx; x < bx + bw; x += c) {
                boolean dark = (((x - bx) / c + (y - fy) / c) & 1) == 0;
                r(x, y, x + c, y + c, dark ? 0xFF0E0E10 : 0xFFE8E8EC);
            }
        }
        r(bx, fy - 1, bx + bw, fy, 0xFFFF3B6B);
        // a mohawk guitar-pick shape pulsing in the center
        int cx = px(50), cy = py(42), s = Math.max(5, bh / 5) + (int) (Math.sin(t / 3.0) * 1.5);
        for (int d = -s; d <= s; d++) {
            int half = (int) ((s - Math.abs(d)) * 0.8);
            r(cx - half, cy + d, cx + half + 1, cy + d + 1, 0xFFFF3B6B);
        }
        r(cx - 1, cy - s + 2, cx + 1, cy + s - 2, 0xFF1B1B1F);
        // safety-pin dots
        for (int i = 0; i < 5; i++) disc(px(10 + i * 20), py(10), 1, 0xFFC9C9D0);
    }
}
