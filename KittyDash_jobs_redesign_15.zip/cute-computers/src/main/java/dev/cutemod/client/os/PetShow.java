package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.App.rect;

/** Small drawing helpers of the talent show (see {@link PetStage}). */
public final class PetShow {
    private PetShow() {}

    public static ComputerColor colorOf(String id) {
        for (ComputerColor c : ComputerColor.values()) if (c.id.equals(id)) return c;
        return ComputerColor.PINK;
    }

    /** A 12 x 13 pixel cup (handles included). */
    public static void cup(GuiGraphics g, int x, int y, int argb) {
        rect(g, x, y, 10, 7, argb);                                   // the bowl
        rect(g, x - 2, y + 1, 2, 3, argb);                             // the handles
        rect(g, x + 10, y + 1, 2, 3, argb);
        rect(g, x + 4, y + 7, 2, 3, argb);                             // the stem
        rect(g, x + 1, y + 10, 8, 3, App.mix(argb, 0x000000, 0.35F));  // the foot
        rect(g, x + 2, y + 1, 2, 4, 0x66FFFFFF);                       // the shine
    }

    /** A 7 x 6 pixel heart. */
    public static void heart(GuiGraphics g, int x, int y, int argb) {
        rect(g, x + 1, y, 2, 1, argb);
        rect(g, x + 4, y, 2, 1, argb);
        rect(g, x, y + 1, 7, 2, argb);
        rect(g, x + 1, y + 3, 5, 1, argb);
        rect(g, x + 2, y + 4, 3, 1, argb);
        rect(g, x + 3, y + 5, 1, 1, argb);
    }
}
