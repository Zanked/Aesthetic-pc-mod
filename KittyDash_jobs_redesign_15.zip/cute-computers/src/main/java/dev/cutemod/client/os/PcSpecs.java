package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;

import java.util.Locale;
import java.util.Random;
import java.util.UUID;

/**
 * The random hardware of this player's computer. Everybody gets a different PC, but it never changes for a player:
 * it is worked out from the player's id, so it needs no saving and is the same on every screen (the Explorer, the
 * terminal). The brands are made up. Shown in the Explorer ("This PC") and by the terminal command "sysinfo".
 */
public final class PcSpecs {
    private PcSpecs() {}

    /** diskD = 0 when the PC has no second drive; usedDPct = how full that drive is; baseGb = what the system takes of C:. */
    public record Spec(String pcName, String cpu, int cores, double ghz, int ramGb, String gpu, int vramGb,
                       int diskC, int diskD, int usedDPct, int baseGb, double score) {}

    private static final String[] CPU = {"Pixelon Bee 3", "Pixelon Bee 5", "Pixelon Bee 7", "Honeycore Q9", "Panda Ultra X"};
    private static final int[][] CORES = {{2, 4}, {4, 6}, {6, 8}, {8, 12}, {12, 16}};
    private static final String[] GPU = {"Cute Graphics (shared)", "Meowforce GT 710", "Meowforce GTX 1050", "Pixel Radish 5500", "Meowforce RTX 3060", "Pixel Radish 7800"};
    private static final int[] VRAM = {0, 2, 4, 6, 8, 12};
    private static final int[] RAM = {2, 4, 8, 16, 32};
    private static final int[] RAM_W = {10, 25, 35, 22, 8};
    private static final int[] DISK_C = {32, 64, 128, 256, 512};
    private static final int[] DISK_C_W = {10, 25, 30, 25, 10};
    private static final int[] DISK_D = {250, 500, 1000};

    private static Spec cached;
    private static UUID cachedFor;

    /** The specs of the player on this screen. */
    public static Spec get() {
        var p = Minecraft.getInstance().player;
        UUID id = p == null ? null : p.getUUID();
        if (cached != null && java.util.Objects.equals(cachedFor, id)) return cached;
        Spec s = make(id == null ? 0L : (id.getMostSignificantBits() ^ (id.getLeastSignificantBits() * 31L)));
        if (id != null) { cached = s; cachedFor = id; }
        return s;
    }

    private static int weighted(Random r, int[] w) {
        int sum = 0;
        for (int v : w) sum += v;
        int x = r.nextInt(sum);
        for (int i = 0; i < w.length; i++) { x -= w[i]; if (x < 0) return i; }
        return w.length - 1;
    }

    private static Spec make(long seed) {
        Random r = new Random(seed * 0x9E3779B97F4A7C15L + 0x5DEECE66DL);
        int cpuTier = r.nextInt(CPU.length);
        int cores = CORES[cpuTier][r.nextInt(2)];
        double ghz = Math.min(4.8, 1.6 + cpuTier * 0.5 + r.nextDouble() * 0.7);
        ghz = Math.round(ghz * 10.0) / 10.0;
        int ramIdx = weighted(r, RAM_W);
        int gpuTier = r.nextInt(GPU.length);
        int cIdx = weighted(r, DISK_C_W);
        int diskC = DISK_C[cIdx];
        int diskD = r.nextInt(100) < 40 ? DISK_D[r.nextInt(DISK_D.length)] : 0;
        int usedD = 5 + r.nextInt(66);
        int baseGb = (int) Math.min(8 + r.nextInt(11), diskC * 0.4);
        double raw = cpuTier / 4.0 * 3.0 + ramIdx / 4.0 * 3.0 + gpuTier / 5.0 * 3.0 + (cIdx >= 2 ? 0.3 : 0.0);
        double score = Math.max(1.0, Math.min(9.9, Math.round((1.0 + raw) * 10.0) / 10.0));
        String name = "CUTE-PC-" + String.format(Locale.ROOT, "%04X", (int) ((seed ^ (seed >>> 32)) & 0xFFFF));
        return new Spec(name, CPU[cpuTier], cores, ghz, RAM[ramIdx], GPU[gpuTier], VRAM[gpuTier], diskC, diskD, usedD, baseGb, score);
    }

    /** "512 GB" or "1 TB". */
    public static String gb(int gb) { return gb >= 1000 ? (gb / 1000) + " TB" : gb + " GB"; }

    public static String score(Spec s) { return String.format(Locale.ROOT, "%.1f", s.score()); }
}
