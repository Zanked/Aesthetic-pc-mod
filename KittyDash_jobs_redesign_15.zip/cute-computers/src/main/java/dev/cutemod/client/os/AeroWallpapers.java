package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The three Frutiger Aero wallpapers (numbers 19-21): a bright sky with green hills, an aqua pool with
 * light rays and bubbles, and glass swooshes. Drawn like WallpapersExtra: clipped by hand, no scissor.
 */
final class AeroWallpapers {
    private static GuiGraphics gg;
    private static int bx, by, bw, bh;

    private AeroWallpapers() {}

    static void draw(GuiGraphics g, int x, int y, int w, int h, int idx) {
        gg = g; bx = x; by = y; bw = Math.max(1, w); bh = Math.max(1, h);
        int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        switch (idx) {
            case 19 -> bliss(t);
            case 20 -> aqua(t);
            default -> swoosh(t);
        }
        gg = null;
    }

    private static void r(int x0, int y0, int x1, int y1, int argb) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fill(x0, y0, x1, y1, argb);
    }

    private static void grad(int x0, int y0, int x1, int y1, int top, int bottom) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fillGradient(x0, y0, x1, y1, top, bottom);
    }

    private static void disc(int cx, int cy, int rad, int argb) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            r(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    private static void bubble(int cx, int cy, int rad) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            int in = Math.abs(dy) >= rad - 1 ? -1 : (int) Math.floor(Math.sqrt((rad - 1) * (rad - 1) - dy * dy + 0.25));
            if (in < 0) r(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, 0x88FFFFFF);
            else {
                r(cx - dx, cy + dy, cx - in, cy + dy + 1, 0x88FFFFFF);
                r(cx - in, cy + dy, cx + in + 1, cy + dy + 1, 0x22FFFFFF);
                r(cx + in + 1, cy + dy, cx + dx + 1, cy + dy + 1, 0x88FFFFFF);
            }
        }
        r(cx - rad / 2, cy - rad / 2, cx - rad / 2 + 2, cy - rad / 2 + 2, 0xDDFFFFFF);
    }

    private static int lerp(int a, int b, float f) {
        f = Math.max(0f, Math.min(1f, f));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * f) << 16) | ((int) (ag + (bg - ag) * f) << 8) | (int) (ab + (bb - ab) * f);
    }

    // ---------- 19: sky and green hills with clouds ----------
    private static void bliss(int t) {
        grad(bx, by, bx + bw, by + bh * 70 / 100, 0xFF2E8FE6, 0xFFB5E4FF);
        // clouds drift to the right
        for (int i = 0; i < 4; i++) {
            int span = bw + bw / 2;
            int cx = bx + ((i * 97 + t / 3 * (1 + i % 2)) % span) - bw / 4;
            int cy = by + bh * (10 + i * 11) / 100;
            int u = Math.max(2, bw / 22);
            disc(cx, cy, u * 2, 0xCCFFFFFF);
            disc(cx - u * 2, cy + u / 2, u + u / 2, 0xCCFFFFFF);
            disc(cx + u * 2, cy + u / 2, u + u / 2, 0xCCFFFFFF);
            r(cx - u * 3, cy + u, cx + u * 3, cy + u * 2, 0xCCFFFFFF);
        }
        // two hills, drawn one column at a time
        for (int xx = 0; xx < bw; xx++) {
            double f = xx / (double) bw;
            int back = by + bh * 62 / 100 + (int) (Math.sin(f * 5.0 + 1) * bh * 0.05);
            r(bx + xx, back, bx + xx + 1, by + bh, 0xFF5DBB4A);
            int front = by + bh * 74 / 100 + (int) (Math.sin(f * 3.2 - 0.5) * bh * 0.07);
            r(bx + xx, front, bx + xx + 1, front + 1, 0xFFB6F27A);
            r(bx + xx, front + 1, bx + xx + 1, by + bh, lerp(0xFF3FA52F, 0xFF1F7A2A, (front - by) / (float) bh));
        }
        grad(bx, by + bh * 62 / 100, bx + bw, by + bh * 80 / 100, 0x33FFFFFF, 0x00FFFFFF);
    }

    // ---------- 20: aqua water, rays and bubbles ----------
    private static void aqua(int t) {
        grad(bx, by, bx + bw, by + bh, 0xFF66E0F2, 0xFF0A63B5);
        // light rays from the top that sway
        for (int i = 0; i < 5; i++) {
            int top = bx + bw * (8 + i * 22) / 100 + (int) (Math.sin(t * 0.03 + i) * bw * 0.02);
            int wTop = Math.max(3, bw / 14), wBot = wTop * 3;
            for (int row = 0; row < bh; row += 2) {
                float f = row / (float) bh;
                int w = (int) (wTop + (wBot - wTop) * f);
                int cx = top + (int) (f * bw * 0.14);
                r(cx - w / 2, by + row, cx + w / 2, by + row + 2, ((int) (0x2A * (1 - f * 0.8f)) << 24) | 0xFFFFFF);
            }
        }
        for (int i = 0; i < 14; i++) {
            int rad = 2 + (i * 5) % 8;
            int rise = (t * (1 + i % 3) / 2 + i * 53) % (bh + rad * 4);
            int cy = by + bh + rad * 2 - rise;
            int cx = bx + rad + (i * 71 + 13) % Math.max(1, bw - rad * 2) + (int) (Math.sin(t * 0.05 + i) * 4);
            bubble(cx, cy, rad);
        }
        // the water surface shine
        grad(bx, by, bx + bw, by + bh / 6, 0x66FFFFFF, 0x00FFFFFF);
    }

    // ---------- 21: glass swooshes ----------
    private static void swoosh(int t) {
        grad(bx, by, bx + bw, by + bh, 0xFF0F4FA8, 0xFF39B6E8);
        int[] cols = {0x55BFF0FF, 0x4486E0A0, 0x33FFFFFF};
        for (int k = 0; k < 3; k++) {
            for (int xx = 0; xx < bw; xx++) {
                double f = xx / (double) bw;
                double wave = Math.sin(f * 4.2 + k * 1.3 + t * 0.012) * bh * 0.12 + Math.sin(f * 9 + k) * bh * 0.015;
                int mid = by + bh * (40 + k * 14) / 100 + (int) wave;
                int thick = Math.max(2, (int) (bh * (0.10 - k * 0.02) * (0.4 + Math.sin(f * 3.14))));
                r(bx + xx, mid, bx + xx + 1, mid + thick, cols[k]);
                r(bx + xx, mid, bx + xx + 1, mid + 1, 0xAAFFFFFF);
            }
        }
        for (int i = 0; i < 8; i++) {
            int rad = 2 + (i * 3) % 5;
            int cx = bx + (i * 83 + 11) % bw;
            int cy = by + bh - ((t * (1 + i % 3) / 3 + i * 41) % (bh + rad * 4)) + rad * 2;
            bubble(cx, cy, rad);
        }
        grad(bx, by, bx + bw, by + bh * 35 / 100, 0x44FFFFFF, 0x00FFFFFF);
    }
}
