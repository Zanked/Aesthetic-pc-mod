package dev.cutemod.client.game;

import dev.cutemod.data.BilliardsBot;
import dev.cutemod.data.BilliardsMatch;
import dev.cutemod.data.BilliardsTable;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayDeque;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Billiards: ten coloured balls and a white one. Aim with the mouse (the line shows where the white ball goes), the farther the
 * mouse is from the white ball the harder the shot, click to shoot.
 * <ul>
 * <li>Solo: pot every ball before the 25 shots run out.</li>
 * <li>Against the bot (easy / normal / hard) or ONLINE against another player on the server: you take turns. Pot a ball and you
 * shoot again, miss and the turn passes; if the white ball drops the turn passes too. Whoever has potted more balls when the
 * table is clear wins.</li>
 * </ul>
 * The table and its physics are in {@link BilliardsTable}, the rules of a game for two in {@link BilliardsMatch}, the bot in
 * {@link BilliardsBot} (no Minecraft classes, tested alone). Online, the server (dev.cutemod.net.BilliardsServer) plays every shot
 * itself and tells both players; each computer replays it with the same physics, so it looks and sounds the same on both.
 */
public class Billiards extends MiniGame {
    private static final int L = BilliardsTable.L, R = BilliardsTable.R, T = BilliardsTable.T, B = BilliardsTable.B;
    private static final int N = BilliardsTable.N, SHOTS = 25;
    private static final float MAX_PULL = BilliardsTable.MAX_PULL;
    private static final int[] COL = {0xFFFFFFFF, 0xFFF5D84A, 0xFF4A8FE0, 0xFFE0594F, 0xFF9B5FD0, 0xFFF58B25, 0xFF52B85A,
            0xFFA83A3A, 0xFF2A2A32, 0xFFF06AAE, 0xFF4FC9B8};

    private static final int BTN_X = 162, BTN_W = 40;      // the Menu / Resign button on the bottom of the frame
    private static final int MENU = 0, PLAY = 1, LOBBY = 2;
    private static final int SOLO = 0, BOT = 1, ONLINE = 2;
    /** Score of a win against the bot (easy / normal / hard) and of a draw; and of an online win / draw. */
    private static final int[] WIN_SCORE = {50, 75, 100}, DRAW_SCORE = {10, 25, 40};
    private static final int ONLINE_WIN = 60, ONLINE_DRAW = 20;

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "cutemod-billiards-ai");
        t.setDaemon(true);
        return t;
    });

    private final BilliardsTable t = new BilliardsTable();
    private int state = MENU, mode = SOLO, anim;
    private boolean moving, won;
    private int shots, msg;
    private String note = "";

    // a game for two (against the bot, or online)
    private BilliardsMatch match;                              // the bot game; online the server has the match
    private int level = 1, me;                                 // the bot level; which player we are: 0 breaks, 1 shoots second
    private int vTurn;                                         // whose turn it is, as the players see it (changes when a shot has finished)
    private final int[] vScore = new int[2];
    private BilliardsNet.Shot playing;                         // the shot that is being replayed (null: the table is at rest)
    private final ArrayDeque<BilliardsNet.Shot> local = new ArrayDeque<>();
    private Future<float[]> thinking;
    private int wait, resultKind;                              // resultKind: 0 none, 1 you won, 2 you lost, 3 draw
    private boolean awaiting;
    private String oppName = "";
    private int seenVersion = -1, noticeT, resignT;
    private String noticeKey = "";
    private final Random botRnd = new Random();

    public Billiards() {
        t.sink = new BilliardsTable.Sink() {
            @Override public void hit(float v) {                          // balls click together: louder and higher for a hard hit
                sound(net.minecraft.sounds.SoundEvents.GLASS_HIT, 1.35F + v * 0.5F + rnd.nextFloat() * 0.1F, 0.25F + 0.6F * v);
            }

            @Override public void wall() {                                // a dull knock on the cushion
                sound(net.minecraft.sounds.SoundEvents.WOODEN_DOOR_CLOSE, 1.9F, 0.22F);
            }

            @Override public void pocket(int ball, int potted) {
                sound(net.minecraft.sounds.SoundEvents.STONE_STEP, 0.55F, 0.8F);                       // the ball drops into the leather pocket
                sound(net.minecraft.sounds.SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 0.8F, 0.5F);
                if (ball == 0) sound(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_BASS.value(), 0.6F, 0.7F);
                else { if (mode == SOLO) score += 10; pling(0.9F + Math.min(potted, 4) * 0.2F); }
            }
        };
    }

    private static String tr(String key) { return Component.translatable(key).getString(); }

    // ---------- game flow ----------
    @Override
    public void reset() {
        score = 0; over = false; won = false; resultKind = 0;
        state = MENU; mode = SOLO;
        cancelThinking();
        if (BilliardsNet.inMatch() && BilliardsNet.result != 0) BilliardsNet.leaveGame();   // a finished online game: we are done with it
        playing = null; local.clear(); awaiting = false; moving = false;
        noticeT = 0; resignT = 0; msg = 0;
        t.rack();
        BilliardsNet.request();            // maybe a game is still running on the server: tick() brings us back to it
    }

    private void cancelThinking() {
        if (thinking != null) thinking.cancel(true);
        thinking = null;
    }

    private void startSolo() {
        mode = SOLO; state = PLAY;
        score = 0; over = false; won = false; shots = SHOTS; moving = false; msg = 0;
        t.rack();
        pling(1.2F);
    }

    private void startBot(int lvl) {
        mode = BOT; state = PLAY; level = lvl;
        score = 0; over = false; resultKind = 0; msg = 0;
        match = new BilliardsMatch(null, null);
        t.copyFrom(match.table);
        me = 0; vTurn = 0; vScore[0] = vScore[1] = 0;
        oppName = tr("cutemod.billiards.bot");
        playing = null; local.clear(); cancelThinking();
        wait = 0;
        pling(1.2F);
    }

    private void startOnline() {
        mode = ONLINE; state = PLAY;
        cancelThinking();
        me = BilliardsNet.youFirst ? 0 : 1;
        oppName = BilliardsNet.opponent;
        over = false; resultKind = 0; score = 0; msg = 0;
        playing = null; local.clear(); awaiting = false;
        t.setResting(BilliardsNet.xy, BilliardsNet.mask);
        seenVersion = -1;
        pling(1.2F);
    }

    private boolean versus() { return mode != SOLO; }

    private boolean humanTurn() {
        if (over || state != PLAY) return false;
        if (mode == SOLO) return !moving;
        if (playing != null || !local.isEmpty()) return false;
        if (mode == ONLINE) return !awaiting && BilliardsNet.shots.isEmpty() && vTurn == me;
        return thinking == null && vTurn == me;
    }

    // ---------- the shot ----------
    private float pull() {
        float dx = mx - t.x[0], dy = my - t.y[0];
        return Math.min(MAX_PULL, (float) Math.sqrt(dx * dx + dy * dy));
    }

    private void cueSound(float power) {
        // the cue strikes the white ball: a hard tap and a glassy click, louder for a harder shot
        sound(net.minecraft.sounds.SoundEvents.STONE_BUTTON_CLICK_ON, 1.1F, 0.6F + 0.4F * power);
        sound(net.minecraft.sounds.SoundEvents.GLASS_HIT, 1.5F + 0.4F * power, 0.5F + 0.4F * power);
    }

    private void play(BilliardsNet.Shot s) {
        t.setResting(s.preXy(), s.preMask());
        t.vx[0] = s.vx(); t.vy[0] = s.vy();
        playing = s;
        awaiting = false;
        cueSound(Math.min(1f, Math.max(0f, ((float) Math.sqrt(s.vx() * s.vx() + s.vy() * s.vy()) - 1.2f) / 5.3f)));
    }

    /** The shot of the bot game, as the same record the online game uses. */
    private BilliardsNet.Shot record(BilliardsMatch m) {
        return new BilliardsNet.Shot(m.shotSeq, m.preXy, m.preMask, m.shotVx, m.shotVy, m.table.positions(), m.table.aliveMask(),
                m.turn, m.score[0], m.score[1], m.result);
    }

    @Override
    public boolean click(int cx, int cy, int button) {
        if (over) return false;
        if (state == MENU) return menuClick(cx, cy);
        if (state == LOBBY) return lobbyClick(cx, cy);
        if (in(cx, cy, BTN_X - 4, H - 12, BTN_W + 8, 12)) {            // the Menu / Resign button: it always asks twice, so one stray click cannot end the game
            if (resignT <= 0) { resignT = 180; pling(0.7F); return true; }
            resignT = 0;
            if (mode == ONLINE) BilliardsNet.leaveGame();
            cancelThinking();
            playing = null; local.clear(); moving = false;
            state = MENU; mode = SOLO;
            t.rack();
            return true;
        }
        resignT = 0;                                                   // a click on the table takes the question back
        if (!humanTurn()) return true;
        float dx = cx - t.x[0], dy = cy - t.y[0], len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 6) return true;
        float power = Math.min(MAX_PULL, len) / MAX_PULL;
        if (mode == SOLO) {
            if (!t.shoot(dx, dy, power)) return true;
            shots--; moving = true; note = "";
            cueSound(power);
        } else if (mode == BOT) {
            if (!match.shoot(0, dx, dy, power)) return true;
            local.add(record(match));
        } else {
            awaiting = true;                                  // the server plays it and tells both of us, the sound comes with the replay
            BilliardsNet.shoot(dx, dy, power);
        }
        return true;
    }

    // ---------- ticking ----------
    @Override
    public void tick() {
        anim++;
        if (msg > 0) msg--;
        if (noticeT > 0) noticeT--;
        if (resignT > 0) resignT--;
        netTick();
        if (state != PLAY) return;
        if (mode == SOLO) {
            if (!moving) return;
            if (!t.tick()) settleSolo();
            return;
        }
        if (playing != null) {
            if (!t.tick()) endShot();
            return;
        }
        if (mode == BOT) botTick();
        else onlineTick();
    }

    private void botTick() {
        if (!local.isEmpty()) { play(local.poll()); return; }
        if (over) return;
        if (vTurn == 1) {
            if (thinking == null) {
                if (--wait > 0) return;
                final BilliardsTable copy = match.table.copy();
                final int lvl = level;
                thinking = POOL.submit(() -> BilliardsBot.best(copy, 1, lvl, new Random()));
            } else if (thinking.isDone()) {
                float[] sh = null;
                try { sh = thinking.get(); } catch (Exception ignored) { /* cancelled or failed: shoot at random below */ }
                thinking = null;
                if (sh == null) sh = new float[]{botRnd.nextFloat() - 0.5f, botRnd.nextFloat() - 0.5f, 0.6f};
                if (match.shoot(1, sh[0], sh[1], sh[2])) local.add(record(match));
                else { vTurn = 0; }                          // cannot happen; do not hang the game
            }
        }
    }

    private void onlineTick() {
        if (!BilliardsNet.shots.isEmpty()) { play(BilliardsNet.shots.poll()); return; }
        if (BilliardsNet.version == seenVersion) return;
        seenVersion = BilliardsNet.version;
        awaiting = false;
        t.setResting(BilliardsNet.xy, BilliardsNet.mask);
        vTurn = BilliardsNet.turn;
        vScore[0] = BilliardsNet.score0; vScore[1] = BilliardsNet.score1;
        if (BilliardsNet.result != 0 && !over) finishVersus(BilliardsNet.result);
    }

    /** The replay of a shot has stopped: take the truth from the record (the table, the turn, the score). */
    private void endShot() {
        BilliardsNet.Shot s = playing;
        playing = null;
        boolean scratch = t.scratch;                         // read before the table is reset below
        t.setResting(s.postXy(), s.postMask());
        int shooter = vTurn;                                 // the turn before this shot
        int[] ns = {s.score0(), s.score1()};
        int own = ns[shooter] - vScore[shooter], gift = ns[1 - shooter] - vScore[1 - shooter];
        vTurn = s.turn(); vScore[0] = ns[0]; vScore[1] = ns[1];
        if (scratch) { note = tr("cutemod.billiards.scratch.vs"); msg = 90; }
        else if (own >= 2) { note = Component.translatable("cutemod.billiards.combo", own).getString(); msg = 90; }
        else if (own == 0 && gift > 0) { note = tr("cutemod.billiards.gift"); msg = 90; }
        else if (own == 0) { note = tr("cutemod.billiards.miss"); msg = 60; }
        if (mode == ONLINE) seenVersion = -1;                // look at the latest news from the server once more
        if (s.result() != 0) finishVersus(s.result());
        else if (mode == BOT && vTurn == 1) wait = 25;
    }

    private void finishVersus(int r) {
        if (over) return;
        over = true;
        boolean firstWon = r == 1;
        resultKind = r == 3 ? 3 : (firstWon == (me == 0)) ? 1 : 2;
        if (mode == BOT) score = resultKind == 1 ? WIN_SCORE[level] : resultKind == 3 ? DRAW_SCORE[level] : 0;
        else score = resultKind == 1 ? ONLINE_WIN : resultKind == 3 ? ONLINE_DRAW : 0;
        sound(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, resultKind == 2 ? 0.5F : 1.0F, 0.7F);
    }

    private void settleSolo() {
        moving = false;
        int potShot = t.potShot;
        if (potShot >= 2) { score += 5 * (potShot - 1); note = Component.translatable("cutemod.billiards.combo", potShot).getString(); msg = 90; }
        if (t.scratch) {                                                    // the white ball dropped: it comes back, and it costs points
            score = Math.max(0, score - 5);
            note = tr("cutemod.billiards.scratch"); msg = 90;
            t.respawnWhite();
        }
        if (t.colouredLeft() == 0) {
            won = true; over = true; score += 30 + 5 * shots;
            sound(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, 1.0F, 0.7F);                                  // the table is clear
        }
        else if (shots <= 0) over = true;
    }

    // ---------- online ----------
    private void netTick() {
        int n = BilliardsNet.takeNotice();
        if (n != 0) { noticeKey = "cutemod.billiards.notice." + n; noticeT = 240; }
        if (state == LOBBY && anim % 120 == 0) BilliardsNet.request();
        if (BilliardsNet.inMatch() && (mode != ONLINE || state != PLAY) && !over) startOnline();
    }

    // ---------- menu and lobby ----------
    private boolean menuClick(int x, int y) {
        if (in(x, y, 12, 20, 196, 18)) { startSolo(); return true; }
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 12 + i * 66, 56, 64, 18)) { startBot(i); return true; }
        }
        if (in(x, y, 12, 82, 196, 18)) { state = LOBBY; BilliardsNet.request(); pling(1.0F); return true; }
        return false;
    }

    private int listY() { return !BilliardsNet.invitedBy.isEmpty() ? 56 : !BilliardsNet.invitedTo.isEmpty() ? 52 : 30; }

    private boolean lobbyClick(int x, int y) {
        if (in(x, y, 12, 120, 60, 14)) {                     // Back
            if (!BilliardsNet.invitedTo.isEmpty()) BilliardsNet.cancelInvite();
            state = MENU;
            return true;
        }
        if (!BilliardsNet.invitedBy.isEmpty()) {
            if (in(x, y, 12, 36, 94, 14)) { BilliardsNet.accept(BilliardsNet.invitedBy); pling(1.4F); return true; }
            if (in(x, y, 114, 36, 94, 14)) { BilliardsNet.decline(BilliardsNet.invitedBy); return true; }
        } else if (!BilliardsNet.invitedTo.isEmpty()) {
            if (in(x, y, 12, 34, 196, 14)) { BilliardsNet.cancelInvite(); return true; }
        }
        int ly = listY();
        for (int i = 0; i < Math.min(BilliardsNet.players.size(), (112 - ly) / 16); i++) {
            if (in(x, y, 12, ly + i * 16, 196, 14)) {
                BilliardsNet.invite(BilliardsNet.players.get(i));
                pling(1.1F);
                return true;
            }
        }
        return true;
    }

    // ---------- drawing ----------
    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean accent) {
        boolean hover = in(mx, my, x, y, w, h);
        rect(g, x, y, w, h, hover ? 0xFFFFFFFF : accent ? 0xFFE6F7D8 : 0xFFEFF4E6);
        rect(g, x, y + h - 2, w, 2, 0xFF8FB08A);
        ctextW(g, label, x + w / 2, y + (h - 8) / 2, w - 6, 0xFF1F3A2A);
    }

    private static void dot(GuiGraphics g, int px, int py, int c) { rect(g, px, py, 1, 1, c); }

    private void ball(GuiGraphics g, int cx, int cy, int c) {
        disc(g, cx + 1, cy + 1, 4, 0x55000000);
        disc(g, cx, cy, 4, c);
        rect(g, cx - 2, cy - 2, 2, 1, 0x99FFFFFF);
    }

    @Override
    public void render(GuiGraphics g) {
        if (state == MENU) { renderMenu(g); return; }
        if (state == LOBBY) { renderLobby(g); return; }
        renderTable(g);
        renderHud(g);
    }

    private void renderTable(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0xFF6B4020);                                    // the wooden frame
        rect(g, 2, 2, W - 4, H - 4, 0xFF8A5530);
        rect(g, L - 3, T - 3, R - L + 6, B - T + 6, 0xFF1F6A40);            // cushions
        rect(g, L, T, R - L, B - T, 0xFF2E8B57);                            // the cloth
        rect(g, L, T, R - L, 2, 0x22FFFFFF);
        rect(g, 60, T + 4, 1, B - T - 8, 0x14FFFFFF);                       // the head string
        for (float[] p : BilliardsTable.POCKETS) disc(g, Math.round(p[0]), Math.round(p[1]), 7, 0xFF14110F);
        for (int i = N - 1; i >= 0; i--) {
            if (!t.alive[i]) continue;
            int bx = Math.round(t.x[i]), by = Math.round(t.y[i]);
            if (versus() && i > 0) disc(g, bx, by, 5, BilliardsMatch.owner(i) == me ? 0xFFFFE680 : 0xFFE5486F);   // gold ring: yours, red ring: theirs
            ball(g, bx, by, COL[i]);
        }
        boolean resting = mode == SOLO ? !moving : playing == null;
        if (humanTurn() && resting && t.alive[0]) aim(g);
        if (msg > 0 && !over) ctext(g, note, W / 2, T + 5, 0xFFFFD866);
    }

    private void renderHud(GuiGraphics g) {
        // the power
        rect(g, 12, H - 8, 62, 4, 0x66000000);
        if (humanTurn()) {
            float p = pull() / MAX_PULL;
            rect(g, 12, H - 8, Math.round(62 * p), 4, p > 0.8f ? 0xFFE5486F : 0xFFFFD866);
        }
        if (mode == SOLO) {
            for (int i = 0; i < Math.min(shots, SHOTS); i++) rect(g, 78 + i * 3, H - 8, 2, 4, 0xFFF4F0E8);
        } else {
            // the names and the score on the top of the frame; the one whose turn it is shines
            String you = clip(tr("cutemod.billiards.you"), 50) + " " + vScore[me] + "/" + BilliardsMatch.PER_PLAYER;
            String opp = vScore[1 - me] + "/" + BilliardsMatch.PER_PLAYER + " " + clip(oppName, 60);
            boolean mine = vTurn == me && !over;
            text(g, you, 6, 0, mine ? 0xFFFFE9A8 : 0xFFE8D8C0);
            text(g, opp, W - 6 - tw(opp), 0, !mine && !over ? 0xFFFFE9A8 : 0xFFE8D8C0);
            String turn;
            if (over) turn = tr("cutemod.billiards.over");
            else if (humanTurn()) turn = tr("cutemod.billiards.turn.you");
            else if (mode == BOT) turn = vTurn == 1 ? tr("cutemod.billiards.turn.bot") + ".".repeat(1 + anim / 15 % 3) : "";
            else turn = awaiting ? tr("cutemod.billiards.turn.wait") : vTurn == me ? "" : Component.translatable("cutemod.billiards.turn.opp", oppName).getString();
            if (!turn.isEmpty()) { int tx = 78; ctextW(g, turn, tx + 40, H - 9, 80, 0xFFFFE9A8); }
        }
        String label = tr(resignT > 0 ? "cutemod.billiards.resign_sure" : mode == ONLINE ? "cutemod.billiards.resign" : "cutemod.billiards.menu");
        boolean hover = in(mx, my, BTN_X - 4, H - 12, BTN_W + 8, 12);
        rect(g, BTN_X, H - 9, BTN_W, 8, hover ? 0xFFFFE9A8 : resignT > 0 ? 0xFFE5486F : 0xFF4A2D18);
        ctextW(g, label, BTN_X + BTN_W / 2, H - 9, BTN_W - 2, hover ? 0xFF3A2A18 : 0xFFF4E8D0);
    }

    private void aim(GuiGraphics g) {
        float dx = mx - t.x[0], dy = my - t.y[0], len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 6) return;
        dx /= len; dy /= len;
        float p = pull() / MAX_PULL;
        // a dotted line to the first ball or cushion it meets
        float px = t.x[0], py = t.y[0];
        for (int s = 0; s < 120; s++) {
            px += dx * 2; py += dy * 2;
            boolean stop = px < L + BilliardsTable.BR || px > R - BilliardsTable.BR || py < T + BilliardsTable.BR || py > B - BilliardsTable.BR;
            for (int i = 1; i < N && !stop; i++) {
                if (t.alive[i] && (px - t.x[i]) * (px - t.x[i]) + (py - t.y[i]) * (py - t.y[i]) < BilliardsTable.BR * BilliardsTable.BR * 4) stop = true;
            }
            if (stop) { disc(g, Math.round(px), Math.round(py), 3, 0x66FFFFFF); break; }
            if (s % 2 == 0 && s > 3) dot(g, Math.round(px), Math.round(py), 0xCCFFFFFF);
        }
        // the cue behind the white ball, pulled back with the power
        float back = 6 + p * 14;
        for (int k = 0; k < 46; k++) {
            int c = k < 3 ? 0xFF5BA8F0 : (k > 36 ? 0xFF3A2A1A : 0xFFE8C890);
            rect(g, Math.round(t.x[0] - dx * (back + k)), Math.round(t.y[0] - dy * (back + k)), 2, 2, c);
        }
    }

    private void felt(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0xFF6B4020);
        rect(g, 2, 2, W - 4, H - 4, 0xFF1F6A40);
    }

    private void renderMenu(GuiGraphics g) {
        felt(g);
        ctextW(g, tr("cutemod.billiards.title"), W / 2, 6, W - 24, 0xFFFFE9A8);
        button(g, 12, 20, 196, 18, tr("cutemod.billiards.solo"), false);
        ctextW(g, tr("cutemod.billiards.vs_bot"), W / 2, 44, W - 24, 0xFFFFFFFF);
        for (int i = 0; i < 3; i++) button(g, 12 + i * 66, 56, 64, 18, tr("cutemod.billiards.lvl." + i), false);
        button(g, 12, 82, 196, 18, tr("cutemod.billiards.online"), true);
        ball(g, 20, 10, COL[3]);
        ball(g, 34, 10, COL[1]);
        ball(g, W - 34, 10, COL[2]);
        ball(g, W - 20, 10, COL[0]);
        if (BilliardsNet.inMatch()) ctextW(g, tr("cutemod.billiards.resume"), W / 2, 108, W - 24, 0xFFFFE9A8);
    }

    private void renderLobby(GuiGraphics g) {
        felt(g);
        ctextW(g, tr("cutemod.billiards.lobby.title"), W / 2, 8, W - 24, 0xFFFFE9A8);
        String by = BilliardsNet.invitedBy, to = BilliardsNet.invitedTo;
        if (!by.isEmpty()) {                                     // someone invited us
            rect(g, 8, 20, 204, 34, 0xFF2E8B57);
            ctext(g, Component.translatable("cutemod.billiards.invite.from", by).getString(), W / 2, 24, 0xFFFFFFFF);
            button(g, 12, 36, 94, 14, tr("cutemod.billiards.accept"), true);
            button(g, 114, 36, 94, 14, tr("cutemod.billiards.decline"), false);
        } else if (!to.isEmpty()) {                              // we invited someone
            ctext(g, Component.translatable("cutemod.billiards.waiting", to).getString() + ".".repeat(1 + anim / 20 % 3), W / 2, 22, 0xFFFFFFFF);
            button(g, 12, 34, 196, 14, tr("cutemod.billiards.cancel"), false);
        } else {
            ctextW(g, tr("cutemod.billiards.lobby.hint"), W / 2, 20, W - 24, 0xFFBFE3C8);
        }
        int ly = listY(), rows = Math.min(BilliardsNet.players.size(), (112 - ly) / 16);
        if (BilliardsNet.players.isEmpty()) ctextW(g, tr("cutemod.billiards.lobby.none"), W / 2, ly + 10, W - 24, 0xFF8FC0A0);
        for (int i = 0; i < rows; i++) {
            String n = BilliardsNet.players.get(i);
            button(g, 12, ly + i * 16, 196, 14, clip(n, 180), n.equals(to));
        }
        if (BilliardsNet.players.size() > rows) ctext(g, "+" + (BilliardsNet.players.size() - rows), W / 2, 112, 0xFF8FC0A0);
        if (noticeT > 0) ctextW(g, tr(noticeKey), W / 2, 108, W - 24, 0xFFFF9A9A);
        button(g, 12, 120, 60, 14, tr("cutemod.billiards.back"), false);
    }

    // ---------- the shell ----------
    @Override
    public boolean isWin() { return mode == SOLO ? won : resultKind == 1; }

    @Override
    public Component endTitle() {
        if (mode == SOLO || state != PLAY) return Component.translatable(won ? "cutemod.billiards.win" : "cutemod.ui.gameover");
        return Component.translatable("cutemod.billiards.end." + resultKind);
    }

    @Override
    public Component status() {
        if (state != PLAY) return Component.translatable("cutemod.billiards.title");
        if (mode == SOLO) return Component.translatable("cutemod.billiards.status", score, Math.max(0, shots));
        return Component.translatable("cutemod.billiards.vs.status", vScore[me], vScore[1 - me], oppName);
    }

    @Override
    public String hintKey() { return "cutemod.hint.billiards"; }
}
