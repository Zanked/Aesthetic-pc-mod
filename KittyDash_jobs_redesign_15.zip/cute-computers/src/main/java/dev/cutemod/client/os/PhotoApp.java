package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

/**
 * Pet Photo: a little photo studio. Pick a background and a pose, the pet wears what it wears now, press the shutter.
 * The album keeps 6 photos; a photo is only a note (background, pose, clothes, species), the picture is drawn again
 * when you look at it, so nothing big is saved. Saved as "photos".
 */
public class PhotoApp extends KitApp {
    private static final int SLOTS = 6, BGS = 6, POSES = 3, VW = 170, VH = 100, VX = 6, VY = 20;

    /** A photo: background, pose (0 happy, 1 calm, 2 asleep), what is worn, the species. Empty species = no photo. */
    private record Photo(int bg, int pose, String head, String body, String species) {}

    private final Photo[] album = new Photo[SLOTS];
    private int bg, pose, view = -1, flash;
    private boolean loaded;

    @Override protected int accent() { return 0xFF8A9AE8; }

    @Override protected String id() { return "photo"; }

    @Override
    public void attach(Shell shell) { super.attach(shell); load(); }

    private static boolean ok(String s) { return s.length() <= 80 && s.matches("[a-z0-9_+]*"); }

    private void load() {
        loaded = true;
        try {
            String s = Store.read("photos");
            if (s == null) return;
            String[] rows = s.split(";", -1);
            for (int i = 0; i < SLOTS && i < rows.length; i++) {
                String[] p = rows[i].split(",", -1);
                if (p.length == 5 && ok(p[2]) && ok(p[3]) && ok(p[4]) && !p[4].isEmpty())
                    album[i] = new Photo(Math.floorMod(Integer.parseInt(p[0]), BGS), Math.floorMod(Integer.parseInt(p[1]), POSES), p[2], p[3], p[4]);
            }
        } catch (Exception ignored) { }
    }

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < SLOTS; i++) {
            Photo p = album[i];
            sb.append(i > 0 ? ";" : "").append(p == null ? ",,,," : p.bg() + "," + p.pose() + "," + p.head() + "," + p.body() + "," + p.species());
        }
        Store.write("photos", sb.toString());
    }

    private ComputerColor species() {
        ComputerColor c = PetApp.speciesOf(shell.color());
        return c == null ? shell.color() : c;
    }

    private static ComputerColor byId(String id) {
        for (ComputerColor c : ComputerColor.values()) if (c.id.equals(id)) return c;
        return ComputerColor.PINK;
    }

    private void shoot() {
        int slot = -1;
        for (int i = 0; i < SLOTS; i++) if (album[i] == null) { slot = i; break; }
        if (slot < 0) { say("cutemod.photo.msg.full"); return; }
        album[slot] = new Photo(bg, pose, Progress.equipped(), Progress.equippedBody(), species().id);
        save();
        flash = 14;
        Sfx.ui(SoundEvents.UI_BUTTON_CLICK.value(), 1.4F, 0.6F);
        say("cutemod.photo.msg.saved", slot + 1);
    }

    @Override
    public void tick() {
        super.tick();
        if (flash > 0) flash--;
    }

    // ---------- the scene (drawn in a 170 x 100 box, scaled for the small pictures) ----------
    private void scene(GuiGraphics g, int x, int y, float s, Photo p, boolean live) {
        ComputerColor spc = p == null ? species() : byId(p.species());
        int b = p == null ? bg : p.bg(), po = p == null ? pose : p.pose();
        String head = p == null ? Progress.equipped() : p.head(), body = p == null ? Progress.equippedBody() : p.body();
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(s, s, 1F);
        backdrop(g, b, live ? ticks : 0);
        PetBlob.Info info = PetBlob.parse(Store.read("pet_" + spc.id));
        int stage = info == null ? 2 : info.stage();
        float sc = 1.25F * PetArt.scaleOf(stage);
        int px = VW / 2, floor = 88, bob = live ? (int) Math.round(Math.sin(ticks / 18.0) * 1.2) : 0;
        g.pose().pushPose();
        g.pose().translate(px, floor, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-px, -floor, 0);
        PetArt.draw(g, spc, px, floor - 28 + bob, po == 0 ? 2 : 1, live ? ticks : 0, po == 2, false, stage, head, body);
        g.pose().popPose();
        g.pose().popPose();
    }

    private static void backdrop(GuiGraphics g, int b, int t) {
        switch (b) {
            case 0 -> {                                                   // park
                rect(g, 0, 0, VW, 62, 0xFF9AD8FF); rect(g, 0, 62, VW, 38, 0xFF8FD39A);
                disc(g, 138, 20, 10, 0xFFFFE066);
                rect(g, 20, 14, 26, 6, 0xFFFFFFFF); rect(g, 26, 10, 14, 6, 0xFFFFFFFF); rect(g, 80, 28, 22, 5, 0xFFFFFFFF);
                rect(g, 10, 54, 4, 12, 0xFF8A5A32); disc(g, 12, 50, 9, 0xFF5BBF6A);
            }
            case 1 -> {                                                   // night
                rect(g, 0, 0, VW, 66, 0xFF1E1A4A); rect(g, 0, 66, VW, 34, 0xFF2A3A5A);
                for (int i = 0; i < 24; i++) if ((t / 10 + i) % 6 != 0) rect(g, (i * 37) % VW, 4 + (i * 23) % 54, 1, 1, 0xFFFFFFFF);
                disc(g, 136, 22, 11, 0xFFFFF3B0); disc(g, 141, 19, 9, 0xFF1E1A4A);
            }
            case 2 -> {                                                   // beach
                rect(g, 0, 0, VW, 50, 0xFF9AD8FF); rect(g, 0, 50, VW, 20, 0xFF4AB0E8); rect(g, 0, 70, VW, 30, 0xFFF0D8A0);
                disc(g, 30, 22, 10, 0xFFFFE066);
                for (int i = 0; i < 6; i++) rect(g, 10 + i * 30 + (t / 20 % 2) * 4, 56, 12, 1, 0xFFB8E8FF);
            }
            case 3 -> {                                                   // pink room
                rect(g, 0, 0, VW, 66, 0xFFFFD8E8); rect(g, 0, 66, VW, 34, 0xFFE8B8C8);
                for (int i = 0; i < 8; i++) { int hx = 10 + i * 21, hy = 8 + (i % 2) * 14; rect(g, hx, hy, 3, 3, 0xFFFF8AB0); rect(g, hx + 4, hy, 3, 3, 0xFFFF8AB0); rect(g, hx, hy + 2, 7, 3, 0xFFFF8AB0); rect(g, hx + 2, hy + 5, 3, 2, 0xFFFF8AB0); }
                rect(g, 120, 30, 28, 22, 0xFFFFF0F6); rect(g, 122, 32, 24, 18, 0xFFBDE4FF);
            }
            case 4 -> {                                                   // sunset
                for (int i = 0; i < 6; i++) rect(g, 0, i * 11, VW, 11, new int[]{0xFF6A4AA8, 0xFFA85AB0, 0xFFE8708A, 0xFFF0985A, 0xFFF8C060, 0xFFFFE08A}[i]);
                disc(g, 85, 66, 16, 0xFFFFF3B0); rect(g, 0, 66, VW, 34, 0xFF3A2A4A);
            }
            default -> {                                                  // party
                rect(g, 0, 0, VW, VH, 0xFFFFF0B0);
                int[] cc = {0xFFFF8AB0, 0xFF6FB8F0, 0xFF7ED9A0, 0xFFB57BD6, 0xFFFFA24A};
                for (int i = 0; i < 28; i++) rect(g, (i * 53) % VW, (i * 29 + t / 4) % 80, 3, 3, cc[i % 5]);
                for (int i = 0; i < 9; i++) { rect(g, i * 20, 0, 12, 2, cc[i % 5]); rect(g, i * 20 + 3, 2, 6, 4, cc[(i + 2) % 5]); }
                rect(g, 0, 90, VW, 10, 0xFFE8C98A);
            }
        }
    }

    // ---------- screen ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        header(g, f);
        Photo showing = view >= 0 ? album[view] : null;
        scene(g, VX, VY, 1F, showing, showing == null);
        rect(g, VX - 1, VY - 1, VW + 2, 1, 0xFFFFFFFF); rect(g, VX - 1, VY + VH, VW + 2, 1, 0xFFFFFFFF);
        if (flash > 0) rect(g, VX, VY, VW, VH, (flash * 16 << 24) | 0xFFFFFF);
        // the controls
        int x = 184;
        CuteFont.draw(g, f, t("cutemod.photo.bg"), x, 20, MUTED, false);
        btn(g, f, mx, my, x, 31, 16, "<", 0); btn(g, f, mx, my, x + 94, 31, 16, ">", 0);
        center(g, f, t("cutemod.photo.bg." + bg), x + 55, 35, TEXT);
        CuteFont.draw(g, f, t("cutemod.photo.pose"), x, 52, MUTED, false);
        for (int i = 0; i < POSES; i++) btn(g, f, mx, my, x + i * 37, 63, 35, t("cutemod.photo.pose." + i), i == pose ? 1 : 0);
        if (view >= 0) {
            btn(g, f, mx, my, x, 86, 110, t("cutemod.photo.back"), 1);
            btn(g, f, mx, my, x, 106, 110, t("cutemod.photo.delete"), 0);
        } else {
            btn(g, f, mx, my, x, 86, 110, t("cutemod.photo.shoot"), 1);
        }
        // the album
        for (int i = 0; i < SLOTS; i++) {
            int ax = 6 + i * 49, ay = 124;
            rect(g, ax - 1, ay - 1, 47, 30, i == view ? 0xFFFFD84A : 0xFFFFFFFF);
            if (album[i] != null) scene(g, ax, ay, 45F / VW, album[i], false);
            else { rect(g, ax, ay, 45, 28, 0xFFEFE7F6); center(g, f, "+", ax + 22, ay + 10, 0xFFC8BCD8); }
        }
        footer(g, f);
    }

    @Override
    public boolean click(int x, int y, int button) {
        int bx = 184;
        if (in(x, y, bx, 31, 16, 16)) { bg = Math.floorMod(bg - 1, BGS); return true; }
        if (in(x, y, bx + 94, 31, 16, 16)) { bg = Math.floorMod(bg + 1, BGS); return true; }
        for (int i = 0; i < POSES; i++) if (in(x, y, bx + i * 37, 63, 35, 16)) { pose = i; return true; }
        for (int i = 0; i < SLOTS; i++) {
            if (in(x, y, 6 + i * 49, 124, 45, 28) && album[i] != null) { view = view == i ? -1 : i; return true; }
        }
        if (view >= 0) {
            if (in(x, y, bx, 86, 110, 16)) { view = -1; return true; }
            if (in(x, y, bx, 106, 110, 16)) { album[view] = null; view = -1; save(); return true; }
        } else if (in(x, y, bx, 86, 110, 16)) { shoot(); return true; }
        return false;
    }
}
