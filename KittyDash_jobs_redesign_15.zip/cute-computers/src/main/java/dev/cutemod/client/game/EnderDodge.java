package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/** Purple computer: dodge the falling ender particles with the mouse. */
public class EnderDodge extends MiniGame {
    private double px, py;
    private int t;
    private final List<double[]> parts = new ArrayList<>(); // x, y, vy, size
    private final int[][] stars = new int[40][3];

    @Override
    public void reset() {
        score = 0; over = false; t = 0; px = W / 2.0; py = H - 24;
        parts.clear();
        for (int[] s : stars) { s[0] = rnd.nextInt(W); s[1] = rnd.nextInt(H); s[2] = rnd.nextInt(3); }
    }

    @Override
    public void tick() {
        t++;
        if (t % 300 == 150) sound(net.minecraft.sounds.SoundEvents.ENDERMAN_AMBIENT, 0.5F + rnd.nextFloat() * 0.3F, 0.6F);
        px += (Math.max(6, Math.min(W - 6, mx)) - px) * 0.35;
        py += (Math.max(6, Math.min(H - 6, my)) - py) * 0.35;
        double chance = Math.min(0.30, 0.07 + t * 0.00004);
        if (rnd.nextDouble() < chance) {
            int size = 4 + rnd.nextInt(5);
            parts.add(new double[]{rnd.nextInt(W - size), -size, 0.9 + rnd.nextDouble() * 1.3 + Math.min(1.6, t / 2400.0), size});
        }
        for (int i = parts.size() - 1; i >= 0; i--) {
            double[] p = parts.get(i);
            p[1] += p[2];
            if (Math.abs(p[0] + p[3] / 2 - px) < (p[3] / 2 + 3.5) && Math.abs(p[1] + p[3] / 2 - py) < (p[3] / 2 + 4)) {
                over = true; beep(); growl(G_SCREAM);
            }
            if (p[1] > H) parts.remove(i);
        }
        score = t / 30;
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF2A1250, 0xFF0A0418);
        for (int[] s : stars) rect(g, s[0], s[1], 1 + (s[2] == 0 ? 1 : 0), 1, 0x88E8C8FF);
        for (double[] p : parts) {
            int x = (int) p[0], y = (int) p[1], s = (int) p[3];
            rect(g, x + 1, y - 6, s - 2, 6, 0x44C26BFF); // trail
            rect(g, x, y, s, s, 0xFFC26BFF);
            rect(g, x + 1, y + 1, s - 2, s - 2, 0xFFE8B8FF);
        }
        int x = (int) px, y = (int) py;
        rect(g, x - 5, y - 6, 10, 12, 0xFF14101C);
        rect(g, x - 5, y - 6, 10, 1, 0xFF4B2F7A);
        rect(g, x - 4, y - 2, 3, 2, 0xFFE45CFF);
        rect(g, x + 1, y - 2, 3, 2, 0xFFE45CFF);
    }

    @Override
    public String hintKey() { return "cutemod.hint.dodge"; }
}
