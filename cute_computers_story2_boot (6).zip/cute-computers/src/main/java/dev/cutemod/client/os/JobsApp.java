package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.client.game.GameFactory;
import dev.cutemod.client.game.MiniGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * CuteJobs: short one-minute shifts that pay coins. Seven jobs, ranks that raise the pay,
 * and a cooldown after each shift so the coins cannot be farmed forever.
 */
public class JobsApp extends App {
    private static final int BG = 0xFF1B1530, ROW_A = 0xFF231B3D, ROW_B = 0xFF1F1736, HOVER = 0xFF352A58;
    private static final int ACCENT = 0xFFB57BD6, GREEN = 0xFF5BD97A, YELLOW = 0xFFFFD866, MUTED = 0xFF9A90B8;
    private static final int WHITE = 0xFFFFFFFF, RED = 0xFFE5484D, BAR = 18;
    private static final int[] JOB_RGB = {0xFF6AA8F0, 0xFFF0B050, 0xFFF58FB8, 0xFFC98B5A, 0xFF5BBF6A, 0xFFB57BD6, 0xFF8EC3F2};

    private enum Mode { MENU, READY, SHIFT, RESULT }

    private Mode mode = Mode.MENU;
    private String jobId = "";
    private Shift shift;
    private int ready, shiftTick;
    private float resultQuality;
    private int resultPay;
    private boolean rankUp;
    private int noGamesTimer;

    @Override
    public Component title() { return Component.translatable("cutemod.os.jobs"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.jobs"); }

    @Override
    public Component status() {
        if (mode == Mode.SHIFT && shift != null) return Component.literal(shift.status());
        return Component.translatable("cutemod.job.rank." + Jobs.rank());
    }

    @Override
    public void close() { Jobs.save(); }

    // ---------- flow ----------
    private boolean available(Jobs.Job j) {
        if (Jobs.rank() < j.rank() || Jobs.cooldownLeft(j.id()) > 0) return false;
        return !j.id().equals("tester") || !installedGames().isEmpty();
    }

    private static List<String> installedGames() {
        List<String> out = new ArrayList<>();
        for (Library.Game g : Library.GAMES) if (Library.installed(g.id())) out.add(g.id());
        return out;
    }

    private void start(Jobs.Job j) {
        if (!available(j)) {
            if (j.id().equals("tester") && Jobs.rank() >= j.rank() && Jobs.cooldownLeft(j.id()) == 0) noGamesTimer = 180;
            return;
        }
        jobId = j.id();
        shift = switch (jobId) {
            case "typing" -> new Typing();
            case "post" -> new Post();
            case "pets" -> new Pets();
            case "cafe" -> new Cafe();
            case "courier" -> new Courier();
            case "artist" -> new Artist();
            default -> new Tester();
        };
        mode = Mode.READY;
        ready = 150;
    }

    private void finish() {
        float q = Math.max(0f, Math.min(1f, shift.quality()));
        resultQuality = q;
        resultPay = Jobs.pay(jobId, q);
        rankUp = Jobs.finish(jobId, q);
        if (resultPay > 0) Progress.earn(resultPay);
        mode = Mode.RESULT;
    }

    @Override
    public void tick() {
        if (noGamesTimer > 0) noGamesTimer--;
        if (mode == Mode.READY) {
            if (--ready <= 0) { mode = Mode.SHIFT; shiftTick = 0; }
        } else if (mode == Mode.SHIFT && shift != null) {
            shift.tick();
            shiftTick++;
            if (shiftTick >= shift.duration() || shift.over()) finish();
        }
    }

    @Override
    public void mouse(int x, int y) {
        if (shift instanceof Tester tt) tt.mouse(x, y);
    }

    // ---------- drawing helpers ----------
    private static void txt(GuiGraphics g, String s, int x, int y, int argb) { g.drawString(font(), s, x, y, argb, false); }

    private static void ctxt(GuiGraphics g, String s, int cx, int y, int argb) {
        g.drawString(font(), s, cx - font().width(s) / 2, y, argb, false);
    }

    private static void big(GuiGraphics g, String s, int cx, int y, int argb, float scale) {
        g.pose().pushPose();
        g.pose().translate(cx - font().width(s) * scale / 2f, y, 0);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font(), s, 0, 0, argb, false);
        g.pose().popPose();
    }

    private static void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean enabled, boolean hover, int color) {
        rect(g, x, y, w, h, !enabled ? 0xFF3A2F5A : hover ? mix(color & 0xFFFFFF, 0xFFFFFF, 0.25f) : color);
        ctxt(g, label, x + w / 2, y + (h - 8) / 2, enabled ? 0xFF1B1530 : MUTED);
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        rect(g, 0, 0, W, H, BG);
        switch (mode) {
            case MENU -> renderMenu(g, mx, my);
            case READY -> {
                rect(g, 0, 0, W, BAR, 0xFF2A2040);
                txt(g, t("cutemod.job.name." + jobId), 8, 5, WHITE);
                ctxt(g, t("cutemod.job.ready"), W / 2, 44, YELLOW);
                big(g, Integer.toString(ready / 50 + 1), W / 2, 62, WHITE, 3f);
                String how = t("cutemod.job.how." + jobId);
                var lines = font().split(net.minecraft.network.chat.FormattedText.of(how), 260);
                for (int i = 0; i < lines.size() && i < 3; i++) {
                    g.drawString(font(), lines.get(i), (W - font().width(lines.get(i))) / 2, 108 + i * 11, 0xFFD8D0EE, false);
                }
            }
            case SHIFT -> {
                rect(g, 0, 0, W, BAR, 0xFF2A2040);
                txt(g, t("cutemod.job.name." + jobId), 8, 5, WHITE);
                int left = Math.max(0, (shift.duration() - shiftTick + 59) / 60);
                String tm = t("cutemod.job.time", left);
                txt(g, tm, W - 8 - font().width(tm), 5, left <= 10 ? RED : YELLOW);
                int bw = (int) ((W - 120) * (1f - shiftTick / (float) shift.duration()));
                rect(g, 110, 7, W - 120, 4, 0xFF3A2F5A);
                rect(g, 110, 7, Math.max(0, bw), 4, left <= 10 ? RED : GREEN);
                shift.render(g, mx, my);
            }
            case RESULT -> renderResult(g, mx, my);
        }
    }

    private void renderMenu(GuiGraphics g, int mx, int my) {
        int rank = Jobs.rank();
        rect(g, 0, 0, W, BAR, 0xFF2A2040);
        txt(g, t("cutemod.job.rank." + rank) + "  x" + trim(Jobs.RANK_MULT[rank]), 8, 5, YELLOW);
        if (rank + 1 < Jobs.RANK_XP.length) {
            int from = Jobs.RANK_XP[rank], to = Jobs.RANK_XP[rank + 1];
            float f = (Jobs.xp() - from) / (float) (to - from);
            rect(g, 150, 7, 100, 4, 0xFF3A2F5A);
            rect(g, 150, 7, Math.round(100 * Math.max(0f, Math.min(1f, f))), 4, ACCENT);
            txt(g, Jobs.xp() + "/" + to, 256, 5, MUTED);
        } else {
            txt(g, t("cutemod.job.maxrank"), 150, 5, GREEN);
        }
        for (int i = 0; i < Jobs.LIST.size(); i++) {
            Jobs.Job j = Jobs.LIST.get(i);
            int y = BAR + 3 + i * 17;
            boolean hov = in(mx, my, 0, y, W, 16);
            boolean ok = available(j);
            rect(g, 0, y, W, 16, hov && ok ? HOVER : (i % 2 == 0 ? ROW_A : ROW_B));
            rect(g, 4, y + 2, 12, 12, JOB_RGB[i]);
            txt(g, t("cutemod.job.name." + j.id()), 22, y + 4, WHITE);
            int pay = Math.round(j.maxPay() * Jobs.multiplier());
            txt(g, t("cutemod.job.upto", pay), 132, y + 4, MUTED);
            String right;
            int rc;
            if (Jobs.rank() < j.rank()) { right = t("cutemod.job.locked", t("cutemod.job.rank." + j.rank())); rc = RED; }
            else if (Jobs.cooldownLeft(j.id()) > 0) { right = t("cutemod.job.cooldown", Jobs.cooldownLeft(j.id())); rc = MUTED; }
            else if (!ok) { right = t("cutemod.job.nogames"); rc = RED; }
            else { right = t("cutemod.job.start"); rc = GREEN; }
            txt(g, right, W - 6 - font().width(right), y + 4, rc);
        }
        String foot = noGamesTimer > 0 ? t("cutemod.job.nogames_hint") : t("cutemod.job.footer", Jobs.COOLDOWN_SEC, Jobs.totalShifts());
        ctxt(g, foot, W / 2, 150, noGamesTimer > 0 ? RED : MUTED);
    }

    private static String trim(float f) { return f == Math.floor(f) ? Integer.toString((int) f) : Float.toString(f); }

    private void renderResult(GuiGraphics g, int mx, int my) {
        rect(g, 0, 0, W, BAR, 0xFF2A2040);
        txt(g, t("cutemod.job.name." + jobId), 8, 5, WHITE);
        ctxt(g, t("cutemod.job.done"), W / 2, 30, YELLOW);
        ctxt(g, t("cutemod.job.quality", Math.round(resultQuality * 100)), W / 2, 50, WHITE);
        Progress.drawCoin(g, W / 2 - 30, 68);
        big(g, "+" + resultPay, W / 2 + 6, 68, resultPay > 0 ? YELLOW : MUTED, 2f);
        if (rankUp) ctxt(g, t("cutemod.job.rankup", t("cutemod.job.rank." + Jobs.rank())), W / 2, 100, GREEN);
        ctxt(g, t("cutemod.job.cooldown_note", Jobs.COOLDOWN_SEC), W / 2, 114, MUTED);
        boolean hov = in(mx, my, 100, 132, 100, 18);
        button(g, 100, 132, 100, 18, t("cutemod.job.back"), true, hov, ACCENT);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int b) {
        switch (mode) {
            case MENU -> {
                for (int i = 0; i < Jobs.LIST.size(); i++) {
                    if (in(x, y, 0, BAR + 3 + i * 17, W, 16)) { start(Jobs.LIST.get(i)); return true; }
                }
                return true;
            }
            case RESULT -> {
                if (in(x, y, 100, 132, 100, 18)) { mode = Mode.MENU; shift = null; }
                return true;
            }
            case SHIFT -> { return shift != null && shift.click(x, y); }
            default -> { return true; }
        }
    }

    @Override
    public boolean drag(int x, int y, int b) {
        return mode == Mode.SHIFT && shift != null && shift.drag(x, y);
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (mode == Mode.RESULT && (keyCode == 257 || keyCode == 32)) { mode = Mode.MENU; shift = null; return true; }
        if (mode == Mode.SHIFT && shift != null) return shift.key(keyCode);
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        return mode == Mode.SHIFT && shift != null && shift.typed(c);
    }

    // ======================================================================
    //                               the shifts
    // ======================================================================
    private abstract class Shift {
        final Random rnd = new Random();
        abstract int duration();
        void tick() {}
        abstract void render(GuiGraphics g, int mx, int my);
        boolean click(int x, int y) { return false; }
        boolean drag(int x, int y) { return false; }
        boolean key(int k) { return false; }
        boolean typed(char c) { return false; }
        boolean over() { return false; }
        abstract float quality();
        abstract String status();
    }

    // ---------- typing ----------
    private final class Typing extends Shift {
        private final String[] words = {"cookie", "panda", "creeper", "honey", "pixel", "cat", "fox", "bee", "penguin", "diamond",
                "pickaxe", "candle", "forest", "cloud", "kitten", "button", "screen", "music", "garden", "castle", "rocket",
                "apple", "bamboo", "sunset", "meadow", "pillow", "puzzle", "ladybug", "lantern", "wizard"};
        private String word;
        private int pos, done, errors, flash;

        Typing() { word = words[rnd.nextInt(words.length)]; }

        @Override int duration() { return 3600; }

        @Override void tick() { if (flash > 0) flash--; }

        @Override boolean typed(char c) {
            if (Character.toLowerCase(c) == word.charAt(pos)) {
                pos++;
                if (pos >= word.length()) {
                    done++;
                    String w;
                    do { w = words[rnd.nextInt(words.length)]; } while (w.equals(word));
                    word = w;
                    pos = 0;
                }
            } else {
                errors++;
                flash = 10;
                pos = 0;                                   // a typo means starting the word again
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            rect(g, 20, 50, W - 40, 50, flash > 0 ? 0xFF4A2A3A : 0xFF2A2040);
            float s = 2.5f;
            int total = (int) (font().width(word) * s);
            int x = (W - total) / 2;
            g.pose().pushPose();
            g.pose().translate(x, 66, 0);
            g.pose().scale(s, s, 1f);
            String a = word.substring(0, pos), b = word.substring(pos);
            g.drawString(font(), a, 0, 0, GREEN, false);
            g.drawString(font(), b, font().width(a), 0, WHITE, false);
            g.pose().popPose();
            ctxt(g, t("cutemod.job.typed", done), W / 2, 115, YELLOW);
            ctxt(g, t("cutemod.job.mistakes", errors), W / 2, 128, MUTED);
        }

        @Override float quality() { return Math.max(0f, done - errors * 0.3f) / 18f; }
        @Override String status() { return t("cutemod.job.typed", done); }
    }

    // ---------- postman ----------
    private final class Post extends Shift {
        private final int[] cols = {RED, 0xFF2F7FD6, 0xFF5BBF6A, 0xFFF3D46A};
        private int cur, age, fall = 110, ok, miss, flash;

        Post() { cur = rnd.nextInt(4); }

        @Override int duration() { return 3600; }

        private void next() { cur = rnd.nextInt(4); age = 0; fall = Math.max(42, 110 - ok * 5); }

        private void choose(int i) {
            if (i == cur) { ok++; flash = 8; } else { miss++; flash = -8; }
            next();
        }

        @Override void tick() {
            if (flash > 0) flash--; else if (flash < 0) flash++;
            if (++age >= fall) { miss++; flash = -8; next(); }
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 4; i++) if (in(x, y, 6 + i * 72, 120, 66, 38)) { choose(i); return true; }
            return true;
        }

        @Override boolean key(int k) {
            if (k >= 49 && k <= 52) { choose(k - 49); return true; }
            return false;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            int ly = 26 + Math.round(age / (float) fall * 80);
            rect(g, 136, ly, 28, 18, 0xFFFFF6E0);
            rect(g, 136, ly, 28, 2, 0xFFE0D0A8);
            rect(g, 154, ly + 4, 8, 8, cols[cur]);
            for (int i = 0; i < 4; i++) {
                int x = 6 + i * 72;
                boolean hov = in(mx, my, x, 120, 66, 38);
                rect(g, x, 120, 66, 38, hov ? mix(cols[i] & 0xFFFFFF, 0xFFFFFF, 0.25f) : cols[i]);
                rect(g, x + 14, 126, 38, 4, 0x55000000);
                ctxt(g, Integer.toString(i + 1), x + 33, 140, 0xFF1B1530);
            }
            if (flash != 0) rect(g, 0, BAR, W, 2, flash > 0 ? GREEN : RED);
            ctxt(g, t("cutemod.job.delivered", ok), W / 2, 106, MUTED);
        }

        @Override float quality() { return Math.max(0f, ok - miss) / 24f; }
        @Override String status() { return t("cutemod.job.delivered", ok); }
    }

    // ---------- cafe ----------
    private final class Cafe extends Shift {
        private final int[] cols = {0xFFFFFFFF, 0xFF8A5A3A, 0xFFF3E6D0, 0xFFF3D46A, 0xFFF58FB8};
        private int[] order = new int[4];
        private int len, prog, patience, maxPat, served, miss, flash;

        Cafe() { newOrder(); }

        @Override int duration() { return 3600; }

        private void newOrder() {
            len = 4;
            order[0] = 0;
            for (int i = 1; i < len; i++) order[i] = 1 + rnd.nextInt(4);
            prog = 0;
            maxPat = Math.max(180, 330 - served * 8);
            patience = maxPat;
        }

        @Override void tick() {
            if (flash > 0) flash--;
            if (--patience <= 0) { miss++; newOrder(); }
        }

        private void press(int i) {
            if (i == order[prog]) {
                if (++prog >= len) { served++; newOrder(); }
            } else {
                prog = 0;
                flash = 12;
            }
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 5; i++) if (in(x, y, 6 + i * 58, 128, 54, 30)) { press(i); return true; }
            return true;
        }

        @Override boolean key(int k) {
            if (k >= 49 && k <= 53) { press(k - 49); return true; }
            return false;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            rect(g, 40, 26, W - 80, 86, flash > 0 ? 0xFF4A2A3A : 0xFFFFF6E0);
            rect(g, 40, 26, W - 80, 10, 0xFFE5B8C8);
            ctxt(g, t("cutemod.job.order", served + 1), W / 2, 27, 0xFF3A2A3A);
            for (int i = 0; i < len; i++) {
                int x = 56 + i * 48, y = 44;
                boolean done = i < prog;
                rect(g, x, y, 40, 24, done ? 0xFFD8D0C0 : cols[order[i]]);
                rect(g, x, y, 40, 24, 0x22000000);
                rect(g, x + 2, y + 2, 36, 20, done ? 0xFFC8C0B0 : cols[order[i]]);
                ctxt(g, done ? "OK" : Integer.toString(order[i] + 1), x + 20, y + 8, 0xFF3A2A3A);
            }
            float f = Math.max(0f, patience / (float) maxPat);
            rect(g, 56, 82, W - 112, 6, 0xFFD8D0C0);
            rect(g, 56, 82, Math.round((W - 112) * Math.min(1f, f)), 6, f > 0.35f ? GREEN : RED);
            ctxt(g, t("cutemod.job.served", served), W / 2, 96, 0xFF3A2A3A);
            for (int i = 0; i < 5; i++) {
                int x = 6 + i * 58;
                boolean hov = in(mx, my, x, 128, 54, 30);
                rect(g, x, 128, 54, 30, hov ? 0xFF4A3A70 : 0xFF3A2F5A);
                rect(g, x + 4, 132, 46, 8, cols[i]);
                ctxt(g, (i + 1) + " " + t("cutemod.job.ing." + i), x + 27, 146, WHITE);
            }
        }

        @Override float quality() { return Math.max(0f, served - miss * 0.6f) / 12f; }
        @Override String status() { return t("cutemod.job.served", served); }
    }

    // ---------- courier ----------
    private final class Courier extends Shift {
        private static final int COLS = 15, ROWS = 7, CELL = 20, OY = 22;
        private final boolean[][] wall = new boolean[COLS][ROWS];
        private final int[] carX = {3, 11};
        private final int[] carRow = {2, 4};
        private int px = 1, py = 3, tx, ty, delivered, stun, carTick;
        private boolean carrying;

        Courier() {
            for (int n = 0; n < 16; n++) {
                int x = rnd.nextInt(COLS), y = rnd.nextInt(ROWS);
                if (y == 2 || y == 4 || (x == 1 && y == 3)) continue;
                wall[x][y] = true;
            }
            spot();
        }

        @Override int duration() { return 3600; }

        private void spot() {
            for (int tries = 0; tries < 60; tries++) {
                int x = rnd.nextInt(COLS), y = rnd.nextInt(ROWS);
                if (wall[x][y] || y == 2 || y == 4 || (x == px && y == py)) continue;
                if (Math.abs(x - px) + Math.abs(y - py) < 5) continue;
                tx = x;
                ty = y;
                return;
            }
            tx = COLS - 2;
            ty = 0;
            wall[tx][ty] = false;
        }

        @Override void tick() {
            if (stun > 0) stun--;
            if (++carTick >= 15) {
                carTick = 0;
                for (int i = 0; i < 2; i++) carX[i] = (carX[i] + (i == 0 ? 1 : COLS - 1)) % COLS;
            }
            hitCheck();
        }

        private void hitCheck() {
            for (int i = 0; i < 2; i++) {
                if (stun == 0 && py == carRow[i] && px == carX[i]) stun = 100;
            }
        }

        @Override boolean key(int k) {
            if (stun > 0) return true;
            int dx = 0, dy = 0;
            switch (k) {
                case 262, 68 -> dx = 1;
                case 263, 65 -> dx = -1;
                case 264, 83 -> dy = 1;
                case 265, 87 -> dy = -1;
                default -> { return false; }
            }
            int nx = px + dx, ny = py + dy;
            if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS || wall[nx][ny]) return true;
            px = nx;
            py = ny;
            hitCheck();
            if (px == tx && py == ty) {
                if (!carrying) { carrying = true; tx = -1; ty = -1; spotDrop(); }
                else { delivered++; carrying = false; spot(); }
            }
            return true;
        }

        /** Chooses the house after a parcel was picked up. */
        private void spotDrop() { spot(); }

        @Override void render(GuiGraphics g, int mx, int my) {
            for (int x = 0; x < COLS; x++) {
                for (int y = 0; y < ROWS; y++) {
                    int c = (y == 2 || y == 4) ? 0xFF4A4A5A : ((x + y) % 2 == 0 ? 0xFF4F9A58 : 0xFF58A862);
                    rect(g, x * CELL, OY + y * CELL, CELL, CELL, c);
                    if (y == 2 || y == 4) rect(g, x * CELL + 4, OY + y * CELL + 9, 12, 2, 0xFFE0D8A0);
                    if (wall[x][y]) {
                        rect(g, x * CELL + 8, OY + y * CELL + 12, 4, 7, 0xFF6A4A2A);
                        disc(g, x * CELL + 10, OY + y * CELL + 8, 7, 0xFF2F7A3A);
                    }
                }
            }
            // goal: a parcel (to pick up) or a house (to deliver to)
            int gx = tx * CELL, gy = OY + ty * CELL;
            if (tx >= 0) {
                if (!carrying) {
                    rect(g, gx + 3, gy + 5, 14, 12, YELLOW);
                    rect(g, gx + 9, gy + 5, 2, 12, 0xFFB98A10);
                } else {
                    rect(g, gx + 3, gy + 8, 14, 10, 0xFFF3E6D0);
                    rect(g, gx + 1, gy + 4, 18, 5, RED);
                    rect(g, gx + 8, gy + 12, 4, 6, 0xFF8A5A3A);
                }
            }
            for (int i = 0; i < 2; i++) {
                int cx = carX[i] * CELL, cy = OY + carRow[i] * CELL;
                rect(g, cx + 1, cy + 4, 18, 12, i == 0 ? 0xFFE5484D : 0xFF2F7FD6);
                rect(g, cx + 5, cy + 6, 6, 4, 0xFFBFE6F8);
            }
            int ppx = px * CELL, ppy = OY + py * CELL;
            boolean blink = stun > 0 && (stun / 6) % 2 == 0;
            if (!blink) {
                disc(g, ppx + 10, ppy + 10, 7, 0xFFFFF3B0);
                rect(g, ppx + 7, ppy + 8, 2, 2, 0xFF3A2A3A);
                rect(g, ppx + 11, ppy + 8, 2, 2, 0xFF3A2A3A);
                if (carrying) rect(g, ppx + 5, ppy - 3, 10, 6, YELLOW);
            }
        }

        @Override float quality() { return delivered / 10f; }
        @Override String status() { return t("cutemod.job.delivered", delivered); }
    }

    // ---------- artist ----------
    private final class Artist extends Shift {
        private static final int GW = 8, GH = 6, CELL = 14;
        private final int[] pal = {0xFFFFFFFF, RED, 0xFF2F7FD6, 0xFFF3D46A, 0xFF5BBF6A};
        private final int[] target = new int[GW * GH], canvas = new int[GW * GH];
        private int sel = 1, sent;
        private float total;

        Artist() { gen(); }

        @Override int duration() { return 3600; }

        private void gen() {
            java.util.Arrays.fill(target, 0);
            java.util.Arrays.fill(canvas, 0);
            for (int n = 0; n < 4; n++) {
                int c = 1 + rnd.nextInt(4), w = 2 + rnd.nextInt(3), h = 2 + rnd.nextInt(3);
                int x0 = rnd.nextInt(GW - w + 1), y0 = rnd.nextInt(GH - h + 1);
                for (int x = x0; x < x0 + w; x++) for (int y = y0; y < y0 + h; y++) target[y * GW + x] = c;
            }
        }

        private boolean paint(int x, int y) {
            int cx = (x - 174) / CELL, cy = (y - 30) / CELL;
            if (x >= 174 && y >= 30 && cx < GW && cy < GH) { canvas[cy * GW + cx] = sel; return true; }
            return false;
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 5; i++) if (in(x, y, 14 + i * 30, 124, 26, 18)) { sel = i; return true; }
            if (in(x, y, 196, 124, 96, 18)) {
                int ok = 0;
                for (int i = 0; i < target.length; i++) if (target[i] == canvas[i]) ok++;
                float acc = ok / (float) target.length;
                total += acc * acc;
                sent++;
                gen();
                return true;
            }
            paint(x, y);
            return true;
        }

        @Override boolean drag(int x, int y) { return paint(x, y); }

        @Override void render(GuiGraphics g, int mx, int my) {
            ctxt(g, t("cutemod.job.target"), 14 + GW * CELL / 2, 20, MUTED);
            ctxt(g, t("cutemod.job.canvas"), 174 + GW * CELL / 2, 20, MUTED);
            for (int x = 0; x < GW; x++) {
                for (int y = 0; y < GH; y++) {
                    rect(g, 14 + x * CELL, 30 + y * CELL, CELL - 1, CELL - 1, pal[target[y * GW + x]]);
                    rect(g, 174 + x * CELL, 30 + y * CELL, CELL - 1, CELL - 1, pal[canvas[y * GW + x]]);
                }
            }
            ctxt(g, "->", 150, 66, MUTED);
            for (int i = 0; i < 5; i++) {
                int x = 14 + i * 30;
                if (i == sel) rect(g, x - 2, 122, 30, 22, WHITE);
                rect(g, x, 124, 26, 18, pal[i]);
            }
            boolean hov = in(mx, my, 196, 124, 96, 18);
            button(g, 196, 124, 96, 18, t("cutemod.job.send"), true, hov, GREEN);
            ctxt(g, t("cutemod.job.sent", sent), W / 2, 150, MUTED);
        }

        @Override float quality() { return Math.min(1f, total / 3.3f); }
        @Override String status() { return t("cutemod.job.sent", sent); }
    }

    // ---------- pet sitter ----------
    private final class Pets extends Shift {
        private final int[] pcol = {0xFFF5B06B, 0xFFB98A60, 0xFFF4F0F0};
        private final int[] ncol = {0xFFE59A6A, 0xFF5BBF6A, 0xFF6AA8F0};
        private final int[] need = {-1, -1, -1}, timer = new int[3], wait = {20, 60, 100};
        private int sel = -1, served, miss, wrong;

        @Override int duration() { return 3600; }

        @Override void tick() {
            for (int i = 0; i < 3; i++) {
                if (need[i] < 0) {
                    if (--wait[i] <= 0) { need[i] = rnd.nextInt(3); timer[i] = 240; }
                } else if (--timer[i] <= 0) {
                    miss++;
                    need[i] = -1;
                    wait[i] = 25 + rnd.nextInt(40);
                    if (sel == i) sel = -1;
                }
            }
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 3; i++) if (in(x, y, 50 + i * 100 - 36, 34, 72, 76)) { sel = i; return true; }
            for (int j = 0; j < 3; j++) {
                if (in(x, y, 14 + j * 94, 124, 86, 28)) {
                    if (sel >= 0 && need[sel] >= 0) {
                        if (need[sel] == j) {
                            served++;
                            need[sel] = -1;
                            wait[sel] = 25 + rnd.nextInt(40);
                            sel = -1;
                        } else wrong++;
                    }
                    return true;
                }
            }
            return true;
        }

        @Override boolean key(int k) {
            if (k >= 49 && k <= 51) return click(14 + (k - 49) * 94 + 1, 125);
            return false;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            for (int i = 0; i < 3; i++) {
                int cx = 50 + i * 100;
                if (i == sel) rect(g, cx - 36, 34, 72, 76, 0xFF352A58);
                disc(g, cx - 10, 62, 5, pcol[i]);
                disc(g, cx + 10, 62, 5, pcol[i]);
                disc(g, cx, 78, 15, pcol[i]);
                rect(g, cx - 6, 76, 2, 3, 0xFF3A2A3A);
                rect(g, cx + 4, 76, 2, 3, 0xFF3A2A3A);
                rect(g, cx - 2, 82, 4, 2, 0xFF3A2A3A);
                if (need[i] >= 0) {
                    disc(g, cx, 44, 9, ncol[need[i]]);
                    ctxt(g, Integer.toString(need[i] + 1), cx, 41, 0xFF1B1530);
                    float f = Math.max(0f, timer[i] / 240f);
                    rect(g, cx - 24, 100, 48, 4, 0xFF3A2F5A);
                    rect(g, cx - 24, 100, Math.round(48 * f), 4, f > 0.35f ? GREEN : RED);
                }
            }
            for (int j = 0; j < 3; j++) {
                int x = 14 + j * 94;
                boolean hov = in(mx, my, x, 124, 86, 28);
                rect(g, x, 124, 86, 28, hov ? 0xFF4A3A70 : 0xFF3A2F5A);
                rect(g, x + 4, 128, 78, 4, ncol[j]);
                ctxt(g, (j + 1) + " " + t("cutemod.job.need." + j), x + 43, 138, WHITE);
            }
            ctxt(g, t("cutemod.job.cared", served), W / 2, 112, MUTED);
        }

        @Override float quality() { return Math.max(0f, served - miss * 0.6f - wrong * 0.4f) / 18f; }
        @Override String status() { return t("cutemod.job.cared", served); }
    }

    // ---------- game tester ----------
    private final class Tester extends Shift {
        private static final int OX = (W - MiniGame.W) / 2, OY = 22;
        private final String gameId;
        private final MiniGame game;
        private int endDelay;

        Tester() {
            List<String> ids = installedGames();
            gameId = ids.get(rnd.nextInt(ids.size()));
            ComputerColor c = null;
            for (ComputerColor cc : ComputerColor.values()) if (cc.id.equals(gameId)) c = cc;
            game = c != null ? GameFactory.create(c) : GameFactory.createExtra(gameId);
            game.reset();
        }

        void mouse(int x, int y) { game.setMouse(x - OX, y - OY); }

        @Override int duration() { return 3600; }

        @Override void tick() {
            if (!game.over) game.tick(); else endDelay++;
        }

        @Override boolean over() { return game.over && endDelay > 90; }

        @Override void render(GuiGraphics g, int mx, int my) {
            rect(g, OX - 2, OY - 2, MiniGame.W + 4, MiniGame.H + 4, 0xFF3A2A4A);
            g.enableScissor(shell.absX() + OX, shell.absY() + OY, shell.absX() + OX + MiniGame.W, shell.absY() + OY + MiniGame.H);
            g.pose().pushPose();
            g.pose().translate(OX, OY, 0);
            game.render(g);
            g.pose().popPose();
            g.disableScissor();
        }

        @Override boolean click(int x, int y) {
            if (game.over) return true;
            int lx = x - OX, ly = y - OY;
            if (in(lx, ly, 0, 0, MiniGame.W, MiniGame.H)) game.click(lx, ly, 0);
            return true;
        }

        @Override boolean key(int k) { return !game.over && game.key(k); }

        @Override float quality() { return Progress.coinsFor(gameId, game.score) / 16f; }
        @Override String status() { return t("cutemod.job.testing", Library.name(gameId)) + "  " + game.score; }
    }
}
