package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.nio.file.Files;
import java.nio.file.Path;

/** Desktop wallpapers. The chosen one is remembered in cutemod_wallpaper.txt. */
public final class Wallpaper {
    public static final int COUNT = 12; // 0-5 are free (Settings), 6-11 come from the shop
    public static final int BASE = 6;
    private static int index;
    private static int gen = -1;

    private Wallpaper() {}

    /** The chosen wallpaper is saved on the server. */
    public static int get() {
        if (gen != Store.gen()) {
            gen = Store.gen();
            index = 0;
            try {
                String s = Store.read("wallpaper");
                if (s != null) index = Math.floorMod(Integer.parseInt(s.trim()), COUNT);
            } catch (Exception ignored) {
            }
        }
        return index;
    }

    public static void set(int i) {
        get();
        index = Math.floorMod(i, COUNT);
        Store.write("wallpaper", Integer.toString(index));
    }

    private static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** Draws wallpaper number idx inside the box x,y,w,h (everything stays inside the box). */
    public static void draw(GuiGraphics g, int x, int y, int w, int h, int body, int idx) {
        switch (idx) {
            case 1 -> { // sky
                g.fillGradient(x, y, x + w, y + h, 0xFF9ED8FF, 0xFFEAF7FF);
                for (int i = 0; i < 3; i++) {
                    int cx = x + (i * 97 + 20) % Math.max(1, w - 40), cy = y + 6 + i * (h / 4);
                    g.fill(cx, cy + 3, cx + 30, cy + 11, 0xCCFFFFFF);
                    g.fill(cx + 6, cy, cx + 22, cy + 5, 0xCCFFFFFF);
                }
            }
            case 2 -> { // mint
                g.fillGradient(x, y, x + w, y + h, 0xFFD6F5DE, 0xFF8FD39A);
                for (int i = 0; i < 14; i++) {
                    int dx = x + (i * 61 + 17) % Math.max(1, w - 3), dy = y + (i * 37 + 9) % Math.max(1, h - 3);
                    g.fill(dx, dy, dx + 3, dy + 3, 0x66FFFFFF);
                }
            }
            case 3 -> { // sunset
                g.fillGradient(x, y, x + w, y + h, 0xFFFFC38A, 0xFFE5668A);
                disc(g, x + w * 3 / 4, y + h * 2 / 3, Math.min(w, h) / 6, 0xFFFFF0B0);
            }
            case 4 -> { // night
                g.fillGradient(x, y, x + w, y + h, 0xFF1B1840, 0xFF4A3A66);
                for (int i = 0; i < 24; i++) {
                    int sx = x + (i * 53 + 11) % Math.max(1, w - 2), sy = y + (i * 29 + 5) % Math.max(1, h - 2);
                    int s = i % 5 == 0 ? 2 : 1;
                    g.fill(sx, sy, sx + s, sy + s, 0xCCFFFFFF);
                }
                disc(g, x + w / 5, y + h / 4, Math.min(w, h) / 9, 0xFFFFF0C0);
            }
            case 5 -> { // candy stripes
                for (int r = 0; r * 8 < h; r++) {
                    g.fill(x, y + r * 8, x + w, Math.min(y + h, y + r * 8 + 8), r % 2 == 0 ? 0xFFFFD6E8 : 0xFFFFFFFF);
                }
            }
            case 6 -> { // starry space
                g.fillGradient(x, y, x + w, y + h, 0xFF0B0F2E, 0xFF2A2A6A);
                for (int i = 0; i < 30; i++) {
                    int sx = x + (i * 47 + 13) % Math.max(1, w - 2), sy = y + (i * 31 + 7) % Math.max(1, h - 2);
                    g.fill(sx, sy, sx + (i % 7 == 0 ? 2 : 1), sy + (i % 7 == 0 ? 2 : 1), 0xFFFFFFFF);
                }
                for (int k = 0; k < Math.min(w, h) / 3; k++) g.fill(x + w * 3 / 4 - k, y + h / 5 + k / 2, x + w * 3 / 4 - k + 1, y + h / 5 + k / 2 + 1, 0xAAFFFFFF);
            }
            case 7 -> { // hearts
                g.fillGradient(x, y, x + w, y + h, 0xFFFFE0EC, 0xFFFFB3CF);
                for (int i = 0; i < 18; i++) {
                    int hx = x + (i * 53 + 9) % Math.max(1, w - 8), hy = y + (i * 29 + 4) % Math.max(1, h - 8);
                    int c = i % 2 == 0 ? 0xAAFF5C93 : 0xAAFFFFFF;
                    g.fill(hx, hy + 1, hx + 5, hy + 3, c);
                    g.fill(hx + 1, hy, hx + 2, hy + 1, c);
                    g.fill(hx + 3, hy, hx + 4, hy + 1, c);
                    g.fill(hx + 1, hy + 3, hx + 4, hy + 4, c);
                    g.fill(hx + 2, hy + 4, hx + 3, hy + 5, c);
                }
            }
            case 8 -> { // honeycomb
                g.fillGradient(x, y, x + w, y + h, 0xFFFFE9A0, 0xFFFFC832);
                for (int r = 0; r * 7 < h; r++) {
                    for (int c = 0; c * 12 < w; c++) {
                        int hx = x + c * 12 + (r % 2) * 6, hy = y + r * 7;
                        if (hx + 7 > x + w || hy + 5 > y + h) continue;
                        g.fill(hx + 1, hy, hx + 6, hy + 1, 0x66B98A10);
                        g.fill(hx, hy + 1, hx + 7, hy + 4, 0x33B98A10);
                        g.fill(hx + 1, hy + 4, hx + 6, hy + 5, 0x66B98A10);
                    }
                }
            }
            case 9 -> { // rainbow
                int[] rc = {0xFFFF8A8A, 0xFFFFB27A, 0xFFFFE27A, 0xFF9AE6A0, 0xFF8AD0FF, 0xFFA89AFF, 0xFFE59AFF};
                for (int i = 0; i < 7; i++) g.fill(x, y + i * h / 7, x + w, y + (i + 1) * h / 7, rc[i]);
                g.fill(x + w / 8, y + h / 6, x + w / 8 + Math.max(4, w / 5), y + h / 6 + Math.max(2, h / 12), 0xCCFFFFFF);
                g.fill(x + w * 2 / 3, y + h * 3 / 5, x + w * 2 / 3 + Math.max(4, w / 4), y + h * 3 / 5 + Math.max(2, h / 12), 0xCCFFFFFF);
            }
            case 10 -> { // ocean
                g.fillGradient(x, y, x + w, y + h, 0xFF7FD8FF, 0xFF1E5FA8);
                for (int r = 6; r < h; r += 8) {
                    int off = ((r / 8) % 2) * 5;
                    for (int c = 0; c + off + 6 <= w; c += 10) g.fill(x + c + off, y + r, x + c + off + 6, y + r + 1, 0x55FFFFFF);
                }
                for (int i = 0; i < 6; i++) {
                    int bx = x + (i * 41 + 9) % Math.max(1, w - 3), by = y + (i * 27 + 5) % Math.max(1, h - 3);
                    g.fill(bx, by, bx + 2, by + 2, 0x88FFFFFF);
                }
            }
            case 11 -> { // night city
                g.fillGradient(x, y, x + w, y + h, 0xFF2A1A4A, 0xFFE56A8A);
                for (int b = 0; b * 12 < w; b++) {
                    int bx = x + b * 12, bh = h / 3 + (b * 17) % Math.max(1, h / 3);
                    int bw = Math.min(10, x + w - bx);
                    g.fill(bx, y + h - bh, bx + bw, y + h, 0xFF14122E);
                    for (int wy = y + h - bh + 3; wy < y + h - 3; wy += 5) {
                        for (int wx = bx + 2; wx + 2 <= bx + bw - 1; wx += 4) {
                            if (((wx + wy + b) % 3) == 0) g.fill(wx, wy, wx + 2, wy + 2, 0xFFFFE680);
                        }
                    }
                }
            }
            default -> { // the computer's own color
                g.fillGradient(x, y, x + w, y + h, App.mix(body, 0xFFFFFF, 0.6f), App.mix(body, 0x3A2A4A, 0.35f));
                for (int i = 0; i < 14; i++) {
                    int dx = x + (i * 61 + 17) % Math.max(1, w - 3), dy = y + (i * 37 + 9) % Math.max(1, h - 3);
                    g.fill(dx, dy, dx + 3, dy + 3, 0x30FFFFFF);
                }
            }
        }
    }
}
