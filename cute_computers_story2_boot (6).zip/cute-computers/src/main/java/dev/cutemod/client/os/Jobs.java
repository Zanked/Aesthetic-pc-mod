package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Jobs of CuteJobs: ranks, shift counts and cooldowns. Saved on the server (via Store).
 * The coins themselves are handled by {@link Progress}.
 */
public final class Jobs {
    private Jobs() {}

    /** A job: id, the rank needed, the best pay (coins at rank 0, quality 100%). */
    public record Job(String id, int rank, int maxPay) {}

    public static final List<Job> LIST = List.of(
            new Job("typing", 0, 14),
            new Job("post", 0, 16),
            new Job("pets", 0, 15),
            new Job("cafe", 1, 18),
            new Job("courier", 1, 20),
            new Job("artist", 2, 20),
            new Job("tester", 2, 18));

    /** Number of experience points needed for each rank. */
    public static final int[] RANK_XP = {0, 8, 24, 55};
    public static final float[] RANK_MULT = {1.0f, 1.25f, 1.5f, 2.0f};
    public static final int COOLDOWN_SEC = 180;

    private static boolean loaded, dirty;
    private static int xp;
    private static final Map<String, Integer> shifts = new HashMap<>();
    private static final Map<String, Long> until = new HashMap<>();

    public static Job job(String id) {
        for (Job j : LIST) if (j.id().equals(id)) return j;
        return LIST.get(0);
    }

    private static int gen = -1;

    private static void ensure() {
        if (loaded && gen == Store.gen()) return;
        loaded = true;
        gen = Store.gen();
        dirty = false;
        xp = 0; shifts.clear(); until.clear();
        try {
            Properties pr = Store.readProps("jobs");
            if (pr == null) return;
            xp = Integer.parseInt(pr.getProperty("xp", "0").trim());
            for (String k : pr.stringPropertyNames()) {
                if (k.startsWith("shifts.")) shifts.put(k.substring(7), Integer.parseInt(pr.getProperty(k).trim()));
                else if (k.startsWith("until.")) until.put(k.substring(6), Long.parseLong(pr.getProperty(k).trim()));
            }
        } catch (Exception ignored) {
        }
    }

    /** Saved on the server (through {@link Store}). */
    public static void save() {
        if (!loaded || !dirty || gen != Store.gen()) return;
        try {
            Properties pr = new Properties();
            pr.setProperty("xp", Integer.toString(xp));
            shifts.forEach((k, v) -> pr.setProperty("shifts." + k, Integer.toString(v)));
            until.forEach((k, v) -> pr.setProperty("until." + k, Long.toString(v)));
            Store.writeProps("jobs", pr);
            dirty = false;
        } catch (Exception ignored) {
        }
    }

    public static int xp() { ensure(); return xp; }

    public static int rank() {
        ensure();
        int r = 0;
        for (int i = 0; i < RANK_XP.length; i++) if (xp >= RANK_XP[i]) r = i;
        return r;
    }

    public static float multiplier() { return RANK_MULT[rank()]; }

    public static int shifts(String id) { ensure(); return shifts.getOrDefault(id, 0); }

    public static int totalShifts() {
        ensure();
        int n = 0;
        for (int v : shifts.values()) n += v;
        return n;
    }

    /** Seconds left until the job can be worked again (0 = free). */
    public static int cooldownLeft(String id) {
        ensure();
        long left = until.getOrDefault(id, 0L) - System.currentTimeMillis();
        return left <= 0 ? 0 : (int) ((left + 999) / 1000);
    }

    public static int pay(String id, float quality) {
        float q = Math.max(0f, Math.min(1f, quality));
        if (q < 0.2f) return 0;                  // a sloppy shift is not paid at all
        return Math.round(job(id).maxPay() * q * multiplier());
    }

    /** Finishes a shift. Returns true if the player reached a new rank. */
    public static boolean finish(String id, float quality) {
        ensure();
        int before = rank();
        xp += 1 + (quality >= 0.8f ? 1 : 0);
        shifts.merge(id, 1, Integer::sum);
        until.put(id, System.currentTimeMillis() + COOLDOWN_SEC * 1000L);
        dirty = true;
        save();
        return rank() > before;
    }
}
