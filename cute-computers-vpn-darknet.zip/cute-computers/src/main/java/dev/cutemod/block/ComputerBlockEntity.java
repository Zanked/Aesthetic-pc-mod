package dev.cutemod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Stores the high score of this particular computer (and who set it) and its own build (processor, board, memory, video card...). */
public class ComputerBlockEntity extends BlockEntity {
    public static final int MAX_SCORE = 100_000;

    private int highScore = 0;
    private String holder = "";
    private String build = "";          // the saved text of the Build (empty = the stock PC)

    public ComputerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.COMPUTER.get(), pos, state);
    }

    public int getHighScore() { return highScore; }
    public String getHolder() { return holder; }

    /** The parts inside this computer. */
    public dev.cutemod.data.Build build() {
        if (build.isEmpty() && getBlockState().getBlock() instanceof LaptopBlock lb) return lb.line().build();      // a laptop starts as it was sold
        return dev.cutemod.data.Build.parse(build);
    }

    /** A laptop keeps its upgraded memory and drive when it is picked up (the loot table copies custom_data) and when it is put down again. */
    @Override
    protected void collectImplicitComponents(net.minecraft.core.component.DataComponentMap.Builder components) {
        super.collectImplicitComponents(components);
        if (build.isEmpty()) return;
        CompoundTag tag = new CompoundTag();
        tag.putString("Build", build);
        components.set(net.minecraft.core.component.DataComponents.CUSTOM_DATA, net.minecraft.world.item.component.CustomData.of(tag));
    }

    @Override
    protected void applyImplicitComponents(BlockEntity.DataComponentInput input) {
        super.applyImplicitComponents(input);
        var cd = input.get(net.minecraft.core.component.DataComponents.CUSTOM_DATA);
        if (cd != null && cd.contains("Build")) build = cd.copyTag().getString("Build");
    }

    /** Server side: keep a new build and tell the clients. */
    public void setBuild(dev.cutemod.data.Build b) {
        build = b.write();
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    /** Server side. Returns true if it was a new record. */
    public boolean submitScore(int score, String playerName) {
        if (score <= highScore || score > MAX_SCORE) return false;
        highScore = score;
        holder = playerName;
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        return true;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("HighScore", highScore);
        tag.putString("Holder", holder);
        if (!build.isEmpty()) tag.putString("Build", build);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        highScore = tag.getInt("HighScore");
        holder = tag.getString("Holder");
        build = tag.getString("Build");
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag, registries);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
