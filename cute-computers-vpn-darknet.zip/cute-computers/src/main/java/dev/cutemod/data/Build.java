package dev.cutemod.data;

/**
 * The build of ONE computer (a computer block keeps its own; a laptop has a fixed one): processor, motherboard, power supply,
 * video card, drive, modem and up to four memory sticks. Pure data and rules, no Minecraft classes, so the server (which installs
 * the parts) and the client (which shows them) share it and it can be tested on its own.
 *
 * <p>Saved as one small text: {@code cpu,board,psu,gpu,disk,modem,s0,s1,s2,s3}. Levels are indices into the ladders below
 * (0 = the stock part every computer starts with, never sold); the modem is -1 for "none"; a stick is its size in GB (0 = empty slot).
 *
 * <p>Compatibility (light): the processor and the board must have the same socket, the sticks must fit the slots of the board.
 * The power supply is a SOFT rule: too weak a one lets the PC run, but it restarts and crashes ({@link #powerShort}).
 */
public final class Build {
    Build() {}

    // ---------- processors ----------
    public static final String[] CPU_NAMES = {"Pixelon Bee 3", "Pixelon Bee 5", "Pixelon Bee 7", "Honeycore Q9", "Panda Ultra X"};
    public static final int[] CPU_SOCKET = {1, 1, 1, 2, 2};
    public static final int[] CPU_CORES = {2, 4, 6, 8, 12};
    public static final double[] CPU_GHZ = {1.6, 2.4, 3.2, 3.8, 4.6};
    public static final int[] CPU_WATTS = {35, 65, 65, 95, 125};
    public static final int[] CPU_PRICE = {0, 100, 180, 360, 650};

    // ---------- motherboards ----------
    public static final String[] BOARD_NAMES = {"Cute Mini", "Cute B350", "Cute X570"};
    public static final int[] BOARD_SOCKET = {1, 1, 2};
    public static final int[] BOARD_SLOTS = {2, 4, 4};
    public static final int[] BOARD_PRICE = {0, 90, 220};

    // ---------- power supplies ----------
    public static final String[] PSU_NAMES = {"Cute 250W", "Cute 400W", "Cute 550W"};
    public static final int[] PSU_WATTS = {250, 400, 550};
    public static final int[] PSU_PRICE = {0, 40, 90};

    /** What the rest of the computer (board, memory, drive, fans) draws, in watts. */
    public static final int BASE_WATTS = 80;

    // ---------- video cards ----------
    public static final int[] GPU_WATTS = {0, 30, 100, 170, 320};

    // ---------- memory sticks ----------
    public static final int[] STICK_GB = {4, 8, 16};          // the sizes that are sold (the stock 2 GB stick is not)
    public static final int STOCK_STICK_GB = 2;
    public static final int MAX_SLOTS = 4;
    public static final int[] STICK_PRICE = {20, 45, 100};     // per stick, in the order of STICK_GB

    // ---------- the build ----------
    public int cpu, board, psu, gpu, disk, modem = -1;
    public final int[] sticks = new int[MAX_SLOTS];

    /** The computer every player starts with: the worst of everything, one 2 GB stick, no modem. */
    public static Build stock() {
        Build b = new Build();
        b.sticks[0] = STOCK_STICK_GB;
        return b;
    }

    public Build copy() {
        Build b = new Build();
        b.cpu = cpu; b.board = board; b.psu = psu; b.gpu = gpu; b.disk = disk; b.modem = modem;
        System.arraycopy(sticks, 0, b.sticks, 0, MAX_SLOTS);
        return b;
    }

    // ---------- derived numbers ----------
    public int slots() { return BOARD_SLOTS[board]; }

    public int ramGb() { int t = 0; for (int s : sticks) t += s; return t; }

    /** Index in {@link PcHardware#RAM_GB} (2, 4, 8, 16, 32, 64): the biggest size the memory reaches. */
    public int ramIdx() {
        int gb = ramGb(), idx = 0;
        for (int i = 0; i < PcHardware.RAM_GB.length; i++) if (gb >= PcHardware.RAM_GB[i]) idx = i;
        return idx;
    }

    /** What the computer draws at full load: the rest of the machine, the processor and the video card. */
    public int load() { return BASE_WATTS + CPU_WATTS[cpu] + GPU_WATTS[gpu]; }

    public int supply() { return PSU_WATTS[psu]; }

    /** True when the power supply is too weak for this build: the PC restarts and crashes now and then. */
    public boolean powerShort() { return supply() < load(); }

    /** How many watts the supply is short (0 = enough). */
    public int shortWatts() { return Math.max(0, load() - supply()); }

    // ---------- installing a part ----------
    public enum Result { OK, SAME_OR_WORSE, SOCKET, NO_SLOT, BAD }

    /** The first empty slot, or -1. */
    public int freeSlot() {
        for (int i = 0; i < slots(); i++) if (sticks[i] == 0) return i;
        return -1;
    }

    /**
     * Tries to put a part in. On OK the build is changed; {@code out[0]} gets the price of what came out (a replaced part, or a stick
     * pushed out) so the caller can pay the trade-in, and 0 if nothing came out. Parts only ever make the PC better
     * (a part that is not better than the installed one is refused), except a stick, which always goes into a free slot.
     */
    public Result install(PcHardware.Kind kind, int level, int[] out) {
        out[0] = 0;
        switch (kind) {
            case CPU -> {
                if (level < 0 || level >= CPU_NAMES.length) return Result.BAD;
                if (level <= cpu) return Result.SAME_OR_WORSE;
                if (CPU_SOCKET[level] != BOARD_SOCKET[board]) return Result.SOCKET;
                out[0] = cpu > 0 ? CPU_PRICE[cpu] : 0;
                cpu = level;
            }
            case BOARD -> {
                if (level < 0 || level >= BOARD_NAMES.length) return Result.BAD;
                if (level <= board) return Result.SAME_OR_WORSE;
                if (BOARD_SOCKET[level] != CPU_SOCKET[cpu]) return Result.SOCKET;       // a new board needs a processor of its socket first
                out[0] = board > 0 ? BOARD_PRICE[board] : 0;
                board = level;
            }
            case PSU -> {
                if (level < 0 || level >= PSU_NAMES.length) return Result.BAD;
                if (level <= psu) return Result.SAME_OR_WORSE;
                out[0] = psu > 0 ? PSU_PRICE[psu] : 0;
                psu = level;
            }
            case GPU -> {
                if (level < 0 || level >= PcHardware.GPU_NAMES.length) return Result.BAD;
                if (level <= gpu) return Result.SAME_OR_WORSE;
                out[0] = gpu > 0 ? PcHardware.price(PcHardware.Kind.GPU, gpu) : 0;
                gpu = level;
            }
            case DISK -> {
                if (level < 0 || level >= PcHardware.DISK_GB.length) return Result.BAD;
                if (level <= disk) return Result.SAME_OR_WORSE;
                out[0] = disk > 0 ? PcHardware.price(PcHardware.Kind.DISK, disk) : 0;
                disk = level;
            }
            case MODEM -> {
                if (level < PcHardware.MODEM_FIRST || level > PcHardware.MODEM_LAST) return Result.BAD;
                if (level <= modem) return Result.SAME_OR_WORSE;
                out[0] = modem > 0 ? PcHardware.price(PcHardware.Kind.MODEM, modem) : 0;
                modem = level;
            }
            case RAM -> {                                   // level = the size of the stick in GB
                int price = stickPrice(level);
                if (price < 0) return Result.BAD;
                int slot = freeSlot();
                if (slot >= 0) { sticks[slot] = level; return Result.OK; }
                int small = -1;                             // all full: the smallest stick is pushed out by a bigger one
                for (int i = 0; i < slots(); i++) if (small < 0 || sticks[i] < sticks[small]) small = i;
                if (small < 0 || sticks[small] >= level) return Result.NO_SLOT;
                out[0] = sticks[small] == STOCK_STICK_GB ? 0 : stickPrice(sticks[small]);
                sticks[small] = level;
            }
        }
        return Result.OK;
    }

    /** Price of a stick of this size in GB, or -1 if no such stick is sold. */
    public static int stickPrice(int gb) {
        for (int i = 0; i < STICK_GB.length; i++) if (STICK_GB[i] == gb) return STICK_PRICE[i];
        return -1;
    }

    // ---------- save / load ----------
    public String write() {
        StringBuilder sb = new StringBuilder();
        sb.append(cpu).append(',').append(board).append(',').append(psu).append(',').append(gpu).append(',')
                .append(disk).append(',').append(modem);
        for (int s : sticks) sb.append(',').append(s);
        return sb.toString();
    }

    /** Reads a saved build; anything missing or wrong falls back to the stock part, and a build that does not fit together is mended. */
    public static Build parse(String text) {
        Build b = stock();
        if (text == null || text.isBlank()) return b;
        String[] p = text.trim().split(",");
        if (p.length < 6 + MAX_SLOTS) return b;               // an old or damaged text: the stock PC (the server pays back old parts)
        try {
            b.cpu = clamp(Integer.parseInt(p[0].trim()), 0, CPU_NAMES.length - 1);
            b.board = clamp(Integer.parseInt(p[1].trim()), 0, BOARD_NAMES.length - 1);
            b.psu = clamp(Integer.parseInt(p[2].trim()), 0, PSU_NAMES.length - 1);
            b.gpu = clamp(Integer.parseInt(p[3].trim()), 0, PcHardware.GPU_NAMES.length - 1);
            b.disk = clamp(Integer.parseInt(p[4].trim()), 0, PcHardware.DISK_GB.length - 1);
            b.modem = clamp(Integer.parseInt(p[5].trim()), -1, PcHardware.MODEM_LAST);
            for (int i = 0; i < MAX_SLOTS; i++) b.sticks[i] = i < b.slots() ? clampStick(Integer.parseInt(p[6 + i].trim())) : 0;
        } catch (NumberFormatException e) {
            return stock();
        }
        if (CPU_SOCKET[b.cpu] != BOARD_SOCKET[b.board]) { b.cpu = 0; b.board = 0; }        // a socket that does not match cannot happen
        if (b.ramGb() == 0) b.sticks[0] = STOCK_STICK_GB;
        return b;
    }

    private static int clampStick(int gb) { return gb == STOCK_STICK_GB || stickPrice(gb) >= 0 ? gb : 0; }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
}
