package dev.cutemod.data;

/**
 * The three kinds of laptop. In a laptop the processor, the video card, the motherboard and the power supply are soldered on and
 * cannot be changed; only the memory (two slots, up to 2 x 16 GB) and the drive can be upgraded. Pure data, no Minecraft classes.
 * <ul>
 *   <li><b>OFFICE</b>: thick bezels, black / white / silver. Weak: Bee 3, the built-in graphics, 4 GB, a small drive.</li>
 *   <li><b>NEO</b>: the slim one (the colourful laptops). Medium: Bee 5, GT 710, 8 GB.</li>
 *   <li><b>GAMING</b>: black or white with RGB lighting. Strong: Bee 7, Radish 5500, 16 GB.</li>
 * </ul>
 */
public enum LaptopLine {
    OFFICE("office", 220, 150),
    NEO("neo", 450, 180),
    GAMING("gaming", 950, 240);

    public final String id;
    /** The price in the shop in coins and the delivery time in seconds. */
    public final int price, secs;

    LaptopLine(String id, int price, int secs) {
        this.id = id;
        this.price = price;
        this.secs = secs;
    }

    /** The build a laptop of this kind is sold with. The power supply and the board stay the stock ones (250 W is enough for all three). */
    public Build build() {
        Build b = new Build();
        switch (this) {
            case OFFICE -> { b.cpu = 0; b.gpu = 0; b.disk = 2; b.modem = 2; b.sticks[0] = 4; }
            case NEO -> { b.cpu = 1; b.gpu = 1; b.disk = 3; b.modem = 3; b.sticks[0] = 8; }
            case GAMING -> { b.cpu = 2; b.gpu = 2; b.disk = 5; b.modem = 4; b.sticks[0] = 8; b.sticks[1] = 8; }
        }
        return b;
    }

    /** Only the memory and the drive of a laptop can be changed. */
    public static boolean upgradable(PcHardware.Kind kind) {
        return kind == PcHardware.Kind.RAM || kind == PcHardware.Kind.DISK;
    }
}
