"""Generates the OFFICE and GAMING laptops (textures, block models, blockstates, item models, loot tables, names).
Run from the project root: python3 tools/make_laptops.py

  office  - thick bezels, thicker plain body, a numpad, black / white / silver  (the weak laptop)
  gaming  - a big body with an RGB keyboard, RGB glow strips on the edges, rear vents, black / white  (the strong laptop)

(The slim Neo laptops, the medium ones, are made by tools/make_neo_laptop.py.) The look is our own: no brand names or logos.
Every model uses small textures with uv 0..16, so each texture has the aspect of its face (the same way as the Neo)."""
import colorsys, json, os
from PIL import Image, ImageDraw

ASSETS = 'src/main/resources/assets/cutemod/'
TEX = ASSETS + 'textures/block/'
MOD = ASSETS + 'models/block/'
ITEM = ASSETS + 'models/item/'
STATE = ASSETS + 'blockstates/'
LOOT = 'src/main/resources/data/cutemod/loot_table/blocks/'

def rgb(h): return ((h >> 16) & 255, (h >> 8) & 255, h & 255)
def mix(a, b, t): return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(3))
def hue(h, s=1.0, v=1.0): return tuple(int(c * 255) for c in colorsys.hsv_to_rgb(h % 1.0, s, v))
def rr(d, box, r, fill, outline=None): d.rounded_rectangle(box, radius=r, fill=fill, outline=outline)

# ----------------------------------------------------------------------------------------------- the variants
# id -> body colour, key colour, legend colour, bed (the dark under the keys), screen bezel, wallpaper style
OFFICE = {
    'office_black':  dict(body=0x2B2D33, key=0x474A54, legend=0xD8DAE0, bed=0x1A1B20, bezel=(8, 9, 8, 13)),
    'office_white':  dict(body=0xE6E8EC, key=0xFAFAFC, legend=0x4A4D57, bed=0xB9BDC6, bezel=(8, 9, 8, 13)),
    'office_silver': dict(body=0xB8BDC6, key=0xDDE0E6, legend=0x3C3F48, bed=0x8E939D, bezel=(8, 9, 8, 13)),
}
GAMING = {
    'gaming_black': dict(body=0x1B1C22, key=0x2A2C35, legend=0xFFFFFF, bed=0x0E0F13),
    'gaming_white': dict(body=0xECEEF2, key=0xF8F9FB, legend=0x3A3D48, bed=0x9FA4B0),
}

def noise_lines(im, c, alpha=10):
    """Soft brushed-metal lines over the whole picture."""
    W, H = im.size
    ov = Image.new('RGBA', (W, H), (0, 0, 0, 0)); od = ImageDraw.Draw(ov)
    for y in range(0, H, 2): od.line([(0, y), (W, y)], fill=(255, 255, 255, alpha))
    im.alpha_composite(ov)

# ----------------------------------------------------------------------------------------------- OFFICE textures
def office_body(v): return Image.new('RGBA', (4, 4), rgb(v['body']) + (255,))

def office_deck(v):
    W, H = 104, 73
    body, key, legend, bed = rgb(v['body']), rgb(v['key']), rgb(v['legend']), rgb(v['bed'])
    im = Image.new('RGBA', (W, H)); d = ImageDraw.Draw(im)
    for y in range(H): d.line([(0, y), (W, y)], fill=mix(mix(body, (255, 255, 255), .06), mix(body, (0, 0, 0), .08), y / H) + (255,))
    rr(d, (3, 4, W - 4, 49), 2, bed)                                   # the keyboard bed
    rows = [(6, 4, 15), (11, 6, 15), (18, 6, 15), (25, 6, 14), (32, 6, 13)]
    for (y, h, n) in rows:                                              # the main block and the numpad share a row
        x = 5
        for k in range(n):
            kw = 5 if k < 12 else 5
            if x + kw > W - 6: break
            d.rectangle((x, y, x + kw - 1, y + h - 1), fill=key)
            if h >= 6: d.point((x + kw // 2, y + h // 2), fill=legend)
            x += kw + 1
            if (y, k) in ((11, 12), (18, 12), (25, 11), (32, 10)): x += 3        # a gap before the numpad
    y = 39                                                              # the bottom row with a long space bar
    x = 5
    for kw in (6, 6, 6):
        d.rectangle((x, y, x + kw - 1, y + 5), fill=key); x += kw + 1
    d.rectangle((x, y, x + 33, y + 5), fill=key); x += 34
    for kw in (6, 6, 6):
        d.rectangle((x, y, x + kw - 1, y + 5), fill=key); x += kw + 1
    edge = mix(body, (0, 0, 0), .25)                                    # trackpad
    rr(d, (34, 53, 69, 69), 2, edge); rr(d, (35, 54, 68, 68), 2, mix(body, (255, 255, 255), .08))
    d.rectangle((90, 55, 96, 61), fill=edge); d.rectangle((91, 56, 95, 60), fill=mix(body, (255, 255, 255), .15))   # a fingerprint reader
    for i in range(4): d.line([(6 + i * 3, 56), (6 + i * 3, 66)], fill=edge)                                       # a speaker grill
    noise_lines(im, body)
    return im

def office_screen(v):
    """A thick bezel and, inside, a classic desktop: sky, a green hill, folder icons and a task bar."""
    W, H = 104, 69
    bz = v['bezel']                                                     # left, top, right, bottom
    bezel = rgb(0x14151A)                                               # a thick black bezel on every colour
    im = Image.new('RGBA', (W, H), bezel + (255,)); d = ImageDraw.Draw(im)
    x0, y0, x1, y1 = bz[0], bz[1], W - bz[2], H - bz[3]
    sw, sh = x1 - x0, y1 - y0
    sc = Image.new('RGBA', (sw, sh)); sd = ImageDraw.Draw(sc)
    for y in range(sh): sd.line([(0, y), (sw, y)], fill=mix(rgb(0x3E8FE0), rgb(0xBFE3FF), y / sh) + (255,))
    sd.ellipse((-20, sh - 22, sw * .8, sh + 40), fill=rgb(0x4DAA4A) + (255,))                          # the hill
    sd.ellipse((sw * .3, sh - 16, sw * 1.3, sh + 40), fill=rgb(0x3E9440) + (255,))
    for cx, cy in ((12, 7), (sw - 22, 11)):                                                            # clouds
        sd.ellipse((cx, cy, cx + 12, cy + 4), fill=(255, 255, 255, 230)); sd.ellipse((cx + 4, cy - 2, cx + 12, cy + 3), fill=(255, 255, 255, 230))
    for i in range(3):                                                                                  # desktop icons
        ix, iy = 3, 3 + i * 9
        sd.rectangle((ix, iy + 1, ix + 6, iy + 5), fill=rgb(0xFFD35C) + (255,)); sd.rectangle((ix, iy, ix + 3, iy + 1), fill=rgb(0xFFD35C) + (255,))
    sd.rectangle((0, sh - 5, sw, sh), fill=rgb(0x1D2330) + (255,))                                       # the task bar
    sd.rectangle((1, sh - 4, 6, sh - 1), fill=rgb(0x3E8FE0) + (255,))
    for i in range(3): sd.rectangle((10 + i * 6, sh - 4, 14 + i * 6, sh - 1), fill=rgb(0x4A5470) + (255,))
    sd.rectangle((sw - 9, sh - 4, sw - 2, sh - 1), fill=rgb(0x4A5470) + (255,))
    im.paste(sc, (x0, y0))
    d.point((W // 2, 3), fill=(70, 74, 90, 255))                                                        # the camera in the thick top bezel
    d.ellipse((W // 2 - 2, H - 9, W // 2 + 2, H - 5), outline=mix(bezel, (255, 255, 255), .35) + (255,))   # a little round mark on the chin
    g = Image.new('RGBA', (W, H), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
    for i in range(0, 12): gd.line([(70 + i, 0), (30 + i, H)], fill=(255, 255, 255, 6))
    im.alpha_composite(g)
    return im

def office_back(v):
    W, H = 104, 69
    body = rgb(v['body'])
    im = Image.new('RGBA', (W, H)); d = ImageDraw.Draw(im)
    for y in range(H): d.line([(0, y), (W, y)], fill=mix(mix(body, (255, 255, 255), .10), mix(body, (0, 0, 0), .10), y / H) + (255,))
    cx, cy = W // 2, H // 2                                             # a plain round mark of our own
    ring = mix(body, (255, 255, 255), .55) if v['body'] == 0x2B2D33 else mix(body, (0, 0, 0), .35)
    d.ellipse((cx - 7, cy - 7, cx + 7, cy + 7), outline=ring + (255,), width=2)
    d.ellipse((cx - 2, cy - 2, cx + 2, cy + 2), fill=ring + (255,))
    noise_lines(im, body, 8)
    return im

# ----------------------------------------------------------------------------------------------- GAMING textures
def gaming_body(v): return Image.new('RGBA', (4, 4), rgb(v['body']) + (255,))

def gaming_rgb():
    """A rainbow strip (for the glow on the edges)."""
    W, H = 64, 4
    im = Image.new('RGBA', (W, H))
    for x in range(W):
        for y in range(H): im.putpixel((x, y), hue(x / W) + (255,))
    return im

def gaming_vent(v):
    W, H = 64, 12
    body = rgb(v['body'])
    im = Image.new('RGBA', (W, H), mix(body, (0, 0, 0), .35) + (255,)); d = ImageDraw.Draw(im)
    for x in range(3, W - 3, 4): d.rectangle((x, 2, x + 1, H - 3), fill=(0, 0, 0, 255) if v['body'] == 0x1B1C22 else mix(body, (0, 0, 0), .7) + (255,))
    d.line([(0, H - 1), (W, H - 1)], fill=hue(.8) + (255,))
    return im

def gaming_deck(v):
    """The keyboard with every key lit in a rainbow, a trackpad with a glowing rim and speaker grills at the sides."""
    W, H = 112, 80
    body, key, legend, bed = rgb(v['body']), rgb(v['key']), rgb(v['legend']), rgb(v['bed'])
    white = v['body'] == 0xECEEF2
    im = Image.new('RGBA', (W, H)); d = ImageDraw.Draw(im)
    for y in range(H): d.line([(0, y), (W, y)], fill=mix(mix(body, (255, 255, 255), .05), mix(body, (0, 0, 0), .10), y / H) + (255,))
    for gx in (3, W - 12):                                              # the speaker grills
        for gy in range(5, 40, 3):
            for k in range(3): d.point((gx + k * 3, gy), fill=mix(body, (0, 0, 0), .55) + (255,))
    rr(d, (13, 5, W - 14, 52), 2, bed)
    rows = [(8, 4, 15), (13, 6, 15), (20, 6, 15), (27, 6, 14), (34, 6, 13), (41, 6, 12)]
    x_end = W - 16
    for ri, (y, h, n) in enumerate(rows):
        x = 15
        for k in range(n):
            kw = 5
            if x + kw > x_end: break
            c = hue((x - 15) / (x_end - 15) + ri * .03, .85, 1.0)       # each key glows in the colour of its place
            d.rectangle((x, y, x + kw - 1, y + h - 1), fill=mix(c, key, .45 if not white else .6) + (255,))
            d.rectangle((x, y + h - 1, x + kw - 1, y + h - 1), fill=c + (255,))                      # the lit lower edge
            if h >= 6: d.point((x + kw // 2, y + h // 2 - 1), fill=legend if not white else mix(legend, c, .4))
            x += kw + 1
    x = 15
    for kw in (6, 6, 6, 6):
        c = hue((x - 15) / (x_end - 15), .85, 1.0)
        d.rectangle((x, 48, x + kw - 1, 51), fill=mix(c, key, .75) + (255,)); x += kw + 1
    c = hue(.55, .85, 1.0)
    d.rectangle((x, 48, x + 29, 51), fill=mix(c, key, .7) + (255,)); x += 30
    for kw in (6, 6, 6):
        c = hue((x - 15) / (x_end - 15), .85, 1.0)
        d.rectangle((x, 48, x + kw - 1, 51), fill=mix(c, key, .75) + (255,)); x += kw + 1
    tp = (38, 58, 73, 74)                                               # a trackpad with a rainbow rim
    for i in range(tp[0], tp[2]): d.point((i, tp[1]), fill=hue((i - tp[0]) / (tp[2] - tp[0])) + (255,)); d.point((i, tp[3]), fill=hue((i - tp[0]) / (tp[2] - tp[0]) + .5) + (255,))
    rr(d, (tp[0], tp[1] + 1, tp[2], tp[3] - 1), 2, mix(body, (0, 0, 0), .30) + (255,))
    d.ellipse((W - 10, 56, W - 4, 62), fill=hue(.3) + (255,)); d.ellipse((W - 9, 57, W - 5, 61), fill=mix(body, (0, 0, 0), .5) + (255,))   # the power button
    return im

def gaming_screen(v):
    """A thin bezel and a neon sunset over a grid (our own), a crosshair, a health bar and a mini map."""
    W, H = 112, 72
    im = Image.new('RGBA', (W, H), (8, 8, 12, 255)); d = ImageDraw.Draw(im)
    sw, sh = W - 4, H - 5
    sc = Image.new('RGBA', (sw, sh)); sd = ImageDraw.Draw(sc)
    for y in range(sh): sd.line([(0, y), (sw, y)], fill=mix(rgb(0x1B0B3A), rgb(0xFF4DA6), (y / sh) ** 1.4) + (255,))
    hz = int(sh * .58)
    sd.ellipse((sw // 2 - 16, hz - 20, sw // 2 + 16, hz + 12), fill=rgb(0xFFD35C) + (255,))             # the sun
    for i in range(4): sd.rectangle((sw // 2 - 17, hz - 6 + i * 4, sw // 2 + 17, hz - 5 + i * 4), fill=mix(rgb(0xFF4DA6), rgb(0x1B0B3A), .3) + (255,))
    sd.rectangle((0, hz, sw, sh), fill=rgb(0x14082B) + (255,))                                         # the ground
    for i in range(0, sw + 40, 10): sd.line([(sw // 2 + (i - sw // 2) * .2, hz), (sw // 2 + (i - sw // 2) * 2.2, sh)], fill=rgb(0x35E0FF) + (255,))
    for j in range(1, 6): sd.line([(0, hz + j * j * 1.6), (sw, hz + j * j * 1.6)], fill=rgb(0x35E0FF) + (255,))
    cx, cy = sw // 2, hz - 3                                                                            # a crosshair
    sd.line([(cx - 5, cy), (cx - 2, cy)], fill=(255, 255, 255, 255)); sd.line([(cx + 2, cy), (cx + 5, cy)], fill=(255, 255, 255, 255))
    sd.line([(cx, cy - 5), (cx, cy - 2)], fill=(255, 255, 255, 255)); sd.line([(cx, cy + 2), (cx, cy + 5)], fill=(255, 255, 255, 255))
    sd.rectangle((4, sh - 9, 34, sh - 5), outline=(255, 255, 255, 200)); sd.rectangle((5, sh - 8, 26, sh - 6), fill=rgb(0x4DFF88) + (255,))   # health
    sd.rectangle((sw - 22, 4, sw - 4, 20), outline=(255, 255, 255, 200), fill=(0, 0, 0, 120)); sd.point((sw - 13, 12), fill=rgb(0xFF4D4D) + (255,))    # mini map
    im.paste(sc, (2, 2))
    d = ImageDraw.Draw(im)
    d.point((W // 2, 1), fill=(70, 74, 90, 255))                                                        # the camera
    g = Image.new('RGBA', (W, H), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
    for i in range(0, 14): gd.line([(78 + i, 0), (36 + i, H)], fill=(255, 255, 255, 6))
    im.alpha_composite(g)
    return im

def gaming_back(v):
    """The lid: a glowing hexagon with cat ears and an RGB rim (our own mark) on a plain body."""
    W, H = 112, 72
    body = rgb(v['body'])
    im = Image.new('RGBA', (W, H)); d = ImageDraw.Draw(im)
    for y in range(H): d.line([(0, y), (W, y)], fill=mix(mix(body, (255, 255, 255), .08), mix(body, (0, 0, 0), .12), y / H) + (255,))
    cx, cy, r = W // 2, H // 2 + 2, 16
    import math
    pts = [(cx + r * math.cos(math.radians(60 * i - 30)), cy + r * math.sin(math.radians(60 * i - 30))) for i in range(6)]
    ears = [[(cx - 11, cy - r + 1), (cx - 9, cy - r - 9), (cx - 2, cy - r + 1)], [(cx + 11, cy - r + 1), (cx + 9, cy - r - 9), (cx + 2, cy - r + 1)]]
    inner = mix(body, (0, 0, 0), .45) if v['body'] == 0x1B1C22 else mix(body, (0, 0, 0), .25)
    for e in ears: d.polygon(e, fill=inner + (255,))
    d.polygon(pts, fill=inner + (255,))
    n = len(pts)
    for i in range(n):                                                                                  # the rim, a rainbow around the hexagon
        a, b = pts[i], pts[(i + 1) % n]
        for t in range(0, 11):
            x = a[0] + (b[0] - a[0]) * t / 10; y = a[1] + (b[1] - a[1]) * t / 10
            c = hue((i + t / 10) / n)
            d.ellipse((x - 1, y - 1, x + 1, y + 1), fill=c + (255,))
    for e in ears:
        for k in range(2):
            a, b = e[k], e[k + 1]
            for t in range(0, 7):
                x = a[0] + (b[0] - a[0]) * t / 6; y = a[1] + (b[1] - a[1]) * t / 6
                d.point((int(x), int(y)), fill=hue(.1 * k + t / 20) + (255,))
    d.ellipse((cx - 5, cy - 4, cx + 5, cy + 6), outline=hue(.55) + (255,), width=1)                    # a paw: one pad and three toes
    for dx in (-5, 0, 5): d.ellipse((cx + dx - 1, cy - 8, cx + dx + 1, cy - 6), fill=hue(.55) + (255,))
    for xx in (8, W - 9):                                                                               # angled glow lines at the corners
        d.line([(xx, 6), (xx + (6 if xx < W // 2 else -6), 14)], fill=hue(xx / W) + (255,))
    noise_lines(im, body, 7)
    return im

# ----------------------------------------------------------------------------------------------- models
def box(name, f, t, faces, rot=None):
    e = {'name': name, 'from': [round(x, 3) for x in f], 'to': [round(x, 3) for x in t], 'faces': faces}
    if rot: e['rotation'] = rot
    return e

def faces_all(tex): return {k: {'uv': [0, 0, 16, 16], 'texture': tex} for k in ('north', 'south', 'east', 'west', 'up', 'down')}

def with_(faces, **kw):
    f = dict(faces)
    for k, tex in kw.items(): f[k] = {'uv': [0, 0, 16, 16], 'texture': tex}
    return f

def office_model(open_):
    X0, X1, Z0, Z1 = 1.25, 14.75, 4.4, 13.9
    els = [box('base', [X0, 0, Z0], [X1, 0.5, Z1], faces_all('#body'))]
    els.append(box('deck', [X0 + .1, 0.5, Z0 + .1], [X1 - .1, 1.1, Z1 - .1], with_(faces_all('#body'), up='#deck')))
    if open_:
        els.append(box('hinge', [2.5, 0.9, Z0 - .15], [13.5, 1.3, Z0 + .3], faces_all('#feet')))
        els.append(box('lid', [X0, 1.1, Z0], [X1, 10.0, Z0 + .6], with_(faces_all('#body'), south='#screen', north='#back'),
                       {'origin': [8, 1.1, Z0 + .3], 'axis': 'x', 'angle': -22.5}))
    else:
        els.append(box('lid_closed', [X0, 1.1, Z0], [X1, 1.8, Z1], with_(faces_all('#body'), up='#back')))
    return els

def gaming_model(open_):
    X0, X1, Z0, Z1 = 1.0, 15.0, 4.2, 14.2
    els = [box('base', [X0, 0, Z0], [X1, 0.6, Z1], faces_all('#body'))]
    els.append(box('deck', [X0 + .1, 0.6, Z0 + .1], [X1 - .1, 1.5, Z1 - .1], with_(faces_all('#body'), up='#deck')))
    els.append(box('glow_front', [X0 + .6, 0.15, Z1], [X1 - .6, 0.5, Z1 + .08], with_(faces_all('#rgb'))))       # the RGB light strips on the edges
    els.append(box('glow_left', [X0 - .08, 0.15, Z0 + 1.2], [X0, 0.5, Z1 - .6], with_(faces_all('#rgb'))))
    els.append(box('glow_right', [X1, 0.15, Z0 + 1.2], [X1 + .08, 0.5, Z1 - .6], with_(faces_all('#rgb'))))
    els.append(box('vent', [2.0, 1.0, Z0 - .45], [14.0, 1.9, Z0 + .9], with_(faces_all('#body'), north='#vent', up='#vent')))   # the rear vents
    if open_:
        els.append(box('lid', [X0, 1.5, Z0], [X1, 10.2, Z0 + .45], with_(faces_all('#body'), south='#screen', north='#back'),
                       {'origin': [8, 1.5, Z0 + .2], 'axis': 'x', 'angle': -22.5}))
    else:
        els.append(box('lid_closed', [X0, 1.5, Z0], [X1, 2.1, Z1], with_(faces_all('#body'), up='#back')))
    return els

DISPLAY = None   # copied from the slim laptop's item model, so every laptop is held the same way

def write_variant(name, textures, elements_fn, credit):
    tex = {'particle': 'cutemod:block/%s_body' % name}
    tex.update({k: 'cutemod:block/%s_%s' % (name, k) for k in textures})
    for open_, suffix in ((True, ''), (False, '_closed')):
        json.dump({'credit': credit, 'ambientocclusion': False, 'textures': tex, 'elements': elements_fn(open_)},
                  open(MOD + '%s_laptop%s.json' % (name, suffix), 'w'), indent=1)
    states = {}
    for facing, y in (('south', 0), ('west', 90), ('north', 180), ('east', 270)):
        states['facing=%s,open=true' % facing] = {'model': 'cutemod:block/%s_laptop' % name, 'y': y}
        states['facing=%s,open=false' % facing] = {'model': 'cutemod:block/%s_laptop_closed' % name, 'y': y}
    json.dump({'variants': states}, open(STATE + '%s_laptop.json' % name, 'w'), indent=2)
    json.dump({'parent': 'cutemod:block/%s_laptop' % name, 'display': DISPLAY}, open(ITEM + '%s_laptop.json' % name, 'w'), indent=1)
    write_loot('%s_laptop' % name)

def write_loot(block):
    """The drop keeps the custom_data of the laptop (its upgraded memory and drive)."""
    json.dump({
        'type': 'minecraft:block',
        'pools': [{'rolls': 1.0, 'bonus_rolls': 0.0,
                   'entries': [{'type': 'minecraft:item', 'name': 'cutemod:%s' % block,
                                'functions': [{'function': 'minecraft:copy_components', 'source': 'block_entity', 'include': ['minecraft:custom_data']}]}],
                   'conditions': [{'condition': 'minecraft:survives_explosion'}]}],
        'random_sequence': 'cutemod:blocks/%s' % block}, open(LOOT + '%s.json' % block, 'w'), indent=2)

if __name__ == '__main__':
    DISPLAY = json.load(open(ITEM + 'pink_laptop.json'))['display']
    for name, v in OFFICE.items():
        office_body(v).save(TEX + '%s_body.png' % name)
        Image.new('RGBA', (4, 4), mix(rgb(v['body']), (0, 0, 0), .45) + (255,)).save(TEX + '%s_feet.png' % name)
        office_deck(v).save(TEX + '%s_deck.png' % name)
        office_screen(v).save(TEX + '%s_screen.png' % name)
        office_back(v).save(TEX + '%s_back.png' % name)
        write_variant(name, ('body', 'feet', 'deck', 'screen', 'back'), office_model, 'office laptop with thick bezels (generated by tools/make_laptops.py)')
    for name, v in GAMING.items():
        gaming_body(v).save(TEX + '%s_body.png' % name)
        gaming_rgb().save(TEX + '%s_rgb.png' % name)
        gaming_vent(v).save(TEX + '%s_vent.png' % name)
        gaming_deck(v).save(TEX + '%s_deck.png' % name)
        gaming_screen(v).save(TEX + '%s_screen.png' % name)
        gaming_back(v).save(TEX + '%s_back.png' % name)
        write_variant(name, ('body', 'rgb', 'vent', 'deck', 'screen', 'back'), gaming_model, 'gaming laptop with RGB lighting (generated by tools/make_laptops.py)')
    print('done')
