package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * "Zombie Shooter": a first-person wave shooter in the style of Call of Duty Zombies.
 * Five rooms (a hall and four rooms behind doors you pay for), endless rounds, boarded windows the zombies tear down
 * and you nail back up, headshots, power-ups that drop from zombies, a wall station to buy a rifle / shotgun and ammo.
 * Same "one ray per screen column" raycaster as Dark Corridor, now with textured walls and floor.
 *
 * Controls: W/S walk, A/D strafe, mouse near the left/right edge or arrow keys to turn,
 * mouse above / below the middle (or the up / down arrows) to look up / down (aim at the head!),
 * LMB or Space to shoot, R reload, 1/2/3/Q switch weapon,
 * E buys at the golden (rifle) or teal (shotgun) wall and opens doors, hold E at a window to repair it,
 * B buy mines, F lay a mine. Pull the power switch (right room) to wake up the perk machines and Pack-a-Punch:
 * E at a perk machine buys the perk (Call of Duty style, once each: Quick Revive $500, Speed Cola $3000, Stamin-Up $2000,
 * Juggernog $2500, Double Tap II $2000, Mule Kick $4000), E at Pack-a-Punch upgrades the gun in your hands ($2500).
 * A zombie bite takes 34 health: 3 bites kill you, with Juggernog it takes 4. Every machine plays its own tune (see PerkMusic).
 * Zombie kinds: normal, runner (round 3+), tank (5+), spitter (7+).
 * Power-ups: max ammo, insta-kill, nuke, double points, carpenter (fixes every window), medkit.
 */
public class ZombieShooter extends MiniGame {
    private static final int MW = 64, MH = 44;
    private static final int COLS = 110, CW = W / COLS;
    private static final double PLANE = 0.75;
    private static final int MINE_COST = 1000, MAX_MINES = 6, BOX_COST = 950, BOX_ROLL = 300;                      // the box rolls for 5 seconds, like the music that plays meanwhile
    // The points work like in CoD Zombies: you start with 500, a bullet that hurts a zombie gives 10, the killing shot 60
    // (100 for a headshot), a nailed board 10. Nothing for just clearing a round. Prices: see the gun table and DOOR_COST.
    private static final int START_PTS = 500, HIT_PTS = 10, KILL_PTS = 60, HEAD_PTS = 100, BOARD_PTS = 10;
    private static final int PERKS = 6, CARD_W = 66, CARD_H = 100, CARD_Y = 22;
    private static final double DEAD = 0.1;                      // the middle of the screen where the mouse does not turn you
    private static final double MAXP = 24, PDEAD = 0.35;          // looking up / down: most pixels the horizon moves, dead zone of the mouse
    private static final int MAX_BOARDS = 5;
    private static final int PAP_COST = 5000;                       // Pack-a-Punch (like CoD): the gun goes into the machine for 5 s, then you take it
    private static final int[] PERK_COST = {500, 3000, 2000, 2500, 2000, 4000};   // Quick Revive, Speed Cola, Stamin-Up, Juggernog, Double Tap II, Mule Kick (the prices of CoD Zombies)
    private static final int P_REVIVE = 0, P_COLA = 1, P_STAMIN = 2, P_JUGG = 3, P_TAP = 4, P_MULE = 5;
    private static final int BASE_HP = 100, JUGG_HP = 135;            // the zombie bites for BITE: 3 bites kill you, with Juggernog it takes 4
    private static final int BITE = 34;
    private static final int[] DOOR_COST = {0, 750, 750, 1250, 1250};
    private static final int[] PERK_COL = {0xFF4AA8E0, 0xFF3FAE4A, 0xFFF08A1A, 0xFFD0302E, 0xFFE8B030, 0xFF2F9A4A};
    private static final int[] KIND_DMG = {BITE, BITE, BITE, BITE};   // a bite: every zombie kills in 3 bites (4 with Juggernog)
    private static final double[] KIND_SIZE = {0.9, 0.8, 1.25, 0.9};   // body height compared with a wall
    private static final double HEAD = 0.69;                         // the top 31 % of a zombie is its head

    // tiles: 0 floor, 1 wall, 2 crate, 3 golden wall (rifle), 4 teal wall (shotgun), 5 door, 6 boarded window, 7 open window,
    //        8 green wall (SMG), 9 red wall (magnum), 10 purple wall (sniper), 11 mystery box, 12 cracked wall (secret door),
    //        22 chain-link fence (low, see-through), 23 car (low), 2 crate (low), 24 house wall with a lit window (the map is the "Town" of CoD Black Ops 2 Zombies: a burning crossroads),
    //        13 power switch (off), 14 Pack-a-Punch, 15-20 perk machines, 21 power switch (on)
    // '#' wall, '.' floor, 'c' crate, 'S' rifle 'T' shotgun 'U' SMG 'G' magnum 'K' sniper, 'X' mystery box, 'Z' cracked wall,
    // '1'-'4' doors (price from DOOR_COST), 'W' window, 'p' outside pocket, 'f' fence, 'v' car, 'h' house wall with a window,
    // 'L' power switch, 'P' Pack-a-Punch, 'A'-'F' perk machines (one per perk)
    private static final String[] LEVEL = {
            "################################################################",
            "##########ppp########ppp####ppp##ppp####ppp########ppp##########",
            "##########ppp########ppp####ppp##ppp####ppp########ppp##########",
            "##########ppp########ppp####ppp##ppp####ppp########ppp##########",
            "##########ppp########ppp##hhhWhXhhWhhh##ppp########ppp##########",
            "###########W##A####B##W###............###W####C#####W###########",
            "#########................h............h................#########",
            "#########................h............h................#########",
            "#########................h............h................#########",
            "#########................h............h...c............#########",
            "#########...c............h...vv.......h................#########",
            "#########............c...h............h............c...#########",
            "#########................h.....c......h................#########",
            "#########................h............h................#########",
            "#########................h............h................#########",
            "#########hhhhhhhh1hhUhhhh#............#hhhhhhh2hhhhhhhh#########",
            "#######h................................................h#######",
            "##ppppph...........................c....................hppppp##",
            "##pppppW..vf............................................Wppppp##",
            "##ppppph....ffff...........................vv...........hppppp##",
            "#######S............................................c...K#######",
            "##ppppph................................................hppppp##",
            "##pppppW..c....c........................................Wppppp##",
            "##ppppph................................................hppppp##",
            "#######T...........vv.......c...................ffff....h#######",
            "##ppppph.............................................vf.hppppp##",
            "##pppppW................................................Wppppp##",
            "##ppppph................................................hppppp##",
            "#########hhhhhhhh3hhhhhhh#.......c....#hhhhhhh4hhhhhhhh#########",
            "#########................h............h................#########",
            "##......#................h............h................#########",
            "##......#............c...h...c........h................#########",
            "##......Z................h............h............c...#########",
            "##......#...c............h.......vv...h................#########",
            "##......#................h............h...c............#########",
            "##......#................h............h................#########",
            "####G####................h............h................#########",
            "#########................h............h................#########",
            "###########W###D###E##W###............###W#L##F###P#W###########",
            "##########ppp########ppp##hhhWhhhhWhhh##ppp########ppp##########",
            "##########ppp########ppp####ppp##ppp####ppp########ppp##########",
            "##########ppp########ppp####ppp##ppp####ppp########ppp##########",
            "##########ppp########ppp####ppp##ppp####ppp########ppp##########",
            "################################################################"
    };
    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    // ---------- power-ups ----------
    private static final int D_AMMO = 0, D_INSTA = 1, D_NUKE = 2, D_DOUBLE = 3, D_CARPENTER = 4, D_MED = 5;
    private static final int[] DROP_COL = {0xFF3A78C8, 0xFFC83A3A, 0xFFE07A20, 0xFFD8B020, 0xFF8A5A2A, 0xFF3AA05A};
    private static final int[] DROP_W = {25, 15, 10, 20, 15, 15};     // how likely each one is
    private static final String[][] ICON = {
            {".ooooo.", "owowowo", "owowowo", "owowowo", "owowowo", "ooooooo", ".ooooo."},   // max ammo: bullets
            {".ooooo.", "owwwwwo", "owowowo", "owwwwwo", ".owwwo.", ".owowo.", "..ooo.."},   // insta-kill: a skull
            {"..ooo..", ".owwwo.", "owwwwwo", ".owwwo.", "..owo..", "..owo..", ".ooooo."},   // nuke: a mushroom cloud
            {"ooooooo", "owwwwwo", "ooooowo", "owwwwwo", "owooooo", "owwwwwo", "ooooooo"},   // double points: a 2
            {"ooooooo", "owwwwwo", "ooooooo", "owwwwwo", "ooooooo", "owwwwwo", "ooooooo"},   // carpenter: planks
            {"ooooooo", "ooowooo", "ooowooo", "owwwwwo", "ooowooo", "ooowooo", "ooooooo"}};  // medkit: a cross

    // ---------- textures (16 x 8 texels, built once) ----------
    private static final int TW = 16, TH = 8;
    private static final int[][][] TEX = new int[27][][];         // 1 brick, 2 crate, 3 gold, 4 teal, 5 door, 8 green, 9 red, 10 purple, 11 box, 12 cracked brick
    private static final int[] PLANK_ROW = {3, 5, 1, 4, 2};           // the rows the boards of a window cover, in order
    private static final int[][] ZONE_ANCHOR = {{31, 21, 0xFF5C4A3E}, {16, 10, 0xFF7A5230}, {46, 10, 0xFF80808A}, {16, 33, 0xFF7E4E60}, {46, 33, 0xFF3E5262}, {4, 32, 0xFF4A3A30}};   // x, y, floor color of that room (Town: the crossroads, bar, bank, tailor, depot, secret closet)
    private static final int POCKET_FLOOR = 0xFF3A2E22, SILL_FLOOR = 0xFF5A4630;

    static {
        for (int i = 0; i < TEX.length; i++) TEX[i] = new int[TH][TW];
        for (int v = 0; v < TH; v++) {
            for (int u = 0; u < TW; u++) {
                // 1: red brick, laid in staggered courses
                int course = v / 2, off = course % 2 == 0 ? 0 : 4, bu = u + off;
                int brick;
                if (v % 2 == 0 || bu % 8 == 0) brick = 0xFF57514B;
                else {
                    int[] bricks = {0xFF8E4B3B, 0xFF9C5642, 0xFF7F4234, 0xFF93503F};
                    brick = bricks[(hash(bu / 8, course) & 3)];
                }
                TEX[1][v][u] = brick;
                // 12: the same brick, but cracked and a little darker: the secret door
                boolean crack = (u == 7 && v == 1) || (u == 8 && (v == 2 || v == 3)) || (u == 9 && v == 4) || (u == 10 && v == 5) || (u == 9 && v == 6)
                        || (u == 6 && v == 3) || (u == 5 && v == 4) || (u == 11 && v == 3) || (u == 12 && v == 2);
                TEX[12][v][u] = crack ? 0xFF1C1816 : shade(brick, 0.82);
                // 2: a wooden crate with a cross
                if (u == 0 || u == TW - 1 || v == 0 || v == TH - 1) TEX[2][v][u] = 0xFF5A3A1C;
                else if (v * 2 == u || v * 2 == TW - 1 - u) TEX[2][v][u] = 0xFF7A5128;
                else TEX[2][v][u] = v % 2 == 0 ? 0xFF9A6B3A : 0xFF8F6335;
                // 3: the golden wall (rifle) with a rifle on it
                boolean edge = u == 0 || u == TW - 1 || v == 0 || v == TH - 1;
                int gold = edge ? 0xFFE8C860 : 0xFFB8902C;
                if ((v == 3 && u >= 2 && u <= 13) || (v == 4 && (u == 3 || u == 4 || u == 9 || u == 10)) || (v == 2 && u >= 10 && u <= 12)) gold = 0xFF2A1E08;
                TEX[3][v][u] = gold;
                // 4: the teal wall (shotgun) with two barrels on it
                int teal = edge ? 0xFF70D0E8 : 0xFF2A8098;
                if (((v == 3 || v == 4) && u >= 2 && u <= 13) || (v == 5 && u >= 2 && u <= 4)) teal = 0xFF08242C;
                TEX[4][v][u] = teal;
                // 5: a steel door with hazard stripes, a lock and rivets
                int door = 0xFF66727E;
                if (u == 0 || u == TW - 1 || u == 8) door = 0xFF4A5560;
                if (v == 0) door = (u / 2) % 2 == 0 ? 0xFFE8C020 : 0xFF1A1A1A;
                if (u >= 10 && u <= 13 && v >= 2 && v <= 5) door = 0xFF3A424C;
                if (u == 12 && (v == 3 || v == 4)) door = 0xFFE0E0E0;
                if ((u == 2 || u == 6 || u == 14) && (v == 2 || v == 6)) door = 0xFFB8C4D0;
                TEX[5][v][u] = door;
                // 8: the green wall (SMG): a short gun with a magazine
                int smg = edge ? 0xFF7ADC8A : 0xFF2E7A3E;
                if ((v == 3 && u >= 2 && u <= 13) || (v == 4 && (u == 4 || u == 5 || u == 10 || u == 11)) || (v == 5 && (u == 10 || u == 11))) smg = 0xFF08200C;
                TEX[8][v][u] = smg;
                // 9: the red wall (magnum): a big revolver
                int mag = edge ? 0xFFF0A070 : 0xFFA84A28;
                if ((v == 3 && u >= 4 && u <= 13) || (v == 4 && (u == 4 || u == 5 || u == 6 || u == 7)) || (v == 5 && (u == 4 || u == 5))) mag = 0xFF2A0E04;
                TEX[9][v][u] = mag;
                // 10: the purple wall (sniper): a long barrel with a scope
                int snp = edge ? 0xFFD0A0F0 : 0xFF6A3A9A;
                if ((v == 3 && u >= 1 && u <= 14) || (v == 2 && u >= 6 && u <= 9) || (v == 4 && u >= 2 && u <= 4)) snp = 0xFF1A0A2A;
                TEX[10][v][u] = snp;
                // 11: the mystery box: a dark chest with a golden question mark
                int box = edge ? 0xFFE8C860 : 0xFF1E2A44;
                boolean q = (v == 1 && (u == 7 || u == 8)) || (v == 2 && (u == 6 || u == 9)) || (v == 3 && u == 9) || (v == 4 && u == 8) || (v == 6 && u == 8);
                if (q) box = 0xFFFFD84A;
                TEX[11][v][u] = box;
                // 13 / 21: the power switch: a grey panel with a lamp (red = off, green = on) and a lever
                int swOff = edge ? 0xFF9AA0A8 : 0xFF3E4248, swOn = swOff;
                if (v == 1 && (u == 7 || u == 8)) { swOff = 0xFFE03030; swOn = 0xFF30E060; }
                if ((v == 3 && u == 6) || (v == 4 && u == 5) || (v == 5 && u == 4)) swOff = 0xFFD8D8D8;
                if ((v == 3 && u == 9) || (v == 4 && u == 10) || (v == 5 && u == 11)) swOn = 0xFFD8D8D8;
                if (v == 6 && u == 4) swOff = 0xFFE03030;
                if (v == 6 && u == 11) swOn = 0xFF30E060;
                TEX[13][v][u] = swOff;
                TEX[21][v][u] = swOn;
                // 14: Pack-a-Punch: a dark violet machine with a pink P
                int pap = edge ? 0xFFFF8AE0 : 0xFF241A44;
                if ((v == 1 && u >= 6 && u <= 8) || (v == 2 && (u == 6 || u == 8)) || (v == 3 && u >= 6 && u <= 8) || (v >= 4 && v <= 5 && u == 6)) pap = 0xFFFFD0F0;
                if (v == 6 && u >= 3 && u <= 12 && (u % 2 == 0)) pap = 0xFF8A4AD0;
                TEX[14][v][u] = pap;
            }
        }
    }

    static {
        // 22: chain-link fence, 23: a car, 24: a house wall with a lit window (Town street furniture)
        for (int v = 0; v < TH; v++) {
            for (int u = 0; u < TW; u++) {
                int f = 0;                                        // the holes of the fence are see-through
                if ((u + v * 2) % 6 == 0 || ((u - v * 2) % 6 + 6) % 6 == 0) f = 0xFF9A948A;
                if (v == 0) f = 0xFF6A645C;
                if (u == 0 || u == TW - 1) f = 0xFF5A544C;
                TEX[22][v][u] = f;
                int car = 0xFFB8AE98;
                if (v == 0) car = 0xFF8A8478;
                else if (v >= 1 && v <= 3) {
                    boolean glass = (u >= 2 && u <= 6) || (u >= 9 && u <= 13);
                    car = glass ? ((u + v) % 5 == 0 ? 0xFF4A5866 : 0xFF1E2630) : 0xFFA89E88;
                } else if (v == 4 || v == 5) car = (hash(u / 2, v) & 7) == 0 ? 0xFF8A5A3A : 0xFFB8AE98;
                else if (v == 6) car = ((u >= 2 && u <= 4) || (u >= 11 && u <= 13)) ? ((u == 3 || u == 12) ? 0xFF8A8A8A : 0xFF101010) : 0xFF2A2622;
                else if (v == 7) car = 0xFF1A1816;
                TEX[23][v][u] = car;
                int brick = TEX[1][v][u];
                int house = shade(brick, 0.8);
                if (u >= 4 && u <= 11 && v >= 1 && v <= 6) {
                    boolean frame = u == 4 || u == 11 || v == 1 || v == 6 || u == 7 || u == 8 || v == 3;
                    house = frame ? 0xFF3A2A1A : 0xFFF0B030;
                }
                TEX[24][v][u] = house;
            }
        }
    }

    static {
        // 15-20: perk vending machines: detailed 16 x 16 pictures (see ZombieArt)
        for (int pk = 0; pk < PERKS; pk++) TEX[15 + pk] = ZombieArt.machine(pk, PERK_COL[pk]);
        TEX[11] = ZombieArt.mysteryBox(false);                       // the mystery box: a wooden crate with glowing question marks (32 x 32)
        TEX[14] = ZombieArt.papMachine(false);                       // Pack-a-Punch: a rusty bowl with three drums under a big sign (32 x 32)
        TEX[26] = ZombieArt.papMachine(true);                        // ...and while it works: the drums glow (see drawWall's caller)
        TEX[25] = ZombieArt.mysteryBox(true);                        // ...and with the lid up while it rolls (see drawWall's caller)
    }

    private static int hash(int a, int b) {
        int h = a * 374761393 + b * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        return (h ^ (h >>> 16)) & 0x7FFFFFFF;
    }

    /** A boarded window: a dark frame with night behind it and up to 5 planks nailed across. */
    private static int windowTexel(int u, int v, int boards) {
        for (int k = 0; k < boards && k < MAX_BOARDS; k++) {
            if (v == PLANK_ROW[k]) {
                if (u == 1 || u == TW - 2) return 0xFF3A3A3A;                    // nails
                return (hash(k, u / 5) & 1) == 0 ? 0xFFA27B4A : 0xFF90693C;
            }
        }
        if (u == 0 || u == TW - 1 || v == 0 || v == TH - 1 || u == 7 || u == 8) return 0xFF4A3220;   // frame and the middle bar
        if (u >= 10 && u <= 13 && v <= 2) return 0xFF22324E;                      // a bit of moon
        return 0xFF0A101C;
    }

    private static int texel(int type, int u, int v, int boards) {
        return type == 6 ? windowTexel(u, v, boards) : TEX[type][v][u];
    }

    // ---------- first-person guns: seen from behind like in a shooter, see GunView (3D boxes, the barrel points into the crosshair) ----------

    // ---------- classes ----------
    /** A gun. pellets > 1 is a shotgun, pierce > 1 goes through several zombies, splash > 0 hurts the ones next to the target. */
    private static final class Weapon {
        final boolean auto, infinite;
        final int pellets, pierce, cost, ammoCost, oCol, oMag, oRes, oDmg, oRate, oRl;
        int col, magSize, maxReserve, dmg, rate, reloadTime;
        boolean pap;
        final double push, splash;
        boolean owned;
        int mag, reserve;

        Weapon(int col, boolean auto, boolean infinite, int magSize, int reserve, int dmg, int rate, int reloadTime,
               int pellets, int pierce, double push, double splash, int cost, int ammoCost) {
            this.col = col; this.auto = auto; this.infinite = infinite; this.magSize = magSize; this.maxReserve = reserve;
            this.dmg = dmg; this.rate = rate; this.reloadTime = reloadTime; this.pellets = pellets; this.pierce = pierce;
            this.push = push; this.splash = splash; this.cost = cost; this.ammoCost = ammoCost;
            this.mag = magSize; this.reserve = reserve;
            oCol = col; oMag = magSize; oRes = reserve; oDmg = dmg; oRate = rate; oRl = reloadTime;
        }

        void resetStats() {
            col = oCol; magSize = oMag; maxReserve = oRes; dmg = oDmg; rate = oRate; reloadTime = oRl; pap = false;
        }

        /** Pack-a-Punch: twice the damage, a bigger magazine and reserve, faster, and a skin of lava. */
        void punch() {
            pap = true;
            dmg = dmg * 2;
            magSize = magSize * 3 / 2;
            maxReserve = maxReserve * 3 / 2;
            rate = Math.max(2, rate * 8 / 10);
            reloadTime = reloadTime * 8 / 10;
            col = 0xFFFF7A18;                                  // lava orange (the gun itself is covered in lava, see GunView.applyLava)
            mag = magSize;
            reserve = maxReserve;
        }
    }

    private static final class Zombie {
        double x, y, speed;
        int hp, maxHp, cool, flash, kind, spitT = 60, tear = 40, stun;      // kind: 0 normal, 1 runner, 2 tank, 3 spitter
        Zombie(double x, double y, int hp, double speed, int kind) {
            this.x = x; this.y = y; this.hp = hp; this.maxHp = hp; this.speed = speed; this.kind = kind;
        }
        double radius() { return kind == 2 ? 0.42 : 0.3; }
    }

    /** A window in a wall: boards on it, the tile inside the room, and the little pocket outside where zombies come from. */
    private static final class Win {
        int x, y, ix, iy, zone, boards = MAX_BOARDS;
        final List<int[]> pocket = new ArrayList<>();
    }

    private final int[][] map = new int[MH][MW];
    private final boolean[][] pocket = new boolean[MH][MW];
    private final int[][] zoneOf = new int[MH][MW];                 // which room a floor tile belongs to (-1 outside)
    private final int[][] winIdx = new int[MH][MW];                 // which window a window tile or a pocket tile belongs to
    private final double[] zbuf = new double[COLS];
    private final double[] winD = new double[COLS];                 // per column: how far the first open window on the ray is (0 = none)
    private final boolean[] winSide = new boolean[COLS];
    private final int[][] flow = new int[MH][MW];
    private final boolean[] zoneOpen = new boolean[16];
    private final List<Win> wins = new ArrayList<>();
    private final List<int[]> doors = new ArrayList<>();            // x, y, price, zone A, zone B
    private final List<int[]> stations = new ArrayList<>();         // x, y, index of the gun sold there
    private final List<int[]> boxes = new ArrayList<>();            // x, y, and the floor tile in front of the mystery box
    private final List<int[]> secrets = new ArrayList<>();          // x, y of the cracked walls
    private final List<int[]> machines = new ArrayList<>();         // x, y, kind (0 power switch, 1 Pack-a-Punch, 2-7 perk 0-5)
    private final int[] zoneColor = new int[16];
    private int streetZone = -1;
    private boolean fogOn;                                           // outdoors: far things fade into the orange haze
    private static final int FOG = 0xFF9A5224;
    private double lowRaw, lowWX;                                    // the first low wall (car, fence, crate) a ray passes over
    private boolean lowSide;
    private int lowType;
    private final double[] lowDz = new double[COLS];
    private final int[] lowTy = new int[COLS];
    private static boolean isLow(int t) { return t == 2 || t == 22 || t == 23; }
    private static double lowFrac(int t) { return t == 23 ? 0.55 : t == 22 ? 0.5 : 0.45; }
    // decorations that nothing collides with: x, y, kind (0 traffic light, 1 street lamp, 2 fire)
    private static final double[][] PROPS = {{26.5, 16.5, 0}, {37.5, 16.5, 0}, {26.5, 27.5, 0}, {37.5, 27.5, 0},
            {12.5, 17.5, 1}, {51.5, 17.5, 1}, {31.5, 7.5, 1}, {31.5, 36.5, 1}, {20.5, 26.5, 1}, {43.5, 26.5, 1},
            {14.5, 24.5, 2}, {24.5, 18.5, 2}, {40.5, 22.5, 2}, {30.5, 14.5, 2}, {33.5, 23.5, 2}, {22.5, 21.5, 2},
            {47.5, 17.5, 2}, {29.5, 30.5, 2}, {35.5, 9.5, 2}, {17.5, 18.5, 2}, {53.5, 22.5, 2}, {31.5, 19.5, 2}};                                    // the open crossroads: sky above, cracked burning asphalt below
    private final List<Zombie> zombies = new ArrayList<>();
    private final java.util.Set<Zombie> shotHit = new java.util.HashSet<>();   // zombies already paid for in the current shot
    //                                         color       auto   inf   mag res dmg rate rl  pel prc push  splash cost ammo
    private final Weapon pistol  = new Weapon(0xFFB0B0B8, false, false,  8,  48, 2, 16,  70, 1, 1, 0.10, 0,   0,   0);   // not infinite: 8 + 48 bullets
    private final Weapon rifle   = new Weapon(0xFF8AA070, true,  false, 30, 120, 3,  6, 100, 1, 1, 0.05, 0, 500, 250);
    private final Weapon shotgun = new Weapon(0xFFB07A44, false, false,  6,  24, 2, 42, 110, 6, 1, 0.16, 0, 1500, 750);
    private final Weapon smg     = new Weapon(0xFF5ADC70, true,  false, 40, 200, 2,  5,  80, 1, 1, 0.04, 0, 1000, 500);
    private final Weapon magnum  = new Weapon(0xFFF08A50, false, false,  6,  36, 7, 26,  90, 1, 1, 0.12, 0, 1200, 600);
    private final Weapon sniper  = new Weapon(0xFFB070F0, false, false,  5,  30, 14, 45, 130, 1, 3, 0.20, 0, 2000, 1000);
    private final Weapon ray     = new Weapon(0xFF4AF0E0, true,  false, 20, 160, 6, 12,  90, 1, 1, 0.08, 1.4, -1, 0);   // only from the mystery box
    // the new guns only come out of the mystery box
    private final Weapon lmg      = new Weapon(0xFFE0A040, true,  false, 100, 300, 3,  4, 200, 1, 1, 0.05, 0,   -1, 0);
    private final Weapon combat   = new Weapon(0xFFE07050, true,  false,   8,  40, 2, 16, 120, 5, 1, 0.12, 0,   -1, 0);
    private final Weapon launcher = new Weapon(0xFF90D050, false, false,   4,  20, 9, 36, 150, 1, 1, 0.35, 2.2, -1, 0);
    private final Weapon railgun  = new Weapon(0xFF60A0FF, false, false,   4,  24, 18, 40, 140, 1, 8, 0.25, 0,  -1, 0);
    private final Weapon minigun  = new Weapon(0xFFB0B0B8, true,  false, 150, 450, 2,  2, 260, 1, 1, 0.03, 0,   -1, 0);
    // junk guns: bad on purpose, the box gamble (like the bad guns in CoD Zombies)
    private final Weapon waterGun = new Weapon(0xFF60C0FF, true,  false, 30, 90, 1,  5,  70, 1, 1, 0.01, 0,   -1, 0);
    private final Weapon dartGun  = new Weapon(0xFFFF8040, false, false, 12, 48, 1,  8,  60, 1, 1, 0.02, 0,   -1, 0);
    private final Weapon musket   = new Weapon(0xFF8A5A2A, false, false,  1, 12, 6, 20, 170, 1, 2, 0.20, 0,   -1, 0);
    private final Weapon sling    = new Weapon(0xFFC0A060, false, true,   1,  0, 2, 24,  50, 1, 1, 0.10, 0,   -1, 0);
    private final Weapon flare    = new Weapon(0xFFFF4040, false, false,  1, 10, 4, 25, 130, 1, 1, 0.25, 1.2, -1, 0);
    private final Weapon[] weapons = {pistol, rifle, shotgun, smg, magnum, sniper, ray, lmg, combat, launcher, railgun, minigun,
            waterGun, dartGun, musket, sling, flare};
    private static final int JUNK_FROM = 12;                          // weapons[12..] are the junk guns
    /** What the mystery box can give (indexes into weapons) and how likely each one is (sums to 100). */
    private static final int[] BOX_GUNS = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
    private static final int[] BOX_WTS  = {11, 9, 9, 8, 6, 5, 7, 6, 6, 4, 4, 6, 5, 5, 5, 4};
    private final int[] perk = new int[PERKS];                // 1 = you have the perk (Quick Revive, Speed Cola, Stamin-Up, Juggernog, Double Tap II, Mule Kick)
    private final PerkMusic perkMusic = new PerkMusic();      // the tunes of the perk machines
    private int reviveT;                                       // after Quick Revive saves you: a short time when nothing can hurt you
    private final List<double[]> mineList = new ArrayList<>(), spits = new ArrayList<>(), blasts = new ArrayList<>(), drops = new ArrayList<>();
    private int[] offer = new int[0];
    private boolean offering;
    private int offerT, mines, seenKinds;

    private double px, py, ang, hp, turnV, pitch;
    private Weapon cur;
    private final Weapon[] slot = new Weapon[3];                // you carry two guns, three with Mule Kick (slot[2] is only used then)
    private boolean trigPrev;
    private int round, toSpawn, spawned, spawnT, breakT, kills, points;
    private int cool, reload, reloadMax, kick, flashT, hit, headT, hurtT, noHurt, ticks, msgT, walkT, swapT;
    private int instaT, dblT, nukeT, repT, repPts, dropsRound, sinceDrop;
    private boolean power;                                     // the power switch has been pulled
    private int tKind, tIdx;                                   // what E would do right now: 0 nothing, 1 gun wall, 2 door, 3 window, 4 mystery box, 5 cracked wall, 6 machine / switch
    private int lastPts = START_PTS, shownPts = START_PTS, popAmt, popT;     // the HUD: the points count up, and a +60 / -950 pops up next to them
    private Weapon papGun;                                         // the gun that is in Pack-a-Punch
    private int papState, papT;                                   // 0 free, 1 working (5 s), 2 the gun is ready and waits for you (15 s)
    private int boxShow = 1, boxCyc;                             // the gun that is shown while the box rolls, and the time until the next one
    private int boxState, boxT, boxW;                           // mystery box: 0 closed, 1 rolling, 2 a gun is waiting (boxW, -1 = teddy bear), 3 the teddy bear is shown
    private int hor = H / 2;                                   // the horizon line on the screen (moves when you look up / down)
    private String msg = "";
    private double lastDist, lastWallX, lastWinDist;
    private int lastType, lastTX, lastTY;
    private boolean lastSide, lastWinSide;

    // ---------- setup ----------
    @Override
    public void reset() {
        score = 0; over = false; round = 1; kills = 0; points = START_PTS; ticks = 0; msgT = 0; breakT = 0;
        turnV = 0; pitch = 0; hp = 100; hurtT = 0; noHurt = 0; kick = 0; flashT = 0; hit = 0; headT = 0; reload = 0; cool = 40; walkT = 0; swapT = 0;
        instaT = 0; dblT = 0; nukeT = 0; repT = 0; repPts = 0; dropsRound = 0; sinceDrop = 0;
        trigPrev = true; boxState = 0; boxT = 0; boxShow = 1; boxCyc = 0;
        lastPts = shownPts = points; popAmt = 0; popT = 0;
        for (Weapon w : weapons) { w.resetStats(); w.mag = w.magSize; w.reserve = w.maxReserve; w.owned = false; }
        pistol.owned = true;
        slot[0] = pistol; slot[1] = null; slot[2] = null;
        power = false;
        Arrays.fill(perk, 0);
        reviveT = 0;
        perkMusic.reset();
        papGun = null; papState = 0; papT = 0;
        mineList.clear(); spits.clear(); blasts.clear(); drops.clear();
        mines = 0; offering = false; seenKinds = 0;
        cur = pistol;
        zombies.clear();
        buildLevel();
        px = 31.5; py = 21.5; ang = -Math.PI / 2;
        zoneOpen[zoneOf[(int) py][(int) px]] = true;
        buildFlow();
        startRound();
        say("cutemod.zombies.start");
    }

    /** Reads LEVEL: tiles, rooms (zones), doors, stations and windows with their pockets. */
    private void buildLevel() {
        wins.clear(); doors.clear(); stations.clear(); boxes.clear(); secrets.clear(); machines.clear();
        Arrays.fill(zoneOpen, false);
        for (int y = 0; y < MH; y++) {
            Arrays.fill(zoneOf[y], -1);
            Arrays.fill(winIdx[y], -1);
            for (int x = 0; x < MW; x++) {
                char c = LEVEL[y].charAt(x);
                pocket[y][x] = c == 'p';
                map[y][x] = switch (c) {
                    case '#' -> 1; case 'c' -> 2; case 'S' -> 3; case 'T' -> 4; case 'U' -> 8; case 'G' -> 9; case 'K' -> 10;
                    case 'X' -> 11; case 'Z' -> 12; case 'W' -> 6;
                    case 'f' -> 22; case 'v' -> 23; case 'h' -> 24;
                    case 'L' -> 13; case 'P' -> 14;
                    case 'A', 'B', 'C', 'D', 'E', 'F' -> 15 + (c - 'A');
                    default -> c >= '1' && c <= '4' ? 5 : 0;
                };
                int gun = c == 'S' ? 1 : c == 'T' ? 2 : c == 'U' ? 3 : c == 'G' ? 4 : c == 'K' ? 5 : 0;
                if (gun > 0) stations.add(new int[]{x, y, gun});
                if (c == 'Z') secrets.add(new int[]{x, y});
                if (c == 'L') machines.add(new int[]{x, y, 0});
                if (c == 'P') machines.add(new int[]{x, y, 1});
                if (c >= 'A' && c <= 'F') machines.add(new int[]{x, y, 2 + (c - 'A')});
                if (c >= '1' && c <= '4') doors.add(new int[]{x, y, DOOR_COST[c - '0'], -1, -1});
            }
        }
        int zones = 0;                                           // rooms: flood fill over the floor
        for (int y = 0; y < MH; y++) {
            for (int x = 0; x < MW; x++) {
                if (map[y][x] != 0 || pocket[y][x] || zoneOf[y][x] >= 0) continue;
                ArrayDeque<int[]> q = new ArrayDeque<>();
                zoneOf[y][x] = zones;
                q.add(new int[]{x, y});
                while (!q.isEmpty()) {
                    int[] c = q.poll();
                    for (int[] d : DIRS) {
                        int nx = c[0] + d[0], ny = c[1] + d[1];
                        if (inb(nx, ny) && map[ny][nx] == 0 && !pocket[ny][nx] && zoneOf[ny][nx] < 0) { zoneOf[ny][nx] = zones; q.add(new int[]{nx, ny}); }
                    }
                }
                zones++;
            }
        }
        for (int y = 0; y < MH; y++) {                           // windows and the pockets behind them
            for (int x = 0; x < MW; x++) {
                if (map[y][x] != 6) continue;
                Win w = new Win();
                w.x = x; w.y = y; w.ix = x; w.iy = y; w.zone = 0;
                int idx = wins.size();
                winIdx[y][x] = idx;
                ArrayDeque<int[]> q = new ArrayDeque<>();
                for (int[] d : DIRS) {
                    int nx = x + d[0], ny = y + d[1];
                    if (!inb(nx, ny)) continue;
                    if (map[ny][nx] == 0 && !pocket[ny][nx]) { w.ix = nx; w.iy = ny; w.zone = zoneOf[ny][nx]; }
                    else if (pocket[ny][nx] && winIdx[ny][nx] < 0) { winIdx[ny][nx] = idx; q.add(new int[]{nx, ny}); }
                }
                while (!q.isEmpty()) {
                    int[] c = q.poll();
                    w.pocket.add(c);
                    for (int[] d : DIRS) {
                        int nx = c[0] + d[0], ny = c[1] + d[1];
                        if (inb(nx, ny) && pocket[ny][nx] && winIdx[ny][nx] < 0) { winIdx[ny][nx] = idx; q.add(new int[]{nx, ny}); }
                    }
                }
                wins.add(w);
            }
        }
        for (int y = 0; y < MH; y++) {                           // the mystery box and the floor in front of it
            for (int x = 0; x < MW; x++) {
                if (map[y][x] != 11) continue;
                for (int[] d : DIRS) {
                    int nx = x + d[0], ny = y + d[1];
                    if (inb(nx, ny) && map[ny][nx] == 0 && !pocket[ny][nx]) { boxes.add(new int[]{x, y, nx, ny}); break; }
                }
            }
        }
        Arrays.fill(zoneColor, 0xFF5A5A5A);                      // every room has its own floor color
        for (int[] a : ZONE_ANCHOR) if (zoneOf[a[1]][a[0]] >= 0) zoneColor[zoneOf[a[1]][a[0]] & 15] = a[2];
        streetZone = zoneOf[ZONE_ANCHOR[0][1]][ZONE_ANCHOR[0][0]];
        for (int[] dr : doors) {                                 // which two rooms a door joins
            for (int[] d : DIRS) {
                int nx = dr[0] + d[0], ny = dr[1] + d[1];
                if (!inb(nx, ny) || zoneOf[ny][nx] < 0) continue;
                if (dr[3] < 0) dr[3] = zoneOf[ny][nx];
                else if (zoneOf[ny][nx] != dr[3]) dr[4] = zoneOf[ny][nx];
            }
        }
    }

    private void startRound() {
        toSpawn = 5 + 3 * round;
        spawned = 0;
        spawnT = 90;
        repPts = 0;
        dropsRound = 0;
        if (round > 1 && ammoLeft() == 0) {                       // nothing left in either gun: a few last bullets so you are never stuck
            Weapon w = slot[0] != null ? slot[0] : pistol;
            w.mag = Math.min(w.magSize, 8);
            say("cutemod.zombies.last_ammo");
            return;
        }
        say("cutemod.zombies.round", round);
    }

    /** All the bullets in the guns you carry. */
    private int ammoLeft() {
        int n = 0;
        for (Weapon w : slot) if (w != null) n += w.mag + (w.infinite ? 999 : w.reserve);
        return n;
    }

    private void say(String key, Object... args) {
        msg = Component.translatable(key, args).getString();
        msgT = 150;
    }

    // ---------- helpers ----------
    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private static boolean lmb() {
        return GLFW.glfwGetMouseButton(Minecraft.getInstance().getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    private static void snd(SoundEvent e, float pitch, float vol) {
        dev.cutemod.client.os.Sfx.gameSound(e, pitch, vol);
    }

    private static void snd(Holder<SoundEvent> h, float pitch, float vol) { snd(h.value(), pitch, vol); }

    // ---------- gun sounds: our own "gun.<name>" events (tools/make_gun_audio.py) ----------
    private static final java.util.Map<String, SoundEvent> GUN_SND = new java.util.HashMap<>();
    private static void gun(String name, float pitch, float vol) {
        snd(GUN_SND.computeIfAbsent(name, n -> SoundEvent.createVariableRangeEvent(
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(dev.cutemod.CuteMod.MOD_ID, "gun." + n))), pitch, vol);
    }
    /** The shot of every gun, in the order of the weapons array. */
    private static final String[] SHOT = {"shot_pistol", "shot_rifle", "shot_shotgun", "shot_smg", "shot_magnum", "shot_sniper", "shot_ray",
            "shot_lmg", "shot_combat", "shot_launcher", "shot_railgun", "shot_minigun", "shot_water", "shot_dart", "shot_musket", "shot_sling", "shot_flare"};
    private static final float[] SHOT_VOL = {0.9F, 0.9F, 1.0F, 0.7F, 1.0F, 1.0F, 0.8F, 0.85F, 1.0F, 1.0F, 0.9F, 0.55F, 0.7F, 0.7F, 1.0F, 0.7F, 0.9F};
    /** The reload, in stages: "percent of the reload time, sound". Every sound is a short one made by tools/make_gun_audio.py. */
    private static final String[][] RELOAD = {
            {"5 mag_out", "55 mag_in", "80 slide"},                                                  // pistol
            {"5 mag_out", "50 mag_in", "80 slide"},                                                  // rifle
            {"12 shell", "27 shell", "42 shell", "57 shell", "85 pump"},                            // shotgun
            {"5 mag_out", "50 mag_in", "80 slide"},                                                  // smg
            {"5 cyl_open", "22 shell", "45 shell", "58 shell", "70 shell", "88 cyl_close"},         // magnum
            {"5 bolt_open", "40 mag_in", "55 shell", "80 bolt_close"},                               // sniper
            {"5 charge", "90 ready"},                                                                // ray gun
            {"5 box_open", "25 mag_out", "40 belt", "78 box_close", "92 slide"},                     // lmg
            {"5 mag_out", "55 mag_in", "85 slide"},                                                  // combat shotgun (drum)
            {"8 latch", "45 tube_in", "90 latch"},                                                   // launcher
            {"5 charge", "90 ready"},                                                                // railgun
            {"5 box_open", "30 belt", "55 belt", "85 box_close"},                                    // minigun
            {"5 gurgle", "62 pump_toy", "76 pump_toy", "90 pump_toy"},                               // water gun
            {"5 plastic", "50 mag_in", "85 plastic"},                                                // dart blaster
            {"5 ramrod", "55 tamp", "67 tamp", "88 latch"},                                          // musket
            {"5 creak", "55 tamp", "85 creak"},                                                      // slingshot
            {"5 cyl_open", "50 shell", "88 cyl_close"}};                                             // flare gun

    private void earn(int n) {
        int v = n * (dblT > 0 ? 2 : 1);                                              // double points
        points += v;
        score += v;
    }

    private static boolean inb(int x, int y) { return x >= 0 && y >= 0 && x < MW && y < MH; }

    /** The player (and spit) can only stand on plain floor. */
    private boolean free(double x, double y) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        return inb(ix, iy) && map[iy][ix] == 0;
    }

    /** Zombies can also climb through a window with no boards left. */
    private boolean zfree(double x, double y) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        return inb(ix, iy) && (map[iy][ix] == 0 || map[iy][ix] == 7);
    }

    private void move(double dx, double dy) {
        double r = 0.22;
        if (free(px + dx + Math.signum(dx) * r, py)) px += dx;
        if (free(px, py + dy + Math.signum(dy) * r)) py += dy;
    }

    /** Distance to the first wall along a direction (also remembers which wall it was). Open windows do not stop the ray. */
    private double ray(double a) {
        double rdx = Math.cos(a), rdy = Math.sin(a);
        int mapX = (int) px, mapY = (int) py;
        double ddx = Math.abs(1 / rdx), ddy = Math.abs(1 / rdy), sdx, sdy;
        int stepX, stepY;
        if (rdx < 0) { stepX = -1; sdx = (px - mapX) * ddx; } else { stepX = 1; sdx = (mapX + 1 - px) * ddx; }
        if (rdy < 0) { stepY = -1; sdy = (py - mapY) * ddy; } else { stepY = 1; sdy = (mapY + 1 - py) * ddy; }
        boolean side = false;
        lastWinDist = -1;
        lowRaw = -1;
        while (map[mapY][mapX] == 0 || map[mapY][mapX] == 7 || isLow(map[mapY][mapX])) {     // low walls: you look (and shoot) over them
            double entry;
            if (sdx < sdy) { entry = sdx; sdx += ddx; mapX += stepX; side = false; }
            else { entry = sdy; sdy += ddy; mapY += stepY; side = true; }
            if (lastWinDist < 0 && map[mapY][mapX] == 7) { lastWinDist = entry; lastWinSide = side; }
            if (lowRaw < 0 && isLow(map[mapY][mapX])) {
                lowRaw = entry; lowSide = side; lowType = map[mapY][mapX];
                double lw = side ? px + entry * rdx : py + entry * rdy;
                lowWX = lw - Math.floor(lw);
            }
        }
        double dist = Math.max(0.05, side ? sdy - ddy : sdx - ddx);
        lastType = map[mapY][mapX];
        lastTX = mapX;
        lastTY = mapY;
        lastSide = side;
        double wx = side ? px + dist * rdx : py + dist * rdy;
        lastWallX = wx - Math.floor(wx);
        return dist;
    }

    // ---------- shooting ----------
    private int dmgOf(Weapon w) { return w.dmg; }

    private void shotSound() {
        int gi = curIndex();
        gun(SHOT[gi], 0.96F + rnd.nextFloat() * 0.08F, SHOT_VOL[gi]);
    }

    private void fire() {
        if (reload > 0 || cool > 0) return;
        if (cur.mag <= 0) { startReload(); if (reload == 0) { gun("dry", 1F, 0.7F); cool = 12; } return; }
        cur.mag--;
        shotHit.clear();
        cool = perk[P_TAP] > 0 ? Math.max(1, cur.rate * 2 / 3) : cur.rate;      // Double Tap II: 1.5 times the rate of fire
        kick = cur.pellets > 1 ? 11 : cur == sniper || cur == launcher || cur == railgun ? 12 : cur == minigun ? 2 : cur == lmg ? 3 : cur == magnum ? 9 : cur == pistol ? 7 : cur == smg ? 3 : 4;
        flashT = (cur == waterGun || cur == dartGun || cur == sling) ? 0 : 3;     // toys have no muzzle flash
        shotSound();
        for (int i = 0; i < cur.pellets; i++) {                // the shotgun throws 6 pellets in a small cone
            double a = cur.pellets > 1 ? ang + (rnd.nextDouble() - 0.5) * 0.24 : ang;
            double dv = cur.pellets > 1 ? (rnd.nextDouble() - 0.5) * 0.22 : 0;
            shootRay(a, dmgOf(cur), dv, cur.push, cur.pierce, cur.splash);
        }
        if (cur.mag == 0) startReload();
    }

    /**
     * One bullet along an angle: hits the nearest zombies in front of the first wall (pierce = how many it goes through).
     * The bullet flies at the height of the crosshair, which depends on how far you look up or down:
     * a wall is 1.0 high and your eyes are at 0.5. The top of a zombie is its head: twice the damage.
     * splash > 0 (the ray gun) also hurts the zombies standing next to the one that was hit.
     */
    private void shootRay(double a, int dmg, double dv, double push, int pierce, double splash) {
        double wall = ray(a);
        double c = Math.cos(a), s = Math.sin(a);
        Zombie[] zs = zombies.toArray(new Zombie[0]);
        List<double[]> cand = new ArrayList<>();               // distance along the bullet, head (1 / 0), index
        for (int i = 0; i < zs.length; i++) {
            Zombie z = zs[i];
            double dx = z.x - px, dy = z.y - py;
            double f = dx * c + dy * s;
            if (f < 0.1 || f > wall) continue;
            if (Math.abs(-dx * s + dy * c) >= z.radius()) continue;
            double h = 0.5 + pitch * f / H + dv * f;
            double size = KIND_SIZE[z.kind];
            if (h < 0 || h > size + 0.03) continue;             // over or under it
            cand.add(new double[]{f, h >= size * HEAD ? 1 : 0, i});
        }
        if (cand.isEmpty()) return;
        cand.sort((p, q) -> Double.compare(p[0], q[0]));
        hit = 8;
        for (int k = 0; k < Math.min(pierce, cand.size()); k++) {
            Zombie best = zs[(int) cand.get(k)[2]];
            boolean head = cand.get(k)[1] > 0;
            int d = dmg;
            if (head) {
                d = (int) Math.ceil(dmg * (best.kind == 2 ? 1.5 : 2.0));
                headT = 40;
                snd(SoundEvents.PLAYER_ATTACK_CRIT, 1.5F, 0.5F);
            }
            double bx = best.x, by = best.y;
            damage(best, d, head, shotHit.add(best));
            if (best.hp > 0) knock(best, c, s, push);
            if (splash > 0) {
                blasts.add(new double[]{bx, by, 8});
                for (Zombie o : new ArrayList<>(zombies)) {
                    if (o != best && Math.hypot(o.x - bx, o.y - by) < splash) damage(o, Math.max(1, d / 2), false, shotHit.add(o));
                }
            }
        }
    }

    /** hitPts: this bullet pays the 10 points for hurting (the killing shot pays 60 / 100 instead). */
    private void damage(Zombie z, int dmg, boolean head, boolean hitPts) {
        if (z.hp <= 0) return;
        if (instaT > 0) dmg = Math.max(dmg, z.hp);
        z.hp -= dmg;
        z.flash = 6;
        if (z.hp <= 0) {
            zombies.remove(z);
            kills++;
            earn(head ? HEAD_PTS : KILL_PTS);
            snd(SoundEvents.ZOMBIE_DEATH, z.kind == 2 ? 0.6F : 1.0F, 0.6F);
            maybeDrop(z);
        } else {
            if (hitPts) earn(HIT_PTS);
            snd(SoundEvents.ZOMBIE_HURT, z.kind == 1 ? 1.5F : 1.2F, 0.5F);
        }
    }

    /** A hit shoves the zombie back along the bullet and makes it stagger for a moment (tanks hardly move). */
    private void knock(Zombie z, double dx, double dy, double amt) {
        if (z.kind == 2) amt *= 0.35;
        double nx = z.x + dx * amt, ny = z.y + dy * amt;
        if (zfree(nx, z.y)) z.x = nx;
        if (zfree(z.x, ny)) z.y = ny;
        z.stun = Math.max(z.stun, (int) (amt * 40));
    }

    private void startReload() {
        if (reload > 0 || cur.mag >= cur.magSize || (!cur.infinite && cur.reserve <= 0)) return;
        reload = perk[P_COLA] > 0 ? Math.max(10, cur.reloadTime / 2) : Math.max(20, cur.reloadTime);        // Speed Cola: twice as fast
        reloadMax = reload;
    }

    private void finishReload() {
        int need = cur.magSize - cur.mag;
        int take = cur.infinite ? need : Math.min(need, cur.reserve);
        cur.mag += take;
        if (!cur.infinite) cur.reserve -= take;
    }

    private void select(Weapon w) {
        if (!w.owned) return;
        if (cur != w) { cur = w; reload = 0; cool = 12; swapT = 10; }
    }

    /** Q: the other gun. */
    private void cycle() {
        int n = slots(), at = 0;
        for (int i = 0; i < n; i++) if (slot[i] == cur) at = i;
        for (int k = 1; k < n; k++) {
            Weapon w = slot[(at + k) % n];
            if (w != null) { select(w); return; }
        }
    }

    /** How many guns you can carry: 2, or 3 with Mule Kick. */
    private int slots() { return perk[P_MULE] > 0 ? 3 : 2; }

    private boolean slotsFull() {
        for (int i = 0; i < slots(); i++) if (slot[i] == null) return false;
        return true;
    }

    // ---------- what is in reach: gun walls, doors, windows, the mystery box ----------
    private boolean nearStation() {
        for (int[] s : stations) if (Math.hypot(px - (s[0] + 0.5), py - (s[1] + 0.5)) < 2.3) return true;
        return false;
    }

    /** Works out what E does here: the nearest of a gun wall, the mystery box, a cracked wall, a closed door or a damaged window. */
    private void findTarget() {
        tKind = 0;
        tIdx = -1;
        double best = 1e9;
        for (int i = 0; i < stations.size(); i++) {
            int[] s = stations.get(i);
            double d = Math.hypot(px - (s[0] + 0.5), py - (s[1] + 0.5));
            if (d < 2.3 && d < best) { best = d; tKind = 1; tIdx = i; }
        }
        for (int i = 0; i < boxes.size(); i++) {
            int[] b = boxes.get(i);
            double d = Math.hypot(px - (b[0] + 0.5), py - (b[1] + 0.5));
            if (d < 2.3 && d < best) { best = d; tKind = 4; tIdx = i; }
        }
        for (int i = 0; i < secrets.size(); i++) {
            int[] sc = secrets.get(i);
            if (map[sc[1]][sc[0]] != 12) continue;
            double d = Math.hypot(px - (sc[0] + 0.5), py - (sc[1] + 0.5));
            if (d < 1.8 && d < best) { best = d; tKind = 5; tIdx = i; }
        }
        for (int i = 0; i < machines.size(); i++) {
            int[] m = machines.get(i);
            if (m[2] == 0 && power) continue;
            double d = Math.hypot(px - (m[0] + 0.5), py - (m[1] + 0.5));
            if (d < 2.0 && d < best) { best = d; tKind = 6; tIdx = i; }
        }
        for (int i = 0; i < doors.size(); i++) {
            int[] dr = doors.get(i);
            if (map[dr[1]][dr[0]] != 5) continue;
            double d = Math.hypot(px - (dr[0] + 0.5), py - (dr[1] + 0.5));
            if (d < 2.0 && d < best) { best = d; tKind = 2; tIdx = i; }
        }
        for (int i = 0; i < wins.size(); i++) {
            Win w = wins.get(i);
            if (w.boards >= MAX_BOARDS) continue;
            double d = Math.hypot(px - (w.x + 0.5), py - (w.y + 0.5));
            if (d < 1.8 && d < best) { best = d; tKind = 3; tIdx = i; }
        }
    }

    private boolean zombieNear(Win w, double r) {
        for (Zombie z : zombies) if (Math.hypot(z.x - (w.x + 0.5), z.y - (w.y + 0.5)) < r) return true;
        return false;
    }

    private void buy() {
        findTarget();
        switch (tKind) {
            case 1 -> buyStation(stations.get(tIdx)[2]);
            case 2 -> openDoor(doors.get(tIdx));
            case 4 -> useBox();
            case 5 -> openSecret(secrets.get(tIdx));
            case 6 -> useMachine(machines.get(tIdx));
            default -> { }
        }
    }

    private static String gunName(int wi) {
        return Component.translatable("cutemod.zombies.w." + wi).getString();
    }

    private int heldGuns() {
        int n = 0;
        for (int i = 0; i < slots(); i++) if (slot[i] != null) n++;
        return n;
    }

    private int indexOf(Weapon w) {
        for (int i = 0; i < weapons.length; i++) if (weapons[i] == w) return i;
        return 0;
    }

    /** Pack-a-Punch is done and you take the gun: it goes into a free slot (or replaces the gun in your hands). */
    private void takePap() {
        Weapon w = papGun;
        if (w == null) { papState = 0; return; }
        int at = -1;
        for (int i = 0; i < slots() && at < 0; i++) if (slot[i] == null) at = i;
        if (at < 0) { at = 0; for (int i = 0; i < slots(); i++) if (slot[i] == cur) at = i; }
        Weapon old = slot[at];
        if (old != null) { old.owned = false; old.resetStats(); old.mag = old.magSize; old.reserve = old.maxReserve; }
        slot[at] = w;
        cur = w; reload = 0; cool = 12; swapT = 10;
        papGun = null; papState = 0;
        say("cutemod.zombies.pap_done", gunName(indexOf(w)));
        pling(2.0F);
        perkMusic.jingle(6);                                       // the tune of Pack-a-Punch
    }

    /** Buy a gun at its wall, or its ammo if you already own it. */
    private void buyStation(int wi) {
        Weapon w = weapons[wi];
        if (w == papGun) { say("cutemod.zombies.pap_busy"); beep(); return; }
        if (!w.owned) {
            if (points < w.cost) { say("cutemod.zombies.poor"); beep(); return; }
            points -= w.cost;
            giveGun(wi);
            pling(1.6F);
        } else {
            if (w.reserve >= w.maxReserve && w.mag >= w.magSize) { say("cutemod.zombies.full"); return; }
            if (points < w.ammoCost) { say("cutemod.zombies.poor"); beep(); return; }
            points -= w.ammoCost;
            w.reserve = w.maxReserve;
            w.mag = w.magSize;
            say("cutemod.zombies.ammo");
            pling(1.3F);
        }
    }

    /** A gun goes into a free slot; with all slots full it replaces the gun in your hands (that one is gone, with its Pack-a-Punch). */
    private void giveGun(int wi) {
        Weapon w = weapons[wi];
        if (w == papGun) { say("cutemod.zombies.pap_busy"); return; }          // that gun is in Pack-a-Punch right now
        if (w.owned) {                                           // you already carry it: just fill it up
            w.mag = w.magSize;
            w.reserve = w.maxReserve;
            select(w);
            say("cutemod.zombies.ammo");
            return;
        }
        int at = -1;                                             // a free slot, or the one in your hands
        for (int i = 0; i < slots() && at < 0; i++) if (slot[i] == null) at = i;
        if (at < 0) { at = 0; for (int i = 0; i < slots(); i++) if (slot[i] == cur) at = i; }
        Weapon old = slot[at];
        if (old != null) {
            old.owned = false;
            old.resetStats();
            old.mag = old.magSize;
            old.reserve = old.maxReserve;
        }
        slot[at] = w;
        w.owned = true;
        w.mag = w.magSize;
        w.reserve = w.maxReserve;
        cur = w;
        reload = 0;
        cool = 12;
        swapT = 10;
        say(wi >= JUNK_FROM ? "cutemod.zombies.junk" : "cutemod.zombies.got", gunName(wi));
    }

    /** The mystery box: pay, the lid opens and the guns flip over a beam of light for 5 s (a music box plays), then the gun waits for you for 6 s;
     *  or a teddy bear laughs at you and your points come back. */
    private void useBox() {
        if (boxState == 0) {
            if (points < BOX_COST) { say("cutemod.zombies.poor"); beep(); return; }
            points -= BOX_COST;
            boxState = 1;
            boxT = BOX_ROLL;
            boxShow = 1 + rnd.nextInt(6);
            boxCyc = 4;
            if (rnd.nextInt(100) < 8) boxW = -1;                 // the teddy bear
            else {
                int r = rnd.nextInt(100), i = 0;
                while (r >= BOX_WTS[i]) { r -= BOX_WTS[i]; i++; }
                boxW = BOX_GUNS[i];
            }
            snd(SoundEvents.WOODEN_DOOR_OPEN, 0.5F, 0.7F);
            PerkMusic.box("box_open");                                // the lid creaks open, then the music box plays while it rolls
            PerkMusic.box("box_roll");
        } else if (boxState == 2) {
            giveGun(boxW);
            boxState = 0;
            pling(1.9F);
        }
    }

    private int curIndex() {
        for (int i = 0; i < weapons.length; i++) if (weapons[i] == cur) return i;
        return 0;
    }

    private static String perkName(int p) {
        return Component.translatable("cutemod.zombies.perk." + p + ".name").getString();
    }

    /** The power switch, Pack-a-Punch and the perk machines (the last two only work with the power on). */
    private void useMachine(int[] m) {
        if (m[2] == 0) {
            power = true;
            map[m[1]][m[0]] = 21;
            say("cutemod.zombies.power_on");
            snd(SoundEvents.LEVER_CLICK, 0.8F, 0.9F);
            pling(0.9F);
            return;
        }
        if (!power) { say("cutemod.zombies.power_off"); beep(); return; }
        if (m[2] == 1) {                                         // Pack-a-Punch, like in CoD: pay, the gun goes in, 5 seconds, take it out
            if (papState == 2) { takePap(); return; }
            if (papState == 1) { say("cutemod.zombies.pap_working"); beep(); return; }
            if (cur.pap) { say("cutemod.zombies.pap_again"); return; }
            if (heldGuns() < 2) { say("cutemod.zombies.pap_need"); beep(); return; }
            if (points < PAP_COST) { say("cutemod.zombies.poor"); beep(); return; }
            points -= PAP_COST;
            papGun = cur;
            for (int i = 0; i < slot.length; i++) if (slot[i] == cur) slot[i] = null;   // the gun leaves your hands...
            for (int i = 0; i < slot.length; i++) if (slot[i] != null) { cur = slot[i]; break; }   // ...you hold your other gun
            reload = 0; cool = 12; swapT = 10;
            papState = 1; papT = 300;
            say("cutemod.zombies.pap_start", gunName(indexOf(papGun)));
            snd(SoundEvents.ANVIL_USE, 1.0F, 0.6F);
            PerkMusic.fx("pap_work");
            return;
        }
        int p = m[2] - 2;
        if (perk[p] > 0) { say("cutemod.zombies.perk_max", perkName(p)); return; }
        int cost = PERK_COST[p];
        if (points < cost) { say("cutemod.zombies.poor"); beep(); return; }
        points -= cost;
        perk[p] = 1;
        if (p == P_JUGG) hp = Math.min(maxHp(), hp + (JUGG_HP - BASE_HP));
        say("cutemod.zombies.perk_got", perkName(p));
        snd(SoundEvents.BOTTLE_FILL, 1.0F, 0.9F);
        perkMusic.jingle(p);                                       // every machine has its own tune
    }

    private void openSecret(int[] sc) {
        map[sc[1]][sc[0]] = 0;
        say("cutemod.zombies.secret_found");
        snd(SoundEvents.WOOD_BREAK, 0.6F, 0.9F);
        pling(1.5F);
    }

    private void openDoor(int[] dr) {
        if (points < dr[2]) { say("cutemod.zombies.poor"); beep(); return; }
        points -= dr[2];
        map[dr[1]][dr[0]] = 0;
        if (dr[3] >= 0) zoneOpen[dr[3]] = true;                  // the zombies of the new room start coming
        if (dr[4] >= 0) zoneOpen[dr[4]] = true;
        say("cutemod.zombies.door_open");
        snd(SoundEvents.WOODEN_DOOR_OPEN, 0.7F, 0.8F);
        pling(1.2F);
    }

    private void repair(Win w) {
        if (w.boards >= MAX_BOARDS) return;
        w.boards++;
        snd(SoundEvents.WOOD_PLACE, 0.9F + rnd.nextFloat() * 0.3F, 0.8F);
        if (repPts < 240) { repPts += BOARD_PTS; earn(BOARD_PTS); }            // only a few points per round, so it cannot be farmed
    }

    private void buyMines() {
        if (!nearStation()) return;
        if (mines >= MAX_MINES) { say("cutemod.zombies.mines_full"); return; }
        if (points < MINE_COST) { say("cutemod.zombies.poor"); beep(); return; }
        points -= MINE_COST;
        mines = Math.min(MAX_MINES, mines + 3);
        say("cutemod.zombies.mines_bought");
        pling(1.4F);
    }

    private void placeMine() {
        if (mines <= 0) { say("cutemod.zombies.nomines"); beep(); return; }
        mines--;
        mineList.add(new double[]{px, py, 45});            // it needs 0.75 s to arm
        snd(SoundEvents.UI_BUTTON_CLICK, 0.5F, 0.8F);
    }

    // ---------- power-ups ----------
    private void maybeDrop(Zombie z) {
        sinceDrop++;
        double chance = z.kind == 2 ? 0.30 : 0.05;
        if (!((dropsRound < 3 && rnd.nextDouble() < chance) || sinceDrop >= 30)) return;
        sinceDrop = 0;
        dropsRound++;
        int total = 0;
        for (int w : DROP_W) total += w;
        int r = rnd.nextInt(total), type = 0;
        while (r >= DROP_W[type]) { r -= DROP_W[type]; type++; }
        double dx = z.x, dy = z.y;
        int tx = (int) z.x, ty = (int) z.y;
        if (inb(tx, ty) && winIdx[ty][tx] >= 0) {               // killed in a window or outside it: the gift lands inside the room
            Win w = wins.get(winIdx[ty][tx]);
            dx = w.ix + 0.5;
            dy = w.iy + 0.5;
        }
        drops.add(new double[]{dx, dy, type, 900});
    }

    private void grab(int type) {
        switch (type) {
            case D_AMMO -> {
                for (Weapon w : weapons) { w.mag = w.magSize; w.reserve = w.maxReserve; }
                mines = Math.min(MAX_MINES, mines + 3);
                reload = 0;
            }
            case D_INSTA -> instaT = 1200;
            case D_NUKE -> {
                for (Zombie z : new ArrayList<>(zombies)) { zombies.remove(z); kills++; }
                spits.clear();
                nukeT = 24;
                earn(400);
                snd(SoundEvents.GENERIC_EXPLODE, 0.7F, 0.9F);
            }
            case D_DOUBLE -> dblT = 1200;
            case D_CARPENTER -> {
                for (Win w : wins) w.boards = MAX_BOARDS;        // a window with a zombie in it closes as soon as it steps out
                earn(200);
                snd(SoundEvents.WOOD_PLACE, 0.8F, 0.9F);
            }
            default -> hp = Math.min(maxHp(), hp + 60);
        }
        say("cutemod.zombies.drop." + type);
        pling(1.8F);
    }

    // ---------- perks: after every round you pick 1 of 3 ----------
    private int maxHp() { return perk[P_JUGG] > 0 ? JUGG_HP : BASE_HP; }

    private void openOffer() {
        List<Integer> pool = new ArrayList<>();
        for (int i = 0; i < PERKS; i++) if (perk[i] < 1) pool.add(i);
        Collections.shuffle(pool, new java.util.Random(rnd.nextLong()));
        int n = Math.min(3, pool.size());
        offer = new int[n];
        for (int i = 0; i < n; i++) offer[i] = pool.get(i);
        offering = n > 0;
        offerT = 900;
    }

    private void choose(int k) {
        if (!offering || k < 0 || k >= offer.length) return;
        int p = offer[k];
        perk[p] = 1;
        if (p == P_JUGG) hp = Math.min(maxHp(), hp + (JUGG_HP - BASE_HP));
        offering = false;
        breakT = Math.min(breakT, 150);
        say("cutemod.zombies.perk_got", Component.translatable("cutemod.zombies.perk." + p + ".name").getString());
        pling(1.7F);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (!offering) return false;
        int n = offer.length, x0 = (W - (n * CARD_W + (n - 1) * 4)) / 2;
        for (int i = 0; i < n; i++) {
            if (in(x, y, x0 + i * (CARD_W + 4), CARD_Y, CARD_W, CARD_H)) { choose(i); return true; }
        }
        return false;
    }

    @Override
    public boolean key(int k) {
        switch (k) {
            case 82 -> startReload();                                  // R
            case 69 -> buy();                                          // E
            case 66 -> buyMines();                                     // B
            case 70 -> placeMine();                                    // F
            case 49, 50, 51 -> { if (offering) choose(k - 49); else if (k - 49 < slot.length && slot[k - 49] != null) select(slot[k - 49]); }   // 1-3: pick a perk; 1 / 2: the first / second gun (Q swaps)
            case 81 -> cycle();                                        // Q
            default -> { return false; }
        }
        return true;
    }

    // ---------- tick ----------
    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        if (cool > 0) cool--;
        if (kick > 0) kick--;
        if (swapT > 0) swapT--;
        if (flashT > 0) flashT--;
        if (hit > 0) hit--;
        if (headT > 0) headT--;
        if (hurtT > 0) hurtT--;
        if (instaT > 0) instaT--;
        if (dblT > 0) dblT--;
        if (nukeT > 0) nukeT--;
        if (reviveT > 0) reviveT--;
        if (points != lastPts) { popAmt = (popT > 0 ? popAmt : 0) + (points - lastPts); lastPts = points; popT = 80; }   // +10 +10 +60 add up to +80
        else if (popT > 0 && --popT == 0) popAmt = 0;
        shownPts = shownPts < points ? Math.min(points, shownPts + Math.max(1, (points - shownPts) / 6)) : points;       // counts up, drops at once
        if (reload > 0) {                                           // the stages of the reload sound: mag out, mag in, slide...
            int el = reloadMax - reload;
            for (String st : RELOAD[curIndex()]) {
                int sp = st.indexOf(' ');
                if (el == reloadMax * Integer.parseInt(st.substring(0, sp)) / 100) gun(st.substring(sp + 1), 0.95F + rnd.nextFloat() * 0.1F, 0.85F);
            }
        }
        if (reload > 0 && --reload == 0) finishReload();

        // --- turning: arrow keys, or the mouse close to the left / right edge ---
        double turn = (down(KEY_RIGHT) ? 1 : 0) - (down(KEY_LEFT) ? 1 : 0);
        ang += turn * 0.045;
        // The farther the mouse is from the middle, the faster you turn: slow and fine near the middle, quick near the
        // edges. It keeps working when the pointer leaves the game area, and the speed is smoothed so aiming does not jerk.
        double target = 0;
        if (!offering) {
            double nx = Math.max(-1.6, Math.min(1.6, (mx - W / 2.0) / (W / 2.0)));
            double d = (Math.abs(nx) - DEAD) / (1 - DEAD);
            if (d > 0) target = Math.signum(nx) * Math.pow(d, 1.6) * 0.06;
        }
        turnV += (target - turnV) * 0.3;
        if (Math.abs(turnV) < 0.0004) turnV = 0;
        ang += turnV;
        // --- looking up / down: the mouse above or below the middle band (or the up / down arrows) ---
        double tp = 0;
        if (!offering) {
            double ny = Math.max(-1, Math.min(1, (my - H / 2.0) / (H / 2.0)));
            double d = (Math.abs(ny) - PDEAD) / (1 - PDEAD);
            if (d > 0) tp = -Math.signum(ny) * d * MAXP;
            tp += ((down(KEY_UP) ? 1 : 0) - (down(KEY_DOWN) ? 1 : 0)) * MAXP * 0.8;
        }
        pitch += (Math.max(-MAXP, Math.min(MAXP, tp)) - pitch) * 0.2;
        // --- walking ---
        double fwd = (down(87) ? 1 : 0) - (down(83) ? 0.75 : 0);
        double str = (down(68) ? 1 : 0) - (down(65) ? 1 : 0);
        double c = Math.cos(ang), s = Math.sin(ang);
        double v = 0.045 * (perk[P_STAMIN] > 0 ? 1.3 : 1);          // Stamin-Up: 30% faster
        move((c * fwd - s * str) * v, (s * fwd + c * str) * v);
        if (fwd != 0 || str != 0) walkT++;

        // --- trigger (not while you are choosing a perk with the mouse) ---
        boolean trig = (lmb() && !offering) || down(KEY_SPACE);
        if (trig && (cur.auto || !trigPrev)) fire();
        trigPrev = trig;

        // --- hold E at a window to nail boards back on ---
        findTarget();
        if (tKind == 3 && !offering && down(69)) {
            Win w = wins.get(tIdx);
            if (zombieNear(w, 1.0)) {
                if (msgT == 0) say("cutemod.zombies.blocked");
                repT = 0;
            } else if (++repT >= 22) {
                repT = 0;
                repair(w);
            }
        } else repT = 0;
        for (Win w : wins) {                                     // a window is shut again once it has a board and nobody stands in it
            if (map[w.y][w.x] == 7 && w.boards > 0 && !zombieNear(w, 1.0)) map[w.y][w.x] = 6;
        }

        // --- Pack-a-Punch: the gun works inside for 5 s, then it waits for you for 15 s (and is gone if you leave it) ---
        if (papState == 1) {
            if (--papT <= 0) {
                papGun.punch();
                papState = 2; papT = 900;
                say("cutemod.zombies.pap_ready", gunName(indexOf(papGun)));
                PerkMusic.fx("pap_ready");
                pling(2.0F);
            }
        } else if (papState == 2 && --papT <= 0) {
            papGun.resetStats(); papGun.owned = false; papGun.mag = papGun.magSize; papGun.reserve = papGun.maxReserve;
            papGun = null; papState = 0;
            say("cutemod.zombies.pap_lost");
        }

        // --- the mystery box: rolling, then a gun waits for you for a few seconds ---
        if (boxState == 1) {
            if (--boxCyc <= 0) {                                       // the guns flip faster at first and slow down towards the end
                boxShow = BOX_GUNS[rnd.nextInt(BOX_GUNS.length)];
                boxCyc = 3 + (BOX_ROLL - boxT) / 24;
                if (!dev.cutemod.client.os.Sfx.music()) pling(0.8F + (BOX_ROLL - boxT) / 300F);   // no music: little ticks instead
            }
            if (--boxT <= 0) {
                if (boxW < 0) {
                    points += BOX_COST; say("cutemod.zombies.teddy"); boxState = 3; boxT = 240;
                    PerkMusic.box("box_teddy");
                } else { boxShow = boxW; boxState = 2; boxT = 360; pling(2.0F); }
            }
        } else if (boxState == 3) {
            if (--boxT <= 0) boxState = 0;
        } else if (boxState == 2 && --boxT <= 0) {
            boxState = 0;
            say("cutemod.zombies.box_lost");
        }

        // --- waves ---
        if (breakT > 0) {
            if (offering) {
                if (--offerT <= 0) choose(rnd.nextInt(offer.length));      // too slow: a random one
            } else if (--breakT == 0) {
                round++;
                startRound();
            }
        } else {
            int cap = Math.min(16, 6 + round);
            if (spawned < toSpawn && zombies.size() < cap && --spawnT <= 0) {
                spawnT = Math.max(30, 100 - round * 6);
                spawnZombie();
            }
            if (spawned >= toSpawn && zombies.isEmpty()) {
                breakT = 300;
                say("cutemod.zombies.clear");
                pling(1.9F);
            }
        }

        // --- zombies ---
        if (ticks % 8 == 0) buildFlow();
        for (Zombie z : new ArrayList<>(zombies)) {
            if (z.flash > 0) z.flash--;
            if (z.cool > 0 && Math.hypot(z.x - px, z.y - py) >= 0.75) z.cool--;
            if (z.kind == 3) {                                  // a spitter stops at a distance and spits
                if (z.spitT > 0) z.spitT--;
                double d = Math.hypot(z.x - px, z.y - py);
                if (d < 5.5 && d > 1.3 && seen(z.x, z.y)) {
                    if (z.spitT <= 0) { spit(z); z.spitT = 110; }
                } else {
                    moveZombie(z);
                }
            } else {
                moveZombie(z);
            }
            if (Math.hypot(z.x - px, z.y - py) < 0.75 && z.stun <= 0 && reviveT <= 0) {
                if (--z.cool <= 0) {
                    z.cool = 50;
                    hp -= KIND_DMG[z.kind];
                    hurtT = 14;
                    noHurt = 0;
                    snd(SoundEvents.PLAYER_HURT, 1.0F, 0.7F);
                }
            }
        }
        for (int i = 0; i < zombies.size(); i++) {           // keep them from stacking on one spot
            for (int j = i + 1; j < zombies.size(); j++) {
                Zombie a = zombies.get(i), b = zombies.get(j);
                double dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy);
                if (d < 0.45 && d > 0.001) {
                    double push = (0.45 - d) * 0.25;
                    if (zfree(a.x - dx / d * push, a.y)) a.x -= dx / d * push;
                    if (zfree(a.x, a.y - dy / d * push)) a.y -= dy / d * push;
                    if (zfree(b.x + dx / d * push, b.y)) b.x += dx / d * push;
                    if (zfree(b.x, b.y + dy / d * push)) b.y += dy / d * push;
                }
            }
        }
        if (!zombies.isEmpty() && rnd.nextInt(150) == 0) snd(SoundEvents.ZOMBIE_AMBIENT, 0.5F + rnd.nextFloat() * 0.4F, 0.6F);

        // --- mines: they wait, then go off when a zombie walks close ---
        for (Iterator<double[]> it = mineList.iterator(); it.hasNext(); ) {
            double[] m = it.next();
            if (m[2] > 0) { m[2]--; continue; }
            boolean trip = false;
            for (Zombie z : zombies) if (Math.hypot(z.x - m[0], z.y - m[1]) < 0.8) { trip = true; break; }
            if (!trip) continue;
            it.remove();
            blasts.add(new double[]{m[0], m[1], 14});
            snd(SoundEvents.GENERIC_EXPLODE, 1.1F, 0.7F);
            for (Zombie z : new ArrayList<>(zombies)) if (Math.hypot(z.x - m[0], z.y - m[1]) < 2.0) damage(z, 8, false, false);
        }
        blasts.removeIf(b -> --b[2] <= 0);

        // --- power-ups on the floor: walk into one to take it ---
        for (Iterator<double[]> it = drops.iterator(); it.hasNext(); ) {
            double[] d = it.next();
            if (--d[3] <= 0) { it.remove(); continue; }
            if (Math.hypot(d[0] - px, d[1] - py) < 0.8) { it.remove(); grab((int) d[2]); }
        }

        // --- spit balls ---
        for (Iterator<double[]> it = spits.iterator(); it.hasNext(); ) {
            double[] sp = it.next();
            sp[0] += sp[2];
            sp[1] += sp[3];
            if (!free(sp[0], sp[1]) || --sp[4] <= 0) { it.remove(); continue; }
            if (reviveT <= 0 && Math.hypot(sp[0] - px, sp[1] - py) < 0.35) {
                hp -= 12;
                hurtT = 14;
                noHurt = 0;
                snd(SoundEvents.PLAYER_HURT, 1.2F, 0.6F);
                it.remove();
            }
        }

        // --- health comes back if you are not hit for a while ---
        boolean qr = perk[P_REVIVE] > 0;                                     // Quick Revive: health comes back sooner and faster
        if (++noHurt > (qr ? 200 : 360) && hp < maxHp()) hp = Math.min(maxHp(), hp + (qr ? 0.4 : 0.25));
        if (hp <= 0 && qr) revive();
        else if (hp <= 0) { over = true; beep(); snd(SoundEvents.ZOMBIE_VILLAGER_CONVERTED, 0.8F, 0.6F); }
        perkMusic.update(px, py, machines, power && !over);                    // the perk machines play their tunes when you are near
    }

    /** Quick Revive (alone, like in CoD Zombies): it saves you once. You get up with 60% health, nothing can hurt you for 2.5 seconds
     *  and the zombies around you are thrown back and stunned. The perk is used up, you can buy it again. */
    private void revive() {
        perk[P_REVIVE] = 0;
        hp = maxHp() * 0.6;
        noHurt = 0; hurtT = 0; reviveT = 150;
        for (Zombie z : zombies) {
            double dx = z.x - px, dy = z.y - py, d = Math.hypot(dx, dy);
            if (d < 3.5 && d > 0.001) { knock(z, dx / d, dy / d, 1.5); z.stun = Math.max(z.stun, 120); }
        }
        say("cutemod.zombies.revived");
        snd(SoundEvents.ZOMBIE_VILLAGER_CURE, 1.0F, 0.8F);
        pling(1.0F);
        perkMusic.jingle(P_REVIVE);
    }

    /** True if nothing solid stands between a point and the player. */
    private boolean seen(double x, double y) {
        double d = Math.hypot(px - x, py - y);
        int steps = (int) (d / 0.25) + 1;
        for (int i = 1; i < steps; i++) {
            double t = i / (double) steps;
            if (!free(x + (px - x) * t, y + (py - y) * t)) return false;
        }
        return true;
    }

    private void spit(Zombie z) {
        double dx = px - z.x, dy = py - z.y, d = Math.max(0.01, Math.hypot(dx, dy));
        spits.add(new double[]{z.x, z.y, dx / d * 0.065, dy / d * 0.065, 200});
        snd(SoundEvents.LLAMA_SPIT, 1.0F, 0.5F);
    }

    /** A zombie appears in the pocket outside a window of a room that is open (a door you paid for), far from you. */
    private void spawnZombie() {
        Win w = null;
        for (int t = 0; t < 12 && w == null; t++) {
            Win c = wins.get(rnd.nextInt(wins.size()));
            if (!zoneOpen[c.zone]) continue;
            if (t < 8 && Math.hypot(c.x + 0.5 - px, c.y + 0.5 - py) < 5) continue;
            w = c;
        }
        if (w == null) {
            List<Win> open = new ArrayList<>();
            for (Win c : wins) if (zoneOpen[c.zone]) open.add(c);
            if (open.isEmpty()) return;
            w = open.get(rnd.nextInt(open.size()));
        }
        int[] pt = w.pocket.get(rnd.nextInt(w.pocket.size()));
        int base = 3 + 2 * (round - 1);
        double sp = Math.min(0.03, 0.012 + 0.0012 * round) * (0.85 + rnd.nextDouble() * 0.3);
        double r = rnd.nextDouble();
        int kind = 0;                                         // new kinds show up in later rounds
        if (round >= 3 && r < 0.22) kind = 1;
        else if (round >= 5 && r < 0.34) kind = 2;
        else if (round >= 7 && r < 0.46) kind = 3;
        int hpz = switch (kind) {
            case 1 -> Math.max(2, base * 6 / 10);
            case 2 -> base * 3;
            case 3 -> Math.max(3, base * 8 / 10);
            default -> base;
        };
        double speed = switch (kind) {
            case 1 -> Math.min(0.043, sp * 1.5);
            case 2 -> sp * 0.6;
            case 3 -> sp * 0.7;
            default -> sp;
        };
        zombies.add(new Zombie(pt[0] + 0.5 + (rnd.nextDouble() - 0.5) * 0.3, pt[1] + 0.5 + (rnd.nextDouble() - 0.5) * 0.3, hpz, speed, kind));
        spawned++;
        if (kind > 0 && (seenKinds & (1 << kind)) == 0) {
            seenKinds |= 1 << kind;
            say("cutemod.zombies.new." + kind);
        }
    }

    /** Distance (in tiles) from every walkable tile to the player. Zombies walk "downhill" (windows count, closed doors do not). */
    private void buildFlow() {
        for (int[] r : flow) Arrays.fill(r, -1);
        ArrayDeque<int[]> q = new ArrayDeque<>();
        int sx = Math.max(1, Math.min(MW - 2, (int) px)), sy = Math.max(1, Math.min(MH - 2, (int) py));
        flow[sy][sx] = 0;
        q.add(new int[]{sx, sy});
        while (!q.isEmpty()) {
            int[] c = q.poll();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0], ny = c[1] + d[1];
                if (inb(nx, ny) && walkable(map[ny][nx]) && flow[ny][nx] < 0) {
                    flow[ny][nx] = flow[c[1]][c[0]] + 1;
                    q.add(new int[]{nx, ny});
                }
            }
        }
    }

    private static boolean walkable(int t) { return t == 0 || t == 6 || t == 7; }

    private void moveZombie(Zombie z) {
        if (z.stun > 0) { z.stun--; return; }
        int cx = (int) z.x, cy = (int) z.y;
        double tx = px, ty = py;
        boolean direct = cx == (int) px && cy == (int) py || (Math.hypot(z.x - px, z.y - py) < 1.3 && seen(z.x, z.y));
        if (!direct && inb(cx, cy) && flow[cy][cx] >= 0) {
            int best = flow[cy][cx];
            tx = cx + 0.5; ty = cy + 0.5;
            for (int[] d : DIRS) {
                int nx = cx + d[0], ny = cy + d[1];
                if (inb(nx, ny) && walkable(map[ny][nx]) && flow[ny][nx] >= 0 && flow[ny][nx] < best) {
                    best = flow[ny][nx];
                    tx = nx + 0.5; ty = ny + 0.5;
                }
            }
            int wx = (int) tx, wy = (int) ty;
            if (map[wy][wx] == 6 && winIdx[wy][wx] >= 0 && Math.hypot(z.x - tx, z.y - ty) < 0.62) {
                Win w = wins.get(winIdx[wy][wx]);               // right at the boards: tear one off every now and then
                if (--z.tear <= 0) {
                    z.tear = 85;
                    if (w.boards > 0) w.boards--;
                    snd(SoundEvents.WOOD_BREAK, 0.8F + rnd.nextFloat() * 0.3F, 0.8F);
                    if (w.boards <= 0) { w.boards = 0; map[w.y][w.x] = 7; }
                }
                return;
            }
        }
        double dx = tx - z.x, dy = ty - z.y, d = Math.hypot(dx, dy);
        if (d < 0.001) return;
        double step = Math.min(z.speed, d);
        double nx = z.x + dx / d * step, ny = z.y + dy / d * step;
        if (zfree(nx, z.y)) z.x = nx;
        if (zfree(z.x, ny)) z.y = ny;
    }

    // ---------- drawing ----------
    private static int shade(int rgb, double b) {
        b = Math.max(0, Math.min(1.5, b));
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * b));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * b));
        int bl = Math.min(255, (int) ((rgb & 255) * b));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    @Override
    public void render(GuiGraphics g) {
        hor = H / 2 + (int) Math.round(pitch);
        boolean outside = streetZone >= 0 && zoneOf[Math.max(0, Math.min(MH - 1, (int) py))][Math.max(0, Math.min(MW - 1, (int) px))] == streetZone;
        fogOn = outside;
        if (hor > 0) {
            if (outside) {                                                                      // the burning sky of Town
                g.fillGradient(0, 0, W, Math.min(H, hor), 0xFF1E0A04, 0xFFC4641E);
                for (int i = 0; i < 80; i++) {                                                   // embers drifting up
                    int ex = hash(i, 11) % W, spd = 1 + hash(i, 12) % 3;
                    int ey = Math.floorMod(hash(i, 13) % H - ticks * spd / 3, H);
                    int sz = 1 + hash(i, 14) % 2;
                    if (ey < hor && (ticks / 7 + i) % 5 != 0) rect(g, ex, ey, sz, sz, 0xFFFFB040);
                }
                for (int x = 0; x < W; x += CW) {                                                // the burnt town far away
                    double cam = 2.0 * (x / CW + 0.5) / COLS - 1;
                    int n = (int) Math.floor((ang + Math.atan(cam * PLANE)) / 0.13);
                    int bh = 8 + hash(n, 21) % 34, top = Math.max(0, hor - bh);
                    rect(g, x, top, CW, hor - top, 0xFF3A1808);
                    if ((hash(n, 22) & 3) != 0 && (x / CW + n) % 3 == 0 && bh > 9)
                        rect(g, x, top + 3 + hash(n, 23 + x / CW) % Math.max(1, bh - 6), CW, 2, 0xFFD87018);
                }
            } else g.fillGradient(0, 0, W, Math.min(H, hor), 0xFF0B0D14, 0xFF222733);       // ceiling (indoors)
        }
        if (hor < H) {
            if (outside) g.fillGradient(0, Math.max(0, hor), W, H, 0xFF9A5224, 0xFF3A2216);
            else g.fillGradient(0, Math.max(0, hor), W, H, 0xFF1A1714, 0xFF2E2822);         // floor, under the tiles
        }
        double dirX = Math.cos(ang), dirY = Math.sin(ang), plX = -dirY * PLANE, plY = dirX * PLANE;

        drawFloor(g, dirX, dirY, plX, plY);

        for (int col = 0; col < COLS; col++) {
            double cam = 2.0 * (col + 0.5) / COLS - 1;
            double a = Math.atan2(dirY + plY * cam, dirX + plX * cam);
            double raw = ray(a);
            double dist = Math.max(0.05, raw * Math.cos(a - ang));          // fix the fish-eye effect
            zbuf[col] = dist;
            double b = Math.max(0.12, 1 - dist / 9.5) * (lastSide ? 0.75 : 1);
            if (glows(lastType)) b = Math.max(b, (lastType == 11 && boxState > 0) || (lastType == 14 && papState == 1) ? 1.1 : 0.45);   // gun walls, doors and the box glow a little in the dark
            if (!power && lastType >= 14 && lastType <= 20) b *= 0.55;            // the machines are dark without power
            int lh = (int) (H / dist);
            drawWall(g, col, lastType == 11 && boxState > 0 ? 25 : lastType == 14 && papState == 1 ? 26 : lastType, lastTX, lastTY, lastWallX, b, lh, hor - lh / 2);   // the box is open while it rolls
            if (lowRaw > 0) {                                              // a car / fence / crate in front: lower than the walls, drawn over them
                double ld = Math.max(0.05, lowRaw * Math.cos(a - ang));
                lowDz[col] = ld;
                lowTy[col] = lowType;
                drawLow(g, col, lowType, lowWX, Math.max(0.12, 1 - ld / 9.5) * (lowSide ? 0.75 : 1), (int) (H / ld));
            } else lowDz[col] = 0;
            winD[col] = lastWinDist > 0 ? Math.max(0.05, lastWinDist * Math.cos(a - ang)) : 0;
            winSide[col] = lastWinSide;
            if (winD[col] > 0) {                                           // an open window: a sill and a lintel around the hole
                double wd = winD[col], wb = Math.max(0.12, 1 - wd / 9.5) * (winSide[col] ? 0.75 : 1);
                int wl = (int) (H / wd), bottom = hor + wl / 2;
                fillCol(g, col, bottom - wl, bottom - (int) (0.82 * wl), shade(0xFF4A3220, wb));
                fillCol(g, col, bottom - (int) (0.28 * wl), bottom - (int) (0.22 * wl), shade(0xFF7A5A3A, wb));      // the lit top of the sill
                fillCol(g, col, bottom - (int) (0.22 * wl), bottom, shade(0xFF4A3220, wb));
            }
        }

        // mines and explosions lie on the floor
        for (double[] m : mineList) billboard(g, m[0], m[1], 0.11, 0, m[2] > 0 || (ticks / 20) % 2 == 0 ? 0xFFE03A3A : 0xFF4A1A1A);
        for (double[] bl : blasts) billboard(g, bl[0], bl[1], 0.25 + (14 - bl[2]) * 0.05, 0.12, bl[2] > 7 ? 0xFFFFC040 : 0xFFE06020);

        if (boxState > 0 && !boxes.isEmpty()) {                    // the gun that is rolling (or waiting) over a beam of light, or the teddy bear
            int[] bx = boxes.get(0);
            double gx = bx[0] + 0.5 + (bx[2] - bx[0]) * 0.62, gy = bx[1] + 0.5 + (bx[3] - bx[1]) * 0.62;
            double lift = 0.5 + 0.03 * Math.sin(ticks * 0.12);
            int shown = boxState == 1 ? boxShow : boxState == 2 ? boxW : -1;
            boxSprite(g, gx, gy, lift, shown);
        }

        if (papState == 2 && papGun != null) {                      // the upgraded gun waits over Pack-a-Punch
            for (int[] mm : machines) {
                if (mm[2] != 1) continue;
                for (int[] d : DIRS) {
                    int nx = mm[0] + d[0], ny = mm[1] + d[1];
                    if (inb(nx, ny) && map[ny][nx] == 0) {
                        boxSprite(g, mm[0] + 0.5 + d[0] * 0.62, mm[1] + 0.5 + d[1] * 0.62, 0.5 + 0.03 * Math.sin(ticks * 0.12), indexOf(papGun));
                        break;
                    }
                }
            }
        }

        // power-ups, far ones first (they blink when they are about to vanish)
        List<double[]> dl = new ArrayList<>(drops);
        dl.sort((p, q) -> Double.compare(Math.hypot(q[0] - px, q[1] - py), Math.hypot(p[0] - px, p[1] - py)));
        for (double[] d : dl) if (d[3] > 180 || (ticks / 6) % 2 == 0) icon(g, d);

        for (double[] pr : PROPS) prop(g, pr);

        // zombies, far ones first
        List<Zombie> order = new ArrayList<>(zombies);
        order.sort((a, b) -> Double.compare(Math.hypot(b.x - px, b.y - py), Math.hypot(a.x - px, a.y - py)));
        for (Zombie z : order) sprite(g, z);
        for (double[] sp : spits) billboard(g, sp[0], sp[1], 0.09, 0.45, 0xFF9AFF3A);

        // red flash / vignette when hurt or low on health
        double missing = 1 - hp / maxHp();
        int alpha = (int) Math.min(150, missing * 110 + hurtT * 6);
        if (alpha > 4) rect(g, 0, 0, W, H, (alpha << 24) | 0xB00000);
        if (nukeT > 0) rect(g, 0, 0, W, H, (Math.min(255, nukeT * 10) << 24) | 0xFFFFFF);
        if (reviveT > 0) rect(g, 0, 0, W, H, (Math.min(90, reviveT) << 24) | 0x40A0E0);
        if (breakT > 0 && breakT < 90 && !offering && ticks % 20 < 10) ctext(g, Component.translatable("cutemod.zombies.next").getString(), W / 2, 30, 0xFFFFE9A0);

        weaponAndHud(g);
        if (offering) renderOffer(g);
        if (over) rect(g, 0, 0, W, H, 0x80900000);
    }

    private boolean glows(int t) { return t == 3 || t == 4 || t == 5 || (t >= 8 && t <= 11) || t == 13 || t == 21 || (power && t >= 14 && t <= 20); }

    /** One wall column: 8 texture rows stretched over the wall height; rows of the same color are drawn as one rectangle. */
    private void drawWall(GuiGraphics g, int col, int type, int tx, int ty, double wx, double b, int lh, int top) {
        int texW = type == 6 ? TW : TEX[type][0].length;            // the perk machines are 32 x 32 texels, the rest 16 x 8
        int u = Math.max(0, Math.min(texW - 1, (int) (wx * texW)));
        int boards = type == 6 && winIdx[ty][tx] >= 0 ? wins.get(winIdx[ty][tx]).boards : 0;
        int rows = type == 6 ? TH : TEX[type].length;               // the perk machines have 32 rows, the rest 8
        int runY = top, runC = 0;
        for (int r = 0; r < rows; r++) {
            int c = lit(texel(type, u, r, boards), b);
            int y = top + r * lh / rows;
            if (r == 0) { runC = c; runY = y; continue; }
            if (c != runC) { fillCol(g, col, runY, y, runC); runY = y; runC = c; }
        }
        fillCol(g, col, runY, top + lh, runC);
        // the storeys above: every wall is 11-16 eighths of a normal wall high (houses of different height); the upper part repeats a brick
        // or a lit-window texture, with a ledge and a dark cornice on top. Doors, guns and machines stay at the foot of the wall.
        int n = wallRows(tx, ty), bottom = top + lh;
        int et = (hash(tx * 5 + ty * 3, 1) & 1) == 0 ? 24 : 1;
        int ey = 0, ec = 0;
        for (int k = n - 1; k >= 8; k--) {
            int c;
            if (k == n - 1) c = lit(0xFF2A1A12, b);                              // cornice
            else if (k == n - 2) c = lit(0xFF8A7A66, b);                         // ledge
            else c = lit(TEX[et][7 - (k % 8)][Math.min(TW - 1, u * TW / texW)], b * 0.92);   // the machines are 32 wide, the brick above them only 16
            int y = bottom - (k + 1) * lh / 8;
            if (k == n - 1) { ey = y; ec = c; continue; }
            if (c != ec) { fillCol(g, col, ey, y, ec); ey = y; ec = c; }
        }
        if (n > 8) fillCol(g, col, ey, top, ec);
        fillCol(g, col, bottom, bottom + Math.max(2, lh / 12), 0x55000000);       // dark strip on the floor at the foot of the wall
    }

    /** How tall the wall of this tile is, in eighths of a normal wall (11-16): neighbouring tiles in a 3 x 3 block share the height. */
    private static int wallRows(int tx, int ty) { return 11 + hash(tx / 3, ty / 3) % 6; }

    /** Haze: close things keep their color, far ones fade into the orange smoke (only outdoors). */
    private int lit(int c, double b) {
        if (!fogOn) return shade(c, b);
        double k = Math.max(0, Math.min(1, b)), m = 0.55 + 0.45 * k, fg = (1 - k) * 0.85;
        int r = (int) (((c >> 16) & 255) * m * (1 - fg) + ((FOG >> 16) & 255) * fg);
        int gr = (int) (((c >> 8) & 255) * m * (1 - fg) + ((FOG >> 8) & 255) * fg);
        int bl = (int) ((c & 255) * m * (1 - fg) + (FOG & 255) * fg);
        return 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, gr) << 8) | Math.min(255, bl);
    }

    /** A low wall (car, fence, crate): half the height of a wall, standing on the floor; clear texels of the fence are skipped. */
    private void drawLow(GuiGraphics g, int col, int type, double wx, double b, int lh) {
        int u = Math.max(0, Math.min(TW - 1, (int) (wx * TW)));
        int h = Math.max(2, (int) (lh * lowFrac(type))), top = hor + lh / 2 - h;
        for (int r = 0; r < TH; r++) {
            int tc = TEX[type][r][u];
            if (tc == 0) continue;
            fillCol(g, col, top + r * h / TH, Math.max(top + r * h / TH + 1, top + (r + 1) * h / TH), lit(tc, b));
        }
        if (type != 22) fillCol(g, col, top + h, top + h + Math.max(2, lh / 14), 0x66000000);   // the shadow of a car / crate on the ground
    }

    private void propRect(GuiGraphics g, double f, int x0, int w, int y0, int y1, int color) {
        for (int x = Math.floorDiv(x0, CW) * CW; x < x0 + w; x += CW) {
            int c = Math.floorDiv(x, CW);
            if (x < 0 || c >= COLS || f >= zbuf[c] || y1 <= y0) continue;
            rect(g, x, y0, CW, y1 - y0, color);
        }
    }

    /** Traffic lights, street lamps and fires of the burning town. */
    private void prop(GuiGraphics g, double[] p) {
        double rx = p[0] - px, ry = p[1] - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang), r = -rx * Math.sin(ang) + ry * Math.cos(ang);
        if (f < 0.3) return;
        int full = (int) (H / f), sx = (int) (W / 2.0 * (1 + r / (f * PLANE))), bottom = hor + full / 2, kind = (int) p[2];
        double b = Math.max(0.25, 1 - f / 9.5);
        if (kind == 2) {                                                  // a fire on the ground
            int fw = Math.max(2, (int) (full * 0.14));
            int fh = Math.max(2, (int) (full * (0.16 + 0.07 * Math.sin(ticks * 0.45 + p[0] * 5) + 0.04 * Math.sin(ticks * 0.9 + p[1] * 3))));
            propRect(g, f, sx - fw, fw * 2, bottom - Math.max(1, full / 40), bottom, 0xFFB04810);
            propRect(g, f, sx - fw / 2, fw, bottom - fh, bottom, 0xFFE05010);
            propRect(g, f, sx - fw / 4, Math.max(2, fw / 2), bottom - fh * 3 / 4, bottom, 0xFFFFC040);
            return;
        }
        int pw = Math.max(2, (int) (full * 0.05)), ph = (int) (full * (kind == 0 ? 1.25 : 1.4));
        propRect(g, f, sx - pw / 2, pw, bottom - ph, bottom, lit(0xFF2A2724, b));
        if (kind == 0) {                                                  // the traffic light: a box with three lamps
            int bw = Math.max(3, (int) (full * 0.16)), bh = Math.max(6, (int) (full * 0.36)), by = bottom - ph - bh / 2, ls = Math.max(2, bw * 2 / 3);
            propRect(g, f, sx - bw / 2, bw, by, by + bh, lit(0xFF1A1A18, b));
            int on = (ticks / 70) % 3;
            int[] lampOn = {0xFFFF3020, 0xFFFFC020, 0xFF30E050}, lampOff = {0xFF4A1810, 0xFF4A3A10, 0xFF104018};
            for (int i = 0; i < 3; i++) propRect(g, f, sx - ls / 2, ls, by + bh * (1 + 3 * i) / 10, Math.max(by + bh * (1 + 3 * i) / 10 + 1, by + bh * (3 + 3 * i) / 10), i == on ? lampOn[i] : lampOff[i]);
        } else {                                                          // the street lamp: a warm light on top
            int lw = Math.max(4, (int) (full * 0.22));
            propRect(g, f, sx - lw / 2, lw, bottom - ph - Math.max(2, full / 25), bottom - ph + Math.max(1, full / 40), 0xFFFFD070);
        }
    }

    private static void fillCol(GuiGraphics g, int col, int y0, int y1, int color) {
        y0 = Math.max(0, y0);
        y1 = Math.min(H, y1);
        if (y1 > y0) rect(g, col * CW, y0, CW, y1 - y0, color);
    }

    /** The floor, row by row (3 pixels at a time): every tile has its own shade, every room its own color. */
    private void drawFloor(GuiGraphics g, double dirX, double dirY, double plX, double plY) {
        final int step = 3;
        for (int y = Math.max(hor + 1, 0); y < H; y += step) {
            double d = H / (2.0 * (y + step / 2.0 - hor));
            if (d > 13) continue;
            double bright = Math.max(0.12, 1 - d / 9.5);
            int runStart = 0, runColor = 0;
            for (int col = 0; col <= COLS; col++) {
                int c = 0;
                if (col < COLS) {
                    double cam = 2.0 * (col + 0.5) / COLS - 1;
                    c = floorColor((int) Math.floor(px + d * (dirX + plX * cam)), (int) Math.floor(py + d * (dirY + plY * cam)), bright);
                }
                if (col == 0) { runColor = c; continue; }
                if (c != runColor || col == COLS) {
                    if (runColor != 0) rect(g, runStart * CW, y, (col - runStart) * CW, Math.min(step, H - y), runColor);
                    runStart = col;
                    runColor = c;
                }
            }
        }
    }

    private int floorColor(int fx, int fy, double bright) {
        if (!inb(fx, fy)) return 0;
        int t = map[fy][fx];
        if (t != 0 && t != 7) return 0;                          // a wall stands there
        if (!pocket[fy][fx] && zoneOf[fy][fx] == streetZone) {                // cracked asphalt with glowing lava cracks
            int h = hash(fx * 7 + 3, fy * 13 + 5);
            if ((h & 7) == 0) return shade(0xFFE0701C, Math.max(bright, 0.55) * (0.75 + 0.25 * Math.sin(ticks * 0.08 + ((h >> 3) & 15))));
        }
        int base = pocket[fy][fx] ? POCKET_FLOOR : zoneOf[fy][fx] < 0 ? SILL_FLOOR : zoneColor[zoneOf[fy][fx] & 15];
        double k = ((fx + fy) & 1) == 0 ? 1.0 : 0.86;            // a checker pattern plus a little noise per tile
        k *= 0.94 + (hash(fx, fy) & 3) * 0.04;
        return lit(shade(base, k), bright);
    }

    /** A small square in the world (a mine, a spit ball, a blast), hidden behind walls. */
    // ---------- the gun over the mystery box: a side view of the gun, a beam of light, or a teddy bear ----------
    /** Every gun as rectangles on a 24 x 10 grid: x, y, w, h, color (0 the color of the gun, 1 dark, 2 light, 3 metal, 4 accent). In the order of the weapons array. */
    private static final String[] GUN_ART = {
            "6,2,13,3,0;6,2,13,1,2;19,3,3,2,1;7,5,4,5,3;11,5,3,1,1",                                   // pistol
            "0,3,5,5,3;5,3,13,3,0;5,3,13,1,2;18,4,6,2,1;9,6,3,4,1;12,2,4,1,3",                         // rifle
            "0,3,5,5,3;5,3,9,3,0;5,3,9,1,2;14,3,10,2,1;14,5,10,1,3;15,6,5,2,3",                        // shotgun
            "0,3,4,2,3;4,2,13,4,0;4,2,13,1,2;17,3,5,2,1;8,6,3,4,1;5,6,3,4,3",                          // SMG
            "4,5,3,5,3;6,2,5,4,0;11,2,12,2,1;11,2,12,1,2;8,4,3,2,1",                                   // magnum
            "0,3,6,5,3;6,4,13,2,0;6,4,13,1,2;19,4,5,1,1;8,1,8,2,3;9,6,3,3,1",                          // sniper
            "3,3,14,5,0;3,3,14,1,2;17,4,6,3,1;19,3,1,5,4;5,1,3,2,4;5,8,3,2,4;7,5,6,1,2",               // ray gun
            "0,3,4,4,3;4,2,14,4,0;4,2,14,1,2;18,3,6,2,1;9,6,6,4,3;1,6,3,3,1",                          // LMG
            "0,3,4,5,3;4,3,10,3,0;4,3,10,1,2;14,3,10,2,1;9,6,5,4,1;10,7,3,2,4",                        // combat shotgun
            "1,2,19,4,0;1,2,19,1,2;20,1,4,6,1;9,6,3,4,3;14,6,2,2,3",                                   // launcher
            "1,3,22,2,0;1,3,22,1,2;1,6,22,1,1;6,2,8,5,3;16,2,5,1,4;16,5,5,1,4",                        // railgun
            "10,2,14,1,1;10,4,14,1,1;10,6,14,1,1;10,2,2,5,3;3,3,8,4,0;4,7,3,3,3",                      // minigun
            "5,2,10,5,0;5,2,10,1,2;8,0,5,2,2;15,4,6,2,1;6,7,3,3,4",                                    // water gun
            "4,2,14,4,0;4,2,14,1,2;18,3,3,2,4;5,6,4,4,3;12,6,3,1,1",                                   // dart blaster
            "0,4,7,3,3;7,3,17,1,3;7,4,17,1,0;4,3,3,1,1",                                               // musket
            "10,5,3,5,3;7,1,2,5,0;14,1,2,5,0;8,5,6,1,0",                                               // slingshot
            "6,2,13,3,0;6,2,13,1,2;19,1,4,5,1;7,5,4,5,3"};                                             // flare gun
    private static final int[][][] GUN_RECTS_CACHE = new int[GUN_ART.length][][];
    /** The teddy bear on a 16 x 16 grid, same format. */
    private static final String TEDDY_ART = "3,3,10,8,0;1,1,4,4,0;11,1,4,4,0;2,2,2,2,2;12,2,2,2,2;6,7,4,3,2;7,7,2,1,1;5,5,1,2,1;10,5,1,2,1;4,11,8,5,0;6,11,4,2,4;3,12,2,3,0;11,12,2,3,0";

    private static int[][] parseArt(String art) {
        String[] parts = art.split(";");
        int[][] out = new int[parts.length][];
        for (int i = 0; i < parts.length; i++) {
            String[] f = parts[i].split(",");
            out[i] = new int[]{Integer.parseInt(f[0]), Integer.parseInt(f[1]), Integer.parseInt(f[2]), Integer.parseInt(f[3]), Integer.parseInt(f[4])};
        }
        return out;
    }

    private static int artColor(int k, int base, boolean teddy) {
        return switch (k) {
            case 1 -> ZombieArt.shade(base, 0.55);
            case 2 -> teddy ? 0xFFE0BE90 : ZombieArt.shade(base, 1.5);
            case 3 -> 0xFF30343C;
            case 4 -> teddy ? 0xFFD03030 : 0xFFFFC040;
            default -> base;
        };
    }

    /** gun >= 0: that gun (index into weapons); -1: the teddy bear. Floats over the box in a column of light and a glow. */
    private void boxSprite(GuiGraphics g, double wx, double wy, double lift, int gun) {
        double rx = wx - px, ry = wy - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang), r = -rx * Math.sin(ang) + ry * Math.cos(ang);
        if (f < 0.25) return;
        int full = (int) (H / f), sx = (int) (W / 2.0 * (1 + r / (f * PLANE))), floorY = hor + full / 2;
        boolean teddy = gun < 0;
        int[][] art;
        if (teddy) art = parseArt(TEDDY_ART);
        else { if (GUN_RECTS_CACHE[gun] == null) GUN_RECTS_CACHE[gun] = parseArt(GUN_ART[gun]); art = GUN_RECTS_CACHE[gun]; }
        int gw = teddy ? 16 : 24, gh = teddy ? 16 : 10;
        double unit = Math.max(1.0, full * (teddy ? 0.34 : 0.5) / gw);
        int sw = (int) (gw * unit), sh = (int) (gh * unit), top = floorY - (int) (full * lift) - sh;
        int beamW = Math.max(3, (int) (full * 0.2));
        propRect(g, f, sx - beamW / 2, beamW, floorY - (int) (full * 0.95), floorY - (int) (full * 0.34), 0x30A8E0FF);          // the beam of light
        propRect(g, f, sx - beamW / 4, Math.max(1, beamW / 2), floorY - (int) (full * 0.95), floorY - (int) (full * 0.34), 0x38FFFFFF);
        int base = teddy ? 0xFF8A5A30 : weapons[gun].col;
        int pad = Math.max(1, (int) unit);
        propRect(g, f, sx - sw / 2 - pad, sw + 2 * pad, top - pad, top + sh + pad, ((teddy ? 0x40 : 0x50) << 24) | (base & 0xFFFFFF));   // a soft glow behind it
        for (int[] q : art) {
            int x0 = sx - sw / 2 + (int) (q[0] * unit), y0 = top + (int) (q[1] * unit);
            int x1 = sx - sw / 2 + (int) ((q[0] + q[2]) * unit), y1 = top + (int) ((q[1] + q[3]) * unit);
            propRect(g, f, x0, Math.max(1, x1 - x0), y0, Math.max(y0 + 1, y1), artColor(q[4], base, teddy));
        }
    }

    private void billboard(GuiGraphics g, double wx, double wy, double size, double lift, int color) {
        double rx = wx - px, ry = wy - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);
        if (f < 0.2) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f);
        int s = Math.max(2, (int) (full * size));
        int sx = (int) (W / 2.0 * (1 + cam));
        int col = Math.floorDiv(sx, CW);
        if (sx < 0 || col >= COLS || f >= zbuf[col]) return;
        int bottom = hor + full / 2 - (int) (full * lift);
        rect(g, sx - s / 2, bottom - s, s, s, color);
    }

    /** A power-up: a 7x7 pixel icon hovering over the floor. */
    private void icon(GuiGraphics g, double[] d) {
        int type = (int) d[2];
        double rx = d[0] - px, ry = d[1] - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);
        if (f < 0.2) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f), s = Math.max(7, (int) (full * 0.26));
        int sx = (int) (W / 2.0 * (1 + cam));
        int col = Math.floorDiv(sx, CW);
        if (sx < 0 || col >= COLS || f >= zbuf[col]) return;
        int lift = (int) (full * (0.12 + 0.03 * Math.sin(ticks * 0.15 + d[0])));
        int left = sx - s / 2, top = hor + full / 2 - lift - s;
        double b = Math.max(0.5, 1 - f / 12);
        String[] art = ICON[type];
        for (int row = 0; row < 7; row++) {
            for (int c = 0; c < 7; c++) {
                char ch = art[row].charAt(c);
                if (ch == '.') continue;
                int x0 = left + c * s / 7, x1 = left + (c + 1) * s / 7, y0 = top + row * s / 7, y1 = top + (row + 1) * s / 7;
                rect(g, x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0), shade(ch == 'w' ? 0xFFFFFFFF : DROP_COL[type], b));
            }
        }
    }

    private void sprite(GuiGraphics g, Zombie z) {
        double rx = z.x - px, ry = z.y - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);
        if (f < 0.2) return;
        double cam = r / (f * PLANE);
        // two walking frames (runners step faster); the picture is drawn by ZombieArt
        int frame = (int) ((ticks + (int) (z.x * 13 + z.y * 7)) / (z.kind == 1 ? 5 : z.kind == 2 ? 14 : 9)) & 1;
        int[][] spr = ZombieArt.zombie(z.kind, frame);
        int sprW = spr[0].length, sprH = spr.length;
        int full = (int) (H / f), sh = (int) (full * KIND_SIZE[z.kind]), sw = sh * sprW / sprH;
        int left = (int) (W / 2.0 * (1 + cam)) - sw / 2, top = hor + full / 2 - sh;
        top += (int) (Math.sin(ticks * (z.kind == 1 ? 0.3 : 0.15) + z.x * 7) * full * 0.015);   // shambling (runners shake faster)
        double b = Math.max(0.22, 1 - f / 9.5);
        boolean flash = z.flash > 0;
        for (int x = Math.floorDiv(left, CW) * CW; x < left + sw; x += CW) {
            int c = x / CW;
            if (x < 0 || c >= COLS || f >= zbuf[c]) continue;
            int u = Math.max(0, Math.min(sprW - 1, (x + CW / 2 - left) * sprW / sw));
            int clipTop = 0, clipBot = H;                         // behind a window you only see what fits through the hole
            if (winD[c] > 0 && f > winD[c]) {
                int wl = (int) (H / winD[c]), bottom = hor + wl / 2;
                clipTop = bottom - (int) (0.82 * wl);
                clipBot = bottom - (int) (0.22 * wl);
            }
            if (lowDz[c] > 0 && f > lowDz[c] && lowTy[c] != 22) {          // behind a car or a crate: its lower part is hidden
                int llh = (int) (H / lowDz[c]);
                clipBot = Math.min(clipBot, hor + llh / 2 - (int) (llh * lowFrac(lowTy[c])));
            }
            // rows of the same color are drawn as one rectangle
            int runRow = 0, runCol = 0;
            for (int row = 0; row <= sprH; row++) {
                int pc = row < sprH ? spr[row][u] : 0;
                if (row > 0 && pc == runCol && row < sprH) continue;
                if ((runCol >>> 24) != 0) {
                    int y0 = Math.max(top + runRow * sh / sprH, clipTop);
                    int y1 = Math.min(Math.max(top + runRow * sh / sprH + 1, top + row * sh / sprH), clipBot);
                    if (y1 > y0) {
                        int col = flash ? mixWhite(runCol) : shade(runCol, isGlow(runCol) ? 1.2 : b);
                        rect(g, x, y0, CW, y1 - y0, col);
                    }
                }
                runRow = row;
                runCol = pc;
            }
        }
        int shc = Math.floorDiv(left + sw / 2, CW);
        if (shc >= 0 && shc < COLS && f < zbuf[shc]) rect(g, left + sw / 5, top + sh - Math.max(1, sh / 40), sw * 3 / 5, Math.max(2, sh / 28), 0x66000000);   // shadow under the feet
        // health bar over the head when it is hurt
        if (z.hp < z.maxHp && f < 6) {
            int bw = Math.max(6, sw), bx = left + sw / 2 - bw / 2;
            rect(g, bx, top - 4, bw, 2, 0xAA000000);
            rect(g, bx, top - 4, Math.max(0, bw * z.hp / z.maxHp), 2, 0xFFE03A3A);
        }
    }

    /** A hit zombie flashes white-pink. */
    private static int mixWhite(int c) {
        int r = ((c >> 16) & 255) / 3 + 170, gr = ((c >> 8) & 255) / 3 + 150, bl = (c & 255) / 3 + 150;
        return 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, gr) << 8) | Math.min(255, bl);
    }

    /** Very saturated bright colors (eyes, acid, teeth) do not get dark in the distance, they glow. */
    private static boolean isGlow(int c) {
        int r = (c >> 16) & 255, gr = (c >> 8) & 255, bl = c & 255, mx = Math.max(r, Math.max(gr, bl)), mn = Math.min(r, Math.min(gr, bl));
        return mx > 225 && mx - mn > 120;
    }

    private void weaponAndHud(GuiGraphics g) {
        // crosshair + hit marker (gold for a headshot)
        int cx = W / 2, cy = H / 2;
        int hitCol = headT > 20 ? 0xFFFFD84A : 0xFFFF4040;
        int cc = hit > 0 ? hitCol : 0xE0FFFFFF;
        rect(g, cx - 5, cy, 3, 1, cc); rect(g, cx + 3, cy, 3, 1, cc);
        rect(g, cx, cy - 5, 1, 3, cc); rect(g, cx, cy + 3, 1, 3, cc);
        if (hit > 0) { rect(g, cx - 3, cy - 3, 1, 1, hitCol); rect(g, cx + 3, cy - 3, 1, 1, hitCol);
                       rect(g, cx - 3, cy + 3, 1, 1, hitCol); rect(g, cx + 3, cy + 3, 1, 1, hitCol); }
        if (headT > 0) ctext(g, Component.translatable("cutemod.zombies.head").getString(), cx, cy - 20 - (40 - headT) / 6, headT > 20 ? 0xFFFFD84A : 0xFFB09A50);

        // the gun, seen from behind like in a shooter: gloved hands hold it, the barrel points into the crosshair.
        // It bobs while walking, jumps back and up when shooting, dips and tilts while reloading and rises when you switch guns.
        int gi = curIndex();
        float rl = reload > 0 && reloadMax > 0 ? (float) (reloadMax - reload) / reloadMax : 0F;
        GunView.Out gv = GunView.render(gi, cur.col, kick, walkT, rl, swapT / 10F, ticks, cur.pap, cur == minigun && (flashT > 0 || cool > 0));
        int[] gpx = gv.px;
        for (int y = Math.max(0, gv.y0); y <= Math.min(H - 1, gv.y1); y++) {          // one rectangle per run of the same color
            int row = y * W, x = 0;
            while (x < W) {
                int c = gpx[row + x];
                if (c == 0) { x++; continue; }
                int run = 1;
                while (x + run < W && gpx[row + x + run] == c) run++;
                rect(g, x, y, run, 1, c);
                x += run;
            }
        }
        if (flashT > 0) {                                           // muzzle flash: a bright star at the end of the barrel, it gets smaller far away
            int mx = gv.mx, my = gv.my;
            int fc = cur == ray ? 0xFF4AF0E0 : cur == flare ? 0xFFFF6030 : cur == railgun ? 0xFF80C0FF : cur == launcher ? 0xFFFFA040 : 0xFFFFD84A;
            boolean big = cur == shotgun || cur == combat || cur == sniper || cur == launcher || cur == railgun;
            int len = big ? 12 : 8;
            rect(g, mx - len, my - 1, len * 2 + 1, 3, fc);          // the star: a cross and two diagonals
            rect(g, mx - 1, my - len, 3, len * 2 + 1, fc);
            rect(g, mx - len / 2 - 1, my - len / 2 - 1, 3, 3, fc);  rect(g, mx + len / 2 - 1, my - len / 2 - 1, 3, 3, fc);
            rect(g, mx - len / 2 - 1, my + len / 2 - 1, 3, 3, fc);  rect(g, mx + len / 2 - 1, my + len / 2 - 1, 3, 3, fc);
            rect(g, mx - len / 2, my - 1, len + 1, 3, 0xFFFFFFFF);
            rect(g, mx - 1, my - len / 2, 3, len + 1, 0xFFFFFFFF);
            rect(g, mx - 2, my - 2, 5, 5, 0xFFFFFFFF);
        }

        drawHud(g);
        if (!offering) {
            if (tKind == 1) {
                int wi = stations.get(tIdx)[2];
                Weapon stw = weapons[wi];
                boolean full = slotsFull();                                  // all hands busy: the new gun replaces the one you hold
                String p = stw.owned ? Component.translatable("cutemod.zombies.buy_ammo", stw.ammoCost).getString()
                        : full ? Component.translatable("cutemod.zombies.buy_swap", gunName(wi), stw.cost, gunName(curIndex())).getString()
                        : Component.translatable("cutemod.zombies.buy_w", gunName(wi), stw.cost).getString();
                prompt(g, p, points >= (stw.owned ? stw.ammoCost : stw.cost) ? 0xFFFFE9A0 : 0xFFFF9A80, 0);
                prompt(g, Component.translatable("cutemod.zombies.mines_buy", MINE_COST).getString(), 0xFFFFC8A0, 1);
            } else if (tKind == 4) {                                  // the mystery box
                if (boxState == 0) prompt(g, Component.translatable("cutemod.zombies.box_buy", BOX_COST).getString(), points >= BOX_COST ? 0xFFFFE9A0 : 0xFFFF9A80, 0);
                else if (boxState == 1) prompt(g, Component.translatable("cutemod.zombies.box_roll", gunName(boxShow)).getString(), 0xFFB8D8FF, 0);
                else if (boxState == 2) {
                    prompt(g, Component.translatable("cutemod.zombies.box_take", gunName(boxW)).getString(), 0xFFFFE9A0, 0);
                    rect(g, W / 2 - 20, H - 34, 40, 2, 0x90000000); rect(g, W / 2 - 20, H - 34, 40 * boxT / 360, 2, 0xFFFFD84A);
                }
            } else if (tKind == 6) {
                int[] mm = machines.get(tIdx);
                String p;
                int need = 0;
                if (mm[2] == 0) p = Component.translatable("cutemod.zombies.lever").getString();
                else if (!power) p = Component.translatable("cutemod.zombies.dark", mm[2] == 1 ? Component.translatable("cutemod.zombies.pap_name").getString() : perkName(mm[2] - 2)).getString();
                else if (mm[2] == 1 && papState == 1) p = Component.translatable("cutemod.zombies.pap_working").getString();
                else if (mm[2] == 1 && papState == 2) p = Component.translatable("cutemod.zombies.pap_take", gunName(indexOf(papGun))).getString();
                else if (mm[2] == 1) {
                    need = cur.pap ? 0 : PAP_COST;
                    p = cur.pap ? Component.translatable("cutemod.zombies.pap_again").getString()
                            : heldGuns() < 2 ? Component.translatable("cutemod.zombies.pap_need").getString()
                            : Component.translatable("cutemod.zombies.pap_buy", gunName(curIndex()), PAP_COST).getString();
                } else {
                    int pk = mm[2] - 2;
                    need = perk[pk] > 0 ? 0 : PERK_COST[pk];
                    p = perk[pk] > 0 ? Component.translatable("cutemod.zombies.perk_max", perkName(pk)).getString() : Component.translatable("cutemod.zombies.perk_buy", perkName(pk), need).getString();
                }
                prompt(g, p, power && points >= need ? 0xFFFFE9A0 : 0xFFFF9A80, 0);
            } else if (tKind == 5) {
                prompt(g, Component.translatable("cutemod.zombies.secret_push").getString(), 0xFFE8C890, 0);
            } else if (tKind == 2) {
                prompt(g, Component.translatable("cutemod.zombies.buy_door", doors.get(tIdx)[2]).getString(), points >= doors.get(tIdx)[2] ? 0xFFFFE9A0 : 0xFFFF9A80, 0);
            } else if (tKind == 3) {
                Win w = wins.get(tIdx);
                prompt(g, Component.translatable("cutemod.zombies.repair", w.boards).getString(), 0xFFE8C890, 0);
                if (repT > 0) { rect(g, W / 2 - 15, H - 34, 30, 2, 0x90000000); rect(g, W / 2 - 15, H - 34, 30 * repT / 22, 2, 0xFFE8C890); }
            }
        }
        if (msgT > 0) {
            int mw = tw(msg) + 12, mx0 = (W - mw) / 2;
            rect(g, mx0, 13, mw, 12, msgT < 30 ? 0x60000000 : 0x90000000);
            rect(g, mx0, 24, mw, 1, msgT < 30 ? 0x60B0A070 : 0xFFE8C890);
            ctext(g, msg, W / 2, 15, msgT < 30 ? 0xFFB0A070 : 0xFFFFFFFF);
        }
    }

    // ---------- the HUD, modern like Black Ops 4 Zombies: the round, the points and the health at the bottom left, the gun and the ammo at the bottom right ----------
    /** Scaled text (the cute font enlarged), with a shadow. */
    private void bigText(GuiGraphics g, String s, int x, int y, float sc, int col, int shadow) {
        g.pose().pushPose();
        g.pose().translate((float) x, (float) y, 0F);
        g.pose().scale(sc, sc, 1F);
        if (shadow != 0) text(g, s, 1, 1, shadow);
        text(g, s, 0, 0, col);
        g.pose().popPose();
    }

    /** A hint (press E to ...) on a dark plate with a colored line, line 0 is the first one, line 1 the one below it. */
    private void prompt(GuiGraphics g, String s, int col, int line) {
        int w = tw(s) + 14, x = (W - w) / 2, y = H - 50 + line * 13;
        rect(g, x, y, w, 11, 0xA0000000);
        rect(g, x, y + 10, w, 1, (col & 0xFFFFFF) | 0xC0000000);
        rect(g, x, y, 2, 11, col);
        text(g, s, x + 7, y + 2, col);
    }

    /** A side view of a gun (the same pictures as over the mystery box), sc times as big as 24 x 10 pixels. */
    private void gunIcon(GuiGraphics g, int gi, int base, int x, int y, double sc) {
        if (gi < 0 || gi >= GUN_ART.length) return;
        if (GUN_RECTS_CACHE[gi] == null) GUN_RECTS_CACHE[gi] = parseArt(GUN_ART[gi]);
        for (int[] q : GUN_RECTS_CACHE[gi]) {
            int x0 = x + (int) (q[0] * sc), y0 = y + (int) (q[1] * sc), x1 = x + (int) ((q[0] + q[2]) * sc), y1 = y + (int) ((q[1] + q[3]) * sc);
            rect(g, x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0), artColor(q[4], base, false));
        }
    }

    private void drawHud(GuiGraphics g) {
        int mh = maxHp();
        // ----- bottom left: the round as a big number, the points, the health, the perks
        String rs = String.valueOf(round);
        float rsc = 3F;
        int rw = (int) (tw(rs) * rsc);
        bigText(g, rs, 6, H - 29, rsc, 0xFFEFE6DC, 0xFF7A0E0E);
        int bx = 6 + rw + 8;
        String ps = String.valueOf(shownPts);
        float psc = 1.5F;
        int pw = Math.max(46, (int) (tw(ps) * psc) + 12);
        int pc = dblT > 0 ? 0xFFE8C030 : 0xFFFFD866;
        rect(g, bx, H - 27, pw, 15, 0x98000000);
        rect(g, bx, H - 27, 2, 15, pc);
        bigText(g, ps, bx + 6, H - 24, psc, dblT > 0 ? 0xFFFFE070 : 0xFFFFFFFF, 0xFF402800);
        if (popT > 0 && popAmt != 0 && popT * 8 >= 12) {                              // +60 / -950 floating up and fading out
            String pp = (popAmt > 0 ? "+" : "") + popAmt;
            text(g, pp, bx + pw + 5, H - 25 - (80 - popT) / 8, (Math.min(255, popT * 8) << 24) | (popAmt > 0 ? 0xFFE060 : 0xFF6050));
        }
        int hw = (int) (64 * mh / 100.0);                                              // the health bar: longer with Juggernog, segments of 25
        float hf = (float) Math.max(0, hp) / mh;
        boolean low = hf < 0.35F;
        rect(g, bx, H - 9, hw + 2, 6, 0xA0000000);
        int hc = low ? (((ticks / 8) & 1) == 0 ? 0xFFFF4040 : 0xFFB02828) : hf < 0.7F ? 0xFFF0C040 : 0xFFEAF2F2;
        rect(g, bx + 1, H - 8, (int) (hw * hf), 4, hc);
        for (int m = 25; m < mh; m += 25) rect(g, bx + 1 + (int) (hw * m / (double) mh), H - 8, 1, 4, 0xB0000000);
        if (low) rect(g, bx - 1, H - 10, hw + 4, 1, 0x60FF4040);
        int py = H - 46;                                                               // the perks you have, going up the left edge
        for (int i = 0; i < PERKS; i++) {
            if (perk[i] == 0) continue;
            rect(g, 4, py - 1, ZombieArt.MINI_SIZE + 2, ZombieArt.MINI_SIZE + 2, 0x90000000);
            drawPicture(g, ZombieArt.miniIcon(i, PERK_COL[i]), 5, py);
            py -= ZombieArt.MINI_SIZE + 3;
        }

        // ----- bottom right: the gun, the magazine big, the reserve small, the other guns above
        int ci = curIndex();
        int xr = W - 6;
        boolean lowMag = cur.mag == 0 || cur.mag * 4 <= cur.magSize;
        String mg = String.valueOf(cur.mag), res = "/" + (cur.infinite ? "--" : String.valueOf(cur.reserve));
        int resW = tw(res);
        text(g, res, xr - resW, H - 20, cur.reserve == 0 && !cur.infinite ? 0xFFFF7060 : 0xFFB0B8C8);
        float msc = 2F;
        int mgW = (int) (tw(mg) * msc), mgx = xr - resW - 4 - mgW;
        bigText(g, mg, mgx, H - 29, msc, reload > 0 ? 0xFFFFD866 : lowMag ? 0xFFFF5848 : 0xFFFFFFFF, 0xFF101018);
        rect(g, mgx - 32, H - 28, 28, 14, 0x70000000);
        gunIcon(g, ci, cur.col, mgx - 30, H - 26, 1.0);
        String gn = cur.pap ? Component.translatable("cutemod.zombies.pap_tag", gunName(ci)).getString() : gunName(ci);
        text(g, gn, xr - tw(gn), H - 39, cur.pap ? 0xFFFFA050 : 0xFFB8C4D8);
        rect(g, xr - 52, H - 9, 52, 3, 0x90000000);                                    // the reload: a bar that fills up
        if (reload > 0 && reloadMax > 0) {
            rect(g, xr - 52, H - 9, 52 * (reloadMax - reload) / reloadMax, 3, 0xFFFFD866);
        } else {
            int bars = Math.min(10, Math.max(1, cur.magSize));                          // the magazine as a row of little bars
            int on = (int) Math.ceil(bars * (double) cur.mag / Math.max(1, cur.magSize));
            for (int i = 0; i < bars; i++) rect(g, xr - 52 + i * 52 / bars, H - 9, Math.max(1, 52 / bars - 1), 3, i < on ? (lowMag ? 0xFFFF5848 : 0xFFE8EEF4) : 0x50FFFFFF);
        }
        int backY = H - 50;                                                            // the guns on your back, and the mines
        for (int si = 0; si < slots(); si++) {
            Weapon ow = slot[si];
            if (ow == null || ow == cur) continue;
            int oi = 0;
            for (int i = 0; i < weapons.length; i++) if (weapons[i] == ow) oi = i;
            String bt = ow.mag + "/" + ow.reserve;
            text(g, bt, xr - tw(bt), backY, ow.mag + ow.reserve == 0 ? 0xFFB06050 : 0xFF9AA6BC);
            gunIcon(g, oi, ow.col, xr - tw(bt) - 15, backY + 1, 0.5);
            text(g, String.valueOf(si + 1), xr - tw(bt) - 21, backY, 0xFF6A7690);
            backY -= 10;
        }
        if (mines > 0) {
            String mt = Component.translatable("cutemod.zombies.mines", mines).getString();
            text(g, mt, xr - tw(mt), backY, 0xFFFF9A80);
        }

        // ----- top right: running power-ups, a label and a shrinking line
        int fy = 5;
        if (instaT > 0) { fxBar(g, "cutemod.zombies.fx.insta", instaT, 0xFFE05050, fy); fy += 15; }
        if (dblT > 0) fxBar(g, "cutemod.zombies.fx.double", dblT, 0xFFE8C030, fy);
        if (reload > 0) ctext(g, Component.translatable("cutemod.zombies.reload").getString(), W / 2, H / 2 + 12, 0xFFFFD866);
    }

    private void fxBar(GuiGraphics g, String key, int t, int color, int y) {
        String lb = Component.translatable(key).getString();
        int w = Math.max(46, tw(lb) + 12), x = W - 5 - w;
        rect(g, x, y, w, 13, 0x98000000);
        rect(g, x + w - 2, y, 2, 13, color);
        text(g, lb, x + 4, y + 1, color);
        rect(g, x + 3, y + 10, w - 8, 2, 0x60000000);
        rect(g, x + 3, y + 10, (w - 8) * Math.min(1200, t) / 1200, 2, color);
    }

    /** The perk cards between two rounds: press 1-3 or click one. Every card has a big picture of its perk. */
    private void renderOffer(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0xB0000000);
        ctext(g, Component.translatable("cutemod.zombies.perk_title").getString(), W / 2, 9, 0xFFFFE9A0);
        int n = offer.length, x0 = (W - (n * CARD_W + (n - 1) * 4)) / 2;
        for (int i = 0; i < n; i++) {
            int p = offer[i], x = x0 + i * (CARD_W + 4), y = CARD_Y;
            boolean hv = in(mx, my, x, y, CARD_W, CARD_H);
            rect(g, x - 1, y - 1, CARD_W + 2, CARD_H + 2, hv ? PERK_COL[p] : 0xFF121722);          // frame (glows in the perk color when hovered)
            rect(g, x, y, CARD_W, CARD_H, hv ? 0xFF3A4868 : 0xFF262E44);
            rect(g, x, y + CARD_H / 2, CARD_W, CARD_H / 2, hv ? 0xFF334060 : 0xFF202739);          // a darker lower half
            rect(g, x, y, CARD_W, 4, PERK_COL[p]);
            rect(g, x, y + 4, CARD_W, 1, ZombieArt.shade(PERK_COL[p], 0.5));
            // the picture: a round medallion with a glow in the color of the perk
            int ix = x + (CARD_W - ZombieArt.ICON) / 2, iy = y + 10 + (hv ? (int) Math.round(Math.sin(ticks * 0.25)) : 0);
            rect(g, ix - 3, y + 8, ZombieArt.ICON + 6, ZombieArt.ICON + 4, ZombieArt.shade(PERK_COL[p], hv ? 0.42 : 0.3));
            rect(g, ix - 2, y + 9, ZombieArt.ICON + 4, ZombieArt.ICON + 2, hv ? 0xFF1B2234 : 0xFF161B2A);
            drawPicture(g, ZombieArt.icon(p, PERK_COL[p]), ix, iy);
            String name = "[" + (i + 1) + "] " + Component.translatable("cutemod.zombies.perk." + p + ".name").getString();
            int ly = y + 40;
            for (var seq : font().split(FormattedText.of(name), CARD_W - 8)) {
                g.drawString(font(), seq, x + 4, ly, 0xFFFFFFFF, false);
                ly += 9;
            }
            ly += 2;
            rect(g, x + 4, ly - 1, CARD_W - 8, 1, 0xFF3A4560);
            ly += 2;
            for (var seq : font().split(FormattedText.of(Component.translatable("cutemod.zombies.perk." + p + ".desc").getString()), CARD_W - 8)) {
                if (ly > y + CARD_H - 15) break;
                g.drawString(font(), seq, x + 4, ly, 0xFFC8D0E0, false);
                ly += 9;
            }
            for (int l = 0; l < 3; l++) {                                                      // the 3 levels: the next one is outlined
                int lx = x + CARD_W / 2 - 12 + l * 9, lyy = y + CARD_H - 9;
                rect(g, lx, lyy, 7, 5, 0xFF10141E);
                rect(g, lx + 1, lyy + 1, 5, 3, l < perk[p] ? PERK_COL[p] : l == perk[p] ? 0xFF6A7690 : 0xFF3A4254);
            }
        }
    }

    /** Draws a small picture (int[row][col] ARGB): rows of equal color in one column are one rectangle, horizontal runs are merged. */
    private void drawPicture(GuiGraphics g, int[][] pic, int x0, int y0) {
        for (int y = 0; y < pic.length; y++) {
            int x = 0;
            while (x < pic[y].length) {
                int c = pic[y][x], e = x + 1;
                while (e < pic[y].length && pic[y][e] == c) e++;
                if ((c >>> 24) != 0) rect(g, x0 + x, y0 + y, e - x, 1, c);
                x = e;
            }
        }
    }

    @Override
    public String hintKey() { return "cutemod.hint.zombies"; }

    @Override
    public Component status() { return Component.translatable("cutemod.zombies.status", round, kills, score); }

    @Override
    public Component endTitle() { return Component.translatable("cutemod.zombies.end", round); }
}
