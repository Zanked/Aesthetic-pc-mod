package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import dev.cutemod.client.os.Fit;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Quiet Hive: an Among Us style game for one player. Eight pets live on a small station, two of them are impostors.
 * You are the crew (do tasks, report bodies, argue and vote) or an impostor (kill, vent, sabotage, lie), every second game
 * the other role. The seven bots are not decoration: each one walks the map, remembers who it saw and where, and at a
 * meeting says what it really saw (or, if it is an impostor, lies). The vote follows what the bots believe.
 * The camera follows the player, the rest of the map is hidden by walls and fog.
 */
public class Hive extends MiniGame {
    private static final int T = 8, MW = 48, MH = 30, N = 8, PER = 4, SIGHT = 56, SPOTS = 14;
    private static final int PH_ROLE = 0, PH_PLAY = 1, PH_MEET = 2, PH_END = 3;
    private static final int M_INTRO = 0, M_TALK = 1, M_VOTE = 2, M_SHOW = 3, M_EJECT = 4;
    private static final int K_WIRES = 0, K_UPLOAD = 1, K_FUEL = 2, K_KEYPAD = 3, K_BUGS = 4, K_CALIB = 5;
    private static final int A_USE = 0, A_REPORT = 1, A_KILL = 2, A_VENT = 3, A_DARK = 4, A_CORE = 5, A_MAP = 6;
    private static final int[] CREW_ACTS = {A_USE, A_REPORT, A_MAP};
    private static final int[] IMP_ACTS = {A_USE, A_KILL, A_VENT, A_DARK, A_CORE, A_MAP};
    private static final String[] ACT_KEYS = {"use", "report", "kill", "vent", "dark", "core", "map"};
    private static final int KILL_CD = 1500;
    private static final float SPEED = 1.0F, BOT_SPEED = 0.85F;

    // pet = 0 pig, 1 frog, 2 panda, 3 mouse, 4 fox, 5 koala, 6 cat, 7 bear
    private static final int[] COLORS = {0xFFF4A7C3, 0xFF7ED957, 0xFFF4F0E8, 0xFF6FA8F2, 0xFFF5A04A, 0xFFB57BD6, 0xFFF3D46A, 0xFFE0594F};
    // rooms: 0 cafeteria, 1 engine, 2 electrical, 3 storage, 4 lab, 5 navigation, 6 garden, 7 hallway
    private static final int[][] ROOMS = {{18, 10, 12, 9}, {2, 2, 10, 7}, {2, 21, 10, 7}, {19, 22, 10, 6}, {36, 2, 10, 7}, {36, 21, 10, 7}, {19, 1, 10, 6}};
    private static final int[][] HALLS = {{23, 7, 2, 3}, {23, 19, 2, 3}, {6, 9, 2, 12}, {40, 9, 2, 12}, {6, 13, 12, 2}, {30, 13, 12, 2}};
    private static final int[][] BLOCKS = {{23, 13, 2, 2}, {6, 4, 2, 2}, {6, 24, 2, 2}, {40, 4, 2, 2}, {40, 24, 2, 2}, {23, 3, 2, 2}, {23, 24, 2, 2}};
    private static final int[] ROOM_COL = {0xFF5C4F9E, 0xFF6A5290, 0xFF52568F, 0xFF5E4F86, 0xFF4F5E9A, 0xFF58529A, 0xFF4F6A8C, 0xFF463E78};
    private static final int[] TX = {10, 3, 10, 4, 20, 27, 37, 44, 37, 44, 27, 20, 19, 28};
    private static final int[] TY = {3, 7, 24, 22, 26, 23, 3, 7, 26, 22, 5, 5, 11, 17};
    private static final int[] KIND = {K_FUEL, K_CALIB, K_WIRES, K_KEYPAD, K_UPLOAD, K_FUEL, K_BUGS, K_UPLOAD, K_CALIB, K_WIRES, K_BUGS, K_KEYPAD, K_WIRES, K_KEYPAD};
    private static final int[] VX = {3, 3, 20, 44, 44, 27}, VY = {3, 26, 2, 3, 26, 26}, VG = {0, 0, 0, 1, 1, 1};
    private static final int LX = 10, LY = 22;                       // the light panel
    private static final int[] CX = {10, 38}, CY = {6, 23};          // the two reactor consoles
    private static final int BX = 192, BY = 112;                     // the emergency button (pixels)
    private static final int[] WIRE_COL = {0xFFE0594F, 0xFF4A8FE0, 0xFFF3D46A};
    private static final int PX = 14, PY = 6, PW = 192, PH = 128;     // the task window

    private static boolean nextImp, roleSeen;

    private static final class Actor {
        final int id;
        boolean imp, alive = true, vented;
        float x, y;
        int face = 1;
        int[] path = new int[0];
        int pp;
        int mode, timer, taskI = -1, fixKind = -1, hunt = -1, huntT, killCd, ventAt = -1, ventT, bodyT = -1, ghostT, lastRoom;
        int witness = -1, witnessV = -1, ventSaw = -1;
        final int[] seenTick = new int[N], seenRoom = new int[N], susp = new int[N];
        final int[] spot = new int[PER];
        final boolean[] done = new boolean[PER];

        Actor(int id) { this.id = id; }
    }

    private static final class Body { int victim, killer, room, tick; float x, y; boolean reported; }

    private static final class Line {
        final int who;
        final Component text;

        Line(int who, Component text) { this.who = who; this.text = text; }
    }

    private final boolean[][] solid = new boolean[MH][MW];
    private final boolean[][] blk = new boolean[MH][MW];
    private final boolean[][] vis = new boolean[MH][MW];
    private final Actor[] act = new Actor[N];
    private final int[] pet = new int[N];
    private final List<Body> bodies = new ArrayList<>();
    private final List<Line> lines = new ArrayList<>();

    private int phase, phaseT, ticks, kills, doneTasks, totalTasks, killFlash;
    private boolean playerImp, crewWon, won;
    private boolean lightsOut, reactorOn, buttonUsed, mapOpen;
    private int reactorT, sabCd, hold;
    private final boolean[] consoleOk = new boolean[2];

    // task window
    private boolean taskOpen, tFix, tFake;
    private int tKind, tIdx, tDone;
    private final int[] wr = new int[3], wc = new int[3];
    private int wsel, upT, knext, cz, chit;
    private boolean upOn;
    private float fuel, cm, cv;
    private final int[] kx = new int[5], ky = new int[5];
    private final float[] bx = new float[6], by = new float[6], bvx = new float[6], bvy = new float[6];
    private final boolean[] bdead = new boolean[6];

    // meeting
    private int mstate, mt, caller, bodyIdx, shown, lineT, sel, pVote, pActs, ejected, skipCount;
    private boolean ejWasImp;
    private final int[] vote = new int[N], tally = new int[N], pub = new int[N];

    public Hive() { buildMap(); }

    private void buildMap() {
        for (boolean[] r : solid) java.util.Arrays.fill(r, true);
        for (int[] r : ROOMS) carve(r, false);
        for (int[] r : HALLS) carve(r, false);
        for (int[] r : BLOCKS) {
            carve(r, true);
            for (int y = r[1]; y < r[1] + r[3]; y++) for (int x = r[0]; x < r[0] + r[2]; x++) blk[y][x] = true;
        }
    }

    private void carve(int[] r, boolean s) {
        for (int y = r[1]; y < r[1] + r[3]; y++) for (int x = r[0]; x < r[0] + r[2]; x++) solid[y][x] = s;
    }

    // ------------------------------------------------------------------ start

    @Override
    public void reset() {
        score = 0; over = false; won = false; crewWon = false;
        phase = PH_ROLE; phaseT = 200; ticks = 0; kills = 0; doneTasks = 0; killFlash = 0;
        bodies.clear(); lines.clear();
        lightsOut = false; reactorOn = false; reactorT = 0; sabCd = 900; buttonUsed = false; hold = 0;
        taskOpen = false; mapOpen = false;
        int[] perm = {0, 1, 2, 3, 4, 5, 6, 7};
        for (int i = N - 1; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = perm[i]; perm[i] = perm[j]; perm[j] = t; }
        System.arraycopy(perm, 0, pet, 0, N);
        nextImp = roleSeen ? !nextImp : rnd.nextBoolean();      // every second game is the other role
        roleSeen = true;
        playerImp = nextImp;
        boolean[] imp = new boolean[N];
        if (playerImp) imp[0] = true;
        int need = playerImp ? 1 : 2;
        while (need > 0) { int i = 1 + rnd.nextInt(N - 1); if (!imp[i]) { imp[i] = true; need--; } }
        totalTasks = 0;
        for (int i = 0; i < N; i++) {
            Actor a = new Actor(i);
            act[i] = a;
            a.imp = imp[i];
            int c = 0;
            while (c < PER) {
                int s = rnd.nextInt(SPOTS);
                boolean dup = false;
                for (int k = 0; k < c; k++) if (a.spot[k] == s) dup = true;
                if (!dup) a.spot[c++] = s;
            }
            if (!a.imp) totalTasks += PER;
            float ang = i * (float) Math.PI / 4F;
            a.x = BX + (float) Math.cos(ang) * 26F;
            a.y = BY + (float) Math.sin(ang) * 26F;
            a.killCd = 1500 + rnd.nextInt(900);
            for (int k = 0; k < N; k++) { a.seenTick[k] = -99999; a.seenRoom[k] = 0; }
        }
        act[0].killCd = 600;
    }

    // ------------------------------------------------------------------ helpers

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private String nm(int id) { return tr("cutemod.hive.name." + pet[id]); }

    private static String rm(int r) { return tr("cutemod.hive.room." + Math.max(0, Math.min(7, r))); }

    private static float dist(float x0, float y0, float x1, float y1) {
        float dx = x1 - x0, dy = y1 - y0;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private boolean solidTile(int tx, int ty) { return tx < 0 || ty < 0 || tx >= MW || ty >= MH || solid[ty][tx]; }

    private boolean solidAt(float x, float y) { return solidTile((int) Math.floor(x / T), (int) Math.floor(y / T)); }

    private boolean free(float x, float y) {
        return !solidAt(x - 3, y - 3) && !solidAt(x + 3, y - 3) && !solidAt(x - 3, y + 3) && !solidAt(x + 3, y + 3);
    }

    private int roomTile(int tx, int ty) {
        for (int i = 0; i < ROOMS.length; i++) {
            int[] r = ROOMS[i];
            if (tx >= r[0] && tx < r[0] + r[2] && ty >= r[1] && ty < r[1] + r[3]) return i;
        }
        return 7;
    }

    private int roomAt(float x, float y) { return roomTile((int) (x / T), (int) (y / T)); }

    /** True if nothing solid is between the two points (the tile of the target itself does not count). */
    private boolean los(float x0, float y0, float x1, float y1) {
        int tx = (int) (x1 / T), ty = (int) (y1 / T);
        float dx = x1 - x0, dy = y1 - y0;
        int n = (int) (Math.sqrt(dx * dx + dy * dy) / 3F) + 1;
        for (int i = 1; i < n; i++) {
            float f = i / (float) n;
            int cx = (int) ((x0 + dx * f) / T), cy = (int) ((y0 + dy * f) / T);
            if (cx == tx && cy == ty) return true;
            if (solidTile(cx, cy)) return false;
        }
        return true;
    }

    private boolean near(Actor a, float x, float y, float r) { return dist(a.x, a.y, x, y) < r; }

    private static int clampi(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private int[] bfs(int sx, int sy, int gx, int gy) {
        sx = clampi(sx, 0, MW - 1); sy = clampi(sy, 0, MH - 1); gx = clampi(gx, 0, MW - 1); gy = clampi(gy, 0, MH - 1);
        int[] prev = new int[MW * MH];
        java.util.Arrays.fill(prev, -2);
        int[] q = new int[MW * MH];
        int h = 0, t = 0, s = sy * MW + sx, goal = gy * MW + gx;
        prev[s] = -1; q[t++] = s;
        int[] ddx = {1, -1, 0, 0}, ddy = {0, 0, 1, -1};
        while (h < t) {
            int c = q[h++];
            if (c == goal) break;
            int cx = c % MW, cy = c / MW;
            for (int k = 0; k < 4; k++) {
                int nx = cx + ddx[k], ny = cy + ddy[k];
                if (nx < 0 || ny < 0 || nx >= MW || ny >= MH || solid[ny][nx]) continue;
                int n = ny * MW + nx;
                if (prev[n] != -2) continue;
                prev[n] = c; q[t++] = n;
            }
        }
        if (prev[goal] == -2) return new int[0];
        int len = 0;
        for (int c = goal; c != -1; c = prev[c]) len++;
        int[] out = new int[len];
        int i = len - 1;
        for (int c = goal; c != -1; c = prev[c]) out[i--] = c;
        return out;
    }

    private void setPath(Actor a, int tx, int ty) {
        a.path = bfs((int) (a.x / T), (int) (a.y / T), tx, ty);
        a.pp = a.path.length > 1 ? 1 : 0;
    }

    private boolean walk(Actor a, float sp) {
        if (a.pp >= a.path.length) return false;
        int t = a.path[a.pp];
        float tx = (t % MW) * T + T / 2F, ty = (t / MW) * T + T / 2F;
        float dx = tx - a.x, dy = ty - a.y, d = dist(0, 0, dx, dy);
        if (d <= sp) { a.x = tx; a.y = ty; a.pp++; return a.pp < a.path.length; }
        a.x += dx / d * sp;
        a.y += dy / d * sp;
        if (Math.abs(dx) > 0.4F) a.face = dx > 0 ? 1 : -1;
        return true;
    }

    private int nearVent(float x, float y, float r) {
        int best = -1;
        float bd = r;
        for (int i = 0; i < VX.length; i++) {
            float d = dist(x, y, VX[i] * T + 4, VY[i] * T + 4);
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }

    private int nextVent(int vi, int dir) {
        int n = VX.length;
        for (int k = 1; k <= n; k++) {
            int i = ((vi + dir * k) % n + n) % n;
            if (VG[i] == VG[vi] && i != vi) return i;
        }
        return vi;
    }

    private int vision() {
        Actor p = act[0];
        if (!p.alive) return 999;
        if (p.imp) return 82;
        return lightsOut ? 24 : 62;
    }

    // ------------------------------------------------------------------ play

    @Override
    public void tick() {
        if (phase == PH_ROLE) { if (--phaseT <= 0) phase = PH_PLAY; return; }
        if (phase == PH_END) { if (--phaseT <= 0) over = true; return; }
        if (phase == PH_MEET) { meetTick(); return; }
        playTick();
    }

    private void playTick() {
        ticks++;
        Actor p = act[0];
        if (killFlash > 0) killFlash--;
        if (taskOpen) updateTask(); else movePlayer();
        // hold E at a reactor console
        boolean holding = false;
        if (reactorOn && !p.imp && !p.vented && !taskOpen && down(69)) {
            for (int i = 0; i < 2; i++) {
                if (!consoleOk[i] && near(p, CX[i] * T + 4, CY[i] * T + 4, 16)) {
                    holding = true;
                    if (++hold >= 120) { hold = 0; completeFix(i + 1); }
                }
            }
        }
        if (!holding) hold = 0;
        for (int i = 1; i < N; i++) botTick(act[i]);
        if (p.killCd > 0) p.killCd--;
        if (ticks % 8 == 0) observe();
        if (!lightsOut && !reactorOn) {
            if (sabCd > 0) sabCd--;
            else if (ticks % 60 == 0 && rnd.nextInt(100) < 5 && botImpAlive()) trigger(rnd.nextInt(2));
        } else if (ticks % 300 == 0) assignFixers();
        if (reactorOn && --reactorT <= 0) { reactorOn = false; end(false); }
    }

    private boolean botImpAlive() {
        for (int i = 1; i < N; i++) if (act[i].imp && act[i].alive) return true;
        return false;
    }

    private void movePlayer() {
        Actor p = act[0];
        if (p.vented) return;
        int dx = 0, dy = 0;
        if (down(87) || down(KEY_UP)) dy--;
        if (down(83) || down(KEY_DOWN)) dy++;
        if (down(65) || down(KEY_LEFT)) dx--;
        if (down(68) || down(KEY_RIGHT)) dx++;
        if (dx == 0 && dy == 0) return;
        float sp = p.alive ? SPEED : 1.3F;
        if (dx != 0 && dy != 0) sp *= 0.707F;
        if (dx != 0) p.face = dx;
        float nx = p.x + dx * sp;
        if (!p.alive || free(nx, p.y)) p.x = Math.max(4, Math.min(MW * T - 4, nx));
        float ny = p.y + dy * sp;
        if (!p.alive || free(p.x, ny)) p.y = Math.max(4, Math.min(MH * T - 4, ny));
    }

    /** What the bots see: who is where (for the talk at the meeting) and bodies. */
    private void observe() {
        for (int i = 1; i < N; i++) {
            Actor b = act[i];
            if (!b.alive || b.vented) continue;
            for (Actor o : act) {
                if (o == b || !o.alive || o.vented) continue;
                if (dist(b.x, b.y, o.x, o.y) < SIGHT && los(b.x, b.y, o.x, o.y)) {
                    b.seenTick[o.id] = ticks;
                    b.seenRoom[o.id] = roomAt(o.x, o.y);
                }
            }
            if (b.imp || b.bodyT >= 0 || b.mode == 6) continue;       // impostors never report what they find
            for (int k = 0; k < bodies.size(); k++) {
                Body d = bodies.get(k);
                if (!d.reported && dist(b.x, b.y, d.x, d.y) < SIGHT && los(b.x, b.y, d.x, d.y)) {
                    b.bodyT = k; b.mode = 5; b.fixKind = -1;
                    setPath(b, (int) (d.x / T), (int) (d.y / T));
                    break;
                }
            }
        }
    }

    private int nextTask(Actor b) {
        for (int i = 0; i < PER; i++) if (!b.done[i]) return i;
        return -1;
    }

    private void botTick(Actor b) {
        if (!b.alive) {                     // a dead crewmate finishes its tasks slowly
            if (!b.imp && ++b.ghostT >= 1500) {
                b.ghostT = 0;
                for (int i = 0; i < PER; i++) if (!b.done[i]) { b.done[i] = true; doneTasks++; break; }
                checkWin();
            }
            return;
        }
        if (b.killCd > 0) b.killCd--;
        if (b.vented) { if (--b.ventT <= 0) ventExit(b); return; }
        if (b.imp && b.killCd <= 0 && (b.mode == 0 || b.mode == 1 || b.mode == 2) && ticks % 10 == b.id) tryHunt(b);
        switch (b.mode) {
            case 0 -> {
                int t = nextTask(b);
                if (t >= 0) { b.taskI = t; setPath(b, TX[b.spot[t]], TY[b.spot[t]]); }
                else { b.taskI = -1; int s = rnd.nextInt(SPOTS); setPath(b, TX[s], TY[s]); }
                b.mode = 1;
            }
            case 1 -> {
                if (!walk(b, BOT_SPEED)) { b.mode = 2; b.timer = b.taskI >= 0 ? 260 + rnd.nextInt(260) : 90 + rnd.nextInt(150); }
            }
            case 2 -> {
                if (--b.timer <= 0) {
                    if (b.taskI >= 0) { b.done[b.taskI] = true; if (!b.imp) { doneTasks++; checkWin(); } }
                    b.mode = 0;
                }
            }
            case 3 -> {
                if (fixDone(b.fixKind)) { b.mode = 0; b.fixKind = -1; }
                else if (!walk(b, BOT_SPEED + 0.1F)) { b.mode = 4; b.timer = 150; }
            }
            case 4 -> {
                if (fixDone(b.fixKind)) { b.mode = 0; b.fixKind = -1; }
                else if (--b.timer <= 0) { int k = b.fixKind; b.mode = 0; b.fixKind = -1; completeFix(k); }
            }
            case 5 -> {
                if (b.bodyT < 0 || b.bodyT >= bodies.size() || bodies.get(b.bodyT).reported) { b.bodyT = -1; b.mode = 0; }
                else {
                    Body d = bodies.get(b.bodyT);
                    if (dist(b.x, b.y, d.x, d.y) < 16) startMeeting(b.id, b.bodyT);
                    else if (!walk(b, BOT_SPEED + 0.15F)) setPath(b, (int) (d.x / T), (int) (d.y / T));
                }
            }
            case 6 -> huntTick(b);
            default -> b.mode = 0;
        }
    }

    // ------------------------------------------------------------------ killing

    private int witnesses(Actor killer, Actor victim) {
        int n = 0;
        for (Actor w : act) {
            if (w == killer || w == victim || !w.alive || w.imp || w.vented) continue;
            float r = (w.id == 0 && lightsOut) ? 26F : SIGHT + 10F;
            if (dist(w.x, w.y, killer.x, killer.y) < r && los(w.x, w.y, killer.x, killer.y)) n++;
        }
        return n;
    }

    private void tryHunt(Actor b) {
        Actor best = null;
        float bd = 1e9F;
        for (Actor v : act) {
            if (v.imp || !v.alive || v.vented) continue;
            float d = dist(b.x, b.y, v.x, v.y);
            if (d < 72 && d < bd && los(b.x, b.y, v.x, v.y)) { best = v; bd = d; }
        }
        if (best == null || witnesses(b, best) > 0) return;
        if (rnd.nextInt(100) < 35) { b.hunt = best.id; b.huntT = 360; b.mode = 6; }
    }

    private void huntTick(Actor b) {
        Actor v = act[Math.max(0, b.hunt)];
        if (b.hunt < 0 || !v.alive || v.imp || --b.huntT <= 0) { b.mode = 0; b.hunt = -1; return; }
        if (ticks % 15 == 0) setPath(b, (int) (v.x / T), (int) (v.y / T));
        if (dist(b.x, b.y, v.x, v.y) < 11) {
            if (witnesses(b, v) == 0) doKill(b, v);
            else { b.mode = 0; b.hunt = -1; b.killCd = 300; }
            return;
        }
        walk(b, BOT_SPEED + 0.1F);
    }

    private void doKill(Actor k, Actor v) {
        Body d = new Body();
        d.victim = v.id; d.killer = k.id; d.x = v.x; d.y = v.y; d.tick = ticks; d.room = roomAt(v.x, v.y);
        bodies.add(d);
        v.alive = false; v.vented = false;
        for (Actor w : act) {
            if (w == k || w == v || !w.alive || w.imp || w.vented) continue;
            if (dist(w.x, w.y, v.x, v.y) < SIGHT && los(w.x, w.y, v.x, v.y)) { w.witness = k.id; w.witnessV = v.id; }
        }
        k.x = v.x; k.y = v.y; k.path = new int[0]; k.pp = 0;
        k.killCd = k.id == 0 ? KILL_CD : 2000 + rnd.nextInt(900);
        sound(SoundEvents.PLAYER_HURT, 0.8F, 0.6F);
        if (k.id == 0) kills++;
        else {
            k.hunt = -1; k.mode = 0;
            int r = rnd.nextInt(100);
            if (r < 30) tryBotVent(k);
            else if (r < 50 && witnesses(k, v) == 0) { k.bodyT = bodies.size() - 1; k.mode = 5; }   // reports its own kill
        }
        if (v.id == 0) { killFlash = 90; taskOpen = false; mapOpen = false; }
        checkWin();
    }

    private void tryBotVent(Actor b) {
        int vi = nearVent(b.x, b.y, 32);
        if (vi < 0) return;
        ventWitness(b.x, b.y, b.id);
        b.vented = true; b.ventAt = vi; b.ventT = 100 + rnd.nextInt(120);
        b.x = VX[vi] * T + 4; b.y = VY[vi] * T + 4;
    }

    private void ventExit(Actor b) {
        int vi = nextVent(b.ventAt, 1);
        b.vented = false; b.mode = 0; b.ventAt = -1;
        b.x = VX[vi] * T + 4; b.y = VY[vi] * T + 4;
        ventWitness(b.x, b.y, b.id);
    }

    private void ventWitness(float x, float y, int id) {
        for (Actor w : act) {
            if (w.id == id || !w.alive || w.imp || w.vented || w.id == 0) continue;
            if (dist(w.x, w.y, x, y) < SIGHT && los(w.x, w.y, x, y)) w.ventSaw = id;
        }
    }

    // ------------------------------------------------------------------ sabotage

    private void trigger(int kind) {
        if (kind == 0) lightsOut = true;
        else { reactorOn = true; reactorT = 2100; consoleOk[0] = false; consoleOk[1] = false; }
        sabCd = 1500;
        assignFixers();
        sound(SoundEvents.BELL_BLOCK, 0.6F, 0.7F);
    }

    private void assignFixers() {
        if (lightsOut) assignNear(LX, LY, 0);
        if (reactorOn) { assignNear(CX[0], CY[0], 1); assignNear(CX[1], CY[1], 2); }
    }

    private void assignNear(int tx, int ty, int kind) {
        int have = 0;
        int want = kind == 0 ? 2 : 1;
        for (int i = 1; i < N; i++) if (act[i].alive && act[i].fixKind == kind) have++;
        while (have < want) {
            Actor best = null;
            float bd = 1e9F;
            for (int i = 1; i < N; i++) {
                Actor b = act[i];
                if (!b.alive || b.imp || b.vented || b.fixKind >= 0 || b.mode == 5) continue;
                float d = dist(b.x, b.y, tx * T + 4, ty * T + 4);
                if (d < bd) { bd = d; best = b; }
            }
            if (best == null) return;
            best.fixKind = kind; best.mode = 3;
            setPath(best, tx, ty);
            have++;
        }
    }

    private boolean fixDone(int kind) {
        if (kind == 0) return !lightsOut;
        return !reactorOn || consoleOk[kind - 1];
    }

    private void completeFix(int kind) {
        if (kind == 0) lightsOut = false;
        else {
            consoleOk[kind - 1] = true;
            if (consoleOk[0] && consoleOk[1]) reactorOn = false;
        }
        pling(1.3F);
    }

    // ------------------------------------------------------------------ the player's actions

    @Override
    public boolean key(int k) {
        if (phase == PH_ROLE) { phaseT = 0; return true; }
        if (phase != PH_PLAY) return false;
        Actor p = act[0];
        if (mapOpen) { mapOpen = false; return true; }
        if (taskOpen) {
            if (tKind == K_FUEL && k == KEY_SPACE && tDone == 0) { fuel = Math.min(100F, fuel + 7F); beep(); }
            return true;
        }
        if (p.vented) {
            if (k == KEY_RIGHT) { hopVent(1); return true; }
            if (k == KEY_LEFT) { hopVent(-1); return true; }
            if (k == KEY_SPACE || k == 86) { doAction(A_VENT); return true; }
            return false;
        }
        if (k == 69) { doAction(A_USE); return true; }
        if (k == 82) { doAction(A_REPORT); return true; }
        if (k == 81) { doAction(A_KILL); return true; }
        if (k == 86) { doAction(A_VENT); return true; }
        if (k == 77) { doAction(A_MAP); return true; }
        if (k == 49) { doAction(A_DARK); return true; }
        if (k == 50) { doAction(A_CORE); return true; }
        return false;
    }

    private void doAction(int a) {
        switch (a) {
            case A_USE -> use();
            case A_REPORT -> report();
            case A_KILL -> kill();
            case A_VENT -> ventAction();
            case A_DARK -> sabotage(0);
            case A_CORE -> sabotage(1);
            default -> mapOpen = !mapOpen;
        }
    }

    private void use() {
        Actor p = act[0];
        if (p.vented || (!p.alive && p.imp)) return;
        if (lightsOut && !p.imp && near(p, LX * T + 4, LY * T + 4, 16)) { startTask(K_KEYPAD, -1, true, false); return; }
        for (int i = 0; i < PER; i++) {
            if (p.done[i]) continue;
            int s = p.spot[i];
            if (near(p, TX[s] * T + 4, TY[s] * T + 4, 14)) { startTask(KIND[s], i, false, p.imp); return; }
        }
        if (p.alive && !buttonUsed && !lightsOut && !reactorOn && near(p, BX, BY, 26)) { buttonUsed = true; startMeeting(0, -1); }
    }

    private void report() {
        Actor p = act[0];
        if (!p.alive || p.vented) return;
        for (int i = 0; i < bodies.size(); i++) {
            Body d = bodies.get(i);
            if (!d.reported && dist(p.x, p.y, d.x, d.y) < 24 && los(p.x, p.y, d.x, d.y)) { startMeeting(0, i); return; }
        }
    }

    private Actor killTarget() {
        Actor p = act[0];
        if (!playerImp || !p.alive || p.vented || phase != PH_PLAY) return null;
        Actor best = null;
        float bd = 22F;
        for (Actor a : act) {
            if (a.imp || !a.alive || a.vented) continue;
            float d = dist(p.x, p.y, a.x, a.y);
            if (d < bd && los(p.x, p.y, a.x, a.y)) { bd = d; best = a; }
        }
        return best;
    }

    private void kill() {
        Actor p = act[0];
        if (!playerImp || p.killCd > 0) return;
        Actor v = killTarget();
        if (v != null) doKill(p, v);
    }

    private void ventAction() {
        Actor p = act[0];
        if (!playerImp || !p.alive) return;
        if (!p.vented) {
            int vi = nearVent(p.x, p.y, 14);
            if (vi < 0) return;
            ventWitness(p.x, p.y, 0);
            p.vented = true; p.ventAt = vi;
            p.x = VX[vi] * T + 4; p.y = VY[vi] * T + 4;
            sound(SoundEvents.ENDERMAN_TELEPORT, 1.2F, 0.5F);
        } else {
            p.vented = false;
            ventWitness(p.x, p.y, 0);
            sound(SoundEvents.ENDERMAN_TELEPORT, 1.4F, 0.5F);
        }
    }

    private void hopVent(int dir) {
        Actor p = act[0];
        p.ventAt = nextVent(p.ventAt, dir);
        p.x = VX[p.ventAt] * T + 4; p.y = VY[p.ventAt] * T + 4;
        beep();
    }

    private void sabotage(int kind) {
        if (!playerImp || sabCd > 0 || lightsOut || reactorOn || phase != PH_PLAY) return;
        trigger(kind);
    }

    // ------------------------------------------------------------------ win

    private void checkWin() {
        if (phase == PH_END) return;
        int ac = 0, ai = 0;
        for (Actor a : act) if (a.alive) { if (a.imp) ai++; else ac++; }
        if (ai == 0) end(true);
        else if (ai >= ac) end(false);
        else if (doneTasks >= totalTasks) end(true);
    }

    private void end(boolean crewWins) {
        if (phase == PH_END) return;
        phase = PH_END; phaseT = 150; crewWon = crewWins; won = crewWins != playerImp;
        taskOpen = false; mapOpen = false;
        int mine = 0;
        for (int i = 0; i < PER; i++) if (act[0].done[i]) mine++;
        score = playerImp ? kills * 20 : mine * 10;
        if (won) score += 60;
        if (won) sound(SoundEvents.PLAYER_LEVELUP, 1.0F, 0.6F); else sound(SoundEvents.VILLAGER_NO, 0.8F, 0.6F);
    }

    // ------------------------------------------------------------------ tasks

    private void startTask(int kind, int idx, boolean fix, boolean fake) {
        taskOpen = true; tKind = kind; tIdx = idx; tFix = fix; tFake = fake; tDone = 0;
        switch (kind) {
            case K_WIRES -> {
                int[] o = {0, 1, 2};
                for (int i = 2; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = o[i]; o[i] = o[j]; o[j] = t; }
                for (int i = 0; i < 3; i++) { wr[i] = o[i]; wc[i] = -1; }
                wsel = -1;
            }
            case K_UPLOAD -> { upT = 0; upOn = false; }
            case K_FUEL -> fuel = 0;
            case K_KEYPAD -> {
                int[] s = {0, 1, 2, 3, 4, 5};
                for (int i = 5; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = s[i]; s[i] = s[j]; s[j] = t; }
                for (int i = 0; i < 5; i++) { kx[i] = 44 + (s[i] % 3) * 56; ky[i] = 54 + (s[i] / 3) * 40; }
                knext = 0;
            }
            case K_BUGS -> {
                for (int i = 0; i < 6; i++) {
                    bx[i] = 40 + rnd.nextInt(140); by[i] = 46 + rnd.nextInt(72);
                    bvx[i] = (rnd.nextBoolean() ? 1 : -1) * (0.5F + rnd.nextFloat() * 0.7F);
                    bvy[i] = (rnd.nextBoolean() ? 1 : -1) * (0.4F + rnd.nextFloat() * 0.6F);
                    bdead[i] = false;
                }
            }
            default -> { cm = 0; cv = 1.9F; cz = 20 + rnd.nextInt(100); chit = 0; }
        }
    }

    private void updateTask() {
        if (tDone > 0) { if (--tDone <= 0) closeTask(true); return; }
        switch (tKind) {
            case K_UPLOAD -> { if (upOn && ++upT >= 300) finishTask(); }
            case K_FUEL -> { fuel = Math.max(0F, fuel - 0.22F); if (fuel >= 100F) finishTask(); }
            case K_BUGS -> {
                for (int i = 0; i < 6; i++) {
                    if (bdead[i]) continue;
                    bx[i] += bvx[i]; by[i] += bvy[i];
                    if (bx[i] < 30 || bx[i] > 190) bvx[i] = -bvx[i];
                    if (by[i] < 42 || by[i] > 120) bvy[i] = -bvy[i];
                    if (ticks % 40 == i && rnd.nextInt(100) < 30) { bvx[i] += (rnd.nextFloat() - 0.5F) * 0.4F; bvy[i] += (rnd.nextFloat() - 0.5F) * 0.4F; }
                }
            }
            case K_CALIB -> { cm += cv; if (cm < 0 || cm > 160) { cv = -cv; cm = Math.max(0, Math.min(160, cm)); } }
            default -> { }
        }
    }

    private void finishTask() {
        tDone = 26;
        pling(1.4F);
    }

    private void closeTask(boolean finished) {
        taskOpen = false;
        if (!finished) return;
        Actor p = act[0];
        if (tFix) completeFix(0);
        else if (tIdx >= 0) {
            p.done[tIdx] = true;
            if (!tFake) { doneTasks++; checkWin(); }
        }
    }

    private boolean taskClick(int x, int y) {
        if (in(x, y, PX + PW - 15, PY + 2, 13, 13)) { closeTask(false); return true; }
        if (tDone > 0) return true;
        switch (tKind) {
            case K_WIRES -> {
                for (int i = 0; i < 3; i++) {
                    if (in(x, y, 20, 46 + i * 26, 18, 14) && wc[i] < 0) { wsel = i; beep(); return true; }
                }
                if (wsel >= 0) {
                    for (int j = 0; j < 3; j++) {
                        if (in(x, y, PX + PW - 28, 46 + j * 26, 18, 14)) {
                            if (wr[j] == wsel) {
                                wc[wsel] = j;
                                pling(1.0F + wsel * 0.2F);
                                if (wc[0] >= 0 && wc[1] >= 0 && wc[2] >= 0) finishTask();
                            } else sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F);
                            wsel = -1;
                            return true;
                        }
                    }
                }
            }
            case K_UPLOAD -> { if (!upOn && in(x, y, 80, 62, 60, 20)) { upOn = true; beep(); } }
            case K_FUEL -> { fuel = Math.min(100F, fuel + 7F); beep(); if (fuel >= 100F) finishTask(); }
            case K_KEYPAD -> {
                for (int i = 0; i < 5; i++) {
                    if (in(x, y, kx[i] - 12, ky[i] - 10, 24, 20)) {
                        if (i == knext) { knext++; pling(1.0F + i * 0.15F); if (knext >= 5) finishTask(); }
                        else { knext = 0; sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F); }
                        return true;
                    }
                }
            }
            case K_BUGS -> {
                boolean all = true;
                for (int i = 0; i < 6; i++) {
                    if (!bdead[i] && dist(x, y, bx[i], by[i]) < 8) { bdead[i] = true; sound(SoundEvents.SLIME_SQUISH, 1.4F, 0.5F); }
                    if (!bdead[i]) all = false;
                }
                if (all) finishTask();
            }
            default -> {
                if (cm >= cz && cm <= cz + 26) {
                    chit++;
                    pling(1.0F + chit * 0.2F);
                    cz = 10 + rnd.nextInt(120);
                    if (chit >= 3) finishTask();
                } else { chit = Math.max(0, chit - 1); sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F); }
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ meetings

    private void startMeeting(int by, int body) {
        for (Actor a : act) {
            a.lastRoom = roomAt(a.x, a.y);
            a.vented = false; a.mode = 0; a.bodyT = -1; a.hunt = -1; a.fixKind = -1; a.path = new int[0]; a.pp = 0;
        }
        phase = PH_MEET; mstate = M_INTRO; mt = 0; caller = by; bodyIdx = body;
        taskOpen = false; mapOpen = false; hold = 0;
        sel = -1; pVote = -2; pActs = 0; shown = 0; lineT = 30; ejected = -1;
        java.util.Arrays.fill(pub, 0);
        buildLines();
        for (Body d : bodies) d.reported = true;
        sound(SoundEvents.BELL_BLOCK, 1.0F, 0.8F);
    }

    private void say(int who, String key, int variants, Object... args) {
        lines.add(new Line(who, Component.translatable(key + "." + rnd.nextInt(variants), args)));
    }

    private void buildLines() {
        lines.clear();
        Body d = bodyIdx >= 0 ? bodies.get(bodyIdx) : null;
        if (d != null) say(caller, "cutemod.hive.m.found", 3, nm(d.victim), rm(d.room));
        else say(caller, "cutemod.hive.m.button", 3);
        List<Actor> order = new ArrayList<>();
        for (Actor a : act) if (a.alive && a.id != 0 && a.id != caller) order.add(a);
        java.util.Collections.shuffle(order, new java.util.Random(rnd.nextLong()));
        int cnt = 0;
        for (Actor b : order) {
            if (cnt >= 6) break;
            statement(b, d);
            cnt++;
        }
    }

    /** One bot says what it knows. Crew tells the truth, an impostor lies. */
    private void statement(Actor b, Body d) {
        if (!b.imp) {
            if (b.witness >= 0 && b.witnessV >= 0) {
                say(b.id, "cutemod.hive.m.kill", 3, nm(b.witness), nm(b.witnessV));
                accuse(b.id, b.witness, 150);
                return;
            }
            if (b.ventSaw >= 0) {
                say(b.id, "cutemod.hive.m.vent", 3, nm(b.ventSaw));
                accuse(b.id, b.ventSaw, 150);
                return;
            }
            int s = d != null ? suspectFor(b, d) : -1;
            if (s >= 0) {
                say(b.id, "cutemod.hive.m.near", 3, nm(s), rm(d.room));
                b.susp[s] += 60;                    // it saw this one itself
                accuse(b.id, s, 40);
                return;
            }
            int o = recentOther(b);
            if (o >= 0) {
                say(b.id, "cutemod.hive.m.alibi", 3, nm(o), rm(b.seenRoom[o]));
                b.susp[o] = Math.max(0, b.susp[o] - 25);
                return;
            }
            say(b.id, "cutemod.hive.m.nothing", 3, rm(b.lastRoom));
            return;
        }
        int s = scapegoat(b);
        if (s >= 0 && rnd.nextInt(100) < 60) {
            say(b.id, "cutemod.hive.m.near", 3, nm(s), rm(d != null ? d.room : rnd.nextInt(7)));
            accuse(b.id, s, 40);
        } else say(b.id, "cutemod.hive.m.nothing", 3, rm(rnd.nextInt(7)));
    }

    /** Who this bot saw in the room of the body shortly before the death. */
    private int suspectFor(Actor b, Body d) {
        int best = -1, bt = -1;
        for (Actor o : act) {
            if (o.id == b.id || o.id == d.victim) continue;
            int t = b.seenTick[o.id];
            if (t >= d.tick - 1200 && t <= d.tick + 300 && b.seenRoom[o.id] == d.room && t > bt) { bt = t; best = o.id; }
        }
        return best;
    }

    private int recentOther(Actor b) {
        int best = -1, bt = ticks - 1800;
        for (Actor o : act) {
            if (o.id == b.id || !o.alive) continue;
            if (b.seenTick[o.id] > bt) { bt = b.seenTick[o.id]; best = o.id; }
        }
        return best;
    }

    private int scapegoat(Actor b) {
        List<Integer> c = new ArrayList<>();
        for (Actor o : act) {
            if (o.imp || !o.alive || o.id == b.id) continue;
            c.add(o.id);
            if (o.id == 0) c.add(0);
        }
        return c.isEmpty() ? -1 : c.get(rnd.nextInt(c.size()));
    }

    /** A public accusation: the other bots weigh it (less if they know the accused was elsewhere). */
    private void accuse(int speaker, int target, int weight) {
        pub[target]++;
        Body d = bodyIdx >= 0 ? bodies.get(bodyIdx) : null;
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.id == speaker || c.id == target) continue;
            int w = weight;
            if (d != null && weight < 100) {
                int t = c.seenTick[target];
                if (t > d.tick - 600 && t < d.tick + 600 && c.seenRoom[target] != d.room) w /= 4;
            }
            c.susp[target] += weight >= 100 ? w : w / 2;      // what others say counts less than what you saw
        }
    }

    private void playerAccuse(int t) {
        Actor ta = act[t];
        if (!ta.alive || t == 0) return;
        pActs++;
        say(0, "cutemod.hive.m.accuse", 3, nm(t));
        if (ta.imp) {
            int s = scapegoat(ta);
            say(t, "cutemod.hive.m.point", 3, nm(s >= 0 ? s : 0));
            if (s >= 0) accuse(t, s, 20);
        } else say(t, "cutemod.hive.m.defend", 3, rm(ta.lastRoom));
        int n = 0;
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.id == t) continue;
            if (n < 2 && (c.susp[t] >= 25 || rnd.nextInt(100) < 25)) {
                say(c.id, "cutemod.hive.m.agree", 3, nm(t));
                c.susp[t] += 30;
                n++;
            } else c.susp[t] += 8;
        }
        afterPlayerLine();
    }

    private void playerAlibi() {
        Actor p = act[0];
        pActs++;
        int room = p.lastRoom;
        if (playerImp) { room = rnd.nextInt(7); if (room == p.lastRoom) room = (room + 1) % 7; }     // an impostor lies
        say(0, "cutemod.hive.m.mine", 3, rm(room));
        boolean said = false;
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.seenTick[0] < ticks - 600) continue;
            if (c.seenRoom[0] == room) c.susp[0] = Math.max(0, c.susp[0] - 25);
            else {
                c.susp[0] += 30;
                if (!said) { said = true; say(c.id, "cutemod.hive.m.liar", 3, rm(c.seenRoom[0])); }
            }
        }
        afterPlayerLine();
    }

    private void afterPlayerLine() { if (shown >= lines.size() - 1) lineT = Math.min(lineT, 25); }

    private void toVote() {
        if (mstate != M_TALK) return;
        mstate = M_VOTE; mt = 0; sel = -1;
        decideVotes();
    }

    private void decideVotes() {
        java.util.Arrays.fill(vote, -3);
        for (int i = 1; i < N; i++) {
            Actor b = act[i];
            if (!b.alive) continue;
            int best = -1, bv = 0;
            if (!b.imp) {
                for (Actor o : act) if (o.alive && o.id != b.id && b.susp[o.id] > bv) { bv = b.susp[o.id]; best = o.id; }
                if (bv >= 90) vote[i] = best;
                else vote[i] = rnd.nextInt(100) < 85 ? -1 : randomOther(b, false);
            } else {
                for (Actor o : act) if (o.alive && !o.imp && pub[o.id] > bv) { bv = pub[o.id]; best = o.id; }
                if (best >= 0) vote[i] = best;
                else vote[i] = rnd.nextInt(100) < 50 ? -1 : randomOther(b, true);
            }
        }
    }

    private int randomOther(Actor b, boolean crewOnly) {
        List<Integer> c = new ArrayList<>();
        for (Actor o : act) if (o.alive && o.id != b.id && (!crewOnly || !o.imp)) c.add(o.id);
        return c.isEmpty() ? -1 : c.get(rnd.nextInt(c.size()));
    }

    private void finishVote() {
        vote[0] = act[0].alive ? (pVote == -2 ? -1 : pVote) : -3;
        java.util.Arrays.fill(tally, 0);
        skipCount = 0;
        for (int i = 0; i < N; i++) {
            int v = vote[i];
            if (v == -1) skipCount++;
            else if (v >= 0) tally[v]++;
        }
        mstate = M_SHOW; mt = 0;
        beep();
    }

    private void computeEject() {
        int best = -1, bv = 0, ties = 0;
        for (int i = 0; i < N; i++) {
            if (tally[i] > bv) { bv = tally[i]; best = i; ties = 1; }
            else if (tally[i] == bv && bv > 0) ties++;
        }
        if (best >= 0 && ties == 1 && bv > skipCount) {
            ejected = best; ejWasImp = act[best].imp; act[best].alive = false;
        } else ejected = -1;
    }

    private void endMeeting() {
        bodies.clear();
        for (int i = 0; i < N; i++) {
            Actor a = act[i];
            if (!a.alive && i != 0) continue;
            float ang = i * (float) Math.PI / 4F;
            a.x = BX + (float) Math.cos(ang) * 26F;
            a.y = BY + (float) Math.sin(ang) * 26F;
            a.witness = -1; a.witnessV = -1; a.ventSaw = -1; a.mode = 0; a.bodyT = -1;
            if (a.imp) a.killCd = Math.max(a.killCd, 900);
        }
        lightsOut = false; reactorOn = false; sabCd = Math.max(sabCd, 900); hold = 0;
        phase = PH_PLAY;
        checkWin();
    }

    private void meetTick() {
        mt++;
        switch (mstate) {
            case M_INTRO -> { if (mt > 100) { mstate = M_TALK; mt = 0; } }
            case M_TALK -> {
                if (shown < lines.size() && --lineT <= 0) { shown++; lineT = 85; beep(); }
                boolean ghost = !act[0].alive;
                if ((ghost && shown >= lines.size() && mt > 60) || mt > 2600) toVote();
            }
            case M_VOTE -> {
                if (!act[0].alive && mt > 90) finishVote();
                else if (mt > 1500) { pVote = -1; finishVote(); }
            }
            case M_SHOW -> { if (mt > 190) { computeEject(); mstate = M_EJECT; mt = 0; sound(SoundEvents.ENDERMAN_TELEPORT, 0.6F, 0.7F); } }
            default -> { if (mt > 240) endMeeting(); }
        }
    }

    private boolean meetClick(int x, int y) {
        Actor p = act[0];
        if (mstate == M_TALK || mstate == M_VOTE) {
            for (int i = 0; i < N; i++) {
                if (in(x, y, 4 + (i % 4) * 54, 15 + (i / 4) * 34, 50, 31)) {
                    if (act[i].alive && i != 0 && p.alive) { sel = i; beep(); }
                    return true;
                }
            }
        }
        if (!p.alive) return true;
        if (mstate == M_TALK) {
            if (in(x, y, 4, 124, 66, 13) && sel >= 0 && pActs < 3) playerAccuse(sel);
            else if (in(x, y, 74, 124, 66, 13) && pActs < 3) playerAlibi();
            else if (in(x, y, 144, 124, 72, 13)) toVote();
        } else if (mstate == M_VOTE) {
            if (in(x, y, 4, 124, 106, 13) && sel >= 0) { pVote = sel; finishVote(); }
            else if (in(x, y, 114, 124, 102, 13)) { pVote = -1; finishVote(); }
        }
        return true;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (phase == PH_ROLE) { phaseT = 0; return true; }
        if (phase == PH_MEET) return meetClick(x, y);
        if (phase != PH_PLAY) return true;
        if (mapOpen) { mapOpen = false; return true; }
        if (taskOpen) return taskClick(x, y);
        int[] acts = playerImp ? IMP_ACTS : CREW_ACTS;
        if (y >= H - 14 && y < H - 2 && x >= 4) {
            int i = (x - 4) / 36;
            if (i < acts.length && (x - 4) % 36 < 34) doAction(acts[i]);
        }
        return true;
    }

    // ------------------------------------------------------------------ drawing: sprites

    private static void bean(GuiGraphics g, int cx, int cy, int pt, int face, boolean ghost) {
        int c = COLORS[pt], d = Gfx.darker(c, 0.28F);
        int white = 0xFFFFFFFF, dark = 0xFF1A1428;
        if (ghost) { c = (c & 0xFFFFFF) | 0x99000000; d = (d & 0xFFFFFF) | 0x99000000; white = 0x99FFFFFF; dark = 0x99000000; }
        // ears and other things behind the head
        switch (pt) {
            case 0 -> { rect(g, cx - 4, cy - 8, 2, 3, d); rect(g, cx + 2, cy - 8, 2, 3, d); }
            case 1 -> { disc(g, cx - 2, cy - 6, 2, white); disc(g, cx + 2, cy - 6, 2, white); rect(g, cx - 2 + (face > 0 ? 1 : 0), cy - 6, 1, 2, dark); rect(g, cx + 2 + (face > 0 ? 1 : 0), cy - 6, 1, 2, dark); }
            case 2 -> { rect(g, cx - 4, cy - 8, 3, 3, dark); rect(g, cx + 1, cy - 8, 3, 3, dark); }
            case 3 -> { disc(g, cx - 4, cy - 6, 3, c); disc(g, cx + 4, cy - 6, 3, c); disc(g, cx - 4, cy - 6, 1, 0xFFF4A7C3); disc(g, cx + 4, cy - 6, 1, 0xFFF4A7C3); }
            case 4 -> { rect(g, cx - 4, cy - 10, 1, 2, c); rect(g, cx - 4, cy - 8, 3, 3, c); rect(g, cx + 3, cy - 10, 1, 2, c); rect(g, cx + 1, cy - 8, 3, 3, c); rect(g, cx - 4, cy - 10, 1, 1, white); rect(g, cx + 3, cy - 10, 1, 1, white); }
            case 5 -> { disc(g, cx - 5, cy - 5, 3, 0xFFD8D0E8); disc(g, cx + 5, cy - 5, 3, 0xFFD8D0E8); disc(g, cx - 5, cy - 5, 1, 0xFF8A7AA8); disc(g, cx + 5, cy - 5, 1, 0xFF8A7AA8); }
            case 6 -> { rect(g, cx - 4, cy - 9, 1, 1, c); rect(g, cx - 4, cy - 8, 3, 3, c); rect(g, cx + 3, cy - 9, 1, 1, c); rect(g, cx + 1, cy - 8, 3, 3, c); }
            default -> { disc(g, cx - 4, cy - 7, 2, d); disc(g, cx + 4, cy - 7, 2, d); }
        }
        // body
        rect(g, cx - 3, cy - 7, 6, 1, c);
        rect(g, cx - 4, cy - 6, 8, 10, c);
        rect(g, cx + 2, cy - 6, 2, 10, d);
        if (ghost) rect(g, cx - 4, cy + 4, 8, 2, c);
        else { rect(g, cx - 4, cy + 4, 3, 2, d); rect(g, cx + 1, cy + 4, 3, 2, d); }
        if (pt == 2) { rect(g, cx - 4, cy - 5, 4, 4, dark); rect(g, cx, cy - 5, 4, 4, dark); }   // the panda's eye patches
        if (pt != 1) {
            int ex = cx - 3 + (face > 0 ? 1 : 0), pxo = face > 0 ? 1 : 0;
            rect(g, ex, cy - 4, 2, 3, white); rect(g, ex + 3, cy - 4, 2, 3, white);
            rect(g, ex + pxo, cy - 3, 1, 2, dark); rect(g, ex + 3 + pxo, cy - 3, 1, 2, dark);
        } else {
            rect(g, cx - 2, cy - 2, 4, 1, dark);
        }
    }

    private static void corpse(GuiGraphics g, int cx, int cy, int pt) {
        int c = COLORS[pt], d = Gfx.darker(c, 0.3F);
        rect(g, cx - 4, cy - 3, 8, 1, c);
        rect(g, cx - 5, cy - 2, 10, 4, c);
        rect(g, cx - 4, cy + 2, 8, 1, d);
        rect(g, cx + 3, cy - 2, 2, 4, d);
        rect(g, cx - 1, cy - 6, 2, 3, 0xFFF4F0E8);
        rect(g, cx - 3, cy - 1, 1, 1, 0xFF1A1428); rect(g, cx - 1, cy - 1, 1, 1, 0xFF1A1428);
        rect(g, cx - 2, cy, 1, 1, 0xFF1A1428);
    }

    private void bigBean(GuiGraphics g, int x, int y, int pt, float scale, boolean ghost) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1F);
        bean(g, 0, 0, pt, 1, ghost);
        g.pose().popPose();
    }

    // ------------------------------------------------------------------ drawing: the world

    @Override
    public void render(GuiGraphics g) {
        if (phase == PH_MEET) { renderMeeting(g); return; }
        renderWorld(g);
        if (phase == PH_PLAY) {
            renderHud(g);
            if (taskOpen) renderTask(g);
            if (mapOpen) renderMap(g);
        }
        if (phase == PH_ROLE) renderRole(g);
        if (phase == PH_END) renderEnd(g);
    }

    private void renderWorld(GuiGraphics g) {
        Actor p = act[0];
        g.fill(0, 0, W, H, 0xFF0A0818);
        float camx = Math.max(0, Math.min(MW * T - W, p.x - W / 2F)), camy = Math.max(0, Math.min(MH * T - H, p.y - H / 2F));
        int ox = -(int) camx, oy = -(int) camy;
        boolean full = !p.alive;
        float rad = vision();
        int tx0 = Math.max(0, (int) (camx / T)), ty0 = Math.max(0, (int) (camy / T));
        int tx1 = Math.min(MW - 1, tx0 + W / T + 1), ty1 = Math.min(MH - 1, ty0 + H / T + 1);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                float cx = tx * T + T / 2F, cy = ty * T + T / 2F;
                float d = dist(p.x, p.y, cx, cy);
                boolean v = full || (d < rad && los(p.x, p.y, cx, cy));
                vis[ty][tx] = v;
                if (!v) continue;
                int px = tx * T + ox, py = ty * T + oy, c;
                if (blk[ty][tx]) c = 0xFFB58A5A;
                else if (solid[ty][tx]) c = 0xFF2D2656;
                else { c = ROOM_COL[roomTile(tx, ty)]; if (((tx + ty) & 1) == 1) c = Gfx.lighter(c, 0.05F); }
                g.fill(px, py, px + T, py + T, c);
                if (blk[ty][tx]) g.fill(px, py, px + T, py + 2, 0xFFD9AE7A);
                else if (solid[ty][tx] && ty + 1 < MH && !solid[ty + 1][tx]) g.fill(px, py + T - 2, px + T, py + T, 0xFF5A4CA0);
                if (!full) {
                    float k = Math.min(1F, d / rad);
                    int a = (int) (k * k * 200F);
                    if (a > 0) g.fill(px, py, px + T, py + T, a << 24);
                }
            }
        }
        // the emergency button, vents, the panel and consoles
        if (visPx(BX, BY)) { disc(g, BX + ox, BY + oy, 3, 0xFFE0594F); rect(g, BX + ox - 1, BY + oy - 2, 2, 1, 0xFFFFB0A8); }
        for (int i = 0; i < VX.length; i++) {
            if (!visPx(VX[i] * T + 4, VY[i] * T + 4)) continue;
            int sx = VX[i] * T + ox, sy = VY[i] * T + oy;
            rect(g, sx + 1, sy + 2, 6, 4, 0xFF1A1630);
            rect(g, sx + 1, sy + 3, 6, 1, 0xFF4A4470);
            rect(g, sx + 1, sy + 5, 6, 1, 0xFF4A4470);
        }
        boolean pulse = (ticks / 15) % 2 == 0;
        if (lightsOut) marker(g, LX, LY, ox, oy, 0xFFFFB347, pulse);
        if (reactorOn) for (int i = 0; i < 2; i++) if (!consoleOk[i]) marker(g, CX[i], CY[i], ox, oy, 0xFFE0594F, pulse);
        for (int i = 0; i < PER; i++) {
            if (p.done[i]) continue;
            int s = p.spot[i];
            marker(g, TX[s], TY[s], ox, oy, 0xFFFFE066, true);
        }
        // bodies
        for (Body d : bodies) if (visPx(d.x, d.y)) corpse(g, (int) d.x + ox, (int) d.y + oy, pet[d.victim]);
        // the one the player can kill
        Actor kt = killTarget();
        // pets (the player is drawn last, on top)
        for (int n = 1; n <= N; n++) {
            Actor a = act[n % N];
            if (a.vented) continue;
            if (!a.alive && !full) continue;                       // only a ghost sees the ghosts
            if (a.alive && a.id != 0 && !visPx(a.x, a.y)) continue;
            int sx = (int) a.x + ox, sy = (int) a.y + oy;
            if (sx < -12 || sx > W + 12 || sy < -14 || sy > H + 14) continue;
            bean(g, sx, a.alive ? sy : sy - 2, pet[a.id], a.face, !a.alive);
            if (a == kt) Gfx.outline(g, sx - 6, sy - 9, 12, 16, 0xFFFF4040);
            if (a.id == 0) { rect(g, sx - 1, sy - 14, 3, 1, 0xFFFFE066); rect(g, sx, sy - 13, 1, 1, 0xFFFFE066); }
            else if (playerImp && a.imp && a.alive) rect(g, sx - 1, sy - 13, 3, 2, 0xFFFF4040);
        }
        if (lightsOut || reactorOn) {
            if (reactorOn && pulse) g.fill(0, 0, W, H, 0x22FF2020);
        }
        if (killFlash > 0) g.fill(0, 0, W, H, (Math.min(110, killFlash * 3) << 24) | 0xC02020);
    }

    private boolean visPx(float x, float y) {
        int tx = (int) (x / T), ty = (int) (y / T);
        return tx >= 0 && ty >= 0 && tx < MW && ty < MH && vis[ty][tx];
    }

    private void marker(GuiGraphics g, int tx, int ty, int ox, int oy, int col, boolean on) {
        if (!visPx(tx * T + 4, ty * T + 4) || !on) return;
        int sx = tx * T + ox + 4, sy = ty * T + oy + 4 - ((ticks / 12) % 2);
        rect(g, sx - 2, sy - 7, 5, 5, col);
        rect(g, sx - 1, sy - 6, 3, 1, 0xFF3A2A10);
        rect(g, sx, sy - 5, 1, 1, 0xFF3A2A10);
        rect(g, sx - 1, sy - 8, 3, 1, Gfx.lighter(col, 0.5F));
    }

    // ------------------------------------------------------------------ drawing: HUD, tasks, map, splash

    private void renderHud(GuiGraphics g) {
        Actor p = act[0];
        rect(g, 4, 4, 72, 7, 0xAA000000);
        int w = totalTasks == 0 ? 0 : 70 * doneTasks / totalTasks;
        rect(g, 5, 5, w, 5, 0xFF7ED957);
        Fit.str(g, font(), tr("cutemod.hive.tasks"), 80, 3, 0xFFFFFFFF, true, W - 40);
        Fit.str(g, font(), tr(playerImp ? "cutemod.hive.role.imp" : "cutemod.hive.role.crew"), W - 68, 3, playerImp ? 0xFFFF6A6A : 0xFF7FE0FF, true, W - 2);
        int ti = nextTask(p);
        if (ti >= 0) {
            int s = p.spot[ti];
            Fit.str(g, font(), tr("cutemod.hive.next", tr("cutemod.hive.task." + KIND[s]), rm(roomTile(TX[s], TY[s]))), 5, 13, 0xFFFFE066, true, W - 4);
        }
        boolean flash = (ticks / 15) % 2 == 0;
        if (lightsOut) ctextW(g, tr("cutemod.hive.sab.lights"), W / 2, 25, W - 8, flash ? 0xFFFFB347 : 0xFFFF6A6A);
        if (reactorOn) ctextW(g, tr("cutemod.hive.sab.reactor", (reactorT + 59) / 60), W / 2, 25, W - 8, flash ? 0xFFFF4040 : 0xFFFFB0A8);
        if (hold > 0) {
            rect(g, W / 2 - 30, 38, 60, 6, 0xAA000000);
            rect(g, W / 2 - 29, 39, 58 * hold / 120, 4, 0xFF7ED957);
            ctext(g, tr("cutemod.hive.hold"), W / 2, 46, 0xFFFFFFFF);
        }
        if (p.vented) ctextW(g, tr("cutemod.hive.ventmsg"), W / 2, 25, W - 8, 0xFFFFFFFF);
        else if (!p.alive) ctextW(g, tr(p.imp ? "cutemod.hive.dead.imp" : "cutemod.hive.dead"), W / 2, 25, W - 8, 0xFFB8B0F0);
        Fit.str(g, font(), rm(roomAt(p.x, p.y)), 5, H - 25, 0xFFFFFFFF, true, 100);
        int[] acts = playerImp ? IMP_ACTS : CREW_ACTS;
        for (int i = 0; i < acts.length; i++) {
            int a = acts[i], x = 4 + i * 36, y = H - 14;
            boolean on = actionOn(a);
            boolean hov = on && in(mx, my, x, y, 34, 12);
            Gfx.bubble(g, x, y, 34, 12, 3, !on ? 0xAA2A2550 : (hov ? 0xFF8A78E8 : 0xFF6A58C8));
            String label = tr("cutemod.hive.a." + ACT_KEYS[a]);
            if (a == A_KILL && p.killCd > 0) label = String.valueOf((p.killCd + 59) / 60);
            if ((a == A_DARK || a == A_CORE) && sabCd > 0 && !lightsOut && !reactorOn) label = String.valueOf((sabCd + 59) / 60);
            ctextW(g, label, x + 17, y + 2, 31, on ? 0xFFFFFFFF : 0x88FFFFFF);
        }
    }

    private boolean actionOn(int a) {
        Actor p = act[0];
        switch (a) {
            case A_USE: {
                if (p.vented || (!p.alive && p.imp)) return false;
                if (lightsOut && !p.imp && near(p, LX * T + 4, LY * T + 4, 16)) return true;
                for (int i = 0; i < PER; i++) if (!p.done[i] && near(p, TX[p.spot[i]] * T + 4, TY[p.spot[i]] * T + 4, 14)) return true;
                return p.alive && !buttonUsed && !lightsOut && !reactorOn && near(p, BX, BY, 26);
            }
            case A_REPORT: {
                if (!p.alive || p.vented) return false;
                for (Body d : bodies) if (!d.reported && dist(p.x, p.y, d.x, d.y) < 24 && los(p.x, p.y, d.x, d.y)) return true;
                return false;
            }
            case A_KILL: return p.killCd <= 0 && killTarget() != null;
            case A_VENT: return p.alive && (p.vented || nearVent(p.x, p.y, 14) >= 0);
            case A_DARK:
            case A_CORE: return sabCd <= 0 && !lightsOut && !reactorOn;
            default: return true;
        }
    }

    private void renderTask(GuiGraphics g) {
        g.fill(0, 0, W, H, 0xAA000000);
        Gfx.bubble(g, PX, PY, PW, PH, 6, 0xFF2E2860);
        ctext(g, tr("cutemod.hive.task." + tKind), W / 2, PY + 4, 0xFFFFFFFF);
        ctextW(g, tr("cutemod.hive.t." + tKind), W / 2, PY + 15, PW - 24, 0xFFB8B0F0);
        boolean hx = in(mx, my, PX + PW - 15, PY + 2, 13, 13);
        rect(g, PX + PW - 15, PY + 2, 13, 13, hx ? 0xFFFF7A70 : 0xFFE0594F);
        ctext(g, "x", PX + PW - 8, PY + 4, 0xFFFFFFFF);
        switch (tKind) {
            case K_WIRES -> {
                for (int i = 0; i < 3; i++) {
                    int y = 53 + i * 26;
                    rect(g, 20, y - 7, 18, 14, 0xFF3A3470);
                    rect(g, 24, y - 2, 14, 4, WIRE_COL[i]);
                    if (wsel == i) Gfx.outline(g, 20, y - 7, 18, 14, 0xFFFFFFFF);
                    int ry = 53 + i * 26;
                    rect(g, PX + PW - 28, ry - 7, 18, 14, 0xFF3A3470);
                    rect(g, PX + PW - 28, ry - 2, 14, 4, WIRE_COL[wr[i]]);
                }
                for (int i = 0; i < 3; i++) if (wc[i] >= 0) Gfx.line(g, 38, 53 + i * 26, PX + PW - 28, 53 + wc[i] * 26, WIRE_COL[i]);
                if (wsel >= 0) Gfx.line(g, 38, 53 + wsel * 26, mx, my, WIRE_COL[wsel]);
            }
            case K_UPLOAD -> {
                if (!upOn) {
                    boolean h = in(mx, my, 80, 62, 60, 20);
                    Gfx.bubble(g, 80, 62, 60, 20, 5, h ? 0xFF8A78E8 : 0xFF6A58C8);
                    ctext(g, tr("cutemod.hive.start"), 110, 68, 0xFFFFFFFF);
                }
                rect(g, 40, 96, 140, 12, 0xFF1A1630);
                rect(g, 41, 97, 138 * upT / 300, 10, 0xFF7ED957);
            }
            case K_FUEL -> {
                Gfx.outline(g, 90, 36, 40, 88, 0xFFFFFFFF);
                rect(g, 91, 37, 38, 86, 0xFF1A1630);
                int h = (int) (84 * fuel / 100F);
                rect(g, 92, 122 - h, 36, h, 0xFFF5A04A);
                ctext(g, "SPACE", 160, 76, 0xFFB8B0F0);
            }
            case K_KEYPAD -> {
                for (int i = 0; i < 5; i++) {
                    boolean d = i < knext;
                    boolean h = !d && in(mx, my, kx[i] - 12, ky[i] - 10, 24, 20);
                    Gfx.bubble(g, kx[i] - 12, ky[i] - 10, 24, 20, 4, d ? 0xFF3E8F55 : (h ? 0xFF8A78E8 : 0xFF5A4AA0));
                    ctext(g, String.valueOf(i + 1), kx[i], ky[i] - 4, 0xFFFFFFFF);
                }
            }
            case K_BUGS -> {
                for (int i = 0; i < 6; i++) {
                    if (bdead[i]) continue;
                    int x = (int) bx[i], y = (int) by[i];
                    disc(g, x, y, 4, 0xFFF3D46A);
                    rect(g, x - 1, y - 3, 2, 6, 0xFF3A2A10);
                    rect(g, x - 5, y - 5, 3, 2, 0xAAFFFFFF);
                    rect(g, x + 3, y - 5, 3, 2, 0xAAFFFFFF);
                }
            }
            default -> {
                rect(g, 30, 70, 160, 14, 0xFF1A1630);
                rect(g, 30 + cz, 70, 26, 14, 0xFF3E8F55);
                rect(g, 30 + (int) cm - 1, 66, 3, 22, 0xFFFFFFFF);
                ctext(g, chit + " / 3", W / 2, 100, 0xFFFFE066);
            }
        }
        if (tDone > 0) ctext(g, "OK!", W / 2, 118, 0xFF7ED957);
    }

    private void renderMap(GuiGraphics g) {
        Actor p = act[0];
        g.fill(0, 0, W, H, 0xDD000000);
        int ox = 14, oy = 10, s = 4;
        for (int ty = 0; ty < MH; ty++) {
            for (int tx = 0; tx < MW; tx++) {
                if (solid[ty][tx] && !blk[ty][tx]) continue;
                int c = blk[ty][tx] ? 0xFFB58A5A : ROOM_COL[roomTile(tx, ty)];
                g.fill(ox + tx * s, oy + ty * s, ox + tx * s + s, oy + ty * s + s, Gfx.lighter(c, 0.1F));
            }
        }
        for (int i = 0; i < VX.length; i++) rect(g, ox + VX[i] * s, oy + VY[i] * s, s, s, 0xFF1A1630);
        for (int i = 0; i < PER; i++) if (!p.done[i]) rect(g, ox + TX[p.spot[i]] * s, oy + TY[p.spot[i]] * s, s, s, 0xFFFFE066);
        boolean fl = (ticks / 15) % 2 == 0;
        if (lightsOut && fl) rect(g, ox + LX * s - 1, oy + LY * s - 1, s + 2, s + 2, 0xFFFFB347);
        if (reactorOn && fl) for (int i = 0; i < 2; i++) if (!consoleOk[i]) rect(g, ox + CX[i] * s - 1, oy + CY[i] * s - 1, s + 2, s + 2, 0xFFE0594F);
        if ((ticks / 10) % 2 == 0) disc(g, ox + (int) (p.x / T * s), oy + (int) (p.y / T * s), 2, 0xFFFFFFFF);
        for (int i = 0; i < 7; i++) {
            int[] r = ROOMS[i];
            ctextW(g, rm(i), ox + (r[0] + r[2] / 2) * s, oy + (r[1] + r[3] / 2) * s - 4, r[2] * s, 0xFFFFFFFF);
        }
    }

    private void renderRole(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF1C1546, 0xFF0A0818);
        for (int i = 0; i < 20; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 8) * W), (int) (Gfx.hash(i, 9) * H), 1, i * 13 + phaseT, 0x66FFFFFF);
        int col = playerImp ? 0xFFFF6A6A : 0xFF7FE0FF;
        ctext(g, tr(playerImp ? "cutemod.hive.role.imp" : "cutemod.hive.role.crew"), W / 2, 22, col);
        String partner = "";
        if (playerImp) for (int i = 1; i < N; i++) if (act[i].imp) partner = nm(i);
        ctextW(g, playerImp ? tr("cutemod.hive.role.imp.sub", partner) : tr("cutemod.hive.role.crew.sub"), W / 2, 36, W - 10, 0xFFFFFFFF);
        if (playerImp) {
            bigBean(g, W / 2 - 24, 80, pet[0], 3F, false);
            for (int i = 1; i < N; i++) if (act[i].imp) bigBean(g, W / 2 + 24, 80, pet[i], 3F, false);
        } else {
            for (int i = 0; i < N; i++) bigBean(g, 14 + i * 27, 86, pet[i], 2F, false);
        }
        ctext(g, tr("cutemod.hive.go"), W / 2, 122, 0xFFB8B0F0);
    }

    private void renderEnd(GuiGraphics g) {
        g.fill(0, 40, W, 74, 0xCC000000);
        ctext(g, tr(crewWon ? "cutemod.hive.win.crew" : "cutemod.hive.win.imp"), W / 2, 52, crewWon ? 0xFF7FE0FF : 0xFFFF6A6A);
        ctextW(g, tr(won ? "cutemod.hive.you.win" : "cutemod.hive.you.lose"), W / 2, 68, W - 10, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------------ drawing: the meeting

    private void renderMeeting(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF2A1F5C, 0xFF140F30);
        for (int i = 0; i < 14; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 5) * W), (int) (Gfx.hash(i, 6) * H), 1, i * 17 + mt, 0x55FFFFFF);
        if (mstate == M_INTRO) { renderIntro(g); return; }
        if (mstate == M_EJECT) { renderEject(g); return; }
        ctext(g, tr(mstate == M_TALK ? "cutemod.hive.discuss" : "cutemod.hive.vote"), W / 2, 3, 0xFFFFFFFF);
        for (int i = 0; i < N; i++) card(g, i);
        rect(g, 4, 86, W - 8, 35, 0x66000000);
        int from = Math.max(0, shown - 3);
        for (int k = from; k < shown; k++) {
            Line l = lines.get(k);
            int y = 88 + (k - from) * 11;
            int col = COLORS[pet[l.who]];
            disc(g, 9, y + 4, 3, col);
            String who = nm(l.who) + ": ";
            Fit.str(g, font(), who, 15, y, col, false, W - 5);
            Fit.str(g, font(), l.text.getString(), 15 + tw(who), y, 0xFFFFFFFF, false, W - 5);
        }
        Actor p = act[0];
        if (!p.alive) { ctext(g, tr("cutemod.hive.ghostwatch"), W / 2, 126, 0xFFB8B0F0); return; }
        if (mstate == M_TALK) {
            btn(g, 4, 124, 66, 13, tr("cutemod.hive.b.accuse"), sel >= 0 && pActs < 3);
            btn(g, 74, 124, 66, 13, tr("cutemod.hive.b.alibi"), pActs < 3);
            btn(g, 144, 124, 72, 13, tr("cutemod.hive.b.vote"), true);
        } else if (mstate == M_VOTE) {
            btn(g, 4, 124, 106, 13, tr("cutemod.hive.b.vote"), sel >= 0);
            btn(g, 114, 124, 102, 13, tr("cutemod.hive.b.skip"), true);
        }
    }

    private void card(GuiGraphics g, int i) {
        Actor a = act[i];
        int x = 4 + (i % 4) * 54, y = 15 + (i / 4) * 34;
        boolean hov = a.alive && i != 0 && in(mx, my, x, y, 50, 31);
        int face = !a.alive ? 0xFF2C2650 : (sel == i ? 0xFF6A58C8 : (hov ? 0xFF4A3F90 : 0xFF3A3070));
        Gfx.bubble(g, x, y, 50, 31, 4, face);
        if (sel == i) Gfx.outline(g, x, y, 50, 31, 0xFFFFE066);
        bigBean(g, x + 13, y + 19, pet[i], 2F, !a.alive);
        ctextW(g, nm(i), x + 37, y + 7, 24, a.alive ? 0xFFFFFFFF : 0x88FFFFFF);
        if (i == 0) rect(g, x + 3, y + 3, 3, 3, 0xFFFFE066);
        else if (playerImp && a.imp) rect(g, x + 3, y + 3, 3, 3, 0xFFFF4040);
        if (mstate == M_SHOW) ctext(g, tally[i] > 0 ? String.valueOf(tally[i]) : "-", x + 37, y + 18, tally[i] > 0 ? 0xFFFFE066 : 0x66FFFFFF);
        else if (!a.alive) ctext(g, "x", x + 37, y + 18, 0xFFFF6A6A);
        else if (mstate == M_VOTE && vote[i] != -3) ctext(g, "*", x + 37, y + 18, 0xFF7ED957);
    }

    private void btn(GuiGraphics g, int x, int y, int w, int h, String label, boolean on) {
        boolean hov = on && in(mx, my, x, y, w, h);
        Gfx.bubble(g, x, y, w, h, 4, !on ? 0xFF3A3560 : (hov ? 0xFF8A78E8 : 0xFF6A58C8));
        ctextW(g, label, x + w / 2, y + 3, w - 4, on ? 0xFFFFFFFF : 0x88FFFFFF);
    }

    private void renderIntro(GuiGraphics g) {
        boolean body = bodyIdx >= 0;
        int flash = (mt / 8) % 2 == 0 ? 0xFFFF5A50 : 0xFFFFB0A8;
        Gfx.bubble(g, 16, 36, W - 32, 62, 8, 0xFF3A1F3F);
        ctextW(g, tr(body ? "cutemod.hive.bodyfound" : "cutemod.hive.emergency"), W / 2, 50, W - 40, flash);
        ctextW(g, tr("cutemod.hive.by", nm(caller)), W / 2, 70, W - 40, 0xFFFFFFFF);
        bigBean(g, W / 2, 96, pet[caller], 1F, false);
    }

    private void renderEject(GuiGraphics g) {
        g.fill(0, 0, W, H, 0xFF08061A);
        for (int i = 0; i < 30; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 3) * W), (int) (Gfx.hash(i, 4) * H), 1, i * 11 + mt, 0x88FFFFFF);
        if (ejected >= 0) {
            float k = Math.min(1F, mt / 120F);
            int x = (int) (-20 + k * (W + 40));
            int y = 60 - (int) (Math.sin(k * Math.PI) * 18);
            bigBean(g, x, y, pet[ejected], 3F, false);
        }
        if (mt > 70) {
            String s = ejected >= 0 ? tr(ejWasImp ? "cutemod.hive.eject.imp" : "cutemod.hive.eject.crew", nm(ejected)) : tr("cutemod.hive.eject.none");
            ctextW(g, s, W / 2, 108, W - 10, ejected >= 0 && ejWasImp ? 0xFFFF6A6A : 0xFFFFFFFF);
        }
    }

    // ------------------------------------------------------------------ the rest of the MiniGame contract

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return Component.translatable(crewWon ? "cutemod.hive.win.crew" : "cutemod.hive.win.imp");
    }

    @Override
    public Component status() {
        if (playerImp) return Component.translatable("cutemod.hive.status.imp", kills);
        return Component.translatable("cutemod.hive.status.crew", totalTasks == 0 ? 0 : doneTasks * 100 / totalTasks);
    }

    @Override
    public String hintKey() { return "cutemod.hint.hive"; }
}
