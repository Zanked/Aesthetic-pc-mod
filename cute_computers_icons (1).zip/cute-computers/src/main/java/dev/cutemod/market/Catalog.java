package dev.cutemod.market;

import dev.cutemod.item.ModItems;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Instrument;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Everything CuteMarket sells, in one place shared by the app and the server (prices and delivery times can
 * never disagree): the mod's own foods, the music discs of the game and real gear.
 * Ids are short and fit a network string: "cupcake", "disc_cat", "iron_pickaxe".
 */
public final class Catalog {
    public static final int FOOD = 0, DISC = 1, TOOL = 2, WEAPON = 3, ARMOR = 4;
    /** How many "items" a piece of gear counts for in the daily limit (so a day brings only a few of them). */
    public static int weight(int kind) { return kind >= TOOL ? 8 : 1; }

    /** One thing for sale. maxQty = the most you can order in one line. */
    public record Entry(String id, int kind, int price, int secs, int maxQty) {}

    private static final Map<String, Entry> ENTRIES = new LinkedHashMap<>();

    private static void add(String id, int kind, int price, int secs, int maxQty) {
        ENTRIES.put(id, new Entry(id, kind, price, secs, maxQty));
    }

    static {
        for (String id : ModItems.ids()) add(id, FOOD, ModItems.price(id), ModItems.deliverySecs(id), 16);
        // music discs: the common ones are cheap, the rare ones cost more (name = the game's music_disc_<name>)
        for (String d : new String[]{"13", "cat", "blocks", "chirp", "far", "mall", "mellohi", "stal", "strad", "ward", "11", "wait"})
            add("disc_" + d, DISC, 30, 60, 4);
        for (String d : new String[]{"5", "otherside", "pigstep", "relic", "creator", "creator_music_box", "precipice"})
            add("disc_" + d, DISC, 60, 90, 4);
        // real gear from the game: the ids are the game's own item names (iron_pickaxe, diamond_sword...)
        String[] tiers = {"wooden", "stone", "iron", "golden", "diamond", "netherite"};
        int[] base = {12, 20, 45, 35, 360, 1040};   // diamond x3, netherite x4 (the real progression must stay worth it)
        int[] secs = {60, 75, 90, 90, 180, 300};
        for (int i = 0; i < tiers.length; i++) {
            add(tiers[i] + "_pickaxe", TOOL, base[i], secs[i], 1);
            add(tiers[i] + "_axe", TOOL, base[i], secs[i], 1);
            add(tiers[i] + "_shovel", TOOL, Math.max(1, base[i] / 2), secs[i], 1);
            add(tiers[i] + "_hoe", TOOL, Math.max(1, base[i] / 2), secs[i], 1);
        }
        add("fishing_rod", TOOL, 20, 60, 1);
        add("shears", TOOL, 18, 60, 1);
        add("flint_and_steel", TOOL, 15, 60, 1);
        for (int i = 0; i < tiers.length; i++) add(tiers[i] + "_sword", WEAPON, Math.max(1, base[i] * 9 / 10), secs[i], 1);
        add("bow", WEAPON, 40, 75, 1);
        add("crossbow", WEAPON, 60, 90, 1);
        add("shield", WEAPON, 30, 75, 1);
        String[] armorTiers = {"leather", "chainmail", "iron", "golden", "diamond", "netherite"};
        String[] pieces = {"helmet", "chestplate", "leggings", "boots"};
        int[][] armorPrice = {{10, 16, 14, 8}, {40, 64, 56, 32}, {50, 80, 70, 40}, {40, 64, 56, 32}, {450, 720, 630, 360}, {1320, 2080, 1840, 1040}};
        int[] armorSecs = {60, 90, 90, 90, 180, 300};
        for (int i = 0; i < armorTiers.length; i++) {
            for (int k = 0; k < pieces.length; k++) add(armorTiers[i] + "_" + pieces[k], ARMOR, armorPrice[i][k], armorSecs[i], 1);
        }
    }

    private Catalog() {}

    public static Entry get(String id) { return ENTRIES.get(id); }

    public static List<Entry> entries(int kind) {
        List<Entry> out = new ArrayList<>();
        for (Entry e : ENTRIES.values()) if (e.kind() == kind) out.add(e);
        return out;
    }

    /** One real item for this id (stack size 1), or an empty stack if the id is unknown. */
    public static ItemStack create(String id, RegistryAccess access) {
        Entry e = ENTRIES.get(id);
        if (e == null) return ItemStack.EMPTY;
        switch (e.kind()) {
            case FOOD -> {
                Item food = ModItems.food(id);
                return food == null ? ItemStack.EMPTY : new ItemStack(food);
            }
            case DISC -> {
                Item disc = BuiltInRegistries.ITEM.get(ResourceLocation.withDefaultNamespace("music_disc_" + id.substring(5)));
                return disc == Items.AIR ? ItemStack.EMPTY : new ItemStack(disc);
            }
            default -> {                                   // tools, weapons, armor: the game's own item with this name
                Item gear = BuiltInRegistries.ITEM.get(ResourceLocation.withDefaultNamespace(id));
                return gear == Items.AIR ? ItemStack.EMPTY : new ItemStack(gear);
            }
        }
    }
}
