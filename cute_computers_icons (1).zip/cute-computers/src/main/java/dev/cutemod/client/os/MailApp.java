package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/** The mail app: a list of letters and a reading view with a "take the reward" button. */
public class MailApp extends App {
    private static final int HEAD = 17, ROW = 24;
    private static final int[] SENDER = {0xFF8A7AA8, 0xFFF58FB8, 0xFFF3C45A, 0xFF3A2A3A, 0xFF7BCB8A};

    private Mail.Msg open;
    private int scroll;
    private int oy;          // > 0 when shown inside the browser (BeeMail): offset below the address bar
    private boolean web;     // BeeMail skin: honey header, same inbox
    private int ticks;
    private boolean writing;      // the "write a letter" screen
    private String draft = "";
    private String note = "";     // short message after sending
    private int noteT;

    /** Turn this app into BeeMail, the browser version of the same inbox. oy = top of the page area. */
    public MailApp embedded(int oy) { this.oy = oy; this.web = true; return this; }

    /** Height of the area this app can draw in. */
    private int h() { return H - oy; }

    @Override
    public void tick() { ticks++; if (noteT > 0) noteT--; }

    @Override
    public Component title() { return Component.translatable("cutemod.os.mail"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.mail"); }

    private int visibleRows() { return (h() - HEAD) / ROW; }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, h(), web ? 0xFFFFFAE6 : 0xFFF6F0FA);
        rect(g, 0, 0, W, HEAD, web ? 0xFFF5C518 : 0xFF5A4A86);
        if (web) bee(g, (ticks * 2) % (W + 30) - 15, 3 + (int) Math.round(Math.sin(ticks / 5.0) * 2));
        if (writing) composing(g, f, mx, my);
        else if (open == null) list(g, f, mx, my);
        else reading(g, f, mx, my);
    }

    private void list(GuiGraphics g, Font f, int mx, int my) {
        int newCount = Mail.unreadCount();
        g.drawString(f, t(web ? "cutemod.mail.web.inbox" : "cutemod.mail.inbox", newCount), 6, 5, web ? 0xFF5A3A00 : 0xFFFFFFFF, false);
        boolean wHover = in(mx, my, W - 62, 0, 62, HEAD);
        if (wHover) rect(g, W - 62, 0, 62, HEAD, web ? 0xFFFFD866 : 0xFF8A6AC6);
        String wl = "+ " + t("cutemod.mail.write");
        g.drawString(f, wl, W - 31 - f.width(wl) / 2, 5, web ? 0xFF5A3A00 : 0xFFFFFFFF, false);
        List<Mail.Msg> box = Mail.inbox();
        scroll = Math.max(0, Math.min(Math.max(0, box.size() - visibleRows()), scroll));
        for (int i = 0; i < visibleRows() && i + scroll < box.size(); i++) {
            Mail.Msg m = box.get(i + scroll);
            int y = HEAD + i * ROW;
            boolean hover = in(mx, my, 0, y, W, ROW);
            rect(g, 0, y, W, ROW - 1, hover ? 0xFFEBDDF7 : (Mail.unread(m) ? 0xFFFFFFFF : 0xFFF0E8F7));
            disc(g, 13, y + 11, 7, SENDER[m.from()]);
            String init = t("cutemod.mail.from." + m.from()).substring(0, 1);
            g.drawString(f, init, 13 - f.width(init) / 2, y + 7, 0xFFFFFFFF, false);
            boolean unread = Mail.unread(m);
            g.drawString(f, t("cutemod.mail.from." + m.from()), 26, y + 3, unread ? 0xFF3A2A3A : 0xFF8A7AA8, false);
            String subj = f.plainSubstrByWidth(t("cutemod.mail." + m.id() + ".subj"), W - 70);
            g.drawString(f, subj, 26, y + 13, unread ? 0xFF3A2A3A : 0xFF9A8AB8, false);
            if (unread) disc(g, W - 10, y + 11, 3, 0xFFE5484D);
            if (m.reward() > 0 && !Mail.claimed(m)) Progress.drawCoin(g, W - 26, y + 8);
        }
        if (noteT > 0) {
            rect(g, 0, h() - 14, W, 14, 0xFFDFF5E3);
            g.drawString(f, note, 6, h() - 11, 0xFF2E6B3A, false);
        }
        if (box.size() > visibleRows()) {
            int track = h() - HEAD, th = Math.max(8, track * visibleRows() / box.size());
            rect(g, W - 2, HEAD + (track - th) * scroll / (box.size() - visibleRows()), 2, th, 0xFFB57BD6);
        }
    }

    private void composing(GuiGraphics g, Font f, int mx, int my) {
        boolean back = in(mx, my, 0, 0, 50, HEAD);
        if (back) rect(g, 0, 0, 50, HEAD, web ? 0xFFFFD866 : 0xFF8A6AC6);
        g.drawString(f, "< " + t("cutemod.mail.back"), 6, 5, web ? 0xFF5A3A00 : 0xFFFFFFFF, false);
        g.drawString(f, t("cutemod.mail.write.title"), 60, 5, web ? 0xFF5A3A00 : 0xFFE9DDF2, false);
        int y = HEAD + 8;
        List<FormattedCharSequence> help = f.split(FormattedText.of(t("cutemod.mail.write.help")), W - 16);
        for (int i = 0; i < help.size() && i < 4; i++) { g.drawString(f, help.get(i), 8, y, 0xFF3A2A3A, false); y += 9; }
        int by = HEAD + 52;
        rect(g, 7, by - 1, W - 14, 16, 0xFFB57BD6);
        rect(g, 8, by, W - 16, 14, 0xFFFFFFFF);
        String shown = draft;
        while (shown.length() > 1 && f.width(shown) > W - 28) shown = shown.substring(1);
        g.drawString(f, shown, 11, by + 3, 0xFF3A2A3A, false);
        if ((ticks / 30) % 2 == 0) rect(g, 12 + f.width(shown), by + 2, 1, 10, 0xFF3A2A3A);
        int sy = by + 22;
        boolean ok = !draft.isBlank();
        boolean hover = ok && in(mx, my, 8, sy, 80, 16);
        rect(g, 8, sy, 80, 16, !ok ? 0xFFE6DDF0 : (hover ? 0xFFFFD866 : 0xFFFFC832));
        String s = t("cutemod.mail.send");
        g.drawString(f, s, 8 + (80 - f.width(s)) / 2, sy + 4, 0xFF3A2A3A, false);
    }

    private void submit() {
        if (draft.isBlank()) return;
        boolean ok = Mail.send(draft);
        note = t(ok ? "cutemod.mail.sent" : "cutemod.mail.sent.none");
        noteT = 240;
        draft = "";
        writing = false;
    }

    private void reading(GuiGraphics g, Font f, int mx, int my) {
        boolean back = in(mx, my, 0, 0, 50, HEAD);
        if (back) rect(g, 0, 0, 50, HEAD, web ? 0xFFFFD866 : 0xFF8A6AC6);
        g.drawString(f, "< " + t("cutemod.mail.back"), 6, 5, web ? 0xFF5A3A00 : 0xFFFFFFFF, false);
        int y = HEAD + 6;
        disc(g, 14, y + 8, 7, SENDER[open.from()]);
        g.drawString(f, t("cutemod.mail.from." + open.from()), 26, y + 1, 0xFF3A2A3A, false);
        g.drawString(f, t("cutemod.mail." + open.id() + ".subj"), 26, y + 11, 0xFFC04A7A, false);
        rect(g, 6, y + 22, W - 12, 1, 0xFFE9DDF2);
        List<FormattedCharSequence> lines = f.split(FormattedText.of(t("cutemod.mail." + open.id() + ".body")), W - 16);
        int ty = y + 28;
        for (int i = 0; i < lines.size() && i < 8; i++) { g.drawString(f, lines.get(i), 8, ty, 0xFF3A2A3A, false); ty += 9; }
        if (open.reward() > 0) {
            boolean got = Mail.claimed(open);
            int bx = 8, by = h() - 22, bw = 120, bh = 16;
            boolean hover = !got && in(mx, my, bx, by, bw, bh);
            rect(g, bx, by, bw, bh, got ? 0xFFDFF5E3 : (hover ? 0xFFFFD866 : 0xFFFFC832));
            String s = got ? t("cutemod.mail.taken") : t("cutemod.mail.take", open.reward());
            g.drawString(f, s, bx + (bw - f.width(s)) / 2, by + 4, 0xFF3A2A3A, false);
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (writing) {
            if (in(x, y, 0, 0, 50, HEAD)) { writing = false; return true; }
            if (in(x, y, 8, HEAD + 74, 80, 16)) { submit(); return true; }
            return false;
        }
        if (open == null && in(x, y, W - 62, 0, 62, HEAD)) { writing = true; draft = ""; return true; }
        if (open != null) {
            if (in(x, y, 0, 0, 50, HEAD)) { open = null; return true; }
            if (open.reward() > 0 && in(x, y, 8, h() - 22, 120, 16)) { Mail.claim(open); return true; }
            return false;
        }
        List<Mail.Msg> box = Mail.inbox();
        int i = (y - HEAD) / ROW;
        if (y >= HEAD && i < visibleRows() && i + scroll < box.size()) {
            open = box.get(i + scroll);
            Mail.markRead(open);
            Progress.onMail(open.id());
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        if (!writing || c < 32 || c == 127) return false;
        if (draft.length() < 40) draft += c;
        return true;
    }

    @Override
    public boolean scroll(double amount) {
        if (open != null || writing) return false;
        scroll -= (int) Math.signum(amount);
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (writing) {
            if (keyCode == 257 || keyCode == 335) { submit(); return true; }            // enter
            if (keyCode == 256) { writing = false; return true; }                        // escape: back, don't close
            if (keyCode == 259) { if (!draft.isEmpty()) draft = draft.substring(0, draft.length() - 1); return true; }
            return false;
        }
        if (open != null && keyCode == 259) { open = null; return true; } // backspace
        return false;
    }

    /** The same tiny bee that buzzes across the BeeMail ad banner. */
    private static void bee(GuiGraphics g, int bx, int by) {
        rect(g, bx + 1, by, 3, 3, 0xDDFFFFFF);
        rect(g, bx + 7, by, 3, 3, 0xDDFFFFFF);
        rect(g, bx, by + 3, 10, 6, 0xFF8A5A00);
        rect(g, bx + 3, by + 3, 1, 6, 0xFF2A2A2A);
        rect(g, bx + 6, by + 3, 1, 6, 0xFF2A2A2A);
        rect(g, bx + 8, by + 4, 1, 1, 0xFF2A2A2A);
    }
}
