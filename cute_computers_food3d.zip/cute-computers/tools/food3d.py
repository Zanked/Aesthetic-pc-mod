"""
Builds the 3D (voxel) models of the 8 CuteMarket foods from code, in the cute pixel style of the mod.
Every food is a 16 x 16 x 16 grid of colored 1-unit voxels. The voxels are merged into as few boxes as possible and
written as item models (models/item/<food>.json) that all share ONE palette texture (textures/item/food_palette.png):
each color is a 16x16 pixel square, so the colors never blur together, even far away or when held.

  python3 tools/food3d.py                 writes the models and the palette
  python3 tools/food3d.py --preview F.png writes a picture of all foods (isometric, same look as in the inventory)
"""
import json, math, os, sys

G = {}          # (x, y, z) -> 'rrggbb'

def put(x, y, z, c):
    if 0 <= x < 16 and 0 <= y < 16 and 0 <= z < 16: G[(x, y, z)] = c

def disc(cx, cz, r, y0, y1, color):
    """A filled disc of voxels from layer y0 to y1 (exclusive). color = 'rrggbb' or a function f(x, y, z)."""
    for y in range(y0, y1):
        for x in range(16):
            for z in range(16):
                if (x + .5 - cx) ** 2 + (z + .5 - cz) ** 2 <= r * r:
                    put(x, y, z, color(x, y, z) if callable(color) else color)

def box(x0, y0, z0, x1, y1, z1, color):
    """Voxels x0..x1, y0..y1, z0..z1 (all inclusive)."""
    for x in range(x0, x1 + 1):
        for y in range(y0, y1 + 1):
            for z in range(z0, z1 + 1):
                put(x, y, z, color(x, y, z) if callable(color) else color)

def ang(x, z, n):          # which of n slices around the middle this voxel is in
    return int((math.atan2(z + .5 - 8, x + .5 - 8) + math.pi) / (2 * math.pi) * n) % n

def top_exposed(y0, y1):
    return [(x, y, z) for (x, y, z) in list(G) if y0 <= y <= y1 and (x, y + 1, z) not in G]

# ---------------------------------------------------------------- the foods
def cupcake():
    for y in range(5):                                      # the paper cup, with pleats
        disc(8, 8, 3.0 + y * .5, y, y + 1, lambda x, y, z: 'f58fb8' if ang(x, z, 14) % 2 else 'ffb3d1')
    disc(8, 8, 5.0, 5, 6, '8a5a3a')                          # the cake
    disc(8, 8, 5.2, 6, 8, 'ffe0ef'); disc(8, 8, 3.8, 8, 10, 'ffc2dd')   # the frosting swirl
    disc(8, 8, 2.6, 10, 12, 'ffe0ef'); disc(8, 8, 1.5, 12, 13, 'ffc2dd')
    disc(8, 8, 1.4, 13, 15, 'e53935'); put(7, 14, 7, 'ff8a80'); put(9, 15, 8, '5a3a24')   # cherry + stem
    for (x, z, c) in [(3, 8, 'ffd84a'), (12, 7, '6fb7e8'), (8, 12, '66bb6a'), (7, 3, 'ffffff')]: put(x, 7, z, c)

def icecream():
    for y in range(7):                                       # the waffle cone, tip down
        disc(8, 8, 0.8 + y * .4, y, y + 1, lambda x, y, z: 'e0a458' if ((x + y) // 2 + (z + y) // 2) % 2 else 'c78a3c')
    disc(8, 8, 3.6, 7, 9, 'b87a34')                          # the rim of the cone
    disc(8, 8, 4.6, 9, 10, 'ff8fb8'); disc(8, 8, 4.8, 10, 12, 'ffb3d1'); disc(8, 8, 4.2, 12, 13, 'ffb3d1')
    disc(8, 8, 3.0, 13, 14, 'ffc2dd'); disc(8, 8, 1.8, 14, 15, 'ffc2dd')
    disc(8, 8, 0.9, 15, 16, 'e53935')

def bubbletea():
    disc(8, 8, 4.2, 0, 2, lambda x, y, z: '3a2a30' if (x * 3 + z * 5 + y) % 3 == 0 else 'a8764a')   # tapioca pearls
    disc(8, 8, 4.2, 2, 6, 'b07a50'); disc(8, 8, 4.2, 6, 9, 'd8b088')                                 # milk tea
    disc(8, 8, 4.2, 9, 10, 'fff3e6')                                                                 # foam
    disc(8, 8, 4.6, 10, 11, 'ffffff'); disc(8, 8, 4.6, 11, 12, 'e8f4ff')                             # the lid
    for y in range(9, 16): put(9, y, 7, 'ff6b9a' if y % 2 else 'ffffff')                             # the straw

def toast():
    box(3, 0, 3, 12, 4, 12, lambda x, y, z: 'c78a3c' if x in (3, 12) or z in (3, 12) or y == 0 else 'f0c070')   # the bread
    box(3, 5, 3, 12, 5, 12, 'f0c070')
    box(4, 5, 4, 11, 5, 11, 'ffc832')                                                                # honey on top
    for (x, z) in [(5, 6), (8, 9)]: put(x, 5, z, 'fff3a0')
    for (x, y, z) in [(2, 4, 5), (2, 3, 5), (13, 4, 8), (13, 3, 8), (13, 2, 8), (6, 4, 2), (6, 3, 2), (9, 4, 13)]: put(x, y, z, 'ffc832')   # drips
    disc(8, 8, 2.6, 6, 7, 'fff6e8'); disc(8, 8, 3.0, 7, 8, 'fff6e8'); disc(8, 8, 2.8, 8, 9, 'ffffff')  # a scoop of ice cream
    for (x, y, z) in [(7, 9, 7), (8, 9, 7), (8, 10, 8)]: put(x, y, z, '66bb6a')                       # a mint leaf

def burger():
    disc(8, 8, 5.3, 0, 2, 'd9a05a')                                                                  # bottom bun
    disc(8, 8, 6.0, 2, 3, lambda x, y, z: '7fd068' if ang(x, z, 12) % 2 else '66bb6a')             # lettuce
    box(4, 3, 4, 11, 3, 11, 'ffd84a')                                                                # cheese
    for (x, y, z) in [(4, 2, 4), (11, 2, 11), (11, 2, 4)]: put(x, y, z, 'ffd84a')
    disc(8, 8, 5.6, 4, 6, '7a4a2a')                                                                  # patty
    disc(8, 8, 5.2, 6, 7, 'e53935')                                                                  # tomato
    disc(8, 8, 5.8, 7, 8, lambda x, y, z: '66bb6a' if ang(x, z, 10) % 2 else '7fd068')
    disc(8, 8, 5.6, 8, 10, 'e0a458'); disc(8, 8, 5.0, 10, 11, 'e0a458')                             # top bun, a dome
    disc(8, 8, 4.0, 11, 12, 'e0a458'); disc(8, 8, 2.5, 12, 13, 'e0a458')
    for (x, y, z) in top_exposed(10, 12):
        if (x * 7 + z * 13 + y * 5) % 9 == 0: G[(x, y, z)] = 'fff3e0'                                # sesame seeds

def pizza():
    for z in range(2, 14):                                    # one slice lying flat, the tip at z = 13
        hw = 6 - (z - 2) * .5
        for x in range(16):
            if abs(x + .5 - 8) <= hw:
                for y in range(3 if z <= 3 else 1):
                    put(x, y, z, 'e0a458' if z <= 3 else 'f0c070')
                if z > 3: put(x, 1, z, 'ffd84a')
    for (cx, cz) in [(6.5, 5.5), (10, 6), (8.5, 9), (8, 12)]:                                         # pepperoni
        for dx in (0, 1):
            for dz in (0, 1): put(int(cx) + dx - 1 + 1, 2, int(cz) + dz - 1 + 1, 'e53935') if (int(cx) + dx, int(cz) + dz) in [(k[0], k[2]) for k in G if k[1] == 1] else None
    for (x, z) in [(8, 7), (6, 9), (10, 10), (7, 11)]: put(x, 2, z, '66bb6a')                          # basil

def ramen():
    disc(8, 8, 2.8, 0, 1, 'c9b8d8'); disc(8, 8, 4.0, 1, 2, 'f4f0ff'); disc(8, 8, 5.0, 2, 3, 'f4f0ff')
    disc(8, 8, 5.6, 3, 4, lambda x, y, z: 'f58fb8' if ang(x, z, 12) % 2 else 'f4f0ff')               # the bowl with a pattern
    disc(8, 8, 6.0, 4, 5, 'f4f0ff')
    disc(8, 8, 6.2, 5, 6, 'f4f0ff'); disc(8, 8, 5.2, 5, 6, 'e8a040')                                 # the rim and the broth
    for x in range(16):                                                                              # the noodles
        for z in range(16):
            if (x + .5 - 8) ** 2 + (z + .5 - 8) ** 2 <= 4.8 ** 2 and ((x + z) % 3 == 0 or (x - z) % 4 == 0): put(x, 6, z, 'ffe08a')
    disc(6, 6, 1.8, 6, 7, 'ffffff'); disc(6, 6, 0.9, 7, 8, 'ffc832')                                 # a boiled egg
    box(10, 6, 5, 10, 9, 8, '1f4d2b')                                                                # a piece of nori
    for (x, z) in [(8, 10), (9, 9), (7, 9), (10, 10)]: put(x, 7, z, 'a5d66f')                         # spring onion
    for z in range(1, 15): put(12, 6, z, 'c78a3c'); put(13, 6, z, 'd9a05a')                           # chopsticks

def sushi():
    box(3, 0, 5, 12, 3, 10, lambda x, y, z: 'e8e4f0' if (x + z + y) % 5 == 0 else 'ffffff')           # the rice
    box(2, 4, 4, 13, 5, 11, lambda x, y, z: 'ffd0c0' if x % 3 == 0 and y == 5 else 'ff8a65')          # the salmon
    box(2, 3, 4, 13, 3, 4, 'ff8a65'); box(2, 3, 11, 13, 3, 11, 'ff8a65')                              # draping over the rice
    box(7, 0, 4, 8, 6, 11, '1f4d2b')                                                                 # the nori band
    for (x, z) in [(11, 7), (11, 8), (10, 7)]: put(x, 6, z, 'a5d66f')                                 # a little wasabi

FOODS = [('cupcake', cupcake), ('icecream', icecream), ('bubbletea', bubbletea), ('toast', toast),
         ('burger', burger), ('pizza', pizza), ('ramen', ramen), ('sushi', sushi)]

def build(fn):
    G.clear(); fn(); return dict(G)

# ---------------------------------------------------------------- boxes and models
def merge(vox):
    """Greedy: join voxels of one color into as few boxes as possible. Returns [(x0,y0,z0,x1,y1,z1,color)] (end exclusive)."""
    rects = {}                                       # y -> [(x0, z0, x1, z1, color)]
    for y in sorted({k[1] for k in vox}):
        layer = {(x, z): c for (x, yy, z), c in vox.items() if yy == y}
        used = set(); out = []
        for z in range(16):
            for x in range(16):
                if (x, z) not in layer or (x, z) in used: continue
                c = layer[(x, z)]; x1 = x
                while (x1 + 1, z) in layer and layer[(x1 + 1, z)] == c and (x1 + 1, z) not in used: x1 += 1
                z1 = z
                while all((xx, z1 + 1) in layer and layer[(xx, z1 + 1)] == c and (xx, z1 + 1) not in used for xx in range(x, x1 + 1)): z1 += 1
                for xx in range(x, x1 + 1):
                    for zz in range(z, z1 + 1): used.add((xx, zz))
                out.append((x, z, x1 + 1, z1 + 1, c))
        rects[y] = out
    boxes = []; open_ = {}
    for y in sorted(rects):
        now = {}
        for r in rects[y]:
            if r in open_.get(y - 1, {}): now[r] = open_[y - 1][r]
            else: now[r] = y
        for r, y0 in now.items():
            nxt = rects.get(y + 1, [])
            if r not in nxt: boxes.append((r[0], y0, r[1], r[2], y + 1, r[3], r[4]))
        open_[y] = now
    return boxes

FACES = {'north': (0, 0, -1), 'south': (0, 0, 1), 'west': (-1, 0, 0), 'east': (1, 0, 0), 'down': (0, -1, 0), 'up': (0, 1, 0)}

def covered(vox, b, face):
    x0, y0, z0, x1, y1, z1 = b[:6]; dx, dy, dz = FACES[face]
    cells = []
    if dx: cells = [(x0 - 1 if dx < 0 else x1, y, z) for y in range(y0, y1) for z in range(z0, z1)]
    if dy: cells = [(x, y0 - 1 if dy < 0 else y1, z) for x in range(x0, x1) for z in range(z0, z1)]
    if dz: cells = [(x, y, z0 - 1 if dz < 0 else z1) for x in range(x0, x1) for y in range(y0, y1)]
    return all(c in vox for c in cells)

DISPLAY = {   # how the food is shown: in the inventory (a little turned, like a block), in the hand, on the ground, in a frame
    'gui': {'rotation': [30, 225, 0], 'translation': [0, -0.5, 0], 'scale': [0.66, 0.66, 0.66]},
    'ground': {'rotation': [0, 0, 0], 'translation': [0, 2, 0], 'scale': [0.28, 0.28, 0.28]},
    'fixed': {'rotation': [0, 0, 0], 'translation': [0, 0, 0], 'scale': [0.5, 0.5, 0.5]},
    'thirdperson_righthand': {'rotation': [75, 45, 0], 'translation': [0, 2.5, 0], 'scale': [0.34, 0.34, 0.34]},
    'thirdperson_lefthand': {'rotation': [75, 45, 0], 'translation': [0, 2.5, 0], 'scale': [0.34, 0.34, 0.34]},
    'firstperson_righthand': {'rotation': [0, 45, 0], 'translation': [0, 2, 0], 'scale': [0.4, 0.4, 0.4]},
    'firstperson_lefthand': {'rotation': [0, 225, 0], 'translation': [0, 2, 0], 'scale': [0.4, 0.4, 0.4]},
    'head': {'rotation': [0, 0, 0], 'translation': [0, 14, 0], 'scale': [0.9, 0.9, 0.9]},
}

def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    foods = {name: build(fn) for name, fn in FOODS}
    palette = []
    for vox in foods.values():
        for c in vox.values():
            if c not in palette: palette.append(c)
    assert len(palette) <= 256, len(palette)
    idx = {c: i for i, c in enumerate(palette)}
    uv = lambda c: [idx[c] % 16 + .25, idx[c] // 16 + .25, idx[c] % 16 + .75, idx[c] // 16 + .75]

    from PIL import Image
    tex = Image.new('RGBA', (256, 256), (0, 0, 0, 0))
    for c, i in idx.items():            # each color fills a 16 x 16 pixel square: no blur between colors at any distance
        rgb = tuple(int(c[k:k + 2], 16) for k in (0, 2, 4)) + (255,)
        for y in range(16):
            for x in range(16): tex.putpixel((i % 16 * 16 + x, i // 16 * 16 + y), rgb)
    tp = os.path.join(root, 'src/main/resources/assets/cutemod/textures/item/food_palette.png'); tex.save(tp)

    mp = os.path.join(root, 'src/main/resources/assets/cutemod/models/item')
    total = 0
    for name, vox in foods.items():
        els = []
        for b in merge(vox):
            faces = {f: {'uv': uv(b[6]), 'texture': '#p'} for f in FACES if not covered(vox, b, f)}
            els.append({'from': list(b[:3]), 'to': list(b[3:6]), 'faces': faces})
        total += len(els)
        model = {'gui_light': 'side', 'textures': {'p': 'cutemod:item/food_palette', 'particle': 'cutemod:item/food_palette'},
                 'elements': els, 'display': DISPLAY}
        json.dump(model, open(os.path.join(mp, name + '.json'), 'w'), separators=(',', ':'))
    for name in [n for n, _ in FOODS]:          # the old flat pictures are not used any more
        old = os.path.join(root, 'src/main/resources/assets/cutemod/textures/item', name + '.png')
        if os.path.exists(old): os.remove(old)
    print('foods: %d, colors: %d, boxes: %d' % (len(foods), len(palette), total))
    return foods

def preview(path, foods):
    from PIL import Image, ImageDraw
    S = 11; c30, s30 = math.cos(math.radians(30)), math.sin(math.radians(30))
    W, H = int(32 * c30 * S) + 30, int(32 * S) + 30
    sheet = Image.new('RGB', (4 * W, 2 * H), (255, 238, 246)); d = ImageDraw.Draw(sheet)
    def shade(c, f): return tuple(int(int(c[k:k + 2], 16) * f) for k in (0, 2, 4))
    for n, (name, vox) in enumerate(foods.items()):
        ox, oy = (n % 4) * W + W // 2, (n // 4) * H + 16 * S + 10
        for (x, y, z) in sorted(vox, key=lambda k: (k[0] + k[2], k[1])):
            c = vox[(x, y, z)]
            def P(px, py, pz): return (ox + (px - pz) * c30 * S, oy + (px + pz) * s30 * S - py * S)
            if (x, y + 1, z) not in vox: d.polygon([P(x, y + 1, z), P(x + 1, y + 1, z), P(x + 1, y + 1, z + 1), P(x, y + 1, z + 1)], fill=shade(c, 1.0))
            if (x, y, z + 1) not in vox: d.polygon([P(x, y, z + 1), P(x + 1, y, z + 1), P(x + 1, y + 1, z + 1), P(x, y + 1, z + 1)], fill=shade(c, 0.8))
            if (x + 1, y, z) not in vox: d.polygon([P(x + 1, y, z), P(x + 1, y, z + 1), P(x + 1, y + 1, z + 1), P(x + 1, y + 1, z)], fill=shade(c, 0.62))
    sheet.save(path)

if __name__ == '__main__':
    f = main()
    if len(sys.argv) > 2 and sys.argv[1] == '--preview': preview(sys.argv[2], f)
