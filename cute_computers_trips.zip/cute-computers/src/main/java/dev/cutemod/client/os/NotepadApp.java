package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Plain text notes, saved to cutemod_notes.txt in the game folder. */
public class NotepadApp extends App {
    private static final int MAX = 4000;
    private static final int TX = 8, TY = 8, TW = W - 22, ROW = 9, ROWS = (H - 14) / ROW;

    private String text = "";
    private int cur = 0, scrollRow = 0, ticks = 0, idle = 0;
    private boolean dirty = false;
    private final List<int[]> vlines = new ArrayList<>();
    private final java.util.Random ghostRnd = new java.util.Random();
    private int ghostDelay, ghostAge = -1, ghostMsg; // a line that "writes itself" (display only, not saved)

    public NotepadApp() {
        load();
        cur = text.length();
        layout();
        keepCaretVisible();
        rollGhost();
    }

    private void rollGhost() {
        ghostAge = -1;
        ghostDelay = (Haunt.scary && ghostRnd.nextInt(3) == 0) ? 300 + ghostRnd.nextInt(900) : 0;
        ghostMsg = ghostRnd.nextInt(4);
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.notes"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.notes"); }

    // ---------- file ----------
    private void load() {
        try {
            String s = Store.read("notes");
            if (s != null) {
                text = s.replace("\r", "");
                if (text.length() > MAX) text = text.substring(0, MAX);
            }
        } catch (Exception ignored) {
        }
    }

    private void save() {
        if (!dirty) return;
        try {
            Store.write("notes", text);
            dirty = false;
        } catch (Exception ignored) {
        }
    }

    @Override
    public void close() { save(); rollGhost(); }

    // ---------- layout ----------
    private void layout() {
        Font f = font();
        vlines.clear();
        int start = 0, i = 0, len = text.length();
        while (true) {
            if (i >= len) { vlines.add(new int[]{start, len}); break; }
            if (text.charAt(i) == '\n') { vlines.add(new int[]{start, i}); start = i + 1; i++; continue; }
            if (i > start && f.width(text.substring(start, i + 1)) > TW) { vlines.add(new int[]{start, i}); start = i; continue; }
            i++;
        }
    }

    private int caretLine() {
        int found = 0;
        for (int l = 0; l < vlines.size(); l++) if (vlines.get(l)[0] <= cur) found = l;
        return found;
    }

    private void keepCaretVisible() {
        int l = caretLine();
        if (l < scrollRow) scrollRow = l;
        if (l >= scrollRow + ROWS) scrollRow = l - ROWS + 1;
        scrollRow = Math.max(0, Math.min(scrollRow, Math.max(0, vlines.size() - ROWS)));
    }

    private void changed() {
        Progress.onNote(text.length()); // story, part 2
        dirty = true;
        idle = 0;
        layout();
        keepCaretVisible();
    }

    // ---------- render ----------
    @Override
    public void tick() {
        ticks++;
        if (dirty && ++idle > 300) save(); // autosave ~5 s after the last change
        if (ghostDelay > 0 && --ghostDelay == 0) ghostAge = 0;
        else if (ghostAge >= 0 && ++ghostAge > 900) ghostAge = -1; // it disappears after ~15 s
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, 0xFFFFFAFD);
        rect(g, 4, 4, W - 8, H - 8, 0xFFFFFFFF);
        rect(g, 4, 4, W - 8, 1, 0xFFF58FB8);
        for (int r = 0; r < ROWS; r++) {
            int l = scrollRow + r;
            if (l >= vlines.size()) break;
            int[] v = vlines.get(l);
            int y = TY + 2 + r * ROW;
            g.drawString(f, text.substring(v[0], v[1]), TX, y, 0xFF3A2A3A, false);
        }
        if (ghostAge >= 0 && Haunt.scary) {
            String gs = t("cutemod.haunt.note." + ghostMsg);
            gs = gs.substring(0, Math.min(gs.length(), ghostAge / 6)); // types itself
            int row = vlines.size() - scrollRow;
            if (row >= 0 && row < ROWS && !gs.isEmpty()) g.drawString(f, gs, TX, TY + 2 + row * ROW, 0xFFB3202A, false);
        }
        if ((ticks / 30) % 2 == 0) {
            int l = caretLine();
            if (l >= scrollRow && l < scrollRow + ROWS) {
                int[] v = vlines.get(l);
                int end = Math.max(v[0], Math.min(cur, v[1]));
                int x = TX + f.width(text.substring(v[0], end));
                rect(g, x, TY + 1 + (l - scrollRow) * ROW, 1, 10, 0xFF3A2A3A);
            }
        }
        if (vlines.size() > ROWS) {
            int th = Math.max(12, (H - 12) * ROWS / vlines.size());
            int ty = 6 + (H - 12 - th) * scrollRow / (vlines.size() - ROWS);
            rect(g, W - 8, 6, 2, H - 12, 0xFFE9DDF2);
            rect(g, W - 8, ty, 2, th, 0xFFB57BD6);
        }
    }

    // ---------- input ----------
    @Override
    public boolean key(int k, int mods) {
        switch (k) {
            case 257, 335 -> insert("\n");
            case 259 -> { // backspace
                if (cur > 0) { text = text.substring(0, cur - 1) + text.substring(cur); cur--; changed(); }
            }
            case 261 -> { // delete
                if (cur < text.length()) { text = text.substring(0, cur) + text.substring(cur + 1); changed(); }
            }
            case 263 -> { cur = Math.max(0, cur - 1); keepCaretVisible(); }
            case 262 -> { cur = Math.min(text.length(), cur + 1); keepCaretVisible(); }
            case 265 -> moveVertical(-1);
            case 264 -> moveVertical(1);
            case 268 -> { cur = vlines.get(caretLine())[0]; keepCaretVisible(); }
            case 269 -> { cur = vlines.get(caretLine())[1]; keepCaretVisible(); }
            case 86 -> {
                if (!Screen.hasControlDown()) return false;
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) insert(clip.replace("\r", ""));
            }
            case 83 -> { // ctrl+s
                if (!Screen.hasControlDown()) return false;
                save();
            }
            default -> { return false; }
        }
        return true;
    }

    private void moveVertical(int dir) {
        int l = caretLine();
        int target = l + dir;
        if (target < 0 || target >= vlines.size()) return;
        int[] from = vlines.get(l), to = vlines.get(target);
        int col = cur - from[0];
        cur = Math.min(to[0] + col, to[1]);
        keepCaretVisible();
    }

    private void insert(String s) {
        if (text.length() + s.length() > MAX) return;
        text = text.substring(0, cur) + s + text.substring(cur);
        cur += s.length();
        changed();
    }

    @Override
    public boolean charTyped(char c) {
        if (c < 32 || c == 127) return false;
        insert(String.valueOf(c));
        return true;
    }

    @Override
    public boolean click(int x, int y, int button) {
        int row = (y - TY - 2) / ROW + scrollRow;
        if (row < 0 || row >= vlines.size()) { cur = text.length(); keepCaretVisible(); return true; }
        int[] v = vlines.get(Math.max(0, row));
        Font f = font();
        int pos = v[0];
        while (pos < v[1] && TX + f.width(text.substring(v[0], pos + 1)) - (f.width(text.substring(pos, pos + 1)) / 2) <= x) pos++;
        cur = pos;
        keepCaretVisible();
        return true;
    }

    @Override
    public boolean scroll(double amount) {
        scrollRow = Math.max(0, Math.min(Math.max(0, vlines.size() - ROWS), scrollRow - (int) Math.signum(amount) * 2));
        return true;
    }
}
