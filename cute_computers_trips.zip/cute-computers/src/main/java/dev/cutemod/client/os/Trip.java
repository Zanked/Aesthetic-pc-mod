package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;

import java.util.Random;

/**
 * Pet trips: the pet of one computer goes to a place for 10 real minutes (it keeps going while the screen is closed),
 * then comes back with a find and sends a letter with a photo. All state lives in the Progress counters (so it is
 * saved on the server with the rest): trip_dest (1-6, 0 = at home), trip_start (seconds), trip_col (computer color + 1),
 * trip_stage, trip_bonus (the pet is happier when it comes back), tf_D_K (the album) and the letters tr0_ ... tr5_.
 */
public final class Trip {
    private Trip() {}

    public static final int DESTS = 6, FINDS = 4, SECONDS = 600, SLOTS = 6, PAID_TRIPS = 5, ALBUM_BONUS = 100;
    /** Growth stage the pet needs: 0 baby, 1 teen, 2 grown-up. The kindergarten takes everybody. */
    public static final int[] NEED = {0, 1, 1, 1, 2, 2};

    private static int pollTimer;

    private static int now() { return (int) (System.currentTimeMillis() / 1000L); }

    public static boolean active() { return Progress.count("trip_dest") > 0; }

    /** 0-5 (-1 if at home). */
    public static int dest() { return Progress.count("trip_dest") - 1; }

    public static boolean awayFor(ComputerColor c) { return active() && Progress.count("trip_col") == c.ordinal() + 1; }

    public static int secondsLeft() { return Math.max(0, Math.min(SECONDS, SECONDS - (now() - Progress.count("trip_start")))); }

    /** Sends the pet away. False if a pet is already away or the pet is too young for that place. */
    public static boolean start(ComputerColor c, int dest, int stage) {
        if (active() || dest < 0 || dest >= DESTS || stage < NEED[dest]) return false;
        Progress.setCount("trip_dest", dest + 1);
        Progress.setCount("trip_start", now());
        Progress.setCount("trip_col", c.ordinal() + 1);
        Progress.setCount("trip_stage", stage);
        return true;
    }

    public static boolean found(int dest, int k) { return Progress.count("tf_" + dest + "_" + k) > 0; }

    public static int albumCount() {
        int n = 0;
        for (int d = 0; d < DESTS; d++) for (int k = 0; k < FINDS; k++) if (found(d, k)) n++;
        return n;
    }

    /** Called 60 times per second; once a second it looks if the pet is home again. */
    public static void tick() {
        if (++pollTimer < 60) return;
        pollTimer = 0;
        if (active() && secondsLeft() == 0) finish();
    }

    private static void finish() {
        int d = dest(), col = Progress.count("trip_col"), stage = Progress.count("trip_stage"), start = Progress.count("trip_start");
        Random r = new Random(start * 31L + d);
        int roll = r.nextInt(100);
        int k = roll < 40 ? 0 : roll < 70 ? 1 : roll < 90 ? 2 : 3;          // the common finds come more often
        boolean fresh = !found(d, k);
        Progress.setCount("tf_" + d + "_" + k, 1);
        Progress.bump("trips");
        int coins = Progress.dailyCount("trips") <= PAID_TRIPS ? 3 + 2 * d + 4 * k : 0;   // only the first trips of the day pay
        int n = Progress.count("trip_n"), s = n % SLOTS;
        String p = "tr" + s + "_";
        Progress.setCount(p + "dest", d + 1);
        Progress.setCount(p + "find", k + 1);
        Progress.setCount(p + "coins", coins);
        Progress.setCount(p + "new", fresh ? 1 : 0);
        Progress.setCount(p + "col", col);
        Progress.setCount(p + "stage", stage);
        Progress.setCount(p + "seq", n + 1);
        Progress.setCount("trip_n", n + 1);
        Progress.setCount("mr_trip_" + s, 0);          // a new letter: unread, and the player is told about it
        Progress.setCount("mn_trip_" + s, 0);
        Progress.setCount("trip_dest", 0);
        Progress.setCount("trip_bonus", col);          // the pet is happier when the player opens it next
        if (coins > 0) Progress.earn(coins);
        Progress.toast("cutemod.trip.back");
        if (fresh && albumCount() == DESTS * FINDS) {
            Progress.earn(ALBUM_BONUS);
            Progress.toast("cutemod.trip.album_full");
        }
    }
}
