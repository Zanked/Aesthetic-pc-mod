package dev.cutemod.client.game;

import dev.cutemod.ComputerColor;

public class GameFactory {
    public static MiniGame create(ComputerColor color) {
        return switch (color) {
            case PINK -> new FlappyCat();
            case GREEN -> new Minesweeper();
            case WHITE -> new PandaSnake();
            case BLUE -> new PenguinFishing();
            case ORANGE -> new FoxMemory();
            case PURPLE -> new EnderDodge();
            case YELLOW -> new WhackBee();
            case RED -> new LadybugMatch();
        };
    }

    /** Games that are not tied to a computer color (only playable from the Games folder). */
    public static MiniGame createExtra(String id) {
        return switch (id) {
            case "breakout" -> new CookieBreaker();
            case "pong" -> new SlimePong();
            case "bees" -> new BeeInvaders();
            case "horror" -> new DarkCandles();
            case "maze" -> new DarkCorridor();
            case "craft" -> new MiniCraft();
            case "zombies" -> new ZombieShooter();
            case "durak" -> new Durak();
            case "sakura" -> new SakuraCatch();
            case "blocks" -> new CuteBlocks();
            case "cakes" -> new CakeBakery();
            case "cakefactory" -> new CakeFactory();
            default -> new MergeCubes();
        };
    }

    private GameFactory() {}
}
