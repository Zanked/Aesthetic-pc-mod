package dev.cutemod.client.os;

import dev.cutemod.CuteMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

/**
 * The music of the mini games: every game has its own short loop (assets/cutemod/sounds/music/&lt;game id&gt;.ogg,
 * made by tools/make_music.py). The music plays while a game is on screen, fades in and out, gets quieter on
 * "Game over" and pauses the vanilla music meanwhile. It follows the "Music" volume slider of Minecraft and the
 * "Music" switch in the computer's Settings.
 *
 * GameApp calls {@link #keep} on every tick. If the calls stop (the game is minimized, closed or the computer is
 * left) the track fades out by itself, so nothing else has to be tracked.
 */
public final class GameMusic {
    private GameMusic() {}

    private static final float LEVEL = 0.8F;      // while playing
    private static final float OVER_LEVEL = 0.25F; // on the "Game over" box

    private static Track current;

    /** The game with this id is running right now: start (or keep) its music. */
    public static void keep(String id, boolean over) {
        if (!Sfx.music() || Sfx.musicVol() <= 0F) { stop(); return; }
        if (current != null && current.isStopped()) current = null;
        if (current != null && !current.id.equals(id)) { current.fadeOut(); current = null; }
        if (current == null) {
            current = new Track(id);
            Minecraft mc = Minecraft.getInstance();
            mc.getSoundManager().play(current);
            mc.getMusicManager().stopPlaying();
        }
        current.alive(over);
    }

    /** Fade the music out (the game was closed). */
    public static void stop() {
        if (current != null) current.fadeOut();
        current = null;
    }

    private static final class Track extends AbstractTickableSoundInstance {
        final String id;
        private float goal = LEVEL;
        private float base = LEVEL;
        private int idle;
        private int duck;
        private boolean out;

        Track(String id) {
            super(SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "music." + id)),
                    SoundSource.MUSIC, RandomSource.create());
            this.id = id;
            this.looping = true;                 // not streamed, so OpenAL loops it without a gap
            this.delay = 0;
            this.volume = 0.01F;                 // a sound that starts at exactly 0 is skipped
            this.relative = true;
            this.attenuation = SoundInstance.Attenuation.NONE;
        }

        void alive(boolean over) {
            idle = 0;
            base = over ? OVER_LEVEL : LEVEL;
        }

        void fadeOut() { out = true; }

        @Override
        public void tick() {
            goal = (out || ++idle > 10 || !Sfx.music()) ? 0 : base * Sfx.musicVol();   // the slider in Settings
            float step = goal > volume ? 0.03F : 0.06F;
            volume = volume < goal ? Math.min(goal, volume + step) : Math.max(goal, volume - step);
            if (goal == 0 && volume <= 0.005F) { stop(); return; }
            // keep the vanilla music quiet while a game plays (its timer restarts every time)
            if (volume > 0.05F && duck++ % 60 == 0) Minecraft.getInstance().getMusicManager().stopPlaying();
        }
    }
}
