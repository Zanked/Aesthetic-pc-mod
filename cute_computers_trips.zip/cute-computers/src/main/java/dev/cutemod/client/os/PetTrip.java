package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

import static dev.cutemod.client.os.App.rect;

/** The trips screen of the Tamagotchi app: pick a place to send the pet to, and the album of the things it found. */
final class PetTrip {
    private static final int W = App.W, H = App.H, HEAD = 17, ROW = 24;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;

    private final Runnable back;
    private final IntConsumer go;
    private final Supplier<String> blocker;       // "" if the pet can leave, else the reason (a lang key)
    private final IntSupplier stage;
    private int tab, ticks;

    PetTrip(Runnable back, IntConsumer go, Supplier<String> blocker, IntSupplier stage) {
        this.back = back;
        this.go = go;
        this.blocker = blocker;
        this.stage = stage;
    }

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    void tick() { ticks++; }

    private boolean ready(int d) { return stage.getAsInt() >= Trip.NEED[d] && blocker.get().isEmpty(); }

    void render(GuiGraphics g, int mx, int my) {
        Font f = net.minecraft.client.Minecraft.getInstance().font;
        rect(g, 0, 0, W, H, 0xFFF6F0FA);
        rect(g, 0, 0, W, HEAD, 0xFF5A4A86);
        boolean bh = App.in(mx, my, 3, 3, 44, 12);
        rect(g, 3, 3, 44, 12, bh ? 0xFFFFFFFF : 0xE0F6F0FA);
        g.drawString(f, "< " + t("cutemod.trip.back_btn"), 7, 5, TEXT, false);
        tabBtn(g, f, mx, my, 54, 56, "cutemod.trip.tab.go", tab == 0);
        tabBtn(g, f, mx, my, 114, 62, "cutemod.trip.tab.album", tab == 1);
        if (tab == 1) {
            String n = Trip.albumCount() + "/" + Trip.DESTS * Trip.FINDS;
            g.drawString(f, n, W - 6 - f.width(n), 5, 0xFFE4D8FF, false);
        } else {
            String why = blocker.get();
            if (!why.isEmpty()) g.drawString(f, f.plainSubstrByWidth(t(why), W - 190), 184, 5, 0xFFFFD0D0, false);
        }
        for (int d = 0; d < Trip.DESTS; d++) {
            int y = HEAD + 1 + d * ROW;
            rect(g, 3, y, W - 6, ROW - 1, 0xFFFFFFFF);
            TripArt.scene(g, 6, y + 2, 28, 19, d, ticks);
            g.drawString(f, t("cutemod.trip.dest." + d), 40, y + 3, TEXT, false);
            if (tab == 0) goRow(g, f, mx, my, d, y); else albumRow(g, f, d, y);
        }
    }

    private void goRow(GuiGraphics g, Font f, int mx, int my, int d, int y) {
        boolean young = stage.getAsInt() < Trip.NEED[d];
        String sub = young ? t("cutemod.trip.needs." + Trip.NEED[d]) : t("cutemod.trip.takes");
        g.drawString(f, sub, 40, y + 13, young ? 0xFFD9302A : MUTED, false);
        boolean ok = ready(d), hov = ok && App.in(mx, my, W - 66, y + 4, 60, 15);
        rect(g, W - 66, y + 4, 60, 15, !ok ? 0xFFD8CCE2 : hov ? 0xFFFFD866 : 0xFFFFC832);
        String s = t("cutemod.trip.go");
        g.drawString(f, s, W - 36 - f.width(s) / 2, y + 8, ok ? TEXT : 0xFFFFFFFF, false);
    }

    private void albumRow(GuiGraphics g, Font f, int d, int y) {
        for (int k = 0; k < Trip.FINDS; k++) {
            int x = 40 + k * 64;
            boolean got = Trip.found(d, k);
            rect(g, x, y + 12, 62, 10, got ? 0xFFE4F5E8 : 0xFFEFE8F5);
            String s = got ? f.plainSubstrByWidth(t("cutemod.trip.find." + d + "." + k), 58) : "?";
            g.drawString(f, s, x + 2, y + 13, got ? 0xFF2E6B3A : 0xFFB8A8D8, false);
        }
    }

    private void tabBtn(GuiGraphics g, Font f, int mx, int my, int x, int w, String key, boolean on) {
        boolean hov = App.in(mx, my, x, 2, w, 13);
        rect(g, x, 2, w, 13, on ? 0xFFF6F0FA : hov ? 0xFF8A6AC6 : 0xFF6E5CA0);
        String s = t(key);
        g.drawString(f, s, x + (w - f.width(s)) / 2, 5, on ? TEXT : 0xFFFFFFFF, false);
    }

    boolean click(int mx, int my) {
        if (App.in(mx, my, 3, 3, 44, 12)) { back.run(); return true; }
        if (App.in(mx, my, 54, 2, 56, 13)) { tab = 0; return true; }
        if (App.in(mx, my, 114, 2, 62, 13)) { tab = 1; return true; }
        if (tab == 0) {
            for (int d = 0; d < Trip.DESTS; d++) {
                if (App.in(mx, my, W - 66, HEAD + 1 + d * ROW + 4, 60, 15) && ready(d)) { go.accept(d); return true; }
            }
        }
        return true;
    }

    boolean key(int keyCode) {
        if (keyCode == 256) { back.run(); return true; }
        return false;
    }
}
