package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Pictures and tiny looping animations for Pandapedia, drawn with rectangles (no image files).
 * Every picture is W x H GUI pixels; t = browser ticks (60 per second).
 */
public final class WikiArt {
    public static final int W = 280, H = 60;
    private static final int GROUND = 52;

    private static GuiGraphics g;
    private static int ox, oy;

    private WikiArt() {}

    // ---------- helpers (local to the picture) ----------
    private static void r(int x, int y, int w, int h, int argb) {
        g.fill(ox + x, oy + y, ox + x + w, oy + y + h, argb);
    }

    private static void d(int cx, int cy, int rad, int argb) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            g.fill(ox + cx - dx, oy + cy + dy, ox + cx + dx + 1, oy + cy + dy + 1, argb);
        }
    }

    private static void bg(int top, int bottom) {
        g.fillGradient(ox, oy, ox + W, oy + H, top, bottom);
    }

    private static void heart(int x, int y, int argb) {
        r(x + 1, y, 2, 1, argb); r(x + 4, y, 2, 1, argb);
        r(x, y + 1, 7, 2, argb);
        r(x + 1, y + 3, 5, 1, argb);
        r(x + 2, y + 4, 3, 1, argb);
        r(x + 3, y + 5, 1, 1, argb);
    }

    public static void draw(GuiGraphics gg, String name, int x, int y, int t) {
        g = gg;
        ox = x;
        oy = y;
        switch (name) {
            case "panda" -> panda(t);
            case "fox" -> fox(t);
            case "creeper" -> creeper(t);
            case "bee" -> bee(t);
            case "ladybug" -> ladybug(t);
            case "penguin" -> penguin(t);
            case "bamboo" -> bamboo(t);
            case "slime" -> slime(t);
            case "me" -> me(t);
            case "window" -> window(t);
            default -> bg(0xFFE9DDF2, 0xFFD8CCE2);
        }
        int frame = 0xFFC9B8D8; // thin frame so the picture looks like a picture
        r(0, 0, W, 1, frame); r(0, H - 1, W, 1, frame);
        r(0, 0, 1, H, frame); r(W - 1, 0, 1, H, frame);
        g = null;
    }

    // ---------- panda chewing bamboo ----------
    private static void panda(int t) {
        bg(0xFFDFF5D8, 0xFFB8E3B0);
        r(0, GROUND, W, H - GROUND, 0xFF8FCB84);
        for (int s = 0; s < 4; s++) { // bamboo grove on both sides
            int bx = s < 2 ? 22 + s * 16 : 234 + (s - 2) * 16;
            r(bx, 0, 5, GROUND, 0xFF6FBF5A);
            for (int ny = 8; ny < GROUND; ny += 14) r(bx - 1, ny + s * 3 % 7, 7, 2, 0xFF4E9F3E);
            r(bx + 5, 6 + s * 5, 6, 2, 0xFF7FD068);
            r(bx - 6, 20 + s * 4, 6, 2, 0xFF7FD068);
        }
        int open = (t / 8) % 2;
        int cx = 140;
        int bob = (int) Math.round(Math.sin(t / 8.0));
        d(cx - 13, 54, 6, 0xFF25252D); d(cx + 13, 54, 6, 0xFF25252D); // feet
        d(cx, 40, 15, 0xFFFFFFFF);                                       // belly
        int hy = 21 + open;
        d(cx - 11, hy - 10, 5, 0xFF25252D); d(cx + 11, hy - 10, 5, 0xFF25252D); // ears
        d(cx, hy, 13, 0xFFFFFFFF);                                       // head
        d(cx - 6, hy, 4, 0xFF25252D); d(cx + 6, hy, 4, 0xFF25252D);     // eye patches
        r(cx - 7, hy - 1, 2, 2, 0xFFFFFFFF); r(cx + 5, hy - 1, 2, 2, 0xFFFFFFFF);
        r(cx - 2, hy + 4, 5, 3, 0xFF25252D);                             // nose
        if (open == 1) r(cx - 2, hy + 8, 5, 3, 0xFFE06A8A); else r(cx - 1, hy + 8, 3, 1, 0xFF25252D);
        int by = 36 + bob;                                               // bamboo piece in the paws
        r(cx - 14, by, 28, 4, 0xFF6FBF5A);
        r(cx - 4, by - 1, 2, 6, 0xFF4E9F3E); r(cx + 6, by - 1, 2, 6, 0xFF4E9F3E);
        d(cx - 13, by + 2, 4, 0xFF25252D); d(cx + 13, by + 2, 4, 0xFF25252D);
        int fall = t % 45;                                               // crumbs
        r(cx + 17, 26 + fall / 2, 2, 2, 0xFF6FBF5A);
        r(cx - 19, 30 + (fall + 20) % 45 / 2, 2, 2, 0xFF7FD068);
    }

    // ---------- fox wagging its tail ----------
    private static void fox(int t) {
        bg(0xFFFFE9C9, 0xFFFFD6A0);
        r(0, GROUND, W, H - GROUND, 0xFFE3B778);
        int orange = 0xFFEE7F1C, dark = 0xFF3A2A3A;
        for (int i = 0; i < 6; i++) { // tail first: it waves from side to side
            int tx = 112 - i * 7;
            int ty = 36 - i * 2 + (int) Math.round(Math.sin(t / 9.0 + i * 0.55) * (1 + i));
            r(tx, ty, 9, 9, i == 5 ? 0xFFFFFFFF : orange);
        }
        r(112, 32, 38, 18, orange);
        r(118, 44, 26, 6, 0xFFFFF3E0);
        for (int lx : new int[]{116, 126, 138, 146}) r(lx, 50, 5, 6, 0xFF7A3A10);
        r(148, 20, 22, 18, orange);
        r(168, 28, 10, 8, orange);
        r(168, 33, 10, 3, 0xFFFFFFFF);
        r(177, 28, 3, 3, dark);
        r(160, 25, 3, 3, dark);
        int twitch = (t % 120) < 10 ? 2 : 0; // one ear twitches now and then
        r(150, 12 + twitch, 6, 9, orange); r(152, 14 + twitch, 2, 6, dark);
        r(162, 12, 6, 9, orange); r(164, 14, 2, 6, dark);
    }

    // ---------- creeper that swells... and gets a hug ----------
    private static void creeper(int t) {
        bg(0xFFCFEFC8, 0xFF9ED68F);
        r(0, GROUND, W, H - GROUND, 0xFF7FBF70);
        int c = t % 240;
        boolean happy = c >= 130;
        int s = 28;
        if (c < 120) s += (int) (c / 120.0 * 10) + (int) Math.round(Math.sin(c / 3.0));
        int cx = 140, x = cx - s / 2, y = Math.max(2, 50 - s - 12);
        int skin = 0xFF5BBF4A, shade = 0xFF3F9A37, face = 0xFF16301A;
        if (c < 120 && (c / 10) % 2 == 1 && c > 40) skin = 0xFFD9F5CF; // nervous blinking
        r(cx - s / 3, y + s, s * 2 / 3, 50 - y - s + 2, shade);
        r(cx - s / 3, 48, s / 3 - 1, 5, skin); r(cx + 1, 48, s / 3 - 1, 5, skin);
        r(x, y, s, s, skin);
        r(x + s / 5, y + s * 28 / 100, s / 5, s / 5, face);
        r(x + s * 3 / 5, y + s * 28 / 100, s / 5, s / 5, face);
        if (!happy) {
            r(x + s * 2 / 5, y + s / 2, s / 5, s / 4, face);
            r(x + s * 3 / 10, y + s * 13 / 20, s / 10 + 1, s / 5, face);
            r(x + s * 6 / 10, y + s * 13 / 20, s / 10 + 1, s / 5, face);
        } else {
            r(x + s * 3 / 10, y + s * 11 / 20, s * 2 / 5, 2, face);
            r(x + s / 4, y + s / 2, 2, 3, face);
            r(x + s * 3 / 4 - 2, y + s / 2, 2, 3, face);
        }
        if (c >= 120 && c < 130) r(0, 0, W, H, 0x77FFFFFF); // bright flash: a hug, not a boom
        if (happy) {
            int[] hx = {cx - 34, cx + 28, cx - 14, cx + 12, cx - 52, cx + 46};
            for (int k = 0; k < hx.length; k++) {
                int hy = 46 - (c - 130) * 2 / 5 - k * 5;
                if (hy > 1 && hy < 54) heart(hx[k], hy, k % 2 == 0 ? 0xFFFF6B9A : 0xFFFFB3CE);
            }
        }
    }

    // ---------- bee flying between flowers ----------
    private static void bee(int t) {
        bg(0xFFCDEBFF, 0xFFEAF7FF);
        r(0, GROUND, W, H - GROUND, 0xFF7CC66B);
        for (int fx : new int[]{62, 205}) {
            r(fx - 1, 40, 3, 13, 0xFF4E9F3E);
            d(fx - 6, 36, 4, 0xFFFF8FB8); d(fx + 6, 36, 4, 0xFFFF8FB8);
            d(fx, 31, 4, 0xFFFF8FB8); d(fx, 41, 3, 0xFFFF8FB8);
            d(fx, 36, 3, 0xFFFFD84A);
        }
        for (int k = 5; k >= 0; k--) { // dotted trail
            double tt = (t - k * 5) / 40.0;
            int px = 140 + (int) Math.round(95 * Math.sin(tt));
            int py = 24 + (int) Math.round(10 * Math.sin(tt * 2));
            r(px + 4, py + 5, 2, 2, k == 0 ? 0 : 0x55FFFFFF);
        }
        double a = t / 40.0;
        int bx = 140 + (int) Math.round(95 * Math.sin(a)) - 4;
        int by = 24 + (int) Math.round(10 * Math.sin(a * 2)) - 4 + 4;
        int flap = (t / 3) % 2;
        r(bx + 1, by - 1 - flap * 2, 3, 4, 0xDDFFFFFF); r(bx + 6, by - 1 - flap * 2, 3, 4, 0xDDFFFFFF);
        r(bx, by + 3, 10, 6, 0xFFF5C518);
        r(bx + 3, by + 3, 1, 6, 0xFF2A2A2A); r(bx + 6, by + 3, 1, 6, 0xFF2A2A2A);
        boolean right = Math.cos(a) >= 0;
        r(right ? bx + 8 : bx + 1, by + 4, 1, 1, 0xFF2A2A2A);
    }

    // ---------- ladybug crawling on a leaf ----------
    private static void ladybug(int t) {
        bg(0xFFBFE8A6, 0xFF8FD27A);
        r(10, 28, 260, 3, 0xFF6BB35A);
        for (int i = 0; i < 8; i++) { // leaf veins
            r(30 + i * 30, 20 + (i % 2) * 18, 2, 10, 0xFF7CC66B);
            r(34 + i * 30, 31, 2, 10, 0xFF7CC66B);
        }
        double p = (t % 480) / 240.0;
        double u = p < 1 ? p : 2 - p;
        int dir = p < 1 ? 1 : -1;
        int bx = 30 + (int) (u * 220);
        int step = (t / 6) % 2;
        for (int i = 0; i < 3; i++) { // legs
            r(bx - 7 + i * 7, 44 + ((i + step) % 2), 1, 4, 0xFF25252D);
            r(bx - 7 + i * 7, 22 - ((i + step) % 2), 1, 4, 0xFF25252D);
        }
        d(bx, 34, 10, 0xFFE53935);
        r(bx, 24, 1, 20, 0xFF25252D);
        d(bx - 5, 30, 2, 0xFF25252D); d(bx + 5, 31, 2, 0xFF25252D); d(bx - 4, 39, 2, 0xFF25252D); d(bx + 4, 40, 2, 0xFF25252D);
        int hx = bx + dir * 11;
        d(hx, 34, 5, 0xFF25252D);
        r(hx + dir * 3, 31, 1, 1, 0xFFFFFFFF);
        r(hx + dir * 4, 26, 1, 4, 0xFF25252D); r(hx + dir * 4, 38, 1, 4, 0xFF25252D); // antennae
    }

    // ---------- penguin fishing ----------
    private static void penguin(int t) {
        bg(0xFFD7F0FF, 0xFFEAF8FF);
        r(0, 44, W, 16, 0xFF4FA3E0);
        for (int i = 0; i < 9; i++) r((i * 37 + t / 2) % W, 46 + i % 3 * 4, 9, 1, 0xFF9AD3FA);
        r(90, 40, 100, 5, 0xFFFFFFFF);
        r(96, 45, 88, 3, 0xFFBFE4F7);
        int k = t / 180, c = t % 180;
        boolean puffer = k % 3 == 2;
        double u = c < 90 ? c / 90.0 : -1;
        int shift = 0;
        if (puffer && c >= 55 && c < 100) shift = -3; // nope, not today
        int px = 140 + shift;
        r(px - 13, 24 + (int) Math.round(Math.sin(t / 10.0)), 3, 10, 0xFF25252D);
        r(px + 10, 24 - (int) Math.round(Math.sin(t / 10.0)), 3, 10, 0xFF25252D);
        d(px, 28, 11, 0xFF25252D);
        d(px, 31, 7, 0xFFFFFFFF);
        d(px, 15, 7, 0xFF25252D);
        r(px + 2, 12, 2, 2, 0xFFFFFFFF);
        boolean gulp = !puffer && c >= 82 && c < 100;
        r(px + 5, gulp ? 14 : 16, 6, gulp ? 1 : 3, 0xFFFF9A1F);
        if (gulp) r(px + 5, 18, 6, 1, 0xFFFF9A1F);
        r(px - 7, 38, 6, 2, 0xFFFF9A1F); r(px + 2, 38, 6, 2, 0xFFFF9A1F);
        if (u >= 0) {
            double arc = 4 * u * (1 - u);
            if (!puffer) {
                int fx = 218 - (int) (u * 62), fy = (int) (46 + (17 - 46) * u - 30 * arc);
                if (u < 0.97) {
                    r(fx, fy, 8, 4, 0xFFFF8A65); r(fx + 8, fy - 1, 3, 6, 0xFFFF8A65); r(fx + 1, fy + 1, 1, 1, 0xFF25252D);
                }
            } else {
                int fx = 218 - (int) (u * 120), fy = (int) (46 - 42 * arc);
                d(fx, fy, 5, 0xFFF2D14B);
                for (int a = 0; a < 8; a++) {
                    double an = a * Math.PI / 4;
                    r(fx + (int) Math.round(Math.cos(an) * 7), fy + (int) Math.round(Math.sin(an) * 7), 1, 1, 0xFFB08A1E);
                }
                r(fx - 2, fy - 1, 1, 1, 0xFF25252D); r(fx + 2, fy - 1, 1, 1, 0xFF25252D);
            }
        }
        if (puffer && c >= 60 && c < 100) r(px + 9, 8 + (c - 60) / 8, 2, 3, 0xFF7FC4F5); // sweat drop
    }

    // ---------- bamboo growing up ----------
    private static void bamboo(int t) {
        bg(0xFFE6F7D9, 0xFFC9EBB5);
        r(0, GROUND, W, H - GROUND, 0xFF8FCB84);
        for (int i = 0; i < 6; i++) {
            int x = 30 + i * 44;
            int phase = (t + i * 55) % 360;
            int h = 4 + (int) ((GROUND - 8) * Math.min(1.0, phase / 300.0));
            int top = GROUND - h;
            r(x, top, 6, h, 0xFF6FBF5A);
            r(x + 4, top, 2, h, 0xFF58A848);
            for (int ny = GROUND - 11; ny > top; ny -= 11) r(x - 1, ny, 8, 2, 0xFF4E9F3E);
            if (h > 18) { // leaves
                r(x + 6, top + 3, 7, 2, 0xFF7FD068); r(x - 7, top + 8, 7, 2, 0xFF7FD068);
            }
            r(x - 1, top - 1, 8, 2, 0xFF9BE07C);
        }
    }

    // ---------- bouncing slimes ----------
    private static void slime(int t) {
        bg(0xFFEFE3FB, 0xFFD8F3E6);
        r(0, GROUND, W, H - GROUND, 0xFFB7E0A8);
        slimeAt(110, t, 30);
        slimeAt(176, t + 22, 18);
    }

    private static void slimeAt(int cx, int t, int sz) {
        double c = (t % 60) / 60.0;
        int air = (int) Math.round(26 * 4 * c * (1 - c));
        int squash = air < 3 ? sz / 5 : 0;
        int w = sz - air / 5 + squash, h = sz * 4 / 5 + air / 4 - squash;
        int bottom = GROUND - air;
        int sw = Math.max(8, sz - air / 2);
        r(cx - sw / 2, GROUND, sw, 2, 0x33000000);
        r(cx - w / 2, bottom - h, w, h, 0xFF4CBF5C);
        r(cx - w / 2 + 2, bottom - h + 2, w - 4, h - 4, 0xFF7BE07F);
        r(cx - w / 2 + 4, bottom - h + 4, Math.max(2, sz / 6), Math.max(2, sz / 10), 0xFFFFFFFF);
        int ey = bottom - h * 6 / 10;
        int e = Math.max(2, sz / 10);
        r(cx - w / 4, ey, e, e, 0xFF16301A); r(cx + w / 4 - e, ey, e, e, 0xFF16301A);
        r(cx - e, ey + e + 2, e * 2, 1, 0xFF16301A);
    }

    // ---------- the hidden article: "Me", a shy little ghost with a candle ----------
    private static void me(int t) {
        bg(0xFF241C3F, 0xFF4A3A66);
        for (int i = 0; i < 18; i++) {
            if ((t / 25 + i) % 5 != 0) r((i * 47 + 9) % 270 + 4, (i * 23 + 5) % 44 + 3, 1 + i % 2, 1 + i % 2, 0xCCFFFFFF);
        }
        r(0, GROUND, W, H - GROUND, 0xFF2E2450);
        int cx = 140, top = 8 + (int) Math.round(Math.sin(t / 14.0) * 3), body = 0xFFF4F0FF, dark = 0xFF3A2A3A;
        d(cx, top + 15, 15, body);
        r(cx - 15, top + 15, 31, 20, body);
        for (int i = 0; i < 5; i++) { // wavy bottom edge
            r(cx - 15 + i * 6 + (i == 4 ? 1 : 0), top + 35, 5, 3 + (i % 2) * 3 + (int) Math.round(Math.sin(t / 6.0 + i) * 1.5), body);
        }
        int eye = (t % 160) < 8 ? 1 : 5; // blinks now and then
        r(cx - 8, top + 12, 4, eye, dark);
        r(cx + 4, top + 12, 4, eye, dark);
        r(cx - 12, top + 20, 3, 2, 0xFFFFB3D1);
        r(cx + 10, top + 20, 3, 2, 0xFFFFB3D1);
        r(cx - 4, top + 23, 9, 1, dark);
        r(cx - 5, top + 22, 1, 1, dark);
        r(cx + 5, top + 22, 1, 1, dark);
        // a candle next to it
        r(cx + 44, 38, 4, 14, 0xFFFFF3C0);
        int flame = 4 + (t / 5) % 2;
        r(cx + 45, 38 - flame, 2, flame, 0xFFFFC832);
        r(cx + 40, 34, 12, 12, 0x22FFE08A);
        if (t % 240 > 120) heart(cx + 24, 22 - (t % 120) / 6, 0xFFFF8FB0); // a heart floats up
    }

    // ---------- the hidden article: a window with a note (the code is the 4 digits) ----------
    private static void window(int t) {
        bg(0xFF2A2248, 0xFF3D3366);
        r(0, GROUND, W, H - GROUND, 0xFF2E2450);
        r(70, 4, 96, 50, 0xFF8A5A3A);                                   // frame
        int glass = 0xFF16193A;
        r(74, 8, 41, 21, glass); r(119, 8, 43, 21, glass);
        r(74, 33, 41, 17, glass); r(119, 33, 43, 17, glass);
        for (int i = 0; i < 7; i++) {                                    // twinkling stars
            if ((t / 30 + i) % 4 != 0) r(78 + (i * 23) % 80, 10 + (i * 11) % 36, 1, 1, 0xFFFFFFFF);
        }
        d(98, 18, 6, 0xFFFFF0C0); d(101, 16, 5, glass);                  // crescent moon
        int tap = (t % 180) < 40 && (t / 6) % 2 == 0 ? 1 : 0;            // a bee taps on the glass
        d(138, 40 + tap, 4, 0xFFF3D46A);
        r(136, 39 + tap, 1, 3, 0xFF3A2A3A); r(139, 39 + tap, 1, 3, 0xFF3A2A3A);
        r(66, 52, 104, 4, 0xFFB08A60);                                   // sill
        r(58, 2, 12, 52, 0xFFE58AAE); r(166, 2, 12, 52, 0xFFE58AAE);     // curtains
        r(61, 2, 1, 52, 0xFFC0587F); r(169, 2, 1, 52, 0xFFC0587F);
        r(188, 10, 46, 38, 0xFFFFF3A0);                                  // sticky note with the code
        r(188, 10, 46, 3, 0xFFF3D46A);
        r(205, 7, 12, 5, 0x88FFFFFF);
        g.pose().pushPose();
        g.pose().translate(ox + 192, oy + 25, 0);
        g.pose().scale(1.5f, 1.5f, 1f);
        g.drawString(Minecraft.getInstance().font, "1307", 0, 0, 0xFFB3202A, false);
        g.pose().popPose();
    }
}
