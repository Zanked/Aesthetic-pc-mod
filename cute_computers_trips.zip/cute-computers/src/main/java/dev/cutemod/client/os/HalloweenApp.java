package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/** The candy shop of the Halloween event: trade the candy you collected on the desktop. */
public class HalloweenApp extends App {
    private record Row(String kind, String id, int cost) {}

    private static final Row[] ROWS = {
            new Row("coins", "", 5),
            new Row("wall", "", 20),
            new Row("game", "horror", 15),
            new Row("game", "maze", 30),
            new Row("game", "zombies", 40)};
    private static final int TOP = 44, ROW = 23;
    private static final int ORANGE = 0xFFFF9A2A, MUTED = 0xFFB8A0D0, GREEN = 0xFF5BD97A;
    private static final int COIN_GAIN = 8, COIN_TRADES_PER_DAY = 3;

    @Override
    public Component title() { return Component.translatable("cutemod.hw.title"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.hw.hint"); }

    @Override
    public Component status() { return Component.translatable("cutemod.hw.candy", Halloween.candy()); }

    @Override
    public void tick() { Halloween.animate(); }

    private String stateOf(Row r) {
        switch (r.kind()) {
            case "wall":
                if (Halloween.hasWallpaper()) return Wallpaper.get() == Halloween.WALL ? "using" : "set";
                return "buy";
            case "game":
                return Library.owned(r.id()) ? "owned" : "buy";
            default:
                return "buy";
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        g.fillGradient(0, 0, W, H, 0xFF1A0F2E, 0xFF331A4A);
        for (int i = 0; i < 20; i++) rect(g, (i * 53 + 11) % (W - 2), (i * 29 + 5) % (H - 2), 1, 1, 0x88FFFFFF);
        Halloween.pumpkin(g, 6, 2, 28, false);
        g.drawString(f, Component.translatable("cutemod.hw.title").copy().withStyle(net.minecraft.ChatFormatting.BOLD), 40, 5, ORANGE, false);
        String cs = Integer.toString(Halloween.candy());
        Halloween.candy(g, W - 20 - f.width(cs) - 14, 8, 0xFFFF6FA5, 0xFFFFFFFF, 2);
        g.drawString(f, cs, W - 12 - f.width(cs), 6, 0xFFFFFFFF, false);
        List<FormattedCharSequence> help = f.split(FormattedText.of(t("cutemod.hw.help")), W - 48);
        for (int i = 0; i < help.size() && i < 3; i++) g.drawString(f, help.get(i), 40, 17 + i * 9, MUTED, false);

        for (int i = 0; i < ROWS.length; i++) {
            Row r = ROWS[i];
            int y = TOP + i * ROW;
            rect(g, 4, y, W - 8, ROW - 2, i % 2 == 0 ? 0xCC2A1A44 : 0xCC231538);
            switch (r.kind()) {
                case "coins" -> Progress.drawCoin(g, 14, y + 6);
                case "wall" -> Wallpaper.draw(g, 6, y + 2, 28, 18, shell.color().bodyColor, Halloween.WALL);
                default -> CoverArt.draw(g, r.id(), 8, y + 2, 18);
            }
            String name = switch (r.kind()) {
                case "coins" -> t("cutemod.hw.row.coins", COIN_GAIN);
                case "wall" -> t("cutemod.hw.row.wall");
                default -> Library.name(r.id());
            };
            g.drawString(f, f.plainSubstrByWidth(name, 150), 40, y + 3, 0xFFFFFFFF, false);
            boolean coinRow = r.kind().equals("coins");
            int left = Math.max(0, COIN_TRADES_PER_DAY - Progress.dailyCount("hw_coins"));
            g.drawString(f, t("cutemod.hw.cost", r.cost()) + (coinRow ? "  " + t("cutemod.hw.left", left) : ""), 40, y + 12, MUTED, false);

            String st = stateOf(r);
            boolean limit = coinRow && left == 0;
            boolean can = st.equals("set") || (st.equals("buy") && Halloween.candy() >= r.cost() && !limit);
            boolean hov = can && in(mx, my, W - 76, y + 3, 68, 16);
            int bg = st.equals("owned") || st.equals("using") ? 0xFF3A2F5A : !can ? 0xFF3A2F5A : hov ? 0xFF7BE890 : GREEN;
            rect(g, W - 76, y + 3, 68, 16, bg);
            String label = limit ? t("cutemod.hw.limit") : t("cutemod.hw." + st);
            g.drawString(f, label, W - 76 + (68 - f.width(label)) / 2, y + 7, can ? 0xFF12301A : MUTED, false);
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < ROWS.length; i++) {
            Row r = ROWS[i];
            int ry = TOP + i * ROW;
            if (!in(x, y, W - 76, ry + 3, 68, 16)) continue;
            String st = stateOf(r);
            switch (r.kind()) {
                case "coins" -> {
                    if (Progress.dailyCount("hw_coins") < COIN_TRADES_PER_DAY && Halloween.spendCandy(r.cost())) {
                        Progress.bump("hw_coins");
                        Progress.earn(COIN_GAIN);
                        Progress.toast("cutemod.toast.hw_trade");
                    }
                }
                case "wall" -> {
                    if (st.equals("set")) Wallpaper.set(Halloween.WALL);
                    else if (st.equals("buy") && Halloween.spendCandy(r.cost())) {
                        Halloween.giveWallpaper();
                        Wallpaper.set(Halloween.WALL);
                        Progress.toast("cutemod.toast.hw_trade");
                    }
                }
                default -> {
                    if (st.equals("buy") && Halloween.spendCandy(r.cost())) {
                        Library.grant(r.id());
                        Progress.toast("cutemod.toast.hw_trade");
                    }
                }
            }
            return true;
        }
        return true;
    }
}
