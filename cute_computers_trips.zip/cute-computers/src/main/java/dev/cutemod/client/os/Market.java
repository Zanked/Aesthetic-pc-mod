package dev.cutemod.client.os;

import dev.cutemod.market.Catalog;
import dev.cutemod.market.MarketServer;
import dev.cutemod.net.MarketOrderPayload;
import dev.cutemod.net.MarketPickupPayload;
import dev.cutemod.net.MarketSyncPayload;
import net.minecraft.core.BlockPos;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * CuteMarket: the online shop for food, music discs and gear. You pay coins here, but the order is kept
 * and delivered by the SERVER ({@link MarketServer}); when a parcel has arrived you collect it at the computer
 * and get real items. This class is only the client's view: the catalog, the cart maths and the parcels.
 */
public final class Market {
    private Market() {}

    public static final int EXPRESS_PCT = MarketServer.EXPRESS_PCT, EXPRESS_SPEED = MarketServer.EXPRESS_SPEED;

    public static final int FOOD = Catalog.FOOD, DISC = Catalog.DISC;

    public record Item(String id, int kind, int price, int secs, int maxQty) {}

    /** A parcel on its way; ready = arrival time on THIS computer's clock. */
    public static final class Order {
        public String id;
        public int qty;
        public long ready;
    }

    private static final List<Order> srv = new ArrayList<>();
    private static final Set<Long> notified = new HashSet<>();
    private static int gen = -1, pollTimer;

    private static Item of(Catalog.Entry e) { return new Item(e.id(), e.kind(), e.price(), e.secs(), e.maxQty()); }

    /** Everything of one kind (FOOD, DISC, TOOL, WEAPON or ARMOR), in shop order. */
    public static List<Item> items(int kind) {
        List<Item> out = new ArrayList<>();
        for (Catalog.Entry e : Catalog.entries(kind)) out.add(of(e));
        return out;
    }

    public static Item item(String id) { return of(Catalog.get(id)); }

    private static void ensure() {
        if (gen == Store.gen()) return;          // joined another world: forget the parcels of the previous one
        gen = Store.gen();
        srv.clear();
        notified.clear();
    }

    public static int total(Map<String, Integer> cart, boolean express) {
        int sum = 0;
        for (Map.Entry<String, Integer> e : cart.entrySet()) sum += Catalog.get(e.getKey()).price() * e.getValue();
        return express ? (int) Math.ceil(sum * (100 + EXPRESS_PCT) / 100.0) : sum;
    }

    /** Pays and sends the order to the server. Returns false if there are not enough coins. */
    public static boolean checkout(Map<String, Integer> cart, boolean express, BlockPos pos) {
        ensure();
        if (cart.isEmpty() || !Progress.spend(total(cart, express))) return false;
        List<MarketOrderPayload.Entry> lines = new ArrayList<>();
        for (Map.Entry<String, Integer> e : cart.entrySet()) lines.add(new MarketOrderPayload.Entry(e.getKey(), e.getValue()));
        PacketDistributor.sendToServer(new MarketOrderPayload(pos, lines, express));
        Progress.bump("market_orders");
        return true;
    }

    /** The server sent the list of parcels (and maybe a refund). */
    public static void applyServer(MarketSyncPayload p) {
        ensure();
        long shift = System.currentTimeMillis() - p.serverNow();   // the server's clock -> ours
        srv.clear();
        for (var x : p.parcels()) {
            Order o = new Order();
            o.id = x.id(); o.qty = x.qty(); o.ready = x.ready() + shift;
            srv.add(o);
        }
        if (p.refund() > 0) {
            Progress.refund(p.refund());
            Progress.toast("cutemod.market.refunded", p.refund());
        }
    }

    /** Newest first. */
    public static List<Order> orders() {
        ensure();
        List<Order> out = new ArrayList<>(srv);
        out.sort((a, b) -> Long.compare(b.ready, a.ready));
        return out;
    }

    public static int active() { ensure(); return srv.size(); }

    /** Parcels that have arrived and wait to be collected. */
    public static int readyCount() {
        int n = 0;
        for (Order o : orders()) if (arrived(o)) n++;
        return n;
    }

    public static int secondsLeft(Order o) { return (int) Math.max(0, (o.ready - System.currentTimeMillis() + 999) / 1000); }

    public static boolean arrived(Order o) { return o.ready <= System.currentTimeMillis(); }

    /** Asks the server for every parcel that has arrived. */
    public static void collect(BlockPos pos) { PacketDistributor.sendToServer(new MarketPickupPayload(pos)); }

    /** Called 60 times per second: once a second it tells the player about parcels that have just arrived. */
    public static void tick() {
        if (++pollTimer < 60) return;
        pollTimer = 0;
        for (Order o : orders()) {
            if (arrived(o) && notified.add(o.ready)) {
                Progress.toast("cutemod.toast.market_arrived", MarketApp.name(o.id));
            }
        }
    }
}
