package dev.cutemod.client.os;

import java.util.ArrayList;
import java.util.List;

/**
 * Which apps are pinned to the Dock, and in what order. The player decides (drag to reorder, drag out
 * or right-click to remove, right-click in the Start menu to pin). Saved on the server through {@link Store}.
 */
public final class DockLayout {
    private DockLayout() {}

    private static final List<Integer> order = new ArrayList<>();
    private static int gen = -1;

    private static void ensure() {
        if (gen == Store.gen()) return;
        gen = Store.gen();
        order.clear();
        String s = Store.read("dock");
        if (s == null) {                                   // never customized: everything is pinned
            for (int i = 0; i < Desktop.ICONS; i++) order.add(i);
            return;
        }
        for (String part : s.trim().split(",")) {
            try {
                int v = Integer.parseInt(part.trim());
                if (v == 15) v = 9;                        // CuteMarket took the slot of the old Shop
                if (v >= 0 && v < Desktop.ICONS && !order.contains(v)) order.add(v);
            } catch (NumberFormatException ignored) {      // "-" means an empty Dock
            }
        }
    }

    private static void save() {
        if (order.isEmpty()) { Store.write("dock", "-"); return; }
        StringBuilder sb = new StringBuilder();
        for (int v : order) sb.append(sb.length() == 0 ? "" : ",").append(v);
        Store.write("dock", sb.toString());
    }

    /** The pinned apps, left to right (apps that are not installed are left out). */
    public static List<Integer> list() {
        ensure();
        List<Integer> out = new ArrayList<>();
        for (int v : order) if (Library.available(v)) out.add(v);
        return out;
    }

    public static boolean pinned(int app) { ensure(); return order.contains(app); }

    public static void pin(int app) {
        ensure();
        if (app < 0 || app >= Desktop.ICONS || order.contains(app)) return;
        order.add(app);
        save();
    }

    public static void unpin(int app) {
        ensure();
        if (order.remove((Integer) app)) save();
    }

    public static void toggle(int app) {
        if (pinned(app)) unpin(app);
        else pin(app);
    }

    /** Put an app at a slot of the Dock (it is added if it was not pinned). */
    public static void move(int app, int slot) {
        ensure();
        order.remove((Integer) app);
        List<Integer> visible = list();                    // the slot counts only the icons that are shown
        int at = slot >= visible.size() ? order.size() : order.indexOf(visible.get(Math.max(0, slot)));
        order.add(Math.max(0, Math.min(order.size(), at)), app);
        save();
    }
}
