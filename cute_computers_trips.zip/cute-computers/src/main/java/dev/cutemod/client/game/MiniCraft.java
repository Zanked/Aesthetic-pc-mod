package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * MiniCraft: a tiny side-view Minecraft.
 * Walk (A/D), jump (W / Space), left click = mine / hit a zombie, right click = place a block.
 * Chop a tree, craft planks (C), make better pickaxes (E), dig down and find 3 diamonds.
 * At night zombies come. You lose when your hearts run out.
 */
public class MiniCraft extends MiniGame {
    private static final int T = 10, WW = 80, WH = 40;          // tile size in px, world size in tiles
    private static final double REACH = 5, PW = 0.7, PH = 1.8, ZW = 0.7, ZH = 1.8;
    private static final int DAY = 7200, NIGHT = 4800, DIAMONDS = 3;

    // blocks
    private static final int AIR = 0, GRASS = 1, DIRT = 2, STONE = 3, LOG = 4, LEAVES = 5, COAL = 6, IRON = 7,
            DIAMOND = 8, BEDROCK = 9, PLANKS = 10;
    private static final int[] HARD = {0, 1, 1, 4, 3, 1, 4, 6, 8, 999, 3};         // damage needed to break
    private static final int[] NEED = {0, 0, 0, 1, 0, 0, 1, 2, 3, 9, 0};           // pickaxe tier needed
    private static final int[] POINTS = {0, 1, 1, 2, 3, 0, 5, 10, 50, 0, 0};
    private static final int[] BASE = {0, 0xFF8A5A33, 0xFF8A5A33, 0xFF7C7C84, 0xFF6B4A2B, 0xFF2F8F3A, 0xFF7C7C84,
            0xFF7C7C84, 0xFF7C7C84, 0xFF2A2A30, 0xFFC49A5A};
    private static final int[] HOTBAR = {DIRT, STONE, LOG, PLANKS};                // what keys 1-4 place
    private static final int[] PICK = {0, 0xFFC49A5A, 0xFF9A9AA2, 0xFFE8E8EE};    // pickaxe head colors by tier
    private static final int[] PICK_MAT = {0, PLANKS, STONE, IRON};                // 3 of these make the next pickaxe

    private static final class Zombie {
        final double[] b = new double[4];                       // x, y, vx, vy
        int hp = 5, hurt, knock, stuck;
        boolean ground;
    }

    private int[][] world = new int[WH][WW];
    private final int[] top = new int[WW];                      // height of the ground in every column
    private final int[] inv = new int[11];
    private final double[] pl = new double[4];                  // player x, y, vx, vy
    private final List<Zombie> zs = new ArrayList<>();
    private boolean ground, won;
    private int hp, tier, sel, face, grace, knock, ticks, time, hx, hy, hit, camX, camY, msgT;
    private String msg = "";

    @Override
    public void reset() {
        score = 0; over = false; won = false;
        hp = 10; tier = 0; sel = 0; face = 1; grace = 0; knock = 0; ticks = 0; time = 600; hit = 0;
        java.util.Arrays.fill(inv, 0);
        zs.clear();
        generate();
        pl[0] = WW / 2.0 - PW / 2;
        pl[1] = Math.min(top[WW / 2 - 1], Math.min(top[WW / 2], top[WW / 2 + 1])) - PH;   // above the highest of the columns we stand on
        pl[2] = pl[3] = 0;
        say("cutemod.craft.start");
    }

    // ---------- the world ----------
    private void generate() {
        double p1 = rnd.nextDouble() * 6.28, p2 = rnd.nextDouble() * 6.28;
        for (int x = 0; x < WW; x++) top[x] = (int) Math.round(16 + 3 * Math.sin(x * 0.12 + p1) + 2 * Math.sin(x * 0.31 + p2));
        for (int x = 1; x < WW; x++) top[x] = Math.max(top[x - 1] - 1, Math.min(top[x - 1] + 1, top[x]));   // hills at most 1 block per step: you can always jump up
        for (int y = 0; y < WH; y++) for (int x = 0; x < WW; x++) {
            int d = y - top[x];
            double r = rnd.nextDouble();
            world[y][x] = y == WH - 1 ? BEDROCK : d < 0 ? AIR : d == 0 ? GRASS : d <= 3 ? DIRT
                    : (d > 3 && r < 0.05) ? COAL : (d > 7 && r > 0.95 && r < 0.975) ? IRON : (d > 14 && r > 0.992) ? DIAMOND : STONE;
        }
        for (int i = 0; i < 14; i++) {                            // caves: round holes in the stone
            int cx = 4 + rnd.nextInt(WW - 8), cy = top[cx] + 6 + rnd.nextInt(WH - top[cx] - 10);
            for (int y = cy - 2; y <= cy + 2; y++) for (int x = cx - 2; x <= cx + 2; x++) {
                if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= 5 && y < WH - 1) world[y][x] = AIR;
            }
        }
        for (int x = 4; x < WW - 4; x++) {                        // trees
            if (rnd.nextInt(8) != 0 || Math.abs(x - WW / 2) < 4) continue;
            int th = 3 + rnd.nextInt(2), ty = top[x] - th;
            for (int i = 1; i <= th; i++) world[top[x] - i][x] = LOG;
            for (int dy = -2; dy <= 0; dy++) for (int dx = -2; dx <= 2; dx++) {
                if (Math.abs(dx) == 2 && dy == -2) continue;
                if (world[ty + dy][x + dx] == AIR) world[ty + dy][x + dx] = LEAVES;
            }
            x += 3;
        }
        int found = 0;                                            // make sure there are enough diamonds
        for (int[] r : world) for (int b : r) if (b == DIAMOND) found++;
        while (found < 5) {
            int x = 2 + rnd.nextInt(WW - 4), y = top[x] + 14 + rnd.nextInt(WH - top[x] - 16);
            if (world[y][x] == STONE) { world[y][x] = DIAMOND; found++; }
        }
    }

    private int at(int x, int y) {
        if (x < 0 || x >= WW || y >= WH) return BEDROCK;
        return y < 0 ? AIR : world[y][x];
    }

    private boolean hits(double x, double y, double w, double h) {
        for (int ty = (int) Math.floor(y); ty <= (int) Math.floor(y + h - 0.001); ty++)
            for (int tx = (int) Math.floor(x); tx <= (int) Math.floor(x + w - 0.001); tx++)
                if (at(tx, ty) != AIR) return true;
        return false;
    }

    /** Gravity + walls for a box b = {x, y, vx, vy}. Returns true if it stands on something. */
    private boolean move(double[] b, double w, double h) {
        b[3] = Math.min(0.5, b[3] + 0.02);
        if (!hits(b[0] + b[2], b[1], w, h)) b[0] += b[2]; else b[2] = 0;
        double ny = b[1] + b[3];
        if (!hits(b[0], ny, w, h)) { b[1] = ny; return false; }
        boolean down = b[3] > 0;
        if (down) b[1] = Math.floor(ny + h) - h;
        b[3] = 0;
        return down;
    }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private void say(String key) { msg = key; msgT = 150; }

    private float dark() {
        return time < 300 ? 1 - time / 300F : time < 4200 ? 0 : time < NIGHT ? (time - 4200) / 600F : 1;
    }

    // ---------- game loop ----------
    @Override
    public void tick() {
        ticks++;
        time = (time + 1) % DAY;
        if (msgT > 0) msgT--;
        if (grace > 0) grace--;
        if (ticks % 600 == 0 && hp < 10) hp++;                       // hearts come back slowly

        double dir = (down(68) || down(KEY_RIGHT) ? 1 : 0) - (down(65) || down(KEY_LEFT) ? 1 : 0);
        if (knock > 0) knock--;
        else {
            pl[2] = dir * 0.07;
            if (dir != 0) face = (int) dir;
        }
        boolean step = dir != 0 && knock == 0 && hits(pl[0] + dir * 0.1, pl[1], PW, PH) && !hits(pl[0] + dir * 0.1, pl[1] - 1.05, PW, PH);   // a one block step: jump on it by itself
        if (ground && (step || down(87) || down(KEY_UP) || down(KEY_SPACE))) pl[3] = -0.28;
        ground = move(pl, PW, PH);

        if (dark() > 0.6F && zs.size() < 4 && ticks % 240 == 0) spawnZombie();
        if (time == 300) zs.clear();                                 // zombies burn at dawn
        for (Zombie z : new ArrayList<>(zs)) {
            double dx = pl[0] + PW / 2 - (z.b[0] + ZW / 2), d = Math.signum(dx);
            if (z.knock > 0) z.knock--; else z.b[2] = d * 0.025;
            boolean blocked = z.ground && z.knock == 0 && hits(z.b[0] + d * 0.15, z.b[1], ZW, ZH);
            if (blocked && !hits(z.b[0] + d * 0.15, z.b[1] - 1.05, ZW, ZH)) z.b[3] = -0.28;   // hop over a one block step
            else if (blocked && ++z.stuck > 40) chew(z, d);                                    // too high: chew through trees
            if (!blocked) z.stuck = 0;
            z.ground = move(z.b, ZW, ZH);
            if (z.hurt > 0) z.hurt--;
            boolean touch = Math.abs(dx) < (PW + ZW) / 2 && Math.abs(pl[1] + PH / 2 - z.b[1] - ZH / 2) < (PH + ZH) / 2;
            if (touch && grace == 0) {                                // ouch
                hp--;
                grace = 60;
                knock = 10;
                pl[2] = -d * 0.15;
                pl[3] = -0.15;
                pling(0.6F);
            }
        }
        if (hp <= 0) { over = true; pling(0.5F); return; }
        if (inv[DIAMOND] >= DIAMONDS) {
            won = true;
            over = true;
            score += 300;
            pling(1.0F); pling(1.5F); pling(2.0F);
        }
    }

    /** A zombie that is stuck breaks the wood, leaves, grass and dirt in front of it. Stone and planks stop it: build a wall! */
    private void chew(Zombie z, double d) {
        int tx = (int) Math.floor(z.b[0] + (d > 0 ? ZW + 0.2 : -0.2));
        for (int ty = (int) Math.floor(z.b[1]); ty <= (int) Math.floor(z.b[1] + ZH - 0.001); ty++) {
            int b = at(tx, ty);
            if (b == LOG || b == LEAVES || b == GRASS || b == DIRT) world[ty][tx] = AIR;
        }
        z.stuck = 0;
    }

    private void spawnZombie() {
        int x = (int) pl[0] + (rnd.nextInt(2) == 0 ? -1 : 1) * (14 + rnd.nextInt(8));
        x = Math.max(1, Math.min(WW - 2, x));
        int y = 0;
        while (y < WH && at(x, y) == AIR) y++;
        Zombie z = new Zombie();
        z.b[0] = x;
        z.b[1] = y - ZH;
        zs.add(z);
    }

    // ---------- mouse and keys ----------
    private void updateCam() {
        camX = Math.max(0, Math.min(WW * T - W, (int) ((pl[0] + PW / 2) * T) - W / 2));
        camY = Math.max(0, Math.min(WH * T - H, (int) ((pl[1] + PH / 2) * T) - H / 2));
    }

    @Override
    public boolean click(int x, int y, int button) {
        int hx0 = (W - 88) / 2;
        if (in(x, y, hx0, H - 20, 88, 20)) { sel = (x - hx0) / 22; return true; }   // click a hotbar slot
        updateCam();
        double wx = (x + camX) / (double) T, wy = (y + camY) / (double) T;
        if (Math.hypot(wx - (pl[0] + PW / 2), wy - (pl[1] + PH / 2)) > REACH) return true;
        if (button == 0) {
            if (!hitZombie(wx, wy)) mine((int) Math.floor(wx), (int) Math.floor(wy));
        } else {
            place((int) Math.floor(wx), (int) Math.floor(wy));
        }
        return true;
    }

    private boolean hitZombie(double wx, double wy) {
        for (Zombie z : zs) {
            if (wx >= z.b[0] - 0.2 && wx <= z.b[0] + ZW + 0.2 && wy >= z.b[1] && wy <= z.b[1] + ZH) {
                z.hp -= 1 + tier;
                z.hurt = 8;
                z.knock = 10;
                z.b[2] = face * 0.12;
                z.b[3] = -0.12;
                beep();
                if (z.hp <= 0) { zs.remove(z); score += 10; pling(1.6F); }
                return true;
            }
        }
        return false;
    }

    private void mine(int tx, int ty) {
        int b = at(tx, ty);
        if (b == AIR || b == BEDROCK) return;
        if (NEED[b] > tier) { say("cutemod.craft.need"); beep(); return; }
        if (tx != hx || ty != hy) { hx = tx; hy = ty; hit = 0; }
        hit += 1 + tier;                                              // better pickaxe = bigger hits
        beep();
        if (hit < HARD[b]) return;
        world[ty][tx] = AIR;
        hit = 0;
        int item = b == GRASS ? DIRT : b == LEAVES ? 0 : b;
        if (item != 0) inv[item]++;
        score += POINTS[b];
        if (b == DIAMOND) { pling(2.0F); say("cutemod.craft.diamond"); }
        else if (b == COAL || b == IRON) pling(1.7F);
        else pling(1.0F);
    }

    private void place(int tx, int ty) {
        int item = HOTBAR[sel];
        if (at(tx, ty) != AIR || inv[item] <= 0) return;
        if (tx + 1 > pl[0] && tx < pl[0] + PW && ty + 1 > pl[1] && ty < pl[1] + PH) return;   // not inside you
        for (Zombie z : zs) if (tx + 1 > z.b[0] && tx < z.b[0] + ZW && ty + 1 > z.b[1] && ty < z.b[1] + ZH) return;
        world[ty][tx] = item;
        inv[item]--;
        beep();
    }

    @Override
    public boolean key(int k) {
        if (k >= 49 && k <= 52) { sel = k - 49; return true; }       // 1-4
        if (k == 67) {                                                // C: logs -> planks
            if (inv[LOG] > 0) { inv[LOG]--; inv[PLANKS] += 4; say("cutemod.craft.planks"); pling(1.2F); }
            else say("cutemod.craft.nolog");
            return true;
        }
        if (k == 69) {                                                // E: next pickaxe
            int next = tier + 1;
            if (next >= PICK.length) say("cutemod.craft.maxpick");
            else if (inv[PICK_MAT[next]] >= 3) {
                inv[PICK_MAT[next]] -= 3;
                tier = next;
                say("cutemod.craft.pick" + next);
                pling(1.5F);
            } else say("cutemod.craft.nomat");
            return true;
        }
        return false;
    }

    // ---------- drawing ----------
    private static int lerp(int a, int b, float f) {
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private void tile(GuiGraphics g, int b, int x, int y, int sx, int sy) {
        rect(g, sx, sy, T, T, BASE[b]);
        int h = ((x * 73856093) ^ (y * 19349663)) & 15;
        switch (b) {
            case GRASS -> { rect(g, sx, sy, T, 3, 0xFF6FD45A); rect(g, sx + h % 8, sy + 3, 2, 1, 0xFF6FD45A); rect(g, sx + 2 + h % 5, sy + 6, 2, 2, 0xFF6B4A2B); }
            case DIRT -> { rect(g, sx + h % 7, sy + 2, 2, 2, 0xFF6B4A2B); rect(g, sx + 6 - h % 5, sy + 6, 2, 2, 0xFFA07040); }
            case STONE -> { rect(g, sx + h % 7, sy + 2, 2, 2, 0xFF6A6A72); rect(g, sx + 7 - h % 5, sy + 6, 2, 2, 0xFF8E8E96); }
            case COAL, IRON, DIAMOND -> {
                int c = b == COAL ? 0xFF1A1A1E : b == IRON ? 0xFFD8A878 : 0xFF4AEDD9;
                rect(g, sx + 1, sy + 1, 2, 2, c); rect(g, sx + 6, sy + 2, 2, 2, c);
                rect(g, sx + 2, sy + 6, 2, 2, c); rect(g, sx + 7, sy + 7, 2, 2, c);
            }
            case LOG -> { rect(g, sx + 2, sy, 1, T, 0xFF4A3018); rect(g, sx + 7, sy, 1, T, 0xFF4A3018); }
            case LEAVES -> { rect(g, sx + h % 7, sy + 1, 2, 2, 0xFF4FB85A); rect(g, sx + 7 - h % 6, sy + 6, 2, 2, 0xFF1E6A2A); }
            case PLANKS -> { rect(g, sx, sy + 3, T, 1, 0xFF9A7440); rect(g, sx, sy + 7, T, 1, 0xFF9A7440); }
            default -> rect(g, sx + h % 7, sy + 3, 3, 2, 0xFF3C3C44);
        }
        int depth = y - top[x] - 5;
        if (depth > 0) rect(g, sx, sy, T, T, (Math.min(0xA0, depth * 6) << 24));   // deeper = darker
    }

    private void heart(GuiGraphics g, int x, int y, int col) {
        rect(g, x, y, 2, 1, col); rect(g, x + 3, y, 2, 1, col);
        rect(g, x, y + 1, 5, 1, col); rect(g, x + 1, y + 2, 3, 1, col); rect(g, x + 2, y + 3, 1, 1, col);
    }

    private void person(GuiGraphics g, double[] b, int dir, boolean zombie, int flash) {
        int sx = (int) (b[0] * T) - camX, sy = (int) (b[1] * T) - camY;
        int walk = Math.abs(b[2]) > 0.01 && (ticks / 8) % 2 == 0 ? 1 : 0;
        rect(g, sx + 1 + walk, sy + 13, 2, 5, 0xFF3A3A8A);                 // legs
        rect(g, sx + 4 - walk, sy + 13, 2, 5, 0xFF3A3A8A);
        rect(g, sx, sy + 7, 7, 6, zombie ? 0xFF2A7A8A : 0xFF3AB5D9);        // body
        rect(g, sx, sy, 7, 7, zombie ? 0xFF5A9A4A : 0xFFF0C8A0);           // head
        rect(g, sx, sy, 7, 2, zombie ? 0xFF3A6A30 : 0xFF4A2A14);           // hair
        rect(g, sx + (dir > 0 ? 4 : 1), sy + 3, 2, 1, zombie ? 0xFF111111 : 0xFF2A2A5A);   // eye
        if (zombie) rect(g, sx + (dir > 0 ? 5 : -2), sy + 8, 4, 2, 0xFF5A9A4A);            // arm held out
        else if (tier > 0) {                                                // pickaxe in hand
            int px = dir > 0 ? sx + 7 : sx - 5;
            rect(g, px, sy + 8, 5, 1, 0xFF6B4A2B);
            rect(g, dir > 0 ? px + 3 : px, sy + 6, 2, 3, PICK[tier]);
        }
        if (flash > 0) rect(g, sx, sy, 7, 18, 0x88FF0000);
    }

    @Override
    public void render(GuiGraphics g) {
        updateCam();
        float dk = dark();
        g.fillGradient(0, 0, W, H, lerp(0xFF7EC8F0, 0xFF0A1030, dk), lerp(0xFFCFEFFF, 0xFF1B2850, dk));
        double frac = time < NIGHT ? time / (double) NIGHT : (time - NIGHT) / (double) (DAY - NIGHT);
        int ox = 15 + (int) (frac * 190), oy = 45 - (int) (Math.sin(frac * Math.PI) * 32);
        if (time < NIGHT) disc(g, ox, oy, 6, 0xFFFFE066); else { disc(g, ox, oy, 5, 0xFFEFEFF5); disc(g, ox + 2, oy - 1, 4, lerp(0xFF7EC8F0, 0xFF0A1030, 1)); }
        if (dk > 0.5F) for (int i = 0; i < 14; i++) rect(g, (i * 53 + 7) % W, (i * 31) % 50, 1, 1, 0xFFFFFFFF);

        for (int y = Math.max(0, camY / T); y <= Math.min(WH - 1, (camY + H) / T); y++) {
            for (int x = Math.max(0, camX / T); x <= Math.min(WW - 1, (camX + W) / T); x++) {
                int b = world[y][x], sx = x * T - camX, sy = y * T - camY;
                if (b != AIR) tile(g, b, x, y, sx, sy);
                else if (y > top[x]) rect(g, sx, sy, T, T, 0xFF1A1620);   // inside a cave
            }
        }
        for (Zombie z : zs) person(g, z.b, pl[0] > z.b[0] ? 1 : -1, true, z.hurt);
        if (grace == 0 || (ticks / 4) % 2 == 0) person(g, pl, face, false, 0);

        int tx = (int) Math.floor((mx + camX) / (double) T), ty = (int) Math.floor((my + camY) / (double) T);   // block under the mouse
        if (Math.hypot((mx + camX) / (double) T - pl[0] - PW / 2, (my + camY) / (double) T - pl[1] - PH / 2) <= REACH) {
            int sx = tx * T - camX, sy = ty * T - camY;
            rect(g, sx, sy, T, 1, 0xCCFFFFFF); rect(g, sx, sy + T - 1, T, 1, 0xCCFFFFFF);
            rect(g, sx, sy, 1, T, 0xCCFFFFFF); rect(g, sx + T - 1, sy, 1, T, 0xCCFFFFFF);
            int b = at(tx, ty);
            if (hit > 0 && tx == hx && ty == hy && HARD[b] < 900 && b != AIR) rect(g, sx + 1, sy + 1, T - 2, T - 2, (Math.min(0xA0, hit * 0xA0 / HARD[b]) << 24));   // cracks
        }
        if (dk > 0) rect(g, 0, 0, W, H, ((int) (dk * 0x70) << 24) | 0x000018);                      // night
        if (grace > 40) rect(g, 0, 0, W, H, 0x30FF0000);
        hud(g);
    }

    private void hud(GuiGraphics g) {
        for (int i = 0; i < 10; i++) heart(g, 4 + i * 6, 4, i < hp ? 0xFFE5484D : 0xFF3A2A3A);
        int[] res = {COAL, IRON, DIAMOND};                                  // coal / iron / diamonds
        int[] col = {0xFF1A1A1E, 0xFFD8A878, 0xFF4AEDD9};
        for (int i = 0; i < 3; i++) {
            int x = W - 70 + i * 23;
            rect(g, x, 3, 6, 6, col[i]);
            text(g, i == 2 ? inv[DIAMOND] + "/" + DIAMONDS : String.valueOf(inv[res[i]]), x + 8, 2, 0xFFFFFFFF);
        }
        int hx0 = (W - 88) / 2;
        for (int i = 0; i < 4; i++) {                                       // hotbar
            int x = hx0 + i * 22, y = H - 20;
            rect(g, x, y, 21, 19, i == sel ? 0xFFFFFFFF : 0xFF3A2A4A);
            rect(g, x + 1, y + 1, 19, 17, 0xFF1B1422);
            tile(g, HOTBAR[i], 0, 0, x + 3, y + 4);
            text(g, String.valueOf(inv[HOTBAR[i]]), x + 14 - (inv[HOTBAR[i]] > 9 ? 4 : 0), y + 10, 0xFFFFFFFF);
        }
        if (tier < PICK.length - 1) {                                       // next pickaxe: 3 x material, press E
            int next = tier + 1, x = W - 44, y = H - 17;
            rect(g, x, y, 40, 14, 0xAA000000);
            rect(g, x + 3, y + 5, 5, 4, PICK[next]);
            rect(g, x + 14, y + 4, 6, 6, BASE[PICK_MAT[next]] | 0xFF000000);
            text(g, "x3", x + 22, y + 3, inv[PICK_MAT[next]] >= 3 ? 0xFF7CFF8A : 0xFFFFFFFF);
        }
        if (msgT > 0) ctext(g, Component.translatable(msg).getString(), W / 2, 16, msgT < 30 ? 0xFFB0A070 : 0xFFFFE9A0);
        if (!zs.isEmpty() && dark() > 0.6F) ctext(g, Component.translatable("cutemod.craft.night").getString(), W / 2, 26, 0xFFFF8A8A);
    }

    @Override
    public String hintKey() { return "cutemod.hint.craft"; }

    @Override
    public Component status() { return Component.translatable("cutemod.craft.status", inv[DIAMOND], DIAMONDS, score); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() { return Component.translatable(won ? "cutemod.craft.win" : "cutemod.craft.dead"); }
}
