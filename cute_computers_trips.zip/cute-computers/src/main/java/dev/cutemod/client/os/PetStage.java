package dev.cutemod.client.os;

import dev.cutemod.CuteMod;
import dev.cutemod.ComputerColor;
import dev.cutemod.data.ShowBoard;
import dev.cutemod.data.ShowJudges;
import dev.cutemod.net.ShowSyncPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/**
 * The talent show screen of the Tamagotchi app: a stage with curtains, a marquee, moving spotlights, four judges
 * at their desk and the pets of the round. It only draws what the server says (see {@link ShowSyncPayload}); the
 * rounds, the stars and the prizes are decided on the server.
 * <ul>
 *   <li>doors open: put your pet on the stage, click a pet to like it (click again to take the like back);</li>
 *   <li>judging: the judges show their stars one by one;</li>
 *   <li>results: a podium with confetti, your place and your prize.</li>
 * </ul>
 */
final class PetStage {
    private static final int W = App.W, H = App.H;
    private static final int FOOT_Y = 152, FOOT_H = 14;
    private static final int WALL_TOP = 13, DESK_Y = 50, FLOOR_Y = 58;
    private static final int TEXT = 0xFF3A2A3A, GOLD = 0xFFF3C45A, ACCENT = 0xFFB57BD6;
    private static final int[] JUDGE_COL = {0xFFFFFFFF, 0xFF8FD39A, 0xFFC9A0FF, 0xFFFFD84D};
    private static final int[] MEDAL = {0xFFF3C45A, 0xFFC4CAD6, 0xFFD08A4E};
    private static final int[] CONFETTI = {0xFFFF5C93, 0xFFFFD84D, 0xFF5BD9C8, 0xFF8FB8FF, 0xFFB57BD6, 0xFFFFFFFF};

    private final String myColor;
    private final Runnable back;
    private final Random rnd = new Random();

    private int ticks, timer = 1000, toastT, armed, armT, bannerT;
    private String toast = "", pending = "";
    private ShowSyncPayload cur, seen;
    private boolean hall;                                       // the Hall of Fame panel is open
    private static final int HALL_X = 27, HALL_Y = 26;
    private int curAt;
    private int lastJudges = -1, lastPhase = -1;
    private final int[] flash = new int[ShowJudges.COUNT];
    // what the judges say (like the animals of a village: a speech box, text that types itself and soft blips)
    /** The voices of the judges: Mei high and sweet, Boom a little hiss and a round "bwoo", Void deep and quiet, Honey bright and buzzy.
     *  Our own sounds (sounds/voice/<judge>_<0..7>.ogg, made by tools/make_voices.py), not Minecraft's. */
    private static final SoundEvent[] VOICE = {voice("mei"), voice("boom"), voice("void"), voice("honey")};
    private static final float[] VOICE_VOL = {0.45F, 0.45F, 0.65F, 0.40F};      // Void is quiet by nature, so a little louder

    private static SoundEvent voice(String judge) {
        return SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "voice." + judge));
    }
    private final ArrayDeque<Object[]> queue = new ArrayDeque<>();          // {judge, text}
    private int spkJ = -1, spkAge, spkHold, idleT = 600, lastTheme = -1, lastRender = -100;
    private String spkText = "";
    private final Map<String, Integer> lastLikes = new HashMap<>();
    private final List<double[]> hearts = new ArrayList<>();     // x, y, vx, vy, life
    private final List<double[]> confetti = new ArrayList<>();   // x, y, vx, vy, color index, spin

    // the place of every pet on the screen, filled while drawing and used for the mouse
    private int[] px = new int[0], pf = new int[0];
    private float[] ps = new float[0];

    PetStage(String myColor, Runnable back) {
        this.myColor = myColor;
        this.back = back;
    }

    void open() {
        cur = Show.last();
        seen = cur;
        curAt = ticks;
        if (cur != null) {
            lastJudges = cur.head().judges();
            lastPhase = cur.head().phase();
            rememberLikes(cur);
        }
        timer = 1000;
        queue.clear();
        spkJ = -1;
        idleT = 300;
        lastTheme = -1;
    }

    private static String myId() {
        var p = Minecraft.getInstance().player;
        return p == null ? "" : p.getUUID().toString();
    }

    private static String t(String key, Object... args) { return net.minecraft.network.chat.Component.translatable(key, args).getString(); }

    private void say(String key) { toast = t(key); toastT = 150; }

    // ---------- time and the news from the server ----------
    void tick() {
        ticks++;
        if (ticks - lastRender < 5) GameMusic.keep("show", false);    // the show tune, only while the stage is on screen
        speechTick();
        if (++timer >= 120) { Show.request(); timer = 0; }
        if (toastT > 0) toastT--;
        if (bannerT > 0) bannerT--;
        if (armT > 0 && --armT == 0) armed = 0;
        for (int i = 0; i < flash.length; i++) if (flash[i] > 0) flash[i]--;
        ShowSyncPayload s = Show.last();
        if (s != seen) {
            seen = s;
            if (s != null) { cur = s; curAt = ticks; onNews(s); }
        }
        if (cur != null && leftSec() == 0 && timer > 60) { Show.request(); timer = 0; }   // the phase has just ended: look again
        // hearts
        for (int i = hearts.size() - 1; i >= 0; i--) {
            double[] h = hearts.get(i);
            h[0] += h[2]; h[1] += h[3]; h[4]--;
            if (h[4] <= 0) hearts.remove(i);
        }
        // confetti while the results are on
        boolean results = cur != null && cur.head().phase() == ShowBoard.RESULTS;
        if (results && ticks % 3 == 0 && confetti.size() < 90) spawnConfetti(1);
        for (int i = confetti.size() - 1; i >= 0; i--) {
            double[] c = confetti.get(i);
            c[0] += c[2] + Math.sin((ticks + i * 7) / 12.0) * 0.4;
            c[1] += c[3];
            c[5] += 0.2;
            if (c[1] > FOOT_Y) confetti.remove(i);
        }
    }

    private int leftSec() {
        if (cur == null) return 0;
        return Math.max(0, cur.head().leftSec() - (ticks - curAt) / 60);
    }

    private void spawnConfetti(int n) {
        for (int i = 0; i < n; i++)
            confetti.add(new double[]{24 + rnd.nextInt(W - 48), WALL_TOP + 2, (rnd.nextDouble() - 0.5) * 0.6, 0.5 + rnd.nextDouble() * 0.7, rnd.nextInt(CONFETTI.length), rnd.nextDouble() * 6});
    }

    private static String key(ShowSyncPayload.Entry e) { return e.who().owner() + "/" + e.who().name() + "/" + e.who().color(); }

    private void rememberLikes(ShowSyncPayload s) {
        lastLikes.clear();
        for (ShowSyncPayload.Entry e : s.pets()) lastLikes.put(key(e), e.likes());
    }

    private void onNews(ShowSyncPayload s) {
        if (s.head().result() >= 0) onResult(s.head().result());
        int phase = s.head().phase();
        // judges that have just spoken
        if (lastJudges >= 0 && s.head().judges() > lastJudges) {
            for (int j = lastJudges; j < s.head().judges() && j < flash.length; j++) {
                flash[j] = 90;
                Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 0.9F + 0.15F * j, 0.6F);
                if (phase == ShowBoard.JUDGING) revealSpeech(s, j);
            }
        }
        int theme = s.head().theme();
        if (theme != lastTheme) {
            lastTheme = theme;
            if (phase == ShowBoard.OPEN) speak(theme % ShowJudges.COUNT, t("cutemod.show.say.theme." + theme % ShowJudges.COUNT, t("cutemod.show.theme." + theme)));
        }
        if (phase == ShowBoard.JUDGING && lastPhase == ShowBoard.OPEN) speak(1, t("cutemod.show.say.judging"));
        lastJudges = s.head().judges();
        // the results have just begun
        if (phase == ShowBoard.RESULTS && lastPhase >= 0 && lastPhase != ShowBoard.RESULTS) {
            spawnConfetti(70);
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 0.9F, 0.6F);
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.2F, 0.6F);
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.8F, 0.6F);
            bannerT = 600;
            if (!s.pets().isEmpty()) {
                speak(0, t("cutemod.show.say.winner", s.pets().get(0).who().name()));
                speak(3, t("cutemod.show.say.bye"));
            }
        } else if (phase == ShowBoard.RESULTS && lastPhase < 0 && bannerT == 0) {
            bannerT = 600;
            spawnConfetti(40);
        }
        lastPhase = phase;
        // a like has just come: hearts rise from that pet
        for (int i = 0; i < s.pets().size(); i++) {
            ShowSyncPayload.Entry e = s.pets().get(i);
            Integer old = lastLikes.get(key(e));
            if (old != null && e.likes() > old && i < px.length) {
                for (int k = 0; k < Math.min(4, e.likes() - old + 1); k++)
                    hearts.add(new double[]{px[i] - 8 + rnd.nextInt(16), pf[i] - 30, (rnd.nextDouble() - 0.5) * 0.4, -0.5 - rnd.nextDouble() * 0.3, 50 + rnd.nextInt(25)});
            }
        }
        rememberLikes(s);
    }

    /** The answer of the server to what we did. */
    private void onResult(int r) {
        String what = pending;
        pending = "";
        switch (r) {
            case 0 -> { if (what.equals("put")) say("cutemod.show.msg.put"); else if (what.equals("take")) say("cutemod.show.msg.taken"); }
            case 1 -> say("cutemod.show.msg.fast");
            case 3 -> say("cutemod.show.msg.sick");
            case 4 -> say("cutemod.show.msg.own");
            case 5 -> say("cutemod.show.msg.missing");
            case 7 -> say("cutemod.show.msg.closed");
            case 8 -> say("cutemod.show.msg.full");
            case 9 -> say("cutemod.show.msg.guest");
            default -> say("cutemod.show.msg.refused");
        }
    }

    // ---------- the judges talk ----------
    private void speak(int j, String text) {
        while (queue.size() >= 3) queue.poll();
        queue.add(new Object[]{j, text});
    }

    private void speakIdle(int j) { speak(j, t("cutemod.show.say." + j + ".idle." + rnd.nextInt(3))); }

    /** After a judge has shown the stars he or she says something about your pet (or the best one if you are not on the stage). */
    private void revealSpeech(ShowSyncPayload s, int j) {
        ShowSyncPayload.Entry about = null;
        String me = myId();
        for (ShowSyncPayload.Entry e : s.pets()) if (!e.bot() && e.who().owner().equals(me)) about = e;
        if (about == null) {
            int best = -1;
            for (ShowSyncPayload.Entry e : s.pets()) {
                int v = e.score().stars().get(j);
                if (v > best) { best = v; about = e; }
            }
        }
        if (about == null) return;
        int v = about.score().stars().get(j);
        int tier = v <= 2 ? 0 : v == 3 ? 1 : 2;
        int variant = Math.floorMod(about.who().name().hashCode() + j + s.head().theme(), 2);
        speak(j, t("cutemod.show.say." + j + "." + tier + "." + variant, about.who().name()));
    }

    private void speechTick() {
        if (spkJ >= 0) {
            spkAge++;
            int shown = spkAge / 3;                                     // about 20 letters a second
            if (spkAge % 3 == 0 && shown > 0 && shown <= spkText.length() && shown % 2 == 0) {
                char c = spkText.charAt(shown - 1);
                if (Character.isLetterOrDigit(c))                       // one soft blip for every other letter
                    Sfx.ui(VOICE[spkJ], 0.92F + (c % 7) * 0.035F, VOICE_VOL[spkJ]);   // the letter picks how high the syllable is
            }
            if (shown >= spkText.length() && ++spkHold > 150) spkJ = -1;   // time to read it
        } else if (!queue.isEmpty()) {
            Object[] n = queue.poll();
            spkJ = (Integer) n[0];
            spkText = (String) n[1];
            spkAge = 0;
            spkHold = 0;
        } else if (cur != null && phase() == ShowBoard.OPEN && --idleT <= 0) {
            idleT = 900 + rnd.nextInt(900);
            speakIdle(rnd.nextInt(ShowJudges.COUNT));
        }
    }

    private void speech(GuiGraphics g, Font f) {
        if (spkJ < 0) return;
        int maxW = 190;
        List<String> lines = new ArrayList<>();
        for (var l : f.getSplitter().splitLines(spkText, maxW, Style.EMPTY)) lines.add(l.getString());
        if (lines.size() > 3) lines = lines.subList(0, 3);
        int bw = 0;
        for (String l : lines) bw = Math.max(bw, f.width(l));
        bw += 14;
        int bh = 14 + lines.size() * 10;
        int cx = 70 + spkJ * 53;
        int bx = Math.max(28, Math.min(W - 28 - bw, cx - bw / 2)), by = 62;
        // the box with a tail that points to whoever is talking
        rect(g, bx - 1, by - 1, bw + 2, bh + 2, 0xFF3A2A3A);
        rect(g, bx, by, bw, bh, 0xF8FFFFFF);
        rect(g, cx - 3, by - 3, 7, 3, 0xFF3A2A3A);
        rect(g, cx - 2, by - 3, 5, 3, 0xF8FFFFFF);
        rect(g, cx - 1, by - 4, 3, 1, 0xFF3A2A3A);
        // the name tag
        String name = t("cutemod.show.judge." + spkJ);
        int nw = f.width(name) + 10;
        rect(g, bx + 4, by - 6, nw, 10, 0xFF3A2A3A);
        rect(g, bx + 5, by - 5, nw - 2, 8, JUDGE_COL[spkJ]);
        g.drawString(f, name, bx + 9, by - 4, TEXT, false);
        // the text types itself
        int remaining = spkAge / 3, y = by + 7;
        for (String l : lines) {
            int n = Math.min(l.length(), Math.max(0, remaining));
            g.drawString(f, l.substring(0, n), bx + 7, y, TEXT, false);
            remaining -= l.length() + 1;
            y += 10;
        }
        if (spkAge / 3 >= spkText.length() && (ticks / 15) % 2 == 0)       // "more" / done marker
            rect(g, bx + bw - 10, by + bh - 6, 5, 3, ACCENT);
    }

    // ---------- the clock, the phase and the theme ----------
    private static void plate(GuiGraphics g, int x, int y, int w, int h) {
        rect(g, x, y, w, h, 0xFF2A0E3A);
        rect(g, x + 1, y + 1, w - 2, h - 2, 0xFF5A1670);
    }

    private void clock(GuiGraphics g, Font f) {
        int ph = phase(), s = leftSec();
        boolean hurry = cur != null && ph == ShowBoard.OPEN && s <= 10 && (ticks / 10) % 2 == 0;
        int col = hurry ? 0xFFFF6B6B : ph == ShowBoard.OPEN ? 0xFFB6F5C4 : ph == ShowBoard.JUDGING ? 0xFFFFE066 : 0xFFFFB3D9;
        // the big clock on the left: how long until the phase ends
        int x = 27, y = 3, w = 44, h = 13;
        plate(g, x, y, w, h);
        disc(g, x + 8, y + 6, 4, 0xFFFFFFFF);
        rect(g, x + 8, y + 3, 1, 4, 0xFF3A2A3A);
        rect(g, x + 8, y + 6, 3, 1, 0xFF3A2A3A);
        String tm = cur == null ? "-:--" : (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
        g.pose().pushPose();
        g.pose().translate(x + 16, y + 2.5F, 0);
        g.pose().scale(1.25F, 1.25F, 1F);
        g.drawString(f, tm, 0, 0, col, true);
        g.pose().popPose();
        // what is going on, on the right
        int rx = 229;
        plate(g, rx, y, w, h);
        String lab = f.plainSubstrByWidth(t("cutemod.show.phase.short." + ph), w - 4);
        g.drawString(f, lab, rx + (w - f.width(lab)) / 2, y + 3, col, false);
        // the whole round as a bar: open / judging / results
        int bx = 27, bw = 246, by = 17;
        long total = ShowBoard.ROUND_MS;
        int w1 = (int) (bw * ShowBoard.OPEN_MS / total), w2 = (int) (bw * (ShowBoard.RESULTS_AT_MS - ShowBoard.OPEN_MS) / total), w3 = bw - w1 - w2;
        long remaining = s * 1000L + (ph == ShowBoard.OPEN ? total - ShowBoard.OPEN_MS : ph == ShowBoard.JUDGING ? total - ShowBoard.RESULTS_AT_MS : 0);
        int done = cur == null ? 0 : (int) Math.max(0, Math.min(bw, bw * (total - remaining) / total));
        int[] start = {0, w1, w1 + w2}, len = {w1, w2, w3};
        int[] dim = {0xFF1E5A38, 0xFF6A5A18, 0xFF6A2A52}, lit = {0xFF5BD97A, 0xFFFFD84D, 0xFFFF7CC4};
        for (int k = 0; k < 3; k++) {
            rect(g, bx + start[k], by, len[k] - 1, 3, dim[k]);
            int fill = Math.max(0, Math.min(len[k] - 1, done - start[k]));
            if (fill > 0) rect(g, bx + start[k], by, fill, 3, lit[k]);
        }
        rect(g, bx + done - 1, by - 1, 2, 5, 0xFFFFFFFF);
    }

    private void themePill(GuiGraphics g, Font f, int mx, int my) {
        if (cur == null || (phase() == ShowBoard.RESULTS && bannerT > 0)) return;
        int th = cur.head().theme();
        String label = t("cutemod.show.theme.label", t("cutemod.show.theme." + th));
        int w = f.width(label) + 22, x = (W - w) / 2, y = 22;
        rect(g, x, y, w, 11, 0xCC2A0E3A);
        rect(g, x, y + 10, w, 1, GOLD);
        star(g, x + 4, y + 3, GOLD);
        star(g, x + w - 9, y + 3, GOLD);
        g.drawString(f, label, x + 11, y + 2, 0xFFFFE9A8, false);
        if (App.in(mx, my, x, y, w, 11)) {                               // the hint: what the judges like tonight
            String hint = t("cutemod.show.theme.hint." + th);
            int hw = Math.min(W - 40, f.width(hint) + 8);
            List<String> hl = new ArrayList<>();
            for (var l : f.getSplitter().splitLines(hint, hw - 8, Style.EMPTY)) hl.add(l.getString());
            int hh = hl.size() * 10 + 4, hx = (W - hw) / 2, hy = y + 14;
            rect(g, hx, hy, hw, hh, 0xEE3A2A3A);
            for (int i = 0; i < hl.size(); i++) g.drawString(f, hl.get(i), hx + 4, hy + 3 + i * 10, 0xFFFFFFFF, false);
        }
    }

    // ---------- where the pets stand ----------
    /** Fills px / pf / ps for n pets. In the results the first three stand on the podium. */
    private void layout(int n, boolean results) {
        if (px.length != n) { px = new int[n]; pf = new int[n]; ps = new float[n]; }
        if (results) {
            for (int i = 0; i < n; i++) {
                switch (i) {
                    case 0 -> { px[i] = 150; pf[i] = 120; ps[i] = 0.62F; }
                    case 1 -> { px[i] = 94; pf[i] = 130; ps[i] = 0.55F; }
                    case 2 -> { px[i] = 206; pf[i] = 136; ps[i] = 0.5F; }
                    default -> {
                        int k = i - 3;
                        boolean left = k % 2 == 0;
                        int col = k / 2;
                        px[i] = left ? 34 + col * 20 : 266 - col * 20;
                        pf[i] = col == 2 ? 134 : 148;
                        ps[i] = 0.4F;
                    }
                }
            }
        } else if (n <= 4) {
            int x0 = 150 - (n - 1) * 33;
            for (int i = 0; i < n; i++) { px[i] = x0 + i * 66; pf[i] = 118; ps[i] = 0.75F; }
        } else {
            int back = (n + 1) / 2, front = n - back;
            for (int i = 0; i < n; i++) {
                boolean b = i < back;
                int cnt = b ? back : front, idx = b ? i : i - back;
                px[i] = 150 - (cnt - 1) * 31 + idx * 62;
                pf[i] = b ? 86 : 130;
                ps[i] = 0.5F;
            }
        }
    }

    private int petAt(int mx, int my) {
        for (int i = px.length - 1; i >= 0; i--) {
            float s = ps[i];
            if (mx >= px[i] - 28 * s - 4 && mx <= px[i] + 28 * s + 4 && my >= pf[i] - 56 * s && my <= pf[i] + 10) return i;
        }
        return -1;
    }

    // ---------- drawing ----------
    void render(GuiGraphics g, int mx, int my) {
        Font f = Minecraft.getInstance().font;
        lastRender = ticks;
        List<ShowSyncPayload.Entry> pets = cur == null ? List.of() : cur.pets();
        int phase = cur == null ? ShowBoard.OPEN : cur.head().phase();
        boolean results = phase == ShowBoard.RESULTS;
        layout(pets.size(), results);
        int hover = petAt(mx, my);

        wall(g);
        desk(g);
        floor(g);
        spotlights(g);
        if (results) podium(g, f, pets);
        judges(g, f, pets, hover);
        String me = myId();
        // pets: back to front, so the nearer ones cover the farther ones
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < pets.size(); i++) order.add(i);
        order.sort((a, b) -> Integer.compare(pf[a], pf[b]));
        for (int i : order) pet(g, f, pets.get(i), i, me, hover == i, results);
        curtains(g);
        marquee(g, f);
        clock(g, f);
        for (double[] c : confetti) {
            int col = CONFETTI[(int) c[4]];
            int w = Math.sin(c[5]) > 0 ? 3 : 2;
            rect(g, (int) c[0], (int) c[1], w, 3, col);
        }
        for (double[] h : hearts) {
            int a = (int) Math.min(255, h[4] * 8);
            PetShow.heart(g, (int) h[0], (int) h[1], (a << 24) | 0xFF5C93);
        }
        speech(g, f);
        if (results && bannerT > 0 && !pets.isEmpty()) winnerBanner(g, f, pets.get(0));
        themePill(g, f, mx, my);
        hallButton(g, f, mx, my);
        footer(g, f, mx, my);
        if (toastT > 0) {
            int w = f.width(toast) + 12, x = (W - w) / 2, y = FOOT_Y - 16;
            rect(g, x, y, w, 13, 0xEE3A2A3A);
            g.drawString(f, toast, x + 6, y + 3, 0xFFFFFFFF, false);
        }
        if (hover >= 0 && !hall) tooltip(g, f, pets.get(hover), mx, my);
        if (hall) hallPanel(g, f);
        if (cur == null) {
            String l = t("cutemod.net.loading");
            g.drawString(f, l, (W - f.width(l)) / 2, 100, 0xFFE4D8FF, false);
        }
    }

    private void wall(GuiGraphics g) {
        for (int y = 0; y < FLOOR_Y; y += 3) {                    // a purple night that gets lighter downwards
            int c = App.mix(0x1E0F44, 0x5A2E8F, y / (float) FLOOR_Y);
            rect(g, 0, y, W, 3, c);
        }
        for (int i = 0; i < 26; i++) {                            // twinkling stars on the wall
            int x = 26 + (i * 73) % (W - 52), y = WALL_TOP + 2 + (i * 37) % 26;
            if ((ticks / 12 + i) % 4 != 0) rect(g, x, y, 1, 1, 0xCCFFFFFF);
            else { rect(g, x - 1, y, 3, 1, 0xFFFFE9A8); rect(g, x, y - 1, 1, 3, 0xFFFFE9A8); }
        }
        // soft party lights behind the judges
        int[] glow = {0x33FF5C93, 0x335BD9C8, 0x33FFD84D, 0x33B57BD6};
        for (int i = 0; i < 4; i++) {
            int r = 16 + (int) (Math.sin(ticks / 25.0 + i * 1.7) * 3);
            disc(g, 70 + i * 53, 36, r, glow[i]);
        }
    }

    private void spotlights(GuiGraphics g) {
        // two cones from the top that sweep over the stage (drawn over the wall and the floor)
        for (int k = 0; k < 2; k++) {
            double sweep = Math.sin(ticks / 70.0 + k * 2.4);
            int topX = (int) (90 + k * 120 + sweep * 18), botX = (int) (90 + k * 120 + sweep * 70);
            int col = k == 0 ? 0x16FFE9A8 : 0x16A8D8FF;
            for (int y = WALL_TOP; y < FOOT_Y; y += 2) {
                float p = (y - WALL_TOP) / (float) (FOOT_Y - WALL_TOP);
                int cx = (int) (topX + (botX - topX) * p), hw = 3 + (int) (p * 26);
                rect(g, cx - hw, y, hw * 2, 2, col);
            }
        }
    }

    private void desk(GuiGraphics g) {
        rect(g, 0, DESK_Y, W, 8, 0xFF6B3A22);
        rect(g, 0, DESK_Y, W, 2, 0xFFA8693E);
        rect(g, 0, DESK_Y + 6, W, 2, 0xFF4A2616);
    }

    private void floor(GuiGraphics g) {
        for (int y = FLOOR_Y, row = 0; y < FOOT_Y; y += 6, row++) {
            float p = (y - FLOOR_Y) / (float) (FOOT_Y - FLOOR_Y);
            int base = App.mix(row % 2 == 0 ? 0xA9784A : 0xB4824F, 0xD9A066, p * 0.35F);
            rect(g, 0, y, W, Math.min(6, FOOT_Y - y), base);
            rect(g, 0, y, W, 1, App.mix(base, 0x000000, 0.18F));
            for (int x = (row * 37) % 60; x < W; x += 60) rect(g, x, y, 1, 6, App.mix(base, 0x000000, 0.12F));
        }
        for (int x = 4; x < W; x += 12) {                         // the footlights along the front edge
            boolean on = (x / 12 + ticks / 20) % 3 != 0;
            rect(g, x, FOOT_Y - 3, 5, 3, on ? 0xFFFFE08A : 0xFF8A6A3A);
            if (on) rect(g, x - 1, FOOT_Y - 4, 7, 1, 0x44FFE08A);
        }
    }

    private void curtains(GuiGraphics g) {
        for (int side = 0; side < 2; side++) {
            int x0 = side == 0 ? 0 : W - 24;
            rect(g, x0, 0, 24, FOOT_Y, 0xFFA82840);
            for (int i = 0; i < 6; i++) {
                int fx = x0 + i * 4;
                rect(g, fx, 0, 2, FOOT_Y, 0xFF8E1F36);
                rect(g, fx + 2, 0, 1, FOOT_Y, 0xFFC03A55);
            }
            int edge = side == 0 ? x0 + 22 : x0;
            rect(g, edge, 0, 2, FOOT_Y, GOLD);
            int tx = side == 0 ? x0 + 17 : x0 + 2;                // the tassel
            rect(g, tx, 70, 5, 3, GOLD);
            rect(g, tx + 1, 73, 3, 8, 0xFFE0A93A);
        }
        for (int x = 0; x < W; x += 12) disc(g, x + 6, 3, 6, 0xFFA82840);   // the scalloped valance at the top
        rect(g, 0, 0, W, 3, 0xFFA82840);
        rect(g, 0, 8, W, 1, GOLD);
    }

    private void marquee(GuiGraphics g, Font f) {
        int x = 74, w = 152, y = 3, h = 13;
        rect(g, x, y, w, h, 0xFF2A0E3A);
        rect(g, x + 1, y + 1, w - 2, h - 2, 0xFF5A1670);
        for (int i = 0; i < 16; i++) {                            // bulbs that chase around the sign
            boolean on = (i + ticks / 6) % 3 == 0;
            int bx = x + 3 + i * 9;
            rect(g, bx, y, 3, 2, on ? 0xFFFFF3B0 : 0xFFB8862A);
            rect(g, bx, y + h - 2, 3, 2, on ? 0xFFB8862A : 0xFFFFF3B0);
        }
        String s = t("cutemod.show.title");
        int tx = x + (w - f.width(s)) / 2;
        g.drawString(f, s, tx, y + 3, (ticks / 15) % 2 == 0 ? 0xFFFFE066 : 0xFFFFFFFF, true);
    }

    private void judges(GuiGraphics g, Font f, List<ShowSyncPayload.Entry> pets, int hover) {
        int revealed = cur == null ? 0 : cur.head().judges();
        for (int j = 0; j < ShowJudges.COUNT; j++) {
            int cx = 70 + j * 53;
            ComputerColor color = PetShow.colorOf(ShowJudges.COLOR[j]);
            boolean talking = spkJ == j && spkAge / 3 < spkText.length();
            int hop = flash[j] > 0 ? (int) Math.abs(Math.sin(flash[j] * 0.3) * 5) : talking ? (ticks / 4) % 2 : 0;
            float sc = 0.4F;
            g.pose().pushPose();
            g.pose().translate(cx, DESK_Y + 2, 0);
            g.pose().scale(sc, sc, 1F);
            g.pose().translate(-cx, -(DESK_Y + 2) - hop * 2.5F, 0);
            PetArt.draw(g, color, cx, DESK_Y + 2 - 28, 2, ticks + j * 11, false, false, 2, ShowJudges.HAT[j], "");
            g.pose().popPose();
            // the score card: the stars of the pet under the mouse (or "?" before the judge has spoken)
            boolean spoke = revealed > j;
            int stars = hover >= 0 && hover < pets.size() && spoke ? pets.get(hover).score().stars().get(j) : -1;
            int cy = 40 - hop;
            rect(g, cx - 9, cy, 18, 11, flash[j] > 0 && (ticks / 4) % 2 == 0 ? 0xFFFFF3B0 : 0xFFFFFFFF);
            rect(g, cx - 9, cy + 9, 18, 2, JUDGE_COL[j]);
            String s = !spoke ? "?" : stars < 0 ? "★" : stars + "★";
            g.drawString(f, s, cx - f.width(s) / 2, cy + 1, !spoke ? 0xFF8A7AA8 : 0xFFB98A10, false);
            String name = t("cutemod.show.judge." + j);
            g.drawString(f, name, cx - f.width(name) / 2, DESK_Y + 1, 0xFFFFE9C8, false);
        }
    }

    private void podium(GuiGraphics g, Font f, List<ShowSyncPayload.Entry> pets) {
        int[] top = {120, 130, 136}, left = {122, 66, 178};
        for (int i = 0; i < 3; i++) {
            int y = top[i], x = left[i], h = FOOT_Y - 3 - y;
            rect(g, x, y, 56, h, App.mix(MEDAL[i], 0x000000, 0.35F));
            rect(g, x, y, 56, 3, MEDAL[i]);
            rect(g, x, y + 3, 56, 1, App.mix(MEDAL[i], 0xFFFFFF, 0.4F));
            String n = "#" + (i + 1);
            g.drawString(f, n, x + 4, y + 6, 0xFFFFFFFF, true);
            if (i < pets.size()) {
                String nm = f.plainSubstrByWidth(pets.get(i).who().name(), 38);
                g.drawString(f, nm, x + 52 - f.width(nm), y + 6, 0xFFFFFFFF, false);
            }
        }
    }

    private void pet(GuiGraphics g, Font f, ShowSyncPayload.Entry e, int i, String me, boolean hover, boolean results) {
        int cx = px[i], fl = pf[i];
        float sc = ps[i];
        boolean mine = !e.bot() && e.who().owner().equals(me);
        int rank = e.score().rank();
        if (hover || mine) oval(g, cx, fl + 1, (int) (22 * sc) + 6, 3, mine ? 0x66FFE066 : 0x55FFFFFF);
        oval(g, cx, fl + 1, (int) (20 * sc) + 2, 2, 0x44000000);
        float s = sc * PetArt.scaleOf(e.look().stage());
        int mood = hover || mine || (results && rank >= 1 && rank <= 3) ? 2 : 1;
        int bob = (int) Math.round(Math.sin((ticks + i * 23) / 18.0) * 1.2);
        g.pose().pushPose();
        g.pose().translate(cx, fl, 0);
        g.pose().scale(s, s, 1F);
        g.pose().translate(-cx, -fl, 0);
        PetArt.draw(g, PetShow.colorOf(e.who().color()), cx, fl - 28 + bob, mood, ticks + i * 37, false, false,
                e.look().stage(), e.look().head(), e.look().body());
        g.pose().popPose();
        if (results && rank >= 1 && rank <= 3) {                  // a little crown sparkle over the podium pets
            if ((ticks / 10 + i) % 2 == 0) sparkle(g, cx + 14, fl - (int) (44 * s) - 2);
            return;
        }
        if (results) {                                            // the rest of the stage: just their place
            String n = "#" + rank;
            g.drawString(f, n, cx - f.width(n) / 2, fl - (int) (50 * s) - 8, 0xFFE4D8FF, true);
            return;
        }
        // the name and the hearts under the pet
        String name = f.plainSubstrByWidth(e.who().name(), (int) (66 * Math.min(1F, sc + 0.25F)));
        int nameCol = mine ? GOLD : e.bot() ? 0xFFC9D8FF : 0xFFFFFFFF;
        g.drawString(f, name, cx - f.width(name) / 2, fl + 3, nameCol, true);
        String likes = Integer.toString(e.likes());
        int sum = 0;
        for (int v : e.score().stars()) sum += v;
        String st = sum > 0 ? "  ★" + sum : "";
        int w = 8 + f.width(likes) + f.width(st);
        int x0 = cx - w / 2;
        PetShow.heart(g, x0, fl + 13, e.liked() ? 0xFFFF5C7C : 0xFFE4D8FF);
        g.drawString(f, likes, x0 + 9, fl + 12, e.liked() ? 0xFFFF9CB0 : 0xFFFFFFFF, true);
        if (!st.isEmpty()) g.drawString(f, st, x0 + 9 + f.width(likes), fl + 12, 0xFFFFE066, true);
    }

    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(1.0 - (dy * dy) / (double) (ry * ry + 1)));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** A 5 x 5 pixel star. */
    private static void star(GuiGraphics g, int x, int y, int argb) {
        rect(g, x + 2, y, 1, 1, argb);
        rect(g, x + 1, y + 1, 3, 1, argb);
        rect(g, x, y + 2, 5, 1, argb);
        rect(g, x + 1, y + 3, 3, 1, argb);
        rect(g, x + 1, y + 4, 1, 1, argb);
        rect(g, x + 3, y + 4, 1, 1, argb);
    }

    private static void sparkle(GuiGraphics g, int x, int y) {
        rect(g, x - 2, y, 5, 1, 0xFFFFF3B0);
        rect(g, x, y - 2, 1, 5, 0xFFFFF3B0);
    }

    private void winnerBanner(GuiGraphics g, Font f, ShowSyncPayload.Entry w) {
        String s = t("cutemod.show.winner.banner", w.who().name());
        int bw = f.width(s) + 16, x = (W - bw) / 2, y = 17 + (bannerT > 560 ? (bannerT - 560) / 2 : 0);
        rect(g, x - 1, y - 1, bw + 2, 13, 0xFF3A2A3A);
        rect(g, x, y, bw, 11, 0xFFFFF3B0);
        rect(g, x, y + 9, bw, 2, GOLD);
        g.drawString(f, s, x + 8, y + 2, TEXT, false);
    }

    // ---------- the Hall of Fame ----------
    private void hallButton(GuiGraphics g, Font f, int mx, int my) {
        boolean hov = App.in(mx, my, HALL_X, HALL_Y, 26, 26);
        rect(g, HALL_X, HALL_Y, 26, 26, hov ? 0xDD5A1670 : 0xAA2A0E3A);
        rect(g, HALL_X, HALL_Y + 25, 26, 1, GOLD);
        PetShow.cup(g, HALL_X + 8, HALL_Y + 3, GOLD);
        String l = t("cutemod.show.hall.btn");
        g.drawString(f, l, HALL_X + (26 - f.width(l)) / 2, HALL_Y + 17, 0xFFFFE9A8, false);
    }

    private static String ago(long ms) {
        long min = ms / 60_000L;
        if (min < 1) return t("cutemod.show.ago.now");
        if (min < 60) return t("cutemod.show.ago.min", min);
        if (min < 1440) return t("cutemod.show.ago.hour", min / 60);
        return t("cutemod.show.ago.day", min / 1440);
    }

    /** Your cups, your title and the last winners of the show. */
    private void hallPanel(GuiGraphics g, Font f) {
        rect(g, 0, 0, W, FOOT_Y, 0xAA120824);
        int x = 34, y = 8, w = 232, h = 142;
        rect(g, x - 1, y - 1, w + 2, h + 2, GOLD);
        rect(g, x, y, w, h, 0xFF2A1450);
        String title = t("cutemod.show.hall.title");
        g.drawString(f, title, x + (w - f.width(title)) / 2, y + 4, GOLD, true);
        ShowSyncPayload.Fame fame = cur == null ? null : cur.fame();
        int gold = fame == null ? 0 : fame.gold();
        int[] n = fame == null ? new int[3] : new int[]{fame.gold(), fame.silver(), fame.bronze()};
        for (int i = 0; i < 3; i++) {
            int cx = x + 44 + i * 56;
            PetShow.cup(g, cx, y + 15, MEDAL[i]);
            g.drawString(f, "x" + n[i], cx + 15, y + 20, 0xFFFFFFFF, false);
        }
        int lvl = ShowBoard.titleLevel(gold);
        String ti = lvl > 0 ? t("cutemod.show.hall.titleline", t("cutemod.show.rank." + lvl)) : t("cutemod.show.hall.notitle");
        String lau = gold >= ShowBoard.OUTFIT_GOLD ? t("cutemod.show.hall.laurel_done") : t("cutemod.show.hall.laurel", gold, ShowBoard.OUTFIT_GOLD);
        String line = f.plainSubstrByWidth(ti + " · " + lau, w - 8);
        g.drawString(f, line, x + (w - f.width(line)) / 2, y + 36, 0xFFE4D8FF, false);
        rect(g, x + 6, y + 47, w - 12, 1, 0x66F3C45A);
        List<ShowSyncPayload.Winner> list = fame == null ? List.of() : fame.hall();
        if (list.isEmpty()) {
            String e = t("cutemod.show.hall.empty");
            g.drawString(f, e, x + (w - f.width(e)) / 2, y + 80, 0xFFB8A8D8, false);
            return;
        }
        String me = Minecraft.getInstance().getUser().getName();
        long now = System.currentTimeMillis();
        for (int i = 0; i < list.size() && i < ShowBoard.HALL_SIZE; i++) {
            ShowSyncPayload.Winner wn = list.get(i);
            int ry = y + 51 + i * 9;
            int col = !wn.bot() && wn.name().equals(me) ? GOLD : 0xFFFFFFFF;
            disc(g, x + 10, ry + 4, 3, PetShow.colorOf(wn.color()).bodyColor | 0xFF000000);
            String nm = wn.name() + (wn.bot() ? " " + t("cutemod.show.hall.guest") : "");
            g.drawString(f, f.plainSubstrByWidth(nm, 112), x + 18, ry, col, false);
            g.drawString(f, wn.total() + "★", x + 138, ry, 0xFFFFE066, false);
            String ago = ago(now - (wn.round() + 1) * ShowBoard.ROUND_MS);
            g.drawString(f, ago, x + w - 6 - f.width(ago), ry, 0xFFB8A8D8, false);
        }
    }

    private void tooltip(GuiGraphics g, Font f, ShowSyncPayload.Entry e, int mx, int my) {
        List<String> lines = new ArrayList<>();
        lines.add(e.who().name() + ": " + t("cutemod.pet.name." + e.who().color()) + ", " + t("cutemod.pet.trait." + e.look().trait())
                + ", " + t("cutemod.pet.stage." + e.look().stage()));
        StringBuilder sb = new StringBuilder();
        for (int j = 0; j < ShowJudges.COUNT; j++) {
            int v = e.score().stars().get(j);
            if (v > 0) sb.append(sb.length() > 0 ? "  " : "").append(t("cutemod.show.judge." + j)).append(' ').append(v).append('★');
        }
        if (sb.length() > 0) lines.add(sb.toString());
        if (e.bot()) lines.add(t("cutemod.show.guest"));
        int lvl = ShowBoard.titleLevel(e.who().gold());
        if (lvl > 0) lines.add("★ " + t("cutemod.show.rank." + lvl));
        int w = 0;
        for (String l : lines) w = Math.max(w, f.width(l));
        w += 8;
        int h = lines.size() * 10 + 4;
        int x = Math.max(2, Math.min(mx + 8, W - w - 2)), y = my + 14 + h < FOOT_Y ? my + 14 : Math.max(2, my - h - 4);
        rect(g, x, y, w, h, 0xEE3A2A3A);
        for (int i = 0; i < lines.size(); i++) g.drawString(f, lines.get(i), x + 4, y + 3 + i * 10, i == 0 ? 0xFFFFFFFF : 0xFFFFE066, false);
    }

    // ---------- the bottom bar ----------
    private boolean entered() { return cur != null && cur.me().entered(); }

    private int phase() { return cur == null ? ShowBoard.OPEN : cur.head().phase(); }

    private void footer(GuiGraphics g, Font f, int mx, int my) {
        rect(g, 0, FOOT_Y, W, H - FOOT_Y, 0xFF2A1450);
        rect(g, 0, FOOT_Y, W, 1, GOLD);
        boolean open = phase() == ShowBoard.OPEN && cur != null;
        if (!open) {
            button(g, f, mx, my, 4, 100, t("cutemod.show.btn.closed"), 2);
        } else if (entered()) {
            button(g, f, mx, my, 4, 66, t("cutemod.show.btn.refresh"), 0);
            button(g, f, mx, my, 72, 36, armed == 1 ? t("cutemod.show.btn.sure") : t("cutemod.show.btn.leave"), armed == 1 ? 3 : 0);
        } else {
            button(g, f, mx, my, 4, 104, t("cutemod.show.btn.enter"), 1);
        }
        button(g, f, mx, my, W - 54, 50, t("cutemod.show.btn.back"), 0);
        // the clock / your result in the middle
        String mid;
        int col = 0xFFE4D8FF;
        if (cur != null && phase() == ShowBoard.RESULTS && cur.me().rank() > 0) {
            int prize = cur.me().prize();
            mid = prize > 0 ? t("cutemod.show.you", cur.me().rank(), prize)
                    : prize == 0 ? t("cutemod.show.you_limit", cur.me().rank()) : t("cutemod.show.you_place", cur.me().rank());
            col = cur.me().rank() == 1 ? GOLD : 0xFFE4D8FF;
        } else {
            int s = leftSec();
            mid = t("cutemod.show.phase." + phase(), s / 60 + ":" + (s % 60 < 10 ? "0" : "") + s % 60);
        }
        int maxW = W - 54 - 4 - 112 - 6;
        mid = f.plainSubstrByWidth(mid, maxW);
        g.drawString(f, mid, 112 + (maxW - f.width(mid)) / 2, FOOT_Y + 3, col, false);
    }

    /** style 0 normal, 1 the main action, 2 dimmed, 3 a red "are you sure". */
    private void button(GuiGraphics g, Font f, int mx, int my, int x, int w, String label, int style) {
        boolean hov = style != 2 && App.in(mx, my, x, FOOT_Y + 1, w, FOOT_H - 1);
        int bg = style == 1 ? (hov ? 0xFF9A6FD0 : ACCENT) : style == 2 ? 0xFF4A3A66 : style == 3 ? 0xFFE5486F : hov ? 0xFFE4D8FF : 0xFFFFFFFF;
        rect(g, x, FOOT_Y + 2, w, FOOT_H - 3, bg);
        rect(g, x, FOOT_Y + FOOT_H - 3, w, 1, 0x33000000);
        int fg = style == 1 || style == 3 ? 0xFFFFFFFF : style == 2 ? 0xFF8A7AA8 : TEXT;
        String l = f.plainSubstrByWidth(label, w - 4);
        g.drawString(f, l, x + (w - f.width(l)) / 2, FOOT_Y + 4, fg, false);
    }

    // ---------- input ----------
    boolean click(int x, int y) {
        if (y >= FOOT_Y) {
            if (App.in(x, y, W - 54, FOOT_Y, 50, FOOT_H)) { back.run(); return true; }
            boolean open = phase() == ShowBoard.OPEN && cur != null;
            if (!open) return true;
            if (entered()) {
                if (App.in(x, y, 4, FOOT_Y, 66, FOOT_H)) { exhibit(); return true; }
                if (App.in(x, y, 72, FOOT_Y, 36, FOOT_H)) {                       // leaving loses the likes: ask twice
                    if (armed != 1) { armed = 1; armT = 180; return true; }
                    armed = 0;
                    pending = "take";
                    Show.withdraw(myColor);
                    timer = 100;
                }
            } else if (App.in(x, y, 4, FOOT_Y, 104, FOOT_H)) {
                exhibit();
            }
            return true;
        }
        if (hall) { hall = false; return true; }                       // any click closes the Hall of Fame
        if (App.in(x, y, HALL_X, HALL_Y, 26, 26)) { hall = true; return true; }
        for (int j = 0; j < ShowJudges.COUNT; j++) {
            if (App.in(x, y, 70 + j * 53 - 14, 24, 28, 32)) {
                if (spkJ >= 0) spkJ = -1; else speakIdle(j);
                return true;
            }
        }
        if (cur == null) return true;
        int i = petAt(x, y);
        if (i < 0 || i >= cur.pets().size()) return true;
        if (phase() == ShowBoard.RESULTS) return true;
        ShowSyncPayload.Entry e = cur.pets().get(i);
        if (e.bot()) { say("cutemod.show.msg.guest"); return true; }
        if (e.who().owner().equals(myId())) { say("cutemod.show.msg.own"); return true; }
        pending = "like";
        if (e.liked()) Show.unlike(e.who().owner(), e.who().color()); else Show.like(e.who().owner(), e.who().color());
        timer = 100;
        return true;
    }

    private void exhibit() {
        pending = "put";
        if (!Show.exhibit(myColor)) { pending = ""; say("cutemod.show.msg.nopet"); }
        timer = 100;
    }

    boolean key(int keyCode) {
        if (keyCode == 256) { if (hall) { hall = false; return true; } back.run(); return true; }       // escape leaves the stage, not the computer
        return false;
    }
}
