# Cute Computers (NeoForge 1.21.1)

Cute retro computers in 8 colors. **Right-click a computer to open its desktop.**
The desktop looks like macOS: a menu bar on top (logo menu, app name, coins, clock), windows with red/yellow/green buttons and a **Dock** at the bottom whose icons grow under the mouse. All icons share one macOS style: a rounded tile with a soft gradient and a flat white glyph (the gamepad takes the computer's color); they are drawn in code in `Desktop.drawIcon`. The Dock has: your computer's own game, a **Games** folder (all 8 games on any computer), a **Browser**, **Notes**, **Paint**, **Calculator** and **Settings**.
No redstone or energy needed. Every computer remembers its own high score and who set it.

![preview](docs/preview.png)

| Block | Game | Controls |
|---|---|---|
| `pink_computer` | Flappy Cat | click / Space |
| `green_computer` | Creeper Sweeper (minesweeper) | LMB dig, RMB flag |
| `white_computer` | Panda Snake | WASD / arrows |
| `blue_computer` | Penguin Fishing | mouse (avoid the pufferfish!) |
| `orange_computer` | Fox Memory (pairs) | click |
| `purple_computer` | Ender Dodge | mouse |
| `yellow_computer` | Whack-a-Bee | click the bee |
| `red_computer` | Ladybug Match (match-3, 20 moves) | click two neighbors |

## Desktop apps
| App | What it does |
|---|---|
| CuteStore | the game store: **all games cost coins**. Store tab with a *game of the day* (-30%, changes every day), cover art, ratings and descriptions; buying starts an **install** (a few seconds of real time, it keeps going even if you close the screen). Library tab: your games, play time and best scores. **Reviews**: every game has reviews from other players, and once you own a game you can leave your own stars + text (first review = +3 coins) |
| CuteStore apps | the **Apps** tab of CuteStore has 6 downloadable apps: **Calculator, Paint, Terminal, Tamagotchi and Mail are free**; Music costs 10 coins. Every app has a page with a description, size, rating and 3 to 5 reviews (every game has 3 to 5 reviews too), and you can leave your own review once you own it. Installing takes a few seconds of real time. **An app that is not installed is hidden from the Dock and the Start menu**; opening it any other way shows its store page. *Remove* (click twice) uninstalls an app, ends its process and takes it off the Dock; what you bought stays yours, so installing it again is free. Calculator, Paint, Terminal and Tamagotchi are free because the story quest needs them. Notes, Browser, Settings, Diary, CuteJobs, CuteMarket (it now holds the old Shop too), the Games folder and CuteStore itself are part of the system and cannot be removed. Saves from before the app store keep all their apps installed |
| Sakura Catch, Cute Blocks | two more store games: an anime-style catcher (chibi girl with a parasol, petals, onigiri, storm clouds) and a pastel falling-blocks puzzle |
| Cake Bakery | a cake shop game in CuteStore (50 coins), in the spirit of the old Windows bakery games. A day is 90 seconds. Customers (up to 3) order a cake with a **flavor** (vanilla, chocolate, strawberry) and a **topping** (cherry, sprinkles, candle) and lose patience. Click a bowl (or keys 1-2-3) to put batter in one of 2 ovens, take the cake out when the bar turns green and **before it burns** (about 10 s later; it is ready after 3 s), it goes to a plate; pick a topping (or Q-W-E) and click the cake, then click the cake and the customer. A right cake pays 10 + a tip (up to 5, the faster the more) + a streak bonus (up to 5); a wrong cake wastes the cake and costs the customer 15% of their patience; a customer who runs out of patience takes one of your 5 hearts; no hearts, the bakery closes. Score = cash earned, a par day (120) gives 10 coins |
| Cake Factory | a conveyor-belt cake game in CuteStore (45 coins), in the spirit of the cake factory from the old Windows Purble Place. A shift is 90 seconds. A cake rides the belt through 4 stations: **shape** (round, square, two tiers), **batter** (vanilla, chocolate, strawberry), **icing** (pink, white, blue) and **topping** (cherry, sprinkles, candle). While the cake is lit inside a station, click one of its 3 buttons (or press 1-2-3) to add that part, then match the **order** in the top left corner. A right cake pays 10 + a streak bonus (up to 5) + a speed bonus (up to 5); a wrong or unfinished cake costs one of 3 hearts. The belt gets faster with every cake (up to 2.4x). Score = money earned, a par shift (180) gives 10 coins |
| Durak | a card game for two in CuteStore (45 coins): the classic Russian *Durak* against the computer. 36 cards, trump suit, attack / defend / take / add cards |
| CuteJobs | **10 jobs to earn coins** (shifts of 1 to 1.5 minutes): Typist, Postman, Pet Sitter (rank Intern), Cafe, Courier (Employee), Artist, Game Tester (Senior), and three hard ones with better pay: **Programmer** (Senior, 75 s: find the one different symbol in a growing grid before time runs out, up to 26 coins), **DJ** (Manager, 90 s: a Simon-style game, repeat the growing pad sequence with clicks or keys 1-4, up to 32) and **Pilot** (Manager, 90 s: fly through narrowing gaps with the mouse, faster and faster, up to 36). Shifts give experience and ranks (x1 / x1.15 / x1.3 / x1.5 pay); each job has a 3 minute rest after a shift and any shift also locks every job for 90 seconds (so rotating jobs is no faster); the first 300 coins of pay a day are full, after that a shift pays a quarter; a shift with quality under 20% pays nothing |
| CuteMarket | the online shop (also `cutemarket.cute` in the browser): order **8 foods**, **19 music discs** and real **gear from the game** (pickaxes, axes, shovels, hoes, swords, bows, shields and all armor, wooden to netherite) for coins, put them in a cart, pick *Express* (+30% price, 3x faster) and follow the courier in real time. When a parcel has arrived, collect it and you get the real items. |
| Halloween event | Oct 24 - Nov 3 by the real calendar (or any time with the terminal command `halloween`): sweets, golden sweets and ghosts pop up on the desktop with bats and cobwebs. Click the sweets to collect candy (shown in the menu bar), click the pumpkin lantern in the corner to trade candy for coins (3 trades a day), the *Haunted Pumpkin Night* wallpaper, or the horror games (Something in the Dark, Dark Corridor, Zombie Shooter). Horror games are on sale (-50%) in the store, three letters arrive in the mail and there is an achievement for 50 candy |
| Games | the games you bought and installed (any computer; the record in the block counts only for the computer's own game). Extra games: Cookie Breaker (breakout), Merge Cubes (2048), Slime Pong, Bee Invaders, Something in the Dark (horror: the monster only moves while you're not lighting it), **Dark Corridor** (first-person horror: a random dark maze, find 3 keys and the green door while a pale figure hunts you; WASD/arrows, a map of the places you have been in the corner), **MiniCraft** (a tiny side-view Minecraft: A/D walk, W jump, LMB mine / hit, RMB place, 1-4 hotbar, C planks, E next pickaxe; chop a tree, craft wooden, stone and iron pickaxes, dig for coal, iron and **3 diamonds** while zombies come at night; they chew through trees and dirt but stone and planks stop them), **Zombie Shooter** (first-person wave shooter in the style of Call of Duty Zombies: endless rounds in one arena, 10 points per hit and 60 per kill, health regenerates when you are not hit; WASD walk, mouse near the left/right edge or arrows turn, LMB/Space shoot, R reload, 1/2/Q switch weapon, E at the golden wall to buy a rifle (500) and ammo (250)). The Games folder has 2 pages (arrows or mouse wheel) |
| Browser | the **Cute Web**, a made-up internet (GTA 5 style): `peep.cute` search, `chirp.cute`, `creepermart.cute`, `pandapedia.cute`, `beemail.cute`, `cutenews.cute`, `scarystories.cute` (dark theme, flickering light, watching eyes). Also `cutetube.cute` - **CuteTube**: 6 tiny animated videos with note-block sound, a progress bar and volume slider, likes, ready-made comments and your own (type in the box, Enter sends; space = pause, arrows = skip 5 s). With **Spooky** on, a 7th video appears: "Don't Watch at 3 AM" (eyes in the corner, something in the door, a jump scare, and it says your name at the end). Every page has an animated ad banner at the bottom (click it to visit the advertiser, "x" skips to the next ad). Words in the address bar search it; real addresses like `example.com` open in your system browser after the vanilla "open link?" confirmation |
| Haunting | on its own the computer sometimes shows annoying pop-up ads (the "x" runs away, "bad" buttons spawn more windows) and creepy events: watching eyes, screen glitches, whispers, a fake record held by "The One Behind You", a line that types itself in Notes (never saved), corrupted ads in the browser. Everything is display-only. Settings has switches for **Spooky** and **Pop-ups** |
| Music | player with 4 little songs played on note-block sounds (lead + bass), equalizer, volume. Plays while the app is open |
| Tamagotchi | every computer color has its own pet (cat, creeper, panda, penguin, fox, enderman, bee, ladybug): feed it, play, let it sleep, pet it. Saved on the server (per player), gets hungry slowly even while you are away. **It grows up**: baby (first 20 minutes with it, small, with pink cheeks), teen (up to an hour) and grown-up (full size, sparkles); the name line shows the stage. **It gets a character** from how you treat it (after about 12 actions): Foodie, Playful, Sleepy or Cuddly, which changes what it says. **It writes you letters**: after 5 minutes of being really happy (awake, all bars good) it sends a letter to the Mail app, up to 4 of them, each with a few coins. **It can fall sick**: if it is neglected (food, fun or energy almost empty for 90 seconds) or left alone for 2+ hours it gets sick: sad face, thermometer, no playing, bars drop faster, no letters, and a red banner on top. Only **Medicine** (25 coins, CuteMarket > Home, the red-cross slot next to the treats) cures it, and it does not go away by itself. The first time it is sick the vet leaves one free dose. Medicine is not used up on a healthy pet. **Mini-game "Where is the treat?"** (the *Game* button under the window): the pet hides a treat under one of 3 cups, the cups are shuffled (more and faster swaps each of 3 rounds) and you click the right one. **The Game button now opens a menu of 3 games**: the cups, **Catch the treats** (20 seconds, treats fall and you click them, bad green blobs cost 2; 5 / 11 / 18 caught = 1 / 2 / 3 stars) and **Copy the pet** (like Simon: 4 colored pads, the pet lights them one by one and you repeat the order, up to 5 rounds that get longer; 1 / 3 / 5 rounds = 1 / 2 / 3 stars). Prize: 2 coins per star (per found treat in the cups), +4 for 3 stars; at most 5 prized games a day; each game costs 10 energy, needs an awake and healthy pet, and Esc leaves it. The yellow **Show** button opens the **talent show** (see below): a stage with judges where players and guest pets compete for coins |
| Diary | the story quest (13 chapters in 2 parts: "Strange Stories" and "The Quiet One"), 3 daily tasks with a login streak bonus, and 14 achievements |
| Terminal | command line: `help`, `whoami`, `scan`, `unlock`, `cat`, `ls`, `bee`, `creeper`, `matrix`, `fortune` and more (some are part of the quest: `archive <code>`, `stay` / `bye`) |
| Coins | you get coins for playing games (each game has its own scale: a good result is worth about 10 coins, at most 25 per game and 150 per day from games), pet care, finished videos, achievements, daily tasks and quest chapters. The balance is shown in the taskbar. Everything is saved on the server, per player (UUID) |
| Notes | text editor, saved on the server, per player |
| Paint | 64x36 pixel drawing (LMB draw, RMB erase) |
| Calculator | mouse or keyboard |
| Settings | three tabs. **Wallpapers**: 6 wallpapers (saved on the server, per player). **Sounds**: switches for Sounds / Fan hum / Music and two volume sliders, *System* (clicks, chimes, fan, effects inside games and apps) and *Music* (game tracks and the Music app), saved in `cutemod_sound.txt` on this machine. **Other**: the Spooky and Pop-ups switches and the computer password |

## CuteMarket (real items and home goods)
The app has four tabs: **Goods** (food, discs, gear), **Home**, **Cart** and **Orders**. The **Home** tab is the old Shop app, now part of CuteMarket: 12 wallpapers (6 of them new and animated: Sakura, Aurora, Synthwave, Neon Grid, Winter Forest, Summer Meadow), the paid **Frutiger Aero** desktop theme (120 coins; glossy blue glass menu bar, window title bars and Dock, a sky glow and rising bubbles over the wallpaper; it sits in the **Style** tab with the wallpapers and can be switched back to the classic look at any time; with it come its own **sounds** (water: bubble pops, splashes and glass chimes for start-up, login, lock, shutdown, clicks and errors), glass-clear **icons** (see-through tiles with a bright rim and a gloss), a glossy blue **mouse cursor** instead of the system arrow, and 3 matching wallpapers: **Aero Sky**, **Aqua**, **Glass Swoosh**, 50-60 coins each in the Style tab), 14 pet accessories (the golden crown and the ghost are story rewards; new: ushanka, headphones, devil horns, witch hat, scarf, cape), 4 extra songs for the player and 5 treats (cookie, fish, honey, milk, cake; buy a stock, then click one under the pet's room to feed it). These are bought with coins and used at once: no cart, no courier. The pet has **two clothing slots**: head or face (hats, glasses, horns, headphones...) and neck or body (scarf, cape), so a hat and a scarf can be worn together; each item has its own Wear / Take off button. The Dock icon of CuteMarket shows a red number when a parcel is ready.

Gear: tools (27), weapons (9) and armor (24 pieces) are the game's own items, priced by metal (a wooden pickaxe 12 coins, a diamond one 360, netherite 1040; netherite armor 1040-2080) and delivered slower the better they are (1 to 5 minutes). Every line holds one piece, and a piece counts as 8 items in the daily limit of 48, so the market brings at most 6 pieces of gear a day.
Everything is a real Minecraft item: the 8 foods of the mod (cupcake, ice cream, bubble tea, honey toast, burger, pizza, ramen, sushi, each with hunger and a short effect; they are small **3D models** with a detailed 64x64 texture each (sesame on the bun, grill marks on the patty, rice grains, a pleated paper cup...), built by `tools/food3d.py`, and the game's 19 music discs (12 cheap, 7 rare ones). The shop list lives in one place, `market/Catalog.java`, shared by the app and the server.

An order is kept **on the server**: it checks the items, limits (8 lines, 16 foods or 4 discs per line, 14 parcels, 48 items per day), the delivery time and that you stand near a computer. When a parcel has arrived, press the collect button in CuteMarket (Orders tab) at any computer and the items go to your inventory (or drop at your feet). Coins are still counted by the client; a refused order gives the coins back.

## Game music
Every one of the 21 games has its own short loop (24-32 seconds, seamless): a creaking drone and a slow heartbeat for the horror games, koto and wind for Sakura Catch, lo-fi for Cute Blocks, synthwave for the arcades and so on. The music plays while a game is on screen, fades in and out, gets quieter on *Game over*, and keeps the vanilla music quiet meanwhile. It follows the **Music** slider of Minecraft and the **Music** switch in the computer's Settings (remembered in `cutemod_sound.txt`). The files are `assets/cutemod/sounds/music/<game id>.ogg`, registered in `sounds.json` as `music.<game id>`. They are generated, not recorded: `python3 tools/make_music.py [game ids]` (numpy, scipy, ffmpeg) synthesizes them, and every game is a few lines in its `GAMES` table (tempo, key, scale, chords, layers), so a track is easy to retune. You can also drop your own `.ogg` over any of the files. `GameMusic.java` plays them.

## Crafting
- Pink computer: iron ingots, glass pane, pink dye, redstone (`IGI / IDI / IRI`).
- Any other color: any computer + the matching dye (shapeless).

## Build
Requires Java 21.

```
./gradlew build          # jar in build/libs
./gradlew runClient      # test in game
```
GitHub Actions (`.github/workflows/build.yml`) builds the jar on every push.

## Project layout
- `src/main/java/dev/cutemod` - blocks, block entity (high score), network packet
- `src/main/java/dev/cutemod/client` - the monitor screen, `os/` (desktop and apps) and `game/` (all 8 mini games)
- `src/main/resources/assets/cutemod` - models, blockstates, textures (64x), lang (en, ru)
- `tools/` - Python scripts that generated the colored textures from the original pink pack

## Adding a new app
Extend `App` (`title`, `render`, optionally `tick`/`click`/`key`/`charTyped`) and add an icon in `Desktop`.

## Adding a new game
Extend `MiniGame` (`reset`, `tick` at 60/s, `render`, optionally `click`/`key`) and map it to a color in `GameFactory`.

## License
MIT

## Windows and hotkeys
Every app is a process. The **red** button of a window (or `Ctrl+W`) quits the app and ends its process; the **yellow** one (or `Ctrl+M` / `Ctrl+D`) minimizes it: it keeps running in the background (music goes on playing) and a dim dot under its Dock icon shows it is still alive. Click the icon (or pick it with `Ctrl+Tab`) to bring it back. Right-click a Dock icon for *Quit* and *Remove from Dock*. Leaving the computer ends every process.

| Keys | Action |
|---|---|
| `Ctrl+W` | quit the current app |
| `Ctrl+M`, `Ctrl+D` | minimize to the desktop |
| `Ctrl+Tab`, `Ctrl+Shift+Tab` | switch between running apps |
| `Ctrl+Space` | open / close the Start menu |
| `Ctrl+1` ... `Ctrl+9` | open the 1st ... 9th app of the Dock |
| `Ctrl+L` | lock the screen |
| `Ctrl+Q` | leave the computer |
| `Esc` | close a menu, or leave the computer |

## Desktop widgets
Right-click the empty desktop to open the **Widgets** menu and switch widgets on or off (a right click on a widget removes it too). Left column: a **Player** (shows up while music plays: track, progress, previous / play-pause / next), **Orders** (CuteMarket parcels on their way with the time left, click opens CuteMarket) and a **Timer** (+1, +5 minutes, start / pause, reset; it keeps counting when an app is open and rings with a notice). Right column: the **Calendar** and a **Clock** with a seconds bar. The choice is saved on the server; in the Frutiger Aero theme the widgets are glass.

## CuteNet (online mode)
The **CuteNet** app (Dock icon with two people, also in the Start menu; add it to the Dock with a right click there) has two tabs. **Top players**: pick any of the 21 games and see the 10 best players of the server with gold, silver and bronze marks, your own place and your best score. **Online**: everyone who has a computer screen open right now and what they are doing (playing a game, listening to music...). Every finished game sends its score to the server (`data/cutemod_net.dat`), which keeps one best score per player and game; when someone takes first place from another player, the whole server gets a chat message. The computer sends an "I am here" ping every 3 seconds while its screen is open; the server forgets it after 20 seconds. Scores come from the client, so a modified client could cheat (like the coins); the server only limits the value (up to 10 million), the game name and how often scores can be sent.

## Player mail (stage 1)
Mail now has a **Players** tab: write letters (up to 200 characters) to any player the server has seen, and attach the current Paint drawing (64x36). Everything lives on the server (`data/cutemod_post.dat`).
- Limits: one letter per 15 s, 60 per day, 30 letters per mailbox; blocked senders are refused.
- Reading: reply, delete, block/unblock the sender. Online recipients get an action-bar notice and the Dock badge counts unread player letters.
- Admin: `/cutemail clear <player>` (op level 2) empties a mailbox.
- Coins by mail are not here yet (they need a server-side wallet first). Network protocol version is now "5".

## Balance
Jobs: full pay up to 150 coins a day (was 300), then 20%. Games still give up to 150 a day. Prices of the expensive games went up (MiniCraft 220, Zombie Shooter 180, Dark Corridor 120, Something in the Dark 80, ...); cheap ones are unchanged or +5.
Real gear in CuteMarket: diamond tools/weapons/armor and netherite got more expensive (diamond pickaxe 600, netherite pickaxe 1800, full diamond armor 2880, full netherite armor 8640). Wallpapers, accessories, songs, treats, discs and food are unchanged.

## Admin command: /cutecoins
Needs operator permission level 2.

| Command | What it does |
|---|---|
| `/cutecoins add <player> <amount>` | gives coins |
| `/cutecoins take <player> <amount>` | takes coins (never below 0) |
| `/cutecoins set <player> <amount>` | sets the balance |
| `/cutecoins get <player>` | shows the balance as last saved on the server |

The amount is 0 to 100,000,000. An online player's computer updates at once and shows an "Admin: +N coins" pop-up; a player who is offline (but was seen on the server before) has the saved data edited and sees the new balance on the next login. Coins given this way do not count as "earned" (no achievements). Clients and the server need the same mod version (the network protocol version changes with it; it is "10" since the trophies of the talent show).

## Volume
`Sfx.volSystem` and `Sfx.volMusic` (0 to 100). Computer and game effects go through `Sfx.ui(...)`, the Music app through `Sfx.musicNote(...)`, and `GameMusic` multiplies its fade level by the music volume.

## Talent show (in the Tamagotchi app)
The pet show is now a **talent show** inside the **Tamagotchi** app (the yellow **Show** button under *Game*). The old *Pet show* tab of CuteNet is gone, and the old likes were dropped on purpose (a save from the old show starts empty).

**Rounds.** The show follows the real clock: a round is 6 minutes (`round = time / 6 min`; it used to be 10 minutes, which felt too long), so nothing has to be started and every client sees the same moment.
| Phase | Time | What happens |
|---|---|---|
| Doors open | 0:00 - 3:00 | put your pet on the stage (*Enter the show*, *Refresh look*, *Leave*); click another player's pet to like it, click again to take the like back |
| Judging | 3:00 - 5:00 | the doors are shut; the four judges show their stars one by one (at 3:15, 3:45, 4:15 and 4:45) and chat about your pet; likes still count |
| Results | 5:00 - 6:00 | a podium with confetti, your place and your prize; the next round starts at 6:00 |

**The clock.** A big clock sits on the top left of the stage (minutes and seconds until the phase ends, it blinks red in the last 10 seconds of the open doors) and the name of the phase on the top right. A bar under them shows the whole round in three colors (open / judging / results) with a marker.

**Themes.** Every round has a theme (a pure function of the round number, never the same twice in a row): *Sweet & cute*, *Spooky night*, *Royal ball*, *Cozy winter*, *Rock star* and *Garden party*. It is shown on a gold plate under the clock (point at it to see what the judges like) and one of the judges announces it when the doors open. A pet that fits the theme gets up to +1.2 stars from every judge (`ShowJudges.themeBonus`: for example bows and flowers for *Sweet & cute*, ghost, horns and witch hat for *Spooky night*, crown and cape for *Royal ball*, ushanka and scarf for *Cozy winter*, headphones, glasses and cap for *Rock star*, flower and hat for *Garden party*; some characters and growth stages help too). A naked pet gets no bonus, so clothes still matter most.

**Scoring.** `score = stars of the 4 judges (4 to 20) + likes`. Every judge has a taste: **Mei** (panda) loves cute things (young pets, bows, flowers), **Boom** (creeper) loves style (hats and capes), **Void** (enderman) loves mystery (ghost, horns, witch hat, sleepy grown-ups) and **Honey** (bee) loves effort (age, headphones, caps, party hats). A pet in clothes scores much better than a naked baby (a naked baby never wins against dressed pets). Ties: more likes, then who came first, players before guests. The stars are a pure function of the round and the pet (`data/ShowJudges.java`), so they never have to be saved.

**The judges talk** like the animals of a cozy village: a speech box with a name tag, text that types itself letter by letter and soft blips in the voice of every judge (Mei a high sweet "pii", Boom a little hiss and a round "bwoo", Void a deep quiet "mmoo", Honey a bright buzzy "bzi"). These are the mod's own sounds, not Minecraft's: 8 short syllables per judge (`sounds/voice/<judge>_<0..7>.ogg`, event `voice.<judge>`), made by `python3 tools/make_voices.py` (numpy, scipy, ffmpeg); the letter decides how high each syllable is. They announce the theme, say when the judging starts, comment on **your** pet right after they show their stars (or on the best pet if you are not on the stage; the words depend on how many stars they gave), announce the winner and say goodbye. Between the big moments they chat now and then; click a judge for a quip (click while one is talking to skip).

**Music.** A bouncy show tune (`sounds/music/show.ogg`, made by `tools/make_music.py show`, a seamless 31 s loop) plays while the stage is on screen. It follows the *Music* switch in Settings and the Minecraft music slider like the game music.

**Guests.** If fewer than 4 players are on the stage, **guest pets** (named like Mochi, Biscuit, Pixel...) fill it up to 4, so the stage is never empty. They are made from the round number, get cheers from an imaginary crowd while the doors are open, can win a place, but **never take coins** and cannot be liked.

**Prizes** (paid once, at the start of the results, by the server): 1st place 12 coins, 2nd 8, 3rd 5, everybody else who took part 2. A player can get at most **60 coins a day** from the show. Players who are offline get the coins in their saved data. The winner is announced in the chat. Only players can win coins: a guest on the podium pushes the places down, so a lone player who loses to the guests gets only the 2 coins for taking part.

**Rules on the server** (`ShowBoard`, no Minecraft code, so it can be tested alone): one pet per player (8 players per stage at most); a sick pet is not shown; the color, stage, character, age and what the pet wears are checked against white lists; the pet itself is sent by the client and cannot be verified (like the CuteNet scores). Limits: a pet can be put on the stage every 10 s, likes every 0.4 s, a refresh of the stage every 0.5 s.

**The screen** (`client/os/PetStage.java`, pure drawing): a theatre stage with red curtains, a marquee sign with chasing bulbs, two sweeping spotlights, footlights, four judges at their desk who jump and hold up a score card when they speak, hearts that float up from a pet when it gets a like, a podium (gold, silver, bronze) with confetti and a winner banner. Point at a pet to see its owner, kind, character and the stars of every judge.

**Network** (protocol version `"10"`): `ShowPutPayload` (put / refresh), `ShowActionPayload` (leave, like, unlike), `ShowRequestPayload` (empty: "send me the stage"), `ShowSyncPayload` (phase, time left, how many judges have spoken, the theme of the round, your place and prize, **your cups and the hall of fame**, every pet with its stars and the gold cups of its owner) and `ShowPrizePayload` (coins for an online player). Data: `data/cutemod_show.dat` (`ShowData`: the pets of the round, the last paid round, the daily prize totals, the cups of every player and the hall of fame).

**Trophies and the Hall of Fame** (no coins, only pride; `ShowBoard.medals`, `hall`, `titleLevel`). The server counts a **cup for every place on the podium**: gold (1st), silver (2nd) and bronze (3rd), and how many rounds a player took part in (a guest in front pushes you down, like with the prizes). Everything is saved in `cutemod_show.dat`.
- **Shelf in the Tamagotchi room:** the cups the player won stand on a small shelf above the pet, with a count (`x3`). The shelf asks the server when the app opens; a pop-up *Gold / Silver / Bronze cup of the show!* comes when a round pays you a podium place.
- **Titles:** from the gold cups: 1 *Winner*, 3 *Star of the Stage*, 6 *Crowd Favorite*, 10 *Stage Legend*. The title is shown in the status line of the Tamagotchi app and as a gold line (with a star) when you point at someone's pet on the stage.
- **Hall of Fame:** the gold **Hall** button on the left wall of the stage opens a panel with your cups, your title, the progress to the laurels and the **last 10 winners** (pet color, name, stars, how long ago; a guest can be there too, marked *(guest)*; your own name is gold). Any click or Esc closes it.
- **Champion laurels:** at **10 gold cups** the server tells the client and the laurel wreath (*acc_champion*, a head item with a golden star) is added to the player's wardrobe for good. It cannot be bought; in CuteMarket > Home its button says *Show reward*. The judges like it like a crown (*Royal ball* theme and the style judge); it is in the white list of the stage.
- **Pet wardrobe (41 outfits):** every outfit lives in one list, `data/PetWear.java` (slot, price, set, source, which judge likes it, which show themes it fits); the shop, the stage, the server check and the judges all read it. Two slots as before: head (27) and body (14). New: chef hat, pirate hat, bunny ears, cat ears, beret, straw hat, mushroom cap, pumpkin head, Santa hat, space helmet, bandana, nightcap, knight helmet; hoodie, winter sweater, tutu, tuxedo, pajamas, Hawaiian shirt, chef apron, fairy wings, kimono, pirate coat, knight armor, space suit.
  - **Sets:** a head item and a body item of the same set (chef hat + apron, pirate hat + coat, space helmet + suit, straw hat + Hawaiian shirt, Santa hat + sweater, top hat + tuxedo, bunny ears + tutu, nightcap + pajamas, bandana + hoodie, flower + wings, knight helmet + armor, cat ears + kimono, pumpkin + cape) give **+0.5 stars from every judge**. The shop shows the set under the name.
  - **How to get them:** most are bought in CuteMarket > Home > Pet. **Seasonal** (bought for good, on sale only for a while, by the real date): pumpkin head 1 Oct - 7 Nov, Santa hat 1 Dec - 10 Jan. **Rewards:** space helmet at 15 pet games and space suit at 30 (counter `pet_games`), bandana at 3 perfect pet games (`pet_perfect`), nightcap at 2 cured pets (`pet_cured`), knight helmet at 3 gold cups and knight armor at 6 gold cups of the talent show (the laurels stay at 10). Rewards are given by `Progress.checkAch` and `Show.apply`; the shop shows how to earn a locked one.
  - **Judges:** the old items keep their tastes in `ShowJudges`. The new items have taste tags (Mei cute, Boom style, Void mystery, Honey fun; +0.6 for a liked hat, +0.4 for a liked body item) and theme tags.
  - **Themes of the rounds are now 10:** the six old ones plus **beach party, space trip, pirate adventure and cooking show**. Outfits that fit the theme add to the old theme bonus (the sum is still capped at +1.2). `ShowJudges.themeOf` now deals the themes in shuffled blocks: every theme once per 10 rounds and never the same twice in a row (the old code could repeat a theme).
  - **Shop icons** of the outfits are drawn by `PetArt.icon` (the outfit on a cream blob), so a new outfit needs only its drawing in `PetArt.accessoryOne`, a line in `PetWear` and its names in the lang files.

**Letters of the judges** (`Mail.showLetter`). When the results of a round you took part in come, one judge writes to your Mail (once per round, from the sender *Talent show*): the judge who gave your pet the **most stars** (the first one on a tie) writes a short line in their own voice (three moods by stars: 1-2, 3, 4-5), then the total points, your place and the theme of the night, then a **tip from the judge who gave you the fewest stars**, with what that judge likes (Mei: babies, bows, flowers; Boom: hats and capes; Void: ghost, horns, witch hat; Honey: grown-up pets, headphones, caps, party hats). A winner gets a cheer instead of a tip. The inbox keeps the **last 6** such letters (the oldest place is reused) and they carry no coins. All of it is saved with the player's other counters (`sl0_...` to `sl5_...`, `show_n`, `show_lr` = the last round that got a letter).

**The inbox is now in order of arrival** (the minute a letter came is saved in `mn_ID`; older saves keep their old order), so every new letter, from any source, is on top.

**Admin:** `/cuteshow remove <player>` (permission level 2) takes a player's pet off the stage.

**Tuning:** all the numbers (phase lengths, prizes, daily limit, guests) are constants at the top of `ShowBoard`.

## Pet Park (in the Tamagotchi app)
The green **Park** button under *Show* opens a sunny meadow shared by every player of the server. Your pet walks where you click the grass; the pets of the other players (with the clothes they wear, their name and their friendship hearts) walk about in real time. Click another pet and yours goes to it and **plays together**: both pets jump, hearts float up, both get **+15 fun** (and lose 4 energy), and each player gets **2 coins** (at most **20 coins a day** from the park). A pair can play once every 15 seconds. Every play counts for the **friendship** of the two players: 1 play = friends (1 heart), 5 = good friends (+5 coins), 15 = close friends (+10 coins), 40 = best friends (+20 coins); the hearts are shown over the friend's pet. Three emotes (heart, "Hi", "!") appear over your pet for 3 seconds. A sick or sleeping pet cannot go to the park; 16 pets fit in it. The park is not saved (it is who is there right now); the friendship and the daily coin totals are, in `data/cutemod_park.dat`.
Network (protocol "11"): `ParkMovePayload` (where my pet stands, about 6 times a second, doubles as "I am here"; the server forgets a pet after 6 s), `ParkActionPayload` (leave / play with this player), `ParkSyncPayload` (the other pets and what happened to you). The server checks that the two pets are close, the cooldown, the daily limit and the clothes names; the pet itself comes from the client and cannot be verified, like in the show.

## Pet trips (in the Tamagotchi app)
The blue **Trips** button (under *Park*) opens a list of 6 places: **Kindergarten** (any pet, even a baby), **Beach**, **Forest**, **Mountains** (a teen or older), **City** and **Moon** (a grown-up). The pet needs to be awake, healthy and not hungry or tired (food and energy 30+). It leaves for **10 real minutes** (the time runs also while the computer screen is closed) and the room shows the place and a countdown. When the pet is home it sends a **letter with a photo** (a polaroid of the place with your pet in it) to the Mail app, tells what it found and is happier (+30 fun). Every place has 4 finds, common ones come more often, so the **Album** tab fills up slowly (24 finds; the full album pays 100 coins once). The first 5 trips of the day pay 3 to 25 coins (more for the farther places and the rare finds), later ones only bring the finds. One pet can be away at a time; the trip is saved in the progress counters (`trip_*`, `tf_*`, `tr0_` ... `tr5_`), so it needs no new network code (the protocol version did not change).
