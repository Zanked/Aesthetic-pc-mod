package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/**
 * The window of a folder: a light frosted page with a header (the name, click it to rename; a color dot, a "+" and a
 * bin) and a grid of app-style icons. "+" switches the grid to a picker that lists every installed app and game with a
 * check mark on the ones that are in the folder. A click on an icon opens it (the folder closes), a right click takes
 * it out of the folder.
 */
public class FolderApp extends App {
    /** A folder that was just made: its window opens with the name ready to be typed. */
    public static int pendingRename = -1;

    private static final int HDR = 22, COLS = 6, ROWS = 3, PER = COLS * ROWS, CW = 48, CH = 44;
    private static final int GX = (W - COLS * CW) / 2, GY = HDR + 3;
    private static final int INK = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6, DANGER = 0xFFE5484D, GOOD = 0xFF34C759;
    private static final int TRASH_X = W - 22, ADD_X = W - 42, COLOR_X = W - 60, BTN_Y = 4, BTN_H = 14;
    private static final int NAME_X = 6, NAME_W = W - 72, FIELD_Y = 3, FIELD_H = 16;

    private final int id;
    private boolean adding, renaming, fresh, confirm;
    private final StringBuilder buf = new StringBuilder();
    private int page, confirmT, mx = -1, my = -1, blink;

    public FolderApp(int id) {
        this.id = id;
        if (pendingRename == id) { pendingRename = -1; startRename(); }
    }

    public int id() { return id; }

    @Override
    public Component title() { return Component.literal(Folders.name(id)); }

    @Override
    public Component hint() { return Component.translatable(adding ? "cutemod.folder.hint.add" : "cutemod.folder.hint"); }

    @Override
    public void mouse(int x, int y) { mx = x; my = y; }

    @Override
    public void tick() {
        blink++;
        if (confirm && --confirmT <= 0) confirm = false;
    }

    @Override
    public void close() { if (renaming) commitRename(); }

    // ---------- rename ----------
    private void startRename() {
        renaming = true;
        fresh = true;                       // the first key typed replaces the old name
        buf.setLength(0);
        buf.append(Folders.name(id));
    }

    private void commitRename() {
        renaming = false;
        String s = buf.toString().trim();
        if (!s.isEmpty()) Folders.rename(id, s);
    }

    // ---------- helpers ----------
    private List<Integer> view() { return adding ? Items.pickable() : Folders.items(id); }

    private static int pages(int n) { return Math.max(1, (n + PER - 1) / PER); }

    private int doneW() { return font().width(t("cutemod.folder.done")) + 12; }

    private static int dotX(int p, int pages) { return W / 2 - (pages - 1) * 5 + p * 10; }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        int body = shell.color().bodyColor;
        Skin.grad(g, 0, 0, W, H, mix(body, 0xFFFFFF, 0.82f), mix(body, 0xFFFFFF, 0.58f));
        rect(g, 0, 0, W, HDR, 0x80FFFFFF);
        rect(g, 0, HDR - 1, W, 1, 0x22000000);
        header(g, f, mx, my);

        List<Integer> list = view();
        int pages = pages(list.size());
        page = Math.min(page, pages - 1);

        if (list.isEmpty() && !adding) {
            List<FormattedCharSequence> lines = f.split(FormattedText.of(t("cutemod.folder.empty")), W - 90);
            for (int i = 0; i < lines.size(); i++) {
                FormattedCharSequence s = lines.get(i);
                g.drawString(f, s, (W - f.width(s)) / 2, 62 + i * 10, MUTED, false);
            }
            boolean hov = in(mx, my, W / 2 - 45, 100, 90, 18);
            roundRect(g, W / 2 - 45, 100, 90, 18, 6, hov ? 0xFF9A63BE : ACCENT);
            String s = t("cutemod.folder.add");
            g.drawString(f, s, W / 2 - f.width(s) / 2, 105, 0xFFFFFFFF, false);
            return;
        }

        for (int slot = 0; slot < PER; slot++) {
            int idx = page * PER + slot;
            if (idx >= list.size()) break;
            int item = list.get(idx);
            int cx = GX + (slot % COLS) * CW, cy = GY + (slot / COLS) * CH;
            if (in(mx, my, cx, cy, CW, CH)) roundRect(g, cx + 1, cy, CW - 2, CH - 2, 6, 0x24000000);
            Desktop.drawIcon(g, item, cx + 8, cy + 2, body);
            fitText(g, f, Desktop.nameOf(item), cx + CW / 2, cy + 35, CW - 4, INK, true);
            if (adding) check(g, cx + 37, cy + 6, Folders.has(id, item));
        }
        if (pages > 1) {
            for (int p = 0; p < pages; p++) disc(g, dotX(p, pages), H - 6, p == page ? 3 : 2, p == page ? ACCENT : 0x55000000);
        }
    }

    private void header(GuiGraphics g, Font f, int mx, int my) {
        if (adding) {
            g.drawString(f, t("cutemod.folder.add_title"), NAME_X + 4, 7, INK, false);
            int dw = doneW(), dx = W - 6 - dw;
            roundRect(g, dx, BTN_Y, dw, BTN_H, 5, in(mx, my, dx, BTN_Y, dw, BTN_H) ? 0xFF9A63BE : ACCENT);
            String s = t("cutemod.folder.done");
            g.drawString(f, s, dx + (dw - f.width(s)) / 2, BTN_Y + 3, 0xFFFFFFFF, false);
            return;
        }
        boolean overName = in(mx, my, NAME_X, FIELD_Y, NAME_W, FIELD_H);
        if (renaming) {
            roundRect(g, NAME_X, FIELD_Y, NAME_W, FIELD_H, 5, ACCENT);
            roundRect(g, NAME_X + 1, FIELD_Y + 1, NAME_W - 2, FIELD_H - 2, 4, 0xFFFFFFFF);
            String s = f.plainSubstrByWidth(buf.toString(), NAME_W - 14, true);
            g.drawString(f, s, NAME_X + 6, 7, INK, false);
            if ((blink / 30) % 2 == 0 && !fresh) g.fill(NAME_X + 6 + f.width(s), 6, NAME_X + 7 + f.width(s), 16, INK);
            if (fresh) g.fill(NAME_X + 5, 5, NAME_X + 7 + f.width(s), 17, 0x55B57BD6);   // the old name is selected
        } else if (confirm) {
            roundRect(g, NAME_X, FIELD_Y, NAME_W, FIELD_H, 5, 0x33E5484D);
            g.drawString(f, f.plainSubstrByWidth(t("cutemod.folder.confirm"), NAME_W - 12), NAME_X + 6, 7, DANGER, false);
        } else {
            if (overName) roundRect(g, NAME_X, FIELD_Y, NAME_W, FIELD_H, 5, 0x40FFFFFF);
            g.drawString(f, f.plainSubstrByWidth(Folders.name(id), NAME_W - 28), NAME_X + 6, 7, INK, false);
            if (overName) {                                                     // a little pencil
                int px = NAME_X + 8 + f.width(f.plainSubstrByWidth(Folders.name(id), NAME_W - 28)), py = 8;
                g.fill(px + 4, py, px + 6, py + 2, MUTED); g.fill(px + 3, py + 1, px + 5, py + 3, MUTED);
                g.fill(px + 2, py + 2, px + 4, py + 4, MUTED); g.fill(px + 1, py + 3, px + 3, py + 5, MUTED);
                g.fill(px, py + 5, px + 2, py + 6, MUTED);
            }
        }
        // the color dot
        int c = Math.floorMod(Folders.color(id), Folders.PAL.length);
        boolean hc = in(mx, my, COLOR_X, BTN_Y, 14, BTN_H);
        disc(g, COLOR_X + 7, BTN_Y + 7, hc ? 7 : 6, 0xFFFFFFFF);
        disc(g, COLOR_X + 7, BTN_Y + 7, hc ? 5 : 4, Folders.PAL[c][1]);
        // "+"
        boolean ha = in(mx, my, ADD_X, BTN_Y, 16, BTN_H);
        roundRect(g, ADD_X, BTN_Y, 16, BTN_H, 5, ha ? ACCENT : 0xB3FFFFFF);
        int pc = ha ? 0xFFFFFFFF : INK;
        g.fill(ADD_X + 7, BTN_Y + 3, ADD_X + 9, BTN_Y + 11, pc);
        g.fill(ADD_X + 4, BTN_Y + 6, ADD_X + 12, BTN_Y + 8, pc);
        // the bin
        boolean ht = in(mx, my, TRASH_X, BTN_Y, 16, BTN_H);
        roundRect(g, TRASH_X, BTN_Y, 16, BTN_H, 5, confirm ? DANGER : ht ? 0xFFF7B3B6 : 0xB3FFFFFF);
        int tc = confirm ? 0xFFFFFFFF : ht ? DANGER : INK;
        g.fill(TRASH_X + 4, BTN_Y + 3, TRASH_X + 12, BTN_Y + 4, tc);
        g.fill(TRASH_X + 6, BTN_Y + 2, TRASH_X + 10, BTN_Y + 3, tc);
        g.fill(TRASH_X + 5, BTN_Y + 5, TRASH_X + 11, BTN_Y + 12, tc);
        g.fill(TRASH_X + 7, BTN_Y + 6, TRASH_X + 8, BTN_Y + 11, confirm ? DANGER : 0xFFE9E4F0);
        g.fill(TRASH_X + 9, BTN_Y + 6, TRASH_X + 10, BTN_Y + 11, confirm ? DANGER : 0xFFE9E4F0);
    }

    /** The round mark in the corner of an icon in the picker. */
    private static void check(GuiGraphics g, int bx, int by, boolean on) {
        disc(g, bx, by, 6, 0xFFFFFFFF);
        if (!on) { disc(g, bx, by, 5, 0xFFC9C0D8); disc(g, bx, by, 4, 0xFFFFFFFF); return; }
        disc(g, bx, by, 5, GOOD);
        int w = 0xFFFFFFFF;
        g.fill(bx - 3, by, bx - 2, by + 1, w); g.fill(bx - 2, by + 1, bx - 1, by + 2, w);
        g.fill(bx - 1, by + 2, bx, by + 3, w); g.fill(bx, by + 1, bx + 1, by + 2, w);
        g.fill(bx + 1, by, bx + 2, by + 1, w); g.fill(bx + 2, by - 1, bx + 3, by, w);
        g.fill(bx + 3, by - 2, bx + 4, by - 1, w);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (renaming && !in(x, y, NAME_X, FIELD_Y, NAME_W, FIELD_H)) commitRename();
        boolean wasConfirm = confirm;
        confirm = false;

        if (y < HDR) {
            if (adding) {
                if (in(x, y, W - 6 - doneW(), BTN_Y, doneW(), BTN_H)) { adding = false; page = 0; }
                return true;
            }
            if (in(x, y, TRASH_X, BTN_Y, 16, BTN_H)) {
                if (wasConfirm) { Folders.delete(id); shell.home(); }
                else { confirm = true; confirmT = 180; }
                return true;
            }
            if (in(x, y, ADD_X, BTN_Y, 16, BTN_H)) { adding = true; page = 0; return true; }
            if (in(x, y, COLOR_X, BTN_Y, 14, BTN_H)) { Folders.cycleColor(id); return true; }
            if (!renaming && in(x, y, NAME_X, FIELD_Y, NAME_W, FIELD_H)) startRename();
            return true;
        }

        List<Integer> list = view();
        int pages = pages(list.size());
        if (list.isEmpty() && !adding) {
            if (in(x, y, W / 2 - 45, 100, 90, 18)) { adding = true; page = 0; }
            return true;
        }
        if (pages > 1) {
            for (int p = 0; p < pages; p++) if (in(x, y, dotX(p, pages) - 5, H - 11, 10, 10)) { page = p; return true; }
        }
        for (int slot = 0; slot < PER; slot++) {
            int idx = page * PER + slot;
            if (idx >= list.size()) break;
            if (!in(x, y, GX + (slot % COLS) * CW, GY + (slot / COLS) * CH, CW, CH)) continue;
            int item = list.get(idx);
            if (adding) {
                if (button == 0) Folders.toggle(id, item);
            } else if (button == 1) {
                Folders.remove(id, item);                       // out of the folder (the app itself stays installed)
            } else {
                shell.home();                                   // the folder closes, the app opens
                shell.launch(item);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        int pages = pages(view().size());
        if (pages <= 1) return false;
        page = Math.floorMod(page + (amount > 0 ? -1 : 1), pages);
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (renaming) {
            switch (keyCode) {
                case 257, 335 -> commitRename();                                   // Enter
                case 256 -> renaming = false;                                      // Esc: keep the old name
                case 259 -> {                                                      // Backspace
                    if (fresh) { buf.setLength(0); fresh = false; }
                    else if (buf.length() > 0) buf.setLength(buf.length() - 1);
                }
                default -> { }
            }
            return true;
        }
        if (keyCode == 263 || keyCode == 262) return scroll(keyCode == 263 ? 1 : -1);   // Left / Right: another page
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        if (!renaming) return false;
        if (c < 32 || c == 127 || c == '|') return true;
        if (fresh) { buf.setLength(0); fresh = false; }
        if (buf.length() < Folders.MAX_NAME) buf.append(c);
        return true;
    }
}
