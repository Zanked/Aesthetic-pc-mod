package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.client.game.GameFactory;
import dev.cutemod.client.game.MiniGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * CuteJobs: short one-minute shifts that pay coins. Ten jobs, ranks that raise the pay,
 * and a cooldown after each shift so the coins cannot be farmed forever.
 */
public class JobsApp extends App {
    private static final int BG = 0xFF1B1530, ROW_A = 0xFF231B3D, ROW_B = 0xFF1F1736, HOVER = 0xFF352A58;
    private static final int ACCENT = 0xFFB57BD6, GREEN = 0xFF5BD97A, YELLOW = 0xFFFFD866, MUTED = 0xFF9A90B8;
    private static final int WHITE = 0xFFFFFFFF, RED = 0xFFE5484D, BAR = 18;
    private static final int[] JOB_RGB = {0xFF6AA8F0, 0xFFF0B050, 0xFFF58FB8, 0xFFC98B5A, 0xFF5BBF6A, 0xFFB57BD6, 0xFF8EC3F2, 0xFF4ADE80, 0xFFFF6AD5, 0xFF38BDF8};

    private static final int MENU_Y = 20, ROW_P = 13; // job rows in the menu

    private enum Mode { MENU, READY, SHIFT, RESULT }

    private Mode mode = Mode.MENU;
    private String jobId = "";
    private Shift shift;
    private int ready, shiftTick;
    private float resultQuality;
    private int resultPay;
    private boolean rankUp;
    private int noGamesTimer;

    @Override
    public Component title() { return Component.translatable("cutemod.os.jobs"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.jobs"); }

    @Override
    public Component status() {
        if (mode == Mode.SHIFT && shift != null) return Component.literal(shift.status());
        return Component.translatable("cutemod.job.rank." + Jobs.rank());
    }

    @Override
    public void close() { Jobs.save(); }

    // ---------- flow ----------
    private boolean available(Jobs.Job j) {
        if (Jobs.rank() < j.rank() || Jobs.cooldownLeft(j.id()) > 0) return false;
        return !j.id().equals("tester") || !installedGames().isEmpty();
    }

    private static List<String> installedGames() {
        List<String> out = new ArrayList<>();
        for (Library.Game g : Library.GAMES) if (Library.installed(g.id())) out.add(g.id());
        return out;
    }

    private void start(Jobs.Job j) {
        if (!available(j)) {
            if (j.id().equals("tester") && Jobs.rank() >= j.rank() && Jobs.cooldownLeft(j.id()) == 0) noGamesTimer = 180;
            return;
        }
        jobId = j.id();
        shift = switch (jobId) {
            case "typing" -> new Typing();
            case "post" -> new Post();
            case "pets" -> new Pets();
            case "cafe" -> new Cafe();
            case "courier" -> new Courier();
            case "artist" -> new Artist();
            case "coder" -> new Coder();
            case "dj" -> new Dj();
            case "pilot" -> new Pilot();
            default -> new Tester();
        };
        mode = Mode.READY;
        ready = 150;
    }

    private void finish() {
        float q = Math.max(0f, Math.min(1f, shift.quality()));
        resultQuality = q;
        resultPay = Jobs.payout(jobId, q);
        rankUp = Jobs.finish(jobId, q);
        if (resultPay > 0) Progress.earn(resultPay);
        mode = Mode.RESULT;
    }

    @Override
    public void tick() {
        if (noGamesTimer > 0) noGamesTimer--;
        if (mode == Mode.READY) {
            if (--ready <= 0) { mode = Mode.SHIFT; shiftTick = 0; }
        } else if (mode == Mode.SHIFT && shift != null) {
            shift.tick();
            shiftTick++;
            if (shiftTick >= shift.duration() || shift.over()) finish();
        }
    }

    @Override
    public void mouse(int x, int y) {
        if (shift instanceof Tester tt) tt.mouse(x, y);
        else if (shift instanceof Pilot pl) pl.mouse(x, y);
    }

    // ---------- drawing helpers ----------
    private static void txt(GuiGraphics g, String s, int x, int y, int argb) { Skin.str(g, font(), s, x, y, argb, false); }

    private static void ctxt(GuiGraphics g, String s, int cx, int y, int argb) {
        Skin.str(g, font(), s, cx - font().width(s) / 2, y, argb, false);
    }

    private static void big(GuiGraphics g, String s, int cx, int y, int argb, float scale) {
        g.pose().pushPose();
        g.pose().translate(cx - font().width(s) * scale / 2f, y, 0);
        g.pose().scale(scale, scale, 1f);
        Skin.str(g, font(), s, 0, 0, argb, false);
        g.pose().popPose();
    }

    private static void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean enabled, boolean hover, int color) {
        Skin.rect(g, x, y, w, h, !enabled ? 0xFF3A2F5A : hover ? mix(color & 0xFFFFFF, 0xFFFFFF, 0.25f) : color);
        ctxt(g, label, x + w / 2, y + (h - 8) / 2, enabled ? 0xFF1B1530 : MUTED);
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Skin.rect(g, 0, 0, W, H, BG);
        switch (mode) {
            case MENU -> renderMenu(g, mx, my);
            case READY -> {
                Skin.rect(g, 0, 0, W, BAR, 0xFF2A2040);
                txt(g, t("cutemod.job.name." + jobId), 8, 5, WHITE);
                ctxt(g, t("cutemod.job.ready"), W / 2, 44, YELLOW);
                big(g, Integer.toString(ready / 50 + 1), W / 2, 62, WHITE, 3f);
                String how = t("cutemod.job.how." + jobId);
                var lines = font().split(net.minecraft.network.chat.FormattedText.of(how), 260);
                for (int i = 0; i < lines.size() && i < 3; i++) {
                    Skin.str(g, font(), lines.get(i), (W - font().width(lines.get(i))) / 2, 108 + i * 11, 0xFFD8D0EE, false);
                }
            }
            case SHIFT -> {
                Skin.rect(g, 0, 0, W, BAR, 0xFF2A2040);
                txt(g, t("cutemod.job.name." + jobId), 8, 5, WHITE);
                int left = Math.max(0, (shift.duration() - shiftTick + 59) / 60);
                String tm = t("cutemod.job.time", left);
                txt(g, tm, W - 8 - font().width(tm), 5, left <= 10 ? RED : YELLOW);
                int bw = (int) ((W - 120) * (1f - shiftTick / (float) shift.duration()));
                Skin.rect(g, 110, 7, W - 120, 4, 0xFF3A2F5A);
                Skin.rect(g, 110, 7, Math.max(0, bw), 4, left <= 10 ? RED : GREEN);
                shift.render(g, mx, my);
            }
            case RESULT -> renderResult(g, mx, my);
        }
    }

    private void renderMenu(GuiGraphics g, int mx, int my) {
        int rank = Jobs.rank();
        Skin.rect(g, 0, 0, W, BAR, 0xFF2A2040);
        txt(g, t("cutemod.job.rank." + rank) + "  x" + trim(Jobs.RANK_MULT[rank]), 8, 5, YELLOW);
        if (rank + 1 < Jobs.RANK_XP.length) {
            int from = Jobs.RANK_XP[rank], to = Jobs.RANK_XP[rank + 1];
            float f = (Jobs.xp() - from) / (float) (to - from);
            Skin.rect(g, 150, 7, 100, 4, 0xFF3A2F5A);
            Skin.rect(g, 150, 7, Math.round(100 * Math.max(0f, Math.min(1f, f))), 4, ACCENT);
            txt(g, Jobs.xp() + "/" + to, 256, 5, MUTED);
        } else {
            txt(g, t("cutemod.job.maxrank"), 150, 5, GREEN);
        }
        for (int i = 0; i < Jobs.LIST.size(); i++) {
            Jobs.Job j = Jobs.LIST.get(i);
            int y = MENU_Y + i * ROW_P;
            boolean hov = in(mx, my, 0, y, W, ROW_P - 1);
            boolean ok = available(j);
            Skin.rect(g, 0, y, W, ROW_P - 1, hov && ok ? HOVER : (i % 2 == 0 ? ROW_A : ROW_B));
            Skin.rect(g, 4, y + 2, 8, 8, JOB_RGB[i]);
            txt(g, t("cutemod.job.name." + j.id()), 18, y + 2, WHITE);
            int pay = Math.round(j.maxPay() * Jobs.multiplier());
            txt(g, t("cutemod.job.upto", pay), 120, y + 2, MUTED);
            String right;
            int rc;
            if (Jobs.rank() < j.rank()) { right = t("cutemod.job.locked", t("cutemod.job.rank." + j.rank())); rc = RED; }
            else if (Jobs.cooldownLeft(j.id()) > 0) { right = t("cutemod.job.cooldown", Jobs.cooldownLeft(j.id())); rc = MUTED; }
            else if (!ok) { right = t("cutemod.job.nogames"); rc = RED; }
            else { right = t("cutemod.job.start"); rc = GREEN; }
            txt(g, right, W - 6 - font().width(right), y + 2, rc);
        }
        String foot = noGamesTimer > 0 ? t("cutemod.job.nogames_hint") : t("cutemod.job.footer", Jobs.COOLDOWN_SEC, Jobs.totalShifts());
        ctxt(g, foot, W / 2, 154, noGamesTimer > 0 ? RED : MUTED);
    }

    private static String trim(float f) { return f == Math.floor(f) ? Integer.toString((int) f) : Float.toString(f); }

    private void renderResult(GuiGraphics g, int mx, int my) {
        Skin.rect(g, 0, 0, W, BAR, 0xFF2A2040);
        txt(g, t("cutemod.job.name." + jobId), 8, 5, WHITE);
        ctxt(g, t("cutemod.job.done"), W / 2, 30, YELLOW);
        ctxt(g, t("cutemod.job.quality", Math.round(resultQuality * 100)), W / 2, 50, WHITE);
        Progress.drawCoin(g, W / 2 - 30, 68);
        big(g, "+" + resultPay, W / 2 + 6, 68, resultPay > 0 ? YELLOW : MUTED, 2f);
        if (Jobs.overCap()) ctxt(g, t("cutemod.job.tired"), W / 2, 88, MUTED);
        if (rankUp) ctxt(g, t("cutemod.job.rankup", t("cutemod.job.rank." + Jobs.rank())), W / 2, 100, GREEN);
        ctxt(g, t("cutemod.job.cooldown_note", Jobs.COOLDOWN_SEC), W / 2, 114, MUTED);
        boolean hov = in(mx, my, 100, 132, 100, 18);
        button(g, 100, 132, 100, 18, t("cutemod.job.back"), true, hov, ACCENT);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int b) {
        switch (mode) {
            case MENU -> {
                for (int i = 0; i < Jobs.LIST.size(); i++) {
                    if (in(x, y, 0, MENU_Y + i * ROW_P, W, ROW_P - 1)) { start(Jobs.LIST.get(i)); return true; }
                }
                return true;
            }
            case RESULT -> {
                if (in(x, y, 100, 132, 100, 18)) { mode = Mode.MENU; shift = null; }
                return true;
            }
            case SHIFT -> { return shift != null && shift.click(x, y); }
            default -> { return true; }
        }
    }

    @Override
    public boolean drag(int x, int y, int b) {
        return mode == Mode.SHIFT && shift != null && shift.drag(x, y);
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (mode == Mode.RESULT && (keyCode == 257 || keyCode == 32)) { mode = Mode.MENU; shift = null; return true; }
        if (mode == Mode.SHIFT && shift != null) return shift.key(keyCode);
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        return mode == Mode.SHIFT && shift != null && shift.typed(c);
    }

    // ======================================================================
    //                               the shifts
    // ======================================================================
    private abstract class Shift {
        final Random rnd = new Random();
        abstract int duration();
        void tick() {}
        abstract void render(GuiGraphics g, int mx, int my);
        boolean click(int x, int y) { return false; }
        boolean drag(int x, int y) { return false; }
        boolean key(int k) { return false; }
        boolean typed(char c) { return false; }
        boolean over() { return false; }
        abstract float quality();
        abstract String status();
    }

    // ---------- typist: words fall from the sky, type them before they land ----------
    private final class Typing extends Shift {
        private static final String[][] WORDS = {
                {"cat", "fox", "bee", "pig", "cow", "owl", "egg", "ice", "map", "sun", "bed", "cup", "hat", "jar", "key", "toy"},
                {"panda", "honey", "pixel", "cloud", "music", "apple", "kitten", "button", "screen", "garden", "castle", "rocket",
                        "puzzle", "sunset", "meadow", "pillow", "candle", "forest", "bamboo", "cookie"},
                {"creeper", "penguin", "diamond", "pickaxe", "ladybug", "lantern", "wizard", "blossom", "rainbow", "pancake",
                        "mushroom", "firework", "treasure", "bluebird"}};
        private static final int TOP = 21, GROUND = 138;

        private static final class Word {
            String s;
            float x, y;
            int pos, pop;          // pop > 0: the word is bursting
            boolean gold;
        }

        private final List<Word> words = new ArrayList<>();
        private Word target;
        private int spawnT = 25, spawned, done, miss, errors, flash, groundFlash, combo;
        private float points;

        @Override int duration() { return 3600; }

        /** Words get longer and faster the more of them you have popped; every eighth one is golden (counts double). */
        private void spawn() {
            int tier = spawned < 5 ? 0 : spawned < 14 ? 1 : 2;
            String s = null;
            for (int tries = 0; tries < 12; tries++) {
                int grp = tier == 0 ? (rnd.nextInt(10) < 7 ? 0 : 1)
                        : tier == 1 ? (rnd.nextInt(10) < 7 ? 1 : (rnd.nextBoolean() ? 0 : 2))
                        : (rnd.nextInt(10) < 6 ? 2 : 1);
                String c = WORDS[grp][rnd.nextInt(WORDS[grp].length)];
                boolean clash = false;
                for (Word w : words) if (w.s.equals(c) || w.s.charAt(0) == c.charAt(0)) clash = true; // one first letter per word on screen
                s = c;
                if (!clash) break;
            }
            Word w = new Word();
            w.s = s;
            w.gold = spawned % 8 == 7;
            int ww = font().width(s) + 8;
            w.x = 6 + rnd.nextInt(Math.max(1, W - 12 - ww));
            w.y = TOP;
            words.add(w);
            spawned++;
        }

        @Override void tick() {
            if (flash > 0) flash--;
            if (groundFlash > 0) groundFlash--;
            if (--spawnT <= 0) { spawn(); spawnT = Math.max(66, 150 - spawned * 3); }
            float speed = Math.min(0.5f, 0.22f + spawned * 0.0065f);
            for (int i = words.size() - 1; i >= 0; i--) {
                Word w = words.get(i);
                if (w.pop > 0) { if (--w.pop <= 0) words.remove(i); continue; }
                w.y += speed * (w.gold ? 1.25f : 1f);
                if (w.y >= GROUND - 10) {                    // it landed
                    miss++;
                    combo = 0;
                    groundFlash = 14;
                    if (w == target) target = null;
                    words.remove(i);
                }
            }
        }

        @Override boolean typed(char c) {
            char ch = Character.toLowerCase(c);
            if (!Character.isLetter(ch)) return false;
            if (target == null) {                            // the first letter picks the lowest word that starts with it
                Word best = null;
                for (Word w : words) if (w.pop == 0 && w.s.charAt(0) == ch && (best == null || w.y > best.y)) best = w;
                if (best == null) { errors++; flash = 8; combo = 0; return true; }
                target = best;
                target.pos = 0;
            }
            if (target.s.charAt(target.pos) == ch) {
                if (++target.pos >= target.s.length()) {
                    target.pop = 14;
                    done += target.gold ? 2 : 1;
                    combo++;
                    points += (target.gold ? 2f : 1f) + (combo >= 5 ? 0.25f : 0f);
                    target = null;
                }
            } else {
                errors++;
                flash = 8;
                combo = 0;
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Skin.rect(g, 0, BAR, W, GROUND - BAR, flash > 0 ? 0xFF2A1830 : 0xFF16102A);
            for (int i = 0; i < 12; i++) Skin.rect(g, (i * 53 + 17) % (W - 4), BAR + 4 + (i * 29) % 100, 1, 1, 0x66FFFFFF);
            Skin.rect(g, 0, GROUND, W, H - GROUND, groundFlash > 0 ? 0xFF6A2A3A : 0xFF2A4A3A);
            Skin.rect(g, 0, GROUND, W, 2, groundFlash > 0 ? 0xFFE5484D : 0xFF5BBF6A);
            for (Word w : words) {
                int ww = font().width(w.s) + 8, x = Math.round(w.x), y = Math.round(w.y);
                if (w.pop > 0) {                             // a little burst
                    double r = (14 - w.pop) * 1.7;
                    for (int k = 0; k < 8; k++) {
                        int px = x + ww / 2 + (int) Math.round(Math.cos(k * Math.PI / 4) * r), py = y + 5 + (int) Math.round(Math.sin(k * Math.PI / 4) * r);
                        Skin.rect(g, px, py, 2, 2, w.gold ? YELLOW : GREEN);
                    }
                    continue;
                }
                boolean tgt = w == target;
                Skin.rect(g, x - 1, y - 1, ww + 2, 12, w.gold ? YELLOW : tgt ? ACCENT : 0xFF4A3F6A);
                Skin.rect(g, x, y, ww, 10, w.gold ? 0xFF6A5410 : tgt ? 0xFF4A3F7A : 0xFF2A2040);
                String a = w.s.substring(0, w.pos), b = w.s.substring(w.pos);
                Skin.str(g, font(), a, x + 4, y + 1, GREEN, false);
                Skin.str(g, font(), b, x + 4 + font().width(a), y + 1, w.gold ? YELLOW : WHITE, false);
            }
            String hud = t("cutemod.job.typed", done) + (combo >= 3 ? "   " + t("cutemod.job.combo", combo) : "");
            ctxt(g, hud, W / 2, GROUND + 6, combo >= 5 ? YELLOW : MUTED);
        }

        @Override float quality() { return Math.max(0f, points - miss - errors * 0.1f) / 28f; }
        @Override String status() { return t("cutemod.job.typed", done); }
    }

    // ---------- postman: sort the letters on the belt, the boxes move around ----------
    private final class Post extends Shift {
        private static final int BELT_Y = 48, BOX_Y = 120, LEFT = 30, FLY = 14;
        private final int[] cols = {RED, 0xFF2F7FD6, 0xFF5BBF6A, 0xFFF3D46A};   // one color per town
        private final int[] slot = {0, 1, 2, 3};                                  // box position -> town

        private static final class Letter {
            float x;
            int town, fly = -1, flyTo;                                            // fly >= 0: on its way into a box
            boolean express;
        }

        private final List<Letter> belt = new ArrayList<>();
        private int ok, miss, flash, moved, sorted, age;

        @Override int duration() { return 3600; }

        private void spawn() {
            Letter l = new Letter();
            l.x = W + 8;
            l.town = rnd.nextInt(4);
            l.express = ok >= 5 && rnd.nextInt(8) == 0;                           // gold letters: double points, faster
            belt.add(l);
        }

        /** Every 8 sorted letters the boxes change places: what your fingers learned is wrong again. */
        private void shuffleBoxes() {
            int[] old = slot.clone();
            do {
                for (int i = 3; i > 0; i--) {
                    int j = rnd.nextInt(i + 1), t0 = slot[i];
                    slot[i] = slot[j];
                    slot[j] = t0;
                }
            } while (java.util.Arrays.equals(old, slot));
            moved = 100;
        }

        private void sort(int s) {
            Letter l = null;
            for (Letter c : belt) if (c.fly < 0) { l = c; break; }               // the front letter (the leftmost)
            if (l == null) return;
            if (slot[s] == l.town) {
                ok += l.express ? 2 : 1;
                sorted++;
                flash = 8;
                l.fly = FLY;
                l.flyTo = s;
                if (sorted % 8 == 0) shuffleBoxes();
            } else {
                miss++;
                flash = -8;
                belt.remove(l);                                                    // sent back
            }
        }

        @Override void tick() {
            age++;
            if (flash > 0) flash--; else if (flash < 0) flash++;
            if (moved > 0) moved--;
            float v = 0.55f + Math.min(0.9f, ok * 0.015f);
            Letter last = null;
            for (Letter l : belt) if (l.fly < 0) last = l;
            if (last == null || last.x < W - 66) spawn();
            for (int i = belt.size() - 1; i >= 0; i--) {
                Letter l = belt.get(i);
                if (l.fly >= 0) { if (--l.fly <= 0) belt.remove(i); continue; }
                l.x -= v * (l.express ? 1.5f : 1f);
                if (l.x < LEFT - 14) { miss++; flash = -8; belt.remove(i); }       // fell off the end of the belt
            }
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 4; i++) if (in(x, y, 6 + i * 72, BOX_Y, 66, 38)) { sort(i); return true; }
            return true;
        }

        @Override boolean key(int k) {
            if (k >= 49 && k <= 52) { sort(k - 49); return true; }
            return false;
        }

        private void envelope(GuiGraphics g, int x, int y, boolean express, int stamp) {
            Skin.rect(g, x, y, 30, 18, express ? 0xFFFFD866 : 0xFFFFF6E0);
            Skin.rect(g, x, y, 30, 2, express ? 0xFFE0B040 : 0xFFE0D0A8);
            Skin.rect(g, x + 20, y + 4, 7, 7, stamp);
            Skin.rect(g, x + 3, y + 7, 12, 1, 0xFF9A8A70);
            Skin.rect(g, x + 3, y + 10, 9, 1, 0xFF9A8A70);
            if (express) Skin.rect(g, x, y + 14, 30, 4, RED);
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            // the conveyor belt
            Skin.rect(g, 0, BELT_Y - 14, W, 42, 0xFF2A2638);
            Skin.rect(g, 0, BELT_Y - 14, W, 2, 0xFF4A4660);
            Skin.rect(g, 0, BELT_Y + 26, W, 2, 0xFF4A4660);
            for (int x = -(age % 12); x < W; x += 12) Skin.rect(g, x, BELT_Y + 22, 6, 2, 0xFF3A3650);
            boolean first = true;
            for (Letter l : belt) {
                int x, y;
                if (l.fly >= 0) {                                                  // flying into its box
                    float p = 1f - l.fly / (float) FLY;
                    int bx = 6 + l.flyTo * 72 + 18;
                    x = Math.round(l.x + (bx - l.x) * p);
                    y = Math.round(BELT_Y + (BOX_Y + 6 - BELT_Y) * p);
                } else {
                    x = Math.round(l.x);
                    y = BELT_Y;
                }
                envelope(g, x, y, l.express, cols[l.town]);
                if (l.fly < 0) {
                    ctxt(g, t("cutemod.job.town." + l.town), x + 15, y + 20, WHITE);   // the address
                    if (first) {                                                        // an arrow over the letter to sort now
                        Skin.rect(g, x + 11, y - 8, 9, 1, YELLOW);
                        Skin.rect(g, x + 12, y - 7, 7, 1, YELLOW);
                        Skin.rect(g, x + 13, y - 6, 5, 1, YELLOW);
                        Skin.rect(g, x + 14, y - 5, 3, 1, YELLOW);
                        first = false;
                    }
                }
            }
            if (moved > 0 && (moved / 8) % 2 == 0) ctxt(g, t("cutemod.job.moved"), W / 2, 92, YELLOW);
            ctxt(g, t("cutemod.job.delivered", ok), W / 2, 106, MUTED);
            for (int i = 0; i < 4; i++) {                                           // the four mailboxes
                int x = 6 + i * 72, town = slot[i];
                boolean hov = in(mx, my, x, BOX_Y, 66, 38);
                int body = hov ? mix(cols[town] & 0xFFFFFF, 0xFFFFFF, 0.25f) : cols[town];
                Skin.rect(g, x + 6, BOX_Y + 8, 54, 28, body);
                Skin.rect(g, x + 10, BOX_Y + 4, 46, 6, mix(cols[town] & 0xFFFFFF, 0xFFFFFF, 0.2f));
                Skin.rect(g, x + 58, BOX_Y, 2, 12, RED);
                Skin.rect(g, x + 14, BOX_Y + 15, 38, 3, 0x55000000);
                ctxt(g, t("cutemod.job.town." + town), x + 33, BOX_Y + 21, 0xFF1B1530);
                ctxt(g, Integer.toString(i + 1), x + 33, BOX_Y + 28, 0xFF1B1530);
            }
            if (flash != 0) Skin.rect(g, 0, BAR, W, 2, flash > 0 ? GREEN : RED);
        }

        @Override float quality() { return Math.max(0f, ok - miss) / 30f; }
        @Override String status() { return t("cutemod.job.delivered", ok); }
    }

    // ---------- barista: named drinks, a menu to learn and a queue of customers ----------
    private final class Cafe extends Shift {
        private final int[] cols = {0xFFFFFFFF, 0xFF8A5A3A, 0xFFF3E6D0, 0xFFF3D46A, 0xFFF58FB8};
        /** The recipes of the five drinks: the ingredients in order (0 cup, 1 coffee, 2 milk, 3 honey, 4 berry). */
        private static final int[][] RECIPES = {{0, 1, 2}, {0, 1, 2, 3}, {0, 2, 4}, {0, 4, 4, 3}, {0, 1, 4, 2}};
        private static final int[] SKIN = {0xFFFFE0CC, 0xFFF3C9A8, 0xFFD9A57E, 0xFFFFE9D6};
        private static final int[] HAIR = {0xFF3A2A3A, 0xFFB8651B, 0xFFF3D46A, 0xFFF58FB8};
        private final List<int[]> queue = new ArrayList<>();   // a customer: {drink, patience, max patience, look}
        private int prog, served, miss, flash, nextT = 20;
        private float points;

        @Override int duration() { return 3600; }

        /** The menu grows while you work: 3 drinks at first, all 5 after a few customers. */
        private int unlocked() { return served < 2 ? 3 : served < 5 ? 4 : 5; }

        @Override void tick() {
            if (flash > 0) flash--;
            if (queue.size() < 3 && --nextT <= 0) {
                int drink = rnd.nextInt(unlocked());
                int max = Math.max(260, 440 - served * 8) + 55 * RECIPES[drink].length;
                queue.add(new int[]{drink, max, max, rnd.nextInt(4)});
                nextT = Math.max(60, 170 - served * 6);
            }
            for (int i = queue.size() - 1; i >= 0; i--) {   // everyone in the queue gets impatient, not only the first one
                int[] c = queue.get(i);
                if (--c[1] <= 0) {
                    miss++;
                    flash = 12;
                    queue.remove(i);
                    if (i == 0) prog = 0;
                }
            }
        }

        private void press(int i) {
            if (queue.isEmpty()) return;
            int[] c = queue.get(0);
            int[] r = RECIPES[c[0]];
            if (i == r[prog]) {
                if (++prog >= r.length) {
                    points += c[1] > c[2] / 2 ? 1.5f : 1f;   // quick service is worth more
                    served++;
                    queue.remove(0);
                    prog = 0;
                }
            } else {                                          // wrong ingredient: pour it out, the customer waits longer
                prog = 0;
                flash = 12;
                c[1] -= 30;
            }
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 5; i++) if (in(x, y, 6 + i * 58, 128, 54, 30)) { press(i); return true; }
            return true;
        }

        @Override boolean key(int k) {
            if (k >= 49 && k <= 53) { press(k - 49); return true; }
            return false;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            // the menu on the left: the recipe of every drink in colors (you learn them while you work)
            Skin.rect(g, 4, 22, 108, 100, 0xFF2A2040);
            ctxt(g, t("cutemod.job.menu"), 58, 25, YELLOW);
            for (int i = 0; i < 5; i++) {
                int y = 37 + i * 17;
                boolean open = i < unlocked();
                Skin.rect(g, 6, y - 2, 104, 15, open ? 0xFF352A58 : 0xFF241C3C);
                txt(g, font().plainSubstrByWidth(t("cutemod.job.drink." + i), 56), 9, y + 1, open ? WHITE : 0xFF5A5078);
                if (open) for (int k = 0; k < RECIPES[i].length; k++) Skin.rect(g, 68 + k * 10, y + 1, 8, 8, cols[RECIPES[i][k]]);
            }
            // the queue of customers
            for (int i = 0; i < 3; i++) {
                int x = 118 + i * 59;
                if (i >= queue.size()) { Skin.rect(g, x, 24, 55, 38, 0xFF231B3D); continue; }
                int[] c = queue.get(i);
                float f = Math.max(0f, c[1] / (float) c[2]);
                Skin.rect(g, x - 1, 23, 57, 40, i == 0 ? ACCENT : 0xFF3A2F5A);
                Skin.rect(g, x, 24, 55, 38, f < 0.3f ? 0xFF4A2A3A : 0xFF2A2040);
                Skin.disc(g, x + 12, 37, 7, SKIN[c[3]]);
                Skin.rect(g, x + 5, 29, 14, 4, HAIR[c[3]]);
                Skin.rect(g, x + 9, 37, 1, 2, 0xFF3A2A3A);
                Skin.rect(g, x + 14, 37, 1, 2, 0xFF3A2A3A);
                Skin.rect(g, x + 10, f < 0.3f ? 42 : 41, 5, 1, 0xFF3A2A3A);
                txt(g, font().plainSubstrByWidth(t("cutemod.job.drink." + c[0]), 50), x + 3, 47, WHITE);
                Skin.rect(g, x + 3, 56, 49, 4, 0xFF3A2F5A);
                Skin.rect(g, x + 3, 56, Math.round(49 * Math.min(1f, f)), 4, f > 0.5f ? GREEN : f > 0.25f ? YELLOW : RED);
            }
            // the drink you are making now
            Skin.rect(g, 118, 68, 176, 54, flash > 0 ? 0xFF4A2A3A : 0xFF231B3D);
            if (queue.isEmpty()) {
                ctxt(g, "...", 206, 90, MUTED);
            } else {
                int[] r = RECIPES[queue.get(0)[0]];
                big(g, t("cutemod.job.drink." + queue.get(0)[0]), 206, 72, YELLOW, 1.5f);
                int total = r.length * 40 - 4, x0 = 206 - total / 2;
                for (int k = 0; k < r.length; k++) {
                    int x = x0 + k * 40;
                    boolean done = k < prog;
                    if (k == prog) Skin.rect(g, x - 2, 93, 40, 24, WHITE);
                    Skin.rect(g, x, 95, 36, 20, done ? 0xFF6A6A7A : cols[r[k]]);
                    ctxt(g, done ? "OK" : Integer.toString(r[k] + 1), x + 18, 101, 0xFF3A2A3A);
                }
            }
            ctxt(g, t("cutemod.job.served", served), 206, 112, MUTED);
            for (int i = 0; i < 5; i++) {
                int x = 6 + i * 58;
                boolean hov = in(mx, my, x, 128, 54, 30);
                Skin.rect(g, x, 128, 54, 30, hov ? 0xFF4A3A70 : 0xFF3A2F5A);
                Skin.rect(g, x + 4, 132, 46, 8, cols[i]);
                ctxt(g, (i + 1) + " " + t("cutemod.job.ing." + i), x + 27, 146, WHITE);
            }
        }

        @Override float quality() { return Math.max(0f, points - miss * 0.7f) / 16f; }
        @Override String status() { return t("cutemod.job.served", served); }
    }

    // ---------- courier ----------
    private final class Courier extends Shift {
        private static final int COLS = 15, ROWS = 7, CELL = 20, OY = 22;
        private final boolean[][] wall = new boolean[COLS][ROWS];
        private final int[] carX = {3, 11};
        private final int[] carRow = {2, 4};
        private int px = 1, py = 3, tx, ty, delivered, stun, carTick;
        private boolean carrying;

        Courier() {
            for (int n = 0; n < 16; n++) {
                int x = rnd.nextInt(COLS), y = rnd.nextInt(ROWS);
                if (y == 2 || y == 4 || (x == 1 && y == 3)) continue;
                wall[x][y] = true;
            }
            spot();
        }

        @Override int duration() { return 3600; }

        private void spot() {
            for (int tries = 0; tries < 60; tries++) {
                int x = rnd.nextInt(COLS), y = rnd.nextInt(ROWS);
                if (wall[x][y] || y == 2 || y == 4 || (x == px && y == py)) continue;
                if (Math.abs(x - px) + Math.abs(y - py) < 5) continue;
                tx = x;
                ty = y;
                return;
            }
            tx = COLS - 2;
            ty = 0;
            wall[tx][ty] = false;
        }

        @Override void tick() {
            if (stun > 0) stun--;
            if (++carTick >= 15) {
                carTick = 0;
                for (int i = 0; i < 2; i++) carX[i] = (carX[i] + (i == 0 ? 1 : COLS - 1)) % COLS;
            }
            hitCheck();
        }

        private void hitCheck() {
            for (int i = 0; i < 2; i++) {
                if (stun == 0 && py == carRow[i] && px == carX[i]) stun = 100;
            }
        }

        @Override boolean key(int k) {
            if (stun > 0) return true;
            int dx = 0, dy = 0;
            switch (k) {
                case 262, 68 -> dx = 1;
                case 263, 65 -> dx = -1;
                case 264, 83 -> dy = 1;
                case 265, 87 -> dy = -1;
                default -> { return false; }
            }
            int nx = px + dx, ny = py + dy;
            if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS || wall[nx][ny]) return true;
            px = nx;
            py = ny;
            hitCheck();
            if (px == tx && py == ty) {
                if (!carrying) { carrying = true; tx = -1; ty = -1; spotDrop(); }
                else { delivered++; carrying = false; spot(); }
            }
            return true;
        }

        /** Chooses the house after a parcel was picked up. */
        private void spotDrop() { spot(); }

        @Override void render(GuiGraphics g, int mx, int my) {
            for (int x = 0; x < COLS; x++) {
                for (int y = 0; y < ROWS; y++) {
                    int c = (y == 2 || y == 4) ? 0xFF4A4A5A : ((x + y) % 2 == 0 ? 0xFF4F9A58 : 0xFF58A862);
                    Skin.rect(g, x * CELL, OY + y * CELL, CELL, CELL, c);
                    if (y == 2 || y == 4) Skin.rect(g, x * CELL + 4, OY + y * CELL + 9, 12, 2, 0xFFE0D8A0);
                    if (wall[x][y]) {
                        Skin.rect(g, x * CELL + 8, OY + y * CELL + 12, 4, 7, 0xFF6A4A2A);
                        Skin.disc(g, x * CELL + 10, OY + y * CELL + 8, 7, 0xFF2F7A3A);
                    }
                }
            }
            // goal: a parcel (to pick up) or a house (to deliver to)
            int gx = tx * CELL, gy = OY + ty * CELL;
            if (tx >= 0) {
                if (!carrying) {
                    Skin.rect(g, gx + 3, gy + 5, 14, 12, YELLOW);
                    Skin.rect(g, gx + 9, gy + 5, 2, 12, 0xFFB98A10);
                } else {
                    Skin.rect(g, gx + 3, gy + 8, 14, 10, 0xFFF3E6D0);
                    Skin.rect(g, gx + 1, gy + 4, 18, 5, RED);
                    Skin.rect(g, gx + 8, gy + 12, 4, 6, 0xFF8A5A3A);
                }
            }
            for (int i = 0; i < 2; i++) {
                int cx = carX[i] * CELL, cy = OY + carRow[i] * CELL;
                Skin.rect(g, cx + 1, cy + 4, 18, 12, i == 0 ? 0xFFE5484D : 0xFF2F7FD6);
                Skin.rect(g, cx + 5, cy + 6, 6, 4, 0xFFBFE6F8);
            }
            int ppx = px * CELL, ppy = OY + py * CELL;
            boolean blink = stun > 0 && (stun / 6) % 2 == 0;
            if (!blink) {
                Skin.disc(g, ppx + 10, ppy + 10, 7, 0xFFFFF3B0);
                Skin.rect(g, ppx + 7, ppy + 8, 2, 2, 0xFF3A2A3A);
                Skin.rect(g, ppx + 11, ppy + 8, 2, 2, 0xFF3A2A3A);
                if (carrying) Skin.rect(g, ppx + 5, ppy - 3, 10, 6, YELLOW);
            }
        }

        @Override float quality() { return delivered / 10f; }
        @Override String status() { return t("cutemod.job.delivered", delivered); }
    }

    // ---------- artist ----------
    private final class Artist extends Shift {
        private static final int GW = 8, GH = 6, CELL = 14;
        private final int[] pal = {0xFFFFFFFF, RED, 0xFF2F7FD6, 0xFFF3D46A, 0xFF5BBF6A};
        private final int[] target = new int[GW * GH], canvas = new int[GW * GH];
        private int sel = 1, sent;
        private float total;

        Artist() { gen(); }

        @Override int duration() { return 3600; }

        private void gen() {
            java.util.Arrays.fill(target, 0);
            java.util.Arrays.fill(canvas, 0);
            for (int n = 0; n < 4; n++) {
                int c = 1 + rnd.nextInt(4), w = 2 + rnd.nextInt(3), h = 2 + rnd.nextInt(3);
                int x0 = rnd.nextInt(GW - w + 1), y0 = rnd.nextInt(GH - h + 1);
                for (int x = x0; x < x0 + w; x++) for (int y = y0; y < y0 + h; y++) target[y * GW + x] = c;
            }
        }

        private boolean paint(int x, int y) {
            int cx = (x - 174) / CELL, cy = (y - 30) / CELL;
            if (x >= 174 && y >= 30 && cx < GW && cy < GH) { canvas[cy * GW + cx] = sel; return true; }
            return false;
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 5; i++) if (in(x, y, 14 + i * 30, 124, 26, 18)) { sel = i; return true; }
            if (in(x, y, 196, 124, 96, 18)) {
                int ok = 0;
                for (int i = 0; i < target.length; i++) if (target[i] == canvas[i]) ok++;
                float acc = ok / (float) target.length;
                total += acc * acc;
                sent++;
                gen();
                return true;
            }
            paint(x, y);
            return true;
        }

        @Override boolean drag(int x, int y) { return paint(x, y); }

        @Override void render(GuiGraphics g, int mx, int my) {
            ctxt(g, t("cutemod.job.target"), 14 + GW * CELL / 2, 20, MUTED);
            ctxt(g, t("cutemod.job.canvas"), 174 + GW * CELL / 2, 20, MUTED);
            for (int x = 0; x < GW; x++) {
                for (int y = 0; y < GH; y++) {
                    Skin.rect(g, 14 + x * CELL, 30 + y * CELL, CELL - 1, CELL - 1, pal[target[y * GW + x]]);
                    Skin.rect(g, 174 + x * CELL, 30 + y * CELL, CELL - 1, CELL - 1, pal[canvas[y * GW + x]]);
                }
            }
            ctxt(g, "->", 150, 66, MUTED);
            for (int i = 0; i < 5; i++) {
                int x = 14 + i * 30;
                if (i == sel) Skin.rect(g, x - 2, 122, 30, 22, WHITE);
                Skin.rect(g, x, 124, 26, 18, pal[i]);
            }
            boolean hov = in(mx, my, 196, 124, 96, 18);
            button(g, 196, 124, 96, 18, t("cutemod.job.send"), true, hov, GREEN);
            ctxt(g, t("cutemod.job.sent", sent), W / 2, 150, MUTED);
        }

        @Override float quality() { return Math.min(1f, total / 3.3f); }
        @Override String status() { return t("cutemod.job.sent", sent); }
    }

    // ---------- pet sitter ----------
    private final class Pets extends Shift {
        private final int[] pcol = {0xFFF5B06B, 0xFFB98A60, 0xFFF4F0F0};
        private final int[] ncol = {0xFFE59A6A, 0xFF5BBF6A, 0xFF6AA8F0};
        private final int[] need = {-1, -1, -1}, timer = new int[3], wait = {20, 60, 100};
        private int sel = -1, served, miss, wrong;

        @Override int duration() { return 3600; }

        @Override void tick() {
            for (int i = 0; i < 3; i++) {
                if (need[i] < 0) {
                    if (--wait[i] <= 0) { need[i] = rnd.nextInt(3); timer[i] = 240; }
                } else if (--timer[i] <= 0) {
                    miss++;
                    need[i] = -1;
                    wait[i] = 25 + rnd.nextInt(40);
                    if (sel == i) sel = -1;
                }
            }
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 3; i++) if (in(x, y, 50 + i * 100 - 36, 34, 72, 76)) { sel = i; return true; }
            for (int j = 0; j < 3; j++) {
                if (in(x, y, 14 + j * 94, 124, 86, 28)) {
                    if (sel >= 0 && need[sel] >= 0) {
                        if (need[sel] == j) {
                            served++;
                            need[sel] = -1;
                            wait[sel] = 25 + rnd.nextInt(40);
                            sel = -1;
                        } else wrong++;
                    }
                    return true;
                }
            }
            return true;
        }

        @Override boolean key(int k) {
            if (k >= 49 && k <= 51) return click(14 + (k - 49) * 94 + 1, 125);
            return false;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            for (int i = 0; i < 3; i++) {
                int cx = 50 + i * 100;
                if (i == sel) Skin.rect(g, cx - 36, 34, 72, 76, 0xFF352A58);
                Skin.disc(g, cx - 10, 62, 5, pcol[i]);
                Skin.disc(g, cx + 10, 62, 5, pcol[i]);
                Skin.disc(g, cx, 78, 15, pcol[i]);
                Skin.rect(g, cx - 6, 76, 2, 3, 0xFF3A2A3A);
                Skin.rect(g, cx + 4, 76, 2, 3, 0xFF3A2A3A);
                Skin.rect(g, cx - 2, 82, 4, 2, 0xFF3A2A3A);
                if (need[i] >= 0) {
                    Skin.disc(g, cx, 44, 9, ncol[need[i]]);
                    ctxt(g, Integer.toString(need[i] + 1), cx, 41, 0xFF1B1530);
                    float f = Math.max(0f, timer[i] / 240f);
                    Skin.rect(g, cx - 24, 100, 48, 4, 0xFF3A2F5A);
                    Skin.rect(g, cx - 24, 100, Math.round(48 * f), 4, f > 0.35f ? GREEN : RED);
                }
            }
            for (int j = 0; j < 3; j++) {
                int x = 14 + j * 94;
                boolean hov = in(mx, my, x, 124, 86, 28);
                Skin.rect(g, x, 124, 86, 28, hov ? 0xFF4A3A70 : 0xFF3A2F5A);
                Skin.rect(g, x + 4, 128, 78, 4, ncol[j]);
                ctxt(g, (j + 1) + " " + t("cutemod.job.need." + j), x + 43, 138, WHITE);
            }
            ctxt(g, t("cutemod.job.cared", served), W / 2, 112, MUTED);
        }

        @Override float quality() { return Math.max(0f, served - miss * 0.6f - wrong * 0.4f) / 18f; }
        @Override String status() { return t("cutemod.job.cared", served); }
    }

    // ---------- programmer: find the odd symbol ----------
    private final class Coder extends Shift {
        private static final String[][] PAIRS = {{"0", "O"}, {"1", "l"}, {"5", "S"}, {"8", "B"}, {"c", "e"},
                {"n", "h"}, {"{", "("}, {"=", "-"}, {"u", "v"}, {"q", "g"}};
        private static final int GX = 10, GY = 34, GW = W - 20;
        private int cols, rows, oddX, oddY, ok, miss, late, timer, maxTimer, flash;
        private String base, odd;

        Coder() { newGrid(); }

        @Override int duration() { return 4500; }

        /** Every find makes the grid bigger and the time shorter. */
        private void newGrid() {
            cols = Math.min(10, 4 + ok / 2);
            rows = Math.min(6, 3 + ok / 3);
            String[] p = PAIRS[rnd.nextInt(PAIRS.length)];
            boolean swap = rnd.nextBoolean();
            base = swap ? p[0] : p[1];
            odd = swap ? p[1] : p[0];
            oddX = rnd.nextInt(cols);
            oddY = rnd.nextInt(rows);
            maxTimer = Math.max(150, 330 - ok * 12);
            timer = maxTimer;
        }

        private int cw() { return GW / cols; }
        private int ch() { return Math.min(24, 118 / rows); }

        @Override void tick() {
            if (flash > 0) flash--; else if (flash < 0) flash++;
            if (--timer <= 0) { late++; flash = -10; newGrid(); }
        }

        @Override boolean click(int x, int y) {
            int cx = (x - GX) / cw(), cy = (y - GY) / ch();
            if (x < GX || y < GY || cx >= cols || cy >= rows) return true;
            if (cx == oddX && cy == oddY) { ok++; flash = 8; newGrid(); }
            else { miss++; flash = -8; }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            float f = Math.max(0f, timer / (float) maxTimer);
            Skin.rect(g, GX, 24, GW, 5, 0xFF3A2F5A);
            Skin.rect(g, GX, 24, Math.round(GW * Math.min(1f, f)), 5, f > 0.35f ? GREEN : RED);
            Skin.rect(g, GX - 2, GY - 2, cols * cw() + 4, rows * ch() + 4, flash > 0 ? 0xFF2A4A3A : flash < 0 ? 0xFF4A2A3A : 0xFF2A2040);
            for (int cy = 0; cy < rows; cy++) {
                for (int cx = 0; cx < cols; cx++) {
                    int x = GX + cx * cw(), y = GY + cy * ch();
                    if (in(mx, my, x, y, cw(), ch())) Skin.rect(g, x, y, cw(), ch(), HOVER);
                    String sym = cx == oddX && cy == oddY ? odd : base;
                    big(g, sym, x + cw() / 2, y + (ch() - 12) / 2, 0xFFD8D0EE, 1.5f);
                }
            }
        }

        @Override float quality() { return Math.max(0f, ok - miss * 0.5f - late * 0.5f) / 13f; }
        @Override String status() { return t("cutemod.job.bugs", ok); }
    }

    // ---------- DJ: repeat the growing sequence ----------
    private final class Dj extends Shift {
        private final int[] cols = {RED, 0xFF2F7FD6, 0xFF5BBF6A, 0xFFF3D46A};
        private final List<Integer> seq = new ArrayList<>();
        private int phase, idx, timer, lit = -1, inputIdx, pressed = -1, pressT, rounds, err, flash;

        Dj() { seq.add(rnd.nextInt(4)); seq.add(rnd.nextInt(4)); startShow(); }

        @Override int duration() { return 5400; }

        /** 0: short pause, 1: the pads light up, 2: your turn. A mistake replays the same sequence. */
        private void startShow() { phase = 0; timer = 40; idx = 0; lit = -1; inputIdx = 0; }

        private int onTicks() { return Math.max(13, 24 - rounds); }

        @Override void tick() {
            if (flash > 0) flash--; else if (flash < 0) flash++;
            if (pressT > 0 && --pressT == 0) pressed = -1;
            if (phase == 0) {
                if (--timer <= 0) { phase = 1; idx = 0; timer = onTicks(); lit = seq.get(0); }
            } else if (phase == 1) {
                if (--timer <= 0) {
                    if (lit >= 0) { lit = -1; timer = 8; }
                    else if (++idx >= seq.size()) { phase = 2; inputIdx = 0; }
                    else { lit = seq.get(idx); timer = onTicks(); }
                }
            }
        }

        private void press(int i) {
            if (phase != 2) return;
            pressed = i;
            pressT = 8;
            if (i == seq.get(inputIdx)) {
                if (++inputIdx >= seq.size()) { rounds++; seq.add(rnd.nextInt(4)); flash = 8; startShow(); }
            } else {
                err++;
                flash = -12;
                startShow();
            }
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 4; i++) if (in(x, y, 6 + i * 72, 62, 66, 60)) { press(i); return true; }
            return true;
        }

        @Override boolean key(int k) {
            if (k >= 49 && k <= 52) { press(k - 49); return true; }
            return false;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            ctxt(g, t("cutemod.job.dj_len", seq.size()), W / 2, 28, YELLOW);
            ctxt(g, t(phase == 2 ? "cutemod.job.dj_turn" : "cutemod.job.dj_watch"), W / 2, 42, phase == 2 ? GREEN : MUTED);
            for (int i = 0; i < 4; i++) {
                int x = 6 + i * 72;
                boolean on = (phase == 1 && lit == i) || pressed == i;
                boolean hov = phase == 2 && in(mx, my, x, 62, 66, 60);
                int c = on ? mix(cols[i] & 0xFFFFFF, 0xFFFFFF, 0.55f) : hov ? mix(cols[i] & 0xFFFFFF, 0xFFFFFF, 0.2f) : mix(cols[i] & 0xFFFFFF, 0x000000, 0.35f);
                Skin.rect(g, x, 62, 66, 60, c);
                if (on) Skin.rect(g, x - 2, 60, 70, 64, 0x33FFFFFF);
                ctxt(g, Integer.toString(i + 1), x + 33, 86, on ? 0xFF1B1530 : 0xFFD8D0EE);
            }
            if (flash != 0) Skin.rect(g, 0, BAR, W, 2, flash > 0 ? GREEN : RED);
            ctxt(g, t("cutemod.job.dj_stat", rounds, err), W / 2, 134, MUTED);
        }

        @Override float quality() { return Math.max(0f, rounds - err * 0.5f) / 7f; }
        @Override String status() { return t("cutemod.job.dj_len", seq.size()); }
    }

    // ---------- pilot: fly through the gaps ----------
    private final class Pilot extends Shift {
        private static final int TOP = 22, BOT = H - 2, SX = 44, WALL_W = 14;
        private float shipY = (TOP + BOT) / 2f, targetY = shipY, lastCenter = (TOP + BOT) / 2f;
        private final List<float[]> walls = new ArrayList<>(); // x, gap top, gap height, 0 open / 1 passed / 2 hit
        private int passed, hits, stun;

        @Override int duration() { return 5400; }

        void mouse(int x, int y) { targetY = Math.max(TOP + 6, Math.min(BOT - 6, y)); }

        @Override void tick() {
            if (stun > 0) stun--;
            float v = Math.min(2.8f, 1.8f + passed * 0.012f);          // faster the longer you fly
            float d = targetY - shipY;
            shipY += Math.max(-2.6f, Math.min(2.6f, d));               // the ship follows the mouse, but not instantly
            if (walls.isEmpty() || walls.get(walls.size() - 1)[0] < W - 110) {
                float gh = Math.max(40f, 56f - passed * 0.25f);         // and the gaps get narrower
                float c = lastCenter + (rnd.nextFloat() - 0.5f) * 120f;
                c = Math.max(TOP + gh / 2 + 4, Math.min(BOT - gh / 2 - 4, c));
                lastCenter = c;
                walls.add(new float[]{W, c - gh / 2, gh, 0});
            }
            for (float[] w : walls) {
                w[0] -= v;
                boolean overlap = SX + 8 > w[0] && SX - 8 < w[0] + WALL_W;
                if (overlap && stun == 0 && (shipY - 5 < w[1] || shipY + 5 > w[1] + w[2])) { hits++; stun = 60; w[3] = 2; }
                if (w[3] == 0 && w[0] + WALL_W < SX - 8) { w[3] = 1; passed++; }
            }
            walls.removeIf(w -> w[0] + WALL_W < -4);
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Skin.rect(g, 0, BAR, W, H - BAR, 0xFF0F1A3A);
            for (int i = 0; i < 14; i++) Skin.rect(g, ((i * 61 - shiftTick * (1 + i % 3)) % W + W) % W, 30 + (i * 37) % 120, 1, 1, 0x88FFFFFF);
            for (float[] w : walls) {
                int x = Math.round(w[0]), top = Math.round(w[1]), gh = Math.round(w[2]);
                Skin.rect(g, x, BAR, WALL_W, top - BAR, 0xFF6A5AA8);
                Skin.rect(g, x, top + gh, WALL_W, H - top - gh, 0xFF6A5AA8);
                Skin.rect(g, x - 2, top - 3, WALL_W + 4, 3, 0xFF8A7AC8);
                Skin.rect(g, x - 2, top + gh, WALL_W + 4, 3, 0xFF8A7AC8);
            }
            int sy = Math.round(shipY);
            if (!(stun > 0 && (stun / 5) % 2 == 0)) {
                Skin.rect(g, SX - 9, sy - 4, 16, 8, 0xFFE8E8F8);
                Skin.rect(g, SX + 5, sy - 2, 5, 4, 0xFFF58FB8);
                Skin.rect(g, SX - 3, sy - 3, 5, 3, 0xFF38BDF8);
                Skin.rect(g, SX - 12, sy - 3 + (shiftTick / 4) % 2, 3, 2, 0xFFFFC832);
            }
            txt(g, t("cutemod.job.pilot_stat", passed, hits), 6, 22, 0xFFD8D0EE);
        }

        @Override float quality() { return Math.max(0f, passed - hits * 3f) / 70f; }
        @Override String status() { return t("cutemod.job.pilot_stat", passed, hits); }
    }

    // ---------- game tester ----------
    private final class Tester extends Shift {
        private static final int OX = (W - MiniGame.W) / 2, OY = 22;
        private final String gameId;
        private final MiniGame game;
        private int endDelay;

        Tester() {
            List<String> ids = installedGames();
            gameId = ids.get(rnd.nextInt(ids.size()));
            ComputerColor c = null;
            for (ComputerColor cc : ComputerColor.values()) if (cc.id.equals(gameId)) c = cc;
            game = c != null ? GameFactory.create(c) : GameFactory.createExtra(gameId);
            game.reset();
        }

        void mouse(int x, int y) { game.setMouse(x - OX, y - OY); }

        @Override int duration() { return 3600; }

        @Override void tick() {
            if (!game.over) game.tick(); else endDelay++;
        }

        @Override boolean over() { return game.over && endDelay > 90; }

        @Override void render(GuiGraphics g, int mx, int my) {
            Skin.rect(g, OX - 2, OY - 2, MiniGame.W + 4, MiniGame.H + 4, 0xFF3A2A4A);
            g.enableScissor(shell.absX() + OX, shell.absY() + OY, shell.absX() + OX + MiniGame.W, shell.absY() + OY + MiniGame.H);
            g.pose().pushPose();
            g.pose().translate(OX, OY, 0);
            game.render(g);
            g.pose().popPose();
            g.disableScissor();
        }

        @Override boolean click(int x, int y) {
            if (game.over) return true;
            int lx = x - OX, ly = y - OY;
            if (in(lx, ly, 0, 0, MiniGame.W, MiniGame.H)) game.click(lx, ly, 0);
            return true;
        }

        @Override boolean key(int k) { return !game.over && game.key(k); }

        @Override float quality() { return Progress.coinsFor(gameId, game.score) / 16f; }
        @Override String status() { return t("cutemod.job.testing", Library.name(gameId)) + "  " + game.score; }
    }
}
