"""
Adds the missing symbols to the pixel font of the computer (cute.png, cute_bold.png and the 6 font json files).
Before this the quotes of the texts (the guillemets), the long dash, @ > < | # $ ^ ~ [ ] ; & x : degree, squares and a few more (the bullet of a password and the arrows too)
were not in the font and fell back to the game font, which looked different in the middle of a line.
The glyphs are 5 x 7 pixels like the rest (the cap height is rows 0-6, the baseline is under row 6); the bold font is the same
glyph smeared one pixel to the right (exactly how the existing bold letters are made).
Run it from the project folder:  python3 tools/extend_cute_font.py   (safe to run again: it does nothing when the rows are there)
"""
import json, os
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'main', 'resources', 'assets', 'cutemod')
CELL_W, CELL_H, COLS = 8, 9, 16

# each glyph: the rows from the top (row 0 = top of a capital letter), '#' is a pixel
G = {
    '\u00ab': {2: '..#.#', 3: '.#.#.', 4: '#.#..', 5: '.#.#.', 6: '..#.#'},
    '\u00bb': {2: '#.#..', 3: '.#.#.', 4: '..#.#', 5: '.#.#.', 6: '#.#..'},
    '\u2014': {4: '#####'},
    '\u2013': {4: '####'},
    '\u2212': {4: '####'},
    '@': {0: '.###.', 1: '#...#', 2: '#.###', 3: '#.#.#', 4: '#.###', 5: '#....', 6: '.####'},
    '>': {2: '#...', 3: '.#..', 4: '..#.', 5: '.#..', 6: '#...'},
    '<': {2: '..#.', 3: '.#..', 4: '#...', 5: '.#..', 6: '..#.'},
    '|': {i: '#' for i in range(9)},
    '#': {0: '.#.#.', 1: '.#.#.', 2: '#####', 3: '.#.#.', 4: '#####', 5: '.#.#.', 6: '.#.#.'},
    '$': {0: '..#..', 1: '.####', 2: '#.#..', 3: '.###.', 4: '..#.#', 5: '####.', 6: '..#..'},
    '^': {0: '..#..', 1: '.#.#.', 2: '#...#'},
    '~': {3: '.#..#', 4: '#.##.'},
    '[': {0: '##', 1: '#.', 2: '#.', 3: '#.', 4: '#.', 5: '#.', 6: '##'},
    ']': {0: '##', 1: '.#', 2: '.#', 3: '.#', 4: '.#', 5: '.#', 6: '##'},
    ';': {3: '.#', 5: '.#', 6: '.#', 7: '#.'},
    '&': {0: '.##..', 1: '#..#.', 2: '#..#.', 3: '.##..', 4: '#.#.#', 5: '#..##', 6: '.##.#'},
    '\u00d7': {3: '#.#', 4: '.#.', 5: '#.#'},
    '\u00f7': {2: '.#.', 4: '###', 6: '.#.'},
    '\u00b0': {0: '.#.', 1: '#.#', 2: '.#.'},
    '\u00b2': {0: '##.', 1: '..#', 2: '.#.', 3: '#..', 4: '###'},
    '\u00b3': {0: '##.', 1: '..#', 2: '.#.', 3: '..#', 4: '##.'},
    '\u2075': {0: '###', 1: '#..', 2: '##.', 3: '..#', 4: '##.'},
    '\u2082': {4: '##.', 5: '..#', 6: '.#.', 7: '#..', 8: '###'},
    '\u00b7': {4: '#'},
    '\u2026': {6: '#.#.#'},
    '\u2116': {0: '#...#..', 1: '##..#.#', 2: '#.#.#.#', 3: '#.#.#.#', 4: '#..##..', 5: '#...#..', 6: '#...#..'},
    '\u2605': {1: '..#..', 2: '#####', 3: '.###.', 4: '.#.#.', 5: '#...#'},
    '\u2022': {3: '.#.', 4: '###', 5: '.#.'},                                   # the dots of a password
    '\u2190': {3: '..#..', 4: '#####', 5: '..#..'},
    '\u2192': {3: '..#..', 4: '#####', 5: '..#..'},
    '\u2191': {1: '..#..', 2: '.###.', 3: '#.#.#', 4: '..#..', 5: '..#..', 6: '..#..'},
    '\u2193': {1: '..#..', 2: '..#..', 3: '..#..', 4: '#.#.#', 5: '.###.', 6: '..#..'},
}
# the arrows left and right need the head on the correct side
G['\u2190'] = {2: '.#...', 3: '##...', 4: '#####', 5: '##...', 6: '.#...'}
G['\u2192'] = {2: '...#.', 3: '...##', 4: '#####', 5: '...##', 6: '...#.'}
# the numero sign has a small "o" on the right: rows 0-2 of columns 6-7 above would clash, so it is drawn as N + ^o
G['\u2116'] = {0: '#...#.##', 1: '##..#.##', 2: '#.#.#...', 3: '#.#.#...', 4: '#..##...', 5: '#...#...', 6: '#...#...'}

ORDER = ['\u00ab', '\u00bb', '\u2014', '\u2013', '\u2212', '@', '>', '<', '|', '#', '$', '^', '~', '[', ']', ';',
         '&', '\u00d7', '\u00f7', '\u00b0', '\u00b2', '\u00b3', '\u2075', '\u2082', '\u00b7', '\u2026', '\u2116', '\u2605',
         '\u2022', '\u2190', '\u2192', '\u2191', '\u2193']
ROWS_NEW = 3


def paint(img, col, row, rows, bold):
    for y, line in rows.items():
        for x, c in enumerate(line):
            if c != '#':
                continue
            for dx in ((0, 1) if bold else (0,)):
                if x + dx < CELL_W:
                    img.putpixel((col * CELL_W + x + dx, row * CELL_H + y), (255, 255, 255, 255))


def main():
    jsons = ['cute', 'cute_s', 'cute_l', 'cute_bold', 'cute_bold_s', 'cute_bold_l']
    first = json.load(open(os.path.join(ROOT, 'font', 'cute.json'), encoding='utf-8'))['providers'][0]['chars']
    if len(first) >= 9 + ROWS_NEW:
        print('already extended'); return
    base = len(first)
    for name, bold in (('cute.png', False), ('cute_bold.png', True)):
        p = os.path.join(ROOT, 'textures', 'font', name)
        src = Image.open(p).convert('RGBA')
        img = Image.new('RGBA', (src.width, src.height + ROWS_NEW * CELL_H), (0, 0, 0, 0))
        img.paste(src, (0, 0))
        for i, ch in enumerate(ORDER):
            paint(img, i % COLS, base + i // COLS, G[ch], bold)
        img.save(p)
    rows = [''.join(ORDER[r * COLS:(r + 1) * COLS]).ljust(COLS, '\u0000') for r in range(ROWS_NEW)]
    for j in jsons:
        p = os.path.join(ROOT, 'font', j + '.json')
        d = json.load(open(p, encoding='utf-8'))
        d['providers'][0]['chars'] = d['providers'][0]['chars'] + rows
        json.dump(d, open(p, 'w', encoding='utf-8'), indent=1)
    print('added', len(ORDER), 'glyphs')


if __name__ == '__main__':
    main()
