#!/usr/bin/env python3
"""
Generates the story of "When the Cicadas Fall Silent" (game id `cicada`, a psychological-horror visual novel).

    python3 tools/make_cicada.py

Writes
  src/main/java/dev/cutemod/client/game/CicadaScript.java   the program (a list of small ops, text is only an index)
  src/main/resources/assets/cutemod/lang/en_us.json         the texts (keys cutemod.cic.*, cutemod.game.cicada ...)
  src/main/resources/assets/cutemod/lang/ru_ru.json

Safe to run again: the old cicada lines are removed from the language files first.

The script below is a tiny language, one command per line:

  label NAME                       a place to jump to
  bg ID FADE                       road shrine class room well fest void dawn; FADE = ticks of the cross-fade
  show CHAR EXPR SLOT              CHAR yuna asuka hikari silent; EXPR n s d f b c; SLOT 0 left, 1 middle, 2 right
  expr SLOT EXPR | hide SLOT | clear
  say CHAR | ru ~~ en              narr | ...   think | ... (Haruki's thoughts)   say me | ... (Haruki speaks)
  opt LABEL SANITY FLAGS | ru ~~ en   consecutive opt lines make one choice; SANITY is added, FLAGS are set
  san N | flag MASK | ifflag MASK LABEL (any bit set) | ifsan MAX LABEL (sanity <= MAX) | jump LABEL
  sfx KIND | shake N | flash N | glitch N | hush 0/1 (the cicadas are silent) | fig 0/1 (a figure in the window)
  title | ru ~~ en | wait N | end N

Flags: 1 charm taken, 2 Hikari's drawing, 4 the diary, 8 drank the well tea, 16 learned about the loop.
Endings: 0 Dawn (good), 1 The Voice in the Water, 2 The Circle, 3 The Choir, 4 Empty Dawn, 5 Silence.
"""
import json
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JAVA = os.path.join(ROOT, "src/main/java/dev/cutemod/client/game/CicadaScript.java")
LANG = os.path.join(ROOT, "src/main/resources/assets/cutemod/lang")

SCRIPT = r"""
# ===================================================================== day one
label start
bg road 0
hush 0
title | День первый ~~ Day one
narr | Июль. Автобус высадил меня на пустой остановке и уехал, не оглянувшись. ~~ July. The bus dropped me at an empty stop and left without looking back.
narr | Цикады кричали так, что звенело в ушах. ~~ The cicadas screamed so loudly that my ears rang.
think | Сэмидзава. Деревня, где я проведу лето у тётки. Сорок домов и ни одной вывески. ~~ Semizawa. The village where I would spend the summer with my aunt. Forty houses and not a single sign.
show yuna s 1
say yuna | Ты Харуки, да? А я Юна! Тётя Мидори просила встретить тебя. ~~ You're Haruki, right? I'm Yuna! Aunt Midori asked me to meet you.
say me | Спасибо. Тут всегда так... громко? ~~ Thanks. Is it always this... loud here?
say yuna | Это цикады! Не бойся их. Они поют, пока всё хорошо. ~~ That's the cicadas! Don't be afraid of them. They sing as long as everything is fine.
say me | А когда нехорошо? ~~ And when it isn't?
expr 1 b
sfx beat
say yuna | Тогда они замолкают. ~~ Then they go quiet.
expr 1 s
say yuna | Ой, не слушай меня! Я вечно болтаю глупости. Пойдём, покажу деревню! ~~ Oh, don't listen to me! I always talk nonsense. Come on, I'll show you the village!
hide 1

bg shrine 40
show yuna s 1
narr | Храм стоял на холме, и закат красил ступени в цвет засохшей крови. ~~ The shrine stood on a hill, and the sunset painted the steps the colour of dried blood.
say yuna | Через три ночи здесь Ночь Тихих Цикад. Самый главный праздник! ~~ In three nights it's the Night of the Silent Cicadas. The most important festival!
say me | Тихих? Какой же это праздник, если тихо? ~~ Silent? What kind of festival is a silent one?
say yuna | Раз в год цикады умолкают на целую ночь. Говорят, кто услышит эту тишину... ~~ Once a year the cicadas go quiet for a whole night. They say whoever hears that silence...
expr 1 b
say yuna | ...услышит, что она говорит. ~~ ...hears what it says.
expr 1 s
think | Она улыбалась. Но улыбка была как приклеенная. ~~ She was smiling. But the smile looked glued on.
say yuna | Вот, возьми оберег! На удачу. Только не открывай. ~~ Here, take this charm! For luck. Just don't open it.
opt a_take 0 1 | Взять оберег ~~ Take the charm
opt a_ask -1 1 | Спросить, что внутри ~~ Ask what's inside
opt a_no 0 0 | Вежливо отказаться ~~ Politely refuse

label a_take
say me | Спасибо. Повешу на рюкзак. ~~ Thanks. I'll hang it on my backpack.
say yuna | Вот и хорошо. Теперь ты точно услышишь... то, что нужно. ~~ Good. Now you'll surely hear... what you need to.
jump a_done
label a_ask
say me | А что внутри? ~~ What's inside?
expr 1 b
say yuna | Не открывай. ~~ Don't open it.
expr 1 s
say yuna | Шучу! Просто бумажка. Берёшь? ~~ Just kidding! Only a slip of paper. Will you take it?
think | Рука сама потянулась за оберегом. ~~ My hand reached for the charm all by itself.
jump a_done
label a_no
say me | Спасибо, но не надо. Я не суеверный. ~~ Thanks, but no. I'm not superstitious.
expr 1 d
say yuna | Ладно... Может, потом. Потом бывает поздно. ~~ Okay... Maybe later. Later is sometimes too late.
label a_done
hide 1

# ===================================================================== day two
bg class 40
title | День второй ~~ Day two
narr | В школе было три ученика. Три — и пустая парта у окна. ~~ The school had three pupils. Three — and one empty desk by the window.
show asuka n 0
show yuna s 2
say asuka | Новенький. Я Асука, староста. Садись. Только не к окну. ~~ The new kid. I'm Asuka, class rep. Sit down. Just not by the window.
say me | Почему? ~~ Why?
say asuka | Там сидела Рэйко. Она уехала. ~~ Reiko used to sit there. She moved away.
say yuna | Харуки, давай после уроков сходим на речку! ~~ Haruki, let's go to the river after class!
think | Асука не повернула головы. Будто никто ничего не сказал. ~~ Asuka did not turn her head. As if nobody had said anything.
hide 0
hide 2
show hikari s 1
say hikari | Смотри, я нарисовала тебя. ~~ Look, I drew you.
narr | Четыре фигурки держались за руки под луной. У одной не было лица. ~~ Four little figures held hands under the moon. One of them had no face.
say hikari | Это ты. ~~ That's you.
opt h_ask -1 2 | Спросить, почему без лица ~~ Ask why there is no face
opt h_praise 0 2 | Похвалить рисунок ~~ Praise the drawing
opt h_quiet 0 0 | Промолчать ~~ Say nothing

label h_ask
say me | Почему у меня нет лица? ~~ Why don't I have a face?
expr 1 b
say hikari | Лицо ты оставишь потом. Тому, кто придёт после тебя. ~~ You'll leave your face for later. For the one who comes after you.
jump h_done
label h_praise
say me | Красиво. Правда. ~~ Beautiful. Really.
say hikari | Ты хороший. Хорошие слышат дольше. ~~ You're nice. Nice ones hear for longer.
jump h_done
label h_quiet
think | Я не знал, что сказать, и просто кивнул. Хикари кивнула в ответ — слишком синхронно. ~~ I didn't know what to say and just nodded. Hikari nodded back — too in sync.
label h_done
hide 1

sfx thud
shake 14
narr | Что-то глухо стукнуло о парту. Мёртвая цикада. Потом ещё одна. И ещё. ~~ Something thudded on the desk. A dead cicada. Then another. And another.
show asuka n 0
say asuka | К вечеру их будет больше. Так всегда перед праздником. ~~ There will be more by evening. It's always like this before the festival.
show yuna s 2
say yuna | Жарко, да? Выпей чаю! Мама заварила на воде из нашего колодца. ~~ Hot, isn't it? Have some tea! Mum brewed it with water from our well.
narr | Асука едва заметно покачала головой. ~~ Asuka shook her head, barely noticeably.
opt t_drink -1 8 | Выпить ~~ Drink it
opt t_no 0 0 | Отказаться ~~ Decline

label t_drink
think | Чай был сладкий. Слишком сладкий. Во рту остался металлический привкус. ~~ The tea was sweet. Too sweet. A metallic taste stayed in my mouth.
say yuna | Вот и умница. Теперь ты почти наш. ~~ Good boy. Now you're almost one of us.
jump t_done
label t_no
say me | Спасибо, я не хочу пить. ~~ Thanks, I'm not thirsty.
expr 2 d
say yuna | Ты обидел чай. ~~ You've offended the tea.
say asuka | Умно. ~~ Smart.
label t_done
clear

# ===================================================================== night two
bg room 50
title | Ночь вторая ~~ Night two
narr | Тётя уснула рано. Я лежал и слушал цикад. Они гудели, как одна огромная машина. ~~ My aunt went to bed early. I lay listening to the cicadas. They hummed like one enormous machine.
think | И вдруг машина остановилась. ~~ And suddenly the machine stopped.
hush 1
sfx hush
narr | Тишина. Не та, когда никого нет. Тишина, в которой кто-то стоит рядом. ~~ Silence. Not the kind where nobody is there. The kind where someone stands right beside you.
ifflag 1 n_charm
jump n_window
label n_charm
narr | Оберег в кармане стал тёплым. Где-то далеко цикады снова зазвенели — слабо, но звенели. ~~ The charm in my pocket grew warm. Far away the cicadas began to ring again — faintly, but they rang.
san 1
hush 0
label n_window
sfx whisper
fig 1
narr | В окне, посреди рисового поля, стояла Юна. Неподвижно. Она смотрела прямо на меня. ~~ Out in the window, in the middle of the rice field, stood Yuna. Motionless. She was looking straight at me.
think | До её дома два километра. Как она оказалась здесь? ~~ Her house is two kilometres away. How did she get here?
opt n_curtain 0 0 | Задёрнуть шторы ~~ Draw the curtains
opt n_wave -1 0 | Помахать ей ~~ Wave at her
opt n_out -1 4 | Выйти наружу ~~ Go outside

label n_curtain
fig 0
narr | Я задёрнул шторы и накрылся с головой. Всю ночь мне казалось, что в комнате кто-то дышит в такт со мной. ~~ I drew the curtains and pulled the blanket over my head. All night it felt like someone in the room was breathing in time with me.
jump n_done
label n_wave
narr | Я помахал. Юна подняла руку и помахала в ответ. Слишком долго. Слишком ровно. Она не остановилась, даже когда я отвернулся. ~~ I waved. Yuna raised her hand and waved back. Too long. Too evenly. She didn't stop even after I turned away.
fig 0
jump n_done
label n_out
fig 0
bg well 20
glitch 40
narr | Поле было пустым. Только трава примята — цепочка маленьких следов, ведущая к лесу. ~~ The field was empty. Only the grass was trampled — a chain of small footprints leading to the forest.
narr | У края поля лежал дневник в красной обложке. ~~ At the edge of the field lay a diary in a red cover.
think | «Седьмой день. Я всё ещё жду автобус. Он приезжает каждый раз, и каждый раз выходит один и тот же мальчик.» ~~ "Day seven. I'm still waiting for the bus. It comes every time, and every time the same boy steps off."
think | Почерк был похож на мой. ~~ The handwriting looked like mine.
label n_done
hush 0

# ===================================================================== day three
bg class 40
title | День третий ~~ Day three
show asuka n 1
narr | После уроков Асука задержала меня у доски. ~~ After lessons Asuka kept me back at the blackboard.
say asuka | Ты разговариваешь с Юной. Я слышала. ~~ You talk to Yuna. I've heard you.
say asuka | Юна пропала восемь дней назад. Искали с собаками. Нашли только ленту у колодца. ~~ Yuna disappeared eight days ago. They searched with dogs. All they found was a ribbon by the well.
think | Я вспомнил красную ленту в волосах Юны. Она была как новая. ~~ I remembered the red ribbon in Yuna's hair. It had looked brand new.
say asuka | Она встречает каждого, кто приезжает на лето. Последний мальчик тоже её видел. ~~ She greets everyone who comes for the summer. The last boy saw her too.
say me | И что с ним стало? ~~ And what happened to him?
expr 1 d
say asuka | Он запел вместе с тишиной. ~~ He began to sing along with the silence.
opt s_tell 0 0 | Рассказать про вчерашнее окно ~~ Tell her about the window
opt s_deny -1 0 | Сказать, что она лжёт ~~ Say she's lying
opt s_dist -1 0 | Спросить, почему она не говорит с Юной ~~ Ask why she never speaks to Yuna

label s_tell
say me | Вчера она стояла в поле. Смотрела на моё окно. ~~ Last night she stood in the field. Looking at my window.
say asuka | Значит, началось. Держись подальше от колодца. ~~ Then it has begun. Stay away from the well.
jump s_done
label s_deny
say me | Это ложь! Юна сидела рядом со мной весь день! ~~ That's a lie! Yuna sat next to me all day!
expr 1 b
say asuka | Рядом с тобой. А кто ещё это видел? ~~ Next to you. And who else saw it?
think | Я хотел ответить. Но не смог вспомнить ни одного лица, которое смотрело бы на неё. ~~ I wanted to answer. But I couldn't recall a single face that had looked at her.
jump s_done
label s_dist
say me | Почему ты никогда с ней не говоришь? ~~ Why do you never talk to her?
say asuka | Потому что не хочу, чтобы она ответила. ~~ Because I don't want her to answer.
label s_done
hide 1

show hikari n 1
say hikari | Это третий раз. ~~ This is the third time.
say me | Что — третий? ~~ The third what?
flag 16
say hikari | Сначала ты приехал и испугался. Потом приехал и убежал. Теперь приехал и остался. ~~ First you came and got scared. Then you came and ran. Now you came and stayed.
ifflag 8 k_drank
say hikari | Ты не пил из колодца. Хорошо. Значит, ты ещё слышишь. ~~ You haven't drunk from the well. Good. That means you can still hear.
jump k_go
label k_drank
say hikari | Ты пил чай. Теперь тишину будет слышно лучше. Прости. ~~ You drank the tea. Now the silence will be easier to hear. I'm sorry.
label k_go
say hikari | Колодец — это не вода. Это рот. А цикады — те, кто не выпил. ~~ The well isn't water. It's a mouth. And the cicadas are the ones who didn't drink.
sfx whisper
shake 20
think | Я посмотрел на пол. Там лежали сотни мёртвых цикад, ровными рядами, лапками к двери. ~~ I looked at the floor. Hundreds of dead cicadas lay there in neat rows, legs pointing to the door.
san -1
hide 1

# ===================================================================== the festival
bg fest 60
title | Ночь Тихих Цикад ~~ The Night of the Silent Cicadas
narr | Вся деревня собралась на площади. Бумажные фонари качались, как повешенные луны. ~~ The whole village gathered in the square. Paper lanterns swayed like hanged moons.
narr | Сорок человек. Они стояли ровными рядами и не разговаривали. ~~ Forty people. They stood in neat rows and did not talk.
think | У них не было лиц. Нет, были. Просто стоило отвести взгляд, и я не мог вспомнить ни одного. ~~ They had no faces. No, they had. It was just that the moment I looked away, I couldn't remember a single one.
ifsan 1 f_mad
sfx bell
narr | Часы на башне пробили двенадцать. Цикады смолкли — все разом, как отрезало. ~~ The tower clock struck twelve. The cicadas stopped — all at once, as if cut off.
hush 1
glitch 120
shake 30
narr | Сорок голов повернулись ко мне. ~~ Forty heads turned towards me.
show yuna s 1
say yuna | Ты пришёл! Давай слушать вместе? Мне так долго было одной. ~~ You came! Shall we listen together? I was alone for so long.
show asuka n 0
say asuka | Харуки! Ключ от колодца у меня. Запрём его — и всё кончится. ~~ Haruki! I have the key to the well. We lock it — and it all ends.
show hikari n 2
say hikari | Выбирай. Но выбирай быстро. Тишина уже говорит. ~~ Choose. But choose fast. The silence is already speaking.
expr 1 c
say yuna | Не слушай их. Они не любят, когда кто-то остаётся. ~~ Don't listen to them. They don't like it when someone stays.
opt f_well 0 0 | Бежать с Асукой к колодцу ~~ Run to the well with Asuka
opt f_stay -1 0 | Остаться с Юной ~~ Stay with Yuna
opt f_run 0 0 | Бежать на остановку ~~ Run to the bus stop

# ---- the well
label f_well
clear
bg well 30
glitch 60
narr | Колодец дышал. Из чёрной воды поднимался шёпот — сотни голосов, говорящих разом. ~~ The well was breathing. A whisper rose from the black water — hundreds of voices speaking at once.
show asuka n 1
say asuka | Помоги мне задвинуть крышку! ~~ Help me slide the lid on!
ifflag 8 w_drank
jump w_ok
label w_drank
ifflag 1 w_charm
sfx whisper
shake 40
narr | Вода звала меня по имени. Я знал этот голос. Это был мой голос. ~~ The water called me by name. I knew that voice. It was my own.
end 1
label w_charm
narr | Оберег жёг карман. Шёпот отступил на шаг — и этого хватило. ~~ The charm burned in my pocket. The whisper took a step back — and that was enough.
label w_ok
narr | Мы навалились на крышку вдвоём. Дерево заскрипело, как зубы. ~~ We threw our weight on the lid together. The wood creaked like teeth.
ifflag 6 w_true
bg dawn 80
hush 0
sfx dawn
narr | Утром цикады запели снова. Но Юна так и не нашлась, а я так и не понял почему. ~~ In the morning the cicadas sang again. But Yuna was never found, and I never understood why.
end 4
label w_true
bg dawn 80
hush 0
sfx dawn
narr | Ровно в шесть утра за холмом закричала первая цикада. Потом вторая. Потом весь мир. ~~ At exactly six in the morning the first cicada screamed beyond the hill. Then a second. Then the whole world.
show yuna s 1
say yuna | Спасибо, что дослушал. Теперь я могу идти. ~~ Thank you for listening to the end. Now I can go.
say me | Куда? ~~ Where to?
say yuna | Не знаю. Но там не так тихо. ~~ I don't know. But it isn't as quiet there.
hide 1
narr | Автобус пришёл вовремя. На остановке не было никого. А на сиденье рядом лежала красная лента. ~~ The bus came on time. There was nobody at the stop. And a red ribbon lay on the seat beside me.
end 0

# ---- staying
label f_stay
hide 0
hide 2
expr 1 s
say yuna | Спасибо. Я так долго ждала кого-нибудь, кто останется. ~~ Thank you. I waited so long for someone who would stay.
narr | Она взяла меня за руку. Рука была тёплой. Это было страшнее всего. ~~ She took my hand. Her hand was warm. That was the scariest part.
narr | Тишина вошла в меня, как вода в колодец. ~~ The silence entered me like water into a well.
narr | Утром цикады запели снова. Но одна из них пела моим голосом. ~~ In the morning the cicadas sang again. But one of them sang in my voice.
end 5

# ---- running away
label f_run
clear
bg road 40
hush 0
narr | Я бежал, пока не увидел остановку. Автобус стоял с открытой дверью, будто ждал только меня. ~~ I ran until I saw the stop. The bus stood with its door open as if it had been waiting only for me.
show silent n 1
say silent | Сэмидзава? Вы уже ехали, молодой человек. ~~ Semizawa? You've already been, young man.
say silent | Садитесь. Цикады ещё не начались. ~~ Get in. The cicadas haven't started yet.
hide 1
show yuna s 1
narr | Автобус тронулся. За окном стояла Юна и махала мне. Слишком долго. Слишком ровно. ~~ The bus pulled away. Outside stood Yuna, waving. Too long. Too evenly.
hide 1
bg road 60
narr | Июль. Автобус высадил меня на пустой остановке и уехал, не оглянувшись. ~~ July. The bus dropped me at an empty stop and left without looking back.
end 2

# ---- madness
label f_mad
clear
glitch 200
hush 1
shake 40
narr | Я больше не слышал цикад. Совсем. Только ровный звук, будто кто-то бесконечно тянет одну ноту. ~~ I couldn't hear the cicadas any more. At all. Only an even sound, as if someone were endlessly holding a single note.
show yuna c 1
say yuna | Слышишь? Ты поёшь вместе с нами. ~~ Hear that? You are singing along with us.
think | Я открыл рот. Звук шёл не из деревни. Звук шёл из меня. ~~ I opened my mouth. The sound didn't come from the village. It came from me.
narr | Утром деревня была тихой. Только я пел. ~~ In the morning the village was quiet. Only I sang.
end 3
"""

WHO = {"yuna": ("Юна", "Yuna"), "asuka": ("Асука", "Asuka"), "hikari": ("Хикари", "Hikari"),
       "silent": ("???", "???"), "me": ("Харуки", "Haruki")}
ENDS = [("Рассвет", "Dawn"), ("Голос в воде", "The Voice in the Water"), ("Круг", "The Circle"),
        ("Хор", "The Choir"), ("Пустой рассвет", "Empty Dawn"), ("Тишина", "Silence")]
CH = {"yuna": 0, "asuka": 1, "hikari": 2, "silent": 3, "me": 4, "narr": 5, "think": 6}
EX = {"n": 0, "s": 1, "d": 2, "f": 3, "b": 4, "c": 5}
BG = {"road": 0, "shrine": 1, "class": 2, "room": 3, "well": 4, "fest": 5, "void": 6, "dawn": 7}

UI_RU = {
    "cutemod.game.cicada": "Когда смолкают цикады",
    "cutemod.hint.cicada": "Клик или пробел: дальше. Выбор: клик или 1-2-3. Следи за рассудком: тишина слышит всех.",
    "cutemod.store.blurb.cicada": "Психологический хоррор-новелла. Лето, глухая деревня, три друга и цикады, которые умолкают раз в год. Твои выборы решают, сохранишь ли ты рассудок. Шесть концовок.",
    "cutemod.store.rev.cicada.0": "Играл днём. Теперь боюсь, когда на улице тихо.",
    "cutemod.store.rev.cicada.1": "Юна улыбалась, и мне хотелось закрыть окно. Прошёл все шесть концовок.",
    "cutemod.store.rev.cicada.2": "Не пейте чай. Я предупредил.",
    "cutemod.store.rev.cicada.3": "Красиво нарисовано и очень страшно. Звук цикад в наушниках - это отдельный вид пытки.",
    "cutemod.store.rev.cicada.4": "Выбрал бежать на остановку. Автобус знал моё имя.",
    "cutemod.cic.status": "Рассудок %s/5  Улики %s",
    "cutemod.cic.sanity": "Рассудок",
    "cutemod.cic.begin": "Нажми, чтобы начать",
}
UI_EN = {
    "cutemod.game.cicada": "When the Cicadas Fall Silent",
    "cutemod.hint.cicada": "Click or Space: next. Choices: click or 1-2-3. Mind your sanity: the silence hears everyone.",
    "cutemod.store.blurb.cicada": "A psychological horror visual novel. A summer, a remote village, three friends and the cicadas that fall silent once a year. Your choices decide whether you keep your mind. Six endings.",
    "cutemod.store.rev.cicada.0": "Played it by day. Now I'm afraid when it's quiet outside.",
    "cutemod.store.rev.cicada.1": "Yuna kept smiling and I wanted to close the window. Got all six endings.",
    "cutemod.store.rev.cicada.2": "Do not drink the tea. I warned you.",
    "cutemod.store.rev.cicada.3": "Beautifully drawn and really scary. Cicadas in headphones is its own kind of torture.",
    "cutemod.store.rev.cicada.4": "I ran to the bus stop. The bus knew my name.",
    "cutemod.cic.status": "Sanity %s/5  Clues %s",
    "cutemod.cic.sanity": "Sanity",
    "cutemod.cic.begin": "Click to begin",
}


def compile_script():
    texts_ru, texts_en = [], []

    def text(s):
        ru, en = [x.strip() for x in s.split("~~")]
        texts_ru.append(ru); texts_en.append(en)
        return len(texts_ru) - 1

    items = []          # ("op", [fields]) or ("label", name); labels are resolved in a second pass
    opts = []

    def flush():
        nonlocal opts
        if opts:
            f = ["choice", str(len(opts))]
            for (lab, san, flg, t) in opts:
                f += [str(t), ("@" + lab), str(san), str(flg)]
            items.append(("op", f))
            opts = []

    for raw in SCRIPT.strip().split("\n"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        head, _, rest = line.partition("|")
        words = head.split()
        cmd = words[0]
        if cmd != "opt":
            flush()
        if cmd == "label":
            items.append(("label", words[1]))
        elif cmd == "bg":
            items.append(("op", ["bg", str(BG[words[1]]), words[2]]))
        elif cmd == "show":
            items.append(("op", ["show", str(CH[words[1]]), str(EX[words[2]]), words[3]]))
        elif cmd == "expr":
            items.append(("op", ["expr", words[1], str(EX[words[2]])]))
        elif cmd in ("hide", "san", "flag", "sfx", "shake", "flash", "glitch", "hush", "fig", "wait", "end"):
            items.append(("op", [cmd, words[1]]))
        elif cmd == "clear":
            items.append(("op", ["clear"]))
        elif cmd == "say":
            items.append(("op", ["say", str(CH[words[1]]), str(text(rest))]))
        elif cmd in ("narr", "think"):
            items.append(("op", ["say", str(CH[cmd]), str(text(rest))]))
        elif cmd == "title":
            items.append(("op", ["title", str(text(rest))]))
        elif cmd == "opt":
            opts.append((words[1], int(words[2]), int(words[3]), text(rest)))
        elif cmd == "ifflag":
            items.append(("op", ["ifflag", words[1], "@" + words[2]]))
        elif cmd == "ifsan":
            items.append(("op", ["ifsan", words[1], "@" + words[2]]))
        elif cmd == "jump":
            items.append(("op", ["jump", "@" + words[1]]))
        else:
            raise SystemExit("unknown command: " + line)
    flush()

    labels, ops = {}, []
    for kind, v in items:
        if kind == "label":
            labels[v] = len(ops)
        else:
            ops.append(v)
    out = []
    for f in ops:
        g = []
        for x in f:
            if x.startswith("@"):
                g.append(str(labels[x[1:]]))
            else:
                g.append(x)
        out.append("|".join(g))
    return out, texts_ru, texts_en


def write_java(ops, n_texts):
    lines = ",\n".join('        "%s"' % o for o in ops)
    src = f"""package dev.cutemod.client.game;

/**
 * The program of the visual novel "When the Cicadas Fall Silent" ({{@link Cicada}}). GENERATED by tools/make_cicada.py: edit the
 * script there, not here. Every op is "name|arg|arg..."; the texts are the language keys cutemod.cic.t.0 ... cutemod.cic.t.{n_texts - 1}.
 */
final class CicadaScript {{
    private CicadaScript() {{}}

    static final int TEXTS = {n_texts};

    static final String[] OPS = {{
{lines}
    }};
}}
"""
    with open(JAVA, "w", encoding="utf-8") as f:
        f.write(src)


def patch_lang(fname, entries):
    path = os.path.join(LANG, fname)
    text = open(path, encoding="utf-8").read()
    lines = text.rstrip().split("\n")
    assert lines[-1].strip() == "}", "unexpected end of " + fname
    body = lines[:-1]
    pat = re.compile(r'^\s*"(cutemod\.cic\.|cutemod\.game\.cicada|cutemod\.hint\.cicada|cutemod\.store\.(blurb|rev)\.cicada)')
    body = [l for l in body if not pat.match(l)]
    while body and not body[-1].strip():
        body.pop()
    body[-1] = body[-1].rstrip().rstrip(",")
    add = ['  %s: %s' % (json.dumps(k, ensure_ascii=False), json.dumps(v, ensure_ascii=False)) for k, v in entries]
    out = "\n".join(body) + ",\n" + ",\n".join(add) + "\n}\n"
    json.loads(out)       # must stay valid
    with open(path, "w", encoding="utf-8") as f:
        f.write(out)


def main():
    ops, ru, en = compile_script()
    write_java(ops, len(ru))
    for fname, texts, ui, idx in (("ru_ru.json", ru, UI_RU, 0), ("en_us.json", en, UI_EN, 1)):
        entries = list(ui.items())
        entries += [("cutemod.cic.who." + k, v[idx]) for k, v in WHO.items()]
        entries += [("cutemod.cic.end.%d" % i, e[idx]) for i, e in enumerate(ENDS)]
        entries += [("cutemod.cic.t.%d" % i, t) for i, t in enumerate(texts)]
        patch_lang(fname, entries)
    print("ops:", len(ops), "texts:", len(ru))
    longest = max(ru + en, key=len)
    print("longest text:", len(longest), longest[:60])


if __name__ == "__main__":
    main()
