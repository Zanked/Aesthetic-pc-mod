package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Breakout: bounce the ball off the plate and eat all the cookies. */
public class CookieBreaker extends MiniGame {
    private static final int COLS = 10, ROWS = 5, BW = 20, BH = 8, PAD_W = 40, PAD_H = 5, PY = H - 14;
    private static final int[] ROW_COLORS = {0xFFF58FB8, 0xFFF5A623, 0xFFE0B46A, 0xFFC98B5A, 0xFF9B6B45};

    private final boolean[][] bricks = new boolean[ROWS][COLS];
    private double px, bx, by, vx, vy, speed;
    private int lives, level, bricksLeft;
    private boolean launched;
    private int t;
    private final java.util.ArrayDeque<double[]> trail = new java.util.ArrayDeque<>();
    private final java.util.List<double[]> crumbs = new java.util.ArrayList<>();   // x, y, vx, vy, life, colour

    @Override
    public void reset() {
        score = 0; over = false; lives = 3; level = 1; speed = 2.2; crumbs.clear(); trail.clear();
        px = W / 2.0;
        fillBricks();
        resetBall();
    }

    private void fillBricks() {
        for (boolean[] row : bricks) java.util.Arrays.fill(row, true);
        bricksLeft = ROWS * COLS;
    }

    private void resetBall() {
        launched = false;
        bx = px; by = PY - 4; vx = 0; vy = 0;
    }

    private void launch() {
        if (launched) return;
        launched = true;
        double a = (rnd.nextDouble() - 0.5) * 0.8;
        vx = speed * Math.sin(a);
        vy = -speed * Math.cos(a);
        pling(1.5F);
    }

    @Override
    public boolean click(int x, int y, int button) { launch(); return true; }

    @Override
    public boolean key(int k) {
        if (k == KEY_SPACE || k == KEY_UP) { launch(); return true; }
        return false;
    }

    private boolean hit(double x, double y) {
        int c = (int) Math.floor((x - 1) / 22.0), r = (int) Math.floor((y - 14) / 10.0);
        if (c < 0 || c >= COLS || r < 0 || r >= ROWS || !bricks[r][c]) return false;
        if ((x - 1) - c * 22 >= BW || (y - 14) - r * 10 >= BH) return false;
        bricks[r][c] = false;
        bricksLeft--;
        for (int i = 0; i < 6; i++) crumbs.add(new double[]{c * 22 + 1 + BW / 2.0, r * 10 + 14 + BH / 2.0, (rnd.nextDouble() - 0.5) * 2.2, -rnd.nextDouble() * 1.8, 26 + rnd.nextInt(10), ROW_COLORS[r]});
        score += 5 * (ROWS - r);
        pling(1.1F + r * 0.1F);
        return true;
    }

    @Override
    public void tick() {
        t++;
        for (int i = crumbs.size() - 1; i >= 0; i--) {
            double[] cr = crumbs.get(i);
            cr[0] += cr[2]; cr[1] += cr[3]; cr[3] += 0.12; cr[4]--;
            if (cr[4] <= 0) crumbs.remove(i);
        }
        trail.addFirst(new double[]{bx, by});
        while (trail.size() > 7) trail.removeLast();
        double target = Math.max(PAD_W / 2.0, Math.min(W - PAD_W / 2.0, mx));
        px += (target - px) * 0.35;
        if (!launched) { bx = px; by = PY - 4; return; }
        int n = (int) Math.ceil(speed);
        for (int s = 0; s < n; s++) {
            bx += vx / n;
            if (bx < 3) { bx = 3; vx = Math.abs(vx); }
            if (bx > W - 3) { bx = W - 3; vx = -Math.abs(vx); }
            if (hit(bx, by)) vx = -vx;
            by += vy / n;
            if (by < 3) { by = 3; vy = Math.abs(vy); }
            if (hit(bx, by)) vy = -vy;
            if (vy > 0 && by + 3 >= PY && by - 3 <= PY + PAD_H && Math.abs(bx - px) <= PAD_W / 2.0 + 3) {
                double a = (bx - px) / (PAD_W / 2.0 + 3);
                vx = speed * Math.sin(a);
                vy = -speed * Math.cos(a);
                by = PY - 3;
                pling(1.0F);
            }
        }
        if (by > H + 4) {
            lives--;
            beep();
            if (lives <= 0) over = true; else resetBall();
        }
        if (bricksLeft == 0) {
            level++;
            speed = Math.min(3.6, speed + 0.25);
            fillBricks();
            resetBall();
        }
    }

    @Override
    public void render(GuiGraphics g) {
        // kitchen table: warm gradient with a soft gingham pattern
        g.fillGradient(0, 0, W, H, 0xFFFFF3DC, 0xFFF5C890);
        for (int y = 0; y < H; y += 20) rect(g, 0, y, W, 10, 0x12FF8A5A);          // gingham = horizontal + vertical stripes
        for (int x = 0; x < W; x += 20) rect(g, x, 0, 10, H, 0x12FF8A5A);
        Gfx.vignette(g, W, H, 50);
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (!bricks[r][c]) continue;
                int x = c * 22 + 1, y = r * 10 + 14;
                int col = ROW_COLORS[r];
                if (r == 0) {
                    // frosted pink cookie with sprinkles
                    Gfx.shadow(g, x, y, BW, BH, 3);
                    Gfx.bubble(g, x, y, BW, BH, 3, col);
                    rect(g, x + 4, y + 3, 2, 1, 0xFFFFFFFF); rect(g, x + 10, y + 2, 2, 1, 0xFFFFE27A); rect(g, x + 14, y + 4, 2, 1, 0xFF7AD3FF);
                    rect(g, x + 7, y + 5, 2, 1, 0xFF9BE07A);
                } else {
                    Gfx.shadow(g, x, y, BW, BH, 3);
                    Gfx.bubble(g, x, y, BW, BH, 3, col);
                    int chip = 0xFF4A2E1C;
                    rect(g, x + 4 + (r & 1) * 2, y + 3, 2, 2, chip); rect(g, x + 12, y + 2, 2, 2, chip);
                    rect(g, x + 9, y + 5, 2, 1, chip); rect(g, x + 16, y + 4, 1, 2, chip);
                }
            }
        }
        // crumbs flying off eaten cookies
        for (double[] cr : crumbs) rect(g, (int) cr[0], (int) cr[1], 2, 2, Gfx.fade((int) cr[5] | 0xFF000000, (float) Math.min(1, cr[4] / 14.0)));
        // the plate: pink, rounded with a shiny rim and a little shadow
        int pxx = (int) px - PAD_W / 2;
        Gfx.shadow(g, pxx, PY, PAD_W, PAD_H, 2);
        Gfx.bubble(g, pxx, PY, PAD_W, PAD_H + 1, 2, 0xFFE58AAE);
        rect(g, pxx + 6, PY + 2, PAD_W - 12, 1, 0x66FFFFFF);
        // marshmallow ball with a soft tail
        int i = 0;
        for (double[] p : trail) {
            if (i > 0 && launched) Gfx.disc(g, (int) p[0], (int) p[1], Math.max(1, 3 - i / 3), Gfx.alpha(0xFFFFFFFF, 80 - i * 10));
            i++;
        }
        Gfx.glow(g, (int) bx, (int) by, 8, 0xFFFFFFFF, 90);
        Gfx.ball(g, (int) bx, (int) by, 3, 0xFFFFFFFF);
        if (!launched) {
            Gfx.rrect(g, W / 2 - 40, H - 36, 80, 13, 4, 0x88FFFFFF);
            ctext(g, "click / space", W / 2, H - 34, 0xFF7A4A2A);
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public String hintKey() { return "cutemod.hint.breakout"; }
}
