package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Rabbit Road: hop forward over endless lanes of grass, roads (minecarts and cars), rivers (logs) and rails (trains).
 * Arrow keys / WASD hop, a click hops forward. Stand still for too long and a phantom takes the rabbit.
 */
public class RabbitRoad extends MiniGame {
    private static final int T = 14, COLS = 15, X0 = 5, HOP = 7;
    private static final int GRASS = 0, ROAD = 1, RIVER = 2, RAIL = 3;
    private static final int TRAIN_W = 150;
    private static final int DEAD_CAR = 0, DEAD_WATER = 1, DEAD_PHANTOM = 2;

    private static final class Lane {
        int type, dir = 1;
        float speed;
        final byte[] obj = new byte[COLS];       // 0 nothing, 1 tree, 2 stone (they block the rabbit)
        final byte[] flower = new byte[COLS];    // 0 nothing, 1..4 a colored flower (just decoration)
        int carrot = -1;
        int n;                                   // cars or logs
        final float[] tx = new float[4];
        final int[] tw = new int[4], tk = new int[4];
        int trainT;
        float trainX;
        boolean train;
    }

    private final List<Lane> lanes = new ArrayList<>();
    private float px, camF;
    private int pr, camTarget, maxRow, carrots, hopT, queued, idleT, dead, t;
    private float fromX, fromRow;

    @Override
    public void reset() {
        score = 0; over = false;
        lanes.clear();
        pr = 0; maxRow = 0; carrots = 0; camTarget = 0; camF = 0; hopT = 0; queued = 0; idleT = 0; dead = -1; t = 0;
        px = X0 + 7 * T;
        fromX = px; fromRow = 0;
        while (lanes.size() < 18) lanes.add(makeLane(lanes.size()));
    }

    // ---------- lanes ----------
    private Lane makeLane(int r) {
        Lane l = new Lane();
        Lane prev = r > 0 ? lanes.get(r - 1) : null;
        int type = GRASS;
        if (r >= 3) {
            int k = rnd.nextInt(100);
            type = k < 34 ? GRASS : k < 64 ? ROAD : k < 84 ? RIVER : RAIL;
            if (prev != null && prev.type == type) {                       // not too many of a kind in a row
                int streak = 1;
                for (int i = r - 2; i >= 0 && lanes.get(i).type == type; i--) streak++;
                int max = type == ROAD ? 3 : type == RIVER ? 2 : type == RAIL ? 1 : 4;
                if (streak >= max) type = GRASS;
            }
        }
        l.type = type;
        l.dir = rnd.nextBoolean() ? 1 : -1;
        if (prev != null && prev.type == type && type == RIVER) l.dir = -prev.dir;   // rivers flow in turns
        switch (type) {
            case GRASS -> {
                if (r >= 2) {
                    int n = rnd.nextInt(5);
                    for (int i = 0; i < n; i++) l.obj[rnd.nextInt(COLS)] = (byte) (1 + rnd.nextInt(2));
                    if (r >= 4 && rnd.nextInt(100) < 14) {
                        int c = rnd.nextInt(COLS);
                        if (l.obj[c] == 0) l.carrot = c;
                    }
                }
                for (int i = 0; i < 4; i++) {
                    int c = rnd.nextInt(COLS);
                    if (l.obj[c] == 0) l.flower[c] = (byte) (1 + rnd.nextInt(4));
                }
            }
            case ROAD -> {
                l.speed = Math.min(1.9F, 0.45F + rnd.nextFloat() * 0.9F + r / 220F);
                l.n = 2 + rnd.nextInt(2);
                for (int i = 0; i < l.n; i++) {
                    l.tk[i] = rnd.nextInt(3);
                    l.tw[i] = l.tk[i] == 0 ? 16 : l.tk[i] == 1 ? 22 : 34;
                    l.tx[i] = i * (W / (float) l.n) + rnd.nextInt(14);
                }
            }
            case RIVER -> {
                l.speed = 0.3F + rnd.nextFloat() * 0.5F;
                l.n = 3;
                for (int i = 0; i < l.n; i++) {
                    l.tw[i] = rnd.nextBoolean() ? 28 : 42;
                    l.tx[i] = i * (W / 3F) + rnd.nextInt(10);
                }
            }
            default -> l.trainT = 90 + rnd.nextInt(200);
        }
        return l;
    }

    private void tickLane(Lane l, boolean visible) {
        switch (l.type) {
            case ROAD, RIVER -> {
                for (int i = 0; i < l.n; i++) {
                    l.tx[i] += l.speed * l.dir;
                    if (l.dir > 0 && l.tx[i] > W + 4) {
                        float minX = Float.MAX_VALUE;
                        for (int j = 0; j < l.n; j++) if (j != i) minX = Math.min(minX, l.tx[j]);
                        l.tx[i] = Math.min(minX, 0) - l.tw[i] - (l.type == ROAD ? 36 : 30) - rnd.nextInt(30);
                    } else if (l.dir < 0 && l.tx[i] + l.tw[i] < -4) {
                        float maxEnd = -Float.MAX_VALUE;
                        for (int j = 0; j < l.n; j++) if (j != i) maxEnd = Math.max(maxEnd, l.tx[j] + l.tw[j]);
                        l.tx[i] = Math.max(maxEnd, W) + (l.type == ROAD ? 36 : 30) + rnd.nextInt(30);
                    }
                }
            }
            case RAIL -> {
                if (l.train) {
                    l.trainX += 5F * l.dir;
                    if (l.dir > 0 ? l.trainX > W + 8 : l.trainX + TRAIN_W < -8) { l.train = false; l.trainT = 140 + rnd.nextInt(240); }
                } else if (--l.trainT <= 0) {
                    l.train = true;
                    l.trainX = l.dir > 0 ? -TRAIN_W : W;
                } else if (visible && l.trainT <= 70 && l.trainT % 14 == 0) beep();
            }
            default -> { }
        }
    }

    // ---------- input ----------
    @Override
    public boolean key(int k) {
        int code = switch (k) {
            case KEY_UP, 87, KEY_SPACE -> 1;       // forward
            case KEY_DOWN, 83 -> 2;                // back
            case KEY_LEFT, 65 -> 3;
            case KEY_RIGHT, 68 -> 4;
            default -> 0;
        };
        if (code == 0) return false;
        input(code);
        return true;
    }

    @Override
    public boolean click(int x, int y, int button) {
        input(1);
        return true;
    }

    private void input(int code) {
        if (over) return;
        if (hopT > 0) { queued = code; return; }
        move(code);
    }

    private int colOf(float x) { return Math.max(0, Math.min(COLS - 1, Math.round((x - X0) / T))); }

    private float snap(float x) { return X0 + colOf(x) * T; }

    private void move(int code) {
        Lane cur = lanes.get(pr);
        float npx = px;
        int npr = pr;
        if (code == 1 || code == 2) {
            int to = pr + (code == 1 ? 1 : -1);
            if (to < 0 || (code == 2 && to < camTarget)) return;                       // never back off the screen
            while (lanes.size() <= to + 1) lanes.add(makeLane(lanes.size()));
            Lane nx = lanes.get(to);
            if (nx.type == GRASS && nx.obj[colOf(px)] != 0) { beep(); return; }       // a tree or a stone
            if (cur.type == RIVER && nx.type != RIVER) npx = snap(px);                  // back onto the grid
            npr = to;
        } else {
            int dx = code == 3 ? -1 : 1;
            if (cur.type == GRASS) {
                int c2 = colOf(px) + dx;
                if (c2 < 0 || c2 >= COLS || cur.obj[c2] != 0) return;
                npx = X0 + c2 * T;
            } else {
                npx = px + dx * T;
                if (npx < X0 - 1 || npx > X0 + (COLS - 1) * T + 1) return;
            }
        }
        fromX = px; fromRow = pr;
        px = npx; pr = npr;
        hopT = HOP;
        beep();
    }

    // ---------- game ----------
    private void die(int how) {
        dead = how;
        over = true;
        if (how == DEAD_PHANTOM) growl(G_BITE);
        else if (how == DEAD_WATER) sound(net.minecraft.sounds.SoundEvents.GENERIC_SPLASH, 1.0F, 0.8F);
        else beep();
    }

    @Override
    public void tick() {
        t++;
        while (lanes.size() < pr + 18) lanes.add(makeLane(lanes.size()));
        int lo = Math.max(0, (int) camF - 1), hi = Math.min(lanes.size() - 1, (int) camF + 12);
        for (int r = lo; r <= hi; r++) tickLane(lanes.get(r), true);

        if (hopT > 0 && --hopT == 0 && queued != 0) { int q = queued; queued = 0; move(q); }

        camTarget = Math.max(camTarget, pr - 3);
        camF += (camTarget - camF) * 0.18F;

        if (pr > maxRow) { maxRow = pr; idleT = 0; } else idleT++;
        score = maxRow + carrots * 3;

        Lane l = lanes.get(pr);
        float pl = px + 2, pw = 10;
        switch (l.type) {
            case ROAD -> {
                if (hopT <= HOP / 2)                                                         // the rabbit has reached this lane
                    for (int i = 0; i < l.n; i++)
                        if (pl < l.tx[i] + l.tw[i] && pl + pw > l.tx[i]) { die(DEAD_CAR); return; }
            }
            case RAIL -> {
                if (hopT <= HOP / 2 && l.train && pl < l.trainX + TRAIN_W && pl + pw > l.trainX) { die(DEAD_CAR); return; }
            }
            case RIVER -> {
                if (hopT == 0) {
                    float c = px + T / 2F;
                    boolean onLog = false;
                    for (int i = 0; i < l.n; i++) if (c >= l.tx[i] && c <= l.tx[i] + l.tw[i]) onLog = true;
                    if (!onLog) { die(DEAD_WATER); return; }
                    px += l.speed * l.dir;                                                   // the log carries the rabbit
                    if (px < -4 || px > W - 10) { die(DEAD_WATER); return; }
                }
            }
            default -> {
                if (hopT == 0 && l.carrot >= 0 && l.carrot == colOf(px)) {
                    l.carrot = -1;
                    carrots++;
                    pling(1.8F);
                }
            }
        }
        if (idleT > 300 && idleT % 70 == 1) growl(G_PHANTOM);                                  // the phantom shrieks above you
        if (idleT > 480) die(DEAD_PHANTOM);                                                  // do not stand still
    }

    // ---------- drawing ----------
    private int rowY(float r) { return Math.round(H - T * (r - camF + 1)); }

    @Override
    public void render(GuiGraphics g) {
        int top = (int) Math.ceil(camF) + 11, bottom = Math.max(0, (int) camF - 1);
        for (int r = Math.min(top, lanes.size() - 1); r >= bottom; r--) drawLane(g, lanes.get(r), r);
        drawRabbit(g);
        if (!over && idleT > 300) {                                         // the phantom is coming
            int a = Math.min(190, (idleT - 300) * 190 / 180);
            g.fillGradient(0, 0, W, 38, (a << 24) | 0x0A0A1E, 0x000A0A1E);
            if ((t / 8) % 2 == 0) ctext(g, "!", W / 2, 8, 0xFFFF5A5A);
        }
    }

    private static final int[] FLOWER_COL = {0, 0xFFFF8FB8, 0xFFFFE066, 0xFFFFFFFF, 0xFF9AD0FF};

    private void drawLane(GuiGraphics g, Lane l, int r) {
        int y = rowY(r);
        switch (l.type) {
            case GRASS -> {
                boolean even = r % 2 == 0;
                g.fillGradient(0, y, W, y + T, even ? 0xFF94DA70 : 0xFF8CD268, even ? 0xFF86CE64 : 0xFF7EC65C);
                for (int c = 0; c < COLS; c++) {
                    int fx = X0 + c * T;
                    float h = Gfx.hash(r * 17 + c, 50);
                    if (h < 0.55F) {                                                       // little grass tufts
                        int tx0 = fx + 2 + (int) (h * 18);
                        rect(g, tx0, y + 10, 1, 2, 0xFF6FB852); rect(g, tx0 + 1, y + 9, 1, 3, 0xFF6FB852); rect(g, tx0 + 3, y + 10, 1, 2, 0xFF6FB852);
                    }
                    if (l.flower[c] != 0) {
                        int col = FLOWER_COL[l.flower[c]], fxx = fx + 4 + (c * 3) % 5, fyy = y + 8 - (c * 2) % 4;
                        rect(g, fxx - 1, fyy, 3, 1, col); rect(g, fxx, fyy - 1, 1, 3, col); rect(g, fxx, fyy, 1, 1, 0xFFFFE066);
                    }
                    if (l.carrot == c) {
                        Gfx.ellipse(g, fx + 8, y + 12, 4, 1, 0x33000000);
                        Gfx.poly(g, new int[]{fx + 4, fx + 11, fx + 7}, new int[]{y + 3, y + 3, y + 12}, 0xFFFF8A1C);
                        rect(g, fx + 5, y + 4, 2, 1, 0xFFFFC27A);
                        rect(g, fx + 6, y + 7, 2, 1, 0xFFD96A0C);
                        Gfx.rrect(g, fx + 4, y, 7, 4, 1, 0xFF4F9A2E);
                        rect(g, fx + 5, y, 2, 1, 0xFF7ACB5E);
                    }
                }
            }
            case ROAD -> {
                g.fillGradient(0, y, W, y + T, 0xFF56566C, 0xFF44445A);
                rect(g, 0, y, W, 1, 0x22FFFFFF); rect(g, 0, y + T - 1, W, 1, 0x33000000);
                for (int x = 4; x < W; x += 24) Gfx.rrect(g, x, y + 6, 12, 2, 1, 0x88FFFFFF);
                for (int i = 0; i < 6; i++) rect(g, (int) (Gfx.hash(r * 7 + i, 51) * W), y + 2 + (i * 5) % 9, 2, 1, 0x1AFFFFFF);
            }
            case RIVER -> {
                g.fillGradient(0, y, W, y + T, 0xFF5AB4EE, 0xFF3F98DC);
                int off = (int) ((t * 0.3F * l.dir) % 28 + 28) % 28;
                for (int x = off - 28; x < W; x += 28) {
                    rect(g, x, y + 3, 6, 1, 0xFF9AD6F6);
                    rect(g, x + 14, y + 10, 6, 1, 0xFF9AD6F6);
                    rect(g, x + 2, y + 4, 3, 1, 0x55FFFFFF);
                }
            }
            default -> {
                g.fillGradient(0, y, W, y + T, 0xFFBCA27A, 0xFF9C8460);
                for (int x = 2; x < W; x += 6) rect(g, x, y + 1, 3, T - 2, 0xFF7A5A36);
                rect(g, 0, y + 3, W, 2, 0xFFB8BEC6); rect(g, 0, y + 3, W, 1, 0xFFE4E8EC);
                rect(g, 0, y + 9, W, 2, 0xFFB8BEC6); rect(g, 0, y + 9, W, 1, 0xFFE4E8EC);
                if (!l.train && l.trainT <= 70) {                                      // warning lamps with a red glow
                    boolean on = (t / 5) % 2 == 0;
                    if (on) { Gfx.glow(g, 6, y + 7, 9, 0xFFFF3030, 110); Gfx.glow(g, W - 7, y + 7, 9, 0xFFFF3030, 110); }
                    int lamp = on ? 0xFFFF3030 : 0xFF701818;
                    Gfx.ball(g, 6, y + 7, 3, lamp);
                    Gfx.ball(g, W - 7, y + 7, 3, lamp);
                }
            }
        }
        // things on the lane
        if (l.type == ROAD) {
            for (int i = 0; i < l.n; i++) drawCar(g, Math.round(l.tx[i]), y, l.tw[i], l.tk[i], l.dir);
        } else if (l.type == RIVER) {
            for (int i = 0; i < l.n; i++) {
                int x = Math.round(l.tx[i]), w = l.tw[i];
                Gfx.rrect(g, x + 1, y + 4, w, 10, 4, 0x2A0A2A50);                                  // shadow on the water
                Gfx.rrect(g, x, y + 2, w, 10, 4, 0xFF6A4420);
                g.fillGradient(x + 2, y + 3, x + w - 2, y + 11, 0xFFA8743C, 0xFF7E5028);
                rect(g, x + 4, y + 4, w - 8, 1, 0x55FFFFFF);
                rect(g, x + 5, y + 7, w - 12, 1, 0xFF5A3A18);
                rect(g, x + 9, y + 9, Math.max(1, w - 20), 1, 0xFF5A3A18);
                Gfx.ellipse(g, x + 3, y + 7, 2, 4, 0xFFD9AA6A); Gfx.ellipse(g, x + 3, y + 7, 1, 2, 0xFFB98848);   // log ends with rings
                Gfx.ellipse(g, x + w - 3, y + 7, 2, 4, 0xFFD9AA6A); Gfx.ellipse(g, x + w - 3, y + 7, 1, 2, 0xFFB98848);
            }
        } else if (l.type == RAIL && l.train) {
            int x = Math.round(l.trainX);
            for (int i = 0; i < 3; i++) {
                int cx = x + i * 50;
                boolean head = i == (l.dir > 0 ? 2 : 0);
                int col = head ? 0xFFD6403A : 0xFF6A6E8A;
                Gfx.rrect(g, cx, y + 1, 48, 12, 3, Gfx.darker(col, 0.4f));
                g.fillGradient(cx + 1, y + 2, cx + 47, y + 12, Gfx.lighter(col, 0.2f), col);
                rect(g, cx + 2, y + 2, 44, 1, 0x55FFFFFF);
                for (int w = 4; w < 44; w += 10) { Gfx.rrect(g, cx + w, y + 4, 6, 4, 1, 0xFFBFE8FF); rect(g, cx + w + 1, y + 4, 3, 1, 0xCCFFFFFF); }
                rect(g, cx + 3, y + 12, 6, 2, 0xFF2A2A2A); rect(g, cx + 39, y + 12, 6, 2, 0xFF2A2A2A);   // wheels
                if (head) {
                    int hx = l.dir > 0 ? cx + 44 : cx;
                    Gfx.glow(g, hx + (l.dir > 0 ? 6 : -2), y + 7, 9, 0xFFFFF3B0, 90);
                    rect(g, hx, y + 5, 4, 3, 0xFFFFF3B0);
                }
            }
        } else if (l.type == GRASS) {
            for (int c = 0; c < COLS; c++) {
                int fx = X0 + c * T;
                if (l.obj[c] == 1) {                                                    // a round tree with a trunk and light on top
                    Gfx.ellipse(g, fx + 8, y + 13, 6, 1, 0x33000000);
                    Gfx.rrect(g, fx + 5, y + 6, 4, 8, 1, 0xFF6A4420);
                    rect(g, fx + 5, y + 6, 1, 8, 0xFF8A5A2E);
                    Gfx.ball(g, fx + 7, y - 1, 7, 0xFF3F9B3A);
                    Gfx.disc(g, fx + 5, y - 3, 2, 0xFF6CC85A);
                    rect(g, fx + 8, y + 1, 3, 2, 0xFF2F7A2C);
                } else if (l.obj[c] == 2) {                                             // a mossy stone
                    Gfx.ellipse(g, fx + 8, y + 13, 6, 1, 0x33000000);
                    Gfx.rrect(g, fx + 2, y + 4, 11, 9, 4, 0xFF6E747C);
                    Gfx.rrect(g, fx + 3, y + 5, 9, 7, 3, 0xFF8E949C);
                    rect(g, fx + 4, y + 5, 5, 2, 0xFFC4C9CF);
                    rect(g, fx + 8, y + 10, 4, 2, 0xFF6CA85A);
                }
            }
        }
    }

    private void drawCar(GuiGraphics g, int x, int y, int w, int kind, int dir) {
        int body = kind == 0 ? 0xFFE08A3C : kind == 1 ? 0xFFF58FB8 : 0xFF4A8FE0;
        Gfx.rrect(g, x + 1, y + 4, w, 10, 3, 0x33000000);                                // shadow
        if (kind == 0) {                                                                // a minecart full of ore
            Gfx.rrect(g, x, y + 3, w, 9, 2, 0xFF6E727C);
            Gfx.rrect(g, x + 1, y + 4, w - 2, 7, 2, 0xFFB0B4BC);
            rect(g, x + 2, y + 4, w - 4, 1, 0x66FFFFFF);
            Gfx.rrect(g, x + 3, y + 1, w - 6, 4, 2, body);
            rect(g, x + 5, y + 2, 2, 1, 0xFFFFD08A); rect(g, x + w - 8, y + 2, 2, 1, 0xFFFFD08A);
        } else {
            Gfx.rrect(g, x, y + 2, w, 10, 4, Gfx.darker(body, 0.35f));
            Gfx.rrect(g, x + 1, y + 3, w - 2, 8, 3, body);
            rect(g, x + 3, y + 3, w - 6, 1, 0x77FFFFFF);
            int wx = dir > 0 ? x + w - 10 : x + 3;
            Gfx.rrect(g, wx, y + 4, 7, 4, 1, 0xFF9FD8F5);
            rect(g, wx + 1, y + 4, 4, 1, 0xCCFFFFFF);
            rect(g, dir > 0 ? x + 3 : x + w - 6, y + 5, 3, 2, Gfx.darker(body, 0.15f));   // the back window / roof detail
        }
        Gfx.rrect(g, x + 2, y + 11, 5, 3, 1, 0xFF22222A);
        Gfx.rrect(g, x + w - 7, y + 11, 5, 3, 1, 0xFF22222A);
        rect(g, dir > 0 ? x + w - 2 : x, y + 5, 2, 2, 0xFFFFE066);                     // a headlight
    }

    private void drawRabbit(GuiGraphics g) {
        float p = hopT > 0 ? 1F - hopT / (float) HOP : 1F;
        float rx = fromX + (px - fromX) * p;
        float rr = fromRow + (pr - fromRow) * p;
        int bx = Math.round(rx), by = rowY(rr);
        int lift = hopT > 0 ? Math.round((float) Math.sin(Math.PI * p) * 5F) : 0;
        if (over && dead == DEAD_WATER) {                                               // a splash with droplets
            Gfx.glow(g, bx + 7, by + 8, 10, 0xFFFFFFFF, 80);
            Gfx.disc(g, bx + 7, by + 8, 6, 0xAAFFFFFF);
            for (int i = 0; i < 5; i++) { rect(g, bx + 1 + i * 3, by + 1 - (i % 2) * 3, 2, 2, 0xFFFFFFFF); }
            return;
        }
        if (over && dead == DEAD_CAR) {                                                 // flat, with swirly eyes
            Gfx.rrect(g, bx + 1, by + 9, 12, 4, 2, 0xFFE8DDE6);
            Gfx.rrect(g, bx + 2, by + 9, 10, 3, 2, 0xFFF4EAF0);
            rect(g, bx + 3, by + 8, 3, 2, 0xFFFFB6CC); rect(g, bx + 8, by + 8, 3, 2, 0xFFFFB6CC);
            rect(g, bx + 4, by + 10, 1, 1, 0xFF2A2433); rect(g, bx + 9, by + 10, 1, 1, 0xFF2A2433);
            return;
        }
        int y = by - lift;
        Gfx.ellipse(g, bx + 7, by + 13, Math.max(3, 5 - lift / 2), 1, 0x44000000);       // the shadow shrinks while hopping
        Gfx.rrect(g, bx + 2, y - 4, 4, 8, 2, 0xFFE8DDE6); Gfx.rrect(g, bx + 8, y - 4, 4, 8, 2, 0xFFE8DDE6);    // ears
        rect(g, bx + 3, y - 2, 2, 5, 0xFFFFB6CC); rect(g, bx + 9, y - 2, 2, 5, 0xFFFFB6CC);
        Gfx.rrect(g, bx + 1, y + 2, 12, 9, 4, 0xFFE8DDE6);                              // head
        Gfx.rrect(g, bx + 2, y + 3, 10, 7, 3, 0xFFFFFFFF);
        rect(g, bx + 4, y + 5, 2, 2, 0xFF2A2433); rect(g, bx + 8, y + 5, 2, 2, 0xFF2A2433);
        rect(g, bx + 4, y + 5, 1, 1, 0xFFFFFFFF); rect(g, bx + 8, y + 5, 1, 1, 0xFFFFFFFF);
        rect(g, bx + 6, y + 7, 2, 1, 0xFFFF8FB8);
        rect(g, bx + 3, y + 8, 2, 1, 0x77FF8FB8); rect(g, bx + 9, y + 8, 2, 1, 0x77FF8FB8);   // cheeks
        Gfx.rrect(g, bx + 3, y + 10, 8, 4, 2, 0xFFF4EAF0);                              // body
        rect(g, bx + 2, y + 11, 2, 2, 0xFFFFFFFF);                                       // fluffy tail
        rect(g, bx + 3, y + 13, 3, 1, 0xFFFFB6CC); rect(g, bx + 8, y + 13, 3, 1, 0xFFFFB6CC);
        if (over && dead == DEAD_PHANTOM) {                                             // the phantom has it
            int hy = by - 12;
            Gfx.glow(g, bx + 7, hy + 4, 18, 0xFF7CFF7C, 70);
            Gfx.rrect(g, bx - 8, hy + 2, 12, 5, 2, 0xFF3A3F8A); Gfx.rrect(g, bx + 10, hy + 2, 12, 5, 2, 0xFF3A3F8A);
            Gfx.rrect(g, bx + 2, hy, 10, 8, 3, 0xFF4A52A8);
            rect(g, bx + 3, hy + 3, 2, 2, 0xFF7CFF7C); rect(g, bx + 9, hy + 3, 2, 2, 0xFF7CFF7C);
        }
    }

    // ---------- texts ----------
    @Override
    public Component endTitle() {
        return Component.translatable("cutemod.rabbit.dead." + Math.max(0, dead));
    }

    @Override
    public String hintKey() { return "cutemod.hint.rabbit"; }
}
