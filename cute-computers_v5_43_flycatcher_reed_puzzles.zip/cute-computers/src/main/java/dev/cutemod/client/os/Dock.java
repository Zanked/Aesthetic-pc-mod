package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/**
 * The Dock: a glass strip with the icons of the apps the player pinned (see {@link DockLayout}). The icon
 * under the mouse (and its neighbours) grows, the app that is running has a little dot below it.
 * An icon can be dragged to another place; the others make room for it.
 */
public class Dock {
    public static final int HEIGHT = 28;
    private static final int BASE = 15, MAX = 28, GAP = 2, RADIUS = 38, PILL_H = 24;
    private static final int EMPTY_W = 150;

    private final float[] size = new float[DockLayout.MAX + 2];     // one slot more: a dragged icon that is not pinned yet
    private final float[] x = new float[DockLayout.MAX + 2];
    private int[] order = new int[0];          // app ids in the order they are drawn
    private int bx, by, bw, bottom;
    private float pillX0, pillX1;

    // drag state (set by the computer screen)
    private int dragApp = -1, dragSlot, dragX, dragY;
    private boolean dragRemove;

    public void setDrag(int app, int slot, int mx, int my, boolean remove) {
        dragApp = app; dragSlot = slot; dragX = mx; dragY = my; dragRemove = remove;
    }

    public void clearDrag() { dragApp = -1; }

    private void buildOrder() {
        List<Integer> l = new ArrayList<>(DockLayout.list());
        if (dragApp >= 0) {
            l.remove((Integer) dragApp);
            if (!dragRemove) l.add(Math.max(0, Math.min(l.size(), dragSlot)), dragApp);
        }
        order = l.stream().mapToInt(Integer::intValue).toArray();
    }

    /** Recompute where every icon is for the given mouse position (the box is the Dock area on screen). */
    private void layout(int bx, int by, int bw, int mx, int my, boolean strict) {
        this.bx = bx; this.by = by; this.bw = bw;
        this.bottom = by + HEIGHT - 5;
        buildOrder();
        boolean near = dragApp < 0 && mx >= bx && mx < bx + bw && my >= (strict ? by : by - 16) && my < by + HEIGHT;
        int n = order.length;
        if (n == 0) { pillX0 = bx + (bw - EMPTY_W) / 2f; pillX1 = pillX0 + EMPTY_W; return; }
        float baseTotal = n * BASE + (n - 1) * GAP, start = bx + (bw - baseTotal) / 2f, total = (n - 1) * GAP;
        for (int i = 0; i < n; i++) {
            float cx = start + i * (BASE + GAP) + BASE / 2f;
            float f = near ? Math.max(0f, 1f - Math.abs(mx - cx) / RADIUS) : 0f;
            f = f * f * (3 - 2 * f);
            size[i] = BASE + (MAX - BASE) * f;
            total += size[i];
        }
        float px = bx + (bw - total) / 2f;
        pillX0 = px - 8;
        for (int i = 0; i < n; i++) { x[i] = px; px += size[i] + GAP; }
        pillX1 = px - GAP + 8;
    }

    /** Screen x of the middle of this app's icon (where its window grows from); the middle of the Dock if it is not pinned. */
    public float centerX(int app, int bx, int bw) {
        for (int i = 0; i < order.length; i++) if (order[i] == app) return x[i] + size[i] / 2f;
        return bx + bw / 2f;
    }

    /** True if the mouse is on the glass strip itself (also between the icons): a right click there makes a new folder. */
    public boolean overBar(int mx, int my) {
        int y0 = by + HEIGHT - 1 - PILL_H;
        return mx >= pillX0 && mx < pillX1 && my >= y0 && my < by + HEIGHT;
    }

    /** The app id of the icon under the mouse, or -1. */
    public int hit(int bx, int by, int bw, int mx, int my, boolean strict) {
        if (strict && my < by) return -1;          // inside an app only the Dock strip itself counts, so a game's bottom edge stays a game
        layout(bx, by, bw, mx, my, strict);
        for (int i = 0; i < order.length; i++) {
            if (mx >= x[i] && mx < x[i] + size[i] && my >= bottom - size[i] && my < bottom + 4) return order[i];
        }
        return -1;
    }

    /** Slot of the Dock a dragged icon would be dropped on, for this mouse x. */
    public int slotAt(int bx, int bw, int mx) {
        int n = DockLayout.list().size() - (dragApp >= 0 && DockLayout.pinned(dragApp) ? 1 : 0);
        n = Math.max(0, n);
        float baseTotal = (n + 1) * BASE + n * GAP, start = bx + (bw - baseTotal) / 2f;
        int slot = Math.round((mx - start) / (BASE + GAP) - 0.5f);
        return Math.max(0, Math.min(n, slot));
    }

    public void render(GuiGraphics g, Desktop desktop, App current, int body, int bx, int by, int bw, int mx, int my, boolean strict,
                       java.util.Set<Integer> running) {
        layout(bx, by, bw, mx, my, strict);
        int active = desktop.activeIndex(current);
        var font = Minecraft.getInstance().font;

        // the glass pill
        int y0 = by + HEIGHT - 1 - PILL_H, y1 = by + HEIGHT - 1;
        if (strict && !Theme.retro() && !Theme.pixel()) {                  // inside an app (the Pixel pill is solid itself): a solid backing so the app does not shine through the glass
            pill(g, Math.round(pillX0) - 1, y0 - 1, Math.round(pillX1) + 1, y1 + 1, solidBacking());
        }
        if (Theme.custom()) {
            Theme.dockPill(g, Math.round(pillX0), y0, Math.round(pillX1), y1);
        } else {
            pill(g, Math.round(pillX0) - 1, y0 - 1, Math.round(pillX1) + 1, y1 + 1, 0x33FFFFFF);
            pill(g, Math.round(pillX0), y0, Math.round(pillX1), y1, 0x88202030);
        }
        if (order.length == 0) {
            String s = tr("cutemod.os.dock.empty");
            int sw = font.width(s);
            CuteFont.draw(g, font, s, bx + (bw - sw) / 2, y0 + 8, Theme.pixel() ? 0xFF5B6678 : 0xCCFFFFFF, false);
        }

        int hovered = -1;
        for (int i = 0; i < order.length; i++) {
            int app = order[i];
            float s = size[i], top = bottom - s;
            boolean ghost = app == dragApp;
            g.pose().pushPose();
            g.pose().translate(x[i], top, 0);
            g.pose().scale(s / 32f, s / 32f, 1f);
            if (!ghost) Desktop.drawIcon(g, app, 0, 0, body);
            g.pose().popPose();
            if (ghost) {                                  // the gap where the dragged icon will land
                g.fill(Math.round(x[i]), Math.round(bottom - BASE), Math.round(x[i] + s), Math.round(bottom), Theme.pixel() ? 0x330B57D0 : 0x33FFFFFF);
                continue;
            }
            if (app == active || running.contains(app))      // white dot: in front, dim dot: running in the background
                g.fill(Math.round(x[i] + s / 2f) - 1, by + HEIGHT - 3, Math.round(x[i] + s / 2f) + 1, by + HEIGHT - 1, Theme.pixel() ? (app == active ? 0xFF0B57D0 : 0x880B57D0) : app == active ? (Hell.active() ? 0xFFFF3040 : 0xFFFFFFFF) : (Hell.active() ? 0x88B01020 : 0x88FFFFFF));
            int b = desktop.badge(app);
            if (b > 0) {
                String n = b > 9 ? "9+" : Integer.toString(b);
                int r = Math.max(4, font.width(n) / 2 + 2), cx = Math.round(x[i] + s) - 2, cy = Math.round(top) + 2;
                g.pose().pushPose();
                g.pose().translate(0, 0, 50);
                g.fill(cx - r - 1, cy - 5, cx + r + 1, cy + 5, Hell.active() ? 0xFF1A0004 : 0xFFFFFFFF);
                g.fill(cx - r, cy - 4, cx + r, cy + 4, Hell.active() ? 0xFFD01020 : 0xFFE5484D);
                g.pose().pushPose();
                g.pose().translate(cx - font.width(n) / 4f, cy - 3, 0);
                g.pose().scale(0.5f, 0.5f, 1f);
                CuteFont.draw(g, font, n, 0, 0, 0xFFFFFFFF, false);
                g.pose().popPose();
                g.pose().popPose();
            }
            if (dragApp < 0 && mx >= x[i] && mx < x[i] + s && my >= top && my < bottom + 4) hovered = i;
        }

        // label above the icon under the mouse
        if (hovered >= 0) {
            String label = desktop.label(order[hovered]);
            int w = font.width(label) + 8, cx = Math.round(x[hovered] + size[hovered] / 2f);
            int lx = Math.max(bx + 2, Math.min(bx + bw - w - 2, cx - w / 2)), ly = Math.round(bottom - size[hovered]) - 14;
            pill(g, lx, ly, lx + w, ly + 12, Hell.active() ? 0xEE2A0508 : 0xEE1B1422);
            CuteFont.draw(g, font, label, lx + 4, ly + 2, Hell.active() ? Hell.PALE : 0xFFFFFFFF, false);
        }

        // the icon that is being dragged follows the mouse (above everything)
        if (dragApp >= 0) {
            g.pose().pushPose();
            g.pose().translate(dragX - 10, dragY - 10, 60);
            g.pose().scale(20 / 32f, 20 / 32f, 1f);
            Desktop.drawIcon(g, dragApp, 0, 0, body);
            g.pose().popPose();
            if (dragRemove) {
                String s = tr("cutemod.os.dock.remove");
                int w = font.width(s) + 8, lx = Math.max(bx + 2, Math.min(bx + bw - w - 2, dragX - w / 2)), ly = dragY - 26;
                g.pose().pushPose();
                g.pose().translate(0, 0, 60);
                pill(g, lx, ly, lx + w, ly + 12, 0xEEB03A3A);
                CuteFont.draw(g, font, s, lx + 4, ly + 2, 0xFFFFFFFF, false);
                g.pose().popPose();
            }
        }
    }

    /** Opaque color under the glass pill while an app is open (matches the tint of the current theme). */
    private static int solidBacking() {
        if (Theme.hell()) return 0xFF1A0004;
        if (Theme.pixel()) return 0xFFF1F4FB;
        if (Theme.sunny()) return 0xFFF0A020;
        if (Theme.anime()) return 0xFFB0408F;
        if (Theme.stranger()) return 0xFF1A1240;
        if (Theme.kawaii()) return 0xFFE070A8;
        if (Theme.custom()) return 0xFF2570B8;
        return 0xFF202030;
    }

    private static String tr(String key) {
        return net.minecraft.network.chat.Component.translatable(key).getString();
    }

    /** A rectangle with rounded corners (no overlapping fills, so translucent colors stay even). */
    public static void pill(GuiGraphics g, int x0, int y0, int x1, int y1, int argb) {
        g.fill(x0 + 2, y0, x1 - 2, y0 + 1, argb);
        g.fill(x0 + 1, y0 + 1, x1 - 1, y0 + 2, argb);
        g.fill(x0, y0 + 2, x1, y1 - 2, argb);
        g.fill(x0 + 1, y1 - 2, x1 - 1, y1 - 1, argb);
        g.fill(x0 + 2, y1 - 1, x1 - 2, y1, argb);
    }
}
