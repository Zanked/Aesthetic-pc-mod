package dev.cutemod.client.os;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.function.Consumer;

/**
 * Pictures made of thousands of rectangles (animated wallpapers, the covers of the books, the lights of the shelf) are drawn
 * ONCE into a texture by a {@link SoftCanvas}; every frame after that is a single textured quad. Animated pictures are
 * redrawn into the same texture 20 times a second (the animations of the OS run at 20 steps a second anyway).
 */
public final class TexCache {
    private TexCache() {}

    public static final class Tex {
        final ResourceLocation rl;
        final DynamicTexture tex;
        final int w, h;
        long step = Long.MIN_VALUE;   // the animation step it shows now
        public int tag = Integer.MIN_VALUE;  // what it shows (a wallpaper number, a night level)
        boolean smooth;               // linear filtering is on (for pictures that are drawn smaller than they are)

        Tex(ResourceLocation rl, DynamicTexture tex, int w, int h) { this.rl = rl; this.tex = tex; this.w = w; this.h = h; }
    }

    private static SoftCanvas canvas;
    private static final HashMap<String, Tex> MAP = new HashMap<>();
    private static int counter;

    /** The texture for a key; a new one if there is none yet or its size has changed. */
    public static Tex get(String key, int w, int h) {
        Tex t = MAP.get(key);
        if (t != null && t.w == w && t.h == h) return t;
        Minecraft mc = Minecraft.getInstance();
        if (t != null) { mc.getTextureManager().release(t.rl); t.tex.close(); }
        ResourceLocation rl = ResourceLocation.fromNamespaceAndPath("cutemod", "baked/t" + (counter++));
        DynamicTexture dt = new DynamicTexture(w, h, false);
        mc.getTextureManager().register(rl, dt);
        t = new Tex(rl, dt, w, h);
        MAP.put(key, t);
        return t;
    }

    /** Draws into the texture: the drawing uses its own coordinates, the point (ox, oy) of it lands in the corner of the texture. */
    public static void render(Tex t, int ox, int oy, Consumer<GuiGraphics> drawing) {
        if (canvas == null) canvas = new SoftCanvas(Minecraft.getInstance());
        canvas.begin(t.w, t.h, ox, oy);
        drawing.accept(canvas);
        NativeImage img = t.tex.getPixels();
        if (img == null) return;
        int[] px = canvas.pixels();
        for (int y = 0; y < t.h; y++) {
            for (int x = 0; x < t.w; x++) {
                int c = px[y * t.w + x];
                img.setPixelRGBA(x, y, (c & 0xFF00FF00) | (c >> 16 & 255) | (c & 255) << 16);   // ARGB -> ABGR
            }
        }
        t.tex.upload();
    }

    /**
     * Draws a picture into a plain array of ARGB pixels (w x h, the point (0, 0) of the drawing is its corner) and returns the array:
     * the part of a scene that never moves is baked like this once, and copied into the texture on every frame after that
     * (see {@link SoftCanvas#loadStill}). It uses the same canvas as {@link #render}, so it must not be called from inside a drawing.
     */
    static int[] bake(int w, int h, Consumer<GuiGraphics> drawing) {
        if (canvas == null) canvas = new SoftCanvas(Minecraft.getInstance());
        canvas.begin(w, h, 0, 0);
        drawing.accept(canvas);
        return java.util.Arrays.copyOf(canvas.pixels(), w * h);
    }

    /** Same, but only when the animation has moved on to its next step (20 a second) or the picture has changed. */
    static void renderStep(Tex t, int tag, int ox, int oy, Consumer<GuiGraphics> drawing) {
        long step = System.currentTimeMillis() / 50L;
        if (t.step == step && t.tag == tag) return;
        t.step = step; t.tag = tag;
        render(t, ox, oy, drawing);
    }

    /** Puts the texture on the screen with its corner at (x, y). */
    public static void blit(GuiGraphics g, Tex t, int x, int y) {
        g.flush();   // fill() only collects rectangles in a batch, blit() draws at once: without this the texture goes UNDER everything drawn before it
        RenderSystem.enableBlend();            // blit() does not turn it on: see-through pixels would come out solid
        RenderSystem.defaultBlendFunc();
        g.blit(t.rl, x, y, 0F, 0F, t.w, t.h, t.w, t.h);
    }

    /** A piece of the texture (w x h pixels from the point (u, v) of it) with its corner at (x, y): the part of a big picture that is on the screen. */
    public static void blitRegion(GuiGraphics g, Tex t, int x, int y, int u, int v, int w, int h) {
        g.flush();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        g.blit(t.rl, x, y, w, h, (float) u, (float) v, w, h, t.w, t.h);
    }

    /** Linear filtering, once: a picture shown at 41 % with the nearest-pixel filter sparkles. */
    static void smooth(Tex t) {
        if (t.smooth) return;
        t.smooth = true;
        t.tex.setFilter(true, false);
    }

    /** The texture stretched into the box (x, y, w, h). */
    static void blitScaled(GuiGraphics g, Tex t, int x, int y, int w, int h) {
        g.flush();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        g.blit(t.rl, x, y, w, h, 0F, 0F, t.w, t.h, t.w, t.h);
    }
}
