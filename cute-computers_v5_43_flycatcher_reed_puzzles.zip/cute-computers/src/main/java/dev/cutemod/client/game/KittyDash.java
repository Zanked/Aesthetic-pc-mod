package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Kitty Dash: an endless runner with a view from behind, in the spirit of Subway Surfers. A pink kitty runs down a
 * track with 3 lanes. Change lanes (A / D or the arrows), jump (W / Up / Space) and slide (S / Down).
 * Carts block a lane (go around), fences must be jumped, hanging signs must be slid under.
 * Coins give points, gems give ten at once. The first crash makes the creeper catch up (one heart left); if you crash again
 * before it falls back, it is over. Score = distance / 30 + points of coins and gems.
 * Mouse: click the left / right third to change lane, the upper middle to jump, the lower middle to slide. M: back to the menu (solo).
 *
 * <h3>Bonuses</h3>
 * Rocket pack (fly over everything), magnet (pulls in every coin), shield (takes one crash, or one attack), x2 (coins are worth double),
 * super sneakers (a higher jump and a second jump in the air), fish (heals you, or +10 when you are fine), gem (+10)
 * and the mystery box (a random bonus; online, sometimes an attack on your opponent).
 *
 * <h3>Online race</h3>
 * Two players run the SAME track (the server hands out one seed) at the same time. You see the other kitty as a ghost on the
 * track. Mystery boxes can send a barrier (a fence across all lanes) or goo (slows down) to the opponent; a shield blocks it.
 * When both runs are over the higher score wins; if the other is already done, passing their score wins at once.
 * Closing the game or leaving gives the race to the opponent. The server is in dev.cutemod.net.DashServer.
 *
 * The world is drawn in a simple perspective: an object at depth z is scaled by k = 1 / (1 + z / Z0).
 */
public class KittyDash extends MiniGame {
    private static final int CX = W / 2, HOR = 40, BOT = 130;
    private static final double Z0 = 24, ZFAR = 170, LW = 42, BED = 66;
    private static final int TRAIN = 0, FENCE = 1, SIGN = 2, COIN = 3, JET = 4,
            MAGNET = 5, SHIELD = 6, DOUBLE = 7, BOOTS = 8, FISH = 9, GEM = 10, BOX = 11;
    private static final int[] TRAIN_COL = {0xFF5BA8F0, 0xFFFF9C5B, 0xFFB57BD6, 0xFF6FCF8B, 0xFFF2C94C};
    private static final int PINK = 0xFFF58FB8, PINK_D = 0xFFD9648F;

    private static final int MENU = 0, LOBBY = 1, PLAY = 2;
    private static final int SOLO = 0, ONLINE = 1;
    private static final int READY = 100;
    private static final int JET_T = 320, MAGNET_T = 600, SHIELD_T = 1200, DOUBLE_T = 900, BOOTS_T = 700, GOO_T = 300;
    private static final int ATK_BARRIER = 1, ATK_GOO = 2;

    private static final class Obj {
        final int type, lane, span, color;
        final double len;
        double z, y, lx;                                                // lx: where it is across the track (a lane number; the magnet moves it)

        Obj(int type, int lane, int span, double z, double len, double y, int color) {
            this.type = type; this.lane = lane; this.span = span; this.z = z; this.len = len; this.y = y; this.color = color;
            this.lx = lane;
        }
    }

    private final List<Obj> things = new ArrayList<>();
    private final List<Obj> stage = new ArrayList<>();                  // the chunk of track that is being made
    private final List<double[]> deco = new ArrayList<>();       // x, world z, kind (0 green tree, 1 cherry tree, 2 lamp)
    private final List<double[]> fx = new ArrayList<>();         // particles: x, y, vx, vy, life, color

    private Random trk = new Random();                                  // the track: the same seed gives the same track
    private double dist, v, laneF, yj, vy, nextSeg, decoNext;
    private int lane, prevLane, slide, jet, ready, ticks, run, coins, coinPts, stumble, invuln, flash, lastSafe, jumpBuf, combo, comboT, dead;
    private int magnet, shield, dbl, boots, goo, airJump, bonusIn;
    private int toastT, menuTick;
    private String toastText = "";
    private boolean dropSlide, decoLeft;

    // game flow
    private int state = MENU, mode = SOLO;
    private boolean lastSolo;                                           // after a solo run, restart goes straight into another one
    private boolean finished, sentFinish;                               // online: my run is over / the server knows
    private int resultKind, startedNo = -1, seenVersion = -1, sendT, noticeT, waitT;
    private String noticeKey = "", oppName = "";
    // the ghost of the other player
    private double gDist, gVel, gLane = 1, tDist;
    private int gFlags, gAge;

    private final Random menuRnd = new Random();

    private static String tr(String key, Object... a) { return Component.translatable(key, a).getString(); }

    // ---------- game flow ----------
    @Override
    public void reset() {
        score = 0; over = false; resultKind = 0;
        if (DashNet.inMatch()) DashNet.leaveGame();                     // closing the game or starting again gives up a race
        noticeT = 0;
        if (lastSolo) { startSolo(); return; }                          // "one more run"
        state = MENU; mode = SOLO;
        initWorld(menuRnd.nextLong());
        ready = 0;
        DashNet.request();
    }

    private void initWorld(long seed) {
        things.clear(); stage.clear(); deco.clear(); fx.clear();
        trk = new Random(seed);
        dist = 0; v = 1.0; lane = prevLane = 1; laneF = 1; yj = 0; vy = 0;
        slide = 0; jet = 0; ready = READY; ticks = 0; run = 0; coins = 0; coinPts = 0; stumble = 0; invuln = 0; flash = 0;
        magnet = shield = dbl = boots = goo = airJump = 0;
        lastSafe = 1; jumpBuf = 0; combo = 0; comboT = 0; dead = 0; dropSlide = false;
        toastT = 0; finished = sentFinish = false; sendT = 0; waitT = 0;
        gDist = tDist = 0; gVel = 0; gLane = 1; gFlags = 0; gAge = 0;
        nextSeg = 60; bonusIn = 2;
        decoNext = 0;
        while (decoNext < ZFAR + 20) addDeco();
    }

    private void startSolo() {
        mode = SOLO; state = PLAY; lastSolo = true;
        score = 0; over = false; resultKind = 0;
        initWorld(new Random().nextLong());
        pling(1.2F);
    }

    private void startOnline() {
        mode = ONLINE; state = PLAY; lastSolo = false;
        score = 0; over = false; resultKind = 0;
        startedNo = DashNet.matchNo;
        oppName = DashNet.opponent;
        initWorld(DashNet.seed * 0x9E3779B97F4A7C15L + 12345L);
        seenVersion = -1;
        pling(1.2F);
    }

    private void toMenu() {
        lastSolo = false; state = MENU; mode = SOLO; score = 0;
        initWorld(menuRnd.nextLong());
        ready = 0;
        DashNet.request();
    }

    private void addDeco() {
        decoLeft = !decoLeft;
        boolean left = decoLeft;
        double x = (left ? -1 : 1) * (BED + 16 + rnd.nextInt(34));
        int kind = rnd.nextInt(10) < 3 ? 2 : rnd.nextInt(2);
        deco.add(new double[]{x, decoNext + rnd.nextInt(8), kind});
        decoNext += 22;
    }

    private static double laneX(double lane) { return (lane - 1) * LW; }

    private void toast(String text) { toastText = text; toastT = 110; }

    // ---------- input ----------
    @Override
    public boolean key(int keyCode) {
        if (over) return false;
        if (state == MENU) {
            if (keyCode == KEY_SPACE || keyCode == 257 || keyCode == 49) { startSolo(); return true; }
            if (keyCode == 50) { state = LOBBY; DashNet.request(); pling(1.0F); return true; }
            return false;
        }
        if (state == LOBBY) {
            if (keyCode == 259 || keyCode == 66) { lobbyBack(); return true; }      // backspace / B
            return false;
        }
        if (mode == SOLO && keyCode == 77) { toMenu(); return true; }               // M
        if (finished) return false;
        if (keyCode == KEY_LEFT || keyCode == 65) { move(-1); return true; }
        if (keyCode == KEY_RIGHT || keyCode == 68) { move(1); return true; }
        if (keyCode == KEY_UP || keyCode == 87 || keyCode == KEY_SPACE) { jump(); return true; }
        if (keyCode == KEY_DOWN || keyCode == 83) { roll(); return true; }
        return false;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        if (state == MENU) return menuClick(x, y);
        if (state == LOBBY) return lobbyClick(x, y);
        if (finished) return true;
        if (x < W / 3) move(-1);
        else if (x > W * 2 / 3) move(1);
        else if (y < H / 2) jump();
        else roll();
        return true;
    }

    private void move(int d) {
        int n = Math.max(0, Math.min(2, lane + d));
        if (n != lane) { prevLane = lane; lane = n; beep(); }
    }

    private void jump() {
        if (jet > 0) return;
        if (yj <= 0.01) {
            vy = boots > 0 ? 4.1 : 3.3; slide = 0; jumpBuf = 0; pling(boots > 0 ? 1.7F : 1.4F);
            airJump = boots > 0 ? 1 : 0;
        } else if (boots > 0 && airJump > 0) {                          // sneakers: a second jump in the air
            airJump--; vy = 3.6; dropSlide = false; pling(1.9F);
            burst(CX + laneX(laneF), BOT - yj, 6, 0xFF8FF0A8);
        } else jumpBuf = 8;                                             // pressed a bit early: jump as soon as we land
    }

    private void roll() {
        if (jet > 0) return;
        if (yj > 0.01) { vy = Math.min(vy, -4.6); dropSlide = true; }   // fall fast, roll on landing
        else { slide = 34; pling(0.8F); }
    }

    // ---------- the game ----------
    @Override
    public void tick() {
        ticks++;
        if (state != PLAY) {                                            // the menu and the lobby: the track runs by slowly
            menuTick++;
            dist += 0.6;
            for (double[] d : deco) d[1] -= 0.6;
            deco.removeIf(d -> d[1] < -14);
            decoNext -= 0.6;
            while (decoNext < ZFAR + 20) addDeco();
            netTick();
            return;
        }
        if (mode == ONLINE) onlineTick();
        if (over) return;
        if (finished) {                                                 // my run is over, the other one is still going
            if (++waitT % 120 == 0) DashNet.request();                  // also tells the server we are still here
            return;
        }
        if (ready > 0) { ready--; return; }
        run++;
        double lvl = Math.min(1.0, run / 6000.0);
        v = 1.0 + lvl * 1.0;
        if (jet > 0) v *= 1.25;
        if (goo > 0) v *= 0.62;
        dist += v;
        score = (int) (dist / 30) + coinPts;
        if (invuln > 0) invuln--;
        if (flash > 0) flash--;
        if (toastT > 0) toastT--;
        if (comboT > 0 && --comboT == 0) combo = 0;
        if (magnet > 0) magnet--;
        if (shield > 0) shield--;
        if (dbl > 0) dbl--;
        if (boots > 0) boots--;
        if (goo > 0) goo--;
        if (stumble > 0) { stumble--; if (stumble % 120 == 60) growl(G_HISS); }          // the creeper hisses behind you

        // lanes and jumping
        laneF += (lane - laneF) * 0.3;
        if (jet > 0) {
            jet--;
            yj += (46 - yj) * 0.12; vy = 0;
            if (jet == 0) invuln = Math.max(invuln, 90);
        } else if (yj > 0 || vy > 0) {
            vy -= 0.19; yj += vy;
            if (yj <= 0) {
                yj = 0; vy = 0;
                if (dropSlide) { slide = 28; dropSlide = false; }
                if (jumpBuf > 0) jump();
            }
        }
        if (jumpBuf > 0) jumpBuf--;
        if (slide > 0) slide--;

        // scenery
        for (double[] d : deco) d[1] -= v;
        deco.removeIf(d -> d[1] < -14);
        decoNext -= v;
        while (decoNext < ZFAR + 20) { addDeco(); }

        // new things
        nextSeg -= v;
        if (nextSeg <= 0) {
            double len = spawnSegment(lvl);
            nextSeg = len + 34 + 18 * lvl;
        }

        // move things and meet them
        for (int i = things.size() - 1; i >= 0; i--) {
            Obj o = things.get(i);
            o.z -= v;
            boolean money = o.type == COIN || o.type == GEM;
            if (money && magnet > 0 && o.z < 80 && o.z > 0) {          // the magnet pulls the coins in
                o.z -= 1.4;
                o.lx += (laneF - o.lx) * 0.14;
                o.y += (12 - o.y) * 0.1;
            }
            double zb = o.z + o.len;
            if (zb < -12) { things.remove(i); continue; }
            if (o.z > 4 || zb < -4) continue;                           // not at the kitty
            boolean inLane = laneF > o.lane - 0.62 && laneF < o.lane + o.span - 1 + 0.62;
            if (money) {
                double dl = Math.abs(laneF - o.lx);
                double mid = yj + (slide > 0 ? 6 : 13);
                boolean got = (dl < 0.62 && Math.abs(mid - o.y) < 15)
                        || (magnet > 0 && dl < 1.0)
                        || (jet > 0 && Math.abs(laneF - o.lane) < 1.6);
                if (got) { takeCoin(o); things.remove(i); }
            } else if (o.type >= JET && o.type != COIN && o.type != GEM) {
                if (inLane) { takePickup(o); things.remove(i); }
            } else if (inLane && invuln <= 0 && jet <= 0) {
                boolean hit = switch (o.type) {
                    case TRAIN -> true;
                    case FENCE -> yj < 12;
                    default -> !(slide > 0 && yj < 3);                  // a sign: only a slide gets under it
                };
                if (!hit) continue;
                boolean side = o.type == TRAIN && o.z < -1.5;           // we ran into the side of a cart: bounce back
                if (side) { lane = prevLane; }
                else things.remove(i);
                crash(o.type);
                if (over || finished) return;
            }
        }

        // particles
        for (int i = fx.size() - 1; i >= 0; i--) {
            double[] p = fx.get(i);
            p[0] += p[2]; p[1] += p[3]; p[3] += 0.12; p[4]--;
            if (p[4] <= 0) fx.remove(i);
        }
    }

    private void takeCoin(Obj o) {
        int worth = (o.type == GEM ? 10 : 2) * (dbl > 0 ? 2 : 1);
        coins += o.type == GEM ? 5 : 1;
        coinPts += worth;
        combo++; comboT = 50;
        if (o.type == GEM) { sound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.5F, 0.6F); pling(1.8F); }
        else pling(1.2F + Math.min(combo, 12) * 0.06F);
        burst(CX + laneX(o.lx) * 0.9, BOT - 16 - o.y * 0.5, o.type == GEM ? 8 : 4, o.type == GEM ? 0xFF58E0F0 : 0xFFFFD84A);
    }

    private void takePickup(Obj o) {
        burst(CX + laneX(o.lx), BOT - 16 - o.y * 0.5, 8, 0xFFFFFFFF);
        if (o.type == BOX) openBox(); else applyBonus(o.type);
    }

    /** The effect of a bonus (from the track or from a mystery box). */
    private void applyBonus(int type) {
        switch (type) {
            case JET -> { jet = JET_T; vy = 0; slide = 0; pling(1.9F); toast(tr("cutemod.dash.bonus.jet")); }
            case MAGNET -> { magnet = MAGNET_T; sound(SoundEvents.BEACON_ACTIVATE, 1.6F, 0.6F); toast(tr("cutemod.dash.bonus.magnet")); }
            case SHIELD -> { shield = SHIELD_T; sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.9F, 0.9F); pling(1.5F); toast(tr("cutemod.dash.bonus.shield")); }
            case DOUBLE -> { dbl = DOUBLE_T; pling(1.7F); sound(SoundEvents.BELL_BLOCK, 1.6F, 0.5F); toast(tr("cutemod.dash.bonus.double")); }
            case BOOTS -> { boots = BOOTS_T; airJump = 1; pling(1.6F); toast(tr("cutemod.dash.bonus.boots")); }
            case FISH -> {
                sound(SoundEvents.GENERIC_EAT, 1.3F, 0.7F);
                if (stumble > 0) { stumble = 0; invuln = Math.max(invuln, 60); toast(tr("cutemod.dash.bonus.fish_heal")); }
                else { coinPts += 10; toast(tr("cutemod.dash.bonus.fish")); }
            }
            default -> { coinPts += 20; sound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.5F, 0.6F); toast(tr("cutemod.dash.bonus.gem")); }
        }
    }

    private static final int[] BOX_POOL = {JET, MAGNET, SHIELD, DOUBLE, BOOTS, FISH, GEM};

    private void openBox() {
        if (mode == ONLINE && !DashNet.oppDone && rnd.nextInt(100) < 40) {          // an attack on the opponent
            int kind = rnd.nextBoolean() ? ATK_BARRIER : ATK_GOO;
            DashNet.attack(kind);
            sound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.2F, 0.6F);
            toast(tr(kind == ATK_BARRIER ? "cutemod.dash.atk.sent.1" : "cutemod.dash.atk.sent.2", oppName));
            return;
        }
        applyBonus(BOX_POOL[rnd.nextInt(BOX_POOL.length)]);
    }

    /** An attack from the other player. A shield blocks it. */
    private void applyAttack(int kind) {
        if (finished) return;
        if (shield > 0) {
            shield = 0; invuln = Math.max(invuln, 40);
            sound(SoundEvents.GLASS_HIT, 0.8F, 0.8F);
            burst(CX + laneX(laneF), BOT - 16, 10, 0xFF60C8FF);
            toast(tr("cutemod.dash.atk.blocked", oppName));
            return;
        }
        if (kind == ATK_BARRIER) {
            // a fence across all lanes, in the middle of the gap before the next chunk of track, so it can always be jumped
            double z = ZFAR + Math.max(0, nextSeg) - 17 - 9 * Math.min(1.0, run / 6000.0);
            things.add(new Obj(FENCE, 0, 3, z, 3, 0, 0xFFFFC83A));
            sound(SoundEvents.WOODEN_DOOR_CLOSE, 0.7F, 0.7F);
        } else {
            goo = GOO_T;
            sound(SoundEvents.SLIME_SQUISH, 0.7F, 0.9F);
        }
        toast(tr(kind == ATK_BARRIER ? "cutemod.dash.atk.got.1" : "cutemod.dash.atk.got.2", oppName));
    }

    private void crash(int type) {
        if (shield > 0) {                                               // the shield takes the hit
            shield = 0; invuln = 70; flash = 6;
            sound(SoundEvents.GLASS_HIT, 0.7F, 0.9F);
            burst(CX + laneX(laneF), BOT - 16, 14, 0xFF60C8FF);
            toast(tr("cutemod.dash.bonus.shield_pop"));
            return;
        }
        flash = 10;
        burst(CX + laneX(laneF), BOT - 14, 12, 0xFFFFFFFF);
        dev.cutemod.client.os.Sfx.ui(SoundEvents.NOTE_BLOCK_BASS.value(), 0.55F, 0.7F);
        combo = 0;
        if (stumble > 0) {                                              // the creeper has caught up
            dead = type == TRAIN ? 0 : type == FENCE ? 1 : 2;
            sound(net.minecraft.sounds.SoundEvents.GENERIC_EXPLODE, 1.0F, 0.7F);           // the creeper goes off
            score = (int) (dist / 30) + coinPts;
            if (mode == ONLINE) endRun(); else over = true;
        } else {
            stumble = 480; invuln = 70;
            growl(G_HISS);
        }
    }

    private void burst(double x, double y, int n, int col) {
        for (int i = 0; i < n; i++)
            fx.add(new double[]{x, y, (rnd.nextDouble() - 0.5) * 3, -rnd.nextDouble() * 2.5, 16 + rnd.nextInt(10), col});
    }

    // ---------- online ----------
    private int flags() {
        return (stumble > 0 ? 1 : 0) | (shield > 0 ? 2 : 0) | (jet > 0 ? 4 : 0) | (yj > 6 ? 8 : 0) | (slide > 0 ? 16 : 0);
    }

    /** My run is over: tell the server and wait for the other player. */
    private void endRun() {
        finished = true;
        if (!sentFinish) { sentFinish = true; DashNet.finish(score); }
        DashNet.request();
    }

    private void netTick() {
        int n = DashNet.takeNotice();
        if (n != 0) { noticeKey = "cutemod.dash.notice." + n; noticeT = 240; }
        if (noticeT > 0) noticeT--;
        if (state == LOBBY && menuTick % 120 == 0) DashNet.request();
        if (state != PLAY && DashNet.inMatch() && DashNet.result == 0 && DashNet.matchNo != startedNo && !over) startOnline();
    }

    private void onlineTick() {
        netTick();
        if (DashNet.result != 0 && !over) {                             // the race is decided (or the other player left)
            resultKind = DashNet.myResult();
            over = true;
            if (resultKind == 1) sound(SoundEvents.PLAYER_LEVELUP, 1.0F, 0.7F);
            else if (resultKind == 2) sound(SoundEvents.VILLAGER_NO, 0.9F, 0.7F);
            return;
        }
        while (!DashNet.attacks.isEmpty()) {                            // attacks by the other player
            int kind = DashNet.attacks.poll();
            if (ready <= 0) applyAttack(kind);
        }
        // the ghost
        if (DashNet.version != seenVersion) {
            seenVersion = DashNet.version;
            double nd = DashNet.oppDist;
            if (gAge > 0 && nd > tDist) gVel = Math.max(0, Math.min(3.0, (nd - tDist) / gAge));
            if (nd != tDist || gAge > 60) { tDist = nd; gAge = 0; }
            gFlags = DashNet.oppFlags;
        }
        gAge++;
        if (!DashNet.oppDone && !finished) gDist += gVel;
        double target = tDist + gVel * gAge;
        gDist += (target - gDist) * 0.2;
        gLane += (DashNet.oppLane / 100.0 - gLane) * 0.25;
        if (finished || ready > 0) return;
        if (++sendT >= 10) { sendT = 0; DashNet.progress(score, (int) dist, (int) Math.round(laneF * 100), flags()); }
        if (DashNet.oppDone && !sentFinish && score > DashNet.oppFinal) {          // I have passed them: the race is mine
            sentFinish = true;
            DashNet.finish(score);
        }
    }

    // ---------- the track: what comes next ----------
    private void add(int type, int lane, int span, double z, double len, double y, int col) {
        stage.add(new Obj(type, lane, span, z, len, y, col));
    }

    private int ti(int n) { return trk.nextInt(n); }

    private void coinLine(int lane, double z, int n) {
        for (int i = 0; i < n; i++) add(COIN, lane, 1, z + i * 6, 0, 8, 0);
    }

    /** One chunk of the track, starting at ZFAR. Returns its length. Only the track generator decides what is in it, so two players see the same one. */
    private double spawnSegment(double lvl) {
        stage.clear();
        int safe = ti(3);
        if (lvl < 0.35 && Math.abs(safe - lastSafe) > 1) safe = 1;      // at the start the lane changes are short
        lastSafe = safe;
        double z = ZFAR, len;
        if (--bonusIn <= 0) {
            bonusIn = 3 + ti(3);
            len = bonusChunk(safe, z);
        } else {
            int roll = ti(100);
            if (roll < 20) {
                int n = 8 + ti(5);
                coinLine(safe, z, n);
                if (ti(100) < 25) add(GEM, safe, 1, z + n * 6 + 4, 0, 10, 0);
                len = 54;
            }
            else if (roll < 42) len = carts(safe, z, lvl);
            else if (roll < 62) len = fences(safe, z, lvl);
            else if (roll < 78) len = signs(z, lvl);
            else len = mixed(safe, z);
        }
        for (Obj o : stage) {                                           // while flying, only coins and bonuses are put down
            if (jet > 0 && o.type <= SIGN) continue;
            things.add(o);
        }
        stage.clear();
        return len;
    }

    /** A bonus on the free lane, with coins behind it. */
    private double bonusChunk(int safe, double z) {
        int r = ti(100);
        int type = r < 12 ? JET : r < 28 ? MAGNET : r < 44 ? SHIELD : r < 57 ? DOUBLE : r < 69 ? BOOTS : r < 78 ? FISH : BOX;
        if (mode == ONLINE && ti(100) < 35) type = BOX;                // online there are more mystery boxes
        add(type, safe, 1, z, 0, 14, 0);
        coinLine(safe, z + 14, type == JET ? 6 : 4);
        if (type == BOX || type == MAGNET) add(GEM, safe, 1, z + 14 + 4 * 6 + 6, 0, 10, 0);
        return 50;
    }

    /** Carts: they fill one lane (two later on), coins run along the free lane. */
    private double carts(int safe, double z, double lvl) {
        double len = 22 + ti(16);
        boolean both = lvl >= 0.25 && trk.nextBoolean();
        int first = -1;
        for (int l = 0; l < 3; l++) {
            if (l == safe) continue;
            if (!both && first >= 0) continue;
            if (first < 0) first = l;
            add(TRAIN, l, 1, z + ti(6), len, 0, TRAIN_COL[ti(TRAIN_COL.length)]);
        }
        coinLine(safe, z, (int) (len / 6) + 1);
        return len + 6;
    }

    /** Low fences to jump over: 1 to 3 lanes wide. After a while there are two in a row. */
    private double fences(int safe, double z, double lvl) {
        int span = 1 + ti(lvl < 0.2 ? 2 : 3);
        int start = span == 3 ? 0 : ti(4 - span);
        add(FENCE, start, span, z, 3, 0, 0);
        double len;
        if (span == 3) {                                                // a coin arc over the fence
            for (int i = 0; i < 7; i++) {
                double t = (i - 3) / 3.0;
                add(COIN, 1, 1, z + (i - 3) * 5 - 2, 0, 8 + (1 - t * t) * 26, 0);
            }
            len = 20;
        } else {
            int free = (start == 0) ? 2 : 0;
            if (span == 1) free = (start + 1 + ti(2)) % 3;
            coinLine(free, z - 4, 6);
            len = 26;
        }
        if (lvl > 0.5 && ti(100) < 45) { add(FENCE, start, span, z + len + 14, 3, 0, 0); len += 20; }
        return len;
    }

    /** Hanging signs: slide under them. */
    private double signs(double z, double lvl) {
        int span = 1 + ti(lvl < 0.2 ? 2 : 3);
        int start = span == 3 ? 0 : ti(4 - span);
        add(SIGN, start, span, z, 4, 0, 0);
        for (int l = start; l < start + span; l++) if (trk.nextBoolean() || span == 1) coinLine(l, z - 6, 5);
        return 30;
    }

    /** A cart in one lane, a fence or sign in another, coins in the free one. */
    private double mixed(int safe, double z) {
        int a = (safe + 1) % 3, b = (safe + 2) % 3;
        add(TRAIN, a, 1, z, 24, 0, TRAIN_COL[ti(TRAIN_COL.length)]);
        add(trk.nextBoolean() ? FENCE : SIGN, b, 1, z + 4, trk.nextBoolean() ? 3 : 4, 0, 0);
        coinLine(safe, z, 5);
        return 34;
    }

    // ---------- drawing ----------
    private static double k(double z) { return 1.0 / (1.0 + Math.max(z, -10) / Z0); }

    private static int gy(double k) { return (int) Math.round(HOR + (BOT - HOR) * k); }

    private static int px(double x, double k) { return (int) Math.round(CX + x * k); }

    /** A fill that never leaves the screen. x1 and y1 are exclusive. */
    private static void fl(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(W, x1); y1 = Math.min(H, y1);
        if (x1 > x0 && y1 > y0) g.fill(x0, y0, x1, y1, c);
    }

    private static void dsc(GuiGraphics g, int cx, int cy, int r, int c) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt((r + 0.5) * (r + 0.5) - dy * dy));
            fl(g, cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, c);
        }
    }

    private static int shade(int c, double f) {
        int r = (int) (((c >> 16) & 255) * f), gr = (int) (((c >> 8) & 255) * f), b = (int) ((c & 255) * f);
        return 0xFF000000 | Math.min(255, r) << 16 | Math.min(255, gr) << 8 | Math.min(255, b);
    }

    private static int lerp(int a, int b, double t) { return (int) Math.round(a + (b - a) * t); }


    @Override
    public void render(GuiGraphics g) {
        drawSky(g);
        drawGround(g);
        if (goo > 0 && state == PLAY) fl(g, 0, HOR, W, H, 0x2E3CD060);       // goo: the whole track is slimy
        for (double[] d : sortedDeco()) drawDeco(g, d);
        List<Obj> sorted = new ArrayList<>(things);
        sorted.sort((a, b) -> Double.compare(b.z + b.len / 2, a.z + a.len / 2));
        double gz = ghostZ();
        boolean ghostDrawn = gz < 4 || gz > ZFAR;
        for (Obj o : sorted) {
            if (!ghostDrawn && o.z + o.len / 2 < gz) { drawGhost(g, gz); ghostDrawn = true; }
            drawObj(g, o);
        }
        if (!ghostDrawn) drawGhost(g, gz);
        drawGhostMarker(g, gz);
        if (stumble > 0 && state == PLAY) drawCreeper(g);
        drawCat(g);
        if (shield > 0 && state == PLAY) drawBubble(g);
        for (double[] p : fx) fl(g, (int) p[0], (int) p[1], (int) p[0] + 2, (int) p[1] + 2, (int) p[5]);
        if (jet > 0) for (int i = 0; i < 6; i++) fl(g, (i * 41 + ticks * 7) % W, (i * 29 + ticks * 13) % H, (i * 41 + ticks * 7) % W + 1, (i * 29 + ticks * 13) % H + 9, 0x55FFFFFF);
        if (flash > 0) fl(g, 0, 0, W, H, (flash * 4) << 24 | 0xFF5C7C);       // a red flash that fades out
        if (state == MENU) { renderMenu(g); return; }
        if (state == LOBBY) { renderLobby(g); return; }
        drawHud(g);
        if (finished && !over) renderWaiting(g);
    }

    private List<double[]> sortedDeco() {
        List<double[]> l = new ArrayList<>(deco);
        l.sort((a, b) -> Double.compare(b[1], a[1]));
        return l;
    }

    private void drawSky(GuiGraphics g) {
        g.fillGradient(0, 0, W, HOR, 0xFFFFC2DA, 0xFFFFF3DC);
        Gfx.glow(g, 158, 26, 26, 0xFFFFF3B8, 120);                         // a pale sun with a soft halo
        dsc(g, 158, 26, 12, 0xFFFFF3B8);
        dsc(g, 158, 26, 8, 0xFFFFE680);
        dsc(g, 155, 23, 3, 0xFFFFF8D0);
        for (int c = 0; c < 3; c++) {                                    // slow puffy clouds
            int cx = (int) ((c * 90 + 30 - dist * 0.03) % (W + 50));
            if (cx < -30) cx += W + 50;
            Gfx.cloud(g, cx - 14, 10 + (c * 11) % 22, 28 + (c % 2) * 8, 0xCCFFFFFF);
        }
        for (int x = 0; x < W; x += 2) {                                 // far lavender hills, then closer green ones
            double h1 = 9 + 5 * Math.sin(x * 0.045 + dist * 0.0015) + 3 * Math.sin(x * 0.11 + 1.7);
            fl(g, x, HOR - (int) h1, x + 2, HOR, 0xFFD6C8EE);
            fl(g, x, HOR - (int) h1, x + 2, HOR - (int) h1 + 1, 0xFFE8DDF8);
            double h2 = 4 + 3 * Math.sin(x * 0.08 + dist * 0.003 + 3) + 2 * Math.sin(x * 0.21);
            fl(g, x, HOR - (int) h2, x + 2, HOR, 0xFFBFE3B4);
        }
    }

    private void drawGround(GuiGraphics g) {
        for (int y = HOR; y < H; y++) {
            double kk = (y - HOR + 0.5) / (BOT - HOR);
            double z = Z0 * (1 / kk - 1);
            double wz = z + dist;
            boolean alt = (((int) Math.floor(wz / 9.0)) & 1) == 0;
            float haze = (float) Math.max(0, Math.min(0.5, (1 - kk) * 0.55));      // far away the ground fades into the sky
            fl(g, 0, y, W, y + 1, Gfx.mix(alt ? 0xFFA3DD9C : 0xFF98D893, 0xFFF4F4E0, haze));       // grass
            int bx0 = px(-BED, kk), bx1 = px(BED, kk);
            fl(g, bx0, y, bx1, y + 1, Gfx.mix(alt ? 0xFF6E6C8A : 0xFF67657F, 0xFFC8C0E0, haze));   // the track
            int cw = Math.max(1, (int) Math.round(2.5 * kk));
            fl(g, bx0 - cw, y, bx0, y + 1, 0xFFFFFFFF);                  // white curbs with a pink stripe
            fl(g, bx1, y, bx1 + cw, y + 1, 0xFFFFFFFF);
            fl(g, bx0, y, bx0 + Math.max(1, cw / 2), y + 1, PINK);
            fl(g, bx1 - Math.max(1, cw / 2), y, bx1, y + 1, PINK);
            if (kk > 0.35) { fl(g, bx0 + cw, y, bx0 + cw + 1, y + 1, 0x22FFFFFF); fl(g, bx1 - cw - 1, y, bx1 - cw, y + 1, 0x22000000); }   // soft track edges
            if ((((int) Math.floor(wz / 14.0)) & 1) == 0) {              // lane dashes
                int lw = kk > 0.6 ? 2 : 1;
                int l0 = px(-LW / 2, kk), l1 = px(LW / 2, kk);
                fl(g, l0, y, l0 + lw, y + 1, 0x99FFFFFF);
                fl(g, l1, y, l1 + lw, y + 1, 0x99FFFFFF);
            }
        }
    }

    private void drawDeco(GuiGraphics g, double[] d) {
        double kk = k(d[1]);
        if (d[1] > ZFAR + 10) return;
        int x = px(d[0], kk), y = gy(kk);
        int kind = (int) d[2];
        if (kind == 2) {                                                  // a lamp post with a warm glow
            fl(g, x - Math.max(1, (int) (kk)), y - (int) (26 * kk), x + Math.max(1, (int) (1.5 * kk)), y, 0xFF5E5878);
            if (kk > 0.3) Gfx.glow(g, x, y - (int) (28 * kk), Math.max(3, (int) (8 * kk)), 0xFFFFE680, 90);
            dsc(g, x, y - (int) (28 * kk), Math.max(1, (int) (3 * kk)), 0xFFFFE680);
            return;
        }
        int tw = Math.max(1, (int) Math.round(3 * kk));
        int r = Math.max(2, (int) Math.round(11 * kk));
        if (kk > 0.25) Gfx.ellipse(g, x + r / 3, y, Math.max(2, r), Math.max(1, r / 4), 0x22000000);        // a soft shadow on the grass
        fl(g, x - tw / 2, y - (int) (16 * kk), x - tw / 2 + tw, y, 0xFF8A6A50);
        fl(g, x - tw / 2, y - (int) (16 * kk), x - tw / 2 + Math.max(1, tw / 3), y, 0xFFA98A6E);
        int top = y - (int) (24 * kk);
        int leaf = kind == 1 ? 0xFFF9B8D3 : 0xFF58B864;
        dsc(g, x + r / 4, top + r / 5, r, shade(leaf, 0.82));
        dsc(g, x, top, r, leaf);
        dsc(g, x - r / 3, top - r / 3, Math.max(1, r / 2), kind == 1 ? 0xFFFFD6E6 : 0xFF84D88E);
    }

    /** A box in the world: depth zf (near) to zb (far), height y0 to y1, centered at lane-x xc. */
    private void box3(GuiGraphics g, double xc, double hw, double y0, double y1, double zf, double zb, int col, int[] face) {
        double kf = k(zf), kb = k(zb);
        int gf = gy(kf), gb = gy(kb);
        int xl = px(xc - hw, kf), xr = px(xc + hw, kf);
        int xlb = px(xc - hw, kb), xrb = px(xc + hw, kb);
        int ytf = gf - (int) Math.round(y1 * kf), ybf = gf - (int) Math.round(y0 * kf);
        int ytb = gb - (int) Math.round(y1 * kb), ybb = gb - (int) Math.round(y0 * kb);
        if (Math.abs(xc) > 1 && zb > zf + 0.5) {                          // the side that looks at the middle of the track
            boolean left = xc < 0;
            int xn = left ? xr : xl, xf = left ? xrb : xlb;
            if (xn != xf) {
                int a = Math.min(xn, xf), b = Math.max(xn, xf);
                for (int x = a; x <= b; x++) {
                    double t = (double) (x - xf) / (xn - xf);
                    fl(g, x, lerp(ytb, ytf, t), x + 1, lerp(ybb, ybf, t), shade(col, 0.72));
                }
            }
        }
        if (zb > zf + 0.5 && ytb < ytf) {                                 // the top
            int topCol = shade(col, 1.18);
            for (int y = ytb; y <= ytf; y++) {
                double t = (double) (y - ytb) / Math.max(1, ytf - ytb);
                fl(g, lerp(xlb, xl, t), y, lerp(xrb, xr, t) + 1, y + 1, topCol);
            }
        }
        fl(g, xl, ytf, xr + 1, ybf, col);                                 // the front
        if (face != null) { face[0] = xl; face[1] = ytf; face[2] = xr + 1; face[3] = ybf; }
    }

    private final int[] face = new int[4];

    private void drawObj(GuiGraphics g, Obj o) {
        if (o.z > ZFAR + 12) return;
        double zb = o.z + o.len;
        double cxw = laneX(o.lane + (o.span - 1) / 2.0), hw = o.span * LW / 2.0 - 4;
        double kf = k(o.z);
        switch (o.type) {
            case TRAIN -> {
                box3(g, cxw, hw, 0, 38, o.z, zb, o.color, face);
                int fw = face[2] - face[0], fh = face[3] - face[1];
                if (fw >= 8) {
                    fl(g, face[0] + fw * 12 / 100, face[1] + fh * 14 / 100, face[0] + fw * 44 / 100, face[1] + fh * 48 / 100, 0xFFBFE8FF);
                    fl(g, face[0] + fw * 56 / 100, face[1] + fh * 14 / 100, face[0] + fw * 88 / 100, face[1] + fh * 48 / 100, 0xFFBFE8FF);
                    fl(g, face[0], face[1] + fh * 58 / 100, face[2], face[1] + fh * 66 / 100, 0xFFFFFFFF);
                    fl(g, face[0] + fw * 10 / 100, face[1] + fh * 76 / 100, face[0] + fw * 26 / 100, face[1] + fh * 90 / 100, 0xFFFFF3B0);
                    fl(g, face[0] + fw * 74 / 100, face[1] + fh * 76 / 100, face[0] + fw * 90 / 100, face[1] + fh * 90 / 100, 0xFFFFF3B0);
                }
            }
            case FENCE -> {
                boolean barrier = o.color != 0;                           // a barrier sent by the other player: yellow with dark stripes
                box3(g, cxw, hw, 0, barrier ? 14 : 11, o.z, zb, barrier ? o.color : 0xFFFFFFFF, face);
                int fw = face[2] - face[0], n = Math.max(2, o.span * 4);
                for (int i = 0; i < n; i += 2)
                    fl(g, face[0] + fw * i / n, face[1], face[0] + fw * (i + 1) / n, face[3], barrier ? 0xFF2A2A32 : PINK);
                if (!barrier) fl(g, face[0], face[1], face[2], face[1] + Math.max(1, (face[3] - face[1]) / 5), PINK_D);
            }
            case SIGN -> {
                double zs = o.z + o.len;
                for (int side = -1; side <= 1; side += 2) {              // two posts at the ends
                    double pxw = cxw + side * (hw + 1);
                    box3(g, pxw, 1.5, 0, 30, o.z, zs, 0xFF5E5878, null);
                }
                box3(g, cxw, hw, 17, 29, o.z, zs, 0xFFE5486F, face);
                int fw = face[2] - face[0], n = Math.max(2, o.span * 4);
                for (int i = 0; i < n; i += 2)
                    fl(g, face[0] + fw * i / n, face[1], face[0] + fw * (i + 1) / n, face[3], 0xFFFFFFFF);
            }
            case COIN -> {
                int x = px(laneX(o.lx), kf), y = gy(kf) - (int) Math.round(o.y * kf);
                double r = Math.max(1.5, 5 * kf);
                double spin = Math.abs(Math.cos((dist + o.z * 0.5) / 12.0));
                int w = Math.max(1, (int) Math.round(r * (0.3 + 0.7 * spin))), h = (int) Math.round(r);
                fl(g, x - w, y - h, x + w, y + h, 0xFFE8A817);
                if (w > 1 && h > 2) fl(g, x - w + 1, y - h + 1, x + w - 1, y + h - 1, 0xFFFFD84A);
            }
            default -> {                                                  // bonuses: they float and bob a little
                int x = px(laneX(o.lx), kf);
                double bob = Math.sin((ticks + o.z) / 9.0) * 2.5;
                int y = gy(kf) - (int) Math.round((o.y + bob) * kf);
                icon(g, o.type, x, y, Math.max(2, (int) Math.round(7 * kf)));
            }
        }
    }

    /** The picture of a bonus, s is half its size in pixels. */
    private void icon(GuiGraphics g, int type, int x, int y, int s) {
        int halo = switch (type) {
            case JET -> 0x44FFE066; case MAGNET -> 0x44FF8A8A; case SHIELD -> 0x4460C8FF; case DOUBLE -> 0x44FFD84A;
            case BOOTS -> 0x4466E08A; case FISH -> 0x44FFB070; case GEM -> 0x4466F0F0; default -> 0x44C28AFF;
        };
        dsc(g, x, y, s + 3, halo);
        int w = Math.max(1, s / 2);
        switch (type) {
            case JET -> {
                fl(g, x - s / 2, y - s, x + s - s / 2, y + s, 0xFFFFFFFF);
                fl(g, x - s / 2, y - s, x + s - s / 2, y - s + Math.max(1, s / 2), 0xFFE5486F);
                fl(g, x - s, y, x - s / 2, y + s, 0xFFE5486F);
                fl(g, x + s - s / 2, y, x + s, y + s, 0xFFE5486F);
                fl(g, x - s / 3, y + s, x + s / 3 + 1, y + s + Math.max(1, s / 2), 0xFFFFB03A);
            }
            case MAGNET -> {                                              // a red horseshoe with white tips
                fl(g, x - s, y - s, x - s + w, y + s, 0xFFE5486F);
                fl(g, x + s - w, y - s, x + s, y + s, 0xFFE5486F);
                fl(g, x - s, y + s - w, x + s, y + s, 0xFFE5486F);
                fl(g, x - s, y - s, x - s + w, y - s + w, 0xFFFFFFFF);
                fl(g, x + s - w, y - s, x + s, y - s + w, 0xFFFFFFFF);
            }
            case SHIELD -> {                                              // a blue shield
                for (int r = 0; r <= 2 * s; r++) {
                    int hw = r <= s ? s : Math.max(0, s - (r - s));
                    fl(g, x - hw, y - s + r, x + hw + 1, y - s + r + 1, r < 2 ? 0xFFBFE8FF : 0xFF4A9BE8);
                }
                if (s >= 4) fl(g, x, y - s + 2, x + 1, y + s - 2, 0xFFFFFFFF);
            }
            case DOUBLE -> {                                              // a gold coin with x2
                dsc(g, x, y, s, 0xFFE8A817);
                dsc(g, x, y, Math.max(1, s - 1), 0xFFFFD84A);
                if (s >= 5) text(g, "x2", x - 5, y - 4, 0xFF7A4A00);
            }
            case BOOTS -> {                                               // a green sneaker with a white sole
                fl(g, x - s / 2, y - s, x + s / 3 + 1, y + s / 2, 0xFF4CC870);
                fl(g, x - s / 2, y, x + s, y + s, 0xFF4CC870);
                fl(g, x - s / 2, y + s - 1, x + s, y + s, 0xFFFFFFFF);
                fl(g, x - s / 2, y - s, x + s / 3 + 1, y - s + Math.max(1, s / 3), 0xFFB8F0C8);
            }
            case FISH -> {                                                // an orange fish
                fl(g, x - s, y - s / 2, x + s / 2, y + s / 2 + 1, 0xFFFF9A4A);
                fl(g, x + s / 2, y - s, x + s, y + s + 1, 0xFFFF9A4A);
                fl(g, x - s / 4, y - s / 2, x - s / 4 + 1, y + s / 2 + 1, 0xFFFFD0A0);
                fl(g, x - s + 1, y - s / 2 + 1, x - s + 2, y - s / 2 + 2, 0xFF2A2A32);
            }
            case GEM -> {                                                 // a cyan diamond
                for (int i = -s; i <= s; i++) {
                    int hw = s - Math.abs(i);
                    fl(g, x - hw, y + i, x + hw + 1, y + i + 1, 0xFF58E0F0);
                }
                fl(g, x - 1, y - s + 1, x, y - s + 3, 0xFFFFFFFF);
            }
            default -> {                                                  // the mystery box
                fl(g, x - s, y - s, x + s, y + s, 0xFFB06AE8);
                fl(g, x - s, y - s, x + s, y - s + 1, 0xFFD9A8FF);
                fl(g, x - s, y + s - 1, x + s, y + s, 0xFF7A3CB0);
                if (s >= 5) text(g, "?", x - 2, y - 4, 0xFFFFFFFF);
            }
        }
    }

    /** The creeper that follows the kitty after the first crash: a green back with speckles and four little feet. */
    private void drawCreeper(GuiGraphics g) {
        boolean warn = stumble < 120 && (ticks / 6) % 2 == 0;           // it is going away: blinks
        int x = (int) (CX + laneX(laneF)) + (int) (Math.sin(ticks / 9.0) * 3);
        int top = BOT + 2 - (warn ? 4 : 0);
        fl(g, x - 11, top, x + 11, H, 0xFF4FAE5E);
        for (int i = 0; i < 9; i++) {
            int sx = x - 10 + (i * 7) % 20, sy = top + 1 + (i * 5) % 8;
            fl(g, sx, sy, sx + 3, sy + 2, i % 2 == 0 ? 0xFF2F8A44 : 0xFF86D790);
        }
        fl(g, x - 11, top, x + 11, top + 1, 0xFF7FD98A);
    }

    private void drawCat(GuiGraphics g) {
        if (state != PLAY) {                                            // the menu: the kitty just trots along
            drawCatBody(g, CX, BOT, (menuTick / 5) % 2 == 0);
            return;
        }
        if (invuln > 0 && jet <= 0 && (ticks / 4) % 2 == 0) return;     // blinks after a crash
        int x = (int) Math.round(CX + laneX(laneF));
        int fy = BOT - (int) Math.round(yj);
        fl(g, x - 7, BOT - 1, x + 8, BOT + 1, yj > 8 ? 0x22000000 : 0x33000000);   // the shadow stays on the ground
        boolean step = (ticks / 4) % 2 == 0;
        if (slide > 0) {                                                // rolling: long and low
            fl(g, x - 9, fy - 9, x + 10, fy, PINK);
            fl(g, x - 9, fy - 3, x + 10, fy, PINK_D);
            fl(g, x - 5, fy - 14, x + 6, fy - 8, PINK);
            fl(g, x - 5, fy - 17, x - 3, fy - 13, PINK); fl(g, x + 3, fy - 17, x + 5, fy - 13, PINK);
            fl(g, x + 9, fy - 7, x + 14, fy - 5, PINK_D);               // tail
            return;
        }
        if (jet > 0) {                                                  // the rocket pack and its flame
            fl(g, x - 5, fy - 20, x + 6, fy - 6, 0xFFE5486F);
            fl(g, x - 4, fy - 6, x + 5, fy + (step ? 6 : 3), 0xFFFFB03A);
            fl(g, x - 2, fy - 6, x + 3, fy + (step ? 3 : 1), 0xFFFFF3B0);
        }
        drawCatBody(g, x, fy, step);
        if (boots > 0) {                                                // the sneakers
            fl(g, x - 6, fy - 3, x - 1, fy, 0xFF4CC870); fl(g, x + 1, fy - 3, x + 6, fy, 0xFF4CC870);
            if (yj > 4) fl(g, x - 1, fy + 1, x + 2, fy + 3 + (ticks / 2) % 2, 0x88B8F0C8);
        }
    }

    private void drawCatBody(GuiGraphics g, int x, int fy, boolean step) {
        // legs with little paws
        Gfx.rrect(g, x - 5, fy - 6 - (step ? 0 : 3), 4, 6, 1, PINK_D);
        Gfx.rrect(g, x + 1, fy - 6 - (step ? 3 : 0), 4, 6, 1, PINK_D);
        if (yj > 1 && jet <= 0 && state == PLAY) { Gfx.rrect(g, x - 5, fy - 6, 4, 4, 1, PINK_D); Gfx.rrect(g, x + 1, fy - 6, 4, 4, 1, PINK_D); }
        // the tail wags behind: white with a soft tip
        int wag = (int) Math.round(Math.sin(ticks / 4.0) * 2);
        Gfx.rrect(g, x + 6, fy - 12 + wag, 5, 3, 1, 0xFFFFFFFF);
        Gfx.rrect(g, x + 9, fy - 17 + wag, 3, 7, 1, 0xFFFFFFFF);
        fl(g, x + 9, fy - 17 + wag, x + 12, fy - 15 + wag, 0xFFFFD0E4);
        // body: a lavender hoodie seen from behind, with a hood pocket and a shaded side
        Gfx.rrect(g, x - 7, fy - 18, 15, 13, 4, 0xFF7A4A9E);
        Gfx.rrect(g, x - 6, fy - 17, 13, 11, 3, 0xFFB57BD6);
        fl(g, x - 4, fy - 17, x + 4, fy - 16, 0xFFD9B4F0);
        Gfx.rrect(g, x - 3, fy - 14, 7, 5, 2, 0xFF9B63BE);                // the hood pocket
        fl(g, x - 6, fy - 10, x - 5, fy - 7, 0x33FFFFFF);
        // head with rounded ears (and pink insides) and a bow
        Gfx.poly(g, new int[]{x - 8, x - 8, x - 2}, new int[]{fy - 26, fy - 34, fy - 28}, PINK);
        Gfx.poly(g, new int[]{x + 9, x + 9, x + 3}, new int[]{fy - 26, fy - 34, fy - 28}, PINK);
        Gfx.poly(g, new int[]{x - 7, x - 7, x - 4}, new int[]{fy - 27, fy - 32, fy - 28}, 0xFFFFC0D6);
        Gfx.poly(g, new int[]{x + 8, x + 8, x + 5}, new int[]{fy - 27, fy - 32, fy - 28}, 0xFFFFC0D6);
        Gfx.rrect(g, x - 8, fy - 29, 17, 13, 5, PINK_D);
        Gfx.rrect(g, x - 7, fy - 29, 15, 11, 5, PINK);
        fl(g, x - 4, fy - 28, x + 3, fy - 27, 0x88FFFFFF);
        fl(g, x - 7, fy - 21, x + 8, fy - 18, PINK_D);                    // the back of the head is in shade
        Gfx.poly(g, new int[]{x + 1, x + 1, x + 3}, new int[]{fy - 31, fy - 26, fy - 28}, 0xFFFFFFFF);                // the bow
        Gfx.poly(g, new int[]{x + 6, x + 6, x + 4}, new int[]{fy - 31, fy - 26, fy - 28}, 0xFFFFFFFF);
        fl(g, x + 3, fy - 29, x + 5, fy - 27, 0xFFE5486F);
    }

    /** The shield bubble around the kitty; it blinks when it is about to run out. */
    private void drawBubble(GuiGraphics g) {
        if (shield < 180 && (ticks / 5) % 2 == 0) return;
        int x = (int) Math.round(CX + laneX(laneF));
        int cy = BOT - (int) Math.round(yj) - 15;
        dsc(g, x, cy, 21, 0x2860C8FF);
        dsc(g, x, cy, 19, 0x2260C8FF);
        Gfx.glow(g, x, cy, 24, 0xFF60C8FF, 40);
        fl(g, x - 12, cy - 15, x - 8, cy - 14, 0xAAFFFFFF);
        fl(g, x - 14, cy - 13, x - 13, cy - 10, 0xAAFFFFFF);
    }

    // ---------- the other kitty ----------
    /** Where the ghost is in front of us (a depth z); anything under 4 is level with us or behind. */
    private double ghostZ() {
        if (state != PLAY || mode != ONLINE) return -1000;
        return gDist - dist;
    }

    private void drawGhost(GuiGraphics g, double gz) {
        if (gz < 4 || gz > ZFAR) return;
        double kk = k(gz);
        int x = px(laneX(gLane), kk), y = gy(kk) - ((gFlags & 8) != 0 ? (int) Math.round(12 * kk) : 0);
        int a = 0xBB000000;
        int body = a | 0x7FB8F5, dark = a | 0x4F86C8, hood = a | 0x9BB0F0;
        fl(g, x - (int) (7 * kk), y - 1, x + (int) (7 * kk) + 1, y + 1, 0x22000000);
        if ((gFlags & 4) != 0) {                                        // a rocket pack
            fl(g, x - (int) (5 * kk), y - (int) (20 * kk), x + (int) (6 * kk), y - (int) (6 * kk), a | 0xE5486F);
            fl(g, x - (int) (3 * kk), y - (int) (6 * kk), x + (int) (4 * kk), y + (int) (5 * kk), a | 0xFFB03A);
        }
        if ((gFlags & 16) != 0) {                                       // sliding
            fl(g, x - (int) (9 * kk), y - (int) (9 * kk), x + (int) (10 * kk), y, body);
            fl(g, x - (int) (5 * kk), y - (int) (16 * kk), x + (int) (6 * kk), y - (int) (8 * kk), body);
        } else {
            fl(g, x - (int) (5 * kk), y - (int) (6 * kk), x + (int) (5 * kk), y, dark);
            fl(g, x - (int) (6 * kk), y - (int) (17 * kk), x + (int) (7 * kk), y - (int) (6 * kk), hood);
            fl(g, x - (int) (7 * kk), y - (int) (28 * kk), x + (int) (8 * kk), y - (int) (17 * kk), body);
            fl(g, x - (int) (7 * kk), y - (int) (32 * kk), x - (int) (3 * kk), y - (int) (27 * kk), body);
            fl(g, x + (int) (4 * kk), y - (int) (32 * kk), x + (int) (8 * kk), y - (int) (27 * kk), body);
        }
        if ((gFlags & 2) != 0) dsc(g, x, y - (int) (15 * kk), Math.max(3, (int) (20 * kk)), 0x2260C8FF);
        if (kk > 0.45) {
            String n = clip(oppName, 44);
            fl(g, x - tw(n) / 2 - 1, y - (int) (36 * kk) - 9, x + tw(n) / 2 + 2, y - (int) (36 * kk) - 1, 0x88000000);
            ctext(g, n, x, y - (int) (36 * kk) - 9, 0xFFBFE8FF);
        }
    }

    /** When the ghost is far ahead (a dot on the horizon) or behind us (a mark at the bottom). */
    private void drawGhostMarker(GuiGraphics g, double gz) {
        if (state != PLAY || mode != ONLINE) return;
        int x = (int) Math.round(CX + laneX(gLane));
        if (gz > ZFAR) {
            dsc(g, x, HOR + 2, 2, 0xFF7FB8F5);
        } else if (gz < 4) {
            int y = H - 7 + (gz < -60 ? 2 : 0);
            fl(g, x - 5, y, x + 6, y + 4, 0xAA7FB8F5);
            fl(g, x - 3, y + 4, x + 4, y + 6, 0xAA7FB8F5);
            fl(g, x - 1, y + 6, x + 2, y + 7, 0xAA7FB8F5);
        }
    }

    private static void heart(GuiGraphics g, int x, int y, int c) {
        fl(g, x + 1, y, x + 3, y + 1, c); fl(g, x + 4, y, x + 6, y + 1, c);
        fl(g, x, y + 1, x + 7, y + 3, c); fl(g, x + 1, y + 3, x + 6, y + 4, c);
        fl(g, x + 2, y + 4, x + 5, y + 5, c); fl(g, x + 3, y + 5, x + 4, y + 6, c);
    }

    // ---------- the HUD ----------
    private void effectBar(GuiGraphics g, int row, int type, int color, int left, int max) {
        int y = 15 + row * 7;
        Gfx.rrect(g, 2, y - 1, 50, 7, 3, 0x66000000);
        if (type == 0) dsc(g, 7, y + 2, 2, 0xFF6BDC6B); else icon(g, type, 7, y + 2, 2);
        Gfx.rrect(g, 14, y, 36, 4, 2, 0x55FFFFFF);
        Gfx.rrect(g, 14, y, Math.max(2, 36 * Math.min(left, max) / max), 4, 2, left < 90 && (ticks / 6) % 2 == 0 ? 0xFFFFFFFF : color);
    }

    private void drawHud(GuiGraphics g) {
        g.fillGradient(0, 0, W, 13, 0xAA000000, 0x33000000);
        text(g, Integer.toString(score), 5, 3, 0xFFFFFFFF);
        dsc(g, 60, 6, 3, 0xFFFFD84A);
        text(g, Integer.toString(coins), 66, 2, 0xFFFFE680);
        if (dbl > 0) text(g, "x2", 84, 2, (ticks / 8) % 2 == 0 ? 0xFFFFD84A : 0xFFFFFFFF);
        boolean second = stumble == 0 || (stumble < 120 && (ticks / 6) % 2 == 0);
        heart(g, W - 24, 3, 0xFFFF5C7C);
        heart(g, W - 13, 3, second ? 0xFFFF5C7C : 0x55FFFFFF);
        int row = 0;
        if (jet > 0) effectBar(g, row++, JET, 0xFFFFB03A, jet, JET_T);
        if (magnet > 0) effectBar(g, row++, MAGNET, 0xFFE5486F, magnet, MAGNET_T);
        if (shield > 0) effectBar(g, row++, SHIELD, 0xFF4A9BE8, shield, SHIELD_T);
        if (dbl > 0) effectBar(g, row++, DOUBLE, 0xFFFFD84A, dbl, DOUBLE_T);
        if (boots > 0) effectBar(g, row++, BOOTS, 0xFF4CC870, boots, BOOTS_T);
        if (goo > 0) effectBar(g, row++, 0, 0xFF6BDC6B, goo, GOO_T);
        if (combo >= 5 && jet <= 0) ctext(g, "x" + combo, 112, 2, 0xFFFFD84A);
        if (mode == ONLINE) {
            String n = clip(oppName, 36) + " " + (DashNet.oppDone ? DashNet.oppFinal + "!" : Integer.toString(DashNet.oppScore));
            boolean ahead = score >= (DashNet.oppDone ? DashNet.oppFinal : DashNet.oppScore);
            text(g, n, W - 28 - tw(n), 2, ahead ? 0xFFBFF0C8 : 0xFFFFB0B8);
            if (ready <= 0 && !finished && !DashNet.oppDone) {
                int gap = (int) Math.round((dist - gDist) / 10.0);            // + means we are in front
                String s = (gap >= 0 ? "+" : "") + gap + "m";
                ctext(g, s, W / 2, 14, gap >= 0 ? 0xFFBFF0C8 : 0xFFFFB0B8);
            }
        }
        if (toastT > 0) {
            String tt = toastText;                                        // to the right of the bonus bars: it shrinks to fit there
            int toastW = Math.min(tw(tt), 136), tx = 126;
            fl(g, tx - toastW / 2 - 3, 24, tx + toastW / 2 + 3, 36, 0x99000000);
            ctextW(g, tt, tx, 26, 136, 0xFFFFE680);
        }
        if (ready > 0) {
            String s = ready > 66 ? "3" : ready > 33 ? "2" : "1";
            Gfx.rrect(g, W / 2 - 26, 50, 52, 24, 6, 0xCC000000);
            ctext(g, s, W / 2, 58, 0xFFFFFFFF);
            if (mode == ONLINE) ctextW(g, tr("cutemod.dash.vs", oppName), W / 2, 80, W - 24, 0xFFFFFFFF);
        } else if (run < 70) {
            ctext(g, "GO!", W / 2, 58, 0xFFFFD84A);
        }
    }

    /** I crashed for the last time, the other player is still running. */
    private void renderWaiting(GuiGraphics g) {
        fl(g, 20, 44, W - 20, 98, 0xDD201828);
        fl(g, 19, 43, W - 19, 44, 0xFFFFFFFF); fl(g, 19, 98, W - 19, 99, 0xFFFFFFFF);
        ctextW(g, endTitle().getString(), W / 2, 49, W - 48, 0xFFFFD866);
        ctextW(g, tr("cutemod.dash.yours", score), W / 2, 62, W - 48, 0xFFFFFFFF);
        String n = clip(oppName, 80);
        ctextW(g, tr("cutemod.dash.theirs", n, DashNet.oppScore), W / 2, 74, W - 48, 0xFFBFE8FF);
        ctextW(g, tr("cutemod.dash.wait_for", clip(oppName, 80)) + ".".repeat(1 + waitT / 20 % 3), W / 2, 86, W - 48, 0xFFB8B0C8);
    }

    // ---------- menu and lobby ----------
    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean accent) {
        boolean hover = in(mx, my, x, y, w, h);
        Gfx.bubble(g, x, y, w, h, 3, hover ? 0xFFFFFFFF : accent ? 0xFFFFE0EE : 0xFFF2ECFA);
        ctextW(g, label, x + w / 2, y + (h - 8) / 2, w - 6, 0xFF3A2A4A);
    }

    private void panel(GuiGraphics g, int x0, int y0, int x1, int y1) {
        Gfx.panel(g, x0, y0, x1 - x0, y1 - y0, 0xF03A2E52, 0xF01E1630);
    }

    private void renderMenu(GuiGraphics g) {
        panel(g, 14, 8, W - 14, 132);
        ctextW(g, tr("cutemod.game.dash"), W / 2, 13, W - 40, 0xFFFFD866);
        button(g, 28, 28, W - 56, 18, tr("cutemod.dash.solo"), false);
        button(g, 28, 52, W - 56, 18, tr("cutemod.dash.online"), true);
        ctextW(g, tr("cutemod.dash.menu.bonuses"), W / 2, 78, W - 40, 0xFFB8B0C8);
        int[] ic = {JET, MAGNET, SHIELD, DOUBLE, BOOTS, FISH, GEM, BOX};
        for (int i = 0; i < ic.length; i++) icon(g, ic[i], 32 + i * 22, 98, 6);
        ctextW(g, tr("cutemod.dash.menu.hint"), W / 2, 116, W - 40, 0xFF9A90B0);
    }

    private boolean menuClick(int x, int y) {
        if (in(x, y, 28, 28, W - 56, 18)) { startSolo(); return true; }
        if (in(x, y, 28, 52, W - 56, 18)) { state = LOBBY; DashNet.request(); pling(1.0F); return true; }
        return true;
    }

    private void lobbyBack() {
        if (!DashNet.invitedTo.isEmpty()) DashNet.cancelInvite();
        state = MENU;
    }

    private int listY() { return !DashNet.invitedBy.isEmpty() ? 60 : !DashNet.invitedTo.isEmpty() ? 56 : 34; }

    private boolean lobbyClick(int x, int y) {
        if (in(x, y, 12, 118, 60, 14)) { lobbyBack(); return true; }
        if (!DashNet.invitedBy.isEmpty()) {
            if (in(x, y, 12, 40, 94, 14)) { DashNet.accept(DashNet.invitedBy); pling(1.4F); return true; }
            if (in(x, y, 114, 40, 94, 14)) { DashNet.decline(DashNet.invitedBy); return true; }
        } else if (!DashNet.invitedTo.isEmpty()) {
            if (in(x, y, 12, 38, 196, 14)) { DashNet.cancelInvite(); return true; }
        }
        int ly = listY();
        for (int i = 0; i < Math.min(DashNet.players.size(), (103 - ly) / 16); i++) {
            if (in(x, y, 12, ly + i * 16, 196, 14)) {
                DashNet.invite(DashNet.players.get(i));
                pling(1.1F);
                return true;
            }
        }
        return true;
    }

    private void renderLobby(GuiGraphics g) {
        panel(g, 6, 4, W - 6, 136);
        ctextW(g, tr("cutemod.dash.lobby.title"), W / 2, 9, W - 40, 0xFFFFD866);
        String by = DashNet.invitedBy, to = DashNet.invitedTo;
        if (!by.isEmpty()) {                                     // someone invited us
            fl(g, 10, 20, W - 10, 58, 0xFF4A3868);
            ctextW(g, tr("cutemod.dash.invite.from", clip(by, 90)), W / 2, 25, W - 28, 0xFFFFFFFF);
            button(g, 12, 40, 94, 14, tr("cutemod.dash.accept"), true);
            button(g, 114, 40, 94, 14, tr("cutemod.dash.decline"), false);
        } else if (!to.isEmpty()) {                              // we invited someone
            ctextW(g, tr("cutemod.dash.waiting", clip(to, 90)) + ".".repeat(1 + menuTick / 20 % 3), W / 2, 24, W - 28, 0xFFFFFFFF);
            button(g, 12, 38, 196, 14, tr("cutemod.dash.cancel"), false);
        } else {
            ctextW(g, tr("cutemod.dash.lobby.hint"), W / 2, 22, W - 28, 0xFFB8B0C8);
        }
        int ly = listY(), rows = Math.min(DashNet.players.size(), (103 - ly) / 16);
        if (DashNet.players.isEmpty()) ctextW(g, tr("cutemod.dash.lobby.none"), W / 2, ly + 10, W - 28, 0xFF9A90B0);
        for (int i = 0; i < rows; i++) {
            String n = DashNet.players.get(i);
            button(g, 12, ly + i * 16, 196, 14, n, n.equals(to));
        }
        if (DashNet.players.size() > rows) ctext(g, "+" + (DashNet.players.size() - rows), W - 30, 121, 0xFF9A90B0);
        if (noticeT > 0) ctextW(g, tr(noticeKey), W / 2, 106, W - 28, 0xFFFF9A9A);
        button(g, 12, 118, 60, 14, tr("cutemod.dash.back"), false);
    }

    // ---------- the shell ----------
    @Override
    public boolean isWin() { return mode == ONLINE && resultKind == 1; }

    @Override
    public Component endTitle() {
        if (mode == ONLINE) {
            if (finished && !over) return Component.translatable("cutemod.dash.dead." + dead);
            return Component.translatable("cutemod.dash.end." + resultKind);
        }
        return Component.translatable("cutemod.dash.dead." + dead);
    }

    @Override
    public Component status() {
        if (state != PLAY) return Component.translatable("cutemod.game.dash");
        if (mode == ONLINE) return Component.translatable("cutemod.dash.status", score, DashNet.oppDone ? DashNet.oppFinal : DashNet.oppScore, oppName);
        return Component.translatable("cutemod.ui.score", score);
    }

    @Override
    public String hintKey() { return "cutemod.hint.dash"; }
}
