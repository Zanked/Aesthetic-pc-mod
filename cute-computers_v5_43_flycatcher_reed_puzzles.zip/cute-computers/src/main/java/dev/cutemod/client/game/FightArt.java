package dev.cutemod.client.game;

import dev.cutemod.data.FightSim;
import net.minecraft.client.gui.GuiGraphics;

/**
 * The pictures of Pet Brawl: four chibi animals (cat, fox, panda, bunny) built from fills with a dark outline, a pose rig that is
 * smoothed from tick to tick, motion trails, and three stages (sunset dojo, moonlit bamboo, festival night). Everything is in the
 * 220 x 140 game pixels; heights are measured up from the floor ({@link FightSim#FLOOR}).
 */
final class FightArt {
    private FightArt() {}

    static final int OUT = 0xFF2A1F3D;
    static final int FLOOR = FightSim.FLOOR;

    // ---------------------------------------------------------------- the four animals
    static final int[] FUR = {0xFFF4A860, 0xFFEE7A34, 0xFFF7F4EE, 0xFFFFD6E6};
    static final int[] FUR_DARK = {0xFFC9722E, 0xFFB5521C, 0xFF2B2B36, 0xFFE8A8C4};
    static final int[] GI = {0xFFE0484F, 0xFF3C7DD9, 0xFF3FA66B, 0xFF8A5BD6};
    static final int[] GI_DARK = {0xFFA8303A, 0xFF2A5AA8, 0xFF2C7A4E, 0xFF6240A8};
    static final int[] BELT = {0xFFFFE27A, 0xFFF4F4F8, 0xFFF2C14A, 0xFFFF9EC8};
    static final int[] GLOW = {0xFFFFC24A, 0xFFFF7A2E, 0xFF7BE06A, 0xFFFF8FD0};

    // ---------------------------------------------------------------- poses
    // joints, local (x forward, y up): head, shoulder, hip, front hand, back hand, front foot, back foot
    static final float[] IDLE_P = {2, 27.5F, 1, 21, 0, 12, 8, 21, 4, 18, 5, 0, -5, 0};
    static final float[] CROUCH_P = {3, 20, 2, 14, 0, 7, 8, 15, 5, 13, 7, 0, -6, 0};
    static final float[] TUCK_P = {2, 28, 1, 21, 0, 12, 7, 26, 3, 24, 5, 5, -4, 3};
    static final float[] FALL_P = {2, 28, 1, 21, 0, 12, 8, 27, 2, 25, 6, 2, -6, 3};
    static final float[] GUARD_P = {0, 27, 0, 21, 0, 12, 9, 24, 7, 19, 5, 0, -5, 0};
    static final float[] GUARD_C = {1, 19, 1, 13, 0, 7, 9, 17, 7, 14, 7, 0, -6, 0};
    static final float[] HIT_P = {-4, 26, -2, 21, 0, 12, -4, 25, -7, 19, 4, 0, -6, 0};
    static final float[] FLY_P = {-9, 8, -3, 7, 4, 6, -8, 12, -2, 12, 11, 10, 10, 5};
    static final float[] LIE_P = {-10, 4, -4, 3.5F, 4, 3, -9, 6, -1, 6, 11, 3, 12, 1};
    static final float[] WIN_P = {1, 29, 1, 21, 0, 12, 9, 38, -5, 34, 5, 0, -5, 0};

    // attack poses: index = move id (0..5), 6 + character for the specials
    static final float[][] PEAK = {
            {5, 27.5F, 3, 21, 0, 12, 17, 22.5F, 2, 17, 7, 0, -6, 0},
            {-1, 28, -2, 21, -1, 12.5F, 7, 24, -6, 21, 19, 17, -4, 0},
            {5, 20, 3, 14, 0, 7, 17, 14.5F, 3, 11, 7, 0, -6, 0},
            {-1, 17, -2, 11, -2, 6, -6, 10, -8, 6, 21, 2, -7, 0},
            {4, 27, 2, 21, 0, 12, 15, 14, 3, 24, 3, 4, -3, 5},
            {-1, 27, -1, 21, -1, 12, 7, 24, -4, 22, 16, 5, -6, 9},
            {8, 24, 5, 19, 0, 13, 18, 23, 13, 17, 6, 3, -10, 6},
            {3, 28, 1, 21, 0, 12, 14, 22, 11, 21, 6, 0, -5, 0},
            {5, 22, 3, 17, 0, 10, 16, 9, 12, 8, 8, 0, -8, 0},
            {2, 30, 1, 23, 0, 14, 7, 45, -3, 28, 4, 8, -3, 10}};
    static final float[][] WIND = {
            {0, 27.5F, -1, 21, -1, 12, 1, 20, 6, 21, 4, 0, -6, 0},
            {0, 27.5F, -1, 21, 0, 12, 6, 22, -3, 20, 3, 8, -5, 0},
            {1, 20, 1, 14, 0, 7, 2, 13, 5, 12, 7, 0, -6, 0},
            {1, 20, 1, 14, 0, 7, 8, 14, 4, 12, 3, 3, -6, 0},
            TUCK_P, TUCK_P,
            {-2, 20, -2, 15, 0, 10, -7, 22, -5, 18, 8, 0, -8, 0},
            {-2, 27, -2, 21, -1, 12, -4, 19, -6, 18, 4, 0, -7, 0},
            {-3, 30, -3, 22, 0, 12, 2, 40, -3, 38, 5, 0, -5, 0},
            {0, 24, 0, 18, 0, 10, -5, 19, -6, 16, 6, 0, -6, 0}};

    /** The smoothed joints of one fighter plus the trail of the limb that strikes. */
    static final class Rig {
        final float[] j = IDLE_P.clone();
        final float[] tx = new float[6], ty = new float[6];
        int trail;
        float tailLag;
        int blink;

        void snap(FightSim.F f, int t) {
            System.arraycopy(pose(f, t), 0, j, 0, 14);
            trail = 0;
        }

        void update(FightSim.F f, int t) {
            float[] tg = pose(f, t);
            boolean snappy = f.state == FightSim.ATTACK || f.state == FightSim.HITSTUN || f.state == FightSim.KNOCKED;
            float k = snappy ? 0.62F : 0.42F;
            for (int i = 0; i < 14; i++) j[i] += (tg[i] - j[i]) * k;
            tailLag += (f.vx * f.face - tailLag) * 0.2F;
            // the trail of the striking limb
            boolean strike = f.state == FightSim.ATTACK && f.move != null && f.moveT > f.move.startup - 2 && f.moveT <= f.move.startup + Math.min(f.move.active, 10) + 3;
            if (strike) {
                int hand = f.move.id == FightSim.M_KICK || f.move.id == FightSim.M_CKICK || f.move.id == FightSim.M_JKICK ? 10 : 6;
                System.arraycopy(tx, 0, tx, 1, 5); System.arraycopy(ty, 0, ty, 1, 5);
                tx[0] = f.x + f.face * j[hand]; ty[0] = f.y + j[hand + 1];
                trail = Math.min(6, trail + 1);
            } else if (trail > 0) trail--;
        }
    }

    static float[] pose(FightSim.F f, int t) {
        float b = (float) Math.sin(t * 0.13F + f.ch) * 0.7F;
        switch (f.state) {
            case FightSim.IDLE: {
                float[] p = IDLE_P.clone();
                p[1] += b; p[3] += b * 0.5F; p[7] += b; p[9] += b * 0.6F;
                return p;
            }
            case FightSim.WALK: {
                float s = (float) Math.sin(t * 0.3F), c = (float) Math.cos(t * 0.3F), bob = Math.abs(c) * 0.9F;
                float[] p = IDLE_P.clone();
                p[1] += bob; p[3] += bob * 0.6F; p[7] += s * 1.5F; p[8] -= s * 2F;
                p[10] = 3 + s * 6; p[11] = Math.max(0, c) * 3; p[12] = -3 - s * 6; p[13] = Math.max(0, -c) * 3;
                return p;
            }
            case FightSim.CROUCH: return CROUCH_P;
            case FightSim.GETUP: return CROUCH_P;
            case FightSim.JUMP: return f.vy > 0 ? TUCK_P : FALL_P;
            case FightSim.BLOCKSTUN: return f.in.down ? GUARD_C : GUARD_P;
            case FightSim.HITSTUN: return HIT_P;
            case FightSim.KNOCKED: return FLY_P;
            case FightSim.LYING: case FightSim.KO: return LIE_P;
            case FightSim.WIN: {
                float[] p = WIN_P.clone();
                float hop = Math.abs((float) Math.sin(t * 0.18F)) * 3F;
                p[1] += hop; p[3] += hop; p[5] += hop; p[7] += hop; p[9] += hop;
                p[7] += (float) Math.sin(t * 0.4F);
                return p;
            }
            case FightSim.ATTACK: {
                FightSim.Move m = f.move;
                if (m == null) return IDLE_P;
                int key = m.id == FightSim.M_SPECIAL ? 6 + f.ch : m.id;
                float ext;
                int t0 = f.moveT;
                if (t0 <= m.startup) ext = -(t0 / (float) Math.max(1, m.startup));
                else if (t0 <= m.startup + m.active) ext = 1;
                else ext = Math.max(0, 1F - (t0 - m.startup - m.active) / (float) Math.max(1, m.recover));
                float[] base = key == 2 || key == 3 ? CROUCH_P : key == 4 || key == 5 ? TUCK_P : IDLE_P;
                float[] to = ext >= 0 ? PEAK[key] : WIND[key];
                float k = Math.abs(ext);
                float[] p = new float[14];
                for (int i = 0; i < 14; i++) p[i] = base[i] + (to[i] - base[i]) * k;
                return p;
            }
            default: return IDLE_P;
        }
    }

    // ---------------------------------------------------------------- colour helpers
    private static int col(int c, int tint, float amt, float alpha) {
        if (amt > 0) c = Gfx.mix(c, tint, amt);
        if (alpha < 1F) c = Gfx.fade(c, alpha);
        return c;
    }

    static void thick(GuiGraphics g, int x0, int y0, int x1, int y1, int w, int color) {
        int dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx - dy, h = w / 2;
        for (int i = 0; i < 160; i++) {
            g.fill(x0 - h, y0 - h, x0 - h + w, y0 - h + w, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 < dx) { err += dx; y0 += sy; }
        }
    }

    /** A limb with an outline: segments from a to b to c. */
    private static void limb(GuiGraphics g, int ax, int ay, int bx, int by, int cx, int cy, int w, int c1, int c2, int tint, float amt, float al) {
        int o = col(OUT, tint, amt * 0.3F, al);
        thick(g, ax, ay, bx, by, w + 2, o); thick(g, bx, by, cx, cy, w + 2, o);
        thick(g, ax, ay, bx, by, w, col(c1, tint, amt, al)); thick(g, bx, by, cx, cy, w, col(c2, tint, amt, al));
    }

    private static void odisc(GuiGraphics g, int x, int y, int r, int color, int tint, float amt, float al) {
        Gfx.disc(g, x, y, r + 1, col(OUT, tint, amt * 0.3F, al));
        Gfx.disc(g, x, y, r, col(color, tint, amt, al));
    }

    private static void opoly(GuiGraphics g, int[] xs, int[] ys, int color, int tint, float amt, float al) {
        int o = col(OUT, tint, amt * 0.3F, al);
        int[][] off = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        for (int[] d : off) {
            int[] ox = new int[xs.length], oy = new int[ys.length];
            for (int i = 0; i < xs.length; i++) { ox[i] = xs[i] + d[0]; oy[i] = ys[i] + d[1]; }
            Gfx.poly(g, ox, oy, o);
        }
        Gfx.poly(g, xs, ys, col(color, tint, amt, al));
    }

    // ---------------------------------------------------------------- a fighter
    /** Draws one fighter. tint / amt mix every colour toward a tint (hit flash), al fades it (after-images). */
    static void fighter(GuiGraphics g, FightSim.F f, Rig r, int t, int tint, float amt, float al) {
        int ch = f.ch, d = f.face;
        float sc = ch == FightSim.PANDA ? 1.1F : 1F;
        int fx = Math.round(f.x), fy = FLOOR - Math.round(f.y);
        int[] X = new int[7], Y = new int[7];
        for (int k = 0; k < 7; k++) {
            X[k] = fx + Math.round(d * r.j[2 * k] * sc);
            Y[k] = fy - Math.round(r.j[2 * k + 1] * sc);
        }
        int hx = X[0], hy = Y[0], sx = X[1], sy = Y[1], ix = X[2], iy = Y[2];
        boolean lying = f.state == FightSim.LYING || f.state == FightSim.KO || f.state == FightSim.KNOCKED;
        int fur = col(FUR[ch], tint, amt, al), furD = col(FUR_DARK[ch], tint, amt, al);
        int gi = GI[ch], giD = GI_DARK[ch], belt = BELT[ch];

        // shadow
        float hgt = Math.min(0.6F, f.y / 90F);
        int rx = Math.round((lying ? 15 : 10) * (1F - hgt));
        Gfx.ellipse(g, fx, FLOOR + 1, rx, 2, Gfx.alpha(0xFF000000, Math.round(70 * al * (1F - hgt))));

        // tail (behind everything)
        int lag = Math.round(-r.tailLag * 3F);
        float wag = (float) Math.sin(t * 0.11F + ch * 2) * 2.5F;
        int tbx = ix - d * 3, tby = iy - 1;
        switch (ch) {
            case FightSim.CAT -> {
                int p1x = tbx - d * 5 + lag, p1y = tby - 2 + Math.round(wag), p2x = p1x - d * 3 + lag, p2y = p1y - 6, p3x = p2x + d * 1, p3y = p2y - 5;
                limb(g, tbx, tby, p1x, p1y, p2x, p2y, 3, FUR[ch], FUR[ch], tint, amt, al);
                limb(g, p2x, p2y, p3x, p3y, p3x, p3y, 3, FUR_DARK[ch], FUR_DARK[ch], tint, amt, al);
            }
            case FightSim.FOX -> {
                int p1x = tbx - d * 5 + lag, p1y = tby - 1 + Math.round(wag * 0.6F), p2x = p1x - d * 4 + lag, p2y = p1y - 4, p3x = p2x - d * 1, p3y = p2y - 4;
                limb(g, tbx, tby, p1x, p1y, p2x, p2y, 4, FUR[ch], FUR[ch], tint, amt, al);
                limb(g, p2x, p2y, p3x, p3y, p3x, p3y, 4, 0xFFFFFFFF, 0xFFFFFFFF, tint, amt, al);
            }
            case FightSim.PANDA -> odisc(g, tbx - d * 2, tby + 1, 3, FUR[ch], tint, amt, al);
            default -> odisc(g, tbx - d * 2, tby - 1, 3, 0xFFFFFFFF, tint, amt, al);
        }

        // back leg and back arm
        leg(g, ix, iy, X[6], Y[6], d, ch, tint, amt, al);
        limb(g, sx, sy + 1, (sx + X[4]) / 2, (sy + Y[4]) / 2 + 1, X[4], Y[4], 3, gi, ch == FightSim.PANDA ? FUR_DARK[ch] : FUR[ch], tint, amt, al);
        odisc(g, X[4], Y[4], 2, ch == FightSim.PANDA ? FUR_DARK[ch] : FUR[ch], tint, amt, al);

        // torso: a short barrel in the gi, a belt, the belt knot
        int o = col(OUT, tint, amt * 0.3F, al);
        thick(g, ix, iy, sx, sy, 11, o);
        thick(g, ix, iy, sx, sy, 9, col(gi, tint, amt, al));
        thick(g, ix + d * 2, iy - 2, sx + d * 2, sy, 3, col(giD, tint, amt, al));          // shade on the back side... (front is lighter)
        thick(g, ix - d * 2, iy - 1, sx - d * 2, sy + 1, 2, col(Gfx.lighter(gi, 0.3F), tint, amt, al));
        int by = iy - 1;
        thick(g, ix - 4, by, ix + 4, by, 3, col(belt, tint, amt * 0.5F, al));
        g.fill(ix - d * 6, by - 1, ix - d * 4, by + 3, col(belt, tint, amt, al));
        int flap = Math.round((float) Math.sin(t * 0.25F + ch) * 1.5F);
        g.fill(ix - d * 8, by + 1 + flap, ix - d * 6, by + 4 + flap, col(belt, tint, amt, al));
        // collar
        thick(g, sx - 3, sy + 3, sx + 3, sy + 3, 2, col(0xFFFFFFFF, tint, amt * 0.6F, al));

        // head
        head(g, f, r, t, hx, hy, tint, amt, al);

        // front leg, front arm and what the hand holds
        leg(g, ix, iy, X[5], Y[5], d, ch, tint, amt, al);
        int handC = ch == FightSim.PANDA ? FUR_DARK[ch] : FUR[ch];
        limb(g, sx, sy + 1, (sx + X[3]) / 2, (sy + Y[3]) / 2 + 1, X[3], Y[3], 3, gi, handC, tint, amt, al);
        odisc(g, X[3], Y[3], 2, handC, tint, amt, al);
        if (f.state == FightSim.ATTACK && f.move != null && f.move.id == FightSim.M_SPECIAL) held(g, f, X, Y, t, tint, amt, al);
        if (f.state == FightSim.ATTACK && f.move != null && f.move.id <= FightSim.M_CPUNCH && f.moveT > f.move.startup && f.moveT <= f.move.startup + 3 && ch == FightSim.CAT) {
            int cx = X[3] + d * 3, cy = Y[3];
            for (int k = -1; k <= 1; k++) g.fill(cx, cy + k * 2, cx + d * 3, cy + k * 2 + 1, col(0xFFFFFFFF, tint, amt, al));
        }
    }

    private static void leg(GuiGraphics g, int hipX, int hipY, int fx, int fy, int d, int ch, int tint, float amt, float al) {
        int kx = (hipX + fx) / 2 + d * 2, ky = (hipY + fy) / 2 + 1;
        int pants = ch == FightSim.PANDA ? GI_DARK[ch] : GI_DARK[ch];
        int shin = ch == FightSim.PANDA ? FUR_DARK[ch] : FUR[ch];
        limb(g, hipX, hipY - 1, kx, ky, fx, fy - 1, 3, pants, shin, tint, amt, al);
        int x0 = d == 1 ? fx - 1 : fx - 3, x1 = d == 1 ? fx + 3 : fx + 1;
        g.fill(x0 - 1, fy - 2, x1 + 1, fy + 1, col(OUT, tint, amt * 0.3F, al));
        g.fill(x0, fy - 2, x1, fy, col(ch == FightSim.PANDA ? FUR_DARK[ch] : FUR_DARK[ch], tint, amt, al));
    }

    private static void held(GuiGraphics g, FightSim.F f, int[] X, int[] Y, int t, int tint, float amt, float al) {
        int d = f.face, ch = f.ch;
        int m = f.moveT, s = f.move.startup;
        switch (ch) {
            case FightSim.FOX -> {
                if (m >= s - 5 && m <= s + 2) {
                    int cx = X[3] + d * 4, cy = Y[3];
                    int rr = 3 + Math.max(0, m - (s - 5)) / 2;
                    Gfx.glow(g, cx, cy, rr + 5, GLOW[ch] & 0xFFFFFF, 160);
                    Gfx.ball(g, cx, cy, Math.min(rr, 5), col(0xFFFFB347, tint, amt, al));
                }
            }
            case FightSim.PANDA -> {
                int ax = X[4], ay = Y[4], bx = X[3], by = Y[3];
                int ex = bx + (bx - ax) / 2, ey = by + (by - ay) / 2;
                int ox = ax - (bx - ax) / 3, oy = ay - (by - ay) / 3;
                thick(g, ox, oy, ex, ey, 4, col(OUT, tint, amt * 0.3F, al));
                thick(g, ox, oy, ex, ey, 2, col(0xFF7BCB5A, tint, amt, al));
                int mx = (ox + ex) / 2, my = (oy + ey) / 2;
                g.fill(mx - 1, my - 1, mx + 2, my + 2, col(0xFF4C9A3A, tint, amt, al));
            }
            case FightSim.BUNNY -> {
                int cx = X[3], cy = Y[3] - 3;
                thick(g, cx, cy + 2, cx, cy - 6, 4, col(OUT, tint, amt * 0.3F, al));
                thick(g, cx, cy + 2, cx, cy - 5, 2, col(0xFFFF9A3C, tint, amt, al));
                g.fill(cx - 1, cy - 8, cx, cy - 5, col(0xFF6BCB5A, tint, amt, al));
                g.fill(cx + 1, cy - 8, cx + 2, cy - 5, col(0xFF6BCB5A, tint, amt, al));
            }
            default -> {
                int cx = X[3] + d * 3, cy = Y[3];
                for (int k = -1; k <= 1; k++) g.fill(cx, cy + k * 2, cx + d * 4, cy + k * 2 + 1, col(0xFFFFFFFF, tint, amt, al));
            }
        }
    }

    // ---------------------------------------------------------------- the head and the face
    private static void head(GuiGraphics g, FightSim.F f, Rig r, int t, int hx, int hy, int tint, float amt, float al) {
        int ch = f.ch, d = f.face;
        int fur = FUR[ch];
        float lean = r.tailLag * 1.5F;
        // ears (behind the head)
        switch (ch) {
            case FightSim.CAT -> {
                opoly(g, new int[]{hx - 7, hx - 6, hx - 1}, new int[]{hy - 3, hy - 11, hy - 6}, fur, tint, amt, al);
                opoly(g, new int[]{hx + 7, hx + 6, hx + 1}, new int[]{hy - 3, hy - 11, hy - 6}, fur, tint, amt, al);
                Gfx.poly(g, new int[]{hx - 6, hx - 6, hx - 3}, new int[]{hy - 5, hy - 9, hy - 6}, col(0xFFFF9EB8, tint, amt, al));
                Gfx.poly(g, new int[]{hx + 6, hx + 6, hx + 3}, new int[]{hy - 5, hy - 9, hy - 6}, col(0xFFFF9EB8, tint, amt, al));
            }
            case FightSim.FOX -> {
                opoly(g, new int[]{hx - 7, hx - 6, hx - 1}, new int[]{hy - 3, hy - 14, hy - 6}, fur, tint, amt, al);
                opoly(g, new int[]{hx + 7, hx + 6, hx + 1}, new int[]{hy - 3, hy - 14, hy - 6}, fur, tint, amt, al);
                Gfx.poly(g, new int[]{hx - 6, hx - 6, hx - 5}, new int[]{hy - 10, hy - 14, hy - 11}, col(0xFF4A2A22, tint, amt, al));
                Gfx.poly(g, new int[]{hx + 6, hx + 6, hx + 5}, new int[]{hy - 10, hy - 14, hy - 11}, col(0xFF4A2A22, tint, amt, al));
            }
            case FightSim.PANDA -> {
                odisc(g, hx - 6, hy - 6, 3, FUR_DARK[ch], tint, amt, al);
                odisc(g, hx + 6, hy - 6, 3, FUR_DARK[ch], tint, amt, al);
            }
            default -> {
                int tilt = Math.round(-lean - 2 + (f.state == FightSim.HITSTUN ? -2 : 0)) * d;
                for (int s = -1; s <= 1; s += 2) {
                    int ex = hx + s * 4;
                    Gfx.rrect(g, ex - 3 + tilt / 2, hy - 20, 6, 14, 2, col(OUT, tint, amt * 0.3F, al));
                    Gfx.rrect(g, ex - 2 + tilt / 2, hy - 19, 4, 13, 2, col(fur, tint, amt, al));
                    g.fill(ex - 1 + tilt / 2, hy - 17, ex + 1 + tilt / 2, hy - 8, col(0xFFFF9EB8, tint, amt, al));
                }
            }
        }
        odisc(g, hx, hy, 7, fur, tint, amt, al);
        // cheek light and the lower face
        Gfx.ellipse(g, hx + d * 2, hy + 3, 5, 3, col(ch == FightSim.PANDA ? 0xFFFFFFFF : Gfx.lighter(fur, 0.55F), tint, amt, al * 0.9F));
        // markings
        if (ch == FightSim.CAT) for (int k = -1; k <= 1; k++) g.fill(hx + k * 2, hy - 7, hx + k * 2 + 1, hy - 4, col(FUR_DARK[ch], tint, amt, al));
        if (ch == FightSim.FOX) {
            Gfx.poly(g, new int[]{hx + d * 7, hx + d * 2, hx + d * 8}, new int[]{hy + 1, hy + 6, hy + 6}, col(0xFFFFFFFF, tint, amt, al));
            Gfx.poly(g, new int[]{hx - d * 7, hx - d * 2, hx - d * 8}, new int[]{hy + 1, hy + 6, hy + 6}, col(0xFFFFFFFF, tint, amt, al));
        }
        // eyes
        int e1 = hx + d, e2 = hx + d * 5, ey = hy - 1;
        boolean hurt = f.state == FightSim.HITSTUN || f.state == FightSim.KNOCKED;
        boolean dead = f.state == FightSim.KO || (f.state == FightSim.LYING && f.hp <= 0);
        boolean happy = f.state == FightSim.WIN;
        boolean block = f.state == FightSim.BLOCKSTUN;
        boolean angry = f.state == FightSim.ATTACK;
        if (ch == FightSim.PANDA) {
            Gfx.ellipse(g, e1, ey, 2, 3, col(0xFF2B2B36, tint, amt, al));
            Gfx.ellipse(g, e2, ey, 2, 3, col(0xFF2B2B36, tint, amt, al));
        }
        int ink = col(0xFF241A30, tint, amt * 0.5F, al), white = col(0xFFFFFFFF, tint, amt, al);
        int blinkNow = (t + ch * 37) % 170 < 5 ? 1 : 0;
        if (dead) {
            for (int e : new int[]{e1, e2}) { g.fill(e - 1, ey - 1, e, ey, ink); g.fill(e + 1, ey - 1, e + 2, ey, ink); g.fill(e, ey, e + 1, ey + 1, ink); g.fill(e - 1, ey + 1, e, ey + 2, ink); g.fill(e + 1, ey + 1, e + 2, ey + 2, ink); }
        } else if (hurt) {
            for (int e : new int[]{e1, e2}) {
                boolean far = e == e1;
                for (int k = 0; k < 3; k++) g.fill(far ? e - 1 + k : e + 1 - k + (d == 1 ? 0 : 0), ey - 1 + (k == 1 ? 1 : 0), (far ? e - 1 + k : e + 1 - k) + 1, ey + (k == 1 ? 2 : 1), ink);
            }
        } else if (happy) {
            for (int e : new int[]{e1, e2}) { g.fill(e - 1, ey, e, ey + 1, ink); g.fill(e, ey - 1, e + 1, ey, ink); g.fill(e + 1, ey, e + 2, ey + 1, ink); }
        } else if (block || blinkNow == 1) {
            g.fill(e1 - 1, ey + 1, e1 + 2, ey + 2, ink); g.fill(e2 - 1, ey + 1, e2 + 2, ey + 2, ink);
        } else {
            g.fill(e1 - 1, ey - 1, e1 + 1, ey + 2, ink); g.fill(e2 - 1, ey - 1, e2 + 1, ey + 2, ink);
            g.fill(e1 - 1, ey - 1, e1, ey, white); g.fill(e2 - 1, ey - 1, e2, ey, white);
        }
        if (angry) {                                         // fierce brows
            thick(g, e1 - 2, ey - 3 - (d == 1 ? 0 : 1), e1 + 2, ey - 2 - (d == 1 ? 1 : 0), 1, ink);
            thick(g, e2 - 2, ey - 2 - (d == 1 ? 1 : 0), e2 + 2, ey - 3 - (d == 1 ? 0 : 1), 1, ink);
        }
        // cheeks, nose, mouth
        g.fill(e1 - 1, ey + 3, e1 + 1, ey + 4, col(0xFFFF8FB0, tint, amt * 0.4F, al * 0.8F));
        g.fill(e2 - 1, ey + 3, e2 + 1, ey + 4, col(0xFFFF8FB0, tint, amt * 0.4F, al * 0.8F));
        int nx = hx + d * 6, ny = hy + 2;
        g.fill(nx - 1, ny, nx + 1, ny + 1, col(ch == FightSim.PANDA ? 0xFF2B2B36 : 0xFFE0508A, tint, amt * 0.4F, al));
        int mx = hx + d * 4;
        if (angry || hurt) { g.fill(mx - 1, hy + 4, mx + 2, hy + 6, ink); g.fill(mx, hy + 5, mx + 1, hy + 6, col(0xFFFF7A9A, tint, amt * 0.3F, al)); }
        else if (happy) { g.fill(mx - 1, hy + 4, mx + 2, hy + 5, ink); g.fill(mx - 1, hy + 5, mx + 2, hy + 6, ink); g.fill(mx, hy + 5, mx + 1, hy + 6, col(0xFFFF7A9A, tint, amt * 0.3F, al)); }
        else g.fill(mx - 1, hy + 5, mx + 2, hy + 6, ink);
        // the headband with two tails
        int belt = BELT[ch];
        g.fill(hx - 7, hy - 4, hx + 8, hy - 1, col(OUT, tint, amt * 0.3F, al));
        g.fill(hx - 6, hy - 3, hx + 7, hy - 2, col(belt, tint, amt, al));
        int fl = Math.round((float) Math.sin(t * 0.3F + ch) * 2F), trail = Math.round(-r.tailLag * 2F);
        thick(g, hx - d * 6, hy - 3, hx - d * 11 + trail, hy - 2 + fl, 2, col(belt, tint, amt, al));
        thick(g, hx - d * 6, hy - 3, hx - d * 10 + trail, hy + 1 - fl, 2, col(Gfx.darker(belt, 0.15F), tint, amt, al));
    }

    /** A little round face for the HUD. */
    static void portrait(GuiGraphics g, int ch, int cx, int cy, int rad) {
        Gfx.disc(g, cx, cy, rad + 1, 0xFFFFE27A);
        Gfx.disc(g, cx, cy, rad, GI[ch]);
        int r = rad - 1;
        Gfx.disc(g, cx, cy + 1, r, FUR[ch]);
        // ears
        int ex = r - 1;
        switch (ch) {
            case FightSim.CAT, FightSim.FOX -> {
                Gfx.poly(g, new int[]{cx - ex - 1, cx - ex + 1, cx - 1}, new int[]{cy - r + 2, cy - r - 3, cy - r + 1}, FUR[ch]);
                Gfx.poly(g, new int[]{cx + ex + 1, cx + ex - 1, cx + 1}, new int[]{cy - r + 2, cy - r - 3, cy - r + 1}, FUR[ch]);
            }
            case FightSim.PANDA -> { Gfx.disc(g, cx - ex, cy - r + 1, 2, FUR_DARK[ch]); Gfx.disc(g, cx + ex, cy - r + 1, 2, FUR_DARK[ch]); }
            default -> { g.fill(cx - ex, cy - r - 4, cx - ex + 2, cy - r + 1, FUR[ch]); g.fill(cx + ex - 1, cy - r - 4, cx + ex + 1, cy - r + 1, FUR[ch]); }
        }
        Gfx.disc(g, cx, cy + 1, r, FUR[ch]);
        if (ch == FightSim.PANDA) { Gfx.ellipse(g, cx - 3, cy, 1, 2, 0xFF2B2B36); Gfx.ellipse(g, cx + 3, cy, 1, 2, 0xFF2B2B36); }
        g.fill(cx - 3, cy, cx - 2, cy + 2, 0xFF241A30); g.fill(cx + 2, cy, cx + 3, cy + 2, 0xFF241A30);
        g.fill(cx, cy + 3, cx + 1, cy + 4, 0xFFE0508A);
        g.fill(cx - 5, cy - 2 - (r > 6 ? 1 : 0), cx + 6, cy - 1 - (r > 6 ? 1 : 0), BELT[ch]);
    }

    // ================================================================ the stages
    static final int STAGES = 3;

    static void stage(GuiGraphics g, int st, int t, int par) {
        switch (st) {
            case 1 -> bamboo(g, t, par);
            case 2 -> festival(g, t, par);
            default -> sunset(g, t, par);
        }
    }

    private static float hash(int i, int k) {
        int h = i * 374761393 + k * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535F;
    }

    private static void floorBoards(GuiGraphics g, int top, int bottom, int lineC, int seamC, int edgeC, int shift) {
        g.fillGradient(0, FLOOR, FightSim.W, 140, top, bottom);
        g.fill(0, FLOOR, FightSim.W, FLOOR + 1, edgeC);
        int[] ys = {FLOOR + 7, FLOOR + 15, FLOOR + 25};
        for (int y : ys) g.fill(0, y, FightSim.W, y + 1, lineC);
        for (int row = 0; row < 3; row++) {
            int y0 = row == 0 ? FLOOR + 1 : ys[row - 1] + 1, y1 = ys[row];
            int step = 26 + row * 10;
            for (int x = -((shift * (row + 1)) % step) - (row * 9) % step; x < FightSim.W; x += step) g.fill(x, y0, x + 1, y1, seamC);
        }
    }

    // ---------------------------------------------------------------- 1: sunset dojo
    private static void sunset(GuiGraphics g, int t, int par) {
        int W = FightSim.W;
        g.fillGradient(0, 0, W, 44, 0xFF2B1B54, 0xFFA8467F);
        g.fillGradient(0, 44, W, 84, 0xFFA8467F, 0xFFFF9A7A);
        g.fillGradient(0, 84, W, FLOOR, 0xFFFF9A7A, 0xFFFFD0A0);
        // the sun with stripes
        int sx = 138 - par / 4, sy = 72;
        Gfx.glow(g, sx, sy, 46, 0xFFC890, 120);
        Gfx.disc(g, sx, sy, 24, 0xFFFFE2A8);
        for (int k = 0; k < 6; k++) g.fill(sx - 25, sy + 4 + k * 4, sx + 26, sy + 4 + k * 4 + k / 2 + 1, Gfx.mix(0xFFFF9A7A, 0xFFFFD0A0, k / 6F));
        // clouds
        for (int i = 0; i < 4; i++) {
            int cx = (int) ((i * 70 + t * 0.06F * (1 + i % 2)) % (W + 80)) - 40 - par / 6;
            g.fill(cx, 24 + i * 9, cx + 34 + i * 6, 26 + i * 9, Gfx.alpha(0xFFFFC8D8, 150));
            g.fill(cx + 8, 26 + i * 9, cx + 30 + i * 6, 27 + i * 9, Gfx.alpha(0xFFFFC8D8, 90));
        }
        // far and near mountains
        int p1 = -par / 5, p2 = -par / 3;
        Gfx.poly(g, new int[]{-10 + p1, 30 + p1, 60 + p1, 100 + p1, 150 + p1, 190 + p1, 240 + p1, 240 + p1, -10 + p1}, new int[]{FLOOR, 84, 94, 74, 92, 80, 96, FLOOR, FLOOR}, 0xFF8A4F94);
        Gfx.poly(g, new int[]{-10 + p2, 20 + p2, 70 + p2, 120 + p2, 170 + p2, 215 + p2, 240 + p2, 240 + p2, -10 + p2}, new int[]{FLOOR, 96, 88, 100, 90, 98, 94, FLOOR, FLOOR}, 0xFF5A3578);
        // the pagoda on the hill
        int px = 150 + p2;
        Gfx.poly(g, new int[]{px - 46, px - 26, px + 26, px + 46}, new int[]{FLOOR, 103, 103, FLOOR}, 0xFF3C2358);
        int[] tw = {26, 20, 14};
        for (int k = 0; k < 3; k++) {
            int y = 104 - k * 13, w = tw[k];
            g.fill(px - w / 2 + 2, y - 8, px + w / 2 - 2, y, 0xFF2E1A4A);
            Gfx.poly(g, new int[]{px - w / 2 - 6, px, px + w / 2 + 6}, new int[]{y - 7, y - 14, y - 7}, 0xFF2E1A4A);
            g.fill(px - w / 2 - 7, y - 8, px + w / 2 + 7, y - 6, 0xFF2E1A4A);
            if (hash(k, 3) > 0.1F) { g.fill(px - 2, y - 5, px + 2, y - 1, 0xFFFFD27A); g.fill(px - w / 2 + 3, y - 4, px - w / 2 + 5, y - 1, 0xFFFFD27A); }
        }
        g.fill(px - 1, 104 - 3 * 13 - 14, px + 1, 104 - 3 * 13 - 8, 0xFF2E1A4A);
        // the cherry tree on the left
        int tx = 22 - par / 2;
        thick(g, tx + 6, FLOOR, tx + 2, 70, 7, 0xFF4A2A3A);
        thick(g, tx + 2, 78, tx + 26, 56, 4, 0xFF4A2A3A);
        thick(g, tx + 3, 84, tx - 16, 62, 4, 0xFF4A2A3A);
        int[][] bl = {{tx - 14, 58, 14}, {tx + 4, 46, 16}, {tx + 24, 52, 15}, {tx - 2, 62, 14}, {tx + 16, 66, 12}, {tx - 24, 68, 10}};
        for (int[] b : bl) { Gfx.disc(g, b[0], b[1], b[2], 0xFFFF8FB8); Gfx.disc(g, b[0] - 2, b[1] - 2, b[2] - 4, 0xFFFFB7D1); }
        // the floor
        floorBoards(g, 0xFFB8794A, 0xFF7A4A2E, 0xFF8A5634, 0xFF8A5634, 0xFFFFD6A0, t / 2);
        g.fill(0, FLOOR + 1, W, FLOOR + 2, Gfx.alpha(0xFFFFFFFF, 60));
        // a red mat in the middle
        g.fillGradient(34, FLOOR + 12, W - 34, FLOOR + 22, Gfx.alpha(0xFFC83A48, 120), Gfx.alpha(0xFF8A2030, 140));
        // lanterns at the top
        for (int k = 0; k < 4; k++) lantern(g, 24 + k * 57 - par / 8, 0, 14 + (k % 2) * 3, 0xFFE0484F, t, k);
        // falling petals
        for (int i = 0; i < 20; i++) {
            float ph = hash(i, 11);
            float x = (hash(i, 5) * 260 + t * (0.18F + ph * 0.2F) + (float) Math.sin(t * 0.03F + i) * 8) % 250 - 15;
            float y = (hash(i, 7) * 160 + t * (0.3F + ph * 0.25F)) % 150 - 10;
            g.fill(Math.round(x), Math.round(y), Math.round(x) + 2, Math.round(y) + 1, 0xFFFFC0D8);
            g.fill(Math.round(x) + 1, Math.round(y) + 1, Math.round(x) + 3, Math.round(y) + 2, 0xFFFF9EC0);
        }
    }

    private static void lantern(GuiGraphics g, int x, int top, int len, int color, int t, int k) {
        int sway = Math.round((float) Math.sin(t * 0.03F + k) * 2F);
        int y = top + len;
        g.fill(x + sway / 2, top, x + sway / 2 + 1, y, 0xFF3A2A44);
        Gfx.glow(g, x + sway, y + 6, 12, color & 0xFFFFFF, 130);
        Gfx.rrect(g, x - 5 + sway, y, 11, 13, 4, Gfx.darker(color, 0.5F));
        Gfx.rrect(g, x - 4 + sway, y + 1, 9, 11, 4, color);
        g.fill(x - 3 + sway, y + 3, x + 3 + sway, y + 4, Gfx.lighter(color, 0.5F));
        g.fill(x - 3 + sway, y + 7, x + 3 + sway, y + 8, Gfx.lighter(color, 0.3F));
        g.fill(x - 2 + sway, y + 13, x + 3 + sway, y + 14, 0xFF3A2A44);
    }

    // ---------------------------------------------------------------- 2: moonlit bamboo
    private static void bamboo(GuiGraphics g, int t, int par) {
        int W = FightSim.W;
        g.fillGradient(0, 0, W, 70, 0xFF0B1030, 0xFF1C2F5C);
        g.fillGradient(0, 70, W, FLOOR, 0xFF1C2F5C, 0xFF3A5A82);
        for (int i = 0; i < 46; i++) {
            float tw = 0.5F + 0.5F * (float) Math.sin(t * 0.05F + i * 1.7F);
            int x = (int) (hash(i, 1) * W), y = (int) (hash(i, 2) * 70);
            g.fill(x, y, x + 1, y + 1, Gfx.alpha(0xFFFFFFFF, 90 + Math.round(150 * tw)));
        }
        int mx = 54 - par / 5, my = 36;
        Gfx.glow(g, mx, my, 40, 0xBFD8FF, 110);
        Gfx.disc(g, mx, my, 16, 0xFFFFF4D0);
        Gfx.disc(g, mx + 5, my - 4, 3, 0xFFEBDDB0); Gfx.disc(g, mx - 5, my + 5, 4, 0xFFEBDDB0); Gfx.disc(g, mx + 6, my + 6, 2, 0xFFEBDDB0);
        for (int i = 0; i < 3; i++) {
            int cx = (int) ((i * 90 + t * 0.05F * (1 + i)) % (W + 100)) - 50;
            g.fill(cx, 30 + i * 14, cx + 52, 32 + i * 14, Gfx.alpha(0xFF5A7AA8, 120));
            g.fill(cx + 10, 32 + i * 14, cx + 44, 33 + i * 14, Gfx.alpha(0xFF5A7AA8, 70));
        }
        // far bamboo
        for (int i = 0; i < 16; i++) {
            int x = (int) (i * 15 + hash(i, 4) * 8) - par / 4;
            g.fill(x, 40, x + 3, FLOOR, 0xFF1D4A5A);
            for (int n = 0; n < 6; n++) g.fill(x, 46 + n * 12, x + 3, 47 + n * 12, 0xFF123340);
        }
        // the red gate
        int gx = 150 - par / 3;
        g.fill(gx - 22, 58, gx - 17, FLOOR - 4, 0xFF8E2A38); g.fill(gx + 17, 58, gx + 22, FLOOR - 4, 0xFF8E2A38);
        Gfx.poly(g, new int[]{gx - 32, gx + 32, gx + 26, gx - 26}, new int[]{52, 52, 58, 58}, 0xFFAE3446);
        g.fill(gx - 24, 64, gx + 24, 68, 0xFF8E2A38);
        g.fill(gx - 32, 51, gx + 32, 52, 0xFFD0485A);
        Gfx.glow(g, gx, 62, 36, 0xFF6A80, 40);
        // near bamboo at both edges
        for (int s = 0; s < 2; s++) {
            for (int i = 0; i < 3; i++) {
                int x = s == 0 ? 4 + i * 9 - par / 2 : W - 12 - i * 9 - par / 2;
                int sway = Math.round((float) Math.sin(t * 0.02F + i + s * 2) * 1.5F);
                for (int y = 0; y < FLOOR; y += 18) {
                    int off = Math.round(sway * (1F - y / (float) FLOOR));
                    g.fill(x + off, y, x + 5 + off, y + 17, 0xFF2F7A4F);
                    g.fill(x + off, y, x + 2 + off, y + 17, 0xFF48A36A);
                    g.fill(x + off - 1, y + 17, x + 6 + off, y + 18, 0xFF1F5236);
                }
                int ly = 30 + i * 22 + s * 9;
                Gfx.poly(g, new int[]{x + 5, x + 20, x + 8}, new int[]{ly, ly - 3, ly + 5}, 0xFF48A36A);
                Gfx.poly(g, new int[]{x, x - 14, x - 2}, new int[]{ly + 12, ly + 9, ly + 16}, 0xFF3A8A58);
            }
        }
        floorBoards(g, 0xFF55667A, 0xFF27303F, 0xFF3C4A5C, 0xFF3C4A5C, 0xFF9AB4D0, 0);
        Gfx.ellipse(g, 70, FLOOR + 14, 54, 6, Gfx.alpha(0xFFBFD8FF, 28));
        for (int i = 0; i < 9; i++) g.fill((int) (hash(i, 9) * W), FLOOR + 3 + (int) (hash(i, 8) * 22), (int) (hash(i, 9) * W) + 3, FLOOR + 4 + (int) (hash(i, 8) * 22), Gfx.alpha(0xFF4FA36A, 150));
        // fireflies
        for (int i = 0; i < 14; i++) {
            float x = hash(i, 21) * W + (float) Math.sin(t * 0.017F + i * 2.1F) * 14;
            float y = 40 + hash(i, 22) * 80 + (float) Math.cos(t * 0.021F + i * 1.3F) * 8;
            float pulse = 0.4F + 0.6F * (float) Math.sin(t * 0.07F + i * 3F) * (float) Math.sin(t * 0.07F + i * 3F);
            Gfx.glow(g, Math.round(x), Math.round(y), 4, 0xE8FF8A, Math.round(150 * pulse));
            g.fill(Math.round(x), Math.round(y), Math.round(x) + 1, Math.round(y) + 1, Gfx.alpha(0xFFF8FFC8, Math.round(255 * pulse)));
        }
    }

    // ---------------------------------------------------------------- 3: festival night
    private static void festival(GuiGraphics g, int t, int par) {
        int W = FightSim.W;
        g.fillGradient(0, 0, W, 64, 0xFF140A2E, 0xFF35185A);
        g.fillGradient(0, 64, W, FLOOR, 0xFF35185A, 0xFF6A2E7A);
        for (int i = 0; i < 30; i++) {
            float tw = 0.5F + 0.5F * (float) Math.sin(t * 0.06F + i * 2.3F);
            g.fill((int) (hash(i, 31) * W), (int) (hash(i, 32) * 50), (int) (hash(i, 31) * W) + 1, (int) (hash(i, 32) * 50) + 1, Gfx.alpha(0xFFFFFFFF, 60 + Math.round(150 * tw)));
        }
        // fireworks: three bursts that take turns
        int[] fcol = {0xFFFF6AD5, 0xFFFFD24A, 0xFF6AE0FF};
        for (int k = 0; k < 3; k++) {
            int period = 150, ph = (t + k * 50) % period, cyc = (t + k * 50) / period;
            if (ph > 70) continue;
            int cx = 40 + (int) (hash(cyc, k + 40) * 140) - par / 6, cy = 22 + (int) (hash(cyc, k + 50) * 30);
            float rad = ph < 12 ? ph * 2.2F : 26 + (ph - 12) * 0.12F;
            float fade = ph < 40 ? 1F : 1F - (ph - 40) / 30F;
            int col = fcol[(cyc + k) % 3];
            if (ph < 12) { g.fill(cx, cy + 40 - ph * 3, cx + 1, cy + 42 - ph * 3, 0xFFFFE8B0); continue; }
            Gfx.glow(g, cx, cy, 20, col & 0xFFFFFF, Math.round(60 * fade));
            for (int s = 0; s < 14; s++) {
                double a = s * Math.PI * 2 / 14;
                float dr = rad * (0.85F + 0.15F * hash(s, k));
                int ex = cx + (int) Math.round(Math.cos(a) * dr), ey = cy + (int) Math.round(Math.sin(a) * dr) + Math.round((ph - 12) * (ph - 12) * 0.004F);
                g.fill(ex, ey, ex + 2, ey + 2, Gfx.alpha(col, Math.round(255 * fade)));
                int bx = cx + (int) Math.round(Math.cos(a) * dr * 0.7F), by = cy + (int) Math.round(Math.sin(a) * dr * 0.7F);
                g.fill(bx, by, bx + 1, by + 1, Gfx.alpha(col, Math.round(150 * fade)));
            }
        }
        // the crowd of little pets
        for (int i = 0; i < 20; i++) {
            int x = i * 12 + 4 - par / 3, bob = Math.round((float) Math.sin(t * 0.1F + i * 1.9F) * 1.5F);
            int y = 92 + (i % 3) * 3 + bob;
            int sh = i % 2 == 0 ? 0xFF241040 : 0xFF2E1650;
            Gfx.disc(g, x, y, 5, sh);
            g.fill(x - 6, y + 4, x + 7, FLOOR, sh);
            int kind = i % 3;
            if (kind == 0) { Gfx.poly(g, new int[]{x - 5, x - 4, x - 1}, new int[]{y - 2, y - 9, y - 4}, sh); Gfx.poly(g, new int[]{x + 5, x + 4, x + 1}, new int[]{y - 2, y - 9, y - 4}, sh); }
            else if (kind == 1) { g.fill(x - 4, y - 12, x - 1, y - 3, sh); g.fill(x + 1, y - 12, x + 4, y - 3, sh); }
            else { Gfx.disc(g, x - 5, y - 4, 2, sh); Gfx.disc(g, x + 5, y - 4, 2, sh); }
            if (i % 4 == 1) {                                                       // a glow stick in the air
                int sx = x + 6, sy = y - 10 + Math.round((float) Math.sin(t * 0.15F + i) * 3F);
                int sc = fcol[(i / 4) % 3];
                thick(g, sx, sy + 6, sx + 2, sy, 2, sc);
                Gfx.glow(g, sx + 1, sy + 2, 6, sc & 0xFFFFFF, 90);
            }
            g.fill(x - 2, y - 1, x - 1, y, Gfx.alpha(0xFFFFE8A0, 200)); g.fill(x + 1, y - 1, x + 2, y, Gfx.alpha(0xFFFFE8A0, 200));
        }
        // string lights
        for (int row = 0; row < 2; row++) {
            int prevX = -1, prevY = 0;
            for (int x = -4; x <= W + 4; x += 6) {
                float u = (x + 4) / (float) (W + 8);
                int y = 8 + row * 10 + Math.round(8F * (float) Math.sin(u * Math.PI * (2 + row)) * 0.5F + 6F * (float) Math.sin(u * Math.PI));
                if (prevX >= 0) Gfx.line(g, prevX, prevY, x, y, 0xFF2A1A3A);
                prevX = x; prevY = y;
                if (((x / 6) + row) % 2 == 0) {
                    int c = fcol[((x / 6) + t / 40 + row) % 3];
                    boolean on = ((t / 20 + x / 6) % 4) != 0;
                    Gfx.glow(g, x, y + 2, 5, c & 0xFFFFFF, on ? 120 : 30);
                    g.fill(x - 1, y + 1, x + 1, y + 4, on ? c : Gfx.darker(c, 0.5F));
                }
            }
        }
        for (int k = 0; k < 3; k++) lantern(g, 30 + k * 80 - par / 8, 0, 22 + k % 2 * 4, k == 1 ? 0xFFFFA23A : 0xFFE04A8A, t, k + 4);
        // the stage floor with neon edge and moving spotlights
        floorBoards(g, 0xFF3A2A5A, 0xFF1F1636, 0xFF2C2048, 0xFF2C2048, 0xFFFF6AD5, 0);
        g.fill(0, FLOOR + 1, W, FLOOR + 2, Gfx.alpha(0xFFFF6AD5, 70));
        int s1 = 60 + Math.round((float) Math.sin(t * 0.02F) * 40), s2 = 160 - Math.round((float) Math.sin(t * 0.02F) * 40);
        Gfx.ellipse(g, s1, FLOOR + 14, 40, 7, Gfx.alpha(0xFFFF6AD5, 40));
        Gfx.ellipse(g, s2, FLOOR + 14, 40, 7, Gfx.alpha(0xFF6AE0FF, 40));
    }

    /** A soft dark frame around the picture. */
    static void vignette(GuiGraphics g, int w, int h, int strength) {
        g.fillGradient(0, 0, w, 14, Gfx.alpha(0xFF000000, strength), 0x00000000);
        g.fillGradient(0, h - 14, w, h, 0x00000000, Gfx.alpha(0xFF000000, strength));
    }
}
