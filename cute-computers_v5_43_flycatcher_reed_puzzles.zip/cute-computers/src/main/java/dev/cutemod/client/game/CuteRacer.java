package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Cute Racer: a top-down road race. Your pink kitty car follows the mouse (or the arrow keys / A and D); dodge the
 * other cars and cones, grab coins (+5) and stars (a few seconds of shield and speed), pick up hearts to repair.
 * 3 hearts; the road gets faster the longer you drive. Score = distance / 14 + 5 per coin.
 */
public class CuteRacer extends MiniGame {
    private static final int ROAD_X = 50, ROAD_W = 120, LANES = 4, LANE_W = ROAD_W / LANES;
    private static final int CAR_W = 16, CAR_H = 26, PY = H - 34;
    private static final int[] CAR_COL = {0xFF5BA8F0, 0xFFF2C94C, 0xFF7ED957, 0xFFB57BD6, 0xFFFF9C5B, 0xFFEDEDED};
    // obstacle kinds
    private static final int CAR = 0, CONE = 1, COIN = 2, STAR = 3, HEART = 4;

    private double px, targetX, dist, speed, scroll;
    private int lives, coins, spawnT, invuln, boost, ready, shake, lastMx, ticks;
    private boolean keyMode;
    private final List<double[]> things = new ArrayList<>();      // x, y, kind, color index
    private final List<double[]> deco = new ArrayList<>();        // x, y, kind (0 tree, 1 flower, 2 bush)

    @Override
    public void reset() {
        score = 0; over = false;
        px = targetX = ROAD_X + ROAD_W / 2.0;
        dist = 0; speed = 1.6; scroll = 0;
        lives = 3; coins = 0; spawnT = 50; invuln = 0; boost = 0; ready = 100; shake = 0; ticks = 0;
        keyMode = false; lastMx = mx;
        things.clear();
        deco.clear();
        for (int i = 0; i < 14; i++) addDeco(rnd.nextInt(H));
    }

    private void addDeco(double y) {
        boolean left = rnd.nextBoolean();
        double x = left ? 4 + rnd.nextInt(ROAD_X - 18) : ROAD_X + ROAD_W + 8 + rnd.nextInt(ROAD_X - 18);
        deco.add(new double[]{x, y, rnd.nextInt(3)});
    }

    private static double laneX(int lane) { return ROAD_X + LANE_W * lane + LANE_W / 2.0; }

    @Override
    public void tick() {
        ticks++;
        if (ready > 0) { ready--; return; }
        // steering: the mouse, or the keys until the mouse moves again
        if (Math.abs(mx - lastMx) > 1) { keyMode = false; lastMx = mx; }
        if (!keyMode) targetX = mx;
        targetX = Math.max(ROAD_X + CAR_W / 2.0 + 2, Math.min(ROAD_X + ROAD_W - CAR_W / 2.0 - 2, targetX));
        px += (targetX - px) * 0.22;

        double base = 1.6 + Math.min(dist / 2400.0, 1.0) * 2.4;
        speed = base + (boost > 0 ? 1.3 : 0);
        dist += speed;
        scroll = (scroll + speed) % 24;
        score = (int) (dist / 14) + coins * 5;
        if (invuln > 0) invuln--;
        if (boost > 0) boost--;
        if (shake > 0) shake--;

        // scenery scrolls and is recycled
        for (double[] d : deco) { d[1] += speed; if (d[1] > H + 10) { d[1] = -10; d[0] = (rnd.nextBoolean() ? 4 + rnd.nextInt(ROAD_X - 18) : ROAD_X + ROAD_W + 8 + rnd.nextInt(ROAD_X - 18)); d[2] = rnd.nextInt(3); } }

        // new things on the road
        if (--spawnT <= 0) {
            spawnT = (int) Math.max(26, 70 - dist / 70);
            spawn();
        }
        for (int i = things.size() - 1; i >= 0; i--) {
            double[] t = things.get(i);
            t[1] += t[2] == CAR ? speed * 0.55 : speed;           // other cars drive the same way, slower than you
            if (t[1] > H + 30) { things.remove(i); continue; }
            if (hit(t)) {
                int k = (int) t[2];
                if (k == COIN) { coins++; things.remove(i); pling(1.2F + Math.min(coins, 10) * 0.05F); }
                else if (k == STAR) { boost = 240; invuln = Math.max(invuln, 240); things.remove(i); pling(1.8F); }
                else if (k == HEART) { if (lives < 3) lives++; things.remove(i); pling(1.5F); }
                else if (invuln <= 0) { crash(); things.remove(i); }
            }
        }
    }

    private void spawn() {
        int lane = rnd.nextInt(LANES);
        int roll = rnd.nextInt(100);
        if (roll < 48) {
            things.add(new double[]{laneX(lane), -CAR_H, CAR, rnd.nextInt(CAR_COL.length)});
            if (dist > 800 && rnd.nextInt(100) < 30) {               // sometimes two cars side by side, never more
                int other = (lane + 1 + rnd.nextInt(LANES - 1)) % LANES;
                things.add(new double[]{laneX(other), -CAR_H - 6, CAR, rnd.nextInt(CAR_COL.length)});
            }
        } else if (roll < 74) {
            things.add(new double[]{laneX(lane), -8, CONE, 0});
        } else if (roll < 94) {
            for (int i = 0; i < 3; i++) things.add(new double[]{laneX(lane), -8 - i * 18, COIN, 0});
        } else if (roll < 98) {
            things.add(new double[]{laneX(lane), -8, STAR, 0});
        } else if (lives < 3) {
            things.add(new double[]{laneX(lane), -8, HEART, 0});
        }
    }

    private boolean hit(double[] t) {
        int k = (int) t[2];
        double hw = k == CAR ? 7 : k == CONE ? 5 : 7, hh = k == CAR ? 12 : k == CONE ? 6 : 7;
        return Math.abs(t[0] - px) < hw + 6 && Math.abs(t[1] - PY) < hh + 10;
    }

    private void crash() {
        lives--;
        invuln = 100;
        shake = 14;
        dist = Math.max(0, dist - 120);                          // a crash costs a little speed: the road gets easier again for a moment
        dev.cutemod.client.os.Sfx.ui(SoundEvents.NOTE_BLOCK_BASS.value(), 0.55F, 0.7F);
        if (lives <= 0) { over = true; score = (int) (dist / 14) + coins * 5; }
    }

    @Override
    public boolean key(int keyCode) {
        if (keyCode == KEY_LEFT || keyCode == 65) { keyMode = true; targetX = Math.max(ROAD_X + 10, targetX - LANE_W); lastMx = mx; return true; }
        if (keyCode == KEY_RIGHT || keyCode == 68) { keyMode = true; targetX = Math.min(ROAD_X + ROAD_W - 10, targetX + LANE_W); lastMx = mx; return true; }
        return false;
    }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g) {
        int sx = shake > 0 ? (int) (Math.sin(ticks * 2.1) * 2) : 0;
        g.fillGradient(0, 0, W, H, 0xFF9BDB8F, 0xFF78C27C);                // grass
        for (int y = 0; y < H; y += 12) rect(g, 0, y, ROAD_X - 6, 6, 0x1A2E8A3E);   // soft stripes of mowed grass
        for (int y = 0; y < H; y += 12) rect(g, ROAD_X + ROAD_W + 6, y, W, 6, 0x1A2E8A3E);
        for (double[] d : deco) drawDeco(g, (int) d[0], (int) d[1], (int) d[2]);
        // road: asphalt gradient, speckles that scroll, pink and white curbs
        g.fillGradient(ROAD_X + sx, 0, ROAD_X + ROAD_W + sx, H, 0xFF52526C, 0xFF3C3C50);
        for (int i = 0; i < 16; i++) rect(g, ROAD_X + 4 + (int) (Gfx.hash(i, 34) * (ROAD_W - 8)) + sx, (int) ((Gfx.hash(i, 35) * H + scroll) % H), 2, 1, 0x1AFFFFFF);
        int curbOff = (int) (scroll % 16);
        for (int y = -16; y < H; y += 8) {
            int yy = y + curbOff;
            boolean pink = (((y + 16) / 8) & 1) == 0;
            rect(g, ROAD_X - 5 + sx, yy, 5, 8, pink ? 0xFFF58FB8 : 0xFFFFFFFF);
            rect(g, ROAD_X + ROAD_W + sx, yy, 5, 8, pink ? 0xFFF58FB8 : 0xFFFFFFFF);
        }
        rect(g, ROAD_X - 6 + sx, 0, 1, H, 0x33000000); rect(g, ROAD_X + ROAD_W + 5 + sx, 0, 1, H, 0x33000000);
        for (int l = 1; l < LANES; l++) {                                  // lane dashes that scroll
            for (double y = -24 + scroll; y < H; y += 24) Gfx.rrect(g, ROAD_X + l * LANE_W - 1 + sx, (int) y, 2, 12, 1, l == LANES / 2 ? 0xFFF3C45A : 0x99FFFFFF);
        }

        for (double[] t : things) drawThing(g, t, sx);
        drawPlayer(g, sx);

        // speed lines when boosting
        if (boost > 0) for (int i = 0; i < 8; i++) rect(g, ROAD_X + 6 + (i * 37 + ticks * 5) % (ROAD_W - 12) + sx, (i * 53 + ticks * 11) % H, 1, 10, 0x66FFFFFF);

        // HUD
        g.fillGradient(0, 0, W, 13, 0xAA000000, 0x33000000);
        text(g, Integer.toString(score), 5, 3, 0xFFFFFFFF);
        for (int i = 0; i < 3; i++) Gfx.heart(g, W - 12 - i * 11, 3, i < lives ? 0xFFFF5C7C : 0x55FFFFFF);
        int bar = (int) (60 * Math.min(1.0, (speed - 1.6) / 3.7));
        Gfx.rrect(g, 59, 3, 62, 6, 2, 0x66000000);
        if (bar > 1) Gfx.rrect(g, 60, 4, bar, 4, 1, boost > 0 ? 0xFFFFD84A : 0xFF7ED957);
        if (bar > 3) rect(g, 61, 4, bar - 2, 1, 0x66FFFFFF);
        if (ready > 0) {
            String s = ready > 66 ? "3" : ready > 33 ? "2" : "1";
            Gfx.rrect(g, W / 2 - 26, 50, 52, 24, 6, 0xCC000000);
            ctext(g, s, W / 2, 58, 0xFFFFFFFF);
        } else if (ticks < 130) {
            ctext(g, "GO!", W / 2, 58, 0xFFFFD84A);
        }
    }

    private static void drawDeco(GuiGraphics g, int x, int y, int kind) {
        if (kind == 0) {                                                    // a round tree seen from above
            disc(g, x + 3, y + 3, 7, 0x33000000);
            disc(g, x, y, 7, 0xFF3F9A4E);
            disc(g, x - 1, y - 1, 5, 0xFF4FAE5E);
            disc(g, x - 3, y - 3, 3, 0xFF7FD98A);
        } else if (kind == 1) {                                             // a flower
            int pet = (x / 7 + y / 5) % 3 == 0 ? 0xFFFFFFFF : (x / 7 + y / 5) % 3 == 1 ? 0xFFFFC2DC : 0xFFFFE27A;
            rect(g, x - 1, y, 3, 1, pet); rect(g, x, y - 1, 1, 3, pet);
            rect(g, x, y, 1, 1, 0xFFFF9A3A);
        } else {                                                            // a bush with a pink berry
            disc(g, x + 1, y + 1, 4, 0x33000000);
            disc(g, x, y, 4, 0xFF4FAE5E);
            disc(g, x - 1, y - 1, 2, 0xFF7FD98A);
            rect(g, x - 1, y - 2, 2, 2, 0xFFF58FB8);
        }
    }

    private void drawThing(GuiGraphics g, double[] t, int sx) {
        int x = (int) t[0] + sx, y = (int) t[1];
        switch ((int) t[2]) {
            case CAR -> car(g, x, y, CAR_COL[(int) t[3]], false);
            case CONE -> {
                Gfx.ellipse(g, x + 1, y + 5, 6, 2, 0x33000000);
                Gfx.rrect(g, x - 5, y + 2, 10, 4, 1, 0xFFFF9C5B);
                Gfx.poly(g, new int[]{x, x - 4, x + 4}, new int[]{y - 5, y + 3, y + 3}, 0xFFFF6A1F);
                rect(g, x - 2, y - 1, 4, 2, 0xFFFFFFFF);
                rect(g, x - 1, y - 4, 1, 2, 0x66FFFFFF);
            }
            case COIN -> {
                int w = 3 + (int) Math.abs(Math.sin((ticks + y) / 9.0) * 3);
                Gfx.ellipse(g, x, y, w, 5, 0xFFC98E10);
                Gfx.ellipse(g, x, y, Math.max(1, w - 1), 4, 0xFFFFD84A);
                if (w > 3) rect(g, x - w + 2, y - 2, 1, 3, 0xAAFFFFFF);
            }
            case STAR -> {
                Gfx.glow(g, x, y, 10, 0xFFFFE066, 90);
                Gfx.star5(g, x, y + 1, 8, 3, 0xFFD9A81A);
                Gfx.star5(g, x, y + 1, 7, 3, 0xFFFFD84A);
                Gfx.star5(g, x - 1, y, 3, 1, 0xFFFFF3B0);
            }
            default -> {
                Gfx.glow(g, x, y, 10, 0xFFFF5C7C, 90);
                Gfx.heart(g, x - 3, y - 3, 0xFFFF5C7C);
            }
        }
    }

    private void drawPlayer(GuiGraphics g, int sx) {
        if (invuln > 0 && boost <= 0 && (ticks / 4) % 2 == 0) return;     // blinks after a crash
        int x = (int) px + sx;
        if (boost > 0) Gfx.glow(g, x, PY, 22, (ticks / 4) % 2 == 0 ? 0xFFFFE066 : 0xFFFF9CCB, 110);
        car(g, x, PY, 0xFFF58FB8, true);
    }

    /** A little car seen from above, facing up: rounded body with a rim, shiny windows, lights and a soft shadow. The player's car has cat ears and a bow. */
    private static void car(GuiGraphics g, int cx, int cy, int col, boolean me) {
        int x = cx - CAR_W / 2, y = cy - CAR_H / 2;
        Gfx.rrect(g, x + 2, y + 3, CAR_W, CAR_H, 5, 0x33000000);                                         // shadow
        Gfx.rrect(g, x - 2, y + 3, 4, 8, 1, 0xFF1A1A26); Gfx.rrect(g, x + CAR_W - 2, y + 3, 4, 8, 1, 0xFF1A1A26);   // wheels
        Gfx.rrect(g, x - 2, y + CAR_H - 11, 4, 8, 1, 0xFF1A1A26); Gfx.rrect(g, x + CAR_W - 2, y + CAR_H - 11, 4, 8, 1, 0xFF1A1A26);
        Gfx.rrect(g, x, y, CAR_W, CAR_H, 5, Gfx.darker(col, 0.35f));                                     // body rim
        Gfx.rrect(g, x + 1, y + 1, CAR_W - 2, CAR_H - 2, 4, col);
        rect(g, x + 3, y + 2, CAR_W - 6, 1, 0x77FFFFFF);                                                  // hood shine
        Gfx.rrect(g, x + 3, y + 7, CAR_W - 6, 6, 2, 0xFF9FD8F5);                                          // windshield
        rect(g, x + 4, y + 8, CAR_W - 9, 1, 0xBBFFFFFF);
        Gfx.rrect(g, x + 3, y + 13, CAR_W - 6, 7, 2, Gfx.darker(col, 0.22f));                             // roof
        rect(g, x + 4, y + 14, CAR_W - 8, 1, 0x44FFFFFF);
        rect(g, x + 4, y + 20, CAR_W - 8, 2, 0xFF7FB8D8);                                                  // rear window
        rect(g, x + 2, y + CAR_H - 4, 4, 2, 0xFFFF5C5C); rect(g, x + CAR_W - 6, y + CAR_H - 4, 4, 2, 0xFFFF5C5C);   // tail lights
        rect(g, x + 2, y + 1, 4, 2, 0xFFFFF3B0); rect(g, x + CAR_W - 6, y + 1, 4, 2, 0xFFFFF3B0);        // headlights
        if (me) {
            Gfx.rrect(g, x + 1, y - 4, 4, 5, 1, col); Gfx.rrect(g, x + CAR_W - 5, y - 4, 4, 5, 1, col);   // ears
            rect(g, x + 2, y - 3, 2, 3, 0xFFFFC0D6); rect(g, x + CAR_W - 4, y - 3, 2, 3, 0xFFFFC0D6);
            Gfx.rrect(g, x + CAR_W / 2 - 4, y + 14, 8, 4, 1, 0xFFFFFFFF);                                  // a bow on the roof
            rect(g, x + CAR_W / 2 - 1, y + 14, 2, 4, 0xFFE5486F);
        }
    }

    @Override
    public String hintKey() { return "cutemod.hint.racer"; }
}
