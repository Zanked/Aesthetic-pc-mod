package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/** Purple computer: dodge the falling ender particles with the mouse. */
public class EnderDodge extends MiniGame {
    private double px, py;
    private int t;
    private final List<double[]> parts = new ArrayList<>(); // x, y, vy, size
    private final int[][] stars = new int[40][3];

    @Override
    public void reset() {
        score = 0; over = false; t = 0; px = W / 2.0; py = H - 24;
        parts.clear();
        for (int[] s : stars) { s[0] = rnd.nextInt(W); s[1] = rnd.nextInt(H); s[2] = rnd.nextInt(3); }
    }

    @Override
    public void tick() {
        t++;
        if (t % 300 == 150) sound(net.minecraft.sounds.SoundEvents.ENDERMAN_AMBIENT, 0.5F + rnd.nextFloat() * 0.3F, 0.6F);
        px += (Math.max(6, Math.min(W - 6, mx)) - px) * 0.35;
        py += (Math.max(6, Math.min(H - 6, my)) - py) * 0.35;
        double chance = Math.min(0.30, 0.07 + t * 0.00004);
        if (rnd.nextDouble() < chance) {
            int size = 4 + rnd.nextInt(5);
            parts.add(new double[]{rnd.nextInt(W - size), -size, 0.9 + rnd.nextDouble() * 1.3 + Math.min(1.6, t / 2400.0), size});
        }
        for (int i = parts.size() - 1; i >= 0; i--) {
            double[] p = parts.get(i);
            p[1] += p[2];
            if (Math.abs(p[0] + p[3] / 2 - px) < (p[3] / 2 + 3.5) && Math.abs(p[1] + p[3] / 2 - py) < (p[3] / 2 + 4)) {
                over = true; beep(); growl(G_SCREAM);
            }
            if (p[1] > H) parts.remove(i);
        }
        score = t / 30;
    }

    @Override
    public void render(GuiGraphics g) {
        // the End: deep gradient, a faint nebula and stars that twinkle and drift
        g.fillGradient(0, 0, W, H, 0xFF2E1458, 0xFF08030F);
        Gfx.glow(g, 50, 30, 46, 0xFF8A3CFF, 60);
        Gfx.glow(g, 180, 95, 52, 0xFFE45CFF, 45);
        for (int i = 0; i < stars.length; i++) {
            int[] s = stars[i];
            int sy = (s[1] + t / (3 + s[2] * 2)) % H;
            if (s[2] == 0 && (t / 20 + i) % 4 == 0) Gfx.sparkle(g, s[0], sy, 2, t + i * 13, 0xFFF0DAFF);
            else rect(g, s[0], sy, 1 + (s[2] == 0 ? 1 : 0), 1, s[2] == 2 ? 0x55E8C8FF : 0x99E8C8FF);
        }
        // floor mist
        g.fillGradient(0, H - 16, W, H, 0x00B060FF, 0x55B060FF);
        // falling ender crystals: glow, long soft trail, bright core
        for (double[] p : parts) {
            int x = (int) p[0], y = (int) p[1], s = (int) p[3];
            int cx = x + s / 2, cy = y + s / 2;
            g.fillGradient(x + 1, y - 10, x + s - 1, y, 0x00C26BFF, 0x66C26BFF);
            Gfx.disc(g, cx, cy, s / 2 + 4, 0x22C26BFF);
            Gfx.disc(g, cx, cy, s / 2 + 2, 0x33C26BFF);
            Gfx.rrect(g, x, y, s, s, 1, 0xFFB052F0);
            rect(g, x + 1, y + 1, s - 2, s - 2, 0xFFE8B8FF);
            rect(g, x + 1, y + 1, Math.max(1, s / 2 - 1), 1, 0xFFFFFFFF);
            rect(g, x + s - 2, y + 2, 1, s - 3, 0x44B052F0);
        }
        // the little enderman: tall dark body, long limbs, glowing eyes and ender sparkles
        int x = (int) px, y = (int) py;
        Gfx.glow(g, x, y, 14, 0xFFE45CFF, 55);
        for (int i = 0; i < 5; i++) {
            double a = t * 0.07 + i * 1.26;
            int ex = x + (int) Math.round(Math.cos(a) * (8 + i % 2 * 2)), ey = y + (int) Math.round(Math.sin(a * 1.3) * 9);
            rect(g, ex, ey, 1, 1, i % 2 == 0 ? 0xFFE45CFF : 0xFFB052F0);
        }
        rect(g, x - 7, y - 3, 2, 9, 0xFF1D1428); rect(g, x + 5, y - 3, 2, 9, 0xFF1D1428);        // arms
        Gfx.rrect(g, x - 5, y - 6, 10, 12, 2, 0xFF0E0A16);
        Gfx.rrect(g, x - 4, y - 5, 8, 10, 2, 0xFF1D1428);
        rect(g, x - 4, y - 5, 8, 1, 0xFF4B2F7A);
        rect(g, x - 4, y - 2, 3, 2, 0xFFFFFFFF); rect(g, x + 1, y - 2, 3, 2, 0xFFFFFFFF);
        rect(g, x - 3, y - 2, 2, 2, 0xFFE45CFF); rect(g, x + 1, y - 2, 2, 2, 0xFFE45CFF);
        rect(g, x - 2, y + 2, 4, 1, 0xFF4B2F7A);
        rect(g, x - 3, y + 6, 2, 3, 0xFF1D1428); rect(g, x + 1, y + 6, 2, 3, 0xFF1D1428);      // legs
        Gfx.vignette(g, W, H, 80);
    }

    @Override
    public String hintKey() { return "cutemod.hint.dodge"; }
}
