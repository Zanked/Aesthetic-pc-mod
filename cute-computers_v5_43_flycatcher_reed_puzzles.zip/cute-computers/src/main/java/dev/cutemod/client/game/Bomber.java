package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import dev.cutemod.client.os.CuteFont;
import dev.cutemod.data.BomberSim;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Bombers: a Bomberman-like game for up to four players. A round is played against 1-3 computer players, or online in a room where
 * people and computer players mix (the rules and the computer players are in {@link BomberSim}; the server is
 * {@link dev.cutemod.net.BomberServer}). Walk with the arrows or WASD, drop a bomb with Space (or a click).
 * Every player is a little animal: a cat, a panda, a fox and a penguin, in the four corners.
 */
public class Bomber extends MiniGame {
    private static final int MENU = 0, ROOMS = 1, ROOM = 2, PLAY = 3;
    private static final int CP = 11, BX = 27, BY = 17;                  // a cell is 11 px wide; the board starts at (27, 17)
    private static final int COLS = BomberSim.COLS, ROWS = BomberSim.ROWS, N = BomberSim.N, CELL = BomberSim.CELL;
    private static final int[] MAIN = {0xFFF59BC1, 0xFFFFFFFF, 0xFFF5A04A, 0xFF6C9BF2};
    private static final int[] RIM = {0xFFFF6FA3, 0xFFB8B8D0, 0xFFE07B1F, 0xFF3F6FD6};
    private static final int INK = 0xFF2B2233;
    private static final int[] TEAM = {0xFFFF5C6C, 0xFF4C9BFF};          // the two teams of the team mode

    private int screen = MENU;
    private boolean online;
    private BomberSim sim = new BomberSim();
    private int bots = 3, skill = 1, mapSel = 0, modeSel = 0;
    private int anim, acc, overWait, noticeT, suddenT, prefDir = -1, sentDir = -2, sendT;
    private String noticeKey = "";
    private boolean bombPress, wasSudden, havePrev;
    private final boolean[] heldNow = new boolean[4], heldBefore = new boolean[4], havePos = new boolean[4];
    private int seenState;
    private final float[] rx = new float[4], ry = new float[4];
    private final byte[] pTile = new byte[N], pItem = new byte[N];
    private final boolean[] pFlame = new boolean[N], pAlive = new boolean[4];
    private final Set<Integer> pBombs = new HashSet<>();


    /** The look of one map: the background, the floor, the frame, the pillars and the crates. */
    private record Theme(int bg1, int bg2, int f1, int f2, int speck, int frameO, int frameI,
                         int pA, int pB, int pC, int cA, int cB, int cC, int pStyle, int cStyle,
                         int hz1, int hz2, int hz3, int hStyle) {}

    private static final Theme[] THEMES = {
            // 0 garden: mint lawn, lavender blocks, pink gifts
            new Theme(0xFF5A3F86, 0xFF2B1F4A, 0xFFC9EBD9, 0xFFBBE3CE, 0xFFFFF2A8, 0xFF8A72C8, 0xFFB9A4E8,
                    0xFFA48BE0, 0xFFC4B2F2, 0xFFFFE27A, 0xFFFFB3CB, 0xFFFFF2A8, 0xFFFFD34D, 0, 0, 0, 0, 0, 0),
            // 1 meadow: sunny grass, mushrooms, hay bales
            new Theme(0xFF3F7A55, 0xFF1F3F30, 0xFFDDF0AE, 0xFFD0E89E, 0xFFFFFFFF, 0xFF5E9E5C, 0xFFA6D58C,
                    0xFFE0584F, 0xFFFFF1D6, 0xFFFFFFFF, 0xFFF2D06B, 0xFFC99A2E, 0xFFFFE9A0, 1, 1, 0, 0, 0, 0),
            // 2 maze: a candy shop
            new Theme(0xFF8A4A8A, 0xFF4A2A5A, 0xFFFFF0E0, 0xFFFFE2EC, 0xFFFF9AB8, 0xFFE98FB5, 0xFFFFC2D6,
                    0xFFFFFFFF, 0xFFFF5C8A, 0xFFFFD1E3, 0xFFB5F0D5, 0xFFFF8FB8, 0xFFFFFFFF, 2, 0, 0, 0, 0, 0),
            // 3 rooms: snow, blue ice crystals and red presents
            new Theme(0xFF2F4F7F, 0xFF172A4A, 0xFFE9F4FF, 0xFFDCEBF9, 0xFFFFFFFF, 0xFF8FB8E8, 0xFFC8E0FF,
                    0xFF4F86C8, 0xFF9CCBF5, 0xFFFFFFFF, 0xFFEF6F6F, 0xFFFFFFFF, 0xFFFFD34D, 3, 0, 0, 0, 0, 0),
            // 4 crates: a sandy warehouse
            new Theme(0xFF7A5A3A, 0xFF3A2A1A, 0xFFF6E3B4, 0xFFEED7A0, 0xFFC9A66B, 0xFFA77A4A, 0xFFD9B27A,
                    0xFF8A5A3A, 0xFFB07A4A, 0xFFE8C890, 0xFFD39A55, 0xFF9A6630, 0xFFFFE0A0, 0, 3, 0, 0, 0, 0),
            // 5 arena: a night sky and gold gifts
            new Theme(0xFF1A1440, 0xFF0A0820, 0xFF3A4A8A, 0xFF34427F, 0xFFBFD0FF, 0xFF5A4FB0, 0xFF8A7CE0,
                    0xFF6A5AD0, 0xFF8F80F0, 0xFFFFE27A, 0xFFFFD04D, 0xFFFFF4B8, 0xFFFF8FB8, 0, 0, 0, 0, 0, 0),
            // 6 lava: black rock, glowing lava lakes (nobody can walk in, flames cross them)
            new Theme(0xFF3A1410, 0xFF14080A, 0xFF5A4651, 0xFF524049, 0xFFFF9A4A, 0xFF8A3A2A, 0xFFD9603A,
                    0xFF2B2530, 0xFF4A4050, 0xFFFF8A3D, 0xFFB5542E, 0xFF7A2E16, 0xFFFFB84A, 0, 3, 0xFFE8431A, 0xFFFFC93B, 0xFFFFF4B8, 0),
            // 7 toxic: a lab with barrels and green slime (you can walk in it, slowly)
            new Theme(0xFF1F3A1A, 0xFF0A1A0C, 0xFFCFE4C8, 0xFFC2DAB9, 0xFFA7E06A, 0xFF4E9A3A, 0xFF8ED45F,
                    0xFFE8C93A, 0xFF2B2B2B, 0xFF7BDC4F, 0xFF9AA8A0, 0xFF5F6E66, 0xFFE8E8E8, 4, 3, 0xFF6FD43A, 0xFF9BEF5E, 0xFFE4FFB0, 2),
            // 8 reef: sand, corals and treasure chests
            new Theme(0xFF0F4A7A, 0xFF082A4A, 0xFFF2E6C0, 0xFFEADBAE, 0xFFFFFFFF, 0xFF3A9ACF, 0xFF8FD6F5,
                    0xFFFF7A59, 0xFFFFC2A3, 0xFFFFE27A, 0xFF9A5A2E, 0xFFFFD34D, 0xFF5A3A1A, 5, 4, 0, 0, 0, 0),
            // 9 sakura: a temple garden with stone lanterns and a pond in the middle
            new Theme(0xFF6A3A5A, 0xFF2A1A3A, 0xFFFBEDEE, 0xFFF6E0E6, 0xFFFFA5C0, 0xFFD9648C, 0xFFFFB3CB,
                    0xFF8A8A9A, 0xFFFFE9A0, 0xFFE0E0E8, 0xFFD9455A, 0xFF9A2A3A, 0xFFFFD34D, 6, 3, 0xFF5CB8F0, 0xFFA8DCFF, 0xFFFFFFFF, 1),
    };

    private int themeIdx() {
        int m;
        if (screen == PLAY) m = v().map;
        else if (screen == ROOM) m = BomberNet.map;
        else if (screen == MENU) m = mapSel;
        else m = 0;
        return m >= 0 && m < THEMES.length ? m : 0;
    }

    private Theme th() { return THEMES[themeIdx()]; }

    private static String mapName(int m) { return m("cutemod.bomber.map." + m); }

    private static final class Pt {
        float x, y, vx, vy;
        int life, max, col, kind;
    }

    private final List<Pt> pts = new ArrayList<>();

    private static String m(String key) { return Component.translatable(key).getString(); }

    private static String tr(String key, Object... a) { return Component.translatable(key, a).getString(); }

    private BomberSim v() { return online ? BomberNet.view : sim; }

    private int me() { return online ? (BomberNet.stateSlot >= 0 ? BomberNet.stateSlot : BomberNet.mySlot) : 0; }

    // ---------------------------------------------------------------- flow
    @Override
    public void reset() {
        score = 0; over = false; overWait = 0; noticeT = 0; bombPress = false; havePrev = false;
        pts.clear();
        screen = MENU;
        online = false;
        BomberNet.request();                                     // maybe we are still in a room: tick() brings us back to it
    }

    @Override
    public void close() {
        if (BomberNet.inRoom) BomberNet.leave();
    }

    @Override
    public String hintKey() { return "cutemod.hint.bomber"; }

    @Override
    public Component status() {
        if (screen != PLAY) return Component.translatable("cutemod.ui.score", score);
        BomberSim s = v();
        if (s.mode == BomberSim.MODE_DM) {
            int left = Math.max(0, (BomberSim.DM_TIME - s.play) / BomberSim.TPS);
            return Component.translatable("cutemod.bomber.status_dm", left / 60 + ":" + (left % 60 < 10 ? "0" : "") + left % 60, s.pl[me()].kills);
        }
        int alive = 0, all = 0;
        for (BomberSim.Player p : s.pl) { if (p.active) all++; if (p.alive) alive++; }
        return Component.translatable("cutemod.bomber.status", alive, all, s.scoreOf(me()));
    }

    @Override
    public boolean isWin() { return v().isWinner(me()); }

    @Override
    public Component endTitle() {
        BomberSim s = v();
        if (s.isWinner(me())) return Component.translatable("cutemod.bomber.win");
        if (s.winner == BomberSim.DRAW) return Component.translatable("cutemod.bomber.draw");
        if (s.winner >= 0) return Component.translatable("cutemod.bomber.lose_to", nameOf(s.winner));
        return Component.translatable("cutemod.bomber.lose");
    }

    private void startSolo() {
        sim = new BomberSim();
        sim.setup(0, false, skill);
        int[] order = {3, 1, 2};
        int nb = modeSel == BomberSim.MODE_TEAMS ? 3 : bots;                  // teams: you and a computer ally against two
        for (int i = 0; i < nb; i++) sim.setup(order[i], true, skill);
        sim.setMap(mapSel);
        sim.setMode(modeSel);
        sim.start();
        online = false;
        beginRound();
    }

    private void startOnline() {
        online = true;
        beginRound();
        seenState = BomberNet.stateVersion - 1;
    }

    private void beginRound() {
        screen = PLAY;
        score = 0; over = false; overWait = 0; acc = 0;
        havePrev = false; wasSudden = false; suddenT = 0;
        prefDir = -1; sentDir = -2; sendT = 0; bombPress = false;
        pts.clear();
        java.util.Arrays.fill(havePos, false);
    }

    @Override
    public void tick() {
        anim++;
        if (noticeT > 0) noticeT--;
        netTick();
        if (screen == PLAY) playTick();
        stepParticles();
    }

    private void netTick() {
        int n = BomberNet.takeNotice();
        if (n != 0) { noticeKey = "cutemod.bomber.notice." + n; noticeT = 220; }
        if ((screen == ROOMS || screen == ROOM) && anim % 100 == 0) BomberNet.request();
        if ((screen == MENU || screen == ROOMS) && BomberNet.inRoom && !BomberNet.inGame) { screen = ROOM; online = true; }
        if (screen == ROOM && !BomberNet.inRoom) screen = ROOMS;
        if (screen == ROOM && BomberNet.inGame && BomberNet.stateVersion != seenState && BomberNet.view.state != BomberSim.ST_OVER) startOnline();
        if (screen == PLAY && online && !BomberNet.inRoom) { screen = ROOMS; online = false; }
    }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    /** The direction the player holds: the newest key wins. 0 down, 1 left, 2 right, 3 up, -1 none. */
    private int readDir() {
        heldNow[0] = down(83) || down(KEY_DOWN);
        heldNow[1] = down(65) || down(KEY_LEFT);
        heldNow[2] = down(68) || down(KEY_RIGHT);
        heldNow[3] = down(87) || down(KEY_UP);
        for (int i = 0; i < 4; i++) if (heldNow[i] && !heldBefore[i]) prefDir = i;
        System.arraycopy(heldNow, 0, heldBefore, 0, 4);
        if (prefDir >= 0 && heldNow[prefDir]) return prefDir;
        prefDir = -1;
        for (int i = 0; i < 4; i++) if (heldNow[i]) return i;
        return -1;
    }

    private void playTick() {
        BomberSim s = v();
        int dir = readDir();
        if (online) {
            if (BomberNet.stateVersion != seenState) { seenState = BomberNet.stateVersion; onSnapshot(s); }
            if (dir != sentDir || bombPress || ++sendT >= 30) {
                BomberNet.input(dir, bombPress);
                sentDir = dir; bombPress = false; sendT = 0;
            }
        } else if (++acc >= 3) {
            acc = 0;
            sim.input(0, dir, bombPress);
            bombPress = false;
            sim.tick();
            onSnapshot(s);
        }
        for (int i = 0; i < 4; i++) {
            BomberSim.Player p = s.pl[i];
            if (!havePos[i] || Math.abs(p.x - rx[i]) > 2 * CELL || Math.abs(p.y - ry[i]) > 2 * CELL) { rx[i] = p.x; ry[i] = p.y; havePos[i] = true; }
            else { rx[i] += (p.x - rx[i]) * 0.4F; ry[i] += (p.y - ry[i]) * 0.4F; }
        }
        if (s.sudden && !wasSudden) { wasSudden = true; suddenT = 140; pling(0.6F); }
        if (suddenT > 0) suddenT--;
        if (s.state == BomberSim.ST_OVER && ++overWait >= 36 && !over) {
            over = true;
            score = s.scoreOf(me());
        }
    }

    // ---------------------------------------------------------------- what happened between two pictures: sounds and sparks
    private void onSnapshot(BomberSim s) {
        int me = me();
        if (havePrev) {
            BomberSim.Player mp = s.pl[me];
            int newFlames = 0, nearest = 99, mine = mp.cy() * COLS + mp.cx();
            for (int i = 0; i < N; i++) {
                boolean fl = s.flame[i] > 0;
                if (fl && !pFlame[i]) {
                    newFlames++;
                    burst(i, 0);
                    nearest = Math.min(nearest, Math.abs(i % COLS - mp.cx()) + Math.abs(i / COLS - mp.cy()));
                }
                if (pTile[i] == BomberSim.CRATE && s.tile[i] == BomberSim.FLOOR) burst(i, 1);
                if (pTile[i] != BomberSim.WALL && s.tile[i] == BomberSim.WALL) burst(i, 3);
                if (pItem[i] != 0 && s.item[i] == 0 && !fl) {
                    burst(i, 2);
                    if (i == mine) pling(1.7F);
                }
            }
            if (newFlames > 0) sound(SoundEvents.GENERIC_EXPLODE, 1.25F, Math.max(0.10F, 0.4F - nearest * 0.025F));
            for (BomberSim.Bomb b : s.bombs)
                if (!pBombs.contains(b.cy * COLS + b.cx)) sound(SoundEvents.STONE_BUTTON_CLICK_ON, b.owner == me ? 0.8F : 0.6F, b.owner == me ? 0.5F : 0.25F);
            for (int i = 0; i < 4; i++) {
                if (!pAlive[i] && s.pl[i].alive && s.mode == BomberSim.MODE_DM) {
                    burst((s.pl[i].idx < 2 ? 0 : ROWS - 1) * COLS + ((s.pl[i].idx & 1) == 0 ? 0 : COLS - 1), 2);
                    if (i == me) pling(1.4F);
                }
                if (pAlive[i] && !s.pl[i].alive) {
                    burst((s.pl[i].cy()) * COLS + s.pl[i].cx(), 4);
                    ghost(s.pl[i]);
                    if (i == me) sound(SoundEvents.PLAYER_HURT, 1.2F, 0.6F); else pling(0.6F);
                }
            }
        }
        System.arraycopy(s.tile, 0, pTile, 0, N);
        System.arraycopy(s.item, 0, pItem, 0, N);
        pBombs.clear();
        for (BomberSim.Bomb b : s.bombs) pBombs.add(b.cy * COLS + b.cx);
        for (int i = 0; i < N; i++) pFlame[i] = s.flame[i] > 0;
        for (int i = 0; i < 4; i++) pAlive[i] = s.pl[i].alive;
        havePrev = true;
    }

    private void burst(int cell, int kind) {
        float cx = BX + (cell % COLS) * CP + CP / 2F, cy = BY + (cell / COLS) * CP + CP / 2F;
        int n = switch (kind) { case 0 -> 4; case 1 -> 7; case 2 -> 6; case 3 -> 3; default -> 9; };
        int[] pink = {0xFFFF8FB8, 0xFFFFD1E3, 0xFFFFF2A8, 0xFFFFFFFF};
        for (int i = 0; i < n && pts.size() < 220; i++) {
            Pt p = new Pt();
            p.x = cx + (rnd.nextFloat() - 0.5F) * 6; p.y = cy + (rnd.nextFloat() - 0.5F) * 6;
            double a = rnd.nextFloat() * Math.PI * 2;
            float sp = 0.3F + rnd.nextFloat() * (kind == 4 ? 1.2F : 0.9F);
            p.vx = (float) Math.cos(a) * sp; p.vy = (float) Math.sin(a) * sp - (kind == 1 ? 0.5F : 0);
            p.max = p.life = 18 + rnd.nextInt(16);
            p.kind = kind;
            p.col = switch (kind) {
                case 0 -> rnd.nextBoolean() ? 0xFFFFC93B : 0xFFFF7A3D;
                case 1 -> pink[rnd.nextInt(4)];
                case 2 -> 0xFFFFF27A;
                case 3 -> 0xFFB9A4E8;
                default -> rnd.nextBoolean() ? 0xFFFFFFFF : 0xFFFFE27A;
            };
            pts.add(p);
        }
    }

    private void ghost(BomberSim.Player pl) {
        Pt p = new Pt();
        p.x = BX + pl.x * CP / (float) CELL + CP / 2F; p.y = BY + pl.y * CP / (float) CELL + CP / 2F;
        p.vx = 0; p.vy = -0.35F;
        p.max = p.life = 56;
        p.kind = 5;
        p.col = MAIN[pl.idx];
        pts.add(p);
    }

    private void stepParticles() {
        for (int i = pts.size() - 1; i >= 0; i--) {
            Pt p = pts.get(i);
            p.x += p.vx; p.y += p.vy;
            if (p.kind == 1 || p.kind == 2) p.vy += 0.05F;
            p.vx *= 0.97F;
            if (--p.life <= 0) pts.remove(i);
        }
    }

    // ---------------------------------------------------------------- input
    @Override
    public boolean key(int keyCode) {
        if (screen == PLAY) {
            if (keyCode == KEY_SPACE || keyCode == 69 || keyCode == 88) { bombPress = true; return true; }
            return keyCode == KEY_UP || keyCode == KEY_DOWN || keyCode == KEY_LEFT || keyCode == KEY_RIGHT
                    || keyCode == 87 || keyCode == 65 || keyCode == 83 || keyCode == 68;
        }
        if (screen == MENU && (keyCode == KEY_SPACE || keyCode == 257)) { startSolo(); pling(1.0F); return true; }
        return false;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (screen == PLAY) { bombPress = true; return true; }
        if (screen == MENU) return menuClick(x, y);
        if (screen == ROOMS) return roomsClick(x, y);
        if (screen == ROOM) return roomClick(x, y);
        return false;
    }

    private boolean menuClick(int x, int y) {
        if (in(x, y, 24, 43, 172, 14)) { startSolo(); pling(1.0F); return true; }
        if (in(x, y, 24, 59, 172, 14)) { screen = ROOMS; BomberNet.request(); pling(1.0F); return true; }
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 112 + i * 28, 76, 24, 12)) { bots = i + 1; beep(); return true; }
            if (in(x, y, 70 + i * 46, 89, 44, 12)) { skill = i; beep(); return true; }
        }
        int mp = pickClick(x, y, 102, mapSel, BomberSim.MAPS + 1);        // the maps and "random"
        if (mp >= 0) { mapSel = mp; beep(); return true; }
        int md = pickClick(x, y, 115, modeSel, BomberSim.MODES);
        if (md >= 0) { modeSel = md; beep(); return true; }
        return false;
    }

    /** A picker (two arrows and the name between them) at height ry: the new value out of n, or -1 if it was not hit. */
    private static int pickClick(int x, int y, int ry, int cur, int n) {
        if (in(x, y, 70, ry, 14, 12)) return (cur + n - 1) % n;
        if (in(x, y, 86, ry, 88, 12) || in(x, y, 176, ry, 14, 12)) return (cur + 1) % n;
        return -1;
    }

    private void picker(GuiGraphics g, int ry, String label, String name, boolean enabled) {
        stext(g, label, 14, ry + 2, 0.85F, 0xFFE8E0FF);
        chip(g, 70, ry, 14, 12, "<", false, enabled);
        chip(g, 86, ry, 88, 12, name, true, enabled);
        chip(g, 176, ry, 14, 12, ">", false, enabled);
    }

    private static String modeName(int m) { return m("cutemod.bomber.mode." + m); }

    private boolean roomsClick(int x, int y) {
        if (in(x, y, 4, 4, 30, 12)) { screen = MENU; pling(0.8F); return true; }
        if (in(x, y, 140, 3, 76, 14)) { BomberNet.create(); pling(1.2F); return true; }
        int rows = Math.min(BomberNet.hosts.size(), 5);
        for (int i = 0; i < rows; i++) {
            if (in(x, y, 8, 24 + i * 20, 204, 18)) { BomberNet.join(BomberNet.hosts.get(i)); pling(1.2F); return true; }
        }
        return false;
    }

    private boolean roomClick(int x, int y) {
        if (in(x, y, 4, 4, 38, 12)) { BomberNet.leave(); screen = ROOMS; pling(0.8F); return true; }
        if (!BomberNet.youHost) return false;
        for (int i = 1; i < 4; i++) {
            if (in(x, y, 8 + i * 53, 20, 49, 46)) { BomberNet.slot(i); beep(); return true; }
        }
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 70 + i * 46, 69, 44, 12)) { BomberNet.setLevel(i); beep(); return true; }
        }
        int mp = pickClick(x, y, 82, BomberNet.map, BomberSim.MAPS + 1);
        if (mp >= 0) { BomberNet.setMap(mp); beep(); return true; }
        int md = pickClick(x, y, 95, BomberNet.mode, BomberSim.MODES);
        if (md >= 0) { BomberNet.setMode(md); beep(); return true; }
        if (in(x, y, 40, 109, 140, 14)) { BomberNet.start(); pling(1.4F); return true; }
        return false;
    }

    // ---------------------------------------------------------------- drawing
    private String nameOf(int slot) {
        if (online) {
            int t = BomberNet.slotType[slot];
            String n = BomberNet.slotName[slot];
            if (t == 3 && !n.isEmpty()) return n;
        } else if (slot == 0) return m("cutemod.bomber.you");
        return m("cutemod.bomber.animal." + slot);
    }

    private static void stext(GuiGraphics g, String s, int x, int y, float k, int argb) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(k, k, 1F);
        CuteFont.draw(g, font(), s, 0, 0, argb, false);
        g.pose().popPose();
    }

    /** Centred text; a line that would not fit in the window is made smaller. */
    private static void sctext(GuiGraphics g, String s, int cx, int y, float k, int argb) {
        int w = Math.round(tw(s) * k);
        if (w > W - 8) k = k * (W - 8) / w;
        stext(g, s, cx - Math.round(tw(s) * k / 2F), y, k, argb);
    }

    private void bg(GuiGraphics g) {
        Theme t = th();
        g.fillGradient(0, 0, W, H, t.bg1(), t.bg2());
        for (int i = 0; i < 14; i++) {
            int sx = (int) (Gfx.hash(i, 1) * W), sy = (int) (Gfx.hash(i, 2) * H);
            Gfx.sparkle(g, sx, sy, 2, anim + i * 17, 0xFFFFE9A8);
        }
        Gfx.vignette(g, W, H, 90);
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String label, int face) {
        boolean hover = in(mx, my, x, y, w, h);
        Gfx.bubble(g, x, y, w, h, 3, hover ? Gfx.lighter(face, 0.3F) : face);
        ctextW(g, label, x + w / 2, y + (h - 8) / 2, w - 6, 0xFF2B2140);
    }

    private void chip(GuiGraphics g, int x, int y, int w, int h, String label, boolean on, boolean enabled) {
        boolean hover = enabled && in(mx, my, x, y, w, h);
        int face = on ? 0xFFFFD866 : 0xFF6A5A92;
        Gfx.bubble(g, x, y, w, h, 3, hover ? Gfx.lighter(face, 0.25F) : face);
        ctextW(g, label, x + w / 2, y + (h - 8) / 2, w - 4, on ? 0xFF3A2A10 : 0xFFE8E0FF);
    }

    @Override
    public void render(GuiGraphics g) {
        bg(g);
        switch (screen) {
            case MENU -> renderMenu(g);
            case ROOMS -> renderRooms(g);
            case ROOM -> renderRoom(g);
            default -> renderPlay(g);
        }
        if (noticeT > 0) {
            int w = 170, x = (W - w) / 2, y = H - 18;
            Gfx.bubble(g, x, y, w, 14, 4, 0xFFFFE9A8);
            ctextW(g, m(noticeKey), W / 2, y + 3, w - 8, 0xFF3A2A10);
        }
    }

    private void renderMenu(GuiGraphics g) {
        sctext(g, m("cutemod.bomber.title"), W / 2 + 1, 4, 2F, 0xFF1B1030);
        sctext(g, m("cutemod.bomber.title"), W / 2, 3, 2F, 0xFFFFE27A);
        for (int i = 0; i < 4; i++) {
            int x = 34 + i * 40;
            animal(g, i, x, 19 + (anim / 14 + i) % 2, i == 0 ? 0 : i == 1 ? 2 : i == 2 ? 1 : 0, 0, 2F);
            bomb(g, x + 28, 32, 4, 50 + i * 7);
        }
        button(g, 24, 43, 172, 14, m("cutemod.bomber.vs_ai"), 0xFFF9C6DB);
        button(g, 24, 59, 172, 14, m("cutemod.bomber.online"), 0xFFB8E8FF);
        boolean teams = modeSel == BomberSim.MODE_TEAMS;                    // the team mode always has three computer players
        stext(g, m("cutemod.bomber.rivals"), 14, 78, 0.85F, 0xFFE8E0FF);
        for (int i = 0; i < 3; i++) chip(g, 112 + i * 28, 76, 24, 12, Integer.toString(i + 1), (teams ? 3 : bots) == i + 1, !teams);
        stext(g, m("cutemod.bomber.skill"), 14, 91, 0.85F, 0xFFE8E0FF);
        for (int i = 0; i < 3; i++) chip(g, 70 + i * 46, 89, 44, 12, m("cutemod.bomber.skill." + i), skill == i, true);
        picker(g, 102, m("cutemod.bomber.map"), mapName(mapSel), true);
        picker(g, 115, m("cutemod.bomber.mode"), modeName(modeSel), true);
        sctext(g, m("cutemod.bomber.mode.desc." + modeSel), W / 2, 130, 0.7F, 0xFFC9BEE8);
    }

    private void renderRooms(GuiGraphics g) {
        button(g, 4, 4, 30, 12, "<", 0xFFE8E0FF);
        sctext(g, m("cutemod.bomber.rooms"), 88, 6, 1F, 0xFFFFE27A);
        button(g, 140, 3, 76, 14, m("cutemod.bomber.create"), 0xFFF9C6DB);
        int rows = Math.min(BomberNet.hosts.size(), 5);
        if (rows == 0) {
            ctextW(g, m("cutemod.bomber.rooms.none"), W / 2, 62, W - 24, 0xFFC9BEE8);
            return;
        }
        for (int i = 0; i < rows; i++) {
            int y = 24 + i * 20;
            boolean hover = in(mx, my, 8, y, 204, 18);
            Gfx.bubble(g, 8, y, 204, 18, 4, hover ? 0xFF7B68AE : 0xFF5E4C8C);
            animal(g, i % 4, 12, y + 3, 0, 0, 1F);
            text(g, clip(BomberNet.hosts.get(i), 90), 28, y + 5, 0xFFFFFFFF);
            String free = tr("cutemod.bomber.free", BomberNet.open.get(i));
            stext(g, free, 150 - Math.round(tw(free) * 0.8F), y + 6, 0.8F, 0xFFD6CBF2);
            Gfx.bubble(g, 156, y + 3, 50, 12, 3, 0xFFFFD866);
            ctextW(g, m("cutemod.bomber.join"), 181, y + 5, 44, 0xFF3A2A10);
        }
    }

    private void renderRoom(GuiGraphics g) {
        button(g, 4, 4, 38, 12, m("cutemod.bomber.leave"), 0xFFE8E0FF);
        String host = BomberNet.slotName[0].isEmpty() ? "" : BomberNet.slotName[0];
        sctext(g, tr("cutemod.bomber.room", host), 130, 6, 0.95F, 0xFFFFE27A);
        for (int i = 0; i < 4; i++) {
            int x = 8 + i * 53, y = 20, t = BomberNet.slotType[i];
            boolean click = BomberNet.youHost && i > 0;
            boolean hover = click && in(mx, my, x, y, 49, 46);
            Gfx.bubble(g, x, y, 49, 46, 4, hover ? 0xFF7B68AE : 0xFF5E4C8C);
            boolean teamMode = BomberNet.mode == BomberSim.MODE_TEAMS;
            g.fill(x + 3, y + 3, x + 46, y + 5, teamMode ? TEAM[i == 0 || i == 3 ? 0 : 1] : MAIN[i]);
            if (t == 1 || t == 2 || t == 3) {
                animal(g, i, x + 13, y + 8 + (anim / 16 + i) % 2, 0, 0, 2F);
                if (t == 1) g.fill(x + 6, y + 6, x + 43, y + 32, hover ? 0x907B68AE : 0x905E4C8C);        // an open place: a bot that a player can replace
            } else {
                Gfx.disc(g, x + 24, y + 20, 8, 0x30FFFFFF);
                ctextW(g, "-", x + 24, y + 16, 20, 0xFFC9BEE8);
            }
            String label = t == 3 ? BomberNet.slotName[i] : m("cutemod.bomber.slot." + t);
            ctextW(g, label, x + 24, y + 34, 45, t == 3 ? 0xFFFFFFFF : 0xFFD6CBF2);
            if (i == 0) stext(g, "*", x + 41, y + 7, 1F, 0xFFFFE27A);
        }
        if (BomberNet.youHost) {
            stext(g, m("cutemod.bomber.skill"), 14, 71, 0.85F, 0xFFE8E0FF);
            for (int i = 0; i < 3; i++) chip(g, 70 + i * 46, 69, 44, 12, m("cutemod.bomber.skill." + i), BomberNet.level == i, true);
            picker(g, 82, m("cutemod.bomber.map"), mapName(BomberNet.map), true);
            picker(g, 95, m("cutemod.bomber.mode"), modeName(BomberNet.mode), true);
            button(g, 40, 109, 140, 14, m("cutemod.bomber.start"), 0xFFB5F0C0);
            sctext(g, m("cutemod.bomber.mode.desc." + BomberNet.mode), W / 2, 126, 0.7F, 0xFFC9BEE8);
            sctext(g, m("cutemod.bomber.slot_hint"), W / 2, 133, 0.65F, 0xFFA99CCB);
        } else {
            sctext(g, m("cutemod.bomber.wait"), W / 2, 72, 1F, 0xFFC9BEE8);
            sctext(g, tr("cutemod.bomber.skill_is", m("cutemod.bomber.skill." + BomberNet.level)), W / 2, 85, 0.85F, 0xFFC9BEE8);
            sctext(g, tr("cutemod.bomber.map_is", mapName(BomberNet.map)), W / 2, 96, 0.85F, 0xFFC9BEE8);
            sctext(g, tr("cutemod.bomber.mode_is", modeName(BomberNet.mode)), W / 2, 107, 0.85F, 0xFFC9BEE8);
            sctext(g, m("cutemod.bomber.mode.desc." + BomberNet.mode), W / 2, 124, 0.7F, 0xFFC9BEE8);
        }
    }

    // ---------------------------------------------------------------- the round
    private void renderPlay(GuiGraphics g) {
        BomberSim s = v();
        int me = me();
        Theme t = th();
        // the board frame
        Gfx.shadow(g, BX - 3, BY - 3, COLS * CP + 6, ROWS * CP + 6, 4);
        Gfx.rrect(g, BX - 3, BY - 3, COLS * CP + 6, ROWS * CP + 6, 4, t.frameO());
        Gfx.rrect(g, BX - 2, BY - 2, COLS * CP + 4, ROWS * CP + 4, 3, t.frameI());
        // the floor: a soft mint checkerboard with a few flowers
        for (int y = 0; y < ROWS; y++) {
            for (int x = 0; x < COLS; x++) {
                int px = BX + x * CP, py = BY + y * CP;
                g.fill(px, py, px + CP, py + CP, ((x + y) & 1) == 0 ? t.f1() : t.f2());
                float h = Gfx.hash(y * COLS + x, 7);
                if (h > 0.86F) g.fill(px + 2 + (int) (h * 40) % 6, py + 3 + (int) (h * 90) % 5, px + 3 + (int) (h * 40) % 6, py + 4 + (int) (h * 90) % 5, t.speck());
                else if (h < 0.08F) g.fill(px + 3, py + 6, px + 4, py + 7, Gfx.darker(t.f1(), 0.07F));
                byte tk = s.tile[y * COLS + x];
                if (tk == BomberSim.LAVA || tk == BomberSim.SLIME) hazard(g, t, tk, px, py, x * 3 + y);
            }
        }
        // shadows of what stands on the floor
        for (int i = 0; i < N; i++) {
            if (s.tile[i] != BomberSim.WALL && s.tile[i] != BomberSim.CRATE) continue;
            int px = BX + (i % COLS) * CP, py = BY + (i / COLS) * CP;
            g.fill(px + 2, py + CP, px + CP + 1, py + CP + 2, 0x26000000);
        }
        // flames and bonuses lie on the floor
        for (int i = 0; i < N; i++) {
            int px = BX + (i % COLS) * CP, py = BY + (i / COLS) * CP;
            if (s.flame[i] > 0) flame(g, s, i, px, py);
            else if (s.item[i] != 0) item(g, s.item[i], px, py);
        }
        for (BomberSim.Bomb b : s.bombs) {
            if (b.owner < 0) {                                       // a bomb from the sky: a blinking warning on the cell
                int wx = BX + b.cx * CP, wy = BY + b.cy * CP;
                Gfx.outline(g, wx, wy, CP, CP, Gfx.alpha(0xFFFF4A5A, (anim / 3) % 2 == 0 ? 220 : 110));
            }
            bomb(g, BX + b.cx * CP + CP / 2, BY + b.cy * CP + CP / 2 + 1, 4, b.fuse);
        }
        // pillars and crates
        for (int i = 0; i < N; i++) {
            int px = BX + (i % COLS) * CP, py = BY + (i / COLS) * CP;
            if (s.tile[i] == BomberSim.WALL) pillar(g, t, px, py, (i % COLS) + (i / COLS) * 3);
            else if (s.tile[i] == BomberSim.CRATE) crate(g, t, px, py);
        }
        // the players, the lower ones in front
        Integer[] order = {0, 1, 2, 3};
        java.util.Arrays.sort(order, (a, b) -> Float.compare(ry[a], ry[b]));
        for (int idx : order) {
            BomberSim.Player p = s.pl[idx];
            if (!p.active || !p.alive) continue;
            if (p.invuln > 0 && (anim / 2) % 2 == 0) continue;
            float fx = BX + rx[idx] * CP / CELL, fy = BY + ry[idx] * CP / CELL;
            int px = Math.round(fx), py = Math.round(fy);
            if (p.shield > 0) {
                Gfx.disc(g, px + 5, py + 6, 7, Gfx.alpha(0xFF9AE0FF, 60 + (int) (30 * Math.sin(anim * 0.2))));
                Gfx.disc(g, px + 5, py + 6, 6, Gfx.alpha(0xFFFFFFFF, 40));
            }
            if (s.mode == BomberSim.MODE_TEAMS) Gfx.ellipse(g, px + 5, py + 10, 5, 2, Gfx.alpha(TEAM[s.teamOf(idx)], 190));   // the colour of the team
            else Gfx.ellipse(g, px + 5, py + 10, 4, 1, 0x33000000);
            animal(g, idx, px, py - 1 + (p.moving >= 0 && (anim / 4) % 2 == 0 ? -1 : 0), p.facing, p.moving >= 0 ? 1 + (anim / 4) % 2 : 0, 1F);
            if (idx == me) {                                         // a little marker over your own head
                int ay = py - 5 + (anim / 10) % 2;
                g.fill(px + 4, ay, px + 7, ay + 1, 0xFFFFE27A);
                g.fill(px + 5, ay + 1, px + 6, ay + 2, 0xFFFFE27A);
            }
        }
        // particles
        for (Pt p : pts) {
            float k = p.life / (float) p.max;
            int x = Math.round(p.x), y = Math.round(p.y);
            if (p.kind == 5) { ghostSprite(g, x, y, p.col, k); continue; }
            int col = Gfx.fade(p.col, Math.min(1F, k * 1.6F));
            if (p.kind == 2 || p.kind == 4) Gfx.star(g, x, y, k > 0.5F ? 1 : 0, col);
            else g.fill(x, y, x + (p.kind == 1 ? 2 : 1), y + 1 + (p.kind == 0 ? 0 : 1), col);
        }
        if (s.sudden) {                                              // the walls are closing in: the frame blinks red
            int a = 90 + (int) (70 * Math.sin(anim * 0.25));
            Gfx.outline(g, BX - 2, BY - 2, COLS * CP + 4, ROWS * CP + 4, Gfx.alpha(0xFFFF4A5A, a));
        }
        cards(g, s);
        // messages over the board
        if (s.state == BomberSim.ST_COUNT) {
            int n = Math.max(1, (s.countdown + 19) / 20);
            String txt = s.countdown <= 6 ? m("cutemod.bomber.go") : Integer.toString(n);
            float k = 3F + (s.countdown % 20) / 20F;
            sctext(g, txt, W / 2 + 1, H / 2 - 12 + 1, k, 0xAA1B1030);
            sctext(g, txt, W / 2, H / 2 - 12, k, 0xFFFFE27A);
        } else if (suddenT > 0 && s.state == BomberSim.ST_PLAY) {
            banner(g, m("cutemod.bomber.sudden"), 0xFFFF9AA5);
        } else if (s.state == BomberSim.ST_PLAY && !s.pl[me].alive) {
            banner(g, m("cutemod.bomber.out"), 0xFFE8E0FF);
        }
    }

    private void banner(GuiGraphics g, String text, int col) {
        int w = Math.min(W - 40, tw(text) + 14);
        int x = (W - w) / 2, y = BY + ROWS * CP - 17;
        Gfx.bubble(g, x, y, w, 12, 4, 0xDD2B1F4A);
        ctextW(g, text, W / 2, y + 2, w - 6, col);
    }

    private void cards(GuiGraphics g, BomberSim s) {
        for (int i = 0; i < 4; i++) {
            BomberSim.Player p = s.pl[i];
            int x = 1 + i * 55, y = 0, w = 53, h = 14;
            if (!p.active) {
                Gfx.rrect(g, x, y, w, h, 3, 0x30FFFFFF);
                continue;
            }
            Gfx.rrect(g, x, y, w, h, 3, p.alive ? 0xFF3A2C5E : 0xFF2A2142);
            g.fill(x + 1, y + 2, x + 3, y + h - 2, !p.alive ? 0xFF55496F : s.mode == BomberSim.MODE_TEAMS ? TEAM[s.teamOf(i)] : MAIN[i]);
            animal(g, i, x + 3, y + 2, 0, 0, 1F);
            if (!p.alive) { g.fill(x + 3, y + 1, x + 14, y + h - 1, 0x99221A38); stext(g, "x", x + 6, y + 3, 1.3F, 0xFFFF8FA8); }
            boolean badge = s.mode == BomberSim.MODE_DM || s.mode == BomberSim.MODE_TEAMS;     // how many players he put out
            String nm = clip(nameOf(i), badge ? 24 : 38);
            stext(g, nm, x + 16, y + 1, 0.72F, p.alive ? 0xFFFFFFFF : 0xFF8A80A8);
            if (badge) {
                Gfx.star(g, x + w - 13, y + 4, 1, 0xFFFFE27A);
                stext(g, Integer.toString(p.kills), x + w - 9, y + 1, 0.72F, 0xFFFFE27A);
            }
            if (p.alive) {
                int sx = x + 16, sy = y + 8;
                bomb(g, sx + 2, sy + 3, 2, 99);
                stext(g, Integer.toString(p.maxBombs), sx + 6, sy, 0.72F, 0xFFFFE9A8);
                sx += 13;
                g.fill(sx, sy + 1, sx + 3, sy + 6, 0xFFFF8A3D);
                g.fill(sx + 1, sy, sx + 2, sy + 2, 0xFFFFD84A);
                stext(g, Integer.toString(p.range), sx + 5, sy, 0.72F, 0xFFFFE9A8);
                sx += 13;
                Gfx.poly(g, new int[]{sx + 3, sx, sx + 2, sx + 1, sx + 4, sx + 2}, new int[]{sy, sy + 3, sy + 3, sy + 6, sy + 2, sy + 2}, 0xFF7FD6FF);
                stext(g, Integer.toString(p.speed + 1), sx + 5, sy, 0.72F, 0xFFFFE9A8);
                if (p.shield > 0) Gfx.outline(g, x + 2, y + 1, 12, 12, 0xFF9AE0FF);               // a shield: a light frame round the face
            }
        }
    }

    // ---------------------------------------------------------------- pieces
    private void pillar(GuiGraphics g, Theme t, int x, int y, int seed) {
        switch (t.pStyle()) {
            case 1 -> {                                                        // a mushroom
                g.fill(x + 3, y + 5, x + 8, y + CP - 1, t.pB());
                g.fill(x + 3, y + 6, x + 8, y + 7, 0x30000000);
                Gfx.rrect(g, x, y + 1, CP, 6, 3, Gfx.darker(t.pA(), 0.2F));
                Gfx.rrect(g, x, y, CP, 6, 3, t.pA());
                g.fill(x + 2, y + 1, x + 4, y + 2, 0x66FFFFFF);
                g.fill(x + 3, y + 2, x + 5, y + 4, t.pC());
                g.fill(x + 7, y + 3, x + 9, y + 5, t.pC());
            }
            case 2 -> {                                                        // a candy block with stripes
                Gfx.bubble(g, x, y, CP, CP, 3, t.pA());
                Gfx.line(g, x + 1, y + 6, x + 6, y + 1, t.pB());
                Gfx.line(g, x + 2, y + 9, x + 9, y + 2, t.pB());
                Gfx.line(g, x + 5, y + 10, x + 10, y + 5, t.pB());
                g.fill(x + 3, y + 1, x + 7, y + 2, t.pC());
            }
            case 3 -> {                                                        // an ice crystal
                Gfx.bubble(g, x, y, CP, CP, 3, t.pA());
                Gfx.poly(g, new int[]{x + 5, x + 9, x + 5, x + 1}, new int[]{y + 1, y + 5, y + 10, y + 5}, t.pB());
                g.fill(x + 4, y + 3, x + 5, y + 6, t.pC());
                g.fill(x + 5, y + 2, x + 6, y + 3, t.pC());
            }
            case 4 -> {                                                        // a toxic barrel
                Gfx.rrect(g, x + 1, y, CP - 2, CP, 3, t.pA());
                g.fill(x + 2, y + 1, x + CP - 2, y + 2, Gfx.lighter(t.pA(), 0.4F));
                g.fill(x + 1, y + 3, x + CP - 1, y + 5, t.pB());
                g.fill(x + 1, y + 7, x + CP - 1, y + 9, t.pB());
                g.fill(x + 4, y + 4, x + 7, y + 8, t.pA());
                g.fill(x + 5, y + 5, x + 6, y + 7, t.pC());
            }
            case 5 -> {                                                        // a branching coral
                int dark = Gfx.darker(t.pA(), 0.22F);
                g.fill(x + 2, y + 8, x + 9, y + CP, dark);                      // the base
                g.fill(x + 4, y, x + 7, y + 9, t.pA());                         // three branches with round tips
                g.fill(x + 1, y + 2, x + 4, y + 9, t.pA());
                g.fill(x + 7, y + 3, x + 10, y + 9, t.pA());
                g.fill(x + 5, y, x + 6, y + 1, t.pB()); g.fill(x + 2, y + 1, x + 3, y + 2, t.pB()); g.fill(x + 8, y + 2, x + 9, y + 3, t.pB());
                g.fill(x + 5, y + 3, x + 6, y + 6, t.pB()); g.fill(x + 2, y + 4, x + 3, y + 7, t.pB()); g.fill(x + 8, y + 5, x + 9, y + 7, t.pB());
                g.fill(x + 4, y + 8, x + 7, y + 9, dark);
                if ((anim / 12 + seed) % 3 == 0) g.fill(x + 10, y + 1, x + 11, y + 2, t.pC());
            }
            case 6 -> {                                                        // a stone lantern
                Gfx.rrect(g, x + 1, y + 8, CP - 2, 3, 1, t.pA());
                g.fill(x + 4, y + 4, x + 7, y + 9, Gfx.darker(t.pA(), 0.1F));
                Gfx.rrect(g, x, y + 1, CP, 3, 1, Gfx.darker(t.pA(), 0.2F));
                g.fill(x + 3, y + 4, x + 8, y + 7, (anim / 10 + seed) % 2 == 0 ? t.pB() : Gfx.darker(t.pB(), 0.12F));
                g.fill(x + 5, y, x + 6, y + 1, t.pC());
            }
            default -> {                                                       // a block with a little star
                Gfx.bubble(g, x, y, CP, CP, 3, t.pA());
                g.fill(x + 3, y + 3, x + CP - 3, y + CP - 4, t.pB());
                g.fill(x + 3, y + 3, x + CP - 3, y + 4, Gfx.lighter(t.pB(), 0.4F));
                Gfx.star(g, x + 5, y + 5, 1, (seed & 1) == 0 ? t.pC() : 0xFFFFB3D1);
            }
        }
    }

    private void crate(GuiGraphics g, Theme t, int x, int y) {
        switch (t.cStyle()) {
            case 1 -> {                                                        // a hay bale
                Gfx.bubble(g, x, y, CP, CP, 3, t.cA());
                g.fill(x + 3, y + 1, x + 4, y + CP - 1, t.cB());
                g.fill(x + 7, y + 1, x + 8, y + CP - 1, t.cB());
                g.fill(x + 1, y + 2, x + 3, y + 3, t.cC()); g.fill(x + 5, y + 5, x + 7, y + 6, t.cC()); g.fill(x + 8, y + 8, x + 10, y + 9, t.cC());
            }
            case 2 -> {                                                        // an ice cube
                Gfx.bubble(g, x, y, CP, CP, 3, t.cA());
                g.fill(x + 2, y + 2, x + 6, y + 5, t.cB());
                g.fill(x + 7, y + 7, x + 9, y + 8, t.cB());
                Gfx.star(g, x + 8, y + 3, 1, t.cC());
            }
            case 3 -> {                                                        // a wooden crate
                Gfx.bubble(g, x, y, CP, CP, 2, t.cA());
                g.fill(x + 1, y + 3, x + CP - 1, y + 4, t.cB());
                g.fill(x + 1, y + 7, x + CP - 1, y + 8, t.cB());
                Gfx.line(g, x + 1, y + 1, x + 9, y + 9, Gfx.alpha(t.cB(), 150));
                g.fill(x + 1, y + 1, x + 2, y + 2, t.cC()); g.fill(x + CP - 2, y + 1, x + CP - 1, y + 2, t.cC());
                g.fill(x + 1, y + CP - 2, x + 2, y + CP - 1, t.cC()); g.fill(x + CP - 2, y + CP - 2, x + CP - 1, y + CP - 1, t.cC());
            }
            case 4 -> {                                                        // a treasure chest
                Gfx.bubble(g, x, y, CP, CP, 2, t.cA());
                g.fill(x + 1, y + 4, x + CP - 1, y + 5, Gfx.darker(t.cA(), 0.25F));
                g.fill(x + 4, y + 1, x + 7, y + CP - 1, t.cB());
                g.fill(x + 5, y + 4, x + 6, y + 7, t.cC());
                g.fill(x + 1, y + 1, x + 2, y + 3, Gfx.alpha(t.cB(), 190));
            }
            default -> {                                                       // a gift with a ribbon and a bow
                Gfx.bubble(g, x, y, CP, CP, 2, t.cA());
                g.fill(x + 4, y + 1, x + 7, y + CP - 1, t.cB());
                g.fill(x + 1, y + 4, x + CP - 1, y + 7, t.cB());
                g.fill(x + 3, y, x + 5, y + 2, t.cC());
                g.fill(x + 6, y, x + 8, y + 2, t.cC());
                g.fill(x + 5, y + 1, x + 6, y + 2, Gfx.darker(t.cC(), 0.2F));
            }
        }
    }

    /** A pit (lava, or water in a pond) or slime, drawn on the floor of one cell. */
    private void hazard(GuiGraphics g, Theme t, int kind, int x, int y, int seed) {
        if (kind == BomberSim.SLIME) {
            Gfx.rrect(g, x, y, CP, CP, 2, Gfx.darker(t.hz1(), 0.3F));
            Gfx.rrect(g, x, y, CP, CP - 1, 2, t.hz1());
            g.fill(x + 2, y + 1, x + 5, y + 2, t.hz2());
            int ph = (anim / 7 + seed) % 5;
            g.fill(x + 2 + ph / 2, y + 7 - ph, x + 4 + ph / 2, y + 9 - ph, Gfx.alpha(t.hz3(), 200));
            g.fill(x + 7, y + 3 + (ph + 2) % 4, x + 8, y + 4 + (ph + 2) % 4, Gfx.alpha(t.hz3(), 160));
        } else if (t.hStyle() == 1) {                                          // water: waves
            g.fill(x, y, x + CP, y + CP, Gfx.darker(t.hz1(), 0.25F));
            g.fill(x + 1, y + 1, x + CP - 1, y + CP - 1, t.hz1());
            int off = (anim / 9 + seed) % 5;
            g.fill(x + 1 + off, y + 3, Math.min(x + CP - 1, x + 5 + off), y + 4, t.hz2());
            g.fill(x + 1 + (off + 2) % 5, y + 7, Math.min(x + CP - 1, x + 5 + (off + 2) % 5), y + 8, t.hz2());
            if ((anim / 6 + seed) % 7 == 0) g.fill(x + 3 + seed % 5, y + 5, x + 4 + seed % 5, y + 6, t.hz3());
        } else {                                                               // lava: a dark crust and glowing blobs
            g.fill(x, y, x + CP, y + CP, Gfx.darker(t.hz1(), 0.45F));
            g.fill(x + 1, y + 1, x + CP - 1, y + CP - 1, t.hz1());
            int b1 = (anim / 5 + seed * 3) % 6, b2 = (anim / 6 + seed * 5 + 3) % 6;
            g.fill(x + 2 + b1 / 2, y + 2, x + 5 + b1 / 2, y + 4, t.hz2());
            g.fill(x + 1 + b2 / 2, y + 6, x + 4 + b2 / 2, y + 8, t.hz2());
            if ((anim / 4 + seed) % 5 == 0) g.fill(x + 6, y + 4, x + 7, y + 5, t.hz3());
            g.fill(x + 1, y + 1, x + CP - 1, y + 2, Gfx.alpha(t.hz3(), 90));
        }
    }

    private void flame(GuiGraphics g, BomberSim s, int i, int x, int y) {
        int c = i % COLS, r = i / COLS;
        boolean f = (anim / 2) % 2 == 0;
        g.fill(x - 1, y - 1, x + CP + 1, y + CP + 1, 0x33FF7A3D);
        Gfx.rrect(g, x, y, CP, CP, 3, f ? 0xFFFF8A3D : 0xFFFF7233);
        Gfx.rrect(g, x + 1, y + 1, CP - 2, CP - 2, 2, 0xFFFFC93B);
        Gfx.rrect(g, x + 3, y + 3, CP - 6, CP - 6, 1, f ? 0xFFFFF4B8 : 0xFFFFFFFF);
        // arms to the next flames, so a blast looks like one shape
        if (c + 1 < COLS && s.flame[i + 1] > 0) g.fill(x + CP - 1, y + 2, x + CP + 1, y + CP - 2, 0xFFFFC93B);
        if (r + 1 < ROWS && s.flame[i + COLS] > 0) g.fill(x + 2, y + CP - 1, x + CP - 2, y + CP + 1, 0xFFFFC93B);
    }

    private void bomb(GuiGraphics g, int cx, int cy, int r, int fuse) {
        boolean hot = fuse < 14 && (anim / 2) % 2 == 0;
        int pulse = fuse < 28 && (anim / 4) % 2 == 0 ? 1 : 0;
        if (r >= 3) Gfx.ellipse(g, cx, cy + r, r, 1, 0x30000000);
        Gfx.ball(g, cx, cy, r + pulse, hot ? 0xFF8A3A4A : 0xFF4A3F66);
        if (r >= 3 && fuse < 99) {                                           // the fuse and its spark
            g.fill(cx + 1, cy - r - 1 - pulse, cx + 2, cy - r + 1, 0xFFBFA77A);
            Gfx.star(g, cx + 2, cy - r - 2 - pulse, (anim / 3) % 2, (anim / 3) % 2 == 0 ? 0xFFFFE27A : 0xFFFF8A3D);
        }
    }

    private void item(GuiGraphics g, int kind, int x, int y) {
        int bob = (int) Math.round(Math.sin(anim * 0.15 + x) * 0.8);
        int cx = x + CP / 2, cy = y + CP / 2 + bob;
        g.fill(x, y, x + CP, y + CP, 0x22FFFFFF);
        Gfx.ellipse(g, cx, y + CP - 1, 3, 1, 0x22000000);
        Gfx.bubble(g, x + 1, y + 1 + bob, CP - 2, CP - 2, 3, 0xFFFFFFF0);
        switch (kind) {
            case BomberSim.IT_BOMB -> {
                Gfx.ball(g, cx, cy + 1, 2, 0xFF4A3F66);
                g.fill(cx + 1, cy - 3, cx + 2, cy - 1, 0xFFBFA77A);
                g.fill(cx + 2, cy - 4, cx + 3, cy - 3, 0xFFFF8A3D);
            }
            case BomberSim.IT_FLAME -> {
                g.fill(cx - 2, cy, cx + 3, cy + 3, 0xFFFF6A3D);
                g.fill(cx - 1, cy - 2, cx + 2, cy + 1, 0xFFFF6A3D);
                g.fill(cx, cy - 3, cx + 1, cy - 1, 0xFFFF6A3D);
                g.fill(cx - 1, cy + 1, cx + 2, cy + 3, 0xFFFFC93B);
            }
            case BomberSim.IT_SPEED -> Gfx.poly(g, new int[]{cx + 1, cx - 2, cx, cx - 1, cx + 2, cx}, new int[]{cy - 3, cy + 1, cy + 1, cy + 4, cy - 1, cy - 1}, 0xFF3FA7F0);
            default -> Gfx.heart(g, cx - 3, cy - 3, 0xFFFF5C8A);
        }
    }

    private void ghostSprite(GuiGraphics g, int x, int y, int tint, float k) {
        int body = Gfx.fade(Gfx.mix(0xFFFFFFFF, tint, 0.3F), Math.min(1F, k * 1.5F));
        g.fill(x - 3, y - 2, x + 4, y + 3, body);
        g.fill(x - 2, y - 4, x + 3, y - 2, body);
        g.fill(x - 3, y + 3, x - 1, y + 4, body); g.fill(x, y + 3, x + 1, y + 4, body); g.fill(x + 2, y + 3, x + 4, y + 4, body);
        int eye = Gfx.fade(INK, Math.min(1F, k * 1.5F));
        g.fill(x - 2, y - 2, x - 1, y, eye); g.fill(x + 1, y - 2, x + 2, y, eye);
    }

    /**
     * One animal, drawn into an 11 x 11 pixel box at (ox, oy) and scaled by k. slot: 0 cat, 1 panda, 2 fox, 3 penguin.
     * facing: 0 down (the face is seen), 1 left, 2 right, 3 up (the back of the head). step: 0 stands, 1 and 2 are the two steps.
     */
    private void animal(GuiGraphics g, int slot, int ox, int oy, int facing, int step, float k) {
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(k, k, 1F);
        int main = MAIN[slot], rim = RIM[slot];
        int ear = slot == 1 ? 0xFF2B2B35 : slot == 2 ? 0xFFE07B1F : main;
        // ears (the penguin has none, only a tuft)
        if (slot == 3) { px(g, 5, 1, 1, 2, rim); px(g, 4, 2, 1, 1, rim); }
        else {
            px(g, 1, slot == 1 ? 1 : 0, 2, slot == 1 ? 2 : 3, ear); px(g, 8, slot == 1 ? 1 : 0, 2, slot == 1 ? 2 : 3, ear);
            if (slot == 0) { px(g, 2, 1, 1, 2, 0xFFFFD6E6); px(g, 8, 1, 1, 2, 0xFFFFD6E6); }
            if (slot == 2) { px(g, 1, 0, 1, 1, 0xFF5A3A2A); px(g, 9, 0, 1, 1, 0xFF5A3A2A); }
        }
        // the body and the feet
        int body = slot == 1 ? 0xFFF4F4FA : slot == 3 ? 0xFF4F7BE0 : Gfx.darker(main, 0.08F);
        px(g, 3, 8, 5, 2, body);
        if (slot == 3) px(g, 4, 8, 3, 2, 0xFFFFFFFF);
        int foot = slot == 1 ? 0xFF2B2B35 : slot == 2 ? 0xFF6B3F22 : slot == 3 ? 0xFFFFA63A : rim;
        if (step != 2) px(g, 2, 10, 3, 1, foot);                    // one foot is lifted in each step
        if (step != 1) px(g, 6, 10, 3, 1, foot);
        // the head: a darker lip at the bottom, then the face
        head(g, 1, rim);
        head(g, 0, main);
        if (slot == 1) px(g, 3, 4, 5, 3, 0xFFFFFFFF);
        if (slot == 2 && facing != 3) { px(g, 2, 6, 2, 1, 0xFFFFF1DD); px(g, 7, 6, 2, 1, 0xFFFFF1DD); px(g, 4, 7, 3, 1, 0xFFFFF1DD); }
        if (slot == 3 && facing != 3) px(g, 3, 4, 5, 4, 0xFFFFFFFF);
        if (facing == 3) {                                          // the back: no face, just a darker patch of fur
            px(g, 4, 3, 3, 1, rim);
            g.pose().popPose();
            return;
        }
        int dx = facing == 1 ? -1 : facing == 2 ? 1 : 0;
        boolean blink = (anim + slot * 37) % 150 < 6;
        if (slot == 1) {                                            // the dark patches round the eyes
            px(g, 2 + dx, 4, 2, 3, 0xFF2B2B35); px(g, 7 + dx, 4, 2, 3, 0xFF2B2B35);
            if (!blink) { px(g, 3 + dx, 5, 1, 1, 0xFFFFFFFF); px(g, 7 + dx, 5, 1, 1, 0xFFFFFFFF); }
            px(g, 5 + dx, 6, 1, 1, 0xFF2B2B35);
        } else {
            int eh = blink ? 1 : 2;
            px(g, 3 + dx, 5, 1, eh, INK); px(g, 7 + dx, 5, 1, eh, INK);
            if (!blink) { px(g, 3 + dx, 5, 1, 1, 0xFF6B5A7E); px(g, 7 + dx, 5, 1, 1, 0xFF6B5A7E); }
            if (slot == 3) { px(g, 4 + dx, 6, 3, 1, 0xFFFFA63A); px(g, 5 + dx, 7, 1, 1, 0xFFE0841A); }
            else { px(g, 5 + dx, 6, 1, 1, slot == 0 ? 0xFFE0508A : INK); px(g, 2 + dx, 6, 1, 1, 0x88FF6FA3); px(g, 8 + dx, 6, 1, 1, 0x88FF6FA3); }
        }
        g.pose().popPose();
    }

    private static void head(GuiGraphics g, int dy, int col) {
        px(g, 3, 2 + dy, 5, 1, col);
        px(g, 2, 3 + dy, 7, 1, col);
        px(g, 1, 4 + dy, 9, 3, col);
        px(g, 2, 7 + dy, 7, 1, col);
    }

    private static void px(GuiGraphics g, int x, int y, int w, int h, int argb) {
        if (argb == 0 || w <= 0 || h <= 0) return;
        g.fill(x, y, x + w, y + h, argb);
    }
}
