package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The pictures of the visual novel {@link Cicada}: eight painted backgrounds and four anime characters with six faces each,
 * all drawn from fills (discs, polygons, gradients). Everything lives in a design space of {@link #W} x {@link #H} units that
 * the game draws at half the size of its 220 x 140 box (pose scale 0.5), so lines are finer than the pixels of the other games.
 * Nothing here is random per frame: shapes are placed by hash, so the scenes do not flicker; only time t moves them.
 */
final class CicadaArt {
    static final int W = 440, H = 280;

    static final int BG_ROAD = 0, BG_SHRINE = 1, BG_CLASS = 2, BG_ROOM = 3, BG_WELL = 4, BG_FEST = 5, BG_VOID = 6, BG_DAWN = 7;
    static final int YUNA = 0, ASUKA = 1, HIKARI = 2, SILENT = 3;
    static final int N = 0, SMILE = 1, SAD = 2, SCARED = 3, BLANK = 4, CRAZED = 5;

    private static GuiGraphics g;

    private CicadaArt() {}

    // ================================================================== primitives
    private static void R(int x, int y, int w, int h, int c) { if (w > 0 && h > 0) g.fill(x, y, x + w, y + h, c); }

    private static void E(int cx, int cy, int rx, int ry, int c) { if (rx > 0 && ry > 0) Gfx.ellipse(g, cx, cy, rx, ry, c); }

    private static void P(int[] xs, int[] ys, int c) { Gfx.poly(g, xs, ys, c); }

    private static void G(int x, int y, int w, int h, int top, int bot) { if (w > 0 && h > 0) g.fillGradient(x, y, x + w, y + h, top, bot); }

    /** A line of a given thickness (a quad). */
    private static void L(float x1, float y1, float x2, float y2, float w, int c) {
        float dx = x2 - x1, dy = y2 - y1, len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.01F) { E(Math.round(x1), Math.round(y1), Math.max(1, Math.round(w / 2)), Math.max(1, Math.round(w / 2)), c); return; }
        float nx = -dy / len * w / 2F, ny = dx / len * w / 2F;
        P(new int[]{Math.round(x1 + nx), Math.round(x2 + nx), Math.round(x2 - nx), Math.round(x1 - nx)},
                new int[]{Math.round(y1 + ny), Math.round(y2 + ny), Math.round(y2 - ny), Math.round(y1 - ny)}, c);
    }

    private static int A(int rgb, int a) { return Gfx.alpha(rgb, a); }

    private static float h(int i, int k) { return Gfx.hash(i, k); }

    /** A mountain ridge: a polygon under a curve made of three sines. */
    private static void ridge(int baseY, int amp, float seed, int col) {
        int step = 10, n = W / step + 2;
        int[] xs = new int[n + 3], ys = new int[n + 3];
        for (int i = 0; i <= n; i++) {
            float x = i * step;
            float v = (float) (Math.sin(x * 0.013 + seed) + 0.55 * Math.sin(x * 0.031 + seed * 2.3) + 0.25 * Math.sin(x * 0.067 + seed * 4.1));
            xs[i] = (int) x; ys[i] = baseY - (int) Math.round(amp * (0.55 + 0.45 * v / 1.8F));
        }
        xs[n + 1] = W + step; ys[n + 1] = baseY + 6; xs[n + 2] = 0; ys[n + 2] = baseY + 6;
        P(xs, ys, col);
    }

    private static void cicada(int x, int y, int s, int t, int seed) {
        float tw = (float) Math.sin(t * 0.9 + seed) * 0.5F;
        E(x - s, y, Math.max(1, s), s * 2, A(0xFFCFE6F0, 110 + (int) (tw * 60)));
        E(x + s, y, Math.max(1, s), s * 2, A(0xFFCFE6F0, 110 - (int) (tw * 60)));
        E(x, y, Math.max(1, s), s * 2 + 1, 0xFF2A2420);
        R(x - s, y - s * 2 - 1, s * 2, 2, 0xFF3A6E4A);
    }

    // ================================================================== backgrounds
    /**
     * @param mood 0 = calm ... 4 = the world is wrong (the picture gets darker and redder)
     * @param hush the cicadas are silent: the colours drain away
     * @param fig  a pale figure stands in the window (room scene)
     */
    static void background(GuiGraphics gr, int id, int t, int mood, boolean hush, boolean fig) {
        g = gr;
        switch (id) {
            case BG_ROAD -> road(t, false);
            case BG_DAWN -> road(t, true);
            case BG_SHRINE -> shrine(t);
            case BG_CLASS -> classroom(t, mood);
            case BG_ROOM -> room(t, fig);
            case BG_WELL -> well(t, mood);
            case BG_FEST -> festival(t, hush);
            default -> voidScene(t);
        }
        if (hush) {      // the colours drain away, the picture turns cold
            R(0, 0, W, H, A(0xFF1C2438, 105));
            G(0, 0, W, H, A(0xFF000000, 0), A(0xFF0A1020, 60));
        }
        if (mood > 0) {  // blood in the corners
            int a = 14 + mood * 14;
            G(0, 0, W, 60, A(0xFF500010, a), A(0xFF500010, 0));
            G(0, H - 70, W, 70, A(0xFF500010, 0), A(0xFF500010, a + 20));
            R(0, 0, 10 + mood * 3, H, A(0xFF300008, a));
            R(W - 10 - mood * 3, 0, 10 + mood * 3, H, A(0xFF300008, a));
        }
        g = null;
    }

    private static void road(int t, boolean dawn) {
        int top = dawn ? 0xFF6FA8E0 : 0xFF2C2157, mid = dawn ? 0xFFFFC9D6 : 0xFFD8527A, hor = dawn ? 0xFFFFF0B8 : 0xFFFFB04A;
        G(0, 0, W, 80, top, mid);
        G(0, 80, W, 78, mid, hor);
        int sx = 292, sy = dawn ? 140 : 146;
        Gfx.glow(g, sx, sy, 120, dawn ? 0xFFFFE9A8 : 0xFFFFB347, dawn ? 80 : 110);
        E(sx, sy, 26, 26, A(dawn ? 0xFFFFFFFF : 0xFFFFD27A, 90));
        E(sx, sy, 22, 22, dawn ? 0xFFFFF8D8 : 0xFFFFE08A);
        for (int i = 0; i < 5; i++) {             // streaky clouds drifting to the left
            int cx = (int) (((i * 131 + 40 - t * 0.1F) % 560 + 560) % 560) - 70, cy = 22 + (i * 29) % 90;
            int col = dawn ? 0xFFFFFFFF : (i % 2 == 0 ? 0xFFFF9AA8 : 0xFF7A3C86);
            E(cx, cy, 52, 4, A(col, 120)); E(cx + 18, cy - 4, 34, 3, A(col, 90)); E(cx - 20, cy + 4, 30, 2, A(col, 80));
        }
        ridge(160, 54, 1.3F, dawn ? 0xFFA6BCE0 : 0xFF6D4282);
        ridge(166, 34, 4.1F, dawn ? 0xFF7FA0CC : 0xFF472A66);
        // rice paddies
        int fieldTop = 160;
        G(0, fieldTop, W, H - fieldTop, dawn ? 0xFF8FC060 : 0xFF566F2E, dawn ? 0xFF4C7A34 : 0xFF2A3C20);
        int y = fieldTop + 2, bh = 2, row = 0;
        while (y < H) {                            // water between the rows reflects the sky
            R(0, y, W, bh, A(mid, dawn ? 70 : 85));
            y += bh * 2 + 1; bh = Math.min(8, bh + (row++ % 2));
        }
        for (int i = -10; i <= 10; i++) {          // the rows run to the vanishing point
            float ex = 220 + i * 62;
            L(220 + i * 2, fieldTop, ex, H, 1, A(0xFF1C2E18, 90));
        }
        // the road
        P(new int[]{213, 227, 346, 94}, new int[]{fieldTop, fieldTop, H, H}, dawn ? 0xFF6B677B : 0xFF48425A);
        P(new int[]{213, 216, 124, 94}, new int[]{fieldTop, fieldTop, H, H}, A(0xFFFFFFFF, 26));
        for (int i = 0; i < 6; i++) {
            float k0 = i / 6F, k1 = (i + 0.55F) / 6F;
            int y0 = fieldTop + (int) (k0 * k0 * 120), y1 = fieldTop + (int) (k1 * k1 * 120);
            int w0 = 1 + (int) ((y0 - fieldTop) * 0.06F), w1 = 1 + (int) ((y1 - fieldTop) * 0.06F);
            P(new int[]{220 - w0, 220 + w0, 220 + w1, 220 - w1}, new int[]{y0, y0, y1, y1}, 0xFFE6DFC8);
        }
        // trees with cicadas
        int dark = dawn ? 0xFF3F5E3A : 0xFF241B38;
        R(22, 120, 12, 110, dark);
        E(26, 96, 46, 38, dark); E(-6, 108, 40, 40, dark); E(62, 112, 34, 28, dark);
        E(14, 84, 22, 14, A(dawn ? 0xFF7FB060 : 0xFF6A3A5A, 120));
        cicada(30, 150, 2, t, 1); cicada(27, 176, 2, t, 2); cicada(32, 196, 2, t, 3);
        // the bus stop
        P(new int[]{70, 168, 178, 60}, new int[]{148, 148, 158, 158}, dawn ? 0xFF4A7080 : 0xFF2F4553);
        R(74, 158, 4, 58, 0xFF5A5F6A); R(160, 158, 4, 58, 0xFF5A5F6A);
        R(78, 158, 82, 44, A(0xFFBFE0F0, 46));
        R(84, 196, 70, 5, 0xFF8A6A48); R(88, 201, 4, 14, 0xFF6A4E34); R(146, 201, 4, 14, 0xFF6A4E34);
        R(188, 112, 4, 106, 0xFF7C808C); E(190, 108, 12, 12, 0xFFE9E4D8); E(190, 108, 9, 9, 0xFF2D5FA8);
        R(185, 105, 10, 6, 0xFFFFFFFF); R(186, 112, 3, 2, 0xFF2D5FA8); R(192, 112, 3, 2, 0xFF2D5FA8);
        // a pole with wires
        R(372, 50, 7, 200, 0xFF33272E);
        R(352, 66, 46, 4, 0xFF33272E); R(360, 82, 30, 3, 0xFF33272E);
        for (int wi = 0; wi < 3; wi++) {
            int y0 = 68 + wi * 7, sag = 16 + wi * 5;
            float px = 375, py = y0;
            for (int x = 366; x >= -12; x -= 12) {
                float tt = (375 - x) / 387F;
                float qy = y0 + (float) Math.sin(tt * Math.PI) * sag;
                L(px, py, x, qy, 1, 0xFF251C28);
                px = x; py = qy;
            }
        }
        cicada(376, 130, 2, t, 4); cicada(374, 160, 2, t, 5);
        // fireflies at dusk, a few birds at dawn
        for (int i = 0; i < 7; i++) {
            float fx = 40 + h(i, 1) * 360 + (float) Math.sin(t * 0.02 + i * 2) * 14, fy = 176 + h(i, 2) * 80 + (float) Math.sin(t * 0.03 + i) * 8;
            if (!dawn) Gfx.glow(g, Math.round(fx), Math.round(fy), 5, 0xFFC8FF70, 90 + (int) (50 * Math.sin(t * 0.07 + i)));
        }
        for (int i = 0; i < 9; i++) {              // the tall grass in front
            int gx = i < 5 ? i * 10 : W - (i - 4) * 10, sway = (int) (Math.sin(t * 0.03 + i) * 3);
            P(new int[]{gx, gx + 8, gx + 4 + sway}, new int[]{H, H, H - 40 - (i % 3) * 12}, dawn ? 0xFF2F5A2A : 0xFF16241A);
        }
    }

    private static void shrine(int t) {
        G(0, 0, W, 90, 0xFF240B30, 0xFF9E2A48);
        G(0, 90, W, 90, 0xFF9E2A48, 0xFFF08A4A);
        Gfx.glow(g, 220, 150, 130, 0xFFFFA050, 110);
        E(220, 150, 30, 30, 0xFFFFD28A);
        ridge(186, 56, 2.2F, 0xFF3C1A44);
        // pine forest on both sides
        for (int i = 0; i < 14; i++) {
            int tx = i < 7 ? 4 + i * 20 : W - 4 - (i - 7) * 20, ty = 150 - (int) (h(i, 3) * 40);
            P(new int[]{tx - 14, tx + 14, tx}, new int[]{190, 190, ty}, 0xFF1B0F24);
            P(new int[]{tx - 11, tx + 11, tx}, new int[]{ty + 38, ty + 38, ty - 8}, 0xFF221430);
        }
        G(0, 186, W, H - 186, 0xFF2E1832, 0xFF150C1C);
        // steps going up to the gate
        for (int i = 0; i < 7; i++) {
            int y = 262 - i * 11, wHalf = 108 - i * 7;
            int shade = 0x30 + i * 6;
            R(220 - wHalf, y, wHalf * 2, 10, 0xFF000000 | (shade + 0x50) << 16 | (shade + 0x3C) << 8 | (shade + 0x50));
            R(220 - wHalf, y, wHalf * 2, 2, A(0xFFFFFFFF, 40));
            R(220 - wHalf, y + 8, wHalf * 2, 2, A(0xFF000000, 60));
        }
        // the torii
        int red = 0xFFB3262E, redDark = 0xFF7A1822;
        R(156, 78, 17, 124, red); R(267, 78, 17, 124, red);
        R(156, 78, 4, 124, A(0xFFFFFFFF, 50)); R(267, 78, 4, 124, A(0xFFFFFFFF, 50));
        R(154, 190, 21, 12, 0xFF1A1418); R(265, 190, 21, 12, 0xFF1A1418);
        R(166, 100, 108, 9, redDark); R(166, 100, 108, 2, red);
        P(new int[]{112, 328, 316, 124}, new int[]{62, 62, 78, 78}, 0xFF1A1418);
        P(new int[]{106, 220, 220, 118}, new int[]{54, 60, 66, 70}, 0xFF1A1418);
        P(new int[]{334, 220, 220, 322}, new int[]{54, 60, 66, 70}, 0xFF1A1418);
        R(120, 70, 200, 8, red); R(120, 70, 200, 2, A(0xFFFFFFFF, 60));
        R(214, 78, 12, 22, 0xFF3A1A20); R(216, 82, 8, 14, 0xFFE8C860);
        // stone lanterns
        for (int s = 0; s < 2; s++) {
            int lx = s == 0 ? 78 : 362;
            R(lx - 6, 150, 12, 66, 0xFF6A6A78); R(lx - 14, 214, 28, 8, 0xFF585866);
            R(lx - 12, 124, 24, 26, 0xFF6A6A78);
            R(lx - 7, 130, 14, 14, 0xFFFFD27A);
            Gfx.glow(g, lx, 137, 34, 0xFFFFB050, 120 + (int) (30 * Math.sin(t * 0.09 + s * 2)));
            P(new int[]{lx - 22, lx + 22, lx + 12, lx - 12}, new int[]{124, 124, 108, 108}, 0xFF585866);
            E(lx, 106, 5, 5, 0xFF6A6A78);
        }
        // a rope with paper streamers
        L(78, 118, 362, 118, 2, 0xFFE8E0D0);
        for (int i = 0; i < 12; i++) {
            int px = 96 + i * 22 + (int) (Math.sin(t * 0.05 + i) * 2);
            if (px > 150 && px < 290) continue;
            P(new int[]{px, px + 8, px + 6, px + 8, px}, new int[]{118, 118, 128, 138, 146}, 0xFFF0ECE4);
        }
        cicada(165, 130, 2, t, 7); cicada(272, 160, 2, t, 8); cicada(163, 168, 2, t, 9);
        for (int i = 0; i < 3; i++) {
            int fy = 222 + i * 14, fx = (int) (((t * (0.2F + i * 0.1F) + i * 140) % 520) - 40);
            E(fx, fy, 70, 5, A(0xFFD8B0C8, 26));
        }
    }

    private static void classroom(int t, int mood) {
        // the wall and the floor
        G(0, 0, W, 170, 0xFFE0CFA6, 0xFFC9B386);
        R(0, 118, W, 52, 0xFF9A6E44); R(0, 118, W, 3, 0xFFB98A58);
        for (int i = 0; i < 12; i++) R(i * 40 + 6, 121, 2, 49, A(0xFF5A3A20, 60));
        G(0, 170, W, 110, 0xFF8B6039, 0xFF5E3C22);
        for (int i = -8; i <= 8; i++) L(220 + i * 8, 170, 220 + i * 56, H, 1, A(0xFF3A2414, 90));
        for (int i = 0; i < 4; i++) R(0, 176 + i * i * 7 + i * 6, W, 1, A(0xFF3A2414, 70));
        // windows with a bright summer outside
        for (int i = 0; i < 2; i++) {
            int wx = 24 + i * 100;
            R(wx - 4, 20, 90, 100, 0xFF6A4A2C);
            G(wx, 24, 82, 92, 0xFF8EC8F2, 0xFFD7EEFF);
            P(new int[]{wx, wx + 12, wx + 32, wx + 56, wx + 72, wx + 82, wx + 82, wx}, new int[]{108, 98, 92, 96, 101, 106, 116, 116}, 0xFF4E8A3A);
            P(new int[]{wx, wx + 20, wx + 50, wx + 82, wx + 82, wx}, new int[]{112, 106, 104, 108, 116, 116}, 0xFF3C7430);
            E(wx + 22, 40, 20, 5, A(0xFFFFFFFF, 190)); E(wx + 60, 56, 16, 4, A(0xFFFFFFFF, 150));
            R(wx + 40, 24, 2, 92, 0xFF6A4A2C); R(wx, 66, 82, 2, 0xFF6A4A2C);
            cicada(wx + 12, 100, 2, t, 10 + i);
        }
        // light shafts on the floor
        for (int i = 0; i < 2; i++) {
            int wx = 24 + i * 100;
            P(new int[]{wx, wx + 82, wx + 200, wx + 80}, new int[]{118, 118, 250, 250}, A(0xFFFFF0B0, 34));
        }
        // the blackboard
        R(228, 30, 170, 86, 0xFF6A4A2C); R(232, 34, 162, 78, 0xFF234A3A);
        R(232, 108, 162, 4, 0xFF8A6A48);
        for (int i = 0; i < 6; i++) {
            int ly = 44 + i * 11, lw = 60 + (int) (h(i, 7) * 80);
            R(242, ly, lw, 2, A(0xFFE8F0E8, 90));
        }
        R(246, 92, 20, 3, A(0xFFE8F0E8, 120));
        if (mood >= 3) for (int i = 0; i < 4; i++) R(300 + i * 18, 52 + i * 3, 14, 2, A(0xFFC8282E, 200));   // the same word again and again
        // a clock
        E(210, 40, 12, 12, 0xFFF0E8D8); E(210, 40, 10, 10, 0xFFFFFFF4);
        L(210, 40, 210, 33, 1.4F, 0xFF2A2020); L(210, 40, 215, 43, 1.4F, 0xFF2A2020);
        // desks in rows
        for (int row = 0; row < 3; row++) {
            for (int c = 0; c < 3; c++) {
                float k = 0.55F + row * 0.3F;
                int dw = Math.round(56 * k), dh = Math.round(24 * k);
                int dx = Math.round(220 + (c - 1) * 110 * k - dw / 2F), dy = 172 + row * 34 + (int) (row * row * 6);
                R(dx, dy, dw, dh, 0xFFC09A68); R(dx, dy, dw, 3, 0xFFD8B484);
                R(dx + 3, dy + dh, 3, Math.round(16 * k), 0xFF5A4630); R(dx + dw - 6, dy + dh, 3, Math.round(16 * k), 0xFF5A4630);
                R(dx + dw / 4, dy + dh + Math.round(8 * k), dw / 2, Math.round(10 * k), 0xFF6A5236);
            }
        }
        // the empty desk by the window: a vase with a white flower
        R(34, 176, 66, 28, 0xFFD8B484); R(34, 176, 66, 3, 0xFFEBCB98); R(40, 204, 4, 20, 0xFF5A4630); R(90, 204, 4, 20, 0xFF5A4630);
        R(60, 158, 12, 20, 0xFF7C9CC8); R(62, 158, 3, 20, A(0xFFFFFFFF, 90));
        L(66, 158, 66, 140, 2, 0xFF3A7A3A);
        for (int i = 0; i < 6; i++) { double a = i * Math.PI / 3; E(66 + (int) (Math.cos(a) * 6), 136 + (int) (Math.sin(a) * 6), 4, 4, 0xFFFFFFFF); }
        E(66, 136, 3, 3, 0xFFF0C84A);
        // dead cicadas on the floor
        int dead = 2 + mood * 3;
        for (int i = 0; i < dead; i++) {
            int dx = 30 + (int) (h(i, 20) * 380), dy = 212 + (int) (h(i, 21) * 60);
            E(dx, dy, 4, 2, 0xFF2A2420); E(dx - 3, dy - 1, 3, 1, A(0xFFCFE6F0, 150));
        }
        for (int i = 0; i < 18; i++) {             // dust in the light
            float dx = (h(i, 30) * 440 + t * 0.15F * (0.5F + h(i, 31))) % 440, dy = 30 + h(i, 32) * 160 + (float) Math.sin(t * 0.02 + i) * 6;
            E(Math.round(dx), Math.round(dy), 1, 1, A(0xFFFFF8D0, 170));
        }
    }

    private static void room(int t, boolean fig) {
        // the view through the window first (the walls are painted over its edges)
        G(126, 56, 188, 118, 0xFF0A1432, 0xFF1C3A5A);
        for (int i = 0; i < 20; i++) E(130 + (int) (h(i, 40) * 180), 60 + (int) (h(i, 41) * 50), 1, 1, A(0xFFFFFFFF, 120 + (int) (60 * Math.sin(t * 0.05 + i))));
        Gfx.glow(g, 262, 92, 46, 0xFFC8D8FF, 70);
        E(262, 92, 18, 18, 0xFFEFF2FF); E(268, 88, 5, 5, A(0xFFB8C4E0, 160)); E(256, 98, 3, 3, A(0xFFB8C4E0, 140));
        ridge(150, 26, 5.7F, 0xFF0E1A30);
        G(126, 150, 188, 24, 0xFF14301F, 0xFF0A1A14);
        for (int i = 0; i < 10; i++) L(220 + (i - 5) * 3, 150, 126 + i * 20, 174, 1, A(0xFF0A1A12, 160));
        // the wall around it
        int c1 = 0xFF161430, c2 = 0xFF241F46;
        G(0, 0, 126, 190, c1, c2); G(314, 0, 126, 190, c1, c2);
        G(126, 0, 188, 56, c1, Gfx.mix(c1, c2, 56 / 190F));
        G(126, 174, 188, 16, Gfx.mix(c1, c2, 174 / 190F), c2);
        for (int i = 0; i < 16; i++) { int vx = i * 28 + 8; if (vx < 120 || vx > 316) R(vx, 0, 2, 190, A(0xFF000000, 40)); }
        R(0, 36, W, 8, 0xFF2A2038);                         // a beam
        R(120, 50, 6, 130, 0xFF3A2C44); R(314, 50, 6, 130, 0xFF3A2C44); R(120, 50, 200, 6, 0xFF3A2C44); R(120, 174, 200, 6, 0xFF3A2C44);
        R(219, 56, 3, 118, 0xFF3A2C44); R(126, 112, 188, 3, 0xFF3A2C44);     // the frame of the shoji
        if (fig) {                                           // a pale girl in the field
            Gfx.glow(g, 184, 150, 26, 0xFFFFFFFF, 40);
            E(184, 134, 4, 5, 0xFFF0E8E4);
            P(new int[]{184, 177, 191}, new int[]{139, 160, 160}, 0xFFE8E4F0);
            R(180, 129, 3, 3, 0xFFC8282E); R(181, 134, 1, 1, 0xFF100810);
            float sway = (float) Math.sin(t * 0.04) * 0.5F;
            R(183 + Math.round(sway), 133, 1, 1, 0xFF100810);
        }
        P(new int[]{126, 314, 380, 60}, new int[]{174, 174, 280, 280}, A(0xFFBFD0FF, 22));   // moonlight on the floor
        // tatami floor
        G(0, 190, W, 90, 0xFF4E5030, 0xFF2E3020);
        for (int i = 0; i < 6; i++) R(0, 190 + i * i * 3 + i * 4, W, 1, A(0xFF1A1A10, 120));
        for (int i = -6; i <= 6; i++) L(220 + i * 20, 190, 220 + i * 70, H, 1, A(0xFF1A1A10, 100));
        // the futon
        P(new int[]{30, 150, 190, 10}, new int[]{214, 214, 268, 268}, 0xFFC8C0D8);
        P(new int[]{30, 150, 190, 10}, new int[]{214, 214, 222, 222}, 0xFFE8E4F4);
        E(60, 226, 28, 8, 0xFFF4F0FA);
        // a lamp
        R(366, 176, 4, 60, 0xFF5A4630); P(new int[]{352, 384, 376, 360}, new int[]{150, 150, 176, 176}, 0xFFE8C080);
        Gfx.glow(g, 368, 166, 54, 0xFFFFC060, 80);
    }

    private static void well(int t, int mood) {
        G(0, 0, W, 196, 0xFF050A14, 0xFF1C3248);
        for (int i = 0; i < 26; i++) E((int) (h(i, 50) * W), 6 + (int) (h(i, 51) * 70), 1, 1, A(0xFFFFFFFF, 110));
        Gfx.glow(g, 330, 56, 70, 0xFF8AB0E8, 60);
        E(330, 56, 22, 22, 0xFFDCE8FF); E(336, 52, 6, 6, A(0xFFA8B8D8, 150));
        // trunks of far and near trees
        for (int i = 0; i < 14; i++) {
            int tx = i * 34 + (int) (h(i, 52) * 14);
            R(tx, 20, 10, 200, 0xFF0A141C); R(tx, 20, 3, 200, A(0xFF8AB0E8, 24));
        }
        for (int i = 0; i < 5; i++) {
            int tx = i * 112 - 10;
            R(tx, 0, 28, 280, 0xFF04080E); R(tx + 22, 0, 4, 280, A(0xFF8AB0E8, 30));
        }
        G(0, 190, W, 90, 0xFF0E1E20, 0xFF040A0C);
        // the well
        E(220, 208, 74, 22, 0xFF3A4048);
        R(146, 184, 148, 24, 0xFF4A5058);
        for (int i = 0; i < 6; i++) { R(146 + i * 25 + (i % 2) * 3, 186 + (i % 2) * 12, 2, 12, A(0xFF000000, 90)); }
        R(146, 184, 148, 3, A(0xFFFFFFFF, 40));
        E(220, 184, 74, 20, 0xFF5A6068);
        E(220, 184, 62, 15, 0xFF020608);
        for (int i = 0; i < 3; i++) E(220, 184, 18 + ((t / 3 + i * 14) % 44), 3 + ((t / 3 + i * 14) % 44) / 4, A(0xFF8AB0E8, 40 - ((t / 3 + i * 14) % 44)));
        if (mood >= 2) {                                      // a face looks up from the water
            E(210, 184, 5, 6, A(0xFFEDE9F0, 120)); E(232, 184, 5, 6, A(0xFFEDE9F0, 120));
            E(210, 184, 2, 3, A(0xFF000000, 200)); E(232, 184, 2, 3, A(0xFF000000, 200));
        }
        R(152, 100, 8, 90, 0xFF4A3A28); R(280, 100, 8, 90, 0xFF4A3A28); R(148, 96, 144, 8, 0xFF5A4630);
        P(new int[]{140, 300, 290, 150}, new int[]{96, 96, 80, 80}, 0xFF3A2C1E);
        L(220, 104, 220, 150 + (int) (Math.sin(t * 0.04) * 3), 2, 0xFFB09A70); R(212, 150, 16, 14, 0xFF4A3A28);
        // will-o'-the-wisps and fog
        for (int i = 0; i < 6; i++) {
            float fx = 60 + h(i, 53) * 320 + (float) Math.sin(t * 0.015 + i * 3) * 24, fy = 110 + h(i, 54) * 100 + (float) Math.sin(t * 0.025 + i) * 12;
            Gfx.glow(g, Math.round(fx), Math.round(fy), 10, 0xFF70C8FF, 110);
            E(Math.round(fx), Math.round(fy), 2, 2, 0xFFD8F4FF);
        }
        for (int i = 0; i < 4; i++) {
            int fx = (int) (((t * (0.12F + i * 0.05F) + i * 170) % 640) - 100), fy = 170 + i * 26;
            E(fx, fy, 110, 9, A(0xFFA8C0D8, 26)); E(fx + 40, fy - 6, 70, 6, A(0xFFA8C0D8, 20));
        }
    }

    private static void festival(int t, boolean hush) {
        G(0, 0, W, 172, 0xFF0A0A24, 0xFF2A1840);
        for (int i = 0; i < 30; i++) E((int) (h(i, 60) * W), 4 + (int) (h(i, 61) * 80), 1, 1, A(0xFFFFFFFF, 110));
        Gfx.glow(g, 330, 70, 90, 0xFFFFC870, hush ? 50 : 90);
        E(330, 70, 30, 30, 0xFFFFE9A0); E(340, 62, 8, 8, A(0xFFE0C070, 130)); E(322, 82, 5, 5, A(0xFFE0C070, 110));
        ridge(150, 50, 3.3F, 0xFF1A1030);
        // the clock tower
        R(60, 60, 34, 110, 0xFF2A1C34); P(new int[]{54, 100, 77}, new int[]{60, 60, 30}, 0xFF1A1224);
        E(77, 82, 12, 12, 0xFFFFF0C0); L(77, 82, 77, 73, 1.6F, 0xFF1A1020); L(77, 82, 77, 72, 1.6F, 0xFF1A1020);
        G(0, 168, W, 112, 0xFF2A1A30, 0xFF120A18);
        // lantern strings
        for (int s = 0; s < 3; s++) {
            int y0 = 8 + s * 22;
            float px = 0, py = y0;
            for (int x = 20; x <= W + 20; x += 20) {
                float qy = y0 + (float) Math.sin(x / 440F * Math.PI * 4) * 6 + 10;
                L(px, py, x, qy, 1, 0xFF140A18);
                px = x; py = qy;
            }
            for (int i = 0; i < 11; i++) {
                int lx = 20 + i * 40 + (s % 2) * 20, ly = y0 + 10 + (int) (Math.sin(lx / 440F * Math.PI * 4) * 6) + 6;
                boolean lit = !hush || (i == 5 && s == 1);
                int col = (i + s) % 3 == 0 ? 0xFFE8482E : 0xFFFF9A3A;
                if (lit) Gfx.glow(g, lx, ly + 4, 16, col, 80 + (int) (20 * Math.sin(t * 0.07 + i)));
                E(lx, ly + 4, 6, 8, lit ? col : 0xFF3A2430); R(lx - 3, ly - 3, 6, 2, 0xFF140A18); R(lx - 3, ly + 11, 6, 2, 0xFF140A18);
                if (lit) E(lx - 2, ly + 2, 2, 3, A(0xFFFFFFFF, 90));
            }
        }
        // stalls
        for (int s = 0; s < 2; s++) {
            int sx = s == 0 ? 6 : 310;
            P(new int[]{sx, sx + 124, sx + 116, sx + 8}, new int[]{116, 116, 132, 132}, 0xFF6A1822);
            for (int i = 0; i < 6; i++) P(new int[]{sx + i * 20 + 8, sx + i * 20 + 18, sx + i * 20 + 16, sx + i * 20 + 10}, new int[]{116, 116, 132, 132}, 0xFFE8E0D0);
            R(sx + 8, 132, 4, 52, 0xFF3A2430); R(sx + 112, 132, 4, 52, 0xFF3A2430);
            R(sx + 12, 160, 100, 24, 0xFF4A3040);
            if (!hush) Gfx.glow(g, sx + 62, 150, 40, 0xFFFFB050, 70);
        }
        // the crowd: dark silhouettes; when it is silent they all look at you, with pale empty faces
        for (int row = 0; row < 2; row++) {
            for (int i = 0; i < 14; i++) {
                int px = 14 + i * 31 + (row % 2) * 15 + (int) (h(i, 70 + row) * 6), py = 186 + row * 26;
                int bh = 36 + row * 10, bw = 20 + row * 4;
                int body = row == 0 ? 0xFF160C1E : 0xFF0C0612;
                R(px - bw / 2, py, bw, bh, body); E(px, py, bw / 2, 5, body);
                if (hush) {
                    E(px, py - 10, 7 + row, 9 + row, 0xFFD8D4DC);
                    E(px - 3, py - 10, 1, 1, 0xFF0A0810); E(px + 3, py - 10, 1, 1, 0xFF0A0810);
                } else {
                    E(px, py - 10, 7 + row, 9 + row, 0xFF0E0814);
                    E(px + 3 * (i % 2 == 0 ? 1 : -1), py - 12, 3, 5, A(0xFFFFA050, 60));
                }
            }
        }
        for (int i = 0; i < 10; i++) {
            float fx = (h(i, 80) * 440 + t * 0.3F) % 440, fy = 120 + h(i, 81) * 80 + (float) Math.sin(t * 0.03 + i) * 8;
            Gfx.glow(g, Math.round(fx), Math.round(fy), 4, 0xFFFFD890, 80);
        }
    }

    private static void voidScene(int t) {
        G(0, 0, W, H, 0xFF05020A, 0xFF28040C);
        for (int i = 0; i < 10; i++) {
            int y0 = (int) ((h(i, 90) * 300 + t * (0.3F + h(i, 91))) % 300) - 10;
            R(0, y0, W, 1 + i % 2, A(0xFF8A1020, 40));
        }
        for (int i = 0; i < 26; i++) {
            float a = i * 0.24F;
            L(220, 140, 220 + (float) Math.cos(a) * 300, 140 + (float) Math.sin(a) * 300, 1, A(0xFF7A0C1C, 70));
        }
    }

    // ================================================================== characters
    private static final class Look {
        int hair, hairHi, hairDark, eye, eyeDark, eyeLight, skin, skinShade, cloth, clothDark, accent;
        boolean longHair, glasses, ribbon, pin, blunt;
        float k;
    }

    private static Look look(int ch) {
        Look l = new Look();
        l.k = 1.2F;
        switch (ch) {
            case YUNA -> {
                l.hair = 0xFF8A4A2C; l.hairHi = 0xFFC27A45; l.hairDark = 0xFF5A2E1C;
                l.eye = 0xFFE88A32; l.eyeDark = 0xFFB85A1E; l.eyeLight = 0xFFFFD27A;
                l.skin = 0xFFFFE2D2; l.skinShade = 0xFFF0B8A4;
                l.cloth = 0xFF2A3668; l.clothDark = 0xFF1B2348; l.accent = 0xFFD8283A;
                l.ribbon = true;
            }
            case ASUKA -> {
                l.hair = 0xFF1C1C34; l.hairHi = 0xFF4A4A78; l.hairDark = 0xFF0E0E1E;
                l.eye = 0xFF4A74D8; l.eyeDark = 0xFF22408E; l.eyeLight = 0xFF9ADCFF;
                l.skin = 0xFFFFE8DC; l.skinShade = 0xFFEEC0B0;
                l.cloth = 0xFF3A3A4E; l.clothDark = 0xFF24242F; l.accent = 0xFF8E1E30;
                l.longHair = true; l.glasses = true; l.blunt = true;
            }
            default -> {
                l.hair = 0xFFDCE6F4; l.hairHi = 0xFFFFFFFF; l.hairDark = 0xFF9AAAD0;
                l.eye = 0xFF9A68E8; l.eyeDark = 0xFF5A32A8; l.eyeLight = 0xFFE8B8FF;
                l.skin = 0xFFFFF2EE; l.skinShade = 0xFFF0C8C8;
                l.cloth = 0xFFF4F0F6; l.clothDark = 0xFFC8C0D4; l.accent = 0xFF5A3A8A;
                l.pin = true; l.blunt = true; l.k = 1.08F;
            }
        }
        return l;
    }

    /** A pen that draws in the local units of a character (the origin is the middle of the face). */
    private static final class Pen {
        final int cx, cy; final float k;
        Pen(int cx, int cy, float k) { this.cx = cx; this.cy = cy; this.k = k; }
        int x(float v) { return cx + Math.round(v * k); }
        int y(float v) { return cy + Math.round(v * k); }
        int s(float v) { return Math.max(1, Math.round(v * k)); }
        void e(float x, float y, float rx, float ry, int c) { E(x(x), y(y), s(rx), s(ry), c); }
        void r(float x, float y, float w, float h, int c) { R(x(x), y(y), s(w), s(h), c); }
        void p(int c, float... pts) {
            int n = pts.length / 2; int[] xs = new int[n], ys = new int[n];
            for (int i = 0; i < n; i++) { xs[i] = x(pts[i * 2]); ys[i] = y(pts[i * 2 + 1]); }
            P(xs, ys, c);
        }
        void l(float x1, float y1, float x2, float y2, float w, int c) { L(x(x1), y(y1), x(x2), y(y2), Math.max(1F, w * k), c); }
    }

    /**
     * Draws a character as a bust. cx = the middle of the face, cy = its height; the picture reaches below the game box (the
     * dialogue window covers it).
     * @param talking the mouth moves
     */
    static void character(GuiGraphics gr, int ch, int expr, int cx, int cy, int t, boolean talking, int seed) {
        g = gr;
        if (ch == SILENT) { silent(cx, cy, t, expr); g = null; return; }
        Look lk = look(ch);
        float breath = (float) Math.sin((t + seed * 31) * 0.045) * 1.5F;
        Pen p = new Pen(cx, cy + Math.round(breath), lk.k);
        float sway = (float) Math.sin((t + seed * 17) * 0.05) * 1.6F;
        boolean blink = ((t + seed * 53) % 210) < 7 && (expr == N || expr == SAD || expr == BLANK);

        // --- back hair
        p.e(0, 0, 45, 47, lk.hairDark);
        if (lk.longHair) {
            p.p(lk.hairDark, -42, -4, -52, 80, -46 + sway, 170, 46 + sway, 170, 52, 80, 42, -4);
        } else if (ch == YUNA) {
            p.p(lk.hairDark, -42, 0, -44, 56 + sway, -30, 62, 30, 62, 44, 56 + sway, 42, 0);
        } else {
            p.p(lk.hairDark, -41, 0, -42, 40 + sway, -30, 44, 30, 44, 42, 40 + sway, 41, 0);
        }
        // --- body: a sailor uniform (a white yukata-like dress for Hikari)
        float shy = 44;
        p.p(lk.cloth, -13, shy - 4, 13, shy - 4, 30, shy + 1, 44, shy + 12, 52, shy + 32, 50, shy + 140, -50, shy + 140, -52, shy + 32, -44, shy + 12, -30, shy + 1);
        p.p(A(lk.clothDark, 140), 24, shy + 20, 52, shy + 32, 50, shy + 140, 34, shy + 140);
        if (ch == HIKARI) {
            p.p(lk.clothDark, -24, shy + 2, 0, shy + 34, 24, shy + 2, 13, shy - 4, -13, shy - 4);
            p.p(lk.accent, 0, shy + 22, -13, shy + 13, -13, shy + 32);
            p.p(lk.accent, 0, shy + 22, 13, shy + 13, 13, shy + 32);
            p.e(0, shy + 24, 4, 4, Gfx.darker(lk.accent, 0.3F));
        } else {
            p.p(lk.clothDark, -34, shy + 6, -13, shy - 4, 0, shy + 24, 13, shy - 4, 34, shy + 6, 20, shy + 48, 0, shy + 34, -20, shy + 48);
            p.l(-34, shy + 6, -20, shy + 48, 1.6F, 0xFFFFFFFF); p.l(34, shy + 6, 20, shy + 48, 1.6F, 0xFFFFFFFF);
            p.l(-31, shy + 10, -18, shy + 45, 1F, 0xFFE8E8F8); p.l(31, shy + 10, 18, shy + 45, 1F, 0xFFE8E8F8);
            // the ribbon (a tie for Asuka)
            if (ch == ASUKA) {
                p.p(lk.accent, -5, shy + 24, 5, shy + 24, 8, shy + 70, 0, shy + 80, -8, shy + 70);
            } else {
                p.p(lk.accent, 0, shy + 30, -17, shy + 20, -18, shy + 42);
                p.p(lk.accent, 0, shy + 30, 17, shy + 20, 18, shy + 42);
                p.e(0, shy + 30, 4, 4, A(lk.accent, 255));
                p.p(Gfx.darker(lk.accent, 0.3F), -1, shy + 34, 1, shy + 34, 6, shy + 62, -6, shy + 62);
            }
        }
        // --- neck
        p.r(-8, 28, 16, 24, lk.skinShade);
        p.r(-8, 28, 16, 6, A(0xFF000000, 28));
        // --- face
        p.e(-35, 8, 5, 8, lk.skin); p.e(35, 8, 5, 8, lk.skin);                                   // ears
        p.e(0, 2, 36, 33, lk.skin);
        p.e(0, 14, 31, 24, lk.skin);
        p.e(-26, 24, 9, 6, A(lk.skinShade, 45)); p.e(26, 24, 9, 6, A(lk.skinShade, 45));          // soft cheeks
        p.e(0, 12, 1, 1, lk.skinShade);                                                            // the nose
        if (lk.glasses) {                                                                         // frames are behind the eyes
            p.e(-16, 9, 16.5F, 15, 0xFF4A5478); p.e(16, 9, 16.5F, 15, 0xFF4A5478);
            p.e(-16, 9, 14.8F, 13.3F, lk.skin); p.e(16, 9, 14.8F, 13.3F, lk.skin);
            p.l(-1, 7, 1, 7, 1.8F, 0xFF4A5478);
            p.l(-32, 7, -37, 5, 1.4F, 0xFF4A5478); p.l(32, 7, 37, 5, 1.4F, 0xFF4A5478);
        }
        // --- eyes and the rest of the face
        face(p, lk, expr, t, blink, talking, seed);
        // --- front hair
        fringe(p, lk, sway, expr);
        if (lk.ribbon) {                                                                          // a red bow in the hair
            p.p(lk.accent, -30, -30, -48, -42, -46, -20);
            p.p(lk.accent, -30, -30, -14, -46, -12, -22);
            p.e(-30, -30, 4, 4, Gfx.darker(lk.accent, 0.25F));
        }
        if (lk.pin) {                                                                             // a cicada-shaped hairpin
            p.e(26, -18, 6, 3, 0xFF6A7AA0); p.e(22, -21, 4, 2, A(0xFFE8F4FF, 200)); p.e(30, -21, 4, 2, A(0xFFE8F4FF, 200));
        }
        if (lk.longHair) {                                                                        // locks in front of the shoulders
            p.p(lk.hair, -36, 8, -46, 60, -47 + sway, 124, -34 + sway, 130, -30, 60, -28, 14);
            p.p(lk.hair, 36, 8, 46, 60, 47 + sway, 124, 34 + sway, 130, 30, 60, 28, 14);
            p.l(-42, 40, -44 + sway, 110, 1.4F, A(lk.hairHi, 130)); p.l(42, 40, 44 + sway, 110, 1.4F, A(lk.hairHi, 130));
        }
        if (expr == BLANK || expr == CRAZED) {                                                    // a shadow from the hair falls on the eyes
            int sa = expr == CRAZED ? 70 : 58;
            p.e(0, 4, 30, 13, A(0xFF1A0820, sa)); p.e(0, 2, 28, 9, A(0xFF1A0820, sa)); p.e(0, 0, 25, 6, A(0xFF1A0820, sa));
        }
        if (expr == SCARED) {                                                                     // cold sweat and gloom lines
            for (int i = 0; i < 4; i++) p.r(-24 + i * 13, -30, 2, 14 + (i % 2) * 4, A(0xFF3A4C9A, 140));
            p.p(0xFFA8E4FF, 36, -22, 40, -12, 36, -6, 32, -12);
        }
        g = null;
    }

    private static void face(Pen p, Look lk, int expr, int t, boolean blink, boolean talking, int seed) {
        int dark = 0xFF2A1828;
        int brow = Gfx.darker(lk.hair, 0.1F);
        for (int s = -1; s <= 1; s += 2) {
            float ex = s * 16, ey = 9;
            float jx = expr == CRAZED ? (float) Math.sin(t * 0.7 + s) * 0.8F : 0;
            // eyebrows
            float bi = expr == SAD ? -3 : expr == SCARED ? -2 : expr == CRAZED ? 3 : 0;      // the inner end is higher (sad) or lower (angry)
            float by = expr == SCARED ? -22 : -17;
            p.l(ex - s * 7, by - bi * 0.8F, ex + s * 7, by + bi * 0.8F, 1.6F, brow);
            Pen q = new Pen(p.x(ex), p.y(ey), p.k * 1.15F);
            if (blink || expr == SMILE) {
                // closed: a happy arc (smile) or a quiet line (blink)
                if (expr == SMILE) {
                    q.l(0 - 9, 0 + 4, 0 - 4, 0 - 2, 2.2F, dark); q.l(0 - 4, 0 - 2, 0 + 4, 0 - 2, 2.2F, dark); q.l(0 + 4, 0 - 2, 0 + 9, 0 + 4, 2.2F, dark);
                    q.e(0 + s * 2, 0 + 14, 8, 4, A(0xFFFF6A86, 90));
                } else {
                    q.l(0 - 9, 0 + 3, 0, 0 + 6, 2.2F, dark); q.l(0, 0 + 6, 0 + 9, 0 + 3, 2.2F, dark);
                    q.l(0 + s * 9, 0 + 3, 0 + s * 13, 0 + 1, 1.6F, dark);
                }
                continue;
            }
            float rx = expr == SCARED || expr == CRAZED ? 10.5F : 9, ry = expr == SCARED || expr == CRAZED ? 13 : 11;
            q.e(0, 0, rx + 1, ry + 1, dark);
            q.e(0, 0 + 1, rx - 0.5F, ry - 0.5F, 0xFFFFFFFF);
            if (expr == BLANK) {                                                              // an empty, flat eye: no light in it at all
                q.e(0 + jx, 0 + 2, 7, 9, Gfx.darker(lk.eyeDark, 0.55F));
                q.e(0 + jx, 0 + 2, 3, 4, 0xFF05030A);
            } else if (expr == SCARED) {
                q.e(0, 0 + 1, 5, 6, lk.eye); q.e(0, 0 + 1, 2, 3, 0xFF100810);
                q.e(0 - 2, 0 - 2, 1.4F, 1.4F, 0xFFFFFFFF);
            } else if (expr == CRAZED) {
                q.e(0 + jx, 0 + 1, 4, 5, 0xFFC81428); q.e(0 + jx, 0 + 1, 1.5F, 2, 0xFF100408);
                q.e(0 + jx - 1, 0 - 1, 1, 1, 0xFFFFFFFF);
            } else {
                int sh = expr == SAD ? 2 : 0;
                q.e(0, 0 + 2 + sh, 7, 9, lk.eyeDark);
                q.e(0, 0 + 5 + sh, 5.5F, 6, lk.eye);
                q.e(0, 0 + 8 + sh, 4, 3, lk.eyeLight);
                q.e(0, 0 + 2 + sh, 3, 5, 0xFF1A1020);
                q.e(0 - 3, 0 - 2 + sh, 2.8F, 3.2F, 0xFFFFFFFF);
                q.e(0 + 2.5F, 0 + 6 + sh, 1.6F, 1.6F, A(0xFFFFFFFF, 220));
            }
            // the upper lid and the lashes
            q.p(dark, 0 - 11, 0 - 1, 0 - 8, 0 - 9, 0, 0 - 13, 0 + 8, 0 - 9, 0 + 11, 0 - 1, 0 + 8, 0 - 7, 0, 0 - 10, 0 - 8, 0 - 7);
            q.p(dark, 0 + s * 10, 0 - 4, 0 + s * 16, 0 - 8, 0 + s * 11, 0 + 1);
            if (expr == SAD) q.p(lk.skinShade, 0 - 10, 0 - 9, 0 + 10, 0 - 9, 0 + 10, 0 - 3, 0 - 10, 0 - 4);
            if (expr == SAD && s == 1) q.e(0 + 4, 0 + 16, 2, 5, A(0xFFB8E4FF, 200));
            if (expr == SCARED || expr == CRAZED) q.p(A(0xFF000000, 60), 0 - 12, 0 + 12, 0, 0 + 15, 0 + 12, 0 + 12, 0, 0 + 18);
        }
        p.e(-23, 20, 7, 3.5F, A(0xFFFF7A90, expr == BLANK || expr == CRAZED ? 0 : 55)); p.e(23, 20, 7, 3.5F, A(0xFFFF7A90, expr == BLANK || expr == CRAZED ? 0 : 55));
        // the mouth
        boolean open = talking && (t / 5) % 2 == 0;
        switch (expr) {
            case SMILE -> {
                if (open || (t / 90 + seed) % 5 == 0) { p.e(0, 27, 7, 4.5F, 0xFF8A2438); p.r(-5, 23, 10, 2, 0xFFFFFFFF); p.e(0, 29, 4, 2, 0xFFFF8AA0); }
                else { p.l(-7, 25, -2, 28, 1.8F, 0xFF8A2438); p.l(-2, 28, 2, 28, 1.8F, 0xFF8A2438); p.l(2, 28, 7, 25, 1.8F, 0xFF8A2438); }
            }
            case SAD -> {
                if (open) p.e(0, 28, 3, 2.5F, 0xFF8A2438);
                else { p.l(-5, 29, 0, 26, 1.6F, 0xFF8A2438); p.l(0, 26, 5, 29, 1.6F, 0xFF8A2438); }
            }
            case SCARED -> p.e(0, 28, 3.5F, open ? 6 : 4.5F, 0xFF5A1426);
            case BLANK -> {
                p.l(-7, 28, 7, 28, 1.4F, 0xFF5A1426);
                p.e(0, 8, 31, 36, A(0xFF3A4C9A, 22));                                           // the face is a little too pale
            }
            case CRAZED -> {                                                                    // a grin that is too wide
                p.p(0xFF4A0814, -17, 21, 0, 27, 17, 21, 15, 30, 0, 42, -15, 30);
                p.p(0xFFFFFFFF, -13, 24, 0, 29, 13, 24, 12, 28, 0, 33, -12, 28);
                for (int i = -2; i <= 2; i++) p.r(i * 5 - 0.5F, 26, 1, 6, A(0xFF4A0814, 160));
            }
            default -> {
                if (open) p.e(0, 27, 3.5F, 3, 0xFF8A2438);
                else { p.l(-4, 28, 4, 28, 1.6F, 0xFF8A2438); }
            }
        }
    }

    private static void fringe(Pen p, Look lk, float sway, int expr) {
        // the top of the head and the fringe
        int n = 13; float[] pts = new float[(n + 14) * 2]; int c = 0;
        for (int i = 0; i < n; i++) {
            double a = Math.PI + i * Math.PI / (n - 1);
            pts[c++] = (float) Math.cos(a) * 43; pts[c++] = -4 + (float) Math.sin(a) * 43;
        }
        float[] fr;
        if (lk.blunt && !lk.longHair) {          // Hikari: a straight, blunt fringe
            fr = new float[]{37, -4, 30, -3, 24, -8, 16, -3, 8, -8, 0, -3, -8, -8, -16, -3, -24, -8, -30, -3, -37, -4};
        } else if (lk.longHair) {                // Asuka: a straight fringe with a tiny parting
            fr = new float[]{38, 4, 34, -6, 22, -2, 12, -8, 4, -4, 0, -10, -4, -4, -12, -8, -22, -2, -34, -6, -38, 4};
        } else {                                 // Yuna: swept bangs with a few loose locks
            fr = new float[]{38, 8, 33, -10, 24, 0, 18, -16, 10, -2, 4, -14, -2, -4, -9, -16, -17, -2, -24, -14, -30, -2, -38, 6};
        }
        for (float v : fr) pts[c++] = v;
        float[] use = java.util.Arrays.copyOf(pts, c);
        p.p(lk.hair, use);
        // light bands on the hair
        p.p(A(lk.hairHi, 150), -26, -34, -10, -40, -2, -38, -16, -30);
        p.p(A(lk.hairHi, 110), 8, -41, 24, -34, 18, -32, 6, -38);
        // the locks at the sides of the face
        float ls = lk.longHair ? 80 : 32;
        p.p(lk.hair, -34, -8, -45, -2, -44, ls * 0.6F, -39 + sway * 0.3F, ls, -35, ls * 0.5F);
        p.p(lk.hair, 34, -8, 45, -2, 44, ls * 0.6F, 39 + sway * 0.3F, ls, 35, ls * 0.5F);
        // a shadow under the fringe
        p.e(0, -3, 28, 4, A(lk.skinShade, 70));
    }

    /** The bus driver / the thing without a face. */
    private static void silent(int cx, int cy, int t, int expr) {
        Pen p = new Pen(cx, cy, 1.2F);
        p.p(0xFF14101C, -16, 40, 16, 40, 70, 60, 92, 100, 96, 150, -96, 150, -92, 100, -70, 60);
        p.p(0xFFE8E4EC, -14, 40, 14, 40, 0, 86);
        p.p(0xFF6A1018, -4, 50, 4, 50, 6, 100, 0, 110, -6, 100);
        p.r(-8, 28, 16, 16, 0xFFD8D2DC);
        p.e(0, 0, 25, 30, 0xFFE6E2EA);                         // a pale face with nothing on it
        p.p(0xFFB8B0C0, -22, 12, 22, 12, 8, 32, -8, 32);
        p.p(0xFF14101C, -34, -10, 34, -10, 30, -34, 0, -44, -30, -34);   // a cap
        p.r(-38, -12, 76, 6, 0xFF0A0810);
        int eye = expr == CRAZED || expr == BLANK ? 0xFFC81428 : 0xFF0A0810;
        p.e(-9, 2, 2, 3, eye); p.e(9, 2, 2, 3, eye);
        p.l(-9, 20, 0, 23, 1.2F, 0xFF3A2030); p.l(0, 23, 9, 20, 1.2F, 0xFF3A2030);
        if (expr == CRAZED || expr == BLANK) Gfx.glow(g, p.x(0), p.y(2), 22, 0xFFFF2A2A, 60 + (int) (30 * Math.sin(t * 0.2)));
    }

    // ================================================================== effects
    /** Glitch bars: thin strips of the picture shifted sideways, drawn as coloured slices. */
    static void glitch(GuiGraphics gr, int t, int strength) {
        g = gr;
        int n = 3 + strength / 20;
        for (int i = 0; i < n; i++) {
            int y = (int) (h(t / 2, i * 7 + 1) * H), hh = 2 + (int) (h(t / 2, i * 7 + 2) * 10);
            int x = (int) (h(t / 2, i * 7 + 3) * (W - 120)), w = 40 + (int) (h(t / 2, i * 7 + 4) * 200);
            int col = i % 3 == 0 ? 0xFFFF2A4A : i % 3 == 1 ? 0xFF2AF0FF : 0xFFFFFFFF;
            R(x, y, w, hh, A(col, 40 + (int) (h(t / 2, i * 7 + 5) * 60)));
        }
        g = null;
    }

    /** Eyes in the dark corners. */
    static void watchers(GuiGraphics gr, int t) {
        g = gr;
        int phase = (t / 90) % 4;
        if ((t % 90) < 70) {
            int[][] pos = {{40, 36}, {392, 60}, {30, 150}, {400, 130}};
            int ex = pos[phase][0], ey = pos[phase][1];
            int a = (t % 90) < 10 ? (t % 90) * 20 : 200;
            Gfx.glow(g, ex, ey, 10, 0xFFFF1A2A, a / 2);
            E(ex - 8, ey, 4, 2, A(0xFFFF3040, a)); E(ex + 8, ey, 4, 2, A(0xFFFF3040, a));
        }
        g = null;
    }
}
