package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;

/** Slide the cubes, merge equal numbers (2048 style). */
public class MergeCubes extends MiniGame {
    private static final int N = 4, CELL = 32, GAP = 2;
    private static final int BOARD = N * CELL + (N + 1) * GAP;
    private static final int BX = (W - BOARD) / 2, BY = (H - BOARD) / 2;

    private final int[][] b = new int[N][N];

    @Override
    public void reset() {
        score = 0; over = false;
        for (int[] row : b) java.util.Arrays.fill(row, 0);
        spawn();
        spawn();
    }

    private void spawn() {
        int empty = 0;
        for (int[] row : b) for (int v : row) if (v == 0) empty++;
        if (empty == 0) return;
        int pick = rnd.nextInt(empty);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (b[i][j] != 0) continue;
                if (pick-- == 0) { b[i][j] = rnd.nextInt(10) == 0 ? 4 : 2; return; }
            }
        }
    }

    /** Slides one line to the front and merges pairs. Result: 4 cells + gained score at index 4. */
    static int[] slide(int[] line) {
        int[] out = new int[N + 1];
        int pos = 0, gain = 0;
        int last = 0;
        for (int v : line) {
            if (v == 0) continue;
            if (last != 0 && last == v) {
                out[pos - 1] = v * 2;
                gain += v * 2;
                last = 0;
            } else {
                out[pos++] = v;
                last = v;
            }
        }
        out[N] = gain;
        return out;
    }

    private int get(int dir, int i, int j) {
        return switch (dir) {
            case 0 -> b[i][j];
            case 1 -> b[i][N - 1 - j];
            case 2 -> b[j][i];
            default -> b[N - 1 - j][i];
        };
    }

    private void set(int dir, int i, int j, int v) {
        switch (dir) {
            case 0 -> b[i][j] = v;
            case 1 -> b[i][N - 1 - j] = v;
            case 2 -> b[j][i] = v;
            default -> b[N - 1 - j][i] = v;
        }
    }

    private boolean move(int dir) {
        boolean moved = false;
        for (int i = 0; i < N; i++) {
            int[] line = new int[N];
            for (int j = 0; j < N; j++) line[j] = get(dir, i, j);
            int[] out = slide(line);
            for (int j = 0; j < N; j++) {
                if (out[j] != line[j]) moved = true;
                set(dir, i, j, out[j]);
            }
            if (out[N] > 0) { score += out[N]; pling(0.9F + Math.min(1.0F, out[N] / 512F)); }
        }
        return moved;
    }

    private boolean canMove() {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (b[i][j] == 0) return true;
                if (i + 1 < N && b[i][j] == b[i + 1][j]) return true;
                if (j + 1 < N && b[i][j] == b[i][j + 1]) return true;
            }
        }
        return false;
    }

    @Override
    public boolean key(int k) {
        int dir = switch (k) {
            case KEY_LEFT, 65 -> 0;
            case KEY_RIGHT, 68 -> 1;
            case KEY_UP, 87 -> 2;
            case KEY_DOWN, 83 -> 3;
            default -> -1;
        };
        if (dir < 0) return false;
        if (move(dir)) {
            spawn();
            if (!canMove()) over = true;
        }
        return true;
    }

    @Override
    public void tick() {}

    private static int color(int v) {
        return switch (v) {
            case 0 -> 0xFFDCCFE8;
            case 2 -> 0xFFFFE3F1;
            case 4 -> 0xFFFFC9E0;
            case 8 -> 0xFFF58FB8;
            case 16 -> 0xFFF5A623;
            case 32 -> 0xFFF3D46A;
            case 64 -> 0xFF8FD39A;
            case 128 -> 0xFF5BBF6A;
            case 256 -> 0xFF8EC3F2;
            case 512 -> 0xFF2F7FD6;
            case 1024 -> 0xFFB57BD6;
            default -> 0xFF4A3A66;
        };
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFFF8F0FC, 0xFFE6D8F0);
        for (int i = 0; i < 12; i++) Gfx.heart(g, (int) (Gfx.hash(i, 20) * (W - 8)), (int) (Gfx.hash(i, 21) * (H - 8)), 0x14C06AA0);
        Gfx.shadow(g, BX, BY, BOARD, BOARD, 4);
        Gfx.rrect(g, BX - 1, BY - 1, BOARD + 2, BOARD + 2, 5, 0xFFA894BC);
        Gfx.rrect(g, BX, BY, BOARD, BOARD, 4, 0xFFC9B8D8);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                int x = BX + GAP + j * (CELL + GAP), y = BY + GAP + i * (CELL + GAP);
                int v = b[i][j];
                if (v == 0) { Gfx.rrect(g, x, y, CELL, CELL, 4, 0xFFDCCFE8); continue; }
                int col = color(v);
                Gfx.shadow(g, x, y, CELL, CELL, 4);
                Gfx.bubble(g, x, y, CELL, CELL, 4, col);
                if (v >= 128) Gfx.glow(g, x + CELL / 2, y + CELL / 2, CELL / 2 + 3, Gfx.lighter(col, 0.4f), 60);
                boolean dark = v <= 4 || v == 32;
                String s = String.valueOf(v);
                int ty = y + CELL / 2 - 4;
                if (!dark) ctext(g, s, x + CELL / 2 + 1, ty + 1, 0x44000000);
                ctext(g, s, x + CELL / 2, ty, dark ? 0xFF3A2A3A : 0xFFFFFFFF);
            }
        }
    }

    @Override
    public String hintKey() { return "cutemod.hint.cubes"; }
}
