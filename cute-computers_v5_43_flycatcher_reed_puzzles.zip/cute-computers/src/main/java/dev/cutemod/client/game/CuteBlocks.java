package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Falling blocks. Arrow keys / mouse move, Up or left click rotates, Down drops softly, Space or right click drops. */
public class CuteBlocks extends MiniGame {
    private static final int COLS = 10, ROWS = 14, CELL = 9, BX = 64, BY = 7;
    private static final int[][][] SHAPES = {
            {{-1, 0}, {0, 0}, {1, 0}, {2, 0}},   // I
            {{0, 0}, {1, 0}, {0, 1}, {1, 1}},    // O
            {{-1, 0}, {0, 0}, {1, 0}, {0, 1}},   // T
            {{0, 0}, {1, 0}, {-1, 1}, {0, 1}},   // S
            {{-1, 0}, {0, 0}, {0, 1}, {1, 1}},   // Z
            {{-1, 0}, {0, 0}, {1, 0}, {-1, 1}},  // J
            {{-1, 0}, {0, 0}, {1, 0}, {1, 1}}};  // L
    private static final int[] COLORS = {0xFF8EC3F2, 0xFFF3D46A, 0xFFB57BD6, 0xFF8FD39A, 0xFFE27B72, 0xFF6A8FE0, 0xFFF5B06B};

    private final int[][] grid = new int[ROWS][COLS];
    private final int[][] cur = new int[4][2];
    private int type, nextType, px, py, fall, lines, level, lastMx, moveT;
    private boolean mouseMode;

    @Override
    public void reset() {
        score = 0; over = false; lines = 0; level = 1; lastMx = mx; mouseMode = false; moveT = 0;
        for (int[] row : grid) java.util.Arrays.fill(row, 0);
        nextType = rnd.nextInt(7);
        spawn();
    }

    private void spawn() {
        type = nextType;
        nextType = rnd.nextInt(7);
        for (int i = 0; i < 4; i++) { cur[i][0] = SHAPES[type][i][0]; cur[i][1] = SHAPES[type][i][1]; }
        px = 4; py = 0; fall = 0;
        if (collides(cur, px, py)) over = true;
    }

    private boolean collides(int[][] shape, int ox, int oy) {
        for (int[] c : shape) {
            int x = ox + c[0], y = oy + c[1];
            if (x < 0 || x >= COLS || y >= ROWS) return true;
            if (y >= 0 && grid[y][x] != 0) return true;
        }
        return false;
    }

    private void rotate() {
        if (type == 1) return;
        int[][] r = new int[4][2];
        for (int i = 0; i < 4; i++) { r[i][0] = -cur[i][1]; r[i][1] = cur[i][0]; }
        for (int kick : new int[]{0, -1, 1, -2, 2}) {
            if (!collides(r, px + kick, py)) {
                for (int i = 0; i < 4; i++) { cur[i][0] = r[i][0]; cur[i][1] = r[i][1]; }
                px += kick;
                beep();
                return;
            }
        }
    }

    private void move(int dx) {
        if (!collides(cur, px + dx, py)) px += dx;
    }

    private void lock() {
        for (int[] c : cur) {
            int x = px + c[0], y = py + c[1];
            if (y >= 0) grid[y][x] = type + 1;
        }
        int cleared = 0;
        for (int y = ROWS - 1; y >= 0; y--) {
            boolean full = true;
            for (int x = 0; x < COLS; x++) if (grid[y][x] == 0) { full = false; break; }
            if (full) {
                cleared++;
                for (int yy = y; yy > 0; yy--) grid[yy] = grid[yy - 1].clone();
                grid[0] = new int[COLS];
                y++;
            }
        }
        if (cleared > 0) {
            lines += cleared;
            score += new int[]{0, 10, 30, 60, 100}[cleared] * level;
            level = lines / 5 + 1;
            pling(1.2F + cleared * 0.15F);
        } else {
            beep();
        }
        spawn();
    }

    private boolean stepDown() {
        if (!collides(cur, px, py + 1)) { py++; return true; }
        lock();
        return false;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return true;
        if (button == 1) hardDrop(); else rotate();
        return true;
    }

    private void hardDrop() {
        int d = 0;
        while (!collides(cur, px, py + 1)) { py++; d++; }
        score += d;
        lock();
    }

    @Override
    public boolean key(int k) {
        if (over) return false;
        mouseMode = false;
        switch (k) {
            case KEY_LEFT, 65 -> move(-1);
            case KEY_RIGHT, 68 -> move(1);
            case KEY_UP, 87 -> rotate();
            case KEY_DOWN, 83 -> { if (stepDown()) score++; fall = 0; }
            case KEY_SPACE -> hardDrop();
            default -> { return false; }
        }
        return true;
    }

    @Override
    public void tick() {
        if (over) return;
        if (mx != lastMx) { mouseMode = true; lastMx = mx; }
        if (mouseMode && ++moveT >= 3) {
            moveT = 0;
            int col = (mx - BX) / CELL;
            if (col < px) move(-1); else if (col > px) move(1);
        }
        if (++fall >= Math.max(6, 40 - level * 4)) { fall = 0; stepDown(); }
    }

    private static int mix(int rgb, int target, float f) {
        int r = (int) (((rgb >> 16) & 255) * (1 - f) + ((target >> 16) & 255) * f);
        int gr = (int) (((rgb >> 8) & 255) * (1 - f) + ((target >> 8) & 255) * f);
        int b = (int) ((rgb & 255) * (1 - f) + (target & 255) * f);
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }

    private void cell(GuiGraphics g, int x, int y, int color, boolean ghost) {
        if (ghost) {                                   // the landing spot: faint fill and a thin outline
            rect(g, x + 1, y + 1, CELL - 2, CELL - 2, Gfx.alpha(color, 0x2A));
            Gfx.outline(g, x, y, CELL, CELL, Gfx.alpha(color, 0xB0));
            return;
        }
        // a glossy little cube: dark rim, gradient face, bright top-left, shade at the bottom
        rect(g, x, y, CELL, CELL, Gfx.darker(0xFF000000 | color, 0.45f));
        g.fillGradient(x + 1, y + 1, x + CELL - 1, y + CELL - 1, Gfx.lighter(0xFF000000 | color, 0.18f), Gfx.darker(0xFF000000 | color, 0.12f));
        rect(g, x + 1, y + 1, CELL - 2, 1, 0xAAFFFFFF);
        rect(g, x + 1, y + 1, 1, CELL - 2, 0x66FFFFFF);
        rect(g, x + 2, y + 2, 2, 2, 0x55FFFFFF);
        rect(g, x + 1, y + CELL - 2, CELL - 2, 1, 0x30000000);
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF2A2250, 0xFF150E2E);
        Gfx.glow(g, 112, 70, 62, 0xFF6A4AC0, 40);
        for (int i = 0; i < 18; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 32) * W), (int) (Gfx.hash(i, 33) * H), 1, i * 21, 0x88FFFFFF);
        // the well: a framed panel with a dark gradient and a faint grid
        Gfx.panel(g, BX - 3, BY - 3, COLS * CELL + 6, ROWS * CELL + 6, 0xFF7A68B8, 0xFF3E2F78);
        g.fillGradient(BX, BY, BX + COLS * CELL, BY + ROWS * CELL, 0xFF171032, 0xFF0A0618);
        for (int x = 1; x < COLS; x++) rect(g, BX + x * CELL, BY, 1, ROWS * CELL, 0x14FFFFFF);
        for (int y = 1; y < ROWS; y++) rect(g, BX, BY + y * CELL, COLS * CELL, 1, 0x14FFFFFF);
        for (int y = 0; y < ROWS; y++) {
            for (int x = 0; x < COLS; x++) if (grid[y][x] != 0) cell(g, BX + x * CELL, BY + y * CELL, COLORS[grid[y][x] - 1], false);
        }
        if (!over) {
            int gy = py;
            while (!collides(cur, px, gy + 1)) gy++;
            for (int[] c : cur) cell(g, BX + (px + c[0]) * CELL, BY + (gy + c[1]) * CELL, COLORS[type], true);
            for (int[] c : cur) if (py + c[1] >= 0) cell(g, BX + (px + c[0]) * CELL, BY + (py + c[1]) * CELL, COLORS[type], false);
        }
        // side panels
        Gfx.panel(g, 158, 4, 58, 50, 0xFF3A2E70, 0xFF241A4C);
        text(g, Component.translatable("cutemod.blocks.next").getString(), 164, 9, 0xFFD8C8FF);
        for (int[] c : SHAPES[nextType]) cell(g, 172 + c[0] * CELL, 27 + c[1] * CELL, COLORS[nextType], false);
        Gfx.panel(g, 3, 4, 56, 32, 0xFF3A2E70, 0xFF241A4C);
        text(g, Component.translatable("cutemod.blocks.level", level).getString(), 7, 9, 0xFFD8C8FF);
        text(g, Component.translatable("cutemod.blocks.lines", lines).getString(), 7, 22, 0xFFD8C8FF);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score", score); }

    @Override
    public String hintKey() { return "cutemod.hint.blocks"; }
}
