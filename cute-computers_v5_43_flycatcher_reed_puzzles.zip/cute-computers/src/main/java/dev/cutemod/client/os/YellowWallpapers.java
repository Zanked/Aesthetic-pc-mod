package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Three yellow wallpapers for CuteMarket (numbers 48-50), made for the Sunny Chick look: a field of sunflowers swaying in the wind,
 * little chicks hopping on a sunny meadow and honey bubbles rising in a golden glow. Drawn from fractions of the box, so they fit the
 * tiny shop icon and the whole desktop alike, and they move. Clipped by hand like {@link NewWallpapers} (no scissor).
 */
final class YellowWallpapers {
    private static GuiGraphics gg;
    private static int bx, by, bw, bh, t;

    private YellowWallpapers() {}

    static void draw(GuiGraphics g, int x, int y, int w, int h, int idx) {
        gg = g; bx = x; by = y; bw = Math.max(1, w); bh = Math.max(1, h);
        t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        switch (idx) {
            case 48 -> sunflowers();
            case 49 -> chicks();
            default -> honeyBubbles();
        }
        gg = null;
    }

    // ---------- helpers ----------
    private static void r(int x0, int y0, int x1, int y1, int argb) {
        x0 = Math.max(x0, bx); y0 = Math.max(y0, by);
        x1 = Math.min(x1, bx + bw); y1 = Math.min(y1, by + bh);
        if (x1 > x0 && y1 > y0) gg.fill(x0, y0, x1, y1, argb);
    }

    private static void grad(int y0, int y1, int top, int bottom) {
        y0 = Math.max(y0, by); y1 = Math.min(y1, by + bh);
        if (y1 > y0) gg.fillGradient(bx, y0, bx + bw, y1, top, bottom);
    }

    private static void disc(int cx, int cy, int rad, int argb) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            r(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** A ring: the rim of a bubble. */
    private static void ring(int cx, int cy, int rad, int argb) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            if (Math.abs(dy) >= rad - 1) r(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
            else { r(cx - dx, cy + dy, cx - dx + 1, cy + dy + 1, argb); r(cx + dx, cy + dy, cx + dx + 1, cy + dy + 1, argb); }
        }
    }

    private static int px(double f) { return bx + (int) Math.round(bw * f); }

    private static int py(double f) { return by + (int) Math.round(bh * f); }

    /** One pixel unit: a hundredth of the height (at least 1). */
    private static int u(double n) { return Math.max(1, (int) Math.round(bh * n / 100.0)); }

    private static int hash(int n) {
        n ^= n >>> 15; n *= 0x2C1B3C6D; n ^= n >>> 12; n *= 0x297A2D39; n ^= n >>> 15;
        return n & 0x7FFFFFFF;
    }

    /** A soft sun: a pale glow and a bright disc. */
    private static void sun(double fx, double fy, int rad) {
        int cx = px(fx), cy = py(fy);
        disc(cx, cy, rad + u(10), 0x22FFFFFF);
        disc(cx, cy, rad + u(5), 0x44FFF6C0);
        disc(cx, cy, rad, 0xFFFFF3A0);
    }

    private static void cloud(int cx, int cy, int s) {
        r(cx - 5 * s, cy, cx + 5 * s, cy + 2 * s, 0xCCFFFFFF);
        r(cx - 3 * s, cy - s, cx + s, cy + s, 0xCCFFFFFF);
        r(cx - s, cy - 2 * s, cx + 3 * s, cy, 0xCCFFFFFF);
    }

    // ---------- 48: sunflowers ----------
    private static void sunflower(int cx, int baseY, int rad, int sway) {
        int stemW = Math.max(1, rad / 4);
        for (int k = 0; k < rad * 3; k++) {                                        // the stem leans with the wind, more at the top
            int off = Math.round(sway * (k / (float) (rad * 3)));
            r(cx - stemW / 2 + off, baseY - k, cx - stemW / 2 + off + stemW, baseY - k + 1, 0xFF4E9A3A);
        }
        int fx = cx + sway, fy = baseY - rad * 3;
        r(fx - rad / 2 - stemW - 1, baseY - rad - 1, fx - stemW, baseY - rad + 1, 0xFF5FB04A);   // a leaf
        for (int i = 0; i < 8; i++) {                                              // petals
            double a = i * Math.PI / 4 + 0.2;
            disc(fx + (int) Math.round(Math.cos(a) * rad), fy + (int) Math.round(Math.sin(a) * rad), Math.max(1, rad / 2), i % 2 == 0 ? 0xFFFFD21E : 0xFFFFE04A);
        }
        disc(fx, fy, Math.max(1, rad * 3 / 4), 0xFF8A4E12);
        disc(fx - rad / 4, fy - rad / 4, Math.max(1, rad / 4), 0xFFB87A2A);
    }

    private static void sunflowers() {
        grad(by, by + bh, 0xFFFFE27A, 0xFFFFF8D8);
        sun(0.8, 0.2, u(9));
        cloud(px(0.25), py(0.16), u(2.2));
        cloud(px(0.58), py(0.3), u(1.6));
        int hz = py(0.55);
        for (int cx = 0; cx < bw; cx++) {                                          // far hills
            int top = hz + (int) Math.round(Math.sin(cx / (bw / 5.0) + 1) * bh * 0.03);
            r(bx + cx, top, bx + cx + 1, by + bh, 0xFFD9D860);
        }
        for (int row = 0; row < 3; row++) {                                        // three rows of flowers, the far ones are small
            double f = 0.62 + row * 0.15;
            int baseY = py(f + 0.14), rad = u(2.6 + row * 1.9);
            int step = Math.max(rad * 4, bw / (6 + (2 - row)));
            for (int i = -1; i * step < bw + step; i++) {
                int cx = bx + i * step + (row * 37 + 11) % step / 2 + step / 2;
                int sway = (int) Math.round(Math.sin(t * 0.05 + i * 0.9 + row) * Math.max(1, rad / 2));
                r(cx - step / 2, baseY - 1, cx + step / 2, by + bh, row == 2 ? 0xFF8FB842 : 0xFFB5C94E);   // the grass under the row
                sunflower(cx, baseY, rad, sway);
            }
        }
        r(bx, py(0.93), bx + bw, by + bh, 0xFF7FAE3A);
    }

    // ---------- 49: chicks ----------
    private static void chick(int cx, int cy, int s, int phase) {
        int hop = (int) Math.round(Math.abs(Math.sin(t * 0.12 + phase)) * s * 3);
        boolean flip = (phase & 1) == 1;
        int d = flip ? -1 : 1;
        cy -= hop;
        r(cx - s * 2, cy + s * 3 + hop, cx + s * 3, cy + s * 3 + hop + 1, 0x30A06010);        // a small shadow on the grass
        disc(cx, cy, s * 3, 0xFFFFD84A);                                                      // the body
        disc(cx - d * s, cy + s, s * 2, 0xFFFFC21E);                                          // the wing
        int hx = cx + d * s * 2, hy = cy - s * 3;
        disc(hx, hy, s * 2 + s / 2, 0xFFFFE05A);                                              // the head
        r(hx - s, hy - s * 4, hx - s + Math.max(1, s / 2) , hy - s * 2, 0xFFFFC21E);          // a tuft
        r(hx, hy - s * 4 + s / 2, hx + Math.max(1, s / 2), hy - s * 2, 0xFFFFC21E);
        int bxl = d > 0 ? hx + s * 2 : hx - s * 2 - s * 2;
        r(bxl, hy, bxl + s * 2, hy + Math.max(1, s), 0xFFFF8A00);                             // the beak
        r(hx + d * s - (d < 0 ? 0 : 0), hy - s, hx + d * s + Math.max(1, s / 2), hy - s + Math.max(1, s), 0xFF3A2208);   // the eye
        r(hx - d * s - s, hy + s / 2, hx - d * s + Math.max(0, s / 2), hy + s / 2 + Math.max(1, s / 2), 0x88FF8CA0);      // a cheek
        r(cx - s, cy + s * 3, cx - s + Math.max(1, s / 2), cy + s * 4 + (hop > 0 ? 1 : 0), 0xFFFF8A00);   // feet
        r(cx + s, cy + s * 3, cx + s + Math.max(1, s / 2), cy + s * 4 + (hop > 0 ? 1 : 0), 0xFFFF8A00);
    }

    private static void chicks() {
        grad(by, by + bh, 0xFFFFE680, 0xFFFFF6C8);
        sun(0.2, 0.2, u(8));
        cloud(px(0.55), py(0.14), u(2));
        cloud(px(0.82), py(0.3), u(1.5));
        int hz = py(0.5);
        r(bx, hz, bx + bw, by + bh, 0xFFF5DC5C);
        grad(hz, by + bh, 0xFFF2E070, 0xFFE6C23E);
        for (int i = 0; i < 26; i++) {                                                // little tufts of grass
            int gx = bx + hash(i * 7 + 3) % bw, gy = hz + u(4) + hash(i * 13 + 5) % Math.max(1, by + bh - hz - u(6));
            r(gx, gy - u(2), gx + 1, gy, 0xFF8FB842); r(gx + u(1.5), gy - u(3), gx + u(1.5) + 1, gy, 0xFF8FB842); r(gx - u(1.5), gy - u(2), gx - u(1.5) + 1, gy, 0xFF8FB842);
        }
        for (int i = 0; i < 9; i++) {                                                 // daisies
            int fx = bx + hash(i * 17 + 1) % bw, fy = hz + u(6) + hash(i * 29 + 2) % Math.max(1, by + bh - hz - u(10));
            r(fx - 1, fy, fx + 2, fy + 1, 0xFFFFFFFF); r(fx, fy - 1, fx + 1, fy + 2, 0xFFFFFFFF); r(fx, fy, fx + 1, fy + 1, 0xFFFF9A2E);
        }
        int n = 6;
        for (int i = 0; i < n; i++) {                                                 // the chicks, the near ones are bigger
            double row = (i % 3) / 2.0;
            int s = Math.max(1, u(1.4 + row * 1.5));
            int cx = bx + (int) (bw * (0.08 + 0.84 * ((i * 0.37 + 0.11) % 1.0))) + (int) Math.round(Math.sin(t * 0.03 + i) * u(2));
            int cy = py(0.66 + row * 0.2);
            chick(cx, cy, s, i * 5 + 1);
        }
    }

    // ---------- 50: honey bubbles ----------
    private static void honeyBubbles() {
        grad(by, by + bh, 0xFFFFD84A, 0xFFFF9A2E);
        int cx = px(0.5), cy = py(1.05);
        for (int k = 4; k >= 1; k--) disc(cx, cy, bh * k / 4 + (int) Math.round(Math.sin(t * 0.04) * u(1.5)), (0x1C << 24) | 0xFFF6C0);   // a warm glow from below
        for (int i = 0; i < 16; i++) {                                                // bubbles of honey light rising
            int rad = u(2 + (i * 5) % 7);
            int rise = (t * (1 + i % 3) / 4 + i * 47) % (bh + rad * 4);
            int by0 = by + bh + rad * 2 - rise;
            int bx0 = bx + rad + hash(i * 11 + 5) % Math.max(1, bw - rad * 2) + (int) Math.round(Math.sin(t * 0.04 + i) * u(2));
            disc(bx0, by0, rad, 0x22FFFFFF);
            ring(bx0, by0, rad, 0x88FFF6C0);
            r(bx0 - rad / 2, by0 - rad / 2, bx0 - rad / 2 + Math.max(1, rad / 3), by0 - rad / 2 + Math.max(1, rad / 3), 0xDDFFFFFF);
        }
        for (int i = 0; i < (bw < 80 ? 0 : 10); i++) {                                // twinkles (not on the tiny shop icon)
            int ph = (t + i * 23) % 50;
            if (ph > 8) continue;
            int sx = bx + hash(i * 7 + (t + i * 23) / 50) % bw, sy = by + hash(i * 3 + 1 + (t + i * 23) / 50) % bh;
            int s = ph < 4 ? 1 : 2;
            r(sx - s, sy, sx + s + 1, sy + 1, 0xFFFFFFFF); r(sx, sy - s, sx + 1, sy + s + 1, 0xFFFFFFFF);
        }
    }
}
