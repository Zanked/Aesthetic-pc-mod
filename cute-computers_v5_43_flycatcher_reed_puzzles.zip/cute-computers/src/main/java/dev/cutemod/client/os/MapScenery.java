package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.MapArt.mix;
import static dev.cutemod.client.os.MapArt.rect;
import static dev.cutemod.client.os.MapArt.tri;

/**
 * The houses at the back of the pet map: a far row behind the towers of the town, a row of little shops behind the promenade of
 * the boulevard and a far skyline behind the towers of Downtown. They are only scenery (nothing here is a place, nothing is
 * clickable) and they never move, so they are drawn into the still picture of the world (see {@link MapArt#pass}), once.
 * Every house is made of a few big rectangles, and every row is skipped when it is out of the view.
 * <p>
 * All the houses are made the same way and use the pastel colours of the towers of the town and of Downtown, but a bit paler
 * the further they stand, so the map reads as one town with depth and not as separate pieces.
 */
final class MapScenery {
    private MapScenery() {}

    /** The pastel colours of the town (the same as the towers): lilac, sky, pink, periwinkle, peach, mint, lavender, blue. */
    private static final int[] PASTEL = {0xFFC9B8EA, 0xFFA8D2E4, 0xFFF0BFD0, 0xFFB8C8F0, 0xFFFFD8B8, 0xFFB5E0C8, 0xFFD2BDF0, 0xFFA8CCEE};
    /** The roofs: rose, terracotta, slate blue, plum (a gable roof is a bit darker than its wall). */
    private static final int[] ROOF = {0xFFE0A0B8, 0xFFE0907A, 0xFF8AA0D0, 0xFFB090C8};

    private static int dark(int c, float f) { return mix(c, 0xFF000000, f); }

    private static int light(int c, float f) { return mix(c, 0xFFFFFFFF, f); }

    // =====================================================================================================
    //  one house: a wall with a shaded side, a roof edge (or a gable roof) and rows of small windows
    // =====================================================================================================
    /**
     * A house at the back. Its colours fade towards {@code fade} (the colour of the paving it stands on), so the far ones are paler;
     * {@code roof} < 0 is a flat roof with a light edge, otherwise the index of the gable roof colour; {@code seed} only varies the
     * little details (a stack, a water tank, a chimney, which windows are lit at night).
     */
    private static void house(GuiGraphics g, int x, int base, int w, int h, int wall, int roof, int fade, boolean night, int seed) {
        int c = mix(wall, fade, 0.34F);
        rect(g, x + 1, base - 1, w, 2, 0x1A000000);                                      // the foot in the shade
        rect(g, x, base - h, w, h, c);
        rect(g, x + w - 3, base - h, 3, h, dark(c, 0.1F));                                // the side in the shade
        rect(g, x, base - h, 2, h, light(c, 0.22F));                                      // the lit edge
        if (roof < 0) {
            rect(g, x - 1, base - h - 2, w + 2, 2, light(c, 0.5F)); rect(g, x - 1, base - h, w + 2, 1, dark(c, 0.16F));
            if (seed % 3 == 0) { rect(g, x + 2, base - h - 5, 2, 3, dark(c, 0.12F)); }    // a stack
            if (seed % 4 == 1) { rect(g, x + w - 6, base - h - 5, 4, 3, dark(c, 0.14F)); rect(g, x + w - 5, base - h - 6, 2, 1, dark(c, 0.14F)); }   // a water tank
        } else {
            int rc = mix(ROOF[roof % ROOF.length], fade, 0.3F), rh = Math.max(4, w / 3);
            tri(g, x + w / 2, base - h - rh, w + 4, rh, rc);
            rect(g, x - 2, base - h - 1, w + 4, 1, dark(rc, 0.2F));
            tri(g, x + w / 2 - 1, base - h - rh, Math.max(2, (w + 4) / 3), rh, light(rc, 0.22F));
            if (seed % 2 == 0) { rect(g, x + w - 5, base - h - rh + 1, 2, rh - 1, dark(c, 0.18F)); }   // a chimney
        }
        int cols = (w - 4) / 5, rows = (h - 6) / 7;
        for (int r = 0; r < rows; r++) for (int cc = 0; cc < cols; cc++) {
            boolean on = night && (seed * 5 + r * 11 + cc * 7) % 4 != 0;
            int wx = x + 3 + cc * 5, wy = base - h + 4 + r * 7;
            rect(g, wx, wy, 3, 4, on ? 0xFFF4D88C : mix(0xFFBFD8F0, fade, 0.3F));
            rect(g, wx, wy, 3, 1, on ? 0xFFFFEDB0 : mix(0xFFE4F0FA, fade, 0.2F));
        }
        rect(g, x + w / 2 - 1, base - 4, 3, 4, dark(c, 0.28F));                            // a door
    }

    // =====================================================================================================
    //  THE TOWN: a far row behind the towers (the row of the map above the first street)
    // =====================================================================================================
    /** x, width, height, colour, roof: the far row, from the left (the lawn of the camp covers its feet at the left side). */
    private static final int[][] TOWN = {
            {0, 15, 40, 4, -1}, {13, 14, 34, 2, 0}, {26, 16, 42, 1, -1}, {41, 14, 36, 6, 2}, {53, 13, 32, 5, -1},
            {63, 14, 38, 0, -1}, {78, 12, 31, 7, 3}, {88, 15, 36, 3, -1}, {100, 11, 34, 4, 1}, {116, 12, 38, 5, -1},
            {130, 13, 32, 2, 0}, {143, 14, 38, 6, -1}, {157, 12, 36, 1, -1}, {169, 14, 32, 7, 2}, {184, 12, 38, 0, -1},
            {196, 13, 34, 3, 1}, {208, 12, 37, 4, -1}, {220, 12, 33, 5, 3}};

    /** The far row: low pale houses at the back of the towers, so the top of the town is a skyline and not an empty sky of paving. */
    static void farTown(GuiGraphics g, boolean night) {
        if (!MapArt.seen(MapArt.HEAD, 66)) return;
        for (int i = 0; i < TOWN.length; i++) {
            int[] t = TOWN[i];
            house(g, t[0], 62, t[1], t[2], PASTEL[t[3]], t[4], 0xFFE4DFF0, night, i);
        }
    }

    // =====================================================================================================
    //  THE BOULEVARD: little shops along the street, behind the promenade (the two big shops stand in front of the ends)
    // =====================================================================================================
    /** x, width, height, colour, awning colour (the middle of the row; the two big shops hide the rest). */
    private static final int[][] SHOPS = {
            {96, 15, 20, 5, 0xFFE8708F}, {112, 13, 25, 4, 0xFF5AC08C}, {126, 17, 19, 0, 0xFFE8A04A}, {144, 12, 27, 2, 0xFF6FB8E8},
            {157, 15, 23, 6, 0xFFB57BD6}, {173, 13, 21, 1, 0xFFE8708F}, {187, 17, 25, 3, 0xFF5AC08C}};

    /** The row of little houses behind the promenade, and two houses at each edge (behind the flower beds). */
    static void shopRow(GuiGraphics g, boolean night) {
        if (!MapArt.seen(180, 210)) return;
        int fade = 0xFFF2E6EA;
        for (int i = 0; i < SHOPS.length; i++) {
            int[] s = SHOPS[i];
            house(g, s[0], 206, s[1], s[2], PASTEL[s[3]], i % 3 == 1 ? i % 4 : -1, fade, night, i + 3);
            awning(g, s[0], 206 - 9, s[1], s[4]);
        }
        rect(g, 94, 206, 114, 3, 0xFFEBDDE2); rect(g, 94, 206, 114, 1, 0xFFFFFFFF);          // the doorsteps
        int[][] edge = {{1, 13, 18, 2, 0}, {13, 15, 22, 1, -1}, {272, 14, 20, 4, -1}, {285, 14, 17, 6, 3}};
        for (int i = 0; i < edge.length; i++) {
            int[] e = edge[i];
            house(g, e[0], 199, e[1], e[2], PASTEL[e[3]], e[4], fade, night, i + 9);
        }
    }

    /** A small striped awning over the door of a little shop. */
    private static void awning(GuiGraphics g, int x, int y, int w, int c) {
        for (int i = 0; i < w; i += 3) rect(g, x + i, y, Math.min(3, w - i), 3, (i / 3) % 2 == 0 ? c : 0xFFFFFFFF);
        rect(g, x, y + 3, w, 1, 0x28000000);
    }

    // =====================================================================================================
    //  DOWNTOWN: a far skyline behind the two rows of towers on both sides of the avenue
    // =====================================================================================================
    /** x, width, height, colour, roof. The base is the foot of the towers; the tops show above them. */
    private static final int[][] CITY = {
            {0, 18, 76, 3, -1}, {16, 16, 66, 1, -1}, {31, 18, 78, 0, -1}, {47, 15, 70, 5, -1}, {61, 17, 74, 2, -1},
            {77, 16, 64, 6, -1}, {92, 15, 72, 4, -1}, {104, 14, 66, 7, -1},
            {188, 15, 70, 4, -1}, {202, 18, 76, 5, -1}, {219, 16, 66, 1, -1}, {234, 18, 74, 3, -1}, {251, 16, 72, 0, -1},
            {266, 17, 78, 6, -1}, {282, 18, 68, 2, -1}};
    // (the tallest one is 78 high: with its aerial and flag it still ends below the hedge of the boulevard, which ends at y = 312)

    /** The far skyline of Downtown: tall pale blocks with an aerial or a pointed top, behind the towers (the avenue covers the middle). */
    static void farCity(GuiGraphics g, int base, boolean night) {
        if (!MapArt.seen(base - 90, base)) return;
        int fade = 0xFFE2DAF0;
        for (int i = 0; i < CITY.length; i++) {
            int[] c = CITY[i];
            house(g, c[0], base, c[1], c[2], PASTEL[c[3]], c[4], fade, night, i * 3);
            int top = base - c[2];
            rect(g, c[0] + c[1] / 2, top - 8, 1, 6, mix(0xFF8A8AA0, fade, 0.4F));            // an aerial
            if (i % 3 == 1) rect(g, c[0] + c[1] / 2 - 1, top - 9, 3, 1, 0xFFFF9AB8);          // with a pink flag
        }
    }
}
