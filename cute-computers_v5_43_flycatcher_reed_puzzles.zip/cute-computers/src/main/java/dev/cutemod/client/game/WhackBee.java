package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Yellow computer: click the bee when it pops out of a flower. 3 misses = game over. */
public class WhackBee extends MiniGame {
    private static final int CW = 64, CH = 40, GX = 8, GY = 6, OX = 6, OY = 4;

    private int active, life, wait, lastCell, misses, t;
    private int hitCell = -1, hitT, missCell = -1, missT;   // little effects after a hit / a miss

    @Override
    public void reset() {
        score = 0; over = false; active = -1; wait = 40; lastCell = -1; misses = 0; t = 0; hitCell = -1; hitT = 0; missCell = -1; missT = 0;
    }

    private static int cellX(int i) { return OX + (i % 3) * (CW + GX); }
    private static int cellY(int i) { return OY + (i / 3) * (CH + GY); }

    @Override
    public boolean click(int x, int y, int button) {
        if (active >= 0 && in(x, y, cellX(active), cellY(active), CW, CH)) {
            score++;
            pling(1.0F + Math.min(score, 25) * 0.03F);
            hitCell = active; hitT = 18;
            active = -1;
            wait = 12;
        }
        return true;
    }

    @Override
    public void tick() {
        t++;
        if (hitT > 0) hitT--;
        if (missT > 0) missT--;
        if (active >= 0) {
            if (--life <= 0) {
                missCell = active; missT = 16;
                active = -1; wait = 20; misses++; beep();
                if (misses >= 3) over = true;
            }
        } else if (--wait <= 0) {
            int c;
            do { c = rnd.nextInt(9); } while (c == lastCell);
            active = c; lastCell = c;
            life = Math.max(26, 80 - score * 2);
        }
    }

    @Override
    public void render(GuiGraphics g) {
        // sunny meadow: gradient, soft light, little flowers in the background
        g.fillGradient(0, 0, W, H, 0xFF9EDC7A, 0xFF5FB04F);
        Gfx.glow(g, 190, 8, 40, 0xFFFFF6C0, 90);
        for (int i = 0; i < 20; i++) {
            int fx = (int) (Gfx.hash(i, 8) * W), fy = (int) (Gfx.hash(i, 9) * H);
            int col = i % 3 == 0 ? 0xFFFFFFFF : i % 3 == 1 ? 0xFFFFC2DC : 0xFFFFE27A;
            rect(g, fx, fy, 1, 1, col); rect(g, fx - 1, fy, 1, 1, Gfx.fade(col, 0.6f)); rect(g, fx + 1, fy, 1, 1, Gfx.fade(col, 0.6f));
            rect(g, fx, fy - 1, 1, 1, Gfx.fade(col, 0.6f)); rect(g, fx, fy + 1, 1, 1, Gfx.fade(col, 0.6f));
        }
        for (int i = 0; i < 9; i++) {
            int x = cellX(i), y = cellY(i);
            int mx0 = x + CW / 2, my0 = y + CH - 12;
            // a big flower around the hole: petals behind, dark hole in the middle
            int sway = (int) Math.round(Math.sin(t * 0.04 + i) * 0.6);
            for (int a = 0; a < 6; a++) {
                double ang = a * Math.PI / 3 + 0.4;
                int px = mx0 + (int) Math.round(Math.cos(ang) * 19), py = my0 - 2 + (int) Math.round(Math.sin(ang) * 8);
                Gfx.rrect(g, px - 8, py - 3, 16, 7, 3, (a & 1) == 0 ? 0xFFFFC2DC : 0xFFFFD9EA);
            }
            Gfx.ellipse(g, mx0, my0, 17, 8, 0xFF8A5A30);
            Gfx.ellipse(g, mx0, my0 - 1, 14, 6, 0xFF2A1A0C);
            if (i == active) {
                int pop = Math.min(14, (80 - life) / 2 + 4);
                int bx = mx0 + sway, by = my0 - 6 - pop;
                bee(g, bx, by);
            }
            if (i == hitCell && hitT > 0) {                 // star burst where the bee was hit
                float k = 1f - hitT / 18f;
                for (int a = 0; a < 6; a++) {
                    double ang = a * Math.PI / 3 + k;
                    int sx = mx0 + (int) Math.round(Math.cos(ang) * (6 + k * 16)), sy = my0 - 12 + (int) Math.round(Math.sin(ang) * (6 + k * 12));
                    Gfx.star(g, sx, sy, 2, Gfx.fade(0xFFFFE27A, 1f - k));
                }
                Gfx.glow(g, mx0, my0 - 12, 14, 0xFFFFFFFF, (int) (80 * (1f - k)));
            }
            if (i == missCell && missT > 0) {               // the bee flies away: a little puff
                float k = 1f - missT / 16f;
                Gfx.disc(g, mx0, my0 - 10 - (int) (k * 12), 3 + (int) (k * 3), Gfx.fade(0xFFFFFFFF, 0.5f * (1f - k)));
            }
            // front rim of the hole hides the bee's lower part
            Gfx.ellipse(g, mx0, my0 + 3, 15, 3, 0xFF6B4423);
            g.fill(mx0 - 15, my0 + 2, mx0 + 16, my0 + 3, 0xFF8A5A30);
        }
    }

    private static void bee(GuiGraphics g, int bx, int by) {
        int flap = ((int) (System.nanoTime() / 40_000_000L)) % 2;      // wings buzz
        Gfx.ellipse(g, bx, by + 12, 9, 2, 0x33000000);
        Gfx.ellipse(g, bx - 9, by - 3 - flap, 6, 4, 0xAAEAF8FF);
        Gfx.ellipse(g, bx + 9, by - 3 - flap, 6, 4, 0xAAEAF8FF);
        Gfx.ellipse(g, bx, by + 5, 11, 8, 0xFF3A2A1A);
        Gfx.ellipse(g, bx, by + 5, 10, 7, 0xFFFFCF2E);
        g.fill(bx - 8, by + 3, bx + 9, by + 5, 0xFF3A2A1A);             // stripes
        g.fill(bx - 6, by + 8, bx + 7, by + 10, 0xFF3A2A1A);
        g.fill(bx - 7, by + 1, bx + 4, by + 2, 0x88FFFFFF);               // shine
        // face
        g.fill(bx - 5, by + 4, bx - 2, by + 7, 0xFFFFFFFF); g.fill(bx + 2, by + 4, bx + 5, by + 7, 0xFFFFFFFF);
        g.fill(bx - 4, by + 5, bx - 2, by + 7, 0xFF2A1D10); g.fill(bx + 2, by + 5, bx + 4, by + 7, 0xFF2A1D10);
        g.fill(bx - 1, by + 8, bx + 1, by + 9, 0xFFC04A2A);
        g.fill(bx - 7, by + 7, bx - 5, by + 8, 0x77FF7A9A); g.fill(bx + 5, by + 7, bx + 7, by + 8, 0x77FF7A9A);
        // antennae with balls
        Gfx.line(g, bx - 3, by - 2, bx - 6, by - 7, 0xFF3A2A1A); Gfx.line(g, bx + 3, by - 2, bx + 6, by - 7, 0xFF3A2A1A);
        g.fill(bx - 7, by - 8, bx - 5, by - 6, 0xFF3A2A1A); g.fill(bx + 5, by - 8, bx + 7, by - 6, 0xFF3A2A1A);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, 3 - misses); }

    @Override
    public String hintKey() { return "cutemod.hint.bee"; }
}
