package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Drawing helpers shared by the mini games: rounded boxes, soft shadows, glows, smooth discs, highlights and little
 * shapes (heart, star, sparkle). Everything is built from plain fills, so it works at the 220 x 140 game size.
 */
public final class Gfx {
    private Gfx() {}

    // ---------- colours ----------
    public static int alpha(int argb, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (argb & 0xFFFFFF); }

    /** Multiplies the alpha of a colour (0..1). */
    public static int fade(int argb, float k) { return alpha(argb, Math.round(((argb >>> 24) & 255) * k)); }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = Math.round(((a >>> 24) & 255) * (1 - t) + ((b >>> 24) & 255) * t);
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (aa << 24) | (r << 16) | (g << 8) | bl;
    }

    public static int lighter(int argb, float t) { return mix(argb, 0xFFFFFFFF, t); }

    public static int darker(int argb, float t) { return mix(argb, 0xFF000000, t); }

    // ---------- boxes ----------
    /** A filled rectangle with the corners cut round (r = 1..4 looks right at this size). */
    public static void rrect(GuiGraphics g, int x, int y, int w, int h, int r, int argb) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { g.fill(x, y, x + w, y + h, argb); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.floor(Math.sqrt(Math.max(0, r * r - dy * dy)) + 0.0001);
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, argb);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, argb);
        }
        g.fill(x, y + r, x + w, y + h - r, argb);
    }

    /** A rounded box with a darker rim, a light top edge and a soft shade at the bottom: buttons, cards, bricks. */
    public static void bubble(GuiGraphics g, int x, int y, int w, int h, int r, int face) {
        rrect(g, x, y, w, h, r, darker(face, 0.35f));
        rrect(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), face);
        if (h > 6) {
            g.fill(x + 2, y + h - 3, x + w - 2, y + h - 1, alpha(0xFF000000, 38));      // shade along the bottom edge
            g.fill(x + r, y + 1, x + w - r, y + 2, alpha(0xFFFFFFFF, 140));             // light top edge
            g.fill(x + 1, y + r, x + 2, y + h - r, alpha(0xFFFFFFFF, 50));              // light left edge
        }
    }

    /** A soft drop shadow under a box: two flat layers (cheap: this is drawn for every card, tile and block, every frame). */
    public static void shadow(GuiGraphics g, int x, int y, int w, int h, int r) {
        g.fill(x - 1, y + 1, x + w + 1, y + h + 3, alpha(0xFF000000, 14));
        g.fill(x, y + 2, x + w, y + h + 2, alpha(0xFF000000, 20));
    }

    public static void outline(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + 1, argb);
        g.fill(x, y + h - 1, x + w, y + h, argb);
        g.fill(x, y + 1, x + 1, y + h - 1, argb);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, argb);
    }

    /** A panel with a shadow, a rim and a gradient face. */
    public static void panel(GuiGraphics g, int x, int y, int w, int h, int top, int bottom) {
        shadow(g, x, y, w, h, 3);
        rrect(g, x - 1, y - 1, w + 2, h + 2, 4, darker(bottom, 0.45f));
        g.fillGradient(x + 1, y + 1, x + w - 1, y + h - 1, top, bottom);
        g.fill(x + 1, y + 1, x + w - 1, y + 2, alpha(0xFFFFFFFF, 90));
    }

    // ---------- round things ----------
    /** A disc whose edge pixels are softened a little. */
    public static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt((r + 0.5) * (r + 0.5) - dy * dy));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** A ball: dark rim, body, shaded lower half and a bright highlight. */
    public static void ball(GuiGraphics g, int cx, int cy, int r, int argb) {
        disc(g, cx, cy, r, darker(argb, 0.45f));
        if (r >= 3) disc(g, cx, cy, r - 1, argb);
        if (r >= 4) {
            int shade = alpha(0xFF000000, 30);
            for (int dy = 0; dy <= r - 2; dy += 2) {                    // the shade is drawn in 2 px bands
                int dx = (int) Math.floor(Math.sqrt(Math.max(0, (r - 1) * (r - 1) - (dy + 2) * (dy + 2))));
                g.fill(cx - dx, cy + dy + 1, cx + dx + 1, cy + dy + 3, shade);
            }
            int hr = Math.max(1, r / 3);
            disc(g, cx - r / 3, cy - r / 3, hr, alpha(0xFFFFFFFF, 170));
        } else if (r == 3) {
            g.fill(cx - 1, cy - 1, cx, cy, alpha(0xFFFFFFFF, 190));
        }
    }

    /** A soft light: a few concentric discs that fade out; big ones are drawn in coarse 2-3 px bands (they are faint anyway). */
    public static void glow(GuiGraphics g, int cx, int cy, int r, int rgb, int a) {
        int steps = r < 8 ? 2 : r < 16 ? 3 : r < 28 ? 5 : 7;
        for (int i = steps; i >= 1; i--) {
            int rr = Math.max(1, Math.round(r * i / (float) steps));
            int col = alpha(rgb, Math.round(a * (1 - (i - 1) / (float) steps) / steps * 1.6f));
            int band = rr >= 30 ? 3 : rr >= 14 ? 2 : 1;
            for (int dy = -rr; dy <= rr; dy += band) {
                int dx = (int) Math.floor(Math.sqrt(Math.max(0, (rr + 0.5) * (rr + 0.5) - (double) dy * dy)));
                g.fill(cx - dx, cy + dy, cx + dx + 1, cy + Math.min(rr + 1, dy + band), col);
            }
        }
    }

    public static void ellipse(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            double k = 1.0 - (dy * dy) / ((ry + 0.5) * (ry + 0.5));
            int dx = (int) Math.floor((rx + 0.5) * Math.sqrt(Math.max(0, k)));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    // ---------- little shapes ----------
    public static void heart(GuiGraphics g, int x, int y, int argb) {   // 7 x 6
        g.fill(x + 1, y, x + 3, y + 1, argb); g.fill(x + 4, y, x + 6, y + 1, argb);
        g.fill(x, y + 1, x + 7, y + 3, argb);
        g.fill(x + 1, y + 3, x + 6, y + 4, argb);
        g.fill(x + 2, y + 4, x + 5, y + 5, argb);
        g.fill(x + 3, y + 5, x + 4, y + 6, argb);
        g.fill(x + 1, y + 1, x + 2, y + 2, alpha(0xFFFFFFFF, 140));
    }

    public static void star(GuiGraphics g, int cx, int cy, int r, int argb) {
        g.fill(cx - r, cy, cx + r + 1, cy + 1, argb);
        g.fill(cx, cy - r, cx + 1, cy + r + 1, argb);
        if (r >= 2) {
            int s = r / 2;
            g.fill(cx - s, cy - s, cx + s + 1, cy + s + 1, argb);
        }
    }

    /** A twinkle: a plus whose size pulses with t (ticks). */
    public static void sparkle(GuiGraphics g, int cx, int cy, int size, int t, int argb) {
        double k = 0.5 + 0.5 * Math.sin(t * 0.12);
        int r = Math.max(1, (int) Math.round(size * (0.4 + 0.6 * k)));
        g.fill(cx - r, cy, cx + r + 1, cy + 1, fade(argb, (float) (0.5 + 0.5 * k)));
        g.fill(cx, cy - r, cx + 1, cy + r + 1, fade(argb, (float) (0.5 + 0.5 * k)));
        g.fill(cx, cy, cx + 1, cy + 1, argb);
    }

    /** A line made of fills (for whiskers, strings, rays). */
    public static void line(GuiGraphics g, int x1, int y1, int x2, int y2, int argb) {
        int dx = Math.abs(x2 - x1), dy = Math.abs(y2 - y1), sx = x1 < x2 ? 1 : -1, sy = y1 < y2 ? 1 : -1, err = dx - dy;
        for (int i = 0; i < 400; i++) {
            g.fill(x1, y1, x1 + 1, y1 + 1, argb);
            if (x1 == x2 && y1 == y2) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x1 += sx; }
            if (e2 < dx) { err += dx; y1 += sy; }
        }
    }

    private static double[] CUT = new double[16];

    /** A filled polygon (scanline), for stars, triangles and gems. */
    public static void poly(GuiGraphics g, int[] xs, int[] ys, int argb) {
        int n = xs.length, minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        for (int y : ys) { minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
        for (int y = minY; y <= maxY; y++) {
            double sy = y + 0.5;
            double[] cut = CUT.length >= n ? CUT : (CUT = new double[n]);
            int c = 0;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                double y1 = ys[i], y2 = ys[j];
                if ((y1 <= sy && y2 > sy) || (y2 <= sy && y1 > sy)) cut[c++] = xs[i] + (sy - y1) / (y2 - y1) * (xs[j] - xs[i]);
            }
            java.util.Arrays.sort(cut, 0, c);
            for (int i = 0; i + 1 < c; i += 2) g.fill((int) Math.round(cut[i]), y, (int) Math.round(cut[i + 1]), y + 1, argb);
        }
    }

    /** A five pointed star: outer radius R, inner radius r. */
    public static void star5(GuiGraphics g, int cx, int cy, int R, int r, int argb) {
        int[] xs = new int[10], ys = new int[10];
        for (int i = 0; i < 10; i++) {
            double a = -Math.PI / 2 + i * Math.PI / 5, rad = (i & 1) == 0 ? R : r;
            xs[i] = cx + (int) Math.round(Math.cos(a) * rad);
            ys[i] = cy + (int) Math.round(Math.sin(a) * rad);
        }
        poly(g, xs, ys, argb);
    }

    // ---------- scenery ----------
    /** A puffy cloud made of three discs and a flat bottom. */
    public static void cloud(GuiGraphics g, int x, int y, int w, int argb) {
        int h = Math.max(4, w / 4);
        disc(g, x + w / 4, y + h / 2, h / 2 + 1, argb);
        disc(g, x + w / 2, y + h / 3, h / 2 + 3, argb);
        disc(g, x + w * 3 / 4, y + h / 2, h / 2 + 1, argb);
        g.fill(x + w / 4, y + h / 2, x + w * 3 / 4, y + h / 2 + h / 2 + 1, argb);
    }

    /** A darkened edge around the whole game box, so the middle looks lit. */
    public static void vignette(GuiGraphics g, int w, int h, int strength) {
        int a = Math.max(0, Math.min(255, strength));
        g.fillGradient(0, 0, w, 14, alpha(0xFF000000, a), 0x00000000);
        g.fillGradient(0, h - 14, w, h, 0x00000000, alpha(0xFF000000, a));
        for (int i = 0; i < 8; i++) {
            int al = a * (8 - i) / 8 / 3;
            g.fill(i, 0, i + 1, h, alpha(0xFF000000, al));
            g.fill(w - 1 - i, 0, w - i, h, alpha(0xFF000000, al));
        }
    }

    /** A tiny deterministic hash for scenery that must not jump around between frames. */
    public static float hash(int i, int k) {
        int h = i * 374761393 + k * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535f;
    }
}
