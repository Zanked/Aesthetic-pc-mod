package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The little animals of the "Sunny Chick" look: pixel faces for the desktop widgets (a chick, a fox, a bear, a cat and a bunny peek over
 * the edge of a card), ears and a tuft that stand on the icon tiles, and the tiny faces that float over the wallpaper.
 * Every sprite is a few rows of letters (see {@link #col}); "." is empty.
 */
final class Critters {
    private Critters() {}

    static final int CHICK = 0, FOX = 1, BEAR = 2, CAT = 3, BUNNY = 4, COUNT = 5;

    private static final String[] CHICK_FACE = {
            "....o.o.o....",
            "....oyoyo....",
            "..ooyyyyyoo..",
            ".oyYyyyyyyyo.",
            ".oyykyyykyyo.",
            "oyppyrrryppyo",
            ".oyyyyyryyyo.",
            "..oyyyyyyyo..",
            "...ooooooo..."};
    private static final String[] FOX_FACE = {
            ".o.........o.",
            ".oro.....oro.",
            ".orrooooorro.",
            "orrrrrrrrrrro",
            "orrkrrrrrkrro",
            "orrwwrrrwwrro",
            "orwwwwkwwwwro",
            ".owwwwwwwwwo.",
            "..owwwwwwwo..",
            "...ooooooo..."};
    private static final String[] BEAR_FACE = {
            ".oo.......oo.",
            "obbo.....obbo",
            "obbooooooobbo",
            ".obbbbbbbbbo.",
            ".obkbbbbbkbo.",
            ".obbbBBBbbbo.",
            ".obbBBkBBbbo.",
            "..obbbbbbbo..",
            "...ooooooo..."};
    private static final String[] CAT_FACE = {
            ".o.........o.",
            ".oro.....oro.",
            ".orcooooorco.",
            "occcrcccrccco",
            "occkccccckcco",
            "occcccpccccco",
            ".occccocccco.",
            "..occccccco..",
            "...ooooooo..."};
    private static final String[] BUNNY_FACE = {
            "..oo.....oo..",
            ".owwo...owwo.",
            ".opwo...opwo.",
            ".owwooooowwo.",
            "owwwwwwwwwwwo",
            "owwkwwwwwkwwo",
            "oppwwwpwwwppo",
            ".owwwwwwwwwo.",
            "..owwwwwwwo..",
            "...ooooooo..."};

    private static final String[][] FACES = {CHICK_FACE, FOX_FACE, BEAR_FACE, CAT_FACE, BUNNY_FACE};

    // ears that stand on top of an icon tile (the left one; the right one is the same, mirrored); the tile covers their feet
    private static final String[] FOX_EAR = {".o....", ".oro..", ".orro.", ".orrro", "orrrro", "orrrro", "orrrro", "orrrro"};
    private static final String[] BEAR_EAR = {".oooo.", "obbbbo", "obppbo", "obppbo", "obbbbo", "obbbbo", "obbbbo"};
    private static final String[] CAT_EAR = {".o....", ".oco..", ".ocpo.", ".occpo", "occcco", "occcco", "occcco", "occcco"};
    private static final String[] BUNNY_EAR = {".oo.", "owwo", "owpo", "owpo", "owpo", "owpo", "owwo", "owwo"};
    private static final String[] CHICK_TUFT = {".o.o.o.", ".oyoyo.", ".oyyyo.", "oyyyyyo", "oyyyyyo"};

    // tiny faces (7 x 7) that float over the wallpaper and inside the music player
    private static final String[][] MINI = {
            {"..o.o..", ".oyyyo.", "oyyyyyo", "oykykyo", "oyyryyo", ".oyyyo.", "..ooo.."},
            {"o.....o", "oro.oro", "orrrrro", "orkrkro", "orwkwro", ".owwwo.", "..ooo.."},
            {"oo...oo", "obo.obo", "obbbbbo", "obkbkbo", "obBkBbo", ".obbbo.", "..ooo.."},
            {"o.....o", "oco.oco", "occccco", "ockckco", "occpcco", ".occco.", "..ooo.."},
            {".oo.oo.", "owwowwo", "owwwwwo", "owkwkwo", "owwpwwo", ".owwwo.", "..ooo.."}};

    /** The colour of a letter: o = outline, y yellow, Y light yellow, r orange, p pink, w white, b brown, B tan, c cream, k eyes, n beak. */
    static int col(char c) {
        return switch (c) {
            case 'o' -> 0xFF7A4210;
            case 'y' -> 0xFFFFD84A;
            case 'Y' -> 0xFFFFF0A0;
            case 'r' -> 0xFFFF9A2E;
            case 'p' -> 0xFFFFA8B8;
            case 'w' -> 0xFFFFFFFF;
            case 'b' -> 0xFFB8743A;
            case 'B' -> 0xFFE8B878;
            case 'c' -> 0xFFFFF0C8;
            case 'k' -> 0xFF3A2208;
            case 'n' -> 0xFFFF7A00;
            default -> 0;
        };
    }

    /** Draws a sprite with its top-left corner at x, y. Neighbouring pixels of one colour go into one fill. */
    static void sprite(GuiGraphics g, String[] rows, int x, int y, boolean mirror) { sprite(g, rows, x, y, mirror, 255); }

    /** The same, with all colours faded to alpha / 255. */
    static void sprite(GuiGraphics g, String[] rows, int x, int y, boolean mirror, int alpha) {
        for (int r = 0; r < rows.length; r++) {
            String s = rows[r];
            int n = s.length();
            int c = 0;
            while (c < n) {
                int i = mirror ? n - 1 - c : c;
                char ch = s.charAt(i);
                if (ch == '.') { c++; continue; }
                int run = 1;
                while (c + run < n && s.charAt(mirror ? n - 1 - (c + run) : c + run) == ch) run++;
                int argb = col(ch);
                if (alpha < 255) argb = (((argb >>> 24) * alpha / 255) << 24) | (argb & 0xFFFFFF);
                g.fill(x + c, y + r, x + c + run, y + r + 1, argb);
                c += run;
            }
        }
    }

    /** The face of a kind (13 wide, 9 or 10 high). x, y is its top-left corner. */
    static void face(GuiGraphics g, int kind, int x, int y) {
        sprite(g, FACES[Math.floorMod(kind, COUNT)], x, y, false);
    }

    static int faceW() { return 13; }

    static int faceH(int kind) { return FACES[Math.floorMod(kind, COUNT)].length; }

    /** A widget mascot: the face sits on the top edge of a card so that its ears poke out above it, at the right corner. */
    static void peek(GuiGraphics g, int kind, int cardX, int cardY, int cardW, int dx) {
        face(g, kind, cardX + cardW - 15 + dx, cardY - 3);
    }

    /** The ears (or the tuft of a chick) of an icon tile at x, y. They are drawn first, the tile covers their feet. */
    static void tileEars(GuiGraphics g, int kind, int x, int y) {
        switch (Math.floorMod(kind, COUNT)) {
            case FOX -> { sprite(g, FOX_EAR, x + 4, y - 7, false, 255); sprite(g, FOX_EAR, x + 22, y - 7, true, 255); }
            case BEAR -> { sprite(g, BEAR_EAR, x + 3, y - 5, false, 255); sprite(g, BEAR_EAR, x + 23, y - 5, false, 255); }
            case CAT -> { sprite(g, CAT_EAR, x + 4, y - 7, false, 255); sprite(g, CAT_EAR, x + 22, y - 7, true, 255); }
            case BUNNY -> { sprite(g, BUNNY_EAR, x + 8, y - 7, false, 255); sprite(g, BUNNY_EAR, x + 20, y - 7, false, 255); }
            default -> sprite(g, CHICK_TUFT, x + 12, y - 4, false, 255);
        }
    }

    /** A tiny floating face (7 x 7) for the overlay. */
    static void mini(GuiGraphics g, int kind, int x, int y, int alpha) {
        sprite(g, MINI[Math.floorMod(kind, COUNT)], x, y, false, alpha);
    }
}
