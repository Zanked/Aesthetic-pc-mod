package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayDeque;

/** Green computer: Minesweeper with creepers. Left click = dig, right click = flag. */
public class Minesweeper extends MiniGame {
    private static final int C = 14, R = 9, CELL = 15, OX = (W - C * CELL) / 2, OY = (H - R * CELL) / 2, MINES = 18;
    private static final int[] NUM = {0, 0xFF2B5FD9, 0xFF2E8B3A, 0xFFD93A3A, 0xFF6B2FA0, 0xFF8A3A1A, 0xFF1A8A8A, 0xFF222222, 0xFF666666};

    private final boolean[][] mine = new boolean[R][C];
    private final boolean[][] shown = new boolean[R][C];
    private final boolean[][] flag = new boolean[R][C];
    private final int[][] adj = new int[R][C];
    private boolean first, lost;
    private int ticks, revealed, flags, boomR, boomC;

    @Override
    public void reset() {
        score = 0; over = false; first = true; lost = false; ticks = 0; revealed = 0; flags = 0; boomR = -1; boomC = -1;
        for (int r = 0; r < R; r++) for (int c = 0; c < C; c++) { mine[r][c] = false; shown[r][c] = false; flag[r][c] = false; adj[r][c] = 0; }
    }

    private void placeMines(int safeR, int safeC) {
        int placed = 0;
        while (placed < MINES) {
            int r = rnd.nextInt(R), c = rnd.nextInt(C);
            if (mine[r][c] || (Math.abs(r - safeR) <= 1 && Math.abs(c - safeC) <= 1)) continue;
            mine[r][c] = true; placed++;
        }
        for (int r = 0; r < R; r++) for (int c = 0; c < C; c++) {
            int n = 0;
            for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
                int rr = r + dr, cc = c + dc;
                if ((dr != 0 || dc != 0) && rr >= 0 && cc >= 0 && rr < R && cc < C && mine[rr][cc]) n++;
            }
            adj[r][c] = n;
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        int c = (x - OX) / CELL, r = (y - OY) / CELL;
        if (x < OX || y < OY || c >= C || r >= R) return true;
        if (button == 1) {
            if (!shown[r][c]) { flag[r][c] = !flag[r][c]; flags += flag[r][c] ? 1 : -1; beep(); }
            return true;
        }
        if (flag[r][c] || shown[r][c]) return true;
        if (first) { first = false; placeMines(r, c); }
        if (mine[r][c]) { lost = true; over = true; boomR = r; boomC = c; score = 0; beep(); return true; }
        floodReveal(r, c);
        pling(1.2F);
        if (revealed == R * C - MINES) {
            over = true;
            score = Math.max(10, 500 - (ticks / 60) * 3);
            pling(1.9F);
        }
        return true;
    }

    private void floodReveal(int sr, int sc) {
        ArrayDeque<int[]> stack = new ArrayDeque<>();
        stack.push(new int[]{sr, sc});
        while (!stack.isEmpty()) {
            int[] p = stack.pop();
            int r = p[0], c = p[1];
            if (r < 0 || c < 0 || r >= R || c >= C || shown[r][c] || flag[r][c] || mine[r][c]) continue;
            shown[r][c] = true; revealed++;
            if (adj[r][c] == 0) {
                for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) stack.push(new int[]{r + dr, c + dc});
            }
        }
    }

    @Override
    public void tick() {
        if (!first) ticks++;
    }

    @Override
    public void render(GuiGraphics g) {
        // mossy backdrop and a framed board with a shadow
        g.fillGradient(0, 0, W, H, 0xFF2E4A30, 0xFF1A2E1C);
        for (int i = 0; i < 16; i++) rect(g, (int) (Gfx.hash(i, 10) * W), (int) (Gfx.hash(i, 11) * H), 2, 1, 0x1A9CFF8A);
        Gfx.shadow(g, OX - 3, OY - 3, C * CELL + 6, R * CELL + 6, 3);
        Gfx.rrect(g, OX - 3, OY - 3, C * CELL + 6, R * CELL + 6, 3, 0xFF5A3A1C);
        Gfx.rrect(g, OX - 2, OY - 2, C * CELL + 4, R * CELL + 4, 2, 0xFF7A5230);
        for (int r = 0; r < R; r++) {
            for (int c = 0; c < C; c++) {
                int x = OX + c * CELL, y = OY + r * CELL;
                boolean boom = lost && mine[r][c] && !flag[r][c];
                if (shown[r][c]) {
                    int base = ((r + c) & 1) == 0 ? 0xFFE0CBA2 : 0xFFD4BC90;
                    rect(g, x, y, CELL, CELL, base);
                    rect(g, x, y, CELL, 1, 0x22000000); rect(g, x, y, 1, CELL, 0x22000000);   // sunken look
                    if (adj[r][c] > 0) {
                        int col = NUM[adj[r][c]];
                        ctext(g, String.valueOf(adj[r][c]), x + CELL / 2 + 1, y + 5, 0x33000000);
                        ctext(g, String.valueOf(adj[r][c]), x + CELL / 2, y + 4, col);
                    }
                } else {
                    // grass block with a darker side, a light top and a few blades
                    int base = ((r + c) & 1) == 0 ? 0xFF72C95F : 0xFF65BA53;
                    rect(g, x, y, CELL, CELL, base);
                    rect(g, x, y, CELL, 2, 0x66FFFFFF);
                    rect(g, x, y, 1, CELL, 0x44FFFFFF);
                    rect(g, x, y + CELL - 2, CELL, 2, 0x44000000);
                    rect(g, x + CELL - 1, y, 1, CELL, 0x33000000);
                    float h1 = Gfx.hash(r * 31 + c, 12), h2 = Gfx.hash(r * 31 + c, 13);
                    rect(g, x + 2 + (int) (h1 * 8), y + 4 + (int) (h2 * 6), 1, 2, 0xFF4FA848);
                    rect(g, x + 3 + (int) (h2 * 8), y + 7 + (int) (h1 * 4), 2, 1, 0xFF8CE07A);
                    if (flag[r][c]) {
                        // pole, a waving red pennant and a little base
                        rect(g, x + 4, y + 11, 6, 2, 0x44000000);
                        rect(g, x + 7, y + 3, 1, 9, 0xFF5A3A1C);
                        int wave = (ticks / 10) % 2;
                        rect(g, x + 3, y + 3, 4, 2 + wave, 0xFFE03A3A);
                        rect(g, x + 3, y + 4, 4, 3 - wave, 0xFFC02828);
                        rect(g, x + 3, y + 3, 4, 1, 0xFFFF7A7A);
                    }
                }
                if (boom) creeper(g, x, y, r == boomR && c == boomC);
            }
        }
    }

    private static void creeper(GuiGraphics g, int x, int y, boolean exploded) {
        if (exploded) Gfx.glow(g, x + CELL / 2, y + CELL / 2, 14, 0xFFFF5A2A, 150);
        int face = exploded ? 0xFFE8503A : 0xFF58B24A;
        rect(g, x, y, CELL, CELL, face);
        rect(g, x, y, CELL, 1, 0x55FFFFFF);
        // pixel noise like the real skin
        rect(g, x + 2, y + 1, 2, 2, Gfx.darker(face, 0.12f)); rect(g, x + 11, y + 10, 2, 2, Gfx.darker(face, 0.12f));
        rect(g, x + 8, y + 13, 3, 1, Gfx.lighter(face, 0.15f));
        // the face
        int d = 0xFF16301A;
        rect(g, x + 2, y + 3, 4, 4, d); rect(g, x + 9, y + 3, 4, 4, d);
        rect(g, x + 6, y + 7, 3, 4, d);
        rect(g, x + 4, y + 9, 2, 4, d); rect(g, x + 9, y + 9, 2, 4, d);
    }

    @Override
    public Component status() {
        return Component.translatable("cutemod.ui.mines", MINES - flags, ticks / 60);
    }

    @Override
    public String hintKey() { return "cutemod.hint.mines"; }
}
