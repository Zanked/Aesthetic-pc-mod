package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Block Tower: a block slides to and fro, click to drop it. What sticks out is cut off, a perfect drop keeps the whole block. */
public class StackTower extends MiniGame {
    private static final int BH = 10, BASE_W = 84, MAXN = 400, GROUND = 8;
    private static final int[] PAL = {0xFFF06AAE, 0xFFF5A04A, 0xFFF3D46A, 0xFF7ED957, 0xFF4FC9B8, 0xFF4A8FE0, 0xFF9B6AE0};

    private final int[] bx = new int[MAXN], bw = new int[MAXN];
    private int n, cw, perfect, flash;
    private float cx, dir, cam, camT;
    private boolean deb;
    private float dx, dy, dvy;
    private int dw, dc;

    @Override
    public void reset() {
        score = 0; over = false; perfect = 0; flash = 0; deb = false; cam = 0; camT = 0;
        bx[0] = (W - BASE_W) / 2; bw[0] = BASE_W; n = 1;
        spawn();
    }

    private void spawn() {
        cw = bw[n - 1];
        boolean left = n % 2 == 0;
        cx = left ? 0 : W - cw;
        dir = left ? 1 : -1;
    }

    private float speed() { return Math.min(3.4F, 1.1F + n * 0.05F); }

    private void drop(int x, int w, int level, int color) {
        deb = true; dx = x; dw = w; dc = color; dy = (H - GROUND) - (level + 1) * BH; dvy = 0;
    }

    private void place() {
        if (over) return;
        int left = bx[n - 1], right = left + bw[n - 1];
        int cl = Math.round(cx), cr = cl + cw;
        int ol = Math.max(left, cl), or = Math.min(right, cr), ow = or - ol;
        if (ow <= 0) { over = true; drop(cl, cw, n, PAL[n % PAL.length]); beep(); sound(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_BASS.value(), 0.6F, 0.8F); return; }
        if (Math.abs(cl - left) <= 2) {                              // a perfect drop: snap, keep the width
            ol = left; ow = bw[n - 1];
            perfect++; score += 2; flash = 40;
            pling(1.1F + Math.min(perfect, 8) * 0.07F);
            sound(net.minecraft.sounds.SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F + Math.min(perfect, 8) * 0.12F, 0.7F);
        } else {
            perfect = 0; score += 1;
            if (cl < left) drop(cl, left - cl, n, PAL[n % PAL.length]);
            else drop(right, cr - right, n, PAL[n % PAL.length]);
            pling(0.8F);
        }
        sound(net.minecraft.sounds.SoundEvents.STONE_STEP, 0.9F + rnd.nextFloat() * 0.2F, 0.7F);                  // the block lands
        bx[n] = ol; bw[n] = ow; n++;
        if (n >= MAXN - 1) { over = true; return; }
        spawn();
    }

    @Override
    public boolean click(int x, int y, int button) { place(); return true; }

    @Override
    public boolean key(int keyCode) {
        if (keyCode == KEY_SPACE) { place(); return true; }
        return false;
    }

    @Override
    public void tick() {
        if (flash > 0) flash--;
        if (deb) {
            dvy += 0.3F; dy += dvy;
            if (dy - cam > H + 20) deb = false;
        }
        camT = Math.max(0, (n + 1) * BH - (H - GROUND - 36));
        cam += (camT - cam) * 0.1F;
        if (over) return;
        cx += dir * speed();
        if (cx < 0) { cx = 0; dir = 1; }
        else if (cx > W - cw) { cx = W - cw; dir = -1; }
    }

    private static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    @Override
    public void render(GuiGraphics g) {
        float f = Math.min(1f, n / 60f);                                   // the sky gets dark as the tower grows
        g.fillGradient(0, 0, W, H, lerp(0xFF6EC6FF, 0xFF1B1440, f), lerp(0xFFFFD6E6, 0xFF3A2A6A, f));
        int cam0 = Math.round(cam);
        // sun/moon and layered clouds / stars that slide with the camera
        int orb = 16 + Math.round(cam0 * 0.15f);
        Gfx.glow(g, 176, orb, 26, f > 0.5f ? 0xFFDCD8FF : 0xFFFFF2C8, 120);
        Gfx.disc(g, 176, orb, 8, f > 0.5f ? 0xFFEFEBFF : 0xFFFFF8E0);
        if (f > 0.35f) for (int i = 0; i < 26; i++) {
            int sy = (int) (Gfx.hash(i, 18) * (H - 20) + cam0 * 0.2f) % (H - 12);
            Gfx.sparkle(g, (int) (Gfx.hash(i, 19) * W), sy, 1, i * 23, Gfx.fade(0xFFFFFFFF, Math.min(1f, (f - 0.35f) * 3f)));
        }
        if (f < 0.7f) for (int i = 0; i < 4; i++) {
            int cyy = (int) (20 + i * 38 + cam0 * (0.25f + i * 0.05f)) % (H + 20) - 10;
            Gfx.cloud(g, (int) ((i * 70 + 10) % (W + 30)) - 15, cyy, 30, Gfx.fade(0xFFFFFFFF, 0.8f * (1f - f)));
        }
        int gy = H - GROUND + cam0;
        if (gy < H) {
            g.fillGradient(0, gy, W, H, 0xFF6BCF58, 0xFF3F9A3A);
            g.fill(0, gy, W, gy + 2, 0xFF9EF08A);
        }
        for (int i = 0; i < n; i++) {
            int y = (H - GROUND) - (i + 1) * BH + cam0;
            if (y > H || y < -BH) continue;
            block(g, bx[i], y, bw[i], PAL[i % PAL.length]);
        }
        if (deb) block(g, Math.round(dx), Math.round(dy) + cam0, dw, dc);
        if (!over) {
            int y = (H - GROUND) - (n + 1) * BH + cam0;
            // a faint guide line down to the tower, so the drop is easier to judge
            rect(g, Math.round(cx), y + BH, 1, 3, 0x33FFFFFF); rect(g, Math.round(cx) + cw - 1, y + BH, 1, 3, 0x33FFFFFF);
            block(g, Math.round(cx), y, cw, PAL[n % PAL.length]);
        }
        if (flash > 0) {
            Gfx.rrect(g, W / 2 - 30, 9, 60, 14, 5, Gfx.fade(0xFF000000, 0.35f));
            ctext(g, Component.translatable("cutemod.tower.perfect").getString(), W / 2, 12, 0xFFFFD866);
            if (n > 0) {
                int y = (H - GROUND) - n * BH + cam0;
                Gfx.glow(g, bx[n - 1] + bw[n - 1] / 2, y + BH / 2, bw[n - 1] / 2 + 6, 0xFFFFFFFF, 70);
            }
        }
    }

    /** One block: rim, bright top, shaded bottom, a little window row and a drop shadow. */
    private static void block(GuiGraphics g, int x, int y, int w, int c) {
        if (w <= 0) return;
        Gfx.shadow(g, x, y, w, BH, 2);
        Gfx.rrect(g, x, y, w, BH, 2, Gfx.darker(c, 0.4f));
        g.fillGradient(x + 1, y + 1, x + w - 1, y + BH - 1, Gfx.lighter(c, 0.18f), Gfx.darker(c, 0.1f));
        g.fill(x + 2, y + 1, x + w - 2, y + 2, 0x77FFFFFF);
        g.fill(x + 1, y + BH - 3, x + w - 1, y + BH - 1, 0x22000000);
        for (int wx = x + 6; wx + 4 < x + w - 4; wx += 9) g.fill(wx, y + 3, wx + 4, y + 6, 0x33FFFFFF);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score", score); }

    @Override
    public String hintKey() { return "cutemod.hint.tower"; }
}
