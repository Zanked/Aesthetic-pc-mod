package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import dev.cutemod.client.os.CuteFont;
import dev.cutemod.data.FightBot;
import dev.cutemod.data.FightSim;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Pet Brawl: a cute Street Fighter. Pick one of four animals and fight best of three rounds against the computer (easy / normal /
 * hard) or against a friend on the same keyboard. The rules are in {@link FightSim}, the computer player in {@link FightBot}, the
 * pictures in {@link FightArt}; this class is the menus, the keys, the hit sparks, the sounds and the HUD.
 * <ul>
 * <li>Player 1: A D walk, W jump, S crouch, F punch, G kick, H special. Against the computer the arrows and J K L work too.</li>
 * <li>Player 2 (two players): arrows to move, J punch, K kick, L special.</li>
 * <li>Block: hold AWAY from the rival (standing blocks high and middle hits, crouching blocks low hits).</li>
 * </ul>
 * Score against the computer: a win is 50 / 75 / 100 (easy / normal / hard) and +10 for every perfect round; a loss gives 8 per
 * round won. A game for two gives no score (so nobody farms coins by playing against themselves).
 */
public class Fighters extends MiniGame {
    private static final int MENU = 0, SELECT = 1, VS = 2, FIGHT = 3;
    private static final int[] WIN_SCORE = {50, 75, 100};

    private int screen = MENU, anim, mode, level = 1, menuSel, cursor, selStep, vsT, overWait;
    private final int[] pick = new int[2];
    private FightSim sim;
    private FightBot bot;
    private final FightArt.Rig[] rig = {new FightArt.Rig(), new FightArt.Rig()};
    private final boolean[] prevKey = new boolean[14];
    private final List<P> parts = new ArrayList<>();
    private final List<FightSim.Ev> evBuf = new ArrayList<>();
    private int shake, shakeMag, flash, lines, linesColor, jingle;
    private final float[] trail = {100, 100};
    private boolean won, draw;
    private int matchWinner = -1;

    // the two fighters on the menu and the four on the select screen: not part of any fight
    private final FightSim.F[] show = new FightSim.F[4];
    private final FightArt.Rig[] showRig = new FightArt.Rig[4];

    private static final int P_STAR = 0, P_BIT = 1, P_RING = 2, P_DUST = 3, P_TEXT = 4, P_FLAT = 5, P_EMBER = 6;

    private static final class P {
        float x, y, vx, vy;
        int life, max, type, color, size;
        String text;
    }

    public Fighters() {
        for (int i = 0; i < 4; i++) { show[i] = new FightSim.F(); showRig[i] = new FightArt.Rig(); }
    }

    private static String tr(String key, Object... a) { return Component.translatable(key, a).getString(); }

    // ---------------------------------------------------------------- flow
    @Override
    public void reset() {
        score = 0; over = false; won = false; draw = false; matchWinner = -1;
        screen = MENU; menuSel = 0; vsT = 0; overWait = 0;
        parts.clear(); shake = 0; flash = 0; lines = 0; jingle = 0;
        java.util.Arrays.fill(prevKey, false);
        show[0].ch = FightSim.CAT; show[1].ch = FightSim.FOX;
    }

    private void startSelect(int m) {
        mode = m; screen = SELECT; selStep = 0; cursor = 0;
        pick[0] = 0; pick[1] = 1;
        pling(1.2F);
    }

    private void startMatch() {
        int c0 = pick[0], c1 = pick[1];
        if (mode == 0) {                                      // the computer takes another animal
            int c;
            do { c = rnd.nextInt(FightSim.CHARS); } while (c == c0 && rnd.nextInt(3) != 0);
            c1 = c;
        }
        pick[1] = c1;
        sim = new FightSim(c0, c1, rnd.nextInt(FightArt.STAGES));
        bot = mode == 0 ? new FightBot(level, rnd.nextLong()) : null;
        for (int i = 0; i < 2; i++) { rig[i].snap(sim.p[i], 0); trail[i] = 100; }
        screen = VS; vsT = 0; overWait = 0; parts.clear(); evBuf.clear(); sim.events.clear();
        won = false; draw = false; matchWinner = -1; score = 0; over = false;
        sound(SoundEvents.BELL_BLOCK, 0.6F, 0.7F);
    }

    private void finish() {
        matchWinner = sim.matchWinner;
        if (mode == 0) {
            won = matchWinner == 0;
            draw = matchWinner == 2;
            if (won) score = WIN_SCORE[level] + 10 * sim.p[0].perfects;
            else score = 8 * sim.p[0].wins + (draw ? 10 : 0);
        } else {
            score = 0;
            draw = matchWinner == 2;
        }
        over = true;
    }

    @Override
    public boolean isWin() { return mode == 0 && won; }

    @Override
    public Component endTitle() {
        if (draw) return Component.translatable("cutemod.fight.draw");
        if (mode == 0) return Component.translatable(won ? "cutemod.fight.victory" : "cutemod.fight.defeat");
        return Component.translatable("cutemod.fight.p_wins", matchWinner + 1);
    }

    @Override
    public Component status() {
        if (screen != FIGHT || sim == null) return Component.translatable("cutemod.fight.title");
        return Component.translatable("cutemod.fight.status", sim.round, sim.p[0].wins, sim.p[1].wins);
    }

    @Override
    public String hintKey() { return "cutemod.hint.fighters"; }

    // ---------------------------------------------------------------- keys
    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private boolean edge(int slot, boolean now) {
        boolean e = now && !prevKey[slot];
        prevKey[slot] = now;
        return e;
    }

    private void readInputs() {
        boolean vsBot = mode == 0;
        boolean l1 = down(65) || (vsBot && down(263)), r1 = down(68) || (vsBot && down(262)), u1 = down(87) || (vsBot && down(265)), d1 = down(83) || (vsBot && down(264));
        boolean pu1 = edge(0, down(70) || (vsBot && down(74))), ki1 = edge(1, down(71) || (vsBot && down(75))), sp1 = edge(2, down(72) || (vsBot && down(76)));
        sim.setInput(0, l1, r1, u1, d1, pu1, ki1, sp1);
        if (vsBot) {
            bot.act(sim, 1);
        } else {
            boolean pu2 = edge(3, down(74)), ki2 = edge(4, down(75)), sp2 = edge(5, down(76));
            sim.setInput(1, down(263), down(262), down(265), down(264), pu2, ki2, sp2);
        }
    }

    @Override
    public boolean key(int k) {
        switch (screen) {
            case MENU -> {
                switch (k) {
                    case 265, 87 -> { menuSel = 0; beep(); }
                    case 264, 83 -> { menuSel = 1; beep(); }
                    case 263, 65 -> { level = Math.max(0, level - 1); beep(); }
                    case 262, 68 -> { level = Math.min(2, level + 1); beep(); }
                    case 257, 32 -> startSelect(menuSel);
                    default -> { return false; }
                }
                return true;
            }
            case SELECT -> {
                switch (k) {
                    case 263, 65 -> { cursor = (cursor + 3) % 4; beep(); }
                    case 262, 68 -> { cursor = (cursor + 1) % 4; beep(); }
                    case 257, 32, 70, 74 -> choose(cursor);
                    case 259 -> back();
                    default -> { return false; }
                }
                return true;
            }
            case FIGHT, VS -> {
                return k == 65 || k == 68 || k == 87 || k == 83 || (k >= 70 && k <= 72) || (k >= 74 && k <= 76) || (k >= 262 && k <= 265);
            }
            default -> { return false; }
        }
    }

    private void back() {
        if (selStep == 1) { selStep = 0; cursor = pick[0]; } else screen = MENU;
        beep();
    }

    private void choose(int c) {
        pick[selStep] = c;
        pling(1.3F + selStep * 0.2F);
        if (mode == 1 && selStep == 0) { selStep = 1; cursor = (c + 1) % 4; return; }
        startMatch();
    }

    // ---------------------------------------------------------------- mouse
    private static final int BW = 104, BH = 16, BX = (W - BW) / 2;
    private static final int CW = 48, CG = 6, CX0 = (W - (4 * CW + 3 * CG)) / 2, CY = 22, CH = 82;

    @Override
    public boolean click(int x, int y, int button) {
        if (screen == MENU) {
            if (in(x, y, BX, 62, BW, BH)) { menuSel = 0; startSelect(0); return true; }
            if (in(x, y, BX, 82, BW, BH)) { menuSel = 1; startSelect(1); return true; }
            for (int i = 0; i < 3; i++) if (in(x, y, BX + i * 36, 102, 32, 13)) { level = i; beep(); return true; }
        } else if (screen == SELECT) {
            if (in(x, y, 4, 4, 34, 13)) { back(); return true; }
            for (int i = 0; i < 4; i++) if (in(x, y, CX0 + i * (CW + CG), CY, CW, CH)) { cursor = i; choose(i); return true; }
        }
        return false;
    }

    // ---------------------------------------------------------------- ticks
    @Override
    public void tick() {
        anim++;
        if (shake > 0) shake--;
        if (flash > 0) flash--;
        if (lines > 0) lines--;
        if (jingle > 0) {
            jingle--;
            if (jingle == 20) pling(1.0F);
            if (jingle == 12) pling(1.26F);
            if (jingle == 4) pling(1.5F);
        }
        switch (screen) {
            case MENU, SELECT -> showTick();
            case VS -> {
                vsT++;
                for (int i = 0; i < 2; i++) rig[i].update(sim.p[i], anim);
                if (vsT >= 85) { screen = FIGHT; sim.events.clear(); }
            }
            case FIGHT -> fightTick();
            default -> { }
        }
        stepParts();
    }

    private void showTick() {
        // the demo fighters bob, and one of them throws a punch now and then
        for (int i = 0; i < 4; i++) {
            FightSim.F f = show[i];
            f.state = FightSim.IDLE; f.move = null; f.y = 0; f.face = 1;
        }
        if (screen == MENU) {
            show[0].face = 1; show[1].face = -1; show[1].ch = FightSim.FOX; show[0].ch = FightSim.CAT;
            int c = anim % 260;                      // they warm up: a punch, a kick, a happy hop
            if (c >= 70 && c < 92) { show[0].state = FightSim.ATTACK; show[0].move = FightSim.PUNCH; show[0].moveT = c - 70; }
            if (c == 74) sound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.5F, 0.3F);
            if (c >= 160 && c < 190) { show[1].state = FightSim.ATTACK; show[1].move = FightSim.KICK; show[1].moveT = (c - 160) / 2; }
            if (c == 166) sound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.05F, 0.3F);
            if (c >= 215 && c < 250) { show[0].state = FightSim.WIN; show[1].state = FightSim.WIN; }
            rig[0].update(show[0], anim); rig[1].update(show[1], anim);
            return;
        }
        for (int i = 0; i < 4; i++) {
            show[i].ch = i; show[i].face = 1;
            boolean hot = i == cursor;
            if (hot) {
                int c = anim % 90;
                if (c >= 50 && c < 72) { show[i].state = FightSim.ATTACK; show[i].move = FightSim.PUNCH; show[i].moveT = c - 50; }
            }
            showRig[i].update(show[i], anim + i * 17);
        }
    }

    private void fightTick() {
        if (sim.phase == FightSim.PH_FIGHT || sim.phase == FightSim.PH_INTRO) readInputs();
        else { sim.setInput(0, false, false, false, false, false, false, false); sim.setInput(1, false, false, false, false, false, false, false); }
        sim.tick();
        for (int i = 0; i < 2; i++) {
            rig[i].update(sim.p[i], anim);
            trail[i] += (sim.p[i].hp - trail[i]) * (trail[i] > sim.p[i].hp ? 0.025F : 1F);
        }
        evBuf.clear();
        sim.takeEvents(evBuf);
        for (FightSim.Ev e : evBuf) handle(e);
        // walking dust
        for (int i = 0; i < 2; i++) {
            FightSim.F f = sim.p[i];
            if (f.state == FightSim.WALK && anim % 11 == 0 && Math.abs(f.vx) > 0.5F) dust(f.x - f.face * 4, FightSim.FLOOR, 1);
        }
        if (sim.phase == FightSim.PH_OVER && ++overWait > 8 && !over) finish();
    }

    // ---------------------------------------------------------------- events: sounds and sparks
    private void handle(FightSim.Ev e) {
        switch (e.type) {
            case FightSim.EV_ROUND -> { sound(SoundEvents.NOTE_BLOCK_BELL, 0.8F, 0.5F); trail[0] = trail[1] = 100; }
            case FightSim.EV_FIGHT -> { sound(SoundEvents.BELL_BLOCK, 0.75F, 0.9F); pling(1.7F); flash = 5; }
            case FightSim.EV_ATTACK -> {
                if (e.a != FightSim.M_SPECIAL) sound(SoundEvents.PLAYER_ATTACK_SWEEP, e.a == FightSim.M_KICK || e.a == FightSim.M_CKICK ? 1.05F : 1.5F, 0.45F);
            }
            case FightSim.EV_SPECIAL -> {
                lines = 16; linesColor = FightArt.GLOW[e.b] & 0xFFFFFF;
                sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.7F, 0.6F);
                switch (e.b) {
                    case FightSim.CAT -> { sound(SoundEvents.PLAYER_ATTACK_SWEEP, 0.8F, 0.7F); sound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.7F, 0.25F); }
                    case FightSim.FOX -> sound(SoundEvents.BLAZE_SHOOT, 1.25F, 0.6F);
                    case FightSim.PANDA -> sound(SoundEvents.NOTE_BLOCK_BASEDRUM, 0.5F, 0.8F);
                    default -> { sound(SoundEvents.RABBIT_JUMP, 1.2F, 0.8F); sound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.8F, 0.5F); }
                }
                text(e.x, e.y - 12, tr("cutemod.fight.sp." + e.b), 0xFF000000 | FightArt.GLOW[e.b]);
            }
            case FightSim.EV_HIT, FightSim.EV_PROJHIT -> {
                int pw = e.a;
                sound(pw == 1 ? SoundEvents.PLAYER_ATTACK_WEAK : pw == 2 ? SoundEvents.PLAYER_ATTACK_STRONG : SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.0F + rnd.nextFloat() * 0.2F, 0.6F);
                if (pw >= 2) sound(SoundEvents.NOTE_BLOCK_BASEDRUM, 0.7F, 0.45F);
                if (pw == 3) sound(SoundEvents.PLAYER_ATTACK_CRIT, 0.9F, 0.6F);
                spark(e.x, e.y, pw, e.b == 1);
                shake = 3 + pw * 2; shakeMag = pw >= 3 ? 2 : 1;
            }
            case FightSim.EV_BLOCK -> {
                sound(SoundEvents.SHIELD_BLOCK, 1.3F, 0.6F);
                sparkBlock(e.x, e.y);
            }
            case FightSim.EV_COUNTER -> { text(e.x, e.y, tr("cutemod.fight.counter"), 0xFFFFE27A); pling(1.8F); }
            case FightSim.EV_JUMP -> { sound(SoundEvents.SLIME_JUMP_SMALL, 1.6F, 0.3F); dust(e.x, FightSim.FLOOR, 3); }
            case FightSim.EV_LAND -> {
                sound(SoundEvents.STONE_STEP, 0.6F, e.a == 1 ? 0.5F : 0.25F);
                dust(e.x, FightSim.FLOOR, e.a == 1 ? 6 : 3);
            }
            case FightSim.EV_DOWN -> { sound(SoundEvents.NOTE_BLOCK_BASEDRUM, 0.55F, 0.5F); ring(e.x, FightSim.FLOOR, 14, 0xFFFFE8C8, true); }
            case FightSim.EV_SHOCK -> {
                sound(SoundEvents.GENERIC_EXPLODE, 1.7F, 0.3F);
                ring(e.x, FightSim.FLOOR - 1, 26, 0xFF7BE06A, true);
                ring(e.x, FightSim.FLOOR - 1, 16, 0xFFFFFFFF, true);
                dust(e.x, FightSim.FLOOR, 8);
                shake = 8; shakeMag = 2;
            }
            case FightSim.EV_RISE -> dust(e.x, FightSim.FLOOR, 4);
            case FightSim.EV_DASH -> { lines = 12; linesColor = 0xFFC24A; }
            case FightSim.EV_KO -> {
                flash = 10; shake = 18; shakeMag = 2;
                sound(SoundEvents.GENERIC_EXPLODE, 0.9F, 0.5F);
                sound(SoundEvents.BELL_BLOCK, 0.5F, 0.8F);
                for (int i = 0; i < 24; i++) bit(e.x, 60, 0xFFFFE27A);
                ring(e.x, 60, 40, 0xFFFFFFFF, false);
            }
            case FightSim.EV_TIMEUP -> { sound(SoundEvents.BELL_BLOCK, 0.9F, 0.8F); sound(SoundEvents.BELL_BLOCK, 0.7F, 0.6F); }
            case FightSim.EV_WIN -> { if (e.a >= 0) jingle = 24; else sound(SoundEvents.VILLAGER_NO, 1.2F, 0.4F); }
            case FightSim.EV_NOMETER -> sound(SoundEvents.VILLAGER_NO, 1.6F, 0.35F);
            default -> { }
        }
    }

    // ---------------------------------------------------------------- particles
    private P add(int type, float x, float y, int life, int color, int size) {
        P p = new P();
        p.type = type; p.x = x; p.y = y; p.life = life; p.max = life; p.color = color; p.size = size;
        if (parts.size() > 220) parts.remove(0);
        parts.add(p);
        return p;
    }

    private void spark(float x, float y, int power, boolean counter) {
        P s = add(P_STAR, x, y, 9 + power * 2, counter ? 0xFFFFE27A : power == 3 ? 0xFFFF7A4A : 0xFFFFD866, 5 + power * 3);
        s.vx = rnd.nextFloat() * 6.28F;
        int n = 5 + power * 3;
        for (int i = 0; i < n; i++) bit(x, y, rnd.nextInt(3) == 0 ? 0xFFFFFFFF : rnd.nextBoolean() ? 0xFFFFD866 : 0xFFFF8FB8);
        if (power >= 3) ring(x, y, 22, 0xFFFFC24A, false);
    }

    private void sparkBlock(float x, float y) {
        P s = add(P_RING, x, y, 10, 0xFF7ED8FF, 13);
        s.vx = 0;
        ring(x, y, 8, 0xFFFFFFFF, false);
        for (int i = 0; i < 6; i++) bit(x, y, 0xFF9FE6FF);
    }

    private void bit(float x, float y, int color) {
        P b = add(P_BIT, x, y, 14 + rnd.nextInt(12), color, 1 + rnd.nextInt(2));
        double a = rnd.nextFloat() * Math.PI * 2;
        float sp = 0.8F + rnd.nextFloat() * 2.2F;
        b.vx = (float) Math.cos(a) * sp; b.vy = (float) Math.sin(a) * sp - 0.6F;
    }

    private void ring(float x, float y, int size, int color, boolean flat) {
        add(flat ? P_FLAT : P_RING, x, y, 12, color, size);
    }

    private void dust(float x, float y, int n) {
        for (int i = 0; i < n; i++) {
            P d = add(P_DUST, x + rnd.nextInt(9) - 4, y - 1, 16 + rnd.nextInt(8), 0xFFEADFCB, 2 + rnd.nextInt(2));
            d.vx = (rnd.nextFloat() - 0.5F) * 1.2F; d.vy = -0.15F - rnd.nextFloat() * 0.25F;
        }
    }

    private void text(float x, float y, String s, int color) {
        P t = add(P_TEXT, x, y, 44, color, 0);
        t.text = s; t.vy = -0.35F;
    }

    private void stepParts() {
        for (int i = parts.size() - 1; i >= 0; i--) {
            P p = parts.get(i);
            p.x += p.vx; p.y += p.vy;
            if (p.type == P_BIT) { p.vy += 0.12F; p.vx *= 0.97F; }
            if (--p.life <= 0) parts.remove(i);
        }
    }

    private void drawParts(GuiGraphics g) {
        for (P p : parts) {
            float age = 1F - p.life / (float) p.max;
            int x = Math.round(p.x), y = Math.round(p.y);
            switch (p.type) {
                case P_STAR -> {
                    float r = p.size * (age < 0.3F ? 0.6F + age * 1.3F : 1F - (age - 0.3F) * 0.9F);
                    int a = Math.round(255 * Math.min(1F, (1F - age) * 1.6F));
                    star(g, x, y, r + 1.5F, p.vx + age * 0.6F, Gfx.alpha(p.color, a));
                    star(g, x, y, r * 0.62F, p.vx + age * 0.6F, Gfx.alpha(0xFFFFFFFF, a));
                }
                case P_BIT -> g.fill(x, y, x + p.size, y + p.size, Gfx.alpha(p.color, Math.round(255 * Math.min(1F, p.life / 8F))));
                case P_RING, P_FLAT -> {
                    float r = p.size * (0.25F + age * 0.85F);
                    float ry = p.type == P_FLAT ? r * 0.28F : r;
                    int col = Gfx.alpha(p.color, Math.round(220 * (1F - age)));
                    int steps = Math.max(12, (int) (r * 2.4F));
                    for (int k = 0; k < steps; k++) {
                        double an = k * Math.PI * 2 / steps;
                        int px = x + (int) Math.round(Math.cos(an) * r), py = y + (int) Math.round(Math.sin(an) * ry);
                        g.fill(px, py, px + 1, py + 1, col);
                        if (p.type == P_RING && age < 0.5F) g.fill(px, py + 1, px + 1, py + 2, col);
                    }
                }
                case P_DUST -> {
                    int r = Math.max(1, Math.round(p.size * (0.6F + age * 1.2F)));
                    Gfx.disc(g, x, y, r, Gfx.alpha(p.color, Math.round(110 * (1F - age))));
                }
                case P_TEXT -> {
                    int w = tw(p.text);
                    int a = Math.round(255 * Math.min(1F, p.life / 14F));
                    CuteFont.draw(g, font(), p.text, x - w / 2 + 1, y + 1, Gfx.alpha(0xFF2A1F3D, a), false);
                    CuteFont.draw(g, font(), p.text, x - w / 2, y, Gfx.alpha(p.color, a), false);
                }
                default -> { }
            }
        }
    }

    private static void star(GuiGraphics g, int cx, int cy, float r, float rot, int color) {
        int n = 8;
        int[] xs = new int[n * 2], ys = new int[n * 2];
        for (int i = 0; i < n * 2; i++) {
            double a = rot + i * Math.PI / n;
            float rr = (i & 1) == 0 ? r : r * 0.42F;
            xs[i] = cx + (int) Math.round(Math.cos(a) * rr);
            ys[i] = cy + (int) Math.round(Math.sin(a) * rr);
        }
        Gfx.poly(g, xs, ys, color);
    }

    // ---------------------------------------------------------------- drawing
    private void big(GuiGraphics g, String s, int cx, int cy, float sc, int color, int outline) {
        int w = tw(s);
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().scale(sc, sc, 1F);
        int x = -w / 2, y = -4;
        if ((outline >>> 24) != 0) {
            int[][] o = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {1, 1}, {-1, 1}, {1, -1}, {-1, -1}, {0, 2}, {1, 2}};
            for (int[] d : o) CuteFont.draw(g, font(), s, x + d[0], y + d[1], outline, false);
        }
        CuteFont.draw(g, font(), s, x, y, color, false);
        g.pose().popPose();
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean hot, int face) {
        Gfx.shadow(g, x, y, w, h, 3);
        Gfx.bubble(g, x, y, w, h, 4, hot ? Gfx.lighter(face, 0.25F) : face);
        if (hot) Gfx.outline(g, x - 1, y - 1, w + 2, h + 2, 0xFFFFE27A);
        ctextW(g, label, x + w / 2, y + (h - 8) / 2, w - 6, 0xFFFFFFFF);
    }

    @Override
    public void render(GuiGraphics g) {
        switch (screen) {
            case MENU -> renderMenu(g);
            case SELECT -> renderSelect(g);
            case VS -> renderVs(g);
            default -> renderFight(g);
        }
    }

    private void renderShow(GuiGraphics g, FightSim.F f, FightArt.Rig r, int x, int feet, int t) {
        f.x = x;
        g.pose().pushPose();
        g.pose().translate(0, feet - FightSim.FLOOR, 0);
        FightArt.fighter(g, f, r, t, 0, 0, 1F);
        g.pose().popPose();
    }

    private void renderMenu(GuiGraphics g) {
        FightArt.stage(g, 0, anim, 0);
        g.fillGradient(0, 0, W, H, Gfx.alpha(0xFF140A2E, 70), Gfx.alpha(0xFF140A2E, 150));
        renderShow(g, show[0], rig[0], 32, FightSim.FLOOR, anim);
        renderShow(g, show[1], rig[1], 188, FightSim.FLOOR, anim + 40);
        drawParts(g);
        // the title
        int bob = Math.round((float) Math.sin(anim * 0.06F) * 1.5F);
        String title = tr("cutemod.fight.title");
        big(g, title, W / 2, 22 + bob, Math.min(2.3F, (W - 16F) / Math.max(1, tw(title))), 0xFFFFE27A, 0xFF8A1E3A);
        big(g, tr("cutemod.fight.tag"), W / 2, 40, 0.8F, 0xFFFFC8E0, 0xFF3A1A4A);
        Gfx.sparkle(g, 30, 14, 3, anim, 0xFFFFFFFF);
        Gfx.sparkle(g, 190, 30, 3, anim + 30, 0xFFFFE27A);
        // the buttons
        button(g, BX, 62, BW, BH, tr("cutemod.fight.vs_bot"), menuSel == 0 || in(mx, my, BX, 62, BW, BH), 0xFFE0484F);
        button(g, BX, 82, BW, BH, tr("cutemod.fight.two"), menuSel == 1 || in(mx, my, BX, 82, BW, BH), 0xFF3C7DD9);
        for (int i = 0; i < 3; i++) {
            boolean sel = level == i;
            button(g, BX + i * 36, 102, 32, 13, tr("cutemod.fight.lvl." + i), sel, sel ? 0xFF3FA66B : 0xFF5A4A72);
        }
        ctextW(g, tr("cutemod.fight.keys"), W / 2, 124, W - 10, 0xFFFFE8F4);
    }

    private void renderSelect(GuiGraphics g) {
        FightArt.stage(g, 2, anim, 0);
        g.fillGradient(0, 0, W, H, Gfx.alpha(0xFF140A2E, 150), Gfx.alpha(0xFF140A2E, 210));
        String head = mode == 1 ? tr("cutemod.fight.pick_p", selStep + 1) : tr("cutemod.fight.pick");
        big(g, head, W / 2, 11, 1.15F, 0xFFFFE27A, 0xFF3A1A4A);
        button(g, 4, 4, 34, 13, tr("cutemod.fight.back"), in(mx, my, 4, 4, 34, 13), 0xFF5A4A72);
        for (int i = 0; i < 4; i++) {
            int x = CX0 + i * (CW + CG);
            boolean hot = i == cursor || in(mx, my, x, CY, CW, CH);
            int c = FightArt.GI[i];
            Gfx.shadow(g, x, CY, CW, CH, 3);
            Gfx.rrect(g, x - 1, CY - 1, CW + 2, CH + 2, 4, hot ? 0xFFFFE27A : 0xFF2A1F3D);
            g.fillGradient(x + 1, CY + 1, x + CW - 1, CY + CH - 1, Gfx.mix(c, 0xFFFFFFFF, hot ? 0.35F : 0.1F), Gfx.darker(c, hot ? 0.45F : 0.6F));
            Gfx.ellipse(g, x + CW / 2, CY + 62, 15, 3, Gfx.alpha(0xFF000000, 70));
            renderShow(g, show[i], showRig[i], x + CW / 2, CY + 62, anim + i * 17);
            ctextW(g, tr("cutemod.fight.name." + i), x + CW / 2, CY + 66, CW - 4, 0xFFFFFFFF);
            // three little stats
            float[] st = {FightSim.SPEED[i] / 1.25F, FightSim.DMG[i] / 1.25F, FightSim.JUMP_V[i] / 4.1F};
            int[] sc = {0xFF7BE0FF, 0xFFFF7A6A, 0xFFFFE27A};
            for (int k = 0; k < 3; k++) {
                int bx = x + 6 + k * 14;
                g.fill(bx, CY + CH - 7, bx + 12, CY + CH - 4, 0xFF140A2E);
                g.fill(bx, CY + CH - 7, bx + Math.round(12 * Math.min(1F, st[k])), CY + CH - 4, sc[k]);
            }
            if (selStep == 1 && pick[0] == i) {
                Gfx.rrect(g, x + 2, CY + 2, 14, 9, 2, 0xFF3C7DD9);
                ctext(g, "P1", x + 9, CY + 3, 0xFFFFFFFF);
            }
        }
        // the special of the animal under the cursor
        int c = cursor;
        ctextW(g, tr("cutemod.fight.special", tr("cutemod.fight.sp." + c)), W / 2, 110, W - 10, 0xFF000000 | FightArt.GLOW[c]);
        ctextW(g, tr("cutemod.fight.sp." + c + ".d"), W / 2, 121, W - 6, 0xFFE8DCF4);
    }

    private void renderVs(GuiGraphics g) {
        int par = Math.round((sim.p[0].x + sim.p[1].x) / 2F - 110F);
        FightArt.stage(g, sim.stage, anim, par);
        float k = Math.min(1F, vsT / 14F);                       // the fighters slide in
        float out = vsT > 70 ? (vsT - 70) / 15F : 0F;            // and out again
        g.fillGradient(0, 0, W, H, Gfx.alpha(0xFF0A0418, 150), Gfx.alpha(0xFF0A0418, 200));
        for (int i = 0; i < 2; i++) {
            FightSim.F f = sim.p[i];
            int dir = i == 0 ? 1 : -1;
            int homeX = i == 0 ? 62 : W - 62;
            int bx = Math.round(homeX - dir * (1F - k) * 150 - dir * out * 150);
            FightSim.F tmp = show[i];
            tmp.ch = f.ch; tmp.face = dir; tmp.state = FightSim.IDLE; tmp.move = null; tmp.y = 0;
            rig[i].update(tmp, anim);
            renderShow(g, tmp, rig[i], bx, FightSim.FLOOR - 4, anim + i * 20);
            // the name plate slides in from its side
            String nm = tr("cutemod.fight.name." + f.ch);
            int plateW = 92, py = 24;
            int px = i == 0 ? Math.round(-plateW + (plateW) * k - out * plateW) : Math.round(W - plateW * k + out * plateW);
            g.fill(px, py, px + plateW, py + 15, Gfx.alpha(i == 0 ? 0xFF3C7DD9 : 0xFFE0484F, 215));
            g.fill(px, py + 15, px + plateW, py + 16, Gfx.alpha(0xFFFFFFFF, 120));
            int tx = i == 0 ? px + 6 : px + plateW - 6 - tw(nm);
            CuteFont.draw(g, font(), nm, tx, py + 4, 0xFFFFFFFF, true);
            String tag = i == 0 ? "P1" : (mode == 0 ? tr("cutemod.fight.cpu") : "P2");
            CuteFont.draw(g, font(), tag, i == 0 ? px + plateW - 6 - tw(tag) : px + 6, py + 4, 0xFFFFE27A, false);
        }
        float pulse = 1.6F + 0.15F * (float) Math.sin(vsT * 0.3F);
        if (vsT > 10) big(g, "VS", W / 2, 66, pulse * Math.min(1F, (vsT - 10) / 8F), 0xFFFFE27A, 0xFF8A1E3A);
        ctextW(g, tr("cutemod.fight.stage." + sim.stage), W / 2, 124, W - 10, Gfx.alpha(0xFFFFE8F4, Math.round(255 * Math.min(1F, vsT / 20F))));
    }

    private void renderFight(GuiGraphics g) {
        int par = Math.round((sim.p[0].x + sim.p[1].x) / 2F - 110F);
        g.pose().pushPose();
        if (shake > 0) g.pose().translate((rnd.nextInt(3) - 1) * shakeMag, (rnd.nextInt(3) - 1) * shakeMag, 0);
        FightArt.stage(g, sim.stage, anim, par);
        // the one who is attacking is in front
        int first = sim.p[0].state == FightSim.ATTACK && sim.p[1].state != FightSim.ATTACK ? 1 : 0;
        for (int n = 0; n < 2; n++) drawFighter(g, n == 0 ? first : 1 - first);
        for (FightSim.Proj b : sim.proj) drawFireball(g, b);
        drawParts(g);
        g.pose().popPose();
        if (lines > 0) speedLines(g);
        FightArt.vignette(g, W, H, sim.phase == FightSim.PH_KO ? 120 : 70);
        hud(g);
        overlays(g);
        if (flash > 0) g.fill(0, 0, W, H, Gfx.alpha(0xFFFFFFFF, Math.min(200, flash * 20)));
    }

    private void drawFighter(GuiGraphics g, int i) {
        FightSim.F f = sim.p[i];
        FightArt.Rig r = rig[i];
        if (f.state == FightSim.ATTACK && f.ch == FightSim.CAT && f.move != null && f.move.id == FightSim.M_SPECIAL && f.moveT > f.move.startup) {
            float save = f.x;
            for (int k = 3; k >= 1; k--) {
                f.x = save - f.face * k * 7;
                FightArt.fighter(g, f, r, anim, 0xFFFF9EC8, 0.7F, 0.16F + 0.06F * (4 - k));
            }
            f.x = save;
        }
        // the trail of a punch or a kick
        if (r.trail > 1) {
            for (int k = 0; k < r.trail - 1 && k < 5; k++) {
                int x0 = Math.round(r.tx[k]), y0 = FightSim.FLOOR - Math.round(r.ty[k]), x1 = Math.round(r.tx[k + 1]), y1 = FightSim.FLOOR - Math.round(r.ty[k + 1]);
                int a = 200 - k * 40;
                FightArt.thick(g, x0, y0, x1, y1, 3 - k / 2, Gfx.alpha(0xFFFFFFFF, Math.max(30, a)));
            }
        }
        float amt = f.flash > 0 ? Math.min(0.85F, f.flash / 7F) : 0F;
        FightArt.fighter(g, f, r, anim, 0xFFFFFFFF, amt, 1F);
        // a block shield
        if (f.state == FightSim.BLOCKSTUN && f.stateT < 8) {
            int sx = Math.round(f.x + f.face * 9), sy = FightSim.FLOOR - Math.round(f.y) - (f.in.down ? 12 : 20);
            Gfx.glow(g, sx, sy, 10, 0x7ED8FF, 110 - f.stateT * 10);
        }
        // dizzy stars over a knocked out fighter
        if (f.state == FightSim.KO || (f.state == FightSim.LYING && f.hp <= 0)) {
            for (int k = 0; k < 3; k++) {
                double a = anim * 0.12 + k * 2.1;
                int sx = Math.round(f.x - f.face * 10 + (float) Math.cos(a) * 8), sy = FightSim.FLOOR - 9 + Math.round((float) Math.sin(a) * 3);
                Gfx.sparkle(g, sx, sy, 2, anim + k * 9, 0xFFFFE27A);
            }
        }
    }

    private void drawFireball(GuiGraphics g, FightSim.Proj b) {
        int x = Math.round(b.x), y = FightSim.FLOOR - Math.round(b.y), d = b.vx > 0 ? 1 : -1;
        Gfx.glow(g, x, y, 12, 0xFF7A2E, 140);
        for (int k = 5; k >= 1; k--) {
            int r = Math.max(1, 4 - k / 2);
            Gfx.disc(g, x - d * k * 3, y + (k % 2) - (anim % 3 == 0 ? 1 : 0), r, Gfx.alpha(k > 3 ? 0xFFFF6A2E : 0xFFFFB347, 190 - k * 28));
        }
        Gfx.ball(g, x, y, 5, 0xFFFF9A3C);
        Gfx.disc(g, x + d, y - 1, 2, 0xFFFFF0B0);
        if (anim % 2 == 0) {
            P e = add(P_EMBER, x - d * 4, y, 10, 0xFFFFB347, 1);
            e.vy = -0.3F; e.vx = -d * 0.3F;
        }
    }

    private void speedLines(GuiGraphics g) {
        for (int i = 0; i < 12; i++) {
            int y = 8 + (i * 37 + anim * 7) % 120;
            int len = 40 + (i * 23) % 60, x = (i * 53 + anim * 19) % (W + 40) - 40;
            g.fill(x, y, x + len, y + 1, Gfx.alpha(0xFF000000 | linesColor, 40 + (lines * 4)));
        }
    }

    // ---------------------------------------------------------------- the HUD
    private void hud(GuiGraphics g) {
        for (int i = 0; i < 2; i++) {
            FightSim.F f = sim.p[i];
            boolean right = i == 1;
            int bx = right ? 124 : 22, bw = 74;
            hpBar(g, bx, 7, bw, 9, f.hp, trail[i], right);
            int pcx = right ? W - 12 : 12;
            FightArt.portrait(g, f.ch, pcx, 12, 8);
            // the name under the bar
            String nm = tr("cutemod.fight.name." + f.ch) + (mode == 0 && i == 1 ? " (" + tr("cutemod.fight.cpu") + ")" : "");
            int nx = right ? bx + bw - tw(nm) : bx;
            CuteFont.draw(g, font(), nm, nx + 1, 18, 0xFF2A1F3D, false);
            CuteFont.draw(g, font(), nm, nx, 17, 0xFFFFF4E0, false);
            // rounds won
            for (int k = 0; k < 2; k++) {
                int sx = right ? bx + 5 + k * 9 : bx + bw - 5 - k * 9;
                boolean on = f.wins > k;
                Gfx.star5(g, sx, 25, 4, 2, on ? 0xFFFFE27A : 0xFF4A3A5A);
            }
            // the power meter
            int mx0 = right ? W - 8 - 66 : 8, my0 = H - 11;
            g.fill(mx0 - 1, my0 - 1, mx0 + 67, my0 + 6, 0xFF1A1226);
            g.fill(mx0, my0, mx0 + 66, my0 + 5, 0xFF3A2A4A);
            int fw = Math.round(66 * f.meter / FightSim.METER_MAX);
            boolean ready = f.meter >= FightSim.SP_COST;
            int c1 = ready ? 0xFFFFE27A : 0xFF7BA8FF, c2 = ready ? 0xFFFF9A3C : 0xFF4A6AD0;
            if (right) g.fillGradient(mx0 + 66 - fw, my0, mx0 + 66, my0 + 5, c1, c2); else g.fillGradient(mx0, my0, mx0 + fw, my0 + 5, c1, c2);
            int tick = Math.round(66 * FightSim.SP_COST / FightSim.METER_MAX);
            g.fill(right ? mx0 + 66 - tick : mx0 + tick, my0, (right ? mx0 + 66 - tick : mx0 + tick) + 1, my0 + 5, 0xFF1A1226);
            if (ready && anim % 40 < 20) Gfx.sparkle(g, right ? mx0 + 66 - fw : mx0 + fw, my0 + 2, 3, anim, 0xFFFFFFFF);
            CuteFont.draw(g, font(), "SP", right ? mx0 - 14 : mx0 + 69, my0 - 2, ready ? 0xFFFFE27A : 0xFFB8B0C8, false);
            // combo
            if (f.comboShow > 0 && f.comboHits >= 2) {
                float pop = 1F + 0.5F * Math.max(0, (f.comboShow - 92) / 8F);
                String cs = tr("cutemod.fight.hits", f.comboHits);
                big(g, cs, right ? W - 8 - tw(cs) / 2 : 8 + tw(cs) / 2, 38, 1.1F * pop, 0xFFFFE27A, 0xFF8A1E3A);
            }
        }
        // the clock
        int secs = Math.max(0, (sim.timer + 59) / 60);
        boolean low = secs <= 10 && sim.phase == FightSim.PH_FIGHT;
        Gfx.rrect(g, 98, 3, 24, 19, 5, 0xFF1A1226);
        Gfx.rrect(g, 99, 4, 22, 17, 4, low && anim % 20 < 10 ? 0xFF7A2030 : 0xFF3A2A5A);
        g.fill(100, 5, 120, 6, Gfx.alpha(0xFFFFFFFF, 60));
        big(g, Integer.toString(secs), 110, 13, 1.25F, low ? 0xFFFF8A8A : 0xFFFFE27A, 0xFF1A1226);
    }

    private void hpBar(GuiGraphics g, int x, int y, int w, int h, float hp, float tr, boolean right) {
        Gfx.rrect(g, x - 2, y - 2, w + 4, h + 4, 3, 0xFF1A1226);
        Gfx.rrect(g, x - 1, y - 1, w + 2, h + 2, 2, 0xFFFFE8B0);
        g.fill(x, y, x + w, y + h, 0xFF2A1F3D);
        int hw = Math.round(w * hp / 100F), tw2 = Math.round(w * tr / 100F);
        int top, bot;
        if (hp > 50) { top = 0xFF9CF58A; bot = 0xFF3DBE5E; }
        else if (hp > 25) { top = 0xFFFFE87A; bot = 0xFFF0A830; }
        else { top = anim % 16 < 8 ? 0xFFFF9A8A : 0xFFFF7A6A; bot = 0xFFD83A4A; }
        if (right) {
            g.fill(x + w - tw2, y, x + w, y + h, 0xFFFF6A5A);
            g.fillGradient(x + w - hw, y, x + w, y + h, top, bot);
            g.fill(x + w - hw, y, x + w, y + 2, Gfx.alpha(0xFFFFFFFF, 80));
        } else {
            g.fill(x, y, x + tw2, y + h, 0xFFFF6A5A);
            g.fillGradient(x, y, x + hw, y + h, top, bot);
            g.fill(x, y, x + hw, y + 2, Gfx.alpha(0xFFFFFFFF, 80));
        }
        for (int k = 1; k < 4; k++) g.fill(x + w * k / 4, y, x + w * k / 4 + 1, y + h, Gfx.alpha(0xFF1A1226, 120));
    }

    private void overlays(GuiGraphics g) {
        int t = sim.phaseT;
        switch (sim.phase) {
            case FightSim.PH_INTRO -> {
                boolean last = sim.p[0].wins == 1 && sim.p[1].wins == 1;
                String s = last ? tr("cutemod.fight.final") : tr("cutemod.fight.round", sim.round);
                float sc = 1.5F + Math.max(0, 14 - t) * 0.12F;
                int a = t < 70 ? 255 : Math.max(0, 255 - (t - 70) * 14);
                if (a > 0) {
                    big(g, s, W / 2, 48, sc, Gfx.alpha(0xFFFFFFFF, a), Gfx.alpha(0xFF8A1E3A, a));
                    if (t > 20) big(g, tr("cutemod.fight.ready"), W / 2, 66, 0.9F, Gfx.alpha(0xFFFFE27A, a), Gfx.alpha(0xFF3A1A4A, a));
                }
            }
            case FightSim.PH_FIGHT -> {
                if (t < 50) {
                    int a = t < 34 ? 255 : Math.max(0, 255 - (t - 34) * 16);
                    float sc = 2.4F - Math.min(0.9F, t * 0.1F) + (t < 6 ? (6 - t) * 0.3F : 0F);
                    big(g, tr("cutemod.fight.go"), W / 2, 50, sc, Gfx.alpha(0xFFFFE27A, a), Gfx.alpha(0xFFC83A2A, a));
                }
            }
            case FightSim.PH_KO -> {
                if (sim.timeUp) {
                    big(g, tr("cutemod.fight.timeup"), W / 2, 50, 2F, 0xFFFFFFFF, 0xFF3A1A4A);
                } else {
                    float sc = 3.4F - Math.min(1.1F, t * 0.12F) + (float) Math.sin(t * 0.4F) * (t < 20 ? 0.12F : 0F);
                    big(g, "K.O.", W / 2, 48, sc, 0xFFFFE27A, 0xFFC83A2A);
                }
            }
            case FightSim.PH_RESULT, FightSim.PH_OVER -> {
                if (t > 10) {
                    if (sim.perfect) big(g, tr("cutemod.fight.perfect"), W / 2, 36, 1.5F + 0.1F * (float) Math.sin(t * 0.2F), 0xFFFFE27A, 0xFFC83A2A);
                    String s = sim.roundWinner < 0 ? tr("cutemod.fight.round_draw") : tr("cutemod.fight.round_win", tr("cutemod.fight.name." + sim.p[sim.roundWinner].ch));
                    big(g, s, W / 2, 56, Math.min(1.2F, 0.6F + t * 0.04F), 0xFFFFFFFF, 0xFF3A1A4A);
                }
            }
            default -> { }
        }
    }
}
