package dev.cutemod.client.game;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Hangman: guess the word letter by letter. Six wrong letters and the little panda is hung up. English and Russian words. */
public class Hangman extends MiniGame {
    private static final int LIVES = 6, KW = 17, KH = 13, KGAP = 2, COLS = 11, KY = 88;
    private static final String EN = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String RU = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
    // the standard Russian keyboard: the physical key (its Latin letter or sign) -> the Russian letter on it
    private static final String RU_KEYS = "QWERTYUIOP[]ASDFGHJKL;'ZXCVBNM,.`";
    private static final String RU_LETTERS = "ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮЁ";
    private static final String[] BACKUP_EN = {"PANDA", "CREEPER", "DIAMOND", "BAMBOO", "KITTEN", "COOKIE", "RAINBOW", "PENGUIN"};
    private static final String[] BACKUP_RU = {"ПАНДА", "КРИПЕР", "АЛМАЗ", "БАМБУК", "КОТИК", "ПЕЧЕНЬЕ", "РАДУГА", "ПИНГВИН"};

    private String alphabet = EN, word = "";
    private boolean ru;
    private final boolean[] tried = new boolean[40];
    private int mistakes;
    private boolean won;

    @Override
    public void reset() {
        score = 0; over = false; won = false; mistakes = 0;
        java.util.Arrays.fill(tried, false);
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        ru = lang != null && lang.toLowerCase(java.util.Locale.ROOT).startsWith("ru");
        alphabet = ru ? RU : EN;
        String[] words = Component.translatable("cutemod.hangman.words").getString().split(",");
        if (words.length < 3) words = ru ? BACKUP_RU : BACKUP_EN;        // the lang key was not found
        word = words[rnd.nextInt(words.length)].trim().toUpperCase(java.util.Locale.ROOT);
        if (word.isEmpty()) word = ru ? BACKUP_RU[0] : BACKUP_EN[0];
    }

    private void guess(int li) {
        if (over || li < 0 || li >= alphabet.length() || tried[li]) return;
        tried[li] = true;
        if (word.indexOf(alphabet.charAt(li)) >= 0) {
            pling(1.2F);
            if (solved()) {
                won = true; over = true; score = 20 + 8 * (LIVES - mistakes) + word.length();
                sound(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, 1.0F, 0.6F);
            }
        } else {
            beep();
            sound(net.minecraft.sounds.SoundEvents.VILLAGER_NO, 1.2F, 0.5F);
            if (++mistakes >= LIVES) { over = true; score = revealed() * 2; }
        }
    }

    private boolean solved() {
        for (int i = 0; i < word.length(); i++) {
            int li = alphabet.indexOf(word.charAt(i));
            if (li >= 0 && !tried[li]) return false;
        }
        return true;
    }

    private int revealed() {
        int c = 0;
        for (int i = 0; i < word.length(); i++) {
            int li = alphabet.indexOf(word.charAt(i));
            if (li >= 0 && tried[li]) c++;
        }
        return c;
    }

    private int keyX(int i) { return (W - (COLS * (KW + KGAP) - KGAP)) / 2 + (i % COLS) * (KW + KGAP); }

    private int keyY(int i) { return KY + (i / COLS) * (KH + KGAP); }

    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < alphabet.length(); i++) if (in(x, y, keyX(i), keyY(i), KW, KH)) { guess(i); break; }
        return true;
    }

    @Override
    public boolean key(int keyCode) {
        if (ru) {
            int k = RU_KEYS.indexOf((char) keyCode);
            if (k >= 0 && keyCode < 128) { guess(alphabet.indexOf(RU_LETTERS.charAt(k))); return true; }
            return false;
        }
        if (keyCode >= 65 && keyCode <= 90) { guess(keyCode - 65); return true; }
        return false;
    }

    @Override
    public void tick() {}

    private static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= steps; i++) {
            int x = x0 + (x1 - x0) * i / Math.max(1, steps), y = y0 + (y1 - y0) * i / Math.max(1, steps);
            rect(g, x, y, 2, 2, c);
        }
    }

    private void gallows(GuiGraphics g) {
        // wooden gallows on a little grassy hill, with a shaded post and a twisted rope
        Gfx.ellipse(g, 36, 80, 32, 6, 0xFF4E9A52);
        Gfx.ellipse(g, 36, 79, 30, 4, 0xFF6BC25A);
        int wood = 0xFFB07A44, woodD = 0xFF8A5A2E, woodL = 0xFFD39A5E;
        g.fillGradient(10, 76, 62, 80, woodL, woodD);                      // the base
        g.fillGradient(18, 8, 22, 78, woodL, woodD);                       // the post
        g.fill(18, 8, 19, 78, 0x44FFFFFF);
        g.fillGradient(18, 8, 52, 12, woodL, woodD);                       // the beam
        line(g, 18, 22, 30, 10, wood);                                     // the brace
        for (int y = 12; y < 20; y += 2) rect(g, 46 + (y / 2 & 1), y, 1, 2, 0xFFE8D8B8);   // the rope (twisted)
        rect(g, 46, 12, 2, 8, 0x66E8D8B8);
        int cx = 47, c = 0xFFF4F0E8, pink = 0xFFF06AAE;
        if (mistakes >= 1) {                    // the panda head with a little face
            Gfx.glow(g, cx, 26, 12, 0xFFFFFFFF, 40);
            disc(g, cx - 6, 19, 3, 0xFF3A2A3A); disc(g, cx + 6, 19, 3, 0xFF3A2A3A);          // ears
            Gfx.ball(g, cx, 26, 7, c);
            Gfx.ellipse(g, cx - 3, 25, 2, 3, 0xFF3A2A3A); Gfx.ellipse(g, cx + 3, 25, 2, 3, 0xFF3A2A3A);   // eye patches
            if (mistakes >= LIVES) {                                                            // lost: crossed eyes
                rect(g, cx - 4, 24, 2, 1, 0xFFFFFFFF); rect(g, cx - 4, 26, 2, 1, 0xFFFFFFFF);
                rect(g, cx + 2, 24, 2, 1, 0xFFFFFFFF); rect(g, cx + 2, 26, 2, 1, 0xFFFFFFFF);
                rect(g, cx - 3, 30, 6, 1, 0xFF3A2A3A);
            } else {
                rect(g, cx - 4, 24, 2, 2, 0xFFFFFFFF); rect(g, cx + 2, 24, 2, 2, 0xFFFFFFFF);
                rect(g, cx - 3, 25, 1, 1, 0xFF14101C); rect(g, cx + 3, 25, 1, 1, 0xFF14101C);
                rect(g, cx - 1, 28, 2, 1, 0xFF3A2A3A);
                rect(g, cx - 2, 30, 4, 1, 0xFF3A2A3A);
            }
        }
        if (mistakes >= 2) { rect(g, cx - 2, 33, 5, 22, pink); rect(g, cx - 2, 33, 1, 22, 0x66FFFFFF); }   // the body
        if (mistakes >= 3) line(g, cx, 38, cx - 11, 48, pink);                // the left arm
        if (mistakes >= 4) line(g, cx, 38, cx + 11, 48, pink);                // the right arm
        if (mistakes >= 5) line(g, cx, 55, cx - 9, 69, pink);                 // the left leg
        if (mistakes >= 6) line(g, cx, 55, cx + 9, 69, pink);                 // the right leg
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF40357C, 0xFF1E1840);
        for (int i = 0; i < 18; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 22) * W), (int) (Gfx.hash(i, 23) * H), 1, i * 19, 0x77FFFFFF);
        Gfx.glow(g, 150, 30, 50, 0xFF8A78E0, 60);
        gallows(g);
        // the word on little plates
        int n = word.length(), pitch = Math.min(16, 140 / Math.max(1, n)), x0 = 76 + (140 - n * pitch) / 2, y = 44;
        for (int i = 0; i < n; i++) {
            int li = alphabet.indexOf(word.charAt(i));
            boolean shown = (li >= 0 && tried[li]) || (over && !won);
            int x = x0 + i * pitch;
            rect(g, x, y + 14, pitch - 3, 2, shown ? 0xFFB6FFC8 : 0xFFFFFFFF);
            if (shown) {
                Gfx.glow(g, x + (pitch - 3) / 2, y + 6, 8, (li >= 0 && tried[li]) ? 0xFFB6FFC8 : 0xFFFF9AA8, 60);
                ctext(g, String.valueOf(word.charAt(i)), x + (pitch - 3) / 2, y, (li >= 0 && tried[li]) ? 0xFFB6FFC8 : 0xFFFF9AA8);
            }
        }
        // the keys: raised, rounded, they sink and light up when used
        for (int i = 0; i < alphabet.length(); i++) {
            int x = keyX(i), ky = keyY(i);
            boolean hov = !tried[i] && !over && in(mx, my, x, ky, KW, KH);
            int face;
            if (tried[i]) face = word.indexOf(alphabet.charAt(i)) >= 0 ? 0xFF3E8F55 : 0xFF8F3E4A;
            else face = hov ? 0xFF9A88F0 : 0xFF5A4AA0;
            int dy = tried[i] ? 1 : (hov ? -1 : 0);
            if (!tried[i]) Gfx.shadow(g, x, ky, KW, KH, 2);
            Gfx.bubble(g, x, ky + dy, KW, KH - (tried[i] ? 1 : 0), 3, face);
            ctext(g, String.valueOf(alphabet.charAt(i)), x + KW / 2, ky + 3 + dy, tried[i] ? 0x99FFFFFF : 0xFFFFFFFF);
        }
    }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return won ? Component.translatable("cutemod.hangman.win") : Component.translatable("cutemod.hangman.lost", word);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.hangman.status", LIVES - mistakes); }

    @Override
    public String hintKey() { return "cutemod.hint.hangman"; }
}
