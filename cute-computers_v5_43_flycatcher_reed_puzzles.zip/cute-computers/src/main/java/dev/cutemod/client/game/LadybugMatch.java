package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Red computer: classic match-3. 20 moves. */
public class LadybugMatch extends MiniGame {
    private static final int C = 8, R = 7, CELL = 18, OX = (W - C * CELL) / 2, OY = (H - R * CELL) / 2;
    private static final int[] COLORS = {0xFFE04848, 0xFF4A8FE0, 0xFF52C45A, 0xFFF2C94C, 0xFFA66BE0};

    private final int[][] grid = new int[R][C];
    private int selR, selC, moves;

    @Override
    public void reset() {
        score = 0; over = false; moves = 20; selR = -1; selC = -1;
        fillBoard();
    }

    private void fillBoard() {
        do {
            for (int r = 0; r < R; r++) for (int c = 0; c < C; c++) grid[r][c] = rnd.nextInt(COLORS.length);
        } while (countMatches(markMatches()) > 0 || !anyMove());
    }

    private boolean[][] markMatches() {
        boolean[][] m = new boolean[R][C];
        for (int r = 0; r < R; r++) {
            for (int c = 0; c < C - 2; c++) {
                int v = grid[r][c];
                if (v >= 0 && v == grid[r][c + 1] && v == grid[r][c + 2]) { m[r][c] = true; m[r][c + 1] = true; m[r][c + 2] = true; }
            }
        }
        for (int c = 0; c < C; c++) {
            for (int r = 0; r < R - 2; r++) {
                int v = grid[r][c];
                if (v >= 0 && v == grid[r + 1][c] && v == grid[r + 2][c]) { m[r][c] = true; m[r + 1][c] = true; m[r + 2][c] = true; }
            }
        }
        return m;
    }

    private static int countMatches(boolean[][] m) {
        int n = 0;
        for (boolean[] row : m) for (boolean b : row) if (b) n++;
        return n;
    }

    private void swap(int r1, int c1, int r2, int c2) {
        int t = grid[r1][c1]; grid[r1][c1] = grid[r2][c2]; grid[r2][c2] = t;
    }

    private boolean anyMove() {
        for (int r = 0; r < R; r++) {
            for (int c = 0; c < C; c++) {
                if (c + 1 < C) { swap(r, c, r, c + 1); boolean ok = countMatches(markMatches()) > 0; swap(r, c, r, c + 1); if (ok) return true; }
                if (r + 1 < R) { swap(r, c, r + 1, c); boolean ok = countMatches(markMatches()) > 0; swap(r, c, r + 1, c); if (ok) return true; }
            }
        }
        return false;
    }

    /** Clears matches, drops gems, refills; returns the points gained. */
    private int resolve() {
        int total = 0, chain = 0;
        while (true) {
            boolean[][] m = markMatches();
            int n = countMatches(m);
            if (n == 0) break;
            chain++;
            total += n * 10 * chain;
            for (int r = 0; r < R; r++) for (int c = 0; c < C; c++) if (m[r][c]) grid[r][c] = -1;
            for (int c = 0; c < C; c++) {
                int write = R - 1;
                for (int r = R - 1; r >= 0; r--) if (grid[r][c] >= 0) grid[write--][c] = grid[r][c];
                for (int r = write; r >= 0; r--) grid[r][c] = rnd.nextInt(COLORS.length);
            }
        }
        return total;
    }

    @Override
    public boolean click(int x, int y, int button) {
        int c = (x - OX) / CELL, r = (y - OY) / CELL;
        if (x < OX || y < OY || c >= C || r >= R) { selR = -1; return true; }
        if (selR < 0) { selR = r; selC = c; return true; }
        if (selR == r && selC == c) { selR = -1; return true; }
        if (Math.abs(selR - r) + Math.abs(selC - c) != 1) { selR = r; selC = c; return true; }
        swap(selR, selC, r, c);
        if (countMatches(markMatches()) == 0) {
            swap(selR, selC, r, c); // not a valid move
            beep();
        } else {
            moves--;
            int gained = resolve();
            score += gained;
            pling(1.0F + Math.min(gained, 200) / 250F);
            if (moves <= 0) over = true;
            else if (!anyMove()) fillBoard();
        }
        selR = -1;
        return true;
    }

    @Override
    public void tick() {}

    @Override
    public void render(GuiGraphics g) {
        // garden backdrop: gradient + soft light + a framed board
        g.fillGradient(0, 0, W, H, 0xFF4EA55A, 0xFF1F5A30);
        Gfx.glow(g, 30, 10, 40, 0xFFE8FFB0, 80);
        for (int i = 0; i < 14; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 14) * W), (int) (Gfx.hash(i, 15) * H), 1, i * 17, 0x66FFFFFF);
        Gfx.shadow(g, OX - 3, OY - 3, C * CELL + 6, R * CELL + 6, 4);
        Gfx.rrect(g, OX - 3, OY - 3, C * CELL + 6, R * CELL + 6, 4, 0xFF143A20);
        Gfx.rrect(g, OX - 2, OY - 2, C * CELL + 4, R * CELL + 4, 3, 0xFF2A6B3A);
        int pulse = (int) (Math.sin(System.nanoTime() / 150_000_000.0) * 40 + 215);
        for (int r = 0; r < R; r++) {
            for (int c = 0; c < C; c++) {
                int x = OX + c * CELL, y = OY + r * CELL;
                Gfx.rrect(g, x + 1, y + 1, CELL - 2, CELL - 2, 1, ((r + c) & 1) == 0 ? 0xFF2F7A3E : 0xFF2A7038);
                int v = grid[r][c];
                int cx = x + CELL / 2, cy = y + CELL / 2;
                if (v >= 0) piece(g, v, cx, cy);
                if (r == selR && c == selC) {
                    Gfx.glow(g, cx, cy, 11, 0xFFFFFFFF, 120);
                    Gfx.outline(g, x, y, CELL, CELL, 0xFF000000 | (pulse << 16) | (pulse << 8) | pulse);
                    Gfx.outline(g, x + 1, y + 1, CELL - 2, CELL - 2, 0x88FFFFFF);
                }
            }
        }
    }

    /** Five different shapes, so the colours are not the only way to tell them apart. */
    private static void piece(GuiGraphics g, int v, int cx, int cy) {
        int col = COLORS[v];
        Gfx.ellipse(g, cx, cy + 6, 6, 1, 0x33000000);
        switch (v) {
            case 0 -> { // ladybug
                Gfx.ball(g, cx, cy + 1, 7, col);
                Gfx.disc(g, cx, cy - 5, 3, 0xFF1A1A1A);                       // head
                g.fill(cx, cy - 3, cx + 1, cy + 8, 0xFF1A1A1A);               // wing split
                g.fill(cx - 4, cy - 1, cx - 2, cy + 1, 0xFF1A1A1A); g.fill(cx + 3, cy - 1, cx + 5, cy + 1, 0xFF1A1A1A);
                g.fill(cx - 4, cy + 3, cx - 2, cy + 5, 0xFF1A1A1A); g.fill(cx + 3, cy + 3, cx + 5, cy + 5, 0xFF1A1A1A);
                g.fill(cx - 2, cy - 6, cx - 1, cy - 5, 0xFFFFFFFF); g.fill(cx + 1, cy - 6, cx + 2, cy - 5, 0xFFFFFFFF);
            }
            case 1 -> { // gem
                Gfx.poly(g, new int[]{cx - 7, cx - 3, cx + 3, cx + 7, cx}, new int[]{cy - 2, cy - 6, cy - 6, cy - 2, cy + 7}, Gfx.darker(col, 0.25f));
                Gfx.poly(g, new int[]{cx - 6, cx - 3, cx + 3, cx + 6, cx}, new int[]{cy - 2, cy - 5, cy - 5, cy - 2, cy + 5}, col);
                Gfx.poly(g, new int[]{cx - 6, cx - 3, cx + 3, cx + 6}, new int[]{cy - 2, cy - 5, cy - 5, cy - 2}, Gfx.lighter(col, 0.5f));
                Gfx.poly(g, new int[]{cx - 2, cx + 2, cx}, new int[]{cy - 2, cy - 2, cy + 5}, Gfx.darker(col, 0.2f));
            }
            case 2 -> { // leaf
                Gfx.ellipse(g, cx, cy, 7, 5, Gfx.darker(col, 0.4f));
                Gfx.ellipse(g, cx, cy, 6, 4, col);
                Gfx.line(g, cx - 5, cy + 3, cx + 5, cy - 3, Gfx.lighter(col, 0.6f));
                g.fill(cx - 4, cy - 2, cx - 1, cy - 1, Gfx.lighter(col, 0.35f));
                g.fill(cx - 7, cy + 4, cx - 5, cy + 5, 0xFF3A2A1A);              // stem
            }
            case 3 -> { // bee
                Gfx.ellipse(g, cx - 5, cy - 4, 3, 2, 0xCCEAF8FF); Gfx.ellipse(g, cx + 5, cy - 4, 3, 2, 0xCCEAF8FF);
                Gfx.ball(g, cx, cy + 1, 6, col);
                g.fill(cx - 5, cy - 1, cx + 6, cy + 1, 0xFF3A2A1A); g.fill(cx - 4, cy + 3, cx + 5, cy + 5, 0xFF3A2A1A);
                g.fill(cx - 3, cy - 3, cx - 1, cy - 2, 0xFFFFFFFF);
            }
            default -> { // flower
                for (int a = 0; a < 5; a++)
                    Gfx.rrect(g, cx + (int) Math.round(Math.cos(a * 1.2566 - 1.57) * 4) - 3, cy + (int) Math.round(Math.sin(a * 1.2566 - 1.57) * 4) - 3, 6, 6, 2, a % 2 == 0 ? col : Gfx.lighter(col, 0.2f));
                Gfx.rrect(g, cx - 2, cy - 2, 5, 5, 2, 0xFFFFD84A);
            }
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_moves", score, moves); }

    @Override
    public String hintKey() { return "cutemod.hint.match"; }
}
