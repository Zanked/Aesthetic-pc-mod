package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Orange computer: find the pairs. */
public class FoxMemory extends MiniGame {
    private static final int CW = 44, CH = 28, GAP = 6, OX = 13, OY = 5;
    private static final int[] COLORS = {0xFFE0594F, 0xFF4A8FE0, 0xFF52B85A, 0xFFE0A93A, 0xFF9B5FD0, 0xFF3CB8B0, 0xFFD9689A, 0xFF8A6A4A};
    private static final String SYMBOLS = "ABCDEFGH";

    private final int[] cards = new int[16];
    private final boolean[] open = new boolean[16];
    private final boolean[] done = new boolean[16];
    private int first, second, timer, moves, pairs, t;
    private final float[] flip = new float[16];   // 0 = face down, 1 = face up (eases, for the turn animation)
    private final int[] pop = new int[16];        // sparkle timer after a match

    @Override
    public void reset() {
        score = 0; over = false; first = -1; second = -1; timer = 0; moves = 0; pairs = 0; t = 0;
        for (int i = 0; i < 16; i++) { flip[i] = 0; pop[i] = 0; }
        for (int i = 0; i < 16; i++) { cards[i] = i / 2; open[i] = false; done[i] = false; }
        for (int i = 15; i > 0; i--) { int j = rnd.nextInt(i + 1); int tmp = cards[i]; cards[i] = cards[j]; cards[j] = tmp; }
    }

    private int cardAt(int x, int y) {
        for (int i = 0; i < 16; i++) {
            int cx = OX + (i % 4) * (CW + GAP), cy = OY + (i / 4) * (CH + GAP);
            if (in(x, y, cx, cy, CW, CH)) return i;
        }
        return -1;
    }

    private void flipBack() {
        if (first >= 0) open[first] = false;
        if (second >= 0) open[second] = false;
        first = -1; second = -1; timer = 0;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (timer > 0) flipBack();
        int i = cardAt(x, y);
        if (i < 0 || open[i] || done[i]) return true;
        open[i] = true;
        pling(0.9F + cards[i] * 0.08F);
        if (first < 0) { first = i; return true; }
        second = i; moves++;
        if (cards[first] == cards[second]) {
            done[first] = true; done[second] = true; pairs++; pop[first] = 40; pop[second] = 40;
            first = -1; second = -1;
            if (pairs == 8) { score = Math.max(10, 200 - 8 * moves); over = true; }
        } else {
            timer = 50;
        }
        return true;
    }

    @Override
    public void tick() {
        t++;
        for (int i = 0; i < 16; i++) {
            float target = (open[i] || done[i]) ? 1f : 0f;
            flip[i] += (target - flip[i]) * 0.3f;
            if (Math.abs(target - flip[i]) < 0.02f) flip[i] = target;
            if (pop[i] > 0) pop[i]--;
        }
        if (timer > 0 && --timer == 0) flipBack();
    }

    @Override
    public void render(GuiGraphics g) {
        // warm wooden table with planks and a soft vignette
        g.fillGradient(0, 0, W, H, 0xFF8A4A24, 0xFF5A2E14);
        for (int y = 0; y < H; y += 14) { g.fill(0, y, W, y + 1, 0x33000000); g.fill(0, y + 1, W, y + 2, 0x11FFFFFF); }
        for (int i = 0; i < 18; i++) g.fill((int) (Gfx.hash(i, 3) * W), (int) (Gfx.hash(i, 4) * H), (int) (Gfx.hash(i, 3) * W) + 6, (int) (Gfx.hash(i, 4) * H) + 1, 0x14000000);
        Gfx.vignette(g, W, H, 90);
        for (int i = 0; i < 16; i++) {
            int cx = OX + (i % 4) * (CW + GAP), cy = OY + (i / 4) * (CH + GAP);
            float f = flip[i];
            float sx = Math.abs(2f * f - 1f);                     // the card narrows to a line while it turns
            int w = Math.max(2, Math.round(CW * (0.12f + 0.88f * sx)));
            int x = cx + (CW - w) / 2;
            Gfx.shadow(g, x, cy, w, CH, 3);
            if (f > 0.5f) {
                int col = COLORS[cards[i]];
                Gfx.rrect(g, x, cy, w, CH, 4, done[i] ? 0xFFFFE9A8 : 0xFFD8CBB4);
                Gfx.rrect(g, x + 1, cy + 1, w - 2, CH - 2, 4, done[i] ? 0xFFFFF7DC : 0xFFFFFFFF);
                if (w > CW * 0.7f) {
                    Gfx.rrect(g, x + 4, cy + 4, w - 8, CH - 8, 3, Gfx.alpha(col, 70));
                    icon(g, cards[i], x + w / 2, cy + CH / 2, col);
                }
                if (pop[i] > 0) {
                    Gfx.glow(g, cx + CW / 2, cy + CH / 2, 22, 0xFFFFE27A, 90);
                    Gfx.sparkle(g, cx + 5, cy + 5, 3, t + i * 7, 0xFFFFFFFF);
                    Gfx.sparkle(g, cx + CW - 6, cy + CH - 6, 3, t + i * 11, 0xFFFFE27A);
                }
            } else {
                Gfx.bubble(g, x, cy, w, CH, 4, 0xFFF58B25);
                if (w > CW * 0.6f) {
                    int mx0 = x + w / 2, my0 = cy + CH / 2;
                    // a little fox face on the back of the card
                    Gfx.rrect(g, x + 3, cy + 3, w - 6, CH - 6, 3, 0xFFFFB866);
                    g.fill(mx0 - 8, my0 - 8, mx0 - 3, my0 - 3, 0xFFD9701A); g.fill(mx0 + 3, my0 - 8, mx0 + 8, my0 - 3, 0xFFD9701A);
                    g.fill(mx0 - 6, my0 - 6, mx0 - 4, my0 - 3, 0xFFFFE0D0); g.fill(mx0 + 4, my0 - 6, mx0 + 6, my0 - 3, 0xFFFFE0D0);
                    Gfx.ellipse(g, mx0, my0 + 1, 8, 6, 0xFFFFA24A);
                    Gfx.ellipse(g, mx0, my0 + 3, 5, 3, 0xFFFFF3DC);
                    g.fill(mx0 - 5, my0 - 1, mx0 - 3, my0 + 1, 0xFF3A2010); g.fill(mx0 + 3, my0 - 1, mx0 + 5, my0 + 1, 0xFF3A2010);
                    g.fill(mx0 - 1, my0 + 2, mx0 + 1, my0 + 4, 0xFF3A2010);
                }
            }
        }
    }

    /** The picture on a card: eight easy to tell apart shapes. */
    private static void icon(GuiGraphics g, int kind, int cx, int cy, int col) {
        int dark = Gfx.darker(col, 0.35f), light = Gfx.lighter(col, 0.55f);
        switch (kind) {
            case 0 -> { // heart
                Gfx.disc(g, cx - 4, cy - 2, 4, col); Gfx.disc(g, cx + 4, cy - 2, 4, col);
                Gfx.poly(g, new int[]{cx - 8, cx + 9, cx}, new int[]{cy - 1, cy - 1, cy + 8}, col);
                Gfx.disc(g, cx - 5, cy - 3, 1, light);
            }
            case 1 -> { Gfx.star5(g, cx, cy + 1, 10, 4, dark); Gfx.star5(g, cx, cy + 1, 9, 4, col); Gfx.star5(g, cx - 1, cy, 4, 2, light); }
            case 2 -> { // gem
                Gfx.poly(g, new int[]{cx - 9, cx - 4, cx + 4, cx + 9, cx}, new int[]{cy - 2, cy - 7, cy - 7, cy - 2, cy + 8}, col);
                Gfx.poly(g, new int[]{cx - 9, cx - 4, cx + 4, cx + 9}, new int[]{cy - 2, cy - 7, cy - 7, cy - 2}, light);
                Gfx.poly(g, new int[]{cx - 3, cx + 3, cx}, new int[]{cy - 2, cy - 2, cy + 8}, dark);
            }
            case 3 -> { Gfx.ball(g, cx, cy, 8, col); }
            case 4 -> { Gfx.disc(g, cx, cy, 8, col); Gfx.disc(g, cx + 4, cy - 3, 7, Gfx.mix(0xFFFFFFFF, col, 0.275f)); Gfx.disc(g, cx - 3, cy + 1, 1, light); } // moon (the bite has the colour of the card)
            case 5 -> { // drop
                Gfx.disc(g, cx, cy + 2, 6, col);
                Gfx.poly(g, new int[]{cx, cx - 6, cx + 7}, new int[]{cy - 9, cy + 1, cy + 1}, col);
                Gfx.disc(g, cx - 2, cy + 2, 1, light);
            }
            case 6 -> { // flower
                for (int a = 0; a < 5; a++) Gfx.disc(g, cx + (int) Math.round(Math.cos(a * 1.2566 - 1.57) * 6), cy + (int) Math.round(Math.sin(a * 1.2566 - 1.57) * 6), 4, col);
                Gfx.disc(g, cx, cy, 3, 0xFFFFE27A);
            }
            default -> { // leaf
                Gfx.ellipse(g, cx, cy, 9, 6, dark); Gfx.ellipse(g, cx, cy, 8, 5, col);
                Gfx.line(g, cx - 7, cy + 3, cx + 7, cy - 3, light);
            }
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.moves", moves); }

    @Override
    public String hintKey() { return "cutemod.hint.memory"; }
}
