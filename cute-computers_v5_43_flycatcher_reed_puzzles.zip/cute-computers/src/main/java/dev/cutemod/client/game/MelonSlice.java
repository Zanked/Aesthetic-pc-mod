package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Melon Slice: fruit flies up from the bottom, swipe the mouse fast across it to slice it (no click needed).
 * Do not slice TNT. Three missed fruit end the game. Several fruit in one swipe give a combo bonus.
 */
public class MelonSlice extends MiniGame {
    private static final int MELON = 0, PUMPKIN = 1, APPLE = 2, BERRY = 3, GOLD = 4, TNT = 5;
    private static final int[] RIND = {0xFF2E8B3A, 0xFFF08A24, 0xFFD93A3A, 0xFFC62A3A, 0xFFD9A400};
    private static final int[] FLESH = {0xFFE8475A, 0xFFFFC857, 0xFFFFF3D6, 0xFFF28B96, 0xFFFFF1A0};
    private static final int[] RADIUS = {10, 9, 7, 6, 9, 9};
    private static final int[] POINTS = {3, 2, 2, 1, 10, 0};
    private static final float GRAVITY = 0.1F;
    private static final int TRAIL = 8, INVALID = -9999;

    private static final class Fruit { float x, y, vx, vy; int type; }
    private static final class Half { float x, y, vx, vy; int type; boolean left; int life; }
    private static final class Bit { float x, y, vx, vy; int color, life; }
    private static final class Pop { String s; float x, y; int life, color; }

    private final List<Fruit> fruits = new ArrayList<>();
    private final List<Half> halves = new ArrayList<>();
    private final List<Bit> bits = new ArrayList<>();
    private final List<Pop> pops = new ArrayList<>();
    private final int[] tx = new int[TRAIL], ty = new int[TRAIL];
    private int misses, spawnT, t, pmx, pmy, combo, comboT, boomX, boomY;
    private boolean boom;

    @Override
    public void reset() {
        score = 0; over = false;
        fruits.clear(); halves.clear(); bits.clear(); pops.clear();
        java.util.Arrays.fill(tx, INVALID);
        java.util.Arrays.fill(ty, INVALID);
        misses = 0; spawnT = 40; t = 0; combo = 0; comboT = 0; boom = false;
        pmx = mx; pmy = my;
    }

    // ---------- game ----------
    @Override
    public void tick() {
        t++;
        // the blade: a fast mouse move is a swipe
        float len = (float) Math.hypot(mx - pmx, my - pmy);
        boolean swipe = len >= 4F && len <= 70F;      // a huge jump is the mouse coming back into the window, not a swipe
        System.arraycopy(tx, 0, tx, 1, TRAIL - 1);
        System.arraycopy(ty, 0, ty, 1, TRAIL - 1);
        tx[0] = swipe ? mx : INVALID;
        ty[0] = swipe ? my : INVALID;
        if (swipe) {
            for (int i = fruits.size() - 1; i >= 0 && !over; i--) {
                Fruit f = fruits.get(i);
                if (segDist(pmx, pmy, mx, my, f.x, f.y) <= RADIUS[f.type] + 2) slice(f, i);
            }
        }
        pmx = mx; pmy = my;
        if (over) return;

        // fruit
        for (int i = fruits.size() - 1; i >= 0; i--) {
            Fruit f = fruits.get(i);
            f.vy += GRAVITY;
            f.x += f.vx;
            f.y += f.vy;
            int r = RADIUS[f.type];
            if (f.x < r) { f.x = r; f.vx = Math.abs(f.vx); }
            if (f.x > W - r) { f.x = W - r; f.vx = -Math.abs(f.vx); }
            if (f.vy > 0 && f.y > H + 14) {
                fruits.remove(i);
                if (f.type != TNT && f.type != GOLD) {
                    misses++;
                    beep();
                    if (misses >= 3) { over = true; return; }
                }
            }
        }
        for (int i = halves.size() - 1; i >= 0; i--) {
            Half h = halves.get(i);
            h.vy += GRAVITY; h.x += h.vx; h.y += h.vy;
            if (--h.life <= 0 || h.y > H + 20) halves.remove(i);
        }
        for (int i = bits.size() - 1; i >= 0; i--) {
            Bit b = bits.get(i);
            b.vy += 0.12F; b.x += b.vx; b.y += b.vy;
            if (--b.life <= 0 || b.y > H) bits.remove(i);
        }
        for (int i = pops.size() - 1; i >= 0; i--) {
            Pop p = pops.get(i);
            p.y -= 0.35F;
            if (--p.life <= 0) pops.remove(i);
        }
        // combo: slices that follow each other quickly
        if (comboT > 0 && --comboT == 0) {
            if (combo >= 2) {
                int bonus = combo * 2;
                score += bonus;
                pop("x" + combo + "  +" + bonus, W / 2F, H / 2F, 0xFFFFD866, 50);
                pling(1.6F);
            }
            combo = 0;
        }
        // new fruit: faster and in bigger waves as the score grows
        if (--spawnT <= 0) {
            int n = 1 + rnd.nextInt(1 + Math.min(3, score / 25));
            boolean tnt = false;
            for (int i = 0; i < n; i++) tnt |= spawnFruit(tnt);
            spawnT = Math.max(30, 80 - score / 3) + rnd.nextInt(24);
        }
    }

    private boolean spawnFruit(boolean tntAlready) {
        Fruit f = new Fruit();
        int r = rnd.nextInt(100);
        if (score >= 10 && !tntAlready && r < 14) f.type = TNT;
        else if (score >= 15 && r < 20) f.type = GOLD;
        else {
            int k = rnd.nextInt(100);
            f.type = k < 42 ? MELON : k < 65 ? PUMPKIN : k < 88 ? APPLE : BERRY;
        }
        f.x = 26 + rnd.nextInt(W - 52);
        f.y = H + 8;
        f.vx = (W / 2F - f.x) * 0.006F + (rnd.nextFloat() - 0.5F) * 0.6F;
        f.vy = -(4.5F + rnd.nextFloat() * 0.6F);
        fruits.add(f);
        return f.type == TNT;
    }

    private void slice(Fruit f, int index) {
        fruits.remove(index);
        if (f.type == TNT) {
            over = true;
            boom = true;
            boomX = Math.round(f.x);
            boomY = Math.round(f.y);
            return;
        }
        int pts = POINTS[f.type];
        score += pts;
        combo++;
        comboT = 14;
        pling(1.0F + Math.min(combo, 6) * 0.12F);
        pop("+" + pts, f.x, f.y - 6, f.type == GOLD ? 0xFFFFD866 : 0xFFFFFFFF, 30);
        for (int side = 0; side < 2; side++) {
            Half h = new Half();
            h.x = f.x; h.y = f.y; h.type = f.type; h.left = side == 0;
            h.vx = f.vx + (side == 0 ? -0.9F : 0.9F);
            h.vy = f.vy * 0.5F - 0.4F;
            h.life = 70;
            halves.add(h);
        }
        for (int i = 0; i < 9; i++) {
            Bit b = new Bit();
            b.x = f.x; b.y = f.y;
            b.vx = (rnd.nextFloat() - 0.5F) * 3F;
            b.vy = -rnd.nextFloat() * 2F;
            b.color = FLESH[f.type];
            b.life = 26;
            bits.add(b);
        }
    }

    private void pop(String s, float x, float y, int color, int life) {
        Pop p = new Pop();
        p.s = s; p.x = x; p.y = y; p.color = color; p.life = life;
        pops.add(p);
    }

    /** Distance from the point (px, py) to the segment (ax, ay)-(bx, by). */
    private static float segDist(float ax, float ay, float bx, float by, float px, float py) {
        float dx = bx - ax, dy = by - ay;
        float l2 = dx * dx + dy * dy;
        float k = l2 == 0 ? 0 : Math.max(0F, Math.min(1F, ((px - ax) * dx + (py - ay) * dy) / l2));
        return (float) Math.hypot(px - (ax + k * dx), py - (ay + k * dy));
    }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g) {
        // a bright dojo: warm wall with a big soft sun, a bamboo mat and a wooden floor
        g.fillGradient(0, 0, W, H, 0xFFFFE8CF, 0xFFF7C9A9);
        Gfx.glow(g, W / 2, 56, 48, 0xFFFFB48A, 70);
        for (int x = 6; x < W; x += 12) rect(g, x, 0, 1, H, 0x1AB5835A);    // a bamboo mat
        g.fillGradient(0, H - 10, W, H, 0xFFC98A56, 0xFF8E5A32);
        rect(g, 0, H - 10, W, 2, 0xFFE0B07A);
        for (int x = 0; x < W; x += 28) rect(g, x, H - 8, 1, 8, 0x33000000);

        for (Half h : halves) drawHalf(g, h);
        for (Fruit f : fruits) drawFruit(g, f);
        for (Bit b : bits) rect(g, Math.round(b.x), Math.round(b.y), 2, 2, b.color);

        // the blade trail: a soft wide streak with a bright core
        for (int i = 0; i < TRAIL - 1; i++) {
            if (tx[i] == INVALID || tx[i + 1] == INVALID) continue;
            int a = 255 - i * 30;
            line(g, tx[i], ty[i], tx[i + 1], ty[i + 1], ((a / 4) << 24) | 0x9FD8FF, 4);
            line(g, tx[i], ty[i], tx[i + 1], ty[i + 1], (a << 24) | 0xFFFFFF, 2);
        }
        for (Pop p : pops) {
            int a = Math.min(255, p.life * 12);
            ctext(g, p.s, Math.round(p.x) + 1, Math.round(p.y) + 1, (a / 3 << 24));
            ctext(g, p.s, Math.round(p.x), Math.round(p.y), (a << 24) | (p.color & 0xFFFFFF));
        }
        // the three chances: little boxes that get a red cross when lost
        for (int i = 0; i < 3; i++) {
            int x = W - 12 - i * 11;
            boolean lost = i >= 3 - misses;
            Gfx.bubble(g, x, 3, 9, 9, 2, lost ? 0xFFE0594F : 0xFFF3D9B8);
            if (lost) { Gfx.line(g, x + 2, 5, x + 6, 9, 0xFFFFFFFF); Gfx.line(g, x + 6, 5, x + 2, 9, 0xFFFFFFFF); }
        }
        if (boom) {   // the explosion where the TNT was
            Gfx.glow(g, boomX, boomY, 34, 0xFFFFE27A, 150);
            disc(g, boomX, boomY, 26, 0x88FFE27A);
            disc(g, boomX, boomY, 17, 0xCCFF9A3C);
            disc(g, boomX, boomY, 9, 0xFFFFF7D6);
        }
    }

    private void line(GuiGraphics g, int x0, int y0, int x1, int y1, int argb, int size) {
        int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        steps = Math.max(1, steps / (size > 2 ? 2 : 1));
        for (int i = 0; i <= steps; i++) {
            float k = steps == 0 ? 0 : i / (float) steps;
            rect(g, Math.round(x0 + (x1 - x0) * k) - (size - 2) / 2, Math.round(y0 + (y1 - y0) * k) - (size - 2) / 2, size, size, argb);
        }
    }

    /** A vertical line that stays inside the circle (used for the stripes). */
    private static void chord(GuiGraphics g, int cx, int cy, int r, int xoff, int argb) {
        int h = (int) Math.floor(Math.sqrt(Math.max(0, r * r - xoff * xoff)));
        g.fill(cx + xoff, cy - h, cx + xoff + 1, cy + h, argb);
    }

    private void drawFruit(GuiGraphics g, Fruit f) {
        int x = Math.round(f.x), y = Math.round(f.y), r = RADIUS[f.type];
        switch (f.type) {
            case MELON -> {
                Gfx.ball(g, x, y, r, RIND[MELON]);
                for (int o = -6; o <= 6; o += 4) chord(g, x, y, r - 1, o, 0xFF1F6B2B);
                rect(g, x + 4, y - 3, 1, 5, 0x22000000);
            }
            case PUMPKIN -> {
                Gfx.ball(g, x, y, r, RIND[PUMPKIN]);
                chord(g, x, y, r - 1, -3, 0xFFC86A10); chord(g, x, y, r - 1, 3, 0xFFC86A10); chord(g, x, y, r - 1, 0, 0x33C86A10);
                Gfx.rrect(g, x - 1, y - r - 3, 3, 4, 1, 0xFF4F8A2E);
            }
            case APPLE -> {
                Gfx.ball(g, x, y, r, RIND[APPLE]);
                rect(g, x, y - r - 3, 1, 4, 0xFF5A3A24);
                Gfx.ellipse(g, x + 3, y - r - 1, 3, 1, 0xFF5DB04A);
            }
            case BERRY -> {
                Gfx.ball(g, x - 3, y + 1, 4, RIND[BERRY]);
                Gfx.ball(g, x + 3, y + 1, 4, RIND[BERRY]);
                Gfx.ball(g, x, y - 3, 4, RIND[BERRY]);
                Gfx.ellipse(g, x, y - 8, 3, 1, 0xFF5DB04A);
            }
            case GOLD -> {
                Gfx.glow(g, x, y, r + 7, 0xFFFFE27A, 100);
                Gfx.ball(g, x, y, r, RIND[GOLD]);
                disc(g, x, y, r - 3, 0xFFFFD84A);
                rect(g, x - 4, y - 5, 3, 2, 0xFFFFFFFF);
                if ((t / 6) % 2 == 0) Gfx.sparkle(g, x + r, y - r, 3, t, 0xFFFFFFFF);
            }
            default -> {  // TNT
                Gfx.shadow(g, x - 10, y - 8, 20, 16, 2);
                Gfx.bubble(g, x - 10, y - 8, 20, 16, 2, 0xFFD6403A);
                rect(g, x - 9, y - 4, 18, 8, 0xFFF4F0E8);
                g.drawString(font(), "TNT", x - font().width("TNT") / 2, y - 4, 0xFF2A2433, false);
                rect(g, x, y - 12, 1, 4, 0xFF5A3A24);
                if ((t / 4) % 2 == 0) { Gfx.glow(g, x, y - 14, 6, 0xFFFFD84A, 130); rect(g, x - 1, y - 15, 3, 3, 0xFFFFD84A); }
            }
        }
    }

    private void drawHalf(GuiGraphics g, Half h) {
        int x = Math.round(h.x), y = Math.round(h.y), r = RADIUS[h.type];
        int alpha = h.life < 20 ? h.life * 12 : 255;
        int rind = (alpha << 24) | (RIND[h.type] & 0xFFFFFF), flesh = (alpha << 24) | (FLESH[h.type] & 0xFFFFFF);
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            int x0 = h.left ? x - dx : x, x1 = h.left ? x : x + dx + 1;
            g.fill(x0, y + dy, x1, y + dy + 1, rind);
            if (Math.abs(dy) <= r - 1) {
                int d1 = (int) Math.floor(Math.sqrt((r - 1) * (r - 1) - dy * dy + 0.25));
                g.fill(h.left ? x - d1 : x, y + dy, h.left ? x : x + d1 + 1, y + dy + 1, (alpha << 24) | 0xEAF7D4);
            }
            if (Math.abs(dy) <= r - 2) {
                int di = (int) Math.floor(Math.sqrt((r - 2) * (r - 2) - dy * dy + 0.25));
                g.fill(h.left ? x - di : x, y + dy, h.left ? x : x + di + 1, y + dy + 1, flesh);
            }
        }
        if (h.type == MELON) {
            int sx = h.left ? x - 4 : x + 3;
            rect(g, sx, y - 2, 1, 2, (alpha << 24) | 0x2A2433);
            rect(g, sx, y + 3, 1, 2, (alpha << 24) | 0x2A2433);
        }
    }

    // ---------- texts ----------
    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, 3 - misses); }

    @Override
    public Component endTitle() {
        return boom ? Component.translatable("cutemod.slice.boom") : Component.translatable("cutemod.ui.gameover");
    }

    @Override
    public String hintKey() { return "cutemod.hint.slice"; }
}
