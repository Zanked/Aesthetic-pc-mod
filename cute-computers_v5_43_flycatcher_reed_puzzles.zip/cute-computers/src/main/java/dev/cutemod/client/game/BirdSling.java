package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Bird Sling: an Angry Birds style game. Pull the slingshot back with the mouse, let go and the bird flies at the
 * green piggies' shelters. Wood, ice and stone blocks break, towers fall, the piggies pop. Four kinds of birds:
 * red (plain), blue (splits in three on a click), yellow (a click makes it dash) and black (a click, or a hit, and it blows up).
 * Eight levels, three hearts: a level that is lost costs a heart and is played again.
 * <p>
 * The physics are a small home-made one: blocks are boxes that do not turn, but they slide off a support that
 * holds them only by an edge, so towers still fall over. Everything is simulated in three small steps per tick.
 */
public class BirdSling extends MiniGame {
    private static final int GY = 124, LEVELS = 8, SUB = 3, LIVES = 3;
    private static final float DT = 1F / SUB, G = 0.11F, MAXD = 26F, VMAX = 5.6F, AX = 32F, AY = 97F, TH = 0.8F;
    private static final int K_BIRD = 0, K_PIG = 1, K_BLOCK = 2;
    private static final int WOOD = 0, ICE = 1, STONE = 2;
    private static final int RED = 0, BLUE = 1, YELLOW = 2, BLACK = 3;
    private static final int S_READY = 0, S_DRAG = 1, S_FLY = 2, S_CLEAR = 3, S_FAIL = 4;

    private static final float[] M_HP = {5F, 3F, 12F}, M_DENS = {1F, 0.7F, 2.2F}, M_FRAG = {1F, 1.5F, 0.45F};
    private static final int[] M_COL = {0xFFC98B4E, 0xFFA9DDF5, 0xFF9A9AA8};
    private static final int[] B_COL = {0xFFE0453A, 0xFF4A8FE0, 0xFFF5D03A, 0xFF3A3A48};
    private static final String[] QUEUES = {"RRR", "RRYR", "RBYR", "BBY", "RYBBR", "KRRY", "RBYK", "KKYBR"};

    private static final class Body {
        final int kind;
        int type, age, hit, still;
        float x, y, vx, vy, w, h, r, hp, maxHp, mass, inv;
        boolean dead, used, child;
        float supL, supR;                 // what holds it from below this step: the span of the supports (a box falls over a ledge)

        Body(int kind) { this.kind = kind; }
    }

    private static final class Fx {
        float x, y, vx, vy;
        int life, max, kind, col;
        String txt;
    }

    private final List<Body> bodies = new ArrayList<>();
    private final List<Fx> fx = new ArrayList<>();
    private int[] queue = new int[0];
    private int qi, cur, level, lives, state, stateT, scoreBase, time, flyT, calm, winT, hop, bannerT, sfxCool;
    private float px, py;
    private Body lead;
    private boolean won;

    // ------------------------------------------------------------------ start

    @Override
    public void reset() {
        score = 0; over = false; won = false; lives = LIVES; scoreBase = 0; time = 0;
        startLevel(0);
    }

    void startLevel(int n) {
        level = n;
        scoreBase = score;
        bodies.clear(); fx.clear();
        String q = QUEUES[n];
        queue = new int[q.length()];
        for (int i = 0; i < queue.length; i++) queue[i] = "RBYK".indexOf(q.charAt(i));
        qi = 0; lead = null; flyT = 0; calm = 0; winT = 0; bannerT = 110;
        build(n);
        loadNext();
    }

    private void loadNext() {
        cur = queue[qi++];
        state = S_READY;
        hop = 24;
        px = AX; py = AY;
    }

    int pigsLeft() {
        int n = 0;
        for (Body b : bodies) if (b.kind == K_PIG && !b.dead) n++;
        return n;
    }

    int birdsLeft() { return queue.length - qi + (cur >= 0 ? 1 : 0); }

    int state() { return state; }

    int level() { return level; }

    int lives() { return lives; }

    // ------------------------------------------------------------------ levels

    private void blk(int mat, int left, int bottom, int w, int h) {
        Body b = new Body(K_BLOCK);
        b.type = mat; b.w = w; b.h = h;
        b.x = left + w / 2F; b.y = bottom - h / 2F;
        b.maxHp = b.hp = M_HP[mat] * Math.max(0.6F, Math.min(1.6F, (float) Math.sqrt(w * h / 80F)));
        b.mass = Math.max(0.6F, w * h * M_DENS[mat] / 40F);
        b.inv = 1F / b.mass;
        bodies.add(b);
    }

    private void pig(int cx, int bottom) {
        Body b = new Body(K_PIG);
        b.r = 5F; b.x = cx; b.y = bottom - 5F;
        b.maxHp = b.hp = 4F; b.mass = 1.1F; b.inv = 1F / b.mass;
        bodies.add(b);
    }

    private void build(int lv) {
        int g = GY;
        switch (lv) {
            case 0 -> {                                   // a little ice hut with two piggies
                blk(ICE, 150, g, 4, 16); blk(ICE, 174, g, 4, 16); blk(ICE, 148, g - 16, 34, 4);
                pig(163, g); pig(165, g - 20);
            }
            case 1 -> {                                   // an ice table and a wooden table
                blk(ICE, 130, g, 4, 20); blk(ICE, 146, g, 4, 20); blk(ICE, 128, g - 20, 26, 4);
                pig(139, g); pig(141, g - 24);
                blk(WOOD, 172, g, 4, 20); blk(WOOD, 192, g, 4, 20); blk(WOOD, 170, g - 20, 30, 4);
                pig(185, g);
            }
            case 2 -> {                                   // a stone wall, the piggies hide behind it
                blk(STONE, 124, g, 6, 30);
                blk(WOOD, 152, g, 4, 18); blk(WOOD, 174, g, 4, 18); blk(WOOD, 150, g - 18, 30, 4);
                pig(165, g); pig(165, g - 22); pig(194, g);
            }
            case 3 -> {                                   // a tall tower on wooden legs, a piggy behind a stone block
                blk(WOOD, 150, g, 4, 24); blk(WOOD, 170, g, 4, 24); blk(ICE, 146, g - 24, 32, 4);
                blk(ICE, 152, g - 28, 4, 16); blk(ICE, 168, g - 28, 4, 16); blk(ICE, 148, g - 44, 28, 4);
                pig(162, g); pig(162, g - 28); pig(162, g - 48);
                blk(STONE, 190, g, 8, 14); pig(204, g);
            }
            case 4 -> {                                   // a stone base with a wooden roof
                blk(STONE, 138, g, 12, 12); blk(STONE, 176, g, 12, 12); blk(WOOD, 136, g - 12, 54, 4);
                blk(WOOD, 144, g - 16, 4, 16); blk(WOOD, 178, g - 16, 4, 16); blk(WOOD, 140, g - 32, 46, 4);
                pig(163, g); pig(163, g - 16); pig(163, g - 36);
            }
            case 5 -> {                                   // a heavy stone gate
                blk(STONE, 140, g, 6, 24); blk(STONE, 170, g, 6, 24); blk(STONE, 136, g - 24, 44, 6);
                pig(158, g); pig(158, g - 30);
                blk(WOOD, 196, g, 4, 14); pig(208, g);
            }
            case 6 -> {                                   // a pyramid of boxes
                blk(WOOD, 136, g, 10, 10); blk(WOOD, 146, g, 10, 10); blk(WOOD, 170, g, 10, 10); blk(WOOD, 180, g, 10, 10);
                blk(ICE, 140, g - 10, 46, 4); blk(WOOD, 150, g - 14, 10, 10); blk(WOOD, 166, g - 14, 10, 10);
                blk(WOOD, 146, g - 24, 34, 4);
                pig(163, g); pig(163, g - 14); pig(163, g - 28);
                blk(STONE, 196, g, 8, 18); pig(188, g - 10);
            }
            default -> {                                  // the castle: three groups of piggies far from each other
                blk(STONE, 114, g, 6, 26); blk(STONE, 134, g, 6, 26); blk(WOOD, 112, g - 26, 30, 4);
                pig(127, g); pig(127, g - 30);
                blk(WOOD, 156, g, 4, 14); blk(WOOD, 170, g, 4, 14); blk(ICE, 154, g - 14, 22, 4);
                pig(163, g); pig(163, g - 18);
                blk(STONE, 192, g, 6, 26); blk(STONE, 210, g, 6, 26); blk(WOOD, 190, g - 26, 28, 4);
                pig(204, g); pig(204, g - 30);
            }
        }
    }

    // ------------------------------------------------------------------ input

    private void pocket(int mxv, int myv) {
        float dx = mxv - AX, dy = myv - AY, len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len > MAXD) { dx *= MAXD / len; dy *= MAXD / len; }
        px = AX + dx;
        py = Math.min(AY + dy, GY - 5F);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        if (state == S_READY && cur >= 0 && hop <= 0) {
            state = S_DRAG;
            pocket(x, y);
            sound(SoundEvents.CROSSBOW_SHOOT, 0.6F, 0.25F);
            return true;
        }
        if (state == S_FLY) { ability(); return true; }
        return false;
    }

    @Override
    public boolean release(int x, int y, int button) {
        if (state != S_DRAG) return false;
        pocket(x, y);
        if (AX - px >= 4F) fire(); else { state = S_READY; px = AX; py = AY; }
        return true;
    }

    @Override
    public boolean key(int keyCode) {
        if (keyCode == KEY_SPACE && state == S_FLY) { ability(); return true; }
        return false;
    }

    private void fire() {
        Body b = new Body(K_BIRD);
        b.type = cur; b.r = 4F; b.x = px; b.y = py;
        b.vx = (AX - px) * VMAX / MAXD; b.vy = (AY - py) * VMAX / MAXD;
        b.mass = cur == BLACK ? 2.6F : 2F; b.inv = 1F / b.mass;
        bodies.add(b);
        lead = b;
        cur = -1;
        state = S_FLY; flyT = 0; calm = 0; winT = 0;
        sound(SoundEvents.CROSSBOW_SHOOT, 1.2F, 0.7F);
        sound(SoundEvents.PARROT_AMBIENT, 1.5F, 0.4F);
    }

    private void ability() {
        Body b = lead;
        if (b == null || b.dead || b.used) return;
        b.used = true;
        switch (b.type) {
            case BLUE -> {
                for (int s = -1; s <= 1; s += 2) {
                    Body c = new Body(K_BIRD);
                    c.type = BLUE; c.r = 3.5F; c.child = true; c.used = true;
                    c.x = b.x; c.y = b.y + s * 2F;
                    float a = s * 0.26F, ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                    c.vx = b.vx * ca - b.vy * sa; c.vy = b.vx * sa + b.vy * ca;
                    c.mass = 1.4F; c.inv = 1F / c.mass; c.hit = b.hit;
                    bodies.add(c);
                }
                puff(b.x, b.y, 0xFFBFE0FF, 6);
                sound(SoundEvents.PARROT_AMBIENT, 1.9F, 0.5F);
            }
            case YELLOW -> {
                b.vx *= 1.8F; b.vy *= 1.8F;
                puff(b.x, b.y, 0xFFFFF2A0, 6);
                sound(SoundEvents.FIREWORK_ROCKET_BLAST, 1.6F, 0.5F);
            }
            case BLACK -> boom(b.x, b.y, b);
            default -> sound(SoundEvents.PARROT_AMBIENT, 1.3F, 0.4F);
        }
    }

    private void boom(float x, float y, Body self) {
        float rad = 28F;
        for (Body b : bodies) {
            if (b.dead || b == self || b.kind == K_BIRD) continue;
            float dx = b.x - x, dy = b.y - y, d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d >= rad) continue;
            float f = 1F - d / rad;
            if (d < 0.01F) { dx = 0; dy = -1; d = 1; }
            float dv = 7F * f / (float) Math.sqrt(b.mass);
            b.vx += dx / d * dv;
            b.vy += dy / d * dv - 0.5F * f;
            hurt(b, 13F * f);
        }
        self.dead = true;
        Fx r = new Fx();
        r.kind = 2; r.x = x; r.y = y; r.life = r.max = 16;
        fx.add(r);
        puff(x, y, 0xFFFFB347, 12);
        sound(SoundEvents.GENERIC_EXPLODE, 1.1F, 0.8F);
    }

    // ------------------------------------------------------------------ physics

    @Override
    public void tick() {
        time++;
        if (bannerT > 0) bannerT--;
        if (sfxCool > 0) sfxCool--;
        if (hop > 0) hop--;
        if (state == S_DRAG) pocket(mx, my);
        stepWorld();
        tickFx();
        if (state <= S_FLY) {                                // the last piggy is gone, whatever the birds are doing
            if (pigsLeft() == 0) { if (++winT > 45) win(); }
            else winT = 0;
        }
        switch (state) {
            case S_FLY -> {
                flyT++;
                boolean birds = false;
                for (Body b : bodies) if (b.kind == K_BIRD && !b.dead) { birds = true; break; }
                if (pigsLeft() > 0 && ((!birds && (calm > 40 || flyT > 900)) || flyT > 1500)) afterShot();
            }
            case S_CLEAR -> {
                if (--stateT <= 0) {
                    if (level + 1 >= LEVELS) { score += lives * 50; won = true; over = true; }
                    else startLevel(level + 1);
                }
            }
            case S_FAIL -> {
                if (--stateT <= 0) {
                    if (lives <= 0) { won = false; over = true; }
                    else startLevel(level);
                }
            }
            default -> { }
        }
    }

    private void afterShot() {
        if (qi < queue.length) { loadNext(); return; }
        lives--;
        score = scoreBase;
        state = S_FAIL; stateT = 110;
        sound(SoundEvents.PIG_HURT, 0.7F, 0.8F);
    }

    private void win() {
        int bonus = birdsLeft() * 20;
        score += bonus;
        state = S_CLEAR; stateT = 140;
        if (bonus > 0) pts(W / 2F, 60, bonus);
        sound(SoundEvents.PLAYER_LEVELUP, 1.1F, 0.8F);
    }

    private void stepWorld() {
        for (int s = 0; s < SUB; s++) substep();
        float maxV = 0;
        for (Body b : bodies) {
            if (b.dead) continue;
            float v = Math.abs(b.vx) + Math.abs(b.vy);
            if (b.kind == K_BIRD) {
                b.age++;
                if (b.hit > 0) b.hit++;
                b.still = v < 0.12F ? b.still + 1 : 0;
                if (b.type == BLACK && !b.used && b.hit > 70) { b.used = true; boom(b.x, b.y, b); continue; }
                if (b.x < -20 || b.x > W + 25 || b.y > H + 20 || b.still > 35 || b.hit > 240) {
                    b.dead = true;
                    puff(b.x, Math.min(b.y, GY - 2F), B_COL[b.type], 4);
                }
            } else {
                maxV = Math.max(maxV, v);
                if (b.x > W + 20 || b.x < -30 || b.y > H + 30) kill(b);
            }
        }
        calm = maxV < 0.05F ? calm + 1 : 0;
        bodies.removeIf(b -> b.dead);
    }

    private void substep() {
        for (Body b : bodies) {
            if (b.dead) continue;
            b.supL = Float.MAX_VALUE; b.supR = -Float.MAX_VALUE;
            b.vy += G * DT;
            b.x += b.vx * DT;
            b.y += b.vy * DT;
            float bottom = b.kind == K_BLOCK ? b.y + b.h / 2F : b.y + b.r;
            if (bottom > GY) {
                b.y -= bottom - GY;
                float vn = b.vy;
                if (vn > 0) {
                    if (b.kind == K_BIRD) { if (vn > 0.3F && b.hit == 0) b.hit = 1; }
                    else if (vn > 1.1F) hurt(b, (vn - 1.1F) * 2F);
                    float e = vn > 1.2F ? (b.kind == K_BIRD ? 0.3F : 0.12F) : 0F;
                    b.vy = -vn * e;
                    if (vn > 1.6F && b.kind != K_BLOCK) sound(SoundEvents.SLIME_SQUISH, 1.3F, 0.15F);
                }
                b.vx *= b.kind == K_BLOCK ? 0.9F : (b.kind == K_BIRD ? 0.97F : 0.96F);
                b.supL = -1e9F; b.supR = 1e9F;
            }
        }
        int n = bodies.size();
        for (int i = 0; i < n; i++) {
            Body a = bodies.get(i);
            if (a.dead) continue;
            for (int j = i + 1; j < n; j++) {
                Body b = bodies.get(j);
                if (!b.dead && !a.dead) collide(a, b);
            }
        }
        for (Body b : bodies) {                          // held only by a ledge: the box slides off it and falls
            if (b.dead || b.kind != K_BLOCK || b.supR < b.supL) continue;
            if (b.x < b.supL - 0.5F) b.vx -= 0.03F;
            else if (b.x > b.supR + 0.5F) b.vx += 0.03F;
        }
    }

    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : Math.min(v, hi); }

    private void collide(Body a, Body b) {
        if (a.kind == K_BIRD && b.kind == K_BIRD) return;
        boolean ac = a.kind != K_BLOCK, bc = b.kind != K_BLOCK;
        float nx, ny, pen;
        if (!ac && !bc) {
            float ox = (a.w + b.w) / 2F - Math.abs(b.x - a.x), oy = (a.h + b.h) / 2F - Math.abs(b.y - a.y);
            if (ox <= 0 || oy <= 0) return;
            if (ox < oy) { nx = b.x > a.x ? 1 : -1; ny = 0; pen = ox; }
            else { nx = 0; ny = b.y > a.y ? 1 : -1; pen = oy; }
        } else if (ac && bc) {
            float dx = b.x - a.x, dy = b.y - a.y, d2 = dx * dx + dy * dy, rr = a.r + b.r;
            if (d2 >= rr * rr) return;
            float d = (float) Math.sqrt(d2);
            if (d < 1e-4F) { nx = 0; ny = -1; } else { nx = dx / d; ny = dy / d; }
            pen = rr - d;
        } else {
            Body c = ac ? a : b, k = ac ? b : a;
            float hx = k.w / 2F, hy = k.h / 2F;
            float qx = clamp(c.x, k.x - hx, k.x + hx), qy = clamp(c.y, k.y - hy, k.y + hy);
            float dx = c.x - qx, dy = c.y - qy, d2 = dx * dx + dy * dy;
            if (d2 > c.r * c.r) return;
            float cnx, cny, cpen;                       // the normal from the box to the circle
            if (d2 > 1e-6F) {
                float d = (float) Math.sqrt(d2);
                cnx = dx / d; cny = dy / d; cpen = c.r - d;
            } else {                                    // the centre is inside the box: out along the shortest way
                float ox = hx - Math.abs(c.x - k.x), oy = hy - Math.abs(c.y - k.y);
                if (ox < oy) { cnx = c.x > k.x ? 1 : -1; cny = 0; cpen = ox + c.r; }
                else { cnx = 0; cny = c.y > k.y ? 1 : -1; cpen = oy + c.r; }
            }
            if (ac) { nx = -cnx; ny = -cny; } else { nx = cnx; ny = cny; }
            pen = cpen;
        }
        resolve(a, b, nx, ny, pen);
    }

    /** n points from a to b. */
    private void resolve(Body a, Body b, float nx, float ny, float pen) {
        float ia = a.inv, ib = b.inv, is = ia + ib;
        float corr = pen / is;
        a.x -= nx * corr * ia; a.y -= ny * corr * ia;
        b.x += nx * corr * ib; b.y += ny * corr * ib;
        float rvx = b.vx - a.vx, rvy = b.vy - a.vy;
        float vn = rvx * nx + rvy * ny;
        if (ny != 0) {                                   // note what holds the upper one of the two
            Body top = ny > 0 ? a : b, bot = ny > 0 ? b : a;
            if (top.kind == K_BLOCK) {
                float half = bot.kind == K_BLOCK ? bot.w / 2F : bot.r;
                top.supL = Math.min(top.supL, bot.x - half);
                top.supR = Math.max(top.supR, bot.x + half);
            }
        }
        if (vn >= 0) return;
        float impact = -vn;
        float e = impact > 1.4F ? 0.22F : 0F;
        float j = -(1F + e) * vn / is;
        a.vx -= j * ia * nx; a.vy -= j * ia * ny;
        b.vx += j * ib * nx; b.vy += j * ib * ny;
        float tx = rvx - vn * nx, ty = rvy - vn * ny, tl = (float) Math.sqrt(tx * tx + ty * ty);
        if (tl > 1e-5F) {
            tx /= tl; ty /= tl;
            float jt = Math.min(tl / is, 0.4F * j);
            a.vx += jt * ia * tx; a.vy += jt * ia * ty;
            b.vx -= jt * ib * tx; b.vy -= jt * ib * ty;
        }
        if (a.kind == K_BIRD && a.hit == 0) a.hit = 1;
        if (b.kind == K_BIRD && b.hit == 0) b.hit = 1;
        if (impact > TH) {
            float sum = a.mass + b.mass, k = 2.4F * (impact - TH);
            hurt(a, k * b.mass / sum);
            hurt(b, k * a.mass / sum);
        }
    }

    private void hurt(Body b, float d) {
        if (b.kind == K_BIRD || b.dead || d <= 0) return;
        float f = b.kind == K_PIG ? 1.2F : M_FRAG[b.type];
        b.hp -= d * f;
        if (b.hp <= 0) kill(b);
        else if (d * f > 0.6F) hitSound(b);
    }

    private void hitSound(Body b) {
        if (sfxCool > 0) return;
        sfxCool = 5;
        if (b.kind == K_PIG) sound(SoundEvents.PIG_HURT, 1.5F, 0.5F);
        else if (b.type == WOOD) sound(SoundEvents.WOOD_HIT, 1F, 0.8F);
        else if (b.type == ICE) sound(SoundEvents.GLASS_BREAK, 1.8F, 0.3F);
        else sound(SoundEvents.STONE_HIT, 0.9F, 0.8F);
    }

    private void kill(Body b) {
        if (b.dead) return;
        b.dead = true;
        if (b.kind == K_PIG) {
            score += 50;
            pts(b.x, b.y - 6, 50);
            puff(b.x, b.y, 0xFFB5F08A, 8);
            sound(SoundEvents.PIG_DEATH, 1.5F, 0.7F);
        } else {
            int p = b.type == WOOD ? 10 : b.type == ICE ? 8 : 20;
            score += p;
            pts(b.x, b.y - 4, p);
            chips(b);
            if (b.type == WOOD) sound(SoundEvents.WOOD_BREAK, 1F, 0.8F);
            else if (b.type == ICE) sound(SoundEvents.GLASS_BREAK, 1.2F, 0.7F);
            else sound(SoundEvents.STONE_BREAK, 0.9F, 0.8F);
        }
    }

    // ------------------------------------------------------------------ effects

    private void pts(float x, float y, int v) {
        Fx f = new Fx();
        f.kind = 3; f.x = x; f.y = y; f.vy = -0.35F; f.life = f.max = 50; f.txt = "+" + v;
        fx.add(f);
    }

    private void puff(float x, float y, int col, int n) {
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.kind = 1; f.x = x; f.y = y; f.col = col;
            f.vx = (rnd.nextFloat() - 0.5F) * 2.4F; f.vy = (rnd.nextFloat() - 0.7F) * 2.2F;
            f.life = f.max = 16 + rnd.nextInt(10);
            fx.add(f);
        }
    }

    private void chips(Body b) {
        int n = Math.max(4, (int) (b.w * b.h / 30F));
        for (int i = 0; i < Math.min(n, 14); i++) {
            Fx f = new Fx();
            f.kind = 0; f.col = M_COL[b.type];
            f.x = b.x + (rnd.nextFloat() - 0.5F) * b.w; f.y = b.y + (rnd.nextFloat() - 0.5F) * b.h;
            f.vx = (rnd.nextFloat() - 0.5F) * 2.6F; f.vy = -rnd.nextFloat() * 2F;
            f.life = f.max = 30 + rnd.nextInt(20);
            fx.add(f);
        }
    }

    private void tickFx() {
        for (Fx f : fx) {
            f.life--;
            f.x += f.vx; f.y += f.vy;
            if (f.kind == 0) f.vy += 0.1F;
            else if (f.kind == 1) { f.vx *= 0.94F; f.vy *= 0.94F; }
        }
        fx.removeIf(f -> f.life <= 0);
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, GY, 0xFF6FCBFF, 0xFFDDF5FF);
        Gfx.glow(g, 190, 18, 26, 0xFFFFF2B0, 120);
        Gfx.disc(g, 190, 18, 8, 0xFFFFF6C8);
        for (int i = 0; i < 3; i++) Gfx.cloud(g, (int) ((i * 85 + time * 0.08F) % (W + 50)) - 30, 14 + i * 16 + (i % 2) * 6, 30 + i * 4, 0xCCFFFFFF);
        Gfx.ellipse(g, 60, GY, 70, 24, 0xFF8FD87A);
        Gfx.ellipse(g, 170, GY, 80, 16, 0xFF7ACB68);
        g.fillGradient(0, GY, W, H, 0xFF6BCF58, 0xFF3F9A3A);
        g.fill(0, GY, W, GY + 2, 0xFF9EF08A);
        g.fill(0, GY + 2, W, H, 0xFF8A5A34);
        g.fillGradient(0, GY + 2, W, H, 0xFF9A6A3E, 0xFF6E4526);
        g.fill(0, GY, W, GY + 3, 0xFF7EE05F);

        // the birds that wait on the ground
        for (int i = 0; i < queue.length - qi; i++) drawBird(g, 24 - 7 * i, GY - 4, queue[qi + i], 4, false);
        drawSlingBack(g);
        for (Body b : bodies) if (b.kind == K_BLOCK) drawBlock(g, b);
        for (Body b : bodies) if (b.kind == K_PIG) drawPig(g, b);
        for (Body b : bodies) if (b.kind == K_BIRD) drawBird(g, Math.round(b.x), Math.round(b.y), b.type, Math.round(b.r), true);
        float bx = AX, by = AY;
        if (cur >= 0) {
            if (state == S_DRAG) { bx = px; by = py; }
            else if (hop > 0) {
                float t = hop / 24F, hy = (float) Math.sin(t * Math.PI) * 14F;
                bx = AX + (24F - AX) * t; by = AY + (GY - 4F - AY) * t - hy;
            }
            if (state == S_DRAG) drawGuide(g);
            if (state == S_DRAG) drawBands(g, bx, by, true); else drawBands(g, AX, AY, false);
            drawBird(g, Math.round(bx), Math.round(by), cur, 4, false);
        } else drawBands(g, AX, AY, false);
        drawSlingFront(g);

        for (Fx f : fx) drawFx(g, f);
        hud(g);
    }

    private void drawSlingBack(GuiGraphics g) {
        int x = (int) AX;
        g.fill(x - 2, 100, x + 3, GY, 0xFF6B3F1E);
        g.fill(x - 1, 100, x + 1, GY, 0xFF8A5A2E);
        Gfx.line(g, x + 2, 100, x + 4, 92, 0xFF54300F);
        Gfx.line(g, x + 3, 100, x + 5, 92, 0xFF54300F);
    }

    private void drawSlingFront(GuiGraphics g) {
        int x = (int) AX;
        Gfx.line(g, x - 2, 100, x - 4, 92, 0xFF8A5A2E);
        Gfx.line(g, x - 1, 100, x - 3, 92, 0xFFA8713A);
        g.fill(x - 5, 91, x - 2, 93, 0xFF6B3F1E);
    }

    private void drawBands(GuiGraphics g, float bx, float by, boolean stretched) {
        int col = stretched ? 0xFF3A1E0C : 0xFF4A2A14;
        Gfx.line(g, (int) AX - 4, 92, Math.round(bx) - 1, Math.round(by), col);
        Gfx.line(g, (int) AX + 4, 92, Math.round(bx) + 1, Math.round(by), col);
    }

    private void drawGuide(GuiGraphics g) {
        float x = px, y = py, vx = (AX - px) * VMAX / MAXD, vy = (AY - py) * VMAX / MAXD;
        for (int t = 1; t <= 48; t++) {
            vy += G; x += vx; y += vy;
            if (y > GY - 2) break;
            if (t % 4 == 0) {
                int a = 255 - t * 3;
                g.fill(Math.round(x), Math.round(y) + 1, Math.round(x) + 2, Math.round(y) + 3, Gfx.alpha(0xFF2A5A7A, a / 3));
                g.fill(Math.round(x), Math.round(y), Math.round(x) + 2, Math.round(y) + 2, Gfx.alpha(0xFFFFFFFF, a));
            }
        }
    }

    private static void drawBird(GuiGraphics g, int cx, int cy, int type, int r, boolean angry) {
        int col = B_COL[type];
        Gfx.ball(g, cx, cy, r, col);
        if (type == BLACK) g.fill(cx - 1, cy - r - 2, cx + 1, cy - r, 0xFFE0A030);          // the fuse
        else g.fill(cx - 2, cy - r, cx + 1, cy - r + 1, Gfx.darker(col, 0.25F));           // a tuft
        Gfx.ellipse(g, cx, cy + 2, 2, 1, Gfx.lighter(col, 0.6F));                            // the belly
        g.fill(cx, cy - 2, cx + 2, cy, 0xFFFFFFFF);
        g.fill(cx + 2, cy - 2, cx + 4, cy, 0xFFFFFFFF);
        g.fill(cx + 1, cy - 1, cx + 2, cy, 0xFF1A1428);
        g.fill(cx + 3, cy - 1, cx + 4, cy, 0xFF1A1428);
        g.fill(cx - 1, cy - 3, cx + 5, cy - 2, Gfx.darker(col, 0.5F));                     // the angry brow
        g.fill(cx + r, cy, cx + r + 2, cy + 2, 0xFFF5A030);                                  // the beak
    }

    private static void drawPig(GuiGraphics g, Body b) {
        int cx = Math.round(b.x), cy = Math.round(b.y), r = 5;
        float k = b.hp / b.maxHp;
        Gfx.ball(g, cx, cy, r, 0xFF7ED957);
        g.fill(cx - 4, cy - r - 1, cx - 2, cy - r + 1, 0xFF5FB840);
        g.fill(cx + 2, cy - r - 1, cx + 4, cy - r + 1, 0xFF5FB840);
        g.fill(cx - 3, cy - 2, cx - 1, cy, 0xFFFFFFFF);
        g.fill(cx + 1, cy - 2, cx + 3, cy, 0xFFFFFFFF);
        g.fill(cx - 2, cy - 1, cx - 1, cy, 0xFF1A1428);
        g.fill(cx + 2, cy - 1, cx + 3, cy, 0xFF1A1428);
        Gfx.ellipse(g, cx, cy + 2, 3, 2, 0xFFA6EC82);
        g.fill(cx - 1, cy + 1, cx, cy + 3, 0xFF3F8A2A);
        g.fill(cx + 1, cy + 1, cx + 2, cy + 3, 0xFF3F8A2A);
        if (k < 0.6F) g.fill(cx - 4, cy - 4, cx - 2, cy - 3, 0xFF6A9A4A);                  // a bruise
        if (k < 0.3F) g.fill(cx + 1, cy - 5, cx + 4, cy - 4, 0xFFFFFFFF);                  // a bandage
    }

    private static void drawBlock(GuiGraphics g, Body b) {
        int x = Math.round(b.x - b.w / 2F), y = Math.round(b.y - b.h / 2F), w = Math.round(b.w), h = Math.round(b.h);
        int col = M_COL[b.type];
        Gfx.bubble(g, x, y, w, h, 1, col);
        int dark = Gfx.darker(col, 0.25F), light = Gfx.lighter(col, 0.35F);
        if (b.type == WOOD) {
            if (w >= h) for (int i = 4; i < w - 3; i += 6) g.fill(x + i, y + 1, x + i + 1, y + h - 1, dark);
            else for (int j = 4; j < h - 3; j += 6) g.fill(x + 1, y + j, x + w - 1, y + j + 1, dark);
        } else if (b.type == ICE) {
            g.fill(x + 1, y + 1, x + Math.min(w - 1, 4), y + 2, 0xFFFFFFFF);
            if (h > 6) g.fill(x + 1, y + 1, x + 2, y + Math.min(h - 1, 5), 0xFFFFFFFF);
        } else {
            for (int i = 0; i < 4; i++) g.fill(x + 2 + (i * 5) % Math.max(1, w - 3), y + 2 + (i * 7) % Math.max(1, h - 3), x + 3 + (i * 5) % Math.max(1, w - 3), y + 3 + (i * 7) % Math.max(1, h - 3), light);
        }
        float k = b.hp / b.maxHp;
        if (k < 0.66F) Gfx.line(g, x + 1, y + 1, x + w / 2, y + h - 2, dark);
        if (k < 0.33F) Gfx.line(g, x + w - 2, y + 1, x + w / 2 - 1, y + h / 2, dark);
    }

    private void drawFx(GuiGraphics g, Fx f) {
        int x = Math.round(f.x), y = Math.round(f.y);
        float t = f.life / (float) f.max;
        switch (f.kind) {
            case 0 -> g.fill(x, y, x + 2, y + 2, Gfx.fade(f.col, Math.min(1F, t * 2F)));
            case 1 -> Gfx.disc(g, x, y, Math.max(1, Math.round(3 * t) + 1), Gfx.fade(f.col, t));
            case 2 -> {
                int rr = Math.round(28F * (1F - t));
                Gfx.glow(g, x, y, rr + 4, 0xFFFFB347, Math.round(150 * t));
                Gfx.disc(g, x, y, Math.max(1, rr / 2), Gfx.fade(0xFFFFF0B0, t));
            }
            default -> ctext(g, f.txt, x, y, Gfx.fade(0xFFFFFFFF, Math.min(1F, t * 2F)));
        }
    }

    private void hud(GuiGraphics g) {
        Gfx.rrect(g, 3, 3, 62, 11, 3, Gfx.fade(0xFF000000, 0.35F));
        text(g, Component.translatable("cutemod.birds.level", level + 1, LEVELS).getString(), 7, 5, 0xFFFFFFFF);
        for (int i = 0; i < LIVES; i++) Gfx.heart(g, W - 11 - i * 9, 5, i < lives ? 0xFFFF6A8E : 0x55FFFFFF);
        if (bannerT > 0 && state == S_READY) banner(g, Component.translatable("cutemod.birds.level", level + 1, LEVELS).getString());
        if (state == S_CLEAR) banner(g, Component.translatable("cutemod.birds.clear").getString());
        if (state == S_FAIL) banner(g, Component.translatable("cutemod.birds.fail").getString());
    }

    private static void banner(GuiGraphics g, String s) {
        int w = Math.min(W - 20, tw(s) + 24);
        Gfx.rrect(g, (W - w) / 2, 30, w, 16, 5, Gfx.fade(0xFF000000, 0.5F));
        ctext(g, s, W / 2, 34, 0xFFFFD866);
    }

    // ------------------------------------------------------------------ misc

    @Override
    public String hintKey() { return "cutemod.hint.birds"; }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return won ? Component.translatable("cutemod.birds.won") : Component.translatable("cutemod.ui.gameover");
    }
}
