package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/**
 * The pictures of the City (the street the pet walks along, see {@link PetCity}): pastel pixel art, drawn from rectangles.
 * Everything here is STATIC: {@link PetCity} bakes every layer once into a texture ({@link TexCache}) and only draws the
 * moving things (clouds, cars, tram, people, water) on top. A layer is drawn in the coordinates of the world: x runs along
 * the street (0 .. {@link #WW}) and y is the row on the screen (the header takes the top 17 rows, the hint bar the bottom 12).
 *
 * The time of day is not baked into the colours: the street is baked in day colours and drawn multiplied by a tint at dusk
 * and at night, with the second layer ({@link #lights}: lit windows, lamps, neon) drawn over it without the tint. Only the
 * sky is baked once for each time of day.
 */
final class CityArt {
    private CityArt() {}

    /** The street is 840 wide (the screen shows 300 of it); the far and the middle skyline move slower than the street. */
    static final int WW = 840, SCREEN_W = 300;
    static final float FAR_K = 0.25F, MID_K = 0.5F;
    static final int FAR_W = SCREEN_W + Math.round((WW - SCREEN_W) * FAR_K), MID_W = SCREEN_W + Math.round((WW - SCREEN_W) * MID_K);
    static final int TOP = 17, BASE = 112, WALK_MIN = 116, WALK_MAX = 127, CURB = 130, ROAD_END = 166;

    // ---------- tiny helpers (this class stands alone) ----------
    static void r(GuiGraphics g, int x, int y, int w, int h, int c) { if (w > 0 && h > 0) g.fill(x, y, x + w, y + h, c); }

    static void ball(GuiGraphics g, int cx, int cy, int rad, int c) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.round(Math.sqrt((rad + 0.2) * (rad + 0.2) - dy * dy));
            r(g, cx - dx, cy + dy, dx * 2 + 1, 1, c);
        }
    }

    static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int c) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0, 1 - dy * dy / (double) (ry * ry + 1))));
            r(g, cx - dx, cy + dy, dx * 2, 1, c);
        }
    }

    static void tri(GuiGraphics g, int cx, int top, int w, int h, int c) {
        for (int row = 0; row < h; row++) r(g, cx - Math.max(1, w * (row + 1) / h) / 2, top + row, Math.max(1, w * (row + 1) / h), 1, c);
    }

    static void ln(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        int n = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)));
        for (int i = 0; i <= n; i++) r(g, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, 1, 1, c);
    }

    static int dk(int c, float f) { return App.mix(c, 0xFF000000, f); }

    static int lt(int c, float f) { return App.mix(c, 0xFFFFFFFF, f); }

    static int hash(int n) {
        n ^= n >>> 15; n *= 0x2C1B3C6D; n ^= n >>> 12; n *= 0x297A2D39; n ^= n >>> 15;
        return n & 0x7FFFFFFF;
    }

    /** The windows that are lit at dusk and at night: {x, y, w, h, kind}. Filled while the street is drawn, read by {@link #lights}. */
    private static final List<int[]> LIT = new ArrayList<>();
    /** The glows of the lamps and signs: {x, y, radius, argb}. */
    private static final List<int[]> GLOWS = new ArrayList<>();
    /** Where the street lamps stand. */
    static final int[] LAMPS = {74, 156, 336, 422, 590, 688, 836};

    // =====================================================================================================
    //  THE SKY (baked for each time of day: 0 day, 1 dusk, 2 night) and the two skylines behind the street
    // =====================================================================================================
    static final int[][] SKY = {
            {0xFF8CCBFF, 0xFFBFE4FF, 0xFFFFE3EE},        // day: blue, pale blue, a pink horizon
            {0xFF6E78D0, 0xFFE892B8, 0xFFFFC890},        // dusk: indigo, rose, peach
            {0xFF10173F, 0xFF2A2F78, 0xFF5A4C9C}};       // night: navy, indigo, violet

    /** The sky and the far skyline (the layer that moves the slowest). */
    static void far(GuiGraphics g, int phase) {
        int[] s = SKY[phase];
        g.fillGradient(0, 0, FAR_W, 62, s[0], s[1]);
        g.fillGradient(0, 62, FAR_W, 118, s[1], s[2]);
        r(g, 0, 118, FAR_W, 60, s[2]);
        if (phase == 0) {                                         // a soft sun with a ring of light
            ball(g, 330, 48, 19, 0x20FFF2C0); ball(g, 330, 48, 14, 0x30FFF2C0); ball(g, 330, 48, 9, 0xFFFFF0B0); ball(g, 330, 48, 7, 0xFFFFFAD8);
        } else if (phase == 1) {                                  // a low sun behind the towers
            ball(g, 120, 96, 26, 0x28FFE0A0); ball(g, 120, 96, 17, 0x50FFD080); ball(g, 120, 96, 11, 0xFFFFE8A8); ball(g, 120, 96, 8, 0xFFFFF4D0);
        } else {                                                  // a crescent moon and a few fixed stars (the others twinkle live)
            ball(g, 336, 44, 17, 0x18C8D0FF); ball(g, 336, 44, 11, 0xFFF4F0D0); ball(g, 341, 41, 10, s[0]);
            r(g, 330, 48, 2, 2, 0x30B0A870); r(g, 333, 52, 2, 1, 0x30B0A870);
        }
        if (phase == 2) {                                         // stars (they are behind the towers, which are drawn after them)
            for (int i = 0; i < 70; i++) {
                int a = hash(i * 977 + 13), sx = a % FAR_W, sy = 19 + (a >> 9) % 70;
                r(g, sx, sy, 1, 1, i % 4 == 0 ? 0xFFFFFFFF : 0xB0D8E0FF);
                if (i % 9 == 0) { r(g, sx - 1, sy, 3, 1, 0x80FFFFFF); r(g, sx, sy - 1, 1, 3, 0x80FFFFFF); }
            }
        }
        // the far towers: pale, low contrast, they melt into the horizon
        int hz = s[2];
        int[][] t = {{6, 40, 24}, {26, 58, 18}, {42, 30, 30}, {68, 66, 20}, {90, 44, 26}, {114, 74, 18}, {130, 36, 32}, {160, 56, 22}, {180, 80, 20},
                {200, 48, 28}, {230, 62, 24}, {254, 34, 30}, {284, 70, 18}, {302, 50, 26}, {330, 82, 20}, {350, 42, 30}, {380, 64, 24}, {404, 38, 26}};
        for (int k = 0; k < t.length; k++) {
            int x = t[k][0], h = t[k][1], w = t[k][2];
            int c = App.mix(phase == 2 ? 0xFF3C3C88 : phase == 1 ? 0xFFB07CB8 : 0xFFA8C0E8, hz, 0.4F);
            r(g, x, 112 - h, w, h, c);
            if (k % 3 == 0) { r(g, x + w / 2, 112 - h - 7, 1, 7, c); }
            r(g, x, 112 - h, w, 1, lt(c, 0.25F));
            if (phase > 0) for (int wy = 112 - h + 4; wy < 108; wy += 5) for (int wx = x + 3; wx < x + w - 3; wx += 5)
                if (hash(wx * 31 + wy * 7 + k) % 5 < 2) r(g, wx, wy, 2, 2, phase == 2 ? 0xFFFFE6A0 : 0x88FFE6A0);
        }
    }

    /** The middle skyline: bigger, softer towers with window grids, a bridge of lights between two of them. */
    static void mid(GuiGraphics g) {
        int[][] t = {{0, 56, 34, 0xFFC8B4E0}, {30, 78, 26, 0xFFA8C4E8}, {58, 48, 36, 0xFFE8B8C8}, {98, 90, 24, 0xFF98B8E0}, {124, 60, 32, 0xFFD0BCE8},
                {160, 70, 28, 0xFFB0D4E0}, {192, 52, 34, 0xFFE8C0B8}, {232, 86, 26, 0xFF9CB0E4}, {262, 62, 30, 0xFFC8B8E8}, {298, 74, 28, 0xFFA8D0D8},
                {330, 50, 36, 0xFFE4B4C4}, {372, 82, 26, 0xFF9AB8E8}, {402, 58, 32, 0xFFD0C0E8}, {440, 70, 28, 0xFFB4D8E0}, {472, 54, 34, 0xFFE8BCB4},
                {510, 84, 28, 0xFFA0B4E8}};
        for (int k = 0; k < t.length; k++) {
            int x = t[k][0], h = t[k][1], w = t[k][2], c = t[k][3], y = 114 - h;
            r(g, x, y, w, h, c);
            r(g, x, y, w, 2, lt(c, 0.4F));
            r(g, x + w - 3, y + 2, 3, h - 2, dk(c, 0.1F));
            if (k % 2 == 1) { r(g, x + w / 2 - 1, y - 8, 2, 8, dk(c, 0.2F)); r(g, x + w / 2 - 1, y - 9, 2, 1, 0xFFFF9AB8); }
            else if (k % 4 == 0) { r(g, x + 3, y - 4, w - 6, 4, dk(c, 0.1F)); }
            for (int wy = y + 6; wy < 106; wy += 6) for (int wx = x + 4; wx < x + w - 5; wx += 6) r(g, wx, wy, 3, 3, lt(c, 0.55F));
        }
        // a bridge of lights between two towers
        r(g, 56, 62, 44, 2, 0xFFF4EAF8); r(g, 56, 64, 44, 1, 0xFFB8A8D0);
        for (int x = 60; x < 98; x += 6) r(g, x, 58, 1, 4, 0xFFB8A8D0);
    }

    // =====================================================================================================
    //  THE STREET (day colours): the buildings along the pavement, the pavement, the road
    // =====================================================================================================
    static void street(GuiGraphics g) {
        LIT.clear();
        GLOWS.clear();
        bookshop(g, 0);
        cafe(g, 78);
        bakery(g, 160);
        square(g, 222);
        cinema(g, 338);
        florist(g, 424);
        arcade(g, 494);
        hall(g, 590);
        boutique(g, 690);
        pavement(g);
        // things on the pavement in front of the buildings
        for (int x : LAMPS) lamp(g, x);
        tree(g, 218, 0xFFFF9CC0); tree(g, 342, 0xFFFF9CC0); tree(g, 770, 0xFF6CC68C);
        terrace(g, 100); terrace(g, 134);
        flowerStands(g, 436); flowerStands(g, 470);
        bench(g, 252); bench(g, 308);
        fountain(g, 280);
        bunting(g, 0, 46, 76, 54, 7, 0xFFFF8FB8, 0xFFFFE066);
        bunting(g, 160, 50, 340, 44, 14, 0xFF8ADCE0, 0xFFFFB8D0);
        bunting(g, 424, 40, 592, 48, 12, 0xFFFFE066, 0xFFB8A0F0);
        iceCream(g, 782);
        busStop(g, 818);
        stop(g, -12);
    }

    /** The pavement, the kerb and the road with its marks. */
    private static void pavement(GuiGraphics g) {
        g.fillGradient(0, BASE, WW, CURB, 0xFFF3EAF2, 0xFFE4D8EA);
        for (int y = BASE + 2, row = 0; y < CURB; y += 6, row++) {                         // the paving slabs, a little wider near the front
            r(g, 0, y, WW, 1, 0x16805090);
            for (int x = (row % 2) * 7; x < WW; x += 14 + row) r(g, x, y + 1, 1, 5, 0x10805090);
        }
        r(g, 0, BASE, WW, 1, 0x30604070);                                                   // the foot of the walls
        r(g, 0, BASE + 1, WW, 2, 0x18604070);
        r(g, 0, CURB, WW, 2, 0xFFFFFFFF); r(g, 0, CURB + 2, WW, 2, 0xFFC8BAD8); r(g, 0, CURB + 4, WW, 1, 0xFF9A8CB8);   // the kerb
        g.fillGradient(0, CURB + 5, WW, ROAD_END, 0xFF635C80, 0xFF4F4A6C);
        for (int x = 0; x < WW; x += 24) r(g, x, 146, 14, 1, 0xFFF4E8A8);                   // the lane mark
        for (int x = 4; x < WW; x += 40) r(g, x, 138, 2, 1, 0x18FFFFFF);                    // little shine on the asphalt
        for (int zx : new int[]{300, 566}) for (int i = 0; i < 6; i++) r(g, zx + i * 4, CURB + 5, 3, 22, 0xE0F4EEF8);     // zebra crossings
    }

    // ---------- little parts used by many buildings ----------
    private static void awning(GuiGraphics g, int x, int y, int w, int c1, int c2) {
        r(g, x - 1, y, w + 2, 2, dk(c1, 0.25F));
        for (int i = 0; i < w; i += 4) {
            int c = (i / 4) % 2 == 0 ? c1 : c2;
            r(g, x + i, y + 2, 4, 6, c);
            r(g, x + i + 1, y + 8, 2, 1, c);
            r(g, x + i, y + 2, 4, 1, lt(c, 0.3F));
        }
        r(g, x, y + 9, w, 2, 0x20000000);
    }

    /** A window with a frame, two panes of glass with a shine, a cross bar and a sill; it can be lit at night. */
    private static void win(GuiGraphics g, int x, int y, int w, int h, int trim, int wall, boolean lit) {
        r(g, x - 1, y - 1, w + 2, h + 2, trim);
        r(g, x - 1, y - 1, 1, 1, wall); r(g, x + w, y - 1, 1, 1, wall);                     // round top corners
        r(g, x, y, w, h / 2 + 1, 0xFFB8E4FF);
        r(g, x, y + h / 2 + 1, w, h - h / 2 - 1, 0xFF8CCBF0);
        r(g, x + 1, y + 3, 1, 1, 0xB0FFFFFF); r(g, x + 2, y + 2, 1, 1, 0xB0FFFFFF); r(g, x + 3, y + 1, 1, 1, 0xB0FFFFFF);
        if (w >= 6) r(g, x + w / 2, y, 1, h, trim);
        r(g, x, y + h / 2, w, 1, trim);
        r(g, x - 2, y + h + 1, w + 4, 1, dk(trim, 0.15F)); r(g, x - 2, y + h + 2, w + 4, 1, 0x20000000);
        if (lit) LIT.add(new int[]{x, y, w, h, trim});
    }

    private static void door(GuiGraphics g, int x, int y, int w, int h, int c) {
        r(g, x - 1, y - 1, w + 2, h + 1, dk(c, 0.3F));
        r(g, x, y, w, h, c);
        r(g, x + 1, y + 1, w - 2, h / 3, 0xFFB8E4FF); r(g, x + 1, y + 1, 1, h / 3 - 1, 0xB0FFFFFF);    // the glass
        r(g, x + 1, y + h / 3 + 3, w - 2, h - h / 3 - 5, dk(c, 0.1F));
        r(g, x + w - 3, y + h / 2, 1, 2, 0xFFFFE680);                                          // the handle
        if (w >= 7) r(g, x + w / 2, y, 1, h, dk(c, 0.3F));
    }

    /** A big shop window: glass with a shine, and the glow of the shop behind it at night. */
    private static void shopWindow(GuiGraphics g, int x, int y, int w, int h, int frame, int back) {
        r(g, x - 1, y - 1, w + 2, h + 2, frame);
        r(g, x, y, w, h, back);
        r(g, x, y, w, 2, lt(back, 0.4F));
        for (int i = 0; i < 3; i++) r(g, x + 3 + i * 5, y + 1 + i, 2, 4 + i, 0x60FFFFFF);      // the shine of the glass
        LIT.add(new int[]{x, y, w, h, -2});
    }

    /** A round hanging sign with a little picture: 0 book, 1 cup, 2 croissant, 3 flower, 4 film, 5 joystick, 6 clock, 7 dress, 8 paw. */
    static void sign(GuiGraphics g, int cx, int y, int kind, int c) {
        r(g, cx - 1, y - 4, 2, 4, 0xFF6A5A7A);                                                 // the bracket
        ball(g, cx, y + 6, 7, dk(c, 0.3F));
        ball(g, cx, y + 6, 6, c);
        ball(g, cx, y + 5, 5, lt(c, 0.5F));
        int px = cx - 3, py = y + 3;
        switch (kind) {
            case 0 -> { r(g, px, py, 7, 6, 0xFFE05A78); r(g, px + 3, py, 1, 6, 0xFFFFE8F0); r(g, px, py + 5, 7, 1, 0xFFFFFFFF); r(g, px + 1, py + 1, 2, 1, 0xFFFFFFFF); }
            case 1 -> { r(g, px + 1, py + 2, 5, 4, 0xFFFFFFFF); r(g, px + 6, py + 3, 1, 2, 0xFFFFFFFF); r(g, px + 1, py + 2, 5, 1, 0xFF8A5A3A); r(g, px + 2, py - 1, 1, 2, 0xAA9A8AA8); r(g, px + 4, py - 1, 1, 2, 0xAA9A8AA8); }
            case 2 -> { r(g, px, py + 2, 7, 3, 0xFFE8A04A); r(g, px + 1, py + 1, 5, 1, 0xFFE8A04A); r(g, px + 2, py + 5, 3, 1, 0xFFE8A04A); r(g, px + 2, py + 1, 1, 4, 0xFFC87A2A); r(g, px + 4, py + 1, 1, 4, 0xFFC87A2A); r(g, px + 1, py + 2, 1, 1, 0xFFFFE0A0); }
            case 3 -> { r(g, px + 3, py + 4, 1, 3, 0xFF4AAA5A); r(g, px + 2, py + 1, 3, 3, 0xFFFFE066); r(g, px + 3, py, 1, 5, 0xFFFF7AA8); r(g, px + 1, py + 2, 5, 1, 0xFFFF7AA8); r(g, px + 3, py + 2, 1, 1, 0xFFFFE066); }
            case 4 -> { r(g, px, py + 1, 7, 5, 0xFF3A3A5A); r(g, px, py, 7, 2, 0xFFFFFFFF); r(g, px + 1, py, 1, 2, 0xFF3A3A5A); r(g, px + 3, py, 1, 2, 0xFF3A3A5A); r(g, px + 5, py, 1, 2, 0xFF3A3A5A); r(g, px + 2, py + 3, 3, 2, 0xFFFFD060); }
            case 5 -> { r(g, px + 3, py, 1, 3, 0xFFE0E0F0); r(g, px + 2, py - 1, 3, 2, 0xFFFF5A7A); r(g, px, py + 3, 7, 3, 0xFF6A6AC8); r(g, px + 1, py + 4, 1, 1, 0xFFFFE066); r(g, px + 5, py + 4, 1, 1, 0xFF6AE0A0); }
            case 6 -> { ball(g, cx, y + 6, 4, 0xFFFFFFFF); r(g, cx, y + 3, 1, 3, 0xFF3A2A4A); r(g, cx, y + 6, 3, 1, 0xFF3A2A4A); }
            case 7 -> { r(g, px + 2, py, 3, 2, 0xFFFF7AA8); r(g, px + 1, py + 2, 5, 2, 0xFFFF7AA8); r(g, px, py + 4, 7, 2, 0xFFFF7AA8); r(g, px + 2, py + 2, 3, 1, 0xFFFFFFFF); }
            default -> { ball(g, cx, y + 7, 2, 0xFF8A5A3A); r(g, cx - 3, y + 3, 1, 2, 0xFF8A5A3A); r(g, cx - 1, y + 2, 1, 2, 0xFF8A5A3A); r(g, cx + 1, y + 2, 1, 2, 0xFF8A5A3A); r(g, cx + 3, y + 3, 1, 2, 0xFF8A5A3A); }
        }
    }

    private static void plantBox(GuiGraphics g, int x, int y, int w, int a, int b) {
        r(g, x, y + 2, w, 3, 0xFFB5703A); r(g, x, y + 2, w, 1, 0xFFD89A5A);
        for (int i = 0; i < w; i += 3) {
            r(g, x + i, y, 2, 3, 0xFF4AAA5A);
            r(g, x + i, y - 1 + (i / 3) % 2, 2, 2, i % 6 == 0 ? a : b);
        }
    }

    private static void roofTop(GuiGraphics g, int x, int y, int w, int c) {
        r(g, x - 1, y - 3, w + 2, 3, lt(c, 0.35F)); r(g, x - 1, y - 1, w + 2, 1, dk(c, 0.2F));      // the cornice
        r(g, x, y, w, 1, 0x30000000);
    }

    private static void wallBody(GuiGraphics g, int x, int top, int w, int c) {
        r(g, x, top, w, BASE - top, c);
        r(g, x, top, 2, BASE - top, lt(c, 0.25F));
        r(g, x + w - 3, top, 3, BASE - top, dk(c, 0.08F));
        r(g, x + w - 1, top, 1, BASE - top, dk(c, 0.18F));
        for (int y = top + 6; y < BASE; y += 8) r(g, x + 2, y, w - 5, 1, dk(c, 0.04F));             // a faint line of bricks
    }

    // =====================================================================================================
    //  THE BUILDINGS (x0 = the left edge)
    // =====================================================================================================
    /** The book tower: lavender, a rooftop garden and a water tank, a shop with shelves of books. */
    private static void bookshop(GuiGraphics g, int x0) {
        int c = 0xFFCDBCEC, trim = 0xFF8E78C8, top = 30;
        wallBody(g, x0, top, 78, c);
        roofTop(g, x0, top, 78, c);
        r(g, x0 + 8, top - 14, 14, 11, 0xFFB08A5A); r(g, x0 + 8, top - 16, 14, 3, 0xFF8A6A3A); r(g, x0 + 10, top - 3, 2, 3, 0xFF6A4A2A); r(g, x0 + 18, top - 3, 2, 3, 0xFF6A4A2A);   // the water tank
        r(g, x0 + 52, top - 12, 1, 12, 0xFF6A5A7A); r(g, x0 + 47, top - 9, 11, 1, 0xFF6A5A7A); r(g, x0 + 49, top - 5, 7, 1, 0xFF6A5A7A);  // an antenna
        for (int i = 0; i < 6; i++) { ball(g, x0 + 30 + i * 6, top - 3, 3, i % 2 == 0 ? 0xFF6CC68C : 0xFF4AAA5A); }                                 // the rooftop garden
        r(g, x0 + 36, top - 5, 3, 2, 0xFFFF7AA8); r(g, x0 + 48, top - 6, 2, 2, 0xFFFFE066);
        for (int row = 0; row < 3; row++) for (int col = 0; col < 3; col++) win(g, x0 + 8 + col * 22, top + 8 + row * 15, 9, 10, trim, c, hash(row * 7 + col) % 4 != 0);
        plantBox(g, x0 + 7, top + 19, 11, 0xFFFF7AA8, 0xFFFFE066);
        plantBox(g, x0 + 51, top + 34, 11, 0xFFFF9AC8, 0xFFFFFFFF);
        r(g, x0, 88, 78, 2, trim); r(g, x0, 88, 78, 1, lt(trim, 0.4F));                                                                          // a band over the shop
        shopWindow(g, x0 + 6, 92, 34, 17, dk(trim, 0.2F), 0xFFFFE9D0);
        int[] book = {0xFFE05A78, 0xFF5A8AE0, 0xFFFFC040, 0xFF5AC090, 0xFF9A6AD8, 0xFFFF8A5A};
        for (int sh = 0; sh < 2; sh++) {
            r(g, x0 + 7, 99 + sh * 8, 32, 1, 0xFF8A5A3A);
            for (int i = 0; i < 9; i++) r(g, x0 + 8 + i * 3 + (i > 5 ? 1 : 0), 92 + sh * 8 + (i % 3), 2, 7 - (i % 3), book[(i + sh * 2) % 6]);
        }
        door(g, x0 + 46, 90, 11, 20, 0xFF7A5AB8);
        awning(g, x0 + 4, 84, 56, 0xFF9A7AD8, 0xFFFFFFFF);
        sign(g, x0 + 66, 90, 0, 0xFFE8D8FF);
        r(g, x0 + 62, 107, 12, 3, 0xFF8A6A4A); r(g, x0 + 64, 105, 8, 2, 0xFFFF9AB8);                                                              // a book stand
    }

    /** The cafe: peach walls, big arched windows, a striped awning, a terrace with parasols. */
    private static void cafe(GuiGraphics g, int x0) {
        int c = 0xFFFAD2B0, trim = 0xFFC8805A, top = 58;
        wallBody(g, x0, top, 82, c);
        roofTop(g, x0, top, 82, c);
        for (int i = 0; i < 82; i += 3) r(g, x0 + i, top - 5, 2, 2, i % 6 == 0 ? 0xFFC8805A : 0xFFE0A07A);                                       // a scalloped parapet
        for (int col = 0; col < 3; col++) win(g, x0 + 8 + col * 25, top + 6, 12, 14, trim, c, true);
        plantBox(g, x0 + 6, top + 22, 16, 0xFFFF7A9A, 0xFFFFE066); plantBox(g, x0 + 56, top + 22, 16, 0xFFFFFFFF, 0xFFFF9AC8);
        shopWindow(g, x0 + 6, 90, 30, 18, 0xFF8A4A2A, 0xFFFFE6C8);
        r(g, x0 + 8, 100, 26, 1, 0xFFB8805A);
        for (int i = 0; i < 4; i++) { r(g, x0 + 10 + i * 6, 96, 4, 4, 0xFFFFFFFF); r(g, x0 + 10 + i * 6, 95, 4, 1, 0xFFFF9AB8); }                // cakes in the window
        r(g, x0 + 9, 102, 8, 4, 0xFF8A5A3A); r(g, x0 + 20, 102, 6, 6, 0xFFE8A04A);
        door(g, x0 + 42, 90, 11, 20, 0xFFB8603A);
        awning(g, x0 + 2, 82, 56, 0xFFD2604A, 0xFFFFF2E0);
        sign(g, x0 + 68, 88, 1, 0xFFFFE9D0);
        r(g, x0 + 64, 102, 14, 8, 0xFF2A4A3A); r(g, x0 + 65, 103, 12, 6, 0xFF3A5A4A);                                                            // the chalk board
        r(g, x0 + 67, 104, 8, 1, 0xFFF4F0E0); r(g, x0 + 67, 106, 6, 1, 0xFFFF9AB8); r(g, x0 + 67, 108, 7, 1, 0xFFF4F0E0);
    }

    /** The bakery: mint walls, a tiled mansard roof, a chimney, loaves in the window. */
    private static void bakery(GuiGraphics g, int x0) {
        int c = 0xFFC4ECD4, trim = 0xFF5AAA84, top = 50;
        wallBody(g, x0, top, 62, c);
        for (int i = 0; i < 12; i++) {                                                                                                           // the roof: a trapezoid of tiles
            int w2 = 40 + i * 2, xs = x0 + (62 - w2) / 2, y = top - 12 + i;
            r(g, xs, y, w2, 1, 0xFFC8604A);
            for (int x = xs + (i % 2) * 2; x < xs + w2; x += 4) r(g, x, y, 1, 1, 0xFFA8483A);
            r(g, xs, y, 1, 1, 0xFFE08A70); r(g, xs + w2 - 1, y, 1, 1, 0xFF8A3A30);
        }
        r(g, x0 + 9, top - 1, 44, 1, 0xFFA8483A); r(g, x0 + 20, top - 12, 22, 1, 0xFFE08A70);
        r(g, x0 + 44, top - 24, 8, 16, 0xFFB86A5A); r(g, x0 + 43, top - 25, 10, 2, 0xFF8A4A3A);                                                  // the chimney
        r(g, x0 + 44, top - 24, 2, 16, 0xFFD88A7A);
        for (int col = 0; col < 2; col++) win(g, x0 + 10 + col * 28, top + 8, 11, 14, trim, c, true);
        plantBox(g, x0 + 8, top + 24, 15, 0xFFFF9AC8, 0xFFFFE066);
        shopWindow(g, x0 + 5, 88, 28, 20, 0xFF3A8A64, 0xFFFFEED0);
        r(g, x0 + 6, 98, 26, 1, 0xFFB88A5A);
        for (int i = 0; i < 4; i++) { r(g, x0 + 8 + i * 6, 93, 5, 4, 0xFFE8A04A); r(g, x0 + 9 + i * 6, 92, 3, 1, 0xFFF0C070); }                  // loaves
        for (int i = 0; i < 3; i++) { r(g, x0 + 9 + i * 8, 102, 6, 3, 0xFFD88A3A); r(g, x0 + 10 + i * 8, 101, 4, 1, 0xFFE8A04A); }              // croissants
        door(g, x0 + 38, 90, 11, 20, 0xFF3A9A74);
        awning(g, x0 + 2, 82, 50, 0xFF5AC08C, 0xFFFFFFFF);
        sign(g, x0 + 54, 86, 2, 0xFFFFF0D0);
        r(g, x0 + 52, 104, 8, 6, 0xFFB8805A); r(g, x0 + 53, 103, 6, 2, 0xFFE8A04A);                                                              // a bread basket
    }

    /** The cinema: a navy art-deco front with gold lines, a marquee, posters and a red carpet. */
    private static void cinema(GuiGraphics g, int x0) {
        int c = 0xFF5A5A92, trim = 0xFFFFD060, top = 44;
        wallBody(g, x0, top, 86, c);
        r(g, x0 + 4, top - 8, 78, 8, dk(c, 0.1F)); r(g, x0 + 12, top - 14, 62, 6, dk(c, 0.15F)); r(g, x0 + 26, top - 19, 34, 5, dk(c, 0.2F));  // stepped top
        r(g, x0 + 4, top - 8, 78, 1, trim); r(g, x0 + 12, top - 14, 62, 1, trim); r(g, x0 + 26, top - 19, 34, 1, trim);
        r(g, x0 + 42, top - 28, 2, 9, trim);                                                                                                     // a star on a pole
        r(g, x0 + 40, top - 26, 6, 2, trim); r(g, x0 + 41, top - 29, 4, 2, trim); r(g, x0 + 42, top - 30, 2, 1, 0xFFFFF0B0);
        for (int i = 0; i < 6; i++) r(g, x0 + 6 + i * 14, top + 4, 8, 22, dk(c, 0.12F));                                                         // pilasters
        for (int i = 0; i < 6; i++) { r(g, x0 + 6 + i * 14, top + 4, 8, 1, trim); r(g, x0 + 9 + i * 14, top + 5, 2, 20, lt(c, 0.15F)); }
        r(g, x0, 70, 86, 14, 0xFF2E2E58);                                                                                                        // the marquee board
        r(g, x0, 70, 86, 1, trim); r(g, x0, 83, 86, 1, trim);
        for (int i = 0; i < 17; i++) { r(g, x0 + 2 + i * 5, 68, 2, 2, 0xFFFFF0B0); r(g, x0 + 2 + i * 5, 84, 2, 2, 0xFFFFF0B0); GLOWS.add(new int[]{x0 + 3 + i * 5, 69, 3, 0x30FFE080}); }
        r(g, x0 + 8, 74, 70, 6, 0xFFFFF4D8);                                                                                                     // the letters are a row of pixels
        for (int i = 0; i < 12; i++) { r(g, x0 + 10 + i * 5, 75, 3, 4, i % 3 == 0 ? 0xFFE05A78 : i % 3 == 1 ? 0xFF5A6AD8 : 0xFF3A2A4A); }
        int[] pc = {0xFFFF8AB8, 0xFF8AD0FF, 0xFFFFD060};
        for (int i = 0; i < 3; i++) {
            int px = x0 + 6 + i * 14;
            r(g, px - 1, 88, 12, 18, trim); r(g, px, 89, 10, 16, pc[i]);                                                                         // a poster in a frame
            if (i == 0) { r(g, px + 3, 93, 4, 3, 0xFFE05A78); r(g, px + 2, 92, 2, 2, 0xFFE05A78); r(g, px + 6, 92, 2, 2, 0xFFE05A78); r(g, px + 4, 96, 2, 1, 0xFFE05A78); }
            if (i == 1) { ball(g, px + 5, 95, 3, 0xFFFFF4C0); ball(g, px + 6, 94, 3, pc[1]); }
            if (i == 2) { r(g, px + 4, 92, 2, 7, 0xFFFFFFFF); r(g, px + 2, 94, 6, 2, 0xFFFFFFFF); }
            r(g, px + 2, 101, 6, 1, 0x80FFFFFF); r(g, px + 3, 103, 4, 1, 0x80FFFFFF);
            LIT.add(new int[]{px, 89, 10, 16, -2});
        }
        r(g, x0 + 50, 88, 22, 22, trim); door(g, x0 + 51, 89, 10, 21, 0xFF8A2A4A); door(g, x0 + 61, 89, 10, 21, 0xFF8A2A4A);
        r(g, x0 + 76, 94, 8, 16, 0xFF3A3A6A); r(g, x0 + 77, 96, 6, 5, 0xFFFFE8B0); r(g, x0 + 75, 93, 10, 2, trim);                                // the ticket booth
        r(g, x0 + 48, 110, 26, 2, 0xFFC8284A); r(g, x0 + 46, 112, 30, 3, 0xFFC8284A); r(g, x0 + 46, 112, 30, 1, 0xFFE85A7A);                         // the red carpet
        sign(g, x0 + 20, 20, 4, 0xFFFFE9B8);
        r(g, x0 + 28, 18, 30, 8, 0xFF2E2E58); r(g, x0 + 28, 18, 30, 1, trim);
        GLOWS.add(new int[]{x0 + 43, 78, 30, 0x18FFE090});
    }

    /** The flower shop: pink walls with a glass house at the side, hanging baskets, buckets of flowers. */
    private static void florist(GuiGraphics g, int x0) {
        int c = 0xFFF8C4D6, trim = 0xFFD8708F, top = 62;
        wallBody(g, x0, top, 70, c);
        roofTop(g, x0, top, 70, c);
        r(g, x0 + 4, top - 8, 3, 5, 0xFFD8708F); r(g, x0 + 4, top - 9, 3, 1, 0xFFFFB8CC);                                                         // a chimney
        win(g, x0 + 8, top + 8, 11, 13, trim, c, true); win(g, x0 + 28, top + 8, 11, 13, trim, c, true);
        for (int i = 0; i < 3; i++) { ball(g, x0 + 10 + i * 4, top + 26, 2, 0xFF6CC68C); r(g, x0 + 10 + i * 4, top + 24, 1, 1, 0xFFFF7AA8); }    // hanging baskets
        r(g, x0 + 46, 66, 22, 44, 0x70D8F4FF);                                                                                                   // the glass house
        r(g, x0 + 46, 66, 22, 1, 0xFFFFFFFF); r(g, x0 + 46, 66, 1, 44, 0xFFFFFFFF); r(g, x0 + 67, 66, 1, 44, 0xFFFFFFFF); r(g, x0 + 57, 66, 1, 44, 0xA0FFFFFF);
        for (int i = 0; i < 3; i++) { r(g, x0 + 47, 78 + i * 10, 20, 1, 0x80FFFFFF); }
        for (int i = 0; i < 6; i++) { ball(g, x0 + 50 + (i % 3) * 7, 90 + (i / 3) * 10, 3, 0xFF4AAA5A); ball(g, x0 + 50 + (i % 3) * 7, 89 + (i / 3) * 10, 2, i % 2 == 0 ? 0xFFFF7AA8 : 0xFFFFE066); }
        r(g, x0 + 46, 66, 22, 3, 0xFFFFFFFF); LIT.add(new int[]{x0 + 47, 70, 20, 38, -2});
        shopWindow(g, x0 + 5, 90, 24, 18, 0xFFC8506F, 0xFFFFF0F4);
        for (int i = 0; i < 4; i++) { r(g, x0 + 8 + i * 5, 98, 1, 8, 0xFF4AAA5A); ball(g, x0 + 8 + i * 5, 98, 2, i % 2 == 0 ? 0xFFFF6A9A : 0xFFFFC040); }
        door(g, x0 + 33, 90, 10, 20, 0xFFE0709A);
        awning(g, x0 + 2, 82, 44, 0xFFFF7AA8, 0xFFFFFFFF);
        sign(g, x0 + 38, 62, 3, 0xFFFFE9F0);
    }

    /** The arcade: a purple front with teal bands, screens in the windows, a big neon sign. */
    private static void arcade(GuiGraphics g, int x0) {
        int c = 0xFF7A68B8, trim = 0xFF58E0D0, top = 40;
        wallBody(g, x0, top, 96, c);
        roofTop(g, x0, top, 96, c);
        r(g, x0, top, 96, 3, trim);
        for (int i = 0; i < 8; i++) { r(g, x0 + 6 + i * 11, top + 8, 8, 6, i % 2 == 0 ? 0xFF58E0D0 : 0xFFFF8AD0); r(g, x0 + 6 + i * 11, top + 8, 8, 1, 0x80FFFFFF); }
        for (int row = 0; row < 2; row++) for (int col = 0; col < 4; col++) win(g, x0 + 8 + col * 22, top + 20 + row * 14, 12, 8, 0xFF3A2E78, c, true);
        r(g, x0 + 4, 79, 88, 6, 0xFF2E2458); r(g, x0 + 4, 79, 88, 1, trim);                                                                       // the neon board
        for (int i = 0; i < 12; i++) r(g, x0 + 8 + i * 7, 81, 4, 2, i % 3 == 0 ? 0xFFFF8AD0 : i % 3 == 1 ? 0xFF58E0D0 : 0xFFFFE066);
        GLOWS.add(new int[]{x0 + 48, 82, 44, 0x20FF7AD0});
        for (int i = 0; i < 3; i++) {                                                                                                            // game cabinets seen through the window
            int px = x0 + 8 + i * 22;
            shopWindow(g, px, 90, 18, 19, 0xFF3A2E78, 0xFF2E2458);
            r(g, px + 3, 94, 12, 8, 0xFF58E0D0); r(g, px + 4, 95, 10, 6, 0xFF1A1440);
            r(g, px + 5, 97 + i % 2, 3, 3, 0xFFFFE066); r(g, px + 10, 96, 2, 2, 0xFFFF5A7A); r(g, px + 3, 103, 12, 2, 0xFF6A58B8);
            r(g, px + 5, 106, 2, 2, 0xFFFF5A7A); r(g, px + 11, 106, 2, 2, 0xFF58E0D0);
        }
        door(g, x0 + 74, 90, 12, 20, 0xFF3A2E78);
        awning(g, x0 + 4, 84, 66, 0xFF58E0D0, 0xFFB8A8F0);
        sign(g, x0 + 90, 34, 5, 0xFFE8E0FF);
        r(g, x0 + 38, top - 12, 22, 9, 0xFF2E2458); r(g, x0 + 38, top - 12, 22, 1, trim);                                                         // a rooftop board
        for (int i = 0; i < 5; i++) r(g, x0 + 41 + i * 4, top - 9, 2, 4, i % 2 == 0 ? 0xFFFF8AD0 : 0xFF58E0D0);
        GLOWS.add(new int[]{x0 + 49, top - 8, 22, 0x20FF7AD0});
    }

    /** The town hall: cream stone, columns, a pediment and a clock tower (the hands are drawn live). */
    private static void hall(GuiGraphics g, int x0) {
        int c = 0xFFF4E8D0, trim = 0xFFC8A870, top = 64;
        wallBody(g, x0 + 0, top, 100, c);
        roofTop(g, x0, top, 100, c);
        r(g, x0 - 2, top - 3, 104, 3, lt(trim, 0.4F));
        // the tower
        r(g, x0 + 36, 30, 28, 36, c); r(g, x0 + 36, 30, 2, 36, lt(c, 0.3F)); r(g, x0 + 60, 30, 4, 36, dk(c, 0.1F));
        r(g, x0 + 34, 28, 32, 3, trim); r(g, x0 + 38, 25, 24, 3, lt(trim, 0.2F));
        for (int i = 0; i < 12; i++) { int w2 = 24 - i * 2; r(g, x0 + 38 + i, 24 - i, w2, 1, i % 2 == 0 ? 0xFF6AA8C8 : 0xFF7AB8D8); }            // a pointed roof of blue tiles
        r(g, x0 + 49, 6 + 6, 2, 8, 0xFF6A5A7A); r(g, x0 + 51, 12, 5, 3, 0xFFFF7A9A); r(g, x0 + 51, 12, 5, 1, 0xFFFFA8BA);                        // a flag
        ball(g, x0 + 50, 44, 11, trim); ball(g, x0 + 50, 44, 10, 0xFFFFFFFF); ball(g, x0 + 50, 44, 9, 0xFFFFF8EC);                                   // the clock face
        for (int i = 0; i < 12; i++) { double a = i * Math.PI / 6; r(g, x0 + 50 + (int) Math.round(Math.sin(a) * 8), 44 - (int) Math.round(Math.cos(a) * 8), 1, 1, 0xFF8A6A9A); }
        r(g, x0 + 49, 43, 3, 3, 0xFFC8A870);
        win(g, x0 + 42, 55, 5, 7, trim, c, true); win(g, x0 + 53, 55, 5, 7, trim, c, true);
        // the front: a pediment on columns
        for (int i = 0; i < 12; i++) { int w2 = 10 + i * 6; r(g, x0 + 50 - w2 / 2, 65 + i, w2, 1, i % 4 == 3 ? trim : i % 2 == 0 ? 0xFFFFF4E0 : 0xFFF8EAD2); }     // a pediment, the point up
        r(g, x0 + 16, 76, 68, 1, trim);
        ball(g, x0 + 50, 71, 3, 0xFFFFC8D8); r(g, x0 + 49, 69, 2, 4, 0xFFFF7A9A);                                                                   // a heart emblem
        for (int i = 0; i < 5; i++) {
            int px = x0 + 20 + i * 14;
            r(g, px, 82, 6, 28, 0xFFFFF8EC); r(g, px, 82, 2, 28, 0xFFFFFFFF); r(g, px + 4, 82, 2, 28, 0xFFE0D2B8);
            r(g, px - 1, 80, 8, 3, trim); r(g, px - 1, 108, 8, 2, trim);
        }
        r(g, x0 + 16, 77, 68, 3, lt(trim, 0.4F)); r(g, x0 + 16, 79, 68, 1, dk(trim, 0.1F));
        r(g, x0 + 24, 83, 10, 27, 0xFFE8D4B8); r(g, x0 + 66, 83, 10, 27, 0xFFE8D4B8); door(g, x0 + 44, 88, 12, 22, 0xFF9A5A8A);
        win(g, x0 + 26, 90, 6, 9, trim, 0xFFE8D4B8, true); win(g, x0 + 68, 90, 6, 9, trim, 0xFFE8D4B8, true);
        r(g, x0 + 14, 110, 72, 2, 0xFFE8DCC8); r(g, x0 + 10, 111, 80, 1, 0xFFDCCFB8);                                                                        // the steps
        plantBox(g, x0 + 2, 100, 12, 0xFFFF7AA8, 0xFFFFE066); plantBox(g, x0 + 86, 100, 12, 0xFFFFFFFF, 0xFFFF9AC8);
        GLOWS.add(new int[]{x0 + 50, 44, 16, 0x28FFE8A0});
    }

    /** The corner boutique: a sky-blue front, dresses in the window, an awning with a scalloped edge. */
    private static void boutique(GuiGraphics g, int x0) {
        int c = 0xFFC0DCF4, trim = 0xFF6A9AD0, top = 54;
        wallBody(g, x0, top, 60, c);
        roofTop(g, x0, top, 60, c);
        for (int col = 0; col < 2; col++) win(g, x0 + 8 + col * 28, top + 6, 12, 14, trim, c, true);
        plantBox(g, x0 + 6, top + 22, 16, 0xFFFF9AC8, 0xFFFFFFFF); plantBox(g, x0 + 36, top + 22, 16, 0xFFFFE066, 0xFFFF7AA8);
        shopWindow(g, x0 + 5, 90, 30, 19, 0xFF4A7AB0, 0xFFF4FAFF);
        int[] dress = {0xFFFF7AA8, 0xFF8A9AE8, 0xFFFFC040};
        for (int i = 0; i < 3; i++) {
            int px = x0 + 9 + i * 9;
            r(g, px + 2, 94, 2, 2, 0xFFF0D8C8); r(g, px + 1, 96, 4, 3, dress[i]); r(g, px, 99, 6, 5, dress[i]); r(g, px - 1, 104, 8, 2, dress[i]); r(g, px + 2, 106, 2, 3, 0xFF8A7A9A);
        }
        door(g, x0 + 40, 90, 11, 20, 0xFF4A7AB0);
        awning(g, x0 + 2, 82, 50, 0xFF7AA8E0, 0xFFFFE0F0);
        sign(g, x0 + 54, 88, 7, 0xFFE8F4FF);
    }

    // =====================================================================================================
    //  THE SQUARE: a fountain, benches, cherry trees (drawn after the pavement so they stand in front of the buildings)
    // =====================================================================================================
    /** The gap between the bakery and the cinema: trees and a low wall with a railing behind the fountain. */
    private static void square(GuiGraphics g, int x0) {
        int w = 116;
        r(g, x0, 98, w, 14, 0xFFCDB8A0); r(g, x0, 98, w, 2, 0xFFE4D2BC);                                                                          // a low brick wall
        for (int y = 100; y < BASE; y += 4) for (int x = x0 + ((y / 4) % 2) * 5; x < x0 + w; x += 10) r(g, x, y, 1, 4, 0x20603A20);
        for (int y = 100; y < BASE; y += 4) r(g, x0, y, w, 1, 0x18603A20);
        for (int x = x0 + 2; x < x0 + w; x += 7) { r(g, x, 88, 1, 10, 0xFF4A4A6A); r(g, x - 1, 87, 3, 1, 0xFF4A4A6A); }                              // the railing
        r(g, x0, 90, w, 1, 0xFF4A4A6A); r(g, x0, 95, w, 1, 0xFF4A4A6A);
        // trees behind the wall
        int[] tx = {x0 + 14, x0 + 44, x0 + 74, x0 + 102};
        int[] th = {58, 48, 54, 60};
        for (int i = 0; i < tx.length; i++) {
            r(g, tx[i] - 1, th[i] + 14, 3, 98 - th[i] - 14, 0xFF8A6248);
            int leaf = i % 2 == 0 ? 0xFF6CC68C : 0xFF86D8A0;
            ball(g, tx[i], th[i] + 8, 11, dk(leaf, 0.12F)); ball(g, tx[i] - 6, th[i] + 12, 8, leaf); ball(g, tx[i] + 6, th[i] + 13, 8, leaf); ball(g, tx[i], th[i] + 5, 9, lt(leaf, 0.12F));
            r(g, tx[i] - 6, th[i] + 2, 3, 2, lt(leaf, 0.4F));
        }
        for (int x = x0 + 4; x < x0 + w - 4; x += 12) { ball(g, x, 95, 3, 0xFF4AAA5A); r(g, x - 1, 93, 2, 2, (x / 12) % 2 == 0 ? 0xFFFF7AA8 : 0xFFFFE066); }   // a hedge with flowers on the wall
    }

    /** The fountain: a round stone basin, a second smaller bowl and a column. The water that moves is drawn live. */
    private static void fountain(GuiGraphics g, int cx) {
        int b = 124;
        oval(g, cx, b, 34, 8, 0x28000000);
        oval(g, cx, b - 3, 32, 8, 0xFFE8DCEC); oval(g, cx, b - 5, 31, 7, 0xFFFFFFFF);
        oval(g, cx, b - 4, 28, 6, 0xFF7AD0F0); oval(g, cx, b - 5, 24, 5, 0xFF9CE0FA); oval(g, cx, b - 5, 14, 3, 0xFFB8EEFF);
        r(g, cx - 3, b - 24, 6, 20, 0xFFE8DCEC); r(g, cx - 3, b - 24, 2, 20, 0xFFFFFFFF); r(g, cx + 1, b - 24, 2, 20, 0xFFC8B8D8);
        oval(g, cx, b - 24, 14, 4, 0xFFE8DCEC); oval(g, cx, b - 25, 13, 3, 0xFFFFFFFF); oval(g, cx, b - 25, 10, 2, 0xFF9CE0FA);
        r(g, cx - 2, b - 34, 4, 10, 0xFFE8DCEC); ball(g, cx, b - 36, 3, 0xFFFFFFFF); ball(g, cx, b - 37, 2, 0xFFFFB8D0);
    }

    // ---------- things on the pavement ----------
    static void lamp(GuiGraphics g, int x) {
        r(g, x - 3, 124, 7, 3, 0xFF4A4468); r(g, x - 2, 122, 5, 2, 0xFF5A5478);
        r(g, x, 82, 2, 41, 0xFF4A4468); r(g, x, 82, 1, 41, 0xFF6A6488);
        r(g, x - 1, 80, 4, 3, 0xFF4A4468);
        r(g, x - 3, 70, 8, 10, 0xFF4A4468); r(g, x - 2, 71, 6, 8, 0xFFFFF4C8); r(g, x - 2, 71, 2, 8, 0xFFFFFFFF);
        r(g, x - 4, 68, 10, 2, 0xFF4A4468); r(g, x - 1, 66, 4, 2, 0xFF4A4468);
        GLOWS.add(new int[]{x + 1, 75, 20, 0x30FFE8A0});
        LIT.add(new int[]{x - 2, 71, 6, 8, -1});
    }

    private static void tree(GuiGraphics g, int cx, int leaf) {
        r(g, cx - 2, 100, 4, 24, 0xFF8A6248); r(g, cx - 2, 100, 1, 24, 0xFFB08A6A);
        r(g, cx - 5, 123, 10, 3, 0xFF6A5A7A);                                                                                                     // a grate
        ball(g, cx, 82, 17, dk(leaf, 0.14F)); ball(g, cx - 9, 90, 11, leaf); ball(g, cx + 9, 90, 11, leaf); ball(g, cx, 78, 14, lt(leaf, 0.08F));
        ball(g, cx - 4, 72, 7, lt(leaf, 0.22F));
        for (int i = 0; i < 12; i++) { int a = hash(cx * 13 + i); r(g, cx - 14 + a % 28, 70 + (a >> 5) % 28, 2, 1, lt(leaf, 0.5F)); }
        for (int i = 0; i < 4; i++) r(g, cx - 8 + i * 5, 98, 1, 1, 0xFF8A6248);
    }

    private static void bench(GuiGraphics g, int cx) {
        r(g, cx - 11, 116, 22, 3, 0xFFC8884A); r(g, cx - 11, 116, 22, 1, 0xFFE8A86A);
        r(g, cx - 11, 110, 22, 2, 0xFFC8884A); r(g, cx - 11, 113, 22, 2, 0xFFB8783A);
        r(g, cx - 10, 119, 2, 6, 0xFF4A4468); r(g, cx + 8, 119, 2, 6, 0xFF4A4468);
        r(g, cx - 11, 109, 2, 8, 0xFF4A4468); r(g, cx + 9, 109, 2, 8, 0xFF4A4468);
        r(g, cx - 12, 125, 24, 2, 0x20000000);
    }

    /** A café table with a parasol and two chairs. */
    private static void terrace(GuiGraphics g, int cx) {
        r(g, cx - 10, 125, 20, 2, 0x20000000);
        r(g, cx - 1, 108, 2, 17, 0xFF6A5A7A); r(g, cx - 5, 124, 10, 2, 0xFF6A5A7A);                                                              // a table
        r(g, cx - 8, 106, 16, 3, 0xFFFFFFFF); r(g, cx - 8, 106, 16, 1, 0xFFFFE9F0); r(g, cx - 8, 108, 16, 1, 0xFFC8B8D8);
        r(g, cx - 3, 104, 3, 2, 0xFFFFFFFF); r(g, cx - 3, 103, 3, 1, 0xFF8A5A3A); r(g, cx + 3, 104, 3, 2, 0xFFFFD0E0);                              // a cup and a plate
        for (int s = -1; s <= 1; s += 2) {                                                                                                      // two chairs
            int x = cx + s * 12;
            r(g, x - 3, 114, 7, 2, 0xFFE05A78); r(g, x - 3 + (s > 0 ? 5 : 0), 106, 2, 9, 0xFFE05A78); r(g, x - 3, 116, 1, 9, 0xFF6A5A7A); r(g, x + 3, 116, 1, 9, 0xFF6A5A7A);
        }
    }

    private static void flowerStands(GuiGraphics g, int cx) {
        r(g, cx - 9, 125, 18, 2, 0x20000000);
        r(g, cx - 8, 112, 16, 12, 0xFFD89A5A); r(g, cx - 8, 112, 16, 1, 0xFFF0B87A); r(g, cx - 8, 118, 16, 1, 0xFFB5703A);
        for (int i = 0; i < 5; i++) { int c = i % 3 == 0 ? 0xFFFF6A9A : i % 3 == 1 ? 0xFFFFC040 : 0xFFFFFFFF; r(g, cx - 7 + i * 3, 106 - (i % 2) * 2, 1, 7, 0xFF4AAA5A); ball(g, cx - 7 + i * 3, 105 - (i % 2) * 2, 2, c); }
        r(g, cx - 9, 123, 2, 4, 0xFF6A5A7A); r(g, cx + 7, 123, 2, 4, 0xFF6A5A7A);
    }

    private static void iceCream(GuiGraphics g, int cx) {
        r(g, cx - 12, 125, 24, 2, 0x20000000);
        r(g, cx - 10, 112, 20, 11, 0xFFFFE0EC); r(g, cx - 10, 112, 20, 2, 0xFFFF9AC8); r(g, cx - 10, 121, 20, 2, 0xFFE0A8C0);                         // the cart
        for (int i = 0; i < 5; i++) { r(g, cx - 9 + i * 4, 112, 2, 1, 0xFFFFFFFF); }
        ball(g, cx - 7, 126, 2, 0xFF4A4468); ball(g, cx + 7, 126, 2, 0xFF4A4468);
        r(g, cx - 1, 96, 2, 16, 0xFF6A5A7A);                                                                                                     // an umbrella
        for (int i = 0; i < 7; i++) { int w2 = 28 - i * 4; r(g, cx - w2 / 2, 90 + i, w2, 1, i % 2 == 0 ? 0xFFFF7AA8 : 0xFFFFFFFF); }
        r(g, cx - 5, 109, 3, 3, 0xFFFFC8E0); r(g, cx - 4, 106, 1, 3, 0xFFE8C080); ball(g, cx - 4, 105, 2, 0xFFFFC8E0);                                // the cones on the counter
        r(g, cx + 3, 109, 3, 3, 0xFFC8F0D8); r(g, cx + 4, 106, 1, 3, 0xFFE8C080); ball(g, cx + 4, 105, 2, 0xFFA8E8C8);
    }

    /** The tram stop: a glass shelter, a bench, a pole with the sign of the line. */
    private static void busStop(GuiGraphics g, int cx) {
        r(g, cx - 18, 125, 36, 2, 0x20000000);
        r(g, cx - 18, 94, 36, 3, 0xFF5A8AC8); r(g, cx - 18, 94, 36, 1, 0xFF8AB4E8);
        r(g, cx - 17, 97, 2, 28, 0xFF5A8AC8); r(g, cx + 15, 97, 2, 28, 0xFF5A8AC8);
        r(g, cx - 15, 97, 30, 18, 0x40D8F4FF); r(g, cx - 14, 99, 2, 6, 0x60FFFFFF);
        r(g, cx - 12, 113, 24, 3, 0xFFC8884A); r(g, cx - 12, 116, 2, 8, 0xFF4A4468); r(g, cx + 10, 116, 2, 8, 0xFF4A4468);
        r(g, cx + 20, 80, 2, 46, 0xFF5A8AC8); ball(g, cx + 21, 78, 6, 0xFF5A8AC8); ball(g, cx + 21, 78, 5, 0xFFFFE066);
        r(g, cx + 18, 77, 7, 2, 0xFF3A2A4A); r(g, cx + 20, 75, 3, 6, 0xFF3A2A4A);
    }

    /** The first tram stop, at the west end. */
    private static void stop(GuiGraphics g, int cx) { r(g, cx + 12, 124, 20, 2, 0x10000000); r(g, cx + 18, 92, 2, 34, 0xFF5A8AC8); ball(g, cx + 19, 90, 6, 0xFF5A8AC8); ball(g, cx + 19, 90, 5, 0xFFFFE066); r(g, cx + 16, 89, 7, 2, 0xFF3A2A4A); r(g, cx + 18, 87, 3, 6, 0xFF3A2A4A); }

    /** Bunting (little flags) on a string from (x0, y0) to (x1, y1) with a sag. */
    private static void bunting(GuiGraphics g, int x0, int y0, int x1, int y1, int sag, int c1, int c2) {
        int n = x1 - x0;
        int prev = y0;
        for (int i = 0; i <= n; i++) {
            double t = i / (double) n;
            int y = (int) Math.round(y0 + (y1 - y0) * t + Math.sin(t * Math.PI) * sag);
            r(g, x0 + i, y, 1, 1, 0xFF8A7AA8);
            if (i % 9 == 4) {
                int c = (i / 9) % 2 == 0 ? c1 : c2;
                r(g, x0 + i - 2, y + 1, 5, 2, c); r(g, x0 + i - 1, y + 3, 3, 2, c); r(g, x0 + i, y + 5, 1, 1, c);
                r(g, x0 + i - 2, y + 1, 5, 1, lt(c, 0.35F));
            }
            prev = y;
        }
    }

    // =====================================================================================================
    //  THE LIGHTS (dusk and night): lit windows, glows of the lamps and signs. Drawn over the tinted street, never tinted
    // =====================================================================================================
    static void lights(GuiGraphics g, int phase) {
        int warm = phase == 2 ? 0xFFFFE6A0 : 0xFFFFEDB8;
        for (int[] w : LIT) {
            int x = w[0], y = w[1], ww = w[2], hh = w[3];
            if (w[4] == -2) { r(g, x, y, ww, hh, 0x66FFE8A8); r(g, x, y, ww, 2, 0x88FFF4C8); continue; }                               // a shop window: the goods stay visible
            if (w[4] == -1) { r(g, x, y, ww, hh, 0xFFFFF8D8); r(g, x + 1, y + 1, ww - 2, hh - 2, 0xFFFFFFFF); continue; }          // a lamp
            if (w[4] != -1 && hash(x * 31 + y * 17) % 10 >= 7 && ww < 16) continue;                                                     // a few small windows stay dark
            r(g, x - 1, y - 1, ww + 2, hh + 2, dk(w[4], 0.25F));
            r(g, x, y, ww, hh, warm);
            r(g, x, y + hh / 2 + 1, ww, hh - hh / 2 - 1, lt(warm, 0.0F) - 0x00101810);
            r(g, x + 1, y + 1, Math.max(1, ww / 3), Math.max(1, hh / 3), 0xFFFFFFF0);
            if (ww >= 6) r(g, x + ww / 2, y, 1, hh, dk(w[4], 0.3F));
            if (hh >= 8) r(g, x, y + hh / 2, ww, 1, dk(w[4], 0.3F));
        }
        for (int[] gl : GLOWS) { ball(g, gl[0], gl[1], gl[2], gl[3]); ball(g, gl[0], gl[1], gl[2] * 2 / 3, gl[3]); }
        // the glow on the pavement under every lamp
        for (int x : LAMPS) oval(g, x + 1, 125, 22, 5, 0x28FFE8A0);
    }
}
