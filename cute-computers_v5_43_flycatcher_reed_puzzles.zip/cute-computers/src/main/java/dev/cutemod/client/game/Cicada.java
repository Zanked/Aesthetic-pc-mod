package dev.cutemod.client.game;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * When the Cicadas Fall Silent: a psychological-horror visual novel in the spirit of the summer-village mysteries. A new boy
 * comes to the village of Semizawa, three days before the festival of the Silent Cicadas. The story is a small program
 * ({@link CicadaScript}, made by tools/make_cicada.py) that this class plays: lines with a typewriter, choices, backgrounds and
 * four characters with six faces each ({@link CicadaArt}).
 *
 * <p>Sanity (0..5) falls when the player makes frightened or reckless choices; the lower it is, the more the world is wrong:
 * the picture reddens, faces go blank, letters in the text break and something watches from the corners. Six endings.
 */
public class Cicada extends MiniGame {
    // run modes
    private static final int M_TITLE = 0, M_RUN = 1, M_SAY = 2, M_CHOICE = 3, M_CARD = 4, M_WAIT = 5, M_END = 6;
    // speakers
    private static final int S_NARR = 5, S_THINK = 6;
    private static final String[] WHO = {"yuna", "asuka", "hikari", "silent", "me"};
    private static final int[] WHO_COLOR = {0xFFFFA860, 0xFF7AA8FF, 0xFFD0B8FF, 0xFFFF5060, 0xFFFFFFFF};
    private static final int[] END_BONUS = {100, 10, 30, 10, 40, 15};
    private static final int CLUES = 2 | 4 | 16;
    private static final int TEXT_W = 196, LINES = 3;
    private static final int[] SLOT_X = {104, 220, 336};

    private static final String[][] OPS = parse();

    private int mode, pc, t;
    private int sanity, flags, ending;
    // the background
    private int bg, prevBg, fadeT, fadeLen;
    private boolean hush, fig;
    // the people on the stage: [slot] = {character, face}
    private final int[][] slots = new int[3][];
    private final int[] slotT = new int[3];
    // the line being said
    private int speaker;
    private List<String> pages = new ArrayList<>();
    private int page;
    private float typed;
    // a choice
    private int nOpt;
    private final String[] optText = new String[3];
    private final int[] optTarget = new int[3], optSan = new int[3], optFlag = new int[3];
    // cards, waits, effects
    private String cardText = "";
    private int cardT, waitT, shakeT, flashT, glitchT, beatT, endT;
    private int sx, sy;

    private static String[][] parse() {
        String[][] r = new String[CicadaScript.OPS.length][];
        for (int i = 0; i < r.length; i++) r[i] = CicadaScript.OPS[i].split("\\|");
        return r;
    }

    // ================================================================== life cycle
    @Override
    public void reset() {
        score = 0; over = false;
        mode = M_TITLE; pc = 0; t = 0; sanity = 5; flags = 0; ending = 0;
        bg = CicadaArt.BG_ROAD; prevBg = bg; fadeT = 0; fadeLen = 0; hush = false; fig = false;
        for (int i = 0; i < 3; i++) { slots[i] = null; slotT[i] = 0; }
        pages = new ArrayList<>(); page = 0; typed = 0;
        nOpt = 0; cardT = 0; waitT = 0; shakeT = 0; flashT = 0; glitchT = 0; beatT = 0; endT = 0;
    }

    @Override
    public String hintKey() { return "cutemod.hint.cicada"; }

    @Override
    public Component status() {
        int clues = Integer.bitCount(flags & CLUES);
        return Component.translatable("cutemod.cic.status", sanity, clues);
    }

    @Override
    public boolean isWin() { return over && ending == 0; }

    @Override
    public Component endTitle() { return Component.translatable("cutemod.cic.end." + ending); }

    private static String str(String key) { return Component.translatable(key).getString(); }

    private static String text(int idx) { return str("cutemod.cic.t." + idx); }

    // ================================================================== the story machine
    /** Runs ops until one of them has to wait for the player. */
    private void run() {
        int guard = 0;
        while (mode == M_RUN && pc < OPS.length && guard++ < 400) {
            String[] o = OPS[pc++];
            switch (o[0]) {
                case "bg" -> {
                    prevBg = bg; bg = Integer.parseInt(o[1]);
                    fadeLen = Integer.parseInt(o[2]); fadeT = fadeLen;
                }
                case "show" -> {
                    int s = Integer.parseInt(o[3]);
                    slots[s] = new int[]{Integer.parseInt(o[1]), Integer.parseInt(o[2])};
                    slotT[s] = 0;
                }
                case "expr" -> {
                    int s = Integer.parseInt(o[1]);
                    if (slots[s] != null) slots[s][1] = Integer.parseInt(o[2]);
                }
                case "hide" -> slots[Integer.parseInt(o[1])] = null;
                case "clear" -> { slots[0] = null; slots[1] = null; slots[2] = null; }
                case "say" -> { startSay(Integer.parseInt(o[1]), text(Integer.parseInt(o[2]))); }
                case "choice" -> startChoice(o);
                case "san" -> changeSanity(Integer.parseInt(o[1]));
                case "flag" -> flags |= Integer.parseInt(o[1]);
                case "ifflag" -> { if ((flags & Integer.parseInt(o[1])) != 0) pc = Integer.parseInt(o[2]); }
                case "ifsan" -> { if (sanity <= Integer.parseInt(o[1])) pc = Integer.parseInt(o[2]); }
                case "jump" -> pc = Integer.parseInt(o[1]);
                case "sfx" -> sfx(o[1]);
                case "shake" -> shakeT = Integer.parseInt(o[1]);
                case "flash" -> flashT = Integer.parseInt(o[1]);
                case "glitch" -> glitchT = Integer.parseInt(o[1]);
                case "hush" -> hush = !"0".equals(o[1]);
                case "fig" -> fig = !"0".equals(o[1]);
                case "title" -> { cardText = text(Integer.parseInt(o[1])); cardT = 150; mode = M_CARD; }
                case "wait" -> { waitT = Integer.parseInt(o[1]); mode = M_WAIT; }
                case "end" -> finish(Integer.parseInt(o[1]));
                default -> { }
            }
        }
    }

    private void startSay(int who, String s) {
        speaker = who;
        List<String> lines = wrap(s, TEXT_W);
        pages = new ArrayList<>();
        for (int i = 0; i < lines.size(); i += LINES) {
            StringBuilder sb = new StringBuilder();
            for (int j = i; j < Math.min(lines.size(), i + LINES); j++) { if (j > i) sb.append('\n'); sb.append(lines.get(j)); }
            pages.add(sb.toString());
        }
        if (pages.isEmpty()) pages.add("");
        page = 0; typed = 0; mode = M_SAY;
    }

    private static List<String> wrap(String s, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : s.split(" ")) {
            String cand = cur.length() == 0 ? w : cur + " " + w;
            if (cur.length() > 0 && tw(cand) > maxW) { out.add(cur.toString()); cur = new StringBuilder(w); }
            else cur = new StringBuilder(cand);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private void startChoice(String[] o) {
        nOpt = Integer.parseInt(o[1]);
        for (int i = 0; i < nOpt; i++) {
            int b = 2 + i * 4;
            optText[i] = text(Integer.parseInt(o[b]));
            optTarget[i] = Integer.parseInt(o[b + 1]);
            optSan[i] = Integer.parseInt(o[b + 2]);
            optFlag[i] = Integer.parseInt(o[b + 3]);
        }
        mode = M_CHOICE;
    }

    private void choose(int i) {
        if (mode != M_CHOICE || i < 0 || i >= nOpt) return;
        beep();
        changeSanity(optSan[i]);
        flags |= optFlag[i];
        pc = optTarget[i];
        mode = M_RUN;
        run();
    }

    private void changeSanity(int d) {
        int old = sanity;
        sanity = Math.max(0, Math.min(5, sanity + d));
        if (sanity < old) {
            glitchT = Math.max(glitchT, 30); shakeT = Math.max(shakeT, 12);
            sound(SoundEvents.ENDERMAN_STARE, 0.5F, 0.45F);
            beatT = 8;
        } else if (sanity > old) {
            sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.9F, 0.6F);
        }
    }

    private void sfx(String kind) {
        switch (kind) {
            case "hush" -> { sound(SoundEvents.ENDERMAN_STARE, 0.45F, 0.5F); beatT = 6; }
            case "thud" -> sound(SoundEvents.NOTE_BLOCK_BASEDRUM, 0.6F, 0.8F);
            case "whisper" -> { sound(SoundEvents.PHANTOM_AMBIENT, 0.5F, 0.45F); sound(SoundEvents.ENDERMAN_AMBIENT, 0.5F, 0.3F); }
            case "bell" -> { sound(SoundEvents.BELL_BLOCK, 0.5F, 1.0F); sound(SoundEvents.BELL_BLOCK, 0.35F, 0.6F); }
            case "dawn" -> { sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.1F, 0.8F); sound(SoundEvents.PLAYER_LEVELUP, 1.0F, 0.4F); }
            case "door" -> sound(SoundEvents.WOODEN_DOOR_CLOSE, 0.7F, 0.7F);
            case "beat" -> beatT = 6;
            default -> { }
        }
    }

    private void finish(int id) {
        ending = id;
        int clues = Integer.bitCount(flags & CLUES);
        score = clues * 15 + sanity * 8 + END_BONUS[Math.max(0, Math.min(END_BONUS.length - 1, id))];
        mode = M_END; endT = 0;
        if (id == 0) sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.2F, 0.8F);
        else growl(id == 3 ? G_SCREAM : G_DEEP);
    }

    // ================================================================== input
    private void advance() {
        switch (mode) {
            case M_TITLE -> { mode = M_RUN; pc = 0; beep(); run(); }
            case M_SAY -> {
                String pg = pages.get(page);
                if (typed < pg.length()) { typed = pg.length(); }
                else if (page + 1 < pages.size()) { page++; typed = 0; beep(); }
                else { mode = M_RUN; run(); }
            }
            case M_CARD -> { if (cardT < 110) { mode = M_RUN; run(); } }
            default -> { }
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        if (mode == M_CHOICE) {
            for (int i = 0; i < nOpt; i++) if (in(x, y, optX(), optY(i), optW(), 17)) { choose(i); return true; }
            return true;
        }
        advance();
        return true;
    }

    @Override
    public boolean key(int keyCode) {
        if (over) return false;
        if (mode == M_CHOICE) {
            if (keyCode >= 49 && keyCode <= 51) { choose(keyCode - 49); return true; }
            if (keyCode >= 321 && keyCode <= 323) { choose(keyCode - 321); return true; }
            return false;
        }
        if (keyCode == KEY_SPACE || keyCode == 257 || keyCode == 335) { advance(); return true; }
        return false;
    }

    // ================================================================== time
    @Override
    public void tick() {
        t++;
        if (shakeT > 0) {
            shakeT--;
            sx = rnd.nextInt(5) - 2; sy = rnd.nextInt(5) - 2;
        } else { sx = 0; sy = 0; }
        if (flashT > 0) flashT--;
        if (glitchT > 0) glitchT--;
        if (fadeT > 0) fadeT--;
        for (int i = 0; i < 3; i++) if (slotT[i] < 16) slotT[i]++;
        if (beatT > 0 && --beatT == 0) {                                   // a heartbeat: two soft drums
            sound(SoundEvents.NOTE_BLOCK_BASEDRUM, 0.45F, 0.7F);
            if (!hush || sanity <= 2) beatT = -10;
        } else if (beatT < 0 && ++beatT == 0) sound(SoundEvents.NOTE_BLOCK_BASEDRUM, 0.4F, 0.55F);
        if (mode != M_TITLE && sanity <= 1 && t % 90 == 0 && !over) beatT = 4;
        if (mode == M_SAY) {
            String pg = pages.get(page);
            if (typed < pg.length()) typed += 0.55F;
        }
        if (mode == M_CARD && cardT > 0) {
            cardT--;
            if (cardT == 0) { mode = M_RUN; run(); }
        }
        if (mode == M_WAIT && --waitT <= 0) { mode = M_RUN; run(); }
        if (mode == M_END) {
            endT++;
            if (endT >= 120) over = true;
        }
    }

    // ================================================================== drawing
    private int optX() { return 20; }

    private int optW() { return 180; }

    private int optY(int i) {
        int total = nOpt * 17 + (nOpt - 1) * 4;
        return 8 + (84 - total) / 2 + i * 21;
    }

    @Override
    public void render(GuiGraphics g) {
        int mood = Math.max(0, Math.min(4, 5 - sanity));
        // ---- the picture, in a design space of 440 x 280
        g.pose().pushPose();
        g.pose().translate(sx, sy, 0);
        g.pose().scale(0.5F, 0.5F, 1F);
        drawWorld(g, mood);
        if (glitchT > 0) CicadaArt.glitch(g, t, Math.min(100, glitchT * 2 + (5 - sanity) * 10));
        else if (sanity <= 2 && (t % 260) < 6) CicadaArt.glitch(g, t, 20 + (3 - sanity) * 20);
        if (sanity <= 2 && mode != M_TITLE) CicadaArt.watchers(g, t);
        g.pose().popPose();
        Gfx.vignette(g, W, H, 90 + mood * 28);
        if (mode == M_TITLE) { drawTitleScreen(g); return; }
        // ---- the interface
        drawSanity(g);
        if (mode == M_SAY) drawDialogue(g);
        else if (mode == M_CHOICE) drawChoices(g);
        else if (mode == M_CARD) drawCard(g);
        if (flashT > 0) g.fill(0, 0, W, H, Gfx.alpha(0xFFFFFFFF, Math.min(200, flashT * 14)));
        if (mode == M_END) {
            int a = Math.min(255, endT * 5);
            g.fill(0, 0, W, H, Gfx.alpha(0xFF000000, a));
            if (endT > 60) {
                String nm = str("cutemod.cic.end." + ending);
                int ta = Math.min(255, (endT - 60) * 8);
                ctext(g, nm, W / 2, H / 2 - 4, Gfx.alpha(ending == 0 ? 0xFFFFE8A0 : 0xFFE04050, ta));
            }
        }
    }

    private void drawWorld(GuiGraphics g, int mood) {
        if (fadeT > 0 && fadeLen > 0) {              // the old picture goes dark, then the new one comes up
            float k = fadeT / (float) fadeLen;
            if (k > 0.5F) {
                CicadaArt.background(g, prevBg, t, mood, hush, fig);
                g.fill(0, 0, CicadaArt.W, CicadaArt.H, Gfx.alpha(0xFF000000, Math.round((1 - k) * 2 * 255)));
            } else {
                CicadaArt.background(g, bg, t, mood, hush, fig);
                g.fill(0, 0, CicadaArt.W, CicadaArt.H, Gfx.alpha(0xFF000000, Math.round(k * 2 * 255)));
            }
        } else {
            CicadaArt.background(g, bg, t, mood, hush, fig);
        }
        if (mode == M_TITLE) {
            CicadaArt.character(g, CicadaArt.YUNA, CicadaArt.SMILE, 352, 112, t, false, 0);
            g.fill(0, 0, CicadaArt.W, CicadaArt.H, Gfx.alpha(0xFF000000, 60));
            return;
        }
        int order[] = {0, 2, 1};
        for (int s : order) {
            int[] c = slots[s];
            if (c == null) continue;
            float in = 1F - slotT[s] / 16F;
            int cx = SLOT_X[s] + Math.round((s == 0 ? -1 : s == 2 ? 1 : 0) * in * 40);
            int cy = 106 + Math.round(in * (s == 1 ? 40 : 0));
            boolean talking = mode == M_SAY && speaker == c[0] && typed < pages.get(page).length();
            boolean quiet = mode == M_SAY && speaker < 5 && speaker != c[0];
            int face = c[1];
            if (sanity <= 2 && c[0] != CicadaArt.SILENT && (t / 40 + c[0]) % (sanity <= 1 ? 4 : 8) == 0 && t % 40 < 8) face = CicadaArt.BLANK;
            CicadaArt.character(g, c[0], face, cx, cy + (quiet ? 8 : 0), t, talking, c[0]);
        }
    }

    private void drawTitleScreen(GuiGraphics g) {
        g.fill(0, 0, W, H, Gfx.alpha(0xFF000000, 40));
        g.fillGradient(0, 30, W, 74, Gfx.alpha(0xFF0A0410, 0), Gfx.alpha(0xFF0A0410, 190));
        g.fillGradient(0, 74, W, 100, Gfx.alpha(0xFF0A0410, 190), Gfx.alpha(0xFF0A0410, 0));
        String name = str("cutemod.game.cicada");
        g.pose().pushPose();
        g.pose().translate(W * 0.34F, 40, 0);
        g.pose().scale(1.5F, 1.5F, 1F);
        ctext(g, name, 1, 1, Gfx.alpha(0xFF000000, 200));
        ctext(g, name, 0, 0, 0xFFFFE0C0);
        g.pose().popPose();
        float pulse = 0.5F + 0.5F * (float) Math.sin(t * 0.08);
        ctext(g, str("cutemod.cic.begin"), (int) (W * 0.34F), 78, Gfx.alpha(0xFFE04050, 120 + (int) (120 * pulse)));
        if (t > 20) for (int i = 0; i < 5; i++) drawCicada(g, (int) (W * 0.34F) - 25 + i * 11, 100, true, t + i);
    }

    private void drawCard(GuiGraphics g) {
        int a = cardT > 130 ? (150 - cardT) * 12 : cardT < 30 ? cardT * 8 : 255;
        a = Math.max(0, Math.min(255, a));
        g.fillGradient(0, 40, W, 60, Gfx.alpha(0xFF000000, a * 0), Gfx.alpha(0xFF000000, a * 200 / 255));
        g.fill(0, 60, W, 82, Gfx.alpha(0xFF000000, a * 200 / 255));
        g.fillGradient(0, 82, W, 102, Gfx.alpha(0xFF000000, a * 200 / 255), Gfx.alpha(0xFF000000, 0));
        g.fill(W / 2 - 40, 63, W / 2 + 40, 64, Gfx.alpha(0xFFC8282E, a));
        g.fill(W / 2 - 40, 78, W / 2 + 40, 79, Gfx.alpha(0xFFC8282E, a));
        ctextW(g, cardText, W / 2, 66, W - 16, Gfx.alpha(0xFFFFE8D0, a));
    }

    private void drawSanity(GuiGraphics g) {
        for (int i = 0; i < 5; i++) {
            boolean alive = i < sanity;
            boolean flicker = alive && sanity <= 1 && (t / 5) % 3 == 0;
            drawCicada(g, 5 + i * 10, 5, alive && !flicker, t + i * 7);
        }
    }

    /** A tiny cicada (7 x 6): alive ones have bright wings, the others are grey. */
    private static void drawCicada(GuiGraphics g, int x, int y, boolean alive, int t) {
        if (alive) {
            int flap = (t / 4) % 2;
            g.fill(x, y + 1 + flap, x + 2, y + 4 + flap, Gfx.alpha(0xFFDDF0FF, 200));
            g.fill(x + 5, y + 1 + flap, x + 7, y + 4 + flap, Gfx.alpha(0xFFDDF0FF, 200));
            g.fill(x + 2, y + 1, x + 5, y + 6, 0xFF2A2420);
            g.fill(x + 2, y, x + 5, y + 1, 0xFF5AAE6A);
            g.fill(x + 3, y + 2, x + 4, y + 3, 0xFFFFB347);
        } else {
            g.fill(x + 2, y + 2, x + 5, y + 6, 0xFF4A4650);
            g.fill(x + 2, y + 1, x + 5, y + 2, 0xFF5A5660);
        }
    }

    private String corrupt(String s, int salt) {
        if (sanity > 2 && !(speaker == S_THINK && sanity <= 3)) return s;
        int rate = sanity <= 1 ? 9 : sanity == 2 ? 4 : 2;       // percent of the letters that break
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch != ' ' && ch != '\n' && Gfx.hash(i + salt * 31, t / 7) * 100F < rate) sb.append("#%?*/".charAt((i + t / 7) % 5));
            else sb.append(ch);
        }
        return sb.toString();
    }

    private void drawDialogue(GuiGraphics g) {
        int bx = 5, by = 98, bw = W - 10, bh = 39;
        int accent = speaker < 5 ? WHO_COLOR[speaker] : speaker == S_THINK ? 0xFF8AA0D0 : 0xFF8A7A9A;
        g.fillGradient(bx, by, bx + bw, by + bh, Gfx.alpha(0xFF160E24, 225), Gfx.alpha(0xFF0A0614, 238));
        Gfx.outline(g, bx, by, bw, bh, Gfx.alpha(accent, 190));
        g.fill(bx + 1, by + 1, bx + bw - 1, by + 2, Gfx.alpha(0xFFFFFFFF, 40));
        if (speaker < 5) {
            String nm = str("cutemod.cic.who." + WHO[speaker]);
            int nw = tw(nm) + 12;
            Gfx.rrect(g, bx + 6, by - 8, nw, 12, 3, Gfx.alpha(0xFF160E24, 240));
            Gfx.outline(g, bx + 6, by - 8, nw, 12, Gfx.alpha(accent, 220));
            text(g, nm, bx + 12, by - 6, accent);
        }
        String pg = pages.get(page);
        int shown = Math.min(pg.length(), (int) typed);
        String vis = corrupt(pg.substring(0, shown), page);
        int col = speaker == S_THINK ? 0xFFB8C8F0 : speaker == S_NARR ? 0xFFE6E0EE : 0xFFFFFFFF;
        if (sanity <= 1) col = Gfx.mix(col, 0xFFFF6070, 0.4F);
        String[] lines = vis.split("\n", -1);
        for (int i = 0; i < lines.length && i < LINES; i++) {
            int jx = sanity <= 1 && (t / 3 + i) % 11 == 0 ? 1 : 0;
            text(g, lines[i], bx + 7 + jx, by + 5 + i * 10, col);
        }
        if (shown >= pg.length() && (t / 20) % 2 == 0) {                 // "next"
            int ax = bx + bw - 12, ay = by + bh - 9;
            boolean last = page + 1 >= pages.size();
            g.fill(ax, ay, ax + 7, ay + 1, accent); g.fill(ax + 1, ay + 1, ax + 6, ay + 2, accent);
            g.fill(ax + 2, ay + 2, ax + 5, ay + 3, accent); g.fill(ax + 3, ay + 3, ax + 4, ay + 4, accent);
            if (!last) g.fill(ax - 4, ay, ax - 2, ay + 1, accent);
        }
    }

    private void drawChoices(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, Gfx.alpha(0xFF000000, 90), Gfx.alpha(0xFF000000, 170));
        for (int i = 0; i < nOpt; i++) {
            int x = optX(), y = optY(i), w = optW();
            boolean hover = in(mx, my, x, y, w, 17);
            int face = hover ? 0xFF3A1E3E : 0xFF1C1228;
            Gfx.shadow(g, x, y, w, 17, 3);
            Gfx.rrect(g, x, y, w, 17, 3, Gfx.alpha(hover ? 0xFFE04050 : 0xFF7A5A8A, 255));
            Gfx.rrect(g, x + 1, y + 1, w - 2, 15, 3, face);
            g.fill(x + 3, y + 2, x + w - 3, y + 3, Gfx.alpha(0xFFFFFFFF, hover ? 50 : 24));
            Gfx.rrect(g, x + 4, y + 3, 11, 11, 3, hover ? 0xFFE04050 : 0xFF5A4468);
            ctext(g, String.valueOf(i + 1), x + 9, y + 4, 0xFFFFFFFF);
            ctextW(g, optText[i], x + w / 2 + 6, y + 4, w - 28, hover ? 0xFFFFFFFF : 0xFFE0D8EC);
        }
    }
}
