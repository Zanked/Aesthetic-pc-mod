package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Pong: you (pink plate, mouse) against a slime. Every return scores, every slime miss gives a bonus. */
public class SlimePong extends MiniGame {
    private static final int PW = 5, PH = 28, MARGIN = 6, BR = 3;

    private double py, ay, bx, by, vx, vy, speed;
    private int lives, rally, serveTimer, ticks;
    private final java.util.ArrayDeque<double[]> trail = new java.util.ArrayDeque<>();   // where the ball was: a soft comet tail
    private int flashL, flashR;                                                           // paddle flash after a hit

    @Override
    public void reset() {
        score = 0; over = false; lives = 3; rally = 0; ticks = 0; trail.clear(); flashL = 0; flashR = 0;
        speed = 1.8;
        py = ay = H / 2.0;
        serve(1);
    }

    private void serve(int dir) {
        bx = W / 2.0; by = H / 2.0;
        speed = 1.8;
        vx = dir * speed;
        vy = (rnd.nextDouble() - 0.5) * 1.6;
        serveTimer = 45;
    }

    @Override
    public void tick() {
        ticks++;
        if (flashL > 0) flashL--;
        if (flashR > 0) flashR--;
        trail.addFirst(new double[]{bx, by});
        while (trail.size() > 9) trail.removeLast();
        double target = Math.max(PH / 2.0, Math.min(H - PH / 2.0, my));
        py += (target - py) * 0.4;
        if (serveTimer > 0) { serveTimer--; return; }

        // slime AI: limited speed, so steep fast balls get past it
        double aiSpeed = 1.1 + Math.min(rally, 10) * 0.06;
        double aim = vx > 0 ? by : H / 2.0;
        double d = aim - ay;
        ay += Math.max(-aiSpeed, Math.min(aiSpeed, d));
        ay = Math.max(PH / 2.0, Math.min(H - PH / 2.0, ay));

        for (int s = 0; s < 2; s++) {
            bx += vx / 2; by += vy / 2;
            if (by < BR) { by = BR; vy = Math.abs(vy); }
            if (by > H - BR) { by = H - BR; vy = -Math.abs(vy); }

            // player plate (left)
            if (vx < 0 && bx - BR <= MARGIN + PW && bx - BR >= MARGIN - 3
                    && Math.abs(by - py) <= PH / 2.0 + BR) {
                double rel = (by - py) / (PH / 2.0 + BR);
                speed = Math.min(3.6, speed + 0.12);
                double a = rel * 0.9;
                vx = speed * Math.cos(a);
                vy = speed * Math.sin(a);
                bx = MARGIN + PW + BR;
                score += 1; rally++; flashL = 8;
                pling(1.0F + Math.min(rally, 10) * 0.05F);
            }
            // slime plate (right)
            if (vx > 0 && bx + BR >= W - MARGIN - PW && bx + BR <= W - MARGIN + 3
                    && Math.abs(by - ay) <= PH / 2.0 + BR) {
                double rel = (by - ay) / (PH / 2.0 + BR);
                double a = rel * 0.9;
                vx = -speed * Math.cos(a);
                vy = speed * Math.sin(a);
                bx = W - MARGIN - PW - BR;
                flashR = 8;
                pling(0.8F);
            }
        }

        if (bx < -BR) {          // you missed
            lives--;
            beep();
            rally = 0;
            if (lives <= 0) over = true; else serve(1);
        } else if (bx > W + BR) { // the slime missed
            score += 10;
            pling(1.8F);
            serve(-1);
        }
    }

    @Override
    public void render(GuiGraphics g) {
        // a mossy arena with a glowing centre line and soft goal zones
        g.fillGradient(0, 0, W, H, 0xFF1B3A28, 0xFF2F6B45);
        for (int i = 0; i < 18; i++) rect(g, (int) (Gfx.hash(i, 16) * W), (int) (Gfx.hash(i, 17) * H), 3, 1, 0x1AFFFFFF);
        for (int i = 0; i < 14; i++) {                                  // goal zones: soft fades from the edges
            int a = 40 - i * 3;
            g.fill(i, 0, i + 1, H, Gfx.alpha(0xFFE58AAE, a));
            g.fill(W - 1 - i, 0, W - i, H, Gfx.alpha(0xFF7ED957, a));
        }
        for (int y = 4; y < H; y += 10) { rect(g, W / 2 - 1, y, 2, 5, 0x55FFFFFF); rect(g, W / 2 - 2, y, 4, 5, 0x11FFFFFF); }
        Gfx.disc(g, W / 2, H / 2, 16, 0x0DFFFFFF);
        Gfx.outline(g, 0, 0, W, H, 0x33FFFFFF);

        // your plate: rounded, shiny, flashes on a hit
        int ry = (int) py - PH / 2;
        Gfx.shadow(g, MARGIN, ry, PW, PH, 2);
        Gfx.bubble(g, MARGIN, ry, PW, PH, 2, flashL > 0 ? 0xFFFFD0E2 : 0xFFE58AAE);
        if (flashL > 0) Gfx.glow(g, MARGIN + 2, (int) py, 14, 0xFFFFB3CE, 110);

        // the slime plate: wobbling blob with eyes that follow the ball
        int sx = W - MARGIN - PW, sy = (int) ay - PH / 2;
        int wob = (int) Math.round(Math.sin(ticks * 0.2) * 1.0);
        Gfx.shadow(g, sx - 2, sy, PW + 2, PH, 2);
        Gfx.bubble(g, sx - 2 - wob, sy, PW + 2 + wob, PH, 2, flashR > 0 ? 0xFFC8FFB0 : 0xFF7ED957);
        if (flashR > 0) Gfx.glow(g, sx, (int) ay, 14, 0xFFB6F59A, 110);
        int look = by > ay ? 1 : by < ay ? -1 : 0;
        rect(g, sx - 2, (int) ay - 7, 3, 4, 0xFFFFFFFF); rect(g, sx - 2, (int) ay + 3, 3, 4, 0xFFFFFFFF);
        rect(g, sx - 2, (int) ay - 6 + look, 2, 2, 0xFF1B3A1B); rect(g, sx - 2, (int) ay + 4 + look, 2, 2, 0xFF1B3A1B);

        // ball with a comet tail
        int i = 0;
        for (double[] p : trail) {
            float k = 1f - i / 9f;
            if (i > 0) Gfx.disc(g, (int) p[0], (int) p[1], Math.max(1, (int) Math.round(BR * k)), Gfx.alpha(0xFFFFFFFF, (int) (70 * k)));
            i++;
        }
        if (serveTimer > 0 && (serveTimer / 8) % 2 == 0) Gfx.glow(g, (int) bx, (int) by, 10, 0xFFFFFFFF, 140);
        Gfx.glow(g, (int) bx, (int) by, 8, 0xFFFFFFFF, 70);
        Gfx.ball(g, (int) bx, (int) by, BR, 0xFFFFFFFF);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public String hintKey() { return "cutemod.hint.pong"; }
}
