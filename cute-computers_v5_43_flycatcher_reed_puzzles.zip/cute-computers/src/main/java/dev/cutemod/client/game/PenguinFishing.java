package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Blue computer: catch fish with the penguin, avoid pufferfish. */
public class PenguinFishing extends MiniGame {
    private double px;
    private int lives, spawn, t;
    private final List<double[]> items = new ArrayList<>(); // x, y, vy, type (0 fish, 1 puffer)

    @Override
    public void reset() {
        score = 0; over = false; lives = 3; spawn = 30; t = 0; px = W / 2.0;
        items.clear();
    }

    @Override
    public void tick() {
        t++;
        double target = Math.max(14, Math.min(W - 14, mx));
        px += (target - px) * 0.3;
        if (--spawn <= 0) {
            spawn = Math.max(18, 55 - score);
            boolean puffer = score >= 5 && rnd.nextInt(5) == 0;
            items.add(new double[]{12 + rnd.nextInt(W - 24), -8,
                    Math.min(2.6, 0.8 + score * 0.025 + rnd.nextDouble() * 0.4), puffer ? 1 : 0});
        }
        for (int i = items.size() - 1; i >= 0; i--) {
            double[] it = items.get(i);
            it[1] += it[2];
            boolean hit = it[1] > H - 34 && it[1] < H - 10 && Math.abs(it[0] - px) < 15;
            if (hit) {
                if (it[3] == 0) { score++; pling(1.3F); }
                else { lives--; beep(); }
                items.remove(i);
            } else if (it[1] > H - 4) {
                if (it[3] == 0) { lives--; beep(); }
                items.remove(i);
            }
        }
        if (lives <= 0) over = true;
    }

    @Override
    public void render(GuiGraphics g) {
        // polar sky with a low sun, far icebergs and snow
        g.fillGradient(0, 0, W, H, 0xFFA8DDFF, 0xFFE4F6FF);
        Gfx.glow(g, 40, H - 38, 34, 0xFFFFF0C8, 120);
        Gfx.disc(g, 40, H - 38, 9, 0xFFFFF6DC);
        for (int i = 0; i < 3; i++) {
            int bx = 70 + i * 62, bw = 46 - i * 6, bh = 22 + (i % 2) * 8;
            Gfx.poly(g, new int[]{bx, bx + bw / 3, bx + bw / 2, bx + bw}, new int[]{H - 10, H - 10 - bh, H - 10 - bh + 5, H - 10}, 0xFFB9E0F4);
            Gfx.poly(g, new int[]{bx + bw / 3, bx + bw / 2, bx + bw / 2 - 3}, new int[]{H - 10 - bh, H - 10 - bh + 5, H - 10}, 0xFFE8F8FF);
        }
        // sea strip behind the ice
        g.fillGradient(0, H - 12, W, H - 8, 0xFF6EC2EE, 0xFF4AA2DC);
        // falling snow in two sizes
        for (int i = 0; i < 22; i++) {
            int sx = (int) ((Gfx.hash(i, 5) * W + Math.sin((t + i * 20) * 0.03) * 4 + W) % W);
            int sy = (int) ((Gfx.hash(i, 6) * H + t * (0.35 + 0.5 * Gfx.hash(i, 7))) % H);
            int big = i % 3 == 0 ? 2 : 1;
            rect(g, sx, sy, big, big, big == 2 ? 0xEEFFFFFF : 0xAAFFFFFF);
        }
        // ice floor
        g.fillGradient(0, H - 8, W, H, 0xFFFFFFFF, 0xFFD5ECFA);
        g.fill(0, H - 8, W, H - 7, 0xFFFFFFFF);
        for (int i = 0; i < 6; i++) g.fill(10 + i * 38, H - 5, 26 + i * 38, H - 4, 0x22A0C8E0);
        for (double[] it : items) {
            int x = (int) it[0], y = (int) it[1];
            if (it[3] == 0) fish(g, x, y); else puffer(g, x, y);
        }
        penguin(g, (int) px, H - 26);
        // lives as little hearts would be redundant: the status line already shows them
    }

    private void fish(GuiGraphics g, int x, int y) {
        int wig = (int) Math.round(Math.sin(t * 0.25 + x) * 1.5);
        Gfx.glow(g, x, y, 9, 0xFFFFC27A, 50);
        // tail
        Gfx.poly(g, new int[]{x + 4, x + 10, x + 10}, new int[]{y, y - 4 + wig, y + 4 + wig}, 0xFFE0753A);
        // body
        Gfx.ellipse(g, x - 1, y, 7, 4, 0xFFE0753A);
        Gfx.ellipse(g, x - 1, y - 1, 6, 3, 0xFFFFA05E);
        g.fill(x - 3, y + 1, x + 3, y + 3, 0xFFFFE0BC);            // belly
        g.fill(x - 1, y - 3, x + 2, y - 2, 0xFFE0753A);            // fin
        // eye and gill
        g.fill(x - 5, y - 2, x - 3, y, 0xFFFFFFFF); g.fill(x - 5, y - 1, x - 4, y, 0xFF1A2A4A);
        g.fill(x - 2, y - 2, x - 1, y + 2, 0x33A04010);
    }

    private void puffer(GuiGraphics g, int x, int y) {
        int pulse = (int) Math.round(Math.sin(t * 0.18) * 0.8);
        Gfx.glow(g, x, y, 11, 0xFFFF6A3A, 45);
        for (int a = 0; a < 12; a++) {
            double ang = a * Math.PI / 6;
            int sx = (int) Math.round(Math.cos(ang) * (7 + pulse)), sy = (int) Math.round(Math.sin(ang) * (7 + pulse));
            g.fill(x + sx - 1, y + sy - 1, x + sx + 1, y + sy + 1, 0xFFB5481F);
        }
        Gfx.ball(g, x, y, 6, 0xFFF2D94E);
        g.fill(x - 4, y + 1, x + 4, y + 4, 0xFFFFF3B0);             // belly
        g.fill(x - 3, y - 2, x - 1, y, 0xFFFFFFFF); g.fill(x + 1, y - 2, x + 3, y, 0xFFFFFFFF);
        g.fill(x - 2, y - 2, x - 1, y - 1, 0xFF1A2A4A); g.fill(x + 2, y - 2, x + 3, y - 1, 0xFF1A2A4A);
        g.fill(x - 1, y + 1, x + 1, y + 2, 0xFFB5481F);              // grumpy mouth
        g.fill(x - 4, y - 4, x - 1, y - 3, 0xFFB5481F); g.fill(x + 1, y - 3, x + 4, y - 4, 0xFFB5481F);   // angry brows
    }

    private void penguin(GuiGraphics g, int x, int y) {
        int sway = (int) Math.round(Math.sin(t * 0.2) * 1.0);
        Gfx.ellipse(g, x, y + 20, 12, 2, 0x33406080);                // shadow on the ice
        // feet
        Gfx.ellipse(g, x - 5, y + 19, 4, 2, 0xFFFF9A1F); Gfx.ellipse(g, x + 5, y + 19, 4, 2, 0xFFFF9A1F);
        // flippers (they flap with the sway)
        Gfx.ellipse(g, x - 12, y + 10 - sway, 3, 6, 0xFF1F3A78);
        Gfx.ellipse(g, x + 12, y + 10 + sway, 3, 6, 0xFF1F3A78);
        // body
        Gfx.ellipse(g, x, y + 10, 11, 11, 0xFF14264F);
        Gfx.ellipse(g, x, y + 9, 10, 10, 0xFF2C4D94);
        Gfx.ellipse(g, x, y + 12, 7, 8, 0xFFFFFFFF);
        Gfx.ellipse(g, x, y + 14, 6, 5, 0xFFE8F2FF);
        // face
        g.fill(x - 6, y + 2, x - 1, y + 7, 0xFFFFFFFF); g.fill(x + 1, y + 2, x + 6, y + 7, 0xFFFFFFFF);
        g.fill(x - 4, y + 4, x - 2, y + 7, 0xFF14213F); g.fill(x + 2, y + 4, x + 4, y + 7, 0xFF14213F);
        g.fill(x - 4, y + 4, x - 3, y + 5, 0xFFFFFFFF); g.fill(x + 2, y + 4, x + 3, y + 5, 0xFFFFFFFF);
        // beak and blush
        Gfx.poly(g, new int[]{x - 3, x + 3, x}, new int[]{y + 7, y + 7, y + 11}, 0xFFFF9A1F);
        g.fill(x - 7, y + 8, x - 5, y + 9, 0x66FF7AA0); g.fill(x + 5, y + 8, x + 7, y + 9, 0x66FF7AA0);
        // little scarf
        g.fill(x - 7, y + 12, x + 8, y + 14, 0xFFE0594F);
        g.fill(x - 7, y + 12, x + 8, y + 13, 0xFFFF8A80);
        g.fill(x + 4, y + 14, x + 7, y + 18, 0xFFE0594F);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public String hintKey() { return "cutemod.hint.penguin"; }
}
