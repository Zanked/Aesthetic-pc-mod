package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Space-Invaders style: a cat shoots at a swarm of bees that drop stingers. */
public class BeeInvaders extends MiniGame {
    private static final int COLS = 8, ROWS = 4, SX = 22, SY = 14, BW = 12, BH = 9, PY = H - 14;

    private final boolean[][] alive = new boolean[ROWS][COLS];
    private final List<double[]> shots = new ArrayList<>();
    private final List<double[]> bombs = new ArrayList<>();
    private double gx, gy, gdir, px, target, speed;
    private int lives, level, left, cooldown, invuln, ticks, lastMx;

    @Override
    public void reset() {
        score = 0; over = false; lives = 3; level = 1;
        px = target = W / 2.0; lastMx = mx;
        cooldown = 0; invuln = 0; ticks = 0;
        shots.clear(); bombs.clear();
        spawnWave();
    }

    private void spawnWave() {
        for (boolean[] row : alive) java.util.Arrays.fill(row, true);
        left = ROWS * COLS;
        gx = 10; gy = 14; gdir = 1;
        speed = Math.min(0.9, 0.25 + 0.06 * level);
        shots.clear(); bombs.clear();
    }

    private void shoot() {
        if (cooldown > 0) return;
        shots.add(new double[]{px, PY - 6});
        cooldown = 18;
        pling(1.6F);
    }

    @Override
    public boolean click(int x, int y, int button) { shoot(); return true; }

    @Override
    public boolean key(int k) {
        if (k == KEY_SPACE || k == KEY_UP) { shoot(); return true; }
        if (k == KEY_LEFT) { target -= 12; return true; }
        if (k == KEY_RIGHT) { target += 12; return true; }
        return false;
    }

    @Override
    public void tick() {
        ticks++;
        if (cooldown > 0) cooldown--;
        if (invuln > 0) invuln--;
        if (mx != lastMx) { target = mx; lastMx = mx; }
        target = Math.max(8, Math.min(W - 8, target));
        px += (target - px) * 0.3;

        // swarm movement: faster when fewer bees remain
        int total = ROWS * COLS;
        double sp = speed * (1.0 + (total - left) / (double) total * 2.0);
        gx += gdir * sp;
        int minC = COLS, maxC = -1, lowR = -1;
        for (int r = 0; r < ROWS; r++)
            for (int c = 0; c < COLS; c++)
                if (alive[r][c]) { minC = Math.min(minC, c); maxC = Math.max(maxC, c); lowR = Math.max(lowR, r); }
        if (maxC >= 0) {
            if (gx + minC * SX < 2 || gx + maxC * SX + BW > W - 2) {
                gdir = -gdir;
                gx += gdir * sp * 2;
                gy += 6;
            }
            if (gy + lowR * SY + BH >= PY - 2) { lives = 0; over = true; return; }
        }

        // our shots
        for (int i = shots.size() - 1; i >= 0; i--) {
            double[] s = shots.get(i);
            s[1] -= 3.5;
            if (s[1] < -4) { shots.remove(i); continue; }
            boolean hit = false;
            for (int r = 0; r < ROWS && !hit; r++) {
                for (int c = 0; c < COLS; c++) {
                    if (!alive[r][c]) continue;
                    double bx = gx + c * SX, by = gy + r * SY;
                    if (s[0] >= bx - 1 && s[0] <= bx + BW + 1 && s[1] >= by && s[1] <= by + BH) {
                        alive[r][c] = false; left--; score += 10;
                        pling(1.2F + r * 0.1F);
                        hit = true;
                        break;
                    }
                }
            }
            if (hit) shots.remove(i);
        }

        // stingers
        if (left > 0 && rnd.nextDouble() < 0.012 + 0.002 * level) {
            int c = rnd.nextInt(COLS);
            for (int r = ROWS - 1; r >= 0; r--) {
                if (alive[r][c]) { bombs.add(new double[]{gx + c * SX + BW / 2.0, gy + r * SY + BH}); break; }
            }
        }
        for (int i = bombs.size() - 1; i >= 0; i--) {
            double[] b = bombs.get(i);
            b[1] += 1.4;
            if (b[1] > H + 4) { bombs.remove(i); continue; }
            if (invuln <= 0 && b[1] >= PY && b[1] <= PY + 9 && Math.abs(b[0] - px) <= 8) {
                bombs.remove(i);
                lives--; invuln = 60; beep();
                if (lives <= 0) { over = true; return; }
            }
        }

        if (left == 0) { level++; score += 50; pling(2.0F); spawnWave(); }
    }

    private void drawBee(GuiGraphics g, int x, int y) {
        int flap = (ticks / 6) % 2;
        // wings buzz above the body; the body is one rounded box with a dark rim, stripes and a shine
        rect(g, x + 1, y + flap, 4, 3, 0xCCEAF8FF); rect(g, x + 7, y + flap, 4, 3, 0xCCEAF8FF);
        Gfx.rrect(g, x, y + 2, 12, 8, 3, 0xFF2A2A2A);
        Gfx.rrect(g, x + 1, y + 3, 10, 6, 2, 0xFFF5C518);
        rect(g, x + 4, y + 3, 1, 6, 0xFF2A2A2A); rect(g, x + 7, y + 3, 1, 6, 0xFF2A2A2A);
        rect(g, x + 4, y + 3, 4, 1, 0x66FFFFFF);
        rect(g, x + 1, y + 4, 2, 2, 0xFFFFFFFF); rect(g, x + 9, y + 4, 2, 2, 0xFFFFFFFF);
        rect(g, x + 2, y + 5, 1, 1, 0xFF14101C); rect(g, x + 9, y + 5, 1, 1, 0xFF14101C);
        rect(g, x + 5, y + 10, 2, 1, 0xFF2A2A2A);
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF100E2A, 0xFF3F2E66);
        Gfx.glow(g, 40, 24, 40, 0xFF7A5AD0, 60);
        Gfx.glow(g, 190, 70, 36, 0xFFE45CFF, 40);
        for (int i = 0; i < 24; i++) { // twinkling stars, some drift down slowly
            int x = (i * 37 + 11) % W, y = ((i * 53 + 7) + ticks / (6 + i % 3 * 3)) % (H - 20);
            if (i % 5 == 0) Gfx.sparkle(g, x, y, 2, ticks + i * 9, 0xFFFFFFFF);
            else if ((ticks / 20 + i) % 3 != 0) rect(g, x, y, 1, 1, 0xAAFFFFFF);
        }
        // glowing ground line
        g.fillGradient(0, H - 6, W, H, 0x00B08AFF, 0x66B08AFF);
        for (int r = 0; r < ROWS; r++)
            for (int c = 0; c < COLS; c++)
                if (alive[r][c]) drawBee(g, (int) gx + c * SX, (int) gy + r * SY);

        for (double[] s : shots) {                         // your shots: bright bolts with a tail
            int x = (int) s[0], y = (int) s[1];
            g.fillGradient(x - 1, y + 3, x + 2, y + 10, 0x00FFE0F0, 0x66FFE0F0);
            Gfx.glow(g, x, y + 1, 5, 0xFFFFC2E0, 90);
            rect(g, x, y, 1, 5, 0xFFFFFFFF);
        }
        for (double[] b : bombs) {                         // bee bombs: flickering orange orbs
            Gfx.glow(g, (int) b[0], (int) b[1], 7, 0xFFFF8A3C, 100);
            Gfx.ball(g, (int) b[0], (int) b[1], 2, 0xFFFFB04C);
        }

        if (invuln == 0 || (invuln / 4) % 2 == 0) { // the cat with a cannon
            int x = (int) px;
            Gfx.glow(g, x, PY + 5, 13, 0xFFFFC2E0, 45);
            Gfx.ellipse(g, x, PY + 9, 8, 2, 0x44000000);
            rect(g, x - 1, PY - 4, 2, 4, 0xFFFFFFFF); rect(g, x - 1, PY - 4, 2, 1, 0xFFFFE27A);   // cannon
            Gfx.ellipse(g, x, PY + 5, 8, 5, 0xFFC95A86);
            Gfx.ellipse(g, x, PY + 4, 7, 4, 0xFFF58FB8);
            rect(g, x - 7, PY, 3, 3, 0xFFF58FB8); rect(g, x + 4, PY, 3, 3, 0xFFF58FB8);            // ears
            rect(g, x - 6, PY + 1, 1, 2, 0xFFFFC2D8); rect(g, x + 5, PY + 1, 1, 2, 0xFFFFC2D8);
            rect(g, x - 4, PY + 3, 3, 3, 0xFF3A2A3A); rect(g, x + 1, PY + 3, 3, 3, 0xFF3A2A3A);    // eyes
            rect(g, x - 4, PY + 3, 1, 1, 0xFFFFFFFF); rect(g, x + 1, PY + 3, 1, 1, 0xFFFFFFFF);
            rect(g, x - 1, PY + 6, 2, 1, 0xFFC04A7A);                                              // mouth
            rect(g, x - 6, PY + 6, 2, 1, 0x66FF6A9A); rect(g, x + 4, PY + 6, 2, 1, 0x66FF6A9A);    // blush
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public String hintKey() { return "cutemod.hint.bees"; }
}
