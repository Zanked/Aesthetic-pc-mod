package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import dev.cutemod.client.os.Fit;
import dev.cutemod.client.os.TexCache;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Quiet Hive: an Among Us style game for one player. Eight pets live on a small station, two of them are impostors.
 * You are the crew (do tasks, report bodies, argue and vote) or an impostor (kill, vent, sabotage, lie), every second game
 * the other role. The seven bots are not decoration: each one walks the map, remembers who it saw and where, and at a
 * meeting says what it really saw (or, if it is an impostor, lies). The vote follows what the bots believe.
 * The camera follows the player, the rest of the map is hidden by walls and fog.
 */
public class Hive extends MiniGame {
    private static final int T = 8, MW = 120, MH = 68, N = 8, PER = 4, SIGHT = 70, SPOTS = 26;
    private static final int PH_ROLE = 0, PH_PLAY = 1, PH_MEET = 2, PH_END = 3;
    private static final int M_INTRO = 0, M_TALK = 1, M_VOTE = 2, M_SHOW = 3, M_EJECT = 4;
    private static final int K_WIRES = 0, K_UPLOAD = 1, K_FUEL = 2, K_KEYPAD = 3, K_BUGS = 4, K_CALIB = 5,
            K_SIMON = 6, K_SWITCH = 7, K_SORT = 8, K_PAIRS = 9;
    private static final int A_USE = 0, A_REPORT = 1, A_KILL = 2, A_VENT = 3, A_DARK = 4, A_CORE = 5, A_MAP = 6, A_ROLE = 7;
    private static final int R_ENG = 1, R_GRD = 2, R_DET = 3, R_KIL = 4, R_SAB = 5;      // the crew roles (engineer, guardian, detective) and the impostor roles (killer, saboteur)
    private static final int[] CREW_ACTS = {A_USE, A_REPORT, A_MAP};
    private static final int[] ROLE_ACTS = {A_USE, A_REPORT, A_ROLE, A_MAP};
    private static final int[] IMP_ACTS = {A_USE, A_KILL, A_VENT, A_DARK, A_CORE, A_MAP};
    private static final String[] ACT_KEYS = {"use", "report", "kill", "vent", "dark", "core", "map", "role"};
    private static final int KILL_CD = 1500;
    private static final float SPEED = 1.0F, BOT_SPEED = 0.85F;

    // pet = 0 pig, 1 frog, 2 panda, 3 mouse, 4 fox, 5 koala, 6 cat, 7 bear
    private static final int[] COLORS = {0xFFF4A7C3, 0xFF7ED957, 0xFFF4F0E8, 0xFF6FA8F2, 0xFFF5A04A, 0xFFB57BD6, 0xFFF3D46A, 0xFFE0594F};
    // rooms: 0 cafeteria, 1 upper engine, 2 lower engine, 3 reactor, 4 security, 5 lab, 6 electrical, 7 storage, 8 admin, 9 communications, 10 shields,
    // 11 navigation, 12 garden, 13 weapons; the hallway is ROOMS.length
    private static final int[][] ROOMS = {{62, 4, 26, 20}, {18, 4, 18, 14}, {18, 50, 18, 14}, {3, 24, 12, 20}, {40, 28, 10, 12}, {44, 12, 14, 12}, {42, 46, 14, 14}, {62, 44, 22, 20}, {92, 34, 14, 12}, {92, 54, 14, 10}, {108, 48, 10, 14}, {108, 24, 10, 14}, {96, 20, 10, 10}, {100, 4, 16, 14}};
    private static final int[] BEVEL = {5, 3, 3, 3, 2, 0, 0, 3, 0, 0, 3, 3, 3, 3};                          // how much of every corner is cut off (the rooms are not plain boxes)
    private static final int[][] HALLS = {{35, 6, 28, 3}, {49, 8, 3, 5}, {57, 16, 6, 3}, {25, 17, 3, 34}, {14, 32, 12, 3}, {27, 32, 14, 3}, {49, 32, 25, 3}, {73, 23, 3, 22}, {47, 39, 3, 8}, {35, 54, 8, 3}, {55, 50, 8, 3}, {75, 38, 18, 3}, {83, 58, 10, 3}, {105, 56, 4, 3}, {111, 37, 3, 12}, {105, 40, 7, 3}, {87, 9, 14, 3}, {87, 20, 10, 3}, {101, 17, 3, 4}, {105, 24, 4, 3}, {99, 29, 3, 6}, {35, 61, 28, 3}};
    private static final int[][] BLOCKS = {{74, 12, 2, 2}, {67, 6, 2, 2}, {82, 6, 2, 2}, {67, 20, 2, 2}, {82, 20, 2, 2}, {26, 9, 2, 2}, {26, 56, 2, 2}, {6, 33, 2, 2}, {46, 16, 2, 2}, {53, 16, 2, 2}, {44, 52, 2, 2}, {52, 54, 2, 2}, {66, 48, 2, 2}, {70, 52, 2, 2}, {78, 50, 2, 2}, {68, 58, 2, 2}, {79, 55, 2, 2}, {98, 41, 2, 2}, {98, 60, 2, 2}, {112, 30, 2, 2}, {108, 8, 2, 2}, {98, 24, 2, 2}, {102, 27, 2, 2}, {110, 13, 2, 2}};
    // what every big thing is: 0 the round table with the button, 1 engine core, 2 fuse box, 3 lab bench, 4 console, 5 planter, 6 crates
    private static final int[] BKIND = {0, 5, 5, 5, 5, 1, 1, 1, 3, 3, 2, 2, 6, 6, 6, 6, 6, 4, 4, 4, 4, 5, 5, 6};
    // floor colours per style (two tones for the checker): cafeteria, engine, electrical, storage, lab, navigation, garden, hallway, reactor, security, admin, comms, weapons, shields
    private static final int[] RSTYLE = {0, 1, 1, 8, 9, 4, 2, 3, 10, 11, 13, 5, 6, 12};
    private static final int[] ROOM_A = {0xFFE8CDB0, 0xFF9AA3B5, 0xFF7F8FC4, 0xFFC9A67E, 0xFFCDEBE4, 0xFF7BA6D9, 0xFF9AD27F, 0xFFB9A8E0, 0xFFC98B8B, 0xFF8FA8C8, 0xFFA8D0A0, 0xFFD0A8D8, 0xFFE0B090, 0xFF8FC4D8};
    private static final int[] ROOM_B = {0xFFE0C3A5, 0xFF909AAE, 0xFF7584B9, 0xFFC09D74, 0xFFC2E2DA, 0xFF729DD0, 0xFF90C876, 0xFFB0A0D8, 0xFFC08282, 0xFF86A0C0, 0xFF9FC898, 0xFFC8A0D0, 0xFFD8A888, 0xFF86BCD0};
    private static final int WALL_TOP = 0xFF3E3478, WALL_FRONT = 0xFF6E60BA;
    private static final int[] TX = {84, 65, 22, 32, 22, 33, 12, 5, 47, 54, 46, 52, 44, 66, 80, 72, 103, 94, 103, 115, 115, 110, 103, 112, 103, 84};
    private static final int[] TY = {8, 18, 14, 6, 60, 53, 34, 40, 36, 20, 21, 57, 49, 61, 47, 60, 36, 43, 61, 58, 28, 35, 22, 6, 15, 21};
    private static final int[] KIND = {K_UPLOAD, K_WIRES, K_FUEL, K_CALIB, K_FUEL, K_SIMON, K_KEYPAD, K_SWITCH, K_WIRES, K_SORT, K_BUGS, K_WIRES, K_SWITCH, K_FUEL, K_SORT, K_PAIRS, K_UPLOAD, K_KEYPAD, K_UPLOAD, K_SWITCH, K_CALIB, K_SIMON, K_BUGS, K_PAIRS, K_KEYPAD, K_SWITCH};
    private static final int[] VX = {20, 5, 20, 5, 45, 41, 43, 85, 104, 113, 110, 114, 115}, VY = {6, 26, 62, 41, 14, 29, 57, 19, 44, 6, 26, 60, 35}, VG = {0, 0, 1, 1, 2, 2, 2, 3, 3, 4, 4, 5, 5};
    private static final int LX = 49, LY = 57;                       // the light panel
    private static final int[] CX = {8, 8}, CY = {26, 41};          // the two reactor consoles
    private static final int BX = 600, BY = 104;                     // the emergency button (pixels)
    private static final int[] WIRE_COL = {0xFFE0594F, 0xFF4A8FE0, 0xFFF3D46A, 0xFF7ED957};
    private static final int CSX = 45, CSY = 33;                     // the camera console
    private static final int[] CMX = {48, 60, 31, 84}, CMY = {7, 33, 33, 39};   // the four cameras: the halls
    private static final int PX = 14, PY = 6, PW = 192, PH = 128;     // the task window

    private static boolean nextImp, roleSeen;

    private static final class Actor {
        final int id;
        boolean imp, alive = true, vented;
        float x, y;
        int face = 1;
        int[] path = new int[0];
        int pp;
        int mode, timer, taskI = -1, fixKind = -1, hunt = -1, huntT, killCd, ventAt = -1, ventT, bodyT = -1, ghostT, lastRoom;
        int witness = -1, witnessV = -1, ventSaw = -1;
        int camWho = -1, camRoom, camTick = -99999;      // the last pet it saw on the cameras
        int goal = -1;                                   // the tile its path was last made for
        int buddy = -1, buddyT, stalk = -1, stalkT;      // whom it walks with, whom an impostor follows
        final int[] hist = new int[64];                  // the room it was in, one entry per 100 ticks
        boolean called, shield;
        final boolean[] seenWork = new boolean[N];       // whom it saw doing a task that everybody can see (that one is crew for sure)
        int role, uses, attacker = -1, detT = -1;
        final int[] together = new int[N];            // how long this bot has been in company of each other pet
        final int[][] with = new int[N][N];           // when it last saw two pets together
        final int[] seenTick = new int[N], seenRoom = new int[N], susp = new int[N];
        final int[] spot = new int[PER];
        final boolean[] done = new boolean[PER];

        Actor(int id) { this.id = id; }
    }

    private static final class Body { int victim, killer, room, tick; float x, y; boolean reported; }

    private static final class Line {
        final int who;
        final Component text;
        final String kind;

        Line(int who, Component text, String kind) { this.who = who; this.text = text; this.kind = kind; }
    }

    private final boolean[][] solid = new boolean[MH][MW];
    private final boolean[][] blk = new boolean[MH][MW];
    private final boolean[][] vis = new boolean[MH][MW];
    private final byte[][] roomOf = new byte[MH][MW];                // the room of every tile, worked out once
    private final byte[][] wallKind = new byte[MH][MW];              // 1 a wall seen from the front, 2 a wall top next to the floor, 0 not drawn
    private final List<int[]> mapRuns = new ArrayList<>();           // the minimap as runs of equal colour: {tx, ty, length, colour}
    private final int[] bfsPrev = new int[MW * MH], bfsQ = new int[MW * MH], bfsMark = new int[MW * MH];
    private int bfsGen;
    private final byte[][] wallDist = new byte[MH][MW];              // how far (in tiles) a floor tile is from the nearest wall
    private final int[][] lampCol = new int[MH][MW];                 // the light of the ceiling lamps on every floor tile (an ARGB overlay)
    private int[] decorTiles = new int[0], sparkleTiles = new int[0], stars = new int[0];
    private boolean bakeMode;                                        // the still picture of the world is being painted: nothing in it may move
    private static TexCache.Tex world;                               // that picture: the whole station in one texture
    private static boolean worldFailed;
    private static int clipW = W, clipH = H;                         // what fillC cuts to: the screen, or the whole picture while it is painted
    private static final int[] LIGHT_RGB = {0xFFE6B0, 0xE6EEFF, 0xB8C4FF, 0xFFE2B8, 0xE0FFF6, 0xC0D8FF, 0xEEFFB8, 0xFFF4D0, 0xFFB8A0, 0xC8E0FF, 0xEAFFC8, 0xF0C8FF, 0xFFD8B8, 0xC0F0FF};
    private static final int[] TWINKLE = {50, 100, 160, 230, 160, 100};
    private final Actor[] act = new Actor[N];
    private final int[] pet = new int[N];
    private final List<Body> bodies = new ArrayList<>();
    private final List<Line> lines = new ArrayList<>();

    private int phase, phaseT, ticks, kills, doneTasks, totalTasks, killFlash;
    private boolean playerImp, crewWon, won;
    private boolean lightsOut, reactorOn, buttonUsed, mapOpen;
    private int reactorT, sabCd, hold;
    private final boolean[] consoleOk = new boolean[2];

    // task window
    private boolean taskOpen, tFix, tFake;
    private int tKind, tIdx, tDone;
    private final int[] wr = new int[4], wc = new int[4];
    private int wsel, upT, knext, cz, chit;
    private boolean upOn;
    private float fuel, cm, cv;
    private final int[] kx = new int[6], ky = new int[6];
    private final float[] bx = new float[8], by = new float[8], bvx = new float[8], bvy = new float[8];     // 6 bugs and 2 fireflies that must be left alone
    private final boolean[] bdead = new boolean[8];
    private final int[] sq = new int[5];                 // the melody
    private int sqIn, sqT, sqFl, sqFlT, sqLen, sqRound;
    private boolean sqShow;
    private final boolean[] swT = new boolean[6], swS = new boolean[6];
    private int sortC, sortN, sortT, sortMax;
    private int upBr, fuelLock, czw;
    private boolean upStall;
    private float fuelHeat;
    private final int[] pcV = new int[8];
    private final boolean[] pcUp = new boolean[8], pcOk = new boolean[8];
    private int pcA, pcWait, pcDone;

    // meeting
    private int mstate, mt, caller, bodyIdx, shown, lineT, sel, pVote, pActs, ejected, skipCount, contras, scoreOut;
    private boolean ejWasImp;
    private final int[] vote = new int[N], tally = new int[N], pub = new int[N];
    private final boolean[] asked = new boolean[N];
    private final int[] chk = new int[N];                // what the detective has found out: 1 crew, 2 impostor
    private String hudMsg = "";
    private int hudT;
    private int chatOff;                                 // how many lines the chat is scrolled back
    private boolean evi, camOpen;
    private final int[] rxK = new int[N], rxT = new int[N];       // the little reaction above a card: its kind and how long it stays
    private int speakT, speakW = -1, myRxLine = -1;
    private int insertAt = -1;
    private final List<float[]> candies = new ArrayList<>();      // sweets lying around: a speed boost
    private int boostT;
    private boolean wary, pressed;                       // a body has been found / the quiet player has been pressed
    private final int[] pairWish = new int[N];           // who wants to walk with whom after the meeting

    public Hive() { buildMap(); }

    private void buildMap() {
        for (boolean[] r : solid) java.util.Arrays.fill(r, true);
        for (int i = 0; i < ROOMS.length; i++) {
            int[] r = ROOMS[i];
            carve(r, false);
            int b = BEVEL[i];
            for (int dy = 0; dy < b; dy++) {                       // the corners are cut off
                for (int dx = 0; dx < b - dy; dx++) {
                    solid[r[1] + dy][r[0] + dx] = true; solid[r[1] + dy][r[0] + r[2] - 1 - dx] = true;
                    solid[r[1] + r[3] - 1 - dy][r[0] + dx] = true; solid[r[1] + r[3] - 1 - dy][r[0] + r[2] - 1 - dx] = true;
                }
            }
        }
        for (int[] r : HALLS) carve(r, false);
        for (int[] r : BLOCKS) {
            carve(r, true);
            for (int y = r[1]; y < r[1] + r[3]; y++) for (int x = r[0]; x < r[0] + r[2]; x++) blk[y][x] = true;
        }
        for (int y = 0; y < MH; y++) {
            for (int x = 0; x < MW; x++) {
                int room = ROOMS.length;
                for (int i = 0; i < ROOMS.length; i++) {
                    int[] r = ROOMS[i];
                    if (x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]) { room = i; break; }
                }
                roomOf[y][x] = (byte) room;
                if (!solid[y][x] || blk[y][x]) continue;
                if (y + 1 < MH && !solid[y + 1][x]) { wallKind[y][x] = 1; continue; }
                boolean edge = false;
                for (int dy = -1; dy <= 1 && !edge; dy++)
                    for (int dx = -1; dx <= 1; dx++) if (!solidTile(x + dx, y + dy)) { edge = true; break; }
                if (edge) wallKind[y][x] = 2;
            }
        }
        mapRuns.clear();
        for (int y = 0; y < MH; y++) {
            int x = 0;
            while (x < MW) {
                if (solid[y][x] && !blk[y][x]) { x++; continue; }
                int c = Gfx.lighter(blk[y][x] ? 0xFFB58A5A : ROOM_A[styleOf(roomOf[y][x])], 0.1F);
                int x1 = x + 1;
                while (x1 < MW && !(solid[y][x1] && !blk[y][x1])
                        && Gfx.lighter(blk[y][x1] ? 0xFFB58A5A : ROOM_A[styleOf(roomOf[y][x1])], 0.1F) == c) x1++;
                mapRuns.add(new int[] {x, y, x1 - x, c});
                x = x1;
            }
        }
        buildDist();
        buildLights();
        buildLists();
    }

    private boolean decorAt(int tx, int ty) { return wallKind[ty][tx] == 1 && Gfx.hash(tx, ty * 3 + 1) < 0.42F; }

    private boolean roomFloor(int tx, int ty) { return tx >= 0 && ty >= 0 && tx < MW && ty < MH && !solid[ty][tx] && roomOf[ty][tx] < ROOMS.length; }

    private boolean hallFloor(int tx, int ty) { return tx >= 0 && ty >= 0 && tx < MW && ty < MH && !solid[ty][tx] && roomOf[ty][tx] == ROOMS.length; }

    /** The distance of every tile from the nearest wall (4 steps at most): the middle of a hall is 2 away. */
    private void buildDist() {
        int[] q = new int[MW * MH];
        int h = 0, t = 0;
        for (int y = 0; y < MH; y++) {
            for (int x = 0; x < MW; x++) {
                if (solid[y][x]) { wallDist[y][x] = 0; q[t++] = y * MW + x; } else wallDist[y][x] = 127;
            }
        }
        int[] ddx = {1, -1, 0, 0}, ddy = {0, 0, 1, -1};
        while (h < t) {
            int c = q[h++];
            int cx = c % MW, cy = c / MW, d = wallDist[cy][cx];
            if (d >= 4) continue;
            for (int k = 0; k < 4; k++) {
                int nx = cx + ddx[k], ny = cy + ddy[k];
                if (nx < 0 || ny < 0 || nx >= MW || ny >= MH || wallDist[ny][nx] != 127) continue;
                wallDist[ny][nx] = (byte) (d + 1);
                q[t++] = ny * MW + nx;
            }
        }
    }

    /** Ceiling lamps: a few in every room, one every twelve tiles along a hall. Their light is worked out once and sits on the floor as a soft pool. */
    private void buildLights() {
        List<float[]> lamps = new ArrayList<>();                    // {x, y, radius, strength}
        for (int[] r : ROOMS) {
            int nx = Math.max(1, Math.round(r[2] / 12F)), ny = Math.max(1, Math.round(r[3] / 12F));
            float rad = Math.max(r[2] / (float) nx, r[3] / (float) ny) * 0.8F;
            for (int j = 0; j < ny; j++)
                for (int i = 0; i < nx; i++) lamps.add(new float[] {r[0] + (i + 0.5F) * r[2] / nx, r[1] + (j + 0.5F) * r[3] / ny, rad, 38F});
        }
        for (int[] h : HALLS) {
            boolean horiz = h[2] >= h[3];
            int n = Math.max(1, (horiz ? h[2] : h[3]) / 12);
            for (int i = 0; i < n; i++) {
                float f = (i + 0.5F) / n;
                lamps.add(new float[] {horiz ? h[0] + f * h[2] : h[0] + h[2] / 2F, horiz ? h[1] + h[3] / 2F : h[1] + f * h[3], 7F, 20F});
            }
        }
        for (int y = 0; y < MH; y++) {
            for (int x = 0; x < MW; x++) {
                lampCol[y][x] = 0;
                if (solid[y][x] && !blk[y][x]) continue;
                float sum = 0F;
                for (float[] l : lamps) {
                    float dx = x + 0.5F - l[0], dy = y + 0.5F - l[1];
                    if (Math.abs(dx) >= l[2] || Math.abs(dy) >= l[2]) continue;
                    float d = (float) Math.sqrt(dx * dx + dy * dy);
                    if (d < l[2]) { float k = 1F - d / l[2]; sum += k * k * l[3]; }
                }
                int a = Math.min(54, (int) sum);
                if (a > 0) lampCol[y][x] = (a << 24) | LIGHT_RGB[styleOf(roomOf[y][x])];
            }
        }
    }

    /** The lists of what moves on the still picture of the world. */
    private void buildLists() {
        List<Integer> dl = new ArrayList<>(), sp = new ArrayList<>(), sl = new ArrayList<>();
        for (int y = 0; y < MH; y++) {
            for (int x = 0; x < MW; x++) {
                if (decorAt(x, y)) dl.add(y * MW + x);
                if (!solid[y][x] && styleOf(roomOf[y][x]) == 13) sp.add(y * MW + x);
            }
        }
        int wpx = MW * T, hpx = MH * T;
        for (int i = 0; sl.size() < 90 && i < 3000; i++) {
            int sx = (int) (Gfx.hash(i, 101) * wpx), sy = (int) (Gfx.hash(i, 203) * hpx);
            if (sx >= wpx || sy >= hpx) continue;
            int tx = sx / T, ty = sy / T;
            if (solid[ty][tx] && !blk[ty][tx] && wallKind[ty][tx] == 0) sl.add(sy * wpx + sx);       // a star in the empty space
        }
        decorTiles = dl.stream().mapToInt(Integer::intValue).toArray();
        sparkleTiles = sp.stream().mapToInt(Integer::intValue).toArray();
        stars = sl.stream().mapToInt(Integer::intValue).toArray();
    }

    private void carve(int[] r, boolean s) {
        for (int y = r[1]; y < r[1] + r[3]; y++) for (int x = r[0]; x < r[0] + r[2]; x++) solid[y][x] = s;
    }

    // ------------------------------------------------------------------ start

    @Override
    public void reset() {
        score = 0; over = false; won = false; crewWon = false;
        phase = PH_ROLE; phaseT = 200; ticks = 0; kills = 0; doneTasks = 0; killFlash = 0;
        bodies.clear(); lines.clear(); wary = false; pressed = false;
        lightsOut = false; reactorOn = false; reactorT = 0; sabCd = 900; buttonUsed = false; hold = 0;
        taskOpen = false; mapOpen = false; camOpen = false;
        candies.clear(); boostT = 0;
        for (int i = 0; i < 4; i++) spawnCandy();
        int[] perm = {0, 1, 2, 3, 4, 5, 6, 7};
        for (int i = N - 1; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = perm[i]; perm[i] = perm[j]; perm[j] = t; }
        System.arraycopy(perm, 0, pet, 0, N);
        nextImp = roleSeen ? !nextImp : rnd.nextBoolean();      // every second game is the other role
        roleSeen = true;
        playerImp = nextImp;
        boolean[] imp = new boolean[N];
        if (playerImp) imp[0] = true;
        int need = playerImp ? 1 : 2;
        while (need > 0) { int i = 1 + rnd.nextInt(N - 1); if (!imp[i]) { imp[i] = true; need--; } }
        totalTasks = 0;
        for (int i = 0; i < N; i++) {
            Actor a = new Actor(i);
            act[i] = a;
            a.imp = imp[i];
            int c = 0;
            while (c < PER) {
                int s = rnd.nextInt(SPOTS);
                boolean dup = false;
                for (int k = 0; k < c; k++) if (a.spot[k] == s) dup = true;
                if (!dup) a.spot[c++] = s;
            }
            if (!a.imp) totalTasks += PER;
            float ang = i * (float) Math.PI / 4F;
            a.x = BX + (float) Math.cos(ang) * 30F;
            a.y = BY + (float) Math.sin(ang) * 30F;
            a.killCd = 1500 + rnd.nextInt(900);
            for (int k = 0; k < N; k++) { a.seenTick[k] = -99999; a.seenRoom[k] = 0; }
            for (int[] w : a.with) java.util.Arrays.fill(w, -99999);
        }
        act[0].killCd = 600;
        java.util.Arrays.fill(chk, 0);
        hudT = 0;
        List<Integer> roles = new ArrayList<>(List.of(R_ENG, R_GRD, R_DET));
        java.util.Collections.shuffle(roles, new java.util.Random(rnd.nextLong()));
        List<Integer> crew = new ArrayList<>();
        for (int i = 1; i < N; i++) if (!act[i].imp) crew.add(i);
        java.util.Collections.shuffle(crew, new java.util.Random(rnd.nextLong()));
        if (!playerImp) setRole(act[0], roles.remove(0));          // a crew player always has a role
        for (int r : roles) if (!crew.isEmpty()) setRole(act[crew.remove(0)], r);
        List<Integer> ir = new ArrayList<>(List.of(R_KIL, R_SAB));
        java.util.Collections.shuffle(ir, new java.util.Random(rnd.nextLong()));
        for (Actor a : act) if (a.imp && !ir.isEmpty()) setRole(a, ir.remove(0));       // the two impostors have different roles
    }

    private void setRole(Actor a, int r) {
        a.role = r;
        a.uses = r == R_ENG ? 2 : (r == R_DET ? 1 : 0);
        a.shield = r == R_GRD;
    }

    private int killCdOf(Actor k) { return k.role == R_KIL ? 1000 : (k.role == R_SAB ? 2100 : KILL_CD); }

    private Actor botImp() {
        for (int i = 1; i < N; i++) if (act[i].imp && act[i].alive) return act[i];
        return null;
    }

    /** The killer waits longer for the next sabotage, the saboteur much less. */
    private static int sabDelay(Actor who) { return who == null ? 1500 : (who.role == R_SAB ? 500 : (who.role == R_KIL ? 2400 : 1500)); }

    private void msg(String s) { hudMsg = s; hudT = 200; }

    private int[] actsOf() { return playerImp ? IMP_ACTS : (act[0].role > 0 ? ROLE_ACTS : CREW_ACTS); }

    private Actor detTarget() {
        Actor p = act[0];
        if (!p.alive || p.role != R_DET || p.uses <= 0 || p.vented || phase != PH_PLAY) return null;
        Actor best = null;
        float bd = 28F;
        for (Actor a : act) {
            if (a == p || !a.alive || a.vented) continue;
            float d = dist(p.x, p.y, a.x, a.y);
            if (d < bd && los(p.x, p.y, a.x, a.y)) { bd = d; best = a; }
        }
        return best;
    }

    private void roleAction() {
        Actor p = act[0];
        if (!p.alive || playerImp) return;
        if (p.role == R_ENG) ventAction();
        else if (p.role == R_DET) {
            Actor t = detTarget();
            if (t == null) return;
            p.uses--;
            chk[t.id] = t.imp ? 2 : 1;
            msg(tr(t.imp ? "cutemod.hive.det.imp" : "cutemod.hive.det.clean", nm(t.id)));
            pling(1.4F);
        }
    }

    // ------------------------------------------------------------------ helpers

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private String nm(int id) { return tr("cutemod.hive.name." + pet[id]); }

    private static String rm(int r) { return tr("cutemod.hive.room." + Math.max(0, Math.min(ROOMS.length, r))); }

    private static int styleOf(int room) { return room >= 0 && room < RSTYLE.length ? RSTYLE[room] : 7; }

    private static float dist(float x0, float y0, float x1, float y1) {
        float dx = x1 - x0, dy = y1 - y0;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private boolean solidTile(int tx, int ty) { return tx < 0 || ty < 0 || tx >= MW || ty >= MH || solid[ty][tx]; }

    private boolean solidAt(float x, float y) { return solidTile((int) Math.floor(x / T), (int) Math.floor(y / T)); }

    private boolean free(float x, float y) {
        return !solidAt(x - 3, y - 3) && !solidAt(x + 3, y - 3) && !solidAt(x - 3, y + 3) && !solidAt(x + 3, y + 3);
    }

    private int roomTile(int tx, int ty) {
        return tx < 0 || ty < 0 || tx >= MW || ty >= MH ? ROOMS.length : roomOf[ty][tx];
    }

    private int roomAt(float x, float y) { return roomTile((int) (x / T), (int) (y / T)); }

    /** True if nothing solid is between the two points (the tile of the target itself does not count). */
    private boolean los(float x0, float y0, float x1, float y1) {
        int tx = (int) (x1 / T), ty = (int) (y1 / T);
        float dx = x1 - x0, dy = y1 - y0;
        int n = (int) (Math.sqrt(dx * dx + dy * dy) / 3F) + 1;
        for (int i = 1; i < n; i++) {
            float f = i / (float) n;
            int cx = (int) ((x0 + dx * f) / T), cy = (int) ((y0 + dy * f) / T);
            if (cx == tx && cy == ty) return true;
            if (solidTile(cx, cy)) return false;
        }
        return true;
    }

    private boolean near(Actor a, float x, float y, float r) { return dist(a.x, a.y, x, y) < r; }

    private static int clampi(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private int[] bfs(int sx, int sy, int gx, int gy) {
        sx = clampi(sx, 0, MW - 1); sy = clampi(sy, 0, MH - 1); gx = clampi(gx, 0, MW - 1); gy = clampi(gy, 0, MH - 1);
        int[] prev = bfsPrev, q = bfsQ, mark = bfsMark;
        int gen = ++bfsGen;
        int h = 0, t = 0, s = sy * MW + sx, goal = gy * MW + gx;
        prev[s] = -1; mark[s] = gen; q[t++] = s;
        int[] ddx = {1, -1, 0, 0}, ddy = {0, 0, 1, -1};
        while (h < t) {
            int c = q[h++];
            if (c == goal) break;
            int cx = c % MW, cy = c / MW;
            for (int k = 0; k < 4; k++) {
                int nx = cx + ddx[k], ny = cy + ddy[k];
                if (nx < 0 || ny < 0 || nx >= MW || ny >= MH || solid[ny][nx]) continue;
                int n = ny * MW + nx;
                if (mark[n] == gen) continue;
                mark[n] = gen; prev[n] = c; q[t++] = n;
            }
        }
        if (mark[goal] != gen) return new int[0];
        int len = 0;
        for (int c = goal; c != -1; c = prev[c]) len++;
        int[] out = new int[len];
        int i = len - 1;
        for (int c = goal; c != -1; c = prev[c]) out[i--] = c;
        return out;
    }

    private void setPath(Actor a, int tx, int ty) {
        a.path = bfs((int) (a.x / T), (int) (a.y / T), tx, ty);
        a.pp = a.path.length > 1 ? 1 : 0;
    }

    private boolean walk(Actor a, float sp) {
        if (a.pp >= a.path.length) return false;
        int t = a.path[a.pp];
        float tx = (t % MW) * T + T / 2F, ty = (t / MW) * T + T / 2F;
        float dx = tx - a.x, dy = ty - a.y, d = dist(0, 0, dx, dy);
        if (d <= sp) { a.x = tx; a.y = ty; a.pp++; return a.pp < a.path.length; }
        a.x += dx / d * sp;
        a.y += dy / d * sp;
        if (Math.abs(dx) > 0.4F) a.face = dx > 0 ? 1 : -1;
        return true;
    }

    private int nearVent(float x, float y, float r) {
        int best = -1;
        float bd = r;
        for (int i = 0; i < VX.length; i++) {
            float d = dist(x, y, VX[i] * T + 4, VY[i] * T + 4);
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }

    private int nextVent(int vi, int dir) {
        int n = VX.length;
        for (int k = 1; k <= n; k++) {
            int i = ((vi + dir * k) % n + n) % n;
            if (VG[i] == VG[vi] && i != vi) return i;
        }
        return vi;
    }

    /** How far a pet sees other pets: the lights going out blinds the crew (and only the crew). */
    private int sightOf(Actor w) { return w.imp ? SIGHT : (lightsOut ? 26 : SIGHT); }

    private int vision() {
        Actor p = act[0];
        if (!p.alive) return 999;
        if (p.imp) return 90;
        return lightsOut ? 38 : 90;
    }

    // ------------------------------------------------------------------ play

    @Override
    public void tick() {
        if (phase == PH_ROLE) { if (--phaseT <= 0) phase = PH_PLAY; return; }
        if (phase == PH_END) { if (--phaseT <= 0) over = true; return; }
        if (phase == PH_MEET) { meetTick(); return; }
        playTick();
    }

    private void playTick() {
        ticks++;
        Actor p = act[0];
        if (killFlash > 0) killFlash--;
        if (hudT > 0) hudT--;
        if (taskOpen) updateTask(); else if (!camOpen) movePlayer();
        if (boostT > 0) boostT--;
        if (ticks % 900 == 0 && candies.size() < 6) spawnCandy();
        if (p.alive && !p.vented) {
            for (int i = candies.size() - 1; i >= 0; i--) {
                float[] c = candies.get(i);
                if (dist(p.x, p.y, c[0], c[1]) < 7F) {
                    candies.remove(i);
                    boostT = 480;
                    if (p.imp) p.killCd = Math.max(0, p.killCd - 300);
                    pling(1.5F);
                    msg(tr(p.imp ? "cutemod.hive.candy.imp" : "cutemod.hive.candy"));
                }
            }
        }
        // hold E at a reactor console
        boolean holding = false;
        if (reactorOn && !p.imp && !p.vented && !taskOpen && !camOpen && down(69)) {
            for (int i = 0; i < 2; i++) {
                if (!consoleOk[i] && near(p, CX[i] * T + 4, CY[i] * T + 4, 16)) {
                    holding = true;
                    if (++hold >= 120) { hold = 0; completeFix(i + 1); }
                }
            }
        }
        if (!holding) hold = 0;
        for (int i = 1; i < N; i++) botTick(act[i]);
        if (p.killCd > 0) p.killCd--;
        if (ticks % 8 == 0) observe();
        if (!lightsOut && !reactorOn) {
            if (sabCd > 0) sabCd--;
            else if (ticks % 60 == 0 && rnd.nextInt(100) < 5 && botImpAlive()) trigger(rnd.nextInt(2), botImp());
        } else if (ticks % 300 == 0) assignFixers();
        if (reactorOn && --reactorT <= 0) { reactorOn = false; end(false); }
    }

    private boolean botImpAlive() {
        for (int i = 1; i < N; i++) if (act[i].imp && act[i].alive) return true;
        return false;
    }

    private void movePlayer() {
        Actor p = act[0];
        if (p.vented) return;
        int dx = 0, dy = 0;
        if (down(87) || down(KEY_UP)) dy--;
        if (down(83) || down(KEY_DOWN)) dy++;
        if (down(65) || down(KEY_LEFT)) dx--;
        if (down(68) || down(KEY_RIGHT)) dx++;
        if (dx == 0 && dy == 0) return;
        float sp = p.alive ? SPEED * (boostT > 0 ? 1.5F : 1F) : 1.3F;
        if (dx != 0 && dy != 0) sp *= 0.707F;
        if (dx != 0) p.face = dx;
        float nx = p.x + dx * sp;
        if (!p.alive || free(nx, p.y)) p.x = Math.max(4, Math.min(MW * T - 4, nx));
        float ny = p.y + dy * sp;
        if (!p.alive || free(p.x, ny)) p.y = Math.max(4, Math.min(MH * T - 4, ny));
    }

    /** What the bots see: who is where (for the talk at the meeting) and bodies. */
    private void observe() {
        for (Actor a : act) if (a.alive && !a.vented) a.hist[(ticks / 100) % 64] = roomAt(a.x, a.y);
        int[] seen = new int[N];
        for (int i = 1; i < N; i++) {
            Actor b = act[i];
            if (!b.alive || b.vented) continue;
            if (b.role == R_DET && b.uses > 0 && !b.imp && rnd.nextInt(1000) < 15) {      // a detective bot checks somebody who is close
                Actor near = null;
                float nd = 28F;
                for (Actor o : act) {
                    float d = dist(b.x, b.y, o.x, o.y);
                    if (o != b && o.alive && !o.vented && d < nd && los(b.x, b.y, o.x, o.y)) { nd = d; near = o; }
                }
                if (near != null) { b.uses = 0; b.detT = near.id; }
            }
            int sr = sightOf(b), ns = 0;
            for (Actor o : act) {
                if (o == b || !o.alive || o.vented) continue;
                if (dist(b.x, b.y, o.x, o.y) < sr && los(b.x, b.y, o.x, o.y)) {
                    b.seenTick[o.id] = ticks;
                    b.seenRoom[o.id] = roomAt(o.x, o.y);
                    b.together[o.id] = Math.min(3000, b.together[o.id] + 8);
                    seen[ns++] = o.id;
                    if (!b.imp && working(o)) b.seenWork[o.id] = true;
                } else b.together[o.id] = Math.max(0, b.together[o.id] - 4);
            }
            for (int x = 0; x < ns; x++) for (int y = x + 1; y < ns; y++) { b.with[seen[x]][seen[y]] = ticks; b.with[seen[y]][seen[x]] = ticks; }
            if (b.imp || b.bodyT >= 0 || b.mode == 6) continue;       // impostors never report what they find
            for (int k = 0; k < bodies.size(); k++) {
                Body d = bodies.get(k);
                if (!d.reported && dist(b.x, b.y, d.x, d.y) < sr && los(b.x, b.y, d.x, d.y)) {
                    b.bodyT = k; b.mode = 5; b.fixKind = -1;
                    setPath(b, (int) (d.x / T), (int) (d.y / T));
                    break;
                }
            }
        }
    }

    private void spawnCandy() {
        for (int n = 0; n < 80; n++) {
            int tx = 2 + rnd.nextInt(MW - 4), ty = 2 + rnd.nextInt(MH - 4);
            if (solid[ty][tx]) continue;
            float x = tx * T + 4, y = ty * T + 4;
            if (dist(x, y, BX, BY) < 30F) continue;
            boolean close = false;
            for (float[] c : candies) if (dist(x, y, c[0], c[1]) < 70F) close = true;
            if (close) continue;
            candies.add(new float[] {x, y});
            return;
        }
    }

    private int nextTask(Actor b) {
        for (int i = 0; i < PER; i++) if (!b.done[i]) return i;
        return -1;
    }

    private void botTick(Actor b) {
        if (!b.alive) {                     // a dead crewmate finishes its tasks slowly
            if (!b.imp && ++b.ghostT >= 1500) {
                b.ghostT = 0;
                for (int i = 0; i < PER; i++) if (!b.done[i]) { b.done[i] = true; doneTasks++; break; }
                checkWin();
            }
            return;
        }
        if (b.killCd > 0) b.killCd--;
        if (b.vented) { if (--b.ventT <= 0) ventExit(b); return; }
        if (b.imp && b.killCd <= 0 && calm(b) && ticks % 10 == b.id) tryHunt(b);
        if (!b.imp && !b.called && calm(b) && (b.witness >= 0 || b.ventSaw >= 0 || b.attacker >= 0)
                && !lightsOut && !reactorOn && ticks % 20 == b.id) { b.mode = 8; setPath(b, BX / T, BY / T + 2); }     // it knows who it is: to the emergency button
        switch (b.mode) {
            case 0 -> {
                int t = nextTask(b);
                int roll = rnd.nextInt(100);
                if (b.imp) {
                    if (b.killCd < 420 && roll < 45 && startStalk(b)) return;          // it follows a lonely crewmate until the chance comes
                    if (roll >= 85 && startBuddy(b)) return;                           // or walks with somebody, to be seen in company
                } else if (wary && roll < 30 && startBuddy(b)) return;                 // after a death the crew sticks together
                if (roll > 90 && startCams(b)) return;                                 // now and then it checks the cameras
                if (t >= 0) { b.taskI = t; setPath(b, TX[b.spot[t]], TY[b.spot[t]]); }
                else {
                    if (roll < 25 && startCams(b)) return;
                    if (roll < 45 && startBuddy(b)) return;
                    b.taskI = -1; int s = rnd.nextInt(SPOTS); setPath(b, TX[s], TY[s]);
                }
                b.mode = 1;
            }
            case 9 -> {                          // watching the cameras
                float cx = CSX * T + 4, cy = CSY * T + 4;
                if (dist(b.x, b.y, cx, cy) >= 12) {
                    if (!walk(b, BOT_SPEED) && dist(b.x, b.y, cx, cy) >= 12) b.mode = 0;
                    return;
                }
                if (b.timer <= 0) b.timer = 260 + rnd.nextInt(200);
                if (--b.timer <= 1) { b.timer = 0; b.mode = 0; return; }
                if (ticks % 8 == b.id) watchCams(b);
            }
            case 10 -> {                         // walking with a buddy
                Actor o = act[Math.max(0, b.buddy)];
                if (b.buddy < 0 || !o.alive || o.vented || --b.buddyT <= 0) { b.buddy = -1; b.mode = 0; return; }
                if (ticks % 20 == b.id) repath(b, o);
                if (dist(b.x, b.y, o.x, o.y) > 26) walk(b, BOT_SPEED);
            }
            case 11 -> {                         // an impostor stalking a crewmate
                Actor o = act[Math.max(0, b.stalk)];
                if (b.stalk < 0 || !o.alive || o.imp || --b.stalkT <= 0) { b.stalk = -1; b.mode = 0; return; }
                if (ticks % 20 == b.id) repath(b, o);
                if (dist(b.x, b.y, o.x, o.y) > 40) walk(b, BOT_SPEED);
            }
            case 1 -> {
                if (!walk(b, BOT_SPEED)) { b.mode = 2; b.timer = b.taskI >= 0 ? 260 + rnd.nextInt(260) : 90 + rnd.nextInt(150); if (b.role == R_ENG && b.taskI >= 0) b.timer = b.timer * 6 / 10; }
            }
            case 2 -> {
                if (--b.timer <= 0) {
                    if (b.taskI >= 0) { b.done[b.taskI] = true; if (!b.imp) { doneTasks++; checkWin(); } }
                    b.mode = 0;
                }
            }
            case 3 -> {
                if (fixDone(b.fixKind)) { b.mode = 0; b.fixKind = -1; }
                else if (!walk(b, BOT_SPEED + 0.1F)) { b.mode = 4; b.timer = 150; }
            }
            case 4 -> {
                if (fixDone(b.fixKind)) { b.mode = 0; b.fixKind = -1; }
                else if (--b.timer <= 0) { int k = b.fixKind; b.mode = 0; b.fixKind = -1; completeFix(k); }
            }
            case 5 -> {
                if (b.bodyT < 0 || b.bodyT >= bodies.size() || bodies.get(b.bodyT).reported) { b.bodyT = -1; b.mode = 0; }
                else {
                    Body d = bodies.get(b.bodyT);
                    if (dist(b.x, b.y, d.x, d.y) < 16) startMeeting(b.id, b.bodyT);
                    else if (!walk(b, BOT_SPEED + 0.15F)) setPath(b, (int) (d.x / T), (int) (d.y / T));
                }
            }
            case 6 -> huntTick(b);
            case 8 -> {
                if (lightsOut || reactorOn) b.mode = 0;
                else if (dist(b.x, b.y, BX, BY) < 24 || !walk(b, BOT_SPEED + 0.15F)) { b.called = true; b.mode = 0; startMeeting(b.id, -1); }
            }
            default -> b.mode = 0;
        }
    }

    /** The modes in which a bot is just going about its business (it may start a hunt or run to the button). */
    private static boolean calm(Actor b) {
        int m = b.mode;
        return m == 0 || m == 1 || m == 2 || m == 9 || m == 10 || m == 11;
    }

    /** A new path to a moving target, but only when the target has moved to another tile (or the bot has run out of path). */
    private void repath(Actor b, Actor o) {
        int g = (int) (o.y / T) * MW + (int) (o.x / T);
        if (g == b.goal && b.pp < b.path.length) return;
        b.goal = g;
        setPath(b, (int) (o.x / T), (int) (o.y / T));
    }

    private boolean startBuddy(Actor b) {
        List<Actor> c = new ArrayList<>();
        for (Actor o : act) if (o != b && o.alive && !o.vented && !(b.imp && o.imp)) c.add(o);
        if (c.isEmpty()) return false;
        c.sort((p, q) -> Float.compare(dist(b.x, b.y, p.x, p.y), dist(b.x, b.y, q.x, q.y)));
        Actor o = c.get(rnd.nextInt(Math.min(3, c.size())));
        b.buddy = o.id; b.buddyT = 350 + rnd.nextInt(300); b.mode = 10;
        setPath(b, (int) (o.x / T), (int) (o.y / T));
        return true;
    }

    /** An impostor picks the crewmate with the fewest friends around and follows it. */
    private boolean startStalk(Actor b) {
        Actor best = null;
        float bd = 1e9F;
        for (Actor o : act) {
            if (o.imp || !o.alive || o.vented) continue;
            float d = dist(b.x, b.y, o.x, o.y);
            int crowd = 0;
            for (Actor w : act) if (w != o && w != b && w.alive && dist(w.x, w.y, o.x, o.y) < SIGHT) crowd++;
            d += crowd * 60F;
            if (d < bd) { bd = d; best = o; }
        }
        if (best == null) return false;
        b.stalk = best.id; b.stalkT = 400 + rnd.nextInt(300); b.mode = 11;
        setPath(b, (int) (best.x / T), (int) (best.y / T));
        return true;
    }

    private boolean startCams(Actor b) {
        b.mode = 9; b.timer = 0;
        setPath(b, CSX, CSY);
        return true;
    }

    /** What a bot sees on the four cameras: a body (the crew reports it) and who walks through the halls. */
    private void watchCams(Actor b) {
        if (!b.imp) {
            for (int k = 0; k < bodies.size(); k++) {
                Body d = bodies.get(k);
                if (d.reported) continue;
                for (int i = 0; i < 4; i++) {
                    float dx = d.x - (CMX[i] * T + 4), dy = d.y - (CMY[i] * T + 4);
                    if (Math.abs(dx) <= 34 && dy >= -9 && dy <= 14) {
                        b.bodyT = k; b.mode = 5; b.fixKind = -1;
                        setPath(b, (int) (d.x / T), (int) (d.y / T));
                        return;
                    }
                }
            }
        }
        for (Actor o : act) {
            if (o == b || !o.alive || o.vented) continue;
            for (int i = 0; i < 4; i++) {
                float dx = o.x - (CMX[i] * T + 4), dy = o.y - (CMY[i] * T + 4);
                if (Math.abs(dx) <= 34 && dy >= -9 && dy <= 14) {
                    b.seenTick[o.id] = ticks; b.seenRoom[o.id] = roomAt(o.x, o.y);
                    b.camWho = o.id; b.camRoom = roomAt(o.x, o.y); b.camTick = ticks;
                    break;
                }
            }
        }
    }

    // ------------------------------------------------------------------ killing

    private int witnesses(Actor killer, Actor victim) {
        int n = 0;
        for (Actor w : act) {
            if (w == killer || w == victim || !w.alive || w.imp || w.vented) continue;
            float r = lightsOut ? 26F : SIGHT + 10F;
            if (dist(w.x, w.y, killer.x, killer.y) < r && los(w.x, w.y, killer.x, killer.y)) n++;
        }
        return n;
    }

    private void tryHunt(Actor b) {
        Actor best = null;
        float bd = 1e9F;
        for (Actor v : act) {
            if (v.imp || !v.alive || v.vented) continue;
            float d = dist(b.x, b.y, v.x, v.y);
            if (d < 72 && d < bd && los(b.x, b.y, v.x, v.y)) { best = v; bd = d; }
        }
        if (best == null) return;
        int wit = witnesses(b, best);
        if (wit > 0 && wit <= 2 && !lightsOut && !reactorOn && sabCd <= 0 && rnd.nextInt(100) < 20) { trigger(0, b); wit = witnesses(b, best); }   // darkness blinds the witnesses
        if (wit > 0) return;
        if (rnd.nextInt(100) < 35) { b.hunt = best.id; b.huntT = 360; b.mode = 6; }
    }

    private void huntTick(Actor b) {
        Actor v = act[Math.max(0, b.hunt)];
        if (b.hunt < 0 || !v.alive || v.imp || --b.huntT <= 0) { b.mode = 0; b.hunt = -1; return; }
        if (ticks % 15 == 0) repath(b, v);
        if (dist(b.x, b.y, v.x, v.y) < 11) {
            if (witnesses(b, v) == 0) doKill(b, v);
            else { b.mode = 0; b.hunt = -1; b.killCd = 300; }
            return;
        }
        walk(b, BOT_SPEED + 0.1F);
    }

    private void doKill(Actor k, Actor v) {
        if (v.role == R_GRD && v.shield && !v.imp) {                // the guardian's shield takes the blow
            v.shield = false; v.attacker = k.id;
            k.killCd = k.id == 0 ? 600 : 900;
            if (k.id != 0) { k.hunt = -1; k.mode = 0; k.path = new int[0]; k.pp = 0; }
            sound(SoundEvents.SHIELD_BLOCK, 0.8F, 1.0F);
            if (k.id == 0) msg(tr("cutemod.hive.shield.imp", nm(v.id)));
            if (v.id == 0) msg(tr("cutemod.hive.shield.me"));
            return;
        }
        Body d = new Body();
        d.victim = v.id; d.killer = k.id; d.x = v.x; d.y = v.y; d.tick = ticks; d.room = roomAt(v.x, v.y);
        bodies.add(d);
        v.alive = false; v.vented = false;
        for (Actor w : act) {
            if (w == k || w == v || !w.alive || w.imp || w.vented) continue;
            if (dist(w.x, w.y, v.x, v.y) < (lightsOut ? 26F : SIGHT) && los(w.x, w.y, v.x, v.y)) { w.witness = k.id; w.witnessV = v.id; }
        }
        k.x = v.x; k.y = v.y; k.path = new int[0]; k.pp = 0;
        k.killCd = k.id == 0 ? killCdOf(k) : (k.role == R_KIL ? 1300 + rnd.nextInt(500) : (k.role == R_SAB ? 2600 + rnd.nextInt(900) : 2000 + rnd.nextInt(900)));
        sound(SoundEvents.PLAYER_HURT, 0.8F, 0.6F);
        if (k.id == 0) kills++;
        else {
            k.hunt = -1; k.mode = 0;
            int r = rnd.nextInt(100);
            if (r < 30) tryBotVent(k);
            else if (r < 50 && witnesses(k, v) == 0) { k.bodyT = bodies.size() - 1; k.mode = 5; }   // reports its own kill
            else if (r < 85) flee(k, d.room);
        }
        if (v.id == 0) { killFlash = 90; taskOpen = false; mapOpen = false; camOpen = false; }
        checkWin();
    }

    /** After a kill: away from the body, to a task in another room, as if nothing happened. */
    private void flee(Actor k, int room) {
        int sp = rnd.nextInt(SPOTS);
        for (int tries = 0; tries < 8 && roomTile(TX[sp], TY[sp]) == room; tries++) sp = rnd.nextInt(SPOTS);
        k.taskI = -1;
        setPath(k, TX[sp], TY[sp]);
        k.mode = 1;
    }

    private void tryBotVent(Actor b) {
        int vi = nearVent(b.x, b.y, 32);
        if (vi < 0) return;
        ventWitness(b.x, b.y, b.id);
        b.vented = true; b.ventAt = vi; b.ventT = 100 + rnd.nextInt(120);
        b.x = VX[vi] * T + 4; b.y = VY[vi] * T + 4;
    }

    private void ventExit(Actor b) {
        int vi = nextVent(b.ventAt, 1);
        b.vented = false; b.mode = 0; b.ventAt = -1;
        b.x = VX[vi] * T + 4; b.y = VY[vi] * T + 4;
        ventWitness(b.x, b.y, b.id);
    }

    private void ventWitness(float x, float y, int id) {
        if (act[id].role == R_ENG && !act[id].imp) return;          // the service hatches are not suspicious
        for (Actor w : act) {
            if (w.id == id || !w.alive || w.imp || w.vented || w.id == 0) continue;
            if (dist(w.x, w.y, x, y) < (lightsOut ? 26F : SIGHT) && los(w.x, w.y, x, y)) w.ventSaw = id;
        }
    }

    // ------------------------------------------------------------------ sabotage

    private void trigger(int kind, Actor who) {
        if (kind == 0) lightsOut = true;
        else { reactorOn = true; reactorT = 2400; consoleOk[0] = false; consoleOk[1] = false; }
        sabCd = sabDelay(who);
        assignFixers();
        sound(SoundEvents.BELL_BLOCK, 0.6F, 0.7F);
    }

    private void assignFixers() {
        if (lightsOut) assignNear(LX, LY, 0);
        if (reactorOn) { assignNear(CX[0], CY[0], 1); assignNear(CX[1], CY[1], 2); }
    }

    private void assignNear(int tx, int ty, int kind) {
        int have = 0;
        int want = kind == 0 ? 2 : 1;
        for (int i = 1; i < N; i++) if (act[i].alive && act[i].fixKind == kind) have++;
        while (have < want) {
            Actor best = null;
            float bd = 1e9F;
            for (int i = 1; i < N; i++) {
                Actor b = act[i];
                if (!b.alive || b.imp || b.vented || b.fixKind >= 0 || b.mode == 5) continue;
                float d = dist(b.x, b.y, tx * T + 4, ty * T + 4);
                if (d < bd) { bd = d; best = b; }
            }
            if (best == null) return;
            best.fixKind = kind; best.mode = 3;
            setPath(best, tx, ty);
            have++;
        }
    }

    private boolean fixDone(int kind) {
        if (kind == 0) return !lightsOut;
        return !reactorOn || consoleOk[kind - 1];
    }

    private void completeFix(int kind) {
        if (kind == 0) lightsOut = false;
        else {
            consoleOk[kind - 1] = true;
            if (consoleOk[0] && consoleOk[1]) reactorOn = false;
        }
        pling(1.3F);
    }

    // ------------------------------------------------------------------ the player's actions

    @Override
    public boolean key(int k) {
        if (phase == PH_ROLE) { phaseT = 0; return true; }
        if (phase == PH_MEET) {
            if (k == KEY_UP) { scrollChat(1); return true; }
            if (k == KEY_DOWN) { scrollChat(-1); return true; }
            return false;
        }
        if (phase != PH_PLAY) return false;
        Actor p = act[0];
        if (mapOpen) { mapOpen = false; return true; }
        if (camOpen) { if (k == 69 || k == KEY_SPACE) camOpen = false; return true; }
        if (taskOpen) {
            if (tKind == K_FUEL && k == KEY_SPACE) pump();
            return true;
        }
        if (p.vented) {
            if (k == KEY_RIGHT) { hopVent(1); return true; }
            if (k == KEY_LEFT) { hopVent(-1); return true; }
            if (k == KEY_SPACE || k == 86) { doAction(A_VENT); return true; }
            return false;
        }
        if (k == 69) { doAction(A_USE); return true; }
        if (k == 82) { doAction(A_REPORT); return true; }
        if (k == 81) { doAction(A_KILL); return true; }
        if (k == 86) { doAction(A_VENT); return true; }
        if (k == 70) { doAction(A_ROLE); return true; }
        if (k == 77) { doAction(A_MAP); return true; }
        if (k == 49) { doAction(A_DARK); return true; }
        if (k == 50) { doAction(A_CORE); return true; }
        return false;
    }

    private void doAction(int a) {
        switch (a) {
            case A_USE -> use();
            case A_REPORT -> report();
            case A_KILL -> kill();
            case A_VENT -> ventAction();
            case A_DARK -> sabotage(0);
            case A_CORE -> sabotage(1);
            case A_ROLE -> roleAction();
            default -> mapOpen = !mapOpen;
        }
    }

    private void use() {
        Actor p = act[0];
        if (p.vented || (!p.alive && p.imp)) return;
        if (lightsOut && !p.imp && near(p, LX * T + 4, LY * T + 4, 16)) { startTask(K_KEYPAD, -1, true, false); return; }
        for (int i = 0; i < PER; i++) {
            if (p.done[i]) continue;
            int s = p.spot[i];
            if (near(p, TX[s] * T + 4, TY[s] * T + 4, 14)) { startTask(KIND[s], i, false, p.imp); return; }
        }
        if (p.alive && near(p, CSX * T + 4, CSY * T + 4, 14)) { camOpen = true; beep(); return; }
        if (p.alive && !buttonUsed && !lightsOut && !reactorOn && near(p, BX, BY, 26)) { buttonUsed = true; startMeeting(0, -1); }
    }

    private void report() {
        Actor p = act[0];
        if (!p.alive || p.vented) return;
        for (int i = 0; i < bodies.size(); i++) {
            Body d = bodies.get(i);
            if (!d.reported && dist(p.x, p.y, d.x, d.y) < 24 && los(p.x, p.y, d.x, d.y)) { startMeeting(0, i); return; }
        }
    }

    private Actor killTarget() {
        Actor p = act[0];
        if (!playerImp || !p.alive || p.vented || phase != PH_PLAY) return null;
        Actor best = null;
        float bd = p.role == R_KIL ? 30F : 22F;
        for (Actor a : act) {
            if (a.imp || !a.alive || a.vented) continue;
            float d = dist(p.x, p.y, a.x, a.y);
            if (d < bd && los(p.x, p.y, a.x, a.y)) { bd = d; best = a; }
        }
        return best;
    }

    private void kill() {
        Actor p = act[0];
        if (!playerImp || p.killCd > 0) return;
        Actor v = killTarget();
        if (v != null) doKill(p, v);
    }

    private void ventAction() {
        Actor p = act[0];
        if (!(playerImp || p.role == R_ENG) || !p.alive) return;
        if (!p.vented) {
            int vi = nearVent(p.x, p.y, 14);
            if (vi < 0) return;
            if (!playerImp) { if (p.uses <= 0) return; p.uses--; }
            ventWitness(p.x, p.y, 0);
            p.vented = true; p.ventAt = vi;
            p.x = VX[vi] * T + 4; p.y = VY[vi] * T + 4;
            sound(SoundEvents.ENDERMAN_TELEPORT, 1.2F, 0.5F);
        } else {
            p.vented = false;
            ventWitness(p.x, p.y, 0);
            sound(SoundEvents.ENDERMAN_TELEPORT, 1.4F, 0.5F);
        }
    }

    private void hopVent(int dir) {
        Actor p = act[0];
        p.ventAt = nextVent(p.ventAt, dir);
        p.x = VX[p.ventAt] * T + 4; p.y = VY[p.ventAt] * T + 4;
        beep();
    }

    private void sabotage(int kind) {
        if (!playerImp || sabCd > 0 || lightsOut || reactorOn || phase != PH_PLAY) return;
        trigger(kind, act[0]);
    }

    // ------------------------------------------------------------------ win

    private void checkWin() {
        if (phase == PH_END) return;
        int ac = 0, ai = 0;
        for (Actor a : act) if (a.alive) { if (a.imp) ai++; else ac++; }
        if (ai == 0) end(true);
        else if (ai >= ac) end(false);
        else if (doneTasks >= totalTasks) end(true);
    }

    private void end(boolean crewWins) {
        if (phase == PH_END) return;
        phase = PH_END; phaseT = 150; crewWon = crewWins; won = crewWins != playerImp;
        taskOpen = false; mapOpen = false; camOpen = false;
        int mine = 0;
        for (int i = 0; i < PER; i++) if (act[0].done[i]) mine++;
        score = playerImp ? kills * 20 : mine * 10;
        if (won) score += 60;
        if (won) sound(SoundEvents.PLAYER_LEVELUP, 1.0F, 0.6F); else sound(SoundEvents.VILLAGER_NO, 0.8F, 0.6F);
    }

    // ------------------------------------------------------------------ tasks

    private void startTask(int kind, int idx, boolean fix, boolean fake) {
        taskOpen = true; tKind = kind; tIdx = idx; tFix = fix; tFake = fake; tDone = 0;
        switch (kind) {
            case K_WIRES -> {
                int[] o = {0, 1, 2, 3};
                for (int i = 3; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = o[i]; o[i] = o[j]; o[j] = t; }
                for (int i = 0; i < 4; i++) { wr[i] = o[i]; wc[i] = -1; }
                wsel = -1;
            }
            case K_UPLOAD -> { upT = 0; upOn = false; upStall = false; upBr = 0; }
            case K_FUEL -> { fuel = 0; fuelHeat = 0; fuelLock = 0; }
            case K_KEYPAD -> { knext = 0; shuffleKeys(); }
            case K_BUGS -> {
                for (int i = 0; i < 8; i++) {
                    bx[i] = 40 + rnd.nextInt(140); by[i] = 46 + rnd.nextInt(72);
                    bvx[i] = (rnd.nextBoolean() ? 1 : -1) * (0.5F + rnd.nextFloat() * 0.7F);
                    bvy[i] = (rnd.nextBoolean() ? 1 : -1) * (0.4F + rnd.nextFloat() * 0.6F);
                    bdead[i] = false;
                }
            }
            case K_SIMON -> {
                for (int i = 0; i < 5; i++) sq[i] = rnd.nextInt(4);
                sqRound = 0; sqLen = 3;
                sqIn = 0; sqT = -24; sqShow = true; sqFl = -1; sqFlT = 0;
            }
            case K_SWITCH -> {                                         // pressing a switch flips its neighbours too: made by pressing from the goal, so it can always be solved
                for (int i = 0; i < 6; i++) { swT[i] = rnd.nextBoolean(); swS[i] = swT[i]; }
                int presses = 3 + rnd.nextInt(2);
                boolean[] used = new boolean[6];
                for (int n = 0; n < presses; ) { int i = rnd.nextInt(6); if (!used[i]) { used[i] = true; n++; flipSwitch(i); } }
            }
            case K_SORT -> { sortC = rnd.nextInt(3); sortN = 0; sortMax = 120; sortT = sortMax; }
            case K_PAIRS -> {
                int[] v = {0, 0, 1, 1, 2, 2, 3, 3};
                for (int i = 7; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = v[i]; v[i] = v[j]; v[j] = t; }
                for (int i = 0; i < 8; i++) { pcV[i] = v[i]; pcUp[i] = false; pcOk[i] = false; }
                pcA = -1; pcWait = 0; pcDone = 0;
            }
            default -> { cm = 0; cv = 1.9F; cz = 20 + rnd.nextInt(100); chit = 0; czw = 26; }
        }
    }

    /** The keys of the keypad go to new places (every time a key is pressed right). */
    private void shuffleKeys() {
        int[] sl = {0, 1, 2, 3, 4, 5};
        for (int i = 5; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = sl[i]; sl[i] = sl[j]; sl[j] = t; }
        for (int i = 0; i < 6; i++) { kx[i] = 44 + (sl[i] % 3) * 56; ky[i] = 54 + (sl[i] / 3) * 40; }
    }

    private void flipSwitch(int i) {
        for (int k = Math.max(0, i - 1); k <= Math.min(5, i + 1); k++) swS[k] = !swS[k];
    }

    private void pump() {
        if (fuelLock > 0 || tDone > 0) return;
        fuel = Math.min(100F, fuel + 7F);
        fuelHeat += 10F;
        if (fuelHeat >= 100F) { fuelHeat = 100F; fuelLock = 80; fuel = Math.max(0F, fuel - 14F); sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F); }
        else beep();
        if (fuel >= 100F) finishTask();
    }

    /** The tasks that others can see being done: the doer is cleared in the eyes of everybody who watched. */
    private static boolean visualKind(int k) { return k == K_FUEL || k == K_BUGS || k == K_SORT; }

    private boolean working(Actor a) {
        if (a.id == 0) return a.alive && taskOpen && !tFake && !tFix && tDone == 0 && visualKind(tKind);
        return a.alive && !a.imp && !a.vented && a.mode == 2 && a.taskI >= 0 && visualKind(KIND[a.spot[a.taskI]]);
    }

    private void updateTask() {
        if (tDone > 0) { if (--tDone <= 0) closeTask(true); return; }
        switch (tKind) {
            case K_UPLOAD -> {
                if (upOn && !upStall) {
                    upT++;
                    if ((upT == 90 && upBr == 0) || (upT == 190 && upBr == 1)) { upStall = true; upBr++; sound(SoundEvents.VILLAGER_NO, 1.2F, 0.5F); }
                    if (upT >= 300) finishTask();
                }
            }
            case K_FUEL -> {
                fuel = Math.max(0F, fuel - 0.22F);
                fuelHeat = Math.max(0F, fuelHeat - 0.5F);
                if (fuelLock > 0 && --fuelLock == 0) fuelHeat = 30F;
                if (fuel >= 100F) finishTask();
            }
            case K_SORT -> {
                if (--sortT <= 0) {                                    // too slow: the sample is lost
                    sortN = Math.max(0, sortN - 1);
                    sortC = rnd.nextInt(3); sortMax = Math.max(60, 120 - sortN * 7); sortT = sortMax;
                    sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F);
                }
            }
            case K_BUGS -> {
                int dead = 0;
                for (int i = 0; i < 6; i++) if (bdead[i]) dead++;
                float f = 1F + 0.16F * dead;                           // the rest get faster
                for (int i = 0; i < 8; i++) {
                    if (bdead[i]) continue;
                    bx[i] += bvx[i] * f; by[i] += bvy[i] * f;
                    if (bx[i] < 30 || bx[i] > 190) bvx[i] = -bvx[i];
                    if (by[i] < 42 || by[i] > 120) bvy[i] = -bvy[i];
                    if (ticks % 40 == i && rnd.nextInt(100) < 30) { bvx[i] += (rnd.nextFloat() - 0.5F) * 0.4F; bvy[i] += (rnd.nextFloat() - 0.5F) * 0.4F; }
                }
            }
            case K_SIMON -> {
                if (sqFlT > 0) sqFlT--;
                if (sqShow) {
                    sqT++;
                    if (sqT >= 0 && sqT % 32 == 0) {
                        int st = sqT / 32;
                        if (st >= sqLen) { sqShow = false; sqIn = 0; }
                        else pling(0.8F + sq[st] * 0.25F);
                    }
                }
            }
            case K_PAIRS -> {
                if (pcWait > 0 && --pcWait == 0) {
                    for (int i = 0; i < 8; i++) if (!pcOk[i]) pcUp[i] = false;
                    pcA = -1;
                }
            }
            case K_CALIB -> { cm += cv; if (cm < 0 || cm > 160) { cv = -cv; cm = Math.max(0, Math.min(160, cm)); } }
            default -> { }
        }
    }

    private void finishTask() {
        tDone = 26;
        pling(1.4F);
    }

    private void closeTask(boolean finished) {
        taskOpen = false;
        if (!finished) return;
        Actor p = act[0];
        if (tFix) completeFix(0);
        else if (tIdx >= 0) {
            p.done[tIdx] = true;
            if (!tFake) { doneTasks++; checkWin(); }
        }
    }

    private boolean taskClick(int x, int y) {
        if (in(x, y, PX + PW - 15, PY + 2, 13, 13)) { closeTask(false); return true; }
        if (tDone > 0) return true;
        switch (tKind) {
            case K_WIRES -> {
                for (int i = 0; i < 4; i++) {
                    if (in(x, y, 20, 41 + i * 22, 18, 14) && wc[i] < 0) { wsel = i; beep(); return true; }
                }
                if (wsel >= 0) {
                    for (int j = 0; j < 4; j++) {
                        if (in(x, y, PX + PW - 28, 41 + j * 22, 18, 14)) {
                            if (wr[j] == wsel) {
                                wc[wsel] = j;
                                pling(1.0F + wsel * 0.2F);
                                if (wc[0] >= 0 && wc[1] >= 0 && wc[2] >= 0 && wc[3] >= 0) finishTask();
                            } else sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F);
                            wsel = -1;
                            return true;
                        }
                    }
                }
            }
            case K_UPLOAD -> { if ((!upOn || upStall) && in(x, y, 80, 62, 60, 20)) { upOn = true; upStall = false; beep(); } }
            case K_FUEL -> pump();
            case K_KEYPAD -> {
                for (int i = 0; i < 6; i++) {
                    if (in(x, y, kx[i] - 12, ky[i] - 10, 24, 20)) {
                        if (i == knext) { knext++; pling(1.0F + i * 0.15F); if (knext >= 6) finishTask(); else shuffleKeys(); }
                        else { knext = 0; sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F); shuffleKeys(); }
                        return true;
                    }
                }
            }
            case K_BUGS -> {
                for (int i = 6; i < 8; i++) {                          // a firefly: leave it alone, or a bug comes back to life
                    if (dist(x, y, bx[i], by[i]) < 8) {
                        sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F);
                        for (int k = 0; k < 6; k++) if (bdead[k]) { bdead[k] = false; bx[k] = bx[i]; by[k] = by[i]; break; }
                        return true;
                    }
                }
                boolean all = true;
                for (int i = 0; i < 6; i++) {
                    if (!bdead[i] && dist(x, y, bx[i], by[i]) < 8) { bdead[i] = true; sound(SoundEvents.SLIME_SQUISH, 1.4F, 0.5F); }
                    if (!bdead[i]) all = false;
                }
                if (all) finishTask();
            }
            case K_SIMON -> {
                if (sqShow) return true;
                for (int i = 0; i < 4; i++) {
                    if (in(x, y, 60 + (i % 2) * 52, 40 + (i / 2) * 38, 48, 30)) {
                        sqFl = i; sqFlT = 8;
                        pling(0.8F + i * 0.25F);
                        if (i == sq[sqIn]) {
                            if (++sqIn >= sqLen) {
                                if (++sqRound >= 3) finishTask();
                                else { sqLen = 3 + sqRound; sqShow = true; sqT = -30; sqIn = 0; }     // the next round: one more note
                            }
                        } else { sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F); sqShow = true; sqT = -24; sqIn = 0; }
                        return true;
                    }
                }
            }
            case K_SWITCH -> {
                for (int i = 0; i < 6; i++) {
                    if (in(x, y, 28 + i * 28, 62, 20, 38)) {
                        flipSwitch(i); beep();
                        boolean all = true;
                        for (int k = 0; k < 6; k++) if (swS[k] != swT[k]) all = false;
                        if (all) finishTask();
                        return true;
                    }
                }
            }
            case K_SORT -> {
                for (int i = 0; i < 3; i++) {
                    if (in(x, y, 30 + i * 56, 94, 48, 24)) {
                        if (i == sortC) {
                            sortN++; pling(1.0F + sortN * 0.08F); sortC = rnd.nextInt(3);
                            sortMax = Math.max(60, 120 - sortN * 7); sortT = sortMax;
                            if (sortN >= 8) finishTask();
                        } else { sortN = Math.max(0, sortN - 1); sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F); }
                        return true;
                    }
                }
            }
            case K_PAIRS -> {
                if (pcWait > 0) return true;
                for (int i = 0; i < 8; i++) {
                    if (!pcUp[i] && in(x, y, 36 + (i % 4) * 38, 42 + (i / 4) * 40, 34, 34)) {
                        pcUp[i] = true; beep();
                        if (pcA < 0) pcA = i;
                        else if (pcV[pcA] == pcV[i]) {
                            pcOk[pcA] = true; pcOk[i] = true; pcA = -1; pling(1.3F);
                            if (++pcDone >= 4) finishTask();
                        } else pcWait = 26;
                        return true;
                    }
                }
            }
            default -> {
                if (cm >= cz && cm <= cz + czw) {
                    chit++;
                    pling(1.0F + chit * 0.2F);
                    czw = 26 - chit * 3;                               // the zone gets narrower and the marker faster
                    cv = (cv > 0 ? 1 : -1) * (1.9F + chit * 0.35F);
                    cz = 10 + rnd.nextInt(130 - czw);
                    if (chit >= 4) finishTask();
                } else { chit = Math.max(0, chit - 1); sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F); }
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ meetings

    private void startMeeting(int by, int body) {
        for (Actor a : act) {
            a.lastRoom = roomAt(a.x, a.y);
            a.vented = false; a.mode = 0; a.bodyT = -1; a.hunt = -1; a.fixKind = -1; a.path = new int[0]; a.pp = 0;
            a.buddy = -1; a.stalk = -1;
        }
        phase = PH_MEET; mstate = M_INTRO; mt = 0; caller = by; bodyIdx = body;
        taskOpen = false; mapOpen = false; camOpen = false; hold = 0;
        sel = -1; pVote = -2; pActs = 0; shown = 0; lineT = 30; ejected = -1; insertAt = -1; chatOff = 0;
        evi = false; speakT = 0; speakW = -1; myRxLine = -1;
        java.util.Arrays.fill(rxT, 0);
        java.util.Arrays.fill(asked, false);
        java.util.Arrays.fill(pub, 0);
        pressed = false;
        java.util.Arrays.fill(pairWish, -1);
        if (body >= 0) wary = true;
        buildLines();
        for (Body d : bodies) d.reported = true;
        sound(SoundEvents.BELL_BLOCK, 1.0F, 0.8F);
    }

    private void say(int who, String key, int variants, Object... args) {
        Line l = new Line(who, Component.translatable(key + "." + rnd.nextInt(variants), args), key.substring(key.lastIndexOf('.') + 1));
        if (insertAt >= 0) lines.add(Math.min(insertAt++, lines.size()), l);      // the player's talk: the answers come right away
        else lines.add(l);
    }

    private void buildLines() {
        lines.clear();
        contras = 0;
        Body d = bodyIdx >= 0 ? bodies.get(bodyIdx) : null;
        if (d != null) say(caller, "cutemod.hive.m.found", 3, nm(d.victim), rm(d.room));
        else say(caller, "cutemod.hive.m.button", 3);
        if (caller > 0 && act[caller].alive) {                    // whoever called the meeting says why first
            Actor c = act[caller];
            if (c.imp || c.witness >= 0 || c.ventSaw >= 0 || (d != null && suspectFor(c, d) >= 0)) statement(c, d);
        }
        List<Actor> order = new ArrayList<>();
        for (Actor a : act) if (a.alive && a.id != 0 && a.id != caller) order.add(a);
        java.util.Collections.shuffle(order, new java.util.Random(rnd.nextLong()));
        int cnt = 0;
        for (Actor b : order) {
            if (cnt >= 6) break;
            statement(b, d);
            cnt++;
        }
        debate();
        crossTalk();
    }

    /** One bot says what it knows. Crew tells the truth, an impostor lies (and picks a victim of the lie that nobody can easily clear). */
    private void statement(Actor b, Body d) {
        if (!b.imp) {
            if (b.attacker >= 0) {
                say(b.id, "cutemod.hive.m.shield", 3, nm(b.attacker));
                accuse(b.id, b.attacker, 150);
                return;
            }
            if (b.witness >= 0 && b.witnessV >= 0) {
                say(b.id, "cutemod.hive.m.kill", 3, nm(b.witness), nm(b.witnessV));
                accuse(b.id, b.witness, 150);
                return;
            }
            if (b.ventSaw >= 0) {
                say(b.id, "cutemod.hive.m.vent", 3, nm(b.ventSaw));
                accuse(b.id, b.ventSaw, 150);
                return;
            }
            if (b.role == R_DET && b.detT >= 0 && act[b.detT].alive) {         // the detective speaks of what it found out
                if (act[b.detT].imp) {
                    say(b.id, "cutemod.hive.m.proof", 3, nm(b.detT));
                    accuse(b.id, b.detT, 150);
                } else {
                    say(b.id, "cutemod.hive.m.clean", 3, nm(b.detT));
                    for (int i = 1; i < N; i++) act[i].susp[b.detT] = Math.max(0, act[i].susp[b.detT] - 60);
                    pub[b.detT] = Math.max(0, pub[b.detT] - 1);
                }
                return;
            }
            if (b.camWho >= 0 && act[b.camWho].alive && d != null && b.camTick >= d.tick - 900 && b.camTick <= d.tick + 150) {
                say(b.id, "cutemod.hive.m.cam", 3, nm(b.camWho), rm(b.camRoom));      // it was watching the cameras
                b.susp[b.camWho] += 30;
                accuse(b.id, b.camWho, 30);
                return;
            }
            int s = d != null ? suspectFor(b, d) : -1;
            if (s >= 0) {
                int sc = scoreOut;
                say(b.id, "cutemod.hive.m.near", 3, nm(s), rm(d.room));
                b.susp[s] += sc >= 100 ? 90 : 60;                  // it saw this one itself
                accuse(b.id, s, sc >= 100 ? 60 : 40);
                contradict(b, s, d);
                return;
            }
            for (Actor w : act) {                                    // it saw somebody doing a visible task: that one is crew
                if (w.id != b.id && w.alive && b.seenWork[w.id] && rnd.nextInt(100) < 60) {
                    say(b.id, "cutemod.hive.m.work", 3, nm(w.id));
                    for (int i = 1; i < N; i++) act[i].susp[w.id] = Math.max(0, act[i].susp[w.id] - 50);
                    return;
                }
            }
            int o = companion(b);
            if (o >= 0) {
                say(b.id, "cutemod.hive.m.alibi", 3, nm(o), rm(b.seenRoom[o]));
                b.susp[o] = Math.max(0, b.susp[o] - 40);
                return;
            }
            say(b.id, "cutemod.hive.m.nothing", 3, rm(b.lastRoom));
            return;
        }
        int s = scapegoat(b);
        if (s >= 0 && d != null && rnd.nextInt(100) < 25) {          // a lie about the cameras
            say(b.id, "cutemod.hive.m.cam", 3, nm(s), rm(ROOMS.length));
            accuse(b.id, s, 30);
        } else if (s >= 0 && rnd.nextInt(100) < 65) {
            say(b.id, "cutemod.hive.m.near", 3, nm(s), rm(d != null ? d.room : rnd.nextInt(ROOMS.length)));
            accuse(b.id, s, 40);
            contradict(b, s, d);
        } else say(b.id, "cutemod.hive.m.nothing", 3, rm(rnd.nextInt(ROOMS.length)));
    }

    /** Who this bot saw near the victim: in the room of the body shortly before the death, and above all together with the victim. */
    private int suspectFor(Actor b, Body d) {
        int best = -1, bs = 0;
        for (Actor o : act) {
            if (o.id == b.id || o.id == d.victim) continue;
            int sc = 0, t = b.seenTick[o.id], w = b.with[d.victim][o.id];
            if (t >= d.tick - 1200 && t <= d.tick + 300 && b.seenRoom[o.id] == d.room) sc += 40;
            if (w >= d.tick - 1500 && w <= d.tick + 10) sc += 60;
            if (b.together[o.id] >= 900) sc -= 80;                 // it spent a long time with this one: cleared
            if (b.seenWork[o.id]) sc -= 80;                        // it saw this one doing a task that everybody can see
            if (sc > bs) { bs = sc; best = o.id; }
        }
        scoreOut = bs;
        return bs >= 40 ? best : -1;
    }

    /** Somebody who saw the accused far from the body at that time says so, and the liar (or the mistaken one) loses credit. */
    private void contradict(Actor a, int x, Body d) {
        if (d == null || contras >= 2) return;
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.imp || c.id == a.id || c.id == x) continue;
            int t = c.seenTick[x];
            if (t >= d.tick - 600 && t <= d.tick + 60 && c.seenRoom[x] != d.room) {
                say(c.id, "cutemod.hive.m.contra", 3, nm(x), rm(c.seenRoom[x]), nm(a.id));
                contras++;
                for (int k = 1; k < N; k++) {
                    Actor o = act[k];
                    if (!o.alive || o.id == a.id) continue;
                    o.susp[a.id] += 30;
                    o.susp[x] = Math.max(0, o.susp[x] - 30);
                }
                pub[a.id]++;
                return;
            }
        }
    }

    /** The one who was accused most defends itself; a friend vouches for it, or an impostor's partner backs the lie up. */
    private void debate() {
        int tgt = -1, bv = 1;
        for (int i = 1; i < N; i++) if (act[i].alive && pub[i] > bv) { bv = pub[i]; tgt = i; }
        if (tgt < 0) return;
        Actor x = act[tgt];
        if (!x.imp) {
            Actor v = null;
            for (int i = 1; i < N; i++) {
                Actor c = act[i];
                if (c.alive && !c.imp && c.id != tgt && c.together[tgt] >= 500) { v = c; break; }
            }
            if (v != null) {
                say(v.id, "cutemod.hive.m.vouch", 3, nm(tgt), rm(v.seenRoom[tgt]));
                for (int i = 1; i < N; i++) act[i].susp[tgt] = Math.max(0, act[i].susp[tgt] - 40);
                pub[tgt] = Math.max(0, pub[tgt] - 1);
            } else say(tgt, "cutemod.hive.m.defend", 3, rm(x.lastRoom));
        } else {
            int s = scapegoat(x);
            say(tgt, "cutemod.hive.m.point", 3, nm(s >= 0 ? s : 0));
            if (s >= 0) accuse(tgt, s, 20);
            for (int i = 1; i < N; i++) {
                Actor q = act[i];
                if (q.alive && q.imp && q.id != tgt) { say(q.id, "cutemod.hive.m.alibi", 3, nm(tgt), rm(rnd.nextInt(ROOMS.length))); break; }
            }
        }
    }

    private int roomAtTime(Actor a, int t) {
        return t >= ticks - 6000 && t >= 0 ? a.hist[(t / 100) % 64] : a.lastRoom;
    }

    /** Round two: the bots question each other. The one who is asked answers, and whoever saw it at that time confirms the answer or catches the lie. */
    private void crossTalk() {
        Body d = bodyIdx >= 0 ? bodies.get(bodyIdx) : null;
        List<Actor> al = new ArrayList<>();
        for (Actor a : act) if (a.alive && a.id != 0) al.add(a);
        java.util.Collections.shuffle(al, new java.util.Random(rnd.nextLong()));
        int asks = 0;
        for (Actor q : al) {
            if (asks >= 2) break;
            int t = -1, tv = 25;
            for (Actor o : act) {
                if (o.id == q.id || o.id == 0 || !o.alive || asked[o.id]) continue;
                int v = q.imp ? (o.imp ? 0 : pub[o.id] * 30 + rnd.nextInt(20)) : q.susp[o.id] + pub[o.id] * 10;
                if (v > tv) { tv = v; t = o.id; }
            }
            if (t < 0) continue;
            asked[t] = true; asks++;
            say(q.id, "cutemod.hive.m.ask", 3, nm(t));
            answer(act[t], d);
        }
        if (wary && rnd.nextInt(100) < 70) {                     // after a death the crew offers to go in pairs
            for (Actor c : al) {
                if (c.imp) continue;
                int o = companion(c);
                if (o < 0) continue;
                say(c.id, "cutemod.hive.m.pair", 3, nm(o));
                pairWish[c.id] = o;
                break;
            }
        }
    }

    /** A bot says where it was when it happened. A crewmate tells the truth, an impostor names the room of one of its own tasks. */
    private void answer(Actor t, Body d) {
        int when = d != null ? d.tick : ticks;
        int room;
        if (t.imp) {
            int k = t.spot[rnd.nextInt(PER)];
            room = roomTile(TX[k], TY[k]);
            if (d != null && room == d.room) room = (room + 1 + rnd.nextInt(ROOMS.length - 1)) % ROOMS.length;
        } else room = d != null ? roomAtTime(t, when) : t.lastRoom;
        say(t.id, "cutemod.hive.m.mine", 3, rm(room));
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.imp || c.id == t.id) continue;
            int st = c.seenTick[t.id];
            if (st < when - 150 || st > when + 100) continue;     // it did not see t around that time
            if (c.seenRoom[t.id] == room) {
                say(c.id, "cutemod.hive.m.confirm", 3, nm(t.id), rm(room));
                for (int k = 1; k < N; k++) act[k].susp[t.id] = Math.max(0, act[k].susp[t.id] - 20);
                pub[t.id] = Math.max(0, pub[t.id] - 1);
            } else {
                say(c.id, "cutemod.hive.m.liar", 3, rm(c.seenRoom[t.id]));
                for (int k = 1; k < N; k++) act[k].susp[t.id] += 40;
                pub[t.id] += 2;
            }
            break;
        }
    }

    /** Everybody has spoken and the player has said nothing: somebody asks them straight out. */
    private void pressPlayer() {
        pressed = true;
        List<Actor> al = new ArrayList<>();
        for (Actor a : act) if (a.alive && a.id != 0) al.add(a);
        if (al.isEmpty()) return;
        Actor q = al.get(0);
        for (Actor a : al) if (a.susp[0] > q.susp[0]) q = a;
        insertAt = -1;
        say(q.id, "cutemod.hive.m.quiet", 3, nm(0));
        for (Actor a : al) a.susp[0] += 10;
        lineT = Math.min(lineT, 30);
    }

    private int companion(Actor b) {
        int best = -1, bt = 299;
        for (Actor o : act) {
            if (o.id == b.id || !o.alive) continue;
            if (b.together[o.id] > bt) { bt = b.together[o.id]; best = o.id; }
        }
        return best >= 0 ? best : recentOther(b);
    }

    private int recentOther(Actor b) {
        int best = -1, bt = ticks - 1800;
        for (Actor o : act) {
            if (o.id == b.id || !o.alive) continue;
            if (b.seenTick[o.id] > bt) { bt = b.seenTick[o.id]; best = o.id; }
        }
        return best;
    }

    /** An impostor accuses someone who has no alibi: the less the crew has seen a pet lately, the better the target. */
    private int scapegoat(Actor b) {
        int best = -1;
        float bw = -1F;
        for (Actor o : act) {
            if (o.imp || !o.alive || o.id == b.id) continue;
            int last = -99999;
            for (Actor c : act) if (!c.imp && c.alive && c.id != o.id) last = Math.max(last, c.seenTick[o.id]);
            float w = (1F + Math.min(5F, (ticks - last) / 600F)) * (0.6F + rnd.nextFloat());
            if (o.id == 0) w *= 1.3F;
            if (w > bw) { bw = w; best = o.id; }
        }
        return best;
    }

    /** A public accusation: the other bots weigh it (less if they know the accused was elsewhere, nothing if they were with the accused for a long time). */
    private void accuse(int speaker, int target, int weight) {
        pub[target]++;
        Body d = bodyIdx >= 0 ? bodies.get(bodyIdx) : null;
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.id == speaker || c.id == target) continue;
            if (weight < 100 && c.together[target] >= 900) continue;
            int w = weight;
            if (d != null && weight < 100) {
                int t = c.seenTick[target];
                if (t > d.tick - 600 && t < d.tick + 600 && c.seenRoom[target] != d.room) w /= 4;
            }
            c.susp[target] += weight >= 100 ? w : w / 2;           // what others say counts less than what you saw
        }
    }

    private void playerAccuse(int t) {
        Actor ta = act[t];
        if (!ta.alive || t == 0) return;
        pActs++;
        insertAt = shown;
        say(0, "cutemod.hive.m.accuse", 3, nm(t));
        if (act[0].role == R_DET && chk[t] == 2 && ta.imp) { say(0, "cutemod.hive.m.proof", 3, nm(t)); accuse(0, t, 150); }
        else if (act[0].attacker == t) { say(0, "cutemod.hive.m.shieldp", 3, nm(t)); accuse(0, t, 150); }
        if (ta.imp) {
            int s = scapegoat(ta);
            say(t, "cutemod.hive.m.point", 3, nm(s >= 0 ? s : 0));
            if (s >= 0) accuse(t, s, 20);
        } else say(t, "cutemod.hive.m.defend", 3, rm(ta.lastRoom));
        boolean disagreed = false;
        for (int i = 1; i < N && !disagreed; i++) {                // a friend of the accused speaks up
            Actor c = act[i];
            if (c.alive && !c.imp && c.id != t && (c.together[t] >= 500 || c.seenWork[t])) {
                say(c.id, "cutemod.hive.m.disagree", 3, nm(t), rm(c.seenRoom[t]));
                c.susp[t] = Math.max(0, c.susp[t] - 20);
                disagreed = true;
            }
        }
        int n = 0;
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.id == t) continue;
            if (n < 2 && (c.susp[t] >= 25 || rnd.nextInt(100) < 25)) {
                say(c.id, "cutemod.hive.m.agree", 3, nm(t));
                c.susp[t] += 30;
                n++;
            } else c.susp[t] += 8;
        }
        afterPlayerLine();
    }

    /** The player asks one pet what it saw; it answers with what it knows (an impostor lies). */
    private void playerAsk(int t) {
        Actor ta = act[t];
        if (!ta.alive || t == 0) return;
        pActs++;
        insertAt = shown;
        say(0, "cutemod.hive.m.ask", 3, nm(t));
        if (asked[t]) say(t, "cutemod.hive.m.already", 3);
        else {
            asked[t] = true;
            statement(ta, bodyIdx >= 0 ? bodies.get(bodyIdx) : null);
        }
        afterPlayerLine();
    }

    private void playerAlibi() {
        Actor p = act[0];
        pActs++;
        insertAt = shown;
        if (pressed) for (int i = 1; i < N; i++) act[i].susp[0] = Math.max(0, act[i].susp[0] - 10);
        int room = p.lastRoom;
        if (playerImp) { room = rnd.nextInt(ROOMS.length); if (room == p.lastRoom) room = (room + 1) % ROOMS.length; }     // an impostor lies
        say(0, "cutemod.hive.m.mine", 3, rm(room));
        boolean said = false, confirmed = false;
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.seenTick[0] < ticks - 600) continue;
            if (c.seenRoom[0] == room) {
                c.susp[0] = Math.max(0, c.susp[0] - 25);
                if (!confirmed) { confirmed = true; say(c.id, "cutemod.hive.m.confirm", 3, nm(0), rm(room)); }
            } else {
                c.susp[0] += 30;
                if (!said) { said = true; say(c.id, "cutemod.hive.m.liar", 3, rm(c.seenRoom[0])); }
            }
        }
        if (!said && !confirmed) {                                  // nobody saw the player: somebody asks for proof
            List<Actor> al = new ArrayList<>();
            for (int i = 1; i < N; i++) if (act[i].alive) al.add(act[i]);
            if (!al.isEmpty()) say(al.get(rnd.nextInt(al.size())).id, "cutemod.hive.m.doubt", 3);
        }
        afterPlayerLine();
    }

    private void afterPlayerLine() { insertAt = -1; lineT = Math.min(lineT, 40); chatOff = 0; }

    private void scrollChat(int d) { chatOff = Math.max(0, Math.min(Math.max(0, shown - 1), chatOff + d)); }

    @Override
    public boolean scroll(double amount) {
        if (phase != PH_MEET || (mstate != M_TALK && mstate != M_VOTE) || evi) return false;
        scrollChat(amount > 0 ? 1 : -1);
        return true;
    }

    private void toVote() {
        if (mstate != M_TALK) return;
        mstate = M_VOTE; mt = 0; sel = -1;
        decideVotes();
    }

    private void decideVotes() {
        java.util.Arrays.fill(vote, -3);
        for (int i = 1; i < N; i++) {
            Actor b = act[i];
            if (!b.alive) continue;
            int best = -1, bv = 0;
            int lead = -1, lv = 1;                                   // whom the whole table has been accusing
            for (Actor o : act) if (o.alive && o.id != b.id && pub[o.id] > lv) { lv = pub[o.id]; lead = o.id; }
            if (!b.imp) {
                for (Actor o : act) if (o.alive && o.id != b.id && b.susp[o.id] > bv && !(b.together[o.id] >= 900 && b.susp[o.id] < 150)) { bv = b.susp[o.id]; best = o.id; }
                if (bv >= 90) vote[i] = best;
                else if (lead >= 0 && b.together[lead] < 900 && rnd.nextInt(100) < 55) vote[i] = lead;      // it goes with the crowd
                else vote[i] = rnd.nextInt(100) < 85 ? -1 : randomOther(b, false);
            } else if (lead >= 0 && act[lead].imp && lv >= 3 && rnd.nextInt(100) < 40) {
                vote[i] = lead;                                                                           // it gives up its partner to look clean
            } else {
                for (Actor o : act) if (o.alive && !o.imp && pub[o.id] > bv) { bv = pub[o.id]; best = o.id; }
                if (best >= 0) vote[i] = best;
                else vote[i] = rnd.nextInt(100) < 50 ? -1 : randomOther(b, true);
            }
        }
    }

    private int randomOther(Actor b, boolean crewOnly) {
        List<Integer> c = new ArrayList<>();
        for (Actor o : act) if (o.alive && o.id != b.id && (!crewOnly || !o.imp)) c.add(o.id);
        return c.isEmpty() ? -1 : c.get(rnd.nextInt(c.size()));
    }

    private void finishVote() {
        vote[0] = act[0].alive ? (pVote == -2 ? -1 : pVote) : -3;
        java.util.Arrays.fill(tally, 0);
        skipCount = 0;
        for (int i = 0; i < N; i++) {
            int v = vote[i];
            if (v == -1) skipCount++;
            else if (v >= 0) tally[v]++;
        }
        mstate = M_SHOW; mt = 0; evi = false;
        beep();
    }

    private void computeEject() {
        int best = -1, bv = 0, ties = 0;
        for (int i = 0; i < N; i++) {
            if (tally[i] > bv) { bv = tally[i]; best = i; ties = 1; }
            else if (tally[i] == bv && bv > 0) ties++;
        }
        if (best >= 0 && ties == 1 && bv > skipCount) {
            ejected = best; ejWasImp = act[best].imp; act[best].alive = false;
        } else ejected = -1;
    }

    private void endMeeting() {
        bodies.clear();
        for (int i = 0; i < N; i++) {
            Actor a = act[i];
            if (!a.alive && i != 0) continue;
            float ang = i * (float) Math.PI / 4F;
            a.x = BX + (float) Math.cos(ang) * 30F;
            a.y = BY + (float) Math.sin(ang) * 30F;
            a.witness = -1; a.witnessV = -1; a.ventSaw = -1; a.attacker = -1; a.mode = 0; a.bodyT = -1;
            if (a.imp) a.killCd = Math.max(a.killCd, 900);
            a.camWho = -1;
            if (i != 0 && a.alive && pairWish[i] >= 0 && act[pairWish[i]].alive) { a.buddy = pairWish[i]; a.buddyT = 700 + rnd.nextInt(400); a.mode = 10; }
        }
        lightsOut = false; reactorOn = false; sabCd = Math.max(sabCd, 900); hold = 0;
        phase = PH_PLAY;
        checkWin();
    }

    private void meetTick() {
        mt++;
        for (int i = 0; i < N; i++) if (rxT[i] > 0) rxT[i]--;
        if (speakT > 0) speakT--;
        switch (mstate) {
            case M_INTRO -> { if (mt > 100) { mstate = M_TALK; mt = 0; } }
            case M_TALK -> {
                if (shown < lines.size() && --lineT <= 0) { shown++; lineT = 180; if (chatOff > 0) chatOff++; beep(); reactTo(lines.get(shown - 1)); }
                if (!pressed && act[0].alive && pActs == 0 && shown >= lines.size() && mt > 90) pressPlayer();
                boolean ghost = !act[0].alive;
                if ((ghost && shown >= lines.size() && mt > 60) || mt > 7200) toVote();
            }
            case M_VOTE -> {
                if (!act[0].alive && mt > 90) finishVote();
                else if (mt > 1500) { pVote = -1; finishVote(); }
            }
            case M_SHOW -> { if (mt > 190) { computeEject(); mstate = M_EJECT; mt = 0; sound(SoundEvents.ENDERMAN_TELEPORT, 0.6F, 0.7F); } }
            default -> { if (mt > 240) endMeeting(); }
        }
    }

    private boolean meetClick(int x, int y) {
        Actor p = act[0];
        if (!evi && (mstate == M_TALK || mstate == M_VOTE) && x >= W - 15 && x < W - 3) {
            if (in(x, y, W - 15, 76, 12, 14)) { scrollChat(1); return true; }
            if (in(x, y, W - 15, 108, 12, 14)) { scrollChat(-1); return true; }
        }
        if (mstate == M_TALK || mstate == M_VOTE) {
            for (int i = 0; i < N; i++) {
                if (in(x, y, 4 + (i % 4) * 54, 12 + (i / 4) * 32, 50, 30)) {
                    if (act[i].alive && i != 0 && p.alive) { sel = i; beep(); }
                    return true;
                }
            }
        }
        if (!p.alive) return true;
        if ((mstate == M_TALK || mstate == M_VOTE) && in(x, y, W - 20, 1, 16, 10)) { evi = !evi; beep(); return true; }
        if (mstate == M_TALK && y < 11) {
            for (int k = 0; k < 4; k++) if (in(x, y, 4 + k * 18, 1, 16, 10)) { playerReact(k); return true; }
        }
        if (mstate == M_TALK) {
            if (in(x, y, 4, 124, 51, 13) && sel >= 0 && pActs < 4) playerAccuse(sel);
            else if (in(x, y, 57, 124, 51, 13) && sel >= 0 && pActs < 4) playerAsk(sel);
            else if (in(x, y, 110, 124, 51, 13) && pActs < 4) playerAlibi();
            else if (in(x, y, 163, 124, 53, 13)) toVote();
        } else if (mstate == M_VOTE) {
            if (in(x, y, 4, 124, 106, 13) && sel >= 0) { pVote = sel; finishVote(); }
            else if (in(x, y, 114, 124, 102, 13)) { pVote = -1; finishVote(); }
        }
        return true;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (phase == PH_ROLE) { phaseT = 0; return true; }
        if (phase == PH_MEET) return meetClick(x, y);
        if (phase != PH_PLAY) return true;
        if (mapOpen) { mapOpen = false; return true; }
        if (camOpen) { if (in(x, y, PX + PW - 15, PY + 2, 13, 13)) camOpen = false; return true; }
        if (taskOpen) return taskClick(x, y);
        int[] acts = actsOf();
        if (y >= H - 14 && y < H - 2 && x >= 4) {
            int i = (x - 4) / 36;
            if (i < acts.length && (x - 4) % 36 < 34) doAction(acts[i]);
        }
        return true;
    }

    // ------------------------------------------------------------------ drawing: sprites

    private static void bean(GuiGraphics g, int cx, int cy, int pt, int face, boolean ghost, int step) {
        int c = COLORS[pt], d = Gfx.darker(c, 0.28F), ol = Gfx.darker(c, 0.55F), hi = Gfx.lighter(c, 0.55F);
        int white = 0xFFFFFFFF, dark = 0xFF1A1428, cheek = 0xFFF28BA8;
        if (ghost) {
            c = (c & 0xFFFFFF) | 0x99000000; d = (d & 0xFFFFFF) | 0x99000000; ol = (ol & 0xFFFFFF) | 0x99000000; hi = (hi & 0xFFFFFF) | 0x99000000;
            white = 0x99FFFFFF; dark = 0x99000000; cheek = 0x99F28BA8;
        }
        // ears and other things behind the head
        switch (pt) {
            case 0 -> { rect(g, cx - 5, cy - 9, 3, 4, ol); rect(g, cx + 2, cy - 9, 3, 4, ol); rect(g, cx - 4, cy - 8, 2, 3, d); rect(g, cx + 2, cy - 8, 2, 3, d); }
            case 1 -> { disc(g, cx - 2, cy - 6, 3, ol); disc(g, cx + 2, cy - 6, 3, ol); disc(g, cx - 2, cy - 6, 2, white); disc(g, cx + 2, cy - 6, 2, white); rect(g, cx - 2 + (face > 0 ? 1 : 0), cy - 6, 1, 2, dark); rect(g, cx + 2 + (face > 0 ? 1 : 0), cy - 6, 1, 2, dark); }
            case 2 -> { disc(g, cx - 3, cy - 7, 3, dark); disc(g, cx + 3, cy - 7, 3, dark); }
            case 3 -> { disc(g, cx - 4, cy - 6, 4, ol); disc(g, cx + 4, cy - 6, 4, ol); disc(g, cx - 4, cy - 6, 3, c); disc(g, cx + 4, cy - 6, 3, c); disc(g, cx - 4, cy - 6, 1, 0xFFF4A7C3); disc(g, cx + 4, cy - 6, 1, 0xFFF4A7C3); }
            case 4 -> { rect(g, cx - 5, cy - 11, 3, 5, ol); rect(g, cx + 2, cy - 11, 3, 5, ol); rect(g, cx - 4, cy - 10, 2, 5, c); rect(g, cx + 2, cy - 10, 2, 5, c); rect(g, cx - 4, cy - 10, 2, 2, white); rect(g, cx + 2, cy - 10, 2, 2, white); }
            case 5 -> { disc(g, cx - 5, cy - 5, 4, ol); disc(g, cx + 5, cy - 5, 4, ol); disc(g, cx - 5, cy - 5, 3, 0xFFD8D0E8); disc(g, cx + 5, cy - 5, 3, 0xFFD8D0E8); disc(g, cx - 5, cy - 5, 1, 0xFF8A7AA8); disc(g, cx + 5, cy - 5, 1, 0xFF8A7AA8); }
            case 6 -> { rect(g, cx - 5, cy - 10, 3, 4, ol); rect(g, cx + 2, cy - 10, 3, 4, ol); rect(g, cx - 4, cy - 9, 2, 3, c); rect(g, cx + 2, cy - 9, 2, 3, c); rect(g, cx - 4, cy - 8, 1, 1, cheek); rect(g, cx + 3, cy - 8, 1, 1, cheek); }
            default -> { disc(g, cx - 4, cy - 7, 3, ol); disc(g, cx + 4, cy - 7, 3, ol); disc(g, cx - 4, cy - 7, 2, d); disc(g, cx + 4, cy - 7, 2, d); }
        }
        // the outline, then the body
        rect(g, cx - 5, cy - 6, 10, 10, ol);
        rect(g, cx - 4, cy - 7, 8, 1, ol);
        rect(g, cx - 3, cy - 7, 6, 1, c);
        rect(g, cx - 4, cy - 6, 8, 10, c);
        rect(g, cx + 2, cy - 6, 2, 10, d);                // the shaded side
        rect(g, cx - 3, cy - 6, 2, 1, hi);                // a shine on the head
        rect(g, cx - 4, cy - 5, 1, 2, hi);
        if (ghost) rect(g, cx - 4, cy + 4, 8, 2, c);
        else {                                            // the feet take turns when it walks
            rect(g, cx - 4, cy + 4, 3, step == 0 ? 2 : 1, d);
            rect(g, cx + 1, cy + 4, 3, step == 0 ? 1 : 2, d);
        }
        if (pt == 2) { rect(g, cx - 4, cy - 5, 4, 4, dark); rect(g, cx, cy - 5, 4, 4, dark); }   // the panda's eye patches
        if (pt != 1) {
            int ex = cx - 3 + (face > 0 ? 1 : 0), pxo = face > 0 ? 1 : 0;
            rect(g, ex, cy - 4, 2, 3, white); rect(g, ex + 3, cy - 4, 2, 3, white);
            rect(g, ex + pxo, cy - 3, 1, 2, dark); rect(g, ex + 3 + pxo, cy - 3, 1, 2, dark);
            if (pt != 2) { rect(g, cx - 4, cy, 1, 1, cheek); rect(g, cx + 3, cy, 1, 1, cheek); }
        } else {
            rect(g, cx - 2, cy - 2, 4, 1, dark);
        }
    }

    private static void corpse(GuiGraphics g, int cx, int cy, int pt) {
        int c = COLORS[pt], d = Gfx.darker(c, 0.3F);
        rect(g, cx - 4, cy - 3, 8, 1, c);
        rect(g, cx - 5, cy - 2, 10, 4, c);
        rect(g, cx - 4, cy + 2, 8, 1, d);
        rect(g, cx + 3, cy - 2, 2, 4, d);
        rect(g, cx - 1, cy - 6, 2, 3, 0xFFF4F0E8);
        rect(g, cx - 3, cy - 1, 1, 1, 0xFF1A1428); rect(g, cx - 1, cy - 1, 1, 1, 0xFF1A1428);
        rect(g, cx - 2, cy, 1, 1, 0xFF1A1428);
    }

    private void bigBean(GuiGraphics g, int x, int y, int pt, float scale, boolean ghost) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1F);
        bean(g, 0, 0, pt, 1, ghost, 0);
        g.pose().popPose();
    }

    // ------------------------------------------------------------------ drawing: the world

    @Override
    public void render(GuiGraphics g) {
        if (phase == PH_MEET) { renderMeeting(g); return; }
        renderWorld(g);
        if (phase == PH_PLAY) {
            renderHud(g);
            if (taskOpen) renderTask(g);
            if (camOpen) renderCams(g);
            if (mapOpen) renderMap(g);
        }
        if (phase == PH_ROLE) renderRole(g);
        if (phase == PH_END) renderEnd(g);
    }

    private final float[][] lit = new float[MH][MW];
    private final float[][] cl = new float[MH + 2][MW + 2];
    private final float[][] soft = new float[MH][MW];

    private static void fillC(GuiGraphics g, int x0, int y0, int x1, int y1, int col) {
        x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(clipW, x1); y1 = Math.min(clipH, y1);
        if (x1 > x0 && y1 > y0) g.fill(x0, y0, x1, y1, col);
    }

    private static float smooth(float t) {
        t = Math.max(0F, Math.min(1F, t));
        return t * t * (3F - 2F * t);
    }

    private void renderWorld(GuiGraphics g) {
        Actor p = act[0];
        g.fill(0, 0, W, H, 0xFF0A0818);
        float camx = Math.max(0, Math.min(MW * T - W, p.x - W / 2F)), camy = Math.max(0, Math.min(MH * T - H, p.y - H / 2F));
        int ox = -(int) camx, oy = -(int) camy;
        boolean full = !p.alive;
        float rad = vision();
        boolean open = full || p.imp || !lightsOut;
        viewOpen = open; viewRad = rad;
        int tx0 = Math.max(0, (int) (camx / T)), ty0 = Math.max(0, (int) (camy / T));
        int tx1 = Math.min(MW - 1, tx0 + W / T + 1), ty1 = Math.min(MH - 1, ty0 + H / T + 1);
        boolean baked = open && ensureWorld();                     // with the lights on the whole station is one still picture
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                if (open) {                                         // with the lights on the whole floor is seen, no black fog
                    vis[ty][tx] = true; lit[ty][tx] = 1F;
                    if (!baked) drawTile(g, tx, ty, tx * T + ox, ty * T + oy);
                    continue;
                }
                float cx = tx * T + T / 2F, cy = ty * T + T / 2F;
                float d = dist(p.x, p.y, cx, cy);
                boolean v = d < rad && los(p.x, p.y, cx, cy);
                vis[ty][tx] = v;
                lit[ty][tx] = v ? 1F - smooth((d / rad - 0.42F) / 0.58F) : 0F;
                if (v) drawTile(g, tx, ty, tx * T + ox, ty * T + oy);
            }
        }
        if (baked) {
            TexCache.blitRegion(g, world, 0, 0, -ox, -oy, W, H);
            worldMotion(g, ox, oy, tx0, ty0, tx1, ty1);
        }
        for (int i = 0; i < BLOCKS.length; i++) {                  // a big thing is lit as a whole, whichever of its tiles the light reaches
            int[] r = BLOCKS[i];
            boolean any = false;
            float m = 0F;
            for (int k = 0; k < 4; k++) {
                int bxx = r[0] + (k & 1), byy = r[1] + (k >> 1);
                any |= vis[byy][bxx];
                m = Math.max(m, lit[byy][bxx]);
            }
            if (!any) continue;
            for (int k = 0; k < 4; k++) {
                int bxx = r[0] + (k & 1), byy = r[1] + (k >> 1);
                if (!vis[byy][bxx]) drawTile(g, bxx, byy, bxx * T + ox, byy * T + oy);
                vis[byy][bxx] = true;
                lit[byy][bxx] = m;
            }
            drawBlock(g, i, ox, oy);
        }
        for (int i = 0; i < VX.length; i++) {
            if (!visPx(VX[i] * T + 4, VY[i] * T + 4)) continue;
            int sx = VX[i] * T + ox, sy = VY[i] * T + oy;
            rect(g, sx, sy + 1, 8, 7, 0xFF6A6498);
            rect(g, sx + 1, sy + 2, 6, 5, 0xFF1E1A3A);
            rect(g, sx + 1, sy + 3, 6, 1, 0xFF6A6498);
            rect(g, sx + 1, sy + 5, 6, 1, 0xFF6A6498);
        }
        if (visPx(CSX * T + 4, CSY * T + 4)) {                      // the camera console
            int sx = CSX * T + ox, sy = CSY * T + oy;
            rect(g, sx, sy + 1, 8, 7, 0xFF2A3A5A);
            rect(g, sx + 1, sy + 2, 6, 4, 0xFF0E2A44);
            rect(g, sx + 2, sy + 3, 2, 1, 0xFF6FE0FF);
            rect(g, sx + 5, sy + 3, 1, 1, (ticks / 30) % 2 == 0 ? 0xFFE0594F : 0xFF7A2A2A);
            rect(g, sx + 1, sy + 6, 6, 1, 0xFF6FE0FF);
        }
        boolean pulse = (ticks / 15) % 2 == 0;
        if (lightsOut) marker(g, LX, LY, ox, oy, 0xFFFFB347, pulse);
        if (reactorOn) for (int i = 0; i < 2; i++) if (!consoleOk[i]) marker(g, CX[i], CY[i], ox, oy, 0xFFE0594F, pulse);
        for (int i = 0; i < PER; i++) {
            if (p.done[i]) continue;
            int s = p.spot[i];
            marker(g, TX[s], TY[s], ox, oy, 0xFFFFE066, true);
        }
        for (float[] c : candies) {
            if (!visPx(c[0], c[1])) continue;
            int sx = (int) c[0] + ox, sy = (int) c[1] + oy - ((ticks / 14) % 2);
            Gfx.ellipse(g, sx, sy + 5, 4, 1, 0x44000000);
            Gfx.glow(g, sx, sy, 8, 0xFFF58FB8, 60);
            candy(g, sx, sy);
        }
        for (Body d : bodies) {
            if (!entVis(d.x, d.y)) continue;
            Gfx.ellipse(g, (int) d.x + ox, (int) d.y + oy + 3, 7, 2, 0x44000000);
            corpse(g, (int) d.x + ox, (int) d.y + oy, pet[d.victim]);
        }
        Actor kt = killTarget();
        Actor dt = detTarget();
        for (int n = 1; n <= N; n++) {
            Actor a = act[n % N];
            if (a.vented) continue;
            if (!a.alive && !full) continue;                       // only a ghost sees the ghosts
            if (a.alive && a.id != 0 && !entVis(a.x, a.y)) continue;
            int sx = (int) a.x + ox, sy = (int) a.y + oy;
            if (sx < -12 || sx > W + 12 || sy < -14 || sy > H + 14) continue;
            if (a.alive) Gfx.ellipse(g, sx, sy + 6, 5, 2, 0x55000000);
            if (a.id == 0 && boostT > 0 && a.alive) {
                Gfx.glow(g, sx, sy, 11, 0xFFF58FB8, 40);
                rect(g, sx - 10 * a.face, sy - 3 + (ticks / 3) % 5, 6, 1, 0x88FFFFFF);
            }
            bean(g, sx, a.alive ? sy : sy - 2, pet[a.id], a.face, !a.alive, (((int) (a.x + a.y)) / 4) & 1);
            if (working(a)) {                                        // a task everybody can see: green sparks around the doer
                for (int k = 0; k < 4; k++) {
                    double an = ticks / 10.0 + k * Math.PI / 2;
                    rect(g, sx + (int) (Math.cos(an) * 9) - 1, sy - 3 + (int) (Math.sin(an) * 6), 2, 2, k % 2 == 0 ? 0xFF7ED957 : 0xFFFFFFFF);
                }
            }
            if (a == kt) Gfx.outline(g, sx - 6, sy - 9, 12, 16, 0xFFFF4040);
            if (a == dt) Gfx.outline(g, sx - 6, sy - 9, 12, 16, 0xFF6FE0FF);
            if (a.id != 0 && a.alive && chk[a.id] > 0) emoji(g, sx, sy - 19, chk[a.id] == 2 ? 3 : 2, 4);
            if (a.id == 0) { rect(g, sx - 1, sy - 14, 3, 1, 0xFFFFE066); rect(g, sx, sy - 13, 1, 1, 0xFFFFE066); }
            else if (playerImp && a.imp && a.alive) rect(g, sx - 1, sy - 13, 3, 2, 0xFFFF4040);
        }
        if (full) fillC(g, 0, 0, W, H, 0x1830508C);
        else if (!open) {                                    // only when the lights are out: the dark and a small glow
            Gfx.glow(g, (int) p.x + ox, (int) p.y + oy, Math.min(34, (int) (rad * 0.5F)), 0xFFFFE4B0, 26);
            shade(g, ox, oy, tx0, ty0, tx1, ty1);
        }
        if (reactorOn && pulse) g.fill(0, 0, W, H, 0x22FF2020);
        if (killFlash > 0) g.fill(0, 0, W, H, (Math.min(110, killFlash * 3) << 24) | 0xC02020);
    }

    private float softAt(int tx, int ty, int tx0, int ty0, int tx1, int ty1) {
        return soft[clampi(ty, ty0, ty1)][clampi(tx, tx0, tx1)];
    }

    private float litAt(int tx, int ty, int tx0, int ty0, int tx1, int ty1) {
        return lit[clampi(ty, ty0, ty1)][clampi(tx, tx0, tx1)];
    }

    /** The darkness: the light of every tile corner is the average of the four tiles around it, and the picture is darkened in 2x2 pixel steps by the smooth mix of the four corners. */
    private void shade(GuiGraphics g, int ox, int oy, int tx0, int ty0, int tx1, int ty1) {
        for (int j = ty0; j <= ty1; j++)
            for (int i = tx0; i <= tx1; i++)
                soft[j][i] = litAt(i, j, tx0, ty0, tx1, ty1) * 0.5F + (litAt(i - 1, j, tx0, ty0, tx1, ty1) + litAt(i + 1, j, tx0, ty0, tx1, ty1)
                        + litAt(i, j - 1, tx0, ty0, tx1, ty1) + litAt(i, j + 1, tx0, ty0, tx1, ty1)) * 0.125F;
        for (int j = ty0; j <= ty1 + 1; j++)
            for (int i = tx0; i <= tx1 + 1; i++)
                cl[j][i] = (softAt(i - 1, j - 1, tx0, ty0, tx1, ty1) + softAt(i, j - 1, tx0, ty0, tx1, ty1)
                        + softAt(i - 1, j, tx0, ty0, tx1, ty1) + softAt(i, j, tx0, ty0, tx1, ty1)) / 4F;
        final int cell = 2, per = T / cell;
        int endX = (tx1 + 1) * T + ox;
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int sub = 0; sub < per; sub++) {
                int y = ty * T + sub * cell + oy;
                if (y + cell <= 0 || y >= H) continue;
                float fy = (sub + 0.5F) / per;
                int level = -1, start = 0;
                for (int tx = tx0; tx <= tx1; tx++) {
                    float a00 = cl[ty][tx], a10 = cl[ty][tx + 1], a01 = cl[ty + 1][tx], a11 = cl[ty + 1][tx + 1];
                    for (int sx = 0; sx < per; sx++) {
                        float fx = (sx + 0.5F) / per;
                        float top = a00 + (a10 - a00) * fx, bot = a01 + (a11 - a01) * fx;
                        int lv = (int) ((1F - (top + (bot - top) * fy)) * 15.99F);
                        int x = tx * T + sx * cell + ox;
                        if (lv != level) {
                            if (level > 0) fillC(g, start, y, x, y + cell, ((level * 17) << 24) | 0x0A0818);
                            start = x; level = lv;
                        }
                    }
                }
                if (level > 0) fillC(g, start, y, endX, y + cell, ((level * 17) << 24) | 0x0A0818);
            }
        }
    }

    private boolean wallAt(int tx, int ty) {
        return tx >= 0 && ty >= 0 && tx < MW && ty < MH && solid[ty][tx] && !blk[ty][tx];
    }

    private static void box(GuiGraphics g, int px, int py, int x0, int y0, int x1, int y1, int c) {
        fillC(g, px + x0, py + y0, px + x1, py + y1, c);
    }

    /** Things on the walls, by the room in front of them: boards, clocks, pipes, screens, shelves, vines... The wall stays plain in most places. */
    private void wallDecor(GuiGraphics g, int tx, int ty, int px, int py) {
        float h = Gfx.hash(tx, ty * 3 + 1);
        if (h >= 0.42F) return;
        int st = ty + 1 < MH ? styleOf(roomTile(tx, ty + 1)) : 7;
        int v = (int) (Gfx.hash(tx * 5 + 2, ty * 7 + 9) * 4F) & 3;
        int ph = ticks / 20;
        boolean done = true;
        switch (st) {
            case 0 -> {
                if (v == 0) { box(g, px, py, 1, 1, 7, 6, 0xFF3A2A18); box(g, px, py, 2, 2, 6, 5, 0xFF2F5A3A); box(g, px, py, 3, 3, 5, 4, 0xFFEAF6E8); box(g, px, py, 3, 4, 4, 5, 0xFFEAF6E8); }
                else if (v == 1) { box(g, px, py, 2, 1, 6, 5, 0xFFB8A8F0); box(g, px, py, 3, 2, 5, 4, 0xFFFFFFFF); box(g, px, py, 4, 2, 5, 3, 0xFF2A2A60); box(g, px, py, ph % 2 == 0 ? 4 : 3, 3, ph % 2 == 0 ? 5 : 4, 4, 0xFF2A2A60); }
                else if (v == 2) { box(g, px, py, 2, 1, 6, 6, 0xFFF58FB8); box(g, px, py, 3, 2, 5, 4, 0xFFFFFFFF); box(g, px, py, 3, 4, 5, 5, 0xFFF3D46A); }
                else done = false;
            }
            case 1 -> {
                if (v == 0) { box(g, px, py, 0, 1, 8, 3, 0xFF8A94AC); box(g, px, py, 0, 1, 8, 2, 0xFFC4CCE0); box(g, px, py, 0, 4, 8, 6, 0xFFE08A3C); box(g, px, py, 0, 4, 8, 5, 0xFFF3B070); }
                else if (v == 1) { box(g, px, py, 2, 1, 6, 5, 0xFF3A4058); box(g, px, py, 3, 2, 5, 4, 0xFFEAE6FF); box(g, px, py, ph % 2 == 0 ? 4 : 3, 2, ph % 2 == 0 ? 5 : 4, 4, 0xFFE0594F); }
                else if (v == 2) { box(g, px, py, 1, 1, 7, 6, 0xFF3A4058); for (int k = 0; k < 3; k++) box(g, px, py, 2, 2 + k * 2 - (k > 0 ? 0 : 0), 6, 3 + k * 2, 0xFF1E2234); }
                else { for (int k = 0; k < 4; k++) box(g, px, py, k * 2, 2, k * 2 + 2, 5, (k & 1) == 0 ? 0xFFF3D46A : 0xFF2A2A2A); }
            }
            case 2 -> {
                if (v < 2) {
                    box(g, px, py, 1, 1, 7, 6, 0xFF222C60); box(g, px, py, 2, 2, 6, 5, 0xFF2F3A80);
                    for (int k = 0; k < 3; k++) box(g, px, py, 2 + k * 2 - (k > 0 ? 0 : 0), 2 + (k & 1), 3 + k * 2, 3 + (k & 1), (ph + k) % 3 == 0 ? 0xFF7ED957 : ((ph + k) % 3 == 1 ? 0xFFF3D46A : 0xFFE0594F));
                } else if (v == 2) { box(g, px, py, 0, 3, 8, 4, 0xFF1E1E3A); box(g, px, py, 0, 5, 8, 6, 0xFFE0594F); box(g, px, py, 3, 2, 5, 3, 0xFF6FE0FF); }
                else done = false;
            }
            case 3 -> {
                if (v < 3) {
                    box(g, px, py, 0, 3, 8, 4, 0xFF8A5A2E); box(g, px, py, 0, 3, 8, 4, 0xFF8A5A2E);
                    box(g, px, py, 1, 1, 4, 3, 0xFFC48A52); box(g, px, py, 1, 1, 4, 2, 0xFFE0AB74);
                    if (v > 0) box(g, px, py, 5, 0, 7, 3, 0xFFB67A44);
                    box(g, px, py, 0, 6, 8, 7, 0xFF8A5A2E);
                    if (v == 2) { box(g, px, py, 2, 4, 6, 6, 0xFFE0AB74); }
                } else done = false;
            }
            case 4 -> {
                if (v == 0) { box(g, px, py, 1, 1, 7, 6, 0xFFEAF6F2); box(g, px, py, 2, 4, 3, 5, 0xFF2A6A6A); box(g, px, py, 3, 3, 4, 4, 0xFF2A6A6A); box(g, px, py, 4, 4, 5, 5, 0xFF2A6A6A); box(g, px, py, 5, 2, 6, 3, 0xFF2A6A6A); }
                else if (v == 1) { box(g, px, py, 1, 4, 7, 5, 0xFF8A94AC); box(g, px, py, 2, 2, 4, 4, 0xFF7ED957); box(g, px, py, 5, 3, 6, 4, 0xFFF58FB8); box(g, px, py, 2, 2, 4, 3, 0xFFB0F0A0); }
                else done = false;
            }
            case 5 -> {
                box(g, px, py, 1, 1, 7, 6, 0xFF1F2E58); box(g, px, py, 2, 2, 6, 5, 0xFF0E2A44);
                box(g, px, py, 2, 2, 3, 3, 0xFFFFFFFF); box(g, px, py, 5, 3, 6, 4, 0xFFFFE066);
                box(g, px, py, 2 + ph % 4, 4, 3 + ph % 4, 5, 0xFF6FE0FF);
            }
            case 6 -> {
                if (v < 3) {
                    box(g, px, py, 1, 0, 2, 4, 0xFF4E9A3C); box(g, px, py, 1, 3, 3, 5, 0xFF7ED957);
                    box(g, px, py, 4, 0, 5, 6, 0xFF4E9A3C); box(g, px, py, 3, 4, 4, 5, 0xFF7ED957); box(g, px, py, 5, 5, 6, 6, 0xFF7ED957);
                    if (v == 1) { box(g, px, py, 6, 0, 7, 3, 0xFF4E9A3C); box(g, px, py, 6, 3, 8, 4, 0xFFF58FB8); }
                } else done = false;
            }
            case 7 -> {
                if (v == 0) { box(g, px, py, 3, 1, 5, 2, 0xFFFFE066); box(g, px, py, 2, 2, 6, 3, 0x44FFE066); }
                else if (v == 1) { box(g, px, py, 1, 2, 7, 5, 0xFF3A47A0); box(g, px, py, 2, 3, 6, 4, 0xFFEAE6FF); }
                else if (v == 2) { box(g, px, py, 1, 2, 7, 5, 0xFFF3D46A); box(g, px, py, 2, 3, 5, 4, 0xFF2A2A2A); box(g, px, py, 5, 2, 6, 5, 0xFF2A2A2A); }
                else done = false;
            }
            case 8 -> {
                if (v < 3) { for (int k = 0; k < 4; k++) box(g, px, py, k * 2, 2, k * 2 + 2, 5, (k & 1) == 0 ? 0xFFF3D46A : 0xFF2A2A2A); if (v == 1) { box(g, px, py, 3, 1, 5, 6, 0xFFE0594F); } }
                else done = false;
            }
            case 9 -> {
                if (v < 3) {
                    for (int k = 0; k < 3; k++) { box(g, px, py, k * 3, 1, k * 3 + 2, 4, 0xFF222234); box(g, px, py, k * 3, 2, k * 3 + 1, 3, (ph + k) % 3 == 0 ? 0xFF6FE0FF : 0xFF2A4A6A); }
                    box(g, px, py, 3, 5, 5, 6, 0xFFE0594F);
                } else done = false;
            }
            case 10 -> {
                if (v < 3) { box(g, px, py, 1, 1, 7, 6, 0xFFC49A5E); box(g, px, py, 2, 2, 4, 4, 0xFFFFFFFF); box(g, px, py, 5, 2, 6, 5, 0xFFFFF0A8); box(g, px, py, 3, 4, 5, 5, 0xFFB8F0FF); }
                else done = false;
            }
            case 11 -> {
                if (v < 3) {
                    box(g, px, py, 1, 1, 7, 6, 0xFF2A2A44);
                    for (int k = 0; k < 3; k++) { int hh = 1 + (ph + k * 2) % 3; box(g, px, py, 2 + k * 2, 5 - hh, 3 + k * 2, 5, 0xFFD0A8D8); }
                } else done = false;
            }
            case 12 -> {
                if (v < 2) { box(g, px, py, 2, 1, 6, 5, 0xFFE0594F); box(g, px, py, 3, 2, 5, 4, 0xFFFFFFFF); box(g, px, py, 4, 2, 5, 3, 0xFFE0594F); }
                else if (v == 2) { box(g, px, py, 1, 2, 7, 3, 0xFF4A4038); box(g, px, py, 1, 4, 7, 5, 0xFF4A4038); box(g, px, py, 2, 1, 3, 6, 0xFF6A5A48); }
                else done = false;
            }
            case 13 -> {
                box(g, px, py, 1, 1, 7, 6, 0xFF1E3A78);
                for (int k = 0; k < 3; k++) box(g, px, py, 2 + k * 2 - (k > 0 ? 0 : 0), 2 + (k & 1) * 2, 3 + k * 2, 3 + (k & 1) * 2, (ph + k) % 2 == 0 ? 0xFFAFEFFF : 0xFF4A78D0);
            }
            default -> done = false;
        }
        if (!done) {                                                // a window
            box(g, px, py, 1, 1, 7, 6, 0xFF2A2A60); box(g, px, py, 2, 2, 6, 5, 0xFFB8F0FF); box(g, px, py, 2, 2, 4, 3, 0xFFFFFFFF);
        }
    }

    private void drawTile(GuiGraphics g, int tx, int ty, int px, int py) {
        if (solid[ty][tx] && !blk[ty][tx]) {
            int wk = wallKind[ty][tx];
            if (wk == 1) {                                          // the wall seen from the front: a lit panel, seams, a skirting board in the colour of the room under it
                int acc = Gfx.mix(ROOM_A[ty + 1 < MH ? styleOf(roomTile(tx, ty + 1)) : 7], WALL_FRONT, 0.55F);
                fillC(g, px, py, px + T, py + T, WALL_FRONT);
                fillC(g, px, py + 1, px + T, py + 3, 0xFF7C6ECC);
                fillC(g, px, py, px + T, py + 1, 0xFFA698F0);
                if ((tx & 3) == 0) fillC(g, px, py + 1, px + 1, py + T - 3, 0x26000000);
                else if ((tx & 3) == 1) fillC(g, px, py + 1, px + 1, py + T - 3, 0x14FFFFFF);
                fillC(g, px + T - 1, py + 1, px + T, py + T - 3, 0x1E000000);
                fillC(g, px, py + T - 3, px + T, py + T - 2, Gfx.lighter(acc, 0.3F));
                fillC(g, px, py + T - 2, px + T, py + T, Gfx.darker(acc, 0.3F));
                if (!bakeMode) wallDecor(g, tx, ty, px, py);
            } else {
                if (wk != 2) return;                               // only the wall next to a floor is drawn, the rest stays dark space
                fillC(g, px, py, px + T, py + T, WALL_TOP);
                fillC(g, px, py, px + T, py + 1, !solidTile(tx, ty - 1) ? 0xFF8A7CD8 : 0xFF4A3F86);      // a rim of light on every edge that faces the floor
                if (!solidTile(tx - 1, ty)) fillC(g, px, py, px + 1, py + T, 0xFF7E70D0);
                if (!solidTile(tx + 1, ty)) fillC(g, px + T - 1, py, px + T, py + T, 0xFF2E2660);
            }
            return;
        }
        int rm0 = roomTile(tx, ty);
        int st = styleOf(rm0);
        int c = ((tx + ty) & 1) == 0 ? ROOM_A[st] : ROOM_B[st];
        boolean plain = true;
        if (st == 0) {                                          // a round rug under the table
            float ex = (tx * T + 4 - BX) / 56F, ey = (ty * T + 4 - BY) / 44F, q = ex * ex + ey * ey;
            if (q < 0.32F) { c = ((tx + ty) & 1) == 0 ? 0xFFE9A3BC : 0xFFE19AB4; plain = false; }
            else if (q < 1F) { c = ((tx + ty) & 1) == 0 ? 0xFFD4849F : 0xFFCC7C98; plain = false; }
        }
        if (rm0 == 5 || rm0 == 8 || rm0 == 11 || rm0 == 4 || rm0 == 13 || rm0 == 6) {      // a rug in the middle of some rooms
            int[] r = ROOMS[rm0];
            int dx = Math.min(tx - (r[0] + 2), r[0] + r[2] - 3 - tx), dy = Math.min(ty - (r[1] + 2), r[1] + r[3] - 3 - ty);
            if (dx >= 0 && dy >= 0) {
                boolean edge = dx == 0 || dy == 0;
                int[] ca = {0xFF7FB8B0, 0xFF9A5A7A, 0xFF6A7ED0, 0xFF6A8AB0, 0xFFC07A50, 0xFF8A6AB0};
                int[] cb = {0xFF98D0C8, 0xFFB87090, 0xFF8A9AE8, 0xFF86A4C8, 0xFFD89A70, 0xFFA088C8};
                int k = rm0 == 5 ? 0 : rm0 == 8 ? 1 : rm0 == 11 ? 2 : rm0 == 4 ? 3 : rm0 == 13 ? 4 : 5;
                c = edge ? ca[k] : (((tx + ty) & 1) == 0 ? cb[k] : Gfx.lighter(cb[k], 0.06F));
                plain = false;
            }
        }
        fillC(g, px, py, px + T, py + T, c);
        fillC(g, px, py + T - 1, px + T, py + T, 0x14000000);
        fillC(g, px + T - 1, py, px + T, py + T, 0x14000000);
        int lc = lampCol[ty][tx];
        if ((lc >>> 24) != 0) fillC(g, px, py, px + T, py + T, lc);   // the pool of light under a ceiling lamp
        boolean wU = wallAt(tx, ty - 1), wD = wallAt(tx, ty + 1), wL = wallAt(tx - 1, ty), wR = wallAt(tx + 1, ty);
        if (wU) { fillC(g, px, py, px + T, py + 3, 0x40000000); fillC(g, px, py + 3, px + T, py + 5, 0x20000000); }     // the shadow of the wall
        if (wL) { fillC(g, px, py, px + 2, py + T, 0x30000000); fillC(g, px + 2, py, px + 3, py + T, 0x14000000); }
        if (wR) { fillC(g, px + T - 2, py, px + T, py + T, 0x30000000); fillC(g, px + T - 3, py, px + T - 2, py + T, 0x14000000); }
        if (wD) fillC(g, px, py + T - 2, px + T, py + T, 0x2A000000);
        if (!wU && !wL && wallAt(tx - 1, ty - 1)) fillC(g, px, py, px + 3, py + 3, 0x22000000);                         // the dark in a corner
        if (!wU && !wR && wallAt(tx + 1, ty - 1)) fillC(g, px + T - 3, py, px + T, py + 3, 0x22000000);
        if (!wD && !wL && wallAt(tx - 1, ty + 1)) fillC(g, px, py + T - 3, px + 3, py + T, 0x1C000000);
        if (!wD && !wR && wallAt(tx + 1, ty + 1)) fillC(g, px + T - 3, py + T - 3, px + T, py + T, 0x1C000000);
        if (!blk[ty][tx]) {                                         // a big thing throws its shadow to the right and down
            if (tx > 0 && blk[ty][tx - 1]) fillC(g, px, py, px + 3, py + T, 0x2A000000);
            if (ty > 0 && blk[ty - 1][tx]) fillC(g, px, py, px + T, py + 3, 0x2A000000);
        }
        if (rm0 == ROOMS.length) {                                  // a hall tile next to a room: the sill of the door, in pastel hazard stripes
            for (int k = 0; k < 4; k++) {
                int col = (k & 1) == 0 ? 0xFFE6D08A : 0xFF7466BE;
                if (roomFloor(tx - 1, ty)) fillC(g, px, py + k * 2, px + 2, py + k * 2 + 2, col);
                if (roomFloor(tx + 1, ty)) fillC(g, px + T - 2, py + k * 2, px + T, py + k * 2 + 2, col);
                if (roomFloor(tx, ty - 1)) fillC(g, px + k * 2, py, px + k * 2 + 2, py + 2, col);
                if (roomFloor(tx, ty + 1)) fillC(g, px + k * 2, py + T - 2, px + k * 2 + 2, py + T, col);
            }
            if (wallDist[ty][tx] == 2 && ((tx + ty) & 3) == 0) fillC(g, px + 2, py + 3, px + 6, py + 5, 0x30FFFFFF);       // the dashes of a guide line down the middle of a hall
        } else {                                                    // the groove of the door on the room's side
            if (hallFloor(tx - 1, ty)) fillC(g, px, py, px + 1, py + T, 0x34000000);
            if (hallFloor(tx + 1, ty)) fillC(g, px + T - 1, py, px + T, py + T, 0x34000000);
            if (hallFloor(tx, ty - 1)) fillC(g, px, py, px + T, py + 1, 0x34000000);
            if (hallFloor(tx, ty + 1)) fillC(g, px, py + T - 1, px + T, py + T, 0x34000000);
        }
        float h = Gfx.hash(tx * 7 + 3, ty * 13 + 5);
        if (st != 0 && h > 0.988F) { fillC(g, px + 1, py + 4, px + 4, py + 5, 0x28000000); fillC(g, px + 4, py + 5, px + 7, py + 6, 0x28000000); }    // a crack in the floor
        switch (st) {
            case 0 -> {
                if (plain) {                                        // wooden planks
                    fillC(g, px, py + 3, px + T, py + 4, 0x0E3A2010);
                    fillC(g, px + 1 + (int) (h * 5F), py + 4, px + 2 + (int) (h * 5F), py + T, 0x0E3A2010);
                }
            }
            case 6 -> {
                if (h < 0.14F) {
                    fillC(g, px + 2, py + 4, px + 3, py + 7, 0xFF5FA84A); fillC(g, px + 4, py + 3, px + 5, py + 7, 0xFF4E9A3C); fillC(g, px + 6, py + 5, px + 7, py + 7, 0xFF5FA84A);
                } else if (h < 0.2F) {
                    fillC(g, px + 3, py + 3, px + 5, py + 5, h < 0.17F ? 0xFFFFFFFF : 0xFFF58FB8);
                    fillC(g, px + 4, py + 4, px + 5, py + 5, 0xFFF3D46A);
                } else if (h > 0.9F) fillC(g, px + 2, py + 2, px + 6, py + 3, 0x1AFFFFAA);      // a sunbeam on the grass
            }
            case 1 -> {
                fillC(g, px + 1, py + 1, px + 2, py + 2, 0xFF6A7488); fillC(g, px + T - 3, py + T - 3, px + T - 2, py + T - 2, 0xFF6A7488);
                if ((tx & 3) == 0) fillC(g, px, py, px + 1, py + T, 0x22000000);
            }
            case 2 -> {
                if ((ty & 3) == 0) {
                    fillC(g, px, py + 3, px + T, py + 4, 0xFF3A4580);
                    if (h < 0.3F) fillC(g, px + 3, py + 2, px + 5, py + 5, 0xFFF3D46A);
                }
            }
            case 3 -> { fillC(g, px, py + 3, px + T, py + 4, 0x22000000); fillC(g, px, py + 7, px + T, py + 8, 0x22000000); }
            case 4 -> {
                fillC(g, px, py, px + T, py + 1, 0x33FFFFFF);
                if (h < 0.08F) fillC(g, px + 3, py + 3, px + 4, py + 4, 0xFFFFFFFF);
            }
            case 5 -> { if (h < 0.2F) fillC(g, px + 2 + (int) (h * 20F) % 4, py + 2 + (int) (h * 40F) % 4, px + 3 + (int) (h * 20F) % 4, py + 3 + (int) (h * 40F) % 4, 0xFFE8F4FF); }
            case 7 -> {
                if (h < 0.04F) fillC(g, px + 2, py + 3, px + 6, py + 5, 0x22FFFFFF);
                if (((tx + ty * 3) & 7) == 0) fillC(g, px + 3, py + 3, px + 5, py + 4, 0x40FFFFFF);
                if (((tx & 1) == 0) && ((ty & 1) == 0)) { fillC(g, px + 1, py + 1, px + 2, py + 2, 0x26FFFFFF); fillC(g, px + T - 2, py + T - 2, px + T - 1, py + T - 1, 0x1E000000); }
            }
            case 8 -> {                                             // the reactor: hazard stripes along the walls
                for (int k = 0; k < 4; k++) {
                    int col = ((tx + ty + k) & 1) == 0 ? 0xFFF3D46A : 0xFF2A2A2A;
                    if (wallAt(tx, ty - 1)) fillC(g, px + k * 2, py, px + k * 2 + 2, py + 2, col);
                    if (wallAt(tx, ty + 1)) fillC(g, px + k * 2, py + T - 2, px + k * 2 + 2, py + T, col);
                    if (wallAt(tx - 1, ty)) fillC(g, px, py + k * 2, px + 2, py + k * 2 + 2, col);
                    if (wallAt(tx + 1, ty)) fillC(g, px + T - 2, py + k * 2, px + T, py + k * 2 + 2, col);
                }
            }
            case 9 -> { if ((((tx >> 1) + (ty >> 1)) & 1) == 0) fillC(g, px, py, px + T, py + T, 0x14000000); }
            case 10 -> { if (h < 0.035F) { fillC(g, px + 2, py + 3, px + 6, py + 6, 0xFFFFFFFF); fillC(g, px + 3, py + 4, px + 5, py + 5, 0xFFC8C0E8); } }
            case 11 -> {
                if ((ty & 1) == 0) fillC(g, px, py, px + T, py + 1, 0x22FFFFFF);
                if (h < 0.08F) fillC(g, px + 1, py + 5, px + 7, py + 6, 0xFF2A2A44);
            }
            case 12 -> {
                fillC(g, px + 1, py + 1, px + 2, py + 2, 0xFF8A6A50); fillC(g, px + T - 2, py + T - 2, px + T - 1, py + T - 1, 0xFF8A6A50);
                if (h < 0.1F) fillC(g, px + 1, py + 4, px + 7, py + 5, 0xFFE08A3C);
            }
            case 13 -> {
                if (!bakeMode && ((tx * 3 + ty * 5 + ticks / 10) & 7) == 0) fillC(g, px + 3, py + 3, px + 5, py + 5, 0x66AFEFFF);
                if (((tx + ty) & 3) == 0) fillC(g, px, py + 3, px + T, py + 4, 0x18AFEFFF);
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ the still picture of the whole station

    /** The station as one texture: the space with its stars, the floors with the light on them, the walls. Painted once, then every frame is a single picture. */
    private boolean ensureWorld() {
        if (worldFailed) return false;
        if (world != null && world.tag == 1) return true;
        try {
            TexCache.Tex t = TexCache.get("hive_world", MW * T, MH * T);
            if (t.tag != 1) { TexCache.render(t, 0, 0, this::bakeWorld); t.tag = 1; }
            world = t;
            return true;
        } catch (RuntimeException e) {
            worldFailed = true;
            return false;
        }
    }

    private void bakeWorld(GuiGraphics c) {
        clipW = MW * T; clipH = MH * T;
        bakeMode = true;
        try {
            paintSpace(c);
            for (int ty = 0; ty < MH; ty++) for (int tx = 0; tx < MW; tx++) drawTile(c, tx, ty, tx * T, ty * T);
            bakeDecals(c);
        } finally {
            bakeMode = false; clipW = W; clipH = H;
        }
    }

    /** The empty space around the station: a deep gradient, a few soft nebulae, a thousand stars. */
    private void paintSpace(GuiGraphics c) {
        int w = MW * T, h = MH * T;
        c.fillGradient(0, 0, w, h, 0xFF16123A, 0xFF0A0818);
        for (int i = 0; i < 9; i++) {
            int col = i % 3 == 0 ? 0xFF7A4AC8 : (i % 3 == 1 ? 0xFF3A6AD0 : 0xFFC85A9A);
            Gfx.glow(c, (int) (Gfx.hash(i * 17 + 1, 3) * w), (int) (Gfx.hash(i * 29 + 5, 7) * h), 70 + (int) (Gfx.hash(i, 11) * 50F), col, 34);
        }
        for (int i = 0; i < 1100; i++) {
            int sx = (int) (Gfx.hash(i, 101) * (w - 1)), sy = (int) (Gfx.hash(i, 203) * (h - 1));
            float b = Gfx.hash(i, 307);
            int col = i % 7 == 0 ? 0xFFFFD6F0 : (i % 5 == 0 ? 0xFFCFE4FF : 0xFFFFFFFF);
            int a = 70 + (int) (b * 150F);
            c.fill(sx, sy, sx + 1, sy + 1, Gfx.alpha(col, a));
            if (b > 0.93F) {
                c.fill(sx - 1, sy, sx + 2, sy + 1, Gfx.alpha(col, a / 3));
                c.fill(sx, sy - 1, sx + 1, sy + 2, Gfx.alpha(col, a / 3));
            }
        }
    }

    private static void ring(GuiGraphics c, int cx, int cy, int ro, int ri, int col, boolean top) {
        for (int dy = -ro; dy <= (top ? 0 : ro); dy++) {
            int xo = (int) Math.sqrt(ro * ro - dy * dy + 0.25);
            if (Math.abs(dy) < ri) {
                int xi = (int) Math.sqrt(ri * ri - dy * dy + 0.25);
                fillC(c, cx - xo, cy + dy, cx - xi, cy + dy + 1, col);
                fillC(c, cx + xi + 1, cy + dy, cx + xo + 1, cy + dy + 1, col);
            } else fillC(c, cx - xo, cy + dy, cx + xo + 1, cy + dy + 1, col);
        }
    }

    /** A faint stencil on the floor in the middle of every room, so that each one has its own sign. */
    private void bakeDecals(GuiGraphics c) {
        int col = 0x221A1030;
        for (int i = 0; i < ROOMS.length; i++) {
            int[] r = ROOMS[i];
            int cx = (r[0] * 2 + r[2]) * T / 2, cy = (r[1] * 2 + r[3]) * T / 2;
            switch (i) {
                case 1, 2 -> {                                      // a gear
                    ring(c, cx, cy, 11, 8, col, false); ring(c, cx, cy, 4, 2, col, false);
                    for (int k = 0; k < 8; k++) {
                        double a = k * Math.PI / 4;
                        int gx = cx + (int) Math.round(Math.cos(a) * 12) - 2, gy = cy + (int) Math.round(Math.sin(a) * 12) - 2;
                        fillC(c, gx, gy, gx + 4, gy + 4, col);
                    }
                }
                case 3 -> { ring(c, cx, cy, 17, 14, col, false); ring(c, cx, cy, 9, 6, col, false); ring(c, cx, cy, 3, 0, col, false); }
                case 4 -> { ring(c, cx, cy, 9, 7, col, false); ring(c, cx, cy, 3, 0, col, false); fillC(c, cx - 14, cy, cx - 9, cy + 1, col); fillC(c, cx + 10, cy, cx + 15, cy + 1, col); }
                case 5 -> { fillC(c, cx - 2, cy - 10, cx + 3, cy + 11, col); fillC(c, cx - 10, cy - 2, cx + 11, cy + 3, col); }
                case 6 -> { fillC(c, cx, cy - 11, cx + 5, cy - 4, col); fillC(c, cx - 5, cy - 5, cx + 5, cy - 1, col); fillC(c, cx - 4, cy - 1, cx + 1, cy + 11, col); }
                case 7 -> {
                    fillC(c, cx - 9, cy - 9, cx + 10, cy - 7, col); fillC(c, cx - 9, cy + 8, cx + 10, cy + 10, col);
                    fillC(c, cx - 9, cy - 7, cx - 7, cy + 8, col); fillC(c, cx + 8, cy - 7, cx + 10, cy + 8, col);
                    fillC(c, cx - 9, cy - 1, cx + 10, cy + 1, col);
                }
                case 8 -> {                                         // a paw
                    ring(c, cx, cy + 4, 6, 0, col, false);
                    ring(c, cx - 8, cy - 3, 3, 0, col, false); ring(c, cx - 3, cy - 8, 3, 0, col, false);
                    ring(c, cx + 3, cy - 8, 3, 0, col, false); ring(c, cx + 8, cy - 3, 3, 0, col, false);
                }
                case 9 -> {                                         // a signal
                    ring(c, cx, cy + 6, 5, 3, col, true); ring(c, cx, cy + 6, 9, 7, col, true); ring(c, cx, cy + 6, 13, 11, col, true);
                    ring(c, cx, cy + 6, 2, 0, col, false);
                }
                case 10 -> {                                        // a shield
                    fillC(c, cx - 8, cy - 10, cx + 9, cy + 1, col);
                    for (int k = 0; k < 9; k++) fillC(c, cx - 8 + k, cy + 1 + k, cx + 9 - k, cy + 2 + k, col);
                }
                case 11 -> {                                        // a compass
                    for (int d = -13; d <= 13; d++) {
                        int w = (13 - Math.abs(d)) / 4;
                        fillC(c, cx - w, cy + d, cx + w + 1, cy + d + 1, col);
                        fillC(c, cx + d, cy - w, cx + d + 1, cy + w + 1, col);
                    }
                }
                case 12 -> {                                        // a flower
                    for (int k = 0; k < 5; k++) {
                        double a = k * Math.PI * 2 / 5;
                        ring(c, cx + (int) Math.round(Math.cos(a) * 6), cy + (int) Math.round(Math.sin(a) * 6), 3, 0, col, false);
                    }
                    ring(c, cx, cy, 2, 0, col, false);
                }
                case 13 -> {                                        // a crosshair
                    ring(c, cx, cy, 11, 9, col, false);
                    fillC(c, cx - 15, cy, cx - 6, cy + 1, col); fillC(c, cx + 7, cy, cx + 16, cy + 1, col);
                    fillC(c, cx, cy - 15, cx + 1, cy - 6, col); fillC(c, cx, cy + 7, cx + 1, cy + 16, col);
                }
                default -> { }
            }
        }
    }

    /** What moves on the still picture: the decorations on the walls, sparks in the shields, twinkling stars, specks of dust in the air. */
    private void worldMotion(GuiGraphics g, int ox, int oy, int tx0, int ty0, int tx1, int ty1) {
        for (int v : decorTiles) {
            int tx = v % MW, ty = v / MW;
            if (tx >= tx0 && tx <= tx1 && ty >= ty0 && ty <= ty1) wallDecor(g, tx, ty, tx * T + ox, ty * T + oy);
        }
        for (int v : sparkleTiles) {
            int tx = v % MW, ty = v / MW;
            if (tx < tx0 || tx > tx1 || ty < ty0 || ty > ty1) continue;
            if (((tx * 3 + ty * 5 + ticks / 10) & 7) == 0) fillC(g, tx * T + ox + 3, ty * T + oy + 3, tx * T + ox + 5, ty * T + oy + 5, 0x66AFEFFF);
        }
        int wpx = MW * T;
        for (int k = 0; k < stars.length; k++) {
            int sx = stars[k] % wpx + ox, sy = stars[k] / wpx + oy;
            if (sx < 0 || sy < 0 || sx >= W || sy >= H) continue;
            fillC(g, sx, sy, sx + 1, sy + 1, Gfx.alpha(0xFFFFFFFF, TWINKLE[(ticks / 8 + k) % 6]));
        }
        for (int k = 0; k < 12; k++) {
            int sx = (int) ((Gfx.hash(k, 9) * W + ticks * (0.03F + (k % 3) * 0.015F)) % W);
            int sy = (int) ((Gfx.hash(k, 17) * H + (float) Math.sin(ticks * 0.02F + k) * 7F + H) % H);
            if (solidTile((sx - ox) / T, (sy - oy) / T)) continue;
            fillC(g, sx, sy, sx + 1, sy + 1, 0x38FFFFFF);
        }
    }

    /** The big things in the rooms (every one is 2 x 2 tiles). */
    private void drawBlock(GuiGraphics g, int bi, int ox, int oy) {
        int[] r = BLOCKS[bi];
        int x = r[0] * T + ox, y = r[1] * T + oy;
        Gfx.ellipse(g, x + 8, y + 15, 9, 3, 0x44000000);
        switch (BKIND[bi]) {
            case 0 -> {                                           // the round table with the emergency button
                Gfx.ellipse(g, x + 8, y + 9, 9, 7, 0xFFB98A5E);
                Gfx.ellipse(g, x + 8, y + 8, 9, 7, 0xFFF2E3C6);
                Gfx.ellipse(g, x + 8, y + 8, 6, 4, 0xFFE8D2AC);
                disc(g, x + 8, y + 8, 3, 0xFFB03A32); disc(g, x + 8, y + 7, 3, 0xFFE0594F);
                rect(g, x + 7, y + 5, 2, 1, 0xFFFFB0A8);
            }
            case 1 -> {                                           // a glowing engine core
                Gfx.rrect(g, x, y + 3, 16, 12, 3, 0xFF3A4058);
                Gfx.rrect(g, x + 1, y + 3, 14, 10, 3, 0xFF59627E);
                Gfx.glow(g, x + 8, y + 8, 11, 0xFFFFB347, (ticks / 15) % 2 == 0 ? 60 : 44);
                disc(g, x + 8, y + 8, 4, 0xFFFF9A3C); disc(g, x + 8, y + 8, 2, 0xFFFFE9A0);
                rect(g, x + 1, y + 12, 14, 1, 0xFF3A4058);
            }
            case 2 -> {                                           // a fuse box with blinking lights
                Gfx.rrect(g, x + 1, y + 2, 14, 13, 2, 0xFF222C60);
                Gfx.rrect(g, x + 1, y + 2, 14, 11, 2, 0xFF3A47A0);
                for (int i = 0; i < 3; i++) {
                    int on = (ticks / 20 + i) % 3;
                    disc(g, x + 4 + i * 4, y + 5, 1, on == 0 ? 0xFF7ED957 : (on == 1 ? 0xFFF3D46A : 0xFFE0594F));
                }
                rect(g, x + 3, y + 8, 10, 1, 0xFF222C60); rect(g, x + 3, y + 10, 10, 1, 0xFF222C60);
            }
            case 3 -> {                                           // a lab bench with flasks
                Gfx.rrect(g, x, y + 5, 16, 10, 2, 0xFF9ACBC0);
                Gfx.rrect(g, x, y + 4, 16, 9, 2, 0xFFEAF6F2);
                rect(g, x + 4, y + 1, 2, 3, 0xFFD0E8E4); disc(g, x + 5, y + 7, 3, 0xFF7ED957); rect(g, x + 3, y + 6, 1, 1, 0xFFFFFFFF);
                rect(g, x + 10, y + 3, 3, 2, 0xFFD0E8E4); disc(g, x + 11, y + 8, 3, 0xFFF58FB8);
            }
            case 4 -> {                                           // a navigation console with a scanning line
                Gfx.rrect(g, x, y + 2, 16, 13, 2, 0xFF1F2E58);
                rect(g, x + 2, y + 3, 12, 7, 0xFF0E2A44);
                rect(g, x + 2, y + 3 + (ticks / 6) % 7, 12, 1, 0xFF6FE0FF);
                rect(g, x + 4, y + 5, 1, 1, 0xFFFFFFFF); rect(g, x + 10, y + 7, 1, 1, 0xFFFFFFFF); rect(g, x + 7, y + 4, 1, 1, 0xFFFFE066);
                rect(g, x + 3, y + 12, 2, 1, 0xFFE0594F); rect(g, x + 7, y + 12, 2, 1, 0xFF7ED957); rect(g, x + 11, y + 12, 2, 1, 0xFFF3D46A);
            }
            case 5 -> {                                           // a planter with a bush and flowers
                Gfx.rrect(g, x + 1, y + 8, 14, 7, 2, 0xFF6E4524);
                Gfx.rrect(g, x + 1, y + 8, 14, 5, 2, 0xFF8A5A36);
                disc(g, x + 5, y + 6, 4, 0xFF4E9A3C); disc(g, x + 11, y + 5, 4, 0xFF5FB44A); disc(g, x + 8, y + 3, 3, 0xFF7ED957);
                rect(g, x + 4, y + 5, 1, 1, 0xFFF58FB8); rect(g, x + 11, y + 4, 1, 1, 0xFFFFFFFF); rect(g, x + 8, y + 2, 1, 1, 0xFFF3D46A);
            }
            default -> {                                          // crates
                rect(g, x + 1, y + 7, 8, 8, 0xFF8A5A2E); rect(g, x + 2, y + 8, 6, 6, 0xFFC48A52); rect(g, x + 2, y + 8, 6, 1, 0xFFE0AB74);
                rect(g, x + 2, y + 10, 6, 1, 0xFF8A5A2E); rect(g, x + 4, y + 8, 1, 6, 0xFF8A5A2E);
                rect(g, x + 8, y + 3, 7, 12, 0xFF8A5A2E); rect(g, x + 9, y + 4, 5, 10, 0xFFB67A44); rect(g, x + 9, y + 4, 5, 1, 0xFFD39A5E);
                rect(g, x + 9, y + 8, 5, 1, 0xFF8A5A2E); rect(g, x + 11, y + 4, 1, 10, 0xFF8A5A2E);
            }
        }
    }

    private boolean viewOpen;
    private float viewRad;

    /** Pets and bodies are seen through the open space only: walls hide them (the big things in the rooms do not). */
    private boolean entVis(float x, float y) {
        Actor p = act[0];
        if (!p.alive) return true;
        if (!viewOpen) return visPx(x, y);
        return dist(p.x, p.y, x, y) < viewRad && losView(p.x, p.y, x, y);
    }

    private boolean losView(float x0, float y0, float x1, float y1) {
        int tx = (int) (x1 / T), ty = (int) (y1 / T);
        float dx = x1 - x0, dy = y1 - y0;
        int n = (int) (Math.sqrt(dx * dx + dy * dy) / 3F) + 1;
        for (int i = 1; i < n; i++) {
            float f = i / (float) n;
            int cx = (int) ((x0 + dx * f) / T), cy = (int) ((y0 + dy * f) / T);
            if (cx == tx && cy == ty) return true;
            if (solidTile(cx, cy) && !blk[cy][cx]) return false;
        }
        return true;
    }

    private boolean visPx(float x, float y) {
        int tx = (int) (x / T), ty = (int) (y / T);
        return tx >= 0 && ty >= 0 && tx < MW && ty < MH && vis[ty][tx];
    }

    private void marker(GuiGraphics g, int tx, int ty, int ox, int oy, int col, boolean on) {
        if (!visPx(tx * T + 4, ty * T + 4) || !on) return;
        int sx = tx * T + ox + 4, sy = ty * T + oy + 4 - ((ticks / 12) % 2);
        Gfx.ellipse(g, sx, sy + 3, 5, 2, (col & 0xFFFFFF) | 0x66000000);
        Gfx.glow(g, sx, sy - 5, 8, col, 60);
        Gfx.rrect(g, sx - 3, sy - 10, 7, 8, 3, 0xFF3A2A10);
        Gfx.rrect(g, sx - 2, sy - 9, 5, 6, 2, col);
        rect(g, sx, sy - 8, 1, 3, 0xFF3A2A10);
        rect(g, sx, sy - 4, 1, 1, 0xFF3A2A10);
    }

    // ------------------------------------------------------------------ drawing: HUD, tasks, map, splash

    // ------------------------------------------------------------------ pixel icons (9 px wide) instead of words

    private static final String[][] ICON = {
            {"#........", "##.......", "###......", "####.....", "#####....", "######...", "#####....", "##.##....", "#...##..."},
            {"....#....", "...###...", "..#####..", "..#####..", ".#######.", ".#######.", "#########", "....#...."},
            {"........#", ".......##", "......##.", ".....##..", "#...##...", ".#.##....", "..###....", ".##.#....", "##......."},
            {"#########", "#.......#", "#########", "#.......#", "#########", "#.......#", "#########"},
            {"...###...", "..###....", ".###.....", ".###.....", ".###.....", "..###....", "...######", ".....###."},
            {"....###..", "...###...", "..###....", ".#######.", "...###...", "..###....", ".###.....", "###......"},
            {"#########", "#.#...#.#", "#.#.#.#.#", "#.#.#.#.#", "#...#...#", "#########"},
            {"..#####..", ".#.....#.", "#.#####.#", "#.#...#.#", "#.#####.#", ".#.....#.", "..#####.."},
            {"#########", "#########", "#########", "#########", ".#######.", "..#####..", "...###...", "....#...."},
            {".####....", "#....#...", "#....#...", "#....#...", ".####....", ".....##..", "......##.", ".......##"},
            {"#.......#", "##.....##", ".##...##.", "..##.##..", "...###...", "..##.##..", ".##...##.", "##.....##"},
            {"....#....", "...###...", "..#####..", "....#....", "....#....", "....#....", "#########"},
            {"..###....", "..#.#....", "#######..", "#.....#..", "#.###.#..", "#.....#..", "#######.."},
            {"##.##.##.", "##.##.##.", ".........", "##.##.##.", "##.##.##.", ".........", "##.##.##.", "##.##.##."},
            {"..#...#..", "...#.#...", "..#####..", ".#######.", "#.#####.#", "..#####..", ".#.###.#."},
            {"..#####..", ".#.....#.", "#...#...#", "#..#....#", "#.......#"},
            {"...####..", "...#..#..", "...#..#..", "...#..#..", ".###.###.", "####.###.", ".##...#.."},
            {".#######.", "#.......#", "#.####..#", "#.####..#", ".#######."},
            {"....#....", "...###...", "..#####..", ".#######.", "..#####..", "...###...", "....#...."},
            {"######...", "#....#...", "#..######", "#..#....#", "####....#", "...#....#", "...######"}
    };
    private static final int[] ACT_ICON = {0, 1, 2, 3, 4, 5, 6, 7};      // the action -> its icon (A_ROLE is replaced by the role's own)
    private static final String[] ACT_HK = {"E", "R", "Q", "V", "1", "2", "M", "F"};

    private static void candy(GuiGraphics g, int cx, int cy) {
        rect(g, cx - 6, cy - 2, 3, 5, 0xFFFFE066);
        rect(g, cx + 4, cy - 2, 3, 5, 0xFFFFE066);
        disc(g, cx, cy + 1, 4, 0xFFB0527A);
        disc(g, cx, cy, 4, 0xFFF58FB8);
        rect(g, cx - 2, cy - 2, 2, 1, 0xCCFFFFFF);
        rect(g, cx, cy - 3, 1, 6, 0x88FFFFFF);
    }

    private static void icon(GuiGraphics g, int id, int cx, int cy, int col) {
        String[] r = ICON[id];
        int x0 = cx - 4, y0 = cy - r.length / 2;
        for (int pass = 0; pass < 2; pass++) {
            int c = pass == 0 ? 0x66000000 : col, o = pass == 0 ? 1 : 0;
            for (int j = 0; j < r.length; j++) {
                for (int i = 0; i < r[j].length(); i++) if (r[j].charAt(i) == '#') rect(g, x0 + i + o, y0 + j + o, 1, 1, c);
            }
        }
    }

    /** The icon of a role (also the one shown beside the role's name). */
    private static int roleIcon(int role) {
        return switch (role) { case R_ENG -> 7; case R_GRD -> 8; case R_DET -> 9; case R_KIL -> 2; default -> 5; };
    }

    private void renderHud(GuiGraphics g) {
        Actor p = act[0];
        Gfx.bubble(g, 3, 3, 74, 9, 3, 0xCC1A1440);
        int w = totalTasks == 0 ? 0 : 68 * doneTasks / totalTasks;
        if (w > 0) { Gfx.bubble(g, 5, 5, Math.max(3, w), 5, 2, 0xFF7ED957); rect(g, 6, 5, Math.max(1, w - 2), 1, 0x66FFFFFF); }
        Fit.str(g, font(), tr("cutemod.hive.tasks"), 80, 3, 0xFFFFFFFF, true, 140);
        String roleS = tr(act[0].role > 0 ? "cutemod.hive.role." + act[0].role : (playerImp ? "cutemod.hive.role.imp" : "cutemod.hive.role.crew"));
        int rx = W - 4 - Math.min(tw(roleS), 66);
        Fit.str(g, font(), roleS, rx, 3, playerImp ? 0xFFFF6A6A : 0xFF7FE0FF, true, W - 2);
        if (act[0].role > 0) icon(g, roleIcon(act[0].role), rx - 7, 8, playerImp ? 0xFFFF6A6A : 0xFF7FE0FF);
        int ti = nextTask(p);
        if (ti >= 0) {
            int s = p.spot[ti];
            icon(g, 10 + KIND[s], 9, 18, 0xFFFFE066);
            Fit.str(g, font(), tr("cutemod.hive.task." + KIND[s]) + ", " + rm(roomTile(TX[s], TY[s])), 16, 13, 0xFFFFE066, true, W - 4);
        }
        if (boostT > 0) {
            candy(g, 10, 40);
            rect(g, 18, 38, 34, 5, 0xAA1A1440);
            rect(g, 19, 39, 32 * boostT / 480, 3, 0xFFF58FB8);
        }
        boolean flash = (ticks / 15) % 2 == 0;
        if (lightsOut) ctextW(g, tr("cutemod.hive.sab.lights"), W / 2, 25, W - 8, flash ? 0xFFFFB347 : 0xFFFF6A6A);
        if (reactorOn) ctextW(g, tr("cutemod.hive.sab.reactor", (reactorT + 59) / 60), W / 2, 25, W - 8, flash ? 0xFFFF4040 : 0xFFFFB0A8);
        if (hold > 0) {
            rect(g, W / 2 - 30, 38, 60, 6, 0xAA000000);
            rect(g, W / 2 - 29, 39, 58 * hold / 120, 4, 0xFF7ED957);
            ctext(g, tr("cutemod.hive.hold"), W / 2, 46, 0xFFFFFFFF);
        }
        if (hudT > 0) { rect(g, 0, 46, W, 12, 0x99000000); ctextW(g, hudMsg, W / 2, 48, W - 8, 0xFFFFE066); }
        if (p.vented) ctextW(g, tr("cutemod.hive.ventmsg"), W / 2, 25, W - 8, 0xFFFFFFFF);
        else if (!p.alive) ctextW(g, tr(p.imp ? "cutemod.hive.dead.imp" : "cutemod.hive.dead"), W / 2, 25, W - 8, 0xFFB8B0F0);
        Fit.str(g, font(), rm(roomAt(p.x, p.y)), 5, H - 25, 0xFFFFFFFF, true, 100);
        int[] acts = actsOf();
        String tip = null;
        int tipX = 0;
        for (int i = 0; i < acts.length; i++) {
            int a = acts[i], x = 4 + i * 36, y = H - 14;
            boolean on = actionOn(a);
            boolean hov = on && in(mx, my, x, y, 34, 12);
            Gfx.bubble(g, x, y, 34, 12, 3, !on ? 0xAA2A2550 : (hov ? 0xFF8A78E8 : 0xFF6A58C8));
            String num = null;
            if (a == A_ROLE && p.role != R_GRD) num = String.valueOf(p.uses);
            if (a == A_ROLE && p.role == R_GRD && !p.shield) num = "-";
            if (a == A_KILL && p.killCd > 0) num = String.valueOf((p.killCd + 59) / 60);
            if ((a == A_DARK || a == A_CORE) && sabCd > 0 && !lightsOut && !reactorOn) num = String.valueOf((sabCd + 59) / 60);
            int ic = a == A_ROLE ? roleIcon(p.role) : ACT_ICON[a];
            int col = on ? 0xFFFFFFFF : 0x88FFFFFF;
            if (num == null) icon(g, ic, x + 17, y + 6, col);
            else { icon(g, ic, x + 10, y + 6, col); ctextW(g, num, x + 26, y + 2, 14, col); }
            if (in(mx, my, x, y, 34, 12)) tip = (a == A_ROLE ? tr("cutemod.hive.role." + p.role) : tr("cutemod.hive.a." + ACT_KEYS[a])) + " [" + ACT_HK[a] + "]";
            if (in(mx, my, x, y, 34, 12)) tipX = x + 17;
        }
        if (tip != null) {                                         // what the icon means, while the mouse is over it
            int tw0 = tw(tip) + 8, tx = Math.max(2, Math.min(W - 2 - tw0, tipX - tw0 / 2));
            rect(g, tx, H - 29, tw0, 11, 0xDD000000);
            Fit.str(g, font(), tip, tx + 4, H - 28, 0xFFFFFFFF, false, W - 2);
        }
    }

    private boolean actionOn(int a) {
        Actor p = act[0];
        switch (a) {
            case A_USE: {
                if (p.vented || (!p.alive && p.imp)) return false;
                if (lightsOut && !p.imp && near(p, LX * T + 4, LY * T + 4, 16)) return true;
                for (int i = 0; i < PER; i++) if (!p.done[i] && near(p, TX[p.spot[i]] * T + 4, TY[p.spot[i]] * T + 4, 14)) return true;
                if (p.alive && near(p, CSX * T + 4, CSY * T + 4, 14)) return true;
                return p.alive && !buttonUsed && !lightsOut && !reactorOn && near(p, BX, BY, 26);
            }
            case A_REPORT: {
                if (!p.alive || p.vented) return false;
                for (Body d : bodies) if (!d.reported && dist(p.x, p.y, d.x, d.y) < 24 && los(p.x, p.y, d.x, d.y)) return true;
                return false;
            }
            case A_KILL: return p.killCd <= 0 && killTarget() != null;
            case A_VENT: return p.alive && (p.vented || nearVent(p.x, p.y, 14) >= 0);
            case A_ROLE: {
                if (!p.alive) return false;
                if (p.role == R_ENG) return p.vented || (p.uses > 0 && nearVent(p.x, p.y, 14) >= 0);
                return p.role == R_DET && detTarget() != null;
            }
            case A_DARK:
            case A_CORE: return sabCd <= 0 && !lightsOut && !reactorOn;
            default: return true;
        }
    }

    private void renderTask(GuiGraphics g) {
        g.fill(0, 0, W, H, 0xAA000000);
        Gfx.bubble(g, PX, PY, PW, PH, 6, 0xFF2E2860);
        ctext(g, tr("cutemod.hive.task." + tKind), W / 2, PY + 4, 0xFFFFFFFF);
        ctextW(g, tr("cutemod.hive.t." + tKind), W / 2, PY + 15, PW - 24, 0xFFB8B0F0);
        boolean hx = in(mx, my, PX + PW - 15, PY + 2, 13, 13);
        rect(g, PX + PW - 15, PY + 2, 13, 13, hx ? 0xFFFF7A70 : 0xFFE0594F);
        ctext(g, "x", PX + PW - 8, PY + 4, 0xFFFFFFFF);
        switch (tKind) {
            case K_WIRES -> {
                for (int i = 0; i < 4; i++) {
                    int y = 48 + i * 22;
                    rect(g, 20, y - 7, 18, 14, 0xFF3A3470);
                    rect(g, 24, y - 2, 14, 4, WIRE_COL[i]);
                    if (wsel == i) Gfx.outline(g, 20, y - 7, 18, 14, 0xFFFFFFFF);
                    rect(g, PX + PW - 28, y - 7, 18, 14, 0xFF3A3470);
                    rect(g, PX + PW - 28, y - 2, 14, 4, WIRE_COL[wr[i]]);
                }
                for (int i = 0; i < 4; i++) if (wc[i] >= 0) Gfx.line(g, 38, 48 + i * 22, PX + PW - 28, 48 + wc[i] * 22, WIRE_COL[i]);
                if (wsel >= 0) Gfx.line(g, 38, 48 + wsel * 22, mx, my, WIRE_COL[wsel]);
            }
            case K_UPLOAD -> {
                if (!upOn || upStall) {
                    boolean h = in(mx, my, 80, 62, 60, 20);
                    boolean blink = upStall && (ticks / 10) % 2 == 0;
                    Gfx.bubble(g, 80, 62, 60, 20, 5, blink ? 0xFFE0594F : (h ? 0xFF8A78E8 : 0xFF6A58C8));
                    ctextW(g, tr(upStall ? "cutemod.hive.retry" : "cutemod.hive.start"), 110, 68, 52, 0xFFFFFFFF);
                }
                rect(g, 40, 96, 140, 12, 0xFF1A1630);
                rect(g, 41, 97, 138 * upT / 300, 10, upStall ? 0xFFE0594F : 0xFF7ED957);
                for (int k = 1; k <= 2; k++) rect(g, 40 + (k == 1 ? 42 : 87), 94, 1, 16, 0xFFB8B0F0);      // where the connection breaks
                if (upOn && !upStall) for (int i = 0; i < 3; i++) rect(g, 98 + i * 8, 52 - (ticks / 6 + i) % 3 * 2, 5, 2, 0xFF6FE0FF);
            }
            case K_FUEL -> {
                Gfx.outline(g, 70, 36, 40, 88, 0xFFFFFFFF);
                rect(g, 71, 37, 38, 86, 0xFF1A1630);
                int h = (int) (84 * fuel / 100F);
                rect(g, 72, 122 - h, 36, h, 0xFFF5A04A);
                rect(g, 72, 122 - h, 36, 2, 0xFFFFD08A);
                ctext(g, "SPACE", 150, 66, 0xFFB8B0F0);
                rect(g, 126, 36, 12, 88, 0xFF1A1630);                    // the heat of the pump
                int hh = (int) (86 * fuelHeat / 100F);
                rect(g, 127, 123 - hh, 10, hh, fuelLock > 0 ? 0xFFE0594F : (fuelHeat > 70 ? 0xFFFFB347 : 0xFF6FE0FF));
                if (fuelLock > 0) ctextW(g, tr("cutemod.hive.hot"), 168, 96, 50, (ticks / 8) % 2 == 0 ? 0xFFFF6A6A : 0xFFFFB0A8);
            }
            case K_KEYPAD -> {
                for (int i = 0; i < 6; i++) {
                    boolean d = i < knext;
                    boolean h = !d && in(mx, my, kx[i] - 12, ky[i] - 10, 24, 20);
                    Gfx.bubble(g, kx[i] - 12, ky[i] - 10, 24, 20, 4, d ? 0xFF3E8F55 : (h ? 0xFF8A78E8 : 0xFF5A4AA0));
                    ctext(g, String.valueOf(i + 1), kx[i], ky[i] - 4, 0xFFFFFFFF);
                }
            }
            case K_BUGS -> {
                for (int i = 0; i < 8; i++) {
                    if (bdead[i]) continue;
                    int x = (int) bx[i], y = (int) by[i];
                    boolean fly = i >= 6;
                    if (fly) Gfx.glow(g, x, y, 9, 0xFF7ED957, 60);
                    disc(g, x, y, 4, fly ? 0xFF7ED957 : 0xFFF3D46A);
                    rect(g, x - 1, y - 3, 2, 6, fly ? 0xFF2A6A3A : 0xFF3A2A10);
                    rect(g, x - 5, y - 5, 3, 2, 0xAAFFFFFF);
                    rect(g, x + 3, y - 5, 3, 2, 0xAAFFFFFF);
                }
            }
            case K_SIMON -> {
                int[] pc = {0xFFE0594F, 0xFF4A8FE0, 0xFFF3D46A, 0xFF7ED957};
                int lit = sqFlT > 0 ? sqFl : (sqShow && sqT >= 0 && sqT % 32 < 22 && sqT / 32 < sqLen ? sq[sqT / 32] : -1);
                for (int i = 0; i < 4; i++) {
                    int x = 60 + (i % 2) * 52, y = 40 + (i / 2) * 38;
                    Gfx.bubble(g, x, y, 48, 30, 5, i == lit ? Gfx.lighter(pc[i], 0.45F) : Gfx.darker(pc[i], 0.45F));
                    if (i == lit) Gfx.outline(g, x, y, 48, 30, 0xFFFFFFFF);
                }
                ctext(g, (sqRound + 1) + "/3   " + (sqShow ? "..." : sqIn + " / " + sqLen), W / 2, 116, 0xFFFFE066);
            }
            case K_SWITCH -> {
                for (int i = 0; i < 6; i++) {
                    int x = 28 + i * 28;
                    disc(g, x + 10, 46, 5, swT[i] ? 0xFFFFE066 : 0xFF1A1630);
                    boolean ok = swS[i] == swT[i];
                    rect(g, x, 62, 20, 38, ok ? 0xFF3E8F55 : 0xFF3A3470);
                    rect(g, x + 4, 64, 12, 34, 0xFF1A1630);
                    rect(g, x + 3, swS[i] ? 66 : 82, 14, 14, 0xFFEAE6FF);
                    rect(g, x + 3, swS[i] ? 66 : 82, 14, 2, 0xFFFFFFFF);
                    if (in(mx, my, x, 62, 20, 38)) {                   // a hint: which neighbours go with it
                        for (int k = Math.max(0, i - 1); k <= Math.min(5, i + 1); k++) rect(g, 28 + k * 28 + 6, 104, 8, 2, 0xFFFFE066);
                    }
                }
            }
            case K_SORT -> {
                int[] pc = {0xFFE0594F, 0xFF4A8FE0, 0xFFF3D46A};
                for (int i = 0; i < 3; i++) {
                    boolean h = in(mx, my, 30 + i * 56, 94, 48, 24);
                    Gfx.bubble(g, 30 + i * 56, 94, 48, 24, 5, h ? Gfx.lighter(pc[i], 0.2F) : Gfx.darker(pc[i], 0.25F));
                }
                disc(g, W / 2, 62, 11, Gfx.darker(pc[sortC], 0.5F));
                disc(g, W / 2, 61, 10, pc[sortC]);
                rect(g, W / 2 - 4, 56, 3, 2, 0x88FFFFFF);
                rect(g, W / 2 - 30, 78, 60, 4, 0xFF1A1630);                // time to throw the sample
                rect(g, W / 2 - 29, 79, 58 * sortT / Math.max(1, sortMax), 2, sortT * 3 < sortMax ? 0xFFE0594F : 0xFF7ED957);
                ctext(g, sortN + " / 8", W / 2, 124, 0xFFFFE066);
            }
            case K_PAIRS -> {
                int[] pc = {0xFFE0594F, 0xFF4A8FE0, 0xFF7ED957, 0xFFF3D46A};
                for (int i = 0; i < 8; i++) {
                    int x = 36 + (i % 4) * 38, y = 42 + (i / 4) * 40;
                    boolean up = pcUp[i];
                    Gfx.bubble(g, x, y, 34, 34, 5, up ? 0xFFEAE6FF : (in(mx, my, x, y, 34, 34) ? 0xFF8A78E8 : 0xFF5A4AA0));
                    if (up) {
                        int cx = x + 17, cy = y + 17;
                        switch (pcV[i]) {
                            case 0 -> disc(g, cx, cy, 9, pc[0]);
                            case 1 -> rect(g, cx - 8, cy - 8, 16, 16, pc[1]);
                            case 2 -> { rect(g, cx - 3, cy - 10, 6, 20, pc[2]); rect(g, cx - 10, cy - 3, 20, 6, pc[2]); }
                            default -> { for (int j = -9; j <= 9; j += 2) rect(g, cx - (9 - Math.abs(j)), cy + j, 2 * (9 - Math.abs(j)) + 1, 2, pc[3]); }
                        }
                        if (pcOk[i]) Gfx.outline(g, x, y, 34, 34, 0xFF3E8F55);
                    } else ctext(g, "?", x + 17, y + 13, 0xFFFFFFFF);
                }
            }
            default -> {
                rect(g, 30, 70, 160, 14, 0xFF1A1630);
                rect(g, 30 + cz, 70, czw, 14, 0xFF3E8F55);
                rect(g, 30 + (int) cm - 1, 66, 3, 22, 0xFFFFFFFF);
                ctext(g, chit + " / 4", W / 2, 100, 0xFFFFE066);
            }
        }
        if (tDone > 0) ctext(g, "OK!", W / 2, 118, 0xFF7ED957);
    }

    private void renderMap(GuiGraphics g) {
        Actor p = act[0];
        g.fill(0, 0, W, H, 0xDD000000);
        final float sc = 1.6F;
        int ox = 14, oy = 12;
        for (int[] r : mapRuns) g.fill(ox + (int) (r[0] * sc), oy + (int) (r[1] * sc), ox + (int) ((r[0] + r[2]) * sc), oy + (int) ((r[1] + 1) * sc), r[3]);
        for (int i = 0; i < VX.length; i++) mapDot(g, ox, oy, sc, VX[i] + 0.5F, VY[i] + 0.5F, 1, 0xFF1A1630);
        mapDot(g, ox, oy, sc, CSX + 0.5F, CSY + 0.5F, 1, 0xFF6FE0FF);
        for (int i = 0; i < PER; i++) if (!p.done[i]) mapDot(g, ox, oy, sc, TX[p.spot[i]] + 0.5F, TY[p.spot[i]] + 0.5F, 1, 0xFFFFE066);
        boolean fl = (ticks / 15) % 2 == 0;
        if (lightsOut && fl) mapDot(g, ox, oy, sc, LX + 0.5F, LY + 0.5F, 2, 0xFFFFB347);
        if (reactorOn && fl) for (int i = 0; i < 2; i++) if (!consoleOk[i]) mapDot(g, ox, oy, sc, CX[i] + 0.5F, CY[i] + 0.5F, 2, 0xFFE0594F);
        if ((ticks / 10) % 2 == 0) disc(g, ox + (int) (p.x / T * sc), oy + (int) (p.y / T * sc), 2, 0xFFFFFFFF);
        for (int i = 0; i < ROOMS.length; i++) {
            int[] r = ROOMS[i];
            ctextW(g, rm(i), ox + (int) ((r[0] + r[2] / 2F) * sc), oy + (int) ((r[1] + r[3] / 2F) * sc) - 4, Math.max(36, (int) (r[2] * sc)), 0xFFFFFFFF);
        }
    }

    private void mapDot(GuiGraphics g, int ox, int oy, float sc, float tx, float ty, int half, int col) {
        rect(g, ox + (int) (tx * sc) - half, oy + (int) (ty * sc) - half, half * 2 + 1, half * 2 + 1, col);
    }

    private void renderRole(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF1C1546, 0xFF0A0818);
        Gfx.glow(g, W / 2, 80, 90, playerImp ? 0xFFE0594F : 0xFF6FA8F2, 36);
        for (int i = 0; i < 20; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 8) * W), (int) (Gfx.hash(i, 9) * H), 1, i * 13 + phaseT, 0x66FFFFFF);
        int col = playerImp ? 0xFFFF6A6A : 0xFF7FE0FF;
        ctext(g, tr(playerImp ? "cutemod.hive.role.imp" : "cutemod.hive.role.crew"), W / 2, 22, col);
        String partner = "";
        if (playerImp) for (int i = 1; i < N; i++) if (act[i].imp) partner = nm(i);
        ctextW(g, playerImp ? tr("cutemod.hive.role.imp.sub", partner) : tr("cutemod.hive.role.crew.sub"), W / 2, 36, W - 10, 0xFFFFFFFF);
        if (act[0].role > 0) {
            ctextW(g, tr("cutemod.hive.role.mine", tr("cutemod.hive.role." + act[0].role)), W / 2, 49, W - 10, 0xFFFFE066);
            List<String> rows = wrap(tr("cutemod.hive.role." + act[0].role + ".d"), W - 16, W - 16);
            for (int r = 0; r < Math.min(2, rows.size()); r++) ctext(g, rows.get(r), W / 2, 61 + r * 10, 0xFFD8D0F8);
        }
        if (playerImp) {
            bigBean(g, W / 2 - 24, 106, pet[0], 2.2F, false);
            for (int i = 1; i < N; i++) if (act[i].imp) bigBean(g, W / 2 + 24, 106, pet[i], 2.2F, false);
        } else {
            for (int i = 0; i < N; i++) bigBean(g, 15 + i * 27, 103, pet[i], 1.6F, false);
        }
        ctext(g, tr("cutemod.hive.go"), W / 2, 122, 0xFFB8B0F0);
    }

    private void renderEnd(GuiGraphics g) {
        g.fill(0, 40, W, 74, 0xCC000000);
        ctext(g, tr(crewWon ? "cutemod.hive.win.crew" : "cutemod.hive.win.imp"), W / 2, 52, crewWon ? 0xFF7FE0FF : 0xFFFF6A6A);
        ctextW(g, tr(won ? "cutemod.hive.you.win" : "cutemod.hive.you.lose"), W / 2, 68, W - 10, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------------ drawing: the meeting

    private void renderMeeting(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF2A1F5C, 0xFF140F30);
        Gfx.glow(g, 40, 30, 70, 0xFF8A78E8, 40); Gfx.glow(g, 190, 120, 80, 0xFFF58FB8, 26);
        for (int i = 0; i < 14; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 5) * W), (int) (Gfx.hash(i, 6) * H), 1, i * 17 + mt, 0x55FFFFFF);
        if (mstate == M_INTRO) { renderIntro(g); return; }
        if (mstate == M_EJECT) { renderEject(g); return; }
        ctextW(g, tr(mstate == M_TALK ? "cutemod.hive.discuss" : "cutemod.hive.vote"), W / 2, 1, 68, 0xFFFFFFFF);
        for (int i = 0; i < N; i++) card(g, i);
        if (evi) renderEvi(g); else renderChat(g);
        Actor p = act[0];
        if (p.alive && (mstate == M_TALK || mstate == M_VOTE)) {
            if (mstate == M_TALK) for (int k = 0; k < 4; k++) {
                boolean hov = in(mx, my, 4 + k * 18, 1, 16, 10);
                Gfx.bubble(g, 4 + k * 18, 1, 16, 10, 3, myRxLine == shown ? 0xFF3A3560 : (hov ? 0xFF8A78E8 : 0xFF5A4AA0));
                emoji(g, 12 + k * 18, 6, k, 4);
            }
            boolean eh = in(mx, my, W - 20, 1, 16, 10);
            Gfx.bubble(g, W - 20, 1, 16, 10, 3, evi ? 0xFF3E8F55 : (eh ? 0xFF8A78E8 : 0xFF5A4AA0));
            icon(g, 9, W - 12, 6, 0xFFFFFFFF);
            if (eh) ctextW(g, tr("cutemod.hive.b.evi"), W - 40, 1, 36, 0xFFFFE066);
        }
        if (!p.alive) { ctext(g, tr("cutemod.hive.ghostwatch"), W / 2, 126, 0xFFB8B0F0); return; }
        if (mstate == M_TALK) {
            btn(g, 4, 124, 51, 13, tr("cutemod.hive.b.accuse"), sel >= 0 && pActs < 4);
            btn(g, 57, 124, 51, 13, tr("cutemod.hive.b.ask"), sel >= 0 && pActs < 4);
            btn(g, 110, 124, 51, 13, tr("cutemod.hive.b.alibi"), pActs < 4);
            btn(g, 163, 124, 53, 13, tr("cutemod.hive.b.vote"), true);
        } else if (mstate == M_VOTE) {
            btn(g, 4, 124, 106, 13, tr("cutemod.hive.b.vote"), sel >= 0);
            btn(g, 114, 124, 102, 13, tr("cutemod.hive.b.skip"), true);
        }
    }

    /** The text split into rows that fit: the first row is shorter (the speaker's name stands before it). */
    private List<String> wrap(String text, int maxFirst, int maxRest) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        int max = maxFirst;
        for (String word : text.split(" ")) {
            String t = cur.length() == 0 ? word : cur + " " + word;
            if (tw(t) <= max) { cur.setLength(0); cur.append(t); continue; }
            if (cur.length() > 0) { out.add(cur.toString()); max = maxRest; }
            while (tw(word) > max) {
                String piece = clip(word, max);
                if (piece.isEmpty()) break;
                out.add(piece);
                word = word.substring(piece.length());
                max = maxRest;
            }
            cur.setLength(0);
            cur.append(word);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private void renderChat(GuiGraphics g) {
        rect(g, 4, 76, W - 8, 46, 0x66000000);
        List<Object[]> msgs = new ArrayList<>();
        int budget = 4;
        chatOff = Math.max(0, Math.min(Math.max(0, shown - 1), chatOff));
        for (int k = shown - 1 - chatOff; k >= 0 && budget > 0; k--) {
            Line l = lines.get(k);
            String prefix = nm(l.who) + ": ";
            List<String> rows = wrap(l.text.getString(), W - 18 - (15 + tw(prefix)), W - 18 - 21);
            if (rows.size() > 3) rows = new ArrayList<>(rows.subList(0, 3));
            if (rows.size() > budget && !msgs.isEmpty()) break;
            msgs.add(0, new Object[]{l.who, prefix, rows});
            budget -= rows.size();
        }
        int y = 78;
        for (Object[] m : msgs) {
            int who = (Integer) m[0];
            String prefix = (String) m[1];
            @SuppressWarnings("unchecked")
            List<String> rows = (List<String>) m[2];
            int col = COLORS[pet[who]];
            disc(g, 9, y + 4, 3, col);
            Fit.str(g, font(), prefix, 15, y, col, false, W - 3);
            for (int r = 0; r < rows.size(); r++) {
                Fit.str(g, font(), rows.get(r), r == 0 ? 15 + tw(prefix) : 21, y, 0xFFFFFFFF, false, W - 3);
                y += 10;
            }
        }
        boolean more = shown - 1 - chatOff > 0;                    // older lines above, newer lines below
        int up = more ? 0xFFFFFFFF : 0x44FFFFFF, dn = chatOff > 0 ? 0xFFFFE066 : 0x44FFFFFF;
        for (int i = 0; i < 4; i++) {
            rect(g, W - 13 + 3 - i, 80 + i, 2 * i + 1, 1, up);
            rect(g, W - 13 + 3 - (3 - i), 112 + i, 2 * (3 - i) + 1, 1, dn);
        }
    }

    // ------------------------------------------------------------------ reactions, evidence, cameras

    /** A small round face-less icon: 0 shock (!), 1 doubt (?), 2 agree (tick), 3 angry. r is 4 or 5. */
    private static void emoji(GuiGraphics g, int cx, int cy, int k, int r) {
        int[] bg = {0xFFF3D46A, 0xFF6FA8F2, 0xFF5CC46E, 0xFFE0594F};
        int ink = k == 0 ? 0xFF3A2A10 : 0xFFFFFFFF;
        disc(g, cx, cy + 1, r, Gfx.darker(bg[k], 0.35F));
        disc(g, cx, cy, r, bg[k]);
        switch (k) {
            case 0 -> { rect(g, cx - 1, cy - 3, 2, 4, ink); rect(g, cx - 1, cy + 2, 2, 1, ink); }
            case 1 -> { rect(g, cx - 2, cy - 3, 4, 1, ink); rect(g, cx + 1, cy - 2, 1, 2, ink); rect(g, cx, cy, 1, 1, ink); rect(g, cx, cy + 2, 1, 1, ink); }
            case 2 -> { rect(g, cx - 3, cy, 1, 1, ink); rect(g, cx - 2, cy + 1, 1, 1, ink); rect(g, cx - 1, cy + 2, 1, 1, ink);
                        rect(g, cx, cy + 1, 1, 1, ink); rect(g, cx + 1, cy, 1, 1, ink); rect(g, cx + 2, cy - 1, 1, 1, ink); rect(g, cx + 3, cy - 2, 1, 1, ink); }
            default -> { rect(g, cx - 3, cy - 3, 2, 1, ink); rect(g, cx - 2, cy - 2, 1, 1, ink); rect(g, cx + 2, cy - 3, 2, 1, ink); rect(g, cx + 2, cy - 2, 1, 1, ink);
                         rect(g, cx - 2, cy - 1, 1, 1, ink); rect(g, cx + 1, cy - 1, 1, 1, ink); rect(g, cx - 2, cy + 2, 4, 1, ink); }
        }
    }

    private static int reactKind(String kind) {
        return switch (kind) {
            case "found", "kill", "vent", "button", "accuse" -> 0;
            case "near", "doubt", "liar", "point", "ask", "nothing", "cam", "quiet" -> 1;
            case "agree", "confirm", "vouch", "alibi", "mine", "pair" -> 2;
            default -> 3;
        };
    }

    /** A new line appears in the chat: it lights up the speaker's card and a couple of the others react to it. */
    private void reactTo(Line l) {
        speakW = l.who; speakT = 150;
        int k = reactKind(l.kind);
        List<Integer> c = new ArrayList<>();
        for (Actor a : act) if (a.alive && a.id != 0 && a.id != l.who) c.add(a.id);
        java.util.Collections.shuffle(c, new java.util.Random(rnd.nextLong()));
        int n = 0;
        for (int id : c) {
            if (n >= 2) break;
            if (rnd.nextInt(100) < 60) { rxK[id] = k; rxT[id] = 150 + rnd.nextInt(80); n++; }
        }
    }

    /** The player reacts to the last line (once per line): the others take it a little to heart. */
    private void playerReact(int k) {
        if (shown <= 0 || myRxLine == shown) return;
        Line l = lines.get(shown - 1);
        if (l.who == 0 || !act[l.who].alive) return;
        myRxLine = shown;
        rxK[0] = k; rxT[0] = 180;
        pling(1.0F + k * 0.1F);
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.id == l.who) continue;
            if (k == 3) c.susp[l.who] += 8;
            else if (k == 1) c.susp[l.who] += 5;
            else if (k == 2) c.susp[l.who] = Math.max(0, c.susp[l.who] - 8);
        }
    }

    private static String shortRoom(int r) {
        String s = rm(r);
        return s.length() > 9 ? s.substring(0, 8) + "." : s;
    }

    /** Where every pet was seen last (by the living crew) and how long ago; the dead show where the body was. */
    private void renderEvi(GuiGraphics g) {
        rect(g, 4, 76, W - 8, 46, 0x66000000);
        for (int i = 0; i < N; i++) {
            int x = 6 + (i / 4) * 106, y = 78 + (i % 4) * 10;       // two columns of four rows
            Actor a = act[i];
            String info;
            if (!a.alive) {
                Body bd = null;
                for (Body d : bodies) if (d.victim == i) bd = d;
                info = bd != null ? tr("cutemod.hive.e.dead", shortRoom(bd.room)) : tr("cutemod.hive.e.out");
            } else if (i == 0) info = tr("cutemod.hive.e.me", shortRoom(a.lastRoom));
            else {
                int best = -1, bt = -99999;
                for (int k = 1; k < N; k++) {
                    Actor b = act[k];
                    if (b == a || !b.alive || b.imp) continue;
                    if (b.seenTick[i] > bt) { bt = b.seenTick[i]; best = k; }
                }
                info = best < 0 || bt < 0 ? tr("cutemod.hive.e.none") : tr("cutemod.hive.e.row", shortRoom(act[best].seenRoom[i]), Math.max(0, (ticks - bt) / 60));
            }
            disc(g, x + 3, y + 4, 3, COLORS[pet[i]]);
            Fit.str(g, font(), nm(i) + ": " + info, x + 9, y, sel == i ? 0xFFFFE066 : (a.alive ? 0xFFFFFFFF : 0x99FFFFFF), false, x + 100);
        }
    }

    /** The four cameras: a small piece of the floor around each hall, with every pet that walks there. */
    private void renderCams(GuiGraphics g) {
        g.fill(0, 0, W, H, 0xAA000000);
        Gfx.bubble(g, PX, PY, PW, PH, 6, 0xFF2E2860);
        ctext(g, tr("cutemod.hive.cam"), W / 2, PY + 4, 0xFFFFFFFF);
        ctextW(g, tr("cutemod.hive.cam.sub"), W / 2, PY + 15, PW - 24, 0xFFB8B0F0);
        boolean hx = in(mx, my, PX + PW - 15, PY + 2, 13, 13);
        rect(g, PX + PW - 15, PY + 2, 13, 13, hx ? 0xFFFF7A70 : 0xFFE0594F);
        ctext(g, "x", PX + PW - 8, PY + 4, 0xFFFFFFFF);
        for (int i = 0; i < 4; i++) {
            int pxx = PX + 8 + (i % 2) * 92, pyy = 34 + (i / 2) * 46;
            rect(g, pxx, pyy, 88, 40, 0xFF0A0818);
            boolean still = ensureWorld();
            if (still) TexCache.blitRegion(g, world, pxx, pyy, (CMX[i] - 5) * T, (CMY[i] - 2) * T, 88, 40);
            for (int j = 0; j < 5; j++) {
                for (int k = 0; k < 11; k++) {
                    int tx = CMX[i] - 5 + k, ty = CMY[i] - 2 + j;
                    if (tx < 0 || ty < 0 || tx >= MW || ty >= MH) continue;
                    if (!still) drawTile(g, tx, ty, pxx + k * T, pyy + j * T);
                    else if (decorAt(tx, ty)) wallDecor(g, tx, ty, pxx + k * T, pyy + j * T);
                }
            }
            float cx = CMX[i] * T + 4, cy = CMY[i] * T + 4;
            for (Body d : bodies) {
                float dx = d.x - cx, dy = d.y - cy;
                if (Math.abs(dx) <= 34 && dy >= -9 && dy <= 14) corpse(g, pxx + 44 + (int) dx, pyy + 20 + (int) dy, pet[d.victim]);
            }
            for (Actor a : act) {
                if (!a.alive || a.vented) continue;
                float dx = a.x - cx, dy = a.y - cy;
                if (Math.abs(dx) > 34 || dy < -9 || dy > 14) continue;
                int sx = pxx + 44 + (int) dx, sy = pyy + 20 + (int) dy;
                Gfx.ellipse(g, sx, sy + 6, 5, 2, 0x55000000);
                bean(g, sx, sy, pet[a.id], a.face, false, (((int) (a.x + a.y)) / 4) & 1);
                if (a.id == 0) { rect(g, sx - 1, sy - 14, 3, 1, 0xFFFFE066); rect(g, sx, sy - 13, 1, 1, 0xFFFFE066); }
            }
            fillC(g, pxx, pyy, pxx + 88, pyy + 40, 0x1830508C);
            for (int yy = pyy; yy < pyy + 40; yy += 3) fillC(g, pxx, yy, pxx + 88, yy + 1, 0x18000000);
            rect(g, pxx, pyy, 12, 9, 0xAA000000);
            ctext(g, String.valueOf(i + 1), pxx + 6, pyy, 0xFFFFFFFF);
            rect(g, pxx + 14, pyy + 3, 3, 3, (ticks / 30) % 2 == 0 ? 0xFFE0594F : 0x66E0594F);
            Gfx.outline(g, pxx - 1, pyy - 1, 90, 42, 0xFF6A58C8);
        }
    }

    private void card(GuiGraphics g, int i) {
        Actor a = act[i];
        int x = 4 + (i % 4) * 54, y = 12 + (i / 4) * 32;
        boolean hov = a.alive && i != 0 && in(mx, my, x, y, 50, 30);
        int face = !a.alive ? 0xFF2C2650 : (sel == i ? 0xFF6A58C8 : (hov ? 0xFF4A3F90 : 0xFF3A3070));
        Gfx.bubble(g, x, y, 50, 30, 4, face);
        if (act[0].role == R_DET && chk[i] > 0) Gfx.outline(g, x, y, 50, 30, chk[i] == 2 ? 0xFFE0594F : 0xFF5CC46E);
        if (sel == i) Gfx.outline(g, x, y, 50, 30, 0xFFFFE066);
        if (speakT > 0 && speakW == i && mstate == M_TALK) Gfx.outline(g, x - 1, y - 1, 52, 32, 0xFFFFFFFF);
        ctextW(g, nm(i), x + 27, y + 1, 38, a.alive ? 0xFFFFFFFF : 0x88FFFFFF);
        bigBean(g, x + 14, y + 22, pet[i], 1.2F, !a.alive);
        if (i == 0) rect(g, x + 3, y + 3, 3, 3, 0xFFFFE066);
        else if (playerImp && a.imp) rect(g, x + 3, y + 3, 3, 3, 0xFFFF4040);
        if (rxT[i] > 0 && mstate == M_TALK && a.alive) emoji(g, x + 38, y + 21 - (rxT[i] / 12) % 2, rxK[i], 5);
        if (mstate == M_SHOW) ctext(g, tally[i] > 0 ? String.valueOf(tally[i]) : "-", x + 36, y + 14, tally[i] > 0 ? 0xFFFFE066 : 0x66FFFFFF);
        else if (!a.alive) ctext(g, "x", x + 36, y + 14, 0xFFFF6A6A);
        else if (mstate == M_VOTE && vote[i] != -3) ctext(g, "*", x + 36, y + 14, 0xFF7ED957);
    }

    private void btn(GuiGraphics g, int x, int y, int w, int h, String label, boolean on) {
        boolean hov = on && in(mx, my, x, y, w, h);
        Gfx.bubble(g, x, y, w, h, 4, !on ? 0xFF3A3560 : (hov ? 0xFF8A78E8 : 0xFF6A58C8));
        ctextW(g, label, x + w / 2, y + 3, w - 4, on ? 0xFFFFFFFF : 0x88FFFFFF);
    }

    private void renderIntro(GuiGraphics g) {
        boolean body = bodyIdx >= 0;
        int flash = (mt / 8) % 2 == 0 ? 0xFFFF5A50 : 0xFFFFB0A8;
        Gfx.bubble(g, 16, 36, W - 32, 62, 8, 0xFF3A1F3F);
        ctextW(g, tr(body ? "cutemod.hive.bodyfound" : "cutemod.hive.emergency"), W / 2, 50, W - 40, flash);
        ctextW(g, tr("cutemod.hive.by", nm(caller)), W / 2, 70, W - 40, 0xFFFFFFFF);
        bigBean(g, W / 2, 96, pet[caller], 1F, false);
    }

    private void renderEject(GuiGraphics g) {
        g.fill(0, 0, W, H, 0xFF08061A);
        for (int i = 0; i < 30; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 3) * W), (int) (Gfx.hash(i, 4) * H), 1, i * 11 + mt, 0x88FFFFFF);
        if (ejected >= 0) {
            float k = Math.min(1F, mt / 120F);
            int x = (int) (-20 + k * (W + 40));
            int y = 60 - (int) (Math.sin(k * Math.PI) * 18);
            bigBean(g, x, y, pet[ejected], 3F, false);
        }
        if (mt > 70) {
            String s = ejected >= 0 ? tr(ejWasImp ? "cutemod.hive.eject.imp" : "cutemod.hive.eject.crew", nm(ejected)) : tr("cutemod.hive.eject.none");
            ctextW(g, s, W / 2, 108, W - 10, ejected >= 0 && ejWasImp ? 0xFFFF6A6A : 0xFFFFFFFF);
        }
    }

    // ------------------------------------------------------------------ the rest of the MiniGame contract

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return Component.translatable(crewWon ? "cutemod.hive.win.crew" : "cutemod.hive.win.imp");
    }

    @Override
    public Component status() {
        if (playerImp) return Component.translatable("cutemod.hive.status.imp", kills);
        return Component.translatable("cutemod.hive.status.crew", totalTasks == 0 ? 0 : doneTasks * 100 / totalTasks);
    }

    @Override
    public String hintKey() { return "cutemod.hint.hive"; }
}
