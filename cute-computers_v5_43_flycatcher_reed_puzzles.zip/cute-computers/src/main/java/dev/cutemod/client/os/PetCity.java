package dev.cutemod.client.os;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.cutemod.ComputerColor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * The City of the pet: a long, pretty street that scrolls sideways. The pavement is where the pet walks (click the street to
 * go there, or use the arrow keys); the shops, the fountain, the benches, the musician and the two tram stops are places it can
 * visit with one click: it walks to the door, enjoys itself for a moment (little hearts, notes and steam float up) and a line says
 * what it did. Visiting a place makes the pet a little happier (once in half a minute for each place, see {@code act}); a ride on
 * the tram from one end of the street to the other is the biggest treat.
 *
 * Nothing here is saved and nothing goes to the server: the street is a quiet place of its own. The pictures are in
 * {@link CityArt}; they are baked into textures once, and only the moving things (clouds, cars, the tram, people, pigeons,
 * water, the clock, the lights of the cinema) are drawn every frame. The time of day is the real time: day, dusk (the
 * windows light up) and night (stars, the moon, lamps and neon).
 */
final class PetCity {
    private static final int W = App.W, H = App.H, HEAD = CityArt.TOP, BAR = 12, WW = CityArt.WW, SCENE_H = 166;
    private static final int TEXT = 0xFF3A2A3A;

    /** A place of the street: its clickable box (x0..x1, top..the pavement), where the pet stands to use it, and what it gives. */
    private record Poi(int id, int x0, int x1, int top, int stand, int standY, int act, int dur) {
        int area() { return (x1 - x0) * (CityArt.CURB - top); }
    }

    // id, x0, x1, top, stand x, stand y, act kind (see PetApp.cityAct), how long the pet enjoys it (ticks)
    private static final Poi[] POIS = {
            new Poi(0, 0, 78, 30, 52, 122, 3, 70),         // the book tower
            new Poi(1, 78, 160, 58, 126, 122, 1, 90),      // the cafe
            new Poi(2, 160, 222, 50, 204, 122, 2, 80),     // the bakery
            new Poi(3, 249, 311, 84, 280, 127, 7, 80),     // the fountain
            new Poi(4, 338, 424, 44, 398, 122, 3, 70),     // the cinema
            new Poi(5, 424, 494, 62, 466, 122, 3, 70),     // the flower shop
            new Poi(6, 494, 590, 40, 574, 122, 9, 80),     // the arcade
            new Poi(7, 590, 690, 25, 640, 122, 8, 60),     // the town hall with the clock
            new Poi(8, 690, 750, 54, 735, 122, 3, 70),     // the boutique
            new Poi(9, 770, 796, 88, 782, 124, 2, 80),     // the ice cream cart
            new Poi(10, 800, 838, 76, 818, 123, 5, 40),    // the east tram stop
            new Poi(11, 0, 14, 84, 24, 123, 5, 40),        // the west tram stop
            new Poi(12, 224, 242, 106, 233, 124, 4, 140),  // the musician
            new Poi(13, 240, 264, 106, 252, 123, 6, 150),  // a bench
            new Poi(14, 296, 320, 106, 308, 123, 6, 150)}; // another bench
    private static final int TRAM_W = 78, TRAM_BOTTOM = 153;
    private static final int[] STOP_X = {24, 818};          // the west and the east stop (where the doors of the tram stop)

    private final Runnable back;
    private final Supplier<ComputerColor> color;
    private final IntSupplier stage, absX, absY;
    private final Consumer<Float> snd;
    private final IntConsumer act;

    private int ticks, hover = -1, toastT, actT, ambT = 420, tramState, tramT, rideFrom;
    private double cam, camTo;
    private double px = 64, py = 122, tx = 64, ty = 122;
    private int dir = 1;
    private boolean walking, rider;
    private Poi pending, acting;
    private String toast = "";
    private final long[] last = new long[POIS.length];
    private double tramX;
    private int tramDir = 1;
    private final List<double[]> bits = new ArrayList<>();     // floating signs: x, y, vx, vy, life, kind (0 heart, 1 note, 2 sparkle, 3 steam, 4 coin)
    private final double[][] pigeons = new double[5][];        // x, y, flight left, target x
    private final double[][] walkers = new double[7][];        // x, y, dir, speed, kind, item, phase
    private final double[][] cars = new double[7][];           // x, lane, dir, speed, colour, bus

    PetCity(Runnable back, Supplier<ComputerColor> color, IntSupplier stage, Consumer<Float> snd, IntConsumer act, IntSupplier absX, IntSupplier absY) {
        this.back = back;
        this.color = color;
        this.stage = stage;
        this.snd = snd;
        this.act = act;
        this.absX = absX;
        this.absY = absY;
        for (int i = 0; i < pigeons.length; i++) pigeons[i] = new double[]{254 + i * 13, 124 + (i % 2) * 2, 0, 0};
        for (int i = 0; i < walkers.length; i++) {
            double d = i % 2 == 0 ? 1 : -1;
            walkers[i] = new double[]{40 + i * 118, 118 + (i * 5) % 9, d, 0.22 + 0.06 * (i % 4), i, i % 3, i * 7};
        }
        for (int i = 0; i < cars.length; i++) {
            int lane = i % 2;
            cars[i] = new double[]{i * 140 + 30, lane, lane == 0 ? -1 : 1, 0.8 + 0.22 * (i % 3), i, i == 3 ? 1 : 0};
        }
        cam = camTo = clampCam(px - W / 2.0);
    }

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    private static double clampCam(double c) { return Math.max(0, Math.min(WW - W, c)); }

    private int camPx() { return (int) Math.round(cam); }

    /** 0 day, 1 dusk (the evening and the early morning), 2 night: from the real clock. */
    private static int phase() {
        int h = LocalTime.now().getHour();
        if (h >= 21 || h < 6) return 2;
        return h >= 18 || h < 8 ? 1 : 0;
    }

    private static int stand(Poi p) { return p.stand(); }

    // ---------------------------------------------------------------- time
    void tick() {
        ticks++;
        GameMusic.keep("trips", false);                                   // the soft travel tune of the map plays here too
        if (toastT > 0) toastT--;
        // the pet walks
        if (walking) {
            double dx = tx - px, dy = ty - py, d = Math.hypot(dx, dy);
            if (d <= 1.4) { px = tx; py = ty; walking = false; arrived(); }
            else { double sp = Math.min(d, 1.35); px += dx / d * sp; py += dy / d * sp; if (Math.abs(dx) > 0.3) dir = dx > 0 ? 1 : -1; }
        }
        if (acting != null && !walking) {
            if (actT > 0) {
                actT--;
                if (actT % 9 == 0) spawnBit(acting);
                if (actT == 0) finishAct();
            }
        }
        tickTram();
        // the camera follows the pet (or the tram it rides)
        double focus = rider ? tramX : px;
        camTo = clampCam(focus - W / 2.0);
        cam += (camTo - cam) * 0.1;
        if (Math.abs(camTo - cam) < 0.3) cam = camTo;
        // the people on the pavement
        for (double[] w : walkers) {
            w[0] += w[2] * w[3];
            w[6] += w[3] * 2;
            if (w[0] < 12) w[2] = 1; else if (w[0] > WW - 12) w[2] = -1;
            if (Math.abs(w[0] - 290) < 3 && ticks % 3 == 0) w[0] += w[2] * 0.2;    // they slow down a little by the fountain
        }
        for (double[] c : cars) {
            c[0] += c[2] * c[3];
            if (c[2] < 0 && c[0] < -50) c[0] = WW + 50 + (ticks * 7 + c[4] * 31) % 120;
            if (c[2] > 0 && c[0] > WW + 50) c[0] = -50 - (ticks * 5 + c[4] * 17) % 120;
        }
        // the pigeons by the fountain run away from the pet and come back
        for (int i = 0; i < pigeons.length; i++) {
            double[] p = pigeons[i];
            if (p[2] > 0) {
                p[2]--;
                p[0] += (p[3] - p[0]) * 0.07;
                if (p[2] == 0) p[1] = 123 + (i % 3);
            } else if (Math.abs(px - p[0]) < 20 && Math.abs(py - p[1]) < 12) {
                p[2] = 38;
                p[3] = Math.max(236, Math.min(326, p[0] + (p[0] < px ? -1 : 1) * (36 + i * 5)));
            }
        }
        // the floating signs
        for (int i = bits.size() - 1; i >= 0; i--) {
            double[] b = bits.get(i);
            b[0] += b[2]; b[1] += b[3];
            if (b[5] == 4) b[3] += 0.12;                                                 // a coin falls
            if (--b[4] <= 0) bits.remove(i);
        }
    }

    private void spawnBit(Poi p) {
        double x = px + (ticks % 2 == 0 ? -3 : 3), y = py - 22;
        switch (p.id()) {
            case 1 -> bits.add(new double[]{x, y, 0.05, -0.35, 40, 3});
            case 3 -> bits.add(new double[]{px + 6, py - 20, 1.1, -1.2, 26, 4});
            case 12 -> bits.add(new double[]{x, y, (ticks % 2 == 0 ? -0.2 : 0.25), -0.45, 50, 1});
            case 0, 4, 6 -> bits.add(new double[]{x, y, 0, -0.4, 36, 2});
            default -> bits.add(new double[]{x, y, (ticks % 2 == 0 ? -0.15 : 0.15), -0.45, 44, 0});
        }
    }

    private void arrived() {
        Poi p = pending;
        pending = null;
        if (p == null) return;
        if (p.id() == 10 || p.id() == 11) { startRide(p.id() == 11 ? 0 : 1); return; }
        acting = p;
        actT = p.dur();
        snd.accept(1.3F + (p.id() % 4) * 0.15F);
    }

    private void finishAct() {
        Poi p = acting;
        acting = null;
        if (p == null) return;
        boolean fresh = last[p.id()] == 0 || ticks - last[p.id()] > 600;               // a place gives its joy once in half a minute
        if (fresh) { last[p.id()] = ticks; act.accept(p.act()); }
        LocalTime now = LocalTime.now();
        say(p.id() == 7 ? t("cutemod.city.do.7", String.format("%02d:%02d", now.getHour(), now.getMinute())) : t("cutemod.city.do." + p.id()));
    }

    private void say(String s) { toast = s; toastT = 200; }

    // ---------------------------------------------------------------- the tram
    private void startRide(int from) {
        if (tramState >= 2) return;
        rideFrom = from;
        tramDir = from == 0 ? 1 : -1;
        tramX = from == 0 ? -TRAM_W - 40 : WW + TRAM_W + 40;
        tramState = 2;
        snd.accept(1.7F);
    }

    private void tickTram() {
        switch (tramState) {
            case 0 -> {
                if (--ambT <= 0) { tramState = 1; tramDir = (ticks / 7) % 2 == 0 ? 1 : -1; tramX = tramDir > 0 ? -TRAM_W - 40 : WW + TRAM_W + 40; }
            }
            case 1 -> {                                                    // a tram that only passes by
                tramX += tramDir * 1.5;
                if (tramX < -TRAM_W - 60 || tramX > WW + TRAM_W + 60) { tramState = 0; ambT = 900 + (ticks * 13) % 500; }
            }
            case 2 -> {                                                    // comes to the stop where the pet waits
                double d = Math.abs(STOP_X[rideFrom] - tramX);
                tramX += tramDir * Math.min(2.0, 0.25 + d * 0.04);
                if (d < 0.8) {
                    tramX = STOP_X[rideFrom];
                    if (walking || Math.abs(px - tramX) > 36) { tramState = 6; return; }          // the pet went away: the tram does not wait
                    tramState = 3; tramT = 70; snd.accept(1.9F);
                }
            }
            case 3 -> {                                                    // the doors are open: the pet steps in
                if (!rider) { px += (tramX - px) * 0.2; py += (125 - py) * 0.2; }
                if (--tramT == 40) { rider = true; walking = false; }
                if (tramT == 0) tramState = 4;
            }
            case 4 -> {                                                    // the ride
                double target = STOP_X[1 - rideFrom], d = Math.abs(target - tramX), done = Math.abs(tramX - STOP_X[rideFrom]);
                tramX += tramDir * Math.min(2.0, 0.3 + Math.min(d, done) * 0.03);
                if (d < 0.8) { tramX = target; tramState = 5; tramT = 90; snd.accept(1.9F); }
            }
            case 5 -> {                                                    // arrived: the doors open, the pet steps out
                if (tramT == 60) {
                    rider = false;
                    px = tramX; py = 124; tx = px; ty = py;
                    act.accept(5);
                    say(t("cutemod.city.ride.end"));
                    for (int i = 0; i < 4; i++) bits.add(new double[]{px - 6 + i * 4, py - 20, (i - 1.5) * 0.12, -0.5, 44, 0});
                }
                if (--tramT == 0) tramState = 6;
            }
            case 6 -> {                                                    // the tram leaves
                tramX += tramDir * Math.min(2.0, 0.3 + Math.abs(tramX - STOP_X[1 - rideFrom]) * 0.04);
                if (tramX < -TRAM_W - 60 || tramX > WW + TRAM_W + 60) { tramState = 0; ambT = 800; }
            }
            default -> { }
        }
    }

    // ---------------------------------------------------------------- the pointer
    /** The place under a point of the world (the smallest box wins, so a bench beats the building behind it), or null. */
    private Poi poiAt(int wx, int wy) {
        Poi best = null;
        for (Poi p : POIS) {
            if (wx < p.x0() || wx >= p.x1() || wy < p.top() || wy > CityArt.CURB) continue;
            if (best == null || p.area() < best.area()) best = p;
        }
        return best;
    }

    private boolean busy() { return tramState >= 2 && (rider || tramState == 3); }

    boolean click(int mx, int my, int button) {
        if (button != 0 || busy()) return true;
        if (my < HEAD || my >= H - BAR) return true;
        if (arrowAt(mx, my) != 0) { goTo(px + arrowAt(mx, my) * 90, py, null); return true; }
        int wx = mx + camPx();
        Poi p = poiAt(wx, my);
        acting = null;
        actT = 0;
        if (p != null) goTo(stand(p), p.standY(), p);
        else goTo(Math.max(10, Math.min(WW - 10, wx)), Math.max(CityArt.WALK_MIN, Math.min(CityArt.WALK_MAX, my < CityArt.BASE ? 121 : my)), null);
        return true;
    }

    private void goTo(double x, double y, Poi p) {
        tx = Math.max(8, Math.min(WW - 8, x));
        ty = y;
        pending = p;
        walking = Math.hypot(tx - px, ty - py) > 1.4;
        if (!walking) { px = tx; py = ty; arrived(); }
    }

    /** -1 / +1 over the arrow at the left / the right edge when there is more street that way, else 0. */
    private int arrowAt(int mx, int my) {
        if (my < 62 || my > 92) return 0;
        if (cam > 2 && mx < 14) return -1;
        if (cam < WW - W - 2 && mx >= W - 14) return 1;
        return 0;
    }

    boolean key(int keyCode) {
        if (keyCode == 256) { back.run(); return true; }
        if (busy()) return true;
        double mv = 0;
        switch (keyCode) {
            case 262, 68 -> mv = 60;                      // right, D
            case 263, 65 -> mv = -60;                     // left, A
            case 265, 87 -> { goTo(px, Math.max(CityArt.WALK_MIN, py - 5), null); return true; }     // up, W
            case 264, 83 -> { goTo(px, Math.min(CityArt.WALK_MAX, py + 5), null); return true; }     // down, S
            default -> { return false; }
        }
        acting = null;
        actT = 0;
        goTo(px + mv, py, null);
        return true;
    }

    // ---------------------------------------------------------------- the picture
    private static float[] tint(int phase, boolean live) {
        return switch (phase) {
            case 1 -> live ? new float[]{1F, 0.9F, 0.9F} : new float[]{1F, 0.80F, 0.82F};
            case 2 -> live ? new float[]{0.72F, 0.76F, 0.96F} : new float[]{0.42F, 0.47F, 0.80F};
            default -> new float[]{1F, 1F, 1F};
        };
    }

    private void tinted(GuiGraphics g, int phase, boolean live, Runnable draw) {
        float[] k = tint(phase, live);
        if (phase == 0) { draw.run(); return; }
        g.flush();
        RenderSystem.setShaderColor(k[0], k[1], k[2], 1F);
        try {
            draw.run();
            g.flush();
        } finally {
            RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        }
    }

    void render(GuiGraphics g, int mx, int my) {
        Font f = Minecraft.getInstance().font;
        int phase = phase(), cx = camPx();
        hover = busy() || walking || my < HEAD || my >= H - BAR ? -1 : indexOf(poiAt(mx + cx, my));
        // the layers, baked once
        TexCache.Tex far = TexCache.get("city_far", CityArt.FAR_W, SCENE_H);
        if (far.tag != phase) { far.tag = phase; final int ph = phase; TexCache.render(far, 0, 0, c -> CityArt.far(c, ph)); }
        TexCache.Tex mid = TexCache.get("city_mid", CityArt.MID_W, SCENE_H);
        if (mid.tag != 1) { mid.tag = 1; TexCache.render(mid, 0, 0, CityArt::mid); }
        TexCache.Tex street = TexCache.get("city_street", WW, SCENE_H);
        if (street.tag != 1) { street.tag = 1; TexCache.render(street, 0, 0, CityArt::street); }
        TexCache.Tex lights = TexCache.get("city_lights", WW, SCENE_H);
        if (phase > 0 && lights.tag != phase) { lights.tag = phase; final int ph = phase; TexCache.render(lights, 0, 0, c -> CityArt.lights(c, ph)); }

        int ax = absX.getAsInt(), ay = absY.getAsInt();
        g.enableScissor(ax, ay + HEAD, ax + W, ay + H - BAR);
        TexCache.blit(g, far, -Math.round(cx * CityArt.FAR_K), 0);
        clouds(g, phase);
        final int fcx = cx;
        tinted(g, phase, false, () -> TexCache.blit(g, mid, -Math.round(fcx * CityArt.MID_K), 0));
        tinted(g, phase, false, () -> TexCache.blit(g, street, -fcx, 0));
        if (phase > 0) TexCache.blit(g, lights, -cx, 0);
        g.pose().pushPose();
        g.pose().translate(-cx, 0, 0);
        life(g, phase);                                                                        // water, smoke, the clock, the bulbs of the cinema
        tinted(g, phase, true, () -> actors(g, phase));
        tinted(g, phase, true, () -> vehicles(g));
        bitsDraw(g);
        g.pose().popPose();
        petals(g, phase);
        arrows(g);
        g.disableScissor();

        // the header, the name of the place under the pointer, the line at the bottom
        Skin.rect(g, 0, 0, W, HEAD, 0xFF5A4A86);
        String title = t("cutemod.city.title");
        Skin.str(g, f, title, W / 2 - f.width(title) / 2, 5, 0xFFFFFFFF, false);
        String clock = String.format("%02d:%02d", LocalTime.now().getHour(), LocalTime.now().getMinute());
        Skin.str(g, f, clock, W - 6 - f.width(clock), 5, 0xFFE4D8FF, false);
        if (hover >= 0) {
            Poi p = POIS[hover];
            String n = t("cutemod.city.n." + p.id());
            int bw = f.width(n) + 10, bx = Math.max(2, Math.min(W - bw - 2, (p.x0() + p.x1()) / 2 - cx - bw / 2)), by = Math.max(HEAD + 3, p.top() - 14);
            Skin.rect(g, bx, by, bw, 11, 0xF2FFFFFF);
            Skin.rect(g, bx, by + 10, bw, 1, 0xFFD8CCE8);
            Skin.str(g, f, n, bx + 5, by + 2, TEXT, false);
        }
        if (toastT > 0) {                                                                         // what the pet did, over the street
            String s = f.plainSubstrByWidth(toast, W - 30);
            int bw = f.width(s) + 14, bx = W / 2 - bw / 2, by = HEAD + 6;
            Skin.rect(g, bx, by, bw, 14, toastT > 20 ? 0xEEFFFFFF : 0x99FFFFFF);
            Skin.rect(g, bx, by + 13, bw, 1, 0xFFD8CCE8);
            Skin.str(g, f, s, bx + 7, by + 3, TEXT, false);
        }
        Skin.rect(g, 0, H - BAR, W, BAR, 0xE63A2A5A);
        String line = hover >= 0 ? t("cutemod.city.n." + POIS[hover].id()) + "  ·  " + t("cutemod.city.s." + POIS[hover].id()) : t("cutemod.city.hint");
        Skin.str(g, f, f.plainSubstrByWidth(line, W - 12), 6, H - 10, hover >= 0 ? 0xFFFFFFFF : 0xFFC8B8E8, false);
    }

    private static int indexOf(Poi p) {
        if (p == null) return -1;
        for (int i = 0; i < POIS.length; i++) if (POIS[i] == p) return i;
        return -1;
    }

    // ---------- the sky ----------
    private void clouds(GuiGraphics g, int phase) {
        if (phase == 2) return;
        int a = phase == 0 ? 0xD8FFFFFF : 0xB8FFD8E4;
        int sh = phase == 0 ? 0x40B8D4F0 : 0x40D890B0;
        for (int i = 0; i < 5; i++) {
            double x = ((ticks * (0.05 + i * 0.012) + i * 143) % (W + 120)) - 60 - (cam * 0.1) % 1;
            int y = 24 + (i * 17) % 30;
            int w = 22 + (i % 3) * 8;
            CityArt.oval(g, (int) x, y + 3, w / 2, 3, sh);
            CityArt.oval(g, (int) x, y + 1, w / 2, 4, a);
            CityArt.ball(g, (int) x - w / 5, y - 2, 5, a);
            CityArt.ball(g, (int) x + w / 6, y - 3, 6, a);
        }
        if (phase == 0) {                                                                         // two birds
            for (int i = 0; i < 2; i++) {
                int bx = (int) ((ticks * 0.35 + i * 90) % (W + 60)) - 30, by = 30 + i * 12 + (int) Math.round(Math.sin((ticks + i * 20) / 14.0) * 3);
                boolean up = (ticks / 7 + i) % 2 == 0;
                CityArt.r(g, bx - 2, by + (up ? -1 : 1), 2, 1, 0xFF6A5A8A); CityArt.r(g, bx, by, 1, 1, 0xFF6A5A8A); CityArt.r(g, bx + 1, by + (up ? -1 : 1), 2, 1, 0xFF6A5A8A);
            }
        }
    }

    // ---------- things that move in the street (world coordinates) ----------
    private void life(GuiGraphics g, int phase) {
        // the fountain: jets of water that fall in arcs, and rings on the basin
        int fx = 280, fy = 87;
        for (int i = 0; i < 10; i++) {
            double tt = ((ticks * 0.9 + i * 6) % 30) / 30.0, side = (i % 2 == 0 ? 1 : -1) * (0.4 + (i % 5) * 0.28);
            int x = (int) Math.round(fx + side * 14 * tt), y = (int) Math.round(fy - 9 * Math.sin(tt * Math.PI) + 6 * tt * tt * 6);
            CityArt.r(g, x, y, 1, 2, i % 3 == 0 ? 0xFFFFFFFF : 0xC8C8F0FF);
        }
        for (int i = 0; i < 3; i++) {
            int rr = (int) ((ticks / 2 + i * 10) % 26);
            int a = Math.max(0, 0x60 - rr * 3);
            CityArt.r(g, 280 - 6 - rr, 119, 1, 1, a << 24 | 0xFFFFFF); CityArt.r(g, 280 + 5 + rr, 119, 1, 1, a << 24 | 0xFFFFFF);
        }
        CityArt.r(g, fx - 1, fy - 5 - (int) (Math.sin(ticks / 5.0) * 1), 2, 6, 0xB0D8F4FF);
        // the smoke of the bakery chimney
        for (int i = 0; i < 4; i++) {
            double tt = ((ticks * 0.5 + i * 22) % 88) / 88.0;
            int x = 208 + (int) Math.round(tt * 14 + Math.sin(tt * 6 + i) * 2), y = 26 - (int) Math.round(tt * 22);
            CityArt.ball(g, x, y, 1 + (int) (tt * 3), (int) (0x70 * (1 - tt)) << 24 | (phase == 2 ? 0x8890B8 : 0xF4F0F8));
        }
        // the clock of the town hall shows the real time
        LocalTime now = LocalTime.now();
        double mA = (now.getMinute() + now.getSecond() / 60.0) / 60.0 * Math.PI * 2, hA = ((now.getHour() % 12) + now.getMinute() / 60.0) / 12.0 * Math.PI * 2;
        int cxk = 640, cyk = 44;
        CityArt.ln(g, cxk, cyk, cxk + (int) Math.round(Math.sin(mA) * 7), cyk - (int) Math.round(Math.cos(mA) * 7), 0xFF3A2A4A);
        CityArt.ln(g, cxk, cyk, cxk + (int) Math.round(Math.sin(hA) * 4.5), cyk - (int) Math.round(Math.cos(hA) * 4.5), 0xFF5A3A6A);
        CityArt.r(g, cxk, cyk, 1, 1, 0xFFE05A78);
        // the bulbs of the cinema run around the board
        for (int i = 0; i < 17; i++) {
            boolean on = (i + ticks / 6) % 3 == 0;
            int c = on ? 0xFFFFFFE0 : 0xFFE8B850;
            CityArt.r(g, 340 + 2 + i * 5, 68, 2, 2, c); CityArt.r(g, 340 + 2 + i * 5, 84, 2, 2, c);
        }
        // the neon board of the arcade blinks
        for (int i = 0; i < 12; i++) {
            int k = (i + ticks / 10) % 3;
            CityArt.r(g, 494 + 8 + i * 7, 81, 4, 2, k == 0 ? 0xFFFF8AD0 : k == 1 ? 0xFF58E0D0 : 0xFFFFE066);
        }
        // the flag on the tower of the hall waves
        int wv = (int) Math.round(Math.sin(ticks / 6.0));
        CityArt.r(g, 590 + 51, 12 + wv, 5, 3, 0xFFFF7A9A); CityArt.r(g, 590 + 56, 13 - wv, 1, 2, 0xFFFF7A9A);
    }

    // ---------- the pet, the people and the pigeons, nearest last ----------
    private void actors(GuiGraphics g, int phase) {
        // sort by the line of the feet
        List<double[]> list = new ArrayList<>();
        for (double[] w : walkers) list.add(new double[]{w[1], 0, w[0], w[2], w[4], w[5], w[6]});
        for (double[] p : pigeons) list.add(new double[]{p[1] - (p[2] > 0 ? Math.sin((38 - p[2]) / 38.0 * Math.PI) * 14 : 0), 1, p[0], p[2], 0, 0, 0});
        list.add(new double[]{py, 2, px, 0, 0, 0, 0});
        list.add(new double[]{124, 3, 233, 0, 0, 0, 0});                                       // the musician
        list.sort((a, b) -> Double.compare(a[0], b[0]));
        for (double[] a : list) {
            int x = (int) Math.round(a[2]), y = (int) Math.round(a[0]);
            switch ((int) a[1]) {
                case 0 -> critter(g, x, y, (int) a[4], (int) a[3], (int) a[6], (int) a[5]);
                case 1 -> pigeon(g, x, y, a[3] > 0, (int) a[3]);
                case 2 -> pet(g);
                default -> musician(g, x, y);
            }
        }
    }

    private void pet(GuiGraphics g) {
        if (rider) return;
        int hop = walking ? (int) Math.round(Math.abs(Math.sin(ticks * 0.5)) * 2.5) : acting != null ? (int) Math.round(Math.abs(Math.sin(ticks * 0.28)) * 2) : 0;
        int x = (int) Math.round(px), y = (int) Math.round(py);
        CityArt.oval(g, x, y, 7, 2, 0x38000000);
        int st = stage.getAsInt();
        int mood = acting != null ? 2 : 1;
        PetActs.pet(g, color.get(), x, y - hop, 0.46F, ticks, st, mood);
    }

    private static final int[][] CRIT = {
            {0xFFFFB0C8, 0xFFFFD8E4, 0xFFE87A9A}, {0xFF8AD88A, 0xFFD8F4C0, 0xFF4AAA5A}, {0xFFFFFFFF, 0xFFF0F0F0, 0xFF3A3A4A}, {0xFFC8C8D8, 0xFFE8E8F0, 0xFFFFB0C0},
            {0xFFFFA050, 0xFFFFE8D0, 0xFF8A4A2A}, {0xFFA8B0C8, 0xFFE0E4F0, 0xFF6A7088}, {0xFFE8C090, 0xFFFFF0E0, 0xFFB88A5A}, {0xFFB8825A, 0xFFE8C8A8, 0xFF7A4A2A}};
    private static final int[] BALLOON = {0xFFFF8AB8, 0xFF8AD0FF, 0xFFFFD060};

    /** A small townsperson: a round animal with ears, a belly and little legs that walk; some carry a balloon or a shopping bag. */
    private static void critter(GuiGraphics g, int cx, int feet, int kind, int dir, int step, int item) {
        int[] k = CRIT[kind % 8];
        int sw = (step / 4) % 2, bob = sw;
        CityArt.oval(g, cx, feet, 6, 2, 0x30000000);
        CityArt.r(g, cx - 3 + sw, feet - 4, 2, 4, k[2]); CityArt.r(g, cx + 1 - sw, feet - 4, 2, 4, k[2]);                      // legs
        CityArt.r(g, cx - 4, feet - 10 - bob, 9, 7, k[0]); CityArt.r(g, cx - 2, feet - 8 - bob, 5, 4, k[1]);                  // body
        int hy = feet - 14 - bob;
        switch (kind % 8) {
            case 0 -> { CityArt.r(g, cx - 5, hy - 5, 3, 3, k[2]); CityArt.r(g, cx + 3, hy - 5, 3, 3, k[2]); }                       // pig: little pink ears
            case 1 -> { CityArt.ball(g, cx - 3, hy - 4, 2, k[0]); CityArt.ball(g, cx + 3, hy - 4, 2, k[0]); }                      // frog: eye bumps
            case 2 -> { CityArt.ball(g, cx - 4, hy - 3, 2, k[2]); CityArt.ball(g, cx + 4, hy - 3, 2, k[2]); }                      // panda: black ears
            case 3 -> { CityArt.ball(g, cx - 5, hy - 3, 3, k[0]); CityArt.ball(g, cx + 5, hy - 3, 3, k[0]); CityArt.ball(g, cx - 5, hy - 3, 1, k[2]); CityArt.ball(g, cx + 5, hy - 3, 1, k[2]); }   // mouse
            case 4, 6 -> { CityArt.tri(g, cx - 3, hy - 8, 4, 5, k[0]); CityArt.tri(g, cx + 3, hy - 8, 4, 5, k[0]); }               // fox, cat: pointed ears
            case 5 -> { CityArt.ball(g, cx - 5, hy - 3, 3, k[0]); CityArt.ball(g, cx + 5, hy - 3, 3, k[0]); }                      // koala: big round ears
            default -> { CityArt.ball(g, cx - 4, hy - 4, 2, k[0]); CityArt.ball(g, cx + 4, hy - 4, 2, k[0]); }                     // bear
        }
        CityArt.ball(g, cx, hy, 5, k[0]);
        if (kind % 8 == 2) { CityArt.r(g, cx - 3, hy - 1, 2, 2, k[2]); CityArt.r(g, cx + 2, hy - 1, 2, 2, k[2]); }
        CityArt.r(g, cx - 3 + dir, hy - 1, 1, 2, 0xFF3A2A3A); CityArt.r(g, cx + 2 + dir, hy - 1, 1, 2, 0xFF3A2A3A);               // eyes look the way it walks
        CityArt.r(g, cx - 1 + dir, hy + 2, 2, 1, kind % 8 == 4 ? 0xFF3A2A3A : k[2]);
        if (item == 1) {                                                                                                           // a balloon on a string
            int bx = cx + dir * 6, by = feet - 30 - (step / 6) % 2;
            CityArt.r(g, bx, by + 4, 1, 17, 0xA08A7AA8);
            CityArt.ball(g, bx, by, 4, BALLOON[kind % 3]); CityArt.r(g, bx - 2, by - 2, 1, 2, 0x90FFFFFF);
        } else if (item == 2) {                                                                                                    // a shopping bag
            int bx = cx - dir * 7;
            CityArt.r(g, bx - 2, feet - 8, 6, 6, 0xFFFF9AC0); CityArt.r(g, bx - 2, feet - 8, 6, 1, 0xFFFFC8DC); CityArt.r(g, bx - 1, feet - 10, 1, 2, 0xFF8A5A6A); CityArt.r(g, bx + 2, feet - 10, 1, 2, 0xFF8A5A6A);
        }
    }

    private static void pigeon(GuiGraphics g, int x, int y, boolean flying, int left) {
        if (flying) {
            int up = (left / 3) % 2 == 0 ? -3 : 1;
            CityArt.ball(g, x, y - 3, 2, 0xFFA8A8C0);
            CityArt.r(g, x - 4, y - 3 + up, 3, 1, 0xFF8A8AA8); CityArt.r(g, x + 2, y - 3 + up, 3, 1, 0xFF8A8AA8);
            return;
        }
        CityArt.oval(g, x, y, 4, 1, 0x28000000);
        CityArt.r(g, x - 2, y - 4, 5, 3, 0xFFA8A8C0); CityArt.r(g, x + 1, y - 6, 3, 3, 0xFF8A8AA8); CityArt.r(g, x + 4, y - 5, 1, 1, 0xFFFFC040); CityArt.r(g, x + 2, y - 5, 1, 1, 0xFF3A2A3A);
        CityArt.r(g, x - 1, y - 1, 1, 1, 0xFFE08A8A); CityArt.r(g, x + 1, y - 1, 1, 1, 0xFFE08A8A);
    }

    /** The street musician: a cat on a little stool with a guitar. */
    private void musician(GuiGraphics g, int x, int y) {
        CityArt.oval(g, x, y, 7, 2, 0x30000000);
        CityArt.r(g, x - 4, y - 5, 8, 2, 0xFF8A5A3A); CityArt.r(g, x - 3, y - 3, 1, 3, 0xFF6A4A2A); CityArt.r(g, x + 2, y - 3, 1, 3, 0xFF6A4A2A);       // a stool
        CityArt.r(g, x - 3, y - 12, 7, 8, 0xFF9AA8F0); CityArt.r(g, x - 2, y - 11, 5, 3, 0xFFC8D0FF);                                                  // body in a blue jumper
        CityArt.tri(g, x - 3, y - 21, 4, 4, 0xFFE8C090); CityArt.tri(g, x + 3, y - 21, 4, 4, 0xFFE8C090);
        CityArt.ball(g, x, y - 16, 4, 0xFFE8C090);
        CityArt.r(g, x - 2, y - 17, 1, 2, 0xFF3A2A3A); CityArt.r(g, x + 2, y - 17, 1, 2, 0xFF3A2A3A); CityArt.r(g, x, y - 14, 1, 1, 0xFFE87A9A);
        CityArt.r(g, x - 4, y - 21, 8, 2, 0xFFE05A78); CityArt.r(g, x - 3, y - 23, 6, 2, 0xFFE05A78);                                                   // a little red beret
        int sw = (ticks / 5) % 2;                                                                                                                       // the guitar and the strumming paw
        CityArt.ball(g, x + 3, y - 6, 3, 0xFFC8884A); CityArt.ball(g, x + 3, y - 6, 1, 0xFF5A3A2A); CityArt.r(g, x + 5, y - 14, 1, 8, 0xFF8A5A3A); CityArt.r(g, x + 4, y - 15, 3, 2, 0xFF5A3A2A);
        CityArt.r(g, x + 1, y - 7 + sw, 3, 1, 0xFFE8C090);
        if (acting == null && ticks % 60 == 0) bits.add(new double[]{x + 4, y - 20, 0.2, -0.4, 44, 1});                                                 // a note now and then
    }

    // ---------- the road ----------
    private static final int[] CAR = {0xFFFF9AB8, 0xFF8AD0F0, 0xFFFFD27A, 0xFFB0E8B8, 0xFFC8A8F0, 0xFFFFFFFF, 0xFFFFB090};

    private void vehicles(GuiGraphics g) {
        int cx = camPx();
        for (double[] c : cars) {
            int x = (int) Math.round(c[0]);
            if (x < cx - 40 || x > cx + W + 40) continue;
            car(g, x, c[1] == 0 ? 142 : 149, (int) c[2], CAR[(int) c[4] % CAR.length], c[5] == 1);
        }
        if (tramState != 0 && tramX > cx - TRAM_W && tramX < cx + W + TRAM_W) tram(g);
        // the rails show where the tram runs
        CityArt.r(g, cx, 153, W, 1, 0x70C8C0E0);
    }

    private static void car(GuiGraphics g, int cx, int bottom, int dir, int c, boolean bus) {
        int w = bus ? 34 : 22, x = cx - w / 2;
        CityArt.oval(g, cx, bottom, w / 2, 1, 0x30000000);
        CityArt.r(g, x, bottom - 6, w, 5, c); CityArt.r(g, x, bottom - 6, w, 1, CityArt.lt(c, 0.45F)); CityArt.r(g, x, bottom - 2, w, 1, CityArt.dk(c, 0.2F));
        if (bus) {
            CityArt.r(g, x + 1, bottom - 10, w - 2, 4, c); CityArt.r(g, x + 1, bottom - 10, w - 2, 1, CityArt.lt(c, 0.45F));
            for (int i = 0; i < 5; i++) CityArt.r(g, x + 3 + i * 6, bottom - 9, 4, 3, 0xFFC8ECFF);
        } else {
            CityArt.r(g, x + 5, bottom - 10, 12, 4, c); CityArt.r(g, x + 5, bottom - 10, 12, 1, CityArt.lt(c, 0.45F));
            CityArt.r(g, x + 6, bottom - 9, 4, 3, 0xFFC8ECFF); CityArt.r(g, x + 11, bottom - 9, 4, 3, 0xFFC8ECFF);
        }
        CityArt.r(g, x + 3, bottom - 2, 4, 3, 0xFF2E2A44); CityArt.r(g, x + w - 7, bottom - 2, 4, 3, 0xFF2E2A44);
        CityArt.r(g, dir > 0 ? x + w - 2 : x, bottom - 5, 2, 2, 0xFFFFF0A0); CityArt.r(g, dir > 0 ? x : x + w - 2, bottom - 5, 2, 2, 0xFFE05A78);
    }

    private void tram(GuiGraphics g) {
        int x = (int) Math.round(tramX) - TRAM_W / 2, y = TRAM_BOTTOM - 27;
        CityArt.oval(g, x + TRAM_W / 2, TRAM_BOTTOM, TRAM_W / 2, 1, 0x38000000);
        CityArt.r(g, x, y + 4, TRAM_W, 20, 0xFFB8E8D8); CityArt.r(g, x, y + 4, TRAM_W, 1, 0xFFE0FAF0);
        CityArt.r(g, x + 2, y, TRAM_W - 4, 5, 0xFF8ACFB8); CityArt.r(g, x + 2, y, TRAM_W - 4, 1, 0xFFB8EEDC);
        CityArt.r(g, x, y + 17, TRAM_W, 3, 0xFFFF9AC0); CityArt.r(g, x, y + 20, TRAM_W, 1, 0xFFE07AA0);
        boolean open = tramState == 3 || tramState == 5;
        int door = x + TRAM_W / 2 - 6;
        for (int i = 0; i < 6; i++) {
            int wx = x + 4 + i * 12;
            if (Math.abs(wx + 4 - (door + 6)) < 9) continue;
            CityArt.r(g, wx - 1, y + 6, 11, 10, 0xFF6AAA98); CityArt.r(g, wx, y + 7, 9, 8, 0xFFE0F6FF); CityArt.r(g, wx, y + 7, 9, 3, 0xFFF4FCFF);
            CityArt.r(g, wx + 1, y + 11, 1, 1, 0xB0FFFFFF); CityArt.r(g, wx + 2, y + 10, 1, 1, 0xB0FFFFFF);
            if (rider && tramState == 4 && i == 1) { CityArt.ball(g, wx + 4, y + 12, 3, color.get().bodyColor | 0xFF000000); CityArt.r(g, wx + 3, y + 11, 1, 1, 0xFF3A2A3A); CityArt.r(g, wx + 6, y + 11, 1, 1, 0xFF3A2A3A); }
        }
        CityArt.r(g, door - 1, y + 5, 14, 16, 0xFF6AAA98);
        if (open) { CityArt.r(g, door, y + 6, 12, 15, 0xFFFFF4D0); CityArt.r(g, door + 5, y + 6, 2, 15, 0xFFE0C890); }
        else { CityArt.r(g, door, y + 6, 6, 15, 0xFF8ACFB8); CityArt.r(g, door + 6, y + 6, 6, 15, 0xFF7ABFA8); CityArt.r(g, door + 1, y + 7, 4, 5, 0xFFE0F6FF); CityArt.r(g, door + 7, y + 7, 4, 5, 0xFFE0F6FF); }
        CityArt.r(g, x + 8, y + 24, 10, 3, 0xFF4A4468); CityArt.r(g, x + TRAM_W - 18, y + 24, 10, 3, 0xFF4A4468);
        CityArt.r(g, x + TRAM_W / 2 - 1, y - 7, 2, 7, 0xFF4A4468); CityArt.r(g, x + TRAM_W / 2 - 12, y - 7, 24, 1, 0xFF4A4468);              // the pantograph
        CityArt.r(g, tramDir > 0 ? x + TRAM_W - 3 : x, y + 14, 3, 4, 0xFFFFF0A0);                                                                // the headlight
        CityArt.r(g, tramDir > 0 ? x : x + TRAM_W - 2, y + 14, 2, 3, 0xFFE05A78);
        CityArt.r(g, x + 4, y + 1, 6, 3, 0xFFFFFFFF);                                                                                            // the number of the line
        CityArt.r(g, x + 5, y + 2, 4, 1, 0xFFE05A78);
    }

    // ---------- floating signs ----------
    private void bitsDraw(GuiGraphics g) {
        for (double[] b : bits) {
            int x = (int) Math.round(b[0]), y = (int) Math.round(b[1]);
            int a = (int) Math.min(255, b[4] * 8) << 24;
            switch ((int) b[5]) {
                case 0 -> { CityArt.r(g, x - 2, y - 1, 2, 2, a | 0xFF5A8A); CityArt.r(g, x + 1, y - 1, 2, 2, a | 0xFF5A8A); CityArt.r(g, x - 2, y, 5, 2, a | 0xFF5A8A); CityArt.r(g, x - 1, y + 2, 3, 1, a | 0xFF5A8A); CityArt.r(g, x, y + 3, 1, 1, a | 0xFF5A8A); }
                case 1 -> { CityArt.r(g, x, y - 4, 1, 6, a | 0x6A4AB8); CityArt.r(g, x + 1, y - 4, 3, 1, a | 0x6A4AB8); CityArt.ball(g, x - 1, y + 2, 1, a | 0x6A4AB8); }
                case 2 -> { CityArt.r(g, x, y - 2, 1, 5, a | 0xFFE066); CityArt.r(g, x - 2, y, 5, 1, a | 0xFFE066); CityArt.r(g, x, y, 1, 1, a | 0xFFFFFF); }
                case 3 -> CityArt.ball(g, x, y, 2 + (int) ((40 - b[4]) / 14), ((int) Math.min(120, b[4] * 3) << 24) | 0xF4F0F8);
                default -> { CityArt.ball(g, x, y, 2, 0xFFFFD060); CityArt.r(g, x, y - 1, 1, 2, 0xFFC89A20); }
            }
        }
    }

    /** Petals of the cherry trees drift over the whole street (on the screen, not in the world). */
    private void petals(GuiGraphics g, int phase) {
        if (phase == 2) return;
        for (int i = 0; i < 14; i++) {
            double fall = (ticks * (0.28 + (i % 4) * 0.05) + i * 31) % (H + 20);
            int x = (int) ((i * 53 + ticks * 0.35 + Math.sin(fall / 14.0 + i) * 8) % (W + 10)), y = (int) fall - 8;
            if (y < HEAD || y > H - BAR - 2) continue;
            CityArt.r(g, x, y, 2, 1, 0xC8FFB8D0); CityArt.r(g, x + 1, y + 1, 1, 1, 0xA0FF9AC0);
        }
    }

    private void arrows(GuiGraphics g) {
        int bob = (int) Math.round(Math.abs(Math.sin(ticks / 12.0)) * 2);
        if (cam > 2) arrow(g, 2 + bob, false);
        if (cam < WW - W - 2) arrow(g, W - 12 - bob, true);
    }

    private static void arrow(GuiGraphics g, int x, boolean right) {
        Skin.rect(g, x - 1, 68, 12, 20, 0x903A2A5A);
        for (int j = 0; j < 3; j++) { int hh = 7 - j * 2, xx = right ? x + 1 + j * 2 : x + 7 - j * 2; Skin.rect(g, xx, 78 - hh / 2, 2, hh, 0xFFFFFFFF); }
    }
}
