package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** White computer: a panda snake eating bamboo. */
public class PandaSnake extends MiniGame {
    private static final int CELL = 10, COLS = W / CELL, ROWS = H / CELL;

    private final List<int[]> body = new ArrayList<>(); // index 0 = head
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();
    private int dx, dy, fx, fy, counter;
    private boolean started;

    @Override
    public void reset() {
        score = 0; over = false; started = false; counter = 0;
        body.clear(); queue.clear();
        for (int i = 0; i < 3; i++) body.add(new int[]{8 - i, ROWS / 2});
        dx = 1; dy = 0;
        placeFood();
    }

    private void placeFood() {
        while (true) {
            fx = rnd.nextInt(COLS); fy = rnd.nextInt(ROWS);
            boolean free = true;
            for (int[] s : body) if (s[0] == fx && s[1] == fy) { free = false; break; }
            if (free) return;
        }
    }

    @Override
    public boolean key(int k) {
        int ndx, ndy;
        switch (k) {
            case KEY_UP, 87 -> { ndx = 0; ndy = -1; }
            case KEY_DOWN, 83 -> { ndx = 0; ndy = 1; }
            case KEY_LEFT, 65 -> { ndx = -1; ndy = 0; }
            case KEY_RIGHT, 68 -> { ndx = 1; ndy = 0; }
            default -> { return false; }
        }
        int ldx = queue.isEmpty() ? dx : queue.peekLast()[0];
        int ldy = queue.isEmpty() ? dy : queue.peekLast()[1];
        if (ndx == -ldx && ndy == -ldy) return true; // no reversing
        if (ndx == ldx && ndy == ldy) { started = true; return true; }
        if (queue.size() < 3) queue.add(new int[]{ndx, ndy});
        started = true;
        return true;
    }

    @Override
    public void tick() {
        if (!started) return;
        int interval = Math.max(5, 11 - score / 3);
        if (++counter < interval) return;
        counter = 0;
        if (!queue.isEmpty()) { int[] d = queue.poll(); dx = d[0]; dy = d[1]; }
        int nx = body.get(0)[0] + dx, ny = body.get(0)[1] + dy;
        if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS) { over = true; return; }
        boolean eat = nx == fx && ny == fy;
        int limit = eat ? body.size() : body.size() - 1; // tail moves away
        for (int i = 0; i < limit; i++) {
            if (body.get(i)[0] == nx && body.get(i)[1] == ny) { over = true; return; }
        }
        body.add(0, new int[]{nx, ny});
        if (eat) { score++; pling(1.0F + Math.min(score, 24) * 0.04F); placeFood(); }
        else body.remove(body.size() - 1);
    }

    @Override
    public void render(GuiGraphics g) {
        // meadow: soft checker, tufts and little flowers that never move
        for (int x = 0; x < COLS; x++)
            for (int y = 0; y < ROWS; y++)
                rect(g, x * CELL, y * CELL, CELL, CELL, ((x + y) & 1) == 0 ? 0xFFD3EDC8 : 0xFFC5E3B9);
        for (int i = 0; i < 26; i++) {
            int gx = (int) (Gfx.hash(i, 1) * (W - 6)), gy = (int) (Gfx.hash(i, 2) * (H - 6));
            if (i % 5 == 0) {
                rect(g, gx, gy, 1, 1, 0xFFFFFFFF); rect(g, gx - 1, gy, 1, 1, 0xFFFFC2DC); rect(g, gx + 1, gy, 1, 1, 0xFFFFC2DC);
                rect(g, gx, gy - 1, 1, 1, 0xFFFFC2DC); rect(g, gx, gy + 1, 1, 1, 0xFFFFC2DC);
                rect(g, gx, gy, 1, 1, 0xFFFFE27A);
            } else {
                rect(g, gx, gy, 1, 2, 0xFF9CCB8C); rect(g, gx + 2, gy + 1, 1, 2, 0xFF9CCB8C);
            }
        }
        Gfx.outline(g, 0, 0, W, H, 0x55557A4A);
        // bamboo: two stalks with joints and a leaf, a soft shadow under it
        int bx = fx * CELL, by = fy * CELL;
        Gfx.ellipse(g, bx + 5, by + 9, 4, 1, 0x33000000);
        for (int s = 0; s < 2; s++) {
            int sx = bx + 2 + s * 4;
            g.fillGradient(sx, by + 1 + s, sx + 3, by + 9, 0xFF7CD58A, 0xFF3E9A4A);
            g.fill(sx, by + 1 + s, sx + 1, by + 9, 0x66FFFFFF);
            g.fill(sx - 1, by + 4 + s, sx + 4, by + 5 + s, 0xFF2A6B33);
            g.fill(sx - 1, by + 7, sx + 4, by + 8, 0xFF2A6B33);
        }
        g.fill(bx + 6, by + 1, bx + 9, by + 2, 0xFF4FBF5E); g.fill(bx + 7, by, bx + 10, by + 1, 0xFF7CD58A);
        // snake body: round segments linked to the next one, black belt on every other one
        int n = body.size();
        for (int i = n - 1; i >= 1; i--) {
            int[] s = body.get(i), p = body.get(i - 1);
            int x = s[0] * CELL, y = s[1] * CELL;
            int col = (i & 1) == 0 ? 0xFF3A3A48 : 0xFFFFFFFF;
            // link toward the neighbour closer to the head
            int lx = Math.min(s[0], p[0]) * CELL + 1, ly = Math.min(s[1], p[1]) * CELL + 1;
            int lw = (Math.abs(s[0] - p[0]) + 1) * CELL - 2, lh = (Math.abs(s[1] - p[1]) + 1) * CELL - 2;
            if (s[0] != p[0]) { lx += 2; lw -= 4; ly += 1; lh -= 2; } else { ly += 2; lh -= 4; lx += 1; lw -= 2; }
            Gfx.rrect(g, lx + 1, ly + 1, lw, lh, 2, 0x22000000);
            Gfx.rrect(g, lx, ly, lw, lh, 2, col);
            Gfx.rrect(g, x + 2, y + 3, CELL - 3, CELL - 3, 3, 0x22000000);
            Gfx.rrect(g, x + 1, y + 1, CELL - 2, CELL - 2, 3, col);
            rect(g, x + 3, y + 2, CELL - 6, 1, (i & 1) == 0 ? 0x44FFFFFF : 0xFFFFFFFF);
            rect(g, x + 2, y + CELL - 4, CELL - 4, 2, 0x22000000);
        }
        // tail tip
        if (n > 1) {
            int[] tl = body.get(n - 1);
            rect(g, tl[0] * CELL + CELL / 2 - 1, tl[1] * CELL + CELL / 2 - 1, 2, 2, 0xFF1F1F27);
        }
        // panda head, looks the way it moves
        int[] h = body.get(0);
        int hx = h[0] * CELL, hy = h[1] * CELL;
        int ox = dx * 1, oy = dy * 1;
        Gfx.rrect(g, hx + 1, hy + 2, CELL - 1, CELL - 1, 4, 0x33000000);
        Gfx.rrect(g, hx, hy + 1, CELL, CELL - 1, 4, 0xFFFFFFFF);
        // black ears
        rect(g, hx, hy, 3, 3, 0xFF25252D); rect(g, hx + CELL - 3, hy, 3, 3, 0xFF25252D);
        // eye patches and shiny eyes
        rect(g, hx + 1 + ox, hy + 3 + oy, 3, 4, 0xFF25252D); rect(g, hx + CELL - 4 + ox, hy + 3 + oy, 3, 4, 0xFF25252D);
        rect(g, hx + 2 + ox, hy + 4 + oy, 1, 1, 0xFFFFFFFF); rect(g, hx + CELL - 3 + ox, hy + 4 + oy, 1, 1, 0xFFFFFFFF);
        // nose and a tiny smile
        rect(g, hx + 4 + ox, hy + 6 + oy, 2, 2, 0xFF25252D);
        rect(g, hx + 3 + ox, hy + 8 + oy, 1, 1, 0xFF25252D); rect(g, hx + 6 + ox, hy + 8 + oy, 1, 1, 0xFF25252D);
        rect(g, hx + 3, hy + 7, 1, 1, 0x66FF9AB8); rect(g, hx + CELL - 4, hy + 7, 1, 1, 0x66FF9AB8);
        if (!started) {
            Gfx.rrect(g, W / 2 - 38, H - 26, 76, 13, 4, 0x99FFFFFF);
            ctext(g, "WASD / \u2190\u2191\u2193\u2192", W / 2, H - 24, 0xFF2A5A33);
        }
    }

    @Override
    public String hintKey() { return "cutemod.hint.snake"; }
}
