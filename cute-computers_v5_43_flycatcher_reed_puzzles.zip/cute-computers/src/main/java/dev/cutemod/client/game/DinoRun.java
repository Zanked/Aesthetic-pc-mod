package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The "no connection" runner of the browser: a panda-saur runs along the ground, jumps over bamboo and creepers
 * and ducks under bees. It is not in the Games folder: the browser draws it on its not-found page, so it has its own
 * size (the whole page area) instead of the usual 220 x 140.
 */
public class DinoRun extends MiniGame {
    private final int vw, vh, ground;

    private static final int DX = 28, DW = 18, DH = 20, DUCK_H = 11, DUCK_W = 22;
    private static final float GRAVITY = 0.4F, JUMP = -6.4F;

    private record Obs(int kind, float x, int w, int h, int y) {} // kind 0 bamboo, 1 creeper, 2 bee; y = top

    private final List<Obs> obs = new ArrayList<>();
    private boolean started;
    private float dy, vy;          // height above the ground (0 = standing) and its speed (up is negative)
    private int duck;              // ticks left of the ducking
    private float speed, dist;
    private int t, overTicks, milestone;
    private float gap;            // distance (px) until the next obstacle appears
    private float night, nightGoal;
    private final int[] cloudX = new int[4], cloudY = new int[4];
    private static int hi;         // the best score of this session

    public DinoRun(int vw, int vh) {
        this.vw = vw;
        this.vh = vh;
        this.ground = vh - 26;
        for (int i = 0; i < cloudX.length; i++) { cloudX[i] = 30 + i * (vw / 3); cloudY[i] = 30 + (i * 17) % 28; }
        reset();
    }

    @Override
    public void reset() {
        score = 0; over = false;
        obs.clear();
        started = false;
        dy = 0; vy = 0; duck = 0;
        speed = 2.1F; dist = 0;
        t = 0; overTicks = 0; milestone = 0;
        night = 0; nightGoal = 0;
        gap = 200;
    }

    public boolean isRunning() { return started && !over; }

    // ---------- input ----------
    private void jump() {
        if (dy == 0 && vy == 0) {
            vy = JUMP;
            duck = 0;
            pling(1.5F);
        }
    }

    @Override
    public boolean key(int k) {
        if (over) {
            if ((k == KEY_SPACE || k == KEY_UP || k == 257 || k == 87) && overTicks > 20) { reset(); started = true; jump(); }
            return true;
        }
        if (k == KEY_SPACE || k == KEY_UP || k == 87) {
            if (!started) started = true;
            jump();
            return true;
        }
        if (k == KEY_DOWN || k == 83) {
            if (!started) return true;
            if (dy > 0) vy = Math.max(vy, 3.5F);      // in the air: drop faster
            else duck = 30;                           // on the ground: duck for half a second
            return true;
        }
        return false;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) { if (overTicks > 20) { reset(); started = true; jump(); } return true; }
        if (!started) started = true;
        jump();
        return true;
    }

    // ---------- game ----------
    private int curH() { return duck > 0 && dy == 0 ? DUCK_H : DH; }

    private int curW() { return duck > 0 && dy == 0 ? DUCK_W : DW; }

    @Override
    public void tick() {
        if (over) { overTicks++; return; }
        t++;
        if (!started) return;

        // the panda-saur
        if (duck > 0) duck--;
        if (vy != 0 || dy > 0) {
            vy += GRAVITY;
            dy -= vy;
            if (dy <= 0) { dy = 0; vy = 0; }
        }
        // the world
        speed = Math.min(4.8F, 2.1F + score / 60 * 0.14F);
        dist += speed;
        score = (int) (dist / 8);
        if (score / 100 > milestone) { milestone = score / 100; pling(2.0F); }
        nightGoal = (score / 350) % 2 == 1 ? 1F : 0F;
        night += (nightGoal - night) * 0.02F;
        for (int i = 0; i < cloudX.length; i++) {
            cloudX[i] -= (t % 3 == 0) ? 1 : 0;
            if (cloudX[i] < -20) { cloudX[i] = vw + rnd.nextInt(40); cloudY[i] = 24 + rnd.nextInt(34); }
        }
        // obstacles
        for (int i = obs.size() - 1; i >= 0; i--) {
            Obs o = obs.get(i);
            Obs m = new Obs(o.kind(), o.x() - speed, o.w(), o.h(), o.y());
            if (m.x() + m.w() < 0) obs.remove(i); else obs.set(i, m);
        }
        gap -= speed;
        if (gap <= 0) {
            spawn();
            gap = 100 + 26 * speed + rnd.nextInt(120);
        }
        // a hit (the boxes are a little smaller than the pictures, so it feels fair)
        int px = DX + 2, pw = curW() - 5, ph = curH() - 3, py = ground - Math.round(dy) - curH() + 2;
        for (Obs o : obs) {
            int ox = Math.round(o.x()) + 2, ow = o.w() - 4, oy = o.y() + 2, oh = o.h() - 3;
            if (px < ox + ow && px + pw > ox && py < oy + oh && py + ph > oy) {
                over = true;
                overTicks = 0;
                if (score > hi) hi = score;
                return;
            }
        }
    }

    private void spawn() {
        int r = rnd.nextInt(100);
        if (score > 250 && r < 28) {              // a bee: low (jump) or at the head (duck)
            boolean low = rnd.nextBoolean();
            obs.add(new Obs(2, vw + 10, 14, 10, ground - (low ? 12 : 24)));
        } else if (r < 55) {                      // a creeper
            obs.add(new Obs(1, vw + 10, 12, 20, ground - 20));
        } else {                                  // bamboo: 1 to 3 stalks, tall or short
            int n = 1 + rnd.nextInt(score > 120 ? 3 : 2);
            int h = rnd.nextBoolean() ? 16 : 24;
            obs.add(new Obs(0, vw + 10, n * 6 - 2, h, ground - h));
        }
    }

    // ---------- drawing ----------
    private static int lerp(int a, int b, float f) {
        int r = Math.round(((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = Math.round(((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = Math.round((a & 255) * (1 - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    @Override
    public void render(GuiGraphics g) {
        int skyTop = lerp(0xFFDDF1FF, 0xFF15122A, night), skyBot = lerp(0xFFF6FBFF, 0xFF3A2F5A, night);
        g.fillGradient(0, 0, vw, ground, skyTop, skyBot);
        int ink = lerp(0xFF4A4A5E, 0xFFE8E4F4, night);

        // stars / sun / moon with a soft halo, and puffy clouds
        if (night > 0.3F) {
            int a = (int) (255 * Math.min(1F, night));
            for (int i = 0; i < 20; i++) {
                int sx = (i * 61 + 13) % vw, sy = 4 + (i * 23) % 60;
                if (i % 4 == 0) Gfx.sparkle(g, sx, sy, 2, t + i * 11, (a << 24) | 0xFFFFFF);
                else rect(g, sx, sy, 1, 1, (a << 24) | 0xFFFFFF);
            }
            Gfx.glow(g, vw - 44, 30, 20, 0xFFF3EEC8, a / 3);
            disc(g, vw - 44, 30, 7, (a << 24) | 0xF3EEC8);
            disc(g, vw - 41, 28, 6, lerp(skyTop, skyBot, 0.4F));
        } else {
            Gfx.glow(g, vw - 44, 30, 24, 0xFFFFE27A, 120 - (int) (night * 300));
            disc(g, vw - 44, 30, 7, 0xFFFFE27A);
            disc(g, vw - 46, 28, 3, 0xFFFFF6C8);
        }
        int cloud = lerp(0xCCFFFFFF, 0xCC4A4468, night);
        for (int i = 0; i < cloudX.length; i++) Gfx.cloud(g, cloudX[i] - 4, cloudY[i] - 4, 26, cloud);

        // far hills and a bamboo forest that slide slowly (parallax)
        int hill = lerp(0xFFD2ECC6, 0xFF222C3A, night), forest = lerp(0xFFB8DFA9, 0xFF1D2632, night), leaf = lerp(0xFFA6D597, 0xFF18202A, night);
        for (int x = 0; x < vw; x += 3) {
            int h = 10 + (int) (6 * Math.sin((x + dist * 0.12) / 19.0) + 3 * Math.sin((x + dist * 0.12) / 7.0));
            g.fill(x, ground - h, x + 3, ground, hill);
        }
        int period = (vw / 18 + 3) * 18;
        for (int k = 0; k < period / 18; k++) {
            int sx = (int) ((k * 18 - dist * 0.3F) % period);
            if (sx < 0) sx += period;
            sx -= 18;
            int h = 16 + (int) (Gfx.hash(k, 40) * 16);
            rect(g, sx, ground - h, 3, h, forest);
            rect(g, sx - 2, ground - h + h / 2, 7, 1, leaf);
            rect(g, sx - 1, ground - h + 3, 5, 1, leaf);
        }

        // the ground: gradient, a bright grass edge, pebbles and tufts that scroll
        g.fillGradient(0, ground, vw, vh, lerp(0xFFB9E3A0, 0xFF2B3A2E, night), lerp(0xFF9BD086, 0xFF1E2A22, night));
        rect(g, 0, ground, vw, 2, lerp(0xFF6BB35A, 0xFF4A6A4A, night));
        rect(g, 0, ground, vw, 1, lerp(0xFF9BE08A, 0xFF5C7E5C, night));
        int off = (int) (dist % 40);
        for (int x = -off; x < vw; x += 40) {
            rect(g, x + 8, ground + 8, 5, 1, lerp(0xFF8CCB78, 0xFF3E5A44, night));
            rect(g, x + 27, ground + 14, 3, 1, lerp(0xFF8CCB78, 0xFF3E5A44, night));
            rect(g, x + 17, ground + 4, 2, 2, lerp(0xFFA89A82, 0xFF4A4A52, night));
            rect(g, x + 35, ground + 10, 1, 2, lerp(0xFF6BB35A, 0xFF4A6A4A, night));
            rect(g, x + 36, ground + 9, 1, 2, lerp(0xFF6BB35A, 0xFF4A6A4A, night));
        }

        for (Obs o : obs) drawObs(g, o);
        drawPanda(g);

        // title (before the first jump) and scores
        if (!started) {
            ctextAt(g, Component.translatable("cutemod.dino.title").getString(), vw / 2, 10, ink);
            ctextAt(g, Component.translatable("cutemod.dino.sub").getString(), vw / 2, 24, lerp(0xFF7A7A90, 0xFFB8B0C8, night));
            ctextAt(g, Component.translatable("cutemod.dino.start").getString(), vw / 2, ground - 40, ink);
        } else {
            String s = String.format("%05d", score);
            String h = hi > 0 ? "HI " + String.format("%05d", hi) + "  " : "";
            g.drawString(font(), h + s, vw - 8 - font().width(h + s), 6, ink, false);
        }
        if (over) {
            int w = 150, bh = 36, x = (vw - w) / 2, y = 22;
            Gfx.panel(g, x, y, w, bh, 0xF0302640, 0xF0201828);
            g.drawCenteredString(font(), Component.translatable("cutemod.dino.over"), x + w / 2, y + 6, 0xFFFFD866);
            g.drawCenteredString(font(), Component.translatable("cutemod.ui.score", score), x + w / 2, y + 16, 0xFFFFFFFF);
            g.drawCenteredString(font(), Component.translatable("cutemod.ui.restart"), x + w / 2, y + 26, 0xFFB8B0C8);
        }
    }

    private void ctextAt(GuiGraphics g, String s, int cx, int y, int argb) {
        g.drawString(font(), s, cx - font().width(s) / 2, y, argb, false);
    }

    private void drawObs(GuiGraphics g, Obs o) {
        int x = Math.round(o.x()), y = o.y();
        switch (o.kind()) {
            case 0 -> {   // bamboo stalks: gradient, bright edge, nodes and leaves
                int n = (o.w() + 2) / 6;
                for (int i = 0; i < n; i++) {
                    int sx = x + i * 6, sh = (i % 2 == 0) ? o.h() : o.h() - 6, sy = ground - sh;
                    g.fillGradient(sx, sy, sx + 4, sy + sh, 0xFF7ACB5E, 0xFF4A9A3C);
                    rect(g, sx, sy, 1, sh, 0x66FFFFFF);
                    rect(g, sx + 3, sy, 1, sh, 0x33000000);
                    for (int j = 4; j < sh; j += 8) Gfx.rrect(g, sx - 1, sy + j, 6, 2, 1, 0xFF2F6A2A);
                    Gfx.ellipse(g, sx + 7, sy + 3, 3, 1, 0xFF7ACB5E);
                    Gfx.ellipse(g, sx - 3, sy + 9, 3, 1, 0xFF5DB04A);
                }
            }
            case 1 -> {   // creeper
                Gfx.ellipse(g, x + 6, ground + 1, 8, 2, 0x33000000);
                rect(g, x + 1, y + 14, 4, 6, 0xFF3E9A44); rect(g, x + 7, y + 14, 4, 6, 0xFF3E9A44);          // legs
                rect(g, x + 1, y + 18, 4, 2, 0xFF2E7A34); rect(g, x + 7, y + 18, 4, 2, 0xFF2E7A34);
                rect(g, x, y, 12, 14, 0xFF3E9A44);
                rect(g, x + 1, y + 1, 10, 12, 0xFF5FC25A);
                rect(g, x + 1, y + 1, 10, 1, 0x55FFFFFF);
                rect(g, x + 8, y + 10, 2, 2, 0xFF4CAF50); rect(g, x + 2, y + 11, 2, 1, 0xFF7ADB74);            // skin noise
                rect(g, x + 2, y + 3, 3, 3, 0xFF1B3A1E); rect(g, x + 7, y + 3, 3, 3, 0xFF1B3A1E);
                rect(g, x + 5, y + 6, 2, 3, 0xFF1B3A1E); rect(g, x + 3, y + 9, 6, 3, 0xFF1B3A1E);
                rect(g, x + 3, y + 9, 1, 3, 0xFF5FC25A); rect(g, x + 8, y + 9, 1, 3, 0xFF5FC25A);
            }
            default -> {  // a bee
                boolean up = (t / 5) % 2 == 0;
                Gfx.ellipse(g, x + 5, y + 1 + (up ? 0 : 2), 3, 2, 0xDDEAF8FF);
                Gfx.ellipse(g, x + 10, y + 1 + (up ? 0 : 2), 3, 2, 0xDDEAF8FF);
                Gfx.rrect(g, x - 1, y + 2, 16, 9, 4, 0xFF3A2A1A);
                Gfx.rrect(g, x, y + 3, 14, 7, 3, 0xFFFFCF2E);
                rect(g, x + 4, y + 3, 2, 7, 0xFF3A2A1A); rect(g, x + 9, y + 3, 2, 7, 0xFF3A2A1A);
                rect(g, x + 3, y + 3, 8, 1, 0x66FFFFFF);
                rect(g, x, y + 4, 3, 3, 0xFFFFFFFF); rect(g, x, y + 5, 2, 2, 0xFF2A1D10);
                rect(g, x + 14, y + 6, 2, 1, 0xFF3A2A1A);                                                       // stinger
            }
        }
    }

    private void drawPanda(GuiGraphics g) {
        int white = 0xFFFFFFFF, rim = 0xFFD4D4E2, black = 0xFF2A2433, green = 0xFF5DB04A;
        int bottom = ground - Math.round(dy);
        boolean ducking = duck > 0 && dy == 0;
        int y = bottom - (ducking ? DUCK_H : DH);
        boolean step = dy == 0 && started && !over && (t / 5) % 2 == 0;
        Gfx.ellipse(g, DX + 9, ground + 1, Math.max(4, 10 - Math.round(dy) / 6), 2, Gfx.alpha(0xFF000000, Math.max(0x10, 0x40 - Math.round(dy) * 2)));   // shadow shrinks while jumping
        if (ducking) {
            Gfx.rrect(g, DX - 3, y + 3, 4, 4, 1, white);                                // tail
            Gfx.rrect(g, DX, y + 2, 18, 9, 4, rim);                              // body
            Gfx.rrect(g, DX + 1, y + 3, 16, 7, 3, white);
            rect(g, DX + 3, y + 1, 2, 3, green); rect(g, DX + 8, y, 2, 4, green);
            Gfx.rrect(g, DX + 12, y, 11, 9, 4, rim);                             // head, stretched forward
            Gfx.rrect(g, DX + 13, y + 1, 9, 7, 3, white);
            Gfx.rrect(g, DX + 12, y - 2, 4, 4, 1, black); Gfx.rrect(g, DX + 18, y - 2, 4, 4, 1, black);
            Gfx.ellipse(g, DX + 17, y + 4, 2, 2, black); rect(g, DX + 17, y + 3, 1, 1, white);
            rect(g, DX + 20, y + 5, 2, 2, black);
            Gfx.rrect(g, DX + 3, y + 9, 4, 3, 1, black); Gfx.rrect(g, DX + 11, y + 9, 4, 3, 1, black);
        } else {
            Gfx.rrect(g, DX - 3, y + 10, 4, 4, 1, white);                               // tail
            Gfx.rrect(g, DX + 1, y + 9, 15, 9, 4, rim);                          // body
            Gfx.rrect(g, DX + 2, y + 10, 13, 7, 3, white);
            rect(g, DX + 3, y + 7, 2, 3, green); rect(g, DX + 7, y + 6, 2, 4, green); rect(g, DX + 11, y + 7, 2, 3, green);
            Gfx.rrect(g, DX + 6, y, 13, 11, 4, rim);                             // head
            Gfx.rrect(g, DX + 7, y + 1, 11, 9, 3, white);
            Gfx.rrect(g, DX + 6, y - 3, 4, 4, 1, black); Gfx.rrect(g, DX + 14, y - 3, 4, 4, 1, black);   // ears
            Gfx.ellipse(g, DX + 12, y + 4, 2, 2, black);                         // eye patch
            if (over) { rect(g, DX + 11, y + 3, 1, 1, white); rect(g, DX + 13, y + 5, 1, 1, white); }
            else rect(g, DX + 12, y + 3, 1, 2, white);
            rect(g, DX + 15, y + 6, 3, 2, black);                                // nose
            rect(g, DX + 9, y + 8, 2, 1, 0x66FF7A9A);                            // blush
            Gfx.rrect(g, DX + 3, y + 17 - (step ? 2 : 0), 4, 3, 1, black);       // legs
            Gfx.rrect(g, DX + 10, y + 17 - (step ? 0 : 2), 4, 3, 1, black);
        }
    }

    public Component status() { return Component.translatable("cutemod.ui.score", score); }

    @Override
    public String hintKey() { return "cutemod.dino.hint"; }

    @Override
    public Component endTitle() { return Component.translatable("cutemod.dino.over"); }
}
