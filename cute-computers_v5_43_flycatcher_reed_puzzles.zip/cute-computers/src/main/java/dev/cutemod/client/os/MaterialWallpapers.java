package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Eight still, minimalist Material You wallpapers for CuteMarket (numbers 51-58): a calm tonal field in one colour with a few big flat shapes
 * (circles, soft waves, rings, a diagonal), like the wallpapers of the Pixel phones. Blue, green, purple, rose, peach, teal, sand and a dark one.
 * Drawn from fractions of the box, so they fit the tiny shop icon and the whole desktop alike. Nothing moves.
 */
final class MaterialWallpapers {
    static final int FIRST = 51, COUNT = 8;

    private static GuiGraphics gg;
    private static int bx, by, bw, bh;

    private MaterialWallpapers() {}

    // background, light shape, strong shape, soft shape (a mix of the first two)
    private static final int[][] PAL = {
            {0xFFD3E3FD, 0xFFA8C7FA, 0xFF0B57D0},      // 51 blue
            {0xFFCDEFD6, 0xFF9AD9AE, 0xFF146C2E},      // 52 green
            {0xFFEADDFF, 0xFFD0BCFF, 0xFF6750A4},      // 53 purple
            {0xFFFFD8E4, 0xFFFFB1C8, 0xFF984061},      // 54 rose
            {0xFFFFDCC2, 0xFFFFB787, 0xFF904D00},      // 55 peach
            {0xFFCDEFEA, 0xFF8FD8D0, 0xFF006A65},      // 56 teal
            {0xFFFFF0B3, 0xFFF5D96B, 0xFF6D5E00},      // 57 sand
            {0xFF121317, 0xFF2A2D3A, 0xFFA8C7FA}};     // 58 dark
    private static final int[] VARIANT = {0, 1, 2, 3, 0, 2, 1, 3};

    static void draw(GuiGraphics g, int x, int y, int w, int h, int idx) {
        gg = g; bx = x; by = y; bw = Math.max(1, w); bh = Math.max(1, h);
        int i = Math.floorMod(idx - FIRST, COUNT);
        int bg = PAL[i][0], a = PAL[i][1], b = PAL[i][2], soft = Theme.blend(a, bg, 0.5f);
        rect(0, 0, bw, bh, bg);
        switch (VARIANT[i]) {
            case 0 -> {                                                   // a big round hill in the corner with a core, and a small dot
                disc(bw * 85 / 100, bh * 98 / 100, bh * 70 / 100, a);
                disc(bw * 85 / 100, bh * 98 / 100, bh * 32 / 100, b);
                disc(bw * 18 / 100, bh * 22 / 100, Math.max(1, bh * 7 / 100), a);
            }
            case 1 -> {                                                   // two soft waves one above the other
                for (int cx = 0; cx < bw; cx++) {
                    double u = cx / (double) Math.max(1, bw - 1);
                    int y1 = (int) Math.round(bh * (0.56 + 0.08 * Math.sin(u * 2.6 + 0.5)));
                    int y2 = (int) Math.round(bh * (0.76 + 0.06 * Math.sin(u * 3.4 + 2.0)));
                    rect(cx, y1, cx + 1, bh, a);
                    rect(cx, y2, cx + 1, bh, b);
                }
                disc(bw * 76 / 100, bh * 24 / 100, Math.max(1, bh * 9 / 100), soft);
            }
            case 2 -> {                                                   // rings that grow from the bottom-left corner
                disc(0, bh, bh, a);
                disc(0, bh, bh * 78 / 100, bg);
                disc(0, bh, bh * 56 / 100, a);
                disc(0, bh, bh * 34 / 100, b);
            }
            default -> {                                                  // a diagonal field and a round sun
                for (int cx = 0; cx < bw; cx++) {
                    double u = cx / (double) Math.max(1, bw - 1);
                    rect(cx, (int) Math.round(bh * (0.92 - 0.55 * u)), cx + 1, bh, a);
                }
                disc(bw * 72 / 100, bh * 32 / 100, Math.max(2, bh * 14 / 100), b);
            }
        }
        gg = null;
    }

    /** A filled box inside the wallpaper's box, clipped by hand (x0..x1, y0..y1 relative to the box). */
    private static void rect(int x0, int y0, int x1, int y1, int argb) {
        x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(bw, x1); y1 = Math.min(bh, y1);
        if (x1 > x0 && y1 > y0) gg.fill(bx + x0, by + y0, bx + x1, by + y1, argb);
    }

    private static void disc(int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            rect(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }
}
