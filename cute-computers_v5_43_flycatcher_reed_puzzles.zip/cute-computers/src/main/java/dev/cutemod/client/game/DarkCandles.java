package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Tiny horror game: you walk in a dark room with a flashlight and collect candles.
 * Something creeps up on you - it freezes while the light touches it, but it moves in the dark.
 */
public class DarkCandles extends MiniGame {
    private static final double R = 52, HALF_COS = Math.cos(0.62);
    private static final int CELL = 4;

    private double px, py, fx, fy, ex, ey, cx, cy;
    private int taken, ticks, stun;

    @Override
    public void reset() {
        score = 0; over = false; taken = 0; ticks = 0; stun = 0;
        px = W / 2.0; py = H / 2.0; fx = 1; fy = 0;
        ex = 12; ey = 12;
        placeCandle();
    }

    private void placeCandle() {
        for (int i = 0; i < 30; i++) {
            cx = 10 + rnd.nextInt(W - 20);
            cy = 10 + rnd.nextInt(H - 20);
            if (Math.hypot(cx - px, cy - py) > 35) break;
        }
    }

    private boolean lit() {
        double dx = ex - px, dy = ey - py, d = Math.hypot(dx, dy);
        return d < R && d > 0.001 && (dx * fx + dy * fy) / d > HALF_COS;
    }

    @Override
    public void tick() {
        ticks++;
        double dx = mx - px, dy = my - py, d = Math.hypot(dx, dy);
        if (d > 3) { fx = dx / d; fy = dy / d; }
        if (d > 8) {
            px += fx * 1.3;
            py += fy * 1.3;
        }
        px = Math.max(4, Math.min(W - 4, px));
        py = Math.max(4, Math.min(H - 4, py));

        // it only moves in the dark
        double ddx = px - ex, ddy = py - ey, md = Math.hypot(ddx, ddy);
        if (stun > 0) stun--;
        else if (!lit() && md > 0.001) {
            double sp = Math.min(1.0, 0.4 + 0.05 * taken);
            ex += ddx / md * sp;
            ey += ddy / md * sp;
        }
        md = Math.hypot(px - ex, py - ey);
        if (md < 6) { over = true; beep(); growl(G_SCREAM); return; }
        if (md < 40 && ticks % 24 == 0) beep(); // heartbeat
        if (md < 70 && ticks % 130 == 0) growl(G_DEEP);                     // it growls from the dark

        if (Math.hypot(cx - px, cy - py) < 7) {
            taken++;
            score += 10;
            stun = 60;
            pling(1.6F);
            placeCandle();
        }
    }

    private void drawFigure(GuiGraphics g, int x, int y) {
        // a tall dark figure with long arms, a pale blank face and a thin suit line
        Gfx.ellipse(g, x, y + 9, 7, 2, 0x66000000);
        rect(g, x - 8, y - 4, 3, 10, 0xFF0A0A0F); rect(g, x + 5, y - 4, 3, 10, 0xFF0A0A0F);          // long arms
        rect(g, x - 9, y + 5, 2, 3, 0xFFE8E4EC); rect(g, x + 7, y + 5, 2, 3, 0xFFE8E4EC);            // pale hands
        Gfx.rrect(g, x - 5, y - 8, 10, 17, 2, 0xFF0A0A0F);
        rect(g, x, y - 5, 1, 12, 0xFF22222C);                                                           // jacket line
        Gfx.rrect(g, x - 4, y - 14, 8, 7, 3, 0xFFEDE9F0);                                               // pale face
        rect(g, x - 3, y - 12, 2, 3, 0xFF000000); rect(g, x + 1, y - 12, 2, 3, 0xFF000000);            // empty eyes
        rect(g, x - 2, y - 8, 4, 1, 0xFF3A3040);
    }

    @Override
    public void render(GuiGraphics g) {
        // old stone floor: dark gaps, tiles with a light top edge, a few cracks
        rect(g, 0, 0, W, H, 0xFF1C1624);
        for (int ty = 0; ty < H; ty += 20) {
            for (int tx = 0; tx < W; tx += 20) {
                rect(g, tx + 1, ty + 1, 18, 18, ((tx + ty) / 20) % 2 == 0 ? 0xFF3A3042 : 0xFF322839);
                rect(g, tx + 1, ty + 1, 18, 1, 0x22FFFFFF);
            }
        }
        for (int i = 0; i < 14; i++) {
            int cx0 = (int) (Gfx.hash(i, 30) * (W - 8)), cy0 = (int) (Gfx.hash(i, 31) * (H - 8));
            rect(g, cx0, cy0, 4, 1, 0x33000000); rect(g, cx0 + 3, cy0 + 1, 3, 1, 0x33000000); rect(g, cx0 + 5, cy0 + 2, 1, 2, 0x33000000);
        }

        boolean lit = lit();
        double md = Math.hypot(px - ex, py - ey);
        if (lit || md < 14) drawFigure(g, (int) ex, (int) ey);

        // darkness in blocks, the runs of equal darkness are merged into one rectangle (about 4x fewer draw calls)
        for (int y = 0; y < H; y += CELL) {
            int runA = -1, runX = 0;
            for (int x = 0; x <= W; x += CELL) {
                int a = -2;
                if (x < W) {
                    double ddx = x + CELL / 2.0 - px, ddy = y + CELL / 2.0 - py, dd = Math.hypot(ddx, ddy);
                    if (dd < 12) a = 0x30;
                    else if (dd < R && (ddx * fx + ddy * fy) / dd > HALF_COS) a = 0x10 + (int) (dd / R * 0x50);
                    else a = 0xEE;
                    a = (a + 4) & ~7;
                    if (a > 0xEE) a = 0xEE;
                }
                if (a != runA) {
                    if (runA > 0) rect(g, runX, y, x - runX, CELL, runA << 24);
                    runA = a; runX = x;
                }
            }
        }
        // a warm glow around the flashlight
        Gfx.glow(g, (int) (px + fx * 8), (int) (py + fy * 8), 16, 0xFFFFE0A0, 44);

        // the candle always glows, the eyes are always watching
        int fl = (ticks / 4) % 2;
        int ccx = (int) cx, ccy = (int) cy;
        Gfx.glow(g, ccx, ccy - 3, 18, 0xFFFFC832, 70);
        Gfx.ellipse(g, ccx, ccy + 4, 4, 1, 0xFF6A5A40);
        Gfx.rrect(g, ccx - 1, ccy - 1, 3, 5, 1, 0xFFF3E6C8);
        rect(g, ccx - 1, ccy - 1, 1, 5, 0xFFFFFFFF);
        rect(g, ccx, ccy - 4 - fl, 1, 3 + fl, 0xFFFFC832);
        rect(g, ccx, ccy - 3 - fl, 1, 1 + fl, 0xFFFFF3B0);
        if (!lit && (ticks % 140) >= 6) {
            Gfx.glow(g, (int) ex - 2, (int) ey - 8, 7, 0xFFFF2A2A, 120);
            Gfx.glow(g, (int) ex + 2, (int) ey - 8, 7, 0xFFFF2A2A, 120);
            rect(g, (int) ex - 3, (int) ey - 9, 2, 2, 0xFFFF2A2A);
            rect(g, (int) ex + 1, (int) ey - 9, 2, 2, 0xFFFF2A2A);
            rect(g, (int) ex - 3, (int) ey - 9, 1, 1, 0xFFFFD0D0);
            rect(g, (int) ex + 1, (int) ey - 9, 1, 1, 0xFFFFD0D0);
        }

        // you: a pink cat with ears, the white dot looks where the flashlight points
        int ppx = (int) px, ppy = (int) py;
        Gfx.ellipse(g, ppx, ppy + 4, 5, 2, 0x55000000);
        rect(g, ppx - 4, ppy - 6, 3, 3, 0xFFF58FB8); rect(g, ppx + 1, ppy - 6, 3, 3, 0xFFF58FB8);
        rect(g, ppx - 3, ppy - 5, 1, 1, 0xFFFFC2D8); rect(g, ppx + 2, ppy - 5, 1, 1, 0xFFFFC2D8);
        Gfx.ball(g, ppx, ppy, 4, 0xFFF58FB8);
        rect(g, (int) (px + fx * 2) - 1, (int) (py + fy * 2) - 1, 2, 2, 0xFFFFFFFF);
        rect(g, (int) (px + fx * 2), (int) (py + fy * 2), 1, 1, 0xFF3A2A3A);

        if (md < 25 && !over && (ticks / 3) % 3 == 0) rect(g, 0, 0, W, H, 0x33FF0000); // panic flicker
        Gfx.vignette(g, W, H, 110);

        if (over) { // jumpscare face under the game over window
            int sh = (int) ((System.nanoTime() / 60_000_000L) % 2) * 2 - 1;
            rect(g, 0, 0, W, H, 0xDD200000);
            Gfx.glow(g, 110, 66, 64, 0xFFFF2A2A, 110);
            Gfx.ellipse(g, 110 + sh, 64, 40, 54, 0xFFC9C4CE);
            Gfx.ellipse(g, 110 + sh, 62, 38, 52, 0xFFEDE9F0);
            Gfx.ellipse(g, 92 + sh, 48, 14, 11, 0xFF000000); Gfx.ellipse(g, 128 + sh, 48, 14, 11, 0xFF000000);
            Gfx.glow(g, 92 + sh, 48, 9, 0xFFFF2A2A, 150); Gfx.glow(g, 128 + sh, 48, 9, 0xFFFF2A2A, 150);
            rect(g, 90 + sh, 46, 4, 4, 0xFFFF2A2A); rect(g, 126 + sh, 46, 4, 4, 0xFFFF2A2A);
            Gfx.poly(g, new int[]{107 + sh, 113 + sh, 110 + sh}, new int[]{62, 62, 72}, 0xFF1A1020);
            Gfx.ellipse(g, 110 + sh, 92, 26, 15, 0xFF000000);
            for (int i = 0; i < 7; i++) {
                rect(g, 87 + sh + i * 6, 80, 4, 6 + (i % 2) * 2, 0xFFFFFFFF);
                rect(g, 87 + sh + i * 6, 99 - (i % 2) * 2, 4, 6, 0xFFE0DCE4);
            }
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score", score); }

    @Override
    public String hintKey() { return "cutemod.hint.horror"; }
}
