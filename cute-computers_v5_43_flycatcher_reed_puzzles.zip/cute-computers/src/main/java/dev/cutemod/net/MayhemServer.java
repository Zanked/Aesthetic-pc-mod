package dev.cutemod.net;

import dev.cutemod.data.MayhemSim;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The server side of online Dangerous Weapons: rooms with four slots, and the rounds that run in them.
 * <p>
 * A player makes a room (he is in the first slot); the other three slots are open for people, and the host clicks them to make
 * a slot a computer player or empty. A slot that is still open when the round starts becomes a computer player, so a room
 * can be people only, computer players only, or both. The round itself is {@link MayhemSim}; it runs here: every server tick
 * (20 a second) it takes three steps of 1/60 s and every person gets the whole picture. Rooms live in memory only.
 */
public final class MayhemServer {
    private MayhemServer() {}

    private static final int OFF = 0, OPEN = 1, AI = 2, HUMAN = 3;
    private static final int[] LIVES = {2, 3, 5};

    private static final class Room {
        UUID host;
        final int[] type = {HUMAN, OPEN, OPEN, OPEN};
        final UUID[] who = new UUID[4];
        final int[] bits = new int[4];
        final boolean[] jump = new boolean[4], fire = new boolean[4];
        int level = 1, lives = 3, map = MayhemSim.RANDOM_MAP;
        MayhemSim sim;
        boolean inGame;
    }

    private static final List<Room> rooms = new ArrayList<>();
    private static final Map<UUID, Room> roomOf = new HashMap<>();
    private static final Map<UUID, Long> lastRequest = new HashMap<>();
    private static MinecraftServer server;

    public static void handle(ServerPlayer sp, MayhemActionPayload p) {
        server = sp.getServer();
        if (server == null) return;
        UUID me = sp.getUUID();
        switch (p.action()) {
            case 0 -> request(sp);
            case 1 -> create(sp);
            case 2 -> join(sp, p.name());
            case 3 -> { leave(me); push(sp, 0); }
            case 4 -> slotClick(sp, p.a());
            case 5 -> {
                Room r = roomOf.get(me);
                if (r != null && r.host.equals(me) && !r.inGame && p.a() >= 0 && p.a() <= 2) { r.level = p.a(); pushRoom(r, 0); }
            }
            case 6 -> start(sp);
            case 8 -> {
                Room r = roomOf.get(me);
                if (r != null && r.host.equals(me) && !r.inGame && (p.a() == 2 || p.a() == 3 || p.a() == 5)) { r.lives = p.a(); pushRoom(r, 0); }
            }
            case 9 -> {
                Room r = roomOf.get(me);
                if (r != null && r.host.equals(me) && !r.inGame && p.a() >= 0 && p.a() <= MayhemSim.RANDOM_MAP) { r.map = p.a(); pushRoom(r, 0); }
            }
            case 7 -> input(me, p.a(), p.b());
            default -> { }
        }
    }

    private static ServerPlayer online(UUID id) { return id == null || server == null ? null : server.getPlayerList().getPlayer(id); }

    private static String name(UUID id) {
        ServerPlayer p = online(id);
        return p == null ? "" : p.getGameProfile().getName();
    }

    private static int slotOf(Room r, UUID id) {
        for (int i = 0; i < 4; i++) if (id.equals(r.who[i])) return i;
        return -1;
    }

    private static int humans(Room r) {
        int n = 0;
        for (int i = 0; i < 4; i++) if (r.who[i] != null) n++;
        return n;
    }

    private static int openSlots(Room r) {
        int n = 0;
        for (int i = 0; i < 4; i++) if (r.type[i] == OPEN && r.who[i] == null) n++;
        return n;
    }

    // ------------------------------------------------------------------ what the player sees

    private static void push(ServerPlayer sp, int notice) {
        if (server == null) return;
        Room mine = roomOf.get(sp.getUUID());
        List<String> hosts = new ArrayList<>();
        List<Integer> open = new ArrayList<>();
        for (Room r : rooms) {
            if (r == mine || r.inGame) continue;
            int o = openSlots(r);
            String h = name(r.host);
            if (o > 0 && !h.isEmpty()) { hosts.add(h); open.add(o); }
        }
        List<Integer> types = new ArrayList<>();
        List<String> names = new ArrayList<>();
        boolean inRoom = mine != null, inGame = false, youHost = false;
        int slot = 0, level = 1, lives = 3, map = MayhemSim.RANDOM_MAP;
        if (mine != null) {
            inGame = mine.inGame;
            youHost = mine.host.equals(sp.getUUID());
            slot = Math.max(0, slotOf(mine, sp.getUUID()));
            level = mine.level;
            lives = mine.lives;
            map = mine.map;
            for (int i = 0; i < 4; i++) { types.add(mine.type[i]); names.add(mine.who[i] == null ? "" : name(mine.who[i])); }
        } else {
            for (int i = 0; i < 4; i++) { types.add(0); names.add(""); }
        }
        PacketDistributor.sendToPlayer(sp, new MayhemLobbyPayload(notice, hosts, open, inRoom, inGame, youHost, slot, types, names, level, lives, map));
    }

    private static void pushTo(UUID id, int notice) {
        ServerPlayer p = online(id);
        if (p != null) push(p, notice);
    }

    private static void pushRoom(Room r, int notice) {
        for (int i = 0; i < 4; i++) if (r.who[i] != null) pushTo(r.who[i], notice);
    }

    private static void request(ServerPlayer sp) {
        long now = System.currentTimeMillis();
        Long last = lastRequest.get(sp.getUUID());
        if (last != null && now - last < 400) return;
        lastRequest.put(sp.getUUID(), now);
        push(sp, 0);
    }

    // ------------------------------------------------------------------ rooms

    private static void create(ServerPlayer sp) {
        UUID me = sp.getUUID();
        leave(me);
        Room r = new Room();
        r.host = me;
        r.who[0] = me;
        rooms.add(r);
        roomOf.put(me, r);
        push(sp, 0);
    }

    private static void join(ServerPlayer sp, String hostName) {
        UUID me = sp.getUUID();
        Room target = null;
        for (Room r : rooms) if (!r.inGame && name(r.host).equalsIgnoreCase(hostName)) { target = r; break; }
        if (target == null || roomOf.get(me) == target) { push(sp, target == null ? 1 : 0); return; }
        int slot = -1;
        for (int i = 1; i < 4 && slot < 0; i++) if (target.type[i] == OPEN && target.who[i] == null) slot = i;
        if (slot < 0) { push(sp, 1); return; }
        leave(me);
        target.who[slot] = me;
        target.type[slot] = HUMAN;
        roomOf.put(me, target);
        pushRoom(target, 0);
    }

    /** The player leaves his room (or a round that is running: he is out of it), or the server. */
    public static void leave(UUID me) {
        Room r = roomOf.remove(me);
        if (r == null) return;
        int slot = slotOf(r, me);
        if (slot >= 0) {
            r.who[slot] = null;
            if (r.inGame && r.sim != null) { r.sim.drop(slot); r.bits[slot] = 0; r.jump[slot] = r.fire[slot] = false; }
            else r.type[slot] = OPEN;
        }
        if (humans(r) == 0) { rooms.remove(r); return; }
        int notice = 0;
        if (r.host.equals(me)) {
            for (int i = 0; i < 4; i++) if (r.who[i] != null) { r.host = r.who[i]; break; }
            notice = 4;
        }
        pushRoom(r, notice);
    }

    public static void forget(UUID me) {
        leave(me);
        lastRequest.remove(me);
    }

    private static void slotClick(ServerPlayer sp, int i) {
        Room r = roomOf.get(sp.getUUID());
        if (r == null || !r.host.equals(sp.getUUID()) || r.inGame || i < 1 || i > 3) return;
        if (r.type[i] == HUMAN && r.who[i] != null) {                          // a person: sent away
            UUID out = r.who[i];
            r.who[i] = null;
            r.type[i] = OPEN;
            roomOf.remove(out);
            pushTo(out, 2);
        } else {
            r.type[i] = r.type[i] == OPEN ? AI : r.type[i] == AI ? OFF : OPEN;
        }
        pushRoom(r, 0);
    }

    // ------------------------------------------------------------------ rounds

    private static void start(ServerPlayer sp) {
        Room r = roomOf.get(sp.getUUID());
        if (r == null || !r.host.equals(sp.getUUID())) return;
        if (r.inGame) return;                                                  // a round is running
        int active = 0;
        for (int i = 0; i < 4; i++) {
            if (r.type[i] == HUMAN && r.who[i] == null) r.type[i] = OPEN;
            if (r.type[i] != OFF) active++;                                      // a slot that is still open will get a computer player
        }
        if (active < 2) { push(sp, 3); return; }
        MayhemSim sim = new MayhemSim();
        for (int i = 0; i < 4; i++) {
            if (r.type[i] == OPEN) r.type[i] = AI;                               // nobody came: a computer player takes the place
            if (r.type[i] == HUMAN) sim.setup(i, MayhemSim.KIND_HUMAN);
            else if (r.type[i] == AI) sim.setup(i, MayhemSim.KIND_BOT);
            else sim.setup(i, MayhemSim.KIND_OFF);
        }
        sim.configure(r.lives, r.level, -1, r.map);
        sim.start();
        r.sim = sim;
        r.inGame = true;
        Arrays.fill(r.bits, 0);
        Arrays.fill(r.jump, false);
        Arrays.fill(r.fire, false);
        pushRoom(r, 0);
        sendState(r);
    }

    private static void input(UUID me, int bits, int press) {
        Room r = roomOf.get(me);
        if (r == null || !r.inGame) return;
        int slot = slotOf(r, me);
        if (slot < 0) return;
        r.bits[slot] = bits & 31;
        if ((press & 1) != 0) r.jump[slot] = true;
        if ((press & 2) != 0) r.fire[slot] = true;
    }

    private static void sendState(Room r) {
        if (r.sim == null) return;
        byte[] data = r.sim.pack();
        for (int i = 0; i < 4; i++) {
            ServerPlayer p = online(r.who[i]);
            if (p != null) PacketDistributor.sendToPlayer(p, new MayhemStatePayload(i, data));
        }
    }

    /** Called 20 times a second: every running round takes three steps. */
    public static void tick(MinecraftServer s) {
        if (rooms.isEmpty()) return;
        server = s;
        for (Room r : new ArrayList<>(rooms)) {
            if (!r.inGame || r.sim == null) continue;
            for (int i = 0; i < 4; i++) {
                if (r.who[i] != null) r.sim.input(i, r.bits[i], r.jump[i], r.fire[i]);
                r.jump[i] = false;
                r.fire[i] = false;
            }
            for (int k = 0; k < 3; k++) r.sim.tick();
            sendState(r);
            if (r.sim.over) {                                                    // the round is over: back to the room
                r.inGame = false;
                r.sim = null;
                for (int i = 0; i < 4; i++) if (r.type[i] == HUMAN && r.who[i] == null) r.type[i] = OPEN;
                pushRoom(r, 0);
            }
        }
    }
}
