package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client, 20 times a second during a round: your corner (0..3) and the whole round ({@link dev.cutemod.data.BomberSim#pack()}). */
public record BomberStatePayload(int slot, byte[] data) implements CustomPacketPayload {
    public static final Type<BomberStatePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "bomber_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BomberStatePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, BomberStatePayload::slot,
            ByteBufCodecs.byteArray(1024), BomberStatePayload::data,
            BomberStatePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(BomberStatePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onBomberState(p));
    }
}
