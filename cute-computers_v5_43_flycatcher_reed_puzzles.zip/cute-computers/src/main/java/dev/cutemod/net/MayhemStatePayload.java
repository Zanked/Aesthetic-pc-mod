package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client, 20 times a second during a round (3 steps of the world each): your slot (0..3) and the whole round ({@link dev.cutemod.data.MayhemSim#pack()}). */
public record MayhemStatePayload(int slot, byte[] data) implements CustomPacketPayload {
    public static final Type<MayhemStatePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "mayhem_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, MayhemStatePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, MayhemStatePayload::slot,
            ByteBufCodecs.byteArray(4096), MayhemStatePayload::data,
            MayhemStatePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(MayhemStatePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onMayhemState(p));
    }
}
