package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: something the player did in online Bombers.
 * action: 0 refresh (rooms, my room), 1 make a room, 2 join the room of {@code name}, 3 leave the room (or the round),
 * 4 the host clicks slot {@code a} (1..3: open -> computer -> empty; a person in it is sent away), 5 the host picks the skill of the
 * computer players {@code a} (0..2), 6 the host starts a round (or the next one), 9 the host picks the mode {@code a} (0..4), 8 the host picks the map {@code a} (0..5, 6 = random), 7 what I do: {@code a} = direction + 1 (0 = none, 1 down,
 * 2 left, 3 right, 4 up), {@code b} = 1 to drop a bomb.
 */
public record BomberActionPayload(int action, int a, int b, String name) implements CustomPacketPayload {
    public static final Type<BomberActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "bomber_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BomberActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, BomberActionPayload::action,
            ByteBufCodecs.VAR_INT, BomberActionPayload::a,
            ByteBufCodecs.VAR_INT, BomberActionPayload::b,
            ByteBufCodecs.stringUtf8(32), BomberActionPayload::name,
            BomberActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(BomberActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) BomberServer.handle(sp, p); });
    }
}
