package dev.cutemod.data;

import java.util.Random;

/**
 * The computer fighter of Pet Brawl. It "presses" the same keys a player has: it holds a direction and sends attack pulses to
 * {@link FightSim#setInput}. Easy reacts slowly and rarely blocks; hard reads the rival's moves, blocks low and high, punishes whiffed
 * moves, uses anti-airs and chains combos. No Minecraft classes.
 */
public final class FightBot {
    private final Random r;
    private final int level;
    private final float react, blockChance, readLow, aggression, antiAir, punish, comboChance, special;
    private int think, plan, planT, blockT;
    private boolean blockCrouch, wasOppAtk, wasOppRecover, antiRolled;
    private FightSim.Proj reacted;

    public FightBot(int level, long seed) {
        this.level = Math.max(0, Math.min(2, level));
        r = new Random(seed);
        react = new float[]{26, 13, 6}[this.level];
        blockChance = new float[]{0.22F, 0.55F, 0.86F}[this.level];
        readLow = new float[]{0.3F, 0.6F, 0.92F}[this.level];
        aggression = new float[]{0.45F, 0.65F, 0.85F}[this.level];
        antiAir = new float[]{0.1F, 0.4F, 0.8F}[this.level];
        punish = new float[]{0.0F, 0.3F, 0.7F}[this.level];
        comboChance = new float[]{0.3F, 0.6F, 0.9F}[this.level];
        special = new float[]{0.2F, 0.45F, 0.7F}[this.level];
    }

    public void act(FightSim s, int me) {
        FightSim.F f = s.p[me], o = s.p[1 - me];
        boolean left = false, right = false, up = false, down = false, pu = false, ki = false, sp = false;
        if (s.phase == FightSim.PH_FIGHT) {
            float dx = o.x - f.x, dist = Math.abs(dx);
            int toward = dx >= 0 ? 1 : -1;
            boolean canAct = f.state == FightSim.IDLE || f.state == FightSim.WALK || f.state == FightSim.CROUCH;
            boolean oppAtk = o.state == FightSim.ATTACK && o.move != null;

            // an attack of the rival has just started: block it or not
            if (oppAtk && !wasOppAtk) {
                float reach = o.move.x1 + 22;
                boolean air = o.y > 6;
                if (dist < reach + (o.move.rank == 3 ? 30 : 0) && r.nextFloat() < blockChance) {
                    blockT = o.move.total() + 6;
                    blockCrouch = !air && o.move.height == 2 ? r.nextFloat() < readLow : (!air && o.move.height == 1 && r.nextFloat() > readLow + 0.05F);
                    if (o.move.height == 2 && r.nextFloat() >= readLow) blockCrouch = false;
                }
            }
            wasOppAtk = oppAtk;
            // a fire ball is coming
            for (FightSim.Proj b : s.proj) {
                if (b.owner == me || b == reacted) continue;
                if ((b.vx > 0) == (f.x > b.x) && Math.abs(b.x - f.x) < 60) {
                    reacted = b;
                    float c = r.nextFloat();
                    if (c < blockChance) { blockT = 22; blockCrouch = false; }
                    else if (c < blockChance + 0.15F * level && canAct) { up = true; right = toward > 0; left = toward < 0; }
                }
            }
            boolean oppRecover = oppAtk && o.moveT > o.move.startup + o.move.active && o.move.id != FightSim.M_JPUNCH && o.move.id != FightSim.M_JKICK;
            boolean punishNow = oppRecover && !wasOppRecover && dist < 34 && r.nextFloat() < punish;
            wasOppRecover = oppRecover;

            if (f.state == FightSim.ATTACK && f.hitDone && f.buf == 0 && f.move != null && !f.air && r.nextFloat() < comboChance * 0.25F) {
                if (f.move.rank == 1) { if (f.meter >= FightSim.SP_COST && r.nextFloat() < special) sp = true; else ki = true; }
                else if (f.move.rank == 2 && f.meter >= FightSim.SP_COST && r.nextFloat() < special + 0.2F) sp = true;
            }
            if (blockT > 0 && canAct) {
                blockT--;
                if (toward > 0) left = true; else right = true;
                down = blockCrouch;
            } else if (canAct) {
                if (o.y > 10 && dist < 50 && !antiRolled && r.nextFloat() < antiAir) {
                    antiRolled = true;
                    if (f.meter >= FightSim.SP_COST && f.ch != FightSim.FOX) sp = true; else pu = true;
                } else if (o.y <= 2) antiRolled = false;
                if (!sp && !pu && punishNow) {
                    if (dist < 24) pu = true; else ki = true;
                } else if (!sp && !pu) {
                    if (--think <= 0) {
                        think = (int) (react * 0.6F) + r.nextInt((int) react + 1);
                        float c = r.nextFloat();
                        if (dist > 48) {
                            plan = c < 0.16F * (level + 1) && f.ch == FightSim.FOX && f.meter >= FightSim.SP_COST ? 5 : c < 0.1F ? 4 : 1;
                        } else if (dist > 31) plan = c < 0.15F ? 4 : c < 0.25F ? 2 : 1;
                        else plan = c < aggression ? 3 : c < aggression + 0.12F ? 2 : 6;
                        planT = 6 + r.nextInt(14);
                    }
                    switch (plan) {
                        case 1 -> { if (dist > 26) { right = toward > 0; left = toward < 0; } else plan = 3; }
                        case 2 -> { right = toward < 0; left = toward > 0; }
                        case 3 -> {
                            if (dist > 30) { right = toward > 0; left = toward < 0; }
                            else {
                                float c = r.nextFloat();
                                if (f.meter >= FightSim.SP_COST && c < special * 0.35F && f.ch != FightSim.FOX) sp = true;
                                else if (dist < 23 && c < 0.5F) pu = true;
                                else if (c < 0.62F) { ki = true; }
                                else if (c < 0.8F) { down = true; ki = true; }
                                else { down = true; pu = true; }
                                plan = 0; think = 8 + r.nextInt((int) react);
                            }
                        }
                        case 4 -> { up = true; right = toward > 0; left = toward < 0; plan = 0; }
                        case 5 -> { sp = true; plan = 0; think = 30; }
                        case 6 -> { down = r.nextFloat() < 0.5F; }
                        default -> { }
                    }
                    if (--planT <= 0 && plan != 3) plan = 0;
                }
            } else if (f.state == FightSim.JUMP && f.y > 6 && dist < 34 && f.buf == 0 && !f.airUsed && r.nextFloat() < 0.15F) {
                if (r.nextBoolean()) ki = true; else pu = true;
            }
        }
        s.setInput(me, left, right, up, down, pu, ki, sp);
    }
}
