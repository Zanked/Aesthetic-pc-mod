package dev.cutemod.data;

import java.util.ArrayList;
import java.util.List;

/**
 * Pet Brawl: the rules of a one-on-one fight (no Minecraft classes, so it is tested on its own). 60 ticks a second, the world is
 * {@link #W} wide and the floor is at {@link #FLOOR}; heights are measured up from the floor.
 * <ul>
 * <li>Normals: punch, kick, crouching punch (fast), crouching kick (a low sweep that knocks down), jump punch / jump kick.</li>
 * <li>One special per animal (costs {@link #SP_COST} of the 100 meter): Mochi's claw dash, Kitsune's fire ball, Bamboo's slam and
 * Usagi's rising carrot kick. Normals chain into stronger moves when they hit or are blocked (punch, kick, special).</li>
 * <li>Block by holding AWAY from the rival: standing blocks high and mid hits, crouching blocks high and low hits.</li>
 * <li>Best of three rounds, 45 seconds a round; the one with more health wins when the time is out.</li>
 * </ul>
 * The picture (client/game/Fighters) reads {@link #p}, {@link #proj}, the phase and the {@link #events} list.
 */
public final class FightSim {
    public static final int W = 220, FLOOR = 112, WALL_L = 14, WALL_R = 206;
    public static final int CAT = 0, FOX = 1, PANDA = 2, BUNNY = 3, CHARS = 4;
    public static final int IDLE = 0, WALK = 1, CROUCH = 2, JUMP = 3, ATTACK = 4, BLOCKSTUN = 5, HITSTUN = 6, KNOCKED = 7,
            LYING = 8, GETUP = 9, KO = 10, WIN = 11;
    public static final int PH_INTRO = 0, PH_FIGHT = 1, PH_KO = 2, PH_RESULT = 3, PH_OVER = 4;
    public static final int INTRO_LEN = 110, RESULT_LEN = 150, ROUND_TIME = 45 * 60, MAX_ROUNDS = 5;
    public static final float SP_COST = 34F, METER_MAX = 100F, GRAVITY = 0.22F;
    public static final float[] SPEED = {1.05F, 1.2F, 0.85F, 1.2F};
    public static final float[] DMG = {0.92F, 1.12F, 1.25F, 1.0F};
    public static final float[] JUMP_V = {3.6F, 3.5F, 3.2F, 4.1F};

    // events for the picture and the sounds
    public static final int EV_HIT = 0, EV_BLOCK = 1, EV_JUMP = 2, EV_LAND = 3, EV_ATTACK = 4, EV_PROJ = 5, EV_KO = 6, EV_FIGHT = 7,
            EV_ROUND = 8, EV_NOMETER = 9, EV_WIN = 10, EV_TIMEUP = 11, EV_SPECIAL = 12, EV_SHOCK = 13, EV_RISE = 14, EV_DASH = 15,
            EV_DOWN = 16, EV_COUNTER = 17, EV_PROJHIT = 18;

    public static final class Ev {
        public final int type, a, b;
        public final float x, y;
        Ev(int type, float x, float y, int a, int b) { this.type = type; this.x = x; this.y = y; this.a = a; this.b = b; }
    }

    // move ids
    public static final int M_PUNCH = 0, M_KICK = 1, M_CPUNCH = 2, M_CKICK = 3, M_JPUNCH = 4, M_JKICK = 5, M_SPECIAL = 6;

    public static final class Move {
        public final int id, startup, active, recover, rank, hitStun, blockStun, freeze, height;   // height: 0 high, 1 mid, 2 low
        public final float dmg, x0, x1, y0, y1, pushHit, pushBlock, chip;
        public final boolean knock, melee;

        Move(int id, int startup, int active, int recover, float dmg, float x0, float x1, float y0, float y1, int hitStun, int blockStun,
             float pushHit, float pushBlock, int height, boolean knock, int rank, int freeze, float chip, boolean melee) {
            this.id = id; this.startup = startup; this.active = active; this.recover = recover; this.dmg = dmg;
            this.x0 = x0; this.x1 = x1; this.y0 = y0; this.y1 = y1; this.hitStun = hitStun; this.blockStun = blockStun;
            this.pushHit = pushHit; this.pushBlock = pushBlock; this.height = height; this.knock = knock; this.rank = rank;
            this.freeze = freeze; this.chip = chip; this.melee = melee;
        }

        public int total() { return startup + active + recover; }
    }

    public static final Move PUNCH = new Move(M_PUNCH, 5, 3, 8, 5.5F, 4, 22, 16, 33, 17, 10, 1.6F, 1.8F, 1, false, 1, 3, 0.1F, true);
    public static final Move KICK = new Move(M_KICK, 8, 4, 12, 9F, 4, 28, 6, 30, 20, 12, 2.4F, 2.6F, 1, false, 2, 5, 0.1F, true);
    public static final Move CPUNCH = new Move(M_CPUNCH, 4, 3, 7, 4F, 4, 21, 8, 22, 14, 8, 1.2F, 1.4F, 1, false, 1, 2, 0.1F, true);
    public static final Move CKICK = new Move(M_CKICK, 8, 4, 14, 7F, 2, 31, 0, 8, 22, 12, 2.0F, 2.2F, 2, true, 2, 5, 0.1F, true);
    public static final Move JPUNCH = new Move(M_JPUNCH, 3, 999, 0, 6F, 2, 19, -2, 20, 16, 11, 1.4F, 1.6F, 0, false, 0, 3, 0.1F, true);
    public static final Move JKICK = new Move(M_JKICK, 5, 999, 0, 8F, 2, 23, -8, 14, 18, 12, 1.8F, 2.0F, 0, false, 0, 4, 0.1F, true);
    public static final Move[] SPECIAL = {
            new Move(M_SPECIAL, 9, 14, 16, 11F, 0, 27, 4, 30, 24, 16, 2.0F, 2.6F, 1, true, 3, 6, 0.25F, true),      // Mochi: claw dash
            new Move(M_SPECIAL, 12, 1, 18, 0F, 0, 0, 0, 0, 0, 0, 0, 0, 1, false, 3, 0, 0, false),                    // Kitsune: fire ball
            new Move(M_SPECIAL, 14, 5, 18, 15F, 0, 31, 0, 36, 26, 18, 2.4F, 3.0F, 1, true, 3, 7, 0.25F, true),       // Bamboo: slam
            new Move(M_SPECIAL, 3, 13, 20, 13F, 0, 17, 8, 48, 26, 14, 1.6F, 2.0F, 1, true, 3, 6, 0.25F, true)};      // Usagi: rising kick
    public static final Move FIREBALL = new Move(M_SPECIAL, 0, 0, 0, 11F, 0, 0, 0, 0, 20, 12, 2.2F, 2.4F, 1, false, 3, 4, 0.2F, false);

    public static final class Input {
        public boolean left, right, up, down;
    }

    public static final class Proj {
        public float x, y, vx;
        public int owner, life, age;
    }

    public static final class F {
        public int ch, face = 1, state, stateT, moveT, stun, buf, bufT, lag, invuln, flash, hitsTaken, comboShow, comboHits, wins, perfects;
        public float x, y, vx, vy, hp = 100, meter, dmgTaken;
        public Move move;
        public boolean hitDone, airUsed, air, blocking;
        public final Input in = new Input();

        public boolean airborne() { return y > 0.01F; }
    }

    public final F[] p = {new F(), new F()};
    public final List<Proj> proj = new ArrayList<>();
    public final List<Ev> events = new ArrayList<>();
    public int phase = PH_INTRO, phaseT, round = 1, timer = ROUND_TIME, stage, freeze, slow, matchWinner = -1, roundWinner = -1, tickCount;
    public boolean timeUp, perfect;
    private boolean slowTog;

    public FightSim(int ch0, int ch1, int firstStage) {
        p[0].ch = ch0; p[1].ch = ch1;
        stage = firstStage;
        startRound();
    }

    // ---------------------------------------------------------------- input
    /** Sets what player i holds now; attack keys are pulses (true on the tick they were pressed) and are remembered for 7 ticks. */
    public void setInput(int i, boolean left, boolean right, boolean up, boolean down, boolean punch, boolean kick, boolean special) {
        F f = p[i];
        f.in.left = left; f.in.right = right; f.in.up = up; f.in.down = down;
        if (phase != PH_FIGHT) return;
        if (special) { f.buf = 3; f.bufT = 8; }
        else if (kick) { f.buf = 2; f.bufT = 8; }
        else if (punch) { f.buf = 1; f.bufT = 8; }
    }

    public List<Ev> takeEvents(List<Ev> into) {
        into.addAll(events);
        events.clear();
        return into;
    }

    private void ev(int type, float x, float y, int a, int b) { events.add(new Ev(type, x, y, a, b)); }

    // ---------------------------------------------------------------- rounds
    private void startRound() {
        phase = PH_INTRO; phaseT = 0; timer = ROUND_TIME; timeUp = false; roundWinner = -1; perfect = false; freeze = 0; slow = 0;
        proj.clear();
        for (int i = 0; i < 2; i++) {
            F f = p[i];
            f.x = i == 0 ? 80 : 140; f.y = 0; f.vx = 0; f.vy = 0; f.face = i == 0 ? 1 : -1;
            f.hp = 100; f.state = IDLE; f.stateT = 0; f.move = null; f.moveT = 0; f.stun = 0; f.buf = 0; f.bufT = 0; f.lag = 0;
            f.invuln = 0; f.flash = 0; f.hitsTaken = 0; f.comboShow = 0; f.comboHits = 0; f.dmgTaken = 0; f.hitDone = false; f.airUsed = false;
            f.air = false; f.blocking = false;
        }
        ev(EV_ROUND, 110, 50, round, 0);
    }

    // ---------------------------------------------------------------- the tick
    public void tick() {
        tickCount++;
        if (slow > 0) {
            slow--;
            slowTog = !slowTog;
            if (slowTog) return;
        }
        if (freeze > 0) { freeze--; return; }
        switch (phase) {
            case PH_INTRO -> {
                phaseT++;
                step(0, false); step(1, false);
                if (phaseT >= INTRO_LEN) {
                    phase = PH_FIGHT; phaseT = 0;
                    p[0].buf = p[1].buf = 0;
                    ev(EV_FIGHT, 110, 50, 0, 0);
                }
            }
            case PH_FIGHT -> {
                phaseT++;
                timer--;
                step(0, true); step(1, true);
                separate();
                detectHits();
                updateProjectiles();
                checkEnd();
            }
            case PH_KO -> {
                phaseT++;
                step(0, false); step(1, false);
                separate();
                if (phaseT >= (timeUp ? 70 : 105)) toResult();
            }
            case PH_RESULT -> {
                phaseT++;
                step(0, false); step(1, false);
                if (phaseT >= RESULT_LEN) nextRoundOrEnd();
            }
            default -> { phaseT++; step(0, false); step(1, false); }
        }
        for (F f : p) { if (f.comboShow > 0) f.comboShow--; }
    }

    private void checkEnd() {
        boolean d0 = p[0].hp <= 0, d1 = p[1].hp <= 0;
        if (d0 || d1) {
            roundWinner = d0 && d1 ? -1 : (d0 ? 1 : 0);
            phase = PH_KO; phaseT = 0; timeUp = false;
            slow = Math.max(slow, 56);
            ev(EV_KO, (p[0].x + p[1].x) / 2, 50, d0 ? 0 : 1, 0);
        } else if (timer <= 0) {
            timer = 0;
            roundWinner = p[0].hp > p[1].hp ? 0 : p[1].hp > p[0].hp ? 1 : -1;
            phase = PH_KO; phaseT = 0; timeUp = true;
            ev(EV_TIMEUP, 110, 50, 0, 0);
        }
    }

    private void toResult() {
        phase = PH_RESULT; phaseT = 0;
        if (roundWinner >= 0) {
            F w = p[roundWinner];
            w.wins++;
            perfect = w.dmgTaken <= 0.01F;
            if (perfect) w.perfects++;
            if (w.state != KNOCKED) { w.state = WIN; w.stateT = 0; w.vx = 0; w.move = null; }
        } else {
            p[0].wins++; p[1].wins++;
        }
        ev(EV_WIN, 110, 50, roundWinner, 0);
    }

    private void nextRoundOrEnd() {
        boolean end = p[0].wins >= 2 || p[1].wins >= 2 || round >= MAX_ROUNDS;
        if (end) {
            phase = PH_OVER; phaseT = 0;
            matchWinner = p[0].wins > p[1].wins ? 0 : p[1].wins > p[0].wins ? 1 : 2;
        } else {
            round++;
            stage = (stage + 1) % 3;
            startRound();
        }
    }

    // ---------------------------------------------------------------- one fighter
    private static boolean groundState(int s) { return s == IDLE || s == WALK || s == CROUCH; }

    private void step(int i, boolean control) {
        F f = p[i], o = p[1 - i];
        Input in = control ? f.in : NONE;
        f.stateT++;
        if (f.bufT > 0 && --f.bufT == 0) f.buf = 0;
        if (f.invuln > 0) f.invuln--;
        if (f.flash > 0) f.flash--;
        if (control) f.meter = Math.min(METER_MAX, f.meter + 0.02F);
        f.blocking = false;
        switch (f.state) {
            case IDLE, WALK, CROUCH -> ground(f, o, in);
            case JUMP -> {
                if (f.buf != 0 && f.buf != 3 && !f.airUsed) { if (startAttack(f, f.buf, in)) { f.buf = 0; f.bufT = 0; } }
            }
            case ATTACK -> attack(f, o, in);
            case BLOCKSTUN, HITSTUN -> {
                f.blocking = f.state == BLOCKSTUN;
                if (--f.stun <= 0) { setState(f, IDLE); f.hitsTaken = 0; }
            }
            case LYING -> {
                if (f.hp <= 0) { setState(f, KO); }
                else if (f.stateT >= 26) { setState(f, GETUP); f.invuln = 16; f.hitsTaken = 0; }
            }
            case GETUP -> { if (f.stateT >= 14) setState(f, IDLE); }
            default -> { }
        }
        integrate(f);
    }

    private static final Input NONE = new Input();

    private static void setState(F f, int s) {
        if (f.state != s) { f.state = s; f.stateT = 0; }
    }

    private void ground(F f, F o, Input in) {
        f.face = o.x >= f.x ? 1 : -1;
        if (f.lag > 0) { f.lag--; f.vx = 0; return; }
        boolean back = f.face == 1 ? in.left : in.right;
        f.blocking = back;
        if (f.buf == 3 && f.meter < SP_COST) { ev(EV_NOMETER, f.x, f.y + 20, 0, 0); f.buf = 0; f.bufT = 0; }
        if (f.buf != 0 && startAttack(f, f.buf, in)) { f.buf = 0; f.bufT = 0; return; }
        if (in.up && !in.down) {
            f.state = JUMP; f.stateT = 0; f.vy = JUMP_V[f.ch]; f.y = 0.02F; f.airUsed = false;
            f.vx = ((in.right ? 1 : 0) - (in.left ? 1 : 0)) * 1.3F;
            ev(EV_JUMP, f.x, 0, f.ch, 0);
            return;
        }
        if (in.down) { setState(f, CROUCH); f.vx = 0; }
        else if (in.left != in.right) {
            setState(f, WALK);
            int dir = in.right ? 1 : -1;
            f.vx = dir * SPEED[f.ch] * (dir == f.face ? 1F : 0.8F);
        } else { setState(f, IDLE); f.vx = 0; }
    }

    private Move pick(F f, int kind, Input in) {
        boolean air = f.y > 0.01F;
        if (air) return kind == 1 ? JPUNCH : kind == 2 ? JKICK : null;
        if (kind == 3) return f.meter >= SP_COST ? SPECIAL[f.ch] : null;
        if (kind == 1) return in.down ? CPUNCH : PUNCH;
        return in.down ? CKICK : KICK;
    }

    private boolean startAttack(F f, int kind, Input in) {
        Move m = pick(f, kind, in);
        if (m == null) return false;
        if (m.id >= M_JPUNCH && m.id <= M_JKICK) f.airUsed = true;
        if (m.id == M_SPECIAL) { f.meter -= SP_COST; ev(EV_SPECIAL, f.x, f.y + 20, p[0] == f ? 0 : 1, f.ch); }
        f.state = ATTACK; f.stateT = 0; f.move = m; f.moveT = 0; f.hitDone = false; f.air = f.y > 0.01F;
        if (!f.air) f.vx = 0;
        ev(EV_ATTACK, f.x, f.y + 18, m.id, f.ch);
        return true;
    }

    private void attack(F f, F o, Input in) {
        Move m = f.move;
        int t = ++f.moveT;
        boolean special = m.id == M_SPECIAL;
        int endActive = m.startup + m.active;
        if (special) {
            switch (f.ch) {
                case CAT -> {
                    if (t == m.startup + 1) ev(EV_DASH, f.x, f.y + 16, f.face, 0);
                    if (t > m.startup && t <= endActive) f.vx = f.face * 3.7F;
                    else if (t == endActive + 1) f.vx *= 0.25F;
                }
                case FOX -> {
                    if (t == m.startup) {
                        Proj b = new Proj();
                        b.owner = p[0] == f ? 0 : 1; b.x = f.x + f.face * 17; b.y = f.y + 19; b.vx = f.face * 2.7F; b.life = 100;
                        proj.add(b);
                        ev(EV_PROJ, b.x, b.y, b.owner, 0);
                    }
                }
                case PANDA -> { if (t == m.startup + 1) ev(EV_SHOCK, f.x + f.face * 24, FLOOR, f.face, 0); }
                default -> {
                    if (t == m.startup + 1) { f.vy = 3.7F; f.y = 0.5F; f.vx = f.face * 1.0F; f.air = true; ev(EV_RISE, f.x, 0, f.face, 0); }
                    if (t <= endActive) f.invuln = Math.max(f.invuln, 2);
                }
            }
        }
        // a hit that connected (or was blocked) can be cancelled into a stronger move
        if (f.hitDone && !f.air && f.buf != 0) {
            Move nm = pick(f, f.buf, in);
            if (nm != null && nm.rank > m.rank && startAttack(f, f.buf, in)) { f.buf = 0; f.bufT = 0; return; }
        }
        if (t >= m.startup + m.active + m.recover) {
            f.move = null;
            if (f.y > 0.01F) setState(f, JUMP); else setState(f, IDLE);
        }
    }

    private void land(F f) {
        f.y = 0; f.vy = 0;
        ev(EV_LAND, f.x, 0, f.state == KNOCKED ? 1 : 0, 0);
        switch (f.state) {
            case JUMP -> { setState(f, IDLE); f.vx = 0; f.lag = 2; }
            case ATTACK -> { f.move = null; setState(f, IDLE); f.vx = 0; f.lag = 5; f.air = false; }
            case KNOCKED -> { setState(f, LYING); f.vx = 0; ev(EV_DOWN, f.x, 0, 0, 0); }
            default -> { }
        }
    }

    private void integrate(F f) {
        boolean flying = f.state == JUMP || f.state == KNOCKED || (f.state == ATTACK && (f.air || f.y > 0.01F));
        f.x += f.vx;
        if (flying) {
            f.y += f.vy;
            f.vy -= GRAVITY;
            if (f.y <= 0 && f.vy < 0) land(f);
        } else if (f.state == HITSTUN || f.state == BLOCKSTUN || f.state == ATTACK || f.state == LYING || f.state == KO || f.state == GETUP) {
            f.vx *= 0.8F;
            if (Math.abs(f.vx) < 0.04F) f.vx = 0;
        }
        if (f.x < WALL_L) { f.x = WALL_L; if (f.vx < 0) f.vx = 0; }
        if (f.x > WALL_R) { f.x = WALL_R; if (f.vx > 0) f.vx = 0; }
    }

    /** Two fighters on the floor do not stand inside each other; against a wall the other one gives way. */
    private void separate() {
        F a = p[0], b = p[1];
        if (a.y > 10 || b.y > 10) return;
        float min = 13F, d = b.x - a.x;
        if (Math.abs(d) >= min) return;
        float s = d > 0 ? 1 : d < 0 ? -1 : a.face, push = (min - Math.abs(d)) / 2F;
        a.x -= s * push; b.x += s * push;
        if (a.x < WALL_L) { a.x = WALL_L; b.x = a.x + s * min; }
        if (b.x < WALL_L) { b.x = WALL_L; a.x = b.x + s * min; }
        if (a.x > WALL_R) { a.x = WALL_R; b.x = a.x + s * min; }
        if (b.x > WALL_R) { b.x = WALL_R; a.x = b.x + s * min; }
    }

    // ---------------------------------------------------------------- hits
    private boolean hurt(F d, float[] box) {
        if (d.invuln > 0 || d.state == LYING || d.state == GETUP || d.state == KO || d.state == KNOCKED || d.state == WIN) return false;
        float hw = d.state == CROUCH ? 8 : 7, hh = d.state == CROUCH ? 20 : 33;
        box[0] = d.x - hw; box[1] = d.x + hw; box[2] = d.y; box[3] = d.y + hh;
        return true;
    }

    private void detectHits() {
        Move m0 = activeMove(p[0]), m1 = activeMove(p[1]);
        float[] hb0 = m0 != null ? hitbox(p[0], m0) : null, hb1 = m1 != null ? hitbox(p[1], m1) : null;
        float[] hu = new float[4];
        boolean h0 = false, h1 = false;
        if (hb0 != null && hurt(p[1], hu) && overlap(hb0, hu)) h0 = true;
        if (hb1 != null && hurt(p[0], hu) && overlap(hb1, hu)) h1 = true;
        float[] c0 = h0 ? contact(hb0, p[1]) : null, c1 = h1 ? contact(hb1, p[0]) : null;
        if (h0) resolve(0, 1, m0, c0[0], c0[1]);
        if (h1) resolve(1, 0, m1, c1[0], c1[1]);
    }

    private Move activeMove(F f) {
        if (f.state != ATTACK || f.hitDone || f.move == null || !f.move.melee) return null;
        Move m = f.move;
        return f.moveT > m.startup && f.moveT <= m.startup + m.active ? m : null;
    }

    private float[] hitbox(F f, Move m) {
        float x0 = f.face == 1 ? f.x + m.x0 : f.x - m.x1, x1 = f.face == 1 ? f.x + m.x1 : f.x - m.x0;
        return new float[]{x0, x1, f.y + m.y0, f.y + m.y1};
    }

    private static boolean overlap(float[] a, float[] b) { return a[0] < b[1] && a[1] > b[0] && a[2] < b[3] && a[3] > b[2]; }

    private float[] contact(float[] hb, F d) {
        float cx = Math.max(hb[0], d.x - 7), cx2 = Math.min(hb[1], d.x + 7);
        float cy = Math.max(hb[2], d.y), cy2 = Math.min(hb[3], d.y + 30);
        return new float[]{(cx + cx2) / 2F, (cy + cy2) / 2F};
    }

    private boolean canBlock(F d, F a, Move m) {
        if (d.y > 0.01F) return false;
        if (!(groundState(d.state) || d.state == BLOCKSTUN)) return false;
        if (d.lag > 0 && d.state != BLOCKSTUN) { /* landing: may still block */ }
        boolean back = a.x > d.x ? d.in.left : d.in.right;
        if (!back) return false;
        boolean crouch = d.in.down;
        if (m.height == 2) return crouch;
        if (m.height == 1) return !crouch;
        return true;
    }

    /** a hit (or a blocked hit) of move m by player ai on player di at (hx, hy). */
    private void resolve(int ai, int di, Move m, float hx, float hy) {
        F a = p[ai], d = p[di];
        if (m.melee) a.hitDone = true;
        float dir = a.x <= d.x ? 1 : -1;
        boolean atWall = d.x <= WALL_L + 1 || d.x >= WALL_R - 1;
        d.face = a.x > d.x ? 1 : -1;
        if (canBlock(d, a, m)) {
            d.state = BLOCKSTUN; d.stateT = 0; d.stun = m.blockStun; d.move = null; d.vx = dir * m.pushBlock;
            d.hp = Math.max(1F, d.hp - m.dmg * DMG[a.ch] * m.chip);
            d.dmgTaken += m.dmg * DMG[a.ch] * m.chip;
            a.meter = Math.min(METER_MAX, a.meter + 2F); d.meter = Math.min(METER_MAX, d.meter + 2.5F);
            if (m.melee && atWall) a.vx = -dir * m.pushBlock * 0.9F;
            freeze = Math.max(freeze, 3);
            ev(EV_BLOCK, hx, hy, m.melee ? 0 : 1, di);
            return;
        }
        boolean counter = d.state == ATTACK && d.move != null && d.moveT <= d.move.startup;
        d.hitsTaken++;
        a.comboHits = d.hitsTaken; a.comboShow = 100;
        float scale = Math.max(0.35F, 1F - 0.16F * (d.hitsTaken - 1));
        float dmg = m.dmg * DMG[a.ch] * scale * (counter ? 1.25F : 1F);
        d.hp -= dmg; d.dmgTaken += dmg;
        a.meter = Math.min(METER_MAX, a.meter + 7F); d.meter = Math.min(METER_MAX, d.meter + 4.5F);
        boolean ko = d.hp <= 0;
        if (ko) d.hp = 0;
        if (m.knock || d.y > 0.01F || ko) {
            d.state = KNOCKED; d.stateT = 0; d.vx = dir * (m.knock ? 2.1F : 1.6F);
            d.vy = ko ? 3.2F : d.y > 0.01F ? 1.6F : 2.9F; d.y = Math.max(d.y, 0.5F);
        } else {
            d.state = HITSTUN; d.stateT = 0; d.stun = m.hitStun; d.vx = dir * m.pushHit;
        }
        d.move = null; d.flash = 7; d.lag = 0;
        if (m.melee && atWall && d.y <= 0.6F) a.vx = -dir * m.pushHit * 0.9F;
        freeze = Math.max(freeze, ko ? 16 : m.freeze);
        int power = m.dmg >= 12 ? 3 : m.dmg >= 7 ? 2 : 1;
        ev(m.melee ? EV_HIT : EV_PROJHIT, hx, hy, power, counter ? 1 : 0);
        if (counter) ev(EV_COUNTER, d.x, d.y + 36, di, 0);
    }

    // ---------------------------------------------------------------- fire balls
    private void updateProjectiles() {
        float[] hu = new float[4];
        List<Proj> gone = new ArrayList<>();
        for (Proj b : proj) {
            b.x += b.vx; b.age++;
            if (--b.life <= 0 || b.x < -8 || b.x > W + 8) { gone.add(b); continue; }
            F d = p[1 - b.owner];
            if (hurt(d, hu) && b.x > hu[0] - 4 && b.x < hu[1] + 4 && b.y > hu[2] - 4 && b.y < hu[3] + 2) {
                resolve(b.owner, 1 - b.owner, FIREBALL, b.x, b.y);
                gone.add(b);
                continue;
            }
            for (Proj c : proj) {                                   // two fire balls cancel each other
                if (c.owner != b.owner && Math.abs(c.x - b.x) < 7 && !gone.contains(b)) {
                    gone.add(b);
                    if (!gone.contains(c)) gone.add(c);
                    ev(EV_BLOCK, b.x, b.y, 1, 2);
                    break;
                }
            }
        }
        proj.removeAll(gone);
    }

    public boolean fighting() { return phase == PH_FIGHT; }
}
