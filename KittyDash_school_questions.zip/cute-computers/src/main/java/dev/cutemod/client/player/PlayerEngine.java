package dev.cutemod.client.player;

import dev.cutemod.client.os.Albums;
import net.minecraft.client.Minecraft;

import java.util.List;
import java.util.Random;

/**
 * The music of the portable player. It lives outside of the screen, so the music keeps playing when the window is closed
 * (you can walk around with it). Ticked from ClientHooks.
 */
public final class PlayerEngine {
    private PlayerEngine() {}

    public record Entry(Albums.Album album, Albums.Track track) {
        public boolean same(Entry o) {
            return o != null && album.id().equals(o.album.id()) && track.id().equals(o.track.id());
        }
    }

    public enum Repeat { OFF, ALL, ONE }

    private static List<Entry> queue = List.of();
    private static int index = -1;
    private static boolean playing, shuffle;
    /** The music is the portable player's (it plays only in the headphones) and not the computer's. */
    private static boolean portableSource;
    /** The portable player waits for the headphones (they were taken off, or were never put on). */
    private static boolean waiting;
    private static Repeat repeat = Repeat.OFF;
    private static long posMs, lastNs;
    private static float volume = 0.7F;
    private static SeekSound inst;
    private static final Random RND = new Random();

    // ---------- state for the screen ----------
    public static Entry current() { return index >= 0 && index < queue.size() ? queue.get(index) : null; }

    public static boolean isPlaying() { return playing; }

    /** Is the music started from the portable player (and not from the Music app of a computer)? */
    public static boolean portable() { return portableSource; }

    public static long position() { return posMs; }

    /** Length of the current song in ms (0 if unknown). */
    public static long length() { Entry e = current(); return e == null ? 0 : e.track().seconds() * 1000L; }

    public static float volume() { return volume; }

    public static boolean shuffle() { return shuffle; }

    public static Repeat repeat() { return repeat; }

    // ---------- control ----------
    /** Plays queue[from] and goes on with the next songs of the queue. */
    public static void play(List<Entry> q, int from) { play(q, from, false); }

    /** The same, and says if the portable player starts it (then the headphones must be on). */
    public static void play(List<Entry> q, int from, boolean portable) {
        if (q.isEmpty() || from < 0 || from >= q.size()) return;
        queue = List.copyOf(q);
        index = from;
        portableSource = portable;
        waiting = false;
        startAt(0);
    }

    public static void toggle() {
        if (current() == null) return;
        if (playing) { advanceClock(); playing = false; waiting = false; stopSound(); }
        else startAt(posMs);
    }

    public static void next() {
        if (current() == null) return;
        goTo(pickNext(true));
    }

    public static void prev() {
        if (current() == null) return;
        if (posMs > 3000 || queue.size() < 2) { startAt(0); return; }   // like every player: first back to the start
        goTo(index <= 0 ? queue.size() - 1 : index - 1);
    }

    public static void seek(long ms) {
        if (current() == null) return;
        long len = length();
        ms = Math.max(0, len > 0 ? Math.min(ms, Math.max(0, len - 500)) : ms);
        if (playing) startAt(ms); else posMs = ms;
    }

    public static void setVolume(float v) { volume = Math.max(0F, Math.min(1F, v)); }

    public static void toggleShuffle() { shuffle = !shuffle; }

    public static void cycleRepeat() { repeat = Repeat.values()[(repeat.ordinal() + 1) % Repeat.values().length]; }

    public static void setShuffle(boolean on) { shuffle = on; }

    /** Stops everything (leaving the world, or the computer's player starts). */
    public static void stop() {
        playing = false;
        waiting = false;
        portableSource = false;
        stopSound();
        queue = List.of();
        index = -1;
        posMs = 0;
    }

    // ---------- inside ----------
    private static void goTo(int i) {
        if (i < 0) { playing = false; stopSound(); posMs = 0; return; }
        index = i;
        startAt(0);
    }

    /** The index of the song after this one, or -1 if the queue is over. */
    private static int pickNext(boolean byHand) {
        int n = queue.size();
        if (n == 0) return -1;
        if (shuffle && n > 1) { int i; do { i = RND.nextInt(n); } while (i == index); return i; }
        if (index + 1 < n) return index + 1;
        return (repeat == Repeat.ALL || byHand) ? 0 : -1;
    }

    private static float outVol() { return Math.min(1F, volume); }

    private static void startAt(long ms) {
        Entry e = current();
        if (e == null) return;
        stopSound();
        if (portableSource && !Headphones.worn()) {          // the portable player plays only in the headphones
            playing = false;
            waiting = true;
            posMs = ms;
            Minecraft.getInstance().gui.setOverlayMessage(net.minecraft.network.chat.Component.translatable("cutemod.player.need_headphones"), false);
            return;
        }
        waiting = false;
        inst = new SeekSound(e.track().sound(), outVol(), ms);
        Minecraft.getInstance().getSoundManager().play(inst);
        posMs = ms;
        lastNs = System.nanoTime();
        playing = true;
    }

    private static void stopSound() {
        if (inst != null) { Minecraft.getInstance().getSoundManager().stop(inst); inst = null; }
    }

    private static void advanceClock() {
        long now = System.nanoTime();
        if (!Minecraft.getInstance().isPaused()) posMs += Math.min(200, (now - lastNs) / 1_000_000);
        lastNs = now;
    }

    /** Called 20 times a second. */
    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (waiting) {                                       // the headphones were put on: the song goes on where it was
            if (mc.level == null) stop();
            else if (Headphones.worn()) startAt(posMs);
            return;
        }
        if (!playing) return;
        if (mc.level == null) { stop(); return; }
        if (portableSource && !Headphones.worn()) {          // taken off: pause, and go on when they are put on again
            advanceClock();
            playing = false;
            waiting = true;
            stopSound();
            mc.gui.setOverlayMessage(net.minecraft.network.chat.Component.translatable("cutemod.player.need_headphones"), false);
            return;
        }
        advanceClock();
        if (inst != null) inst.setVol(outVol());
        long len = length();
        boolean over = len > 0 ? posMs >= len + 400
                : (posMs > 3000 && inst != null && !mc.getSoundManager().isActive(inst));
        if (!over) return;
        if (repeat == Repeat.ONE) { startAt(0); return; }
        goTo(pickNext(false));
    }
}
