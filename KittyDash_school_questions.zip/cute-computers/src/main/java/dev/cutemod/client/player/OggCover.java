package dev.cutemod.client.player;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;

/**
 * Reads the picture that is embedded in an .ogg file (Vorbis, Opus or FLAC-in-Ogg).
 * Players store it in the comment header as METADATA_BLOCK_PICTURE (base64 of a FLAC picture block);
 * some old taggers use COVERART (base64 of the bare image). Returns the bytes of the image (png/jpg/...) or null.
 */
public final class OggCover {
    private OggCover() {}

    /** The embedded cover of the file, or null if it has none. Never throws. */
    public static byte[] extract(byte[] ogg) {
        try {
            return find(ogg);
        } catch (Throwable t) {
            return null;
        }
    }

    private static byte[] find(byte[] b) {
        // the first packets of the stream: the comment header is in the 2nd (Vorbis, Opus) or in a later one (FLAC)
        List<byte[]> packets = firstPackets(b, 8);
        byte[] best = null;
        for (byte[] p : packets) {
            int off = commentOffset(p);
            if (off < 0) continue;
            byte[] img = fromComments(p, off);
            if (img != null) { best = img; break; }
        }
        return best;
    }

    /** Where the vendor string of a comment header starts, or -1 if the packet is not a comment header. */
    static int commentOffset(byte[] p) {
        if (p.length > 7 && p[0] == 3 && starts(p, 1, "vorbis")) return 7;          // Vorbis
        if (p.length > 8 && starts(p, 0, "OpusTags")) return 8;                      // Opus
        if (p.length > 4 && (p[0] & 0x7F) == 4 && p.length > 8) return 4;            // FLAC-in-Ogg: a VORBIS_COMMENT block
        return -1;
    }

    private static boolean starts(byte[] p, int at, String s) {
        byte[] t = s.getBytes(StandardCharsets.US_ASCII);
        if (at + t.length > p.length) return false;
        for (int i = 0; i < t.length; i++) if (p[at + i] != t[i]) return false;
        return true;
    }

    private static byte[] fromComments(byte[] p, int off) {
        long vendor = le32(p, off);
        long pos = off + 4 + vendor;
        if (vendor < 0 || pos + 4 > p.length) return null;
        long n = le32(p, (int) pos);
        pos += 4;
        byte[] legacy = null;
        for (long i = 0; i < n && pos + 4 <= p.length; i++) {
            long len = le32(p, (int) pos);
            pos += 4;
            if (len < 0 || pos + len > p.length) break;
            String c = new String(p, (int) pos, (int) len, StandardCharsets.ISO_8859_1);
            pos += len;
            int eq = c.indexOf('=');
            if (eq <= 0) continue;
            String key = c.substring(0, eq).toUpperCase(Locale.ROOT);
            String val = c.substring(eq + 1).replaceAll("\\s", "");
            if (key.equals("METADATA_BLOCK_PICTURE")) {
                byte[] img = flacPicture(Base64.getMimeDecoder().decode(val));
                if (img != null) return img;
            } else if (key.equals("COVERART") && legacy == null) {
                legacy = Base64.getMimeDecoder().decode(val);
            }
        }
        return legacy != null && legacy.length > 0 ? legacy : null;
    }

    /** A FLAC picture block: type, mime, description, w, h, depth, colors, length, data (all numbers big endian). */
    private static byte[] flacPicture(byte[] d) {
        int at = 4;                                              // the picture type
        int mime = be32(d, at); at += 4 + mime;
        int desc = be32(d, at); at += 4 + desc;
        at += 16;                                                // width, height, depth, colors
        int len = be32(d, at); at += 4;
        if (mime < 0 || desc < 0 || len <= 0 || at + len > d.length) return null;
        byte[] img = new byte[len];
        System.arraycopy(d, at, img, 0, len);
        return img;
    }

    /** The first packets of the stream, put together from the Ogg pages (a big picture goes over many pages). */
    static List<byte[]> firstPackets(byte[] b, int max) {
        List<byte[]> out = new ArrayList<>();
        ByteArrayOutputStream cur = new ByteArrayOutputStream();
        int i = 0;
        while (i + 27 <= b.length && out.size() < max) {
            if (b[i] != 'O' || b[i + 1] != 'g' || b[i + 2] != 'g' || b[i + 3] != 'S') break;
            int segs = b[i + 26] & 0xFF;
            int at = i + 27 + segs;
            if (at > b.length) break;
            for (int s = 0; s < segs; s++) {
                int len = b[i + 27 + s] & 0xFF;
                if (at + len > b.length) return out;
                cur.write(b, at, len);
                at += len;
                if (len < 255) {                                  // a segment shorter than 255 ends the packet
                    out.add(cur.toByteArray());
                    cur.reset();
                    if (out.size() >= max) break;
                }
            }
            i = at;
        }
        return out;
    }

    static long le32(byte[] p, int at) {
        if (at < 0 || at + 4 > p.length) return -1;
        return (p[at] & 0xFFL) | ((p[at + 1] & 0xFFL) << 8) | ((p[at + 2] & 0xFFL) << 16) | ((p[at + 3] & 0xFFL) << 24);
    }

    private static int be32(byte[] p, int at) {
        if (at < 0 || at + 4 > p.length) return -1;
        return ((p[at] & 0xFF) << 24) | ((p[at + 1] & 0xFF) << 16) | ((p[at + 2] & 0xFF) << 8) | (p[at + 3] & 0xFF);
    }
}
