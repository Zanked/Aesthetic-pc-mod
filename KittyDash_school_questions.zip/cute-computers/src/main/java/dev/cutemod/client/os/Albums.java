package dev.cutemod.client.os;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/**
 * The albums that music.gradle found in the music/ folder (assets/cutemod/music/albums.json).
 * Loaded once when first needed; {@link #reload()} reads it again.
 */
public final class Albums {
    private Albums() {}

    public record Track(String id, String title, int seconds, SoundEvent sound) {}

    public record Album(String id, String title, String artist, int price, ResourceLocation cover, int coverW, int coverH,
                        List<Track> tracks) {
        public String ownKey() { return "album_" + id; }

        /** Free albums are in the library from the start. */
        public boolean owned() { return price <= 0 || Progress.owned(ownKey()); }

        /** Is this album loaded onto the portable player? (set in the Music app at the computer) */
        public boolean onPlayer() { return owned() && Progress.owned("plr_" + id); }

        public void setOnPlayer(boolean on) { Progress.setFlag("plr_" + id, on); }

        public boolean buy() { return owned() || Progress.buyNamed(ownKey(), price, title); }
    }

    private static List<Album> all;

    public static List<Album> all() {
        if (all == null) load();
        return all;
    }

    public static void reload() { all = null; }

    private static void load() {
        java.util.Map<String, Album> out = new java.util.LinkedHashMap<>();
        all = new ArrayList<>();
        try {
            var rm = Minecraft.getInstance().getResourceManager();
            // the mod itself and the folder of the player each have an albums.json (the lower pack first)
            for (var res : rm.getResourceStack(ResourceLocation.fromNamespaceAndPath("cutemod", "music/albums.json"))) {
                try (Reader r = res.openAsReader()) {
                    JsonArray arr = JsonParser.parseReader(r).getAsJsonObject().getAsJsonArray("albums");
                    for (JsonElement e : arr) {
                        JsonObject a = e.getAsJsonObject();
                        String id = a.get("id").getAsString();
                        List<Track> tracks = new ArrayList<>();
                        for (JsonElement te : a.getAsJsonArray("tracks")) {
                            JsonObject t = te.getAsJsonObject();
                            String tid = t.get("id").getAsString();
                            SoundEvent ev = SoundEvent.createVariableRangeEvent(
                                    ResourceLocation.fromNamespaceAndPath("cutemod", "music." + id + "." + tid));
                            tracks.add(new Track(tid, t.get("title").getAsString(), t.get("seconds").getAsInt(), ev));
                        }
                        boolean cover = a.has("cover") && a.get("cover").getAsBoolean();
                        out.put(id, new Album(id, a.get("title").getAsString(), a.get("artist").getAsString(),
                                a.get("price").getAsInt(),
                                cover ? ResourceLocation.fromNamespaceAndPath("cutemod", "textures/music/" + id + ".png") : null,
                                a.get("coverW").getAsInt(), a.get("coverH").getAsInt(), tracks));
                    }
                } catch (Exception ex) {
                    // one broken albums.json must not break the others
                }
            }
        } catch (Exception ex) {
            // no albums
        }
        all = new ArrayList<>(out.values());
    }
}
