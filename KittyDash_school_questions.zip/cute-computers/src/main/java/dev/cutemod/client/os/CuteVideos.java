package dev.cutemod.client.os;

import java.util.function.BiFunction;
import net.minecraft.client.gui.GuiGraphics;

/**
 * 100 more cute videos for the normal site, every one made from its number alone (nothing is stored), like the abyss
 * of the haunted site (see AbyssVideos) but soft. Six themes: cozy rain, a dancing critter, pastel psychedelics,
 * a lo-fi room, clouds and stars, falling petals (or snow, leaves, hearts). Each video has its own title, channel,
 * three kind comments (all from the language files, key prefix cutemod.tube.g.) and its own little tune.
 */
final class CuteVideos {
    private CuteVideos() {}

    static final int COUNT = 100;
    private static final int PW = 146, PH = 82;

    // ---------- numbers made from the number of the video ----------
    private static long mix(long z) {
        z += 0x9E3779B97F4A7C15L;
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    private static int h(int n, int salt) { return (int) (mix(n * 1_000_033L + salt * 6151L + 7L) >>> 34); }

    static int theme(int n) { return h(n, 1) % 6; }

    static int len(int n) { return 1500 + (h(n, 2) % 5) * 300; }

    static int preview(int n) { return 120 + h(n, 3) % 500; }

    static int likes(int n) { return 12 + h(n, 4) % 3000; }

    static int views(int n) { return 120 + h(n, 5) % 48000; }

    static int avatar(int n) { return hsb((h(n, 6) % 100) / 100F, 0.45F, 0.95F); }

    // ---------- words (from the language files) ----------
    static String title(int n, BiFunction<String, Object[], String> tr) {
        int th = theme(n);
        String s = tr.apply("cutemod.tube.g.t." + th + "." + h(n, 7) % 8, new Object[0]);
        int sf = h(n, 8) % 6;
        if (sf >= 1 && sf <= 4) s += tr.apply("cutemod.tube.g.sfx." + sf, new Object[]{n % 97 + 2});
        return s;
    }

    static String channel(int n, BiFunction<String, Object[], String> tr) {
        return tr.apply("cutemod.tube.g.ch." + theme(n) + "." + h(n, 9) % 5, new Object[0]);
    }

    static String comment(int n, int k, String player, BiFunction<String, Object[], String> tr) {
        int a = h(n, 10) % 8, b = (a + 1 + h(n, 11) % 3) % 8, c = (b + 1 + h(n, 12) % 3) % 8;   // three different ones of eight
        int pick = k == 0 ? a : k == 1 ? b : c;
        return tr.apply("cutemod.tube.g.c." + theme(n) + "." + pick, new Object[]{player});
    }

    // ---------- the tune: 16 steps on a scale, a bass on every bar ----------
    private static final int[][] SCALES = {{0, 2, 4, 7, 9}, {0, 3, 5, 7, 10}, {0, 2, 4, 6, 7, 9, 11}, {0, 2, 3, 7, 8}};

    /** Themes with a melody (the rain and the lo-fi room have their own sounds). */
    static boolean hasTune(int n) { int th = theme(n); return th == 1 || th == 2 || th == 4 || th == 5; }

    static int unit(int n) { return 7 + h(n, 13) % 7; }

    static int instrument(int n) { return new int[]{0, 1, 3}[h(n, 14) % 3]; }

    static int root(int n) { return 4 + h(n, 15) % 9; }

    /** The note (0..24) of step s of the tune, or -1 for a rest. */
    static int noteAt(int n, int s) {
        int[] sc = SCALES[h(n, 16) % SCALES.length];
        int idx = sc.length + h(n, 17) % sc.length;
        int note = -1;
        for (int i = 0; i <= s % 16; i++) {
            int r = h(n, 100 + i);
            idx = Math.max(0, Math.min(sc.length * 2 - 1, idx + (r % 5) - 2));
            note = r % 100 < 22 ? -1 : root(n) + sc[idx % sc.length] + 12 * (idx / sc.length);
            while (note > 24) note -= 12;
        }
        return note;
    }

    // ---------- colours ----------
    private static int hsb(float hue, float sat, float br) {
        return 0xFF000000 | (java.awt.Color.HSBtoRGB(hue - (float) Math.floor(hue), Math.max(0F, Math.min(1F, sat)), Math.max(0F, Math.min(1F, br))) & 0xFFFFFF);
    }

    private static int withAlpha(int rgb, float a) {
        return ((int) (Math.max(0F, Math.min(1F, a)) * 255) << 24) | (rgb & 0xFFFFFF);
    }

    private static int mixc(int a, int b, float p) {
        p = Math.max(0F, Math.min(1F, p));
        int r = 0xFF000000;
        for (int sh = 0; sh <= 16; sh += 8) r |= (int) (((a >> sh) & 255) * (1F - p) + ((b >> sh) & 255) * p) << sh;
        return r;
    }

    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        if (rx <= 0 || ry <= 0) return;
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0.0, 1.0 - dy * (double) dy / (ry * (double) ry))));
            Skin.rect(g, cx - dx, cy + dy, 2 * dx + 1, 1, argb);
        }
    }

    private static final String[] HEART = {"01010", "11111", "11111", "01110", "00100"};

    private static void heart(GuiGraphics g, int x, int y, int sc, int col) {
        for (int r = 0; r < 5; r++) {
            for (int c = 0; c < 5; c++) if (HEART[r].charAt(c) == '1') Skin.rect(g, x + c * sc, y + r * sc, sc, sc, col);
        }
    }

    private static void bands(GuiGraphics g, int top, int bottom, int band) {
        for (int y = 0; y < PH; y += band) Skin.rect(g, 0, y, PW, band, mixc(top, bottom, y / (float) PH));
    }

    /** One frame of the cute video n (0..99) at tick tm, drawn on the 146 x 82 screen. */
    static void draw(GuiGraphics g, int n, int tm, boolean thumb) {
        switch (theme(n)) {
            case 0 -> rain(g, n, tm, thumb);
            case 1 -> critter(g, n, tm, thumb);
            case 2 -> pastel(g, n, tm, thumb);
            case 3 -> lofi(g, n, tm, thumb);
            case 4 -> sky(g, n, tm, thumb);
            default -> petals(g, n, tm, thumb);
        }
    }

    // ---------- 0: cozy rain at a window ----------
    private static void rain(GuiGraphics g, int n, int tm, boolean thumb) {
        float hb = 0.52F + (h(n, 20) % 18) / 100F;
        bands(g, hsb(hb, 0.6F, 0.22F), hsb(hb, 0.4F, 0.5F), thumb ? 14 : 7);
        for (int i = 0; i < (thumb ? 6 : 14); i++) {                                       // lights of a small town
            int x = h(n, 30 + i) % PW, y = 38 + h(n, 50 + i) % 26;
            Skin.rect(g, x, y, 2, 2, ((tm / 40 + i) % 7 == 0) ? 0xFF403830 : 0xFFFFD890);
        }
        float flick = 1F + 0.08F * (float) Math.sin(tm / 9.0);
        Skin.disc(g, 112, 56, Math.round(16 * flick), withAlpha(0xFFB060, 0.14F));          // a warm lamp somewhere in the room
        Skin.disc(g, 112, 56, Math.round(9 * flick), withAlpha(0xFFC878, 0.22F));
        int drops = thumb ? 14 : 46;
        for (int i = 0; i < drops; i++) {
            int x = (i * 37 + h(n, 60 + i)) % PW, sp = 2 + i % 3;
            int y = (tm * sp / 2 + i * 29) % (PH + 8) - 6;
            Skin.rect(g, x, y, 1, 5, 0x88C8E0FF);
        }
        if (!thumb) for (int i = 0; i < 5; i++) {                                           // drops that slide down the glass
            int x = 14 + (h(n, 80 + i) % 118), y = (tm / 5 + i * 17) % (PH - 14);
            Skin.disc(g, x, y, 1, 0x77FFFFFF);
            Skin.rect(g, x, y - 5, 1, 5, 0x33FFFFFF);
        }
        int fr = 0xFF1C1B2A;
        Skin.rect(g, 0, 0, PW, 3, fr);
        Skin.rect(g, 0, 0, 3, PH, fr);
        Skin.rect(g, PW - 3, 0, 3, PH, fr);
        Skin.rect(g, PW / 2 - 1, 0, 2, PH - 10, fr);
        Skin.rect(g, 0, 34, PW, 2, fr);
        Skin.rect(g, 0, PH - 10, PW, 10, 0xFF3A2A28);                                       // the sill
        Skin.rect(g, 22, PH - 18, 9, 8, 0xFFF5E6D8);                                        // a mug
        Skin.rect(g, 31, PH - 16, 2, 4, 0xFFF5E6D8);
        for (int i = 0; i < 3; i++) {                                                       // steam
            int sy = PH - 22 - ((tm / 3 + i * 7) % 18);
            Skin.rect(g, 26 + (int) Math.round(Math.sin(tm / 14.0 + i * 2) * 2), sy, 1, 3, withAlpha(0xFFFFFF, 0.35F));
        }
    }

    // ---------- 1: a critter that dances ----------
    private static void critter(GuiGraphics g, int n, int tm, boolean thumb) {
        float hb = (h(n, 20) % 100) / 100F;
        bands(g, hsb(hb, 0.22F, 0.99F), hsb(hb + 0.08F, 0.28F, 0.93F), thumb ? 20 : 10);
        Skin.rect(g, 0, 62, PW, 20, hsb(hb + 0.3F, 0.3F, 0.88F));
        int kind = h(n, 21) % 5;
        int cx = 73 + (int) Math.round(Math.sin(tm / 40.0) * 16);
        float jump = (float) Math.abs(Math.sin(tm / 10.0)) * 12F;
        int by = 54 - Math.round(jump);
        int rx = 17 + Math.round((12F - jump) / 12F * 2), ry = 14 - Math.round((12F - jump) / 12F * 2);
        oval(g, cx, 63, 14 - Math.round(jump / 3F), 3, 0x33000000);                         // shadow
        int body = switch (kind) {
            case 0 -> hsb(0.33F + (h(n, 22) % 20) / 100F, 0.45F, 0.95F);                    // a slime
            case 1 -> hsb(0.08F + (h(n, 22) % 6) / 100F, 0.4F + (h(n, 23) % 3) / 10F, 0.98F);   // a cat
            case 2 -> 0xFFFAFAFA;                                                           // a panda
            case 3 -> 0xFFFFD84A;                                                           // a bee
            default -> 0xFFFFF4F4;                                                          // a bunny
        };
        int dark = 0xFF3A2A3A;
        if (kind == 1) { Skin.rect(g, cx - 14, by - ry - 5, 6, 7, body); Skin.rect(g, cx + 8, by - ry - 5, 6, 7, body); }   // cat ears
        if (kind == 2) { Skin.disc(g, cx - 12, by - ry + 1, 4, dark); Skin.disc(g, cx + 12, by - ry + 1, 4, dark); }       // panda ears
        if (kind == 4) { oval(g, cx - 8, by - ry - 9, 3, 9, body); oval(g, cx + 8, by - ry - 9, 3, 9, body); oval(g, cx - 8, by - ry - 8, 1, 6, 0xFFF5A0B8); oval(g, cx + 8, by - ry - 8, 1, 6, 0xFFF5A0B8); }
        if (kind == 3) { int wv = Math.round((float) Math.sin(tm / 2.0) * 2); oval(g, cx - 14, by - ry - 2 + wv, 6, 4, 0xAAE8F4FF); oval(g, cx + 14, by - ry - 2 + wv, 6, 4, 0xAAE8F4FF); }   // bee wings
        oval(g, cx, by, rx, ry, body);
        if (kind == 3) for (int i = -1; i <= 1; i += 2) Skin.rect(g, cx + i * 6 - 1, by - ry + 2, 3, ry * 2 - 3, dark);     // stripes
        if (kind == 2) { oval(g, cx - 6, by - 3, 4, 5, dark); oval(g, cx + 6, by - 3, 4, 5, dark); }                        // panda eye patches
        boolean blink = tm % 110 < 5;
        for (int s = -1; s <= 1; s += 2) {
            if (blink) Skin.rect(g, cx + s * 6 - 1, by - 3, 3, 1, kind == 2 ? 0xFFFFFFFF : dark);
            else { Skin.disc(g, cx + s * 6, by - 3, 2, kind == 2 ? 0xFFFFFFFF : dark); Skin.rect(g, cx + s * 6, by - 4, 1, 1, 0xFFFFFFFF); }
            Skin.disc(g, cx + s * 11, by + 3, 2, withAlpha(0xF58FB8, 0.7F));                // cheeks
        }
        Skin.rect(g, cx - 2, by + 3, 5, 1, dark);                                           // a smile
        Skin.rect(g, cx - 3, by + 2, 1, 1, dark);
        Skin.rect(g, cx + 3, by + 2, 1, 1, dark);
        for (int i = 0; i < (thumb ? 2 : 5); i++) {                                         // hearts float up
            int hx = (h(n, 30 + i) % (PW - 12)) + (int) Math.round(Math.sin(tm / 25.0 + i) * 3);
            int hy = PH - (int) ((tm * 0.5 + i * 17) % PH);
            heart(g, hx, hy, 1, withAlpha(0xF58FB8, 0.85F));
        }
    }

    // ---------- 2: pastel psychedelics ----------
    private static void pastel(GuiGraphics g, int n, int tm, boolean thumb) {
        float hb = (h(n, 20) % 100) / 100F, ph = tm * 0.012F * (0.7F + (h(n, 21) % 100) / 100F);
        float f1 = 0.05F + (h(n, 22) % 50) / 1000F, f2 = 0.06F + (h(n, 23) % 60) / 1000F;
        int cell = thumb ? 12 : 6, mode = h(n, 24) % 3;
        for (int y = 0; y < PH; y += cell) {
            for (int x = 0; x < PW; x += cell) {
                float dx = x - 73, dy = y - 41;
                double r = Math.sqrt(dx * dx + dy * dy);
                double v = mode == 0 ? Math.sin(dx * f1 + ph * 3) + Math.sin(dy * f2 - ph * 2.3) + Math.sin(r * 0.13 - ph * 4)
                        : mode == 1 ? Math.sin(r * (f1 + 0.1) - ph * 5) * 2 + Math.sin(Math.atan2(dy, dx) * 3 + ph * 2)
                        : Math.sin(dx * f1 * 1.5 + Math.sin(dy * f2 * 2 + ph * 2) * 2) * 2 + Math.sin(dy * f2 - ph);
                float q = (float) (v / 6 + 0.5);
                Skin.rect(g, x, y, cell, cell, hsb(hb + q * 0.5F + ph * 0.05F, 0.32F + 0.25F * q, 0.88F + 0.12F * q));
            }
        }
        for (int i = 0; i < (thumb ? 2 : 5); i++) {
            int hx = (h(n, 30 + i) % (PW - 20)) + (int) Math.round(Math.sin(tm / 30.0 + i) * 6);
            int hy = PH - (int) ((tm * 0.45 + i * 19) % (PH + 12));
            heart(g, hx, hy, 2, withAlpha(0xFFFFFF, 0.8F));
        }
    }

    // ---------- 3: a lo-fi room ----------
    private static void lofi(GuiGraphics g, int n, int tm, boolean thumb) {
        float hb = (h(n, 20) % 100) / 100F;
        boolean night = h(n, 21) % 2 == 0;
        Skin.rect(g, 0, 0, PW, PH, hsb(hb, 0.3F, night ? 0.32F : 0.62F));                  // the wall
        Skin.rect(g, 16, 8, 56, 40, 0xFF2A2030);                                            // the window
        Skin.rect(g, 19, 11, 50, 34, night ? mixc(0xFF1A1F4A, 0xFF4A2A6A, 0.5F) : 0xFFA8D8F8);
        for (int i = 0; i < 3; i++) {                                                       // clouds or stars
            int cx = (int) ((tm * (0.15F + 0.07F * i) + i * 22) % 60) + 12;
            if (night) Skin.rect(g, 21 + (h(n, 40 + i) % 44), 13 + (h(n, 50 + i) % 28), 1, 1, ((tm / 30 + i) % 3 == 0) ? 0xFFFFE8A0 : 0xFFFFFFFF);
            else oval(g, Math.min(66, cx + 6), 18 + i * 9, 7, 3, 0xFFFFFFFF);
        }
        if (night) Skin.disc(g, 56, 22, 5, 0xFFFFF0B8);
        Skin.rect(g, 43, 11, 2, 34, 0xFF2A2030);
        Skin.rect(g, 19, 27, 50, 2, 0xFF2A2030);
        Skin.rect(g, 0, 56, PW, 26, hsb(0.07F, 0.5F, 0.42F));                               // the desk
        Skin.rect(g, 0, 56, PW, 2, hsb(0.07F, 0.5F, 0.55F));
        int posters = 2;                                                                    // posters
        for (int i = 0; i < posters; i++) {
            Skin.rect(g, 86 + i * 24, 10, 18, 22, 0xFFF8F0E8);
            Skin.rect(g, 88 + i * 24, 12, 14, 18, hsb(hb + i * 0.3F, 0.35F, 0.95F));
            heart(g, 91 + i * 24, 17, 2, 0xFFFFFFFF);
        }
        float glow = 1F + 0.05F * (float) Math.sin(tm / 11.0);                              // the lamp
        Skin.rect(g, 118, 40, 2, 16, 0xFF2A2030);
        Skin.rect(g, 112, 36, 14, 5, 0xFFFFC878);
        if (night) { Skin.disc(g, 119, 50, Math.round(22 * glow), withAlpha(0xFFB060, 0.10F)); Skin.disc(g, 119, 48, Math.round(12 * glow), withAlpha(0xFFB060, 0.14F)); }
        Skin.rect(g, 8, 48, 10, 8, 0xFFC86A4A);                                             // a plant
        for (int i = -1; i <= 1; i++) {
            int sway = (int) Math.round(Math.sin(tm / 40.0 + i) * 1.5);
            oval(g, 13 + i * 5 + sway, 42 - Math.abs(i) * 2, 3, 6, 0xFF4FA860);
        }
        int cat = Math.round((float) Math.sin(tm / 28.0) * 1F);                             // a sleeping cat that breathes
        oval(g, 50, 53 - cat, 13, 5 + cat, 0xFFF2A55A);
        Skin.disc(g, 62, 52, 5, 0xFFF2A55A);
        Skin.rect(g, 60, 50, 1, 2, 0xFF3A2A3A);
        Skin.rect(g, 64, 50, 1, 2, 0xFF3A2A3A);
        Skin.rect(g, 86, 49, 9, 8, 0xFFF5E6D8);                                             // a mug
        Skin.rect(g, 95, 51, 2, 4, 0xFFF5E6D8);
        for (int i = 0; i < (thumb ? 1 : 3); i++) {
            int sy = 46 - ((tm / 3 + i * 6) % 14);
            Skin.rect(g, 90 + (int) Math.round(Math.sin(tm / 12.0 + i * 2) * 2), sy, 1, 3, withAlpha(0xFFFFFF, 0.4F));
        }
    }

    // ---------- 4: clouds and stars ----------
    private static void sky(GuiGraphics g, int n, int tm, boolean thumb) {
        int v = h(n, 20) % 4;
        int[][] pal = {{0xFF5AA8F0, 0xFFD8F0FF}, {0xFF6A4AA8, 0xFFFFA0A0}, {0xFF0E1240, 0xFF4A2A78}, {0xFFA890E0, 0xFFFFD0B0}};
        bands(g, pal[v][0], pal[v][1], thumb ? 14 : 8);
        boolean night = v == 2;
        if (night) {
            for (int i = 0; i < (thumb ? 8 : 24); i++) {
                int x = h(n, 30 + i) % PW, y = h(n, 60 + i) % 50;
                Skin.rect(g, x, y, 1, 1, (tm / 25 + i) % 4 == 0 ? 0xFF8090C0 : 0xFFFFFFFF);
            }
            int p = tm % 700;                                                               // a shooting star
            if (p < 40) { int sx = 110 - p * 3, sy = 6 + p; for (int k = 0; k < 8; k++) Skin.rect(g, sx + k * 2, sy - k, 2, 1, withAlpha(0xFFFFFF, 1F - k / 8F)); }
        }
        int sunY = 22 + (int) Math.round(Math.sin(tm / 90.0) * 3);
        Skin.disc(g, 30 + h(n, 21) % 80, sunY, 9, night ? 0xFFFFF0B8 : withAlpha(0xFFE8A0, 0.9F));
        for (int i = 0; i < 4; i++) {
            int x = (int) ((i * 50 + tm * (0.2F + 0.08F * i)) % (PW + 50)) - 25, y = 12 + i * 12 + h(n, 40 + i) % 6;
            int c = night ? 0xFFB8A8E8 : 0xFFFFFFFF;
            oval(g, x, y, 12, 4, c);
            Skin.disc(g, x - 5, y - 3, 5, c);
            Skin.disc(g, x + 3, y - 4, 6, c);
        }
        oval(g, 30, 90, 70, 26, night ? 0xFF1A1A3A : 0xFF7ACB8A);
        oval(g, 120, 94, 60, 28, night ? 0xFF14142E : 0xFF5FB874);
    }

    // ---------- 5: falling petals, snow, leaves, hearts ----------
    private static void petals(GuiGraphics g, int n, int tm, boolean thumb) {
        int v = h(n, 20) % 5;
        int[][] pal = {{0xFFFFC8DC, 0xFFFFF0F4}, {0xFF14183A, 0xFF4A2A5A}, {0xFFB8D8F8, 0xFFF4FAFF}, {0xFFE8A858, 0xFFFFE8B8}, {0xFFC8A8F0, 0xFFFFD8F0}};
        int[] pc = {0xFFFFFFFF, 0xFFFFB8D0, 0xFFFFFFFF, 0xFFE06A28, 0xFFFF6A9A};
        pc[0] = 0xFFFF9EC0;
        bands(g, pal[v][0], pal[v][1], thumb ? 14 : 8);
        if (v <= 1) {                                                                       // a blossoming branch
            Skin.rect(g, 0, 6, 46, 3, 0xFF4A3028);
            Skin.rect(g, 30, 8, 3, 14, 0xFF4A3028);
            for (int i = 0; i < 9; i++) Skin.disc(g, 4 + i * 5, 5 + (i % 3) * 3, 3, v == 0 ? 0xFFFF9EC0 : 0xFFD870B0);
        }
        int cnt = thumb ? 10 : 36;
        for (int i = 0; i < cnt; i++) {
            int x = (int) ((h(n, 100 + i) % PW + Math.sin(tm / 30.0 + i) * 6 + tm * 0.2F) % PW);
            int y = (int) ((tm * (0.5F + (i % 4) * 0.2F) + h(n, 200 + i) % PH) % (PH + 6)) - 3;
            if (v == 4 && i % 2 == 0) heart(g, x, y, 1, pc[4]);
            else if (v == 1 && i % 3 == 0) Skin.rect(g, x, y, 1, 1, 0xFFFFE8A0);
            else Skin.rect(g, x, y, 2, 2, v == 3 && i % 2 == 0 ? 0xFFC04818 : pc[v]);
        }
        oval(g, 40, 92, 90, 24, v == 2 ? 0xFFFFFFFF : v == 3 ? 0xFFB87838 : v == 1 ? 0xFF1A1030 : 0xFFFFE4EC);
        oval(g, 120, 94, 60, 22, v == 2 ? 0xFFE8F2FF : v == 3 ? 0xFFA06A30 : v == 1 ? 0xFF241440 : 0xFFFFD4E0);
    }
}
