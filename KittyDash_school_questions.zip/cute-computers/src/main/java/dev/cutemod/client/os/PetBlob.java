package dev.cutemod.client.os;

/**
 * Reads the saved text of a pet (the blob "pet_&lt;color&gt;", written by PetApp.save) without opening the pet window,
 * so other apps can see how old it is, what character it has and whether it is sick.
 * Format: food fun energy sleeping age saved-at [feed play sleep pet [sick neglect]] (old saves are shorter).
 */
public final class PetBlob {
    private PetBlob() {}

    public record Info(long ageSec, int feed, int play, int sleep, int pet, boolean sick) {
        public int stage() { return PetArt.stageOf(ageSec); }
        public int trait() { return PetArt.traitOf(feed, play, sleep, pet); }
        public int ageMin() { return (int) Math.min(10_000_000L, ageSec / 60); }
    }

    /** The pet described by this text, or null if there is none (or the text is broken). */
    public static Info parse(String s) {
        if (s == null) return null;
        try {
            String[] a = s.trim().split("\\s+");
            if (a.length < 6) return null;
            long age = Math.max(0, Long.parseLong(a[4]));
            int feed = 0, play = 0, sleep = 0, pet = 0;
            if (a.length >= 10) {
                feed = Integer.parseInt(a[6]);
                play = Integer.parseInt(a[7]);
                sleep = Integer.parseInt(a[8]);
                pet = Integer.parseInt(a[9]);
            }
            boolean sick = a.length >= 12 && a[10].equals("1");
            return new Info(age, Math.max(0, feed), Math.max(0, play), Math.max(0, sleep), Math.max(0, pet), sick);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * Gives the saved pet some food (the free lunch of the school canteen) without opening the pet window.
     * Returns 1 if it ate, 0 if it is already at or above cap (nothing changes), -1 if there is no pet.
     */
    public static int feed(String speciesId, double add, double cap) {
        String key = "pet_" + speciesId;
        String s = Store.read(key);
        if (s == null) return -1;
        try {
            String[] a = s.trim().split("\\s+");
            if (a.length < 6) return -1;
            double food = Double.parseDouble(a[0]);
            if (food >= cap) return 0;
            a[0] = String.format(java.util.Locale.ROOT, "%.2f", Math.min(cap, food + add));
            Store.write(key, String.join(" ", a));
            return 1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /**
     * Cures a sick pet (no medicine is used up): sick and neglect are set to 0 and its fun is raised to at least 40, like the medicine of the pet app.
     * Returns 1 if it was cured, 0 if it was not sick, -1 if there is no pet.
     */
    public static int cure(String speciesId) {
        String key = "pet_" + speciesId;
        String s = Store.read(key);
        if (s == null) return -1;
        try {
            String[] a = s.trim().split("\\s+");
            if (a.length < 6) return -1;
            if (a.length < 12 || !a[10].equals("1")) return 0;
            a[10] = "0";
            a[11] = "0";
            a[1] = String.format(java.util.Locale.ROOT, "%.2f", Math.max(Double.parseDouble(a[1]), 40.0));
            Store.write(key, String.join(" ", a));
            return 1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
