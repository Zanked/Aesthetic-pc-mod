package dev.cutemod.client.player;

import net.minecraft.client.Minecraft;

/** What the item calls on the client (kept apart so the server never loads client classes). */
public final class PlayerHooks {
    private PlayerHooks() {}

    public static void open() { Minecraft.getInstance().setScreen(new PlayerScreen()); }

    public static void toggle() { PlayerEngine.toggle(); }
}
