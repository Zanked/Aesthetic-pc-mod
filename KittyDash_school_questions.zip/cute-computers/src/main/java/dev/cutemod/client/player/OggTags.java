package dev.cutemod.client.player;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;

/**
 * Reads the tags of an .ogg file (Vorbis comments of Vorbis, Opus and FLAC-in-Ogg): title, artist, album artist,
 * album, track and disc number. This is what sorts a pile of songs into albums without any folders.
 */
public final class OggTags {
    private OggTags() {}

    /** Empty strings and 0 where a file has no such tag. */
    public record Tags(String title, String artist, String albumArtist, String album, int track, int disc) {}

    public static final Tags NONE = new Tags("", "", "", "", 0, 0);

    /** The tags of the file, or NONE if it has none. Never throws. */
    public static Tags read(byte[] ogg) {
        try {
            for (byte[] p : OggCover.firstPackets(ogg, 8)) {
                int off = OggCover.commentOffset(p);
                if (off < 0) continue;
                Tags t = fromComments(p, off);
                if (t != null) return t;
            }
        } catch (Throwable ignored) { /* a file with broken tags is a file without tags */ }
        return NONE;
    }

    private static Tags fromComments(byte[] p, int off) {
        long vendor = OggCover.le32(p, off);
        long pos = off + 4 + vendor;
        if (vendor < 0 || pos + 4 > p.length) return null;
        long n = OggCover.le32(p, (int) pos);
        pos += 4;
        String title = "", artist = "", albumArtist = "", album = "";
        int track = 0, disc = 0;
        for (long i = 0; i < n && pos + 4 <= p.length; i++) {
            long len = OggCover.le32(p, (int) pos);
            pos += 4;
            if (len < 0 || pos + len > p.length) break;
            String c = new String(p, (int) pos, (int) len, StandardCharsets.UTF_8);
            pos += len;
            int eq = c.indexOf('=');
            if (eq <= 0) continue;
            String key = c.substring(0, eq).toUpperCase(Locale.ROOT).replace(" ", "");
            String val = c.substring(eq + 1).trim();
            if (val.isEmpty()) continue;
            switch (key) {
                case "TITLE" -> { if (title.isEmpty()) title = val; }
                case "ARTIST" -> { if (artist.isEmpty()) artist = val; }
                case "ALBUMARTIST" -> { if (albumArtist.isEmpty()) albumArtist = val; }
                case "ALBUM" -> { if (album.isEmpty()) album = val; }
                case "TRACKNUMBER", "TRACK" -> { if (track == 0) track = number(val); }
                case "DISCNUMBER", "DISC" -> { if (disc == 0) disc = number(val); }
                default -> { }
            }
        }
        return new Tags(title, artist, albumArtist, album, track, disc);
    }

    /** "3", "03" and "3/12" are all 3; anything else is 0. */
    private static int number(String v) {
        int i = 0;
        while (i < v.length() && Character.isDigit(v.charAt(i)) && i < 6) i++;
        if (i == 0) return 0;
        try { return Integer.parseInt(v.substring(0, i)); } catch (NumberFormatException e) { return 0; }
    }
}
