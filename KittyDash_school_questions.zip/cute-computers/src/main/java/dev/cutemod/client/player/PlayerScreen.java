package dev.cutemod.client.player;

import dev.cutemod.ComputerColor;
import dev.cutemod.client.os.App;
import dev.cutemod.client.os.MusicApp;
import dev.cutemod.client.os.Shell;
import dev.cutemod.client.os.Skin;
import dev.cutemod.client.os.Theme;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * The window of the portable player. It is the very same Music app that runs on the computer ({@link MusicApp}), with the same
 * pages, search, covers, player bar and the look of the desktop theme that is on (Aero, Kawaii, Retro 98, Anime), but it shows only
 * the albums that were put on the player. The music itself is in {@link PlayerEngine}, so closing this window does not stop it.
 */
public class PlayerScreen extends Screen implements Shell {
    private final MusicApp app = new MusicApp().portable();
    private int px, py;
    private int ticks3;

    public PlayerScreen() {
        super(Component.translatable("cutemod.player.title"));
        app.attach(this);
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void tick() {
        for (int i = 0; i < 3; i++) app.tick();          // the app counts in 60ths of a second, the screen in 20ths
    }

    private void layout() {
        px = (width - App.W) / 2;
        py = (height - App.H) / 2;
    }

    // ---------- Shell: the little the Music app asks of its computer (nothing here) ----------
    @Override public void open(App a) {}
    @Override public void home() { onClose(); }
    @Override public BlockPos pos() { return BlockPos.ZERO; }
    @Override public ComputerColor color() { return ComputerColor.values()[0]; }
    @Override public void openLink(String url) {}
    @Override public void submitScore(ComputerColor game, int score) {}
    @Override public int absX() { return px; }
    @Override public int absY() { return py; }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        layout();
        g.fill(0, 0, width, height, 0x88000000);
        if (Theme.retro()) Theme.bevel(g, px - 3, py - 3, App.W + 6, App.H + 6, true, 0xFFC0C0C0);      // a grey frame with raised edges
        else Theme.rrect(g, px - 3, py - 3, App.W + 6, App.H + 6, 9, Theme.pal().rim());              // a soft rim in the colour of the look
        g.pose().pushPose();
        g.pose().translate(px, py, 0);
        Skin.appsKeepColours(true);                      // the app has its own colours: dark mode must not repaint them
        try {
            app.mouse(mx - px, my - py);
            app.render(g, mx - px, my - py);
        } finally {
            Skin.appsKeepColours(false);
            Skin.appTheme(false);
            g.pose().popPose();
        }
    }

    // ---------- input ----------
    private boolean inside(double mx, double my) { return mx >= px && my >= py && mx < px + App.W && my < py + App.H; }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        layout();
        if (inside(mx, my)) { app.click((int) Math.floor(mx) - px, (int) Math.floor(my) - py, button); return true; }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (app.drag((int) Math.floor(mx) - px, (int) Math.floor(my) - py, button)) return true;
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        boolean was = app.release((int) Math.floor(mx) - px, (int) Math.floor(my) - py, button);
        return was || super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        app.mouse((int) Math.floor(mx) - px, (int) Math.floor(my) - py);
        return app.scroll(sy) || super.mouseScrolled(mx, my, sx, sy);
    }

    @Override
    public boolean charTyped(char c, int mods) {
        return app.charTyped(c) || super.charTyped(c, mods);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_F && (mods & GLFW.GLFW_MOD_CONTROL) != 0) return app.key(47, 0);      // Ctrl+F = the search, like "/"
        if (app.key(key, mods)) return true;
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void removed() {
        app.close();                                     // the portable app leaves the music playing
        super.removed();
    }
}
