package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * Everything the player earns on the computers, shared by all of them (it is saved on this PC in
 * cutemod_progress.txt): coins, shop purchases, achievements, daily tasks and the story quest.
 * Apps report what happens with the on...() methods, the rest is decided here.
 */
public final class Progress {
    private Progress() {}

    public record Ach(String id, String counter, int target, int reward) {}

    public record Daily(String counter, int target, int reward) {}

    public static final Ach[] ACHS = {
            new Ach("first_game", "games", 1, 5),
            new Ach("games10", "games", 10, 20),
            new Ach("score100", "bestcoins", 15, 15),
            new Ach("feed10", "feed", 10, 15),
            new Ach("pet20", "pet", 20, 10),
            new Ach("scary_all", "scary_read", 4, 15),
            new Ach("popups10", "popups", 10, 10),
            new Ach("hacker", "cmds", 8, 20),
            new Ach("rich", "earned", 200, 25),
            new Ach("shopper", "bought", 3, 15),
            new Ach("treats5", "treats_used", 5, 10),
            new Ach("quest", "quest_done", 1, 50),
            new Ach("wiki_all", "wiki_read", 8, 15),
            new Ach("quest2", "quest2_done", 1, 75),
            new Ach("candy50", "candy_all", 50, 25),
            new Ach("behind", "q3_done", 1, 60),
            new Ach("hell_watch", "hell_watch", 1, 30),     // the video 666, to the end
            new Ach("hell_66", "hell_66", 1, 66),            // the secret: paused at the 66th second
            new Ach("hell_survive", "hell_survive", 1, 40),  // stayed at the computer for the whole two minutes of the crimson look
    };

    public static final Daily[] DAILY = {
            new Daily("games", 2, 10),
            new Daily("feed", 1, 5),
            new Daily("pet", 3, 5),
    };

    /** Coins for finishing each chapter of the story. */
    public static final int[] QUEST_REWARD = {10, 10, 15, 20, 20, 25, 100,   // part 1: Strange Stories
                                              15, 20, 20, 25, 25, 150};      // part 2: The Quiet One
    /** The first part of the story ends here (the crown is given); part 2 goes on to QUEST_STEPS. */
    public static final int PART1 = 7;
    public static final int QUEST_STEPS = QUEST_REWARD.length;

    /**
     * A "good" result in each game; it is worth about 10 coins. Games count points very differently
     * (a Flappy Cat run is ~10 points, Merge Cubes is ~1000), so the coins are scaled per game.
     */
    private static final Map<String, Integer> PAR = Map.ofEntries(
            Map.entry("pink", 10),      // Flappy Cat: pipes
            Map.entry("green", 300),    // Minesweeper: a win gives up to 500
            Map.entry("white", 12),     // Panda Snake: food
            Map.entry("blue", 15),      // Penguin Fishing: fish
            Map.entry("orange", 50),    // Fox Memory: 200 - 8 per move
            Map.entry("purple", 30),    // Ender Dodge: seconds survived
            Map.entry("yellow", 20),    // Whack-a-Bee: hits
            Map.entry("red", 700),      // Ladybug Match
            Map.entry("breakout", 200), // Cookie Breaker
            Map.entry("cubes", 1000),   // Merge Cubes
            Map.entry("pong", 40),      // Slime Pong
            Map.entry("bees", 300),     // Bee Invaders
            Map.entry("horror", 100),   // Something in the Dark: candles x 10
            Map.entry("maze", 1000),    // Dark Corridor: a win is 1000 or more (5 keys x 100 + the exit)
            Map.entry("otherworld", 800), // Otherworld: 100 per seal, a win is 800 or more
            Map.entry("craft", 300),    // MiniCraft: blocks mined + zombies, a win (3 diamonds) adds 300
            Map.entry("zombies", 600),  // Zombie Shooter: 10 per hit, 60 per kill, 100 per round
            Map.entry("durak", 100),    // Durak: a win is 100, a draw 40
            Map.entry("sakura", 60),    // Sakura Catch: petals x combo, onigiri 5
            Map.entry("blocks", 250),   // Cute Blocks: lines x level, drops
            Map.entry("cakes", 120),    // Cake Bakery: money earned in a day (10 + tip + bonus per cake)
            Map.entry("cakefactory", 180),  // Cake Factory: 10 + streak bonus + speed bonus per right cake
            Map.entry("racer", 300),        // Cute Racer: distance / 14 + 5 per coin
            Map.entry("checkers", 100),     // Checkers: a win is 50 / 75 / 100 (easy / normal / hard), a draw 10 / 25 / 40
            Map.entry("slice", 60),         // Melon Slice: 3 per melon, 2 pumpkin / apple, 1 berries, 10 golden melon, combos
            Map.entry("rabbit", 40),        // Rabbit Road: rows hopped + 3 per carrot
            Map.entry("dash", 250),         // Kitty Dash: distance / 30 + 2 per coin
            Map.entry("echo", 10),          // Echo Pads: rounds repeated
            Map.entry("lights", 80),        // Lights Out: 120 - 4 per move
            Map.entry("targets", 45),       // Target Pop: 1 to 3 per target in 30 seconds
            Map.entry("rps", 6),            // Rock Paper Scissors: wins in a row
            Map.entry("guess", 50),         // Number Hunt: 20 + 10 per try left
            Map.entry("tower", 40),         // Block Tower: 1 per block, 2 per perfect drop
            Map.entry("hangman", 55),       // Hangman: 20 + 8 per life left + word length
            Map.entry("billiards", 100));   // Billiards: solo 10 per ball, combos, 30 + 5 per shot left for clearing the table; a win against the bot is 50 / 75 / 100, a draw 10 / 25 / 40; online a win is 60, a draw 20

    /** The most coins that games can give in one day (quests, achievements and tasks are not limited). */
    public static final int GAME_COIN_CAP = 150;

    /** Coins for a finished game: a par score gives 10 coins, at most 25 per game. */
    public static int coinsFor(String id, int score) {
        int par = PAR.getOrDefault(id, 100);
        return Math.max(0, Math.min(25, (int) Math.round(10.0 * score / par)));
    }

    private static boolean loaded, dirty;
    private static int coins, step, streak, saveDelay;
    private static long lastDay;
    /** What the pet wears: one id (or "") for every layer, indexed by {@link dev.cutemod.data.PetWear.Slot#ordinal()}. */
    private static final String[] layer = new String[dev.cutemod.data.PetWear.Slot.values().length];
    private static String packedUpper = "", packedLower = "";   // the same, packed for the drawing and the network
    static { java.util.Arrays.fill(layer, ""); }
    private static final Map<String, Integer> counters = new HashMap<>();
    private static final Map<String, Integer> daily = new HashMap<>();
    private static final Set<String> owned = new LinkedHashSet<>();
    private static final Set<String> ach = new HashSet<>();

    private static final List<String> toasts = new ArrayList<>();
    private static String shown = "";
    private static int toastTimer;

    // ---------- save / load ----------
    private static int geti(Properties p, String k, int d) {
        try { return Integer.parseInt(p.getProperty(k, Integer.toString(d)).trim()); } catch (Exception e) { return d; }
    }

    private static void fill(Set<String> set, String csv) {
        if (csv == null || csv.isBlank()) return;
        for (String s : csv.split(",")) if (!s.isBlank()) set.add(s.trim());
    }

    private static int gen = -1;

    private static void ensure() {
        if (loaded && gen == Store.gen()) return;
        loaded = true;
        gen = Store.gen();
        coins = 0; step = 0; streak = 0; lastDay = 0; java.util.Arrays.fill(layer, ""); dirty = false;
        counters.clear(); daily.clear(); owned.clear(); ach.clear();
        try {
            Properties pr = Store.readProps("progress");
            if (pr != null) {
                coins = geti(pr, "coins", 0);
                step = Math.max(0, Math.min(QUEST_STEPS, geti(pr, "step", 0)));
                streak = geti(pr, "streak", 0);
                lastDay = geti(pr, "lastday", 0);
                // old saves had two slots (equipped = head or face, equipped2 = neck or body): every id goes to its own layer
                putOn(pr.getProperty("equipped", ""));
                putOn(pr.getProperty("equipped2", ""));
                for (dev.cutemod.data.PetWear.Slot s : dev.cutemod.data.PetWear.Slot.values())
                    putOn(pr.getProperty("eq." + s.name().toLowerCase(), ""));
                fill(owned, pr.getProperty("own"));
                fill(ach, pr.getProperty("ach"));
                for (String k : pr.stringPropertyNames()) {
                    if (k.startsWith("c.")) counters.put(k.substring(2), geti(pr, k, 0));
                    else if (k.startsWith("d.")) daily.put(k.substring(2), geti(pr, k, 0));
                }
            }
        } catch (Exception ignored) {
        }
        repack();
        newDay();
    }

    /** Saved on the server (through {@link Store}). */
    public static void save() {
        if (!loaded || gen != Store.gen()) return;
        try {
            Properties pr = new Properties();
            pr.setProperty("coins", Integer.toString(coins));
            pr.setProperty("step", Integer.toString(step));
            pr.setProperty("streak", Integer.toString(streak));
            pr.setProperty("lastday", Long.toString(lastDay));
            for (dev.cutemod.data.PetWear.Slot s : dev.cutemod.data.PetWear.Slot.values())
                pr.setProperty("eq." + s.name().toLowerCase(), layer[s.ordinal()]);
            pr.setProperty("equipped", layer[dev.cutemod.data.PetWear.Slot.HEAD.ordinal()]);   // the two old keys stay, for an older version
            pr.setProperty("equipped2", layer[dev.cutemod.data.PetWear.Slot.BODY.ordinal()]);
            pr.setProperty("own", String.join(",", owned));
            pr.setProperty("ach", String.join(",", ach));
            counters.forEach((k, v) -> pr.setProperty("c." + k, Integer.toString(v)));
            daily.forEach((k, v) -> pr.setProperty("d." + k, Integer.toString(v)));
            Store.writeProps("progress", pr);
            dirty = false;
        } catch (Exception ignored) {
        }
    }

    /** First visit of a new day: reset daily tasks and give the login bonus (it grows with the streak). */
    private static void newDay() {
        long today = System.currentTimeMillis() / 86_400_000L;
        if (lastDay == today) return;
        streak = (lastDay == today - 1) ? streak + 1 : 1;
        lastDay = today;
        daily.clear();
        int bonus = Math.min(streak, 7) * 3;
        addCoins(bonus);
        toast("cutemod.toast.daily_bonus", bonus, streak);
        Season.add(10);
        dirty = true;
    }

    // ---------- coins ----------
    public static int coins() { ensure(); return coins; }

    private static void addCoins(int n) {
        coins += n;
        counters.merge("earned", n, Integer::sum);
        dirty = true;
    }

    /** Give coins and show a pop-up. */
    public static void earn(int n) {
        ensure();
        if (n <= 0) return;
        addCoins(n);
        toast("cutemod.toast.coins", n);
        checkAch();
    }

    /** Like {@link #earn}, but the pop-up has no sound (the caller plays its own, like the end of a CuteJobs shift). */
    public static void earnQuiet(int n) {
        quiet = true;
        try { earn(n); } finally { quiet = false; }
    }

    private static boolean quiet;

    // ---------- counters, achievements, daily tasks ----------
    public static int count(String key) { ensure(); return counters.getOrDefault(key, 0); }

    public static void setCount(String key, int v) { ensure(); counters.put(key, v); dirty = true; }

    public static int dailyCount(String key) { ensure(); return daily.getOrDefault(key, 0); }

    /** Coins earned from games today (for the diary). */
    public static int gameCoinsToday() { ensure(); return daily.getOrDefault("game_coins", 0); }

    public static boolean dailyDone(String key) { ensure(); return daily.containsKey("done_" + key); }

    public static int streak() { ensure(); return streak; }

    public static boolean hasAch(String id) { ensure(); return ach.contains(id); }

    public static void bump(String key) {
        ensure();
        counters.merge(key, 1, Integer::sum);
        daily.merge(key, 1, Integer::sum);
        dirty = true;
        checkAch();
        checkDaily();
        Season.onBump(key);
    }

    private static void setMax(String key, int v) {
        if (v > counters.getOrDefault(key, 0)) { counters.put(key, v); dirty = true; checkAch(); }
    }

    private static void checkAch() {
        for (Ach a : ACHS) {
            if (!ach.contains(a.id()) && counters.getOrDefault(a.counter(), 0) >= a.target()) {
                ach.add(a.id());
                addCoins(a.reward());
                toast("cutemod.toast.ach", Component.translatable("cutemod.ach." + a.id()).getString(), a.reward());
                Season.add(40);
                dirty = true;
            }
        }
        // outfits that are won by playing with the pet (see PetWear)
        for (dev.cutemod.data.PetWear.Item w : dev.cutemod.data.PetWear.ALL) {
            if (w.src() == dev.cutemod.data.PetWear.Src.COUNT && !owned.contains(w.id()) && counters.getOrDefault(w.key(), 0) >= w.at()) {
                owned.add(w.id());
                toast("cutemod.toast.newwear", Component.translatable("cutemod.shop.item." + w.id()).getString());
                dirty = true;
            }
        }
    }

    private static void checkDaily() {
        for (Daily d : DAILY) {
            String done = "done_" + d.counter();
            if (!daily.containsKey(done) && daily.getOrDefault(d.counter(), 0) >= d.target()) {
                daily.put(done, 1);
                addCoins(d.reward());
                toast("cutemod.toast.task", Component.translatable("cutemod.task." + d.counter()).getString(), d.reward());
                Season.add(20);
                dirty = true;
            }
        }
    }

    /** An operator set or changed the coins (/cutecoins). Not counted as earned. */
    public static void admin(boolean set, int amount) {
        ensure();
        long v = set ? amount : (long) coins + amount;
        int old = coins;
        coins = (int) Math.max(0, Math.min(dev.cutemod.net.CoinsCommand.MAX, v));
        dirty = true;
        save();
        int diff = coins - old;
        toast("cutemod.toast.admin_coins", (diff >= 0 ? "+" : "") + diff);
    }

    /** Gives coins back (a refused order). Not counted as earned. */
    public static void refund(int n) {
        ensure();
        if (n <= 0) return;
        coins += n;
        dirty = true;
        save();
    }

    /** Takes coins for something bought in CuteStore. */
    public static boolean spend(int price) {
        ensure();
        if (price < 0 || coins < price) return false;
        coins -= price;
        dirty = true;
        bump("bought");
        save();
        return true;
    }

    // ---------- shop ----------
    public static boolean owned(String id) { ensure(); return owned.contains(id); }

    public static boolean buy(String id, int price) {
        ensure();
        if (owned.contains(id) || coins < price) return false;
        coins -= price;
        owned.add(id);
        dirty = true;
        bump("bought");
        toast("cutemod.toast.bought", Component.translatable("cutemod.shop.item." + id).getString());
        save();
        return true;
    }

    /** Turns a plain yes/no mark on or off (it is saved with the other things you own). */
    public static void setFlag(String id, boolean on) {
        ensure();
        if (on ? owned.add(id) : owned.remove(id)) { dirty = true; save(); }
    }

    /** Buys something that is not in the lang file by id (an album of the Music app): the toast shows the given name. */
    public static boolean buyNamed(String id, int price, String name) {
        ensure();
        if (owned.contains(id) || coins < price) return false;
        coins -= price;
        owned.add(id);
        dirty = true;
        bump("bought");
        toast("cutemod.toast.bought", name);
        save();
        return true;
    }

    // ---------- treats (things that are used up) ----------
    public static int stock(String id) { ensure(); return counters.getOrDefault("stock_" + id, 0); }

    public static boolean buyTreat(String id, int price) {
        ensure();
        if (coins < price) return false;
        coins -= price;
        counters.merge("stock_" + id, 1, Integer::sum);
        dirty = true;
        toast("cutemod.toast.bought", Component.translatable("cutemod.shop.item." + id).getString());
        save();
        return true;
    }

    /** A reward: puts treats into the stock (the season pass). */
    public static void giveTreat(String id, int n) {
        ensure();
        if (n <= 0) return;
        counters.merge("stock_" + id, n, Integer::sum);
        dirty = true;
        toast("cutemod.toast.bought", Component.translatable("cutemod.shop.item." + id).getString());
    }

    /** A reward: an outfit for the pet that the player did not have to buy (the season pass). */
    public static void grantWear(String id) {
        ensure();
        if (id == null || owned.contains(id)) return;
        owned.add(id);
        dirty = true;
        toast("cutemod.toast.newwear", Component.translatable("cutemod.shop.item." + id).getString());
    }

    /** Takes one treat from the stock. Returns false if there is none. */
    public static boolean useTreat(String id) {
        ensure();
        int n = counters.getOrDefault("stock_" + id, 0);
        if (n <= 0) return false;
        counters.put("stock_" + id, n - 1);
        dirty = true;
        return true;
    }

    /** What the pet wears on the head and the face, packed ("acc_crown+acc_glasses", see PetWear.layers). */
    public static String equipped() { ensure(); return packedUpper; }

    /** What the pet wears on the body, over it and around the neck, packed like {@link #equipped()}. */
    public static String equippedBody() { ensure(); return packedLower; }

    /** The thing worn on one layer ("" if nothing). */
    public static String worn(dev.cutemod.data.PetWear.Slot s) { ensure(); return layer[s.ordinal()]; }

    public static boolean wearing(String id) {
        ensure();
        if (id.isEmpty()) return false;
        for (String w : layer) if (w.equals(id)) return true;
        return false;
    }

    /** Puts the item on, on its own layer (the thing that was there goes off). An empty id clears the head layer. */
    public static void equip(String id) {
        ensure();
        layer[id.isEmpty() ? dev.cutemod.data.PetWear.Slot.HEAD.ordinal() : dev.cutemod.data.PetWear.slotOf(id).ordinal()] = id;
        repack();
        dirty = true;
        save();
    }

    /** Takes this one item off (the other layers stay as they are). */
    public static void unequip(String id) {
        ensure();
        for (int i = 0; i < layer.length; i++) if (layer[i].equals(id)) layer[i] = "";
        repack();
        dirty = true;
        save();
    }

    /** Takes everything off. */
    public static void undress() {
        ensure();
        java.util.Arrays.fill(layer, "");
        repack();
        dirty = true;
        save();
    }

    private static void putOn(String id) {
        if (id != null && !id.isEmpty() && dev.cutemod.data.PetWear.get(id) != null) layer[dev.cutemod.data.PetWear.slotOf(id).ordinal()] = id;
    }

    private static void repack() {
        packedUpper = dev.cutemod.data.PetWear.pack(layer, false);
        packedLower = dev.cutemod.data.PetWear.pack(layer, true);
    }

    // ---------- story quest ----------
    public static int step() { ensure(); return step; }

    public static boolean questDone() { ensure(); return step >= QUEST_STEPS; }

    /** A reward that is not for sale (the outfit of the talent show). True if it is new. */
    public static boolean grant(String id) {
        ensure();
        if (!owned.add(id)) return false;
        dirty = true;
        return true;
    }

    /** Finish chapter "from" if the player is on it. Returns true if the story moved on. */
    public static boolean advanceIf(int from) {
        ensure();
        if (step != from) return false;
        addCoins(QUEST_REWARD[from]);
        step++;
        dirty = true;
        if (step == PART1) { // end of part 1
            owned.add("acc_crown");
            counters.put("quest_done", 1);
            toast("cutemod.toast.finale");
            checkAch();
        } else if (step >= QUEST_STEPS) { // end of part 2
            owned.add("acc_ghost");
            counters.put("quest2_done", 1);
            toast("cutemod.toast.finale2");
            checkAch();
        } else {
            toast("cutemod.toast.chapter", Component.translatable("cutemod.quest." + from + ".title").getString(), QUEST_REWARD[from]);
        }
        save();
        return true;
    }

    // ---------- events reported by the apps ----------
    public static void onPage(String id) {
        ensure();
        if (id.matches("scary[1-4]") && count("v_" + id) == 0) {
            counters.put("v_" + id, 1);
            bump("scary_read");
        }
        if (step == 0 && count("scary_read") >= 4) advanceIf(0);
        if (id.matches("wiki[1-8]") && count("v_" + id) == 0) { // every Pandapedia article, once
            counters.put("v_" + id, 1);
            bump("wiki_read");
        }
        if (step == 7 && id.equals("wiki9")) advanceIf(7);
    }

    /** A letter was opened in the Mail app. */
    public static void onMail(String id) {
        ensure();
        if (step == 1 && id.equals("strange")) advanceIf(1);
    }

    public static void onGame(String id, int score, boolean won) {
        ensure();
        bump("games");
        int c = Math.round(coinsFor(id, score));
        setMax("bestcoins", c);
        int left = Math.max(0, GAME_COIN_CAP - daily.getOrDefault("game_coins", 0));
        if (c > left) {
            c = left;
            if (!daily.containsKey("cap_shown")) { // tell the player once a day
                daily.put("cap_shown", 1);
                toast("cutemod.toast.cap");
            }
        }
        if (c > 0) {
            daily.merge("game_coins", c, Integer::sum);
            earn(c);
        }
        if (step == 4 && id.equals("horror") && score >= 30) advanceIf(4);
        if (step == 6 && id.equals("maze") && won) advanceIf(6);
    }

    public static void onPet(String action) {
        ensure();
        bump(action);
        if (!action.equals("pet")) addCoins(1);
        if (step == 5 && !action.equals("pet")) {
            bump("q_" + action);
            if (count("q_feed") >= 3 && count("q_play") >= 2) advanceIf(5);
        }
    }

    public static void onVideoEnd(int video) {
        ensure();
        if (count("video" + video) == 0) {
            counters.put("video" + video, 1);
            addCoins(2);
            dirty = true;
        }
        if (step == 9) advanceIf(9); // part 2: any video watched to the end
    }

    /** Part 2: the picture in Paint has this many painted pixels now. */
    public static void onPaint(int pixels) {
        ensure();
        if (step != 10) return;
        setMax("q_paint", pixels);
        if (pixels >= 60) advanceIf(10);
    }

    /** Part 2: the note in Notes is this long now. */
    public static void onNote(int chars) {
        ensure();
        if (step != 11) return;
        setMax("q_note", chars);
        if (chars >= 40) advanceIf(11);
    }

    // ---------- part 3: "Behind You" (a separate track; it opens when part 2 is done) ----------
    /** Coins for each chapter of part 3: 0 Viewer, 1 Mirror, 2 Look Back, 3 Your Video, 4 Three Steps, 5 The One Behind You. */
    public static final int[] Q3_REWARD = {25, 30, 40, 35, 35, 60};
    public static final int Q3_STEPS = Q3_REWARD.length;

    /** The chapter of part 3 the player is on (Q3_STEPS = all written chapters are done). */
    public static int step3() { ensure(); return counters.getOrDefault("q3", 0); }

    /** Finish chapter "from" of part 3 if the player is on it (and part 2 is done). */
    public static boolean advance3(int from) {
        ensure();
        if (!questDone() || step3() != from || from >= Q3_STEPS) return false;
        addCoins(Q3_REWARD[from]);
        counters.put("q3", from + 1);
        dirty = true;
        if (from + 1 >= Q3_STEPS) {
            counters.put("q3_done", 1);
            toast("cutemod.toast.q3end");
            checkAch();
        } else {
            toast("cutemod.toast.chapter", Component.translatable("cutemod.q3." + from + ".title").getString(), Q3_REWARD[from]);
        }
        save();
        return true;
    }

    /** Part 3, chapter 2: the picture in Paint has this many painted pixels now. */
    public static void onPaint3(int pixels) {
        ensure();
        if (!questDone() || step3() != 1) return;
        setMax("q3_paint", pixels);
        if (pixels >= 40) advance3(1);
    }

    /** How part 2 ended: 1 = Me stays, 2 = Me flies away, 0 = not decided yet. */
    public static int ending() { ensure(); return counters.getOrDefault("ending", 0); }

    public static void setEnding(int e) { ensure(); counters.put("ending", e); dirty = true; }

    public static void onPopupClosed() { bump("popups"); }

    /** A terminal command was used for the first time. */
    public static void onCommand(String name) {
        ensure();
        if (count("cmd_" + name) == 0) {
            counters.put("cmd_" + name, 1);
            bump("cmds");
        }
    }

    // ---------- pop-up messages ----------
    public static void toast(String key, Object... args) {
        String s = Component.translatable(key, args).getString();
        remember(s, false);
        if (!Retro.dnd()) { toasts.add(s); if (!quiet) AppSfx.toast(key); }
    }

    // ---------- the notification centre: the last pop-ups, newest first ----------
    private static final List<String[]> history = new ArrayList<>();   // {time, text, mail?}
    private static int unread;

    private static void remember(String text, boolean mail) {
        history.add(0, new String[]{java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")), text, mail ? "1" : "0"});
        while (history.size() > 30) history.remove(history.size() - 1);
        unread = Math.min(99, unread + 1);
    }

    public static List<String[]> history() { return history; }

    public static int unread() { return unread; }

    public static void markRead() { unread = 0; }

    public static void clearHistory() { history.clear(); unread = 0; }

    /** A pop-up about a new letter (drawn with an envelope instead of a coin). */
    public static void mailToast(String key, Object... args) {
        String s = Component.translatable(key, args).getString();
        remember(s, true);
        if (!Retro.dnd()) { toasts.add("\u0001" + s); AppSfx.mail(); }
    }

    /** Called 60 times per second by the computer screen. */
    public static void tick() {
        Mail.tick();
        Trip.tick();
        if (toastTimer > 0) toastTimer--;
        else if (!toasts.isEmpty()) { shown = toasts.remove(0); toastTimer = 170; }
        if (dirty && ++saveDelay > 180) { saveDelay = 0; save(); }
    }

    public static void drawCoin(GuiGraphics g, int x, int y) {
        int c = 0xFFFFC832, d = 0xFFB98A10;
        g.fill(x + 2, y, x + 5, y + 1, c);
        g.fill(x + 1, y + 1, x + 6, y + 2, c);
        g.fill(x, y + 2, x + 7, y + 5, c);
        g.fill(x + 1, y + 5, x + 6, y + 6, c);
        g.fill(x + 2, y + 6, x + 5, y + 7, d);
        g.fill(x + 3, y + 2, x + 4, y + 5, d);
    }

    /** The little message that slides in at the top of the screen. */
    public static void renderToast(GuiGraphics g) {
        if (toastTimer <= 0 || shown.isEmpty()) return;
        Font f = Minecraft.getInstance().font;
        boolean mail = shown.charAt(0) == '\u0001';
        String text = mail ? shown.substring(1) : shown;
        int w = Math.min(App.W - 10, f.width(text) + 22), h = 16;
        int age = 170 - toastTimer;
        int slide = age < 12 ? (12 - age) * (h + 4) / 12 : toastTimer < 12 ? (12 - toastTimer) * (h + 4) / 12 : 0;
        int x = (App.W - w) / 2, y = 3 - slide;
        boolean hell = Hell.active();                                                    // the video 666: a black toast with a bloody edge
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, hell ? 0xFF8A0A14 : 0xFF3A2A4A);
        g.fill(x, y, x + w, y + h, hell ? 0xF2160204 : 0xF0FFF6D8);
        if (hell) g.fill(x + 3, y + h + 1, x + 4, y + h + 3 + (toastTimer / 6) % 3, 0xAA8A0A14);   // a drip
        if (mail) {
            g.fill(x + 5, y + 4, x + 12, y + 10, hell ? 0xFFC01828 : 0xFFB57BD6);
            g.fill(x + 6, y + 5, x + 11, y + 6, 0xFFFFFFFF);
            g.fill(x + 7, y + 6, x + 10, y + 7, 0xFFFFFFFF);
        } else {
            drawCoin(g, x + 5, y + 4);
        }
        Fit.str(g, f, text, x + 16, y + 4, hell ? Hell.PALE : 0xFF3A2A3A, false);
    }
}
