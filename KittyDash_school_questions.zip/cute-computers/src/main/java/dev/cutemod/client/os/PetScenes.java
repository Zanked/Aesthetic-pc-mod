package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.SchoolScenes.*;

/**
 * The room of the pet in the Tamagotchi app (the wall, the floor and the window). The colours follow the colour of the pet:
 * a pink pet has a rosy room, a blue one a blue room. The furniture, the pet, the bars and the buttons are drawn over it by
 * {@link PetApp}. The whole screen is 300 x 166; the floor starts at y = 110.
 */
final class PetScenes {
    private PetScenes() {}

    static final int FLOOR_TOP = 110;

    /** The room of a pet whose body colour is {@code body}; night = the pet sleeps (the window shows the night). */
    static void room(GuiGraphics g, int body, boolean night, int ticks) {
        int wall1 = mix(body, 0xFFFFFFFF, 0.80F), wall2 = mix(body, 0xFFFFFFFF, 0.62F);
        int dot = mix(body, 0xFFFFFFFF, 0.90F), deep = mix(body, 0xFF000000, 0.18F);
        int panel = mix(body, 0xFFFFFFFF, 0.48F), panelLight = mix(body, 0xFFFFFFFF, 0.72F), panelDark = mix(body, 0xFF000000, 0.12F);
        // the wall: a soft gradient with a pattern of little diamonds and a darker top
        g.fillGradient(0, 0, W, 92, wall1, wall2);
        for (int y = 8, r = 0; y < 90; y += 10, r++)
            for (int x = (r & 1) * 8; x < W; x += 16) { rect(g, x + 3, y, 2, 1, dot); rect(g, x + 2, y + 1, 4, 1, dot); rect(g, x + 3, y + 2, 2, 1, dot); }
        g.fillGradient(0, 0, W, 22, mix(body, 0xFF000000, 0.14F) & 0x00FFFFFF | 0x1C000000, 0x00000000);
        rect(g, 0, 0, W, 3, mix(body, 0xFFFFFFFF, 0.92F));                                // the crown moulding
        rect(g, 0, 3, W, 1, mix(body, 0xFF000000, 0.10F));
        // the wainscot: a rail, panels and a skirting
        rect(g, 0, 90, W, 1, panelDark);
        rect(g, 0, 91, W, 3, panelLight);
        rect(g, 0, 94, W, 1, panelDark);
        rect(g, 0, 95, W, 13, panel);
        for (int x = 5; x < W; x += 30) bevel(g, x, 97, 24, 9, panel, panelLight, panelDark);
        rect(g, 0, 108, W, 3, 0xFFFFF8EE);
        rect(g, 0, 108, W, 1, 0xFFFFFFFF);
        rect(g, 0, 110, W, 1, 0x55000000);
        // the floor: warm planks with staggered joints and a shine
        for (int r = 0, y = FLOOR_TOP + 1; y < H; r++, y += 9) {
            rect(g, 0, y, W, 9, (r & 1) == 0 ? 0xFFE0B887 : 0xFFD8AE7C);
            rect(g, 0, y, W, 1, 0x26FFFFFF);
            rect(g, 0, y + 8, W, 1, 0x2A7A4A1A);
            for (int x = (r * 41) % 60; x < W; x += 60) rect(g, x, y, 1, 9, 0x2A7A4A1A);
        }
        g.fillGradient(0, FLOOR_TOP + 1, W, FLOOR_TOP + 14, 0x40000000, 0x00000000);
        // a patch of light (or moonlight) from the window
        int light = night ? 0x168AB0FF : 0x18FFF0B0;
        for (int i = 0; i < 14; i++) rect(g, 20 + i * 2, FLOOR_TOP + 4 + i, 36 - i, 1, light);
        window(g, 14, 12, night, ticks, body);
    }

    private static void window(GuiGraphics g, int x, int y, boolean night, int ticks, int body) {
        int w = 46, h = 40;
        rect(g, x - 2, y - 1, w + 5, h + 5, 0x26000000);                                  // the shadow
        bevel(g, x, y, w, h, 0xFFB98450, 0xFFE8C08A, 0xFF6E4726);
        int gx = x + 3, gy = y + 3, gw = w - 6, gh = h - 6;
        if (night) {
            g.fillGradient(gx, gy, gx + gw, gy + gh, 0xFF141C46, 0xFF2C3E78);
            disc(g, x + 31, y + 12, 6, 0xFFFFF3B0);
            disc(g, x + 33, y + 10, 5, 0xFF1E2A5E);                                       // a crescent moon
            int[][] st = {{8, 6}, {16, 14}, {24, 8}, {10, 26}, {34, 22}, {20, 24}, {38, 6}};
            for (int i = 0; i < st.length; i++) if ((ticks / 18 + i) % 4 != 0) rect(g, x + 3 + st[i][0], y + 3 + st[i][1], 1, 1, 0xFFFFFFFF);
            rect(g, gx, gy + gh - 7, gw, 7, 0xFF1C3A4A);                                  // dark hills
            oval(g, gx + 10, gy + gh - 7, 14, 4, 0xFF1C3A4A);
        } else {
            g.fillGradient(gx, gy, gx + gw, gy + gh, 0xFF86D0FF, 0xFFDDF4FF);
            disc(g, x + 13, y + 12, 7, 0x40FFE066);
            disc(g, x + 13, y + 12, 5, 0xFFFFE066);
            disc(g, x + 11, y + 10, 1, 0x99FFFFFF);
            int cx = gx + 6 + (int) ((ticks * 0.04) % (gw - 12));                         // a cloud that drifts across
            disc(g, cx, y + 20, 3, 0xEEFFFFFF); disc(g, cx + 4, y + 21, 3, 0xEEFFFFFF); disc(g, cx - 4, y + 21, 2, 0xEEFFFFFF);
            rect(g, gx, gy + gh - 8, gw, 8, 0xFF8ADB82);                                  // hills
            rect(g, gx + 4, gy + gh - 10, 14, 2, 0xFF8ADB82); rect(g, gx + 28, gy + gh - 9, 12, 1, 0xFF6FC66A);
            rect(g, gx, gy + gh - 4, gw, 4, 0xFF6FC66A);
        }
        rect(g, x + w / 2 - 1, gy, 2, gh, 0xFFB98450); rect(g, gx, y + h / 2 - 1, gw, 2, 0xFFB98450);   // the crossbars
        rect(g, x + w / 2 - 1, gy, 1, gh, 0x66FFFFFF); rect(g, gx, y + h / 2 - 1, gw, 1, 0x66FFFFFF);
        if (!night) { line(g, gx + 3, gy + 8, gx + 9, gy + 2, 0x66FFFFFF); line(g, gx + 5, gy + 10, gx + 8, gy + 6, 0x44FFFFFF); }
        // curtains: a darker shade of the room, folds and a tie
        int cur = mix(body, 0xFFFFFFFF, 0.05F), curL = mix(body, 0xFFFFFFFF, 0.35F), curD = mix(body, 0xFF000000, 0.22F);
        for (int s = 0; s < 2; s++) {
            int cx = s == 0 ? x - 3 : x + w - 8;
            rect(g, cx, y - 2, 11, h + 3, cur);
            for (int k = 2; k < 11; k += 4) rect(g, cx + k, y - 2, 1, h + 3, curD);
            rect(g, cx + 1, y - 2, 1, h + 3, curL);
            rect(g, cx, y + h / 2 + 4, 11, 3, curD);
            rect(g, cx, y + h / 2 + 4, 11, 1, curL);
        }
        rect(g, x - 5, y - 4, w + 10, 3, 0xFF6E4726);                                     // the rod with two gold ends
        rect(g, x - 5, y - 4, w + 10, 1, 0xFFB98450);
        disc(g, x - 5, y - 3, 2, 0xFFFFD34E); disc(g, x + w + 5, y - 3, 2, 0xFFFFD34E);
        bevel(g, x - 3, y + h, w + 6, 4, 0xFFB98450, 0xFFE8C08A, 0xFF6E4726);             // the sill
        // a little pot on the sill
        rrect(g, x + w - 14, y + h - 5, 7, 5, 2, 0xFFE0705A);
        disc(g, x + w - 11, y + h - 8, 3, 0xFF4CAF50);
        rect(g, x + w - 11, y + h - 12, 1, 3, 0xFFFF8FB8);
    }
}
