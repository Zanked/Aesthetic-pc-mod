package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The rooms of the Pet School, drawn as pictures: the classroom, the hall (walls, floor, lockers, doors), the canteen, the
 * nurse's office and the school yard. Only the scenery is here: the pets, the texts, the buttons and the Halloween extras stay
 * in {@link SchoolApp}, which also owns every click area (nothing in here moves a door or a locker).
 *
 * The look: soft light from the left, every surface has a lit edge and a shaded edge, floors have a little shine,
 * walls have a trim, everything is cute and warm. Size: the whole app is 300 x 166 pixels, the title bar takes the top 15.
 */
final class SchoolScenes {
    private SchoolScenes() {}

    static final int W = 300, H = 166;
    static final int WOOD = 0xFF9A6A3C, WOOD_LIGHT = 0xFFC8955C, WOOD_DARK = 0xFF6E4726;

    // ---------- tiny drawing helpers (the same shapes as in App, so this class stands alone) ----------
    static void rect(GuiGraphics g, int x, int y, int w, int h, int argb) { g.fill(x, y, x + w, y + h, argb); }

    static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(1 - dy * dy / (double) (ry * ry + 1)));
            g.fill(cx - dx, cy + dy, cx + dx, cy + dy + 1, argb);
        }
    }

    static void rrect(GuiGraphics g, int x, int y, int w, int h, int r, int argb) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int dy = 0; dy < h; dy++) {
            double m = dy + 0.5, e = m < r ? r - m : m > h - r ? m - (h - r) : 0;
            int inset = e > 0 ? (int) Math.round(r - Math.sqrt(Math.max(0, r * r - e * e))) : 0;
            g.fill(x + inset, y + dy, x + w - inset, y + dy + 1, argb);
        }
    }

    static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        int n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= n; i++) rect(g, x0 + (x1 - x0) * i / Math.max(1, n), y0 + (y1 - y0) * i / Math.max(1, n), 1, 1, c);
    }

    /** A box with a lit top edge, a lit left edge and a shaded bottom and right edge. */
    static void bevel(GuiGraphics g, int x, int y, int w, int h, int fill, int light, int dark) {
        rect(g, x, y, w, h, fill);
        rect(g, x, y, w, 1, light);
        rect(g, x, y, 1, h, light);
        rect(g, x, y + h - 1, w, 1, dark);
        rect(g, x + w - 1, y, 1, h, dark);
    }

    /** Blends the colour a toward b (f = 0..1); the result is opaque. */
    static int mix(int a, int b, float f) {
        int r = Math.round((a >> 16 & 255) + ((b >> 16 & 255) - (a >> 16 & 255)) * f);
        int gr = Math.round((a >> 8 & 255) + ((b >> 8 & 255) - (a >> 8 & 255)) * f);
        int bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * f);
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }

    // =====================================================================================================
    //  THE CLASSROOM
    // =====================================================================================================
    static void classroom(GuiGraphics g, int ticks) {
        // the wall: warm cream with soft stripes, darker under the ceiling
        rect(g, 0, 15, W, 83, 0xFFFFF2DE);
        for (int x = 0; x < W; x += 16) rect(g, x, 15, 8, 83, 0xFFFFEBD2);
        g.fillGradient(0, 15, W, 40, 0x30C89860, 0x00C89860);
        g.fillGradient(0, 80, W, 98, 0x00C89860, 0x20C89860);
        // the ceiling edge with a crown moulding
        rect(g, 0, 15, W, 3, 0xFFFFF9EE);
        rect(g, 0, 18, W, 1, 0xFFE2BE8E);
        rect(g, 0, 19, W, 1, 0x30A06A3A);
        // the wainscot: a wooden rail, panels with a bevel and a skirting
        rect(g, 0, 97, W, 1, 0x40000000);
        rect(g, 0, 98, W, 3, 0xFFE8B880);
        rect(g, 0, 98, W, 1, 0xFFFFE2B8);
        rect(g, 0, 101, W, 1, 0xFFB98450);
        rect(g, 0, 102, W, 16, 0xFFD9A06A);
        for (int x = 4; x < W; x += 26) {
            bevel(g, x, 105, 22, 10, 0xFFE0AA74, 0xFFF2C894, 0xFFB98450);
        }
        rect(g, 0, 118, W, 4, 0xFFC8955C);
        rect(g, 0, 118, W, 1, 0xFFF2C894);
        rect(g, 0, 121, W, 1, 0x55000000);
        // the floor: planks with staggered joints, a bit of shine
        for (int r = 0, y = 122; y < H; r++, y += 9) {
            rect(g, 0, y, W, 9, (r & 1) == 0 ? 0xFFE3B67E : 0xFFDBAB72);
            rect(g, 0, y, W, 1, 0x22FFFFFF);
            rect(g, 0, y + 8, W, 1, 0x2A7A4A1A);
            for (int x = (r * 37) % 52; x < W; x += 52) rect(g, x, y, 1, 9, 0x2A7A4A1A);
        }
        g.fillGradient(0, 122, W, 134, 0x40000000, 0x00000000);                     // the wall casts a soft shadow on the floor
        // a patch of sun from the window
        for (int i = 0; i < 12; i++) {
            int x0 = 10 + i * 2, y0 = 124 + i;
            rect(g, x0, y0, 34 - i, 1, 0x16FFF4C0);
        }
        // the rug under the pupils: pink with a white border and a dotted line
        rrect(g, 6, 129, W - 12, H - 129, 8, 0xFFE58AB0);
        rrect(g, 8, 131, W - 16, H - 131, 7, 0xFFF4A7C3);
        rrect(g, 11, 134, W - 22, H - 134, 5, 0xFFFFD0E2);
        for (int x = 16; x < W - 16; x += 8) rect(g, x, 136, 4, 1, 0xFFF4A7C3);
        for (int x = 14; x < W - 14; x += 6) rect(g, x, 131, 2, 1, 0xFFFFE9F2);

        window(g, 3, 18);
        clock(g, 55, 29);
        plant(g, 29, 43);                                                           // on the sill
    }

    private static void window(GuiGraphics g, int x, int y) {
        rect(g, x - 1, y - 1, 40, 32, 0x30000000);                                    // the shadow under the frame
        bevel(g, x, y, 38, 29, WOOD_LIGHT, 0xFFE8C08A, WOOD_DARK);
        g.fillGradient(x + 3, y + 3, x + 35, y + 22, 0xFF8FD3FF, 0xFFD6F2FF);        // the sky
        disc(g, x + 11, y + 10, 3, 0xFFFFF0A0);
        disc(g, x + 11, y + 10, 4, 0x33FFF0A0);
        disc(g, x + 24, y + 8, 3, 0xEEFFFFFF); disc(g, x + 28, y + 9, 3, 0xEEFFFFFF); disc(g, x + 20, y + 9, 2, 0xEEFFFFFF);   // a cloud
        rect(g, x + 3, y + 20, 32, 5, 0xFF9AD98C);                                    // hills
        rect(g, x + 5, y + 19, 12, 1, 0xFF9AD98C); rect(g, x + 7, y + 18, 6, 1, 0xFF9AD98C);
        rect(g, x + 20, y + 21, 15, 4, 0xFF7BC773); rect(g, x + 23, y + 20, 8, 1, 0xFF7BC773);
        rect(g, x + 18, y + 3, 2, 22, WOOD_LIGHT); rect(g, x + 3, y + 13, 32, 2, WOOD_LIGHT);   // the crossbars
        rect(g, x + 18, y + 3, 1, 22, 0x44FFFFFF); rect(g, x + 3, y + 13, 32, 1, 0x44FFFFFF);
        line(g, x + 5, y + 9, x + 8, y + 5, 0x66FFFFFF);                                // a glint on the glass
        // curtains with folds and a tie
        for (int s = 0; s < 2; s++) {
            int cx = s == 0 ? x - 1 : x + 31;
            rect(g, cx, y - 1, 8, 28, 0xFFF4A7C3);
            for (int k = 1; k < 8; k += 3) rect(g, cx + k, y - 1, 1, 28, 0xFFE58AB0);
            rect(g, cx + 1, y - 1, 1, 28, 0x66FFFFFF);
            rect(g, cx, y + 14, 8, 2, 0xFFFFD34E);
        }
        rect(g, x - 3, y - 3, 44, 3, WOOD_DARK);                                      // the rod
        rect(g, x - 3, y - 3, 44, 1, WOOD);
        disc(g, x - 3, y - 2, 2, 0xFFFFD34E); disc(g, x + 41, y - 2, 2, 0xFFFFD34E);
        bevel(g, x - 2, y + 28, 42, 4, WOOD, 0xFFC8955C, WOOD_DARK);                  // the sill
    }

    private static void plant(GuiGraphics g, int x, int y) {
        rrect(g, x, y - 5, 7, 6, 2, 0xFFE0705A);
        rect(g, x, y - 5, 7, 1, 0xFFF08A74);
        disc(g, x + 3, y - 9, 3, 0xFF4CAF50);
        disc(g, x - 1, y - 7, 2, 0xFF6BC46A);
        disc(g, x + 7, y - 7, 2, 0xFF3F9E48);
        rect(g, x + 3, y - 14, 1, 3, 0xFFFF8FB8);
    }

    static void clock(GuiGraphics g, int cx, int cy) {
        disc(g, cx, cy + 1, 11, 0x30000000);
        disc(g, cx, cy, 11, WOOD_DARK);
        disc(g, cx, cy, 10, WOOD_LIGHT);
        disc(g, cx, cy, 8, 0xFFFFFBF0);
        for (int k = 0; k < 12; k++) {
            double a = k * Math.PI / 6;
            int r = k % 3 == 0 ? 6 : 7;
            rect(g, cx + (int) Math.round(Math.sin(a) * r), cy - (int) Math.round(Math.cos(a) * r), 1, 1, k % 3 == 0 ? 0xFF6E5A8A : 0xFFB0A0C8);
        }
        java.time.LocalTime now = java.time.LocalTime.now();
        double ma = now.getMinute() / 60.0 * Math.PI * 2, ha = (now.getHour() % 12 + now.getMinute() / 60.0) / 12 * Math.PI * 2;
        line(g, cx, cy, cx + (int) Math.round(Math.sin(ma) * 6), cy - (int) Math.round(Math.cos(ma) * 6), 0xFF3A2A3A);
        line(g, cx, cy, cx + (int) Math.round(Math.sin(ha) * 4), cy - (int) Math.round(Math.cos(ha) * 4), 0xFFE5486F);
        disc(g, cx, cy, 1, 0xFF3A2A3A);
        rect(g, cx - 5, cy - 8, 3, 1, 0x88FFFFFF);
    }

    // =====================================================================================================
    //  THE HALL
    // =====================================================================================================
    static void hall(GuiGraphics g, int ticks) {
        // the wall: light blue with a white panel line, a darker band at the bottom
        rect(g, 0, 15, W, 80, 0xFFEAF2FF);
        for (int x = 0; x < W; x += 16) rect(g, x, 15, 8, 80, 0xFFE3EDFC);
        g.fillGradient(0, 15, W, 36, 0x2860A0E0, 0x0060A0E0);
        rect(g, 0, 15, W, 3, 0xFFF8FBFF);
        rect(g, 0, 18, W, 1, 0xFFBBD2F0);
        rect(g, 0, 66, W, 2, 0xFFFFFFFF);                                             // a picture rail
        rect(g, 0, 68, W, 1, 0xFFB5CBEA);
        rect(g, 0, 69, W, 26, 0xFFC4D9F4);                                            // the lower wall
        for (int x = 3; x < W; x += 24) bevel(g, x, 73, 20, 18, 0xFFCADDF6, 0xFFE0ECFC, 0xFFA8C2E6);
        rect(g, 0, 95, W, 4, 0xFFFFF8EE);                                             // the skirting
        rect(g, 0, 95, W, 1, 0xFFFFFFFF);
        rect(g, 0, 98, W, 1, 0x55000000);
        // the ceiling lamps with a glow on the wall
        for (int x = 30; x < W; x += 80) {
            g.fillGradient(x - 22, 18, x + 22, 40, 0x22FFF4C0, 0x00FFF4C0);
            rect(g, x - 9, 15, 18, 3, 0xFFFFFFFF);
            rect(g, x - 9, 17, 18, 1, 0xFFFFE9A8);
        }
        // the floor: big glossy tiles, a runner in the middle
        for (int y = 99, r = 0; y < H; y += 17, r++) {
            for (int x = 0, c = 0; x < W; x += 20, c++) {
                boolean a = ((r + c) & 1) == 0;
                rect(g, x, y, 20, 17, a ? 0xFFF8EBD3 : 0xFFEBD7B4);
                rect(g, x, y, 20, 1, a ? 0xFFFFFFF0 : 0xFFF5E6C8);
                rect(g, x, y + 16, 20, 1, 0x182A1A0A);
                rect(g, x + 19, y, 1, 17, 0x142A1A0A);
            }
        }
        g.fillGradient(0, 99, W, 111, 0x38000000, 0x00000000);
        bulletin(g, 8, 21, 86, 15);
        for (int i = 0; i < 6; i++) rect(g, 18 + i * 52, 104 + (i % 2) * 14, 9, 1, 0x40FFFFFF);   // the shine of the tiles
        rrect(g, 20, 138, 260, 28, 4, 0xFFE58AB0);                                     // the runner
        rrect(g, 22, 140, 256, 26, 3, 0xFFF4A7C3);
        for (int x = 28; x < 272; x += 10) { rect(g, x, 144, 5, 1, 0xFFFFD0E2); rect(g, x + 5, 160, 5, 1, 0xFFFFD0E2); }
    }

    /** A cork board with notes and a pin, over the lockers. */
    private static void bulletin(GuiGraphics g, int x, int y, int w, int h) {
        rect(g, x - 1, y + 1, w + 2, h + 1, 0x24000000);
        rect(g, x - 2, y - 2, w + 4, h + 4, WOOD_DARK);
        rect(g, x - 2, y - 2, w + 4, 1, WOOD);
        rect(g, x, y, w, h, 0xFFD9A872);
        for (int i = 0; i < 24; i++) rect(g, x + (i * 29) % w, y + (i * 13) % h, 1, 1, 0xFFC08A55);
        int[] c = {0xFFFFF3B0, 0xFFFFC8DC, 0xFFC8E6FF, 0xFFD8F3D8, 0xFFFFFFFF};
        for (int i = 0; i < 5; i++) {
            int nx = x + 4 + i * 17, ny = y + 2 + (i % 2) * 3;
            rect(g, nx, ny, 12, 9, c[i]);
            rect(g, nx, ny + 8, 12, 1, 0x22000000);
            rect(g, nx + 5, ny, 2, 2, i % 2 == 0 ? 0xFFE5486F : 0xFF4A9AE8);
            for (int k = 0; k < 2; k++) rect(g, nx + 2, ny + 3 + k * 2, 8 - k * 3, 1, 0x55806070);
        }
    }

    /** A locker: a body with vents, a handle, a lock and a name tag. open = the door stands ajar. */
    static void locker(GuiGraphics g, int x, int y, int color, boolean open, boolean hover, boolean own) {
        rect(g, x - 1, y + 56, 18, 2, 0x22000000);                                    // the shadow on the floor
        rect(g, x, y, 16, 56, mix(color, 0x000000, 0.28F));
        if (open) {                                                                   // the door stands ajar, the inside is dark
            rect(g, x + 1, y + 1, 14, 54, mix(color, 0x000000, 0.6F));
            rect(g, x + 2, y + 22, 11, 1, 0x44FFFFFF);
            rect(g, x + 2, y + 38, 11, 1, 0x33FFFFFF);
            rect(g, x + 1, y + 1, 4, 54, color);
            rect(g, x + 1, y + 1, 4, 1, 0x66FFFFFF);
            rect(g, x + 4, y + 1, 1, 54, 0x44000000);
            return;
        }
        int body = hover ? mix(color, 0xFFFFFF, 0.3F) : color;
        rect(g, x + 1, y + 1, 14, 54, body);
        rect(g, x + 1, y + 1, 14, 1, 0x88FFFFFF);
        rect(g, x + 1, y + 1, 1, 54, 0x44FFFFFF);
        rect(g, x + 14, y + 1, 1, 54, 0x30000000);
        for (int k = 0; k < 3; k++) rect(g, x + 4, y + 5 + k * 3, 8, 1, 0x55000000);   // vents
        rect(g, x + 1, y + 27, 14, 1, 0x30000000);
        rect(g, x + 11, y + 29, 2, 6, 0xFFFFFFFF);                                    // the handle
        rect(g, x + 11, y + 29, 2, 1, 0xFFB0B8C8);
        rect(g, x + 4, y + 31, 3, 3, 0xFF8A8AA0);                                     // the lock
        rect(g, x + 5, y + 32, 1, 1, 0xFF3A3A4A);
        if (own) {                                                                    // your own locker has a gold name tag
            rect(g, x + 3, y + 40, 10, 6, 0xFFFFD34E);
            rect(g, x + 3, y + 40, 10, 1, 0xFFFFF0A0);
            rect(g, x + 4, y + 42, 8, 1, 0xFFB07A10); rect(g, x + 4, y + 44, 5, 1, 0xFFB07A10);
        }
    }

    /** The frame of a door: dark wood with a lit left edge and a shadow on the wall. */
    static void doorFrame(GuiGraphics g, int x, int y, int w, int h) {
        rect(g, x - 1, y - 1, w + 4, h + 3, 0x24000000);
        rect(g, x - 3, y - 3, w + 6, h + 3, WOOD_DARK);
        rect(g, x - 3, y - 3, w + 6, 1, WOOD);
        rect(g, x - 3, y - 3, 1, h + 3, WOOD);
    }

    /** The class door: shut until the bell. */
    static void classDoor(GuiGraphics g, int x, int y, int w, int h) {
        doorFrame(g, x, y, w, h);
        rect(g, x, y, w, h, WOOD);
        rect(g, x + 2, y + 2, w - 4, h - 4, 0xFF8A5A30);
        bevel(g, x + 3, y + 3, w - 6, 20, 0xFFBFE6FF, 0xFFE8F6FF, 0xFF6E4726);       // the window of the door
        rect(g, x + w / 2 - 1, y + 3, 2, 20, WOOD_LIGHT);
        line(g, x + 6, y + 8, x + 11, y + 4, 0x88FFFFFF);
        bevel(g, x + 5, y + 28, w - 10, 14, 0xFF9A6A3C, 0xFFB98450, 0xFF6E4726);     // panels
        bevel(g, x + 5, y + 45, w - 10, h - 49, 0xFF9A6A3C, 0xFFB98450, 0xFF6E4726);
        disc(g, x + w - 7, y + 40, 2, 0xFFFFD34E);                                    // the knob
        rect(g, x + w - 8, y + 39, 1, 1, 0xFFFFF8C0);
    }

    /** The door of the canteen: swing doors with round windows and a mat. */
    static void canteenDoor(GuiGraphics g, int x, int y, int w, int h, boolean hover, int ticks) {
        doorFrame(g, x, y, w, h);
        int c = hover ? 0xFFFFE9A8 : 0xFFFFD99A;
        rect(g, x, y, w, h, c);
        rect(g, x, y, w / 2, h, mix(c, 0xFFFFFF, 0.12F));
        rect(g, x + w / 2 - 1, y, 2, h, WOOD_DARK);
        rect(g, x, y + h - 6, w, 6, mix(c, 0x000000, 0.12F));                        // the kick plate
        for (int d = 0; d < 2; d++) {
            int wx = x + 13 + d * (w - 26);
            disc(g, wx, y + 22, 8, WOOD_DARK);
            disc(g, wx, y + 22, 7, 0xFFFFF8E8);
            disc(g, wx, y + 22, 5, d == 0 ? 0xFFFFE9C8 : 0xFFFFF0D0);
            disc(g, wx, y + 22, 3, d == 0 ? 0xFFE5486F : 0xFFF5B84A);              // a little dish behind the glass
            rect(g, wx - 3, y + 18, 2, 1, 0xAAFFFFFF);
        }
        rrect(g, x + 4, y + h - 3, w - 8, 3, 1, 0xFFE5486F);                           // the mat
        for (int k = 0; k < 3; k++) rect(g, x + 10 + k * 14, y - 8 - (int) Math.round(Math.sin((ticks + k * 20) / 12.0) * 2), 1, 4, 0x66B0A0C0);   // steam
    }

    /** The glass door to the yard: a view of the grass and the sky. */
    static void yardDoor(GuiGraphics g, int x, int y, int w, int h, boolean hover) {
        doorFrame(g, x, y, w, h);
        g.fillGradient(x, y, x + w, y + 32, hover ? 0xFF9FDCFF : 0xFF8FD3FF, hover ? 0xFFE8F8FF : 0xFFD6F2FF);
        rect(g, x, y + 32, w, h - 32, hover ? 0xFFC8EFC0 : 0xFFA8DDA0);
        rect(g, x, y + 32, w, 3, hover ? 0xFFB0E4A8 : 0xFF8ECB86);
        disc(g, x + 9, y + 11, 3, 0xFFFFF0A0);
        disc(g, x + w - 11, y + 14, 3, 0xEEFFFFFF); disc(g, x + w - 7, y + 15, 3, 0xEEFFFFFF);   // a cloud
        rect(g, x + 6, y + 45, 1, 3, 0xFFFF8FB8); rect(g, x + 26, y + 50, 1, 3, 0xFFFFF3B0); rect(g, x + 15, y + 54, 1, 3, 0xFFFFFFFF);   // flowers
        rect(g, x + w / 2 - 1, y, 2, h, WOOD_DARK);
        rect(g, x, y + 30, w, 2, WOOD_DARK);
        line(g, x + 3, y + 22, x + 10, y + 5, 0x55FFFFFF);                             // a glint
        line(g, x + 5, y + 24, x + 9, y + 15, 0x33FFFFFF);
        rect(g, x + w / 2 - 5, y + 38, 2, 6, 0xFFFFD34E);                              // the handles
        rect(g, x + w / 2 + 3, y + 38, 2, 6, 0xFFFFD34E);
    }

    /** The door of the nurse: white with a red cross and a little window. */
    static void nurseDoor(GuiGraphics g, int x, int y, int w, int h, boolean hover) {
        doorFrame(g, x, y, w, h);
        rect(g, x, y, w, h, hover ? 0xFFFFFFFF : 0xFFF2FBF8);
        rect(g, x, y, 2, h, 0x66FFFFFF);
        rect(g, x + w - 2, y, 2, h, 0x14000000);
        rect(g, x + w / 2 - 1, y, 2, h, 0xFFC8DDD6);
        bevel(g, x + 5, y + 4, w - 10, 8, 0xFFBFE6F0, 0xFFE8F8FF, 0xFF7EC0C8);
        rrect(g, x + w / 2 - 9, y + 20, 18, 18, 3, 0xFFFFE9EE);
        rect(g, x + w / 2 - 2, y + 22, 4, 14, 0xFFE5486F);
        rect(g, x + w / 2 - 7, y + 27, 14, 4, 0xFFE5486F);
        disc(g, x + w - 6, y + 44, 2, 0xFFFFD34E);
    }

    // =====================================================================================================
    //  THE CANTEEN (wall, floor and counter; the dishes, the menu text and the pet stay in SchoolApp)
    // =====================================================================================================
    static void canteen(GuiGraphics g, int ticks) {
        rect(g, 0, 15, W, 90, 0xFFFFF3D6);
        for (int x = 0; x < W; x += 14) rect(g, x, 15, 7, 90, 0xFFFFECC2);
        g.fillGradient(0, 15, W, 40, 0x30E0A850, 0x00E0A850);
        rect(g, 0, 15, W, 3, 0xFFFFFAEC);
        rect(g, 0, 18, W, 1, 0xFFE8CC90);
        // a tiled band behind the counter
        for (int y = 66, r = 0; y < 100; y += 8, r++) for (int x = (r & 1) * 8 - 8; x < W; x += 16) { rect(g, x, y, 16, 8, 0xFFFFF9EC); rect(g, x, y, 16, 1, 0xFFFFFFFF); rect(g, x + 15, y, 1, 8, 0xFFE8D8B0); rect(g, x, y + 7, 16, 1, 0xFFE8D8B0); }
        rect(g, 0, 100, W, 4, 0xFFC8955C);
        rect(g, 0, 100, W, 1, 0xFFF2C894);
        // the floor
        for (int y = 104, r = 0; y < H; y += 16, r++) {
            for (int x = 0, c = 0; x < W; x += 20, c++) {
                boolean a = ((r + c) & 1) == 0;
                rect(g, x, y, 20, 16, a ? 0xFFF8EBD3 : 0xFFEBD7B4);
                rect(g, x, y, 20, 1, a ? 0xFFFFFFF0 : 0xFFF5E6C8);
                rect(g, x, y + 15, 20, 1, 0x182A1A0A);
            }
        }
        g.fillGradient(0, 104, W, 116, 0x38000000, 0x00000000);
        clock(g, 26, 31);                                                              // a clock on the left, a picture on the right
        rect(g, 261, 20, 28, 23, 0x24000000);
        bevel(g, 260, 18, 28, 23, 0xFFFFF8E8, WOOD_LIGHT, WOOD_DARK);
        rect(g, 263, 21, 22, 17, 0xFFFFF0D0);
        disc(g, 274, 31, 5, 0xFFE5486F); disc(g, 272, 29, 1, 0x88FFFFFF);
        rect(g, 274, 22, 1, 4, 0xFF6E4726); rect(g, 275, 22, 4, 3, 0xFF4CAF50);
    }

    /** The counter of the canteen: a wooden front with a top that shines and a shaded lower edge. */
    static void counter(GuiGraphics g, int x, int y, int w, int h) {
        rrect(g, x, y + 2, w, h, 6, 0x30000000);
        rrect(g, x, y, w, h, 6, WOOD_DARK);
        rrect(g, x, y, w, h - 4, 6, WOOD);
        rect(g, x + 2, y, w - 4, 5, 0xFFD9A872);                                      // the shiny top
        rect(g, x + 2, y, w - 4, 1, 0xFFF4D4A8);
        rect(g, x + 2, y + 5, w - 4, 1, 0xFFB98450);
        for (int k = 0; k < 4; k++) rect(g, x + 14 + k * 66, y + 46, 52, 1, 0x30000000);
    }

    // =====================================================================================================
    //  THE NURSE'S OFFICE
    // =====================================================================================================
    static void nurse(GuiGraphics g, int ticks) {
        rect(g, 0, 15, W, 85, 0xFFE6F6F0);
        for (int x = 0; x < W; x += 20) rect(g, x, 15, 10, 85, 0xFFDDF0E8);
        g.fillGradient(0, 15, W, 38, 0x2840B0A0, 0x0040B0A0);
        rect(g, 0, 15, W, 3, 0xFFF4FFFA);
        rect(g, 0, 18, W, 1, 0xFFB9D8CE);
        rect(g, 0, 82, W, 2, 0xFFFFFFFF);                                              // a white band with a teal edge
        rect(g, 0, 84, W, 1, 0xFF8FCFC0);
        rect(g, 0, 85, W, 15, 0xFFCDE9E0);
        for (int x = 0; x < W; x += 20) rect(g, x, 85, 1, 15, 0x22FFFFFF);
        rect(g, 0, 98, W, 3, 0xFFFFFFFF);
        rect(g, 0, 100, W, 1, 0x44000000);
        for (int y = 101, r = 0; y < H; y += 16, r++) {
            for (int x = 0, c = 0; x < W; x += 20, c++) {
                boolean a = ((r + c) & 1) == 0;
                rect(g, x, y, 20, 16, a ? 0xFFF6FCF9 : 0xFFDDEEE8);
                rect(g, x, y, 20, 1, a ? 0xFFFFFFFF : 0xFFEAF6F2);
                rect(g, x, y + 15, 20, 1, 0x142A4A3A);
            }
        }
        g.fillGradient(0, 101, W, 113, 0x30000000, 0x00000000);
        // the green cross on the wall in a round sign
        disc(g, 235, 30, 12, 0xFFFFFFFF);
        disc(g, 235, 30, 11, 0xFFE6F6F0);
        rect(g, 232, 22, 6, 16, 0xFF3AAFA9); rect(g, 227, 27, 16, 6, 0xFF3AAFA9);
        rect(g, 232, 22, 6, 1, 0x66FFFFFF);
        // an eye chart
        rect(g, 252, 22, 34, 26, 0x24000000);
        bevel(g, 250, 20, 34, 26, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFC8DDD6);
        rect(g, 256, 24, 22, 3, 0xFF3A2A3A);
        rect(g, 258, 30, 18, 2, 0xFF5A4A5A);
        rect(g, 260, 35, 14, 2, 0xFF7A6A7A);
        rect(g, 262, 40, 10, 1, 0xFF9A8A9A);
        // the medicine cabinet: glass door, shelves, bottles
        rect(g, 7, 25, 40, 60, 0x24000000);
        rect(g, 6, 23, 38, 60, WOOD_DARK);
        rect(g, 6, 23, 38, 1, WOOD);
        rect(g, 8, 25, 34, 56, 0xFFEFF8F5);
        for (int sh = 0; sh < 3; sh++) {
            rect(g, 8, 43 + sh * 17, 34, 2, 0xFFB9D8CE);
            rect(g, 8, 43 + sh * 17, 34, 1, 0xFFFFFFFF);
            for (int k = 0; k < 3; k++) {
                int bx = 12 + k * 10, by = 28 + sh * 17;
                int col = (k + sh) % 3 == 0 ? 0xFFE5486F : (k + sh) % 3 == 1 ? 0xFF4A9AE8 : 0xFF8FD3A0;
                rrect(g, bx, by + 4, 6, 11, 2, col);
                rect(g, bx + 1, by + 1, 4, 3, 0xFFFFFFFF);
                rect(g, bx + 1, by + 7, 4, 3, 0xFFFFFFFF);
                rect(g, bx + 1, by + 5, 1, 9, 0x55FFFFFF);
            }
        }
        line(g, 11, 78, 22, 28, 0x44FFFFFF);                                           // a glint on the glass
        line(g, 15, 78, 24, 40, 0x33FFFFFF);
        // the bed: a frame, a mattress, a blanket and a pillow
        rect(g, 150, 96, 140, 3, 0x30000000);
        rect(g, 152, 98, 4, 20, 0xFF8A8AA0); rect(g, 152, 98, 1, 20, 0xFFB0B0C8);
        rect(g, 284, 98, 4, 20, 0xFF8A8AA0); rect(g, 284, 98, 1, 20, 0xFFB0B0C8);
        rect(g, 148, 92, 144, 7, 0xFFB9D8CE);
        rect(g, 148, 92, 144, 1, 0xFFE0F4EC);
        rrect(g, 150, 82, 140, 13, 5, 0xFFFFFFFF);
        rrect(g, 152, 80, 34, 11, 5, 0xFFFFF1D6);                                      // the pillow
        rect(g, 156, 82, 14, 1, 0xFFFFFFFF);
        rect(g, 190, 87, 100, 6, 0xFF8FD3C8);                                          // the blanket
        rect(g, 190, 87, 100, 1, 0xFFBDEBE2);
        for (int x = 196; x < 288; x += 12) rect(g, x, 89, 6, 1, 0xFFBDEBE2);
        // a rug and a scale next to the bed
        rrect(g, 20, 134, 116, 30, 6, 0xFFB9E4DA);
        rrect(g, 23, 137, 110, 24, 5, 0xFFDAF3EC);
    }

    // =====================================================================================================
    //  THE YARD: sky, the school, the fence and the grass (the toys are drawn by yardToys)
    // =====================================================================================================
    static void yardBase(GuiGraphics g, int part, int ticks) {
        g.fillGradient(0, 15, W, 66, part == 2 ? 0xFF121838 : part == 1 ? 0xFFFF9A62 : 0xFF7CCBFF, part == 2 ? 0xFF2C3E78 : part == 1 ? 0xFFFFD9A0 : 0xFFE4F7FF);
        if (part == 2) {
            disc(g, 262, 30, 9, 0xFFF4F1D8);
            disc(g, 266, 27, 8, 0xFF121838);
            for (int i = 0; i < 18; i++) if ((ticks / 20 + i) % 5 != 0) rect(g, (i * 67 + 11) % W, (i * 29) % 40 + 17, 1, 1, 0xFFFFFFFF);
        } else {
            int sy = part == 1 ? 44 : 30;
            disc(g, 270, sy, 14, part == 1 ? 0x30FF8A4A : 0x30FFE066);
            disc(g, 270, sy, 9, part == 1 ? 0xFFFF8A4A : 0xFFFFE066);
            disc(g, 267, sy - 3, 3, part == 1 ? 0x55FFFFFF : 0x66FFFFFF);
        }
        for (int i = 0; i < 2; i++) {                                                 // clouds that drift
            int cx = (int) ((ticks * (0.12 + i * 0.05) + i * 150) % (W + 80)) - 40, cy = 24 + i * 13;
            int c = part == 2 ? 0x55FFFFFF : 0xEEFFFFFF;
            disc(g, cx, cy, 5, c); disc(g, cx + 7, cy + 2, 6, c); disc(g, cx - 7, cy + 3, 4, c);
            rect(g, cx - 8, cy + 5, 20, 2, c);
        }
        // far trees and hills
        oval(g, 30, 66, 50, 10, part == 2 ? 0xFF244A5E : 0xFF9AD98C);
        oval(g, 250, 66, 60, 12, part == 2 ? 0xFF1E4056 : 0xFF86CC7E);
        for (int i = 0; i < 5; i++) { int tx = 6 + i * 62; disc(g, tx, 56, 6, part == 2 ? 0xFF1E5040 : 0xFF63B86A); rect(g, tx - 1, 58, 2, 8, part == 2 ? 0xFF2A3A3A : 0xFF7A5A3A); }
        // the school building
        rect(g, 36, 32, 228, 34, 0xFFF3D9B5);
        for (int x = 36; x < 264; x += 6) rect(g, x, 32, 1, 34, 0x10A07040);                 // bricks
        for (int y = 36; y < 66; y += 6) rect(g, 36, y, 228, 1, 0x0CA07040);
        rect(g, 36, 32, 228, 1, 0xFFFFEAD0);
        rect(g, 32, 24, 236, 8, 0xFFC8553D);                                                  // the roof
        rect(g, 32, 24, 236, 1, 0xFFE8806A);
        rect(g, 32, 31, 236, 1, 0xFF8A3A2A);
        for (int x = 34; x < 266; x += 8) rect(g, x, 26, 1, 5, 0x22000000);
        rect(g, 36, 62, 228, 4, 0xFFD2B88C);                                                  // the plinth
        for (int i = 0; i < 6; i++) {
            if (i == 2 || i == 3) continue;
            int wx = 46 + i * 36;
            rect(g, wx - 1, 37, 22, 18, 0x22000000);
            bevel(g, wx, 36, 20, 17, WOOD_LIGHT, 0xFFE8C08A, WOOD_DARK);
            rect(g, wx + 2, 38, 16, 13, part == 2 ? 0xFFFFE9A0 : 0xFFBFE6FF);
            rect(g, wx + 9, 38, 2, 13, WOOD_LIGHT);
            rect(g, wx + 2, 44, 16, 1, WOOD_LIGHT);
            if (part != 2) rect(g, wx + 3, 39, 3, 1, 0x88FFFFFF);
            rect(g, wx - 1, 53, 22, 2, 0xFFD2B88C);                                           // the sill
        }
        rect(g, 133, 41, 34, 25, 0xFF6E4726);                                                 // the main door
        rect(g, 135, 43, 30, 23, WOOD);
        rect(g, 149, 43, 2, 23, 0xFF6E4726);
        bevel(g, 137, 45, 10, 10, 0xFFBFE6FF, 0xFFE8F6FF, 0xFF6E4726);
        bevel(g, 153, 45, 10, 10, 0xFFBFE6FF, 0xFFE8F6FF, 0xFF6E4726);
        rect(g, 146, 56, 1, 3, 0xFFFFD34E); rect(g, 153, 56, 1, 3, 0xFFFFD34E);
        rect(g, 130, 66, 40, 2, 0xFFD2B88C);
        rrect(g, 138, 27, 24, 11, 3, 0xFFFFF8E8);                                              // a sign over the door
        rect(g, 140, 29, 20, 1, 0xFFF4A7C3);
        for (int k = 0; k < 3; k++) rect(g, 142 + k * 6, 32, 4, 3, k == 1 ? 0xFFF4A7C3 : 0xFF8FB8F0);
        if (part == 2) g.fill(36, 32, 264, 66, 0x40101840);
        // the grass and the fence
        g.fillGradient(0, 66, W, H, 0xFF86D68A, 0xFF4DB35E);
        for (int i = 0; i < 9; i++) rect(g, (i & 1) * 20, 77 + i * 10, W, 5, 0x14FFFFFF);          // mown stripes
        for (int i = 0; i < 40; i++) { int gx = (i * 71 + 13) % W, gy = 84 + (i * 37) % 80; rect(g, gx, gy, 1, 2, 0x30206830); rect(g, gx + 2, gy + 1, 1, 1, 0x30206830); }
        rect(g, 0, 69, W, 2, 0xFFFFF8E8);
        rect(g, 0, 74, W, 2, 0xFFFFF8E8);
        rect(g, 0, 71, W, 1, 0x22000000);
        for (int x = 2; x < W; x += 9) { rect(g, x, 66, 3, 12, 0xFFFFF8E8); rect(g, x, 66, 3, 1, 0xFFFFFFFF); rect(g, x + 2, 67, 1, 11, 0x14000000); rect(g, x, 78, 3, 1, 0x18000000); }
        rect(g, 108, 66, 84, 13, 0xFF86D68A);                                                 // the gate is open
        g.fillGradient(108, 66, 192, 79, 0xFF86D68A, 0xFF7ACB82);
        rect(g, 105, 63, 4, 16, 0xFFC8553D); rect(g, 191, 63, 4, 16, 0xFFC8553D); rect(g, 105, 63, 4, 1, 0xFFE8806A); rect(g, 191, 63, 4, 1, 0xFFE8806A);
        oval(g, 150, 86, 42, 7, 0xFFE0C898);                                                   // a path from the gate
        oval(g, 150, 85, 38, 5, 0xFFEBD6A8);
    }

    /** The toys of the yard: hopscotch, the hoop, a bench, swings, a tree and flowers (the ball keeps bouncing). */
    static void yardToys(GuiGraphics g, int ticks, int part) {
        for (int i = 0; i < 5; i++) {                                                         // hopscotch
            int hx0 = 48, hy0 = 134 - i * 9;
            rect(g, hx0, hy0, 12, 8, 0x77FFFFFF);
            rect(g, hx0 + 1, hy0 + 1, 10, 6, i % 2 == 0 ? 0x66FFD34E : 0x66FF8FB8);
        }
        // the basketball hoop
        oval(g, 25, 123, 8, 2, 0x28000000);
        rect(g, 24, 96, 3, 28, 0xFF6E6E88);
        rect(g, 24, 96, 1, 28, 0xFFA0A0BC);
        rect(g, 19, 88, 14, 10, 0xFFFFFFFF);
        rect(g, 19, 88, 14, 1, 0xFFDDDDEE);
        rect(g, 21, 90, 10, 6, 0xFFE5486F);
        rect(g, 22, 91, 8, 4, 0xFFFFFFFF);
        rect(g, 23, 92, 6, 2, 0xFFE5486F);
        rect(g, 21, 98, 10, 2, 0xFFFF8A4A);
        for (int k = 0; k < 4; k++) rect(g, 22 + k * 2, 100 + k % 2, 1, 4, 0xAAFFFFFF);       // the net
        int bounce = (int) Math.round(Math.abs(Math.sin(ticks / 9.0)) * 9);
        oval(g, 38, 124, 4, 1, 0x33000000);
        disc(g, 38, 121 - bounce, 3, 0xFFE8742A);
        rect(g, 35, 121 - bounce, 7, 1, 0xFF8A3A10);
        rect(g, 38, 118 - bounce, 1, 7, 0xFF8A3A10);
        rect(g, 36, 119 - bounce, 1, 1, 0xFFFFC080);
        // swings
        int sway = (int) Math.round(Math.sin(ticks / 24.0) * 5);
        oval(g, 259, 128, 24, 3, 0x22000000);
        rect(g, 239, 92, 4, 35, 0xFFC8553D); rect(g, 275, 92, 4, 35, 0xFFC8553D);
        rect(g, 239, 92, 1, 35, 0xFFE8806A); rect(g, 275, 92, 1, 35, 0xFFE8806A);
        rect(g, 237, 89, 44, 4, 0xFFC8553D);
        rect(g, 237, 89, 44, 1, 0xFFE8806A);
        for (int k = 0; k < 2; k++) {
            int sx = 249 + k * 18 + (k == 0 ? sway : -sway) / 2;
            rect(g, sx, 93, 1, 22, 0xFF8A8AA0);
            rect(g, sx + 7, 93, 1, 22, 0xFF8A8AA0);
            rrect(g, sx - 1, 115, 10, 3, 1, 0xFF4A9AE8);
            rect(g, sx, 115, 8, 1, 0xFF7ABAF8);
        }
        // a bench
        oval(g, 114, 128, 20, 2, 0x22000000);
        rect(g, 96, 111, 36, 3, 0xFFB98450); rect(g, 96, 111, 36, 1, 0xFFD9A872);
        rect(g, 96, 116, 36, 4, 0xFF9A6A44); rect(g, 96, 116, 36, 1, 0xFFB98450);
        rect(g, 98, 120, 3, 7, 0xFF6A4228); rect(g, 127, 120, 3, 7, 0xFF6A4228);
        rect(g, 98, 105, 2, 7, 0xFF6A4228); rect(g, 128, 105, 2, 7, 0xFF6A4228);
        // a tree with a shaded side
        oval(g, 110, 112, 14, 3, 0x28000000);
        rect(g, 107, 90, 5, 22, 0xFF6A4228); rect(g, 107, 90, 2, 22, 0xFF8A5A3A);
        disc(g, 110, 84, 15, 0xFF3F9E48);
        disc(g, 108, 82, 13, 0xFF4CAF50);
        disc(g, 102, 87, 8, 0xFF5CC560);
        disc(g, 104, 77, 5, 0xFF6FD870);
        disc(g, 119, 89, 8, 0xFF3A9444);
        for (int i = 0; i < 5; i++) rect(g, 100 + (i * 7) % 20, 76 + (i * 11) % 18, 2, 2, 0xFFFF7B8A);   // little apples
        // flowers
        for (int i = 0; i < 14; i++) {
            int fx = (i * 83 + 17) % (W - 20) + 10, fy = 104 + (i * 47) % 50;
            int c = i % 3 == 0 ? 0xFFFFF3B0 : i % 3 == 1 ? 0xFFFF8FB8 : 0xFFFFFFFF;
            rect(g, fx, fy + 2, 1, 2, 0xFF3F9E48);
            rect(g, fx - 1, fy, 3, 1, c); rect(g, fx, fy - 1, 1, 3, c);
            rect(g, fx, fy, 1, 1, 0xFFFFD34E);
        }
        if (part == 2) g.fill(0, 15, W, H, 0x55101840);
        else if (part == 1) g.fill(0, 15, W, H, 0x22FF6A20);
    }
}
