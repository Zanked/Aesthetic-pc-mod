package dev.cutemod.client.player;

import dev.cutemod.item.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.Sound;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.resources.sounds.TickableSoundInstance;
import net.minecraft.client.sounds.AudioStream;
import net.minecraft.client.sounds.SoundBufferLibrary;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.client.sounds.WeighedSoundEvents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.neoforged.neoforge.client.event.sound.PlaySoundEvent;

import java.util.concurrent.CompletableFuture;

/**
 * The headphones, client side: are they on, and the quieter world while the portable player plays in them.
 * Only sounds that start while the music plays are made quieter (the ones already playing go on as they were).
 */
public final class Headphones {
    private Headphones() {}

    /** How loud the world is while you listen to the portable player in the headphones (the music itself keeps its volume). */
    public static final float WORLD = 0.55F;

    /** Are the headphones on the head of the local player? */
    public static boolean worn() {
        var p = Minecraft.getInstance().player;
        return p != null && p.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.HEADPHONES.get());
    }

    /** The world is muffled: the portable player plays and the headphones are on. */
    public static boolean muffled() {
        return PlayerEngine.isPlaying() && PlayerEngine.portable() && worn();
    }

    /** Every sound that starts while we listen gets quieter (not the music, records, the menu or our own player). */
    public static void onPlaySound(PlaySoundEvent e) {
        SoundInstance s = e.getSound();
        if (s == null || s instanceof Quiet || s instanceof QuietTick || s instanceof SeekSound) return;
        SoundSource src = s.getSource();
        if (src == SoundSource.MASTER || src == SoundSource.MUSIC || src == SoundSource.RECORDS) return;
        if (!muffled()) return;
        e.setSound(s instanceof TickableSoundInstance t ? new QuietTick(t) : new Quiet(s));
    }

    /** A sound that is the same as another one, only quieter. */
    private static class Quiet implements SoundInstance {
        final SoundInstance in;

        Quiet(SoundInstance in) { this.in = in; }

        @Override public ResourceLocation getLocation() { return in.getLocation(); }
        @Override public WeighedSoundEvents resolve(SoundManager m) { return in.resolve(m); }
        @Override public Sound getSound() { return in.getSound(); }
        @Override public SoundSource getSource() { return in.getSource(); }
        @Override public boolean isLooping() { return in.isLooping(); }
        @Override public boolean isRelative() { return in.isRelative(); }
        @Override public int getDelay() { return in.getDelay(); }
        @Override public float getVolume() { return in.getVolume() * WORLD; }
        @Override public float getPitch() { return in.getPitch(); }
        @Override public double getX() { return in.getX(); }
        @Override public double getY() { return in.getY(); }
        @Override public double getZ() { return in.getZ(); }
        @Override public SoundInstance.Attenuation getAttenuation() { return in.getAttenuation(); }
        @Override public boolean canStartSilent() { return in.canStartSilent(); }
        @Override public boolean canPlaySound() { return in.canPlaySound(); }
        @Override public CompletableFuture<AudioStream> getStream(SoundBufferLibrary lib, Sound sound, boolean looping) { return in.getStream(lib, sound, looping); }
    }

    /** The same for sounds that tick (they follow something or stop by themselves). */
    private static final class QuietTick extends Quiet implements TickableSoundInstance {
        private final TickableSoundInstance t;

        QuietTick(TickableSoundInstance t) { super(t); this.t = t; }

        @Override public boolean isStopped() { return t.isStopped(); }
        @Override public void tick() { t.tick(); }
    }
}
