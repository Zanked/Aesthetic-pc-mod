package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.RandomSource;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * The Halloween event (Oct 24 - Nov 3 by the real calendar, or any time after the "halloween" terminal command).
 * Pumpkin-flavoured things pop up on the desktop: click them to collect candy. Candy is traded in the
 * {@link HalloweenApp} for coins, a wallpaper and spooky games. Horror games are on sale in the Store.
 * Everything is kept in the Progress counters: candy (balance), candy_all (total), hw_force, hw_wall.
 */
public final class Halloween {
    private Halloween() {}

    public static final int WALL = 12;
    private static final int LIFE = 360;
    private static final RandomSource rnd = RandomSource.create();

    private static final class Pop {
        int x, y, age, type;   // type 0 candy, 1 golden candy, 2 ghost
    }

    private static final List<Pop> pops = new ArrayList<>();
    private static int spawnT = 150, ticks;

    // ---------- when ----------
    public static boolean forced() { return Progress.count("hw_force") > 0; }

    public static boolean active() {
        if (forced()) return true;
        LocalDate d = LocalDate.now();
        return (d.getMonthValue() == 10 && d.getDayOfMonth() >= 24) || (d.getMonthValue() == 11 && d.getDayOfMonth() <= 3);
    }

    /** The terminal command: turns the event on for good (or back to the calendar). */
    public static boolean toggleForce() {
        Progress.setCount("hw_force", forced() ? 0 : 1);
        return forced();
    }

    // ---------- candy ----------
    public static int candy() { return Progress.count("candy"); }

    public static int candyAll() { return Progress.count("candy_all"); }

    public static void addCandy(int n) {
        Progress.setCount("candy", candy() + n);
        for (int i = 0; i < n; i++) Progress.bump("candy_all");
    }

    public static boolean spendCandy(int n) {
        if (candy() < n) return false;
        Progress.setCount("candy", candy() - n);
        return true;
    }

    public static boolean hasWallpaper() { return Progress.count("hw_wall") > 0; }

    public static void giveWallpaper() { Progress.setCount("hw_wall", 1); }

    // ---------- the desktop ----------
    /** Only moves the animations (the candy shop uses this). */
    public static void animate() { ticks++; }

    /** Called 60 times per second while the desktop is shown. */
    public static void tick() {
        ticks++;
        if (!active()) { pops.clear(); return; }
        for (int i = pops.size() - 1; i >= 0; i--) {
            if (++pops.get(i).age >= LIFE) pops.remove(i);
        }
        if (--spawnT <= 0) {
            spawnT = 500 + rnd.nextInt(700);
            if (pops.size() < 3) {
                Pop p = new Pop();
                p.x = 12 + rnd.nextInt(App.W - 90);
                p.y = 22 + rnd.nextInt(App.H - 92);          // stays clear of the lantern button in the corner
                int r = rnd.nextInt(100);
                p.type = r < 18 ? 2 : r < 26 ? 1 : 0;
                pops.add(p);
            }
        }
    }

    /** A click on the desktop. Returns true if it hit something of the event. */
    public static boolean click(Shell shell, int x, int y) {
        if (!active()) return false;
        if (x >= 8 && x < 36 && y >= App.H - Dock.HEIGHT - 34 && y < App.H - Dock.HEIGHT - 6) { shell.open(new HalloweenApp()); return true; }
        for (int i = pops.size() - 1; i >= 0; i--) {
            Pop p = pops.get(i);
            if (x >= p.x - 4 && x < p.x + 22 && y >= p.y - 4 && y < p.y + 22) {
                pops.remove(i);
                if (p.type == 2) {
                    Progress.toast("cutemod.toast.hw_ghost");
                } else {
                    int n = p.type == 1 ? 5 : 1;
                    addCandy(n);
                    Progress.toast(p.type == 1 ? "cutemod.toast.hw_golden" : "cutemod.toast.hw_candy", n);
                }
                return true;
            }
        }
        return false;
    }

    /** Decorations and the things to click, drawn on top of the bare desktop. */
    public static void render(GuiGraphics g, int mx, int my) {
        if (!active()) return;
        // cobwebs in the top-left corner
        for (int i = 0; i < 26; i += 3) {
            g.fill(0, i, 26 - i, i + 1, 0x55FFFFFF);
            g.fill(i, 0, i + 1, 26 - i, 0x55FFFFFF);
        }
        g.fill(0, 0, 18, 1, 0x88FFFFFF);
        // three bats
        for (int k = 0; k < 3; k++) {
            int x = (int) ((ticks * (0.5 + 0.25 * k) + k * 97) % (App.W + 40)) - 20;
            int y = 12 + k * 20 + (int) Math.round(Math.sin((ticks + k * 30) / 18.0) * 7);
            bat(g, x, y, (ticks / 6 + k) % 2 == 0);
        }
        // the jack-o'-lantern button
        boolean hov = mx >= 8 && mx < 36 && my >= App.H - Dock.HEIGHT - 34 && my < App.H - Dock.HEIGHT - 6;
        pumpkin(g, 8, App.H - Dock.HEIGHT - 34, 28, hov);
        // the candy count sits on the pumpkin, in a little tag at its bottom edge
        net.minecraft.client.gui.Font font = net.minecraft.client.Minecraft.getInstance().font;
        String cnt = Integer.toString(candy());
        int tw = CuteFont.width(font, cnt), pw = tw + 17, bx = 8 + 14 - pw / 2, by = App.H - Dock.HEIGHT - 15;
        App.roundRect(g, bx - 1, by - 1, pw + 2, 11, 5, 0xFFFF9A2A);
        App.roundRect(g, bx, by, pw, 9, 4, 0xFF2A1A44);
        drawCandy(g, bx + 4, by + 2);
        CuteFont.draw(g, font, cnt, bx + 13, by + 1, 0xFFFFFFFF, false);
        // things to click
        for (Pop p : pops) {
            if (p.age > LIFE - 90 && (p.age / 6) % 2 == 0) continue;   // blinks before it leaves
            int bob = (int) Math.round(Math.sin((ticks + p.x * 3) / 9.0) * 2);
            switch (p.type) {
                case 2 -> ghost(g, p.x, p.y + bob);
                case 1 -> { candy(g, p.x + 2, p.y + 6 + bob, 0xFFFFD866, 0xFFFFF0A0, 2); sparkle(g, p.x + 16, p.y + bob); }
                default -> candy(g, p.x + 2, p.y + 6 + bob, (p.x % 2 == 0) ? 0xFFFF6FA5 : 0xFF6FB8FF, 0xFFFFFFFF, 2);
            }
        }
    }

    // ---------- little pictures ----------
    public static void bat(GuiGraphics g, int x, int y, boolean up) {
        int c = 0xFF1A1226;
        g.fill(x + 4, y + 2, x + 8, y + 6, c);
        g.fill(x + 4, y, x + 5, y + 2, c);
        g.fill(x + 7, y, x + 8, y + 2, c);
        int wy = up ? y : y + 3;
        g.fill(x - 3, wy + 1, x + 4, wy + 3, c);
        g.fill(x + 8, wy + 1, x + 15, wy + 3, c);
        g.fill(x - 3, wy + (up ? 3 : -1), x, wy + (up ? 4 : 1), c);
        g.fill(x + 12, wy + (up ? 3 : -1), x + 15, wy + (up ? 4 : 1), c);
        g.fill(x + 5, y + 3, x + 6, y + 4, 0xFFFF4040);
        g.fill(x + 7, y + 3, x + 8, y + 4, 0xFFFF4040);
    }

    /** A wrapped sweet: body in color, twisted ends. scale 2 = about 10 x 6 pixels. */
    public static void candy(GuiGraphics g, int x, int y, int color, int stripe, int s) {
        g.fill(x, y, x + 3 * s, y + 3 * s, color);
        g.fill(x + 3 * s, y - s / 2, x + 4 * s + 1, y + 3 * s + s / 2, color);
        g.fill(x - s, y - s / 2, x, y + 3 * s + s / 2, color);
        g.fill(x + s, y, x + s + 1, y + 3 * s, stripe);
        g.fill(x + 2, y, x + 3, y + 2, stripe);
    }

    /** The small candy for the menu bar (7 x 4). */
    public static void drawCandy(GuiGraphics g, int x, int y) {
        g.fill(x + 2, y, x + 5, y + 4, 0xFFFF6FA5);
        g.fill(x, y + 1, x + 2, y + 3, 0xFFFF9FC5);
        g.fill(x + 5, y + 1, x + 7, y + 3, 0xFFFF9FC5);
        g.fill(x + 3, y, x + 4, y + 4, 0xFFFFFFFF);
    }

    private static void sparkle(GuiGraphics g, int x, int y) {
        int s = (ticks / 5) % 3;
        g.fill(x - s, y, x + s + 1, y + 1, 0xFFFFFFFF);
        g.fill(x, y - s, x + 1, y + s + 1, 0xFFFFFFFF);
    }

    public static void ghost(GuiGraphics g, int x, int y) {
        int c = 0xEEFFFFFF;
        g.fill(x + 3, y, x + 15, y + 2, c);
        g.fill(x + 1, y + 2, x + 17, y + 16, c);
        for (int i = 0; i < 4; i++) g.fill(x + 1 + i * 4, y + 16, x + 5 + i * 4, y + 19 - (i % 2) * 2, c);
        g.fill(x + 5, y + 6, x + 8, y + 10, 0xFF2A2040);
        g.fill(x + 10, y + 6, x + 13, y + 10, 0xFF2A2040);
        g.fill(x + 7, y + 12, x + 11, y + 14, 0xFF2A2040);
    }

    /** A jack-o'-lantern (also the event button on the desktop). */
    public static void pumpkin(GuiGraphics g, int x, int y, int s, boolean glow) {
        int u = Math.max(1, s / 14);
        int orange = glow ? 0xFFFF9A2A : 0xFFF0801C;
        g.fill(x + 6 * u, y + 2 * u, x + 8 * u, y + 5 * u, 0xFF3A7A3A);
        g.fill(x + 2 * u, y + 5 * u, x + 12 * u, y + 13 * u, orange);
        g.fill(x, y + 7 * u, x + 14 * u, y + 11 * u, orange);
        g.fill(x + 6 * u, y + 5 * u, x + 7 * u, y + 13 * u, 0xFFC86010);
        boolean flick = (ticks / 7) % 5 != 0;
        int eye = flick ? 0xFFFFE680 : 0xFFE0A030;
        g.fill(x + 3 * u, y + 7 * u, x + 5 * u, y + 9 * u, eye);
        g.fill(x + 9 * u, y + 7 * u, x + 11 * u, y + 9 * u, eye);
        g.fill(x + 4 * u, y + 10 * u, x + 10 * u, y + 11 * u, eye);
        g.fill(x + 5 * u, y + 11 * u, x + 6 * u, y + 12 * u, eye);
        g.fill(x + 8 * u, y + 11 * u, x + 9 * u, y + 12 * u, eye);
    }

    /** The "Haunted Pumpkin Night" wallpaper (number {@link #WALL}). */
    public static void wallpaper(GuiGraphics g, int x, int y, int w, int h) {
        g.fillGradient(x, y, x + w, y + h, 0xFF1A0F2E, 0xFF4A2260);
        for (int i = 0; i < 18; i++) {
            int sx = x + (i * 53 + 11) % Math.max(1, w - 2), sy = y + (i * 29 + 5) % Math.max(1, h * 2 / 3);
            g.fill(sx, sy, sx + 1, sy + 1, 0xAAFFFFFF);
        }
        int mr = Math.max(4, Math.min(w, h) / 6);
        int mx = x + w * 3 / 4, my = y + h / 4;
        for (int dy = -mr; dy <= mr; dy++) {
            int dx = (int) Math.floor(Math.sqrt(mr * mr - dy * dy + 0.25));
            g.fill(mx - dx, my + dy, mx + dx + 1, my + dy + 1, 0xFFFFB347);
        }
        // hills and gravestones
        for (int i = 0; i < w; i++) {
            int hh = h / 5 + (int) (Math.sin(i / 9.0) * h / 14);
            g.fill(x + i, y + h - hh, x + i + 1, y + h, 0xFF120A1E);
        }
        for (int k = 0; k < 3; k++) {
            int gx = x + w / 6 + k * (w / 4), gh = Math.max(4, h / 8);
            g.fill(gx, y + h - h / 5 - gh, gx + Math.max(3, w / 24), y + h - h / 5 + 2, 0xFF2A1E3A);
        }
        // a small pumpkin on the hill
        int ps = Math.max(8, Math.min(w, h) / 4);
        pumpkin(g, x + w / 2 - ps / 2, y + h - ps - 2, ps, false);
    }
}
