package dev.cutemod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * The headphones: they go on the head like a helmet (right-click, or the helmet slot) and give no armor. The portable
 * player ({@link MusicPlayerItem}) plays only while they are on, and the world gets quieter (client side, see
 * {@code client.player.Headphones}).
 */
public class HeadphonesItem extends ArmorItem {
    public HeadphonesItem(Holder<ArmorMaterial> material, Properties props) {
        super(material, ArmorItem.Type.HELMET, props);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("cutemod.tip.headphones.wear").withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable("cutemod.tip.headphones.fx").withStyle(ChatFormatting.BLUE));
    }
}
