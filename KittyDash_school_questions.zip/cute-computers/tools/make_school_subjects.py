#!/usr/bin/env python3
"""Pet School subjects: reads tools/school_q/<subject>.txt, checks the questions and writes them (plus the texts of the
subject screen) into both language files. Run it again after every change in the .txt files; it is safe to repeat.

    python3 tools/make_school_subjects.py

File format (one question per line, the FIRST answer is the right one, the game shuffles them):
    [easy.ru]   25 lines   question|right|wrong|wrong
    [easy.en]   25 lines   the same questions in the same order
    [easy.all]  (instead of .ru/.en) one text for both languages (the English class uses it)
Easy and medium have 3 answers, hard has 4. The keys are cutemod.school.q.<subject>.<level>.<n> and
cutemod.school.a.<subject>.<level>.<n>.<k>. The old "mixed" class keeps its old keys (cutemod.school.q.<level>.<n>).
"""
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
LANG = ROOT / "src/main/resources/assets/cutemod/lang"
QDIR = ROOT / "tools/school_q"

SUBJECTS = ["english", "biology", "chemistry", "physics", "history", "philosophy", "literature", "algebra", "geometry"]
ALL_IDS = ["general"] + SUBJECTS                    # the order of the tiles in SchoolApp.SUBJECT
LEVELS = ["easy", "medium", "hard"]
OPTIONS = {"easy": 3, "medium": 3, "hard": 4}
MIN_COUNT = 25                                      # every class of a subject has the same number of questions (at least this many); the game reads it from SchoolApp.SUBJ_POOL

TEXT = {
    "ru": {
        "name": {"general": "Всё сразу", "english": "Английский", "biology": "Биология", "chemistry": "Химия",
                 "physics": "Физика", "history": "История", "philosophy": "Философия", "literature": "Литература", "algebra": "Алгебра", "geometry": "Геометрия"},
        "full": {"general": "Всё понемногу", "english": "Английский язык", "biology": "Биология", "chemistry": "Химия",
                 "physics": "Физика", "history": "Всемирная история", "philosophy": "Философия", "literature": "Литература", "algebra": "Алгебра", "geometry": "Геометрия"},
        "say": {
            "general": "Всё понемногу: звери, числа, природа и много чего ещё! Выбирай класс.",
            "english": "Английский! Слова, грамматика и немного идиом. Выбирай класс.",
            "biology": "Биология! Поговорим о живой природе. Выбирай класс.",
            "chemistry": "Химия! Атомы, газы и кислоты. Выбирай класс.",
            "physics": "Физика! Силы, свет и электричество. Выбирай класс.",
            "history": "Всемирная история! От пирамид и до наших дней. Выбирай класс.",
            "philosophy": "Философия! Большие вопросы о мудрости. Выбирай класс.",
            "literature": "Литература! Книги, герои и писатели. Выбирай класс.",
            "algebra": "Алгебра! Уравнения, степени и числа с загадками. Выбирай класс.",
            "geometry": "Геометрия! Фигуры, углы и площади. Выбирай класс.",
        },
        "misc": {
            "cutemod.school.subj.back": "Предметы",
            "cutemod.school.subj.hello": "Ух-ху! Здравствуй, мой хороший! Какой предмет сегодня выберем?",
            "cutemod.school.subj.hello.1": "Ух-ху! Как я рада тебя видеть! Выбирай предмет, а потом класс.",
            "cutemod.school.subj.hello.2": "Садись, птенчик! Сегодня у нас целых десять предметов.",
            "cutemod.school.subj.hello.nm": "Ух-ху! Здравствуй, %s! Какой предмет выберем?",
            "cutemod.school.subj.idle.0": "Ух-ху, я жду тебя! Выбери предмет, не стесняйся.",
            "cutemod.school.subj.idle.1": "Не бойся, вопросы совсем не страшные. Выбирай предмет!",
            "cutemod.school.subj.idle.2": "Тик-так, тик-так... Урок сам себя не начнёт, малыш!",
            "cutemod.school.subj.idle.3": "Ух-ху, мои крылышки уже затекли! Какой предмет возьмём?",
        },
    },
    "en": {
        "name": {"general": "Mixed", "english": "English", "biology": "Biology", "chemistry": "Chemistry",
                 "physics": "Physics", "history": "History", "philosophy": "Philosophy", "literature": "Literature", "algebra": "Algebra", "geometry": "Geometry"},
        "full": {"general": "A bit of everything", "english": "English language", "biology": "Biology", "chemistry": "Chemistry",
                 "physics": "Physics", "history": "World history", "philosophy": "Philosophy", "literature": "Literature", "algebra": "Algebra", "geometry": "Geometry"},
        "say": {
            "general": "A bit of everything: animals, numbers, nature and much more! Pick a class.",
            "english": "English! Words, grammar and a few idioms. Pick a class.",
            "biology": "Biology! Let's talk about living nature. Pick a class.",
            "chemistry": "Chemistry! Atoms, gases and acids. Pick a class.",
            "physics": "Physics! Forces, light and electricity. Pick a class.",
            "history": "World history! From the pyramids to our days. Pick a class.",
            "philosophy": "Philosophy! Big questions about wisdom. Pick a class.",
            "literature": "Literature! Books, heroes and writers. Pick a class.",
            "algebra": "Algebra! Equations, powers and numbers with secrets. Pick a class.",
            "geometry": "Geometry! Shapes, angles and areas. Pick a class.",
        },
        "misc": {
            "cutemod.school.subj.back": "Subjects",
            "cutemod.school.subj.hello": "Hoo-hoo! Hello, my dear! Which subject shall we take today?",
            "cutemod.school.subj.hello.1": "Hoo-hoo! So glad to see you! Pick a subject first, then a class.",
            "cutemod.school.subj.hello.2": "Sit down, little chick! We have ten subjects today.",
            "cutemod.school.subj.hello.nm": "Hoo-hoo! Hello, %s! Which subject shall we take?",
            "cutemod.school.subj.idle.0": "Hoo-hoo, I am waiting for you! Pick a subject, do not be shy.",
            "cutemod.school.subj.idle.1": "Do not be afraid, the questions are not scary. Pick a subject!",
            "cutemod.school.subj.idle.2": "Tick-tock, tick-tock... The lesson will not start by itself!",
            "cutemod.school.subj.idle.3": "Hoo-hoo, my wings have gone stiff! Which subject shall we take?",
        },
    },
}


COUNTS = {}


def parse(path):
    sections, cur = {}, None
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = re.fullmatch(r"\[(\w+)\.(ru|en|all)\]", line)
        if m:
            cur = (m.group(1), m.group(2))
            sections[cur] = []
        elif cur is None:
            sys.exit(f"{path.name}: text before the first [section]")
        else:
            sections[cur].append(line)
    return sections


def check(subject, level, lang, lines, problems, count):
    n_opt = OPTIONS[level]
    if len(lines) != count:
        problems.append(f"{subject} {level}.{lang}: {len(lines)} questions, the subject has {count}")
    seen = set()
    for i, line in enumerate(lines):
        parts = [p.strip() for p in line.split("|")]
        where = f"{subject} {level}.{lang} #{i + 1}"
        if len(parts) != n_opt + 1:
            problems.append(f"{where}: {len(parts) - 1} answers, need {n_opt}: {line[:60]}")
            continue
        if any(not p for p in parts):
            problems.append(f"{where}: an empty part: {line[:60]}")
        if len(set(parts[1:])) != len(parts[1:]):
            problems.append(f"{where}: two equal answers: {line[:60]}")
        if parts[0] in seen:
            problems.append(f"{where}: a repeated question")
        seen.add(parts[0])
        if len(parts[0]) > 150:
            problems.append(f"{where}: the question is long ({len(parts[0])} letters)")
        if any(len(p) > 60 for p in parts[1:]):
            problems.append(f"{where}: a long answer")


def load_subject(subject, problems):
    sec = parse(QDIR / f"{subject}.txt")
    out = {"ru": {}, "en": {}}
    count = len(next(iter(sec.values()))) if sec else 0
    if count < MIN_COUNT:
        problems.append(f"{subject}: only {count} questions per class, need at least {MIN_COUNT}")
    COUNTS[subject] = count
    for level in LEVELS:
        if (level, "all") in sec:
            lines = sec[(level, "all")]
            check(subject, level, "all", lines, problems, count)
            out["ru"][level] = out["en"][level] = lines
            continue
        for lang in ("ru", "en"):
            if (level, lang) not in sec:
                problems.append(f"{subject}: no [{level}.{lang}] section")
                continue
            check(subject, level, lang, sec[(level, lang)], problems, count)
            out[lang][level] = sec[(level, lang)]
        a, b = out["ru"].get(level, []), out["en"].get(level, [])
        for i, (x, y) in enumerate(zip(a, b)):
            rx, ry = x.split("|")[1], y.split("|")[1]
            if re.sub(r"\D", "", rx) != re.sub(r"\D", "", ry):
                problems.append(f"{subject} {level} #{i + 1}: the right answers differ in digits: {rx} / {ry}")
            if len(x.split("|")) != len(y.split("|")):
                problems.append(f"{subject} {level} #{i + 1}: ru and en have a different number of answers")
    return out


def main():
    problems = []
    data = {s: load_subject(s, problems) for s in SUBJECTS}
    if problems:
        print("\n".join(problems))
        sys.exit(f"{len(problems)} problem(s), nothing written")
    drop = re.compile(r"^cutemod\.school\.(q|a)\.(%s)\." % "|".join(SUBJECTS))
    total = 0
    for lang, fname in (("en", "en_us.json"), ("ru", "ru_ru.json")):
        path = LANG / fname
        d = json.loads(path.read_text(encoding="utf-8"))
        for k in [k for k in d if drop.match(k) or k.startswith("cutemod.school.subj.")]:
            del d[k]
        t = TEXT[lang]
        for s in ALL_IDS:
            d[f"cutemod.school.subj.name.{s}"] = t["name"][s]
            d[f"cutemod.school.subj.full.{s}"] = t["full"][s]
            d[f"cutemod.school.subj.say.{s}"] = t["say"][s]
        d.update(t["misc"])
        n = 0
        for s in SUBJECTS:
            for level in LEVELS:
                for i, line in enumerate(data[s][lang][level]):
                    parts = [p.strip() for p in line.split("|")]
                    d[f"cutemod.school.q.{s}.{level}.{i}"] = parts[0]
                    for k, ans in enumerate(parts[1:]):
                        d[f"cutemod.school.a.{s}.{level}.{i}.{k}"] = ans
                    n += 1
        total = n
        path.write_text(json.dumps(d, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"{fname}: {n} subject questions, {len(d)} keys")
    print(f"done: {total} questions per language (x3 classes already counted)")
    print("SchoolApp.SUBJ_COUNT = {0, " + ", ".join(str(COUNTS[s]) for s in SUBJECTS) + "}   // general (mixed) first; keep it in the Java file")


if __name__ == "__main__":
    main()
