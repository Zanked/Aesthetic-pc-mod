#!/usr/bin/env python3
"""The words of the 100 generated cute videos (CuteVideos.java): titles, channels, comments, suffixes.
Keys: cutemod.tube.g.t.<theme>.<0-7>, .ch.<theme>.<0-4>, .c.<theme>.<0-7> (%s = the player), .sfx.<1-4> (%d = a number).
Themes: 0 cozy rain, 1 a dancing critter, 2 pastel psychedelics, 3 a lo-fi room, 4 clouds and stars, 5 falling petals.
Run:  python3 tools/make_cute_lang.py     (it adds the keys to en_us.json and ru_ru.json; running it again does nothing)"""
import json, os, re

LANG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "cutemod", "lang")

EN = {
 "t": [
  ["Cozy Rain at the Window", "Rain and a Warm Lamp", "Night Rain for Sleeping", "Raindrops on the Glass", "Rain Over a Tiny Town", "A Quiet Downpour", "Rain and a Cup of Cocoa", "Rain You Can Fall Asleep To"],
  ["Dancing Slime", "Little Panda Does Morning Stretches", "A Bee and a Flower", "Kitty Catches Stars", "Bunny Hops Non-Stop", "Fox on a Cloud", "Penguin Slides Downhill", "The Slime Who Loves Everyone"],
  ["Rainbow Cloud (no words)", "Pink Plasma for 10 Minutes", "Candy Kaleidoscope", "Soft Light and Patterns", "Bubblegum Universe", "Pastel Tunnel", "Lollipop Waves", "Cotton Candy in Space"],
  ["Lo-fi Room for Studying", "Lo-fi: Tea and Sunset", "Warm Room, Quiet Music", "Lo-fi for Homework", "Lo-fi: Lamp and Plants", "An Evening in a Small Room", "Lo-fi for Reading", "Lo-fi: Cup, Window, Silence"],
  ["Clouds Drifting Over the Meadow", "Starry Sky", "A Shooting Star (Let's Wait Together)", "Pink Sunset", "Moon and Little Clouds", "The Sky Before Bed", "Quiet Clouds", "Stars Over a Tiny House"],
  ["Cherry Blossoms Falling", "Spring Wind", "Falling Little Hearts", "Quiet Snowfall", "Golden Leaves", "Dance of the Petals", "Starry Snowfall", "Sakura at Night"],
 ],
 "ch": [
  ["QuietRain", "DropByDrop", "CozyWindow", "RainyCat", "LampAndRain"],
  ["HopHop", "CuteZoo", "FluffyChannel", "StarCritter", "DancingPets"],
  ["SoftTrip", "CandyLight", "PastelDreams", "GlowyCloud", "SugarWaves"],
  ["TeaTimeFM", "LampRoom", "SleepyStudy", "CozyBeats", "WindowSeat"],
  ["SkyBlanket", "LittleStar", "CloudCounter", "SunsetClub", "MoonNap"],
  ["PetalWind", "SakuraDays", "SnowGlobe", "LeafCatcher", "SoftFall"],
 ],
 "c": [
  ["@sleepy_fox: I put this on every evening", "@bee_buzz: it's raining outside too, what a coincidence", "@cat_in_socks: I fall asleep in the 2nd minute, thank you", "@panda_study: I do my homework to this", "@cloud_kid: I want a window like that", "@noodle_nick: can I get one more hour?", "@mochi_moon: %s, can't you sleep either?", "@snow_pea: saved to favorites"],
  ["@sleepy_panda: this is me in the morning", "@bee_buzz: I watched it 5 times already", "@fox_in_socks: so tiny and so brave", "@mochi_moon: %s, look, it waves at you!", "@cloud_kid: made my whole day", "@noodle_nick: the cheeks!! the cheeks!!", "@cat_in_socks: sending this to everyone", "@snow_pea: I want one at home"],
  ["@sleepy_fox: I can't look away", "@bee_buzz: the colors are so soft", "@cat_in_socks: what is this, and why is it so nice", "@panda_study: I stare at it instead of studying", "@mochi_moon: %s, do you see the hearts too?", "@cloud_kid: like a dream with the lights on", "@noodle_nick: more of this please", "@snow_pea: it relaxed my eyes"],
  ["@panda_study: three hours of studying thanks to this", "@sleepy_fox: the cat is breathing so gently", "@bee_buzz: whose room is this? I'll move in", "@cat_in_socks: tea is ready, join me", "@cloud_kid: the lamp is so warm", "@mochi_moon: %s, bring your homework, we'll sit together", "@noodle_nick: I wish evenings were always like this", "@snow_pea: the best background for work"],
  ["@cloud_kid: I counted the clouds. there were 7", "@sleepy_fox: I made a wish on the shooting star", "@bee_buzz: so calm up there", "@cat_in_socks: I'm lying on the roof and watching", "@mochi_moon: %s, did you make a wish too?", "@panda_study: the moon looks like a cookie", "@noodle_nick: sweet dreams, everyone", "@snow_pea: watching it before bed every day"],
  ["@snow_pea: my favorite one, again and again", "@sleepy_fox: so quiet, so soft", "@bee_buzz: the petals dance like they're alive", "@cat_in_socks: I'd catch them with my paws", "@mochi_moon: %s, catch one for me!", "@panda_study: spring in a video", "@noodle_nick: I could watch it forever", "@cloud_kid: this song stays in my head"],
 ],
 "sfx": {1: " #%d", 2: " (1 hour)", 3: " (10 minutes)", 4: " - part %d"},
}
RU = {
 "t": [
  ["Уютный дождь за окном", "Дождь и тёплая лампа", "Ночной дождь для сна", "Капли на стекле", "Дождь над маленьким городом", "Тихий ливень", "Дождь и чашка какао", "Дождь, под который хочется спать"],
  ["Танцующий слайм", "Маленькая панда делает зарядку", "Пчёлка и цветочек", "Котик ловит звёздочки", "Крольчонок прыгает без остановки", "Лисичка на облаке", "Пингвин катится с горки", "Слайм, который любит всех"],
  ["Радужное облако (без слов)", "Розовая плазма 10 минут", "Конфетный калейдоскоп", "Мягкий свет и узоры", "Жвачка во вселенной", "Пастельный туннель", "Леденцовые волны", "Сахарная вата в космосе"],
  ["Lo-fi комната для учёбы", "Lo-fi: чай и закат", "Тёплая комната, тихая музыка", "Lo-fi для домашки", "Lo-fi: лампа и растения", "Вечер в маленькой комнате", "Lo-fi для чтения", "Lo-fi: чашка, окно, тишина"],
  ["Облака плывут над лугом", "Звёздное небо", "Падающая звезда (ждём вместе)", "Розовый закат", "Луна и облачка", "Небо перед сном", "Тихие облака", "Звёзды над маленьким домиком"],
  ["Лепестки сакуры падают", "Весенний ветер", "Падающие сердечки", "Тихий снегопад", "Золотые листья", "Танец лепестков", "Звёздный снегопад", "Сакура в ночи"],
 ],
 "ch": [
  ["ТихийДождь", "КапляЗаКаплей", "УютноеОкно", "ДождливыйКот", "ЛампаИДождь"],
  ["ПрыгПрыг", "МилыйЗоопарк", "ПушистыйКанал", "ЗвёздныйЗверёк", "ТанцыЗверят"],
  ["МягкийТрип", "КонфетныйСвет", "ПастельныеСны", "СветлоеОблако", "СахарныеВолны"],
  ["ЧайныйЭфир", "КомнатаСЛампой", "СонныйСтудент", "УютныеБиты", "МестоУОкна"],
  ["НебесноеОдеяло", "МаленькаяЗвезда", "СчётОблаков", "КлубЗакатов", "ЛунныйСон"],
  ["ЛепесткиНаВетру", "СакуроваяПора", "СнежныйШар", "ЛовецЛистьев", "МягкоеПадение"],
 ],
 "c": [
  ["@sleepy_fox: включаю каждый вечер", "@bee_buzz: за окном тоже дождь, как совпало", "@cat_in_socks: засыпаю на второй минуте, спасибо", "@panda_study: под него делаю уроки", "@cloud_kid: хочу такое окно", "@noodle_nick: можно ещё час?", "@mochi_moon: %s, тебе тоже не спится?", "@snow_pea: сохранил в избранное"],
  ["@sleepy_panda: это я по утрам", "@bee_buzz: уже пять раз посмотрел", "@fox_in_socks: такой маленький и такой смелый", "@mochi_moon: %s, смотри, он тебе машет!", "@cloud_kid: у меня день удался", "@noodle_nick: щёчки!! щёчки!!", "@cat_in_socks: отправляю всем", "@snow_pea: хочу такого домой"],
  ["@sleepy_fox: не могу оторваться", "@bee_buzz: такие мягкие цвета", "@cat_in_socks: что это и почему так приятно", "@panda_study: смотрю вместо учёбы", "@mochi_moon: %s, ты тоже видишь сердечки?", "@cloud_kid: как сон, но с включённым светом", "@noodle_nick: ещё такое, пожалуйста", "@snow_pea: глаза отдохнули"],
  ["@panda_study: три часа учёбы благодаря этому", "@sleepy_fox: кот так нежно дышит", "@bee_buzz: чья это комната? я заселяюсь", "@cat_in_socks: чай готов, присоединяйся", "@cloud_kid: лампа такая тёплая", "@mochi_moon: %s, неси домашку, посидим вместе", "@noodle_nick: хочу, чтобы вечера всегда были такими", "@snow_pea: лучший фон для работы"],
  ["@cloud_kid: я посчитал облака. их было 7", "@sleepy_fox: загадал желание на падающую звезду", "@bee_buzz: там так спокойно", "@cat_in_socks: лежу на крыше и смотрю", "@mochi_moon: %s, ты тоже загадал желание?", "@panda_study: луна похожа на печенье", "@noodle_nick: сладких снов всем", "@snow_pea: смотрю перед сном каждый день"],
  ["@snow_pea: мой любимый, смотрю снова и снова", "@sleepy_fox: так тихо и мягко", "@bee_buzz: лепестки танцуют как живые", "@cat_in_socks: я бы их лапками поймал", "@mochi_moon: %s, поймай один для меня!", "@panda_study: весна в видео", "@noodle_nick: смотрел бы вечно", "@cloud_kid: мелодия застряла в голове"],
 ],
 "sfx": {1: " #%d", 2: " (1 час)", 3: " (10 минут)", 4: " — часть %d"},
}

def entries(d):
    out = {}
    for th in range(6):
        for i, v in enumerate(d["t"][th]): out[f"cutemod.tube.g.t.{th}.{i}"] = v
        for i, v in enumerate(d["ch"][th]): out[f"cutemod.tube.g.ch.{th}.{i}"] = v
        for i, v in enumerate(d["c"][th]): out[f"cutemod.tube.g.c.{th}.{i}"] = v
    for k, v in d["sfx"].items(): out[f"cutemod.tube.g.sfx.{k}"] = v
    return out

for name, data in (("en_us.json", EN), ("ru_ru.json", RU)):
    p = os.path.join(LANG, name)
    txt = open(p, encoding="utf-8").read()
    if "cutemod.tube.g.t.0.0" in txt:
        print(name, "already has them"); continue
    add = entries(data)
    body = ",\n".join(f"  {json.dumps(k)}: {json.dumps(v, ensure_ascii=False)}" for k, v in add.items())
    end = txt.rstrip().rfind("}")
    head = txt[:end].rstrip()
    open(p, "w", encoding="utf-8").write(head + ",\n" + body + "\n}\n")
    json.load(open(p, encoding="utf-8"))          # must still be valid
    print(name, "+", len(add), "keys")
