"""
Smooth, high-resolution portable-player textures.

  python tools/make_player_textures.py            # rewrites src/main/resources/.../textures/item/music_player*_3d.png (256 -> 128, smooth)

What it does for every music_player*_3d.png:
  1. the "chips" in the corners of every face (big dark triangles) are replaced by a soft rounded corner with a thin outline;
  2. the pixel art is scaled x4 with smoothing (no stair steps, soft anti-aliased edges, edges re-sharpened a little);
  3. a soft bevel (light on the top/left, shade on the bottom/right) is added to the big faces so the player looks like a glossy toy.

The layout of the atlas (where each face / swatch lives) is NOT changed, so the models keep working.
Run it ONCE on the original 256x256 textures (it detects an already processed 1024 texture and skips it).
"""
import os, sys
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage as ndi

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ITEMS = os.path.join(ROOT, 'src/main/resources/assets/cutemod/textures/item')
NAMES = ['music_player'] + ['music_player_' + c for c in ['pink', 'green', 'white', 'blue', 'orange', 'purple', 'yellow', 'red']]

S = 4  # work size 256 -> 1024
OUT = 128  # size of the saved texture
# faces of the atlas (x, y, w, h) in 256-px space; radius of the rounded corner
FACES = {
    'front':  (0, 0, 96, 160, 7),
    'back':   (100, 0, 96, 160, 7),
    'side':   (200, 0, 36, 160, 6),
    'top':    (100, 170, 96, 36, 5),
    'bottom': (100, 212, 96, 36, 5),
}


def fix_corners(a):
    """a: HxWx4 uint8 (256). Replaces the dark chips with a thin outline + a soft rounded corner."""
    out = a.copy()
    outline = a[0, 0, :3].astype(np.float32)
    for name, (x0, y0, w, h, r) in FACES.items():
        m = r + 5
        for right in (False, True):
            for bottom in (False, True):
                for dy in range(m):
                    for dx in range(m):
                        px = x0 + (w - 1 - dx if right else dx)
                        py = y0 + (h - 1 - dy if bottom else dy)
                        # colour of the face next to the corner, on the same row (keeps the vertical gradient)
                        sx = x0 + (w - 1 - (m + 2) if right else m + 2)
                        cols = [sx + k * (-1 if right else 1) for k in range(0, 9)]
                        fill = np.median(a[py, cols, :3].astype(np.float32), axis=0)   # median: a sticker near the corner does not leak in
                        if dx < r and dy < r:
                            d = np.hypot(dx + 0.5 - r, dy + 0.5 - r)
                            if d > r + 0.5:
                                col = outline * 0.45 + fill * 0.55          # outside the arc: soft, not black
                            elif d > r - 1.2:
                                col = outline                                 # the thin outline follows the arc
                            else:
                                col = fill
                        elif dx < 1 or dy < 1:
                            col = outline
                        else:
                            col = a[py, px, :3].astype(np.float32)
                            # only the old chip (dark outline colour) is replaced
                            if np.abs(col - outline).sum() < 12 and (dx < m - 1 and dy < m - 1):
                                col = fill
                        out[py, px, :3] = np.clip(col, 0, 255).astype(np.uint8)
    return out


def fill_transparent(rgb, alpha):
    """Colour of the transparent pixels = colour of the nearest opaque pixel (so the blur does not drag black in)."""
    inv = alpha == 0
    if not inv.any():
        return rgb
    idx = ndi.distance_transform_edt(inv, return_distances=False, return_indices=True)
    return rgb[idx[0], idx[1]]


def smooth_up(rgb, alpha):
    rgb = fill_transparent(rgb, alpha).astype(np.float32)
    nn = cv2.resize(rgb, None, fx=S, fy=S, interpolation=cv2.INTER_NEAREST)
    g = cv2.GaussianBlur(nn, (0, 0), 3.7)                       # kills the stair steps
    g2 = cv2.GaussianBlur(g, (0, 0), 6.0)
    out = np.clip(g + 1.05 * (g - g2), 0, 255)                   # brings the edges back (a little: no halo)
    out = cv2.bilateralFilter(out.astype(np.uint8), 7, 14, 5)  # smooths the noise inside the colour areas
    return out


def bevel(img, a256):
    """Soft light/shade on the big faces (img: 1024x1024x3 uint8, in place)."""
    f = img.astype(np.float32)
    outline = a256[0, 0, :3].astype(np.float32)
    for name in ('front', 'back', 'side'):
        x0, y0, w, h, r = FACES[name]
        X0, Y0, X1, Y1 = x0 * S, y0 * S, (x0 + w) * S, (y0 + h) * S
        # mask of the area inside the outline (rounded)
        m = Image.new('L', (X1 - X0, Y1 - Y0), 0)
        ImageDraw.Draw(m).rounded_rectangle((7, 7, X1 - X0 - 8, Y1 - Y0 - 8), radius=(r - 1) * S, fill=255)
        m = np.asarray(m.filter(ImageFilter.GaussianBlur(3)), np.float32) / 255
        hh, ww = m.shape
        ys = np.arange(hh)[:, None].astype(np.float32); xs = np.arange(ww)[None, :].astype(np.float32)
        top = np.clip(1 - (ys - 8) / 26, 0, 1) ** 1.6
        left = np.clip(1 - (xs - 8) / 26, 0, 1) ** 1.6
        bot = np.clip(1 - ((hh - 9) - ys) / 30, 0, 1) ** 1.6
        right = np.clip(1 - ((ww - 9) - xs) / 30, 0, 1) ** 1.6
        light = np.clip(top * 0.9 + left * 0.6, 0, 1) * m * 0.38
        shade = np.clip(bot * 0.9 + right * 0.6, 0, 1) * m * 0.20
        reg = f[Y0:Y1, X0:X1]
        reg += (255 - reg) * light[..., None]
        reg -= (reg - outline * 0.8) * shade[..., None]
        f[Y0:Y1, X0:X1] = reg
    return np.clip(f, 0, 255).astype(np.uint8)


def process(path):
    im = Image.open(path).convert('RGBA')
    if im.size != (256, 256):  # (already processed textures are not 256x256)
        print('skip (not 256x256, already processed?):', path, im.size)
        return None
    a = np.array(im)
    alpha = a[..., 3]
    a = fix_corners(a)
    up = smooth_up(a[..., :3], alpha)
    up = bevel(up, a)
    al = cv2.resize(alpha, None, fx=S, fy=S, interpolation=cv2.INTER_NEAREST)
    out = np.dstack([up, al])
    return Image.fromarray(out, 'RGBA').resize((OUT, OUT), Image.LANCZOS)


if __name__ == '__main__':
    outdir = sys.argv[1] if len(sys.argv) > 1 else ITEMS
    for n in NAMES:
        src = os.path.join(ITEMS, n + '_3d.png')
        res = process(src)
        if res is not None:
            res.save(os.path.join(outdir, n + '_3d.png'))
            print('ok', n)
