#!/usr/bin/env python3
"""The words of the new Music app (MusicApp.java). Adds the keys to en_us.json and ru_ru.json; running it again does nothing."""
import json, os
LANG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "cutemod", "lang")
EN = {
 "cutemod.music.tab.home": "Home", "cutemod.music.tab.songs": "Songs", "cutemod.music.tab.artists": "Artists",
 "cutemod.music.tab.albums": "Albums", "cutemod.music.tab.store": "Store",
 "cutemod.music.shuffleall": "Shuffle all - %d", "cutemod.music.sort.title": "By title", "cutemod.music.sort.artist": "By artist",
 "cutemod.music.recent": "Recently added", "cutemod.music.nowplaying": "Now playing", "cutemod.music.coins": "Coins: %d",
 "cutemod.music.albums.n": "%d albums", "cutemod.music.back": "Back", "cutemod.music.theme.tip": "Light / dark look",
 "cutemod.music.libempty.player": "No albums on the player yet.|At the computer open Music, then Library,|and press Player next to an album.",
 "cutemod.music.welcome": "Your music starts here", "cutemod.music.welcome2": "Press the button or pick an album",
}
RU = {
 "cutemod.music.tab.home": "Главная", "cutemod.music.tab.songs": "Песни", "cutemod.music.tab.artists": "Артисты",
 "cutemod.music.tab.albums": "Альбомы", "cutemod.music.tab.store": "Магазин",
 "cutemod.music.shuffleall": "Перемешать всё - %d", "cutemod.music.sort.title": "По названию", "cutemod.music.sort.artist": "По артисту",
 "cutemod.music.recent": "Недавно добавлено", "cutemod.music.nowplaying": "Сейчас играет", "cutemod.music.coins": "Монет: %d",
 "cutemod.music.albums.n": "Альбомов: %d", "cutemod.music.back": "Назад", "cutemod.music.theme.tip": "Светлая / тёмная тема",
 "cutemod.music.libempty.player": "На плеере пока нет альбомов.|За компьютером открой Музыку, потом|Медиатеку и нажми «Плеер» у альбома.",
 "cutemod.music.welcome": "Здесь начинается твоя музыка", "cutemod.music.welcome2": "Нажми кнопку или выбери альбом",
}
for name, add in (("en_us.json", EN), ("ru_ru.json", RU)):
    p = os.path.join(LANG, name)
    txt = open(p, encoding="utf-8").read()
    if '"cutemod.music.tab.home"' in txt:
        print(name, "already has them"); continue
    body = ",\n".join(f"  {json.dumps(k)}: {json.dumps(v, ensure_ascii=False)}" for k, v in add.items())
    head = txt[:txt.rstrip().rfind("}")].rstrip()
    open(p, "w", encoding="utf-8").write(head + ",\n" + body + "\n}\n")
    json.load(open(p, encoding="utf-8"))
    print(name, "+", len(add), "keys")
