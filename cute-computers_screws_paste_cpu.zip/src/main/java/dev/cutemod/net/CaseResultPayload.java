package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client: the prize is already rolled ("skin" = its id) or the opening was refused (skin = "", reason = why). The client only draws the reel. */
public record CaseResultPayload(String skin, String reason) implements CustomPacketPayload {
    public static final Type<CaseResultPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "case_result"));

    public static final StreamCodec<RegistryFriendlyByteBuf, CaseResultPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(48), CaseResultPayload::skin,
            ByteBufCodecs.stringUtf8(24), CaseResultPayload::reason,
            CaseResultPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(CaseResultPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onCaseResult(payload.skin(), payload.reason()));
    }
}
