package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: what is inside a PC case, for the build screen ({@code PcBuildScreen}).
 * {@code open}: open the screen (the first message); otherwise just update the one that is open.
 * {@code event} (EV_*) says what the last action of the player did, {@code detail} gives more (an error code or the slot that was emptied).
 * {@code color}: ordinal of the colour of the case. {@code st} = board, cpu, psu, gpu, disk, modem (-1 = none), cables (0/1), on (0/1), four memory sticks (GB, 0 = empty),
 * the cooler (-2 = old factory cooling, -1 = none, 1..3), how tidy the cables are (0..100), the RGB mode (0..3) and the RGB colour (0..7).
 * EV_POST: the PC started for the first time (or after a change): play the start-up check; EV_THERMAL: it did not start, too hot ({@code detail} 1 = processor, 2 = card).
 * EV_SCREWED: some screws were tightened, {@code detail} = kind * 1000 + how well the cooler sits (0 for the other places, see {@code Screws});
 * EV_PASTED: thermal paste was put on, {@code detail} = its quality (1..100). The state {@code st} has, after the RGB colour: the quality of the paste (0 = none),
 * the mask of the tight screws, how well the cooler sits (0..100), the realistic mode (0 / 1), whether the processor is locked in (0 / 1) and how many
 * of its pins are bent. EV_SEATED: the processor locked in; EV_BENT: it was forced in the wrong way, {@code detail} = the bent pins; EV_CPU_BROKEN: it is
 * ruined (gone); EV_STRAIGHTENED: a pin is straight again, {@code detail} = the bent pins that are left.
 */
public record PcBuildStatePayload(BlockPos pos, boolean open, int event, int detail, int color, List<Integer> st) implements CustomPacketPayload {
    public static final int EV_NONE = 0, EV_INSTALLED = 1, EV_REMOVED = 2, EV_ON = 3, EV_OFF = 4, EV_ERROR = 5, EV_INCOMPLETE = 6, EV_POST = 7, EV_THERMAL = 8, EV_SCREWED = 9, EV_PASTED = 10, EV_SEATED = 11, EV_BENT = 12, EV_CPU_BROKEN = 13, EV_STRAIGHTENED = 14;

    public static final Type<PcBuildStatePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "pc_build_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PcBuildStatePayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, PcBuildStatePayload::pos,
            ByteBufCodecs.BOOL, PcBuildStatePayload::open,
            ByteBufCodecs.VAR_INT, PcBuildStatePayload::event,
            ByteBufCodecs.VAR_INT, PcBuildStatePayload::detail,
            ByteBufCodecs.VAR_INT, PcBuildStatePayload::color,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(32)), PcBuildStatePayload::st,
            PcBuildStatePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(PcBuildStatePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onPcBuild(p));
    }
}
