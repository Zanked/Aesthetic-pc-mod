package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.market.CaseServer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "open one darknet case (with one key) at the computer at pos". The server rolls the prize. */
public record CaseOpenPayload(BlockPos pos) implements CustomPacketPayload {
    public static final Type<CaseOpenPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "case_open"));

    public static final StreamCodec<RegistryFriendlyByteBuf, CaseOpenPayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, CaseOpenPayload::pos,
            CaseOpenPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(CaseOpenPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) CaseServer.open(sp, payload.pos());
        });
    }
}
