package dev.cutemod.market;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Predicate;

/**
 * What a darknet case can hold: the camos of the packs "darknet_camos_pistols" and "dark_matter_pistols" (MCP Skins) in six
 * grades like the cases of CS. Pure data and dice: the client uses it to draw the reel, the server to roll the prize.
 * The skin ids are "<gun>_<camo>".
 */
public final class CaseLoot {
    private CaseLoot() {}

    /** The grades. weight = chances out of 1000 (the sum is 1000); rgb = the colour of the card. */
    public enum Tier {
        COMMON(600, 0xB0C3D9), UNCOMMON(240, 0x5E98D9), RARE(100, 0x4B69FF), EPIC(50, 0x8847FF), LEGENDARY(6, 0xD32CE6), GOLD(4, 0xFFC94D);
        public final int weight, rgb;
        Tier(int weight, int rgb) { this.weight = weight; this.rgb = rgb; }
        public String key() { return name().toLowerCase(java.util.Locale.ROOT); }
    }

    public record Skin(String id, String gun, String gunName, String camo, Tier tier) {}

    private static final String[][] GUNS = {
            {"b93r", "B93R"}, {"cz75", "CZ 75"}, {"deagle", "Desert Eagle"}, {"deagle_golden", "Golden Desert Eagle"},
            {"glock_17", "Glock 17"}, {"lonetrail", "Lonetrail"}, {"m1911", "M1911"}, {"m9a4", "M9A4"},
            {"p320", "P320"}, {"timeless50", "Timeless .50"}};

    private static final Object[][] CAMOS = {
            {"forest_ddpat", "Forest DDPAT", Tier.COMMON}, {"safari_mesh", "Safari Mesh", Tier.COMMON},
            {"urban_masked", "Urban Masked", Tier.UNCOMMON}, {"carbon_fiber", "Carbon Fiber", Tier.UNCOMMON},
            {"blue_steel", "Blue Steel", Tier.RARE}, {"crimson_web", "Crimson Web", Tier.RARE},
            {"fade", "Fade", Tier.EPIC}, {"case_hardened", "Case Hardened", Tier.EPIC}};

    public static final List<Skin> ALL = new ArrayList<>();
    private static final Map<Tier, List<Skin>> BY_TIER = new EnumMap<>(Tier.class);
    private static final Map<String, Skin> BY_ID = new LinkedHashMap<>();

    static {
        for (Tier t : Tier.values()) BY_TIER.put(t, new ArrayList<>());
        for (String[] g : GUNS) {
            for (Object[] c : CAMOS) add(new Skin(g[0] + "_" + c[0], g[0], g[1], (String) c[1], (Tier) c[2]));
            // Dark Matter: the golden Desert Eagle is the "knife" of the case
            add(new Skin(g[0] + "_dark_matter", g[0], g[1], "Dark Matter", g[0].equals("deagle_golden") ? Tier.GOLD : Tier.LEGENDARY));
        }
    }

    private static void add(Skin s) {
        ALL.add(s);
        BY_TIER.get(s.tier()).add(s);
        BY_ID.put(s.id(), s);
    }

    public static Skin byId(String id) { return BY_ID.get(id); }

    public static List<Skin> of(Tier t) { return BY_TIER.get(t); }

    /** The prize: a grade by its chances (only grades that have a skin installed), then one of its skins. Null when nothing is installed. */
    public static Skin roll(Random r, Predicate<String> installed) {
        Map<Tier, List<Skin>> have = new EnumMap<>(Tier.class);
        int total = 0;
        for (Tier t : Tier.values()) {
            List<Skin> list = new ArrayList<>();
            for (Skin s : BY_TIER.get(t)) if (installed.test(s.id())) list.add(s);
            if (!list.isEmpty()) { have.put(t, list); total += t.weight; }
        }
        if (total == 0) return null;
        int roll = r.nextInt(total);
        for (Map.Entry<Tier, List<Skin>> e : have.entrySet()) {
            roll -= e.getKey().weight;
            if (roll < 0) return e.getValue().get(r.nextInt(e.getValue().size()));
        }
        return null;
    }

    /** A card for the reel (the client's decoration: the same chances, but nothing is installed-checked). */
    public static Skin filler(Random r) { return roll(r, id -> true); }
}
