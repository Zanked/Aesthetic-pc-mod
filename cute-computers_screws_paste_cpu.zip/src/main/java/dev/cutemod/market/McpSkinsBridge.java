package dev.cutemod.market;

import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.ModList;

import java.lang.reflect.Method;

/**
 * The link to MCP Skins (the camouflage mod for TACZ guns). Like {@link TaczBridge} it is only used through reflection, so
 * Cute Computers does not need it to compile or to start: without it the darknet cases are "out of stock".
 * A won skin is handed out as MCP Skins' own unlock item (right-click = the skin is yours for good).
 */
public final class McpSkinsBridge {
    private McpSkinsBridge() {}

    public static final String MOD_ID = "mcpskins";
    private static final String API = "org.minechestplate.mcpskins.api.MCPSkinsAPI";

    private static Boolean present;
    private static boolean broken;
    private static Method exists, unlock, skinned;

    /** True when MCP Skins is installed and its API could be found. */
    public static boolean loaded() {
        if (broken) return false;
        if (present == null) {
            try {
                present = ModList.get() != null && ModList.get().isLoaded(MOD_ID);
                if (present) {
                    Class<?> c = Class.forName(API);
                    exists = c.getMethod("exists", String.class);
                    unlock = c.getMethod("createUnlockItem", String.class);
                    skinned = c.getMethod("createSkinnedGun", String.class, String.class);
                }
            } catch (Throwable t) {
                present = false;
                broken = true;
            }
        }
        return present;
    }

    /** Whether a loaded skin pack defines this skin (a pack that is not installed gives false). */
    public static boolean exists(String skinId) {
        if (!loaded()) return false;
        try {
            return (boolean) exists.invoke(null, skinId);
        } catch (Throwable t) {
            return false;
        }
    }

    /** MCP Skins' unlock item of this skin, or an empty stack. */
    public static ItemStack unlockItem(String skinId) {
        if (!loaded()) return ItemStack.EMPTY;
        try {
            return unlock.invoke(null, skinId) instanceof ItemStack s ? s : ItemStack.EMPTY;
        } catch (Throwable t) {
            return ItemStack.EMPTY;
        }
    }

    /** A TACZ gun (id like "tacz:m1911") wearing the skin: only for the picture of the prize. */
    public static ItemStack skinnedGun(String gunId, String skinId) {
        if (!loaded()) return ItemStack.EMPTY;
        try {
            return skinned.invoke(null, gunId, skinId) instanceof ItemStack s ? s : ItemStack.EMPTY;
        } catch (Throwable t) {
            return ItemStack.EMPTY;
        }
    }
}
