package dev.cutemod.market;

import dev.cutemod.item.ModItems;
import dev.cutemod.net.CaseResultPayload;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Opening a darknet case, all on the server: next to a computer, one case and one key out of the inventory, the dice
 * ({@link CaseLoot#roll}) and the prize as MCP Skins' unlock item (it can be used at once or traded to another player).
 * The client only gets the result to draw its reel, so nothing can be tampered with there.
 */
public final class CaseServer {
    private CaseServer() {}

    /** The reel takes about six seconds on the client; a new opening is not taken before that. */
    private static final long COOLDOWN_MS = 6_000L;
    private static final Map<UUID, Long> LAST = new HashMap<>();

    public static void open(ServerPlayer player, BlockPos pos) {
        if (!MarketServer.nearComputer(player, pos)) return;
        if (!(TaczBridge.loaded() && McpSkinsBridge.loaded())) { refuse(player, "nomod"); return; }
        long now = System.currentTimeMillis();
        Long last = LAST.get(player.getUUID());
        if (last != null && now - last < COOLDOWN_MS) { refuse(player, "wait"); return; }
        int cases = count(player, true), keys = count(player, false);
        if (cases < 1) { refuse(player, "nocase"); return; }
        if (keys < 1) { refuse(player, "nokey"); return; }

        CaseLoot.Skin prize = CaseLoot.roll(ThreadLocalRandom.current(), McpSkinsBridge::exists);
        ItemStack unlock = prize == null ? ItemStack.EMPTY : McpSkinsBridge.unlockItem(prize.id());
        if (unlock.isEmpty()) { refuse(player, "noskins"); return; }     // the skin packs are not installed: nothing is taken

        take(player, true);
        take(player, false);
        LAST.put(player.getUUID(), now);
        if (!player.getInventory().add(unlock)) player.drop(unlock, false);   // inventory full: it lands at the player's feet
        PacketDistributor.sendToPlayer(player, new CaseResultPayload(prize.id(), ""));
    }

    public static void forget(UUID id) { LAST.remove(id); }

    private static void refuse(ServerPlayer player, String reason) {
        PacketDistributor.sendToPlayer(player, new CaseResultPayload("", reason));
    }

    private static boolean isIt(ItemStack s, boolean caseItem) {
        return s.is(caseItem ? ModItems.DN_CASE.get() : ModItems.DN_KEY.get());
    }

    private static int count(ServerPlayer p, boolean caseItem) {
        int n = 0;
        for (ItemStack s : p.getInventory().items) if (isIt(s, caseItem)) n += s.getCount();
        for (ItemStack s : p.getInventory().offhand) if (isIt(s, caseItem)) n += s.getCount();
        return n;
    }

    private static void take(ServerPlayer p, boolean caseItem) {
        for (ItemStack s : p.getInventory().items) if (isIt(s, caseItem)) { s.shrink(1); return; }
        for (ItemStack s : p.getInventory().offhand) if (isIt(s, caseItem)) { s.shrink(1); return; }
    }
}
