package dev.cutemod.market;

import java.util.ArrayList;
import java.util.List;

/**
 * The shelves of the dark market (see {@code DarkMarketApp}). Every gun belongs to the gun mod TACZ: {@code gun} is the id of
 * the gun in its default gun pack, {@code ammo} the ammo it shoots, {@code mag} the size of its magazine (a gun is delivered
 * with a full one). Catalog ids are "gun_<gun>" and "ammo_<ammo>", so they fit the 24 characters of a network string.
 * Prices are in coins: a pistol costs about as much as a diamond pickaxe, a sniper rifle as much as netherite armor.
 */
public final class BlackGoods {
    private BlackGoods() {}

    public static final int PISTOL = 0, SMG = 1, RIFLE = 2, SHOTGUN = 3, SNIPER = 4, AMMO = 5;
    public static final int CATS = 6;

    public record Gun(String gun, int cat, String ammo, int mag, int price, int secs) {
        public String id() { return GUN_PREFIX + gun; }
    }

    public record Round(String ammo, int price, int secs) {
        public String id() { return AMMO_PREFIX + ammo; }
    }

    public static final String GUN_PREFIX = "gun_", AMMO_PREFIX = "ammo_";
    /** The darknet case and its key (catalog ids; both cost the same, so a case + a key is 400 coins). */
    public static final String CASE_ID = "dn_case", KEY_ID = "dn_key";
    public static final int CASE_PRICE = 200, KEY_PRICE = 200;

    public static boolean isCaseGoods(String id) { return CASE_ID.equals(id) || KEY_ID.equals(id); }

    public static final List<Gun> GUNS = List.of(
            new Gun("glock_17", PISTOL, "9mm", 17, 350, 150),
            new Gun("cz75", PISTOL, "9mm", 16, 380, 150),
            new Gun("m1911", PISTOL, "45acp", 7, 420, 160),
            new Gun("deagle", PISTOL, "50ae", 7, 700, 180),

            new Gun("hk_mp5a5", SMG, "9mm", 30, 900, 240),
            new Gun("hk_mp7a1", SMG, "46x30", 20, 1000, 240),
            new Gun("p90", SMG, "57x28", 50, 1200, 260),

            new Gun("ak47", RIFLE, "762x39", 30, 1500, 300),
            new Gun("m4a1", RIFLE, "556x45", 30, 1600, 300),
            new Gun("hk416d", RIFLE, "556x45", 30, 1900, 320),
            new Gun("scar_h", RIFLE, "308", 20, 2100, 330),

            new Gun("m870", SHOTGUN, "12g", 5, 1100, 270),
            new Gun("spas_12", SHOTGUN, "12g", 5, 1400, 280),

            new Gun("m700", SNIPER, "30_06", 5, 2200, 400),
            new Gun("ai_awp", SNIPER, "338", 5, 3200, 420),
            new Gun("m95", SNIPER, "50bmg", 5, 4500, 480));

    /** One coin buys one round (a pack of up to 64 is one order line); the bigger the bullet, the dearer it is. */
    public static final List<Round> ROUNDS = List.of(
            new Round("9mm", 1, 90),
            new Round("45acp", 1, 90),
            new Round("46x30", 1, 90),
            new Round("556x45", 1, 100),
            new Round("762x39", 1, 100),
            new Round("12g", 2, 100),
            new Round("50ae", 2, 100),
            new Round("57x28", 2, 100),
            new Round("308", 2, 110),
            new Round("30_06", 2, 110),
            new Round("338", 3, 120),
            new Round("50bmg", 5, 140));

    public static Gun gun(String catalogId) {
        for (Gun g : GUNS) if (g.id().equals(catalogId)) return g;
        return null;
    }

    public static Round round(String catalogId) {
        for (Round r : ROUNDS) if (r.id().equals(catalogId)) return r;
        return null;
    }

    public static List<Gun> guns(int cat) {
        List<Gun> out = new ArrayList<>();
        for (Gun g : GUNS) if (g.cat() == cat) out.add(g);
        return out;
    }

    /** The ammo packs of the calibers that the guns of the shop shoot come first (the player almost always needs those). */
    public static List<Round> rounds() { return ROUNDS; }

    /** Largest pack of one order line (one stack of the ammo item). */
    public static final int PACK = 64;
}
