package dev.cutemod.data;

/**
 * The heat of a PC that was built in a case: how hot the processor and the video card get under full load, from the cooler, the
 * tidiness of the cables (air flows better through a tidy case) and the watts the two parts burn. Pure numbers, no Minecraft
 * classes, so the server (which decides whether the PC may start) and the client (which draws the numbers) share it.
 *
 * <p>The rule of thumb: {@code temperature = 28 + 62 * watts / cooling}, so a part whose watts equal its cooling sits at 90 degrees,
 * where it starts to throttle (the games get slower); at {@link #CRIT} degrees the PC does not start at all (thermal protection).
 * A cooler is optional for the weak processors (a boxed heatsink is enough for the first ones), the strong ones need a real cooler.
 */
public final class Thermal {
    private Thermal() {}

    public static final int AMBIENT = 28;
    /** From this temperature a part throttles (one step; two steps from {@link #HOT}). */
    public static final int THROTTLE = 90, HOT = 96;
    /** From this temperature the PC refuses to start. */
    public static final int CRIT = 100;

    // ---------- coolers (level 0 = none; the items are level 1..3) ----------
    public static final String[] COOLER_NAMES = {"No cooler", "Cute Air 92", "Cute Tower 120", "Cute Liquid 240"};
    /** The watts of the processor each cooler can carry away at 90 degrees. */
    public static final int[] COOLER_CAP = {80, 140, 240, 400};
    /** How much each cooler helps the airflow of the whole case (added to 1.0). */
    public static final double[] COOLER_AIR = {0.0, 0.0, 0.05, 0.10};
    public static final int[] COOLER_PRICE = {0, 45, 110, 260};
    public static final int COOLER_FIRST = 1, COOLER_LAST = 3;
    /** A case built before the coolers existed keeps working: it counts as a good tower cooler until a real one is put in. */
    public static final int LEGACY_CAP = 240;
    /** A cooler without thermal paste on the processor carries away only this part of its watts. */
    public static final double NO_PASTE = 0.85;
    /** A cooler that is screwed on as badly as possible (crooked, uneven) carries away only this part of its watts. */
    public static final double MOUNT_MIN = 0.92;
    /** The thermal paste of a "pea" that is just right (the amount, 0..100, that gives the best contact). */
    public static final int PASTE_IDEAL = 40;
    /** What a part that was put in without the mini-game (the simple mode, a right click on the case) is worth, 0..100. */
    public static final int AUTO_QUALITY = 70;

    /** The watts of the video card each level can carry away at 90 degrees with the airflow of 1.0 (its own fans). */
    public static final int[] GPU_CAP = {1, 45, 105, 185, 330};

    /** What a freshly plugged-in set of cables gives: not neat, not a mess. The cable puzzle replaces it. */
    public static final int TIDY_DEFAULT = 40, TIDY_LEGACY = 50;

    public static String coolerName(int level) { return COOLER_NAMES[Math.max(0, Math.min(COOLER_NAMES.length - 1, level))]; }

    /**
     * How good a blob of thermal paste is: {@code amount} 0..100 is how much was squeezed out. Too little leaves the chip bare in
     * places (the quality falls in step with the amount), too much is not as bad (it only insulates a little), the pea in the
     * middle, {@link #PASTE_IDEAL}, is 100.
     */
    public static int pasteQuality(int amount) {
        int a = Math.max(0, Math.min(100, amount));
        if (a <= PASTE_IDEAL) return (int) Math.round(100.0 * a / PASTE_IDEAL);
        return Math.max(30, 100 - (int) Math.round((a - PASTE_IDEAL) * 1.2));
    }

    /** The part of the cooler's watts that is used with this paste: 0 (none) = {@link #NO_PASTE}, 100 = 1.0. */
    public static double pasteFactor(int quality) {
        if (quality <= 0) return NO_PASTE;
        return NO_PASTE + (1.0 - NO_PASTE) * Math.min(100, quality) / 100.0;
    }

    /** The part of the cooler's watts that is used with this mounting (0..100, from the screws): 100 = 1.0, 0 = {@link #MOUNT_MIN}. */
    public static double mountFactor(int mount) {
        return MOUNT_MIN + (1.0 - MOUNT_MIN) * Math.max(0, Math.min(100, mount)) / 100.0;
    }

    /** The airflow of the case: 1.0 +- 0.15 from the cables (tidy 0..100) and a little from the cooler. */
    public static double air(int cooler, int tidy) {
        int t = Math.max(0, Math.min(100, tidy));
        int c = Math.max(0, Math.min(COOLER_AIR.length - 1, cooler));
        return 1.0 + 0.15 * (t - 50) / 50.0 + COOLER_AIR[c];
    }

    /**
     * Full-load temperature of the processor. {@code cooler} is 0 for none (or the level 1..3), {@code legacy} says the case has
     * the old factory cooling and no cooler was ever put in; {@code paste} is the quality of the thermal paste on the processor
     * (0 = none, 100 = a perfect pea) and {@code mount} how well the cooler is screwed on (0..100); both only count for a real cooler.
     */
    public static int cpuTemp(int cpuWatts, int cooler, boolean legacy, int tidy, int paste, int mount) {
        double cap = cooler > 0 ? COOLER_CAP[Math.min(cooler, COOLER_CAP.length - 1)] * pasteFactor(paste) * mountFactor(mount)
                : legacy ? LEGACY_CAP : COOLER_CAP[0];
        return (int) Math.round(AMBIENT + 62.0 * cpuWatts / (cap * air(cooler, tidy)));
    }

    /** The same with the old yes / no paste and a cooler that sits perfectly (what every case did before the screws). */
    public static int cpuTemp(int cpuWatts, int cooler, boolean legacy, int tidy, boolean paste) {
        return cpuTemp(cpuWatts, cooler, legacy, tidy, paste ? 100 : 0, 100);
    }

    /** Full-load temperature of the video card; 0 if there is none. */
    public static int gpuTemp(int gpuLevel, int gpuWatts, int cooler, int tidy) {
        if (gpuLevel <= 0) return 0;
        int cap = GPU_CAP[Math.min(gpuLevel, GPU_CAP.length - 1)];
        return (int) Math.round(AMBIENT + 62.0 * gpuWatts / (cap * air(cooler, tidy)));
    }

    /** How many steps a part with this temperature throttles: 0, 1 or 2. */
    public static int steps(int temp) { return temp >= HOT ? 2 : temp >= THROTTLE ? 1 : 0; }

    public static boolean critical(int temp) { return temp >= CRIT; }
}
