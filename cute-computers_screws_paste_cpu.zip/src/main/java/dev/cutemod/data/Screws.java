package dev.cutemod.data;

/**
 * The screws of a PC that was built in a case. Three things are screwed down: the motherboard (4 screws, one turn each), the cooler
 * on the processor (4 screws, two turns each: snug, then tight) and the video card (2 screws, one turn each). Pure numbers, no
 * Minecraft classes, so the server (which decides) and the client (which plays the mini-game) share it.
 *
 * <p>The state of a case is one bit mask: bits 0..3 the board, bits 4..7 the cooler, bits 8..9 the card (a set bit = that screw is tight).
 * The mini-game does not send a score: it sends the ORDER in which the screws were turned, and the server works out how well the
 * cooler sits from that order ({@link #coolerQuality}), so a changed client cannot invent a quality.
 *
 * <p>The corners of the cooler are numbered like this: 0 top left, 1 top right, 2 bottom left, 3 bottom right; the opposite corner of
 * {@code i} is {@code 3 - i}.
 */
public final class Screws {
    private Screws() {}

    public static final int KIND_BOARD = 0, KIND_COOLER = 1, KIND_GPU = 2;
    public static final int BOARD = 0x00F, COOLER = 0x0F0, GPU = 0x300, ALL = 0x3FF;

    /** How many screws a place has. */
    public static int count(int kind) { return kind == KIND_COOLER ? 4 : kind == KIND_BOARD ? 4 : 2; }

    /** How many turns every screw of a place needs until it is tight. */
    public static int turns(int kind) { return kind == KIND_COOLER ? 2 : 1; }

    /** The bits of a place in the mask. */
    public static int mask(int kind) { return kind == KIND_COOLER ? COOLER : kind == KIND_BOARD ? BOARD : GPU; }

    public static boolean validKind(int kind) { return kind >= KIND_BOARD && kind <= KIND_GPU; }

    /** The number of turns of the whole job: every screw {@link #turns} times. */
    public static int steps(int kind) { return count(kind) * turns(kind); }

    // ---------- the order of the turns, as one number ----------
    /** The order {@code order[i]} = the screw that was turned i-th, packed 2 bits each into the low 16 bits, with the kind above them. */
    public static int encode(int kind, int[] order) {
        int v = 0;
        for (int i = 0; i < order.length && i < 8; i++) v |= (order[i] & 3) << (2 * i);
        return (kind << 16) | v;
    }

    public static int kindOf(int arg) { return (arg >>> 16) & 3; }

    /** The order of the turns of a place out of the number made by {@link #encode}. */
    public static int[] decode(int arg) {
        int kind = kindOf(arg);
        if (!validKind(kind)) return new int[0];
        int[] order = new int[steps(kind)];
        for (int i = 0; i < order.length; i++) order[i] = (arg >>> (2 * i)) & 3;
        return order;
    }

    /** True if this is exactly one full job: every screw of the place turned exactly {@link #turns} times, none that does not exist. */
    public static boolean valid(int kind, int[] order) {
        if (!validKind(kind) || order == null || order.length != steps(kind)) return false;
        int[] times = new int[4];
        for (int s : order) {
            if (s < 0 || s >= count(kind)) return false;
            times[s]++;
        }
        for (int s = 0; s < count(kind); s++) if (times[s] != turns(kind)) return false;
        return true;
    }

    /**
     * How well the cooler sits after the screws were turned in this order, 10..100. Two things cost points: a screw that is turned
     * further than the others (the cooler tilts: more than one turn ahead of the loosest screw) and two screws in a row that are not
     * opposite corners (the right way is a cross: a pair of opposite corners, then the other pair). The order must be {@link #valid}.
     */
    public static int coolerQuality(int[] order) {
        if (!valid(KIND_COOLER, order)) return 10;
        int[] level = new int[4];
        int q = 100;
        for (int i = 0; i < order.length; i++) {
            level[order[i]]++;
            int hi = 0, lo = Integer.MAX_VALUE;
            for (int l : level) { hi = Math.max(hi, l); lo = Math.min(lo, l); }
            if (hi - lo > 1) q -= 12;                                   // it tilts
            if (i % 2 == 1 && order[i] != 3 - order[i - 1]) q -= 8;     // a pair that is not opposite corners
        }
        return Math.max(10, Math.min(100, q));
    }

    /** Whether every screw of the place is tight in this mask. */
    public static boolean tight(int mask, int kind) { return (mask & mask(kind)) == mask(kind); }
}
