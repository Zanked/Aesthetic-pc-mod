package dev.cutemod.data;

import java.util.Random;

/**
 * Putting the processor into its socket (the realistic mode of a PC case). The chip has a marked corner, the socket has one too: the
 * marks have to be on top of each other. The player turns the chip (0..3 quarter turns away from the right way, the "offset") and lowers
 * the lever. A chip that sits right just locks in. A chip that is forced in the wrong way bends pins: a quarter turn away 1..3 of
 * them, upside down (offset 2) 2..5, and from {@link #DESTROY_AT} bent pins on the chip is ruined for good. Bent pins have to be
 * straightened one by one, and a pin can snap while it is bent back ({@link #SNAP_PERCENT} of the tries) and ruin the chip too.
 *
 * <p>Pure numbers, no Minecraft classes. The server rolls every dice (the screen cannot pick how many pins bend); the number the screen
 * sends is only what the player did: the offset of the chip, or "straighten one pin" ({@link #encodeStraighten}).
 */
public final class CpuSeat {
    private CpuSeat() {}

    /** The pins a socket has that can bend, and how many bent pins ruin the processor. */
    public static final int MAX_PINS = 8, DESTROY_AT = 4;
    /** The chance (percent) that a pin snaps when it is bent back. */
    public static final int SNAP_PERCENT = 5;
    private static final int STRAIGHTEN = 4;

    /** The action number for "the lever was lowered with the chip this far (0..3 quarter turns) from the right way". */
    public static int encodeSeat(int offset) { return offset & 3; }

    /** The action number for "straighten one bent pin". */
    public static int encodeStraighten() { return STRAIGHTEN; }

    public static boolean isStraighten(int arg) { return (arg & STRAIGHTEN) != 0; }

    public static int offsetOf(int arg) { return arg & 3; }

    /** How many pins bend when the chip is forced in with this offset (0 = it sits right: none). */
    public static int bentOnForce(int offset, Random rnd) {
        int o = offset & 3;
        if (o == 0) return 0;
        return o == 2 ? 2 + rnd.nextInt(4) : 1 + rnd.nextInt(3);
    }

    /** Whether this many bent pins ruin the chip. */
    public static boolean ruined(int bent) { return bent >= DESTROY_AT; }

    /** Whether a pin snaps on this try of bending it back. */
    public static boolean snaps(Random rnd) { return rnd.nextInt(100) < SNAP_PERCENT; }
}
