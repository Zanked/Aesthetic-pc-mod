package dev.cutemod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/** A darknet case or its key: no use of its own, a case is opened with a key at the NOIR app of a computer (see CaseServer). */
public class DarknetItem extends Item {
    private final String kind;

    public DarknetItem(Properties props, String kind) {
        super(props);
        this.kind = kind;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("cutemod.tip.darknet." + kind).withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable("cutemod.tip.darknet.where").withStyle(ChatFormatting.DARK_PURPLE));
    }
}
