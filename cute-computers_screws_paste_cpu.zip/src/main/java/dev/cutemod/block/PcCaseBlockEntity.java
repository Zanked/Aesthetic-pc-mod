package dev.cutemod.block;

import dev.cutemod.data.Build;
import dev.cutemod.data.CpuSeat;
import dev.cutemod.data.Screws;
import dev.cutemod.data.Thermal;
import dev.cutemod.data.PcHardware.Kind;
import dev.cutemod.item.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/**
 * The inside of a PC case that is being built: which parts are physically in it. Unlike an old computer (which always has a
 * "stock" part of every kind) a case starts EMPTY and every part has to be put in by hand, in an order that makes sense: the
 * board first, then the processor, memory, drive, card; the power supply goes in on its own.
 *
 * <p>What is inside is shown on the block itself (properties of {@link PcCaseBlock}, one model per part, see the blockstate), so
 * the player watches the PC being assembled through the glass. This class is the truth; {@link #syncState} copies it to the
 * block state. It extends {@link ComputerBlockEntity}, so the OS, the records and the shop treat it like any computer: the build
 * it gives out ({@link #build()}) is made of exactly the parts that are inside.
 *
 * <p>Saved as: Board, Cpu, Psu, Gpu, Disk, Modem (-1 = not installed, else the level in the ladders of {@link Build}),
 * Sticks (the size of the memory stick of each slot in GB, 0 = empty slot) and On (the PC is switched on).
 */
public class PcCaseBlockEntity extends ComputerBlockEntity {
    /** Why a part did not go in. */
    /** (New values go at the END: the build screen reads the result by its number.) */
    public enum Result { OK, SAME, NEED_BOARD, NEED_PSU, SOCKET, NO_SLOT, BOARD_SLOTS, BUSY, NEED_CPU, NOTHING, CPU_LOOSE, BENT, BROKEN }

    /** The places of the case, as the build screen names them (see {@link #remove}). The memory sticks are S_STICK + 0..3. */
    public static final int S_BOARD = 0, S_CPU = 1, S_PSU = 2, S_GPU = 3, S_DISK = 4, S_MODEM = 5, S_CABLES = 6, S_COOLER = 7, S_STICK = 10;

    private int board = -1, cpu = -1, psu = -1, gpu = -1, disk = -1, modem = -1;
    private final int[] sticks = new int[Build.MAX_SLOTS];
    private boolean cables;
    private boolean on;
    /** The cooler of the processor (-1 = none, else 1..3 = the level of the item, see {@link Thermal}). */
    private int cooler = -1;
    /** How good the thermal paste on the processor is (0 = none, 1..100 = the quality, see {@link Thermal#pasteQuality}); a cooler without paste works worse. It dries when the cooler or the processor comes out. */
    private int paste;
    /** Which screws are tight (see {@link Screws}): the board, the cooler and the video card have to be screwed down before the PC starts. */
    private int screws;
    /** How well the cooler sits (0..100, worked out from the order of its screws, see {@link Screws#coolerQuality}); a crooked cooler cools worse. */
    private int mount;
    /** Realistic mode: the screws, the paste and the processor are a mini-game. Simple mode does them by itself (at {@link Thermal#AUTO_QUALITY}). A case from before the screws is simple. */
    private boolean realistic = true;
    /** The processor is locked into its socket (realistic mode: the player does it with the lever, {@link CpuSeat}; the simple mode does it by itself). */
    private boolean cpuSeated;
    /** How many pins of the processor are bent (0 = none): the PC does not start until they are straightened. */
    private int bent;
    private final java.util.Random rng = new java.util.Random();
    /** A case saved before the coolers existed: it counts as a good tower cooler until a real one is put in. */
    private boolean legacyCooling;
    /** How neat the cables are (0..100, from the cable puzzle); air flows better through a tidy case. */
    private int tidy = Thermal.TIDY_DEFAULT;
    /** The RGB light of the case: mode 0 = off, 1 = one colour, 2 = breathing, 3 = rainbow, 4 = a wave of light running along the parts; colour 0..7 (the colours of the cases). */
    private int rgbMode, rgbColor;
    /** What the PC looked like the last time it started up: a different build makes the next start a first start (the POST screen). */
    private int postSig;
    /** The answer of the last install / remove (for the build screen, which tells the player why a part did not go in). Not saved. */
    private Result last = Result.OK;

    public PcCaseBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.PC_CASE.get(), pos, state);
    }

    // ---------- what is inside ----------
    public boolean hasBoard() { return board >= 0; }
    public boolean hasCpu() { return cpu >= 0; }
    public boolean hasPsu() { return psu >= 0; }
    public boolean hasDisk() { return disk >= 0; }
    public boolean hasModem() { return modem >= 0; }
    public boolean hasCables() { return cables; }
    public int gpuLevel() { return Math.max(0, gpu); }
    public boolean isOn() { return on; }
    public boolean hasCooler() { return cooler > 0; }
    public boolean hasPaste() { return paste > 0; }
    public int pasteQuality() { return paste; }
    public int mount() { return mount; }
    public int screwMask() { return screws; }
    public boolean isRealistic() { return realistic; }
    public boolean isCpuSeated() { return cpuSeated; }
    public int bentPins() { return bent; }
    /** The processor is in, locked and with straight pins: a cooler and paste can go on it. */
    public boolean cpuReady() { return cpu >= 0 && cpuSeated && bent == 0; }
    /** Whether memory slot {@code i} (0..3) has a stick in it. */
    public boolean hasStick(int i) { return i >= 0 && i < sticks.length && sticks[i] > 0; }
    public int coolerLevel() { return Math.max(0, cooler); }
    public int tidy() { return tidy; }
    public int rgbMode() { return rgbMode; }
    public int rgbColor() { return rgbColor; }

    // ---------- the heat ----------
    /** Full-load temperature of the processor (the stock one when there is none yet). */
    public int cpuTemp() { return Thermal.cpuTemp(Build.CPU_WATTS[Math.max(0, cpu)], coolerLevel(), legacyCooling && cooler < 0, tidy, paste, mount); }

    /** Full-load temperature of the video card (0 = there is none). */
    public int gpuTemp() { return Thermal.gpuTemp(Math.max(0, gpu), Build.GPU_WATTS[Math.max(0, gpu)], coolerLevel(), tidy); }

    /** 0 = the temperatures are fine, 1 = the processor is too hot to start, 2 = the video card is. */
    public int thermalFault() {
        if (Thermal.critical(cpuTemp())) return 1;
        if (Thermal.critical(gpuTemp())) return 2;
        return 0;
    }

    /** The cooler as the build screen sees it: -2 = the old factory cooling of a case from before the coolers, -1 = none, else the level. */
    public int coolerCode() { return cooler > 0 ? cooler : legacyCooling ? -2 : -1; }

    private int signature() {
        int h = java.util.Arrays.hashCode(new int[]{board, cpu, psu, gpu, disk, modem, cooler, sticks[0], sticks[1], sticks[2], sticks[3]});
        return h == 0 ? 1 : h;
    }

    /** True when this build never started up yet (or something was changed since): the next start shows the POST screen. */
    public boolean needsPost() { return postSig != signature(); }

    /** The PC started: this build has had its first start. */
    public void markPosted() {
        if (postSig == signature()) return;
        postSig = signature();
        setChanged();
    }

    /** The cable puzzle was solved with this score (0..100). A change switches the PC off, like every change. */
    public boolean setTidy(int value) {
        if (!cables) return false;
        int v = Math.max(0, Math.min(100, value));
        if (v == tidy) return true;
        tidy = v;
        on = false;
        changed();
        return true;
    }

    /** The RGB light: mode 0..4 and colour 0..7. */
    public void setRgb(int mode, int color) {
        int m = Math.max(0, Math.min(4, mode)), c = Math.max(0, Math.min(7, color));
        if (m == rgbMode && c == rgbColor) return;
        rgbMode = m;
        rgbColor = c;
        changed();
    }

    public int stickCount() {
        int n = 0;
        for (int s : sticks) if (s > 0) n++;
        return n;
    }

    /** The parts a PC cannot start without, as the names to show: the ones that are still missing (empty = it is ready). */
    public List<Component> missing() {
        List<Component> out = new ArrayList<>();
        if (!hasBoard()) out.add(Component.translatable("cutemod.case.part.board"));
        if (!hasCpu()) out.add(Component.translatable("cutemod.case.part.cpu"));
        if (stickCount() == 0) out.add(Component.translatable("cutemod.case.part.ram"));
        if (!hasDisk()) out.add(Component.translatable("cutemod.case.part.disk"));
        if (!hasPsu()) out.add(Component.translatable("cutemod.case.part.psu"));
        if (!hasCables()) out.add(Component.translatable("cutemod.case.part.cables"));
        if (cpu >= 0 && !cpuSeated) out.add(Component.translatable("cutemod.case.part.cpuseat"));
        if (cpu >= 0 && bent > 0) out.add(Component.translatable("cutemod.case.part.cpubent"));
        if (hasBoard() && !Screws.tight(screws, Screws.KIND_BOARD)) out.add(Component.translatable("cutemod.case.part.screws.board"));
        if (cooler > 0 && !Screws.tight(screws, Screws.KIND_COOLER)) out.add(Component.translatable("cutemod.case.part.screws.cooler"));
        if (gpu >= 0 && !Screws.tight(screws, Screws.KIND_GPU)) out.add(Component.translatable("cutemod.case.part.screws.gpu"));
        return out;
    }

    /** True when the PC has everything it needs to start (the video card and the modem are optional: the processor draws, the modem is for the internet). */
    public boolean isComplete() { return missing().isEmpty(); }

    /** The build of the parts that are inside: this is what the OS, the games and the shop see. */
    @Override
    public Build build() {
        Build b = Build.stock();
        b.cpu = Math.max(0, cpu);
        b.board = Math.max(0, board);
        b.psu = Math.max(0, psu);
        b.gpu = Math.max(0, gpu);
        b.disk = Math.max(0, disk);
        b.modem = modem;
        int slots = b.slots();
        for (int i = 0; i < Build.MAX_SLOTS; i++) b.sticks[i] = i < slots ? sticks[i] : 0;
        b.cased = true;                                  // a PC built by hand can overheat (see Thermal)
        b.cpuTemp = cpuTemp();
        b.gpuTemp = gpuTemp();
        return b;
    }

    // ---------- installing and taking out ----------
    /**
     * Tries to put a part in. On OK the part is in and {@code out[0]} is what came out of its place (a swapped part, as an item;
     * EMPTY if the place was free). A change always switches the PC off. {@code level} is the level in the ladders of
     * {@link Build}, for a memory stick its size in GB.
     */
    public Result install(Kind kind, int level, ItemStack[] out) { return last = installPart(kind, level, out); }

    private Result installPart(Kind kind, int level, ItemStack[] out) {
        out[0] = ItemStack.EMPTY;
        switch (kind) {
            case BOARD -> {
                if (level < 0 || level >= Build.BOARD_NAMES.length) return Result.SAME;
                if (level == board) return Result.SAME;
                if (cpu >= 0 && !Build.fits(Build.CPU_SOCKET[cpu], Build.BOARD_SOCKET[level])) return Result.SOCKET;
                if (stickCount() > Build.BOARD_SLOTS[level] || highestUsedSlot() >= Build.BOARD_SLOTS[level]) return Result.BOARD_SLOTS;
                if (board >= 0) out[0] = ModItems.partStack(Kind.BOARD, board);
                board = level;
                screws = realistic ? screws & ~Screws.BOARD : screws | Screws.BOARD;      // a new board lies loose until it is screwed down
            }
            case CPU -> {
                if (level < 0 || level >= Build.CPU_NAMES.length) return Result.SAME;
                if (board < 0) return Result.NEED_BOARD;
                if (level == cpu) return Result.SAME;
                if (!Build.fits(Build.CPU_SOCKET[level], Build.BOARD_SOCKET[board])) return Result.SOCKET;
                if (cpu >= 0) out[0] = ModItems.partStack(Kind.CPU, cpu);
                cpu = level;
                paste = 0;                                               // a new chip has no paste
                cpuSeated = !realistic;                                  // and lies loose on the socket until the lever is down
                bent = 0;
            }
            case PSU -> {
                if (level < 0 || level >= Build.PSU_NAMES.length) return Result.SAME;
                if (level == psu) return Result.SAME;
                if (psu >= 0) out[0] = ModItems.partStack(Kind.PSU, psu);
                psu = level;
            }
            case GPU -> {
                if (level < 1 || level >= dev.cutemod.data.PcHardware.GPU_NAMES.length) return Result.SAME;
                if (board < 0) return Result.NEED_BOARD;
                if (level == gpu) return Result.SAME;
                if (gpu >= 0) out[0] = ModItems.partStack(Kind.GPU, gpu);
                gpu = level;
                screws = realistic ? screws & ~Screws.GPU : screws | Screws.GPU;
            }
            case DISK -> {
                if (level < 0 || level >= dev.cutemod.data.PcHardware.DISK_GB.length) return Result.SAME;
                if (board < 0) return Result.NEED_BOARD;
                if (level == disk) return Result.SAME;
                if (disk >= 0) out[0] = ModItems.partStack(Kind.DISK, disk);
                disk = level;
            }
            case MODEM -> {
                if (level < dev.cutemod.data.PcHardware.MODEM_FIRST || level > dev.cutemod.data.PcHardware.MODEM_LAST) return Result.SAME;
                if (board < 0) return Result.NEED_BOARD;
                if (level == modem) return Result.SAME;
                if (modem >= 0) out[0] = ModItems.partStack(Kind.MODEM, modem);
                modem = level;
            }
            case RAM -> {                                           // level = the size of the stick in GB
                if (Build.stickPrice(level) < 0) return Result.SAME;
                if (board < 0) return Result.NEED_BOARD;
                int slot = -1;
                for (int i = 0; i < Build.BOARD_SLOTS[board] && slot < 0; i++) if (sticks[i] == 0) slot = i;
                if (slot < 0) return Result.NO_SLOT;
                sticks[slot] = level;
            }
        }
        on = false;
        changed();
        return Result.OK;
    }

    /**
     * Puts the cables in: they join the power supply to the board, so both have to be inside already. A change switches the PC off.
     */
    public Result installCables() { return last = installCablesInner(); }

    private Result installCablesInner() {
        if (board < 0) return Result.NEED_BOARD;
        if (psu < 0) return Result.NEED_PSU;
        if (cables) return Result.SAME;
        cables = true;
        tidy = Thermal.TIDY_DEFAULT;                     // plugged in quickly: the cable puzzle can make it neat
        on = false;
        changed();
        return Result.OK;
    }

    /** Puts a cooler on the processor (level 1..3). The processor has to be in already; a cooler that is in is swapped for it. A change switches the PC off. */
    public Result installCooler(int level, ItemStack[] out) { return last = installCoolerInner(level, out); }

    private Result installCoolerInner(int level, ItemStack[] out) {
        out[0] = ItemStack.EMPTY;
        if (level < Thermal.COOLER_FIRST || level > Thermal.COOLER_LAST) return Result.SAME;
        if (board < 0) return Result.NEED_BOARD;
        if (cpu < 0) return Result.NEED_CPU;
        if (!cpuReady()) return Result.CPU_LOOSE;
        if (level == cooler) return Result.SAME;
        if (cooler > 0) out[0] = ModItems.coolerStack(cooler);
        cooler = level;
        legacyCooling = false;
        screws &= ~Screws.COOLER;                                // a new cooler lies on the chip until it is screwed on
        mount = 0;
        if (!realistic) { screws |= Screws.COOLER; mount = Thermal.AUTO_QUALITY; }
        on = false;
        changed();
        return Result.OK;
    }

    /** Puts thermal paste on the processor the quick way (an average blob: {@link Thermal#AUTO_QUALITY}). */
    public Result applyPaste() { return applyPaste(Thermal.AUTO_QUALITY); }

    /**
     * Puts thermal paste of this quality (1..100, the mini-game works it out with {@link Thermal#pasteQuality}) on the processor: it has
     * to be in, with no cooler on it yet, and not have paste already (take the processor out to wipe it). A change switches the PC off.
     */
    public Result applyPaste(int quality) { return last = applyPasteInner(quality); }

    private Result applyPasteInner(int quality) {
        if (board < 0) return Result.NEED_BOARD;
        if (cpu < 0) return Result.NEED_CPU;
        if (cooler > 0) return Result.BUSY;
        if (!cpuReady()) return Result.CPU_LOOSE;
        if (paste > 0) return Result.SAME;
        paste = Math.max(1, Math.min(100, quality));
        on = false;
        changed();
        return Result.OK;
    }

    /**
     * Tightens the screws of one place ({@link Screws#KIND_BOARD}, {@link Screws#KIND_COOLER} or {@link Screws#KIND_GPU}); {@code order}
     * is the order the player turned them in, one full job (see {@link Screws#valid}). The cooler can be screwed again at any time (a better
     * order is a better mounting); the board and the card only once. A change switches the PC off.
     */
    public Result screw(int kind, int[] order) { return last = screwInner(kind, order); }

    private Result screwInner(int kind, int[] order) {
        if (!Screws.valid(kind, order)) return Result.NOTHING;
        switch (kind) {
            case Screws.KIND_BOARD -> {
                if (board < 0) return Result.NOTHING;
                if (Screws.tight(screws, kind)) return Result.SAME;
                screws |= Screws.BOARD;
            }
            case Screws.KIND_GPU -> {
                if (gpu < 0) return Result.NOTHING;
                if (Screws.tight(screws, kind)) return Result.SAME;
                screws |= Screws.GPU;
            }
            default -> {
                if (cooler < 1) return Result.NOTHING;
                screws |= Screws.COOLER;
                mount = Screws.coolerQuality(order);
            }
        }
        on = false;
        changed();
        return Result.OK;
    }

    /**
     * The processor and its pins (see {@link CpuSeat}): {@code arg} is either "the lever was lowered with the chip this many quarter
     * turns from the right way" or "straighten one bent pin". The server rolls the dice: a chip forced in the wrong way bends pins (BENT)
     * or is ruined (BROKEN: gone for good, no item comes back), a pin that is bent back can snap (BROKEN too). OK = it locked in (or a pin
     * is straight now; ask {@link #bentPins} how many are left). It needs no cooler on it. A change switches the PC off.
     */
    public Result seat(int arg) { return last = seatInner(arg); }

    private Result seatInner(int arg) {
        if (cpu < 0) return Result.NOTHING;
        if (cooler > 0) return Result.BUSY;                       // the cooler sits on it
        if (CpuSeat.isStraighten(arg)) {
            if (bent <= 0) return Result.SAME;
            if (CpuSeat.snaps(rng)) return ruinCpu();
            bent--;
            on = false;
            changed();
            return Result.OK;
        }
        if (cpuSeated) return Result.SAME;
        cpuSeated = true;
        bent = CpuSeat.bentOnForce(CpuSeat.offsetOf(arg), rng);
        if (CpuSeat.ruined(bent)) return ruinCpu();
        on = false;
        changed();
        return bent > 0 ? Result.BENT : Result.OK;
    }

    private Result ruinCpu() {
        cpu = -1;
        paste = 0;
        cpuSeated = false;
        bent = 0;
        on = false;
        changed();
        return Result.BROKEN;
    }

    /** Switches between the simple mode (the screws and the paste are done by themselves) and the realistic one. */
    public void setRealistic(boolean value) {
        if (value == realistic) return;
        realistic = value;
        if (!value) {                                          // simple: what is in is tightened now, a cooler keeps the mounting it has if that is better
            if (board >= 0) screws |= Screws.BOARD;
            if (gpu >= 0) screws |= Screws.GPU;
            if (cooler > 0) { screws |= Screws.COOLER; mount = Math.max(mount, Thermal.AUTO_QUALITY); }
            if (cpu >= 0) { cpuSeated = true; bent = 0; }       // and the chip is locked in with straight pins
        }
        changed();
    }

    /** A screw that has nothing to hold is not tight: keeps the mask in step with what is inside. */
    private void normalize() {
        if (board < 0) screws &= ~Screws.BOARD;
        if (gpu < 0) screws &= ~Screws.GPU;
        if (cooler <= 0) { screws &= ~Screws.COOLER; mount = 0; }
        if (cpu < 0) { cpuSeated = false; bent = 0; }
        bent = Math.max(0, Math.min(CpuSeat.MAX_PINS, bent));
        screws &= Screws.ALL;
    }

    /** How the last install / remove ended. */
    public Result lastResult() { return last; }

    /**
     * What is inside, for the build screen: board, cpu, psu, gpu, disk, modem (-1 = none), cables (0/1), on (0/1), then the four memory
     * sticks (GB, 0 = empty), then the cooler (see {@link #coolerCode}), how tidy the cables are (0..100), the RGB mode and the RGB colour,
     * the quality of the thermal paste (0 = none), the mask of the tight screws ({@link Screws}), how well the cooler sits (0..100)
     * and whether the case is in the realistic mode (0 / 1), whether the processor is locked in (0 / 1) and how many of its pins are bent.
     */
    public int[] snapshot() {
        int[] s = new int[12 + 10];
        s[0] = board; s[1] = cpu; s[2] = psu; s[3] = gpu; s[4] = disk; s[5] = modem;
        s[6] = cables ? 1 : 0;
        s[7] = on ? 1 : 0;
        for (int i = 0; i < Build.MAX_SLOTS; i++) s[8 + i] = sticks[i];
        s[12] = coolerCode();
        s[13] = tidy;
        s[14] = rgbMode;
        s[15] = rgbColor;
        s[16] = paste;                                   // thermal paste on the processor (0 = none, else the quality)
        s[17] = screws;
        s[18] = mount;
        s[19] = realistic ? 1 : 0;
        s[20] = cpuSeated ? 1 : 0;
        s[21] = bent;
        return s;
    }

    /**
     * Takes ONE chosen part out (the build screen lets the player pick it; {@link #removeLast} is the sneak shortcut). A part that others
     * sit on cannot come out: the board needs the processor, memory, card, drive, modem and cables out first, the power supply the cables.
     * On OK {@code out[0]} is the part as an item. A change always switches the PC off.
     */
    public Result remove(int slot, ItemStack[] out) { return last = removeInner(slot, out); }

    private Result removeInner(int slot, ItemStack[] out) {
        out[0] = ItemStack.EMPTY;
        switch (slot) {
            case S_BOARD -> {
                if (board < 0) return Result.SAME;
                if (cpu >= 0 || gpu >= 0 || disk >= 0 || modem >= 0 || cables || stickCount() > 0) return Result.BUSY;
                out[0] = ModItems.partStack(Kind.BOARD, board);
                board = -1;
            }
            case S_CPU -> {
                if (cpu < 0) return Result.SAME;
                if (cooler > 0) return Result.BUSY;                          // the cooler sits on it
                out[0] = ModItems.partStack(Kind.CPU, cpu);
                cpu = -1;
                paste = 0;
            }
            case S_PSU -> {
                if (psu < 0) return Result.SAME;
                if (cables) return Result.BUSY;
                out[0] = ModItems.partStack(Kind.PSU, psu);
                psu = -1;
            }
            case S_GPU -> {
                if (gpu < 0) return Result.SAME;
                out[0] = ModItems.partStack(Kind.GPU, gpu);
                gpu = -1;
            }
            case S_DISK -> {
                if (disk < 0) return Result.SAME;
                out[0] = ModItems.partStack(Kind.DISK, disk);
                disk = -1;
            }
            case S_MODEM -> {
                if (modem < 0) return Result.SAME;
                out[0] = ModItems.partStack(Kind.MODEM, modem);
                modem = -1;
            }
            case S_CABLES -> {
                if (!cables) return Result.SAME;
                out[0] = new ItemStack(ModItems.PC_CABLES.get());
                cables = false;
            }
            case S_COOLER -> {
                if (cooler < 0) return Result.SAME;
                out[0] = ModItems.coolerStack(cooler);
                cooler = -1;
                paste = 0;                                               // the paste stays on the cooler
            }
            default -> {
                int i = slot - S_STICK;
                if (i < 0 || i >= sticks.length || sticks[i] == 0) return Result.SAME;
                out[0] = ModItems.stickStack(sticks[i]);
                sticks[i] = 0;
            }
        }
        if (out[0].isEmpty()) return Result.SAME;
        on = false;
        changed();
        return Result.OK;
    }

    private int highestUsedSlot() {
        int hi = -1;
        for (int i = 0; i < sticks.length; i++) if (sticks[i] > 0) hi = i;
        return hi;
    }

    /**
     * Takes the part that went in last out of the case (the order of a real build, backwards: the card and the modem, the drive,
     * the memory, the cables, the processor, the board, the power supply) and gives it back as an item. EMPTY if the case is empty.
     */
    public ItemStack removeLast() {
        ItemStack out = ItemStack.EMPTY;
        if (modem >= 0) { out = ModItems.partStack(Kind.MODEM, modem); modem = -1; }
        else if (gpu >= 0) { out = ModItems.partStack(Kind.GPU, gpu); gpu = -1; }
        else if (disk >= 0) { out = ModItems.partStack(Kind.DISK, disk); disk = -1; }
        else if (highestUsedSlot() >= 0) { int i = highestUsedSlot(); out = ModItems.stickStack(sticks[i]); sticks[i] = 0; }
        else if (cables) { out = new ItemStack(ModItems.PC_CABLES.get()); cables = false; }
        else if (cooler > 0) { out = ModItems.coolerStack(cooler); cooler = -1; paste = 0; }
        else if (cpu >= 0) { out = ModItems.partStack(Kind.CPU, cpu); cpu = -1; paste = 0; }
        else if (board >= 0) { out = ModItems.partStack(Kind.BOARD, board); board = -1; }
        else if (psu >= 0) { out = ModItems.partStack(Kind.PSU, psu); psu = -1; }
        else return ItemStack.EMPTY;
        on = false;
        changed();
        return out;
    }

    /** Every part that is inside, as items (when the case is broken they drop). */
    public List<ItemStack> allParts() {
        List<ItemStack> out = new ArrayList<>();
        if (modem >= 0) out.add(ModItems.partStack(Kind.MODEM, modem));
        if (gpu >= 0) out.add(ModItems.partStack(Kind.GPU, gpu));
        if (disk >= 0) out.add(ModItems.partStack(Kind.DISK, disk));
        for (int s : sticks) if (s > 0) out.add(ModItems.stickStack(s));
        if (cables) out.add(new ItemStack(ModItems.PC_CABLES.get()));
        if (cooler > 0) out.add(ModItems.coolerStack(cooler));
        if (cpu >= 0) out.add(ModItems.partStack(Kind.CPU, cpu));
        if (board >= 0) out.add(ModItems.partStack(Kind.BOARD, board));
        if (psu >= 0) out.add(ModItems.partStack(Kind.PSU, psu));
        out.removeIf(ItemStack::isEmpty);
        return out;
    }

    /** Server side: switch the PC on or off. A PC that is not complete stays off. Returns whether it is on now. */
    public boolean setOn(boolean value) {
        boolean now = value && isComplete() && thermalFault() == 0;
        if (now != on) {
            on = now;
            changed();
        }
        return on;
    }

    // ---------- keeping the block in step ----------
    /** Copies what is inside to the block state (so the model shows it) and tells the clients. */
    private void changed() {
        normalize();
        setChanged();
        if (level == null) return;
        BlockState s = syncState(getBlockState());
        if (s != getBlockState()) level.setBlock(worldPosition, s, 3);
        else level.sendBlockUpdated(worldPosition, s, s, 3);
    }

    /** The given state of the case with the properties of what is inside. */
    public BlockState syncState(BlockState s) {
        if (!(s.getBlock() instanceof PcCaseBlock)) return s;
        return s.setValue(PcCaseBlock.BOARD, board >= 0)
                .setValue(PcCaseBlock.CPU, cpu >= 0)
                .setValue(PcCaseBlock.PSU, psu >= 0)
                .setValue(PcCaseBlock.DISK, disk >= 0)
                .setValue(PcCaseBlock.NET, modem >= 0)
                .setValue(PcCaseBlock.CABLES, cables)
                .setValue(PcCaseBlock.GPU, Math.max(0, gpu))
                .setValue(PcCaseBlock.RAM, stickCount())
                .setValue(PcCaseBlock.LIT, on);
    }

    // ---------- saving ----------
    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Board", board);
        tag.putInt("Cpu", cpu);
        tag.putInt("Psu", psu);
        tag.putInt("Gpu", gpu);
        tag.putInt("Disk", disk);
        tag.putInt("Modem", modem);
        tag.putBoolean("Cables", cables);
        tag.putIntArray("Sticks", sticks);
        tag.putBoolean("On", on);
        tag.putInt("Cooler", cooler);
        tag.putInt("PasteQ", paste);
        tag.putInt("Screws", screws);
        tag.putInt("Mount", mount);
        tag.putBoolean("Realistic", realistic);
        tag.putBoolean("CpuSeated", cpuSeated);
        tag.putInt("Bent", bent);
        tag.putBoolean("Legacy", legacyCooling);
        tag.putInt("Tidy", tidy);
        tag.putInt("RgbMode", rgbMode);
        tag.putInt("RgbColor", rgbColor);
        tag.putInt("PostSig", postSig);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        board = tag.contains("Board") ? tag.getInt("Board") : -1;
        cpu = tag.contains("Cpu") ? tag.getInt("Cpu") : -1;
        psu = tag.contains("Psu") ? tag.getInt("Psu") : -1;
        gpu = tag.contains("Gpu") ? tag.getInt("Gpu") : -1;
        disk = tag.contains("Disk") ? tag.getInt("Disk") : -1;
        modem = tag.contains("Modem") ? tag.getInt("Modem") : -1;
        // a case built before the cables existed keeps working: it counts as already wired (the cables are "in" when the board and the power supply are)
        cables = tag.contains("Cables") ? tag.getBoolean("Cables") : (board >= 0 && psu >= 0);
        int[] s = tag.getIntArray("Sticks");
        for (int i = 0; i < sticks.length; i++) sticks[i] = i < s.length ? s[i] : 0;
        on = tag.getBoolean("On");
        // a case saved before the coolers existed keeps its old cooling until a real cooler is put in
        cooler = tag.contains("Cooler") ? tag.getInt("Cooler") : -1;
        paste = tag.contains("PasteQ") ? Math.max(0, Math.min(100, tag.getInt("PasteQ"))) : tag.getBoolean("Paste") ? 100 : 0;   // a case from before the paste quality: paste was yes / no
        // a case from before the screws: everything that is in counts as screwed down, the cooler as perfectly mounted, and it stays in the simple mode
        screws = tag.contains("Screws") ? tag.getInt("Screws") & Screws.ALL : Screws.ALL;
        mount = tag.contains("Mount") ? Math.max(0, Math.min(100, tag.getInt("Mount"))) : 100;
        realistic = tag.contains("Realistic") && tag.getBoolean("Realistic");
        cpuSeated = tag.contains("CpuSeated") ? tag.getBoolean("CpuSeated") : true;             // a case from before the pins: the chip is locked in
        bent = tag.getInt("Bent");
        legacyCooling = tag.contains("Cooler") ? tag.getBoolean("Legacy") : true;
        tidy = tag.contains("Tidy") ? Math.max(0, Math.min(100, tag.getInt("Tidy"))) : Thermal.TIDY_LEGACY;
        rgbMode = Math.max(0, Math.min(4, tag.getInt("RgbMode")));
        rgbColor = Math.max(0, Math.min(7, tag.getInt("RgbColor")));
        postSig = tag.getInt("PostSig");
        normalize();                                     // (an old case has every screw "tight", also those that hold nothing)
    }
}
