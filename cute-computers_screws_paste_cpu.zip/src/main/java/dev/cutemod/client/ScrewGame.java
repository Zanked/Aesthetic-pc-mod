package dev.cutemod.client;

import com.mojang.math.Axis;
import dev.cutemod.data.Screws;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The screw mini-game of the PC build screen: the motherboard (4 screws), the cooler (4 screws, two turns each) or the video card
 * (2 screws). Click a screw to turn it one step (loose, snug, tight). The motherboard and the card only have to be screwed down;
 * the cooler has to be tightened the way a real one is: in a CROSS (opposite corners, then the other two) and evenly, two rounds.
 * A cooler that is tightened crooked sits badly and cools worse (see {@link Screws#coolerQuality}).
 *
 * <p>The screen does not send a score: it sends the ORDER the screws were turned in ({@link #arg()}), and the server works out the quality
 * itself. The number shown here at the end is only a preview of the same maths.
 */
final class ScrewGame {
    static final int AREA_W = 220, AREA_H = 150;
    private static final int HIT = 9;
    private static final int[] RING = {0xFF6A7088, 0xFFFFD86B, 0xFF8CF0A8};

    private final int kind;
    private final int count, turns;
    private final int[] level;
    private final long[] turnedAt;
    private final List<Integer> order = new ArrayList<>();
    private boolean done, cancelled;

    ScrewGame(int kind) {
        this.kind = kind;
        this.count = Screws.count(kind);
        this.turns = Screws.turns(kind);
        this.level = new int[count];
        this.turnedAt = new long[count];
    }

    boolean finished() { return done; }

    boolean cancelled() { return cancelled; }

    /** The order of the turns as the number the server reads (see {@link Screws#encode}). */
    int arg() { return Screws.encode(kind, orderArray()); }

    private int[] orderArray() {
        int[] o = new int[order.size()];
        for (int i = 0; i < o.length; i++) o[i] = order.get(i);
        return o;
    }

    private boolean allTight() { return order.size() == Screws.steps(kind); }

    private int quality() { return Screws.coolerQuality(orderArray()); }

    /** Whether one screw is turned further than the loosest one (the cooler would sit crooked). */
    private boolean crooked() {
        int hi = 0, lo = Integer.MAX_VALUE;
        for (int l : level) { hi = Math.max(hi, l); lo = Math.min(lo, l); }
        return kind == Screws.KIND_COOLER && hi - lo > 1;
    }

    // ---------- the places (relative to the top left corner of the overlay) ----------
    private int[] area() {
        if (kind == Screws.KIND_BOARD) return new int[]{50, 30, 120, 84};
        if (kind == Screws.KIND_COOLER) return new int[]{68, 30, 84, 84};
        return new int[]{40, 52, 140, 36};
    }

    /** The middle of a screw: the corners 0 top left, 1 top right, 2 bottom left, 3 bottom right (the card: the left and the right end). */
    private int[] pos(int i) {
        int[] a = area();
        if (kind == Screws.KIND_GPU) return new int[]{a[0] + (i == 0 ? 12 : a[2] - 12), a[1] + a[3] / 2};
        return new int[]{a[0] + ((i & 1) == 0 ? 14 : a[2] - 14), a[1] + (i < 2 ? 14 : a[3] - 14)};
    }

    // ---------- input ----------
    /** A click; returns true (the overlay covers the case and always uses it). */
    boolean mouseClicked(double mx, double my, int button, int x0, int y0) {
        if (button != 0) return true;
        int[] reset = {x0 + 14, y0 + 131, 56, 14}, back = {x0 + 76, y0 + 131, 56, 14}, ok = {x0 + 138, y0 + 131, 68, 14};
        if (hit(reset, mx, my)) { reset(); return true; }
        if (hit(back, mx, my)) { cancelled = true; return true; }
        if (hit(ok, mx, my)) {
            if (allTight()) done = true;
            return true;
        }
        for (int i = 0; i < count; i++) {
            int[] p = pos(i);
            double dx = mx - (x0 + p[0]), dy = my - (y0 + p[1]);
            if (dx * dx + dy * dy <= HIT * HIT) { turn(i); return true; }
        }
        return true;
    }

    private void turn(int i) {
        if (level[i] >= turns) return;
        level[i]++;
        order.add(i);
        turnedAt[i] = System.currentTimeMillis();
    }

    private void reset() {
        for (int i = 0; i < count; i++) level[i] = 0;
        order.clear();
    }

    private static boolean hit(int[] r, double x, double y) { return x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]; }

    // ---------- drawing ----------
    void render(GuiGraphics g, Font font, int x0, int y0, int mx, int my, float t, int acc) {
        fill(g, x0, y0, AREA_W, AREA_H, 0xF2100C22);
        outline(g, x0, y0, AREA_W, AREA_H, acc & 0x66FFFFFF | 0x66000000);
        String key = kind == Screws.KIND_COOLER ? "cooler" : kind == Screws.KIND_BOARD ? "board" : "gpu";
        txt(g, font, Component.translatable("cutemod.screw.title." + key).getString(), x0 + 8, y0 + 5, acc, 0.85f);
        String hint = Component.translatable("cutemod.screw.hint." + key).getString();
        txt(g, font, font.plainSubstrByWidth(hint, (int) ((AREA_W - 16) / 0.65f)), x0 + 8, y0 + 17, 0xFF8A8FB0, 0.65f);

        drawPart(g, font, x0, y0, t, acc);

        if (crooked() && (int) (t * 4) % 2 == 0) {
            String tilt = Component.translatable("cutemod.screw.tilt").getString();
            txt(g, font, tilt, x0 + AREA_W - 8 - (int) (font.width(tilt) * 0.8f), y0 + 118, 0xFFFF7A8A, 0.8f);
        }
        for (int i = 0; i < count; i++) drawScrew(g, x0, y0, i);

        if (allTight()) {
            boolean cooler = kind == Screws.KIND_COOLER;
            int q = quality();
            String msg = cooler ? Component.translatable("cutemod.screw.done.cooler", q).getString()
                    : Component.translatable("cutemod.screw.done.plain").getString();
            int c = !cooler || q >= 85 ? 0xFF8CF0A8 : q >= 60 ? 0xFFFFD86B : 0xFFFF9A3C;
            txt(g, font, msg, x0 + 8, y0 + 118, c, 0.8f);
        }

        button(g, font, x0 + 14, y0 + 131, 56, 14, Component.translatable("cutemod.cable.reset").getString(), mx, my, true, acc);
        button(g, font, x0 + 76, y0 + 131, 56, 14, Component.translatable("cutemod.cable.back").getString(), mx, my, true, acc);
        button(g, font, x0 + 138, y0 + 131, 68, 14, Component.translatable("cutemod.cable.done").getString(), mx, my, allTight(), acc);
    }

    private void drawPart(GuiGraphics g, Font font, int x0, int y0, float t, int acc) {
        int[] a = area();
        int x = x0 + a[0], y = y0 + a[1], w = a[2], h = a[3];
        if (kind == Screws.KIND_BOARD) {
            fill(g, x, y, w, h, 0xFF1F3A55);
            outline(g, x, y, w, h, 0xFF4A5078);
            fill(g, x + 36, y + 24, 30, 30, 0xFF3A4060);                                   // the socket
            outline(g, x + 36, y + 24, 30, 30, 0xFF8A90A8);
            for (int i = 0; i < 4; i++) fill(g, x + 80 + i * 8, y + 14, 5, 52, 0xFF2A2F4C);   // the memory slots
            fill(g, x + 14, y + h - 22, 70, 8, 0xFF2A2F4C);                                 // the card slot
        } else if (kind == Screws.KIND_COOLER) {
            fill(g, x, y, w, h, 0xFF2A2F4C);
            outline(g, x, y, w, h, 0xFF4A5078);
            fan(g, x + w / 2, y + h / 2, 26, t * 160f, acc & 0x00FFFFFF | 0xF2000000, 0xFF1A1632);
        } else {
            fill(g, x, y, w, h, 0xFF30354F);
            outline(g, x, y, w, h, 0xFF4A5078);
            fill(g, x + 2, y + 2, w - 4, 2, acc & 0x00FFFFFF | 0xCC000000);
            fan(g, x + 48, y + h / 2, 12, t * 220f, acc & 0x00FFFFFF | 0xF2000000, 0xFF1A1632);
            fan(g, x + 92, y + h / 2, 12, t * 220f, acc & 0x00FFFFFF | 0xF2000000, 0xFF1A1632);
        }
    }

    private void drawScrew(GuiGraphics g, int x0, int y0, int i) {
        int[] p = pos(i);
        int cx = x0 + p[0], cy = y0 + p[1];
        int ring = RING[Math.min(2, turns == 1 ? level[i] * 2 : level[i])];
        circle(g, cx, cy, 8, ring);
        circle(g, cx, cy, 6, 0xFF0E0B1E);
        float since = (System.currentTimeMillis() - turnedAt[i]) / 260f;
        float e = since >= 1f ? 1f : 1f - (1f - since) * (1f - since);
        float angle = level[i] * 90f - (1f - e) * 90f;                                       // the screw turns a quarter every click
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0f);
        g.pose().mulPose(Axis.ZP.rotationDegrees(angle));
        g.fill(-4, -1, 5, 1, level[i] > 0 ? 0xFFFFFFFF : 0xFF8A8FB0);
        g.fill(-1, -4, 1, 5, level[i] > 0 ? 0xFFFFFFFF : 0xFF8A8FB0);
        g.pose().popPose();
        for (int k = 0; k < turns; k++) {                                                    // one pip for every turn it still needs
            fill(g, cx - turns * 2 + k * 4, cy + 11, 3, 2, k < level[i] ? RING[Math.min(2, turns == 1 ? 2 : k + 1)] : 0xFF3A3F5C);
        }
    }

    private static void fan(GuiGraphics g, int cx, int cy, int r, float angle, int blade, int bg) {
        circle(g, cx, cy, r, bg);
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0f);
        g.pose().mulPose(Axis.ZP.rotationDegrees(angle));
        g.fill(-r + 2, -1, r - 1, 1, blade);
        g.fill(-1, -r + 2, 1, r - 1, blade);
        g.pose().popPose();
        circle(g, cx, cy, 2, blade);
    }

    private static void circle(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.round(Math.sqrt(r * r - dy * dy + 0.5));
            g.fill(cx - w, cy + dy, cx + w, cy + dy + 1, argb);
        }
    }

    private static void button(GuiGraphics g, Font font, int x, int y, int w, int h, String label, int mx, int my, boolean enabled, int acc) {
        boolean hov = enabled && hit(new int[]{x, y, w, h}, mx, my);
        fill(g, x, y, w, h, enabled ? (hov ? acc : 0xFF2A2548) : 0xFF1A1630);
        fill(g, x + 1, y + 1, w - 2, h - 2, enabled ? (hov ? 0xFF3A2F5E : 0xFF1B1636) : 0xFF120F24);
        txt(g, font, label, x + w / 2 - (int) (font.width(label) * 0.8f / 2), y + 4, enabled ? 0xFFFFFFFF : 0xFF5A5878, 0.8f);
    }

    private static void fill(GuiGraphics g, int x, int y, int w, int h, int argb) { g.fill(x, y, x + w, y + h, argb); }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + 1, argb);
        g.fill(x, y + h - 1, x + w, y + h, argb);
        g.fill(x, y, x + 1, y + h, argb);
        g.fill(x + w - 1, y, x + w, y + h, argb);
    }

    private static void txt(GuiGraphics g, Font font, String s, int x, int y, int argb, float scale) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, s, 0, 0, argb, false);
        g.pose().popPose();
    }
}
