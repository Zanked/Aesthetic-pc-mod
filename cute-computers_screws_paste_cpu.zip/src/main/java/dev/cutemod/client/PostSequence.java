package dev.cutemod.client;

import dev.cutemod.data.Build;
import dev.cutemod.data.PcHardware;
import dev.cutemod.data.Thermal;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The start-up check (POST) of a PC that starts for the first time, or after a part was changed: a little BIOS screen that checks the
 * parts one after another, line by line, with a beep for each, and then says whether the PC runs well, runs hot (throttles) or was
 * stopped by the thermal protection because it is too hot. It only READS what the server sent ({@code st} of the build screen),
 * nothing is decided here: the server has already decided whether the PC started (see PcBuildServer).
 */
final class PostSequence {
    static final int OK = 1, WARN = 2, FAIL = 3, HEAD = 0, END_OK = 4, END_WARN = 5, END_FAIL = 6, NOTE = 7;
    private static final long LINE_MS = 240L;
    private static final int W = 220, H = 150;

    /** One line: its text, and how it ended (OK / WARN / FAIL, or a header / the verdict / a small note). */
    record Line(String text, int kind) {}

    private final List<Line> lines = new ArrayList<>();
    private final boolean fail;
    private final long start;
    private long skippedAt = -1;

    PostSequence(int[] st, boolean fail, int fault, long now) {
        this.fail = fail;
        this.start = now;
        int cpu = Math.max(0, st[1]), gpu = Math.max(0, st[3]), disk = Math.max(0, st[4]);
        int cooler = st.length > 12 ? st[12] : -1;
        int tidy = st.length > 13 ? st[13] : Thermal.TIDY_LEGACY;
        int ramGb = 0, sticks = 0;
        for (int i = 8; i < 12; i++) if (st[i] > 0) { ramGb += st[i]; sticks++; }

        lines.add(new Line(tr("cutemod.post.head"), HEAD));
        lines.add(new Line(tr("cutemod.post.cpu", Build.CPU_NAMES[cpu], Build.CPU_CORES[cpu], String.valueOf(Build.CPU_GHZ[cpu])), OK));
        lines.add(new Line(tr("cutemod.post.ram", ramGb, sticks), OK));
        lines.add(new Line(gpu > 0 ? tr("cutemod.post.gpu", PcHardware.GPU_NAMES[gpu], PcHardware.VRAM_GB[gpu])
                : tr("cutemod.post.igpu", PcHardware.GPU_NAMES[0]), OK));
        int gb = PcHardware.DISK_GB[disk];
        String kind = tr("cutemod.post.disk." + (PcHardware.diskKind(disk) == 0 ? "hdd" : PcHardware.diskKind(disk) == 1 ? "ssd" : "nvme"));
        lines.add(new Line(tr("cutemod.post.disk", gb >= 1000 ? (gb / 1000) + " TB" : gb + " GB", kind), OK));
        int modem = st[5];
        lines.add(modem >= 1 ? new Line(tr("cutemod.post.net", PcHardware.MODEM_NAMES[modem], PcHardware.MODEM_MBPS[modem]), OK)
                : new Line(tr("cutemod.post.nonet"), WARN));

        int coolerLevel = Math.max(0, cooler);
        int pasteQ = st.length > 16 ? st[16] : 0;
        int mount = st.length > 18 ? st[18] : 100;
        boolean paste = pasteQ > 0;
        int cpuT = Thermal.cpuTemp(Build.CPU_WATTS[cpu], coolerLevel, cooler == -2, tidy, pasteQ, mount);
        int gpuT = Thermal.gpuTemp(gpu, Build.GPU_WATTS[gpu], coolerLevel, tidy);
        String coolerName = cooler > 0 ? Thermal.coolerName(cooler) : cooler == -2 ? tr("cutemod.post.fan.legacy") : tr("cutemod.post.fan.none");
        String temps = gpu > 0 ? tr("cutemod.post.fan", coolerName, cpuT, gpuT) : tr("cutemod.post.fan.cpu", coolerName, cpuT);
        if (cooler > 0 && !paste) temps += tr("cutemod.post.nopaste");
        int hot = Math.max(cpuT, gpuT);
        lines.add(new Line(temps, hot >= Thermal.CRIT ? FAIL : hot >= Thermal.THROTTLE || (cooler == -1 && cpuT >= 75) ? WARN : OK));

        int load = Build.BASE_WATTS + Build.CPU_WATTS[cpu] + Build.GPU_WATTS[gpu];
        int supply = st[2] >= 0 ? Build.PSU_WATTS[st[2]] : 0;
        lines.add(new Line(tr("cutemod.post.pwr", supply, load), load > supply ? WARN : OK));
        lines.add(new Line(tr("cutemod.post.cables", tidy), tidy >= 70 ? OK : WARN));

        if (fail) {
            lines.add(new Line(tr(fault == 2 ? "cutemod.post.fail.gpu" : "cutemod.post.fail.cpu", fault == 2 ? gpuT : cpuT), END_FAIL));
            lines.add(new Line(tr("cutemod.post.fail.hint"), NOTE));
        } else if (hot >= Thermal.THROTTLE) {
            lines.add(new Line(tr("cutemod.post.hot", hot), END_WARN));
            lines.add(new Line(tr("cutemod.post.hot.hint"), NOTE));
        } else {
            lines.add(new Line(tr(load > supply ? "cutemod.post.weak" : "cutemod.post.good"), load > supply ? END_WARN : END_OK));
        }
    }

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    boolean isFail() { return fail; }

    int size() { return lines.size(); }

    Line line(int i) { return lines.get(i); }

    /** How many lines are on the screen at this moment. */
    int shown(long now) {
        if (skippedAt >= 0) return lines.size();
        return (int) Math.min(lines.size(), 1 + (now - start) / LINE_MS);
    }

    boolean finished(long now) { return shown(now) >= lines.size(); }

    /** A click while the lines are still coming: show them all at once. */
    void skip(long now) { if (skippedAt < 0) skippedAt = now; }

    /** A good start closes itself a moment after the last line; a failed one waits for a click. */
    boolean expired(long now) {
        if (fail || !finished(now)) return false;
        long end = skippedAt >= 0 ? skippedAt + 900L : start + lines.size() * LINE_MS + 1500L;
        return now >= end;
    }

    void render(GuiGraphics g, Font font, int x0, int y0, long now, int acc) {
        g.fill(x0, y0, x0 + W, y0 + H, 0xF5050A08);
        g.fill(x0, y0, x0 + W, y0 + 1, acc);
        g.fill(x0, y0 + H - 1, x0 + W, y0 + H, acc);
        g.fill(x0, y0, x0 + 1, y0 + H, acc);
        g.fill(x0 + W - 1, y0, x0 + W, y0 + H, acc);
        int n = shown(now);
        int y = y0 + 8;
        for (int i = 0; i < n; i++) {
            Line l = lines.get(i);
            int color = switch (l.kind()) {
                case HEAD -> acc;
                case END_OK -> 0xFF8CF0A8;
                case END_WARN -> 0xFFFFD86B;
                case END_FAIL -> 0xFFFF6B7A;
                case NOTE -> 0xFF8A8FB0;
                default -> 0xFFB8F0C8;
            };
            if (i == lines.size() - 1 || l.kind() == END_FAIL || l.kind() == NOTE) y += 3;
            String text = font.plainSubstrByWidth(l.text(), (int) ((W - 62) / 0.72f));
            scaled(g, font, text, x0 + 8, y, color, 0.72f);
            if (l.kind() == OK || l.kind() == WARN || l.kind() == FAIL) {
                String tag = tr(l.kind() == OK ? "cutemod.post.tag.ok" : l.kind() == WARN ? "cutemod.post.tag.warn" : "cutemod.post.tag.fail");
                int tc = l.kind() == OK ? 0xFF8CF0A8 : l.kind() == WARN ? 0xFFFFD86B : 0xFFFF6B7A;
                scaled(g, font, tag, x0 + W - 8 - (int) (font.width(tag) * 0.72f), y, tc, 0.72f);
            }
            y += 10;
        }
        if (n < lines.size() && (now / 300) % 2 == 0) g.fill(x0 + 8, y, x0 + 13, y + 7, 0xFFB8F0C8);       // the blinking cursor
        if (finished(now)) scaled(g, font, tr("cutemod.post.click"), x0 + W - 8 - (int) (font.width(tr("cutemod.post.click")) * 0.6f), y0 + H - 11, 0xFF6A7088, 0.6f);
    }

    private static void scaled(GuiGraphics g, Font font, String s, int x, int y, int argb, float scale) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, s, 0, 0, argb, false);
        g.pose().popPose();
    }
}
