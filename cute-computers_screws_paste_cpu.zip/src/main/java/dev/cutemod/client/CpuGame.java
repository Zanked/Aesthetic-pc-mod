package dev.cutemod.client;

import dev.cutemod.data.CpuSeat;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.Random;

/**
 * The processor mini-game of the PC build screen, two modes.
 * <p>SEAT: the chip lies on its socket, turned some way. Both have a marked corner (a little triangle); turn the chip (the Turn button, or
 * click the chip) until the marks are on top of each other, then lower the lever. A chip that is not turned right and is forced in bends pins
 * (or is ruined, see {@link CpuSeat}); the server decides how many.
 * <p>REPAIR: the chip is in but pins are bent. Click a bent pin to straighten it: every try can snap the pin and ruin the chip.
 *
 * <p>The screen only says what the player did ({@link #takeRequest}: the offset of the chip, or "straighten a pin"); the dice are rolled by the server.
 */
final class CpuGame {
    static final int AREA_W = 220, AREA_H = 150;
    private static final int SX = 56, SY = 30, SS = 84;                  // the socket
    private static final int CX = 66, CY = 40, CS = 64;                  // the chip on it

    private final boolean repair;
    private int rot;                                                      // the corner of the chip that is marked: 0 top left, 1 top right, 2 bottom right, 3 bottom left
    private boolean seated;
    private int bent;
    private boolean cancelled;
    private int pending = -1;
    private long lastStraighten;
    private long turnedAt;

    CpuGame(boolean repair, int bent, Random rnd) {
        this.repair = repair;
        this.bent = bent;
        this.seated = repair;
        this.rot = repair ? 0 : 1 + rnd.nextInt(3);                      // never solved at the start
    }

    boolean isSeat() { return !repair; }

    boolean cancelled() { return cancelled; }

    /** The pins are straight and the chip is locked in (the repair is over). */
    boolean ready() { return repair && seated && bent == 0; }

    /** The state of the case, as the server sent it (the repair follows the pins that are still bent). */
    void sync(boolean seated, int bent) {
        if (!repair) return;
        this.seated = seated;
        this.bent = bent;
    }

    /** What the screen has to send now (see {@link CpuSeat}), or -1 if the player did nothing. */
    int takeRequest() {
        int r = pending;
        pending = -1;
        return r;
    }

    // ---------- input ----------
    boolean mouseClicked(double mx, double my, int button, int x0, int y0) {
        if (button != 0) return true;
        int[] back = {x0 + 76, y0 + 131, 56, 14};
        if (hit(back, mx, my)) { cancelled = true; return true; }
        if (!repair) {
            int[] turn = {x0 + 14, y0 + 131, 56, 14}, lever = {x0 + 138, y0 + 131, 68, 14}, chip = {x0 + CX, y0 + CY, CS, CS};
            if (hit(turn, mx, my) || hit(chip, mx, my)) { turnChip(); return true; }
            if (hit(lever, mx, my)) { pending = CpuSeat.encodeSeat(rot); return true; }
            return true;
        }
        long now = System.currentTimeMillis();
        for (int i = 0; i < bent; i++) {
            int[] p = pin(i);
            if (hit(new int[]{x0 + p[0] - 6, y0 + p[1] - 4, 22, 30}, mx, my) && now - lastStraighten > 250) {
                lastStraighten = now;
                pending = CpuSeat.encodeStraighten();
                return true;
            }
        }
        return true;
    }

    private void turnChip() {
        rot = (rot + 1) & 3;
        turnedAt = System.currentTimeMillis();
    }

    private static boolean hit(int[] r, double x, double y) { return x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]; }

    /** The top of a pin of the repair view (8 pins in two rows). */
    private static int[] pin(int i) { return new int[]{40 + (i % 4) * 36 + 16, 44 + (i / 4) * 40}; }

    // ---------- drawing ----------
    void render(GuiGraphics g, Font font, int x0, int y0, int mx, int my, float t, int acc) {
        fill(g, x0, y0, AREA_W, AREA_H, 0xF2100C22);
        outline(g, x0, y0, AREA_W, AREA_H, acc & 0x66FFFFFF | 0x66000000);
        String key = repair ? "repair" : "seat";
        txt(g, font, Component.translatable("cutemod.cpu.title." + key).getString(), x0 + 8, y0 + 5, acc, 0.85f);
        String hint = Component.translatable("cutemod.cpu.hint." + key).getString();
        txt(g, font, font.plainSubstrByWidth(hint, (int) ((AREA_W - 16) / 0.65f)), x0 + 8, y0 + 17, 0xFF8A8FB0, 0.65f);

        if (repair) drawRepair(g, font, x0, y0, t);
        else drawSeat(g, font, x0, y0, t);

        if (!repair) button(g, font, x0 + 14, y0 + 131, 56, 14, Component.translatable("cutemod.cpu.turn").getString(), mx, my, true, acc);
        button(g, font, x0 + 76, y0 + 131, 56, 14, Component.translatable("cutemod.cable.back").getString(), mx, my, true, acc);
        if (!repair) button(g, font, x0 + 138, y0 + 131, 68, 14, Component.translatable("cutemod.cpu.lever").getString(), mx, my, true, acc);
    }

    private void drawSeat(GuiGraphics g, Font font, int x0, int y0, float t) {
        int sx = x0 + SX, sy = y0 + SY;
        fill(g, sx, sy, SS, SS, 0xFF262A44);                                              // the socket
        outline(g, sx, sy, SS, SS, 0xFF4A5078);
        for (int i = 0; i < 8; i++) {                                                      // its holes
            fill(g, sx + 4 + i * 10, sy + 3, 2, 2, 0xFFD8C27A);
            fill(g, sx + 4 + i * 10, sy + SS - 5, 2, 2, 0xFFD8C27A);
            fill(g, sx + 3, sy + 4 + i * 10, 2, 2, 0xFFD8C27A);
            fill(g, sx + SS - 5, sy + 4 + i * 10, 2, 2, 0xFFD8C27A);
        }
        triangle(g, sx + 2, sy + 2, 0, 9, 0xFF7FF0C8);                                     // the mark of the socket: top left
        fill(g, sx + SS + 6, sy + 6, 6, SS - 12, 0xFF3A4060);                              // the lever (it goes down when the chip sits)
        fill(g, sx + SS + 4, sy + 6, 10, 6, 0xFFB8C0D8);

        int cx = x0 + CX, cy = y0 + CY;
        float since = (System.currentTimeMillis() - turnedAt) / 200f;
        int lift = since >= 1f ? 0 : (int) Math.round(Math.sin(since * Math.PI) * 3);       // the chip lifts a little when it is turned
        g.fillGradient(cx, cy - lift, cx + CS, cy + CS - lift, 0xFFB4BAD0, 0xFF6E7592);
        outline(g, cx, cy - lift, CS, CS, 0xFF8A90A8);
        fill(g, cx + 18, cy + 18 - lift, CS - 36, CS - 36, 0xFF3A4060);
        txt(g, font, "CPU", cx + CS / 2 - 8, cy + CS / 2 - 4 - lift, 0xFFE8E4F5, 0.8f);
        triangle(g, cx + 2, cy + 2 - lift, rot, 9, rot == 0 ? 0xFF7FF0C8 : 0xFFFFD86B);    // the mark of the chip: where it is now
        if (rot == 0 && (int) (t * 3) % 2 == 0) outline(g, cx - 1, cy - 1 - lift, CS + 2, CS + 2, 0xFF7FF0C8);   // it matches: the chip blinks
    }

    private void drawRepair(GuiGraphics g, Font font, int x0, int y0, float t) {
        fill(g, x0 + 30, y0 + 34, 160, 92, 0xFF262A44);
        outline(g, x0 + 30, y0 + 34, 160, 92, 0xFF4A5078);
        for (int i = 0; i < CpuSeat.MAX_PINS; i++) {
            int px = x0 + pin(i)[0], py = y0 + pin(i)[1];
            if (i < bent) {                                                                // a bent pin: it leans over in steps
                int c = 0xFFFF9A3C;
                fill(g, px, py + 14, 4, 8, c);
                fill(g, px + 3, py + 7, 4, 8, c);
                fill(g, px + 6, py, 4, 8, c);
                if ((int) (t * 3) % 2 == 0) outline(g, px - 3, py - 3, 16, 28, 0x88FFB45A);
            } else {
                fill(g, px, py, 4, 22, 0xFFD8C27A);
            }
        }
        String left = Component.translatable("cutemod.cpu.bent", bent).getString();
        txt(g, font, left, x0 + 8, y0 + 118, bent > 0 ? 0xFFFFB45A : 0xFF8CF0A8, 0.8f);
    }

    /** A little triangle of a corner: 0 top left, 1 top right, 2 bottom right, 3 bottom left (x, y = the top left of the square it sits in). */
    private static void triangle(GuiGraphics g, int x, int y, int corner, int size, int argb) {
        for (int k = 0; k < size; k++) {
            int w = size - k;
            switch (corner) {
                case 0 -> g.fill(x, y + k, x + w, y + k + 1, argb);
                case 1 -> g.fill(x + CS - 4 - w, y + k, x + CS - 4, y + k + 1, argb);
                case 2 -> g.fill(x + CS - 4 - w, y + CS - 4 - k - 1, x + CS - 4, y + CS - 4 - k, argb);
                default -> g.fill(x, y + CS - 4 - k - 1, x + w, y + CS - 4 - k, argb);
            }
        }
    }

    private static void button(GuiGraphics g, Font font, int x, int y, int w, int h, String label, int mx, int my, boolean enabled, int acc) {
        boolean hov = enabled && hit(new int[]{x, y, w, h}, mx, my);
        fill(g, x, y, w, h, enabled ? (hov ? acc : 0xFF2A2548) : 0xFF1A1630);
        fill(g, x + 1, y + 1, w - 2, h - 2, enabled ? (hov ? 0xFF3A2F5E : 0xFF1B1636) : 0xFF120F24);
        txt(g, font, label, x + w / 2 - (int) (font.width(label) * 0.8f / 2), y + 4, enabled ? 0xFFFFFFFF : 0xFF5A5878, 0.8f);
    }

    private static void fill(GuiGraphics g, int x, int y, int w, int h, int argb) { g.fill(x, y, x + w, y + h, argb); }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + 1, argb);
        g.fill(x, y + h - 1, x + w, y + h, argb);
        g.fill(x, y, x + 1, y + h, argb);
        g.fill(x + w - 1, y, x + w, y + h, argb);
    }

    private static void txt(GuiGraphics g, Font font, String s, int x, int y, int argb, float scale) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, s, 0, 0, argb, false);
        g.pose().popPose();
    }
}
