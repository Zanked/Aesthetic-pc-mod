package dev.cutemod.client;

import dev.cutemod.data.Thermal;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * The thermal paste mini-game of the PC build screen: HOLD the mouse button to squeeze paste out of the tube onto the processor, LET GO
 * when the blob is the size of a pea (the pea on the right shows the size). Too little leaves the chip bare in places, too much
 * insulates a little. The paste does not flow evenly (it pulses), so the timing is a small skill.
 *
 * <p>The screen sends only how much was squeezed out ({@link #amount()}, 0..100); the server works out the quality with
 * {@link Thermal#pasteQuality}. The percentage shown here at the end is only a preview of the same maths.
 */
final class PasteGame {
    static final int AREA_W = 220, AREA_H = 150;
    private static final float PER_UNIT = 0.2f;                 // the radius of the blob grows this many pixels for every unit of paste

    private enum Phase { READY, SQUEEZE, PLACED }

    private Phase phase = Phase.READY;
    private double amount;
    private long lastMs, placedAt;
    private boolean cancelled;

    boolean cancelled() { return cancelled; }

    /** The blob is placed and has been shown for a moment: the screen can send it now. */
    boolean finished() { return phase == Phase.PLACED && System.currentTimeMillis() - placedAt > 1100; }

    /** How much paste was squeezed out, 0..100. */
    int amount() { return (int) Math.round(Math.max(0, Math.min(100, amount))); }

    // ---------- input ----------
    boolean mouseClicked(double mx, double my, int button, int x0, int y0) {
        if (button != 0) return true;
        int[] back = {x0 + 14, y0 + 131, 56, 14};
        if (hit(back, mx, my)) { cancelled = true; return true; }
        if (phase == Phase.READY) {
            phase = Phase.SQUEEZE;
            amount = 0;
            lastMs = System.currentTimeMillis();
        }
        return true;
    }

    boolean mouseReleased() {
        if (phase == Phase.SQUEEZE) {
            advance(System.currentTimeMillis());                  // count the paste up to the very moment the button went up
            if (phase == Phase.SQUEEZE) place();
        }
        return true;
    }

    /** The paste flows while the button is held: it pulses, 14..38 units a second. */
    private void advance(long now) {
        if (phase != Phase.SQUEEZE) return;
        double dt = Math.max(0, Math.min(100, now - lastMs)) / 1000.0;
        amount += (26.0 + 12.0 * Math.sin(now / 1000.0 * 4.1)) * dt;
        lastMs = now;
        if (amount >= 100) { amount = 100; place(); }
    }

    private void place() {
        phase = Phase.PLACED;
        placedAt = System.currentTimeMillis();
    }

    private static boolean hit(int[] r, double x, double y) { return x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]; }

    // ---------- drawing ----------
    void render(GuiGraphics g, Font font, int x0, int y0, int mx, int my, float t, int acc) {
        long now = System.currentTimeMillis();
        advance(now);

        fill(g, x0, y0, AREA_W, AREA_H, 0xF2100C22);
        outline(g, x0, y0, AREA_W, AREA_H, acc & 0x66FFFFFF | 0x66000000);
        txt(g, font, Component.translatable("cutemod.paste.title").getString(), x0 + 8, y0 + 5, acc, 0.85f);
        String hint = Component.translatable("cutemod.paste.hint").getString();
        txt(g, font, font.plainSubstrByWidth(hint, (int) ((AREA_W - 16) / 0.65f)), x0 + 8, y0 + 17, 0xFF8A8FB0, 0.65f);

        // the processor: the metal lid on the board
        int dx = x0 + 34, dy = y0 + 32, ds = 76;
        fill(g, dx - 3, dy - 3, ds + 6, ds + 6, 0xFF262A44);
        outline(g, dx - 3, dy - 3, ds + 6, ds + 6, 0xFF4A5078);
        g.fillGradient(dx, dy, dx + ds, dy + ds, 0xFFB4BAD0, 0xFF6E7592);
        outline(g, dx, dy, ds, ds, 0xFF8A90A8);
        int cx = dx + ds / 2, cy = dy + ds / 2;

        float r = 1f + (float) amount * PER_UNIT;
        if (phase == Phase.SQUEEZE) {                                                       // the tube and the string of paste
            fill(g, cx - 5, dy - 16, 10, 10, 0xFF8A90A8);
            fill(g, cx - 2, dy - 7, 4, 7, 0xFFB8C0D8);
            fill(g, cx - 1, dy, 2, Math.max(1, cy - dy), 0xFFD8DEF0);
        }
        if (phase != Phase.READY) {
            float spread = phase == Phase.PLACED ? 1.12f : 1f;                              // a placed blob settles a little wider
            circle(g, cx, cy, Math.round(r * spread) + 1, 0xFF8A90A8);
            circle(g, cx, cy, Math.round(r * spread), 0xFFE6EAF6);
            circle(g, cx - Math.round(r * 0.3f), cy - Math.round(r * 0.3f), Math.max(1, Math.round(r * 0.3f)), 0xFFFFFFFF);
        } else if ((int) (t * 2) % 2 == 0) {
            txt(g, font, "+", cx - 2, cy - 4, 0x88FFFFFF, 1.1f);
        }

        // the pea: that is how big the blob should be
        int px = x0 + 166, py = y0 + 70;
        float pr = 1f + Thermal.PASTE_IDEAL * PER_UNIT;
        circle(g, px, py, Math.round(pr) + 1, 0xFF3C7A4E);
        circle(g, px, py, Math.round(pr), 0xFF7FD08A);
        circle(g, px - 3, py - 3, 2, 0xFFD8F8DC);
        String pea = Component.translatable("cutemod.paste.pea").getString();
        txt(g, font, pea, px - (int) (font.width(pea) * 0.75f / 2), py + 16, 0xFF8CF0A8, 0.75f);

        if (phase == Phase.PLACED) {
            int q = Thermal.pasteQuality(amount());
            String verdict = Component.translatable(q >= 95 ? "cutemod.paste.great" : amount() < Thermal.PASTE_IDEAL ? "cutemod.paste.low" : "cutemod.paste.high").getString();
            int c = q >= 85 ? 0xFF8CF0A8 : q >= 60 ? 0xFFFFD86B : 0xFFFF9A3C;
            txt(g, font, Component.translatable("cutemod.paste.result", q).getString() + "  " + verdict, x0 + 8, y0 + 118, c, 0.8f);
        }

        button(g, font, x0 + 14, y0 + 131, 56, 14, Component.translatable("cutemod.cable.back").getString(), mx, my, true, acc);
    }

    private static void circle(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.round(Math.sqrt(r * r - dy * dy + 0.5));
            g.fill(cx - w, cy + dy, cx + w, cy + dy + 1, argb);
        }
    }

    private static void button(GuiGraphics g, Font font, int x, int y, int w, int h, String label, int mx, int my, boolean enabled, int acc) {
        boolean hov = enabled && hit(new int[]{x, y, w, h}, mx, my);
        fill(g, x, y, w, h, enabled ? (hov ? acc : 0xFF2A2548) : 0xFF1A1630);
        fill(g, x + 1, y + 1, w - 2, h - 2, enabled ? (hov ? 0xFF3A2F5E : 0xFF1B1636) : 0xFF120F24);
        txt(g, font, label, x + w / 2 - (int) (font.width(label) * 0.8f / 2), y + 4, enabled ? 0xFFFFFFFF : 0xFF5A5878, 0.8f);
    }

    private static void fill(GuiGraphics g, int x, int y, int w, int h, int argb) { g.fill(x, y, x + w, y + h, argb); }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + 1, argb);
        g.fill(x, y + h - 1, x + w, y + h, argb);
        g.fill(x, y, x + 1, y + h, argb);
        g.fill(x + w - 1, y, x + w, y + h, argb);
    }

    private static void txt(GuiGraphics g, Font font, String s, int x, int y, int argb, float scale) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, s, 0, 0, argb, false);
        g.pose().popPose();
    }
}
