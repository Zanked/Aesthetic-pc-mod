#!/usr/bin/env python3
"""
Removes the flicker ("z-fighting") of the PC case models: two surfaces in the SAME place are drawn one over the other and the video card
shows now the one, now the other. Run from the repo root (it can be run again: every model gets a "zfix" mark once).

  * the glowing overlays (glow_*, the cooler glow) are moved 0.03 px away from the part they lie on (they were 0.02 px away or even
    exactly in the same plane with their own back face), and the renderer draws its light 0.06 px further (see PcCaseRgbRenderer)
  * the memory sticks are 0.03 px wider than their slots on the board, the cable ribbons 0.03 px thicker than the shroud they lie in,
    the shrouds of the graphics cards 0.03 px higher than the PCIe slot
  * the mid case: the top plate no longer runs under the front bar (both drew the same faces)
"""
import json, glob, os

MOD = "src/main/resources/assets/cutemod/models/block"
D = 0.03


def load(n): return json.load(open(f"{MOD}/{n}.json"))


def save(n, d): json.dump(d, open(f"{MOD}/{n}.json", "w"), indent=1)


def edit(name, fn):
    path = f"{MOD}/{name}.json"
    if not os.path.exists(path): return
    d = load(name)
    if d.get("zfix"): return
    for e in d.get("elements", []): fn(e)
    d["zfix"] = True
    save(name, d)


def shift(axis):
    def f(e):
        e["from"][axis] = round(e["from"][axis] + D, 4); e["to"][axis] = round(e["to"][axis] + D, 4)
    return f


def grow(axes, only=None):
    def f(e):
        if only and e["name"] not in only: return
        for a in axes:
            e["from"][a] = round(e["from"][a] - D, 4); e["to"][a] = round(e["to"][a] + D, 4)
    return f


def raise_top(only):
    def f(e):
        if e["name"] in only: e["to"][1] = round(e["to"][1] + D, 4)
    return f


for size in ("mini", "mid"):
    for n in ("glow_base", "glow_base_yellow"):
        def glow(e, size=size):
            if e["name"] == "io" and size == "mini": shift(0)(e)             # the panel of the mini case is on its side (x)
            else: shift(2)(e)
        edit(f"pc_case_{size}_{n}", glow)
    for i in range(4):
        edit(f"pc_case_{size}_glow_ram{i}", shift(2))
        edit(f"pc_case_{size}_ram{i}", grow((0,), {"stick"}))
        edit(f"pc_case_{size}_glow_gpu{i + 1}", shift(2))
    edit(f"pc_case_{size}_glow_net", shift(2))
    edit(f"pc_case_{size}_cooler_glow", shift(2))
for i in range(1, 5): edit(f"pc_case_mini_gpu{i}", raise_top({"shroud"}))
edit("pc_case_mini_cable", grow((1,), {"ribbon", "ribbon_low"}))


def mid_top(e):
    if e["name"] == "top": e["to"][2] = 13.412
for n in ("pc_case_mid_body", "pc_case_mid_item"): edit(n, mid_top)
print("z-fighting fixed")
