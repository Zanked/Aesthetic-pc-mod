#!/usr/bin/env python3
"""The words of the screws, the thermal paste mini-game and the build mode of the PC build screen (ScrewGame, PasteGame, PcBuildScreen).
Run:  python3 tools/make_pc_screws_lang.py     (it adds the keys to en_us.json and ru_ru.json right after cutemod.build.paste.off and
turns the text of cutemod.build.paste.on into a quality; running it again does nothing)"""
import json, os

LANG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "cutemod", "lang")
ANCHOR = '  "cutemod.build.paste.off"'

EN = {
 "cutemod.case.part.screws.board": "motherboard screws",
 "cutemod.case.part.screws.cooler": "cooler screws",
 "cutemod.case.part.screws.gpu": "video card screws",
 "cutemod.case.nothing": "Nothing to do there",
 "cutemod.build.paste.done": "Thermal paste put on: %d%%",
 "cutemod.build.screw.board": "Board",
 "cutemod.build.screw.cooler": "Cooler",
 "cutemod.build.screw.cooler.q": "Cooler %d%%",
 "cutemod.build.screw.gpu": "Card",
 "cutemod.build.screw.tip": "Screw it down",
 "cutemod.build.screw.tip.board": "The motherboard has to be screwed down before the PC starts",
 "cutemod.build.screw.tip.cooler": "Tighten in a cross (opposite corners), evenly: a crooked cooler cools worse. You can redo it any time",
 "cutemod.build.screw.tip.gpu": "The video card has to be screwed in before the PC starts",
 "cutemod.build.mode.real": "Realistic",
 "cutemod.build.mode.simple": "Simple",
 "cutemod.build.mode.tip": "How the case is built (click to switch)",
 "cutemod.build.mode.tip.real": "Realistic: the screws and the thermal paste are mini-games",
 "cutemod.build.mode.tip.simple": "Simple: they are done for you (a little worse than a perfect job)",
 "cutemod.screw.nothing": "Put that part in the case first",
 "cutemod.screw.already": "Already screwed down",
 "cutemod.screw.toast.board": "Motherboard screwed down",
 "cutemod.screw.toast.gpu": "Video card screwed in",
 "cutemod.screw.toast.cooler": "Cooler mounted: sits at %d%%",
 "cutemod.screw.title.board": "Screw down the motherboard",
 "cutemod.screw.title.cooler": "Mount the cooler",
 "cutemod.screw.title.gpu": "Screw in the video card",
 "cutemod.screw.hint.board": "Click every screw",
 "cutemod.screw.hint.cooler": "Tighten in a cross: opposite corners, two rounds, evenly",
 "cutemod.screw.hint.gpu": "Click both screws",
 "cutemod.screw.tilt": "Crooked!",
 "cutemod.screw.done.cooler": "The cooler sits at %d%%",
 "cutemod.screw.done.plain": "All tight",
 "cutemod.paste.title": "Thermal paste",
 "cutemod.paste.hint": "Hold to squeeze, let go at the size of a pea",
 "cutemod.paste.pea": "a pea",
 "cutemod.paste.great": "Perfect!",
 "cutemod.paste.low": "Too little",
 "cutemod.paste.high": "Too much",
 "cutemod.paste.result": "Paste: %d%%",
}
EN_ON = "Thermal paste: %d%%"

# the processor and its pins (CpuGame)
EN_CPU = {
 "cutemod.case.part.cpuseat": "processor locked in",
 "cutemod.case.part.cpubent": "processor pins straightened",
 "cutemod.case.cpu_loose": "Lock the processor in first (and straighten its pins)",
 "cutemod.build.screw.cpu": "CPU",
 "cutemod.build.cpu.tip": "The processor",
 "cutemod.build.screw.tip.cpu": "Turn it so the marks match and lower the lever. Forced in the wrong way it bends pins, and with too many the chip is ruined",
 "cutemod.cpu.title.seat": "Lock the processor in",
 "cutemod.cpu.title.repair": "Straighten the pins",
 "cutemod.cpu.hint.seat": "Match the two triangles, then lower the lever",
 "cutemod.cpu.hint.repair": "Click a bent pin to bend it back (a pin can snap!)",
 "cutemod.cpu.turn": "Turn",
 "cutemod.cpu.lever": "Lower lever",
 "cutemod.cpu.bent": "Bent pins: %d",
 "cutemod.cpu.already": "The processor is already locked in",
 "cutemod.cpu.toast.seated": "Processor locked in",
 "cutemod.cpu.toast.bent": "Wrong way! %d pins are bent",
 "cutemod.cpu.toast.broken": "The pins snapped: the processor is ruined",
 "cutemod.cpu.toast.straight": "Pin straightened, %d left",
 "cutemod.cpu.toast.done": "All pins are straight",
}

RU = {
 "cutemod.case.part.screws.board": "винты материнской платы",
 "cutemod.case.part.screws.cooler": "винты кулера",
 "cutemod.case.part.screws.gpu": "винты видеокарты",
 "cutemod.case.nothing": "Тут нечего делать",
 "cutemod.build.paste.done": "Термопаста нанесена: %d%%",
 "cutemod.build.screw.board": "Плата",
 "cutemod.build.screw.cooler": "Кулер",
 "cutemod.build.screw.cooler.q": "Кулер %d%%",
 "cutemod.build.screw.gpu": "Карта",
 "cutemod.build.screw.tip": "Закрутить винты",
 "cutemod.build.screw.tip.board": "Материнскую плату нужно закрутить, иначе ПК не запустится",
 "cutemod.build.screw.tip.cooler": "Затягивай крест-накрест (противоположные углы) и равномерно: кривой кулер охлаждает хуже. Переделать можно в любой момент",
 "cutemod.build.screw.tip.gpu": "Видеокарту нужно закрутить, иначе ПК не запустится",
 "cutemod.build.mode.real": "Реалистично",
 "cutemod.build.mode.simple": "Просто",
 "cutemod.build.mode.tip": "Как собирается корпус (нажми, чтобы переключить)",
 "cutemod.build.mode.tip.real": "Реалистично: винты и термопаста — мини-игры",
 "cutemod.build.mode.tip.simple": "Просто: всё делается само (чуть хуже, чем идеальная работа)",
 "cutemod.screw.nothing": "Сначала поставь эту деталь в корпус",
 "cutemod.screw.already": "Уже закручено",
 "cutemod.screw.toast.board": "Материнская плата закручена",
 "cutemod.screw.toast.gpu": "Видеокарта закручена",
 "cutemod.screw.toast.cooler": "Кулер установлен: посадка %d%%",
 "cutemod.screw.title.board": "Закрути материнскую плату",
 "cutemod.screw.title.cooler": "Установи кулер",
 "cutemod.screw.title.gpu": "Закрути видеокарту",
 "cutemod.screw.hint.board": "Нажми на каждый винт",
 "cutemod.screw.hint.cooler": "Затягивай крест-накрест: противоположные углы, два круга, равномерно",
 "cutemod.screw.hint.gpu": "Нажми на оба винта",
 "cutemod.screw.tilt": "Перекос!",
 "cutemod.screw.done.cooler": "Кулер сидит на %d%%",
 "cutemod.screw.done.plain": "Всё затянуто",
 "cutemod.paste.title": "Термопаста",
 "cutemod.paste.hint": "Зажми, чтобы выдавить; отпусти, когда капля с горошину",
 "cutemod.paste.pea": "горошина",
 "cutemod.paste.great": "Идеально!",
 "cutemod.paste.low": "Маловато",
 "cutemod.paste.high": "Многовато",
 "cutemod.paste.result": "Паста: %d%%",
}
RU_ON = "Термопаста: %d%%"

RU_CPU = {
 "cutemod.case.part.cpuseat": "процессор в сокете",
 "cutemod.case.part.cpubent": "выпрямленные ножки процессора",
 "cutemod.case.cpu_loose": "Сначала зафиксируй процессор (и выпрями его ножки)",
 "cutemod.build.screw.cpu": "ЦП",
 "cutemod.build.cpu.tip": "Процессор",
 "cutemod.build.screw.tip.cpu": "Поверни так, чтобы метки совпали, и опусти рычаг. Если вдавить не той стороной, ножки погнутся, а если их много — чип погибнет",
 "cutemod.cpu.title.seat": "Установи процессор",
 "cutemod.cpu.title.repair": "Выпрями ножки",
 "cutemod.cpu.hint.seat": "Совмести два треугольника и опусти рычаг",
 "cutemod.cpu.hint.repair": "Нажми на погнутую ножку, чтобы выпрямить (она может сломаться!)",
 "cutemod.cpu.turn": "Повернуть",
 "cutemod.cpu.lever": "Опустить",
 "cutemod.cpu.bent": "Погнуто ножек: %d",
 "cutemod.cpu.already": "Процессор уже в сокете",
 "cutemod.cpu.toast.seated": "Процессор установлен",
 "cutemod.cpu.toast.bent": "Не той стороной! Погнуто ножек: %d",
 "cutemod.cpu.toast.broken": "Ножки сломались: процессор погиб",
 "cutemod.cpu.toast.straight": "Ножка выпрямлена, осталось %d",
 "cutemod.cpu.toast.done": "Все ножки выпрямлены",
}


def patch(name, groups, new_on):
    path = os.path.join(LANG, name)
    text = open(path, encoding="utf-8").read()
    lines = text.split("\n")
    at = next(i for i, l in enumerate(lines) if l.startswith(ANCHOR))
    added = 0
    for words in groups:
        first = next(iter(words))
        if any(l.startswith("  " + json.dumps(first) + ":") for l in lines):
            continue
        block = ['  %s: %s,' % (json.dumps(k), json.dumps(v, ensure_ascii=False)) for k, v in words.items()]
        lines[at + 1:at + 1] = block
        added += len(block)
    on = next(i for i, l in enumerate(lines) if l.startswith('  "cutemod.build.paste.on"'))
    lines[on] = '  "cutemod.build.paste.on": %s,' % json.dumps(new_on, ensure_ascii=False)
    out = "\n".join(lines)
    json.loads(out)                                    # it must still be valid JSON
    open(path, "w", encoding="utf-8", newline="\n").write(out)
    print(name, ": added", added, "keys" if added else "keys (already there)")


patch("en_us.json", [EN, EN_CPU], EN_ON)
patch("ru_ru.json", [RU, RU_CPU], RU_ON)
