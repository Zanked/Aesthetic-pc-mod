import dev.cutemod.data.Build;
import dev.cutemod.data.CpuSeat;
import dev.cutemod.data.Screws;
import dev.cutemod.data.Thermal;

/**
 * A self-contained check of the pure rules of the PC build (thermal paste, cooler mounting, screws). No Minecraft, no JUnit:
 *   javac -d /tmp/chk src/main/java/dev/cutemod/data/{Build,PcHardware,Thermal,Screws,CpuSeat}.java tools/BuildLogicCheck.java
 *   java -cp /tmp/chk BuildLogicCheck
 */
public class BuildLogicCheck {
    static int fails = 0, checks = 0;

    static void eq(String what, Object got, Object want) {
        checks++;
        if (!got.equals(want)) { fails++; System.out.println("FAIL " + what + ": got " + got + ", want " + want); }
    }

    static void ok(String what, boolean cond) { eq(what, cond, true); }

    /** The formula of the old Thermal (before paste quality and mounting), copied here to prove nothing changed for old cases. */
    static int oldCpuTemp(int w, int cooler, boolean legacy, int tidy, boolean paste) {
        double air = 1.0 + 0.15 * (Math.max(0, Math.min(100, tidy)) - 50) / 50.0 + Thermal.COOLER_AIR[Math.max(0, Math.min(3, cooler))];
        double cap = cooler > 0 ? Thermal.COOLER_CAP[Math.min(cooler, 3)] * (paste ? 1.0 : 0.85) : legacy ? 240 : 80;
        return (int) Math.round(28 + 62.0 * w / (cap * air));
    }

    public static void main(String[] a) {
        // ---- nothing changes for an old case (paste yes/no, perfect mounting) ----
        for (int cpu = 0; cpu < Build.CPU_WATTS.length; cpu++)
            for (int cooler = 0; cooler <= 3; cooler++)
                for (int tidy = 0; tidy <= 100; tidy += 25)
                    for (boolean paste : new boolean[]{false, true})
                        for (boolean legacy : new boolean[]{false, true})
                            eq("old " + cpu + "/" + cooler + "/" + tidy + "/" + paste + "/" + legacy,
                                    Thermal.cpuTemp(Build.CPU_WATTS[cpu], cooler, legacy, tidy, paste),
                                    oldCpuTemp(Build.CPU_WATTS[cpu], cooler, legacy, tidy, paste));

        // ---- the numbers of the plan: Panda Ultra X (125 W) under a Cute Air 92 (cap 140), tidy 50 ----
        int w = Build.CPU_WATTS[4];
        eq("ideal paste + ideal screws", Thermal.cpuTemp(w, 1, false, 50, 100, 100), 83);
        eq("no paste, ideal screws", Thermal.cpuTemp(w, 1, false, 50, 0, 100), 93);
        eq("auto quality both", Thermal.cpuTemp(w, 1, false, 50, Thermal.AUTO_QUALITY, Thermal.AUTO_QUALITY), 87);
        eq("worst paste + worst screws", Thermal.cpuTemp(w, 1, false, 50, 0, 0), 99);
        ok("worst case still starts (< CRIT) but throttles hard", Thermal.cpuTemp(w, 1, false, 50, 0, 0) < Thermal.CRIT
                && Thermal.steps(Thermal.cpuTemp(w, 1, false, 50, 0, 0)) == 2);
        // a part that does not have a real cooler ignores paste and mounting
        eq("no cooler ignores paste", Thermal.cpuTemp(65, 0, true, 50, 0, 0), Thermal.cpuTemp(65, 0, true, 50, 100, 100));

        // ---- thermal paste ----
        eq("paste 0", Thermal.pasteQuality(0), 0);
        eq("paste half pea", Thermal.pasteQuality(20), 50);
        eq("paste ideal", Thermal.pasteQuality(Thermal.PASTE_IDEAL), 100);
        eq("paste a bit much", Thermal.pasteQuality(45), 94);
        eq("paste too much", Thermal.pasteQuality(100), 30);
        eq("paste clamps low", Thermal.pasteQuality(-5), 0);
        eq("paste clamps high", Thermal.pasteQuality(1000), 30);
        int prev = -1;
        for (int x = 0; x <= Thermal.PASTE_IDEAL; x++) { ok("paste rises to the pea " + x, Thermal.pasteQuality(x) >= prev); prev = Thermal.pasteQuality(x); }
        prev = 101;
        for (int x = Thermal.PASTE_IDEAL; x <= 100; x++) { ok("paste falls after the pea " + x, Thermal.pasteQuality(x) <= prev); prev = Thermal.pasteQuality(x); }
        eq("factor none", Thermal.pasteFactor(0), Thermal.NO_PASTE);
        eq("factor perfect", Thermal.pasteFactor(100), 1.0);
        eq("factor over 100 is capped", Thermal.pasteFactor(500), 1.0);
        eq("mount worst", Thermal.mountFactor(0), Thermal.MOUNT_MIN);
        eq("mount best", Thermal.mountFactor(100), 1.0);
        eq("mount clamps", Thermal.mountFactor(-9), Thermal.MOUNT_MIN);

        // ---- the screws: masks and kinds ----
        eq("masks do not overlap", Screws.BOARD & Screws.COOLER | Screws.BOARD & Screws.GPU | Screws.COOLER & Screws.GPU, 0);
        eq("masks make ALL", Screws.BOARD | Screws.COOLER | Screws.GPU, Screws.ALL);
        eq("board steps", Screws.steps(Screws.KIND_BOARD), 4);
        eq("cooler steps", Screws.steps(Screws.KIND_COOLER), 8);
        eq("gpu steps", Screws.steps(Screws.KIND_GPU), 2);
        ok("tight board", Screws.tight(Screws.ALL, Screws.KIND_BOARD));
        ok("loose cooler", !Screws.tight(Screws.BOARD | Screws.GPU, Screws.KIND_COOLER));
        ok("half cooler is loose", !Screws.tight(0x30, Screws.KIND_COOLER));

        // ---- the cooler quality ----
        eq("cross a", Screws.coolerQuality(new int[]{0, 3, 1, 2, 0, 3, 1, 2}), 100);
        eq("cross b", Screws.coolerQuality(new int[]{1, 2, 0, 3, 1, 2, 0, 3}), 100);
        eq("cross, first pass then the second", Screws.coolerQuality(new int[]{0, 3, 1, 2, 2, 1, 3, 0}), 100);
        eq("round the square", Screws.coolerQuality(new int[]{0, 1, 2, 3, 0, 1, 2, 3}), 68);
        eq("one screw all the way", Screws.coolerQuality(new int[]{0, 0, 1, 1, 2, 2, 3, 3}), 10);
        eq("invalid order is the worst", Screws.coolerQuality(new int[]{0, 0, 0, 0, 0, 0, 0, 0}), 10);
        eq("too short is the worst", Screws.coolerQuality(new int[]{0, 3, 1, 2}), 10);

        // every possible order of the eight turns: all valid, all in range, round trip of the number, only a few perfect
        int[] pool = {0, 0, 1, 1, 2, 2, 3, 3};
        int[] count = new int[2];
        int[] best = {0};
        permute(pool, 0, count, best);
        eq("number of distinct orders", count[0], 2520);
        ok("a perfect order exists", best[0] == 100);
        ok("some orders are perfect", count[1] > 0 && count[1] < 2520 / 4);

        // ---- validity and the number the order travels in ----
        ok("board 4 ok", Screws.valid(Screws.KIND_BOARD, new int[]{0, 1, 2, 3}));
        ok("board order is free", Screws.valid(Screws.KIND_BOARD, new int[]{3, 1, 0, 2}));
        ok("board twice the same", !Screws.valid(Screws.KIND_BOARD, new int[]{0, 0, 2, 3}));
        ok("board missing one", !Screws.valid(Screws.KIND_BOARD, new int[]{0, 1, 2}));
        ok("gpu has two screws", Screws.valid(Screws.KIND_GPU, new int[]{1, 0}));
        ok("gpu has no screw 2", !Screws.valid(Screws.KIND_GPU, new int[]{2, 0}));
        ok("cooler needs two turns each", !Screws.valid(Screws.KIND_COOLER, new int[]{0, 1, 2, 3, 0, 1, 2, 2}));
        ok("bad kind", !Screws.valid(3, new int[]{0, 1}));
        ok("null order", !Screws.valid(Screws.KIND_BOARD, null));
        for (int kind = 0; kind < 3; kind++) {
            int n = Screws.steps(kind);
            int[] o = new int[n];
            for (int i = 0; i < n; i++) o[i] = i % Screws.count(kind);
            int arg = Screws.encode(kind, o);
            eq("kind survives " + kind, Screws.kindOf(arg), kind);
            ok("round trip " + kind, java.util.Arrays.equals(Screws.decode(arg), o));
            ok("the round trip is valid " + kind, Screws.valid(kind, Screws.decode(arg)));
        }
        eq("an arg with a bad kind decodes to nothing", Screws.decode(3 << 16).length, 0);

        // ---- the processor and its pins ----
        for (int off = 0; off < 4; off++) {
            eq("seat arg round trip " + off, CpuSeat.offsetOf(CpuSeat.encodeSeat(off)), off);
            ok("a seat arg is not a straighten " + off, !CpuSeat.isStraighten(CpuSeat.encodeSeat(off)));
        }
        ok("straighten is its own action", CpuSeat.isStraighten(CpuSeat.encodeStraighten()));
        eq("a chip that sits right bends nothing", CpuSeat.bentOnForce(0, new java.util.Random(1)), 0);
        java.util.Random rnd = new java.util.Random(42);
        int[][] seen = new int[4][8];
        int ruinedUpsideDown = 0, ruinedQuarter = 0, n = 100000;
        for (int i = 0; i < n; i++) {
            for (int off = 1; off < 4; off++) {
                int bent = CpuSeat.bentOnForce(off, rnd);
                seen[off][bent]++;
                if (CpuSeat.ruined(bent)) { if (off == 2) ruinedUpsideDown++; else ruinedQuarter++; }
            }
        }
        ok("a quarter turn bends 1..3 pins", seen[1][0] == 0 && seen[1][4] == 0 && seen[1][1] > 0 && seen[1][3] > 0 && seen[3][1] > 0 && seen[3][3] > 0);
        ok("upside down bends 2..5 pins", seen[2][0] == 0 && seen[2][1] == 0 && seen[2][2] > 0 && seen[2][5] > 0 && seen[2][6] == 0);
        eq("a quarter turn never ruins the chip", ruinedQuarter, 0);
        ok("upside down ruins the chip about half the time", Math.abs(ruinedUpsideDown / (double) n - 0.5) < 0.01);
        int snaps = 0;
        for (int i = 0; i < n; i++) if (CpuSeat.snaps(rnd)) snaps++;
        ok("a pin snaps about " + CpuSeat.SNAP_PERCENT + " percent of the tries", Math.abs(snaps / (double) n - CpuSeat.SNAP_PERCENT / 100.0) < 0.005);
        ok("the chip is ruined from " + CpuSeat.DESTROY_AT + " pins", !CpuSeat.ruined(CpuSeat.DESTROY_AT - 1) && CpuSeat.ruined(CpuSeat.DESTROY_AT));
        ok("a socket has more pins than ruin a chip", CpuSeat.MAX_PINS > CpuSeat.DESTROY_AT);

        System.out.println(checks + " checks, " + fails + " failed");
        if (fails > 0) System.exit(1);
    }

    static void permute(int[] p, int k, int[] count, int[] best) {
        if (k == p.length) {
            // the same multiset in a different order is counted once: dedupe by only counting sorted-by-first-occurrence orders
            if (!seen.add(java.util.Arrays.toString(p))) return;
            count[0]++;
            int[] o = p.clone();
            if (!Screws.valid(Screws.KIND_COOLER, o)) { System.out.println("FAIL invalid " + java.util.Arrays.toString(o)); fails++; return; }
            int q = Screws.coolerQuality(o);
            if (q < 10 || q > 100) { System.out.println("FAIL range " + q); fails++; }
            best[0] = Math.max(best[0], q);
            if (q == 100) count[1]++;
            int[] back = Screws.decode(Screws.encode(Screws.KIND_COOLER, o));
            if (!java.util.Arrays.equals(back, o)) { System.out.println("FAIL round trip " + java.util.Arrays.toString(o)); fails++; }
            return;
        }
        for (int i = k; i < p.length; i++) {
            int t = p[k]; p[k] = p[i]; p[i] = t;
            permute(p, k + 1, count, best);
            t = p[k]; p[k] = p[i]; p[i] = t;
        }
    }

    static final java.util.Set<String> seen = new java.util.HashSet<>();
}
