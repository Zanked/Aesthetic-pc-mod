package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

/**
 * Music player: little songs played on note-block sounds. Each track has a lead voice and a bass voice,
 * stored as {note, length} pairs (note 0..24 = note block range, -1 = rest, length in units).
 * Music plays while the player is open.
 */
public class MusicApp extends App {
    // note numbers: C4 = 6, D4 = 8, E4 = 10, F4 = 11, G4 = 13, A4 = 15, B4 = 17, C5 = 18, D5 = 20, E5 = 22
    private static final int[][] MELODY = {
            // 0: Ode to Joy (traditional, public domain)
            {10, 2, 10, 2, 11, 2, 13, 2, 13, 2, 11, 2, 10, 2, 8, 2, 6, 2, 6, 2, 8, 2, 10, 2, 10, 3, 8, 1, 8, 4,
                    10, 2, 10, 2, 11, 2, 13, 2, 13, 2, 11, 2, 10, 2, 8, 2, 6, 2, 6, 2, 8, 2, 10, 2, 8, 3, 6, 1, 6, 4},
            // 1: Calm Night
            {10, 3, 13, 3, 15, 2, 13, 4, 10, 3, 8, 3, 6, 2, 8, 4, 10, 3, 13, 3, 15, 2, 18, 4, 15, 3, 13, 3, 10, 2, 13, 4},
            // 2: Bee Waltz
            {13, 1, 15, 1, 18, 2, 15, 1, 13, 1, 10, 2, 13, 1, 15, 1, 18, 2, 20, 4,
                    18, 1, 15, 1, 13, 2, 10, 1, 13, 1, 15, 2, 13, 2, 10, 2, 6, 4},
            // 3: Creepy Lullaby
            {10, 6, 13, 2, 16, 6, 13, 2, 10, 4, 9, 4, 10, 8, -1, 8}
    };
    private static final int[][] BASS = {
            {6, 8, 13, 8, 6, 8, 13, 8, 6, 8, 13, 8, 13, 8, 6, 8},
            {6, 12, 15, 12, 11, 12, 13, 12},
            {6, 4, 13, 4, 6, 4, 13, 4, 11, 4, 6, 4, 13, 4, 6, 4},
            {3, 20, 2, 20}
    };
    private static final int[] UNIT = {8, 10, 5, 9};           // ticks per unit
    private static final int[] LEAD = {0, 1, 0, 3};             // 0 harp, 1 bell, 3 chime
    private static final int COUNT = MELODY.length;
    private static final int[] TOTAL = new int[COUNT];

    static {
        for (int i = 0; i < COUNT; i++) {
            int sum = 0;
            for (int k = 1; k < MELODY[i].length; k += 2) sum += MELODY[i][k];
            TOTAL[i] = sum * UNIT[i];
        }
    }

    private int track = 0, t = 0, ticks = 0;
    private boolean playing;
    private final int[] cur = new int[2], next = new int[2];
    private float vol = 0.6F;
    private final float[] bars = new float[12];

    @Override
    public Component title() { return Component.translatable("cutemod.os.music"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.music"); }

    @Override
    public Component status() {
        return playing ? Component.translatable("cutemod.music.now", t("cutemod.music." + track))
                : Component.translatable("cutemod.music.paused");
    }

    @Override
    public void close() { playing = false; }

    private void startTrack(int i) {
        track = Math.floorMod(i, COUNT);
        t = 0;
        cur[0] = cur[1] = 0;
        next[0] = next[1] = 0;
        playing = true;
    }

    private static void note(int instrument, int n, float volume) {
        SoundEvent ev = switch (instrument) {
            case 0 -> SoundEvents.NOTE_BLOCK_HARP.value();
            case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
            case 2 -> SoundEvents.NOTE_BLOCK_BASS.value();
            default -> SoundEvents.NOTE_BLOCK_CHIME.value();
        };
        float pitch = (float) Math.max(0.5, Math.min(2.0, Math.pow(2.0, (n - 12) / 12.0)));
        Minecraft.getInstance().getSoundManager().play(
                net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(ev, pitch, volume));
    }

    @Override
    public void tick() {
        ticks++;
        for (int i = 0; i < bars.length; i++) bars[i] *= 0.92F;
        if (!playing) return;
        int unit = UNIT[track];
        for (int v = 0; v < 2; v++) {
            int[] arr = v == 0 ? MELODY[track] : BASS[track];
            while (cur[v] < arr.length && t >= next[v]) {
                int n = arr[cur[v]], len = arr[cur[v] + 1];
                if (n >= 0) {
                    note(v == 0 ? LEAD[track] : 2, n, v == 0 ? vol * 0.8F : vol);
                    bars[(n + v * 5) % 12] = 1F;
                }
                next[v] += len * unit;
                cur[v] += 2;
            }
        }
        t++;
        if (t >= TOTAL[track] + 8) startTrack(track + 1); // next track
    }

    // ---------- layout ----------
    private static final int LIST_X = 8, LIST_Y = 10, ROW_H = 22, LIST_W = 132;
    private static final int BAR_X = 8, BAR_Y = 112, BAR_W = 284;
    private static final int VOL_X = 190, VOL_Y = 133, VOL_W = 90;

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        g.fillGradient(0, 0, W, H, 0xFF1B1430, 0xFF3A2A5A);

        // track list
        for (int i = 0; i < COUNT; i++) {
            int y = LIST_Y + i * ROW_H;
            boolean sel = i == track, hover = in(mx, my, LIST_X, y, LIST_W, ROW_H - 2);
            rect(g, LIST_X, y, LIST_W, ROW_H - 2, sel ? 0xFFB57BD6 : (hover ? 0xFF5A4A86 : 0xFF3A2A66));
            g.drawString(font(), t("cutemod.music." + i), LIST_X + 6, y + 6, sel ? 0xFFFFFFFF : 0xFFD8CCE8, false);
            if (sel && playing) g.drawString(font(), (ticks / 15) % 2 == 0 ? ">" : ">>", LIST_X + LIST_W - 12, y + 6, 0xFFFFFFFF, false);
        }

        // equalizer
        rect(g, 150, 10, 142, 86, 0xFF14102A);
        for (int i = 0; i < bars.length; i++) {
            int h = 3 + (int) (bars[i] * 74);
            int col = 0xFF000000 | java.awt.Color.HSBtoRGB(i / 12f, 0.55f, 0.95f);
            rect(g, 154 + i * 11, 92 - h, 9, h, col);
            rect(g, 154 + i * 11, 92 - h, 9, 1, 0x88FFFFFF);
        }

        // now playing + progress
        g.drawString(font(), t("cutemod.music." + track), BAR_X, 100, 0xFFFFFFFF, false);
        rect(g, BAR_X, BAR_Y, BAR_W, 6, 0xFF14102A);
        int done = playing || t > 0 ? Math.min(BAR_W, BAR_W * t / Math.max(1, TOTAL[track])) : 0;
        rect(g, BAR_X, BAR_Y, done, 6, 0xFFF58FB8);

        // buttons
        button(g, mx, my, 8, 128, 28, "|<");
        button(g, mx, my, 40, 128, 40, playing ? "||" : ">");
        button(g, mx, my, 84, 128, 28, ">|");

        // volume
        g.drawString(font(), t("cutemod.music.volume"), 120, 132, 0xFFD8CCE8, false);
        rect(g, VOL_X, VOL_Y, VOL_W, 8, 0xFF14102A);
        rect(g, VOL_X, VOL_Y, (int) (VOL_W * vol), 8, 0xFFB57BD6);
    }

    private void button(GuiGraphics g, int mx, int my, int x, int y, int w, String s) {
        boolean hover = in(mx, my, x, y, w, 16);
        rect(g, x, y, w, 16, hover ? 0xFF8A6AC6 : 0xFF5A4A86);
        g.drawString(font(), s, x + (w - font().width(s)) / 2, y + 4, 0xFFFFFFFF, false);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < COUNT; i++) {
            if (in(x, y, LIST_X, LIST_Y + i * ROW_H, LIST_W, ROW_H - 2)) { startTrack(i); return true; }
        }
        if (in(x, y, 8, 128, 28, 16)) { startTrack(track - 1); return true; }
        if (in(x, y, 40, 128, 40, 16)) {
            if (playing) playing = false; else if (t == 0) startTrack(track); else playing = true;
            return true;
        }
        if (in(x, y, 84, 128, 28, 16)) { startTrack(track + 1); return true; }
        if (in(x, y, VOL_X - 2, VOL_Y - 3, VOL_W + 4, 14)) { setVol(x); return true; }
        return false;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (in(x, y, VOL_X - 6, VOL_Y - 8, VOL_W + 12, 24)) { setVol(x); return true; }
        return false;
    }

    private void setVol(int x) { vol = Math.max(0.05F, Math.min(1F, (x - VOL_X) / (float) VOL_W)); }

    @Override
    public boolean key(int keyCode, int modifiers) {
        switch (keyCode) {
            case 32 -> { if (playing) playing = false; else if (t == 0) startTrack(track); else playing = true; } // space
            case 262 -> startTrack(track + 1);
            case 263 -> startTrack(track - 1);
            default -> { return false; }
        }
        return true;
    }
}
