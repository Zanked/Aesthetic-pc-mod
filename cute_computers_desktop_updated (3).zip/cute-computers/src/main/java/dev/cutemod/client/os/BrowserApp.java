package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * A tiny browser. "cute://" pages are built into the mod; any other address or search words
 * are opened in the player's real browser (after the vanilla "open link?" confirmation).
 */
public class BrowserApp extends App {
    private record RLine(FormattedCharSequence seq, int kind, String target, int y) {} // kind: 0 text, 1 heading, 2 link

    private static final Set<String> PAGES = Set.of("home", "peep", "chirp", "shop", "wiki", "mail",
            "news", "tips", "about", "notfound", "scary", "scary1", "scary2", "scary3", "scary4");
    /** The fictional internet: domain -> page id. */
    private static final Map<String, String> DOMAINS = Map.of(
            "peep.cute", "peep", "chirp.cute", "chirp", "creepermart.cute", "shop",
            "pandapedia.cute", "wiki", "beemail.cute", "mail", "cutenews.cute", "news",
            "scarystories.cute", "scary");
    private static final String[] SEARCHABLE = {"peep", "chirp", "shop", "wiki", "mail", "news", "tips", "about",
            "scary", "scary1", "scary2", "scary3", "scary4"};
    private static final int AD_H = 18, AD_Y = H - AD_H - 1, AD_COUNT = 4, AD_TICKS = 300;
    private static final int VIEW_Y = 20, VIEW_H = H - VIEW_Y - 2 - AD_H, TEXT_X = 8, TEXT_W = W - 20;
    private static final int BAR_X = 52, BAR_W = W - BAR_X - 4;

    private final List<String> history = new ArrayList<>();
    private int hIdx = -1;
    private String address = "";
    private boolean focus, fresh;
    private final List<RLine> lines = new ArrayList<>();
    private int contentH, scroll, ticks;
    private int adSkip; // ticks added by closing an ad (jumps to the next one)

    public BrowserApp() {
        open("home");
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.browser"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.browser"); }

    @Override
    public void tick() { ticks++; }

    private String currentId() { return hIdx >= 0 ? history.get(hIdx) : "home"; }

    // ---------- navigation ----------
    private void open(String id) {
        if (!id.startsWith("?") && !PAGES.contains(id)) id = "notfound";
        while (history.size() > hIdx + 1) history.remove(history.size() - 1);
        history.add(id);
        hIdx = history.size() - 1;
        show(id);
    }

    private String addressOf(String id) {
        if (id.startsWith("?")) return "peep.cute/?q=" + id.substring(1);
        if (id.startsWith("scary") && id.length() > 5) return "scarystories.cute/" + id.substring(5);
        for (Map.Entry<String, String> e : DOMAINS.entrySet()) if (e.getValue().equals(id)) return e.getKey();
        return "cute://" + id;
    }

    private void show(String id) {
        address = addressOf(id);
        focus = false;
        fresh = false;
        scroll = 0;
        if (id.startsWith("?")) buildSearch(id.substring(1));
        else layout(t("cutemod.page." + id));
    }

    private void back() {
        if (hIdx > 0) { hIdx--; show(history.get(hIdx)); }
    }

    private void forward() {
        if (hIdx < history.size() - 1) { hIdx++; show(history.get(hIdx)); }
    }

    private void go(String raw) {
        String in = raw.trim();
        if (in.isEmpty()) { address = addressOf(currentId()); return; }
        String low = in.toLowerCase(Locale.ROOT);
        if (low.startsWith("cute://")) { open(low.substring(7)); return; }
        String host = low.replaceFirst("^https?://", "").replaceFirst("^www\\.", "");
        String path = "";
        int slash = host.indexOf('/');
        if (slash >= 0) { path = host.substring(slash + 1); host = host.substring(0, slash); }
        if (host.equals("scarystories.cute") && path.matches("[1-4]")) { open("scary" + path); return; }
        if (DOMAINS.containsKey(host)) { open(DOMAINS.get(host)); return; }
        if (PAGES.contains(low)) { open(low); return; }
        if (low.startsWith("http://") || low.startsWith("https://") || (!in.contains(" ") && in.contains("."))) {
            String url = low.startsWith("http") ? in : "https://" + in;
            address = addressOf(currentId());
            shell.openLink(url); // a real address: ask, then open in the system browser
            return;
        }
        open("?" + in); // plain words: search the cute internet
    }

    private void follow(String target) { go(target); }

    // ---------- page layout ----------
    /** Page format: "# heading", "> target | label" for links, blank line = gap. */
    private void layout(String raw) {
        lines.clear();
        Font f = font();
        int y = 4;
        for (String ln : raw.split("\n", -1)) {
            if (ln.isBlank()) { y += 5; continue; }
            int kind = 0;
            String target = null, text = ln;
            if (ln.startsWith("# ")) {
                kind = 1;
                text = ln.substring(2);
            } else if (ln.startsWith("> ") && ln.indexOf('|') > 0) {
                int bar = ln.indexOf('|');
                kind = 2;
                target = ln.substring(2, bar).trim();
                text = ln.substring(bar + 1).trim();
            }
            for (FormattedCharSequence part : f.split(FormattedText.of(text), TEXT_W)) {
                lines.add(new RLine(part, kind, target, y));
                y += 10;
            }
            if (kind == 1) y += 3;
        }
        contentH = y + 4;
    }

    /** Search inside the cute internet: pages are ranked by how many query words they contain. */
    private void buildSearch(String query) {
        String[] words = query.toLowerCase(Locale.ROOT).trim().split("\\s+");
        List<String> ids = new ArrayList<>();
        List<Integer> scores = new ArrayList<>();
        for (String id : SEARCHABLE) {
            String page = t("cutemod.page." + id);
            String low = page.toLowerCase(Locale.ROOT);
            int score = 0;
            for (String w : words) if (!w.isEmpty() && low.contains(w)) score++;
            if (score == 0) continue;
            int at = 0;
            while (at < ids.size() && scores.get(at) >= score) at++;
            ids.add(at, id);
            scores.add(at, score);
        }
        StringBuilder sb = new StringBuilder("# ").append(t("cutemod.os.search.results", query)).append('\n');
        if (ids.isEmpty()) sb.append(t("cutemod.os.search.none")).append('\n');
        for (String id : ids) {
            String page = t("cutemod.page." + id);
            String title = page.startsWith("# ") ? page.substring(2, page.indexOf('\n')) : id;
            sb.append("> cute://").append(id).append(" | ").append(title.replace("|", "/")).append('\n');
            String domain = addressOf(id);
            sb.append(domain.startsWith("cute://") ? domain : "http://" + domain).append("\n\n");
        }
        sb.append("> https://www.google.com/search?q=")
          .append(URLEncoder.encode(query, StandardCharsets.UTF_8))
          .append(" | ").append(t("cutemod.os.search.real")).append('\n');
        layout(sb.toString());
    }

    private int maxScroll() { return Math.max(0, contentH - VIEW_H); }

    private void clampScroll() { scroll = Math.max(0, Math.min(maxScroll(), scroll)); }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        boolean dark = currentId().startsWith("scary");
        rect(g, 0, 0, W, H, dark ? 0xFF0D0A10 : 0xFFFFFAFD);
        rect(g, 0, 0, W, VIEW_Y - 1, 0xFFE9DDF2);
        rect(g, 0, VIEW_Y - 1, W, 1, 0xFFC9B8D8);

        // toolbar buttons: back, forward, home
        drawButton(g, 3, 3, hIdx > 0, mx, my);
        glyph(g, "<", 3 + 5, 6, hIdx > 0);
        drawButton(g, 19, 3, hIdx < history.size() - 1, mx, my);
        glyph(g, ">", 19 + 5, 6, hIdx < history.size() - 1);
        drawButton(g, 35, 3, true, mx, my);
        rect(g, 35 + 4, 3 + 7, 6, 5, 0xFF3A2A3A);
        rect(g, 35 + 3, 3 + 6, 8, 1, 0xFF3A2A3A);
        rect(g, 35 + 4, 3 + 5, 6, 1, 0xFF3A2A3A);
        rect(g, 35 + 5, 3 + 4, 4, 1, 0xFF3A2A3A);
        rect(g, 35 + 6, 3 + 3, 2, 1, 0xFF3A2A3A);

        // address bar
        rect(g, BAR_X - 1, 2, BAR_W + 2, 16, focus ? 0xFF4A7BD0 : 0xFFB9A8C8);
        rect(g, BAR_X, 3, BAR_W, 14, 0xFFFFFFFF);
        String shown = address;
        while (shown.length() > 1 && f.width(shown) > BAR_W - 8) shown = shown.substring(1);
        int tw = f.width(shown);
        if (focus && fresh && !shown.isEmpty()) rect(g, BAR_X + 3, 4, tw + 2, 12, 0xFF4A7BD0);
        g.drawString(f, shown, BAR_X + 4, 6, focus && fresh ? 0xFFFFFFFF : 0xFF3A2A3A, false);
        if (focus && !fresh && (ticks / 30) % 2 == 0) rect(g, BAR_X + 4 + tw, 5, 1, 10, 0xFF3A2A3A);

        // page
        g.enableScissor(shell.absX(), shell.absY() + VIEW_Y, shell.absX() + W, shell.absY() + VIEW_Y + VIEW_H);
        for (RLine l : lines) {
            int y = VIEW_Y + l.y() - scroll;
            if (y < VIEW_Y - 12 || y > VIEW_Y + VIEW_H) continue;
            int w = f.width(l.seq());
            if (l.kind() == 1) {
                g.drawString(f, l.seq(), TEXT_X, y, dark ? 0xFFB3202A : 0xFFC04A7A, false);
                rect(g, TEXT_X, y + 9, w, 1, dark ? 0xFF5A0F15 : 0xFFF58FB8);
            } else if (l.kind() == 2) {
                boolean hover = in(mx, my, TEXT_X, y - 1, w, 10);
                int col = dark ? (hover ? 0xFFFF8A80 : 0xFFD9534F) : (hover ? 0xFF2F9BFF : 0xFF1F5FBF);
                g.drawString(f, l.seq(), TEXT_X, y, col, false);
                rect(g, TEXT_X, y + 9, w, 1, col);
            } else {
                g.drawString(f, l.seq(), TEXT_X, y, dark ? 0xFFC9C2CC : 0xFF3A2A3A, false);
            }
        }
        if (dark) renderScareEffects(g);
        g.disableScissor();

        // scrollbar
        if (contentH > VIEW_H) {
            rect(g, W - 5, VIEW_Y, 3, VIEW_H, dark ? 0xFF2A1A2A : 0xFFE9DDF2);
            int th = Math.max(12, VIEW_H * VIEW_H / contentH);
            int ty = VIEW_Y + (VIEW_H - th) * scroll / maxScroll();
            rect(g, W - 5, ty, 3, th, 0xFFB57BD6);
        }

        renderAd(g, mx, my);
    }

    /** Creepy extras for the scary site: flickering light and a pair of eyes that watch from the corners. */
    private void renderScareEffects(GuiGraphics g) {
        int phase = ticks % 400;
        if ((phase >= 380 && phase < 384) || (phase >= 390 && phase < 392)) {
            rect(g, 0, VIEW_Y, W, VIEW_H, 0xB0000000);
        }
        if (phase >= 150 && phase < 200) {
            boolean blink = phase >= 172 && phase < 178;
            int slot = (ticks / 400) % 4;
            int ex = slot == 0 ? 14 : slot == 1 ? W - 40 : slot == 2 ? 24 : W - 60;
            int ey = slot == 0 ? VIEW_Y + VIEW_H - 18 : slot == 1 ? VIEW_Y + 30 : slot == 2 ? VIEW_Y + 70 : VIEW_Y + VIEW_H - 40;
            rect(g, ex - 2, ey - 2, 22, 7, 0x33FF0000);
            if (!blink) {
                rect(g, ex, ey, 6, 3, 0xFFFF2A2A);
                rect(g, ex + 12, ey, 6, 3, 0xFFFF2A2A);
                rect(g, ex + 2, ey + 1, 2, 1, 0xFF000000);
                rect(g, ex + 14, ey + 1, 2, 1, 0xFF000000);
            } else {
                rect(g, ex, ey + 1, 6, 1, 0xFF7A1010);
                rect(g, ex + 12, ey + 1, 6, 1, 0xFF7A1010);
            }
        }
    }

    // ---------- animated ads ----------
    private int adTime() { return ticks + adSkip; }

    private int adIndex() { return (adTime() / AD_TICKS) % AD_COUNT; }

    /** Every sixth ad is "corrupted" (only when the scary stuff is switched on). */
    private boolean hauntedAd() { return Haunt.scary && (adTime() / AD_TICKS) % 6 == 5; }

    private String adTarget(int idx) {
        if (hauntedAd()) return "scary";
        return switch (idx) {
            case 0 -> "shop";
            case 1 -> "mail";
            case 2 -> "chirp";
            default -> "scary";
        };
    }

    private void renderAd(GuiGraphics g, int mx, int my) {
        Font f = font();
        int idx = adIndex();
        int t = adTime() % AD_TICKS;
        int slide = t < 16 ? (int) ((1 - t / 16.0) * (1 - t / 16.0) * W) : 0; // slides in from the right

        g.enableScissor(shell.absX(), shell.absY() + AD_Y, shell.absX() + W, shell.absY() + AD_Y + AD_H);
        g.pose().pushPose();
        g.pose().translate(slide, AD_Y, 0);
        String msg = hauntedAd() ? t("cutemod.ad.h" + (adTime() / AD_TICKS / 6) % 3) : t("cutemod.ad." + idx);
        int tw = f.width(msg);
        if (hauntedAd()) { // corrupted ad: flickers, shakes and stares back
            rect(g, 0, 0, W, AD_H, 0xFF000000);
            int shake = (t % 9 < 2) ? (t % 3) - 1 : 0;
            boolean off = (t % 37) > 31;
            g.drawString(f, msg, 6 + shake, 5, off ? 0xFF3A0A10 : 0xFFFF2A2A, false);
            if (t % 60 < 45) {
                rect(g, 205, 6, 6, 3, 0xFFFF2A2A);
                rect(g, 217, 6, 6, 3, 0xFFFF2A2A);
            }
            for (int k = 0; k < 3; k++) { // static noise
                int ny = (t * 7 + k * 5) % AD_H;
                rect(g, (t * 13 + k * 90) % W, ny, 30, 1, 0x55FFFFFF);
            }
        } else switch (idx) {
            case 0 -> { // CreeperMart: blinking sale, pulsing creeper
                rect(g, 0, 0, W, AD_H, (t / 12) % 2 == 0 ? 0xFF2E7D32 : 0xFF388E3C);
                int pulse = (int) Math.round(Math.sin(t / 6.0) * 1.5);
                int cs = 12 + pulse, cx = 4 - pulse / 2, cy = (AD_H - cs) / 2;
                rect(g, cx, cy, cs, cs, 0xFF5BBF6A);
                rect(g, cx + 2, cy + 3, 3, 3, 0xFF1B3A1B);
                rect(g, cx + cs - 5, cy + 3, 3, 3, 0xFF1B3A1B);
                rect(g, cx + cs / 2 - 1, cy + 6, 2, 4, 0xFF1B3A1B);
                g.drawString(f, msg, 24, 5, (t / 10) % 2 == 0 ? 0xFFFFEB3B : 0xFFFFFFFF, true);
            }
            case 1 -> { // BeeMail: a bee buzzes across the banner
                rect(g, 0, 0, W, AD_H, 0xFFFFF3B0);
                g.drawString(f, msg, (W - tw) / 2, 5, 0xFF5A3A00, false);
                int bx = (t * 3) % (W + 40) - 20;
                int by = 4 + (int) Math.round(Math.sin(t / 5.0) * 3);
                int flap = (t / 4) % 2;
                rect(g, bx + 1, by + flap * 2, 3, 3, 0xDDFFFFFF);
                rect(g, bx + 7, by + flap * 2, 3, 3, 0xDDFFFFFF);
                rect(g, bx, by + 3, 10, 6, 0xFFF5C518);
                rect(g, bx + 3, by + 3, 1, 6, 0xFF2A2A2A);
                rect(g, bx + 6, by + 3, 1, 6, 0xFF2A2A2A);
                rect(g, bx + 8, by + 4, 1, 1, 0xFF2A2A2A);
            }
            case 2 -> { // Panda Pizza: rainbow marquee
                g.fillGradient(0, 0, W, AD_H, 0xFFFFD6E8, 0xFFFFB3D1);
                int span = tw + 40;
                for (int k = 0; k < 2; k++) {
                    int x = W - (t * 2) % span + k * span - span;
                    int col = java.awt.Color.HSBtoRGB(((t + k * 30) % 120) / 120f, 0.7f, 0.85f);
                    g.drawString(f, msg, x, 5, 0xFF000000 | col, false);
                }
                rect(g, 0, 0, 3, AD_H, 0xFFFFFFFF);
                rect(g, W - 3, 0, 3, AD_H, 0xFFFFFFFF);
            }
            default -> { // Scary stories: dark banner with flickering text and eyes
                rect(g, 0, 0, W, AD_H, 0xFF0D0A10);
                boolean off = (t % 70) > 62 && (t % 4) < 2;
                g.drawString(f, msg, 6, 5, off ? 0xFF3A0A10 : 0xFFD9534F, false);
                if ((t % 90) < 70) {
                    int ex = 200 + (t / 90 % 2) * 15;
                    rect(g, ex, 7, 5, 3, 0xFFFF2A2A);
                    rect(g, ex + 10, 7, 5, 3, 0xFFFF2A2A);
                }
            }
        }
        // "Ad" label and a close button that only closes this one ad
        String label = t("cutemod.ad.label");
        rect(g, W - f.width(label) - 22, 1, f.width(label) + 3, 9, 0x88000000);
        g.drawString(f, label, W - f.width(label) - 20, 2, 0xFFFFFFFF, false);
        boolean hoverX = in(mx, my, W - 14, AD_Y + 2, 11, 11);
        rect(g, W - 14, 2, 11, 11, hoverX ? 0xFFFFFFFF : 0xCCFFFFFF);
        g.drawString(f, "x", W - 11, 3, 0xFF3A2A3A, false);
        g.pose().popPose();
        g.disableScissor();
        rect(g, 0, AD_Y - 1, W, 1, 0xFFC9B8D8);
    }

    private void drawButton(GuiGraphics g, int x, int y, boolean enabled, int mx, int my) {
        boolean hover = enabled && in(mx, my, x, y, 14, 14);
        rect(g, x, y, 14, 14, hover ? 0xFFFFFFFF : (enabled ? 0xFFF6F0FA : 0xFFD8CCE2));
    }

    private void glyph(GuiGraphics g, String s, int x, int y, boolean enabled) {
        g.drawString(font(), s, x, y, enabled ? 0xFF3A2A3A : 0xFF9A8FA8, false);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (y >= AD_Y) {
            if (in(x, y, W - 14, AD_Y + 2, 11, 11)) { // close: the next ad takes its place
                adSkip += AD_TICKS - adTime() % AD_TICKS;
            } else {
                follow(adTarget(adIndex()));
            }
            return true;
        }
        if (y < VIEW_Y) {
            if (in(x, y, 3, 3, 14, 14)) { back(); return true; }
            if (in(x, y, 19, 3, 14, 14)) { forward(); return true; }
            if (in(x, y, 35, 3, 14, 14)) { open("home"); return true; }
            if (in(x, y, BAR_X, 3, BAR_W, 14)) {
                if (!focus) { focus = true; fresh = true; }
                return true;
            }
            return true;
        }
        if (focus) { focus = false; fresh = false; address = addressOf(currentId()); }
        Font f = font();
        for (RLine l : lines) {
            if (l.kind() != 2) continue;
            int ly = VIEW_Y + l.y() - scroll;
            if (in(x, y, TEXT_X, ly - 1, f.width(l.seq()), 10)) {
                follow(l.target());
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (focus) {
            if (keyCode == 257 || keyCode == 335) { // enter
                focus = false;
                fresh = false;
                go(address);
                return true;
            }
            if (keyCode == 256) { // escape: leave the address bar, don't close the computer
                focus = false;
                fresh = false;
                address = addressOf(currentId());
                return true;
            }
            if (keyCode == 259) { // backspace
                if (fresh) { address = ""; fresh = false; }
                else if (!address.isEmpty()) address = address.substring(0, address.length() - 1);
                return true;
            }
            if (keyCode == 86 && Screen.hasControlDown()) { // ctrl+v
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) {
                    clip = clip.replace("\n", "").replace("\r", "").trim();
                    if (fresh) { address = ""; fresh = false; }
                    address = (address + clip);
                    if (address.length() > 300) address = address.substring(0, 300);
                }
                return true;
            }
            return false;
        }
        switch (keyCode) {
            case 265 -> scroll -= 12;   // up
            case 264 -> scroll += 12;   // down
            case 266 -> scroll -= VIEW_H - 12; // page up
            case 267 -> scroll += VIEW_H - 12; // page down
            case 268 -> scroll = 0;     // home
            case 269 -> scroll = maxScroll(); // end
            default -> { return false; }
        }
        clampScroll();
        return true;
    }

    @Override
    public boolean charTyped(char c) {
        if (!focus || c < 32 || c == 127) return false;
        if (fresh) { address = ""; fresh = false; }
        if (address.length() < 300) address += c;
        return true;
    }

    @Override
    public boolean scroll(double amount) {
        scroll -= (int) Math.round(amount * 14);
        clampScroll();
        return true;
    }
}
