package dev.cutemod.client.os;

import java.util.ArrayList;
import java.util.List;

/**
 * Which apps, games and folders are pinned to the Dock, and in what order. The player decides (drag to reorder, drag out
 * or right-click to remove, right-click in the Start menu to pin). Saved on the server through {@link Store}.
 */
public final class DockLayout {
    private DockLayout() {}

    /** The Dock holds this many apps at most (more would not fit the strip); the rest stay in the Start menu. */
    public static final int MAX = 14;

    private static final List<Integer> order = new ArrayList<>();
    private static int gen = -1;

    private static void ensure() {
        if (gen == Store.gen()) return;
        gen = Store.gen();
        order.clear();
        String s = Store.read("dock");
        if (s == null) {                                   // never customized: everything is pinned
            for (int i = 2; i < Desktop.ICONS && order.size() < MAX; i++) order.add(i);
            return;
        }
        for (String part : s.trim().split(",")) {
            try {
                int v = Integer.parseInt(part.trim());
                if (v == 15) v = 9;                        // CuteMarket took the slot of the old Shop
                if (Items.valid(v) && !order.contains(v)) order.add(v);       // 0 and 1 (own game, Games folder) are dropped
            } catch (NumberFormatException ignored) {      // "-" means an empty Dock
            }
        }
    }

    private static void save() {
        if (order.isEmpty()) { Store.write("dock", "-"); return; }
        StringBuilder sb = new StringBuilder();
        for (int v : order) sb.append(sb.length() == 0 ? "" : ",").append(v);
        Store.write("dock", sb.toString());
    }

    /** The pinned apps, left to right (apps that are not installed are left out). */
    public static List<Integer> list() {
        ensure();
        List<Integer> out = new ArrayList<>();
        for (int v : order) if (Library.available(v) && out.size() < MAX) out.add(v);
        return out;
    }

    public static boolean full() { return list().size() >= MAX; }

    public static boolean pinned(int app) { ensure(); return order.contains(app); }

    /** False if the Dock is full (or the app is not valid / already pinned). */
    public static boolean pin(int app) {
        ensure();
        if (!Items.valid(app) || !Library.available(app) || order.contains(app) || full()) return false;   // the apps of the pet (farm, school...) never go to the Dock
        order.add(app);
        save();
        return true;
    }

    public static void unpin(int app) {
        ensure();
        if (order.remove((Integer) app)) save();
    }

    public static void toggle(int app) {
        if (pinned(app)) unpin(app);
        else pin(app);
    }

    /** Put an app at a slot of the Dock (it is added if it was not pinned). */
    public static void move(int app, int slot) {
        ensure();
        boolean was = order.remove((Integer) app);
        if (!was && full()) return;                        // a new icon does not fit into a full Dock
        List<Integer> visible = list();                    // the slot counts only the icons that are shown
        int at = slot >= visible.size() ? order.size() : order.indexOf(visible.get(Math.max(0, slot)));
        order.add(Math.max(0, Math.min(order.size(), at)), app);
        save();
    }
}
