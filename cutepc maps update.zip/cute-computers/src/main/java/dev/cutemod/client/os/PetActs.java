package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * The little games of the map places. A place with a game has a "Play" button on its panel ({@link PetPlace}):
 * the amusement park has a shooting gallery, the cinema a movie night, the museum a pairs game and the camp
 * roasts marshmallows. Every game ends with {@link Reward#give}: the coins and what the pet gets (fun, energy, food).
 * The texts are in the lang files: cutemod.act.*.
 */
final class PetActs {
    private PetActs() {}

    static final int W = App.W, H = App.H, HEAD = MapArt.HEAD;
    private static final int TEXT = 0xFF3A2A3A, WHITE = 0xFFFFFFFF;

    /** What a game gives to the pet when it ends. The numbers are changes (a game can also tire the pet, so they can be negative). */
    interface Reward { void give(int coins, int fun, int energy, int food); }

    /** What a game needs from the pet screen. */
    record Ctx(Runnable exit, Reward reward, Supplier<ComputerColor> color, IntSupplier stage, Consumer<Float> snd) {}

    static boolean has(int dest) { return dest >= PlaceUnlock.AMUSEMENT && dest <= PlaceUnlock.CAMP; }

    static Act create(int dest, Ctx c) {
        return switch (dest) {
            case PlaceUnlock.AMUSEMENT -> new Gallery(dest, c);
            case PlaceUnlock.CINEMA -> new Cinema(dest, c);
            case PlaceUnlock.MUSEUM -> new Match(dest, c);
            default -> new Camp(dest, c);
        };
    }

    static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    // =====================================================================================================
    //  shared drawing
    // =====================================================================================================
    static void btn(GuiGraphics g, Font f, String label, int x, int y, int w, int h, boolean hover, int base) {
        int c = hover ? MapArt.mix(base, WHITE, 0.2F) : base;
        Skin.rect(g, x, y, w, h, c);
        Skin.rect(g, x, y, w, 1, MapArt.mix(base, WHITE, 0.5F));
        Skin.rect(g, x, y + h - 1, w, 1, MapArt.mix(base, 0xFF000000, 0.3F));
        Skin.str(g, f, label, x + (w - f.width(label)) / 2, y + (h - 8) / 2, WHITE, true);
    }

    static void pixelStar(GuiGraphics g, int cx, int cy, int c) {
        MapArt.rect(g, cx - 1, cy - 3, 3, 7, c); MapArt.rect(g, cx - 3, cy - 1, 7, 3, c);
        MapArt.rect(g, cx - 2, cy - 2, 5, 5, c); MapArt.rect(g, cx, cy - 1, 1, 1, 0xAAFFFFFF);
    }

    static void pet(GuiGraphics g, ComputerColor col, int x, int feet, float sc, int ticks, int stage, int mood) {
        float s = sc * PetArt.scaleOf(stage);
        g.pose().pushPose();
        g.pose().translate(x, feet, 0);
        g.pose().scale(s, s, 1F);
        g.pose().translate(-x, -feet, 0);
        PetArt.draw(g, col, x, feet - 28, mood, ticks, false, false, stage, Progress.equipped(), Progress.equippedBody());
        g.pose().popPose();
    }

    // =====================================================================================================
    //  a game
    // =====================================================================================================
    abstract static class Act {
        final int dest;
        final Ctx c;
        int ticks;
        boolean over, paid;

        Act(int dest, Ctx c) { this.dest = dest; this.c = c; }

        void tick() { ticks++; }
        abstract void render(GuiGraphics g, int mx, int my);
        abstract boolean click(int mx, int my, int button);

        boolean key(int keyCode) {
            if (keyCode == 256) { c.exit().run(); return true; }
            return false;
        }

        Font font() { return Minecraft.getInstance().font; }

        /** The header: a back button, the name of the game in the middle and a short text at the right. */
        void header(GuiGraphics g, int mx, int my, String right) {
            Font f = font();
            Skin.rect(g, 0, 0, W, HEAD, 0xFF5A4A86);
            boolean bh = App.in(mx, my, 3, 3, 44, 12);
            Skin.rect(g, 3, 3, 44, 12, bh ? WHITE : 0xE0F6F0FA);
            Skin.str(g, f, "< " + t("cutemod.trip.back_btn"), 7, 5, TEXT, false);
            String title = t("cutemod.act.name." + dest);
            Skin.str(g, f, title, W / 2 - f.width(title) / 2, 5, WHITE, false);
            if (right != null && !right.isEmpty()) Skin.str(g, f, right, W - 6 - f.width(right), 5, 0xFFE4D8FF, false);
        }

        boolean backHit(int mx, int my) { return App.in(mx, my, 3, 3, 44, 12); }

        void give(int coins, int fun, int energy, int food) {
            if (paid) return;
            paid = true;
            c.reward().give(coins, fun, energy, food);
        }

        /** The box at the end of a game; returns 1 for "again", 2 for "back", 0 for nothing. */
        void resultBox(GuiGraphics g, int mx, int my, String title, String line1, String line2, int coins) {
            Font f = font();
            g.fill(0, HEAD, W, H, 0x66000000);
            int bx = 60, by = 40, bw = 180, bh = 84;
            Skin.rect(g, bx - 2, by - 2, bw + 4, bh + 4, 0xFF5A4A86);
            Skin.rect(g, bx, by, bw, bh, 0xFFFFF8F0);
            Skin.rect(g, bx, by, bw, 14, 0xFFFFD84D);
            Skin.str(g, f, title, bx + (bw - f.width(title)) / 2, by + 3, TEXT, false);
            Skin.str(g, f, line1, bx + (bw - f.width(line1)) / 2, by + 20, TEXT, false);
            if (line2 != null && !line2.isEmpty()) Skin.str(g, f, line2, bx + (bw - f.width(line2)) / 2, by + 31, 0xFF8A7AA8, false);
            if (coins > 0) {
                String s = t("cutemod.act.coins", coins);
                int sw = f.width(s) + 12, sx = bx + (bw - sw) / 2;
                Progress.drawCoin(g, sx, by + 43);
                Skin.str(g, f, s, sx + 12, by + 44, 0xFFB07A10, false);
            }
            btn(g, f, t("cutemod.act.again"), bx + 10, by + 62, 76, 16, App.in(mx, my, bx + 10, by + 62, 76, 16), 0xFF4CAF50);
            btn(g, f, t("cutemod.trip.back_btn"), bx + bw - 86, by + 62, 76, 16, App.in(mx, my, bx + bw - 86, by + 62, 76, 16), 0xFF8A7AA8);
        }

        /** 1 = again, 2 = back, 0 = neither (see {@link #resultBox}). */
        int resultClick(int mx, int my) {
            int bx = 60, by = 40, bw = 180;
            if (App.in(mx, my, bx + 10, by + 62, 76, 16)) return 1;
            if (App.in(mx, my, bx + bw - 86, by + 62, 76, 16)) return 2;
            return 0;
        }
    }

    // =====================================================================================================
    //  1. THE SHOOTING GALLERY (amusement park): click the ducks, balloons and golden stars that pass by
    // =====================================================================================================
    static final class Gallery extends Act {
        private static final int DUR = 1500;                          // 25 seconds
        private static final int[] ROW_Y = {52, 86, 120};
        private static final double[] ROW_V = {0.9, -1.2, 1.5};
        /** x, y, vx, type (0 duck, 1 golden star, 2 balloon), pop timer (0 = alive), phase, value shown */
        private final List<double[]> ts = new ArrayList<>();
        private final int[] spawn = {5, 30, 55};
        private final Random rnd = new Random();
        private int left = DUR, score, shots, hits;

        Gallery(int dest, Ctx c) { super(dest, c); }

        @Override void tick() {
            super.tick();
            if (over) return;
            left--;
            for (int r = 0; r < 3; r++) {
                if (--spawn[r] > 0) continue;
                int roll = rnd.nextInt(10), type = roll < 6 ? 0 : roll < 8 ? 2 : 1;
                double v = ROW_V[r] * (type == 1 ? 1.35 : type == 2 ? 0.8 : 1);
                ts.add(new double[]{v > 0 ? -10 : W + 10, ROW_Y[r], v, type, 0, rnd.nextDouble() * 6.28, 0});
                spawn[r] = 40 + rnd.nextInt(55);
            }
            for (double[] t : ts) { t[0] += t[2]; if (t[4] > 0) t[4]--; }
            ts.removeIf(t -> t[0] < -16 || t[0] > W + 16 || (t[4] < 0.5 && t[6] > 0));
            if (left <= 0) {
                over = true;
                give(Math.min(12, score / 2), 18 + Math.min(14, score), -10, 0);
            }
        }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(mx, my);
                if (r == 1) { ts.clear(); left = DUR; score = 0; shots = 0; hits = 0; over = false; paid = false; }
                else if (r == 2) c.exit().run();
                return true;
            }
            shots++;
            double bd = 11;
            double[] best = null;
            for (double[] t : ts) {
                if (t[4] > 0 || t[6] > 0) continue;
                double d = Math.hypot(mx - t[0], my - bob(t));
                if (d < bd) { bd = d; best = t; }
            }
            if (best != null) {
                int v = best[3] == 1 ? 3 : best[3] == 2 ? 2 : 1;
                score += v; hits++;
                best[4] = 16; best[6] = v;
                c.snd().accept(best[3] == 1 ? 2.0F : 1.6F);
            } else c.snd().accept(0.8F);
            return true;
        }

        private static double bob(double[] t) { return t[3] == 2 ? t[1] + Math.sin(t[5]) * 3 : t[1]; }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
            g.fill(0, HEAD, W, H, 0x38201840);
            for (int r = 0; r < 3; r++) {                                   // the rails the targets slide on
                int y = ROW_Y[r] + 8;
                MapArt.rect(g, 0, y, W, 3, 0xFF8A5A3A); MapArt.rect(g, 0, y, W, 1, 0xFFC8955C);
                for (int x = (ticks * (r % 2 == 0 ? 1 : -1)) % 12; x < W; x += 12) MapArt.rect(g, x < 0 ? x + 12 : x, y + 1, 4, 1, 0xFFFFD84D);
            }
            for (double[] t : ts) drawTarget(g, f, t);
            header(g, mx, my, null);
            Skin.str(g, f, t("cutemod.act.g.score", score), 54, 5, 0xFFFFE680, false);
            int bw = 70, fill = bw * Math.max(0, left) / DUR;             // the time left
            Skin.rect(g, W - bw - 6, 5, bw, 7, 0xFF3A2A5A);
            Skin.rect(g, W - bw - 6, 5, fill, 7, left < 300 ? 0xFFE5484D : 0xFF6BCB77);
            Skin.rect(g, W - bw - 6, 5, fill, 1, 0x66FFFFFF);
            if (!over && App.in(mx, my, 0, HEAD, W, H - HEAD)) {            // the sight
                int cl = 0xFFFFFFFF;
                MapArt.rect(g, mx - 7, my, 5, 1, cl); MapArt.rect(g, mx + 3, my, 5, 1, cl);
                MapArt.rect(g, mx, my - 7, 1, 5, cl); MapArt.rect(g, mx, my + 3, 1, 5, cl);
                MapArt.rect(g, mx, my, 1, 1, 0xFFE5484D);
            }
            if (over) {
                String acc = shots == 0 ? "" : t("cutemod.act.g.acc", hits * 100 / shots);
                resultBox(g, mx, my, t("cutemod.act.g.end"), t("cutemod.act.g.score", score), acc, Math.min(12, score / 2));
            }
        }

        private void drawTarget(GuiGraphics g, Font f, double[] t) {
            int x = (int) Math.round(t[0]), y = (int) Math.round(bob(t)), dir = t[2] > 0 ? 1 : -1;
            if (t[4] > 0) {                                                 // popped: a ring and the points that float up
                int p = (int) (16 - t[4]);
                for (int a = 0; a < 8; a++) {
                    double an = a * Math.PI / 4;
                    MapArt.rect(g, x + (int) Math.round(Math.cos(an) * (3 + p)), y + (int) Math.round(Math.sin(an) * (3 + p)), 2, 2, t[3] == 1 ? 0xFFFFD84D : 0xFFFFFFFF);
                }
                Skin.str(g, f, "+" + (int) t[6], x - 3, y - 6 - p, 0xFFFFE680, true);
                return;
            }
            if (t[3] == 0) {                                                // a duck
                MapArt.oval(g, x, y + 8, 7, 2, 0x33000000);
                MapArt.ball(g, x, y + 1, 5, 0xFFFFD84D); MapArt.ball(g, x + dir * 4, y - 4, 3, 0xFFFFE680);
                MapArt.rect(g, x + dir * 7 - (dir < 0 ? 2 : 0), y - 4, 3, 2, 0xFFFF9A3C);
                MapArt.rect(g, x + dir * 4, y - 5, 1, 1, 0xFF3A2A3A);
                MapArt.rect(g, x - dir * 2, y, 4, 3, 0xFFF0B800);
                MapArt.rect(g, x - dir * 6, y - 1, 2, 2, 0xFFFFD84D);
            } else if (t[3] == 2) {                                         // a balloon
                int[] bc = {0xFFFF6B6B, 0xFF4D96FF, 0xFF6BCB77, 0xFFB57BD6};
                int col = bc[(int) (t[5] * 3) % 4];
                MapArt.ball(g, x, y, 5, col); MapArt.rect(g, x - 2, y - 3, 1, 2, 0x99FFFFFF);
                MapArt.ln(g, x, y + 6, x + 1, y + 10, 0xAA8A7A8A);
            } else {                                                        // a golden star, worth more
                int tw = (ticks / 8) % 2;
                MapArt.ball(g, x, y, 8, 0x30FFD84D);
                pixelStar(g, x, y, tw == 0 ? 0xFFFFD84D : 0xFFFFE680);
            }
        }
    }

    // =====================================================================================================
    //  2. THE CINEMA: pick a film, watch it with the pet
    // =====================================================================================================
    static final class Cinema extends Act {
        static final int COST = 3, FILM_TICKS = 720;                  // 12 seconds
        private static final int[][] GAIN = {{30, -4, 0}, {24, -8, 0}, {10, 22, 0}};   // fun, energy, food of the three films
        private int state, film, toastT;                              // 0 pick, 1 watching, 2 done
        private int watch;

        Cinema(int dest, Ctx c) { super(dest, c); }

        @Override void tick() {
            super.tick();
            if (toastT > 0) toastT--;
            if (state == 1 && ++watch >= FILM_TICKS) {
                state = 2;
                give(0, GAIN[film][0], GAIN[film][1], GAIN[film][2]);
            }
        }

        private static final int CW = 86, CH = 108, CY = 30;
        private static int cardX(int i) { return 13 + i * (CW + 8); }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (state == 2) {
                int r = resultClick(mx, my);
                if (r == 1) { state = 0; watch = 0; paid = false; }
                else if (r == 2) c.exit().run();
                return true;
            }
            if (state == 0) for (int i = 0; i < 3; i++) if (App.in(mx, my, cardX(i), CY, CW, CH)) {
                if (!Progress.spend(COST)) { toastT = 140; c.snd().accept(0.8F); return true; }
                film = i; state = 1; watch = 0; paid = false;
                c.snd().accept(1.6F);
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            if (state == 0) {
                g.fillGradient(0, HEAD, W, H, 0xFF2A1030, 0xFF5A1A3A);
                header(g, mx, my, null);
                String pick = t("cutemod.act.c.pick", COST);
                Skin.str(g, f, pick, W / 2 - f.width(pick) / 2, 21, 0xFFFFE680, true);
                for (int i = 0; i < 3; i++) card(g, f, i, mx, my);
                if (toastT > 0) {
                    String s = t("cutemod.act.c.poor", COST);
                    int sw = f.width(s) + 14, sx = W / 2 - sw / 2;
                    Skin.rect(g, sx, 142, sw, 13, 0xF0FFE4E4);
                    Skin.str(g, f, s, sx + 7, 145, 0xFFB02A30, false);
                }
                return;
            }
            TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
            int sx = 300 * 18 / 100, sw = 300 * 64 / 100, sy = HEAD + (H - HEAD) * 10 / 100, sh = (H - HEAD) * 42 / 100;
            filmArt(g, film, sx, sy, sw, sh, ticks);
            g.fill(sx, sy, sx + sw, sy + 2, 0x30000000);
            ComputerColor col = c.color().get();
            pet(g, col, 150, H - 18, 0.6F, ticks, c.stage().getAsInt(), state == 2 ? 2 : 1);
            MapArt.rect(g, 0, H - 14, W, 14, 0xFF3A1428);                  // the seat in front
            MapArt.rect(g, 0, H - 14, W, 1, 0xFFC84868);
            header(g, mx, my, null);
            if (state == 1) {
                String now = t("cutemod.act.c.now", t("cutemod.act.c.f." + film));
                Skin.str(g, f, now, W / 2 - f.width(now) / 2, H - 11, 0xFFFFE680, false);
                int bw = 100, fill = bw * watch / FILM_TICKS;
                Skin.rect(g, W / 2 - bw / 2, 20, bw, 4, 0xAA000000); Skin.rect(g, W / 2 - bw / 2, 20, fill, 4, 0xFFFF6B8E);
            } else resultBox(g, mx, my, t("cutemod.act.c.end"), t("cutemod.act.c.f." + film), t("cutemod.act.c.fx." + film), 0);
        }

        private void card(GuiGraphics g, Font f, int i, int mx, int my) {
            int x = cardX(i);
            boolean hv = App.in(mx, my, x, CY, CW, CH);
            int lift = hv ? -2 : 0;
            Skin.rect(g, x - 1, CY + lift - 1, CW + 2, CH + 2, hv ? 0xFFFFD84D : 0xFF1A0A20);
            Skin.rect(g, x, CY + lift, CW, CH, 0xFFFFF8F0);
            filmArt(g, i, x + 3, CY + lift + 3, CW - 6, 58, ticks / 3);
            String name = t("cutemod.act.c.f." + i);
            Skin.str(g, f, f.plainSubstrByWidth(name, CW - 6), x + (CW - Math.min(f.width(name), CW - 6)) / 2, CY + lift + 66, TEXT, false);
            String fx = t("cutemod.act.c.fx." + i);
            Skin.str(g, f, f.plainSubstrByWidth(fx, CW - 6), x + (CW - Math.min(f.width(fx), CW - 6)) / 2, CY + lift + 77, 0xFF8A7AA8, false);
            boolean can = Progress.coins() >= COST;
            Skin.rect(g, x + 14, CY + lift + 89, CW - 28, 13, can ? 0xFF4CAF50 : 0xFFB8B0C0);
            Progress.drawCoin(g, x + 20, CY + lift + 91);
            Skin.str(g, f, "x" + COST, x + 34, CY + lift + 92, WHITE, true);
            Skin.str(g, f, t("cutemod.act.c.go"), x + 48, CY + lift + 92, WHITE, true);
        }

        /** What is on the screen: 0 cuddly cats, 1 star voyage, 2 sleepy moon. Drawn inside the box x, y, w, h. */
        static void filmArt(GuiGraphics g, int film, int x, int y, int w, int h, int t) {
            switch (film) {
                case 0 -> {                                                 // two cats that bounce and send hearts
                    g.fillGradient(x, y, x + w, y + h, 0xFFFFE4EC, 0xFFFFC8DC);
                    MapArt.rect(g, x, y + h * 82 / 100, w, h - h * 82 / 100, 0xFFC8E8A8);
                    for (int k = 0; k < 2; k++) {
                        int cx = x + w * (30 + k * 40) / 100, bounce = (int) Math.round(Math.abs(Math.sin((t + k * 20) / 14.0)) * h / 6.0);
                        int cy = y + h * 62 / 100 - bounce, r = Math.max(4, h / 6);
                        int fur = k == 0 ? 0xFFFFB066 : 0xFF9AA0B0;
                        MapArt.tri(g, cx - r + 1, cy - r - r / 2, r, r / 2 + 2, fur); MapArt.tri(g, cx + r - 1, cy - r - r / 2, r, r / 2 + 2, fur);
                        MapArt.ball(g, cx, cy, r, fur);
                        MapArt.rect(g, cx - r / 2 - 1, cy - 1, 2, 2, 0xFF3A2A3A); MapArt.rect(g, cx + r / 2, cy - 1, 2, 2, 0xFF3A2A3A);
                        MapArt.rect(g, cx, cy + 2, 1, 1, 0xFFFF6B8E);
                    }
                    for (int k = 0; k < 3; k++) {
                        int hx = x + w * (40 + k * 10) / 100, hy = y + h * 34 / 100 - (t / 2 + k * 14) % (h / 3 + 1);
                        MapArt.rect(g, hx, hy, 3, 2, 0xFFFF6B8E); MapArt.rect(g, hx + 1, hy + 2, 1, 1, 0xFFFF6B8E);
                    }
                }
                case 1 -> {                                                 // a rocket among stars
                    g.fillGradient(x, y, x + w, y + h, 0xFF0A1236, 0xFF2A3A7A);
                    for (int k = 0; k < 16; k++) {
                        int sx = x + Math.floorMod(k * 37 - t * (1 + k % 3), w), sy = y + 2 + (k * 23) % Math.max(1, h - 4);
                        MapArt.rect(g, sx, sy, 1, 1, k % 3 == 0 ? 0xFFFFE680 : 0xFFFFFFFF);
                    }
                    MapArt.ball(g, x + w * 80 / 100, y + h * 30 / 100, Math.max(3, h / 6), 0xFFE8803A);
                    MapArt.ball(g, x + w * 78 / 100, y + h * 28 / 100, Math.max(2, h / 10), 0xFFF4A860);
                    int rx = x + w * 40 / 100, ry = y + h * 52 / 100 + (int) Math.round(Math.sin(t / 12.0) * h / 14.0), rl = Math.max(8, h / 4);
                    MapArt.rect(g, rx - rl, ry - 2, rl, 5, 0xFFF0F0FA); MapArt.tri(g, rx + 3, ry - 2, 5, 6, 0xFFE5484D);
                    MapArt.rect(g, rx - rl, ry - 2, 3, 5, 0xFFE5484D); MapArt.ball(g, rx - rl / 2, ry, 1, 0xFF4D96FF);
                    int fl = 3 + (t / 3) % 3; MapArt.tri(g, rx - rl - 2, ry - 2, 5, 5, 0xFFFFC832); MapArt.rect(g, rx - rl - fl - 2, ry, fl, 1, 0xFFFF7A2A);
                }
                default -> {                                                // a sleepy moon with drifting zzz
                    g.fillGradient(x, y, x + w, y + h, 0xFF3A2A6A, 0xFF8A5AA0);
                    MapArt.ball(g, x + w * 50 / 100, y + h * 42 / 100, Math.max(5, h / 4), 0xFFFFE9A8);
                    MapArt.ball(g, x + w * 50 / 100 + 3, y + h * 42 / 100 - 2, Math.max(4, h / 5), 0xFF6A4A8A);
                    for (int k = 0; k < 3; k++) {
                        int zx = x + w * (60 + k * 8) / 100 + (t / 5 + k * 9) % 6, zy = y + h * 34 / 100 - (t / 4 + k * 12) % (h / 3 + 1);
                        MapArt.rect(g, zx, zy, 4, 1, 0xFFFFFFFF); MapArt.rect(g, zx + 3, zy + 1, 1, 1, 0xFFFFFFFF); MapArt.rect(g, zx + 2, zy + 2, 1, 1, 0xFFFFFFFF); MapArt.rect(g, zx, zy + 3, 4, 1, 0xFFFFFFFF);
                    }
                    int cd = (t / 3) % (w + 30);
                    MapArt.oval(g, x + cd - 20, y + h * 78 / 100, 12, 3, 0xAAFFFFFF);
                    MapArt.oval(g, x + Math.floorMod(cd + w / 2, w + 30) - 20, y + h * 62 / 100, 9, 2, 0x88FFFFFF);
                    MapArt.rect(g, x, y + h * 90 / 100, w, h - h * 90 / 100, 0xFF2A1A44);
                }
            }
        }
    }

    // =====================================================================================================
    //  3. THE MUSEUM: find the pairs of the treasures
    // =====================================================================================================
    static final class Match extends Act {
        private static final int COLS = 4, ROWS = 3, CW = 52, CH = 36, GAP = 8, X0 = 34, Y0 = 26;
        private final int[] card = new int[COLS * ROWS];
        private final float[] flip = new float[COLS * ROWS];            // 0 = back, 1 = face
        private final boolean[] up = new boolean[COLS * ROWS], done = new boolean[COLS * ROWS];
        private int first = -1, second = -1, wait, moves, pairs;

        Match(int dest, Ctx c) { super(dest, c); reset(); }

        private void reset() {
            List<Integer> l = new ArrayList<>();
            for (int i = 0; i < card.length / 2; i++) { l.add(i); l.add(i); }
            java.util.Collections.shuffle(l, new Random());
            for (int i = 0; i < card.length; i++) { card[i] = l.get(i); flip[i] = 0; up[i] = false; done[i] = false; }
            first = second = -1; wait = 0; moves = 0; pairs = 0; over = false; paid = false;
        }

        private static int cx(int i) { return X0 + (i % COLS) * (CW + GAP); }
        private static int cy(int i) { return Y0 + (i / COLS) * (CH + GAP); }

        @Override void tick() {
            super.tick();
            for (int i = 0; i < card.length; i++) {
                float to = up[i] || done[i] ? 1 : 0;
                flip[i] += Math.signum(to - flip[i]) * Math.min(0.12F, Math.abs(to - flip[i]));
            }
            if (wait > 0 && --wait == 0) {
                if (card[first] == card[second]) {
                    done[first] = done[second] = true; pairs++;
                    c.snd().accept(2.0F);
                    if (pairs == card.length / 2) {
                        over = true;
                        int coins = moves <= 8 ? 10 : moves <= 12 ? 7 : 4;
                        give(coins, 14, -6, 0);
                    }
                } else { up[first] = false; up[second] = false; c.snd().accept(0.9F); }
                first = second = -1;
            }
        }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(mx, my);
                if (r == 1) reset(); else if (r == 2) c.exit().run();
                return true;
            }
            if (wait > 0) return true;
            for (int i = 0; i < card.length; i++) {
                if (!App.in(mx, my, cx(i), cy(i), CW, CH) || up[i] || done[i]) continue;
                up[i] = true; c.snd().accept(1.4F);
                if (first < 0) first = i;
                else { second = i; moves++; wait = 38; }
                break;
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            g.fillGradient(0, HEAD, W, H, 0xFFF8EEDA, 0xFFE8D4AA);
            for (int x = 0; x < W; x += 16) MapArt.rect(g, x, HEAD, 1, H - HEAD, 0x10A07A40);
            MapArt.rect(g, 6, HEAD + 3, W - 12, 2, 0xFFC8952C); MapArt.rect(g, 6, H - 7, W - 12, 2, 0xFFC8952C);
            header(g, mx, my, null);
            Skin.str(g, f, t("cutemod.act.m.moves", moves), 54, 5, 0xFFFFE680, false);
            for (int i = 0; i < card.length; i++) drawCard(g, i, mx, my);
            if (over) {
                int stars = moves <= 8 ? 3 : moves <= 12 ? 2 : 1;
                resultBox(g, mx, my, t("cutemod.act.m.win"), t("cutemod.act.m.moves", moves), "", moves <= 8 ? 10 : moves <= 12 ? 7 : 4);
                for (int s = 0; s < 3; s++) pixelStar(g, 150 - 14 + s * 14, 40 + 52, s < stars ? 0xFFFFC832 : 0xFFD8D0E0);
            }
        }

        private void drawCard(GuiGraphics g, int i, int mx, int my) {
            int x = cx(i), y = cy(i);
            float fl = flip[i];
            float sx = Math.abs(2 * fl - 1);                                  // the card turns around its middle
            int w = Math.max(2, Math.round(CW * Math.max(0.08F, sx))), x0 = x + (CW - w) / 2;
            boolean hv = App.in(mx, my, x, y, CW, CH) && !up[i] && !done[i] && !over;
            if (fl < 0.5F) {                                                  // the back
                Skin.rect(g, x0 - 1, y - 1 + (hv ? -1 : 0), w + 2, CH + 2, 0xFF4A3A7A);
                Skin.rect(g, x0, y + (hv ? -1 : 0), w, CH, hv ? 0xFFB08AE0 : 0xFF9A7AD0);
                if (w > 20) {
                    MapArt.rect(g, x0 + 3, y + 3 + (hv ? -1 : 0), w - 6, 1, 0xFFC8B0F0); MapArt.rect(g, x0 + 3, y + CH - 4 + (hv ? -1 : 0), w - 6, 1, 0xFFC8B0F0);
                    pixelStar(g, x + CW / 2, y + CH / 2 + (hv ? -1 : 0), 0xFFFFD84D);
                }
            } else {
                Skin.rect(g, x0 - 1, y - 1, w + 2, CH + 2, done[i] ? 0xFF6BCB77 : 0xFFC8952C);
                Skin.rect(g, x0, y, w, CH, 0xFFFFFBF0);
                if (w > 24) glyph(g, card[i], x + CW / 2, y + CH / 2, ticks);
            }
        }

        /** The treasures: 0 gem, 1 coin, 2 shell, 3 fish, 4 key, 5 crown. About 22 pixels across. */
        static void glyph(GuiGraphics g, int id, int cx, int cy, int t) {
            switch (id) {
                case 0 -> {
                    MapArt.tri(g, cx, cy - 10, 20, 8, 0xFFB57BD6);
                    for (int r = 0; r < 9; r++) { int w = 20 - r * 20 / 9; MapArt.rect(g, cx - w / 2, cy - 2 + r, Math.max(1, w), 1, r < 3 ? 0xFF9A5ABE : 0xFF8048A8); }
                    MapArt.rect(g, cx - 5, cy - 8, 3, 1, 0xFFE8D0FA); MapArt.rect(g, cx - 4, cy - 7, 1, 3, 0xFFE8D0FA);
                }
                case 1 -> {
                    MapArt.ball(g, cx, cy, 9, 0xFFC8952C); MapArt.ball(g, cx, cy, 7, 0xFFFFD84D); MapArt.ball(g, cx - 1, cy - 1, 4, 0xFFFFE680);
                    MapArt.rect(g, cx - 1, cy - 4, 2, 8, 0xFFC8952C); MapArt.rect(g, cx - 3, cy - 1, 6, 2, 0xFFC8952C);
                }
                case 2 -> {
                    for (int r = 0; r < 12; r++) { int w = 6 + r * 2; MapArt.rect(g, cx - w / 2, cy - 8 + r, w, 1, r % 2 == 0 ? 0xFFFFB8C8 : 0xFFFF9AB4); }
                    for (int k = -2; k <= 2; k++) MapArt.ln(g, cx, cy + 4, cx + k * 4, cy - 8, 0xFFE87A98);
                    MapArt.rect(g, cx - 4, cy + 4, 9, 3, 0xFFC8956A);
                }
                case 3 -> {
                    MapArt.oval(g, cx - 2, cy, 9, 6, 0xFF4D96FF); MapArt.oval(g, cx - 2, cy + 1, 8, 4, 0xFF7ABAFF);
                    MapArt.tri(g, cx + 9, cy - 5, 8, 9, 0xFF2A5AC0); MapArt.rect(g, cx - 7, cy - 2, 2, 2, 0xFF3A2A3A); MapArt.rect(g, cx - 3, cy - 5, 3, 2, 0x88FFFFFF);
                }
                case 4 -> {
                    MapArt.ball(g, cx - 5, cy, 6, 0xFFC8952C); MapArt.ball(g, cx - 5, cy, 3, 0xFFFFFBF0);
                    MapArt.rect(g, cx, cy - 1, 11, 3, 0xFFC8952C); MapArt.rect(g, cx + 7, cy + 2, 2, 4, 0xFFC8952C); MapArt.rect(g, cx + 10, cy + 2, 2, 3, 0xFFC8952C);
                    MapArt.rect(g, cx, cy - 1, 11, 1, 0xFFFFD84D);
                }
                default -> {
                    MapArt.rect(g, cx - 9, cy - 1, 19, 8, 0xFFFFC832); MapArt.rect(g, cx - 9, cy + 5, 19, 2, 0xFFC8952C);
                    MapArt.tri(g, cx - 7, cy - 8, 5, 8, 0xFFFFC832); MapArt.tri(g, cx, cy - 11, 5, 11, 0xFFFFC832); MapArt.tri(g, cx + 7, cy - 8, 5, 8, 0xFFFFC832);
                    MapArt.ball(g, cx - 7, cy - 9, 1, 0xFFE5484D); MapArt.ball(g, cx, cy - 12, 1, 0xFF4D96FF); MapArt.ball(g, cx + 7, cy - 9, 1, 0xFF6BCB77);
                    MapArt.rect(g, cx - 1, cy + 1, 3, 3, 0xFFE5484D);
                }
            }
        }
    }

    // =====================================================================================================
    //  4. THE CAMP: roast three marshmallows, golden is best
    // =====================================================================================================
    static final class Camp extends Act {
        private int stick = 1, state, verdictT, points, last;           // state: 0 waiting, 1 roasting, 2 verdict
        private double roast, hold;                                     // roast 0..100, hold 0..1 (how far the stick is over the fire)
        private int best;

        Camp(int dest, Ctx c) { super(dest, c); }

        private static final int[] KEY_P = {0, 28, 55, 76, 100};
        private static final int[] KEY_C = {0xFFFFFFFF, 0xFFF4DC9C, 0xFFD89A4A, 0xFF8A5028, 0xFF2A2020};

        static int roastColor(double p) {
            for (int i = 0; i < KEY_P.length - 1; i++)
                if (p <= KEY_P[i + 1]) return MapArt.mix(KEY_C[i], KEY_C[i + 1], (float) ((p - KEY_P[i]) / (KEY_P[i + 1] - KEY_P[i])));
            return KEY_C[KEY_C.length - 1];
        }

        private int score(double p) { return p >= 52 && p <= 76 ? 3 : (p >= 30 && p < 52) || (p > 76 && p <= 92) ? 1 : 0; }

        @Override void tick() {
            super.tick();
            double to = state == 1 ? 1 : 0;
            hold += (to - hold) * 0.12;
            if (state == 1) {
                roast += 0.42;
                if (roast >= 100) finish();
            } else if (state == 2 && --verdictT <= 0) {
                if (stick >= 3) { over = true; give(points, 12 + points * 2, 5, 3 + points * 2); state = 3; }
                else { stick++; state = 0; roast = 0; }
            }
        }

        private void finish() {
            last = state == 1 && roast >= 100 ? 0 : score(roast);
            points += last;
            state = 2; verdictT = 95;
            c.snd().accept(last == 3 ? 2.0F : last == 1 ? 1.5F : 0.8F);
        }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(mx, my);
                if (r == 1) { stick = 1; state = 0; roast = 0; hold = 0; points = 0; over = false; paid = false; }
                else if (r == 2) c.exit().run();
                return true;
            }
            if (state == 0) { state = 1; roast = 0; c.snd().accept(1.3F); }
            else if (state == 1) finish();
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
            int floor = HEAD + (H - HEAD) * 70 / 100, fx = 300 * 66 / 100, fb = floor + 3;
            if (state == 1) MapArt.ball(g, fx, fb - 8, 14 + (int) (roast / 12), 0x20FFB040);
            ComputerColor col = c.color().get();
            pet(g, col, 126, floor + 10, 0.62F, ticks, c.stage().getAsInt(), state == 2 && last == 0 ? 0 : 2);
            // the stick: from the paw of the pet to over the fire (raised when waiting, lowered while roasting)
            int sx0 = 148, sy0 = floor - 10;
            int ex = fx - 2 - (int) Math.round((1 - hold) * 14), ey = (int) Math.round((fb - 46) + hold * 22);
            MapArt.ln(g, sx0, sy0, ex, ey, 0xFF8A5A3A); MapArt.ln(g, sx0, sy0 + 1, ex, ey + 1, 0xFF6E4726);
            double p = state == 1 || state == 2 ? roast : 0;
            int mc = roastColor(p);
            MapArt.rect(g, ex - 3, ey - 5, 7, 8, MapArt.mix(mc, 0xFF000000, 0.2F)); MapArt.rect(g, ex - 3, ey - 5, 7, 7, mc);
            MapArt.rect(g, ex - 2, ey - 4, 2, 2, MapArt.mix(mc, WHITE, 0.5F));
            if (p >= 90 && state == 1) for (int k = 0; k < 3; k++) MapArt.rect(g, ex - 3 + k * 3, ey - 8 - (ticks / 3 + k * 4) % 8, 1, 3, 0xFFFF7A2A);    // it is on fire
            if (state == 2 && last == 3) for (int k = 0; k < 4; k++) pixelStar(g, ex - 12 + k * 8, ey - 12 - (ticks / 4 + k * 5) % 6, 0xFFFFE680);
            header(g, mx, my, t("cutemod.act.k.stick", stick));
            // the meter: how done it is, with the golden zone marked
            int bx = 70, by = H - 14, bw = 160;
            Skin.rect(g, bx - 1, by - 1, bw + 2, 9, 0xFF1A1020);
            for (int x = 0; x < bw; x++) MapArt.rect(g, bx + x, by, 1, 7, roastColor(x * 100.0 / bw));
            MapArt.rect(g, bx + bw * 52 / 100, by - 2, bw * 24 / 100, 1, 0xFFFFE680); MapArt.rect(g, bx + bw * 52 / 100, by + 8, bw * 24 / 100, 1, 0xFFFFE680);
            if (state != 0) { int mx2 = bx + (int) Math.round(bw * Math.min(100, p) / 100); MapArt.rect(g, mx2 - 1, by - 3, 3, 13, WHITE); MapArt.rect(g, mx2, by - 3, 1, 13, 0xFF3A2A3A); }
            String msg = state == 0 ? t("cutemod.act.k.start") : state == 1 ? t("cutemod.act.k.pull") : t("cutemod.act.k.r." + (last == 3 ? 2 : last == 1 ? 1 : p >= 90 ? 3 : 0));
            Skin.str(g, f, msg, W / 2 - f.width(msg) / 2, HEAD + 5, WHITE, true);
            if (over) resultBox(g, mx, my, t("cutemod.act.k.end"), t("cutemod.act.k.pts", points), "", points);
        }
    }
}
