package dev.cutemod;

import dev.cutemod.block.ModBlockEntities;
import dev.cutemod.block.ModBlocks;
import dev.cutemod.net.RequestDataPayload;
import dev.cutemod.net.SaveDataPayload;
import dev.cutemod.net.ScorePayload;
import dev.cutemod.net.SyncDataPayload;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

@Mod(CuteMod.MOD_ID)
public class CuteMod {
    public static final String MOD_ID = "cutemod";

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final Supplier<CreativeModeTab> TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.cutemod"))
                    .icon(() -> new ItemStack(ModBlocks.get(ComputerColor.PINK).get()))
                    .displayItems((params, out) -> {
                        for (ComputerColor c : ComputerColor.values()) {
                            out.accept(ModBlocks.get(c).get());
                        }
                        for (net.minecraft.world.item.Item food : dev.cutemod.item.ModItems.foods()) {
                            out.accept(food);
                        }
                    })
                    .build());

    public CuteMod(IEventBus modBus) {
        ModBlocks.BLOCKS.register(modBus);
        ModBlocks.ITEMS.register(modBus);
        dev.cutemod.item.ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        TABS.register(modBus);
        modBus.addListener(CuteMod::registerPayloads);
        // the server sends each player what it has saved for them as soon as they join
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedInEvent e) -> RequestDataPayload.sendTo(e.getEntity()));
        if (FMLEnvironment.dist.isClient()) dev.cutemod.client.ClientHooks.init();
    }

    private static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("3");
        registrar.playToServer(ScorePayload.TYPE, ScorePayload.STREAM_CODEC, ScorePayload::handle);
        registrar.playToServer(SaveDataPayload.TYPE, SaveDataPayload.STREAM_CODEC, SaveDataPayload::handle);
        registrar.playToServer(RequestDataPayload.TYPE, RequestDataPayload.STREAM_CODEC, RequestDataPayload::handle);
        registrar.playToClient(SyncDataPayload.TYPE, SyncDataPayload.STREAM_CODEC, SyncDataPayload::handle);
        registrar.playToServer(dev.cutemod.net.MarketOrderPayload.TYPE, dev.cutemod.net.MarketOrderPayload.STREAM_CODEC, dev.cutemod.net.MarketOrderPayload::handle);
        registrar.playToServer(dev.cutemod.net.MarketPickupPayload.TYPE, dev.cutemod.net.MarketPickupPayload.STREAM_CODEC, dev.cutemod.net.MarketPickupPayload::handle);
        registrar.playToClient(dev.cutemod.net.MarketSyncPayload.TYPE, dev.cutemod.net.MarketSyncPayload.STREAM_CODEC, dev.cutemod.net.MarketSyncPayload::handle);
    }
}
