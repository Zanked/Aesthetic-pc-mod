package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

/**
 * CuteStore: buy games with coins, watch them install, play them from the library.
 * Tabs: Store (a "game of the day" with a discount + all games) and Library (your games).
 */
public class StoreApp extends App {
    private static final int HEAD = 18, ROW = 24, BANNER = 46, LROW = 28;
    private static final int BG = 0xFF1B1530, ROW_A = 0xFF231B3D, ROW_B = 0xFF1F1736, HOVER = 0xFF352A58;
    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFF9A90B8, GREEN = 0xFF5BD97A, YELLOW = 0xFFFFD866, ACCENT = 0xFFB57BD6;

    private int tab;
    private String detail;
    private int scroll, libScroll;
    // reviews page of a game
    private boolean reviews, typing;
    private int revScroll, pick;
    private String draft = "";

    private record Rev(String author, int stars, String text, boolean mine) {}

    @Override
    public Component title() { return Component.translatable("cutemod.os.store"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.store"); }

    /** Open the page of one game (used when you try to start a game you do not own). */
    public void show(String id) { tab = 0; openDetail(id); }

    private void openDetail(String id) {
        detail = id;
        reviews = false;
        typing = false;
        revScroll = 0;
    }

    private void openReviews() {
        reviews = true;
        revScroll = 0;
        typing = false;
        pick = Library.reviewStars(detail);
        draft = Library.reviewText(detail);
    }

    private List<Rev> reviewList(String id) {
        List<Rev> out = new ArrayList<>();
        if (Library.reviewStars(id) > 0) {
            out.add(new Rev(t("cutemod.store.you", Minecraft.getInstance().getUser().getName()), Library.reviewStars(id), Library.reviewText(id), true));
        }
        for (int i = 0; i < Library.NPC_REVIEWS; i++) {
            out.add(new Rev(Library.npcAuthor(id, i), Library.npcStars(id, i), t("cutemod.store.rev." + id + "." + i), false));
        }
        return out;
    }

    /** A tiny 5x5 star. */
    private static void star(GuiGraphics g, int x, int y, boolean filled) {
        int c = filled ? YELLOW : 0xFF4A3F6E;
        g.fill(x + 2, y, x + 3, y + 1, c);
        g.fill(x + 1, y + 1, x + 4, y + 2, c);
        g.fill(x, y + 2, x + 5, y + 3, c);
        g.fill(x + 1, y + 3, x + 4, y + 4, c);
        g.fill(x + 1, y + 4, x + 2, y + 5, c);
        g.fill(x + 3, y + 4, x + 4, y + 5, c);
    }

    private static void stars(GuiGraphics g, int x, int y, int n) {
        for (int i = 0; i < 5; i++) star(g, x + i * 7, y, i < n);
    }

    // ---------- helpers ----------
    private static void text(GuiGraphics g, String s, int x, int y, int argb) { g.drawString(font(), s, x, y, argb, false); }

    private static void bold(GuiGraphics g, String s, int x, int y, int argb) {
        g.drawString(font(), Component.literal(s).withStyle(ChatFormatting.BOLD), x, y, argb, false);
    }

    private static String fit(String s, int w) { return font().plainSubstrByWidth(s, w); }

    private static String genre(String id) { return t("cutemod.store.genre." + Library.game(id).genre()); }

    private static String rating(Library.Game gm) { return (gm.rating() / 10) + "." + (gm.rating() % 10); }

    private AppAction play(String id) {
        return () -> {
            for (ComputerColor c : ComputerColor.values()) {
                if (c.id.equals(id)) { shell.open(new GameApp(c)); return; }
            }
            shell.open(GameApp.extra(id));
        };
    }

    private interface AppAction { void run(); }

    private void scissorOn(GuiGraphics g) {
        g.enableScissor(shell.absX(), shell.absY() + HEAD, shell.absX() + W, shell.absY() + H);
    }

    /** Price (with the old price crossed out on sale) or the install state, right aligned to x. */
    private void status(GuiGraphics g, String id, int right, int y) {
        Font f = font();
        float p = Library.progress(id);
        if (p < 0) {
            int now = Library.priceNow(id), old = Library.game(id).price();
            boolean afford = Progress.coins() >= now;
            String ns = Integer.toString(now);
            int nx = right - f.width(ns);
            text(g, ns, nx, y, id.equals(Library.dealId()) ? (afford ? GREEN : 0xFFE5484D) : (afford ? WHITE : 0xFFE5484D));
            Progress.drawCoin(g, nx - 10, y);
            if (now != old) {
                String os = Integer.toString(old);
                int ox = nx - 14 - f.width(os);
                text(g, os, ox, y, MUTED);
                rect(g, ox, y + 4, f.width(os), 1, MUTED);
            }
        } else if (p < 1f) {
            rect(g, right - 50, y + 2, 50, 5, 0xFF3A2F5A);
            rect(g, right - 50, y + 2, (int) (50 * p), 5, ACCENT);
            String s = (int) (p * 100) + "%";
            text(g, s, right - 54 - f.width(s), y, MUTED);
        } else {
            String s = t("cutemod.store.installed");
            text(g, s, right - f.width(s), y, GREEN);
        }
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        rect(g, 0, 0, W, H, BG);
        if (detail != null) renderDetail(g, mx, my);
        else if (tab == 0) renderStore(g, mx, my);
        else renderLibrary(g, mx, my);

        // header
        Font f = font();
        rect(g, 0, 0, W, HEAD, 0xFF2A2040);
        bold(g, t("cutemod.os.store"), 6, 5, WHITE);
        int tx = 96;
        for (int i = 0; i < 2; i++) {
            boolean sel = detail == null && tab == i, hover = in(mx, my, tx + i * 56, 2, 54, 14);
            rect(g, tx + i * 56, 2, 54, 14, sel ? ACCENT : (hover ? 0xFF4A3A70 : 0xFF3A2F5A));
            String s = t("cutemod.store.tab." + i);
            text(g, s, tx + i * 56 + (54 - f.width(s)) / 2, 5, WHITE);
        }
        String bal = Integer.toString(Progress.coins());
        text(g, bal, W - 6 - f.width(bal), 5, 0xFFFFE680);
        Progress.drawCoin(g, W - 16 - f.width(bal), 5);
    }

    private int storeMax() { return Math.max(0, BANNER + Library.GAMES.size() * ROW - (H - HEAD)); }

    private void renderStore(GuiGraphics g, int mx, int my) {
        Font f = font();
        scissorOn(g);
        int y = HEAD - scroll;

        // game of the day
        String deal = Library.dealId();
        Library.Game dg = Library.game(deal);
        g.fillGradient(0, y, W, y + BANNER, 0xFF000000 | dg.rgb(), 0xFF1B1530);
        rect(g, 0, y, W, BANNER, 0x66000000);
        if (in(mx, my, 0, Math.max(HEAD, y), W, BANNER)) rect(g, 0, y, W, BANNER, 0x22FFFFFF);
        CoverArt.draw(g, deal, 8, y + 5, 36);
        text(g, t("cutemod.store.deal"), 52, y + 6, YELLOW);
        bold(g, fit(Library.name(deal), 150), 52, y + 17, WHITE);
        text(g, genre(deal) + "  -  " + t("cutemod.store.size", dg.sizeMb()), 52, y + 29, MUTED);
        rect(g, W - 44, y + 7, 36, 14, 0xFFE5484D);
        String pct = "-" + Library.dealPercent() + "%";
        text(g, pct, W - 44 + (36 - f.width(pct)) / 2, y + 10, WHITE);
        status(g, deal, W - 8, y + 30);
        y += BANNER;

        for (int i = 0; i < Library.GAMES.size(); i++, y += ROW) {
            if (y + ROW < HEAD || y > H) continue;
            Library.Game gm = Library.GAMES.get(i);
            rect(g, 0, y, W, ROW - 1, in(mx, my, 0, Math.max(HEAD, y), W, ROW - 1) && my >= HEAD ? HOVER : (i % 2 == 0 ? ROW_A : ROW_B));
            CoverArt.draw(g, gm.id(), 6, y + 2, 20);
            bold(g, fit(Library.name(gm.id()), 130), 32, y + 3, WHITE);
            text(g, genre(gm.id()) + "  -  " + rating(gm), 32, y + 13, MUTED);
            status(g, gm.id(), W - 10, y + 8);
        }
        g.disableScissor();
        if (storeMax() > 0) {
            int track = H - HEAD;
            int th = Math.max(8, track * track / (BANNER + Library.GAMES.size() * ROW));
            rect(g, W - 3, HEAD, 3, track, 0xFF2A2040);
            rect(g, W - 3, HEAD + (track - th) * scroll / storeMax(), 3, th, ACCENT);
        }
    }

    private List<String> ownedIds() {
        List<String> out = new ArrayList<>();
        for (Library.Game gm : Library.GAMES) if (Library.owned(gm.id())) out.add(gm.id());
        return out;
    }

    private int libMax() { return Math.max(0, ownedIds().size() * LROW - (H - HEAD)); }

    private void renderLibrary(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<String> ids = ownedIds();
        if (ids.isEmpty()) {
            List<FormattedCharSequence> lines = f.split(FormattedText.of(t("cutemod.store.empty")), W - 60);
            for (int i = 0; i < lines.size(); i++) {
                FormattedCharSequence s = lines.get(i);
                g.drawString(f, s, (W - f.width(s)) / 2, 70 + i * 10, MUTED, false);
            }
            return;
        }
        scissorOn(g);
        int y = HEAD - libScroll;
        for (int i = 0; i < ids.size(); i++, y += LROW) {
            if (y + LROW < HEAD || y > H) continue;
            String id = ids.get(i);
            rect(g, 0, y, W, LROW - 1, in(mx, my, 0, Math.max(HEAD, y), W, LROW - 1) && my >= HEAD ? HOVER : (i % 2 == 0 ? ROW_A : ROW_B));
            CoverArt.draw(g, id, 6, y + 3, 22);
            bold(g, fit(Library.name(id), 150), 34, y + 4, WHITE);
            float p = Library.progress(id);
            if (p >= 1f) {
                String sub = t("cutemod.store.played", Library.playTime(id)) + "   " + t("cutemod.store.best", Library.best(id));
                text(g, fit(sub, 170), 34, y + 15, MUTED);
                boolean hover = in(mx, my, W - 58, y + 6, 50, 16);
                rect(g, W - 58, y + 6, 50, 16, hover ? 0xFF7BE890 : GREEN);
                String s = t("cutemod.store.play");
                text(g, s, W - 58 + (50 - f.width(s)) / 2, y + 10, 0xFF12301A);
            } else {
                text(g, t("cutemod.store.installing", (int) (p * 100)), 34, y + 15, MUTED);
                rect(g, W - 98, y + 12, 90, 5, 0xFF3A2F5A);
                rect(g, W - 98, y + 12, (int) (90 * p), 5, ACCENT);
            }
        }
        g.disableScissor();
    }

    private void renderDetail(GuiGraphics g, int mx, int my) {
        Font f = font();
        String id = detail;
        Library.Game gm = Library.game(id);
        if (reviews) { renderReviews(g, mx, my); return; }
        boolean backHover = in(mx, my, 6, 22, 46, 12);
        rect(g, 6, 22, 46, 12, backHover ? 0xFF4A3A70 : 0xFF3A2F5A);
        text(g, t("cutemod.store.back"), 6 + (46 - f.width(t("cutemod.store.back"))) / 2, 24, WHITE);
        String rb = t("cutemod.store.reviews", Library.NPC_REVIEWS + (Library.reviewStars(id) > 0 ? 1 : 0));
        boolean rbHover = in(mx, my, W - 98, 22, 92, 12);
        rect(g, W - 98, 22, 92, 12, rbHover ? 0xFF8A6AC6 : ACCENT);
        text(g, rb, W - 98 + (92 - f.width(rb)) / 2, 24, WHITE);

        rect(g, 7, 41, 82, 82, 0xFF000000);
        CoverArt.draw(g, id, 8, 42, 80);

        int x = 98;
        bold(g, fit(Library.name(id), 190), x, 38, WHITE);
        text(g, fit(genre(id) + "  -  " + t("cutemod.store.size", gm.sizeMb()) + "  -  " + t("cutemod.store.rating", rating(gm)), 192), x, 49, MUTED);
        List<FormattedCharSequence> lines = f.split(FormattedText.of(t("cutemod.store.blurb." + id)), 192);
        for (int i = 0; i < lines.size() && i < 5; i++) g.drawString(f, lines.get(i), x, 62 + i * 10, 0xFFD8D0EE, false);

        float p = Library.progress(id);
        if (p < 0) {
            int now = Library.priceNow(id), old = gm.price();
            boolean afford = Progress.coins() >= now;
            Progress.drawCoin(g, x, 125);
            String ns = Integer.toString(now);
            text(g, ns, x + 11, 125, afford ? WHITE : 0xFFE5484D);
            int cx = x + 11 + f.width(ns) + 6;
            if (now != old) {
                String os = Integer.toString(old);
                text(g, os, cx, 125, MUTED);
                rect(g, cx, 129, f.width(os), 1, MUTED);
                rect(g, cx + f.width(os) + 6, 123, 30, 12, 0xFFE5484D);
                text(g, "-" + Library.dealPercent() + "%", cx + f.width(os) + 9, 125, WHITE);
            }
            boolean hover = afford && in(mx, my, x, 139, 110, 18);
            rect(g, x, 139, 110, 18, !afford ? 0xFF3A2F5A : hover ? 0xFF7BE890 : GREEN);
            String s = afford ? t("cutemod.store.buy") : t("cutemod.store.poor");
            text(g, s, x + (110 - f.width(s)) / 2, 144, afford ? 0xFF12301A : MUTED);
        } else if (p < 1f) {
            text(g, t("cutemod.store.installing", (int) (p * 100)), x, 124, WHITE);
            rect(g, x, 136, 190, 8, 0xFF3A2F5A);
            rect(g, x, 136, (int) (190 * p), 8, ACCENT);
            text(g, t("cutemod.store.eta", Library.secondsLeft(id)), x, 148, MUTED);
        } else {
            boolean hover = in(mx, my, x, 134, 100, 20);
            rect(g, x, 134, 100, 20, hover ? 0xFF7BE890 : GREEN);
            String s = t("cutemod.store.play");
            text(g, s, x + (100 - f.width(s)) / 2, 140, 0xFF12301A);
            text(g, t("cutemod.store.played", Library.playTime(id)), 206, 130, MUTED);
            text(g, t("cutemod.store.best", Library.best(id)), 206, 142, MUTED);
        }
    }

    private static final int REV_TOP = 38, REV_BOTTOM = 118;

    private int revHeight(Rev r) {
        int lines = Math.max(1, Math.min(2, font().split(FormattedText.of(r.text()), 266).size()));
        return 12 + lines * 9 + 5;
    }

    private int revContent(List<Rev> list) {
        int h = 0;
        for (Rev r : list) h += revHeight(r);
        return h;
    }

    private void renderReviews(GuiGraphics g, int mx, int my) {
        Font f = font();
        String id = detail;
        Library.Game gm = Library.game(id);
        boolean backHover = in(mx, my, 6, 22, 46, 12);
        rect(g, 6, 22, 46, 12, backHover ? 0xFF4A3A70 : 0xFF3A2F5A);
        text(g, t("cutemod.store.back"), 6 + (46 - f.width(t("cutemod.store.back"))) / 2, 24, WHITE);
        List<Rev> list = reviewList(id);
        bold(g, fit(Library.name(id), 150), 58, 24, WHITE);
        String sum = t("cutemod.store.rating", rating(gm)) + " (" + list.size() + ")";
        text(g, sum, W - 6 - f.width(sum), 24, MUTED);

        // the list
        g.enableScissor(shell.absX(), shell.absY() + REV_TOP, shell.absX() + W, shell.absY() + REV_BOTTOM);
        int y = REV_TOP - revScroll, i = 0;
        for (Rev r : list) {
            int h = revHeight(r);
            if (y + h >= REV_TOP && y <= REV_BOTTOM) {
                rect(g, 0, y, W, h - 1, r.mine() ? 0xFF2F2550 : (i % 2 == 0 ? ROW_A : ROW_B));
                bold(g, fit(r.author(), 150), 8, y + 3, r.mine() ? YELLOW : WHITE);
                stars(g, W - 8 - 33, y + 4, r.stars());
                List<FormattedCharSequence> lines = f.split(FormattedText.of(r.text()), 266);
                for (int l = 0; l < lines.size() && l < 2; l++) g.drawString(f, lines.get(l), 8, y + 14 + l * 9, 0xFFD8D0EE, false);
            }
            y += h;
            i++;
        }
        g.disableScissor();
        int max = Math.max(0, revContent(list) - (REV_BOTTOM - REV_TOP));
        revScroll = Math.min(revScroll, max);
        if (max > 0) {
            int track = REV_BOTTOM - REV_TOP, th = Math.max(8, track * track / revContent(list));
            rect(g, W - 3, REV_TOP, 3, track, 0xFF2A2040);
            rect(g, W - 3, REV_TOP + (track - th) * revScroll / max, 3, th, ACCENT);
        }

        // write your own
        rect(g, 0, REV_BOTTOM, W, H - REV_BOTTOM, 0xFF2A2040);
        if (!Library.owned(id)) {
            String s = t("cutemod.store.rev_locked");
            text(g, s, (W - f.width(s)) / 2, 138, MUTED);
            return;
        }
        text(g, t("cutemod.store.your_rating"), 8, 124, WHITE);
        for (int k = 0; k < 5; k++) star(g, 90 + k * 12, 123, k < pick);
        rect(g, 8, 138, 220, 14, typing ? 0xFF4A3A70 : 0xFF3A2F5A);
        String shown = draft.isEmpty() && !typing ? t("cutemod.store.write_hint") : draft + (typing && (System.currentTimeMillis() / 400) % 2 == 0 ? "_" : "");
        g.drawString(f, f.plainSubstrByWidth(shown, 214, true), 12, 141, draft.isEmpty() && !typing ? MUTED : WHITE, false);
        boolean can = pick > 0;
        boolean hov = can && in(mx, my, 234, 138, 58, 14);
        rect(g, 234, 138, 58, 14, !can ? 0xFF3A2F5A : hov ? 0xFF7BE890 : GREEN);
        String post = t(Library.reviewStars(id) > 0 ? "cutemod.store.update" : "cutemod.store.post");
        text(g, post, 234 + (58 - f.width(post)) / 2, 141, can ? 0xFF12301A : MUTED);
        text(g, t("cutemod.store.rev_hint"), 8, 155, MUTED);
    }

    private void postReview() {
        if (pick <= 0 || detail == null || !Library.owned(detail)) return;
        boolean first = Library.setReview(detail, pick, draft.trim());
        Progress.toast("cutemod.toast.review_posted");
        if (first) Progress.earn(3);
        typing = false;
        revScroll = 0;
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (y < HEAD) {
            for (int i = 0; i < 2; i++) {
                if (in(x, y, 96 + i * 56, 2, 54, 14)) { tab = i; detail = null; reviews = false; typing = false; return true; }
            }
            return true;
        }
        if (detail != null && reviews) {
            if (in(x, y, 6, 22, 46, 12)) { reviews = false; typing = false; return true; }
            if (Library.owned(detail)) {
                for (int k = 0; k < 5; k++) if (in(x, y, 90 + k * 12 - 1, 121, 12, 10)) { pick = k + 1; typing = false; return true; }
                if (in(x, y, 8, 138, 220, 14)) { typing = true; return true; }
                if (in(x, y, 234, 138, 58, 14)) { postReview(); return true; }
            }
            typing = false;
            return true;
        }
        if (detail != null) {
            String id = detail;
            if (in(x, y, 6, 22, 46, 12)) { detail = null; return true; }
            if (in(x, y, W - 98, 22, 92, 12)) { openReviews(); return true; }
            float p = Library.progress(id);
            if (p < 0 && in(x, y, 98, 139, 110, 18)) { Library.buy(id); return true; }
            if (p >= 1f && in(x, y, 98, 134, 100, 20)) { play(id).run(); return true; }
            return true;
        }
        if (tab == 0) {
            int cy = y - HEAD + scroll;
            if (cy < BANNER) { openDetail(Library.dealId()); return true; }
            int idx = (cy - BANNER) / ROW;
            if (idx >= 0 && idx < Library.GAMES.size()) openDetail(Library.GAMES.get(idx).id());
            return true;
        }
        List<String> ids = ownedIds();
        int idx = (y - HEAD + libScroll) / LROW;
        if (idx >= 0 && idx < ids.size()) {
            String id = ids.get(idx);
            int rowY = HEAD + idx * LROW - libScroll;
            if (Library.installed(id) && in(x, y, W - 58, rowY + 6, 50, 16)) play(id).run();
            else openDetail(id);
        }
        return true;
    }

    @Override
    public boolean scroll(double amount) {
        if (detail != null && reviews) {
            int max = Math.max(0, revContent(reviewList(detail)) - (REV_BOTTOM - REV_TOP));
            revScroll = Math.max(0, Math.min(max, revScroll - (int) Math.signum(amount) * 14));
            return true;
        }
        if (detail != null) return false;
        if (tab == 0) scroll = Math.max(0, Math.min(storeMax(), scroll - (int) Math.signum(amount) * ROW));
        else libScroll = Math.max(0, Math.min(libMax(), libScroll - (int) Math.signum(amount) * LROW));
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (typing) {
            if (keyCode == 259) { if (!draft.isEmpty()) draft = draft.substring(0, draft.length() - 1); return true; }   // Backspace
            if (keyCode == 257 || keyCode == 335) { postReview(); return true; }                                          // Enter
            return false;
        }
        if (keyCode == 259 && detail != null) {                                  // Backspace: one page back
            if (reviews) reviews = false; else detail = null;
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        if (!typing || c < 32 || c == 127 || draft.length() >= 70) return false;
        draft += c;
        return true;
    }
}
