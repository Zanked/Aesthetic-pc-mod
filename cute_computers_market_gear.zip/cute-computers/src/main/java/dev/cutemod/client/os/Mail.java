package dev.cutemod.client.os;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

/**
 * The mail: letters that arrive over real time and when the player does things. All state lives in the
 * Progress counters (so it is saved with the rest): mail_t0 = minute of the first visit, mr_ID = read,
 * mc_ID = reward taken, mn_ID = the player was already told about it.
 */
public final class Mail {
    private Mail() {}

    /** from: 0 system, 1 Pandochka, 2 Bee, 3 the stranger. delayMin: minutes after the first visit. */
    public record Msg(String id, int from, int delayMin, BooleanSupplier cond, int reward) {}

    private static final BooleanSupplier ALWAYS = () -> true;

    /** A reply that arrives after the player wrote the matching word in the "Write" box (counter ms_KEY). */
    private static BooleanSupplier sent(String key) { return () -> Progress.count("ms_" + key) > 0; }

    /** Words the player can write -> which reply comes back. Russian and English, ye/yo are treated the same. */
    private static final String[][] WORDS = {
            {"honey", "honey", "\u043c\u0435\u0434", "bee", "\u043f\u0447\u0435\u043b", "\u0431\u0437\u0437", "bzz"},
            {"panda", "panda", "\u043f\u0430\u043d\u0434\u0430", "bamboo", "\u0431\u0430\u043c\u0431\u0443\u043a"},
            {"creeper", "creeper", "\u043a\u0440\u0438\u043f\u0435\u0440", "boom", "\u0431\u0443\u043c"},
            {"secret", "secret", "\u0441\u0435\u043a\u0440\u0435\u0442", "whoami", "\u043a\u0442\u043e \u0442\u044b"},
    };

    public static final Msg[] MSGS = {
            new Msg("hello", 0, 0, ALWAYS, 5),
            new Msg("games", 1, 3, ALWAYS, 0),
            new Msg("first_game", 2, 0, () -> Progress.count("games") >= 1, 3),
            new Msg("pet", 1, 0, () -> Progress.count("feed") >= 1, 3),
            new Msg("strange", 3, 0, () -> Progress.step() >= 1, 0),
            new Msg("streak3", 0, 0, () -> Progress.streak() >= 3, 10),
            new Msg("day1", 1, 1440, ALWAYS, 5),
            new Msg("rich", 2, 0, () -> Progress.count("earned") >= 100, 10),
            new Msg("day3", 2, 4320, ALWAYS, 15),
            new Msg("quest_done", 3, 0, () -> Progress.step() >= Progress.PART1, 20),
            // part 2 of the story: the stranger ("Me") writes again, one hint per chapter
            new Msg("p2_hello", 3, 0, () -> Progress.step() >= 7, 0),
            new Msg("p2_window", 3, 0, () -> Progress.step() >= 8, 0),
            new Msg("p2_song", 3, 0, () -> Progress.step() >= 9, 0),
            new Msg("p2_draw", 3, 0, () -> Progress.step() >= 10, 0),
            new Msg("p2_note", 3, 0, () -> Progress.step() >= 11, 0),
            new Msg("p2_choice", 3, 0, () -> Progress.step() >= 12, 0),
            new Msg("p2_stay", 3, 0, () -> Progress.questDone() && Progress.ending() == 1, 30),
            new Msg("p2_bye", 3, 0, () -> Progress.questDone() && Progress.ending() == 2, 30),
            new Msg("week", 0, 10080, ALWAYS, 30),
            // the Halloween event (the letters stay once they have come)
            new Msg("hw_party", 1, 0, () -> Progress.count("hw_seen") > 0, 10),
            new Msg("hw_bee", 2, 0, () -> Halloween.candyAll() >= 10, 5),
            new Msg("hw_stranger", 3, 0, () -> Halloween.candyAll() >= 30, 15),
            // replies to letters the player writes (they sit on top of the inbox once they arrive)
            new Msg("re_honey", 2, 0, sent("honey"), 5),
            new Msg("re_panda", 1, 0, sent("panda"), 5),
            new Msg("re_creeper", 0, 0, sent("creeper"), 5),
            new Msg("re_secret", 3, 0, sent("secret"), 10),
            new Msg("re_none", 0, 0, sent("none"), 0),
    };

    private static int pollTimer;

    private static int nowMin() { return (int) (System.currentTimeMillis() / 60_000L); }

    private static int t0() {
        int t = Progress.count("mail_t0");
        if (t == 0) { t = nowMin(); Progress.setCount("mail_t0", t); }
        return t;
    }

    public static boolean arrived(Msg m) {
        return nowMin() - t0() >= m.delayMin() && m.cond().getAsBoolean();
    }

    public static boolean read(Msg m) { return Progress.count("mr_" + m.id()) > 0; }

    public static boolean claimed(Msg m) { return Progress.count("mc_" + m.id()) > 0; }

    public static boolean unread(Msg m) { return arrived(m) && !read(m); }

    /** Letters that have arrived, newest first. */
    public static List<Msg> inbox() {
        List<Msg> out = new ArrayList<>();
        for (int i = MSGS.length - 1; i >= 0; i--) if (arrived(MSGS[i])) out.add(MSGS[i]);
        return out;
    }

    public static int unreadCount() {
        int n = 0;
        for (Msg m : MSGS) if (unread(m)) n++;
        return n;
    }

    public static void markRead(Msg m) {
        if (!read(m)) Progress.setCount("mr_" + m.id(), 1);
    }

    public static boolean claim(Msg m) {
        if (m.reward() <= 0 || claimed(m)) return false;
        Progress.setCount("mc_" + m.id(), 1);
        Progress.earn(m.reward());
        Progress.bump("mail_claims");
        return true;
    }

    /**
     * The player wrote a letter. A known word brings its reply (once); anything else gets a polite
     * "nobody understood" from the system. Returns true if a word was understood.
     */
    public static boolean send(String text) {
        String t = text == null ? "" : text.toLowerCase(java.util.Locale.ROOT).replace('\u0451', '\u0435').trim();
        if (t.isEmpty()) return false;
        Progress.bump("mail_sent");
        for (String[] w : WORDS) {
            for (int i = 1; i < w.length; i++) {
                if (t.contains(w[i].replace('\u0451', '\u0435'))) {
                    if (Progress.count("ms_" + w[0]) == 0) Progress.setCount("ms_" + w[0], 1);
                    return true;
                }
            }
        }
        if (Progress.count("ms_none") == 0) Progress.setCount("ms_none", 1);
        return false;
    }

    /** Called 60 times per second; once a second it looks for new letters and tells the player. */
    public static void tick() {
        if (++pollTimer < 60) return;
        pollTimer = 0;
        if (Progress.count("hw_seen") == 0 && Halloween.active()) Progress.setCount("hw_seen", 1);
        int fresh = 0;
        Msg last = null;
        for (Msg m : MSGS) {
            if (arrived(m) && Progress.count("mn_" + m.id()) == 0) {
                Progress.setCount("mn_" + m.id(), 1);
                fresh++;
                last = m;
            }
        }
        if (fresh == 1) Progress.mailToast("cutemod.toast.mail", net.minecraft.network.chat.Component.translatable("cutemod.mail.from." + last.from()).getString());
        else if (fresh > 1) Progress.mailToast("cutemod.toast.mail_n", fresh);
    }
}
