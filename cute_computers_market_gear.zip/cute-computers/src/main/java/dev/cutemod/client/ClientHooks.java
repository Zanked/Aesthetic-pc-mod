package dev.cutemod.client;

import dev.cutemod.ComputerColor;
import dev.cutemod.client.os.Store;
import dev.cutemod.net.RequestDataPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;

/** Kept in a separate class so the dedicated server never loads client-only code. */
public class ClientHooks {
    /** Called once on the client: forget the server's data when we disconnect. */
    public static void init() {
        NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingOut e) -> Store.clear());
    }

    /** The server sent what it has saved for us. */
    public static void onSync(Map<String, String> data) {
        Store.apply(data);
    }

    /** The server told us which parcels are on their way (and maybe gave coins back). */
    public static void onMarketSync(dev.cutemod.net.MarketSyncPayload p) {
        dev.cutemod.client.os.Market.applyServer(p);
    }

    public static void openComputer(ComputerColor color, BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        if (!Store.ready()) {                       // the server's copy of our data has not arrived yet
            PacketDistributor.sendToServer(new RequestDataPayload());
            if (mc.player != null) mc.player.displayClientMessage(Component.translatable("cutemod.sync.wait"), true);
            return;
        }
        mc.setScreen(new ComputerScreen(color, pos));
    }

    private ClientHooks() {}
}
