package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;

/** What an app can ask of the computer it is running on. */
public interface Shell {
    /** Open an app (the previous one is closed). */
    void open(App app);

    /** Go back to the desktop. */
    void home();

    /** Where this computer stands (the server checks orders and pick-ups against it). */
    net.minecraft.core.BlockPos pos();

    /** Color of this computer (also decides its "own" game). */
    ComputerColor color();

    /** Ask to open a real web address (the player confirms first, then it opens in the system browser). */
    void openLink(String url);

    /** A game finished with this score. Only the computer's own game counts for its record. */
    void submitScore(ComputerColor game, int score);

    /** Absolute GUI position of the top-left corner of the app area (for scissor). */
    int absX();

    int absY();
}
