package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * "Zombie Shooter": a first-person wave shooter in the style of Call of Duty Zombies.
 * Five rooms (a hall and four rooms behind doors you pay for), endless rounds, boarded windows the zombies tear down
 * and you nail back up, headshots, power-ups that drop from zombies, a wall station to buy a rifle / shotgun and ammo.
 * Same "one ray per screen column" raycaster as Dark Corridor, now with textured walls and floor.
 *
 * Controls: W/S walk, A/D strafe, mouse near the left/right edge or arrow keys to turn,
 * mouse above / below the middle (or the up / down arrows) to look up / down (aim at the head!),
 * LMB or Space to shoot, R reload, 1/2/3/Q switch weapon,
 * E buys at the golden (rifle) or teal (shotgun) wall and opens doors, hold E at a window to repair it,
 * B buy mines, F lay a mine. After every round you pick 1 of 3 perks (keys 1-3 or click).
 * Zombie kinds: normal, runner (round 3+), tank (5+), spitter (7+).
 * Power-ups: max ammo, insta-kill, nuke, double points, carpenter (fixes every window), medkit.
 */
public class ZombieShooter extends MiniGame {
    private static final int MW = 32, MH = 24;
    private static final int COLS = 110, CW = W / COLS;
    private static final double PLANE = 0.75;
    private static final int MINE_COST = 1000, MAX_MINES = 6, BOX_COST = 950;
    // The points work like in CoD Zombies: you start with 500, a bullet that hurts a zombie gives 10, the killing shot 60
    // (100 for a headshot), a nailed board 10. Nothing for just clearing a round. Prices: see the gun table and DOOR_COST.
    private static final int START_PTS = 500, HIT_PTS = 10, KILL_PTS = 60, HEAD_PTS = 100, BOARD_PTS = 10;
    private static final int PERKS = 6, CARD_W = 66;
    private static final double DEAD = 0.1;                      // the middle of the screen where the mouse does not turn you
    private static final double MAXP = 24, PDEAD = 0.35;          // looking up / down: most pixels the horizon moves, dead zone of the mouse
    private static final int MAX_BOARDS = 5;
    private static final int[] DOOR_COST = {0, 750, 750, 1250, 1250};
    private static final int[] PERK_COL = {0xFF5AB0F0, 0xFFE0603A, 0xFFF0D84A, 0xFF5FD35A, 0xFFE070B0, 0xFFB57BD6};
    private static final int[] KIND_DMG = {25, 15, 40, 25};          // a bite
    private static final double[] KIND_SIZE = {0.9, 0.8, 1.25, 0.9};   // body height compared with a wall
    private static final double HEAD = 0.69;                         // the top 31 % of a zombie is its head

    // tiles: 0 floor, 1 wall, 2 crate, 3 golden wall (rifle), 4 teal wall (shotgun), 5 door, 6 boarded window, 7 open window,
    //        8 green wall (SMG), 9 red wall (magnum), 10 purple wall (sniper), 11 mystery box, 12 cracked wall (secret door)
    // '#' wall, '.' floor, 'c' crate, 'S' rifle 'T' shotgun 'U' SMG 'G' magnum 'K' sniper, 'X' mystery box, 'Z' cracked wall,
    // '1'-'4' doors (price from DOOR_COST), 'W' window, 'p' outside pocket
    private static final String[] LEVEL = {
            "################K###############",
            "##############.....#######X#####",
            "###########pp#.....#pp##......##",
            "###########ppW..c..Wpp##......##",
            "##############.....#####......##",
            "###########pp#.....#pp##......##",
            "###########pp#.....#pp##.#######",
            "###pp#######W#S#3###W###.##pp###",
            "###pp######...........##.##pp###",
            "####W##U###...........U#Z##W####",
            "#.........#...c...c...#........#",
            "#.........#...........#........#",
            "T...c..c..1..c.....c..2....c...T",
            "#.........#...........#........#",
            "#.........#...c...c...#........#",
            "######W####...........###W###G##",
            "#####pp####...........##pp######",
            "#####pp#####W###4#G#W###pp######",
            "###########pp#.....#pp##########",
            "###########pp#.....#pp##########",
            "##############..c..#############",
            "###########ppW.....Wpp##########",
            "###########pp#.....#pp##########",
            "################S###############"
    };
    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    /** A blocky zombie, one char = one pixel. g/G skin, b shirt, p trousers, r eyes, k shoes. */
    private static final String[] ZOMBIE = {
            "..GGGG..", ".gggggg.", ".grggrg.", ".gggggg.", "..gggg..", "bbbbbbbb", "gbbbbbbg", "gbbbbbbg",
            "gbbbbbbg", ".bbbbbb.", ".bbbbbb.", ".pppppp.", ".pp..pp.", ".pp..pp.", ".pp..pp.", ".kk..kk."};

    // ---------- power-ups ----------
    private static final int D_AMMO = 0, D_INSTA = 1, D_NUKE = 2, D_DOUBLE = 3, D_CARPENTER = 4, D_MED = 5;
    private static final int[] DROP_COL = {0xFF3A78C8, 0xFFC83A3A, 0xFFE07A20, 0xFFD8B020, 0xFF8A5A2A, 0xFF3AA05A};
    private static final int[] DROP_W = {25, 15, 10, 20, 15, 15};     // how likely each one is
    private static final String[][] ICON = {
            {".ooooo.", "owowowo", "owowowo", "owowowo", "owowowo", "ooooooo", ".ooooo."},   // max ammo: bullets
            {".ooooo.", "owwwwwo", "owowowo", "owwwwwo", ".owwwo.", ".owowo.", "..ooo.."},   // insta-kill: a skull
            {"..ooo..", ".owwwo.", "owwwwwo", ".owwwo.", "..owo..", "..owo..", ".ooooo."},   // nuke: a mushroom cloud
            {"ooooooo", "owwwwwo", "ooooowo", "owwwwwo", "owooooo", "owwwwwo", "ooooooo"},   // double points: a 2
            {"ooooooo", "owwwwwo", "ooooooo", "owwwwwo", "ooooooo", "owwwwwo", "ooooooo"},   // carpenter: planks
            {"ooooooo", "ooowooo", "ooowooo", "owwwwwo", "ooowooo", "ooowooo", "ooooooo"}};  // medkit: a cross

    // ---------- textures (16 x 8 texels, built once) ----------
    private static final int TW = 16, TH = 8;
    private static final int[][][] TEX = new int[13][TH][TW];         // 1 brick, 2 crate, 3 gold, 4 teal, 5 door, 8 green, 9 red, 10 purple, 11 box, 12 cracked brick
    private static final int[] PLANK_ROW = {3, 5, 1, 4, 2};           // the rows the boards of a window cover, in order
    private static final int[][] ZONE_ANCHOR = {{16, 12, 0xFF7C7468}, {3, 12, 0xFF6E5638}, {26, 12, 0xFF566878}, {15, 3, 0xFF7A3E3E}, {15, 20, 0xFF4E6E52}, {26, 4, 0xFF4A3A6A}};   // x, y, floor color of that room
    private static final int POCKET_FLOOR = 0xFF3A2E22, SILL_FLOOR = 0xFF5A4630;

    static {
        for (int v = 0; v < TH; v++) {
            for (int u = 0; u < TW; u++) {
                // 1: red brick, laid in staggered courses
                int course = v / 2, off = course % 2 == 0 ? 0 : 4, bu = u + off;
                int brick;
                if (v % 2 == 0 || bu % 8 == 0) brick = 0xFF57514B;
                else {
                    int[] bricks = {0xFF8E4B3B, 0xFF9C5642, 0xFF7F4234, 0xFF93503F};
                    brick = bricks[(hash(bu / 8, course) & 3)];
                }
                TEX[1][v][u] = brick;
                // 12: the same brick, but cracked and a little darker: the secret door
                boolean crack = (u == 7 && v == 1) || (u == 8 && (v == 2 || v == 3)) || (u == 9 && v == 4) || (u == 10 && v == 5) || (u == 9 && v == 6)
                        || (u == 6 && v == 3) || (u == 5 && v == 4) || (u == 11 && v == 3) || (u == 12 && v == 2);
                TEX[12][v][u] = crack ? 0xFF1C1816 : shade(brick, 0.82);
                // 2: a wooden crate with a cross
                if (u == 0 || u == TW - 1 || v == 0 || v == TH - 1) TEX[2][v][u] = 0xFF5A3A1C;
                else if (v * 2 == u || v * 2 == TW - 1 - u) TEX[2][v][u] = 0xFF7A5128;
                else TEX[2][v][u] = v % 2 == 0 ? 0xFF9A6B3A : 0xFF8F6335;
                // 3: the golden wall (rifle) with a rifle on it
                boolean edge = u == 0 || u == TW - 1 || v == 0 || v == TH - 1;
                int gold = edge ? 0xFFE8C860 : 0xFFB8902C;
                if ((v == 3 && u >= 2 && u <= 13) || (v == 4 && (u == 3 || u == 4 || u == 9 || u == 10)) || (v == 2 && u >= 10 && u <= 12)) gold = 0xFF2A1E08;
                TEX[3][v][u] = gold;
                // 4: the teal wall (shotgun) with two barrels on it
                int teal = edge ? 0xFF70D0E8 : 0xFF2A8098;
                if (((v == 3 || v == 4) && u >= 2 && u <= 13) || (v == 5 && u >= 2 && u <= 4)) teal = 0xFF08242C;
                TEX[4][v][u] = teal;
                // 5: a steel door with hazard stripes, a lock and rivets
                int door = 0xFF66727E;
                if (u == 0 || u == TW - 1 || u == 8) door = 0xFF4A5560;
                if (v == 0) door = (u / 2) % 2 == 0 ? 0xFFE8C020 : 0xFF1A1A1A;
                if (u >= 10 && u <= 13 && v >= 2 && v <= 5) door = 0xFF3A424C;
                if (u == 12 && (v == 3 || v == 4)) door = 0xFFE0E0E0;
                if ((u == 2 || u == 6 || u == 14) && (v == 2 || v == 6)) door = 0xFFB8C4D0;
                TEX[5][v][u] = door;
                // 8: the green wall (SMG): a short gun with a magazine
                int smg = edge ? 0xFF7ADC8A : 0xFF2E7A3E;
                if ((v == 3 && u >= 2 && u <= 13) || (v == 4 && (u == 4 || u == 5 || u == 10 || u == 11)) || (v == 5 && (u == 10 || u == 11))) smg = 0xFF08200C;
                TEX[8][v][u] = smg;
                // 9: the red wall (magnum): a big revolver
                int mag = edge ? 0xFFF0A070 : 0xFFA84A28;
                if ((v == 3 && u >= 4 && u <= 13) || (v == 4 && (u == 4 || u == 5 || u == 6 || u == 7)) || (v == 5 && (u == 4 || u == 5))) mag = 0xFF2A0E04;
                TEX[9][v][u] = mag;
                // 10: the purple wall (sniper): a long barrel with a scope
                int snp = edge ? 0xFFD0A0F0 : 0xFF6A3A9A;
                if ((v == 3 && u >= 1 && u <= 14) || (v == 2 && u >= 6 && u <= 9) || (v == 4 && u >= 2 && u <= 4)) snp = 0xFF1A0A2A;
                TEX[10][v][u] = snp;
                // 11: the mystery box: a dark chest with a golden question mark
                int box = edge ? 0xFFE8C860 : 0xFF1E2A44;
                boolean q = (v == 1 && (u == 7 || u == 8)) || (v == 2 && (u == 6 || u == 9)) || (v == 3 && u == 9) || (v == 4 && u == 8) || (v == 6 && u == 8);
                if (q) box = 0xFFFFD84A;
                TEX[11][v][u] = box;
            }
        }
    }

    private static int hash(int a, int b) {
        int h = a * 374761393 + b * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        return (h ^ (h >>> 16)) & 0x7FFFFFFF;
    }

    /** A boarded window: a dark frame with night behind it and up to 5 planks nailed across. */
    private static int windowTexel(int u, int v, int boards) {
        for (int k = 0; k < boards && k < MAX_BOARDS; k++) {
            if (v == PLANK_ROW[k]) {
                if (u == 1 || u == TW - 2) return 0xFF3A3A3A;                    // nails
                return (hash(k, u / 5) & 1) == 0 ? 0xFFA27B4A : 0xFF90693C;
            }
        }
        if (u == 0 || u == TW - 1 || v == 0 || v == TH - 1 || u == 7 || u == 8) return 0xFF4A3220;   // frame and the middle bar
        if (u >= 10 && u <= 13 && v <= 2) return 0xFF22324E;                      // a bit of moon
        return 0xFF0A101C;
    }

    private static int texel(int type, int u, int v, int boards) {
        return type == 6 ? windowTexel(u, v, boards) : TEX[type][v][u];
    }

    // ---------- classes ----------
    /** A gun. pellets > 1 is a shotgun, pierce > 1 goes through several zombies, splash > 0 hurts the ones next to the target. */
    private static final class Weapon {
        final boolean auto, infinite;
        final int col, magSize, maxReserve, dmg, rate, reloadTime, pellets, pierce, cost, ammoCost;
        final double push, splash;
        boolean owned;
        int mag, reserve;

        Weapon(int col, boolean auto, boolean infinite, int magSize, int reserve, int dmg, int rate, int reloadTime,
               int pellets, int pierce, double push, double splash, int cost, int ammoCost) {
            this.col = col; this.auto = auto; this.infinite = infinite; this.magSize = magSize; this.maxReserve = reserve;
            this.dmg = dmg; this.rate = rate; this.reloadTime = reloadTime; this.pellets = pellets; this.pierce = pierce;
            this.push = push; this.splash = splash; this.cost = cost; this.ammoCost = ammoCost;
            this.mag = magSize; this.reserve = reserve;
        }
    }

    private static final class Zombie {
        double x, y, speed;
        int hp, maxHp, cool, flash, kind, spitT = 60, tear = 40, stun;      // kind: 0 normal, 1 runner, 2 tank, 3 spitter
        Zombie(double x, double y, int hp, double speed, int kind) {
            this.x = x; this.y = y; this.hp = hp; this.maxHp = hp; this.speed = speed; this.kind = kind;
        }
        double radius() { return kind == 2 ? 0.42 : 0.3; }
    }

    /** A window in a wall: boards on it, the tile inside the room, and the little pocket outside where zombies come from. */
    private static final class Win {
        int x, y, ix, iy, zone, boards = MAX_BOARDS;
        final List<int[]> pocket = new ArrayList<>();
    }

    private final int[][] map = new int[MH][MW];
    private final boolean[][] pocket = new boolean[MH][MW];
    private final int[][] zoneOf = new int[MH][MW];                 // which room a floor tile belongs to (-1 outside)
    private final int[][] winIdx = new int[MH][MW];                 // which window a window tile or a pocket tile belongs to
    private final double[] zbuf = new double[COLS];
    private final double[] winD = new double[COLS];                 // per column: how far the first open window on the ray is (0 = none)
    private final boolean[] winSide = new boolean[COLS];
    private final int[][] flow = new int[MH][MW];
    private final boolean[] zoneOpen = new boolean[16];
    private final List<Win> wins = new ArrayList<>();
    private final List<int[]> doors = new ArrayList<>();            // x, y, price, zone A, zone B
    private final List<int[]> stations = new ArrayList<>();         // x, y, index of the gun sold there
    private final List<int[]> boxes = new ArrayList<>();            // x, y, and the floor tile in front of the mystery box
    private final List<int[]> secrets = new ArrayList<>();          // x, y of the cracked walls
    private final int[] zoneColor = new int[16];
    private final List<Zombie> zombies = new ArrayList<>();
    private final java.util.Set<Zombie> shotHit = new java.util.HashSet<>();   // zombies already paid for in the current shot
    //                                         color       auto   inf   mag res dmg rate rl  pel prc push  splash cost ammo
    private final Weapon pistol  = new Weapon(0xFFB0B0B8, false, true,   8,   0, 2, 16,  70, 1, 1, 0.10, 0,   0,   0);
    private final Weapon rifle   = new Weapon(0xFF8AA070, true,  false, 30, 120, 3,  6, 100, 1, 1, 0.05, 0, 500, 250);
    private final Weapon shotgun = new Weapon(0xFFB07A44, false, false,  6,  24, 2, 42, 110, 6, 1, 0.16, 0, 1500, 750);
    private final Weapon smg     = new Weapon(0xFF5ADC70, true,  false, 40, 200, 2,  5,  80, 1, 1, 0.04, 0, 1000, 500);
    private final Weapon magnum  = new Weapon(0xFFF08A50, false, false,  6,  36, 7, 26,  90, 1, 1, 0.12, 0, 1200, 600);
    private final Weapon sniper  = new Weapon(0xFFB070F0, false, false,  5,  30, 14, 45, 130, 1, 3, 0.20, 0, 2000, 1000);
    private final Weapon ray     = new Weapon(0xFF4AF0E0, true,  false, 20, 160, 6, 12,  90, 1, 1, 0.08, 1.4, -1, 0);   // only from the mystery box
    private final Weapon[] weapons = {pistol, rifle, shotgun, smg, magnum, sniper, ray};
    private final int[] perk = new int[PERKS];                // levels of the perks (0-3)
    private final List<double[]> mineList = new ArrayList<>(), spits = new ArrayList<>(), blasts = new ArrayList<>(), drops = new ArrayList<>();
    private int[] offer = new int[0];
    private boolean offering;
    private int offerT, mines, seenKinds;

    private double px, py, ang, hp, turnV, pitch;
    private Weapon cur;
    private boolean trigPrev;
    private int round, toSpawn, spawned, spawnT, breakT, kills, points;
    private int cool, reload, kick, flashT, hit, headT, hurtT, noHurt, ticks, msgT, walkT;
    private int instaT, dblT, nukeT, repT, repPts, dropsRound, sinceDrop;
    private int tKind, tIdx;                                   // what E would do right now: 0 nothing, 1 gun wall, 2 door, 3 window, 4 mystery box, 5 cracked wall
    private int boxState, boxT, boxW;                           // mystery box: 0 closed, 1 rolling, 2 a gun is waiting (boxW, -1 = teddy bear)
    private int hor = H / 2;                                   // the horizon line on the screen (moves when you look up / down)
    private String msg = "";
    private double lastDist, lastWallX, lastWinDist;
    private int lastType, lastTX, lastTY;
    private boolean lastSide, lastWinSide;

    // ---------- setup ----------
    @Override
    public void reset() {
        score = 0; over = false; round = 1; kills = 0; points = START_PTS; ticks = 0; msgT = 0; breakT = 0;
        turnV = 0; pitch = 0; hp = 100; hurtT = 0; noHurt = 0; kick = 0; flashT = 0; hit = 0; headT = 0; reload = 0; cool = 40; walkT = 0;
        instaT = 0; dblT = 0; nukeT = 0; repT = 0; repPts = 0; dropsRound = 0; sinceDrop = 0;
        trigPrev = true; boxState = 0; boxT = 0;
        for (Weapon w : weapons) { w.mag = w.magSize; w.reserve = w.maxReserve; w.owned = false; }
        pistol.owned = true;
        Arrays.fill(perk, 0);
        mineList.clear(); spits.clear(); blasts.clear(); drops.clear();
        mines = 0; offering = false; seenKinds = 0;
        cur = pistol;
        zombies.clear();
        buildLevel();
        px = 16.5; py = 12.5; ang = -Math.PI / 2;
        zoneOpen[zoneOf[(int) py][(int) px]] = true;
        buildFlow();
        startRound();
        say("cutemod.zombies.start");
    }

    /** Reads LEVEL: tiles, rooms (zones), doors, stations and windows with their pockets. */
    private void buildLevel() {
        wins.clear(); doors.clear(); stations.clear(); boxes.clear(); secrets.clear();
        Arrays.fill(zoneOpen, false);
        for (int y = 0; y < MH; y++) {
            Arrays.fill(zoneOf[y], -1);
            Arrays.fill(winIdx[y], -1);
            for (int x = 0; x < MW; x++) {
                char c = LEVEL[y].charAt(x);
                pocket[y][x] = c == 'p';
                map[y][x] = switch (c) {
                    case '#' -> 1; case 'c' -> 2; case 'S' -> 3; case 'T' -> 4; case 'U' -> 8; case 'G' -> 9; case 'K' -> 10;
                    case 'X' -> 11; case 'Z' -> 12; case 'W' -> 6;
                    default -> c >= '1' && c <= '4' ? 5 : 0;
                };
                int gun = c == 'S' ? 1 : c == 'T' ? 2 : c == 'U' ? 3 : c == 'G' ? 4 : c == 'K' ? 5 : 0;
                if (gun > 0) stations.add(new int[]{x, y, gun});
                if (c == 'Z') secrets.add(new int[]{x, y});
                if (c >= '1' && c <= '4') doors.add(new int[]{x, y, DOOR_COST[c - '0'], -1, -1});
            }
        }
        int zones = 0;                                           // rooms: flood fill over the floor
        for (int y = 0; y < MH; y++) {
            for (int x = 0; x < MW; x++) {
                if (map[y][x] != 0 || pocket[y][x] || zoneOf[y][x] >= 0) continue;
                ArrayDeque<int[]> q = new ArrayDeque<>();
                zoneOf[y][x] = zones;
                q.add(new int[]{x, y});
                while (!q.isEmpty()) {
                    int[] c = q.poll();
                    for (int[] d : DIRS) {
                        int nx = c[0] + d[0], ny = c[1] + d[1];
                        if (inb(nx, ny) && map[ny][nx] == 0 && !pocket[ny][nx] && zoneOf[ny][nx] < 0) { zoneOf[ny][nx] = zones; q.add(new int[]{nx, ny}); }
                    }
                }
                zones++;
            }
        }
        for (int y = 0; y < MH; y++) {                           // windows and the pockets behind them
            for (int x = 0; x < MW; x++) {
                if (map[y][x] != 6) continue;
                Win w = new Win();
                w.x = x; w.y = y; w.ix = x; w.iy = y; w.zone = 0;
                int idx = wins.size();
                winIdx[y][x] = idx;
                ArrayDeque<int[]> q = new ArrayDeque<>();
                for (int[] d : DIRS) {
                    int nx = x + d[0], ny = y + d[1];
                    if (!inb(nx, ny)) continue;
                    if (map[ny][nx] == 0 && !pocket[ny][nx]) { w.ix = nx; w.iy = ny; w.zone = zoneOf[ny][nx]; }
                    else if (pocket[ny][nx] && winIdx[ny][nx] < 0) { winIdx[ny][nx] = idx; q.add(new int[]{nx, ny}); }
                }
                while (!q.isEmpty()) {
                    int[] c = q.poll();
                    w.pocket.add(c);
                    for (int[] d : DIRS) {
                        int nx = c[0] + d[0], ny = c[1] + d[1];
                        if (inb(nx, ny) && pocket[ny][nx] && winIdx[ny][nx] < 0) { winIdx[ny][nx] = idx; q.add(new int[]{nx, ny}); }
                    }
                }
                wins.add(w);
            }
        }
        for (int y = 0; y < MH; y++) {                           // the mystery box and the floor in front of it
            for (int x = 0; x < MW; x++) {
                if (map[y][x] != 11) continue;
                for (int[] d : DIRS) {
                    int nx = x + d[0], ny = y + d[1];
                    if (inb(nx, ny) && map[ny][nx] == 0 && !pocket[ny][nx]) { boxes.add(new int[]{x, y, nx, ny}); break; }
                }
            }
        }
        Arrays.fill(zoneColor, 0xFF5A5A5A);                      // every room has its own floor color
        for (int[] a : ZONE_ANCHOR) if (zoneOf[a[1]][a[0]] >= 0) zoneColor[zoneOf[a[1]][a[0]] & 15] = a[2];
        for (int[] dr : doors) {                                 // which two rooms a door joins
            for (int[] d : DIRS) {
                int nx = dr[0] + d[0], ny = dr[1] + d[1];
                if (!inb(nx, ny) || zoneOf[ny][nx] < 0) continue;
                if (dr[3] < 0) dr[3] = zoneOf[ny][nx];
                else if (zoneOf[ny][nx] != dr[3]) dr[4] = zoneOf[ny][nx];
            }
        }
    }

    private void startRound() {
        toSpawn = 5 + 3 * round;
        spawned = 0;
        spawnT = 90;
        repPts = 0;
        dropsRound = 0;
        say("cutemod.zombies.round", round);
    }

    private void say(String key, Object... args) {
        msg = Component.translatable(key, args).getString();
        msgT = 150;
    }

    // ---------- helpers ----------
    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private static boolean lmb() {
        return GLFW.glfwGetMouseButton(Minecraft.getInstance().getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    private static void snd(SoundEvent e, float pitch, float vol) {
        dev.cutemod.client.os.Sfx.gameSound(e, pitch, vol);
    }

    private static void snd(Holder<SoundEvent> h, float pitch, float vol) { snd(h.value(), pitch, vol); }

    private void earn(int n) {
        int v = (int) Math.round(n * (1 + 0.25 * perk[5])) * (dblT > 0 ? 2 : 1);    // the "greedy" perk, double points
        points += v;
        score += v;
    }

    private static boolean inb(int x, int y) { return x >= 0 && y >= 0 && x < MW && y < MH; }

    /** The player (and spit) can only stand on plain floor. */
    private boolean free(double x, double y) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        return inb(ix, iy) && map[iy][ix] == 0;
    }

    /** Zombies can also climb through a window with no boards left. */
    private boolean zfree(double x, double y) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        return inb(ix, iy) && (map[iy][ix] == 0 || map[iy][ix] == 7);
    }

    private void move(double dx, double dy) {
        double r = 0.22;
        if (free(px + dx + Math.signum(dx) * r, py)) px += dx;
        if (free(px, py + dy + Math.signum(dy) * r)) py += dy;
    }

    /** Distance to the first wall along a direction (also remembers which wall it was). Open windows do not stop the ray. */
    private double ray(double a) {
        double rdx = Math.cos(a), rdy = Math.sin(a);
        int mapX = (int) px, mapY = (int) py;
        double ddx = Math.abs(1 / rdx), ddy = Math.abs(1 / rdy), sdx, sdy;
        int stepX, stepY;
        if (rdx < 0) { stepX = -1; sdx = (px - mapX) * ddx; } else { stepX = 1; sdx = (mapX + 1 - px) * ddx; }
        if (rdy < 0) { stepY = -1; sdy = (py - mapY) * ddy; } else { stepY = 1; sdy = (mapY + 1 - py) * ddy; }
        boolean side = false;
        lastWinDist = -1;
        while (map[mapY][mapX] == 0 || map[mapY][mapX] == 7) {
            double entry;
            if (sdx < sdy) { entry = sdx; sdx += ddx; mapX += stepX; side = false; }
            else { entry = sdy; sdy += ddy; mapY += stepY; side = true; }
            if (lastWinDist < 0 && map[mapY][mapX] == 7) { lastWinDist = entry; lastWinSide = side; }
        }
        double dist = Math.max(0.05, side ? sdy - ddy : sdx - ddx);
        lastType = map[mapY][mapX];
        lastTX = mapX;
        lastTY = mapY;
        lastSide = side;
        double wx = side ? px + dist * rdx : py + dist * rdy;
        lastWallX = wx - Math.floor(wx);
        return dist;
    }

    // ---------- shooting ----------
    private int dmgOf(Weapon w) { return w.dmg + perk[1]; }

    private void shotSound() {
        if (cur == ray) { snd(SoundEvents.FIREWORK_ROCKET_BLAST, 1.8F, 0.5F); return; }
        float pitch = cur == rifle ? 1.9F : cur == shotgun ? 0.7F : cur == smg ? 2.0F : cur == magnum ? 1.0F : cur == sniper ? 0.6F : 1.5F;
        snd(SoundEvents.ARROW_SHOOT, pitch, cur == shotgun || cur == sniper ? 0.9F : 0.6F);
    }

    private void fire() {
        if (reload > 0 || cool > 0) return;
        if (cur.mag <= 0) { startReload(); return; }
        cur.mag--;
        shotHit.clear();
        cool = cur.rate;
        kick = cur.pellets > 1 ? 11 : cur == sniper ? 12 : cur == magnum ? 9 : cur == pistol ? 7 : cur == smg ? 3 : 4;
        flashT = 3;
        shotSound();
        for (int i = 0; i < cur.pellets; i++) {                // the shotgun throws 6 pellets in a small cone
            double a = cur.pellets > 1 ? ang + (rnd.nextDouble() - 0.5) * 0.24 : ang;
            double dv = cur.pellets > 1 ? (rnd.nextDouble() - 0.5) * 0.22 : 0;
            shootRay(a, dmgOf(cur), dv, cur.push, cur.pierce, cur.splash);
        }
        if (cur.mag == 0) startReload();
    }

    /**
     * One bullet along an angle: hits the nearest zombies in front of the first wall (pierce = how many it goes through).
     * The bullet flies at the height of the crosshair, which depends on how far you look up or down:
     * a wall is 1.0 high and your eyes are at 0.5. The top of a zombie is its head: twice the damage.
     * splash > 0 (the ray gun) also hurts the zombies standing next to the one that was hit.
     */
    private void shootRay(double a, int dmg, double dv, double push, int pierce, double splash) {
        double wall = ray(a);
        double c = Math.cos(a), s = Math.sin(a);
        Zombie[] zs = zombies.toArray(new Zombie[0]);
        List<double[]> cand = new ArrayList<>();               // distance along the bullet, head (1 / 0), index
        for (int i = 0; i < zs.length; i++) {
            Zombie z = zs[i];
            double dx = z.x - px, dy = z.y - py;
            double f = dx * c + dy * s;
            if (f < 0.1 || f > wall) continue;
            if (Math.abs(-dx * s + dy * c) >= z.radius()) continue;
            double h = 0.5 + pitch * f / H + dv * f;
            double size = KIND_SIZE[z.kind];
            if (h < 0 || h > size + 0.03) continue;             // over or under it
            cand.add(new double[]{f, h >= size * HEAD ? 1 : 0, i});
        }
        if (cand.isEmpty()) return;
        cand.sort((p, q) -> Double.compare(p[0], q[0]));
        hit = 8;
        for (int k = 0; k < Math.min(pierce, cand.size()); k++) {
            Zombie best = zs[(int) cand.get(k)[2]];
            boolean head = cand.get(k)[1] > 0;
            int d = dmg;
            if (head) {
                d = (int) Math.ceil(dmg * (best.kind == 2 ? 1.5 : 2.0));
                headT = 40;
                snd(SoundEvents.PLAYER_ATTACK_CRIT, 1.5F, 0.5F);
            }
            double bx = best.x, by = best.y;
            damage(best, d, head, shotHit.add(best));
            if (best.hp > 0) knock(best, c, s, push);
            if (splash > 0) {
                blasts.add(new double[]{bx, by, 8});
                for (Zombie o : new ArrayList<>(zombies)) {
                    if (o != best && Math.hypot(o.x - bx, o.y - by) < splash) damage(o, Math.max(1, d / 2), false, shotHit.add(o));
                }
            }
        }
    }

    /** hitPts: this bullet pays the 10 points for hurting (the killing shot pays 60 / 100 instead). */
    private void damage(Zombie z, int dmg, boolean head, boolean hitPts) {
        if (z.hp <= 0) return;
        if (instaT > 0) dmg = Math.max(dmg, z.hp);
        z.hp -= dmg;
        z.flash = 6;
        if (z.hp <= 0) {
            zombies.remove(z);
            kills++;
            earn(head ? HEAD_PTS : KILL_PTS);
            snd(SoundEvents.ZOMBIE_DEATH, z.kind == 2 ? 0.6F : 1.0F, 0.6F);
            maybeDrop(z);
        } else {
            if (hitPts) earn(HIT_PTS);
            snd(SoundEvents.ZOMBIE_HURT, z.kind == 1 ? 1.5F : 1.2F, 0.5F);
        }
    }

    /** A hit shoves the zombie back along the bullet and makes it stagger for a moment (tanks hardly move). */
    private void knock(Zombie z, double dx, double dy, double amt) {
        if (z.kind == 2) amt *= 0.35;
        double nx = z.x + dx * amt, ny = z.y + dy * amt;
        if (zfree(nx, z.y)) z.x = nx;
        if (zfree(z.x, ny)) z.y = ny;
        z.stun = Math.max(z.stun, (int) (amt * 40));
    }

    private void startReload() {
        if (reload > 0 || cur.mag >= cur.magSize || (!cur.infinite && cur.reserve <= 0)) return;
        reload = Math.max(20, (int) (cur.reloadTime * (1 - 0.25 * perk[0])));
        snd(SoundEvents.UI_BUTTON_CLICK, 0.6F, 0.7F);
    }

    private void finishReload() {
        int need = cur.magSize - cur.mag;
        int take = cur.infinite ? need : Math.min(need, cur.reserve);
        cur.mag += take;
        if (!cur.infinite) cur.reserve -= take;
        snd(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.7F);
    }

    private void select(Weapon w) {
        if (!w.owned) return;
        if (cur != w) { cur = w; reload = 0; cool = 12; }
    }

    private void cycle() {
        List<Weapon> own = new ArrayList<>();
        for (Weapon w : weapons) if (w.owned) own.add(w);
        select(own.get((own.indexOf(cur) + 1) % own.size()));
    }

    // ---------- what is in reach: gun walls, doors, windows, the mystery box ----------
    private boolean nearStation() {
        for (int[] s : stations) if (Math.hypot(px - (s[0] + 0.5), py - (s[1] + 0.5)) < 2.3) return true;
        return false;
    }

    /** Works out what E does here: the nearest of a gun wall, the mystery box, a cracked wall, a closed door or a damaged window. */
    private void findTarget() {
        tKind = 0;
        tIdx = -1;
        double best = 1e9;
        for (int i = 0; i < stations.size(); i++) {
            int[] s = stations.get(i);
            double d = Math.hypot(px - (s[0] + 0.5), py - (s[1] + 0.5));
            if (d < 2.3 && d < best) { best = d; tKind = 1; tIdx = i; }
        }
        for (int i = 0; i < boxes.size(); i++) {
            int[] b = boxes.get(i);
            double d = Math.hypot(px - (b[0] + 0.5), py - (b[1] + 0.5));
            if (d < 2.3 && d < best) { best = d; tKind = 4; tIdx = i; }
        }
        for (int i = 0; i < secrets.size(); i++) {
            int[] sc = secrets.get(i);
            if (map[sc[1]][sc[0]] != 12) continue;
            double d = Math.hypot(px - (sc[0] + 0.5), py - (sc[1] + 0.5));
            if (d < 1.8 && d < best) { best = d; tKind = 5; tIdx = i; }
        }
        for (int i = 0; i < doors.size(); i++) {
            int[] dr = doors.get(i);
            if (map[dr[1]][dr[0]] != 5) continue;
            double d = Math.hypot(px - (dr[0] + 0.5), py - (dr[1] + 0.5));
            if (d < 2.0 && d < best) { best = d; tKind = 2; tIdx = i; }
        }
        for (int i = 0; i < wins.size(); i++) {
            Win w = wins.get(i);
            if (w.boards >= MAX_BOARDS) continue;
            double d = Math.hypot(px - (w.x + 0.5), py - (w.y + 0.5));
            if (d < 1.8 && d < best) { best = d; tKind = 3; tIdx = i; }
        }
    }

    private boolean zombieNear(Win w, double r) {
        for (Zombie z : zombies) if (Math.hypot(z.x - (w.x + 0.5), z.y - (w.y + 0.5)) < r) return true;
        return false;
    }

    private void buy() {
        findTarget();
        switch (tKind) {
            case 1 -> buyStation(stations.get(tIdx)[2]);
            case 2 -> openDoor(doors.get(tIdx));
            case 4 -> useBox();
            case 5 -> openSecret(secrets.get(tIdx));
            default -> { }
        }
    }

    private static String gunName(int wi) {
        return Component.translatable("cutemod.zombies.w." + wi).getString();
    }

    /** Buy a gun at its wall, or its ammo if you already own it. */
    private void buyStation(int wi) {
        Weapon w = weapons[wi];
        if (!w.owned) {
            if (points < w.cost) { say("cutemod.zombies.poor"); beep(); return; }
            points -= w.cost;
            giveGun(wi);
            pling(1.6F);
        } else {
            if (w.reserve >= w.maxReserve && w.mag >= w.magSize) { say("cutemod.zombies.full"); return; }
            if (points < w.ammoCost) { say("cutemod.zombies.poor"); beep(); return; }
            points -= w.ammoCost;
            w.reserve = w.maxReserve;
            w.mag = w.magSize;
            say("cutemod.zombies.ammo");
            pling(1.3F);
        }
    }

    private void giveGun(int wi) {
        Weapon w = weapons[wi];
        w.owned = true;
        w.mag = w.magSize;
        w.reserve = w.maxReserve;
        select(w);
        say("cutemod.zombies.got", gunName(wi));
    }

    /** The mystery box: pay, it rolls for about 1.7 s, then a random gun waits for you for 6 s (or a teddy bear takes half). */
    private void useBox() {
        if (boxState == 0) {
            if (points < BOX_COST) { say("cutemod.zombies.poor"); beep(); return; }
            points -= BOX_COST;
            boxState = 1;
            boxT = 100;
            if (rnd.nextInt(100) < 8) boxW = -1;                 // the teddy bear
            else {
                int[] wts = {20, 20, 20, 15, 15, 10};            // rifle, shotgun, SMG, magnum, sniper, ray gun
                int r = rnd.nextInt(100), i = 0;
                while (r >= wts[i]) { r -= wts[i]; i++; }
                boxW = i + 1;
            }
            snd(SoundEvents.WOODEN_DOOR_OPEN, 0.5F, 0.7F);
        } else if (boxState == 2) {
            giveGun(boxW);
            boxState = 0;
            pling(1.9F);
        }
    }

    private void openSecret(int[] sc) {
        map[sc[1]][sc[0]] = 0;
        say("cutemod.zombies.secret_found");
        snd(SoundEvents.WOOD_BREAK, 0.6F, 0.9F);
        pling(1.5F);
    }

    private void openDoor(int[] dr) {
        if (points < dr[2]) { say("cutemod.zombies.poor"); beep(); return; }
        points -= dr[2];
        map[dr[1]][dr[0]] = 0;
        if (dr[3] >= 0) zoneOpen[dr[3]] = true;                  // the zombies of the new room start coming
        if (dr[4] >= 0) zoneOpen[dr[4]] = true;
        say("cutemod.zombies.door_open");
        snd(SoundEvents.WOODEN_DOOR_OPEN, 0.7F, 0.8F);
        pling(1.2F);
    }

    private void repair(Win w) {
        if (w.boards >= MAX_BOARDS) return;
        w.boards++;
        snd(SoundEvents.WOOD_PLACE, 0.9F + rnd.nextFloat() * 0.3F, 0.8F);
        if (repPts < 240) { repPts += BOARD_PTS; earn(BOARD_PTS); }            // only a few points per round, so it cannot be farmed
    }

    private void buyMines() {
        if (!nearStation()) return;
        if (mines >= MAX_MINES) { say("cutemod.zombies.mines_full"); return; }
        if (points < MINE_COST) { say("cutemod.zombies.poor"); beep(); return; }
        points -= MINE_COST;
        mines = Math.min(MAX_MINES, mines + 3);
        say("cutemod.zombies.mines_bought");
        pling(1.4F);
    }

    private void placeMine() {
        if (mines <= 0) { say("cutemod.zombies.nomines"); beep(); return; }
        mines--;
        mineList.add(new double[]{px, py, 45});            // it needs 0.75 s to arm
        snd(SoundEvents.UI_BUTTON_CLICK, 0.5F, 0.8F);
    }

    // ---------- power-ups ----------
    private void maybeDrop(Zombie z) {
        sinceDrop++;
        double chance = z.kind == 2 ? 0.30 : 0.05;
        if (!((dropsRound < 3 && rnd.nextDouble() < chance) || sinceDrop >= 30)) return;
        sinceDrop = 0;
        dropsRound++;
        int total = 0;
        for (int w : DROP_W) total += w;
        int r = rnd.nextInt(total), type = 0;
        while (r >= DROP_W[type]) { r -= DROP_W[type]; type++; }
        double dx = z.x, dy = z.y;
        int tx = (int) z.x, ty = (int) z.y;
        if (inb(tx, ty) && winIdx[ty][tx] >= 0) {               // killed in a window or outside it: the gift lands inside the room
            Win w = wins.get(winIdx[ty][tx]);
            dx = w.ix + 0.5;
            dy = w.iy + 0.5;
        }
        drops.add(new double[]{dx, dy, type, 900});
    }

    private void grab(int type) {
        switch (type) {
            case D_AMMO -> {
                for (Weapon w : weapons) { w.mag = w.magSize; w.reserve = w.maxReserve; }
                mines = Math.min(MAX_MINES, mines + 3);
                reload = 0;
            }
            case D_INSTA -> instaT = 1200;
            case D_NUKE -> {
                for (Zombie z : new ArrayList<>(zombies)) { zombies.remove(z); kills++; }
                spits.clear();
                nukeT = 24;
                earn(400);
                snd(SoundEvents.GENERIC_EXPLODE, 0.7F, 0.9F);
            }
            case D_DOUBLE -> dblT = 1200;
            case D_CARPENTER -> {
                for (Win w : wins) w.boards = MAX_BOARDS;        // a window with a zombie in it closes as soon as it steps out
                earn(200);
                snd(SoundEvents.WOOD_PLACE, 0.8F, 0.9F);
            }
            default -> hp = Math.min(maxHp(), hp + 60);
        }
        say("cutemod.zombies.drop." + type);
        pling(1.8F);
    }

    // ---------- perks: after every round you pick 1 of 3 ----------
    private int maxHp() { return 100 + 25 * perk[3]; }

    private void openOffer() {
        List<Integer> pool = new ArrayList<>();
        for (int i = 0; i < PERKS; i++) if (perk[i] < 3) pool.add(i);
        Collections.shuffle(pool, new java.util.Random(rnd.nextLong()));
        int n = Math.min(3, pool.size());
        offer = new int[n];
        for (int i = 0; i < n; i++) offer[i] = pool.get(i);
        offering = n > 0;
        offerT = 900;
    }

    private void choose(int k) {
        if (!offering || k < 0 || k >= offer.length) return;
        int p = offer[k];
        perk[p]++;
        if (p == 3) hp = Math.min(maxHp(), hp + 25);
        offering = false;
        breakT = Math.min(breakT, 150);
        say("cutemod.zombies.perk_got", Component.translatable("cutemod.zombies.perk." + p + ".name").getString());
        pling(1.7F);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (!offering) return false;
        int n = offer.length, x0 = (W - (n * CARD_W + (n - 1) * 4)) / 2;
        for (int i = 0; i < n; i++) {
            if (in(x, y, x0 + i * (CARD_W + 4), 30, CARD_W, 86)) { choose(i); return true; }
        }
        return false;
    }

    @Override
    public boolean key(int k) {
        switch (k) {
            case 82 -> startReload();                                  // R
            case 69 -> buy();                                          // E
            case 66 -> buyMines();                                     // B
            case 70 -> placeMine();                                    // F
            case 49, 50, 51, 52, 53, 54, 55 -> { if (offering) choose(k - 49); else select(weapons[k - 49]); }   // 1-7: pick a perk / a gun
            case 81 -> cycle();                                        // Q
            default -> { return false; }
        }
        return true;
    }

    // ---------- tick ----------
    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        if (cool > 0) cool--;
        if (kick > 0) kick--;
        if (flashT > 0) flashT--;
        if (hit > 0) hit--;
        if (headT > 0) headT--;
        if (hurtT > 0) hurtT--;
        if (instaT > 0) instaT--;
        if (dblT > 0) dblT--;
        if (nukeT > 0) nukeT--;
        if (reload > 0 && --reload == 0) finishReload();

        // --- turning: arrow keys, or the mouse close to the left / right edge ---
        double turn = (down(KEY_RIGHT) ? 1 : 0) - (down(KEY_LEFT) ? 1 : 0);
        ang += turn * 0.045;
        // The farther the mouse is from the middle, the faster you turn: slow and fine near the middle, quick near the
        // edges. It keeps working when the pointer leaves the game area, and the speed is smoothed so aiming does not jerk.
        double target = 0;
        if (!offering) {
            double nx = Math.max(-1.6, Math.min(1.6, (mx - W / 2.0) / (W / 2.0)));
            double d = (Math.abs(nx) - DEAD) / (1 - DEAD);
            if (d > 0) target = Math.signum(nx) * Math.pow(d, 1.6) * 0.06;
        }
        turnV += (target - turnV) * 0.3;
        if (Math.abs(turnV) < 0.0004) turnV = 0;
        ang += turnV;
        // --- looking up / down: the mouse above or below the middle band (or the up / down arrows) ---
        double tp = 0;
        if (!offering) {
            double ny = Math.max(-1, Math.min(1, (my - H / 2.0) / (H / 2.0)));
            double d = (Math.abs(ny) - PDEAD) / (1 - PDEAD);
            if (d > 0) tp = -Math.signum(ny) * d * MAXP;
            tp += ((down(KEY_UP) ? 1 : 0) - (down(KEY_DOWN) ? 1 : 0)) * MAXP * 0.8;
        }
        pitch += (Math.max(-MAXP, Math.min(MAXP, tp)) - pitch) * 0.2;
        // --- walking ---
        double fwd = (down(87) ? 1 : 0) - (down(83) ? 0.75 : 0);
        double str = (down(68) ? 1 : 0) - (down(65) ? 1 : 0);
        double c = Math.cos(ang), s = Math.sin(ang);
        double v = 0.045 * (1 + 0.15 * perk[2]);
        move((c * fwd - s * str) * v, (s * fwd + c * str) * v);
        if (fwd != 0 || str != 0) walkT++;

        // --- trigger (not while you are choosing a perk with the mouse) ---
        boolean trig = (lmb() && !offering) || down(KEY_SPACE);
        if (trig && (cur.auto || !trigPrev)) fire();
        trigPrev = trig;

        // --- hold E at a window to nail boards back on ---
        findTarget();
        if (tKind == 3 && !offering && down(69)) {
            Win w = wins.get(tIdx);
            if (zombieNear(w, 1.0)) {
                if (msgT == 0) say("cutemod.zombies.blocked");
                repT = 0;
            } else if (++repT >= 22) {
                repT = 0;
                repair(w);
            }
        } else repT = 0;
        for (Win w : wins) {                                     // a window is shut again once it has a board and nobody stands in it
            if (map[w.y][w.x] == 7 && w.boards > 0 && !zombieNear(w, 1.0)) map[w.y][w.x] = 6;
        }

        // --- the mystery box: rolling, then a gun waits for you for a few seconds ---
        if (boxState == 1) {
            if (boxT % 8 == 0) pling(0.8F + (100 - boxT) / 100F);
            if (--boxT <= 0) {
                if (boxW < 0) { points += BOX_COST; say("cutemod.zombies.teddy"); boxState = 0; }
                else { boxState = 2; boxT = 360; pling(2.0F); }
            }
        } else if (boxState == 2 && --boxT <= 0) {
            boxState = 0;
            say("cutemod.zombies.box_lost");
        }

        // --- waves ---
        if (breakT > 0) {
            if (offering) {
                if (--offerT <= 0) choose(rnd.nextInt(offer.length));      // too slow: a random one
            } else if (--breakT == 0) {
                round++;
                startRound();
            }
        } else {
            int cap = Math.min(16, 6 + round);
            if (spawned < toSpawn && zombies.size() < cap && --spawnT <= 0) {
                spawnT = Math.max(30, 100 - round * 6);
                spawnZombie();
            }
            if (spawned >= toSpawn && zombies.isEmpty()) {
                breakT = 300;
                say("cutemod.zombies.clear");
                pling(1.9F);
                openOffer();
            }
        }

        // --- zombies ---
        if (ticks % 8 == 0) buildFlow();
        for (Zombie z : new ArrayList<>(zombies)) {
            if (z.flash > 0) z.flash--;
            if (z.cool > 0 && Math.hypot(z.x - px, z.y - py) >= 0.75) z.cool--;
            if (z.kind == 3) {                                  // a spitter stops at a distance and spits
                if (z.spitT > 0) z.spitT--;
                double d = Math.hypot(z.x - px, z.y - py);
                if (d < 5.5 && d > 1.3 && seen(z.x, z.y)) {
                    if (z.spitT <= 0) { spit(z); z.spitT = 110; }
                } else {
                    moveZombie(z);
                }
            } else {
                moveZombie(z);
            }
            if (Math.hypot(z.x - px, z.y - py) < 0.75 && z.stun <= 0) {
                if (--z.cool <= 0) {
                    z.cool = 50;
                    hp -= KIND_DMG[z.kind];
                    hurtT = 14;
                    noHurt = 0;
                    snd(SoundEvents.PLAYER_HURT, 1.0F, 0.7F);
                }
            }
        }
        for (int i = 0; i < zombies.size(); i++) {           // keep them from stacking on one spot
            for (int j = i + 1; j < zombies.size(); j++) {
                Zombie a = zombies.get(i), b = zombies.get(j);
                double dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy);
                if (d < 0.45 && d > 0.001) {
                    double push = (0.45 - d) * 0.25;
                    if (zfree(a.x - dx / d * push, a.y)) a.x -= dx / d * push;
                    if (zfree(a.x, a.y - dy / d * push)) a.y -= dy / d * push;
                    if (zfree(b.x + dx / d * push, b.y)) b.x += dx / d * push;
                    if (zfree(b.x, b.y + dy / d * push)) b.y += dy / d * push;
                }
            }
        }
        if (!zombies.isEmpty() && rnd.nextInt(150) == 0) snd(SoundEvents.ZOMBIE_AMBIENT, 0.5F + rnd.nextFloat() * 0.4F, 0.6F);

        // --- mines: they wait, then go off when a zombie walks close ---
        for (Iterator<double[]> it = mineList.iterator(); it.hasNext(); ) {
            double[] m = it.next();
            if (m[2] > 0) { m[2]--; continue; }
            boolean trip = false;
            for (Zombie z : zombies) if (Math.hypot(z.x - m[0], z.y - m[1]) < 0.8) { trip = true; break; }
            if (!trip) continue;
            it.remove();
            blasts.add(new double[]{m[0], m[1], 14});
            snd(SoundEvents.GENERIC_EXPLODE, 1.1F, 0.7F);
            for (Zombie z : new ArrayList<>(zombies)) if (Math.hypot(z.x - m[0], z.y - m[1]) < 2.0) damage(z, 8, false, false);
        }
        blasts.removeIf(b -> --b[2] <= 0);

        // --- power-ups on the floor: walk into one to take it ---
        for (Iterator<double[]> it = drops.iterator(); it.hasNext(); ) {
            double[] d = it.next();
            if (--d[3] <= 0) { it.remove(); continue; }
            if (Math.hypot(d[0] - px, d[1] - py) < 0.8) { it.remove(); grab((int) d[2]); }
        }

        // --- spit balls ---
        for (Iterator<double[]> it = spits.iterator(); it.hasNext(); ) {
            double[] sp = it.next();
            sp[0] += sp[2];
            sp[1] += sp[3];
            if (!free(sp[0], sp[1]) || --sp[4] <= 0) { it.remove(); continue; }
            if (Math.hypot(sp[0] - px, sp[1] - py) < 0.35) {
                hp -= 12;
                hurtT = 14;
                noHurt = 0;
                snd(SoundEvents.PLAYER_HURT, 1.2F, 0.6F);
                it.remove();
            }
        }

        // --- health comes back if you are not hit for a while ---
        if (++noHurt > 360 - 80 * perk[4] && hp < maxHp()) hp = Math.min(maxHp(), hp + 0.25 + 0.12 * perk[4]);
        if (hp <= 0) { over = true; beep(); snd(SoundEvents.ZOMBIE_VILLAGER_CONVERTED, 0.8F, 0.6F); }
    }

    /** True if nothing solid stands between a point and the player. */
    private boolean seen(double x, double y) {
        double d = Math.hypot(px - x, py - y);
        int steps = (int) (d / 0.25) + 1;
        for (int i = 1; i < steps; i++) {
            double t = i / (double) steps;
            if (!free(x + (px - x) * t, y + (py - y) * t)) return false;
        }
        return true;
    }

    private void spit(Zombie z) {
        double dx = px - z.x, dy = py - z.y, d = Math.max(0.01, Math.hypot(dx, dy));
        spits.add(new double[]{z.x, z.y, dx / d * 0.065, dy / d * 0.065, 200});
        snd(SoundEvents.LLAMA_SPIT, 1.0F, 0.5F);
    }

    /** A zombie appears in the pocket outside a window of a room that is open (a door you paid for), far from you. */
    private void spawnZombie() {
        Win w = null;
        for (int t = 0; t < 12 && w == null; t++) {
            Win c = wins.get(rnd.nextInt(wins.size()));
            if (!zoneOpen[c.zone]) continue;
            if (t < 8 && Math.hypot(c.x + 0.5 - px, c.y + 0.5 - py) < 5) continue;
            w = c;
        }
        if (w == null) {
            List<Win> open = new ArrayList<>();
            for (Win c : wins) if (zoneOpen[c.zone]) open.add(c);
            if (open.isEmpty()) return;
            w = open.get(rnd.nextInt(open.size()));
        }
        int[] pt = w.pocket.get(rnd.nextInt(w.pocket.size()));
        int base = 3 + 2 * (round - 1);
        double sp = Math.min(0.03, 0.012 + 0.0012 * round) * (0.85 + rnd.nextDouble() * 0.3);
        double r = rnd.nextDouble();
        int kind = 0;                                         // new kinds show up in later rounds
        if (round >= 3 && r < 0.22) kind = 1;
        else if (round >= 5 && r < 0.34) kind = 2;
        else if (round >= 7 && r < 0.46) kind = 3;
        int hpz = switch (kind) {
            case 1 -> Math.max(2, base * 6 / 10);
            case 2 -> base * 3;
            case 3 -> Math.max(3, base * 8 / 10);
            default -> base;
        };
        double speed = switch (kind) {
            case 1 -> Math.min(0.043, sp * 1.5);
            case 2 -> sp * 0.6;
            case 3 -> sp * 0.7;
            default -> sp;
        };
        zombies.add(new Zombie(pt[0] + 0.5 + (rnd.nextDouble() - 0.5) * 0.3, pt[1] + 0.5 + (rnd.nextDouble() - 0.5) * 0.3, hpz, speed, kind));
        spawned++;
        if (kind > 0 && (seenKinds & (1 << kind)) == 0) {
            seenKinds |= 1 << kind;
            say("cutemod.zombies.new." + kind);
        }
    }

    /** Distance (in tiles) from every walkable tile to the player. Zombies walk "downhill" (windows count, closed doors do not). */
    private void buildFlow() {
        for (int[] r : flow) Arrays.fill(r, -1);
        ArrayDeque<int[]> q = new ArrayDeque<>();
        int sx = Math.max(1, Math.min(MW - 2, (int) px)), sy = Math.max(1, Math.min(MH - 2, (int) py));
        flow[sy][sx] = 0;
        q.add(new int[]{sx, sy});
        while (!q.isEmpty()) {
            int[] c = q.poll();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0], ny = c[1] + d[1];
                if (inb(nx, ny) && walkable(map[ny][nx]) && flow[ny][nx] < 0) {
                    flow[ny][nx] = flow[c[1]][c[0]] + 1;
                    q.add(new int[]{nx, ny});
                }
            }
        }
    }

    private static boolean walkable(int t) { return t == 0 || t == 6 || t == 7; }

    private void moveZombie(Zombie z) {
        if (z.stun > 0) { z.stun--; return; }
        int cx = (int) z.x, cy = (int) z.y;
        double tx = px, ty = py;
        boolean direct = cx == (int) px && cy == (int) py || (Math.hypot(z.x - px, z.y - py) < 1.3 && seen(z.x, z.y));
        if (!direct && inb(cx, cy) && flow[cy][cx] >= 0) {
            int best = flow[cy][cx];
            tx = cx + 0.5; ty = cy + 0.5;
            for (int[] d : DIRS) {
                int nx = cx + d[0], ny = cy + d[1];
                if (inb(nx, ny) && walkable(map[ny][nx]) && flow[ny][nx] >= 0 && flow[ny][nx] < best) {
                    best = flow[ny][nx];
                    tx = nx + 0.5; ty = ny + 0.5;
                }
            }
            int wx = (int) tx, wy = (int) ty;
            if (map[wy][wx] == 6 && winIdx[wy][wx] >= 0 && Math.hypot(z.x - tx, z.y - ty) < 0.62) {
                Win w = wins.get(winIdx[wy][wx]);               // right at the boards: tear one off every now and then
                if (--z.tear <= 0) {
                    z.tear = 85;
                    if (w.boards > 0) w.boards--;
                    snd(SoundEvents.WOOD_BREAK, 0.8F + rnd.nextFloat() * 0.3F, 0.8F);
                    if (w.boards <= 0) { w.boards = 0; map[w.y][w.x] = 7; }
                }
                return;
            }
        }
        double dx = tx - z.x, dy = ty - z.y, d = Math.hypot(dx, dy);
        if (d < 0.001) return;
        double step = Math.min(z.speed, d);
        double nx = z.x + dx / d * step, ny = z.y + dy / d * step;
        if (zfree(nx, z.y)) z.x = nx;
        if (zfree(z.x, ny)) z.y = ny;
    }

    // ---------- drawing ----------
    private static int shade(int rgb, double b) {
        b = Math.max(0, Math.min(1.5, b));
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * b));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * b));
        int bl = Math.min(255, (int) ((rgb & 255) * b));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Colors of the 4 kinds: normal, runner (red shirt), tank (big, purple), spitter (yellow-green, glowing eyes). */
    private static int pal(char c, int kind, boolean flash) {
        if (flash) return 0xFFFFE0E0;
        return switch (kind) {
            case 1 -> switch (c) {
                case 'G' -> 0xFF5C9A3C; case 'g' -> 0xFF86C25A; case 'b' -> 0xFFC84040; case 'p' -> 0xFF2C2C34;
                case 'r' -> 0xFFFFE030; default -> 0xFF222222;
            };
            case 2 -> switch (c) {
                case 'G' -> 0xFF3C5A38; case 'g' -> 0xFF557A4C; case 'b' -> 0xFF5A3A7A; case 'p' -> 0xFF2A2030;
                case 'r' -> 0xFFFF3030; default -> 0xFF1A1A1A;
            };
            case 3 -> switch (c) {
                case 'G' -> 0xFF98A82A; case 'g' -> 0xFFBCCB3A; case 'b' -> 0xFF6A8A2A; case 'p' -> 0xFF3A4A22;
                case 'r' -> 0xFF9AFF3A; default -> 0xFF222222;
            };
            default -> switch (c) {
                case 'G' -> 0xFF3F7F34; case 'g' -> 0xFF5FA84A; case 'b' -> 0xFF2AA6B0; case 'p' -> 0xFF3A3A8A;
                case 'r' -> 0xFFFF3030; default -> 0xFF222222;
            };
        };
    }

    @Override
    public void render(GuiGraphics g) {
        hor = H / 2 + (int) Math.round(pitch);
        if (hor > 0) g.fillGradient(0, 0, W, Math.min(H, hor), 0xFF0B0D14, 0xFF222733);       // ceiling
        if (hor < H) g.fillGradient(0, Math.max(0, hor), W, H, 0xFF1A1714, 0xFF2E2822);       // floor, under the tiles
        double dirX = Math.cos(ang), dirY = Math.sin(ang), plX = -dirY * PLANE, plY = dirX * PLANE;

        drawFloor(g, dirX, dirY, plX, plY);

        for (int col = 0; col < COLS; col++) {
            double cam = 2.0 * (col + 0.5) / COLS - 1;
            double a = Math.atan2(dirY + plY * cam, dirX + plX * cam);
            double raw = ray(a);
            double dist = Math.max(0.05, raw * Math.cos(a - ang));          // fix the fish-eye effect
            zbuf[col] = dist;
            double b = Math.max(0.12, 1 - dist / 9.5) * (lastSide ? 0.75 : 1);
            if (glows(lastType)) b = Math.max(b, lastType == 11 && boxState > 0 ? 1.1 : 0.45);   // gun walls, doors and the box glow a little in the dark
            int lh = (int) (H / dist);
            drawWall(g, col, lastType, lastTX, lastTY, lastWallX, b, lh, hor - lh / 2);
            winD[col] = lastWinDist > 0 ? Math.max(0.05, lastWinDist * Math.cos(a - ang)) : 0;
            winSide[col] = lastWinSide;
            if (winD[col] > 0) {                                           // an open window: a sill and a lintel around the hole
                double wd = winD[col], wb = Math.max(0.12, 1 - wd / 9.5) * (winSide[col] ? 0.75 : 1);
                int wl = (int) (H / wd), bottom = hor + wl / 2;
                fillCol(g, col, bottom - wl, bottom - (int) (0.82 * wl), shade(0xFF4A3220, wb));
                fillCol(g, col, bottom - (int) (0.28 * wl), bottom - (int) (0.22 * wl), shade(0xFF7A5A3A, wb));      // the lit top of the sill
                fillCol(g, col, bottom - (int) (0.22 * wl), bottom, shade(0xFF4A3220, wb));
            }
        }

        // mines and explosions lie on the floor
        for (double[] m : mineList) billboard(g, m[0], m[1], 0.11, 0, m[2] > 0 || (ticks / 20) % 2 == 0 ? 0xFFE03A3A : 0xFF4A1A1A);
        for (double[] bl : blasts) billboard(g, bl[0], bl[1], 0.25 + (14 - bl[2]) * 0.05, 0.12, bl[2] > 7 ? 0xFFFFC040 : 0xFFE06020);

        if (boxState > 0 && !boxes.isEmpty()) {                    // the gun that is rolling (or waiting) above the box
            int[] bx = boxes.get(0);
            int gi = boxState == 1 ? 1 + (ticks / 4) % 6 : boxW;
            if (gi >= 0) billboard(g, bx[0] + 0.5 + (bx[2] - bx[0]) * 0.62, bx[1] + 0.5 + (bx[3] - bx[1]) * 0.62, 0.17, 0.5 + 0.03 * Math.sin(ticks * 0.2), weapons[gi].col);
        }

        // power-ups, far ones first (they blink when they are about to vanish)
        List<double[]> dl = new ArrayList<>(drops);
        dl.sort((p, q) -> Double.compare(Math.hypot(q[0] - px, q[1] - py), Math.hypot(p[0] - px, p[1] - py)));
        for (double[] d : dl) if (d[3] > 180 || (ticks / 6) % 2 == 0) icon(g, d);

        // zombies, far ones first
        List<Zombie> order = new ArrayList<>(zombies);
        order.sort((a, b) -> Double.compare(Math.hypot(b.x - px, b.y - py), Math.hypot(a.x - px, a.y - py)));
        for (Zombie z : order) sprite(g, z);
        for (double[] sp : spits) billboard(g, sp[0], sp[1], 0.09, 0.45, 0xFF9AFF3A);

        // red flash / vignette when hurt or low on health
        double missing = 1 - hp / maxHp();
        int alpha = (int) Math.min(150, missing * 110 + hurtT * 6);
        if (alpha > 4) rect(g, 0, 0, W, H, (alpha << 24) | 0xB00000);
        if (nukeT > 0) rect(g, 0, 0, W, H, (Math.min(255, nukeT * 10) << 24) | 0xFFFFFF);
        if (breakT > 0 && breakT < 90 && !offering && ticks % 20 < 10) ctext(g, Component.translatable("cutemod.zombies.next").getString(), W / 2, 30, 0xFFFFE9A0);

        weaponAndHud(g);
        if (offering) renderOffer(g);
        if (over) rect(g, 0, 0, W, H, 0x80900000);
    }

    private static boolean glows(int t) { return t == 3 || t == 4 || t == 5 || (t >= 8 && t <= 11); }

    /** One wall column: 8 texture rows stretched over the wall height; rows of the same color are drawn as one rectangle. */
    private void drawWall(GuiGraphics g, int col, int type, int tx, int ty, double wx, double b, int lh, int top) {
        int u = Math.max(0, Math.min(TW - 1, (int) (wx * TW)));
        int boards = type == 6 && winIdx[ty][tx] >= 0 ? wins.get(winIdx[ty][tx]).boards : 0;
        int runY = top, runC = 0;
        for (int r = 0; r < TH; r++) {
            int c = shade(texel(type, u, r, boards), b);
            int y = top + r * lh / TH;
            if (r == 0) { runC = c; runY = y; continue; }
            if (c != runC) { fillCol(g, col, runY, y, runC); runY = y; runC = c; }
        }
        fillCol(g, col, runY, top + lh, runC);
    }

    private static void fillCol(GuiGraphics g, int col, int y0, int y1, int color) {
        y0 = Math.max(0, y0);
        y1 = Math.min(H, y1);
        if (y1 > y0) rect(g, col * CW, y0, CW, y1 - y0, color);
    }

    /** The floor, row by row (3 pixels at a time): every tile has its own shade, every room its own color. */
    private void drawFloor(GuiGraphics g, double dirX, double dirY, double plX, double plY) {
        final int step = 3;
        for (int y = Math.max(hor + 1, 0); y < H; y += step) {
            double d = H / (2.0 * (y + step / 2.0 - hor));
            if (d > 13) continue;
            double bright = Math.max(0.12, 1 - d / 9.5);
            int runStart = 0, runColor = 0;
            for (int col = 0; col <= COLS; col++) {
                int c = 0;
                if (col < COLS) {
                    double cam = 2.0 * (col + 0.5) / COLS - 1;
                    c = floorColor((int) Math.floor(px + d * (dirX + plX * cam)), (int) Math.floor(py + d * (dirY + plY * cam)), bright);
                }
                if (col == 0) { runColor = c; continue; }
                if (c != runColor || col == COLS) {
                    if (runColor != 0) rect(g, runStart * CW, y, (col - runStart) * CW, Math.min(step, H - y), runColor);
                    runStart = col;
                    runColor = c;
                }
            }
        }
    }

    private int floorColor(int fx, int fy, double bright) {
        if (!inb(fx, fy)) return 0;
        int t = map[fy][fx];
        if (t != 0 && t != 7) return 0;                          // a wall stands there
        int base = pocket[fy][fx] ? POCKET_FLOOR : zoneOf[fy][fx] < 0 ? SILL_FLOOR : zoneColor[zoneOf[fy][fx] & 15];
        double k = ((fx + fy) & 1) == 0 ? 1.0 : 0.86;            // a checker pattern plus a little noise per tile
        k *= 0.94 + (hash(fx, fy) & 3) * 0.04;
        return shade(base, bright * k);
    }

    /** A small square in the world (a mine, a spit ball, a blast), hidden behind walls. */
    private void billboard(GuiGraphics g, double wx, double wy, double size, double lift, int color) {
        double rx = wx - px, ry = wy - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);
        if (f < 0.2) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f);
        int s = Math.max(2, (int) (full * size));
        int sx = (int) (W / 2.0 * (1 + cam));
        int col = Math.floorDiv(sx, CW);
        if (sx < 0 || col >= COLS || f >= zbuf[col]) return;
        int bottom = hor + full / 2 - (int) (full * lift);
        rect(g, sx - s / 2, bottom - s, s, s, color);
    }

    /** A power-up: a 7x7 pixel icon hovering over the floor. */
    private void icon(GuiGraphics g, double[] d) {
        int type = (int) d[2];
        double rx = d[0] - px, ry = d[1] - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);
        if (f < 0.2) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f), s = Math.max(7, (int) (full * 0.26));
        int sx = (int) (W / 2.0 * (1 + cam));
        int col = Math.floorDiv(sx, CW);
        if (sx < 0 || col >= COLS || f >= zbuf[col]) return;
        int lift = (int) (full * (0.12 + 0.03 * Math.sin(ticks * 0.15 + d[0])));
        int left = sx - s / 2, top = hor + full / 2 - lift - s;
        double b = Math.max(0.5, 1 - f / 12);
        String[] art = ICON[type];
        for (int row = 0; row < 7; row++) {
            for (int c = 0; c < 7; c++) {
                char ch = art[row].charAt(c);
                if (ch == '.') continue;
                int x0 = left + c * s / 7, x1 = left + (c + 1) * s / 7, y0 = top + row * s / 7, y1 = top + (row + 1) * s / 7;
                rect(g, x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0), shade(ch == 'w' ? 0xFFFFFFFF : DROP_COL[type], b));
            }
        }
    }

    private void sprite(GuiGraphics g, Zombie z) {
        double rx = z.x - px, ry = z.y - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);
        if (f < 0.2) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f), sh = (int) (full * KIND_SIZE[z.kind]), sw = sh * ZOMBIE[0].length() / ZOMBIE.length;
        int left = (int) (W / 2.0 * (1 + cam)) - sw / 2, top = hor + full / 2 - sh;
        top += (int) (Math.sin(ticks * (z.kind == 1 ? 0.3 : 0.15) + z.x * 7) * full * 0.015);   // shambling (runners shake faster)
        double b = Math.max(0.22, 1 - f / 9.5);
        boolean flash = z.flash > 0;
        for (int x = Math.floorDiv(left, CW) * CW; x < left + sw; x += CW) {
            int c = x / CW;
            if (x < 0 || c >= COLS || f >= zbuf[c]) continue;
            int u = Math.max(0, Math.min(ZOMBIE[0].length() - 1, (x + CW / 2 - left) * ZOMBIE[0].length() / sw));
            int clipTop = 0, clipBot = H;                         // behind a window you only see what fits through the hole
            if (winD[c] > 0 && f > winD[c]) {
                int wl = (int) (H / winD[c]), bottom = hor + wl / 2;
                clipTop = bottom - (int) (0.82 * wl);
                clipBot = bottom - (int) (0.22 * wl);
            }
            for (int row = 0; row < ZOMBIE.length; row++) {
                char ch = ZOMBIE[row].charAt(u);
                if (ch == '.') continue;
                int y0 = top + row * sh / ZOMBIE.length, y1 = Math.max(y0 + 1, top + (row + 1) * sh / ZOMBIE.length);
                y0 = Math.max(y0, clipTop);
                y1 = Math.min(y1, clipBot);
                if (y1 <= y0) continue;
                rect(g, x, y0, CW, y1 - y0, shade(pal(ch, z.kind, flash), ch == 'r' ? 1.2 : b));
            }
        }
        // health bar over the head when it is hurt
        if (z.hp < z.maxHp && f < 6) {
            int bw = Math.max(6, sw), bx = left + sw / 2 - bw / 2;
            rect(g, bx, top - 4, bw, 2, 0xAA000000);
            rect(g, bx, top - 4, Math.max(0, bw * z.hp / z.maxHp), 2, 0xFFE03A3A);
        }
    }

    private void weaponAndHud(GuiGraphics g) {
        // crosshair + hit marker (gold for a headshot)
        int cx = W / 2, cy = H / 2;
        int hitCol = headT > 20 ? 0xFFFFD84A : 0xFFFF4040;
        int cc = hit > 0 ? hitCol : 0xE0FFFFFF;
        rect(g, cx - 5, cy, 3, 1, cc); rect(g, cx + 3, cy, 3, 1, cc);
        rect(g, cx, cy - 5, 1, 3, cc); rect(g, cx, cy + 3, 1, 3, cc);
        if (hit > 0) { rect(g, cx - 3, cy - 3, 1, 1, hitCol); rect(g, cx + 3, cy - 3, 1, 1, hitCol);
                       rect(g, cx - 3, cy + 3, 1, 1, hitCol); rect(g, cx + 3, cy + 3, 1, 1, hitCol); }
        if (headT > 0) ctext(g, Component.translatable("cutemod.zombies.head").getString(), cx, cy - 20 - (40 - headT) / 6, headT > 20 ? 0xFFFFD84A : 0xFFB09A50);

        // the gun (bobs while walking, kicks when shooting, drops while reloading)
        int bobX = (int) (Math.sin(walkT * 0.2) * 2), bobY = (int) (Math.abs(Math.cos(walkT * 0.2)) * 2);
        int gx = W / 2 + 22 + bobX, gy = H - 34 + bobY + kick + (reload > 0 ? 14 : 0);
        if (cur == pistol) {
            rect(g, gx - 5, gy + 10, 9, 16, 0xFF2E2E36);
            rect(g, gx - 7, gy, 13, 11, 0xFF55555F);
            rect(g, gx - 7, gy, 13, 2, 0xFF7A7A86);
            rect(g, gx - 3, gy - 5, 5, 6, 0xFF44444E);
        } else if (cur == rifle) {
            rect(g, gx - 4, gy + 12, 8, 20, 0xFF2E2E36);
            rect(g, gx - 8, gy - 4, 16, 18, 0xFF3F4A38);
            rect(g, gx - 3, gy - 14, 6, 12, 0xFF2A2A30);
            rect(g, gx - 8, gy - 4, 16, 2, 0xFF5E6B54);
        } else if (cur == shotgun) {                                // two fat barrels and a wooden grip
            rect(g, gx - 4, gy + 14, 8, 18, 0xFF6A4424);
            rect(g, gx - 9, gy - 2, 18, 16, 0xFF4A4A54);
            rect(g, gx - 8, gy - 12, 7, 12, 0xFF2A2A30);
            rect(g, gx + 1, gy - 12, 7, 12, 0xFF2A2A30);
            rect(g, gx - 9, gy - 2, 18, 2, 0xFF7A7A86);
        } else if (cur == smg) {                                    // short and boxy, with a magazine at the side
            rect(g, gx - 4, gy + 12, 7, 18, 0xFF2E2E36);
            rect(g, gx - 6, gy - 2, 12, 14, 0xFF2E5A38);
            rect(g, gx - 2, gy - 10, 4, 9, 0xFF2A2A30);
            rect(g, gx + 2, gy + 10, 4, 12, 0xFF1E1E24);
            rect(g, gx - 6, gy - 2, 12, 2, 0xFF58A068);
        } else if (cur == magnum) {                                 // a big revolver: wooden grip, a cylinder and a long barrel
            rect(g, gx - 5, gy + 12, 9, 18, 0xFF5A3A1E);
            rect(g, gx - 7, gy - 1, 14, 13, 0xFF8A4A28);
            rect(g, gx - 3, gy - 12, 6, 12, 0xFF30241C);
            rect(g, gx - 2, gy + 2, 5, 5, 0xFF2A1A10);
            rect(g, gx - 7, gy - 1, 14, 2, 0xFFD08A60);
        } else if (cur == sniper) {                                 // a long barrel, a scope and a stock
            rect(g, gx - 4, gy + 14, 8, 18, 0xFF3A2A4A);
            rect(g, gx - 6, gy - 2, 12, 16, 0xFF4A3A6A);
            rect(g, gx - 2, gy - 26, 4, 26, 0xFF1E1A26);
            rect(g, gx - 4, gy - 12, 8, 7, 0xFF10101A);
            rect(g, gx - 1, gy - 10, 2, 3, 0xFF70C0FF);
            rect(g, gx - 6, gy - 2, 12, 2, 0xFF8A70B8);
        } else {                                                    // the ray gun: chunky, with a glowing barrel
            rect(g, gx - 4, gy + 12, 8, 18, 0xFF2A3A3E);
            rect(g, gx - 8, gy - 4, 16, 18, 0xFF2A6A70);
            rect(g, gx - 3, gy - 16, 6, 14, 0xFF38C0C0);
            rect(g, gx - 1, gy - 16, 2, 14, 0xFFB0FFFF);
            rect(g, gx - 6, gy + 2, 3, 8, 0xFF1A2A2E);
            rect(g, gx - 8, gy - 4, 16, 2, 0xFF70F0E8);
        }
        if (flashT > 0) {
            int fy = gy - (cur == pistol ? 9 : cur == rifle ? 18 : cur == shotgun ? 20 : cur == smg ? 14 : cur == magnum ? 14 : cur == sniper ? 28 : 18);
            rect(g, gx - 5, fy - 5, 10, 8, cur == ray ? 0xFF4AF0E0 : 0xFFFFD84A);
            rect(g, gx - 2, fy - 8, 4, 12, 0xFFFFFFFF);
        }

        // HUD
        rect(g, 4, H - 10, 62, 6, 0xAA000000);
        rect(g, 5, H - 9, (int) (60 * Math.max(0, hp) / maxHp()), 4, hp > maxHp() * 0.4 ? 0xFF5FD35A : 0xFFE03A3A);
        String ammo = cur.mag + "/" + (cur.infinite ? "--" : String.valueOf(cur.reserve));
        text(g, ammo, W - 6 - font().width(ammo), H - 11, reload > 0 ? 0xFFFFD866 : 0xFFFFFFFF);
        int ci = 0;
        for (int i = 0; i < weapons.length; i++) if (weapons[i] == cur) ci = i;
        String gn = gunName(ci);
        text(g, gn, W - 6 - font().width(gn), H - 21, 0xFFB8C4D8);
        if (mines > 0) {
            String mt = Component.translatable("cutemod.zombies.mines", mines).getString();
            text(g, mt, W - 6 - font().width(mt), H - 31, 0xFFFF9A80);
        }
        text(g, Component.translatable("cutemod.zombies.round_hud", round).getString(), 5, 4, 0xFFFFE9A0);
        String pts = Component.translatable("cutemod.zombies.points", points).getString();
        text(g, pts, W - 5 - font().width(pts), 4, 0xFFFFD866);
        int px0 = 5;                                                // taken perks: a small colored square per level
        for (int i = 0; i < PERKS; i++) for (int l = 0; l < perk[i]; l++) { rect(g, px0, 15, 4, 4, PERK_COL[i]); px0 += 5; }
        int fyy = 24;                                               // running power-ups: a label and a shrinking bar
        if (instaT > 0) { fxBar(g, "cutemod.zombies.fx.insta", instaT, 0xFFE05050, fyy); fyy += 13; }
        if (dblT > 0) fxBar(g, "cutemod.zombies.fx.double", dblT, 0xFFE8C030, fyy);
        if (reload > 0) ctext(g, Component.translatable("cutemod.zombies.reload").getString(), W / 2, H / 2 + 12, 0xFFFFD866);
        if (!offering) {
            if (tKind == 1) {
                int wi = stations.get(tIdx)[2];
                Weapon sw = weapons[wi];
                String p = sw.owned ? Component.translatable("cutemod.zombies.buy_ammo", sw.ammoCost).getString()
                        : Component.translatable("cutemod.zombies.buy_w", gunName(wi), sw.cost).getString();
                ctext(g, p, W / 2, H - 34, points >= (sw.owned ? sw.ammoCost : sw.cost) ? 0xFFFFE9A0 : 0xFFFF9A80);
                ctext(g, Component.translatable("cutemod.zombies.mines_buy", MINE_COST).getString(), W / 2, H - 24, 0xFFFFC8A0);
            } else if (tKind == 4) {                                  // the mystery box
                if (boxState == 0) ctext(g, Component.translatable("cutemod.zombies.box_buy", BOX_COST).getString(), W / 2, H - 34, points >= BOX_COST ? 0xFFFFE9A0 : 0xFFFF9A80);
                else if (boxState == 1) ctext(g, Component.translatable("cutemod.zombies.box_roll", gunName(1 + (ticks / 4) % 6)).getString(), W / 2, H - 34, 0xFFB8D8FF);
                else {
                    ctext(g, Component.translatable("cutemod.zombies.box_take", gunName(boxW)).getString(), W / 2, H - 34, 0xFFFFE9A0);
                    rect(g, W / 2 - 20, H - 22, 40 * boxT / 360, 3, 0xFFFFD84A);
                }
            } else if (tKind == 5) {
                ctext(g, Component.translatable("cutemod.zombies.secret_push").getString(), W / 2, H - 34, 0xFFE8C890);
            } else if (tKind == 2) {
                ctext(g, Component.translatable("cutemod.zombies.buy_door", doors.get(tIdx)[2]).getString(), W / 2, H - 34, points >= doors.get(tIdx)[2] ? 0xFFFFE9A0 : 0xFFFF9A80);
            } else if (tKind == 3) {
                Win w = wins.get(tIdx);
                ctext(g, Component.translatable("cutemod.zombies.repair", w.boards).getString(), W / 2, H - 34, 0xFFE8C890);
                if (repT > 0) rect(g, W / 2 - 15, H - 22, 30 * repT / 22, 3, 0xFFE8C890);
            }
        }
        if (msgT > 0) ctext(g, msg, W / 2, 16, msgT < 30 ? 0xFFB0A070 : 0xFFFFFFFF);
    }

    private void fxBar(GuiGraphics g, String key, int t, int color, int y) {
        text(g, Component.translatable(key).getString(), 5, y, color);
        rect(g, 5, y + 9, 40, 2, 0xAA000000);
        rect(g, 5, y + 9, 40 * t / 1200, 2, color);
    }

    /** The perk cards between two rounds: press 1-3 or click one. */
    private void renderOffer(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0x99000000);
        ctext(g, Component.translatable("cutemod.zombies.perk_title").getString(), W / 2, 14, 0xFFFFE9A0);
        int n = offer.length, x0 = (W - (n * CARD_W + (n - 1) * 4)) / 2;
        for (int i = 0; i < n; i++) {
            int p = offer[i], x = x0 + i * (CARD_W + 4), y = 30;
            boolean hv = in(mx, my, x, y, CARD_W, 86);
            rect(g, x, y, CARD_W, 86, hv ? 0xFF3C4E70 : 0xFF2A3348);
            rect(g, x, y, CARD_W, 3, PERK_COL[p]);
            String name = "[" + (i + 1) + "] " + Component.translatable("cutemod.zombies.perk." + p + ".name").getString();
            int ly = y + 8;
            for (var seq : font().split(FormattedText.of(name), CARD_W - 8)) {
                g.drawString(font(), seq, x + 4, ly, 0xFFFFFFFF, false);
                ly += 9;
            }
            ly += 3;
            for (var seq : font().split(FormattedText.of(Component.translatable("cutemod.zombies.perk." + p + ".desc").getString()), CARD_W - 8)) {
                if (ly > y + 70) break;
                g.drawString(font(), seq, x + 4, ly, 0xFFC8D0E0, false);
                ly += 9;
            }
            for (int l = 0; l < 3; l++) rect(g, x + 4 + l * 7, y + 76, 5, 5, l < perk[p] ? PERK_COL[p] : 0xFF4A5468);
        }
    }

    @Override
    public String hintKey() { return "cutemod.hint.zombies"; }

    @Override
    public Component status() { return Component.translatable("cutemod.zombies.status", round, kills, score); }

    @Override
    public Component endTitle() { return Component.translatable("cutemod.zombies.end", round); }
}
