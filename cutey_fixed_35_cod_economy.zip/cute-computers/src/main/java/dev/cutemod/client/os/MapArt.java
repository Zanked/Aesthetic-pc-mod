package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import java.util.function.IntPredicate;

/**
 * The pictures of the pet map: the little town (grass, roads, sea, lake, mountains, fields) and one small building for
 * every place on it. Only scenery is here; the clicks, the pet and the texts are in {@link PetMap}. The whole screen is
 * 300 x 166 and the header takes the top 17 pixels. Everything is drawn from the coordinates it is given, so the
 * places can be moved just by changing their numbers in {@link PetMap}.
 */
final class MapArt {
    private MapArt() {}

    static final int W = 300, H = 166, HEAD = 17;
    /** The map is taller than the screen: the town (166 high), the shopping boulevard under it and Downtown (the City) at the bottom. The screen scrolls over it. */
    static final int WORLD_H = 440, MAX_CAM = WORLD_H - H;

    // the places (ids of the map): where they stand (centre x, ground y)
    static final int HOME = 0, SCHOOL = 1, PARK = 2, STAGE = 3, FARM = 4, FISHING = 5, MARKET = 6, BALLOON = 7,
            AMUSEMENT = 8, CINEMA = 9, MUSEUM = 10, CAMP = 11, OLD_HOUSE = 12, FAIR = 13, QUIET = 14,
            // the little shops (apps of the pet): PetStyle, photo, stickers, pet stats, tic-tac-toe, the season
            WARDROBE = 15, PHOTO = 16, STICKERS = 17, PETSTATS = 18, TICTAC = 19, SEASON = 20,
            // the shopping boulevard under the town: the boutique (outfits) and the pantry (treats)
            BOUTIQUE = 21, PANTRY = 22,
            // Downtown, at the foot of the avenue: the long street of the pet (PetCity)
            CITY = 23, COUNT = 24;
    static final int[][] POS = {
            {128, 110}, {76, 108}, {182, 112}, {236, 108}, {46, 153}, {252, 153}, {116, 153}, {250, 68},
            {188, 68}, {130, 66}, {80, 66}, {28, 68}, {24, 110}, {172, 153}, {282, 110},
            {155, 110}, {86, 160}, {200, 160}, {50, 108}, {159, 66}, {219, 66},
            {62, 248}, {238, 248}, {150, 416}};

    /** True for the six little shops (narrow, they stand in the gaps) and for the two big shops of the boulevard. */
    static boolean littleShop(int id) { return id >= WARDROBE && id <= SEASON; }
    static boolean bigShop(int id) { return id == BOUTIQUE || id == PANTRY; }

    /** Half the width of the place for the pointer (a click inside it counts). */
    static int halfW(int id) { return id == CITY ? 42 : bigShop(id) ? 30 : littleShop(id) ? 9 : 18; }

    /** How far above the ground line the place reaches (for the pointer and the name flag). */
    static int height(int id) {
        if (id == CITY) return 66;
        if (bigShop(id)) return 58;
        if (littleShop(id)) return 30;
        return id == BALLOON ? 40 : id == AMUSEMENT || id == OLD_HOUSE || id == SCHOOL ? 38 : 32;
    }

    /** Where the pet stands when it has walked to the place (x), beside the door or the front. */
    static int standX(int id) {
        int x = POS[id][0];
        if (id == HOME) return x + 20;
        if (id == CITY) return x - 54;                                              // in front of the left tower, on the plaza
        return x + (bigShop(id) ? 44 : 15) * (x < 150 ? 1 : -1);
    }

    // ---------- tiny helpers (this class stands alone) ----------
    /**
     * The rows of the world that are on the screen now (set by {@link PetMap} while it draws, and put back after): the map is
     * taller than the screen, and a rectangle that is out of the view is not drawn at all (it would only be cut away).
     */
    static int viewTop = Integer.MIN_VALUE, viewBottom = Integer.MAX_VALUE;

    /** True if something at these world rows is on the screen. */
    static boolean seen(int y0, int y1) { return y1 >= viewTop && y0 <= viewBottom; }

    static void rect(GuiGraphics g, int x, int y, int w, int h, int c) {
        if (y > viewBottom || y + h < viewTop) return;
        g.fill(x, y, x + w, y + h, c);
    }

    static void ball(GuiGraphics g, int cx, int cy, int r, int c) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.round(Math.sqrt((r + 0.2) * (r + 0.2) - dy * dy));
            rect(g, cx - dx, cy + dy, dx * 2 + 1, 1, c);
        }
    }

    static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int c) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0, 1 - dy * dy / (double) (ry * ry + 1))));
            rect(g, cx - dx, cy + dy, dx * 2, 1, c);
        }
    }

    static void tri(GuiGraphics g, int cx, int top, int w, int h, int c) {
        for (int r = 0; r < h; r++) {
            int ww = Math.max(1, w * (r + 1) / h);
            rect(g, cx - ww / 2, top + r, ww, 1, c);
        }
    }

    static void ln(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        int n = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)));
        for (int i = 0; i <= n; i++) rect(g, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, 1, 1, c);
    }

    static int mix(int a, int b, float f) { return App.mix(a, b, f); }

    static void shadow(GuiGraphics g, int cx, int b, int rx) { oval(g, cx, b, rx, 3, 0x30000000); }

    // =====================================================================================================
    //  THE CITY: paving, a skyline of towers, streets with cars and people, a few green parks, the harbour and the lake
    // =====================================================================================================
    /** The streets: the two long ones across the map and the cross streets between them (x, y, w, h). */
    private static final int[][] H_STREETS = {{0, 76, W, 8}, {0, 122, W, 8}};
    private static final int[][] V_STREETS = {{100, 84, 8, 38}, {208, 84, 8, 38}, {64, 130, 8, 40}, {148, 130, 8, 40}};

    /** The places far to near (by the ground line, then from the left), so that the near ones cover the far ones. Worked out once. */
    private static final int[] ORDER = placesInOrder();

    private static int[] placesInOrder() {
        Integer[] order = new Integer[COUNT];
        for (int i = 0; i < order.length; i++) order[i] = i;
        java.util.Arrays.sort(order, (a, b) -> POS[a][1] != POS[b][1] ? Integer.compare(POS[a][1], POS[b][1]) : Integer.compare(POS[a][0], POS[b][0]));
        int[] o = new int[COUNT];
        for (int i = 0; i < o.length; i++) o[i] = order[i];
        return o;
    }

    /**
     * The picture of the world (the town, the boulevard, Downtown and every place on them) for the rows {@code top .. bottom}, in
     * the coordinates of the world: nothing outside these rows is drawn. {@link PetMap} bakes this into a texture (the picture
     * only changes with the game tick, the camera, the place under the pointer and the time of day), so it uses nothing but
     * rectangles. {@code hidden} / {@code locked} / {@code lit} say which places are not on the map yet, wrapped in mist, or
     * glowing (an event is on); {@code hover} is the place under the pointer (it glows and stands a pixel higher), or -1.
     */
    static void world(GuiGraphics g, int top, int bottom, int ticks, boolean night, int hover, int body, IntPredicate hidden, IntPredicate locked, IntPredicate lit) {
        int oldTop = viewTop, oldBottom = viewBottom;
        viewTop = top;                                                                  // only what is on the screen is drawn
        viewBottom = bottom;
        try {
            terrain(g, ticks, night);
            for (int id : ORDER) {
                if (hidden.test(id)) continue;
                int cx = POS[id][0], b = POS[id][1];
                if (b - height(id) - 8 > bottom || b + 8 < top) continue;               // out of the view
                if (id == hover) glow(g, cx, b, ticks);
                place(g, id, cx, b - (id == hover ? 1 : 0), ticks, night, lit.test(id), body);
                if (locked.test(id)) mist(g, cx, b, ticks);
            }
            if (night) {
                g.fill(0, HEAD, W, WORLD_H, 0x78101840);
                lampGlow(g);
                for (int id : new int[]{HOME, SCHOOL, CINEMA, OLD_HOUSE, STAGE, CAMP, MARKET})
                    if (!locked.test(id)) oval(g, POS[id][0], POS[id][1] - 2, 17, 6, 0x30FFD070);
                for (int id : new int[]{BOUTIQUE, PANTRY}) oval(g, POS[id][0], POS[id][1] - 2, 30, 7, 0x30FFD070);
                oval(g, POS[CITY][0], POS[CITY][1] - 2, 42, 8, 0x30FFD070);
            }
        } finally {
            viewTop = oldTop;
            viewBottom = oldBottom;
        }
    }

    static void terrain(GuiGraphics g, int ticks) { terrain(g, ticks, false); }

    static void terrain(GuiGraphics g, int ticks, boolean night) {
        // the paving of the blocks
        g.fillGradient(0, HEAD, W, H, 0xFFE9E5F2, 0xFFD9D4E6);
        for (int x = 0; x < W; x += 12) rect(g, x, HEAD, 1, H - HEAD, 0x0C6A5A8A);
        for (int y = HEAD; y < H; y += 12) rect(g, 0, y, W, 1, 0x0C6A5A8A);
        MapBoulevard.district(g, ticks, night);
        MapCity.district(g, ticks, night);
        skyline(g, ticks);
        greens(g, ticks);
        harbour(g, ticks);
        lake(g, ticks);
        // the streets: asphalt, a pavement on both sides, lane marks
        for (int[] r : V_STREETS) street(g, r[0], r[1], r[2], r[3], false);
        for (int[] r : H_STREETS) street(g, r[0], r[1], r[2], r[3], true);
        for (int[] r : V_STREETS) crossing(g, r[0], r[1], r[2], false);
        crossing(g, 100, 76, 8, true); crossing(g, 208, 76, 8, true); crossing(g, 64, 122, 8, true); crossing(g, 148, 122, 8, true);
        // things that stand along the streets
        for (int x : new int[]{22, 52, 92, 118, 168, 200, 224, 262}) lamp(g, x, 74, false);
        for (int x : new int[]{16, 60, 112, 160, 196, 236, 284}) lamp(g, x, 133, false);
        planter(g, 94, 72); planter(g, 114, 72); planter(g, 154, 72); planter(g, 222, 72); planter(g, 20, 119); planter(g, 140, 119); planter(g, 226, 119);
        trafficLight(g, 98, 74, ticks); trafficLight(g, 210, 85, ticks + 60); trafficLight(g, 62, 120, ticks + 30); trafficLight(g, 150, 131, ticks + 90);
        blocks(g, ticks);
        cars(g, ticks);
        people(g, ticks);
    }

    /** The towers at the back of the first row of the map. */
    private static void skyline(GuiGraphics g, int ticks) {
        int[][] t = {{60, 15, 36, 0xFF8AA8D8}, {75, 10, 26, 0xFFB8A0D8}, {104, 13, 40, 0xFF7ABAC8}, {118, 14, 30, 0xFFE0A8B8}, {157, 12, 38, 0xFF9AB0E0},
                {170, 16, 28, 0xFFC8B0E8}, {207, 12, 35, 0xFF88B8D0}, {220, 13, 27, 0xFFE8B8A0}};
        for (int k = 0; k < t.length; k++) tower(g, t[k][0], 62, t[k][1], t[k][2], t[k][3], ticks, k % 2 == 0);
    }

    /** A block of flats or an office: walls, lit windows, a light roof edge and sometimes an aerial. */
    private static void tower(GuiGraphics g, int x, int base, int w, int h, int c, int ticks, boolean aerial) {
        rect(g, x + 2, base - 1, w, 2, 0x22000000);
        rect(g, x, base - h, w, h, c);
        rect(g, x + w - 3, base - h, 3, h, mix(c, 0xFF000000, 0.16F));
        rect(g, x, base - h, w, 2, mix(c, 0xFFFFFFFF, 0.4F));
        for (int r = 0; r < h / 5 - 1; r++) for (int cc = 0; cc < (w - 3) / 4; cc++) {
            boolean on = (x * 7 + r * 13 + cc * 5 + ticks / 90) % 3 != 0;
            rect(g, x + 2 + cc * 4, base - h + 5 + r * 5, 2, 3, on ? 0xFFFFF0B0 : mix(c, 0xFF000000, 0.3F));
        }
        rect(g, x + w / 2 - 2, base - 6, 4, 6, 0xFF4A4868);                                  // the door
        if (aerial) { rect(g, x + w / 2, base - h - 5, 1, 5, 0xFF8A8AA0); if ((ticks / 30) % 2 == 0) rect(g, x + w / 2, base - h - 6, 1, 1, 0xFFE5484D); }
    }

    /** Houses that fill the gaps between the places: a block of flats (the café and the kiosk are shops of the pet now). */
    private static void blocks(GuiGraphics g, int ticks) {
        tower(g, 272, 118, 22, 30, 0xFFE8A8C0, ticks, true);
        tower(g, 262, 118, 9, 20, 0xFF9AB8E0, ticks, false);
    }

    /** The green islands of the city: the forest park (the camp), the lawn of the old house, the city park and the allotments of the farm. */
    private static void greens(GuiGraphics g, int ticks) {
        lawn(g, 0, 40, 60, 36);
        for (int x : new int[]{4, 14, 46, 52}) pine(g, x + 4, 66);
        pine(g, 8, 52); pine(g, 52, 54);
        lawn(g, 2, 90, 46, 30);
        lawn(g, 156, 86, 56, 34);
        for (int r = 0; r < 4; r++) {                                            // the allotments of the farm
            int y = 134 + r * 8;
            rect(g, 4, y, 84, 6, r % 2 == 0 ? 0xFFC9A96A : 0xFFB8935A);
            for (int x = 6; x < 86; x += 6) rect(g, x, y + 1, 2, 3, r % 2 == 0 ? 0xFF8ACB5C : 0xFFE8C84A);
        }
    }

    static void lawn(GuiGraphics g, int x, int y, int w, int h) {
        g.fillGradient(x, y, x + w, y + h, 0xFFB8E890, 0xFF8CD07A);
        rect(g, x, y, w, 1, 0xFFD8F4B8); rect(g, x, y + h - 1, w, 1, 0xFF6FBF6A);
        for (int i = 0; i < w * h / 70; i++) {
            int px = x + 2 + (i * 29 + 5) % Math.max(1, w - 4), py = y + 2 + (i * 17 + 3) % Math.max(1, h - 4);
            rect(g, px, py, 1, 2, 0xFF7CC46A); if (i % 7 == 0) { rect(g, px + 2, py, 1, 1, 0xFFFFFFFF); rect(g, px + 2, py - 1, 1, 1, 0xFFFFE066); }
        }
    }

    static void pine(GuiGraphics g, int cx, int b) {
        rect(g, cx, b - 2, 2, 3, 0xFF6A4228);
        tri(g, cx + 1, b - 20, 12, 12, 0xFF1A5A38); tri(g, cx + 1, b - 12, 16, 12, 0xFF2A7048); tri(g, cx + 1, b - 20, 5, 9, 0xFF3A8A58);
    }

    /** The sea in the top-right corner with a harbour: a quay, a lighthouse and a sailing boat. */
    private static void harbour(GuiGraphics g, int ticks) {
        if (!seen(HEAD, 90)) return;
        for (int x = 232; x < W; x++) {
            int bottom = HEAD + (x - 232) * 60 / 68;
            g.fillGradient(x, HEAD, x + 1, bottom, 0xFF4DB0E8, 0xFF7ACBF2);
            rect(g, x, bottom, 1, 2, 0xFFB8B4C8); rect(g, x, bottom + 2, 1, 1, 0xFF8A86A0);            // the stone quay
            if ((x + ticks / 8) % 11 == 0) rect(g, x, HEAD + 2 + (x * 7) % Math.max(1, bottom - HEAD - 2), 2, 1, 0xCCFFFFFF);
        }
        int bob = (int) Math.round(Math.sin(ticks / 22.0));
        rect(g, 270, 40 + bob, 12, 3, 0xFF8A5A3A); rect(g, 270, 40 + bob, 12, 1, 0xFFC8955C);           // a sailing boat
        rect(g, 276, 28 + bob, 1, 12, 0xFF6E4726); tri(g, 273, 29 + bob, 8, 10, 0xFFFFFFFF); tri(g, 280, 31 + bob, 6, 8, 0xFFFF8FB8);
        rect(g, 288, 56 + bob, 12, 3, 0xFF4D96FF); rect(g, 288, 56 + bob, 12, 1, 0xFF7ABAFF);            // a small motor boat
        rect(g, 292, 52 + bob, 4, 4, 0xFFFFFFFF);
        rect(g, 282, 20, 6, 10, 0xFFFFFFFF); rect(g, 282, 24, 6, 2, 0xFFE5484D); rect(g, 281, 18, 8, 2, 0xFFE5484D); rect(g, 284, 16, 2, 2, (ticks / 25) % 2 == 0 ? 0xFFFFE680 : 0xFFFFC832);   // the lighthouse
    }

    /** The lake of the city in the bottom-right corner: a stone promenade around it. */
    private static void lake(GuiGraphics g, int ticks) {
        oval(g, 252, 148, 47, 19, 0xFFB8B4C8); oval(g, 252, 148, 45, 17, 0xFFD8D4E4);
        oval(g, 252, 148, 43, 16, 0xFF4DA8E0); oval(g, 252, 147, 40, 14, 0xFF63BBEA);
        for (int i = 0; i < 4; i++) rect(g, 222 + (i * 17 + ticks / 10) % 56, 142 + (i * 5) % 12, 5, 1, 0x88FFFFFF);
        ball(g, 262, 141, 2, 0xFFFFFFFF); rect(g, 263, 141, 3, 1, 0xFFFFC832);                                   // a swan
    }

    static void street(GuiGraphics g, int x, int y, int w, int h, boolean horiz) {
        rect(g, x, y, w, h, 0xFF5E5C78);
        if (horiz) {
            rect(g, x, y - 2, w, 2, 0xFFC4C0D4); rect(g, x, y + h, w, 2, 0xFFC4C0D4);              // the pavements
            rect(g, x, y - 1, w, 1, 0xFFE8E4F4); rect(g, x, y + h + 1, w, 1, 0xFFA8A4BC);
            for (int i = x + 3; i < x + w; i += 14) rect(g, i, y + h / 2 - 1, 7, 1, 0xFFFFE680);
        } else {
            rect(g, x - 2, y, 2, h, 0xFFC4C0D4); rect(g, x + w, y, 2, h, 0xFFC4C0D4);
            for (int i = y + 3; i < y + h; i += 10) rect(g, x + w / 2 - 1, i, 1, 5, 0xFFFFE680);
        }
    }

    /** The zebra of a crossing at the end of a street. */
    static void crossing(GuiGraphics g, int x, int y, int w, boolean horizStreet) {
        if (horizStreet) { for (int i = 0; i < 4; i++) rect(g, x - 10, y + 1 + i * 2, 5, 1, 0xFFFFFFFF); }
        else for (int i = 0; i < 4; i++) rect(g, x + 1 + i * 2, y + 1, 1, 4, 0xFFFFFFFF);
    }

    static void lamp(GuiGraphics g, int x, int b, boolean glowOnly) {
        if (glowOnly) { ball(g, x, b - 8, 10, 0x30FFD070); ball(g, x, b - 8, 5, 0x55FFE090); return; }
        rect(g, x, b - 8, 1, 8, 0xFF6A6880); rect(g, x - 1, b - 9, 3, 2, 0xFF8A88A0); rect(g, x, b - 8, 1, 1, 0xFFFFE680);
    }

    /** The glow of the street lamps at night (drawn over the dark wash). */
    static void lampGlow(GuiGraphics g) {
        for (int x : new int[]{22, 52, 92, 118, 168, 200, 224, 262}) lamp(g, x, 74, true);
        for (int x : new int[]{16, 60, 112, 160, 196, 236, 284}) lamp(g, x, 133, true);
        MapBoulevard.lampGlow(g);
    }

    static void planter(GuiGraphics g, int x, int b) {
        rect(g, x - 3, b - 2, 7, 3, 0xFF8A5A3A); rect(g, x - 3, b - 2, 7, 1, 0xFFC8955C);
        ball(g, x, b - 5, 3, 0xFF3FA55A); rect(g, x - 1, b - 7, 1, 1, 0xFFFF8FB8); rect(g, x + 2, b - 5, 1, 1, 0xFFFFE066);
    }

    static void trafficLight(GuiGraphics g, int x, int b, int ticks) {
        int ph = (ticks / 160) % 2;
        rect(g, x, b - 8, 1, 8, 0xFF3A3A4A); rect(g, x - 1, b - 14, 3, 6, 0xFF2A2A3A);
        rect(g, x, b - 13, 1, 1, ph == 0 ? 0xFFE5484D : 0xFF5A2A2A); rect(g, x, b - 11, 1, 1, ph == 1 ? 0xFF6BCB77 : 0xFF2A4A2E);
    }

    /** Cars and a bus that drive along the two long streets. */
    private static void cars(GuiGraphics g, int ticks) {
        int[] cc = {0xFFE5484D, 0xFF4D96FF, 0xFFFFC832, 0xFF6BCB77, 0xFFB57BD6, 0xFFFF9A3C};
        for (int i = 0; i < 4; i++) {                                           // the upper street: left to right (lower lane), right to left (upper lane)
            int dir = i % 2 == 0 ? 1 : -1, y = dir > 0 ? 80 : 77;
            int x = Math.floorMod((int) (ticks * 0.7 * dir) + i * 83, W + 40) - 20;
            car(g, x, y, dir, cc[i % cc.length], false);
        }
        for (int i = 0; i < 3; i++) {                                           // the lower street
            int dir = i % 2 == 0 ? -1 : 1, y = dir > 0 ? 126 : 123;
            int x = Math.floorMod((int) (ticks * 0.55 * dir) + i * 110 + 40, W + 40) - 20;
            car(g, x, y, dir, cc[(i + 3) % cc.length], i == 1);
        }
    }

    static void car(GuiGraphics g, int x, int y, int dir, int c, boolean bus) {
        int len = bus ? 18 : 11;
        rect(g, x, y, len, 3, c); rect(g, x, y, len, 1, mix(c, 0xFFFFFFFF, 0.35F)); rect(g, x, y + 2, len, 1, mix(c, 0xFF000000, 0.25F));
        if (bus) { for (int k = 0; k < 4; k++) rect(g, x + 2 + k * 4, y + 1, 2, 1, 0xFFBFE6FF); }
        else rect(g, x + (dir > 0 ? 6 : 2), y - 1, 4, 2, mix(c, 0xFFFFFFFF, 0.2F));
        rect(g, x + 2, y + 3, 2, 1, 0xFF1A1A24); rect(g, x + len - 4, y + 3, 2, 1, 0xFF1A1A24);
        rect(g, dir > 0 ? x + len : x - 1, y + 1, 1, 1, 0xFFFFF0A0);
    }

    /** A few little people who walk along the pavements. */
    private static void people(GuiGraphics g, int ticks) {
        int[] shirt = {0xFFE5484D, 0xFF4D96FF, 0xFFFFC832, 0xFF6BCB77, 0xFFB57BD6};
        for (int i = 0; i < 5; i++) {
            int y = i < 3 ? 74 : 120, dir = i % 2 == 0 ? 1 : -1;
            int x = Math.floorMod((int) (ticks * 0.16 * dir) + i * 61, W);
            int step = (ticks / 8 + i) % 2;
            rect(g, x, y - 5, 2, 3, shirt[i]); rect(g, x, y - 7, 2, 2, 0xFFFFD8B0);
            rect(g, x, y - 2, 1, 2 + step, 0xFF3A3A5A); rect(g, x + 1, y - 2, 1, 3 - step, 0xFF3A3A5A);
        }
    }

    /** A soft light on the ground under the place the pointer is on. */
    static void glow(GuiGraphics g, int cx, int b, int ticks) {
        int p = 18 + (int) Math.round(Math.sin(ticks / 8.0) * 2);
        oval(g, cx, b - 2, p + 4, 8, 0x22FFFFFF); oval(g, cx, b - 2, p, 6, 0x33FFFFFF);
    }

    /** Mist over a place that is still locked: two soft rounds of cloud, a padlock in the middle. */
    static void mist(GuiGraphics g, int cx, int b, int ticks) {
        int dx = (int) Math.round(Math.sin(ticks / 40.0) * 2);
        oval(g, cx + dx, b - 15, 22, 17, 0x40E8EEF8); oval(g, cx - dx, b - 14, 19, 14, 0x55F2F0FA);
        for (int i = 0; i < 3; i++) ball(g, cx - 10 + i * 10 + dx, b - 8 + (i % 2) * 2, 5, 0x66FFFFFF);
        int lx = cx, ly = b - 16;
        rect(g, lx - 4, ly - 1, 9, 7, 0xFF7A6AA0); rect(g, lx - 4, ly - 1, 9, 1, 0xFFB8A8D8);
        rect(g, lx - 3, ly - 6, 1, 5, 0xFF7A6AA0); rect(g, lx + 3, ly - 6, 1, 5, 0xFF7A6AA0); rect(g, lx - 2, ly - 7, 5, 1, 0xFF7A6AA0);
        rect(g, lx, ly + 1, 1, 3, 0xFFF2ECF8);
    }

    // =====================================================================================================
    //  THE PLACES. cx = the middle, b = the ground line; every place is at most 36 wide and 36 high.
    // =====================================================================================================
    static void place(GuiGraphics g, int id, int cx, int b, int ticks, boolean night, boolean lit, int body) {
        shadow(g, cx, b, id == CITY ? 40 : littleShop(id) ? 10 : bigShop(id) ? 28 : id == AMUSEMENT || id == PARK ? 16 : 14);
        switch (id) {
            case HOME -> home(g, cx, b, ticks, night, body);
            case SCHOOL -> school(g, cx, b, ticks, night);
            case PARK -> park(g, cx, b, ticks);
            case STAGE -> stage(g, cx, b, ticks);
            case FARM -> farm(g, cx, b, ticks);
            case FISHING -> fishing(g, cx, b, ticks);
            case MARKET -> market(g, cx, b, ticks);
            case BALLOON -> balloon(g, cx, b, ticks);
            case AMUSEMENT -> amusement(g, cx, b, ticks);
            case CINEMA -> cinema(g, cx, b, ticks);
            case MUSEUM -> museum(g, cx, b, ticks);
            case CAMP -> camp(g, cx, b, ticks);
            case OLD_HOUSE -> oldHouse(g, cx, b, ticks, lit);
            case FAIR -> fair(g, cx, b, ticks, lit);
            case QUIET -> quiet(g, cx, b, ticks);
            case WARDROBE, PHOTO, STICKERS, PETSTATS, TICTAC, SEASON -> shop(g, id, cx, b, ticks, night);
            case BOUTIQUE -> MapBoulevard.boutique(g, cx, b, ticks, night);
            case PANTRY -> MapBoulevard.pantry(g, cx, b, ticks, night);
            case CITY -> MapCity.city(g, cx, b, ticks, night);
            default -> { }
        }
    }


    // ---------- the little shops: the apps of the pet that used to be icons in the room (wardrobe, photo, stickers, stats, tic-tac-toe, season) ----------
    /** The signs of the shops: the colour of the awning and the little picture over the door. */
    private static final int[] SHOP_COL = {0xFFB57BD6, 0xFF8A9AE8, 0xFFE98AC8, 0xFFE8A04A, 0xFF6FB8E8, 0xFFF0A030};

    /** A small shop, 18 wide and about 28 high: walls, an awning in the colour of the shop, a door and a sign with a picture. */
    private static void shop(GuiGraphics g, int id, int cx, int b, int ticks, boolean night) {
        int k = id - WARDROBE, col = SHOP_COL[k];
        rect(g, cx - 9, b - 15, 18, 15, 0xFFFFF4DC);                                         // the walls
        rect(g, cx + 5, b - 15, 4, 15, 0xFFE8DCC0);
        rect(g, cx - 10, b - 19, 20, 5, col);                                                // the awning with stripes
        for (int x = 0; x < 20; x += 4) rect(g, cx - 10 + x, b - 19, 2, 5, mix(col, 0xFFFFFFFF, 0.55F));
        rect(g, cx - 10, b - 15, 20, 1, mix(col, 0xFF000000, 0.25F));
        rect(g, cx - 7, b - 11, 6, 6, night ? 0xFFFFE680 : 0xFFA8DEFF);                      // the window
        rect(g, cx + 1, b - 11, 5, 11, 0xFF8A5A3A); rect(g, cx + 4, b - 6, 1, 1, 0xFFFFE680);   // the door
        rect(g, cx - 8, b - 29, 16, 9, 0xFFFFFFFF); rect(g, cx - 8, b - 29, 16, 1, mix(col, 0xFF000000, 0.2F));   // the sign board
        rect(g, cx - 8, b - 21, 16, 1, mix(col, 0xFF000000, 0.2F));
        rect(g, cx - 8, b - 29, 1, 9, mix(col, 0xFF000000, 0.2F)); rect(g, cx + 7, b - 29, 1, 9, mix(col, 0xFF000000, 0.2F));
        rect(g, cx - 5, b - 20, 1, 1, 0xFF8A8AA0); rect(g, cx + 4, b - 20, 1, 1, 0xFF8A8AA0);
        int sx = cx, sy = b - 25;                                                            // the picture, 9 x 6, in the middle of the board
        switch (k) {
            case 0 -> { rect(g, sx, sy - 1, 1, 1, col); tri(g, sx, sy, 9, 4, col); rect(g, sx - 4, sy + 3, 9, 1, col); }   // a hanger
            case 1 -> { rect(g, sx - 4, sy - 1, 9, 5, 0xFF5A4A86); rect(g, sx - 2, sy - 2, 3, 1, 0xFF5A4A86); ball(g, sx, sy + 1, 1, 0xFFA8DEFF); }   // a camera
            case 2 -> { rect(g, sx, sy - 2, 1, 5, col); rect(g, sx - 2, sy, 5, 1, col); rect(g, sx - 1, sy - 1, 3, 3, col); }   // a star
            case 3 -> { rect(g, sx - 4, sy + 1, 2, 3, col); rect(g, sx - 1, sy - 1, 2, 5, col); rect(g, sx + 2, sy - 2, 2, 6, col); }   // bars
            case 4 -> { rect(g, sx - 1, sy - 2, 1, 6, 0xFF5A4A86); rect(g, sx + 1, sy - 2, 1, 6, 0xFF5A4A86); rect(g, sx - 3, sy, 7, 1, 0xFF5A4A86); rect(g, sx - 3, sy + 2, 7, 1, 0xFF5A4A86); }   // a hash of the game
            default -> { rect(g, sx - 3, sy, 7, 4, col); rect(g, sx - 4, sy - 1, 9, 2, mix(col, 0xFFFFFFFF, 0.3F)); rect(g, sx, sy - 1, 1, 5, 0xFFE5484D); }   // a gift
        }
        if (night) rect(g, cx - 7, b - 11, 6, 1, 0x66FFFFFF);
        if ((ticks / 40 + k) % 4 == 0) { rect(g, cx + 8, b - 26, 1, 1, 0xFFFFFFFF); }          // a twinkle on the sign now and then
    }

    private static int win(boolean night) { return night ? 0xFFFFE680 : 0xFFA8DEFF; }

    private static void home(GuiGraphics g, int cx, int b, int ticks, boolean night, int body) {
        int roof = mix(body | 0xFF000000, 0xFF000000, 0.08F), roofL = mix(body | 0xFF000000, 0xFFFFFFFF, 0.3F), roofD = mix(body | 0xFF000000, 0xFF000000, 0.3F);
        rect(g, cx + 5, b - 27, 4, 9, 0xFFC87A5A); rect(g, cx + 5, b - 27, 4, 1, 0xFFE8A07A);
        for (int k = 0; k < 3; k++) ball(g, cx + 7 + (ticks / 12 + k) % 3 - 1, b - 30 - (ticks / 5 + k * 6) % 14, 1, 0x88FFFFFF);   // smoke
        rect(g, cx - 11, b - 13, 22, 13, 0xFFFFF3E0); rect(g, cx - 11, b - 13, 1, 13, 0xFFFFFFFF); rect(g, cx + 10, b - 13, 1, 13, 0xFFE2C9A0);
        for (int r = 0; r < 12; r++) {
            int w = 30 * (r + 1) / 12;
            rect(g, cx - w / 2, b - 25 + r, w, 1, r < 2 ? roofL : roof);
        }
        rect(g, cx - 15, b - 14, 30, 2, roofD);
        rect(g, cx - 2, b - 8, 5, 8, 0xFF8A5A3A); rect(g, cx + 1, b - 4, 1, 1, 0xFFFFD84D);
        for (int s = -1; s <= 1; s += 2) {
            int wx = cx + (s < 0 ? -9 : 5);
            rect(g, wx - 1, b - 11, 6, 6, 0xFFFFFFFF); rect(g, wx, b - 10, 4, 4, win(night)); rect(g, wx + 1, b - 10, 1, 4, 0xFFFFFFFF);
        }
        rect(g, cx - 14, b - 2, 3, 2, 0xFF3FA55A); rect(g, cx - 14, b - 4, 1, 2, 0xFFFF8FB8); rect(g, cx + 12, b - 2, 3, 2, 0xFF3FA55A); rect(g, cx + 13, b - 4, 1, 2, 0xFFFFE066);
    }

    private static void school(GuiGraphics g, int cx, int b, int ticks, boolean night) {
        rect(g, cx - 15, b - 12, 30, 12, 0xFFE8A07A); rect(g, cx - 15, b - 12, 30, 1, 0xFFF4C0A0);
        for (int y = b - 10; y < b; y += 3) rect(g, cx - 15, y, 30, 1, 0x20A04A2A);
        rect(g, cx - 16, b - 15, 32, 3, 0xFF4D6AD0); rect(g, cx - 16, b - 15, 32, 1, 0xFF7A94F0);
        rect(g, cx - 5, b - 24, 11, 10, 0xFFD88A66); rect(g, cx - 5, b - 24, 11, 1, 0xFFF4C0A0);
        tri(g, cx, b - 31, 13, 7, 0xFF4D6AD0);
        ball(g, cx, b - 19, 3, 0xFFFFFFFF); ball(g, cx, b - 19, 2, 0xFFFFF8E8);
        double an = ticks / 30.0; ln(g, cx, b - 19, cx + (int) Math.round(Math.cos(an) * 2), b - 19 + (int) Math.round(Math.sin(an) * 2), 0xFF3A2A3A);
        rect(g, cx, b - 38, 1, 8, 0xFF8A6A5A); rect(g, cx + 1, b - 38, 5 + (ticks / 10) % 2, 3, 0xFFE5484D);          // the flag
        rect(g, cx - 3, b - 7, 7, 7, 0xFF6E4726); rect(g, cx - 3, b - 7, 7, 1, 0xFF9A6A3C); rect(g, cx, b - 7, 1, 7, 0xFF4A2E16);
        for (int s = -1; s <= 1; s += 2) for (int k = 0; k < 2; k++) {
            int wx = cx + s * (8 + k * 5) - 2;
            rect(g, wx, b - 10, 4, 5, win(night)); rect(g, wx + 1, b - 10, 1, 5, 0xFFFFFFFF);
        }
    }

    private static void park(GuiGraphics g, int cx, int b, int ticks) {
        oval(g, cx + 7, b - 5, 13, 5, 0xFF5AB0E8); oval(g, cx + 7, b - 5, 10, 3, 0xFF7ACBF2);
        rect(g, cx + 3 + (ticks / 9) % 8, b - 6, 3, 1, 0x99FFFFFF);
        for (int i = 0; i < 2; i++) {
            int tx = cx - 12 + i * 8, th = 12 + i * 3;
            rect(g, tx - 1, b - th, 3, th, 0xFF7A4A2A);
            ball(g, tx, b - th - 3, 7, i == 0 ? 0xFF2E8B4A : 0xFF3FA55A); ball(g, tx - 2, b - th - 5, 3, 0xFF5DBB6A);
            if (i == 1) { rect(g, tx + 3, b - th - 2, 1, 1, 0xFFFF8FB8); rect(g, tx - 4, b - th, 1, 1, 0xFFFF8FB8); }
        }
        rect(g, cx - 4, b - 4, 8, 1, 0xFF9A6A3C); rect(g, cx - 4, b - 6, 8, 1, 0xFFC8955C); rect(g, cx - 4, b - 4, 1, 4, 0xFF6E4726); rect(g, cx + 3, b - 4, 1, 4, 0xFF6E4726);   // a bench
        rect(g, cx + 6, b - 8, 1, 3, 0xFFFFFFFF); ball(g, cx + 6, b - 9, 1, 0xFFFFC832);                                                              // a duck
    }

    private static void stage(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 15, b - 4, 30, 4, 0xFF8A5A3A); rect(g, cx - 15, b - 4, 30, 1, 0xFFC8955C);
        rect(g, cx - 13, b - 20, 26, 16, 0xFF3A2860);
        rect(g, cx - 13, b - 20, 6, 16, 0xFFC02844); rect(g, cx + 7, b - 20, 6, 16, 0xFFC02844);
        for (int k = 1; k < 6; k += 2) { rect(g, cx - 13 + k, b - 20, 1, 16, 0xFF8A1830); rect(g, cx + 7 + k, b - 20, 1, 16, 0xFF8A1830); }
        rect(g, cx - 14, b - 23, 28, 4, 0xFFFFC832); rect(g, cx - 14, b - 23, 28, 1, 0xFFFFE680);
        int sp = (ticks / 10) % 2;
        rect(g, cx - 1, b - 31 - sp, 3, 7, 0xFFFFD84D); rect(g, cx - 3, b - 29 - sp, 7, 3, 0xFFFFD84D); rect(g, cx, b - 29 - sp, 1, 1, 0xFFFFFFFF);   // the star
        int sw = (int) Math.round(Math.sin(ticks / 25.0) * 4);                               // the spotlights
        tri(g, cx - 4 + sw, b - 20, 10, 16, 0x26FFF0A0); tri(g, cx + 4 - sw, b - 20, 10, 16, 0x1CFFB0E0);
        ball(g, cx, b - 6, 2, 0xFFFFC8E0);
    }

    private static void farm(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 14, b - 12, 18, 12, 0xFFD8483E); rect(g, cx - 14, b - 12, 18, 1, 0xFFF07A6A);
        tri(g, cx - 5, b - 22, 22, 10, 0xFF7A2A2A);
        rect(g, cx - 9, b - 9, 8, 9, 0xFFFFFFFF); ln(g, cx - 9, b - 9, cx - 2, b - 1, 0xFFD8483E); ln(g, cx - 2, b - 9, cx - 9, b - 1, 0xFFD8483E);
        rect(g, cx + 7, b - 18, 7, 18, 0xFFC8D0D8); rect(g, cx + 7, b - 18, 2, 18, 0xFFE8EEF4); ball(g, cx + 10, b - 18, 4, 0xFFA8B0B8);
        for (int i = 0; i < 4; i++) { rect(g, cx - 14 + i * 4, b - 3, 1, 3, 0xFF8A5A3A); }
        rect(g, cx - 14, b - 2, 14, 1, 0xFFB98450);
        int hop = (ticks / 14) % 2; rect(g, cx + 16, b - 3 - hop, 3, 3, 0xFFFFFFFF); rect(g, cx + 18, b - 4 - hop, 2, 2, 0xFFFFFFFF);          // a lamb
    }

    private static void fishing(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 15, b - 9, 22, 4, 0xFFC8955C); rect(g, cx - 15, b - 9, 22, 1, 0xFFE8B880);
        for (int x = cx - 12; x < cx + 6; x += 4) rect(g, x, b - 9, 1, 4, 0xFF9A6A3C);
        for (int x = cx - 14; x < cx + 7; x += 7) rect(g, x, b - 5, 2, 6, 0xFF6E4726);
        int bob = (int) Math.round(Math.sin(ticks / 12.0));
        ln(g, cx - 13, b - 10, cx - 19, b - 20, 0xFF6E4726);
        ln(g, cx - 19, b - 20, cx - 20, b - 6 + bob, 0x99FFFFFF);
        ball(g, cx - 20, b - 5 + bob, 1, 0xFFE5484D);
        int j = ticks % 160;                                                                      // a fish jumps now and then
        if (j < 20) {
            int fx = cx + 6 + j, fy = b - 2 - (int) Math.round(Math.sin(j * Math.PI / 20) * 9);
            rect(g, fx, fy, 4, 2, 0xFFFF9A3C); rect(g, fx - 2, fy - 1, 2, 4, 0xFFFFC832); rect(g, fx + 3, fy, 1, 1, 0xFF3A2A3A);
        }
        for (int k = 0; k < 3; k++) rect(g, cx + 6 + k * 6 - (ticks / 10) % 5, b + 1 + k % 2, 4, 1, 0x88FFFFFF);
    }

    private static void market(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 12, b - 14, 24, 14, 0xFFFFF4DC);
        rect(g, cx - 13, b - 6, 26, 6, 0xFFC8955C); rect(g, cx - 13, b - 6, 26, 1, 0xFFE8B880);
        for (int k = 0; k < 26; k += 4) {
            rect(g, cx - 13 + k, b - 20, Math.min(4, 26 - k), 7, (k / 4) % 2 == 0 ? 0xFFE5484D : 0xFFFFFFFF);
            rect(g, cx - 13 + k, b - 14, Math.min(4, 26 - k), 2, (k / 4) % 2 == 0 ? 0xFFB02A30 : 0xFFE0D8E0);
        }
        ball(g, cx - 7, b - 8, 2, 0xFFE5484D); ball(g, cx - 3, b - 8, 2, 0xFFFF9A3C); ball(g, cx + 2, b - 8, 2, 0xFFFFE066); ball(g, cx + 7, b - 8, 2, 0xFF6BCB77);
        rect(g, cx - 15, b - 3, 4, 3, 0xFF9A6A3C); rect(g, cx + 12, b - 3, 4, 3, 0xFF9A6A3C);
        if ((ticks / 40) % 2 == 0) { rect(g, cx - 2, b - 17, 1, 1, 0xFFFFD84D); }
    }

    private static void balloon(GuiGraphics g, int cx, int b, int ticks) {
        int bob = (int) Math.round(Math.sin(ticks / 25.0) * 2);
        int by = b - 27 + bob;
        int[] band = {0xFFE5484D, 0xFFFFC832, 0xFF4D96FF};
        for (int dy = -9; dy <= 9; dy++) {
            int half = (int) Math.round(Math.sqrt(9.2 * 9.2 - dy * dy) * (dy > 3 ? 1.0 - (dy - 3) * 0.07 : 1.0));
            for (int dx = -half; dx <= half; dx++) rect(g, cx + dx, by + dy, 1, 1, band[Math.floorMod((dx + 16) / 4, 3)]);
        }
        rect(g, cx - 5, by - 6, 2, 2, 0x88FFFFFF);
        ln(g, cx - 5, by + 8, cx - 3, by + 14, 0xFF6E4726); ln(g, cx + 5, by + 8, cx + 3, by + 14, 0xFF6E4726);
        rect(g, cx - 4, by + 14, 8, 5, 0xFFC8955C); rect(g, cx - 4, by + 14, 8, 1, 0xFFE8B880);
        rect(g, cx - 8, b - 2, 16, 2, 0xFF8A6A5A); rect(g, cx - 6, b - 4, 1, 2, 0xFF6E4726); rect(g, cx + 5, b - 4, 1, 2, 0xFF6E4726);
    }

    private static void amusement(GuiGraphics g, int cx, int b, int ticks) {
        int r = 11, cy = b - r - 6;
        ln(g, cx, cy, cx - 6, b, 0xFF8A5A3A); ln(g, cx, cy, cx + 6, b, 0xFF8A5A3A); ln(g, cx + 1, cy, cx - 5, b, 0xFF8A5A3A); ln(g, cx + 1, cy, cx + 7, b, 0xFF8A5A3A);
        for (int a = 0; a < 36; a++) { double an = a * Math.PI / 18; rect(g, cx + (int) Math.round(Math.cos(an) * r), cy + (int) Math.round(Math.sin(an) * r), 1, 1, 0xFFE5484D); }
        int[] gc = {0xFFFFC832, 0xFF4D96FF, 0xFFFF8FB8, 0xFF6BCB77, 0xFFB57BD6, 0xFFFF9A3C};
        for (int i = 0; i < 6; i++) {
            double an = ticks / 90.0 + i * Math.PI / 3;
            int gx = cx + (int) Math.round(Math.cos(an) * r), gy = cy + (int) Math.round(Math.sin(an) * r);
            ln(g, cx, cy, gx, gy, 0x88FFFFFF); rect(g, gx - 1, gy, 3, 3, gc[i]); rect(g, gx - 1, gy + 2, 3, 1, mix(gc[i], 0xFF000000, 0.25F));
        }
        ball(g, cx, cy, 2, 0xFFFFD84D);
        rect(g, cx - 10, b - 2, 20, 2, 0xFF6E4726);
        for (int i = 0; i < 5; i++) rect(g, cx - 12 + i * 6, b - 4, 2, 2, (ticks / 12 + i) % 2 == 0 ? 0xFFFFE680 : 0xFFFF8FB8);     // blinking bulbs
    }

    private static void cinema(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 14, b - 15, 28, 15, 0xFF7A2848); rect(g, cx - 14, b - 15, 28, 1, 0xFF9A3A60);
        rect(g, cx - 16, b - 21, 32, 6, 0xFFFFC832); rect(g, cx - 16, b - 21, 32, 1, 0xFFFFE680); rect(g, cx - 16, b - 16, 32, 1, 0xFFC8952C);
        for (int i = 0; i < 8; i++) rect(g, cx - 14 + i * 4, b - 19, 2, 2, (ticks / 10 + i) % 2 == 0 ? 0xFFFFFFFF : 0xFFE5484D);          // chasing lights
        rect(g, cx - 11, b - 12, 7, 9, 0xFF3A1A5A); rect(g, cx - 10, b - 11, 5, 7, 0xFFB57BD6); ball(g, cx - 8, b - 8, 1, 0xFFFFE680);   // a poster
        rect(g, cx + 3, b - 12, 7, 9, 0xFF1A3A5A); rect(g, cx + 4, b - 11, 5, 7, 0xFF4D96FF); rect(g, cx + 5, b - 8, 3, 1, 0xFFFFFFFF);
        rect(g, cx - 2, b - 7, 4, 7, 0xFF3A1428);
        tri(g, cx, b - 27, 7, 6, 0xFFFF6B8E);
    }

    private static void museum(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 15, b - 15, 30, 13, 0xFFD8C8A8);
        tri(g, cx, b - 27, 34, 9, 0xFFF0E4CC); rect(g, cx - 17, b - 18, 34, 3, 0xFFFFF8E8); rect(g, cx - 17, b - 16, 34, 1, 0xFFC8B890);
        ball(g, cx, b - 22, 2, 0xFFC8952C);
        for (int i = 0; i < 5; i++) { rect(g, cx - 14 + i * 7, b - 15, 3, 13, 0xFFFFFFFF); rect(g, cx - 12 + i * 7, b - 15, 1, 13, 0xFFD8CDB8); }
        rect(g, cx - 18, b - 2, 36, 2, 0xFFE8DCC8); rect(g, cx - 18, b - 2, 36, 1, 0xFFFFFFFF);
        if ((ticks / 14) % 3 != 0) { rect(g, cx + 12, b - 24, 3, 1, 0xFFFFFFFF); rect(g, cx + 13, b - 25, 1, 3, 0xFFFFFFFF); }
    }

    private static void camp(GuiGraphics g, int cx, int b, int ticks) {
        tri(g, cx - 11, b - 24, 12, 24, 0xFF1A5A38); tri(g, cx - 11, b - 16, 16, 16, 0xFF2A7048);
        rect(g, cx - 12, b - 2, 3, 2, 0xFF6A4228);
        tri(g, cx + 3, b - 17, 20, 17, 0xFFE8803A); tri(g, cx + 3, b - 17, 10, 17, 0xFFF4A860); tri(g, cx + 3, b - 8, 6, 8, 0xFF3A2A3A);
        int fx = cx + 16, fh = 5 + (ticks / 4) % 2;
        ball(g, fx, b - 4, 5, 0x22FFB040);
        rect(g, fx - 3, b - 1, 7, 1, 0xFF6A4228);
        tri(g, fx, b - 1 - fh, 5, fh, 0xFFFF7A2A); tri(g, fx, b - fh + 1, 3, fh - 2, 0xFFFFC832);
        rect(g, fx - 2 + (ticks / 6) % 3, b - fh - 3 - (ticks / 3) % 6, 1, 1, 0xFFFFD84D);
    }

    private static void oldHouse(GuiGraphics g, int cx, int b, int ticks, boolean lit) {
        if (lit) ball(g, cx, b - 14, 18, 0x18B57BD6);
        rect(g, cx - 12, b - 14, 24, 14, 0xFF3A2858); rect(g, cx - 12, b - 14, 1, 14, 0xFF4A3470);
        tri(g, cx, b - 29, 30, 15, 0xFF2A1A44); tri(g, cx - 1, b - 29, 14, 15, 0xFF3A2858);
        rect(g, cx + 6, b - 30, 3, 8, 0xFF2A1A44);
        for (int i = 0; i < 2; i++) {
            boolean on = (ticks / 22 + i * 4) % 7 != 0;
            rect(g, cx - 9 + i * 12, b - 11, 5, 6, on ? 0xFFFFD84D : 0xFF6A5030);
        }
        rect(g, cx - 2, b - 7, 5, 7, 0xFF120A20);
        ball(g, cx + 15, b - 3, 3, 0xFFE8803A); rect(g, cx + 15, b - 7, 1, 2, 0xFF3A7A3A);           // a pumpkin
        rect(g, cx + 14, b - 4, 1, 1, 0xFFFFF0A0); rect(g, cx + 16, b - 4, 1, 1, 0xFFFFF0A0);
        int bx = cx - 14 + (ticks / 3) % 28, by = b - 30 + (int) Math.round(Math.sin(ticks / 5.0) * 2);   // a bat
        boolean up = (ticks / 6) % 2 == 0;
        rect(g, bx + 1, by, 2, 2, 0xFF0A0614); rect(g, bx - 1, by + (up ? -1 : 1), 2, 1, 0xFF0A0614); rect(g, bx + 3, by + (up ? -1 : 1), 2, 1, 0xFF0A0614);
        rect(g, cx - 15, b - 8, 1, 8, 0xFF120A20); ln(g, cx - 15, b - 8, cx - 18, b - 13, 0xFF120A20); ln(g, cx - 15, b - 6, cx - 11, b - 12, 0xFF120A20);   // a bare tree
    }

    private static void fair(GuiGraphics g, int cx, int b, int ticks, boolean lit) {
        rect(g, cx - 11, b - 14, 22, 14, 0xFFFFF4DC);
        rect(g, cx - 12, b - 6, 24, 6, 0xFFC8955C); rect(g, cx - 12, b - 6, 24, 1, 0xFFE8B880);
        for (int k = 0; k < 24; k += 4) {
            rect(g, cx - 12 + k, b - 20, 4, 7, (k / 4) % 2 == 0 ? 0xFF4D96FF : 0xFFFFFFFF);
            rect(g, cx - 12 + k, b - 14, 4, 2, (k / 4) % 2 == 0 ? 0xFF2A5AC0 : 0xFFE0D8E0);
        }
        ball(g, cx - 3, b - 9, 2, 0xFFB57B4A); ball(g, cx + 4, b - 9, 2, 0xFFFF8FB8);
        int[] bc = {0xFFFF6B6B, 0xFFFFC832, 0xFF6BCB77};
        for (int i = 0; i < 3; i++) {
            int bx = cx - 9 + i * 9 + (int) Math.round(Math.sin((ticks + i * 15) / 18.0) * 2), by = b - 28 + (int) Math.round(Math.sin((ticks + i * 9) / 22.0));
            ball(g, bx, by, 3, bc[i]); rect(g, bx - 1, by - 2, 1, 1, 0x99FFFFFF); ln(g, bx, by + 4, cx - 9 + i * 9, b - 20, 0xAA8A7A8A);
        }
        for (int i = 0; i < 24; i += 6) tri(g, cx - 12 + i + 3, b - 22, 5, 3, lit ? ((ticks / 10 + i) % 2 == 0 ? 0xFFFFE680 : 0xFFFF8FB8) : 0xFFE5484D);
    }

    /** The Quiet Place: a small stone hut with a violet door, a lantern and a star that bobs over the roof. */
    private static void quiet(GuiGraphics g, int cx, int b, int ticks) {
        ball(g, cx, b - 16, 17, 0x14B79CFF);
        rect(g, cx - 11, b - 12, 22, 12, 0xFF2B2250); rect(g, cx - 11, b - 12, 1, 12, 0xFF3C3070); rect(g, cx + 10, b - 12, 1, 12, 0xFF1A1440);
        tri(g, cx, b - 24, 28, 12, 0xFF1A1440); tri(g, cx - 1, b - 24, 12, 12, 0xFF2B2250);
        rect(g, cx - 3, b - 8, 7, 8, 0xFF0B0820);
        boolean on = (ticks / 30) % 9 != 0;
        rect(g, cx - 2, b - 7, 5, 7, on ? 0xFF6A4FC0 : 0xFF3A2C7A);
        rect(g, cx + 14, b - 12, 1, 12, 0xFF3A2C7A);
        rect(g, cx + 13, b - 15, 3, 3, (ticks / 12) % 5 == 0 ? 0xFFFFE680 : 0xFFFFD866);
        int sy = b - 30 - (int) Math.round(Math.sin(ticks / 14.0) * 2);
        rect(g, cx, sy - 2, 1, 5, 0xFFFFD866); rect(g, cx - 2, sy, 5, 1, 0xFFFFD866); rect(g, cx - 1, sy - 1, 3, 3, 0xFFFFF0A0);
    }
}
