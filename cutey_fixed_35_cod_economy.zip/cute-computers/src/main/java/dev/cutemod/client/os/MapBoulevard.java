package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.MapArt.W;
import static dev.cutemod.client.os.MapArt.WORLD_H;
import static dev.cutemod.client.os.MapArt.ball;
import static dev.cutemod.client.os.MapArt.ln;
import static dev.cutemod.client.os.MapArt.mix;
import static dev.cutemod.client.os.MapArt.oval;
import static dev.cutemod.client.os.MapArt.rect;
import static dev.cutemod.client.os.MapArt.tri;

/**
 * The shopping boulevard under the town: a third street, a warm promenade with a fountain square, a lawn with a pet
 * agility course, a bus stop, and the two big shops of the pet: the Boutique (outfits) and the Pantry (treats).
 * Only pictures are here; the clicks and the texts are in {@link PetMap}. Everything is drawn from the coordinates
 * it is given, in the world of the map (the screen scrolls over it, see {@link MapArt#WORLD_H}).
 */
final class MapBoulevard {
    private MapBoulevard() {}

    /** The third street, the fountain square and the lamps. */
    private static final int STREET_Y = 170, FX = 150, FY = 250;
    private static final int[] SIDE_LAMPS = {16, 96, 204, 284}, PLAZA_LAMPS = {101, 199};
    private static final int LAMP_Y = 187, PLAZA_LAMP_Y = 274;

    private static int dark(int c, float f) { return mix(c, 0xFF000000, f); }

    private static int light(int c, float f) { return mix(c, 0xFFFFFFFF, f); }

    // =====================================================================================================
    //  small pictures that the places use
    // =====================================================================================================
    static void heart(GuiGraphics g, int x, int y, int c) {
        rect(g, x, y, 2, 1, c); rect(g, x + 3, y, 2, 1, c); rect(g, x, y + 1, 5, 1, c); rect(g, x + 1, y + 2, 3, 1, c); rect(g, x + 2, y + 3, 1, 1, c);
    }

    static void bone(GuiGraphics g, int x, int y, int c) {
        rect(g, x + 1, y + 1, 7, 1, c);
        rect(g, x, y, 2, 1, c); rect(g, x, y + 2, 2, 1, c); rect(g, x + 7, y, 2, 1, c); rect(g, x + 7, y + 2, 2, 1, c);
    }

    /** A fish swimming to the right, about 8 x 4. */
    static void fish(GuiGraphics g, int x, int y, int c, int eye) {
        rect(g, x + 1, y, 4, 4, c); rect(g, x, y + 1, 6, 2, c); rect(g, x + 6, y, 1, 4, mix(c, 0xFFFFFFFF, 0.2F)); rect(g, x + 7, y - 1, 1, 6, mix(c, 0xFFFFFFFF, 0.2F));
        rect(g, x + 1, y + 1, 1, 1, eye); rect(g, x + 2, y + 3, 2, 1, mix(c, 0xFFFFFFFF, 0.45F));
    }

    static void cookie(GuiGraphics g, int cx, int cy, int r) {
        ball(g, cx, cy, r, 0xFFD9A25E); ball(g, cx - 1, cy - 1, Math.max(1, r - 2), 0xFFE8B878);
        rect(g, cx - 1, cy, 1, 1, 0xFF6A3A1E); rect(g, cx + 1, cy - 1, 1, 1, 0xFF6A3A1E); rect(g, cx, cy + 1, 1, 1, 0xFF6A3A1E);
    }

    /** A hanger with a little garment on it (cx = the hook, y = the top). */
    static void garment(GuiGraphics g, int cx, int y, int c) {
        rect(g, cx, y, 1, 1, 0xFF8A7A9A);
        ln(g, cx, y + 1, cx - 3, y + 2, 0xFF8A7A9A); ln(g, cx, y + 1, cx + 3, y + 2, 0xFF8A7A9A);
        rect(g, cx - 3, y + 3, 7, 4, c); rect(g, cx - 3, y + 3, 7, 1, light(c, 0.4F)); rect(g, cx - 4, y + 3, 1, 2, c); rect(g, cx + 4, y + 3, 1, 2, c);
        rect(g, cx - 3, y + 6, 7, 1, dark(c, 0.2F));
    }

    private static void ring(GuiGraphics g, int cx, int cy, int rx, int ry, int c, boolean upperHalf) {
        int n = Math.max(12, (rx + ry) * 4);
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            if (upperHalf && Math.sin(a) > 0.05) continue;
            rect(g, cx + (int) Math.round(Math.cos(a) * rx), cy + (int) Math.round(Math.sin(a) * ry), 1, 1, c);
        }
    }

    private static void cat(GuiGraphics g, int x, int y, int ticks, int fur) {
        rect(g, x, y - 4, 6, 4, fur); rect(g, x, y - 4, 6, 1, light(fur, 0.3F));                       // the body
        rect(g, x + 5, y - 7, 4, 4, fur); rect(g, x + 5, y - 8, 1, 1, fur); rect(g, x + 8, y - 8, 1, 1, fur);   // the head, the ears
        rect(g, x + 6, y - 6, 1, 1, 0xFF3A2A3A); rect(g, x + 8, y - 6, 1, 1, 0xFF3A2A3A);
        if ((ticks / 70) % 6 == 0) { rect(g, x + 6, y - 6, 1, 1, fur); rect(g, x + 8, y - 6, 1, 1, fur); }   // a blink
        int wag = (int) Math.round(Math.sin(ticks / 12.0) * 2);
        rect(g, x - 1, y - 2, 1, 2, fur); rect(g, x - 2 + wag / 2, y - 6, 1, 4, fur); rect(g, x - 2 + wag, y - 7, 1, 1, dark(fur, 0.2F));   // the tail
        rect(g, x + 1, y - 1, 1, 1, light(fur, 0.5F)); rect(g, x + 4, y - 1, 1, 1, light(fur, 0.5F));
    }

    private static void person(GuiGraphics g, int x, int y, int shirt, int hair, int step) {
        rect(g, x, y - 5, 2, 3, shirt); rect(g, x, y - 7, 2, 2, 0xFFFFD8B0); rect(g, x, y - 8, 2, 1, hair);
        rect(g, x, y - 2, 1, 2 + step, 0xFF3A3A5A); rect(g, x + 1, y - 2, 1, 3 - step, 0xFF3A3A5A);
    }

    /** A small dog that trots to the right (dir = 1) or the left (dir = -1). */
    private static void dog(GuiGraphics g, int x, int y, int dir, int ticks, int fur) {
        int step = (ticks / 5) % 2;
        int bx = dir > 0 ? x : x + 3, hx = dir > 0 ? x + 6 : x;
        rect(g, bx, y - 4, 6, 3, fur); rect(g, bx, y - 4, 6, 1, light(fur, 0.3F));
        rect(g, hx, y - 6, 3, 3, fur); rect(g, hx + (dir > 0 ? 2 : 0), y - 5, 1, 1, 0xFF3A2A3A);
        rect(g, hx + (dir > 0 ? 0 : 2), y - 7, 1, 2, dark(fur, 0.3F));                                     // an ear
        rect(g, dir > 0 ? bx - 1 : bx + 6, y - 5 - step, 1, 2, fur);                                       // the tail wags
        rect(g, bx + 1, y - 1, 1, 1 + step, dark(fur, 0.3F)); rect(g, bx + 4, y - 1, 1, 2 - step, dark(fur, 0.3F));
    }

    private static void pigeon(GuiGraphics g, int x, int y, int ticks, int seed) {
        boolean peck = (ticks / 14 + seed) % 5 == 0;
        rect(g, x, y - 3, 4, 2, 0xFF9A98B0); rect(g, x, y - 3, 4, 1, 0xFFB8B6CC); rect(g, x + 3, y - 3, 1, 1, 0xFF6E6C88);
        rect(g, peck ? x + 4 : x + 3, peck ? y - 2 : y - 5, 1, peck ? 2 : 2, 0xFF9A98B0);
        rect(g, x + 5, peck ? y - 1 : y - 4, 1, 1, 0xFFFFC832);
        rect(g, x + 1, y - 1, 1, 1, 0xFFE07A8A); rect(g, x + 3, y - 1, 1, 1, 0xFFE07A8A);
    }

    private static void tree(GuiGraphics g, int cx, int b, int r, int leaf) {
        rect(g, cx - 1, b - r - 2, 3, r + 3, 0xFF7A4A2A); rect(g, cx - 1, b - r - 2, 1, r + 3, 0xFF9A6A3C);
        ball(g, cx, b - r - 4, r, leaf); ball(g, cx - 2, b - r - 6, r - 2, light(leaf, 0.25F));
        rect(g, cx + r / 2, b - r - 3, 1, 1, 0xFFFF8FB8); rect(g, cx - r / 2, b - r - 1, 1, 1, 0xFFFFE066);
    }

    private static void bench(GuiGraphics g, int cx, int b) {
        rect(g, cx - 6, b - 3, 12, 1, 0xFFC8955C); rect(g, cx - 6, b - 2, 12, 1, 0xFF9A6A3C);
        rect(g, cx - 6, b - 6, 12, 1, 0xFFC8955C); rect(g, cx - 6, b - 5, 12, 1, 0xFF9A6A3C);
        rect(g, cx - 6, b - 2, 1, 3, 0xFF6E4726); rect(g, cx + 5, b - 2, 1, 3, 0xFF6E4726);
        rect(g, cx - 6, b - 6, 1, 4, 0xFF6E4726); rect(g, cx + 5, b - 6, 1, 4, 0xFF6E4726);
    }

    static void paw(GuiGraphics g, int x, int y, int c) {
        rect(g, x, y + 1, 3, 2, c); rect(g, x - 1, y, 1, 1, c); rect(g, x + 1, y - 1, 1, 1, c); rect(g, x + 3, y, 1, 1, c);
    }

    private static void flowerBox(GuiGraphics g, int x, int y, int w, int a, int b2) {
        rect(g, x, y + 2, w, 3, 0xFF8A5A3A); rect(g, x, y + 2, w, 1, 0xFFC8955C);
        for (int i = 0; i < w; i += 2) {
            rect(g, x + i, y + 1 - (i / 2) % 2, 1, 2, 0xFF3FA55A);
            if (i % 4 == 0) rect(g, x + i, y - 1 - (i / 4) % 2, 2, 2, a); else rect(g, x + i, y - (i / 3) % 2, 1, 2, b2);
        }
    }

    // =====================================================================================================
    //  THE DISTRICT
    // =====================================================================================================
    static void district(GuiGraphics g, int ticks, boolean night) {
        if (!MapArt.seen(166, MapCity.TOP)) return;                             // the screen shows only the town
        paving(g);
        MapArt.street(g, 0, STREET_Y, W, 8, true);
        MapArt.crossing(g, 64, STREET_Y, 8, true); MapArt.crossing(g, 148, STREET_Y, 8, true);
        MapArt.trafficLight(g, 152, STREET_Y - 2, ticks + 40);
        square(g, ticks, night);
        paws(g);
        lawn(g, ticks);
        for (int x : new int[]{30, 78, 120, 182, 222, 270}) MapArt.planter(g, x, LAMP_Y - 1);
        for (int x : SIDE_LAMPS) MapArt.lamp(g, x, LAMP_Y, false);
        for (int x : PLAZA_LAMPS) MapArt.lamp(g, x, PLAZA_LAMP_Y, false);
        sides(g, ticks);
        tree(g, 112, 302, 6, 0xFF4AB868); tree(g, 196, 302, 6, 0xFF4AB868);
        busStop(g, 266, 298, ticks);
        flowerCart(g, 224, 296, ticks);
        hedge(g, 0, 303, W, ticks);
        traffic(g, ticks);
        people(g, ticks);
        bunting(g, 92, 207, 208, 207, 12, ticks);
        if (night) lightStrings(g, ticks);
    }

    /** The glow of the lamps of the boulevard at night (drawn over the dark wash). */
    static void lampGlow(GuiGraphics g) {
        for (int x : SIDE_LAMPS) MapArt.lamp(g, x, LAMP_Y, true);
        for (int x : PLAZA_LAMPS) MapArt.lamp(g, x, PLAZA_LAMP_Y, true);
        ball(g, 150, FY - 10, 20, 0x1840C8FF);
    }

    private static void paving(GuiGraphics g) {
        g.fillGradient(0, 166, W, MapCity.TOP, 0xFFF7ECE6, 0xFFEAD6D8);
        for (int y = 180, r = 0; y < MapCity.TOP; y += 5, r++) {                                   // the bricks of the promenade
            if (!MapArt.seen(y, y + 5)) continue;
            rect(g, 0, y, W, 1, 0x14905070);
            for (int x = (r % 2) * 5; x < W; x += 10) rect(g, x, y + 1, 1, 4, 0x0E905070);
        }
        rect(g, 0, 180, W, 1, 0x22FFFFFF);
        for (int x = 0; x < W; x += 4) rect(g, x, 181, 2, 1, 0x1AB0809A);                      // the kerb shadow
    }

    /** The round square with the fountain: rings of stones, a bench on each side, pigeons and two hedge sculptures. */
    private static void square(GuiGraphics g, int ticks, boolean night) {
        oval(g, FX, FY + 4, 56, 27, 0xFFCDBFCF);                                               // the edge of the square
        oval(g, FX, FY + 3, 54, 25, 0xFFF4E8EE);
        oval(g, FX, FY + 3, 46, 21, 0xFFE9D6E0);
        oval(g, FX, FY + 3, 38, 17, 0xFFF4E8EE);
        for (int i = 0; i < 28; i++) {                                                          // the stones of the ring
            double a = i * Math.PI * 2 / 28;
            int sx = FX + (int) Math.round(Math.cos(a) * 50), sy = FY + 3 + (int) Math.round(Math.sin(a) * 23);
            rect(g, sx - 1, sy, 3, 1, 0x30906080);
        }
        for (int i = 0; i < 20; i++) {
            double a = i * Math.PI * 2 / 20 + 0.15;
            rect(g, FX + (int) Math.round(Math.cos(a) * 42), FY + 3 + (int) Math.round(Math.sin(a) * 19), 2, 1, 0x28906080);
        }
        for (int k = 0; k < 8; k++) {                                                           // a star of the stones round the fountain
            double a = k * Math.PI / 4;
            ln(g, FX + (int) Math.round(Math.cos(a) * 26), FY + 3 + (int) Math.round(Math.sin(a) * 12), FX + (int) Math.round(Math.cos(a) * 36), FY + 3 + (int) Math.round(Math.sin(a) * 16), 0x30F59AB8);
        }
        bench(g, 108, FY + 14); bench(g, 192, FY + 14);
        topiary(g, 114, 278, true); topiary(g, 186, 278, false);
        fountain(g, FX, FY, ticks, night);
        pigeon(g, 124, FY + 24, ticks, 0); pigeon(g, 133, FY + 27, ticks, 2); pigeon(g, 170, FY + 25, ticks, 4);
    }

    private static void fountain(GuiGraphics g, int cx, int b, int ticks, boolean night) {
        int stone = 0xFFE2DCEE, stoneD = 0xFFA79BBE;
        oval(g, cx, b + 5, 25, 10, stoneD);                                                     // the front wall of the basin
        oval(g, cx, b + 3, 25, 10, 0xFFC8BEDA);
        oval(g, cx, b + 1, 25, 10, stone);                                                      // the rim
        oval(g, cx, b + 1, 21, 8, 0xFF58B2E4); oval(g, cx, b, 19, 7, 0xFF72C6F0);              // the water
        if (night) oval(g, cx, b, 19, 7, 0x40FFF0A0);
        for (int i = 0; i < 3; i++) {                                                           // ripples
            int ph = (ticks / 3 + i * 14) % 42;
            ring(g, cx, b + 1, 4 + ph * 14 / 42, 1 + ph * 5 / 42, 0x66FFFFFF, false);
        }
        rect(g, cx - 3, b - 12, 6, 14, stoneD); rect(g, cx - 2, b - 12, 4, 14, stone);          // the column
        oval(g, cx, b - 7, 11, 4, stoneD); oval(g, cx, b - 8, 11, 4, stone); oval(g, cx, b - 8, 9, 3, 0xFF72C6F0);   // the lower bowl
        rect(g, cx - 1, b - 20, 3, 9, stone); rect(g, cx + 1, b - 20, 1, 9, stoneD);
        oval(g, cx, b - 15, 6, 2, stone); oval(g, cx, b - 15, 4, 1, 0xFF72C6F0);                 // the upper bowl
        // a little stone cat on the top
        rect(g, cx - 2, b - 25, 5, 5, 0xFFD2CBE0); rect(g, cx - 2, b - 25, 5, 1, 0xFFF4F0FA);
        rect(g, cx - 2, b - 28, 4, 3, 0xFFD2CBE0); rect(g, cx - 2, b - 29, 1, 1, 0xFFD2CBE0); rect(g, cx + 1, b - 29, 1, 1, 0xFFD2CBE0);
        rect(g, cx + 3, b - 24, 1, 4, 0xFFC0B8D4); rect(g, cx + 3, b - 25, 1, 1, 0xFFC0B8D4);
        // the spray: drops fly out of the upper bowl and fall into the basin
        for (int k = 0; k < 6; k++) for (int s = -1; s <= 1; s += 2) {
            double t = ((ticks * 0.9 + k * 6) % 36) / 36.0;
            int x = cx + (int) Math.round(s * (3 + t * 15)), y = (b - 17) - (int) Math.round(Math.sin(Math.PI * t) * 7) + (int) Math.round(t * t * 19);
            rect(g, x, y, 1, 2, 0xCCDDF4FF);
        }
        for (int k = 0; k < 5; k++) {                                                           // curtains of water from the lower bowl
            int dy = (ticks / 2 + k * 3) % 9;
            rect(g, cx - 10 + k * 5 - (k > 2 ? 0 : 0), b - 6 + dy, 1, 2, 0xAAC8ECFF);
        }
        ball(g, cx - 12 + (ticks / 9) % 24, b + 2 + (ticks / 20) % 2, 1, 0x55FFFFFF);
    }

    private static void topiary(GuiGraphics g, int cx, int b, boolean heart) {
        rect(g, cx - 5, b - 4, 11, 4, 0xFFC87A5A); rect(g, cx - 5, b - 4, 11, 1, 0xFFE8A07A); rect(g, cx - 4, b - 1, 9, 1, 0xFF9A5A3C);
        int leaf = 0xFF2E8B4A, leafL = 0xFF4AB868;
        if (heart) {
            ball(g, cx - 3, b - 9, 3, leaf); ball(g, cx + 3, b - 9, 3, leaf);
            for (int r = 0; r < 5; r++) rect(g, cx - 6 + r, b - 8 + r, 13 - r * 2, 1, leaf);
            ball(g, cx - 3, b - 10, 1, leafL); rect(g, cx - 4, b - 11, 2, 1, leafL);
            rect(g, cx + 4, b - 8, 1, 1, 0xFFFF8FB8); rect(g, cx - 5, b - 9, 1, 1, 0xFFFFE066);
        } else {                                                                                // a bone
            rect(g, cx - 4, b - 10, 9, 4, leaf); rect(g, cx - 4, b - 10, 9, 1, leafL);
            ball(g, cx - 5, b - 11, 2, leaf); ball(g, cx - 5, b - 6, 2, leaf); ball(g, cx + 5, b - 11, 2, leaf); ball(g, cx + 5, b - 6, 2, leaf);
            rect(g, cx - 6, b - 12, 1, 1, leafL); rect(g, cx + 4, b - 12, 1, 1, leafL);
            rect(g, cx - 1, b - 9, 1, 1, 0xFFFF8FB8); rect(g, cx + 2, b - 8, 1, 1, 0xFFFFE066);
        }
    }

    /** Three paws of the pets that walked from the doors of the shops to the square. */
    private static void paws(GuiGraphics g) {
        for (int i = 0; i < 6; i++) {
            paw(g, 76 + i * 5, 258 + (i % 2) * 3 + i * 2, 0x34A06880);
            paw(g, 224 - i * 5, 258 + (i % 2) * 3 + i * 2, 0x34A06880);
        }
    }

    /** The lawn of the pet agility course in the bottom-left corner: a fence, hoops, a tunnel, a see-saw, cones and a runner. */
    private static void lawn(GuiGraphics g, int ticks) {
        int x0 = 4, y0 = 280, w = 96, h = 22;
        g.fillGradient(x0, y0, x0 + w, y0 + h, 0xFFB8E890, 0xFF8CD07A);
        rect(g, x0, y0, w, 1, 0xFFD8F4B8); rect(g, x0, y0 + h - 1, w, 1, 0xFF6FBF6A);
        for (int i = 0; i < 40; i++) {
            int px = x0 + 2 + (i * 29 + 5) % (w - 4), py = y0 + 3 + (i * 17 + 3) % (h - 6);
            rect(g, px, py, 1, 2, 0xFF7CC46A); if (i % 6 == 0) { rect(g, px + 2, py, 1, 1, 0xFFFFFFFF); rect(g, px + 2, py - 1, 1, 1, 0xFFFFE066); }
        }
        for (int x = x0; x < x0 + w; x += 4) { rect(g, x, y0 - 4, 2, 5, 0xFFFFFFFF); rect(g, x, y0 - 4, 2, 1, 0xFFE8E0F0); }   // the fence
        rect(g, x0, y0 - 3, w, 1, 0xFFE8E0F0); rect(g, x0, y0 - 1, w, 1, 0xFFE8E0F0);
        // two hoops
        int[] hc = {0xFFE5484D, 0xFF4D96FF};
        for (int i = 0; i < 2; i++) {
            int hx = 17 + i * 15;
            rect(g, hx - 4, y0 + 7, 1, 8, 0xFFFFFFFF); rect(g, hx + 4, y0 + 7, 1, 8, 0xFFFFFFFF);
            ring(g, hx, y0 + 12, 4, 5, hc[i], false); ring(g, hx, y0 + 12, 3, 4, hc[i], false);
            rect(g, hx - 5, y0 + 15, 11, 1, 0x30000000);
        }
        // the tunnel
        int tx = 48;
        rect(g, tx, y0 + 9, 22, 8, 0xFFFF9A3C);
        for (int i = 0; i < 22; i += 4) rect(g, tx + i, y0 + 9, 2, 8, 0xFFFFFFFF);
        rect(g, tx, y0 + 9, 22, 1, 0x55FFFFFF); rect(g, tx, y0 + 16, 22, 1, 0x33000000);
        oval(g, tx + 1, y0 + 13, 3, 4, 0xFF3A2A3A); oval(g, tx + 21, y0 + 13, 2, 4, 0xFFE07A20);
        rect(g, tx - 1, y0 + 17, 24, 1, 0x30000000);
        // the see-saw
        int sx = 82, tilt = (int) Math.round(Math.sin(ticks / 30.0) * 2);
        tri(g, sx, y0 + 12, 6, 6, 0xFF8A5A3A);
        ln(g, sx - 9, y0 + 14 - tilt, sx + 9, y0 + 14 + tilt, 0xFFC8955C); ln(g, sx - 9, y0 + 15 - tilt, sx + 9, y0 + 15 + tilt, 0xFF9A6A3C);
        ball(g, sx - 9, y0 + 12 - tilt, 1, 0xFFFF8FB8);
        // cones and a little flag
        for (int i = 0; i < 4; i++) { int cx = 12 + i * 21; tri(g, cx, y0 + 17, 4, 4, i % 2 == 0 ? 0xFFFF7A2A : 0xFFFFFFFF); rect(g, cx - 2, y0 + 21, 5, 1, 0xFFFF7A2A); }
        rect(g, 94, y0 + 4, 1, 12, 0xFF8A6A5A); rect(g, 95, y0 + 4, 4 + (ticks / 10) % 2, 3, 0xFFE5484D);
        // the runner: a dog that trots along the course and back
        int ph = (ticks / 2) % 160, rx = ph < 80 ? 8 + ph : 8 + (159 - ph);
        dog(g, x0 + rx - 4, y0 + 20, ph < 80 ? 1 : -1, ticks, 0xFFD9A25E);
    }

    private static void busStop(GuiGraphics g, int cx, int b, int ticks) {
        MapArt.shadow(g, cx, b, 14);
        rect(g, cx - 12, b - 18, 25, 3, 0xFF5A6AA8); rect(g, cx - 12, b - 18, 25, 1, 0xFF8A9AD8); rect(g, cx - 13, b - 15, 27, 1, 0xFF3A4A88);   // the roof
        rect(g, cx - 11, b - 15, 1, 15, 0xFF6A6880); rect(g, cx + 12, b - 15, 1, 15, 0xFF6A6880);
        rect(g, cx - 10, b - 15, 22, 11, 0x66BFE6FF); rect(g, cx - 9, b - 14, 3, 1, 0x88FFFFFF); rect(g, cx - 8, b - 13, 1, 2, 0x88FFFFFF);   // the glass
        rect(g, cx - 9, b - 6, 14, 1, 0xFFC8955C); rect(g, cx - 9, b - 5, 14, 1, 0xFF9A6A3C); rect(g, cx - 8, b - 4, 1, 4, 0xFF6E4726); rect(g, cx + 3, b - 4, 1, 4, 0xFF6E4726);   // the bench
        rect(g, cx + 8, b - 24, 1, 24, 0xFF6A6880); rect(g, cx + 5, b - 28, 8, 5, 0xFFFFC832); rect(g, cx + 5, b - 28, 8, 1, 0xFFFFE680);   // the sign
        rect(g, cx + 7, b - 26, 4, 1, 0xFF3A2A3A); rect(g, cx + 6, b - 25, 6, 2, 0xFF3A2A3A); rect(g, cx + 7, b - 24, 1, 1, 0xFFFFC832); rect(g, cx + 10, b - 24, 1, 1, 0xFFFFC832);
        rect(g, cx - 6, b - 12, 7, 5, 0xFFFFFFFF); rect(g, cx - 5, b - 11, 5, 3, 0xFFFF8FB8); rect(g, cx - 4, b - 10, 1, 1, 0xFFFFFFFF); rect(g, cx - 2, b - 10, 1, 1, 0xFFFFFFFF);   // a poster
        if ((ticks / 50) % 4 == 0) rect(g, cx - 4, b - 13, 1, 1, 0xFFFFFFFF);
    }

    private static void flowerCart(GuiGraphics g, int cx, int b, int ticks) {
        MapArt.shadow(g, cx, b, 11);
        rect(g, cx - 9, b - 8, 18, 6, 0xFF8A5A3A); rect(g, cx - 9, b - 8, 18, 1, 0xFFC8955C); rect(g, cx - 9, b - 3, 18, 1, 0xFF6E4726);
        for (int i = 0; i < 4; i++) rect(g, cx - 7 + i * 4, b - 7, 1, 4, 0xFF9A6A3C);
        ball(g, cx - 6, b - 2, 2, 0xFF3A2A3A); ball(g, cx + 6, b - 2, 2, 0xFF3A2A3A); ball(g, cx - 6, b - 2, 1, 0xFFC8C8D8); ball(g, cx + 6, b - 2, 1, 0xFFC8C8D8);
        int[] fc = {0xFFFF8FB8, 0xFFFFE066, 0xFFFFFFFF, 0xFFB57BD6, 0xFFFF6B6B};
        for (int i = 0; i < 9; i++) {
            int fx = cx - 8 + i * 2, fy = b - 13 - (i * 5) % 3;
            rect(g, fx, fy + 3, 1, 5, 0xFF3FA55A); ball(g, fx, fy + 1, 1, fc[i % fc.length]); rect(g, fx, fy + 1, 1, 1, 0xFFFFF0A0);
        }
        rect(g, cx + 9, b - 20, 1, 20, 0xFF6E4726); tri(g, cx + 4, b - 26, 18, 6, (ticks / 60) % 2 == 0 ? 0xFFFF8FB8 : 0xFFFFB8D0);     // a little umbrella
        rect(g, cx - 5, b - 20, 10, 1, 0x55FFFFFF);
    }

    private static void hedge(GuiGraphics g, int x, int y, int w, int ticks) {
        rect(g, x, y + 3, w, 6, 0xFF2E8B4A);
        for (int i = 0; i < w; i += 6) { ball(g, x + i + 3, y + 3, 3, i % 12 == 0 ? 0xFF3FA55A : 0xFF4AB868); }
        rect(g, x, y + 6, w, 3, 0xFF2E8B4A); rect(g, x, y + 8, w, 1, 0xFF1F6B38);
        for (int i = 2; i < w; i += 9) { int c = i % 3 == 0 ? 0xFFFF8FB8 : i % 3 == 1 ? 0xFFFFE066 : 0xFFFFFFFF; rect(g, x + i, y + 1 + (i / 9) % 3, 2, 2, c); }
    }

    private static void traffic(GuiGraphics g, int ticks) {
        int[] cc = {0xFFFF9A3C, 0xFF6BCB77, 0xFFB57BD6, 0xFF4D96FF};
        for (int i = 0; i < 3; i++) {
            int dir = i % 2 == 0 ? 1 : -1, y = dir > 0 ? STREET_Y + 4 : STREET_Y + 1;
            int x = Math.floorMod((int) (ticks * 0.6 * dir) + i * 97 + 20, W + 40) - 20;
            MapArt.car(g, x, y, dir, cc[i], i == 2);
        }
    }

    private static void people(GuiGraphics g, int ticks) {
        int[] shirt = {0xFFE5484D, 0xFF4D96FF, 0xFFFFC832, 0xFFB57BD6, 0xFF6BCB77};
        for (int i = 0; i < 3; i++) {                                                           // along the shop fronts
            int dir = i % 2 == 0 ? 1 : -1;
            int x = Math.floorMod((int) (ticks * 0.15 * dir) + i * 97 + 30, W);
            person(g, x, 187 + (i % 2) * 2, shirt[i], 0xFF5A3A2A, (ticks / 8 + i) % 2);
        }
        // a girl with a dog on a lead walks along the bottom path
        int wx = Math.floorMod((int) (ticks * 0.2), W + 80) - 40;
        person(g, wx, 289, 0xFFFF8FB8, 0xFFFFC832, (ticks / 8) % 2);
        ln(g, wx + 2, 285, wx + 9, 288, 0xFFC8C8D8);
        dog(g, wx + 9, 290, 1, ticks, 0xFFB57B4A);
    }

    /** A string of little flags between two points (it sags in the middle). */
    private static void bunting(GuiGraphics g, int x0, int y0, int x1, int y1, int sag, int ticks) {
        int[] fc = {0xFFFF8FB8, 0xFFFFE066, 0xFF8FD3FF, 0xFFB8F0A8, 0xFFFFA860};
        int n = x1 - x0;
        for (int i = 0; i <= n; i++) {
            double t = i / (double) n;
            int y = (int) Math.round(y0 + (y1 - y0) * t + Math.sin(Math.PI * t) * sag);
            rect(g, x0 + i, y, 1, 1, 0xFF8A7A9A);
            if (i % 8 == 4) {
                int sw = (int) Math.round(Math.sin(ticks / 14.0 + i * 0.5));
                tri(g, x0 + i, y + 1, 5, 5, fc[(i / 8) % fc.length]);
                rect(g, x0 + i - 2, y + 1, 5, 1, mix(fc[(i / 8) % fc.length], 0xFFFFFFFF, 0.4F));
                if (sw > 0) rect(g, x0 + i, y + 6, 1, 1, fc[(i / 8) % fc.length]);
            }
        }
        rect(g, x0 - 1, y0 - 1, 2, 3, 0xFF6A6880); rect(g, x1, y1 - 1, 2, 3, 0xFF6A6880);
    }

    private static void lightStrings(GuiGraphics g, int ticks) {
        for (int i = 0; i < 30; i++) {
            int x = 98 + i * 4, y = 206 + (int) Math.round(Math.sin(Math.PI * i / 29.0) * 9);
            rect(g, x, y + 4, 2, 2, (ticks / 12 + i) % 3 == 0 ? 0xFFFFF0A0 : 0xFFFFC85A);
            rect(g, x - 1, y + 3, 4, 4, 0x18FFE090);
        }
    }

    // =====================================================================================================
    //  THE BOUTIQUE (outfits): pink walls, a lilac mansard roof with a heart, a striped awning, two display windows
    // =====================================================================================================
    static void boutique(GuiGraphics g, int cx, int b, int ticks, boolean night) {
        int lilac = 0xFFB48AD6, lilacD = 0xFF8A62B0, pink = 0xFFFFE9F1, white = 0xFFFFFFFF;
        // ---- the clothes rail and the mannequin on the pavement (left of the shop)
        rail(g, cx - 38, b, ticks);
        // ---- the roof: a lilac mansard with scales
        for (int r = 0; r < 13; r++) {
            int w = 38 + 22 * r / 12, y = b - 53 + r;
            rect(g, cx - w / 2, y, w, 1, r < 2 ? light(lilac, 0.35F) : r > 10 ? lilacD : lilac);
            if (r % 3 == 2 && r < 11) rect(g, cx - w / 2 + 1, y, w - 2, 1, dark(lilac, 0.16F));
            for (int x = -w / 2 + (r / 3 % 2) * 3; x < w / 2; x += 6) if (r % 3 != 2 && r > 1 && r < 11) rect(g, cx + x, y, 1, 1, dark(lilac, 0.14F));
        }
        rect(g, cx - 21, b - 54, 42, 2, light(lilac, 0.55F)); rect(g, cx - 21, b - 54, 42, 1, 0xFFFFFFFF);             // the ridge
        heart(g, cx - 2, b - 60 - (ticks / 25) % 2, 0xFFFF6B9A); rect(g, cx, b - 55, 1, 2, 0xFF8A7A9A);                // the finial
        rect(g, cx - 19, b - 61, 5, 8, 0xFFC87A6A); rect(g, cx - 19, b - 61, 5, 1, 0xFFE8A07A); rect(g, cx - 20, b - 62, 7, 1, 0xFF8A4A3A);   // the chimney
        for (int k = 0; k < 3; k++) ball(g, cx - 17 + (ticks / 14 + k) % 3 - 1, b - 65 - (ticks / 6 + k * 5) % 10, 1, 0x88FFFFFF);
        // the dormer window with a heart
        rect(g, cx - 7, b - 48, 14, 9, pink); rect(g, cx - 7, b - 48, 14, 1, white);
        tri(g, cx, b - 54, 18, 7, lilacD); tri(g, cx - 1, b - 54, 8, 7, lilac);
        ball(g, cx, b - 44, 4, white); ball(g, cx, b - 44, 3, night ? 0xFFFFE680 : 0xFFA8DEFF); heart(g, cx - 2, b - 46, 0xFFFF6B9A);
        rect(g, cx - 8, b - 40, 16, 1, 0x33000000);
        cat(g, cx + 14, b - 47, ticks, 0xFFE8A04A);
        // ---- the walls
        rect(g, cx - 27, b - 40, 54, 40, pink); rect(g, cx + 22, b - 40, 5, 40, 0xFFF2D0DE);
        for (int x = -20; x < 22; x += 13) rect(g, cx + x, b - 34, 1, 29, 0x14C080A0);
        rect(g, cx - 29, b - 41, 58, 3, white); rect(g, cx - 29, b - 38, 58, 1, 0x30A06080);                         // the cornice
        rect(g, cx - 29, b - 38, 3, 38, white); rect(g, cx + 26, b - 38, 3, 38, 0xFFF4E0EA);                        // the pilasters
        rect(g, cx - 27, b - 4, 54, 4, 0xFFD6BCE6); rect(g, cx - 27, b - 4, 54, 1, 0xFFEAD8F4);                      // the plinth
        // ---- the sign board on two chains: a hat, a hanger and a bow
        rect(g, cx - 14, b - 37, 1, 3, 0xFF8A7A9A); rect(g, cx + 14, b - 37, 1, 3, 0xFF8A7A9A);
        rect(g, cx - 18, b - 34, 37, 9, 0x33000000); rect(g, cx - 19, b - 35, 37, 9, white);
        rect(g, cx - 19, b - 35, 37, 1, lilacD); rect(g, cx - 19, b - 27, 37, 1, lilacD); rect(g, cx - 19, b - 35, 1, 9, lilacD); rect(g, cx + 17, b - 35, 1, 9, lilacD);
        rect(g, cx - 18, b - 34, 35, 1, 0xFFF4E8FA);
        // the hat
        rect(g, cx - 15, b - 29, 8, 1, 0xFFE5484D); rect(g, cx - 13, b - 32, 4, 3, 0xFFE5484D); rect(g, cx - 13, b - 30, 4, 1, 0xFFFFD84D);
        // the hanger
        rect(g, cx, b - 33, 1, 1, lilacD); ln(g, cx, b - 32, cx - 4, b - 29, lilacD); ln(g, cx, b - 32, cx + 4, b - 29, lilacD); rect(g, cx - 4, b - 29, 9, 1, lilacD);
        // the bow
        rect(g, cx + 8, b - 32, 3, 3, 0xFFFF6B9A); rect(g, cx + 12, b - 32, 3, 3, 0xFFFF6B9A); rect(g, cx + 11, b - 31, 1, 1, 0xFFFFD84D); rect(g, cx + 9, b - 31, 1, 1, 0xFFFFB8D0);
        if ((ticks / 30) % 3 == 0) { rect(g, cx - 17, b - 33, 1, 1, 0xFFFFD84D); rect(g, cx + 16, b - 28, 1, 1, 0xFFFFD84D); }
        // ---- the striped awning with scallops (they stir a little in the wind)
        for (int x = -30; x < 30; x += 4) {
            int c = ((x + 30) / 4) % 2 == 0 ? lilac : white;
            rect(g, cx + x, b - 25, 4, 5, c);
            rect(g, cx + x, b - 25, 4, 1, light(c, 0.4F));
            int wv = (ticks / 22 + (x + 30) / 4) % 7 == 0 ? 1 : 0;
            rect(g, cx + x, b - 20, 4, 1, dark(c, 0.15F));
            rect(g, cx + x + 1, b - 19, 2, 1 + wv, c); rect(g, cx + x + 1, b - 19 + wv, 2, 1, dark(c, 0.2F));
            if (night && (x / 4 + ticks / 20) % 3 != 0) rect(g, cx + x + 1, b - 17, 2, 2, 0xFFFFF0A0);
        }
        rect(g, cx - 30, b - 26, 60, 1, light(lilac, 0.5F));
        // ---- the display windows
        window(g, cx - 25, b - 18, night);
        window(g, cx + 10, b - 18, night);
        // the left window: a mannequin with a hat and a scarf, a stack of folded things
        int mx = cx - 17;
        rect(g, mx, b - 8, 1, 3, 0xFF8A7A9A); rect(g, mx - 2, b - 6, 5, 1, 0xFF8A7A9A);
        rect(g, mx - 2, b - 12, 5, 5, 0xFFB57BD6); rect(g, mx - 2, b - 12, 5, 1, 0xFFD8B0F0); rect(g, mx - 3, b - 11, 1, 2, 0xFFB57BD6); rect(g, mx + 3, b - 11, 1, 2, 0xFFB57BD6);
        rect(g, mx - 2, b - 12, 5, 1, 0xFFFF6B9A);                                                                   // the scarf
        ball(g, mx, b - 14, 2, 0xFFF4D8C0); rect(g, mx - 2, b - 17, 5, 2, 0xFFE5484D); rect(g, mx - 1, b - 18, 3, 1, 0xFFE5484D);   // a head with a red beret
        rect(g, cx - 12, b - 11, 3, 1, 0xFFFFD84D); rect(g, cx - 12, b - 10, 3, 1, 0xFF6A8CE8); rect(g, cx - 12, b - 9, 3, 1, 0xFFFF8FB8);
        // the right window: a rail with garments and a hat on a stand
        int rx = cx + 17;
        rect(g, rx - 5, b - 18, 11, 1, 0xFF8A7A9A);
        garment(g, rx - 3, b - 17, 0xFFFF8FB8); garment(g, rx + 3, b - 17, 0xFF6A8CE8);
        rect(g, rx - 4, b - 9, 9, 1, 0xFF8A5A3A); rect(g, rx - 2, b - 12, 5, 3, 0xFF3A2A3A); rect(g, rx - 4, b - 10, 9, 1, 0xFF3A2A3A); rect(g, rx - 2, b - 11, 5, 1, 0xFFFFD84D);   // a top hat
        flowerBox(g, cx - 25, b - 8, 15, 0xFFFF6B9A, 0xFFFFE066);
        flowerBox(g, cx + 10, b - 8, 15, 0xFFB57BD6, 0xFFFFFFFF);
        // ---- the door
        rect(g, cx - 6, b - 21, 13, 21, white);
        rect(g, cx - 5, b - 20, 11, 20, 0xFF9A68C8); rect(g, cx - 5, b - 20, 1, 1, white); rect(g, cx + 5, b - 20, 1, 1, white);
        rect(g, cx - 4, b - 19, 9, 8, night ? 0xFFFFE680 : 0xFFA8DEFF); rect(g, cx, b - 19, 1, 8, white); rect(g, cx - 4, b - 15, 9, 1, white);
        rect(g, cx - 4, b - 10, 9, 8, 0xFFB080D8); rect(g, cx - 4, b - 10, 9, 1, 0xFFD0A8F0); rect(g, cx + 3, b - 10, 1, 1, 0xFFFFD84D);
        rect(g, cx + 3, b - 12, 1, 2, 0xFFFFD84D);                                                                   // the handle
        int sw = (int) Math.round(Math.sin(ticks / 16.0));
        rect(g, cx - 3 + sw / 2, b - 14, 1, 2, 0xFF8A7A9A); heart(g, cx - 5 + sw / 2, b - 12, 0xFFFF6B9A);          // the sign "open" swings on the door
        rect(g, cx - 7, b - 3, 15, 2, 0xFFE4D6EE); rect(g, cx - 8, b - 1, 17, 2, 0xFFC8B8DA); rect(g, cx - 4, b - 3, 9, 1, 0xFFFF8FB8);   // the steps, the mat
        // lanterns beside the door
        for (int s = -1; s <= 1; s += 2) {
            int lx = cx + s * 9;
            rect(g, lx, b - 22, 1, 2, 0xFF8A7A9A); rect(g, lx - 1, b - 20, 3, 3, night ? 0xFFFFE680 : 0xFFFFD866); rect(g, lx, b - 20, 1, 1, 0xFFFFFFFF);
            if (night) ball(g, lx, b - 19, 5, 0x24FFE090);
        }
    }

    /** A display window: a white frame, a cream room inside (a warm light at night), a shine on the glass. */
    private static void window(GuiGraphics g, int x, int y, boolean night) {
        rect(g, x, y, 15, 15, 0xFFFFFFFF);
        rect(g, x + 1, y + 1, 13, 13, night ? 0xFFFFE8A0 : 0xFFFFF8EE);
        rect(g, x + 1, y + 10, 13, 4, night ? 0xFFF0C878 : 0xFFF0DCE4);                                           // the floor of the window
        rect(g, x + 1, y + 10, 13, 1, 0x22000000);
        for (int i = 0; i < 4; i++) ln(g, x + 2 + i * 2, y + 6, x + 8 + i * 2, y + 1, 0x33FFFFFF);               // the shine
        rect(g, x, y + 14, 15, 1, 0x33000000);
    }

    /** A rail of outfits and a mannequin in a sun hat, on the pavement. */
    private static void rail(GuiGraphics g, int cx, int b, int ticks) {
        MapArt.shadow(g, cx, b, 10);
        rect(g, cx - 8, b - 15, 1, 15, 0xFF8A7A9A); rect(g, cx + 8, b - 15, 1, 15, 0xFF8A7A9A); rect(g, cx - 9, b - 1, 3, 1, 0xFF6A6880); rect(g, cx + 7, b - 1, 3, 1, 0xFF6A6880);
        rect(g, cx - 8, b - 15, 17, 1, 0xFFC8C4D8);
        int[] gc = {0xFFFF8FB8, 0xFF8FD3FF, 0xFFFFE066, 0xFFB8F0A8};
        for (int i = 0; i < 4; i++) {
            int sw = (int) Math.round(Math.sin(ticks / 18.0 + i) * 0.8);
            garment(g, cx - 6 + i * 4 + sw, b - 14, gc[i]);
        }
        rect(g, cx - 3, b - 4, 7, 3, 0xFFFFFFFF); rect(g, cx - 3, b - 4, 7, 1, 0xFFE8E0F0); rect(g, cx - 2, b - 3, 5, 1, 0xFFFF8FB8);   // a box of hats
        rect(g, cx - 2, b - 7, 5, 3, 0xFFE8C888); rect(g, cx - 4, b - 5, 9, 1, 0xFFE8C888);
    }

    // =====================================================================================================
    //  THE PANTRY (treats): a cream shop with a terracotta gable, a green awning, shelves in the window, a bunny at the counter
    // =====================================================================================================
    static void pantry(GuiGraphics g, int cx, int b, int ticks, boolean night) {
        int tile = 0xFFD8683E, tileD = 0xFFA84A2A, cream = 0xFFFFF0C8, mint = 0xFF9ADBB8, green = 0xFF4CAF6A, wood = 0xFF9A6A3C, white = 0xFFFFFFFF;
        crates(g, cx + 38, b, ticks);
        chalk(g, cx - 34, b, ticks);
        // ---- the gable roof with tiles
        for (int r = 0; r < 14; r++) {
            int w = 8 + 52 * r / 13, y = b - 54 + r;
            rect(g, cx - w / 2, y, w, 1, r == 0 ? light(tile, 0.4F) : tile);
            if (r % 3 == 2) rect(g, cx - w / 2 + 1, y, w - 2, 1, dark(tile, 0.2F));
            else for (int x = -w / 2 + 1 + (r / 3 % 2) * 2; x < w / 2 - 1; x += 5) rect(g, cx + x, y, 1, 1, dark(tile, 0.15F));
        }
        rect(g, cx - 31, b - 41, 62, 2, tileD); rect(g, cx - 31, b - 41, 62, 1, light(tileD, 0.2F));               // the eave
        tri(g, cx, b - 54, 4, 1, light(tile, 0.5F));
        // the weather vane: a fish that turns now and then
        rect(g, cx, b - 62, 1, 9, 0xFF6A6880); int dir = (ticks / 90) % 2 == 0 ? 1 : -1;
        fish(g, dir > 0 ? cx - 7 : cx - 1, b - 66, 0xFFFFC832, 0xFF3A2A3A);
        rect(g, cx - 1, b - 53, 3, 1, 0xFF6A6880);
        // the chimney with hearts of steam
        rect(g, cx + 18, b - 53, 6, 12, 0xFFB8644A); rect(g, cx + 18, b - 53, 6, 1, 0xFFE0907A); rect(g, cx + 17, b - 54, 8, 2, 0xFF8A4A3A);
        for (int k = 0; k < 3; k++) {
            int ph = (ticks / 5 + k * 7) % 21;
            if (ph < 18) heart(g, cx + 18 + (int) Math.round(Math.sin((ticks + k * 40) / 20.0) * 2), b - 60 - ph, k % 2 == 0 ? 0x99FFB8D0 : 0x88FFFFFF);
        }
        // the round window in the gable: a fish on a blue plate
        ball(g, cx, b - 47, 4, white); ball(g, cx, b - 47, 3, night ? 0xFFFFE680 : 0xFFBFE6FF); fish(g, cx - 3, b - 49, 0xFFFF9A3C, 0xFF3A2A3A);
        // ---- the walls: cream above, mint boards below
        rect(g, cx - 27, b - 40, 54, 40, cream); rect(g, cx + 22, b - 40, 5, 40, 0xFFF0DCA8);
        rect(g, cx - 27, b - 14, 54, 14, mint); rect(g, cx - 27, b - 14, 54, 1, white); rect(g, cx + 22, b - 14, 5, 14, mix(mint, 0xFF000000, 0.12F));
        for (int x = -26; x < 27; x += 5) rect(g, cx + x, b - 13, 1, 13, 0x22FFFFFF);
        rect(g, cx - 29, b - 41, 58, 2, white); rect(g, cx - 29, b - 39, 58, 1, 0x30A08040);
        for (int i = 0; i < 8; i++) { rect(g, cx - 29, b - 38 + i * 5, 3, 3, 0xFFE88A4A); rect(g, cx + 26, b - 38 + i * 5, 3, 3, 0xFFD87A3A); }   // the corner bricks
        rect(g, cx - 27, b - 3, 54, 3, 0xFFB87A4A); rect(g, cx - 27, b - 3, 54, 1, 0xFFD8A070);
        // ---- the sign board: a cookie, a bone and a fish on a wooden board
        rect(g, cx - 18, b - 38, 37, 9, 0x33000000); rect(g, cx - 19, b - 39, 37, 9, wood);
        rect(g, cx - 19, b - 39, 37, 1, light(wood, 0.35F)); rect(g, cx - 18, b - 38, 35, 7, cream);
        cookie(g, cx - 12, b - 35, 3); bone(g, cx - 4, b - 36, 0xFFB87A4A); fish(g, cx + 8, b - 37, 0xFFFF9A3C, 0xFF3A2A3A);
        if ((ticks / 30) % 3 == 1) { rect(g, cx - 16, b - 37, 1, 1, white); rect(g, cx + 15, b - 33, 1, 1, white); }
        // ---- the awning: green and white, scalloped
        for (int x = -30; x < 30; x += 4) {
            int c = ((x + 30) / 4) % 2 == 0 ? green : white;
            rect(g, cx + x, b - 29, 4, 5, c); rect(g, cx + x, b - 29, 4, 1, light(c, 0.4F));
            int wv = (ticks / 22 + (x + 30) / 4) % 7 == 0 ? 1 : 0;
            rect(g, cx + x, b - 24, 4, 1, dark(c, 0.15F));
            rect(g, cx + x + 1, b - 23, 2, 1 + wv, c); rect(g, cx + x + 1, b - 23 + wv, 2, 1, dark(c, 0.2F));
            if (night && (x / 4 + ticks / 20) % 3 != 0) rect(g, cx + x + 1, b - 21, 2, 2, 0xFFFFF0A0);
        }
        // fish dried on a string under the awning
        for (int i = 0; i < 3; i++) {
            int sx = cx + 12 + i * 5 + (int) Math.round(Math.sin(ticks / 20.0 + i) * 0.7);
            rect(g, sx, b - 22, 1, 2, 0xFF8A7A9A); rect(g, sx - 1, b - 20, 3, 3, 0xFF9AB8D8); rect(g, sx, b - 17, 1, 1, 0xFF7A98B8);
        }
        // ---- the windows
        pantryWindow(g, cx - 25, b - 21, night);
        pantryWindow(g, cx + 10, b - 21, night);
        // the left window: shelves with jars, cans and a fish
        int lx = cx - 24;
        rect(g, lx, b - 15, 13, 1, wood); rect(g, lx, b - 9, 13, 1, wood);
        rect(g, lx + 1, b - 19, 3, 4, 0xFFE5484D); rect(g, lx + 1, b - 20, 3, 1, white); rect(g, lx + 5, b - 18, 3, 3, 0xFFFFC832); rect(g, lx + 5, b - 19, 3, 1, white);
        rect(g, lx + 9, b - 19, 3, 4, 0xFF4D96FF); rect(g, lx + 9, b - 20, 3, 1, white);
        rect(g, lx + 1, b - 13, 4, 4, 0xFFC8C8D8); rect(g, lx + 1, b - 13, 4, 1, white); rect(g, lx + 2, b - 12, 2, 2, 0xFFFF8FB8);
        fish(g, lx + 6, b - 13, 0xFFFF9A3C, 0xFF3A2A3A);
        // the right window: the counter with a cake under a dome, and a bunny who sells it
        int rx = cx + 11;
        rect(g, rx, b - 9, 13, 2, wood); rect(g, rx, b - 9, 13, 1, light(wood, 0.3F)); rect(g, rx, b - 7, 13, 1, 0xFFC8955C);
        bunny(g, rx + 1, b - 9, ticks);
        rect(g, rx + 8, b - 13, 5, 4, 0xFFFFD6E8); rect(g, rx + 8, b - 13, 5, 1, white); rect(g, rx + 9, b - 15, 3, 2, 0xFFE0508A);
        rect(g, rx + 7, b - 16, 7, 7, 0x40BFE6FF); rect(g, rx + 8, b - 16, 5, 1, 0x88FFFFFF); rect(g, rx + 7, b - 16, 1, 7, 0x66FFFFFF);
        // ---- the door with a bell and a chalk board
        rect(g, cx - 6, b - 22, 13, 22, white);
        rect(g, cx - 5, b - 21, 11, 21, wood); rect(g, cx - 5, b - 21, 11, 1, light(wood, 0.35F));
        rect(g, cx - 4, b - 20, 9, 8, night ? 0xFFFFE680 : 0xFFBFE6FF); rect(g, cx, b - 20, 1, 8, white);
        rect(g, cx - 4, b - 11, 9, 8, 0xFFB0824C); rect(g, cx - 4, b - 11, 9, 1, 0xFFD8A870);
        rect(g, cx + 3, b - 13, 1, 2, 0xFFFFD84D);
        int bs = (int) Math.round(Math.sin(ticks / 9.0) * ((ticks / 120) % 3 == 0 ? 1 : 0));
        rect(g, cx - 1 + bs, b - 24, 3, 1, 0xFFFFC832); rect(g, cx + bs, b - 23, 1, 1, 0xFF8A5A2A);              // the bell
        rect(g, cx - 7, b - 3, 15, 2, 0xFFE8D8B8); rect(g, cx - 8, b - 1, 17, 2, 0xFFC8B088); rect(g, cx - 4, b - 3, 9, 1, 0xFF4CAF6A);
        // lanterns
        for (int s = -1; s <= 1; s += 2) {
            int lx2 = cx + s * 9;
            rect(g, lx2, b - 25, 1, 2, 0xFF8A7A9A); rect(g, lx2 - 1, b - 23, 3, 3, night ? 0xFFFFE680 : 0xFFFFD866);
            if (night) ball(g, lx2, b - 22, 5, 0x24FFE090);
        }
    }

    private static void pantryWindow(GuiGraphics g, int x, int y, boolean night) {
        rect(g, x, y, 15, 16, 0xFFFFFFFF);
        rect(g, x + 1, y + 1, 13, 14, night ? 0xFFFFE8A0 : 0xFFFFF4DA);
        for (int i = 0; i < 4; i++) ln(g, x + 2 + i * 2, y + 6, x + 8 + i * 2, y + 1, 0x33FFFFFF);
        rect(g, x, y + 15, 15, 1, 0x33000000);
    }

    /** A bunny shopkeeper behind the counter: caramel fur, long ears that twitch, a blink, a pink nose, a green apron. */
    private static void bunny(GuiGraphics g, int x, int y, int ticks) {
        int fur = 0xFFD9A872, furL = 0xFFEBC698;
        int tw = (ticks / 40) % 5 == 0 ? 1 : 0;
        rect(g, x, y - 9 - tw, 2, 5 + tw, fur); rect(g, x + 3, y - 9, 2, 5, fur); rect(g, x + 1, y - 8 - tw, 1, 3, 0xFFFFB8D0); rect(g, x + 4, y - 8, 1, 3, 0xFFFFB8D0);
        rect(g, x - 1, y - 5, 7, 5, fur); rect(g, x - 1, y - 5, 7, 1, furL); rect(g, x + 1, y - 2, 3, 2, 0xFFFFF4E0);
        boolean blink = (ticks / 80) % 5 == 0;
        rect(g, x, y - 4, 1, blink ? 1 : 2, 0xFF3A2A3A); rect(g, x + 4, y - 4, 1, blink ? 1 : 2, 0xFF3A2A3A);
        rect(g, x + 2, y - 3, 1, 1, 0xFFFF6B9A);
        rect(g, x - 1, y - 1, 7, 1, 0xFF4CAF6A);                                                                       // an apron
    }

    /** An A-frame board on the pavement: a chalk menu with a bone, a heart and a fish. */
    private static void chalk(GuiGraphics g, int cx, int b, int ticks) {
        MapArt.shadow(g, cx, b, 6);
        rect(g, cx - 5, b - 13, 1, 13, 0xFF8A5A3A); rect(g, cx + 4, b - 13, 1, 13, 0xFF8A5A3A);
        rect(g, cx - 4, b - 12, 8, 10, 0xFF2A3A3A); rect(g, cx - 4, b - 12, 8, 1, 0xFF3A4A4A); rect(g, cx - 5, b - 13, 10, 1, 0xFFC8955C); rect(g, cx - 5, b - 2, 10, 1, 0xFFC8955C);
        bone(g, cx - 3, b - 11, 0xFFFFFFFF); heart(g, cx - 2, b - 8, 0xFFFFB8D0);
        rect(g, cx - 3, b - 4, 6, 1, 0x99FFFFFF); if ((ticks / 50) % 2 == 0) rect(g, cx - 3, b - 3, 3, 1, 0x66FFFFFF);
    }

    /** A flower bed with a stone border (x, y = the top left corner). */
    private static void bed(GuiGraphics g, int x, int y, int w, int h, int seed) {
        rect(g, x, y, w, h, 0xFFB8A8C0); rect(g, x + 1, y + 1, w - 2, h - 2, 0xFF7A4A2A);
        rect(g, x, y, w, 1, 0xFFE0D4E8);
        int[] fc = {0xFFFF8FB8, 0xFFFFE066, 0xFFFFFFFF, 0xFFB57BD6, 0xFFFF6B6B};
        for (int i = 0; i < w * h / 6; i++) {
            int fx = x + 2 + (i * 7 + seed) % (w - 4), fy = y + 2 + (i * 3 + seed) % (h - 4);
            rect(g, fx, fy + 1, 1, 1, 0xFF3FA55A); rect(g, fx, fy, 1, 1, fc[(i + seed) % fc.length]);
        }
    }

    /** Things at the two edges of the boulevard: trees, flower beds and a stone bowl of water for the pets. */
    private static void sides(GuiGraphics g, int ticks) {
        tree(g, 8, 270, 8, 0xFF3FA55A); tree(g, 292, 270, 8, 0xFF3FA55A);
        bed(g, 6, 200, 20, 9, 1); bed(g, 6, 214, 20, 9, 4);
        bed(g, 274, 200, 20, 9, 2); bed(g, 274, 214, 20, 9, 5);
        // a stone bowl for the pets with a paw on it, on a little column
        int bx = 30, by = 276;
        MapArt.shadow(g, bx, by, 6);
        rect(g, bx - 2, by - 8, 5, 8, 0xFFD2CBE0); rect(g, bx - 2, by - 8, 1, 8, 0xFFF4F0FA); rect(g, bx + 2, by - 8, 1, 8, 0xFFA79BBE);
        MapArt.oval(g, bx, by - 9, 6, 2, 0xFFD2CBE0); MapArt.oval(g, bx, by - 9, 5, 1, 0xFF72C6F0);
        rect(g, bx - 4 + (ticks / 15) % 8, by - 9, 1, 1, 0x88FFFFFF);
        paw(g, bx - 1, by - 5, 0xFF8A7AA8);
    }

    /** Crates of berries and apples, a barrel with fish and a sack of kibble, on the pavement (right of the shop). */
    private static void crates(GuiGraphics g, int cx, int b, int ticks) {
        MapArt.shadow(g, cx, b, 11);
        // a crate with berries
        rect(g, cx - 10, b - 7, 12, 7, 0xFFB07840); rect(g, cx - 10, b - 7, 12, 1, 0xFFD8A468); rect(g, cx - 10, b - 4, 12, 1, 0xFF8A5A2A);
        for (int i = 0; i < 5; i++) ball(g, cx - 8 + i * 2, b - 8, 1, i % 2 == 0 ? 0xFFE5484D : 0xFFC02844);
        // a crate with apples, on top
        rect(g, cx - 8, b - 13, 9, 6, 0xFFC8955C); rect(g, cx - 8, b - 13, 9, 1, 0xFFE8B880); rect(g, cx - 8, b - 10, 9, 1, 0xFF9A6A3C);
        for (int i = 0; i < 3; i++) { ball(g, cx - 6 + i * 3, b - 14, 1, i % 2 == 0 ? 0xFF6BCB77 : 0xFFE5484D); rect(g, cx - 6 + i * 3, b - 16, 1, 1, 0xFF3A7A3A); }
        // a barrel with a fish
        rect(g, cx + 4, b - 10, 8, 10, 0xFF8A5A3A); rect(g, cx + 4, b - 10, 8, 1, 0xFFC8955C); rect(g, cx + 4, b - 7, 8, 1, 0xFF6E4726); rect(g, cx + 4, b - 3, 8, 1, 0xFF6E4726);
        rect(g, cx + 5, b - 10, 1, 10, 0x22FFFFFF);
        fish(g, cx + 5, b - 13, 0xFF9AB8D8, 0xFF3A2A3A);
        // a sack of kibble with a paw
        rect(g, cx + 13, b - 9, 7, 9, 0xFFE8D8B8); rect(g, cx + 13, b - 9, 7, 1, 0xFFFFF0D0); rect(g, cx + 14, b - 11, 5, 2, 0xFFD8C8A0);
        paw(g, cx + 15, b - 6, 0xFFB87A4A);
        if ((ticks / 40) % 3 == 0) { rect(g, cx - 7, b - 17, 1, 1, 0xFFFFFFFF); }
    }
}
