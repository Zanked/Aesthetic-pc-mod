package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.MapArt.W;
import static dev.cutemod.client.os.MapArt.WORLD_H;
import static dev.cutemod.client.os.MapArt.ball;
import static dev.cutemod.client.os.MapArt.mix;
import static dev.cutemod.client.os.MapArt.oval;
import static dev.cutemod.client.os.MapArt.rect;
import static dev.cutemod.client.os.MapArt.tri;

/**
 * The last part of the pet map, under the shopping boulevard: a gate in the hedge, a tree-lined avenue and Downtown, where a
 * cluster of pastel towers with a clock tower stands: the City place (open it and the pet walks the long street of
 * {@link PetCity}). Only scenery and the icon of the place are here; the clicks are in {@link PetMap}.
 */
final class MapCity {
    private MapCity() {}

    /** Where the district starts: the row where the boulevard ends (see {@link MapBoulevard}). */
    static final int TOP = 312;
    private static final int AVE_X = 138, AVE_W = 24, BASE = 416, STREET_Y = 428;

    private static int dark(int c, float f) { return mix(c, 0xFF000000, f); }

    private static int light(int c, float f) { return mix(c, 0xFFFFFFFF, f); }

    // =====================================================================================================
    //  THE DISTRICT: paving, the gate, the avenue, towers at both sides, the street along the bottom
    // =====================================================================================================
    static void district(GuiGraphics g, int ticks, boolean night) {
        if (!MapArt.seen(TOP - 12, WORLD_H)) return;
        g.fillGradient(0, TOP, W, WORLD_H, 0xFFE9E3F2, 0xFFD2CBE6);
        for (int y = TOP + 4; y < WORLD_H; y += 6) if (MapArt.seen(y, y + 1)) rect(g, 0, y, W, 1, 0x12705090);
        for (int x = 0; x < W; x += 12) rect(g, x, TOP, 1, WORLD_H - TOP, 0x0C705090);

        // the gate in the hedge: two stone pillars with lanterns and a paved opening
        rect(g, 126, 304, 48, 9, 0xFFF1E6EE);
        for (int s = 0; s < 2; s++) {
            int px = s == 0 ? 123 : 171;
            rect(g, px, 294, 6, 19, 0xFFE4D8E8); rect(g, px, 294, 2, 19, 0xFFFFFFFF); rect(g, px + 4, 294, 2, 19, 0xFFC8B8D8);
            rect(g, px - 1, 292, 8, 3, 0xFFC8B8D8); rect(g, px - 1, 292, 8, 1, 0xFFFFFFFF);
            rect(g, px + 1, 287, 4, 5, 0xFFFFF0B8); rect(g, px + 1, 287, 1, 5, 0xFFFFFFFF); rect(g, px, 286, 6, 1, 0xFF8A7AA8); rect(g, px + 2, 284, 2, 2, 0xFF8A7AA8);
        }

        // the buildings at both sides of the avenue (pale towers with windows), then the avenue in front of them
        int[][] left = {{4, 46, 0xFFC9B8EA}, {32, 34, 0xFFA8D2E4}, {60, 50, 0xFFF0BFD0}, {92, 38, 0xFFB8C8F0}};
        int[][] right = {{172, 38, 0xFFFFD8B8}, {198, 48, 0xFFB5E0C8}, {226, 36, 0xFFD2BDF0}, {254, 44, 0xFFA8CCEE}};
        for (int[] t : left) tower(g, t[0], 28, t[1], t[2], night);
        for (int[] t : right) tower(g, t[0], 28, t[1], t[2], night);

        // the avenue: light paving with a pattern, hedges at the edges, lamps and a pair of trees
        rect(g, AVE_X, TOP, AVE_W, BASE - TOP + 8, 0xFFF6EAEE);
        for (int y = TOP + 3; y < BASE + 8; y += 6) if (MapArt.seen(y, y + 1)) rect(g, AVE_X, y, AVE_W, 1, 0x16B07090);
        for (int y = TOP; y < BASE + 8; y += 12) if (MapArt.seen(y, y + 1)) { rect(g, AVE_X + 11, y, 1, 6, 0x14B07090); rect(g, AVE_X + 5, y + 6, 1, 6, 0x14B07090); rect(g, AVE_X + 17, y + 6, 1, 6, 0x14B07090); }
        rect(g, AVE_X - 2, TOP, 2, BASE + 8 - TOP, 0xFFD8C8DC); rect(g, AVE_X + AVE_W, TOP, 2, BASE + 8 - TOP, 0xFFD8C8DC);
        for (int y = TOP + 6; y < BASE - 10; y += 3) if (MapArt.seen(y, y + 3)) { ball(g, AVE_X - 4, y, 2, 0xFF4AB868); ball(g, AVE_X + AVE_W + 4, y, 2, 0xFF4AB868); }
        for (int y = TOP + 22; y < BASE - 20; y += 28) {
            MapArt.lamp(g, AVE_X - 1, y, false); MapArt.lamp(g, AVE_X + AVE_W + 1, y, false);
            if (MapArt.seen(y - 12, y)) { rect(g, AVE_X + 3, y - 5, 1, 1, 0xFFFF9AC8); rect(g, AVE_X + AVE_W - 4, y - 3, 1, 1, 0xFFFFE066); }
        }
        round(g, 122, 372, 7); round(g, 178, 372, 7); round(g, 122, 398, 6); round(g, 178, 398, 6);

        // paw prints on the avenue lead to the City
        for (int y = TOP + 14; y < BASE - 14; y += 14) { MapBoulevard.paw(g, AVE_X + 8, y, 0x44E0A8C0); MapBoulevard.paw(g, AVE_X + 15, y + 6, 0x44E0A8C0); }

        // the street along the bottom of the world: kerb, asphalt, a crossing, cars
        rect(g, 0, STREET_Y - 4, W, 2, 0xFFFFFFFF); rect(g, 0, STREET_Y - 2, W, 2, 0xFFC8BAD8);
        MapArt.street(g, 0, STREET_Y, W, 8, true);
        rect(g, 0, STREET_Y + 10, W, WORLD_H - STREET_Y - 10, 0xFFD8D0EA);
        for (int i = 0; i < 4; i++) rect(g, 130 + i * 10, STREET_Y, 6, 8, 0xE0F4EEF8);
        int[] cc = {0xFFFF9AB8, 0xFF8AD0F0, 0xFFFFD27A, 0xFFB0E8B8};
        for (int i = 0; i < 3; i++) {
            int dir = i % 2 == 0 ? 1 : -1, y = dir > 0 ? STREET_Y + 4 : STREET_Y + 1;
            int x = Math.floorMod((int) (ticks * 0.6 * dir) + i * 97, W + 40) - 20;
            MapArt.car(g, x, y, dir, cc[(i + 1) % cc.length], i == 1);
        }
        for (int x : new int[]{24, 78, 232, 276}) MapArt.lamp(g, x, STREET_Y - 4, false);
        for (int x : new int[]{40, 104, 206, 262}) MapArt.planter(g, x, STREET_Y - 4);
        rect(g, 0, WORLD_H - 3, W, 3, 0xFF2E8B4A);                                                                                // the lower edge of the map is a hedge
        for (int x = 0; x < W; x += 6) ball(g, x + 3, WORLD_H - 3, 3, x % 12 == 0 ? 0xFF3FA55A : 0xFF4AB868);
    }

    /** A shop tower at the side of the avenue: a wall, a cornice, rows of windows (lit at night) and a striped awning at the foot. */
    private static void tower(GuiGraphics g, int x, int w0, int h, int c, boolean night) {
        int top = BASE - 14 - h, w = 24;
        rect(g, x, top, w, BASE - top, c);
        rect(g, x, top, 2, BASE - top, light(c, 0.3F)); rect(g, x + w - 3, top, 3, BASE - top, dark(c, 0.1F));
        rect(g, x - 1, top - 2, w + 2, 2, light(c, 0.45F)); rect(g, x - 1, top, w + 2, 1, dark(c, 0.2F));
        if (h % 3 == 0) { rect(g, x + 4, top - 7, 2, 5, dark(c, 0.15F)); rect(g, x + 3, top - 8, 4, 1, 0xFFFF9AB8); }
        for (int y = top + 5; y < BASE - 24; y += 8) for (int wx = x + 4; wx < x + w - 5; wx += 8) {
            boolean lit = night && ((wx * 7 + y * 3) % 5 != 0);
            rect(g, wx, y, 4, 5, lit ? 0xFFFFE680 : 0xFFB8E4FF); rect(g, wx, y, 4, 1, lit ? 0xFFFFF4B8 : 0xFFE0F4FF); rect(g, wx - 1, y + 5, 6, 1, dark(c, 0.2F));
        }
        int a = c % 2 == 0 ? 0xFFE8708F : 0xFF5AC08C;
        for (int i = 0; i < w; i += 4) rect(g, x + i, BASE - 14, 4, 5, (i / 4) % 2 == 0 ? a : 0xFFFFFFFF);
        rect(g, x, BASE - 9, w, 1, 0x20000000);
        rect(g, x + 2, BASE - 8, w - 4, 8, night ? 0xFFFFE8A8 : 0xFFD8F0FF); rect(g, x + 2, BASE - 8, w - 4, 1, 0x66FFFFFF); rect(g, x + w / 2, BASE - 8, 1, 8, dark(c, 0.3F));
    }

    private static void round(GuiGraphics g, int cx, int cy, int r) {
        rect(g, cx - 1, cy + 2, 3, r, 0xFF8A6248);
        ball(g, cx, cy - 2, r, 0xFF3FA55A); ball(g, cx - 3, cy, r - 2, 0xFF4AB868); ball(g, cx + 3, cy - 1, r - 2, 0xFF58C878); rect(g, cx - 3, cy - 5, 2, 1, 0xFFA8E8B8);
        rect(g, cx - 4, cy + r + 1, 9, 1, 0x28000000);
    }

    // =====================================================================================================
    //  THE PLACE: three pastel towers with a clock tower between them, an arcade of shops at the foot
    // =====================================================================================================
    /** cx = the middle, b = the ground line; 84 wide, about 64 high. */
    static void city(GuiGraphics g, int cx, int b, int ticks, boolean night) {
        int win = night ? 0xFFFFE680 : 0xFFB8E4FF, winTop = night ? 0xFFFFF4B8 : 0xFFE0F4FF;
        // the side towers
        sideTower(g, cx - 41, b, 18, 44, 0xFFC4B2EA, win, winTop, night);
        sideTower(g, cx + 23, b, 18, 52, 0xFF9ED2DC, win, winTop, night);
        // the middle block and the clock tower
        rect(g, cx - 22, b - 34, 44, 34, 0xFFF4E4CC); rect(g, cx - 22, b - 34, 2, 34, 0xFFFFF4E4); rect(g, cx + 19, b - 34, 3, 34, 0xFFD8C4A8);
        rect(g, cx - 24, b - 37, 48, 3, 0xFFD8B890); rect(g, cx - 24, b - 37, 48, 1, 0xFFFFE8C8);
        for (int i = 0; i < 4; i++) { rect(g, cx - 18 + i * 10, b - 30, 5, 7, win); rect(g, cx - 18 + i * 10, b - 30, 5, 1, winTop); rect(g, cx - 19 + i * 10, b - 23, 7, 1, 0xFFB89870); }
        rect(g, cx - 8, b - 58, 16, 22, 0xFFF4E4CC); rect(g, cx - 8, b - 58, 2, 22, 0xFFFFF4E4); rect(g, cx + 5, b - 58, 3, 22, 0xFFD8C4A8);
        rect(g, cx - 10, b - 61, 20, 3, 0xFFD8B890); rect(g, cx - 10, b - 61, 20, 1, 0xFFFFE8C8);
        for (int i = 0; i < 8; i++) rect(g, cx - 8 + i, b - 69 + i, 16 - i * 2, 1, i % 2 == 0 ? 0xFF6AA8C8 : 0xFF7AB8D8);               // the pointed roof
        rect(g, cx, b - 78, 1, 9, 0xFF6A5A7A); rect(g, cx + 1, b - 77, 4, 2, 0xFFFF7A9A);
        ball(g, cx, b - 50, 5, 0xFFD8B890); ball(g, cx, b - 50, 4, 0xFFFFFFFF);                                                         // the clock
        rect(g, cx, b - 53, 1, 3, 0xFF3A2A4A); rect(g, cx, b - 50, 3, 1, 0xFF3A2A4A);
        // the arcade of shops at the foot: arches, awnings and warm windows
        rect(g, cx - 42, b - 14, 84, 14, 0xFFFFF0E0); rect(g, cx - 42, b - 14, 84, 1, 0xFFFFFFFF);
        for (int i = 0; i < 84; i += 4) rect(g, cx - 42 + i, b - 16, 4, 4, (i / 4) % 2 == 0 ? 0xFFE8708F : 0xFFFFFFFF);
        for (int i = 0; i < 84; i += 4) rect(g, cx - 41 + i, b - 12, 2, 1, (i / 4) % 2 == 0 ? 0xFFE8708F : 0xFFFFFFFF);
        for (int s = -1; s <= 1; s += 2) for (int i = 0; i < 2; i++) {
            int wx = cx + s * (14 + i * 12) - 4;
            rect(g, wx, b - 10, 8, 8, night ? 0xFFFFE8A8 : 0xFFD8F0FF); rect(g, wx, b - 10, 8, 1, 0x88FFFFFF); rect(g, wx + 4, b - 10, 1, 8, 0xFFB89870);
            rect(g, wx + 1, b - 4, 2, 2, 0xFFE8A04A); rect(g, wx + 5, b - 4, 2, 2, 0xFFFF9AC0);
        }
        rect(g, cx - 5, b - 11, 10, 11, 0xFF9A5A8A); rect(g, cx - 5, b - 11, 10, 1, 0xFFC890B8); rect(g, cx - 4, b - 10, 3, 4, 0xFFB8E4FF); rect(g, cx + 1, b - 10, 3, 4, 0xFFB8E4FF); rect(g, cx, b - 11, 1, 11, 0xFF6A3A5A);
        // a heart over the door and bunting under the eaves
        rect(g, cx - 2, b - 19, 2, 2, 0xFFFF5A8A); rect(g, cx + 1, b - 19, 2, 2, 0xFFFF5A8A); rect(g, cx - 2, b - 18, 5, 2, 0xFFFF5A8A); rect(g, cx - 1, b - 16, 3, 1, 0xFFFF5A8A);
        for (int i = 0; i < 9; i++) rect(g, cx - 40 + i * 10, b - 42 + (i % 2), 3, 3, i % 3 == 0 ? 0xFFFF8FB8 : i % 3 == 1 ? 0xFFFFE066 : 0xFF8ADCE0);
        // planters with little trees
        for (int s = -1; s <= 1; s += 2) { MapArt.planter(g, cx + s * 37, b + 2); ball(g, cx + s * 37, b - 5, 3, 0xFFFF9AC8); }
        if (night) ball(g, cx, b - 12, 22, 0x14FFE090);
    }

    private static void sideTower(GuiGraphics g, int x, int b, int w, int h, int c, int win, int winTop, boolean night) {
        int top = b - 14 - h;
        rect(g, x, top, w, h + 2, c); rect(g, x, top, 2, h + 2, light(c, 0.3F)); rect(g, x + w - 3, top, 3, h + 2, dark(c, 0.1F));
        rect(g, x - 1, top - 2, w + 2, 2, light(c, 0.45F));
        rect(g, x + w / 2, top - 8, 1, 6, 0xFF6A5A7A); rect(g, x + w / 2 - 1, top - 9, 3, 1, 0xFFFF9AB8);
        for (int y = top + 4; y < b - 22; y += 7) for (int wx = x + 3; wx < x + w - 3; wx += 6) {
            boolean lit = !night || ((wx * 5 + y) % 4 != 0);
            rect(g, wx, y, 3, 4, night && !lit ? 0xFF6A6A9A : win); rect(g, wx, y, 3, 1, night && !lit ? 0xFF8A8ABA : winTop);
        }
    }
}
