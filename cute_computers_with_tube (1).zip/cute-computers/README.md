# Cute Computers (NeoForge 1.21.1)

Cute retro computers in 8 colors. **Right-click a computer to open its desktop.**
The desktop has: your computer's own game, a **Games** folder (all 8 games on any computer), a **Browser**, **Notes**, **Paint**, **Calculator** and **Settings**.
No redstone or energy needed. Every computer remembers its own high score and who set it.

![preview](docs/preview.png)

| Block | Game | Controls |
|---|---|---|
| `pink_computer` | Flappy Cat | click / Space |
| `green_computer` | Creeper Sweeper (minesweeper) | LMB dig, RMB flag |
| `white_computer` | Panda Snake | WASD / arrows |
| `blue_computer` | Penguin Fishing | mouse (avoid the pufferfish!) |
| `orange_computer` | Fox Memory (pairs) | click |
| `purple_computer` | Ender Dodge | mouse |
| `yellow_computer` | Whack-a-Bee | click the bee |
| `red_computer` | Ladybug Match (match-3, 20 moves) | click two neighbors |

## Desktop apps
| App | What it does |
|---|---|
| Games | all 14 games on any computer (the record in the block counts only for the computer's own game). Extra games: Cookie Breaker (breakout), Merge Cubes (2048), Slime Pong, Bee Invaders, Something in the Dark (horror: the monster only moves while you're not lighting it), **Dark Corridor** (first-person horror: a random dark maze, find 3 keys and the green door while a pale figure hunts you; WASD/arrows, a map of the places you have been in the corner) |
| Browser | the **Cute Web**, a made-up internet (GTA 5 style): `peep.cute` search, `chirp.cute`, `creepermart.cute`, `pandapedia.cute`, `beemail.cute`, `cutenews.cute`, `scarystories.cute` (dark theme, flickering light, watching eyes). Also `cutetube.cute` - **CuteTube**: 6 tiny animated videos with note-block sound, a progress bar and volume slider, likes, ready-made comments and your own (type in the box, Enter sends; space = pause, arrows = skip 5 s). With **Spooky** on, a 7th video appears: "Don't Watch at 3 AM" (eyes in the corner, something in the door, a jump scare, and it says your name at the end). Every page has an animated ad banner at the bottom (click it to visit the advertiser, "x" skips to the next ad). Words in the address bar search it; real addresses like `example.com` open in your system browser after the vanilla "open link?" confirmation |
| Haunting | on its own the computer sometimes shows annoying pop-up ads (the "x" runs away, "bad" buttons spawn more windows) and creepy events: watching eyes, screen glitches, whispers, a fake record held by "The One Behind You", a line that types itself in Notes (never saved), corrupted ads in the browser. Everything is display-only. Settings has switches for **Spooky** and **Pop-ups** |
| Music | player with 4 little songs played on note-block sounds (lead + bass), equalizer, volume. Plays while the app is open |
| Tamagotchi | every computer color has its own pet (cat, creeper, panda, penguin, fox, enderman, bee, ladybug): feed it, play, let it sleep, pet it. Saved to `cutemod_pet_<color>.txt`, gets hungry slowly even while you are away |
| Notes | text editor, saved to `cutemod_notes.txt` in the game folder |
| Paint | 64x36 pixel drawing (LMB draw, RMB erase) |
| Calculator | mouse or keyboard |
| Settings | 6 wallpapers, remembered in `cutemod_wallpaper.txt` |

## Crafting
- Pink computer: iron ingots, glass pane, pink dye, redstone (`IGI / IDI / IRI`).
- Any other color: any computer + the matching dye (shapeless).

## Build
Requires Java 21.

```
./gradlew build          # jar in build/libs
./gradlew runClient      # test in game
```
GitHub Actions (`.github/workflows/build.yml`) builds the jar on every push.

## Project layout
- `src/main/java/dev/cutemod` - blocks, block entity (high score), network packet
- `src/main/java/dev/cutemod/client` - the monitor screen, `os/` (desktop and apps) and `game/` (all 8 mini games)
- `src/main/resources/assets/cutemod` - models, blockstates, textures (64x), lang (en, ru)
- `tools/` - Python scripts that generated the colored textures from the original pink pack

## Adding a new app
Extend `App` (`title`, `render`, optionally `tick`/`click`/`key`/`charTyped`) and add an icon in `Desktop`.

## Adding a new game
Extend `MiniGame` (`reset`, `tick` at 60/s, `render`, optionally `click`/`key`) and map it to a color in `GameFactory`.

## License
MIT
