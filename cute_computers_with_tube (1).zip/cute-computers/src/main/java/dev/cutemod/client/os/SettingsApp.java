package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Settings: pick the desktop wallpaper. */
public class SettingsApp extends App {
    private static final int COLS = 3, TW = 88, TH = 52, GAP = 8;
    private static final int X0 = (W - (COLS * TW + (COLS - 1) * GAP)) / 2, Y0 = 26;

    @Override
    public Component title() { return Component.translatable("cutemod.os.settings"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.settings"); }

    private static int tx(int i) { return X0 + (i % COLS) * (TW + GAP); }

    private static int ty(int i) { return Y0 + (i / COLS) * (TH + GAP); }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        rect(g, 0, 0, W, H, 0xFFE9DDF2);
        g.drawString(font(), t("cutemod.os.wallpaper"), X0, 10, 0xFF3A2A3A, false);
        for (int i = 0; i < Wallpaper.COUNT; i++) {
            int x = tx(i), y = ty(i);
            boolean selected = i == Wallpaper.get();
            boolean hover = in(mx, my, x, y, TW, TH);
            rect(g, x - 2, y - 2, TW + 4, TH + 4, selected ? 0xFFFFD866 : (hover ? 0xFFFFFFFF : 0xFF3A2A4A));
            Wallpaper.draw(g, x, y, TW, TH, shell.color().bodyColor, i);
        }
        toggle(g, mx, my, 0, "cutemod.os.set.scary", Haunt.scary);
        toggle(g, mx, my, 1, "cutemod.os.set.popups", Haunt.popups);
    }

    private static int bx(int i) { return X0 + i * (TW * 3 + GAP * 2 + 6) / 2; }

    private void toggle(GuiGraphics g, int mx, int my, int i, String key, boolean on) {
        int x = bx(i), y = 144, w = (TW * 3 + GAP * 2 - 6) / 2;
        boolean hover = in(mx, my, x, y, w, 14);
        rect(g, x, y, w, 14, on ? (hover ? 0xFFB57BD6 : 0xFF9A64BF) : (hover ? 0xFFFFFFFF : 0xFFC9B8D8));
        String s = t(key) + ": " + t(on ? "cutemod.os.on" : "cutemod.os.off");
        g.drawString(font(), s, x + (w - font().width(s)) / 2, y + 3, on ? 0xFFFFFFFF : 0xFF3A2A3A, false);
    }

    @Override
    public boolean click(int x, int y, int button) {
        int tw = (TW * 3 + GAP * 2 - 6) / 2;
        if (in(x, y, bx(0), 144, tw, 14)) { Haunt.scary = !Haunt.scary; return true; }
        if (in(x, y, bx(1), 144, tw, 14)) { Haunt.popups = !Haunt.popups; return true; }
        for (int i = 0; i < Wallpaper.COUNT; i++) {
            if (in(x, y, tx(i), ty(i), TW, TH)) {
                Wallpaper.set(i);
                return true;
            }
        }
        return false;
    }
}
