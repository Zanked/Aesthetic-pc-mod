package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Things that happen on their own while you use the computer: annoying pop-up "ads" and a few
 * creepy events (eyes, glitches, whispers, a haunted record). Everything is display-only,
 * nothing is saved or changed. Both parts can be switched off in Settings.
 */
public class Haunt {
    public static boolean scary = true;
    public static boolean popups = true;

    private static final int W = App.W, H = App.H;
    private static final int POP_W = 160, POP_H = 58, MAX_POPUPS = 5;
    private static final int[] TITLE_COLORS = {0xFFF5C518, 0xFFE5484D, 0xFF5BBF6A};

    private static final class Popup {
        int x, y, type, slot, dodges;
    }

    private final Random rnd = new Random();
    private final List<Popup> pops = new ArrayList<>();
    private int mx = -100, my = -100;
    private boolean game;

    private int nextPopup = 900 + rnd.nextInt(900);   // first pop-up after 15-30 s on the desktop / browser
    private int eventTimer = 2400 + rnd.nextInt(3600); // creepy event every 40-100 s
    private int event = -1, evTimer, evTotal, evA, evB, evSeed;
    private int recordTimer;

    // ---------- helpers ----------
    private static Font font() { return Minecraft.getInstance().font; }

    private static String t(String key) { return Component.translatable(key).getString(); }

    private static void rect(GuiGraphics g, int x, int y, int w, int h, int argb) { g.fill(x, y, x + w, y + h, argb); }

    private static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && py >= y && px < x + w && py < y + h;
    }

    private static void sound(float pitch, float volume) {
        Minecraft.getInstance().getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
                net.minecraft.sounds.SoundEvents.NOTE_BLOCK_CHIME.value(), pitch, volume));
    }

    private static int closeX(int slot) { return slot == 0 ? POP_W - 13 : slot == 1 ? 2 : POP_W / 2 - 5; }

    /** The "record" in the footer is replaced by a creepy one for a few seconds. */
    public boolean recordHaunted() { return scary && recordTimer > 0; }

    // ---------- logic (60 times a second) ----------
    public void tick(App app) {
        game = app instanceof GameApp;
        boolean web = app instanceof BrowserApp || app instanceof Desktop;

        if (popups && web && --nextPopup <= 0) {
            spawnPopup();
            nextPopup = 1800 + rnd.nextInt(2400); // next one in 30-70 s
        }

        // the "x" of a pop-up runs away from the mouse a few times
        if (!game) {
            for (Popup p : pops) {
                if (p.type == 3 || p.dodges >= 4) continue;
                int cx = p.x + closeX(p.slot) + 5, cy = p.y + 7;
                if (Math.abs(mx - cx) < 14 && Math.abs(my - cy) < 12) {
                    p.slot = (p.slot + 1 + rnd.nextInt(2)) % 3;
                    p.dodges++;
                }
            }
        }

        if (!scary) return;
        if (event < 0) {
            if (--eventTimer <= 0) startEvent(rnd.nextInt(3));
        } else if (--evTimer <= 0) {
            event = -1;
            eventTimer = 3600 + rnd.nextInt(3600);
        }
        if (recordTimer > 0) recordTimer--;
        else if (app.showRecord() && rnd.nextInt(2400) == 0) { recordTimer = 300; sound(0.5F, 0.5F); }
    }

    private void startEvent(int type) {
        event = type;
        evTotal = evTimer = type == 0 ? 150 : type == 1 ? 30 : 200;
        evA = 10 + rnd.nextInt(W - 50);
        evB = type == 0 ? (rnd.nextBoolean() ? 8 : H - 16) : rnd.nextInt(4);
        evSeed = rnd.nextInt();
        if (type != 1) sound(0.5F, 0.5F);
    }

    private void spawnPopup() {
        if (pops.size() >= MAX_POPUPS) return;
        Popup p = new Popup();
        p.type = (scary && rnd.nextInt(6) == 0) ? 3 : rnd.nextInt(3);
        p.x = rnd.nextInt(W - POP_W);
        p.y = 4 + rnd.nextInt(H - POP_H - 8);
        pops.add(p);
        sound(1.8F, 0.3F);
    }

    // ---------- render ----------
    public void render(GuiGraphics g, int mouseX, int mouseY) {
        mx = mouseX;
        my = mouseY;
        if (scary && event >= 0) renderEvent(g);
        if (!game) renderPopups(g);
    }

    private void renderEvent(GuiGraphics g) {
        Font f = font();
        int a = Math.min(255, Math.min(evTimer, evTotal - evTimer) * 10);
        switch (event) {
            case 0 -> { // eyes in the dark
                boolean blink = (evTimer % 70) < 5;
                rect(g, evA - 3, evB - 3, 24, 9, ((a / 5) << 24) | 0xFF0000);
                if (a < 8) return;
                if (!blink) {
                    rect(g, evA, evB, 7, 3, (a << 24) | 0xFF2A2A);
                    rect(g, evA + 13, evB, 7, 3, (a << 24) | 0xFF2A2A);
                    rect(g, evA + 3, evB + 1, 2, 1, a << 24);
                    rect(g, evA + 16, evB + 1, 2, 1, a << 24);
                } else {
                    rect(g, evA, evB + 1, 7, 1, (a << 24) | 0x7A1010);
                    rect(g, evA + 13, evB + 1, 7, 1, (a << 24) | 0x7A1010);
                }
            }
            case 1 -> { // the picture glitches
                Random r = new Random(evSeed + (evTimer / 3) * 7919L);
                if (evTimer > evTotal - 3 || r.nextInt(5) == 0) rect(g, 0, 0, W, H, 0x88000000);
                int[] cols = {0x66FF00FF, 0x6600FFFF, 0xAA000000, 0x66FFFF00};
                for (int i = 0; i < 7; i++) {
                    int y = r.nextInt(H), h = 1 + r.nextInt(6), x = r.nextInt(W / 2), w = 40 + r.nextInt(W);
                    rect(g, x, y, w, h, cols[r.nextInt(cols.length)]);
                }
            }
            default -> { // a whisper on the screen
                if (a < 8) return;
                String s = t("cutemod.haunt.whisper." + evB);
                rect(g, 0, H - 19, W, 14, ((a / 2) << 24));
                g.drawString(f, s, (W - f.width(s)) / 2, H - 16, (a << 24) | 0xD9302A, false);
            }
        }
    }

    private void renderPopups(GuiGraphics g) {
        Font f = font();
        for (Popup p : pops) {
            boolean dark = p.type == 3;
            int x = p.x, y = p.y;
            rect(g, x - 1, y - 1, POP_W + 2, POP_H + 2, dark ? 0xFF5A0F15 : 0xFF3A2A4A);
            rect(g, x, y, POP_W, POP_H, dark ? 0xFF0D0A10 : 0xFFF6F0FA);
            rect(g, x, y, POP_W, 14, dark ? 0xFF5A0F15 : TITLE_COLORS[p.type]);
            g.drawString(f, t("cutemod.pop.title." + p.type), x + 16, y + 3, dark ? 0xFFD9534F : 0xFF3A2A3A, false);
            if (!dark) { // close button (it runs away)
                boolean hv = in(mx, my, x + closeX(p.slot), y + 2, 11, 11);
                rect(g, x + closeX(p.slot), y + 2, 11, 11, hv ? 0xFFFFFFFF : 0xCCFFFFFF);
                g.drawString(f, "x", x + closeX(p.slot) + 3, y + 3, 0xFF3A2A3A, false);
            }
            List<FormattedCharSequence> lines = f.split(FormattedText.of(t("cutemod.pop.msg." + p.type)), POP_W - 12);
            for (int l = 0; l < lines.size() && l < 3; l++) {
                g.drawString(f, lines.get(l), x + 6, y + 18 + l * 9, dark ? 0xFFD9534F : 0xFF3A2A3A, false);
            }
            if (dark) {
                button(g, x + (POP_W - 70) / 2, y + POP_H - 16, t("cutemod.pop.ok.3"), 0xFF5A0F15, 0xFFD9534F);
            } else {
                button(g, x + 6, y + POP_H - 16, t("cutemod.pop.bad." + p.type), 0xFF2F9BFF, 0xFFFFFFFF);
                button(g, x + POP_W - 76, y + POP_H - 16, t("cutemod.pop.ok." + p.type), 0xFFB9A8C8, 0xFF3A2A3A);
            }
        }
    }

    private void button(GuiGraphics g, int x, int y, String label, int bg, int fg) {
        Font f = font();
        boolean hv = in(mx, my, x, y, 70, 12);
        rect(g, x, y, 70, 12, hv ? App.mix(bg & 0xFFFFFF, 0xFFFFFF, 0.3f) : bg);
        String s = label;
        while (s.length() > 1 && f.width(s) > 66) s = s.substring(0, s.length() - 1);
        g.drawString(f, s, x + (70 - f.width(s)) / 2, y + 2, fg, false);
    }

    // ---------- input ----------
    /** Returns true if a pop-up swallowed the click. */
    public boolean click(int x, int y, int button) {
        if (game) return false;
        for (int i = pops.size() - 1; i >= 0; i--) {
            Popup p = pops.get(i);
            if (!in(x, y, p.x, p.y, POP_W, POP_H)) continue;
            boolean dark = p.type == 3;
            if (!dark && in(x, y, p.x + closeX(p.slot), p.y + 2, 11, 11)) { // the "x"
                pops.remove(i);
                return true;
            }
            int by = p.y + POP_H - 16;
            if (dark) {
                if (in(x, y, p.x + (POP_W - 70) / 2, by, 70, 12)) {
                    pops.remove(i);
                    if (scary) startEvent(0); // closing it did not help
                    return true;
                }
            } else if (in(x, y, p.x + 6, by, 70, 12)) { // the "bad" button: more pop-ups!
                pops.remove(i);
                spawnPopup();
                spawnPopup();
                return true;
            } else if (in(x, y, p.x + POP_W - 76, by, 70, 12)) {
                pops.remove(i);
                return true;
            }
            pops.remove(i); // click on the window: bring it to the front
            pops.add(p);
            return true;
        }
        return false;
    }
}
