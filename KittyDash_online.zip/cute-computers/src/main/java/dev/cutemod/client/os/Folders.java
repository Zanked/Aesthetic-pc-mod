package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The folders the player makes. A folder holds apps and games (not other folders); it can stand on the desktop
 * (free position, drag it around), in the Dock, or just live in the Start menu. Saved on the server through
 * {@link Store} as "folders" (the folders) and "deskicons" (where they stand on the desktop).
 * The look of a folder icon (a frosted tile showing the first 9 icons inside) is drawn here too.
 */
public final class Folders {
    private Folders() {}

    public static final int MAX_NAME = 16;
    /** The size of a folder on the desktop: a 24 px icon, the name under it. */
    public static final int DESK_W = 36, DESK_H = 35;

    /** Tile colors (top, bottom) a folder can have. */
    public static final int[][] PAL = {
            {0xFFA9C4F5, 0xFF6F8FD8},   // periwinkle
            {0xFFFFA3C4, 0xFFE5558A},   // pink
            {0xFFFFC98A, 0xFFF08A3C},   // orange
            {0xFFFFE27A, 0xFFF0B820},   // yellow
            {0xFF9BE3A5, 0xFF3FB36A},   // green
            {0xFF86DCE8, 0xFF2AA3C0},   // teal
            {0xFFC9A6F5, 0xFF8A55D8},   // purple
            {0xFFB8BFCC, 0xFF6F7788}};  // graphite

    private static final class Folder {
        final int id;
        String name;
        int color;
        final List<Integer> items = new ArrayList<>();
        Folder(int id, String name, int color) { this.id = id; this.name = name; this.color = color; }
    }

    private static final List<Folder> list = new ArrayList<>();
    private static final Map<Integer, int[]> desk = new LinkedHashMap<>();
    private static int next = Items.FOLDER_BASE, gen = -1;

    // ---------- load / save ----------
    private static void ensure() {
        if (gen == Store.gen()) return;
        gen = Store.gen();
        list.clear();
        desk.clear();
        next = Items.FOLDER_BASE;
        String s = Store.read("folders");
        if (s != null) {
            for (String line : s.split("\n")) {
                try {
                    if (line.startsWith("next=")) { next = Math.max(next, Integer.parseInt(line.substring(5).trim())); continue; }
                    String[] p = line.split("\\|", -1);
                    if (p.length < 4) continue;
                    Folder f = new Folder(Integer.parseInt(p[0].trim()), clean(p[2]), Math.floorMod(Integer.parseInt(p[1].trim()), PAL.length));
                    if (f.id < Items.FOLDER_BASE || get(f.id) != null) continue;
                    for (String it : p[3].split(",")) {
                        if (it.isBlank()) continue;
                        int v = Integer.parseInt(it.trim());
                        if (Items.valid(v) && !Items.isFolder(v) && !f.items.contains(v)) f.items.add(v);
                    }
                    list.add(f);
                    next = Math.max(next, f.id + 1);
                } catch (NumberFormatException ignored) {
                }
            }
        }
        String d = Store.read("deskicons");
        if (d != null) {
            for (String part : d.trim().split(",")) {
                try {
                    String[] p = part.trim().split(":");
                    int id = Integer.parseInt(p[0]);
                    if (get(id) != null) desk.put(id, new int[]{Integer.parseInt(p[1]), Integer.parseInt(p[2])});
                } catch (RuntimeException ignored) {
                }
            }
        }
    }

    private static void save() {
        StringBuilder sb = new StringBuilder("next=").append(next).append('\n');
        for (Folder f : list) {
            sb.append(f.id).append('|').append(f.color).append('|').append(f.name).append('|');
            for (int i = 0; i < f.items.size(); i++) sb.append(i == 0 ? "" : ",").append(f.items.get(i));
            sb.append('\n');
        }
        Store.write("folders", sb.toString());
    }

    private static void saveDesk() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Integer, int[]> e : desk.entrySet())
            sb.append(sb.length() == 0 ? "" : ",").append(e.getKey()).append(':').append(e.getValue()[0]).append(':').append(e.getValue()[1]);
        Store.write("deskicons", sb.length() == 0 ? "" : sb.toString());
    }

    private static String clean(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) if (c >= 32 && c != 127 && c != '|') sb.append(c);
        String r = sb.toString().trim();
        return r.length() > MAX_NAME ? r.substring(0, MAX_NAME).trim() : r;
    }

    private static Folder get(int id) {
        for (Folder f : list) if (f.id == id) return f;
        return null;
    }

    // ---------- folders ----------
    public static boolean exists(int id) { ensure(); return get(id) != null; }

    public static String name(int id) { ensure(); Folder f = get(id); return f == null ? "" : f.name; }

    public static int color(int id) { ensure(); Folder f = get(id); return f == null ? 0 : f.color; }

    /** Every folder, oldest first. */
    public static List<Integer> all() {
        ensure();
        List<Integer> l = new ArrayList<>();
        for (Folder f : list) l.add(f.id);
        return l;
    }

    public static int create(String name) {
        ensure();
        String n = clean(name);
        Folder f = new Folder(next++, n.isEmpty() ? "Folder" : n, 0);
        list.add(f);
        save();
        return f.id;
    }

    public static void delete(int id) {
        ensure();
        Folder f = get(id);
        if (f == null) return;
        list.remove(f);
        desk.remove(id);
        DockLayout.unpin(id);
        save();
        saveDesk();
    }

    public static void rename(int id, String name) {
        ensure();
        Folder f = get(id);
        String n = clean(name);
        if (f == null || n.isEmpty() || n.equals(f.name)) return;
        f.name = n;
        save();
    }

    public static void cycleColor(int id) {
        ensure();
        Folder f = get(id);
        if (f == null) return;
        f.color = (f.color + 1) % PAL.length;
        save();
    }

    // ---------- what is inside ----------
    /** The apps and games in the folder that are installed (an uninstalled app is just not shown, it stays in the list). */
    public static List<Integer> items(int id) {
        ensure();
        Folder f = get(id);
        List<Integer> out = new ArrayList<>();
        if (f == null) return out;
        for (int v : f.items) if (Library.available(v)) out.add(v);
        return out;
    }

    public static boolean has(int id, int item) { ensure(); Folder f = get(id); return f != null && f.items.contains(item); }

    public static void toggle(int id, int item) {
        ensure();
        Folder f = get(id);
        if (f == null || !Items.valid(item) || Items.isFolder(item)) return;
        if (!f.items.remove((Integer) item)) f.items.add(item);
        save();
    }

    public static void remove(int id, int item) {
        ensure();
        Folder f = get(id);
        if (f != null && f.items.remove((Integer) item)) save();
    }

    // ---------- the desktop ----------
    public static List<Integer> onDesk() {
        ensure();
        return new ArrayList<>(desk.keySet());
    }

    public static boolean onDesk(int id) { ensure(); return desk.containsKey(id); }

    /** Top-left corner of a folder on the desktop (the 36 x 35 box), or null. */
    public static int[] deskPos(int id) { ensure(); return desk.get(id); }

    private static int[] slot(int n) {
        if (n < 6) return new int[]{136 + (n / 3) * 46, 10 + (n % 3) * 48};
        int k = (n - 6) % 5;
        return new int[]{140 + k * 5, 14 + k * 5};
    }

    /** Puts a folder on the desktop on the first free spot (nothing happens if it is there already). */
    public static void deskAdd(int id) {
        ensure();
        if (get(id) == null || desk.containsKey(id)) return;
        for (int n = 0; ; n++) {
            int[] s = slot(n);
            boolean free = n >= 6;
            if (!free) {
                free = true;
                for (int[] o : desk.values()) if (Math.abs(o[0] - s[0]) < DESK_W && Math.abs(o[1] - s[1]) < DESK_H) free = false;
            }
            if (free) { desk.put(id, s); break; }
        }
        saveDesk();
    }

    public static void deskMove(int id, int x, int y) {
        ensure();
        if (get(id) == null) return;
        desk.put(id, new int[]{Math.max(0, Math.min(App.W - DESK_W, x)), Math.max(0, Math.min(App.H - DESK_H, y))});
        saveDesk();
    }

    public static void deskRemove(int id) {
        ensure();
        if (desk.remove(id) != null) saveDesk();
    }

    // ---------- the icon ----------
    /**
     * A modern folder: a rounded glossy tile in the folder's color with a frosted plate on it that shows the
     * first nine icons inside, tiny (an empty folder shows a plain folder shape). Drawn in a 32 x 32 box.
     */
    public static void drawIcon(GuiGraphics g, int id, int x, int y, int body) {
        int c = Math.floorMod(color(id), PAL.length);
        Desktop.tile(g, x, y, PAL[c][0], PAL[c][1]);
        App.roundRect(g, x + 3, y + 3, 26, 26, 6, 0x42FFFFFF);
        List<Integer> in = items(id);
        if (in.isEmpty()) {
            final int WH = 0xEBFFFFFF;
            g.fill(x + 8, y + 10, x + 15, y + 13, WH);
            g.fill(x + 8, y + 12, x + 24, y + 23, WH);
            return;
        }
        for (int i = 0; i < Math.min(9, in.size()); i++) {
            g.pose().pushPose();
            g.pose().translate(x + 5 + (i % 3) * 8, y + 5 + (i / 3) * 8, 0);
            g.pose().scale(7f / 32f, 7f / 32f, 1f);
            Desktop.drawIcon(g, in.get(i), 0, 0, body);
            g.pose().popPose();
        }
    }
}
