package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.HexFormat;

/**
 * What happens before the desktop is usable: the boot (loading) screen, the password screen
 * (only if a password is set in Settings) and the welcome splash. The same overlay also draws the
 * screensaver that starts when nothing is touched for a while, and the lock screen.
 * It covers the whole screen area of the computer and eats every click and key while it is active.
 */
public final class Startup {
    private enum Stage { BOOT, LOCK, WELCOME, DONE, SAVER }

    public static final int BOOT_TICKS = 150;
    private static final int WELCOME_TICKS = 90;
    private static final int MAX_PASSWORD = 24;
    private static final int KEY_ESC = 256, KEY_ENTER = 257, KEY_BACKSPACE = 259, KEY_KP_ENTER = 335;

    private Stage stage = Stage.BOOT;
    private int t;
    private int shake;
    private boolean wrong;
    private final StringBuilder input = new StringBuilder();
    // screensaver heart
    private float hx = 40, hy = 30, vx = 0.6f, vy = 0.45f;
    // notes waiting to be played: {tick when due, semitone, instrument}
    private final java.util.List<int[]> notes = new java.util.ArrayList<>();
    private int clock;

    public Startup() {
        Sfx.powerOn();
        Sfx.startFan();
    }

    private void jingle(int[][] j) {
        for (int[] n : j) notes.add(new int[]{clock + n[0], n[1], n[2]});
    }

    // ================= password storage (this PC only, cutemod_password.txt) =================
    private static boolean pwLoaded;
    private static String pwSalt = "", pwHash = "";

    private static Path pwFile() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("cutemod_password.txt");
    }

    private static void pwLoad() {
        if (pwLoaded) return;
        pwLoaded = true;
        try {
            Path p = pwFile();
            if (Files.exists(p)) {
                String[] parts = Files.readString(p).trim().split(":");
                if (parts.length == 2) {
                    pwSalt = parts[0];
                    pwHash = parts[1];
                }
            }
        } catch (Exception ignored) {
        }
    }

    private static String hash(String salt, String pw) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest((salt + pw).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(d);
        } catch (Exception e) {
            return "";
        }
    }

    public static boolean hasPassword() {
        pwLoad();
        return !pwHash.isEmpty();
    }

    public static boolean checkPassword(String pw) {
        pwLoad();
        return !pwHash.isEmpty() && pwHash.equals(hash(pwSalt, pw));
    }

    /** Set a new password; null or empty removes it. */
    public static void setPassword(String pw) {
        pwLoad();
        try {
            if (pw == null || pw.isEmpty()) {
                pwSalt = "";
                pwHash = "";
                Files.deleteIfExists(pwFile());
                return;
            }
            byte[] s = new byte[8];
            new SecureRandom().nextBytes(s);
            pwSalt = HexFormat.of().formatHex(s);
            pwHash = hash(pwSalt, pw);
            Files.writeString(pwFile(), pwSalt + ":" + pwHash);
        } catch (Exception ignored) {
        }
    }

    // ================= state =================
    public boolean active() { return stage != Stage.DONE; }

    /** The screensaver may only start while the desktop is in use. */
    public boolean canSave() { return stage == Stage.DONE; }

    public void saver() {
        if (stage != Stage.DONE) return;
        stage = Stage.SAVER;
        t = 0;
    }

    /** "Lock screen" from the logo menu: the password screen, or the screensaver if there is no password. */
    public void lock() {
        if (stage != Stage.DONE) return;
        jingle(Sfx.LOCK);
        if (hasPassword()) toLock();
        else saver();
    }

    private void toLock() {
        stage = Stage.LOCK;
        t = 0;
        input.setLength(0);
        wrong = false;
        shake = 0;
    }

    private void afterBoot() {
        jingle(Sfx.STARTUP);
        if (hasPassword()) toLock();
        else {
            stage = Stage.WELCOME;
            t = 0;
        }
    }

    private void wake() {
        Sfx.click();
        if (hasPassword()) toLock();
        else stage = Stage.DONE;
    }

    public void tick() {
        t++;
        clock++;
        notes.removeIf(n -> {
            if (clock < n[0]) return false;
            Sfx.note(n);
            return true;
        });
        if (stage != Stage.BOOT && stage != Stage.SAVER && (clock % 40) == 0 && Math.random() < 0.18) Sfx.disk();
        if (shake > 0) shake--;
        switch (stage) {
            case BOOT -> { if (t >= BOOT_TICKS) afterBoot(); }
            case WELCOME -> { if (t >= WELCOME_TICKS) stage = Stage.DONE; }
            default -> {}
        }
    }

    // ================= input =================
    public boolean click() {
        switch (stage) {
            case BOOT -> { if (t > 15) t = BOOT_TICKS; }
            case SAVER -> wake();
            case WELCOME -> stage = Stage.DONE;
            default -> {}
        }
        return active();
    }

    public boolean key(int keyCode) {
        if (!active()) return false;
        if (keyCode == KEY_ESC && stage != Stage.SAVER) return false;      // Esc still leaves the computer
        switch (stage) {
            case BOOT -> { if (t > 15) t = BOOT_TICKS; }
            case SAVER -> wake();
            case WELCOME -> stage = Stage.DONE;
            case LOCK -> {
                if (keyCode == KEY_ENTER || keyCode == KEY_KP_ENTER) submit();
                else if (keyCode == KEY_BACKSPACE && input.length() > 0) {
                    input.setLength(input.length() - 1);
                    wrong = false;
                }
            }
            default -> {}
        }
        return true;
    }

    public boolean charTyped(char c) {
        if (!active()) return false;
        if (stage == Stage.LOCK && c >= 32 && c != 127 && input.length() < MAX_PASSWORD) {
            input.append(c);
            Sfx.key();
            wrong = false;
        }
        return true;
    }

    private void submit() {
        if (checkPassword(input.toString())) {
            input.setLength(0);
            stage = Stage.WELCOME;
            t = 0;
            jingle(Sfx.LOGIN);
        } else {
            Sfx.error();
            wrong = true;
            shake = 18;
            input.setLength(0);
        }
    }

    // ================= drawing =================
    private static void heart(GuiGraphics g, int x, int y, int s, int argb) {
        g.fill(x + s, y, x + 3 * s, y + s, argb);
        g.fill(x + 4 * s, y, x + 6 * s, y + s, argb);
        g.fill(x, y + s, x + 7 * s, y + 3 * s, argb);
        g.fill(x + s, y + 3 * s, x + 6 * s, y + 4 * s, argb);
        g.fill(x + 2 * s, y + 4 * s, x + 5 * s, y + 5 * s, argb);
        g.fill(x + 3 * s, y + 5 * s, x + 4 * s, y + 6 * s, argb);
    }

    private static void centered(GuiGraphics g, Font f, String s, int cx, int y, int argb) {
        g.drawString(f, s, cx - f.width(s) / 2, y, argb, false);
    }

    private static int alpha(int rgb, float a) {
        return ((int) (Math.max(0, Math.min(1, a)) * 255) << 24) | (rgb & 0xFFFFFF);
    }

    private static String playerName() {
        try {
            return Minecraft.getInstance().getUser().getName();
        } catch (Exception e) {
            return "Player";
        }
    }

    /** Draw over the screen area (x, y, w, h); body is the computer's color. */
    public void render(GuiGraphics g, int x, int y, int w, int h, int body, float partial) {
        Font f = Minecraft.getInstance().font;
        int cx = x + w / 2, cy = y + h / 2;
        switch (stage) {
            case BOOT -> renderBoot(g, f, x, y, w, h, cx, cy, body, partial);
            case LOCK -> renderLock(g, f, x, y, w, h, cx, cy, body);
            case WELCOME -> renderWelcome(g, f, x, y, w, h, cx, cy, body);
            case SAVER -> renderSaver(g, f, x, y, w, h, cx);
            default -> {}
        }
    }

    private void renderBoot(GuiGraphics g, Font f, int x, int y, int w, int h, int cx, int cy, int body, float partial) {
        g.fillGradient(x, y, x + w, y + h, 0xFF120C1A, 0xFF241838);
        float tt = t + partial;
        // logo: a heart that gently beats
        int s = (Math.sin(tt / 7.0) > 0.6) ? 6 : 5;
        int hw = 7 * s;
        heart(g, cx - hw / 2, cy - 48, s, 0xFFFFB3D9);
        g.fill(cx - hw / 2, cy - 48, cx - hw / 2 + 2 * s, cy - 48 + s, 0x66FFFFFF);
        g.drawCenteredString(f, Component.translatable("cutemod.os.title"), cx, cy - 8, 0xFFFFFFFF);

        // progress bar: it speeds up and stalls a little, like a real boot
        float p = Math.min(1f, tt / BOOT_TICKS);
        p = p * p * (3 - 2 * p);
        int bw = 120, bx = cx - bw / 2, by = cy + 8;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 7, 0xFF5A4A72);
        g.fill(bx, by, bx + bw, by + 6, 0xFF1B1422);
        int fill = (int) (bw * p);
        g.fill(bx, by, bx + fill, by + 6, accent(body));
        g.fill(bx, by, bx + fill, by + 2, 0x55FFFFFF);

        String[] msgs = {"cutemod.os.boot.m0", "cutemod.os.boot.m1", "cutemod.os.boot.m2"};
        int mi = Math.min(msgs.length - 1, (int) (p * msgs.length));
        centered(g, f, Component.translatable(msgs[mi]).getString(), cx, by + 14, 0xFFBFB2D6);
        if (t > 15) centered(g, f, Component.translatable("cutemod.os.boot.skip").getString(), cx, y + h - 12, 0x77BFB2D6);
    }

    /** Pastel pink-ish accent that follows the computer color a little. */
    private static int accent(int body) {
        return App.mix(body, 0xFFB3D9, 0.55f);
    }

    private void renderLock(GuiGraphics g, Font f, int x, int y, int w, int h, int cx, int cy, int body) {
        Wallpaper.draw(g, x, y, w, h, body, Wallpaper.get());
        g.fill(x, y, x + w, y + h, 0xB0140E1C);

        // avatar
        int ay = cy - 36;
        disc(g, cx, ay, 22, 0xFFFFFFFF);
        disc(g, cx, ay, 20, App.mix(body, 0xFFFFFF, 0.2f));
        heart(g, cx - 10, ay - 8, 3, 0xFFFFFFFF);
        centered(g, f, playerName(), cx, ay + 28, 0xFFFFFFFF);

        // password field (shakes when wrong)
        int off = shake > 0 ? (int) Math.round(Math.sin(shake * 1.3) * 4) : 0;
        int fw = 128, fx = cx - fw / 2 + off, fy = ay + 42;
        g.fill(fx - 1, fy - 1, fx + fw + 1, fy + 15, wrong ? 0xFFFF6B6B : 0xFFB9B0C8);
        g.fill(fx, fy, fx + fw, fy + 14, 0xFFF4EFF8);
        if (input.length() == 0) {
            g.drawString(f, Component.translatable("cutemod.os.lock.prompt"), fx + 5, fy + 3, 0xFF9A90A8, false);
        } else {
            String dots = "•".repeat(input.length());
            while (f.width(dots) > fw - 12) dots = dots.substring(1);
            g.drawString(f, dots, fx + 5, fy + 3, 0xFF3A2A3A, false);
        }
        if ((t / 25) % 2 == 0) {                                       // blinking cursor
            String dots = "•".repeat(Math.min(input.length(), 40));
            int cxp = fx + 5 + Math.min(f.width(dots), fw - 12) + 1;
            g.fill(cxp, fy + 2, cxp + 1, fy + 12, 0xFF3A2A3A);
        }
        if (wrong) centered(g, f, Component.translatable("cutemod.os.lock.wrong").getString(), cx, fy + 20, 0xFFFF8F8F);
        else centered(g, f, Component.translatable("cutemod.os.lock.enter").getString(), cx, fy + 20, 0x99FFFFFF);
    }

    private static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    private void renderWelcome(GuiGraphics g, Font f, int x, int y, int w, int h, int cx, int cy, int body) {
        Wallpaper.draw(g, x, y, w, h, body, Wallpaper.get());
        // the whole splash fades in, stays and fades out, revealing the desktop
        float a = t < 20 ? t / 20f : (t > WELCOME_TICKS - 25 ? (WELCOME_TICKS - t) / 25f : 1f);
        g.fill(x, y, x + w, y + h, alpha(0x140E1C, 0.45f + 0.5f * a));
        int s = 4;
        heart(g, cx - 14, cy - 30, s, alpha(0xFFB3D9, a));
        String msg = Component.translatable("cutemod.os.welcome", playerName()).getString();
        g.drawString(f, msg, cx - f.width(msg) / 2, cy + 2, alpha(0xFFFFFF, a), false);
    }

    private void renderSaver(GuiGraphics g, Font f, int x, int y, int w, int h, int cx) {
        g.fill(x, y, x + w, y + h, 0xFF05030A);
        // twinkling stars
        for (int i = 0; i < 28; i++) {
            int sx = x + (i * 97 + 13) % w, sy = y + (i * 53 + 7) % h;
            if (((t / 12) + i) % 5 != 0) g.fill(sx, sy, sx + 1, sy + 1, 0xFF8F86AA);
        }
        // a heart that bounces around (the DVD logo classic)
        int s = 3, hw = 7 * s, hh = 6 * s;
        hx += vx;
        hy += vy;
        if (hx < 0) { hx = 0; vx = Math.abs(vx); }
        if (hx > w - hw) { hx = w - hw; vx = -Math.abs(vx); }
        if (hy < 0) { hy = 0; vy = Math.abs(vy); }
        if (hy > h - hh) { hy = h - hh; vy = -Math.abs(vy); }
        int[] cols = {0xFFFFB3D9, 0xFFB3E0FF, 0xFFFFE680, 0xFFC9B3FF};
        heart(g, x + (int) hx, y + (int) hy, s, cols[(t / 120) % cols.length]);
        centered(g, f, Component.translatable("cutemod.os.saver.hint").getString(), cx, y + h - 12, 0x66FFFFFF);
    }
}
