package dev.cutemod.client;

import dev.cutemod.ComputerColor;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Kept in a separate class so the dedicated server never loads client-only code. */
public class ClientHooks {
    public static void openComputer(ComputerColor color, BlockPos pos) {
        Minecraft.getInstance().setScreen(new ComputerScreen(color, pos));
    }

    private ClientHooks() {}
}
