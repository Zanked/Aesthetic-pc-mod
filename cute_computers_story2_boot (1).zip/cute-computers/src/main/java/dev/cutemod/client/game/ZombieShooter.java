package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * "Zombie Shooter": a simple first-person wave shooter in the style of Call of Duty Zombies.
 * One small arena, endless rounds, points for hits and kills, a wall station to buy a rifle and ammo.
 * Same "one ray per screen column" raycaster as Dark Corridor.
 *
 * Controls: W/S walk, A/D strafe, mouse near the left/right edge or arrow keys to turn,
 * LMB or Space to shoot, R reload, 1/2/Q switch weapon, E buy at the golden wall.
 */
public class ZombieShooter extends MiniGame {
    private static final int N = 17;
    private static final int COLS = 110, CW = W / COLS;
    private static final double PLANE = 0.75;
    private static final int RIFLE_COST = 500, AMMO_COST = 250;

    private static final String[] LEVEL = {
            "########S########",
            "#...............#",
            "#...............#",
            "#...cc.....cc...#",
            "#...............#",
            "#...............#",
            "#......c.c......#",
            "#...............#",
            "#...c.......c...#",
            "#...............#",
            "#......c.c......#",
            "#...............#",
            "#...............#",
            "#...cc.....cc...#",
            "#...............#",
            "#...............#",
            "#################"};
    private static final int[][] SPAWNS = {{2, 2}, {14, 2}, {2, 14}, {14, 14}, {8, 15}, {8, 2}};
    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    /** A blocky zombie, one char = one pixel. g/G skin, b shirt, p trousers, r eyes, k shoes. */
    private static final String[] ZOMBIE = {
            "..GGGG..", ".gggggg.", ".grggrg.", ".gggggg.", "..gggg..", "bbbbbbbb", "gbbbbbbg", "gbbbbbbg",
            "gbbbbbbg", ".bbbbbb.", ".bbbbbb.", ".pppppp.", ".pp..pp.", ".pp..pp.", ".pp..pp.", ".kk..kk."};

    private static final class Weapon {
        final boolean auto, infinite;
        final int magSize, maxReserve, dmg, rate, reloadTime;
        int mag, reserve;

        Weapon(boolean auto, boolean infinite, int magSize, int reserve, int dmg, int rate, int reloadTime) {
            this.auto = auto; this.infinite = infinite; this.magSize = magSize; this.maxReserve = reserve;
            this.dmg = dmg; this.rate = rate; this.reloadTime = reloadTime;
            this.mag = magSize; this.reserve = reserve;
        }
    }

    private static final class Zombie {
        double x, y, speed;
        int hp, cool, flash;
        Zombie(double x, double y, int hp, double speed) { this.x = x; this.y = y; this.hp = hp; this.speed = speed; }
    }

    private final int[][] map = new int[N][N];     // 0 floor, 1 wall, 2 crate, 3 station
    private final double[] zbuf = new double[COLS];
    private final int[][] flow = new int[N][N];
    private final List<Zombie> zombies = new ArrayList<>();
    private final Weapon pistol = new Weapon(false, true, 8, 0, 2, 16, 70);
    private final Weapon rifle = new Weapon(true, false, 30, 120, 3, 6, 100);

    private double px, py, ang, hp;
    private Weapon cur;
    private boolean hasRifle, trigPrev;
    private int round, toSpawn, spawned, spawnT, breakT, kills, points;
    private int cool, reload, kick, flashT, hit, hurtT, noHurt, ticks, msgT, walkT;
    private String msg = "";
    private double lastDist, lastWallX;
    private int lastType;
    private boolean lastSide;

    // ---------- setup ----------
    @Override
    public void reset() {
        score = 0; over = false; round = 1; kills = 0; points = 0; ticks = 0; msgT = 0; breakT = 0;
        hp = 100; hurtT = 0; noHurt = 0; kick = 0; flashT = 0; hit = 0; reload = 0; cool = 40; walkT = 0;
        hasRifle = false; trigPrev = true;
        pistol.mag = pistol.magSize;
        rifle.mag = rifle.magSize; rifle.reserve = rifle.maxReserve;
        cur = pistol;
        zombies.clear();
        for (int y = 0; y < N; y++) for (int x = 0; x < N; x++) {
            char c = LEVEL[y].charAt(x);
            map[y][x] = c == '#' ? 1 : c == 'c' ? 2 : c == 'S' ? 3 : 0;
        }
        px = 8.5; py = 8.5; ang = Math.PI / 2;
        startRound();
        say("cutemod.zombies.start");
    }

    private void startRound() {
        toSpawn = 5 + 3 * round;
        spawned = 0;
        spawnT = 90;
        say("cutemod.zombies.round", round);
    }

    private void say(String key, Object... args) {
        msg = Component.translatable(key, args).getString();
        msgT = 150;
    }

    // ---------- helpers ----------
    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private static boolean lmb() {
        return GLFW.glfwGetMouseButton(Minecraft.getInstance().getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    private static void snd(SoundEvent e, float pitch, float vol) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(e, pitch, vol));
    }

    private static void snd(Holder<SoundEvent> h, float pitch, float vol) { snd(h.value(), pitch, vol); }

    private void earn(int n) { points += n; score += n; }

    private boolean free(double x, double y) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        return ix >= 0 && iy >= 0 && ix < N && iy < N && map[iy][ix] == 0;
    }

    private void move(double dx, double dy) {
        double r = 0.22;
        if (free(px + dx + Math.signum(dx) * r, py)) px += dx;
        if (free(px, py + dy + Math.signum(dy) * r)) py += dy;
    }

    /** Distance to the first wall along a direction (also remembers which wall it was). */
    private double ray(double a) {
        double rdx = Math.cos(a), rdy = Math.sin(a);
        int mapX = (int) px, mapY = (int) py;
        double ddx = Math.abs(1 / rdx), ddy = Math.abs(1 / rdy), sdx, sdy;
        int stepX, stepY;
        if (rdx < 0) { stepX = -1; sdx = (px - mapX) * ddx; } else { stepX = 1; sdx = (mapX + 1 - px) * ddx; }
        if (rdy < 0) { stepY = -1; sdy = (py - mapY) * ddy; } else { stepY = 1; sdy = (mapY + 1 - py) * ddy; }
        boolean side = false;
        while (map[mapY][mapX] == 0) {
            if (sdx < sdy) { sdx += ddx; mapX += stepX; side = false; }
            else { sdy += ddy; mapY += stepY; side = true; }
        }
        double dist = Math.max(0.05, side ? sdy - ddy : sdx - ddx);
        lastType = map[mapY][mapX];
        lastSide = side;
        double wx = side ? px + dist * rdx : py + dist * rdy;
        lastWallX = wx - Math.floor(wx);
        return dist;
    }

    // ---------- shooting ----------
    private void fire() {
        if (reload > 0 || cool > 0) return;
        if (cur.mag <= 0) { startReload(); return; }
        cur.mag--;
        cool = cur.rate;
        kick = cur == rifle ? 4 : 7;
        flashT = 3;
        snd(SoundEvents.ARROW_SHOOT, cur == rifle ? 1.9F : 1.5F, 0.6F);

        double wall = ray(ang), bestD = 1e9;
        Zombie best = null;
        double c = Math.cos(ang), s = Math.sin(ang);
        for (Zombie z : zombies) {
            double dx = z.x - px, dy = z.y - py;
            double f = dx * c + dy * s;
            if (f < 0.1 || f > wall || f >= bestD) continue;
            if (Math.abs(-dx * s + dy * c) < 0.3) { best = z; bestD = f; }
        }
        if (best != null) {
            best.hp -= cur.dmg;
            best.flash = 6;
            hit = 8;
            earn(10);
            if (best.hp <= 0) {
                zombies.remove(best);
                kills++;
                earn(60);
                snd(SoundEvents.ZOMBIE_DEATH, 1.0F, 0.6F);
            } else {
                snd(SoundEvents.ZOMBIE_HURT, 1.2F, 0.5F);
            }
        }
        if (cur.mag == 0) startReload();
    }

    private void startReload() {
        if (reload > 0 || cur.mag >= cur.magSize || (!cur.infinite && cur.reserve <= 0)) return;
        reload = cur.reloadTime;
        snd(SoundEvents.UI_BUTTON_CLICK, 0.6F, 0.7F);
    }

    private void finishReload() {
        int need = cur.magSize - cur.mag;
        int take = cur.infinite ? need : Math.min(need, cur.reserve);
        cur.mag += take;
        if (!cur.infinite) cur.reserve -= take;
        snd(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.7F);
    }

    private void select(Weapon w) {
        if (w == rifle && !hasRifle) return;
        if (cur != w) { cur = w; reload = 0; cool = 12; }
    }

    private boolean nearStation() {
        return Math.hypot(px - 8.5, py - 1.0) < 2.2;
    }

    private void buy() {
        if (!nearStation()) return;
        if (!hasRifle) {
            if (points < RIFLE_COST) { say("cutemod.zombies.poor"); beep(); return; }
            points -= RIFLE_COST;
            hasRifle = true;
            select(rifle);
            say("cutemod.zombies.bought");
            pling(1.6F);
        } else {
            if (rifle.reserve >= rifle.maxReserve && rifle.mag >= rifle.magSize) { say("cutemod.zombies.full"); return; }
            if (points < AMMO_COST) { say("cutemod.zombies.poor"); beep(); return; }
            points -= AMMO_COST;
            rifle.reserve = rifle.maxReserve;
            rifle.mag = rifle.magSize;
            say("cutemod.zombies.ammo");
            pling(1.3F);
        }
    }

    @Override
    public boolean key(int k) {
        switch (k) {
            case 82 -> startReload();                                  // R
            case 69 -> buy();                                          // E
            case 49 -> select(pistol);                                 // 1
            case 50 -> select(rifle);                                  // 2
            case 81 -> select(cur == pistol ? rifle : pistol);         // Q
            default -> { return false; }
        }
        return true;
    }

    // ---------- tick ----------
    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        if (cool > 0) cool--;
        if (kick > 0) kick--;
        if (flashT > 0) flashT--;
        if (hit > 0) hit--;
        if (hurtT > 0) hurtT--;
        if (reload > 0 && --reload == 0) finishReload();

        // --- turning: arrow keys, or the mouse close to the left / right edge ---
        double turn = (down(KEY_RIGHT) ? 1 : 0) - (down(KEY_LEFT) ? 1 : 0);
        ang += turn * 0.045;
        if (mx >= 0 && mx < W && my >= 0 && my < H) {
            double nx = (mx - W / 2.0) / (W / 2.0);
            if (Math.abs(nx) > 0.2) ang += (nx - Math.signum(nx) * 0.2) * 0.07;
        }
        // --- walking ---
        double fwd = (down(87) ? 1 : 0) - (down(83) ? 0.75 : 0);
        double str = (down(68) ? 1 : 0) - (down(65) ? 1 : 0);
        double c = Math.cos(ang), s = Math.sin(ang);
        move((c * fwd - s * str) * 0.045, (s * fwd + c * str) * 0.045);
        if (fwd != 0 || str != 0) walkT++;

        // --- trigger ---
        boolean trig = lmb() || down(KEY_SPACE);
        if (trig && (cur.auto || !trigPrev)) fire();
        trigPrev = trig;

        // --- waves ---
        if (breakT > 0) {
            if (--breakT == 0) { round++; startRound(); }
        } else {
            int cap = Math.min(14, 6 + round);
            if (spawned < toSpawn && zombies.size() < cap && --spawnT <= 0) {
                spawnT = Math.max(30, 100 - round * 6);
                spawnZombie();
            }
            if (spawned >= toSpawn && zombies.isEmpty()) {
                earn(100);
                breakT = 300;
                say("cutemod.zombies.clear");
                pling(1.9F);
            }
        }

        // --- zombies ---
        if (ticks % 8 == 0) buildFlow();
        for (Zombie z : zombies) {
            if (z.flash > 0) z.flash--;
            moveZombie(z);
            if (Math.hypot(z.x - px, z.y - py) < 0.75) {
                if (--z.cool <= 0) {
                    z.cool = 50;
                    hp -= 25;
                    hurtT = 14;
                    noHurt = 0;
                    snd(SoundEvents.PLAYER_HURT, 1.0F, 0.7F);
                }
            } else if (z.cool > 0) z.cool--;
        }
        for (int i = 0; i < zombies.size(); i++) {           // keep them from stacking on one spot
            for (int j = i + 1; j < zombies.size(); j++) {
                Zombie a = zombies.get(i), b = zombies.get(j);
                double dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy);
                if (d < 0.45 && d > 0.001) {
                    double push = (0.45 - d) * 0.25;
                    if (free(a.x - dx / d * push, a.y)) a.x -= dx / d * push;
                    if (free(a.x, a.y - dy / d * push)) a.y -= dy / d * push;
                    if (free(b.x + dx / d * push, b.y)) b.x += dx / d * push;
                    if (free(b.x, b.y + dy / d * push)) b.y += dy / d * push;
                }
            }
        }
        if (!zombies.isEmpty() && rnd.nextInt(380) == 0) snd(SoundEvents.ZOMBIE_AMBIENT, 0.7F + rnd.nextFloat() * 0.5F, 0.4F);

        // --- health comes back if you are not hit for a while ---
        if (++noHurt > 360 && hp < 100) hp = Math.min(100, hp + 0.25);
        if (hp <= 0) { over = true; beep(); snd(SoundEvents.ZOMBIE_VILLAGER_CONVERTED, 0.8F, 0.6F); }
    }

    private void spawnZombie() {
        int[] best = null;
        int tries = 0;
        while (tries++ < 12) {
            int[] sp = SPAWNS[rnd.nextInt(SPAWNS.length)];
            if (Math.hypot(sp[0] + 0.5 - px, sp[1] + 0.5 - py) >= 6) { best = sp; break; }
        }
        if (best == null) best = SPAWNS[rnd.nextInt(SPAWNS.length)];
        int hpz = 3 + 2 * (round - 1);
        double sp = Math.min(0.03, 0.012 + 0.0012 * round) * (0.85 + rnd.nextDouble() * 0.3);
        zombies.add(new Zombie(best[0] + 0.5, best[1] + 0.5, hpz, sp));
        spawned++;
    }

    /** Distance (in tiles) from every floor tile to the player. Zombies walk "downhill". */
    private void buildFlow() {
        for (int[] r : flow) Arrays.fill(r, -1);
        ArrayDeque<int[]> q = new ArrayDeque<>();
        int sx = Math.max(1, Math.min(N - 2, (int) px)), sy = Math.max(1, Math.min(N - 2, (int) py));
        flow[sy][sx] = 0;
        q.add(new int[]{sx, sy});
        while (!q.isEmpty()) {
            int[] c = q.poll();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0], ny = c[1] + d[1];
                if (nx >= 0 && ny >= 0 && nx < N && ny < N && map[ny][nx] == 0 && flow[ny][nx] < 0) {
                    flow[ny][nx] = flow[c[1]][c[0]] + 1;
                    q.add(new int[]{nx, ny});
                }
            }
        }
    }

    private void moveZombie(Zombie z) {
        int cx = (int) z.x, cy = (int) z.y;
        double tx = px, ty = py;
        boolean direct = cx == (int) px && cy == (int) py || Math.hypot(z.x - px, z.y - py) < 1.3;
        if (!direct && cx >= 0 && cy >= 0 && cx < N && cy < N && flow[cy][cx] >= 0) {
            int best = flow[cy][cx];
            tx = cx + 0.5; ty = cy + 0.5;
            for (int[] d : DIRS) {
                int nx = cx + d[0], ny = cy + d[1];
                if (nx >= 0 && ny >= 0 && nx < N && ny < N && map[ny][nx] == 0 && flow[ny][nx] >= 0 && flow[ny][nx] < best) {
                    best = flow[ny][nx];
                    tx = nx + 0.5; ty = ny + 0.5;
                }
            }
        }
        double dx = tx - z.x, dy = ty - z.y, d = Math.hypot(dx, dy);
        if (d < 0.001) return;
        double step = Math.min(z.speed, d);
        double nx = z.x + dx / d * step, ny = z.y + dy / d * step;
        if (free(nx, z.y)) z.x = nx;
        if (free(z.x, ny)) z.y = ny;
    }

    // ---------- drawing ----------
    private static int shade(int rgb, double b) {
        b = Math.max(0, Math.min(1.5, b));
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * b));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * b));
        int bl = Math.min(255, (int) ((rgb & 255) * b));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int pal(char c, boolean flash) {
        int col = switch (c) {
            case 'G' -> 0xFF3F7F34;
            case 'g' -> 0xFF5FA84A;
            case 'b' -> 0xFF2AA6B0;
            case 'p' -> 0xFF3A3A8A;
            case 'r' -> 0xFFFF3030;
            case 'k' -> 0xFF222222;
            default -> 0xFF222222;
        };
        return flash ? 0xFFFFE0E0 : col;
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H / 2, 0xFF0E121A, 0xFF252E3C);     // ceiling (night sky)
        g.fillGradient(0, H / 2, W, H, 0xFF2A2420, 0xFF4E4438);     // floor
        double dirX = Math.cos(ang), dirY = Math.sin(ang), plX = -dirY * PLANE, plY = dirX * PLANE;

        for (int col = 0; col < COLS; col++) {
            double cam = 2.0 * (col + 0.5) / COLS - 1;
            double a = Math.atan2(dirY + plY * cam, dirX + plX * cam);
            double raw = ray(a);
            double dist = Math.max(0.05, raw * Math.cos(a - ang));          // fix the fish-eye effect
            zbuf[col] = dist;
            int base = lastType == 3 ? 0xFFD8B04A : lastType == 2 ? 0xFF9A6B3A : 0xFF8A8A92;
            double b = 1.0 * Math.max(0.12, 1 - dist / 9.5) * (lastSide ? 0.75 : 1);
            if (lastType == 2 && ((int) (lastWallX * 6) % 2 == 0)) b *= 0.82;                     // crate planks
            if (lastType == 1 && ((int) (lastWallX * 8) % 4 == 0)) b *= 0.85;                     // brick joints
            int lh = (int) (H / dist), y0 = Math.max(0, H / 2 - lh / 2), y1 = Math.min(H, H / 2 + lh / 2);
            rect(g, col * CW, y0, CW, y1 - y0, shade(base, b));
        }

        // zombies, far ones first
        List<Zombie> order = new ArrayList<>(zombies);
        order.sort((a, b) -> Double.compare(Math.hypot(b.x - px, b.y - py), Math.hypot(a.x - px, a.y - py)));
        for (Zombie z : order) sprite(g, z);

        // red flash / vignette when hurt or low on health
        double missing = 1 - hp / 100.0;
        int alpha = (int) Math.min(150, missing * 110 + hurtT * 6);
        if (alpha > 4) rect(g, 0, 0, W, H, (alpha << 24) | 0xB00000);
        if (breakT > 0 && breakT < 90 && ticks % 20 < 10) ctext(g, Component.translatable("cutemod.zombies.next").getString(), W / 2, 30, 0xFFFFE9A0);

        weaponAndHud(g);
        if (over) rect(g, 0, 0, W, H, 0x80900000);
    }

    private void sprite(GuiGraphics g, Zombie z) {
        double rx = z.x - px, ry = z.y - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);
        if (f < 0.2) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f), sh = (int) (full * 0.9), sw = sh * ZOMBIE[0].length() / ZOMBIE.length;
        int left = (int) (W / 2.0 * (1 + cam)) - sw / 2, top = H / 2 + full / 2 - sh;
        top += (int) (Math.sin(ticks * 0.15 + z.x * 7) * full * 0.015);               // shambling
        double b = Math.max(0.22, 1 - f / 9.5);
        boolean flash = z.flash > 0;
        for (int x = Math.floorDiv(left, CW) * CW; x < left + sw; x += CW) {
            int c = x / CW;
            if (x < 0 || c >= COLS || f >= zbuf[c]) continue;
            int u = Math.max(0, Math.min(ZOMBIE[0].length() - 1, (x + CW / 2 - left) * ZOMBIE[0].length() / sw));
            for (int row = 0; row < ZOMBIE.length; row++) {
                char ch = ZOMBIE[row].charAt(u);
                if (ch == '.') continue;
                int y0 = top + row * sh / ZOMBIE.length, y1 = Math.max(y0 + 1, top + (row + 1) * sh / ZOMBIE.length);
                rect(g, x, y0, CW, y1 - y0, shade(pal(ch, flash), ch == 'r' ? 1.2 : b));
            }
        }
        // health bar over the head when it is hurt
        int maxHp = 3 + 2 * (round - 1);
        if (z.hp < maxHp && f < 6) {
            int bw = Math.max(6, sw), bx = left + sw / 2 - bw / 2;
            rect(g, bx, top - 4, bw, 2, 0xAA000000);
            rect(g, bx, top - 4, Math.max(0, bw * z.hp / maxHp), 2, 0xFFE03A3A);
        }
    }

    private void weaponAndHud(GuiGraphics g) {
        // crosshair + hit marker
        int cx = W / 2, cy = H / 2;
        int cc = hit > 0 ? 0xFFFF4040 : 0xE0FFFFFF;
        rect(g, cx - 5, cy, 3, 1, cc); rect(g, cx + 3, cy, 3, 1, cc);
        rect(g, cx, cy - 5, 1, 3, cc); rect(g, cx, cy + 3, 1, 3, cc);
        if (hit > 0) { rect(g, cx - 3, cy - 3, 1, 1, 0xFFFF4040); rect(g, cx + 3, cy - 3, 1, 1, 0xFFFF4040);
                       rect(g, cx - 3, cy + 3, 1, 1, 0xFFFF4040); rect(g, cx + 3, cy + 3, 1, 1, 0xFFFF4040); }

        // the gun (bobs while walking, kicks when shooting, drops while reloading)
        int bobX = (int) (Math.sin(walkT * 0.2) * 2), bobY = (int) (Math.abs(Math.cos(walkT * 0.2)) * 2);
        int gx = W / 2 + 22 + bobX, gy = H - 34 + bobY + kick + (reload > 0 ? 14 : 0);
        if (cur == pistol) {
            rect(g, gx - 5, gy + 10, 9, 16, 0xFF2E2E36);
            rect(g, gx - 7, gy, 13, 11, 0xFF55555F);
            rect(g, gx - 7, gy, 13, 2, 0xFF7A7A86);
            rect(g, gx - 3, gy - 5, 5, 6, 0xFF44444E);
        } else {
            rect(g, gx - 4, gy + 12, 8, 20, 0xFF2E2E36);
            rect(g, gx - 8, gy - 4, 16, 18, 0xFF3F4A38);
            rect(g, gx - 3, gy - 14, 6, 12, 0xFF2A2A30);
            rect(g, gx - 8, gy - 4, 16, 2, 0xFF5E6B54);
        }
        if (flashT > 0) {
            int fy = gy - (cur == rifle ? 18 : 9);
            rect(g, gx - 5, fy - 5, 10, 8, 0xFFFFD84A);
            rect(g, gx - 2, fy - 8, 4, 12, 0xFFFFFFFF);
        }

        // HUD
        rect(g, 4, H - 10, 62, 6, 0xAA000000);
        rect(g, 5, H - 9, (int) (60 * Math.max(0, hp) / 100), 4, hp > 40 ? 0xFF5FD35A : 0xFFE03A3A);
        String ammo = cur.mag + "/" + (cur.infinite ? "--" : String.valueOf(cur.reserve));
        text(g, ammo, W - 6 - font().width(ammo), H - 11, reload > 0 ? 0xFFFFD866 : 0xFFFFFFFF);
        text(g, Component.translatable("cutemod.zombies.round_hud", round).getString(), 5, 4, 0xFFFFE9A0);
        String pts = Component.translatable("cutemod.zombies.points", points).getString();
        text(g, pts, W - 5 - font().width(pts), 4, 0xFFFFD866);
        if (reload > 0) ctext(g, Component.translatable("cutemod.zombies.reload").getString(), W / 2, H / 2 + 12, 0xFFFFD866);
        if (nearStation()) {
            String p = Component.translatable(hasRifle ? "cutemod.zombies.buy_ammo" : "cutemod.zombies.buy_rifle",
                    hasRifle ? AMMO_COST : RIFLE_COST).getString();
            ctext(g, p, W / 2, H - 24, 0xFFFFE9A0);
        }
        if (msgT > 0) ctext(g, msg, W / 2, 16, msgT < 30 ? 0xFFB0A070 : 0xFFFFFFFF);
    }

    @Override
    public String hintKey() { return "cutemod.hint.zombies"; }

    @Override
    public Component status() { return Component.translatable("cutemod.zombies.status", round, kills, score); }

    @Override
    public Component endTitle() { return Component.translatable("cutemod.zombies.end", round); }
}
