package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * The Dock: a glass strip with the app icons. The icon under the mouse (and its neighbours) grows,
 * the app that is running has a little dot below it.
 */
public class Dock {
    public static final int HEIGHT = 28;
    private static final int BASE = 15, MAX = 28, GAP = 2, RADIUS = 38, PILL_H = 24;

    private final float[] size = new float[Desktop.ICONS];
    private final float[] x = new float[Desktop.ICONS];
    private int bx, by, bw, bottom;
    private float pillX0, pillX1;

    /** Recompute where every icon is for the given mouse position (the box is the Dock area on screen). */
    private void layout(int bx, int by, int bw, int mx, int my) {
        this.bx = bx; this.by = by; this.bw = bw;
        this.bottom = by + HEIGHT - 5;
        boolean near = mx >= bx && mx < bx + bw && my >= by - 16 && my < by + HEIGHT;
        int n = Desktop.ICONS;
        float baseTotal = n * BASE + (n - 1) * GAP, start = bx + (bw - baseTotal) / 2f, total = (n - 1) * GAP;
        for (int i = 0; i < n; i++) {
            float cx = start + i * (BASE + GAP) + BASE / 2f;
            float f = near ? Math.max(0f, 1f - Math.abs(mx - cx) / RADIUS) : 0f;
            f = f * f * (3 - 2 * f);
            size[i] = BASE + (MAX - BASE) * f;
            total += size[i];
        }
        float px = bx + (bw - total) / 2f;
        pillX0 = px - 8;
        for (int i = 0; i < n; i++) { x[i] = px; px += size[i] + GAP; }
        pillX1 = px - GAP + 8;
    }

    /** Index of the icon under the mouse, or -1. */
    public int hit(int bx, int by, int bw, int mx, int my) {
        layout(bx, by, bw, mx, my);
        for (int i = 0; i < Desktop.ICONS; i++) {
            if (mx >= x[i] && mx < x[i] + size[i] && my >= bottom - size[i] && my < bottom + 4) return i;
        }
        return -1;
    }

    public void render(GuiGraphics g, Desktop desktop, App current, int body, int bx, int by, int bw, int mx, int my) {
        layout(bx, by, bw, mx, my);
        int active = desktop.activeIndex(current);

        // the glass pill
        int y0 = by + HEIGHT - 1 - PILL_H, y1 = by + HEIGHT - 1;
        pill(g, Math.round(pillX0) - 1, y0 - 1, Math.round(pillX1) + 1, y1 + 1, 0x33FFFFFF);
        pill(g, Math.round(pillX0), y0, Math.round(pillX1), y1, 0x88202030);

        int hovered = -1;
        for (int i = 0; i < Desktop.ICONS; i++) {
            float s = size[i], top = bottom - s;
            g.pose().pushPose();
            g.pose().translate(x[i], top, 0);
            g.pose().scale(s / 32f, s / 32f, 1f);
            Desktop.drawIcon(g, i, 0, 0, body);
            g.pose().popPose();
            if (i == active) g.fill(Math.round(x[i] + s / 2f) - 1, by + HEIGHT - 3, Math.round(x[i] + s / 2f) + 1, by + HEIGHT - 1, 0xFFFFFFFF);
            int b = desktop.badge(i);
            if (b > 0) {
                String n = b > 9 ? "9+" : Integer.toString(b);
                var font = Minecraft.getInstance().font;
                int r = Math.max(4, font.width(n) / 2 + 2), cx = Math.round(x[i] + s) - 2, cy = Math.round(top) + 2;
                g.pose().pushPose();
                g.pose().translate(0, 0, 50);
                g.fill(cx - r - 1, cy - 5, cx + r + 1, cy + 5, 0xFFFFFFFF);
                g.fill(cx - r, cy - 4, cx + r, cy + 4, 0xFFE5484D);
                g.pose().pushPose();
                g.pose().translate(cx - font.width(n) / 4f, cy - 3, 0);
                g.pose().scale(0.5f, 0.5f, 1f);
                g.drawString(font, n, 0, 0, 0xFFFFFFFF, false);
                g.pose().popPose();
                g.pose().popPose();
            }
            if (mx >= x[i] && mx < x[i] + s && my >= top && my < bottom + 4) hovered = i;
        }

        // label above the icon under the mouse
        if (hovered >= 0) {
            String label = desktop.label(hovered);
            var font = Minecraft.getInstance().font;
            int w = font.width(label) + 8, cx = Math.round(x[hovered] + size[hovered] / 2f);
            int lx = Math.max(bx + 2, Math.min(bx + bw - w - 2, cx - w / 2)), ly = Math.round(bottom - size[hovered]) - 14;
            pill(g, lx, ly, lx + w, ly + 12, 0xEE1B1422);
            g.drawString(font, label, lx + 4, ly + 2, 0xFFFFFFFF, false);
        }
    }

    /** A rectangle with rounded corners (no overlapping fills, so translucent colors stay even). */
    private static void pill(GuiGraphics g, int x0, int y0, int x1, int y1, int argb) {
        g.fill(x0 + 2, y0, x1 - 2, y0 + 1, argb);
        g.fill(x0 + 1, y0 + 1, x1 - 1, y0 + 2, argb);
        g.fill(x0, y0 + 2, x1, y1 - 2, argb);
        g.fill(x0 + 1, y1 - 2, x1 - 1, y1 - 1, argb);
        g.fill(x0 + 2, y1 - 1, x1 - 2, y1, argb);
    }
}
