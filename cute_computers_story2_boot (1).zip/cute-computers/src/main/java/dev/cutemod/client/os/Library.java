package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * The catalog of CuteStore and what the player owns: bought games, installs (they take a few seconds
 * of real time, even when the computer screen is closed), play time and best scores.
 * Saved in cutemod_library.txt. Coins are handled by {@link Progress}.
 */
public final class Library {
    private Library() {}

    /** One game in the store. rating is x10 (47 = 4.7), size in MB. */
    public record Game(String id, int price, String genre, int sizeMb, int rating, int rgb) {}

    public static final List<Game> GAMES = List.of(
            new Game("pink", 15, "arcade", 12, 38, 0xF4A7C3),
            new Game("green", 20, "puzzle", 18, 44, 0x8FD39A),
            new Game("white", 15, "arcade", 9, 41, 0xE8EAF0),
            new Game("blue", 20, "arcade", 14, 40, 0x8EC3F2),
            new Game("orange", 15, "puzzle", 11, 36, 0xF5B06B),
            new Game("purple", 20, "arcade", 10, 39, 0x4A3A66),
            new Game("yellow", 15, "arcade", 8, 35, 0xF3D46A),
            new Game("red", 25, "puzzle", 22, 43, 0xE27B72),
            new Game("breakout", 25, "arcade", 16, 42, 0xC98B5A),
            new Game("cubes", 30, "puzzle", 20, 47, 0xB57BD6),
            new Game("pong", 25, "arcade", 13, 37, 0x7ED957),
            new Game("bees", 35, "arcade", 27, 41, 0xF5C518),
            new Game("horror", 40, "horror", 45, 46, 0x8B1A2B),
            new Game("maze", 60, "horror", 70, 48, 0x5A2A6A),
            new Game("craft", 90, "sandbox", 120, 49, 0x5BBF4A),
            new Game("zombies", 80, "shooter", 95, 47, 0x4F8F3A),
            new Game("durak", 45, "cards", 15, 45, 0x2E7D4F),
            new Game("sakura", 35, "anime", 24, 46, 0xF58FB8),
            new Game("blocks", 40, "puzzle", 10, 47, 0x6A8FE0));

    public static final int DEAL_PERCENT = 30;
    public static final int WELCOME_COINS = 100;

    private static boolean loaded, dirty, welcomed;
    private static int saveDelay;
    private static final Set<String> owned = new HashSet<>();
    private static final Set<String> notified = new HashSet<>();
    private static final Map<String, Long> installStart = new HashMap<>();
    private static final Map<String, Integer> playSeconds = new HashMap<>();
    private static final Map<String, Integer> best = new HashMap<>();
    private static final Map<String, Integer> reviewStars = new HashMap<>();
    private static final Map<String, String> reviewText = new HashMap<>();

    // ---------- catalog ----------
    public static Game game(String id) {
        for (Game g : GAMES) if (g.id().equals(id)) return g;
        return GAMES.get(0);
    }

    public static String name(String id) { return Component.translatable("cutemod.game." + id).getString(); }

    /** The game on sale today (the same for everybody, changes every day). */
    public static String dealId() {
        long day = System.currentTimeMillis() / 86_400_000L;
        return GAMES.get((int) Math.floorMod(day * 7 + 3, (long) GAMES.size())).id();
    }

    public static int priceNow(String id) {
        int p = game(id).price();
        return id.equals(dealId()) ? Math.max(1, p * (100 - DEAL_PERCENT) / 100) : p;
    }

    /** How long the "download" takes. */
    private static long durationMs(String id) { return 5000L + game(id).sizeMb() * 130L; }

    // ---------- state ----------
    public static boolean owned(String id) { ensure(); return owned.contains(id); }

    /** 0..1 while installing, 1 when installed, -1 if not owned. */
    public static float progress(String id) {
        ensure();
        if (!owned.contains(id)) return -1;
        Long start = installStart.get(id);
        if (start == null) return 1;
        return Math.max(0f, Math.min(1f, (System.currentTimeMillis() - start) / (float) durationMs(id)));
    }

    public static boolean installed(String id) { return progress(id) >= 1f; }

    public static int secondsLeft(String id) {
        Long start = installStart.get(id);
        if (start == null) return 0;
        return (int) Math.max(0, Math.ceil((durationMs(id) - (System.currentTimeMillis() - start)) / 1000.0));
    }

    public static int ownedCount() { ensure(); return owned.size(); }

    /** Buys a game and starts installing it. Returns false if there are not enough coins. */
    public static boolean buy(String id) {
        ensure();
        if (owned.contains(id)) return false;
        if (!Progress.spend(priceNow(id))) return false;
        owned.add(id);
        installStart.put(id, System.currentTimeMillis());
        Progress.toast("cutemod.toast.store_bought", name(id));
        dirty = true;
        save();
        return true;
    }

    // ---------- reviews ----------
    /** Every game has this many reviews from "other players" (texts are in the lang files). */
    public static final int NPC_REVIEWS = 3;
    private static final String[] NAMES = {"CreeperFan", "BeeKeeper42", "SleepyPanda", "IceCube", "FoxyLady", "EnderBoy",
            "PixelCat", "MossyStone", "NightOwl", "Cookie_Monster", "DiamondDigger", "Zzz_Zed"};

    public static String npcAuthor(String id, int n) { return NAMES[Math.floorMod(id.hashCode() * 31 + n * 7 + 5, NAMES.length)]; }

    public static int npcStars(String id, int n) {
        int base = Math.round(game(id).rating() / 10f);
        int d = n == 0 ? 0 : Math.floorMod(id.hashCode() + n * 13, 3) - 1;
        return Math.max(1, Math.min(5, base + d));
    }

    /** The player's own review: 0 stars = none yet. */
    public static int reviewStars(String id) { ensure(); return reviewStars.getOrDefault(id, 0); }

    public static String reviewText(String id) { ensure(); return reviewText.getOrDefault(id, ""); }

    /** Saves the review. Returns true if it is the first review for this game. */
    public static boolean setReview(String id, int stars, String text) {
        ensure();
        boolean first = !reviewStars.containsKey(id);
        reviewStars.put(id, Math.max(1, Math.min(5, stars)));
        reviewText.put(id, text == null ? "" : text);
        dirty = true;
        save();
        return first;
    }

    // ---------- play statistics ----------
    public static int playSeconds(String id) { ensure(); return playSeconds.getOrDefault(id, 0); }

    public static int best(String id) { ensure(); return best.getOrDefault(id, 0); }

    public static void addPlaySecond(String id) {
        ensure();
        playSeconds.merge(id, 1, Integer::sum);
        dirty = true;
    }

    public static void recordScore(String id, int score) {
        ensure();
        if (score > best.getOrDefault(id, 0)) { best.put(id, score); dirty = true; }
    }

    public static String playTime(String id) {
        int s = playSeconds(id), h = s / 3600, m = (s % 3600) / 60;
        return h > 0 ? h + "h " + m + "m" : m > 0 ? m + " min" : s + " s";
    }

    // ---------- save / load ----------
    private static Path file() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("cutemod_library.txt");
    }

    private static void ensure() {
        if (loaded) return;
        loaded = true;
        boolean existing = false;
        try {
            Path p = file();
            if (Files.exists(p)) {
                existing = true;
                Properties pr = new Properties();
                try (var r = Files.newBufferedReader(p)) { pr.load(r); }
                welcomed = pr.getProperty("welcome", "0").equals("1");
                fill(owned, pr.getProperty("own"));
                fill(notified, pr.getProperty("notified"));
                for (String k : pr.stringPropertyNames()) {
                    try {
                        if (k.startsWith("start.")) installStart.put(k.substring(6), Long.parseLong(pr.getProperty(k).trim()));
                        else if (k.startsWith("play.")) playSeconds.put(k.substring(5), Integer.parseInt(pr.getProperty(k).trim()));
                        else if (k.startsWith("best.")) best.put(k.substring(5), Integer.parseInt(pr.getProperty(k).trim()));
                        else if (k.startsWith("rs.")) reviewStars.put(k.substring(3), Integer.parseInt(pr.getProperty(k).trim()));
                        else if (k.startsWith("rt.")) reviewText.put(k.substring(3), pr.getProperty(k));
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        } catch (Exception ignored) {
        }
        if (!welcomed) {                      // a little gift so the very first game can be bought
            welcomed = true;
            dirty = true;
            Progress.earn(WELCOME_COINS);
            save();
        }
    }

    private static void fill(Set<String> set, String csv) {
        if (csv == null || csv.isBlank()) return;
        for (String s : csv.split(",")) if (!s.isBlank()) set.add(s.trim());
    }

    public static void save() {
        if (!loaded) return;
        try {
            Properties pr = new Properties();
            pr.setProperty("welcome", welcomed ? "1" : "0");
            pr.setProperty("own", String.join(",", owned));
            pr.setProperty("notified", String.join(",", notified));
            installStart.forEach((k, v) -> pr.setProperty("start." + k, Long.toString(v)));
            playSeconds.forEach((k, v) -> pr.setProperty("play." + k, Integer.toString(v)));
            best.forEach((k, v) -> pr.setProperty("best." + k, Integer.toString(v)));
            reviewStars.forEach((k, v) -> pr.setProperty("rs." + k, Integer.toString(v)));
            reviewText.forEach((k, v) -> pr.setProperty("rt." + k, v));
            try (var w = Files.newBufferedWriter(file())) { pr.store(w, "CuteStore library"); }
            dirty = false;
        } catch (Exception ignored) {
        }
    }

    /** Called 60 times per second by the computer screen: finishes installs and saves now and then. */
    public static void tick() {
        ensure();
        if (++saveDelay % 30 == 0) {
            for (String id : owned) {
                if (!notified.contains(id) && installed(id)) {
                    notified.add(id);
                    Progress.toast("cutemod.toast.store_installed", name(id));
                    dirty = true;
                }
            }
        }
        if (dirty && saveDelay > 600) { saveDelay = 0; save(); }
    }
}
