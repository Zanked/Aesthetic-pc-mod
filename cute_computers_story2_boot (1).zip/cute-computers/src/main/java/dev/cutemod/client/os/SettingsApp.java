package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Settings: pick the desktop wallpaper, switch effects and set the computer password. */
public class SettingsApp extends App {
    private static final int COLS = 3, TW = 88, TH = 40, GAP = 8;
    private static final int X0 = (W - (COLS * TW + (COLS - 1) * GAP)) / 2, Y0 = 22;
    private static final int TOGGLE_Y = 116, TOGGLE2_Y = 133, PW_Y = 150, BTN_H = 14, MAX_PASSWORD = 24;
    private static final int KEY_ESC = 256, KEY_ENTER = 257, KEY_BACKSPACE = 259, KEY_KP_ENTER = 335;

    // password dialog: 0 = closed, 1 = type a new password, 2 = repeat it
    private int dialog;
    private final StringBuilder buf = new StringBuilder();
    private String first = "";
    private String message = "";

    @Override
    public Component title() { return Component.translatable("cutemod.os.settings"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.settings"); }

    @Override
    public void close() { dialog = 0; buf.setLength(0); }

    private static int tx(int i) { return X0 + (i % COLS) * (TW + GAP); }

    private static int ty(int i) { return Y0 + (i / COLS) * (TH + GAP); }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        rect(g, 0, 0, W, H, 0xFFE9DDF2);
        g.drawString(font(), t("cutemod.os.wallpaper"), X0, 8, 0xFF3A2A3A, false);
        for (int i = 0; i < Wallpaper.BASE; i++) {
            int x = tx(i), y = ty(i);
            boolean selected = i == Wallpaper.get();
            boolean hover = in(mx, my, x, y, TW, TH);
            rect(g, x - 2, y - 2, TW + 4, TH + 4, selected ? 0xFFFFD866 : (hover ? 0xFFFFFFFF : 0xFF3A2A4A));
            Wallpaper.draw(g, x, y, TW, TH, shell.color().bodyColor, i);
        }
        toggle(g, mx, my, 0, "cutemod.os.set.scary", Haunt.scary);
        toggle(g, mx, my, 1, "cutemod.os.set.popups", Haunt.popups);
        toggle(g, mx, my, 0, TOGGLE2_Y, "cutemod.os.set.sounds", Sfx.sounds());
        toggle(g, mx, my, 1, TOGGLE2_Y, "cutemod.os.set.hum", Sfx.hum());

        boolean has = Startup.hasPassword();
        button(g, mx, my, 0, PW_Y, t(has ? "cutemod.os.pw.change" : "cutemod.os.pw.set"), true);
        button(g, mx, my, 1, PW_Y, t("cutemod.os.pw.remove"), has);

        if (dialog > 0) renderDialog(g);
    }

    private static int bx(int i) { return X0 + i * (TW * 3 + GAP * 2 + 6) / 2; }

    private static int bw() { return (TW * 3 + GAP * 2 - 6) / 2; }

    private void toggle(GuiGraphics g, int mx, int my, int i, String key, boolean on) {
        toggle(g, mx, my, i, TOGGLE_Y, key, on);
    }

    private void toggle(GuiGraphics g, int mx, int my, int i, int y, String key, boolean on) {
        int x = bx(i), w = bw();
        boolean hover = in(mx, my, x, y, w, BTN_H);
        rect(g, x, y, w, BTN_H, on ? (hover ? 0xFFB57BD6 : 0xFF9A64BF) : (hover ? 0xFFFFFFFF : 0xFFC9B8D8));
        String s = t(key) + ": " + t(on ? "cutemod.os.on" : "cutemod.os.off");
        g.drawString(font(), s, x + (w - font().width(s)) / 2, y + 3, on ? 0xFFFFFFFF : 0xFF3A2A3A, false);
    }

    private void button(GuiGraphics g, int mx, int my, int i, int y, String label, boolean enabled) {
        int x = bx(i), w = bw();
        boolean hover = enabled && in(mx, my, x, y, w, BTN_H);
        rect(g, x, y, w, BTN_H, !enabled ? 0xFFD9CEE3 : (hover ? 0xFFB57BD6 : 0xFF9A64BF));
        g.drawString(font(), label, x + (w - font().width(label)) / 2, y + 3, enabled ? 0xFFFFFFFF : 0xFF9A90A8, false);
    }

    private void renderDialog(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0xAA140E1C);
        int dw = 180, dh = 74, dx = (W - dw) / 2, dy = (H - dh) / 2;
        rect(g, dx - 1, dy - 1, dw + 2, dh + 2, 0xFFB9B0C8);
        rect(g, dx, dy, dw, dh, 0xFFF4EFF8);
        g.drawCenteredString(font(), Component.translatable(dialog == 1 ? "cutemod.os.pw.new" : "cutemod.os.pw.repeat"),
                W / 2, dy + 8, 0xFF3A2A3A);
        int fx = dx + 16, fy = dy + 24, fw = dw - 32;
        rect(g, fx - 1, fy - 1, fw + 2, 16, 0xFF9A64BF);
        rect(g, fx, fy, fw, 14, 0xFFFFFFFF);
        String dots = "•".repeat(buf.length());
        while (font().width(dots) > fw - 12) dots = dots.substring(1);
        g.drawString(font(), dots, fx + 4, fy + 3, 0xFF3A2A3A, false);
        if ((System.currentTimeMillis() / 400) % 2 == 0) rect(g, fx + 5 + font().width(dots), fy + 2, 1, 10, 0xFF3A2A3A);
        if (!message.isEmpty()) g.drawCenteredString(font(), Component.literal(message), W / 2, dy + 44, 0xFFD9302A);
        g.drawCenteredString(font(), Component.translatable("cutemod.os.pw.dialog.hint"), W / 2, dy + 58, 0xFF7A6A8A);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (dialog > 0) return true;
        int tw = bw();
        if (in(x, y, bx(0), TOGGLE_Y, tw, BTN_H)) { Haunt.scary = !Haunt.scary; return true; }
        if (in(x, y, bx(1), TOGGLE_Y, tw, BTN_H)) { Haunt.popups = !Haunt.popups; return true; }
        if (in(x, y, bx(0), TOGGLE2_Y, tw, BTN_H)) { Sfx.sounds = !Sfx.sounds; Sfx.save(); return true; }
        if (in(x, y, bx(1), TOGGLE2_Y, tw, BTN_H)) { Sfx.hum = !Sfx.hum; Sfx.save(); return true; }
        if (in(x, y, bx(0), PW_Y, tw, BTN_H)) {
            dialog = 1;
            buf.setLength(0);
            message = "";
            return true;
        }
        if (in(x, y, bx(1), PW_Y, tw, BTN_H)) {
            if (Startup.hasPassword()) Startup.setPassword(null);
            return true;
        }
        for (int i = 0; i < Wallpaper.BASE; i++) {
            if (in(x, y, tx(i), ty(i), TW, TH)) {
                Wallpaper.set(i);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (dialog == 0) return false;
        if (keyCode == KEY_ESC) {
            dialog = 0;
            buf.setLength(0);
        } else if (keyCode == KEY_BACKSPACE && buf.length() > 0) {
            buf.setLength(buf.length() - 1);
            message = "";
        } else if (keyCode == KEY_ENTER || keyCode == KEY_KP_ENTER) {
            if (dialog == 1) {
                if (buf.length() == 0) return true;
                first = buf.toString();
                buf.setLength(0);
                dialog = 2;
                message = "";
            } else if (buf.toString().equals(first)) {
                Startup.setPassword(first);
                first = "";
                buf.setLength(0);
                dialog = 0;
            } else {
                message = t("cutemod.os.pw.mismatch");
                buf.setLength(0);
                dialog = 1;
                first = "";
            }
        }
        return true;    // while the dialog is open every key belongs to it
    }

    @Override
    public boolean charTyped(char c) {
        if (dialog == 0) return false;
        if (c >= 32 && c != 127 && buf.length() < MAX_PASSWORD) {
            buf.append(c);
            message = "";
        }
        return true;
    }
}
