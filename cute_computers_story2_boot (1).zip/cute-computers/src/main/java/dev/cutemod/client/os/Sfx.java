package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * The sounds of the computer: the power-on chime, system beeps, key clicks, a quiet disk crackle
 * and the hum of the fan. Everything is made of vanilla sounds (note blocks, UI clicks, the beacon
 * hum), so no sound files are needed. "Sounds" and "Hum" can be switched off in Settings
 * (remembered in cutemod_sound.txt).
 */
public final class Sfx {
    private Sfx() {}

    public static boolean sounds = true;
    public static boolean hum = true;
    private static boolean loaded;

    private static Path file() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("cutemod_sound.txt");
    }

    private static void load() {
        if (loaded) return;
        loaded = true;
        try {
            Path p = file();
            if (Files.exists(p)) {
                String[] v = Files.readString(p).trim().split(",");
                sounds = v[0].equals("1");
                hum = v.length < 2 || v[1].equals("1");
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Files.writeString(file(), (sounds ? "1" : "0") + "," + (hum ? "1" : "0"));
        } catch (Exception ignored) {
        }
    }

    public static boolean sounds() { load(); return sounds; }

    public static boolean hum() { load(); return hum; }

    private static void play(SoundEvent e, float pitch, float vol) {
        if (!sounds()) return;
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(e, pitch, vol));
    }

    /** Note-block pitch for a semitone offset from the middle note. */
    private static float semi(int n) { return (float) Math.pow(2, n / 12.0); }

    // ---------- single sounds ----------
    public static void click() { play(SoundEvents.UI_BUTTON_CLICK.value(), 1.7F, 0.35F); }

    public static void key() { play(SoundEvents.UI_BUTTON_CLICK.value(), 2.0F, 0.18F); }

    public static void disk() { play(SoundEvents.UI_BUTTON_CLICK.value(), 2.0F, 0.1F); }

    public static void error() {
        play(SoundEvents.NOTE_BLOCK_BASS.value(), 0.6F, 0.8F);
        play(SoundEvents.NOTE_BLOCK_BIT.value(), 0.5F, 0.4F);
    }

    public static void powerOn() {
        play(SoundEvents.UI_BUTTON_CLICK.value(), 0.6F, 0.6F);
        play(SoundEvents.BEACON_ACTIVATE, 1.6F, 0.25F);
    }

    /** Notes of the sounds that need a few steps. {delay in ticks, semitone, instrument (0 chime, 1 bell, 2 bit)}. */
    public static final int[][] STARTUP = {{0, -5, 0}, {5, 0, 0}, {10, 4, 0}, {15, 7, 1}, {22, 12, 1}};
    public static final int[][] LOGIN = {{0, 4, 1}, {4, 9, 1}};
    public static final int[][] LOCK = {{0, 7, 1}, {4, 0, 1}};
    public static final int[][] SHUTDOWN = {{0, 7, 0}, {5, 0, 0}, {10, -5, 0}};

    public static void note(int[] n) {
        SoundEvent e = switch (n[2]) {
            case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
            case 2 -> SoundEvents.NOTE_BLOCK_BIT.value();
            default -> SoundEvents.NOTE_BLOCK_CHIME.value();
        };
        play(e, semi(n[1]), 0.5F);
    }

    /** Plays a jingle right now (the delays are ignored). Used for the shutdown, when no tick follows. */
    public static void jingleNow(int[][] j) {
        for (int[] n : j) note(n);
    }

    // ---------- the fan ----------
    private static Hum fan;

    /** A quiet looping drone (the beacon hum) that follows the player, so it is heard evenly. */
    private static final class Hum extends AbstractTickableSoundInstance {
        private boolean off;

        Hum() {
            super(SoundEvents.BEACON_AMBIENT, SoundSource.BLOCKS, RandomSource.create());
            this.looping = true;
            this.delay = 0;
            this.volume = 0.12F;
            this.pitch = 1.5F;
            this.relative = true;
            this.attenuation = SoundInstance.Attenuation.NONE;
        }

        void turnOff() { off = true; stop(); }

        @Override
        public void tick() {
            if (off || !Sfx.hum()) { stop(); return; }
        }
    }

    public static void startFan() {
        stopFan();
        if (!hum()) return;
        fan = new Hum();
        Minecraft.getInstance().getSoundManager().play(fan);
    }

    /** Called every frame: starts the fan again if it was switched on in Settings (or off). */
    public static void keepFan() {
        if (fan == null || fan.isStopped()) {
            if (hum()) startFan();
        } else if (!hum()) {
            stopFan();
        }
    }

    public static void stopFan() {
        if (fan != null) fan.turnOff();
        fan = null;
    }
}
