package dev.cutemod.client.player;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.PackLocationInfo;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.PathPackResources;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;
import net.neoforged.fml.loading.FMLPaths;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

/**
 * Albums from the folder "cutemod_music" next to the game (no rebuild of the mod needed).
 *
 *   cutemod_music/My Album/01 First song.ogg
 *   cutemod_music/My Album/cover.png          (optional)
 *   cutemod_music/My Album/album.json         (optional: {"title": "...", "artist": "...", "price": 70})
 *
 * Every time the game loads its resources (start, F3+T, the Rescan button of the Music app) the folder is scanned and
 * turned into a small resource pack (in cutemod_music/.cache) that holds the same things music.gradle makes for the
 * albums that are inside the mod: the songs, their entries for sounds.json and albums.json.
 */
public final class UserMusic {
    private UserMusic() {}

    public static final String PACK_ID = "cutemod_user_music";
    private static final int DEFAULT_PRICE = 70;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    /** The folder the player puts the albums into. */
    public static Path dir() { return FMLPaths.GAMEDIR.get().resolve("cutemod_music"); }

    private static Path cache() { return dir().resolve(".cache"); }

    /** A RepositorySource: gives the game the resource pack made from the folder. Runs at every resource reload. */
    public static void loadPack(Consumer<Pack> consumer) {
        try {
            rebuild();
            PackLocationInfo info = new PackLocationInfo(PACK_ID, Component.literal("Cute Computers: your music"),
                    PackSource.BUILT_IN, Optional.empty());
            Pack pack = makePack(info, new PathPackResources.PathResourcesSupplier(cache()));
            if (pack != null) consumer.accept(pack);
        } catch (Exception e) {
            // a problem with the folder must never stop the game from starting: just no user albums
            System.err.println("[cutemod] could not read the music folder: " + e);
        }
    }

    /**
     * Pack.readMetaAndCreate changed its last parameter between Minecraft versions (a "selection config" record, or the
     * position), so it is found and called by reflection: the pack is always on, at the top, and cannot be moved.
     */
    private static Pack makePack(Object info, Object supplier) throws Exception {
        for (java.lang.reflect.Method m : Pack.class.getMethods()) {
            if (!m.getName().equals("readMetaAndCreate") || !java.lang.reflect.Modifier.isStatic(m.getModifiers())) continue;
            Class<?>[] p = m.getParameterTypes();
            if (p.length != 4 || p[0] != PackLocationInfo.class || p[2] != PackType.class) continue;
            Object last;
            if (p[3] == Pack.Position.class) last = Pack.Position.TOP;
            else last = p[3].getConstructor(boolean.class, Pack.Position.class, boolean.class).newInstance(true, Pack.Position.TOP, false);
            return (Pack) m.invoke(null, info, supplier, PackType.CLIENT_RESOURCES, last);
        }
        throw new IllegalStateException("Pack.readMetaAndCreate was not found");
    }

    // ---------- scan the folder and write the pack ----------
    private static void rebuild() throws IOException {
        Path root = dir();
        Files.createDirectories(root);
        readme(root);

        Path pack = cache();
        Path assets = pack.resolve("assets/cutemod");
        Files.createDirectories(assets.resolve("sounds/music"));
        Files.createDirectories(assets.resolve("textures/music"));
        Files.createDirectories(assets.resolve("music"));
        Files.writeString(pack.resolve("pack.mcmeta"),
                "{\"pack\":{\"pack_format\":34,\"description\":\"Cute Computers: your music\"}}", StandardCharsets.UTF_8);

        JsonObject sounds = new JsonObject();
        JsonArray albums = new JsonArray();
        Set<String> ids = new HashSet<>();
        Set<String> coverFiles = new HashSet<>();

        List<Path> folders = new ArrayList<>();
        try (Stream<Path> s = Files.list(root)) {
            s.filter(p -> Files.isDirectory(p) && !p.getFileName().toString().startsWith(".")).forEach(folders::add);
        }
        folders.sort((a, b) -> natural(a.getFileName().toString(), b.getFileName().toString()));

        for (Path folder : folders) {
            String name = folder.getFileName().toString();
            List<Path> songs = new ArrayList<>();
            try (Stream<Path> s = Files.list(folder)) {
                s.filter(p -> Files.isRegularFile(p) && p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".ogg")).forEach(songs::add);
            }
            if (songs.isEmpty()) continue;
            songs.sort((a, b) -> natural(a.getFileName().toString(), b.getFileName().toString()));

            JsonObject meta = new JsonObject();
            Path metaFile = folder.resolve("album.json");
            if (Files.exists(metaFile)) {
                try { meta = JsonParser.parseString(Files.readString(metaFile, StandardCharsets.UTF_8)).getAsJsonObject(); }
                catch (Exception ignored) { /* a broken album.json: use the defaults */ }
            }

            String id = "u_" + slug(meta.has("id") ? meta.get("id").getAsString() : name, name);
            while (!ids.add(id)) id += "x";

            Path songDir = assets.resolve("sounds/music/" + id);
            Files.createDirectories(songDir);
            JsonArray tracks = new JsonArray();
            Set<String> wanted = new HashSet<>();
            for (int i = 0; i < songs.size(); i++) {
                Path src = songs.get(i);
                String tid = String.format("t%02d", i + 1);
                wanted.add(tid + ".ogg");
                copyIfChanged(src, songDir.resolve(tid + ".ogg"));

                JsonObject ev = new JsonObject();
                JsonArray list = new JsonArray();
                JsonObject snd = new JsonObject();
                snd.addProperty("name", "cutemod:music/" + id + "/" + tid);
                snd.addProperty("stream", true);
                list.add(snd);
                ev.add("sounds", list);
                sounds.add("music." + id + "." + tid, ev);

                JsonObject t = new JsonObject();
                t.addProperty("id", tid);
                t.addProperty("title", prettyTitle(src.getFileName().toString()));
                t.addProperty("seconds", oggSeconds(Files.readAllBytes(src)));
                tracks.add(t);
            }
            try (Stream<Path> old = Files.list(songDir)) {          // songs that were removed from the folder
                for (Path p : (Iterable<Path>) old::iterator) if (!wanted.contains(p.getFileName().toString())) Files.deleteIfExists(p);
            }

            boolean hasCover = false;
            int cw = 0, ch = 0;
            Path cover = folder.resolve("cover.png");
            if (Files.exists(cover)) {
                int[] size = pngSize(Files.readAllBytes(cover));
                if (size[0] > 0 && size[1] > 0) {
                    copyIfChanged(cover, assets.resolve("textures/music/" + id + ".png"));
                    coverFiles.add(id + ".png");
                    hasCover = true; cw = size[0]; ch = size[1];
                }
            }

            JsonObject a = new JsonObject();
            a.addProperty("id", id);
            a.addProperty("title", meta.has("title") ? meta.get("title").getAsString() : name);
            a.addProperty("artist", meta.has("artist") ? meta.get("artist").getAsString() : "");
            a.addProperty("price", meta.has("price") ? meta.get("price").getAsInt() : DEFAULT_PRICE);
            a.addProperty("cover", hasCover);
            a.addProperty("coverW", cw);
            a.addProperty("coverH", ch);
            a.add("tracks", tracks);
            albums.add(a);
        }

        // albums that were removed from the folder
        try (Stream<Path> old = Files.list(assets.resolve("sounds/music"))) {
            for (Path p : (Iterable<Path>) old::iterator) if (!ids.contains(p.getFileName().toString())) deleteTree(p);
        }
        try (Stream<Path> old = Files.list(assets.resolve("textures/music"))) {
            for (Path p : (Iterable<Path>) old::iterator) if (!coverFiles.contains(p.getFileName().toString())) Files.deleteIfExists(p);
        }

        Files.writeString(assets.resolve("sounds.json"), GSON.toJson(sounds), StandardCharsets.UTF_8);
        JsonObject manifest = new JsonObject();
        manifest.add("albums", albums);
        Files.writeString(assets.resolve("music/albums.json"), GSON.toJson(manifest), StandardCharsets.UTF_8);
    }

    private static void readme(Path root) throws IOException {
        Path f = root.resolve("README.txt");
        if (Files.exists(f)) return;
        Files.writeString(f, String.join("\n",
                "YOUR MUSIC FOR THE MUSIC APP / ТВОЯ МУЗЫКА ДЛЯ ПРИЛОЖЕНИЯ «МУЗЫКА»",
                "",
                "One folder = one album / Одна папка = один альбом:",
                "",
                "  cutemod_music/My Album/01 First song.ogg",
                "  cutemod_music/My Album/02 Second song.ogg",
                "  cutemod_music/My Album/cover.png      (optional / необязательно)",
                "  cutemod_music/My Album/album.json     (optional / необязательно)",
                "",
                "album.json:  { \"title\": \"My Album\", \"artist\": \"Me\", \"price\": 70 }",
                "",
                "Songs must be .ogg. Convert with: ffmpeg -i song.mp3 -c:a libvorbis -q:a 4 song.ogg",
                "Песни должны быть в формате .ogg. Конвертация: ffmpeg -i song.mp3 -c:a libvorbis -q:a 4 song.ogg",
                "",
                "After adding an album press Rescan in the Music app (or F3+T in the game).",
                "Добавил альбом? Нажми «Обновить» в приложении «Музыка» (или F3+T в игре).",
                "Price is 70 coins by default / Цена по умолчанию 70 монет (0 = бесплатно).",
                ""), StandardCharsets.UTF_8);
    }

    // ---------- helpers (the same rules as music.gradle) ----------
    private static void copyIfChanged(Path src, Path dest) throws IOException {
        if (Files.exists(dest) && Files.size(dest) == Files.size(src)
                && Files.getLastModifiedTime(dest).toMillis() >= Files.getLastModifiedTime(src).toMillis()) return;
        Files.createDirectories(dest.getParent());
        Files.copy(src, dest, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    }

    private static void deleteTree(Path p) throws IOException {
        if (Files.isDirectory(p)) {
            try (Stream<Path> s = Files.list(p)) { for (Path c : (Iterable<Path>) s::iterator) deleteTree(c); }
        }
        Files.deleteIfExists(p);
    }

    /** a-z, 0-9 and _ only; anything else (Cyrillic names...) becomes a short stable hash of the folder name. */
    private static String slug(String wanted, String folderName) {
        String s = wanted.toLowerCase(Locale.ROOT).trim().replaceAll("\\s+", "_");
        if (s.matches("[a-z0-9_]+")) return s;
        try {
            byte[] h = MessageDigest.getInstance("MD5").digest(folderName.getBytes(StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder("a");
            for (int i = 0; i < 4; i++) b.append(String.format("%02x", h[i]));
            return b.toString();
        } catch (Exception e) { return "a" + Math.abs(folderName.hashCode()); }
    }

    private static String prettyTitle(String file) {
        String s = file.replaceAll("(?i)\\.ogg$", "");
        s = s.replaceFirst("^\\s*\\d+\\s*[-_.)]*\\s*", "").replace('_', ' ').trim();
        return s.isEmpty() ? file.replaceAll("(?i)\\.ogg$", "") : s;
    }

    /** "2 a" before "10 a". */
    private static int natural(String a, String b) {
        a = a.toLowerCase(Locale.ROOT);
        b = b.toLowerCase(Locale.ROOT);
        int i = 0, j = 0;
        while (i < a.length() && j < b.length()) {
            char x = a.charAt(i), y = b.charAt(j);
            if (Character.isDigit(x) && Character.isDigit(y)) {
                int i2 = i, j2 = j;
                while (i2 < a.length() && Character.isDigit(a.charAt(i2))) i2++;
                while (j2 < b.length() && Character.isDigit(b.charAt(j2))) j2++;
                int c = new BigInteger(a.substring(i, i2)).compareTo(new BigInteger(b.substring(j, j2)));
                if (c != 0) return c;
                i = i2; j = j2;
            } else {
                if (x != y) return Character.compare(x, y);
                i++; j++;
            }
        }
        return Integer.compare(a.length() - i, b.length() - j);
    }

    /** Length of an .ogg in whole seconds: sample rate from the Vorbis header, sample count from the last Ogg page. */
    private static int oggSeconds(byte[] b) {
        int rate = 0;
        for (int i = 0; i < Math.min(b.length - 16, 4096); i++) {
            if (b[i] == 1 && b[i + 1] == 'v' && b[i + 2] == 'o' && b[i + 3] == 'r' && b[i + 4] == 'b' && b[i + 5] == 'i' && b[i + 6] == 's') {
                int o = i + 12;
                rate = (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
                break;
            }
        }
        long gran = -1;
        for (int i = b.length - 14; i >= 0; i--) {
            if (b[i] == 'O' && b[i + 1] == 'g' && b[i + 2] == 'g' && b[i + 3] == 'S') {
                gran = 0;
                for (int k = 7; k >= 0; k--) gran = (gran << 8) | (b[i + 6 + k] & 0xFF);
                break;
            }
        }
        return (rate > 0 && gran > 0) ? (int) Math.ceil(gran / (double) rate) : 0;
    }

    private static int[] pngSize(byte[] b) {
        if (b.length < 24) return new int[]{0, 0};
        int w = ((b[16] & 0xFF) << 24) | ((b[17] & 0xFF) << 16) | ((b[18] & 0xFF) << 8) | (b[19] & 0xFF);
        int h = ((b[20] & 0xFF) << 24) | ((b[21] & 0xFF) << 16) | ((b[22] & 0xFF) << 8) | (b[23] & 0xFF);
        return new int[]{w, h};
    }
}
