package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

import java.util.ArrayList;
import java.util.List;

/**
 * Music player: real songs from the albums in the music/ folder (see music.gradle and {@link Albums}), played as .ogg files.
 * The Library tab plays the albums you own, the Store tab sells albums for coins. Music plays while the player is open.
 */
public class MusicApp extends App {
    // ---------- the list of songs ----------
    /** kind 0 = a heading (the album), 2 = a song of an album. */
    private record Row(int kind, String label, Albums.Album album, Albums.Track track) {
        String key() { return kind == 2 ? album.id() + "." + track.id() : ""; }
    }

    private List<Row> rows = new ArrayList<>();
    private int sel = -1;                       // the row that is playing / was played last
    private int t = 0, ticks = 0, listTop = 0, lastSel = -2, rebuildAt = 0;
    private static final int VIS = 8;           // the rows that fit above the "now playing" line
    private boolean playing;

    private boolean store;                      // false = Library tab, true = Store tab
    private int storeSel = 0, storeTop = 0;

    private float vol = 0.6F;
    private final float[] bars = new float[12];
    private final java.util.Random rnd = new java.util.Random();
    private TrackSound inst;                    // the sound of the album song that plays now
    private String flash = "";                 // a short message (not enough coins)
    private int flashT;

    private void say(String s) { flash = s; flashT = 150; }

    public MusicApp() {
        rebuild();
        for (int i = 0; i < rows.size(); i++) if (rows.get(i).kind() != 0) { sel = i; break; }
    }

    /** Builds the Library list again (a song or an album may have been bought); the playing song keeps its place. */
    private void rebuild() {
        String key = sel >= 0 && sel < rows.size() ? rows.get(sel).key() : null;
        List<Row> r = new ArrayList<>();
        for (Albums.Album a : Albums.all()) {
            if (!a.owned()) continue;
            r.add(new Row(0, a.artist().isEmpty() ? a.title() : a.title() + " - " + a.artist(), a, null));
            for (Albums.Track tr : a.tracks()) r.add(new Row(2, tr.title(), a, tr));
        }
        rows = r;
        if (key != null) {
            sel = -1;
            for (int i = 0; i < r.size(); i++) if (r.get(i).key().equals(key)) { sel = i; break; }
        }
        if (sel < 0) { for (int i = 0; i < r.size(); i++) if (r.get(i).kind() != 0) { sel = i; break; } }
    }

    private Row selRow() { return sel >= 0 && sel < rows.size() ? rows.get(sel) : null; }

    /** How long the song is, in ticks (60 per second here: the app ticks 60 times a second). */
    private int total() {
        Row r = selRow();
        if (r == null || r.kind() != 2) return 1;
        return r.track().seconds() > 0 ? r.track().seconds() * 60 : Integer.MAX_VALUE / 2;
    }

    // ---------- the sound of an album song ----------
    /** A normal UI sound whose volume can be changed while it plays (the slider). */
    private static final class TrackSound extends SimpleSoundInstance {
        TrackSound(SoundEvent e, float v) {
            super(e.getLocation(), SoundSource.MASTER, v, 1F, RandomSource.create(), false, 0,
                    SoundInstance.Attenuation.NONE, 0, 0, 0, true);
        }

        void setVol(float v) { this.volume = v; }
    }

    private float outVol() { return Math.min(1F, vol * Sfx.musicVol()); }

    private void stopSound() {
        if (inst != null) { Minecraft.getInstance().getSoundManager().stop(inst); inst = null; }
    }

    // ---------- for the desktop player widget ----------
    @Override
    public boolean busy() { return playing; }

    @Override
    public Component title() { return Component.translatable("cutemod.os.music"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.music"); }

    @Override
    public Component status() {
        return playing ? Component.translatable("cutemod.music.now", trackName())
                : Component.translatable("cutemod.music.paused");
    }

    @Override
    public void close() { playing = false; stopSound(); }

    @Override
    public boolean background() { return playing; }

    boolean active() { return playing || t > 0; }

    boolean isPlaying() { return playing; }

    String trackName() { Row r = selRow(); return r == null ? "" : r.label(); }

    float progress() { return Math.min(1f, t / (float) Math.max(1, total())); }

    void toggle() {
        if (playing) { playing = false; stopSound(); t = 0; }   // a real song cannot be paused in the middle: it starts again
        else startRow(sel);
    }

    void nextTrack() { startRow(step(sel, 1)); }

    void prevTrack() { startRow(step(sel, -1)); }

    /** The next row that is a song (headings are skipped), going round the list; -1 if there are no songs. */
    private int step(int from, int dir) {
        int n = rows.size();
        for (int k = 1; k <= n; k++) {
            int i = Math.floorMod(from + dir * k, n);
            if (rows.get(i).kind() != 0) return i;
        }
        return -1;
    }

    private void startRow(int i) {
        if (i < 0 || i >= rows.size() || rows.get(i).kind() == 0) return;
        stopSound();
        dev.cutemod.client.player.PlayerEngine.stop();   // only one thing plays: the portable player stops
        sel = i;
        t = 0;
        playing = true;
        inst = new TrackSound(rows.get(i).track().sound(), outVol());
        Minecraft.getInstance().getSoundManager().play(inst);
    }

    static void note(int instrument, int n, float volume) {
        SoundEvent ev = switch (instrument) {
            case 0 -> SoundEvents.NOTE_BLOCK_HARP.value();
            case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
            case 2 -> SoundEvents.NOTE_BLOCK_BASS.value();
            default -> SoundEvents.NOTE_BLOCK_CHIME.value();
        };
        float pitch = (float) Math.max(0.5, Math.min(2.0, Math.pow(2.0, (n - 12) / 12.0)));
        Sfx.musicNote(ev, pitch, volume);
    }

    @Override
    public void tick() {
        ticks++;
        if (flashT > 0) flashT--;
        for (int i = 0; i < bars.length; i++) bars[i] *= 0.92F;
        if (ticks >= rebuildAt) { rebuildAt = ticks + 120; if (!store) rebuild(); }
        if (!playing) return;
        Row r = selRow();
        if (r == null || r.kind() != 2) { playing = false; return; }
        if (inst != null) inst.setVol(outVol());
        if (ticks % 6 == 0) bars[rnd.nextInt(bars.length)] = 0.35F + rnd.nextFloat() * 0.65F;   // the equalizer just dances
        boolean unknownLength = r.track().seconds() <= 0;
        if (unknownLength && t > 120 && inst != null && !Minecraft.getInstance().getSoundManager().isActive(inst)) {
            startRow(step(sel, 1));
            return;
        }
        t++;
        if (t >= total() + 30) startRow(step(sel, 1));   // next song
    }

    // ---------- layout ----------
    private static final int LIST_X = 8, LIST_Y = 10, ROW_H = 11, LIST_W = 132;
    private static final int BAR_X = 8, BAR_Y = 112, BAR_W = 284;
    private static final int VOL_X = 190, VOL_Y = 133, VOL_W = 90;
    private static final int TAB_X = 8, TAB_Y = 148, TAB_W = 62, TAB_H = 14;
    private static final int FOLDER_X = 172, FOLDER_W = 56, RESCAN_X = 232, RESCAN_W = 60;
    private static final int PANE_X = 150, PANE_Y = 10, PANE_W = 142, PANE_H = 86;
    private static final int BUY_X = 222, BUY_Y = 78, BUY_W = 66, BUY_H = 14;

    private int count() { return store ? Albums.all().size() : rows.size(); }

    private int top() { return store ? storeTop : listTop; }

    private void setTop(int v) {
        int c = Math.max(0, Math.min(Math.max(0, count() - VIS), v));
        if (store) storeTop = c; else listTop = c;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Skin.grad(g, 0, 0, W, H, 0xFF1B1430, 0xFF3A2A5A);

        // follow the song only when it changes; every frame would pull the list back and it could never be scrolled away
        if (!store && sel != lastSel) {
            lastSel = sel;
            if (sel < listTop) listTop = sel;
            if (sel >= listTop + VIS) listTop = sel - VIS + 1;
        }
        setTop(top());
        int n = count(), tp = top();
        if (n > VIS) {                            // a scroll bar, so it is clear there is more
            int th = VIS * ROW_H - 2, bh = Math.max(8, th * VIS / n);
            Skin.rect(g, LIST_X + LIST_W + 3, LIST_Y, 2, th, 0xFF2A2050);
            Skin.rect(g, LIST_X + LIST_W + 3, LIST_Y + (th - bh) * tp / (n - VIS), 2, bh, 0xFFB57BD6);
        }

        if (store) renderStoreList(g, mx, my, tp, n); else renderLibraryList(g, mx, my, tp, n);

        // the right pane: equalizer (Library) or the album (Store)
        Skin.rect(g, PANE_X, PANE_Y, PANE_W, PANE_H, 0xFF14102A);
        if (store) renderAlbum(g, mx, my); else renderEqualizer(g);

        // now playing + progress
        fitText(g, font(), trackName(), BAR_X, 100, BAR_W, 0xFFFFFFFF, false);
        Skin.rect(g, BAR_X, BAR_Y, BAR_W, 6, 0xFF14102A);
        int done = playing || t > 0 ? Math.min(BAR_W, (int) ((long) BAR_W * t / Math.max(1, total()))) : 0;
        Skin.rect(g, BAR_X, BAR_Y, done, 6, 0xFFF58FB8);

        // buttons
        button(g, mx, my, 8, 128, 28, "|<");
        button(g, mx, my, 40, 128, 40, playing ? "||" : ">");
        button(g, mx, my, 84, 128, 28, ">|");

        // volume
        Skin.str(g, font(), t("cutemod.music.volume"), 120, 132, 0xFFD8CCE8, false);
        Skin.rect(g, VOL_X, VOL_Y, VOL_W, 8, 0xFF14102A);
        Skin.rect(g, VOL_X, VOL_Y, (int) (VOL_W * vol), 8, 0xFFB57BD6);

        // tab switch + coins
        button(g, mx, my, TAB_X, TAB_Y, TAB_W, store ? t("cutemod.music.library") : t("cutemod.music.store"));
        if (flashT > 0) fitText(g, font(), flash, TAB_X + TAB_W + 8, TAB_Y + 4, FOLDER_X - TAB_X - TAB_W - 14, 0xFFFF8A8A, false);
        else Skin.str(g, font(), t("cutemod.music.coins", Progress.coins()), TAB_X + TAB_W + 8, TAB_Y + 4, 0xFFFFD25A, false);
        button(g, mx, my, FOLDER_X, TAB_Y, FOLDER_W, t("cutemod.music.folder"));
        button(g, mx, my, RESCAN_X, TAB_Y, RESCAN_W, t("cutemod.music.rescan"));
    }

    private void renderLibraryList(GuiGraphics g, int mx, int my, int tp, int n) {
        for (int i = tp; i < Math.min(n, tp + VIS); i++) {
            int y = LIST_Y + (i - tp) * ROW_H;
            Row r = rows.get(i);
            if (r.kind() == 0) {                  // a heading: the album; the box puts it on the portable player
                String pl = t("cutemod.music.toplayer");
                int pw = font().width(pl) + 12;
                fitText(g, font(), r.label(), LIST_X + 2, y + 1, LIST_W - pw - 6, 0xFFF58FB8, false);
                if (r.album() != null) {
                    boolean on = r.album().onPlayer(), hv = in(mx, my, LIST_X + LIST_W - pw, y, pw, ROW_H - 2);
                    Skin.rect(g, LIST_X + LIST_W - pw, y, pw, ROW_H - 2, on ? 0xFFB57BD6 : (hv ? 0xFF5A4A86 : 0xFF3A2A66));
                    Skin.str(g, font(), pl, LIST_X + LIST_W - pw + 6, y + 1, on ? 0xFFFFFFFF : 0xFFD8CCE8, false);
                }
                continue;
            }
            boolean s = i == sel, hover = in(mx, my, LIST_X, y, LIST_W, ROW_H - 2);
            Skin.rect(g, LIST_X, y, LIST_W, ROW_H - 2, s ? 0xFFB57BD6 : (hover ? 0xFF5A4A86 : 0xFF3A2A66));
            fitText(g, font(), r.label(), LIST_X + 6, y + 1, LIST_W - 24, s ? 0xFFFFFFFF : 0xFFD8CCE8, false);
            if (s && playing) Skin.str(g, font(), (ticks / 15) % 2 == 0 ? ">" : ">>", LIST_X + LIST_W - 12, y + 1, 0xFFFFFFFF, false);
        }
        if (rows.isEmpty()) Skin.str(g, font(), t("cutemod.music.empty"), LIST_X + 4, LIST_Y + 4, 0xFFD8CCE8, false);
    }

    private void renderStoreList(GuiGraphics g, int mx, int my, int tp, int n) {
        List<Albums.Album> all = Albums.all();
        for (int i = tp; i < Math.min(n, tp + VIS); i++) {
            int y = LIST_Y + (i - tp) * ROW_H;
            Albums.Album a = all.get(i);
            boolean s = i == storeSel, hover = in(mx, my, LIST_X, y, LIST_W, ROW_H - 2);
            Skin.rect(g, LIST_X, y, LIST_W, ROW_H - 2, s ? 0xFFB57BD6 : (hover ? 0xFF5A4A86 : 0xFF3A2A66));
            String tag = a.owned() ? t("cutemod.music.owned") : (a.price() + "");
            int tw = font().width(tag);
            fitText(g, font(), a.title(), LIST_X + 6, y + 1, LIST_W - tw - 16, s ? 0xFFFFFFFF : 0xFFD8CCE8, false);
            Skin.str(g, font(), tag, LIST_X + LIST_W - 6 - tw, y + 1, a.owned() ? 0xFF8EE6A0 : 0xFFFFD25A, false);
        }
        if (all.isEmpty()) {
            String[] hint = t("cutemod.music.noalbums").split("\\|");
            for (int i = 0; i < hint.length; i++) Skin.str(g, font(), hint[i], LIST_X + 4, LIST_Y + 4 + i * 11, 0xFFD8CCE8, false);
        }
    }

    private void renderEqualizer(GuiGraphics g) {
        for (int i = 0; i < bars.length; i++) {
            int h = 3 + (int) (bars[i] * 74);
            int col = 0xFF000000 | java.awt.Color.HSBtoRGB(i / 12f, 0.55f, 0.95f);
            Skin.rect(g, 154 + i * 11, 92 - h, 9, h, col);
            Skin.rect(g, 154 + i * 11, 92 - h, 9, 1, 0x88FFFFFF);
        }
    }

    private void renderAlbum(GuiGraphics g, int mx, int my) {
        List<Albums.Album> all = Albums.all();
        if (storeSel < 0 || storeSel >= all.size()) return;
        Albums.Album a = all.get(storeSel);
        // the cover, 64 x 64 at most
        int cx = PANE_X + 6, cy = PANE_Y + 6, box = 64;
        if (a.cover() != null && a.coverW() > 0 && a.coverH() > 0) {
            float sc = Math.min(box / (float) a.coverW(), box / (float) a.coverH());
            int w = Math.max(1, (int) (a.coverW() * sc)), h = Math.max(1, (int) (a.coverH() * sc));
            g.blit(a.cover(), cx + (box - w) / 2, cy + (box - h) / 2, w, h, 0F, 0F, a.coverW(), a.coverH(), a.coverW(), a.coverH());
        } else {
            Skin.rect(g, cx, cy, box, box, 0xFF3A2A66);
            String letter = a.title().isEmpty() ? "?" : a.title().substring(0, 1).toUpperCase();
            Skin.str(g, font(), letter, cx + (box - font().width(letter)) / 2, cy + box / 2 - 4, 0xFFB57BD6, false);
        }
        int tx = cx + box + 6, tw = PANE_X + PANE_W - 4 - tx;
        fitText(g, font(), a.title(), tx, cy, tw, 0xFFFFFFFF, false);
        if (!a.artist().isEmpty()) fitText(g, font(), a.artist(), tx, cy + 12, tw, 0xFFD8CCE8, false);
        fitText(g, font(), t("cutemod.music.songs", a.tracks().size()), tx, cy + 24, tw, 0xFFB8A8D8, false);
        // the price / buy button
        if (a.owned()) {
            Skin.str(g, font(), t("cutemod.music.owned"), BUY_X + (BUY_W - font().width(t("cutemod.music.owned"))) / 2, BUY_Y + 4, 0xFF8EE6A0, false);
        } else {
            boolean can = Progress.coins() >= a.price(), hover = in(mx, my, BUY_X, BUY_Y, BUY_W, BUY_H);
            Skin.rect(g, BUY_X, BUY_Y, BUY_W, BUY_H, can ? (hover ? 0xFFF58FB8 : 0xFFD0709A) : 0xFF4A3A66);
            String s = t("cutemod.music.buy", a.price());
            Skin.str(g, font(), s, BUY_X + (BUY_W - font().width(s)) / 2, BUY_Y + 4, can ? 0xFFFFFFFF : 0xFF9A8ABA, false);
        }
    }

    private void button(GuiGraphics g, int mx, int my, int x, int y, int w, String s) {
        boolean hover = in(mx, my, x, y, w, 16);
        Skin.rect(g, x, y, w, 16, hover ? 0xFF8A6AC6 : 0xFF5A4A86);
        Skin.str(g, font(), s, x + (w - font().width(s)) / 2, y + 4, 0xFFFFFFFF, false);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        int n = count(), tp = top();
        for (int i = tp; i < Math.min(n, tp + VIS); i++) {
            if (!in(x, y, LIST_X, LIST_Y + (i - tp) * ROW_H, LIST_W, ROW_H - 2)) continue;
            if (store) storeSel = i;
            else if (rows.get(i).kind() == 0) {   // a heading: the portable player button
                Albums.Album al = rows.get(i).album();
                int pw = font().width(t("cutemod.music.toplayer")) + 12;
                if (al != null && in(x, y, LIST_X + LIST_W - pw, LIST_Y + (i - tp) * ROW_H, pw, ROW_H - 2)) al.setOnPlayer(!al.onPlayer());
            } else startRow(i);
            return true;
        }
        if (store) {
            List<Albums.Album> all = Albums.all();
            if (in(x, y, BUY_X, BUY_Y, BUY_W, BUY_H) && storeSel >= 0 && storeSel < all.size()) {
                Albums.Album a = all.get(storeSel);
                if (!a.owned()) {
                    if (a.buy()) { Sfx.musicNote(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.2F, 0.8F); rebuild(); }
                    else say(t("cutemod.music.notenough"));
                }
                return true;
            }
        }
        if (in(x, y, TAB_X, TAB_Y, TAB_W, 16)) { store = !store; if (!store) rebuild(); return true; }
        if (in(x, y, FOLDER_X, TAB_Y, FOLDER_W, 16)) {      // open the folder where the albums go
            try {
                java.nio.file.Files.createDirectories(dev.cutemod.client.player.UserMusic.dir());
                net.minecraft.Util.getPlatform().openFile(dev.cutemod.client.player.UserMusic.dir().toFile());
            } catch (Exception ex) { say(t("cutemod.music.nofolder")); }
            return true;
        }
        if (in(x, y, RESCAN_X, TAB_Y, RESCAN_W, 16)) {      // read the folder again (the same as F3+T)
            say(t("cutemod.music.rescanning"));
            Minecraft.getInstance().reloadResourcePacks();
            return true;
        }
        if (in(x, y, 8, 128, 28, 16)) { prevTrack(); return true; }
        if (in(x, y, 40, 128, 40, 16)) { toggle(); return true; }
        if (in(x, y, 84, 128, 28, 16)) { nextTrack(); return true; }
        if (in(x, y, VOL_X - 2, VOL_Y - 3, VOL_W + 4, 14)) { setVol(x); return true; }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        setTop(top() - (int) Math.signum(amount));
        return true;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (in(x, y, VOL_X - 6, VOL_Y - 8, VOL_W + 12, 24)) { setVol(x); return true; }
        return false;
    }

    private void setVol(int x) { vol = Math.max(0.05F, Math.min(1F, (x - VOL_X) / (float) VOL_W)); }

    @Override
    public boolean key(int keyCode, int modifiers) {
        switch (keyCode) {
            case 32 -> toggle();                  // space
            case 262 -> nextTrack();
            case 263 -> prevTrack();
            default -> { return false; }
        }
        return true;
    }
}
