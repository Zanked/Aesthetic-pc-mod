package dev.cutemod.client.os;

import java.util.Properties;

/**
 * The settings of the nostalgia pack (helper bee, crashes, screensaver, installed update). They are saved on
 * the server with the rest of the player's data. Safe Mode is only remembered while the game runs.
 */
public final class Retro {
    private Retro() {}

    private static Properties props;
    private static int gen = -1;
    private static boolean safe;

    private static Properties p() {
        if (props == null || gen != Store.gen()) {
            props = Store.readProps("retro");
            if (props == null) props = new Properties();
            gen = Store.gen();
        }
        return props;
    }

    private static void put(String key, String value) {
        p().setProperty(key, value);
        Store.writeProps("retro", p());
    }

    private static int geti(String key, int def) {
        try {
            return Integer.parseInt(p().getProperty(key, "").trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    /** The helper bee is on unless the player turned it off. */
    public static boolean bee() { return geti("bee", 1) != 0; }

    public static void setBee(boolean on) { put("bee", on ? "1" : "0"); }

    /** Now and then the computer may crash (a blue screen). */
    public static boolean crashes() { return geti("crash", 1) != 0; }

    public static void setCrashes(boolean on) { put("crash", on ? "1" : "0"); }

    /** The chosen screensaver (always one that is unlocked). */
    public static int saver() {
        int s = geti("saver", 0);
        return s >= 0 && s < Savers.COUNT && Savers.unlocked(s) ? s : 0;
    }

    public static void setSaver(int s) { put("saver", Integer.toString(s)); }

    /** How many updates are installed (0 = the first version). */
    public static int version() { return Math.max(0, Math.min(Updates.ALL.size(), geti("ver", 0))); }

    public static void setVersion(int v) { put("ver", Integer.toString(v)); }

    /** Which Dock apps the bee has already given a tip for (one bit each). */
    public static int beeSeen() { return geti("seen", 0); }

    public static void markSeen(int bit) { put("seen", Integer.toString(beeSeen() | bit)); }

    // ---------- Safe Mode ----------
    public static boolean safe() { return safe; }

    public static void setSafe(boolean on) { safe = on; }

    /** Only a few plain apps work in Safe Mode: Notes, Paint, Calculator, Settings and the Terminal. */
    public static boolean safeAllows(int icon) {
        return icon == 3 || icon == 4 || icon == 5 || icon == 6 || icon == 11;
    }
}
