package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Settings, in three tabs: Wallpapers, Sounds (switches and volume sliders) and Other (Spooky, Pop-ups, password). */
public class SettingsApp extends App {
    private static final int COLS = 3, TW = 88, TH = 40, GAP = 8;
    private static final int X0 = (W - (COLS * TW + (COLS - 1) * GAP)) / 2, Y0 = 28;
    private static final int TAB_Y = 4, TAB_H = 15;
    // Sounds tab
    private static final int SND_TOGGLE_Y = 34, VOL_Y = 70, VOL_STEP = 20;
    // Other tab
    private static final int OTHER_TOGGLE_Y = 34, BEE_Y = 50, PW_Y = 66, SAVER_Y = 86, UPD_Y = 104, SKIN_Y = 135;
    private static final int BTN_H = 14, MAX_PASSWORD = 24;
    private static final int VOL_LABEL_W = 52, VOL_H = 11;
    private static final int TAB_WALLPAPER = 0, TAB_SOUNDS = 1, TAB_OTHER = 2;
    private int tab;
    private int dragVol = -1;       // 0 = system slider, 1 = music slider, -1 = none
    private static final int KEY_ESC = 256, KEY_ENTER = 257, KEY_BACKSPACE = 259, KEY_KP_ENTER = 335;

    // password dialog: 0 = closed, 1 = type a new password, 2 = repeat it
    private int dialog;
    private final StringBuilder buf = new StringBuilder();
    private String first = "";
    private String message = "";

    @Override
    public Component title() { return Component.translatable("cutemod.os.settings"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.settings"); }

    @Override
    public void close() {
        dialog = 0;
        buf.setLength(0);
        if (dragVol >= 0) { dragVol = -1; Sfx.save(); }
    }

    private static int tx(int i) { return X0 + (i % COLS) * (TW + GAP); }

    private static int ty(int i) { return Y0 + (i / COLS) * (TH + GAP); }

    private static final String[] TAB_KEYS = {"cutemod.os.tab.wallpaper", "cutemod.os.tab.sounds", "cutemod.os.tab.other"};

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Skin.rect(g, 0, 0, W, H, 0xFFE9DDF2);
        for (int i = 0; i < TAB_KEYS.length; i++) {
            int x = bx3(i), w = bw3();
            boolean on = i == tab, hover = in(mx, my, x, TAB_Y, w, TAB_H);
            Skin.rect(g, x, TAB_Y, w, TAB_H, on ? 0xFF9A64BF : (hover ? 0xFFFFFFFF : 0xFFC9B8D8));
            String s = t(TAB_KEYS[i]);
            Skin.str(g, font(), s, x + (w - font().width(s)) / 2, TAB_Y + 4, on ? 0xFFFFFFFF : 0xFF3A2A3A, false);
        }
        Skin.rect(g, X0, TAB_Y + TAB_H + 3, TW * 3 + GAP * 2, 1, 0xFFC9B8D8);

        if (tab == TAB_WALLPAPER) {
            for (int i = 0; i < Wallpaper.BASE; i++) {
                int x = tx(i), y = ty(i);
                boolean selected = i == Wallpaper.get();
                boolean hover = in(mx, my, x, y, TW, TH);
                Skin.rect(g, x - 2, y - 2, TW + 4, TH + 4, selected ? 0xFFFFD866 : (hover ? 0xFFFFFFFF : 0xFF3A2A4A));
                Wallpaper.draw(g, x, y, TW, TH, shell.color().bodyColor, i);
            }
        } else if (tab == TAB_SOUNDS) {
            toggle3(g, mx, my, 0, SND_TOGGLE_Y, "cutemod.os.set.sounds", Sfx.sounds());
            toggle3(g, mx, my, 1, SND_TOGGLE_Y, "cutemod.os.set.hum", Sfx.hum());
            toggle3(g, mx, my, 2, SND_TOGGLE_Y, "cutemod.os.set.music", Sfx.music());
            Skin.str(g, font(), t("cutemod.os.set.volume"), X0, VOL_Y - 14, 0xFF7A6A8A, false);
            slider(g, mx, my, 0, "cutemod.os.set.volsys", Sfx.volSystem);
            slider(g, mx, my, 1, "cutemod.os.set.volmusic", Sfx.volMusic);
        } else {
            toggle(g, mx, my, 0, OTHER_TOGGLE_Y, "cutemod.os.set.scary", Haunt.scary);
            toggle(g, mx, my, 1, OTHER_TOGGLE_Y, "cutemod.os.set.popups", Haunt.popups);
            toggle(g, mx, my, 0, BEE_Y, "cutemod.os.set.bee", Retro.bee());
            toggle(g, mx, my, 1, BEE_Y, "cutemod.os.set.crash", Retro.crashes());
            boolean has = Startup.hasPassword();
            button(g, mx, my, 0, PW_Y, t(has ? "cutemod.os.pw.change" : "cutemod.os.pw.set"), true);
            button(g, mx, my, 1, PW_Y, t("cutemod.os.pw.remove"), has);
            // screensaver: < name > and a preview
            int sx = X0, sw = TW * 3 + GAP * 2;
            Skin.rect(g, sx, SAVER_Y, 16, BTN_H, in(mx, my, sx, SAVER_Y, 16, BTN_H) ? 0xFFB57BD6 : 0xFF9A64BF);
            Skin.str(g, font(), "<", sx + 5, SAVER_Y + 3, 0xFFFFFFFF, false);
            Skin.rect(g, sx + 18, SAVER_Y, 138, BTN_H, 0xFFF4EFF8);
            String sn = t("cutemod.os.set.saver") + ": " + t("cutemod.saver." + Retro.saver());
            Skin.str(g, font(), sn, sx + 18 + (138 - font().width(sn)) / 2, SAVER_Y + 3, 0xFF3A2A3A, false);
            Skin.rect(g, sx + 158, SAVER_Y, 16, BTN_H, in(mx, my, sx + 158, SAVER_Y, 16, BTN_H) ? 0xFFB57BD6 : 0xFF9A64BF);
            Skin.str(g, font(), ">", sx + 163, SAVER_Y + 3, 0xFFFFFFFF, false);
            boolean ph = in(mx, my, sx + 176, SAVER_Y, sw - 176, BTN_H);
            Skin.rect(g, sx + 176, SAVER_Y, sw - 176, BTN_H, ph ? 0xFFB57BD6 : 0xFF9A64BF);
            String pv = t("cutemod.os.saver.preview");
            Skin.str(g, font(), pv, sx + 176 + (sw - 176 - font().width(pv)) / 2, SAVER_Y + 3, 0xFFFFFFFF, false);
            // the update
            int av = Updates.available();
            String info = av >= 0 ? t("cutemod.os.upd.available", t("cutemod.update." + Updates.ALL.get(av).id() + ".name"))
                    : Updates.upcoming() != null ? t("cutemod.os.upd.next", Updates.upcoming().date().toString())
                    : t("cutemod.os.upd.uptodate");
            Skin.str(g, font(), t("cutemod.os.upd.version", Updates.versionLabel()), X0, UPD_Y - 1, 0xFF3A2A3A, false);
            Skin.str(g, font(), info, X0, UPD_Y + 9, av >= 0 ? 0xFF2E7D4F : 0xFF7A6A8A, false);
            button(g, mx, my, 1, UPD_Y, t("cutemod.os.upd.install"), av >= 0);
            // light / dark / auto
            Skin.str(g, font(), t("cutemod.os.skin") + (Skin.mode() == Skin.AUTO ? " (" + t(Skin.dark() ? "cutemod.os.skin.dark" : "cutemod.os.skin.light") + ")" : ""), X0, SKIN_Y - 11, 0xFF3A2A3A, false);
            String[] names = {"cutemod.os.skin.light", "cutemod.os.skin.dark", "cutemod.os.skin.auto"};
            for (int i = 0; i < 3; i++) {
                int bx = bx3(i), bw = bw3();
                boolean on = Skin.mode() == i, hover = in(mx, my, bx, SKIN_Y, bw, BTN_H);
                Skin.rect(g, bx, SKIN_Y, bw, BTN_H, on ? (hover ? 0xFFB57BD6 : 0xFF9A64BF) : (hover ? 0xFFFFFFFF : 0xFFC9B8D8));
                String n = t(names[i]);
                Skin.str(g, font(), n, bx + (bw - font().width(n)) / 2, SKIN_Y + 3, on ? 0xFFFFFFFF : 0xFF3A2A3A, false);
            }
        }

        if (dialog > 0) renderDialog(g);
    }

    private static int bx(int i) { return X0 + i * (TW * 3 + GAP * 2 + 6) / 2; }

    private static int bw() { return (TW * 3 + GAP * 2 - 6) / 2; }

    /** The sound row has three switches instead of two. */
    private static int bw3() { return (TW * 3 + GAP * 2 - 8) / 3; }

    private static int bx3(int i) { return X0 + i * (bw3() + 4); }

    // ---------- volume sliders ----------
    private static int sliderY(int i) { return VOL_Y + i * VOL_STEP; }

    private static int trackX() { return X0 + VOL_LABEL_W; }

    private static int trackW() { return TW * 3 + GAP * 2 - VOL_LABEL_W - 28; }

    private void slider(GuiGraphics g, int mx, int my, int i, String key, int value) {
        int y = sliderY(i), tx = trackX(), tw = trackW();
        Skin.str(g, font(), t(key), X0, y + 2, 0xFF3A2A3A, false);
        Skin.rect(g, tx, y + 4, tw, 3, 0xFFC9B8D8);                                   // the groove
        Skin.rect(g, tx, y + 4, tw * value / 100, 3, 0xFF9A64BF);                     // the filled part
        int kx = tx + tw * value / 100 - 3;
        boolean hot = dragVol == i || in(mx, my, tx - 3, y, tw + 6, VOL_H);
        Skin.rect(g, kx, y + 1, 6, 9, hot ? 0xFFFFFFFF : 0xFFF4EFF8);                // the knob
        Skin.rect(g, kx, y + 1, 6, 1, 0xFF9A64BF);
        Skin.rect(g, kx, y + 9, 6, 1, 0xFF9A64BF);
        Skin.str(g, font(), value + "%", tx + tw + 5, y + 2, 0xFF3A2A3A, false);
    }

    private static int valueAt(int x) {
        return Math.max(0, Math.min(100, Math.round(100F * (x - trackX()) / trackW())));
    }

    private void setVol(int i, int value) {
        if (i == 0) Sfx.volSystem = value; else Sfx.volMusic = value;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (dragVol < 0) return false;
        setVol(dragVol, valueAt(x));
        return true;
    }

    @Override
    public void mouse(int x, int y) {
        // called every frame: when the button is let go, save the volume once and play a sample
        if (dragVol >= 0 && org.lwjgl.glfw.GLFW.glfwGetMouseButton(net.minecraft.client.Minecraft.getInstance().getWindow().getWindow(),
                org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT) != org.lwjgl.glfw.GLFW.GLFW_PRESS) {
            int which = dragVol;
            dragVol = -1;
            Sfx.save();
            if (which == 0) Sfx.click();
            else Sfx.musicNote(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_CHIME.value(), 1.0F, 0.6F);
        }
    }

    private void toggle3(GuiGraphics g, int mx, int my, int i, int y, String key, boolean on) {
        int x = bx3(i), w = bw3();
        boolean hover = in(mx, my, x, y, w, BTN_H);
        Skin.rect(g, x, y, w, BTN_H, on ? (hover ? 0xFFB57BD6 : 0xFF9A64BF) : (hover ? 0xFFFFFFFF : 0xFFC9B8D8));
        String s = t(key) + ": " + t(on ? "cutemod.os.on" : "cutemod.os.off");
        Skin.str(g, font(), s, x + (w - font().width(s)) / 2, y + 3, on ? 0xFFFFFFFF : 0xFF3A2A3A, false);
    }

    private void toggle(GuiGraphics g, int mx, int my, int i, int y, String key, boolean on) {
        int x = bx(i), w = bw();
        boolean hover = in(mx, my, x, y, w, BTN_H);
        Skin.rect(g, x, y, w, BTN_H, on ? (hover ? 0xFFB57BD6 : 0xFF9A64BF) : (hover ? 0xFFFFFFFF : 0xFFC9B8D8));
        String s = t(key) + ": " + t(on ? "cutemod.os.on" : "cutemod.os.off");
        Skin.str(g, font(), s, x + (w - font().width(s)) / 2, y + 3, on ? 0xFFFFFFFF : 0xFF3A2A3A, false);
    }

    private void button(GuiGraphics g, int mx, int my, int i, int y, String label, boolean enabled) {
        int x = bx(i), w = bw();
        boolean hover = enabled && in(mx, my, x, y, w, BTN_H);
        Skin.rect(g, x, y, w, BTN_H, !enabled ? 0xFFD9CEE3 : (hover ? 0xFFB57BD6 : 0xFF9A64BF));
        Skin.str(g, font(), label, x + (w - font().width(label)) / 2, y + 3, enabled ? 0xFFFFFFFF : 0xFF9A90A8, false);
    }

    private void renderDialog(GuiGraphics g) {
        Skin.rect(g, 0, 0, W, H, 0xAA140E1C);
        int dw = 180, dh = 74, dx = (W - dw) / 2, dy = (H - dh) / 2;
        Skin.rect(g, dx - 1, dy - 1, dw + 2, dh + 2, 0xFFB9B0C8);
        Skin.rect(g, dx, dy, dw, dh, 0xFFF4EFF8);
        Skin.cstr(g, font(), Component.translatable(dialog == 1 ? "cutemod.os.pw.new" : "cutemod.os.pw.repeat"),
                W / 2, dy + 8, 0xFF3A2A3A);
        int fx = dx + 16, fy = dy + 24, fw = dw - 32;
        Skin.rect(g, fx - 1, fy - 1, fw + 2, 16, 0xFF9A64BF);
        Skin.rect(g, fx, fy, fw, 14, 0xFFFFFFFF);
        String dots = "•".repeat(buf.length());
        while (font().width(dots) > fw - 12) dots = dots.substring(1);
        Skin.str(g, font(), dots, fx + 4, fy + 3, 0xFF3A2A3A, false);
        if ((System.currentTimeMillis() / 400) % 2 == 0) Skin.rect(g, fx + 5 + font().width(dots), fy + 2, 1, 10, 0xFF3A2A3A);
        if (!message.isEmpty()) Skin.cstr(g, font(), Component.literal(message), W / 2, dy + 44, 0xFFD9302A);
        Skin.cstr(g, font(), Component.translatable("cutemod.os.pw.dialog.hint"), W / 2, dy + 58, 0xFF7A6A8A);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (dialog > 0) return true;
        for (int i = 0; i < TAB_KEYS.length; i++) {
            if (in(x, y, bx3(i), TAB_Y, bw3(), TAB_H)) { tab = i; return true; }
        }
        int tw = bw();
        if (tab == TAB_SOUNDS) {
            for (int i = 0; i < 2; i++) {
                if (in(x, y, trackX() - 4, sliderY(i), trackW() + 8, VOL_H)) {
                    dragVol = i;
                    setVol(i, valueAt(x));
                    return true;
                }
            }
            if (in(x, y, bx3(0), SND_TOGGLE_Y, bw3(), BTN_H)) { Sfx.sounds = !Sfx.sounds; Sfx.save(); return true; }
            if (in(x, y, bx3(1), SND_TOGGLE_Y, bw3(), BTN_H)) { Sfx.hum = !Sfx.hum; Sfx.save(); return true; }
            if (in(x, y, bx3(2), SND_TOGGLE_Y, bw3(), BTN_H)) { Sfx.music = !Sfx.music; Sfx.save(); return true; }
        } else if (tab == TAB_OTHER) {
            if (in(x, y, bx(0), OTHER_TOGGLE_Y, tw, BTN_H)) { Haunt.scary = !Haunt.scary; return true; }
            if (in(x, y, bx(1), OTHER_TOGGLE_Y, tw, BTN_H)) { Haunt.popups = !Haunt.popups; return true; }
            if (in(x, y, bx(0), BEE_Y, tw, BTN_H)) { Retro.setBee(!Retro.bee()); return true; }
            if (in(x, y, bx(1), BEE_Y, tw, BTN_H)) { Retro.setCrashes(!Retro.crashes()); return true; }
            if (in(x, y, X0, SAVER_Y, 16, BTN_H)) { Retro.setSaver(Savers.step(Retro.saver(), -1)); return true; }
            if (in(x, y, X0 + 158, SAVER_Y, 16, BTN_H)) { Retro.setSaver(Savers.step(Retro.saver(), 1)); return true; }
            if (in(x, y, X0 + 176, SAVER_Y, TW * 3 + GAP * 2 - 176, BTN_H)) { shell.saver(); return true; }
            for (int i = 0; i < 3; i++) {
                if (in(x, y, bx3(i), SKIN_Y, bw3(), BTN_H)) { Skin.setMode(i); Sfx.click(); return true; }
            }
            if (in(x, y, bx(1), UPD_Y, tw, BTN_H)) {
                int av = Updates.available();
                if (av >= 0) shell.installUpdate(av);
                return true;
            }
            if (in(x, y, bx(0), PW_Y, tw, BTN_H)) {
                dialog = 1;
                buf.setLength(0);
                message = "";
                return true;
            }
            if (in(x, y, bx(1), PW_Y, tw, BTN_H)) {
                if (Startup.hasPassword()) Startup.setPassword(null);
                return true;
            }
        } else {
            for (int i = 0; i < Wallpaper.BASE; i++) {
                if (in(x, y, tx(i), ty(i), TW, TH)) {
                    Wallpaper.set(i);
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (dialog == 0) return false;
        if (keyCode == KEY_ESC) {
            dialog = 0;
            buf.setLength(0);
        } else if (keyCode == KEY_BACKSPACE && buf.length() > 0) {
            buf.setLength(buf.length() - 1);
            message = "";
        } else if (keyCode == KEY_ENTER || keyCode == KEY_KP_ENTER) {
            if (dialog == 1) {
                if (buf.length() == 0) return true;
                first = buf.toString();
                buf.setLength(0);
                dialog = 2;
                message = "";
            } else if (buf.toString().equals(first)) {
                Startup.setPassword(first);
                first = "";
                buf.setLength(0);
                dialog = 0;
            } else {
                message = t("cutemod.os.pw.mismatch");
                buf.setLength(0);
                dialog = 1;
                first = "";
            }
        }
        return true;    // while the dialog is open every key belongs to it
    }

    @Override
    public boolean charTyped(char c) {
        if (dialog == 0) return false;
        if (c >= 32 && c != 127 && buf.length() < MAX_PASSWORD) {
            buf.append(c);
            message = "";
        }
        return true;
    }
}
