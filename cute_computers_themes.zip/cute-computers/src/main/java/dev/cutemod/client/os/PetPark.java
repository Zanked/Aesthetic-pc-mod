package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.data.ParkData;
import dev.cutemod.net.ParkSyncPayload;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/**
 * The Pet Park screen of the Tamagotchi app: a sunny meadow where the pets of the players on the server walk about.
 * Click the grass to walk, click another pet to go and play with it, use the three emotes to say hi.
 * Everything that counts (friendship, coins) is decided on the server; this class only draws and sends the position.
 */
final class PetPark {
    private static final int W = App.W, H = App.H;
    private static final int Y_MIN = 70, Y_MAX = 150, BAR_Y = 150;
    private static final int[] EMOTE_X = {8, 36, 64};
    private static final float SCALE = 0.55F;

    private final String myColor;
    private final Runnable back, onPlayed;
    private double x = 150, y = 120, tx = 150, ty = 120;
    private int ticks, sendT = 100, emoteOut, myEmote, myEmoteT, toastT, chaseGap;
    private String toast = "", chase = "";
    private boolean noPet;
    private final Map<String, double[]> pos = new HashMap<>();      // owner -> {x, y} (smoothed)
    private final List<double[]> hearts = new ArrayList<>();         // x, y, vy, life

    PetPark(String myColor, Runnable back, Runnable onPlayed) {
        this.myColor = myColor;
        this.back = back;
        this.onPlayed = onPlayed;
    }

    void open() {
        noPet = !Park.move(myColor, (int) x, (int) y, 0);
        sendT = 0;
    }

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    private void leave() {
        Park.leave();
        back.run();
    }

    private void say(String s) { toast = s; toastT = 180; }

    // ---------- time ----------
    void tick() {
        ticks++;
        if (noPet) return;
        if (++sendT >= 10) { sendT = 0; if (!Park.move(myColor, (int) x, (int) y, emoteOut)) noPet = true; emoteOut = 0; }
        if (toastT > 0) toastT--;
        if (myEmoteT > 0 && --myEmoteT == 0) myEmote = 0;
        ParkSyncPayload s = Park.last();
        ParkSyncPayload.Pet target = null;
        if (s != null) {
            for (ParkSyncPayload.Pet p : s.pets()) {
                double[] q = pos.computeIfAbsent(p.owner(), k -> new double[]{p.x(), p.y()});
                q[0] += (p.x() - q[0]) * 0.18;
                q[1] += (p.y() - q[1]) * 0.18;
                if (p.owner().equals(chase)) target = p;
                if (p.playing() && ticks % 12 == 0) hearts.add(new double[]{q[0] + (ticks % 24 == 0 ? 6 : -6), q[1] - 30, -0.5, 50});
            }
            pos.keySet().removeIf(k -> s.pets().stream().noneMatch(p -> p.owner().equals(k)));
        }
        if (Park.takeFull()) say(t("cutemod.park.full"));
        if (Park.takePlayed()) {
            onPlayed.run();
            say(t("cutemod.park.played", Park.with()));
            for (int i = 0; i < 6; i++) hearts.add(new double[]{x - 10 + i * 4, y - 30, -0.6 - (i % 3) * 0.2, 60});
        }
        // walk to the target (or to the pet we want to play with)
        if (target != null) {
            double[] q = pos.get(target.owner());
            double dx = q[0] - x, dy = q[1] - y, d = Math.hypot(dx, dy);
            if (d <= 42) {
                if (chaseGap == 0) { Park.play(target.owner()); chaseGap = 90; }
                chase = "";
            } else { tx = q[0] - dx / d * 30; ty = q[1] - dy / d * 30; }
        } else if (!chase.isEmpty()) chase = "";
        if (chaseGap > 0) chaseGap--;
        double dx = tx - x, dy = ty - y, d = Math.hypot(dx, dy);
        if (d > 1.5) { double sp = Math.min(d, 1.5); x += dx / d * sp; y += dy / d * sp; }
        y = Math.max(Y_MIN, Math.min(Y_MAX, y));
        hearts.removeIf(h -> { h[1] += h[2]; return --h[3] <= 0; });
    }

    // ---------- drawing ----------
    private void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(1 - (dy * dy) / (double) (ry * ry + 1)));
            rect(g, cx - dx, cy + dy, dx * 2 + 1, 1, argb);
        }
    }

    private void tree(GuiGraphics g, int cx, int base, int sz) {
        rect(g, cx - 3, base - sz, 6, sz, 0xFF8A5A3A);
        disc(g, cx, base - sz - 8, 15, 0xFF3FA55A);
        disc(g, cx - 9, base - sz - 2, 10, 0xFF4FB86A);
        disc(g, cx + 9, base - sz - 2, 10, 0xFF4FB86A);
        disc(g, cx - 4, base - sz - 12, 5, 0xFF7ADC8A);
    }

    private void scenery(GuiGraphics g) {
        g.fillGradient(0, 0, W, 66, 0xFF8FD3FF, 0xFFDDF4FF);
        disc(g, 262, 22, 11, 0xFFFFE066);
        for (int i = 0; i < 3; i++) {                                      // clouds that drift
            int cx = (int) ((ticks * (0.12 + i * 0.05) + i * 110) % (W + 80)) - 40, cy = 14 + i * 12;
            disc(g, cx, cy, 6, 0xDDFFFFFF); disc(g, cx + 8, cy + 2, 7, 0xDDFFFFFF); disc(g, cx - 8, cy + 3, 5, 0xDDFFFFFF);
        }
        disc(g, 60, 78, 40, 0xFF7ACB7A); disc(g, 200, 84, 46, 0xFF6BC070);  // far hills
        g.fillGradient(0, 62, W, H, 0xFF86D68A, 0xFF4DB35E);
        for (int i = 0; i < 9; i++) rect(g, 0, 70 + i * 10, W, 4, 0x14FFFFFF);
        oval(g, 150, 138, 90, 8, 0x33C9A678);                              // a sandy path
        oval(g, 236, 128, 34, 10, 0xFF6FC7F0);                              // the pond
        oval(g, 236, 127, 30, 7, 0xFF9ADCF8);
        int r = (ticks / 18) % 4;
        rect(g, 226 + r * 3, 126, 6, 1, 0x88FFFFFF);
        tree(g, 24, 100, 28);
        tree(g, 282, 96, 24);
        for (int i = 0; i < 14; i++) {                                      // flowers
            int fx = (i * 83 + 17) % (W - 20) + 10, fy = 80 + (i * 47) % 66;
            rect(g, fx, fy, 2, 2, i % 3 == 0 ? 0xFFFFF3B0 : i % 3 == 1 ? 0xFFFF8FB8 : 0xFFFFFFFF);
        }
        decor(g);
        // a bench
        rect(g, 118, 78, 36, 4, 0xFF8A5A3A); rect(g, 120, 82, 3, 8, 0xFF6A4228); rect(g, 149, 82, 3, 8, 0xFF6A4228);
        rect(g, 118, 72, 36, 3, 0xFF9A6A44);
    }

    /** What the OS updates added to the park (each update brings one thing; see Updates). */
    private void decor(GuiGraphics g) {
        if (Updates.has(0)) {                                              // a beehive in the left tree, with bees
            disc(g, 38, 62, 5, 0xFFF5B800);
            rect(g, 36, 62, 4, 3, 0xFF3A2A3A);
            for (int i = 0; i < 3; i++) {
                int bx = 38 + (int) Math.round(Math.cos(ticks / 10.0 + i * 2.1) * 12), by = 60 + (int) Math.round(Math.sin(ticks / 7.0 + i * 2.1) * 6);
                rect(g, bx, by, 3, 2, 0xFFFFC832);
                rect(g, bx + 1, by, 1, 2, 0xFF3A2A3A);
            }
        }
        if (Updates.has(1)) {                                              // a hot-air balloon drifts by
            int bx = (ticks / 5) % (W + 60) - 30, by = 26 + (int) Math.round(Math.sin(ticks / 40.0) * 3);
            disc(g, bx, by, 8, 0xFFE5484D);
            rect(g, bx - 8, by - 1, 17, 3, 0xFFFFFFFF);
            rect(g, bx - 3, by + 9, 7, 5, 0xFF8A5A3A);
            rect(g, bx - 4, by + 7, 1, 3, 0xFF6A4228); rect(g, bx + 4, by + 7, 1, 3, 0xFF6A4228);
        }
        if (Updates.has(2)) {                                              // a snowman by the pond, a few snowflakes
            disc(g, 200, 142, 6, 0xFFFFFFFF);
            disc(g, 200, 133, 4, 0xFFFFFFFF);
            rect(g, 198, 132, 1, 1, 0xFF3A2A3A); rect(g, 201, 132, 1, 1, 0xFF3A2A3A);
            rect(g, 199, 135, 3, 1, 0xFFE5484D);
            rect(g, 200, 133, 3, 1, 0xFFF59A3A);
            for (int i = 0; i < 12; i++) rect(g, (i * 53 + ticks / 4) % W, (i * 29 + ticks / 2) % 140, 1, 1, 0xCCFFFFFF);
        }
        if (Updates.has(3)) {                                              // the right tree blossoms and drops petals
            disc(g, 282, 66, 15, 0xFFF58FB8);
            disc(g, 273, 72, 10, 0xFFFFB6D2);
            disc(g, 291, 72, 10, 0xFFFFB6D2);
            for (int i = 0; i < 8; i++) rect(g, 260 + (i * 11 + ticks / 6) % 40, 70 + (i * 17 + ticks / 2) % 70, 2, 1, i % 2 == 0 ? 0xFFFFB6D2 : 0xFFFFFFFF);
        }
        if (Updates.has(4)) {                                              // sunset glow and a string of paper lanterns
            g.fillGradient(0, 0, W, 66, 0x55FF8A5C, 0x00FFB870);
            for (int i = 0; i < 8; i++) {
                int lx = 22 + i * 36, ly = 20 + (int) Math.round(Math.sin(i * 0.9) * 3) + (int) Math.round(Math.sin(ticks / 30.0 + i) * 1.5);
                rect(g, lx, 14, 1, ly - 14, 0xFF6A4228);
                rect(g, lx - 3, ly, 7, 8, 0xFFE5484D);
                rect(g, lx - 2, ly + 2, 5, 4, 0xFFFFE680);
            }
        }
    }

    void render(GuiGraphics g, int mx, int my) {
        Font f = net.minecraft.client.Minecraft.getInstance().font;
        scenery(g);
        if (noPet) {
            rect(g, 40, 60, W - 80, 36, 0xE0201828);
            g.drawCenteredString(f, t("cutemod.park.nopet"), W / 2, 74, 0xFFFFFFFF);
            drawBack(g, f, mx, my);
            return;
        }
        ParkSyncPayload s = Park.last();
        // everybody sorted by their feet: the ones lower on the screen are in front
        record Ent(double y, ParkSyncPayload.Pet pet) {}
        List<Ent> list = new ArrayList<>();
        list.add(new Ent(y, null));
        String hover = "";
        if (s != null) for (ParkSyncPayload.Pet p : s.pets()) {
            double[] q = pos.get(p.owner());
            if (q == null) continue;
            list.add(new Ent(q[1], p));
            if (Math.abs(mx - q[0]) < 18 && my > q[1] - 40 && my < q[1] + 4) hover = p.owner();
        }
        list.sort((a, b) -> Double.compare(a.y(), b.y()));
        for (Ent e : list) {
            if (e.pet() == null) drawPet(g, f, x, y, myColor, null, true, false, 0, "", hover.isEmpty() ? "" : "");
            else {
                double[] q = pos.get(e.pet().owner());
                drawPet(g, f, q[0], q[1], e.pet().color(), e.pet().look(), false, e.pet().playing(), ParkData.level(e.pet().plays()),
                        e.pet().name(), hover.equals(e.pet().owner()) ? e.pet().owner() : "");
                emote(g, f, q[0], q[1], e.pet().emote());
            }
        }
        emote(g, f, x, y, myEmote);
        for (double[] h : hearts) PetShow.heart(g, (int) h[0] - 3, (int) h[1], 0xFFFF5C93);
        drawHud(g, f, mx, my, s, hover);
    }

    private void drawPet(GuiGraphics g, Font f, double px, double py, String color, dev.cutemod.net.PetLook look,
                         boolean mine, boolean playing, int friend, String name, String hovered) {
        int stage = look == null ? stageOfMine() : look.stage();
        String head = look == null ? Progress.equipped() : look.head();
        String body = look == null ? Progress.equippedBody() : look.body();
        float sc = SCALE * PetArt.scaleOf(stage);
        int cx = (int) Math.round(px), fl = (int) Math.round(py);
        boolean walking = mine && Math.hypot(tx - x, ty - y) > 2;
        int hop = playing ? (int) Math.round(Math.abs(Math.sin(ticks / 5.0)) * 8) : walking ? (int) Math.round(Math.abs(Math.sin(ticks / 4.0)) * 3) : 0;
        oval(g, cx, fl + 1, (int) (20 * sc) + 2, 2, 0x44000000);
        if (!hovered.isEmpty()) oval(g, cx, fl + 1, (int) (22 * sc) + 6, 3, 0x88FFFFFF);
        g.pose().pushPose();
        g.pose().translate(cx, fl, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-cx, -fl, 0);
        PetArt.draw(g, PetShow.colorOf(color), cx, fl - 28 - (int) (hop / sc), playing || !hovered.isEmpty() ? 2 : 1, ticks + (mine ? 0 : name.length() * 13),
                false, false, stage, head == null ? "" : head, body == null ? "" : body);
        g.pose().popPose();
        String label = mine ? t("cutemod.park.you") : name;
        int top = fl - (int) (50 * sc) - 10;
        g.drawString(f, label, cx - f.width(label) / 2, fl + 3, mine ? 0xFFFFE680 : 0xFFFFFFFF, true);
        for (int i = 0; i < friend; i++) PetShow.heart(g, cx - friend * 5 + i * 10 + 1, top - 8, 0xFFFF5C93);
    }

    private int stageOfMine() {
        PetBlob.Info i = PetBlob.parse(Store.read("pet_" + myColor));
        return i == null ? 2 : i.stage();
    }

    private void emote(GuiGraphics g, Font f, double px, double py, int e) {
        if (e <= 0) return;
        int cx = (int) Math.round(px), by = (int) Math.round(py) - 62;
        rect(g, cx - 12, by, 24, 12, 0xFFFFFFFF);
        rect(g, cx - 2, by + 12, 4, 3, 0xFFFFFFFF);
        switch (e) {
            case 1 -> PetShow.heart(g, cx - 3, by + 3, 0xFFFF5C93);
            case 2 -> g.drawString(f, "Hi!", cx - f.width("Hi!") / 2, by + 2, 0xFF3A2A3A, false);
            default -> g.drawString(f, "!", cx - f.width("!") / 2, by + 2, 0xFFE5484D, false);
        }
    }

    private void drawBack(GuiGraphics g, Font f, int mx, int my) {
        boolean hov = App.in(mx, my, 3, 3, 44, 12);
        rect(g, 3, 3, 44, 12, hov ? 0xFFFFFFFF : 0xE0F6F0FA);
        g.drawString(f, "< " + t("cutemod.park.back"), 7, 5, 0xFF3A2A3A, false);
    }

    private void drawHud(GuiGraphics g, Font f, int mx, int my, ParkSyncPayload s, String hover) {
        drawBack(g, f, mx, my);
        String title = t("cutemod.park.title");
        g.drawString(f, title, W / 2 - f.width(title) / 2, 5, 0xFFFFFFFF, true);
        String count = t("cutemod.park.count", (s == null ? 0 : s.pets().size()) + 1);
        g.drawString(f, count, W - 6 - f.width(count), 5, 0xFFFFFFFF, true);
        rect(g, 0, BAR_Y, W, H - BAR_Y, 0xCC201828);
        for (int i = 0; i < 3; i++) {
            boolean hov = App.in(mx, my, EMOTE_X[i], BAR_Y + 2, 24, 12);
            rect(g, EMOTE_X[i], BAR_Y + 2, 24, 12, hov ? 0xFFFFFFFF : 0xFFE4D8FF);
            switch (i) {
                case 0 -> PetShow.heart(g, EMOTE_X[i] + 9, BAR_Y + 5, 0xFFFF5C93);
                case 1 -> g.drawString(f, "Hi", EMOTE_X[i] + 12 - f.width("Hi") / 2, BAR_Y + 4, 0xFF3A2A3A, false);
                default -> g.drawString(f, "!", EMOTE_X[i] + 12 - f.width("!") / 2, BAR_Y + 4, 0xFFE5484D, false);
            }
        }
        String line = toastT > 0 ? toast : hover.isEmpty() ? t("cutemod.park.hint") : t("cutemod.park.click_play");
        g.drawString(f, f.plainSubstrByWidth(line, W - 100), 96, BAR_Y + 4, toastT > 0 ? 0xFFFFE680 : 0xFFE4D8FF, false);
    }

    // ---------- input ----------
    boolean click(int mx, int my) {
        if (App.in(mx, my, 3, 3, 44, 12)) { leave(); return true; }
        if (noPet) return true;
        for (int i = 0; i < 3; i++) {
            if (App.in(mx, my, EMOTE_X[i], BAR_Y + 2, 24, 12)) { emoteOut = i + 1; myEmote = i + 1; myEmoteT = 180; return true; }
        }
        if (my >= BAR_Y) return true;
        ParkSyncPayload s = Park.last();
        if (s != null) for (ParkSyncPayload.Pet p : s.pets()) {
            double[] q = pos.get(p.owner());
            if (q != null && Math.abs(mx - q[0]) < 18 && my > q[1] - 40 && my < q[1] + 4) { chase = p.owner(); chaseGap = 0; return true; }
        }
        chase = "";
        tx = Math.max(8, Math.min(W - 8, mx));
        ty = Math.max(Y_MIN, Math.min(Y_MAX, my + 24));          // the click is where the pet's body is, its feet are lower
        return true;
    }

    boolean key(int keyCode) {
        if (keyCode == 256) { leave(); return true; }            // escape: back to the room, not out of the computer
        return false;
    }

    void close() { Park.leave(); }
}
