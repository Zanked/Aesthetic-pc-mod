package dev.cutemod.client;

import dev.cutemod.ComputerColor;
import dev.cutemod.block.ComputerBlockEntity;
import dev.cutemod.client.os.App;
import dev.cutemod.client.os.AppSfx;
import dev.cutemod.client.os.Bee;
import dev.cutemod.client.os.RepairApp;
import dev.cutemod.client.os.Retro;
import dev.cutemod.client.os.Desktop;
import dev.cutemod.client.os.FolderApp;
import dev.cutemod.client.os.Folders;
import dev.cutemod.client.os.Items;
import dev.cutemod.client.os.Dock;
import dev.cutemod.client.os.Halloween;
import dev.cutemod.client.os.Hell;
import dev.cutemod.client.os.Market;
import dev.cutemod.client.os.Net;
import dev.cutemod.client.os.DockLayout;
import dev.cutemod.client.os.Skin;
import dev.cutemod.client.os.CuteFont;
import dev.cutemod.client.os.Theme;
import dev.cutemod.client.os.Haunt;
import dev.cutemod.client.os.Library;
import dev.cutemod.client.os.Progress;
import dev.cutemod.client.os.Sfx;
import dev.cutemod.client.os.Shell;
import dev.cutemod.client.os.StartMenu;
import dev.cutemod.client.os.Startup;
import dev.cutemod.client.os.TaskManagerApp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import dev.cutemod.client.os.Wallpaper;
import dev.cutemod.client.os.Widgets;
import dev.cutemod.net.ScorePayload;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.net.URI;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** The "monitor": a little desktop with games, a browser and other apps. */
public class ComputerScreen extends Screen implements Shell {
    private static final float ZOOM_MAX = 1.5f;     // how much bigger the monitor may get
    private static final int PAD = 10;
    private static final int HEADER = 8;     // thin frame above the screen
    private static final int MENU = 12;      // menu bar
    private static final int TB = 12;        // window title bar (traffic lights)
    private static final int DOCK = Dock.HEIGHT;
    private static final int FOOTER = 29;     // up to three lines: the record and a hint that wraps to two
    private static final int VIEW_W = App.W;
    private static final long STEP_NS = 16_666_667L; // apps run at 60 steps/second
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("EEE HH:mm");

    private final ComputerColor color;
    private final BlockPos pos;
    private final Desktop desktop = new Desktop();
    private final Haunt haunt = new Haunt();
    private final Dock dock = new Dock();
    private final Startup startup = new Startup();
    private final StartMenu start = new StartMenu();
    private final Bee bee = new Bee(this);               // the helper bee in the corner
    private int uptime, crashCheck;                      // the computer may crash now and then (only on the bare desktop)
    private boolean repairShown;                         // Safe Mode opens the repair tool once
    private static final int IDLE_TICKS = 60 * 90;   // screensaver after 90 s without input
    // Dock: press on an icon, drag to move it, release to open (or drop it out of the Dock to remove it)
    private int pressApp = -1, pressX, pressY, ctxApp = -1, ctxX;
    private boolean dragging;
    // opening animation: the window grows out of the icon (or the Start button) it was launched from
    private static final float ANIM_STEP = 1f / 14f;      // per tick: about 0.23 s
    private float animT = 1f;
    private float animX = Float.NaN, animY;                // launch origin on screen (NaN = the middle of the Dock)
    // the processes: every app that was opened and not shut down (the foreground one is `app`)
    private final List<App> running = new ArrayList<>();
    private final List<Integer> ctxItems = new ArrayList<>();   // right-click menu of a Dock icon: 0 = unpin, 1 = quit
    private boolean linking;      // a link dialog is open on top: not a real shutdown
    private int idle, lastMx = -1, lastMy = -1, purge;
    private boolean menuOpen;
    private App app;
    private App beforeTm;                               // the app that was in front when the Task Manager was opened (null = the desktop)

    private int left, top, gx, gy, panelW, panelH, menuY, dockY;
    // auto-hide: on the bare desktop the Dock is always there; in an app it slides up when the mouse touches the bottom edge
    private float dockShow = 1f;                     // 0 = hidden, 1 = shown
    private float dockHover;                         // seconds the mouse has rested on the bottom edge
    private long dockLastNs;
    private long dockFullUntil;                      // "the Dock is full" note, until this time (ms)
    private long lastNs = 0, acc = 0;

    public ComputerScreen(ComputerColor color, BlockPos pos) {
        super(Component.translatable("cutemod.os.title"));
        this.color = color;
        this.pos = pos;
        open(desktop);
        startup.setRebootHook(this::reboot);
    }

    // ---------- Shell ----------
    @Override
    public void open(App next) {
        // the previous app is NOT closed: it keeps running in the background (minimized)
        if (next != desktop && !running.contains(next)) {
            int idx = desktop.activeIndex(next);
            if (idx >= 0) {                                    // one process per Dock icon: a new game replaces the old one
                for (App other : new ArrayList<>(running)) {
                    if (other != app && desktop.activeIndex(other) == idx) { running.remove(other); other.close(); }
                }
            }
            running.add(next);
        }
        app = next;
        app.attach(this);
        acc = 0;
        animT = next == desktop ? 1f : 0f;                  // going home has no animation
        bee.context(next == desktop ? -1 : desktop.legacyIndex(next));
    }

    /** A restart (after a blue screen or an update): every app is shut down and we are on the desktop again. */
    private void reboot() {
        for (App a : new ArrayList<>(running)) {
            running.remove(a);
            a.close();
            desktop.forget(a);
        }
        beforeTm = null;
        open(desktop);
        repairShown = false;
        uptime = 0;
        crashCheck = 0;
        bee.reset();
    }

    @Override
    public void saver() { if (startup.canSave()) startup.saver(); }

    @Override
    public void crash() { startup.crash(); }

    @Override
    public void installUpdate(int idx) { startup.install(idx); }

    /** The nostalgia pack's slow things: Safe Mode opens the repair tool, and now and then the computer crashes. */
    private void retroTick() {
        bee.tick();
        if (Retro.safe() && !repairShown) {
            repairShown = true;
            open(new RepairApp());
        }
        uptime++;
        if (app == desktop && ++crashCheck >= 3600) {                  // once a minute, only while nothing is open
            crashCheck = 0;
            if (Retro.crashes() && !Retro.safe() && uptime >= 60 * 60 * 20 && Math.random() < 0.06) {
                startup.crash();
                uptime = 0;
            }
        }
    }

    /** How far the Dock is pushed down (GUI px) while it slides in or out. */
    private int dockOff() {
        float e = dockShow * dockShow * (3f - 2f * dockShow);
        return Math.round((1f - e) * (DOCK + 2));
    }

    /** True while the Dock is shown enough to be clicked (a hidden Dock lets the clicks through to the app). */
    private boolean dockActive() { return dockShow > 0.6f; }

    /** Show the Dock on the bare desktop, or when the mouse rests on the bottom edge of an app; hide it otherwise. */
    private void updateDock(int mx, int my) {
        long now = System.nanoTime();
        float dt = dockLastNs == 0 ? 0f : Math.min(0.1f, (now - dockLastNs) / 1_000_000_000f);
        dockLastNs = now;
        boolean want;
        if (app == desktop || Retro.safe()) {
            want = true;
        } else {
            boolean inX = mx >= gx && mx < gx + VIEW_W;
            boolean sticky = pressApp >= 0 || ctxApp >= 0 || menuOpen || System.currentTimeMillis() < dockFullUntil;
            int edge = dockShow > 0.5f ? dockY - 18 : gy + App.H - 3;      // shown: stay while the mouse is on the Dock; hidden: only the very bottom edge
            boolean over = inX && my >= edge;
            dockHover = over ? dockHover + dt : 0f;
            want = sticky || (over && (dockShow > 0.5f || dockHover > 0.25f));
        }
        dockShow = Math.max(0f, Math.min(1f, dockShow + (want ? dt : -dt) / 0.18f));
    }

    private void drawSafeWallpaper(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xFF000000);
        String label = Component.translatable("cutemod.safe.label").getString();
        int lw = font.width(label);
        dev.cutemod.client.os.CuteFont.draw(g, font, label, x + 3, y + MENU + 2, 0xFFBFBFBF, false);
        dev.cutemod.client.os.CuteFont.draw(g, font, label, x + w - lw - 3, y + MENU + 2, 0xFFBFBFBF, false);
        dev.cutemod.client.os.CuteFont.draw(g, font, label, x + 3, y + h - DOCK - 10, 0xFFBFBFBF, false);
        dev.cutemod.client.os.CuteFont.draw(g, font, label, x + w - lw - 3, y + h - DOCK - 10, 0xFFBFBFBF, false);
    }

    @Override
    public void home() { closeApp(app); }                   // an app asking for "home" is finished

    /** Minimize: back to the desktop, the app goes on in the background. */
    private void minimize() {
        if (app != desktop) { Sfx.click(); AppSfx.close(); open(desktop); }
    }

    /** Quit the app (end its process). */
    private void closeApp(App a) {
        if (a == desktop) return;
        running.remove(a);
        a.close();
        desktop.forget(a);
        AppSfx.close();
        if (a == beforeTm) beforeTm = null;
        if (a == app) open(a instanceof TaskManagerApp && beforeTm != null && running.contains(beforeTm) ? beforeTm : desktop);
    }

    // ---------- the Task Manager (F10) ----------
    @Override
    public List<Proc> processes() {
        List<Proc> l = new ArrayList<>();
        for (App a : running) {
            if (a instanceof TaskManagerApp) continue;
            int i = desktop.activeIndex(a);
            l.add(new Proc(a, i >= 0 ? Desktop.nameOf(i) : a.title().getString(), i, a == beforeTm || a == app));
        }
        return l;
    }

    @Override
    public void switchTo(App target) {
        if (app instanceof TaskManagerApp tm) {                          // the manager is done: it does not stay behind as a process
            running.remove(tm);
            tm.close();
            desktop.forget(tm);
        }
        beforeTm = null;
        open(target != null && running.contains(target) ? target : desktop);
    }

    @Override
    public void endTask(App target) { if (!(target instanceof TaskManagerApp)) closeApp(target); }

    /** F10 (or Ctrl+Shift+Esc): open the Task Manager over whatever is running, or close it again. */
    private void toggleTaskManager() {
        menuOpen = false; ctxApp = -1; notesOpen = false;
        if (app instanceof TaskManagerApp tm) { Sfx.click(); closeApp(tm); return; }
        for (App a : running) if (a instanceof TaskManagerApp tm) { running.remove(a); tm.close(); break; }
        beforeTm = app == desktop ? null : app;
        Sfx.click();
        animX = gx + VIEW_W / 2f; animY = menuY + MENU;
        open(new TaskManagerApp());
    }

    /** Open an app from the Dock / Start / a hotkey: bring back its process if it is running, else start it. */
    private void launchApp(int i) {
        for (App a : running) {
            if (desktop.activeIndex(a) == i) { if (a != app) open(a); return; }
        }
        AppSfx.open();                                              // a new process: the window opens
        desktop.launch(i);
    }

    @Override
    public void launch(int icon) { launchApp(icon); }

    @Override
    public void launchFrom(int icon, int screenX, int screenY) {
        animX = screenX; animY = screenY;                  // the window grows out of this spot (kept until it has grown)
        launchApp(icon);
    }

    /** Apps that are removed in CuteStore end their process (and leave the Dock). */
    private void closeRemovedApps() {
        for (App a : new ArrayList<>(running)) {
            int i = desktop.activeIndex(a);
            if (i >= 0 && !Library.available(i)) closeApp(a);
        }
    }

    private Set<Integer> runningIcons() {
        Set<Integer> s = new HashSet<>();
        for (App a : running) {
            int i = desktop.activeIndex(a);
            if (i >= 0) s.add(i);
        }
        return s;
    }

    /** Ctrl+Tab: the next running app. */
    private void cycle(int dir) {
        if (running.isEmpty()) return;
        int at = running.indexOf(app);
        int n = at < 0 ? (dir > 0 ? 0 : running.size() - 1) : Math.floorMod(at + dir, running.size());
        open(running.get(n));
    }

    @Override
    public ComputerColor color() { return color; }

    @Override
    public BlockPos pos() { return pos; }

    @Override
    public void openLink(String url) {
        Minecraft mc = Minecraft.getInstance();
        linking = true;
        mc.setScreen(new ConfirmLinkScreen(accepted -> {
            linking = false;
            if (accepted) {
                try {
                    Util.getPlatform().openUri(URI.create(url));
                } catch (Exception ignored) {
                }
            }
            mc.setScreen(this);
        }, url, true));
    }

    @Override
    public void submitScore(ComputerColor game, int score) {
        // only the computer's own game counts for the record stored in the block
        if (game == color) PacketDistributor.sendToServer(new ScorePayload(pos, score));
    }

    @Override
    public int absX() { return gx; }

    @Override
    public int absY() { return gy; }

    // ---------- Screen ----------
    @Override
    protected void init() {
        panelW = VIEW_W + PAD * 2;
        panelH = HEADER + MENU + TB + App.H + FOOTER;
        // the monitor is a bit larger than before: the GUI scale grows (up to ZOOM_MAX) while this screen is open, as far as the window allows
        var win = Minecraft.getInstance().getWindow();
        double base = win.calculateScale(Minecraft.getInstance().options.guiScale().get(), Minecraft.getInstance().isEnforceUnicode());
        double zoom = Math.max(1.0, Math.min(ZOOM_MAX, Math.min(
                win.getWidth() / (base * (panelW + 12)), win.getHeight() / (base * (panelH + 12)))));
        win.setGuiScale(base * zoom);
        width = win.getGuiScaledWidth();
        height = win.getGuiScaledHeight();
        left = (width - panelW) / 2;
        top = (height - panelH) / 2;
        menuY = top + HEADER;
        gx = left + PAD;
        gy = menuY + MENU + TB;       // top-left of the app area
        dockY = gy + App.H - DOCK;      // the Dock lies over the bottom of the app area (it does not take room of its own)
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private int netPing = 170;

    private void sendPing(boolean open) {
        String game = app instanceof dev.cutemod.client.os.GameApp ga ? ga.gameId() : "";
        Net.ping(open, desktop.legacyIndex(app), game);
    }

    private boolean cursorHidden;

    /** Hides the system cursor while our own cursor is drawn (the mouse stays free, unlike when it is grabbed). */
    private void hideCursor(boolean hide) {
        if (hide == cursorHidden) return;
        cursorHidden = hide;
        long win = Minecraft.getInstance().getWindow().getWindow();
        org.lwjgl.glfw.GLFW.glfwSetInputMode(win, org.lwjgl.glfw.GLFW.GLFW_CURSOR,
                hide ? org.lwjgl.glfw.GLFW.GLFW_CURSOR_HIDDEN : org.lwjgl.glfw.GLFW.GLFW_CURSOR_NORMAL);
    }

    @Override
    public void removed() {
        Hell.screenClosed();
        sendPing(false);
        hideCursor(false);
        Sfx.stopFan();
        if (!linking) Sfx.jingleNow(Sfx.shutdown());
        if (!linking) dev.cutemod.client.os.Behind.onLeave();
        for (App a : new ArrayList<>(running)) a.close();        // leaving the computer ends every process
        if (!running.contains(app)) app.close();
        Progress.save();
        Library.save();
        var mc = Minecraft.getInstance();
        mc.getWindow().setGuiScale(mc.getWindow().calculateScale(mc.options.guiScale().get(), mc.isEnforceUnicode()));   // back to the normal GUI scale
        super.removed();
    }

    private ComputerBlockEntity be() {
        var level = Minecraft.getInstance().level;
        if (level != null && level.getBlockEntity(pos) instanceof ComputerBlockEntity b) return b;
        return null;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        super.render(g, mouseX, mouseY, partial);

        // --- fixed timestep for the apps ---
        long now = System.nanoTime();
        if (lastNs == 0) lastNs = now;
        acc += now - lastNs;
        lastNs = now;
        if (acc > 100_000_000L) acc = 100_000_000L;
        Sfx.keepFan();
        if (mouseX != lastMx || mouseY != lastMy) { lastMx = mouseX; lastMy = mouseY; idle = 0; }
        app.mouse(mouseX - gx, mouseY - gy);
        while (acc >= STEP_NS) {
            acc -= STEP_NS;
            startup.tick();
            Widgets.tick();
            Hell.tick();                                                  // the crimson look: did the player stay for the whole two minutes?
            if (++netPing >= 180) { netPing = 0; sendPing(true); }       // CuteNet: "I am at a computer" every 3 seconds
            if (animT < 1f) animT = Math.min(1f, animT + ANIM_STEP);
            else animX = Float.NaN;
            if (!startup.active()) {                       // nothing runs behind the boot / lock / screensaver
                app.tick();
                for (App a : new ArrayList<>(running)) if (a != app && a.background()) a.tick();
                haunt.tick(app);
                if (app.busy()) idle = 0;
                else if (++idle >= IDLE_TICKS && startup.canSave()) { startup.saver(); idle = 0; }
            }
            if (!startup.active()) { Progress.tick(); retroTick(); }      // pop-ups wait until the desktop is visible
            Library.tick();
            Market.tick();
            if (++purge % 20 == 0) closeRemovedApps();
        }

        // --- computer casing ---
        int body = 0xFF000000 | color.bodyColor;
        boolean darkBody = luminance(color.bodyColor) < 110;
        int textCol = darkBody ? 0xFFFFFFFF : 0xFF3A2A3A;
        int viewH = MENU + TB + App.H;
        drawCasing(g, body, darkBody);
        g.fill(gx - 4, menuY - 4, gx + VIEW_W + 4, menuY + viewH + 4, 0xFF1B1422);
        // --- wallpaper behind the menu bar, the apps and the Dock ---
        if (Retro.safe()) {
            drawSafeWallpaper(g, gx, menuY, VIEW_W, viewH);                      // Safe Mode: plain black, no frills
        } else {
            Wallpaper.drawCached(g, gx, menuY, VIEW_W, viewH, color.bodyColor, Wallpaper.shown());
            if (Theme.custom()) Theme.overlay(g, gx, menuY, VIEW_W, viewH);        // Frutiger Aero: sky glow and bubbles, Kawaii: hearts and sparkles
            if (Skin.dark()) g.fill(gx, menuY, gx + VIEW_W, menuY + viewH, 0x99080614);   // dark mode: the wallpaper dims
        }

        // --- the window (title bar + app) grows out of its icon when it opens ---
        g.pose().pushPose();
        if (animT < 1f) {
            float e = 1f - (1f - animT) * (1f - animT) * (1f - animT);      // ease out
            float sc = 0.12f + 0.88f * e;
            float ax = Float.isNaN(animX) ? gx + VIEW_W / 2f : animX, ay = Float.isNaN(animX) ? dockY : animY;
            g.pose().translate(ax * (1 - sc), ay * (1 - sc), 0);
            g.pose().scale(sc, sc, 1f);
        }

        // --- window title bar with the "traffic lights" (not on the bare desktop) ---
        boolean onDesktop = app == desktop;
        int tbY = gy - TB;
        if (!onDesktop) {
            if (Skin.dark()) {
                g.fillGradient(gx, tbY, gx + VIEW_W, gy, 0xFF2E2742, 0xFF231D35);
                g.fill(gx, gy - 1, gx + VIEW_W, gy, 0xFF14101E);
            } else if (Theme.custom()) {
                Theme.titleBar(g, gx, tbY, VIEW_W, gy - tbY);
            } else {
                g.fillGradient(gx, tbY, gx + VIEW_W, gy, 0xFFEEE9F3, 0xFFD9D3E3);
                g.fill(gx, gy - 1, gx + VIEW_W, gy, 0xFFB9B0C8);
            }
            boolean overLights = mouseX >= gx + 2 && mouseX < gx + 36 && mouseY >= tbY && mouseY < gy;
            int[] cols = {0xFFFF5F57, 0xFFFEBC2E, 0xFF28C840};
            for (int i = 0; i < 3; i++) {
                int cx = gx + 8 + i * 10, cy = tbY + TB / 2;
                circle(g, cx, cy, 3, overLights ? cols[i] : (cols[i] & 0x00FFFFFF) | 0xFF000000);
                circle(g, cx, cy, 2, shadeUp(cols[i]));
                if (i == 2) circle(g, cx, cy, 3, 0xFFBDB6C8);               // green: not used, grey
                if (overLights && i == 0) {                                  // x = quit
                    g.fill(cx - 1, cy - 1, cx, cy, 0xFF6A1E1A); g.fill(cx + 1, cy - 1, cx + 2, cy, 0xFF6A1E1A);
                    g.fill(cx, cy, cx + 1, cy + 1, 0xFF6A1E1A);
                    g.fill(cx - 1, cy + 1, cx, cy + 2, 0xFF6A1E1A); g.fill(cx + 1, cy + 1, cx + 2, cy + 2, 0xFF6A1E1A);
                }
                if (overLights && i == 1) g.fill(cx - 1, cy, cx + 2, cy + 1, 0xFF6A4A0A);   // - = minimize
            }
            Component title = app.title();
            dev.cutemod.client.os.CuteFont.draw(g, font, title, gx + (VIEW_W - font.width(title)) / 2, tbY + 2, Skin.dark() ? 0xFFEDE6FA : Theme.titleText(), false);
        }

        // --- app ---
        g.enableScissor(gx, gy, gx + VIEW_W, gy + App.H);
        g.pose().pushPose();
        g.pose().translate(gx, gy, 0);
        Skin.appsKeepColours(app != desktop);       // dark mode darkens the shell, not the apps
        try { app.render(g, mouseX - gx, mouseY - gy); } finally { Skin.appsKeepColours(false); }
        g.pose().pushPose();
        g.pose().translate(0, 0, 50);           // pop-ups and creepy events lie above the text of the app (else the text shines through the ad)
        haunt.render(g, mouseX - gx, mouseY - gy);
        g.pose().popPose();
        g.pose().pushPose();
        g.pose().translate(0, 0, 100);          // the bee, its bubble and the notifications lie above everything in the app (text from below must not shine through)
        bee.render(g, mouseX - gx, mouseY - gy);
        Progress.renderToast(g);
        g.pose().popPose();
        g.pose().popPose();
        g.disableScissor();
        g.pose().popPose();

        // --- menu bar ---
        if (Theme.custom()) Theme.menuBar(g, gx, menuY, VIEW_W, MENU);
        else g.fill(gx, menuY, gx + VIEW_W, menuY + MENU, 0x99101018);
        drawLogo(g, gx + 5, menuY + 3);
        Component name = (onDesktop ? Component.translatable("cutemod.os.title") : app.title()).copy().withStyle(ChatFormatting.BOLD);
        dev.cutemod.client.os.CuteFont.draw(g, font, name, gx + 19, menuY + 2, 0xFFFFFFFF, false);
        String clock = LocalDateTime.now().format(CLOCK);
        dev.cutemod.client.os.CuteFont.draw(g, font, clock, gx + VIEW_W - 5 - dev.cutemod.client.os.CuteFont.width(font, clock), menuY + 2, 0xFFFFFFFF, false);
        String coinText = Integer.toString(Progress.coins());
        int coinX = gx + VIEW_W - 5 - dev.cutemod.client.os.CuteFont.width(font, clock) - 10 - dev.cutemod.client.os.CuteFont.width(font, coinText);
        Progress.drawCoin(g, coinX - 10, menuY + 2);
        dev.cutemod.client.os.CuteFont.draw(g, font, coinText, coinX, menuY + 2, 0xFFFFE680, false);
        int leftEdge = coinX - 10;

        // --- the notification centre: a bell in the menu bar and a list that drops down from it ---
        bellX = leftEdge - 13;
        drawBell(g, bellX, menuY + 2);
        // the status of the app: only in the room that is left between the name and the bell (long ones are cut)
        String statusText = app.status().getString();
        int sx = gx + 19 + dev.cutemod.client.os.CuteFont.width(font, name) + 10;
        int statusRoom = bellX - 8 - sx;
        if (!statusText.isEmpty() && statusRoom >= 24) {
            dev.cutemod.client.os.CuteFont.draw(g, font, dev.cutemod.client.os.CuteFont.cut(font, statusText, statusRoom), sx, menuY + 2, 0xCCFFFFFF, false);
        }
        if (notesOpen) drawNotes(g, mouseX, mouseY);

        // --- Dock ---
        if (pressApp >= 0 && dragging) dock.setDrag(pressApp, dock.slotAt(gx, VIEW_W, mouseX), mouseX, mouseY, mouseY < dockY - 12);
        else dock.clearDrag();
        updateDock(mouseX, mouseY);
        int off = dockOff();
        if (off > 0) g.enableScissor(gx, menuY, gx + VIEW_W, gy + App.H);      // sliding: the Dock does not reach out of the screen
        dock.render(g, desktop, app, color.bodyColor, gx, dockY + off, VIEW_W, mouseX, mouseY, app != desktop, runningIcons());
        if (off > 0) g.disableScissor();

        if (System.currentTimeMillis() < dockFullUntil) {        // the Dock is full: tell why the app did not pin
            String note = Component.translatable("cutemod.os.dock.full", DockLayout.MAX).getString();
            int nw = font.width(note) + 10, nx = gx + (VIEW_W - nw) / 2;
            g.fill(nx, dockY - 16, nx + nw, dockY - 3, 0xEE000000);
            dev.cutemod.client.os.CuteFont.draw(g, font, note, nx + 5, dockY - 13, 0xFFFFFFFF, false);
        }

        // --- the Start menu: every app, plus Desktop / Lock / Quit ---
        if (menuOpen) start.render(g, smX(), smY(), mouseX, mouseY, desktop, color.bodyColor);

        // --- right-click menu of a Dock icon ---
        if (ctxApp >= 0) {
            int n = ctxItems.size(), w = ctxW(), lx = ctxLeft(w), ly = dockY - 2 - n * 12;
            g.pose().pushPose();
            g.pose().translate(0, 0, 60);
            g.fill(lx - 1, ly - 1, lx + w + 1, ly + n * 12 + 1, 0x55FFFFFF);
            for (int i = 0; i < n; i++) {
                boolean hov = mouseX >= lx && mouseX < lx + w && mouseY >= ly + i * 12 && mouseY < ly + i * 12 + 12;
                g.fill(lx, ly + i * 12, lx + w, ly + i * 12 + 12, hov ? 0xFFB57BD6 : 0xF21B1422);
                dev.cutemod.client.os.CuteFont.draw(g, font, ctxLabel(ctxItems.get(i)), lx + 5, ly + i * 12 + 2, 0xFFFFFFFF, false);
            }
            g.pose().popPose();
        }

        // --- boot / password / welcome / screensaver cover the whole screen ---
        if (startup.active()) {
            menuOpen = false;
            g.pose().pushPose();
            g.pose().translate(0, 0, 400);      // above everything, including the Dock badges (they sit at z 50)
            startup.render(g, gx, menuY, VIEW_W, viewH, color.bodyColor, partial);
            g.pose().popPose();
        }

        // --- our own cursor instead of the system arrow: glossy blue in Frutiger Aero, a cute pink one in the classic look ---
        hideCursor(true);
        if (Theme.custom()) Theme.cursor(g, mouseX, mouseY, false);
        else Theme.cursorClassic(g, mouseX, mouseY);

        // --- footer: record + hint (a long hint wraps to a second line instead of leaving the screen) ---
        Component rec = null;
        boolean spooky = false;
        if (app.showRecord()) {
            ComputerBlockEntity be = be();
            spooky = haunt.recordHaunted();
            rec = spooky
                    ? Component.translatable("cutemod.ui.record", 999999, Component.translatable("cutemod.haunt.holder"))
                    : (be == null || be.getHighScore() <= 0)
                    ? Component.translatable("cutemod.ui.record_none")
                    : Component.translatable("cutemod.ui.record", be.getHighScore(), be.getHolder());
        }
        int maxW = panelW - PAD * 2;
        var hintLines = new java.util.ArrayList<>(font.split(app.hint(), maxW));
        while (hintLines.size() > 2) hintLines.remove(hintLines.size() - 1);
        if (!Retro.hints()) hintLines.clear();
        int hintW = 0;
        for (var l : hintLines) hintW = Math.max(hintW, font.width(l));
        boolean sameRow = rec != null && hintLines.size() <= 1 && font.width(rec) + 10 + hintW <= maxW;
        int rows = hintLines.size() + (rec != null && !sameRow ? 1 : 0);
        int fy = dockY + DOCK + Math.max(1, (FOOTER - rows * 9) / 2) + 1;
        if (rec != null) {
            dev.cutemod.client.os.CuteFont.draw(g, font, rec, left + PAD, fy, spooky ? 0xFFD9302A : textCol, false);
            if (!sameRow) fy += 9;
        }
        for (var l : hintLines) {
            dev.cutemod.client.os.CuteFont.draw(g, font, l, left + panelW - PAD - font.width(l), fy, textCol, false);
            fy += 9;
        }
    }

    // ---------- Dock context menu ----------
    /** Rows of the Dock menu: 0 take off the Dock, 1 quit, 3 delete a folder, 4 move a folder to the desktop, 5 new folder. */
    private static final int BAR_CTX = Integer.MAX_VALUE;     // the menu of the empty glass strip (not of an icon)

    private String ctxLabel(int item) {
        String key = switch (item) {
            case 0 -> "cutemod.os.dock.unpin";
            case 1 -> "cutemod.os.dock.quit";
            case 3 -> "cutemod.folder.delete";
            case 4 -> "cutemod.folder.to_desktop";
            default -> "cutemod.folder.new";
        };
        return Component.translatable(key).getString();
    }

    /** "New folder" in the Dock: it is pinned there and opens ready to be named. */
    private void newDockFolder() {
        int id = Folders.create(Component.translatable("cutemod.folder.default").getString());
        if (!DockLayout.pin(id)) { Folders.deskAdd(id); dockFullUntil = System.currentTimeMillis() + 2500; }
        FolderApp.pendingRename = id;
        launchApp(id);
    }

    private int ctxW() {
        int w = 0;
        for (int it : ctxItems) w = Math.max(w, font.width(ctxLabel(it)));
        return w + 10;
    }

    private int ctxLeft(int w) { return Math.max(gx + 2, Math.min(gx + VIEW_W - w - 2, ctxX - w / 2)); }

    // ---------- Start menu ----------
    private int smX() { return gx + 2; }

    private int smY() { return menuY + MENU; }

    private void openStart() {
        menuOpen = true;
        start.open();
    }

    /** Open an app chosen in the Start menu: it grows out of the Start button. */
    private void launchFromStart(int k) {
        menuOpen = false;
        animX = gx + 8; animY = menuY + MENU;
        if (desktop.activeIndex(app) != k) launchApp(k);
    }

    private static void circle(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    private static int shadeUp(int argb) {
        int r = Math.min(255, ((argb >> 16) & 255) + 28), gr = Math.min(255, ((argb >> 8) & 255) + 28), b = Math.min(255, (argb & 255) + 28);
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }

    /** A tiny pixel heart, the "logo" of Cute OS. */
    private static void drawLogo(GuiGraphics g, int x, int y) {
        int c = 0xFFFFFFFF;
        g.fill(x + 1, y, x + 3, y + 1, c);
        g.fill(x + 4, y, x + 6, y + 1, c);
        g.fill(x, y + 1, x + 7, y + 3, c);
        g.fill(x + 1, y + 3, x + 6, y + 4, c);
        g.fill(x + 2, y + 4, x + 5, y + 5, c);
        g.fill(x + 3, y + 5, x + 4, y + 6, c);
    }

    // ---------- the notification centre ----------
    private boolean notesOpen;
    private int bellX = -1;
    /** The panel is NOTE_W wide; every text in it is the same small size (lines are 8 px high) and a long note wraps onto a second line. */
    private static final int NOTE_W = Math.min(176, App.W - 8), NOTE_LINE = 8, NOTE_PAD = 3, NOTE_HEAD = 17, NOTE_MAX = 104, NOTE_LINES = 2;

    private void drawBell(GuiGraphics g, int x, int y) {
        int c = Progress.unread() > 0 ? 0xFFFFE680 : 0xCCFFFFFF;
        g.fill(x + 3, y, x + 5, y + 1, c);
        g.fill(x + 2, y + 1, x + 6, y + 2, c);
        g.fill(x + 1, y + 2, x + 7, y + 6, c);
        g.fill(x, y + 6, x + 8, y + 7, c);
        g.fill(x + 3, y + 7, x + 5, y + 8, c);
        if (Retro.dnd()) g.fill(x - 1, y + 4, x + 9, y + 5, 0xFFE5486F);                // crossed out: do not disturb
        if (Progress.unread() > 0) {
            g.fill(x + 5, y - 1, x + 10, y + 4, 0xFFE5486F);
            String n = Integer.toString(Math.min(9, Progress.unread()));
            g.pose().pushPose();
            g.pose().translate(x + 6.5F, y - 0.5F, 0);
            g.pose().scale(0.5F, 0.5F, 1F);
            g.drawString(font, n, 0, 0, 0xFFFFFFFF, false);
            g.pose().popPose();
        }
    }

    private int notesX() { return gx + VIEW_W - NOTE_W - 3; }

    private int notesY() { return menuY + MENU + 2; }

    /** Width of the text column: the panel minus the icon on the left and the time on the right. */
    private int noteTextW() { return NOTE_W - 19 - 7 - CuteFont.widthSmall(font, "00:00") - 5; }

    /** The wrapped lines of the newest notes that fit under the header (row i belongs to Progress.history().get(i)). */
    private List<List<String>> noteRows() {
        List<List<String>> rows = new ArrayList<>();
        int used = 0, tw = noteTextW();
        for (String[] n : Progress.history()) {
            List<String> ls = CuteFont.wrapSmall(font, n[1], tw, NOTE_LINES);
            int rh = NOTE_PAD * 2 + Math.max(1, ls.size()) * NOTE_LINE;
            if (!rows.isEmpty() && used + rh > NOTE_MAX) break;
            rows.add(ls);
            used += rh;
        }
        return rows;
    }

    private int notesH(List<List<String>> rows) {
        int list = 0;
        for (List<String> ls : rows) list += NOTE_PAD * 2 + Math.max(1, ls.size()) * NOTE_LINE;
        if (rows.isEmpty()) list = 18;
        return NOTE_HEAD + 3 + list + 2;
    }

    /** {x, y, w, h} of the pill buttons in the header: 0 = Quiet (do not disturb), 1 = Clear. The widths follow the text, so nothing overflows. */
    private int[] noteBtn(int x, int hy, int b) {
        String quiet = Component.translatable(Retro.dnd() ? "cutemod.notes.dnd_on" : "cutemod.notes.dnd").getString();
        String clear = Component.translatable("cutemod.notes.clear").getString();
        int w1 = CuteFont.widthSmall(font, clear) + 10, w0 = CuteFont.widthSmall(font, quiet) + 10;
        int x1 = x + NOTE_W - 6 - w1, x0 = x1 - 3 - w0;
        return b == 0 ? new int[]{x0, hy, w0, 11} : new int[]{x1, hy, w1, 11};
    }

    private void drawNotes(GuiGraphics g, int mx, int my) {
        Theme.Pal p = Theme.pal();
        List<List<String>> rows = noteRows();
        List<String[]> hist = Progress.history();
        int x = notesX(), y = notesY(), h = notesH(rows);
        g.pose().pushPose();
        g.pose().translate(0, 0, 300);
        Theme.card(g, x, y, NOTE_W, h);                                   // a rounded card in the colours of the look that is on
        int sep = p.bevel() ? 0xFF808080 : 0x44FFFFFF;

        // the header: the title on the left, two pills on the right
        int hy = y + 4;
        CuteFont.drawSmall(g, font, Component.translatable("cutemod.notes.title").getString(), x + 8, hy + 2, p.label());
        for (int b = 0; b < 2; b++) {
            int[] r = noteBtn(x, hy, b);
            boolean hov = mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3];
            boolean quiet = b == 0 && Retro.dnd();
            int face = quiet ? 0xFFE5486F : hov ? p.buttonHover() : p.button();
            if (p.bevel()) Theme.bevel(g, r[0], r[1], r[2], r[3], !hov, face);
            else Theme.rgrad(g, r[0], r[1], r[2], r[3], r[3] / 2, Theme.blend(face, 0xFFFFFFFF, 0.25f), face);
            String t = b == 0 ? Component.translatable(Retro.dnd() ? "cutemod.notes.dnd_on" : "cutemod.notes.dnd").getString()
                    : Component.translatable("cutemod.notes.clear").getString();
            CuteFont.drawSmall(g, font, t, r[0] + (r[2] - CuteFont.widthSmall(font, t)) / 2, r[1] + 2, p.bevel() && !quiet ? p.text() : 0xFFFFFFFF);
        }
        g.fill(x + 7, y + NOTE_HEAD, x + NOTE_W - 7, y + NOTE_HEAD + 1, sep);

        // the notes: an icon, the text (one size, wrapped) and the time on the right
        int ry = y + NOTE_HEAD + 3;
        if (hist.isEmpty()) {
            String e = CuteFont.cutSmall(font, Component.translatable("cutemod.notes.empty").getString(), NOTE_W - 16);
            CuteFont.drawSmall(g, font, e, x + (NOTE_W - CuteFont.widthSmall(font, e)) / 2, ry + 6, p.muted());
        }
        int tx = x + 19;
        for (int i = 0; i < rows.size(); i++) {
            List<String> ls = rows.get(i);
            String[] n = hist.get(i);
            int rh = NOTE_PAD * 2 + Math.max(1, ls.size()) * NOTE_LINE;
            if (i > 0) g.fill(x + 7, ry, x + NOTE_W - 7, ry + 1, sep);
            int ix = x + 8, iy = ry + NOTE_PAD;
            if ("1".equals(n[2])) {                                        // a letter: a little envelope
                g.fill(ix, iy + 1, ix + 7, iy + 6, p.accent());
                g.fill(ix + 1, iy + 2, ix + 6, iy + 3, p.onAccent());
                g.fill(ix + 2, iy + 3, ix + 5, iy + 4, p.onAccent());
            } else {
                Progress.drawCoin(g, ix, iy);
            }
            for (int l = 0; l < ls.size(); l++) CuteFont.drawSmall(g, font, ls.get(l), tx, ry + NOTE_PAD + l * NOTE_LINE, p.text());
            CuteFont.drawSmall(g, font, n[0], x + NOTE_W - 7 - CuteFont.widthSmall(font, n[0]), ry + NOTE_PAD, p.muted());
            ry += rh;
        }
        g.pose().popPose();
    }

    /** A click while the notification centre is open: true if it was used. */
    private boolean notesClick(int mx, int my) {
        int x = notesX(), y = notesY(), h = notesH(noteRows());
        if (mx < x || mx >= x + NOTE_W || my < y || my >= y + h) return false;
        for (int b = 0; b < 2; b++) {
            int[] r = noteBtn(x, y + 4, b);
            if (mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3]) {
                if (b == 1) Progress.clearHistory(); else Retro.setDnd(!Retro.dnd());
            }
        }
        return true;
    }

    private static int shade(int rgb, float f) {
        int r = Math.min(255, Math.max(0, Math.round(((rgb >> 16) & 255) * f)));
        int gr = Math.min(255, Math.max(0, Math.round(((rgb >> 8) & 255) * f)));
        int bl = Math.min(255, Math.max(0, Math.round((rgb & 255) * f)));
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }

    /** A filled rectangle with small rounded corners and a vertical colour gradient. */
    private static void roundFill(GuiGraphics g, int x0, int y0, int x1, int y1, int top, int bottom) {
        int[] inset = {4, 2, 1, 1};
        int h = y1 - y0;
        for (int row = 0; row < h; row++) {
            int d = Math.min(row, h - 1 - row);
            int in = d < 4 ? inset[d] : 0;
            float t = h <= 1 ? 0f : row / (float) (h - 1);
            int c = 0xFF000000;
            for (int sh = 16; sh >= 0; sh -= 8) {
                int a = (top >> sh) & 255, b = (bottom >> sh) & 255;
                c |= Math.round(a + (b - a) * t) << sh;
            }
            g.fill(x0 + in, y0 + row, x1 - in, y0 + row + 1, c);
        }
    }

    /** The monitor casing: rounded gradient plastic, a recessed inner panel and tidy ventilation grilles on the sides. */
    private void drawCasing(GuiGraphics g, int body, boolean darkBody) {
        int x0 = left - 2, y0 = top - 2, x1 = left + panelW + 2, y1 = top + panelH + 2;
        int light = shade(body, 1.16f), dark = shade(body, 0.80f);
        roundFill(g, left - 3, top - 3, x1 + 1, y1 + 1, 0xFF2A2030, 0xFF2A2030);        // outline
        roundFill(g, x0, y0, x1, y1, light, dark);                                        // plastic
        // rim light and shade following the rounded outline
        g.fill(x0 + 4, y0, x1 - 4, y0 + 1, 0x88FFFFFF);
        g.fill(x0 + 2, y0 + 1, x0 + 4, y0 + 2, 0x66FFFFFF);
        g.fill(x1 - 4, y0 + 1, x1 - 2, y0 + 2, 0x44FFFFFF);
        g.fill(x0, y0 + 4, x0 + 1, y1 - 4, 0x44FFFFFF);
        g.fill(x1 - 1, y0 + 4, x1, y1 - 4, 0x33000000);
        g.fill(x0 + 4, y1 - 1, x1 - 4, y1, 0x55000000);
        // recessed inner panel: dark edge top/left, light edge bottom/right
        int ix0 = x0 + 3, iy0 = y0 + 3, ix1 = x1 - 3, iy1 = y1 - 3;
        g.fill(ix0 + 1, iy0, ix1 - 1, iy0 + 1, 0x40000000);
        g.fill(ix0, iy0 + 1, ix0 + 1, iy1 - 1, 0x40000000);
        g.fill(ix0 + 1, iy1 - 1, ix1 - 1, iy1, 0x40FFFFFF);
        g.fill(ix1 - 1, iy0 + 1, ix1, iy1 - 1, 0x40FFFFFF);
        // ventilation grilles in the side frames: four short slits, evenly spaced, the same on both sides
        int cy = top + panelH / 2;
        for (int i = 0; i < 4; i++) {
            int vy = cy - 6 + i * 3;
            g.fill(x0 + 5, vy, x0 + 8, vy + 1, 0x55000000);
            g.fill(x0 + 5, vy + 1, x0 + 8, vy + 2, 0x22FFFFFF);
            g.fill(x1 - 8, vy, x1 - 5, vy + 1, 0x55000000);
            g.fill(x1 - 8, vy + 1, x1 - 5, vy + 2, 0x22FFFFFF);
        }
    }

    private static int luminance(int rgb) {
        int r = (rgb >> 16) & 255, gr = (rgb >> 8) & 255, b = rgb & 255;
        return (int) (0.299 * r + 0.587 * gr + 0.114 * b);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        idle = 0;
        if (startup.active()) { startup.click(); return true; }
        int mx = (int) Math.floor(mouseX), my = (int) Math.floor(mouseY);

        Sfx.click();
        if (bellX >= 0 && mx >= bellX - 2 && mx < bellX + 11 && my >= menuY && my < menuY + MENU) {     // the bell
            notesOpen = !notesOpen;
            if (notesOpen) { Progress.markRead(); menuOpen = false; }
            return true;
        }
        if (notesOpen) {
            if (notesClick(mx, my)) return true;
            notesOpen = false;
        }
        if (ctxApp >= 0) {                                      // the right-click menu of a Dock icon
            int n = ctxItems.size(), w = ctxW(), lx0 = ctxLeft(w), ly0 = dockY - 2 - n * 12;
            int which = ctxApp, row = (my - ly0) / 12;
            boolean inside = mx >= lx0 && mx < lx0 + w && my >= ly0 && my < ly0 + n * 12;
            ctxApp = -1;
            if (inside && row >= 0 && row < n) {
                switch (ctxItems.get(row)) {
                    case 0 -> DockLayout.unpin(which);
                    case 1 -> { for (App a : new ArrayList<>(running)) if (desktop.activeIndex(a) == which) closeApp(a); }
                    case 3 -> Folders.delete(which);
                    case 4 -> { Folders.deskAdd(which); DockLayout.unpin(which); }
                    default -> newDockFolder();
                }
                return true;
            }
        }
        boolean onLogo = mx >= gx + 2 && mx < gx + 16 && my >= menuY && my < menuY + MENU;
        if (menuOpen) {                                         // the Start menu eats the click
            int r = start.click(mx, my, button, smX(), smY(), desktop);
            if (r == StartMenu.OUTSIDE) { menuOpen = false; return true; }     // a click on the logo closes it too
            if (r >= StartMenu.BTN) {
                menuOpen = false;
                switch (r - StartMenu.BTN) {
                    case 0 -> minimize();
                    case 1 -> startup.lock();
                    default -> onClose();
                }
            } else if (r >= StartMenu.PIN) {                    // right-click: pin / unpin
                int k = r - StartMenu.PIN;
                if (!DockLayout.pinned(k) && DockLayout.full()) dockFullUntil = System.currentTimeMillis() + 2500;
                else DockLayout.toggle(k);
            } else if (r >= 0) {
                launchFromStart(r);
            }
            return true;
        }
        if (onLogo) {
            openStart();
            return true;
        }
        int icon = dockActive() ? dock.hit(gx, dockY + dockOff(), VIEW_W, mx, my, app != desktop) : -1;
        if (icon >= 0) {
            if (button == 1) {
                ctxApp = icon; ctxX = mx;
                ctxItems.clear();
                if (Items.isFolder(icon)) ctxItems.add(4);
                if (DockLayout.pinned(icon)) ctxItems.add(0);
                if (Items.isFolder(icon)) ctxItems.add(3);
                if (runningIcons().contains(icon)) ctxItems.add(1);
                if (ctxItems.isEmpty()) ctxApp = -1;
                return true;
            }
            pressApp = icon; pressX = mx; pressY = my; dragging = false;   // it opens on release, unless dragged
            return true;
        }
        if (dockActive() && dock.overBar(mx, my)) {                       // the glass strip itself: it is above the app, so it takes the click
            if (button == 1) {                                           // right click on the empty glass: a new folder
                ctxApp = BAR_CTX; ctxX = mx;
                ctxItems.clear();
                ctxItems.add(5);
            }
            return true;
        }
        int lx = mx - gx, ly = my - gy;
        if (lx >= 0 && lx < VIEW_W && ly >= 0 && ly < App.H) {
            if (animT < 1f) return true;                       // not while the window is still growing
            if (!bee.click(lx, ly) && !haunt.click(lx, ly, button)) app.click(lx, ly, button);
            return true;
        }
        if (app != desktop && lx >= 2 && lx < 36 && ly >= -TB && ly < 0) {       // traffic lights
            int light = (lx - 3) / 10;
            if (light == 0) closeApp(app);                                        // red: quit the app (end the process)
            else if (light == 1) minimize();                                      // yellow: minimize, it keeps running
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (startup.active()) return true;
        if (pressApp >= 0 && button == 0) {
            if (!dragging && Math.abs((int) mouseX - pressX) + Math.abs((int) mouseY - pressY) > 4) dragging = true;
            return true;
        }
        int lx = (int) Math.floor(mouseX - gx), ly = (int) Math.floor(mouseY - gy);
        if (app.drag(lx, ly, button)) return true;
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (pressApp >= 0 && button == 0) {
            int which = pressApp, mx = (int) Math.floor(mouseX), my = (int) Math.floor(mouseY);
            boolean wasDragged = dragging;
            int slot = dock.slotAt(gx, VIEW_W, mx);
            pressApp = -1;
            dragging = false;
            dock.clearDrag();
            if (wasDragged) {
                if (my < dockY - 12) {                                  // dropped out of the Dock
                    DockLayout.unpin(which);
                    if (Items.isFolder(which)) {                        // a folder lands on the desktop where it was dropped
                        Folders.deskAdd(which);
                        Folders.deskMove(which, mx - gx - Folders.DESK_W / 2, my - gy - 16);
                    }
                }
                else if (!DockLayout.pinned(which) && DockLayout.full()) dockFullUntil = System.currentTimeMillis() + 2500;
                else DockLayout.move(which, slot);
            } else if (desktop.activeIndex(app) != which) {
                animX = dock.centerX(which, gx, VIEW_W); animY = dockY;   // grows out of its Dock icon
                launchApp(which);
            }
            return true;
        }
        if (app.release((int) Math.floor(mouseX - gx), (int) Math.floor(mouseY - gy), button)) return true;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        idle = 0;
        if (startup.active()) return true;
        if (menuOpen) return start.scroll(scrollY, desktop);
        if (app.scroll(scrollY)) return true;
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        idle = 0;
        if (startup.key(keyCode)) return true;
        if (!startup.active() && (keyCode == 299 || (keyCode == 256 && hasControlDown() && hasShiftDown()))) {   // F10 (GLFW_KEY_F10 = 299; 291 is F2), or Ctrl+Shift+Esc
            toggleTaskManager();
            return true;
        }
        if (keyCode == 256 && notesOpen) { notesOpen = false; return true; }
        if (keyCode == 256 && (menuOpen || ctxApp >= 0)) {                    // Esc closes menus first (the search is cleared before that)
            if (menuOpen && ctxApp < 0 && start.clearQuery()) return true;
            menuOpen = false; ctxApp = -1;
            return true;
        }
        if (hotkey(keyCode)) return true;
        if (menuOpen) {                                                       // the open Start menu takes the keys: search, Up / Down, Enter
            int r = start.key(keyCode, desktop);
            if (keyCode == 259) Sfx.key();                                    // Backspace in the search
            if (r >= 0) { launchFromStart(r); return true; }
            return true;
        }
        if (app.key(keyCode, modifiers)) {
            if (keyCode == 259) Sfx.key();                                    // Backspace in a text field
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    /** Hotkeys (all with Ctrl): W close, M or D minimize, Tab switch, L lock, Q leave, Space Start, 1-9 the Dock apps. */
    private boolean hotkey(int key) {
        if (!hasControlDown()) return false;
        switch (key) {
            case 87 -> closeApp(app);                                    // W
            case 77, 68 -> minimize();                                   // M, D
            case 258 -> cycle(hasShiftDown() ? -1 : 1);                  // Tab
            case 76 -> startup.lock();                                   // L
            case 81 -> onClose();                                        // Q
            case 32 -> { if (menuOpen) menuOpen = false; else openStart(); }   // Space
            default -> {
                if (key >= 49 && key <= 57) {                            // 1..9
                    List<Integer> pinned = DockLayout.list();
                    int n = key - 49;
                    if (n < pinned.size()) { Sfx.click(); menuOpen = false; launchApp(pinned.get(n)); }
                    return true;
                }
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        idle = 0;
        if (startup.charTyped(codePoint)) return true;
        boolean printable = codePoint >= 32 && codePoint != 127;
        if (menuOpen) {                                                       // the Start menu search
            boolean used = start.charTyped(codePoint);
            if (used && printable) Sfx.key();
            return used;
        }
        if (app.charTyped(codePoint)) {                                       // typing anywhere (search, notes, mail, terminal...): a key click for every letter
            if (printable) Sfx.key();
            return true;
        }
        return super.charTyped(codePoint, modifiers);
    }
}
