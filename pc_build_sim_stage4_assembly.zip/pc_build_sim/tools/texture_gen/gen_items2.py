import sys
from gen_items import *
import gen_items

WH0, WH1 = C(255, 255, 255), C(206, 211, 222)
ORG0, ORG1 = C(255, 168, 64), C(238, 104, 20)      # accent orange
FAN0, FAN1 = C(255, 150, 70), C(226, 86, 34)       # burnt-orange fan blades
YEL0, YEL1 = C(255, 232, 130), C(240, 180, 40)


def white(cv, box, r):
    x0, y0, x1, y1 = box
    rr(cv, box, r, lin_grad(WH0, WH1, (x0, y0), (x1, y1)))


def orange(cv, box, r):
    x0, y0, x1, y1 = box
    rr(cv, box, r, lin_grad(ORG0, ORG1, (x0, y0), (x0, y1)))


def cat_badge(cv, cx, cy, s):
    """tiny cat head with goggles for badges"""
    ell(cv, cx, cy + 0.6 * s, 3.4 * s, 2.8 * s, C(255, 255, 255))
    poly(cv, [(cx - 3.2 * s, cy - 0.6 * s), (cx - 3.0 * s, cy - 4 * s), (cx - 0.6 * s, cy - 1.8 * s)], C(255, 255, 255))
    poly(cv, [(cx + 3.2 * s, cy - 0.6 * s), (cx + 3.0 * s, cy - 4 * s), (cx + 0.6 * s, cy - 1.8 * s)], C(255, 255, 255))
    rr(cv, (cx - 2.9 * s, cy - 0.2 * s, cx + 2.9 * s, cy + 0.9 * s), 0.4 * s, C(60, 70, 90))


def motherboard():
    cv = new_canvas()
    B = (4, 4, 60, 60)
    rr(cv, B, 2.6, lin_grad(C(250, 250, 253), C(214, 218, 228), (4, 4), (60, 60)))
    # orange silkscreen lines
    for (a, b) in (((10, 36), (10, 58)), ((22, 38), (22, 58)), ((8, 38), (58, 38))):
        line(cv, [a, b], 0.35, ORG1, 0.35, False)
    # white VRM armor: L shape around the socket
    white(cv, (14, 6, 46, 16), 1.6)
    white(cv, (5, 6, 24, 37), 1.6)
    for x in range(17, 45, 2):
        rr(cv, (x, 8, x + 0.8, 14), 0.2, C(150, 156, 172), 0.55)
    for y in range(18, 35, 2):
        rr(cv, (7, y, 22, y + 0.8), 0.2, C(150, 156, 172), 0.45)
    orange(cv, (7, 8, 13, 10.4), 0.6)                       # orange tag on the armor
    rr(cv, (14, 15, 46, 16.2), 0.4, ORG1, 0.9)               # orange edge line
    # I/O ports hint on the armor
    for i, y in enumerate((12, 17, 22, 27)):
        rr(cv, (5.8, y, 9.6, y + 3), 0.5, C(36, 38, 48))
    # CPU socket
    rr(cv, (25, 17, 46, 38), 1.0, lin_grad(C(240, 242, 248), C(150, 156, 170), (25, 17), (46, 38)))
    rr(cv, (26.6, 18.6, 44.4, 36.4), 0.6, C(60, 64, 76))
    for yy in range(20, 36, 2):
        for xx in range(28, 44, 2):
            ell(cv, xx, yy, 0.4, 0.4, C(255, 206, 90))
    # RAM slots (black)
    for i in range(4):
        x = 48.5 + i * 2.7
        rr(cv, (x, 6, x + 2.0, 37), 0.5, C(26, 26, 32))
        rr(cv, (x + 0.7, 9, x + 1.3, 34), 0.2, C(100, 100, 116), 0.7)
        rr(cv, (x + 0.2, 6.3, x + 1.8, 7.8), 0.3, C(240, 240, 246))
    # PCIe slot (black w/ silver reinforcement)
    rr(cv, (8, 40, 40, 44), 0.8, C(26, 26, 32))
    rr(cv, (8.6, 40.6, 39.4, 41.6), 0.3, C(180, 184, 198), 0.9)
    # M.2 white shield with orange stripe
    white(cv, (8, 46, 34, 51.6), 1.2)
    rr(cv, (8, 46, 34, 47.4), 0.8, ORG1, 0.95)
    ell(cv, 31.5, 49.4, 1.0, 1.0, C(150, 156, 170))
    # chipset heatsink + cat badge
    white(cv, (38, 44, 56, 58), 1.6)
    for y in (45.5, 47.5):
        rr(cv, (39.6, y, 54.4, y + 0.6), 0.2, C(150, 156, 172), 0.6)
    rr(cv, (41, 49.4, 53, 56.4), 1.2, lin_grad(ORG0, ORG1, (41, 49), (41, 57)))
    cat_badge(cv, 47, 53.2, 0.8)
    # label "MEOW" orange pill bottom-left
    rr(cv, (8, 53.4, 29, 58.6), 1.4, lin_grad(ORG0, ORG1, (8, 53), (8, 59)))
    # SATA ports
    for x in (58 - 0.0,):
        pass
    for y in (38, 41.2):
        rr(cv, (56.6, y, 59.4, y + 2.4), 0.4, C(26, 26, 32))
    # screws
    for (sx, sy) in ((7.2, 40), (57, 6.6)):
        ell(cv, sx, sy, 0.9, 0.9, C(176, 168, 150))
    bevel(cv, B, 2.6)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 9, 54, "MEOW", C(255, 255, 255))
    speckle(img, 1, 31)
    return img


def gpu():
    cv = new_canvas()
    # PCB bottom peek + gold fingers
    rr(cv, (8, 42, 58, 47), 0.8, C(150, 154, 168))
    for k in range(20):
        x = 12 + k * 1.3 + (3 if k > 10 else 0)
        rr(cv, (x, 45, x + 0.8, 50), 0.15, lin_grad(GOLD0, GOLD1, (x, 45), (x, 50)))
    body = (6, 12, 61, 44)
    rr(cv, body, 3.0, lin_grad(WH0, WH1, (6, 12), (6, 44)))
    # orange angular accent (bottom right wedge) + stripe
    poly(cv, [(61, 34), (61, 44), (44, 44)], lin_grad(ORG0, ORG1, (44, 34), (61, 44)))
    rr(cv, (6, 12, 61, 15.2), 1.8, lin_grad(ORG0, ORG1, (6, 12), (6, 16)))
    # fans: white / orange / white
    cols = [(C(255, 255, 255), C(210, 216, 228)), (FAN0, FAN1), (C(255, 255, 255), C(210, 216, 228))]
    for cx, (b0, b1) in zip((18, 33.5, 49), cols):
        ell(cv, cx, 29.5, 9.6, 9.6, C(170, 176, 190))
        fan(cv, cx, 29.5, 8.8, 9, b0, C(255, 244, 232), C(34, 36, 46))
        # blade tint (second tone)
        ell(cv, cx, 29.5, 2.4, 2.4, ORG1 if b0[0] == 255 and b0[1] == 255 else C(255, 255, 255))
    # bracket
    metal(cv, (1.5, 10, 6, 47), 0.8)
    for y in (15, 23, 31):
        rr(cv, (2.3, y, 5.2, y + 5), 0.4, C(36, 38, 48))
    rr(cv, (47, 8.6, 58, 12.4), 0.6, C(40, 40, 48))
    for x in range(48, 57, 2):
        rr(cv, (x, 9.4, x + 1, 11.4), 0.2, C(255, 206, 90), 0.9)
    poly(cv, [(8, 16), (28, 16), (18, 40), (8, 40)], C(255, 255, 255), 0.18)
    bevel(cv, body, 3.0, 0.6, 0.25)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 9, 17, "MEOW", C(255, 255, 255)) if False else None
    speckle(img, 1, 32)
    return img


def ram():
    cv = new_canvas()
    rr(cv, (3, 38, 61, 46), 1.0, C(60, 64, 76))
    for k in range(28):
        x = 5 + k * 2.0 + (0.8 if k > 15 else 0)
        if 33.5 < x < 36:
            continue
        rr(cv, (x, 41, x + 1.2, 46), 0.2, lin_grad(GOLD0, GOLD1, (x, 41), (x, 46)))
    hs = (3, 12, 61, 40)
    rr(cv, hs, 2.2, lin_grad(WH0, WH1, (3, 12), (3, 40)))
    # glowing light bar (warm)
    rr(cv, (6, 13, 58, 18.4), 1.6, lin_grad(C(255, 246, 214), C(255, 200, 110), (6, 13), (58, 18)))
    ell(cv, 32, 15.5, 27, 2.4, C(255, 255, 255), 0.5)
    for x in range(10, 56, 6):
        rr(cv, (x, 13.4, x + 0.5, 18), 0.2, C(255, 160, 50), 0.35)
    # grooves
    for y in (21.6, 23.8):
        rr(cv, (6, y, 58, y + 0.7), 0.3, C(150, 156, 172), 0.6)
    # orange label
    rr(cv, (9, 27, 55, 36.4), 1.4, lin_grad(ORG0, ORG1, (9, 27), (9, 36)))
    poly(cv, [(5, 14), (22, 14), (14, 39), (5, 39)], C(255, 255, 255), 0.14)
    bevel(cv, hs, 2.2, 0.6, 0.3)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 13, 29, "16GB", C(255, 255, 255))
    put_text(img, 35, 29, "DDR5", C(255, 240, 210))
    speckle(img, 1, 33)
    return img


def cpu_cooler():
    """AIO liquid cooler: pump head (yellow logo ring) + white tubes + radiator fan (orange)"""
    cv = new_canvas()
    # radiator + fan on the right
    white(cv, (30, 18, 61, 56), 3.0)
    ell(cv, 45.5, 37, 13.6, 13.6, C(170, 176, 190))
    fan(cv, 45.5, 37, 12.6, 9, FAN0, C(255, 244, 232), C(34, 36, 46))
    ell(cv, 45.5, 37, 3.0, 3.0, C(255, 255, 255))
    paw(cv, 45.5, 36.6, 0.5, ORG1, 0.95)
    # tubes
    for (x0, y0, dy) in ((26, 24, 0), (26, 33, 0)):
        pass
    line(cv, [(20, 22), (28, 20), (36, 17)], 3.6, C(140, 146, 164))
    line(cv, [(20, 22), (28, 20), (36, 17)], 2.6, WH0)
    line(cv, [(20, 30), (30, 28), (38, 27)], 3.6, C(140, 146, 164))
    line(cv, [(20, 30), (30, 28), (38, 27)], 2.6, WH0)
    # pump head (left)
    ph = (3, 12, 26, 44)
    blur_shadow(cv, mask_from(lambda d: d.rounded_rectangle([3 * S, 12 * S, 26 * S, 44 * S], 4 * S, fill=255)), 0.5, 0.9, 0.8,
                color=(70, 50, 30, 255), alpha=0.45)
    white(cv, ph, 4.0)
    ell(cv, 14.5, 28, 8.4, 8.4, C(200, 206, 218))
    ell(cv, 14.5, 28, 7.4, 7.4, lin_grad(C(40, 42, 52), C(20, 20, 26), (8, 20), (22, 36)))
    ring(cv, lambda d, i: d.ellipse([(14.5 - 6.2 + i) * S, (28 - 6.2 + i) * S, (14.5 + 6.2 - i) * S, (28 + 6.2 - i) * S], fill=255), 1.2,
         lin_grad(YEL0, YEL1, (8, 22), (21, 34)))
    paw(cv, 14.5, 28.6, 0.9, YEL0, 0.95)
    orange(cv, (3, 12, 26, 15.4), 1.6)
    bevel(cv, ph, 4.0, 0.6, 0.25)
    cv = shadowed(cv)
    img = finish(cv)
    speckle(img, 1, 34)
    return img


def ssd_m2():
    cv = new_canvas()
    rr(cv, (3, 22, 61, 42), 1.6, lin_grad(C(60, 64, 74), C(36, 38, 46), (3, 22), (3, 42)))
    for k in range(9):
        y = 23.4 + k * 2.0
        rr(cv, (3.4, y, 7.6, y + 1.2), 0.2, lin_grad(GOLD0, GOLD1, (3, y), (8, y)))
    white(cv, (10, 23.5, 52, 40.5), 1.6)
    for x in range(13, 50, 3):
        rr(cv, (x, 25, x + 0.8, 39), 0.2, C(150, 156, 172), 0.5)
    rr(cv, (10, 23.5, 52, 26.4), 1.2, lin_grad(ORG0, ORG1, (10, 23), (10, 27)))
    orange(cv, (53.5, 25, 58.6, 39), 1.0)
    cv_a = cv.getchannel("A")
    hole = mask_from(lambda d: d.ellipse([58.8 * S, 29.4 * S, 64.2 * S, 34.6 * S], fill=255))
    cv.putalpha(ImageChops.subtract(cv_a, hole))
    bevel(cv, (3, 22, 61, 42), 1.6, 0.3, 0.2)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 20, 31, "M.2", C(255, 140, 30)) if False else None
    paw_img = None
    speckle(img, 1, 35)
    return img


def ssd_sata():
    cv = new_canvas()
    B = (8, 7, 56, 53)
    rr(cv, B, 3.4, lin_grad(WH0, WH1, (8, 7), (56, 53)))
    band = mask_from(lambda d: d.polygon([(8 * S, 30 * S), (8 * S, 20 * S), (56 * S, 44 * S), (56 * S, 54 * S)], fill=255))
    bm = mask_from(lambda d: d.rounded_rectangle([8 * S, 7 * S, 56 * S, 53 * S], 3.4 * S, fill=255))
    comp(cv, ImageChops.multiply(band, bm), lin_grad(ORG0, ORG1, (8, 20), (8, 54)))
    rr(cv, (14, 12, 50, 30), 2.0, lin_grad(ORG0, ORG1, (14, 12), (14, 30)))
    for (sx, sy) in ((11.6, 10.6), (52.4, 10.6), (11.6, 49.4), (52.4, 49.4)):
        ell(cv, sx, sy, 1.2, 1.2, C(190, 190, 200))
        line(cv, [(sx - 0.7, sy - 0.7), (sx + 0.7, sy + 0.7)], 0.35, C(90, 90, 100))
    rr(cv, (22, 53, 52, 60), 1.0, C(28, 28, 34))
    for x in list(range(24, 38, 2)) + list(range(42, 51, 2)):
        rr(cv, (x, 55, x + 1.1, 59), 0.2, lin_grad(GOLD0, GOLD1, (x, 55), (x, 59)))
    bevel(cv, B, 3.4, 0.5, 0.25)
    cv = shadowed(cv)
    img = finish(cv)
    big_text(img, 20, 16, "SSD", C(255, 255, 255), 2, shadow=C(176, 74, 0))
    speckle(img, 1, 36)
    return img


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "items_out"
    gen_items.OUT = out
    import os
    os.makedirs(out, exist_ok=True)
    gen_items.save(gen_items.cpu(), "cpu")
    gen_items.save(motherboard(), "motherboard")
    gen_items.save(gpu(), "gpu")
    gen_items.save(ram(), "ram")
    gen_items.save(ssd_m2(), "ssd_m2")
    gen_items.save(ssd_sata(), "ssd_sata")
    gen_items.save(gen_items.hdd(), "hdd")
    gen_items.save(gen_items.psu(), "psu")
    gen_items.save(cpu_cooler(), "cpu_cooler")
