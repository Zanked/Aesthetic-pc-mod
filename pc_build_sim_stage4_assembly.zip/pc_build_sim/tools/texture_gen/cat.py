from lib import *

FUR = C(246, 154, 44)
FUR_L = C(255, 196, 98)
FUR_D = C(214, 112, 26)
STRIPE = C(196, 94, 18)
CHEEK = C(255, 120, 130)


class Pen:
    """draw in cat-local units; (cx,cy) texel position of local origin, s = texels per unit"""

    def __init__(self, cv, cx, cy, s):
        self.cv, self.cx, self.cy, self.s = cv, cx, cy, s

    def p(self, x, y):
        return (self.cx + x * self.s, self.cy + y * self.s)

    def pts(self, L):
        return [self.p(x, y) for x, y in L]

    def ell(self, x, y, rx, ry, fill, ow=0.0, ocol=OUT, alpha=1.0):
        cx, cy = self.p(x, y)
        if ow:
            ell(self.cv, cx, cy, rx * self.s + ow, ry * self.s + ow, ocol)
        ell(self.cv, cx, cy, rx * self.s, ry * self.s, fill, alpha)

    def poly(self, L, fill, ow=0.0, ocol=OUT, alpha=1.0):
        P = self.pts(L)
        if ow:
            Pw = [(x * S, y * S) for x, y in P]
            m = mask_from(lambda d: d.polygon(Pw, fill=255, outline=255, width=int(ow * 2 * S)))
            comp(self.cv, m, ocol)
        poly(self.cv, P, fill, alpha)

    def line(self, L, w, fill, alpha=1.0):
        line(self.cv, self.pts(L), w * self.s, fill, alpha)

    def rrect(self, x0, y0, x1, y1, r, fill, ow=0.0, ocol=OUT):
        a = self.p(x0, y0)
        b = self.p(x1, y1)
        if ow:
            rr(self.cv, (a[0] - ow, a[1] - ow, b[0] + ow, b[1] + ow), r * self.s + ow, ocol)
        rr(self.cv, (a[0], a[1], b[0], b[1]), r * self.s, fill)


def head(pen, tilt=0.0, mouth_open=False):
    P = pen
    # ears
    for sg in (-1, 1):
        P.poly([(sg * 11.8, -4), (sg * 13.8, -17.5), (sg * 4.2, -9.2)], FUR, ow=0.55)
        P.poly([(sg * 10.6, -6.4), (sg * 12.0, -14.2), (sg * 5.8, -9.4)], PINK)
    # cheek tufts
    for sg in (-1, 1):
        P.poly([(sg * 11.2, 1.0), (sg * 15.4, 4.2), (sg * 11.0, 6.6)], FUR, ow=0.5)
        P.poly([(sg * 9.5, 5.5), (sg * 13.2, 8.8), (sg * 8.2, 8.9)], FUR_L, ow=0.5)
    # head
    P.ell(0, 0, 12.6, 10.6, FUR, ow=0.6)
    # shading: light top, darker bottom
    P.ell(-2.0, -4.4, 8.6, 4.6, FUR_L, alpha=0.55)
    P.ell(0, 8.2, 11.0, 3.4, FUR_D, alpha=0.35)
    # forehead stripes
    P.line([(0, -10.0), (0, -5.8)], 1.1, STRIPE)
    P.line([(-3.9, -9.6), (-3.2, -6.2)], 0.95, STRIPE)
    P.line([(3.9, -9.6), (3.2, -6.2)], 0.95, STRIPE)
    for sg in (-1, 1):
        P.line([(sg * 12.0, -0.6), (sg * 9.4, -0.2)], 0.8, STRIPE)
        P.line([(sg * 12.2, 2.0), (sg * 9.6, 2.2)], 0.8, STRIPE)
    # muzzle
    P.ell(0, 4.6, 6.8, 4.7, WHITE)
    P.ell(0, 6.4, 5.2, 2.7, CREAM_S, alpha=0.4)
    # eyes
    for sg in (-1, 1):
        P.ell(sg * 5.4, 0.9, 1.95, 2.45, C(44, 24, 18))
        P.ell(sg * 4.7, -0.1, 0.8, 0.9, C(255, 255, 255))
        P.ell(sg * 6.0, 1.9, 0.38, 0.38, C(255, 255, 255), alpha=0.8)
    # blush
    for sg in (-1, 1):
        P.ell(sg * 8.9, 3.6, 1.9, 1.1, CHEEK, alpha=0.5)
    # nose + mouth
    P.poly([(-1.25, 2.5), (1.25, 2.5), (0, 3.9)], C(238, 110, 124))
    if mouth_open:
        P.ell(0, 6.1, 1.5, 1.3, C(120, 40, 44))
        P.ell(0, 6.5, 0.8, 0.6, C(255, 130, 140))
    else:
        P.line([(0, 3.9), (0, 4.9)], 0.35, OUT)
        P.line([(0, 4.9), (-1.3, 5.7), (-2.4, 5.2)], 0.35, OUT)
        P.line([(0, 4.9), (1.3, 5.7), (2.4, 5.2)], 0.35, OUT)
    # whiskers
    for sg in (-1, 1):
        for k, dy in enumerate((-0.8, 1.2, 3.2)):
            P.line([(sg * 8.4, 4.4 + dy * 0.3), (sg * 15.8, 3.6 + dy)], 0.28, C(120, 70, 40), alpha=0.7)
    # goggles on forehead: strap + lenses
    P.line([(-12.6, -6.3), (-6, -6.7), (0, -6.9), (6, -6.7), (12.6, -6.3)], 2.0, GRAPH)
    P.line([(-12.6, -6.9), (12.6, -6.9)], 0.35, GRAPH_L, alpha=0.7)
    for sg in (-1, 1):
        cx = sg * 5.4
        P.ell(cx, -6.4, 4.1, 3.2, GRAPH)
        P.ell(cx, -6.4, 3.35, 2.5, C(40, 170, 205))
        P.ell(cx, -5.7, 3.0, 1.6, C(90, 228, 240), alpha=0.9)
        P.ell(cx - 1.1, -7.3, 1.2, 0.65, C(255, 255, 255), alpha=0.9)
    # strap buckle accent
    P.rrect(-1.2, -7.9, 1.2, -5.5, 0.4, OR, ow=0.0)


def pizza_slice(pen, x, y, ang_deg, size=1.0):
    """cheese slice, tip at (x,y) pointing along angle (deg, 0 = pointing right)"""
    a = math.radians(ang_deg)

    def rot(px, py):
        return (x + (px * math.cos(a) - py * math.sin(a)) * size, y + (px * math.sin(a) + py * math.cos(a)) * size)

    P = pen
    # crust end at +length
    L = 11.0
    wd = 6.2
    tip = rot(0, 0)
    c1 = rot(L, -wd)
    c2 = rot(L, wd)
    P.poly([tip, c1, c2], C(255, 208, 92), ow=0.5)
    # cheese gloss
    P.poly([rot(2.2, 0), rot(L - 1.4, -wd + 1.2), rot(L - 1.4, -1.0)], C(255, 226, 140), alpha=0.7)
    # crust
    cr1 = rot(L - 0.2, -wd - 0.2)
    cr2 = rot(L - 0.2, wd + 0.2)
    cr3 = rot(L + 2.6, wd - 0.3)
    cr4 = rot(L + 2.6, -wd + 0.3)
    P.poly([cr1, cr2, cr3, cr4], C(228, 150, 62), ow=0.45)
    # pepperoni
    for (px, py, r) in ((L - 3.4, -1.8, 1.55), (L - 4.9, 2.0, 1.35), (L - 8.0, -0.3, 1.05)):
        q = P.p(*rot(px, py))
        ell(P.cv, q[0], q[1], r * P.s * size, r * P.s * size, C(204, 58, 44))
        ell(P.cv, q[0] - 0.25, q[1] - 0.25, r * P.s * size * 0.5, r * P.s * size * 0.45, C(236, 100, 80), 0.8)


def full_cat(cv, cx, cy, s=1.0):
    """sitting cat with goggles, vest, pizza box and slice. (cx,cy) = head centre in texels"""
    P = Pen(cv, cx, cy, s)
    # tail behind (viewer right)
    tail = [(11, 30), (19, 31), (24, 24), (24, 14), (21, 6)]
    P.line(tail, 5.4 * 1.0, OUT)
    P.line(tail, 4.2, FUR)
    for (a, b) in (((17.6, 30.8), (18.0, 27.8)), ((22.8, 25.6), (20.0, 24.8)), ((23.2, 18.4), (20.4, 17.6))):
        P.line([a, b], 0.9, STRIPE)
    P.line([(23.2, 10.0), (21, 6)], 4.2, WHITE)
    # body
    P.ell(0, 22.0, 12.6, 15.4, FUR, ow=0.6)
    P.ell(-3, 18, 7.5, 9.5, FUR_L, alpha=0.35)
    # belly bib
    P.ell(0, 14.0, 6.0, 6.4, WHITE)
    # hind feet
    for sg in (-1, 1):
        P.ell(sg * 8.6, 35.8, 4.4, 2.5, WHITE, ow=0.55)
    # vest (graphite) over torso with orange trim
    P.poly([(-10.2, 12.6), (-4.2, 11.0), (-3.2, 17), (-3.6, 33.0), (-11.2, 33.2), (-12.4, 22)], GRAPH, ow=0.5)
    P.poly([(10.2, 12.6), (4.2, 11.0), (3.2, 17), (3.6, 33.0), (11.2, 33.2), (12.4, 22)], GRAPH, ow=0.5)
    P.line([(-4.0, 11.4), (-3.2, 17.0), (-3.6, 32.6)], 0.9, OR)
    P.line([(4.0, 11.4), (3.2, 17.0), (3.6, 32.6)], 0.9, OR)
    # vest details
    P.rrect(-9.4, 21.4, -5.0, 25.6, 0.8, GRAPH_L)
    P.rrect(5.0, 21.4, 9.4, 25.6, 0.8, GRAPH_L)
    P.line([(-9.0, 23.5), (-5.4, 23.5)], 0.5, OR)
    P.line([(5.4, 23.5), (9.0, 23.5)], 0.5, OR)
    P.ell(-6.6, 15.2, 0.9, 0.9, C(96, 235, 245))
    P.ell(6.6, 15.2, 0.9, 0.9, C(255, 130, 60))
    # head
    head(P)
    # pizza box in front
    P.poly([(-17, 27.5), (17, 27.5), (21, 38.5), (-21, 38.5)], C(196, 82, 38), ow=0.7)
    P.poly([(-15.6, 28.6), (15.6, 28.6), (18.4, 36.6), (-18.4, 36.6)], C(255, 232, 170))
    # pizza (ellipse seen from above) with slice missing
    P.ell(0, 32.7, 14.0, 4.6, C(228, 150, 62))
    P.ell(0, 32.5, 12.6, 3.8, C(255, 208, 92))
    P.ell(-2.4, 32.0, 8.0, 2.2, C(255, 226, 140), alpha=0.6)
    for (px, py) in ((-8.0, 32.6), (-3.0, 34.0), (3.0, 31.4), (8.2, 33.1), (-5.2, 30.9)):
        P.ell(px, py, 1.5, 0.85, C(204, 58, 44))
    # missing wedge
    P.poly([(5.2, 31.2), (14.5, 29.4), (14.5, 36.8), (5.2, 34.6)], C(255, 232, 170))
    # box lid hint (back, open)
    P.poly([(-16, 27.6), (16, 27.6), (14.6, 24.6), (-14.6, 24.6)], C(214, 100, 48), ow=0.6)
    # paws (white mitts) holding slice and the box edge
    P.ell(-9.6, 28.6, 3.6, 2.7, WHITE, ow=0.55)
    P.ell(-8.4, 29.0, 2.3, 1.2, CREAM_S, alpha=0.5)
    # slice raised in right paw toward mouth
    pizza_slice(P, 5.6, 12.6, 64, 0.80)
    P.ell(11.2, 22.2, 3.5, 3.0, WHITE, ow=0.55)
    P.ell(11.2, 23.2, 2.2, 1.1, CREAM_S, alpha=0.5)
    # toe lines
    for (x, y) in ((-10.8, 29.2), (-9.4, 29.6), (11.9, 23.2), (10.4, 23.6)):
        P.line([(x, y - 0.8), (x, y + 0.5)], 0.22, CREAM_D)


def screen_scene(cv_out, x0, y0, x1, y1):
    """cat head + pizza slice on the cream screen (clipped to the screen)"""
    cv = new_canvas()
    # background
    bg = lin_grad(C(255, 246, 214), C(255, 222, 152), (x0, y0), (x1, y1))
    rr(cv, (x0, y0, x1, y1), 0.6, bg)
    # soft sun
    ell(cv, x0 + (x1 - x0) * 0.72, y0 + (y1 - y0) * 0.55, 9, 9, C(255, 196, 96), 0.45)
    ell(cv, x0 + (x1 - x0) * 0.72, y0 + (y1 - y0) * 0.55, 6, 6, C(255, 176, 70), 0.35)
    # sparkles
    for (sx, sy, r) in ((x0 + 3.2, y0 + 3.0, 0.9), (x1 - 3.0, y0 + 2.6, 0.7), (x0 + 3.8, y1 - 2.8, 0.6), (x1 - 4.4, y1 - 2.6, 0.8)):
        poly(cv, [(sx, sy - r * 1.6), (sx + r * 0.45, sy - r * 0.45), (sx + r * 1.6, sy), (sx + r * 0.45, sy + r * 0.45),
                  (sx, sy + r * 1.6), (sx - r * 0.45, sy + r * 0.45), (sx - r * 1.6, sy), (sx - r * 0.45, sy - r * 0.45)],
             C(255, 255, 255), 0.9)
    # cat head
    hx = x0 + (x1 - x0) * 0.40
    hy = y0 + (y1 - y0) * 0.52
    P = Pen(cv, hx, hy, 0.46)
    # body hint (vest) below the head
    P.ell(0, 17, 12, 8, FUR, ow=0.7)
    P.poly([(-9, 13), (-3, 12), (-3, 22), (-10, 22)], GRAPH, ow=0.6)
    P.poly([(9, 13), (3, 12), (3, 22), (10, 22)], GRAPH, ow=0.6)
    head(P)
    # slice
    pizza_slice(P, 19.0, 6.0, 18, 0.85)
    P.ell(15.6, 9.6, 3.2, 2.6, WHITE, ow=0.6)
    clip = mask_from(lambda d: d.rounded_rectangle([x0 * S, y0 * S, x1 * S - 1, y1 * S - 1], 0.6 * S, fill=255))
    comp(cv_out, clip, cv)
