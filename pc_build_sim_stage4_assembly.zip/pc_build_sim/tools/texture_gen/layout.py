"""Front-panel layout in TEXTURE PIXELS (front face = px 10..54 x rows 0..60). Shared by gen_case.py and gen_model.py.

Matches the reference photo (Segotep x Colorfire 'Meow' Game-Boy case): wide orange-framed screen on top,
sticker under it, d-pad bottom-left, two round paw buttons bottom-right, audio + 2x USB along the bottom.
"""

FACE = (10, 0, 54, 60)          # x0, y0, x1, y1 (exclusive)

BEZEL = (14, 5, 50, 28)         # outer orange frame
SCREEN = (17, 8, 47, 24)        # glowing screen (30 x 16)
STICKER = (13, 30, 35, 37)

DPAD_CENTER = (19, 44)
DPAD_H = (13, 42, 25, 46)       # horizontal arm
DPAD_V = (17, 38, 21, 50)       # vertical arm

# round buttons: 7x7 octagon, top-left corner
BTN_MASK = ["..###..",
            ".#####.",
            "#######",
            "#######",
            "#######",
            ".#####.",
            "..###.."]
BTN_A = (43, 37)
BTN_B = (36, 42)

AUDIO = (28, 54)
USB1 = (33, 52, 39, 56)
USB2 = (41, 52, 47, 56)
