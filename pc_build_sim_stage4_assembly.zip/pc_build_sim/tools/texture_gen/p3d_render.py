"""Tiny software renderer for Minecraft block-model JSON (item models) -> PNG previews.
Supports: multiple textures, element rotation (x/y/z), uv flipping, cutout alpha, emissive faces (neoforge_data),
MC-style per-direction shading and the vanilla GUI transform ([30,225,0])."""
import json, math, os
import numpy as np
from PIL import Image

SHADE = {"up": 1.0, "north": 0.85, "south": 0.85, "east": 0.65, "west": 0.65, "down": 0.5}
NORMALS = {"up": (0, 1, 0), "down": (0, -1, 0), "north": (0, 0, -1), "south": (0, 0, 1), "east": (1, 0, 0), "west": (-1, 0, 0)}


def corners(d, a, b):
    x1, y1, z1 = a
    x2, y2, z2 = b
    return {
        "north": ((x2, y2, z1), (x1, y2, z1), (x2, y1, z1)),
        "south": ((x1, y2, z2), (x2, y2, z2), (x1, y1, z2)),
        "east": ((x2, y2, z2), (x2, y2, z1), (x2, y1, z2)),
        "west": ((x1, y2, z1), (x1, y2, z2), (x1, y1, z1)),
        "up": ((x1, y2, z1), (x2, y2, z1), (x1, y2, z2)),
        "down": ((x1, y1, z2), (x2, y1, z2), (x1, y1, z1)),
    }[d]


def rot_view(p, rx, ry):
    """GUI-style: rotate about Y first, then X (matches Quaternionf.rotationXYZ)."""
    x, y, z = p
    c, s = math.cos(math.radians(ry)), math.sin(math.radians(ry))
    x, z = x * c + z * s, -x * s + z * c
    c, s = math.cos(math.radians(rx)), math.sin(math.radians(rx))
    y, z = y * c - z * s, y * s + z * c
    return np.array([x, y, z], float)


def rot_axis(p, axis, ang, origin):
    x, y, z = [p[i] - origin[i] for i in range(3)]
    c, s = math.cos(math.radians(ang)), math.sin(math.radians(ang))
    if axis == "y":
        x, z = x * c + z * s, -x * s + z * c
    elif axis == "x":
        y, z = y * c - z * s, y * s + z * c
    else:
        x, y = x * c - y * s, x * s + y * c
    return np.array([x + origin[0], y + origin[1], z + origin[2]], float)


def nearest_dir(n):
    best, bd = None, -9
    for k, v in NORMALS.items():
        d = n[0] * v[0] + n[1] * v[1] + n[2] * v[2]
        if d > bd:
            best, bd = k, d
    return best


class Loader:
    def __init__(self, texroot):
        self.root = texroot
        self.cache = {}

    def get(self, ref):
        # "pcbuildsim:item/foo" -> root/item/foo.png
        path = ref.split(":", 1)[-1]
        if path not in self.cache:
            self.cache[path] = np.array(Image.open(os.path.join(self.root, path + ".png")).convert("RGBA"))
        return self.cache[path]


def collect_quads(model):
    quads = []
    for el in model["elements"]:
        a, b = el["from"], el["to"]
        rot = el.get("rotation")
        for d, f in el["faces"].items():
            c0, c1, c2 = [np.array(c, float) for c in corners(d, a, b)]
            n = np.array(NORMALS[d], float)
            if rot:
                o = rot["origin"]
                c0, c1, c2 = [rot_axis(c, rot["axis"], rot["angle"], o) for c in (c0, c1, c2)]
                n = rot_axis(n, rot["axis"], rot["angle"], (0, 0, 0))
            quads.append((c0, c1, c2, n, f, el.get("shade", True)))
    return quads


def bbox_view(model, rx, ry):
    pts = []
    for el in model["elements"]:
        a, b = el["from"], el["to"]
        rot = el.get("rotation")
        for x in (a[0], b[0]):
            for y in (a[1], b[1]):
                for z in (a[2], b[2]):
                    p = np.array([x, y, z], float)
                    if rot:
                        p = rot_axis(p, rot["axis"], rot["angle"], rot["origin"])
                    pts.append(rot_view(p - 8, rx, ry))
    pts = np.array(pts)
    return pts.min(0), pts.max(0)


def render(model, loader, rx=30, ry=225, size=512, scale=None, tx=0.0, ty=0.0, bg=(200, 214, 224), ss=2):
    """size: output px; 1 model unit == size/16*scale px (scale defaults to 0.625 like vanilla gui)."""
    scale = 0.625 if scale is None else scale
    S = size * ss
    unit = S / 16.0 * scale
    img = np.zeros((S, S, 3), float)
    img[:] = np.array(bg)
    bgmask = np.ones((S, S), bool)
    zb = np.full((S, S), -1e9)
    texmap = model["textures"]
    quads = collect_quads(model)
    items = []
    for c0, c1, c2, n, f, shade in quads:
        P0, P1, P2 = [rot_view(c - 8, rx, ry) for c in (c0, c1, c2)]
        nv = rot_view(n, rx, ry)
        if nv[2] <= 1e-6:
            continue
        d = nearest_dir(n)
        items.append((P0 + 0, P1 + 0, P2 + 0, d, f, shade, (P0[2] + P1[2] + P2[2]) / 3))
    items.sort(key=lambda it: it[6])
    cx = S / 2 + tx * unit / scale * scale  # tx in "px at 16px slot" units -> handled below
    for P0, P1, P2, d, f, shade, _ in items:
        ref = f["texture"]
        key = ref[1:] if ref.startswith("#") else ref
        tex = loader.get(texmap[key])
        H, W = tex.shape[:2]
        e1, e2 = P1 - P0, P2 - P0
        ox = S / 2 + tx * S / 16.0
        oy = S / 2 - ty * S / 16.0

        def scr(p):
            return ox + p[0] * unit, oy - p[1] * unit

        pts = [P0, P1, P2, P1 + e2]
        sx = [scr(p)[0] for p in pts]
        sy = [scr(p)[1] for p in pts]
        x0, x1 = int(max(0, min(sx) - 1)), int(min(S - 1, max(sx) + 1))
        y0, y1 = int(max(0, min(sy) - 1)), int(min(S - 1, max(sy) + 1))
        if x1 <= x0 or y1 <= y0:
            continue
        ys, xs = np.mgrid[y0:y1 + 1, x0:x1 + 1]
        A = np.array([[e1[0] * unit, e2[0] * unit], [-e1[1] * unit, -e2[1] * unit]])
        if abs(np.linalg.det(A)) < 1e-9:
            continue
        Ainv = np.linalg.inv(A)
        px = xs + 0.5 - scr(P0)[0]
        py = ys + 0.5 - scr(P0)[1]
        s = Ainv[0, 0] * px + Ainv[0, 1] * py
        t = Ainv[1, 0] * px + Ainv[1, 1] * py
        inside = (s >= 0) & (s < 1) & (t >= 0) & (t < 1)
        if not inside.any():
            continue
        u1, v1, u2, v2 = f["uv"]
        rotf = f.get("rotation", 0)
        s2, t2 = s, t
        if rotf == 90:
            s2, t2 = t, 1 - s
        elif rotf == 180:
            s2, t2 = 1 - s, 1 - t
        elif rotf == 270:
            s2, t2 = 1 - t, s
        u = (u1 + (u2 - u1) * s2) / 16.0 * W
        v = (v1 + (v2 - v1) * t2) / 16.0 * H
        ui = np.clip(np.floor(u).astype(int), 0, W - 1)
        vi = np.clip(np.floor(v).astype(int), 0, H - 1)
        col = tex[vi, ui].astype(float)
        alpha = col[..., 3] / 255.0
        z = P0[2] + e1[2] * s + e2[2] * t
        emis = "neoforge_data" in f
        sh = 1.0 if (emis or not shade) else SHADE[d]
        zz = zb[y0:y1 + 1, x0:x1 + 1]
        m = inside & (z >= zz - 1e-6) & (alpha > 0.5)
        rgb = col[..., :3] * sh
        cur = img[y0:y1 + 1, x0:x1 + 1]
        cur[m] = rgb[m]
        zz[m] = z[m]
        bgmask[y0:y1 + 1, x0:x1 + 1][m] = False
    out = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))
    if ss > 1:
        out = out.resize((size, size), Image.LANCZOS)
    return out


def fit_gui(model, rx=30, ry=225, margin=0.5, max_scale=1.6):
    """auto-fit scale+translation (in 16px-slot px) so the model fills the slot"""
    lo, hi = bbox_view(model, rx, ry)
    w, h = hi[0] - lo[0], hi[1] - lo[1]
    s = min((16 - 2 * margin) / w, (16 - 2 * margin) / h, max_scale)
    cxm, cym = (lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2
    return round(s, 3), round(-cxm * s, 2), round(-cym * s, 2)
