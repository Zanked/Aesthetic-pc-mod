"""Helpers: supersampled drawing -> 64x64 minecraft textures. All coords are in TEXELS (0..64)."""
from PIL import Image, ImageDraw, ImageChops, ImageFilter
import numpy as np
import math, random

S = 8
W = 64 * S


def C(r, g, b, a=255):
    return (r, g, b, a)


# ---------------- palette ----------------
CREAM = C(244, 239, 229)
CREAM_L = C(253, 251, 245)
CREAM_S = C(224, 216, 202)
CREAM_D = C(196, 187, 170)
OR = C(255, 154, 31)
OR_L = C(255, 198, 100)
OR_LL = C(255, 224, 160)
OR_D = C(224, 106, 0)
OR_DD = C(166, 70, 0)
GRAPH = C(46, 48, 56)
GRAPH_L = C(78, 82, 94)
OUT = C(98, 46, 18)
WHITE = C(255, 250, 242)
PINK = C(255, 150, 160)


def new_canvas(bg=(0, 0, 0, 0)):
    return Image.new("RGBA", (W, W), bg)


def mask_from(fn):
    m = Image.new("L", (W, W), 0)
    d = ImageDraw.Draw(m)
    fn(d)
    return m


def lin_grad(c0, c1, p0, p1):
    ys, xs = np.mgrid[0:W, 0:W]
    x0, y0, x1, y1 = p0[0] * S, p0[1] * S, p1[0] * S, p1[1] * S
    dx, dy = x1 - x0, y1 - y0
    t = ((xs - x0) * dx + (ys - y0) * dy) / float(dx * dx + dy * dy)
    t = np.clip(t, 0, 1)[..., None]
    a0 = np.array(c0, float)
    a1 = np.array(c1, float)
    arr = (a0 + (a1 - a0) * t).astype(np.uint8)
    return Image.fromarray(arr, "RGBA")


def rad_grad(c0, c1, center, radius):
    ys, xs = np.mgrid[0:W, 0:W]
    cx, cy = center[0] * S, center[1] * S
    t = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2) / float(radius * S)
    t = np.clip(t, 0, 1)[..., None]
    a0 = np.array(c0, float)
    a1 = np.array(c1, float)
    arr = (a0 + (a1 - a0) * t).astype(np.uint8)
    return Image.fromarray(arr, "RGBA")


def comp(canvas, mask, fill, alpha=1.0):
    if isinstance(fill, tuple):
        layer = Image.new("RGBA", canvas.size, fill if len(fill) == 4 else fill + (255,))
    else:
        layer = fill.copy()
    a = ImageChops.multiply(layer.getchannel("A"), mask)
    if alpha < 1.0:
        a = a.point(lambda v: int(v * alpha))
    layer.putalpha(a)
    canvas.alpha_composite(layer)


def rr(canvas, box, r, fill, alpha=1.0):
    x0, y0, x1, y1 = box
    m = mask_from(lambda d: d.rounded_rectangle([x0 * S, y0 * S, x1 * S - 1, y1 * S - 1], max(r * S, 0), fill=255))
    comp(canvas, m, fill, alpha)
    return m


def ell(canvas, cx, cy, rx, ry, fill, alpha=1.0):
    m = mask_from(lambda d: d.ellipse([(cx - rx) * S, (cy - ry) * S, (cx + rx) * S - 1, (cy + ry) * S - 1], fill=255))
    comp(canvas, m, fill, alpha)
    return m


def poly(canvas, pts, fill, alpha=1.0):
    P = [(x * S, y * S) for x, y in pts]
    m = mask_from(lambda d: d.polygon(P, fill=255))
    comp(canvas, m, fill, alpha)
    return m


def line(canvas, pts, w, fill, alpha=1.0, round_caps=True):
    P = [(x * S, y * S) for x, y in pts]

    def f(d):
        d.line(P, fill=255, width=max(1, int(w * S)), joint="curve")
        if round_caps:
            r = w * S / 2
            for (x, y) in (P[0], P[-1]):
                d.ellipse([x - r, y - r, x + r, y + r], fill=255)

    m = mask_from(f)
    comp(canvas, m, fill, alpha)
    return m


def blur_shadow(canvas, mask, dx, dy, blur, color=(60, 40, 20, 255), alpha=0.35):
    m = ImageChops.offset(mask, int(dx * S), int(dy * S))
    m = m.filter(ImageFilter.GaussianBlur(blur * S))
    comp(canvas, m, color, alpha)


def ring(canvas, shape_fn, width, fill, alpha=1.0):
    """shape_fn(d, inset) draws filled shape inset by `inset` texels"""
    outer = mask_from(lambda d: shape_fn(d, 0))
    inner = mask_from(lambda d: shape_fn(d, width))
    m = ImageChops.subtract(outer, inner)
    comp(canvas, m, fill, alpha)


def clip_to(mask_fn_canvas, mask):
    pass


def finish(canvas):
    """downsample hi-res canvas to 64x64 with premultiplied alpha"""
    c = canvas.convert("RGBa").resize((64, 64), Image.LANCZOS).convert("RGBA")
    return c


# ---------------- pixel font 3x5 ----------------
FONT = {
    "C": ["###", "#..", "#..", "#..", "###"],
    "U": ["#.#", "#.#", "#.#", "#.#", "###"],
    "T": ["###", ".#.", ".#.", ".#.", ".#."],
    "E": ["###", "#..", "##.", "#..", "###"],
    "P": ["###", "#.#", "###", "#..", "#.."],
    "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#"],
    "O": ["###", "#.#", "#.#", "#.#", "###"],
    "W": ["#...#", "#...#", "#.#.#", "##.##", "#...#"],
    "S": ["###", "#..", "###", "..#", "###"],
    "H": ["#.#", "#.#", "###", "#.#", "#.#"],
    "I": ["###", ".#.", ".#.", ".#.", "###"],
    "N": ["##.", "#.#", "#.#", "#.#", "#.#"],
    "Y": ["#.#", "#.#", ".#.", ".#.", ".#."],
    "L": ["#..", "#..", "#..", "#..", "###"],
    "R": ["###", "#.#", "##.", "#.#", "#.#"],
    "A": [".#.", "#.#", "###", "#.#", "#.#"],
    "D": ["##.", "#.#", "#.#", "#.#", "##."],
    "V": ["#.#", "#.#", "#.#", "#.#", ".#."],
    "G": ["###", "#..", "#.#", "#.#", "###"],
    "B": ["##.", "#.#", "##.", "#.#", "##."],
    "K": ["#.#", "#.#", "##.", "#.#", "#.#"],
    "F": ["###", "#..", "##.", "#..", "#.."],
    "J": ["..#", "..#", "..#", "#.#", "###"],
    "X": ["#.#", "#.#", ".#.", "#.#", "#.#"],
    "Z": ["###", "..#", ".#.", "#..", "###"],
    "Q": ["###", "#.#", "#.#", "###", "..#"],
    "0": ["###", "#.#", "#.#", "#.#", "###"],
    "1": [".#.", "##.", ".#.", ".#.", "###"],
    "2": ["###", "..#", "###", "#..", "###"],
    "3": ["###", "..#", "###", "..#", "###"],
    "4": ["#.#", "#.#", "###", "..#", "..#"],
    "5": ["###", "#..", "###", "..#", "###"],
    "6": ["###", "#..", "###", "#.#", "###"],
    "7": ["###", "..#", ".#.", ".#.", ".#."],
    "8": ["###", "#.#", "###", "#.#", "###"],
    "9": ["###", "#.#", "###", "..#", "###"],
    "-": ["...", "...", "###", "...", "..."],
    ".": ["...", "...", "...", "...", ".#."],
}


def text_w(s):
    return sum(3 if ch == " " else len(FONT[ch][0]) + 1 for ch in s) - 1


def put_text(img, x, y, s, color, shadow=None):
    px = img.load()
    cx = x
    for ch in s:
        if ch == " ":
            cx += 3
            continue
        g = FONT[ch]
        for r, row in enumerate(g):
            for c, v in enumerate(row):
                if v == "#":
                    if shadow is not None:
                        sx, sy = cx + c + shadow[0], y + r + shadow[1]
                        if 0 <= sx < 64 and 0 <= sy < 64:
                            px[sx, sy] = shadow[2]
        for r, row in enumerate(g):
            for c, v in enumerate(row):
                if v == "#":
                    xx, yy = cx + c, y + r
                    if 0 <= xx < 64 and 0 <= yy < 64:
                        px[xx, yy] = color
        cx += len(g[0]) + 1


def speckle(img, amount=3, seed=1, region=None):
    """tiny plastic grain on final 64x64 image (only on opaque pixels)"""
    rnd = random.Random(seed)
    px = img.load()
    for y in range(64):
        for x in range(64):
            if region and not (region[0] <= x < region[2] and region[1] <= y < region[3]):
                continue
            r, g, b, a = px[x, y]
            if a < 200:
                continue
            d = rnd.randint(-amount, amount)
            px[x, y] = (max(0, min(255, r + d)), max(0, min(255, g + d)), max(0, min(255, b + d)), a)
