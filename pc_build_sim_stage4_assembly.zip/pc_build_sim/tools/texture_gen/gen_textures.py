import os, sys
from lib import *
from cat import full_cat, screen_scene, Pen, head

OUTDIR = sys.argv[1] if len(sys.argv) > 1 else "tex_out"
os.makedirs(OUTDIR, exist_ok=True)


def save(img, name):
    img.save(os.path.join(OUTDIR, name))
    print("saved", name)


def cream_panel(cv, box, r=0.0, c0=CREAM_L, c1=CREAM_S):
    x0, y0, x1, y1 = box
    g = lin_grad(c0, c1, (x0, y0), (x1, y1))
    return rr(cv, box, r, g)


# =====================================================================================
# FRONT  (viewer coords: u = 16 - X ; face spans px 10..54, rows 0..60)
# =====================================================================================
def make_front():
    cv = new_canvas()
    # body plate
    cream_panel(cv, (10, 0, 54, 61), 0, C(254, 252, 247), C(241, 237, 228))
    # big soft light from top-left
    ell(cv, 22, 8, 30, 22, C(255, 255, 255), 0.30)
    # lower shade (bottom edge a bit darker)
    rr(cv, (10, 52, 54, 61), 0, lin_grad(C(0, 0, 0, 0), C(170, 158, 135, 45), (0, 52), (0, 61)))

    # ---- bezel (orange) : px 17..52, rows 5..28 ----
    blur_shadow(cv, mask_from(lambda d: d.rounded_rectangle([17 * S, 5 * S, 52 * S, 28 * S], 3 * S, fill=255)), 0.5, 1.0, 0.9,
                color=(90, 60, 30, 255), alpha=0.45)
    og = lin_grad(C(255, 190, 80), C(240, 128, 8), (17, 5), (17, 29))
    rr(cv, (17, 5, 52, 28.4), 3.0, og)
    # top highlight line + left highlight
    rr(cv, (18.2, 5.4, 50.8, 6.4), 0.5, C(255, 232, 175), 0.85)
    # outer rim (darker orange)
    ring(cv, lambda d, i: d.rounded_rectangle([(17 + i) * S, (5 + i) * S, (52 - i) * S - 1, (28.4 - i) * S - 1],
                                              max((3.0 - i) * S, 1), fill=255), 0.55, C(214, 98, 0), 0.9)
    # inner screen well (dark edge)
    rr(cv, (19.4, 7.4, 49.6, 24.8), 1.2, C(120, 56, 6))
    # SCREEN : px 20..49 , rows 8..24
    screen_scene(cv, 20, 8, 49, 24)
    # inner shadow of the well on top/left
    rr(cv, (20, 8, 49, 9.2), 0.2, C(120, 70, 20), 0.30)
    rr(cv, (20, 8, 21, 24), 0.2, C(120, 70, 20), 0.18)
    # glass glare on the screen
    poly(cv, [(20, 8), (31, 8), (24, 24), (20, 24)], C(255, 255, 255), 0.10)
    # power led
    ell(cv, 49.2, 26.6, 0.9, 0.9, C(255, 240, 200))
    ell(cv, 49.2, 26.6, 2.2, 2.2, C(255, 210, 90), 0.35)

    # ---- sticker ----
    rr(cv, (16.5, 30.6, 38.5, 37.2), 1.2, C(38, 38, 44))
    rr(cv, (16.9, 30.9, 38.1, 31.9), 0.5, C(255, 255, 255), 0.16)

    # ---- d-pad well (circle) ----
    ell(cv, 22, 43, 8.6, 8.6, lin_grad(C(206, 197, 180), C(246, 241, 231), (14, 35), (30, 52)))
    ell(cv, 22, 43, 7.6, 7.6, lin_grad(C(176, 166, 148), C(232, 225, 212), (14, 35), (30, 52)))
    ell(cv, 22, 43.4, 6.6, 6.6, C(215, 207, 192), 0.6)
    # cross (painted, also visible under the raised cross)
    for b in ((16, 41, 28, 45), (20, 37, 24, 49)):
        rr(cv, b, 0.9, C(255, 166, 40))
    rr(cv, (16.5, 41.2, 27.5, 42.2), 0.4, C(255, 214, 128), 0.8)
    rr(cv, (20.3, 37.3, 23.7, 38.2), 0.4, C(255, 214, 128), 0.8)

    # ---- A/B pill well ----
    pill = Image.new("L", (W, W), 0)
    d = ImageDraw.Draw(pill)
    d.rounded_rectangle([(43.5 - 11) * S, (42 - 5.6) * S, (43.5 + 11) * S, (42 + 5.6) * S], 5.6 * S, fill=255)
    pill = pill.rotate(30, resample=Image.BICUBIC, center=(43.5 * S, 42 * S))
    d2 = Image.new("L", (W, W), 0)
    dd = ImageDraw.Draw(d2)
    dd.rounded_rectangle([(43.5 - 10.2) * S, (42 - 4.8) * S, (43.5 + 10.2) * S, (42 + 4.8) * S], 4.8 * S, fill=255)
    d2 = d2.rotate(30, resample=Image.BICUBIC, center=(43.5 * S, 42 * S))
    comp(cv, pill, lin_grad(C(206, 197, 180), C(246, 241, 231), (36, 34), (50, 50)))
    comp(cv, d2, lin_grad(C(180, 170, 152), C(232, 225, 212), (36, 34), (50, 50)))
    # buttons (A: px47,row40  B: px40,row44)
    for (bx, by) in ((47, 40), (40, 44)):
        ell(cv, bx + 0.4, by + 0.8, 4.0, 4.0, C(110, 60, 10), 0.35)
        ell(cv, bx, by, 3.6, 3.6, lin_grad(C(255, 190, 80), C(226, 108, 0), (bx - 3, by - 3), (bx + 3, by + 3)))
        ell(cv, bx - 0.9, by - 1.0, 1.5, 1.0, C(255, 240, 200), 0.85)

    # ---- ports ----
    ell(cv, 27, 53.5, 2.0, 2.0, C(150, 142, 128))
    ell(cv, 27, 53.5, 1.4, 1.4, C(34, 30, 28))
    for x in (33, 40):
        rr(cv, (x, 51.5, x + 5, 55.6), 0.5, C(110, 104, 94))
        rr(cv, (x + 0.5, 52, x + 4.5, 55.1), 0.3, C(28, 26, 26))
        rr(cv, (x + 1.0, 52.9, x + 4.0, 53.8), 0.2, C(90, 150, 255))
        rr(cv, (x, 55.6, x + 5, 56.2), 0.2, C(255, 255, 255), 0.6)

    # ---- bevel edges of the face ----
    rr(cv, (10, 0, 54, 0.9), 0, C(255, 255, 255), 0.55)
    rr(cv, (10, 0, 10.9, 61), 0, C(255, 255, 255), 0.35)
    rr(cv, (53.1, 0, 54, 61), 0, C(120, 105, 80), 0.14)
    rr(cv, (10, 59.9, 54, 61), 0, C(120, 105, 80), 0.15)

    img = finish(cv)
    # crisp pixel text
    put_text(img, 18, 32, "MEOW", C(255, 255, 255))
    put_text(img, 29, 32, "PC", C(255, 170, 50)) if False else None
    speckle(img, 2, 3, (10, 0, 54, 61))
    # clear anything outside the real face width
    px = img.load()
    for y in range(64):
        for x in range(64):
            if not (10 <= x < 54 and y < 61):
                px[x, y] = (0, 0, 0, 0)
    save(img, "pc_case_front.png")


# =====================================================================================
# SIDE of the front slab, glass side (viewer from east: u = 16 - z ; slab z 0.5..2 -> px 56..62, rows 0..60)
# =====================================================================================
def make_side():
    cv = new_canvas()
    cream_panel(cv, (56, 0, 62, 61), 0, C(254, 252, 247), C(241, 237, 228))
    for i in range(14):
        y = 5.0 + i * 3.7
        rr(cv, (57.0, y, 61.0, y + 1.6), 0.6, C(150, 144, 136))
        rr(cv, (57.3, y + 0.25, 60.7, y + 1.25), 0.45, C(70, 64, 60))
        rr(cv, (57.0, y + 1.6, 61.0, y + 2.1), 0.2, C(255, 255, 255), 0.7)
    rr(cv, (56, 0, 62, 0.9), 0, C(255, 255, 255), 0.55)
    rr(cv, (56, 59.9, 62, 61), 0, C(120, 105, 80), 0.15)
    img = finish(cv)
    speckle(img, 2, 7, (56, 0, 62, 61))
    save(img, "pc_case_side.png")


# =====================================================================================
# GLASS (viewer from east: u = 16 - z ; glass z 2..15 -> region px 4..56, rows 0..60)
# =====================================================================================
def make_glass():
    cv = new_canvas()
    L, T, R, B = 4, 0, 56, 60.5
    # orange printed frame
    frame_g = lin_grad(C(255, 176, 60), C(238, 118, 10), (L, T), (L, B))
    rr(cv, (L, T, R, B), 3.0, frame_g)
    # diagonal hatch pattern
    hatch = mask_from(lambda d: [d.line([(x * S, 0), ((x - 64) * S, 64 * S)], fill=255, width=int(1.1 * S)) for x in range(0, 140, 4)])
    comp(cv, hatch, C(255, 215, 130), 0.30)
    # inner transparent window
    win = (9, 5, 51, 53)
    inner = mask_from(lambda d: d.rounded_rectangle([win[0] * S, win[1] * S, win[2] * S - 1, win[3] * S - 1], 1.6 * S, fill=255))
    outer = mask_from(lambda d: d.rounded_rectangle([L * S, T * S, R * S - 1, int(B * S) - 1], 3.0 * S, fill=255))
    # punch window out of the frame
    cv_a = cv.getchannel("A")
    cv_a = ImageChops.subtract(cv_a, inner)
    cv.putalpha(cv_a)
    # cream inner line around the window
    ring(cv, lambda d, i: d.rounded_rectangle([(win[0] - 1.2 + i) * S, (win[1] - 1.2 + i) * S, (win[2] + 1.2 - i) * S - 1, (win[3] + 1.2 - i) * S - 1],
                                              max((2.4 - i) * S, 1), fill=255), 0.8, C(255, 236, 190), 0.95)
    # frame outer dark rim & top light
    ring(cv, lambda d, i: d.rounded_rectangle([(L + i) * S, (T + i) * S, (R - i) * S - 1, (B - i) * S - 1], max((3.0 - i) * S, 1), fill=255),
         0.7, C(190, 80, 0), 0.95)
    rr(cv, (L + 3, T + 0.7, R - 3, T + 1.5), 0.4, C(255, 230, 170), 0.7)
    # window: very faint tint + reflection streaks
    tint = mask_from(lambda d: d.rounded_rectangle([win[0] * S, win[1] * S, win[2] * S - 1, win[3] * S - 1], 1.6 * S, fill=255))
    comp(cv, tint, C(190, 228, 242), 0.17)
    # diagonal reflection
    refl = Image.new("L", (W, W), 0)
    rd = ImageDraw.Draw(refl)
    rd.polygon([(9 * S, 30 * S), (9 * S, 18 * S), (36 * S, 5 * S), (46 * S, 5 * S)], fill=255)
    refl = ImageChops.multiply(refl, tint)
    comp(cv, refl, C(255, 255, 255), 0.10)
    rd2 = Image.new("L", (W, W), 0)
    ImageDraw.Draw(rd2).polygon([(9 * S, 40 * S), (9 * S, 34 * S), (44 * S, 5 * S), (48 * S, 5 * S)], fill=255)
    rd2 = ImageChops.multiply(rd2, tint)
    comp(cv, rd2, C(255, 255, 255), 0.07)

    # cat sticker (sits behind the glass, centred right)
    # soft sticker halo
    # the glass is stretched ~1.19x horizontally by the model proportions (see gen_model.py) -> pre-squeeze the cat
    SQ = 0.84
    cat_layer = new_canvas()
    full_cat(cat_layer, 30.5, 21.5, 0.90)
    cat_layer = cat_layer.resize((int(W * SQ), W), Image.LANCZOS)
    shifted = new_canvas()
    shifted.paste(cat_layer, (int(30.5 * S * (1 - SQ)), 0))
    cv.alpha_composite(shifted)
    # sparkles in the empty part of the window
    for (sx, sy, r) in ((13.5, 12, 1.5), (17.5, 22, 1.0), (12.5, 33, 0.9), (47.5, 11, 1.1)):
        poly(cv, [(sx, sy - r * 1.7), (sx + r * 0.45, sy - r * 0.45), (sx + r * 1.7, sy), (sx + r * 0.45, sy + r * 0.45), (sx, sy + r * 1.7), (sx - r * 0.45, sy + r * 0.45), (sx - r * 1.7, sy), (sx - r * 0.45, sy - r * 0.45)], C(255, 255, 255), 0.85)

    # little decor on frame: pizza slices at the top corners & paws
    for (cx, cy) in ((12.5, 2.6), (24, 2.6), (35.5, 2.6), (47, 2.6)):
        poly(cv, [(cx - 1.4, cy - 1.0), (cx + 1.4, cy - 1.0), (cx, cy + 1.6)], C(255, 232, 150), 0.95)
        ell(cv, cx, cy - 0.5, 0.4, 0.4, C(200, 60, 40))
    for cy in (11, 19, 27, 35, 43, 51):
        for cx in (6.5, 53.5):
            poly(cv, [(cx, cy - 1.2), (cx + 1.0, cy), (cx, cy + 1.2), (cx - 1.0, cy)], C(255, 236, 190), 0.9)
    img = finish(cv)
    # bottom border text: MEOW x3 and a small badge top-left of the window
    put_text(img, 10, 55, "MEOW MEOW", C(255, 240, 200), shadow=(0, 1, C(176, 74, 0, 255)))
    save(img, "pc_case_glass.png")


# =====================================================================================
# WEST outer panel (viewer from west: u = z ; rows = 16 - y)
# =====================================================================================
def make_west():
    cv = new_canvas()
    cream_panel(cv, (12, 0, 60, 61), 0, C(254, 252, 247), C(241, 237, 228))
    ell(cv, 30, 16, 34, 26, C(255, 255, 255), 0.25)
    # inset panel
    rr(cv, (16, 6.5, 56, 52), 3.0, lin_grad(C(214, 205, 188), C(250, 246, 238), (16, 6), (16, 52)))
    rr(cv, (16.9, 7.4, 55.1, 51.1), 2.4, lin_grad(C(248, 244, 235), C(232, 225, 210), (16, 7), (56, 51)))
    # vent slots (top area)
    for i in range(6):
        y = 11 + i * 2.6
        rr(cv, (22, y, 50, y + 1.3), 0.6, C(70, 62, 54))
        rr(cv, (22.2, y + 0.15, 49.8, y + 0.9), 0.4, C(36, 31, 28))
        rr(cv, (22, y + 1.3, 50, y + 1.8), 0.2, C(255, 255, 255), 0.7)
    # big paw print (soft orange)
    cx, cy = 36, 40
    ell(cv, cx, cy + 1.8, 5.2, 4.2, C(255, 172, 60), 0.9)
    for (dx, dy, rx, ry) in ((-6.6, -3.2, 1.9, 2.4), (-2.3, -6.0, 2.0, 2.6), (2.3, -6.0, 2.0, 2.6), (6.6, -3.2, 1.9, 2.4)):
        ell(cv, cx + dx, cy + dy, rx, ry, C(255, 172, 60), 0.9)
    ell(cv, cx - 1.2, cy + 0.6, 2.4, 1.4, C(255, 224, 160), 0.6)
    # orange corner stripe near the bottom
    rr(cv, (16, 54.2, 56, 55.4), 0.4, C(255, 154, 31), 0.95)
    # bevels
    rr(cv, (12, 0, 60, 0.9), 0, C(255, 255, 255), 0.5)
    rr(cv, (12, 59.8, 60, 61), 0, C(120, 105, 80), 0.3)
    img = finish(cv)
    speckle(img, 2, 5, (12, 0, 60, 61))
    save(img, "pc_case_west.png")


# =====================================================================================
# BACK (viewer from south: u = X ; rows = 16 - y ; face spans px 10..54)
# =====================================================================================
def dark_hole(cv, box, r=1.0, depth=True):
    x0, y0, x1, y1 = box
    rr(cv, (x0 - 0.6, y0 - 0.6, x1 + 0.6, y1 + 0.6), r + 0.5, C(170, 160, 142))
    rr(cv, box, r, lin_grad(C(24, 24, 30), C(58, 58, 68), (x0, y0), (x1, y1)))
    rr(cv, (x0, y1 - 0.6, x1, y1), 0.2, C(255, 255, 255), 0.18)


def make_back():
    cv = new_canvas()
    cream_panel(cv, (10, 0, 54, 61), 0, C(254, 252, 247), C(241, 237, 228))
    ell(cv, 30, 10, 28, 20, C(255, 255, 255), 0.22)
    # I/O shield area (next to tray = west = left)
    dark_hole(cv, (15, 8, 34, 22), 1.4)
    # inside: I/O shield plate silhouette (empty cutout: faint frame)
    ring(cv, lambda d, i: d.rounded_rectangle([(16.4 + i) * S, (9.4 + i) * S, (32.6 - i) * S, (20.6 - i) * S], max((0.8 - i) * S, 1), fill=255),
         0.5, C(110, 110, 126), 0.8)
    # grill / exhaust fan hole at top-right
    cx, cy = 45, 14
    ell(cv, cx, cy, 7.4, 7.4, C(170, 160, 142))
    ell(cv, cx, cy, 6.8, 6.8, lin_grad(C(24, 24, 30), C(66, 66, 78), (cx - 6, cy - 6), (cx + 6, cy + 6)))
    for rad in (5.0, 3.2, 1.4):
        ring(cv, lambda d, i, rad=rad: d.ellipse([(cx - rad + i) * S, (cy - rad + i) * S, (cx + rad - i) * S, (cy + rad - i) * S], fill=255),
             0.45, C(150, 150, 168), 0.8)
    for a in range(0, 180, 45):
        t = math.radians(a)
        line(cv, [(cx - 6.4 * math.cos(t), cy - 6.4 * math.sin(t)), (cx + 6.4 * math.cos(t), cy + 6.4 * math.sin(t))], 0.4,
             C(150, 150, 168), 0.7, False)
    # expansion slots (horizontal, 4 of them)
    for i in range(4):
        y = 26 + i * 4.2
        dark_hole(cv, (15, y, 50, y + 2.6), 0.9)
        for k in range(0, 35, 2):
            rr(cv, (16 + k, y + 0.5, 16.8 + k, y + 2.1), 0.2, C(110, 110, 126), 0.65)
    # PSU opening (bottom)
    dark_hole(cv, (16, 43.5, 50, 58.5), 1.6)
    cx, cy = 33, 51
    ell(cv, cx, cy, 6.2, 6.2, C(90, 90, 104))
    for rad in (5.2, 3.6, 2.0):
        ring(cv, lambda d, i, rad=rad: d.ellipse([(cx - rad + i) * S, (cy - rad + i) * S, (cx + rad - i) * S, (cy + rad - i) * S], fill=255),
             0.4, C(150, 150, 168), 0.8)
    for a in range(0, 180, 30):
        t = math.radians(a)
        line(cv, [(cx - 5.4 * math.cos(t), cy - 5.4 * math.sin(t)), (cx + 5.4 * math.cos(t), cy + 5.4 * math.sin(t))], 0.35,
             C(150, 150, 168), 0.7, False)
    ell(cv, cx, cy, 1.0, 1.0, C(255, 154, 31))
    # PSU socket + switch hint
    rr(cv, (42, 46, 48.4, 50.6), 0.6, C(60, 60, 70))
    rr(cv, (42.6, 46.6, 47.8, 50.0), 0.4, C(20, 20, 26))
    # screws
    for (sx, sy) in ((12, 3), (52, 3), (12, 58), (52, 58)):
        ell(cv, sx, sy, 1.0, 1.0, C(190, 180, 162))
        line(cv, [(sx - 0.6, sy - 0.6), (sx + 0.6, sy + 0.6)], 0.3, C(110, 100, 84))
    # bevels
    rr(cv, (10, 0, 54, 0.9), 0, C(255, 255, 255), 0.5)
    rr(cv, (10, 59.8, 54, 61), 0, C(120, 105, 80), 0.3)
    img = finish(cv)
    speckle(img, 2, 7, (10, 0, 54, 61))
    px = img.load()
    for y in range(64):
        for x in range(64):
            if not (10 <= x < 54 and y < 61):
                px[x, y] = (0, 0, 0, 0)
    save(img, "pc_case_back.png")


# =====================================================================================
# TRAY (inner face of the west wall, viewed from east: u = 16 - z ; region z 2..14 -> px 8..56 ; y 3..15 -> rows 4..52)
# =====================================================================================
STANDOFFS = [(5, 5), (5, 9), (5, 13), (8, 5), (8, 13), (11, 5), (11, 9), (11, 13)]  # (z, y)


def make_tray():
    cv = new_canvas()
    x0, y0, x1, y1 = 8, 4, 56, 52
    cream_panel(cv, (x0, y0, x1, y1), 0, C(214, 211, 204), C(184, 180, 172))
    # brushed vertical streaks
    rnd = random.Random(11)
    for _ in range(46):
        x = rnd.uniform(x0, x1)
        line(cv, [(x, y0), (x, y1)], rnd.uniform(0.15, 0.5), C(255, 255, 255) if rnd.random() < 0.5 else C(150, 140, 120),
             0.10, False)
    # border groove
    ring(cv, lambda d, i: d.rounded_rectangle([(x0 + 0.5 + i) * S, (y0 + 0.5 + i) * S, (x1 - 0.5 - i) * S, (y1 - 0.5 - i) * S],
                                              max((1.2 - i) * S, 1), fill=255), 0.55, C(170, 160, 142), 0.8)
    # orange trim at the front edge (right in this view)
    rr(cv, (x1 - 2.6, y0 + 1.5, x1 - 1.6, y1 - 1.5), 0.4, C(255, 154, 31), 0.95)
    rr(cv, (x1 - 2.4, y0 + 1.7, x1 - 2.0, y1 - 1.7), 0.2, C(255, 214, 128), 0.8)
    # big CPU cutout
    cx, cy = 30, 24
    rr(cv, (cx - 7.8, cy - 7.8, cx + 7.8, cy + 7.8), 2.2, C(150, 140, 122))
    rr(cv, (cx - 7, cy - 7, cx + 7, cy + 7), 1.8, lin_grad(C(34, 34, 42), C(70, 70, 82), (cx - 7, cy - 7), (cx + 7, cy + 7)))
    rr(cv, (cx - 7, cy + 6.2, cx + 7, cy + 7), 0.2, C(255, 255, 255), 0.16)
    # cable routing slots
    for box in ((12, 12, 14.4, 40), (45, 9, 48, 17), (45, 31, 48, 41)):
        rr(cv, (box[0] - 0.5, box[1] - 0.5, box[2] + 0.5, box[3] + 0.5), 1.4, C(150, 140, 122))
        rr(cv, box, 1.1, lin_grad(C(34, 34, 42), C(70, 70, 82), (box[0], box[1]), (box[2], box[3])))
        rr(cv, (box[0] + 0.2, box[1] - 0.2, box[2] - 0.2, box[1] + 0.4), 0.2, C(255, 255, 255), 0.0)
    # rubber grommets (inside slots)
    for box in ((12, 12, 14.4, 40), (45, 9, 48, 17), (45, 31, 48, 41)):
        ring(cv, lambda d, i, b=box: d.rounded_rectangle([(b[0] - 0.9 + i) * S, (b[1] - 0.9 + i) * S, (b[2] + 0.9 - i) * S, (b[3] + 0.9 - i) * S],
                                                         max((1.8 - i) * S, 1), fill=255), 0.5, C(120, 120, 134), 0.9)
    # vent holes (top strip) 2 rows of dots
    for row in range(2):
        for k in range(8):
            ell(cv, 17 + k * 2.4, 7.3 + row * 1.9, 0.62, 0.62, C(70, 66, 60))
    # standoff holes (u = (16 - z)*4 ; row = (16 - y)*4)
    for (z, y) in STANDOFFS:
        u, v = (16 - z) * 4, (16 - y) * 4
        ell(cv, u, v, 1.7, 1.7, C(160, 150, 130))
        ell(cv, u, v, 1.1, 1.1, C(70, 64, 56))
    # paw logo (bottom-left in this view)
    px_, py_ = 16, 46
    ell(cv, px_, py_ + 0.9, 2.2, 1.7, C(255, 172, 60), 0.9)
    for (dx, dy) in ((-2.7, -1.3), (-0.9, -2.7), (0.9, -2.7), (2.7, -1.3)):
        ell(cv, px_ + dx, py_ + dy, 0.8, 1.0, C(255, 172, 60), 0.9)
    # screws in the corners
    for (sx, sy) in ((x0 + 2.4, y0 + 2.4), (x0 + 2.4, y1 - 2.4), (x1 - 4.8, y0 + 2.4), (x1 - 4.8, y1 - 2.4)):
        ell(cv, sx, sy, 0.9, 0.9, C(190, 180, 162))
    img = finish(cv)
    speckle(img, 2, 9, (x0, y0, x1, y1))
    save(img, "pc_case_tray.png")


# =====================================================================================
# TOP (viewed from above: u = X ; v = z)
# =====================================================================================
def make_top():
    # drawn "upright" as seen from above by a player standing in front of the case (back of the case = picture top),
    # then rotated 180 deg to match the face uv (u = x, v = z). Card = px 10..53 x 4..51 before rotation
    # (-> u 10..53, v 8..59 after rotation = x 2.5..13.5, z 2..15).
    cv = new_canvas()
    cream_panel(cv, (10, 4, 54, 56), 0, C(254, 252, 247), C(241, 237, 228))
    ell(cv, 27, 15, 24, 16, C(255, 255, 255), 0.25)
    # faint diagonal pattern
    hatch = mask_from(lambda d: [d.line([(x * S, 0), ((x - 64) * S, 64 * S)], fill=255, width=int(1.0 * S)) for x in range(0, 140, 5)])
    comp(cv, hatch, C(214, 206, 190), 0.16)
    OR, OR_D = C(255, 154, 31), C(214, 98, 0)
    # two accent lines
    rr(cv, (13, 35.0, 51, 36.4), 0.4, OR, 0.95)
    rr(cv, (13, 38.0, 51, 39.4), 0.4, OR, 0.95)
    # target badge with a paw
    bx, by = 46, 27
    ell(cv, bx, by, 5.6, 5.6, OR_D)
    ell(cv, bx, by, 5.2, 5.2, OR)
    ell(cv, bx, by, 3.8, 3.8, C(254, 252, 247))
    ell(cv, bx, by, 3.2, 3.2, OR)
    ell(cv, bx, by + 0.9, 1.4, 1.1, C(254, 252, 247))
    for (dx, dy) in ((-1.8, -0.5), (-0.65, -1.6), (0.65, -1.6), (1.8, -0.5)):
        ell(cv, bx + dx, by + dy, 0.5, 0.6, C(254, 252, 247))
    # screws
    for (sx, sy) in ((12, 6), (52, 6), (12, 54), (52, 54)):
        ell(cv, sx, sy, 0.9, 0.9, C(190, 180, 162))
    rr(cv, (10, 4, 54, 4.9), 0, C(255, 255, 255), 0.4)
    img = finish(cv)
    put_text(img, 13, 8, "SHINE UP", OR, shadow=(0, 1, C(214, 98, 0, 255)))
    put_text(img, 13, 15, "YOUR STYLE", OR, shadow=(0, 1, C(214, 98, 0, 255)))
    put_text(img, 13, 22, "MEOW", OR, shadow=(0, 1, C(214, 98, 0, 255)))
    px = img.load()
    for y in range(64):
        for x in range(64):
            if not (10 <= x < 54 and 4 <= y < 56):
                px[x, y] = (0, 0, 0, 0)
    speckle(img, 2, 13, (10, 4, 54, 56))
    save(img.rotate(180), "pc_case_top.png")


# =====================================================================================
# MISC atlas : 4x4 grid of 16x16 patches
# =====================================================================================
def patch(img, gx, gy, c0, c1, noise=0, seed=0):
    x0, y0 = gx * 16, gy * 16
    px = img.load()
    rnd = random.Random(seed)
    for y in range(16):
        for x in range(16):
            t = (x + y) / 30.0
            c = tuple(int(c0[i] + (c1[i] - c0[i]) * t) for i in range(3))
            n = rnd.randint(-noise, noise) if noise else 0
            px[x0 + x, y0 + y] = (max(0, min(255, c[0] + n)), max(0, min(255, c[1] + n)), max(0, min(255, c[2] + n)), 255)


def make_misc():
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    patch(img, 0, 0, (254, 252, 247), (243, 239, 230), 1, 1)  # cream
    patch(img, 1, 0, (214, 205, 188), (196, 187, 170), 1, 2)  # cream dark (underside)
    patch(img, 2, 0, (255, 170, 52), (246, 140, 14), 0, 3)  # orange
    patch(img, 3, 0, (214, 102, 0), (190, 84, 0), 0, 4)  # orange dark
    patch(img, 0, 1, (40, 42, 50), (58, 60, 70), 1, 5)  # graphite
    patch(img, 1, 1, (176, 168, 152), (160, 152, 136), 1, 6)  # inner floor
    patch(img, 2, 1, (224, 182, 92), (196, 150, 60), 1, 7)  # brass
    patch(img, 3, 1, (255, 224, 150), (255, 206, 110), 0, 8)  # orange highlight
    patch(img, 0, 2, (54, 54, 60), (70, 70, 78), 1, 9)  # rubber
    patch(img, 1, 2, (232, 226, 214), (214, 207, 192), 1, 10)  # inner wall cream
    patch(img, 2, 2, (255, 246, 214), (255, 226, 160), 0, 11)  # screen edge
    save(img, "pc_case_misc.png")


if __name__ == "__main__":
    make_front()
    make_side()
    make_glass()
    make_west()
    make_back()
    make_tray()
    make_top()
    make_misc()
