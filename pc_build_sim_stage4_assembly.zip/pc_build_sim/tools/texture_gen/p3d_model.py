"""Box DSL + the nine PC parts, built as Minecraft item models (cuboids, a few rotated).

LOCAL FRAME (what you see looking straight down at the part, like the old 2D icon):
    a -> image right, b -> image down, h -> up.   Units are model units (1 = 1/16 block, 4 texels).
WORLD FRAME is x = 16 - a, z = 16 - b, y = h  (so in the inventory icon you see the image's LEFT edge (L)
and BOTTOM edge (B) plus the top; the right/top edges are the 'back').
Face keys: top, L, R, T, B  (left/right/top/bottom edge of the image).
Face spec: 'patch_name' | '*patch_name' (emissive) | ('art',) top-view art | ('reg', name, *flags) atlas region"""
import math
import p3d_tex as T

MOD = "pcbuildsim"
EPS = 1e-6
FACE_MAP = {"top": "up", "L": "east", "R": "west", "T": "south", "B": "north"}


class Box:
    def __init__(self, a1, a2, b1, b2, h1, h2, faces, rot, name):
        self.a1, self.a2, self.b1, self.b2, self.h1, self.h2 = a1, a2, b1, b2, h1, h2
        self.faces, self.rot, self.name = faces, rot, name


class Part:
    def __init__(self, name, art):
        self.name, self.art, self.boxes = name, art, []

    def box(self, a1, a2, b1, b2, h1, h2, top=None, side=None, L=None, R=None, T=None, B=None, rot=None, name=None, origin=None):
        """rot=angle (deg, +CCW seen from above, multiple of 22.5, |a|<=45) about the vertical axis through `origin`
        (local a,b) or the box centre."""
        faces = {"top": top, "L": L or side, "R": R or side, "T": T or side, "B": B or side}
        if rot:
            oa, ob = origin if origin else ((a1 + a2) / 2, (b1 + b2) / 2)
            rot = (rot, oa, ob, (h1 + h2) / 2)
        self.boxes.append(Box(a1, a2, b1, b2, h1, h2, {k: v for k, v in faces.items() if v}, rot, name or f"{self.name}_{len(self.boxes)}"))
        return self

    def disc(self, ca, cb, r, h1, h2, top, side, name=None):
        """stepped 'cylinder' (12-gon-ish): two crossed slabs + a centre square, like the case buttons"""
        k1, k2, k3 = 0.924 * r, 0.383 * r, 0.653 * r
        self.box(ca - k1, ca + k1, cb - k2, cb + k2, h1, h2, top=top, side=side, name=name)
        self.box(ca - k2, ca + k2, cb - k1, cb + k1, h1, h2, top=top, side=side, name=name)
        self.box(ca - k3, ca + k3, cb - k3, cb + k3, h1, h2, top=top, side=side, name=name)
        return self


# ------------------------------------------------------------------ geometry helpers
def covered(b, key, boxes):
    if b.rot:
        return False
    for o in boxes:
        if o is b or o.rot:
            continue
        if key == "top":
            if abs(o.h1 - b.h2) < EPS and o.a1 <= b.a1 + EPS and o.a2 >= b.a2 - EPS and o.b1 <= b.b1 + EPS and o.b2 >= b.b2 - EPS:
                return True
        elif key in ("L", "R"):
            p = b.a1 if key == "L" else b.a2
            q = o.a2 if key == "L" else o.a1
            if abs(p - q) < EPS and o.b1 <= b.b1 + EPS and o.b2 >= b.b2 - EPS and o.h1 <= b.h1 + EPS and o.h2 >= b.h2 - EPS:
                return True
        else:
            p = b.b1 if key == "T" else b.b2
            q = o.b2 if key == "T" else o.b1
            if abs(p - q) < EPS and o.a1 <= b.a1 + EPS and o.a2 >= b.a2 - EPS and o.h1 <= b.h1 + EPS and o.h2 >= b.h2 - EPS:
                return True
    return False


def r4(v):
    return round(v, 4)


def face_json(b, key, spec):
    flags = ()
    if isinstance(spec, str):
        emis = spec.startswith("*")
        name = spec.lstrip("*")
        f = {"uv": [r4(v) for v in T.ATLAS.patch_uv(name)], "texture": "#atlas"}
    elif spec[0] == "art":
        emis = False
        f = {"uv": [r4(b.a2), r4(b.b2), r4(b.a1), r4(b.b1)], "texture": "#art"}
    elif spec[0] == "reg":
        flags = spec[2:]
        emis = "emis" in flags
        f = {"uv": [r4(v) for v in T.ATLAS.reg_uv(spec[1], "fx" in flags, "fy" in flags)], "texture": "#atlas"}
    else:
        raise ValueError(spec)
    if emis:
        f["neoforge_data"] = {"block_light": 15, "sky_light": 15}
    return f


def build_elements(part):
    els = []
    for b in part.boxes:
        faces = {}
        for key, spec in b.faces.items():
            if key == "top" and b.h2 - b.h1 < EPS:
                pass
            elif covered(b, key, part.boxes):
                continue
            faces[FACE_MAP[key]] = face_json(b, key, spec)
        if not faces:
            continue
        el = {"name": b.name,
              "from": [r4(16 - b.a2), r4(b.h1), r4(16 - b.b2)],
              "to": [r4(16 - b.a1), r4(b.h2), r4(16 - b.b1)],
              "faces": faces}
        if b.rot:
            ang, oa, ob, oh = b.rot
            el["rotation"] = {"angle": ang, "axis": "y", "origin": [r4(16 - oa), r4(oh), r4(16 - ob)]}
        if any("neoforge_data" in f for f in faces.values()):
            el["shade"] = False
        els.append(el)
    return els


# =================================================================== PARTS
def gpu():
    T.reg_gpu_misc()
    p = Part("gpu", "gpu_top")
    art = ("art",)
    # slot bracket (port face looks to the left)
    p.box(1.0, 1.7, 2.0, 12.0, 0, 4.6, side="silver", top="silver_l", L=("reg", "bracket"))
    # PCB + PCIe gold fingers
    p.box(1.7, 15.4, 3.0, 11.4, 0, 0.6, side="graph", top="graph")
    p.box(2.6, 12.4, 11.4, 12.4, 0, 0.6, side="graph", top=("reg", "fing_top"), B=("reg", "fing_front"))
    # cooler body: floor + frame with three fan windows (shallow, so the blades read in the inventory view)
    p.box(1.7, 15.8, 2.6, 11.4, 0.6, 2.6, side="cream_s", top="black")
    holes = [(2.6, 6.1), (6.45, 9.95), (10.3, 13.8)]
    p.box(1.7, 2.6, 2.6, 11.4, 2.6, 3.6, side="cream", top=art, R="graph")
    p.box(13.8, 15.8, 2.6, 11.4, 2.6, 3.6, side="cream", top=art, L="graph")
    p.box(6.1, 6.45, 5.25, 8.75, 2.6, 3.6, side="graph", top=art)
    p.box(9.95, 10.3, 5.25, 8.75, 2.6, 3.6, side="graph", top=art)
    p.box(2.6, 13.8, 2.6, 5.25, 2.6, 3.6, side="cream", top=art, B="graph")
    p.box(2.6, 13.8, 8.75, 11.4, 2.6, 3.6, side="cream", top=art, T="graph")
    # fans: floating blade plate + hub
    for (a0, a1), fan, hub in zip(holes, ("fan_w1", "fan_o", "fan_w1"), ("or", "white", "or")):
        cx = (a0 + a1) / 2
        p.box(cx - 1.75, cx + 1.75, 5.25, 8.75, 3.05, 3.05, top=("reg", fan))
        p.disc(cx, 7.0, 0.5, 3.05, 3.4, top=hub, side=hub if hub != "white" else "cream_s")
    # rgb strip on the front wall + 12V plug on the back edge
    p.box(2.4, 15.2, 11.4, 11.6, 1.3, 2.0, side="black", top="black", B=("reg", "rgb", "emis"))
    p.box(10.6, 13.4, 2.0, 3.4, 2.4, 4.3, side="black", top=("reg", "pins"), B="black_l")
    return p


def motherboard():
    T.reg_misc()
    p = Part("motherboard", "mb_top")
    art = ("art",)
    p.box(1.0, 15.0, 1.0, 15.0, 0, 0.8, side="pcb_e", top=art)
    # white VRM / io armour (L shape) with fin ribs
    p.box(2.6, 6.0, 1.5, 9.25, 0.8, 2.8, side="cream", top=art)
    p.box(6.0, 11.5, 1.5, 4.0, 0.8, 2.8, side="cream", top=art)
    for k in range(9):
        a = 6.3 + 0.6 * k
        p.box(a, a + 0.3, 1.9, 3.6, 2.8, 3.3, side="cream_s", top="cream_l")
    for k in range(11):
        b = 2.1 + 0.62 * k
        p.box(3.0, 5.6, b, b + 0.3, 2.8, 3.3, side="cream_s", top="cream_l")
    # orange tag on the armour
    p.box(2.9, 4.7, 1.7, 2.2, 2.8, 3.05, side="or_d", top="or")
    # i/o ports poke out of the left edge
    for i, reg in enumerate(("port_usb", "port_usb", "port_blue", "port_rj")):
        b = 2.4 + 1.5 * i
        p.box(0.7, 2.6, b, b + 1.2, 0.8, 2.3, side="black", top="black_l", L=("reg", reg))
    # CPU socket: frame + recessed contact field
    p.box(6.25, 11.5, 4.25, 4.65, 0.8, 1.7, side="silver", top="silver_l")
    p.box(6.25, 11.5, 9.1, 9.5, 0.8, 1.7, side="silver", top="silver_l")
    p.box(6.25, 6.65, 4.65, 9.1, 0.8, 1.7, side="silver", top="silver_l")
    p.box(11.1, 11.5, 4.65, 9.1, 0.8, 1.7, side="silver", top="silver_l")
    p.box(6.65, 11.1, 4.65, 9.1, 0.8, 1.0, side="graph", top=art)
    p.box(5.9, 6.25, 5.2, 8.4, 0.8, 2.0, side="silver_d", top="silver")  # retention lever
    # RAM slots with clips
    for i in range(4):
        a = 12.125 + 0.675 * i
        p.box(a, a + 0.5, 1.5, 9.25, 0.8, 2.2, side="black", top=art)
        p.box(a - 0.05, a + 0.55, 1.3, 2.0, 0.8, 2.6, side="cream_l", top="white")
    # PCIe x16 slot
    p.box(2.0, 10.0, 10.0, 11.0, 0.8, 1.9, side="black", top=art)
    p.box(1.8, 2.2, 10.0, 11.0, 0.8, 2.1, side="silver_d", top="silver")
    # M.2 shield with screw
    p.box(2.0, 8.5, 11.5, 12.9, 0.8, 1.7, side="cream", top=art)
    p.box(7.8, 8.3, 12.0, 12.4, 1.7, 2.0, side="silver_d", top="silver_l")
    # chipset heatsink
    p.box(9.5, 14.0, 11.0, 14.5, 0.8, 2.0, side="cream", top=art, L=("reg", "fins"), B=("reg", "fins"))
    # MEOW label pill
    p.box(2.0, 7.25, 13.35, 14.65, 0.8, 1.2, side="or_d", top=art)
    # SATA ports on the back edge
    for b in (9.5, 10.3):
        p.box(14.0, 14.85, b, b + 0.6, 0.8, 1.9, side="black", top="black_l")
    return p


def cpu():
    p = Part("cpu", "cpu_top")
    art = ("art",)
    p.box(1.75, 14.25, 1.75, 14.25, 0, 0.9, side="cream_d", top=art)
    for i in range(9):
        t = 2.75 + 1.3 * i
        for (a1, a2, b1, b2) in ((t - 0.25, t + 0.25, 2.2, 2.55), (t - 0.25, t + 0.25, 13.45, 13.8), (2.2, 2.55, t - 0.25, t + 0.25), (13.45, 13.8, t - 0.25, t + 0.25)):
            if (a1 < 3.9 and b1 < 3.9):
                continue
            p.box(a1, a2, b1, b2, 0.9, 1.15, side="gold_d", top="gold")
    p.box(3.5, 12.5, 3.5, 12.5, 0.9, 1.7, side="silver_d", top=art)
    p.box(4.0, 12.0, 4.0, 12.0, 1.7, 2.2, side="silver", top=art)
    return p


def cpu_cooler():
    T.reg_misc()
    p = Part("cpu_cooler", "cooler_top")
    art = ("art",)
    # --- pump head
    p.box(0.75, 6.5, 4.1, 9.85, 0, 0.8, side="or_d", top="or_d")
    p.box(0.85, 6.4, 4.2, 9.75, 0.8, 4.0, side="cream", top=art)
    p.disc(3.625, 6.975, 1.2, 4.0, 4.35, top="black", side="graph")
    p.disc(3.625, 6.975, 0.55, 4.35, 4.55, top="gold_l", side="gold")
    # --- hoses: two braided hoses bridging pump -> radiator housing, crimp collars + orange rings
    for b in (7.0, 8.95):
        p.box(6.3, 9.2, b - 0.5, b + 0.5, 2.2, 3.2, side="silver", top="silver_l")
        p.box(6.4, 6.95, b - 0.62, b + 0.62, 2.05, 3.35, side="metal", top="silver_d")
        p.box(8.55, 9.2, b - 0.62, b + 0.62, 2.05, 3.35, side="metal", top="silver_d")
        p.box(7.3, 7.55, b - 0.55, b + 0.55, 2.1, 3.3, side="or", top="or_l")
    # --- radiator + fan
    p.box(9.0, 15.4, 4.8, 13.6, 0, 1.6, side="cream", top=art, L=("reg", "fins"), B=("reg", "fins"))
    p.box(9.1, 15.3, 6.1, 6.6, 1.6, 2.9, side="cream", top="cream_l", B="black")
    p.box(9.1, 15.3, 11.8, 12.3, 1.6, 2.9, side="cream", top="cream_l", T="black")
    p.box(9.1, 9.6, 6.6, 11.8, 1.6, 2.9, side="cream", top="or", R="black")
    p.box(14.8, 15.3, 6.6, 11.8, 1.6, 2.9, side="cream", top="or", L="black")
    p.box(9.6, 14.8, 6.6, 11.8, 1.6, 1.8, side="black", top="black")
    p.box(9.65, 14.75, 6.65, 11.75, 2.45, 2.45, top=("reg", "fan_aio"))
    p.disc(12.2, 9.2, 0.85, 2.45, 2.85, top="cream_l", side="cream_s")
    p.disc(12.2, 9.2, 0.4, 2.85, 3.0, top="or", side="or_d")
    return p


def ram():
    T.reg_misc()
    p = Part("ram", "ram_top")
    art = ("art",)
    p.box(0.75, 15.25, 9.5, 10.75, 0, 0.4, side="graph", top=art, B=("reg", "ram_fing_front"))
    p.box(0.75, 15.25, 5.25, 9.5, 0.4, 1.5, side="cream", top="cream_s")
    p.box(1.0, 15.0, 5.5, 9.25, 1.5, 2.3, side="cream_l", top=art)
    p.box(1.5, 14.5, 5.7, 6.7, 2.3, 2.65, side="*led_w", top=("reg", "rgb_bar", "emis"))
    # little heat-spreader clips on both ends
    p.box(0.55, 0.75, 6.0, 9.0, 0.4, 1.9, side="silver", top="silver_l")
    p.box(15.25, 15.45, 6.0, 9.0, 0.4, 1.9, side="silver", top="silver_l")
    return p


def ssd_m2():
    p = Part("ssd_m2", "m2_top")
    art = ("art",)
    p.box(0.75, 15.25, 4.75, 11.25, 0, 0.5, side="graph", top=art)
    p.box(1.65, 14.25, 5.35, 10.65, 0.5, 1.2, side="or_d", top=art)
    p.box(1.95, 13.95, 5.65, 10.35, 1.2, 1.65, side="or", top=art)
    p.disc(1.15, 8.0, 0.5, 0.5, 1.1, top="silver_l", side="silver")
    return p


def ssd_sata():
    T.reg_misc()
    p = Part("ssd_sata", "sata_top")
    art = ("art",)
    p.box(2.0, 14.0, 1.75, 13.25, 0, 1.8, side="silver", top="silver_l")
    p.box(2.15, 13.85, 1.9, 13.1, 1.8, 2.3, side="silver_l", top=art)
    for (a, b) in ((2.9, 2.65), (13.1, 2.65), (2.9, 12.35), (13.1, 12.35)):
        p.box(a - 0.3, a + 0.3, b - 0.3, b + 0.3, 2.3, 2.45, side="silver_d", top="silver")
    p.box(5.5, 10.0, 13.25, 15.0, 0.4, 1.8, side="black", top="black_l", B=("reg", "sata_data"))
    p.box(10.4, 13.0, 13.25, 15.0, 0.4, 1.8, side="black", top="black_l", B=("reg", "sata_pow"))
    return p


def hdd():
    T.reg_misc()
    p = Part("hdd", "hdd_top")
    art = ("art",)
    p.box(1.5, 14.5, 1.25, 14.75, 0, 2.8, side="silver", top="silver_l")
    p.box(1.8, 14.2, 1.55, 14.45, 2.8, 3.3, side="silver_l", top=art)
    p.box(2.75, 13.25, 2.25, 6.75, 3.3, 3.42, side="cream", top=art)
    for (a, b) in ((2.35, 2.0), (13.65, 2.0), (2.35, 14.0), (13.65, 14.0)):
        p.box(a - 0.3, a + 0.3, b - 0.3, b + 0.3, 3.3, 3.5, side="silver_d", top="silver")
    # platter (octagon: art square + turned square), hub, actuator arm
    p.disc(8.0, 10.75, 3.0, 3.3, 3.55, top=art, side="silver")
    p.box(7.5, 8.5, 10.25, 11.25, 3.55, 3.8, side="silver_d", top="metal")
    p.box(8.0, 13.0, 10.45, 11.05, 3.8, 4.05, side="metal", top="graph_l", rot=22.5, origin=(8.0, 10.75))
    p.box(12.2, 13.1, 8.4, 9.3, 3.3, 4.15, side="silver_d", top="silver")
    # sata + power plugs on the front edge
    p.box(8.4, 12.4, 14.75, 15.8, 0.5, 1.9, side="black", top="black_l", B=("reg", "sata_data"))
    p.box(12.7, 14.2, 14.75, 15.8, 0.5, 1.9, side="black", top="black_l", B=("reg", "sata_pow"))
    p.box(5.4, 7.4, 14.75, 15.4, 0.5, 1.5, side="black_l", top="graph_l")
    return p


def psu():
    T.reg_misc()
    p = Part("psu", "psu_top")
    art = ("art",)
    p.box(0.9, 13.1, 2.65, 13.1, 0, 0.6, side="or_d", top="or_d")
    p.box(1.0, 13.0, 2.75, 13.0, 0.6, 6.0, side="cream", top=art, B=("reg", "psu_ports"), L=("reg", "psu_rear"))
    p.box(1.7, 9.3, 4.45, 12.05, 6.35, 6.35, top=("reg", "grille"))
    p.disc(5.5, 8.25, 0.6, 6.0, 6.35, top="or", side="or_d")
    # rear: AC inlet + rocker switch
    p.box(0.55, 1.0, 7.5, 10.5, 2.0, 3.8, side="black", top="black_l", L=("reg", "ac_inlet"))
    p.box(0.7, 1.0, 11.2, 12.5, 2.4, 4.0, side="or_d", top="or")
    # modular cables: one tidy row of four sleeved cables, outer ones fan out a little
    cable = [(2.9, "or", "or_l", -22.5), (5.6, "graph", "graph_l", 0), (8.4, "yellow", "or_ll", 0), (11.1, "or", "or_l", 22.5)]
    for a, side, top, ang in cable:
        h = 4.4
        p.box(a - 0.45, a + 0.45, 13.0, 15.2, h - 0.45, h + 0.45, side=side, top=top, rot=ang, origin=(a, 13.0))
        p.box(a - 0.6, a + 0.6, 15.2, 16.1, h - 0.6, h + 0.6, side="black", top="black_l", rot=ang, origin=(a, 13.0))
        p.box(a - 0.35, a + 0.35, 16.1, 16.3, h - 0.35, h + 0.35, side="gold_d", top="gold", rot=ang, origin=(a, 13.0))
    return p


PARTS = {
    "motherboard": motherboard, "cpu": cpu, "cpu_cooler": cpu_cooler, "gpu": gpu, "ram": ram,
    "ssd_m2": ssd_m2, "ssd_sata": ssd_sata, "hdd": hdd, "psu": psu,
}
