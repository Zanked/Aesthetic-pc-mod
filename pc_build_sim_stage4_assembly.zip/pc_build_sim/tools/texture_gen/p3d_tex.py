"""Textures for the 3D PC parts:
   * parts_atlas.png  - palette patches + small detail regions (ports, fans, gold fingers...), 4 px per model unit
   * <part>_top.png   - flat top-view art for every part (the old icons re-painted without baked shadows/bevels)
Everything is pixel-art-ish and matches the cream/orange cat style of the case."""
import math, os
from PIL import Image, ImageDraw
import lib
from lib import *
import gen_items, gen_items2, gen_items3

# ---------------------------------------------------------------- flatten old painters (3D gives its own shading)
for _m in (gen_items, gen_items2, gen_items3):
    _m.shadowed = lambda cv, strength=0.0: cv
    _m.bevel = lambda *a, **k: None

AT = 128  # atlas size (px); 16 model units == 128 px -> 8 px / uv-unit


# ---------------------------------------------------------------- palette
PAL = {
    "cream": (244, 239, 229), "cream_l": (253, 251, 245), "cream_s": (224, 216, 202), "cream_d": (196, 187, 170),
    "white": (255, 255, 255), "pcb_w": (250, 250, 253), "pcb_e": (214, 218, 228),
    "or": (255, 154, 31), "or_l": (255, 198, 100), "or_ll": (255, 224, 160), "or_d": (224, 106, 0), "or_dd": (166, 70, 0),
    "graph": (46, 48, 56), "graph_l": (78, 82, 94), "black": (26, 26, 32), "black_l": (44, 46, 56),
    "silver": (200, 204, 214), "silver_l": (240, 242, 248), "silver_d": (140, 146, 160), "metal": (96, 100, 114),
    "gold": (240, 190, 60), "gold_l": (255, 226, 120), "gold_d": (190, 140, 40), "brass": (214, 170, 86),
    "rubber": (36, 36, 40), "led_b": (90, 170, 255), "led_p": (255, 120, 200), "led_y": (255, 224, 100),
    "led_w": (255, 248, 230), "led_g": (120, 255, 170), "glass": (150, 210, 230), "red": (230, 70, 60),
    "usb_blue": (60, 120, 230), "yellow": (255, 214, 90), "pcb_g": (40, 110, 84),
}
PAL_NAMES = list(PAL)


class Atlas:
    def __init__(self):
        self.img = Image.new("RGBA", (AT, AT), (0, 0, 0, 0))
        self.regs = {}
        self.cells = {}
        for i, n in enumerate(PAL_NAMES):
            x, y = (i % 32) * 4, (i // 32) * 4
            ImageDraw.Draw(self.img).rectangle([x, y, x + 3, y + 3], fill=PAL[n] + (255,))
            self.cells[n] = (x, y)
        self.cx, self.cy, self.rowh = 0, 8, 0

    def reg(self, name, w, h, painter):
        if name in self.regs:
            return self.regs[name]
        if self.cx + w > AT:
            self.cx, self.cy, self.rowh = 0, self.cy + self.rowh + 1, 0
        assert self.cy + h <= AT, "atlas full"
        im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        painter(im, ImageDraw.Draw(im))
        self.img.alpha_composite(im, (self.cx, self.cy))
        self.regs[name] = (self.cx, self.cy, self.cx + w, self.cy + h)
        self.cx += w + 1
        self.rowh = max(self.rowh, h)
        return self.regs[name]

    def patch_uv(self, name):
        x, y = self.cells[name]
        return [(x + 1) / 8.0, (y + 1) / 8.0, (x + 3) / 8.0, (y + 3) / 8.0]

    def reg_uv(self, name, flipx=False, flipy=False):
        x0, y0, x1, y1 = self.regs[name]
        u1, v1, u2, v2 = x0 / 8.0, y0 / 8.0, x1 / 8.0, y1 / 8.0
        if flipx:
            u1, u2 = u2, u1
        if flipy:
            v1, v2 = v2, v1
        return [u1, v1, u2, v2]


ATLAS = Atlas()


# ---------------------------------------------------------------- tiny pixel helpers
def R(d, x0, y0, x1, y1, c):
    d.rectangle([x0, y0, x1 - 1, y1 - 1], fill=tuple(c) + ((255,) if len(c) == 3 else ()))


def P(n):
    return PAL[n]


def downsample(im, N):
    return im.convert("RGBa").resize((N, N), Image.LANCZOS).convert("RGBA")


def fan_tex(N, n, blade, blade_hi, hub, rim=(34, 34, 42), frame=(170, 176, 190), twist=0.9, hub_r=0.28):
    """top-view fan with transparent corners (cutout plate)"""
    S = 8
    im = Image.new("RGBA", (N * S, N * S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = N * S / 2
    Rr = c - 0.15 * S
    d.ellipse([c - Rr, c - Rr, c + Rr, c + Rr], fill=frame + (255,))
    r2 = Rr * 0.9
    d.ellipse([c - r2, c - r2, c + r2, c + r2], fill=rim + (255,))
    r0 = Rr * 0.26
    wd = 2 * math.pi / n * 0.62
    Rb = Rr * 0.86
    for i in range(n):
        a = 2 * math.pi * i / n
        pts = []
        for (rad, da) in ((r0, -wd * 0.25), (Rb, twist - wd * 0.5), (Rb, twist + wd * 0.5), (r0, wd * 0.6)):
            pts.append((c + rad * math.cos(a + da), c + rad * math.sin(a + da)))
        d.polygon(pts, fill=blade + (255,))
        mid = ((pts[1][0] + pts[2][0]) / 2, (pts[1][1] + pts[2][1]) / 2)
        d.polygon([pts[0], pts[1], mid], fill=blade_hi + (255,))
    hr = Rr * hub_r
    d.ellipse([c - hr, c - hr, c + hr, c + hr], fill=hub + (255,))
    d.ellipse([c - hr * 0.55 - hr * 0.2, c - hr * 0.55 - hr * 0.25, c + hr * 0.1, c + hr * 0.05], fill=(255, 255, 255, 140))
    return downsample(im, N)


def grille_tex(N):
    """PSU wire fan guard: thin concentric rings + spokes on transparent"""
    S = 8
    im = Image.new("RGBA", (N * S, N * S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = N * S / 2
    col = (176, 180, 198, 255)
    for k, rad in enumerate((0.48, 0.36, 0.24, 0.12)):
        rr_ = rad * N * S
        d.ellipse([c - rr_, c - rr_, c + rr_, c + rr_], outline=col, width=int(S * 0.7))
    for k in range(6):
        t = math.pi * k / 6
        x, y = math.cos(t) * 0.48 * N * S, math.sin(t) * 0.48 * N * S
        d.line([c - x, c - y, c + x, c + y], fill=col, width=int(S * 0.7))
    r = 0.07 * N * S
    d.ellipse([c - r, c - r, c + r, c + r], fill=(255, 154, 31, 255))
    return downsample(im, N)


def fingers(w, h, notch=None, pitch=3, bar=2, plain_rows=0):
    def paint(im, d):
        R(d, 0, 0, w, h, (30, 30, 38))
        for x in range(1, w - 1, pitch):
            if notch and notch[0] <= x < notch[1]:
                continue
            R(d, x, 0, min(x + bar, w - 1), h, (240, 190, 60))
            R(d, x, 0, min(x + bar, w - 1), 1, (255, 232, 140))
    return paint


def rainbow(w, h, stops):
    def paint(im, d):
        for x in range(w):
            t = x / max(1, w - 1) * (len(stops) - 1)
            i = min(int(t), len(stops) - 2)
            f = t - i
            c = tuple(int(stops[i][k] + (stops[i + 1][k] - stops[i][k]) * f) for k in range(3))
            R(d, x, 0, x + 1, h, c)
    return paint


# ---------------------------------------------------------------- atlas regions (called by the model builders)
def reg_bracket():
    def paint(im, d):
        R(d, 0, 0, 41, 19, (206, 210, 220))
        R(d, 0, 0, 41, 1, (244, 246, 250))
        R(d, 0, 18, 41, 19, (150, 156, 170))
        # HDMI
        R(d, 2, 3, 12, 8, (26, 26, 32)); R(d, 3, 8, 11, 9, (26, 26, 32)); R(d, 3, 4, 11, 6, (70, 74, 88))
        # 3 x DP
        for x in (15, 25, 35):
            R(d, x, 3, x + 8, 8, (26, 26, 32)); R(d, x + 1, 8, x + 8, 9, (26, 26, 32)); R(d, x + 1, 4, x + 7, 6, (70, 74, 88))
        # vent dots
        for y in (12, 15):
            for x in range(3, 39, 3):
                R(d, x, y, x + 2, y + 2, (74, 78, 92))
    return ATLAS.reg("bracket", 41, 19, paint)


def reg_gpu_misc():
    ATLAS.reg("fing_top", 39, 4, fingers(39, 4, notch=(18, 22)))
    ATLAS.reg("fing_front", 39, 2, fingers(39, 2, notch=(18, 22)))
    ATLAS.reg("rgb", 53, 3, rainbow(53, 3, [(90, 170, 255), (190, 120, 255), (255, 120, 200), (255, 190, 100), (255, 120, 200), (120, 200, 255)]))

    def pins(im, d):
        R(d, 0, 0, 11, 6, (26, 26, 32))
        for i in range(4):
            R(d, 1 + i * 2 + (1 if i > 1 else 0), 1, 2 + i * 2 + (1 if i > 1 else 0), 3, (255, 214, 90))
            R(d, 1 + i * 2 + (1 if i > 1 else 0), 4, 2 + i * 2 + (1 if i > 1 else 0), 5, (255, 154, 31))
    ATLAS.reg("pins", 11, 6, pins)
    ATLAS.reg("fan_w1", 14, 14, lambda im, d: im.paste(fan_tex(14, 9, (255, 255, 255), (214, 220, 232), (255, 154, 31)), (0, 0)))
    ATLAS.reg("fan_o", 14, 14, lambda im, d: im.paste(fan_tex(14, 9, (255, 150, 70), (255, 206, 150), (255, 255, 255)), (0, 0)))
    reg_bracket()


def reg_misc():
    # chipset/heatsink fins (horizontal slats)
    def fins(im, d):
        for y in range(8):
            R(d, 0, y, 18, y + 1, (250, 247, 240) if y % 3 != 2 else (170, 164, 150))
    ATLAS.reg("fins", 18, 8, fins)
    # motherboard I/O
    def usb(col):
        def paint(im, d):
            R(d, 0, 0, 5, 6, (26, 26, 32))
            R(d, 1, 1, 4, 5, col)
            R(d, 1, 2, 4, 3, (26, 26, 32))
        return paint
    ATLAS.reg("port_usb", 5, 6, usb((70, 74, 88)))
    ATLAS.reg("port_blue", 5, 6, usb((60, 120, 230)))
    def rj(im, d):
        R(d, 0, 0, 5, 6, (150, 156, 170)); R(d, 1, 1, 4, 5, (26, 26, 32)); R(d, 1, 4, 4, 5, (255, 206, 90))
    ATLAS.reg("port_rj", 5, 6, rj)
    # SATA connectors (gold pins on black)
    ATLAS.reg("sata_data", 18, 6, fingers(18, 6, notch=(8, 10), pitch=2, bar=1))
    ATLAS.reg("sata_pow", 11, 6, fingers(11, 6, pitch=2, bar=1))
    ATLAS.reg("ram_fing_front", 58, 2, fingers(58, 2, notch=(28, 31), pitch=2, bar=1))
    ATLAS.reg("rgb_bar", 56, 4, rainbow(56, 4, [(110, 190, 255), (255, 140, 210), (255, 250, 245), (255, 214, 160), (255, 150, 60)]))
    # PSU panels
    def psu_ports(im, d):
        R(d, 0, 0, 48, 22, (244, 239, 229))
        R(d, 1, 1, 47, 21, (36, 36, 44))
        for x0 in (3, 14, 25, 36):  # sockets
            R(d, x0, 3, x0 + 9, 10, (18, 18, 24)); R(d, x0, 12, x0 + 9, 19, (18, 18, 24))
            for k in range(3):
                R(d, x0 + 1 + k * 3, 5, x0 + 2 + k * 3, 8, (255, 206, 90)); R(d, x0 + 1 + k * 3, 14, x0 + 2 + k * 3, 17, (255, 206, 90))
        R(d, 0, 20, 48, 22, (255, 154, 31))
    ATLAS.reg("psu_ports", 48, 22, psu_ports)
    def psu_rear(im, d):
        R(d, 0, 0, 41, 22, (244, 239, 229))
        R(d, 0, 0, 41, 1, (255, 255, 255)); R(d, 0, 21, 41, 22, (196, 187, 170))
        for y in range(3, 19, 3):
            for x in range(2, 14, 3):
                R(d, x + (1 if (y // 3) % 2 else 0), y, x + 2 + (1 if (y // 3) % 2 else 0), y + 2, (60, 60, 72))
        R(d, 0, 0, 41, 1, (255, 255, 255))
    ATLAS.reg("psu_rear", 41, 22, psu_rear)
    def ac(im, d):
        R(d, 0, 0, 12, 7, (26, 26, 32)); R(d, 1, 1, 11, 6, (44, 46, 56))
        for x in (3, 5, 8):
            R(d, x, 2, x + 1, 5, (190, 194, 204))
    ATLAS.reg("ac_inlet", 12, 7, ac)
    ATLAS.reg("grille", 31, 31, lambda im, d: im.paste(grille_tex(31), (0, 0)))
    ATLAS.reg("fan_aio", 20, 20, lambda im, d: im.paste(fan_tex(20, 9, (255, 150, 70), (255, 214, 160), (255, 255, 255)), (0, 0)))


# ---------------------------------------------------------------- top art
def gpu_top():
    cv = new_canvas()
    body = (6.8, 10.4, 63.2, 45.6)
    rr(cv, body, 0, lin_grad(gen_items2.WH0, gen_items2.WH1, (7, 10), (7, 46)))
    rr(cv, (6.8, 10.4, 63.2, 13.6), 0, lin_grad(gen_items2.ORG0, gen_items2.ORG1, (7, 10), (7, 14)))
    poly(cv, [(63.2, 33.5), (63.2, 45.6), (45.5, 45.6)], lin_grad(gen_items2.ORG0, gen_items2.ORG1, (45, 34), (63, 46)))
    gen_items.paw(cv, 59.2, 24, 0.55, gen_items2.ORG1)
    img = finish(cv)
    put_text(img, 14, 38, "MEOW", (176, 182, 198))
    speckle(img, 1, 32)
    return img


def cooler_top():
    cv = new_canvas()
    W0, W1 = gen_items2.WH0, gen_items2.WH1
    # radiator
    rr(cv, (36, 19.2, 61.6, 54.4), 1.2, lin_grad(W0, W1, (36, 19), (61, 54)))
    rr(cv, (36, 19.2, 61.6, 22.4), 0.8, lin_grad(gen_items2.ORG0, gen_items2.ORG1, (36, 19), (36, 23)))
    # pump head with logo ring
    rr(cv, (3, 16.4, 26, 39.4), 1.2, lin_grad(W0, W1, (3, 16), (26, 39)))
    ell(cv, 14.5, 28, 7.6, 7.6, C(200, 206, 218))
    ell(cv, 14.5, 28, 6.8, 6.8, lin_grad(C(40, 42, 52), C(20, 20, 26), (8, 20), (22, 36)))
    ring(cv, lambda d, i: d.ellipse([(14.5 - 5.8 + i) * S, (28 - 5.8 + i) * S, (14.5 + 5.8 - i) * S, (28 + 5.8 - i) * S], fill=255), 1.1,
         lin_grad(gen_items2.YEL0, gen_items2.YEL1, (8, 22), (21, 34)))
    rr(cv, (3, 16.4, 26, 19.6), 0.8, lin_grad(gen_items2.ORG0, gen_items2.ORG1, (3, 16), (3, 20)))
    img = finish(cv)
    speckle(img, 1, 34)
    return img


def hdd_top():
    cv = new_canvas()
    B = (6, 5, 58, 59)
    rr(cv, B, 1.2, lin_grad(C(250, 251, 254), C(150, 156, 170), (6, 5), (58, 59)))
    ell(cv, 32, 43, 13.6, 13.6, C(90, 94, 106))
    ell(cv, 32, 43, 12.6, 12.6, rad_grad(C(236, 238, 244), C(120, 126, 140), (28, 38), 16))
    ell(cv, 32, 43, 4.6, 4.6, C(190, 194, 204))
    poly(cv, [(20, 35), (38, 33), (30, 43)], C(255, 255, 255), 0.18)
    rr(cv, (11, 9, 53, 27), 1.0, lin_grad(C(255, 255, 255), C(212, 216, 226), (11, 9), (11, 27)))
    rr(cv, (11, 9, 53, 12), 0.6, lin_grad(C(255, 190, 84), C(240, 128, 8), (11, 9), (11, 12)))
    img = finish(cv)
    put_text(img, 14, 15, "HDD", C(60, 50, 40))
    put_text(img, 33, 15, "2TB", C(255, 130, 10))
    put_text(img, 14, 21, "MEOW", C(150, 140, 125))
    speckle(img, 2, 27)
    return img


def psu_top():
    cv = new_canvas()
    B = (4, 11, 52, 53)
    rr(cv, B, 0.8, lin_grad(C(255, 255, 255), C(210, 214, 224), (4, 11), (50, 53)))
    rr(cv, (4, 48.4, 52, 53), 0.6, lin_grad(C(255, 190, 80), C(240, 128, 8), (4, 48), (4, 53)))
    cx, cy = 22, 33
    ell(cv, cx, cy, 15.8, 15.8, C(180, 170, 152))
    ell(cv, cx, cy, 14.8, 14.8, C(26, 26, 34))
    gen_items.fan(cv, cx, cy, 13.6, 7, C(70, 74, 90), C(255, 154, 31), None, 0.9)
    rr(cv, (39, 16, 51, 45), 1.0, C(40, 40, 50))
    rr(cv, (41, 36, 49, 43.4), 0.8, C(255, 154, 31))
    rr(cv, (43.2, 37.4, 46.8, 42), 0.5, C(255, 232, 180))
    img = finish(cv)
    put_text(img, 40, 19, "750", C(255, 255, 255))
    put_text(img, 44, 25, "W", C(255, 154, 31))
    speckle(img, 2, 28)
    return img


def make_tops():
    """returns {name: Image}"""
    return {
        "mb_top": gen_items2.motherboard(),
        "cpu_top": gen_items.cpu(),
        "gpu_top": gpu_top(),
        "cooler_top": cooler_top(),
        "ram_top": gen_items3.ram(),
        "m2_top": gen_items3.ssd_m2(),
        "sata_top": gen_items2.ssd_sata(),
        "hdd_top": hdd_top(),
        "psu_top": psu_top(),
    }
