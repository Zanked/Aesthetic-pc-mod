import os, sys, math
from lib import *

OUT = sys.argv[1] if len(sys.argv) > 1 else "items_out"
os.makedirs(OUT, exist_ok=True)

SILVER0, SILVER1 = C(248, 249, 252), C(160, 166, 178)
GOLD0, GOLD1 = C(255, 226, 120), C(210, 160, 50)


def big_text(img, x, y, s, color, k=2, shadow=None):
    px = img.load()
    cx = x
    for ch in s:
        if ch == " ":
            cx += 3 * k
            continue
        g = FONT[ch]
        for r, row in enumerate(g):
            for c, v in enumerate(row):
                if v == "#":
                    for dy in range(k):
                        for dx in range(k):
                            xx, yy = cx + c * k + dx, y + r * k + dy
                            if shadow is not None and 0 <= xx + 1 < 64 and 0 <= yy + 1 < 64:
                                px[xx + 1, yy + 1] = shadow
                    
        for r, row in enumerate(g):
            for c, v in enumerate(row):
                if v == "#":
                    for dy in range(k):
                        for dx in range(k):
                            xx, yy = cx + c * k + dx, y + r * k + dy
                            if 0 <= xx < 64 and 0 <= yy < 64:
                                px[xx, yy] = color
        cx += (len(g[0]) + 1) * k


def shadowed(cv, strength=0.38):
    out = new_canvas()
    a = cv.getchannel("A")
    sh = ImageChops.offset(a, int(0.8 * S), int(1.4 * S)).filter(ImageFilter.GaussianBlur(1.0 * S))
    comp(out, sh, C(70, 44, 20), strength)
    out.alpha_composite(cv)
    return out


def metal(cv, box, r, c0=SILVER0, c1=SILVER1):
    x0, y0, x1, y1 = box
    rr(cv, box, r, lin_grad(c0, c1, (x0, y0), (x1, y1)))


def bevel(cv, box, r, hi=0.5, lo=0.3):
    x0, y0, x1, y1 = box
    ring(cv, lambda d, i: d.rounded_rectangle([(x0 + i) * S, (y0 + i) * S, (x1 - i) * S - 1, (y1 - i) * S - 1], max((r - i) * S, 1), fill=255),
         0.5, C(255, 255, 255), hi)
    rr(cv, (x0 + r * 0.6, y1 - 0.9, x1 - r * 0.6, y1 - 0.2), 0.3, C(60, 40, 20), lo)


def paw(cv, cx, cy, s, col, alpha=1.0):
    ell(cv, cx, cy + 0.9 * s, 2.2 * s, 1.7 * s, col, alpha)
    for (dx, dy) in ((-2.7, -1.3), (-0.9, -2.7), (0.9, -2.7), (2.7, -1.3)):
        ell(cv, cx + dx * s, cy + dy * s, 0.8 * s, 1.0 * s, col, alpha)


def fan(cv, cx, cy, R, n, blade, hub, ring_col=None, twist=0.9):
    if ring_col:
        ell(cv, cx, cy, R, R, ring_col)
        ell(cv, cx, cy, R * 0.9, R * 0.9, C(34, 34, 42))
    else:
        ell(cv, cx, cy, R, R, C(34, 34, 42))
    r0 = R * 0.24
    wd = 2 * math.pi / n * 0.62
    for i in range(n):
        a = 2 * math.pi * i / n
        pts = []
        for (rad, da) in ((r0, -wd * 0.25), (R * 0.86, twist - wd * 0.5), (R * 0.86, twist + wd * 0.5), (r0, wd * 0.6)):
            pts.append((cx + rad * math.cos(a + da), cy + rad * math.sin(a + da)))
        poly(cv, pts, blade)
        poly(cv, pts[:2] + [((pts[1][0] + pts[2][0]) / 2, (pts[1][1] + pts[2][1]) / 2)], C(255, 255, 255), 0.22)
    ell(cv, cx, cy, R * 0.26, R * 0.26, hub)
    ell(cv, cx - R * 0.07, cy - R * 0.08, R * 0.12, R * 0.09, C(255, 255, 255), 0.55)


def save(img, name):
    img.save(os.path.join(OUT, name + ".png"))
    print("saved", name)


# ================================================================ MOTHERBOARD
def motherboard():
    cv = new_canvas()
    B = (4, 4, 60, 60)
    rr(cv, B, 2.6, lin_grad(C(255, 255, 255), C(224, 215, 199), (4, 4), (60, 60)))
    # traces
    for (a, b) in (((18, 38), (18, 58)), ((20, 14), (20, 38)), ((46, 38), (46, 58)), ((12, 33), (46, 33)), ((8, 57), (58, 57))):
        line(cv, [a, b], 0.35, C(255, 154, 31), 0.25, False)
    # I/O shield
    metal(cv, (5, 8, 16, 30), 1.0)
    for i, y in enumerate((10, 14, 18, 22, 26)):
        rr(cv, (6.2, y, 14.8, y + 2.6), 0.4, C(40, 42, 52))
        rr(cv, (6.8, y + 0.7, 11.5, y + 1.7), 0.2, C(80, 140, 255) if i in (1, 2) else C(150, 152, 165))
    # VRM heatsinks (orange with fins)
    og = lin_grad(C(255, 196, 96), C(236, 120, 10), (17, 6), (17, 15))
    rr(cv, (17, 6, 45, 14), 1.2, og)
    for x in range(19, 44, 2):
        rr(cv, (x, 7, x + 0.7, 13), 0.2, C(190, 90, 0), 0.5)
    og2 = lin_grad(C(255, 196, 96), C(236, 120, 10), (17, 0), (23, 0))
    rr(cv, (17, 15, 23, 38), 1.2, og2)
    for y in range(17, 37, 2):
        rr(cv, (18, y, 22, y + 0.7), 0.2, C(190, 90, 0), 0.5)
    # CPU socket
    rr(cv, (24, 15, 46, 38), 1.0, lin_grad(C(236, 238, 244), C(150, 156, 170), (24, 15), (46, 38)))
    rr(cv, (25.4, 16.4, 44.6, 36.6), 0.6, C(38, 38, 46))
    for yy in range(18, 36, 2):
        for xx in range(27, 44, 2):
            ell(cv, xx, yy, 0.42, 0.42, C(255, 206, 90))
    rr(cv, (46, 17, 47.4, 36), 0.5, C(180, 186, 198))
    # RAM slots with latches
    for i in range(4):
        x = 48.5 + i * 2.7
        rr(cv, (x, 6, x + 2.0, 37), 0.5, C(30, 30, 38))
        rr(cv, (x + 0.3, 6.4, x + 1.7, 8.2), 0.4, C(255, 154, 31))
        rr(cv, (x + 0.3, 34.8, x + 1.7, 36.6), 0.4, C(255, 154, 31))
        rr(cv, (x + 0.7, 9, x + 1.3, 34), 0.2, C(90, 90, 104), 0.7)
    # PCIe x16
    rr(cv, (8, 40, 41, 44), 0.8, C(30, 30, 38))
    rr(cv, (8.6, 40.6, 40.4, 41.6), 0.3, C(90, 90, 104), 0.8)
    rr(cv, (8, 40, 10.2, 44), 0.5, C(255, 154, 31))
    # PCIe x1
    rr(cv, (8, 47, 26, 50.4), 0.8, C(30, 30, 38))
    rr(cv, (8, 47, 10.2, 50.4), 0.5, C(255, 154, 31))
    # M.2 slot + screw
    rr(cv, (8, 53, 30, 56.4), 0.8, C(54, 54, 62))
    rr(cv, (8.6, 53.6, 13, 55.8), 0.3, C(255, 206, 90))
    ell(cv, 33.5, 54.7, 1.5, 1.5, C(190, 180, 162))
    # chipset heatsink
    rr(cv, (41, 46, 56, 58), 1.2, lin_grad(C(255, 196, 96), C(236, 120, 10), (41, 46), (56, 58)))
    paw(cv, 48.5, 52, 0.95, C(255, 236, 190), 0.9)
    # sata ports
    for x in (36, 40, 44):
        rr(cv, (x, 53, x + 3, 56.4), 0.5, C(30, 30, 38))
        rr(cv, (x + 0.5, 53.5, x + 2.5, 54.4), 0.2, C(120, 120, 136), 0.8)
    # 24-pin power
    rr(cv, (57, 40, 59.6, 52), 0.5, C(244, 240, 232))
    for y in range(41, 51, 2):
        rr(cv, (57.6, y, 59, y + 1), 0.2, C(40, 40, 50))
    # screws
    for (sx, sy) in ((7.4, 6.4), (57, 6.4), (7.4, 57.4), (57.4, 57.4), (22, 55)):
        ell(cv, sx, sy, 1.1, 1.1, C(176, 168, 150))
        ell(cv, sx, sy, 0.55, 0.55, C(110, 100, 84))
    bevel(cv, B, 2.6)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 35, 56, "MEOW", C(176, 166, 148)) if False else None
    speckle(img, 2, 21)
    return img


# ================================================================ CPU
def cpu():
    cv = new_canvas()
    B = (7, 7, 57, 57)
    rr(cv, B, 3.4, lin_grad(C(250, 250, 253), C(204, 208, 220), (7, 7), (57, 57)))
    # contact pads / smd caps around the heat spreader
    for i in range(9):
        t = 11 + i * 5.2
        for (x, y, w, h) in ((t - 1, 8.8, 2, 1.4), (t - 1, 53.8, 2, 1.4), (8.8, t - 1, 1.4, 2), (53.8, t - 1, 1.4, 2)):
            rr(cv, (x, y, x + w, y + h), 0.3, lin_grad(GOLD0, GOLD1, (x, y), (x + w, y + h)))
    # gold triangle marker
    poly(cv, [(9, 9), (15, 9), (9, 15)], lin_grad(GOLD0, GOLD1, (9, 9), (15, 15)))
    # IHS
    ih = (14, 14, 50, 50)
    blur_shadow(cv, mask_from(lambda d: d.rounded_rectangle([14 * S, 14 * S, 50 * S, 50 * S], 4 * S, fill=255)), 0.5, 0.9, 0.8,
                color=(70, 50, 30, 255), alpha=0.5)
    metal(cv, ih, 4.0, C(250, 251, 254), C(150, 156, 170))
    ring(cv, lambda d, i: d.rounded_rectangle([(14 + i) * S, (14 + i) * S, (50 - i) * S - 1, (50 - i) * S - 1], max((4.0 - i) * S, 1), fill=255),
         1.0, C(255, 255, 255), 0.45)
    rr(cv, (17.5, 17.5, 46.5, 46.5), 2.4, lin_grad(C(222, 226, 234), C(190, 196, 208), (17, 17), (46, 46)))
    ring(cv, lambda d, i: d.rounded_rectangle([(17.5 + i) * S, (17.5 + i) * S, (46.5 - i) * S - 1, (46.5 - i) * S - 1], max((2.4 - i) * S, 1), fill=255),
         0.4, C(120, 126, 140), 0.5)
    paw(cv, 32, 39.5, 1.15, C(255, 154, 31), 0.95)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 22, 21, "MEOW", C(84, 90, 104))
    put_text(img, 22, 27, "CORE", C(255, 140, 20)) if False else None
    speckle(img, 2, 22)
    return img


# ================================================================ GPU
def gpu():
    cv = new_canvas()
    # PCB behind (peeks under shroud)
    rr(cv, (8, 41, 58, 47), 0.8, C(150, 140, 120))
    # gold fingers
    for k in range(20):
        x = 12 + k * 1.3 + (3 if k > 10 else 0)
        rr(cv, (x, 45, x + 0.8, 50), 0.15, lin_grad(GOLD0, GOLD1, (x, 45), (x, 50)))
    # shroud
    body = (6, 13, 61, 44)
    rr(cv, body, 3.0, lin_grad(C(255, 255, 255), C(210, 214, 224), (6, 13), (6, 44)))
    rr(cv, (6, 13, 61, 17), 2.0, lin_grad(C(255, 190, 80), C(240, 128, 8), (6, 13), (6, 17)))   # orange top strip
    rr(cv, (6, 40.4, 61, 44), 2.0, lin_grad(C(255, 190, 80), C(240, 128, 8), (6, 40), (6, 44)))  # orange bottom strip
    # fans
    for cx in (22, 45):
        ell(cv, cx, 29, 11.4, 11.4, C(190, 180, 162))
        fan(cv, cx, 29, 10.4, 9, C(255, 170, 54), C(255, 244, 220), C(255, 154, 31))
        paw(cv, cx, 28.6, 0.52, C(190, 90, 0), 0.9)
    # backplate bracket (left) + ports
    metal(cv, (1.5, 11, 6, 47), 0.8)
    for y in (16, 24, 32):
        rr(cv, (2.3, y, 5.2, y + 5), 0.4, C(36, 38, 48))
    # power connector (top right)
    rr(cv, (47, 9.6, 58, 13.4), 0.6, C(40, 40, 48))
    for x in range(48, 57, 2):
        rr(cv, (x, 10.4, x + 1, 12.4), 0.2, C(255, 206, 90), 0.9)
    # glare
    poly(cv, [(8, 17), (30, 17), (20, 40), (8, 40)], C(255, 255, 255), 0.10)
    bevel(cv, body, 3.0, 0.5, 0.25)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 25, 49, "MEOW", C(255, 255, 255)) if False else None
    speckle(img, 2, 23)
    return img


# ================================================================ RAM
def ram():
    cv = new_canvas()
    # pcb + gold contacts
    rr(cv, (3, 38, 61, 46), 1.0, C(60, 56, 70))
    for k in range(28):
        x = 5 + k * 2.0 + (0.8 if k > 15 else 0)
        if 33.5 < x < 36:
            continue
        rr(cv, (x, 41, x + 1.2, 46), 0.2, lin_grad(GOLD0, GOLD1, (x, 41), (x, 46)))
    ell(cv, 35, 46, 1.2, 1.2, C(0, 0, 0), 0.0)
    # heatspreader
    hs = (3, 14, 61, 40)
    rr(cv, hs, 2.2, lin_grad(C(255, 190, 84), C(232, 112, 6), (3, 14), (3, 40)))
    # ridges
    for y in (18.4, 20.6, 22.8):
        rr(cv, (6, y, 58, y + 0.8), 0.3, C(190, 88, 0), 0.55)
        rr(cv, (6, y + 0.8, 58, y + 1.2), 0.2, C(255, 232, 170), 0.6)
    # label
    rr(cv, (9, 26, 55, 36), 1.4, lin_grad(C(255, 255, 255), C(230, 222, 206), (13, 26), (13, 36)))
    # light bar (rgb-ish)
    rr(cv, (6, 14.8, 58, 17), 0.9, lin_grad(C(255, 120, 170), C(255, 220, 90), (6, 0), (58, 0)))
    ell(cv, 32, 16, 28, 1.6, C(255, 255, 255), 0.25)
    poly(cv, [(5, 15), (22, 15), (14, 39), (5, 39)], C(255, 255, 255), 0.10)
    bevel(cv, hs, 2.2, 0.5, 0.3)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 13, 29, "16GB", C(60, 50, 40))
    paw_img = None
    put_text(img, 35, 29, "DDR5", C(255, 130, 10))
    speckle(img, 2, 24)
    return img


# ================================================================ SSD M.2
def ssd_m2():
    cv = new_canvas()
    rr(cv, (3, 22, 61, 42), 1.6, lin_grad(C(60, 64, 74), C(36, 38, 46), (3, 22), (3, 42)))
    # screw notch on the right
    ell(cv, 61.5, 32, 2.6, 2.6, C(0, 0, 0, 0))
    # gold contacts left with key notch
    for k in range(9):
        y = 23.4 + k * 2.0
        rr(cv, (3.4, y, 7.6, y + 1.2), 0.2, lin_grad(GOLD0, GOLD1, (3, y), (8, y)))
    # chips
    for (x0, x1) in ((11, 24), (26.5, 39)):
        rr(cv, (x0, 25.5, x1, 38.5), 0.9, lin_grad(C(34, 34, 40), C(18, 18, 22), (x0, 25), (x1, 38)))
        rr(cv, (x0 + 0.5, 26, x1 - 0.5, 27), 0.3, C(255, 255, 255), 0.12)
    # label
    rr(cv, (42, 25, 58, 39), 1.2, lin_grad(C(255, 190, 84), C(236, 120, 10), (42, 25), (58, 39)))
    paw(cv, 50, 33, 1.5, C(255, 244, 220), 0.9)
    # holes cut for contacts key + screw
    cv_a = cv.getchannel("A")
    hole = mask_from(lambda d: d.ellipse([58.8 * S, 29.4 * S, 64.2 * S, 34.6 * S], fill=255))
    cv.putalpha(ImageChops.subtract(cv_a, hole))
    bevel(cv, (3, 22, 61, 42), 1.6, 0.3, 0.2)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 12, 29, "M.2", C(255, 154, 31)) if False else None
    speckle(img, 2, 25)
    return img


# ================================================================ SSD SATA
def ssd_sata():
    cv = new_canvas()
    B = (8, 7, 56, 53)
    rr(cv, B, 3.4, lin_grad(C(88, 92, 104), C(40, 42, 50), (8, 7), (56, 53)))
    # orange diagonal band
    band = mask_from(lambda d: d.polygon([(8 * S, 30 * S), (8 * S, 20 * S), (56 * S, 44 * S), (56 * S, 54 * S)], fill=255))
    bm = mask_from(lambda d: d.rounded_rectangle([8 * S, 7 * S, 56 * S, 53 * S], 3.4 * S, fill=255))
    comp(cv, ImageChops.multiply(band, bm), lin_grad(C(255, 190, 84), C(236, 120, 10), (8, 20), (8, 54)))
    # label
    rr(cv, (14, 12, 50, 30), 2.0, lin_grad(C(255, 255, 255), C(212, 216, 226), (14, 12), (14, 30)))
    # screws
    for (sx, sy) in ((11.6, 10.6), (52.4, 10.6), (11.6, 49.4), (52.4, 49.4)):
        ell(cv, sx, sy, 1.2, 1.2, C(190, 190, 200))
        line(cv, [(sx - 0.7, sy - 0.7), (sx + 0.7, sy + 0.7)], 0.35, C(90, 90, 100))
    # SATA connector (bottom)
    rr(cv, (22, 53, 52, 60), 1.0, C(28, 28, 34))
    rr(cv, (24, 55, 38, 58.4), 0.3, C(255, 206, 90), 0.0)
    for x in range(24, 38, 2):
        rr(cv, (x, 55, x + 1.1, 59), 0.2, lin_grad(GOLD0, GOLD1, (x, 55), (x, 59)))
    for x in range(42, 51, 2):
        rr(cv, (x, 55, x + 1.1, 59), 0.2, lin_grad(GOLD0, GOLD1, (x, 55), (x, 59)))
    bevel(cv, B, 3.4, 0.35, 0.25)
    cv = shadowed(cv)
    img = finish(cv)
    big_text(img, 20, 16, "SSD", C(60, 50, 40), 2)
    paw_dummy = None
    speckle(img, 2, 26)
    return img


# ================================================================ HDD
def hdd():
    cv = new_canvas()
    B = (6, 5, 58, 59)
    rr(cv, B, 3.4, lin_grad(C(250, 251, 254), C(150, 156, 170), (6, 5), (58, 59)))
    # platter window
    ell(cv, 32, 43, 13.6, 13.6, C(90, 94, 106))
    ell(cv, 32, 43, 12.6, 12.6, rad_grad(C(236, 238, 244), C(120, 126, 140), (28, 38), 16))
    ell(cv, 32, 43, 4.6, 4.6, C(190, 194, 204))
    ell(cv, 32, 43, 2.2, 2.2, C(90, 94, 106))
    poly(cv, [(32, 43), (48, 33), (51, 36)], C(60, 60, 70))
    poly(cv, [(20, 35), (38, 33), (30, 43)], C(255, 255, 255), 0.18)
    # label
    rr(cv, (11, 9, 53, 27), 2.0, lin_grad(C(255, 255, 255), C(212, 216, 226), (11, 9), (11, 27)))
    rr(cv, (11, 9, 53, 12), 1.5, lin_grad(C(255, 190, 84), C(240, 128, 8), (11, 9), (11, 12)))
    for (sx, sy) in ((9.4, 8), (54.6, 8), (9.4, 56), (54.6, 56)):
        ell(cv, sx, sy, 1.2, 1.2, C(120, 124, 138))
    bevel(cv, B, 3.4, 0.5, 0.25)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 14, 15, "HDD", C(60, 50, 40))
    put_text(img, 33, 15, "2TB", C(255, 130, 10))
    put_text(img, 14, 21, "MEOW", C(150, 140, 125))
    speckle(img, 2, 27)
    return img


# ================================================================ PSU
def psu():
    cv = new_canvas()
    B = (4, 11, 52, 53)
    rr(cv, B, 3.0, lin_grad(C(255, 255, 255), C(210, 214, 224), (4, 11), (50, 53)))
    # orange side rail
    rr(cv, (4, 11, 52, 15.4), 2.4, lin_grad(C(255, 190, 80), C(240, 128, 8), (4, 11), (4, 16)))
    # fan grille
    cx, cy = 22, 33
    ell(cv, cx, cy, 15.6, 15.6, C(180, 170, 152))
    ell(cv, cx, cy, 14.6, 14.6, lin_grad(C(26, 26, 34), C(60, 60, 72), (8, 18), (36, 48)))
    for rad in (12.2, 9.0, 5.8):
        ring(cv, lambda d, i, rad=rad: d.ellipse([(cx - rad + i) * S, (cy - rad + i) * S, (cx + rad - i) * S, (cy + rad - i) * S], fill=255),
             0.55, C(170, 172, 190), 0.9)
    for a in range(0, 180, 30):
        t = math.radians(a)
        line(cv, [(cx - 14 * math.cos(t), cy - 14 * math.sin(t)), (cx + 14 * math.cos(t), cy + 14 * math.sin(t))], 0.5, C(170, 172, 190), 0.8, False)
    ell(cv, cx, cy, 2.6, 2.6, C(255, 154, 31))
    paw(cv, cx, cy, 0.4, C(255, 236, 190), 0.9)
    # label
    rr(cv, (39, 18, 51, 49), 1.0, C(40, 40, 50))
    # switch
    rr(cv, (41, 40, 49, 47.4), 0.8, C(255, 154, 31))
    rr(cv, (43.2, 41.4, 46.8, 46), 0.5, C(255, 232, 180))
    # cables exiting right
    cols = [C(255, 154, 31), C(40, 40, 50), C(255, 214, 90), C(40, 40, 50), C(255, 154, 31)]
    for i, c in enumerate(cols):
        y = 22 + i * 5.4
        line(cv, [(52, y), (56, y + (i - 2) * 0.8), (61, y + (i - 2) * 2.4)], 2.0, c)
        line(cv, [(52, y - 0.5), (58, y - 0.3 + (i - 2) * 0.8)], 0.5, C(255, 255, 255), 0.35, False)
    bevel(cv, B, 3.0, 0.5, 0.25)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 40, 21, "750", C(255, 255, 255))
    put_text(img, 44, 27, "W", C(255, 154, 31))
    speckle(img, 2, 28)
    return img


# ================================================================ CPU COOLER
def cooler():
    cv = new_canvas()
    B = (5, 5, 59, 59)
    rr(cv, B, 4.0, lin_grad(C(255, 255, 255), C(210, 214, 224), (5, 5), (59, 59)))
    # heatpipe hints at left/right
    for y in (16, 24, 32, 40, 48):
        rr(cv, (5, y, 8, y + 3), 0.8, lin_grad(C(255, 232, 170), C(220, 150, 40), (5, y), (8, y + 3)))
        rr(cv, (56, y, 59, y + 3), 0.8, lin_grad(C(255, 232, 170), C(220, 150, 40), (56, y), (59, y + 3)))
    # frame inner ring
    ell(cv, 32, 32, 25, 25, C(170, 176, 190))
    ell(cv, 32, 32, 24, 24, C(255, 160, 40))
    fan(cv, 32, 32, 22.6, 9, C(255, 244, 224), C(255, 170, 54), C(36, 36, 44), 1.0)
    paw(cv, 32, 31.6, 1.2, C(190, 90, 0), 0.95)
    # corner screws
    for (sx, sy) in ((9, 9), (55, 9), (9, 55), (55, 55)):
        ell(cv, sx, sy, 1.5, 1.5, C(176, 168, 150))
        ell(cv, sx, sy, 0.7, 0.7, C(110, 100, 84))
    bevel(cv, B, 4.0, 0.5, 0.25)
    cv = shadowed(cv)
    img = finish(cv)
    speckle(img, 2, 29)
    return img


if __name__ == "__main__":
    save(motherboard(), "motherboard")
    save(cpu(), "cpu")
    save(gpu(), "gpu")
    save(ram(), "ram")
    save(ssd_m2(), "ssd_m2")
    save(ssd_sata(), "ssd_sata")
    save(hdd(), "hdd")
    save(psu(), "psu")
    save(cooler(), "cpu_cooler")
