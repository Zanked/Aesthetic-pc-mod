import json, math, sys, os
import numpy as np
from PIL import Image

MOD = "pcbuildsim"
EPS = 1e-6

TEXKEYS = {
    "front": "pc_case_front", "glass": "pc_case_glass", "west": "pc_case_west", "back": "pc_case_back",
    "tray": "pc_case_tray", "side": "pc_case_side", "top": "pc_case_top", "misc": "pc_case_misc",
}

DIRS = ["north", "south", "east", "west", "up", "down"]
AXIS = {"north": (2, -1), "south": (2, 1), "east": (0, 1), "west": (0, -1), "up": (1, 1), "down": (1, -1)}


class Box:
    def __init__(self, name, a, b, faces):
        self.name, self.a, self.b, self.faces = name, a, b, faces


def X(v):  # viewer coordinate -> model x
    return 16 - v


boxes = []


def add(name, a, b, **faces):
    boxes.append(Box(name, a, b, faces))


P_CREAM, P_CREAM_D, P_OR, P_OR_D = ("patch", 0, 0), ("patch", 1, 0), ("patch", 2, 0), ("patch", 3, 0)
P_BLACK, P_FLOOR, P_BRASS, P_OR_HI = ("patch", 0, 1), ("patch", 1, 1), ("patch", 2, 1), ("patch", 3, 1)
P_RUBBER, P_INNER = ("patch", 0, 2), ("patch", 1, 2)

# ---- shell: everything flush, square corners (x 2.5..13.5, y 1..16, z 1..15) ----
# The white front slab (vents + screen face) is Z_SLAB deep; the glass side starts right behind it.
# Reference photo: the slab is only ~10% of the side depth, so keep it thin (was 3.0).
ZS = 2.0
add("front", (2.5, 1, 0.5), (13.5, 16, ZS), north=("pos", "front"), south=P_INNER, west=P_CREAM, east=("pos", "side"),
    up=P_CREAM, down=P_CREAM_D)
add("back", (2.5, 1, 14), (13.5, 16, 15), south=("pos", "back"), north=P_INNER, west=("pos", "west"),
    up=("pos", "top"), down=P_CREAM_D)
add("top", (2.5, 15, 3), (13.5, 16, 14), up=("pos", "top"), down=P_INNER, west=("pos", "west"))
add("bottom", (2.5, 1, 3), (13.5, 1.5, 14), up=P_FLOOR, down=P_CREAM_D, west=("pos", "west"))
add("wall", (2.5, 1.5, 3), (3.5, 15, 14), west=("pos", "west"), east=("pos", "tray"))
# fillers between the thin slab and the old z=3 seam (textures of top/west are drawn for z >= 3)
add("top_f", (2.5, 15, ZS), (13.5, 16, 3), up=("pos", "top"), down=P_INNER, west=P_CREAM)
add("bottom_f", (2.5, 1, ZS), (13.5, 1.5, 3), up=P_FLOOR, down=P_CREAM_D, west=P_CREAM)
add("wall_f", (2.5, 1.5, ZS), (3.5, 15, 3), west=P_CREAM, east=("pos", "tray"))

# ---- feet ----
for i, (fx, fz) in enumerate(((5, 3), (10.5, 3), (5, 11), (10.5, 11))):
    add(f"foot_{i}", (fx, 0, fz), (fx + 2, 1, fz + 2), north=P_CREAM, south=P_CREAM, east=P_CREAM_D, west=P_CREAM_D, down=P_CREAM_D)

# ---- glass side (east) ----
add("glass", (13, 1, ZS), (13.5, 16, 15), east=("pos", "glass"))

# ---- standoffs on the tray ----
STANDOFFS = [(5, 5), (5, 9), (5, 13), (8, 5), (8, 13), (11, 5), (11, 9), (11, 13)]
for i, (z, y) in enumerate(STANDOFFS):
    add(f"standoff_{i}", (3.5, y - 0.25, z - 0.25), (4.0, y + 0.25, z + 0.25), east=P_BRASS, north=P_BRASS, south=P_BRASS, up=P_BRASS, down=P_BRASS)

# ---- front-panel parts, placed in TEXTURE PIXELS (see layout.py) so art and geometry always line up ----
import layout as L


def pbox(name, px0, row0, px1, row1, za, zb, **faces):
    """box from texture-pixel rect (px0,row0)-(px1,row1) on the front face, between z=za and z=zb"""
    add(name, (X(px1 / 4), 16 - row1 / 4, za), (X(px0 / 4), 16 - row0 / 4, zb), **faces)


SIDE = dict(up=P_OR_D, down=P_OR_D, east=P_OR_D, west=P_OR_D)
bx0, by0, bx1, by1 = L.BEZEL
sx0, sy0, sx1, sy1 = L.SCREEN
FR = ("pos", "front")
pbox("bz_top", bx0, by0, bx1, sy0, 0.0, 0.5, north=FR, **SIDE)
pbox("bz_bot", bx0, sy1, bx1, by1, 0.0, 0.5, north=FR, **SIDE)
pbox("bz_l", bx0, sy0, sx0, sy1, 0.0, 0.5, north=FR, **SIDE)
pbox("bz_r", sx1, sy0, bx1, sy1, 0.0, 0.5, north=FR, **SIDE)
pbox("screen", sx0, sy0, sx1, sy1, 0.3, 0.5, north=("pos", "front", "emissive"), **SIDE)

# d-pad: two arms, art (shading, dimple) comes from the front texture
BTN_FACES = dict(north=FR, up=P_OR, down=P_OR_D, east=P_OR_D, west=P_OR_D)
pbox("dpad_v", *L.DPAD_V, 0.0, 0.5, **BTN_FACES)
pbox("dpad_h", L.DPAD_H[0], L.DPAD_H[1], L.DPAD_V[0], L.DPAD_H[3], 0.05, 0.5, **BTN_FACES)
pbox("dpad_h2", L.DPAD_V[2], L.DPAD_H[1], L.DPAD_H[2], L.DPAD_H[3], 0.05, 0.5, **BTN_FACES)

# round A/B buttons: pixel-exact octagon built from horizontal runs (merged vertically)
for tag, (cx0, cy0) in (("a", L.BTN_A), ("b", L.BTN_B)):
    runs = []
    for j, row in enumerate(L.BTN_MASK):
        i0 = row.find("#")
        i1 = row.rfind("#") + 1
        if runs and runs[-1][0] == i0 and runs[-1][1] == i1 and runs[-1][3] == j:
            runs[-1][3] = j + 1
        else:
            runs.append([i0, i1, j, j + 1])
    for k, (i0, i1, j0, j1) in enumerate(runs):
        pbox(f"btn_{tag}{k}", cx0 + i0, cy0 + j0, cx0 + i1, cy0 + j1, 0.05, 0.5, **BTN_FACES)


# =============================== face handling ===============================
def covered(box, d):
    """True if face `d` of `box` is fully covered by a neighbouring box touching it"""
    ax, sg = AXIS[d]
    p = box.b[ax] if sg > 0 else box.a[ax]
    o1, o2 = [i for i in range(3) if i != ax]
    for other in boxes:
        if other is box:
            continue
        q = other.a[ax] if sg > 0 else other.b[ax]
        if abs(q - p) > EPS:
            continue
        if other.a[o1] <= box.a[o1] + EPS and other.b[o1] >= box.b[o1] - EPS and other.a[o2] <= box.a[o2] + EPS and other.b[o2] >= box.b[o2] - EPS:
            return True
    return False


def pos_uv(d, a, b):
    x1, y1, z1 = a
    x2, y2, z2 = b
    return {
        "north": [16 - x2, 16 - y2, 16 - x1, 16 - y1],
        "south": [x1, 16 - y2, x2, 16 - y1],
        "east": [16 - z2, 16 - y2, 16 - z1, 16 - y1],
        "west": [z1, 16 - y2, z2, 16 - y1],
        "up": [x1, z1, x2, z2],
        "down": [x1, 16 - z2, x2, 16 - z1],
    }[d]


def face_json(box, d, spec):
    if spec[0] == "pos":
        uv = pos_uv(d, box.a, box.b)
        f = {"uv": [round(v, 4) for v in uv], "texture": "#" + spec[1]}
        if len(spec) > 2 and spec[2] == "emissive":
            f["neoforge_data"] = {"block_light": 15, "sky_light": 15}
        return f
    if spec[0] == "patch":
        gx, gy = spec[1], spec[2]
        return {"uv": [4 * gx, 4 * gy, 4 * gx + 4, 4 * gy + 4], "texture": "#misc"}
    raise ValueError(spec)


# ---- proportions (reference: Segotep x Colorfire "Meow" case) ----
# The shell is designed in the original 16-unit space (UVs are derived from these design coordinates),
# then squeezed in width/height and stretched in depth, so the glass side becomes wider than tall.
SX = 0.90   # width  (around the block centre x = 8)
SY = 0.90   # height (from the floor)
Z_FRONT = 0.5   # everything in front of this (bezel, buttons) keeps its depth
Z_BACK_DESIGN, Z_BACK_NEW = 15.0, 16.0


K = 0.65    # overall size of the placed block (1.0 = fills the whole 16^3 block); scales about the block centre/floor


def tx(v):
    return round(8 + (v - 8) * SX * K, 4)


def ty(v):
    return round(v * SY * K, 4)


def tz(v):
    if v > Z_FRONT:
        v = Z_FRONT + (v - Z_FRONT) * (Z_BACK_NEW - Z_FRONT) / (Z_BACK_DESIGN - Z_FRONT)
    return round(8 + (v - 8) * K, 4)


def scaled(a, b=None):
    return [tx(a[0]), ty(a[1]), tz(a[2])]


def build_elements():
    els = []
    for bx in boxes:
        faces = {}
        for d, spec in bx.faces.items():
            if covered(bx, d):
                continue
            faces[d] = face_json(bx, d, spec)
        if not faces:
            continue
        el = {"name": bx.name, "from": scaled(bx.a), "to": scaled(bx.b), "faces": faces}
        if any("neoforge_data" in f for f in faces.values()):
            el["shade"] = False
        els.append(el)
    return els


def build_model():
    return {
        "parent": "minecraft:block/block",
        "ambientocclusion": False,
        "render_type": "minecraft:translucent",
        "textures": {**{k: f"{MOD}:block/{v}" for k, v in TEXKEYS.items()}, "particle": f"{MOD}:block/pc_case_west"},
        "elements": build_elements(),
    }


# =============================== preview renderer ===============================
SHADE = {"up": 1.0, "north": 0.85, "south": 0.85, "east": 0.65, "west": 0.65, "down": 0.5}


def rot_xy(p, rx, ry):
    x, y, z = p
    c, s = math.cos(math.radians(ry)), math.sin(math.radians(ry))
    x, z = x * c + z * s, -x * s + z * c
    c, s = math.cos(math.radians(rx)), math.sin(math.radians(rx))
    y, z = y * c - z * s, y * s + z * c
    return np.array([x, y, z])


def corners(d, a, b):
    """3D corners (top-left, top-right, bottom-left) as seen from outside, matching MC uv corner order"""
    x1, y1, z1 = a
    x2, y2, z2 = b
    if d == "north":
        return (x2, y2, z1), (x1, y2, z1), (x2, y1, z1)
    if d == "south":
        return (x1, y2, z2), (x2, y2, z2), (x1, y1, z2)
    if d == "east":
        return (x2, y2, z2), (x2, y2, z1), (x2, y1, z2)
    if d == "west":
        return (x1, y2, z1), (x1, y2, z2), (x1, y1, z1)
    if d == "up":
        return (x1, y2, z1), (x2, y2, z1), (x1, y2, z2)
    if d == "down":
        return (x1, y1, z2), (x2, y1, z2), (x1, y1, z1)


def render(model, texdir, rx, ry, out, size=520, scale=None, yrot=0):
    texs = {k: np.array(Image.open(os.path.join(texdir, v + ".png")).convert("RGBA")) for k, v in TEXKEYS.items()}
    scale = scale or size / 24.0
    img = np.zeros((size, size, 3), float)
    img[:] = np.array([200, 214, 224])
    zb = np.full((size, size), -1e9)
    items = []
    for el in model["elements"]:
        a, b = el["from"], el["to"]
        for d, f in el["faces"].items():
            c0, c1, c2 = corners(d, a, b)
            if yrot:
                pass
            P0, P1, P2 = [rot_xy(np.array(c) - 8, rx, ry) for c in (c0, c1, c2)]
            n = np.cross(P1 - P0, P2 - P0)
            # outward normal check: viewer looks from +z; face visible when normal z has right sign
            n = -n if False else n
            items.append((d, f, P0, P1, P2))
    # sort far -> near by centre depth
    items.sort(key=lambda it: it[2][2] + (it[3][2] - it[2][2] + it[4][2] - it[2][2]) / 2)
    for d, f, P0, P1, P2 in items:
        e1, e2 = P1 - P0, P2 - P0
        nrm = np.cross(e1, e2)
        # edges: e1 = along u (left->right), e2 = along v (top->bottom); cross points toward viewer if front-facing
        if nrm[2] >= -1e-9:
            continue
        tex = texs[f["texture"][1:]]
        u1, v1, u2, v2 = f["uv"]
        pts = [P0, P1, P2, P1 + e2]
        sx = [size / 2 + p[0] * scale for p in pts]
        sy = [size / 2 - p[1] * scale + 8 for p in pts]
        x0, x1 = int(max(0, min(sx) - 1)), int(min(size - 1, max(sx) + 1))
        y0, y1 = int(max(0, min(sy) - 1)), int(min(size - 1, max(sy) + 1))
        ys, xs = np.mgrid[y0:y1 + 1, x0:x1 + 1]
        # screen basis
        A = np.array([[e1[0] * scale, e2[0] * scale], [-e1[1] * scale, -e2[1] * scale]])
        if abs(np.linalg.det(A)) < 1e-9:
            continue
        Ainv = np.linalg.inv(A)
        px = xs + 0.5 - (size / 2 + P0[0] * scale)
        py = ys + 0.5 - (size / 2 - P0[1] * scale + 8)
        s = Ainv[0, 0] * px + Ainv[0, 1] * py
        t = Ainv[1, 0] * px + Ainv[1, 1] * py
        inside = (s >= 0) & (s < 1) & (t >= 0) & (t < 1)
        if not inside.any():
            continue
        u = (u1 + (u2 - u1) * s) * 4
        v = (v1 + (v2 - v1) * t) * 4
        ui = np.clip(np.floor(u).astype(int), 0, 63)
        vi = np.clip(np.floor(v).astype(int), 0, 63)
        col = tex[vi, ui].astype(float)
        alpha = col[..., 3] / 255.0
        z = P0[2] + e1[2] * s + e2[2] * t
        shade = SHADE[d] if "neoforge_data" not in f else 1.0
        m = inside & (z >= zb[y0:y1 + 1, x0:x1 + 1] - 1e-6) & (alpha > 0.02)
        rgb = col[..., :3] * shade
        cur = img[y0:y1 + 1, x0:x1 + 1]
        new = cur * (1 - alpha[..., None]) + rgb * alpha[..., None]
        cur[m] = new[m]
        zz = zb[y0:y1 + 1, x0:x1 + 1]
        wm = m & (alpha > 0.5)
        zz[wm] = z[wm]
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).save(out)


def split_models(model):
    """The shell must NOT live in the translucent layer (quads there are depth-sorted per face, so the inside of the
    case showed through the walls). Opaque shell -> cutout, glass sticker -> translucent; glued by a composite model."""
    common = {"ambientocclusion": False, "textures": model["textures"]}
    shell = {**common, "render_type": "minecraft:cutout", "elements": [e for e in model["elements"] if e["name"] != "glass"]}
    glass = {**common, "render_type": "minecraft:translucent", "elements": [e for e in model["elements"] if e["name"] == "glass"]}
    composite = {
        "loader": "neoforge:composite",
        "parent": "minecraft:block/block",
        "textures": {"particle": model["textures"]["particle"]},
        "children": {
            "shell": {"parent": f"{MOD}:block/pc_case_shell"},
            "glass": {"parent": f"{MOD}:block/pc_case_glass"},
        },
        "item_render_order": ["shell", "glass"],
    }
    return composite, shell, glass


if __name__ == "__main__":
    texdir = sys.argv[1]
    outjson = sys.argv[2]
    prev = sys.argv[3] if len(sys.argv) > 3 else None
    model = build_model()
    composite, shell, glass = split_models(model)
    base = os.path.dirname(outjson)
    for path, data in ((outjson, composite), (os.path.join(base, "pc_case_shell.json"), shell),
                       (os.path.join(base, "pc_case_glass.json"), glass)):
        with open(path, "w") as fh:
            json.dump(data, fh, indent=2)
    print("elements:", len(model["elements"]), "faces:", sum(len(e["faces"]) for e in model["elements"]),
          "| shell:", len(shell["elements"]), "glass:", len(glass["elements"]))
    if prev:
        render(model, texdir, 30, 225, prev + "_gui.png")
        render(model, texdir, 20, 135, prev + "_v135.png")
        render(model, texdir, 25, 315, prev + "_v315.png")
        render(model, texdir, 25, 45, prev + "_v45.png")
