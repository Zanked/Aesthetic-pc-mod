import sys, os
from gen_items2 import *
import gen_items2, gen_items
from cat import Pen, head, FUR, FUR_L, STRIPE


def ssd_m2():
    cv = new_canvas()
    PCB = (3, 19, 61, 45)
    rr(cv, PCB, 1.8, lin_grad(C(52, 54, 62), C(26, 27, 32), (3, 19), (3, 45)))
    # tiny SMD dots at the left end
    for (x, y) in ((4.6, 24), (4.6, 27), (4.6, 30), (4.6, 33), (4.6, 36), (4.6, 39)):
        ell(cv, x, y, 0.45, 0.45, C(120, 124, 138), 0.8)
    # gold contacts (right) with key notch
    for k in range(11):
        y = 20.2 + k * 2.2
        if 31 < y < 33.2:
            continue
        rr(cv, (57.6, y, 60.8, y + 1.3), 0.2, lin_grad(GOLD0, GOLD1, (57, y), (61, y)))
    # sticker: white edge + orange body
    rr(cv, (6.6, 21.4, 57, 42.6), 2.4, C(255, 255, 255))
    ST = (7.6, 22.4, 56, 41.6)
    rr(cv, ST, 1.8, lin_grad(C(255, 196, 96), C(250, 150, 48), (7, 22), (7, 42)))
    # big soft paw prints (lighter orange)
    clip = mask_from(lambda d: d.rounded_rectangle([ST[0] * S, ST[1] * S, ST[2] * S - 1, ST[3] * S - 1], 1.8 * S, fill=255))
    pw = new_canvas()
    for (cx, cy, s) in ((30, 33, 2.6), (22, 24, 1.5)):
        paw(pw, cx, cy, s, C(255, 222, 160))
    comp(cv, clip, pw, 0.55)
    # cat with goggles holding a gamepad (right)
    P = Pen(cv, 48.4, 30.4, 0.34)
    P.ell(0, 17, 13, 9, C(255, 255, 255), ow=0.7)            # white belly
    P.ell(-11, 13, 4, 6.5, FUR, ow=0.6)
    P.ell(11, 13, 4, 6.5, FUR, ow=0.6)
    P.rrect(-8, 10, 8, 19, 3, C(58, 62, 74), ow=0.6)         # gamepad
    P.ell(-4.6, 14.6, 1.8, 1.8, C(120, 126, 140))
    P.ell(4.6, 13.2, 1.1, 1.1, C(255, 154, 31))
    P.ell(6.8, 15.6, 1.1, 1.1, C(255, 154, 31))
    head(P)
    # screw notch (left, semicircle)
    a = cv.getchannel("A")
    hole = mask_from(lambda d: d.ellipse([0.6 * S, 29.2 * S, 5.2 * S, 34.8 * S], fill=255))
    cv.putalpha(ImageChops.subtract(a, hole))
    bevel(cv, PCB, 1.8, 0.25, 0.2)
    cv = shadowed(cv)
    img = finish(cv)
    big_text(img, 10, 25, "SSD", C(255, 255, 255), 2, shadow=C(190, 90, 10))
    put_text(img, 10, 36, "PCIE4.0", C(255, 255, 255), shadow=(0, 1, C(190, 90, 10, 255)))
    speckle(img, 1, 41)
    return img


def ram():
    cv = new_canvas()
    # slim DIMM: heatspreader y 22..38, pcb + gold contacts y 38..43
    rr(cv, (3, 36, 61, 43), 1.0, C(60, 64, 76))
    for k in range(28):
        x = 5 + k * 2.0 + (0.8 if k > 15 else 0)
        if 33.5 < x < 36:
            continue
        rr(cv, (x, 39.4, x + 1.2, 43), 0.2, lin_grad(GOLD0, GOLD1, (x, 39), (x, 43)))
    hs = (3, 21, 61, 38)
    rr(cv, hs, 2.0, lin_grad(WH0, C(214, 219, 230), (3, 21), (3, 38)))
    clip = mask_from(lambda d: d.rounded_rectangle([3 * S, 21 * S, 61 * S - 1, 38 * S - 1], 2.0 * S, fill=255))
    bar = new_canvas()
    stops = [(4, C(110, 190, 255)), (14, C(255, 140, 210)), (30, C(255, 250, 245)), (46, C(255, 214, 160)), (60, C(255, 150, 60))]
    for (x0, c0), (x1, c1) in zip(stops, stops[1:]):
        rr(bar, (x0, 21, x1 + 0.5, 25.4), 0, lin_grad(c0, c1, (x0, 0), (x1, 0)))
    comp(cv, ImageChops.multiply(clip, mask_from(lambda d: d.rectangle([0, 21 * S, W, 25.4 * S], fill=255))), bar)
    ell(cv, 32, 25.4, 28, 1.0, C(255, 255, 255), 0.5)
    pat = new_canvas()
    for gx in range(0, 9):
        cx = 7 + gx * 5.2
        if cx > 44:
            continue
        paw(pat, cx, 28.4 + (1.6 if gx % 2 else 0), 0.36, C(150, 156, 172))
    comp(cv, clip, pat, 0.55)
    # sunglasses cat badge (right)
    ell(cv, 52, 31.6, 4.2, 4.2, C(255, 255, 255))
    poly(cv, [(48.4, 30.0), (48.8, 26.4), (51.6, 28.6)], FUR)
    poly(cv, [(55.6, 30.0), (55.2, 26.4), (52.4, 28.6)], FUR)
    ell(cv, 52, 32, 3.4, 3.1, FUR)
    rr(cv, (48.6, 30.8, 55.4, 32.6), 0.7, C(30, 30, 36))
    ell(cv, 52, 34.2, 1.6, 1.0, C(255, 255, 255))
    poly(cv, [(3, 22), (18, 22), (11, 37), (3, 37)], C(255, 255, 255), 0.16)
    bevel(cv, hs, 2.0, 0.6, 0.3)
    cv = shadowed(cv)
    img = finish(cv)
    put_text(img, 16, 31, "MEOW", C(168, 174, 190), shadow=(0, 1, C(255, 255, 255, 220)))
    speckle(img, 1, 42)
    return img


if __name__ == "__main__":
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    gen_items.OUT = out
    gen_items.save(ssd_m2(), "ssd_m2")
    gen_items.save(ram(), "ram")
