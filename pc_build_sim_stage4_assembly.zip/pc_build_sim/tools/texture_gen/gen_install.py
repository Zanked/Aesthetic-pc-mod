"""Этап 3: «установленные» модели деталей внутри корпуса + blockstate со стадиями сборки.

    python gen_install.py <assets/pcbuildsim dir> [preview_dir]

Берёт item-модели деталей (models/item/<part>.json), поворачивает/масштабирует/сдвигает их так, чтобы они
оказались на своих местах внутри корпуса (система координат модели корпуса, лицо на север), и пишет:
  models/block/installed_<part>.json  - по одной модели на деталь
  blockstates/pc_case.json            - multipart: корпус + все детали со стадией >= своего номера
  models/block/pc_case_shell.json     - (патч) стойки на лотке сдвигаются под отверстия материнки
Запускать ПОСЛЕ gen_model.py (он перезаписывает pc_case_shell.json).
"""
import copy, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

ASSETS = os.path.abspath(sys.argv[1])
PREV = os.path.abspath(sys.argv[2]) if len(sys.argv) > 2 else None
ITEM = os.path.join(ASSETS, "models", "item")
BLOCK = os.path.join(ASSETS, "models", "block")

# ---------------------------------------------------------------- геометрия корпуса (координаты модели, лицо на север)
X_TRAY = 5.66       # плоскость, на которую встаёт материнка (верхушки стоек)
Z_BACK = 12.45      # внутренняя сторона задней стенки (с зазором)
Z_FRONT = 4.25      # внутренняя сторона передней панели
Y_FLOOR = 0.88
Y_TOP = 8.70

# ---------------------------------------------------------------- линейная алгебра на целых матрицах
DIR_VEC = {"north": (0, 0, -1), "south": (0, 0, 1), "east": (1, 0, 0), "west": (-1, 0, 0), "up": (0, 1, 0), "down": (0, -1, 0)}
# (u-ось, v-ось) текстуры грани в мировых координатах (как в майнкрафте / p3d_render.corners)
UV_AXES = {
    "north": ((-1, 0, 0), (0, -1, 0)),
    "south": ((1, 0, 0), (0, -1, 0)),
    "east": ((0, 0, -1), (0, -1, 0)),
    "west": ((0, 0, 1), (0, -1, 0)),
    "up": ((1, 0, 0), (0, 0, 1)),
    "down": ((1, 0, 0), (0, 0, -1)),
}


def mv(M, v):
    return tuple(sum(M[r][c] * v[c] for c in range(3)) for r in range(3))


def det(M):
    return (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1])
            - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0])
            + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]))


def vec_dir(v):
    for d, w in DIR_VEC.items():
        if tuple(v) == w:
            return d
    raise ValueError(v)


class Place:
    """case = A + k * (M @ model). M - перестановка осей со знаками (определитель +1, без зеркала)."""

    def __init__(self, M, k, anchor_model, anchor_case):
        assert det(M) == 1, "зеркальное преобразование недопустимо (текст на текстурах отзеркалится)"
        self.M, self.k = M, k
        mm = mv(M, anchor_model)
        self.A = tuple(anchor_case[i] - k * mm[i] for i in range(3))

    def pt(self, p):
        m = mv(self.M, p)
        return tuple(self.A[i] + self.k * m[i] for i in range(3))


def r4(v):
    return round(v + 0.0, 4)


def face_rotation(M, d):
    """поворот текстуры (0/90/180/270), чтобы рисунок остался «на месте» после перестановки осей"""
    a_u, a_v = UV_AXES[d]
    nd = vec_dir(mv(M, DIR_VEC[d]))
    A_u, A_v = UV_AXES[nd]
    U, V = mv(M, a_u), mv(M, a_v)
    neg = lambda v: tuple(-x for x in v)
    table = {0: (A_u, A_v), 90: (A_v, neg(A_u)), 180: (neg(A_u), neg(A_v)), 270: (neg(A_v), A_u)}
    for r, (eu, ev) in table.items():
        if U == eu and V == ev:
            return nd, r
    raise RuntimeError("не удалось подобрать поворот грани")


def transform_elements(elements, pl):
    out = []
    for el in elements:
        a, b = pl.pt(el["from"]), pl.pt(el["to"])
        lo = [r4(min(a[i], b[i])) for i in range(3)]
        hi = [r4(max(a[i], b[i])) for i in range(3)]
        new = {k: copy.deepcopy(v) for k, v in el.items() if k not in ("from", "to", "faces", "rotation")}
        new["from"], new["to"] = lo, hi
        faces = {}
        for d, f in el["faces"].items():
            assert "rotation" not in f
            nd, r = face_rotation(pl.M, d)
            nf = copy.deepcopy(f)
            if r:
                nf["rotation"] = r
            faces[nd] = nf
        new["faces"] = faces
        rot = el.get("rotation")
        if rot:
            axis_vec = {"x": (1, 0, 0), "y": (0, 1, 0), "z": (0, 0, 1)}[rot["axis"]]
            img = mv(pl.M, axis_vec)
            idx = [i for i in range(3) if img[i] != 0][0]
            sign = img[idx]
            origin = pl.pt(rot["origin"])
            nr = dict(rot)
            nr["axis"] = "xyz"[idx]
            nr["angle"] = rot["angle"] * sign
            nr["origin"] = [r4(v) for v in origin]
            new["rotation"] = nr
        out.append(new)
    return out


def load_item(name):
    with open(os.path.join(ITEM, name + ".json")) as fh:
        return json.load(fh)


def block_model(src, elements):
    return {
        "parent": "minecraft:block/block",
        "ambientocclusion": False,
        "render_type": "minecraft:cutout",
        "textures": src["textures"],
        "elements": elements,
    }


# ---------------------------------------------------------------- ориентации (матрицы строк x,y,z случая от x,y,z модели)
#   MAP_A   : деталь «лежит» на плоскости материнки: модель +y -> к стеклу (+x), +z -> вверх, +x -> назад. Текст читается с боковины.
#   MAP_RAM : планка стоит в слоте: длинная ось -> вверх, ширина -> от платы, толщина -> назад
#   MAP_FLAT: плата/карта лежит горизонтально, низ (модель +y) смотрит вниз (вентиляторы вниз), длинная ось -> назад
#   MAP_RAD : радиатор стоит у передней панели, вентилятор смотрит назад
#   MAP_DRV : диск лежит на дне, длинная сторона -> поперёк корпуса
MAP_A = ((0, 1, 0), (0, 0, 1), (1, 0, 0))
MAP_RAM = ((0, 0, 1), (1, 0, 0), (0, 1, 0))
MAP_FLAT = ((0, 0, 1), (0, -1, 0), (1, 0, 0))
MAP_RAD = ((1, 0, 0), (0, 0, -1), (0, 1, 0))
MAP_DRV = ((0, 0, -1), (0, 1, 0), (1, 0, 0))

# материнка
S_B = 0.40
BOARD = Place(MAP_A, S_B, (15.3, 0, 15.0), (X_TRAY, Y_TOP, Z_BACK))   # край I/O (x=15.3) - к задней стенке, верх платы - к верху


def board_pt(mx, my, mz):
    return BOARD.pt((mx, my, mz))


# ---------------------------------------------------------------- детали
def build_parts():
    parts = {}

    # 1. материнская плата
    m = load_item("motherboard")
    parts["motherboard"] = block_model(m, transform_elements(m["elements"], BOARD))

    # 2. процессор - в сокет (сокет на плате: x 4.9..9.35, z 6.9..11.35, дно сокета y=1.0)
    c = load_item("cpu")
    sock = board_pt(7.125, 1.0, 9.125)
    k = S_B * 4.4 / 12.5
    pl = Place(MAP_A, k, (8.0, 0, 8.0), sock)
    parts["cpu"] = block_model(c, transform_elements(c["elements"], pl))
    cpu_top = sock[0] + k * 2.2

    # 3. ОЗУ - в первый слот (вертикально). слоты: x 1.35..1.85 (первый), z 6.75..14.5
    r = load_item("ram")
    k_r = S_B * 0.45
    # cx = ax + k*mz (от платы), cy = ay + k*mx (вверх), cz = az + k*my (назад)
    # якорь: контактная кромка (mz=5.25) у верха слота, середина планки (mx=8) по середине слота, середина толщины (my=1.3) по оси слота
    ram_pl = Place(MAP_RAM, k_r, (8.0, 1.3, 5.25),
                   (board_pt(0, 2.0, 0)[0], board_pt(0, 0, 10.6)[1], board_pt(1.6, 0, 0)[2]))
    parts["ram"] = block_model(r, transform_elements(r["elements"], ram_pl))

    # 4. M.2 SSD - на плате, над разъёмом (x 7.5..14, z 3.1..4.5, высота 1.7)
    s = load_item("ssd_m2")
    k_m = S_B * 0.40
    pl = Place(MAP_A, k_m, (8.0, 0, 8.0), board_pt(10.75, 1.7, 3.8))
    parts["ssd_m2"] = block_model(s, transform_elements(s["elements"], pl))

    # 5. кулер СЖО: помпа на CPU + радиатор у передней панели + шланги
    cc = load_item("cpu_cooler")
    els = cc["elements"]
    # в модели: elements 0..7 - помпа (квадрат 5.75, кольцо-логотип сверху), 8..15 - шланги, 16..28 - радиатор с вентилятором
    k_h = 0.30
    pl_head = Place(MAP_A, k_h, (12.375, 0, 9.025), (cpu_top, sock[1], sock[2]))
    head = transform_elements(els[0:8], pl_head)
    k_rad = 0.60
    pl_rad = Place(MAP_RAD, k_rad, (0.6, 0.0, 2.4), (6.3, 8.6, Z_FRONT))
    rad = transform_elements(els[16:29], pl_rad)
    tube = els[8]["faces"]
    z_head_front = sock[2] - k_h * 5.75 / 2
    z_rad_back = Z_FRONT + k_rad * 2.9
    x_hose = 7.50
    hoses = []
    for i, y in enumerate((sock[1] - 0.40, sock[1] + 0.10)):
        faces = {d: copy.deepcopy(tube.get(d) or tube["up"]) for d in ("north", "south", "east", "west", "up", "down")}
        hoses.append({"name": f"hose_{i}", "from": [r4(x_hose), r4(y), r4(z_rad_back - 0.05)],
                      "to": [r4(x_hose + 0.35), r4(y + 0.35), r4(z_head_front + 0.05)], "faces": faces})
    parts["cpu_cooler"] = block_model(cc, rad + head + hoses)

    # 6. блок питания - на дне сзади, вентилятор вниз, кабели в сторону лотка
    p = load_item("psu")
    k_p = 0.34
    # кабели (mz=-0.3) у x=5.7, низ (my=6.35) на дне, AC-вход (mx=15.45) у задней стенки
    pl = Place(MAP_FLAT, k_p, (15.45, 6.35, -0.3), (5.7, Y_FLOOR, Z_BACK))
    parts["psu"] = block_model(p, transform_elements(p["elements"], pl))

    # 7. видеокарта - в PCIe (слот на плате x 6..14, z 5..6, y 0.8..1.9), вентиляторы вниз, планка у задней стенки
    g = load_item("gpu")
    k_g = S_B
    slot_c = board_pt(10.0, 1.35, 5.5)      # центр слота
    pl = Place(MAP_FLAT, k_g, (15.0, 1.65, 4.5), (X_TRAY + 0.30, slot_c[1], Z_BACK))
    parts["gpu"] = block_model(g, transform_elements(g["elements"], pl))

    # 8. SATA SSD, 9. HDD - на дне у передней панели (HDD внизу, SSD сверху)
    hd = load_item("hdd")
    k_d = 0.23
    pl_hdd = Place(MAP_DRV, k_d, (1.5, 0, 0.2), (10.6, Y_FLOOR, Z_FRONT + 0.05))
    parts["hdd"] = block_model(hd, transform_elements(hd["elements"], pl_hdd))
    hdd_top = Y_FLOOR + k_d * 4.15
    ss = load_item("ssd_sata")
    pl_ssd = Place(MAP_DRV, k_d, (2.0, 0, 1.0), (10.5, hdd_top, Z_FRONT + 0.1))
    parts["ssd_sata"] = block_model(ss, transform_elements(ss["elements"], pl_ssd))
    return parts


# порядок сборки (стадия i = установлено i деталей)
ORDER = ["motherboard", "cpu", "ram", "ssd_m2", "cpu_cooler", "psu", "gpu", "ssd_sata", "hdd"]
FACINGS = {"north": 0, "east": 90, "south": 180, "west": 270}


def write_all(parts):
    for name, model in parts.items():
        with open(os.path.join(BLOCK, f"installed_{name}.json"), "w") as fh:
            json.dump(model, fh, indent=1)

    n = len(ORDER)
    mp = []
    for f, y in FACINGS.items():
        ap = {"model": "pcbuildsim:block/pc_case"}
        if y:
            ap["y"] = y
        mp.append({"when": {"facing": f}, "apply": ap})
    for i, name in enumerate(ORDER, start=1):
        stages = "|".join(str(s) for s in range(i, n + 1))
        for f, y in FACINGS.items():
            ap = {"model": f"pcbuildsim:block/installed_{name}"}
            if y:
                ap["y"] = y
            mp.append({"when": {"facing": f, "stage": stages}, "apply": ap})
    with open(os.path.join(ASSETS, "blockstates", "pc_case.json"), "w") as fh:
        json.dump({"multipart": mp}, fh, indent=1)


def patch_standoffs():
    """стойки на лотке - под отверстия материнки (3x3 без центра)"""
    path = os.path.join(BLOCK, "pc_case_shell.json")
    with open(path) as fh:
        shell = json.load(fh)
    holes = [(mx, mz) for mx in (2.0, 8.0, 14.0) for mz in (2.0, 8.0, 14.0) if (mx, mz) != (8.0, 8.0)]
    byname = {e["name"]: e for e in shell["elements"]}
    for i, (mx, mz) in enumerate(holes):
        el = byname[f"standoff_{i}"]
        p = board_pt(mx, 0, mz)
        h = 0.145
        el["from"] = [5.37, r4(p[1] - h), r4(p[2] - h)]
        el["to"] = [r4(X_TRAY), r4(p[1] + h), r4(p[2] + h)]
    with open(path, "w") as fh:
        json.dump(shell, fh, indent=2)


def merged_model(shell, parts, stage):
    """склейка оболочки и деталей в одну модель для превью (ключи текстур деталей переименовываются, чтобы не затирали друг друга)"""
    els = copy.deepcopy(shell["elements"])
    textures = dict(shell["textures"])
    for name in ORDER[:stage]:
        mdl = parts[name]
        for k, v in mdl["textures"].items():
            if k != "particle":
                textures[f"{name}_{k}"] = v
        for el in copy.deepcopy(mdl["elements"]):
            for f in el["faces"].values():
                f["texture"] = "#" + name + "_" + f["texture"][1:]
            els.append(el)
    return {"textures": textures, "elements": els}


def preview(parts):
    import p3d_render as RD
    from PIL import Image
    shell = json.load(open(os.path.join(BLOCK, "pc_case_shell.json")))
    loader = RD.Loader(os.path.join(ASSETS, "textures"))
    os.makedirs(PREV, exist_ok=True)
    # финал: вид сбоку (со стороны стекла) + два ракурса
    views = [(0, 270, 1.15), (22, 235, 1.0), (22, 305, 1.0)]
    sheet = Image.new("RGB", (len(views) * 520, 520), (200, 214, 224))
    for i, (rx, ry, sc) in enumerate(views):
        sheet.paste(RD.render(merged_model(shell, parts, 9), loader, rx, ry, 520, scale=sc, ty=3.3 if rx == 0 else 3.0, ss=3), (i * 520, 0))
    sheet.save(os.path.join(PREV, "assembly_final.png"))
    # по шагам (вид сбоку с небольшим наклоном)
    cols = 5
    steps = Image.new("RGB", (cols * 360, 2 * 360), (200, 214, 224))
    for st in range(1, 10):
        im = RD.render(merged_model(shell, parts, st), loader, 15, 250, 360, scale=0.95, ty=2.9, ss=3)
        steps.paste(im, (((st - 1) % cols) * 360, ((st - 1) // cols) * 360))
    steps.save(os.path.join(PREV, "assembly_steps.png"))


if __name__ == "__main__":
    parts = build_parts()
    write_all(parts)
    patch_standoffs()
    print("installed models:", ", ".join(f"{n}({len(m['elements'])})" for n, m in parts.items()))
    if PREV:
        preview(parts)
        print("preview ->", PREV)
