"""Pixel-art cats for the case textures (crisp, cel-shaded, auto outline)."""
import math
import numpy as np
from px import Cv, H, BAYER4

OUT = H("#5E2A0B")
FUR_L, FUR, FUR_D, FUR_DD = H("#FFC46E"), H("#FF9C2E"), H("#E8791A"), H("#C65A10")
STR = H("#C75D10")
CRM, CRM_D, CRM_DD = H("#FFF6E0"), H("#F6DFB6"), H("#E3C393")
PNK, PNK_D = H("#FF93A8"), H("#E8657F")
EYE = H("#3B2013")
JK, JK_L, JK_D = H("#454B5E"), H("#646C82"), H("#2D3140")
ZIP = H("#FF8E22")
LENS, LENS_L, LENS_D = H("#58DCF6"), H("#D4FAFF"), H("#2B9AC4")
RIM, STRAP = H("#2B303C"), H("#3E4452")
CHEESE, CHEESE_L, CHEESE_D = H("#FFD35A"), H("#FFEB9C"), H("#F0AE2E")
CRUST, CRUST_D = H("#E9A85F"), H("#C98338")
PEP, PEP_D = H("#E04A35"), H("#A92E22")
BASIL = H("#58A94A")
BOX, BOX_D, BOX_DD = H("#FFF9EC"), H("#EBDDC3"), H("#CDBB9B")


class Sc:
    """draws in 'sprite space' but lands on a smaller pixel grid (geometry is scaled, pixels stay crisp)"""
    def __init__(self, W, Hh, s, margin=0):
        self.s = s
        self.m = margin
        ex = 0 if s == 1.0 else 1
        self.base = Cv(int(math.ceil(W * s)) + ex + 2 * margin, int(math.ceil(Hh * s)) + ex + 2 * margin)
        self.w, self.h = W, Hh

    def px(self, x, y, c, alpha=None):
        self.base.px(int(math.floor(x * self.s + 0.5)) + self.m, int(math.floor(y * self.s + 0.5)) + self.m, c, alpha)

    def rect(self, x0, y0, x1, y1, c, alpha=None):
        X0, Y0 = int(round(x0 * self.s)) + self.m, int(round(y0 * self.s)) + self.m
        X1, Y1 = max(int(round(x1 * self.s)) + self.m, X0 + 1), max(int(round(y1 * self.s)) + self.m, Y0 + 1)
        self.base.rect(X0, Y0, X1, Y1, c, alpha)

    def hline(self, x0, x1, y, c, alpha=None):
        self.rect(x0, y, x1, y + 1, c, alpha)

    def vline(self, x, y0, y1, c, alpha=None):
        self.rect(x, y0, x + 1, y1, c, alpha)

    def ell(self, cx, cy, rx, ry, c, alpha=None):
        s = self.s
        self.base.ell(cx * s + self.m, cy * s + self.m, max(rx * s, 0.9), max(ry * s, 0.9), c, alpha)

    def poly(self, pts, c, alpha=None):
        self.base.poly([(x * self.s + self.m, y * self.s + self.m) for x, y in pts], c, alpha)

    def line(self, x0, y0, x1, y1, c, alpha=None):
        s = self.s
        m = self.m
        self.base.line(round(x0 * s) + m, round(y0 * s) + m, round(x1 * s) + m, round(y1 * s) + m, c, alpha)

    def outline(self, c, **kw):
        if c is None:
            self.base.outline_sel()
        else:
            self.base.outline(c, **kw)

    def outline_sel(self, **kw):
        self.base.outline_sel(**kw)

    def rrect(self, x0, y0, x1, y1, c, r=2, alpha=None):
        k, m = self.s, self.m
        self.base.rrect(int(round(x0 * k)) + m, int(round(y0 * k)) + m, max(int(round(x1 * k)), int(round(x0 * k)) + 1) + m,
                        max(int(round(y1 * k)), int(round(y0 * k)) + 1) + m, c, r, alpha)

    @property
    def a(self):
        return self.base.a


def shaded_ell(cv, cx, cy, rx, ry, cols, light=(-0.55, -0.75), dith=True, hi=0.42, lo=-0.28):
    """cel-shaded ellipse. cols = (light, mid, dark[, deepest])"""
    lx, ly = light
    lz = math.sqrt(max(0.0, 1 - lx * lx - ly * ly))
    if isinstance(cv, Sc):
        k = cv.s
        cx, cy, rx, ry = cx * k + cv.m, cy * k + cv.m, max(rx * k, 0.9), max(ry * k, 0.9)
        cv = cv.base
    for y in range(cv.h):
        for x in range(cv.w):
            nx = (x + 0.5 - cx) / rx
            ny = (y + 0.5 - cy) / ry
            r2 = nx * nx + ny * ny
            if r2 > 1:
                continue
            nz = math.sqrt(1 - r2)
            l = nx * lx + ny * ly + nz * lz
            j = (BAYER4[y % 4, x % 4] - 0.5) * 0.16 if dith else 0
            l += j
            if l > hi:
                c = cols[0]
            elif l > lo:
                c = cols[1]
            elif len(cols) > 3 and l < lo - 0.55:
                c = cols[3]
            else:
                c = cols[2]
            cv.px(x, y, c)


def tri(cv, pts, c):
    cv.poly(pts, c)


def comp(dst, src):
    ys, xs = np.nonzero(src.a[..., 3] > 0)
    for y, x in zip(ys, xs):
        dst.a[y, x] = src.a[y, x]


SCALE = 1.0
MARGIN = 0


OUTLINE_MODE = "sel"      # 'sel' = soft coloured outlines, 'dark' = old heavy brown


def part(W, Hh, drawfn, outline="default"):
    p = Sc(W, Hh, SCALE, MARGIN)
    drawfn(p)
    if outline == "default":
        outline = None if OUTLINE_MODE == "sel" else OUT
    if outline is not False:
        p.outline(outline)
    return p


def sitting_cat(W=42, Hh=48, scale=1.0):
    """cat sitting behind an open pizza box, goggles on forehead, nibbling a slice. returns Cv"""
    global SCALE, MARGIN
    SCALE, MARGIN = scale, 1
    cv = Sc(W, Hh, scale, 1)
    cx = 19

    # ------------------------------------------------------------- tail
    def d_tail(p):
        tail = [(30, 42), (33.5, 41), (35.5, 38), (36.3, 34), (36.2, 30), (35.4, 26), (34, 23)]
        for (tx, ty) in tail:
            p.ell(tx, ty, 2.7, 2.7, FUR)
        for (tx, ty) in tail:
            p.px(tx - 1, ty - 1, FUR_L)
            p.px(tx - 1, ty, FUR_L)
            p.px(tx + 1, ty + 1, FUR_D)
            p.px(tx + 2, ty + 1, FUR_D)
        for (tx, ty) in ((36, 37), (36, 33), (36, 29), (35, 25.5)):
            p.hline(tx - 2, tx + 3, ty, STR)
        p.ell(33.8, 22.2, 2.7, 2.4, CRM)
        p.px(32, 21, H("#FFFFFF"))
        p.px(33, 21, H("#FFFFFF"))
        p.px(35, 24, CRM_D)
    comp(cv, part(W, Hh, d_tail))

    # ------------------------------------------------------------- body (jacket)
    def d_body(p):
        shaded_ell(p, cx, 33, 11.2, 10.4, (JK_L, JK, JK_D), hi=0.5, lo=-0.3)
        # orange collar
        p.ell(cx, 25.6, 6.8, 2.5, ZIP)
        p.ell(cx - 0.5, 25.1, 5.4, 1.5, H("#FFB352"))
        # zip
        for yy in range(27, 38):
            p.px(cx, yy, ZIP)
            if yy % 2 == 1:
                p.px(cx, yy, H("#FFD08A"))
        # sleeve seams + orange side stripes
        p.vline(cx - 9, 29, 38, ZIP)
        p.vline(cx + 9, 29, 38, ZIP)
        p.px(cx - 4, 33, JK_D)
        p.px(cx - 5, 33, JK_D)
        p.px(cx + 4, 33, JK_D)
        p.px(cx + 5, 33, JK_D)
        # little badge
        p.rect(cx - 7, 29, cx - 4, 31, ZIP)
        p.px(cx - 6, 30, H("#FFE2A8"))
    comp(cv, part(W, Hh, d_body))

    # ------------------------------------------------------------- head with ears + goggles
    def d_head(p):
        # ears
        for sx in (-1, 1):
            ex = cx + sx * 8.5
            p.poly([(ex - 5.2, 11.5), (ex + sx * 0.3, 0.2), (ex + 5.2, 11.5)], FUR)
            p.poly([(ex - 3.2, 11), (ex + sx * 0.2, 3.4), (ex + 3.2, 11)], PNK)
            p.px(int(ex + sx * 0.2), 4, PNK_D) if False else None
            p.px(int(ex) - 2 + (1 if sx > 0 else 0), 6, FUR_D)
            p.vline(int(ex) + (3 if sx > 0 else -3), 9, 12, PNK_D)
        # head
        shaded_ell(p, cx, 15.5, 12.4, 9.1, (FUR_L, FUR, FUR_D, FUR_DD), light=(-0.45, -0.85), hi=0.5, lo=-0.22)
        for sx in (-1, 1):
            p.px(cx + sx * 12, 19, FUR_D)
            p.px(cx + sx * 13, 19, FUR_D)
            p.px(cx + sx * 12, 20, FUR_D)
            p.px(cx + sx * 11, 21, FUR_D)
        # muzzle
        shaded_ell(p, cx, 19.8, 6.4, 4.4, (CRM, CRM, CRM_D), light=(-0.3, -0.9), hi=0.9, lo=0.15, dith=False)
        # cheek stripes
        for sx in (-1, 1):
            base = cx + sx * 10
            for k, yy in enumerate((15, 17, 19)):
                L = 2 if k != 1 else 3
                for i in range(L):
                    p.px(base - sx * i, yy, STR)
        for xx in (cx - 2, cx, cx + 2):
            p.px(xx, 8, STR)
        # goggles
        p.rect(cx - 12, 9, cx + 12, 11, STRAP)
        p.hline(cx - 12, cx + 12, 9, H("#5A6174"))
        for sx in (-1, 1):
            lx = cx + sx * 5.8
            p.ell(lx, 8.4, 5.1, 3.9, RIM)
            shaded_ell(p, lx, 8.4, 4.1, 2.9, (LENS_L, LENS, LENS_D), light=(-0.5, -0.8), hi=0.55, lo=-0.1)
            p.px(int(lx) - 2, 7, H("#FFFFFF"))
            p.px(int(lx) - 1, 6, H("#FFFFFF"))
        p.rect(cx - 1, 8, cx + 1, 10, RIM)
        # eyes ^ ^
        for sx in (-1, 1):
            ex = cx + sx * 6
            p.px(ex - 2, 17, EYE)
            p.px(ex - 1, 16, EYE)
            p.px(ex, 16, EYE)
            p.px(ex + 1, 17, EYE)
            bx = ex - 2 + (1 if sx < 0 else -1)
            p.rect(bx, 19, bx + 4, 20, PNK)
        # nose + mouth
        p.rect(cx - 1, 18, cx + 1, 19, PNK_D)
        p.px(cx, 19, PNK)
        p.px(cx - 2, 20, EYE)
        p.px(cx - 1, 21, EYE)
        p.px(cx, 20, EYE)
        p.px(cx + 1, 21, EYE)
        p.px(cx + 2, 20, EYE)
    comp(cv, part(W, Hh, d_head))

    # ------------------------------------------------------------- pizza box (open) + pizza
    def d_lid(p):
        p.poly([(6, 38.5), (9, 32.2), (cx + 11, 32.2), (33, 38.5)], BOX)
        p.hline(9, cx + 11, 32, H("#FFFFFF"))
        p.hline(7, 33, 38, BOX_D)
        # paw emblem on the lid
        c0 = H("#FF9C2E")
        p.rect(cx - 2, 35, cx + 1, 37, c0)
        p.px(cx - 3, 34, c0)
        p.px(cx, 34, c0)
        p.px(cx - 1, 33, c0)
        p.px(cx + 2, 34, c0)
        p.px(cx - 1, 35, H("#FFC46E"))
    comp(cv, part(W, Hh, d_lid))

    def d_box(p):
        # front wall
        p.poly([(3, 40.5), (35, 40.5), (33.4, 47.4), (4.6, 47.4)], BOX)
        p.hline(4, 34, 40, BOX_D)
        p.hline(4, 35, 41, BOX_DD)
        p.rect(5, 45, 34, 47, BOX_D)
        p.hline(5, 34, 44, ZIP)
        p.hline(5, 34, 43, H("#FFB352"))
        # pizza
        p.ell(cx + 0.2, 40.9, 15.2, 5.0, CRUST_D)
        p.ell(cx + 0.2, 40.5, 14.8, 4.6, CRUST)
        p.ell(cx + 0.2, 40.7, 12.7, 3.5, CHEESE)
        p.ell(cx - 1.8, 40.0, 9.6, 2.1, CHEESE_L)
        for y in range(p.h):
            for x in range(p.w):
                nx = (x + 0.5 - (cx + 0.2)) / 12.7
                ny = (y + 0.5 - 40.7) / 3.5
                if nx * nx + ny * ny <= 1 and (nx * 0.5 + ny) > 0.55:
                    p.px(x, y, CHEESE_D)
        for (px_, py_) in ((9, 40.5), (15, 42), (22, 40), (28, 42), (32, 40.2)):
            p.ell(px_, py_, 2.3, 1.45, PEP)
            p.px(int(px_) - 1, int(py_) - 1, H("#F58A70"))
            p.px(int(px_) + 1, int(py_), PEP_D)
        for (bx, by) in ((12, 39), (25, 43), (30, 38)):
            p.px(bx, by, BASIL)
            p.px(bx + 1, by, BASIL)
    comp(cv, part(W, Hh, d_box))

    # ------------------------------------------------------------- slice raised to the mouth + paws
    def d_slice(p):
        sl = [(cx + 3.2, 23.2), (cx + 13.6, 27.4), (cx + 7.5, 33.2)]
        p.poly(sl, CRUST)
        p.poly([(cx + 4.6, 24.6), (cx + 12.0, 27.6), (cx + 7.6, 31.8)], CHEESE)
        p.poly([(cx + 5.0, 25.0), (cx + 9.0, 26.4), (cx + 6.6, 28.2)], CHEESE_L)
        p.px(cx + 9, 28, PEP)
        p.px(cx + 10, 28, PEP)
        p.px(cx + 9, 29, PEP_D)
        p.px(cx + 8, 30, PEP)
        # crust edge highlight
        p.line(cx + 13, 27.8, cx + 7.8, 32.6, CRUST_D)
        # cheese drip
        p.px(cx + 2, 23, CHEESE)
        p.px(cx + 2, 24, CHEESE_L)
    comp(cv, part(W, Hh, d_slice))

    def d_paws(p):
        # right paw holds the slice crust
        p.ell(cx + 12.3, 31.4, 3.3, 2.7, CRM)
        p.px(cx + 10, 30, H("#FFFFFF"))
        p.px(cx + 11, 30, H("#FFFFFF"))
        p.px(cx + 13, 33, CRM_D)
        p.px(cx + 14, 32, CRM_D)
        p.px(cx + 11, 33, CRM_D)
        p.px(cx + 12, 31, CRM_DD)
        p.px(cx + 14, 31, CRM_DD)
        # left paw rests on the box edge
        p.ell(cx - 11.5, 39.2, 3.6, 2.6, CRM)
        p.px(cx - 13, 38, H("#FFFFFF"))
        p.px(cx - 12, 38, H("#FFFFFF"))
        p.px(cx - 9, 40, CRM_D)
        p.px(cx - 13, 41, CRM_D)
        p.px(cx - 12, 39, CRM_DD)
        p.px(cx - 10, 39, CRM_DD)
    comp(cv, part(W, Hh, d_paws))

    if OUTLINE_MODE != "sel":          # soft mode: every part already carries its own coloured outline
        cv.outline(OUT)
    MARGIN = 0
    return cv.base


def screen_scene(W=30, Hh=16):
    """30x16 handheld-screen illustration: sphinx-pose cat (goggles up) between a game pad and a soda"""
    global SCALE, MARGIN
    SCALE, MARGIN = 1.0, 0
    cv = Cv(W, Hh)
    # calm flat background: warm cream sky, a slightly deeper floor
    cv.rect(0, 0, W, Hh, H("#FFF3CF"))
    cv.rect(0, 0, W, 6, H("#FFF8E0"))
    cv.hline(0, W, 6, H("#FFF3CF"))
    for x in range(0, W, 2):
        cv.px(x + (0 if x % 4 == 0 else 1), 6, H("#FFF8E0"))
    cv.rect(0, 12, W, Hh, H("#F5CE80"))
    cv.hline(0, W, 12, H("#FFE2A6"))
    cv.rect(0, 15, W, Hh, H("#E8B866"))
    # sparkles
    for (sx, sy) in ((3, 3), (26, 2)):
        cv.px(sx, sy, H("#FFFFFF"))
        cv.px(sx - 1, sy, H("#FFE9B0"))
        cv.px(sx + 1, sy, H("#FFE9B0"))
        cv.px(sx, sy - 1, H("#FFE9B0"))
        cv.px(sx, sy + 1, H("#FFE9B0"))
    cv.px(8, 1, H("#FFFFFF"))
    cv.px(22, 4, H("#FFFFFF"))
    # floor shadow
    cv.ell(15, 14.2, 9.5, 1.2, H("#C98E3E"), 0.35)

    # ---- game pad (left)
    def d_pad(p):
        p.rrect(1, 9, 8, 14, H("#B9C2D8"), 2)
        p.hline(2, 7, 9, H("#E3E8F4"))
        p.hline(2, 7, 13, H("#8791AB"))
        # d-pad cross
        p.px(3, 10, H("#454B5E"))
        p.px(2, 11, H("#454B5E"))
        p.px(3, 11, H("#454B5E"))
        p.px(4, 11, H("#454B5E"))
        p.px(3, 12, H("#454B5E"))
        # buttons
        p.px(6, 10, H("#E8473A"))
        p.px(5, 11, H("#FFD35A"))
        p.px(6, 12, H("#58DCF6")) if False else None
    comp(cv, part(W, Hh, d_pad, outline=H("#4A5068")))

    # ---- soda cup (right)
    def d_cup(p):
        p.poly([(23.5, 7.2), (28.6, 7.2), (27.8, 13.8), (24.3, 13.8)], H("#E8473A"))
        p.rect(23, 6, 29, 8, H("#FFFFFF"))
        p.hline(23, 29, 6, H("#FFFFFF"))
        p.hline(24, 28, 10, H("#FFFFFF"))
        p.vline(25, 8, 10, H("#FF8A7A"))
        p.vline(25, 11, 13, H("#FF8A7A"))
        p.rect(27, 11, 28, 14, H("#B5302A"))
        # straw
        p.line(26, 5.6, 27.6, 1.8, H("#FFFFFF"))
        p.px(26, 4, H("#E8473A"))
        p.px(27, 3, H("#E8473A"))
    comp(cv, part(W, Hh, d_cup, outline=H("#7A2A22")))

    # ---- cat body / shoulders (behind the head)
    def d_body(p):
        shaded_ell(p, 15, 13.4, 8.4, 3.2, (JK_L, JK, JK_D), light=(-0.3, -0.9), hi=0.5, lo=-0.2)
        p.hline(11, 19, 11, ZIP)
        p.hline(12, 18, 12, H("#FFB352"))
    comp(cv, part(W, Hh, d_body))

    # ---- head
    def d_head(p):
        # ears
        for sx in (-1, 1):
            ex = 15 + sx * 4.8
            p.poly([(ex - 2.6, 5.6), (ex + sx * 0.4, 0.6), (ex + 2.6, 5.6)], FUR)
            p.poly([(ex - 1.2, 5.2), (ex + sx * 0.2, 2.4), (ex + 1.2, 5.2)], PNK)
        shaded_ell(p, 15, 8.0, 7.0, 4.8, (FUR_L, FUR, FUR_D), light=(-0.45, -0.85), hi=0.5, lo=-0.2)
        # forehead stripes + cheek stripes
        p.px(14, 3, STR)
        p.px(15, 3, STR)
        p.px(16, 3, STR)
        p.px(15, 4, STR)
        for sx in (-1, 1):
            p.px(15 + sx * 7, 8, STR)
            p.px(15 + sx * 6, 9, STR)
        # goggles on the forehead
        p.hline(9, 21, 4, STRAP)
        for gx in (12.4, 17.6):
            p.ell(gx, 4.4, 2.3, 1.8, RIM)
            p.ell(gx, 4.4, 1.7, 1.2, LENS)
            p.px(int(gx) - 1, 3, H("#FFFFFF"))
            p.px(int(gx), 3, LENS_L)
        # muzzle
        p.ell(15, 10.2, 3.3, 1.8, CRM)
        # closed happy eyes (^ ^)
        for ex in (11, 18):
            p.px(ex, 8, EYE)
            p.px(ex + 1, 7, EYE)
            p.px(ex + 2, 8, EYE)
        # blush, nose, mouth
        p.rect(9, 9, 11, 10, PNK)
        p.rect(20, 9, 22, 10, PNK)
        p.px(14, 9, PNK_D)
        p.px(15, 9, PNK_D)
        p.px(13, 10, EYE)
        p.px(14, 11, EYE)
        p.px(15, 10, EYE) if False else None
        p.px(15, 11, EYE)
        p.px(16, 10, EYE)
    comp(cv, part(W, Hh, d_head))

    # ---- front paws on the floor
    def d_paws(p):
        for px_ in (11, 19):
            p.ell(px_, 14.2, 2.4, 1.3, CRM)
            p.px(px_ - 1, 14, CRM_DD)
            p.px(px_ + 1, 14, CRM_DD)
            p.px(px_ - 1, 13, H("#FFFFFF"))
    comp(cv, part(W, Hh, d_paws))
    return cv


if __name__ == "__main__":
    import sys
    from PIL import Image
    c = sitting_cat()
    bg = Image.new("RGBA", (c.w, c.h), (120, 150, 170, 255))
    bg.alpha_composite(c.image())
    bg.resize((c.w * 12, c.h * 12), Image.NEAREST).save("/home/claude/cat_sit.png")
    l = screen_scene()
    l.image().resize((l.w * 16, l.h * 16), Image.NEAREST).save("/home/claude/cat_lie.png")
