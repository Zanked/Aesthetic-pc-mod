"""Builds the 3D item models of the PC parts.

    python gen_parts3d.py <assets/pcbuildsim dir> [preview_dir]

writes   textures/item/parts_atlas.png, textures/item/<part>_top.png   and   models/item/<part>.json
and (optionally) PNG previews rendered with a small software renderer (p3d_render.py)."""
import json, os, sys, tempfile

ASSETS = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else None
PREV = os.path.abspath(sys.argv[2]) if len(sys.argv) > 2 else None
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.argv = sys.argv[:1]
os.chdir(tempfile.mkdtemp())  # the old icon scripts create an output dir on import

import p3d_tex as T
import p3d_model as M
import p3d_render as RD
from PIL import Image

MOD = "pcbuildsim"


def display(model_els, gui):
    s, tx, ty = gui
    ys = [e["from"][1] for e in model_els] + [e["to"][1] for e in model_els]
    cy = (min(ys) + max(ys)) / 2
    top = max(ys)
    g = 0.5
    return {
        "gui": {"rotation": [30, 225, 0], "translation": [tx, ty, 0], "scale": [s, s, s]},
        "ground": {"rotation": [0, 0, 0], "translation": [0, round(1 + 8 * g - cy * g, 2), 0], "scale": [g, g, g]},
        "fixed": {"rotation": [-90, 0, 0], "translation": [0, 0, 0], "scale": [0.6, 0.6, 0.6]},
        "thirdperson_righthand": {"rotation": [60, 45, 0], "translation": [0, round(2.5 + (8 - cy) * 0.375, 2), 0], "scale": [0.375, 0.375, 0.375]},
        "thirdperson_lefthand": {"rotation": [60, 45, 0], "translation": [0, round(2.5 + (8 - cy) * 0.375, 2), 0], "scale": [0.375, 0.375, 0.375]},
        "firstperson_righthand": {"rotation": [25, 45, 0], "translation": [0, round((8 - cy) * 0.45, 2), 0], "scale": [0.45, 0.45, 0.45]},
        "firstperson_lefthand": {"rotation": [25, 225, 0], "translation": [0, round((8 - cy) * 0.45, 2), 0], "scale": [0.45, 0.45, 0.45]},
    }


def main():
    models = {}
    for name, fn in M.PARTS.items():
        part = fn()
        els = M.build_elements(part)
        textures = {"atlas": f"{MOD}:item/parts_atlas", "art": f"{MOD}:item/{part.art}", "particle": f"{MOD}:item/{part.art}"}
        model = {"parent": "minecraft:block/block", "ambientocclusion": False, "render_type": "minecraft:cutout",
                 "textures": textures, "elements": els}
        gui = RD.fit_gui(model)
        model["display"] = display(els, gui)
        models[name] = (model, part)
        print(f"{name:12s} elements={len(els):3d} faces={sum(len(e['faces']) for e in els):4d} gui={gui}")

    if ASSETS:
        tex_dir = os.path.join(ASSETS, "textures", "item")
        mod_dir = os.path.join(ASSETS, "models", "item")
        os.makedirs(tex_dir, exist_ok=True)
        os.makedirs(mod_dir, exist_ok=True)
        T.ATLAS.img.save(os.path.join(tex_dir, "parts_atlas.png"))
        for n, im in T.make_tops().items():
            im.save(os.path.join(tex_dir, n + ".png"))
        for n, (model, _) in models.items():
            with open(os.path.join(mod_dir, n + ".json"), "w") as fh:
                json.dump(model, fh, indent=1)
        print("written to", ASSETS)

    if PREV:
        os.makedirs(PREV, exist_ok=True)
        loader = RD.Loader(os.path.join(ASSETS, "textures"))
        tiles = []
        for n, (model, part) in models.items():
            d = model["display"]["gui"]
            big = RD.render(model, loader, 30, 225, 560, scale=RD.fit_gui(model)[0] * 0.98, tx=d["translation"][0], ty=d["translation"][1])
            views = [RD.render(model, loader, 30, 225 + off, 280, scale=0.7) for off in (90, 180, 270)]
            small = RD.render(model, loader, 30, 225, 64, scale=d["scale"][0], tx=d["translation"][0], ty=d["translation"][1], ss=4)
            sheet = Image.new("RGB", (560 + 280 + 8, 560), (200, 214, 224))
            sheet.paste(big, (0, 0))
            for i, v in enumerate(views[:2]):
                sheet.paste(v, (564, i * 280))
            sheet.paste(small.resize((128, 128), Image.NEAREST), (564 + 140, 280 + 140))
            sheet.save(os.path.join(PREV, n + ".png"))
            tiles.append((n, big, views, small))
        print("previews ->", PREV)


if __name__ == "__main__":
    main()
