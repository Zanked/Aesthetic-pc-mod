"""Tiny crisp pixel-art toolkit (no anti-aliasing). Everything is drawn directly on a 64x64 RGBA grid."""
import math
import numpy as np
from PIL import Image


def H(h, a=255):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


BAYER4 = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) / 16.0 + 1 / 32.0


class Cv:
    def __init__(self, w=64, h=64):
        self.w, self.h = w, h
        self.a = np.zeros((h, w, 4), np.uint8)

    # ---------------------------------------------------------------- basics
    def get(self, x, y):
        if 0 <= x < self.w and 0 <= y < self.h:
            return tuple(int(v) for v in self.a[y, x])
        return (0, 0, 0, 0)

    def px(self, x, y, c, alpha=None):
        x, y = int(x), int(y)
        if not (0 <= x < self.w and 0 <= y < self.h) or c is None:
            return
        if alpha is None or alpha >= 1:
            self.a[y, x] = c if len(c) == 4 else (*c, 255)
            return
        # blend over what is there
        dst = self.a[y, x].astype(float)
        src = np.array(c if len(c) == 4 else (*c, 255), float)
        sa = src[3] / 255.0 * alpha
        da = dst[3] / 255.0
        oa = sa + da * (1 - sa)
        if oa <= 0:
            return
        rgb = (src[:3] * sa + dst[:3] * da * (1 - sa)) / oa
        self.a[y, x] = (*[int(round(v)) for v in rgb], int(round(oa * 255)))

    def rect(self, x0, y0, x1, y1, c, alpha=None):
        for y in range(int(y0), int(y1)):
            for x in range(int(x0), int(x1)):
                self.px(x, y, c, alpha)

    def hline(self, x0, x1, y, c, alpha=None):
        self.rect(x0, y, x1, y + 1, c, alpha)

    def vline(self, x, y0, y1, c, alpha=None):
        self.rect(x, y0, x + 1, y1, c, alpha)

    def _corner_keep(self, i, j, r):
        """is the pixel at offset (i,j) from a corner (0..r-1) inside the rounded corner?"""
        if r <= 0:
            return True
        if r == 1:
            return not (i == 0 and j == 0)
        d = math.hypot(r - i - 0.5, r - j - 0.5)
        return d <= r - 0.1

    def rrect_mask(self, x0, y0, x1, y1, r=2):
        m = np.zeros((self.h, self.w), bool)
        for y in range(int(y0), int(y1)):
            for x in range(int(x0), int(x1)):
                ok = True
                dx = min(x - x0, x1 - 1 - x)
                dy = min(y - y0, y1 - 1 - y)
                if dx < r and dy < r:
                    ok = self._corner_keep(dx, dy, r)
                if ok and 0 <= x < self.w and 0 <= y < self.h:
                    m[y, x] = True
        return m

    def rrect(self, x0, y0, x1, y1, c, r=2, alpha=None):
        m = self.rrect_mask(x0, y0, x1, y1, r)
        self.fill_mask(m, c, alpha)

    def fill_mask(self, m, c, alpha=None):
        ys, xs = np.nonzero(m)
        for y, x in zip(ys, xs):
            self.px(x, y, c, alpha)

    def ell_mask(self, cx, cy, rx, ry):
        m = np.zeros((self.h, self.w), bool)
        for y in range(self.h):
            for x in range(self.w):
                if ((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 <= 1.0:
                    m[y, x] = True
        return m

    def ell(self, cx, cy, rx, ry, c, alpha=None):
        self.fill_mask(self.ell_mask(cx, cy, rx, ry), c, alpha)

    def line(self, x0, y0, x1, y1, c, alpha=None):
        n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
        for i in range(n + 1):
            t = i / max(n, 1)
            self.px(round(x0 + (x1 - x0) * t), round(y0 + (y1 - y0) * t), c, alpha)

    def poly(self, pts, c, alpha=None):
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        for y in range(int(min(ys)), int(max(ys)) + 1):
            for x in range(int(min(xs)), int(max(xs)) + 1):
                if _inside(pts, x + 0.5, y + 0.5):
                    self.px(x, y, c, alpha)

    # ---------------------------------------------------------------- shading
    def dgrad(self, x0, y0, x1, y1, cols, vec=(0.0, 1.0), mask=None, bias=0.0):
        """ordered-dither gradient across a list of colours; vec = direction (dx,dy)"""
        n = len(cols)
        vx, vy = vec
        L = math.hypot(vx, vy) or 1
        vx, vy = vx / L, vy / L
        corners = [(x0, y0), (x1, y0), (x0, y1), (x1, y1)]
        proj = [cx * vx + cy * vy for cx, cy in corners]
        lo, hi = min(proj), max(proj)
        for y in range(int(y0), int(y1)):
            for x in range(int(x0), int(x1)):
                if mask is not None and not mask[y, x]:
                    continue
                t = ((x + 0.5) * vx + (y + 0.5) * vy - lo) / max(hi - lo, 1e-6)
                t = min(max(t + bias, 0), 0.9999)
                p = t * (n - 1)
                i = int(p)
                f = p - i
                self.px(x, y, cols[i + 1] if f > BAYER4[y % 4, x % 4] else cols[i])

    @staticmethod
    def _shift(a, dy, dx):
        out = np.zeros_like(a)
        h, w = a.shape
        ys = slice(max(dy, 0), h + min(dy, 0))
        yd = slice(max(-dy, 0), h + min(-dy, 0))
        xs = slice(max(dx, 0), w + min(dx, 0))
        xd = slice(max(-dx, 0), w + min(-dx, 0))
        out[ys, xs] = a[yd, xd]
        return out

    def outline(self, c, only_where=None, diag=False):
        """1px outline around every opaque pixel (drawn onto transparent neighbours); no wrap-around."""
        a = self.a[..., 3] > 40
        out = np.zeros_like(a)
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)) + (((1, 1), (1, -1), (-1, 1), (-1, -1)) if diag else ()):
            out |= self._shift(a, dy, dx) & ~a
        if only_where is not None:
            out &= only_where
        ys, xs = np.nonzero(out)
        for y, x in zip(ys, xs):
            self.px(x, y, c)

    def outline_sel(self, mul=(0.70, 0.50, 0.40), only_where=None):
        """selective outline: each outline pixel = darkened average colour of the opaque pixels it touches"""
        a = self.a[..., 3] > 40
        h, w = a.shape
        out = []
        for y in range(h):
            for x in range(w):
                if a[y, x]:
                    continue
                cols = []
                for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    yy, xx = y + dy, x + dx
                    if 0 <= yy < h and 0 <= xx < w and a[yy, xx]:
                        cols.append(self.a[yy, xx, :3].astype(float))
                if cols and (only_where is None or only_where[y, x]):
                    m = sum(cols) / len(cols)
                    out.append((x, y, (int(m[0] * mul[0]), int(m[1] * mul[1]), int(m[2] * mul[2]), 255)))
        for x, y, c in out:
            self.a[y, x] = c

    def inner_outline(self, c, mask):
        """recolour the 1px inner border of a mask"""
        e = mask.copy()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            e &= self._shift(mask, dy, dx)
        edge = mask & ~e
        ys, xs = np.nonzero(edge)
        for y, x in zip(ys, xs):
            self.px(x, y, c)

    def speckle(self, mask_rect, amount=14, seed=1, light=(255, 255, 255), dark=(120, 105, 80), alpha=0.35):
        import random
        rnd = random.Random(seed)
        x0, y0, x1, y1 = mask_rect
        for _ in range(amount):
            x = rnd.randrange(int(x0), int(x1))
            y = rnd.randrange(int(y0), int(y1))
            if self.get(x, y)[3] > 200:
                self.px(x, y, light if rnd.random() < 0.5 else dark, alpha)

    # ---------------------------------------------------------------- sprites / text
    def sprite(self, x, y, rows, pal, flip=False):
        for j, row in enumerate(rows):
            if flip:
                row = row[::-1]
            for i, ch in enumerate(row):
                if ch != "." and ch != " ":
                    self.px(x + i, y + j, pal[ch])

    def text(self, x, y, s, c, font=None, shadow=None, gap=1):
        font = font or FONT4
        cx = x
        for ch in s:
            g = font.get(ch)
            if g is None:
                cx += 3
                continue
            if shadow is not None:
                for j, row in enumerate(g):
                    for i, v in enumerate(row):
                        if v == "#":
                            self.px(cx + i + shadow[0], y + j + shadow[1], shadow[2])
            for j, row in enumerate(g):
                for i, v in enumerate(row):
                    if v == "#":
                        self.px(cx + i, y + j, c)
            cx += len(g[0]) + gap
        return cx

    def save(self, path):
        Image.fromarray(self.a, "RGBA").save(path)

    def image(self):
        return Image.fromarray(self.a, "RGBA")


def _inside(pts, x, y):
    ins = False
    n = len(pts)
    j = n - 1
    for i in range(n):
        xi, yi = pts[i]
        xj, yj = pts[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi + 1e-9) + xi:
            ins = not ins
        j = i
    return ins


def text_width(s, font=None, gap=1):
    font = font or FONT4
    w = 0
    for ch in s:
        g = font.get(ch)
        w += (len(g[0]) if g else 3) + gap
    return w - gap


def _g(s):
    return [r for r in s.split("/")]


# 4x5-ish pixel font (variable width, caps only)
FONT4 = {k: _g(v) for k, v in {
    "A": ".##./#..#/####/#..#/#..#",
    "B": "###./#..#/###./#..#/###.",
    "C": ".###/#.../#.../#.../.###",
    "D": "###./#..#/#..#/#..#/###.",
    "E": "###/#../##./#../###",
    "F": "###/#../##./#../#..",
    "G": ".###/#.../#.##/#..#/.###",
    "H": "#..#/#..#/####/#..#/#..#",
    "I": "###/.#./.#./.#./###",
    "J": "..#/..#/..#/#.#/.#.",
    "K": "#..#/#.#./##../#.#./#..#",
    "L": "#.../#.../#.../#.../####",
    "M": "#...#/##.##/#.#.#/#...#/#...#",
    "N": "#...#/##..#/#.#.#/#..##/#...#",
    "O": ".##./#..#/#..#/#..#/.##.",
    "P": "###./#..#/###./#.../#...",
    "Q": ".##./#..#/#..#/#.##/.###",
    "R": "###./#..#/###./#.#./#..#",
    "S": ".###/#.../.##./...#/###.",
    "T": "###/.#./.#./.#./.#.",
    "U": "#..#/#..#/#..#/#..#/.##.",
    "V": "#..#/#..#/#..#/.##./.##.",
    "W": "#...#/#...#/#.#.#/##.##/#...#",
    "X": "#..#/.##./.##./.##./#..#",
    "Y": "#.#/#.#/.#./.#./.#.",
    "Z": "####/..#./.#../#.../####",
    "0": ".##./#..#/#..#/#..#/.##.",
    "1": ".#./##./.#./.#./###",
    "2": "###./...#/.##./#.../####",
    "3": "###./...#/.##./...#/###.",
    "4": "#..#/#..#/####/...#/...#",
    "5": "####/#.../###./...#/###.",
    "6": ".###/#.../###./#..#/.##.",
    "7": "####/...#/..#./.#../.#..",
    "8": ".##./#..#/.##./#..#/.##.",
    "9": ".##./#..#/.###/...#/###.",
    "-": "..../..../###./..../....",
    "x": "..../#.#./.#../#.#./....",
    "+": "..../.#../###./.#../....",
    ".": "../../../../#.",
    "!": "#/#/#/./#",
}.items()}

# 3x5 compact font for micro labels
FONT3 = {k: _g(v) for k, v in {
    "A": ".#./#.#/###/#.#/#.#", "B": "##./#.#/##./#.#/##.", "C": ".##/#../#../#../.##", "D": "##./#.#/#.#/#.#/##.",
    "E": "###/#../##./#../###", "F": "###/#../##./#../#..", "G": ".##/#../#.#/#.#/.##", "H": "#.#/#.#/###/#.#/#.#",
    "I": "###/.#./.#./.#./###", "K": "#.#/#.#/##./#.#/#.#", "L": "#../#../#../#../###", "M": "#.#/###/###/#.#/#.#",
    "N": "##./#.#/#.#/#.#/#.#", "O": ".#./#.#/#.#/#.#/.#.", "P": "##./#.#/##./#../#..", "R": "##./#.#/##./#.#/#.#",
    "S": ".##/#../.#./..#/##.", "T": "###/.#./.#./.#./.#.", "U": "#.#/#.#/#.#/#.#/###", "V": "#.#/#.#/#.#/#.#/.#.",
    "W": "#.#/#.#/###/###/#.#", "X": "#.#/#.#/.#./#.#/#.#", "Y": "#.#/#.#/.#./.#./.#.", "0": "###/#.#/#.#/#.#/###",
    "1": ".#./##./.#./.#./###", "2": "##./..#/.#./#../###", "3": "##./..#/.#./..#/##.", "4": "#.#/#.#/###/..#/..#",
    "5": "###/#../##./..#/##.", "-": ".../.../###/.../...",
}.items()}
