"""Pixel-art textures for the 'Meow' Game-Boy PC case (64x64 each, crisp, hand-shaded).

usage:  python gen_case.py OUTDIR
Layout of the front panel lives in layout.py (shared with gen_model.py).
"""
import os, sys, math, random
import numpy as np
from PIL import Image
from px import Cv, H, BAYER4, FONT4, FONT3, text_width
import layout as L
import cat2

OUTDIR = sys.argv[1] if len(sys.argv) > 1 else "tex_out"
os.makedirs(OUTDIR, exist_ok=True)

# ------------------------------------------------------------------ palette
C1, C2, C3, C4, C5 = H("#FFFEF9"), H("#F8F4EA"), H("#ECE6D7"), H("#D8D0BD"), H("#BDB39C")   # cream plastic: hi..deep shade
O1, O2, O3, O4, O5, OL = H("#FFE0A6"), H("#FFB04A"), H("#FF9524"), H("#E97712"), H("#B95409"), H("#8C3C05")
D1, D2, D3, D4 = H("#24262F"), H("#363945"), H("#555968"), H("#7C8192")
WHITE = H("#FFFFFF")


def save(cv, name):
    cv.save(os.path.join(OUTDIR, name))
    print("saved", name)


def bands(cv, rect, cols, cuts, vec=(0.55, 1.0), mask=None, soft=0.045):
    """flat colour bands along `vec`, with a narrow dithered seam at each cut (0..1)"""
    x0, y0, x1, y1 = rect
    vx, vy = vec
    n = math.hypot(vx, vy)
    vx, vy = vx / n, vy / n
    proj = [x * vx + y * vy for x in (x0, x1) for y in (y0, y1)]
    lo, hi = min(proj), max(proj)
    for y in range(y0, y1):
        for x in range(x0, x1):
            if mask is not None and not mask[y, x]:
                continue
            t = ((x + 0.5) * vx + (y + 0.5) * vy - lo) / (hi - lo)
            i = 0
            for k, c in enumerate(cuts):
                j = (BAYER4[y % 4, x % 4] - 0.5) * 2 * soft
                if t + j > c:
                    i = k + 1
            cv.px(x, y, cols[i])


def paw(cv, x, y, c, c2=None, big=False):
    """tiny paw print, (x,y) = top-left. 5x4 or 9x7"""
    if not big:
        for (dx, dy) in ((1, 0), (3, 0), (0, 1), (4, 1), (1, 2), (2, 2), (3, 2), (1, 3), (2, 3), (3, 3)):
            cv.px(x + dx, y + dy, c)
        cv.px(x + 1, y + 2, c2 or c) if c2 else None
    else:
        rows = ["..#...#..", ".###.###.", ".###.###.", "#.#...#.#", "..#####..", ".#######.", ".#######.", "..#####.."]
        for j, r in enumerate(rows):
            for i, ch in enumerate(r):
                if ch == "#":
                    cv.px(x + i, y + j, c)


# =====================================================================================
# FRONT  (face px 10..54 x rows 0..60)
# =====================================================================================
def make_front():
    cv = Cv()
    fx0, fy0, fx1, fy1 = L.FACE
    # --- body plate
    bands(cv, (fx0, fy0, fx1, fy1), [C1, C2, C3, C4], [0.16, 0.62, 0.9], vec=(0.45, 1.0))
    # top lip with a groove, soft edges
    cv.hline(fx0, fx1, 0, WHITE)
    cv.hline(fx0, fx1, 1, C1)
    cv.hline(fx0, fx1, 3, C4)
    cv.hline(fx0, fx1, 4, C1)
    cv.vline(fx0, 0, fy1, WHITE)
    cv.vline(fx0 + 1, 2, fy1 - 2, C1)
    cv.vline(fx1 - 1, 0, fy1, C4)
    cv.vline(fx1 - 2, 3, fy1 - 2, C3)
    cv.hline(fx0, fx1, fy1 - 1, C5)
    cv.hline(fx0 + 1, fx1 - 1, fy1 - 2, C4)
    cv.hline(fx0 + 1, fx1 - 1, fy1 - 3, C3)
    # tiny embossed screws in the lip corners
    for (sx, sy) in ((12, 2), (51, 2)):
        cv.px(sx, sy, C4)

    # --- bezel (orange frame)
    bx0, by0, bx1, by1 = L.BEZEL
    # soft drop shadow on the body
    cv.rect(bx0 + 1, by1, bx1 + 1, by1 + 1, C4, 0.9)
    cv.vline(bx1, by0 + 1, by1 + 1, C4, 0.9)
    cv.rect(bx0, by0, bx1, by1, O3)
    # vertical gradient (light top -> deep bottom)
    bands(cv, (bx0, by0, bx1, by1), [O2, O3, O4], [0.30, 0.74], vec=(0.0, 1.0), soft=0.07)
    cv.hline(bx0, bx1, by0, O1)                # top highlight
    cv.vline(bx0, by0, by1, O2)               # left highlight
    cv.vline(bx0 + 1, by0 + 1, by1 - 1, O2) if False else None
    cv.hline(bx0, bx1, by1 - 1, O5)           # bottom rim
    cv.vline(bx1 - 1, by0, by1, O5)           # right rim
    cv.px(bx0, by0, O2)
    cv.px(bx1 - 1, by0, O3)
    cv.px(bx0, by1 - 1, O4)
    # perforation dots along the frame (like the real case)
    for x in range(bx0 + 4, bx1 - 3, 2):
        cv.px(x, by0 + 1, O4)
        cv.px(x, by0 + 2, O1) if False else None
        cv.px(x, by1 - 3, O4)
    for y in range(by0 + 5, by1 - 6, 2):
        cv.px(bx0 + 1, y, O4)
        cv.px(bx1 - 2, y, O4)
    # power LED (bottom-right of the bezel)
    cv.px(bx1 - 3, by1 - 3, H("#FFF4C8"))
    cv.px(bx1 - 4, by1 - 3, H("#FFC24A"), 0.7)
    cv.px(bx1 - 2, by1 - 3, H("#FFC24A"), 0.7)

    # --- screen well + artwork
    sx0, sy0, sx1, sy1 = L.SCREEN
    cv.rect(sx0 - 1, sy0 - 1, sx1 + 1, sy1 + 1, O5)
    scene = cat2.screen_scene(sx1 - sx0, sy1 - sy0)
    for yy in range(scene.h):
        for xx in range(scene.w):
            cv.px(sx0 + xx, sy0 + yy, tuple(scene.a[yy, xx]))
    # inner shadow (recessed glass) + glare
    cv.hline(sx0, sx1, sy0, H("#5A2A00"), 0.28)
    cv.hline(sx0, sx1, sy0 + 1, H("#5A2A00"), 0.12)
    cv.vline(sx0, sy0, sy1, H("#5A2A00"), 0.2)
    for yy in range(sy0 + 1, sy1 - 1):
        for xx in range(sx0 + 1, sx1 - 1):
            d = (xx - sx0) + (yy - sy0) * 0.9 - 9
            if 0 <= d < 2.6 and BAYER4[yy % 4, xx % 4] < 0.55:
                cv.px(xx, yy, WHITE, 0.30)
            if 4 <= d < 5.2 and BAYER4[yy % 4, xx % 4] < 0.4:
                cv.px(xx, yy, WHITE, 0.2)

    # --- sticker (black label)
    kx0, ky0, kx1, ky1 = L.STICKER
    cv.rrect(kx0, ky0, kx1, ky1, D1, 1)
    cv.hline(kx0 + 1, kx1 - 1, ky0, D3)
    cv.text(kx0 + 1, ky0 + 1, "MEOW", WHITE)

    # --- d-pad well (recessed disc)
    dcx, dcy = L.DPAD_CENTER
    m_out = cv.ell_mask(dcx, dcy, 8.6, 8.6)
    m_in = cv.ell_mask(dcx + 0.6, dcy + 0.6, 7.6, 7.6)
    cv.fill_mask(m_out, C5)
    cv.fill_mask(m_in, C3)
    # dark top-left lip, bright bottom-right lip
    for y in range(cv.h):
        for x in range(cv.w):
            if m_out[y, x] and not m_in[y, x]:
                cv.px(x, y, C5 if (x - dcx) + (y - dcy) < 0 else WHITE)
    cv.fill_mask(cv.ell_mask(dcx + 0.8, dcy + 0.8, 6.0, 6.0), C2)
    # painted cross under the raised one (so it still looks right on the very edge)
    for (ax0, ay0, ax1, ay1) in (L.DPAD_H, L.DPAD_V):
        cv.rect(ax0, ay0, ax1, ay1, O3)
    hx0, hy0, hx1, hy1 = L.DPAD_H
    vx0, vy0, vx1, vy1 = L.DPAD_V
    # lighting: top/left light, bottom/right dark
    cv.hline(hx0, hx1, hy0, O2)
    cv.hline(hx0, vx0, hy0, O1)
    cv.hline(hx0, hx1, hy1 - 1, O4)
    cv.hline(vx1, hx1, hy1 - 1, O5)
    cv.hline(vx0, vx1, vy0, O1)
    cv.vline(vx0, vy0, vy1, O2)
    cv.vline(vx1 - 1, vy0, vy1, O4)
    cv.hline(vx0, vx1, vy1 - 1, O5)
    cv.vline(hx0, hy0, hy1, O2)
    cv.vline(hx1 - 1, hy0, hy1, O5)
    cv.px(hx0, hy0, O1)
    # centre dimple
    cv.rect(dcx - 1, dcy - 1, dcx + 1, dcy + 1, O4)
    cv.px(dcx - 1, dcy - 1, O5)
    cv.px(dcx, dcy, O2)
    # arrow nicks
    cv.px(dcx, vy0 + 1, O4)
    cv.px(dcx, vy1 - 2, O4)
    cv.px(hx0 + 1, dcy, O4)
    cv.px(hx1 - 2, dcy, O4)

    # --- A/B buttons: recessed capsule + two paw buttons
    ax, ay = L.BTN_A[0] + 3, L.BTN_A[1] + 3
    bx, by = L.BTN_B[0] + 3, L.BTN_B[1] + 3
    cap = np.zeros((cv.h, cv.w), bool)
    capi = np.zeros((cv.h, cv.w), bool)
    for y in range(cv.h):
        for x in range(cv.w):
            # distance to the segment A-B
            vx_, vy_ = ax - bx, ay - by
            t = max(0, min(1, ((x + 0.5 - bx) * vx_ + (y + 0.5 - by) * vy_) / (vx_ * vx_ + vy_ * vy_)))
            d = math.hypot(x + 0.5 - (bx + t * vx_), y + 0.5 - (by + t * vy_))
            if d <= 6.0:
                cap[y, x] = True
            if d <= 5.0:
                capi[y, x] = True
    cv.fill_mask(cap, C5)
    cv.fill_mask(capi, C3)
    for y in range(cv.h):
        for x in range(cv.w):
            if cap[y, x] and not capi[y, x]:
                cv.px(x, y, C5 if (x - 40) + (y - 42) < 0 else WHITE)
    for (cx0, cy0) in (L.BTN_A, L.BTN_B):
        for j, row in enumerate(L.BTN_MASK):
            for i, ch in enumerate(row):
                if ch != "#":
                    continue
                c = O3
                if j <= 1 and i <= 3:
                    c = O2
                if j >= 4 and i >= 3:
                    c = O4
                if (j == 6) or (i == 6 and 2 <= j <= 4) or (j == 5 and i == 5):
                    c = O5
                if (j == 0 and i == 2) or (j == 1 and i == 1) or (j == 2 and i == 0):
                    c = O1
                cv.px(cx0 + i, cy0 + j, c)
        # paw on the button
        pc = H("#FFE9B8")
        for (dx, dy) in ((2, 1), (4, 1), (1, 2), (5, 2), (2, 3), (3, 3), (4, 3), (2, 4), (3, 4), (4, 4)):
            cv.px(cx0 + dx, cy0 + dy, pc)
        cv.px(cx0 + 3, cy0 + 4, H("#FFD08A"))
    # --- ports
    px_, py_ = L.AUDIO
    cv.ell(px_, py_, 2.6, 2.6, C5)
    cv.ell(px_, py_, 1.8, 1.8, D1)
    cv.px(px_ - 1, py_ - 1, D3)
    cv.hline(px_ - 2, px_ + 3, py_ + 3, WHITE, 0.8)
    for (ux0, uy0, ux1, uy1) in (L.USB1, L.USB2):
        cv.rect(ux0, uy0, ux1, uy1, H("#A9A391"))
        cv.hline(ux0, ux1, uy0, H("#D9D4C4"))
        cv.rect(ux0 + 1, uy0 + 1, ux1 - 1, uy1 - 1, D1)
        cv.hline(ux0 + 1, ux1 - 1, uy0 + 2, H("#3D86FF"))
        cv.px(ux0 + 1, uy0 + 2, H("#8DB9FF"))
        cv.hline(ux0, ux1, uy1, WHITE, 0.85)
    # grain
    cv.speckle((fx0 + 2, 6, fx1 - 2, fy1 - 4), 22, seed=3, alpha=0.14)
    # clear anything outside the face
    cv.a[:, :fx0] = 0
    cv.a[:, fx1:] = 0
    cv.a[fy1:, :] = 0
    save(cv, "pc_case_front.png")


# =====================================================================================
# SIDE of the front slab on the glass side (u = 16 - z: slab z .5..2 -> px 56..62)
# =====================================================================================
def make_side():
    cv = Cv()
    x0, x1 = 56, 62
    bands(cv, (x0, 0, x1, 60), [C1, C2, C3], [0.35, 0.8], vec=(1.0, 0.25))
    cv.hline(x0, x1, 0, WHITE)
    cv.hline(x0, x1, 59, C5)
    cv.vline(x1 - 1, 0, 60, C4)
    cv.vline(x0, 0, 60, C1)
    # 13 vent slats: dark slit, soft shadow under it, white lip
    for i in range(13):
        y = 4 + i * 4
        cv.rect(x0 + 1, y, x1 - 1, y + 1, H("#4C463C"))
        cv.rect(x0 + 1, y + 1, x1 - 1, y + 2, H("#9B9384"))
        cv.rect(x0 + 1, y + 2, x1 - 1, y + 3, WHITE)
        cv.px(x0 + 1, y, H("#2B2822"))
    cv.speckle((x0, 2, x1, 58), 10, seed=7, alpha=0.18)
    save(cv, "pc_case_side.png")


# =====================================================================================
# GLASS (u = 16 - z; glass z 2..15 -> px 4..56, rows 0..60)
# =====================================================================================
CAT_SCALE = 0.66
CAT_SHIFT = 3          # px to the right of the window centre


def make_glass():
    cv = Cv()
    FL, FT, FR, FB = 4, 0, 56, 60
    WL, WT, WR, WB = 9, 5, 51, 52                      # window interior

    # --- cat sticker first (sits behind the frame)
    cat = cat2.sitting_cat(scale=CAT_SCALE)
    pad = cat                                           # already padded by 1px, outlines included
    ox = 30 + CAT_SHIFT - int(round(19 * CAT_SCALE)) - 1   # head centred in the window, nudged right
    oy = WB - pad.h + 1                                 # sits on the window sill
    for y in range(pad.h):
        for x in range(pad.w):
            if pad.a[y, x, 3]:
                cv.px(ox + x, oy + y, tuple(pad.a[y, x]))
    # soft pale 'sticker' base behind the cat so it reads on dark backgrounds
    base = cv.a[..., 3] > 0

    # --- window: faint blue tint + diagonal reflections
    for y in range(WT, WB):
        for x in range(WL, WR):
            if cv.a[y, x, 3] == 0:
                cv.px(x, y, H("#BFE6F5", 26))
    for y in range(WT, WB):
        for x in range(WL, WR):
            d = (x - WL) + (y - WT) * 1.0
            if cv.a[y, x, 3] < 60:
                if 12 <= d < 15:
                    cv.px(x, y, WHITE, 0.34) if BAYER4[y % 4, x % 4] < 0.8 else None
                if 19 <= d < 20.5:
                    cv.px(x, y, WHITE, 0.26)
    # sparkles
    for (sx, sy, big) in ((14, 12, 1), (45, 10, 1), (12, 31, 0), (47, 40, 0), (16, 45, 0)):
        cv.px(sx, sy, WHITE)
        cv.px(sx - 1, sy, WHITE, 0.7)
        cv.px(sx + 1, sy, WHITE, 0.7)
        cv.px(sx, sy - 1, WHITE, 0.7)
        cv.px(sx, sy + 1, WHITE, 0.7)
        if big:
            cv.px(sx - 2, sy, WHITE, 0.35)
            cv.px(sx + 2, sy, WHITE, 0.35)
            cv.px(sx, sy - 2, WHITE, 0.35)
            cv.px(sx, sy + 2, WHITE, 0.35)

    # --- orange printed frame (drawn over the cat's edges)
    frame = np.zeros((cv.h, cv.w), bool)
    outer = cv.rrect_mask(FL, FT, FR, FB, 3)
    inner = np.zeros_like(outer)
    inner[WT:WB, WL:WR] = True
    frame = outer & ~inner
    # base + diagonal 'print' pattern + paws
    for y in range(cv.h):
        for x in range(cv.w):
            if not frame[y, x]:
                continue
            c = O3
            if (x + y) % 8 in (0, 1):
                c = O2
            if (x - y) % 16 == 0:
                c = O4
            cv.px(x, y, c)
    # tiny paw prints in the side borders
    for py in (9, 21, 33, 45):
        for (px_, c) in ((FL + 1, O1), (FR - 4, O1)):
            for (dx, dy) in ((1, 0), (0, 1), (2, 1), (1, 2)):
                if frame[py + dy, px_ + dx]:
                    cv.px(px_ + dx, py + dy, c, 0.85)
    # highlights / depth
    cv.inner_outline(OL, outer)
    inner_edge = cv.rrect_mask(WL - 1, WT - 1, WR + 1, WB + 1, 2)
    for y in range(cv.h):
        for x in range(cv.w):
            if inner_edge[y, x] and not inner[y, x]:
                cv.px(x, y, O1)               # cream line right around the window
    cv.hline(FL + 3, FR - 3, FT + 1, O1, 0.8)
    cv.vline(FL + 1, FT + 3, FB - 3, O2)
    # frame bottom text strip
    cv.hline(FL + 2, FR - 2, WB + 1, O4, 0.9)
    tx = FL + (FR - FL - text_width("MEOW MEOW")) // 2
    cv.text(tx, WB + 3, "MEOW MEOW", H("#FFF2CF"), shadow=(0, 1, OL))
    # corner screws
    for (sx, sy) in ((FL + 2, FT + 2), (FR - 3, FT + 2), (FL + 2, FB - 3), (FR - 3, FB - 3)):
        cv.px(sx, sy, O5)
        cv.px(sx - 1, sy - 1, O1) if False else None
    save(cv, "pc_case_glass.png")



# =====================================================================================
# TOP  (region px 10..54 x rows 8..60; picture is drawn as seen from the glass side, then mapped)
#   picture: 44 rows (x: west edge on top) x 52 cols (z: back on the left, front on the right)
# =====================================================================================
def make_top():
    P = Cv(52, 44)
    P.rect(0, 0, 52, 44, C2)
    bands(P, (0, 0, 52, 44), [C1, C2, C3], [0.18, 0.86], vec=(0.6, 1.0))
    # diagonal engraved hatch (very faint)
    for y in range(44):
        for x in range(52):
            if (x + y) % 6 == 0:
                P.px(x, y, C3, 0.55)
    # inset border
    P.hline(1, 51, 1, WHITE)
    P.hline(1, 51, 42, C4)
    P.vline(1, 1, 43, WHITE)
    P.vline(50, 1, 43, C4)
    # headline: SHINE UP / YOUR STYLE / MEOW  (orange with a dark-orange drop shadow, slight italic by row shear)
    def line(text, x, y, col):
        tmp = Cv(52, 44)
        tmp.text(x, y, text, col, shadow=(1, 1, OL))
        for yy in range(44):
            for xx in range(52):
                if tmp.a[yy, xx, 3]:
                    sh = (yy - y) // 3
                    P.px(xx + (1 if sh == 0 else 0), yy, tuple(tmp.a[yy, xx]))
    line("SHINE UP", 5, 5, O3)
    line("YOUR STYLE", 3, 14, O3)
    line("MEOW", 5, 23, O2)
    # two sporty stripes
    P.rect(4, 33, 34, 35, O3)
    P.hline(4, 34, 33, O2)
    P.rect(4, 37, 34, 39, O3)
    P.hline(4, 34, 37, O2)
    P.hline(4, 34, 35, O5, 0.6)
    P.hline(4, 34, 39, O5, 0.6)
    # target badge with a paw
    bcx, bcy = 42, 34
    P.ell(bcx, bcy, 6.6, 6.6, O5)
    P.ell(bcx, bcy, 6.0, 6.0, O3)
    P.ell(bcx, bcy, 4.6, 4.6, C1)
    P.ell(bcx, bcy, 3.6, 3.6, O3)
    P.ell(bcx, bcy, 2.8, 2.8, C1)
    paw(P, bcx - 2, bcy - 2, O3)
    # corner screws
    for (sx, sy) in ((3, 3), (48, 3), (3, 40), (48, 40)):
        P.px(sx, sy, C5)
        P.px(sx - 1, sy - 1, C1) if False else None
    # ---- map picture -> texture:  region[z_idx, x_idx] = pic.T[51 - z_idx, x_idx]
    pic_t = np.transpose(P.a, (1, 0, 2))[::-1, :, :]          # (52 z) x (44 x) x 4
    cv = Cv()
    cv.a[8:60, 10:54] = pic_t
    # front end (z .5..2) is a separate cream patch in the model; keep a bevel on the picture's front edge
    save(cv, "pc_case_top.png")


# =====================================================================================
# WEST (solid side, viewed from outside: left = front) px 12..60 x rows 0..60
# =====================================================================================
def make_west():
    cv = Cv()
    x0, x1 = 12, 60
    bands(cv, (x0, 0, x1, 60), [C1, C2, C3], [0.15, 0.85], vec=(0.7, 1.0))
    # top/bottom edge bevels (rows 0..4 / 58..60) + back edge (px 56..60)
    cv.rect(x0, 0, x1, 4, C1)
    cv.hline(x0, x1, 0, WHITE)
    cv.hline(x0, x1, 3, C3)
    cv.rect(x0, 58, x1, 60, C4)
    cv.hline(x0, x1, 59, C5)
    cv.vline(56, 0, 60, C3)
    cv.vline(57, 4, 58, C2)
    # recessed inset panel
    px0, py0, px1, py1 = 16, 7, 55, 53
    m = cv.rrect_mask(px0, py0, px1, py1, 3)
    cv.fill_mask(m, C3)
    cv.inner_outline(C5, m)
    for y in range(py0, py1):
        for x in range(px0, px1):
            if m[y, x] and (y - py0 < 2 or x - px0 < 2) and not (x - px0 < 1 and y - py0 < 1):
                pass
    cv.hline(px0 + 3, px1 - 3, py1, WHITE)            # lit lower lip
    bands(cv, (px0 + 1, py0 + 1, px1 - 1, py1 - 1), [C2, C3, C4], [0.45, 0.9], vec=(0.5, 1.0), mask=m)
    cv.inner_outline(C4, m)
    # vent slots
    for i in range(6):
        y = 12 + i * 3
        cv.rrect(23, y, 49, y + 2, D2, 1)
        cv.hline(24, 48, y, D1)
        cv.hline(23, 49, y + 2, WHITE)
    # big paw print: 4 toes + pad, lit from the top-left (rim light / rim shade from neighbours)
    pm = np.zeros((cv.h, cv.w), bool)
    ox0, oy0 = 29, 32
    for (tx, ty, rx, ry) in ((1.8, 6.4, 1.8, 2.3), (5.0, 2.6, 1.9, 2.5), (10.0, 2.6, 1.9, 2.5), (13.2, 6.4, 1.8, 2.3), (7.5, 11.4, 4.7, 3.3)):
        pm |= cv.ell_mask(ox0 + tx, oy0 + ty, rx, ry)
    ys, xs = np.nonzero(pm)
    for y, x in zip(ys, xs):
        c = O3
        if not pm[y - 1, x] or not pm[y, x - 1]:
            c = O2
        if not pm[y + 1, x] or not pm[y, x + 1]:
            c = O4
        cv.px(x, y, c)
    cv.px(ox0 + 5, oy0 + 10, O1)
    cv.px(ox0 + 6, oy0 + 10, O1)
    # accent stripe
    cv.rect(px0 + 3, 48, px1 - 3, 50, O3)
    cv.hline(px0 + 3, px1 - 3, 48, O2)
    cv.hline(px0 + 3, px1 - 3, 50, O5, 0.5)
    # screws
    for (sx, sy) in ((px0 + 3, py0 + 3), (px1 - 4, py0 + 3), (px0 + 3, py1 - 4), (px1 - 4, py1 - 4)):
        cv.px(sx, sy, C5)
        cv.px(sx + 1, sy + 1, WHITE, 0.8)
    cv.speckle((x0, 4, x1, 58), 26, seed=11, alpha=0.14)
    save(cv, "pc_case_west.png")


# =====================================================================================
# BACK (south face, viewed from behind: u = x) px 10..54 x rows 0..60
# =====================================================================================
def make_back():
    cv = Cv()
    fx0, fx1 = 10, 54
    bands(cv, (fx0, 0, fx1, 60), [C1, C2, C3, C4], [0.16, 0.62, 0.92], vec=(0.45, 1.0))
    cv.hline(fx0, fx1, 0, WHITE)
    cv.vline(fx0, 0, 60, WHITE)
    cv.vline(fx1 - 1, 0, 60, C4)
    cv.hline(fx0, fx1, 59, C5)
    cv.hline(fx0 + 1, fx1 - 1, 58, C4)
    # I/O shield (top-left): dark plate with tiny coloured ports
    cv.rrect(12, 5, 33, 20, D1, 2)
    cv.inner_outline(D3, cv.rrect_mask(12, 5, 33, 20, 2))
    cv.rect(14, 7, 31, 18, D2)
    for i in range(2):                                    # usb pairs
        cv.rect(15 + i * 5, 8, 19 + i * 5, 11, D1)
        cv.hline(15 + i * 5, 19 + i * 5, 9, H("#3D86FF"))
    cv.rect(25, 8, 30, 12, D1)                            # lan
    cv.px(26, 9, H("#8EE08A"))
    cv.px(29, 9, H("#FFB04A"))
    for i, col in enumerate((H("#7FD66B"), H("#E86AA6"), H("#58DCF6"))):   # audio jacks
        cv.ell(16.5 + i * 4, 15, 1.6, 1.6, D1)
        cv.px(16 + i * 4, 14, col)
        cv.px(17 + i * 4, 15, col)
    cv.hline(26, 30, 15, D3)
    cv.hline(26, 30, 16, D3)
    # rear fan (top-right): grille ring + orange blades
    fcx, fcy = 44, 12
    cv.ell(fcx, fcy, 8.6, 8.6, C5)
    cv.ell(fcx, fcy, 8.0, 8.0, D1)
    cv.ell(fcx, fcy, 6.6, 6.6, D2)
    for a in range(6):
        ang = a * math.pi / 3 + 0.35
        for r in range(1, 7):
            x = fcx + math.cos(ang) * r + math.cos(ang + 1.45) * r * 0.28
            y = fcy + math.sin(ang) * r + math.sin(ang + 1.45) * r * 0.28
            cv.px(int(x), int(y), O3 if r < 5 else O2)
            cv.px(int(x), int(y) + 1, O4) if r in (3, 4) else None
    cv.ell(fcx, fcy, 2.0, 2.0, O5)
    cv.ell(fcx, fcy, 1.3, 1.3, O2)
    cv.px(fcx - 1, fcy - 1, O1)
    # grille rings
    for a in range(0, 360, 20):
        x = fcx + math.cos(math.radians(a)) * 7.4
        y = fcy + math.sin(math.radians(a)) * 7.4
        cv.px(int(x), int(y), D4)
    # expansion slots (middle)
    for i in range(5):
        y = 23 + i * 4
        cv.rrect(13, y, 51, y + 3, D1, 1)
        cv.hline(14, 50, y, D3)
        cv.hline(14, 50, y + 3, WHITE, 0.9)
        cv.px(15, y + 1, C5)
        cv.px(49, y + 1, C5)
    # PSU bay (bottom): big dark rounded rect with a fan grille, socket, switch
    cv.rrect(12, 43, 52, 57, D1, 3)
    cv.inner_outline(D3, cv.rrect_mask(12, 43, 52, 57, 3))
    cv.ell(26, 50, 6.4, 6.4, D4)
    cv.ell(26, 50, 5.6, 5.6, D2)
    cv.ell(26, 50, 4.4, 4.4, D1)
    for r in (2, 4):
        for a in range(0, 360, 24 if r == 4 else 40):
            cv.px(int(26 + math.cos(math.radians(a)) * r), int(50 + math.sin(math.radians(a)) * r), D4)
    cv.ell(26, 50, 1.5, 1.5, O3)
    cv.px(25, 49, O1)
    cv.rect(38, 46, 49, 52, D2)                           # power socket
    cv.hline(38, 49, 46, D3)
    cv.rect(40, 48, 42, 50, D1)
    cv.rect(44, 48, 46, 50, D1)
    cv.rect(41, 52, 46, 54, D1) if False else None
    cv.rect(39, 54, 47, 56, D3)                           # rocker switch
    cv.rect(42, 54, 44, 56, O3)
    # corner screws
    for (sx, sy) in ((12, 2), (51, 2), (12, 57), (51, 57)):
        cv.px(sx, sy, C5)
        cv.px(sx + 1, sy + 1, WHITE, 0.8) if False else None
    cv.speckle((fx0 + 2, 2, fx1 - 2, 58), 22, seed=5, alpha=0.14)
    save(cv, "pc_case_back.png")


# =====================================================================================
# TRAY (inner face of the glass-side wall, seen through the glass: u = (16 - z) * 4) px 8..56 x rows 4..58
# standoff positions must match STANDOFFS in gen_model.py
# =====================================================================================
def make_tray():
    cv = Cv()
    x0, y0, x1, y1 = 8, 4, 56, 58
    bands(cv, (x0, y0, x1, y1), [H("#E4DFD2"), H("#D6D0C1"), H("#C6BFAE")], [0.35, 0.78], vec=(0.5, 1.0))
    # brushed-metal streaks
    rnd = random.Random(21)
    for _ in range(70):
        x = rnd.randrange(x0, x1)
        yy = rnd.randrange(y0, y1 - 5)
        n = rnd.randrange(3, 8)
        for k in range(n):
            cv.px(x, yy + k, WHITE if rnd.random() < 0.5 else C5, 0.22)
    cv.hline(x0, x1, y0, WHITE)
    cv.vline(x0, y0, y1, WHITE, 0.8)
    cv.hline(x0, x1, y1 - 1, C5)
    # motherboard footprint (subtle raised plate)
    cv.rrect(14, 8, 50, 54, H("#CFC9B9"), 2)
    cv.inner_outline(H("#B3AC9A"), cv.rrect_mask(14, 8, 50, 54, 2))
    # CPU cut-out
    cv.rrect(22, 16, 40, 34, D1, 2)
    cv.inner_outline(D3, cv.rrect_mask(22, 16, 40, 34, 2))
    cv.rect(24, 18, 38, 32, D2)
    cv.hline(24, 38, 18, D3)
    cv.text(26, 36, "CPU", H("#8E8777"), font=FONT3)
    # cable-pass slots with little grommets
    for (sx0, sy0, sx1, sy1) in ((11, 12, 14, 40), (47, 9, 51, 18), (47, 31, 51, 41)):
        cv.rrect(sx0, sy0, sx1, sy1, D1, 1)
        cv.hline(sx0, sx1, sy0, D3)
        cv.hline(sx0 - 1, sx1 + 1, sy1, WHITE, 0.8)
    # vent grid (top-left)
    for j in range(2):
        for i in range(6):
            cv.rect(16 + i * 3, 5 + j * 2, 18 + i * 3, 6 + j * 2, D2)
    # standoff holes (u=(16-z)*4, row=(16-y)*4)
    for (u, v) in ((44, 44), (44, 28), (44, 12), (32, 44), (32, 12), (20, 44), (20, 28), (20, 12)):
        cv.ell(u, v, 2.4, 2.4, D2)
        cv.ell(u, v, 1.6, 1.6, D1)
        cv.px(u - 1, v - 1, D3)
    # cat paw silk-screen bottom-left
    paw(cv, 12, 46, O3)
    cv.px(13, 48, O1)
    # orange trim at the front edge (visible through the narrow slab gap)
    cv.vline(53, y0, y1, O3)
    cv.vline(54, y0, y1, O4)
    cv.vline(52, y0, y1, O2)
    cv.speckle((x0, y0, x1, y1), 30, seed=9, alpha=0.12)
    save(cv, "pc_case_tray.png")


# =====================================================================================
# MISC patches (4x4 grid of 16x16): flat colours with a hint of texture
# =====================================================================================
def make_misc():
    cv = Cv()
    def patch(gx, gy, base, hi=None, lo=None, grain=0.0, seed=1):
        x0, y0 = gx * 16, gy * 16
        cv.rect(x0, y0, x0 + 16, y0 + 16, base)
        r = random.Random(seed)
        if hi is not None:
            cv.hline(x0, x0 + 16, y0, hi)
            cv.vline(x0, y0, y0 + 16, hi)
        if lo is not None:
            cv.hline(x0, x0 + 16, y0 + 15, lo)
            cv.vline(x0 + 15, y0, y0 + 16, lo)
        for _ in range(int(grain * 40)):
            x, y = x0 + r.randrange(2, 14), y0 + r.randrange(2, 14)
            cv.px(x, y, WHITE if r.random() < 0.5 else (lo or base), 0.35)
    patch(0, 0, C2, WHITE, C3, 0.5, 1)           # P_CREAM
    patch(1, 0, C4, C3, C5, 0.4, 2)              # P_CREAM_D
    patch(2, 0, O3, O2, O4, 0.4, 3)              # P_OR
    patch(3, 0, O4, O3, O5, 0.3, 4)              # P_OR_D
    patch(0, 1, D1, D2, D1, 0.2, 5)              # black
    patch(1, 1, H("#BDB6A4"), H("#CFC9B9"), H("#A29B88"), 0.5, 6)   # floor
    patch(2, 1, H("#D2AE55"), H("#EBCB7A"), H("#A98A38"), 0.4, 7)   # brass
    patch(3, 1, O1, WHITE, O2, 0.2, 8)           # orange highlight
    patch(0, 2, D2, D3, D1, 0.2, 9)              # rubber
    patch(1, 2, C3, C2, C4, 0.4, 10)             # inner cream
    patch(2, 2, O5, O4, OL, 0.2, 11)             # screen edge
    save(cv, "pc_case_misc.png")


if __name__ == "__main__":
    for fn in (make_front, make_side, make_glass, make_top, make_west, make_back, make_tray, make_misc):
        fn()
