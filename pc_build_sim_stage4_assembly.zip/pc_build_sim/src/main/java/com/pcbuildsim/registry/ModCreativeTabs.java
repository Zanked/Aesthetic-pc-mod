package com.pcbuildsim.registry;

import com.pcbuildsim.PcBuildSim;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PcBuildSim.MOD_ID);

    public static final Supplier<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.pcbuildsim.main"))
            .icon(() -> new ItemStack(ModItems.PC_CASE.get()))
            .displayItems((params, output) -> {
                output.accept(ModItems.PC_CASE.get());
                output.accept(ModItems.MOTHERBOARD.get());
                output.accept(ModItems.CPU.get());
                output.accept(ModItems.CPU_COOLER.get());
                output.accept(ModItems.GPU.get());
                output.accept(ModItems.RAM.get());
                output.accept(ModItems.SSD_M2.get());
                output.accept(ModItems.SSD_SATA.get());
                output.accept(ModItems.HDD.get());
                output.accept(ModItems.PSU.get());
            })
            .build());
}
