package com.pcbuildsim.registry;

import com.pcbuildsim.PcBuildSim;
import com.pcbuildsim.block.PcCaseBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(PcBuildSim.MOD_ID);

    public static final DeferredBlock<PcCaseBlock> PC_CASE = BLOCKS.registerBlock(
            "pc_case",
            PcCaseBlock::new,
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.SNOW)
                    .strength(1.5F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()
                    // RGB-подсветка: светится, когда установлена ОЗУ (3-я деталь) и дальше
                    .lightLevel(state -> state.getValue(PcCaseBlock.STAGE) >= 3 ? 5 : 0));
}
