package com.pcbuildsim.registry;

import com.pcbuildsim.PcBuildSim;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(PcBuildSim.MOD_ID);

    // --- корпус ---
    public static final DeferredItem<BlockItem> PC_CASE = ITEMS.registerSimpleBlockItem("pc_case", ModBlocks.PC_CASE);

    // --- комплектующие (этап 2) ---
    public static final DeferredItem<Item> MOTHERBOARD = part("motherboard");
    public static final DeferredItem<Item> CPU = part("cpu");
    public static final DeferredItem<Item> CPU_COOLER = part("cpu_cooler");
    public static final DeferredItem<Item> GPU = part("gpu");
    public static final DeferredItem<Item> RAM = part("ram");
    public static final DeferredItem<Item> SSD_M2 = part("ssd_m2");
    public static final DeferredItem<Item> SSD_SATA = part("ssd_sata");
    public static final DeferredItem<Item> HDD = part("hdd");
    public static final DeferredItem<Item> PSU = part("psu");

    private static DeferredItem<Item> part(String name) {
        return ITEMS.registerSimpleItem(name, new Item.Properties().stacksTo(16));
    }
}
