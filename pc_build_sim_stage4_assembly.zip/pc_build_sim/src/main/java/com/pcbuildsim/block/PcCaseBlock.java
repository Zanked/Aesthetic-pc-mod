package com.pcbuildsim.block;

import com.mojang.serialization.MapCodec;
import com.pcbuildsim.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Корпус ПК в стиле Game Boy. Лицевая сторона (экран + кнопки) смотрит на игрока,
 * стеклянная боковина — слева от лица.
 *
 * Сборка: свойство STAGE (0..9) = сколько деталей уже установлено. Детали ставятся строго по порядку
 * (ПКМ нужной деталью по корпусу), последнюю установленную деталь можно снять Shift+ПКМ пустой рукой.
 * Внешний вид каждой стадии задаёт blockstates/pc_case.json (multipart), его генерирует tools/texture_gen/gen_install.py.
 */
public class PcCaseBlock extends HorizontalDirectionalBlock {
    public static final MapCodec<PcCaseBlock> CODEC = simpleCodec(PcCaseBlock::new);

    /** Число этапов сборки (деталей). */
    public static final int PART_COUNT = 9;
    /** 0 = пустой корпус, PART_COUNT = ПК собран полностью. */
    public static final IntegerProperty STAGE = IntegerProperty.create("stage", 0, PART_COUNT);

    // модель (K=0.65 в gen_model.py) занимает X 4.78..11.22, Y 0..9.36, Z 2.8..13.2 (лицом на север).
    // Пропорции: стеклянная боковина шире, чем выше (см. SX/SY/Z_BACK_NEW в tools/texture_gen/gen_model.py)
    private static final VoxelShape SHAPE_NORTH = Block.box(4.78, 0, 2.8, 11.22, 9.36, 13.2);
    private static final VoxelShape SHAPE_SOUTH = Block.box(4.78, 0, 2.8, 11.22, 9.36, 13.2);
    private static final VoxelShape SHAPE_EAST = Block.box(2.8, 0, 4.78, 13.2, 9.36, 11.22);
    private static final VoxelShape SHAPE_WEST = Block.box(2.8, 0, 4.78, 13.2, 9.36, 11.22);

    public PcCaseBlock(BlockBehaviour.Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(STAGE, 0));
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, STAGE);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite()).setValue(STAGE, 0);
    }

    // ------------------------------------------------------------------ порядок сборки

    /** Деталь, которая устанавливается на этапе index (0..PART_COUNT-1). Порядок сборки меняется только здесь + в ORDER в gen_install.py. */
    public static Item partForIndex(int index) {
        return switch (index) {
            case 0 -> ModItems.MOTHERBOARD.get();
            case 1 -> ModItems.CPU.get();
            case 2 -> ModItems.RAM.get();
            case 3 -> ModItems.SSD_M2.get();
            case 4 -> ModItems.CPU_COOLER.get();
            case 5 -> ModItems.PSU.get();
            case 6 -> ModItems.GPU.get();
            case 7 -> ModItems.SSD_SATA.get();
            default -> ModItems.HDD.get();
        };
    }

    private static boolean isAnyPart(ItemStack stack) {
        for (int i = 0; i < PART_COUNT; i++) {
            if (stack.is(partForIndex(i))) {
                return true;
            }
        }
        return false;
    }

    private static Component nameOf(Item item) {
        return Component.translatable(item.getDescriptionId());
    }

    private static void say(Player player, Component message) {
        player.displayClientMessage(message, true); // над хотбаром
    }

    // ------------------------------------------------------------------ взаимодействие

    /** ПКМ деталью в руке: ставим, если это именно та деталь, которая нужна сейчас. */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player,
                                              InteractionHand hand, BlockHitResult hit) {
        if (!isAnyPart(stack)) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        int stage = state.getValue(STAGE);
        if (stage >= PART_COUNT) {
            if (!level.isClientSide) {
                say(player, Component.translatable("msg.pcbuildsim.complete"));
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        Item needed = partForIndex(stage);
        if (!stack.is(needed)) {
            if (!level.isClientSide) {
                say(player, Component.translatable("msg.pcbuildsim.wrong_part", nameOf(needed)));
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!level.isClientSide) {
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
            BlockState next = state.setValue(STAGE, stage + 1);
            level.setBlock(pos, next, Block.UPDATE_ALL);
            level.playSound(null, pos, next.getSoundType().getPlaceSound(), SoundSource.BLOCKS, 1.0F, 1.1F);
            if (stage + 1 >= PART_COUNT) {
                say(player, Component.translatable("msg.pcbuildsim.done"));
            } else {
                say(player, Component.translatable("msg.pcbuildsim.installed", nameOf(needed), stage + 1, PART_COUNT,
                        nameOf(partForIndex(stage + 1))));
            }
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** Пустая рука (или чужой предмет): Shift+ПКМ снимает последнюю деталь, обычный ПКМ подсказывает, что ставить дальше. */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        int stage = state.getValue(STAGE);
        if (!level.isClientSide) {
            if (player.isShiftKeyDown() && stage > 0) {
                Item removed = partForIndex(stage - 1);
                BlockState prev = state.setValue(STAGE, stage - 1);
                level.setBlock(pos, prev, Block.UPDATE_ALL);
                level.playSound(null, pos, prev.getSoundType().getBreakSound(), SoundSource.BLOCKS, 0.8F, 1.3F);
                ItemStack back = new ItemStack(removed);
                if (!player.getInventory().add(back)) {
                    player.drop(back, false);
                }
                say(player, Component.translatable("msg.pcbuildsim.removed", nameOf(removed)));
            } else if (stage >= PART_COUNT) {
                say(player, Component.translatable("msg.pcbuildsim.complete"));
            } else {
                say(player, Component.translatable("msg.pcbuildsim.next", stage, PART_COUNT, nameOf(partForIndex(stage))));
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** При поломке корпуса установленные детали выпадают (в креативе — нет). */
    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && !player.isCreative()) {
            int stage = state.getValue(STAGE);
            for (int i = 0; i < stage; i++) {
                Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, new ItemStack(partForIndex(i)));
            }
        }
        return super.playerWillDestroy(level, pos, state, player);
    }

    // ------------------------------------------------------------------ форма

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return switch (state.getValue(FACING)) {
            case SOUTH -> SHAPE_SOUTH;
            case EAST -> SHAPE_EAST;
            case WEST -> SHAPE_WEST;
            default -> SHAPE_NORTH;
        };
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }
}
