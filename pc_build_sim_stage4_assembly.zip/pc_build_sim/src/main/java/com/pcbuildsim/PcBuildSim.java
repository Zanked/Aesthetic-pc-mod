package com.pcbuildsim;

import com.pcbuildsim.registry.ModBlocks;
import com.pcbuildsim.registry.ModCreativeTabs;
import com.pcbuildsim.registry.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

/**
 * PC Build Simulator — главный класс мода.
 * Этап 1: корпус ПК. Новые этапы (материнка, процессор, видеокарта...) добавляются
 * в registry/ModBlocks + registry/ModItems по тому же шаблону.
 */
@Mod(PcBuildSim.MOD_ID)
public class PcBuildSim {
    public static final String MOD_ID = "pcbuildsim";

    public PcBuildSim(IEventBus modBus) {
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
