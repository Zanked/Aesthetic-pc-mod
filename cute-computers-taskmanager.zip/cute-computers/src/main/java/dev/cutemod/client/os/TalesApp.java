package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.IntUnaryOperator;

/**
 * Fairy Tales: a shelf with twelve books (Andersen, Grimm, Perrault, Pushkin, a Russian folk tale). Open one and read it
 * like a real book: two pages, a picture on every scene, and the pages turn. Click the right page (or press the right arrow)
 * to turn forward, the left page (left arrow) to go back. Reading a tale to its end for the first time pays 2 coins.
 * <p>
 * The text never leaves the page: it is cut into lines by the real width of the font ({@link CuteFont#width}), and the
 * lines are cut into pages by the height of the page. A scene that is longer than its spread simply goes on over the next
 * pages, so a long translation or a big font only makes the book thicker. Saved: "tales" (finished tales), "tales_mark"
 * (where you stopped) and "tales_sticker" (the Storyteller sticker of the Sticker Book was given).
 * <p>
 * The books are collected: two are on the shelf from the start, the others are found as pages in other apps or bought ({@link TaleBooks}).
 * The shelf shows an empty place with the pages found so far; a click opens a small card with the price.
 * <p>
 * Cosiness: page, book and shelf sounds and a quiet background for every scene with a music box lullaby ({@link TaleAudio});
 * a wooden table, a warm lamp, a candle, dust in the light, and at night (by the time of the Minecraft world) a blue night with
 * the moon in the window ({@link ReadingRoom}); pages that bend and cast a shadow, the thickness of the book, a ribbon bookmark;
 * a drop cap and flourishes; living pictures ({@link BookArt}); a seal on every tale that is read and a sticker for all twelve.
 */
public class TalesApp extends KitApp {
    // the open book: two pages and a spine
    private static final int BX = 8, BY = 18, BW = 284, BH = 140, PW = 138, SPINE = 8;
    private static final int TX = 9, TW = 120, LINE = 9;                  // text: margin, width, line height
    private static final int TOP = BY + 8, BOTTOM = BY + BH - 14;          // where the text of a page may be
    private static final int PIC_Y = TOP, PIC_H = BookArt.H;
    private static final int LEFT_LINES = (BOTTOM - (PIC_Y + PIC_H + 4)) / LINE;   // under the picture
    private static final int FULL_LINES = (BOTTOM - TOP) / LINE;                   // a whole page
    private static final int FLIP = 16;                                    // ticks of a page turn
    private static final double CURL = 0.9;                                // how much a turning page bends (radians)
    private static final int LIFT = 5;                                     // how much its free edge rises towards the reader
    private static final int DROP_LINES = 2;                               // the drop cap is two lines high
    private static final int PAPER = 0xFFFFF8E8, INK = 0xFF4A3A3A, ORNAMENT = 0xFFD9B35A;
    private static final int REWARD = 2;

    /** One open book spread: the left and the right page. kind 0 = the title, 1 = the story, 2 = the end. */
    static final class Spread {
        final int kind, scene;                                       // scene: the picture on the left page, -1 = none
        final List<String> left = new ArrayList<>(), right = new ArrayList<>();
        char cap;                                                    // the drop cap of the tale (the first spread only), 0 = none
        int capW;
        boolean endL, endR;                                          // the scene ends on the left / on the right page

        Spread(int kind, int scene) { this.kind = kind; this.scene = scene; }
    }

    private int tale = -1;                                           // the open book, -1 = the shelf
    private final List<Spread> spreads = new ArrayList<>();
    private String builtKey = "";
    private int cur, flipTo = -1, flipT, hover = -1, knockT = -1;
    private int buying = -1, panelMsgT;                              // the card of a book that is not on the shelf yet (-1 = none)
    private String panelMsg = "";
    private boolean justEarned, justSticker;
    private final Set<String> done = new LinkedHashSet<>();
    private String markId = "";
    private int markSpread;
    private boolean loaded;

    @Override protected int accent() { return 0xFFC8905A; }

    @Override protected String id() { return "tales"; }

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        load();
    }

    private void load() {
        loaded = true;
        done.clear();
        String s = Store.read("tales");
        if (s != null) for (String id : s.split(",")) if (find(id) >= 0) done.add(id);
        String m = Store.read("tales_mark");
        if (m != null && m.contains(":")) {
            try {
                markId = m.substring(0, m.indexOf(':'));
                markSpread = Integer.parseInt(m.substring(m.indexOf(':') + 1));
            } catch (NumberFormatException e) {
                markId = "";
            }
        }
        if (Store.ready()) award();                                  // all twelve were read before the sticker existed
    }

    private static int find(String id) {
        for (int i = 0; i < Tales.ALL.size(); i++) if (Tales.ALL.get(i).id().equals(id)) return i;
        return -1;
    }

    /** All twelve tales are read: the Storyteller sticker goes to the Sticker Book (once). */
    private boolean award() {
        if (done.size() < Tales.ALL.size() || "1".equals(Store.read("tales_sticker"))) return false;
        Store.write("tales_sticker", "1");
        Progress.toast("cutemod.toast.tales_sticker");
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.5F, 0.6F);
        return true;
    }

    // ---------- laying the text out ----------
    /** The text cut into lines no wider than "width" pixels in the font that is really used. Words wider than a line are broken. */
    static List<String> wrap(Font f, String text, int width) { return wrapVar(f, text, i -> width); }

    /** The same, but the width may change from line to line (the first lines are shorter next to a drop cap). */
    static List<String> wrapVar(Font f, String text, IntUnaryOperator widthOf) {
        List<String> out = new ArrayList<>();
        for (String para : text.split("\n")) {
            StringBuilder line = new StringBuilder();
            for (String word : para.split(" ")) {
                if (word.isEmpty()) continue;
                int width = widthOf.applyAsInt(out.size());
                while (CuteFont.width(f, word) > width) {
                    if (line.length() > 0) { out.add(line.toString()); line.setLength(0); width = widthOf.applyAsInt(out.size()); }
                    int n = word.length();
                    while (n > 1 && CuteFont.width(f, word.substring(0, n) + "-") > width) n--;
                    out.add(word.substring(0, n) + "-");
                    word = word.substring(n);
                    width = widthOf.applyAsInt(out.size());
                }
                String attempt = line.length() == 0 ? word : line + " " + word;
                if (CuteFont.width(f, attempt) <= width) { line.setLength(0); line.append(attempt); }
                else { out.add(line.toString()); line.setLength(0); line.append(word); }
            }
            if (line.length() > 0) out.add(line.toString());
        }
        return out;
    }

    private static int take(List<String> from, int i, List<String> to, int max) {
        while (i < from.size() && to.size() < max) to.add(from.get(i++));
        return i;
    }

    /** All the spreads of the tale: the title, the scenes (picture + text, going on over more pages if needed), the end. */
    static List<Spread> layout(Font f, Tales.Tale tl, java.util.function.Function<String, String> text) {
        List<Spread> out = new ArrayList<>();
        out.add(new Spread(0, -1));
        for (int s = 0; s < Tales.SCENES; s++) {
            String txt = text.apply("cutemod.tale." + tl.id() + ".s" + (s + 1));
            final int dropLines = s == 0 && !txt.isEmpty() && Character.isLetter(txt.charAt(0)) ? DROP_LINES : 0;
            char cap = 0;
            int capW = 0;
            if (dropLines > 0) {                                     // the first letter of the tale is a big decorated one
                cap = txt.charAt(0);
                capW = Math.max(14, Math.min(26, CuteFont.width(f, String.valueOf(Character.toUpperCase(cap))) * 2 + 6));
                txt = txt.substring(1);
            }
            final int narrow = TW - capW - 3;
            List<String> lines = wrapVar(f, txt, i -> i < dropLines ? narrow : TW);
            Spread first = new Spread(1, s);
            first.cap = cap;
            first.capW = capW;
            int i = take(lines, 0, first.left, LEFT_LINES);
            i = take(lines, i, first.right, FULL_LINES);
            if (i >= lines.size()) { if (first.right.isEmpty()) first.endL = true; else first.endR = true; }
            out.add(first);
            while (i < lines.size()) {
                Spread more = new Spread(1, -1);
                i = take(lines, i, more.left, FULL_LINES);
                i = take(lines, i, more.right, FULL_LINES);
                if (i >= lines.size()) { if (more.right.isEmpty()) more.endL = true; else more.endR = true; }
                out.add(more);
            }
        }
        out.add(new Spread(2, -1));
        return out;
    }

    private void build(Font f) {
        Tales.Tale tl = Tales.ALL.get(tale);
        String key = tale + "|" + CuteFont.width(f, "MWmw\u0416\u044B\u0429 0123") + "|" + t("cutemod.tale." + tl.id() + ".s1").hashCode();
        if (key.equals(builtKey) && !spreads.isEmpty()) return;
        builtKey = key;
        spreads.clear();
        spreads.addAll(layout(f, tl, k -> t(k)));
        if (cur >= spreads.size()) cur = spreads.size() - 1;
    }

    // ---------- opening, turning, finishing ----------
    private void open(int i) {
        if (!TaleBooks.owns(Tales.ALL.get(i).id())) return;
        tale = i;
        cur = 0;
        flipTo = -1;
        justEarned = false;
        justSticker = false;
        builtKey = "";
        spreads.clear();
        build(font());
        if (Tales.ALL.get(i).id().equals(markId) && markSpread > 0 && markSpread < spreads.size() - 1) cur = markSpread;
        TaleAudio.open();
    }

    private void toShelf() {
        tale = -1;
        buying = -1;
        flipTo = -1;
        TaleAudio.close();
        knockT = 9;                                                  // the knock of the shelf comes a moment after the book closes
    }

    private void go(int to) {
        if (flipTo >= 0 || to < 0 || to >= spreads.size()) return;
        flipTo = to;
        flipT = 0;
        TaleAudio.page();
    }

    private void arrived() {
        String id = Tales.ALL.get(tale).id();
        markId = id;
        markSpread = cur;
        Store.write("tales_mark", id + ":" + cur);
        if (cur == spreads.size() - 1 && !done.contains(id)) {
            done.add(id);
            Store.write("tales", String.join(",", done));
            Progress.earn(REWARD);
            justEarned = true;
            justSticker = award();
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (panelMsgT > 0) panelMsgT--;
        if (flipTo >= 0 && ++flipT >= FLIP) {
            cur = flipTo;
            flipTo = -1;
            arrived();
        }
        if (knockT > 0 && --knockT == 0) { TaleAudio.shelf(); knockT = -1; }
        audio();
    }

    /** The quiet background follows the scene on the page (the one that is turning in counts from the middle of the turn). */
    private void audio() {
        if (!loaded) return;
        if (tale < 0 || spreads.isEmpty()) { TaleAudio.keep(TaleAudio.shelfMood()); return; }
        int idx = flipTo >= 0 && flipT > FLIP / 2 ? flipTo : cur;
        TaleAudio.keep(TaleAudio.mood(Tales.ALL.get(tale), sceneAt(idx)));
    }

    /** The scene of this spread (the pages that go on after a picture belong to its scene); -1 for the title and the end. */
    private int sceneAt(int idx) {
        for (int i = Math.min(idx, spreads.size() - 1); i >= 0; i--) {
            Spread s = spreads.get(i);
            if (s.kind != 1) return -1;
            if (s.scene >= 0) return s.scene;
        }
        return -1;
    }

    // ---------- input ----------
    private static int coverX(int i) { return 9 + (i % 6) * 48; }

    private static int coverY(int i) { return 20 + (i / 6) * 62; }

    @Override
    public boolean click(int x, int y, int button) {
        if (tale < 0) {
            if (buying >= 0) { buyClick(x, y); return true; }
            for (int i = 0; i < Tales.ALL.size(); i++) {
                if (!in(x, y, coverX(i), coverY(i) - 3, 42, 55)) continue;
                if (TaleBooks.owns(Tales.ALL.get(i).id())) open(i);
                else { buying = i; panelMsgT = 0; Sfx.click(); }
                return true;
            }
            return false;
        }
        if (in(x, y, W - 54, 1, 50, 12)) { toShelf(); return true; }
        if (flipTo >= 0 || !in(x, y, BX, BY, BW, BH)) return true;
        if (x < BX + PW + SPINE / 2) go(cur - 1);
        else if (cur >= spreads.size() - 1) toShelf();
        else go(cur + 1);
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (tale < 0) {
            if (buying >= 0 && (keyCode == 256 || keyCode == 259)) { buying = -1; return true; }          // Esc or Backspace close the card
            return false;
        }
        if (keyCode == 263) { go(cur - 1); return true; }                         // left arrow
        if (keyCode == 262) { if (cur >= spreads.size() - 1) toShelf(); else go(cur + 1); return true; }   // right arrow
        if (keyCode == 259) { toShelf(); return true; }                           // backspace
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        if (tale < 0) return false;
        go(amount > 0 ? cur - 1 : cur + 1);
        return true;
    }

    // ---------- drawing ----------
    private static void ctext(GuiGraphics g, Font f, String s, int cx, int y, int color) {
        CuteFont.draw(g, f, s, cx - CuteFont.width(f, s) / 2, y, color, false);
    }

    private static String trunc(Font f, String s, int max) {
        if (CuteFont.width(f, s) <= max) return s;
        int n = s.length();
        while (n > 1 && CuteFont.width(f, s.substring(0, n) + "...") > max) n--;
        return s.substring(0, n) + "...";
    }

    /** A red wax seal with a gold star: the stamp of a tale that was read. */
    private static void seal(GuiGraphics g, int cx, int cy, int rad) {
        disc(g, cx, cy, rad, 0xFF8E1F2C);
        disc(g, cx, cy, rad - 1, 0xFFD8404E);
        disc(g, cx, cy, Math.max(1, rad - 3), 0xFFB82E3C);
        int gold = 0xFFFFD84A;
        g.fill(cx, cy - rad / 2, cx + 1, cy + rad / 2 + 1, gold);
        g.fill(cx - rad / 2, cy, cx + rad / 2 + 1, cy + 1, gold);
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, gold);
        g.fill(cx - 2, cy - 2, cx - 1, cy - 1, gold); g.fill(cx + 2, cy - 2, cx + 3, cy - 1, gold);
        g.fill(cx - 2, cy + 2, cx - 1, cy + 3, gold); g.fill(cx + 2, cy + 2, cx + 3, cy + 3, gold);
        g.fill(cx - rad + 1, cy - rad + 2, cx - rad + 3, cy - rad + 3, 0x66FFFFFF);        // a glint
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        if (tale < 0) { renderShelf(g, f, mx, my); return; }
        build(f);
        renderBook(g, f, mx, my);
    }

    private void cover(GuiGraphics g, Tales.Tale tl, int x, int y, boolean lifted, boolean read, boolean reading) {
        int c = tl.cover(), dark = mix(c, 0x000000, 0.3F);
        if (reading && !read) {                                                  // a bookmark sticks out of the top: you are in the middle of it
            rect(g, x + 29, y - 5, 5, 9, 0xFF3FA04A); rect(g, x + 29, y - 5, 1, 9, 0xFF6AC86A);
            rect(g, x + 30, y + 2, 3, 2, c);
        }
        rect(g, x, y, 42, 52, c);
        rect(g, x, y, 5, 52, dark);
        rect(g, x + 5, y, 1, 52, mix(c, 0xFFFFFF, 0.3F));
        rect(g, x + 8, y + 3, 31, 1, 0xFFFFD84A); rect(g, x + 8, y + 48, 31, 1, 0xFFFFD84A);
        rect(g, x + 8, y + 3, 1, 46, 0xFFFFD84A); rect(g, x + 38, y + 3, 1, 46, 0xFFFFD84A);
        BookArt.prop(g, tl.prop(), x + 23, y + 40, tl.propSize() * 6 / 10);
        if (read) {
            rect(g, x + 35, y, 4, 9, 0xFFE5484D); rect(g, x + 35, y + 9, 2, 2, 0xFFE5484D);   // a ribbon: read
            seal(g, x + 12, y + 42, 6);                                                         // and the seal
        }
        if (lifted) rect(g, x, y, 42, 1, 0x88FFFFFF);
    }

    /** An empty place on the shelf: a dotted outline, a question mark, the pages found so far lying about and five pips. */
    private void locked(GuiGraphics g, Font f, Tales.Tale tl, int x, int y, boolean lifted) {
        int mask = TaleBooks.mask(tl.id()), n = Integer.bitCount(mask);
        rect(g, x, y, 42, 52, lifted ? 0x22FFFFFF : 0x14000000);
        int dot = lifted ? 0xFFB8743A : 0x99B8985A;
        for (int i = 0; i < 42; i += 4) { rect(g, x + i, y, 2, 1, dot); rect(g, x + i, y + 51, 2, 1, dot); }
        for (int i = 0; i < 52; i += 4) { rect(g, x, y + i, 1, 2, dot); rect(g, x + 41, y + i, 1, 2, dot); }
        for (int k = 0; k < n; k++) {                                            // the pages that were found lie in the place of the book
            int px = x + 7 + k * 5, py = y + 9 + (k % 2) * 3;
            rect(g, px, py, 13, 19, 0xFFD8C8A0);
            rect(g, px + 1, py + 1, 11, 17, PAPER);
            for (int l = 0; l < 4; l++) rect(g, px + 2, py + 3 + l * 4, 8, 1, 0x33000000);
        }
        if (n == 0) {
            g.pose().pushPose();
            g.pose().translate(x + 21 - CuteFont.width(f, "?"), y + 14, 0);
            g.pose().scale(2F, 2F, 1F);
            CuteFont.draw(g, f, "?", 0, 0, lifted ? 0xFFB8743A : 0x88B8985A, false);
            g.pose().popPose();
        }
        for (int s = 0; s < Tales.SCENES; s++) {                                 // five pips: one for every page
            boolean has = (mask & (1 << s)) != 0;
            rect(g, x + 4 + s * 7, y + 41, 6, 6, has ? 0xFF8A5A1A : 0x33000000);
            rect(g, x + 5 + s * 7, y + 42, 4, 4, has ? 0xFFFFD84A : 0x22FFFFFF);
        }
    }

    private void renderShelf(GuiGraphics g, Font f, int mx, int my) {
        hover = -1;
        for (int i = 0; i < Tales.ALL.size(); i++) if (buying < 0 && in(mx, my, coverX(i), coverY(i) - 3, 42, 55)) hover = i;
        header(g, f);
        String cnt = CuteFont.cut(f, t("cutemod.tales.collection", TaleBooks.owned(), Tales.ALL.size(), done.size()), W - 70);
        int cw = CuteFont.width(f, cnt);
        CuteFont.draw(g, f, cnt, W - 6 - cw, 3, 0xFFFFFFFF, false);
        if (!done.isEmpty()) seal(g, W - 14 - cw, 7, 5);
        rect(g, 0, 14, W, H - 14, 0xFFF3E2C8);                                   // the wall behind the shelves
        for (int r = 0; r < 2; r++) {
            int py = coverY(r * 6) + 52;
            rect(g, 4, py, W - 8, 6, 0xFF9A6A3A);
            rect(g, 4, py, W - 8, 2, 0xFFC08A52);
            rect(g, 4, py + 6, W - 8, 2, 0x33000000);
        }
        for (int i = 0; i < Tales.ALL.size(); i++) {
            Tales.Tale tl = Tales.ALL.get(i);
            boolean has = TaleBooks.owns(tl.id());
            int x = coverX(i), y = coverY(i) - (hover == i && has ? 3 : 0);
            if (has) {
                rect(g, x + 2, coverY(i) + 50, 42, 3, 0x22000000);
                cover(g, tl, x, y, hover == i, done.contains(tl.id()), tl.id().equals(markId) && markSpread > 0);
            } else {
                locked(g, f, tl, x, coverY(i), hover == i);
            }
        }
        if (hover >= 0) {
            Tales.Tale tl = Tales.ALL.get(hover);
            ctext(g, f, trunc(f, t("cutemod.tale." + tl.id() + ".title"), W - 16), W / 2, 146, TEXT);
            if (TaleBooks.owns(tl.id())) ctext(g, f, trunc(f, t("cutemod.tale.author." + tl.author()), W - 16), W / 2, 156, MUTED);
            else ctext(g, f, trunc(f, t("cutemod.tales.locked", TaleBooks.found(tl.id()), Tales.SCENES, TaleBooks.price(tl.id())), W - 16), W / 2, 156, 0xFFB8743A);
        } else if (done.size() == Tales.ALL.size()) {
            ctext(g, f, trunc(f, t("cutemod.tales.all"), W - 16), W / 2, 150, 0xFFB8743A);
        } else {
            ctext(g, f, trunc(f, t("cutemod.tales.pick"), W - 16), W / 2, 150, MUTED);
        }
        footer(g, f);
        if (buying >= 0) renderBuy(g, f, mx, my);
    }

    // ---------- the card of a book that is not on the shelf yet ----------
    private static final int CX = 40, CY = 20, CW = 220, CH = 132;

    private static boolean pill(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, String label, boolean enabled, boolean main) {
        boolean hov = enabled && mx >= x && mx < x + w && my >= y && my < y + 16;
        int bg = !enabled ? 0xFFE9E2F2 : main ? (hov ? 0xFFA8743A : 0xFFC8905A) : hov ? 0xFFFFEFF8 : 0xFFFFFFFF;
        rect(g, x, y, w, 16, bg);
        rect(g, x, y + 14, w, 2, !enabled ? 0xFFB9A8C8 : main ? 0x33000000 : 0xFFB9A8C8);
        String l = CuteFont.cut(f, label, w - 6);
        CuteFont.draw(g, f, l, x + (w - CuteFont.width(f, l)) / 2, y + 4, !enabled ? 0xFFB8A8D8 : main ? 0xFFFFFFFF : TEXT, false);
        return hov;
    }

    private void renderBuy(GuiGraphics g, Font f, int mx, int my) {
        Tales.Tale tl = Tales.ALL.get(buying);
        int mask = TaleBooks.mask(tl.id()), n = Integer.bitCount(mask), price = TaleBooks.price(tl.id());
        rect(g, 0, 14, W, H - 14, 0xCC1E1438);
        rect(g, CX - 1, CY - 1, CW + 2, CH + 2, 0xFFC8905A);
        rect(g, CX, CY, CW, CH, PAPER);
        cover(g, tl, CX + 10, CY + 10, false, false, false);
        rect(g, CX + 10, CY + 10, 42, 52, 0x66F3E2C8);                             // faded: it is not yours yet
        int tx = CX + 62, tw = CW - 72;
        CuteFont.draw(g, f, trunc(f, t("cutemod.tale." + tl.id() + ".title"), tw), tx, CY + 10, TEXT, false);
        CuteFont.draw(g, f, trunc(f, t("cutemod.tale.author." + tl.author()), tw), tx, CY + 21, MUTED, false);
        for (int s = 0; s < Tales.SCENES; s++) {                                   // the five pages
            boolean has = (mask & (1 << s)) != 0;
            rect(g, tx + s * 14, CY + 36, 11, 15, has ? 0xFFD8C8A0 : 0xFFE6DCC4);
            rect(g, tx + s * 14 + 1, CY + 37, 9, 13, has ? 0xFFFFF8E8 : 0xFFEFE6D2);
            if (has) { rect(g, tx + s * 14 + 3, CY + 40, 5, 1, 0x44000000); rect(g, tx + s * 14 + 3, CY + 43, 5, 1, 0x44000000); rect(g, tx + s * 14 + 3, CY + 46, 3, 1, 0x44000000); }
            else CuteFont.draw(g, f, "?", tx + s * 14 + 3, CY + 39, 0xFFB8A888, false);
        }
        if (panelMsgT > 0) CuteFont.draw(g, f, trunc(f, panelMsg, tw), tx, CY + 54, 0xFFC0392B, false);
        else CuteFont.draw(g, f, trunc(f, t("cutemod.tales.pages", n, Tales.SCENES), tw), tx, CY + 54, 0xFFB8743A, false);
        List<String> where = wrap(f, t("cutemod.tales.where"), CW - 20);
        if (where.size() > 5) {                                                   // never runs over the buttons: the end is cut with "..."
            String rest = String.join(" ", where.subList(4, where.size()));
            where = new ArrayList<>(where.subList(0, 4));
            where.add(trunc(f, rest, CW - 20));
        }
        for (int i = 0; i < where.size(); i++) CuteFont.draw(g, f, where.get(i), CX + 10, CY + 66 + i * LINE, MUTED, false);
        boolean can = Progress.coins() >= price;
        pill(g, f, mx, my, CX + 10, CY + 114, 142, t("cutemod.tales.buy", price), true, can);
        pill(g, f, mx, my, CX + 158, CY + 114, CW - 168, t("cutemod.tales.close"), true, false);
    }

    private void buyClick(int x, int y) {
        Tales.Tale tl = Tales.ALL.get(buying);
        if (!in(x, y, CX, CY, CW, CH)) { buying = -1; return; }
        if (in(x, y, CX + 158, CY + 114, CW - 168, 16)) { buying = -1; Sfx.click(); return; }
        if (!in(x, y, CX + 10, CY + 114, 142, 16)) return;
        if (Progress.coins() < TaleBooks.price(tl.id())) { panelMsg = t("cutemod.tales.nocoins"); panelMsgT = 150; Sfx.click(); return; }
        if (TaleBooks.buy(tl.id())) {
            buying = -1;
            say("cutemod.tales.bought", t("cutemod.tale." + tl.id() + ".title"));
        }
    }

    private void paper(GuiGraphics g, int x, int w, boolean rightPage) {
        rect(g, x, BY, w, BH, PAPER);
        int c = 0xFFE6D8B0;                                                     // the filigree in the outer corners
        ReadingRoom.corner(g, rightPage ? x + w - 4 : x + 3, BY + 3, rightPage, false, c);
        ReadingRoom.corner(g, rightPage ? x + w - 4 : x + 3, BY + BH - 4, rightPage, true, c);
    }

    private void renderBook(GuiGraphics g, Font f, int mx, int my) {
        Tales.Tale tl = Tales.ALL.get(tale);
        float night = ReadingRoom.nightness(), tm = ReadingRoom.clock();
        ReadingRoom.desk(g, W, H, night);                                       // the wooden table
        rect(g, 0, 0, W, 14, accent());
        CuteFont.draw(g, f, trunc(f, t("cutemod.tale." + tl.id() + ".title"), W - 100), 5, 3, 0xFFFFFFFF, false);
        ReadingRoom.window(g, W - 76, 2, night, tm);                            // the sun or the moon in the window
        boolean hb = in(mx, my, W - 54, 1, 50, 12);
        rect(g, W - 54, 1, 50, 12, hb ? 0x66FFFFFF : 0x33FFFFFF);
        ctext(g, f, trunc(f, t("cutemod.tales.shelf"), 46), W - 29, 3, 0xFFFFFFFF);

        // the book: a shadow on the table, the cover around the pages, the thickness of the pages on both sides
        rect(g, BX - 2, BY + 3, BW + 8, BH + 5, 0x40000000);
        rect(g, BX - 4, BY - 4, BW + 8, BH + 8, mix(tl.cover(), 0x000000, 0.2F));
        rect(g, BX - 4, BY - 4, BW + 8, 2, mix(tl.cover(), 0xFFFFFF, 0.25F));
        float prog = spreads.size() <= 1 ? 0F : cur / (float) (spreads.size() - 1);
        int thL = 1 + Math.round(2 * prog), thR = 1 + Math.round(2 * (1 - prog)), thB = Math.max(thL, thR);
        for (int k = 0; k < thL; k++) rect(g, BX - 1 - k, BY + 1 + k, 1, BH - 1 - k, k % 2 == 0 ? 0xFFF2E8D0 : 0xFFD8C8A0);
        for (int k = 0; k < thR; k++) rect(g, BX + BW + k, BY + 1 + k, 1, BH - 1 - k, k % 2 == 0 ? 0xFFF2E8D0 : 0xFFD8C8A0);
        for (int k = 0; k < thB + 1; k++) rect(g, BX - 2 + k, BY + BH + k, BW + 4 - 2 * k, 1, k % 2 == 0 ? 0xFFE8DCC0 : 0xFFC8B890);
        paper(g, BX, PW, false);
        paper(g, BX + PW + SPINE, PW, true);
        rect(g, BX + PW, BY, SPINE, BH, 0xFFEADBB8);
        rect(g, BX + PW + 3, BY, 2, BH, 0x33000000);
        for (int i = 0; i < 4; i++) {                                              // the gutter shadow
            rect(g, BX + PW - 1 - i, BY, 1, BH, (0x16 - i * 4) << 24);
            rect(g, BX + PW + SPINE + i, BY, 1, BH, (0x16 - i * 4) << 24);
        }
        Spread now = spreads.get(cur);
        if (flipTo < 0) {
            leftPage(g, f, now, tl, cur * 2 + 1);
            rightPage(g, f, now, tl, cur * 2 + 2);
        } else {
            drawFlip(g, f, tl);
        }
        ribbon(g);
        if (night > 0.01F) rect(g, BX, BY, BW, BH, ((int) (0x2A * night) << 24) | 0x16286B);   // the pages in the blue of the night
        ReadingRoom.light(g, W, H, BX + BW / 2, night, tm);                     // the lamp, the candle light and the moon beams
        ReadingRoom.candle(g, W, H, tm);
        ReadingRoom.dust(g, W, H, night, tm);
    }

    /** A page that turns: it lifts, bends (its free edge leads) and throws a shadow on the page under it; its faces show the text. */
    private void drawFlip(GuiGraphics g, Font f, Tales.Tale tl) {
        boolean fwd = flipTo > cur;
        Spread now = spreads.get(cur), to = spreads.get(flipTo);
        if (fwd) { leftPage(g, f, now, tl, -1); rightPage(g, f, to, tl, -1); }
        else { rightPage(g, f, now, tl, -1); leftPage(g, f, to, tl, -1); }

        float p = Math.min(1F, flipT / (float) FLIP), e = p * p * (3 - 2 * p);
        double theta = Math.PI * (fwd ? e : 1 - e), sinT = Math.sin(theta), lead = fwd ? 1 : -1;
        final int d = PW + SPINE / 2, hinge = BX + PW + SPINE / 2;
        double[] xs = new double[d + 1], phis = new double[d];
        xs[0] = hinge;
        for (int i = 0; i < d; i++) {
            phis[i] = theta + lead * CURL * sinT * (i / (double) d - 0.4);
            xs[i + 1] = xs[i] + Math.cos(phis[i]);
        }
        double freeX = xs[d];

        for (int k = 0; k < 18; k++) {                                         // the shadow on the page under the turning one
            int a = (int) (0x48 * sinT * (1 - k / 18.0) * (1 - k / 18.0));
            if (a <= 0) continue;
            if (freeX > hinge) rect(g, (int) freeX + k, BY, 1, BH, a << 24);
            else rect(g, (int) freeX - 1 - k, BY, 1, BH, a << 24);
        }
        for (int i = 0; i < d; i++) {                                          // the page, a column at a time
            double phi = phis[i], s = i / (double) d;
            int xl = (int) Math.round(Math.min(xs[i], xs[i + 1])), xr = (int) Math.round(Math.max(xs[i], xs[i + 1]));
            if (xr <= xl) xr = xl + 1;
            int lift = (int) Math.round(LIFT * Math.sin(phi) * Math.pow(s, 0.7));
            int top = BY - lift, bot = BY + BH + lift;
            boolean back = phi > Math.PI / 2;
            float dark = (float) (0.22 * Math.sin(phi) * (0.5 + 0.5 * s) + 0.10 * (1 - s));
            int c = mix(back ? 0xFFFAF1DC : PAPER, 0x2A1A10, Math.min(0.6F, dark));
            rect(g, xl, top, xr - xl, bot - top, c);
            rect(g, xl, top, xr - xl, 1, mix(c, 0x000000, 0.28F));
            rect(g, xl, bot - 1, xr - xl, 1, mix(c, 0x000000, 0.28F));
        }
        int fl = (int) Math.round(freeX);                                       // the edge of the paper
        int liftE = (int) Math.round(LIFT * Math.sin(phis[d - 1]));
        rect(g, fl - 1, BY - liftE, 2, BH + 2 * liftE, 0xFFFFFDF4);
        rect(g, fl + (freeX > hinge ? 1 : -2), BY - liftE, 1, BH + 2 * liftE, 0x33000000);

        double s = Math.abs(freeX - hinge) / d;                                  // what is written on the faces, squeezed to the width of the page
        if (s > 0.05) {
            g.pose().pushPose();
            g.pose().translate(hinge, 0, 0);
            g.pose().scale((float) s, 1F, 1F);
            g.pose().translate(-hinge, 0, 0);
            if (theta < Math.PI / 2) rightPage(g, f, fwd ? now : to, tl, -1);
            else leftPage(g, f, fwd ? to : now, tl, -1);
            g.pose().popPose();
        }
    }

    /** The ribbon bookmark: it lies in the gutter on top of the pages and hangs out of the bottom of the book. */
    private void ribbon(GuiGraphics g) {
        int x = BX + PW + SPINE / 2 - 1, len = BH + 6;
        rect(g, x + 1, BY + 2, 3, len, 0x33000000);
        rect(g, x, BY + 1, 3, len, 0xFFD83A4A);
        rect(g, x, BY + 1, 1, len, 0xFFF0707A);
        rect(g, x + 2, BY + 1, 1, len, 0xFFA82836);
        rect(g, x + 1, BY + 1 + len - 3, 1, 3, 0xFF5A3A28);                      // the swallowtail
        rect(g, x, BY + 1, 3, 1, 0xFFFFD84A);
    }

    private void lines(GuiGraphics g, Font f, List<String> ls, int x, int y) {
        for (int i = 0; i < ls.size(); i++) CuteFont.draw(g, f, ls.get(i), x, y + i * LINE, INK, false);
    }

    private void number(GuiGraphics g, Font f, int n, int cx) {
        if (n > 0) ctext(g, f, Integer.toString(n), cx, BY + BH - 11, 0xFFB8A888);
    }

    private void leftPage(GuiGraphics g, Font f, Spread s, Tales.Tale tl, int num) {
        int px = BX + TX, cx = BX + PW / 2;
        switch (s.kind) {
            case 0 -> {                                                           // the cover plate
                rect(g, px, TOP, TW, BOTTOM - TOP, tl.cover());
                rect(g, px + 3, TOP + 3, TW - 6, 1, 0xFFFFD84A); rect(g, px + 3, BOTTOM - 4, TW - 6, 1, 0xFFFFD84A);
                rect(g, px + 3, TOP + 3, 1, BOTTOM - TOP - 6, 0xFFFFD84A); rect(g, px + TW - 4, TOP + 3, 1, BOTTOM - TOP - 6, 0xFFFFD84A);
                for (int k = 0; k < 4; k++) {                                       // gold corner blocks
                    int cxk = k % 2 == 0 ? px + 3 : px + TW - 7, cyk = k < 2 ? TOP + 3 : BOTTOM - 7;
                    rect(g, cxk, cyk, 4, 4, 0xFFFFD84A); rect(g, cxk + 1, cyk + 1, 2, 2, tl.cover());
                }
                BookArt.prop(g, tl.prop(), px + TW / 2, TOP + 78, tl.propSize() * 18 / 10);
            }
            case 2 -> {                                                           // the end: a small cover and "The End"
                BookArt.prop(g, tl.prop(), cx, TOP + 56, tl.propSize());
                String end = t("cutemod.tales.the_end");
                int sc = CuteFont.width(f, end) * 2 <= TW ? 2 : 1;
                g.pose().pushPose();
                g.pose().translate(cx - CuteFont.width(f, end) * sc / 2F, TOP + 70, 0);
                g.pose().scale(sc, sc, 1F);
                CuteFont.draw(g, f, end, 0, 0, 0xFFB8743A, false);
                g.pose().popPose();
            }
            default -> {
                int ty = TOP;
                if (s.scene >= 0) {
                    rect(g, px - 2, PIC_Y - 2, BookArt.W + 4, PIC_H + 4, 0xFF8A5A3A);
                    BookArt.scene(g, tl.pictures()[s.scene], px, PIC_Y);
                    ty = PIC_Y + PIC_H + 4;
                }
                textBlock(g, f, s, s.left, px, ty, tl, s.endL);
            }
        }
        number(g, f, num, cx);
    }

    /** The lines of a page; the first lines of a tale go round the drop cap, and a flourish closes a scene when there is room. */
    private void textBlock(GuiGraphics g, Font f, Spread s, List<String> ls, int px, int ty, Tales.Tale tl, boolean ends) {
        if (s.cap != 0 && ls == s.left) {
            ReadingRoom.dropCap(g, f, s.cap, px, ty, s.capW, tl.cover());
            for (int i = 0; i < ls.size(); i++) {
                int ix = i < DROP_LINES ? px + s.capW + 3 : px;
                CuteFont.draw(g, f, ls.get(i), ix, ty + i * LINE, INK, false);
            }
        } else {
            lines(g, f, ls, px, ty);
        }
        int fy = ty + ls.size() * LINE + 5;
        if (ends && fy + 4 <= BOTTOM) ReadingRoom.flourish(g, px + TW / 2, fy, ORNAMENT);
    }

    private void rightPage(GuiGraphics g, Font f, Spread s, Tales.Tale tl, int num) {
        int px = BX + PW + SPINE + TX, cx = BX + PW + SPINE + PW / 2;
        switch (s.kind) {
            case 0 -> {
                String name = t("cutemod.tale." + tl.id() + ".title");
                List<String> big = wrap(f, name, TW / 2);                     // twice as big when no word has to be broken
                boolean twice = big.size() <= 4;
                for (String l : big) if (l.endsWith("-")) twice = false;
                int y = TOP + 18;
                if (twice) {
                    for (String l : big) {
                        g.pose().pushPose();
                        g.pose().translate(cx - CuteFont.width(f, l), y, 0);
                        g.pose().scale(2F, 2F, 1F);
                        CuteFont.draw(g, f, l, 0, 0, tl.cover(), false);
                        g.pose().popPose();
                        y += LINE * 2;
                    }
                } else {
                    for (String l : wrap(f, name, TW)) { ctext(g, f, l, cx, y, tl.cover()); y += LINE + 2; }
                }
                ReadingRoom.flourish(g, cx, y + 5, 0xFFFFC832);
                y += 16;
                for (String l : wrap(f, t("cutemod.tale.author." + tl.author()), TW)) { ctext(g, f, l, cx, y, MUTED); y += LINE; }
                List<String> note = wrap(f, t("cutemod.tales.retold"), TW);
                int ny = BOTTOM - note.size() * LINE;
                for (String l : note) { ctext(g, f, l, cx, ny, 0xFFB8A888); ny += LINE; }
            }
            case 2 -> {
                int y = TOP + 14;
                ReadingRoom.flourish(g, cx, y, ORNAMENT);
                y += 12;
                for (String l : wrap(f, t("cutemod.tales.thanks"), TW)) { ctext(g, f, l, cx, y, INK); y += LINE; }
                if (justEarned) { y += 6; for (String l : wrap(f, t("cutemod.tales.reward", REWARD), TW)) { ctext(g, f, l, cx, y, 0xFFB8743A); y += LINE; } }
                if (justSticker) { y += 4; for (String l : wrap(f, t("cutemod.tales.sticker"), TW)) { ctext(g, f, l, cx, y, 0xFF9A5AC0); y += LINE; } }
                y += 8;
                for (String l : wrap(f, t("cutemod.tales.back"), TW)) { ctext(g, f, l, cx, y, MUTED); y += LINE; }
            }
            default -> textBlock(g, f, s, s.right, px, TOP, tl, s.endR);
        }
        number(g, f, num, cx);
    }
}
