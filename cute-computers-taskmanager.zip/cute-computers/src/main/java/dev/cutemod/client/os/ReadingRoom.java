package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.Level;

import java.time.LocalTime;

/**
 * The cosy room around the book of the Fairy Tales app: a wooden table, a warm lamp over the book, a breathing candle flame,
 * glowing dust in the air, a window with the sun or the moon, the blue of the night, and the little decorations of the pages
 * (flourishes, drop caps, corners). Everything is drawn with rectangles, like the rest of the computer.
 */
final class ReadingRoom {
    private ReadingRoom() {}

    private static void r(GuiGraphics g, int x, int y, int w, int h, int c) { g.fill(x, y, x + w, y + h, c); }

    private static int mix(int a, int b, float t) {
        int aa = a >>> 24, ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255;
        int ba = b >>> 24, br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
        return (int) (aa + (ba - aa) * t) << 24 | (int) (ar + (br - ar) * t) << 16 | (int) (ag + (bg - ag) * t) << 8 | (int) (ab + (bb - ab) * t);
    }

    private static int argb(float alpha, int rgb) { return Math.max(0, Math.min(255, Math.round(alpha * 255F))) << 24 | (rgb & 0xFFFFFF); }

    private static int hash(int n) {
        n ^= n >>> 15; n *= 0x2C1B3C6D; n ^= n >>> 12; n *= 0x297A2D39; n ^= n >>> 15;
        return n & 0x7FFFFFFF;
    }

    /** Time for the animations, about 60 steps per second whatever the tick rate is. */
    static float clock() { return (System.currentTimeMillis() % 3_600_000L) / 16.667F; }

    // ---------- day and night ----------
    /** 0 = day, 1 = night. By the time of the Minecraft world (dusk 11500-13500, dawn 22500-24000); without a world by the real clock. */
    static float nightness() {
        long dt;
        Level lvl = Minecraft.getInstance().level;
        if (lvl != null) dt = Math.floorMod(lvl.getDayTime(), 24000L);
        else {
            LocalTime now = LocalTime.now();
            dt = (((now.getHour() * 60L + now.getMinute()) * 24000L / 1440L) + 18000L) % 24000L;     // 6:00 = sunrise = tick 0
        }
        if (dt < 11500) return 0F;
        if (dt < 13500) return (dt - 11500) / 2000F;
        if (dt < 22500) return 1F;
        return 1F - (dt - 22500) / 1500F;
    }

    /** The breathing of a flame: about 0.9 .. 1.1, never still. */
    static float flame(float t) {
        float f = 1F + 0.05F * (float) Math.sin(t * 0.11) + 0.04F * (float) Math.sin(t * 0.37 + 1.3) + 0.025F * (float) Math.sin(t * 0.83 + 0.4);
        if ((hash((int) (t / 23F)) % 7) == 0) f -= 0.05F * (float) Math.sin((t % 23F) / 23F * Math.PI);        // now and then it dips
        return f;
    }

    // ---------- the table ----------
    /** Planks of a wooden table with grain, nails and a darker edge, under the book. night 0..1 darkens it to blue. */
    static void desk(GuiGraphics g, int w, int h, float night) {
        int[] wood = {0xFF76523A, 0xFF6C4A36, 0xFF7C583F, 0xFF684832};
        int plank = 13;
        for (int i = 0, y = 14; y < h; i++, y += plank) {
            int ph = Math.min(plank, h - y), base = wood[i % wood.length];
            r(g, 0, y, w, ph, base);
            for (int k = 0; k < 9; k++) {                                              // the grain
                int hv = hash(i * 131 + k * 17);
                int gx = hv % w, gy = y + 1 + (hv >> 8) % Math.max(1, ph - 2), gl = 14 + (hv >> 16) % 46;
                r(g, gx, gy, Math.min(gl, w - gx), 1, (k % 2 == 0) ? 0x1E000000 : 0x14FFFFFF);
            }
            r(g, 0, y, w, 1, 0x14FFFFFF);
            r(g, 0, y + ph - 1, w, 1, 0x55000000);
            r(g, 5, y + 5, 2, 2, 0x55000000); r(g, 5, y + 5, 1, 1, 0x44FFFFFF);        // nails
            r(g, w - 7, y + 5, 2, 2, 0x55000000); r(g, w - 7, y + 5, 1, 1, 0x44FFFFFF);
        }
        for (int i = 0; i < 18; i++) {                                                 // a soft vignette
            int a = (int) ((0x34 * (1F - i / 18F)) * (1F - i / 18F));
            r(g, 0, 14, 1 + i, h - 14, a << 24);
            r(g, w - 1 - i, 14, 1 + i, h - 14, a << 24);
        }
        if (night > 0.01F) r(g, 0, 14, w, h - 14, argb(0.36F * night, 0x0A1038));       // the blue of the night
    }

    // ---------- light ----------
    private static void ellipse(GuiGraphics g, int cx, int cy, int rx, int ry, int top, int bottom, int argb) {
        for (int dy = Math.max(-ry, top - cy); dy <= Math.min(ry, bottom - cy); dy += 2) {
            int dx = (int) (rx * Math.sqrt(Math.max(0.0, 1.0 - (double) dy * dy / ((double) ry * ry))));
            if (dx > 0) g.fill(cx - dx, cy + dy, cx + dx, cy + dy + 2, argb);
        }
    }

    /** A warm pool of light: stacked ellipses, brightest in the middle. */
    private static void glow(GuiGraphics g, int cx, int cy, int rx, int ry, int rgb, float alphaEach, int steps, int top, int bottom) {
        for (int k = 0; k < steps; k++) {
            float fr = 1F - k / (float) steps;
            ellipse(g, cx, cy, Math.max(2, (int) (rx * fr)), Math.max(2, (int) (ry * fr)), top, bottom, argb(alphaEach, rgb));
        }
    }

    /** The lamp over the book (it burns brighter at night), the light of the candle and the cool beams of the moon. */
    static void light(GuiGraphics g, int w, int h, int bookCx, float night, float t) {
        float fl = flame(t);
        float k = (1F + 0.7F * night) * fl;
        glow(g, bookCx, 6, 190, 112, 0xFFC878, 0.030F * k, 7, 14, h);
        glow(g, w - 6, h - 20, 46, 44, 0xFFB050, 0.022F * k, 4, 14, h);
        if (night > 0.12F) {                                                            // beams from the window
            for (int y = 14; y < h; y++) {
                float shift = (y - 14) * 0.85F;
                int x0 = (int) (w - 70 - shift);
                r(g, x0, y, 9, 1, argb(0.045F * night, 0xBFD8FF));
                r(g, x0 + 17, y, 5, 1, argb(0.035F * night, 0xBFD8FF));
                r(g, x0 + 29, y, 3, 1, argb(0.03F * night, 0xBFD8FF));
            }
        }
    }

    /** A candle in a brass dish in the corner of the table, with a flame that sways and breathes. */
    static void candle(GuiGraphics g, int w, int h, float t) {
        int cx = w - 5, base = h - 2;
        r(g, cx - 4, base - 2, 8, 2, 0xFFB8883A);                                       // the dish
        r(g, cx - 4, base - 2, 8, 1, 0xFFE0B860);
        r(g, cx - 2, base - 14, 4, 12, 0xFFF4ECD8);                                     // the candle
        r(g, cx - 2, base - 14, 1, 12, 0xFFFFFFFF);
        r(g, cx + 1, base - 14, 1, 12, 0xFFD8CCB0);
        r(g, cx, base - 16, 1, 2, 0xFF3A2A2A);                                          // the wick
        float fl = flame(t);
        int sway = Math.round((float) Math.sin(t * 0.21) * 0.8F);
        int hgt = 5 + Math.round((fl - 1F) * 18F);
        int fy = base - 16 - hgt;
        r(g, cx - 2 + sway, fy + 2, 5, hgt - 1, argb(0.45F, 0xFF9A2A));                 // the outer flame
        r(g, cx - 1 + sway, fy, 3, hgt + 1, 0xFFFF9A2A);
        r(g, cx - 1 + sway, fy + 2, 3, hgt - 1, 0xFFFFC84A);
        r(g, cx + sway, fy + 3, 1, hgt - 3, 0xFFFFF4C0);                                // the bright core
    }

    /** Dust in the lamp light: tiny warm specks that drift and twinkle, brighter at night. */
    static void dust(GuiGraphics g, int w, int h, float night, float t) {
        for (int i = 0; i < 18; i++) {
            int hv = hash(i * 977 + 13);
            float sp = 0.012F + (hv % 7) * 0.003F;
            float x = (hv % w + t * sp * (i % 2 == 0 ? 1 : -0.7F) + (float) Math.sin(t * 0.013 + i) * 6F) % w;
            if (x < 0) x += w;
            float y = 16 + ((hv >> 9) % (h - 24)) + (float) Math.sin(t * 0.017 + i * 1.7) * 5F - (t * 0.004F * (1 + i % 3)) % 12F;
            float tw = 0.35F + 0.65F * Math.abs((float) Math.sin(t * 0.045 + i * 2.1));
            float near = 1F - Math.min(1F, (float) Math.hypot(x - w / 2F, y - 8F) / (w * 0.75F));         // brighter near the lamp
            float a = (0.18F + 0.5F * near) * tw * (0.7F + 0.6F * night);
            int px = (int) x, py = (int) y;
            r(g, px, py, 1, 1, argb(a, 0xFFF0C0));
            if (i % 5 == 0) {
                r(g, px - 1, py, 3, 1, argb(a * 0.35F, 0xFFF0C0));
                r(g, px, py - 1, 1, 3, argb(a * 0.35F, 0xFFF0C0));
            }
        }
    }

    /** A small window in the title bar: a sunny day or a moon and twinkling stars (a curtain at the side). */
    static void window(GuiGraphics g, int x, int y, float night, float t) {
        r(g, x - 1, y - 1, 18, 13, 0xFF8A5A3A);
        r(g, x - 1, y - 1, 18, 1, 0xFFB07A52);
        for (int i = 0; i < 11; i++) r(g, x, y + i, 16, 1, mix(mix(0xFF8FD3FF, 0xFFDDF4FF, i / 10F), mix(0xFF0E1236, 0xFF34437E, i / 10F), night));
        if (night < 0.5F) {
            r(g, x + 10, y + 2, 4, 4, 0xFFFFD84A);
            r(g, x + 11, y + 1, 2, 6, 0xFFFFD84A); r(g, x + 9, y + 3, 6, 2, 0xFFFFD84A);
            r(g, x + 2, y + 6, 6, 2, 0xFFFFFFFF); r(g, x + 3, y + 5, 4, 1, 0xFFFFFFFF);
        } else {
            for (int dy = -3; dy <= 3; dy++) {                                         // the moon
                int dx = (int) Math.floor(Math.sqrt(9 - dy * dy + 0.25));
                r(g, x + 11 - dx, y + 5 + dy, dx * 2 + 1, 1, 0xFFFFF3C0);
            }
            r(g, x + 10, y + 4, 1, 1, 0xFFE8D890);
            int[] st = {2, 2, 6, 7, 4, 9, 13, 1};
            for (int i = 0; i < st.length; i += 2) {
                float tw = 0.4F + 0.6F * Math.abs((float) Math.sin(t * 0.05 + i));
                r(g, x + st[i], y + st[i + 1], 1, 1, argb(tw, 0xFFFFF3B0));
            }
        }
        r(g, x + 7, y, 1, 11, 0xFF8A5A3A); r(g, x, y + 5, 16, 1, 0xFF8A5A3A);          // the frame bars
        r(g, x - 1, y - 1, 3, 12, 0x55E5484D);                                         // a curtain
    }

    // ---------- the decorations of the pages ----------
    /** A flourish centred on cx: a diamond, two tapering lines and a curl at each end. y = the middle of the ornament. */
    static void flourish(GuiGraphics g, int cx, int y, int color) {
        r(g, cx - 1, y - 2, 3, 5, color); r(g, cx - 2, y - 1, 5, 3, color); r(g, cx, y - 3, 1, 7, color); r(g, cx - 3, y, 7, 1, color);
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 14; i++) {                                              // the line, tapering into dots
                int px = cx + side * (6 + i);
                if (i < 8 || i % 2 == 0) r(g, px, y, 1, 1, i < 8 ? color : mix(color, 0x00FFFFFF & color, 0.4F));
            }
            for (int a = 0; a < 16; a++) {                                              // the curl: a little spiral going up
                double ang = a * 0.42, rad = 3.2 - a * 0.14;
                int px = cx + side * (22 + (int) Math.round(Math.cos(ang) * rad)), py = y - 2 + (int) Math.round(-Math.sin(ang) * rad);
                r(g, px, py, 1, 1, color);
            }
            r(g, cx + side * 28, y + 1, 1, 1, color);
        }
    }

    /** The big first letter of a tale: a small plate in the colour of the book with a gold frame. w x 18 pixels (two lines of text). */
    static void dropCap(GuiGraphics g, Font f, char ch, int x, int y, int w, int cover) {
        r(g, x, y, w, 18, cover);
        r(g, x, y, w, 1, 0xFFFFD84A); r(g, x, y + 17, w, 1, 0xFFFFD84A);
        r(g, x, y, 1, 18, 0xFFFFD84A); r(g, x + w - 1, y, 1, 18, 0xFFFFD84A);
        r(g, x + 2, y + 2, 2, 2, 0xFFFFD84A); r(g, x + w - 4, y + 2, 2, 2, 0xFFFFD84A);
        r(g, x + 2, y + 14, 2, 2, 0xFFFFD84A); r(g, x + w - 4, y + 14, 2, 2, 0xFFFFD84A);
        String s = String.valueOf(Character.toUpperCase(ch));
        int cw = CuteFont.width(f, s);
        g.pose().pushPose();
        g.pose().translate(x + (w - cw * 2) / 2F, y + 1, 0);
        g.pose().scale(2F, 2F, 1F);
        CuteFont.draw(g, f, s, 0, 0, 0xFFFFF0B8, false);
        g.pose().popPose();
    }

    /** Corner filigree of a page: two thin lines and two dots. right / bottom say which corner of the page it is. */
    static void corner(GuiGraphics g, int x, int y, boolean right, boolean bottom, int color) {
        int sx = right ? -1 : 1, sy = bottom ? -1 : 1;
        for (int i = 0; i < 6; i++) {
            r(g, x + sx * i, y, 1, 1, color);
            r(g, x, y + sy * i, 1, 1, color);
        }
        r(g, x + sx * 2, y + sy * 2, 1, 1, color);
        r(g, x + sx * 3, y + sy * 3, 1, 1, color);
    }
}
