package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/** Little cover pictures for the store, drawn with rectangles. Everything is in fractions of the size. */
public final class CoverArt {
    private CoverArt() {}

    private static void r(GuiGraphics g, int x, int y, int s, double fx, double fy, double fw, double fh, int argb) {
        int x0 = x + (int) Math.round(fx * s), y0 = y + (int) Math.round(fy * s);
        int x1 = x + (int) Math.round((fx + fw) * s), y1 = y + (int) Math.round((fy + fh) * s);
        g.fill(x0, y0, Math.max(x0 + 1, x1), Math.max(y0 + 1, y1), argb);
    }

    private static void d(GuiGraphics g, int x, int y, int s, double cx, double cy, double rad, int argb) {
        int px = x + (int) Math.round(cx * s), py = y + (int) Math.round(cy * s), rr = Math.max(1, (int) Math.round(rad * s));
        for (int dy = -rr; dy <= rr; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rr * rr - dy * dy + 0.25));
            g.fill(px - dx, py + dy, px + dx + 1, py + dy + 1, argb);
        }
    }

    private static int mix(int a, int b, double f) {
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int gr = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }

    /** Games whose cover is dark (the tile of the game gets dark too). */
    public static boolean isDark(String id) {
        return id.equals("horror") || id.equals("ward") || id.equals("purple") || id.equals("bees") || id.equals("cicada") || id.equals("night");
    }

    /** A square cover: the background and the picture. */
    public static void draw(GuiGraphics g, String id, int x, int y, int s) {
        int base = 0xFF000000 | Library.game(id).rgb();
        boolean dark = isDark(id);
        g.fillGradient(x, y, x + s, y + s, dark ? mix(base, 0x000000, 0.6) : mix(base, 0xFFFFFF, 0.35), dark ? mix(base, 0x000000, 0.85) : base);
        glyph(g, id, x, y, s);
        g.fill(x, y, x + s, y + 1, 0x55FFFFFF);
    }

    /** Only the picture of the game, without a background (an app icon draws it on its own rounded tile). */
    public static void glyph(GuiGraphics g, String id, int x, int y, int s) {
        int base = 0xFF000000 | Library.game(id).rgb();
        switch (id) {
            case "pink" -> {
                r(g, x, y, s, 0.78, 0, 0.16, 0.35, 0xFF4E9F5E); r(g, x, y, s, 0.78, 0.68, 0.16, 0.32, 0xFF4E9F5E);
                r(g, x, y, s, 0.2, 0.38, 0.42, 0.34, 0xFFF58FB8); r(g, x, y, s, 0.2, 0.28, 0.1, 0.1, 0xFFF58FB8);
                r(g, x, y, s, 0.52, 0.28, 0.1, 0.1, 0xFFF58FB8); r(g, x, y, s, 0.3, 0.48, 0.06, 0.06, 0xFF3A2A3A);
                r(g, x, y, s, 0.46, 0.48, 0.06, 0.06, 0xFF3A2A3A);
            }
            case "green" -> {
                r(g, x, y, s, 0.18, 0.18, 0.64, 0.64, 0xFF5BBF4A);
                r(g, x, y, s, 0.26, 0.3, 0.15, 0.15, 0xFF16301A); r(g, x, y, s, 0.59, 0.3, 0.15, 0.15, 0xFF16301A);
                r(g, x, y, s, 0.42, 0.46, 0.16, 0.2, 0xFF16301A); r(g, x, y, s, 0.34, 0.58, 0.12, 0.18, 0xFF16301A);
                r(g, x, y, s, 0.54, 0.58, 0.12, 0.18, 0xFF16301A);
            }
            case "white" -> {
                d(g, x, y, s, 0.25, 0.25, 0.12, 0xFF25252D); d(g, x, y, s, 0.75, 0.25, 0.12, 0xFF25252D);
                d(g, x, y, s, 0.5, 0.52, 0.32, 0xFFFFFFFF);
                d(g, x, y, s, 0.36, 0.48, 0.09, 0xFF25252D); d(g, x, y, s, 0.64, 0.48, 0.09, 0xFF25252D);
                d(g, x, y, s, 0.36, 0.47, 0.03, 0xFFFFFFFF); d(g, x, y, s, 0.64, 0.47, 0.03, 0xFFFFFFFF);
                r(g, x, y, s, 0.44, 0.6, 0.12, 0.07, 0xFF25252D);
            }
            case "blue" -> {
                d(g, x, y, s, 0.5, 0.52, 0.34, 0xFF2C4D94); d(g, x, y, s, 0.5, 0.6, 0.22, 0xFFFFFFFF);
                d(g, x, y, s, 0.4, 0.45, 0.05, 0xFF14213F); d(g, x, y, s, 0.6, 0.45, 0.05, 0xFF14213F);
                r(g, x, y, s, 0.44, 0.52, 0.12, 0.08, 0xFFFF9A1F);
            }
            case "orange" -> {
                r(g, x, y, s, 0.14, 0.14, 0.2, 0.28, 0xFFEE7F1C); r(g, x, y, s, 0.66, 0.14, 0.2, 0.28, 0xFFEE7F1C);
                d(g, x, y, s, 0.5, 0.56, 0.34, 0xFFF58B25); r(g, x, y, s, 0.2, 0.62, 0.6, 0.22, 0xFFFFF5E6);
                r(g, x, y, s, 0.3, 0.46, 0.08, 0.12, 0xFF2A1A12); r(g, x, y, s, 0.62, 0.46, 0.08, 0.12, 0xFF2A1A12);
                r(g, x, y, s, 0.45, 0.66, 0.1, 0.07, 0xFF2A1A12);
            }
            case "purple" -> {
                r(g, x, y, s, 0.2, 0.2, 0.6, 0.55, 0xFF17111F);
                r(g, x, y, s, 0.26, 0.44, 0.18, 0.1, 0xFFE45CFF); r(g, x, y, s, 0.56, 0.44, 0.18, 0.1, 0xFFE45CFF);
                r(g, x, y, s, 0.1, 0.3, 0.04, 0.04, 0xFFC26BFF); r(g, x, y, s, 0.88, 0.62, 0.04, 0.04, 0xFFC26BFF);
            }
            case "yellow" -> {
                d(g, x, y, s, 0.5, 0.55, 0.3, 0xFFFFCF2E); r(g, x, y, s, 0.26, 0.42, 0.48, 0.06, 0xFF3A2A1A);
                r(g, x, y, s, 0.22, 0.58, 0.56, 0.06, 0xFF3A2A1A);
                d(g, x, y, s, 0.32, 0.22, 0.1, 0xFFEAF8FF); d(g, x, y, s, 0.68, 0.22, 0.1, 0xFFEAF8FF);
                r(g, x, y, s, 0.4, 0.5, 0.05, 0.06, 0xFF2A1D10); r(g, x, y, s, 0.55, 0.5, 0.05, 0.06, 0xFF2A1D10);
            }
            case "red" -> {
                d(g, x, y, s, 0.5, 0.6, 0.32, 0xFFE2392F); r(g, x, y, s, 0.48, 0.3, 0.04, 0.6, 0xFF2A1414);
                d(g, x, y, s, 0.5, 0.28, 0.16, 0xFF2A1B1B);
                d(g, x, y, s, 0.34, 0.6, 0.06, 0xFF2A1414); d(g, x, y, s, 0.66, 0.6, 0.06, 0xFF2A1414);
                d(g, x, y, s, 0.4, 0.78, 0.05, 0xFF2A1414); d(g, x, y, s, 0.6, 0.78, 0.05, 0xFF2A1414);
            }
            case "breakout" -> {
                for (int i = 0; i < 4; i++) r(g, x, y, s, 0.1 + i * 0.2, 0.12, 0.17, 0.1, i % 2 == 0 ? 0xFFE0594F : 0xFFF2C94C);
                d(g, x, y, s, 0.5, 0.5, 0.16, 0xFFE8B66A); d(g, x, y, s, 0.45, 0.46, 0.03, 0xFF4A2A14); d(g, x, y, s, 0.55, 0.53, 0.03, 0xFF4A2A14);
                r(g, x, y, s, 0.3, 0.86, 0.4, 0.06, 0xFFFFFFFF);
            }
            case "cubes" -> {
                r(g, x, y, s, 0.14, 0.14, 0.34, 0.34, 0xFFF2C94C); r(g, x, y, s, 0.52, 0.14, 0.34, 0.34, 0xFFE0594F);
                r(g, x, y, s, 0.14, 0.52, 0.34, 0.34, 0xFF52C45A); r(g, x, y, s, 0.52, 0.52, 0.34, 0.34, 0xFF4A8FE0);
            }
            case "racer" -> {
                r(g, x, y, s, 0.28, 0, 0.44, 1, 0xFF4A4A5E); r(g, x, y, s, 0.26, 0, 0.03, 1, 0xFFFFFFFF); r(g, x, y, s, 0.71, 0, 0.03, 1, 0xFFFFFFFF);
                r(g, x, y, s, 0.49, 0.1, 0.02, 0.14, 0xFFF3C45A); r(g, x, y, s, 0.49, 0.38, 0.02, 0.14, 0xFFF3C45A); r(g, x, y, s, 0.49, 0.66, 0.02, 0.14, 0xFFF3C45A);
                r(g, x, y, s, 0.36, 0.5, 0.28, 0.4, 0xFFF58FB8); r(g, x, y, s, 0.41, 0.56, 0.18, 0.12, 0xFFBFE8FF);
                r(g, x, y, s, 0.37, 0.46, 0.07, 0.07, 0xFFF58FB8); r(g, x, y, s, 0.56, 0.46, 0.07, 0.07, 0xFFF58FB8);
                d(g, x, y, s, 0.6, 0.22, 0.06, 0xFFFFD84A);
            }
            case "pong" -> {
                d(g, x, y, s, 0.5, 0.9, 0.3, 0xFF7ED957); r(g, x, y, s, 0, 0.9, 1, 0.1, mix(base, 0x000000, 0.4));
                d(g, x, y, s, 0.4, 0.78, 0.04, 0xFF16301A); d(g, x, y, s, 0.6, 0.78, 0.04, 0xFF16301A);
                d(g, x, y, s, 0.7, 0.3, 0.07, 0xFFFFFFFF);
            }
            case "bees" -> {
                for (int i = 0; i < 3; i++) { d(g, x, y, s, 0.25 + i * 0.25, 0.28, 0.08, 0xFFFFCF2E); r(g, x, y, s, 0.2 + i * 0.25, 0.26, 0.1, 0.03, 0xFF3A2A1A); }
                r(g, x, y, s, 0.44, 0.78, 0.12, 0.12, 0xFF7ED957); r(g, x, y, s, 0.49, 0.66, 0.02, 0.12, 0xFFFFFFFF);
            }
            case "horror" -> {
                r(g, x, y, s, 0.44, 0.45, 0.12, 0.4, 0xFFF2EBDD); r(g, x, y, s, 0.47, 0.3, 0.06, 0.15, 0xFFFFD84A);
                d(g, x, y, s, 0.5, 0.36, 0.2, 0x33FFD84A);
                r(g, x, y, s, 0.12, 0.2, 0.08, 0.04, 0xFFFF2A2A); r(g, x, y, s, 0.8, 0.2, 0.08, 0.04, 0xFFFF2A2A);
            }
            case "craft" -> {
                r(g, x, y, s, 0, 0, 1, 0.5, 0xFF8ED0FF);
                r(g, x, y, s, 0.2, 0.4, 0.6, 0.15, 0xFF5BBF4A); r(g, x, y, s, 0.2, 0.55, 0.6, 0.35, 0xFF8A5A3A);
                r(g, x, y, s, 0.3, 0.65, 0.1, 0.1, 0xFF5A3A22); r(g, x, y, s, 0.55, 0.72, 0.1, 0.1, 0xFF5A3A22);
                d(g, x, y, s, 0.8, 0.15, 0.08, 0xFFFFE066);
            }
            case "durak" -> {
                r(g, x, y, s, 0.14, 0.26, 0.34, 0.5, 0xFFFAF6EC); r(g, x, y, s, 0.5, 0.2, 0.34, 0.5, 0xFFFAF6EC);
                r(g, x, y, s, 0.2, 0.34, 0.1, 0.1, 0xFF2A2A3A); r(g, x, y, s, 0.56, 0.28, 0.1, 0.1, 0xFFD83A4A);
                d(g, x, y, s, 0.67, 0.5, 0.08, 0xFFD83A4A); d(g, x, y, s, 0.31, 0.58, 0.07, 0xFF2A2A3A);
            }
            case "sakura" -> {
                d(g, x, y, s, 0.5, 0.42, 0.3, 0xFFFFB6D2); d(g, x, y, s, 0.5, 0.42, 0.2, 0xFFF58FB8);
                r(g, x, y, s, 0.49, 0.42, 0.03, 0.4, 0xFF9A6A4A);
                r(g, x, y, s, 0.14, 0.2, 0.08, 0.06, 0xFFFFFFFF); r(g, x, y, s, 0.8, 0.6, 0.08, 0.06, 0xFFFFFFFF);
                r(g, x, y, s, 0.7, 0.14, 0.06, 0.06, 0xFFFFFFFF);
            }
            case "blocks" -> {
                r(g, x, y, s, 0.2, 0.2, 0.2, 0.2, 0xFFF3D46A); r(g, x, y, s, 0.4, 0.2, 0.2, 0.2, 0xFFF3D46A);
                r(g, x, y, s, 0.2, 0.4, 0.2, 0.2, 0xFFF3D46A); r(g, x, y, s, 0.4, 0.4, 0.2, 0.2, 0xFFF3D46A);
                r(g, x, y, s, 0.2, 0.6, 0.2, 0.2, 0xFFE27B72); r(g, x, y, s, 0.4, 0.6, 0.2, 0.2, 0xFFE27B72);
                r(g, x, y, s, 0.6, 0.6, 0.2, 0.2, 0xFFE27B72); r(g, x, y, s, 0.6, 0.4, 0.2, 0.2, 0xFF8FD39A);
            }
            case "cakes" -> {
                r(g, x, y, s, 0.1, 0.72, 0.8, 0.07, 0xFFFFFFFF);
                r(g, x, y, s, 0.2, 0.46, 0.6, 0.26, 0xFF7A4A2A);
                r(g, x, y, s, 0.16, 0.38, 0.68, 0.12, 0xFFFFFFFF);
                r(g, x, y, s, 0.24, 0.48, 0.07, 0.1, 0xFFFFFFFF); r(g, x, y, s, 0.66, 0.48, 0.07, 0.12, 0xFFFFFFFF);
                d(g, x, y, s, 0.5, 0.3, 0.075, 0xFFE5484D);
                r(g, x, y, s, 0.5, 0.14, 0.02, 0.1, 0xFF2A7A3A);
            }
            case "cakefactory" -> {
                r(g, x, y, s, 0.04, 0.74, 0.92, 0.1, 0xFF4A4A5A);
                r(g, x, y, s, 0.1, 0.78, 0.06, 0.02, 0xFF8A8A9A); r(g, x, y, s, 0.4, 0.78, 0.06, 0.02, 0xFF8A8A9A); r(g, x, y, s, 0.7, 0.78, 0.06, 0.02, 0xFF8A8A9A);
                r(g, x, y, s, 0.26, 0.52, 0.48, 0.22, 0xFF7A4A2A);
                r(g, x, y, s, 0.3, 0.34, 0.4, 0.18, 0xFFF3E3B0);
                r(g, x, y, s, 0.24, 0.44, 0.52, 0.1, 0xFFF58FB8);
                d(g, x, y, s, 0.5, 0.28, 0.07, 0xFFE5484D);
            }
            case "checkers" -> {   // a board corner with a white and a black piece, the white one crowned
                for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++)
                    r(g, x, y, s, 0.1 + i * 0.2, 0.1 + j * 0.2, 0.2, 0.2, (i + j) % 2 == 0 ? 0xFFFFF0F6 : 0xFF8A4A78);
                d(g, x, y, s, 0.3, 0.7, 0.085, 0xFFFFFFFF);
                d(g, x, y, s, 0.3, 0.7, 0.06, 0xFFE8D0DC);
                r(g, x, y, s, 0.27, 0.68, 0.06, 0.03, 0xFFFFD84A);
                d(g, x, y, s, 0.7, 0.3, 0.085, 0xFF2A1840);
                d(g, x, y, s, 0.7, 0.3, 0.06, 0xFF4A2A66);
            }
            case "slice" -> {   // a melon cut in two, with a white slash across it
                d(g, x, y, s, 0.5, 0.52, 0.3, 0xFF2E8B3A);
                d(g, x, y, s, 0.5, 0.52, 0.24, 0xFFE8475A);
                r(g, x, y, s, 0.4, 0.42, 0.03, 0.05, 0xFF2A2433); r(g, x, y, s, 0.56, 0.5, 0.03, 0.05, 0xFF2A2433); r(g, x, y, s, 0.46, 0.62, 0.03, 0.05, 0xFF2A2433);
                for (int i = 0; i < 12; i++) r(g, x, y, s, 0.12 + i * 0.065, 0.8 - i * 0.055, 0.07, 0.035, 0xFFFFFFFF);
            }
            case "rabbit" -> {  // a rabbit on the grass, a road behind it
                r(g, x, y, s, 0, 0, 1, 0.45, 0xFF4A4A5E);
                r(g, x, y, s, 0.08, 0.21, 0.16, 0.03, 0xFFFFFFFF); r(g, x, y, s, 0.42, 0.21, 0.16, 0.03, 0xFFFFFFFF); r(g, x, y, s, 0.76, 0.21, 0.16, 0.03, 0xFFFFFFFF);
                r(g, x, y, s, 0, 0.45, 1, 0.55, 0xFF8ED36A);
                r(g, x, y, s, 0.36, 0.3, 0.06, 0.26, 0xFFFFFFFF); r(g, x, y, s, 0.58, 0.3, 0.06, 0.26, 0xFFFFFFFF);
                r(g, x, y, s, 0.32, 0.52, 0.36, 0.22, 0xFFFFFFFF); r(g, x, y, s, 0.42, 0.6, 0.04, 0.04, 0xFF2A2433); r(g, x, y, s, 0.55, 0.6, 0.04, 0.04, 0xFF2A2433);
                r(g, x, y, s, 0.3, 0.74, 0.4, 0.16, 0xFFF4EAF0);
            }
            case "dash" -> {    // a track running away to the horizon, a cart on the left, the kitty from behind
                r(g, x, y, s, 0, 0, 1, 0.38, 0xFFFFD6E6); r(g, x, y, s, 0, 0.38, 1, 0.62, 0xFF98D893);
                for (int i = 0; i < 12; i++) {
                    double f = 0.38 + i * 0.052, hw = 0.05 + i * 0.037;
                    r(g, x, y, s, 0.5 - hw, f, hw * 2, 0.055, i % 2 == 0 ? 0xFF6E6C8A : 0xFF67657F);
                }
                r(g, x, y, s, 0.26, 0.5, 0.15, 0.2, 0xFF5BA8F0); r(g, x, y, s, 0.285, 0.54, 0.045, 0.06, 0xFFBFE8FF); r(g, x, y, s, 0.34, 0.54, 0.045, 0.06, 0xFFBFE8FF);
                d(g, x, y, s, 0.72, 0.52, 0.035, 0xFFFFD84A); d(g, x, y, s, 0.72, 0.64, 0.045, 0xFFFFD84A);
                r(g, x, y, s, 0.4, 0.6, 0.2, 0.2, 0xFFB57BD6); r(g, x, y, s, 0.39, 0.4, 0.22, 0.2, 0xFFF58FB8);
                r(g, x, y, s, 0.39, 0.34, 0.06, 0.08, 0xFFF58FB8); r(g, x, y, s, 0.55, 0.34, 0.06, 0.08, 0xFFF58FB8);
                r(g, x, y, s, 0.42, 0.78, 0.06, 0.12, 0xFFD9648F); r(g, x, y, s, 0.52, 0.78, 0.06, 0.12, 0xFFD9648F);
            }
            case "tower" -> {   // a leaning tower of coloured blocks
                int[] pc = {0xFFF06AAE, 0xFFF5A04A, 0xFFF3D46A, 0xFF7ED957, 0xFF4FC9B8};
                double[] ox = {0.18, 0.22, 0.2, 0.26, 0.24};
                for (int i = 0; i < 5; i++) r(g, x, y, s, ox[i], 0.78 - i * 0.14, 0.52 - i * 0.02, 0.13, pc[i]);
            }
            case "hangman" -> { // a gallows with a little head
                r(g, x, y, s, 0.2, 0.84, 0.5, 0.06, 0xFFB07A44); r(g, x, y, s, 0.3, 0.14, 0.06, 0.7, 0xFFB07A44);
                r(g, x, y, s, 0.3, 0.14, 0.38, 0.06, 0xFFB07A44); r(g, x, y, s, 0.64, 0.2, 0.03, 0.12, 0xFFFFFFFF);
                d(g, x, y, s, 0.655, 0.4, 0.1, 0xFFF4F0E8); r(g, x, y, s, 0.64, 0.5, 0.03, 0.22, 0xFFF06AAE);
            }
            case "billiards" -> { // a rack of balls and the white one
                int[] bc = {0xFFF5D84A, 0xFF4A8FE0, 0xFFE0594F, 0xFF9B5FD0, 0xFFF58B25, 0xFF52B85A};
                int k = 0;
                for (int row = 0; row < 3; row++) for (int j = 0; j <= row; j++)
                    d(g, x, y, s, 0.58 + row * 0.12, 0.5 + (j - row / 2.0) * 0.15, 0.075, bc[k++]);
                d(g, x, y, s, 0.22, 0.5, 0.08, 0xFFFFFFFF);
                for (int i = 0; i < 6; i++) r(g, x, y, s, 0.04 + i * 0.02, 0.5, 0.02, 0.02, 0xFFE8C890);
            }
            case "hive" -> {   // a pink bean-pet with ears and a red alarm bubble
                d(g, x, y, s, 0.5, 0.55, 0.3, 0x44FFFFFF);
                r(g, x, y, s, 0.34, 0.4, 0.32, 0.38, 0xFFF4A7C3); d(g, x, y, s, 0.5, 0.4, 0.16, 0xFFF4A7C3);
                r(g, x, y, s, 0.58, 0.4, 0.08, 0.38, 0xFFC97FA0);
                r(g, x, y, s, 0.34, 0.78, 0.12, 0.08, 0xFFC97FA0); r(g, x, y, s, 0.54, 0.78, 0.12, 0.08, 0xFFC97FA0);
                d(g, x, y, s, 0.38, 0.26, 0.05, 0xFFC97FA0); d(g, x, y, s, 0.62, 0.26, 0.05, 0xFFC97FA0);
                r(g, x, y, s, 0.4, 0.42, 0.07, 0.12, 0xFFFFFFFF); r(g, x, y, s, 0.5, 0.42, 0.07, 0.12, 0xFFFFFFFF);
                r(g, x, y, s, 0.43, 0.46, 0.03, 0.07, 0xFF1A1428); r(g, x, y, s, 0.53, 0.46, 0.03, 0.07, 0xFF1A1428);
                d(g, x, y, s, 0.78, 0.22, 0.1, 0xFFE0594F);
                r(g, x, y, s, 0.765, 0.15, 0.03, 0.08, 0xFFFFFFFF); r(g, x, y, s, 0.765, 0.25, 0.03, 0.03, 0xFFFFFFFF);
            }
            case "bomber" -> { // a pink cat next to a lit bomb, with a blast behind them
                d(g, x, y, s, 0.7, 0.55, 0.22, 0x55FFC93B); d(g, x, y, s, 0.7, 0.55, 0.15, 0x99FF8A3D);
                d(g, x, y, s, 0.68, 0.58, 0.14, 0xFF4A3F66); d(g, x, y, s, 0.64, 0.53, 0.04, 0xAAFFFFFF);
                r(g, x, y, s, 0.7, 0.34, 0.03, 0.08, 0xFFBFA77A); d(g, x, y, s, 0.73, 0.3, 0.04, 0xFFFFE27A);
                r(g, x, y, s, 0.14, 0.3, 0.07, 0.14, 0xFFF59BC1); r(g, x, y, s, 0.34, 0.3, 0.07, 0.14, 0xFFF59BC1);
                r(g, x, y, s, 0.12, 0.4, 0.31, 0.24, 0xFFF59BC1); r(g, x, y, s, 0.17, 0.64, 0.21, 0.14, 0xFFE9709F);
                r(g, x, y, s, 0.19, 0.48, 0.04, 0.07, 0xFF2B2233); r(g, x, y, s, 0.31, 0.48, 0.04, 0.07, 0xFF2B2233);
                r(g, x, y, s, 0.25, 0.56, 0.04, 0.03, 0xFFE0508A);
            }
            case "mayhem" -> { // a red and a blue fighter with guns on a marble slab, bullets between them
                d(g, x, y, s, 0.5, 0.5, 0.32, 0x33FFFFFF);
                r(g, x, y, s, 0.06, 0.78, 0.88, 0.07, 0xFFF0EBDD); r(g, x, y, s, 0.06, 0.78, 0.88, 0.02, 0xFFFFFFFF); r(g, x, y, s, 0.06, 0.85, 0.88, 0.03, 0xFFC9C0AC);
                r(g, x, y, s, 0.2, 0.88, 0.08, 0.1, 0xFFE9E3D4); r(g, x, y, s, 0.72, 0.88, 0.08, 0.1, 0xFFE9E3D4);
                r(g, x, y, s, 0.12, 0.46, 0.24, 0.3, 0xFFE8544E); r(g, x, y, s, 0.15, 0.42, 0.18, 0.05, 0xFFFF9A90); r(g, x, y, s, 0.12, 0.46, 0.03, 0.3, 0xFFB43A3A);
                r(g, x, y, s, 0.13, 0.5, 0.22, 0.04, 0xFFFFFFFF);
                r(g, x, y, s, 0.24, 0.54, 0.05, 0.09, 0xFFFFFFFF); r(g, x, y, s, 0.27, 0.56, 0.02, 0.06, 0xFF2A2233);
                r(g, x, y, s, 0.36, 0.6, 0.14, 0.05, 0xFF666E84); r(g, x, y, s, 0.36, 0.6, 0.04, 0.08, 0xFF343949);
                r(g, x, y, s, 0.64, 0.46, 0.24, 0.3, 0xFF3E8FE8); r(g, x, y, s, 0.67, 0.42, 0.18, 0.05, 0xFF86BEFF); r(g, x, y, s, 0.85, 0.46, 0.03, 0.3, 0xFF2A63B0);
                r(g, x, y, s, 0.64, 0.4, 0.24, 0.1, 0xFF2A3F73);
                r(g, x, y, s, 0.71, 0.54, 0.05, 0.09, 0xFFFFFFFF); r(g, x, y, s, 0.71, 0.56, 0.02, 0.06, 0xFF2A2233);
                r(g, x, y, s, 0.5, 0.6, 0.14, 0.05, 0xFF666E84); r(g, x, y, s, 0.6, 0.6, 0.04, 0.08, 0xFF343949);
                d(g, x, y, s, 0.52, 0.62, 0.05, 0xFFFFF2A0); r(g, x, y, s, 0.4, 0.4, 0.1, 0.02, 0xFFFFD34D); r(g, x, y, s, 0.58, 0.34, 0.09, 0.02, 0xFFFFD34D);
            }
            case "funnyfarm" -> { // a red barn on a green hill and a white hen
                r(g, x, y, s, 0.0, 0.74, 1.0, 0.26, 0xFF5FAE5A);
                r(g, x, y, s, 0.0, 0.74, 1.0, 0.04, 0xFF9AE08A);
                r(g, x, y, s, 0.14, 0.34, 0.42, 0.4, 0xFFD9504F);
                r(g, x, y, s, 0.10, 0.26, 0.50, 0.08, 0xFF8A5A3A);
                r(g, x, y, s, 0.16, 0.18, 0.38, 0.08, 0xFF8A5A3A);
                r(g, x, y, s, 0.24, 0.10, 0.22, 0.08, 0xFF8A5A3A);
                r(g, x, y, s, 0.27, 0.5, 0.16, 0.24, 0xFFFFFFFF);
                r(g, x, y, s, 0.29, 0.52, 0.12, 0.2, 0xFFC03F44);
                r(g, x, y, s, 0.34, 0.52, 0.02, 0.2, 0xFFFFFFFF);
                d(g, x, y, s, 0.74, 0.66, 0.14, 0xFFFFFFFF);
                d(g, x, y, s, 0.82, 0.54, 0.08, 0xFFFFFFFF);
                r(g, x, y, s, 0.79, 0.42, 0.06, 0.06, 0xFFE0564F);
                r(g, x, y, s, 0.89, 0.54, 0.06, 0.04, 0xFFFFA83A);
                r(g, x, y, s, 0.83, 0.5, 0.03, 0.05, 0xFF2A2030);
                r(g, x, y, s, 0.66, 0.62, 0.1, 0.08, 0xFFE8E0D0);
                r(g, x, y, s, 0.7, 0.78, 0.02, 0.08, 0xFFF0A030); r(g, x, y, s, 0.78, 0.78, 0.02, 0.08, 0xFFF0A030);
            }
            case "cicada" -> { // a blood-red moon over a girl with a red bow, and a cicada
                d(g, x, y, s, 0.5, 0.36, 0.36, 0x33FF5050);
                d(g, x, y, s, 0.5, 0.36, 0.28, 0xFFD8323A); d(g, x, y, s, 0.6, 0.28, 0.06, 0x33000000);
                r(g, x, y, s, 0.0, 0.9, 1.0, 0.1, 0xFF140A1C);
                r(g, x, y, s, 0.2, 0.76, 0.6, 0.16, 0xFF2A3668); r(g, x, y, s, 0.44, 0.74, 0.12, 0.06, 0xFFE8E4F0); r(g, x, y, s, 0.47, 0.76, 0.06, 0.05, 0xFFD8283A);
                d(g, x, y, s, 0.5, 0.58, 0.21, 0xFF8A4A2C); r(g, x, y, s, 0.29, 0.58, 0.42, 0.2, 0xFF8A4A2C);
                d(g, x, y, s, 0.5, 0.62, 0.15, 0xFFFFE2D2);
                r(g, x, y, s, 0.33, 0.42, 0.34, 0.1, 0xFF8A4A2C); r(g, x, y, s, 0.38, 0.52, 0.06, 0.04, 0xFF8A4A2C); r(g, x, y, s, 0.56, 0.52, 0.06, 0.04, 0xFF8A4A2C);
                r(g, x, y, s, 0.4, 0.6, 0.06, 0.09, 0xFF1A1020); r(g, x, y, s, 0.54, 0.6, 0.06, 0.09, 0xFF1A1020);
                r(g, x, y, s, 0.41, 0.61, 0.02, 0.025, 0xFFFFFFFF); r(g, x, y, s, 0.55, 0.61, 0.02, 0.025, 0xFFFFFFFF);
                r(g, x, y, s, 0.47, 0.73, 0.06, 0.015, 0xFF8A2438);
                r(g, x, y, s, 0.26, 0.4, 0.13, 0.06, 0xFFD8283A); r(g, x, y, s, 0.3, 0.38, 0.05, 0.1, 0xFFB01E2E);
                r(g, x, y, s, 0.1, 0.14, 0.05, 0.1, 0xFF2A2420); r(g, x, y, s, 0.04, 0.15, 0.05, 0.07, 0x99CFE6F0); r(g, x, y, s, 0.15, 0.15, 0.05, 0.07, 0x99CFE6F0);
            }
            case "night" -> { // a dark doorway with a pale bunny in it, a moon clock and stars
                for (int i = 0; i < 6; i++) r(g, x, y, s, 0.08 + i * 0.16, 0.06 + (i * 37 % 17) / 100.0, 0.02, 0.02, 0xAAE8E4FF);
                d(g, x, y, s, 0.5, 0.5, 0.4, 0x22B070FF);
                r(g, x, y, s, 0.26, 0.14, 0.48, 0.78, 0xFF3A2A5A);
                r(g, x, y, s, 0.29, 0.17, 0.42, 0.75, 0xFF0A0618);
                r(g, x, y, s, 0.38, 0.2, 0.07, 0.24, 0xFFEBCBDB); r(g, x, y, s, 0.4, 0.24, 0.03, 0.16, 0xFFD08AAA);
                r(g, x, y, s, 0.55, 0.23, 0.07, 0.2, 0xFFEBCBDB); r(g, x, y, s, 0.57, 0.27, 0.03, 0.12, 0xFFD08AAA);
                d(g, x, y, s, 0.5, 0.56, 0.17, 0xFFEBCBDB);
                d(g, x, y, s, 0.44, 0.53, 0.05, 0xFF0B0710); d(g, x, y, s, 0.57, 0.53, 0.04, 0xFF0B0710);
                r(g, x, y, s, 0.43, 0.515, 0.012, 0.012, 0xFFFFFFFF); r(g, x, y, s, 0.565, 0.52, 0.01, 0.01, 0xFFFFFFFF);
                r(g, x, y, s, 0.4, 0.65, 0.2, 0.014, 0xFF8A4A6A);
                for (int i = 0; i < 5; i++) r(g, x, y, s, 0.4 + i * 0.05, 0.635, 0.012, 0.04, 0xFF8A4A6A);
                r(g, x, y, s, 0.41, 0.72, 0.18, 0.2, 0xFFEBCBDB);
                r(g, x, y, s, 0.0, 0.92, 1.0, 0.08, 0xFF140A20);
                d(g, x, y, s, 0.84, 0.17, 0.09, 0xFFE8E0D0); r(g, x, y, s, 0.835, 0.1, 0.012, 0.08, 0xFF3A2A30); r(g, x, y, s, 0.835, 0.165, 0.06, 0.012, 0xFF3A2A30);
            }
            case "birds" -> { // a red bird on a slingshot and a green piggy behind a block
                d(g, x, y, s, 0.5, 0.5, 0.36, 0x33FFFFFF);
                r(g, x, y, s, 0.0, 0.88, 1.0, 0.12, 0xFF6BCF58); r(g, x, y, s, 0.0, 0.88, 1.0, 0.03, 0xFFB5F08A);
                r(g, x, y, s, 0.2, 0.62, 0.06, 0.28, 0xFF8A5A2E); r(g, x, y, s, 0.14, 0.5, 0.05, 0.14, 0xFF8A5A2E); r(g, x, y, s, 0.27, 0.5, 0.05, 0.14, 0xFF8A5A2E);
                r(g, x, y, s, 0.17, 0.52, 0.12, 0.02, 0xFF4A2A14);
                d(g, x, y, s, 0.23, 0.45, 0.1, 0xFFE0453A); d(g, x, y, s, 0.23, 0.5, 0.05, 0xFFF7C9B8);
                r(g, x, y, s, 0.24, 0.4, 0.04, 0.06, 0xFFFFFFFF); r(g, x, y, s, 0.3, 0.4, 0.04, 0.06, 0xFFFFFFFF);
                r(g, x, y, s, 0.27, 0.42, 0.02, 0.03, 0xFF1A1428); r(g, x, y, s, 0.32, 0.42, 0.02, 0.03, 0xFF1A1428);
                r(g, x, y, s, 0.22, 0.36, 0.14, 0.025, 0xFF5A1A14); r(g, x, y, s, 0.33, 0.47, 0.05, 0.04, 0xFFF5A030);
                r(g, x, y, s, 0.62, 0.52, 0.07, 0.36, 0xFFC98B4E); r(g, x, y, s, 0.86, 0.52, 0.07, 0.36, 0xFFC98B4E); r(g, x, y, s, 0.58, 0.46, 0.39, 0.07, 0xFFA9DDF5);
                d(g, x, y, s, 0.775, 0.8, 0.1, 0xFF7ED957); d(g, x, y, s, 0.775, 0.83, 0.045, 0xFFA6EC82);
                r(g, x, y, s, 0.73, 0.76, 0.04, 0.05, 0xFFFFFFFF); r(g, x, y, s, 0.8, 0.76, 0.04, 0.05, 0xFFFFFFFF);
                r(g, x, y, s, 0.745, 0.78, 0.02, 0.03, 0xFF1A1428); r(g, x, y, s, 0.815, 0.78, 0.02, 0.03, 0xFF1A1428);
            }
            case "frog" -> { // a green frog on a lily pad with a tongue out to a fly, night-blue swamp
                d(g, x, y, s, 0.5, 0.5, 0.36, 0x33FFFFFF);
                r(g, x, y, s, 0.0, 0.84, 1.0, 0.16, 0xFF123478);
                d(g, x, y, s, 0.5, 0.82, 0.3, 0xFF2E9A44); d(g, x, y, s, 0.5, 0.8, 0.27, 0xFF45BE55);
                d(g, x, y, s, 0.5, 0.66, 0.2, 0xFF4FCF3F); d(g, x, y, s, 0.5, 0.74, 0.13, 0xFFE6F7A8);
                d(g, x, y, s, 0.38, 0.46, 0.07, 0xFF4FCF3F); d(g, x, y, s, 0.62, 0.46, 0.07, 0xFF4FCF3F);
                d(g, x, y, s, 0.38, 0.46, 0.05, 0xFFFFFFFF); d(g, x, y, s, 0.62, 0.46, 0.05, 0xFFFFFFFF);
                r(g, x, y, s, 0.4, 0.44, 0.03, 0.05, 0xFF1A1428); r(g, x, y, s, 0.64, 0.44, 0.03, 0.05, 0xFF1A1428);
                r(g, x, y, s, 0.42, 0.64, 0.16, 0.02, 0xFF2A7A2A);
                r(g, x, y, s, 0.5, 0.58, 0.02, 0.01, 0xFFFF5A78); r(g, x, y, s, 0.52, 0.5, 0.18, 0.03, 0xFFFF5A78);
                d(g, x, y, s, 0.78, 0.22, 0.05, 0xFF2A2A34); r(g, x, y, s, 0.66, 0.16, 0.08, 0.04, 0xCCE8F4FF); r(g, x, y, s, 0.82, 0.16, 0.08, 0.04, 0xCCE8F4FF);
                d(g, x, y, s, 0.14, 0.2, 0.03, 0xFFEFFF8A);
            }
            case "fighters" -> { // a cat and a fox trading punches, a hit star between them
                d(g, x, y, s, 0.5, 0.5, 0.36, 0x33FFFFFF);
                r(g, x, y, s, 0.0, 0.88, 1.0, 0.12, 0xFF8A5634); r(g, x, y, s, 0.0, 0.88, 1.0, 0.03, 0xFFFFD6A0);
                r(g, x, y, s, 0.1, 0.26, 0.06, 0.1, 0xFFF4A860); r(g, x, y, s, 0.27, 0.26, 0.06, 0.1, 0xFFF4A860);
                r(g, x, y, s, 0.12, 0.54, 0.2, 0.26, 0xFFE0484F); d(g, x, y, s, 0.22, 0.43, 0.13, 0xFFF4A860);
                r(g, x, y, s, 0.1, 0.38, 0.24, 0.035, 0xFFFFE27A);
                r(g, x, y, s, 0.19, 0.43, 0.03, 0.07, 0xFF241A30); r(g, x, y, s, 0.27, 0.43, 0.03, 0.07, 0xFF241A30);
                r(g, x, y, s, 0.14, 0.8, 0.07, 0.09, 0xFFA8303A); r(g, x, y, s, 0.24, 0.8, 0.07, 0.09, 0xFFA8303A);
                r(g, x, y, s, 0.3, 0.57, 0.22, 0.07, 0xFFE0484F); d(g, x, y, s, 0.54, 0.605, 0.045, 0xFFF4A860);
                r(g, x, y, s, 0.66, 0.26, 0.06, 0.1, 0xFFEE7A34); r(g, x, y, s, 0.83, 0.26, 0.06, 0.1, 0xFFEE7A34);
                r(g, x, y, s, 0.68, 0.54, 0.2, 0.26, 0xFF3C7DD9); d(g, x, y, s, 0.78, 0.43, 0.13, 0xFFEE7A34);
                r(g, x, y, s, 0.66, 0.38, 0.24, 0.035, 0xFFF4F4F8);
                r(g, x, y, s, 0.7, 0.43, 0.03, 0.07, 0xFF241A30); r(g, x, y, s, 0.78, 0.43, 0.03, 0.07, 0xFF241A30);
                r(g, x, y, s, 0.7, 0.8, 0.07, 0.09, 0xFF2A5AA8); r(g, x, y, s, 0.8, 0.8, 0.07, 0.09, 0xFF2A5AA8);
                d(g, x, y, s, 0.6, 0.55, 0.08, 0xFFFFE27A); d(g, x, y, s, 0.6, 0.55, 0.045, 0xFFFFFFFF);
                r(g, x, y, s, 0.59, 0.38, 0.02, 0.07, 0xFFFFE27A); r(g, x, y, s, 0.59, 0.66, 0.02, 0.07, 0xFFFFE27A);
                r(g, x, y, s, 0.47, 0.54, 0.06, 0.02, 0xFFFFE27A); r(g, x, y, s, 0.67, 0.54, 0.06, 0.02, 0xFFFFE27A);
            }
            case "ward" -> { // a hospital door with a red cross, a pale nurse in the dark and two red eyes
                r(g, x, y, s, 0.14, 0.2, 0.46, 0.7, 0xFF3C5A5E); r(g, x, y, s, 0.18, 0.24, 0.38, 0.66, 0xFF5E8A8C);
                r(g, x, y, s, 0.26, 0.32, 0.22, 0.16, 0xFF0C1418); r(g, x, y, s, 0.4, 0.62, 0.05, 0.05, 0xFFE0C860);
                r(g, x, y, s, 0.34, 0.06, 0.06, 0.18, 0xFFD02A3A); r(g, x, y, s, 0.28, 0.12, 0.18, 0.06, 0xFFD02A3A);
                d(g, x, y, s, 0.7, 0.42, 0.15, 0x33FF2A2A);
                r(g, x, y, s, 0.6, 0.5, 0.2, 0.4, 0xFFDDE4E6); d(g, x, y, s, 0.7, 0.38, 0.1, 0xFFEADFD6);
                r(g, x, y, s, 0.6, 0.26, 0.2, 0.08, 0xFFFFFFFF); r(g, x, y, s, 0.68, 0.22, 0.04, 0.12, 0xFFD02A3A);
                r(g, x, y, s, 0.64, 0.38, 0.04, 0.03, 0xFFFF2A2A); r(g, x, y, s, 0.73, 0.38, 0.04, 0.03, 0xFFFF2A2A);
                r(g, x, y, s, 0.68, 0.7, 0.04, 0.1, 0xFF7A0E16);
            }
            default -> d(g, x, y, s, 0.5, 0.5, 0.25, 0xFFFFFFFF);
        }
    }
}
