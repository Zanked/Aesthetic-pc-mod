package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Bird Sling: an Angry Birds style game. Pull the slingshot back with the mouse, let go and the bird flies at the
 * piggies' shelters. Wood, ice and stone blocks break, TNT goes off, towers fall, the piggies pop.
 * <p>
 * Six birds: red (plain), blue (splits in three on a click), yellow (a click makes it dash), black (a click, or a hit,
 * and it blows up), white (a click drops an egg bomb and the bird hops up) and the heavy one (a click slams it down;
 * it breaks stone). 24 levels in three worlds (meadow, frost, volcano), each with a boss at the end.
 * Three hearts: a lost level costs a heart and is played again; a boss gives a heart back.
 * <p>
 * The physics are a small home-made one: blocks are boxes that do not turn, but they slide off a support that
 * holds them only by an edge, so towers still fall over. Everything is simulated in three small steps per tick.
 * The levels live in {@link BirdLevels}.
 */
public class BirdSling extends MiniGame {
    static final int GY = 124;
    static final int WOOD = 0, ICE = 1, STONE = 2, TNT = 3;
    private static final int LEVELS = BirdLevels.COUNT, SUB = 3, LIVES = 3;
    private static final float DT = 1F / SUB, G = 0.11F, MAXD = 26F, VMAX = 5.6F, AX = 32F, AY = 97F, TH = 0.8F;
    private static final int K_BIRD = 0, K_PIG = 1, K_BLOCK = 2;
    private static final int RED = 0, BLUE = 1, YELLOW = 2, BLACK = 3, WHITE = 4, HEAVY = 5, EGG = 6;
    private static final int S_READY = 0, S_DRAG = 1, S_FLY = 2, S_CLEAR = 3, S_FAIL = 4;
    private static final String BIRD_CHARS = "RBYKWH";

    // wood, ice, stone, TNT
    private static final float[] M_HP = {5F, 3F, 12F, 1.5F}, M_DENS = {1F, 0.7F, 2.2F, 0.9F}, M_FRAG = {1F, 1.5F, 0.45F, 2.2F};
    private static final int[] M_COL = {0xFFC98B4E, 0xFFA9DDF5, 0xFF9A9AA8, 0xFFD8453A};
    // red, blue, yellow, black, white, heavy, egg
    private static final int[] B_COL = {0xFFE0453A, 0xFF4A8FE0, 0xFFF5D03A, 0xFF3A3A48, 0xFFF2F2F2, 0xFF8A2A2A, 0xFFFFF4D0};
    private static final float[] B_R = {4F, 4F, 4F, 4F, 4F, 6F, 2.5F}, B_M = {2F, 2F, 2F, 2.6F, 1.8F, 7F, 1.2F}, B_DMG = {1F, 1F, 1F, 1F, 1F, 1.6F, 1F};
    // piggy, piggy in a helmet, boss
    private static final float[] PIG_FRAG = {1.2F, 0.8F, 0.9F}, BOSS_HP = {12F, 20F, 18F};
    private static final int[] BOSS_COL = {0xFF7ED957, 0xFF8FD8F0, 0xFFB5503A};
    private static final int[] M_DARK = new int[4], M_LIGHT = new int[4], B_DARK = new int[7], B_LIGHT = new int[7];
    // the three worlds: sky top and bottom, far and near hills, grass (top, bottom, edge), soil (top, bottom), cloud, sun
    private static final int[] SKY_T = {0xFF6FCBFF, 0xFF8FB8E8, 0xFF3A2048}, SKY_B = {0xFFDDF5FF, 0xFFEAF4FF, 0xFFFF9A5A};
    private static final int[] HILL_A = {0xFF8FD87A, 0xFFE4F0FA, 0xFF5A2A3A}, HILL_B = {0xFF7ACB68, 0xFFCFE2F4, 0xFF442030};
    private static final int[] GR_T = {0xFF6BCF58, 0xFFF4FAFF, 0xFF5A4A48}, GR_B = {0xFF3F9A3A, 0xFFBFD8EE, 0xFF3A2C2C};
    private static final int[] GR_E = {0xFF7EE05F, 0xFFFFFFFF, 0xFF7A6A66};
    private static final int[] DIRT_T = {0xFF9A6A3E, 0xFF8AA0B8, 0xFF4A3030}, DIRT_B = {0xFF6E4526, 0xFF6C849C, 0xFF2A1A1A};
    private static final int[] CLOUD = {0xCCFFFFFF, 0xCCFFFFFF, 0x66301828}, SUN = {0xFFFFF6C8, 0xFFFFFFFF, 0xFFFF6A3A};

    static {
        for (int i = 0; i < 4; i++) { M_DARK[i] = Gfx.darker(M_COL[i], 0.25F); M_LIGHT[i] = Gfx.lighter(M_COL[i], 0.35F); }
        for (int i = 0; i < 7; i++) { B_DARK[i] = Gfx.darker(B_COL[i], 0.45F); B_LIGHT[i] = Gfx.lighter(B_COL[i], 0.6F); }
    }

    private static final class Body {
        final int kind;
        int type, var, age, hit, still;
        float x, y, vx, vy, w, h, r, rad, hp, maxHp, mass, inv;
        boolean dead, used, child;
        float supL, supR;                 // what holds it from below this step: the span of the supports (a box falls over a ledge)

        Body(int kind) { this.kind = kind; }
    }

    private static final class Fx {
        float x, y, vx, vy, rad;
        int life, max, kind, col;
        String txt;
    }

    private final List<Body> bodies = new ArrayList<>(), pending = new ArrayList<>();
    private final List<Fx> fx = new ArrayList<>();
    private int[] queue = new int[0];
    private int qi, cur, level, lives, state, stateT, scoreBase, time, flyT, calm, winT, hop, bannerT, sfxCool;
    private int pigCount, combo, lastKill, stars, world;
    private float px, py, wind;
    private Body lead, boss;
    private boolean won;
    private String lvText = "", bannerA = "", clearText, failText;

    // ------------------------------------------------------------------ start

    @Override
    public void reset() {
        score = 0; over = false; won = false; lives = LIVES; scoreBase = 0; time = 0;
        startLevel(0);
    }

    void startLevel(int n) {
        level = n;
        world = n / 8;
        scoreBase = score;
        bodies.clear(); pending.clear(); fx.clear();
        String q = BirdLevels.QUEUES[n];
        queue = new int[q.length()];
        for (int i = 0; i < queue.length; i++) queue[i] = BIRD_CHARS.indexOf(q.charAt(i));
        qi = 0; lead = null; boss = null; flyT = 0; calm = 0; winT = 0; combo = 0; lastKill = -1000; bannerT = 130;
        wind = BirdLevels.wind(n);
        BirdLevels.build(this, n);
        for (Body b : bodies) if (b.kind == K_PIG && b.type == 2) boss = b;
        pigCount = countPigs();
        // the texts are made once per level, not once per frame
        lvText = Component.translatable("cutemod.birds.level", n + 1, LEVELS).getString();
        if (n % 8 == 7) bannerA = Component.translatable("cutemod.birds.bossfmt", Component.translatable("cutemod.birds.boss." + world).getString()).getString();
        else if (n % 8 == 0) bannerA = Component.translatable("cutemod.birds.world." + world).getString();
        else bannerA = "";
        if (clearText == null) {
            clearText = Component.translatable("cutemod.birds.clear").getString();
            failText = Component.translatable("cutemod.birds.fail").getString();
        }
        loadNext();
    }

    private void loadNext() {
        cur = queue[qi++];
        state = S_READY;
        hop = 24;
        px = AX; py = AY;
    }

    private int countPigs() {
        int n = 0;
        for (int i = 0, m = bodies.size(); i < m; i++) { Body b = bodies.get(i); if (b.kind == K_PIG && !b.dead) n++; }
        return n;
    }

    int pigsLeft() { return pigCount; }

    int birdsLeft() { return queue.length - qi + (cur >= 0 ? 1 : 0); }

    int state() { return state; }

    int level() { return level; }

    int lives() { return lives; }

    // ------------------------------------------------------------------ building (called by the levels)

    private Body mkBlock(int mat, float left, float bottom, int w, int h) {
        Body b = new Body(K_BLOCK);
        b.type = mat; b.w = w; b.h = h;
        b.x = left + w / 2F; b.y = bottom - h / 2F;
        b.rad = (float) Math.sqrt(w * w + h * h) / 2F;
        b.maxHp = b.hp = M_HP[mat] * Math.max(0.6F, Math.min(1.6F, (float) Math.sqrt(w * h / 80F)));
        b.mass = Math.max(0.6F, w * h * M_DENS[mat] / 40F);
        b.inv = 1F / b.mass;
        return b;
    }

    private Body mkPig(int type, int var, float cx, float bottom) {
        Body b = new Body(K_PIG);
        b.type = type; b.var = var;
        b.r = type == 2 ? 9F : 5F; b.rad = b.r;
        b.x = cx; b.y = bottom - b.r;
        b.maxHp = b.hp = type == 0 ? 4F : type == 1 ? 9F : BOSS_HP[var];
        b.mass = type == 2 ? 3.6F : type == 1 ? 1.3F : 1.1F;
        b.inv = 1F / b.mass;
        return b;
    }

    void blk(int mat, int left, int bottom, int w, int h) { bodies.add(mkBlock(mat, left, bottom, w, h)); }

    void tnt(int left, int bottom) { blk(TNT, left, bottom, 8, 8); }

    void pig(int cx, int bottom) { bodies.add(mkPig(0, 0, cx, bottom)); }

    void helm(int cx, int bottom) { bodies.add(mkPig(1, 0, cx, bottom)); }

    void boss(int var, int cx, int bottom) { bodies.add(mkPig(2, var, cx, bottom)); }

    // ------------------------------------------------------------------ input

    private void pocket(int mxv, int myv) {
        float dx = mxv - AX, dy = myv - AY, len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len > MAXD) { dx *= MAXD / len; dy *= MAXD / len; }
        px = AX + dx;
        py = Math.min(AY + dy, GY - 5F);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        if (state == S_READY && cur >= 0 && hop <= 0) {
            state = S_DRAG;
            pocket(x, y);
            sound(SoundEvents.CROSSBOW_SHOOT, 0.6F, 0.25F);
            return true;
        }
        if (state == S_FLY) { ability(); return true; }
        return false;
    }

    @Override
    public boolean release(int x, int y, int button) {
        if (state != S_DRAG) return false;
        pocket(x, y);
        if (AX - px >= 4F) fire(); else { state = S_READY; px = AX; py = AY; }
        return true;
    }

    @Override
    public boolean key(int keyCode) {
        if (keyCode == KEY_SPACE && state == S_FLY) { ability(); return true; }
        return false;
    }

    private void fire() {
        Body b = new Body(K_BIRD);
        b.type = cur; b.r = B_R[cur]; b.rad = b.r; b.x = px; b.y = py;
        b.vx = (AX - px) * VMAX / MAXD; b.vy = (AY - py) * VMAX / MAXD;
        b.mass = B_M[cur]; b.inv = 1F / b.mass;
        bodies.add(b);
        lead = b;
        cur = -1;
        state = S_FLY; flyT = 0; calm = 0; winT = 0;
        sound(SoundEvents.CROSSBOW_SHOOT, 1.2F, 0.7F);
        sound(SoundEvents.PARROT_AMBIENT, 1.5F, 0.4F);
    }

    private void ability() {
        Body b = lead;
        if (b == null || b.dead || b.used) return;
        b.used = true;
        switch (b.type) {
            case BLUE -> {
                for (int s = -1; s <= 1; s += 2) {
                    Body c = new Body(K_BIRD);
                    c.type = BLUE; c.r = 3.5F; c.rad = c.r; c.child = true; c.used = true;
                    c.x = b.x; c.y = b.y + s * 2F;
                    float a = s * 0.26F, ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                    c.vx = b.vx * ca - b.vy * sa; c.vy = b.vx * sa + b.vy * ca;
                    c.mass = 1.4F; c.inv = 1F / c.mass; c.hit = b.hit;
                    bodies.add(c);
                }
                puff(b.x, b.y, 0xFFBFE0FF, 6);
                sound(SoundEvents.PARROT_AMBIENT, 1.9F, 0.5F);
            }
            case YELLOW -> {
                b.vx *= 1.8F; b.vy *= 1.8F;
                puff(b.x, b.y, 0xFFFFF2A0, 6);
                sound(SoundEvents.FIREWORK_ROCKET_BLAST, 1.6F, 0.5F);
            }
            case BLACK -> boom(b.x, b.y, b, 28F, 13F);
            case WHITE -> {                                 // an egg bomb drops, the bird hops up and on
                Body e = new Body(K_BIRD);
                e.type = EGG; e.r = B_R[EGG]; e.rad = e.r; e.child = true; e.used = true;
                e.x = b.x; e.y = b.y + 5F; e.vx = b.vx * 0.3F; e.vy = 2.4F;
                e.mass = B_M[EGG]; e.inv = 1F / e.mass;
                bodies.add(e);
                b.vy = -2.2F; b.vx *= 1.25F;
                puff(b.x, b.y, 0xFFFFFFFF, 5);
                sound(SoundEvents.PARROT_AMBIENT, 1.2F, 0.5F);
            }
            case HEAVY -> {                                 // slams down
                b.vy = Math.max(b.vy, 0F) + 4.8F; b.vx *= 0.35F;
                puff(b.x, b.y, 0xFFE0C0A0, 6);
                sound(SoundEvents.SLIME_SQUISH, 0.6F, 0.6F);
            }
            default -> sound(SoundEvents.PARROT_AMBIENT, 1.3F, 0.4F);
        }
    }

    /** A blast: pushes and hurts everything near, more the nearer it is. */
    private void boom(float x, float y, Body self, float rad, float dmg) {
        for (int i = 0, n = bodies.size(); i < n; i++) {
            Body b = bodies.get(i);
            if (b.dead || b == self || b.kind == K_BIRD) continue;
            float dx = b.x - x, dy = b.y - y, d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d >= rad) continue;
            float f = 1F - d / rad;
            if (d < 0.01F) { dx = 0; dy = -1; d = 1; }
            float dv = 5.5F * f / (float) Math.sqrt(b.mass);
            b.vx += dx / d * dv;
            b.vy += dy / d * dv - 0.5F * f;
            hurt(b, dmg * f);
        }
        if (self != null) self.dead = true;
        Fx r = new Fx();
        r.kind = 2; r.x = x; r.y = y; r.rad = rad; r.life = r.max = 16;
        fx.add(r);
        puff(x, y, 0xFFFFB347, rad > 20F ? 12 : 6);
        sound(SoundEvents.GENERIC_EXPLODE, rad > 20F ? 1.1F : 1.6F, rad > 20F ? 0.8F : 0.5F);
    }

    // ------------------------------------------------------------------ physics

    @Override
    public void tick() {
        time++;
        if (bannerT > 0) bannerT--;
        if (sfxCool > 0) sfxCool--;
        if (hop > 0) hop--;
        if (state == S_DRAG) pocket(mx, my);
        stepWorld();
        tickFx();
        if (state <= S_FLY) {                                // the last piggy is gone, whatever the birds are doing
            if (pigCount == 0) { if (++winT > 45) win(); }
            else winT = 0;
        }
        switch (state) {
            case S_FLY -> {
                flyT++;
                boolean birds = false;
                for (int i = 0, n = bodies.size(); i < n; i++) { Body b = bodies.get(i); if (b.kind == K_BIRD && !b.dead) { birds = true; break; } }
                if (pigCount > 0 && ((!birds && (calm > 40 || flyT > 900)) || flyT > 1500)) afterShot();
            }
            case S_CLEAR -> {
                if (--stateT <= 0) {
                    if (level + 1 >= LEVELS) { score += lives * 50; won = true; over = true; }
                    else startLevel(level + 1);
                }
            }
            case S_FAIL -> {
                if (--stateT <= 0) {
                    if (lives <= 0) { won = false; over = true; }
                    else startLevel(level);
                }
            }
            default -> { }
        }
    }

    private void afterShot() {
        if (qi < queue.length) { loadNext(); return; }
        lives--;
        score = scoreBase;
        state = S_FAIL; stateT = 110;
        sound(SoundEvents.PIG_HURT, 0.7F, 0.8F);
    }

    private void win() {
        int spare = birdsLeft();
        int bonus = spare * 20;
        stars = spare >= 2 ? 3 : spare == 1 ? 2 : 1;
        if (level % 8 == 7) {                                // a boss is down: a bonus and a heart back
            bonus += 500;
            lives = Math.min(LIVES, lives + 1);
        }
        score += bonus;
        state = S_CLEAR; stateT = level % 8 == 7 ? 190 : 150;
        if (bonus > 0) pts(W / 2F, 66, bonus);
        sound(SoundEvents.PLAYER_LEVELUP, 1.1F, 0.8F);
    }

    private void stepWorld() {
        for (int s = 0; s < SUB; s++) substep();
        float maxV = 0;
        for (int i = 0, n = bodies.size(); i < n; i++) {
            Body b = bodies.get(i);
            if (b.dead) continue;
            float v = Math.abs(b.vx) + Math.abs(b.vy);
            if (b.kind == K_BIRD) {
                b.age++;
                if (b.hit > 0) b.hit++;
                b.still = v < 0.12F ? b.still + 1 : 0;
                if (b.type == EGG) {
                    if (b.hit > 0) { boom(b.x, b.y, b, 18F, 9F); continue; }
                } else if (b.type == BLACK && !b.used && b.hit > 70) { b.used = true; boom(b.x, b.y, b, 28F, 13F); continue; }
                if (b.x < -20 || b.x > W + 25 || b.y > H + 20 || b.still > 35 || b.hit > 240) {
                    b.dead = true;
                    puff(b.x, Math.min(b.y, GY - 2F), B_COL[b.type], 4);
                }
            } else {
                maxV = Math.max(maxV, v);
                if (b.x > W + 20 || b.x < -30 || b.y > H + 30) kill(b);
            }
        }
        calm = maxV < 0.05F ? calm + 1 : 0;
        if (!pending.isEmpty()) { bodies.addAll(pending); pending.clear(); }
        int w = 0;                                           // drop the dead ones
        for (int i = 0, n = bodies.size(); i < n; i++) { Body b = bodies.get(i); if (!b.dead) bodies.set(w++, b); }
        for (int i = bodies.size() - 1; i >= w; i--) bodies.remove(i);
        pigCount = countPigs();
    }

    private void substep() {
        int n = bodies.size();
        for (int i = 0; i < n; i++) {
            Body b = bodies.get(i);
            if (b.dead) continue;
            b.supL = Float.MAX_VALUE; b.supR = -Float.MAX_VALUE;
            b.vy += G * DT;
            if (b.kind == K_BIRD && wind != 0F) b.vx += wind * DT;
            b.x += b.vx * DT;
            b.y += b.vy * DT;
            if (b.kind != K_BIRD) {                          // invisible walls: nothing is blown out of the picture
                float half = b.kind == K_BLOCK ? b.w / 2F : b.r;
                if (b.x > W - 1 - half) { b.x = W - 1 - half; if (b.vx > 0) b.vx *= -0.2F; }
                else if (b.x < 44 + half) { b.x = 44 + half; if (b.vx < 0) b.vx *= -0.2F; }
            }
            float bottom = b.kind == K_BLOCK ? b.y + b.h / 2F : b.y + b.r;
            if (bottom > GY) {
                b.y -= bottom - GY;
                float vn = b.vy;
                if (vn > 0) {
                    if (b.kind == K_BIRD) { if (vn > 0.3F && b.hit == 0) b.hit = 1; }
                    else if (vn > 1.1F) hurt(b, (vn - 1.1F) * 2F);
                    float e = vn > 1.2F ? (b.kind == K_BIRD ? 0.3F : 0.12F) : 0F;
                    b.vy = -vn * e;
                    if (vn > 1.6F && b.kind != K_BLOCK) sound(SoundEvents.SLIME_SQUISH, 1.3F, 0.15F);
                }
                b.vx *= b.kind == K_BLOCK ? 0.9F : (b.kind == K_BIRD ? 0.97F : 0.96F);
                b.supL = -1e9F; b.supR = 1e9F;
            }
        }
        for (int i = 0; i < n; i++) {
            Body a = bodies.get(i);
            if (a.dead) continue;
            for (int j = i + 1; j < n; j++) {
                Body b = bodies.get(j);
                if (b.dead || a.dead) continue;
                float dx = b.x - a.x, dy = b.y - a.y, reach = a.rad + b.rad;
                if (dx * dx + dy * dy > reach * reach) continue;     // too far apart to touch
                collide(a, b);
            }
        }
        for (int i = 0; i < n; i++) {                        // held only by a ledge: the box slides off it and falls
            Body b = bodies.get(i);
            if (b.dead || b.kind != K_BLOCK || b.supR < b.supL) continue;
            if (b.x < b.supL - 0.5F) b.vx -= 0.03F;
            else if (b.x > b.supR + 0.5F) b.vx += 0.03F;
        }
    }

    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : Math.min(v, hi); }

    private void collide(Body a, Body b) {
        if (a.kind == K_BIRD && b.kind == K_BIRD) return;
        boolean ac = a.kind != K_BLOCK, bc = b.kind != K_BLOCK;
        float nx, ny, pen;
        if (!ac && !bc) {
            float ox = (a.w + b.w) / 2F - Math.abs(b.x - a.x), oy = (a.h + b.h) / 2F - Math.abs(b.y - a.y);
            if (ox <= 0 || oy <= 0) return;
            if (ox < oy) { nx = b.x > a.x ? 1 : -1; ny = 0; pen = ox; }
            else { nx = 0; ny = b.y > a.y ? 1 : -1; pen = oy; }
        } else if (ac && bc) {
            float dx = b.x - a.x, dy = b.y - a.y, d2 = dx * dx + dy * dy, rr = a.r + b.r;
            if (d2 >= rr * rr) return;
            float d = (float) Math.sqrt(d2);
            if (d < 1e-4F) { nx = 0; ny = -1; } else { nx = dx / d; ny = dy / d; }
            pen = rr - d;
        } else {
            Body c = ac ? a : b, k = ac ? b : a;
            float hx = k.w / 2F, hy = k.h / 2F;
            float qx = clamp(c.x, k.x - hx, k.x + hx), qy = clamp(c.y, k.y - hy, k.y + hy);
            float dx = c.x - qx, dy = c.y - qy, d2 = dx * dx + dy * dy;
            if (d2 > c.r * c.r) return;
            float cnx, cny, cpen;                       // the normal from the box to the circle
            if (d2 > 1e-6F) {
                float d = (float) Math.sqrt(d2);
                cnx = dx / d; cny = dy / d; cpen = c.r - d;
            } else {                                    // the centre is inside the box: out along the shortest way
                float ox = hx - Math.abs(c.x - k.x), oy = hy - Math.abs(c.y - k.y);
                if (ox < oy) { cnx = c.x > k.x ? 1 : -1; cny = 0; cpen = ox + c.r; }
                else { cnx = 0; cny = c.y > k.y ? 1 : -1; cpen = oy + c.r; }
            }
            if (ac) { nx = -cnx; ny = -cny; } else { nx = cnx; ny = cny; }
            pen = cpen;
        }
        resolve(a, b, nx, ny, pen);
    }

    /** n points from a to b. */
    private void resolve(Body a, Body b, float nx, float ny, float pen) {
        float ia = a.inv, ib = b.inv, is = ia + ib;
        float corr = pen / is;
        a.x -= nx * corr * ia; a.y -= ny * corr * ia;
        b.x += nx * corr * ib; b.y += ny * corr * ib;
        float rvx = b.vx - a.vx, rvy = b.vy - a.vy;
        float vn = rvx * nx + rvy * ny;
        if (ny != 0) {                                   // note what holds the upper one of the two
            Body top = ny > 0 ? a : b, bot = ny > 0 ? b : a;
            if (top.kind == K_BLOCK) {
                float half = bot.kind == K_BLOCK ? bot.w / 2F : bot.r;
                top.supL = Math.min(top.supL, bot.x - half);
                top.supR = Math.max(top.supR, bot.x + half);
            }
        }
        if (vn >= 0) return;
        float impact = -vn;
        float e = impact > 1.4F ? 0.22F : 0F;
        float j = -(1F + e) * vn / is;
        a.vx -= j * ia * nx; a.vy -= j * ia * ny;
        b.vx += j * ib * nx; b.vy += j * ib * ny;
        float tx = rvx - vn * nx, ty = rvy - vn * ny, tl = (float) Math.sqrt(tx * tx + ty * ty);
        if (tl > 1e-5F) {
            tx /= tl; ty /= tl;
            float jt = Math.min(tl / is, 0.4F * j);
            a.vx += jt * ia * tx; a.vy += jt * ia * ty;
            b.vx -= jt * ib * tx; b.vy -= jt * ib * ty;
        }
        if (a.kind == K_BIRD && a.hit == 0) a.hit = 1;
        if (b.kind == K_BIRD && b.hit == 0) b.hit = 1;
        if (impact > TH) {
            float sum = a.mass + b.mass, k = 2.4F * (impact - TH);
            hurt(a, k * b.mass / sum * punch(b, a));
            hurt(b, k * a.mass / sum * punch(a, b));
        }
    }

    /** How hard the attacker hits: the heavy bird is strong, and much stronger against stone. */
    private static float punch(Body att, Body target) {
        if (att.kind != K_BIRD) return 1F;
        float m = B_DMG[att.type];
        if (att.type == HEAVY && target.kind == K_BLOCK && target.type == STONE) m *= 2.5F;
        return m;
    }

    private void hurt(Body b, float d) {
        if (b.kind == K_BIRD || b.dead || d <= 0) return;
        float f = b.kind == K_PIG ? PIG_FRAG[b.type] : M_FRAG[b.type];
        b.hp -= d * f;
        if (b.hp <= 0) kill(b);
        else {
            if (b.kind == K_PIG && b.type == 2 && !b.used && b.hp <= b.maxHp * 0.5F) rage(b);
            if (d * f > 0.6F) hitSound(b);
        }
    }

    /** The boss, half beaten, loses his temper and calls for help (once). */
    private void rage(Body b) {
        b.used = true;
        switch (b.var) {
            case 0 -> {                                     // the King: two piggies
                Body l = mkPig(0, 0, b.x - 15F, b.y - 8F), r = mkPig(0, 0, b.x + 15F, b.y - 8F);
                l.vx = -0.9F; l.vy = -1.2F; r.vx = 0.9F; r.vy = -1.2F;
                pending.add(l); pending.add(r);
            }
            case 1 -> {                                     // the Queen: a wall of ice falls in front of her
                pending.add(mkBlock(ICE, b.x - 21F, b.y - 30F, 6, 16));
                pending.add(mkBlock(ICE, b.x - 21F, b.y - 50F, 6, 16));
            }
            default -> {                                    // the Overlord: two guards in helmets and a crate of TNT
                Body l = mkPig(1, 0, b.x - 16F, b.y - 8F), r = mkPig(1, 0, b.x + 16F, b.y - 8F);
                l.vx = -0.9F; l.vy = -1.2F; r.vx = 0.9F; r.vy = -1.2F;
                pending.add(l); pending.add(r);
                pending.add(mkBlock(TNT, b.x - 4F, b.y - 26F, 8, 8));
            }
        }
        Fx f = new Fx();
        f.kind = 3; f.x = b.x; f.y = b.y - 16F; f.vy = -0.2F; f.life = f.max = 70; f.txt = "!!";
        fx.add(f);
        puff(b.x, b.y, 0xFFFF8A6A, 10);
        sound(SoundEvents.PIG_HURT, 0.5F, 1F);
        sound(SoundEvents.WARDEN_ROAR, 0.8F, 0.6F);
    }

    private void hitSound(Body b) {
        if (sfxCool > 0) return;
        sfxCool = 5;
        if (b.kind == K_PIG) sound(SoundEvents.PIG_HURT, b.type == 2 ? 0.7F : 1.5F, 0.5F);
        else if (b.type == WOOD || b.type == TNT) sound(SoundEvents.WOOD_HIT, 1F, 0.8F);
        else if (b.type == ICE) sound(SoundEvents.GLASS_BREAK, 1.8F, 0.3F);
        else sound(SoundEvents.STONE_HIT, 0.9F, 0.8F);
    }

    private void kill(Body b) {
        if (b.dead) return;
        b.dead = true;
        if (b.kind == K_PIG) {
            combo = time - lastKill < 90 ? combo + 1 : 1;     // piggies popped one after another are worth more
            lastKill = time;
            int p = (b.type == 2 ? 300 : b.type == 1 ? 80 : 50) + (combo - 1) * 25;
            score += p;
            pts(b.x, b.y - 6, p, combo);
            puff(b.x, b.y, b.type == 2 ? BOSS_COL[b.var] : 0xFFB5F08A, b.type == 2 ? 18 : 8);
            sound(SoundEvents.PIG_DEATH, b.type == 2 ? 0.6F : 1.5F, 0.7F);
        } else {
            int p = b.type == WOOD ? 10 : b.type == ICE ? 8 : b.type == STONE ? 20 : 5;
            score += p;
            pts(b.x, b.y - 4, p, 1);
            chips(b);
            if (b.type == TNT) boom(b.x, b.y, b, 26F, 11F);
            else if (b.type == WOOD) sound(SoundEvents.WOOD_BREAK, 1F, 0.8F);
            else if (b.type == ICE) sound(SoundEvents.GLASS_BREAK, 1.2F, 0.7F);
            else sound(SoundEvents.STONE_BREAK, 0.9F, 0.8F);
        }
    }

    // ------------------------------------------------------------------ effects

    private void addFx(Fx f) { if (fx.size() < 160) fx.add(f); }

    private void pts(float x, float y, int v) { pts(x, y, v, 1); }

    private void pts(float x, float y, int v, int cmb) {
        Fx f = new Fx();
        f.kind = 3; f.x = x; f.y = y; f.vy = -0.35F; f.life = f.max = 50;
        f.txt = cmb > 1 ? "+" + v + " x" + cmb : "+" + v;
        addFx(f);
    }

    private void puff(float x, float y, int col, int n) {
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.kind = 1; f.x = x; f.y = y; f.col = col;
            f.vx = (rnd.nextFloat() - 0.5F) * 2.4F; f.vy = (rnd.nextFloat() - 0.7F) * 2.2F;
            f.life = f.max = 16 + rnd.nextInt(10);
            addFx(f);
        }
    }

    private void chips(Body b) {
        int n = Math.min(14, Math.max(4, (int) (b.w * b.h / 30F)));
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.kind = 0; f.col = M_COL[b.type];
            f.x = b.x + (rnd.nextFloat() - 0.5F) * b.w; f.y = b.y + (rnd.nextFloat() - 0.5F) * b.h;
            f.vx = (rnd.nextFloat() - 0.5F) * 2.6F; f.vy = -rnd.nextFloat() * 2F;
            f.life = f.max = 30 + rnd.nextInt(20);
            addFx(f);
        }
    }

    private void tickFx() {
        int w = 0;
        for (int i = 0, n = fx.size(); i < n; i++) {
            Fx f = fx.get(i);
            f.life--;
            f.x += f.vx; f.y += f.vy;
            if (f.kind == 0) f.vy += 0.1F;
            else if (f.kind == 1) { f.vx *= 0.94F; f.vy *= 0.94F; }
            if (f.life > 0) fx.set(w++, f);
        }
        for (int i = fx.size() - 1; i >= w; i--) fx.remove(i);
    }

    // ------------------------------------------------------------------ drawing

    private static void hill(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= 0; dy += 2) {                // only the upper half: the rest is under the ground
            double k = 1.0 - (dy * dy) / ((ry + 0.5) * (ry + 0.5));
            int dx = (int) Math.floor((rx + 0.5) * Math.sqrt(Math.max(0, k)));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 2, argb);
        }
    }

    private void backdrop(GuiGraphics g) {
        int w = world;
        g.fillGradient(0, 0, W, GY, SKY_T[w], SKY_B[w]);
        int sy = w == 2 ? 40 : 18;
        disc(g, 190, sy, w == 2 ? 15 : 13, Gfx.alpha(SUN[w], 70));
        disc(g, 190, sy, 10, Gfx.alpha(SUN[w], 130));
        disc(g, 190, sy, 8, SUN[w]);
        for (int i = 0; i < 2; i++) Gfx.cloud(g, (int) ((i * 110 + time * 0.08F) % (W + 50)) - 30, 16 + i * 18, 32 + i * 6, CLOUD[w]);
        hill(g, 60, GY, 70, 24, HILL_A[w]);
        hill(g, 170, GY, 80, 16, HILL_B[w]);
        g.fillGradient(0, GY, W, H, GR_T[w], GR_B[w]);
        g.fill(0, GY + 2, W, H, DIRT_T[w]);
        g.fillGradient(0, GY + 2, W, H, DIRT_T[w], DIRT_B[w]);
        g.fill(0, GY, W, GY + 3, GR_E[w]);
        if (w == 1) {                                          // snow
            for (int i = 0; i < 16; i++) {
                int x = (int) ((i * 53 + time * (0.25F + (i % 3) * 0.12F)) % W), y = (int) ((i * 29 + time * (0.35F + (i % 4) * 0.1F)) % GY);
                g.fill(x, y, x + 1 + (i & 1), y + 1 + (i & 1), 0xCCFFFFFF);
            }
        } else if (w == 2) {                                   // embers
            for (int i = 0; i < 14; i++) {
                int x = (i * 61 + (int) (Math.sin((time + i * 17) * 0.05) * 6)) % W, y = GY - (int) ((time * (0.3F + (i % 3) * 0.15F) + i * 19) % GY);
                g.fill(x, y, x + 1, y + 1, 0xCCFFA040);
            }
        }
    }

    @Override
    public void render(GuiGraphics g) {
        backdrop(g);
        // the birds that wait on the ground
        for (int i = 0; i < queue.length - qi; i++) drawBird(g, 24 - 7 * i, GY - 4, queue[qi + i], 4);
        drawSlingBack(g);
        for (int i = 0, n = bodies.size(); i < n; i++) { Body b = bodies.get(i); if (b.kind == K_BLOCK) drawBlock(g, b); }
        for (int i = 0, n = bodies.size(); i < n; i++) { Body b = bodies.get(i); if (b.kind == K_PIG) drawPig(g, b); }
        for (int i = 0, n = bodies.size(); i < n; i++) { Body b = bodies.get(i); if (b.kind == K_BIRD) drawBird(g, Math.round(b.x), Math.round(b.y), b.type, Math.round(b.r)); }
        float bx = AX, by = AY;
        if (cur >= 0) {
            if (state == S_DRAG) { bx = px; by = py; }
            else if (hop > 0) {
                float t = hop / 24F, hy = (float) Math.sin(t * Math.PI) * 14F;
                bx = AX + (24F - AX) * t; by = AY + (GY - 4F - AY) * t - hy;
            }
            if (state == S_DRAG) { drawGuide(g); drawBands(g, bx, by, true); } else drawBands(g, AX, AY, false);
            drawBird(g, Math.round(bx), Math.round(by), cur, Math.round(B_R[cur]));
        } else drawBands(g, AX, AY, false);
        drawSlingFront(g);

        for (int i = 0, n = fx.size(); i < n; i++) drawFx(g, fx.get(i));
        hud(g);
    }

    private void drawSlingBack(GuiGraphics g) {
        int x = (int) AX;
        g.fill(x - 2, 100, x + 3, GY, 0xFF6B3F1E);
        g.fill(x - 1, 100, x + 1, GY, 0xFF8A5A2E);
        Gfx.line(g, x + 2, 100, x + 4, 92, 0xFF54300F);
        Gfx.line(g, x + 3, 100, x + 5, 92, 0xFF54300F);
    }

    private void drawSlingFront(GuiGraphics g) {
        int x = (int) AX;
        Gfx.line(g, x - 2, 100, x - 4, 92, 0xFF8A5A2E);
        Gfx.line(g, x - 1, 100, x - 3, 92, 0xFFA8713A);
        g.fill(x - 5, 91, x - 2, 93, 0xFF6B3F1E);
    }

    private void drawBands(GuiGraphics g, float bx, float by, boolean stretched) {
        int col = stretched ? 0xFF3A1E0C : 0xFF4A2A14;
        Gfx.line(g, (int) AX - 4, 92, Math.round(bx) - 1, Math.round(by), col);
        Gfx.line(g, (int) AX + 4, 92, Math.round(bx) + 1, Math.round(by), col);
    }

    private void drawGuide(GuiGraphics g) {
        float x = px, y = py, vx = (AX - px) * VMAX / MAXD, vy = (AY - py) * VMAX / MAXD;
        for (int t = 1; t <= 48; t++) {
            vy += G; vx += wind; x += vx; y += vy;
            if (y > GY - 2) break;
            if (t % 4 == 0) {
                int a = 255 - t * 3, rx = Math.round(x), ry = Math.round(y);
                g.fill(rx, ry + 1, rx + 2, ry + 3, Gfx.alpha(0xFF2A5A7A, a / 3));
                g.fill(rx, ry, rx + 2, ry + 2, Gfx.alpha(0xFFFFFFFF, a));
            }
        }
    }

    private static void drawBird(GuiGraphics g, int cx, int cy, int type, int r) {
        int col = B_COL[type];
        if (type == EGG) {
            disc(g, cx, cy, r, 0xFFE8D8A8);
            disc(g, cx, cy, Math.max(1, r - 1), col);
            g.fill(cx - 1, cy - 1, cx, cy, 0xFFFFFFFF);
            return;
        }
        Gfx.ball(g, cx, cy, r, col);
        if (r >= 6) {                                                                         // the heavy one
            g.fill(cx - 3, cy - r - 1, cx + 3, cy - r + 1, B_DARK[type]);
            Gfx.ellipse(g, cx, cy + 3, 4, 2, B_LIGHT[type]);
            g.fill(cx - 1, cy - 3, cx + 2, cy, 0xFFFFFFFF);
            g.fill(cx + 3, cy - 3, cx + 6, cy, 0xFFFFFFFF);
            g.fill(cx + 1, cy - 2, cx + 2, cy, 0xFF1A1428);
            g.fill(cx + 4, cy - 2, cx + 5, cy, 0xFF1A1428);
            g.fill(cx - 2, cy - 5, cx + 7, cy - 3, 0xFF3A0E0E);
            g.fill(cx + r, cy, cx + r + 3, cy + 3, 0xFFF5A030);
            return;
        }
        if (type == BLACK) g.fill(cx - 1, cy - r - 2, cx + 1, cy - r, 0xFFE0A030);          // the fuse
        else g.fill(cx - 2, cy - r, cx + 1, cy - r + 1, type == WHITE ? 0xFFE0453A : B_DARK[type]);  // a tuft
        Gfx.ellipse(g, cx, cy + 2, 2, 1, type == WHITE ? 0xFFD8E8F0 : B_LIGHT[type]);        // the belly
        g.fill(cx, cy - 2, cx + 2, cy, 0xFFFFFFFF);
        g.fill(cx + 2, cy - 2, cx + 4, cy, 0xFFFFFFFF);
        g.fill(cx + 1, cy - 1, cx + 2, cy, 0xFF1A1428);
        g.fill(cx + 3, cy - 1, cx + 4, cy, 0xFF1A1428);
        g.fill(cx - 1, cy - 3, cx + 5, cy - 2, type == WHITE ? 0xFF7A7A88 : B_DARK[type]);  // the angry brow
        g.fill(cx + r, cy, cx + r + 2, cy + 2, 0xFFF5A030);                                  // the beak
    }

    private void drawPig(GuiGraphics g, Body b) {
        int cx = Math.round(b.x), cy = Math.round(b.y);
        if (b.type == 2) { drawBoss(g, b, cx, cy); return; }
        float k = b.hp / b.maxHp;
        Gfx.ball(g, cx, cy, 5, 0xFF7ED957);
        g.fill(cx - 4, cy - 6, cx - 2, cy - 4, 0xFF5FB840);
        g.fill(cx + 2, cy - 6, cx + 4, cy - 4, 0xFF5FB840);
        g.fill(cx - 3, cy - 2, cx - 1, cy, 0xFFFFFFFF);
        g.fill(cx + 1, cy - 2, cx + 3, cy, 0xFFFFFFFF);
        g.fill(cx - 2, cy - 1, cx - 1, cy, 0xFF1A1428);
        g.fill(cx + 2, cy - 1, cx + 3, cy, 0xFF1A1428);
        Gfx.ellipse(g, cx, cy + 2, 3, 2, 0xFFA6EC82);
        g.fill(cx - 1, cy + 1, cx, cy + 3, 0xFF3F8A2A);
        g.fill(cx + 1, cy + 1, cx + 2, cy + 3, 0xFF3F8A2A);
        if (b.type == 1) {                                                                  // the helmet
            g.fill(cx - 5, cy - 5, cx + 5, cy - 3, 0xFF8A93A6);
            g.fill(cx - 4, cy - 7, cx + 4, cy - 5, 0xFFB4BDD0);
            g.fill(cx - 1, cy - 8, cx + 1, cy - 7, 0xFFD6DCEA);
        } else {
            if (k < 0.6F) g.fill(cx - 4, cy - 4, cx - 2, cy - 3, 0xFF6A9A4A);              // a bruise
            if (k < 0.3F) g.fill(cx + 1, cy - 5, cx + 4, cy - 4, 0xFFFFFFFF);              // a bandage
        }
    }

    private void drawBoss(GuiGraphics g, Body b, int cx, int cy) {
        int col = BOSS_COL[b.var], dark = Gfx.darker(col, 0.35F);
        boolean rage = b.used;
        Gfx.ball(g, cx, cy, 9, col);
        g.fill(cx - 8, cy - 9, cx - 5, cy - 6, dark);
        g.fill(cx + 5, cy - 9, cx + 8, cy - 6, dark);
        g.fill(cx - 5, cy - 4, cx - 1, cy, 0xFFFFFFFF);
        g.fill(cx + 1, cy - 4, cx + 5, cy, 0xFFFFFFFF);
        int pu = rage ? 0xFFD02020 : 0xFF1A1428;
        g.fill(cx - 3, cy - 3, cx - 1, cy - 1, pu);
        g.fill(cx + 1, cy - 3, cx + 3, cy - 1, pu);
        Gfx.line(g, cx - 6, cy - 6, cx - 1, cy - 4, rage ? 0xFF6A1010 : dark);
        Gfx.line(g, cx + 6, cy - 6, cx + 1, cy - 4, rage ? 0xFF6A1010 : dark);
        Gfx.ellipse(g, cx, cy + 4, 4, 3, Gfx.lighter(col, 0.35F));
        g.fill(cx - 2, cy + 3, cx - 1, cy + 5, dark);
        g.fill(cx + 1, cy + 3, cx + 2, cy + 5, dark);
        g.fill(cx - 5, cy + 6, cx - 4, cy + 9, 0xFFFFFFFF);
        g.fill(cx + 4, cy + 6, cx + 5, cy + 9, 0xFFFFFFFF);
        switch (b.var) {
            case 0 -> {                                                                     // a golden crown
                g.fill(cx - 5, cy - 13, cx + 6, cy - 10, 0xFFFFD040);
                g.fill(cx - 5, cy - 15, cx - 3, cy - 13, 0xFFFFD040);
                g.fill(cx - 1, cy - 16, cx + 1, cy - 13, 0xFFFFD040);
                g.fill(cx + 4, cy - 15, cx + 6, cy - 13, 0xFFFFD040);
                g.fill(cx, cy - 12, cx + 1, cy - 11, 0xFFE0304A);
            }
            case 1 -> {                                                                     // a crown of ice
                g.fill(cx - 5, cy - 13, cx + 6, cy - 10, 0xFFD8F6FF);
                g.fill(cx - 5, cy - 16, cx - 3, cy - 13, 0xFFFFFFFF);
                g.fill(cx - 1, cy - 18, cx + 1, cy - 13, 0xFFFFFFFF);
                g.fill(cx + 4, cy - 16, cx + 6, cy - 13, 0xFFFFFFFF);
            }
            default -> {                                                                    // horns
                g.fill(cx - 8, cy - 13, cx - 6, cy - 8, 0xFF2A1018);
                g.fill(cx - 9, cy - 15, cx - 7, cy - 13, 0xFF2A1018);
                g.fill(cx + 6, cy - 13, cx + 8, cy - 8, 0xFF2A1018);
                g.fill(cx + 7, cy - 15, cx + 9, cy - 13, 0xFF2A1018);
            }
        }
    }

    private void drawBlock(GuiGraphics g, Body b) {
        int x = Math.round(b.x - b.w / 2F), y = Math.round(b.y - b.h / 2F), w = Math.round(b.w), h = Math.round(b.h);
        int col = M_COL[b.type], dark = M_DARK[b.type], light = M_LIGHT[b.type];
        Gfx.bubble(g, x, y, w, h, 1, col);
        if (b.type == WOOD) {
            if (w >= h) for (int i = 4; i < w - 3; i += 6) g.fill(x + i, y + 1, x + i + 1, y + h - 1, dark);
            else for (int j = 4; j < h - 3; j += 6) g.fill(x + 1, y + j, x + w - 1, y + j + 1, dark);
        } else if (b.type == ICE) {
            g.fill(x + 1, y + 1, x + Math.min(w - 1, 4), y + 2, 0xFFFFFFFF);
            if (h > 6) g.fill(x + 1, y + 1, x + 2, y + Math.min(h - 1, 5), 0xFFFFFFFF);
        } else if (b.type == STONE) {
            for (int i = 0; i < 4; i++) g.fill(x + 2 + (i * 5) % Math.max(1, w - 3), y + 2 + (i * 7) % Math.max(1, h - 3), x + 3 + (i * 5) % Math.max(1, w - 3), y + 3 + (i * 7) % Math.max(1, h - 3), light);
        } else {                                                                            // a crate of TNT
            g.fill(x + 1, y + h / 2 - 1, x + w - 1, y + h / 2 + 1, 0xFFFFE9C0);
            g.fill(x + w / 2, y - 2, x + w / 2 + 1, y, 0xFF444444);
            if ((time / 6 & 1) == 0) g.fill(x + w / 2, y - 3, x + w / 2 + 1, y - 2, 0xFFFFB030);
        }
        float k = b.hp / b.maxHp;
        if (k < 0.66F) Gfx.line(g, x + 1, y + 1, x + w / 2, y + h - 2, dark);
        if (k < 0.33F) Gfx.line(g, x + w - 2, y + 1, x + w / 2 - 1, y + h / 2, dark);
    }

    private void drawFx(GuiGraphics g, Fx f) {
        int x = Math.round(f.x), y = Math.round(f.y);
        float t = f.life / (float) f.max;
        switch (f.kind) {
            case 0 -> g.fill(x, y, x + 2, y + 2, Gfx.fade(f.col, Math.min(1F, t * 2F)));
            case 1 -> disc(g, x, y, Math.max(1, Math.round(3 * t) + 1), Gfx.fade(f.col, t));
            case 2 -> {
                int rr = Math.round(f.rad * (1F - t));
                disc(g, x, y, rr + 3, Gfx.alpha(0xFFFFB347, Math.round(110 * t)));
                disc(g, x, y, Math.max(1, rr / 2), Gfx.fade(0xFFFFF0B0, t));
            }
            default -> ctext(g, f.txt, x, y, Gfx.fade(0xFFFFFFFF, Math.min(1F, t * 2F)));
        }
    }

    private void hud(GuiGraphics g) {
        Gfx.rrect(g, 3, 3, Math.max(62, tw(lvText) + 10), 11, 3, Gfx.fade(0xFF000000, 0.35F));
        text(g, lvText, 7, 5, 0xFFFFFFFF);
        for (int i = 0; i < LIVES; i++) Gfx.heart(g, W - 11 - i * 9, 5, i < lives ? 0xFFFF6A8E : 0x55FFFFFF);
        if (wind != 0F) {                                                                   // the wind: one chevron per notch
            int n = Math.min(3, Math.max(1, Math.round(Math.abs(wind) / 0.0015F))), dir = wind > 0 ? 1 : -1;
            for (int i = 0; i < n; i++) {
                int x = W / 2 - 6 + i * 5 * dir;
                for (int j = 0; j < 5; j++) g.fill(x + (j < 3 ? j : 4 - j) * dir, 5 + j, x + (j < 3 ? j : 4 - j) * dir + 1, 6 + j, 0xDDFFFFFF);
            }
        }
        if (boss != null && !boss.dead) {                                                   // the boss's health
            int bw = 56, bx = (W - bw) / 2, fill = Math.round(bw * Math.max(0F, boss.hp) / boss.maxHp);
            Gfx.rrect(g, bx - 1, 17, bw + 2, 6, 2, Gfx.fade(0xFF000000, 0.55F));
            g.fill(bx, 18, bx + fill, 22, boss.used ? 0xFFFF5A3A : 0xFF7AE060);
        }
        if (bannerT > 0 && state == S_READY) banner(g, bannerA, lvText, 0);
        if (state == S_CLEAR) banner(g, clearText, null, stars);
        if (state == S_FAIL) banner(g, failText, null, 0);
    }

    private static void banner(GuiGraphics g, String a, String b, int stars) {
        boolean two = b != null && !a.isEmpty();
        String top = two || b == null ? a : b;
        int w = Math.min(W - 20, Math.max(tw(top), two ? tw(b) : 0) + 24), h = two ? 26 : stars > 0 ? 28 : 16, y = 28;
        Gfx.rrect(g, (W - w) / 2, y, w, h, 5, Gfx.fade(0xFF000000, 0.5F));
        ctext(g, top, W / 2, y + 4, 0xFFFFD866);
        if (two) ctext(g, b, W / 2, y + 15, 0xFFFFFFFF);
        for (int i = 0; i < stars + (stars > 0 ? 3 - stars : 0); i++) Gfx.star(g, W / 2 - 12 + i * 12, y + 20, 4, i < stars ? 0xFFFFD040 : 0x66FFFFFF);
    }

    // ------------------------------------------------------------------ misc

    @Override
    public String hintKey() { return "cutemod.hint.birds"; }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return won ? Component.translatable("cutemod.birds.won") : Component.translatable("cutemod.ui.gameover");
    }
}
