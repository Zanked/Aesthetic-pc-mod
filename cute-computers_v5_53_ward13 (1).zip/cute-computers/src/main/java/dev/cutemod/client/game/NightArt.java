package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The pictures of Night Shift: four toys (a bunny, a cat, a bear and a doll), the rooms of the toy shop as the cameras see them,
 * and the guard's office. Everything is built from plain fills, so it works at the 220 x 140 game size. The palette is a dusty
 * violet night: soft, sweet colours that have gone slightly wrong.
 */
final class NightArt {
    private NightArt() {}

    static final int INK = 0xFF05030C;
    static final int[] BODY = {0xFFEBCBDB, 0xFF93A6CF, 0xFFAA765B, 0xFFF3E9E3};
    static final int[] SHADE = {0xFFB88CA4, 0xFF60709E, 0xFF744A32, 0xFFCDB8B2};

    // ================================================================== helpers
    static void r(GuiGraphics g, int x, int y, int w, int h, int c) { g.fill(x, y, x + w, y + h, c); }

    static void grad(GuiGraphics g, int x, int y, int w, int h, int top, int bot) { g.fillGradient(x, y, x + w, y + h, top, bot); }

    /** A triangle that points up: base width w at the bottom, top at (x + w / 2, y), height h. */
    static void tri(GuiGraphics g, int x, int y, int w, int h, int c) {
        for (int i = 0; i < h; i++) {
            int ww = Math.max(1, w * (i + 1) / h);
            int ox = x + (w - ww) / 2;
            g.fill(ox, y + i, ox + ww, y + i + 1, c);
        }
    }

    static int hash(int a, int b) {
        int h = a * 374761393 + b * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        return h ^ (h >>> 16);
    }

    static float rnd01(int a, int b) { return (hash(a, b) & 0xFFFF) / 65535f; }

    // ================================================================== the toys
    /**
     * One toy standing with its feet at (cx, by). type 0 bunny, 1 cat, 2 bear, 3 doll. s = scale; mood 0 sweet, 1 wrong
     * (huge smile, tiny pupils), 2 attacking; look = -1..1 where the eyes look; shade 0..1 = how much of the dark is mixed in.
     */
    static void toy(GuiGraphics g, int type, float cx, float by, float s, int mood, int t, int look, float shade) {
        g.pose().pushPose();
        g.pose().translate(cx, by, 0);
        g.pose().scale(s, s, 1f);
        int body = Gfx.mix(BODY[type], INK, shade), dk = Gfx.mix(SHADE[type], INK, shade);
        int light = Gfx.mix(body, 0xFFFFFFFF, 0.3f);
        int tw = (mood < 2 && t % 160 < 3) ? 1 : 0;     // the head twitches now and then
        Gfx.ellipse(g, 0, 0, 12, 2, Gfx.alpha(0xFF000000, 90));
        switch (type) {
            case 0 -> bunny(g, body, dk, light, mood, look, tw, shade);
            case 1 -> cat(g, body, dk, light, mood, look, tw);
            case 2 -> bear(g, body, dk, light, mood, look, tw, shade);
            default -> doll(g, body, dk, mood, look, tw, shade);
        }
        g.pose().popPose();
    }

    /** Two black button eyes, ex pixels left and right of the middle. */
    private static void buttonEyes(GuiGraphics g, int ex, int ey, int mood, int look) {
        for (int side = -1; side <= 1; side += 2) {
            int x = side * ex;
            int rr = mood == 0 ? 2 : mood == 1 ? (side < 0 ? 4 : 3) : 4;
            Gfx.disc(g, x, ey, rr, 0xFF0B0710);
            if (mood == 0) {
                r(g, x - 1, ey - 1, 1, 1, 0xFFFFFFFF);
                r(g, x, ey + 1, 1, 1, 0x55FFFFFF);
            } else if (mood == 1) {
                r(g, x + look, ey, 1, 1, 0xFFFFFFFF);                      // a pinprick of light in a black hole
            } else {
                r(g, x + look, ey, 2, 2, 0xFFFF2A3C);
            }
        }
    }

    /** A stitched mouth: a line with little crossing stitches; mood 1 is too wide, mood 2 is wide open with teeth. */
    private static void stitchMouth(GuiGraphics g, int my, int mood, int c) {
        if (mood == 2) {
            Gfx.rrect(g, -7, my - 2, 14, 9, 3, 0xFF14020A);
            for (int i = -6; i <= 4; i += 3) { r(g, i, my - 2, 2, 2, 0xFFEFE9E0); r(g, i + 1, my + 5, 2, 2, 0xFFEFE9E0); }
            r(g, -3, my + 3, 6, 2, 0xFF7A1020);
            return;
        }
        int w = mood == 1 ? 8 : 4;
        r(g, -w, my, w * 2, 1, c);
        for (int x = -w; x <= w; x += 3) r(g, x, my - 1, 1, 3, c);
        if (mood == 1) { r(g, -w - 1, my - 2, 1, 2, c); r(g, w, my - 2, 1, 2, c); }
    }

    private static void bunny(GuiGraphics g, int body, int dk, int light, int mood, int look, int tw, float shade) {
        int pink = Gfx.mix(dk, 0xFFE06A98, 0.55f), cheek = Gfx.mix(0xFFE57AA2, INK, shade * 0.8f);
        r(g, -7, -3, 5, 3, dk); r(g, 2, -3, 5, 3, dk);                           // feet
        Gfx.rrect(g, -8, -15, 16, 13, 4, body);                                  // body
        Gfx.rrect(g, -4, -12, 8, 8, 3, light);                                   // belly
        r(g, -11, -14, 3, 8, body); r(g, 8, -14, 3, 8, body);                    // arms
        r(g, -11, -7, 3, 2, dk); r(g, 8, -7, 3, 2, dk);                          // hands
        g.pose().pushPose();
        g.pose().translate(tw, 0, 0);
        Gfx.rrect(g, -8, -43, 5, 17, 2, body); Gfx.rrect(g, -7, -41, 3, 12, 1, pink);        // left ear
        Gfx.rrect(g, 3, -41, 5, 11, 2, body); r(g, 5, -44, 5, 5, body); r(g, 6, -43, 3, 3, pink);   // right ear, bent
        Gfx.rrect(g, -10, -29, 20, 17, 7, body);                                 // head
        r(g, -9, -20, 3, 2, cheek); r(g, 6, -20, 3, 2, cheek);
        buttonEyes(g, 4, -22, mood, look);
        r(g, -1, -19, 2, 1, pink);
        stitchMouth(g, -15, mood, dk);
        g.pose().popPose();
    }

    private static void cat(GuiGraphics g, int body, int dk, int light, int mood, int look, int tw) {
        Gfx.rrect(g, 8, -27, 4, 25, 2, body);                                    // tail
        for (int y = -25; y < -4; y += 5) r(g, 8, y, 4, 2, dk);
        r(g, 10, -30, 4, 5, body);
        r(g, -7, -3, 5, 3, dk); r(g, 2, -3, 5, 3, dk);
        Gfx.rrect(g, -8, -15, 16, 13, 4, body);
        for (int y = -13; y < -4; y += 4) { r(g, -8, y, 3, 1, dk); r(g, 5, y, 3, 1, dk); }
        Gfx.rrect(g, -3, -12, 6, 8, 2, light);
        r(g, -11, -14, 3, 8, body); r(g, 8, -14, 3, 8, body);
        r(g, -11, -7, 3, 2, dk); r(g, 8, -7, 3, 2, dk);
        g.pose().pushPose();
        g.pose().translate(tw, 0, 0);
        tri(g, -12, -38, 8, 10, body); tri(g, 4, -38, 8, 10, body);               // ears
        tri(g, -10, -35, 4, 6, Gfx.mix(dk, 0xFFE06A98, 0.5f)); tri(g, 6, -35, 4, 6, Gfx.mix(dk, 0xFFE06A98, 0.5f));
        Gfx.rrect(g, -12, -30, 24, 18, 8, body);
        r(g, -1, -30, 2, 3, dk); r(g, -5, -30, 1, 2, dk); r(g, 4, -30, 1, 2, dk);        // forehead stripes
        for (int side = -1; side <= 1; side += 2) {
            int x = side * 5;
            int rr = mood == 2 ? 4 : 3;
            Gfx.disc(g, x, -22, rr, mood == 2 ? 0xFFFF8A2A : 0xFFE9D56A);
            r(g, x + look, -22 - rr + 1, 1, rr * 2 - 1, 0xFF10080C);                       // the slit pupil
            if (mood == 0) r(g, x - 2, -24, 1, 1, 0xFFFFFFFF);
        }
        r(g, -1, -17, 2, 1, Gfx.mix(dk, 0xFFE06A98, 0.5f));
        stitchMouth(g, -14, mood, dk);
        int wh = Gfx.mix(0xFFE8E4F0, dk, 0.35f);
        r(g, -19, -19, 8, 1, wh); r(g, -18, -16, 7, 1, wh); r(g, 11, -19, 8, 1, wh); r(g, 11, -16, 7, 1, wh);   // whiskers
        g.pose().popPose();
    }

    private static void bear(GuiGraphics g, int body, int dk, int light, int mood, int look, int tw, float shade) {
        int red = Gfx.mix(0xFFC0283A, INK, shade);
        r(g, -9, -3, 7, 3, dk); r(g, 2, -3, 7, 3, dk);
        Gfx.rrect(g, -10, -17, 20, 15, 5, body);
        Gfx.ellipse(g, 0, -9, 5, 4, light);
        r(g, -13, -16, 3, 10, body); r(g, 10, -16, 3, 10, body);
        r(g, -13, -8, 3, 2, dk); r(g, 10, -8, 3, 2, dk);
        r(g, -5, -17, 4, 4, red); r(g, 1, -17, 4, 4, red); r(g, -1, -16, 2, 2, Gfx.mix(red, INK, 0.4f));   // bow tie
        g.pose().pushPose();
        g.pose().translate(tw, 0, 0);
        Gfx.disc(g, -9, -30, 4, body); Gfx.disc(g, -9, -30, 2, dk);
        Gfx.disc(g, 9, -30, 4, body); Gfx.disc(g, 9, -30, 2, dk);
        Gfx.rrect(g, -11, -31, 22, 18, 8, body);
        Gfx.ellipse(g, 0, -19, 6, 4, light);
        r(g, -2, -22, 4, 2, 0xFF1A0E10);
        if (mood == 0) {
            Gfx.disc(g, -5, -25, 2, 0xFF0B0710); r(g, -6, -26, 1, 1, 0xFFFFFFFF);          // one button eye ...
            for (int i = -2; i <= 2; i++) { r(g, 5 + i, -25 + i, 1, 1, red); r(g, 5 + i, -25 - i, 1, 1, red); }   // ... and one sewn X
        } else {
            buttonEyes(g, 5, -25, mood, look);
        }
        stitchMouth(g, -15, mood == 0 ? 0 : mood, dk);
        g.pose().popPose();
    }

    private static void doll(GuiGraphics g, int body, int dk, int mood, int look, int tw, float shade) {
        int hair = Gfx.mix(0xFF1C1424, INK, shade), dress = Gfx.mix(0xFF7A1F32, INK, shade), red = Gfx.mix(0xFFC0283A, INK, shade);
        int cheek = Gfx.mix(0xFFD8607A, INK, shade * 0.8f);
        r(g, -4, -7, 2, 7, body); r(g, 2, -7, 2, 7, body);                       // legs
        r(g, -5, -2, 4, 2, 0xFF1A1018); r(g, 1, -2, 4, 2, 0xFF1A1018);           // shoes
        Gfx.rrect(g, -7, -18, 14, 12, 3, dress);                                  // dress
        Gfx.rrect(g, -10, -11, 20, 7, 3, dress);                                  // skirt
        r(g, -4, -19, 8, 2, Gfx.mix(0xFFFFFFFF, INK, shade));                    // collar
        r(g, -11, -17, 3, 8, body); r(g, 8, -17, 3, 8, body);
        g.pose().pushPose();
        g.pose().translate(tw, 0, 0);
        Gfx.rrect(g, -11, -37, 22, 22, 8, hair);                                  // the black bob
        Gfx.disc(g, 0, -26, 8, body);                                             // the porcelain head
        Gfx.rrect(g, -9, -34, 18, 5, 2, hair);                                    // fringe
        r(g, 7, -34, 5, 3, red); r(g, 11, -36, 2, 7, red); r(g, 9, -33, 2, 1, Gfx.mix(red, INK, 0.4f));   // ribbon
        Gfx.disc(g, -5, -22, 2, cheek); Gfx.disc(g, 5, -22, 2, cheek);
        if (mood == 0) {
            r(g, -6, -26, 4, 1, 0xFF1A1018); r(g, 2, -26, 4, 1, 0xFF1A1018);     // closed eyes
            r(g, -7, -25, 1, 1, 0xFF1A1018); r(g, 6, -25, 1, 1, 0xFF1A1018);
            r(g, -2, -19, 4, 1, 0xFFB03048);
        } else {
            int rr = mood == 2 ? 3 : 2;
            Gfx.disc(g, -4, -26, rr, 0xFF0B0710); Gfx.disc(g, 4, -26, rr, 0xFF0B0710);
            r(g, -4 + look, -26, 1, 1, 0xFFFFFFFF); r(g, 4 + look, -26, 1, 1, 0xFFFFFFFF);
            if (mood == 2) { Gfx.rrect(g, -4, -21, 8, 5, 2, 0xFF14020A); r(g, -3, -21, 6, 1, 0xFFEFE9E0); }
            else { r(g, -4, -20, 8, 1, 0xFFB03048); r(g, -5, -21, 1, 1, 0xFFB03048); r(g, 4, -21, 1, 1, 0xFFB03048); }
        }
        for (int i = 0; i < 15; i++) r(g, -2 + i * 5 / 14, -33 + i, 1, 1, Gfx.alpha(dk, 200));   // a crack in the porcelain
        g.pose().popPose();
    }

    // ================================================================== the rooms (as the cameras see them)
    /** The picture of room 0..4 (the music room has its own method). night 0..4 makes the drawings on the playroom wall grow. */
    static void room(GuiGraphics g, int room, int t, int night) {
        switch (room) {
            case 0 -> stage(g, t);
            case 1 -> playroom(g, t, night);
            case 2 -> hall(g, t, false);
            case 3 -> hall(g, t, true);
            default -> storage(g, t);
        }
    }

    private static void stage(GuiGraphics g, int t) {
        grad(g, 0, 0, 220, 90, 0xFF2C1B3A, 0xFF150E22);
        for (int i = 0; i < 16; i++) {
            int sx = 36 + (int) (rnd01(i, 1) * 148), sy = 14 + (int) (rnd01(i, 2) * 44);
            int sz = 1 + (i & 1);
            r(g, sx, sy, sz, sz, ((t / 20 + i) % 7 == 0) ? 0x55FFFFFF : 0xAAE8E4FF);
        }
        Gfx.disc(g, 110, 34, 15, 0xFFD6D0F0);                                    // a painted moon
        Gfx.disc(g, 116, 30, 13, 0xFF281A38);
        for (int x = 0; x < 220; x += 5) {                                       // cardboard hills
            int h = 14 + (int) (Math.sin(x * 0.045) * 7) + (int) (Math.sin(x * 0.13) * 3);
            r(g, x, 88 - h, 5, h, 0xFF120A1C);
        }
        for (int px : new int[]{58, 110, 162}) {                                 // spotlight cones
            boolean out = (px == 110) && (NightArt.hash(t / 7, 3) % 11 == 0);
            if (out) continue;
            for (int y = 14; y < 92; y += 3) {
                int w = 8 + (int) ((y - 14) * 0.32);
                r(g, px - w / 2, y, w, 3, Gfx.alpha(0xFFFFE8B0, 9));
            }
        }
        grad(g, 0, 90, 220, 34, 0xFF5C3B24, 0xFF2A1810);                         // the wooden stage
        r(g, 0, 90, 220, 2, 0xFF7A5232);
        for (int x = 0; x < 220; x += 22) r(g, x, 92, 1, 32, Gfx.alpha(0xFF000000, 80));
        for (int px : new int[]{58, 110, 162}) {                                 // pedestals
            Gfx.rrect(g, px - 15, 93, 30, 15, 3, 0xFF3A2A48);
            r(g, px - 14, 93, 28, 2, 0xFF6A5A84);
            r(g, px - 6, 99, 12, 4, 0xFFB8902C);
        }
        r(g, 0, 0, 40, 100, 0xFF5E1828); r(g, 180, 0, 40, 100, 0xFF5E1828);                  // curtains
        for (int x = 0; x < 40; x += 8) {
            r(g, x, 0, 3, 100, Gfx.alpha(0xFF000000, 55)); r(g, x + 4, 0, 2, 100, Gfx.alpha(0xFFFFFFFF, 18));
            r(g, 180 + x, 0, 3, 100, Gfx.alpha(0xFF000000, 55)); r(g, 184 + x, 0, 2, 100, Gfx.alpha(0xFFFFFFFF, 18));
        }
        r(g, 0, 72, 40, 3, 0xFFB8902C); r(g, 180, 72, 40, 3, 0xFFB8902C);
        r(g, 0, 0, 220, 12, 0xFF4A1020);
        for (int x = 7; x < 220; x += 14) Gfx.ellipse(g, x, 12, 7, 4, 0xFF4A1020);
        r(g, 0, 15, 220, 1, Gfx.alpha(0xFFB8902C, 160));
    }

    private static void playroom(GuiGraphics g, int t, int night) {
        grad(g, 0, 0, 220, 90, 0xFF3B3354, 0xFF272040);
        for (int i = 0; i < 44; i++) r(g, (int) (rnd01(i, 5) * 218), (int) (rnd01(i, 6) * 84), 2, 2, Gfx.alpha(0xFFFFFFFF, 14));
        r(g, 0, 87, 220, 37, 0xFF2A2236);
        for (int yy = 0; yy < 3; yy++) for (int xx = 0; xx < 15; xx++)
            if (((xx + yy) & 1) == 0) r(g, xx * 16 - 4, 90 + yy * 12, 16, 12, 0x30A090C0);
        r(g, 0, 85, 220, 3, 0xFF4A3A5C);
        // the shelves with the toys
        r(g, 8, 44, 62, 3, 0xFF6A4A32); r(g, 8, 70, 62, 3, 0xFF6A4A32);
        r(g, 12, 34, 10, 10, 0xFFC8403C); r(g, 15, 37, 4, 1, 0xFFF4E8E0); r(g, 15, 39, 4, 1, 0xFFF4E8E0);
        r(g, 24, 36, 8, 8, 0xFF3C78C8); r(g, 27, 38, 2, 4, 0xFFF4E8E0);
        Gfx.disc(g, 46, 38, 4, 0xFF8A5A40); Gfx.disc(g, 43, 34, 2, 0xFF8A5A40); Gfx.disc(g, 49, 34, 2, 0xFF8A5A40);
        r(g, 44, 38, 1, 1, 0xFF120A12); r(g, 48, 38, 1, 1, 0xFF120A12);
        Gfx.disc(g, 60, 40, 4, 0xFFE8C838); r(g, 63, 40, 4, 2, 0xFFE8802A);
        for (int i = 0; i < 5; i++) {
            Gfx.disc(g, 14 + i * 11, 63, 3, 0xFFE8D6D0);
            r(g, 11 + i * 11, 66, 6, 4, i % 2 == 0 ? 0xFF8A3048 : 0xFF3A5C98);
            r(g, 13 + i * 11, 62, 1, 1, 0xFF120A12); r(g, 15 + i * 11, 62, 1, 1, 0xFF120A12);
        }
        // the drawing on the wall: a family, and one more every night
        r(g, 148, 14, 58, 40, 0xFFE8E0C8); r(g, 200, 14, 6, 4, 0xFF5A4A68);
        Gfx.disc(g, 156, 22, 3, 0xFFF4D23C);
        int[] crayon = {0xFFD8483C, 0xFF3C78D8, 0xFF3CA85C, 0xFFE89A2C, 0xFF9A4CC8, 0xFF3A3A44};
        int n = Math.min(6, 3 + night);
        for (int i = 0; i < n; i++) {
            int hx = 158 + i * 8;
            boolean last = i == n - 1;
            int c = last ? 0xFF1A1418 : crayon[i];
            int top = last ? 24 : 30;
            Gfx.disc(g, hx, top, 2, c);
            r(g, hx, top + 2, 1, last ? 14 : 8, c); r(g, hx - 2, top + 5, 5, 1, c);
            r(g, hx - 1, last ? 40 : 38, 1, 5, c); r(g, hx + 1, last ? 40 : 38, 1, 5, c);
            if (last) { r(g, hx - 1, top - 1, 1, 1, 0xFFFFFFFF); r(g, hx + 1, top - 1, 1, 1, 0xFFFFFFFF); }
        }
        // letter blocks and a rocking horse
        r(g, 150, 100, 14, 14, 0xFFC8403C); r(g, 166, 100, 14, 14, 0xFF3C78C8); r(g, 158, 86, 14, 14, 0xFFE0B830);
        r(g, 154, 104, 6, 1, 0xFFF4E8E0); r(g, 156, 104, 2, 6, 0xFFF4E8E0); r(g, 171, 104, 4, 6, 0xFFF4E8E0); r(g, 162, 90, 6, 1, 0xFF3A2A18);
        r(g, 34, 112, 38, 2, 0xFF6A4A32);
        Gfx.rrect(g, 40, 98, 22, 10, 4, 0xFF8A5A3A); r(g, 58, 90, 5, 10, 0xFF8A5A3A); Gfx.rrect(g, 56, 86, 13, 7, 3, 0xFF8A5A3A);
        r(g, 42, 106, 3, 7, 0xFF6A4228); r(g, 56, 106, 3, 7, 0xFF6A4228); r(g, 64, 88, 1, 1, 0xFFF0E8E0);
    }

    private static void hall(GuiGraphics g, int t, boolean east) {
        int vx0 = east ? 96 : 86, vx1 = vx0 + 48;
        Gfx.poly(g, new int[]{0, 220, vx1, vx0}, new int[]{0, 0, 34, 34}, 0xFF1B1428);
        Gfx.poly(g, new int[]{0, 220, vx1, vx0}, new int[]{124, 124, 82, 82}, 0xFF2A2030);
        Gfx.poly(g, new int[]{0, vx0, vx0, 0}, new int[]{0, 34, 82, 124}, 0xFF2E2440);
        Gfx.poly(g, new int[]{220, vx1, vx1, 220}, new int[]{0, 34, 82, 124}, 0xFF2A2038);
        r(g, vx0, 34, 48, 48, 0xFF3A2E4C);
        for (int k = 1; k < 6; k++) {                                            // floor tiles: rows get closer far away
            int y = 82 + 42 * k * k / 25;
            float f = (y - 82) / 42f;
            int lx = Math.round(vx0 * (1 - f)), rx = Math.round(vx1 + (220 - vx1) * f);
            r(g, lx, y, rx - lx, 1, Gfx.alpha(0xFF000000, 70));
        }
        for (int x : new int[]{10, 30, 50, 66, 78}) {                            // wall panels
            int top = 34 * x / vx0, bot = 124 - 42 * x / vx0;
            r(g, x, top, 1, bot - top, Gfx.alpha(0xFF000000, 55));
            int x2 = 220 - x;
            top = 34 * x / vx0; bot = 124 - 42 * x / vx0;
            r(g, x2, top, 1, bot - top, Gfx.alpha(0xFF000000, 55));
        }
        int dx = vx0 + 14;                                                       // the office door at the far end
        r(g, dx - 2, 46, 24, 36, 0xFF1C1420); r(g, dx, 48, 20, 34, 0xFF4A3524);
        r(g, dx + 4, 52, 12, 9, 0xFFFFE0A0); r(g, dx + 4, 52, 12, 1, 0xFFFFF4D0); r(g, dx + 15, 66, 2, 2, 0xFFD8B050);
        if (east) {                                                              // a moonlit window on the right wall
            r(g, 168, 38, 30, 50, 0xFF3A2A44); r(g, 171, 41, 24, 44, 0xFF1C2560);
            r(g, 182, 41, 2, 44, 0xFF3A2A44); r(g, 171, 60, 24, 2, 0xFF3A2A44);
            Gfx.disc(g, 189, 49, 3, 0xFFDAD6F8);
            Gfx.poly(g, new int[]{168, 198, 214, 150}, new int[]{88, 88, 118, 118}, Gfx.alpha(0xFF8890E0, 22));
        } else {                                                                 // a poster: SMILE!
            r(g, 40, 44, 22, 28, 0xFFD8C8A0); r(g, 42, 46, 18, 24, 0xFFE8D6B0);
            Gfx.disc(g, 51, 55, 5, 0xFFF0D048); r(g, 49, 54, 1, 2, 0xFF1A1018); r(g, 53, 54, 1, 2, 0xFF1A1018);
            r(g, 48, 58, 7, 1, 0xFF1A1018); r(g, 47, 57, 1, 1, 0xFF1A1018); r(g, 55, 57, 1, 1, 0xFF1A1018);
            r(g, 44, 64, 14, 2, 0xFFC8403C);
        }
        // a sign on the other wall
        r(g, east ? 40 : 158, 48, 16, 20, 0xFFB83030); r(g, east ? 42 : 160, 50, 12, 16, 0xFFF0E8E0);
        r(g, east ? 47 : 165, 52, 2, 3, 0xFF1A1018); r(g, east ? 46 : 164, 55, 4, 5, 0xFF1A1018); r(g, east ? 44 : 162, 62, 8, 1, 0xFFB83030);
        // the ceiling lamp, flickering
        int fl = hash(t / 3, east ? 9 : 4);
        boolean dim = (fl % 13) == 0;
        int lx = 110;
        r(g, lx, 14, 1, 14, 0xFF3A3A44); Gfx.rrect(g, lx - 4, 28, 9, 4, 2, 0xFF4A4A56);
        Gfx.disc(g, lx, 33, 3, dim ? 0xFF8A7448 : 0xFFFFE6A8);
        if (!dim) {
            Gfx.ellipse(g, lx, 38, 26, 9, Gfx.alpha(0xFFFFD890, 16));
            Gfx.ellipse(g, lx, 100, 46, 9, Gfx.alpha(0xFFFFD890, 20));
        }
    }

    private static void storage(GuiGraphics g, int t) {
        r(g, 0, 0, 220, 124, 0xFF2A1C1A);
        for (int y = 4; y < 100; y += 6) {
            r(g, 0, y, 220, 1, Gfx.alpha(0xFF000000, 70));
            for (int x = (y / 6 % 2) * 9; x < 220; x += 18) r(g, x, y, 1, 6, Gfx.alpha(0xFF000000, 55));
        }
        r(g, 0, 100, 220, 24, 0xFF22202C); r(g, 0, 100, 220, 1, 0xFF3A3648);
        for (int row = 0; row < 3; row++) {                                      // shelves
            int y = 34 + row * 30;
            r(g, 6, y, 88, 3, 0xFF5A3C28);
            r(g, 8, y + 3, 3, 24, 0xFF4A3020); r(g, 89, y + 3, 3, 24, 0xFF4A3020);
        }
        for (int i = 0; i < 7; i++) {                                            // a shelf of spare heads
            int hx = 16 + i * 11;
            int c = BODY[i & 3];
            Gfx.disc(g, hx, 28, 4, Gfx.mix(c, INK, 0.45f));
            r(g, hx - 2, 27, 1, 1, 0xFF0A060C); r(g, hx + 1, 27, 1, 1, i == 3 ? 0xFFC0283A : 0xFF0A060C);
            r(g, hx - 1, 30, 3, 1, 0xFF3A1A24);
        }
        r(g, 12, 52, 20, 14, 0xFF7A5A3C); r(g, 12, 58, 20, 2, 0xFFA8845A); r(g, 36, 56, 16, 10, 0xFF6A4A32); r(g, 56, 50, 24, 16, 0xFF7A5A3C);
        r(g, 12, 82, 14, 10, 0xFF6A4A32); r(g, 30, 78, 24, 14, 0xFF7A5A3C); r(g, 58, 84, 20, 8, 0xFF8A6A44);
        r(g, 14, 112, 24, 10, 0xFF6A4A32); r(g, 140, 62, 36, 38, 0xFF7A5A3C); r(g, 140, 78, 36, 3, 0xFF5A3C28);
        r(g, 176, 74, 28, 26, 0xFF6A4A32); r(g, 150, 70, 14, 4, 0xFFC83030); r(g, 150, 70, 2, 4, 0xFFF0E8E0); r(g, 156, 70, 2, 4, 0xFFF0E8E0);
        for (int i = 0; i < 7; i++) r(g, 100 + i * 6 + (i % 3) * 2, 112 + (i % 2) * 4, 5, 2, Gfx.alpha(0xFFE8E4EC, 150));   // stuffing on the floor
        int sw = (int) (Math.sin(t * 0.04) * 6);                                 // a swinging bulb
        r(g, 118, 0, 1, 18, 0xFF3A3A44);
        Gfx.line(g, 118, 18, 118 + sw, 30, 0xFF3A3A44);
        Gfx.disc(g, 118 + sw, 33, 3, 0xFFFFE6A8);
        Gfx.ellipse(g, 118 + sw, 52, 30, 20, Gfx.alpha(0xFFFFD890, 14));
        Gfx.ellipse(g, 118 + sw, 100, 50, 7, Gfx.alpha(0xFFFFD890, 16));
    }

    /** The music box room (camera 6). wind 0..100, crank = turns. */
    static void music(GuiGraphics g, int t, double wind, boolean winding) {
        grad(g, 0, 0, 220, 100, 0xFF1A1840, 0xFF2A2250);
        for (int i = 0; i < 40; i++) {
            int sx = (int) (rnd01(i, 11) * 218), sy = (int) (rnd01(i, 12) * 96);
            r(g, sx, sy, 1 + (i & 1), 1 + (i & 1), ((t / 25 + i) % 6 == 0) ? 0x66FFFFFF : 0xBBFFE8A8);
        }
        r(g, 0, 98, 220, 26, 0xFF2A1E30);
        Gfx.ellipse(g, 110, 112, 80, 11, 0xFF4A2E48); Gfx.ellipse(g, 110, 112, 60, 8, 0xFF5A3A58); Gfx.ellipse(g, 110, 112, 38, 5, 0xFF4A2E48);
        // the box
        r(g, 84, 68, 52, 36, 0xFF3A2E6A); r(g, 84, 68, 52, 3, 0xFF6A5AB0); r(g, 84, 101, 52, 3, 0xFF1E1840);
        for (int i = 0; i < 5; i++) Gfx.star(g, 94 + i * 8, 86 + (i % 2) * 6, 2, 0xFFE8C838);
        r(g, 82, 66, 56, 4, 0xFFB8902C);
        // the crank
        int ang = winding ? t / 2 : t / 12;
        int cx = 140, cy = 88;
        r(g, 136, 87, 6, 2, 0xFF9A9AAA);
        int ox = (int) Math.round(Math.cos(ang * 0.9) * 5), oy = (int) Math.round(Math.sin(ang * 0.9) * 5);
        Gfx.line(g, cx + 2, cy, cx + 2 + ox, cy + oy, 0xFFB8B8C8); Gfx.disc(g, cx + 2 + ox, cy + oy, 2, 0xFFE8C838);
        // the lid and the doll: the lower the spring, the higher she rises
        float f = (float) Math.max(0, Math.min(1, (36 - wind) / 36.0));
        int rise = Math.round(f * 30);
        if (f <= 0.02f) {
            r(g, 84, 60, 52, 8, 0xFF5A4A9A); r(g, 84, 60, 52, 2, 0xFF8A7AD0);
        } else {
            r(g, 76 - rise / 3, 58 - rise / 2, 12, 4, 0xFF5A4A9A);                // the lid swings open
            r(g, 132 + rise / 3, 58 - rise / 2, 12, 4, 0xFF5A4A9A);
            for (int i = 0; i < 6; i++) r(g, 106 + (i % 2) * 6, 66 - i * Math.max(1, rise / 6), 8, 2, 0xFFB8B8C8);   // the spring
            int hy = 66 - rise - 6;
            int wob = (int) Math.round(Math.sin(t * 0.3) * f * 2);
            g.pose().pushPose();
            g.pose().translate(110 + wob, hy + 22, 0);
            g.pose().scale(1.0f, 1.0f, 1f);
            doll(g, Gfx.mix(BODY[3], INK, 0.15f), SHADE[3], f > 0.7f ? 2 : 1, 0, 0, 0.15f);
            g.pose().popPose();
        }
    }

    // ================================================================== the office
    /** The guard's office without the doorways, the doors and the toys. hour 0..5 sets the clock, night 0..4 the calendar. */
    static void office(GuiGraphics g, int t, int hour, int night) {
        grad(g, 0, 0, 220, 102, 0xFF271B3C, 0xFF181029);
        r(g, 0, 0, 220, 16, 0xFF120C1C); r(g, 0, 6, 220, 2, 0xFF1E162C);
        for (int x = 0; x < 220; x += 12) r(g, x, 16, 1, 60, Gfx.alpha(0xFF000000, 36));
        r(g, 0, 76, 220, 26, 0xFF1F1420); r(g, 0, 76, 220, 1, 0xFF3C2C48);
        for (int x = 0; x < 220; x += 14) r(g, x, 77, 1, 25, Gfx.alpha(0xFF000000, 60));
        grad(g, 0, 102, 220, 38, 0xFF2A1E26, 0xFF0E0A12);
        for (int yy = 0; yy < 4; yy++) for (int xx = 0; xx < 15; xx++)
            if (((xx + yy) & 1) == 0) r(g, xx * 16 - 4, 104 + yy * 9, 16, 9, Gfx.alpha(0xFFFFFFFF, 9));
        // the window
        r(g, 82, 20, 56, 47, 0xFF3C2C48);
        grad(g, 84, 22, 52, 43, 0xFF0B1030, 0xFF24296A);
        for (int i = 0; i < 9; i++) r(g, 86 + (int) (rnd01(i, 21) * 48), 24 + (int) (rnd01(i, 22) * 26), 1, 1, ((t / 18 + i) % 5 == 0) ? 0x66FFFFFF : 0xCCFFFFFF);
        Gfx.disc(g, 122, 35, 7, 0xFFE9E4FF); Gfx.disc(g, 125, 33, 6, 0xFF121A4A);
        for (int x = 84; x < 136; x += 4) r(g, x, 58 - (int) (Math.abs(Math.sin(x * 0.4)) * 7), 4, 8, 0xFF080A1C);   // far trees
        r(g, 84, 60, 52, 5, 0xFF080A1C);
        r(g, 108, 22, 2, 43, 0xFF3C2C48); r(g, 84, 42, 52, 2, 0xFF3C2C48); r(g, 80, 66, 60, 3, 0xFF4C3A58);
        r(g, 76, 20, 8, 48, 0xFF4A1830); r(g, 78, 20, 1, 48, 0xFF2A0C1C); r(g, 81, 20, 1, 48, 0xFF2A0C1C);
        r(g, 136, 20, 8, 48, 0xFF4A1830); r(g, 138, 20, 1, 48, 0xFF2A0C1C); r(g, 141, 20, 1, 48, 0xFF2A0C1C);
        // the clock
        Gfx.disc(g, 66, 40, 7, 0xFF3C2C48); Gfx.disc(g, 66, 40, 6, 0xFFE8E0D0);
        for (int i = 0; i < 4; i++) r(g, 66 + (i == 1 ? 5 : i == 3 ? -5 : 0), 40 + (i == 0 ? -5 : i == 2 ? 5 : 0), 1, 1, 0xFF3A2A30);
        double ha = (hour % 12) / 12.0 * Math.PI * 2 - Math.PI / 2;
        Gfx.line(g, 66, 40, 66 + (int) Math.round(Math.cos(ha) * 3), 40 + (int) Math.round(Math.sin(ha) * 3), 0xFF1A1018);
        Gfx.line(g, 66, 40, 66, 35, 0xFF1A1018);
        // the calendar: a cross for every night that is over
        r(g, 150, 28, 10, 30, 0xFFE8E0D0); r(g, 150, 28, 10, 5, 0xFFC03840);
        for (int i = 0; i < 5; i++) {
            r(g, 152, 35 + i * 4, 6, 3, 0xFFD8D0C0);
            if (i < night) { Gfx.line(g, 152, 35 + i * 4, 157, 37 + i * 4, 0xFF702028); }
            if (i == night) r(g, 151, 34 + i * 4, 8, 1, 0xFFC03840);
        }
        // the desk
        r(g, 52, 98, 116, 6, 0xFF4E3624); r(g, 52, 98, 116, 1, 0xFF7A5A3C);
        r(g, 56, 104, 108, 22, 0xFF2E2016); r(g, 60, 108, 46, 14, 0xFF241810); r(g, 114, 108, 46, 14, 0xFF241810);
        r(g, 80, 114, 6, 2, 0xFF9A7A4A); r(g, 134, 114, 6, 2, 0xFF9A7A4A);
        // the monitor
        r(g, 94, 74, 32, 25, 0xFF1C1A24); r(g, 96, 76, 28, 19, 0xFF081816); r(g, 106, 99, 8, 3, 0xFF2A2834);
        for (int y = 77; y < 94; y += 3) r(g, 97, y, 26, 1, Gfx.alpha(0xFF50FFC8, 34));
        int bar = 77 + (t / 2) % 17;
        r(g, 97, bar, 26, 2, Gfx.alpha(0xFF50FFC8, 46));
        r(g, 100, 80, 6, 4, Gfx.alpha(0xFF50FFC8, 70)); r(g, 110, 84, 8, 5, Gfx.alpha(0xFF50FFC8, 50));
        // the lamp
        r(g, 66, 97, 10, 2, 0xFF3A3A48); r(g, 70, 84, 2, 13, 0xFF3A3A48); tri(g, 64, 76, 14, 8, 0xFF8A5A2A);
        Gfx.ellipse(g, 71, 99, 15, 3, Gfx.alpha(0xFFFFC880, 40));
        // a mug with steam, papers
        r(g, 140, 92, 7, 6, 0xFFE8E0D0); r(g, 147, 93, 2, 3, 0xFFE8E0D0); r(g, 141, 93, 5, 1, 0xFF3A2010);
        for (int i = 0; i < 3; i++) {
            int sy = 88 - ((t / 4 + i * 5) % 14);
            r(g, 142 + (int) Math.round(Math.sin((t + i * 20) * 0.1) * 1.5), sy, 1, 2, Gfx.alpha(0xFFFFFFFF, 60 - (88 - sy) * 3));
        }
        r(g, 154, 96, 12, 2, 0xFFD8D0C0); r(g, 156, 94, 10, 2, 0xFFE8E0D0);
        r(g, 52, 94, 8, 4, 0xFF2A2A34); r(g, 54, 93, 4, 1, 0xFF50FF88);
    }

    /** What the guard sees down a hall through the open doorway at x (32 wide, 76 tall). */
    static void hallView(GuiGraphics g, int x, boolean lit, int t, boolean east) {
        int y = 26, w = 32, h = 76;
        if (!lit) {
            grad(g, x, y, w, h, 0xFF0A0818, 0xFF030208);
            r(g, x + 12, y + 62, 8, 14, Gfx.alpha(0xFF6A70C0, 10));
            r(g, x + 10, y + 20, 12, 22, Gfx.alpha(0xFF000000, 30));
            return;
        }
        grad(g, x, y, w, h, 0xFF3A3040, 0xFF8A7860);
        r(g, x + 8, y + 18, 16, 36, 0xFF5A4A58);
        r(g, x + 10, y + 20, 12, 34, 0xFF6A5A60);
        r(g, x, y + 60, w, 16, 0xFF6A5C50);
        for (int i = 0; i < 4; i++) r(g, x, y + 60 + i * 4, w, 1, Gfx.alpha(0xFF000000, 50));
        int wall = east ? 0xFF4A4060 : 0xFF584860;
        r(g, x, y, 5, 62, wall); r(g, x + w - 5, y, 5, 62, wall);
        r(g, x, y, w, 3, 0xFF2A2030);
        Gfx.ellipse(g, x + 16, y + 62, 14, 3, Gfx.alpha(0xFFFFF0C0, 40));
    }

    /** A steel door sliding down over a doorway; k 0..1 = how far it is down. */
    static void door(GuiGraphics g, int x, float k, int t) {
        int y = 26, w = 32, h = Math.round(76 * k);
        if (h <= 0) return;
        grad(g, x, y, w, h, 0xFF6C6E7C, 0xFF3C3E4A);
        for (int i = 0; i < w; i += 4) r(g, x + i, y, 1, h, Gfx.alpha(0xFF000000, 36));
        r(g, x, y, 1, h, Gfx.alpha(0xFFFFFFFF, 60));
        for (int yy = y + 6; yy < y + h - 4; yy += 14) {
            r(g, x + 2, yy, 2, 2, 0xFF2A2C36); r(g, x + w - 4, yy, 2, 2, 0xFF2A2C36);
            r(g, x, yy + 6, w, 1, Gfx.alpha(0xFF000000, 60));
        }
        r(g, x, y + h - 5, w, 5, 0xFF1A1A20);
        for (int i = 0; i < w; i += 8) r(g, x + i, y + h - 5, 4, 5, 0xFFD8B02C);
        if (h > 30) { r(g, x + 10, y + 16, 12, 10, 0xFF14141C); for (int i = 0; i < 12; i += 3) r(g, x + 10 + i, y + 16, 1, 10, 0xFF50505C); }
    }
}
