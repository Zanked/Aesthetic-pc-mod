package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * Night Shift: a horror game in the spirit of the night-guard classics. You work the night shift (12 AM to 6 AM) in a toy shop
 * where the plush toys wake up. Three of them (a bunny, a cat and a bear) walk through the shop towards your two doors; look at them
 * on the cameras, close the doors in time and flash the lights down the halls, but every door, light and camera drains the
 * power. A music-box doll sleeps as long as you keep winding the box. Survive five nights.
 *
 * <p>Controls: mouse, or A / D = doors, Q / E = lights, Space = cameras, 1-6 = a camera, W = wind the box.
 */
public class NightShift extends MiniGame {
    private static final int M_CARD = 0, M_PLAY = 1, M_DAWN = 2, M_SCARE = 3;
    // places the toys can be in
    private static final int STAGE = 0, PLAYROOM = 1, WEST = 2, EAST = 3, STORE = 4, MUSIC = 5, DOOR_W = 6, DOOR_E = 7;
    private static final int NIGHTS = 5, HOURS = 6, HOUR_TICKS = 900;
    /** How restless each toy is on each night (0 = it stays on the stage): bunny, cat, bear. */
    private static final int[][] LVL = {{5, 7, 9, 12, 15}, {0, 6, 8, 11, 14}, {0, 0, 5, 9, 13}};
    private static final int[] BASE_INT = {150, 165, 200};
    private static final int[] TUNE = {0, 3, 7, 3, 5, 2, 0, -2, 0, 3, 7, 10, 8, 7, 3, 0};
    private static final int CARD_TICKS = 190;

    private int mode, t, night, nightT, hour;
    private final int[] pos = new int[3];
    private final int[] moveT = new int[3], doorT = new int[3];
    private final boolean[] seen = new boolean[3];
    private boolean doorW, doorE, lightW, lightE, cam, winding, win, darkDeath, powerOut;
    private int keyLightW, keyLightE, camSel, glitchT, flick, noteI, noteT, heartT, knockT, scareWho, emptyT, outT;
    private float doorWA, doorEA, camA;
    private double power, wind;

    // ================================================================== life cycle
    @Override
    public void reset() {
        score = 0; over = false; win = false; darkDeath = false;
        night = 0; mode = M_CARD; t = 0; scareWho = 0;
        initNight();
    }

    private void initNight() {
        nightT = 0; hour = 0; power = 100; wind = 100; emptyT = 0; powerOut = false; outT = 0;
        doorW = false; doorE = false; lightW = false; lightE = false; keyLightW = 0; keyLightE = 0;
        cam = false; camSel = 0; camA = 0; doorWA = 0; doorEA = 0; winding = false;
        for (int i = 0; i < 3; i++) { pos[i] = STAGE; moveT[i] = 240 + rnd.nextInt(200); doorT[i] = 0; seen[i] = false; }
        glitchT = 0; flick = 0; noteI = 0; noteT = 30; heartT = 0; knockT = 0;
    }

    @Override
    public String hintKey() { return "cutemod.hint.night"; }

    @Override
    public Component status() { return Component.translatable("cutemod.night.status", night + 1, (int) Math.ceil(power)); }

    @Override
    public boolean isWin() { return win; }

    @Override
    public Component endTitle() {
        if (win) return Component.translatable("cutemod.night.end.win");
        return Component.translatable(darkDeath ? "cutemod.night.end.4" : "cutemod.night.end." + scareWho);
    }

    private static String str(String key, Object... a) { return Component.translatable(key, a).getString(); }

    private String hourStr() { return str("cutemod.night.h." + Math.min(hour, 6)); }

    private boolean lightWOn() { return !powerOut && !cam && (lightW || keyLightW > 0); }

    private boolean lightEOn() { return !powerOut && !cam && (lightE || keyLightE > 0); }

    private int usage() {
        if (powerOut) return 0;
        return 1 + (doorW ? 1 : 0) + (doorE ? 1 : 0) + (lightWOn() ? 1 : 0) + (lightEOn() ? 1 : 0) + (cam ? 1 : 0);
    }

    private static void thud(float pitch, float vol) { sound(SoundEvents.NOTE_BLOCK_BASEDRUM, pitch, vol); }

    // ================================================================== the clock
    @Override
    public void tick() {
        if (over) return;
        t++;
        switch (mode) {
            case M_CARD -> {
                if (t == 8) sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 0.5F);
                if (t >= CARD_TICKS) { mode = M_PLAY; t = 0; sound(SoundEvents.NOTE_BLOCK_BASS, 0.6F, 0.6F); }
            }
            case M_PLAY -> playTick();
            case M_DAWN -> {
                if (t >= 10 && t <= 150 && (t - 10) % 28 == 0) sound(SoundEvents.BELL_BLOCK, 1.0F, 0.9F);
                if (t == 160) sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.2F, 0.8F);
                if (t >= 240) {
                    if (night + 1 >= NIGHTS) { win = true; score += 50; over = true; return; }
                    night++; initNight(); mode = M_CARD; t = 0;
                }
            }
            default -> { if (t == 70) over = true; }
        }
    }

    private void playTick() {
        nightT++;
        camA = cam ? Math.min(1f, camA + 0.2f) : Math.max(0f, camA - 0.2f);
        doorWA += ((doorW ? 1f : 0f) - doorWA) * 0.3f; if (Math.abs((doorW ? 1f : 0f) - doorWA) < 0.02f) doorWA = doorW ? 1f : 0f;
        doorEA += ((doorE ? 1f : 0f) - doorEA) * 0.3f; if (Math.abs((doorE ? 1f : 0f) - doorEA) < 0.02f) doorEA = doorE ? 1f : 0f;
        if (glitchT > 0) glitchT--;
        if (keyLightW > 0) keyLightW--;
        if (keyLightE > 0) keyLightE--;
        if (flick > 0) flick--; else if (rnd.nextInt(260) == 0) flick = 4 + rnd.nextInt(6);

        int h = nightT / HOUR_TICKS;
        if (h != hour) {
            hour = h;
            if (hour >= HOURS) { dawn(); return; }
            score += 2;
            sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.7F, 0.45F);
        }

        if (powerOut) { outTick(); return; }

        power -= usage() * (0.0072 + 0.0003 * night);
        if (power <= 0) { power = 0; goPowerOut(); return; }

        // the music box
        wind = Math.max(0, wind - (0.026 + 0.005 * night));
        if (winding && cam && camSel == MUSIC) wind = Math.min(100, wind + 0.75);
        if (wind > 0) {
            emptyT = 0;
            if (--noteT <= 0) {
                noteT = 16 + (int) ((100 - wind) * 0.3);
                float p = (float) Math.pow(2, TUNE[noteI++ % TUNE.length] / 12.0);
                sound(SoundEvents.NOTE_BLOCK_BELL, p, cam && camSel == MUSIC ? 0.55F : 0.16F);
            }
        } else {
            if (++emptyT == 1) sound(SoundEvents.NOTE_BLOCK_BASS, 0.5F, 0.8F);
            if (emptyT > 160 && emptyT % 70 == 0) sound(SoundEvents.PHANTOM_AMBIENT, 0.6F, 0.35F);
            if (emptyT >= dollLimit()) { scare(3); return; }
        }

        // the toys
        boolean threat = false, knock = false;
        for (int i = 0; i < 3; i++) {
            int lvl = LVL[i][night];
            if (lvl == 0) continue;
            if (pos[i] == DOOR_W || pos[i] == DOOR_E) {
                boolean west = pos[i] == DOOR_W;
                boolean closed = west ? doorW : doorE;
                boolean lit = west ? lightWOn() : lightEOn();
                if (lit && !seen[i]) { seen[i] = true; sound(SoundEvents.ENDERMAN_STARE, 0.6F, 0.5F); }
                if (closed) knock = true; else threat = true;
                if (--doorT[i] <= 0) {
                    if (closed) {                                         // it bangs on the door and goes away
                        sound(SoundEvents.SHIELD_BLOCK, 0.5F, 0.9F);
                        pos[i] = PLAYROOM; seen[i] = false; moveT[i] = BASE_INT[i] + 60; glitchT = 8;
                    } else { scare(i); return; }
                }
            } else {
                if (i == 2 && cam && camSel == pos[i] && pos[i] <= STORE) continue;      // the bear freezes while it is watched
                if (--moveT[i] <= 0) {
                    moveT[i] = Math.max(70, BASE_INT[i] - 8 * night) + rnd.nextInt(60);
                    if (rnd.nextInt(20) < lvl) moveToy(i);
                }
            }
        }
        if (threat && ++heartT % 36 == 0) thud(0.5F, 0.7F);
        if (knock && ++knockT % 30 == 0) thud(0.9F, 0.45F);
        if (rnd.nextInt(520) == 0) sound(SoundEvents.ENDERMAN_AMBIENT, 0.5F, 0.25F);
    }

    private int dollLimit() { return 520 - 50 * night; }

    private void moveToy(int i) {
        int p = pos[i], np;
        float f = rnd.nextFloat();
        switch (p) {
            case STAGE -> np = PLAYROOM;
            case PLAYROOM -> {
                if (i == 0) np = f < 0.75F ? WEST : f < 0.9F ? STORE : EAST;
                else if (i == 1) np = f < 0.35F ? EAST : f < 0.9F ? STORE : WEST;
                else np = f < 0.4F ? WEST : f < 0.7F ? EAST : STORE;
            }
            case STORE -> np = f < 0.8F ? EAST : PLAYROOM;
            case WEST -> np = f < 0.85F ? DOOR_W : PLAYROOM;
            case EAST -> np = f < 0.85F ? DOOR_E : PLAYROOM;
            default -> np = PLAYROOM;
        }
        if (cam && (camSel == p || camSel == np)) glitchT = 7;
        pos[i] = np;
        seen[i] = false;
        if (np == DOOR_W || np == DOOR_E) {
            doorT[i] = (i == 2 ? 170 : 230) - 10 * night;
            sound(SoundEvents.STONE_STEP, 0.5F, 0.8F);
            thud(0.55F, 0.5F);
        } else {
            sound(SoundEvents.STONE_STEP, 0.6F + rnd.nextFloat() * 0.2F, 0.3F);
        }
    }

    private void goPowerOut() {
        powerOut = true; outT = 0; darkDeath = false;
        doorW = false; doorE = false; lightW = false; lightE = false; keyLightW = 0; keyLightE = 0; cam = false; winding = false;
        sound(SoundEvents.NOTE_BLOCK_BASS, 0.5F, 1.0F);
        sound(SoundEvents.GENERIC_EXPLODE, 0.5F, 0.15F);
    }

    private void outTick() {
        outT++;
        camA = Math.max(0f, camA - 0.2f);
        doorWA = Math.max(0f, doorWA - 0.2f); doorEA = Math.max(0f, doorEA - 0.2f);
        if (outT >= 150 && outT < 150 + 8 * 30 && (outT - 150) % 30 == 0) {          // the bear hums its tune
            float p = (float) Math.pow(2, TUNE[((outT - 150) / 30) % TUNE.length] / 12.0 - 0.5);
            sound(SoundEvents.NOTE_BLOCK_BELL, Math.max(0.5F, p), 0.7F);
        }
        if (outT > 150 && outT % 45 == 0) thud(0.5F, 0.6F);
        if (outT >= 450) { darkDeath = true; scare(2); }
    }

    private void scare(int who) {
        mode = M_SCARE; t = 0; scareWho = who; cam = false; winding = false;
        growl(G_SCREAM); growl(G_ROAR);
        sound(SoundEvents.GLASS_BREAK, 0.5F, 0.7F);
    }

    private void dawn() {
        mode = M_DAWN; t = 0; cam = false; winding = false;
        score += 15 + (int) (power / 5);
    }

    // ================================================================== input
    private void toggleCam() {
        if (powerOut) return;
        cam = !cam; glitchT = 5; winding = false;
        if (cam) { lightW = false; lightE = false; keyLightW = 0; keyLightE = 0; }
        sound(SoundEvents.NOTE_BLOCK_BASS, cam ? 1.4F : 1.0F, 0.4F);
    }

    private void toggleDoor(boolean west) {
        if (powerOut) return;
        boolean now = west ? (doorW = !doorW) : (doorE = !doorE);
        sound(SoundEvents.SHIELD_BLOCK, now ? 0.55F : 0.85F, 0.6F);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (mode == M_CARD) { if (t > 40) t = CARD_TICKS; return true; }
        if (mode != M_PLAY || powerOut) return mode == M_PLAY;
        if (cam) {
            if (y >= 124) {
                for (int i = 0; i < 6; i++) if (in(x, y, 4 + i * 24, 126, 22, 12)) { camSel = i; glitchT = 6; winding = false; beep(); return true; }
                if (in(x, y, 152, 126, 64, 12)) toggleCam();
                return true;
            }
            if (camSel == MUSIC && in(x, y, 66, 100, 88, 18)) winding = true;
            return true;
        }
        if (in(x, y, 60, 126, 100, 12)) { toggleCam(); return true; }
        if (in(x, y, 1, 36, 20, 24)) { toggleDoor(true); return true; }
        if (in(x, y, 1, 62, 20, 24)) { lightW = true; return true; }
        if (in(x, y, 199, 36, 20, 24)) { toggleDoor(false); return true; }
        if (in(x, y, 199, 62, 20, 24)) { lightE = true; return true; }
        if (in(x, y, 20, 24, 38, 80)) { toggleDoor(true); return true; }
        if (in(x, y, 164, 24, 38, 80)) { toggleDoor(false); return true; }
        return true;
    }

    @Override
    public boolean release(int x, int y, int button) {
        lightW = false; lightE = false; winding = false;
        return false;
    }

    @Override
    public boolean key(int keyCode) {
        if (mode == M_CARD) { if (t > 40) t = CARD_TICKS; return true; }
        if (mode != M_PLAY || powerOut) return mode == M_PLAY;
        switch (keyCode) {
            case 65, KEY_LEFT -> { if (!cam) toggleDoor(true); }
            case 68, KEY_RIGHT -> { if (!cam) toggleDoor(false); }
            case 81 -> { if (!cam) keyLightW = 45; }
            case 69 -> { if (!cam) keyLightE = 45; }
            case 32, 83, KEY_DOWN, 258 -> toggleCam();
            case 87, KEY_UP -> { if (cam && camSel == MUSIC) wind = Math.min(100, wind + 7); }
            default -> {
                if (keyCode >= 49 && keyCode <= 54) {
                    if (!cam) toggleCam();
                    camSel = keyCode - 49; glitchT = 6; winding = false;
                } else return false;
            }
        }
        return true;
    }

    // ================================================================== drawing
    @Override
    public void render(GuiGraphics g) {
        switch (mode) {
            case M_CARD -> renderCard(g);
            case M_DAWN -> renderDawn(g);
            case M_SCARE -> renderScare(g);
            default -> {
                if (camA >= 0.5F) renderCam(g); else renderOffice(g);
                if (camA > 0F && camA < 1F) NightArt.r(g, 0, 0, W, H, Gfx.alpha(0xFF000000, (int) ((1 - Math.abs(camA - 0.5F) * 2) * 230)));
                renderHud(g);
            }
        }
    }

    private void bigText(GuiGraphics g, String s, int cx, int y, float k, int argb) {
        if (((argb >>> 24) & 255) < 6) return;
        g.pose().pushPose();
        g.pose().translate(cx, y, 0);
        g.pose().scale(k, k, 1f);
        ctext(g, s, 0, 0, argb);
        g.pose().popPose();
    }

    private void vignette(GuiGraphics g, int strength) {
        for (int k = 0; k < 6; k++) {
            int a = strength * (6 - k) / 6 / 3;
            int c = Gfx.alpha(0xFF04020A, a);
            NightArt.r(g, 0, k * 6, W, 6, k == 0 ? c : Gfx.alpha(0xFF04020A, a / 2));
            NightArt.r(g, 0, H - 6 - k * 6, W, 6, c);
            NightArt.r(g, k * 8, 0, 8, H, c);
            NightArt.r(g, W - 8 - k * 8, 0, 8, H, c);
        }
    }

    private void renderCard(GuiGraphics g) {
        NightArt.r(g, 0, 0, W, H, 0xFF06040E);
        for (int i = 0; i < 30; i++) {
            int sx = (int) (NightArt.rnd01(i, 31) * 218), sy = (int) (NightArt.rnd01(i, 32) * 136);
            NightArt.r(g, sx, sy, 1, 1, Gfx.alpha(0xFFE8E4FF, ((t / 14 + i) % 5 == 0) ? 40 : 130));
        }
        Gfx.disc(g, 176, 26, 11, 0xFFE9E4FF); Gfx.disc(g, 181, 22, 10, 0xFF06040E);
        int a = t < 30 ? t * 255 / 30 : t > CARD_TICKS - 30 ? (CARD_TICKS - t) * 255 / 30 : 255;
        a = Math.max(0, Math.min(255, a));
        bigText(g, str("cutemod.night.card", night + 1), W / 2, 40, 2.2F, Gfx.alpha(0xFFF0E8FF, a));
        bigText(g, str("cutemod.night.h.0"), W / 2, 72, 1.1F, Gfx.alpha(0xFFB8A8E8, a));
        ctextW(g, str("cutemod.night.card.sub." + night), W / 2, 92, 200, Gfx.alpha(0xFFD8C8F0, a * 7 / 10));
        ctextW(g, str("cutemod.night.card.tip"), W / 2, 120, 210, Gfx.alpha(0xFF8A7AB8, a * 6 / 10));
        vignette(g, 120);
    }

    private void renderDawn(GuiGraphics g) {
        float k = Math.min(1f, t / 150f);
        NightArt.grad(g, 0, 0, W, 100, Gfx.mix(0xFF140E34, 0xFF5A78C8, k), Gfx.mix(0xFF2A1E4A, 0xFFFFB878, k));
        NightArt.r(g, 0, 100, W, 40, 0xFF0C0814);
        int sy = 112 - (int) (k * 44);
        Gfx.disc(g, 110, sy, 16, Gfx.mix(0xFFFF8A4A, 0xFFFFE8A0, k));
        Gfx.ellipse(g, 110, sy, 38, 22, Gfx.alpha(0xFFFFC888, (int) (40 * k)));
        for (int x = 0; x < W; x += 12) {                                          // the roofs of the town
            int h = 10 + (int) (NightArt.rnd01(x, 41) * 14);
            NightArt.r(g, x, 100 - h, 12, h, 0xFF120C1E);
            if (NightArt.rnd01(x, 42) > 0.6F) NightArt.r(g, x + 4, 100 - h + 4, 3, 3, Gfx.alpha(0xFFFFD890, 130 - (int) (k * 100)));
        }
        NightArt.r(g, 0, 100, W, 40, 0xFF0C0814);
        bigText(g, str("cutemod.night.h.6"), W / 2, 106, 2.0F, Gfx.alpha(0xFFFFF0D0, Math.min(255, t * 6)));
        if (t > 40) ctextW(g, str("cutemod.night.survived", night + 1), W / 2, 126, 210, Gfx.alpha(0xFFE8DCF8, Math.min(255, (t - 40) * 8)));
        if (t > 200) NightArt.r(g, 0, 0, W, H, Gfx.alpha(0xFF000000, Math.min(255, (t - 200) * 6)));
    }

    private void renderScare(GuiGraphics g) {
        int tt = Math.min(t, 70);
        boolean flashOn = tt < 40 && (tt / 2) % 2 == 0;
        NightArt.r(g, 0, 0, W, H, tt < 3 ? 0xFFFFFFFF : flashOn ? 0xFF4A0A14 : 0xFF14030A);
        float s = 2.0F + Math.min(tt, 16) * 0.14F;
        int shx = tt < 55 ? rnd.nextInt(9) - 4 : 0, shy = tt < 55 ? rnd.nextInt(9) - 4 : 0;
        float by = 60 + 20 * s;
        NightArt.toy(g, scareWho, W / 2F + shx, by + shy, s, 2, t, 0, tt > 56 ? 0.45F : 0F);
        for (int i = 0; i < 12; i++) NightArt.r(g, 0, rnd.nextInt(H), W, 1 + rnd.nextInt(2), Gfx.alpha(0xFFFFFFFF, 30 + rnd.nextInt(40)));
        vignette(g, 300);
        if (tt > 60) NightArt.r(g, 0, 0, W, H, Gfx.alpha(0xFF000000, (tt - 60) * 12));
    }

    private void renderOffice(GuiGraphics g) {
        NightArt.office(g, t, hour, night);
        // the guard feels watched: the doll creeps to the window
        if (!powerOut && wind <= 0) {
            float p = Math.min(1f, emptyT / (float) dollLimit());
            NightArt.toy(g, 3, 110, 62 + 8 * p, 0.45F + 0.9F * p, 1, t, 0, 0.55F - 0.3F * p);
            NightArt.r(g, 76, 20, 8, 48, 0xFF4A1830); NightArt.r(g, 136, 20, 8, 48, 0xFF4A1830);
        }
        doorway(g, true);
        doorway(g, false);
        panels(g);
        // the monitor bar
        boolean hov = in(mx, my, 60, 126, 100, 12);
        Gfx.bubble(g, 60, 126, 100, 12, 4, hov ? 0xFF4C4278 : 0xFF362F58);
        ctext(g, str("cutemod.night.cams"), 110, 127, 0xFFE8E0FF);
        // darkness
        int dark = 60 + (flick > 0 && (flick & 1) == 0 ? 70 : 0) + (powerOut ? 130 : 0) + (power < 15 && !powerOut ? (t / 6 % 3 == 0 ? 40 : 0) : 0);
        NightArt.r(g, 0, 0, W, H, Gfx.alpha(0xFF050210, Math.min(235, dark)));
        vignette(g, powerOut ? 330 : 230);
        if (powerOut && outT > 20 && (outT / 20) % 2 == 0 && outT < 200) ctext(g, str("cutemod.night.out"), 110, 62, 0xFFFF5A5A);
    }

    private void doorway(GuiGraphics g, boolean west) {
        int x = west ? 22 : 166;
        float da = west ? doorWA : doorEA;
        boolean lit = west ? lightWOn() : lightEOn();
        NightArt.hallView(g, x, lit, t, !west);
        int here = west ? DOOR_W : DOOR_E;
        if (da < 0.6F) {
            for (int i = 0; i < 3; i++) {
                if (pos[i] != here) continue;
                if (lit) NightArt.toy(g, i, x + 16, 101, 1.15F, 1, t, 0, 0.08F);
                else if (((t + i * 37) % 150) < 6) {                                 // two eyes in the dark
                    int c = i == 2 ? 0xFFFF4A50 : 0xFFF4F0FF;
                    NightArt.r(g, x + 10, 73, 3, 2, c); NightArt.r(g, x + 19, 73, 3, 2, c);
                }
            }
            if (powerOut && outT > 90 && west && ((outT / 7) % 9) < 6) {            // the bear's eyes in the blackout
                NightArt.r(g, x + 9, 70, 4, 3, 0xFFF4F0FF); NightArt.r(g, x + 19, 70, 4, 3, 0xFFF4F0FF);
                if (outT > 300) NightArt.toy(g, 2, x + 16, 101, 1.25F, 1, t, 0, 0.8F);
            }
        }
        NightArt.door(g, x, da, t);
        int fx = west ? 18 : 162;
        NightArt.r(g, fx, 22, 40, 4, 0xFF3C2C48); NightArt.r(g, fx, 26, 4, 76, 0xFF3C2C48); NightArt.r(g, fx + 36, 26, 4, 76, 0xFF3C2C48);
    }

    private void panels(GuiGraphics g) {
        for (int side = 0; side < 2; side++) {
            int px = side == 0 ? 1 : 199;
            boolean west = side == 0;
            boolean closed = west ? doorW : doorE, lit = west ? lightWOn() : lightEOn();
            Gfx.rrect(g, px, 33, 20, 56, 3, 0xFF2A2238);
            Gfx.rrect(g, px + 1, 34, 18, 54, 3, 0xFF372E48);
            boolean hd = in(mx, my, px, 36, 20, 24), hl = in(mx, my, px, 62, 20, 24);
            Gfx.bubble(g, px + 2, 37, 16, 22, 3, closed ? (hd ? 0xFFE0564F : 0xFFC03C3C) : (hd ? 0xFF4A5A78 : 0xFF3C4860));
            NightArt.r(g, px + 6, 41, 8, 13, closed ? 0xFFF0C8C0 : 0xFF8A98B8); NightArt.r(g, px + 12, 47, 1, 2, 0xFF2A2030);
            Gfx.bubble(g, px + 2, 63, 16, 22, 3, lit ? 0xFFF0C84A : (hl ? 0xFF5A5A78 : 0xFF444460));
            Gfx.disc(g, px + 10, 72, 4, lit ? 0xFFFFF6C0 : 0xFF8A8AA8);
            NightArt.r(g, px + 8, 77, 4, 4, lit ? 0xFFB89830 : 0xFF6A6A84);
            if (lit) Gfx.ellipse(g, px + 10, 72, 10, 7, Gfx.alpha(0xFFFFE890, 40));
        }
    }

    private void renderCam(GuiGraphics g) {
        if (camSel == MUSIC) NightArt.music(g, t, wind, winding);
        else NightArt.room(g, camSel, t, night);
        int k = 0;
        for (int i = 0; i < 3; i++) {
            if (pos[i] != camSel) continue;
            float x, by, s;
            switch (camSel) {
                case STAGE -> { x = i == 0 ? 58 : i == 2 ? 110 : 162; by = 95; s = 1.0F; }
                case PLAYROOM -> { x = 64 + k * 44; by = 114; s = 1.25F; }
                case WEST, EAST -> { x = 110 + (k - 1) * 12; by = 102; s = 0.95F; }
                default -> { x = 74 + k * 36; by = 109; s = 1.2F; }
            }
            int look = i == 2 ? 0 : (int) Math.round(Math.sin(t * 0.03 + i));
            NightArt.toy(g, i, x, by, s, glitchT > 0 ? 1 : 0, t, look, 0.1F);
            k++;
        }
        // the camera: green-teal tint, scan lines, rolling bar, noise, glitches
        NightArt.r(g, 0, 0, W, 124, Gfx.alpha(0xFF40FFD0, 26));
        for (int y = 0; y < 124; y += 2) NightArt.r(g, 0, y, W, 1, Gfx.alpha(0xFF000000, 30));
        int roll = (t * 2) % 170 - 20;
        NightArt.r(g, 0, roll, W, 9, Gfx.alpha(0xFFFFFFFF, 11));
        for (int i = 0; i < 26; i++) NightArt.r(g, rnd.nextInt(W), rnd.nextInt(124), 1, 1, Gfx.alpha(0xFFFFFFFF, 28));
        if (glitchT > 0) {
            for (int i = 0; i < 6; i++) NightArt.r(g, 0, rnd.nextInt(124), W, 2 + rnd.nextInt(5), Gfx.alpha(i % 2 == 0 ? 0xFFB0FFE8 : 0xFFFF70D0, 50 + glitchT * 8));
        }
        if (flick > 0 && (flick & 1) == 0) NightArt.r(g, 0, 0, W, 124, Gfx.alpha(0xFF000000, 60));
        // the music box room has a winding key
        if (camSel == MUSIC) {
            boolean low = wind < 25;
            NightArt.r(g, 50, 16, 120, 5, 0xAA000000);
            NightArt.r(g, 51, 17, (int) (118 * wind / 100.0), 3, low && (t / 8) % 2 == 0 ? 0xFFFF5A5A : low ? 0xFFE88A4A : 0xFF8AF0C8);
            boolean hd = winding || in(mx, my, 66, 100, 88, 18);
            Gfx.bubble(g, 66, 100, 88, 18, 4, winding ? 0xFF2F8F7A : hd ? 0xFF5A4C8C : 0xFF40386A);
            ctextW(g, str("cutemod.night.wind"), 110, 105, 80, 0xFFF4EEFF);
        }
        vignette(g, 260);
        // the bar with the cameras
        NightArt.r(g, 0, 124, W, 16, 0xFF0C0A14); NightArt.r(g, 0, 124, W, 1, 0xFF3A3A4A);
        for (int i = 0; i < 6; i++) {
            boolean hv = in(mx, my, 4 + i * 24, 126, 22, 12);
            Gfx.bubble(g, 4 + i * 24, 126, 22, 12, 3, i == camSel ? 0xFF2F8F7A : hv ? 0xFF4A4670 : 0xFF2C2848);
            ctext(g, String.valueOf(i + 1), 4 + i * 24 + 11, 127, 0xFFFFFFFF);
        }
        boolean hc = in(mx, my, 152, 126, 64, 12);
        Gfx.bubble(g, 152, 126, 64, 12, 3, hc ? 0xFF7A3A4A : 0xFF5A2E3C);
        ctextW(g, str("cutemod.night.close"), 184, 127, 58, 0xFFFFE8EC);
    }

    private void renderHud(GuiGraphics g) {
        boolean inCam = camA >= 0.5F;
        NightArt.grad(g, 0, 0, W, 28, Gfx.alpha(0xFF000000, 140), Gfx.alpha(0xFF000000, 0));
        if (inCam) {
            text(g, str("cutemod.night.cam", camSel + 1, str("cutemod.night.cam." + camSel)), 5, 3, 0xFFC8FFF0);
        } else {
            text(g, hourStr(), 5, 3, 0xFFEDE6FF);
            text(g, str("cutemod.night.card", night + 1), 5, 13, 0xFF9C8CC8);
        }
        int pct = (int) Math.ceil(power);
        String ps = pct + "%";
        int pc = pct > 50 ? 0xFF9CE6A8 : pct > 20 ? 0xFFFFE08A : 0xFFFF6A6A;
        if (pct <= 15 && (t / 8) % 2 == 0) pc = 0xFFFFFFFF;
        text(g, ps, W - 5 - tw(ps), 3, pc);
        int u = usage();
        for (int i = 0; i < u; i++) NightArt.r(g, W - 5 - 30 + i * 5, 14, 4, 5, i < 2 ? 0xFF7AE090 : i < 4 ? 0xFFFFD070 : 0xFFFF6A6A);
        if (inCam) {
            if ((t / 30) % 2 == 0) Gfx.disc(g, W - 12 - tw(ps), 7, 2, 0xFFFF3A3A);
        }
        if (inCam && hour < 6) text(g, hourStr(), W - 5 - tw(hourStr()), 21, 0xFFC8FFF0);
    }
}
