package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Fly Catcher: a frog sits on a lily pad in the middle of a night swamp. Insects buzz around it. Aim with the mouse and
 * click to shoot the tongue: it flies to the cursor (but no further than the dashed ring) and sticks to the first
 * insect on the way. Flies, bluebottles, butterflies and dragonflies give points, a firefly also gives a bonus for one of
 * the four jars at the top (slow time, a long tongue, double points, a thunderclap). A wasp costs 200 points.
 * Catches in a row build a combo (the meter on the left): a miss or a wasp breaks it.
 * <p>
 * Every level has its own modifiers (swarm, gold rush, wind, sinking bog, short tongue, hurricane, streak ...) and floating
 * bonus bubbles drift over the swamp: hourglass (+time), heart, shield, ice (freezes the bugs) and a wide tongue. Armoured
 * beetles need two hits, golden flies are worth a lot. The time bar runs slowly.
 * <p>
 * Every normal level has its own map: a layout of pads of different sizes, reed clumps that stop the tongue, logs, stones,
 * cattails and its own tint of the water.
 * <p>
 * The fifth level of every part is a big reed maze that scrolls: hop from pad to pad through the passages, eat the wasps that
 * guard pads, and find the exit.
 * <p>
 * Five parts of five levels. Reach the goal score before the time bar runs out; a level that is lost costs a heart and is
 * replayed. The fifth level of every part is a long final level: a big boss bug joins halfway, and it must be hit with the
 * tongue several times (it cannot be eaten) as well as the goal reached. A new part gives a heart back and a new swamp:
 * 1 night, 2 crimson, 3 frost, 4 toxic, 5 starry.
 * <p>
 * The frog can hop between five lily pads (right click on a pad, or the arrow keys). From part 2 on the pads sink: one
 * shakes, goes under for a few seconds and comes back, and a frog that is still on it falls into the water. Every part has
 * its own tricks: 1 bumblebees (slow to pull in, they give a jar), 2 wasp swarms and sinking pads, 3 frozen bugs and
 * hornets (-400), 4 toxic flies (they make the frog dizzy: the tongue goes the wrong way), 5 falling stars and everything at once.
 */
public class FlyCatcher extends MiniGame {
    private static final int PARTS = 5, PER = 5, LEVELS = PARTS * PER, LIVES = 3, MAX_LIVES = 5, NORMAL_TICKS = 7800, FINAL_TICKS = 15000, COMBO_TIME = 170;
    private static final float RANGE = 66F, OUT = 7F, IN = 6F;
    private static final int FLY = 0, BLUEBOTTLE = 1, BUTTERFLY = 2, DRAGONFLY = 3, FIREFLY = 4, WASP = 5, BOSS = 6, HORNET = 7, BUMBLE = 8, TOXIC = 9, STAR = 10,
            BEETLE = 11, HOURGLASS = 12, HEART = 13, SHIELD = 14, ICE = 15, NET = 16, GOLD = 17;
    private static final int[] VALUE = {50, 100, 150, 250, 200, -200, 0, -400, 300, -100, 500, 300, 100, 100, 100, 100, 100, 700};
    private static final float[] SPEED = {0.55F, 0.45F, 0.3F, 0.85F, 0.25F, 0.65F, 0.35F, 0.95F, 0.3F, 0.5F, 1.5F, 0.3F, 0.22F, 0.22F, 0.22F, 0.22F, 0.22F, 0.7F};
    private static final float[] RAD = {3F, 3.5F, 4.5F, 4F, 3.5F, 4F, 8F, 5F, 5.5F, 3.5F, 3.5F, 4.5F, 5F, 5F, 5F, 5F, 5F, 3.5F};
    private static final int J_SLOW = 0, J_LONG = 1, J_DOUBLE = 2, J_THUNDER = 3;
    private static final int[] JAR_COL = {0xFF6FB8FF, 0xFF7ED957, 0xFFFFD84A, 0xFFB57BFF};
    private static final int S_PLAY = 0, S_CLEAR = 1, S_FAIL = 2;
    // the five swamps: night, crimson, frost, toxic, starry
    private static final int[] BG_TOP = {0xFF0A1442, 0xFF2C0610, 0xFF0A2A4A, 0xFF16062A, 0xFF05050F};
    private static final int[] BG_BOT = {0xFF123478, 0xFF640F26, 0xFF1E5A8A, 0xFF3A1262, 0xFF1C1646};
    private static final int[] PAD = {0xFF3FB44A, 0xFF9A1E32, 0xFF7ED0D0, 0xFF5AC03A, 0xFFE0B83A};
    private static final int[] PAD2 = {0xFF8ED04A, 0xFFC8344A, 0xFFB8F0F0, 0xFFB8E85A, 0xFFFFE27A};
    private static final int[] STUMP = {0xFF8A6A2E, 0xFF5A1A22, 0xFF8AA8C0, 0xFF5A3A7A, 0xFF6A5A8A};
    private static final int[] SPECK = {0xFF3FB04D, 0xFFC03048, 0xFFBEE8FF, 0xFF8AE04A, 0xFFFFE27A};
    private static final int[] PETAL = {0xFFFFFFFF, 0xFFFF6A7A, 0xFFE8FAFF, 0xFFE0A0FF, 0xFFFFF4C0};
    private static final int[] BOSS_COL = {0xFFFFD02A, 0xFFD0283A, 0xFF7AD8FF, 0xFFA0E04A, 0xFFFFE27A};
    private static final int[][] PADS = {{110, 116}, {34, 104}, {186, 104}, {52, 70}, {168, 70}};
    private static final int WARN = 100, UNDER = 260, RISE = 40;
    // the level modifiers: every level has its own mix of them (a bit mask)
    private static final int M_SWARM = 1, M_GOLD = 2, M_BUTTER = 4, M_WASPS = 8, M_SINK = 16, M_WIND = 32, M_SHORT = 64, M_FAST = 128, M_COMBO = 256;
    private static final int[] MOD_COL = {0xFFB8F0FF, 0xFFFFE066, 0xFFFF8FC8, 0xFFFF9A4A, 0xFF7AD8A0, 0xFFD0E8FF, 0xFFFF7A7A, 0xFFFF5AE0, 0xFFC8A0FF};
    private static final int[] MODS = {
            0, M_SWARM, M_GOLD, M_BUTTER, 0,
            M_WASPS, M_SINK, M_SHORT, M_COMBO, 0,
            M_FAST, M_SWARM | M_SHORT, M_WIND | M_SINK, M_WASPS | M_BUTTER, 0,
            M_GOLD | M_WIND, M_SHORT | M_FAST, M_SWARM | M_WASPS, M_COMBO | M_SINK, 0,
            M_BUTTER | M_FAST, M_WASPS | M_SHORT, M_SINK | M_WIND | M_COMBO, M_SWARM | M_COMBO | M_FAST, 0};
    // the final level of every part is a big reed maze: CELL x CELL cells, one lily pad in each, reeds are the walls
    private static final int CELL = 44, WALL = 6;
    // the maps of the normal levels: every layout has its own pads (the first one is where the frog starts)
    private static final int[][][] LAYOUTS = {
            {{110, 116}, {34, 104}, {186, 104}, {52, 70}, {168, 70}},                                   // 0 the classic cove
            {{28, 112}, {66, 94}, {106, 78}, {146, 64}, {186, 80}},                                     // 1 a staircase
            {{110, 118}, {60, 108}, {34, 78}, {66, 58}, {154, 58}, {186, 80}, {160, 108}},              // 2 a ring
            {{110, 116}, {30, 108}, {62, 90}, {36, 64}, {190, 108}, {158, 90}, {184, 64}},              // 3 twin islands
            {{110, 114}, {30, 98}, {190, 98}, {110, 64}},                                               // 4 far apart: long jumps
            {{24, 112}, {64, 86}, {104, 112}, {146, 86}, {186, 112}, {196, 62}},                        // 5 a zigzag
            {{110, 120}, {110, 86}, {110, 52}, {50, 102}, {170, 102}},                                  // 6 a column
            {{110, 118}, {24, 106}, {48, 78}, {86, 62}, {134, 62}, {172, 78}, {196, 106}},              // 7 a rainbow
            {{110, 120}, {60, 92}, {110, 60}, {160, 92}, {22, 118}, {198, 118}},                        // 8 a diamond
            {{110, 116}, {30, 116}, {70, 116}, {150, 116}, {190, 116}, {110, 68}},                      // 9 a dock
            {{110, 118}, {190, 112}, {150, 96}, {114, 82}, {74, 70}, {36, 60}}};                        // 10 a hillside
    private static final int[] LAYOUT_ORDER = {
            0, 1, 2, 3, 0,   4, 5, 6, 7, 0,   8, 9, 10, 3, 0,   2, 5, 7, 9, 0,   10, 6, 8, 1, 0};
    private static final int[] TINT = {0xFF1A7A6A, 0xFF3A2A9A, 0xFF6A7A1A, 0xFF8A2A7A, 0xFF2A5A8A, 0xFF7A5A2A};
    private static final int[][] CLASSIC_DECOR = {{0, 34, 36, 17, 0}, {0, 186, 34, 17, 1}, {1, 112, 27, 15, 2}, {4, 66, 40, 0, 0}, {4, 154, 124, 0, 0},
            {4, 196, 62, 0, 1}, {5, 70, 108, -1, 0}, {5, 150, 108, 1, 0}};
    // the bonus bubbles: hourglass, heart, shield, ice, wide tongue
    private static final int[] BONUS_COL = {0xFFFFB84A, 0xFFFF6A8E, 0xFF7AC8FF, 0xFFBEEBFF, 0xFFFF8AF0};
    private static final int JAR_X = 72, JAR_Y = 2, JAR_W = 16, JAR_H = 17, JAR_STEP = 19;

    private static final class Bug {
        final int kind;
        float x, y, a, turn, boost;
        int age, life, caught, hp, maxHp, hit, frozen;
        float spd;
        boolean straight;
        boolean dead;
        boolean still;
        int pad = -1;

        Bug(int kind) { this.kind = kind; }
    }

    private static final class Fx {
        float x, y, vx, vy;
        int life, max, col, kind;
        String txt;
    }

    private final List<Bug> bugs = new ArrayList<>();
    private final List<Fx> fx = new ArrayList<>();
    private final int[] jars = new int[4];
    private int level, lives, state, stateT, scoreBase, levelPts, timeLeft, time;
    private int combo, comboT, slowT, longT, doubleT, hurtT, flash, bannerT, gulpT;
    private int tState, totalTime, bannerKind;
    private boolean bossSpawned, bossDead, tHitBoss;
    private int[][] pads = PADS;
    private int[] padT = new int[PADS.length];
    private int frogX = pads[0][0], frogY = pads[0][1], frogPad, hopT, hopMax, hopFx, hopFy, sinkCool, swarmCool, dizzyT;
    private String bannerMsg = "";
    private float tLen, tGoal, tAng;
    private Bug tCatch;
    private boolean won;
    private int mods, shield, netT, bonusCool;
    private int[] reeds = new int[0];
    private int mCols, mRows, startPad, exitPad, prevPad, worldW = W, worldH = H;
    private boolean[] openR = new boolean[0], openD = new boolean[0], seen = new boolean[0];
    private int[] guardCells = new int[0];
    private float camX, camY;
    private int[] padR = new int[0];
    private int[][] decor = new int[0][];
    private String mapName = "";
    private float windX, windTo, windPos;
    private String modLine = "";

    // ------------------------------------------------------------------ start

    @Override
    public void reset() {
        score = 0; over = false; won = false; lives = LIVES; scoreBase = 0; time = 0;
        java.util.Arrays.fill(jars, 0);
        startLevel(0);
    }

    private void startLevel(int n) {
        level = n;
        mods = MODS[n];
        state = S_PLAY; stateT = 0;
        buildWorld();
        totalTime = isFinal() ? 3600 + 110 * mCols * mRows : NORMAL_TICKS;
        bossSpawned = false; bossDead = false; tHitBoss = false;
        levelPts = 0; timeLeft = totalTime; combo = 0; comboT = 0;
        slowT = 0; longT = 0; doubleT = 0; hurtT = 0; flash = 0; gulpT = 0;
        tState = 0; tLen = 0; tCatch = null;
        frogPad = startPad; prevPad = startPad; frogX = pads[startPad][0]; frogY = pads[startPad][1]; hopT = 0; dizzyT = 0;
        sinkCool = 240 + rnd.nextInt(120); swarmCool = 500 + rnd.nextInt(400);
        shield = 0; netT = 0; windX = windTo = 0F; bonusCool = 420 + rnd.nextInt(300);
        modLine = buildModLine();
        bannerT = 150;
        if (n % PER == 0) bannerMsg = Component.translatable("cutemod.frog.part." + part()).getString();
        else if (isFinal()) bannerMsg = T("maze");
        else bannerMsg = Component.translatable("cutemod.frog.start", goal()).getString();
        if (n % PER == 0) bannerT = 190;
        if (mods != 0) bannerT = Math.max(bannerT, 200);
        if (isFinal()) bannerT = 260;
        bugs.clear(); fx.clear();
        if (isFinal()) placeMazeBugs();
        else for (int i = 0; i < target() - 2; i++) spawn(true);
        score = scoreBase;
        updateCam(true);
    }

    private int part() { return level / PER; }

    /** Every map has a slightly different tint of the water. */
    private int tinted(int c) { return isFinal() || level == 0 ? c : Gfx.mix(c, TINT[(level * 3 + part() * 2) % TINT.length], 0.16F); }

    private int bgTop() { return tinted(BG_TOP[part()]); }

    private int bgBot() { return tinted(BG_BOT[part()]); }

    private boolean isFinal() { return level % PER == PER - 1; }

    /** The goal: it grows with every level; the final level of a part asks for more than twice as much. */
    private int goal() {
        int g = 800 + 400 * level;
        return isFinal() ? Math.round(g * 2.2F / 50F) * 50 : g;
    }

    private int target() { return Math.min(14, 5 + level / 2) + (has(M_SWARM) ? 4 : 0) + (bossSpawned && !bossDead ? 2 : 0); }

    // ------------------------------------------------------------------ the maze

    private void link(int a, int b) {
        if (b == a + 1) openR[a] = true;
        else if (b == a - 1) openR[b] = true;
        else if (b == a + mCols) openD[a] = true;
        else openD[b] = true;
    }

    /** The pad next to c in direction d (0 right, 1 left, 2 down, 3 up) if there is a passage through the reeds, else -1. */
    private int step(int c, int d) {
        int cc = c % mCols, cr = c / mCols;
        return switch (d) {
            case 0 -> cc < mCols - 1 && openR[c] ? c + 1 : -1;
            case 1 -> cc > 0 && openR[c - 1] ? c - 1 : -1;
            case 2 -> cr < mRows - 1 && openD[c] ? c + mCols : -1;
            default -> cr > 0 && openD[c - mCols] ? c - mCols : -1;
        };
    }

    private boolean connected(int a, int b) {
        if (!isFinal() || mCols == 0) return true;
        for (int d = 0; d < 4; d++) if (step(a, d) == b) return true;
        return false;
    }

    private boolean vWall(int c, int r) { return r >= 0 && r < mRows && (c == 0 || c == mCols || !openR[r * mCols + c - 1]); }

    private boolean hWall(int c, int r) { return c >= 0 && c < mCols && (r == 0 || r == mRows || !openD[(r - 1) * mCols + c]); }

    /** Sets up the world of the level: the five pads of a normal level, or a whole reed maze for a final. */
    private void buildWorld() {
        camX = camY = 0F;
        mapName = "";
        if (!isFinal()) { buildMap(); return; }
        int p = part();
        mCols = 6 + 2 * p; mRows = 4 + p;                                     // 6x4, 8x5, 10x6, 12x7, 14x8 cells
        int n = mCols * mRows;
        worldW = mCols * CELL; worldH = mRows * CELL;
        openR = new boolean[n]; openD = new boolean[n]; seen = new boolean[n];
        java.util.Random r = new java.util.Random(7919L * (level + 1) + 13);   // the same maze every time a level is replayed
        boolean[] vis = new boolean[n];
        int[] stack = new int[n], nb = new int[4];
        int sp = 0;
        startPad = (mRows - 1) * mCols;
        vis[startPad] = true; stack[sp++] = startPad;
        while (sp > 0) {                                                       // depth-first carving: a perfect maze
            int cur = stack[sp - 1], cc = cur % mCols, cr = cur / mCols, k = 0;
            if (cc > 0 && !vis[cur - 1]) nb[k++] = cur - 1;
            if (cc < mCols - 1 && !vis[cur + 1]) nb[k++] = cur + 1;
            if (cr > 0 && !vis[cur - mCols]) nb[k++] = cur - mCols;
            if (cr < mRows - 1 && !vis[cur + mCols]) nb[k++] = cur + mCols;
            if (k == 0) { sp--; continue; }
            int nx = nb[r.nextInt(k)];
            link(cur, nx);
            vis[nx] = true; stack[sp++] = nx;
        }
        for (int i = 0, extra = n / 7; i < extra; i++) {                       // a few more passages: loops give several routes
            int c = r.nextInt(n), cc = c % mCols, cr = c / mCols;
            if (r.nextBoolean() && cc < mCols - 1) openR[c] = true;
            else if (cr < mRows - 1) openD[c] = true;
        }
        pads = new int[n][];
        for (int c = 0; c < n; c++) pads[c] = new int[]{(c % mCols) * CELL + CELL / 2, (c / mCols) * CELL + 24};
        padT = new int[n];
        padR = new int[n];
        java.util.Arrays.fill(padR, 16);
        decor = new int[0][];
        // the exit is the pad that is the farthest from the start
        int[] dist = new int[n], par = new int[n], q = new int[n];
        java.util.Arrays.fill(dist, -1);
        int qh = 0, qt = 0;
        dist[startPad] = 0; par[startPad] = -1; q[qt++] = startPad;
        while (qh < qt) {
            int c = q[qh++];
            for (int d = 0; d < 4; d++) {
                int t = step(c, d);
                if (t < 0 || dist[t] >= 0) continue;
                dist[t] = dist[c] + 1; par[t] = c; q[qt++] = t;
            }
        }
        exitPad = startPad;
        for (int c = 0; c < n; c++) if (dist[c] > dist[exitPad]) exitPad = c;
        // wasp guards sit on the route to the exit: a guarded pad can not be entered until the wasp is eaten
        List<Integer> path = new ArrayList<>();
        for (int c = exitPad; c >= 0; c = par[c]) path.add(0, c);
        guardCells = new int[p];
        for (int i = 0; i < p; i++) guardCells[i] = path.get(path.size() * (i + 1) / (p + 1));
        // the reeds: a post wherever walls meet, a wall piece wherever there is no passage
        List<Integer> rl = new ArrayList<>();
        for (int vr = 0; vr <= mRows; vr++) for (int vc = 0; vc <= mCols; vc++)
            if (vWall(vc, vr - 1) || vWall(vc, vr) || hWall(vc - 1, vr) || hWall(vc, vr)) addRect(rl, vc * CELL - WALL / 2, vr * CELL - WALL / 2, WALL, WALL);
        for (int vc = 0; vc <= mCols; vc++) for (int vr = 0; vr < mRows; vr++)
            if (vWall(vc, vr)) addRect(rl, vc * CELL - WALL / 2, vr * CELL + WALL / 2, WALL, CELL - WALL);
        for (int vr = 0; vr <= mRows; vr++) for (int vc = 0; vc < mCols; vc++)
            if (hWall(vc, vr)) addRect(rl, vc * CELL + WALL / 2, vr * CELL - WALL / 2, CELL - WALL, WALL);
        reeds = new int[rl.size()];
        for (int i = 0; i < reeds.length; i++) reeds[i] = rl.get(i);
    }

    /** The map of a normal level: its own pads, reed clumps that stop the tongue, and its own scenery. */
    private void buildMap() {
        int tpl = LAYOUT_ORDER[level];
        boolean mirror = level % 3 == 1;
        int[][] src = LAYOUTS[tpl];
        java.util.Random r = new java.util.Random(977L * level + 3);
        pads = new int[src.length][];
        padR = new int[src.length];
        for (int attempt = 0; attempt < 8; attempt++) {                              // a little jitter and pads of different sizes, as long as they do not touch
            boolean last = attempt == 7;
            for (int i = 0; i < src.length; i++) {
                int x = src[i][0], y = src[i][1];
                if (level > 0 && !last) { x += r.nextInt(5) - 2; y += r.nextInt(5) - 2; }
                if (mirror) x = W - x;
                pads[i] = new int[]{x, y};
                padR[i] = level == 0 || last ? 16 : 13 + r.nextInt(7);
            }
            if (padsApart()) break;
        }
        padT = new int[pads.length];
        startPad = 0; exitPad = -1; worldW = W; worldH = H; mCols = mRows = 0; guardCells = new int[0];
        mapName = T("map." + tpl);
        List<Integer> rl = new ArrayList<>();
        int want = level == 0 ? 0 : Math.min(3, r.nextInt(3) + (part() >= 2 ? 1 : 0));
        for (int t = 0; t < 100 && rl.size() < want * 4; t++) {
            boolean horiz = r.nextBoolean();
            int len = 14 + r.nextInt(21), w = horiz ? len : WALL, h = horiz ? WALL : len;
            int x = 8 + r.nextInt(W - 16 - w), y = 36 + r.nextInt(70 - h);
            if (rectNearPad(x, y, w, h, 27) || rectsClose(rl, x, y, w, h, 10)) continue;
            addRect(rl, x, y, w, h);
        }
        reeds = new int[rl.size()];
        for (int i = 0; i < reeds.length; i++) reeds[i] = rl.get(i);
        decor = level == 0 ? CLASSIC_DECOR : buildDecor(r);
    }

    private boolean padsApart() {
        for (int i = 0; i < pads.length; i++) for (int j = i + 1; j < pads.length; j++) {
            float ex = padR[i] + padR[j] + 3F, ey = ex * 0.625F, dx = pads[i][0] - pads[j][0], dy = pads[i][1] - pads[j][1];
            if (dx * dx / (ex * ex) + dy * dy / (ey * ey) < 1F) return false;
        }
        return true;
    }

    private static float rectDist(float px, float py, int x, int y, int w, int h) {
        float dx = Math.max(Math.max(x - px, 0F), px - (x + w)), dy = Math.max(Math.max(y - py, 0F), py - (y + h));
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private boolean rectNearPad(int x, int y, int w, int h, float m) {
        for (int[] p : pads) if (rectDist(p[0], p[1], x, y, w, h) < m) return true;
        return false;
    }

    private static boolean rectsClose(List<Integer> l, int x, int y, int w, int h, int gap) {
        for (int i = 0; i + 3 < l.size(); i += 4)
            if (x < l.get(i) + l.get(i + 2) + gap && x + w + gap > l.get(i) && y < l.get(i + 1) + l.get(i + 3) + gap && y + h + gap > l.get(i + 1)) return true;
        return false;
    }

    /** The scenery of a map: lily pads, stones, logs, flowers, leaves and cattails; kind, x, y, size, variant. */
    private int[][] buildDecor(java.util.Random r) {
        List<int[]> d = new ArrayList<>();
        int n = 8 + r.nextInt(5);
        for (int t = 0; t < 200 && d.size() < n; t++) {
            int kind = r.nextInt(7), rad = 9 + r.nextInt(8);
            int x = 10 + r.nextInt(W - 20), y = 14 + r.nextInt(H - 26);
            if (kind <= 1) y = 22 + r.nextInt(30);                                       // decorative pads stay at the top, away from the real ones
            if (kind == 6) { x = r.nextBoolean() ? 6 + r.nextInt(14) : W - 20 + r.nextInt(14); y = 46 + r.nextInt(80); }
            int clear = kind <= 3 ? rad + 22 : 22;
            boolean bad = false;
            for (int[] p : pads) { int dx = p[0] - x, dy = p[1] - y; if (dx * dx + dy * dy < clear * clear) { bad = true; break; } }
            for (int[] o : d) { int dx = o[1] - x, dy = o[2] - y; if (dx * dx + dy * dy < 16 * 16) { bad = true; break; } }
            if (bad) continue;
            int variant = kind == 5 ? (r.nextBoolean() ? 1 : -1) : r.nextInt(3);
            d.add(new int[]{kind, x, y, kind == 5 ? variant : rad, kind == 5 ? 0 : variant});
        }
        return d.toArray(new int[0][]);
    }

    private static void addRect(List<Integer> l, int x, int y, int w, int h) { l.add(x); l.add(y); l.add(w); l.add(h); }

    private Bug addStill(int kind, int cell, int ox, int oy) {
        Bug b = new Bug(kind);
        b.x = pads[cell][0] + ox; b.y = pads[cell][1] + oy;
        b.still = true; b.life = Integer.MAX_VALUE;
        bugs.add(b);
        return b;
    }

    /** Wasp guards, flies to catch, treasure in the dead ends and bonus bubbles; always the same for a level. */
    private void placeMazeBugs() {
        java.util.Random r = new java.util.Random(31L * level + 5);
        int n = mCols * mRows, p = part();
        boolean[] used = new boolean[n];
        used[startPad] = used[exitPad] = true;
        for (int c : guardCells) { used[c] = true; addStill(WASP, c, 0, -6).pad = c; }
        for (int c = 0; c < n; c++) {                                          // a dead end: the reward for exploring
            int k = 0;
            for (int d = 0; d < 4; d++) if (step(c, d) >= 0) k++;
            if (k == 1 && !used[c] && r.nextInt(10) < 6) { used[c] = true; addStill(r.nextBoolean() ? GOLD : FIREFLY, c, 0, -7); }
        }
        int[] bubbles = {HOURGLASS, SHIELD, HEART, HOURGLASS, SHIELD};
        for (int i = 0; i < 2 + p; i++) {
            for (int t = 0; t < 200; t++) {
                int c = r.nextInt(n);
                if (used[c]) continue;
                used[c] = true; addStill(bubbles[i % bubbles.length], c, 0, -8);
                break;
            }
        }
        for (int i = 0, flies = n / 3; i < flies; i++) {
            for (int t = 0; t < 200; t++) {
                int c = r.nextInt(n);
                if (used[c]) continue;
                used[c] = true;
                int k = r.nextInt(100);
                int kind = k < 40 ? FLY : k < 65 ? BLUEBOTTLE : k < 80 ? BUTTERFLY : k < 90 ? DRAGONFLY : k < 95 ? BEETLE : BUMBLE;
                Bug b = addStill(kind, c, r.nextInt(17) - 8, -(4 + r.nextInt(8)));
                if (kind == BEETLE) b.hp = b.maxHp = 1;
                break;
            }
        }
    }

    private boolean padGuarded(int pad) {
        for (Bug b : bugs) if (!b.dead && b.pad == pad) return true;
        return false;
    }

    /** A random pad close to the frog: the ones that are about to sink. */
    private int nearPad() {
        for (int t = 0; t < 14; t++) {
            int i = rnd.nextInt(pads.length), dx = pads[i][0] - frogX, dy = pads[i][1] - frogY;
            if (i != exitPad && dx * dx + dy * dy < 110 * 110) return i;
        }
        return frogPad;
    }

    private int wmx() { return mx + Math.round(camX); }

    private int wmy() { return my + Math.round(camY); }

    private boolean onScreen(float x, float y, float m) {
        return x - camX > -m && x - camX < W + m && y - camY > -m && y - camY < H + m;
    }

    /** The camera follows the frog over the big map of a final level. */
    private void updateCam(boolean snap) {
        if (!isFinal()) { camX = camY = 0F; return; }
        float tx = Math.max(0F, Math.min(worldW - W, frogX - W / 2F)), ty = Math.max(0F, Math.min(worldH - H, frogY - H / 2F + 6F));
        if (snap) { camX = tx; camY = ty; }
        else { camX += (tx - camX) * 0.1F; camY += (ty - camY) * 0.1F; }
    }

    private boolean inReed(float x, float y) {
        for (int i = 0; i + 3 < reeds.length; i += 4)
            if (x >= reeds[i] - 1 && x < reeds[i] + reeds[i + 2] + 1 && y >= reeds[i + 1] - 1 && y < reeds[i + 1] + reeds[i + 3] + 1) return true;
        return false;
    }

    private void tickMaze() {
        if (slowT > 0) slowT--;
        if (dizzyT > 0) dizzyT--;
        tickHop();
        tickPads();
        if (longT > 0) longT--;
        if (doubleT > 0) doubleT--;
        if (netT > 0) netT--;
        if (comboT > 0 && --comboT == 0) combo = 0;
        for (Bug b : bugs) if (b.caught == 0) moveBug(b);
        tickTongue();
        bugs.removeIf(b -> b.dead);
        updateCam(false);
        for (int c = 0; c < pads.length; c++)                                   // what has been on the screen shows on the little map
            if (!seen[c] && Math.abs(pads[c][0] - camX - W / 2F) < W / 2F + 10 && Math.abs(pads[c][1] - camY - H / 2F) < H / 2F + 10) seen[c] = true;
        if (state == S_PLAY && hopT == 0 && frogPad == exitPad) { mazeClear(); return; }
        if (slowT <= 0 || time % 2 == 0) timeLeft--;
        if (timeLeft <= 0) timeUp();
    }

    private void mazeClear() {
        int bonus = 500 + timeLeft / 90 * 10;
        scoreBase += Math.max(0, levelPts) + bonus;
        score = scoreBase;
        state = S_CLEAR; stateT = 260;
        tState = 0; tCatch = null; tHitBoss = false;
        bannerMsg = level + 1 >= LEVELS ? T("won") : T("partclear");
        pts(frogX, frogY - 30, "+" + bonus, 0xFFFFD866);
        puff(frogX, frogY - 6, 0xFFFFE066, 16);
        sound(SoundEvents.PLAYER_LEVELUP, 1.1F, 0.8F);
    }

    private float range() { return RANGE * (longT > 0 ? 1.4F : 1F) * (has(M_SHORT) ? 0.78F : 1F); }

    private boolean has(int m) { return (mods & m) != 0; }

    private static boolean isBonus(int kind) { return kind >= HOURGLASS && kind <= NET; }

    private int comboMax() { return has(M_COMBO) ? 8 : 5; }

    private int comboTime() { return has(M_COMBO) ? 110 : COMBO_TIME; }

    private int normalCount() {
        int n = 0;
        for (Bug b : bugs) if (!b.dead && !isBonus(b.kind)) n++;
        return n;
    }

    private static String T(String key, Object... args) { return Component.translatable("cutemod.frog." + key, args).getString(); }

    private String buildModLine() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 9; i++) if ((mods >> i & 1) != 0) sb.append(sb.length() > 0 ? " + " : "").append(T("mod." + (i + 1)));
        return sb.toString();
    }

    // ------------------------------------------------------------------ insects

    private void spawn(boolean inside) {
        float r = rnd.nextFloat();
        int p = part();
        float wasp = Math.min(0.42F, (0.08F + 0.012F * level) * (has(M_WASPS) ? 2F : has(M_SWARM) ? 0.4F : 1F)), c = wasp;
        int kind;
        if (r < c) kind = (p >= 2 || has(M_WASPS) && level >= 5) && rnd.nextFloat() < 0.4F ? HORNET : WASP;
        else if (r < (c += 0.04F)) kind = FIREFLY;
        else if (r < (c += has(M_GOLD) ? 0.14F : 0.012F)) kind = GOLD;
        else if (r < (c += p == 0 ? (level >= 2 ? 0.05F : 0F) : 0.06F)) kind = BUMBLE;
        else if (level >= 4 && r < (c += Math.min(0.10F, 0.03F + 0.003F * level))) kind = BEETLE;
        else if (p == 3 && r < (c += 0.10F)) kind = TOXIC;
        else if (p == 4 && r < (c += 0.03F)) kind = STAR;
        else if (has(M_BUTTER) && r < (c += 0.40F)) kind = BUTTERFLY;
        else if (level >= 1 && r < (c += 0.08F)) kind = DRAGONFLY;
        else if (r < (c += 0.12F)) kind = BUTTERFLY;
        else if (r < (c += 0.25F)) kind = BLUEBOTTLE;
        else kind = FLY;
        if (has(M_SWARM) && (kind == BUMBLE || kind == BEETLE || kind == DRAGONFLY || kind == BUTTERFLY) && rnd.nextInt(5) < 3) kind = rnd.nextInt(3) == 0 ? BLUEBOTTLE : FLY;
        if (inside && kind == STAR) kind = FLY;
        Bug b = new Bug(kind);
        if (kind == BEETLE) { b.hp = b.maxHp = 1; }                     // an armoured beetle: the first hit cracks the shell
        if (inside) {
            b.x = 10 + rnd.nextInt(W - 20);
            b.y = 14 + rnd.nextInt(H - 40);
            b.a = rnd.nextFloat() * 6.2832F;
        } else {
            switch (rnd.nextInt(3)) {
                case 0 -> { b.x = -8; b.y = 10 + rnd.nextInt(H - 40); }
                case 1 -> { b.x = W + 8; b.y = 10 + rnd.nextInt(H - 40); }
                default -> { b.x = 10 + rnd.nextInt(W - 20); b.y = -8; }
            }
            b.a = (float) Math.atan2(30 + rnd.nextInt(60) - b.y, 20 + rnd.nextInt(W - 40) - b.x);
        }
        b.life = 480 + rnd.nextInt(420);
        if (kind == GOLD) b.life = 330 + rnd.nextInt(120);              // a golden fly does not stay long
        if (kind == STAR) {                                           // a falling star: straight and fast
            b.x = 10 + rnd.nextInt(W - 20); b.y = -8;
            b.a = (rnd.nextBoolean() ? 1F : 2.1F) + rnd.nextFloat() * 0.3F;
            b.straight = true; b.spd = 1.5F; b.life = 1;
        }
        bugs.add(b);
    }

    /** A floating bonus bubble: hourglass (time), heart (life), shield, ice (freezes everything) or a wide tongue. */
    private void spawnBonus() {
        int[] pool = {HOURGLASS, HOURGLASS, SHIELD, SHIELD, ICE, NET, NET, HEART};
        int kind = pool[rnd.nextInt(pool.length)];
        if (kind == HEART && lives >= MAX_LIVES) kind = HOURGLASS;
        if (kind == SHIELD && shield >= 2) kind = NET;
        Bug b = new Bug(kind);
        b.x = 24 + rnd.nextInt(W - 48);
        b.y = 24 + rnd.nextInt(H - 76);
        b.a = rnd.nextFloat() * 6.2832F;
        b.life = 620;
        bugs.add(b);
        puff(b.x, b.y, BONUS_COL[kind - HOURGLASS], 8);
        sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.7F, 0.5F);
    }

    private void applyBonus(Bug b, float px, float py) {
        int col = BONUS_COL[b.kind - HOURGLASS];
        puff(px, py + 6, col, 12);
        switch (b.kind) {
            case HOURGLASS -> {
                timeLeft += 1200;
                totalTime = Math.max(totalTime, timeLeft);
                pts(px, py - 10, T("b.time"), col);
                sound(SoundEvents.PLAYER_LEVELUP, 1.6F, 0.7F);
            }
            case HEART -> {
                lives = Math.min(MAX_LIVES, lives + 1);
                pts(px, py - 10, T("b.heart"), col);
                sound(SoundEvents.PLAYER_LEVELUP, 1.2F, 0.8F);
            }
            case SHIELD -> {
                shield = Math.min(2, shield + 1);
                pts(px, py - 10, T("b.shield"), col);
                sound(SoundEvents.SHIELD_BLOCK, 1.3F, 0.8F);
            }
            case ICE -> {
                for (Bug o : bugs) if (!o.dead && o.kind != BOSS && !o.straight && o.caught == 0 && !isBonus(o.kind)) o.frozen = 300;
                flash = 10;
                pts(px, py - 10, T("b.ice"), col);
                sound(SoundEvents.GLASS_BREAK, 1.4F, 0.7F);
            }
            default -> {
                netT = 900;
                pts(px, py - 10, T("b.net"), col);
                sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.9F, 1F);
            }
        }
    }

    /** A line of wasps that flies straight across the screen. */
    private void spawnSwarm() {
        boolean left = rnd.nextBoolean();
        int y0 = 18 + rnd.nextInt(56), n = 3 + (part() >= 3 ? 1 : 0);
        for (int i = 0; i < n; i++) {
            Bug b = new Bug(part() >= 2 && i == 0 ? HORNET : WASP);
            b.x = left ? -8 - i * 13 : W + 8 + i * 13;
            b.y = y0 + (i % 2) * 7;
            b.a = left ? 0F : 3.1416F;
            b.straight = true; b.spd = 0.85F; b.life = 1;
            bugs.add(b);
        }
        pts(left ? 14 : W - 14, y0 - 6, "!", 0xFFFF5A5A);
        sound(SoundEvents.BEE_STING, 0.6F, 0.6F);
    }

    private void spawnBoss() {
        Bug b = new Bug(BOSS);
        b.x = W / 2F; b.y = -10; b.a = 1.5708F;
        b.maxHp = b.hp = 4 + 2 * part();
        b.life = Integer.MAX_VALUE;
        bugs.add(b);
        bossSpawned = true;
        bannerMsg = Component.translatable("cutemod.frog.boss").getString();
        bannerT = 140;
        sound(SoundEvents.BEE_STING, 0.5F, 1F);
    }

    private static float wrap(float a) {
        while (a > Math.PI) a -= 6.2832F;
        while (a < -Math.PI) a += 6.2832F;
        return a;
    }

    private void steer(Bug b, float tx, float ty, float k) {
        float want = (float) Math.atan2(ty - b.y, tx - b.x);
        b.a += wrap(want - b.a) * k;
    }

    private void moveBug(Bug b) {
        b.age++;
        if (b.still) return;
        if (b.frozen > 0) { b.frozen--; return; }
        if (b.straight) {
            float sl = slowT > 0 ? 0.4F : 1F, v = (b.spd > 0 ? b.spd : SPEED[b.kind]) * sl;
            b.x += (float) Math.cos(b.a) * v;
            b.y += (float) Math.sin(b.a) * v;
            if (b.x < -40 || b.x > W + 40 || b.y < -30 || b.y > H + 30) b.dead = true;
            return;
        }
        float slow = slowT > 0 ? 0.4F : 1F;
        float sp = SPEED[b.kind] * (1F + (b.kind == BOSS ? 0.015F : 0.03F) * level) * slow * (has(M_FAST) && !isBonus(b.kind) ? 1.35F : 1F);
        if (has(M_WIND) && b.kind != BOSS) b.x += windX * slow;
        if (b.hit > 0) b.hit--;
        if (b.age % (b.kind == DRAGONFLY || b.kind == GOLD ? 70 : 45) == 0) b.turn = (rnd.nextFloat() - 0.5F) * (b.kind == WASP || b.kind == HORNET ? 0.1F : b.kind == BUMBLE ? 0.06F : 0.16F);
        if ((b.kind == DRAGONFLY || b.kind == GOLD) && b.age % 70 == 0) { b.boost = 1.8F; b.a += (rnd.nextFloat() - 0.5F) * 2F; }
        if (b.boost > 0) { sp *= 1F + b.boost; b.boost = Math.max(0F, b.boost - 0.03F); }
        b.a += b.turn;
        if (b.kind == BUTTERFLY) b.a += (float) Math.sin(b.age * 0.14F) * 0.05F;
        if (b.kind == BOSS) {
            if (b.age < 60 || b.y > 78 || b.y < 20 || b.x < 34 || b.x > W - 34) steer(b, W / 2F + (float) Math.sin(b.age * 0.02F) * 50F, 46, 0.05F);
        } else if (b.age > b.life) steer(b, b.x < W / 2F ? -40 : W + 40, b.y < H / 2F ? -40 : H + 40, 0.02F);
        else if (b.x < 6 || b.x > W - 6 || b.y < 8 || b.y > H - 20) steer(b, W / 2F, H / 2F - 10, 0.06F);
        b.x += (float) Math.cos(b.a) * sp;
        b.y += (float) Math.sin(b.a) * sp;
        if (b.kind != BOSS && b.age > b.life && (b.x < -12 || b.x > W + 12 || b.y < -12 || b.y > H + 12)) b.dead = true;
        if (b.kind != BOSS && b.age > b.life + 900) b.dead = true;
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        if (button == 1) {                                          // right click: hop to the pad under the cursor
            int best = -1;
            float bd = 24F * 24F;
            int wx = x + Math.round(camX), wy = y + Math.round(camY);
            for (int i = 0; i < pads.length; i++) {
                float dx = pads[i][0] - wx, dy = pads[i][1] + 3 - wy, d = dx * dx + dy * dy * 2F;
                if (d < bd) { bd = d; best = i; }
            }
            if (best >= 0) hopTo(best, 18);
            return true;
        }
        for (int i = 0; i < 4; i++) {
            if (in(x, y, JAR_X + i * JAR_STEP, JAR_Y, JAR_W, JAR_H)) { useJar(i); return true; }
        }
        shoot();
        return true;
    }

    @Override
    public boolean key(int keyCode) {
        if (over) return false;
        if (keyCode >= 49 && keyCode <= 52) { useJar(keyCode - 49); return true; }
        if (keyCode == KEY_SPACE) { shoot(); return true; }
        if (keyCode == KEY_LEFT) { hopDir(-1, 0); return true; }
        if (keyCode == KEY_RIGHT) { hopDir(1, 0); return true; }
        if (keyCode == KEY_UP) { hopDir(0, -1); return true; }
        if (keyCode == KEY_DOWN) { hopDir(0, 1); return true; }
        return false;
    }

    private boolean padUnder(int i) { return padT[i] > WARN && padT[i] <= WARN + UNDER; }

    private boolean padSolid(int i) { return padT[i] <= WARN; }

    private void hopDir(int dx, int dy) {
        if (isFinal()) {                                                       // in the maze only through a passage
            int t = step(frogPad, dx > 0 ? 0 : dx < 0 ? 1 : dy > 0 ? 2 : 3);
            if (t >= 0) hopTo(t, 18);
            return;
        }
        int best = -1;
        float bd = 1e9F;
        for (int i = 0; i < pads.length; i++) {
            if (i == frogPad) continue;
            float ex = pads[i][0] - frogX, ey = pads[i][1] - frogY, d = (float) Math.sqrt(ex * ex + ey * ey);
            if (ex * dx + ey * dy < d * 0.3F) continue;
            if (d < bd) { bd = d; best = i; }
        }
        if (best >= 0) hopTo(best, 18);
    }

    private void hopTo(int pad, int ticks) {
        if (state != S_PLAY || tState != 0 || hopT > 0 || pad == frogPad || !padSolid(pad) || !connected(frogPad, pad)) return;
        if (padGuarded(pad)) { pts(frogX, frogY - 22, T("guard"), 0xFFFF9A4A); return; }
        prevPad = frogPad;
        hopFx = frogX; hopFy = frogY; hopT = hopMax = ticks; frogPad = pad;
        sound(SoundEvents.SLIME_SQUISH_SMALL, 1.3F, 0.7F);
    }

    private void tickHop() {
        if (hopT <= 0) return;
        hopT--;
        float t = 1F - hopT / (float) hopMax;
        frogX = Math.round(hopFx + (pads[frogPad][0] - hopFx) * t);
        frogY = Math.round(hopFy + (pads[frogPad][1] - hopFy) * t - (float) Math.sin(t * Math.PI) * 16F);
        if (hopT == 0) { frogX = pads[frogPad][0]; frogY = pads[frogPad][1]; }
    }

    /** The pad under the frog went under: it falls in, loses points and jumps to the nearest pad that holds. */
    private void fall() {
        if (shield > 0) { shield--; pts(frogX, frogY - 16, T("b.block"), BONUS_COL[SHIELD - HOURGLASS]); }
        else {
            levelPts -= 300;
            combo = 0; comboT = 0; hurtT = 60;
            pts(frogX, frogY - 16, "-300", 0xFFFF5A5A);
        }
        puff(frogX, frogY + 4, 0xFF8AD0FF, 10);
        sound(SoundEvents.FROG_HURT, 0.8F, 1F);
        sound(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 0.8F, 1F);
        if (tCatch != null) tCatch.caught = 0;
        tCatch = null; tState = 0; tLen = 0; tHitBoss = false;
        int best = -1;
        float bd = 1e9F;
        for (int i = 0; i < pads.length; i++) {
            if (i == frogPad || padT[i] != 0 || padGuarded(i) || !connected(frogPad, i)) continue;
            float ex = pads[i][0] - frogX, ey = pads[i][1] - frogY, d = ex * ex + ey * ey;
            if (d < bd) { bd = d; best = i; }
        }
        if (best < 0 && isFinal()) {                                           // nothing next to it holds: the nearest pad that does
            for (int i = 0; i < pads.length; i++) {
                if (i == frogPad || padT[i] != 0 || padGuarded(i)) continue;
                float ex = pads[i][0] - frogX, ey = pads[i][1] - frogY, d = ex * ex + ey * ey;
                if (d < bd) { bd = d; best = i; }
            }
        }
        if (best < 0) best = frogPad == 0 ? 1 : 0;
        hopFx = frogX; hopFy = frogY; hopT = hopMax = 14; frogPad = best;
        sync();
    }

    private void tickPads() {
        for (int i = 0; i < pads.length; i++) if (padT[i] > 0 && ++padT[i] > WARN + UNDER + RISE) padT[i] = 0;
        if (padUnder(frogPad) && hopT == 0) fall();
        if (part() < 1 && !has(M_SINK)) return;
        if (--sinkCool > 0) return;
        sinkCool = (has(M_SINK) ? Math.max(120, 270 - 30 * part()) : Math.max(150, 380 - 45 * part())) + rnd.nextInt(90);
        int sunk = 0;
        for (int t : padT) if (t > 0) sunk++;
        if (sunk >= Math.min(part() >= 3 || has(M_SINK) ? 3 : 2, pads.length - 2)) return;
        int pick = padT[frogPad] == 0 && rnd.nextFloat() < 0.55F ? frogPad : isFinal() ? nearPad() : rnd.nextInt(pads.length);
        if (padT[pick] != 0 || pick == exitPad) return;
        padT[pick] = 1;
        if (pick == frogPad) pts(frogX, frogY - 24, Component.translatable("cutemod.frog.jump").getString(), 0xFFFFE27A);
    }

    private void shoot() {
        if (state != S_PLAY || tState != 0 || hopT > 0) return;
        tAng = (float) Math.atan2(wmy() - frogY, wmx() - frogX);
        if (dizzyT > 0) tAng += 3.1416F;                              // a dizzy frog shoots the wrong way
        float ox = frogX + (float) Math.cos(tAng) * 7F, oy = frogY - 1 + (float) Math.sin(tAng) * 7F;
        float d = (float) Math.sqrt((wmx() - ox) * (wmx() - ox) + (wmy() - oy) * (wmy() - oy));
        tGoal = Math.max(12F, Math.min(range(), d + 3F));
        tLen = 0; tState = 1; tCatch = null;
        sound(SoundEvents.FROG_TONGUE, 1F + rnd.nextFloat() * 0.2F, 0.8F);
    }

    private void useJar(int i) {
        if (state != S_PLAY || jars[i] <= 0) return;
        jars[i]--;
        switch (i) {
            case J_SLOW -> { slowT = 480; sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 1F); }
            case J_LONG -> { longT = 600; sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.1F, 1F); }
            case J_DOUBLE -> { doubleT = 600; sound(SoundEvents.PLAYER_LEVELUP, 1.4F, 0.6F); }
            default -> thunder();
        }
    }

    private void thunder() {
        flash = 16;
        sound(SoundEvents.LIGHTNING_BOLT_THUNDER, 1.4F, 0.5F);
        int mult = doubleT > 0 ? 2 : 1;
        for (Bug b : bugs) {
            if (b.dead || b.caught > 0) continue;
            float dx = b.x - frogX, dy = b.y - frogY;
            if (dx * dx + dy * dy > range() * range()) continue;
            if (isBonus(b.kind)) continue;
            if (b.kind == BOSS) { b.hit = 14; b.hp = Math.max(1, b.hp - 1); puff(b.x, b.y, 0xFFFFF0A0, 6); continue; }
            b.dead = true;
            puff(b.x, b.y, 0xFFFFF0A0, 6);
            if (VALUE[b.kind] < 0) continue;
            int v = VALUE[b.kind] * mult;
            levelPts += v;
            pts(b.x, b.y - 4, "+" + v, 0xFFFFFFFF);
            if (b.kind == FIREFLY || b.kind == BUMBLE || b.kind == STAR || b.kind == GOLD) gainJar(b.x, b.y);
        }
        sync();
        checkGoal();
    }

    private void hitBoss(Bug b) {
        b.hp--; b.hit = 14;
        int v = 300 * (doubleT > 0 ? 2 : 1);
        levelPts += v;
        pts(b.x, b.y - 10, "+" + v, 0xFFFFB84A);
        puff(b.x, b.y, 0xFFFFE27A, 8);
        gainJar(b.x, b.y);
        sound(SoundEvents.FROG_HURT, 0.6F, 1F);
        if (b.hp <= 0) {
            b.dead = true; bossDead = true;
            levelPts += 1000;
            pts(b.x, b.y - 18, "+1000", 0xFFFFE27A);
            for (int i = 0; i < 4; i++) puff(b.x, b.y, BOSS_COL[part()], 8);
            flash = 20;
            sound(SoundEvents.PLAYER_LEVELUP, 0.7F, 1F);
            sound(SoundEvents.LIGHTNING_BOLT_THUNDER, 1F, 0.6F);
        }
        sync();
        checkGoal();
    }

    private void gainJar(float x, float y) {
        int t = rnd.nextInt(4);
        jars[t] = Math.min(3, jars[t] + 1);
        puff(x, y, JAR_COL[t], 8);
        sound(SoundEvents.NOTE_BLOCK_CHIME, 1.6F, 0.7F);
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        time++;
        if (bannerT > 0) bannerT--;
        if (hurtT > 0) hurtT--;
        if (gulpT > 0) gulpT--;
        if (flash > 0) flash--;
        tickFx();
        if (state == S_CLEAR) {
            if (--stateT <= 0) {
                if (level + 1 >= LEVELS) { won = true; over = true; }
                else {
                    if (isFinal()) lives = Math.min(MAX_LIVES, lives + 1);     // a new part gives a heart back
                    startLevel(level + 1);
                }
            }
            return;
        }
        if (state == S_FAIL) {
            if (--stateT <= 0) {
                if (lives <= 0) { won = false; over = true; }
                else startLevel(level);
            }
            return;
        }
        if (isFinal()) { tickMaze(); return; }
        if (slowT > 0) slowT--;
        if (dizzyT > 0) dizzyT--;
        tickHop();
        tickPads();
        if ((part() >= 1 || has(M_WASPS)) && --swarmCool <= 0) {
            spawnSwarm();
            swarmCool = Math.round(Math.max(380, 900 - 90 * part()) * (has(M_WASPS) ? 0.6F : 1F)) + rnd.nextInt(300);
        }
        if (has(M_WIND)) {                                                    // the wind changes direction now and then
            if (time % 360 == 0) windTo = (rnd.nextFloat() - 0.5F) * 0.75F;
            windX += (windTo - windX) * 0.01F;
            windPos += windX * 3F;
        }
        if (netT > 0) netT--;
        if (--bonusCool <= 0) {
            int on = 0;
            for (Bug b : bugs) if (!b.dead && isBonus(b.kind)) on++;
            if (on < 2) spawnBonus();
            bonusCool = 600 + rnd.nextInt(500);
        }
        if (part() == 2 || part() == 4) {                                    // frost: now and then a bug freezes in the air
            if (time % (part() == 2 ? 150 : 260) == 0 && !bugs.isEmpty()) {
                Bug f = bugs.get(rnd.nextInt(bugs.size()));
                if (f.kind != BOSS && !isBonus(f.kind) && f.caught == 0 && !f.straight && f.frozen == 0) f.frozen = 220;
            }
        }
        if (longT > 0) longT--;
        if (doubleT > 0) doubleT--;
        if (comboT > 0 && --comboT == 0) combo = 0;
        for (Bug b : bugs) if (b.caught == 0) moveBug(b);
        tickTongue();
        bugs.removeIf(b -> b.dead);
        if (isFinal() && !bossSpawned && levelPts >= goal() / 2) spawnBoss();
        if (normalCount() < target() && rnd.nextInt(Math.max(14, 26 - level / 2)) == 0) spawn(false);
        if (slowT <= 0 || time % 2 == 0) timeLeft--;                       // slowing the time slows the time bar too
        if (timeLeft <= 0) timeUp();
    }

    private void tickTongue() {
        if (tState == 0) return;
        float ox = frogX + (float) Math.cos(tAng) * 7F, oy = frogY - 1 + (float) Math.sin(tAng) * 7F;
        if (tState == 1) {
            float prev = tLen;
            boolean reedHit = false;
            tLen = Math.min(tGoal, tLen + OUT);
            for (float l = prev; l <= tLen + 0.01F && tCatch == null && !tHitBoss; l += 2F) {
                float tx = ox + (float) Math.cos(tAng) * l, ty = oy + (float) Math.sin(tAng) * l;
                for (Bug b : bugs) {
                    if (b.dead || b.caught > 0) continue;
                    float dx = b.x - tx, dy = b.y - ty, r = RAD[b.kind] + 2.5F + (netT > 0 ? 3F : 0F);
                    if (dx * dx + dy * dy <= r * r) {
                        tLen = l;
                        if (b.kind == BOSS) { hitBoss(b); tHitBoss = true; break; }
                        if (b.kind == BEETLE && b.hp > 0) {                  // the shell cracks: the tongue comes back empty (no miss)
                            b.hp--; b.hit = 14;
                            levelPts += 50;
                            pts(b.x, b.y - 8, "+50", 0xFFFFD866);
                            puff(b.x, b.y, 0xFF9AE08A, 6);
                            sound(SoundEvents.GLASS_BREAK, 1.8F, 0.5F);
                            sync();
                            tHitBoss = true;
                            break;
                        }
                        tCatch = b; b.caught = 1;
                        break;
                    }
                }
                if (tCatch == null && !tHitBoss && !reedHit && reeds.length > 0 && inReed(tx, ty)) { tLen = l; reedHit = true; break; }
            }
            if (reedHit) {
                tState = 2;
                puff(ox + (float) Math.cos(tAng) * tLen, oy + (float) Math.sin(tAng) * tLen, 0xFF9AC85A, 5);
                sound(SoundEvents.SLIME_SQUISH_SMALL, 0.6F, 0.5F);
            } else if (tHitBoss) tState = 2;
            else if (tCatch != null) {
                sound(VALUE[tCatch.kind] < 0 ? SoundEvents.BEE_STING : SoundEvents.SLIME_SQUISH_SMALL, 1.2F, 0.8F);
                tState = 2;
            } else if (tLen >= tGoal) tState = 2;
        } else {
            tLen -= IN * (tCatch != null && tCatch.kind == BUMBLE ? 0.5F : tCatch != null && tCatch.kind == BEETLE ? 0.7F : 1F);     // a bumblebee is heavy
            if (tCatch != null) {
                tCatch.x = ox + (float) Math.cos(tAng) * tLen;
                tCatch.y = oy + (float) Math.sin(tAng) * tLen;
            }
            if (tLen <= 4F) deliver();
        }
    }

    private void deliver() {
        tState = 0; tLen = 0;
        Bug b = tCatch;
        tCatch = null;
        if (b == null && tHitBoss) { tHitBoss = false; return; }          // a hit on the boss (or a cracked shell) is not a miss
        if (b == null) { combo = 0; comboT = 0; return; }       // a miss breaks the combo
        b.dead = true;
        float px = frogX, py = frogY - 16;
        if (VALUE[b.kind] < 0) {
            if (shield > 0) {                                           // the shield takes the sting
                shield--;
                pts(px, py, T("b.block"), BONUS_COL[SHIELD - HOURGLASS]);
                puff(px, py + 8, BONUS_COL[SHIELD - HOURGLASS], 10);
                sound(SoundEvents.SHIELD_BLOCK, 1F, 1F);
            } else {
                levelPts += VALUE[b.kind];
                combo = 0; comboT = 0; hurtT = 40;
                if (b.kind == TOXIC) dizzyT = 260;
                pts(px, py, "" + VALUE[b.kind], 0xFFFF5A5A);
                sound(SoundEvents.FROG_HURT, 1F, 0.9F);
            }
        } else {
            combo++; comboT = comboTime(); gulpT = 12;
            int v = VALUE[b.kind] * Math.min(comboMax(), 1 + combo / 3) * (doubleT > 0 ? 2 : 1);
            if (has(M_SHORT)) v = v * 3 / 2;                          // a short tongue pays better
            if (b.frozen > 0) v = v * 3 / 2;                          // a frozen bug is worth half as much again
            levelPts += v;
            pts(px, py, "+" + v, b.kind == FIREFLY ? 0xFFE8FF7A : b.kind == GOLD ? 0xFFFFE066 : b.frozen > 0 ? 0xFFBEEBFF : 0xFFFFFFFF);
            puff(px, py + 6, 0xFFFFE27A, 3);
            sound(SoundEvents.FROG_EAT, 1F, 0.9F);
            if (isBonus(b.kind)) applyBonus(b, px, py);
            if (b.kind == FIREFLY || b.kind == BUMBLE || b.kind == STAR || b.kind == GOLD) gainJar(px, py);
            if (b.kind == GOLD) { puff(px, py + 6, 0xFFFFE066, 14); gainJar(px, py); }
        }
        sync();
        checkGoal();
    }

    private void sync() { score = Math.max(0, scoreBase + levelPts); }

    private void checkGoal() {
        if (state != S_PLAY || isFinal() || levelPts < goal()) return;
        if (isFinal()) {
            if (!bossSpawned) spawnBoss();
            if (!bossDead) return;
        }
        int bonus = timeLeft / 90 * 10;
        scoreBase += Math.max(0, levelPts) + bonus;
        score = scoreBase;
        state = S_CLEAR; stateT = isFinal() ? 260 : 150;
        tState = 0; tCatch = null; tHitBoss = false;
        bannerMsg = level + 1 >= LEVELS ? Component.translatable("cutemod.frog.won").getString()
                : Component.translatable(isFinal() ? "cutemod.frog.partclear" : "cutemod.frog.clear").getString();
        pts(W / 2F, 52, "+" + bonus, 0xFFFFD866);
        sound(SoundEvents.PLAYER_LEVELUP, 1.1F, 0.8F);
    }

    private void timeUp() {
        lives--;
        score = scoreBase;
        state = S_FAIL; stateT = 120;
        tState = 0; tCatch = null; tHitBoss = false;
        bannerMsg = Component.translatable("cutemod.frog.fail").getString();
        sound(SoundEvents.VILLAGER_NO, 1F, 0.8F);
    }

    // ------------------------------------------------------------------ effects

    private void pts(float x, float y, String s, int col) {
        Fx f = new Fx();
        f.kind = 3; f.x = x; f.y = y; f.vy = -0.4F; f.life = f.max = 55; f.txt = s; f.col = col;
        fx.add(f);
    }

    private void puff(float x, float y, int col, int n) {
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.kind = 1; f.x = x; f.y = y; f.col = col;
            f.vx = (rnd.nextFloat() - 0.5F) * 2.2F; f.vy = (rnd.nextFloat() - 0.5F) * 2.2F;
            f.life = f.max = 16 + rnd.nextInt(10);
            fx.add(f);
        }
    }

    private void tickFx() {
        for (Fx f : fx) {
            f.life--;
            f.x += f.vx; f.y += f.vy;
            if (f.kind == 1) { f.vx *= 0.93F; f.vy *= 0.93F; }
        }
        fx.removeIf(f -> f.life <= 0);
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, bgTop(), bgBot());
        if (isFinal()) atmosphere(g, part());
        g.pose().pushPose();
        g.pose().translate(-Math.round(camX), -Math.round(camY), 0F);
        if (isFinal()) mazeScenery(g); else scenery(g);
        drawReeds(g);
        windFx(g);
        ringOfRange(g);
        for (Bug b : bugs) {
            drawBug(g, b);
            if (b.frozen > 0) {                                                  // a frozen bug sits in a little ice cube
                int x = Math.round(b.x), y = Math.round(b.y), r = Math.round(RAD[b.kind]) + 2;
                g.fill(x - r, y - r, x + r + 1, y + r + 1, Gfx.alpha(0xFFBEEBFF, b.frozen < 40 && b.frozen % 6 < 3 ? 40 : 100));
                Gfx.outline(g, x - r, y - r, 2 * r + 1, 2 * r + 1, 0xCCFFFFFF);
                g.fill(x - r + 1, y - r + 1, x - r + 3, y - r + 2, 0xFFFFFFFF);
            }
        }
        drawFrog(g);
        drawShield(g);
        drawTongue(g);
        for (Fx f : fx) drawFx(g, f);
        g.pose().popPose();
        if (flash > 0) g.fill(0, 0, W, H, Gfx.alpha(0xFFFFFFFF, flash * 9));
        if (slowT > 0) g.fill(0, 0, W, H, Gfx.alpha(0xFF3A7AFF, 22));
        Gfx.vignette(g, W, H, 40);
        drawCursor(g);
        hud(g);
    }

    private void scenery(GuiGraphics g) {
        int pt = part(), lv = level * 100;
        for (int i = 0; i < 70; i++) {                                    // clover specks on the water
            int x = (int) (Gfx.hash(i + lv, 1) * W), y = (int) (Gfx.hash(i + lv, 2) * H), c = Gfx.alpha(SPECK[pt], Gfx.hash(i + lv, 3) > 0.5F ? 100 : 64);
            if (pt == 4 && i % 3 == 0) { g.fill(x, y, x + 1, y + 1, Gfx.alpha(0xFFFFFFFF, 60 + (int) (60 * Math.sin(time * 0.05F + i)))); continue; }
            g.fill(x, y - 1, x + 1, y + 2, c);
            g.fill(x - 1, y, x + 2, y + 1, c);
        }
        for (int i = 0; i < 5; i++) Gfx.ellipse(g, (int) (Gfx.hash(i + lv, 4) * W), (int) (Gfx.hash(i + lv, 5) * H), 16, 5, 0x1A000000);
        drawDecor(g, false);
        atmosphere(g, pt);
        drawDecor(g, true);
        for (int i = 0; i < pads.length; i++) hopPad(g, i, pt);
    }

    /** The scenery of the map: what lies on the water (pads, stones, logs) and, above the haze, what grows out of it. */
    private void drawDecor(GuiGraphics g, boolean above) {
        int pt = part(), bg = bgBot(), hole = Gfx.darker(bg, 0.4F);
        for (int[] d : decor) {
            if ((d[0] >= 4) != above) continue;
            int x = d[1], y = d[2], rad = d[3];
            switch (d[0]) {
                case 0, 1 -> {                                           // pads that bob under the water in the later parts
                    float dm = pt == 0 ? 1F : Math.max(0F, Math.min(1F, 1.4F * (float) Math.cos(time * 0.007F + d[4] * 2.1F + x) + 0.7F));
                    if (dm <= 0.2F) ripple(g, x, y, rad);
                    else if (d[0] == 0) pad(g, x, y, Math.round(rad * dm), d[4] % 2 == 1 ? Gfx.darker(PAD[pt], 0.08F) : PAD[pt], bg);
                    else spotted(g, x, y, Math.round(rad * dm), PAD2[pt], bg, hole);
                }
                case 2 -> {                                              // a stone
                    Gfx.ellipse(g, x, y + 2, rad, Math.max(2, rad * 2 / 3), 0x44000000);
                    Gfx.ellipse(g, x, y, Math.max(2, rad - 1), Math.max(2, rad * 2 / 3 - 1), 0xFF6E767E);
                    Gfx.ellipse(g, x - 1, y - 1, Math.max(1, rad / 2), Math.max(1, rad / 3), 0xFF98A2AA);
                }
                case 3 -> {                                              // a floating log
                    int half = rad + 4;
                    Gfx.rrect(g, x - half, y - 1, half * 2, 7, 3, 0x33000000);
                    Gfx.rrect(g, x - half, y - 4, half * 2, 7, 3, 0xFF6A4A2A);
                    Gfx.rrect(g, x - half + 2, y - 3, half * 2 - 4, 2, 1, 0xFF8A6A42);
                    g.fill(x + half - 3, y - 3, x + half - 1, y + 1, 0xFF3A2A18);
                }
                case 4 -> flower(g, x, y, PETAL[pt], d[4] == 1 ? 0xFFFFD84A : pt == 1 ? 0xFF2A0610 : 0xFFA8C8FF);
                case 5 -> leaves(g, x, y, rad, PAD[pt]);
                default -> {                                             // cattails
                    for (int k = 0; k < 3; k++) {
                        int sx = x + (k - 1) * 4, hgt = 14 + (k % 2) * 6 + d[4] * 2, sway = Math.round((float) Math.sin(time * 0.04F + x + k) * 1.4F);
                        for (int yy = 0; yy < hgt; yy += 2) g.fill(sx + sway * yy / hgt, y - yy, sx + 1 + sway * yy / hgt, y - yy + 2, Gfx.darker(PAD[pt], 0.15F));
                        g.fill(sx + sway - 1, y - hgt - 5, sx + sway + 1, y - hgt, 0xFF6A4228);
                    }
                }
            }
        }
    }

    /** Rings on the water where a pad is under. */
    private void ripple(GuiGraphics g, int cx, int cy, int r) {
        for (int k = 0; k < 2; k++) {
            float ph = ((time + k * 30) % 60) / 60F;
            int rx = Math.round(4 + r * ph), ry = Math.max(1, Math.round((4 + r * ph) * 0.55F));
            int col = Gfx.alpha(0xFFBEE8FF, Math.round(90 * (1F - ph)));
            for (int i = 0; i < 24; i++) {
                double a = i * Math.PI / 12;
                int x = cx + (int) Math.round(Math.cos(a) * rx), y = cy + 3 + (int) Math.round(Math.sin(a) * ry);
                if (onScreen(x, y, 0)) g.fill(x, y, x + 1, y + 1, col);
            }
        }
    }

    private void hopPad(GuiGraphics g, int i, int pt) {
        if (!onScreen(pads[i][0], pads[i][1], 24)) return;
        int cx = pads[i][0], cy = pads[i][1], t = padT[i];
        boolean warn = t > 0 && t <= WARN;
        float sc = 1F;
        if (t > WARN && t <= WARN + UNDER) sc = 0F;
        else if (t > WARN + UNDER) sc = (t - WARN - UNDER) / (float) RISE;
        if (sc < 0.15F) {
            ripple(g, cx, cy, 14);
            if (t > WARN && time % 24 == i) Gfx.disc(g, cx - 6 + rnd.nextInt(12), cy + 2 + rnd.nextInt(5), 1, 0x88DFF4FF);
            return;
        }
        int ox = warn ? (time % 4 < 2 ? -1 : 1) : 0;
        int pr = i < padR.length ? padR[i] : 16, rx = Math.round(pr * sc), ry = Math.round(pr * 0.625F * sc);
        int col = warn && (t / 8) % 2 == 0 ? Gfx.mix(PAD[pt], 0xFFFFFFFF, 0.35F) : PAD[pt];
        if (warn) { ry = Math.round(ry * (1F - 0.15F * t / WARN)); }
        Gfx.ellipse(g, cx + ox, cy + 4, rx + 1, ry + 1, Gfx.darker(PAD[pt], 0.45F));
        Gfx.ellipse(g, cx + ox, cy + 3, rx, ry, Gfx.lighter(col, 0.08F));
        Gfx.ellipse(g, cx + ox, cy + 5, Math.max(1, rx / 2), Math.max(1, ry / 3), 0x22FFFFFF);
        g.fill(cx + ox, cy + 3 - ry, cx + ox + 1, cy + 3, Gfx.darker(PAD[pt], 0.45F));          // the notch
        if (warn && t > WARN - 40 && time % 6 < 3) Gfx.disc(g, cx + ox + rx - 2, cy + 6, 1, 0xAAFFFFFF);   // bubbles: it is about to sink
    }

    /** Things that float through the air of a swamp: embers, snow, toxic bubbles. */
    private void atmosphere(GuiGraphics g, int pt) {
        if (pt == 1) {
            for (int i = 0; i < 14; i++) {
                int x = (int) (Gfx.hash(i, 8) * W) + (int) (Math.sin(time * 0.03F + i) * 4), y = H - (int) ((time * (0.25F + Gfx.hash(i, 9) * 0.3F) + Gfx.hash(i, 10) * H) % H);
                g.fill(x, y, x + 1, y + 1, Gfx.alpha(0xFFFF7A5A, 120));
            }
        } else if (pt == 2) {
            for (int i = 0; i < 24; i++) {
                int x = (int) (Gfx.hash(i, 11) * W) + (int) (Math.sin(time * 0.02F + i) * 5), y = (int) ((time * (0.2F + Gfx.hash(i, 12) * 0.25F) + Gfx.hash(i, 13) * H) % H);
                g.fill(x, y, x + 2, y + 1, Gfx.alpha(0xFFFFFFFF, 150));
            }
        } else if (pt == 3) {
            for (int i = 0; i < 10; i++) {
                int x = (int) (Gfx.hash(i, 14) * W) + (int) (Math.sin(time * 0.03F + i) * 3), y = H - (int) ((time * (0.2F + Gfx.hash(i, 15) * 0.3F) + Gfx.hash(i, 16) * H) % H);
                int r = 1 + (int) (Gfx.hash(i, 17) * 2);
                Gfx.disc(g, x, y, r, Gfx.alpha(0xFF9AFF5A, 60));
            }
        }
    }

    private static void pad(GuiGraphics g, int cx, int cy, int r, int col, int water) {
        Gfx.disc(g, cx, cy, r + 1, Gfx.darker(col, 0.45F));
        Gfx.disc(g, cx, cy, r, col);
        Gfx.disc(g, cx, cy, r - 5, Gfx.lighter(col, 0.18F));
        Gfx.disc(g, cx, cy, r / 4, Gfx.darker(col, 0.2F));
        g.fill(cx, cy - r, cx + 1, cy, Gfx.darker(col, 0.45F));                 // the notch
        g.fill(cx - 1, cy - r, cx + 2, cy - r / 2, water);
    }

    private static void spotted(GuiGraphics g, int cx, int cy, int r, int col, int water, int hole) {
        pad(g, cx, cy, r, col, water);
        int[][] holes = {{-6, -2, 2}, {1, -6, 2}, {5, 0, 3}, {-3, 5, 2}, {2, 4, 2}, {-8, 3, 1}};
        for (int[] h : holes) Gfx.disc(g, cx + h[0], cy + h[1], h[2], hole);
    }

    private static void stump(GuiGraphics g, int cx, int cy, int r, int col) {
        Gfx.disc(g, cx, cy, r + 2, Gfx.darker(col, 0.5F));
        Gfx.disc(g, cx, cy, r, col);
        Gfx.disc(g, cx, cy, r - 3, Gfx.lighter(col, 0.2F));
        Gfx.disc(g, cx, cy, r / 2, col);
        Gfx.disc(g, cx - 2, cy - 2, 2, 0x55FFFFFF);
    }

    private static void flower(GuiGraphics g, int cx, int cy, int petal, int core) {
        for (int i = 0; i < 5; i++) {
            double a = i * 1.2566 + 0.4;
            Gfx.disc(g, cx + (int) Math.round(Math.cos(a) * 4), cy + (int) Math.round(Math.sin(a) * 4), 2, petal);
        }
        Gfx.disc(g, cx, cy, 2, core);
    }

    private static void leaves(GuiGraphics g, int cx, int cy, int dir, int col) {
        for (int i = 0; i < 4; i++) {
            int ex = cx + dir * (4 + i * 4), ey = cy - 12 + i * 3 - (i == 1 ? 4 : 0);
            Gfx.line(g, cx, cy + 6, ex, ey, Gfx.darker(col, 0.2F));
            Gfx.line(g, cx + 1, cy + 6, ex + dir, ey, Gfx.lighter(col, 0.2F));
        }
    }

    private void ringOfRange(GuiGraphics g) {
        float r = range();
        int col = tState == 0 ? 0xAAE0505A : 0x66E0505A;
        for (int i = 0; i < 90; i++) {
            if (i % 2 == 1) continue;
            double a = i * Math.PI * 2 / 90 + time * 0.003;
            int x = frogX + (int) Math.round(Math.cos(a) * r), y = frogY + (int) Math.round(Math.sin(a) * r);
            if (onScreen(x, y, 0)) g.fill(x, y, x + 1, y + 1, col);
        }
        if (longT > 0) Gfx.glow(g, frogX, frogY, 12, 0xFF7ED957, 70);
    }

    private void drawBug(GuiGraphics g, Bug b) {
        int x = Math.round(b.x), y = Math.round(b.y);
        if (!onScreen(x, y, 12)) return;
        boolean flap = (time / 2 + (int) (b.x * 0.3F)) % 2 == 0;
        int wing = 0xB0E8F4FF;
        if (isBonus(b.kind)) { drawBonus(g, b, x, y); return; }
        switch (b.kind) {
            case FLY -> {
                Gfx.ellipse(g, x - 2, y - 2 + (flap ? 0 : 1), 2, 1, wing);
                Gfx.ellipse(g, x + 2, y - 2 + (flap ? 1 : 0), 2, 1, wing);
                Gfx.disc(g, x, y, 2, 0xFF2A2A34);
                g.fill(x - 1, y - 1, x, y, 0xFFE04040);
                g.fill(x + 1, y - 1, x + 2, y, 0xFFE04040);
            }
            case BLUEBOTTLE -> {
                Gfx.ellipse(g, x - 3, y - 2 + (flap ? 0 : 1), 3, 1, wing);
                Gfx.ellipse(g, x + 3, y - 2 + (flap ? 1 : 0), 3, 1, wing);
                Gfx.ball(g, x, y, 3, 0xFF2FB6A4);
                g.fill(x - 1, y - 1, x + 2, y, 0xFFB8FFF0);
                g.fill(x - 2, y - 3, x - 1, y - 2, 0xFFE04040);
                g.fill(x + 1, y - 3, x + 2, y - 2, 0xFFE04040);
            }
            case BUTTERFLY -> {
                int sp = flap ? 5 : 3;
                Gfx.ellipse(g, x - sp / 2 - 1, y - 1, sp, 3, 0xFFFF8FC8);
                Gfx.ellipse(g, x + sp / 2 + 1, y - 1, sp, 3, 0xFFFF8FC8);
                Gfx.ellipse(g, x - sp / 2, y + 2, sp - 1, 2, 0xFFFFC27A);
                Gfx.ellipse(g, x + sp / 2, y + 2, sp - 1, 2, 0xFFFFC27A);
                g.fill(x, y - 3, x + 1, y + 4, 0xFF4A2A44);
            }
            case DRAGONFLY -> {
                int dx = Math.round((float) Math.cos(b.a) * 4), dy = Math.round((float) Math.sin(b.a) * 4);
                Gfx.line(g, x - dx, y - dy, x + dx, y + dy, 0xFF2FD0E8);
                Gfx.disc(g, x + dx, y + dy, 1, 0xFF1A8AA0);
                Gfx.ellipse(g, x, y - 2 + (flap ? 0 : 1), 5, 1, wing);
                Gfx.ellipse(g, x, y + 2 + (flap ? 1 : 0), 5, 1, wing);
            }
            case FIREFLY -> {
                float p = 0.6F + 0.4F * (float) Math.sin(time * 0.15F + b.x);
                Gfx.glow(g, x, y, 9, 0xFFD8FF50, Math.round(120 * p));
                Gfx.disc(g, x, y, 2, 0xFFEFFF8A);
                g.fill(x - 3, y - 2 + (flap ? 0 : 1), x - 1, y - 1 + (flap ? 0 : 1), wing);
                g.fill(x + 1, y - 2 + (flap ? 1 : 0), x + 3, y - 1 + (flap ? 1 : 0), wing);
                g.fill(x - 1, y - 1, x + 1, y + 1, 0xFFFFFFFF);
            }
            case BOSS -> drawBoss(g, b, x, y, flap);
            case HORNET -> {                                                     // a big red-orange wasp
                Gfx.ellipse(g, x - 3, y - 4 + (flap ? 0 : 1), 4, 1, wing);
                Gfx.ellipse(g, x + 3, y - 4 + (flap ? 1 : 0), 4, 1, wing);
                Gfx.ellipse(g, x, y, 5, 4, 0xFFE8552A);
                g.fill(x - 3, y - 3, x - 2, y + 4, 0xFF2A1410);
                g.fill(x, y - 3, x + 1, y + 4, 0xFF2A1410);
                g.fill(x + 2, y - 3, x + 3, y + 4, 0xFF2A1410);
                g.fill(x - 5, y - 1, x - 3, y + 1, 0xFFFFE030);
                g.fill(x + 5, y + 3, x + 8, y + 4, 0xFF2A1410);                    // a long sting
            }
            case BUMBLE -> {                                                     // a fat fuzzy bumblebee
                Gfx.ellipse(g, x - 2, y - 5 + (flap ? 0 : 1), 3, 1, wing);
                Gfx.ellipse(g, x + 3, y - 5 + (flap ? 1 : 0), 3, 1, wing);
                Gfx.ball(g, x, y, 5, 0xFFFFD84A);
                g.fill(x - 4, y - 1, x + 5, y + 1, 0xFF3A2A20);
                g.fill(x - 3, y + 2, x + 4, y + 3, 0xFF3A2A20);
                g.fill(x - 5, y - 3, x - 3, y - 1, 0xFFFFF4C0);
                g.fill(x - 4, y - 2, x - 3, y - 1, 0xFF1A1428);
                g.fill(x - 6, y + 1, x - 5, y + 3, 0xFFFFF4C0);
            }
            case TOXIC -> {                                                      // a fly that glows poison green
                Gfx.glow(g, x, y, 8, 0xFF9AFF5A, 90);
                Gfx.ellipse(g, x - 2, y - 2 + (flap ? 0 : 1), 2, 1, 0xB0C8FFC8);
                Gfx.ellipse(g, x + 2, y - 2 + (flap ? 1 : 0), 2, 1, 0xB0C8FFC8);
                Gfx.disc(g, x, y, 2, 0xFF7A3AB0);
                g.fill(x - 1, y - 1, x, y, 0xFFB8FF5A);
                g.fill(x + 1, y - 1, x + 2, y, 0xFFB8FF5A);
                if (time % 20 < 10) Gfx.disc(g, x + 3, y - 4, 1, 0xAA9AFF5A);
            }
            case STAR -> {                                                       // a falling star with a tail
                for (int k = 4; k >= 1; k--) {
                    int tx = x - Math.round((float) Math.cos(b.a) * k * 3), ty = y - Math.round((float) Math.sin(b.a) * k * 3);
                    Gfx.disc(g, tx, ty, Math.max(1, 3 - k / 2), Gfx.alpha(0xFFFFE27A, 150 - k * 30));
                }
                Gfx.glow(g, x, y, 9, 0xFFFFE27A, 110);
                Gfx.star(g, x, y, 4, 0xFFFFF4A0);
            }
            case BEETLE -> {                                                     // an armoured beetle; once cracked it shows its wings
                boolean armor = b.hp > 0;
                int shell = b.hit > 0 && b.hit % 4 < 2 ? 0xFFFFFFFF : armor ? 0xFF2F8A4A : 0xFF9A7A4A, dk = Gfx.darker(shell, 0.45F);
                g.fill(x - 5, y + 2, x + 6, y + 3, dk);
                g.fill(x - 4, y - 1, x + 5, y, dk);
                if (!armor) {
                    Gfx.ellipse(g, x - 3, y - 4 + (flap ? 0 : 1), 3, 1, wing);
                    Gfx.ellipse(g, x + 3, y - 4 + (flap ? 1 : 0), 3, 1, wing);
                }
                Gfx.ellipse(g, x, y, 4, 3, shell);
                g.fill(x, y - 3, x + 1, y + 3, dk);
                if (armor) g.fill(x - 3, y - 2, x - 1, y - 1, 0xAAFFFFFF);
                else g.fill(x + 1, y - 1, x + 3, y, 0xFFE8C890);
                g.fill(x - 2, y - 5, x + 3, y - 3, 0xFF1A1428);
                g.fill(x - 2, y - 6, x - 1, y - 5, dk);
                g.fill(x + 2, y - 6, x + 3, y - 5, dk);
            }
            case GOLD -> {                                                       // a golden fly: fast, sparkly and worth a lot
                float p = 0.6F + 0.4F * (float) Math.sin(time * 0.2F + b.y);
                Gfx.glow(g, x, y, 11, 0xFFFFE066, Math.round(130 * p));
                Gfx.ellipse(g, x - 3, y - 2 + (flap ? 0 : 1), 3, 1, 0xD0FFF4B0);
                Gfx.ellipse(g, x + 3, y - 2 + (flap ? 1 : 0), 3, 1, 0xD0FFF4B0);
                Gfx.disc(g, x, y, 2, 0xFFFFC21A);
                g.fill(x - 1, y - 1, x, y, 0xFFFFFFFF);
                g.fill(x + 1, y - 1, x + 2, y, 0xFFFFFFFF);
                if (time % 14 < 7) Gfx.star(g, x + 4, y - 4, 2, 0xFFFFFFFF);
            }
            default -> {                                                         // a wasp: yellow and black stripes, angry red eyes
                Gfx.ellipse(g, x - 2, y - 3 + (flap ? 0 : 1), 3, 1, wing);
                Gfx.ellipse(g, x + 2, y - 3 + (flap ? 1 : 0), 3, 1, wing);
                Gfx.ellipse(g, x, y, 4, 3, 0xFFFFD02A);
                g.fill(x - 2, y - 2, x - 1, y + 3, 0xFF2A2420);
                g.fill(x + 1, y - 2, x + 2, y + 3, 0xFF2A2420);
                g.fill(x - 4, y - 1, x - 3, y + 1, 0xFFE03030);
                g.fill(x + 4, y + 2, x + 6, y + 3, 0xFF2A2420);                    // the sting
            }
        }
    }

    private void drawBoss(GuiGraphics g, Bug b, int x, int y, boolean flap) {
        int col = BOSS_COL[part()], dark = Gfx.darker(col, 0.55F);
        if (b.hit > 0 && b.hit % 4 < 2) col = 0xFFFFFFFF;
        Gfx.glow(g, x, y, 16, BOSS_COL[part()], 60);
        Gfx.ellipse(g, x - 8, y - 8 + (flap ? 0 : 2), 8, 3, 0xB0E8F4FF);
        Gfx.ellipse(g, x + 8, y - 8 + (flap ? 2 : 0), 8, 3, 0xB0E8F4FF);
        Gfx.ellipse(g, x, y + 2, 9, 8, col);
        for (int i = -1; i <= 1; i += 2) g.fill(x + i * 3 - 1, y - 4, x + i * 3 + 1, y + 9, dark);
        Gfx.ball(g, x, y - 5, 6, col);
        g.fill(x - 4, y - 7, x - 1, y - 4, 0xFFFFFFFF);
        g.fill(x + 1, y - 7, x + 4, y - 4, 0xFFFFFFFF);
        g.fill(x - 3, y - 6, x - 1, y - 4, 0xFFD02020);
        g.fill(x + 1, y - 6, x + 3, y - 4, 0xFFD02020);
        g.fill(x - 5, y - 9, x + 6, y - 8, dark);                                      // the angry brow
        g.fill(x - 4, y - 14, x - 3, y - 11, 0xFFFFE27A);                              // a little crown
        g.fill(x - 1, y - 15, x, y - 11, 0xFFFFE27A);
        g.fill(x + 2, y - 14, x + 3, y - 11, 0xFFFFE27A);
        g.fill(x - 4, y - 11, x + 3, y - 10, 0xFFFFE27A);
        g.fill(x - 1, y + 10, x + 1, y + 14, dark);                                    // the sting
        int w = 20, hx = x - w / 2, hy = y - 21;
        g.fill(hx - 1, hy - 1, hx + w + 1, hy + 3, 0xAA000000);
        g.fill(hx, hy, hx + Math.round(w * b.hp / (float) b.maxHp), hy + 2, 0xFFFF5A5A);
    }

    private void drawFrog(GuiGraphics g) {
        float ang = (float) Math.atan2(wmy() - frogY, wmx() - frogX);
        boolean hurt = hurtT > 0;
        int body = hurt ? 0xFF8FC24A : 0xFF4FCF3F, dark = Gfx.darker(body, 0.35F);
        int shake = hurt ? (time % 4 < 2 ? -1 : 1) : 0;
        int cx = frogX + shake, cy = frogY;
        Gfx.ellipse(g, cx - 9, cy + 6, 5, 3, dark);                                  // the back legs
        Gfx.ellipse(g, cx + 9, cy + 6, 5, 3, dark);
        Gfx.ellipse(g, cx, cy + 2, 9, 7, body);                                      // the body
        Gfx.ellipse(g, cx, cy + 4, 6, 4, 0xFFE6F7A8);                                // the belly
        Gfx.ellipse(g, cx - 5, cy + 9, 3, 2, body);                                  // the front feet
        Gfx.ellipse(g, cx + 5, cy + 9, 3, 2, body);
        Gfx.ball(g, cx, cy - 3, 8, body);                                            // the head
        int ex = Math.round((float) Math.cos(ang) * 1.4F), ey = Math.round((float) Math.sin(ang) * 1.4F);
        for (int s = -1; s <= 1; s += 2) {                                           // the big eyes follow the cursor
            int ox = cx + s * 5, oy = cy - 9;
            Gfx.ball(g, ox, oy, 3, body);
            Gfx.disc(g, ox, oy, 2, 0xFFFFFFFF);
            if (hurt) { g.fill(ox - 1, oy - 1, ox + 2, oy, 0xFF1A1428); g.fill(ox - 1, oy + 1, ox + 2, oy + 2, 0xFF1A1428); }
            else g.fill(ox + ex, oy + ey, ox + ex + 2, oy + ey + 2, 0xFF1A1428);
        }
        g.fill(cx - 3, cy - 4, cx - 2, cy - 3, dark);                                // the nostrils
        g.fill(cx + 2, cy - 4, cx + 3, cy - 3, dark);
        int my2 = cy - 1;
        if (tState == 0 && gulpT <= 0) {                                             // a smile
            g.fill(cx - 4, my2, cx + 5, my2 + 1, dark);
            g.fill(cx - 5, my2 - 1, cx - 4, my2, dark);
            g.fill(cx + 5, my2 - 1, cx + 6, my2, dark);
        } else if (gulpT > 0) {
            g.fill(cx - 4, my2, cx + 5, my2 + 1, dark);
            g.fill(cx - 3, my2 + 1, cx + 4, my2 + 2, 0xFFFF8FA8);
        } else {
            Gfx.ellipse(g, cx, my2, 3, 2, 0xFF7A1F34);                               // the mouth is open
        }
        g.fill(cx - 6, cy + 1, cx - 4, cy + 3, Gfx.alpha(0xFFFF9FB5, 150));          // the blush
        g.fill(cx + 5, cy + 1, cx + 7, cy + 3, Gfx.alpha(0xFFFF9FB5, 150));
    }

    /** The reed walls of a maze: a thick hedge of stalks with brown cattail heads. */
    private void drawReeds(GuiGraphics g) {
        int pt = part(), base = Gfx.darker(PAD[pt], 0.45F), a = Gfx.darker(PAD[pt], 0.1F), b = Gfx.lighter(PAD[pt], 0.2F);
        int sx0 = Math.round(camX), sy0 = Math.round(camY);
        for (int i = 0; i + 3 < reeds.length; i += 4) {
            int x = reeds[i], y = reeds[i + 1], w = reeds[i + 2], h = reeds[i + 3];
            if (x + w < sx0 - 2 || x > sx0 + W + 2 || y + h < sy0 - 2 || y > sy0 + H + 2) continue;
            g.fill(x + 1, y + h, x + w + 2, y + h + 2, 0x44000000);
            g.fill(x, y, x + w, y + h, base);
            for (int cx = x; cx < x + w; cx += 2) {
                for (int cy = y; cy < y + h; cy += 5) {
                    int hh = Math.min(5, y + h - cy);
                    g.fill(cx, cy, cx + 1, cy + hh, (cx / 2 + cy / 5) % 2 == 0 ? a : b);
                    if (Gfx.hash(cx * 7 + cy, 31) > 0.82F) g.fill(cx, cy, cx + 2, Math.min(cy + 3, y + h), 0xFF7A5230);
                }
            }
            Gfx.outline(g, x, y, w, h, Gfx.alpha(0xFF000000, 70));
        }
    }

    /** Water, pads and the exit of the maze. */
    private void mazeScenery(GuiGraphics g) {
        int pt = part(), x0 = Math.round(camX), y0 = Math.round(camY);
        for (int gx = Math.max(0, x0 / 16 - 1); gx <= (x0 + W) / 16 + 1; gx++) {      // clover specks on the water, fixed to the world
            for (int gy = Math.max(0, y0 / 16 - 1); gy <= (y0 + H) / 16 + 1; gy++) {
                int k = gx * 131 + gy * 17;
                int x = gx * 16 + (int) (Gfx.hash(k, 41) * 16), y = gy * 16 + (int) (Gfx.hash(k, 42) * 16);
                if (Gfx.hash(k, 40) > 0.55F) continue;
                int c = Gfx.alpha(SPECK[pt], Gfx.hash(k, 43) > 0.5F ? 100 : 64);
                if (pt == 4 && k % 3 == 0) { g.fill(x, y, x + 1, y + 1, Gfx.alpha(0xFFFFFFFF, 60 + (int) (60 * Math.sin(time * 0.05F + k)))); continue; }
                g.fill(x, y - 1, x + 1, y + 2, c);
                g.fill(x - 1, y, x + 2, y + 1, c);
            }
        }
        for (int i = 0; i < pads.length; i++) hopPad(g, i, pt);
        if (exitPad >= 0 && onScreen(pads[exitPad][0], pads[exitPad][1], 34)) {          // the exit: a golden pad with flowers
            int ex = pads[exitPad][0], ey = pads[exitPad][1];
            float pulse = 0.6F + 0.4F * (float) Math.sin(time * 0.08F);
            Gfx.glow(g, ex, ey + 3, 26, 0xFFFFE066, Math.round(95 * pulse));
            flower(g, ex - 7, ey + 2, 0xFFFFE27A, 0xFFFF8A3A);
            flower(g, ex + 8, ey + 5, 0xFFFFFFFF, 0xFFFFD84A);
            for (int k = 0; k < 4; k++) {
                double a = time * 0.05 + k * 1.5708;
                Gfx.star(g, ex + (int) Math.round(Math.cos(a) * 15), ey - 2 + (int) Math.round(Math.sin(a) * 7), 2, 0xFFFFF4A0);
            }
        }
    }

    /** The little map in the corner: the cells that were on the screen, the frog and (once seen) the exit. */
    private void drawMiniMap(GuiGraphics g) {
        int cs = 4, mw = mCols * cs, mh = mRows * cs, ox = W - 5 - mw, oy = 27, wall = 0xFFE0F0FF;
        Gfx.rrect(g, ox - 2, oy - 2, mw + 4, mh + 4, 2, Gfx.fade(0xFF000000, 0.55F));
        for (int c = 0; c < mCols * mRows; c++) {
            if (!seen[c]) continue;
            int cx = ox + (c % mCols) * cs, cy = oy + (c / mCols) * cs;
            g.fill(cx, cy, cx + cs, cy + cs, 0x55B8F0FF);
            if (step(c, 0) < 0) g.fill(cx + cs - 1, cy, cx + cs, cy + cs, wall);
            if (step(c, 1) < 0) g.fill(cx, cy, cx + 1, cy + cs, wall);
            if (step(c, 2) < 0) g.fill(cx, cy + cs - 1, cx + cs, cy + cs, wall);
            if (step(c, 3) < 0) g.fill(cx, cy, cx + cs, cy + 1, wall);
        }
        if (seen[exitPad]) { int ex = ox + (exitPad % mCols) * cs + 1, ey = oy + (exitPad / mCols) * cs + 1; g.fill(ex, ey, ex + 2, ey + 2, 0xFFFFE066); }
        if (time % 30 < 20) { int fx0 = ox + (frogPad % mCols) * cs + 1, fy0 = oy + (frogPad / mCols) * cs + 1; g.fill(fx0, fy0, fx0 + 2, fy0 + 2, 0xFF7AFF7A); }
    }

    /** Streaks that blow across the swamp on a windy level. */
    private void windFx(GuiGraphics g) {
        if (!has(M_WIND)) return;
        int len = Math.round(Math.abs(windX) * 18F) + 2;
        for (int i = 0; i < 14; i++) {
            int x = Math.floorMod(Math.round(Gfx.hash(i, 20) * W + windPos * (0.6F + Gfx.hash(i, 22))), W), y = (int) (Gfx.hash(i, 21) * (H - 20)) + 8;
            g.fill(windX >= 0 ? x : x - len, y, windX >= 0 ? x + len : x, y + 1, Gfx.alpha(0xFFFFFFFF, 55));
        }
    }

    private void drawShield(GuiGraphics g) {
        if (shield <= 0) return;
        int col = BONUS_COL[SHIELD - HOURGLASS];
        Gfx.glow(g, frogX, frogY - 1, 15, col, 50 + 20 * shield);
        for (int i = 0; i < 28; i++) {
            double a = i * Math.PI / 14 + time * 0.04;
            int x = frogX + (int) Math.round(Math.cos(a) * 13), y = frogY - 1 + (int) Math.round(Math.sin(a) * 12);
            g.fill(x, y, x + 1, y + 1, Gfx.alpha(col, 150));
        }
    }

    private void drawBonus(GuiGraphics g, Bug b, int x, int y0) {
        if (b.age > b.life - 100 && time % 8 < 3) return;                              // it blinks before it floats away
        int i = b.kind - HOURGLASS, col = BONUS_COL[i];
        int y = y0 + Math.round((float) Math.sin(time * 0.08F + b.x) * 1.6F);
        Gfx.glow(g, x, y, 13, col, 85);
        Gfx.disc(g, x, y, 8, Gfx.alpha(0xFF10203A, 170));
        for (int k = 0; k < 24; k++) {
            double a = k * Math.PI / 12;
            g.fill(x + (int) Math.round(Math.cos(a) * 8), y + (int) Math.round(Math.sin(a) * 8), x + (int) Math.round(Math.cos(a) * 8) + 1, y + (int) Math.round(Math.sin(a) * 8) + 1, Gfx.alpha(col, 200));
        }
        switch (b.kind) {
            case HOURGLASS -> {
                g.fill(x - 3, y - 5, x + 4, y - 4, 0xFFFFFFFF);
                g.fill(x - 3, y + 4, x + 4, y + 5, 0xFFFFFFFF);
                for (int k = 0; k < 3; k++) {
                    g.fill(x - 2 + k, y - 3 + k, x + 3 - k, y - 2 + k, col);
                    g.fill(x - k, y + 1 + k, x + 1 + k, y + 2 + k, col);
                }
                g.fill(x, y, x + 1, y + 1, 0xFFFFFFFF);
            }
            case HEART -> Gfx.heart(g, x - 3, y - 3, col);
            case SHIELD -> {
                g.fill(x - 3, y - 4, x + 4, y + 1, col);
                g.fill(x - 2, y + 1, x + 3, y + 2, col);
                g.fill(x - 1, y + 2, x + 2, y + 3, col);
                g.fill(x, y + 3, x + 1, y + 4, col);
                g.fill(x - 2, y - 3, x - 1, y, 0xCCFFFFFF);
            }
            case ICE -> {
                Gfx.line(g, x - 4, y, x + 4, y, 0xFFFFFFFF);
                Gfx.line(g, x, y - 4, x, y + 4, 0xFFFFFFFF);
                Gfx.line(g, x - 3, y - 3, x + 3, y + 3, col);
                Gfx.line(g, x - 3, y + 3, x + 3, y - 3, col);
            }
            default -> {                                                               // a wide tongue: a fat band with arrows
                g.fill(x - 1, y - 4, x + 2, y + 5, 0xFFFF5A78);
                g.fill(x - 2, y - 3, x + 3, y - 2, 0xFFFFFFFF);
                g.fill(x - 3, y - 2, x + 4, y - 1, 0xFFFFFFFF);
                g.fill(x - 2, y + 3, x + 3, y + 4, 0xFFFFFFFF);
                g.fill(x - 3, y + 2, x + 4, y + 3, 0xFFFFFFFF);
            }
        }
    }

    private void dizzyStars(GuiGraphics g) {
        if (dizzyT <= 0) return;
        for (int i = 0; i < 3; i++) {
            double a = time * 0.15 + i * 2.0944;
            int x = frogX + (int) Math.round(Math.cos(a) * 9), y = frogY - 17 + (int) Math.round(Math.sin(a) * 3);
            Gfx.star(g, x, y, 2, 0xFFD8A0FF);
        }
        g.fill(Math.round(camX), Math.round(camY), Math.round(camX) + W, Math.round(camY) + H, Gfx.alpha(0xFF8A3AD0, 14));
    }

    private void drawTongue(GuiGraphics g) {
        dizzyStars(g);
        if (tState == 0 || tLen <= 0) return;
        float ox = frogX + (float) Math.cos(tAng) * 7F, oy = frogY - 1 + (float) Math.sin(tAng) * 7F;
        int tx = Math.round(ox + (float) Math.cos(tAng) * tLen), ty = Math.round(oy + (float) Math.sin(tAng) * tLen);
        Gfx.line(g, Math.round(ox), Math.round(oy), tx, ty, 0xFFC02244);
        Gfx.line(g, Math.round(ox) + 1, Math.round(oy), tx + 1, ty, 0xFFFF5A78);
        Gfx.line(g, Math.round(ox), Math.round(oy) + 1, tx, ty + 1, 0xFFFF5A78);
        if (netT > 0) {
            Gfx.line(g, Math.round(ox), Math.round(oy) - 1, tx, ty - 1, 0xFFFF8AF0);
            Gfx.line(g, Math.round(ox) - 1, Math.round(oy), tx - 1, ty, 0xFFFF8AF0);
            Gfx.disc(g, tx, ty, 4, Gfx.alpha(0xFFFF8AF0, 120));
        }
        Gfx.disc(g, tx, ty, 2, 0xFFFF7A92);
        if (tCatch != null) drawBug(g, tCatch);
    }

    private void drawCursor(GuiGraphics g) {
        if (state != S_PLAY || over) return;
        boolean reach = (wmx() - frogX) * (wmx() - frogX) + (wmy() - frogY) * (wmy() - frogY) <= range() * range();
        int col = reach ? 0xFFFFFFFF : 0x88FFFFFF;
        Bug under = null;
        for (Bug b : bugs) {
            if (b.dead || b.caught > 0) continue;
            float dx = b.x - wmx(), dy = b.y - wmy();
            if (dx * dx + dy * dy < 49) { under = b; break; }
        }
        for (int i = 0; i < 16; i++) {
            double a = i * Math.PI / 8;
            int x = mx + (int) Math.round(Math.cos(a) * 5), y = my + (int) Math.round(Math.sin(a) * 5);
            g.fill(x, y, x + 1, y + 1, col);
        }
        g.fill(mx, my, mx + 1, my + 1, col);
        if (under != null && reach && under.kind != BOSS) {
            int v = VALUE[under.kind];
            ctext(g, v > 0 ? "" + v : "" + v, mx, my - 15, v > 0 ? 0xFFFFE27A : 0xFFFF6A6A);
        }
    }

    private void drawFx(GuiGraphics g, Fx f) {
        int x = Math.round(f.x), y = Math.round(f.y);
        if (!onScreen(x, y, 40)) return;
        float t = f.life / (float) f.max;
        if (f.kind == 1) Gfx.disc(g, x, y, Math.max(1, Math.round(3 * t)), Gfx.fade(f.col, t));
        else ctext(g, f.txt, x, y, Gfx.fade(f.col, Math.min(1F, t * 2F)));
    }

    private void hud(GuiGraphics g) {
        Gfx.rrect(g, 3, 3, 66, 11, 3, Gfx.fade(0xFF000000, 0.4F));
        String lv = isFinal() ? Component.translatable("cutemod.frog.hud.final", part() + 1).getString()
                : Component.translatable("cutemod.frog.hud", part() + 1, level % PER + 1, PER).getString();
        text(g, lv, 7, 5, isFinal() ? 0xFFFF8A6A : 0xFFFFD866);
        Gfx.rrect(g, W - 62, 3, 59, 11, 3, Gfx.fade(0xFF000000, 0.4F));
        text(g, isFinal() ? T("hud.exit") : Component.translatable("cutemod.frog.goal", goal()).getString(), W - 58, 5, 0xFFFFFFFF);
        int sc = scoreBase + levelPts;
        text(g, "" + sc, W - 6 - tw("" + sc), 16, sc < scoreBase ? 0xFFFF7A7A : 0xFFB8F0FF);
        for (int i = 0; i < 4; i++) {                                                // the four jars
            int x = JAR_X + i * JAR_STEP, y = JAR_Y;
            Gfx.rrect(g, x, y, JAR_W, JAR_H, 3, Gfx.fade(0xFF000000, 0.45F));
            Gfx.outline(g, x, y, JAR_W, JAR_H, jars[i] > 0 ? Gfx.alpha(JAR_COL[i], 220) : 0x44FFFFFF);
            if (jars[i] > 0) {
                Gfx.glow(g, x + 8, y + 8, 7, JAR_COL[i], 90);
                Gfx.disc(g, x + 8, y + 7, 3, JAR_COL[i]);
                text(g, "" + jars[i], x + 11, y + 8, 0xFFFFFFFF);
            } else Gfx.disc(g, x + 8, y + 7, 3, 0x33FFFFFF);
            text(g, "" + (i + 1), x + 2, y + 1, 0x88FFFFFF);
        }
        // the active bonuses
        int ax = 4;
        if (slowT > 0) { Gfx.rrect(g, ax, 112, 5, 5, 1, JAR_COL[J_SLOW]); ax += 7; }
        if (longT > 0) { Gfx.rrect(g, ax, 112, 5, 5, 1, JAR_COL[J_LONG]); ax += 7; }
        if (doubleT > 0) { Gfx.rrect(g, ax, 112, 5, 5, 1, JAR_COL[J_DOUBLE]); ax += 7; }
        if (netT > 0) { Gfx.rrect(g, ax, 112, 5, 5, 1, BONUS_COL[NET - HOURGLASS]); ax += 7; }
        for (int i = 0; i < shield; i++) { Gfx.rrect(g, ax, 112, 5, 5, 1, BONUS_COL[SHIELD - HOURGLASS]); ax += 7; }
        int ty2 = 26;                                                                 // the modifiers of this level
        for (int i = 0; i < 9; i++) {
            if ((mods >> i & 1) == 0) continue;
            String n = clip(T("mod." + (i + 1)), 70);
            text(g, n, W - 4 - tw(n), ty2, Gfx.alpha(MOD_COL[i], 210));
            ty2 += 9;
        }
        // the combo meter on the left
        Gfx.rrect(g, 4, 24, 6, 70, 3, Gfx.fade(0xFF000000, 0.4F));
        int fill = Math.round(66F * comboT / comboTime());
        if (fill > 0) Gfx.rrect(g, 5, 25 + 68 - fill - 2, 4, Math.max(1, fill), 2, Gfx.mix(0xFFFFC23A, 0xFFFF5A8A, Math.min(1F, combo / 12F)));
        if (combo >= 3) ctext(g, "x" + Math.min(comboMax(), 1 + combo / 3) * (doubleT > 0 ? 2 : 1), 7, 96, 0xFFFFE27A);
        if (isFinal()) drawMiniMap(g);
        // lives and the time bar
        Gfx.heart(g, 4, H - 10, 0xFFFF6A8E);
        text(g, "x" + lives, 13, H - 11, 0xFFFFFFFF);
        int bx = 26, bw = W - 40, by = H - 7;
        Gfx.rrect(g, bx - 1, by - 1, bw + 2, 6, 3, Gfx.fade(0xFF000000, 0.55F));
        float k = Math.max(0F, timeLeft / (float) totalTime);
        int col = k > 0.5F ? 0xFF4A9CF0 : k > 0.2F ? 0xFFF0C23A : 0xFFE0485A;
        if (k > 0) Gfx.rrect(g, bx, by, Math.max(2, Math.round(bw * k)), 4, 2, col);
        int sx = bx + Math.round(bw * (1F - k));
        Gfx.ellipse(g, sx, by - 1, 4, 3, 0xFFD2A060);                                  // a snail crawls along the bar
        Gfx.disc(g, sx, by - 2, 2, 0xFF9A6A38);
        g.fill(sx + 3, by - 4, sx + 4, by - 2, 0xFFE8D8B8);

        if ((bannerT > 0 && state == S_PLAY) || state != S_PLAY) banner(g, bannerMsg);
        if (bannerT > 0 && state == S_PLAY && !modLine.isEmpty()) banner(g, modLine, 76, 0xFFB8F0FF);
        if (bannerT > 0 && state == S_PLAY && !mapName.isEmpty()) banner(g, mapName, 36, 0xFFA8D8FF);
        if (isFinal() && state == S_PLAY && bossSpawned && !bossDead && levelPts >= goal() && bannerT <= 0)
            banner(g, Component.translatable("cutemod.frog.bossleft").getString());
    }

    private static void banner(GuiGraphics g, String s) { banner(g, s, 56, 0xFFFFD866); }

    private static void banner(GuiGraphics g, String s, int y, int col) {
        if (s == null) return;
        int w = Math.min(W - 20, tw(s) + 24);
        Gfx.rrect(g, (W - w) / 2, y, w, 16, 5, Gfx.fade(0xFF000000, 0.55F));
        ctextW(g, s, W / 2, y + 4, w - 8, col);
    }

    // ------------------------------------------------------------------ misc

    @Override
    public String hintKey() { return "cutemod.hint.frog"; }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return won ? Component.translatable("cutemod.frog.won") : Component.translatable("cutemod.ui.gameover");
    }
}
