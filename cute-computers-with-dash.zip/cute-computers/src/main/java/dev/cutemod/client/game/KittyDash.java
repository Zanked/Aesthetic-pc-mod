package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Kitty Dash: an endless runner with a view from behind, in the spirit of Subway Surfers. A pink kitty runs down a
 * track with 3 lanes. Change lanes (A / D or the arrows), jump (W / Up / Space) and slide (S / Down).
 * Carts block a lane (go around), fences must be jumped, hanging signs must be slid under.
 * Coins give points; a rocket pack lifts you over everything for a few seconds.
 * The first crash makes the creeper catch up (one heart left); if you crash again before it falls back, it is over.
 * Score = distance / 30 + 2 per coin.
 * Mouse: click the left / right third to change lane, the upper middle to jump, the lower middle to slide.
 *
 * The world is drawn in a simple perspective: an object at depth z is scaled by k = 1 / (1 + z / Z0).
 */
public class KittyDash extends MiniGame {
    private static final int CX = W / 2, HOR = 40, BOT = 130;
    private static final double Z0 = 24, ZFAR = 170, LW = 42, BED = 66;
    private static final int TRAIN = 0, FENCE = 1, SIGN = 2, COIN = 3, JET = 4;
    private static final int[] TRAIN_COL = {0xFF5BA8F0, 0xFFFF9C5B, 0xFFB57BD6, 0xFF6FCF8B, 0xFFF2C94C};
    private static final int PINK = 0xFFF58FB8, PINK_D = 0xFFD9648F;

    private static final class Obj {
        final int type, lane, span, color;
        final double len, y;
        double z;

        Obj(int type, int lane, int span, double z, double len, double y, int color) {
            this.type = type; this.lane = lane; this.span = span; this.z = z; this.len = len; this.y = y; this.color = color;
        }
    }

    private final List<Obj> things = new ArrayList<>();
    private final List<double[]> deco = new ArrayList<>();       // x, world z, kind (0 green tree, 1 cherry tree, 2 lamp)
    private final List<double[]> fx = new ArrayList<>();         // particles: x, y, vx, vy, life, color

    private double dist, v, laneF, yj, vy, nextSeg, decoNext;
    private int lane, prevLane, slide, jet, ready, ticks, run, coins, stumble, invuln, flash, lastSafe, jumpBuf, combo, comboT, dead;
    private boolean dropSlide, decoLeft;

    @Override
    public void reset() {
        score = 0; over = false;
        things.clear(); deco.clear(); fx.clear();
        dist = 0; v = 1.0; lane = prevLane = 1; laneF = 1; yj = 0; vy = 0;
        slide = 0; jet = 0; ready = 100; ticks = 0; run = 0; coins = 0; stumble = 0; invuln = 0; flash = 0;
        lastSafe = 1; jumpBuf = 0; combo = 0; comboT = 0; dead = 0; dropSlide = false;
        nextSeg = 60;
        decoNext = 0;
        while (decoNext < ZFAR + 20) addDeco();
    }

    private void addDeco() {
        decoLeft = !decoLeft;
        boolean left = decoLeft;
        double x = (left ? -1 : 1) * (BED + 16 + rnd.nextInt(34));
        int kind = rnd.nextInt(10) < 3 ? 2 : rnd.nextInt(2);
        deco.add(new double[]{x, decoNext + rnd.nextInt(8), kind});
        decoNext += 22;
    }

    private static double laneX(double lane) { return (lane - 1) * LW; }

    // ---------- input ----------
    @Override
    public boolean key(int keyCode) {
        if (over) return false;
        if (keyCode == KEY_LEFT || keyCode == 65) { move(-1); return true; }
        if (keyCode == KEY_RIGHT || keyCode == 68) { move(1); return true; }
        if (keyCode == KEY_UP || keyCode == 87 || keyCode == KEY_SPACE) { jump(); return true; }
        if (keyCode == KEY_DOWN || keyCode == 83) { roll(); return true; }
        return false;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        if (x < W / 3) move(-1);
        else if (x > W * 2 / 3) move(1);
        else if (y < H / 2) jump();
        else roll();
        return true;
    }

    private void move(int d) {
        int n = Math.max(0, Math.min(2, lane + d));
        if (n != lane) { prevLane = lane; lane = n; beep(); }
    }

    private void jump() {
        if (jet > 0) return;
        if (yj <= 0.01) { vy = 3.3; slide = 0; jumpBuf = 0; pling(1.4F); }
        else jumpBuf = 8;                                               // pressed a bit early: jump as soon as we land
    }

    private void roll() {
        if (jet > 0) return;
        if (yj > 0.01) { vy = Math.min(vy, -4.6); dropSlide = true; }   // fall fast, roll on landing
        else { slide = 34; pling(0.8F); }
    }

    // ---------- the game ----------
    @Override
    public void tick() {
        ticks++;
        if (ready > 0) { ready--; return; }
        run++;
        double lvl = Math.min(1.0, run / 6000.0);
        v = 1.0 + lvl * 1.0;
        if (jet > 0) v *= 1.25;
        dist += v;
        score = (int) (dist / 30) + coins * 2;
        if (invuln > 0) invuln--;
        if (flash > 0) flash--;
        if (comboT > 0 && --comboT == 0) combo = 0;
        if (stumble > 0) stumble--;

        // lanes and jumping
        laneF += (lane - laneF) * 0.3;
        if (jet > 0) {
            jet--;
            yj += (46 - yj) * 0.12; vy = 0;
            if (jet == 0) invuln = Math.max(invuln, 90);
        } else if (yj > 0 || vy > 0) {
            vy -= 0.19; yj += vy;
            if (yj <= 0) {
                yj = 0; vy = 0;
                if (dropSlide) { slide = 28; dropSlide = false; }
                if (jumpBuf > 0) jump();
            }
        }
        if (jumpBuf > 0) jumpBuf--;
        if (slide > 0) slide--;

        // scenery
        for (double[] d : deco) d[1] -= v;
        deco.removeIf(d -> d[1] < -14);
        decoNext -= v;
        while (decoNext < ZFAR + 20) { addDeco(); }

        // new things
        nextSeg -= v;
        if (nextSeg <= 0) {
            double len = spawnSegment(lvl);
            nextSeg = len + 34 + 18 * lvl;
        }

        // move things and meet them
        for (int i = things.size() - 1; i >= 0; i--) {
            Obj o = things.get(i);
            o.z -= v;
            double zb = o.z + o.len;
            if (zb < -12) { things.remove(i); continue; }
            if (o.z > 4 || zb < -4) continue;                           // not at the kitty
            boolean inLane = laneF > o.lane - 0.62 && laneF < o.lane + o.span - 1 + 0.62;
            if (o.type == COIN) {
                boolean magnet = jet > 0 && Math.abs(laneF - o.lane) < 1.6;
                double mid = yj + (slide > 0 ? 6 : 13);
                if ((inLane && Math.abs(mid - o.y) < 15) || magnet) { takeCoin(o); things.remove(i); }
            } else if (o.type == JET) {
                if (inLane) { jet = 320; vy = 0; slide = 0; pling(1.9F); things.remove(i); }
            } else if (inLane && invuln <= 0 && jet <= 0) {
                boolean hit = switch (o.type) {
                    case TRAIN -> true;
                    case FENCE -> yj < 12;
                    default -> !(slide > 0 && yj < 3);                  // a sign: only a slide gets under it
                };
                if (!hit) continue;
                boolean side = o.type == TRAIN && o.z < -1.5;           // we ran into the side of a cart: bounce back
                if (side) { lane = prevLane; }
                else things.remove(i);
                crash(o.type);
            }
        }

        // particles
        for (int i = fx.size() - 1; i >= 0; i--) {
            double[] p = fx.get(i);
            p[0] += p[2]; p[1] += p[3]; p[3] += 0.12; p[4]--;
            if (p[4] <= 0) fx.remove(i);
        }
    }

    private void takeCoin(Obj o) {
        coins++; combo++; comboT = 50;
        pling(1.2F + Math.min(combo, 12) * 0.06F);
        burst(CX + laneX(o.lane) * 0.9, BOT - 16 - o.y * 0.5, 4, 0xFFFFD84A);
    }

    private void crash(int type) {
        flash = 10;
        burst(CX + laneX(laneF), BOT - 14, 12, 0xFFFFFFFF);
        dev.cutemod.client.os.Sfx.ui(SoundEvents.NOTE_BLOCK_BASS.value(), 0.55F, 0.7F);
        combo = 0;
        if (stumble > 0) {                                              // the creeper has caught up
            over = true;
            dead = type == TRAIN ? 0 : type == FENCE ? 1 : 2;
            score = (int) (dist / 30) + coins * 2;
        } else {
            stumble = 480; invuln = 70;
        }
    }

    private void burst(double x, double y, int n, int col) {
        for (int i = 0; i < n; i++)
            fx.add(new double[]{x, y, (rnd.nextDouble() - 0.5) * 3, -rnd.nextDouble() * 2.5, 16 + rnd.nextInt(10), col});
    }

    // ---------- the track: what comes next ----------
    private void add(int type, int lane, int span, double z, double len, double y, int col) {
        things.add(new Obj(type, lane, span, z, len, y, col));
    }

    private void coinLine(int lane, double z, int n) {
        for (int i = 0; i < n; i++) add(COIN, lane, 1, z + i * 6, 0, 8, 0);
    }

    /** One chunk of the track, starting at ZFAR. Returns its length. */
    private double spawnSegment(double lvl) {
        int safe = rnd.nextInt(3);
        if (lvl < 0.35 && Math.abs(safe - lastSafe) > 1) safe = 1;      // at the start the lane changes are short
        lastSafe = safe;
        double z = ZFAR;
        if (jet > 0) { coinLine(safe, z, 10); return 60; }
        boolean jetOnTrack = false;
        for (Obj o : things) if (o.type == JET) jetOnTrack = true;
        int roll = rnd.nextInt(100);
        if (!jetOnTrack && rnd.nextInt(100) < 4) {                      // a rocket pack, with coins behind it
            add(JET, safe, 1, z, 0, 14, 0);
            coinLine(safe, z + 14, 6);
            return 50;
        }
        if (roll < 20) { coinLine(safe, z, 8 + rnd.nextInt(5)); return 54; }
        if (roll < 42) return carts(safe, z, lvl);
        if (roll < 62) return fences(safe, z, lvl);
        if (roll < 78) return signs(z, lvl);
        return mixed(safe, z);
    }

    /** Carts: they fill one lane (two later on), coins run along the free lane. */
    private double carts(int safe, double z, double lvl) {
        double len = 22 + rnd.nextInt(16);
        boolean both = lvl >= 0.25 && rnd.nextBoolean();
        int first = -1;
        for (int l = 0; l < 3; l++) {
            if (l == safe) continue;
            if (!both && first >= 0) continue;
            if (first < 0) first = l;
            add(TRAIN, l, 1, z + rnd.nextInt(6), len, 0, TRAIN_COL[rnd.nextInt(TRAIN_COL.length)]);
        }
        coinLine(safe, z, (int) (len / 6) + 1);
        return len + 6;
    }

    /** Low fences to jump over: 1 to 3 lanes wide. After a while there are two in a row. */
    private double fences(int safe, double z, double lvl) {
        int span = 1 + rnd.nextInt(lvl < 0.2 ? 2 : 3);
        int start = span == 3 ? 0 : rnd.nextInt(4 - span);
        add(FENCE, start, span, z, 3, 0, 0);
        double len = 3;
        if (span == 3) {                                                // a coin arc over the fence
            for (int i = 0; i < 7; i++) {
                double t = (i - 3) / 3.0;
                add(COIN, 1, 1, z + (i - 3) * 5 - 2, 0, 8 + (1 - t * t) * 26, 0);
            }
            len = 20;
        } else {
            int free = (start == 0) ? 2 : 0;
            if (span == 1) free = (start + 1 + rnd.nextInt(2)) % 3;
            coinLine(free, z - 4, 6);
            len = 26;
        }
        if (lvl > 0.5 && rnd.nextInt(100) < 45) { add(FENCE, start, span, z + len + 14, 3, 0, 0); len += 20; }
        return len;
    }

    /** Hanging signs: slide under them. */
    private double signs(double z, double lvl) {
        int span = 1 + rnd.nextInt(lvl < 0.2 ? 2 : 3);
        int start = span == 3 ? 0 : rnd.nextInt(4 - span);
        add(SIGN, start, span, z, 4, 0, 0);
        for (int l = start; l < start + span; l++) if (rnd.nextBoolean() || span == 1) coinLine(l, z - 6, 5);
        return 30;
    }

    /** A cart in one lane, a fence or sign in another, coins in the free one. */
    private double mixed(int safe, double z) {
        int a = (safe + 1) % 3, b = (safe + 2) % 3;
        add(TRAIN, a, 1, z, 24, 0, TRAIN_COL[rnd.nextInt(TRAIN_COL.length)]);
        add(rnd.nextBoolean() ? FENCE : SIGN, b, 1, z + 4, rnd.nextBoolean() ? 3 : 4, 0, 0);
        coinLine(safe, z, 5);
        return 34;
    }

    // ---------- drawing ----------
    private static double k(double z) { return 1.0 / (1.0 + Math.max(z, -10) / Z0); }

    private static int gy(double k) { return (int) Math.round(HOR + (BOT - HOR) * k); }

    private static int px(double x, double k) { return (int) Math.round(CX + x * k); }

    /** A fill that never leaves the screen. x1 and y1 are exclusive. */
    private static void fl(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(W, x1); y1 = Math.min(H, y1);
        if (x1 > x0 && y1 > y0) g.fill(x0, y0, x1, y1, c);
    }

    private static void dsc(GuiGraphics g, int cx, int cy, int r, int c) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            fl(g, cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, c);
        }
    }

    private static int shade(int c, double f) {
        int r = (int) (((c >> 16) & 255) * f), gr = (int) (((c >> 8) & 255) * f), b = (int) ((c & 255) * f);
        return 0xFF000000 | Math.min(255, r) << 16 | Math.min(255, gr) << 8 | Math.min(255, b);
    }

    private static int lerp(int a, int b, double t) { return (int) Math.round(a + (b - a) * t); }

    @Override
    public void render(GuiGraphics g) {
        drawSky(g);
        drawGround(g);
        for (double[] d : sortedDeco()) drawDeco(g, d);
        List<Obj> sorted = new ArrayList<>(things);
        sorted.sort((a, b) -> Double.compare(b.z + b.len / 2, a.z + a.len / 2));
        for (Obj o : sorted) drawObj(g, o);
        if (stumble > 0) drawCreeper(g);
        drawCat(g);
        for (double[] p : fx) fl(g, (int) p[0], (int) p[1], (int) p[0] + 2, (int) p[1] + 2, (int) p[5]);
        if (jet > 0) for (int i = 0; i < 6; i++) fl(g, (i * 41 + ticks * 7) % W, (i * 29 + ticks * 13) % H, (i * 41 + ticks * 7) % W + 1, (i * 29 + ticks * 13) % H + 9, 0x55FFFFFF);
        if (flash > 0) fl(g, 0, 0, W, H, (flash * 4) << 24 | 0xFF5C7C);       // a red flash that fades out
        drawHud(g);
    }

    private List<double[]> sortedDeco() {
        List<double[]> l = new ArrayList<>(deco);
        l.sort((a, b) -> Double.compare(b[1], a[1]));
        return l;
    }

    private void drawSky(GuiGraphics g) {
        int[] band = {0xFFFFC9DE, 0xFFFFD6E6, 0xFFFFE3E6, 0xFFFFEEE0, 0xFFFFF6E0};
        int bh = HOR / band.length + 1;
        for (int i = 0; i < band.length; i++) fl(g, 0, i * bh, W, (i + 1) * bh, band[i]);
        dsc(g, 158, 26, 12, 0xFFFFF3B8);                                 // a pale sun
        dsc(g, 158, 26, 8, 0xFFFFE680);
        for (int c = 0; c < 2; c++) {                                    // two slow clouds
            int cx = (int) ((c * 120 + 40 - dist * 0.03) % (W + 40));
            if (cx < -30) cx += W + 40;
            fl(g, cx - 12, 14 + c * 9, cx + 12, 19 + c * 9, 0xCCFFFFFF);
            fl(g, cx - 7, 11 + c * 9, cx + 7, 16 + c * 9, 0xCCFFFFFF);
        }
        for (int x = 0; x < W; x += 2) {                                 // far lavender hills, then closer green ones
            double h1 = 9 + 5 * Math.sin(x * 0.045 + dist * 0.0015) + 3 * Math.sin(x * 0.11 + 1.7);
            fl(g, x, HOR - (int) h1, x + 2, HOR, 0xFFD6C8EE);
            double h2 = 4 + 3 * Math.sin(x * 0.08 + dist * 0.003 + 3) + 2 * Math.sin(x * 0.21);
            fl(g, x, HOR - (int) h2, x + 2, HOR, 0xFFBFE3B4);
        }
    }

    private void drawGround(GuiGraphics g) {
        for (int y = HOR; y < H; y++) {
            double kk = (y - HOR + 0.5) / (BOT - HOR);
            double z = Z0 * (1 / kk - 1);
            double wz = z + dist;
            boolean alt = (((int) Math.floor(wz / 9.0)) & 1) == 0;
            fl(g, 0, y, W, y + 1, alt ? 0xFFA3DD9C : 0xFF98D893);       // grass
            int bx0 = px(-BED, kk), bx1 = px(BED, kk);
            fl(g, bx0, y, bx1, y + 1, alt ? 0xFF6E6C8A : 0xFF67657F);   // the track
            int cw = Math.max(1, (int) Math.round(2.5 * kk));
            fl(g, bx0 - cw, y, bx0, y + 1, 0xFFFFFFFF);                  // white curbs with a pink stripe
            fl(g, bx1, y, bx1 + cw, y + 1, 0xFFFFFFFF);
            fl(g, bx0, y, bx0 + Math.max(1, cw / 2), y + 1, PINK);
            fl(g, bx1 - Math.max(1, cw / 2), y, bx1, y + 1, PINK);
            if ((((int) Math.floor(wz / 14.0)) & 1) == 0) {              // lane dashes
                int lw = kk > 0.6 ? 2 : 1;
                int l0 = px(-LW / 2, kk), l1 = px(LW / 2, kk);
                fl(g, l0, y, l0 + lw, y + 1, 0x99FFFFFF);
                fl(g, l1, y, l1 + lw, y + 1, 0x99FFFFFF);
            }
        }
    }

    private void drawDeco(GuiGraphics g, double[] d) {
        double kk = k(d[1]);
        if (d[1] > ZFAR + 10) return;
        int x = px(d[0], kk), y = gy(kk);
        int kind = (int) d[2];
        if (kind == 2) {                                                  // a lamp post
            fl(g, x - Math.max(1, (int) (kk)), y - (int) (26 * kk), x + Math.max(1, (int) (1.5 * kk)), y, 0xFF5E5878);
            dsc(g, x, y - (int) (28 * kk), Math.max(1, (int) (3 * kk)), 0xFFFFE680);
            return;
        }
        int tw = Math.max(1, (int) Math.round(3 * kk));
        fl(g, x - tw / 2, y - (int) (16 * kk), x - tw / 2 + tw, y, 0xFF8A6A50);
        int r = Math.max(2, (int) Math.round(11 * kk));
        int top = y - (int) (24 * kk);
        dsc(g, x, top, r, kind == 1 ? 0xFFF9B8D3 : 0xFF58B864);
        dsc(g, x - r / 3, top - r / 3, Math.max(1, r / 2), kind == 1 ? 0xFFFFD6E6 : 0xFF84D88E);
    }

    /** A box in the world: depth zf (near) to zb (far), height y0 to y1, centered at lane-x xc. */
    private void box3(GuiGraphics g, double xc, double hw, double y0, double y1, double zf, double zb, int col, int[] face) {
        double kf = k(zf), kb = k(zb);
        int gf = gy(kf), gb = gy(kb);
        int xl = px(xc - hw, kf), xr = px(xc + hw, kf);
        int xlb = px(xc - hw, kb), xrb = px(xc + hw, kb);
        int ytf = gf - (int) Math.round(y1 * kf), ybf = gf - (int) Math.round(y0 * kf);
        int ytb = gb - (int) Math.round(y1 * kb), ybb = gb - (int) Math.round(y0 * kb);
        if (Math.abs(xc) > 1 && zb > zf + 0.5) {                          // the side that looks at the middle of the track
            boolean left = xc < 0;
            int xn = left ? xr : xl, xf = left ? xrb : xlb;
            if (xn != xf) {
                int a = Math.min(xn, xf), b = Math.max(xn, xf);
                for (int x = a; x <= b; x++) {
                    double t = (double) (x - xf) / (xn - xf);
                    fl(g, x, lerp(ytb, ytf, t), x + 1, lerp(ybb, ybf, t), shade(col, 0.72));
                }
            }
        }
        if (zb > zf + 0.5 && ytb < ytf) {                                 // the top
            int topCol = shade(col, 1.18);
            for (int y = ytb; y <= ytf; y++) {
                double t = (double) (y - ytb) / Math.max(1, ytf - ytb);
                fl(g, lerp(xlb, xl, t), y, lerp(xrb, xr, t) + 1, y + 1, topCol);
            }
        }
        fl(g, xl, ytf, xr + 1, ybf, col);                                 // the front
        if (face != null) { face[0] = xl; face[1] = ytf; face[2] = xr + 1; face[3] = ybf; }
    }

    private final int[] face = new int[4];

    private void drawObj(GuiGraphics g, Obj o) {
        if (o.z > ZFAR + 12) return;
        double zb = o.z + o.len;
        double cxw = laneX(o.lane + (o.span - 1) / 2.0), hw = o.span * LW / 2.0 - 4;
        double kf = k(o.z);
        switch (o.type) {
            case TRAIN -> {
                box3(g, cxw, hw, 0, 38, o.z, zb, o.color, face);
                int fw = face[2] - face[0], fh = face[3] - face[1];
                if (fw >= 8) {
                    fl(g, face[0] + fw * 12 / 100, face[1] + fh * 14 / 100, face[0] + fw * 44 / 100, face[1] + fh * 48 / 100, 0xFFBFE8FF);
                    fl(g, face[0] + fw * 56 / 100, face[1] + fh * 14 / 100, face[0] + fw * 88 / 100, face[1] + fh * 48 / 100, 0xFFBFE8FF);
                    fl(g, face[0], face[1] + fh * 58 / 100, face[2], face[1] + fh * 66 / 100, 0xFFFFFFFF);
                    fl(g, face[0] + fw * 10 / 100, face[1] + fh * 76 / 100, face[0] + fw * 26 / 100, face[1] + fh * 90 / 100, 0xFFFFF3B0);
                    fl(g, face[0] + fw * 74 / 100, face[1] + fh * 76 / 100, face[0] + fw * 90 / 100, face[1] + fh * 90 / 100, 0xFFFFF3B0);
                }
            }
            case FENCE -> {
                box3(g, cxw, hw, 0, 11, o.z, zb, 0xFFFFFFFF, face);
                int fw = face[2] - face[0], n = Math.max(2, o.span * 4);
                for (int i = 0; i < n; i += 2)
                    fl(g, face[0] + fw * i / n, face[1], face[0] + fw * (i + 1) / n, face[3], PINK);
                fl(g, face[0], face[1], face[2], face[1] + Math.max(1, (face[3] - face[1]) / 5), PINK_D);
            }
            case SIGN -> {
                double zs = o.z + o.len;
                for (int side = -1; side <= 1; side += 2) {              // two posts at the ends
                    double pxw = cxw + side * (hw + 1);
                    box3(g, pxw, 1.5, 0, 30, o.z, zs, 0xFF5E5878, null);
                }
                box3(g, cxw, hw, 17, 29, o.z, zs, 0xFFE5486F, face);
                int fw = face[2] - face[0], n = Math.max(2, o.span * 4);
                for (int i = 0; i < n; i += 2)
                    fl(g, face[0] + fw * i / n, face[1], face[0] + fw * (i + 1) / n, face[3], 0xFFFFFFFF);
            }
            case COIN -> {
                int x = px(laneX(o.lane), kf), y = gy(kf) - (int) Math.round(o.y * kf);
                double r = Math.max(1.5, 5 * kf);
                double spin = Math.abs(Math.cos((dist + o.z * 0.5) / 12.0));
                int w = Math.max(1, (int) Math.round(r * (0.3 + 0.7 * spin))), h = (int) Math.round(r);
                fl(g, x - w, y - h, x + w, y + h, 0xFFE8A817);
                if (w > 1 && h > 2) fl(g, x - w + 1, y - h + 1, x + w - 1, y + h - 1, 0xFFFFD84A);
            }
            default -> {                                                  // the rocket pack
                int x = px(laneX(o.lane), kf), y = gy(kf) - (int) Math.round(o.y * kf);
                int s = Math.max(2, (int) Math.round(7 * kf));
                dsc(g, x, y, s + 3, 0x44FFE066);
                fl(g, x - s / 2, y - s, x + s - s / 2, y + s, 0xFFFFFFFF);
                fl(g, x - s / 2, y - s, x + s - s / 2, y - s + Math.max(1, s / 2), 0xFFE5486F);
                fl(g, x - s, y, x - s / 2, y + s, 0xFFE5486F);
                fl(g, x + s - s / 2, y, x + s, y + s, 0xFFE5486F);
                fl(g, x - s / 3, y + s, x + s / 3 + 1, y + s + Math.max(1, s / 2), 0xFFFFB03A);
            }
        }
    }

    /** The creeper that follows the kitty after the first crash: a green back with speckles and four little feet. */
    private void drawCreeper(GuiGraphics g) {
        boolean warn = stumble < 120 && (ticks / 6) % 2 == 0;           // it is going away: blinks
        int x = (int) (CX + laneX(laneF)) + (int) (Math.sin(ticks / 9.0) * 3);
        int top = BOT + 2 - (warn ? 4 : 0);
        fl(g, x - 11, top, x + 11, H, 0xFF4FAE5E);
        for (int i = 0; i < 9; i++) {
            int sx = x - 10 + (i * 7) % 20, sy = top + 1 + (i * 5) % 8;
            fl(g, sx, sy, sx + 3, sy + 2, i % 2 == 0 ? 0xFF2F8A44 : 0xFF86D790);
        }
        fl(g, x - 11, top, x + 11, top + 1, 0xFF7FD98A);
    }

    private void drawCat(GuiGraphics g) {
        if (invuln > 0 && jet <= 0 && (ticks / 4) % 2 == 0) return;     // blinks after a crash
        int x = (int) Math.round(CX + laneX(laneF));
        int fy = BOT - (int) Math.round(yj);
        fl(g, x - 7, BOT - 1, x + 8, BOT + 1, yj > 8 ? 0x22000000 : 0x33000000);   // the shadow stays on the ground
        boolean step = (ticks / 4) % 2 == 0;
        if (slide > 0) {                                                // rolling: long and low
            fl(g, x - 9, fy - 9, x + 10, fy, PINK);
            fl(g, x - 9, fy - 3, x + 10, fy, PINK_D);
            fl(g, x - 5, fy - 14, x + 6, fy - 8, PINK);
            fl(g, x - 5, fy - 17, x - 3, fy - 13, PINK); fl(g, x + 3, fy - 17, x + 5, fy - 13, PINK);
            fl(g, x + 9, fy - 7, x + 14, fy - 5, PINK_D);               // tail
            return;
        }
        if (jet > 0) {                                                  // the rocket pack and its flame
            fl(g, x - 5, fy - 20, x + 6, fy - 6, 0xFFE5486F);
            fl(g, x - 4, fy - 6, x + 5, fy + (step ? 6 : 3), 0xFFFFB03A);
            fl(g, x - 2, fy - 6, x + 3, fy + (step ? 3 : 1), 0xFFFFF3B0);
        }
        // legs
        fl(g, x - 5, fy - 6 - (step ? 0 : 3), x - 1, fy - (step ? 0 : 3), PINK_D);
        fl(g, x + 1, fy - 6 - (step ? 3 : 0), x + 5, fy - (step ? 3 : 0), PINK_D);
        if (yj > 1 && jet <= 0) { fl(g, x - 5, fy - 6, x - 1, fy - 2, PINK_D); fl(g, x + 1, fy - 6, x + 5, fy - 2, PINK_D); }
        // body: a lavender hoodie seen from behind, with a white tail
        fl(g, x - 6, fy - 17, x + 7, fy - 6, 0xFFB57BD6);
        fl(g, x - 6, fy - 17, x + 7, fy - 15, 0xFFCFA3E8);
        fl(g, x - 3, fy - 14, x + 4, fy - 9, 0xFF9B63BE);                // the hood pocket
        int wag = (int) Math.round(Math.sin(ticks / 4.0) * 2);
        fl(g, x + 6, fy - 12 + wag, x + 10, fy - 10 + wag, 0xFFFFFFFF);
        fl(g, x + 9, fy - 16 + wag, x + 11, fy - 11 + wag, 0xFFFFFFFF);
        // head with ears and a bow
        fl(g, x - 7, fy - 28, x + 8, fy - 17, PINK);
        fl(g, x - 7, fy - 32, x - 3, fy - 27, PINK); fl(g, x + 4, fy - 32, x + 8, fy - 27, PINK);
        fl(g, x - 6, fy - 31, x - 4, fy - 28, 0xFFFFC0D6); fl(g, x + 5, fy - 31, x + 7, fy - 28, 0xFFFFC0D6);
        fl(g, x - 7, fy - 21, x + 8, fy - 17, PINK_D);
        fl(g, x + 1, fy - 29, x + 6, fy - 26, 0xFFFFFFFF); fl(g, x + 3, fy - 29, x + 4, fy - 26, 0xFFE5486F);
    }

    private static void heart(GuiGraphics g, int x, int y, int c) {
        fl(g, x + 1, y, x + 3, y + 1, c); fl(g, x + 4, y, x + 6, y + 1, c);
        fl(g, x, y + 1, x + 7, y + 3, c); fl(g, x + 1, y + 3, x + 6, y + 4, c);
        fl(g, x + 2, y + 4, x + 5, y + 5, c); fl(g, x + 3, y + 5, x + 4, y + 6, c);
    }

    private void drawHud(GuiGraphics g) {
        fl(g, 0, 0, W, 12, 0x88000000);
        text(g, Integer.toString(score), 5, 2, 0xFFFFFFFF);
        dsc(g, 60, 6, 3, 0xFFFFD84A);
        text(g, Integer.toString(coins), 66, 2, 0xFFFFE680);
        boolean second = stumble == 0 || (stumble < 120 && (ticks / 6) % 2 == 0);
        heart(g, W - 24, 3, 0xFFFF5C7C);
        heart(g, W - 13, 3, second ? 0xFFFF5C7C : 0x55FFFFFF);
        if (jet > 0) {
            fl(g, 90, 4, 90 + 40, 8, 0x55FFFFFF);
            fl(g, 90, 4, 90 + 40 * jet / 320, 8, 0xFFFFB03A);
        } else if (combo >= 5) {
            ctext(g, "x" + combo, 110, 2, 0xFFFFD84A);
        }
        if (ready > 0) {
            String s = ready > 66 ? "3" : ready > 33 ? "2" : "1";
            fl(g, W / 2 - 26, 50, W / 2 + 26, 74, 0xCC000000);
            ctext(g, s, W / 2, 58, 0xFFFFFFFF);
        } else if (run < 70) {
            ctext(g, "GO!", W / 2, 58, 0xFFFFD84A);
        }
    }

    @Override
    public Component endTitle() {
        return Component.translatable("cutemod.dash.dead." + dead);
    }

    @Override
    public String hintKey() { return "cutemod.hint.dash"; }
}
