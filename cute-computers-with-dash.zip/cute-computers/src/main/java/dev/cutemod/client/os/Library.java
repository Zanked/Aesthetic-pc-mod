package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * The catalog of CuteStore and what the player owns: bought games, installs (they take a few seconds
 * of real time, even when the computer screen is closed), play time and best scores.
 * Saved in cutemod_library.txt. Coins are handled by {@link Progress}.
 */
public final class Library {
    private Library() {}

    /** One game in the store. rating is x10 (47 = 4.7), size in MB. */
    public record Game(String id, int price, String genre, int sizeMb, int rating, int rgb) {}

    public static final List<Game> GAMES = List.of(
            new Game("pink", 15, "arcade", 12, 38, 0xF4A7C3),
            new Game("green", 20, "puzzle", 18, 44, 0x8FD39A),
            new Game("white", 15, "arcade", 9, 41, 0xE8EAF0),
            new Game("blue", 20, "arcade", 14, 40, 0x8EC3F2),
            new Game("orange", 20, "puzzle", 11, 36, 0xF5B06B),
            new Game("purple", 25, "arcade", 10, 39, 0x4A3A66),
            new Game("yellow", 20, "arcade", 8, 35, 0xF3D46A),
            new Game("red", 30, "puzzle", 22, 43, 0xE27B72),
            new Game("breakout", 35, "arcade", 16, 42, 0xC98B5A),
            new Game("cubes", 40, "puzzle", 20, 47, 0xB57BD6),
            new Game("pong", 35, "arcade", 13, 37, 0x7ED957),
            new Game("bees", 55, "arcade", 27, 41, 0xF5C518),
            new Game("horror", 80, "horror", 45, 46, 0x8B1A2B),
            new Game("maze", 120, "horror", 70, 48, 0x5A2A6A),
            new Game("otherworld", 130, "horror", 80, 48, 0x8A1020),
            new Game("craft", 220, "sandbox", 120, 49, 0x5BBF4A),
            new Game("zombies", 180, "shooter", 95, 47, 0x4F8F3A),
            new Game("durak", 90, "cards", 15, 45, 0x2E7D4F),
            new Game("sakura", 70, "anime", 24, 46, 0xF58FB8),
            new Game("blocks", 75, "puzzle", 10, 47, 0x6A8FE0),
            new Game("cakes", 100, "cooking", 17, 48, 0xF4A8B8),
            new Game("cakefactory", 90, "cooking", 14, 46, 0xF7B6D2),
            new Game("racer", 60, "arcade", 16, 45, 0xF58FB8),
            new Game("checkers", 90, "board", 12, 47, 0xC48BB0),
            new Game("slice", 65, "arcade", 14, 46, 0xE8475A),
            new Game("rabbit", 70, "arcade", 18, 47, 0x8ED36A),
            new Game("dash", 80, "arcade", 20, 47, 0x6FC7E8));

    /**
     * A downloadable app: the desktop apps that are not part of the system. Until it is installed it is hidden
     * from the Dock and the Start menu. icon = its number in the Dock (see {@link Desktop#drawIcon}). price 0 = free.
     */
    public record Program(String id, int icon, int price, String genre, int sizeMb, int rating, int rgb) {}

    public static final List<Program> PROGRAMS = List.of(
            new Program("calc", 5, 0, "tools", 2, 44, 0x7FA8E8),
            new Program("paint", 4, 0, "creative", 6, 46, 0xF3A6C8),
            new Program("terminal", 11, 0, "tools", 3, 47, 0x2B4A33),
            new Program("pet", 8, 0, "pets", 18, 48, 0xFFE08A),
            new Program("mail", 14, 0, "social", 5, 41, 0xE9A0A0),
            new Program("music", 7, 10, "media", 14, 45, 0x8A6AC6),
            new Program("weather", 16, 0, "tools", 4, 46, 0x5AA8F0),
            new Program("farm", 17, 30, "pets", 7, 47, 0x8FD39A),
            new Program("fishing", 18, 25, "pets", 6, 46, 0x6FD0FF),
            new Program("style", 19, 25, "pets", 5, 47, 0xB57BD6),
            new Program("beats", 20, 30, "media", 8, 46, 0x6A4AD0),
            new Program("season", 21, 0, "pets", 4, 47, 0xF0A030),
            new Program("gift", 23, 0, "tools", 3, 47, 0xF08AA8),
            new Program("quiz", 24, 0, "tools", 4, 46, 0x7ACB8A),
            new Program("tictac", 25, 0, "pets", 2, 45, 0x6FB8E8),
            new Program("wheel", 26, 0, "tools", 3, 46, 0xFF9A4A),
            new Program("photo", 28, 20, "creative", 6, 47, 0x8A9AE8),
            new Program("stickers", 29, 15, "creative", 5, 46, 0xE98AC8),
            new Program("bank", 30, 20, "tools", 2, 46, 0xF08A9A),
            new Program("wishlist", 31, 10, "tools", 3, 46, 0xE0709A),
            new Program("radio", 32, 15, "media", 9, 47, 0x7A8AE8),
            new Program("petstats", 33, 10, "pets", 2, 47, 0xE8A04A),
            new Program("tales", 34, 15, "media", 6, 48, 0xC8905A));

    /** Icon number of the removed Habits app. The numbers of the other apps are saved in the Dock layouts, so it is not reused. */
    private static final int RETIRED_ICON = 27;

    public static final int DEAL_PERCENT = 30;

    private static boolean loaded, dirty;
    private static int saveDelay;
    private static final Set<String> owned = new HashSet<>();
    private static final Set<String> notified = new HashSet<>();
    /** Apps that were bought (or free) and then uninstalled: they stay owned, installing them again is free. */
    private static final Set<String> removed = new HashSet<>();
    private static final Map<String, Long> installStart = new HashMap<>();
    private static final Map<String, Integer> playSeconds = new HashMap<>();
    private static final Map<String, Integer> best = new HashMap<>();
    private static final Map<String, Integer> reviewStars = new HashMap<>();
    private static final Map<String, String> reviewText = new HashMap<>();

    // ---------- catalog ----------
    public static Game game(String id) {
        for (Game g : GAMES) if (g.id().equals(id)) return g;
        return GAMES.get(0);
    }

    public static String name(String id) {
        return Component.translatable((isProgram(id) ? "cutemod.os." : "cutemod.game.") + id).getString();
    }

    // ---------- apps ----------
    public static Program program(String id) {
        for (Program p : PROGRAMS) if (p.id().equals(id)) return p;
        return null;
    }

    public static boolean isProgram(String id) { return program(id) != null; }

    /** A game or an app that exists (an old save may still know the Shop app, which was removed). */
    private static boolean known(String id) {
        for (Game g : GAMES) if (g.id().equals(id)) return true;
        return isProgram(id);
    }

    public static Program programByIcon(int icon) {
        for (Program p : PROGRAMS) if (p.icon() == icon) return p;
        return null;
    }

    /** False while a store app (the Dock icon number) is not installed: it is hidden from the Dock and the Start menu. */
    public static boolean available(int icon) {
        if (icon == RETIRED_ICON) return false;                   // an app that was removed (its number stays unused)
        if (Retro.safe()) return Retro.safeAllows(icon);          // Safe Mode: only a few plain apps
        if (Items.isFolder(icon)) return Folders.exists(icon);
        if (Items.isGame(icon)) return installed(Items.gameId(icon));     // a game is an app of its own once it is installed
        if (icon < 2) return false;                               // the old own-game icon and Games folder are gone
        Program p = programByIcon(icon);
        return p == null || installed(p.id());
    }

    // ---------- games and apps alike ----------
    public static int priceOf(String id) { Program p = program(id); return p != null ? p.price() : game(id).price(); }

    public static int sizeOf(String id) { Program p = program(id); return p != null ? p.sizeMb() : game(id).sizeMb(); }

    public static int ratingOf(String id) { Program p = program(id); return p != null ? p.rating() : game(id).rating(); }

    public static String genreOf(String id) { Program p = program(id); return p != null ? p.genre() : game(id).genre(); }

    /** The game on sale today (the same for everybody, changes every day). */
    public static String dealId() {
        if (Halloween.active()) {                       // the event: a horror game is on sale every day
            String[] horror = {"horror", "maze", "zombies", "otherworld"};
            return horror[(int) Math.floorMod(System.currentTimeMillis() / 86_400_000L, 4L)];
        }
        long day = System.currentTimeMillis() / 86_400_000L;
        return GAMES.get((int) Math.floorMod(day * 7 + 3, (long) GAMES.size())).id();
    }

    /** The discount of the game of the day (bigger during the Halloween event). */
    public static int dealPercent() { return Halloween.active() ? 50 : DEAL_PERCENT; }

    public static int priceNow(String id) {
        if (isProgram(id)) return program(id).price();         // no sales for apps
        int p = game(id).price();
        return id.equals(dealId()) ? Math.max(1, p * (100 - dealPercent()) / 100) : p;
    }

    /** How long the "download" takes. */
    private static long durationMs(String id) {
        return isProgram(id) ? 2500L + sizeOf(id) * 120L : 5000L + sizeOf(id) * 130L;
    }

    // ---------- state ----------
    public static boolean owned(String id) { ensure(); return owned.contains(id); }

    /** True if the app was uninstalled but is still owned (it can be installed again for free). */
    public static boolean uninstalled(String id) { ensure(); return owned.contains(id) && removed.contains(id); }

    /** 0..1 while installing, 1 when installed, -1 if not installed (not owned, or an app that was removed). */
    public static float progress(String id) {
        ensure();
        if (!owned.contains(id) || removed.contains(id)) return -1;
        Long start = installStart.get(id);
        if (start == null) return 1;
        return Math.max(0f, Math.min(1f, (System.currentTimeMillis() - start) / (float) durationMs(id)));
    }

    public static boolean installed(String id) { return progress(id) >= 1f; }

    public static int secondsLeft(String id) {
        Long start = installStart.get(id);
        if (start == null) return 0;
        return (int) Math.max(0, Math.ceil((durationMs(id) - (System.currentTimeMillis() - start)) / 1000.0));
    }

    /** How many games the player owns (apps are not counted). */
    public static int ownedCount() {
        ensure();
        int n = 0;
        for (Game g : GAMES) if (owned.contains(g.id())) n++;
        return n;
    }

    /** Buys a game or an app (free apps cost nothing) and starts installing it. Returns false if there are not enough coins. */
    public static boolean buy(String id) {
        ensure();
        if (owned.contains(id)) return false;
        int price = priceNow(id);
        if (price > 0 && !Progress.spend(price)) return false;
        owned.add(id);
        removed.remove(id);
        installStart.put(id, System.currentTimeMillis());
        Progress.toast(isProgram(id) ? "cutemod.toast.app_installing" : "cutemod.toast.store_bought", name(id));
        dirty = true;
        save();
        return true;
    }

    /** Installs an app that was removed earlier (free). */
    public static boolean install(String id) {
        ensure();
        if (!owned.contains(id) || !removed.contains(id)) return false;
        removed.remove(id);
        notified.remove(id);
        installStart.put(id, System.currentTimeMillis());
        Progress.toast("cutemod.toast.app_installing", name(id));
        dirty = true;
        save();
        return true;
    }

    /** Removes an app: it disappears from the Dock and the Start menu, the purchase stays. */
    public static boolean uninstall(String id) {
        ensure();
        Program p = program(id);
        if (p == null || !owned.contains(id) || removed.contains(id)) return false;
        removed.add(id);
        installStart.remove(id);
        notified.remove(id);
        DockLayout.unpin(p.icon());
        Progress.toast("cutemod.toast.app_removed", name(id));
        dirty = true;
        save();
        return true;
    }

    /** Gives a game for free (event rewards) and starts installing it. */
    public static void grant(String id) {
        ensure();
        if (owned.contains(id)) return;
        owned.add(id);
        installStart.put(id, System.currentTimeMillis());
        Progress.toast("cutemod.toast.store_bought", name(id));
        dirty = true;
        save();
    }

    // ---------- reviews ----------
    /** Every game and app has 3 to 5 reviews from "other players" (the texts are cutemod.store.rev.<id>.<n> in the lang files). */
    public static int reviewCount(String id) { return 3 + Math.floorMod(id.hashCode(), 3); }
    private static final String[] NAMES = {"CreeperFan", "BeeKeeper42", "SleepyPanda", "IceCube", "FoxyLady", "EnderBoy",
            "PixelCat", "MossyStone", "NightOwl", "Cookie_Monster", "DiamondDigger", "Zzz_Zed"};

    public static String npcAuthor(String id, int n) { return NAMES[Math.floorMod(id.hashCode() * 31 + n * 7 + 5, NAMES.length)]; }

    public static int npcStars(String id, int n) {
        int base = Math.round(ratingOf(id) / 10f);
        int d = n == 0 ? 0 : Math.floorMod(id.hashCode() + n * 13, 3) - 1;
        return Math.max(1, Math.min(5, base + d));
    }

    /** The player's own review: 0 stars = none yet. */
    public static int reviewStars(String id) { ensure(); return reviewStars.getOrDefault(id, 0); }

    public static String reviewText(String id) { ensure(); return reviewText.getOrDefault(id, ""); }

    /** Saves the review. Returns true if it is the first review for this game. */
    public static boolean setReview(String id, int stars, String text) {
        ensure();
        boolean first = !reviewStars.containsKey(id);
        reviewStars.put(id, Math.max(1, Math.min(5, stars)));
        reviewText.put(id, text == null ? "" : text);
        dirty = true;
        save();
        return first;
    }

    // ---------- play statistics ----------
    public static int playSeconds(String id) { ensure(); return playSeconds.getOrDefault(id, 0); }

    public static int best(String id) { ensure(); return best.getOrDefault(id, 0); }

    public static void addPlaySecond(String id) {
        ensure();
        playSeconds.merge(id, 1, Integer::sum);
        dirty = true;
    }

    public static void recordScore(String id, int score) {
        ensure();
        if (score > best.getOrDefault(id, 0)) { best.put(id, score); dirty = true; }
    }

    public static String playTime(String id) {
        int s = playSeconds(id), h = s / 3600, m = (s % 3600) / 60;
        return h > 0 ? h + "h " + m + "m" : m > 0 ? m + " min" : s + " s";
    }

    // ---------- save / load ----------
    private static int gen = -1;

    private static void ensure() {
        if (loaded && gen == Store.gen()) return;
        loaded = true;
        gen = Store.gen();
        dirty = false;
        owned.clear(); notified.clear(); removed.clear(); installStart.clear(); playSeconds.clear();
        best.clear(); reviewStars.clear(); reviewText.clear();
        try {
            Properties pr = Store.readProps("library");
            if (pr != null) {
                fill(owned, pr.getProperty("own"));
                fill(notified, pr.getProperty("notified"));
                fill(removed, pr.getProperty("removed"));
                owned.removeIf(id -> !known(id)); notified.removeIf(id -> !known(id)); removed.removeIf(id -> !known(id));
                for (String k : pr.stringPropertyNames()) {
                    try {
                        if (k.startsWith("start.")) installStart.put(k.substring(6), Long.parseLong(pr.getProperty(k).trim()));
                        else if (k.startsWith("play.")) playSeconds.put(k.substring(5), Integer.parseInt(pr.getProperty(k).trim()));
                        else if (k.startsWith("best.")) best.put(k.substring(5), Integer.parseInt(pr.getProperty(k).trim()));
                        else if (k.startsWith("rs.")) reviewStars.put(k.substring(3), Integer.parseInt(pr.getProperty(k).trim()));
                        else if (k.startsWith("rt.")) reviewText.put(k.substring(3), pr.getProperty(k));
                    } catch (NumberFormatException ignored) {
                    }
                }
                // a save from before the app store: the player already had the apps, so keep them installed
                if (Store.ready() && pr.getProperty("apps") == null && !owned.isEmpty()) {
                    for (Program p : PROGRAMS) { owned.add(p.id()); notified.add(p.id()); }
                    dirty = true;
                }
            }
        } catch (Exception ignored) {
        }
    }

    private static void fill(Set<String> set, String csv) {
        if (csv == null || csv.isBlank()) return;
        for (String s : csv.split(",")) if (!s.isBlank()) set.add(s.trim());
    }

    /** Saved on the server (through {@link Store}). */
    public static void save() {
        if (!loaded || gen != Store.gen()) return;
        try {
            Properties pr = new Properties();
            pr.setProperty("own", String.join(",", owned));
            pr.setProperty("notified", String.join(",", notified));
            pr.setProperty("removed", String.join(",", removed));
            pr.setProperty("apps", "1");
            installStart.forEach((k, v) -> pr.setProperty("start." + k, Long.toString(v)));
            playSeconds.forEach((k, v) -> pr.setProperty("play." + k, Integer.toString(v)));
            best.forEach((k, v) -> pr.setProperty("best." + k, Integer.toString(v)));
            reviewStars.forEach((k, v) -> pr.setProperty("rs." + k, Integer.toString(v)));
            reviewText.forEach((k, v) -> pr.setProperty("rt." + k, v));
            Store.writeProps("library", pr);
            dirty = false;
        } catch (Exception ignored) {
        }
    }

    /** Called 60 times per second by the computer screen: finishes installs and saves now and then. */
    public static void tick() {
        ensure();
        if (++saveDelay % 30 == 0) {
            for (String id : owned) {
                if (!notified.contains(id) && installed(id)) {
                    notified.add(id);
                    Progress.toast("cutemod.toast.store_installed", name(id));
                    Program prog = program(id);
                    if (prog != null) DockLayout.pin(prog.icon());     // a new app shows up in the Dock
                    dirty = true;
                }
            }
        }
        if (dirty && saveDelay > 600) { saveDelay = 0; save(); }
    }
}
