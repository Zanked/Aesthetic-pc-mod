package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/** Little cover pictures for the store, drawn with rectangles. Everything is in fractions of the size. */
public final class CoverArt {
    private CoverArt() {}

    private static void r(GuiGraphics g, int x, int y, int s, double fx, double fy, double fw, double fh, int argb) {
        int x0 = x + (int) Math.round(fx * s), y0 = y + (int) Math.round(fy * s);
        int x1 = x + (int) Math.round((fx + fw) * s), y1 = y + (int) Math.round((fy + fh) * s);
        g.fill(x0, y0, Math.max(x0 + 1, x1), Math.max(y0 + 1, y1), argb);
    }

    private static void d(GuiGraphics g, int x, int y, int s, double cx, double cy, double rad, int argb) {
        int px = x + (int) Math.round(cx * s), py = y + (int) Math.round(cy * s), rr = Math.max(1, (int) Math.round(rad * s));
        for (int dy = -rr; dy <= rr; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rr * rr - dy * dy + 0.25));
            g.fill(px - dx, py + dy, px + dx + 1, py + dy + 1, argb);
        }
    }

    private static int mix(int a, int b, double f) {
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int gr = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }

    /** Games whose cover is dark (the tile of the game gets dark too). */
    public static boolean isDark(String id) {
        return id.equals("horror") || id.equals("maze") || id.equals("otherworld") || id.equals("purple") || id.equals("bees") || id.equals("zombies");
    }

    /** A square cover: the background and the picture. */
    public static void draw(GuiGraphics g, String id, int x, int y, int s) {
        int base = 0xFF000000 | Library.game(id).rgb();
        boolean dark = isDark(id);
        g.fillGradient(x, y, x + s, y + s, dark ? mix(base, 0x000000, 0.6) : mix(base, 0xFFFFFF, 0.35), dark ? mix(base, 0x000000, 0.85) : base);
        glyph(g, id, x, y, s);
        g.fill(x, y, x + s, y + 1, 0x55FFFFFF);
    }

    /** Only the picture of the game, without a background (an app icon draws it on its own rounded tile). */
    public static void glyph(GuiGraphics g, String id, int x, int y, int s) {
        int base = 0xFF000000 | Library.game(id).rgb();
        switch (id) {
            case "pink" -> {
                r(g, x, y, s, 0.78, 0, 0.16, 0.35, 0xFF4E9F5E); r(g, x, y, s, 0.78, 0.68, 0.16, 0.32, 0xFF4E9F5E);
                r(g, x, y, s, 0.2, 0.38, 0.42, 0.34, 0xFFF58FB8); r(g, x, y, s, 0.2, 0.28, 0.1, 0.1, 0xFFF58FB8);
                r(g, x, y, s, 0.52, 0.28, 0.1, 0.1, 0xFFF58FB8); r(g, x, y, s, 0.3, 0.48, 0.06, 0.06, 0xFF3A2A3A);
                r(g, x, y, s, 0.46, 0.48, 0.06, 0.06, 0xFF3A2A3A);
            }
            case "green" -> {
                r(g, x, y, s, 0.18, 0.18, 0.64, 0.64, 0xFF5BBF4A);
                r(g, x, y, s, 0.26, 0.3, 0.15, 0.15, 0xFF16301A); r(g, x, y, s, 0.59, 0.3, 0.15, 0.15, 0xFF16301A);
                r(g, x, y, s, 0.42, 0.46, 0.16, 0.2, 0xFF16301A); r(g, x, y, s, 0.34, 0.58, 0.12, 0.18, 0xFF16301A);
                r(g, x, y, s, 0.54, 0.58, 0.12, 0.18, 0xFF16301A);
            }
            case "white" -> {
                d(g, x, y, s, 0.25, 0.25, 0.12, 0xFF25252D); d(g, x, y, s, 0.75, 0.25, 0.12, 0xFF25252D);
                d(g, x, y, s, 0.5, 0.52, 0.32, 0xFFFFFFFF);
                d(g, x, y, s, 0.36, 0.48, 0.09, 0xFF25252D); d(g, x, y, s, 0.64, 0.48, 0.09, 0xFF25252D);
                d(g, x, y, s, 0.36, 0.47, 0.03, 0xFFFFFFFF); d(g, x, y, s, 0.64, 0.47, 0.03, 0xFFFFFFFF);
                r(g, x, y, s, 0.44, 0.6, 0.12, 0.07, 0xFF25252D);
            }
            case "blue" -> {
                d(g, x, y, s, 0.5, 0.52, 0.34, 0xFF2C4D94); d(g, x, y, s, 0.5, 0.6, 0.22, 0xFFFFFFFF);
                d(g, x, y, s, 0.4, 0.45, 0.05, 0xFF14213F); d(g, x, y, s, 0.6, 0.45, 0.05, 0xFF14213F);
                r(g, x, y, s, 0.44, 0.52, 0.12, 0.08, 0xFFFF9A1F);
            }
            case "orange" -> {
                r(g, x, y, s, 0.14, 0.14, 0.2, 0.28, 0xFFEE7F1C); r(g, x, y, s, 0.66, 0.14, 0.2, 0.28, 0xFFEE7F1C);
                d(g, x, y, s, 0.5, 0.56, 0.34, 0xFFF58B25); r(g, x, y, s, 0.2, 0.62, 0.6, 0.22, 0xFFFFF5E6);
                r(g, x, y, s, 0.3, 0.46, 0.08, 0.12, 0xFF2A1A12); r(g, x, y, s, 0.62, 0.46, 0.08, 0.12, 0xFF2A1A12);
                r(g, x, y, s, 0.45, 0.66, 0.1, 0.07, 0xFF2A1A12);
            }
            case "purple" -> {
                r(g, x, y, s, 0.2, 0.2, 0.6, 0.55, 0xFF17111F);
                r(g, x, y, s, 0.26, 0.44, 0.18, 0.1, 0xFFE45CFF); r(g, x, y, s, 0.56, 0.44, 0.18, 0.1, 0xFFE45CFF);
                r(g, x, y, s, 0.1, 0.3, 0.04, 0.04, 0xFFC26BFF); r(g, x, y, s, 0.88, 0.62, 0.04, 0.04, 0xFFC26BFF);
            }
            case "yellow" -> {
                d(g, x, y, s, 0.5, 0.55, 0.3, 0xFFFFCF2E); r(g, x, y, s, 0.26, 0.42, 0.48, 0.06, 0xFF3A2A1A);
                r(g, x, y, s, 0.22, 0.58, 0.56, 0.06, 0xFF3A2A1A);
                d(g, x, y, s, 0.32, 0.22, 0.1, 0xFFEAF8FF); d(g, x, y, s, 0.68, 0.22, 0.1, 0xFFEAF8FF);
                r(g, x, y, s, 0.4, 0.5, 0.05, 0.06, 0xFF2A1D10); r(g, x, y, s, 0.55, 0.5, 0.05, 0.06, 0xFF2A1D10);
            }
            case "red" -> {
                d(g, x, y, s, 0.5, 0.6, 0.32, 0xFFE2392F); r(g, x, y, s, 0.48, 0.3, 0.04, 0.6, 0xFF2A1414);
                d(g, x, y, s, 0.5, 0.28, 0.16, 0xFF2A1B1B);
                d(g, x, y, s, 0.34, 0.6, 0.06, 0xFF2A1414); d(g, x, y, s, 0.66, 0.6, 0.06, 0xFF2A1414);
                d(g, x, y, s, 0.4, 0.78, 0.05, 0xFF2A1414); d(g, x, y, s, 0.6, 0.78, 0.05, 0xFF2A1414);
            }
            case "breakout" -> {
                for (int i = 0; i < 4; i++) r(g, x, y, s, 0.1 + i * 0.2, 0.12, 0.17, 0.1, i % 2 == 0 ? 0xFFE0594F : 0xFFF2C94C);
                d(g, x, y, s, 0.5, 0.5, 0.16, 0xFFE8B66A); d(g, x, y, s, 0.45, 0.46, 0.03, 0xFF4A2A14); d(g, x, y, s, 0.55, 0.53, 0.03, 0xFF4A2A14);
                r(g, x, y, s, 0.3, 0.86, 0.4, 0.06, 0xFFFFFFFF);
            }
            case "cubes" -> {
                r(g, x, y, s, 0.14, 0.14, 0.34, 0.34, 0xFFF2C94C); r(g, x, y, s, 0.52, 0.14, 0.34, 0.34, 0xFFE0594F);
                r(g, x, y, s, 0.14, 0.52, 0.34, 0.34, 0xFF52C45A); r(g, x, y, s, 0.52, 0.52, 0.34, 0.34, 0xFF4A8FE0);
            }
            case "racer" -> {
                r(g, x, y, s, 0.28, 0, 0.44, 1, 0xFF4A4A5E); r(g, x, y, s, 0.26, 0, 0.03, 1, 0xFFFFFFFF); r(g, x, y, s, 0.71, 0, 0.03, 1, 0xFFFFFFFF);
                r(g, x, y, s, 0.49, 0.1, 0.02, 0.14, 0xFFF3C45A); r(g, x, y, s, 0.49, 0.38, 0.02, 0.14, 0xFFF3C45A); r(g, x, y, s, 0.49, 0.66, 0.02, 0.14, 0xFFF3C45A);
                r(g, x, y, s, 0.36, 0.5, 0.28, 0.4, 0xFFF58FB8); r(g, x, y, s, 0.41, 0.56, 0.18, 0.12, 0xFFBFE8FF);
                r(g, x, y, s, 0.37, 0.46, 0.07, 0.07, 0xFFF58FB8); r(g, x, y, s, 0.56, 0.46, 0.07, 0.07, 0xFFF58FB8);
                d(g, x, y, s, 0.6, 0.22, 0.06, 0xFFFFD84A);
            }
            case "pong" -> {
                d(g, x, y, s, 0.5, 0.9, 0.3, 0xFF7ED957); r(g, x, y, s, 0, 0.9, 1, 0.1, mix(base, 0x000000, 0.4));
                d(g, x, y, s, 0.4, 0.78, 0.04, 0xFF16301A); d(g, x, y, s, 0.6, 0.78, 0.04, 0xFF16301A);
                d(g, x, y, s, 0.7, 0.3, 0.07, 0xFFFFFFFF);
            }
            case "bees" -> {
                for (int i = 0; i < 3; i++) { d(g, x, y, s, 0.25 + i * 0.25, 0.28, 0.08, 0xFFFFCF2E); r(g, x, y, s, 0.2 + i * 0.25, 0.26, 0.1, 0.03, 0xFF3A2A1A); }
                r(g, x, y, s, 0.44, 0.78, 0.12, 0.12, 0xFF7ED957); r(g, x, y, s, 0.49, 0.66, 0.02, 0.12, 0xFFFFFFFF);
            }
            case "horror" -> {
                r(g, x, y, s, 0.44, 0.45, 0.12, 0.4, 0xFFF2EBDD); r(g, x, y, s, 0.47, 0.3, 0.06, 0.15, 0xFFFFD84A);
                d(g, x, y, s, 0.5, 0.36, 0.2, 0x33FFD84A);
                r(g, x, y, s, 0.12, 0.2, 0.08, 0.04, 0xFFFF2A2A); r(g, x, y, s, 0.8, 0.2, 0.08, 0.04, 0xFFFF2A2A);
            }
            case "maze" -> {
                r(g, x, y, s, 0.1, 0.1, 0.8, 0.8, 0xFF2A2230); r(g, x, y, s, 0.22, 0.22, 0.56, 0.56, 0xFF14101A);
                r(g, x, y, s, 0.34, 0.34, 0.32, 0.32, 0xFF0A080D);
                r(g, x, y, s, 0.43, 0.4, 0.14, 0.2, 0xFFE8E4EC); r(g, x, y, s, 0.46, 0.46, 0.03, 0.03, 0xFFFF2A2A); r(g, x, y, s, 0.52, 0.46, 0.03, 0.03, 0xFFFF2A2A);
            }
            case "otherworld" -> {       // a red corridor with a seal glowing at the end
                r(g, x, y, s, 0.08, 0.1, 0.84, 0.8, 0xFF4A0A12); r(g, x, y, s, 0.2, 0.2, 0.6, 0.6, 0xFF2A0509);
                r(g, x, y, s, 0.32, 0.32, 0.36, 0.36, 0xFF12020A);
                for (int i = 0; i < 4; i++) r(g, x, y, s, 0.08 + i * 0.04, 0.12 + i * 0.1, 0.02, 0.06, 0xFFB01822);
                d(g, x, y, s, 0.5, 0.5, 0.14, 0x55FF2A3A); d(g, x, y, s, 0.5, 0.5, 0.08, 0xFFFF2A3A); d(g, x, y, s, 0.5, 0.5, 0.045, 0xFF12020A);
                r(g, x, y, s, 0.48, 0.4, 0.04, 0.2, 0xFFFF9AA0); r(g, x, y, s, 0.4, 0.48, 0.2, 0.04, 0xFFFF9AA0);
            }
            case "craft" -> {
                r(g, x, y, s, 0, 0, 1, 0.5, 0xFF8ED0FF);
                r(g, x, y, s, 0.2, 0.4, 0.6, 0.15, 0xFF5BBF4A); r(g, x, y, s, 0.2, 0.55, 0.6, 0.35, 0xFF8A5A3A);
                r(g, x, y, s, 0.3, 0.65, 0.1, 0.1, 0xFF5A3A22); r(g, x, y, s, 0.55, 0.72, 0.1, 0.1, 0xFF5A3A22);
                d(g, x, y, s, 0.8, 0.15, 0.08, 0xFFFFE066);
            }
            case "zombies" -> {
                r(g, x, y, s, 0.22, 0.2, 0.56, 0.56, 0xFF5FA84A); r(g, x, y, s, 0.22, 0.2, 0.56, 0.12, 0xFF3F7F34);
                r(g, x, y, s, 0.3, 0.42, 0.12, 0.1, 0xFFFF3030); r(g, x, y, s, 0.58, 0.42, 0.12, 0.1, 0xFFFF3030);
                r(g, x, y, s, 0.4, 0.62, 0.2, 0.06, 0xFF16301A);
                r(g, x, y, s, 0.1, 0.5, 0.12, 0.02, 0xFFFFFFFF); r(g, x, y, s, 0.78, 0.5, 0.12, 0.02, 0xFFFFFFFF);
                r(g, x, y, s, 0.5, 0.1, 0.02, 0.1, 0xFFFFFFFF); r(g, x, y, s, 0.5, 0.8, 0.02, 0.1, 0xFFFFFFFF);
            }
            case "durak" -> {
                r(g, x, y, s, 0.14, 0.26, 0.34, 0.5, 0xFFFAF6EC); r(g, x, y, s, 0.5, 0.2, 0.34, 0.5, 0xFFFAF6EC);
                r(g, x, y, s, 0.2, 0.34, 0.1, 0.1, 0xFF2A2A3A); r(g, x, y, s, 0.56, 0.28, 0.1, 0.1, 0xFFD83A4A);
                d(g, x, y, s, 0.67, 0.5, 0.08, 0xFFD83A4A); d(g, x, y, s, 0.31, 0.58, 0.07, 0xFF2A2A3A);
            }
            case "sakura" -> {
                d(g, x, y, s, 0.5, 0.42, 0.3, 0xFFFFB6D2); d(g, x, y, s, 0.5, 0.42, 0.2, 0xFFF58FB8);
                r(g, x, y, s, 0.49, 0.42, 0.03, 0.4, 0xFF9A6A4A);
                r(g, x, y, s, 0.14, 0.2, 0.08, 0.06, 0xFFFFFFFF); r(g, x, y, s, 0.8, 0.6, 0.08, 0.06, 0xFFFFFFFF);
                r(g, x, y, s, 0.7, 0.14, 0.06, 0.06, 0xFFFFFFFF);
            }
            case "blocks" -> {
                r(g, x, y, s, 0.2, 0.2, 0.2, 0.2, 0xFFF3D46A); r(g, x, y, s, 0.4, 0.2, 0.2, 0.2, 0xFFF3D46A);
                r(g, x, y, s, 0.2, 0.4, 0.2, 0.2, 0xFFF3D46A); r(g, x, y, s, 0.4, 0.4, 0.2, 0.2, 0xFFF3D46A);
                r(g, x, y, s, 0.2, 0.6, 0.2, 0.2, 0xFFE27B72); r(g, x, y, s, 0.4, 0.6, 0.2, 0.2, 0xFFE27B72);
                r(g, x, y, s, 0.6, 0.6, 0.2, 0.2, 0xFFE27B72); r(g, x, y, s, 0.6, 0.4, 0.2, 0.2, 0xFF8FD39A);
            }
            case "cakes" -> {
                r(g, x, y, s, 0.1, 0.72, 0.8, 0.07, 0xFFFFFFFF);
                r(g, x, y, s, 0.2, 0.46, 0.6, 0.26, 0xFF7A4A2A);
                r(g, x, y, s, 0.16, 0.38, 0.68, 0.12, 0xFFFFFFFF);
                r(g, x, y, s, 0.24, 0.48, 0.07, 0.1, 0xFFFFFFFF); r(g, x, y, s, 0.66, 0.48, 0.07, 0.12, 0xFFFFFFFF);
                d(g, x, y, s, 0.5, 0.3, 0.075, 0xFFE5484D);
                r(g, x, y, s, 0.5, 0.14, 0.02, 0.1, 0xFF2A7A3A);
            }
            case "cakefactory" -> {
                r(g, x, y, s, 0.04, 0.74, 0.92, 0.1, 0xFF4A4A5A);
                r(g, x, y, s, 0.1, 0.78, 0.06, 0.02, 0xFF8A8A9A); r(g, x, y, s, 0.4, 0.78, 0.06, 0.02, 0xFF8A8A9A); r(g, x, y, s, 0.7, 0.78, 0.06, 0.02, 0xFF8A8A9A);
                r(g, x, y, s, 0.26, 0.52, 0.48, 0.22, 0xFF7A4A2A);
                r(g, x, y, s, 0.3, 0.34, 0.4, 0.18, 0xFFF3E3B0);
                r(g, x, y, s, 0.24, 0.44, 0.52, 0.1, 0xFFF58FB8);
                d(g, x, y, s, 0.5, 0.28, 0.07, 0xFFE5484D);
            }
            case "checkers" -> {   // a board corner with a white and a black piece, the white one crowned
                for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++)
                    r(g, x, y, s, 0.1 + i * 0.2, 0.1 + j * 0.2, 0.2, 0.2, (i + j) % 2 == 0 ? 0xFFFFF0F6 : 0xFF8A4A78);
                d(g, x, y, s, 0.3, 0.7, 0.085, 0xFFFFFFFF);
                d(g, x, y, s, 0.3, 0.7, 0.06, 0xFFE8D0DC);
                r(g, x, y, s, 0.27, 0.68, 0.06, 0.03, 0xFFFFD84A);
                d(g, x, y, s, 0.7, 0.3, 0.085, 0xFF2A1840);
                d(g, x, y, s, 0.7, 0.3, 0.06, 0xFF4A2A66);
            }
            case "slice" -> {   // a melon cut in two, with a white slash across it
                d(g, x, y, s, 0.5, 0.52, 0.3, 0xFF2E8B3A);
                d(g, x, y, s, 0.5, 0.52, 0.24, 0xFFE8475A);
                r(g, x, y, s, 0.4, 0.42, 0.03, 0.05, 0xFF2A2433); r(g, x, y, s, 0.56, 0.5, 0.03, 0.05, 0xFF2A2433); r(g, x, y, s, 0.46, 0.62, 0.03, 0.05, 0xFF2A2433);
                for (int i = 0; i < 12; i++) r(g, x, y, s, 0.12 + i * 0.065, 0.8 - i * 0.055, 0.07, 0.035, 0xFFFFFFFF);
            }
            case "rabbit" -> {  // a rabbit on the grass, a road behind it
                r(g, x, y, s, 0, 0, 1, 0.45, 0xFF4A4A5E);
                r(g, x, y, s, 0.08, 0.21, 0.16, 0.03, 0xFFFFFFFF); r(g, x, y, s, 0.42, 0.21, 0.16, 0.03, 0xFFFFFFFF); r(g, x, y, s, 0.76, 0.21, 0.16, 0.03, 0xFFFFFFFF);
                r(g, x, y, s, 0, 0.45, 1, 0.55, 0xFF8ED36A);
                r(g, x, y, s, 0.36, 0.3, 0.06, 0.26, 0xFFFFFFFF); r(g, x, y, s, 0.58, 0.3, 0.06, 0.26, 0xFFFFFFFF);
                r(g, x, y, s, 0.32, 0.52, 0.36, 0.22, 0xFFFFFFFF); r(g, x, y, s, 0.42, 0.6, 0.04, 0.04, 0xFF2A2433); r(g, x, y, s, 0.55, 0.6, 0.04, 0.04, 0xFF2A2433);
                r(g, x, y, s, 0.3, 0.74, 0.4, 0.16, 0xFFF4EAF0);
            }
            case "dash" -> {    // a track running away to the horizon, a cart on the left, the kitty from behind
                r(g, x, y, s, 0, 0, 1, 0.38, 0xFFFFD6E6); r(g, x, y, s, 0, 0.38, 1, 0.62, 0xFF98D893);
                for (int i = 0; i < 12; i++) {
                    double f = 0.38 + i * 0.052, hw = 0.05 + i * 0.037;
                    r(g, x, y, s, 0.5 - hw, f, hw * 2, 0.055, i % 2 == 0 ? 0xFF6E6C8A : 0xFF67657F);
                }
                r(g, x, y, s, 0.26, 0.5, 0.15, 0.2, 0xFF5BA8F0); r(g, x, y, s, 0.285, 0.54, 0.045, 0.06, 0xFFBFE8FF); r(g, x, y, s, 0.34, 0.54, 0.045, 0.06, 0xFFBFE8FF);
                d(g, x, y, s, 0.72, 0.52, 0.035, 0xFFFFD84A); d(g, x, y, s, 0.72, 0.64, 0.045, 0xFFFFD84A);
                r(g, x, y, s, 0.4, 0.6, 0.2, 0.2, 0xFFB57BD6); r(g, x, y, s, 0.39, 0.4, 0.22, 0.2, 0xFFF58FB8);
                r(g, x, y, s, 0.39, 0.34, 0.06, 0.08, 0xFFF58FB8); r(g, x, y, s, 0.55, 0.34, 0.06, 0.08, 0xFFF58FB8);
                r(g, x, y, s, 0.42, 0.78, 0.06, 0.12, 0xFFD9648F); r(g, x, y, s, 0.52, 0.78, 0.06, 0.12, 0xFFD9648F);
            }
            default -> d(g, x, y, s, 0.5, 0.5, 0.25, 0xFFFFFFFF);
        }
    }
}
