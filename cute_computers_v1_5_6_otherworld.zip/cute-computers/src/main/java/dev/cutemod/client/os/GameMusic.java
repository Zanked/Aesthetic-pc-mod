package dev.cutemod.client.os;

import dev.cutemod.CuteMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

/**
 * The music of the mini games: every game has its own short loop (assets/cutemod/sounds/music/&lt;game id&gt;.ogg,
 * made by tools/make_music.py). The music plays while a game is on screen, fades in and out, gets quieter on
 * "Game over" and pauses the vanilla music meanwhile. It follows the "Music" volume slider of Minecraft and the
 * "Music" switch in the computer's Settings.
 *
 * GameApp calls {@link #keep} on every tick. If the calls stop (the game is minimized, closed or the computer is
 * left) the track fades out by itself, so nothing else has to be tracked.
 */
public final class GameMusic {
    private GameMusic() {}

    private static final float LEVEL = 0.8F;      // while playing
    private static final float OVER_LEVEL = 0.25F; // on the "Game over" box
    private static final java.util.Set<String> DARK = java.util.Set.of("horror", "maze", "otherworld", "zombies", "purple");
    private static final java.util.Set<String> TENSE = java.util.Set.of("horror", "maze", "otherworld", "zombies", "purple", "bees", "yellow", "pong", "green", "racer");

    /** Dark games: horror, zombies... (they get a heartbeat on Game over instead of a bell). */
    public static boolean dark(String id) { return DARK.contains(id); }

    private static Track current;

    /** The game with this id is running right now: start (or keep) its music. */
    /** For screens that are not games (the talent show stage...): no rising tension. */
    public static void keep(String id, boolean over) { keep(id, over, 0); }

    public static void keep(String id, boolean over, int roundTicks) {
        if (!Sfx.music() || Sfx.musicVol() <= 0F) { stop(); return; }
        if (current != null && current.isStopped()) current = null;
        if (current != null && !current.id.equals(id)) { current.fadeOut(); current = null; }
        if (current == null) {
            current = new Track(id);
            Minecraft mc = Minecraft.getInstance();
            mc.getSoundManager().play(current);
            mc.getMusicManager().stopPlaying();
        }
        // the longer a round lasts the faster the track gets (up to +10% in tense games, +3% in calm ones, after 2 minutes);
        // on Game over it slows down
        float max = TENSE.contains(id) ? 0.10F : 0.03F;
        current.alive(over, over ? 0.92F : 1.0F + max * Math.min(1.0F, roundTicks / 7200.0F));
    }

    /** Fade the music out (the game was closed). */
    public static void stop() {
        if (current != null) current.fadeOut();
        current = null;
    }

    private static final class Track extends AbstractTickableSoundInstance {
        final String id;
        private float goal = LEVEL;
        private float base = LEVEL;
        private float pitchGoal = 1.0F;
        private int idle;
        private int duck;
        private boolean out;

        Track(String id) {
            super(SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "music." + id)),
                    SoundSource.MUSIC, RandomSource.create());
            this.id = id;
            this.looping = true;                 // not streamed, so OpenAL loops it without a gap
            this.delay = 0;
            this.volume = 0.01F;                 // a sound that starts at exactly 0 is skipped
            this.relative = true;
            this.attenuation = SoundInstance.Attenuation.NONE;
        }

        void alive(boolean over, float pitch) {
            idle = 0;
            base = over ? OVER_LEVEL : LEVEL;
            pitchGoal = pitch;
        }

        void fadeOut() { out = true; }

        @Override
        public void tick() {
            goal = (out || ++idle > 10 || !Sfx.music()) ? 0 : base * Sfx.musicVol();   // the slider in Settings
            pitch += (pitchGoal - pitch) * 0.05F;
            float step = goal > volume ? 0.03F : 0.06F;
            volume = volume < goal ? Math.min(goal, volume + step) : Math.max(goal, volume - step);
            if (goal == 0 && volume <= 0.005F) { stop(); return; }
            // keep the vanilla music quiet while a game plays (its timer restarts every time)
            if (volume > 0.05F && duck++ % 60 == 0) Minecraft.getInstance().getMusicManager().stopPlaying();
        }
    }
}
