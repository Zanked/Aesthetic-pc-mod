package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * First-person horror in a crimson "otherworld": a rusty maze whose walls shimmer between red and black
 * (living flesh, a glowing iron grate, bloody iron plates). Find 3 seals, then reach the gate.
 * A faceless warden with a triangle head walks the corridors after you: it is slow, but it never stops.
 * Now and then a siren sounds and the whole world pulses. A simple game: no weapons, just walk.
 */
public class Otherworld extends MiniGame {
    private static final int N = 15, SEALS = 3;          // the maze is N x N tiles (walls included)
    private static final int COLS = 110, CW = W / COLS;  // one ray per 2 px
    private static final double PLANE = 0.75;            // field of view (bigger = wider)

    // tiny sprites: one char = one pixel (see pal())
    private static final String[] SEAL = {      // a ring with a cross: the seal
            "..rrrr..", ".r.pp.r.", "r..pp..r", "rppppppr", "r..pp..r", "r..pp..r", ".r.pp.r.", "..rrrr.."};
    private static final String[] GATE = {      // an iron gate: dark bars, and a glow in the gaps (brighter once it can be opened)
            "bbbbbb", "bgbbgb", "bgbbgb", "bgbbgb", "bbbbbb", "bgbbgb", "bgbbgb", "bgpbgb", "bgbbgb", "bbbbbb", "bgbbgb", "bgbbgb"};
    private static final String[] WARDEN = {
            "...kk...", "..kkkk..", "..kddk..", ".kkddkk.", ".kdrrdk.", "kkddddkk", "kkkkkkkk", "..kddk..",
            ".kkddkk.", "kkddddkk", "k.kddk.k", "k.kddk.k", "k.kkkk.k", "..kddk..", "..k..k..", "..k..k.."};
    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    private final int[][] map = new int[N][N];          // 1 = wall
    private final boolean[][] seen = new boolean[N][N]; // for the little map
    private final double[] zbuf = new double[COLS];     // wall distance per column (hides sprites behind walls)
    private final double[] sx = new double[SEALS], sy = new double[SEALS];
    private final boolean[] got = new boolean[SEALS];

    private double px, py, ang, ex, ey, tx, ty, light;
    private int ox, oy;                                 // where the warden last heard you
    private int seals, ticks, msgT;
    private boolean won, awake;
    private String msg = "";

    @Override
    public void reset() {
        score = 0; over = false; won = false; awake = false; ex = ey = tx = ty = -100; seals = 0; ticks = 0; msgT = 0; light = 1;
        Arrays.fill(got, false);
        for (boolean[] r : seen) Arrays.fill(r, false);
        build();
        px = 1.5; py = 1.5;
        ox = 1; oy = 1;
        ang = map[1][2] == 0 ? 0 : Math.PI / 2;
        say("cutemod.otherworld.start");
    }

    /** Random maze: carve corridors with a depth-first walk, then knock out a few walls to make loops. */
    private void build() {
        for (int[] r : map) Arrays.fill(r, 1);
        ArrayDeque<int[]> st = new ArrayDeque<>();
        map[1][1] = 0;
        st.push(new int[]{1, 1});
        while (!st.isEmpty()) {
            int[] c = st.peek();
            List<int[]> opts = new ArrayList<>();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0] * 2, ny = c[1] + d[1] * 2;
                if (nx > 0 && ny > 0 && nx < N - 1 && ny < N - 1 && map[ny][nx] == 1) opts.add(d);
            }
            if (opts.isEmpty()) { st.pop(); continue; }
            int[] d = opts.get(rnd.nextInt(opts.size()));
            map[c[1] + d[1]][c[0] + d[0]] = 0;
            map[c[1] + d[1] * 2][c[0] + d[0] * 2] = 0;
            st.push(new int[]{c[0] + d[0] * 2, c[1] + d[1] * 2});
        }
        for (int i = 0; i < 14; i++) {
            int x = 1 + rnd.nextInt(N - 2), y = 1 + rnd.nextInt(N - 2);
            if ((x + y) % 2 == 1) map[y][x] = 0;
        }
        // the seals lie in the middle of random tiles, far from the start
        List<int[]> cells = new ArrayList<>();
        for (int y = 1; y < N - 1; y += 2) for (int x = 1; x < N - 1; x += 2) {
            if (x + y >= 8 && !(x == N - 2 && y == N - 2)) cells.add(new int[]{x, y});
        }
        for (int i = 0; i < SEALS; i++) {
            int[] c = cells.remove(rnd.nextInt(cells.size()));
            sx[i] = c[0] + 0.5;
            sy[i] = c[1] + 0.5;
        }
    }

    /** After 10 seconds the warden wakes up, far away from you. */
    private void spawn() {
        List<int[]> far = new ArrayList<>();
        for (int y = 1; y < N - 1; y += 2) for (int x = 1; x < N - 1; x += 2) {
            if (Math.abs(x - (int) px) + Math.abs(y - (int) py) >= 10) far.add(new int[]{x, y});
        }
        int[] m = far.get(rnd.nextInt(far.size()));
        ex = tx = m[0] + 0.5;
        ey = ty = m[1] + 0.5;
        ox = (int) px;
        oy = (int) py;
        awake = true;
        say("cutemod.otherworld.wake");
        pling(0.5F);
    }

    private void say(String key) { msg = key; msgT = 150; }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private void move(double dx, double dy) {
        double r = 0.22;
        if (map[(int) py][(int) (px + dx + Math.signum(dx) * r)] == 0) px += dx;
        if (map[(int) (py + dy + Math.signum(dy) * r)][(int) px] == 0) py += dy;
    }

    /** 0 most of the time; every 40 seconds a siren sounds for 5 seconds and this swells to 1 and back. */
    private double siren() {
        int p = ticks % 2400;
        return p < 2100 ? 0 : Math.sin((p - 2100) / 300.0 * Math.PI);
    }

    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        double md = Math.hypot(ex - px, ey - py);
        light = ((md < 4 && ticks % 11 < 2) || ticks % 500 > 494) ? 0.4 : 1.0;   // the light flickers
        if (ticks % 2400 == 2100) pling(0.5F);                                     // the siren

        // walk: W/S or up/down, turn: A/D or left/right
        double turn = (down(68) || down(KEY_RIGHT) ? 1 : 0) - (down(65) || down(KEY_LEFT) ? 1 : 0);
        double walk = (down(87) || down(KEY_UP) ? 1 : 0) - (down(83) || down(KEY_DOWN) ? 1 : 0);
        ang += turn * 0.05;
        move(Math.cos(ang) * walk * 0.05, Math.sin(ang) * walk * 0.05);
        for (int dy = -2; dy <= 2; dy++) for (int dx = -2; dx <= 2; dx++) {   // little map: remember what we saw
            int cx = (int) px + dx, cy = (int) py + dy;
            if (cx >= 0 && cy >= 0 && cx < N && cy < N) seen[cy][cx] = true;
        }

        if (ticks % 120 == 0 || md < 3) { ox = (int) px; oy = (int) py; }   // it hears you every 2 s (always, when close)
        if (ticks == 600) spawn();
        if (awake) chase();
        md = Math.hypot(ex - px, ey - py);
        if (md < 0.55) { over = true; pling(0.5F); beep(); return; }
        if (md < 7 && ticks % (int) (14 + md * 6) == 0) pling(0.5F);        // heartbeat, faster when it is close

        for (int i = 0; i < SEALS; i++) {
            if (!got[i] && Math.hypot(sx[i] - px, sy[i] - py) < 0.5) {
                got[i] = true;
                seals++;
                score += 100;
                pling(1.8F);
                say("cutemod.otherworld.seal");
            }
        }
        if (Math.hypot(N - 1.5 - px, N - 1.5 - py) < 0.8) {
            if (seals == SEALS) {
                won = true;
                over = true;
                score += 500 + Math.max(0, 600 - ticks / 30);      // faster = more points
                pling(1.0F); pling(1.5F); pling(2.0F);
            } else if (msgT == 0) say("cutemod.otherworld.locked");
        }
    }

    // ---------- the warden: walks tile to tile along the shortest way to you ----------
    private void chase() {
        double sp = 0.013 + 0.0025 * seals + 0.004 * siren();       // slow (you walk 0.05); a little faster with every seal
        double dx = tx - ex, dy = ty - ey, d = Math.hypot(dx, dy);
        if (d <= sp) { ex = tx; ey = ty; next(); }
        else { ex += dx / d * sp; ey += dy / d * sp; }
    }

    private void next() {
        int cx = (int) ex, cy = (int) ey;
        if (cx == (int) px && cy == (int) py) { tx = px; ty = py; return; }   // right on top of you
        if (cx == ox && cy == oy) { tx = cx + 0.5; ty = cy + 0.5; return; }   // reached the last heard spot: waits there
        int[][] dist = new int[N][N];
        for (int[] r : dist) Arrays.fill(r, -1);
        ArrayDeque<int[]> q = new ArrayDeque<>();
        dist[oy][ox] = 0;
        q.add(new int[]{ox, oy});
        while (!q.isEmpty()) {                                     // distance from every tile to where it heard you
            int[] c = q.poll();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0], ny = c[1] + d[1];
                if (map[ny][nx] == 0 && dist[ny][nx] < 0) { dist[ny][nx] = dist[c[1]][c[0]] + 1; q.add(new int[]{nx, ny}); }
            }
        }
        int best = dist[cy][cx];
        tx = cx + 0.5;
        ty = cy + 0.5;
        for (int[] d : DIRS) {
            int nx = cx + d[0], ny = cy + d[1];
            if (map[ny][nx] == 0 && dist[ny][nx] >= 0 && dist[ny][nx] < best) { best = dist[ny][nx]; tx = nx + 0.5; ty = ny + 0.5; }
        }
    }

    // ---------- the crimson walls ----------
    private static int shade(int rgb, double b) {
        b = Math.max(0, Math.min(1.5, b));
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * b));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * b));
        int bl = Math.min(255, (int) ((rgb & 255) * b));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int mixc(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static double frac(double x) { return x - Math.floor(x); }

    /**
     * The color of one spot of a wall. u = along the wall (0-1), v = up the wall (0-1), t = seconds, ph = a number
     * that is different for every tile. Everything moves, so the walls never lie still: they shimmer between red and black.
     * Three kinds of wall: living flesh with glowing veins, a rusty grate with a red glow behind it, bloody iron plates.
     */
    private static int wall(int type, double u, double v, double t, double ph) {
        switch (type) {
            case 0 -> {                                              // flesh: slow waves, bright veins
                double n = Math.sin(u * 10 + Math.sin(v * 6 + t * 0.9) * 1.8 + t * 0.6 + ph)
                        + Math.sin(v * 8 - u * 3 - t * 1.2 + ph * 2) + Math.sin(u * 4 + v * 7 + t * 0.45);
                n = (n + 3) / 6;
                int c = mixc(0xFF060103, 0xFF9C1020, n * n * (3 - 2 * n));
                return n > 0.8 ? mixc(c, 0xFFFF4050, (n - 0.8) / 0.2 * 0.85) : c;
            }
            case 1 -> {                                              // grate: rusty bars, the holes glow and fade
                double gu = frac(u * 5 + ph), gv = frac(v * 5);
                if (gu < 0.2 || gv < 0.2) return mixc(0xFF1A0305, 0xFF5A0C10, 0.5 + 0.5 * Math.sin(u * 40 + v * 30));
                double pulse = 0.5 + 0.5 * Math.sin(t * 1.6 + Math.floor(u * 5 + ph) * 0.9 + Math.floor(v * 5) * 1.3);
                return mixc(0xFF050102, 0xFFC81C28, pulse * pulse);
            }
            default -> {                                             // iron plates: seams, rivets, red streaks that creep down
                double pu = frac(u * 2 + ph), pv = frac(v * 3);
                if (pu < .06 || pu > .94 || pv < .06 || pv > .94) return 0xFF1F0406;
                if ((pu < .15 || pu > .85) && (pv < .15 || pv > .85)) return 0xFF7A2024;
                double drip = 0.5 + 0.5 * Math.sin(u * 31 + ph * 5) * Math.sin(v * 3 + 0.5 * Math.sin(u * 17) - t * 0.4);
                double sh = 0.5 + 0.5 * Math.sin(t * 1.3 + u * 8 + v * 5);
                return mixc(0xFF22060A, 0xFFB82424, 0.25 * drip + 0.6 * sh * sh);
            }
        }
    }

    private static int pal(char c, boolean open) {
        return switch (c) {
            case 'k' -> 0xFF14030A;
            case 'd' -> 0xFF5A0A14;
            case 'r' -> 0xFFFF2A3A;
            case 'p' -> 0xFFFF9AA0;
            case 'b' -> 0xFF3A0810;
            case 'g' -> open ? 0xFFFF6A6A : 0xFF7A1018;
            default -> 0xFF2A0A10;
        };
    }

    @Override
    public void render(GuiGraphics g) {
        if (over && !won) { jumpScare(g); return; }
        double t = ticks / 60.0, sir = siren();
        g.fillGradient(0, 0, W, H / 2, 0xFF1C0408, 0xFF000000);    // ceiling
        g.fillGradient(0, H / 2, W, H, 0xFF000000, 0xFF3E060A);    // floor
        int glow = (int) (36 + 26 * Math.sin(t * 2.0) + 70 * sir);  // the floor pulses
        g.fillGradient(0, H - 34, W, H, 0x00700010, (Math.min(140, glow) << 24) | 0x700010);

        double dirX = Math.cos(ang), dirY = Math.sin(ang), plX = -dirY * PLANE, plY = dirX * PLANE;
        for (int c = 0; c < COLS; c++) {                           // walls: one ray per column
            double cam = 2.0 * (c + 0.5) / COLS - 1;
            double rdx = dirX + plX * cam, rdy = dirY + plY * cam;
            int mapX = (int) px, mapY = (int) py;
            double ddx = Math.abs(1 / rdx), ddy = Math.abs(1 / rdy), sdx, sdy;
            int stepX, stepY;
            if (rdx < 0) { stepX = -1; sdx = (px - mapX) * ddx; } else { stepX = 1; sdx = (mapX + 1 - px) * ddx; }
            if (rdy < 0) { stepY = -1; sdy = (py - mapY) * ddy; } else { stepY = 1; sdy = (mapY + 1 - py) * ddy; }
            boolean side = false;
            while (map[mapY][mapX] == 0) {                         // walk the grid until a wall is hit
                if (sdx < sdy) { sdx += ddx; mapX += stepX; side = false; }
                else { sdy += ddy; mapY += stepY; side = true; }
            }
            double dist = Math.max(0.05, side ? sdy - ddy : sdx - ddx);
            zbuf[c] = dist;
            double wallX = (side ? px + dist * rdx : py + dist * rdy);
            wallX -= Math.floor(wallX);
            double fog = Math.pow(Math.max(0, 1 - dist / 6.5), 1.2);
            double b = (0.95 * fog + 0.09) * light * (side ? 0.72 : 1) * (1 + 0.4 * sir * (0.6 + 0.4 * Math.sin(t * 9)));
            int type = Math.floorMod(mapX * 3 + mapY * 7, 3);
            double ph = mapX * 0.37 + mapY * 0.61;
            int lh = (int) (H / dist), top = H / 2 - lh / 2;
            int y0 = Math.max(0, top), y1 = Math.min(H, top + lh);
            int seg = Math.max(2, Math.min(8, (y1 - y0) / 12));
            for (int y = y0; y < y1; y += seg) {                   // the wall is drawn in pieces, each with its own color
                int h = Math.min(seg, y1 - y);
                double v = (y + h * 0.5 - top) / (double) lh;
                rect(g, c * CW, y, CW, h, shade(wall(type, wallX, v, t, ph), b));
            }
        }

        List<double[]> things = new ArrayList<>();                 // sprites, far ones first
        for (int i = 0; i < SEALS; i++) if (!got[i]) things.add(new double[]{sq(sx[i] - px) + sq(sy[i] - py), sx[i], sy[i], 0});
        things.add(new double[]{sq(N - 1.5 - px) + sq(N - 1.5 - py), N - 1.5, N - 1.5, 1});
        if (awake) things.add(new double[]{sq(ex - px) + sq(ey - py), ex, ey, 2});
        things.sort((a, b) -> Double.compare(b[0], a[0]));
        for (double[] s : things) {
            switch ((int) s[3]) {
                case 0 -> sprite(g, s[1], s[2], SEAL, 0.3, 0.12 + Math.sin(ticks / 12.0) * 0.04, 0.8, 10);
                case 1 -> sprite(g, s[1], s[2], GATE, 0.9, 0, 0.5, 10);
                default -> sprite(g, s[1], s[2], WARDEN, 0.9, 0, 0.12, 6);
            }
        }

        double md = Math.hypot(ex - px, ey - py);
        if (md < 3) {                                              // it is close: red edges and static
            rect(g, 0, 0, W, H, ((int) ((3 - md) / 3 * 90) << 24) | 0x900010);
            for (int k = 0; k < 6; k++) rect(g, rnd.nextInt(W), rnd.nextInt(H), 40, 1, 0x40FF6060);
        }
        if (sir > 0) rect(g, 0, 0, W, H, ((int) (sir * 46) << 24) | 0xFF0010);   // the siren washes the screen red
        for (int i = 0; i < 4; i++) {                              // dark red vignette
            int a = (0x78 - i * 0x1E) << 24;
            rect(g, i * 6, 0, 6, H, a | 0x100004);
            rect(g, W - 6 - i * 6, 0, 6, H, a | 0x100004);
        }
        hud(g);
        minimap(g);
        if (msgT > 0) ctext(g, Component.translatable(msg).getString(), W / 2, H - 14, msgT < 30 ? 0xFF8A3A40 : 0xFFFFA0A8);
        if (won) rect(g, 0, 0, W, H, 0x50FF8090);
    }

    private static double sq(double v) { return v * v; }

    /** Top-left: the three seals (a lit ring for every one you hold). */
    private void hud(GuiGraphics g) {
        for (int i = 0; i < SEALS; i++) {
            int x = 10 + i * 12;
            disc(g, x, 9, 4, 0xFF2A0610);
            disc(g, x, 9, 3, got[i] ? 0xFFFF3040 : 0xFF14030A);
            if (got[i]) rect(g, x - 1, 8, 2, 2, 0xFFFFC0C4);
        }
    }

    /** A billboard: a tiny picture that always faces you. Columns behind walls are skipped. */
    private void sprite(GuiGraphics g, double spx, double spy, String[] bmp, double size, double lift, double minB, double range) {
        double rx = spx - px, ry = spy - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);          // how far in front of us
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);         // how far to the right
        if (f < 0.15) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f), sh = (int) (full * size), sw = sh * bmp[0].length() / bmp.length;
        int left = (int) (W / 2.0 * (1 + cam)) - sw / 2, top = H / 2 + full / 2 - sh - (int) (full * lift);
        double b = (Math.max(minB, 1 - f / range) + (Math.abs(cam) < 0.35 ? 0.25 : 0)) * light;
        if (b <= 0.02) return;
        boolean open = seals == SEALS;
        for (int x = Math.floorDiv(left, CW) * CW; x < left + sw; x += CW) {
            int c = x / CW;
            if (x < 0 || c >= COLS || f >= zbuf[c]) continue;
            int u = Math.max(0, Math.min(bmp[0].length() - 1, (x + CW / 2 - left) * bmp[0].length() / sw));
            for (int row = 0; row < bmp.length; row++) {
                char ch = bmp[row].charAt(u);
                if (ch == '.') continue;
                int y0 = top + row * sh / bmp.length, y1 = Math.max(y0 + 1, top + (row + 1) * sh / bmp.length);
                rect(g, x, y0, CW, y1 - y0, shade(pal(ch, open), b));
            }
        }
    }

    /** Top-right: only the places you have already been to, in red. */
    private void minimap(GuiGraphics g) {
        int s = 3, x0 = W - N * s - 6, y0 = 6;
        rect(g, x0 - 2, y0 - 2, N * s + 4, N * s + 4, 0x99000000);
        for (int y = 0; y < N; y++) for (int x = 0; x < N; x++) {
            if (!seen[y][x]) continue;
            rect(g, x0 + x * s, y0 + y * s, s, s, map[y][x] == 1 ? 0xFF7A1C24 : 0xFF2A0A10);
        }
        if (seen[N - 2][N - 2]) rect(g, x0 + (N - 2) * s, y0 + (N - 2) * s, s, s, seals == SEALS ? 0xFFFF6A6A : 0xFF8A2028);
        rect(g, x0 + (int) (px * s) - 1, y0 + (int) (py * s) - 1, 2, 2, 0xFFFFC0C4);
        rect(g, x0 + (int) ((px + Math.cos(ang) * 1.2) * s), y0 + (int) ((py + Math.sin(ang) * 1.2) * s), 1, 1, 0xFFFF8A90);
    }

    /** You were caught: the warden's triangle head fills the screen. (The "Game over" box is drawn on top of the middle.) */
    private void jumpScare(GuiGraphics g) {
        boolean flick = (System.currentTimeMillis() / 80) % 2 == 0;
        rect(g, 0, 0, W, H, flick ? 0xFF3A0008 : 0xFF000000);
        rect(g, 24, 84, 172, 56, 0xFF14030A);                      // shoulders
        for (int r = 0; r < 76; r++) {                             // the head: a big triangle
            int ww = 8 + r * 2;
            rect(g, W / 2 - ww / 2, 8 + r, ww, 1, r % 6 < 3 ? 0xFF4A0A14 : 0xFF3A0610);
        }
        rect(g, W / 2 - 34, 58, 68, 7, 0xFFFF2A3A);                // the glowing slit
        rect(g, W / 2 - 34, 61, 68, 1, 0xFFFFC0C4);
        for (int k = 0; k < 9; k++) rect(g, 30 + k * 20, 84, 3, 10 + (k * 7) % 14, 0xFF8A0A16);   // blood
    }

    @Override
    public String hintKey() { return "cutemod.hint.otherworld"; }

    @Override
    public Component status() { return Component.translatable("cutemod.otherworld.status", seals, SEALS); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return Component.translatable(won ? "cutemod.otherworld.win" : "cutemod.ui.gameover");
    }
}
