"""Cute laptops in the same style as the PCs (mottled painted plastic, bevels, stickers, mascot desktops, chunky detailed models).
Run from the project root:  python3 tools/make_cute_laptops.py

Replaces the textures and block models of ALL nine laptops (blockstates / item models / loot tables / names stay as they are):
  neo    pink / blue / white / yellow  - cute, with stickers, the mascot desktop of the matching PC, raised keys
  office black / white / silver        - the thick, weak one: big bezel, numpad, ports, still with the same finish
  gaming black / white                 - THIN, with animated rainbow RGB (keys, deck glow, trackpad rim, lid rim, edge strips, rear vent)
The RGB textures are animated with .mcmeta files (rainbow slowly rolling), so the light really moves in the game.
The look is our own: no brand names or logos."""
import json, math, os, sys, random
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import numpy as np, cv2
from PIL import Image, ImageDraw
import art as A
import make_laptops as ML

TEX, MOD = ML.TEX, ML.MOD
PCTEX = TEX    # the PC textures (for the mascot desktops and the colours)
ppu = 10       # texture pixels per model unit on the flat parts

# ------------------------------------------------------------------------------------------------ small helpers
def rgb(h): return ((h >> 16) & 255, (h >> 8) & 255, h & 255)
def mix(a, b, t): return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(3))
def lighten(c, t): return mix(c, (255, 255, 255), t)
def darken(c, t): return mix(c, (0, 0, 0), t)
def clampu8(a): return np.clip(a, 0, 255).astype(np.uint8)

def mottle(w, h, base, seed=1, amp=7.0, grain=2.0, scale=None, top_light=0.05):
    """The soft painted / marbled plastic of the PCs: smooth noise on two scales plus a fine grain and a gentle top-to-bottom light."""
    rng = np.random.RandomState(seed)
    sc = scale or max(w, h) / 9.0
    low = cv2.GaussianBlur(rng.randn(h, w).astype(np.float32), (0, 0), sc); low /= (low.std() + 1e-6)
    mid = cv2.GaussianBlur(rng.randn(h, w).astype(np.float32), (0, 0), sc / 2.6); mid /= (mid.std() + 1e-6)
    fine = rng.randn(h, w).astype(np.float32)
    n = (low * 0.75 + mid * 0.45) * amp + fine * grain
    arr = np.zeros((h, w, 3), np.float32) + np.array(base, np.float32) + n[..., None]
    arr *= np.linspace(1 + top_light, 1 - top_light, h)[:, None, None]
    return Image.fromarray(np.dstack([clampu8(arr), np.full((h, w), 255, np.uint8)]), 'RGBA')

def bevel(im, t=2, hi=0.42, lo=0.24):
    """Light on the top and left rim, shade on the bottom and right: the panel looks like a raised piece of plastic."""
    a = np.array(im).astype(np.float32); h, w = a.shape[:2]
    for i in range(t):
        f = hi * (1 - i / t); g = lo * (1 - i / t)
        a[i, :, :3] = a[i, :, :3] * (1 - f) + 255 * f
        a[:, i, :3] = a[:, i, :3] * (1 - f * .8) + 255 * f * .8
        a[h - 1 - i, :, :3] *= (1 - g)
        a[:, w - 1 - i, :3] *= (1 - g * .8)
    return Image.fromarray(clampu8(a), 'RGBA')

def groove(im, inset, base, r=3):
    """A panel seam: a dark line with a light line under it."""
    d = ImageDraw.Draw(im); w, h = im.size
    d.rounded_rectangle((inset, inset, w - 1 - inset, h - 1 - inset), radius=r, outline=darken(base, .20) + (255,))
    d.rounded_rectangle((inset + 1, inset + 1, w - 2 - inset, h - 2 - inset), radius=max(r - 1, 0), outline=lighten(base, .22) + (255,))

def screws(im, inset, base):
    d = ImageDraw.Draw(im); w, h = im.size
    for (x, y) in ((inset, inset), (w - 1 - inset, inset), (inset, h - 1 - inset), (w - 1 - inset, h - 1 - inset)):
        d.point((x, y), fill=darken(base, .38) + (255,)); d.point((x - 1, y - 1), fill=lighten(base, .3) + (255,))

def place(im, spr, cx, cy, rot=0):
    if rot: spr = spr.rotate(rot, resample=Image.BICUBIC, expand=True)
    im.alpha_composite(spr, (int(round(cx - spr.width / 2)), int(round(cy - spr.height / 2))))

def lerp_grad(w, h, c0, c1, vertical=True):
    t = np.linspace(0, 1, h if vertical else w)
    arr = np.array(c0)[None, :] * (1 - t[:, None]) + np.array(c1)[None, :] * t[:, None]
    arr = np.repeat(arr[:, None, :], w, 1) if vertical else np.repeat(arr[None, :, :], h, 0)
    return Image.fromarray(np.dstack([clampu8(arr), np.full((h, w), 255, np.uint8)]), 'RGBA')

def rrect(d, box, r, fill, outline=None): d.rounded_rectangle(box, radius=r, fill=fill, outline=outline)

# extra stickers, drawn like the ones in art.py (a 0..100 canvas)
def strawberry(d, im):
    A.poly(d, [(50, 96), (12, 52), (14, 30), (50, 22), (86, 30), (88, 52)], '#e8334a', '#9c1426')
    for (x, y) in ((34, 40), (50, 36), (66, 40), (28, 54), (44, 52), (58, 52), (72, 54), (38, 68), (52, 66), (62, 70), (50, 82)):
        A.ell(d, x - 2.5, y - 3.5, x + 2.5, y + 3.5, '#ffe9a8')
    A.poly(d, [(50, 28), (24, 12), (34, 30)], '#4fb24a', '#2a7a2c'); A.poly(d, [(50, 28), (76, 12), (66, 30)], '#4fb24a', '#2a7a2c')
    A.poly(d, [(50, 28), (40, 6), (60, 6)], '#69c85a', '#2a7a2c')
def heart(d, im):
    A.circ(d, 31, 34, 22, '#ff4f7b', '#b81c47', 3); A.circ(d, 69, 34, 22, '#ff4f7b', '#b81c47', 3)
    A.poly(d, [(11, 44), (89, 44), (50, 92)], '#ff4f7b', '#b81c47'); A.circ(d, 31, 34, 20, '#ff4f7b'); A.circ(d, 69, 34, 20, '#ff4f7b')
    A.poly(d, [(13, 46), (87, 46), (50, 89)], '#ff4f7b'); A.ell(d, 18, 20, 36, 32, (255, 255, 255, 140))
def star5(d, im):
    pts = []
    for i in range(10):
        r = 46 if i % 2 == 0 else 20; a = math.radians(-90 + 36 * i); pts.append((50 + r * math.cos(a), 52 + r * math.sin(a)))
    A.poly(d, pts, '#ffd84a', '#b8861a')
def catface(d, im):
    A.poly(d, [(10, 8), (42, 24), (12, 50)], '#ff9fc0', '#b84a78'); A.poly(d, [(90, 8), (58, 24), (88, 50)], '#ff9fc0', '#b84a78')
    A.ell(d, 6, 20, 94, 92, '#ffb3cc', '#b84a78', 2.5)
    A.ell(d, 24, 46, 38, 62, '#3a1a3a'); A.ell(d, 62, 46, 76, 62, '#3a1a3a'); A.circ(d, 31, 50, 2.6, '#fff'); A.circ(d, 69, 50, 2.6, '#fff')
    A.poly(d, [(45, 66), (55, 66), (50, 72)], '#e8527d'); A.line(d, [(50, 72), (50, 76), (44, 79)], '#3a1a3a', 1.6); A.line(d, [(50, 76), (56, 79)], '#3a1a3a', 1.6)
    A.ell(d, 12, 64, 26, 74, (255, 110, 150, 150)); A.ell(d, 74, 64, 88, 74, (255, 110, 150, 150))
def sticker(fn, size, border=None, shadow=True): return A.sticker(fn, size, border, shadow)

# ------------------------------------------------------------------------------------------------ colours & themes
def pc_color(name):
    """The body colour of the matching PC (median of its tower texture) so laptop and PC look like one family."""
    a = np.array(Image.open(PCTEX + '%s_computer_tower.png' % name).convert('RGBA')).reshape(-1, 4)
    a = a[a[:, 3] > 200][:, :3]
    return tuple(int(x) for x in np.median(a, 0))

NEO = {  # id -> mascot sticker, two small glyphs, accent key colour
    'pink':   dict(pc='pink',   big=[strawberry, heart], small=[star5, heart], accent=(255, 112, 160), mascot=catface),
    'blue':   dict(pc='blue',   big=[A.penguin],         small=[A.fish, A.snow],  accent=(88, 150, 255), mascot=A.penguin),
    'white':  dict(pc='white',  big=[A.panda],           small=[A.bamboo, A.paw], accent=(110, 190, 140), mascot=A.panda),
    'yellow': dict(pc='yellow', big=[A.bee],             small=[A.honey, A.flower_y], accent=(255, 170, 40), mascot=A.bee),
}

# ------------------------------------------------------------------------------------------------ keyboards
LAYOUT = [  # (height in px, key widths in key units); the row is stretched to fill the width
    (5, [1] * 13),
    (7, [1] * 13 + [1.6]),
    (7, [1.5] + [1] * 12 + [1.5]),
    (7, [1.8] + [1] * 11 + [2.2]),
    (7, [2.3] + [1] * 10 + [2.7]),
    (7, [1.3, 1.1, 1.1, 1.1, 5.4, 1.1, 1.1, 1.1, 1, 1, 1]),
]
NUMPAD = [  # a block on the right of an office keyboard: 4 columns
    (5, [1] * 4), (7, [1] * 4), (7, [1] * 4), (7, [1] * 4), (7, [1] * 4), (7, [2, 1, 1]),
]

def draw_keys(im, x0, y0, x1, key_cols, bed, rows=LAYOUT, accent=None, legend=None, rowh_gap=1, key_fn=None, y_stretch=None):
    """Draw rows of 3D-looking keys into im between x0 and x1. key_cols(kx, ky, ri, ki) -> colour of a key."""
    d = ImageDraw.Draw(im); y = y0; keycount = 0
    total_h = sum(h + rowh_gap for h, _ in rows)
    sy = (y_stretch / total_h) if y_stretch else 1.0
    for ri, (h, widths) in enumerate(rows):
        hh = max(3, int(round(h * sy)))
        tot = sum(widths); gaps = len(widths) - 1
        unit = (x1 - x0 - gaps) / tot; x = float(x0)
        for ki, wk in enumerate(widths):
            kw = wk * unit; xa, xb = int(round(x)), int(round(x + kw)) - 1
            c = key_cols(xa, y, ri, ki)
            d.rectangle((xa, y, xb, y + hh - 1), fill=c + (255,))
            d.line([(xa, y), (xb, y)], fill=lighten(c, .45) + (255,))                       # lit top edge
            d.line([(xa, y + hh - 1), (xb, y + hh - 1)], fill=darken(c, .28) + (255,))        # shaded bottom edge
            d.line([(xb, y + 1), (xb, y + hh - 2)], fill=darken(c, .12) + (255,))
            if hh >= 5 and legend and (xb - xa) >= 4:
                d.point(((xa + xb) // 2, y + hh // 2 - (0 if hh < 6 else 0)), fill=legend + (255,))
            x += kw + 1; keycount += 1
        y += hh + rowh_gap
    return y

# =========================================================================================================== NEO
def neo_body(c): return mottle(16, 16, c, seed=3, amp=6, grain=1.6, scale=3)

def neo_deck(c, th, seed):
    W, H = 128, 88
    im = mottle(W, H, c, seed=seed, amp=7); im = bevel(im, 2)
    groove(im, 4, c, 5); screws(im, 7, c)
    d = ImageDraw.Draw(im)
    bed = darken(c, .55)
    rrect(d, (13, 7, 114, 52), 3, bed + (255,), darken(c, .7) + (255,))                    # the keyboard well (the keys block sits on top)
    for gx in (4, 119):                                                                      # speaker grills beside the keys
        for gy in range(12, 46, 4): d.rectangle((gx, gy, gx + 3, gy + 1), fill=darken(c, .45) + (255,)); d.point((gx, gy + 2), fill=lighten(c, .3) + (255,))
    tp = (40, 58, 88, 80)                                                                    # the trackpad: a sunken pad with a lit lip
    rrect(d, tp, 4, darken(c, .22) + (255,)); rrect(d, (tp[0] + 1, tp[1] + 1, tp[2] - 1, tp[3] - 1), 4, lighten(c, .14) + (255,))
    d.line([(tp[0] + 4, tp[1] + 1), (tp[2] - 4, tp[1] + 1)], fill=lighten(c, .5) + (255,))
    place(im, sticker(th['small'][0], 11, 1, False), 20, 70)                                 # little stickers on the palm rest
    place(im, sticker(th['small'][-1], 11, 1, False), 108, 70)
    d.ellipse((111, 81, 113, 83), fill=tuple(th['accent']) + (255,)); d.point((111, 81), fill=(255, 255, 255, 255))   # the power light
    return im

def neo_keys(c, th):
    W, H = 104, 44
    bed = darken(c, .55); im = Image.new('RGBA', (W, H), bed + (255,))
    keyc = lighten(c, .55); acc = th['accent']
    def col(x, y, ri, ki):
        if ri == 0 and ki == 0: return acc
        if ri == 3 and ki == 12: return acc
        if ri == 5 and ki == 4: return lighten(c, .68)
        return mix(keyc, c, 0.0 + 0.10 * ((ki + ri) % 2))
    draw_keys(im, 2, 2, W - 2, col, bed, LAYOUT, legend=darken(c, .5), y_stretch=H - 4)
    return im

def neo_bed(c): return Image.new('RGBA', (4, 4), darken(c, .6) + (255,))
def neo_feet(c): return Image.new('RGBA', (4, 4), darken(c, .45) + (255,))

def neo_back(c, th, seed):
    W, H = 104, 70
    im = mottle(W, H, c, seed=seed + 11, amp=7); im = bevel(im, 2)
    groove(im, 5, c, 6); screws(im, 8, c)
    big = th['big']
    if len(big) == 1:
        place(im, sticker(big[0], 34, 2), W / 2, H / 2 - 1)
        place(im, sticker(th['small'][0], 15, 1), 24, 52, -10); place(im, sticker(th['small'][1], 15, 1), 80, 21, 10)
    else:
        place(im, sticker(big[0], 32, 2), W / 2 - 15, H / 2 + 1, -6); place(im, sticker(big[1], 28, 2), W / 2 + 17, H / 2 - 2, 8)
        place(im, sticker(th['small'][0], 13, 1), 78, 54, 8); place(im, sticker(th['small'][1], 13, 1), 24, 18, -8)
    d = ImageDraw.Draw(im)
    for (x, y) in ((16, 30), (88, 44), (60, 14), (36, 56)): d.point((x, y), fill=lighten(c, .7) + (255,)); d.point((x + 1, y), fill=lighten(c, .45) + (255,)); d.point((x, y + 1), fill=lighten(c, .45) + (255,))
    return im

def neo_screen(name, th, c):
    """The desktop of the matching PC (the mascot, icons, sticky note, stars, task bar) inside a soft bezel."""
    W, H = 104, 70
    bz = darken(c, .78)
    im = Image.new('RGBA', (W, H), bz + (255,)); d = ImageDraw.Draw(im)
    pc = Image.open(PCTEX + '%s_computer_monitor.png' % th['pc']).convert('RGBA').crop((10, 9, 71, 48))   # the desktop part of the PC monitor atlas (128 px pack)
    sw, sh = 96, 60
    desk = pc.resize((sw, sh), Image.LANCZOS)
    m = Image.new('L', (sw, sh), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, sw - 1, sh - 1), radius=4, fill=255)
    ox, oy = (W - sw) // 2, 4
    d.rounded_rectangle((ox - 2, oy - 2, ox + sw + 1, oy + sh + 1), radius=5, fill=(10, 9, 16, 255))
    im.paste(desk, (ox, oy), m)
    d = ImageDraw.Draw(im)
    d.ellipse((W // 2 - 1, 1, W // 2 + 1, 3), fill=(62, 60, 84, 255)); d.point((W // 2, 2), fill=(120, 160, 255, 255))      # the camera
    d.rounded_rectangle((W // 2 - 8, H - 4, W // 2 + 8, H - 3), radius=1, fill=lighten(bz, .22) + (255,))                  # a chin mark
    g = Image.new('RGBA', (W, H), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
    for i in range(0, 16): gd.line([(72 + i, 4), (40 + i, 62)], fill=(255, 255, 255, 7))
    im.alpha_composite(g)
    return im

# =========================================================================================================== OFFICE
def office_deck(v, seed):
    c = rgb(v['body']); W, H = 133, 93
    im = mottle(W, H, c, seed=seed, amp=5, grain=1.4); im = bevel(im, 2); groove(im, 4, c, 3); screws(im, 7, c)
    d = ImageDraw.Draw(im)
    rrect(d, (8, 9, 125, 60), 2, rgb(v['bed']) + (255,), darken(rgb(v['bed']), .3) + (255,))
    tp = (46, 66, 88, 87)
    rrect(d, tp, 3, darken(c, .25) + (255,)); rrect(d, (tp[0] + 1, tp[1] + 1, tp[2] - 1, tp[3] - 1), 3, lighten(c, .10) + (255,))
    d.line([(tp[0] + 3, tp[1] + 1), (tp[2] - 3, tp[1] + 1)], fill=lighten(c, .45) + (255,))
    d.rectangle((110, 68, 120, 76), fill=darken(c, .3) + (255,)); d.rectangle((111, 69, 119, 75), fill=lighten(c, .12) + (255,))   # fingerprint reader
    for i in range(5): d.line([(10 + i * 3, 70), (10 + i * 3, 84)], fill=darken(c, .4) + (255,))                                    # speaker grill
    return im

def office_keys(v):
    W, H = 116, 47; c = rgb(v['body']); key = rgb(v['key']); bed = rgb(v['bed'])
    im = Image.new('RGBA', (W, H), bed + (255,))
    def col(x, y, ri, ki): return key
    nx = 85
    draw_keys(im, 2, 2, nx - 3, col, bed, LAYOUT, legend=rgb(v['legend']), y_stretch=H - 4)
    draw_keys(im, nx, 2, W - 2, col, bed, NUMPAD, legend=rgb(v['legend']), y_stretch=H - 4)
    return im

def office_back(v, seed):
    c = rgb(v['body']); W, H = 104, 69
    im = mottle(W, H, c, seed=seed, amp=5, grain=1.3); im = bevel(im, 2); groove(im, 5, c, 4); screws(im, 8, c)
    d = ImageDraw.Draw(im); cx, cy = W // 2, H // 2
    ring = lighten(c, .6) if v['body'] == 0x2B2D33 else darken(c, .4)
    d.ellipse((cx - 9, cy - 9, cx + 9, cy + 9), outline=ring + (255,), width=2); d.ellipse((cx - 3, cy - 3, cx + 3, cy + 3), fill=ring + (255,))
    return im

# =========================================================================================================== GAMING (animated)
NF = 12   # animation frames

def hue(h, s=1.0, v=1.0):
    import colorsys
    return tuple(int(x * 255) for x in colorsys.hsv_to_rgb(h % 1.0, s, v))

def gaming_body(v, seed):
    c = rgb(v['body']); im = mottle(16, 16, c, seed=seed, amp=3.0, grain=1.0, scale=3)
    return im

def gaming_deck(v, t, seed):
    c = rgb(v['body']); white = v['body'] == 0xECEEF2
    W, H = 140, 90
    im = mottle(W, H, c, seed=seed, amp=3.5, grain=1.2); im = bevel(im, 2, .30, .30); groove(im, 4, c, 4); screws(im, 7, c)
    # soft rainbow glow around the keyboard well (it moves with the animation)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    bx0, by0, bx1, by1 = 15, 9, 125, 56
    dx = np.maximum(np.maximum(bx0 - xx, xx - bx1), 0); dy = np.maximum(np.maximum(by0 - yy, yy - by1), 0)
    dist = np.sqrt(dx * dx + dy * dy)
    inten = np.exp(-dist / 5.0) * (dist > 0)
    hmap = ((xx / W) + t / NF)
    glow = np.zeros((H, W, 3), np.float32)
    import colorsys
    lut = np.array([colorsys.hsv_to_rgb(i / 256, .9, 1.0) for i in range(256)], np.float32) * 255
    glow = lut[((hmap % 1.0) * 255).astype(int)]
    arr = np.array(im).astype(np.float32)
    k = (inten * (.55 if not white else .45))[..., None]
    arr[..., :3] = arr[..., :3] * (1 - k) + glow * k
    im = Image.fromarray(clampu8(arr), 'RGBA'); d = ImageDraw.Draw(im)
    rrect(d, (bx0, by0, bx1, by1), 3, darken(c, .72) + (255,))                              # the dark well
    for gx in (3, W - 13):                                                                    # speaker grills
        for gy in range(11, 52, 3):
            for kk in range(3): d.point((gx + kk * 3, gy), fill=darken(c, .6) + (255,))
    tp = (44, 59, 96, 84)                                                                     # the trackpad with a rolling rainbow rim
    rrect(d, tp, 3, darken(c, .35) + (255,)); rrect(d, (tp[0] + 1, tp[1] + 1, tp[2] - 1, tp[3] - 1), 3, mix(darken(c, .25), (30, 30, 40), .3) + (255,))
    for i in range(tp[0] + 3, tp[2] - 2): d.point((i, tp[1]), fill=hue((i - tp[0]) / (tp[2] - tp[0]) + t / NF) + (255,)); d.point((i, tp[3]), fill=hue((i - tp[0]) / (tp[2] - tp[0]) + .5 + t / NF) + (255,))
    for j in range(tp[1] + 3, tp[3] - 2): d.point((tp[0], j), fill=hue(.0 + t / NF) + (255,)); d.point((tp[2], j), fill=hue(.5 + t / NF) + (255,))
    d.ellipse((W - 14, 70, W - 7, 77), fill=hue(.33 + t / NF) + (255,)); d.ellipse((W - 12, 72, W - 9, 75), fill=darken(c, .6) + (255,))   # the power button
    return im

def gaming_keys(v, t):
    W, H = 108, 45; c = rgb(v['body']); white = v['body'] == 0xECEEF2
    key = rgb(v['key']); bed = rgb(v['bed'])
    im = Image.new('RGBA', (W, H), darken(c, .7) + (255,))
    def col(x, y, ri, ki):
        h = hue(x / W + ri * .04 + t / NF, .85, 1.0)          # every key glows in the colour of its place and the colours roll
        return mix(h, key, .35 if not white else .5)
    draw_keys(im, 2, 2, W - 2, col, bed, LAYOUT, legend=(255, 255, 255) if not white else (40, 40, 60), y_stretch=H - 4)
    # glow bleeding between the keys
    arr = np.array(im).astype(np.float32); blur = cv2.GaussianBlur(arr[..., :3], (0, 0), 1.2)
    arr[..., :3] = np.maximum(arr[..., :3], blur * .85)
    return Image.fromarray(clampu8(arr), 'RGBA')

def gaming_rgb(t):
    W, H = 64, 4; im = Image.new('RGBA', (W, H))
    for x in range(W):
        for y in range(H): im.putpixel((x, y), hue(x / W + t / NF, .95, 1.0) + (255,))
    return im

def gaming_vent(v, t):
    W, H = 64, 12; c = rgb(v['body']); white = v['body'] == 0xECEEF2
    im = Image.new('RGBA', (W, H), darken(c, .45) + (255,)); d = ImageDraw.Draw(im)
    for x in range(3, W - 3, 4): d.rectangle((x, 2, x + 1, H - 4), fill=(0, 0, 0, 255) if not white else darken(c, .75) + (255,))
    for x in range(W): d.point((x, H - 1), fill=hue(x / W + t / NF) + (255,)); d.point((x, H - 2), fill=darken(hue(x / W + t / NF), .5) + (255,))
    return im

def gaming_screen(v):
    """Thin bezel, neon sunset over a grid, a crosshair, a health bar and a round radar."""
    W, H = 120, 72
    im = Image.new('RGBA', (W, H), (8, 8, 12, 255)); d = ImageDraw.Draw(im)
    sw, sh = W - 4, H - 5
    sc = Image.new('RGBA', (sw, sh)); sd = ImageDraw.Draw(sc)
    for y in range(sh): sd.line([(0, y), (sw, y)], fill=mix(rgb(0x1B0B3A), rgb(0xFF4DA6), (y / sh) ** 1.4) + (255,))
    hz = int(sh * .58)
    sd.ellipse((sw // 2 - 17, hz - 21, sw // 2 + 17, hz + 13), fill=rgb(0xFFD35C) + (255,))
    for i in range(4): sd.rectangle((sw // 2 - 18, hz - 6 + i * 4, sw // 2 + 18, hz - 5 + i * 4), fill=mix(rgb(0xFF4DA6), rgb(0x1B0B3A), .3) + (255,))
    sd.rectangle((0, hz, sw, sh), fill=rgb(0x14082B) + (255,))
    for i in range(0, sw + 40, 10): sd.line([(sw // 2 + (i - sw // 2) * .2, hz), (sw // 2 + (i - sw // 2) * 2.2, sh)], fill=rgb(0x35E0FF) + (255,))
    for j in range(1, 6): sd.line([(0, hz + j * j * 1.6), (sw, hz + j * j * 1.6)], fill=rgb(0x35E0FF) + (255,))
    cx, cy = sw // 2, hz - 3
    for (a, b, c2, e) in ((cx - 5, cy, cx - 2, cy), (cx + 2, cy, cx + 5, cy), (cx, cy - 5, cx, cy - 2), (cx, cy + 2, cx, cy + 5)): sd.line([(a, b), (c2, e)], fill=(255, 255, 255, 255))
    sd.rectangle((4, sh - 9, 36, sh - 5), outline=(255, 255, 255, 200)); sd.rectangle((5, sh - 8, 28, sh - 6), fill=rgb(0x4DFF88) + (255,))
    rx, ry = sw - 14, 14                                                                       # the radar
    sd.ellipse((rx - 10, ry - 10, rx + 10, ry + 10), fill=(0, 20, 30, 190), outline=rgb(0x35E0FF) + (255,)); sd.ellipse((rx - 5, ry - 5, rx + 5, ry + 5), outline=rgb(0x1a8aa8) + (255,))
    sd.line([(rx, ry), (rx + 7, ry - 6)], fill=rgb(0x4DFF88) + (255,)); sd.point((rx - 4, ry + 3), fill=rgb(0xFF4D4D) + (255,)); sd.point((rx + 3, ry + 4), fill=rgb(0xFF4D4D) + (255,))
    im.paste(sc, (2, 2)); d = ImageDraw.Draw(im)
    d.point((W // 2, 1), fill=(70, 74, 90, 255))
    g = Image.new('RGBA', (W, H), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
    for i in range(0, 14): gd.line([(84 + i, 0), (40 + i, H)], fill=(255, 255, 255, 6))
    im.alpha_composite(g)
    return im

def gaming_back(v, t, seed):
    """The lid: a hexagon with cat ears and a rainbow rim (our own mark), a rainbow frame along the edge, all rolling."""
    c = rgb(v['body']); W, H = 120, 72
    im = mottle(W, H, c, seed=seed, amp=3.2, grain=1.0); im = bevel(im, 2, .3, .3)
    d = ImageDraw.Draw(im)
    cx, cy, r = W // 2, H // 2 + 3, 16
    pts = [(cx + r * math.cos(math.radians(60 * i - 30)), cy + r * math.sin(math.radians(60 * i - 30))) for i in range(6)]
    ears = [[(cx - 11, cy - r + 1), (cx - 9, cy - r - 9), (cx - 2, cy - r + 1)], [(cx + 11, cy - r + 1), (cx + 9, cy - r - 9), (cx + 2, cy - r + 1)]]
    inner = darken(c, .5) if v['body'] == 0x1B1C22 else darken(c, .25)
    for e in ears: d.polygon(e, fill=inner + (255,))
    d.polygon(pts, fill=inner + (255,))
    n = len(pts)
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        for s in range(0, 11):
            x = a[0] + (b[0] - a[0]) * s / 10; y = a[1] + (b[1] - a[1]) * s / 10
            d.ellipse((x - 1, y - 1, x + 1, y + 1), fill=hue((i + s / 10) / n + t / NF) + (255,))
    for e in ears:
        for k in range(2):
            a, b = e[k], e[k + 1]
            for s in range(0, 7):
                x = a[0] + (b[0] - a[0]) * s / 6; y = a[1] + (b[1] - a[1]) * s / 6
                d.point((int(x), int(y)), fill=hue(.1 * k + s / 20 + t / NF) + (255,))
    col = hue(.55 + t / NF)
    d.ellipse((cx - 5, cy - 4, cx + 5, cy + 6), outline=col + (255,))
    for dx in (-5, 0, 5): d.ellipse((cx + dx - 1, cy - 8, cx + dx + 1, cy - 6), fill=col + (255,))
    for x in range(4, W - 4):                                                                  # the rainbow frame, just inside the edge
        d.point((x, 4), fill=hue(x / W + t / NF) + (255,)); d.point((x, H - 5), fill=hue(x / W + .5 + t / NF) + (255,))
    for y in range(4, H - 4):
        d.point((4, y), fill=hue(y / H * .5 + t / NF) + (255,)); d.point((W - 5, y), fill=hue(y / H * .5 + .5 + t / NF) + (255,))
    return im

def save_anim(name, frames, frametime=4):
    """Stack the frames vertically and write the .mcmeta (a rainbow that rolls)."""
    w, h = frames[0].size; sheet = Image.new('RGBA', (w, h * len(frames)))
    for i, f in enumerate(frames): sheet.paste(f, (0, i * h))
    sheet.save(TEX + name + '.png')
    json.dump({'animation': {'width': w, 'height': h, 'frametime': frametime, 'interpolate': True}}, open(TEX + name + '.png.mcmeta', 'w'))

# =========================================================================================================== MODELS
def box(name, f, t, faces, rot=None):
    e = {'name': name, 'from': [round(x, 3) for x in f], 'to': [round(x, 3) for x in t], 'faces': faces}
    if rot: e['rotation'] = rot
    return e
def fa(tex): return {k: {'uv': [0, 0, 16, 16], 'texture': tex} for k in ('north', 'south', 'east', 'west', 'up', 'down')}
def w_(faces, **kw):
    f = dict(faces)
    for k, tex in kw.items(): f[k] = {'uv': [0, 0, 16, 16], 'texture': tex}
    return f
def feet(X0, X1, Z0, Z1, h=.15, inset=.7, sz=.9):
    out = []
    for i, (x, z) in enumerate(((X0 + inset, Z0 + inset), (X1 - inset - sz, Z0 + inset), (X0 + inset, Z1 - inset - sz), (X1 - inset - sz, Z1 - inset - sz))):
        out.append(box('foot%d' % i, [x, 0, z], [x + sz, h, z + sz * .8], fa('#feet')))
    return out

def neo_model(open_):
    X0, X1, Z0, Z1 = 1.5, 14.5, 4.4, 13.4
    els = feet(X0, X1, Z0, Z1, .15)
    els.append(box('base', [X0, .15, Z0], [X1, .5, Z1], fa('#body')))
    els.append(box('deck', [X0 + .12, .5, Z0 + .12], [X1 - .12, .8, Z1 - .12], w_(fa('#body'), up='#deck')))
    els.append(box('thumb_notch', [6.8, .42, Z1], [9.2, .62, Z1 + .05], fa('#bed')))
    for i, z in enumerate((6.5, 7.6)): els.append(box('port_l%d' % i, [X0 - .05, .28, z], [X0, .5, z + .7], fa('#bed')))
    els.append(box('port_r', [X1, .28, 6.8], [X1 + .05, .5, 7.5], fa('#bed')))
    if open_:
        els.append(box('keybed', [2.65, .8, 5.15], [13.35, .88, 9.85], fa('#bed')))
        els.append(box('keys', [2.75, .88, 5.25], [13.25, 1.04, 9.75], w_(fa('#bed'), up='#keys')))
        els.append(box('hinge', [2.4, .58, Z0 - .25], [13.6, 1.1, Z0 + .38], fa('#body')))
        els.append(box('hinge_cap_l', [2.0, .6, Z0 - .2], [2.4, 1.05, Z0 + .34], fa('#feet')))
        els.append(box('hinge_cap_r', [13.6, .6, Z0 - .2], [14.0, 1.05, Z0 + .34], fa('#feet')))
        rot = {'origin': [8, .8, Z0 + .22], 'axis': 'x', 'angle': -22.5}
        els.append(box('lid', [X0, .8, Z0], [X1, 9.6, Z0 + .44], w_(fa('#body'), south='#screen', north='#back'), rot))
        els.append(box('lid_front', [X0 + .15, .95, Z0 + .44], [X1 - .15, 9.45, Z0 + .52], w_(fa('#body'), south='#screen'), rot))
    else:
        els.append(box('lid_closed', [X0, .8, Z0], [X1, 1.25, Z1], w_(fa('#body'), up='#back')))
        els.append(box('lid_closed_rim', [X0 + .2, 1.25, Z0 + .2], [X1 - .2, 1.3, Z1 - .2], w_(fa('#body'), up='#back')))
    return els

def office_model(open_):
    X0, X1, Z0, Z1 = 1.25, 14.75, 4.4, 13.9
    els = feet(X0, X1, Z0, Z1, .16, .9, 1.1)
    els.append(box('base', [X0, .16, Z0], [X1, .6, Z1], fa('#body')))
    els.append(box('deck', [X0 + .1, .6, Z0 + .1], [X1 - .1, 1.15, Z1 - .1], w_(fa('#body'), up='#deck')))
    for i, z in enumerate((6.4, 7.5, 8.6)): els.append(box('port_l%d' % i, [X0 - .06, .62, z], [X0, 1.0, z + .8], fa('#feet')))
    for i, z in enumerate((6.4, 7.8)): els.append(box('port_r%d' % i, [X1, .62, z], [X1 + .06, 1.0, z + .9], fa('#feet')))
    if open_:
        els.append(box('keybed', [2.1, 1.15, 5.4], [13.9, 1.22, 10.3], fa('#bed')))
        els.append(box('keys', [2.2, 1.22, 5.5], [13.8, 1.36, 10.2], w_(fa('#bed'), up='#keys')))
        els.append(box('hinge', [2.5, .95, Z0 - .2], [13.5, 1.4, Z0 + .35], fa('#feet')))
        rot = {'origin': [8, 1.15, Z0 + .3], 'axis': 'x', 'angle': -22.5}
        els.append(box('lid', [X0, 1.15, Z0], [X1, 10.0, Z0 + .6], w_(fa('#body'), south='#screen', north='#back'), rot))
        els.append(box('lid_front', [X0 + .2, 1.3, Z0 + .6], [X1 - .2, 9.85, Z0 + .68], w_(fa('#body'), south='#screen'), rot))
    else:
        els.append(box('lid_closed', [X0, 1.15, Z0], [X1, 1.85, Z1], w_(fa('#body'), up='#back')))
    return els

def gaming_model(open_):
    X0, X1, Z0, Z1 = .9, 15.1, 4.7, 13.9
    els = feet(X0, X1, Z0, Z1, .12, .8, 1.0)
    els.append(box('base', [X0, .12, Z0], [X1, .36, Z1], fa('#body')))
    els.append(box('glow_front', [X0 + .5, .14, Z1], [X1 - .5, .32, Z1 + .06], fa('#rgb')))                     # the underglow strips
    els.append(box('glow_left', [X0 - .06, .14, Z0 + 1.0], [X0, .32, Z1 - .5], fa('#rgb')))
    els.append(box('glow_right', [X1, .14, Z0 + 1.0], [X1 + .06, .32, Z1 - .5], fa('#rgb')))
    els.append(box('deck', [X0 + .08, .36, Z0 + .08], [X1 - .08, .62, Z1 - .08], w_(fa('#body'), up='#deck')))
    if open_:
        els.append(box('keybed', [2.5, .62, 5.7], [13.5, .68, 10.4], fa('#bed')))
        els.append(box('keys', [2.6, .68, 5.8], [13.4, .78, 10.3], w_(fa('#bed'), up='#keys')))
        els.append(box('hinge_pod', [2.0, .36, Z0 - .35], [14.0, .98, Z0 + .75], w_(fa('#body'), north='#vent', up='#vent')))   # the rear vent pod
        els.append(box('pod_cap_l', [1.8, .42, Z0 - .3], [2.0, .9, Z0 + .7], fa('#rgb')))
        els.append(box('pod_cap_r', [14.0, .42, Z0 - .3], [14.2, .9, Z0 + .7], fa('#rgb')))
        rot = {'origin': [8, .92, Z0 + .22], 'axis': 'x', 'angle': -22.5}
        els.append(box('lid', [X0, .92, Z0 + .05], [X1, 9.5, Z0 + .38], w_(fa('#body'), south='#screen', north='#back'), rot))
        els.append(box('lid_glow_l', [X0 - .06, 1.1, Z0 + .08], [X0, 9.3, Z0 + .35], fa('#rgb'), rot))              # the lit sides of the lid
        els.append(box('lid_glow_r', [X1, 1.1, Z0 + .08], [X1 + .06, 9.3, Z0 + .35], fa('#rgb'), rot))
        els.append(box('lid_glow_top', [X0 + .4, 9.5, Z0 + .08], [X1 - .4, 9.56, Z0 + .35], fa('#rgb'), rot))
    else:
        els.append(box('lid_closed', [X0, .62, Z0], [X1, .92, Z1], w_(fa('#body'), up='#back')))
        els.append(box('lid_glow_f', [X0 + .3, .68, Z1], [X1 - .3, .84, Z1 + .05], fa('#rgb')))
        els.append(box('lid_glow_l', [X0 - .05, .68, Z0 + .6], [X0, .84, Z1 - .3], fa('#rgb')))
        els.append(box('lid_glow_r', [X1, .68, Z0 + .6], [X1 + .05, .84, Z1 - .3], fa('#rgb')))
    return els

def write_models(block, prefix, keys, fn, credit):
    tex = {'particle': 'cutemod:block/%s_body' % prefix, 'body': 'cutemod:block/%s_body' % prefix}
    tex.update({k: 'cutemod:block/%s_%s' % (prefix, k) for k in keys})
    for open_, suffix in ((True, ''), (False, '_closed')):
        json.dump({'credit': credit, 'ambientocclusion': False, 'textures': tex, 'elements': fn(open_)}, open(MOD + '%s_laptop%s.json' % (block, suffix), 'w'), indent=1)

# =========================================================================================================== main
def main():
    for i, (name, th) in enumerate(NEO.items()):
        c = pc_color(th['pc']); p = '%s_neo' % name
        neo_body(c).save(TEX + p + '_body.png'); neo_deck(c, th, i + 1).save(TEX + p + '_deck.png')
        neo_keys(c, th).save(TEX + p + '_keys.png'); neo_bed(c).save(TEX + p + '_bed.png'); neo_feet(c).save(TEX + p + '_feet.png')
        neo_back(c, th, i + 1).save(TEX + p + '_back.png'); neo_screen(name, th, c).save(TEX + p + '_screen.png')
        write_models(name, p, ('deck', 'keys', 'bed', 'feet', 'screen', 'back'), neo_model, 'cute Neo laptop (generated by tools/make_cute_laptops.py)')
    for i, (name, v) in enumerate(ML.OFFICE.items()):
        c = rgb(v['body'])
        mottle(16, 16, c, seed=20 + i, amp=4, grain=1.2, scale=3).save(TEX + name + '_body.png')
        Image.new('RGBA', (4, 4), darken(c, .5) + (255,)).save(TEX + name + '_feet.png')
        Image.new('RGBA', (4, 4), rgb(v['bed']) + (255,)).save(TEX + name + '_bed.png')
        office_deck(v, 30 + i).save(TEX + name + '_deck.png'); office_keys(v).save(TEX + name + '_keys.png')
        ML.office_screen(v).save(TEX + name + '_screen.png'); office_back(v, 40 + i).save(TEX + name + '_back.png')
        write_models(name, name, ('deck', 'keys', 'bed', 'feet', 'screen', 'back'), office_model, 'cute office laptop (generated by tools/make_cute_laptops.py)')
    for i, (name, v) in enumerate(ML.GAMING.items()):
        c = rgb(v['body'])
        gaming_body(v, 50 + i).save(TEX + name + '_body.png')
        Image.new('RGBA', (4, 4), darken(c, .55) + (255,)).save(TEX + name + '_feet.png')
        Image.new('RGBA', (4, 4), darken(c, .72) + (255,)).save(TEX + name + '_bed.png')
        gaming_screen(v).save(TEX + name + '_screen.png')
        save_anim(name + '_deck', [gaming_deck(v, t, 60 + i) for t in range(NF)], 4)
        save_anim(name + '_keys', [gaming_keys(v, t) for t in range(NF)], 4)
        save_anim(name + '_rgb', [gaming_rgb(t) for t in range(NF)], 4)
        save_anim(name + '_vent', [gaming_vent(v, t) for t in range(NF)], 4)
        save_anim(name + '_back', [gaming_back(v, t, 70 + i) for t in range(NF)], 4)
        write_models(name, name, ('rgb', 'vent', 'deck', 'keys', 'bed', 'feet', 'screen', 'back'), gaming_model, 'thin gaming laptop with animated RGB (generated by tools/make_cute_laptops.py)')
    print('done')

if __name__ == '__main__':
    main()
