package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.client.game.GameFactory;
import dev.cutemod.client.game.MiniGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Runs one of the mini games inside the computer window. */
public class GameApp extends App {
    private static final int OX = (W - MiniGame.W) / 2;
    private static final int OY = (H - MiniGame.H) / 2;

    private final String id;
    private final ComputerColor color; // null for games that are not tied to a computer color
    private final MiniGame game;
    private boolean submitted = false;
    private int overTicks = 0;

    public GameApp(ComputerColor color) {
        this(color.id, color, GameFactory.create(color));
    }

    /** A game from the Games folder that has no computer of its own (no block record). */
    public static GameApp extra(String id) {
        return new GameApp(id, null, GameFactory.createExtra(id));
    }

    private GameApp(String id, ComputerColor color, MiniGame game) {
        this.id = id;
        this.color = color;
        this.game = game;
        this.game.reset();
    }

    @Override
    public Component title() { return Component.translatable("cutemod.game." + id); }

    @Override
    public Component hint() { return Component.translatable(game.hintKey()); }

    @Override
    public Component status() { return game.status(); }

    @Override
    public boolean showRecord() { return color != null && shell != null && shell.color() == color; }

    private void restart() {
        game.reset();
        submitted = false;
        overTicks = 0;
    }

    @Override
    public void mouse(int x, int y) { game.setMouse(x - OX, y - OY); }

    @Override
    public void tick() {
        if (!game.over) game.tick();
        else overTicks++;
        if (game.over && !submitted) {
            submitted = true;
            Progress.onGame(id, game.score, game.isWin());
            if (game.score > 0 && color != null) shell.submitScore(color, game.score);
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        rect(g, 0, 0, W, H, 0xFF1B1422);
        rect(g, OX - 2, OY - 2, MiniGame.W + 4, MiniGame.H + 4, 0xFF3A2A4A);
        g.enableScissor(shell.absX() + OX, shell.absY() + OY,
                shell.absX() + OX + MiniGame.W, shell.absY() + OY + MiniGame.H);
        g.pose().pushPose();
        g.pose().translate(OX, OY, 0);
        game.render(g);
        if (game.over) renderGameOver(g);
        g.pose().popPose();
        g.disableScissor();
    }

    private void renderGameOver(GuiGraphics g) {
        int w = 150, h = 48, x = (MiniGame.W - w) / 2, y = (MiniGame.H - h) / 2;
        var font = font();
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFFFFFFFF);
        g.fill(x, y, x + w, y + h, 0xE0201828);
        g.drawCenteredString(font, game.endTitle(), x + w / 2, y + 7, 0xFFFFD866);
        g.drawCenteredString(font, Component.translatable("cutemod.ui.score", game.score), x + w / 2, y + 20, 0xFFFFFFFF);
        g.drawCenteredString(font, Component.translatable("cutemod.ui.restart"), x + w / 2, y + 33, 0xFFB8B0C8);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (game.over) {
            if (overTicks > 20) restart();
            return true;
        }
        int lx = x - OX, ly = y - OY;
        if (in(lx, ly, 0, 0, MiniGame.W, MiniGame.H)) {
            game.click(lx, ly, button);
            return true;
        }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (game.over) {
            if ((keyCode == 32 || keyCode == 257) && overTicks > 20) { // space / enter
                restart();
                return true;
            }
            return false;
        }
        return game.key(keyCode);
    }
}
