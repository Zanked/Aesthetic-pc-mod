package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * The desktop. The wallpaper, menu bar and Dock are drawn by the computer screen; this class owns the apps
 * (the Dock launches them with launch(i)) and draws the desktop widget.
 */
public class Desktop extends App {
    public static final int ICONS = 12;

    private BrowserApp browser;
    private NotepadApp notes;
    private PaintApp paint;
    private CalcApp calc;
    private MusicApp music;
    private PetApp pet;
    private ShopApp shop;
    private QuestApp quest;
    private TerminalApp terminal;

    @Override
    public Component title() { return Component.translatable("cutemod.os.title"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.desktop"); }

    /** Name of the app with this Dock index. */
    public String label(int i) {
        return switch (i) {
            case 0 -> t("cutemod.game." + shell.color().id);
            case 1 -> t("cutemod.os.games");
            case 2 -> t("cutemod.os.browser");
            case 3 -> t("cutemod.os.notes");
            case 4 -> t("cutemod.os.paint");
            case 5 -> t("cutemod.os.calc");
            case 7 -> t("cutemod.os.music");
            case 8 -> t("cutemod.os.pet");
            case 9 -> t("cutemod.os.shop");
            case 10 -> t("cutemod.os.quest");
            case 11 -> t("cutemod.os.terminal");
            default -> t("cutemod.os.settings");
        };
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        // the wallpaper is drawn behind everything by the computer screen; here is just a calendar widget
        LocalDate d = LocalDate.now();
        int x = W - 56, y = 8, w = 46, h = 48;
        rect(g, x + 1, y + 2, w, h, 0x44000000);
        rect(g, x, y, w, h, 0xEEFFFFFF);
        rect(g, x, y, w, 12, 0xFFE5484D);
        String month = d.getMonth().getDisplayName(TextStyle.SHORT, Locale.getDefault()).toUpperCase(Locale.ROOT);
        g.drawString(font(), month, x + (w - font().width(month)) / 2, y + 2, 0xFFFFFFFF, false);
        String day = Integer.toString(d.getDayOfMonth());
        g.pose().pushPose();
        g.pose().translate(x + w / 2f, y + 20, 0);
        g.pose().scale(2.2f, 2.2f, 1f);
        g.drawString(font(), day, -font().width(day) / 2, 0, 0xFF3A2A3A, false);
        g.pose().popPose();
        String dow = d.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.getDefault());
        g.drawString(font(), dow, x + (w - font().width(dow)) / 2, y + h - 10, 0xFF8A7AA8, false);
    }

    /** Which Dock icon belongs to the running app (-1 = none / the desktop itself). */
    public int activeIndex(App a) {
        if (a instanceof GamesApp) return 1;
        if (a instanceof GameApp) return 0;
        if (a instanceof BrowserApp) return 2;
        if (a instanceof NotepadApp) return 3;
        if (a instanceof PaintApp) return 4;
        if (a instanceof CalcApp) return 5;
        if (a instanceof SettingsApp) return 6;
        if (a instanceof MusicApp) return 7;
        if (a instanceof PetApp) return 8;
        if (a instanceof ShopApp) return 9;
        if (a instanceof QuestApp) return 10;
        if (a instanceof TerminalApp) return 11;
        return -1;
    }

    /** Draws the 32x32 icon of app number i at x,y (the Dock scales it with the pose). */
    public static void drawIcon(GuiGraphics g, int i, int x, int y, int body) {
        switch (i) {
            case 0 -> { // gamepad in the computer's color
                rect(g, x + 1, y + 8, 30, 18, 0xFF3A2A3A);
                rect(g, x + 2, y + 9, 28, 16, 0xFF000000 | body);
                rect(g, x + 7, y + 16, 9, 2, 0xFF3A2A3A);
                rect(g, x + 10, y + 13, 3, 8, 0xFF3A2A3A);
                disc(g, x + 22, y + 15, 2, 0xFFE5484D);
                disc(g, x + 26, y + 19, 2, 0xFF2F7FD6);
            }
            case 1 -> { // folder
                rect(g, x + 2, y + 6, 13, 5, 0xFFE0A93B);
                rect(g, x + 2, y + 10, 28, 18, 0xFFF3C45A);
                rect(g, x + 2, y + 10, 28, 2, 0xFFFFE08A);
                rect(g, x + 12, y + 16, 8, 6, 0xFF3A2A3A);
                rect(g, x + 14, y + 17, 4, 1, 0xFF8FD39A);
            }
            case 2 -> { // globe
                disc(g, x + 16, y + 16, 14, 0xFF2F7FD6);
                rect(g, x + 8, y + 8, 9, 5, 0xFF5BBF6A);
                rect(g, x + 18, y + 16, 8, 7, 0xFF5BBF6A);
                rect(g, x + 7, y + 19, 5, 5, 0xFF5BBF6A);
                rect(g, x + 3, y + 16, 26, 1, 0x66FFFFFF);
                rect(g, x + 16, y + 3, 1, 26, 0x66FFFFFF);
            }
            case 3 -> { // notepad
                rect(g, x + 6, y + 2, 20, 28, 0xFF3A2A3A);
                rect(g, x + 7, y + 3, 18, 26, 0xFFFFFFFF);
                rect(g, x + 7, y + 3, 18, 4, 0xFFF58FB8);
                for (int l = 0; l < 4; l++) rect(g, x + 10, y + 11 + l * 4, 12, 1, 0xFF9AA0C0);
            }
            case 5 -> { // calculator
                rect(g, x + 5, y + 2, 22, 28, 0xFF3A2A3A);
                rect(g, x + 6, y + 3, 20, 26, 0xFFF6F0FA);
                rect(g, x + 8, y + 5, 16, 7, 0xFFC8E6B8);
                for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++)
                    rect(g, x + 8 + c * 6, y + 15 + r * 5, 4, 3, c == 2 && r == 2 ? 0xFFF58FB8 : 0xFF8A7AA8);
            }
            case 6 -> { // settings: sliders
                rect(g, x + 3, y + 4, 26, 24, 0xFF3A2A3A);
                rect(g, x + 4, y + 5, 24, 22, 0xFFF6F0FA);
                for (int l = 0; l < 3; l++) {
                    rect(g, x + 7, y + 9 + l * 6, 18, 2, 0xFFB9A8C8);
                    rect(g, x + 9 + ((l * 7 + 3) % 12), y + 7 + l * 6, 4, 6, 0xFFF58FB8);
                }
            }
            case 7 -> { // music player: a note on a dark square
                rect(g, x + 3, y + 3, 26, 26, 0xFF3A2A3A);
                rect(g, x + 4, y + 4, 24, 24, 0xFF6A4A9A);
                disc(g, x + 13, y + 22, 4, 0xFFFFFFFF);
                rect(g, x + 16, y + 8, 2, 15, 0xFFFFFFFF);
                rect(g, x + 16, y + 8, 8, 3, 0xFFFFFFFF);
                rect(g, x + 22, y + 11, 2, 4, 0xFFFFFFFF);
            }
            case 8 -> { // tamagotchi: an egg with a face
                rect(g, x + 13, y + 1, 6, 1, 0xFFB9A8C8);
                rect(g, x + 13, y + 1, 1, 4, 0xFFB9A8C8);
                rect(g, x + 18, y + 1, 1, 4, 0xFFB9A8C8);
                disc(g, x + 16, y + 19, 12, 0xFFFFF3B0);
                disc(g, x + 16, y + 11, 8, 0xFFFFF3B0);
                rect(g, x + 11, y + 16, 2, 3, 0xFF3A2A3A);
                rect(g, x + 19, y + 16, 2, 3, 0xFF3A2A3A);
                rect(g, x + 14, y + 22, 4, 1, 0xFF3A2A3A);
                rect(g, x + 13, y + 21, 1, 1, 0xFF3A2A3A);
                rect(g, x + 18, y + 21, 1, 1, 0xFF3A2A3A);
                rect(g, x + 8, y + 22, 3, 2, 0xFFF58FB8);
                rect(g, x + 21, y + 22, 3, 2, 0xFFF58FB8);
            }
            case 9 -> { // shop: a bag with a coin
                rect(g, x + 10, y + 5, 12, 6, 0xFFC98B5A);
                rect(g, x + 5, y + 10, 22, 18, 0xFFC98B5A);
                rect(g, x + 9, y + 9, 14, 2, 0xFF8A5A3A);
                disc(g, x + 16, y + 19, 5, 0xFFFFC832);
                rect(g, x + 15, y + 16, 2, 6, 0xFFB98A10);
            }
            case 10 -> { // diary: a book with an exclamation mark
                rect(g, x + 5, y + 3, 22, 25, 0xFF8A3A5A);
                rect(g, x + 8, y + 5, 17, 21, 0xFFFFF6D8);
                rect(g, x + 15, y + 8, 3, 9, 0xFFE5484D);
                rect(g, x + 15, y + 19, 3, 3, 0xFFE5484D);
            }
            case 11 -> { // terminal
                rect(g, x + 2, y + 5, 28, 22, 0xFF3A2A3A);
                rect(g, x + 3, y + 6, 26, 20, 0xFF0B140E);
                rect(g, x + 7, y + 11, 2, 2, 0xFFB6F59A);
                rect(g, x + 9, y + 13, 2, 2, 0xFFB6F59A);
                rect(g, x + 7, y + 15, 2, 2, 0xFFB6F59A);
                rect(g, x + 14, y + 17, 7, 2, 0xFFB6F59A);
            }
            default -> { // paint palette
                disc(g, x + 16, y + 16, 14, 0xFFF3D9B1);
                disc(g, x + 9, y + 13, 3, 0xFFE5484D);
                disc(g, x + 16, y + 8, 3, 0xFFF3D46A);
                disc(g, x + 23, y + 13, 3, 0xFF5BBF6A);
                disc(g, x + 22, y + 22, 3, 0xFF2F7FD6);
                disc(g, x + 11, y + 22, 3, 0xFFB57BD6);
            }
        }
    }

    /** Opens the app with this Dock index. */
    public void launch(int i) {
        switch (i) {
            case 0 -> shell.open(new GameApp(shell.color()));
            case 1 -> shell.open(new GamesApp());
            case 2 -> {
                if (browser == null) browser = new BrowserApp();
                shell.open(browser);
            }
            case 3 -> {
                if (notes == null) notes = new NotepadApp();
                shell.open(notes);
            }
            case 4 -> {
                if (paint == null) paint = new PaintApp();
                shell.open(paint);
            }
            case 5 -> {
                if (calc == null) calc = new CalcApp();
                shell.open(calc);
            }
            case 7 -> {
                if (music == null) music = new MusicApp();
                shell.open(music);
            }
            case 8 -> {
                if (pet == null) pet = new PetApp();
                shell.open(pet);
            }
            case 9 -> {
                if (shop == null) shop = new ShopApp();
                shell.open(shop);
            }
            case 10 -> {
                if (quest == null) quest = new QuestApp();
                shell.open(quest);
            }
            case 11 -> {
                if (terminal == null) terminal = new TerminalApp();
                shell.open(terminal);
            }
            default -> shell.open(new SettingsApp());
        }
    }
}
