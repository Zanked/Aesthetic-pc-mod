package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * Everything the player earns on the computers, shared by all of them (it is saved on this PC in
 * cutemod_progress.txt): coins, shop purchases, achievements, daily tasks and the story quest.
 * Apps report what happens with the on...() methods, the rest is decided here.
 */
public final class Progress {
    private Progress() {}

    public record Ach(String id, String counter, int target, int reward) {}

    public record Daily(String counter, int target, int reward) {}

    public static final Ach[] ACHS = {
            new Ach("first_game", "games", 1, 5),
            new Ach("games10", "games", 10, 20),
            new Ach("score100", "bestcoins", 15, 15),
            new Ach("feed10", "feed", 10, 15),
            new Ach("pet20", "pet", 20, 10),
            new Ach("scary_all", "scary_read", 4, 15),
            new Ach("popups10", "popups", 10, 10),
            new Ach("hacker", "cmds", 8, 20),
            new Ach("rich", "earned", 200, 25),
            new Ach("shopper", "bought", 3, 15),
            new Ach("treats5", "treats_used", 5, 10),
            new Ach("quest", "quest_done", 1, 50),
    };

    public static final Daily[] DAILY = {
            new Daily("games", 2, 10),
            new Daily("feed", 1, 5),
            new Daily("pet", 3, 5),
    };

    /** Coins for finishing each chapter of the story. */
    public static final int[] QUEST_REWARD = {10, 10, 15, 20, 20, 25, 100};
    public static final int QUEST_STEPS = QUEST_REWARD.length;

    /**
     * A "good" result in each game; it is worth about 10 coins. Games count points very differently
     * (a Flappy Cat run is ~10 points, Merge Cubes is ~1000), so the coins are scaled per game.
     */
    private static final Map<String, Integer> PAR = Map.ofEntries(
            Map.entry("pink", 10),      // Flappy Cat: pipes
            Map.entry("green", 300),    // Minesweeper: a win gives up to 500
            Map.entry("white", 12),     // Panda Snake: food
            Map.entry("blue", 15),      // Penguin Fishing: fish
            Map.entry("orange", 50),    // Fox Memory: 200 - 8 per move
            Map.entry("purple", 30),    // Ender Dodge: seconds survived
            Map.entry("yellow", 20),    // Whack-a-Bee: hits
            Map.entry("red", 700),      // Ladybug Match
            Map.entry("breakout", 200), // Cookie Breaker
            Map.entry("cubes", 1000),   // Merge Cubes
            Map.entry("pong", 40),      // Slime Pong
            Map.entry("bees", 300),     // Bee Invaders
            Map.entry("horror", 100),   // Something in the Dark: candles x 10
            Map.entry("maze", 800),     // Dark Corridor: a win is 800 or more
            Map.entry("craft", 300),    // MiniCraft: blocks mined + zombies, a win (3 diamonds) adds 300
            Map.entry("zombies", 600)); // Zombie Shooter: 10 per hit, 60 per kill, 100 per round

    /** The most coins that games can give in one day (quests, achievements and tasks are not limited). */
    public static final int GAME_COIN_CAP = 150;

    /** Coins for a finished game: a par score gives 10 coins, at most 25 per game. */
    public static int coinsFor(String id, int score) {
        int par = PAR.getOrDefault(id, 100);
        return Math.max(0, Math.min(25, (int) Math.round(10.0 * score / par)));
    }

    private static boolean loaded, dirty;
    private static int coins, step, streak, saveDelay;
    private static long lastDay;
    private static String equipped = "";
    private static final Map<String, Integer> counters = new HashMap<>();
    private static final Map<String, Integer> daily = new HashMap<>();
    private static final Set<String> owned = new LinkedHashSet<>();
    private static final Set<String> ach = new HashSet<>();

    private static final List<String> toasts = new ArrayList<>();
    private static String shown = "";
    private static int toastTimer;

    // ---------- save / load ----------
    private static Path file() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("cutemod_progress.txt");
    }

    private static int geti(Properties p, String k, int d) {
        try { return Integer.parseInt(p.getProperty(k, Integer.toString(d)).trim()); } catch (Exception e) { return d; }
    }

    private static void fill(Set<String> set, String csv) {
        if (csv == null || csv.isBlank()) return;
        for (String s : csv.split(",")) if (!s.isBlank()) set.add(s.trim());
    }

    private static void ensure() {
        if (loaded) return;
        loaded = true;
        try {
            Path p = file();
            if (Files.exists(p)) {
                Properties pr = new Properties();
                try (var r = Files.newBufferedReader(p)) { pr.load(r); }
                coins = geti(pr, "coins", 0);
                step = Math.max(0, Math.min(QUEST_STEPS, geti(pr, "step", 0)));
                streak = geti(pr, "streak", 0);
                lastDay = geti(pr, "lastday", 0);
                equipped = pr.getProperty("equipped", "");
                fill(owned, pr.getProperty("own"));
                fill(ach, pr.getProperty("ach"));
                for (String k : pr.stringPropertyNames()) {
                    if (k.startsWith("c.")) counters.put(k.substring(2), geti(pr, k, 0));
                    else if (k.startsWith("d.")) daily.put(k.substring(2), geti(pr, k, 0));
                }
            }
        } catch (Exception ignored) {
        }
        newDay();
    }

    public static void save() {
        if (!loaded) return;
        try {
            Properties pr = new Properties();
            pr.setProperty("coins", Integer.toString(coins));
            pr.setProperty("step", Integer.toString(step));
            pr.setProperty("streak", Integer.toString(streak));
            pr.setProperty("lastday", Long.toString(lastDay));
            pr.setProperty("equipped", equipped);
            pr.setProperty("own", String.join(",", owned));
            pr.setProperty("ach", String.join(",", ach));
            counters.forEach((k, v) -> pr.setProperty("c." + k, Integer.toString(v)));
            daily.forEach((k, v) -> pr.setProperty("d." + k, Integer.toString(v)));
            try (var w = Files.newBufferedWriter(file())) { pr.store(w, "Cute Computers progress"); }
            dirty = false;
        } catch (Exception ignored) {
        }
    }

    /** First visit of a new day: reset daily tasks and give the login bonus (it grows with the streak). */
    private static void newDay() {
        long today = System.currentTimeMillis() / 86_400_000L;
        if (lastDay == today) return;
        streak = (lastDay == today - 1) ? streak + 1 : 1;
        lastDay = today;
        daily.clear();
        int bonus = Math.min(streak, 7) * 3;
        addCoins(bonus);
        toast("cutemod.toast.daily_bonus", bonus, streak);
        dirty = true;
    }

    // ---------- coins ----------
    public static int coins() { ensure(); return coins; }

    private static void addCoins(int n) {
        coins += n;
        counters.merge("earned", n, Integer::sum);
        dirty = true;
    }

    /** Give coins and show a pop-up. */
    public static void earn(int n) {
        ensure();
        if (n <= 0) return;
        addCoins(n);
        toast("cutemod.toast.coins", n);
        checkAch();
    }

    // ---------- counters, achievements, daily tasks ----------
    public static int count(String key) { ensure(); return counters.getOrDefault(key, 0); }

    public static int dailyCount(String key) { ensure(); return daily.getOrDefault(key, 0); }

    /** Coins earned from games today (for the diary). */
    public static int gameCoinsToday() { ensure(); return daily.getOrDefault("game_coins", 0); }

    public static boolean dailyDone(String key) { ensure(); return daily.containsKey("done_" + key); }

    public static int streak() { ensure(); return streak; }

    public static boolean hasAch(String id) { ensure(); return ach.contains(id); }

    public static void bump(String key) {
        ensure();
        counters.merge(key, 1, Integer::sum);
        daily.merge(key, 1, Integer::sum);
        dirty = true;
        checkAch();
        checkDaily();
    }

    private static void setMax(String key, int v) {
        if (v > counters.getOrDefault(key, 0)) { counters.put(key, v); dirty = true; checkAch(); }
    }

    private static void checkAch() {
        for (Ach a : ACHS) {
            if (!ach.contains(a.id()) && counters.getOrDefault(a.counter(), 0) >= a.target()) {
                ach.add(a.id());
                addCoins(a.reward());
                toast("cutemod.toast.ach", Component.translatable("cutemod.ach." + a.id()).getString(), a.reward());
                dirty = true;
            }
        }
    }

    private static void checkDaily() {
        for (Daily d : DAILY) {
            String done = "done_" + d.counter();
            if (!daily.containsKey(done) && daily.getOrDefault(d.counter(), 0) >= d.target()) {
                daily.put(done, 1);
                addCoins(d.reward());
                toast("cutemod.toast.task", Component.translatable("cutemod.task." + d.counter()).getString(), d.reward());
                dirty = true;
            }
        }
    }

    // ---------- shop ----------
    public static boolean owned(String id) { ensure(); return owned.contains(id); }

    public static boolean buy(String id, int price) {
        ensure();
        if (owned.contains(id) || coins < price) return false;
        coins -= price;
        owned.add(id);
        dirty = true;
        bump("bought");
        toast("cutemod.toast.bought", Component.translatable("cutemod.shop.item." + id).getString());
        save();
        return true;
    }

    // ---------- treats (things that are used up) ----------
    public static int stock(String id) { ensure(); return counters.getOrDefault("stock_" + id, 0); }

    public static boolean buyTreat(String id, int price) {
        ensure();
        if (coins < price) return false;
        coins -= price;
        counters.merge("stock_" + id, 1, Integer::sum);
        dirty = true;
        toast("cutemod.toast.bought", Component.translatable("cutemod.shop.item." + id).getString());
        save();
        return true;
    }

    /** Takes one treat from the stock. Returns false if there is none. */
    public static boolean useTreat(String id) {
        ensure();
        int n = counters.getOrDefault("stock_" + id, 0);
        if (n <= 0) return false;
        counters.put("stock_" + id, n - 1);
        dirty = true;
        return true;
    }

    public static String equipped() { ensure(); return equipped; }

    public static void equip(String id) { ensure(); equipped = id; dirty = true; save(); }

    // ---------- story quest ----------
    public static int step() { ensure(); return step; }

    public static boolean questDone() { ensure(); return step >= QUEST_STEPS; }

    /** Finish chapter "from" if the player is on it. Returns true if the story moved on. */
    public static boolean advanceIf(int from) {
        ensure();
        if (step != from) return false;
        addCoins(QUEST_REWARD[from]);
        step++;
        dirty = true;
        if (step >= QUEST_STEPS) {
            owned.add("acc_crown");
            counters.put("quest_done", 1);
            toast("cutemod.toast.finale");
            checkAch();
        } else {
            toast("cutemod.toast.chapter", Component.translatable("cutemod.quest." + from + ".title").getString(), QUEST_REWARD[from]);
        }
        save();
        return true;
    }

    // ---------- events reported by the apps ----------
    public static void onPage(String id) {
        ensure();
        if (id.startsWith("scary") && id.length() == 6 && count("v_" + id) == 0) {
            counters.put("v_" + id, 1);
            bump("scary_read");
        }
        if (step == 0 && count("scary_read") >= 4) advanceIf(0);
        if (step == 1 && id.equals("mail")) advanceIf(1);
    }

    public static void onGame(String id, int score, boolean won) {
        ensure();
        bump("games");
        int c = coinsFor(id, score);
        setMax("bestcoins", c);
        int left = Math.max(0, GAME_COIN_CAP - daily.getOrDefault("game_coins", 0));
        if (c > left) {
            c = left;
            if (!daily.containsKey("cap_shown")) { // tell the player once a day
                daily.put("cap_shown", 1);
                toast("cutemod.toast.cap");
            }
        }
        if (c > 0) {
            daily.merge("game_coins", c, Integer::sum);
            earn(c);
        }
        if (step == 4 && id.equals("horror") && score >= 30) advanceIf(4);
        if (step == 6 && id.equals("maze") && won) advanceIf(6);
    }

    public static void onPet(String action) {
        ensure();
        bump(action);
        if (!action.equals("pet")) addCoins(1);
        if (step == 5 && !action.equals("pet")) {
            bump("q_" + action);
            if (count("q_feed") >= 3 && count("q_play") >= 2) advanceIf(5);
        }
    }

    public static void onVideoEnd(int video) {
        ensure();
        if (count("video" + video) == 0) {
            counters.put("video" + video, 1);
            addCoins(2);
            dirty = true;
        }
    }

    public static void onPopupClosed() { bump("popups"); }

    /** A terminal command was used for the first time. */
    public static void onCommand(String name) {
        ensure();
        if (count("cmd_" + name) == 0) {
            counters.put("cmd_" + name, 1);
            bump("cmds");
        }
    }

    // ---------- pop-up messages ----------
    public static void toast(String key, Object... args) {
        toasts.add(Component.translatable(key, args).getString());
    }

    /** Called 60 times per second by the computer screen. */
    public static void tick() {
        if (toastTimer > 0) toastTimer--;
        else if (!toasts.isEmpty()) { shown = toasts.remove(0); toastTimer = 170; }
        if (dirty && ++saveDelay > 180) { saveDelay = 0; save(); }
    }

    public static void drawCoin(GuiGraphics g, int x, int y) {
        int c = 0xFFFFC832, d = 0xFFB98A10;
        g.fill(x + 2, y, x + 5, y + 1, c);
        g.fill(x + 1, y + 1, x + 6, y + 2, c);
        g.fill(x, y + 2, x + 7, y + 5, c);
        g.fill(x + 1, y + 5, x + 6, y + 6, c);
        g.fill(x + 2, y + 6, x + 5, y + 7, d);
        g.fill(x + 3, y + 2, x + 4, y + 5, d);
    }

    /** The little message that slides in at the top of the screen. */
    public static void renderToast(GuiGraphics g) {
        if (toastTimer <= 0 || shown.isEmpty()) return;
        Font f = Minecraft.getInstance().font;
        int w = Math.min(App.W - 10, f.width(shown) + 22), h = 16;
        int age = 170 - toastTimer;
        int slide = age < 12 ? (12 - age) * (h + 4) / 12 : toastTimer < 12 ? (12 - toastTimer) * (h + 4) / 12 : 0;
        int x = (App.W - w) / 2, y = 3 - slide;
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF3A2A4A);
        g.fill(x, y, x + w, y + h, 0xF0FFF6D8);
        drawCoin(g, x + 5, y + 4);
        g.drawString(f, shown, x + 16, y + 4, 0xFF3A2A3A, false);
    }
}
