package dev.cutemod.net;

import dev.cutemod.data.SkribblCanvas;
import dev.cutemod.data.SkribblGame;
import dev.cutemod.data.SkribblWords;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * The server side of online Scribble Pals: rooms with eight places (people, computer players or nobody) and the games that run in them.
 * The rules are in {@link SkribblGame}; this class only connects them to the players: it tells every person what changed, passes the
 * drawing operations on and ticks the games 20 times a second. A place that is still open when the game starts is dropped, and computer
 * players join until there are three players. Rooms live in memory only.
 */
public final class SkribblServer {
    private SkribblServer() {}

    private static final int SLOTS = SkribblGame.SLOTS;

    private static final class Room implements SkribblGame.Sink {
        UUID host;
        final UUID[] who = new UUID[SLOTS];
        final SkribblGame game = new SkribblGame(this, new Random());
        int roundsIdx = 1, secondsIdx = 1, mode, wordSet;
        boolean dirty, wasRunning;

        Room() {
            game.type[1] = SkribblGame.BOT;
            game.type[2] = SkribblGame.BOT;
            for (int i = 3; i < SLOTS; i++) game.type[i] = SkribblGame.OPEN;
        }

        @Override public void changed() { dirty = true; }

        @Override public void draw(int kind, String op, int except) { sendDraw(this, kind, op, except); }

        @Override public void chat(int kind, int from, String text, int arg, int audience) { sendChat(this, kind, from, text, arg, audience); }

        @Override public void tele(int audience, int kind, int chain, int step, int author, String text, byte[] pic) { sendTele(this, audience, kind, chain, step, author, text, pic); }
    }

    private static final List<Room> rooms = new ArrayList<>();
    private static final Map<UUID, Room> roomOf = new HashMap<>();
    private static final Map<UUID, Long> lastRequest = new HashMap<>(), lastSay = new HashMap<>(), lastEmoji = new HashMap<>();
    private static MinecraftServer server;

    public static void handle(ServerPlayer sp, SkribblActionPayload p) {
        server = sp.getServer();
        if (server == null) return;
        UUID me = sp.getUUID();
        Room r = roomOf.get(me);
        int slot = r == null ? -1 : slotOf(r, me);
        switch (p.action()) {
            case 0 -> request(sp);
            case 1 -> create(sp);
            case 2 -> join(sp, p.text());
            case 3 -> { leave(me); push(sp, 0); }
            case 4 -> slotClick(sp, p.a());
            case 5 -> start(sp);
            case 6 -> { if (isHost(r, me) && !r.game.running() && p.a() >= 0 && p.a() < SkribblGame.ROUNDS.length) { r.roundsIdx = p.a(); pushRoom(r, 0); } }
            case 7 -> { if (isHost(r, me) && !r.game.running() && p.a() >= 0 && p.a() < SkribblGame.SECONDS.length) { r.secondsIdx = p.a(); pushRoom(r, 0); } }
            case 8 -> { if (r != null && slot >= 0) r.game.pick(slot, p.a()); }
            case 9 -> { if (r != null && slot >= 0) r.game.op(slot, p.text()); }
            case 10 -> { if (r != null && slot >= 0) r.game.undo(slot); }
            case 11 -> { if (r != null && slot >= 0) r.game.clearBoard(slot); }
            case 12 -> say(r, slot, me, p.text());
            case 13 -> { if (r != null && slot >= 0) r.game.like(slot); }
            case 14 -> { if (r != null && slot >= 0 && r.game.addCustom(slot, p.text())) pushRoom(r, 0); }
            case 15 -> { if (r != null && slot >= 0 && !r.game.running()) { r.game.clearCustom(slot); pushRoom(r, 0); } }
            case 16 -> { if (isHost(r, me) && !r.game.running() && p.a() >= 0 && p.a() < SkribblWords.SETS) { r.wordSet = p.a(); pushRoom(r, 0); } }
            case 17 -> emoji(r, slot, me, p.a());
            case 18 -> { if (r != null && slot >= 0) r.game.submitText(slot, p.text()); }
            case 19 -> { if (r != null && slot >= 0) r.game.submitPicture(slot); }
            case 20 -> { if (isHost(r, me) && !r.game.running() && (p.a() == 0 || p.a() == 1)) { r.mode = p.a(); pushRoom(r, 0); } }
            default -> { }
        }
        if (r != null) flush(r);
    }

    /** Called 20 times a second. */
    public static void tick(MinecraftServer s) {
        server = s;
        if (rooms.isEmpty()) return;
        for (Room r : new ArrayList<>(rooms)) {
            if (r.game.running()) r.game.tick();
            flush(r);
        }
    }

    private static boolean isHost(Room r, UUID me) { return r != null && r.host.equals(me); }

    private static ServerPlayer online(UUID id) { return id == null || server == null ? null : server.getPlayerList().getPlayer(id); }

    private static String name(UUID id) {
        ServerPlayer p = online(id);
        return p == null ? "" : p.getGameProfile().getName();
    }

    private static int slotOf(Room r, UUID id) {
        for (int i = 0; i < SLOTS; i++) if (id.equals(r.who[i])) return i;
        return -1;
    }

    private static int openSlots(Room r) {
        int n = 0;
        for (int i = 0; i < SLOTS; i++) if (r.game.type[i] == SkribblGame.OPEN && r.who[i] == null) n++;
        return n;
    }

    private static boolean anyone(Room r) {
        for (UUID u : r.who) if (u != null) return true;
        return false;
    }

    // ------------------------------------------------------------------ what the player sees

    private static void push(ServerPlayer sp, int notice) {
        if (server == null) return;
        Room mine = roomOf.get(sp.getUUID());
        List<String> hosts = new ArrayList<>();
        List<Integer> open = new ArrayList<>();
        for (Room r : rooms) {
            if (r == mine || r.game.running()) continue;
            int o = openSlots(r);
            String h = name(r.host);
            if (o > 0 && !h.isEmpty()) { hosts.add(h); open.add(o); }
        }
        List<Integer> types = new ArrayList<>();
        List<String> names = new ArrayList<>();
        boolean inRoom = mine != null, inGame = false, youHost = false;
        int slot = 0, ri = 1, si = 1, mode = 0, set = 0, cc = 0, cm = 0;
        if (mine != null) {
            inGame = mine.game.running();
            youHost = mine.host.equals(sp.getUUID());
            slot = Math.max(0, slotOf(mine, sp.getUUID()));
            ri = mine.roundsIdx;
            si = mine.secondsIdx;
            mode = mine.mode;
            set = mine.wordSet;
            cc = mine.game.customCount();
            cm = mine.game.customMine(slot);
            for (int i = 0; i < SLOTS; i++) {
                types.add(mine.game.type[i]);
                names.add(mine.game.type[i] == SkribblGame.EMPTY || mine.game.type[i] == SkribblGame.OPEN ? "" : mine.game.name[i]);
            }
        } else {
            for (int i = 0; i < SLOTS; i++) { types.add(0); names.add(""); }
        }
        PacketDistributor.sendToPlayer(sp, new SkribblLobbyPayload(notice, hosts, open, inRoom, inGame, youHost, slot, types, names, ri, si, mode, set, cc, cm));
    }

    private static void pushTo(UUID id, int notice) {
        ServerPlayer p = online(id);
        if (p != null) push(p, notice);
    }

    /** The lobby picture and the game state for everybody in the room. */
    private static void pushRoom(Room r, int notice) {
        for (int i = 0; i < SLOTS; i++) if (r.who[i] != null) pushTo(r.who[i], notice);
        if (r.game.running()) sendState(r);
    }

    private static void sendState(Room r) {
        SkribblGame g = r.game;
        String en = g.hint("en"), ru = g.hint("ru");
        List<Integer> scores = new ArrayList<>(), gains = new ArrayList<>();
        for (int i = 0; i < SLOTS; i++) { scores.add(g.score[i]); gains.add(g.gain[i]); }
        for (int i = 0; i < SLOTS; i++) {
            ServerPlayer p = online(r.who[i]);
            if (p == null) continue;
            List<String> choices = new ArrayList<>();
            if (g.phase == SkribblGame.PICK && i == g.drawer) choices.addAll(java.util.Arrays.asList(g.choices));
            boolean tele = g.phase >= SkribblGame.T_WRITE;
            int mask = tele ? g.doneMask() : g.guessedMask();
            PacketDistributor.sendToPlayer(p, new SkribblStatePayload(g.phase, tele ? g.step : g.round, tele ? g.steps : g.rounds, g.drawer, g.timeLeft, g.timeTotal,
                    g.wordFor(i), choices, en, ru, scores, gains, mask, g.likes, g.liked[i]));
        }
    }

    /** Send what changed (and, when a game has just ended, put the room back into its lobby shape). */
    private static void flush(Room r) {
        boolean running = r.game.running();
        if (r.wasRunning && !running) {                                    // the game is over: back to the room
            for (int i = 1; i < SLOTS; i++) if (r.game.type[i] == SkribblGame.EMPTY && r.who[i] == null) r.game.type[i] = SkribblGame.OPEN;
            r.wasRunning = false;
            r.dirty = false;
            pushRoom(r, 0);
            if (!anyone(r)) rooms.remove(r);
            return;
        }
        r.wasRunning = running;
        if (!r.dirty) return;
        r.dirty = false;
        if (running) sendState(r);
    }

    private static void sendDraw(Room r, int kind, String op, int except) {
        List<String> ops = op == null || op.isEmpty() ? List.of() : List.of(op);
        for (int i = 0; i < SLOTS; i++) {
            if (i == except) continue;
            ServerPlayer p = online(r.who[i]);
            if (p != null) PacketDistributor.sendToPlayer(p, new SkribblDrawPayload(kind, ops));
        }
    }

    private static void sendChat(Room r, int kind, int from, String text, int arg, int audience) {
        String who = from >= 0 && from < SLOTS ? r.game.name[from] : "";
        for (int i = 0; i < SLOTS; i++) {
            if (audience != SkribblGame.ALL && (audience & (1 << i)) == 0) continue;
            ServerPlayer p = online(r.who[i]);
            if (p != null) PacketDistributor.sendToPlayer(p, new SkribblChatPayload(kind, who, text, arg));
        }
    }

    private static void sendTele(Room r, int audience, int kind, int chain, int step, int author, String text, byte[] pic) {
        for (int i = 0; i < SLOTS; i++) {
            if (audience != SkribblGame.ALL && (audience & (1 << i)) == 0) continue;
            ServerPlayer p = online(r.who[i]);
            if (p != null) PacketDistributor.sendToPlayer(p, new SkribblTelePayload(kind, chain, step, author, text == null ? "" : text, pic == null ? new byte[0] : pic));
        }
    }

    private static void emoji(Room r, int slot, UUID me, int idx) {
        if (r == null || slot < 0) return;
        long now = System.currentTimeMillis();
        Long last = lastEmoji.get(me);
        if (last != null && now - last < 600) return;
        lastEmoji.put(me, now);
        r.game.emoji(slot, idx);
    }

    /** The whole picture, for a player who has just come back to the game window. */
    private static void sendBoard(Room r, ServerPlayer sp) {
        List<String> ops = r.game.canvas.ops();
        int n = ops.size();
        PacketDistributor.sendToPlayer(sp, new SkribblDrawPayload(3, new ArrayList<>(ops.subList(0, Math.min(n, 300)))));
        for (int i = 300; i < n; i += 300) PacketDistributor.sendToPlayer(sp, new SkribblDrawPayload(0, new ArrayList<>(ops.subList(i, Math.min(n, i + 300)))));
    }

    private static void request(ServerPlayer sp) {
        long now = System.currentTimeMillis();
        Long last = lastRequest.get(sp.getUUID());
        if (last != null && now - last < 400) return;
        lastRequest.put(sp.getUUID(), now);
        push(sp, 0);
        Room r = roomOf.get(sp.getUUID());
        if (r != null && r.game.running()) {
            sendState(r);
            sendBoard(r, sp);
            int slot = slotOf(r, sp.getUUID());
            if (slot >= 0) r.game.resendPrompt(slot);
        }
    }

    private static void say(Room r, int slot, UUID me, String text) {
        if (r == null || slot < 0 || text == null) return;
        long now = System.currentTimeMillis();
        Long last = lastSay.get(me);
        if (last != null && now - last < 350) return;
        lastSay.put(me, now);
        r.game.say(slot, text);
    }

    // ------------------------------------------------------------------ rooms

    private static void create(ServerPlayer sp) {
        UUID me = sp.getUUID();
        leave(me);
        Room r = new Room();
        r.host = me;
        r.who[0] = me;
        r.game.type[0] = SkribblGame.HUMAN;
        r.game.name[0] = sp.getGameProfile().getName();
        rooms.add(r);
        roomOf.put(me, r);
        push(sp, 0);
    }

    private static void join(ServerPlayer sp, String hostName) {
        UUID me = sp.getUUID();
        Room target = null;
        for (Room r : rooms) if (!r.game.running() && name(r.host).equalsIgnoreCase(hostName)) { target = r; break; }
        if (target == null || roomOf.get(me) == target) { push(sp, target == null ? 1 : 0); return; }
        int slot = -1;
        for (int i = 0; i < SLOTS && slot < 0; i++) if (target.game.type[i] == SkribblGame.OPEN && target.who[i] == null) slot = i;
        if (slot < 0) { push(sp, 1); return; }
        leave(me);
        target.who[slot] = me;
        target.game.type[slot] = SkribblGame.HUMAN;
        target.game.name[slot] = sp.getGameProfile().getName();
        roomOf.put(me, target);
        pushRoom(target, 0);
    }

    /** The player leaves his room (or the game that runs in it), or the server. */
    public static void leave(UUID me) {
        Room r = roomOf.remove(me);
        if (r == null) return;
        int slot = slotOf(r, me);
        if (slot >= 0) {
            r.who[slot] = null;
            if (r.game.running()) r.game.leave(slot, true);
            else { r.game.type[slot] = SkribblGame.OPEN; r.game.name[slot] = ""; r.game.clearCustom(slot); }
        }
        if (!anyone(r)) { rooms.remove(r); return; }
        int notice = 0;
        if (r.host.equals(me)) {
            for (int i = 0; i < SLOTS; i++) if (r.who[i] != null) { r.host = r.who[i]; break; }
            notice = 4;
        }
        pushRoom(r, notice);
        flush(r);
    }

    public static void forget(UUID me) {
        leave(me);
        lastRequest.remove(me);
        lastSay.remove(me);
        lastEmoji.remove(me);
    }

    private static void slotClick(ServerPlayer sp, int i) {
        Room r = roomOf.get(sp.getUUID());
        if (r == null || !r.host.equals(sp.getUUID()) || r.game.running() || i < 1 || i >= SLOTS) return;
        int t = r.game.type[i];
        if (sp.getUUID().equals(r.who[i])) return;
        if (t == SkribblGame.HUMAN && r.who[i] != null) {                       // a person: sent away
            UUID out = r.who[i];
            r.who[i] = null;
            r.game.type[i] = SkribblGame.OPEN;
            r.game.name[i] = "";
            roomOf.remove(out);
            pushTo(out, 2);
        } else {
            r.game.type[i] = t == SkribblGame.OPEN ? SkribblGame.BOT : t == SkribblGame.BOT ? SkribblGame.EMPTY : SkribblGame.OPEN;
        }
        pushRoom(r, 0);
    }

    private static void start(ServerPlayer sp) {
        Room r = roomOf.get(sp.getUUID());
        if (r == null || !r.host.equals(sp.getUUID()) || r.game.running()) return;
        r.game.rounds = SkribblGame.ROUNDS[r.roundsIdx];
        r.game.drawSeconds = SkribblGame.SECONDS[r.secondsIdx];
        r.game.mode = r.mode;
        r.game.wordSet = r.wordSet;
        if (!r.game.start()) return;
        r.wasRunning = true;
        pushRoom(r, 0);
    }
}
