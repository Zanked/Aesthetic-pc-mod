package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: the picture of a running game of Scribble Pals (everything except the drawing itself and the chat).
 * phase: 0 lobby, 1 the drawer picks a word, 2 drawing and guessing, 3 the word is shown, 4 the final scores, 5 telephone: write, 6 telephone: draw,
 * 7 telephone: the chains are shown. word ("english|russian"): the word if this player may see it (he draws, he guessed it, or the turn is over; in
 * telephone step 6 the phrase he has to draw), otherwise empty. choices: the three words to pick from (only for the drawer, only while picking).
 * hintEn / hintRu: the word as "_ _ A _". guessedMask: the slots that have the word (in telephone: the slots that handed in their work).
 * In telephone round / rounds are the step and the number of steps. timeLeft / timeTotal are in server ticks (20 a second).
 */
public record SkribblStatePayload(int phase, int round, int rounds, int drawer, int timeLeft, int timeTotal, String word, List<String> choices,
                                  String hintEn, String hintRu, List<Integer> scores, List<Integer> gains, int guessedMask, int likes,
                                  boolean liked) implements CustomPacketPayload {
    public static final Type<SkribblStatePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "skribbl_state"));

    private static final StreamCodec<io.netty.buffer.ByteBuf, List<Integer>> INTS =
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(16));
    private static final StreamCodec<io.netty.buffer.ByteBuf, List<String>> WORDS =
            ByteBufCodecs.stringUtf8(80).apply(ByteBufCodecs.list(8));

    public static final StreamCodec<RegistryFriendlyByteBuf, SkribblStatePayload> STREAM_CODEC = StreamCodec.of((buf, p) -> {
        ByteBufCodecs.VAR_INT.encode(buf, p.phase());
        ByteBufCodecs.VAR_INT.encode(buf, p.round());
        ByteBufCodecs.VAR_INT.encode(buf, p.rounds());
        ByteBufCodecs.VAR_INT.encode(buf, p.drawer() + 1);
        ByteBufCodecs.VAR_INT.encode(buf, p.timeLeft());
        ByteBufCodecs.VAR_INT.encode(buf, p.timeTotal());
        ByteBufCodecs.stringUtf8(80).encode(buf, p.word());
        WORDS.encode(buf, p.choices());
        ByteBufCodecs.stringUtf8(120).encode(buf, p.hintEn());
        ByteBufCodecs.stringUtf8(120).encode(buf, p.hintRu());
        INTS.encode(buf, p.scores());
        INTS.encode(buf, p.gains());
        ByteBufCodecs.VAR_INT.encode(buf, p.guessedMask());
        ByteBufCodecs.VAR_INT.encode(buf, p.likes());
        ByteBufCodecs.BOOL.encode(buf, p.liked());
    }, buf -> new SkribblStatePayload(
            ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf) - 1, ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.stringUtf8(80).decode(buf), WORDS.decode(buf), ByteBufCodecs.stringUtf8(120).decode(buf),
            ByteBufCodecs.stringUtf8(120).decode(buf), INTS.decode(buf), INTS.decode(buf), ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.BOOL.decode(buf)));

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(SkribblStatePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onSkribblState(p));
    }
}
