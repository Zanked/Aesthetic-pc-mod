package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client: "a part was installed, this is what your PC has now" (the same text the server saved under "hw"). */
public record HardwarePayload(String hw) implements CustomPacketPayload {
    public static final Type<HardwarePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "hardware"));

    public static final StreamCodec<RegistryFriendlyByteBuf, HardwarePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(64), HardwarePayload::hw,
            HardwarePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(HardwarePayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onHardware(payload.hw()));
    }
}
