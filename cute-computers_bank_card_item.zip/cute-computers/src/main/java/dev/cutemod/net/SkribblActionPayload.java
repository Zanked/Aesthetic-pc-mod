package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: something the player did in online Scribble Pals.
 * action: 0 refresh (rooms, my room, the picture), 1 make a room, 2 join the room of {@code text}, 3 leave the room (or the game),
 * 4 the host clicks slot {@code a} (1..7: open -> computer -> empty; a person in it is sent away), 5 the host starts the game,
 * 6 the host picks the number of rounds (index {@code a} 0..2), 7 the host picks the drawing time (index {@code a} 0..2),
 * 8 the drawer picks word number {@code a} (0..2), 9 a drawing operation ({@code text}, see SkribblCanvas), 10 undo, 11 clear the board,
 * 12 a chat line or a guess ({@code text}), 13 like the picture, 14 add an own word to the room ({@code text}), 15 take back my own words,
 * 16 the host picks the word set ({@code a}, see SkribblWords.SET_*), 17 a reaction (emoji number {@code a}), 18 telephone: hand in the text,
 * 19 telephone: my picture is finished, 20 the host picks the game ({@code a}: 0 draw and guess, 1 telephone).
 */
public record SkribblActionPayload(int action, int a, String text) implements CustomPacketPayload {
    public static final Type<SkribblActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "skribbl_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SkribblActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SkribblActionPayload::action,
            ByteBufCodecs.VAR_INT, SkribblActionPayload::a,
            ByteBufCodecs.stringUtf8(400), SkribblActionPayload::text,
            SkribblActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(SkribblActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) SkribblServer.handle(sp, p); });
    }
}
