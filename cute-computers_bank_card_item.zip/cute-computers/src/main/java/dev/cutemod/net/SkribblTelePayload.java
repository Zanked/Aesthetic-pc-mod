package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Server -> client, telephone game: kind 0 = the picture you have to describe in this step, kind 1 = one item of a finished chain that is
 * being shown. An item is text (a phrase, "english|russian" if a computer player wrote it) or a picture (the colours of the board, zipped).
 * author is the slot of the player who made the item.
 */
public record SkribblTelePayload(int kind, int chain, int step, int author, String text, byte[] pic) implements CustomPacketPayload {
    public static final Type<SkribblTelePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "skribbl_tele"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SkribblTelePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SkribblTelePayload::kind,
            ByteBufCodecs.VAR_INT, SkribblTelePayload::chain,
            ByteBufCodecs.VAR_INT, SkribblTelePayload::step,
            ByteBufCodecs.VAR_INT, SkribblTelePayload::author,
            ByteBufCodecs.stringUtf8(80), SkribblTelePayload::text,
            ByteBufCodecs.byteArray(12000), SkribblTelePayload::pic,
            SkribblTelePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(SkribblTelePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onSkribblTele(p));
    }
}
