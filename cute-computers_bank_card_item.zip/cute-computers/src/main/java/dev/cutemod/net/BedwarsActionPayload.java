package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: something the player did in online Bed Wars.
 * action: 0 refresh (rooms, my room), 1 make a room, 2 join the room of {@code name}, 3 leave the room (or the round),
 * 4 the host clicks slot {@code a} (1..3: open -> computer -> empty; a person in it is sent away), 5 the host picks the skill of the
 * computer players {@code a} (0..2), 6 the host starts a round (or the next one), 7 what I do: {@code a} = direction + 1 (0 = none, 1 down,
 * 2 left, 3 right, 4 up), {@code b} = bit 0 attack held, bit 1 bridge held, bit 2 put a wall (once), bits 3..5 what to buy (0 nothing, 1..4).
 */
public record BedwarsActionPayload(int action, int a, int b, String name) implements CustomPacketPayload {
    public static final Type<BedwarsActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "bedwars_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BedwarsActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, BedwarsActionPayload::action,
            ByteBufCodecs.VAR_INT, BedwarsActionPayload::a,
            ByteBufCodecs.VAR_INT, BedwarsActionPayload::b,
            ByteBufCodecs.stringUtf8(32), BedwarsActionPayload::name,
            BedwarsActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(BedwarsActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) BedwarsServer.handle(sp, p); });
    }
}
