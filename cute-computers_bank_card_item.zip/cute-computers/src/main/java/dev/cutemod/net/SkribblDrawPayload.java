package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/** Server -> client: the picture changed. kind: 0 add these operations, 1 undo the last stroke, 2 clear the board, 3 replace the board with these operations. */
public record SkribblDrawPayload(int kind, List<String> ops) implements CustomPacketPayload {
    public static final Type<SkribblDrawPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "skribbl_draw"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SkribblDrawPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SkribblDrawPayload::kind,
            ByteBufCodecs.stringUtf8(400).apply(ByteBufCodecs.list(400)), SkribblDrawPayload::ops,
            SkribblDrawPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(SkribblDrawPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onSkribblDraw(p));
    }
}
