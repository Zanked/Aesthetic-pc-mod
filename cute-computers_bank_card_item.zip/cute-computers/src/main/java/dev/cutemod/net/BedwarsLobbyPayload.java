package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: the open rooms and the room you are in (if any).
 * notice: 0 nothing, 1 the room is gone or full, 2 you were sent away, 3 not enough players to start, 4 the host left (you are the host now).
 * slotType (4 numbers): 0 empty, 1 open (waiting for a person), 2 computer player, 3 person; slotName: the name of the person.
 */
public record BedwarsLobbyPayload(int notice, List<String> hosts, List<Integer> open, boolean inRoom, boolean inGame, boolean youHost,
                                  int mySlot, List<Integer> slotType, List<String> slotName, int level) implements CustomPacketPayload {
    public static final Type<BedwarsLobbyPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "bedwars_lobby"));

    private static final StreamCodec<io.netty.buffer.ByteBuf, List<String>> NAMES =
            ByteBufCodecs.stringUtf8(32).apply(ByteBufCodecs.list(100));
    private static final StreamCodec<io.netty.buffer.ByteBuf, List<Integer>> INTS =
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(100));

    public static final StreamCodec<RegistryFriendlyByteBuf, BedwarsLobbyPayload> STREAM_CODEC = StreamCodec.of((buf, p) -> {
        ByteBufCodecs.VAR_INT.encode(buf, p.notice());
        NAMES.encode(buf, p.hosts());
        INTS.encode(buf, p.open());
        ByteBufCodecs.BOOL.encode(buf, p.inRoom());
        ByteBufCodecs.BOOL.encode(buf, p.inGame());
        ByteBufCodecs.BOOL.encode(buf, p.youHost());
        ByteBufCodecs.VAR_INT.encode(buf, p.mySlot());
        INTS.encode(buf, p.slotType());
        NAMES.encode(buf, p.slotName());
        ByteBufCodecs.VAR_INT.encode(buf, p.level());
    }, buf -> {
        int notice = ByteBufCodecs.VAR_INT.decode(buf);
        List<String> hosts = NAMES.decode(buf);
        List<Integer> open = INTS.decode(buf);
        boolean inRoom = ByteBufCodecs.BOOL.decode(buf);
        boolean inGame = ByteBufCodecs.BOOL.decode(buf);
        boolean youHost = ByteBufCodecs.BOOL.decode(buf);
        int mySlot = ByteBufCodecs.VAR_INT.decode(buf);
        List<Integer> types = INTS.decode(buf);
        List<String> names = NAMES.decode(buf);
        int level = ByteBufCodecs.VAR_INT.decode(buf);
        return new BedwarsLobbyPayload(notice, hosts, open, inRoom, inGame, youHost, mySlot, types, names, level);
    });

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(BedwarsLobbyPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onBedwarsLobby(p));
    }
}
