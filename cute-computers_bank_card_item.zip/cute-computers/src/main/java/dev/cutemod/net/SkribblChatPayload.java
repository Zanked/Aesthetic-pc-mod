package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client: a line for the chat window (kinds: see SkribblGame.K_*; the client writes the sentence in its own language). */
public record SkribblChatPayload(int kind, String name, String text, int arg) implements CustomPacketPayload {
    public static final Type<SkribblChatPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "skribbl_chat"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SkribblChatPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SkribblChatPayload::kind,
            ByteBufCodecs.stringUtf8(32), SkribblChatPayload::name,
            ByteBufCodecs.stringUtf8(120), SkribblChatPayload::text,
            ByteBufCodecs.VAR_INT, SkribblChatPayload::arg,
            SkribblChatPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(SkribblChatPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onSkribblChat(p));
    }
}
