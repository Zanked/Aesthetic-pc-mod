package dev.cutemod.item;

import dev.cutemod.data.PcHardware;
import dev.cutemod.data.PcHardware.Kind;
import dev.cutemod.data.PlayerData;
import dev.cutemod.net.HardwarePayload;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;
import java.util.UUID;

/**
 * A part for the computer: memory, a video card or a drive. Right-click a computer (or a laptop, or use it while holding a
 * laptop in the other hand) and the part goes inside. The server keeps what is installed ({@link PcHardware}); a part only
 * goes in if it is better than what the PC already has, and the part it replaces comes back to the player.
 */
public class PcPartItem extends Item {
    private final Kind kind;
    private final int level;

    public PcPartItem(Properties props, Kind kind, int level) {
        super(props);
        this.kind = kind;
        this.level = level;
    }

    public Kind kind() { return kind; }

    public int level() { return level; }

    /** Server side: put this part (one of the stack) into the player's PC. */
    public void install(ServerPlayer sp, ItemStack stack) {
        var server = sp.getServer();
        if (server == null) return;
        PlayerData data = PlayerData.get(server);
        UUID id = sp.getUUID();
        int[] hw = PcHardware.parse(data.copyOf(id).get(dev.cutemod.net.SaveDataPayload.HARDWARE));
        int have = PcHardware.effective(PcHardware.base(PcHardware.seedOf(id)), hw, kind);
        if (level <= have) {                                           // the PC is already as good (or better) here
            sp.displayClientMessage(Component.translatable("cutemod.part.worse", Component.translatable(getDescriptionId())).withStyle(ChatFormatting.RED), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.PLAYERS, 0.7F, 1.2F);
            return;
        }
        int old = hw[kind.ordinal()];
        hw[kind.ordinal()] = level;
        String text = PcHardware.write(hw);
        data.put(id, dev.cutemod.net.SaveDataPayload.HARDWARE, text);
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        if (old >= 0) {                                                // the part that was inside comes out again
            ItemStack back = ModItems.partStack(kind, old);
            if (!back.isEmpty() && !sp.getInventory().add(back)) sp.drop(back, false);
        }
        PacketDistributor.sendToPlayer(sp, new HardwarePayload(text));
        sp.displayClientMessage(Component.translatable("cutemod.part.installed", Component.translatable(getDescriptionId())).withStyle(ChatFormatting.GREEN), true);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1F, 1.3F);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.PLAYERS, 0.8F, 1.4F);
    }

    /** The name of the blob where the server notes that the player got the free first modem. */
    private static final String GIFT_KEY = "modemgift";

    /** Once per player: the first (weakest) modem as a gift, so the online apps can be switched on at all. Server side. */
    public static void giveStarterModem(ServerPlayer sp) {
        var server = sp.getServer();
        if (server == null) return;
        PlayerData data = PlayerData.get(server);
        UUID id = sp.getUUID();
        if (data.copyOf(id).get(GIFT_KEY) != null) return;
        data.put(id, GIFT_KEY, "1");
        ItemStack modem = ModItems.partStack(Kind.MODEM, PcHardware.MODEM_FIRST);
        if (modem.isEmpty()) return;
        if (!sp.getInventory().add(modem)) sp.drop(modem, false);
        sp.displayClientMessage(Component.translatable("cutemod.part.modemgift").withStyle(ChatFormatting.AQUA), false);
    }

    /** With a laptop in the other hand the part can be installed without a block. */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        ItemStack other = player.getItemInHand(hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        if (other.getItem() instanceof LaptopItem) {
            if (!level.isClientSide && player instanceof ServerPlayer sp) install(sp, stack);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        return InteractionResultHolder.pass(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        switch (kind) {
            case RAM -> tip.add(Component.translatable("cutemod.tip.part.ram", gb(PcHardware.RAM_GB[level])).withStyle(ChatFormatting.AQUA));
            case DISK -> tip.add(Component.translatable("cutemod.tip.part.disk", gb(PcHardware.DISK_GB[level])).withStyle(ChatFormatting.AQUA));
            case MODEM -> {
                tip.add(Component.translatable("cutemod.tip.part.modem", PcHardware.MODEM_MBPS[level]).withStyle(ChatFormatting.AQUA));
                if (level <= 2) tip.add(Component.translatable("cutemod.tip.part.modem.flaky").withStyle(ChatFormatting.RED));
            }
            case GPU -> {
                tip.add(Component.translatable("cutemod.tip.part.gpu", PcHardware.VRAM_GB[level]).withStyle(ChatFormatting.AQUA));
                tip.add(Component.translatable("cutemod.tip.part.gfx", Component.translatable("cutemod.gfx." + PcHardware.gpuLevel(level))).withStyle(ChatFormatting.LIGHT_PURPLE));
            }
        }
        tip.add(Component.translatable("cutemod.tip.part.install").withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable("cutemod.tip.part.better").withStyle(ChatFormatting.DARK_GRAY));
    }

    private static String gb(int gb) { return gb >= 1000 ? (gb / 1000) + " TB" : gb + " GB"; }
}
