package dev.cutemod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * The CuteBank card as a real item (a thin 3D slab, see models/item/bank_card.json). The balance is the player's own coins,
 * so it is read on the client: the tooltip shows it and a right-click prints it over the hotbar.
 * Later features of the card (pay, transfer...) go into {@link #use}.
 */
public class BankCardItem extends Item {
    public BankCardItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            player.displayClientMessage(Component.translatable("cutemod.card.balance", dev.cutemod.client.os.BankHooks.balance()).withStyle(ChatFormatting.GOLD), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        if (net.neoforged.fml.loading.FMLEnvironment.dist.isClient()) {
            tip.add(Component.translatable("cutemod.card.balance", dev.cutemod.client.os.BankHooks.balance()).withStyle(ChatFormatting.GOLD));
        }
        tip.add(Component.translatable("cutemod.tip.card.use").withStyle(ChatFormatting.GRAY));
    }
}
