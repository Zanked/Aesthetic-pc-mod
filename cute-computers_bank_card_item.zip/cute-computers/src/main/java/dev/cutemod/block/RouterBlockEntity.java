package dev.cutemod.block;

import dev.cutemod.data.WifiNet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * A Wi-Fi router: keeps the name of its network (an anvil-renamed item gives the router that name). On the CLIENT every
 * loaded router lists itself in {@link #CLIENT_ROUTERS}, so a computer can offer "the networks near you" without scanning the world.
 */
public class RouterBlockEntity extends BlockEntity {
    /** Client side only: the routers that are loaded around the player. Nothing is ever added on a server. */
    public static final List<RouterBlockEntity> CLIENT_ROUTERS = new CopyOnWriteArrayList<>();

    private String name = "";

    public RouterBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ROUTER.get(), pos, state);
    }

    /** 1..5, from the block. */
    public int routerLevel() {
        return getBlockState().getBlock() instanceof RouterBlock rb ? rb.routerLevel() : WifiNet.FIRST;
    }

    /** The name of the network. */
    public String networkName() {
        return name.isEmpty() ? WifiNet.defaultName(worldPosition.asLong()) : name;
    }

    public void setNetworkName(String n) {
        String clean = n == null ? "" : n.trim();
        if (clean.length() > 24) clean = clean.substring(0, 24);
        if (clean.equals(name)) return;
        name = clean;
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    // ---------- the client's list ----------
    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && level.isClientSide && !CLIENT_ROUTERS.contains(this)) CLIENT_ROUTERS.add(this);
    }

    @Override
    public void clearRemoved() {
        super.clearRemoved();
        if (level != null && level.isClientSide && !CLIENT_ROUTERS.contains(this)) CLIENT_ROUTERS.add(this);
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        CLIENT_ROUTERS.remove(this);
    }

    // ---------- saving and syncing ----------
    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putString("Ssid", name);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        name = tag.getString("Ssid");
    }

    /** The name an item had when it was placed (its custom name). */
    @Override
    protected void applyImplicitComponents(BlockEntity.DataComponentInput input) {
        super.applyImplicitComponents(input);
        Component custom = input.get(DataComponents.CUSTOM_NAME);
        if (custom != null) name = custom.getString().trim();
    }

    /** ...and it goes back onto the item when the router is broken. */
    @Override
    protected void collectImplicitComponents(DataComponentMap.Builder builder) {
        super.collectImplicitComponents(builder);
        if (!name.isEmpty()) builder.set(DataComponents.CUSTOM_NAME, Component.literal(name));
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag, registries);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
