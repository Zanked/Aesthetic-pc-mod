package dev.cutemod.block;

import dev.cutemod.ComputerColor;
import dev.cutemod.CuteMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.Map;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(CuteMod.MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CuteMod.MOD_ID);

    private static final Map<ComputerColor, DeferredBlock<ComputerBlock>> COMPUTERS = new EnumMap<>(ComputerColor.class);
    private static final Map<ComputerColor, DeferredItem<BlockItem>> COMPUTER_ITEMS = new EnumMap<>(ComputerColor.class);

    static {
        for (ComputerColor color : ComputerColor.values()) {
            DeferredBlock<ComputerBlock> block = BLOCKS.registerBlock(
                    color.blockName(),
                    props -> new ComputerBlock(props, color),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_PINK)
                            .strength(1.0F)
                            .sound(SoundType.METAL)
                            .noOcclusion());
            COMPUTERS.put(color, block);
            COMPUTER_ITEMS.put(color, ITEMS.registerSimpleBlockItem(block));
        }
    }

    private static final Map<ComputerColor, DeferredBlock<LaptopBlock>> LAPTOPS = new EnumMap<>(ComputerColor.class);

    static {
        for (ComputerColor color : ComputerColor.values()) {
            String name = color.id + "_laptop";
            DeferredBlock<LaptopBlock> block = BLOCKS.registerBlock(
                    name,
                    props -> new LaptopBlock(props, color),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_PINK)
                            .strength(1.0F)
                            .sound(SoundType.METAL)
                            .noOcclusion());
            LAPTOPS.put(color, block);
            ITEMS.registerItem(name, props -> new dev.cutemod.item.LaptopItem(block.get(), props), new net.minecraft.world.item.Item.Properties().stacksTo(1));
        }
    }

    private static final Map<Integer, DeferredBlock<RouterBlock>> ROUTERS = new java.util.LinkedHashMap<>();
    private static final Map<Integer, DeferredItem<BlockItem>> ROUTER_ITEMS = new java.util.LinkedHashMap<>();

    static {
        for (int lv = dev.cutemod.data.WifiNet.FIRST; lv <= dev.cutemod.data.WifiNet.LAST; lv++) {
            final int level = lv;
            DeferredBlock<RouterBlock> block = BLOCKS.registerBlock(
                    dev.cutemod.data.WifiNet.id(lv),
                    props -> new RouterBlock(props, level),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_PINK)
                            .strength(0.8F)
                            .sound(SoundType.METAL)
                            .noOcclusion());
            ROUTERS.put(lv, block);
            ROUTER_ITEMS.put(lv, ITEMS.registerSimpleBlockItem(block));
        }
    }

    /** The Wi-Fi router block of this level (1..5). */
    public static DeferredBlock<RouterBlock> getRouter(int level) { return ROUTERS.get(dev.cutemod.data.WifiNet.level(level)); }

    public static Iterable<DeferredBlock<RouterBlock>> allRouters() { return ROUTERS.values(); }

    /** One router item of this level (1..5). */
    public static net.minecraft.world.item.ItemStack routerStack(int level) {
        DeferredItem<BlockItem> it = ROUTER_ITEMS.get(level);
        return it == null ? net.minecraft.world.item.ItemStack.EMPTY : new net.minecraft.world.item.ItemStack(it.get());
    }

    public static DeferredBlock<LaptopBlock> getLaptop(ComputerColor color) {
        return LAPTOPS.get(color);
    }

    public static Iterable<DeferredBlock<LaptopBlock>> allLaptops() {
        return LAPTOPS.values();
    }

    public static DeferredBlock<ComputerBlock> get(ComputerColor color) {
        return COMPUTERS.get(color);
    }

    public static Iterable<DeferredBlock<ComputerBlock>> all() {
        return COMPUTERS.values();
    }

    private ModBlocks() {}
}
