package dev.cutemod.block;

import com.mojang.serialization.MapCodec;
import dev.cutemod.data.WifiNet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * A Wi-Fi router. Put it down and every computer within its range sees its network in the Wi-Fi list (the icon in the
 * menu bar of the computer) and can connect to it. Level 1 is crafted, the better ones (2..5) come from CuteMarket.
 */
public class RouterBlock extends Block implements EntityBlock {
    public static final MapCodec<RouterBlock> CODEC = simpleCodec(p -> new RouterBlock(p, WifiNet.FIRST));
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    private static final VoxelShape[] SHAPES = new VoxelShape[4];
    static {
        for (int turn = 0; turn < 4; turn++) SHAPES[turn] = ComputerBlock.rotated(2, 0, 4, 14, 3, 12, turn);
    }

    private final int routerLevel;

    public RouterBlock(BlockBehaviour.Properties props, int routerLevel) {
        super(props);
        this.routerLevel = WifiNet.level(routerLevel);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.SOUTH));
    }

    public int routerLevel() { return routerLevel; }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rot) {
        return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPES[ComputerBlock.turnsOf(state.getValue(FACING))];
    }

    /** An item with a custom name (renamed in an anvil) gives the network that name. */
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (!level.isClientSide && stack.has(net.minecraft.core.component.DataComponents.CUSTOM_NAME)
                && level.getBlockEntity(pos) instanceof RouterBlockEntity be) {
            be.setNetworkName(stack.getHoverName().getString());
        }
    }

    /** Right-click: a line above the hotbar with the network, the speed and the range. */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof RouterBlockEntity be) {
            player.displayClientMessage(Component.translatable("cutemod.wifi.info", be.networkName(),
                    WifiNet.NAMES[routerLevel], WifiNet.mbps(routerLevel), WifiNet.range(routerLevel)), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new RouterBlockEntity(pos, state);
    }
}
