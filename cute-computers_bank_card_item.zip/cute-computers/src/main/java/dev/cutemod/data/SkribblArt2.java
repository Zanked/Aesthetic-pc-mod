package dev.cutemod.data;

import static dev.cutemod.data.SkribblArt.*;

/** More pictures for the computer artists (see {@link SkribblArt}): Minecraft things, animals, food and a few objects. */
final class SkribblArt2 {
    private SkribblArt2() {}

    static void creeper(B b) {
        b.box(34, 4, 86, 44, GREEN, MID);
        b.box(46, 44, 74, 70, GREEN, MID);
        b.box(40, 70, 56, 78, GREEN, MID);
        b.box(64, 70, 80, 78, GREEN, MID);
        b.box(43, 14, 55, 26, INK, THIN);
        b.box(65, 14, 77, 26, INK, THIN);
        b.box(54, 26, 66, 38, INK, THIN);
        b.box(48, 34, 56, 44, INK, THIN);
        b.box(64, 34, 72, 44, INK, THIN);
        for (double[] d : new double[][]{{38, 8}, {76, 10}, {80, 34}, {38, 36}, {58, 50}, {66, 60}}) b.dot(d[0], d[1], TEAL, MID);
    }

    static void diamond(B b) {
        b.shape(SKY, 60, 34, 38, 24, 82, 24, 98, 40, 60, 74, 22, 40);
        b.line(22, 40, 98, 40, INK, THIN);
        b.path(INK, THIN, new double[]{38, 24, 50, 40, 60, 74});
        b.path(INK, THIN, new double[]{82, 24, 70, 40, 60, 74});
        b.fill(60, 32, MINT);
        b.dot(48, 32, PAPER, MID);
        b.dot(54, 30, PAPER, THIN);
    }

    static void pickaxe(B b) {
        b.line(36, 74, 82, 24, INK, HUGE);
        b.line(36, 74, 82, 24, BROWN, FAT);
        b.path(INK, HUGE, new double[]{44, 14, 62, 6, 82, 8, 98, 18, 108, 36});
        b.path(GREY, FAT, new double[]{44, 14, 62, 6, 82, 8, 98, 18, 108, 36});
        b.path(PAPER, THIN, new double[]{52, 12, 64, 8, 78, 9});
    }

    static void sword(B b) {
        b.shape(SKY, 80, 30, 100, 5, 105, 10, 58, 58, 52, 52);
        b.line(100, 5, 56, 55, PAPER, THIN);
        b.line(44, 46, 68, 70, INK, HUGE);
        b.line(44, 46, 68, 70, ORANGE, FAT);
        b.line(54, 60, 40, 74, INK, FAT);
        b.line(54, 60, 40, 74, BROWN, MID);
        b.dot(38, 75, YELLOW, FAT);
    }

    static void torch(B b) {
        b.box(53, 34, 67, 76, BROWN, MID);
        b.line(60, 40, 60, 72, ORANGE, THIN);
        b.shape(ORANGE, 60, 28, 60, 4, 74, 22, 68, 34, 52, 34, 46, 22);
        b.shape(YELLOW, 60, 28, 60, 14, 67, 24, 62, 33, 56, 33, 53, 24);
    }

    static void tnt(B b) {
        b.line(60, 22, 62, 12, INK, MID);
        b.dot(63, 8, YELLOW, FAT);
        b.dot(63, 8, ORANGE, MID);
        b.box(28, 22, 92, 68, RED, MID);
        b.box(28, 36, 92, 54, PAPER, MID);
        b.line(40, 40, 50, 40, INK, MID); b.line(45, 40, 45, 50, INK, MID);
        b.path(INK, MID, new double[]{56, 50, 56, 40, 64, 50, 64, 40});
        b.line(70, 40, 80, 40, INK, MID); b.line(75, 40, 75, 50, INK, MID);
    }

    static void chest(B b) {
        b.box(28, 38, 92, 72, BROWN, MID);
        b.box(28, 22, 92, 38, ORANGE, MID);
        b.line(28, 55, 92, 55, INK, THIN);
        b.line(44, 22, 44, 72, INK, THIN);
        b.line(76, 22, 76, 72, INK, THIN);
        b.box(53, 32, 67, 46, YELLOW, MID);
        b.dot(60, 39, INK, MID);
    }

    static void penguin(B b) {
        b.oval(38, 50, 5, 14, INK, MID); b.fill(38, 50, INK);
        b.oval(82, 50, 5, 14, INK, MID); b.fill(82, 50, INK);
        b.oval(60, 44, 21, 30, INK, MID); b.fill(60, 44, INK);
        b.ellipse(60, 50, 13, 22, PAPER, THIN);
        b.fill(60, 50, PAPER);
        b.shape(ORANGE, 60, 34, 54, 33, 66, 33, 60, 41);
        b.dot(52, 26, PAPER, FAT); b.dot(68, 26, PAPER, FAT);
        b.dot(52, 26, INK, THIN); b.dot(68, 26, INK, THIN);
        b.oval(50, 75, 7, 3, ORANGE, THIN);
        b.oval(70, 75, 7, 3, ORANGE, THIN);
    }

    static void frog(B b) {
        b.oval(60, 48, 32, 24, GREEN, MID);
        b.oval(44, 22, 10, 10, PAPER, MID);
        b.oval(76, 22, 10, 10, PAPER, MID);
        b.dot(46, 23, INK, FAT); b.dot(74, 23, INK, FAT);
        b.arc(60, 48, 18, 9, 10, 170, INK, THIN);
        b.dot(48, 46, INK, THIN); b.dot(72, 46, INK, THIN);
        b.dot(36, 52, PINK, MID); b.dot(84, 52, PINK, MID);
        b.oval(36, 72, 10, 4, GREEN, THIN);
        b.oval(84, 72, 10, 4, GREEN, THIN);
    }

    static void pig(B b) {
        b.shape(PINK, 40, 22, 36, 28, 40, 10, 54, 20);
        b.shape(PINK, 80, 22, 84, 28, 80, 10, 66, 20);
        b.oval(60, 42, 27, 26, PINK, MID);
        b.oval(60, 50, 12, 9, 3, MID);
        b.fill(60, 50, RED);
        b.dot(56, 50, INK, MID); b.dot(64, 50, INK, MID);
        b.dot(48, 36, INK, MID); b.dot(72, 36, INK, MID);
        b.dot(40, 46, PAPER, MID); b.dot(80, 46, PAPER, MID);
    }

    static void dog(B b) {
        b.oval(35, 36, 8, 16, BROWN, MID);
        b.oval(85, 36, 8, 16, BROWN, MID);
        b.oval(60, 42, 24, 24, BEIGE, MID);
        b.oval(60, 54, 13, 10, PAPER, MID);
        b.oval(60, 48, 5, 3, INK, THIN);
        b.fill(60, 48, INK);
        b.line(60, 51, 60, 55, INK, THIN);
        b.arc(56, 56, 4, 3, 0, 150, INK, THIN);
        b.arc(64, 56, 4, 3, 30, 180, INK, THIN);
        b.dot(60, 60, PINK, FAT);
        b.dot(50, 38, INK, FAT); b.dot(70, 38, INK, FAT);
        b.dot(50, 37, PAPER, THIN);
    }

    static void owl(B b) {
        b.shape(BROWN, 42, 14, 38, 24, 40, 8, 50, 18);
        b.shape(BROWN, 78, 14, 82, 24, 80, 8, 70, 18);
        b.oval(33, 54, 5, 14, ORANGE, THIN);
        b.oval(87, 54, 5, 14, ORANGE, THIN);
        b.oval(60, 46, 26, 30, BROWN, MID);
        b.oval(60, 56, 15, 17, BEIGE, THIN);
        b.oval(50, 32, 10, 10, PAPER, MID);
        b.oval(70, 32, 10, 10, PAPER, MID);
        b.dot(50, 33, INK, FAT); b.dot(70, 33, INK, FAT);
        b.poly(ORANGE, THIN, 56, 38, 64, 38, 60, 46);
        b.fill(60, 40, ORANGE);
        b.oval(52, 76, 6, 2, ORANGE, THIN);
        b.oval(68, 76, 6, 2, ORANGE, THIN);
    }

    static void butterfly(B b) {
        b.oval(42, 28, 19, 17, PINK, MID);
        b.oval(78, 28, 19, 17, PINK, MID);
        b.oval(46, 54, 14, 13, LAV, MID);
        b.oval(74, 54, 14, 13, LAV, MID);
        b.dot(40, 28, PAPER, FAT); b.dot(80, 28, PAPER, FAT); b.dot(46, 55, PAPER, MID); b.dot(74, 55, PAPER, MID);
        b.oval(60, 42, 4, 22, INK, MID);
        b.fill(60, 42, INK);
        b.path(INK, THIN, new double[]{58, 20, 52, 8});
        b.path(INK, THIN, new double[]{62, 20, 68, 8});
        b.dot(52, 7, INK, MID); b.dot(68, 7, INK, MID);
    }

    static void snail(B b) {
        b.oval(46, 64, 38, 8, BEIGE, MID);
        b.oval(24, 52, 8, 13, BEIGE, MID);
        b.path(INK, THIN, new double[]{20, 42, 18, 30});
        b.path(INK, THIN, new double[]{28, 44, 30, 32});
        b.dot(18, 29, INK, FAT); b.dot(30, 31, INK, FAT);
        b.arc(24, 54, 4, 3, 20, 160, INK, THIN);
        b.oval(72, 40, 22, 22, ORANGE, MID);
        b.arc(72, 40, 14, 14, 0, 300, BROWN, THIN);
        b.arc(72, 40, 7, 7, 40, 340, BROWN, THIN);
        b.dot(72, 40, BROWN, MID);
    }

    static void turtle(B b) {
        b.oval(98, 50, 9, 9, MINT, MID);
        b.dot(101, 48, INK, MID);
        b.oval(34, 70, 8, 5, MINT, MID);
        b.oval(80, 70, 8, 5, MINT, MID);
        b.poly(INK, MID, 24, 60, 24, 66, 16, 62);
        b.oval(58, 48, 34, 24, GREEN, MID);
        b.poly(INK, THIN, 48, 40, 58, 34, 68, 40, 68, 52, 58, 58, 48, 52);
        b.line(32, 40, 48, 40, INK, THIN); b.line(68, 40, 84, 40, INK, THIN);
        b.line(32, 54, 48, 52, INK, THIN); b.line(68, 52, 84, 54, INK, THIN);
        b.line(58, 34, 58, 26, INK, THIN); b.line(58, 58, 58, 70, INK, THIN);
    }

    static void spider(B b) {
        b.line(60, 0, 60, 14, GREY, THIN);
        double[][] legs = {{50, 34, 34, 22, 22, 30}, {48, 38, 30, 36, 20, 46}, {48, 44, 30, 50, 22, 64}, {52, 48, 40, 62, 32, 76}};
        for (double[] l : legs) {
            b.path(INK, MID, l);
            b.path(INK, MID, new double[]{120 - l[0], l[1], 120 - l[2], l[3], 120 - l[4], l[5]});
        }
        b.oval(60, 42, 13, 14, INK, MID); b.fill(60, 42, INK);
        b.oval(60, 26, 8, 8, INK, MID); b.fill(60, 26, INK);
        b.dot(57, 25, PAPER, MID); b.dot(63, 25, PAPER, MID);
        b.dot(60, 42, RED, FAT);
    }

    static void bat(B b) {
        b.shape(INK, 40, 40, 52, 34, 36, 20, 22, 14, 24, 28, 10, 34, 20, 42, 14, 54, 30, 50, 40, 58, 52, 52);
        b.fill(30, 36, INK);
        b.shape(INK, 80, 40, 68, 34, 84, 20, 98, 14, 96, 28, 110, 34, 100, 42, 106, 54, 90, 50, 80, 58, 68, 52);
        b.fill(90, 36, INK);
        b.oval(60, 42, 9, 13, INK, MID); b.fill(60, 42, INK);
        b.shape(INK, 54, 28, 52, 32, 52, 20, 58, 28);
        b.shape(INK, 66, 28, 68, 32, 68, 20, 62, 28);
        b.dot(56, 38, RED, MID); b.dot(64, 38, RED, MID);
        b.dot(57, 48, PAPER, THIN); b.dot(63, 48, PAPER, THIN);
    }

    static void donut(B b) {
        b.oval(60, 42, 29, 29, BEIGE, MID);
        b.circle(60, 38, 23, PINK, MID);
        b.fill(60, 26, PINK);
        b.oval(60, 40, 8, 8, PAPER, MID);
        int[] cols = {YELLOW, SKY, MINT, RED, LAV, GREEN};
        double[][] sp = {{42, 30}, {52, 22}, {70, 24}, {78, 34}, {44, 46}, {76, 48}, {60, 56}, {58, 30}};
        for (int i = 0; i < sp.length; i++) b.line(sp[i][0], sp[i][1], sp[i][0] + 3, sp[i][1] + (i % 2 == 0 ? 2 : -2), cols[i % cols.length], MID);
    }

    static void pizza(B b) {
        b.shape(YELLOW, 60, 40, 22, 22, 98, 22, 60, 76);
        b.box(20, 12, 100, 24, ORANGE, MID);
        for (double[] p : new double[][]{{46, 34}, {72, 36}, {58, 54}}) { b.oval(p[0], p[1], 6, 6, RED, THIN); b.dot(p[0] - 1, p[1] - 1, 3, THIN); }
        b.dot(60, 30, GREEN, MID); b.dot(50, 46, GREEN, MID); b.dot(70, 48, GREEN, MID);
    }

    static void cookie(B b) {
        b.oval(60, 40, 29, 29, BEIGE, MID);
        for (double[] c : new double[][]{{46, 30}, {70, 28}, {58, 44}, {78, 46}, {44, 52}, {64, 58}}) b.dot(c[0], c[1], BROWN, FAT);
        b.arc(60, 40, 22, 22, 200, 250, PAPER, THIN);
    }

    static void banana(B b) {
        b.arc(60, 12, 54, 56, 22, 158, INK, THIN);
        b.arc(60, 12, 36, 38, 22, 158, INK, THIN);
        b.line(25, 41, 36, 44, INK, THIN);
        b.line(95, 41, 84, 44, INK, THIN);
        b.arc(60, 12, 49, 51, 25, 155, YELLOW, HUGE);
        b.arc(60, 12, 41, 43, 25, 155, YELLOW, HUGE);
        b.arc(60, 12, 45, 47, 30, 150, YELLOW, HUGE);
        b.arc(60, 14, 49, 50, 40, 100, PAPER, THIN);
        b.dot(26, 41, BROWN, FAT);
        b.dot(94, 41, BROWN, FAT);
    }

    static void strawberry(B b) {
        b.shape(RED, 60, 44, 32, 24, 88, 24, 74, 62, 60, 76, 46, 62);
        b.shape(GREEN, 60, 20, 34, 24, 44, 12, 54, 20, 60, 8, 66, 20, 76, 12, 86, 24, 60, 28);
        for (double[] s : new double[][]{{46, 38}, {60, 36}, {74, 38}, {52, 50}, {68, 50}, {60, 62}}) b.dot(s[0], s[1], YELLOW, MID);
    }

    static void carrot(B b) {
        b.oval(50, 14, 4, 10, GREEN, THIN);
        b.oval(60, 10, 4, 12, GREEN, THIN);
        b.oval(70, 14, 4, 10, GREEN, THIN);
        b.shape(ORANGE, 60, 40, 46, 22, 74, 22, 60, 78);
        b.line(50, 32, 58, 32, BROWN, THIN); b.line(62, 44, 70, 44, BROWN, THIN); b.line(54, 54, 60, 54, BROWN, THIN);
    }

    static void onigiri(B b) {
        b.shape(PAPER, 60, 40, 60, 10, 90, 58, 84, 68, 36, 68, 30, 58);
        b.shape(INK, 60, 62, 42, 54, 78, 54, 84, 68, 36, 68);
        b.dot(52, 38, INK, FAT); b.dot(68, 38, INK, FAT);
        b.arc(60, 44, 5, 4, 20, 160, INK, THIN);
        b.dot(46, 44, PINK, MID); b.dot(74, 44, PINK, MID);
    }

    static void egg(B b) {
        b.path(INK, MID, SkribblArt.blob(60, 44, new double[][]{{46, 42, 21}, {72, 38, 19}, {64, 56, 19}, {48, 56, 15}}, 77));
        b.fill(60, 46, PAPER);
        b.oval(60, 44, 11, 11, YELLOW, MID);
        b.dot(56, 40, PAPER, MID);
    }

    static void rocket(B b) {
        b.shape(RED, 44, 58, 46, 50, 30, 72, 46, 66);
        b.shape(RED, 76, 58, 74, 50, 90, 72, 74, 66);
        b.shape(ORANGE, 60, 76, 52, 66, 68, 66, 60, 78);
        b.oval(60, 36, 16, 30, PAPER, MID);
        b.shape(RED, 60, 12, 60, 3, 76, 22, 44, 22);
        b.circle(60, 40, 7, INK, MID);
        b.fill(60, 40, SKY);
    }

    static void campfire(B b) {
        b.line(26, 72, 94, 62, INK, HUGE); b.line(26, 72, 94, 62, BROWN, FAT);
        b.line(26, 62, 94, 72, INK, HUGE); b.line(26, 62, 94, 72, BROWN, FAT);
        b.shape(ORANGE, 60, 40, 60, 4, 78, 32, 72, 56, 48, 56, 42, 32);
        b.shape(YELLOW, 60, 44, 60, 22, 70, 40, 64, 56, 54, 56, 50, 40);
        for (double[] s : new double[][]{{28, 76}, {44, 77}, {76, 77}, {92, 76}}) b.oval(s[0], s[1], 5, 3, GREY, THIN);
    }

    static void lightning(B b) {
        b.shape(YELLOW, 62, 40, 68, 4, 36, 44, 56, 44, 44, 76, 86, 30, 64, 30, 82, 4);
        b.line(20, 20, 26, 20, YELLOW, MID); b.line(23, 17, 23, 23, YELLOW, MID);
        b.line(94, 56, 100, 56, YELLOW, MID); b.line(97, 53, 97, 59, YELLOW, MID);
    }

    static void snowflake(B b) {
        for (int i = 0; i < 6; i++) {
            double a = Math.toRadians(i * 60 - 90), ca = Math.cos(a), sa = Math.sin(a);
            b.line(60, 40, 60 + ca * 32, 40 + sa * 32, SKY, MID);
            double bx = 60 + ca * 20, by = 40 + sa * 20;
            for (int s = -1; s <= 1; s += 2) {
                double ba = a + s * Math.toRadians(45);
                b.line(bx, by, bx + Math.cos(ba) * 10, by + Math.sin(ba) * 10, SKY, MID);
            }
        }
        b.dot(60, 40, BLUE, FAT);
    }

    static void planet(B b) {
        b.arc(60, 42, 42, 10, 180, 360, INK, MID);
        b.oval(60, 40, 22, 22, ORANGE, MID);
        b.arc(60, 36, 20, 6, 20, 160, BROWN, THIN);
        b.arc(60, 48, 20, 6, 20, 160, BROWN, THIN);
        b.arc(60, 42, 42, 10, 0, 180, INK, MID);
        b.arc(60, 42, 42, 10, 0, 180, YELLOW, THIN);
        for (double[] s : new double[][]{{16, 14}, {100, 18}, {20, 66}, {102, 64}}) { b.line(s[0] - 3, s[1], s[0] + 3, s[1], PURPLE, THIN); b.line(s[0], s[1] - 3, s[0], s[1] + 3, PURPLE, THIN); }
    }

    static void robot(B b) {
        b.line(60, 12, 60, 4, INK, MID); b.dot(60, 3, RED, FAT);
        b.box(38, 12, 82, 46, LAV, MID);
        b.box(46, 22, 56, 32, SKY, THIN);
        b.box(64, 22, 74, 32, SKY, THIN);
        b.line(50, 39, 70, 39, INK, MID);
        b.box(42, 48, 78, 74, GREY, MID);
        b.dot(52, 58, RED, FAT); b.dot(60, 58, YELLOW, FAT); b.dot(68, 58, GREEN, FAT);
        b.line(42, 54, 30, 66, INK, FAT); b.line(78, 54, 90, 66, INK, FAT);
        b.line(34, 12, 38, 12, INK, MID); b.line(82, 12, 86, 12, INK, MID);
    }

    static void gift(B b) {
        b.box(30, 38, 90, 74, PINK, MID);
        b.box(26, 28, 94, 40, 3, MID);
        b.box(54, 28, 66, 74, YELLOW, MID);
        b.oval(49, 20, 10, 6, YELLOW, MID);
        b.oval(71, 20, 10, 6, YELLOW, MID);
        b.dot(60, 24, ORANGE, FAT);
    }

    static void bell(B b) {
        b.circle(60, 10, 5, INK, MID);
        double[] p = new double[2 * 21 + 12];
        int k = 0;
        for (int i = 0; i <= 20; i++) {
            double a = Math.toRadians(180 + 180.0 * i / 20);
            p[k++] = 60 + Math.cos(a) * 22;
            p[k++] = 36 + Math.sin(a) * 22;
        }
        double[] tail = {82, 52, 90, 60, 94, 64, 26, 64, 30, 60, 38, 52};
        for (double v : tail) p[k++] = v;
        b.shape(YELLOW, 60, 36, p);
        b.dot(60, 68, BROWN, HUGE);
        b.arc(60, 36, 14, 14, 200, 260, PAPER, MID);
    }

    static void candle(B b) {
        b.oval(60, 74, 24, 4, GREY, MID);
        b.box(48, 30, 72, 72, LAV, MID);
        b.path(PAPER, MID, new double[]{52, 34, 52, 44});
        b.path(PAPER, MID, new double[]{68, 38, 68, 50});
        b.line(60, 30, 60, 24, INK, MID);
        b.poly(INK, THIN, 60, 0, 70, 12, 60, 24, 50, 12);
        b.fill(60, 12, ORANGE);
        b.dot(60, 16, YELLOW, MID);
    }

    static void teddy(B b) {
        b.oval(38, 54, 8, 12, BROWN, MID); b.oval(82, 54, 8, 12, BROWN, MID);
        b.oval(48, 72, 10, 6, BROWN, MID); b.oval(72, 72, 10, 6, BROWN, MID);
        b.oval(60, 54, 21, 20, BROWN, MID);
        b.oval(60, 58, 12, 11, BEIGE, THIN);
        b.oval(44, 12, 7, 7, BROWN, MID); b.oval(76, 12, 7, 7, BROWN, MID);
        b.oval(60, 26, 18, 16, BROWN, MID);
        b.oval(60, 31, 8, 6, BEIGE, THIN);
        b.dot(60, 29, INK, FAT);
        b.dot(53, 22, INK, FAT); b.dot(67, 22, INK, FAT);
        b.arc(60, 33, 3, 2, 20, 160, INK, THIN);
        b.poly(INK, THIN, 54, 43, 54, 49, 60, 46, 66, 49, 66, 43);
        b.fill(56, 46, RED);
        b.fill(64, 46, RED);
    }

    static void kitten(B b) {
        b.shape(PINK, 44, 22, 36, 34, 38, 10, 54, 24);
        b.shape(PINK, 76, 22, 84, 34, 82, 10, 66, 24);
        b.oval(60, 48, 25, 22, GREY, MID);
        b.fill(60, 48, LAV);
        b.oval(50, 44, 7, 7, PAPER, MID); b.oval(70, 44, 7, 7, PAPER, MID);
        b.dot(51, 45, INK, FAT); b.dot(69, 45, INK, FAT);
        b.poly(PINK, THIN, 57, 52, 63, 52, 60, 56);
        b.arc(56, 58, 4, 3, 0, 160, INK, THIN);
        b.arc(64, 58, 4, 3, 20, 180, INK, THIN);
        b.line(34, 52, 44, 54, INK, THIN); b.line(34, 59, 44, 57, INK, THIN);
        b.line(86, 52, 76, 54, INK, THIN); b.line(86, 59, 76, 57, INK, THIN);
        b.dot(46, 32, PINK, MID);
    }
}
