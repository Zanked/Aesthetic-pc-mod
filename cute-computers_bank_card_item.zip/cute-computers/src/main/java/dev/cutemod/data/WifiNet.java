package dev.cutemod.data;

/**
 * The Wi-Fi routers (blocks): shared by the server (shop, items) and the client (the list of networks).
 * Level 1 is crafted, levels 2..5 are sold in CuteMarket. A router reaches the computers that stand within its range;
 * its speed and its dropouts follow the same ladder as the old modems ({@link PcHardware#modemSpeed}, {@link PcHardware#modemDown}).
 */
public final class WifiNet {
    private WifiNet() {}

    public static final int FIRST = 1, LAST = 5, CRAFTED = 1, FIRST_SHOP = 2;

    public static final String[] NAMES = {"", "Cute Wi-Fi Mini", "Cute Wi-Fi Home", "Cute Wi-Fi Plus", "Cute Wi-Fi Pro", "Cute Wi-Fi Max"};

    /** How far (in blocks) the signal reaches. */
    public static final int[] RANGE = {0, 10, 18, 28, 40, 56};

    private static final int[] PRICE = {0, 0, 60, 140, 300, 600};

    public static int level(int lv) { return Math.max(FIRST, Math.min(LAST, lv)); }

    public static int range(int lv) { return RANGE[level(lv)]; }

    public static int mbps(int lv) { return PcHardware.MODEM_MBPS[level(lv)]; }

    /** Price in coins in the shop (level 1 is not sold: it is crafted). */
    public static int price(int lv) { return PRICE[level(lv)]; }

    /** Delivery time in seconds: the better the router, the longer the courier takes. */
    public static int secs(int lv) { return 60 + (level(lv) - FIRST_SHOP) * 30; }

    /** The id of the block / item / shop entry: wifi_router_1 ... wifi_router_5. */
    public static String id(int lv) { return "wifi_router_" + level(lv); }

    /** The level in an id like wifi_router_3, or 0 if it is not a router id. */
    public static int levelOf(String id) {
        if (id == null || !id.startsWith("wifi_router_")) return 0;
        try {
            int lv = Integer.parseInt(id.substring("wifi_router_".length()));
            return lv >= FIRST && lv <= LAST ? lv : 0;
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** The name a network has until its owner renames the router (an anvil-renamed item keeps its name): CuteWiFi-3A7F. */
    public static String defaultName(long posLong) {
        long h = posLong * 0x9E3779B97F4A7C15L;
        return String.format(java.util.Locale.ROOT, "CuteWiFi-%04X", (int) ((h ^ (h >>> 32)) & 0xFFFF));
    }

    /** 1..4 bars: how strong the signal is at this distance (the closer, the stronger). */
    public static int bars(double dist, int lv) {
        double r = range(lv);
        double f = r <= 0 ? 1.0 : dist / r;
        if (f >= 1.0) return 0;
        return Math.max(1, 4 - (int) Math.floor(f * 4.0));
    }

    /** Download speed factor of a signal with this many bars: 1.0 at four bars, a bit slower further away. */
    public static double barsSpeed(int bars) {
        return switch (bars) { case 4 -> 1.0; case 3 -> 0.9; case 2 -> 0.75; case 1 -> 0.55; default -> 0.0; };
    }
}
