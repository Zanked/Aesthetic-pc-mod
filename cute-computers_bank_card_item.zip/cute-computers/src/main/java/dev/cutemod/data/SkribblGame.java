package dev.cutemod.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * The rules of Scribble Pals (a "draw and guess" game for up to eight players, people and computer players), without any
 * network or Minecraft code, so it can be tested on its own. {@code SkribblServer} owns one of these per room, calls
 * {@link #tick()} 20 times a second and sends what changed to the people in the room.
 * <p>
 * <b>Draw and guess.</b> A game is {@code rounds} rounds; in a round every player draws once. The drawer gets three words to pick from
 * (a computer player only gets words it knows how to draw), then everybody else has {@code drawSeconds} to type the word in the chat.
 * The earlier a guess, the more points; the drawer is paid for every guesser. After the time (or when everybody has it) the word is shown
 * for a few seconds, people can like the picture, and the next player draws. The words come from a word set (everything, animals, food,
 * Minecraft, anime, spooky, things, or the words the players typed themselves).
 * <p>
 * <b>Telephone.</b> Every player starts a chain with a phrase; the next player draws it, the next one describes the drawing, and so on
 * (everybody works on a different chain at the same time, so there is no waiting). In the end every chain is shown, one step at a time.
 */
public final class SkribblGame {
    public static final int SLOTS = 8;
    public static final int EMPTY = 0, OPEN = 1, BOT = 2, HUMAN = 3;
    public static final int LOBBY = 0, PICK = 1, DRAW = 2, REVEAL = 3, END = 4, T_WRITE = 5, T_DRAW = 6, T_SHOW = 7;
    public static final int MODE_CLASSIC = 0, MODE_TELEPHONE = 1;
    /** Chat kinds, the client turns them into text in its own language. K_EMOJI is a reaction (arg = which one). */
    public static final int K_SAY = 0, K_GUESSED = 1, K_CLOSE = 2, K_WHISPER = 3, K_WORD = 4, K_JOIN = 5, K_LEAVE = 6, K_DRAWER = 7, K_NOBODY = 8, K_EMOJI = 9;
    public static final int ALL = -1, EMOJIS = 6, MAX_CUSTOM = 24, CUSTOM_EACH = 4;
    public static final int[] ROUNDS = {2, 3, 4}, SECONDS = {60, 80, 100};

    private static final int PICK_TICKS = 15 * 20, REVEAL_TICKS = 8 * 20, END_TICKS = 18 * 20, WRITE_TICKS = 45 * 20, SHOW_GAP = 70;
    private static final String[] BOT_NAMES = {"Mochi", "Panko", "Nori", "Kiwi", "Pudding", "Boba", "Miso", "Tofu"};

    public interface Sink {
        /** Something everybody should see changed (phase, scores, hints...): send the picture of the game again. */
        void changed();

        /** A drawing operation for everybody except slot {@code except} (kind 0 add {@code op}, 1 undo, 2 clear). */
        void draw(int kind, String op, int except);

        /** A chat line for the slots in the bit mask {@code audience} (ALL = everybody). */
        void chat(int kind, int from, String text, int arg, int audience);

        /**
         * Telephone: kind 0 = the picture you have to describe (only for {@code audience}), kind 1 = one item of a finished chain
         * (for everybody). An item is text or a picture (zipped colours, see SkribblCanvas.zip).
         */
        void tele(int audience, int kind, int chain, int step, int author, String text, byte[] pic);
    }

    private final Sink sink;
    private final Random rnd;

    public final int[] type = new int[SLOTS];
    public final String[] name = new String[SLOTS];
    public final int[] score = new int[SLOTS], gain = new int[SLOTS];
    public final boolean[] guessed = new boolean[SLOTS], liked = new boolean[SLOTS];
    public int rounds = 3, drawSeconds = 80, mode = MODE_CLASSIC, wordSet = SkribblWords.SET_ALL;
    public int phase = LOBBY, round, drawer = -1, timeLeft, timeTotal, likes, guessers, step, steps;
    /** The secret word as "english|russian" ("" when there is none). */
    public String word = "";
    public String[] choices = new String[0];
    public long seed;
    public final SkribblCanvas canvas = new SkribblCanvas();
    /** The words the players typed for the "own words" set. */
    public final List<String> custom = new ArrayList<>();
    private final List<Integer> customBy = new ArrayList<>();

    private final List<Integer> order = new ArrayList<>();
    private final Set<String> usedWords = new HashSet<>();
    private final List<String> pool = new ArrayList<>(), artPool = new ArrayList<>();
    private int turn;
    private int pickLeft, revealLeft, endLeft, tickNo, penStrokes;
    private boolean allIn;
    // computer players
    private final double[] skill = new double[SLOTS];
    private final int[] nextThink = new int[SLOTS], guesses = new int[SLOTS];
    /** What each computer player has in its head: a share of all the words (the better player knows more of them). */
    private final int[] salt = new int[SLOTS];
    /** The wrong guesses of this turn (as normalised English words): nobody says them twice. */
    private final Set<String> said = new HashSet<>();
    private List<String> botOps = new ArrayList<>();
    private int botNext;
    private double botGap, botClock;
    // telephone
    private int[] tOrder = new int[0];
    private String[][] tText, tSrc;
    private byte[][][] tPic;
    private final boolean[] done = new boolean[SLOTS];
    private final SkribblCanvas[] tcan = new SkribblCanvas[SLOTS];
    private final String[] prompt = new String[SLOTS];
    private final byte[][] promptPic = new byte[SLOTS][];
    private int showChain, showItem, showWait;
    private boolean showDone;

    public SkribblGame(Sink sink, Random rnd) {
        this.sink = sink;
        this.rnd = rnd;
        for (int i = 0; i < SLOTS; i++) { name[i] = ""; tcan[i] = new SkribblCanvas(); }
    }

    // ------------------------------------------------------------------ the room

    public int players() {
        int n = 0;
        for (int t : type) if (t == BOT || t == HUMAN) n++;
        return n;
    }

    public int humans() {
        int n = 0;
        for (int t : type) if (t == HUMAN) n++;
        return n;
    }

    public boolean running() { return phase != LOBBY; }

    private boolean active(int s) { return type[s] == HUMAN || type[s] == BOT; }

    /** Start a game: the places still open are dropped and computer players join until there are at least three. */
    public boolean start() {
        if (phase != LOBBY || humans() < 1) return false;
        for (int i = 0; i < SLOTS; i++) if (type[i] == OPEN) type[i] = EMPTY;
        for (int i = 0; i < SLOTS && players() < 3; i++) if (type[i] == EMPTY) type[i] = BOT;
        for (int i = 0; i < SLOTS; i++) {
            score[i] = 0;
            gain[i] = 0;
            if (type[i] == BOT) { name[i] = BOT_NAMES[i % BOT_NAMES.length]; skill[i] = 0.25 + rnd.nextDouble() * 0.75; salt[i] = rnd.nextInt(); }
        }
        order.clear();
        for (int i = 0; i < SLOTS; i++) if (active(i)) order.add(i);
        buildPools();
        usedWords.clear();
        if (mode == MODE_TELEPHONE) { startTelephone(); return true; }
        round = 0;
        turn = -1;
        nextTurn();
        return true;
    }

    private void buildPools() {
        pool.clear();
        artPool.clear();
        boolean own = wordSet == SkribblWords.SET_OWN;
        int set = own ? SkribblWords.SET_ALL : wordSet;
        if (own && custom.size() >= 3) pool.addAll(custom);
        for (int i = 0; i < SkribblWords.count(); i++) {
            String e = SkribblWords.entry(i);
            if (SkribblWords.inSet(i, set)) {
                if (!(own && custom.size() >= 3)) pool.add(e);
                if (SkribblArt.can(e)) artPool.add(e);
            }
        }
        if (artPool.size() < 3) for (int i = 0; i < SkribblWords.count(); i++) if (SkribblArt.can(SkribblWords.entry(i))) artPool.add(SkribblWords.entry(i));
    }

    /** A person leaves (or is sent away) while the game runs. */
    public void leave(int slot, boolean announce) {
        if (type[slot] != HUMAN) return;
        if (announce && phase != LOBBY) sink.chat(K_LEAVE, slot, name[slot], 0, ALL);
        type[slot] = EMPTY;
        clearCustom(slot);
        if (phase == LOBBY) return;
        if (humans() == 0) { phase = LOBBY; sink.changed(); return; }
        if (phase == PICK || phase == DRAW) {
            if (slot == drawer) endTurn();
            else checkAllIn();
        } else if ((phase == T_WRITE || phase == T_DRAW) && !done[slot]) autoSubmit(slot);
        sink.changed();
    }

    // ------------------------------------------------------------------ own words

    public int customCount() { return custom.size(); }

    public int customMine(int slot) {
        int n = 0;
        for (int by : customBy) if (by == slot) n++;
        return n;
    }

    /** A player adds a word to the "own words" set (in the room, before the game). */
    public boolean addCustom(int slot, String text) {
        if (phase != LOBBY || text == null) return false;
        String e = SkribblWords.custom(text);
        if (e.isEmpty() || custom.size() >= MAX_CUSTOM || customMine(slot) >= CUSTOM_EACH) return false;
        String n = SkribblWords.norm(SkribblWords.en(e));
        for (String c : custom) if (SkribblWords.norm(SkribblWords.en(c)).equals(n)) return false;
        custom.add(e);
        customBy.add(slot);
        sink.changed();
        return true;
    }

    public void clearCustom(int slot) {
        for (int i = customBy.size() - 1; i >= 0; i--) if (customBy.get(i) == slot) { customBy.remove(i); custom.remove(i); }
    }

    // ------------------------------------------------------------------ classic: turns

    private void nextTurn() {
        while (true) {
            turn++;
            if (turn >= order.size()) { turn = 0; round++; }
            if (round >= rounds) { finish(); return; }
            int s = order.get(turn);
            if (active(s)) { drawer = s; break; }
        }
        phase = PICK;
        pickLeft = PICK_TICKS;
        word = "";
        for (int i = 0; i < SLOTS; i++) { guessed[i] = false; liked[i] = false; gain[i] = 0; }
        likes = 0;
        guessers = 0;
        allIn = false;
        penStrokes = 0;
        said.clear();
        canvas.clear();
        sink.draw(2, "", -1);
        choices = pickChoices(type[drawer] == BOT);
        sink.chat(K_DRAWER, drawer, name[drawer], 0, ALL);
        sink.changed();
    }

    private String[] pickChoices(boolean artOnly) {
        List<String> from = artOnly ? artPool : pool;
        String[] c = new String[3];
        for (int i = 0; i < 3; i++) {
            String w;
            int tries = 0;
            do {
                w = from.get(rnd.nextInt(from.size()));
                tries++;
            } while (tries < 60 && (usedWords.contains(w) || Arrays.asList(c).subList(0, i).contains(w)));
            c[i] = w;
        }
        return c;
    }

    /** The drawer picks one of the three words. */
    public boolean pick(int slot, int index) {
        if (phase != PICK || slot != drawer || index < 0 || index >= choices.length) return false;
        beginDrawing(choices[index]);
        return true;
    }

    private void beginDrawing(String w) {
        word = w;
        usedWords.add(w);
        phase = DRAW;
        timeTotal = drawSeconds * 20;
        timeLeft = timeTotal;
        seed = rnd.nextLong();
        for (int i = 0; i < SLOTS; i++) {
            if (type[i] != BOT || i == drawer) continue;
            nextThink[i] = (int) ((50 + rnd.nextInt(120)) * (1.6 - skill[i]));
            guesses[i] = 0;
        }
        if (type[drawer] == BOT) {
            botOps = SkribblArt.draw(w);
            botNext = 0;
            botGap = Math.max(2.0, timeTotal * 0.55 / Math.max(1, botOps.size()));
            botClock = 20;
        }
        sink.changed();
    }

    private void endTurn() {
        if (phase != PICK && phase != DRAW) return;
        if (phase == DRAW && guessers > 0) {
            gain[drawer] += 25 + (allIn ? 25 : 0);
            score[drawer] += 25 + (allIn ? 25 : 0);
        }
        phase = REVEAL;
        revealLeft = REVEAL_TICKS;
        if (!word.isEmpty()) sink.chat(K_WORD, drawer, word, 0, ALL);
        else sink.chat(K_NOBODY, drawer, name[drawer], 0, ALL);
        sink.changed();
    }

    private void finish() {
        phase = END;
        endLeft = END_TICKS;
        drawer = -1;
        word = "";
        sink.changed();
    }

    // ------------------------------------------------------------------ classic: guessing

    private int guessed() {
        int n = 0;
        for (int i = 0; i < SLOTS; i++) if (i != drawer && guessed[i] && active(i)) n++;
        return n;
    }

    private int guessable() {
        int n = 0;
        for (int i = 0; i < SLOTS; i++) if (i != drawer && active(i)) n++;
        return n;
    }

    private void checkAllIn() {
        if (phase == DRAW && !allIn && guessable() > 0 && guessed() >= guessable()) {
            allIn = true;
            timeLeft = Math.min(timeLeft, 3 * 20);
        } else if (phase == DRAW && guessable() == 0) endTurn();
    }

    /** What a person typed in the chat. */
    public void say(int slot, String text) {
        if (type[slot] != HUMAN || phase == LOBBY) return;
        text = text.trim();
        if (text.isEmpty()) return;
        if (text.length() > 60) text = text.substring(0, 60);
        if (phase == DRAW && slot != drawer && !guessed[slot]) {
            if (SkribblWords.matches(word, text)) { solved(slot); return; }
            sink.chat(K_SAY, slot, text, 0, ALL);
            if (SkribblWords.close(word, text)) sink.chat(K_CLOSE, slot, text, 0, 1 << slot);
            return;
        }
        if (phase == DRAW) {                                  // the drawer and the ones who know the word talk among themselves
            if (SkribblWords.matches(word, text)) return;      // no spoilers
            int mask = 1 << drawer;
            for (int i = 0; i < SLOTS; i++) if (guessed[i]) mask |= 1 << i;
            sink.chat(K_WHISPER, slot, text, 0, mask);
            return;
        }
        sink.chat(K_SAY, slot, text, 0, ALL);
    }

    private void solved(int slot) {
        int pts = 40 + (int) Math.round(160.0 * timeLeft / Math.max(1, timeTotal));
        if (guessed() == 0) pts += 20;
        guessed[slot] = true;
        gain[slot] = pts;
        score[slot] += pts;
        guessers++;
        sink.chat(K_GUESSED, slot, name[slot], 0, ALL);
        botReacts(slot);
        checkAllIn();
        sink.changed();
    }

    /** Somebody clicked the heart on the picture. */
    public void like(int slot) {
        if (phase != REVEAL || slot == drawer || liked[slot] || type[slot] != HUMAN || word.isEmpty() || !canvas.hasInk()) return;
        liked[slot] = true;
        likes++;
        score[drawer] += 5;
        gain[drawer] += 5;
        sink.changed();
    }

    // ------------------------------------------------------------------ reactions

    /** A reaction (a small picture that floats over the board) from a person. */
    public void emoji(int slot, int idx) {
        if (phase == LOBBY || !active(slot) || idx < 0 || idx >= EMOJIS) return;
        sink.chat(K_EMOJI, slot, name[slot], idx, ALL);
    }

    private void botReacts(int except) {
        if (rnd.nextDouble() > 0.4) return;
        List<Integer> bots = new ArrayList<>();
        for (int i = 0; i < SLOTS; i++) if (type[i] == BOT && i != except) bots.add(i);
        if (bots.isEmpty()) return;
        int b = bots.get(rnd.nextInt(bots.size()));
        sink.chat(K_EMOJI, b, name[b], rnd.nextInt(4) == 0 ? 3 : rnd.nextInt(3) == 0 ? 2 : 0, ALL);
    }

    // ------------------------------------------------------------------ the drawing tools

    /** One drawing operation from a person (the drawer of this turn, or anybody in a telephone drawing step). */
    public boolean op(int slot, String op) {
        if (type[slot] != HUMAN) return false;
        if (phase == T_DRAW) return !done[slot] && tcan[slot].count() < 1500 && tcan[slot].add(op);
        if (phase != DRAW || slot != drawer || canvas.count() >= 1500) return false;
        if (!canvas.add(op)) return false;
        penStrokes++;
        sink.draw(0, op, slot);
        return true;
    }

    public boolean undo(int slot) {
        if (type[slot] != HUMAN) return false;
        if (phase == T_DRAW) return !done[slot] && tcan[slot].undo();
        if (phase != DRAW || slot != drawer || !canvas.undo()) return false;
        sink.draw(1, "", slot);
        return true;
    }

    public boolean clearBoard(int slot) {
        if (type[slot] != HUMAN) return false;
        if (phase == T_DRAW) { if (done[slot]) return false; tcan[slot].clear(); return true; }
        if (phase != DRAW || slot != drawer) return false;
        canvas.clear();
        sink.draw(2, "", slot);
        return true;
    }

    // ------------------------------------------------------------------ telephone

    private int indexOf(int slot) {
        for (int i = 0; i < tOrder.length; i++) if (tOrder[i] == slot) return i;
        return -1;
    }

    /** The chain that this player works on in the given step. */
    private int chainOf(int slot, int k) {
        int n = tOrder.length;
        return (((indexOf(slot) - k) % n) + n) % n;
    }

    private void startTelephone() {
        int n = order.size();
        tOrder = new int[n];
        for (int i = 0; i < n; i++) tOrder[i] = order.get(i);
        steps = n % 2 == 1 ? n : n + 1;
        tText = new String[n][steps];
        tSrc = new String[n][steps];
        tPic = new byte[n][steps][];
        showChain = 0;
        showItem = 0;
        showDone = false;
        beginStep(0);
    }

    private void beginStep(int k) {
        step = k;
        phase = k % 2 == 0 ? T_WRITE : T_DRAW;
        timeTotal = (phase == T_WRITE ? WRITE_TICKS : drawSeconds * 20);
        timeLeft = timeTotal;
        Arrays.fill(done, false);
        for (int s : tOrder) {
            prompt[s] = null;
            promptPic[s] = null;
            if (!active(s)) { done[s] = true; continue; }
            int c = chainOf(s, k);
            if (k > 0) {
                if (phase == T_DRAW) prompt[s] = tText[c][k - 1]; else promptPic[s] = tPic[c][k - 1];
            }
            if (phase == T_DRAW) tcan[s].clear();
            if (type[s] == BOT) botStep(s, c, k);
            else resendPrompt(s);
        }
        sink.changed();
    }

    /** Send a person the picture he has to describe (again). */
    public void resendPrompt(int s) {
        if (phase != T_WRITE || step == 0 || promptPic[s] == null) return;
        int c = chainOf(s, step);
        sink.tele(1 << s, 0, c, step, tOrder[(c + step - 1) % tOrder.length], "", promptPic[s]);
    }

    private String randomEntry() {
        return rnd.nextInt(10) < 7 && !artPool.isEmpty() ? artPool.get(rnd.nextInt(artPool.size())) : SkribblWords.entry(rnd.nextInt(SkribblWords.count()));
    }

    /** A computer player's turn in a telephone game: it writes a word, draws a picture it knows, or guesses. */
    private void botStep(int s, int c, int k) {
        if (phase == T_WRITE) {
            if (k == 0) { tText[c][0] = randomEntry(); done[s] = true; return; }
            byte[] px = SkribblCanvas.unzip(tPic[c][k - 1]);
            List<String> all = new ArrayList<>(artPool);
            for (int i = 0; i < SkribblWords.count(); i += 7) all.add(SkribblWords.entry(i));        // and some it cannot draw
            SkribblBrain.Pick p = px == null ? null : SkribblBrain.guess(px, all, 0.15 + 0.3 * (1 - skill[s]), rnd);
            tText[c][k] = p == null || p.score < 0.25 ? randomEntry() : p.entry;
        } else {
            String e = drawableFor(tText[c][k - 1]);
            for (String o : SkribblArt.draw(e)) tcan[s].add(o);
            tPic[c][k] = SkribblCanvas.zip(tcan[s].px);
            tSrc[c][k] = e;
        }
        done[s] = true;
    }

    /** The picture a computer player draws for a phrase: a word it knows that is in the phrase, otherwise any picture it knows. */
    private String drawableFor(String text) {
        String n = SkribblWords.norm(text == null ? "" : SkribblWords.en(text) + SkribblWords.ru(text));
        String found = null;
        int bestLen = 0;
        for (int i = 0; i < SkribblWords.count(); i++) {
            String e = SkribblWords.entry(i);
            if (!SkribblArt.can(e)) continue;
            String a = SkribblWords.norm(SkribblWords.en(e)), b = SkribblWords.norm(SkribblWords.ru(e));
            if (n.contains(a) && a.length() > bestLen) { found = e; bestLen = a.length(); }
            if (n.contains(b) && b.length() > bestLen) { found = e; bestLen = b.length(); }
        }
        return found != null ? found : artPool.get(rnd.nextInt(artPool.size()));
    }

    /** A person hands in his text (a phrase to draw, or the description of a picture). */
    public boolean submitText(int slot, String text) {
        if (phase != T_WRITE || type[slot] != HUMAN || indexOf(slot) < 0 || done[slot]) return false;
        String t = text == null ? "" : text.replace('|', ' ').trim();
        if (t.length() > 40) t = t.substring(0, 40);
        tText[chainOf(slot, step)][step] = t.isEmpty() ? "?" : t;
        done[slot] = true;
        sink.changed();
        return true;
    }

    /** A person says his picture is finished. */
    public boolean submitPicture(int slot) {
        if (phase != T_DRAW || type[slot] != HUMAN || indexOf(slot) < 0 || done[slot]) return false;
        tPic[chainOf(slot, step)][step] = SkribblCanvas.zip(tcan[slot].px);
        done[slot] = true;
        sink.changed();
        return true;
    }

    private void autoSubmit(int slot) {
        if (indexOf(slot) < 0 || done[slot]) return;
        int c = chainOf(slot, step);
        if (phase == T_WRITE) tText[c][step] = "?"; else tPic[c][step] = SkribblCanvas.zip(tcan[slot].px);
        done[slot] = true;
    }

    private void teleTick() {
        timeLeft--;
        boolean all = true;
        for (int s : tOrder) if (!done[s]) all = false;
        if (all && timeLeft > 30) timeLeft = 30;
        if (tickNo % 100 == 0) sink.changed();
        if (timeLeft <= 0) {
            for (int s : tOrder) autoSubmit(s);
            if (step + 1 < steps) beginStep(step + 1);
            else startShow();
        }
    }

    private void startShow() {
        phase = T_SHOW;
        showChain = 0;
        showItem = 0;
        showWait = 40;
        showDone = false;
        sink.changed();
    }

    private void showTick() {
        if (--showWait > 0) return;
        int n = tOrder.length;
        if (showChain >= n) {
            if (!showDone) { showDone = true; showWait = 8 * 20; sink.changed(); } else { phase = LOBBY; sink.changed(); }
            return;
        }
        int c = showChain, k = showItem;
        sink.tele(ALL, 1, c, k, tOrder[(c + k) % n], tText[c][k] == null ? "" : tText[c][k], tPic[c][k]);
        showItem++;
        if (showItem >= steps) { showItem = 0; showChain++; showWait = SHOW_GAP * 2; } else showWait = SHOW_GAP;
    }

    /** Bit mask of the slots that have handed in their work in this telephone step. */
    public int doneMask() {
        int m = 0;
        for (int s : tOrder) if (done[s]) m |= 1 << s;
        return m;
    }

    // ------------------------------------------------------------------ time

    /** One step: 1/20 of a second. */
    public void tick() {
        tickNo++;
        switch (phase) {
            case PICK -> {
                pickLeft--;
                boolean bot = type[drawer] == BOT;
                if (pickLeft <= 0 || (bot && pickLeft < PICK_TICKS - 30)) pick(drawer, rnd.nextInt(choices.length));
            }
            case DRAW -> drawing();
            case REVEAL -> { if (--revealLeft <= 0) nextTurn(); }
            case END -> { if (--endLeft <= 0) { phase = LOBBY; sink.changed(); } }
            case T_WRITE, T_DRAW -> teleTick();
            case T_SHOW -> showTick();
            default -> { }
        }
    }

    private int revealCount() {
        int pct = (timeTotal - timeLeft) * 100 / Math.max(1, timeTotal);
        return pct >= 70 ? 2 : pct >= 40 ? 1 : 0;
    }

    private void drawing() {
        int before = revealCount();
        timeLeft--;
        if (revealCount() != before || tickNo % 100 == 0) sink.changed();
        if (type[drawer] == BOT && botNext < botOps.size()) {
            botClock -= 1;
            if (botClock <= 0) {
                String o = botOps.get(botNext++);
                canvas.add(o);
                sink.draw(0, o, -1);
                botClock += botGap;
            }
        }
        if (tickNo % 20 == 0 && rnd.nextInt(30) == 0) {          // a computer player shows what it feels about the picture
            List<Integer> bots = new ArrayList<>();
            for (int i = 0; i < SLOTS; i++) if (type[i] == BOT && i != drawer) bots.add(i);
            if (!bots.isEmpty()) { int b = bots.get(rnd.nextInt(bots.size())); sink.chat(K_EMOJI, b, name[b], rnd.nextInt(EMOJIS), ALL); }
        }
        int elapsed = timeTotal - timeLeft;
        for (int i = 0; i < SLOTS && phase == DRAW; i++) {
            if (type[i] != BOT || i == drawer || guessed[i] || guesses[i] >= 7 || elapsed < nextThink[i]) continue;
            botThinks(i, elapsed);
        }
        if (phase == DRAW && timeLeft <= 0) endTurn();
    }

    /**
     * A computer player looks at the picture and the hint. The words that do not fit the hint (length, letters shown), the ones already
     * said wrong and the ones used earlier are out; of the rest it takes the one that looks most like the picture. If it is not sure yet it
     * waits and looks again (more is drawn, more letters show up); when only one word is left it knows.
     */
    private void botThinks(int i, int elapsed) {
        double frac = elapsed / (double) Math.max(1, timeTotal);
        int reveal = revealCount();
        String pat = SkribblWords.pattern(SkribblWords.en(word), reveal, seed);
        List<String> cands = new ArrayList<>();
        for (String c : pool) {
            if (c.equals(word) ? false : usedWords.contains(c)) continue;
            String en = SkribblWords.en(c);
            if (SkribblWords.fits(en, pat) && !said.contains(SkribblWords.norm(en)) && knows(i, c)) cands.add(c);
        }
        if (cands.isEmpty()) { nextThink[i] = elapsed + 200; guesses[i]++; return; }   // it has no idea at all
        double think = (1.6 - skill[i]) * (60 + rnd.nextInt(110));
        double noise = 0.12 + 0.3 * (1 - skill[i]);
        SkribblBrain.Pick p = SkribblBrain.guess(canvas.px, cands, noise, rnd);
        if (p == null) { nextThink[i] = elapsed + (int) think; return; }
        double need = Math.max(0.12, 0.62 - 0.45 * frac - 0.1 * reveal);
        if (cands.size() > 1 && p.score < need) { nextThink[i] = elapsed + (int) think; return; }   // not sure: look again later
        String pick = p.entry;
        guesses[i]++;
        if (pick.equals(word)) { solved(i); return; }
        said.add(SkribblWords.norm(SkribblWords.en(pick)));
        sink.chat(K_SAY, i, SkribblWords.en(pick), 0, ALL);
        nextThink[i] = elapsed + (int) (think * 0.8) + 20;
    }

    /** True if the computer player has the word in its head (a fixed share of the words, 55 to 95 percent, depending on the player). */
    private boolean knows(int i, String entry) {
        int h = (entry.hashCode() * 31 + salt[i]) * 0x9E3779B1;
        return ((h >>> 8) & 0xFFFF) % 100 < 55 + (int) (40 * skill[i]);
    }

    // ------------------------------------------------------------------ what the clients are shown

    public String hint(String lang) { return word.isEmpty() ? "" : SkribblWords.hint(SkribblWords.word(word, lang), revealCount(), seed); }

    public int guessedMask() {
        int m = 0;
        for (int i = 0; i < SLOTS; i++) if (guessed[i]) m |= 1 << i;
        return m;
    }

    /** What the player may see of the word right now: the secret word, the prompt of a telephone drawing step, or nothing. */
    public String wordFor(int slot) {
        if (phase == T_DRAW) return prompt[slot] == null ? "" : prompt[slot];
        if (phase == T_WRITE || phase == T_SHOW) return "";
        return !word.isEmpty() && (phase == REVEAL || slot == drawer || guessed[slot]) ? word : "";
    }
}
