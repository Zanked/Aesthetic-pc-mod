package dev.cutemod.data;

import java.util.Random;
import java.util.UUID;

/**
 * The hardware of a player's computer, shared by the server (which installs the upgrades) and the client (which shows them).
 * Every player starts with the same worst "stock" PC (nothing is saved for it); upgrade parts bought in
 * CuteMarket and installed into a computer are saved on the SERVER as one small text ("hw") and only ever make the PC better:
 * a part is used when its level is higher than what the PC has. Nothing here touches the game, so both sides can use it.
 */
public final class PcHardware {
    private PcHardware() {}

    public enum Kind { RAM, GPU, DISK, MODEM }

    // ---------- the ladders (index = level) ----------
    public static final int[] RAM_GB = {2, 4, 8, 16, 32, 64};
    public static final int[] DISK_GB = {16, 32, 48, 64, 96, 128, 160, 256, 512, 1024};
    public static final String[] GPU_NAMES = {"Cute Graphics (shared)", "Meowforce GT 710", "Meowforce GTX 1050", "Pixel Radish 5500",
            "Meowforce RTX 3060", "Pixel Radish 7800", "Meowforce RTX 4080", "Pixel Radish 9900 XT"};
    public static final int[] VRAM_GB = {0, 2, 4, 6, 8, 12, 16, 24};

    /** How fast the drive writes (installs a game), relative to a plain SSD = 1.0: the small drives are slow hard disks, the big ones are NVMe. */
    public static final double[] DISK_SPEED = {0.5, 0.7, 1.0, 1.4, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0};

    public static double diskSpeed(int diskIdx) { return DISK_SPEED[Math.max(0, Math.min(DISK_SPEED.length - 1, diskIdx))]; }

    // ---------- how long the computer takes to start ----------
    /** Boot ticks (about 60 a second) that the memory and the drive each add. The stock PC (2 GB, slow HDD) needs 540 ticks = 9 s,
     *  a 16 GB PC with a 128 GB drive 150 ticks = 2.5 s (the old fixed time), the best one (64 GB, 1 TB NVMe) 50 ticks = under 1 s. */
    private static final int[] BOOT_RAM = {240, 180, 120, 80, 50, 30};
    private static final int[] BOOT_DISK = {300, 240, 190, 140, 100, 70, 50, 40, 30, 20};

    /** How many ticks the start-up screen runs for a PC with this memory level and this drive level. */
    public static int bootTicks(int ramIdx, int diskIdx) {
        int r = Math.max(0, Math.min(BOOT_RAM.length - 1, ramIdx));
        int d = Math.max(0, Math.min(BOOT_DISK.length - 1, diskIdx));
        return BOOT_RAM[r] + BOOT_DISK[d];
    }

    /** 0 = HDD, 1 = SSD, 2 = NVMe: what kind of drive this level is. */
    public static int diskKind(int diskIdx) { return diskIdx <= 1 ? 0 : diskIdx <= 3 ? 1 : 2; }

    // ---------- the modem: without one the online apps do not work; a PC never has one from the start ----------
    /** Level 0 = no modem. 1 is the weakest (slow, drops now and then), 5 the best. */
    public static final String[] MODEM_NAMES = {"No modem", "Cute Dial-Up 56K", "Cute ADSL", "Cute Cable", "Cute Fiber 300", "Cute Fiber Max"};
    public static final int[] MODEM_MBPS = {0, 1, 8, 50, 300, 1000};
    /** How fast downloads (installing games and apps) run with this modem, 1.0 = the old speed. */
    public static final double[] MODEM_SPEED = {0.0, 0.25, 0.6, 1.0, 2.0, 4.0};
    private static final int[] MODEM_PRICE = {0, 20, 60, 140, 300, 600};
    public static final int MODEM_FIRST = 1, MODEM_LAST = 5;

    public static double modemSpeed(int level) { return level < 1 ? 0.0 : MODEM_SPEED[Math.min(level, MODEM_SPEED.length - 1)]; }

    /**
     * True while the modem is out at this moment: the weak ones lose the connection now and then (level 1 often and for long,
     * level 2 rarely and for a few seconds, the others never). Nothing is stored: for one player and one moment the answer is
     * always the same, so every screen agrees.
     */
    public static boolean modemDown(int level, long seed, long nowMs) {
        if (level < 1 || level > 2) return false;
        long cycle = level == 1 ? 40_000L : 120_000L;
        long n = Math.floorDiv(nowMs, cycle);
        Random r = new Random(seed * 31L + n * 0x9E3779B97F4A7C15L + level);
        if (r.nextInt(100) >= (level == 1 ? 65 : 30)) return false;
        long len = level == 1 ? 6_000L + r.nextInt(8_001) : 3_000L + r.nextInt(3_001);
        long start = r.nextInt((int) (cycle - len - 1_000L));
        long pos = nowMs - n * cycle;
        return pos >= start && pos < start + len;
    }

    /** The levels that exist as parts in the shop (only the very first RAM, video card and drive are never sold: every PC starts with them). */
    public static final int RAM_FIRST = 1, RAM_LAST = 5, GPU_FIRST = 1, GPU_LAST = 7, DISK_FIRST = 1, DISK_LAST = 9;

    public static int first(Kind k) { return switch (k) { case RAM -> RAM_FIRST; case GPU -> GPU_FIRST; case DISK -> DISK_FIRST; case MODEM -> MODEM_FIRST; }; }
    public static int last(Kind k) { return switch (k) { case RAM -> RAM_LAST; case GPU -> GPU_LAST; case DISK -> DISK_LAST; case MODEM -> MODEM_LAST; }; }

    private static final int[] RAM_PRICE = {0, 30, 70, 140, 260, 480};
    private static final int[] GPU_PRICE = {0, 50, 120, 240, 420, 700, 1100, 1600};
    private static final int[] DISK_PRICE = {0, 25, 50, 100, 170, 260, 380, 580, 950, 1500};

    /** Price in coins of the part (the shop sells it for this). */
    public static int price(Kind k, int level) {
        return switch (k) { case RAM -> RAM_PRICE[level]; case GPU -> GPU_PRICE[level]; case DISK -> DISK_PRICE[level]; case MODEM -> MODEM_PRICE[level]; };
    }

    /** Delivery time in seconds: the better the part, the longer the courier takes. */
    public static int secs(Kind k, int level) {
        int rel = level - (k == Kind.DISK ? 2 : first(k));      // the cheap 32 GB drive arrives as fast as the 48 GB one did
        if (rel < 0) rel = 0;
        return 60 + rel * 30;
    }

    /** The id of the item / shop entry of a part: pc_ram_16, pc_gpu_4, pc_disk_96. */
    public static String partId(Kind k, int level) {
        return switch (k) {
            case RAM -> "pc_ram_" + RAM_GB[level];
            case GPU -> "pc_gpu_" + level;
            case DISK -> "pc_disk_" + DISK_GB[level];
            case MODEM -> "pc_modem_" + level;
        };
    }

    // ---------- the stock PC of a player (the same worst one for everybody) ----------
    /** What the stock PC of a player is made of, as tiers (indices into the ladders). */
    public record Base(int cpuTier, int cores, double ghz, int ramIdx, int gpuTier, int diskIdx,
                       int diskD, int usedDPct, int baseRand, long seed) {}

    private static final int[][] CORES = {{2, 4}, {4, 6}, {6, 8}, {8, 12}, {12, 16}};

    /** The number the random PC of this player is worked out from (0 when there is no player yet). */
    public static long seedOf(UUID id) {
        return id == null ? 0L : (id.getMostSignificantBits() ^ (id.getLeastSignificantBits() * 31L));
    }

    /**
     * The stock PC of a player. Everybody starts with the very same worst computer (the weakest processor, 2 GB of memory,
     * the shared video card, the smallest slow drive, no second drive); only the seed differs, and it still gives each PC its own name.
     * Better parts have to be bought in CuteMarket. (The random PCs worked out from the seed are not used any more.)
     */
    public static Base base(long seed) {
        return new Base(0, CORES[0][0], 1.6, 0, 0, 0, 0, 0, 8, seed);
    }

    // ---------- what is installed ----------
    /** Installed parts as levels in the order RAM, GPU, DISK, MODEM; -1 = nothing installed (the stock part is used). */
    public static int[] parse(String text) {
        int[] hw = {-1, -1, -1, -1};
        if (text == null) return hw;
        String[] p = text.trim().split(",");
        for (int i = 0; i < 4 && i < p.length; i++) {
            try { hw[i] = Math.max(-1, Math.min(last(Kind.values()[i]), Integer.parseInt(p[i].trim()))); }
            catch (NumberFormatException ignored) { }
        }
        return hw;
    }

    public static String write(int[] hw) { return hw[0] + "," + hw[1] + "," + hw[2] + "," + hw[3]; }

    /** The level the PC really has: the better of the stock part and the installed one. */
    public static int effective(Base b, int[] hw, Kind k) {
        int stock = switch (k) { case RAM -> b.ramIdx(); case GPU -> b.gpuTier(); case DISK -> b.diskIdx(); case MODEM -> -1; };   // a PC never comes with a modem
        return Math.max(stock, hw[k.ordinal()]);
    }

    /** 0 low, 1 medium, 2 high, 3 ultra: how nice the games look with this video card. The first card already changes the picture. */
    public static int gpuLevel(int gpuTier) {
        return gpuTier <= 0 ? 0 : gpuTier <= 2 ? 1 : gpuTier <= 5 ? 2 : 3;
    }
}
