package dev.cutemod.data;

import java.util.ArrayList;
import java.util.List;

/**
 * The little pictures the computer artists draw in Scribble Pals: for every word below {@link SkribblWords#ART} a list of
 * drawing operations (see {@link SkribblCanvas}). They are drawn the way a person would: an outline, then the colour,
 * then the details, a few points at a time.
 */
public final class SkribblArt {
    private SkribblArt() {}

    // palette numbers
    static final int PAPER = 0, INK = 1, GREY = 2, RED = 3, ORANGE = 4, YELLOW = 5, GREEN = 6, TEAL = 7, SKY = 8, BLUE = 9,
            PURPLE = 10, PINK = 11, BROWN = 12, BEIGE = 13, MINT = 14, LAV = 15;
    static final int THIN = 0, MID = 1, FAT = 2, HUGE = 3;

    private static final java.util.Map<String, java.util.function.Consumer<B>> ART = new java.util.HashMap<>();

    static {
        ART.put("sun", SkribblArt::sun); ART.put("moon", SkribblArt::moon); ART.put("star", SkribblArt::star); ART.put("heart", SkribblArt::heart);
        ART.put("flower", SkribblArt::flower); ART.put("tree", SkribblArt::tree); ART.put("house", SkribblArt::house); ART.put("cat", SkribblArt::cat);
        ART.put("fish", SkribblArt::fish); ART.put("apple", SkribblArt::apple); ART.put("cake", SkribblArt::cake); ART.put("car", SkribblArt::car);
        ART.put("boat", SkribblArt::boat); ART.put("umbrella", SkribblArt::umbrella); ART.put("mushroom", SkribblArt::mushroom);
        ART.put("snowman", SkribblArt::snowman); ART.put("ghost", SkribblArt::ghost); ART.put("bee", SkribblArt::bee); ART.put("panda", SkribblArt::panda);
        ART.put("rabbit", SkribblArt::rabbit); ART.put("ice cream", SkribblArt::iceCream); ART.put("cloud", SkribblArt::cloudArt);
        ART.put("balloon", SkribblArt::balloon); ART.put("pumpkin", SkribblArt::pumpkin); ART.put("cup", SkribblArt::cup); ART.put("key", SkribblArt::key);
        ART.put("crown", SkribblArt::crown); ART.put("rainbow", SkribblArt::rainbow);
        ART.put("creeper", SkribblArt2::creeper); ART.put("diamond", SkribblArt2::diamond); ART.put("pickaxe", SkribblArt2::pickaxe);
        ART.put("sword", SkribblArt2::sword); ART.put("torch", SkribblArt2::torch); ART.put("tnt", SkribblArt2::tnt); ART.put("chest", SkribblArt2::chest);
        ART.put("penguin", SkribblArt2::penguin); ART.put("frog", SkribblArt2::frog); ART.put("pig", SkribblArt2::pig); ART.put("dog", SkribblArt2::dog);
        ART.put("owl", SkribblArt2::owl); ART.put("butterfly", SkribblArt2::butterfly); ART.put("snail", SkribblArt2::snail);
        ART.put("turtle", SkribblArt2::turtle); ART.put("spider", SkribblArt2::spider); ART.put("bat", SkribblArt2::bat);
        ART.put("donut", SkribblArt2::donut); ART.put("pizza", SkribblArt2::pizza); ART.put("cookie", SkribblArt2::cookie);
        ART.put("banana", SkribblArt2::banana); ART.put("strawberry", SkribblArt2::strawberry); ART.put("carrot", SkribblArt2::carrot);
        ART.put("onigiri", SkribblArt2::onigiri); ART.put("egg", SkribblArt2::egg); ART.put("rocket", SkribblArt2::rocket);
        ART.put("campfire", SkribblArt2::campfire); ART.put("lightning", SkribblArt2::lightning); ART.put("snowflake", SkribblArt2::snowflake);
        ART.put("planet", SkribblArt2::planet); ART.put("robot", SkribblArt2::robot); ART.put("gift", SkribblArt2::gift); ART.put("bell", SkribblArt2::bell);
        ART.put("candle", SkribblArt2::candle); ART.put("teddy bear", SkribblArt2::teddy); ART.put("kitten", SkribblArt2::kitten);
    }

    /** True if the computer artists can draw the word (a "en|ru" entry of the word table). */
    public static boolean can(String entry) { return ART.containsKey(SkribblWords.en(entry)); }

    /** The operations that draw the picture of this word (an empty list for a word the computer cannot draw). */
    public static List<String> draw(String entry) {
        B b = new B();
        java.util.function.Consumer<B> f = ART.get(SkribblWords.en(entry));
        if (f != null) f.accept(b);
        return b.ops;
    }

    // ------------------------------------------------------------------ the builder

    static final class B {
        final List<String> ops = new ArrayList<>();
        int stroke = 1;

        void path(int col, int size, double[] pts) {
            List<int[]> p = new ArrayList<>();
            for (int i = 0; i + 1 < pts.length; i += 2) {
                int x = clampX(pts[i]), y = clampY(pts[i + 1]);
                if (p.isEmpty() || p.get(p.size() - 1)[0] != x || p.get(p.size() - 1)[1] != y) p.add(new int[]{x, y});
            }
            if (p.isEmpty()) return;
            if (p.size() == 1) p.add(new int[]{p.get(0)[0], p.get(0)[1]});
            int i = 0;
            while (i < p.size() - 1 || i == 0) {
                StringBuilder s = new StringBuilder().append(stroke).append(',').append(SkribblCanvas.PEN).append(',').append(col).append(',').append(size);
                int end = Math.min(p.size() - 1, i + 7);
                for (int k = i; k <= end; k++) s.append(',').append(p.get(k)[0]).append(',').append(p.get(k)[1]);
                ops.add(s.toString());
                if (end >= p.size() - 1) break;
                i = end;
            }
            stroke++;
        }

        void line(double x0, double y0, double x1, double y1, int col, int size) { path(col, size, new double[]{x0, y0, x1, y1}); }

        void dot(double x, double y, int col, int size) { path(col, size, new double[]{x, y}); }

        void poly(int col, int size, double... xy) {
            double[] c = java.util.Arrays.copyOf(xy, xy.length + 2);
            c[xy.length] = xy[0];
            c[xy.length + 1] = xy[1];
            path(col, size, c);
        }

        void arc(double cx, double cy, double rx, double ry, double a0, double a1, int col, int size) {
            int n = Math.max(6, (int) (Math.abs(a1 - a0) / 9));
            double[] p = new double[(n + 1) * 2];
            for (int i = 0; i <= n; i++) {
                double a = Math.toRadians(a0 + (a1 - a0) * i / n);
                p[i * 2] = cx + Math.cos(a) * rx;
                p[i * 2 + 1] = cy + Math.sin(a) * ry;
            }
            path(col, size, p);
        }

        void ellipse(double cx, double cy, double rx, double ry, int col, int size) { arc(cx, cy, rx, ry, 0, 360, col, size); }

        void circle(double cx, double cy, double r, int col, int size) { ellipse(cx, cy, r, r, col, size); }

        void rect(double x0, double y0, double x1, double y1, int col, int size) { poly(col, size, x0, y0, x1, y0, x1, y1, x0, y1); }

        /** An outlined, filled rectangle. */
        void box(double x0, double y0, double x1, double y1, int fillCol, int size) {
            rect(x0, y0, x1, y1, INK, size);
            fill((x0 + x1) / 2, (y0 + y1) / 2, fillCol);
        }

        /** An outlined, filled polygon; the colour goes in at (fx, fy). */
        void shape(int fillCol, double fx, double fy, double... xy) {
            poly(INK, MID, xy);
            fill(fx, fy, fillCol);
        }

        /** An outlined, filled oval. */
        void oval(double cx, double cy, double rx, double ry, int fillCol, int size) {
            ellipse(cx, cy, rx, ry, INK, size);
            fill(cx, cy, fillCol);
        }

        void fill(double x, double y, int col) {
            ops.add(stroke++ + "," + SkribblCanvas.FILL + "," + col + ",0," + clampX(x) + "," + clampY(y));
        }
    }

    /** The outline of the union of some discs {x, y, r}, seen from (cx, cy) and cut flat at maxY. */
    static double[] blob(double cx, double cy, double[][] discs, double maxY) {
        double[] p = new double[2 * 61];
        for (int i = 0; i <= 60; i++) {
            double a = Math.toRadians(i * 6.0), best = 0;
            for (double t = 4; t < 70; t += 0.5) {
                double x = cx + Math.cos(a) * t, y = cy + Math.sin(a) * t;
                for (double[] d : discs) if ((x - d[0]) * (x - d[0]) + (y - d[1]) * (y - d[1]) <= d[2] * d[2]) best = t;
            }
            p[i * 2] = cx + Math.cos(a) * best;
            p[i * 2 + 1] = Math.min(maxY, cy + Math.sin(a) * best);
        }
        return p;
    }

    private static int clampX(double x) { return (int) Math.max(0, Math.min(SkribblCanvas.CW - 1, Math.round(x))); }

    private static int clampY(double y) { return (int) Math.max(0, Math.min(SkribblCanvas.CH - 1, Math.round(y))); }

    // ------------------------------------------------------------------ the pictures

    private static void sun(B b) {
        for (int i = 0; i < 8; i++) {
            double a = Math.toRadians(i * 45 + 22.5);
            b.line(60 + Math.cos(a) * 21, 40 + Math.sin(a) * 21, 60 + Math.cos(a) * 31, 40 + Math.sin(a) * 31, ORANGE, MID);
        }
        b.circle(60, 40, 15, INK, MID);
        b.fill(60, 40, YELLOW);
        b.dot(54, 36, INK, MID);
        b.dot(66, 36, INK, MID);
        b.arc(60, 40, 8, 7, 25, 155, INK, THIN);
        b.dot(50, 43, PINK, MID);
        b.dot(70, 43, PINK, MID);
    }

    private static void moon(B b) {
        double[] p = new double[(60 + 60) * 2];
        int k = 0;
        for (int i = 0; i < 60; i++) {
            double a = Math.toRadians(-56.2 - (303.8 - 56.2) * i / 59.0);
            p[k++] = 56 + Math.cos(a) * 24;
            p[k++] = 40 + Math.sin(a) * 24;
        }
        for (int i = 0; i < 60; i++) {
            double a = Math.toRadians(86.2 + (273.8 - 86.2) * i / 59.0);
            p[k++] = 68 + Math.cos(a) * 20;
            p[k++] = 40 + Math.sin(a) * 20;
        }
        b.path(INK, MID, p);
        b.line(p[0], p[1], p[2 * 119], p[2 * 119 + 1], INK, MID);
        b.fill(44, 40, YELLOW);
        b.dot(40, 34, INK, THIN);
        b.arc(38, 44, 5, 4, 20, 150, INK, THIN);
        for (double[] s : new double[][]{{92, 20}, {104, 46}, {88, 62}}) {
            b.line(s[0] - 4, s[1], s[0] + 4, s[1], PURPLE, THIN);
            b.line(s[0], s[1] - 4, s[0], s[1] + 4, PURPLE, THIN);
        }
    }

    private static void star(B b) {
        double[] p = new double[20];
        for (int i = 0; i < 10; i++) {
            double r = i % 2 == 0 ? 33 : 14, a = Math.toRadians(-90 + i * 36);
            p[i * 2] = 60 + Math.cos(a) * r;
            p[i * 2 + 1] = 43 + Math.sin(a) * r;
        }
        b.poly(INK, MID, p);
        b.fill(60, 43, YELLOW);
        b.dot(54, 42, INK, MID);
        b.dot(66, 42, INK, MID);
        b.arc(60, 44, 5, 4, 20, 160, INK, THIN);
        b.dot(50, 47, PINK, MID);
        b.dot(70, 47, PINK, MID);
    }

    private static void heart(B b) {
        double[] p = new double[2 * 41];
        for (int i = 0; i <= 40; i++) {
            double t = Math.PI * 2 * i / 40;
            p[i * 2] = 60 + 1.9 * 16 * Math.pow(Math.sin(t), 3);
            p[i * 2 + 1] = 38 - 1.9 * (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
        }
        b.path(INK, MID, p);
        b.fill(60, 36, PINK);
        b.arc(60, 36, 24, 20, 200, 250, PAPER, MID);
        b.dot(50, 33, INK, MID);
        b.dot(70, 33, INK, MID);
        b.arc(60, 40, 6, 5, 20, 160, INK, THIN);
    }

    private static void flower(B b) {
        b.line(60, 78, 60, 46, GREEN, FAT);
        b.ellipse(50, 63, 8, 4, INK, THIN);
        b.fill(50, 63, GREEN);
        b.ellipse(70, 56, 8, 4, INK, THIN);
        b.fill(70, 56, GREEN);
        for (int i = 0; i < 6; i++) {
            double a = Math.toRadians(i * 60 - 90);
            double cx = 60 + Math.cos(a) * 13, cy = 30 + Math.sin(a) * 13;
            b.circle(cx, cy, 9, INK, MID);
            b.fill(60 + Math.cos(a) * 18, 30 + Math.sin(a) * 18, PINK);
        }
        b.circle(60, 30, 7, INK, MID);
        b.fill(60, 30, YELLOW);
    }

    private static void tree(B b) {
        b.rect(53, 48, 67, 76, INK, MID);
        b.fill(60, 62, BROWN);
        b.circle(60, 30, 23, INK, MID);
        b.fill(60, 30, GREEN);
        b.dot(50, 24, RED, MID);
        b.dot(68, 20, RED, MID);
        b.dot(62, 38, RED, MID);
        b.dot(48, 38, RED, MID);
        b.line(22, 77, 98, 77, GREEN, MID);
    }

    private static void house(B b) {
        b.rect(78, 14, 87, 34, INK, MID);
        b.fill(82, 24, BROWN);
        b.rect(30, 38, 90, 74, INK, MID);
        b.fill(60, 70, BEIGE);
        b.poly(INK, MID, 23, 40, 60, 10, 97, 40);
        b.fill(60, 30, RED);
        b.rect(53, 50, 69, 74, INK, MID);
        b.fill(60, 66, BROWN);
        b.dot(65, 63, YELLOW, MID);
        b.rect(36, 46, 48, 58, INK, MID);
        b.fill(42, 52, SKY);
        b.line(42, 46, 42, 58, INK, THIN);
        b.line(36, 52, 48, 52, INK, THIN);
        b.rect(72, 46, 84, 58, INK, MID);
        b.fill(78, 52, SKY);
    }

    private static void cat(B b) {
        b.poly(INK, MID, 38, 34, 40, 10, 56, 24);
        b.fill(41, 22, ORANGE);
        b.poly(INK, MID, 82, 34, 80, 10, 64, 24);
        b.fill(79, 22, ORANGE);
        b.circle(60, 46, 23, INK, MID);
        b.fill(60, 52, ORANGE);
        b.line(60, 25, 60, 32, BROWN, MID);
        b.line(50, 27, 52, 33, BROWN, MID);
        b.line(70, 27, 68, 33, BROWN, MID);
        b.dot(51, 44, INK, MID);
        b.dot(69, 44, INK, MID);
        b.poly(PINK, THIN, 57, 50, 63, 50, 60, 54);
        b.line(60, 54, 60, 57, INK, THIN);
        b.arc(56, 57, 4, 3, 0, 160, INK, THIN);
        b.arc(64, 57, 4, 3, 20, 180, INK, THIN);
        b.line(36, 50, 46, 52, INK, THIN);
        b.line(36, 57, 46, 55, INK, THIN);
        b.line(84, 50, 74, 52, INK, THIN);
        b.line(84, 57, 74, 55, INK, THIN);
    }

    private static void fish(B b) {
        b.poly(INK, MID, 78, 40, 100, 22, 100, 58);
        b.fill(94, 40, BLUE);
        b.poly(INK, MID, 44, 30, 54, 12, 66, 30);
        b.fill(54, 24, BLUE);
        b.ellipse(54, 40, 27, 17, INK, MID);
        b.fill(54, 40, SKY);
        b.dot(38, 36, INK, MID);
        b.arc(30, 44, 6, 5, 20, 130, INK, THIN);
        b.arc(56, 40, 8, 10, -60, 60, INK, THIN);
        b.arc(64, 40, 8, 10, -60, 60, INK, THIN);
        b.circle(20, 20, 4, BLUE, THIN);
        b.circle(14, 10, 3, BLUE, THIN);
        b.circle(26, 8, 2, BLUE, THIN);
    }

    private static void apple(B b) {
        b.path(INK, MID, blob(60, 48, new double[][]{{49, 45, 20}, {71, 45, 20}, {60, 54, 19}}, 77));
        b.fill(60, 52, RED);
        b.line(60, 26, 64, 13, BROWN, MID);
        b.ellipse(73, 16, 9, 5, INK, THIN);
        b.fill(73, 16, GREEN);
        b.arc(46, 44, 11, 14, 200, 250, PINK, MID);
    }

    private static void cake(B b) {
        for (int i = 0; i < 3; i++) {
            double x = 44 + i * 16;
            b.rect(x - 2, 22, x + 2, 36, INK, THIN);
            b.fill(x, 30, SKY);
            b.dot(x, 18, ORANGE, MID);
        }
        b.rect(26, 36, 94, 70, INK, MID);
        b.fill(60, 60, BEIGE);
        b.rect(26, 36, 94, 48, INK, MID);
        b.fill(60, 42, PINK);
        for (int i = 0; i < 6; i++) b.arc(32 + i * 11.2, 48, 5.6, 6, 0, 180, PINK, MID);
        b.dot(40, 58, RED, MID);
        b.dot(60, 62, RED, MID);
        b.dot(80, 58, RED, MID);
        b.line(20, 71, 100, 71, INK, MID);
    }

    private static void car(B b) {
        b.poly(INK, MID, 34, 40, 46, 22, 80, 22, 92, 40);
        b.fill(60, 34, RED);
        b.rect(12, 40, 108, 58, INK, MID);
        b.fill(60, 50, RED);
        b.poly(INK, THIN, 40, 38, 48, 26, 58, 26, 58, 38);
        b.fill(52, 34, SKY);
        b.poly(INK, THIN, 62, 26, 78, 26, 86, 38, 62, 38);
        b.fill(72, 34, SKY);
        b.circle(36, 60, 10, INK, MID);
        b.fill(36, 60, GREY);
        b.circle(86, 60, 10, INK, MID);
        b.fill(86, 60, GREY);
        b.dot(36, 60, INK, MID);
        b.dot(86, 60, INK, MID);
        b.dot(104, 46, YELLOW, MID);
    }

    private static void boat(B b) {
        b.poly(INK, MID, 22, 52, 98, 52, 86, 70, 34, 70);
        b.fill(60, 62, BROWN);
        b.line(60, 52, 60, 10, INK, MID);
        b.poly(INK, MID, 62, 14, 62, 48, 92, 48);
        b.fill(66, 40, PINK);
        b.poly(INK, MID, 58, 20, 58, 48, 34, 48);
        b.fill(54, 42, LAV);
        b.poly(RED, THIN, 60, 10, 70, 13, 60, 16);
        b.arc(30, 74, 8, 4, 180, 360, BLUE, MID);
        b.arc(46, 74, 8, 4, 180, 360, BLUE, MID);
        b.arc(76, 74, 8, 4, 180, 360, BLUE, MID);
        b.arc(92, 74, 8, 4, 180, 360, BLUE, MID);
    }

    private static void umbrella(B b) {
        double[] p = new double[2 * 30];
        for (int i = 0; i < 15; i++) {
            double a = Math.toRadians(180 + 180.0 * i / 14);
            p[i * 2] = 60 + Math.cos(a) * 36;
            p[i * 2 + 1] = 44 + Math.sin(a) * 34;
        }
        for (int i = 0; i < 15; i++) {          // the scalloped edge, back from the right
            double x = 96 - i * (72.0 / 14);
            p[(15 + i) * 2] = x;
            p[(15 + i) * 2 + 1] = 44 + (i % 2 == 0 ? 0 : 5);
        }
        b.poly(INK, MID, p);
        b.fill(32, 38, PINK);
        b.line(60, 10, 60, 44, INK, THIN);
        b.line(60, 10, 38, 44, INK, THIN);
        b.line(60, 10, 82, 44, INK, THIN);
        b.fill(51, 38, RED);
        b.fill(69, 38, PINK);
        b.fill(88, 38, RED);
        b.line(60, 46, 60, 68, INK, MID);
        b.arc(66, 68, 6, 6, 180, 360 - 180 + 180, INK, MID);
        b.line(60, 8, 60, 4, INK, MID);
    }

    private static void mushroom(B b) {
        b.poly(INK, MID, 49, 44, 71, 44, 73, 72, 47, 72);
        b.fill(60, 60, BEIGE);
        double[] p = new double[2 * 21];
        for (int i = 0; i <= 20; i++) {
            double a = Math.toRadians(180 + 180.0 * i / 20);
            p[i * 2] = 60 + Math.cos(a) * 36;
            p[i * 2 + 1] = 44 + Math.sin(a) * 28;
        }
        b.poly(INK, MID, p);
        b.fill(60, 30, RED);
        for (double[] s : new double[][]{{46, 32, 6}, {70, 26, 5}, {60, 38, 4}, {80, 38, 4}}) {
            b.circle(s[0], s[1], s[2], INK, THIN);
            b.fill(s[0], s[1], PAPER);
        }
        b.dot(56, 56, INK, MID);
        b.dot(64, 56, INK, MID);
        b.line(30, 76, 90, 76, GREEN, MID);
    }

    private static void snowman(B b) {
        b.circle(60, 60, 16, INK, MID);
        b.circle(60, 38, 12, INK, MID);
        b.circle(60, 21, 9, INK, MID);
        b.fill(60, 66, SKY);
        b.fill(60, 40, SKY);
        b.fill(60, 22, SKY);
        b.rect(52, 6, 68, 14, INK, MID);
        b.fill(60, 10, PURPLE);
        b.line(48, 14, 72, 14, INK, MID);
        b.poly(ORANGE, THIN, 60, 22, 70, 24, 60, 25);
        b.dot(56, 19, INK, THIN);
        b.dot(64, 19, INK, THIN);
        b.dot(60, 52, INK, MID);
        b.dot(60, 60, INK, MID);
        b.dot(60, 68, INK, MID);
        b.line(50, 32, 40, 24, BROWN, MID);
        b.line(70, 32, 80, 24, BROWN, MID);
        b.line(52, 31, 68, 31, RED, MID);
    }

    private static void ghost(B b) {
        double[] p = new double[2 * 40];
        int k = 0;
        for (int i = 0; i <= 14; i++) {
            double a = Math.toRadians(180 + 180.0 * i / 14);
            p[k++] = 60 + Math.cos(a) * 22;
            p[k++] = 36 + Math.sin(a) * 24;
        }
        p[k++] = 82; p[k++] = 70;
        double[] xs = {75, 68, 61, 54, 47, 40}, ys = {76, 70, 76, 70, 76, 70};
        for (int i = 0; i < 6; i++) { p[k++] = xs[i]; p[k++] = ys[i]; }
        p[k++] = 38; p[k++] = 70;
        p[k++] = 38; p[k++] = 36;
        b.path(INK, MID, java.util.Arrays.copyOf(p, k));
        b.fill(60, 44, LAV);
        b.circle(52, 38, 4, INK, MID);
        b.circle(68, 38, 4, INK, MID);
        b.circle(60, 50, 3, INK, THIN);
        b.dot(46, 46, PINK, MID);
        b.dot(74, 46, PINK, MID);
    }

    private static void bee(B b) {
        b.ellipse(50, 22, 8, 11, INK, THIN);
        b.fill(50, 22, SKY);
        b.ellipse(68, 22, 8, 11, INK, THIN);
        b.fill(68, 22, SKY);
        b.ellipse(60, 44, 26, 17, INK, MID);
        b.fill(60, 44, YELLOW);
        b.line(52, 30, 52, 58, INK, FAT);
        b.line(66, 30, 66, 58, INK, FAT);
        b.poly(INK, THIN, 34, 44, 26, 42, 26, 46);
        b.dot(78, 38, INK, MID);
        b.arc(80, 46, 4, 3, 20, 150, INK, THIN);
        b.line(76, 28, 80, 20, INK, THIN);
        b.line(84, 30, 90, 24, INK, THIN);
        b.dot(80, 19, INK, MID);
        b.dot(91, 23, INK, MID);
    }

    private static void panda(B b) {
        b.circle(38, 22, 9, INK, MID);
        b.fill(38, 22, INK);
        b.circle(82, 22, 9, INK, MID);
        b.fill(82, 22, INK);
        b.circle(60, 44, 26, INK, MID);
        b.fill(60, 56, PAPER);
        b.ellipse(49, 42, 7, 9, INK, THIN);
        b.fill(49, 42, INK);
        b.ellipse(71, 42, 7, 9, INK, THIN);
        b.fill(71, 42, INK);
        b.dot(50, 40, PAPER, THIN);
        b.dot(70, 40, PAPER, THIN);
        b.ellipse(60, 52, 4, 3, INK, THIN);
        b.fill(60, 52, INK);
        b.arc(56, 57, 4, 3, 0, 160, INK, THIN);
        b.arc(64, 57, 4, 3, 20, 180, INK, THIN);
        b.dot(40, 54, PINK, MID);
        b.dot(80, 54, PINK, MID);
    }

    private static void rabbit(B b) {
        b.ellipse(48, 20, 7, 17, INK, MID);
        b.ellipse(72, 20, 7, 17, INK, MID);
        b.fill(48, 14, PAPER);
        b.ellipse(48, 22, 3, 11, PINK, THIN);
        b.ellipse(72, 22, 3, 11, PINK, THIN);
        b.circle(60, 52, 20, INK, MID);
        b.fill(60, 62, BEIGE);
        b.dot(52, 48, INK, MID);
        b.dot(68, 48, INK, MID);
        b.poly(PINK, THIN, 57, 54, 63, 54, 60, 58);
        b.line(60, 58, 60, 61, INK, THIN);
        b.arc(56, 61, 4, 3, 0, 160, INK, THIN);
        b.arc(64, 61, 4, 3, 20, 180, INK, THIN);
        b.line(40, 54, 49, 56, INK, THIN);
        b.line(40, 61, 49, 59, INK, THIN);
        b.line(80, 54, 71, 56, INK, THIN);
        b.line(80, 61, 71, 59, INK, THIN);
        b.dot(44, 56, PINK, MID);
        b.dot(76, 56, PINK, MID);
    }

    private static void iceCream(B b) {
        b.poly(INK, MID, 44, 42, 76, 42, 60, 76);
        b.fill(60, 50, BEIGE);
        b.line(50, 50, 66, 62, BROWN, THIN);
        b.line(70, 50, 54, 62, BROWN, THIN);
        b.circle(60, 32, 16, INK, MID);
        b.fill(60, 34, PINK);
        b.circle(60, 18, 12, INK, MID);
        b.fill(60, 14, MINT);
        b.dot(60, 5, RED, FAT);
        b.line(60, 5, 66, 1, GREEN, THIN);
        b.dot(54, 32, PAPER, MID);
        b.dot(66, 38, PAPER, MID);
    }

    private static void cloudArt(B b) {
        double[] p = blob(66, 46, new double[][]{{40, 46, 13}, {58, 36, 17}, {78, 44, 14}, {94, 50, 10}}, 58);
        b.path(INK, MID, p);
        b.fill(66, 46, SKY);
        b.dot(56, 44, INK, MID);
        b.dot(72, 44, INK, MID);
        b.arc(64, 48, 5, 4, 20, 160, INK, THIN);
        b.dot(50, 49, PINK, MID);
        b.dot(78, 49, PINK, MID);
        for (double x : new double[]{48, 64, 80}) b.line(x, 64, x - 3, 72, BLUE, MID);
    }

    private static void balloon(B b) {
        b.poly(INK, MID, 60, 56, 55, 63, 65, 63);
        b.fill(60, 60, PINK);
        b.ellipse(60, 32, 21, 25, INK, MID);
        b.fill(60, 32, PINK);
        b.arc(60, 32, 14, 18, 200, 260, PAPER, MID);
        b.path(INK, THIN, new double[]{60, 63, 56, 68, 64, 72, 58, 77});
    }

    private static void pumpkin(B b) {
        b.rect(57, 14, 64, 26, INK, MID);
        b.fill(60, 20, GREEN);
        b.ellipse(60, 48, 33, 24, INK, MID);
        b.fill(60, 48, ORANGE);
        b.ellipse(60, 48, 17, 24, BROWN, THIN);
        b.arc(60, 48, 26, 24, 110, 250, BROWN, THIN);
        b.arc(60, 48, 26, 24, -70, 70, BROWN, THIN);
        b.poly(INK, MID, 48, 42, 53, 36, 58, 42);
        b.fill(53, 40, INK);
        b.poly(INK, MID, 62, 42, 67, 36, 72, 42);
        b.fill(67, 40, INK);
        b.poly(INK, MID, 50, 54, 55, 58, 60, 54, 65, 58, 70, 54, 60, 62);
    }

    private static void cup(B b) {
        b.ellipse(60, 70, 34, 5, INK, MID);
        b.fill(60, 70, LAV);
        b.arc(88, 48, 11, 12, -90, 90, INK, MID);
        b.poly(INK, MID, 36, 30, 84, 30, 78, 66, 42, 66);
        b.fill(60, 50, PINK);
        b.ellipse(60, 30, 24, 5, INK, MID);
        b.fill(60, 30, BROWN);
        b.path(GREY, THIN, new double[]{50, 22, 54, 17, 50, 12, 54, 7});
        b.path(GREY, THIN, new double[]{66, 22, 70, 17, 66, 12, 70, 7});
        b.dot(60, 48, RED, MID);
    }

    private static void key(B b) {
        b.rect(50, 35, 106, 45, INK, MID);
        b.fill(78, 40, YELLOW);
        b.rect(90, 45, 96, 56, INK, MID);
        b.fill(93, 50, YELLOW);
        b.rect(100, 45, 106, 52, INK, MID);
        b.fill(103, 48, YELLOW);
        b.circle(34, 40, 18, INK, MID);
        b.fill(34, 26, YELLOW);
        b.circle(34, 40, 7, INK, MID);
        b.fill(34, 40, PAPER);
        b.dot(28, 30, PAPER, MID);
    }

    private static void crown(B b) {
        b.poly(INK, MID, 24, 62, 24, 26, 44, 46, 60, 18, 76, 46, 96, 26, 96, 62);
        b.fill(60, 54, YELLOW);
        b.line(24, 56, 96, 56, INK, MID);
        b.circle(24, 26, 4, INK, THIN);
        b.fill(24, 26, RED);
        b.circle(60, 18, 4, INK, THIN);
        b.fill(60, 18, RED);
        b.circle(96, 26, 4, INK, THIN);
        b.fill(96, 26, RED);
        b.dot(42, 59, SKY, FAT);
        b.dot(60, 59, PINK, FAT);
        b.dot(78, 59, SKY, FAT);
    }

    private static void rainbow(B b) {
        int[] cols = {RED, ORANGE, YELLOW, GREEN, SKY, PURPLE};
        for (int i = 0; i < cols.length; i++) b.arc(60, 62, 40 - i * 5, 40 - i * 5, 180, 360, cols[i], FAT);
        for (double x : new double[]{20, 100}) {
            b.circle(x, 66, 8, INK, MID);
            b.fill(x, 66, PAPER);
            b.circle(x + (x < 60 ? 9 : -9), 68, 7, INK, MID);
            b.fill(x + (x < 60 ? 11 : -11), 68, PAPER);
        }
    }
}
