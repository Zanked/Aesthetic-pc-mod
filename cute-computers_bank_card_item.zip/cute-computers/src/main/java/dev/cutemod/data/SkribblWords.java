package dev.cutemod.data;

import java.util.Locale;

/**
 * The words of Scribble Pals, every one in English and in Russian ("en|ru"). The server accepts a guess in either language;
 * every player sees the word in the language of his own game. The computer artists know how to draw some of them ({@link SkribblArt}).
 * A word travels as one text "english|russian" (an entry), so the words players type themselves work the same way.
 */
public final class SkribblWords {
    private SkribblWords() {}

    private static final String[] WORDS = {
            // the computer players can draw these (keep the order: SkribblArt uses the numbers)
            "sun|солнце", "moon|луна", "star|звезда", "heart|сердце", "flower|цветок", "tree|дерево", "house|дом", "cat|кот",
            "fish|рыба", "apple|яблоко", "cake|торт", "car|машина", "boat|лодка", "umbrella|зонт", "mushroom|гриб", "snowman|снеговик",
            "ghost|привидение", "bee|пчела", "panda|панда", "rabbit|кролик", "ice cream|мороженое", "cloud|облако", "balloon|шарик",
            "pumpkin|тыква", "cup|чашка", "key|ключ", "crown|корона", "rainbow|радуга",
            // only people draw these
            "dog|собака", "bird|птица", "bear|медведь", "penguin|пингвин", "owl|сова", "frog|лягушка", "pig|свинья", "cow|корова",
            "mouse|мышь", "spider|паук", "butterfly|бабочка", "snail|улитка", "turtle|черепаха", "dragon|дракон", "unicorn|единорог",
            "mermaid|русалка", "witch|ведьма", "vampire|вампир", "zombie|зомби", "creeper|крипер", "pickaxe|кирка", "sword|меч",
            "diamond|алмаз", "torch|факел", "bed|кровать", "chair|стул", "table|стол", "door|дверь", "window|окно", "lamp|лампа",
            "clock|часы", "book|книга", "pencil|карандаш", "scissors|ножницы", "glasses|очки", "hat|шляпа", "shoe|ботинок",
            "sock|носок", "scarf|шарф", "dress|платье", "bag|сумка", "phone|телефон", "computer|компьютер", "keyboard|клавиатура",
            "headphones|наушники", "guitar|гитара", "piano|пианино", "drum|барабан", "camera|камера", "pizza|пицца", "burger|бургер",
            "sushi|суши", "donut|пончик", "cookie|печенье", "candy|конфета", "banana|банан", "strawberry|клубника", "carrot|морковь",
            "bread|хлеб", "coffee|кофе", "tea|чай", "egg|яйцо", "plane|самолёт", "train|поезд", "bicycle|велосипед", "rocket|ракета",
            "lighthouse|маяк", "castle|замок", "bridge|мост", "mountain|гора", "volcano|вулкан", "island|остров", "campfire|костёр",
            "tent|палатка", "snowflake|снежинка", "lightning|молния", "tornado|торнадо", "planet|планета", "robot|робот",
            "ninja|ниндзя", "pirate|пират", "angel|ангел", "skeleton|скелет", "popcorn|попкорн", "bubble tea|бабл ти",
            "kitten|котёнок", "teddy bear|плюшевый мишка", "gift|подарок", "bell|колокольчик", "feather|перо", "wizard|волшебник",
            // Minecraft
            "enderman|эндермен", "cobblestone|булыжник", "villager|житель", "tnt|динамит", "furnace|печка", "crafting table|верстак",
            "chest|сундук", "axolotl|аксолотль", "sheep|овца", "wolf|волк", "nether portal|портал в незер", "bookshelf|книжная полка",
            // anime and kawaii
            "onigiri|онигири", "kimono|кимоно", "cherry blossom|сакура", "cat ears|кошачьи ушки", "ramen|рамен", "bento|бенто",
            "lucky cat|манэки-неко", "torii gate|тории", "folding fan|веер", "school uniform|школьная форма",
            // spooky
            "coffin|гроб", "bat|летучая мышь", "candle|свеча", "cauldron|котёл", "cobweb|паутина", "haunted house|дом с привидениями"};

    /** The word sets a room can play with: 0 everything, 7 the words the players typed themselves. */
    public static final int SET_ALL = 0, SET_ANIMALS = 1, SET_FOOD = 2, SET_MINECRAFT = 3, SET_ANIME = 4, SET_SPOOKY = 5, SET_THINGS = 6, SET_OWN = 7, SETS = 8;

    private static final String[][] SET_WORDS = {
            {},
            {"cat", "fish", "bee", "panda", "rabbit", "dog", "bird", "bear", "penguin", "owl", "frog", "pig", "cow", "mouse", "spider", "butterfly", "snail",
                    "turtle", "kitten", "axolotl", "sheep", "wolf", "bat", "dragon", "unicorn"},
            {"apple", "cake", "ice cream", "pizza", "burger", "sushi", "donut", "cookie", "candy", "banana", "strawberry", "carrot", "bread", "coffee", "tea",
                    "egg", "popcorn", "bubble tea", "onigiri", "ramen", "bento", "mushroom", "pumpkin"},
            {"creeper", "pickaxe", "sword", "diamond", "torch", "zombie", "skeleton", "bed", "door", "window", "mushroom", "pig", "cow", "sheep", "wolf",
                    "spider", "enderman", "cobblestone", "villager", "tnt", "furnace", "crafting table", "chest", "axolotl", "nether portal", "bookshelf", "tree",
                    "boat", "campfire", "lightning", "apple", "carrot", "bread", "cake", "cookie", "egg", "fish"},
            {"onigiri", "kimono", "cherry blossom", "cat ears", "ramen", "bento", "lucky cat", "torii gate", "folding fan", "school uniform", "sushi", "bubble tea",
                    "ninja", "mermaid", "unicorn", "dragon", "flower", "star", "cat", "rabbit", "donut", "ice cream", "heart", "rainbow", "kitten", "teddy bear"},
            {"ghost", "pumpkin", "vampire", "zombie", "witch", "skeleton", "moon", "bat", "spider", "coffin", "candle", "cauldron", "cobweb", "haunted house",
                    "creeper", "dragon", "wizard", "torch", "lightning", "owl", "cat"},
            {"house", "car", "boat", "umbrella", "key", "crown", "cup", "balloon", "clock", "book", "pencil", "scissors", "glasses", "hat", "shoe", "sock",
                    "scarf", "dress", "bag", "phone", "computer", "keyboard", "headphones", "guitar", "piano", "drum", "camera", "lamp", "chair", "table", "bed",
                    "door", "window", "plane", "train", "bicycle", "rocket", "lighthouse", "castle", "bridge", "tent", "gift", "bell", "feather", "robot", "bookshelf"}};

    private static final java.util.Map<String, Integer> SET_MASK = new java.util.HashMap<>();

    static {
        for (int set = 1; set <= 6; set++) for (String w : SET_WORDS[set]) SET_MASK.merge(w, 1 << set, (x, y) -> x | y);
    }

    /** True if the word number belongs to the word set (a built-in set; SET_ALL has everything). */
    public static boolean inSet(int word, int set) {
        if (set == SET_ALL) return true;
        if (set < 1 || set > 6) return false;
        return (SET_MASK.getOrDefault(en(word), 0) & (1 << set)) != 0;
    }

    /** The word as the game keeps it: "english|russian". */
    public static String entry(int i) { return WORDS[i]; }

    /** A word a player typed: the same text in both languages (no | and no ; in it). */
    public static String custom(String text) {
        StringBuilder b = new StringBuilder();
        for (char c : text.trim().toCharArray()) if (c >= 32 && c != '|' && c != ';' && c != 127) b.append(c);
        String t = b.toString().replaceAll("\\s+", " ").trim();
        if (t.length() > 20) t = t.substring(0, 20).trim();
        return t.length() < 2 ? "" : t + "|" + t;
    }

    public static int count() { return WORDS.length; }

    public static String en(int i) { return en(WORDS[i]); }

    public static String ru(int i) { return ru(WORDS[i]); }

    public static String en(String entry) { int c = entry.indexOf('|'); return c < 0 ? entry : entry.substring(0, c); }

    public static String ru(String entry) { return entry.substring(entry.indexOf('|') + 1); }

    /** The word in the given language code ("ru_ru", "en_us"...). */
    public static String word(String entry, String lang) {
        if (entry == null || entry.isEmpty()) return "";
        return lang != null && lang.toLowerCase(Locale.ROOT).startsWith("ru") ? ru(entry) : en(entry);
    }

    public static String word(int i, String lang) { return i < 0 || i >= WORDS.length ? "" : word(WORDS[i], lang); }

    /** The number of a built-in word (by its entry), or -1 for a word somebody typed. */
    public static int index(String entry) {
        for (int i = 0; i < WORDS.length; i++) if (WORDS[i].equals(entry)) return i;
        return -1;
    }

    /** Lower case, no spaces, ё = е: so that "Ice  Cream" and "icecream" are the same guess. */
    public static String norm(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toLowerCase(Locale.ROOT).toCharArray()) {
            if (c == 'ё') c = 'е';
            if (Character.isLetterOrDigit(c)) b.append(c);
        }
        return b.toString();
    }

    public static boolean matches(String entry, String guess) {
        String g = norm(guess);
        return !g.isEmpty() && (g.equals(norm(en(entry))) || g.equals(norm(ru(entry))));
    }

    /** One letter wrong, missing or extra, in a word of at least four letters: "so close!". */
    public static boolean close(String entry, String guess) {
        String g = norm(guess);
        if (g.length() < 4) return false;
        return dist(g, norm(en(entry))) == 1 || dist(g, norm(ru(entry))) == 1;
    }

    private static int dist(String a, String b) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++)
                cur[j] = Math.min(Math.min(cur[j - 1], prev[j]) + 1, prev[j - 1] + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1));
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }

    /**
     * What the guessers see: one "_" for every letter (spaces stay as gaps) and the letters that were given as hints.
     * {@code reveal} letters are shown, in the order of a shuffle that depends on the seed (all players see the same ones).
     */
    public static String hint(String word, int reveal, long seed) {
        String p = pattern(word, reveal, seed);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < p.length(); i++) b.append(p.charAt(i) == ' ' ? "  " : p.charAt(i) + " ");
        return b.toString().trim();
    }

    /** The same as {@link #hint}, one character for every character of the word: "_", a revealed letter in capitals, or a space. */
    public static String pattern(String word, int reveal, long seed) {
        int n = word.length();
        int[] order = new int[n];
        int k = 0;
        for (int i = 0; i < n; i++) if (Character.isLetterOrDigit(word.charAt(i))) order[k++] = i;
        java.util.Random r = new java.util.Random(seed);
        for (int i = k - 1; i > 0; i--) { int j = r.nextInt(i + 1); int t = order[i]; order[i] = order[j]; order[j] = t; }
        boolean[] shown = new boolean[n];
        for (int i = 0; i < Math.min(reveal, Math.max(0, k - 2)); i++) shown[order[i]] = true;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < n; i++) {
            char c = word.charAt(i);
            b.append(!Character.isLetterOrDigit(c) ? ' ' : shown[i] ? Character.toUpperCase(c) : '_');
        }
        return b.toString();
    }

    /** True if the word could be the one behind the pattern (same length, same letters where they are shown). */
    public static boolean fits(String word, String pattern) {
        if (word.length() != pattern.length()) return false;
        for (int i = 0; i < pattern.length(); i++) {
            char pc = pattern.charAt(i), wc = word.charAt(i);
            if (pc == '_') { if (!Character.isLetterOrDigit(wc)) return false; }
            else if (pc == ' ') { if (Character.isLetterOrDigit(wc)) return false; }
            else if (Character.toUpperCase(wc) != pc) return false;
        }
        return true;
    }
}
