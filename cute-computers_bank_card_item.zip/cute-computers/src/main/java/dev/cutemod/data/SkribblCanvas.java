package dev.cutemod.data;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * The drawing board of Scribble Pals: a small grid of palette colours and the list of operations that made it.
 * Plain Java (no Minecraft), so the server, the clients and the bot artists all rebuild exactly the same picture from the
 * same list of operations.
 * <p>
 * An operation is one text line of numbers: {@code stroke,tool,colour,size,x1,y1,x2,y2,...}. A stroke is one drag of the mouse
 * (a free line may arrive as several operations with the same stroke number: the clients send a chunk every few ticks, so the others
 * see the line grow). Tools: 0 pen, 1 eraser (the pen in paper colour), 2 fill (one point), 3 line, 4 / 5 rectangle (outline / filled),
 * 6 / 7 oval (outline / filled) (these five take two points: the corners), 8 to 15 stamps (one point, the stamp number is tool - 8,
 * the two thick sizes make it twice as big). Undo removes every operation of the last stroke.
 */
public final class SkribblCanvas {
    public static final int CW = 120, CH = 80;
    public static final int PEN = 0, ERASER = 1, FILL = 2, LINE = 3, RECT = 4, RECTF = 5, OVAL = 6, OVALF = 7, STAMP = 8;
    public static final int MAX_POINTS = 24;
    public static final int[] SIZES = {1, 2, 3, 5};
    /** The 16 main colours of the palette; the other 48 (12 hues in four tones) come after them. */
    public static final int BASE = 16, HUES = 12, TONES = 4;
    public static final int[] PALETTE = new int[BASE + HUES * TONES];

    static {
        int[] base = {0xFFFFFDF8, 0xFF3A3347, 0xFF8E8A99, 0xFFE8566B, 0xFFF59B5B, 0xFFF7D860, 0xFF8FD17A, 0xFF3FA88A,
                0xFF6EC3F2, 0xFF4A78E0, 0xFF9B7BE0, 0xFFF4A0C8, 0xFFB66A4B, 0xFFE8C9A0, 0xFFBFEFD6, 0xFFC9B8F5};
        System.arraycopy(base, 0, PALETTE, 0, BASE);
        double[][] tone = {{0.38, 1.0}, {0.78, 0.98}, {0.8, 0.74}, {0.85, 0.44}};
        for (int t = 0; t < TONES; t++)
            for (int h = 0; h < HUES; h++) PALETTE[BASE + t * HUES + h] = hsv(h * 30.0, tone[t][0], tone[t][1]);
    }

    private static int hsv(double h, double s, double v) {
        double c = v * s, x = c * (1 - Math.abs((h / 60.0) % 2 - 1)), m = v - c, r, g, b;
        int sector = (int) (h / 60.0) % 6;
        switch (sector) {
            case 0 -> { r = c; g = x; b = 0; }
            case 1 -> { r = x; g = c; b = 0; }
            case 2 -> { r = 0; g = c; b = x; }
            case 3 -> { r = 0; g = x; b = c; }
            case 4 -> { r = x; g = 0; b = c; }
            default -> { r = c; g = 0; b = x; }
        }
        return 0xFF000000 | (int) Math.round((r + m) * 255) << 16 | (int) Math.round((g + m) * 255) << 8 | (int) Math.round((b + m) * 255);
    }

    public final byte[] px = new byte[CW * CH];
    private final List<String> ops = new ArrayList<>();

    public List<String> ops() { return ops; }

    public int count() { return ops.size(); }

    public void clear() {
        ops.clear();
        java.util.Arrays.fill(px, (byte) 0);
    }

    /** Copy only the colours of another board (no operations): for a preview that is drawn over and thrown away. */
    public void copyPixels(SkribblCanvas o) {
        System.arraycopy(o.px, 0, px, 0, px.length);
    }

    /** Add one operation and draw it. False if the text is not a good operation (it is dropped). */
    public boolean add(String op) {
        int[] v = parse(op);
        if (v == null) return false;
        ops.add(op);
        apply(v);
        return true;
    }

    /** Draw an operation without keeping it (the preview of a shape that is still being dragged). */
    public boolean preview(String op) {
        int[] v = parse(op);
        if (v == null) return false;
        apply(v);
        return true;
    }

    /** Remove every operation of the last stroke and draw the rest again. False if there was nothing to undo. */
    public boolean undo() {
        if (ops.isEmpty()) return false;
        int last = strokeOf(ops.get(ops.size() - 1));
        while (!ops.isEmpty() && strokeOf(ops.get(ops.size() - 1)) == last) ops.remove(ops.size() - 1);
        rebuild();
        return true;
    }

    public void rebuild() {
        java.util.Arrays.fill(px, (byte) 0);
        for (String o : ops) { int[] v = parse(o); if (v != null) apply(v); }
    }

    public void setOps(List<String> list) {
        ops.clear();
        java.util.Arrays.fill(px, (byte) 0);
        for (String o : list) add(o);
    }

    public static int strokeOf(String op) {
        int c = op.indexOf(',');
        try { return Integer.parseInt(c < 0 ? op : op.substring(0, c)); } catch (NumberFormatException e) { return -1; }
    }

    /** The numbers of an operation, or null if it is not valid. */
    public static int[] parse(String op) {
        if (op == null || op.length() > 400) return null;
        String[] s = op.split(",");
        if (s.length < 6 || s.length > 4 + MAX_POINTS * 2 || (s.length & 1) != 0) return null;
        int[] v = new int[s.length];
        try { for (int i = 0; i < s.length; i++) v[i] = Integer.parseInt(s[i].trim()); } catch (NumberFormatException e) { return null; }
        int tool = v[1];
        if (tool < 0 || tool >= STAMP + SkribblStamps.COUNT || v[2] < 0 || v[2] >= PALETTE.length || v[3] < 0 || v[3] >= SIZES.length) return null;
        if ((tool == FILL || tool >= STAMP) && v.length != 6) return null;
        if (tool >= LINE && tool <= OVALF && v.length != 8) return null;
        for (int i = 4; i < v.length; i += 2) if (v[i] < 0 || v[i] >= CW || v[i + 1] < 0 || v[i + 1] >= CH) return null;
        return v;
    }

    private void apply(int[] v) {
        int tool = v[1], col = tool == ERASER ? 0 : v[2];
        int r = SIZES[v[3]] - 1;
        if (tool == FILL) { fill(v[4], v[5], (byte) col); return; }
        if (tool >= STAMP) { stampShape(tool - STAMP, v[4], v[5], v[3] >= 2 ? 2 : 1, (byte) col); return; }
        if (tool == LINE) { line(v[4], v[5], v[6], v[7], r, (byte) col); return; }
        if (tool >= RECT) { shape(tool, v[4], v[5], v[6], v[7], r, (byte) col); return; }
        int x = v[4], y = v[5];
        stamp(x, y, r, (byte) col);
        for (int i = 6; i < v.length; i += 2) {
            line(x, y, v[i], v[i + 1], r, (byte) col);
            x = v[i];
            y = v[i + 1];
        }
    }

    private void shape(int tool, int xa, int ya, int xb, int yb, int r, byte c) {
        int x0 = Math.min(xa, xb), x1 = Math.max(xa, xb), y0 = Math.min(ya, yb), y1 = Math.max(ya, yb);
        boolean filled = tool == RECTF || tool == OVALF;
        if (tool == RECT || tool == RECTF) {
            if (filled) { for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) put(x, y, c); return; }
            line(x0, y0, x1, y0, r, c); line(x1, y0, x1, y1, r, c); line(x1, y1, x0, y1, r, c); line(x0, y1, x0, y0, r, c);
            return;
        }
        double cx = (x0 + x1) / 2.0, cy = (y0 + y1) / 2.0, rx = (x1 - x0) / 2.0, ry = (y1 - y0) / 2.0;
        if (filled) {
            for (int y = y0; y <= y1; y++) {
                double t = ry < 0.5 ? 0 : (y - cy) / ry;
                double w = rx * Math.sqrt(Math.max(0, 1 - t * t));
                for (int x = (int) Math.round(cx - w); x <= (int) Math.round(cx + w); x++) put(x, y, c);
            }
            return;
        }
        int steps = Math.max(12, (int) (Math.max(rx, ry) * 8));
        int px0 = (int) Math.round(cx + rx), py0 = (int) Math.round(cy);
        for (int i = 1; i <= steps; i++) {
            double a = Math.PI * 2 * i / steps;
            int nx = (int) Math.round(cx + Math.cos(a) * rx), ny = (int) Math.round(cy + Math.sin(a) * ry);
            line(px0, py0, nx, ny, r, c);
            px0 = nx;
            py0 = ny;
        }
    }

    private void stampShape(int shape, int cx, int cy, int scale, byte c) {
        for (int y = 0; y < 9; y++)
            for (int x = 0; x < 9; x++)
                if (SkribblStamps.on(shape, x, y))
                    for (int dy = 0; dy < scale; dy++)
                        for (int dx = 0; dx < scale; dx++) put(cx + (x - 4) * scale + dx - (scale - 1) / 2, cy + (y - 4) * scale + dy - (scale - 1) / 2, c);
    }

    private void line(int x0, int y0, int x1, int y1, int r, byte c) {
        int dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx - dy;
        while (true) {
            stamp(x0, y0, r, c);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 < dx) { err += dx; y0 += sy; }
        }
    }

    private void stamp(int cx, int cy, int r, byte c) {
        if (r == 0) { put(cx, cy, c); return; }
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.floor(Math.sqrt((r + 0.5) * (r + 0.5) - dy * dy));
            for (int dx = -w; dx <= w; dx++) put(cx + dx, cy + dy, c);
        }
    }

    private void put(int x, int y, byte c) {
        if (x >= 0 && y >= 0 && x < CW && y < CH) px[y * CW + x] = c;
    }

    private void fill(int sx, int sy, byte c) {
        byte from = px[sy * CW + sx];
        if (from == c) return;
        ArrayDeque<int[]> q = new ArrayDeque<>();
        q.add(new int[]{sx, sy});
        while (!q.isEmpty()) {
            int[] p = q.poll();
            int x = p[0], y = p[1];
            if (x < 0 || y < 0 || x >= CW || y >= CH || px[y * CW + x] != from) continue;
            px[y * CW + x] = c;
            q.add(new int[]{x + 1, y}); q.add(new int[]{x - 1, y}); q.add(new int[]{x, y + 1}); q.add(new int[]{x, y - 1});
        }
    }

    // ------------------------------------------------------------------ packing

    /** All operations in one line (separated by ;). */
    public String pack() { return String.join(";", ops); }

    public static List<String> unpack(String s) {
        List<String> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        for (String o : s.split(";")) if (parse(o) != null) out.add(o);
        return out;
    }

    /** True once something has been drawn (an empty board is not worth keeping). */
    public boolean hasInk() {
        for (byte b : px) if (b != 0) return true;
        return false;
    }

    /** The colours of a board as a few hundred bytes (zipped), for sending a finished picture or keeping it. */
    public static byte[] zip(byte[] px) {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (GZIPOutputStream z = new GZIPOutputStream(bo)) { z.write(px); }
            return bo.toByteArray();
        } catch (Exception e) {
            return new byte[0];
        }
    }

    /** The other way round: a board of CW x CH colours, or null if the bytes are not a picture. */
    public static byte[] unzip(byte[] zipped) {
        try (GZIPInputStream z = new GZIPInputStream(new ByteArrayInputStream(zipped))) {
            byte[] raw = z.readNBytes(CW * CH + 1);
            if (raw.length != CW * CH) return null;
            for (int i = 0; i < raw.length; i++) if (raw[i] < 0 || raw[i] >= PALETTE.length) raw[i] = 0;
            return raw;
        } catch (Exception e) {
            return null;
        }
    }
}
