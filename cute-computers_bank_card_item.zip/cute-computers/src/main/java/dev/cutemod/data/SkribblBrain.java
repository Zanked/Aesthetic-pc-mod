package dev.cutemod.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * The eyes of the computer players: they look at a picture and say which of some words it most likely is. A picture is turned into a short
 * list of numbers (how much of each colour it has, and where the ink is), the pictures the computer artists know are turned into the same
 * kind of list, and the word whose picture is the most alike wins (a little noise makes weak players wrong more often). A word the computer
 * cannot draw has no picture to compare with: it is only a guess, and it becomes the answer by elimination once the hints leave nothing else.
 */
public final class SkribblBrain {
    private SkribblBrain() {}

    private static final int COLOURS = SkribblCanvas.PALETTE.length, GRID_W = 6, GRID_H = 4, LEN = COLOURS + GRID_W * GRID_H;
    private static final Map<String, double[]> ART = new HashMap<>();
    private static final Map<String, Integer> ART_INK = new HashMap<>();

    /** A guess: the word and how sure the player is (0..1). */
    public static final class Pick {
        public final String entry;
        public final double score;

        Pick(String entry, double score) { this.entry = entry; this.score = score; }
    }

    /** The numbers that describe a picture: colour shares, then how much of each 20 x 20 square is covered. */
    static double[] feature(byte[] px) {
        double[] f = new double[LEN];
        int[] cnt = new int[COLOURS], cell = new int[GRID_W * GRID_H];
        int ink = 0;
        for (int y = 0; y < SkribblCanvas.CH; y++)
            for (int x = 0; x < SkribblCanvas.CW; x++) {
                int c = px[y * SkribblCanvas.CW + x];
                if (c == 0) continue;
                cnt[c]++;
                cell[(y / 20) * GRID_W + x / 20]++;
                ink++;
            }
        if (ink == 0) return f;
        for (int i = 0; i < COLOURS; i++) f[i] = cnt[i] / (double) ink;
        for (int i = 0; i < cell.length; i++) f[COLOURS + i] = Math.min(1.0, cell[i] / 400.0);
        return f;
    }

    private static int inkOf(byte[] px) {
        int n = 0;
        for (byte b : px) if (b != 0) n++;
        return n;
    }

    private static double cosine(double[] a, double[] b) {
        double dot = 0, na = 0, nb = 0;
        for (int i = 0; i < a.length; i++) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; }
        return na == 0 || nb == 0 ? 0 : dot / Math.sqrt(na * nb);
    }

    private static synchronized double[] artFeature(String entry) {
        double[] f = ART.get(entry);
        if (f == null) {
            SkribblCanvas c = new SkribblCanvas();
            for (String o : SkribblArt.draw(entry)) c.add(o);
            f = feature(c.px);
            ART.put(entry, f);
            ART_INK.put(entry, inkOf(c.px));
        }
        return f;
    }

    /** How much a picture looks like the picture the computer artists draw for the word: 0 (not at all) .. 1 (the same); -1 if there is no such picture. */
    public static double similarity(byte[] px, String entry) {
        if (!SkribblArt.can(entry)) return -1;
        double[] a = artFeature(entry);
        double s = cosine(feature(px), a);
        int ink = inkOf(px), full = ART_INK.get(entry);
        double done = Math.min(1.0, ink / (0.75 * Math.max(1, full)));        // a picture that is hardly started cannot be sure
        return s * (0.35 + 0.65 * done);
    }

    /**
     * The player's best guess among the words, for the picture. {@code noise} is how much the player's eyes wander (0.1 sharp, 0.4 careless).
     * Words without a picture of their own are worth a middle score, so that they are guessed too, but not before the ones that look right.
     */
    public static Pick guess(byte[] px, List<String> words, double noise, Random rnd) {
        String best = null;
        double bestScore = -1e9, bestRaw = 0;
        for (String w : words) {
            double s = similarity(px, w), raw = s < 0 ? 0.28 : s;
            double v = raw + rnd.nextGaussian() * noise * 0.5;
            if (v > bestScore) { bestScore = v; best = w; bestRaw = raw; }
        }
        return best == null ? null : new Pick(best, bestRaw);
    }
}
