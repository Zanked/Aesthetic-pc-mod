package dev.cutemod.client.os;

import dev.cutemod.net.NetPingPayload;
import dev.cutemod.net.NetRequestPayload;
import dev.cutemod.net.NetScorePayload;
import dev.cutemod.net.NetSyncPayload;
import net.neoforged.neoforge.network.PacketDistributor;

/** CuteNet on the client: sends scores and "I am here" pings, keeps the last answer of the server. */
public final class Net {
    private Net() {}

    private static NetSyncPayload last;

    public static void apply(NetSyncPayload p) { last = p; }

    /** The last answer (null before the first one). */
    public static NetSyncPayload last() { return last; }

    public static void request(String game) { dev.cutemod.client.os.Modem.sendQuiet(new NetRequestPayload(game == null ? "" : game)); }

    public static void submit(String game, int score) {
        if (score > 0 && game != null && !game.isEmpty()) dev.cutemod.client.os.Modem.sendQuiet(new NetScorePayload(game, score));
    }

    public static void ping(boolean open, int app, String game) {
        dev.cutemod.client.os.Modem.sendQuiet(new NetPingPayload(open, app, game == null ? "" : game));
    }

    public static void clear() { last = null; }
}
