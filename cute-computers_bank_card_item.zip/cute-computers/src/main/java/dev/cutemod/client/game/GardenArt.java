package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.game.GardenMaps.*;

/**
 * The pixel art of {@link GardenGuard}: the eight guards (cat, penguin, fox, panda, bee, frog, owl, hedgehog),
 * the eight kinds of pests, the shots and the scenery. Everything is built from plain fills.
 */
final class GardenArt {
    private GardenArt() {}

    static final int INK = 0xFF2A2433;

    static void px(GuiGraphics g, int x, int y, int col) { g.fill(x, y, x + 1, y + 1, col); }

    static void rect(GuiGraphics g, int x, int y, int w, int h, int col) { g.fill(x, y, x + w, y + h, col); }

    static void coin(GuiGraphics g, int cx, int cy) {
        Gfx.disc(g, cx, cy, 3, 0xFFB8860B);
        Gfx.disc(g, cx, cy, 2, 0xFFFFD84A);
        px(g, cx - 1, cy - 1, 0xFFFFF6B0);
        px(g, cx + 1, cy + 1, 0xFFE0A81A);
    }

    // =====================================================================================================
    // guards: 0 cat, 1 penguin, 2 fox, 3 panda, 4 bee, 5 frog, 6 owl, 7 hedgehog
    // =====================================================================================================
    static void tower(GuiGraphics g, int type, int cx, int cy, int level, int look, boolean firing, int ph, int t, boolean shadow) {
        if (shadow) Gfx.ellipse(g, cx, cy + 5, 6, 2, 0x30000000);
        Gfx.ellipse(g, cx, cy + 5, 5, 2, 0xFFD6D0C2);                     // a little stone plate
        Gfx.ellipse(g, cx, cy + 5, 4, 1, 0xFFEFEAE0);
        if (level >= 3) Gfx.glow(g, cx, cy, 8, 0xFFFFE27A, 60 + (int) (Math.sin(t * 0.12) * 20));
        int b = firing ? 1 : (((t / 22) + ph) & 1) == 0 ? 0 : -1;        // breathing, and a little hop when shooting
        boolean blink = (t + ph * 13) % 170 < 5;
        switch (type) {
            case 0 -> cat(g, cx, cy, b, look, firing, blink, t);
            case 1 -> penguin(g, cx, cy, b, look, firing, blink);
            case 2 -> fox(g, cx, cy, b, look, firing, blink, t);
            case 3 -> panda(g, cx, cy, b, look, firing, blink);
            case 4 -> bee(g, cx, cy, look, firing, blink, ph, t);
            case 5 -> frog(g, cx, cy, b, look, firing, blink);
            case 6 -> owl(g, cx, cy, b, look, firing, blink);
            default -> hedgehog(g, cx, cy, look, firing, blink);
        }
        if (level >= 2) Gfx.star(g, cx + 5, cy - 6, 1, 0xFFFFE27A);
        if (level >= 3) Gfx.star(g, cx - 5, cy - 6, 1, 0xFFFFE27A);
    }

    private static void eyes(GuiGraphics g, int x1, int x2, int y, int look, boolean blink) {
        if (blink) { rect(g, x1 + look, y + 1, 1, 1, INK); rect(g, x2 + look, y + 1, 1, 1, INK); }
        else {
            rect(g, x1 + look, y, 1, 2, INK); rect(g, x2 + look, y, 1, 2, INK);
            px(g, x1 + look, y, 0xFF6A5A80); px(g, x2 + look, y, 0xFF6A5A80);
        }
    }

    private static void cat(GuiGraphics g, int cx, int cy, int b, int look, boolean fire, boolean blink, int t) {
        int d = 0xFF9C5A26, f = 0xFFF4A84E, l = 0xFFFFE3B8, pk = 0xFFFF9DB5;
        int tx = look < 0 ? cx + 4 : cx - 5, wag = ((t / 8) & 1) == 0 ? 0 : (look < 0 ? 1 : -1);
        rect(g, tx, cy + 2, 2, 3, d); px(g, tx + (look < 0 ? 0 : 1), cy + 2, f); px(g, tx + wag, cy + 1, f);
        Gfx.ellipse(g, cx, cy + 3, 4, 3, d);
        Gfx.ellipse(g, cx, cy + 3, 3, 2, f);
        px(g, cx, cy + 4, l); px(g, cx - 2, cy + 5, l); px(g, cx + 2, cy + 5, l);
        px(g, cx - 3, cy - 6 + b, d); rect(g, cx - 4, cy - 5 + b, 3, 1, d);                      // ears
        px(g, cx + 3, cy - 6 + b, d); rect(g, cx + 2, cy - 5 + b, 3, 1, d);
        Gfx.disc(g, cx, cy - 1 + b, 4, d);
        Gfx.disc(g, cx, cy - 1 + b, 3, f);
        px(g, cx - 3, cy - 5 + b, pk); px(g, cx + 3, cy - 5 + b, pk);
        px(g, cx - 1, cy - 4 + b, d); px(g, cx + 1, cy - 4 + b, d); px(g, cx, cy - 3 + b, d);    // tabby stripes
        eyes(g, cx - 2, cx + 1, cy - 2 + b, look, blink);
        px(g, cx - 3, cy + b, Gfx.alpha(pk, 190)); px(g, cx + 2, cy + b, Gfx.alpha(pk, 190));
        px(g, cx, cy + b, pk);
        if (fire) rect(g, cx - 1, cy + 1 + b, 2, 1, 0xFFE05A6A); else { px(g, cx - 1, cy + 1 + b, d); px(g, cx + 1, cy + 1 + b, d); }
        rect(g, cx - 2, cy + 2 + b, 5, 1, 0xFFE0485A); px(g, cx, cy + 3 + b, 0xFFFFD84A);       // ribbon and bell
    }

    private static void penguin(GuiGraphics g, int cx, int cy, int b, int look, boolean fire, boolean blink) {
        int navy = 0xFF34496E, deep = 0xFF263552;
        Gfx.ellipse(g, cx, cy + 2, 4, 4, deep);
        Gfx.ellipse(g, cx, cy + 2, 3, 4, navy);
        Gfx.ellipse(g, cx, cy + 3, 2, 3, 0xFFFFFFFF);
        rect(g, cx - 5, cy + (fire ? -1 : 1), 2, 3, navy); rect(g, cx + 4, cy + (fire ? -1 : 1), 2, 3, navy);   // flippers
        rect(g, cx - 3, cy + 5, 2, 1, 0xFFFFA030); rect(g, cx + 1, cy + 5, 2, 1, 0xFFFFA030);                    // feet
        Gfx.disc(g, cx, cy - 3 + b, 4, deep);
        Gfx.disc(g, cx, cy - 3 + b, 3, navy);
        rect(g, cx - 2, cy - 4 + b, 2, 2, 0xFFFFFFFF); rect(g, cx + 1, cy - 4 + b, 2, 2, 0xFFFFFFFF);            // eye patches
        px(g, cx - 2 + look, cy - 3 + b, INK); px(g, cx + 1 + look, cy - 3 + b, INK);
        if (!blink) { px(g, cx - 2 + look, cy - 4 + b, 0xFF8A7AA8); px(g, cx + 1 + look, cy - 4 + b, 0xFF8A7AA8); }
        rect(g, cx - 1, cy - 2 + b, 2, 1, 0xFFFFA030); if (fire) px(g, cx, cy - 1 + b, 0xFFE07A10);
        rect(g, cx - 3, cy + b, 6, 1, 0xFFE0485A); rect(g, cx + 2, cy + 1 + b, 1, 2, 0xFFE0485A);                // scarf
        px(g, cx - 3, cy - 6 + b, 0xFFFFFFFF); px(g, cx - 2, cy - 7 + b, 0xFFFFFFFF);                           // a bit of snow
    }

    private static void fox(GuiGraphics g, int cx, int cy, int b, int look, boolean fire, boolean blink, int t) {
        int o = 0xFFE8742C, d = 0xFFA84A14, w = 0xFFFFF4E4;
        int tx = look < 0 ? cx + 3 : cx - 7, sway = ((t / 10) & 1);
        Gfx.ellipse(g, tx + 2, cy + 2 - sway, 3, 3, d);
        Gfx.ellipse(g, tx + 2, cy + 2 - sway, 2, 2, o);
        px(g, tx + (look < 0 ? 4 : 0), cy + 3 - sway, w); px(g, tx + (look < 0 ? 4 : 0), cy + 2 - sway, w);   // white tip
        Gfx.ellipse(g, cx, cy + 3, 4, 3, d);
        Gfx.ellipse(g, cx, cy + 3, 3, 2, o);
        rect(g, cx - 1, cy + 4, 3, 1, w);
        px(g, cx - 2, cy + 5, INK); px(g, cx + 2, cy + 5, INK);                                                  // socks
        rect(g, cx - 4, cy - 7 + b, 1, 3, d); px(g, cx - 3, cy - 6 + b, o); rect(g, cx - 3, cy - 5 + b, 2, 2, d);   // tall ears
        rect(g, cx + 4, cy - 7 + b, 1, 3, d); px(g, cx + 3, cy - 6 + b, o); rect(g, cx + 2, cy - 5 + b, 2, 2, d);
        px(g, cx - 4, cy - 7 + b, INK); px(g, cx + 4, cy - 7 + b, INK);
        Gfx.disc(g, cx, cy - 1 + b, 4, d);
        Gfx.disc(g, cx, cy - 1 + b, 3, 0xFFF08A3C);
        rect(g, cx - 3, cy + b, 2, 1, w); rect(g, cx + 2, cy + b, 2, 1, w); rect(g, cx - 1, cy + b, 3, 2, w);     // cheeks and muzzle
        eyes(g, cx - 2, cx + 1, cy - 2 + b, look, blink);
        px(g, cx, cy + 1 + b, INK);
        if (fire) px(g, cx, cy + 2 + b, 0xFFE05A6A);
        rect(g, cx - 3, cy + 2 + b, 7, 1, 0xFF4FA05A); px(g, cx, cy + 3 + b, 0xFF4FA05A);                         // a leaf bandana
    }

    private static void panda(GuiGraphics g, int cx, int cy, int b, int look, boolean fire, boolean blink) {
        int bl = 0xFF2A2433, gr = 0xFFB8B8C4;
        Gfx.disc(g, cx, cy + 2, 4, gr);
        Gfx.disc(g, cx, cy + 2, 3, 0xFFFFFFFF);
        rect(g, cx - 5, cy + 1, 2, 3, bl); rect(g, cx + 4, cy + (fire ? -1 : 1), 2, 3, bl);                       // arms
        rect(g, cx - 3, cy + 5, 2, 1, bl); rect(g, cx + 1, cy + 5, 2, 1, bl);                                     // feet
        int bx = look < 0 ? cx - 6 : cx + 6;
        rect(g, bx, cy - 4, 1, 8, 0xFF6CC04A); px(g, bx, cy - 1, 0xFF3F8F3A); px(g, bx, cy + 2, 0xFF3F8F3A);      // bamboo
        px(g, bx + (look < 0 ? -1 : 1), cy - 3, 0xFF9BE07A);
        Gfx.disc(g, cx - 3, cy - 5 + b, 1, bl); Gfx.disc(g, cx + 3, cy - 5 + b, 1, bl);                           // ears
        Gfx.disc(g, cx, cy - 2 + b, 4, gr);
        Gfx.disc(g, cx, cy - 2 + b, 3, 0xFFFFFFFF);
        rect(g, cx - 3, cy - 3 + b, 2, 2, bl); rect(g, cx + 2, cy - 3 + b, 2, 2, bl);                             // eye patches
        if (!blink) { px(g, cx - 2 + look, cy - 3 + b, 0xFFFFFFFF); px(g, cx + 2 + look, cy - 3 + b, 0xFFFFFFFF); }
        px(g, cx, cy - 1 + b, bl);
        if (fire) rect(g, cx - 1, cy + b, 2, 1, 0xFFE05A6A); else px(g, cx, cy + b, 0xFF6A5A70);
        px(g, cx - 3, cy - 1 + b, 0x90FF9DB5); px(g, cx + 3, cy - 1 + b, 0x90FF9DB5);
        rect(g, cx - 3, cy - 6 + b, 2, 1, 0xFFFF6B8A); rect(g, cx + 2, cy - 6 + b, 2, 1, 0xFFFF6B8A); px(g, cx, cy - 6 + b, 0xFFFF9DB5);   // a bow
    }

    /** The honey bee hovers over its honey jar and pays out coins. */
    private static void bee(GuiGraphics g, int cx, int cy, int look, boolean fire, boolean blink, int ph, int t) {
        int d = 0xFF8A5A10, y = 0xFFFFD84A;
        int b = (int) Math.round(Math.sin(t * 0.15 + ph) * 1.2) - (fire ? 1 : 0);
        rect(g, cx - 6, cy + 2, 3, 3, 0xFFE8A020); rect(g, cx - 6, cy + 1, 3, 1, 0xFF8A5A30); px(g, cx - 5, cy + 2, 0xFFFFE08A);   // the honey jar
        int wf = ((t / 2) & 1) == 0 ? -1 : 0;
        Gfx.ellipse(g, cx - 3, cy - 4 + b + wf, 2, 1, 0xD0E8F4FF); Gfx.ellipse(g, cx + 3, cy - 4 + b - wf, 2, 1, 0xD0E8F4FF);   // buzzing wings
        Gfx.ellipse(g, cx, cy + 2 + b, 4, 3, d);
        Gfx.ellipse(g, cx, cy + 2 + b, 3, 2, y);
        rect(g, cx - 1, cy + 1 + b, 1, 3, INK); rect(g, cx + 1, cy + 1 + b, 1, 3, INK);
        px(g, cx + (look <= 0 ? 4 : -4), cy + 3 + b, INK);                                                       // stinger
        Gfx.disc(g, cx, cy - 1 + b, 4, d);
        Gfx.disc(g, cx, cy - 1 + b, 3, y);
        eyes(g, cx - 2, cx + 1, cy - 2 + b, look, blink);
        px(g, cx - 3, cy + b, 0x90FF9DB5); px(g, cx + 2, cy + b, 0x90FF9DB5);
        if (fire) rect(g, cx - 1, cy + 1 + b, 2, 1, 0xFFE05A6A); else { px(g, cx - 1, cy + 1 + b, d); px(g, cx, cy + 1 + b, d); }
        px(g, cx - 2, cy - 5 + b, INK); px(g, cx - 3, cy - 6 + b, INK); px(g, cx - 3, cy - 7 + b, y);              // antennae
        px(g, cx + 2, cy - 5 + b, INK); px(g, cx + 3, cy - 6 + b, INK); px(g, cx + 3, cy - 7 + b, y);
    }

    private static void frog(GuiGraphics g, int cx, int cy, int b, int look, boolean fire, boolean blink) {
        int d = 0xFF2E7A3A, f = 0xFF5CC85A, l = 0xFFC8F0A0;
        Gfx.ellipse(g, cx - 4, cy + 4, 2, 2, d); Gfx.ellipse(g, cx + 4, cy + 4, 2, 2, d);                           // back legs
        Gfx.ellipse(g, cx - 4, cy + 4, 1, 1, f); Gfx.ellipse(g, cx + 4, cy + 4, 1, 1, f);
        Gfx.ellipse(g, cx, cy + 3, 4, 3, d);
        Gfx.ellipse(g, cx, cy + 3, 3, 2, f);
        Gfx.ellipse(g, cx, cy + 4, 2, 1, l);
        px(g, cx - 2, cy + 2, d); px(g, cx + 2, cy + 3, d);                                                        // spots
        rect(g, cx - 3, cy + 5, 2, 1, l); rect(g, cx + 2, cy + 5, 2, 1, l);
        Gfx.ellipse(g, cx, cy - 1 + b, 5, 3, d);                                                                   // the wide head
        Gfx.ellipse(g, cx, cy - 1 + b, 4, 2, f);
        Gfx.disc(g, cx - 3, cy - 4 + b, 2, d); Gfx.disc(g, cx + 3, cy - 4 + b, 2, d);                              // bulging eyes
        rect(g, cx - 4, cy - 5 + b, 3, 3, 0xFFFFFFFF); rect(g, cx + 2, cy - 5 + b, 3, 3, 0xFFFFFFFF);
        if (blink) { rect(g, cx - 4, cy - 4 + b, 3, 1, d); rect(g, cx + 2, cy - 4 + b, 3, 1, d); }
        else { rect(g, cx - 3 + look, cy - 4 + b, 1, 2, INK); rect(g, cx + 3 + look, cy - 4 + b, 1, 2, INK); }
        if (fire) rect(g, cx - 2, cy + b, 5, 2, 0xFFE05A6A); else rect(g, cx - 3, cy + b, 7, 1, d);                // the mouth
        px(g, cx - 4, cy - 1 + b, 0x90FF9DB5); px(g, cx + 4, cy - 1 + b, 0x90FF9DB5);
    }

    private static void owl(GuiGraphics g, int cx, int cy, int b, int look, boolean fire, boolean blink) {
        int d = 0xFF6A4220, f = 0xFFB07A48, l = 0xFFF0DCB8, gold = 0xFFE8B030;
        int wy = fire ? -1 : 1;
        rect(g, cx - 5, cy + wy, 2, 4, d); rect(g, cx + 4, cy + wy, 2, 4, d);                                      // wings
        Gfx.ellipse(g, cx, cy + 2, 4, 4, d);
        Gfx.ellipse(g, cx, cy + 2, 3, 3, f);
        Gfx.ellipse(g, cx, cy + 3, 2, 2, l);
        px(g, cx - 1, cy + 3, f); px(g, cx + 1, cy + 4, f); px(g, cx, cy + 5, f);                                  // feathers
        rect(g, cx - 2, cy + 5, 2, 1, 0xFFFFA030); rect(g, cx + 1, cy + 5, 2, 1, 0xFFFFA030);
        Gfx.disc(g, cx, cy - 2 + b, 4, d);
        Gfx.disc(g, cx, cy - 2 + b, 3, f);
        px(g, cx - 4, cy - 7 + b, d); rect(g, cx - 4, cy - 6 + b, 2, 1, d);                                        // ear tufts
        px(g, cx + 4, cy - 7 + b, d); rect(g, cx + 3, cy - 6 + b, 2, 1, d);
        Gfx.disc(g, cx - 2, cy - 3 + b, 2, gold); Gfx.disc(g, cx + 2, cy - 3 + b, 2, gold);                        // big round eyes
        rect(g, cx - 3, cy - 4 + b, 3, 3, 0xFFFFFFFF); rect(g, cx + 1, cy - 4 + b, 3, 3, 0xFFFFFFFF);
        if (blink) { rect(g, cx - 3, cy - 3 + b, 3, 1, d); rect(g, cx + 1, cy - 3 + b, 3, 1, d); }
        else { rect(g, cx - 2 + look, cy - 3 + b, 1, 2, INK); rect(g, cx + 2 + look, cy - 3 + b, 1, 2, INK); }
        rect(g, cx, cy - 1 + b, 1, 2, 0xFFFFA030);                                                                 // the beak
        px(g, cx - 3, cy + b, 0x90FF9DB5); px(g, cx + 3, cy + b, 0x90FF9DB5);
    }

    private static void hedgehog(GuiGraphics g, int cx, int cy, int look, boolean fire, boolean blink) {
        int d = 0xFF5A3C1E, s = 0xFF8A6238, l = 0xFFC09A68, face = 0xFFF0D8B0;
        int dir = look < 0 ? -1 : 1, ext = fire ? 1 : 0, bx = cx - dir;
        Gfx.ellipse(g, bx, cy + 2, 5 + ext, 4 + ext, d);
        Gfx.ellipse(g, bx, cy + 2, 4 + ext, 3 + ext, s);
        for (int i = -4; i <= 4; i++) {                                                                            // the spikes
            int top = cy + 2 - (int) Math.round((4 + ext) * Math.sqrt(1 - (i * i) / 30.0));
            px(g, bx + i, top - 1, d);
            if ((i & 1) == 0) { px(g, bx + i, top - 2 - ext, d); px(g, bx + i, top, l); }
        }
        int hx = cx + dir * 3;
        Gfx.ellipse(g, hx, cy + 3, 3, 2, face);
        px(g, hx - dir * 2, cy + 1, face);                                                                         // the ear
        px(g, hx + dir * 3, cy + 3, INK);                                                                          // the nose
        if (blink) px(g, hx + dir, cy + 2, d); else { px(g, hx + dir, cy + 2, INK); px(g, hx + dir, cy + 1, 0xFF6A5A80); }
        px(g, hx, cy + 4, 0x90FF9DB5);
        px(g, cx - 2, cy + 5, face); px(g, cx + 2, cy + 5, face);
    }

    // =====================================================================================================
    // shots
    // =====================================================================================================
    static void shot(GuiGraphics g, int type, int x, int y, int t) {
        switch (type) {
            case 0 -> {   // a little fish
                rect(g, x - 1, y, 3, 2, 0xFFFFB347); px(g, x - 2, y - 1, 0xFFFFB347); px(g, x - 2, y + 1, 0xFFFFB347);
                px(g, x + 1, y, INK);
            }
            case 1 -> { Gfx.disc(g, x, y, 2, 0xFF8FD0F0); Gfx.disc(g, x, y, 1, 0xFFFFFFFF); }
            case 2 -> { Gfx.glow(g, x, y, 4, 0xFFFFA040, 120); Gfx.disc(g, x, y, 1, 0xFFFFE08A); }
            case 3 -> {
                Gfx.disc(g, x, y, 2, 0xFF3F8F3A); px(g, x - 1, y - 1, 0xFF9BE07A);
                if ((t & 2) == 0) px(g, x + 1, y - 3, 0xFFFFE27A); else px(g, x + 2, y - 3, 0xFFFF8A3C);   // the sparking fuse
            }
            case 6 -> { rect(g, x - 1, y - 1, 3, 2, 0xFFF0DCB8); px(g, x - 2, y, 0xFFB07A48); px(g, x + 2, y - 1, 0xFFB07A48); }   // a feather
            default -> { }
        }
    }

    // =====================================================================================================
    // pests: 0 aphid, 1 beetle, 2 crow, 3 boss snail, 4 caterpillar, 5 larva, 6 shell snail, 7 ghost aphid
    // =====================================================================================================
    /**
     * @param ph   a number that changes while the pest walks (it moves the legs); the pest stands at the pixel x, y
     * @param mode extra state: the mole is digging (1), the snail king is enraged (1), how many times mother caterpillar has burst
     */
    static void enemy(GuiGraphics g, int kind, int x, int y, int fx, int fy, boolean fl, int ph, int t, boolean revealed, int mode) {
        int step = ((t + ph) / 5) & 1;
        switch (kind) {
            case 0 -> aphid(g, x, y, fx, fy, fl, step);
            case 1 -> beetle(g, x, y, fx, fy, fl, step);
            case 2 -> crow(g, x, y, fx, fl, t);
            case 3 -> snail(g, x, y, fx, fl, t, true, mode == 1);
            case 4 -> caterpillar(g, x, y, fx, fy, fl, t, ph, 3, 0xFF8EE866, 0xFFF0E070);
            case 5 -> caterpillar(g, x, y, fx, fy, fl, t, ph, 2, 0xFFC8F08A, 0xFFF4F0A0);
            case 6 -> snail(g, x, y, fx, fl, t, false, false);
            case 8 -> mole(g, x, y, fx, fy, fl, t, mode == 1);
            case 9 -> queen(g, x, y, fx, fl, t);
            case 10 -> wasp(g, x, y, fx, fl, t, ph);
            case 11 -> mother(g, x, y, fx, fy, fl, t, ph, mode);
            default -> ghost(g, x, y, fx, t, revealed);
        }
    }

    private static void aphid(GuiGraphics g, int x, int y, int fx, int fy, boolean fl, int step) {
        Gfx.ellipse(g, x, y + 4, 3, 1, 0x28000000);
        rect(g, x - 3, y + 2 + step, 1, 2, 0xFF3F7F2A); rect(g, x + 2, y + 2 + (1 - step), 1, 2, 0xFF3F7F2A);
        px(g, x - 1, y + 3 + (1 - step), 0xFF3F7F2A); px(g, x + 1, y + 3 + step, 0xFF3F7F2A);
        Gfx.disc(g, x, y, 3, 0xFF3F8F2A);
        Gfx.disc(g, x, y, 2, fl ? 0xFFFFFFFF : 0xFF8EE866);
        px(g, x - 1, y - 1, 0xFFE2FFC8);
        int ex = x + fx, ey = y - 1 + (fy > 0 ? 1 : 0);
        px(g, ex - 1, ey, INK); px(g, ex + 1, ey, INK); px(g, ex - 1, ey - 1, 0xFFFFFFFF); px(g, ex + 1, ey - 1, 0xFFFFFFFF);
        px(g, x - 2 + fx, y - 3 + step, 0xFF3F7F2A); px(g, x + 2 + fx, y - 3 + (1 - step), 0xFF3F7F2A);           // feelers
    }

    private static void beetle(GuiGraphics g, int x, int y, int fx, int fy, boolean fl, int step) {
        Gfx.ellipse(g, x, y + 5, 4, 1, 0x28000000);
        px(g, x - 5, y - 1 + step, INK); px(g, x + 5, y - 1 + (1 - step), INK);
        px(g, x - 5, y + 2 + (1 - step), INK); px(g, x + 5, y + 2 + step, INK);
        Gfx.disc(g, x, y, 4, 0xFF4A2A78);
        Gfx.disc(g, x, y, 3, fl ? 0xFFFFFFFF : 0xFF8A6AD8);
        rect(g, x, y - 3, 1, 7, 0xFF4A2A78);
        px(g, x - 2, y - 2, 0xFFD8C8FF); px(g, x - 2, y - 1, 0xFFB8A0F0); px(g, x + 2, y + 1, 0xFF6A4AB0);
        Gfx.disc(g, x + fx * 4, y + fy * 4, 1, INK);
        px(g, x + fx * 4 + fy, y + fy * 4 - fx, 0xFFFFFFFF);
    }

    private static void crow(GuiGraphics g, int x, int y, int fx, boolean fl, int t) {
        int fly = y - 4 + (((t / 6) & 1) == 0 ? 0 : 1);
        Gfx.ellipse(g, x, y + 4, 3, 1, 0x30000000);
        int wing = ((t / 3) & 3);
        int wy = wing == 0 ? -4 : wing == 1 ? -2 : wing == 2 ? 0 : -2;
        Gfx.ellipse(g, x, fly, 3, 3, INK);
        Gfx.ellipse(g, x, fly, 2, 2, fl ? 0xFFFFFFFF : 0xFF4A4262);
        rect(g, x - 6, fly + wy, 4, 2, 0xFF3D3550); rect(g, x + 3, fly + wy, 4, 2, 0xFF3D3550);
        px(g, x - 6, fly + wy + 1, 0xFF5A5078); px(g, x + 6, fly + wy + 1, 0xFF5A5078);
        int hx = x + (fx == 0 ? 1 : fx * 3);
        rect(g, hx, fly, 2, 1, 0xFFFFA030);
        px(g, hx - (fx >= 0 ? 1 : -1), fly - 1, 0xFFFFFFFF);
        px(g, x - fx * 3, fly + 1, INK);
    }

    /** The boss snail wears a crown; the shell snail is smaller, grey and armoured. */
    private static void snail(GuiGraphics g, int x, int y, int fx, boolean fl, int t, boolean boss, boolean rage) {
        int bob = ((t / 12) & 1);
        int body = boss ? 0xFFF0A0C4 : 0xFFE0C49C, belly = boss ? 0xFFC96A94 : 0xFFB89A70;
        int shellD = boss ? 0xFF6A3A8C : 0xFF4A5468, shellM = boss ? 0xFFA878D8 : 0xFF9AA4BC, shellI = boss ? 0xFF8A58B8 : 0xFF7C86A0;
        if (boss) {
            Gfx.ellipse(g, x, y + 7, 8, 2, 0x30000000);
            Gfx.ellipse(g, x, y + 4, 8, 3, belly);
            Gfx.ellipse(g, x, y + 3, 7, 3, fl ? 0xFFFFFFFF : body);
            int hx = x + fx * 6;
            Gfx.disc(g, hx, y + 1, 3, body);
            px(g, hx - 1 + fx, y + 1 + bob, INK); px(g, hx + 1 + fx, y + 1 + bob, INK);
            rect(g, hx - 1, y - 3, 1, 2, belly); rect(g, hx + 1, y - 3, 1, 2, belly);
            rect(g, hx - 2, y - 5 - bob, 2, 2, INK); rect(g, hx + 1, y - 5 - bob, 2, 2, INK);
            px(g, hx - 2, y - 5 - bob, 0xFFFFFFFF); px(g, hx + 1, y - 5 - bob, 0xFFFFFFFF);
            int sx = x - fx * 2;
            Gfx.disc(g, sx, y - 1, 6, shellD);
            Gfx.disc(g, sx, y - 1, 5, fl ? 0xFFFFFFFF : shellM);
            Gfx.disc(g, sx, y - 1, 3, shellI);
            Gfx.disc(g, sx, y - 1, 1, 0xFFD8B8F8);
            px(g, sx - 3, y - 4, 0xFFE8D0FF);
            rect(g, sx - 2, y - 8, 5, 2, 0xFFFFD84A); px(g, sx - 2, y - 9, 0xFFFFD84A); px(g, sx, y - 10, 0xFFFFD84A); px(g, sx + 2, y - 9, 0xFFFFD84A); px(g, sx, y - 7, 0xFFE05A6A);
            if (rage) {                                                                                           // angry: red brows, a red glow and steam
                Gfx.glow(g, x, y - 2, 11, 0xFFFF4040, 55);
                rect(g, hx - 2, y - 6 - bob, 2, 1, 0xFFC02020); rect(g, hx + 1, y - 6 - bob, 2, 1, 0xFFC02020);
                int st = (t / 4) % 6;
                px(g, x - 3 + st, y - 11 - st / 2, Gfx.alpha(0xFFFFFFFF, 200 - st * 30)); px(g, x + 3 - st, y - 11 - st / 2, Gfx.alpha(0xFFFFFFFF, 200 - st * 30));
            }
        } else {
            Gfx.ellipse(g, x, y + 5, 5, 1, 0x30000000);
            Gfx.ellipse(g, x, y + 3, 5, 2, belly);
            Gfx.ellipse(g, x, y + 3, 4, 1, fl ? 0xFFFFFFFF : body);
            int hx = x + fx * 4;
            Gfx.disc(g, hx, y + 2, 2, body);
            px(g, hx + fx, y + 2, INK); px(g, hx - 1 + fx, y - 1 - bob, INK); px(g, hx + 1 + fx, y - 1 - bob, INK);
            px(g, hx, y, belly);
            int sx = x - fx;
            Gfx.disc(g, sx, y - 1, 5, shellD);
            Gfx.disc(g, sx, y - 1, 4, fl ? 0xFFFFFFFF : shellM);
            Gfx.disc(g, sx, y - 1, 2, shellI);
            rect(g, sx - 4, y - 1, 9, 1, shellD); rect(g, sx, y - 5, 1, 9, shellD);                                  // armour plates
            px(g, sx - 3, y - 3, 0xFFE8EEFF); px(g, sx + 2, y + 1, 0xFFE8EEFF); px(g, sx - 3, y + 1, 0xFFE8EEFF); px(g, sx + 2, y - 3, 0xFFE8EEFF);   // rivets
        }
    }

    private static void caterpillar(GuiGraphics g, int x, int y, int fx, int fy, boolean fl, int t, int ph, int segs, int c1, int c2) {
        Gfx.ellipse(g, x, y + 4, segs + 1, 1, 0x28000000);
        int r = segs == 3 ? 3 : 2;
        for (int i = segs - 1; i >= 0; i--) {
            int w = (int) Math.round(Math.sin((t + ph) * 0.25 + i * 1.3));
            int sx = x - fx * i * (r), sy = y - fy * i * (r);
            if (fx != 0) sy += w; else sx += w;
            int col = fl ? 0xFFFFFFFF : (i & 1) == 0 ? c1 : c2;
            Gfx.disc(g, sx, sy, r, Gfx.darker(c1, 0.45F));
            Gfx.disc(g, sx, sy, r - 1, col);
            if (i > 0 && segs == 3) px(g, sx, sy - 1, 0xFFFF9A4A);                                                // orange back spots
            if (i == 0) {
                int ex = sx + fx, ey = sy - 1 + (fy > 0 ? 1 : 0);
                px(g, ex - 1, ey, INK); px(g, ex + 1, ey, INK);
                if (segs == 3) { px(g, ex - 1, ey - 1, 0xFFFFFFFF); px(g, ex + 1, ey - 1, 0xFFFFFFFF); px(g, sx - 2 + fx, sy - r - 1, INK); px(g, sx + 2 + fx, sy - r - 1, INK); }
            }
        }
    }

    /** A see-through ghost: nearly invisible until an owl lights it up. */
    private static void ghost(GuiGraphics g, int x, int y, int fx, int t, boolean revealed) {
        int bob = (int) Math.round(Math.sin(t * 0.12 + x * 0.1));
        int yy = y - 2 + bob;
        if (!revealed) {
            int a = 22 + (int) (Math.sin(t * 0.2 + x) * 10 + 10);
            Gfx.disc(g, x, yy, 3, Gfx.alpha(0xFFD8ECFF, a));
            if (((t / 7) & 3) == 0) Gfx.sparkle(g, x + 2, yy - 2, 1, t, 0x90FFFFFF);
            return;
        }
        Gfx.glow(g, x, yy, 7, 0xFFB8E0FF, 90);
        Gfx.ellipse(g, x, y + 4, 3, 1, 0x20000000);
        Gfx.disc(g, x, yy, 3, 0xE0A8C8F0);
        Gfx.disc(g, x, yy, 2, 0xF0E8F6FF);
        rect(g, x - 3, yy + 2, 7, 2, 0xE0A8C8F0);
        px(g, x - 3, yy + 4, 0xE0A8C8F0); px(g, x - 1, yy + 4, 0xE0A8C8F0); px(g, x + 1, yy + 4, 0xE0A8C8F0); px(g, x + 3, yy + 4, 0xE0A8C8F0);   // the wavy hem
        px(g, x - 1 + fx, yy - 1, INK); px(g, x + 1 + fx, yy - 1, INK);
        px(g, x - 2, yy + 1, 0x90FF9DB5); px(g, x + 2, yy + 1, 0x90FF9DB5);
    }

    /** The digger mole: a hard hat with a lamp, shovel claws, and underground it is only a moving heap of earth. */
    private static void mole(GuiGraphics g, int x, int y, int fx, int fy, boolean fl, int t, boolean under) {
        if (under) {
            Gfx.ellipse(g, x, y + 3, 7, 3, 0x30000000);
            Gfx.ellipse(g, x, y + 2, 6, 3, 0xFF6A4A2A);
            Gfx.ellipse(g, x, y + 1, 5, 2, 0xFF8A6238);
            rect(g, x - 3, y, 3, 1, 0xFFB8905A);
            px(g, x - 7, y + 3, 0xFF6A4A2A); px(g, x + 7, y + 3, 0xFF6A4A2A);                                       // cracks in the ground
            int hop = (t / 3) % 4;
            px(g, x - 4 + hop, y - 3 + (hop & 1), 0xFFB8905A); px(g, x + 3 - hop, y - 2 + (hop & 1), 0xFF8A6238);   // hopping dirt
            return;
        }
        Gfx.ellipse(g, x, y + 7, 8, 2, 0x30000000);
        int d = 0xFF3A2A22, f = fl ? 0xFFFFFFFF : 0xFF6A4A3A, l = 0xFF8A6A52;
        Gfx.disc(g, x - fx * 2, y + 2, 6, d);
        Gfx.disc(g, x - fx * 2, y + 2, 5, f);
        Gfx.ellipse(g, x - fx * 2, y + 4, 3, 2, l);
        int hx = x + fx * 4, hy = y + fy * 4 - 1;
        Gfx.disc(g, hx, hy, 4, d);
        Gfx.disc(g, hx, hy, 3, f);
        Gfx.disc(g, hx + fx * 3, hy + fy * 3 + 1, 1, 0xFFFF9DB5);                                                    // the pink snout
        int ex = hx + fx, ey = hy - 1 + (fy > 0 ? 1 : 0);
        px(g, ex - 1, ey, INK); px(g, ex + 1, ey, INK);
        int sw = (t / 6) & 1;
        for (int sgn = -1; sgn <= 1; sgn += 2) {                                                                     // the digging claws
            int cx = hx + fx * (4 + sw) + fy * 3 * sgn, cy = hy + fy * (4 + sw) + fx * 3 * sgn + 2;
            rect(g, cx, cy, 2, 2, 0xFFF0E0D0);
            px(g, cx + fx, cy + fy, 0xFFB8A890);
        }
        rect(g, hx - 3, hy - 5, 7, 2, 0xFFFFD84A); rect(g, hx - 2, hy - 6, 5, 1, 0xFFFFD84A);                      // the hard hat
        px(g, hx - 1, hy - 5, 0xFFFFF6B0);
        Gfx.glow(g, hx + fx * 3, hy - 5, 3, 0xFFFFF0A0, 90);                                                         // its lamp
    }

    /** The wasp queen flies over her swarm, wearing a crown. */
    private static void queen(GuiGraphics g, int x, int y, int fx, boolean fl, int t) {
        int dir = fx == 0 ? 1 : fx;
        int fly = y - 5 + (((t / 5) & 1) == 0 ? 0 : 1);
        Gfx.ellipse(g, x, y + 5, 6, 1, 0x30000000);
        int wf = ((t / 2) & 1) == 0 ? -2 : 0;
        Gfx.ellipse(g, x - 3, fly - 4 + wf, 4, 2, 0xD0E8F4FF); Gfx.ellipse(g, x + 3, fly - 4 - wf, 4, 2, 0xD0E8F4FF);   // buzzing wings
        int sx = x - dir * 3;
        Gfx.ellipse(g, sx, fly + 1, 6, 4, 0xFF8A5A10);
        Gfx.ellipse(g, sx, fly + 1, 5, 3, fl ? 0xFFFFFFFF : 0xFFFFD84A);
        rect(g, sx - 3, fly - 1, 1, 5, INK); rect(g, sx - 1, fly - 2, 1, 6, INK); rect(g, sx + 1, fly - 2, 1, 6, INK); rect(g, sx + 3, fly - 1, 1, 5, INK);
        px(g, sx - dir * 6, fly + 1, INK); px(g, sx - dir * 7, fly + 1, INK);                                        // the stinger
        int hx = x + dir * 4;
        Gfx.disc(g, hx, fly, 3, 0xFF8A5A10); Gfx.disc(g, hx, fly, 2, fl ? 0xFFFFFFFF : 0xFFFFD84A);
        px(g, hx + dir - 1, fly - 1, INK); px(g, hx + dir + 1, fly - 1, INK); px(g, hx + dir, fly + 1, 0xFFFF6B8A);
        rect(g, hx - 2, fly - 4, 5, 1, 0xFFFFD84A); px(g, hx - 2, fly - 5, 0xFFFFD84A); px(g, hx, fly - 6, 0xFFFFD84A); px(g, hx + 2, fly - 5, 0xFFFFD84A); px(g, hx, fly - 5, 0xFFE0485A);   // the crown
    }

    /** A wasp of the queen's swarm. */
    private static void wasp(GuiGraphics g, int x, int y, int fx, boolean fl, int t, int ph) {
        int fly = y - 4 + (((t + ph) / 3) & 1);
        Gfx.ellipse(g, x, y + 4, 2, 1, 0x28000000);
        int wf = ((t / 2) & 1) == 0 ? -2 : -1;
        px(g, x - 2, fly + wf, 0xD0E8F4FF); px(g, x - 3, fly + wf, 0xD0E8F4FF); px(g, x + 2, fly + wf, 0xD0E8F4FF); px(g, x + 3, fly + wf, 0xD0E8F4FF);
        Gfx.disc(g, x, fly, 2, 0xFF8A5A10);
        Gfx.disc(g, x, fly, 1, fl ? 0xFFFFFFFF : 0xFFFFD84A);
        px(g, x, fly - 1, INK); px(g, x, fly + 1, INK);
        px(g, x + (fx >= 0 ? 2 : -2), fly - 1, INK);
        px(g, x - (fx >= 0 ? 3 : -3), fly + 1, INK);
    }

    /** Mother caterpillar: five fat segments and a tiara; the glow grows each time she bursts into children. */
    private static void mother(GuiGraphics g, int x, int y, int fx, int fy, boolean fl, int t, int ph, int mode) {
        Gfx.ellipse(g, x, y + 8, 11, 2, 0x30000000);
        if (mode > 0) Gfx.glow(g, x, y, 13, 0xFFFF9AE0, 35 + mode * 25);
        int c1 = 0xFFC878E0, c2 = 0xFFE8A0F0;
        for (int i = 4; i >= 0; i--) {
            int w = (int) Math.round(Math.sin((t + ph) * 0.2 + i * 1.2) * 1.2);
            int sx = x + fx * (2 - i) * 5, sy = y + fy * (2 - i) * 5;
            if (fx != 0) sy += w; else sx += w;
            int r = i == 0 ? 5 : 4;
            int col = fl ? 0xFFFFFFFF : (i & 1) == 0 ? c1 : c2;
            Gfx.disc(g, sx, sy, r, 0xFF6A3A8C);
            Gfx.disc(g, sx, sy, r - 1, col);
            if (i > 0) { px(g, sx - 1, sy - 2, 0xFFFF9A4A); px(g, sx + 1, sy - 2, 0xFFFF9A4A); px(g, sx, sy + 2, 0xFFFFF0B0); }
            if (i == 0) {
                int ex = sx + fx, ey = sy - 1 + (fy > 0 ? 1 : 0);
                rect(g, ex - 2, ey - 1, 2, 2, 0xFFFFFFFF); rect(g, ex + 1, ey - 1, 2, 2, 0xFFFFFFFF);               // big eyes
                px(g, ex - 1, ey, INK); px(g, ex + 1, ey, INK);
                px(g, ex - 3, ey + 2, 0x90FF9DB5); px(g, ex + 3, ey + 2, 0x90FF9DB5);
                rect(g, sx - 3, sy - 6, 7, 1, 0xFFFFD84A); px(g, sx - 3, sy - 7, 0xFFFFD84A); px(g, sx, sy - 8, 0xFFFFD84A); px(g, sx + 3, sy - 7, 0xFFFFD84A); px(g, sx, sy - 7, 0xFFE0485A);   // the tiara
                px(g, sx - 3, sy - 7 + ((t / 8) & 1) - 1, INK); px(g, sx + 3, sy - 9 + ((t / 8) & 1), INK);
            }
        }
    }

    // =====================================================================================================
    // scenery
    // =====================================================================================================
    /** @param sick 0 (healthy) .. 1 (wilted): the cabbages turn yellow as the lives run out. */
    static void decor(GuiGraphics g, Map m, int c, int r, int t, float sick, boolean shake) {
        int kind = m.kind[c][r], cx = c * T + T / 2, cy = OY + r * T + T / 2;
        boolean snow = m.index == 2;
        switch (kind) {
            case TREE -> {
                Gfx.ellipse(g, cx, cy + 5, 5, 2, 0x28000000);
                if (snow) {   // a pine with snowy branches
                    rect(g, cx - 1, cy + 3, 3, 3, 0xFF6A4A2A);
                    rect(g, cx - 4, cy + 1, 9, 3, 0xFF2F6F4A); rect(g, cx - 3, cy - 2, 7, 3, 0xFF2F6F4A); rect(g, cx - 2, cy - 5, 5, 3, 0xFF3A8458); px(g, cx, cy - 6, 0xFF3A8458);
                    rect(g, cx - 4, cy + 1, 9, 1, 0xFFF4FAFF); rect(g, cx - 3, cy - 2, 7, 1, 0xFFF4FAFF); rect(g, cx - 2, cy - 5, 5, 1, 0xFFF4FAFF);
                    px(g, cx - 3, cy + 3, 0xFFC9E1F4); px(g, cx + 3, cy, 0xFFC9E1F4);
                } else {
                    rect(g, cx - 1, cy + 1, 3, 5, 0xFF7A4E28);
                    rect(g, cx, cy + 1, 1, 5, 0xFFA8733F);
                    int sw = ((t / 50 + c) & 3) == 0 ? 1 : 0;
                    Gfx.disc(g, cx + sw, cy - 2, 5, 0xFF3A8A3A);
                    Gfx.disc(g, cx + sw, cy - 2, 4, 0xFF5CB84E);
                    Gfx.disc(g, cx + sw - 1, cy - 3, 2, 0xFF86DC72);
                    px(g, cx + sw + 2, cy - 1, 0xFFE0485A); px(g, cx + sw - 2, cy, 0xFFE0485A);
                }
            }
            case BUSH -> {
                Gfx.ellipse(g, cx, cy + 5, 5, 2, 0x28000000);
                Gfx.ellipse(g, cx, cy + 2, 5, 4, snow ? 0xFFA9C4DC : 0xFF3A8A3A);
                Gfx.ellipse(g, cx, cy + 2, 4, 3, snow ? 0xFFF4FAFF : 0xFF58B04A);
                Gfx.disc(g, cx - 2, cy + 1, 1, snow ? 0xFFFFFFFF : 0xFF86DC72);
                px(g, cx + 1, cy + 1, 0xFFFF6B8A); px(g, cx - 1, cy + 3, 0xFFFF6B8A); px(g, cx + 3, cy + 3, 0xFFFF6B8A);
            }
            case ROCK -> {
                Gfx.ellipse(g, cx, cy + 5, 5, 2, 0x28000000);
                Gfx.ellipse(g, cx, cy + 2, 5, 4, 0xFF7C8088);
                Gfx.ellipse(g, cx, cy + 2, 4, 3, 0xFFA9AEB8);
                rect(g, cx - 2, cy, 3, 1, 0xFFD6DAE2);
                if (snow) { rect(g, cx - 3, cy - 1, 7, 2, 0xFFF4FAFF); px(g, cx - 4, cy, 0xFFF4FAFF); }
                else { px(g, cx + 3, cy + 5, 0xFF58A84A); px(g, cx + 4, cy + 4, 0xFF58A84A); }
            }
            case CABBAGE -> {
                int dark = Gfx.mix(0xFF3A8A3A, 0xFF8A7A30, sick), mid = Gfx.mix(0xFF5CB84E, 0xFFB5A040, sick), light = Gfx.mix(0xFF9BE07A, 0xFFD8C86A, sick);
                int sh = shake ? ((t & 1) == 0 ? 1 : -1) : 0;
                int bob = ((t / 30 + c) & 1) == 0 ? 0 : 1;
                Gfx.ellipse(g, cx, cy + 5, 5, 2, 0x28000000);
                rect(g, cx - 5, cy + 3, 10, 3, snow ? 0xFFE6EEF6 : 0xFF8A5A30);
                Gfx.disc(g, cx + sh, cy + 1 - bob / 2, 5, dark);
                Gfx.disc(g, cx + sh, cy + 1 - bob / 2, 4, mid);
                Gfx.disc(g, cx + sh, cy + 1 - bob / 2, 2, light);
                rect(g, cx - 1 + sh, cy - 3, 1, 3, light); rect(g, cx - 3 + sh, cy + 1, 2, 1, light); rect(g, cx + 2 + sh, cy + 1, 2, 1, light);
                if (snow) { rect(g, cx - 2 + sh, cy - 4 - bob / 2, 4, 1, 0xFFF4FAFF); }
            }
            case WATER, LILY -> {
                int x = c * T, y = OY + r * T;
                g.fillGradient(x, y, x + T, y + T, 0xFF6CC4F0, 0xFF3E96D8);
                int rp = (int) Math.round(Math.sin(t * 0.06 + c * 2 + r)) ;
                rect(g, x + 2 + rp, y + 3, 4, 1, 0x50FFFFFF); rect(g, x + 6 - rp, y + 8, 4, 1, 0x40FFFFFF);
                boolean[][] w = m.water;
                if (c == 0 || !w[c - 1][r]) { rect(g, x, y, 1, T, 0xFFE8D8A8); rect(g, x + 1, y, 1, T, 0xFF2E78B8); }
                if (c == COLS - 1 || !w[c + 1][r]) { rect(g, x + T - 1, y, 1, T, 0xFFE8D8A8); rect(g, x + T - 2, y, 1, T, 0xFF2E78B8); }
                if (r == 0 || !w[c][r - 1]) { rect(g, x, y, T, 1, 0xFFE8D8A8); rect(g, x, y + 1, T, 1, 0xFF2E78B8); }
                if (r == ROWS - 1 || !w[c][r + 1]) { rect(g, x, y + T - 1, T, 1, 0xFFE8D8A8); rect(g, x, y + T - 2, T, 1, 0xFF2E78B8); }
                if (kind == LILY) {
                    int lx = cx + (((t / 90 + c) & 1) == 0 ? 0 : 1);
                    Gfx.disc(g, lx, cy, 3, 0xFF2F8F4A); Gfx.disc(g, lx, cy, 2, 0xFF58C46A);
                    px(g, lx + 1, cy - 1, 0xFF3E96D8); px(g, lx + 2, cy, 0xFF3E96D8);                              // the notch
                    px(g, lx - 1, cy, 0xFFFF9DC4); px(g, lx - 1, cy - 1, 0xFFFFC8E0); px(g, lx - 2, cy, 0xFFFFC8E0);
                }
            }
            case REED -> {
                Gfx.ellipse(g, cx, cy + 5, 5, 2, 0x20000000);
                for (int i = -1; i <= 1; i++) {
                    int sw = ((t / 40 + i + c) & 3) == 0 ? 1 : 0;
                    int hgt = 7 + (i == 0 ? 2 : 0);
                    rect(g, cx + i * 3, cy + 5 - hgt, 1, hgt, 0xFF3F8F3A);
                    rect(g, cx + i * 3 + sw, cy + 5 - hgt - 2, 2, 3, 0xFF8A5A30);                                  // the cattail
                    px(g, cx + i * 3 + sw, cy + 5 - hgt - 2, 0xFFB88450);
                }
            }
            default -> {   // snowman
                Gfx.ellipse(g, cx, cy + 5, 5, 2, 0x28000000);
                Gfx.disc(g, cx, cy + 2, 4, 0xFFB8D4EC); Gfx.disc(g, cx, cy + 2, 3, 0xFFFFFFFF);
                Gfx.disc(g, cx, cy - 2, 3, 0xFFB8D4EC); Gfx.disc(g, cx, cy - 2, 2, 0xFFFFFFFF);
                px(g, cx - 1, cy - 3, INK); px(g, cx + 1, cy - 3, INK);
                px(g, cx, cy - 2, 0xFFFF8A2A); px(g, cx + 1, cy - 2, 0xFFFF8A2A);                                  // the carrot nose
                rect(g, cx - 2, cy - 1, 5, 1, 0xFFE0485A); px(g, cx + 2, cy, 0xFFE0485A);                          // the scarf
                rect(g, cx - 2, cy - 5, 5, 1, INK); rect(g, cx - 1, cy - 6, 3, 1, INK);                            // the hat
                px(g, cx, cy + 2, INK); px(g, cx, cy + 4, INK);
            }
        }
    }
}
