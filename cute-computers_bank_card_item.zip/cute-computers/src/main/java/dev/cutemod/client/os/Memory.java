package dev.cutemod.client.os;

/**
 * What the memory (RAM) of this PC can carry. Every running program takes {@link #weight} "slots" of it; the RAM level
 * decides how many slots there are ({@link #capacity}). The same numbers drive three things, so they always agree:
 * <ul>
 *   <li>a new program does not start when its slots do not fit (ComputerScreen asks the player to close one, F10),</li>
 *   <li>the Task Manager draws the RAM bar from the slots in use,</li>
 *   <li>while the memory is full a small PC stalls now and then, and, if it stays crowded on the bare desktop, it may crash
 *       (only the small ones: from 16 GB on nothing of this ever happens).</li>
 * </ul>
 * Balance: the stock 2 GB PC holds 3 programs, so the first RAM bar (30 coins) is felt at once; 16 GB is "enough for everything".
 */
public final class Memory {
    private Memory() {}

    /** Program slots per RAM level (index = level in PcHardware.RAM_GB: 2, 4, 8, 16, 32, 64 GB). */
    private static final int[] SLOTS = {3, 4, 6, 8, 11, 15};

    /** Part of the RAM the system itself takes (the Task Manager draws it as the base of the bar). */
    public static final float SYSTEM_SHARE = 0.12f;

    public static int capacity(int ramIdx) { return SLOTS[Math.max(0, Math.min(SLOTS.length - 1, ramIdx))]; }

    public static int capacity() { return capacity(PcSpecs.get().ramIdx()); }

    /** Slots of the program with this Dock number (-1 = none): a game that wants 32 GB or more takes three, a big game two, everything else one. */
    public static int weight(int icon) {
        if (icon < 0 || !Items.isGame(icon)) return 1;
        String id = Items.gameId(icon);
        if (id == null) return 1;
        int need = Library.minRam(id);
        return need >= 4 ? 3 : need >= 2 ? 2 : 1;
    }

    /** True when the slots in use leave no room for even one more small program. */
    public static boolean full(int used) { return used >= capacity(); }

    /** True when the memory is crowded (three quarters or more in use): the warning and the crash chance start here. */
    public static boolean crowded(int used) { return used * 4 >= capacity() * 3; }

    // ---------- the failures (they only exist on the small PCs: 2, 4 and 8 GB) ----------
    /** Average ticks between two stalls of the front program while the memory is full (0 = never). */
    public static int stallEvery(int ramIdx) { return switch (ramIdx) { case 0 -> 600; case 1 -> 900; case 2 -> 1500; default -> 0; }; }

    /** How long a stall lasts, in ticks (60 a second): 0.7 s, 0.5 s, 0.3 s. */
    public static int stallLen(int ramIdx) { return switch (ramIdx) { case 0 -> 40; case 1 -> 30; case 2 -> 18; default -> 0; }; }

    /** Chance per minute (spent on the bare desktop, with the memory crowded and after the warning) of a blue screen. */
    public static double crashChance(int ramIdx) { return switch (ramIdx) { case 0 -> 0.12; case 1 -> 0.08; case 2 -> 0.04; default -> 0.0; }; }

    /** Ticks the memory must stay crowded before a crash is even possible: the player always gets the warning first (20 s). */
    public static final int WARN_TICKS = 60 * 20;

    /** Ticks since the start / restart before the first crash is possible (3 minutes). */
    public static final int GRACE_TICKS = 60 * 60 * 3;
}
