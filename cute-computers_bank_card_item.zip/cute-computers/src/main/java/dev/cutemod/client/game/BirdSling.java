package dev.cutemod.client.game;

import dev.cutemod.client.os.Progress;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Bird Sling: an Angry Birds style game. Pull the slingshot back with the mouse, let go and the bird flies at the
 * piggies' shelters. Wood, ice and stone blocks break, TNT goes off, towers fall, the piggies pop.
 * <p>
 * Six birds: red (plain), blue (splits in three on a click), yellow (a click makes it dash), black (a click, or a hit,
 * and it blows up), white (a click drops an egg bomb and the bird hops up) and the heavy one (a click slams it down;
 * it breaks stone). 24 levels in three worlds (meadow, frost, volcano), each with a boss at the end.
 * Three hearts: a lost level costs a heart and is played again; a boss gives a heart back.
 * <p>
 * The physics are a small home-made one: blocks are boxes that do not turn, but they slide off a support that
 * holds them only by an edge, so towers still fall over. Everything is simulated in three small steps per tick.
 * The levels live in {@link BirdLevels}.
 */
public class BirdSling extends MiniGame {
    static final int GY = 124;
    static final int WOOD = 0, ICE = 1, STONE = 2, TNT = 3, BOUNCE = 4, METAL = 5;
    private static final int LEVELS = BirdLevels.COUNT, SUB = 3, LIVES = 5;
    private static final float DT = 1F / SUB, G = 0.11F, MAXD = 36F, VMAX = 5.6F, AX = 46F, AY = 97F, TH = 0.8F;
    private static final int K_BIRD = 0, K_PIG = 1, K_BLOCK = 2;
    private static final int RED = 0, BLUE = 1, YELLOW = 2, BLACK = 3, WHITE = 4, HEAVY = 5, EGG = 6, BOOM = 7, MAGNET = 8;
    private static final int S_READY = 0, S_DRAG = 1, S_FLY = 2, S_CLEAR = 3, S_FAIL = 4, S_MENU = 5;
    private static final String BIRD_CHARS = "RBYKWH_OM";

    // wood, ice, stone, TNT, a trampoline, steel (the last two are fixed in place and cannot be broken)
    private static final float[] M_HP = {5F, 3F, 8F, 1.5F, 1e9F, 1e9F}, M_DENS = {1F, 0.7F, 2.2F, 0.9F, 1F, 3F}, M_FRAG = {1F, 1.5F, 0.65F, 2.2F, 0F, 0F};
    private static final int[] M_COL = {0xFFC98B4E, 0xFFA9DDF5, 0xFF9A9AA8, 0xFFD8453A, 0xFFE86AA8, 0xFF7A8AA0};
    // red, blue, yellow, black, white, heavy, egg, boomerang (orange), magnet (purple)
    private static final int[] B_COL = {0xFFE0453A, 0xFF4A8FE0, 0xFFF5D03A, 0xFF3A3A48, 0xFFF2F2F2, 0xFF8A2A2A, 0xFFFFF4D0, 0xFFF08A30, 0xFF9A5AD8};
    private static final float[] B_R = {4F, 4F, 4F, 4F, 4F, 6F, 2.5F, 4F, 4F}, B_M = {2F, 2F, 2F, 2.6F, 1.8F, 7F, 1.2F, 2F, 2.2F}, B_DMG = {1F, 1F, 1F, 1F, 1F, 1.6F, 1F, 1F, 1F};
    // piggy, piggy in a helmet, boss
    private static final float[] PIG_FRAG = {1.2F, 0.8F, 0.9F}, BOSS_HP = {12F, 20F, 14F, 14F};
    private static final int[] BOSS_COL = {0xFF7ED957, 0xFF8FD8F0, 0xFFB5503A, 0xFFE87AC0};
    private static final float PIG_REACH = 3F;
    private final float[] guideX = new float[170], guideY = new float[170];
    private static final float[] LAUNCH_PITCH = {1.5F, 1.9F, 1.3F, 0.7F, 1.7F, 0.5F, 1F, 1.1F, 0.9F};
    private static final int[] M_DARK = new int[6], M_LIGHT = new int[6], B_DARK = new int[9], B_LIGHT = new int[9];
    // the three worlds: sky top and bottom, far and near hills, grass (top, bottom, edge), soil (top, bottom), cloud, sun
    private static final int[] SKY_T = {0xFF6FCBFF, 0xFF8FB8E8, 0xFF3A2048, 0xFFB8A0F0}, SKY_B = {0xFFDDF5FF, 0xFFEAF4FF, 0xFFFF9A5A, 0xFFFFD6EC};
    private static final int[] HILL_A = {0xFF8FD87A, 0xFFE4F0FA, 0xFF5A2A3A, 0xFFFFB8DC}, HILL_B = {0xFF7ACB68, 0xFFCFE2F4, 0xFF442030, 0xFFF59AC8};
    private static final int[] GR_T = {0xFF6BCF58, 0xFFF4FAFF, 0xFF5A4A48, 0xFF9AF0C8}, GR_B = {0xFF3F9A3A, 0xFFBFD8EE, 0xFF3A2C2C, 0xFF52C8A0};
    private static final int[] GR_E = {0xFF7EE05F, 0xFFFFFFFF, 0xFF7A6A66, 0xFFC8FFE6};
    private static final int[] DIRT_T = {0xFF9A6A3E, 0xFF8AA0B8, 0xFF4A3030, 0xFFE8A0C0}, DIRT_B = {0xFF6E4526, 0xFF6C849C, 0xFF2A1A1A, 0xFFC0709A};
    private static final int[] CLOUD = {0xCCFFFFFF, 0xCCFFFFFF, 0x66301828, 0xDDFFFFFF}, SUN = {0xFFFFF6C8, 0xFFFFFFFF, 0xFFFF6A3A, 0xFFFFF0A0};

    static {
        for (int i = 0; i < 6; i++) { M_DARK[i] = Gfx.darker(M_COL[i], 0.25F); M_LIGHT[i] = Gfx.lighter(M_COL[i], 0.35F); }
        for (int i = 0; i < 9; i++) { B_DARK[i] = Gfx.darker(B_COL[i], 0.45F); B_LIGHT[i] = Gfx.lighter(B_COL[i], 0.6F); }
    }

    private static final class Body {
        final int kind;
        int type, var, age, hit, still;
        float x, y, vx, vy, w, h, r, rad, hp, maxHp, mass, inv;
        boolean dead, used, child, fixed;
        int fxT;                          // a magnet bird: ticks of pull left; a hopping boss: ticks to the next hop
        float supL, supR;                 // what holds it from below this step: the span of the supports (a box falls over a ledge)

        Body(int kind) { this.kind = kind; }

        Body copy() {
            Body c = new Body(kind);
            c.type = type; c.var = var; c.age = age; c.hit = hit; c.still = still; c.fxT = fxT;
            c.x = x; c.y = y; c.vx = vx; c.vy = vy; c.w = w; c.h = h; c.r = r; c.rad = rad; c.hp = hp; c.maxHp = maxHp; c.mass = mass; c.inv = inv;
            c.dead = dead; c.used = used; c.child = child; c.fixed = fixed; c.supL = supL; c.supR = supR;
            return c;
        }
    }

    private static final class Fx {
        float x, y, vx, vy, rad;
        int life, max, kind, col;
        String txt;
    }

    private final List<Body> bodies = new ArrayList<>(), pending = new ArrayList<>();
    private final List<Fx> fx = new ArrayList<>();
    private int[] queue = new int[0];
    private int qi, cur, level, lives, state, stateT, scoreBase, time, flyT, calm, winT, hop, bannerT, sfxCool;
    private int pigCount, combo, lastKill, stars, world, idleT, shakeT, shakeMag, slowT, flashT;
    private int menuWorld, totalStars, hintStage, hintIdx, hintTotal, hintBestPigs, hintBestScore, hintAbil, failsHere, failLevel = -1, clearT, pillW = 62;
    private float hintBestHp, hintAng, hintPow;
    private int[] hintAb;
    private boolean hinted;
    private BirdSling hintBase;
    private String[] worldNames;
    private String starsText = "", pickText = "", hintText = "";
    private static final String[] MUSIC = {"birds_meadow", "birds_frost", "birds_volcano", "birds_sky"};
    private int extra;                                      // birds given out of mercy after lost tries
    private boolean sim;                                  // a copy that only plays a shot to see what comes of it (the hint)
    private float px, py, wind;
    private Body lead, boss;
    private boolean won;
    private String lvText = "", bannerA = "", clearText, failText;

    // ------------------------------------------------------------------ start

    @Override
    public void reset() {
        time = 0; scoreBase = 0;
        openMenu();
    }

    /** A run: three hearts, from this level on, as far as the hearts last. */
    private void startRun(int lv) {
        failLevel = -1; failsHere = 0;
        score = 0; over = false; won = false; lives = LIVES;
        startLevel(lv);
    }

    void startLevel(int n) {
        level = n;
        world = n / 8;
        scoreBase = score;
        bodies.clear(); pending.clear(); fx.clear();
        String q = BirdLevels.QUEUES[n];
        extra = n == failLevel ? Math.min(2, failsHere) : 0;
        queue = new int[q.length() + extra];
        for (int i = 0; i < queue.length; i++) queue[i] = i < q.length() ? BIRD_CHARS.indexOf(q.charAt(i)) : RED;
        hintStage = 0; hintBase = null; hinted = false; clearT = 0;
        if (n != failLevel) { failLevel = n; failsHere = 0; }
        qi = 0; lead = null; boss = null; flyT = 0; calm = 0; winT = 0; idleT = 0; combo = 0; lastKill = -1000; bannerT = 130;
        wind = BirdLevels.wind(n);
        BirdLevels.build(this, n);
        for (Body b : bodies) if (b.kind == K_PIG && b.type == 2) boss = b;
        pigCount = countPigs();
        // the texts are made once per level, not once per frame
        lvText = Component.translatable("cutemod.birds.level", n + 1, LEVELS).getString();
        if (n % 8 == 7) bannerA = Component.translatable("cutemod.birds.bossfmt", Component.translatable("cutemod.birds.boss." + world).getString()).getString();
        else if (n % 8 == 0) bannerA = Component.translatable("cutemod.birds.world." + world).getString();
        else bannerA = "";
        if (hintText.isEmpty()) hintText = Component.translatable("cutemod.birds.hintclick").getString();
        if (clearText == null) {
            clearText = Component.translatable("cutemod.birds.clear").getString();
            failText = Component.translatable("cutemod.birds.fail").getString();
        }
        loadNext();
    }

    private void loadNext() {
        cur = queue[qi++];
        state = S_READY;
        hop = 24;
        px = AX; py = AY;
        hintStage = 0; hintBase = null;
    }

    private int countPigs() {
        int n = 0;
        for (int i = 0, m = bodies.size(); i < m; i++) { Body b = bodies.get(i); if (b.kind == K_PIG && !b.dead) n++; }
        return n;
    }

    int pigsLeft() { return pigCount; }

    int birdsLeft() { return queue.length - qi + (cur >= 0 ? 1 : 0); }

    int state() { return state; }

    int level() { return level; }

    int lives() { return lives; }

    // ------------------------------------------------------------------ building (called by the levels)

    private Body mkBlock(int mat, float left, float bottom, int w, int h) {
        Body b = new Body(K_BLOCK);
        b.type = mat; b.w = w; b.h = h;
        b.x = left + w / 2F; b.y = bottom - h / 2F;
        b.rad = (float) Math.sqrt(w * w + h * h) / 2F;
        b.maxHp = b.hp = M_HP[mat] * Math.max(0.6F, Math.min(1.6F, (float) Math.sqrt(w * h / 80F)));
        b.mass = Math.max(0.6F, w * h * M_DENS[mat] / 40F);
        b.inv = 1F / b.mass;
        return b;
    }

    private Body mkPig(int type, int var, float cx, float bottom) {
        Body b = new Body(K_PIG);
        b.type = type; b.var = var;
        b.r = type == 2 ? 9F : 5F; b.rad = b.r;
        b.x = cx; b.y = bottom - b.r;
        b.maxHp = b.hp = type == 0 ? 4F : type == 1 ? 9F : BOSS_HP[var];
        if (type == 2 && var == 3) b.fxT = 60;
        b.mass = type == 2 ? 3.6F : type == 1 ? 1.3F : 1.1F;
        b.inv = 1F / b.mass;
        return b;
    }

    void blk(int mat, int left, int bottom, int w, int h) { bodies.add(mkBlock(mat, left, bottom, w, h)); }

    void tnt(int left, int bottom) { blk(TNT, left, bottom, 8, 8); }

    /** A block that hangs in the air and cannot be broken (steel), or a trampoline. */
    private void fixedBlk(int mat, int left, int bottom, int w, int h) {
        Body b = mkBlock(mat, left, bottom, w, h);
        b.fixed = true; b.inv = 0F; b.mass = 30F;
        bodies.add(b);
    }

    void plat(int left, int bottom, int w, int h) { fixedBlk(METAL, left, bottom, w, h); }

    void pad(int left, int bottom, int w) { fixedBlk(BOUNCE, left, bottom, w, 4); }

    void pig(int cx, int bottom) { bodies.add(mkPig(0, 0, cx, bottom)); }

    void helm(int cx, int bottom) { bodies.add(mkPig(1, 0, cx, bottom)); }

    void boss(int var, int cx, int bottom) { bodies.add(mkPig(2, var, cx, bottom)); }

    // ------------------------------------------------------------------ input

    private void pocket(int mxv, int myv) {
        float dx = mxv - AX, dy = myv - AY, len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len > MAXD) { dx *= MAXD / len; dy *= MAXD / len; }
        px = AX + dx;
        py = Math.min(AY + dy, GY - 5F);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (state == S_MENU) return menuClick(x, y);
        if (over) return false;
        if (in(x, y, 3, 3, pillW, 11) && state != S_DRAG) { openMenu(); beep(); return true; }         // the level pill is the way back to the menu
        if (in(x, y, W - 66, 2, 12, 11)) { startHint(); return true; }                              // the light bulb
        if (state == S_READY && cur >= 0 && hop <= 0) {
            state = S_DRAG;
            pocket(x, y);
            snd(SoundEvents.CROSSBOW_SHOOT, 0.6F, 0.25F);
            return true;
        }
        if (state == S_FLY) { ability(); return true; }
        return false;
    }

    @Override
    public boolean release(int x, int y, int button) {
        if (state != S_DRAG) return false;
        pocket(x, y);
        if (AX - px >= 4F) fire(); else { state = S_READY; px = AX; py = AY; }
        return true;
    }

    @Override
    public boolean key(int keyCode) {
        if (state == S_MENU) {
            if (keyCode == KEY_LEFT) { menuWorld = (menuWorld + 3) % 4; world = menuWorld; return true; }
            if (keyCode == KEY_RIGHT) { menuWorld = (menuWorld + 1) % 4; world = menuWorld; return true; }
            if (keyCode == KEY_SPACE || keyCode == 257) { startRun(firstOpen()); return true; }
            return false;
        }
        if (keyCode == KEY_SPACE && state == S_FLY) { ability(); return true; }
        if (keyCode == 72 && !over) { startHint(); return true; }              // H: a hint
        if (keyCode == 77 && !over) { openMenu(); return true; }               // M: the menu
        return false;
    }

    private void fire() {
        Body b = new Body(K_BIRD);
        b.type = cur; b.r = B_R[cur]; b.rad = b.r; b.x = px; b.y = py;
        b.vx = (AX - px) * VMAX / MAXD; b.vy = (AY - py) * VMAX / MAXD;
        b.mass = B_M[cur]; b.inv = 1F / b.mass;
        bodies.add(b);
        lead = b;
        cur = -1;
        state = S_FLY; flyT = 0; calm = 0; winT = 0; idleT = 0;
        hintStage = 0; hintBase = null;
        snd(SoundEvents.CROSSBOW_SHOOT, 1.2F, 0.7F);
        snd(SoundEvents.PARROT_AMBIENT, LAUNCH_PITCH[b.type], 0.4F);
    }

    private void ability() {
        Body b = lead;
        if (b == null || b.dead || b.used) return;
        b.used = true;
        switch (b.type) {
            case BLUE -> {
                for (int s = -1; s <= 1; s += 2) {
                    Body c = new Body(K_BIRD);
                    c.type = BLUE; c.r = 3.5F; c.rad = c.r; c.child = true; c.used = true;
                    c.x = b.x; c.y = b.y + s * 2F;
                    float a = s * 0.26F, ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                    c.vx = b.vx * ca - b.vy * sa; c.vy = b.vx * sa + b.vy * ca;
                    c.mass = 1.4F; c.inv = 1F / c.mass; c.hit = b.hit;
                    bodies.add(c);
                }
                puff(b.x, b.y, 0xFFBFE0FF, 6);
                snd(SoundEvents.PARROT_AMBIENT, 1.9F, 0.5F);
            }
            case YELLOW -> {
                b.vx *= 1.8F; b.vy *= 1.8F;
                puff(b.x, b.y, 0xFFFFF2A0, 6);
                snd(SoundEvents.FIREWORK_ROCKET_BLAST, 1.6F, 0.5F);
            }
            case BLACK -> boom(b.x, b.y, b, 28F, 13F);
            case WHITE -> {                                 // an egg bomb drops, the bird hops up and on
                Body e = new Body(K_BIRD);
                e.type = EGG; e.r = B_R[EGG]; e.rad = e.r; e.child = true; e.used = true;
                e.x = b.x; e.y = b.y + 5F; e.vx = b.vx * 0.3F; e.vy = 2.4F;
                e.mass = B_M[EGG]; e.inv = 1F / e.mass;
                bodies.add(e);
                b.vy = -2.2F; b.vx *= 1.25F;
                puff(b.x, b.y, 0xFFFFFFFF, 5);
                snd(SoundEvents.PARROT_AMBIENT, 1.2F, 0.5F);
            }
            case HEAVY -> {                                 // slams down
                b.vy = Math.max(b.vy, 0F) + 4.8F; b.vx *= 0.35F;
                puff(b.x, b.y, 0xFFE0C0A0, 6);
                snd(SoundEvents.SLIME_SQUISH, 0.6F, 0.6F);
            }
            case BOOM -> {                                  // the boomerang turns back
                b.vx = -b.vx * 0.9F; b.vy = b.vy * 0.4F - 0.4F; b.hit = 0;
                puff(b.x, b.y, 0xFFFFC080, 6);
                snd(SoundEvents.PARROT_AMBIENT, 1.7F, 0.5F);
            }
            case MAGNET -> {                                // pulls everything near it for three quarters of a second
                b.fxT = 45;
                Fx r = new Fx();
                r.kind = 5; r.x = b.x; r.y = b.y; r.rad = 38F; r.life = r.max = 20;
                addFx(r);
                snd(SoundEvents.PLAYER_LEVELUP, 0.5F, 0.5F);
            }
            default -> snd(SoundEvents.PARROT_AMBIENT, 1.3F, 0.4F);
        }
    }

    /** A blast: pushes and hurts everything near, more the nearer it is. */
    private void boom(float x, float y, Body self, float rad, float dmg) {
        for (int i = 0, n = bodies.size(); i < n; i++) {
            Body b = bodies.get(i);
            if (b.dead || b == self || b.kind == K_BIRD || b.fixed) continue;
            float dx = b.x - x, dy = b.y - y, d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d >= rad) continue;
            float f = 1F - d / rad;
            if (d < 0.01F) { dx = 0; dy = -1; d = 1; }
            float dv = 5.5F * f / (float) Math.sqrt(b.mass);
            b.vx += dx / d * dv;
            b.vy += dy / d * dv - 0.5F * f;
            hurt(b, dmg * f);
        }
        if (self != null) self.dead = true;
        Fx r = new Fx();
        r.kind = 2; r.x = x; r.y = y; r.rad = rad; r.life = r.max = 16;
        addFx(r);
        shake(rad > 20F ? 12 : 6, rad > 20F ? 2 : 1);
        puff(x, y, 0xFFFFB347, rad > 20F ? 12 : 6);
        snd(SoundEvents.GENERIC_EXPLODE, rad > 20F ? 1.1F : 1.6F, rad > 20F ? 0.8F : 0.5F);
    }

    // ------------------------------------------------------------------ physics

    @Override
    public void tick() {
        time++;
        if (state == S_MENU) return;
        if (hintStage == 1) tickHint();
        if (bannerT > 0) bannerT--;
        if (sfxCool > 0) sfxCool--;
        if (hop > 0) hop--;
        if (shakeT > 0) shakeT--;
        if (flashT > 0) flashT--;
        if (state == S_DRAG) pocket(mx, my);
        if (slowT > 0 && (slowT-- & 1) == 0) { /* slow motion: this tick the world waits */ } else stepWorld();
        tickFx();
        if (!sim && state == S_FLY && lead != null && !lead.dead && (time & 3) == 0) {   // a trail behind the bird
            Fx f = new Fx();
            f.kind = 4; f.x = lead.x; f.y = lead.y; f.life = f.max = 24;
            addFx(f);
        }
        if (state <= S_FLY) {                                // the last piggy is gone, whatever the birds are doing
            if (pigCount == 0) {
                if (winT == 0 && !sim) { slowT = 70; shake(8, 1); }
                if (++winT > 45) win();
            } else winT = 0;
        }
        switch (state) {
            case S_FLY -> {
                flyT++;
                boolean birds = false;
                for (int i = 0, n = bodies.size(); i < n; i++) { Body b = bodies.get(i); if (b.kind == K_BIRD && !b.dead) { birds = true; break; } }
                idleT = birds ? 0 : idleT + 1;
                if (pigCount > 0 && ((!birds && (calm > 40 || idleT > 150)) || flyT > 1500)) afterShot();
            }
            case S_CLEAR -> {
                clearT++;
                for (int i = 0; i < stars; i++) if (clearT == 25 + 18 * i && !sim) pling(0.8F + 0.25F * i);
                if (--stateT <= 0) {
                    if (level + 1 >= LEVELS) { score += lives * 50; won = true; over = true; }
                    else startLevel(level + 1);
                }
            }
            case S_FAIL -> {
                if (--stateT <= 0) {
                    if (lives <= 0) { won = false; over = true; }
                    else startLevel(level);
                }
            }
            default -> { }
        }
    }

    private void afterShot() {
        if (qi < queue.length) { loadNext(); return; }
        lives--;
        failsHere++;
        score = scoreBase;
        state = S_FAIL; stateT = 110;
        snd(SoundEvents.PIG_HURT, 0.7F, 0.8F);
    }

    private void win() {
        int bonus = birdsLeft() * 20;
        int spare = Math.max(0, birdsLeft() - extra);        // the mercy birds do not count for the stars
        stars = spare >= 2 ? 3 : spare == 1 ? 2 : 1;
        if (hinted) stars = Math.min(stars, 2);               // a hint costs the third star
        clearT = 0;
        if (!sim) {                                           // saved: the stars of a level, the next one opens
            String k = starKey(level);
            if (stars > Progress.count(k)) Progress.setCount(k, stars);
            Progress.save();
            refreshStars();
            totalStars = sumStars();
        }
        if (level % 8 == 7) {                                // a boss is down: a bonus and a heart back
            bonus += 500;
            lives = Math.min(LIVES, lives + 1);
        }
        score += bonus;
        state = S_CLEAR; stateT = level % 8 == 7 ? 190 : 150;
        if (bonus > 0) pts(W / 2F, 66, bonus);
        snd(SoundEvents.PLAYER_LEVELUP, 1.1F, 0.8F);
    }

    private void stepWorld() {
        for (int s = 0; s < SUB; s++) substep();
        float maxV = 0;
        for (int i = 0, n = bodies.size(); i < n; i++) {
            Body b = bodies.get(i);
            if (b.dead) continue;
            float v = Math.abs(b.vx) + Math.abs(b.vy);
            if (b.kind == K_BIRD) {
                b.age++;
                if (b.fxT > 0) { b.fxT--; if (!sim && (b.fxT & 7) == 0) puff(b.x, b.y, 0xFFC8A0FF, 2); }
                if (b.hit > 0) b.hit++;
                b.still = v < 0.12F ? b.still + 1 : 0;
                if (b.type == EGG) {
                    if (b.hit > 0) { boom(b.x, b.y, b, 18F, 9F); continue; }
                } else if (b.type == BLACK && !b.used && b.hit > 70) { b.used = true; boom(b.x, b.y, b, 28F, 13F); continue; }
                if (b.x < -20 || b.x > W + 25 || b.y < -90 || b.y > H + 20 || b.still > 35 || b.hit > 240 || b.age > 700) {
                    b.dead = true;
                    puff(b.x, Math.min(b.y, GY - 2F), B_COL[b.type], 4);
                }
            } else {
                maxV = Math.max(maxV, v);
                if (b.kind == K_PIG && b.type == 2 && b.var >= 2 && (b.var == 3 || b.used) && --b.fxT <= 0 && b.y + b.r >= GY - 0.8F) {   // the big bosses hop and shake the fort
                    b.fxT = b.var == 3 ? 110 : 170;
                    b.vy = b.var == 3 ? -1.9F : -1.8F;
                    shake(6, 1);
                    snd(SoundEvents.SLIME_SQUISH, 0.5F, 0.8F);
                }
                if (b.x > W + 20 || b.x < -30 || b.y > H + 30) kill(b);
            }
        }
        calm = maxV < 0.12F ? calm + 1 : 0;
        if (!pending.isEmpty()) { bodies.addAll(pending); pending.clear(); }
        int w = 0;                                           // drop the dead ones
        for (int i = 0, n = bodies.size(); i < n; i++) { Body b = bodies.get(i); if (!b.dead) bodies.set(w++, b); }
        for (int i = bodies.size() - 1; i >= w; i--) bodies.remove(i);
        pigCount = countPigs();
    }

    private void substep() {
        int n = bodies.size();
        for (int i = 0; i < n; i++) {
            Body b = bodies.get(i);
            if (b.dead) continue;
            if (b.fixed) { b.supL = -1e9F; b.supR = 1e9F; continue; }
            b.supL = Float.MAX_VALUE; b.supR = -Float.MAX_VALUE;
            b.vy += G * DT;
            if (b.kind == K_BIRD && wind != 0F) b.vx += wind * DT;
            b.x += b.vx * DT;
            b.y += b.vy * DT;
            if (b.kind != K_BIRD) {                          // invisible walls: nothing is blown out of the picture
                float half = b.kind == K_BLOCK ? b.w / 2F : b.r;
                if (b.x > W - 1 - half) { b.x = W - 1 - half; if (b.vx > 0) b.vx *= -0.2F; }
                else if (b.x < 44 + half) { b.x = 44 + half; if (b.vx < 0) b.vx *= -0.2F; }
            }
            float bottom = b.kind == K_BLOCK ? b.y + b.h / 2F : b.y + b.r;
            if (bottom > GY) {
                b.y -= bottom - GY;
                float vn = b.vy;
                if (vn > 0) {
                    if (b.kind == K_BIRD) { if (vn > 0.3F && b.hit == 0) b.hit = 1; }
                    else if (vn > 1.1F && !(b.kind == K_PIG && b.type == 2)) hurt(b, (vn - 1.1F) * 2F);   // a boss does not hurt himself by landing
                    float e = vn > 1.2F ? (b.kind == K_BIRD ? 0.3F : 0.12F) : 0F;
                    b.vy = -vn * e;
                    if (vn > 1.6F && b.kind != K_BLOCK) snd(SoundEvents.SLIME_SQUISH, 1.3F, 0.15F);
                }
                b.vx *= b.kind == K_BLOCK ? 0.9F : (b.kind == K_BIRD ? 0.97F : 0.96F);
                b.supL = -1e9F; b.supR = 1e9F;
            }
        }
        for (int i = 0; i < n; i++) {                        // a magnet bird pulls everything near it
            Body m = bodies.get(i);
            if (m.dead || m.kind != K_BIRD || m.fxT <= 0) continue;
            for (int j = 0; j < n; j++) {
                Body b = bodies.get(j);
                if (b.dead || b.kind == K_BIRD || b.fixed) continue;
                float dx = m.x - b.x, dy = m.y - b.y, d2 = dx * dx + dy * dy;
                if (d2 > 1444F || d2 < 1F) continue;
                float d = (float) Math.sqrt(d2), f = 1F - d / 38F;
                b.vx += dx / d * 0.13F * f * DT;
                b.vy += dy / d * 0.13F * f * DT;
            }
        }
        for (int i = 0; i < n; i++) {
            Body a = bodies.get(i);
            if (a.dead) continue;
            for (int j = i + 1; j < n; j++) {
                Body b = bodies.get(j);
                if (b.dead || a.dead || (a.fixed && b.fixed)) continue;
                float dx = b.x - a.x, dy = b.y - a.y, reach = a.rad + b.rad;
                if (dx * dx + dy * dy > reach * reach) continue;     // too far apart to touch
                collide(a, b);
            }
        }
        for (int i = 0; i < n; i++) {                        // held only by a ledge: the box slides off it and falls
            Body b = bodies.get(i);
            if (b.dead || b.kind != K_BLOCK || b.supR < b.supL) continue;
            if (b.x < b.supL - 0.5F) b.vx -= 0.03F;
            else if (b.x > b.supR + 0.5F) b.vx += 0.03F;
        }
    }

    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : Math.min(v, hi); }

    private void collide(Body a, Body b) {
        if (a.kind == K_BIRD && b.kind == K_BIRD) return;
        boolean ac = a.kind != K_BLOCK, bc = b.kind != K_BLOCK;
        float nx, ny, pen;
        if (!ac && !bc) {
            float ox = (a.w + b.w) / 2F - Math.abs(b.x - a.x), oy = (a.h + b.h) / 2F - Math.abs(b.y - a.y);
            if (ox <= 0 || oy <= 0) return;
            if (ox < oy) { nx = b.x > a.x ? 1 : -1; ny = 0; pen = ox; }
            else { nx = 0; ny = b.y > a.y ? 1 : -1; pen = oy; }
        } else if (ac && bc) {
            float dx = b.x - a.x, dy = b.y - a.y, d2 = dx * dx + dy * dy, rr = a.r + b.r + ((a.kind == K_BIRD) != (b.kind == K_BIRD) ? PIG_REACH : 0F);   // a bird's hit on a piggy counts a little before they touch
            if (d2 >= rr * rr) return;
            float d = (float) Math.sqrt(d2);
            if (d < 1e-4F) { nx = 0; ny = -1; } else { nx = dx / d; ny = dy / d; }
            pen = rr - d;
        } else {
            Body c = ac ? a : b, k = ac ? b : a;
            float hx = k.w / 2F, hy = k.h / 2F;
            float qx = clamp(c.x, k.x - hx, k.x + hx), qy = clamp(c.y, k.y - hy, k.y + hy);
            float dx = c.x - qx, dy = c.y - qy, d2 = dx * dx + dy * dy;
            if (d2 > c.r * c.r) return;
            float cnx, cny, cpen;                       // the normal from the box to the circle
            if (d2 > 1e-6F) {
                float d = (float) Math.sqrt(d2);
                cnx = dx / d; cny = dy / d; cpen = c.r - d;
            } else {                                    // the centre is inside the box: out along the shortest way
                float ox = hx - Math.abs(c.x - k.x), oy = hy - Math.abs(c.y - k.y);
                if (ox < oy) { cnx = c.x > k.x ? 1 : -1; cny = 0; cpen = ox + c.r; }
                else { cnx = 0; cny = c.y > k.y ? 1 : -1; cpen = oy + c.r; }
            }
            if (ac) { nx = -cnx; ny = -cny; } else { nx = cnx; ny = cny; }
            pen = cpen;
        }
        resolve(a, b, nx, ny, pen);
    }

    /** n points from a to b. */
    private void resolve(Body a, Body b, float nx, float ny, float pen) {
        float ia = a.inv, ib = b.inv, is = ia + ib;
        float corr = pen / is;
        a.x -= nx * corr * ia; a.y -= ny * corr * ia;
        b.x += nx * corr * ib; b.y += ny * corr * ib;
        float rvx = b.vx - a.vx, rvy = b.vy - a.vy;
        float vn = rvx * nx + rvy * ny;
        if (ny != 0) {                                   // note what holds the upper one of the two
            Body top = ny > 0 ? a : b, bot = ny > 0 ? b : a;
            if (top.kind == K_BLOCK) {
                float half = bot.kind == K_BLOCK ? bot.w / 2F : bot.r;
                top.supL = Math.min(top.supL, bot.x - half);
                top.supR = Math.max(top.supR, bot.x + half);
            }
        }
        if (vn >= 0) return;
        float impact = -vn;
        boolean spring = (a.kind == K_BLOCK && a.type == BOUNCE) || (b.kind == K_BLOCK && b.type == BOUNCE);
        float e = spring ? (impact > 0.4F ? 0.9F : 0F) : impact > 1.4F ? 0.22F : 0F;
        float j = -(1F + e) * vn / is;
        a.vx -= j * ia * nx; a.vy -= j * ia * ny;
        b.vx += j * ib * nx; b.vy += j * ib * ny;
        if (spring && impact > 0.4F) {                    // a trampoline also kicks a bird a little forward, so it never bounces on the spot for ever
            if (a.kind == K_BIRD) a.vx += 0.15F;
            else if (b.kind == K_BIRD) b.vx += 0.15F;
        }
        float tx = rvx - vn * nx, ty = rvy - vn * ny, tl = (float) Math.sqrt(tx * tx + ty * ty);
        if (tl > 1e-5F) {
            tx /= tl; ty /= tl;
            float jt = Math.min(tl / is, 0.4F * j);
            a.vx += jt * ia * tx; a.vy += jt * ia * ty;
            b.vx -= jt * ib * tx; b.vy -= jt * ib * ty;
        }
        if (a.kind == K_BIRD && a.hit == 0 && !spring) a.hit = 1;
        if (b.kind == K_BIRD && b.hit == 0 && !spring) b.hit = 1;
        if (impact > 2.5F && ((a.kind == K_BIRD && a.type == HEAVY) || (b.kind == K_BIRD && b.type == HEAVY))) shake(8, 2);
        if (impact > TH && !spring) {
            float sum = a.mass + b.mass, k = 2.4F * (impact - TH);
            hurt(a, k * b.mass / sum * punch(b, a));
            hurt(b, k * a.mass / sum * punch(a, b));
        }
    }

    /** How hard the attacker hits: the heavy bird is strong, and much stronger against stone. */
    private static float punch(Body att, Body target) {
        if (att.kind != K_BIRD) return 1F;
        float m = B_DMG[att.type];
        if (att.type == HEAVY && target.kind == K_BLOCK && target.type == STONE) m *= 2.5F;
        return m;
    }

    private void hurt(Body b, float d) {
        if (b.kind == K_BIRD || b.dead || b.fixed || d <= 0) return;
        float f = b.kind == K_PIG ? PIG_FRAG[b.type] : M_FRAG[b.type];
        b.hp -= d * f;
        if (b.hp <= 0) kill(b);
        else {
            if (b.kind == K_PIG && b.type == 2 && !b.used && b.hp <= b.maxHp * 0.5F) rage(b);
            if (d * f > 0.6F) hitSound(b);
        }
    }

    /** The boss, half beaten, loses his temper and calls for help (once). */
    private void rage(Body b) {
        b.used = true;
        b.fxT = 60;
        switch (b.var) {
            case 0 -> {                                     // the King: two piggies
                Body l = mkPig(0, 0, b.x - 15F, b.y - 8F), r = mkPig(0, 0, b.x + 15F, b.y - 8F);
                l.vx = -0.9F; l.vy = -1.2F; r.vx = 0.9F; r.vy = -1.2F;
                pending.add(l); pending.add(r);
            }
            case 1 -> {                                     // the Queen: a wall of ice falls in front of her
                pending.add(mkBlock(ICE, b.x - 21F, b.y - 30F, 6, 16));
                pending.add(mkBlock(ICE, b.x - 21F, b.y - 50F, 6, 16));
            }
            case 3 -> {                                     // the Mega Pig: two guards in helmets
                Body l = mkPig(1, 0, b.x - 16F, b.y - 8F), r = mkPig(1, 0, b.x + 16F, b.y - 8F);
                l.vx = -0.9F; l.vy = -1.2F; r.vx = 0.9F; r.vy = -1.2F;
                pending.add(l); pending.add(r);
            }
            default -> {                                    // the Overlord: two guards in helmets and a crate of TNT
                Body l = mkPig(1, 0, b.x - 16F, b.y - 8F), r = mkPig(1, 0, b.x + 16F, b.y - 8F);
                l.vx = -0.9F; l.vy = -1.2F; r.vx = 0.9F; r.vy = -1.2F;
                pending.add(l); pending.add(r);
                pending.add(mkBlock(TNT, b.x - 4F, b.y - 26F, 8, 8));
            }
        }
        Fx f = new Fx();
        f.kind = 3; f.x = b.x; f.y = b.y - 16F; f.vy = -0.2F; f.life = f.max = 70; f.txt = "!!";
        addFx(f);
        puff(b.x, b.y, 0xFFFF8A6A, 10);
        snd(SoundEvents.PIG_HURT, 0.5F, 1F);
        snd(SoundEvents.WARDEN_ROAR, 0.8F, 0.6F);
    }

    private void hitSound(Body b) {
        if (sfxCool > 0) return;
        sfxCool = 5;
        if (b.kind == K_PIG) snd(SoundEvents.PIG_HURT, b.type == 2 ? 0.7F : 1.5F, 0.5F);
        else if (b.type == WOOD || b.type == TNT) snd(SoundEvents.WOOD_HIT, 1F, 0.8F);
        else if (b.type == ICE) snd(SoundEvents.GLASS_BREAK, 1.8F, 0.3F);
        else snd(SoundEvents.STONE_HIT, 0.9F, 0.8F);
    }

    private void kill(Body b) {
        if (b.dead) return;
        b.dead = true;
        if (b.kind == K_PIG) {
            combo = time - lastKill < 90 ? combo + 1 : 1;     // piggies popped one after another are worth more
            lastKill = time;
            int p = (b.type == 2 ? 300 : b.type == 1 ? 80 : 50) + (combo - 1) * 25;
            score += p;
            pts(b.x, b.y - 6, p, combo);
            if (b.type == 2 && !sim) { slowT = Math.max(slowT, 90); flashT = 10; shake(20, 3); }
            puff(b.x, b.y, b.type == 2 ? BOSS_COL[b.var] : 0xFFB5F08A, b.type == 2 ? 18 : 8);
            snd(SoundEvents.PIG_DEATH, b.type == 2 ? 0.6F : 1.5F, 0.7F);
        } else {
            int p = b.type == WOOD ? 10 : b.type == ICE ? 8 : b.type == STONE ? 20 : 5;
            score += p;
            pts(b.x, b.y - 4, p, 1);
            chips(b);
            if (b.type == TNT) boom(b.x, b.y, b, 26F, 11F);
            else if (b.type == WOOD) snd(SoundEvents.WOOD_BREAK, 1F, 0.8F);
            else if (b.type == ICE) snd(SoundEvents.GLASS_BREAK, 1.2F, 0.7F);
            else snd(SoundEvents.STONE_BREAK, 0.9F, 0.8F);
        }
    }

    // ------------------------------------------------------------------ effects

    private void snd(net.minecraft.sounds.SoundEvent e, float pitch, float vol) { if (!sim) sound(e, pitch, vol); }

    private void snd(net.minecraft.core.Holder<net.minecraft.sounds.SoundEvent> h, float pitch, float vol) { if (!sim) sound(h, pitch, vol); }

    private void shake(int ticks, int mag) { if (!sim && ticks > shakeT) { shakeT = ticks; shakeMag = mag; } }

    private void addFx(Fx f) { if (!sim && fx.size() < 160) fx.add(f); }

    private void pts(float x, float y, int v) { pts(x, y, v, 1); }

    private void pts(float x, float y, int v, int cmb) {
        Fx f = new Fx();
        f.kind = 3; f.x = x; f.y = y; f.vy = -0.35F; f.life = f.max = 50;
        f.txt = cmb > 1 ? "+" + v + " x" + cmb : "+" + v;
        addFx(f);
    }

    private void puff(float x, float y, int col, int n) {
        if (sim) return;
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.kind = 1; f.x = x; f.y = y; f.col = col;
            f.vx = (rnd.nextFloat() - 0.5F) * 2.4F; f.vy = (rnd.nextFloat() - 0.7F) * 2.2F;
            f.life = f.max = 16 + rnd.nextInt(10);
            addFx(f);
        }
    }

    private void chips(Body b) {
        if (sim) return;
        int n = Math.min(14, Math.max(4, (int) (b.w * b.h / 30F)));
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.kind = 0; f.col = M_COL[b.type];
            f.x = b.x + (rnd.nextFloat() - 0.5F) * b.w; f.y = b.y + (rnd.nextFloat() - 0.5F) * b.h;
            f.vx = (rnd.nextFloat() - 0.5F) * 2.6F; f.vy = -rnd.nextFloat() * 2F;
            f.life = f.max = 30 + rnd.nextInt(20);
            addFx(f);
        }
    }

    private void tickFx() {
        int w = 0;
        for (int i = 0, n = fx.size(); i < n; i++) {
            Fx f = fx.get(i);
            f.life--;
            f.x += f.vx; f.y += f.vy;
            if (f.kind == 0) f.vy += 0.1F;
            else if (f.kind == 1) { f.vx *= 0.94F; f.vy *= 0.94F; }
            if (f.life > 0) fx.set(w++, f);
        }
        for (int i = fx.size() - 1; i >= w; i--) fx.remove(i);
    }

    // ------------------------------------------------------------------ drawing

    private static void hill(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= 0; dy += 2) {                // only the upper half: the rest is under the ground
            double k = 1.0 - (dy * dy) / ((ry + 0.5) * (ry + 0.5));
            int dx = (int) Math.floor((rx + 0.5) * Math.sqrt(Math.max(0, k)));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 2, argb);
        }
    }

    private void backdrop(GuiGraphics g) {
        int w = world;
        g.fillGradient(-4, -4, W + 4, GY, SKY_T[w], SKY_B[w]);
        int sy = w == 2 ? 40 : 18;
        disc(g, 190, sy, w == 2 ? 15 : 13, Gfx.alpha(SUN[w], 70));
        disc(g, 190, sy, 10, Gfx.alpha(SUN[w], 130));
        disc(g, 190, sy, 8, SUN[w]);
        for (int i = 0; i < 2; i++) Gfx.cloud(g, (int) ((i * 110 + time * 0.08F) % (W + 50)) - 30, 16 + i * 18, 32 + i * 6, CLOUD[w]);
        hill(g, 60, GY, 70, 24, HILL_A[w]);
        hill(g, 170, GY, 80, 16, HILL_B[w]);
        g.fillGradient(-4, GY, W + 4, H + 4, GR_T[w], GR_B[w]);
        g.fillGradient(-4, GY + 2, W + 4, H + 4, DIRT_T[w], DIRT_B[w]);
        g.fill(-4, GY, W + 4, GY + 3, GR_E[w]);
        if (w == 1) {                                          // snow
            for (int i = 0; i < 16; i++) {
                int x = (int) ((i * 53 + time * (0.25F + (i % 3) * 0.12F)) % W), y = (int) ((i * 29 + time * (0.35F + (i % 4) * 0.1F)) % GY);
                g.fill(x, y, x + 1 + (i & 1), y + 1 + (i & 1), 0xCCFFFFFF);
            }
        } else if (w == 2) {                                   // embers
            for (int i = 0; i < 14; i++) {
                int x = (i * 61 + (int) (Math.sin((time + i * 17) * 0.05) * 6)) % W, y = GY - (int) ((time * (0.3F + (i % 3) * 0.15F) + i * 19) % GY);
                g.fill(x, y, x + 1, y + 1, 0xCCFFA040);
            }
        }
    }

    @Override
    public void render(GuiGraphics g) {
        if (state == S_MENU) { renderMenu(g); return; }
        int sx = 0, sy = 0;
        if (shakeT > 0) { sx = rnd.nextInt(2 * shakeMag + 1) - shakeMag; sy = rnd.nextInt(2 * shakeMag + 1) - shakeMag; }
        g.pose().pushPose();
        g.pose().translate(sx, sy, 0);
        backdrop(g);
        // the birds that wait on the ground
        for (int i = 0; i < queue.length - qi; i++) drawBird(g, (int) AX - 8 - 7 * i, GY - 4, queue[qi + i], 4);
        drawSlingBack(g);
        for (int i = 0, n = bodies.size(); i < n; i++) { Body b = bodies.get(i); if (b.kind == K_BLOCK) drawBlock(g, b); }
        for (int i = 0, n = bodies.size(); i < n; i++) { Body b = bodies.get(i); if (b.kind == K_PIG) drawPig(g, b); }
        for (int i = 0, n = bodies.size(); i < n; i++) { Body b = bodies.get(i); if (b.kind == K_BIRD) drawBird(g, Math.round(b.x), Math.round(b.y), b.type, Math.round(b.r)); }
        float bx = AX, by = AY;
        if (cur >= 0) {
            if (state == S_DRAG) { bx = px; by = py; }
            else if (hop > 0) {
                float t = hop / 24F, hy = (float) Math.sin(t * Math.PI) * 14F;
                bx = AX + (-8F) * t; by = AY + (GY - 4F - AY) * t - hy;
            }
            if (state == S_DRAG) { drawGuide(g); drawBands(g, bx, by, true); } else drawBands(g, AX, AY, false);
            drawBird(g, Math.round(bx), Math.round(by), cur, Math.round(B_R[cur]));
        } else drawBands(g, AX, AY, false);
        drawSlingFront(g);
        if (hintStage == 2 && (state == S_READY || state == S_DRAG)) drawHint(g);

        for (int i = 0, n = fx.size(); i < n; i++) drawFx(g, fx.get(i));
        g.pose().popPose();
        hud(g);
        if (flashT > 0) g.fill(0, 0, W, H, Gfx.alpha(0xFFFFFFFF, flashT * 18));
    }

    private void drawSlingBack(GuiGraphics g) {
        int x = (int) AX;
        g.fill(x - 2, 100, x + 3, GY, 0xFF6B3F1E);
        g.fill(x - 1, 100, x + 1, GY, 0xFF8A5A2E);
        Gfx.line(g, x + 2, 100, x + 4, 92, 0xFF54300F);
        Gfx.line(g, x + 3, 100, x + 5, 92, 0xFF54300F);
    }

    private void drawSlingFront(GuiGraphics g) {
        int x = (int) AX;
        Gfx.line(g, x - 2, 100, x - 4, 92, 0xFF8A5A2E);
        Gfx.line(g, x - 1, 100, x - 3, 92, 0xFFA8713A);
        g.fill(x - 5, 91, x - 2, 93, 0xFF6B3F1E);
    }

    private void drawBands(GuiGraphics g, float bx, float by, boolean stretched) {
        int col = stretched ? 0xFF3A1E0C : 0xFF4A2A14;
        Gfx.line(g, (int) AX - 4, 92, Math.round(bx) - 1, Math.round(by), col);
        Gfx.line(g, (int) AX + 4, 92, Math.round(bx) + 1, Math.round(by), col);
    }

    /** The dotted path of the shot up to where the bird will first hit something; a piggy in the way is lit up. */
    private void drawGuide(GuiGraphics g) {
        float x = px, y = py, vx = (AX - px) * VMAX / MAXD, vy = (AY - py) * VMAX / MAXD, r = cur >= 0 ? B_R[cur] : 4F;
        Body hit = null;
        int n = 0;
        for (int t = 1; t <= 160; t++) {
            vy += G; vx += wind; x += vx; y += vy;
            guideX[n] = x; guideY[n] = y; n++;
            if (y > GY - r || x > W + 30 || y < -120) break;
            for (int i = 0, m = bodies.size(); i < m && hit == null; i++) {
                Body b = bodies.get(i);
                if (b.dead || b.kind == K_BIRD) continue;
                if (b.kind == K_BLOCK) {
                    float qx = clamp(x, b.x - b.w / 2F, b.x + b.w / 2F), qy = clamp(y, b.y - b.h / 2F, b.y + b.h / 2F);
                    if ((x - qx) * (x - qx) + (y - qy) * (y - qy) < r * r) hit = b;
                } else {
                    float rr = r + b.r + PIG_REACH;
                    if ((x - b.x) * (x - b.x) + (y - b.y) * (y - b.y) < rr * rr) hit = b;
                }
            }
            if (hit != null) break;
        }
        boolean onPig = hit != null && hit.kind == K_PIG;
        int dot = onPig ? 0xFFB8FFB8 : 0xFFFFFFFF;
        for (int k = 2; k < n; k += 3) {
            int a = Math.max(150, 255 - k), rx = Math.round(guideX[k]), ry = Math.round(guideY[k]);
            g.fill(rx, ry + 1, rx + 2, ry + 3, Gfx.alpha(0xFF2A5A7A, a / 3));
            g.fill(rx, ry, rx + 2, ry + 2, Gfx.alpha(dot, a));
        }
        int ix = Math.round(guideX[Math.max(0, n - 1)]), iy = Math.round(guideY[Math.max(0, n - 1)]);
        if (onPig) disc(g, Math.round(hit.x), Math.round(hit.y), (int) hit.r + 3, Gfx.alpha(0xFF7AF08A, 110));      // the piggy this shot would hit
        int mc = onPig ? 0xFF7AF08A : 0xFFFFE060;                                                                      // the impact: a little cross
        g.fill(ix - 2, iy, ix + 3, iy + 1, mc);
        g.fill(ix, iy - 2, ix + 1, iy + 3, mc);
    }

    private static void drawBird(GuiGraphics g, int cx, int cy, int type, int r) {
        int col = B_COL[type];
        if (type == EGG) {
            disc(g, cx, cy, r, 0xFFE8D8A8);
            disc(g, cx, cy, Math.max(1, r - 1), col);
            g.fill(cx - 1, cy - 1, cx, cy, 0xFFFFFFFF);
            return;
        }
        Gfx.ball(g, cx, cy, r, col);
        if (r >= 6) {                                                                         // the heavy one
            g.fill(cx - 3, cy - r - 1, cx + 3, cy - r + 1, B_DARK[type]);
            Gfx.ellipse(g, cx, cy + 3, 4, 2, B_LIGHT[type]);
            g.fill(cx - 1, cy - 3, cx + 2, cy, 0xFFFFFFFF);
            g.fill(cx + 3, cy - 3, cx + 6, cy, 0xFFFFFFFF);
            g.fill(cx + 1, cy - 2, cx + 2, cy, 0xFF1A1428);
            g.fill(cx + 4, cy - 2, cx + 5, cy, 0xFF1A1428);
            g.fill(cx - 2, cy - 5, cx + 7, cy - 3, 0xFF3A0E0E);
            g.fill(cx + r, cy, cx + r + 3, cy + 3, 0xFFF5A030);
            return;
        }
        if (type == BLACK) g.fill(cx - 1, cy - r - 2, cx + 1, cy - r, 0xFFE0A030);          // the fuse
        else g.fill(cx - 2, cy - r, cx + 1, cy - r + 1, type == WHITE ? 0xFFE0453A : B_DARK[type]);  // a tuft
        Gfx.ellipse(g, cx, cy + 2, 2, 1, type == WHITE ? 0xFFD8E8F0 : B_LIGHT[type]);        // the belly
        g.fill(cx, cy - 2, cx + 2, cy, 0xFFFFFFFF);
        g.fill(cx + 2, cy - 2, cx + 4, cy, 0xFFFFFFFF);
        g.fill(cx + 1, cy - 1, cx + 2, cy, 0xFF1A1428);
        g.fill(cx + 3, cy - 1, cx + 4, cy, 0xFF1A1428);
        g.fill(cx - 1, cy - 3, cx + 5, cy - 2, type == WHITE ? 0xFF7A7A88 : B_DARK[type]);  // the angry brow
        g.fill(cx + r, cy, cx + r + 2, cy + 2, 0xFFF5A030);                                  // the beak
    }

    private void drawPig(GuiGraphics g, Body b) {
        int cx = Math.round(b.x), cy = Math.round(b.y);
        if (b.type == 2) { drawBoss(g, b, cx, cy); return; }
        float k = b.hp / b.maxHp;
        Gfx.ball(g, cx, cy, 5, 0xFF7ED957);
        g.fill(cx - 4, cy - 6, cx - 2, cy - 4, 0xFF5FB840);
        g.fill(cx + 2, cy - 6, cx + 4, cy - 4, 0xFF5FB840);
        g.fill(cx - 3, cy - 2, cx - 1, cy, 0xFFFFFFFF);
        g.fill(cx + 1, cy - 2, cx + 3, cy, 0xFFFFFFFF);
        g.fill(cx - 2, cy - 1, cx - 1, cy, 0xFF1A1428);
        g.fill(cx + 2, cy - 1, cx + 3, cy, 0xFF1A1428);
        Gfx.ellipse(g, cx, cy + 2, 3, 2, 0xFFA6EC82);
        g.fill(cx - 1, cy + 1, cx, cy + 3, 0xFF3F8A2A);
        g.fill(cx + 1, cy + 1, cx + 2, cy + 3, 0xFF3F8A2A);
        if (b.type == 1) {                                                                  // the helmet
            g.fill(cx - 5, cy - 5, cx + 5, cy - 3, 0xFF8A93A6);
            g.fill(cx - 4, cy - 7, cx + 4, cy - 5, 0xFFB4BDD0);
            g.fill(cx - 1, cy - 8, cx + 1, cy - 7, 0xFFD6DCEA);
        } else {
            if (k < 0.6F) g.fill(cx - 4, cy - 4, cx - 2, cy - 3, 0xFF6A9A4A);              // a bruise
            if (k < 0.3F) g.fill(cx + 1, cy - 5, cx + 4, cy - 4, 0xFFFFFFFF);              // a bandage
        }
    }

    private void drawBoss(GuiGraphics g, Body b, int cx, int cy) {
        int col = BOSS_COL[b.var], dark = Gfx.darker(col, 0.35F);
        boolean rage = b.used;
        Gfx.ball(g, cx, cy, 9, col);
        g.fill(cx - 8, cy - 9, cx - 5, cy - 6, dark);
        g.fill(cx + 5, cy - 9, cx + 8, cy - 6, dark);
        g.fill(cx - 5, cy - 4, cx - 1, cy, 0xFFFFFFFF);
        g.fill(cx + 1, cy - 4, cx + 5, cy, 0xFFFFFFFF);
        int pu = rage ? 0xFFD02020 : 0xFF1A1428;
        g.fill(cx - 3, cy - 3, cx - 1, cy - 1, pu);
        g.fill(cx + 1, cy - 3, cx + 3, cy - 1, pu);
        Gfx.line(g, cx - 6, cy - 6, cx - 1, cy - 4, rage ? 0xFF6A1010 : dark);
        Gfx.line(g, cx + 6, cy - 6, cx + 1, cy - 4, rage ? 0xFF6A1010 : dark);
        Gfx.ellipse(g, cx, cy + 4, 4, 3, Gfx.lighter(col, 0.35F));
        g.fill(cx - 2, cy + 3, cx - 1, cy + 5, dark);
        g.fill(cx + 1, cy + 3, cx + 2, cy + 5, dark);
        g.fill(cx - 5, cy + 6, cx - 4, cy + 9, 0xFFFFFFFF);
        g.fill(cx + 4, cy + 6, cx + 5, cy + 9, 0xFFFFFFFF);
        switch (b.var) {
            case 0 -> {                                                                     // a golden crown
                g.fill(cx - 5, cy - 13, cx + 6, cy - 10, 0xFFFFD040);
                g.fill(cx - 5, cy - 15, cx - 3, cy - 13, 0xFFFFD040);
                g.fill(cx - 1, cy - 16, cx + 1, cy - 13, 0xFFFFD040);
                g.fill(cx + 4, cy - 15, cx + 6, cy - 13, 0xFFFFD040);
                g.fill(cx, cy - 12, cx + 1, cy - 11, 0xFFE0304A);
            }
            case 1 -> {                                                                     // a crown of ice
                g.fill(cx - 5, cy - 13, cx + 6, cy - 10, 0xFFD8F6FF);
                g.fill(cx - 5, cy - 16, cx - 3, cy - 13, 0xFFFFFFFF);
                g.fill(cx - 1, cy - 18, cx + 1, cy - 13, 0xFFFFFFFF);
                g.fill(cx + 4, cy - 16, cx + 6, cy - 13, 0xFFFFFFFF);
            }
            case 3 -> {                                                                     // a golden crown and sunglasses
                g.fill(cx - 5, cy - 13, cx + 6, cy - 10, 0xFFFFD040);
                g.fill(cx - 5, cy - 15, cx - 3, cy - 13, 0xFFFFD040);
                g.fill(cx - 1, cy - 16, cx + 1, cy - 13, 0xFFFFD040);
                g.fill(cx + 4, cy - 15, cx + 6, cy - 13, 0xFFFFD040);
                g.fill(cx - 6, cy - 5, cx + 7, cy - 1, 0xFF101018);
                g.fill(cx - 5, cy - 4, cx - 3, cy - 3, 0xFFFFFFFF);
                g.fill(cx + 2, cy - 4, cx + 4, cy - 3, 0xFFFFFFFF);
            }
            default -> {                                                                    // horns
                g.fill(cx - 8, cy - 13, cx - 6, cy - 8, 0xFF2A1018);
                g.fill(cx - 9, cy - 15, cx - 7, cy - 13, 0xFF2A1018);
                g.fill(cx + 6, cy - 13, cx + 8, cy - 8, 0xFF2A1018);
                g.fill(cx + 7, cy - 15, cx + 9, cy - 13, 0xFF2A1018);
            }
        }
    }

    private void drawBlock(GuiGraphics g, Body b) {
        int x = Math.round(b.x - b.w / 2F), y = Math.round(b.y - b.h / 2F), w = Math.round(b.w), h = Math.round(b.h);
        int col = M_COL[b.type], dark = M_DARK[b.type], light = M_LIGHT[b.type];
        Gfx.bubble(g, x, y, w, h, 1, col);
        if (b.type == WOOD) {
            if (w >= h) for (int i = 4; i < w - 3; i += 6) g.fill(x + i, y + 1, x + i + 1, y + h - 1, dark);
            else for (int j = 4; j < h - 3; j += 6) g.fill(x + 1, y + j, x + w - 1, y + j + 1, dark);
        } else if (b.type == ICE) {
            g.fill(x + 1, y + 1, x + Math.min(w - 1, 4), y + 2, 0xFFFFFFFF);
            if (h > 6) g.fill(x + 1, y + 1, x + 2, y + Math.min(h - 1, 5), 0xFFFFFFFF);
        } else if (b.type == STONE) {
            for (int i = 0; i < 4; i++) g.fill(x + 2 + (i * 5) % Math.max(1, w - 3), y + 2 + (i * 7) % Math.max(1, h - 3), x + 3 + (i * 5) % Math.max(1, w - 3), y + 3 + (i * 7) % Math.max(1, h - 3), light);
        } else if (b.type == BOUNCE) {                                                       // a trampoline
            g.fill(x + 1, y, x + w - 1, y + 1, 0xFFFFC8E4);
            for (int i = 3; i < w - 2; i += 4) g.fill(x + i, y + 1, x + i + 1, y + h, dark);
        } else if (b.type == METAL) {                                                        // steel with rivets
            g.fill(x + 1, y + 1, x + 2, y + 2, light);
            g.fill(x + w - 2, y + 1, x + w - 1, y + 2, light);
            g.fill(x + 1, y + h - 2, x + 2, y + h - 1, dark);
            g.fill(x + w - 2, y + h - 2, x + w - 1, y + h - 1, dark);
            if (h > 6) g.fill(x + w / 2, y + 2, x + w / 2 + 1, y + h - 2, dark);
        } else {                                                                            // a crate of TNT
            g.fill(x + 1, y + h / 2 - 1, x + w - 1, y + h / 2 + 1, 0xFFFFE9C0);
            g.fill(x + w / 2, y - 2, x + w / 2 + 1, y, 0xFF444444);
            if ((time / 6 & 1) == 0) g.fill(x + w / 2, y - 3, x + w / 2 + 1, y - 2, 0xFFFFB030);
        }
        float k = b.hp / b.maxHp;
        if (k < 0.66F) Gfx.line(g, x + 1, y + 1, x + w / 2, y + h - 2, dark);
        if (k < 0.33F) Gfx.line(g, x + w - 2, y + 1, x + w / 2 - 1, y + h / 2, dark);
    }

    private void drawFx(GuiGraphics g, Fx f) {
        int x = Math.round(f.x), y = Math.round(f.y);
        float t = f.life / (float) f.max;
        switch (f.kind) {
            case 0 -> g.fill(x, y, x + 2, y + 2, Gfx.fade(f.col, Math.min(1F, t * 2F)));
            case 1 -> disc(g, x, y, Math.max(1, Math.round(3 * t) + 1), Gfx.fade(f.col, t));
            case 2 -> {
                int rr = Math.round(f.rad * (1F - t));
                disc(g, x, y, rr + 3, Gfx.alpha(0xFFFFB347, Math.round(110 * t)));
                disc(g, x, y, Math.max(1, rr / 2), Gfx.fade(0xFFFFF0B0, t));
            }
            case 4 -> g.fill(x, y, x + 1, y + 1, Gfx.fade(0xFFFFFFFF, t * 0.8F));
            case 5 -> {
                int rr = Math.round(f.rad * t);
                disc(g, x, y, rr, Gfx.alpha(0xFF9A5AD8, Math.round(70 * (1F - t) + 30)));
                disc(g, x, y, Math.max(1, rr - 2), Gfx.alpha(0xFFE8D8FF, 40));
            }
            default -> ctext(g, f.txt, x, y, Gfx.fade(0xFFFFFFFF, Math.min(1F, t * 2F)));
        }
    }

    private void hud(GuiGraphics g) {
        pillW = Math.max(62, tw(lvText) + 18);                                              // the pill is a button: back to the menu
        Gfx.rrect(g, 3, 3, pillW, 11, 3, Gfx.fade(0xFF000000, 0.35F));
        g.fill(6, 6, 11, 7, 0xCCFFFFFF); g.fill(6, 8, 11, 9, 0xCCFFFFFF); g.fill(6, 10, 11, 11, 0xCCFFFFFF);
        text(g, lvText, 14, 5, 0xFFFFFFFF);
        drawBulb(g);
        for (int i = 0; i < LIVES; i++) Gfx.heart(g, W - 11 - i * 9, 5, i < lives ? 0xFFFF6A8E : 0x55FFFFFF);
        if (wind != 0F) {                                                                   // the wind: one chevron per notch
            int n = Math.min(3, Math.max(1, Math.round(Math.abs(wind) / 0.0015F))), dir = wind > 0 ? 1 : -1;
            for (int i = 0; i < n; i++) {
                int x = W / 2 - 6 + i * 5 * dir;
                for (int j = 0; j < 5; j++) g.fill(x + (j < 3 ? j : 4 - j) * dir, 5 + j, x + (j < 3 ? j : 4 - j) * dir + 1, 6 + j, 0xDDFFFFFF);
            }
        }
        if (boss != null && !boss.dead) {                                                   // the boss's health
            int bw = 56, bx = (W - bw) / 2, fill = Math.round(bw * Math.max(0F, boss.hp) / boss.maxHp);
            Gfx.rrect(g, bx - 1, 17, bw + 2, 6, 2, Gfx.fade(0xFF000000, 0.55F));
            g.fill(bx, 18, bx + fill, 22, boss.used ? 0xFFFF5A3A : 0xFF7AE060);
        }
        if (bannerT > 0 && state == S_READY) banner(g, bannerA, lvText, 0, false);
        if (state == S_CLEAR) banner(g, clearText, null, starsShown(), true);
        if (state == S_FAIL) banner(g, failText, null, 0, false);
    }

    private static void banner(GuiGraphics g, String a, String b, int filled, boolean withStars) {
        boolean two = b != null && !a.isEmpty();
        String top = two || b == null ? a : b;
        int w = Math.min(W - 20, Math.max(tw(top), two ? tw(b) : 0) + 24), h = two ? 26 : withStars ? 28 : 16, y = 28;
        Gfx.rrect(g, (W - w) / 2, y, w, h, 5, Gfx.fade(0xFF000000, 0.5F));
        ctext(g, top, W / 2, y + 4, 0xFFFFD866);
        if (two) ctext(g, b, W / 2, y + 15, 0xFFFFFFFF);
        if (withStars) for (int i = 0; i < 3; i++) Gfx.star(g, W / 2 - 12 + i * 12, y + 20, 4, i < filled ? 0xFFFFD040 : 0x66FFFFFF);
    }


    // ------------------------------------------------------------------ the level menu and the saved stars

    private static String starKey(int lv) { return "birds.s" + lv; }

    /** The saved stars of the levels, read once when the menu opens (not on every frame). */
    private final int[] starCache = new int[LEVELS];

    private void refreshStars() { for (int i = 0; i < LEVELS; i++) starCache[i] = Progress.count(starKey(i)); }

    private int starsOf(int lv) { return starCache[lv]; }

    private boolean unlocked(int lv) { return lv == 0 || starCache[lv - 1] > 0; }

    private int sumStars() {
        int n = 0;
        for (int i = 0; i < LEVELS; i++) n += starCache[i];
        return n;
    }

    /** The first level that has not been cleared yet. */
    private int firstOpen() {
        int n = 0;
        while (n + 1 < LEVELS && starsOf(n) > 0) n++;
        return n;
    }

    private void openMenu() {
        state = S_MENU;
        bodies.clear(); pending.clear(); fx.clear();
        score = 0; over = false; won = false; lives = LIVES;
        hintStage = 0; hintBase = null; boss = null; lead = null; wind = 0F; cur = -1;
        refreshStars();
        menuWorld = firstOpen() / 8; world = menuWorld;
        totalStars = sumStars();
        if (worldNames == null) {
            worldNames = new String[4];
            for (int i = 0; i < 4; i++) worldNames[i] = Component.translatable("cutemod.birds.world." + i).getString();
            pickText = Component.translatable("cutemod.birds.pick").getString();
        }
        starsText = Component.translatable("cutemod.birds.stars", totalStars, LEVELS * 3).getString();
    }

    private boolean menuClick(int x, int y) {
        for (int i = 0; i < 4; i++) {
            if (in(x, y, 4 + i * 54, 4, 50, 12)) { menuWorld = i; world = i; beep(); return true; }
        }
        for (int r = 0; r < 2; r++) {
            for (int c = 0; c < 4; c++) {
                if (!in(x, y, 8 + c * 52, 26 + r * 40, 48, 34)) continue;
                int lv = menuWorld * 8 + r * 4 + c;
                if (unlocked(lv)) { beep(); startRun(lv); }
                else snd(SoundEvents.PIG_HURT, 1.6F, 0.4F);
                return true;
            }
        }
        return false;
    }

    private void renderMenu(GuiGraphics g) {
        backdrop(g);
        for (int i = 0; i < 4; i++) {
            int x = 4 + i * 54;
            boolean sel = i == menuWorld;
            Gfx.rrect(g, x, 4, 50, 12, 3, Gfx.fade(sel ? 0xFFFFFFFF : 0xFF000000, sel ? 0.8F : 0.35F));
            ctext(g, worldNames[i], x + 25, 6, sel ? 0xFF3A3A48 : unlocked(i * 8) ? 0xFFFFFFFF : 0x88FFFFFF);
        }
        for (int r = 0; r < 2; r++) {
            for (int c = 0; c < 4; c++) {
                int lv = menuWorld * 8 + r * 4 + c, x = 8 + c * 52, y = 26 + r * 40;
                boolean ok = unlocked(lv), hov = ok && in(mx, my, x, y, 48, 34), boss = lv % 8 == 7;
                Gfx.rrect(g, x, y, 48, 34, 5, Gfx.fade(boss ? 0xFF5A2A2A : 0xFF000000, ok ? 0.55F : 0.7F));
                if (hov) Gfx.rrect(g, x - 1, y - 1, 50, 36, 6, Gfx.fade(0xFFFFFFFF, 0.3F));
                if (ok) {
                    ctext(g, String.valueOf(lv + 1), x + 24, y + 6, boss ? 0xFFFFD866 : 0xFFFFFFFF);
                    int st = starsOf(lv);
                    for (int i = 0; i < 3; i++) Gfx.star(g, x + 12 + i * 12, y + 25, 4, i < st ? 0xFFFFD040 : 0x55FFFFFF);
                    if (boss) {                                                             // a little crown: the boss level
                        g.fill(x + 4, y + 6, x + 11, y + 8, 0xFFFFD040);
                        g.fill(x + 4, y + 4, x + 6, y + 6, 0xFFFFD040);
                        g.fill(x + 7, y + 3, x + 9, y + 6, 0xFFFFD040);
                        g.fill(x + 9, y + 4, x + 11, y + 6, 0xFFFFD040);
                    }
                } else {                                                                    // a padlock
                    int cx = x + 24, cy = y + 15;
                    g.fill(cx - 4, cy, cx + 4, cy + 7, 0xFF9A9AA8);
                    g.fill(cx - 3, cy - 4, cx - 2, cy, 0xFF9A9AA8);
                    g.fill(cx + 2, cy - 4, cx + 3, cy, 0xFF9A9AA8);
                    g.fill(cx - 3, cy - 5, cx + 3, cy - 4, 0xFF9A9AA8);
                    g.fill(cx, cy + 2, cx + 1, cy + 5, 0xFF3A3A48);
                }
            }
        }
        ctext(g, starsText, W / 2, 106, 0xFFFFE060);
        ctext(g, pickText, W / 2, 116, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------------ the hint: the game plays the shots on a copy of the world

    private static int[] abilitiesFor(int type) {
        return type == RED ? new int[]{0} : type == HEAVY ? new int[]{0, 6, 14, 24, 36, 52} : new int[]{0, 8, 16, 26, 38, 52, 70};
    }

    private void startHint() {
        if (sim || state != S_READY || cur < 0 || hop > 0) return;
        hinted = true;
        hintStage = 1; hintIdx = 0;
        hintBase = fork();
        hintAb = abilitiesFor(cur);
        hintTotal = 18 * 6 * hintAb.length;
        hintBestPigs = 99; hintBestHp = 1e9F; hintBestScore = -1;
        hintAng = 40F; hintPow = 0.8F; hintAbil = 0;
        snd(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.2F, 0.4F);
    }

    /** A few shots per tick, so the game does not stop while it thinks (a second or two). */
    private void tickHint() {
        long t0 = System.nanoTime();
        while (hintIdx < hintTotal && System.nanoTime() - t0 < 6_000_000L) {
            int k = hintIdx++, ab = hintAb[k % hintAb.length], rest = k / hintAb.length;
            float ang = 6F + 4F * (rest % 18), pow = 0.5F + 0.1F * (rest / 18);
            BirdSling f = hintBase.fork();
            f.simShot(ang, pow, ab);
            int pigs = f.state == S_CLEAR ? 0 : f.pigCount;
            float hp = pigs == 0 ? 0F : f.pigHp();
            if (pigs < hintBestPigs || (pigs == hintBestPigs && (hp < hintBestHp - 0.01F || (Math.abs(hp - hintBestHp) <= 0.01F && f.score > hintBestScore)))) {
                hintBestPigs = pigs; hintBestHp = hp; hintBestScore = f.score; hintAng = ang; hintPow = pow; hintAbil = ab;
            }
        }
        if (hintIdx >= hintTotal) { hintStage = 2; hintBase = null; snd(SoundEvents.PLAYER_LEVELUP, 1.6F, 0.3F); }
    }

    /** A copy of the world in its present state, for trying a shot out. It makes no sound and no effects. */
    private BirdSling fork() {
        BirdSling f = new BirdSling();
        f.sim = true;
        f.level = level; f.world = world; f.wind = wind; f.lives = lives; f.time = time;
        f.queue = queue; f.qi = qi; f.cur = cur; f.score = score; f.scoreBase = scoreBase;
        f.state = S_READY; f.hop = 0; f.pigCount = pigCount; f.combo = combo; f.lastKill = lastKill; f.winT = winT;
        for (Body b : bodies) {
            Body c = b.copy();
            f.bodies.add(c);
            if (b == boss) f.boss = c;
        }
        return f;
    }

    private void simShot(float ang, float pow, int ab) {
        float len = pow * MAXD, a = (float) Math.toRadians(ang);
        px = AX - len * (float) Math.cos(a);
        py = Math.min(AY + len * (float) Math.sin(a), GY - 5F);
        fire();
        for (int t = 0; state == S_FLY && t < 1200; t++) {
            if (ab > 0 && t == ab) ability();
            tick();
        }
    }

    private float pigHp() {
        float sum = 0;
        for (int i = 0, n = bodies.size(); i < n; i++) { Body b = bodies.get(i); if (b.kind == K_PIG && !b.dead) sum += Math.max(0F, b.hp); }
        return sum;
    }

    private void drawHint(GuiGraphics g) {
        float len = hintPow * MAXD, a = (float) Math.toRadians(hintAng);
        float hx = AX - len * (float) Math.cos(a), hy = Math.min(AY + len * (float) Math.sin(a), GY - 5F);
        boolean near = state == S_DRAG && Math.abs(px - hx) < 2.5F && Math.abs(py - hy) < 2.5F;
        int col = near ? 0xFF7AF08A : 0xFFFFE060;
        disc(g, Math.round(hx), Math.round(hy), 4, Gfx.alpha(col, 120));                 // the ghost of the bird, pulled back
        float x = hx, y = hy, vx = (AX - hx) * VMAX / MAXD, vy = (AY - hy) * VMAX / MAXD;
        for (int t = 1; t <= 90; t++) {
            vy += G; vx += wind; x += vx; y += vy;
            if (y > GY - 2) break;
            int rx = Math.round(x), ry = Math.round(y);
            if (t % 5 == 0) g.fill(rx, ry, rx + 2, ry + 2, Gfx.alpha(col, 230));
            if (hintAbil > 0 && t == hintAbil) Gfx.star(g, rx, ry, 4, 0xFFFFFFFF);          // where to click for the power
        }
        if (hintAbil > 0) ctext(g, hintText, W / 2, GY + 6, 0xFFFFFFFF);
    }

    private void drawBulb(GuiGraphics g) {
        int x = W - 64, y = 4;
        boolean blink = hintStage == 0 && failsHere >= 2 && (time / 15 & 1) == 0;       // after two lost tries the bulb asks to be pressed
        int col = hintStage == 2 ? 0xFFFFE060 : hintStage == 1 ? 0xFFFFC040 : blink ? 0xFFFFE060 : 0x99FFFFFF;
        disc(g, x + 4, y + 3, 3, col);
        g.fill(x + 2, y + 6, x + 7, y + 7, 0xFF9A9AA8);
        g.fill(x + 3, y + 7, x + 6, y + 8, 0xFF7A7A88);
        if (hintStage == 1) { int d = (time / 6) % 3; g.fill(x + 10 + d * 2, y + 4, x + 11 + d * 2, y + 5, 0xFFFFFFFF); }
    }

    private int starsShown() { return clearT < 25 ? 0 : Math.min(stars, 1 + (clearT - 25) / 18); }

    // ------------------------------------------------------------------ misc

    @Override
    public String hintKey() { return "cutemod.hint.birds"; }

    @Override
    public Component status() {
        if (state == S_MENU) return Component.translatable("cutemod.birds.stars", totalStars, LEVELS * 3);
        return Component.translatable("cutemod.ui.score_lives", score, lives);
    }

    @Override
    public String musicId() { return MUSIC[Math.max(0, Math.min(3, world))]; }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return won ? Component.translatable("cutemod.birds.won") : Component.translatable("cutemod.ui.gameover");
    }
}
