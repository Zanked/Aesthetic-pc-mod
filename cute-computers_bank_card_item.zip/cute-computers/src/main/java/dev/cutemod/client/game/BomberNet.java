package dev.cutemod.client.game;

import dev.cutemod.data.BomberSim;
import dev.cutemod.net.BomberActionPayload;
import dev.cutemod.net.BomberLobbyPayload;
import dev.cutemod.net.BomberStatePayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** The client side of online Bombers: what the server last told us (rooms, our room, the running round) and the messages we send. */
public final class BomberNet {
    private BomberNet() {}

    /** The open rooms: the name of the host and how many places are free. */
    public static List<String> hosts = new ArrayList<>();
    public static List<Integer> open = new ArrayList<>();
    public static boolean inRoom, inGame, youHost;
    public static int mySlot, level = 1, map, mode;
    /** 0 empty, 1 open, 2 computer player, 3 person. */
    public static final int[] slotType = new int[4];
    public static final String[] slotName = {"", "", "", ""};
    /** Goes up with every lobby message. */
    public static int version;
    private static int notice;
    private static long ignoreUntil;

    /** The round as the server sent it last (the same class the server runs), and how many times it was sent. */
    public static final BomberSim view = new BomberSim();
    public static int stateVersion, stateSlot = -1;

    public static void apply(BomberLobbyPayload p) {
        hosts = new ArrayList<>(p.hosts());
        open = new ArrayList<>(p.open());
        boolean room = p.inRoom();
        inRoom = System.currentTimeMillis() < ignoreUntil ? false : room;
        inGame = inRoom && p.inGame();
        youHost = p.youHost();
        mySlot = p.mySlot();
        level = p.level();
        map = p.map();
        mode = p.mode();
        for (int i = 0; i < 4; i++) {
            slotType[i] = i < p.slotType().size() ? p.slotType().get(i) : 0;
            slotName[i] = i < p.slotName().size() ? p.slotName().get(i) : "";
        }
        if (p.notice() != 0) notice = p.notice();
        version++;
    }

    public static void applyState(BomberStatePayload p) {
        if (!view.unpack(p.data())) return;
        stateSlot = p.slot();
        stateVersion++;
    }

    public static void clear() {
        hosts = new ArrayList<>();
        open = new ArrayList<>();
        inRoom = inGame = youHost = false;
        notice = 0;
        version++;
    }

    /** The last notice (the room is gone, ...), only once. */
    public static int takeNotice() {
        int n = notice;
        notice = 0;
        return n;
    }

    private static void send(int action, int a, int b, String name) {
        dev.cutemod.client.os.Modem.send(new BomberActionPayload(action, a, b, name));
    }

    public static void request() { send(0, 0, 0, ""); }

    public static void create() { send(1, 0, 0, ""); }

    public static void join(String host) { send(2, 0, 0, host); }

    /** Leave the room (or the round). We forget the room at once, the server confirms later. */
    public static void leave() {
        send(3, 0, 0, "");
        ignoreUntil = System.currentTimeMillis() + 1500;
        inRoom = inGame = false;
        version++;
    }

    public static void slot(int i) { send(4, i, 0, ""); }

    public static void setLevel(int l) { send(5, l, 0, ""); }

    public static void start() { send(6, 0, 0, ""); }

    /** The host picks the mode: 0 classic, 1 teams, 2 deathmatch, 3 chaos, 4 bomb rain. */
    public static void setMode(int m) { send(9, m, 0, ""); }

    /** The host picks the map: 0..5, or 6 for a different one every round. */
    public static void setMap(int m) { send(8, m, 0, ""); }

    /** dir: 0 down, 1 left, 2 right, 3 up, -1 nothing. */
    public static void input(int dir, boolean bomb) { send(7, dir + 1, bomb ? 1 : 0, ""); }
}
