package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Ward 13: a top-down horror in an abandoned hospital. You are a little cat in a patient gown. Find three fuses,
 * put them into the generator, and run to the exit. Night Nurse Agatha walks the corridors: she hears you run,
 * she sees the flashlight, and she checks the lockers. The whole map is dark; only the flashlight, the ceiling
 * lamps (some of them flicker and die) and a small halo around you light it.
 */
public class Ward13 extends MiniGame {
    // ---------- map ----------
    private static final int T = 10, MW = 46, MH = 28;
    private static final int FLOOR = 0, CORR = 1, WALL = 2, DOOR = 3, EXIT = 4;
    private static final int BED = 0, LOCKER = 1, TABLE = 2, SHELF = 3, GURNEY = 4, CHAIR = 5, CRATE = 6, GEN = 7, DESK = 8, BENCH = 9, COUNTER = 10;
    private static final int[] WX = {0, 9, 18, 27, 36, 45};
    private static final int CELL = 4;
    private static final int BASE_AMB = 0xE6, ALARM_AMB = 0xC4;

    private static final class Obj {
        final int type, tx, ty, w, h;
        int variant, open, shake;
        Obj(int type, int tx, int ty, int w, int h) { this.type = type; this.tx = tx; this.ty = ty; this.w = w; this.h = h; }
        double cx() { return tx * T + w * T / 2.0; }
        double cy() { return ty * T + h * T / 2.0; }
    }

    private static final class Item {
        final int kind; final double x, y; final int id; boolean got;
        Item(int kind, double x, double y, int id) { this.kind = kind; this.x = x; this.y = y; this.id = id; }
    }

    private static final class Lamp {
        final double x, y, r; boolean dead; int flick, next;
        Lamp(double x, double y, double r, boolean dead) { this.x = x; this.y = y; this.r = r; this.dead = dead; next = 60; }
    }

    private static final class Decal {
        final double x, y; final int kind, size;
        Decal(double x, double y, int kind, int size) { this.x = x; this.y = y; this.kind = kind; this.size = size; }
    }

    private final int[][] tile = new int[MH][MW];
    private final boolean[][] solid = new boolean[MH][MW];
    private final int[][] roomOf = new int[MH][MW];
    private final Obj[][] objAt = new Obj[MH][MW];
    private final boolean[][] reach = new boolean[MH][MW];
    private final List<Obj> objs = new ArrayList<>();
    private final List<Obj> lockers = new ArrayList<>();
    private final List<Item> items = new ArrayList<>();
    private final List<Lamp> lamps = new ArrayList<>();
    private final List<Decal> decals = new ArrayList<>();
    private final List<int[]> patrol = new ArrayList<>();
    private Obj generator;

    // ---------- state ----------
    private int ticks;
    private boolean win, hidden, flOn, running, moving, exhausted, exitOpen, hunt;
    private double px, py, mfx = 0, mfy = 1, fx = 0, fy = 1, battery, stamina;
    private int aimT, pmx = -1, pmy = -1, hideCd, stepT, flickerT;
    private Obj hideObj;
    private int fuses, slotted, got, notes;
    private String msg = "";
    private int msgT;
    private double camXf, camYf;
    private int camX, camY;
    private int beatT, ambT, alarmT, shakeT;
    private int caughtT, stunT;

    // ---------- the nurse ----------
    private static final int PATROL = 0, INVEST = 1, CHASE = 2, SEARCH = 3, CHECK = 4;
    private double nx, ny, nfx = 1, nfy = 0;
    private int ns, gx, gy, nWait = -1, nTimer, lost, pingT;
    private double lsx, lsy;
    private boolean gDirty;
    private final int[][] gdist = new int[MH][MW];
    private final List<Obj> queue = new ArrayList<>();
    private Obj chk;

    // ======================================================================================================
    // setup
    // ======================================================================================================
    private static int rx(int r) { return WX[r % 5] + 1; }
    private static int ry(int r) { return r < 5 ? 1 : 16; }
    private static int rh(int r) { return r < 5 ? 9 : 11; }

    @Override
    public void reset() {
        score = 0; over = false; win = false; ticks = 0; caughtT = 0; stunT = 0;
        hidden = false; hideObj = null; flOn = false; running = false; moving = false; exhausted = false; exitOpen = false; hunt = false;
        battery = 100; stamina = 360; fuses = 0; slotted = 0; got = 0; notes = 0; msg = ""; msgT = 0;
        aimT = 0; hideCd = 0; flickerT = 0; beatT = 0; ambT = 300; alarmT = 0; shakeT = 0;
        build();
        px = 40 * T + 5; py = 20 * T + 5; mfx = -1; mfy = 0; fx = -1; fy = 0;
        bfsReach((int) (px / T), (int) (py / T));
        placeItems();
        placeDecals();
        // the nurse starts far away, at the other end of the map
        nx = 4 * T + 5; ny = 8 * T + 5; nfx = 1; nfy = 0; ns = PATROL; nWait = -1; lost = 0; pingT = 0; chk = null; queue.clear();
        setGoal(rx(1) + 3, ry(1) + rh(1) - 2); gDirty = true;      // first she looks into the morgue
        camXf = px - W / 2.0; camYf = py - H / 2.0;
        introT = 190;
    }

    private int introT;

    private void build() {
        objs.clear(); lockers.clear(); items.clear(); lamps.clear(); decals.clear(); patrol.clear(); generator = null;
        for (int y = 0; y < MH; y++) for (int x = 0; x < MW; x++) { tile[y][x] = WALL; solid[y][x] = true; roomOf[y][x] = -1; objAt[y][x] = null; }
        for (int r = 0; r < 10; r++)
            for (int y = ry(r); y < ry(r) + rh(r); y++) for (int x = rx(r); x < rx(r) + 8; x++) { tile[y][x] = FLOOR; solid[y][x] = false; roomOf[y][x] = r; }
        for (int y = 11; y <= 14; y++) for (int x = 1; x <= 44; x++) { tile[y][x] = CORR; solid[y][x] = false; }
        for (int i = 0; i < 5; i++) {
            door(rx(i) + 3, 10); door(rx(i) + 4, 10);
            door(rx(i + 5) + 3, 15); door(rx(i + 5) + 4, 15);
        }
        int[][] side = {{9, 4}, {9, 5}, {27, 4}, {27, 5}, {9, 21}, {9, 22}, {27, 21}, {27, 22}, {36, 21}, {36, 22}};
        for (int[] s : side) door(s[0], s[1]);
        tile[12][45] = EXIT; tile[13][45] = EXIT;                    // the locked exit (solid until the power is on)
        furnish();
        // lamps: above the doors in the corridor, and one in every room
        for (int i = 0; i < 5; i++) {
            lamps.add(new Lamp((rx(i) + 4) * T, 13 * T, 42, i == 1 || i == 3 || rnd.nextInt(100) < 20));
        }
        for (int r = 0; r < 10; r++) {
            boolean alive = r == 2 || r == 9 || rnd.nextBoolean();
            if (r == 0) alive = false;
            lamps.add(new Lamp((rx(r) + 4) * T, (ry(r) + rh(r) / 2.0) * T, 34, !alive));
        }
        // where the nurse walks: just inside every door, and three places in the corridor
        for (int r = 0; r < 10; r++) patrol.add(new int[]{rx(r) + 3, r < 5 ? ry(r) + rh(r) - 2 : ry(r) + 1});
        patrol.add(new int[]{3, 12}); patrol.add(new int[]{23, 13}); patrol.add(new int[]{43, 13});
    }

    private void door(int x, int y) { tile[y][x] = DOOR; solid[y][x] = false; }

    private Obj add(int room, int type, int lx, int ly, int w, int h) { return addAbs(type, rx(room) + lx, ry(room) + ly, w, h); }

    private Obj addAbs(int type, int x, int y, int w, int h) {
        Obj o = new Obj(type, x, y, w, h);
        objs.add(o);
        for (int dy = 0; dy < h; dy++) for (int dx = 0; dx < w; dx++) { solid[y + dy][x + dx] = true; objAt[y + dy][x + dx] = o; }
        if (type == LOCKER) lockers.add(o);
        if (type == GEN) generator = o;
        return o;
    }

    private void furnish() {
        // 0 generator room
        add(0, GEN, 3, 0, 2, 1); add(0, CRATE, 0, 0, 1, 2); add(0, CRATE, 6, 6, 2, 2); add(0, LOCKER, 0, 5, 1, 1); add(0, CRATE, 7, 0, 1, 1);
        // 1 morgue
        for (int i = 3; i <= 6; i++) add(1, LOCKER, i, 0, 1, 1);
        add(1, GURNEY, 2, 3, 1, 3).variant = 1; add(1, GURNEY, 6, 3, 1, 3).variant = 1; add(1, LOCKER, 7, 6, 1, 1);
        // 2 operating room
        add(2, GURNEY, 3, 3, 2, 3).variant = 2; add(2, SHELF, 1, 0, 2, 1); add(2, SHELF, 5, 0, 2, 1); add(2, LOCKER, 7, 1, 1, 1); add(2, CHAIR, 0, 6, 1, 1);
        // 3 office
        add(3, DESK, 1, 1, 3, 2); add(3, DESK, 4, 6, 3, 2); add(3, SHELF, 5, 0, 2, 1); add(3, LOCKER, 7, 3, 1, 1);
        // 4 ward A
        add(4, BED, 1, 0, 2, 3); add(4, BED, 5, 0, 2, 3); add(4, BED, 1, 5, 2, 3); add(4, BED, 5, 5, 2, 3); add(4, LOCKER, 7, 3, 1, 1);
        // 5 pharmacy
        add(5, SHELF, 1, 2, 2, 1); add(5, SHELF, 5, 2, 2, 1); add(5, SHELF, 1, 5, 3, 1); add(5, SHELF, 4, 8, 3, 1); add(5, LOCKER, 0, 9, 1, 1);
        // 6 ward 13
        add(6, BED, 1, 1, 2, 3).variant = 2; add(6, BED, 5, 1, 2, 3).variant = 2; add(6, BED, 1, 7, 2, 3).variant = 2; add(6, BED, 5, 7, 2, 3).variant = 1;
        add(6, CHAIR, 3, 5, 1, 1); add(6, LOCKER, 7, 5, 1, 1); add(6, LOCKER, 0, 0, 1, 1);
        // 7 waiting room
        add(7, BENCH, 1, 2, 2, 1); add(7, BENCH, 5, 2, 2, 1); add(7, BENCH, 1, 8, 2, 1); add(7, BENCH, 5, 8, 2, 1); add(7, LOCKER, 0, 0, 1, 1); add(7, LOCKER, 7, 9, 1, 1);
        // 8 kitchen
        add(8, TABLE, 2, 2, 2, 2); add(8, TABLE, 4, 7, 2, 2); add(8, COUNTER, 6, 0, 2, 1); add(8, LOCKER, 0, 9, 1, 1);
        // 9 your room
        add(9, BED, 5, 2, 2, 3); add(9, BED, 5, 7, 2, 3).variant = 1; add(9, TABLE, 1, 8, 2, 1); add(9, LOCKER, 7, 0, 1, 1);
        // the corridor
        addAbs(GURNEY, 16, 14, 3, 1); addAbs(CHAIR, 26, 11, 1, 1); addAbs(CRATE, 35, 14, 1, 1); addAbs(CRATE, 36, 14, 1, 1); addAbs(CRATE, 8, 11, 1, 1);
    }

    private void bfsReach(int sx, int sy) {
        for (boolean[] r : reach) java.util.Arrays.fill(r, false);
        int[] q = new int[MW * MH]; int h = 0, t = 0;
        q[t++] = sy * MW + sx; reach[sy][sx] = true;
        while (h < t) {
            int c = q[h++], cx = c % MW, cy = c / MW;
            int[][] d = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
            for (int[] v : d) {
                int x = cx + v[0], y = cy + v[1];
                if (x < 0 || y < 0 || x >= MW || y >= MH || solid[y][x] || reach[y][x]) continue;
                reach[y][x] = true; q[t++] = y * MW + x;
            }
        }
        reach[12][45] = reach[13][45] = true;
    }

    private int[] freeTile(int room) {
        List<int[]> c = new ArrayList<>();
        for (int y = 0; y < MH; y++) for (int x = 0; x < MW; x++) {
            boolean in = room < 0 ? tile[y][x] == CORR : roomOf[y][x] == room;
            if (!in || solid[y][x] || !reach[y][x]) continue;
            if (Math.abs(x - px / T) < 6 && Math.abs(y - py / T) < 6) continue;
            boolean taken = false;
            for (Item it : items) if ((int) (it.x / T) == x && (int) (it.y / T) == y) taken = true;
            // not in the doorways
            if (!taken && roomOf[y][x] >= 0 && (tile[y + 1][x] == DOOR || tile[y - 1][x] == DOOR)) taken = true;
            if (!taken) c.add(new int[]{x, y});
        }
        if (c.isEmpty()) return new int[]{23, 13};
        return c.get(rnd.nextInt(c.size()));
    }

    private void putItem(int kind, int room, int id) {
        int[] t = freeTile(room);
        items.add(new Item(kind, t[0] * T + 5, t[1] * T + 5, id));
    }

    private void placeItems() {
        List<Integer> pool = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6, 7, 8));
        for (int i = 0; i < 3; i++) putItem(0, pool.remove(rnd.nextInt(pool.size())), i);
        for (int i = 0; i < 5; i++) putItem(1, i == 4 ? -1 : rnd.nextInt(9), i);
        putItem(2, 9, 0); putItem(2, 3, 1); putItem(2, 6, 2); putItem(2, 2, 3);
    }

    private void placeDecals() {
        for (int i = 0; i < 12; i++) { int[] t = freeTile(6); decals.add(new Decal(t[0] * T + 5, t[1] * T + 5, rnd.nextInt(3), 2 + rnd.nextInt(4))); }
        for (int i = 0; i < 6; i++) { int[] t = freeTile(2); decals.add(new Decal(t[0] * T + 5, t[1] * T + 5, rnd.nextInt(3), 2 + rnd.nextInt(3))); }
        for (int i = 0; i < 5; i++) { int[] t = freeTile(1); decals.add(new Decal(t[0] * T + 5, t[1] * T + 5, rnd.nextInt(3), 2 + rnd.nextInt(3))); }
        // a trail of drops from ward 13 into the corridor
        double x = 14 * T, y = 12 * T;
        for (int i = 0; i < 16; i++) { x += 6 + rnd.nextInt(8); y += rnd.nextInt(5) - 2; decals.add(new Decal(x, Math.max(11 * T + 3, Math.min(14 * T + 6, y)), 0, 1 + rnd.nextInt(2))); }
        for (int i = 0; i < 7; i++) { int[] t = freeTile(-1); decals.add(new Decal(t[0] * T + 5, t[1] * T + 5, rnd.nextInt(3), 1 + rnd.nextInt(3))); }
    }

    // ======================================================================================================
    // input
    // ======================================================================================================
    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    @Override
    public boolean key(int k) {
        if (over) return false;
        if (k == 69) { interact(); return true; }                                   // E
        if (k == 70 || k == KEY_SPACE) { toggleLight(); return true; }              // F / space
        return false;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        if (button == 0) { toggleLight(); return true; }
        return false;
    }

    private void toggleLight() {
        if (hidden) return;
        if (!flOn && battery <= 0) { snd(SoundEvents.STONE_BUTTON_CLICK_OFF, 0.7F, 0.4F); say(tr("cutemod.ward.dead"), 90); return; }
        flOn = !flOn;
        sound(SoundEvents.STONE_BUTTON_CLICK_ON, flOn ? 1.5F : 1.2F, 0.5F);
    }

    private void interact() {
        if (hidden) { leaveLocker(); return; }
        if (hideCd > 0) return;
        // the generator
        if (generator != null && Math.hypot(px - generator.cx(), py - (generator.cy() + 8)) < 17 && !exitOpen) {
            if (fuses > 0) {
                slotted += fuses; fuses = 0;
                sound(SoundEvents.STONE_BUTTON_CLICK_ON, 0.6F, 0.8F); sound(SoundEvents.NOTE_BLOCK_BASS.value(), 0.7F, 0.7F);
                if (slotted >= 3) powerOn(); else say(tr("cutemod.ward.slot", slotted), 150);
            } else {
                say(tr("cutemod.ward.nofuse"), 110);
                sound(SoundEvents.VILLAGER_NO, 0.7F, 0.5F);
            }
            return;
        }
        // a locker to hide in
        Obj best = null; double bd = 14;
        for (Obj l : lockers) {
            double d = Math.hypot(px - (l.cx()), py - (l.cy() + 4));
            if (d < bd) { bd = d; best = l; }
        }
        if (best != null) {
            if (Math.hypot(nx - px, ny - py) < 12) return;
            hidden = true; hideObj = best; flOn = false;
            px = best.cx(); py = best.cy();
            sound(SoundEvents.WOODEN_DOOR_CLOSE, 0.7F, 0.6F);
            say(tr("cutemod.ward.hide"), 100);
            // she saw you slip in: she goes straight to this locker
            double d = Math.hypot(nx - px, ny - py);
            if (ns == CHASE && d < 100 && los(nx, ny, px, py)) {
                ns = CHECK; chk = best; queue.clear(); setGoal(best.tx, best.ty + 1); nWait = -1;
            }
        }
    }

    private void leaveLocker() {
        if (hideObj == null) { hidden = false; return; }
        px = hideObj.cx(); py = (hideObj.ty + 1) * T + 5;
        hidden = false; hideObj = null; hideCd = 20;
        snd(SoundEvents.WOODEN_DOOR_OPEN, 0.8F, 0.5F);
    }

    private void powerOn() {
        exitOpen = true; hunt = true; alarmT = 1; pingT = 60;
        stunT = ns == CHASE ? 70 : 170;                      // the siren deafens her for a moment: your head start
        solid[12][45] = false; solid[13][45] = false;
        score += 30;
        say(tr("cutemod.ward.power"), 220);
        sound(SoundEvents.BEACON_ACTIVATE, 0.6F, 0.9F);
        growl(G_ROAR);
        for (Lamp l : lamps) l.dead = false;
        // she comes to the noise: the generator. You have a moment to get away from it
        if (ns != CHASE) { ns = INVEST; chk = null; queue.clear(); setGoal(generator.tx + 1, generator.ty + 1); }
    }

    // ======================================================================================================
    // text helpers
    // ======================================================================================================
    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    /** A sound given either as a SoundEvent or as a Holder of one (the vanilla constants are a mix of both). */
    private static void snd(Object o, float pitch, float vol) {
        net.minecraft.sounds.SoundEvent e = o instanceof net.minecraft.core.Holder<?> h ? (net.minecraft.sounds.SoundEvent) h.value() : (net.minecraft.sounds.SoundEvent) o;
        sound(e, pitch, vol);
    }

    private void say(String s, int t) { msg = s; msgT = t; }

    private static void shText(GuiGraphics g, String s, int x, int y, int argb) { text(g, s, x + 1, y + 1, 0xCC000000); text(g, s, x, y, argb); }

    private static List<String> wrap(String s, int maxW) {
        List<String> out = new ArrayList<>();
        String line = "";
        for (String w : s.split(" ")) {
            String t = line.isEmpty() ? w : line + " " + w;
            if (tw(t) > maxW && !line.isEmpty()) { out.add(line); line = w; } else line = t;
        }
        if (!line.isEmpty()) out.add(line);
        return out;
    }

    // ======================================================================================================
    // geometry: collisions, sight, light
    // ======================================================================================================
    private boolean solidAt(double x, double y) {
        int tx = (int) Math.floor(x / T), ty = (int) Math.floor(y / T);
        return tx < 0 || ty < 0 || tx >= MW || ty >= MH || solid[ty][tx];
    }

    private boolean blocked(double x, double y) {
        double r = 3.4;
        return solidAt(x - r, y - r) || solidAt(x + r, y - r) || solidAt(x - r, y + r) || solidAt(x + r, y + r);
    }

    private boolean opaque(int tx, int ty) { return tx < 0 || ty < 0 || tx >= MW || ty >= MH || tile[ty][tx] == WALL; }

    /** True if no wall lies between the two points (the tile of the end point itself may be a wall). */
    private boolean los(double x0, double y0, double x1, double y1) {
        double dx = x1 - x0, dy = y1 - y0, d = Math.hypot(dx, dy);
        int ex = (int) Math.floor(x1 / T), ey = (int) Math.floor(y1 / T);
        int n = (int) (d / 3);
        for (int i = 1; i < n; i++) {
            double k = i * 3.0 / d;
            int tx = (int) Math.floor((x0 + dx * k) / T), ty = (int) Math.floor((y0 + dy * k) / T);
            if (tx == ex && ty == ey) return true;
            if (opaque(tx, ty)) return false;
        }
        return true;
    }

    private boolean lampOn(Lamp l) {
        if (l.dead) return false;
        return !(l.flick > 0 && (l.flick / 3) % 2 == 0);
    }

    // ======================================================================================================
    // tick
    // ======================================================================================================
    @Override
    public void tick() {
        ticks++;
        if (introT > 0) introT--;
        if (msgT > 0) msgT--;
        if (hideCd > 0) hideCd--;
        if (alarmT > 0) alarmT++;
        for (Obj o : objs) { if (o.open > 0) o.open--; if (o.shake > 0) o.shake--; }

        playerTick();
        nurseTick();
        lampsTick();
        sfxTick();
    }

    private void playerTick() {
        boolean l = down(KEY_LEFT) || down(65), r = down(KEY_RIGHT) || down(68), u = down(KEY_UP) || down(87), d = down(KEY_DOWN) || down(83);
        int dx = (r ? 1 : 0) - (l ? 1 : 0), dy = (d ? 1 : 0) - (u ? 1 : 0);
        moving = false; running = false;
        if (!hidden && (dx != 0 || dy != 0)) {
            double len = Math.hypot(dx, dy);
            boolean shift = down(340) || down(344);
            if (exhausted && stamina > 70) exhausted = false;
            running = shift && !exhausted && stamina > 0;
            double sp = running ? 1.55 : 0.95;
            double mx2 = dx / len * sp, my2 = dy / len * sp;
            if (!blocked(px + mx2, py)) px += mx2;
            if (!blocked(px, py + my2)) py += my2;
            mfx = dx / len; mfy = dy / len;
            moving = true;
            if (running) { stamina -= 1; if (stamina <= 0) { stamina = 0; exhausted = true; } }
            if (++stepT >= (running ? 9 : 17)) { stepT = 0; sound(SoundEvents.STONE_STEP, running ? 0.8F : 0.6F, running ? 0.18F : 0.07F); }
        }
        if (!running) stamina = Math.min(360, stamina + (moving ? 0.45 : 0.9));
        // the exit
        int tx = (int) (px / T), ty = (int) (py / T);
        if (exitOpen && px > 45 * T - 2 && ty >= 12 && ty <= 13) { escape(); return; }
        // the aim: the mouse when it moved lately, else the way you walk
        if (mx != pmx || my != pmy) { aimT = 240; pmx = mx; pmy = my; }
        if (aimT > 0) aimT--;
        double tfx = mfx, tfy = mfy;
        if (aimT > 0) {
            double ax = mx + camX - px, ay = my + camY - py, ad = Math.hypot(ax, ay);
            if (ad > 4) { tfx = ax / ad; tfy = ay / ad; }
        }
        fx += (tfx - fx) * 0.35; fy += (tfy - fy) * 0.35;
        double fl = Math.hypot(fx, fy);
        if (fl > 0.01) { fx /= fl; fy /= fl; }
        // the flashlight
        if (flOn) {
            battery -= 0.022;
            if (battery <= 0) { battery = 0; flOn = false; snd(SoundEvents.STONE_BUTTON_CLICK_OFF, 0.7F, 0.5F); say(tr("cutemod.ward.dead"), 110); }
            if (battery < 18 && rnd.nextInt(40) == 0) flickerT = 5 + rnd.nextInt(8);
        }
        if (flickerT > 0) flickerT--;
        // things on the floor
        if (!hidden) {
            for (Item it : items) {
                if (it.got || Math.hypot(px - it.x, py - it.y) > 7) continue;
                it.got = true;
                switch (it.kind) {
                    case 0 -> { fuses++; got++; score += 25; say(tr("cutemod.ward.fuse", got), 130); sound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.3F, 0.7F); pling(1.5F); }
                    case 1 -> { battery = Math.min(100, battery + 45); say(tr("cutemod.ward.battery"), 100); sound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.8F, 0.6F); }
                    default -> { notes++; score += 5; say(tr("cutemod.ward.note." + it.id), 420); sound(SoundEvents.GLASS_HIT, 1.9F, 0.5F); }
                }
            }
        }
        // the camera
        double gxp = Math.max(0, Math.min(MW * T - W, px - W / 2.0)), gyp = Math.max(0, Math.min(MH * T - H, py - H / 2.0));
        camXf += (gxp - camXf) * 0.18; camYf += (gyp - camYf) * 0.18;
    }

    private void escape() {
        win = true; over = true;
        score += 100 + Math.max(0, 40 - ticks / 300);
        sound(SoundEvents.PLAYER_LEVELUP, 1.0F, 0.8F);
    }

    private void caught() {
        if (over) return;
        over = true; win = false;
        growl(G_SCREAM); sound(SoundEvents.PHANTOM_BITE, 0.7F, 1.0F); beep();
    }

    // ---------- the nurse ----------
    private void setGoal(int tx, int ty) {
        tx = Math.max(1, Math.min(MW - 2, tx)); ty = Math.max(1, Math.min(MH - 2, ty));
        if (solid[ty][tx]) {
            int[][] d = {{0, 1}, {0, -1}, {-1, 0}, {1, 0}, {1, 1}, {-1, 1}};
            for (int[] v : d) if (!solid[ty + v[1]][tx + v[0]]) { tx += v[0]; ty += v[1]; break; }
        }
        if (tx != gx || ty != gy) gDirty = true;
        gx = tx; gy = ty;
    }

    private void bfsGoal() {
        for (int[] row : gdist) java.util.Arrays.fill(row, Integer.MAX_VALUE);
        int[] q = new int[MW * MH]; int h = 0, t = 0;
        gdist[gy][gx] = 0; q[t++] = gy * MW + gx;
        while (h < t) {
            int c = q[h++], cx = c % MW, cy = c / MW;
            for (int oy = -1; oy <= 1; oy++) for (int ox = -1; ox <= 1; ox++) {
                if (ox == 0 && oy == 0) continue;
                int x = cx + ox, y = cy + oy;
                if (x < 0 || y < 0 || x >= MW || y >= MH || solid[y][x] || gdist[y][x] != Integer.MAX_VALUE) continue;
                if (ox != 0 && oy != 0 && (solid[cy][x] || solid[y][cx])) continue;
                gdist[y][x] = gdist[cy][cx] + 1; q[t++] = y * MW + x;
            }
        }
    }

    /** One step towards the goal tile. True when she stands on it. */
    private boolean walk(double sp) {
        if (gDirty) { bfsGoal(); gDirty = false; }
        int cx = Math.max(0, Math.min(MW - 1, (int) (nx / T))), cy = Math.max(0, Math.min(MH - 1, (int) (ny / T)));
        double tx, ty;
        if (cx == gx && cy == gy) { tx = gx * T + 5; ty = gy * T + 5; }
        else {
            int bx = cx, by = cy, bd = gdist[cy][cx];
            for (int oy = -1; oy <= 1; oy++) for (int ox = -1; ox <= 1; ox++) {
                if (ox == 0 && oy == 0) continue;
                int x = cx + ox, y = cy + oy;
                if (x < 0 || y < 0 || x >= MW || y >= MH || solid[y][x]) continue;
                if (ox != 0 && oy != 0 && (solid[cy][x] || solid[y][cx])) continue;
                if (gdist[y][x] < bd) { bd = gdist[y][x]; bx = x; by = y; }
            }
            tx = bx * T + 5; ty = by * T + 5;
        }
        double dx = tx - nx, dy = ty - ny, d = Math.hypot(dx, dy);
        if (d > 0.01) {
            double m = Math.min(sp, d);
            nx += dx / d * m; ny += dy / d * m;
            if (d > 0.4) {
                nfx += (dx / d - nfx) * 0.18; nfy += (dy / d - nfy) * 0.18;
                double l = Math.hypot(nfx, nfy); if (l > 0.01) { nfx /= l; nfy /= l; }
            }
        }
        return cx == gx && cy == gy && d < 2.5;
    }

    private void pickPatrol() {
        int[] best = null;
        int pcx = (int) (px / T), pcy = (int) (py / T);
        if (rnd.nextInt(4) == 0) {               // sometimes she goes where you are
            double bd = 1e9;
            for (int[] p : patrol) { double d = Math.hypot(p[0] - pcx, p[1] - pcy); if (d < bd && d > 3) { bd = d; best = p; } }
        }
        if (best == null) best = patrol.get(rnd.nextInt(patrol.size()));
        ns = PATROL; setGoal(best[0], best[1]); nWait = -1;
    }

    private void startSearch(int t, double radius, float prob) {
        ns = SEARCH; nTimer = t; chk = null; queue.clear(); nWait = -1;
        List<Obj> c = new ArrayList<>();
        for (Obj l : lockers) if (Math.hypot(l.cx() - nx, l.cy() - ny) < radius && rnd.nextFloat() < prob) c.add(l);
        c.sort((a, b) -> Double.compare(Math.hypot(a.cx() - nx, a.cy() - ny), Math.hypot(b.cx() - nx, b.cy() - ny)));
        queue.addAll(c);
    }

    private void nurseTick() {
        if (stunT > 0) { stunT--; if (!hidden && Math.hypot(px - nx, py - ny) < 6.5) caught(); return; }
        double dist = Math.max(0.01, Math.hypot(px - nx, py - ny));
        boolean sees = false;
        if (!hidden) {
            double range = 64 + (flOn ? 22 : 0) + (hunt ? 10 : 0);
            if (dist < range) {
                double ux = (px - nx) / dist, uy = (py - ny) / dist;
                if ((ux * nfx + uy * nfy > 0.6 || dist < 16) && los(nx, ny, px, py)) sees = true;
            }
            // she hears you run
            if (!sees && (ns == PATROL || ns == SEARCH || ns == INVEST)) {
                double nr = running ? 52 : moving ? 16 : 4;
                if (dist < nr && (los(nx, ny, px, py) || dist < nr * 0.55)) { ns = INVEST; setGoal((int) (px / T), (int) (py / T)); lsx = px; lsy = py; chk = null; queue.clear(); }
            }
        }
        if (sees) {
            if (ns != CHASE) { ns = CHASE; chk = null; queue.clear(); growl(G_DEEP); shakeT = 12; }
            lsx = px; lsy = py; lost = 0;
            setGoal((int) (px / T), (int) (py / T));
        }
        double chaseSp = 1.05 + 0.06 * got + (hunt ? 0.05 : 0);
        switch (ns) {
            case PATROL -> {
                if (walk(0.55)) {
                    if (nWait < 0) { nWait = 40 + rnd.nextInt(70); if (rnd.nextInt(4) == 0) startSearch(40, 60, 0.4F); }
                    else if (--nWait <= 0) { nWait = -1; pickPatrol(); }
                }
            }
            case INVEST -> { if (walk(hunt ? 1.0 : 0.85)) startSearch(80, 70, 0.5F); }
            case CHASE -> {
                boolean at = walk(chaseSp);
                if (!sees) { lost++; if (at || lost > 240) startSearch(150, 80, 0.55F); }
                if (sees && dist < 7) caught();
            }
            case SEARCH -> {
                double a = Math.atan2(nfy, nfx) + 0.06;
                nfx = Math.cos(a); nfy = Math.sin(a);
                if (chk == null && !queue.isEmpty()) {
                    chk = queue.remove(0); setGoal(chk.tx, chk.ty + 1); ns = CHECK; nWait = -1;
                } else if (--nTimer <= 0) pickPatrol();
            }
            case CHECK -> {
                if (chk == null) { ns = SEARCH; break; }
                if (walk(0.75)) {
                    nfx = 0; nfy = -1;
                    if (nWait < 0) { nWait = 50; chk.shake = 50; snd(SoundEvents.WOODEN_DOOR_OPEN, 0.5F, 0.5F); }
                    else if (--nWait <= 0) {
                        nWait = -1; chk.open = 50;
                        if (hidden && hideObj == chk) { caught(); return; }
                        chk = null; ns = SEARCH; nTimer = Math.max(nTimer, 25);
                    }
                }
            }
            default -> ns = PATROL;
        }
        // the nurse hunts after the alarm: every few seconds she knows where you are
        if (hunt && (ns == PATROL || ns == SEARCH) && ++pingT >= 240) {
            pingT = 0; ns = INVEST; chk = null; queue.clear();
            setGoal((int) (px / T) + rnd.nextInt(9) - 4, (int) (py / T) + rnd.nextInt(7) - 3);      // she knows roughly where you are
        }
        if (!hidden && Math.hypot(px - nx, py - ny) < 6.5) caught();
    }

    private void lampsTick() {
        for (Lamp l : lamps) {
            if (l.flick > 0) l.flick--;
            if (l.dead) continue;
            double dn = Math.hypot(l.x - nx, l.y - ny);
            if (--l.next <= 0) {
                if (dn < 110) { l.flick = 14 + rnd.nextInt(24); l.next = 40 + rnd.nextInt(80); if (rnd.nextInt(10) == 0 && !hunt) l.dead = true; }
                else { if (rnd.nextInt(5) == 0) l.flick = 6 + rnd.nextInt(10); l.next = 260 + rnd.nextInt(420); }
            }
        }
    }

    private void sfxTick() {
        double dn = Math.hypot(px - nx, py - ny);
        if (shakeT > 0) shakeT--;
        // her heels
        if (dn < 130 && ticks % (ns == CHASE ? 9 : 19) == 0) sound(SoundEvents.STONE_STEP, 0.5F + rnd.nextFloat() * 0.1F, 0.55F * (float) (1 - dn / 130));
        // your heart
        if (dn < 80 && --beatT <= 0) {
            beatT = (int) (22 + dn * 0.45);
            snd(SoundEvents.WARDEN_HEARTBEAT, 1.0F, 0.9F * (float) (1.05 - dn / 80));
        }
        if (--ambT <= 0) { ambT = 500 + rnd.nextInt(700); snd(SoundEvents.AMBIENT_CAVE, 0.6F + rnd.nextFloat() * 0.3F, 0.6F); if (rnd.nextInt(3) == 0 && !lockers.isEmpty()) lockers.get(rnd.nextInt(lockers.size())).shake = 40; }
        if (hunt && alarmT % 70 == 0) sound(SoundEvents.BELL_BLOCK, 0.5F, 0.35F);
        if (dn < 50 && ns == CHASE && ticks % 14 == 0) beep();
    }

    // ======================================================================================================
    // drawing: the world
    // ======================================================================================================
    private static final int[] FLA = {0xFF5C7571, 0xFF566C6F, 0xFF6A6F66, 0xFF607069, 0xFF5B6E7A, 0xFF65716C, 0xFF4E5A52, 0xFF627280, 0xFF706A60, 0xFF5E6E70};
    private static final int[] FLB = {0xFF536B67, 0xFF4E6466, 0xFF626759, 0xFF58665F, 0xFF536571, 0xFF5C6862, 0xFF47524B, 0xFF596874, 0xFF665F56, 0xFF566466};

    private int sx(double wx) { return (int) Math.round(wx) - camX; }

    private int sy(double wy) { return (int) Math.round(wy) - camY; }

    private void drawFloorAndWalls(GuiGraphics g) {
        int tx0 = Math.max(0, camX / T), ty0 = Math.max(0, camY / T), tx1 = Math.min(MW - 1, (camX + W) / T), ty1 = Math.min(MH - 1, (camY + H) / T);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                int x = tx * T - camX, y = ty * T - camY, t = tile[ty][tx];
                if (t == WALL) { drawWall(g, tx, ty, x, y); continue; }
                if (t == EXIT) { drawExit(g, x, y); continue; }
                int room = roomOf[ty][tx];
                int a, b;
                if (t == CORR) { a = 0xFF73898A; b = 0xFF6A8081; }
                else if (t == DOOR) { a = b = 0xFF4A3F3A; }
                else { a = FLA[room]; b = FLB[room]; }
                boolean chk = ((tx + ty) & 1) == 0;
                rect(g, x, y, T, T, chk ? a : b);
                rect(g, x, y + T - 1, T, 1, 0x22000000);                      // grout
                rect(g, x + T - 1, y, 1, T, 0x22000000);
                rect(g, x, y, T, 1, 0x14FFFFFF);
                float h = Gfx.hash(tx * 31 + 7, ty * 17 + 3);
                if (h < 0.10) { rect(g, x + 2 + (int) (h * 40), y + 3, 4, 1, 0x28000000); rect(g, x + 5, y + 4, 1, 3, 0x20000000); }   // scuffs and cracks
                else if (h > 0.96) rect(g, x + 3, y + 6, 3, 2, 0x1AFFFFFF);
                if (t == DOOR) {                                                // threshold with brass strip
                    rect(g, x, y, T, 2, 0xFF6A5A44); rect(g, x, y + T - 2, T, 1, 0xFF6A5A44);
                }
            }
        }
        // under the lamps and doors: the walls' shadows on the floor
        for (int ty = ty0; ty <= ty1; ty++) for (int tx = tx0; tx <= tx1; tx++) {
            if (tile[ty][tx] == WALL || tile[ty][tx] == EXIT) continue;
            if (ty > 0 && tile[ty - 1][tx] == WALL) rect(g, tx * T - camX, ty * T - camY, T, 3, 0x30000000);
        }
    }

    private void drawWall(GuiGraphics g, int tx, int ty, int x, int y) {
        boolean below = ty + 1 < MH && tile[ty + 1][tx] != WALL;
        if (below) {
            rect(g, x, y, T, 4, 0xFF3C4A52);                                   // top edge of the wall
            rect(g, x, y, T, 1, 0xFF54656E);
            rect(g, x, y + 4, T, 6, 0xFF52696D);                              // the tiled face
            rect(g, x, y + 4, T, 1, 0xFF6E878B);
            rect(g, x + 4, y + 5, 1, 4, 0x33000000); rect(g, x + 9, y + 5, 1, 4, 0x33000000);
            rect(g, x, y + 9, T, 1, 0xFF2D3A3F);                              // skirting
            float h = Gfx.hash(tx * 13 + 1, ty * 7 + 9);
            if (h > 0.93) { rect(g, x + 2, y + 5, 2, 4, 0x55600A12); rect(g, x + 2, y + 8, 3, 1, 0x66600A12); }   // a blood smear
        } else {
            rect(g, x, y, T, T, 0xFF2D383E);
            if (ty > 0 && tile[ty - 1][tx] != WALL) rect(g, x, y, T, 1, 0xFF445661);
            if (tx > 0 && tile[ty][tx - 1] != WALL) rect(g, x, y, 1, T, 0xFF3A4952);
        }
    }

    private void drawExit(GuiGraphics g, int x, int y) {
        if (exitOpen) {
            rect(g, x, y, T, T, 0xFFEFF7DC);
            Gfx.glow(g, x + 2, y + 5, 14, 0xFFFFF6C0, 160);
        } else {
            rect(g, x, y, T, T, 0xFF5A3A3C);
            rect(g, x + 1, y + 1, T - 2, T - 2, 0xFF6D4A4C);
            rect(g, x + 3, y, 1, T, 0xFF3E2628);
            rect(g, x, y + 4, T, 1, 0xFF3E2628);
        }
        // EXIT sign
        if (y > -T && y < H) { rect(g, x - 6, y - 3, 6, 5, 0xFF0E3A1E); rect(g, x - 5, y - 2, 4, 3, 0xFF3CFF7A); }
    }

    private void drawDecals(GuiGraphics g) {
        for (Decal d : decals) {
            int x = sx(d.x), y = sy(d.y);
            if (x < -8 || y < -8 || x > W + 8 || y > H + 8) continue;
            int r = d.size;
            switch (d.kind) {
                case 0 -> { Gfx.ellipse(g, x, y, r + 1, r, 0xFF4A0A12); Gfx.ellipse(g, x - 1, y - 1, Math.max(1, r - 1), Math.max(1, r - 1), 0xFF6E1019); }
                case 1 -> { Gfx.ellipse(g, x, y, r + 2, Math.max(1, r - 1), 0xFF3E080E); rect(g, x + r, y - 1, r + 2, 1, 0xFF3E080E); rect(g, x - r - 2, y + 1, 3, 1, 0xFF4A0A12); }
                default -> { rect(g, x, y, 1, 1, 0xFF5A0C14); rect(g, x + 3, y + 2, 1, 1, 0xFF5A0C14); rect(g, x - 2, y + 3, 2, 1, 0xFF4A0A12); rect(g, x + r, y - 2, 1, 2, 0xFF4A0A12); }
            }
        }
    }

    private void drawObj(GuiGraphics g, Obj o) {
        int x = o.tx * T - camX, y = o.ty * T - camY, w = o.w * T, h = o.h * T;
        if (x + w < -4 || y + h < -4 || x > W + 4 || y > H + 4) return;
        int shk = o.shake > 0 ? ((o.shake / 2) % 2 == 0 ? 1 : -1) : 0;
        rect(g, x + w, y + 2, 2, h, 0x40000000); rect(g, x + 2, y + h, w, 2, 0x40000000);        // shadow
        switch (o.type) {
            case BED -> {
                Gfx.rrect(g, x, y, w, h, 2, 0xFF6F7C89);
                Gfx.rrect(g, x + 1, y + 1, w - 2, h - 2, 2, 0xFFE8EFF3);
                Gfx.rrect(g, x + 2, y + 2, w - 4, 6, 2, 0xFFFFFFFF); rect(g, x + 3, y + 6, w - 6, 1, 0xFFCFDDE6);
                Gfx.rrect(g, x + 1, y + 11, w - 2, h - 12, 2, o.variant == 2 ? 0xFF7FA0B4 : 0xFF9CC4DC);
                rect(g, x + 1, y + 11, w - 2, 1, 0xFFC4E0F0); rect(g, x + 4, y + 11 + (h - 12) / 2, w - 8, 1, 0x22000000);
                if (o.variant >= 1) { Gfx.ellipse(g, x + 6, y + h - 8, 4, 3, 0xFF6A0C14); Gfx.ellipse(g, x + 5, y + h - 9, 2, 2, 0xFF8A1520); rect(g, x + 8, y + h - 5, 1, 4, 0xFF6A0C14); }
                if (o.variant == 2) { rect(g, x + 2, y + 3, 5, 2, 0xFF7A1018); }
                rect(g, x, y + h - 2, 1, 2, 0xFF3C4650); rect(g, x + w - 1, y + h - 2, 1, 2, 0xFF3C4650);
            }
            case LOCKER -> {
                int ox = shk;
                rect(g, x + ox, y, T, 4, 0xFF8B98A4); rect(g, x + ox, y, T, 1, 0xFFB0BCC6);
                rect(g, x + ox, y + 4, T, 6, 0xFF5E6B76);
                if (o.open > 0) { rect(g, x + 1 + ox, y + 4, T - 2, 6, 0xFF0C0F12); rect(g, x + 7 + ox, y + 4, 3, 6, 0xFF7A8792); }
                else {
                    for (int i = 0; i < 3; i++) rect(g, x + 2 + ox, y + 5 + i * 2, 6, 1, 0xFF3A444C);
                    rect(g, x + 7 + ox, y + 8, 2, 1, 0xFFE0C860);
                }
                rect(g, x + ox, y + 9, T, 1, 0xFF2E373E);
            }
            case TABLE, DESK -> {
                Gfx.rrect(g, x, y, w, h, 1, 0xFF6E5238); Gfx.rrect(g, x + 1, y + 1, w - 2, h - 3, 1, o.type == DESK ? 0xFF8C6B48 : 0xFFA88A62);
                rect(g, x + 1, y + 1, w - 2, 1, 0x33FFFFFF);
                if (o.type == DESK) {
                    rect(g, x + 3, y + 2, 7, 5, 0xFF1E2830); rect(g, x + 4, y + 3, 5, 3, 0xFF6FD6B8 - ((ticks / 40) % 2 == 0 ? 0 : 0x101010));
                    rect(g, x + w - 8, y + 3, 5, 4, 0xFFE8E0C8); rect(g, x + w - 7, y + 4, 3, 1, 0xFFA09878);
                } else { rect(g, x + 3, y + 3, 4, 3, 0xFFE8E4D8); Gfx.ellipse(g, x + w - 6, y + 5, 2, 2, 0xFFD0D8E0); }
            }
            case BENCH -> {
                Gfx.rrect(g, x, y + 2, w, 7, 2, 0xFF2E5470); Gfx.rrect(g, x + 1, y + 2, w - 2, 5, 2, 0xFF3F6E90);
                rect(g, x + 1, y + 2, w - 2, 1, 0x44FFFFFF); rect(g, x + 1, y + 9, 2, 1, 0xFF20262C); rect(g, x + w - 3, y + 9, 2, 1, 0xFF20262C);
            }
            case SHELF -> {
                rect(g, x, y, w, T, 0xFF4E3C2E); rect(g, x, y, w, 1, 0xFF7A6046); rect(g, x, y + 4, w, 1, 0xFF33271D);
                int[] cols = {0xFFE06A6A, 0xFF6AB0E0, 0xFFE0D06A, 0xFF8AD08A, 0xFFE0E0E8, 0xFFC08AE0};
                for (int i = 0; i < w - 2; i += 3) {
                    int c = cols[((o.tx + i / 3 + o.ty) & 7) % cols.length];
                    rect(g, x + 1 + i, y + 1, 2, 3, c); rect(g, x + 1 + i, y + 6, 2, 3, cols[(i / 3 + 2) % cols.length]);
                }
            }
            case GURNEY -> {
                boolean vert = h > w;
                rect(g, x, y, w, h, 0xFF9AA8B4);
                rect(g, x + 1, y + 1, w - 2, h - 2, 0xFFE4EBEF);
                if (o.variant == 1) {          // a body under a sheet
                    int bw = 6, bl = h - 6;
                    Gfx.rrect(g, x + 2, y + 2, bw, bl, 3, 0xFFF3F6F8); Gfx.ellipse(g, x + 5, y + 4, 2, 2, 0xFFD0D8DE);
                    rect(g, x + 2, y + h / 2, 6, 2, 0xFF6A0C14); rect(g, x + 4, y + h / 2 + 2, 2, 3, 0xFF8A1520);
                } else if (o.variant == 2) {   // the operating table, with a bloody cloth and tools
                    Gfx.rrect(g, x + 3, y + 3, w - 6, h - 6, 2, 0xFFC6D6DF);
                    Gfx.ellipse(g, x + w / 2, y + h / 2, 5, 6, 0xFF7A0E16); Gfx.ellipse(g, x + w / 2 - 1, y + h / 2 - 1, 3, 4, 0xFF9A1822);
                    rect(g, x + w - 5, y + 4, 2, 6, 0xFFAEB8C0); rect(g, x + w - 5, y + 11, 1, 5, 0xFF9AA4AC);
                } else { rect(g, x + 2, y + 2, w - 4, h - 4, 0xFFF0F4F6); }
                if (vert) { rect(g, x, y + 2, 1, 3, 0xFF3C4650); rect(g, x + w - 1, y + h - 4, 1, 3, 0xFF3C4650); }
                else { rect(g, x + 2, y + h - 1, 3, 1, 0xFF3C4650); rect(g, x + w - 5, y + h - 1, 3, 1, 0xFF3C4650); }
            }
            case CHAIR -> {
                rect(g, x + 1, y + 2, 2, 7, 0xFF14181C); rect(g, x + 7, y + 2, 2, 7, 0xFF14181C);
                rect(g, x + 3, y + 3, 4, 5, 0xFF2E3C48); rect(g, x + 3, y + 1, 4, 2, 0xFF3C4E5C); rect(g, x + 2, y, 6, 1, 0xFF8A98A4);
            }
            case CRATE -> {
                rect(g, x, y, w, h, 0xFF7A5A38); rect(g, x + 1, y + 1, w - 2, h - 2, 0xFF9A7448);
                for (int i = 0; i < w; i += T) { rect(g, x + i, y, 1, h, 0xFF5A4028); rect(g, x + i + T - 1, y, 1, h, 0xFF5A4028); }
                for (int j = 0; j < h; j += T) { rect(g, x, y + j + 4, w, 1, 0xFF5A4028); rect(g, x, y + j, w, 1, 0xFFB08A58); }
            }
            case COUNTER -> {
                rect(g, x, y, w, T, 0xFF5E6A74); rect(g, x, y, w, 5, 0xFFB4C0C8); rect(g, x, y, w, 1, 0xFFDDE6EA);
                Gfx.rrect(g, x + 3, y + 1, 6, 3, 1, 0xFF7E8C96); rect(g, x + 12, y + 1, 4, 3, 0xFFC4D2DA);
                rect(g, x, y + 9, w, 1, 0xFF2E373E);
            }
            case GEN -> drawGenerator(g, o, x, y, w, h);
            default -> rect(g, x, y, w, h, 0xFF888888);
        }
    }

    private void drawGenerator(GuiGraphics g, Obj o, int x, int y, int w, int h) {
        rect(g, x - 1, y, w + 2, T + 2, 0xFF2A343A);
        rect(g, x, y, w, T, 0xFF4A5A64); rect(g, x, y, w, 2, 0xFF6C808C);
        rect(g, x + 1, y + 3, w - 2, 6, 0xFF1E272C);
        for (int i = 0; i < 3; i++) {                                     // three fuse slots
            boolean filled = i < slotted;
            rect(g, x + 2 + i * 6, y + 4, 4, 4, filled ? 0xFFFFA93A : 0xFF0C1014);
            if (filled) { rect(g, x + 3 + i * 6, y + 5, 2, 2, 0xFFFFE9A0); }
            else if ((ticks / 30) % 2 == 0 && !exitOpen) rect(g, x + 3 + i * 6, y + 7, 2, 1, 0xFF5A1818);
        }
        rect(g, x + w - 3, y + 1, 2, 2, exitOpen ? 0xFF48FF7A : (alarmT == 0 ? 0xFFFF3A3A : 0xFF48FF7A));
    }

    private void drawItems(GuiGraphics g) {
        for (Item it : items) {
            if (it.got) continue;
            int x = sx(it.x), y = sy(it.y);
            if (x < -16 || y < -16 || x > W + 16 || y > H + 16) continue;
            double bob = Math.sin((ticks + it.id * 17 + it.kind * 7) * 0.08);
            int by = y + (int) Math.round(bob);
            double pd = Math.hypot(px - it.x, py - it.y);
            double near = pd < 45 ? 1 : Math.max(0.3, 1 - (pd - 45) / 90);    // far away they only glimmer
            switch (it.kind) {
                case 0 -> {   // a fuse: a glass tube with an orange core
                    Gfx.glow(g, x, by, 13, 0xFFFFA93A, (int) (120 * near));
                    rect(g, x - 1, by - 4, 3, 8, 0xFFC8D4DC); rect(g, x - 1, by - 5, 3, 1, 0xFF7A8690); rect(g, x - 1, by + 4, 3, 1, 0xFF7A8690);
                    rect(g, x, by - 3, 1, 6, 0xFFFFA93A); if (near > 0.5) Gfx.sparkle(g, x + 3, by - 4, 2, ticks + it.id * 20, 0xFFFFF0B0);
                }
                case 1 -> {   // a battery
                    Gfx.glow(g, x, by, 8, 0xFF8AFF8A, 60);
                    rect(g, x - 2, by - 3, 5, 7, 0xFF2E8A3E); rect(g, x - 1, by - 4, 3, 1, 0xFFB0B8C0); rect(g, x - 2, by - 1, 5, 2, 0xFFE8D048);
                }
                default -> {  // a note
                    Gfx.glow(g, x, y, 8, 0xFFFFF4C0, 50);
                    rect(g, x - 3, y - 3, 7, 8, 0xFFEFE6C8); rect(g, x - 2, y - 2, 5, 1, 0xFF8A7E60); rect(g, x - 2, y, 4, 1, 0xFF8A7E60); rect(g, x - 2, y + 2, 5, 1, 0xFF8A7E60);
                }
            }
        }
    }

    // ---------- characters ----------
    private void drawCat(GuiGraphics g, int x, int y) {
        Gfx.ellipse(g, x, y + 4, 5, 2, 0x66000000);
        int tailx = (int) Math.round(x - mfx * 5), taily = (int) Math.round(y - mfy * 5 + 1);
        Gfx.line(g, x, y, tailx, taily, 0xFFE57AA4);
        rect(g, tailx, taily, 1, 1, 0xFFFFC2D8);
        Gfx.ball(g, x, y, 4, 0xFFBEE3F2);                         // the hospital gown
        rect(g, x - 1, y + 1, 2, 1, 0xFFFFFFFF);
        int hx = (int) Math.round(x + fx * 2.2), hy = (int) Math.round(y + fy * 2.2 - 2);
        // pointed ears on top of the head, like the cat of the other games
        Gfx.poly(g, new int[]{hx - 4, hx - 1, hx - 4}, new int[]{hy - 6, hy - 3, hy - 2}, 0xFFF58FB8);
        Gfx.poly(g, new int[]{hx + 4, hx + 1, hx + 4}, new int[]{hy - 6, hy - 3, hy - 2}, 0xFFF58FB8);
        rect(g, hx - 3, hy - 4, 1, 2, 0xFFFFC2D8); rect(g, hx + 3, hy - 4, 1, 2, 0xFFFFC2D8);
        Gfx.ball(g, hx, hy, 3, 0xFFF58FB8);
        // eyes look where the light points; a tiny nose and whiskers
        int ex = (int) Math.round(fx * 1.2), ey = (int) Math.round(fy * 1.2);
        rect(g, hx - 2 + ex, hy - 1 + ey, 1, 1, 0xFF2A1A2A); rect(g, hx + 1 + ex, hy - 1 + ey, 1, 1, 0xFF2A1A2A);
        rect(g, hx + ex, hy + 1 + ey, 1, 1, 0xFFD0507E);
        rect(g, hx - 5, hy, 2, 1, 0xCCFFFFFF); rect(g, hx + 4, hy, 2, 1, 0xCCFFFFFF);
        // the torch in her hand
        int tx = (int) Math.round(x + fx * 5 - fy * 3), ty = (int) Math.round(y + fy * 5 + fx * 3);
        rect(g, tx, ty, 2, 2, flOn ? 0xFFFFF0A0 : 0xFF8A8A92);
    }

    private void drawNurse(GuiGraphics g, int x, int y) {
        if (stunT > 0) x += (ticks % 2 == 0) ? 1 : -1;       // she shakes, hands over her ears
        Gfx.ellipse(g, x, y + 4, 6, 3, 0x77000000);
        double sx2 = -nfy, sy2 = nfx;
        // long pale arms stretched forward, a syringe in the right hand
        for (int s = -1; s <= 1; s += 2) {
            int ax = (int) Math.round(x + sx2 * 4 * s), ay = (int) Math.round(y + sy2 * 4 * s - 1);
            int hx = (int) Math.round(ax + nfx * 7), hy = (int) Math.round(ay + nfy * 7);
            Gfx.line(g, ax, ay, hx, hy, 0xFFDCCFC8);
            rect(g, hx, hy, 2, 2, 0xFFEFE4DC);
            if (s == 1) { Gfx.line(g, hx, hy, (int) Math.round(hx + nfx * 5), (int) Math.round(hy + nfy * 5), 0xFFE0E8F0); rect(g, (int) Math.round(hx + nfx * 5), (int) Math.round(hy + nfy * 5), 1, 1, 0xFFFF3A4A); }
        }
        Gfx.ellipse(g, x, y, 6, 4, 0xFFE6ECEE);                    // the uniform
        Gfx.ellipse(g, x, y + 1, 4, 3, 0xFFCDD6DA);
        rect(g, x - 1, y, 3, 3, 0xFF7A0E16); rect(g, x, y + 3, 1, 2, 0xFF7A0E16);   // blood on the apron
        int hx = (int) Math.round(x + nfx * 1.5), hy = (int) Math.round(y + nfy * 1.5 - 3);
        Gfx.ball(g, hx, hy, 3, 0xFFEADFD6);                         // pale face / head
        rect(g, hx - 3, hy - 4, 7, 3, 0xFFFFFFFF); rect(g, hx - 2, hy - 5, 5, 1, 0xFFF4F4F4);   // the cap
        rect(g, hx, hy - 4, 1, 3, 0xFFD02A3A); rect(g, hx - 1, hy - 3, 3, 1, 0xFFD02A3A);        // red cross
        rect(g, hx - 3 - (int) Math.round(nfx * 2), hy + 1 - (int) Math.round(nfy * 2), 7, 1, 0xFF14101A); // dark hair at the back
    }

    private void drawNurseEyes(GuiGraphics g, int x, int y) {
        int hx = (int) Math.round(x + nfx * 1.5), hy = (int) Math.round(y + nfy * 1.5 - 3);
        int ex = (int) Math.round(nfx * 1.5), ey = (int) Math.round(nfy * 1.5);
        Gfx.glow(g, hx - 2 + ex, hy + ey, 6, 0xFFFF2A2A, 130); Gfx.glow(g, hx + 2 + ex, hy + ey, 6, 0xFFFF2A2A, 130);
        rect(g, hx - 3 + ex, hy + ey, 2, 1, 0xFFFF4040); rect(g, hx + 1 + ex, hy + ey, 2, 1, 0xFFFF4040);
    }

    // ---------- the darkness ----------
    private int cellAlpha(double wx, double wy, int amb, List<Lamp> near) {
        double a = amb;
        double dx = wx - px, dy = wy - py, d = Math.sqrt(dx * dx + dy * dy);
        if (!hidden) {
            if (d < 24 && los(px, py, wx, wy)) {
                double t = d / 24;
                a = Math.min(a, 0x34 + (amb - 0x34) * t * t);
            }
            if (flOn && battery > 0 && d < 92 && d > 0.5) {
                double dot = (dx * fx + dy * fy) / d;
                double reach = 92 * (flickerT > 0 ? 0.6 : (battery < 18 ? 0.8 : 1.0));
                if (d < reach && dot > 0.80) {
                    double f = Math.min(1, (dot - 0.80) / 0.14), fall = d / reach;
                    double v = 0x08 + 0x70 * fall * fall;
                    v = amb + (v - amb) * f;
                    if (v < a && los(px, py, wx, wy)) a = v;
                }
            }
        }
        for (Lamp l : near) {
            double ld = Math.hypot(wx - l.x, wy - l.y);
            if (ld >= l.r) continue;
            double t = ld / l.r;
            double v = 0x4C + (amb - 0x4C) * Math.pow(t, 1.3);
            if (v < a && los(l.x, l.y, wx, wy)) a = v;
        }
        int q = ((int) a + 4) & ~7;
        return Math.min(amb, q);
    }

    private void drawDarkness(GuiGraphics g) {
        int amb = exitOpen ? ALARM_AMB : BASE_AMB;
        List<Lamp> near = new ArrayList<>();
        for (Lamp l : lamps) {
            if (!lampOn(l)) continue;
            if (l.x + l.r < camX || l.x - l.r > camX + W || l.y + l.r < camY || l.y - l.r > camY + H) continue;
            near.add(l);
        }
        int rgb = exitOpen ? 0x120406 : 0x04030C;
        for (int y = 0; y < H; y += CELL) {
            int runA = -1, runX = 0;
            for (int x = 0; x <= W; x += CELL) {
                int a = -2;
                if (x < W) a = cellAlpha(camX + x + CELL / 2.0, camY + y + CELL / 2.0, amb, near);
                if (a != runA) {
                    if (runA > 0) rect(g, runX, y, x - runX, CELL, (runA << 24) | rgb);
                    runA = a; runX = x;
                }
            }
        }
        // warm / cold glows around the lamps and the flashlight
        for (Lamp l : near) {
            int c = exitOpen ? 0xFFFF4A3A : 0xFFD8EEFF;
            double pulse = exitOpen ? 0.6 + 0.4 * Math.sin(ticks * 0.15) : 1.0;
            Gfx.glow(g, sx(l.x), sy(l.y), 16, c, (int) (46 * pulse));
            rect(g, sx(l.x) - 2, sy(l.y) - 1, 5, 2, exitOpen ? 0xFFFF9A8A : 0xFFF4FBFF);
        }
        if (flOn && battery > 0 && !hidden) Gfx.glow(g, sx(px + fx * 10), sy(py + fy * 10), 18, 0xFFFFF0B0, flickerT > 0 ? 16 : 36);
        // the generator's blinking light can be seen from afar: it is where you must go
        if (generator != null) {
            int gx2 = sx(generator.cx()), gy2 = sy(generator.cy());
            if (gx2 > -20 && gx2 < W + 20 && gy2 > -20 && gy2 < H + 20) {
                boolean on = exitOpen || (ticks / 30) % 2 == 0;
                Gfx.glow(g, gx2 + 6, gy2 - 1, 9, exitOpen ? 0xFF48FF7A : 0xFFFF3A3A, on ? 90 : 30);
            }
        }
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g) {
        camX = (int) Math.round(Math.max(0, Math.min(MW * T - W, camXf)));
        camY = (int) Math.round(Math.max(0, Math.min(MH * T - H, camYf)));
        if (shakeT > 0 && !over) { camX += (ticks % 2 == 0) ? 1 : -1; }
        rect(g, 0, 0, W, H, 0xFF08060C);
        drawFloorAndWalls(g);
        drawDecals(g);
        List<Obj> sorted = new ArrayList<>(objs);
        sorted.sort((a, b) -> Integer.compare(a.ty + a.h, b.ty + b.h));
        for (Obj o : sorted) drawObj(g, o);
        // the nurse is only seen where there is light (or very close)
        int nsx = sx(nx), nsy = sy(ny);
        boolean nurseLit = isLit(nx, ny);
        if (nurseLit || Math.hypot(px - nx, py - ny) < 15 || over) drawNurse(g, nsx, nsy);
        if (!hidden) drawCat(g, sx(px), sy(py));
        drawDarkness(g);
        drawItems(g);
        // her eyes in the dark: a warning
        if (!over && !nurseLit && Math.hypot(px - nx, py - ny) < 110 && (ticks % 160) > 8 && los(nx, ny, px, py)) drawNurseEyes(g, nsx, nsy);
        if (!hidden) drawPrompts(g);
        if (hidden) drawLockerView(g);
        if (exitOpen && !over) rect(g, 0, 0, W, H, ((int) (8 + 14 * (0.5 + 0.5 * Math.sin(ticks * 0.15))) << 24) | 0xFF1010);   // alarm tint
        double dn = Math.hypot(px - nx, py - ny);
        if (!over && ns == CHASE && dn < 60 && (ticks / 4) % 3 == 0) rect(g, 0, 0, W, H, 0x22FF0000);                          // panic flicker
        Gfx.vignette(g, W, H, 120);
        if (over) { if (win) drawWin(g); else drawJumpscare(g); }
        else drawHud(g);
    }

    private boolean isLit(double wx, double wy) {
        List<Lamp> near = new ArrayList<>();
        for (Lamp l : lamps) if (lampOn(l) && Math.hypot(l.x - wx, l.y - wy) < l.r) near.add(l);
        return cellAlpha(wx, wy, exitOpen ? ALARM_AMB : BASE_AMB, near) < 0xA0;
    }

    private void drawPrompts(GuiGraphics g) {
        String at = null; double ax = 0, ay = 0;
        if (generator != null && !exitOpen && Math.hypot(px - generator.cx(), py - (generator.cy() + 8)) < 17) { at = "E"; ax = generator.cx(); ay = generator.cy() - 6; }
        else {
            for (Obj l : lockers) if (Math.hypot(px - l.cx(), py - (l.cy() + 4)) < 14) { at = "E"; ax = l.cx(); ay = l.cy() - 8; break; }
        }
        if (at != null) {
            int x = sx(ax), y = sy(ay) - (int) Math.round(Math.sin(ticks * 0.12));
            Gfx.bubble(g, x - 5, y - 5, 10, 10, 2, 0xFF2A3038);
            ctext(g, at, x, y - 4, 0xFFFFE9A0);
        }
    }

    /** Inside a locker: the dark door with three slits you look through. */
    private void drawLockerView(GuiGraphics g) {
        int c = 0xF2050408;
        int sy0 = H / 2 - 18, sh = 3, gap = 8, x0 = 60, x1 = W - 60;
        rect(g, 0, 0, W, sy0, c);
        for (int i = 0; i < 3; i++) {
            int y = sy0 + i * (sh + gap);
            rect(g, 0, y, x0, sh, c); rect(g, x1, y, W - x1, sh, c);
            if (i < 2) rect(g, 0, y + sh, W, gap, c);
        }
        rect(g, 0, sy0 + 3 * sh + 2 * gap, W, H, c);
        rect(g, x0 - 1, sy0 - 4, 1, 3 * sh + 2 * gap + 8, 0xFF3A444C); rect(g, x1, sy0 - 4, 1, 3 * sh + 2 * gap + 8, 0xFF3A444C);
    }

    // ---------- HUD ----------
    private void drawHud(GuiGraphics g) {
        // fuses
        Gfx.rrect(g, 3, 3, 33, 12, 3, 0x99000000);
        int total = slotted + fuses;
        for (int i = 0; i < 3; i++) {
            int x = 6 + i * 10;
            boolean on = i < total;
            rect(g, x, 5, 6, 8, on ? (i < slotted ? 0xFF48D878 : 0xFFFFA93A) : 0xFF3A3F46);
            rect(g, x + 1, 6, 1, 6, on ? 0xFFFFF0C0 : 0xFF4E545C);
            rect(g, x + 2, 4, 2, 1, 0xFF8A949E);
        }
        String obj = exitOpen ? tr("cutemod.ward.obj.2") : (fuses > 0 ? tr("cutemod.ward.obj.1") : tr("cutemod.ward.obj.0", got));
        if (introT == 0 || introT < 60) shText(g, clip(obj, W - 44), 40, 5, exitOpen ? 0xFFFF9A8A : 0xFFE8E4D8);
        // battery and stamina
        Gfx.rrect(g, 3, H - 14, 36, 11, 3, 0x99000000);
        rect(g, 6, H - 11, 3, 5, 0xFFB0B8C0);
        int bw = (int) Math.round(27 * battery / 100.0);
        rect(g, 11, H - 11, 27 - 0, 5, 0xFF1E2228);
        rect(g, 11, H - 11, bw, 5, battery < 20 ? 0xFFE04848 : (flOn ? 0xFFFFE070 : 0xFF9AA2AA));
        rect(g, 11, H - 5, (int) Math.round(27 * stamina / 360.0), 1, exhausted ? 0xFFE04848 : 0xFF7FD6A0);
        // the message
        if (msgT > 0 && !msg.isEmpty()) {
            List<String> lines = wrap(msg, W - 30);
            int n = Math.min(3, lines.size());
            int bh = n * 9 + 5, by = H - 16 - bh;
            float k = Math.min(1F, msgT / 20F);
            Gfx.rrect(g, 14, by, W - 28, bh, 3, Gfx.fade(0xDD0A0C10, k));
            Gfx.outline(g, 14, by, W - 28, bh, Gfx.fade(0x55FFFFFF, k));
            for (int i = 0; i < n; i++) ctext(g, lines.get(i), W / 2, by + 3 + i * 9, Gfx.fade(0xFFF0EAD8, k));
        }
        // the intro
        if (introT > 0) {
            float k = Math.min(1F, introT / 50F);
            rect(g, 0, 0, W, H, Gfx.fade(0xFF000000, k * (introT > 130 ? 1F : 0.35F)));
            String t = tr("cutemod.ward.title"), s = tr("cutemod.ward.sub");
            g.pose().pushPose();
            g.pose().translate(W / 2F - tw(t) * 1.5F, 44, 0);
            g.pose().scale(3F, 3F, 1F);
            dev.cutemod.client.os.CuteFont.draw(g, font(), t, 0, 0, Gfx.fade(0xFFE8E4D8, k), false);
            g.pose().popPose();
            ctextW(g, s, W / 2, 78, W - 20, Gfx.fade(0xFFB05A60, k));
        }
    }

    private void drawWin(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0xCCFFF4D0);
        Gfx.glow(g, W / 2, H, 110, 0xFFFFE08A, 200);
        for (int i = 0; i < 12; i++) Gfx.sparkle(g, 20 + (int) (Gfx.hash(i, 5) * 180), 12 + (int) (Gfx.hash(i, 9) * 90), 3, (int) (System.nanoTime() / 16_000_000L) + i * 13, 0xFFFFFFFF);
        Gfx.ball(g, W / 2, H - 38, 9, 0xFFF58FB8);
        rect(g, W / 2 - 5, H - 52, 3, 3, 0xFFF58FB8); rect(g, W / 2 + 3, H - 52, 3, 3, 0xFFF58FB8);
        rect(g, W / 2 - 4, H - 40, 2, 2, 0xFF2A1A2A); rect(g, W / 2 + 2, H - 40, 2, 2, 0xFF2A1A2A);
    }

    private void drawJumpscare(GuiGraphics g) {
        long ms = System.nanoTime() / 55_000_000L;
        int sh = (int) (ms % 2) * 3 - 1, sv = (int) ((ms / 2) % 2) * 2 - 1;
        rect(g, 0, 0, W, H, 0xE6200004);
        Gfx.glow(g, 110, 66, 74, 0xFFFF2A2A, 120);
        int cx = 110 + sh, cy = 74 + sv;
        Gfx.ellipse(g, cx, cy, 42, 56, 0xFFB9B2B4);
        Gfx.ellipse(g, cx, cy - 2, 40, 54, 0xFFE9E0DA);
        // cap with a red cross
        Gfx.rrect(g, cx - 40, cy - 66, 80, 26, 6, 0xFFF4F4F4); rect(g, cx - 40, cy - 44, 80, 3, 0xFFC8C8C8);
        rect(g, cx - 4, cy - 62, 8, 18, 0xFFC8202E); rect(g, cx - 10, cy - 57, 20, 8, 0xFFC8202E);
        // eyes
        Gfx.ellipse(g, cx - 17, cy - 20, 13, 10, 0xFF050005); Gfx.ellipse(g, cx + 17, cy - 20, 13, 10, 0xFF050005);
        Gfx.glow(g, cx - 17, cy - 20, 9, 0xFFFF2A2A, 160); Gfx.glow(g, cx + 17, cy - 20, 9, 0xFFFF2A2A, 160);
        rect(g, cx - 19, cy - 22, 4, 4, 0xFFFF3030); rect(g, cx + 15, cy - 22, 4, 4, 0xFFFF3030);
        rect(g, cx - 18, cy - 21, 1, 1, 0xFFFFE0E0); rect(g, cx + 16, cy - 21, 1, 1, 0xFFFFE0E0);
        // blood tears
        rect(g, cx - 22, cy - 12, 2, 22, 0xFF8A0E18); rect(g, cx + 20, cy - 12, 2, 28, 0xFF8A0E18);
        // nose and the huge mouth
        Gfx.poly(g, new int[]{cx - 3, cx + 3, cx}, new int[]{cy - 6, cy - 6, cy + 4}, 0xFF3A2024);
        Gfx.ellipse(g, cx, cy + 26, 28, 17, 0xFF120004);
        for (int i = 0; i < 9; i++) {
            rect(g, cx - 26 + i * 6, cy + 11, 4, 7 + (i % 2) * 3, 0xFFF4F0E8);
            rect(g, cx - 26 + i * 6, cy + 37 - (i % 2) * 3, 4, 7, 0xFFE0DCD0);
        }
        rect(g, cx - 12, cy + 24, 24, 4, 0xFF8A0E18);
        // she holds the syringe up
        rect(g, cx + 46, cy - 6, 3, 36, 0xFFE8F0F8); rect(g, cx + 44, cy + 30, 7, 2, 0xFFB0B8C0); rect(g, cx + 47, cy - 14, 1, 8, 0xFFFF3A4A);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ward.status", got, score); }

    @Override
    public boolean isWin() { return win; }

    @Override
    public Component endTitle() { return Component.translatable(win ? "cutemod.ward.win" : "cutemod.ward.caught"); }

    @Override
    public String hintKey() { return "cutemod.hint.ward"; }
}
