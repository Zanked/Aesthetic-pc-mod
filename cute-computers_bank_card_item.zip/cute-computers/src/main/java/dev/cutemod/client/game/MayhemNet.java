package dev.cutemod.client.game;

import dev.cutemod.data.MayhemSim;
import dev.cutemod.net.MayhemActionPayload;
import dev.cutemod.net.MayhemLobbyPayload;
import dev.cutemod.net.MayhemStatePayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** The client side of online Dangerous Weapons: what the server last told us (rooms, our room, the running round) and the messages we send. */
public final class MayhemNet {
    private MayhemNet() {}

    /** The open rooms: the name of the host and how many places are free. */
    public static List<String> hosts = new ArrayList<>();
    public static List<Integer> open = new ArrayList<>();
    public static boolean inRoom, inGame, youHost;
    public static int mySlot, level = 1, lives = 3, map = MayhemSim.RANDOM_MAP, gameMode;
    /** 0 empty, 1 open, 2 computer player, 3 person. */
    public static final int[] slotType = new int[4];
    public static final String[] slotName = {"", "", "", ""};
    /** The colour | class << 4 | pistol << 8 of every slot, -1 when it is not chosen (a computer player, an open slot). */
    public static final int[] slotLoad = {-1, -1, -1, -1};
    /** Goes up with every lobby message. */
    public static int version;
    private static int notice;
    private static long ignoreUntil;

    /** The round as the server sent it last (the same class the server runs, it only draws), and how many snapshots came. */
    public static final MayhemSim view = new MayhemSim();
    public static int stateVersion, stateSlot = -1;
    /** The events (shots, blasts, ...) of the snapshots that the game has not turned into particles and sounds yet. */
    public static final List<int[]> pending = new ArrayList<>();

    public static void apply(MayhemLobbyPayload p) {
        hosts = new ArrayList<>(p.hosts());
        open = new ArrayList<>(p.open());
        boolean room = p.inRoom();
        inRoom = System.currentTimeMillis() < ignoreUntil ? false : room;
        inGame = inRoom && p.inGame();
        youHost = p.youHost();
        mySlot = p.mySlot();
        level = p.level();
        lives = p.lives();
        map = p.map();
        gameMode = p.gameMode();
        for (int i = 0; i < 4; i++) {
            slotType[i] = i < p.slotType().size() ? p.slotType().get(i) : 0;
            slotName[i] = i < p.slotName().size() ? p.slotName().get(i) : "";
            slotLoad[i] = i < p.slotLoad().size() ? p.slotLoad().get(i) : -1;
        }
        if (p.notice() != 0) notice = p.notice();
        version++;
    }

    public static void applyState(MayhemStatePayload p) {
        if (!view.unpack(p.data())) return;
        if (pending.size() < 400) pending.addAll(view.events);
        view.events.clear();
        stateSlot = p.slot();
        stateVersion++;
    }

    public static void clear() {
        hosts = new ArrayList<>();
        open = new ArrayList<>();
        inRoom = inGame = youHost = false;
        notice = 0;
        pending.clear();
        version++;
    }

    /** The last notice (the room is gone, ...), only once. */
    public static int takeNotice() {
        int n = notice;
        notice = 0;
        return n;
    }

    private static void send(int action, int a, int b, String name) {
        dev.cutemod.client.os.Modem.send(new MayhemActionPayload(action, a, b, name));
    }

    public static void request() { send(0, 0, 0, ""); }

    public static void create() { send(1, 0, 0, ""); }

    public static void join(String host) { send(2, 0, 0, host); }

    /** Leave the room (or the round). We forget the room at once, the server confirms later. */
    public static void leave() {
        send(3, 0, 0, "");
        ignoreUntil = System.currentTimeMillis() + 1500;
        inRoom = inGame = false;
        version++;
    }

    public static void slot(int i) { send(4, i, 0, ""); }

    public static void setLevel(int l) { send(5, l, 0, ""); }

    public static void start() { send(6, 0, 0, ""); }

    public static void setLives(int n) { send(8, n, 0, ""); }

    /** The host picks the map: 0..6, or MayhemSim.RANDOM_MAP for a different one every round. */
    public static void setMap(int m) { send(9, m, 0, ""); }

    /** My colour, class and pistol (packed as colour | class << 4 | pistol << 8). */
    public static void setLoad(int packed) { send(10, packed, 0, ""); }

    /** The host picks what the room plays: 0 classic, 1 hill, 2 ladder, 3 teams, 4 bomb, 5 waves. */
    public static void setMode(int m) { send(11, m, 0, ""); }

    /** The keys I hold (MayhemSim.K_*) and what I pressed since the last message (1 jump, 2 fire). */
    public static void input(int bits, int press) { send(7, bits, press, ""); }
}
