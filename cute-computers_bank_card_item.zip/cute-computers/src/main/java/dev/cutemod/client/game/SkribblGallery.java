package dev.cutemod.client.game;

import dev.cutemod.client.os.Store;
import dev.cutemod.data.SkribblCanvas;
import dev.cutemod.data.SkribblWords;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.zip.GZIPInputStream;

/**
 * The pictures of Scribble Pals that the player has seen (drawn or guessed), newest first. They are kept with the rest of the
 * computer's data (Store, "skribbl"), so they follow the player: one line per picture, {@code word|artist|seconds|pixels}, the pixels
 * zipped and written in base64 (a leading B; the first version of the gallery packed two colours to a byte and is still read).
 */
public final class SkribblGallery {
    private SkribblGallery() {}

    public static final int MAX = 24;

    public static final class Entry {
        /** The word as "english|russian". */
        public final String word;
        public final String by;
        public final long time;
        public final byte[] px;
        private int[] runs;

        Entry(String word, String by, long time, byte[] px) {
            this.word = word;
            this.by = by;
            this.time = time;
            this.px = px;
        }

        /** The picture as horizontal runs (x, y, length, colour) without the paper: for drawing it with few rectangles. */
        public int[] runs() {
            if (runs != null) return runs;
            int[] out = new int[256];
            int n = 0;
            for (int y = 0; y < SkribblCanvas.CH; y++) {
                int x = 0;
                while (x < SkribblCanvas.CW) {
                    int c = px[y * SkribblCanvas.CW + x], x0 = x;
                    while (x < SkribblCanvas.CW && px[y * SkribblCanvas.CW + x] == c) x++;
                    if (c == 0) continue;
                    if (n + 4 > out.length) out = java.util.Arrays.copyOf(out, out.length * 2);
                    out[n++] = x0; out[n++] = y; out[n++] = x - x0; out[n++] = c;
                }
            }
            runs = java.util.Arrays.copyOf(out, n);
            return runs;
        }
    }

    private static final List<Entry> entries = new ArrayList<>();
    private static int gen = -1;

    private static void ensure() {
        if (!Store.ready() || gen == Store.gen()) return;
        gen = Store.gen();
        entries.clear();
        String text = Store.read("skribbl");
        if (text == null) return;
        for (String line : text.split("\n")) {
            String[] f = line.split("\\|", 4);
            if (f.length < 4) continue;
            try {
                String word = f[0].matches("\\d+") ? SkribblWords.entry(Math.min(Integer.parseInt(f[0]), SkribblWords.count() - 1)) : f[0].replace(';', '|');
                byte[] px = unpack(f[3]);
                if (px != null) entries.add(new Entry(word, f[1], Long.parseLong(f[2]), px));
            } catch (NumberFormatException ignored) { }
        }
    }

    public static List<Entry> list() {
        ensure();
        return entries;
    }

    public static int count() { return list().size(); }

    /** Keep a picture (the board as it was when the turn ended). Empty boards are not kept. */
    public static void add(String word, String by, byte[] px) {
        ensure();
        if (!Store.ready() || word == null || word.isEmpty()) return;
        boolean ink = false;
        for (byte b : px) if (b != 0) { ink = true; break; }
        if (!ink) return;
        entries.add(0, new Entry(word, by.replace('|', ' ').replace('\n', ' '), System.currentTimeMillis() / 1000L, px.clone()));
        while (entries.size() > MAX) entries.remove(entries.size() - 1);
        save();
    }

    public static void remove(int i) {
        ensure();
        if (i < 0 || i >= entries.size()) return;
        entries.remove(i);
        save();
    }

    private static void save() {
        StringBuilder sb = new StringBuilder();
        for (Entry e : entries) sb.append(e.word.replace('|', ';').replace('\n', ' ')).append('|').append(e.by).append('|').append(e.time).append('|').append(pack(e.px)).append('\n');
        Store.write("skribbl", sb.toString());
        gen = Store.gen();
    }

    private static String pack(byte[] px) {
        return "B" + Base64.getEncoder().withoutPadding().encodeToString(SkribblCanvas.zip(px));
    }

    private static byte[] unpack(String s) {
        try {
            s = s.trim();
            if (s.startsWith("B")) return SkribblCanvas.unzip(Base64.getDecoder().decode(s.substring(1)));
            byte[] zipped = Base64.getDecoder().decode(s);                    // the first version: two colours to a byte
            byte[] two = new GZIPInputStream(new ByteArrayInputStream(zipped)).readAllBytes();
            byte[] px = new byte[SkribblCanvas.CW * SkribblCanvas.CH];
            for (int i = 0; i < px.length && i / 2 < two.length; i++) px[i] = (byte) ((two[i / 2] >> ((i & 1) * 4)) & 15);
            return px;
        } catch (Exception e) {
            return null;
        }
    }
}
