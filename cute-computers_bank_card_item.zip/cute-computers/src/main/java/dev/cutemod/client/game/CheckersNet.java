package dev.cutemod.client.game;

import dev.cutemod.net.CheckersActionPayload;
import dev.cutemod.net.CheckersSyncPayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** The client side of online checkers: what the server last told us, and the messages we send to it. */
public final class CheckersNet {
    private CheckersNet() {}

    /** Free players, the invitations, and the game we are in (opponent is empty if there is none). */
    public static List<String> players = new ArrayList<>();
    public static String invitedBy = "", invitedTo = "", opponent = "";
    public static boolean youWhite = true, whiteTurn = true;
    public static int[] board = new int[64];
    public static int lastFrom = -1, lastTo = -1, result, seq;
    /** Goes up with every message from the server. */
    public static int version;
    private static int notice;
    private static long ignoreUntil;       // right after we left a game, an old message must not bring it back

    public static void apply(CheckersSyncPayload p) {
        players = new ArrayList<>(p.players());
        invitedBy = p.invitedBy();
        invitedTo = p.invitedTo();
        opponent = System.currentTimeMillis() < ignoreUntil ? "" : p.opponent();
        youWhite = p.youWhite();
        whiteTurn = p.whiteTurn();
        int[] b = new int[64];
        for (int i = 0; i < 64 && i < p.board().length; i++) b[i] = p.board()[i];
        board = b;
        lastFrom = p.lastFrom();
        lastTo = p.lastTo();
        result = p.result();
        seq = p.seq();
        if (p.notice() != 0) notice = p.notice();
        version++;
    }

    public static void clear() {
        players = new ArrayList<>();
        invitedBy = invitedTo = opponent = "";
        result = 0;
        notice = 0;
        version++;
    }

    public static boolean inMatch() { return !opponent.isEmpty(); }

    /** The last notice (declined, busy, ...), only once. */
    public static int takeNotice() {
        int n = notice;
        notice = 0;
        return n;
    }

    private static void send(int action, String name, int from, List<Integer> to) {
        dev.cutemod.client.os.Modem.send(new CheckersActionPayload(action, name, from, to));
    }

    public static void request() { send(0, "", 0, List.of()); }

    public static void invite(String name) { send(1, name, 0, List.of()); }

    public static void accept(String name) { send(2, name, 0, List.of()); }

    public static void decline(String name) { send(3, name, 0, List.of()); }

    public static void cancelInvite() { send(6, "", 0, List.of()); }

    public static void move(int from, int[] to) {
        List<Integer> l = new ArrayList<>();
        for (int s : to) l.add(s);
        send(4, "", from, l);
    }

    /** Give up, or leave a finished game. We forget the game at once, the server confirms later. */
    public static void leaveGame() {
        send(5, "", 0, List.of());
        ignoreUntil = System.currentTimeMillis() + 1500;
        opponent = "";
        result = 0;
        version++;
    }
}
