package dev.cutemod.client.os;

import dev.cutemod.data.PetWear;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * PetStyle: a little clothes boutique for your pet. The pet wears up to 5 layers (head, face, neck, body, outer).
 * Three tabs, like three rooms of the shop:
 * <ul>
 *   <li><b>Outfits</b>: 5 hangers keep complete outfits; one click puts an outfit on. Point at one to see it on the pet.</li>
 *   <li><b>Wardrobe</b>: everything you own on shelves, sorted by layer (filter chips on top). A click puts a piece on top
 *       of what the pet already wears, or takes it off. The dice puts together a surprise look.</li>
 *   <li><b>Shop</b>: what is on sale. A click tries a piece on in the fitting room without paying; "Buy" pays for it and
 *       puts it on. Things that cannot be bought (story, show and season prizes) stay behind a lock with a hint.</li>
 * </ul>
 * Only things you own can be worn. The outfits are saved on the server as "wardrobe".
 */
public class StyleApp extends App {
    private static final int SLOTS = 5;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;

    private static final int TAB_X = 126, TAB_W = 56, TABS = 3;
    private static final int PX = 6, PY = 20, PW = 106, PH = 100;                   // the fitting room
    private static final int ROW_X = 118, ROW_Y = 20, ROW_W = 176, ROW_H = 22, ROW_PITCH = 24;
    private static final int SAVE_X = 208, SAVE_W = 38, WEAR_X = 248, WEAR_W = 44;
    private static final int CHIP_X = 118, CHIP_Y = 18, CHIP_W = 29, CHIP_H = 12, CHIPS = 6;
    private static final int GX = 118, GY = 34, CW = 22, COLS = 8, ROWS = 3, RP = 27;   // the shelves
    private static final int INFO_Y = 116, INFO_H = 24, STRIP_Y = 144;

    /** The chips: all, then one layer each. */
    private static final PetWear.Slot[] CAT = {null, PetWear.Slot.HEAD, PetWear.Slot.FACE, PetWear.Slot.NECK, PetWear.Slot.OUTER, PetWear.Slot.BODY};
    private static final PetWear.Slot[] ORDER = {PetWear.Slot.HEAD, PetWear.Slot.FACE, PetWear.Slot.NECK, PetWear.Slot.OUTER, PetWear.Slot.BODY};

    private final String[] head = new String[SLOTS], body = new String[SLOTS];
    private final String[] tryBy = new String[PetWear.Slot.values().length];     // the fitting room: null = what the pet wears
    private final Random rnd = new Random();
    private boolean loaded;
    private int mode, cat, scroll;                                                // mode: 0 outfits, 1 wardrobe, 2 shop
    private String sel = "";
    private int ticks, armed = -1, armT, msgT;
    private String msg = "";

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        if (!loaded) { loaded = true; load(); }
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.style"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.style"); }

    // ---------- save / load ----------
    private void load() {
        for (int i = 0; i < SLOTS; i++) { head[i] = ""; body[i] = ""; }
        try {
            String s = Store.read("wardrobe");
            if (s == null || s.isBlank()) return;
            String[] p = s.split(";", -1);
            for (int i = 0; i < SLOTS && i < p.length; i++) {
                String[] f = p[i].split(",", -1);
                if (f.length >= 2 && ok(f[0]) && ok(f[1])) { head[i] = f[0]; body[i] = f[1]; }
            }
        } catch (Exception ignored) {
        }
    }

    /** Item ids are short words like acc_crown: nothing else is accepted from the save. */
    private static boolean ok(String s) { return s.length() <= 64 && s.matches("[a-z0-9_+]*"); }   // '+' joins the layers of one group

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < SLOTS; i++) sb.append(i > 0 ? ";" : "").append(head[i]).append(',').append(body[i]);
        try { Store.write("wardrobe", sb.toString()); } catch (Exception ignored) { }
    }

    // ---------- outfits ----------
    private boolean filled(int i) { return !head[i].isEmpty() || !body[i].isEmpty(); }

    private void say(String key, Object... args) { msg = t(key, args); msgT = 180; }

    private void chime(float pitch) { Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), pitch, 0.5F); }

    private void saveSlot(int i) {
        String h = Progress.equipped(), b = Progress.equippedBody();
        if (h.isEmpty() && b.isEmpty()) { say("cutemod.style.msg.naked"); return; }
        if (filled(i) && armed != i) { armed = i; armT = 150; say("cutemod.style.msg.sure"); return; }   // overwriting asks twice
        armed = -1;
        head[i] = h;
        body[i] = b;
        chime(1.6F);
        say("cutemod.style.msg.saved", i + 1);
        save();
    }

    private void wear(int i) {
        if (!filled(i)) return;
        int missing = 0;
        Progress.undress();                                              // every layer off, then the saved ones on
        for (String id : PetWear.layers(head[i])) { if (Progress.owned(id)) Progress.equip(id); else missing++; }
        for (String id : PetWear.layers(body[i])) { if (Progress.owned(id)) Progress.equip(id); else missing++; }
        chime(1.9F);
        if (missing > 0) say("cutemod.style.msg.missing", missing); else say("cutemod.style.msg.worn", i + 1);
    }

    private void takeOff() {
        Progress.undress();
        chime(1.0F);
        say("cutemod.style.msg.off");
    }

    /** A surprise look: every layer gets a random piece you own (or stays bare). */
    private void surprise() {
        Progress.undress();
        int n = 0;
        for (PetWear.Slot sl : ORDER) {
            List<String> own = new ArrayList<>();
            for (PetWear.Item it : PetWear.ALL) if (PetWear.slotOf(it.id()) == sl && Progress.owned(it.id())) own.add(it.id());
            if (own.isEmpty() || rnd.nextInt(100) >= (sl == PetWear.Slot.BODY ? 75 : 45)) continue;
            Progress.equip(own.get(rnd.nextInt(own.size())));
            n++;
        }
        chime(1.7F);
        say(n == 0 ? "cutemod.style.msg.surprise.none" : "cutemod.style.msg.surprise");
    }

    // ---------- the shelves ----------
    private void setMode(int m) {
        if (m == mode) return;
        mode = m;
        scroll = 0;
        armed = -1;
        sel = "";
        java.util.Arrays.fill(tryBy, null);
        chime(1.4F);
    }

    private static int today() {
        java.time.LocalDate d = java.time.LocalDate.now();
        return d.getMonthValue() * 100 + d.getDayOfMonth();
    }

    private static boolean canBuy(PetWear.Item w) {
        return w.src() == PetWear.Src.SHOP || (w.src() == PetWear.Src.SEASON && PetWear.onSale(w, today()));
    }

    private static int cost(String id) {
        PetWear.Item w = PetWear.get(id);
        return w == null ? 0 : dev.cutemod.market.Deals.price(id, w.price());
    }

    /** The things on the shelves now: what you own (wardrobe) or what you do not own yet, the buyable ones first (shop). */
    private List<String> items() {
        List<String> out = new ArrayList<>(), locked = new ArrayList<>();
        if (mode == 0) return out;
        for (PetWear.Slot sl : ORDER) {
            if (CAT[cat] != null && CAT[cat] != sl) continue;
            for (PetWear.Item it : PetWear.ALL) {
                if (PetWear.slotOf(it.id()) != sl) continue;
                boolean own = Progress.owned(it.id());
                if (mode == 1) { if (own) out.add(it.id()); continue; }
                if (own || PetWear.STARS_KEY.equals(it.key())) continue;       // the Star Set is a secret until it is won
                (canBuy(it) ? out : locked).add(it.id());
            }
        }
        out.addAll(locked);
        return out;
    }

    private static int maxScroll(int n) { return Math.max(0, (n + COLS - 1) / COLS - ROWS); }

    /** The thing under the mouse on the shelves, or -1. */
    private int itemAt(int x, int y, int n) {
        if (x < GX || y < GY || x >= GX + COLS * CW) return -1;
        int r = (y - GY) / RP;
        if (r >= ROWS || (y - GY) % RP >= 22) return -1;
        int i = (r + scroll) * COLS + (x - GX) / CW;
        return i < n ? i : -1;
    }

    private static boolean in2(int x, int y, int rx, int ry, int rw, int rh) { return in(x, y, rx, ry, rw, rh); }

    private int chipAt(int x, int y) {
        if (mode == 0 || y < CHIP_Y || y >= CHIP_Y + CHIP_H || x < CHIP_X || x >= CHIP_X + CHIPS * CHIP_W) return -1;
        return (x - CHIP_X) / CHIP_W;
    }

    private boolean anyTry() {
        for (String s : tryBy) if (s != null) return true;
        return false;
    }

    /** What the pet would look like: the worn layers (or the fitting room's), with this piece put on or taken off. */
    private String[] look(String hoverId) {
        String[] by = new String[PetWear.Slot.values().length];
        for (PetWear.Slot sl : PetWear.Slot.values()) {
            int k = sl.ordinal();
            by[k] = mode == 2 && tryBy[k] != null ? tryBy[k] : Progress.worn(sl);
        }
        if (hoverId != null) {
            int k = PetWear.slotOf(hoverId).ordinal();
            by[k] = by[k].equals(hoverId) ? "" : hoverId;
        }
        return new String[]{PetWear.pack(by, false), PetWear.pack(by, true)};
    }

    /** Puts a piece on (the piece on the same layer goes off) or takes it off. */
    private void toggle(String id) {
        String name = t("cutemod.shop.item." + id);
        if (Progress.wearing(id)) {
            Progress.unequip(id);
            chime(1.0F);
            say("cutemod.style.msg.takeoff", name);
        } else {
            Progress.equip(id);
            chime(1.9F);
            say("cutemod.style.msg.on", name);
        }
    }

    /** The fitting room: tries a piece on (or off) for the picture only, nothing is paid and nothing really changes. */
    private void tryToggle(String id) {
        int k = PetWear.slotOf(id).ordinal();
        String cur = tryBy[k] != null ? tryBy[k] : Progress.worn(PetWear.slotOf(id));
        tryBy[k] = cur.equals(id) ? "" : id;
        chime(cur.equals(id) ? 1.0F : 1.7F);
    }

    private void buy(String id) {
        PetWear.Item w = PetWear.get(id);
        if (w == null) return;
        if (!canBuy(w)) { say("cutemod.style.msg.locked"); return; }
        int c = cost(id);
        if (Progress.coins() < c) { Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 0.6F, 0.5F); say("cutemod.style.msg.poor", c); return; }
        if (Progress.buy(id, c)) {
            Progress.equip(id);
            tryBy[PetWear.slotOf(id).ordinal()] = null;
            sel = "";
            Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 1.5F, 0.5F);
            say("cutemod.style.msg.bought", t("cutemod.shop.item." + id));
        }
    }

    private int wornCount() {
        int n = 0;
        for (PetWear.Slot sl : PetWear.Slot.values()) if (!Progress.worn(sl).isEmpty()) n++;
        return n;
    }

    @Override
    public boolean scroll(double amount) {
        if (mode == 0) return false;
        scroll = Math.max(0, Math.min(maxScroll(items().size()), scroll + (amount < 0 ? 1 : -1)));
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (keyCode >= 49 && keyCode < 49 + TABS) { setMode(keyCode - 49); return true; }   // 1, 2, 3
        return false;
    }

    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        if (armT > 0 && --armT == 0) armed = -1;
    }

    /** The names of a packed list of layers, joined with commas. */
    private static String itemName(String packed) {
        if (packed.isEmpty()) return "-";
        StringBuilder sb = new StringBuilder();
        for (String id : PetWear.layers(packed)) sb.append(sb.length() > 0 ? ", " : "").append(t("cutemod.shop.item." + id));
        return sb.toString();
    }

    private static String layerName(String id) { return t("cutemod.style.layer." + PetWear.slotOf(id).name().toLowerCase(Locale.ROOT)); }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, 0xFFFDF0F7);
        PetShops.page(g, W, H, ACCENT);
        PetShops.bar(g, W, ACCENT);
        CuteFont.draw(g, f, t("cutemod.os.style"), 5, 3, 0xFFFFFFFF, false);
        for (int i = 0; i < TABS; i++) {                    // the three tabs
            int tx = TAB_X + i * TAB_W;
            boolean sel = i == mode;
            rect(g, tx, 2, TAB_W - 3, 12, sel ? 0xFFFDF0F7 : in(mx, my, tx, 2, TAB_W - 3, 12) ? 0xFFCDA4E8 : 0xFF9A6FD0);
            String tl = f.plainSubstrByWidth(t("cutemod.style.tab." + i), TAB_W - 9);
            CuteFont.draw(g, f, tl, tx + (TAB_W - 3 - f.width(tl)) / 2, 4, sel ? ACCENT : 0xFFFFFFFF, false);
        }
        // which look the fitting room shows: the outfit or the piece under the mouse, the pieces tried on, or what the pet wears now
        String ph = Progress.equipped(), pb = Progress.equippedBody();
        boolean showing = false;
        int hoverRow = -1, hi = -1, chip = chipAt(mx, my);
        String hoverId = null;
        List<String> items = items();
        if (mode == 0) {
            for (int i = 0; i < SLOTS; i++) if (in(mx, my, ROW_X, rowY(i), ROW_W, ROW_H)) hoverRow = i;
            if (hoverRow >= 0 && filled(hoverRow)) { ph = head[hoverRow]; pb = body[hoverRow]; showing = true; }
        } else {
            scroll = Math.min(scroll, maxScroll(items.size()));
            hi = itemAt(mx, my, items.size());
            if (hi >= 0) hoverId = items.get(hi + 0);
            String[] lk = look(hoverId);
            ph = lk[0];
            pb = lk[1];
            showing = hoverId != null || (mode == 2 && anyTry());
        }
        preview(g, f, ph, pb, showing);
        // the buttons under the fitting room
        if (mode == 2) {
            btn(g, f, mx, my, 6, 142, 100, t("cutemod.style.btn.reset"), anyTry() ? 0 : 2);
        } else {
            btn(g, f, mx, my, 6, 142, 66, t("cutemod.style.btn.off"), 0);
            btn(g, f, mx, my, 74, 142, 32, "", 0);
            PetShops.dice(g, 74 + 10, 142 + 2, in(mx, my, 74, 142, 32, 16) ? ACCENT : MUTED);
        }
        if (mode == 0) for (int i = 0; i < SLOTS; i++) row(g, f, i, mx, my);
        else { chips(g, f, mx, my); shelves(g, f, items, hoverId, hi, mx, my); info(g, f, items, hoverId, chip, mx, my); }
        strip(g, f);
    }

    private static int rowY(int i) { return ROW_Y + i * ROW_PITCH; }

    private dev.cutemod.ComputerColor species() {
        dev.cutemod.ComputerColor c = PetApp.speciesOf(shell.color());
        return c == null ? shell.color() : c;
    }

    private void preview(GuiGraphics g, Font f, String h, String b, boolean showing) {
        PetShops.boutique(g, PX, PY, PW, PH, showing, ticks, mode);
        dev.cutemod.ComputerColor spc = species();
        PetBlob.Info info = PetBlob.parse(Store.read("pet_" + spc.id));
        int stage = info == null ? 2 : info.stage();
        int cx = PX + PW / 2, floor = PY + PH - 12 + 3;
        float sc = 1.1F * PetArt.scaleOf(stage);
        int bob = (int) Math.round(Math.sin(ticks / 18.0) * 1.5);
        g.pose().pushPose();
        g.pose().translate(cx, floor, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-cx, -floor, 0);
        PetArt.draw(g, spc, cx, floor - 28 + bob, 2, ticks, false, info != null && info.sick(), stage, h, b);
        g.pose().popPose();
        String l1 = f.plainSubstrByWidth(itemName(h), 102), l2 = f.plainSubstrByWidth(itemName(b), 102);
        CuteFont.draw(g, f, l1, PX + (PW - f.width(l1)) / 2, 122, TEXT, false);
        CuteFont.draw(g, f, l2, PX + (PW - f.width(l2)) / 2, 131, MUTED, false);
    }

    /** The coins and the layers worn, or the last message (a dark bubble) for a few seconds. */
    private void strip(GuiGraphics g, Font f) {
        if (msgT > 0) {
            String m = f.plainSubstrByWidth(msg, 168);
            rect(g, ROW_X, STRIP_Y, ROW_W, 14, 0xEE3A2A3A);
            CuteFont.draw(g, f, m, ROW_X + (ROW_W - f.width(m)) / 2, STRIP_Y + 3, 0xFFFFFFFF, false);
            return;
        }
        rect(g, ROW_X, STRIP_Y, ROW_W, 14, 0xFFF6F0FA);
        rect(g, ROW_X, STRIP_Y + 12, ROW_W, 2, 0xFFE4D8F0);
        String w = t("cutemod.style.count", wornCount(), PetWear.Slot.values().length);
        CuteFont.draw(g, f, w, ROW_X + ROW_W - 6 - f.width(w), STRIP_Y + 3, MUTED, false);
    }

    private void chips(GuiGraphics g, Font f, int mx, int my) {
        for (int i = 0; i < CHIPS; i++) {
            int x = CHIP_X + i * CHIP_W;
            boolean on = i == cat, hov = in(mx, my, x, CHIP_Y, CHIP_W - 2, CHIP_H);
            int bg = on ? ACCENT : hov ? 0xFFFFFFFF : 0xFFF6F0FA;
            rect(g, x, CHIP_Y, CHIP_W - 2, CHIP_H, bg);
            rect(g, x, CHIP_Y + CHIP_H - 2, CHIP_W - 2, 2, on ? 0x33000000 : 0xFFD9C7EA);
            PetShops.chip(g, i, x + (CHIP_W - 2) / 2, CHIP_Y + 5, on ? 0xFFFFFFFF : 0xFF8A6AB8, bg);
        }
    }

    private void shelves(GuiGraphics g, Font f, List<String> items, String hoverId, int hi, int mx, int my) {
        if (items.isEmpty()) {
            String none = f.plainSubstrByWidth(t(mode == 1 ? (cat == 0 ? "cutemod.style.noitems" : "cutemod.style.nolayer") : "cutemod.style.nostock"), 168);
            PetShops.plank(g, GX, GY + 46, COLS * CW - 2);
            CuteFont.draw(g, f, none, GX + (COLS * CW - f.width(none)) / 2, GY + 20, MUTED, false);
            return;
        }
        int coins = Progress.coins();
        for (int r = 0; r < ROWS; r++) {
            int first = (r + scroll) * COLS;
            if (first >= items.size()) break;
            PetShops.plank(g, GX, GY + r * RP + 21, COLS * CW - 2);
        }
        for (int v = 0; v < ROWS * COLS; v++) {
            int idx = scroll * COLS + v;
            if (idx >= items.size()) break;
            String id = items.get(idx);
            int cx = GX + (v % COLS) * CW + 1, cy = GY + (v / COLS) * RP;
            int k = PetWear.slotOf(id).ordinal();
            boolean marked = mode == 1 ? Progress.wearing(id) : id.equals(tryBy[k]);
            boolean hov = idx == hi, picked = id.equals(sel);
            int frame = marked ? ACCENT : hov ? 0xFFFFFFFF : picked ? 0xFFD9C7EA : 0;
            if (frame != 0) rect(g, cx - 1, cy - 1, 22, 22, frame);
            PetArt.icon(g, id, cx, cy, shell.absX(), shell.absY());
            if (marked) PetShops.heart5(g, cx + 14, cy + 1, 0xFFE0508A);
            if (mode == 2) {
                PetWear.Item w = PetWear.get(id);
                if (w != null && canBuy(w)) rect(g, cx + 15, cy + 15, 5, 5, coins >= cost(id) ? 0xFF4CAF50 : 0xFFE5486F);
                else { rect(g, cx, cy, 20, 20, 0xAAF6F0FA); PetShops.lock(g, cx + 8, cy + 6, 0xFF8A7AA8); }
            }
        }
        int rows = (items.size() + COLS - 1) / COLS;           // a thin bar on the right shows where you are in the list
        if (rows > ROWS) {
            int th = ROWS * RP - 3, bh = Math.max(8, th * ROWS / rows), by = GY + (th - bh) * scroll / maxScroll(items.size());
            rect(g, GX + COLS * CW + 1, GY, 3, th, 0xFFE9E2F2);
            rect(g, GX + COLS * CW + 1, by, 3, bh, ACCENT);
        }
    }

    /** The price tag under the shelves: the name, the layer and what to do with the piece (wear it, buy it, or how to get it). */
    private void info(GuiGraphics g, Font f, List<String> items, String hoverId, int chip, int mx, int my) {
        int w = COLS * CW;
        rect(g, GX, INFO_Y, w, INFO_H, 0xFFF6F0FA);
        rect(g, GX, INFO_Y, 3, INFO_H, ACCENT);
        rect(g, GX, INFO_Y + INFO_H - 2, w, 2, 0xFFE4D8F0);
        String id = hoverId != null ? hoverId : items.contains(sel) ? sel : null;
        if (chip >= 0 && hoverId == null) {
            String name = chip == 0 ? t("cutemod.style.cat.0") : t("cutemod.style.layer." + CAT[chip].name().toLowerCase(Locale.ROOT));
            CuteFont.draw(g, f, f.plainSubstrByWidth(name, w - 10), GX + 7, INFO_Y + 8, TEXT, false);
            return;
        }
        if (id == null) {
            String a = f.plainSubstrByWidth(t(mode == 2 ? "cutemod.style.pick.shop" : "cutemod.style.pick"), w - 12);
            CuteFont.draw(g, f, a, GX + 7, INFO_Y + 8, MUTED, false);
            return;
        }
        PetWear.Item pw = PetWear.get(id);
        boolean buyable = mode == 2 && pw != null && canBuy(pw);
        int textW = 112;
        CuteFont.draw(g, f, f.plainSubstrByWidth(t("cutemod.shop.item." + id), textW), GX + 7, INFO_Y + 4, TEXT, false);
        int by = INFO_Y + 14;
        if (mode == 1) {
            String sub = layerName(id) + (Progress.wearing(id) ? " - " + t("cutemod.style.worn") : "");
            CuteFont.draw(g, f, f.plainSubstrByWidth(sub, textW), GX + 7, by, MUTED, false);
        } else if (buyable) {
            String lay = f.plainSubstrByWidth(layerName(id) + " - ", textW - 30);
            CuteFont.draw(g, f, lay, GX + 7, by, MUTED, false);
            String p = Integer.toString(cost(id));
            int px = GX + 7 + f.width(lay);
            CuteFont.draw(g, f, p, px, by, TEXT, false);
            Progress.drawCoin(g, px + f.width(p) + 2, by);
        } else {
            String how = pw != null && !pw.legacy() ? t("cutemod.shop.how." + id) : t("cutemod.style.locked");
            CuteFont.draw(g, f, f.plainSubstrByWidth(how, textW), GX + 7, by, MUTED, false);
        }
        // the button
        int bx = GX + w - 56, bty = INFO_Y + 4;
        if (mode == 1) {
            boolean worn = Progress.wearing(id);
            btn(g, f, mx, my, bx, bty, 52, t(worn ? "cutemod.style.btn.takeoff" : "cutemod.style.btn.wear"), worn ? 0 : 1);
        } else if (buyable) {
            btn(g, f, mx, my, bx, bty, 52, t("cutemod.style.btn.buy"), Progress.coins() >= cost(id) ? 1 : 2);
        } else {
            btn(g, f, mx, my, bx, bty, 52, t("cutemod.style.btn.locked"), 2);
        }
    }

    private void row(GuiGraphics g, Font f, int i, int mx, int my) {
        int y = rowY(i);
        boolean full = filled(i), hov = in(mx, my, ROW_X, y, ROW_W, ROW_H);
        rect(g, ROW_X, y, ROW_W, ROW_H, hov ? 0xFFFFFFFF : 0xFFF6F0FA);
        rect(g, ROW_X, y + ROW_H - 2, ROW_W, 2, 0xFFE4D8F0);
        rect(g, ROW_X, y, 3, ROW_H, full ? ACCENT : 0xFFD9C7EA);
        // a tiny pet wearing the outfit, on a little hanger-shaped plate
        dev.cutemod.ComputerColor spc = species();
        PetBlob.Info info = PetBlob.parse(Store.read("pet_" + spc.id));
        int stage = info == null ? 2 : info.stage();
        rect(g, ROW_X + 6, y + 3, 26, 16, full ? 0xFFFFF3F8 : 0xFFEFE7F6);
        if (full) {
            int cx = ROW_X + 19, floor = y + 20;
            float sc = 0.3F * PetArt.scaleOf(stage);
            g.pose().pushPose();
            g.pose().translate(cx, floor, 0);
            g.pose().scale(sc, sc, 1F);
            g.pose().translate(-cx, -floor, 0);
            PetArt.draw(g, spc, cx, floor - 28, 2, ticks, false, false, stage, head[i], body[i]);
            g.pose().popPose();
        } else {
            PetShops.chip(g, 4, ROW_X + 19, y + 11, 0xFFD2C4E4, 0xFFEFE7F6);
        }
        CuteFont.draw(g, f, t("cutemod.style.outfit", i + 1), ROW_X + 38, y + 3, full ? TEXT : MUTED, false);
        String names = full ? itemName(body[i].isEmpty() ? head[i] : head[i].isEmpty() ? body[i] : body[i] + PetWear.SEP + head[i]) : t("cutemod.style.empty");
        CuteFont.draw(g, f, f.plainSubstrByWidth(names, SAVE_X - ROW_X - 42), ROW_X + 38, y + 12, MUTED, false);
        btn(g, f, mx, my, SAVE_X, y + 3, SAVE_W, armed == i ? t("cutemod.style.btn.sure") : t("cutemod.style.btn.save"), armed == i ? 3 : 0);
        btn(g, f, mx, my, WEAR_X, y + 3, WEAR_W, t("cutemod.style.btn.wear"), full ? 1 : 2);
    }

    /** style 0 normal, 1 main, 2 dimmed, 3 warning. */
    private void btn(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, String label, int style) {
        boolean hov = style != 2 && in(mx, my, x, y, w, 16);
        int bg = style == 1 ? (hov ? 0xFF9A6FD0 : ACCENT) : style == 2 ? 0xFFE9E2F2 : style == 3 ? 0xFFE5486F : hov ? 0xFFE4D8FF : 0xFFFFFFFF;
        rect(g, x, y, w, 16, bg);
        rect(g, x, y + 14, w, 2, style == 1 || style == 3 ? 0x33000000 : 0xFFB9A8C8);
        String l = f.plainSubstrByWidth(label, w - 4);
        CuteFont.draw(g, f, l, x + (w - f.width(l)) / 2, y + 4, style == 1 || style == 3 ? 0xFFFFFFFF : style == 2 ? 0xFFB8A8D8 : TEXT, false);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < TABS; i++) if (in(x, y, TAB_X + i * TAB_W, 2, TAB_W - 3, 12)) { setMode(i); return true; }
        // the buttons under the fitting room
        if (mode == 2) {
            if (in(x, y, 6, 142, 100, 16)) { if (anyTry()) { java.util.Arrays.fill(tryBy, null); chime(1.0F); } return true; }
        } else {
            if (in(x, y, 6, 142, 66, 16)) { takeOff(); return true; }
            if (in(x, y, 74, 142, 32, 16)) { surprise(); return true; }
        }
        if (mode == 0) {
            for (int i = 0; i < SLOTS; i++) {
                int ry = rowY(i) + 3;
                if (in(x, y, SAVE_X, ry, SAVE_W, 16)) { saveSlot(i); return true; }
                if (in(x, y, WEAR_X, ry, WEAR_W, 16)) { wear(i); return true; }
            }
            return false;
        }
        int chip = chipAt(x, y);
        if (chip >= 0) { if (chip != cat) { cat = chip; scroll = 0; chime(1.5F); } return true; }
        List<String> items = items();
        int idx = itemAt(x, y, items.size());
        if (idx >= 0) {
            String id = items.get(idx);
            sel = id;
            if (mode == 1) toggle(id); else tryToggle(id);
            return true;
        }
        // the button of the price tag
        if (in2(x, y, GX + COLS * CW - 56, INFO_Y + 4, 52, 16) && items.contains(sel)) {
            if (mode == 1) toggle(sel); else buy(sel);
            return true;
        }
        return false;
    }
}
