package dev.cutemod.client.os;

import dev.cutemod.data.PcHardware;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The internet of the computer. It comes from a Wi-Fi router (a block, see {@link Wifi}) that the computer is connected to and that is
 * within reach; the old modem part inside the PC still works as a cable. Without a connection nothing online works; the weak routers
 * also lose the connection now and then, and the better the router the faster the downloads.
 * What needs the net: apps that say so ({@link App#needsNet()}), everything that is sent to the server for online games, CuteNet and Tube
 * ({@link #send}), and buying or installing in CuteStore.
 */
public final class Modem {
    private Modem() {}

    /** The connected Wi-Fi network (null: none, or out of range). Looked at once per frame, many callers ask in one frame. */
    private static Wifi.Net wifi;
    private static long wifiAt = -1;

    private static Wifi.Net net() {
        long now = System.currentTimeMillis();
        if (now - wifiAt > 100) { wifi = Wifi.current(); wifiAt = now; }
        return wifi;
    }

    /** The old modem part inside the PC (it is not sold any more): works like a cable when no Wi-Fi is connected. Level -1 / 0 = none, 1..5. */
    private static int cableLevel() { return Math.max(0, PcSpecs.get().modemIdx()); }

    /** Level of the connection: the connected Wi-Fi network, else the cable (the old modem part). 0 = nothing, 1..5. */
    public static int level() {
        Wifi.Net n = net();
        return n != null ? n.level() : cableLevel();
    }

    public static boolean has() { return level() >= 1; }

    /** The connection exists but is out at this moment (the weak routers lose it now and then). */
    public static boolean down() {
        var p = Minecraft.getInstance().player;
        return PcHardware.modemDown(level(), PcHardware.seedOf(p == null ? null : p.getUUID()), System.currentTimeMillis());
    }

    public static boolean connected() { return has() && !down(); }

    /** Download speed, 1.0 = normal. A weak signal (few bars) is a bit slower. */
    public static double speed() {
        Wifi.Net n = net();
        double base = PcHardware.modemSpeed(level());
        return n == null ? base : base * dev.cutemod.data.WifiNet.barsSpeed(n.bars());
    }

    /** True for an app that needs the net while there is none: the window shows "No connection" and does not react. */
    public static boolean blocks(App app) { return app != null && app.needsNet() && !connected(); }

    private static long lastNote;

    /** A short pop-up "no internet" (at most every 6 seconds). */
    public static void note() {
        long now = System.currentTimeMillis();
        if (now - lastNote < 6000) return;
        lastNote = now;
        Progress.toast(has() ? "cutemod.toast.net_down" : "cutemod.toast.net_none");
    }

    /** Sends something to the server through the modem: with no connection it is lost (and the player is told). */
    public static void send(CustomPacketPayload p) {
        if (!connected()) { note(); return; }
        PacketDistributor.sendToServer(p);
    }

    /** Like {@link #send}, but silent (pings and polls that happen all the time). */
    public static void sendQuiet(CustomPacketPayload p) {
        if (connected()) PacketDistributor.sendToServer(p);
    }

    /** The "No connection" screen drawn over an app window (local coordinates, App.W x App.H). */
    public static void overlay(GuiGraphics g) {
        var f = Minecraft.getInstance().font;
        boolean none = !has();
        boolean range = none && Wifi.picked();                                  // a network is picked, but its router is too far
        g.fill(0, 0, App.W, App.H, 0xFF20182E);
        int cx = App.W / 2, cy = App.H / 2 - 22;
        int c = none ? 0xFFE5484D : 0xFFF0B820;
        g.fill(cx - 12, cy + 10, cx - 8, cy + 14, c);                          // a little signal: bars, crossed out
        g.fill(cx - 6, cy + 6, cx - 2, cy + 14, c);
        g.fill(cx, cy + 2, cx + 4, cy + 14, c);
        g.fill(cx + 6, cy - 2, cx + 10, cy + 14, c);
        for (int i = -14; i <= 12; i++) g.fill(cx + i, cy + 14 - (i + 14) * 16 / 26, cx + i + 2, cy + 16 - (i + 14) * 16 / 26, 0xFFFFFFFF);
        String title = net.minecraft.network.chat.Component.translatable(range ? "cutemod.net.range" : none ? "cutemod.net.nomodem" : "cutemod.net.down").getString();
        String hint = net.minecraft.network.chat.Component.translatable(range ? "cutemod.net.range.hint" : none ? "cutemod.net.nomodem.hint" : "cutemod.net.down.hint").getString();
        g.drawCenteredString(f, title, cx, cy + 24, 0xFFFFFFFF);
        g.drawCenteredString(f, hint, cx, cy + 37, 0xFFB8A9D4);
        if (!none) {
            int dots = (int) (System.currentTimeMillis() / 400 % 4);
            g.drawCenteredString(f, ".".repeat(dots), cx, cy + 50, 0xFFF0B820);
        }
    }
}
