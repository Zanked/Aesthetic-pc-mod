package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;

import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;
import java.util.Locale;

/**
 * The Explorer, like the one of Windows: a toolbar (back, up, the address), a side bar (quick access, This PC, the
 * drives) and the list of what is in the folder. The "files" are the real things of this computer: your notes, the
 * wallpapers and songs you own, the installed apps and games (with their real sizes) and the folders of your desktop.
 * "This PC" shows the drives and the random hardware of this computer ({@link PcSpecs}). A double click opens.
 */
public class ExplorerApp extends App {
    private static final int INK = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6, BG = 0xFFFFFFFF, BAR = 0xFFEDE3F5,
            SIDE = 0xFFF4ECFA, SEL = 0xFFE3D2F2, HOVER = 0xFFF0E6F8, DANGER = 0xFFE5484D, GOOD = 0xFF34C759;
    private static final int TB_H = 17, SB_W = 98, STATUS_H = 12, HDR_Y = TB_H + 1, HDR_H = 11, ROW0 = HDR_Y + HDR_H, ROW_H = 12;
    private static final int VISIBLE = (H - STATUS_H - ROW0) / ROW_H;
    private static final int DOUBLE_TICKS = 28;

    // All the text of the Explorer has ONE size. What does not fit is cut with "..." (names) or a shorter wording is
    // taken (the CPU line), it is never squeezed into a smaller font: that is what made the old Explorer look untidy.
    private static String cut(Font f, String s, int maxW) {
        if (maxW <= 0) return "";
        if (f.width(s) <= maxW) return s;
        String dots = "...";
        return f.plainSubstrByWidth(s, Math.max(0, maxW - f.width(dots))) + dots;
    }

    /** The first candidate that fits into maxW (the last one, cut, if none does). */
    private static String pick(Font f, int maxW, String... candidates) {
        for (String c : candidates) if (f.width(c) <= maxW) return c;
        return cut(f, candidates[candidates.length - 1], maxW);
    }

    private static void put(GuiGraphics g, Font f, String s, int x, int y, int maxW, int color) {
        CuteFont.draw(g, f, cut(f, s, maxW), x, y, color, false);
    }

    /** The address: the whole way if it fits, else "... > the last folders" (like the real Explorer). */
    private String address(Font f, int maxW) {
        String sep = "  >  ";
        List<String> parts = new ArrayList<>();
        parts.add(t("cutemod.explorer.thispc"));
        for (String k : path) parts.add(label(k));
        for (int from = 0; from < parts.size(); from++) {
            StringBuilder b = new StringBuilder(from > 0 ? "..." : "");
            for (int i = from; i < parts.size(); i++) {
                if (b.length() > 0) b.append(sep);
                b.append(parts.get(i));
            }
            if (f.width(b.toString()) <= maxW) return b.toString();
        }
        return cut(f, parts.get(parts.size() - 1), maxW);
    }

    /** One line of a folder: kind 0 folder, 1 file, 2 text, 3 picture, 4 music, 5 app (icon = the Dock number). */
    private record Entry(String key, String name, boolean folder, long bytes, int kind, int icon, Runnable open, String note) {}

    /** One line of the side bar. */
    private record Side(String label, List<String> path, int icon, boolean head) {}

    private final List<String> path = new ArrayList<>();
    private final Deque<List<String>> back = new ArrayDeque<>();
    private List<Entry> cache;
    private int scroll, sel = -1, ticks, lastClickTick = -1000, lastClickIdx = -2, mx = -1, my = -1, flashT;
    private String flash = "";

    @Override
    public Component title() { return Component.translatable("cutemod.os.explorer"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.explorer.hint"); }

    @Override
    public void mouse(int x, int y) { mx = x; my = y; }

    @Override
    public void tick() {
        ticks++;
        if (flashT > 0) flashT--;
        if (ticks % 30 == 0) cache = null;          // the contents can change (an app got installed, a note was written)
    }

    // ---------- the tree ----------
    private static String me() {
        var p = Minecraft.getInstance().player;
        String n = p == null ? "Player" : p.getGameProfile().getName();
        return n == null || n.isBlank() ? "Player" : n;
    }

    private static List<String> userPath(String dir) { return List.of("C:", "users", "me", dir); }

    private static String label(String key) {
        if (key.startsWith("f") && key.length() > 1 && Character.isDigit(key.charAt(1))) {
            try { return Folders.name(Integer.parseInt(key.substring(1))); } catch (NumberFormatException ignored) { return key; }
        }
        return switch (key) {
            case "C:" -> t("cutemod.explorer.drive.c");
            case "D:" -> t("cutemod.explorer.drive.d");
            case "me" -> me();
            default -> t("cutemod.explorer.dir." + key);
        };
    }

    private void go(List<String> p, boolean remember) {
        if (remember && !p.equals(path)) {
            back.push(new ArrayList<>(path));
            while (back.size() > 30) back.removeLast();
        }
        path.clear();
        path.addAll(p);
        scroll = 0;
        sel = -1;
        cache = null;
    }

    private void up() { if (!path.isEmpty()) go(new ArrayList<>(path.subList(0, path.size() - 1)), true); }

    private void goBack() { if (!back.isEmpty()) go(back.pop(), false); }

    private void say(String s) { flash = s; flashT = 150; }

    private void launch(int icon) {
        if (!Library.available(icon)) { say(t("cutemod.explorer.noapp")); return; }
        shell.home();                                   // the Explorer closes, the app opens (like a folder does)
        shell.launch(icon);
    }

    // ---------- what is in a folder ----------
    private static Entry dir(String key) { return new Entry(key, label(key), true, 0, 0, -1, null, ""); }

    private static Entry file(String name, long bytes, int kind, Runnable open) { return new Entry(null, name, false, bytes, kind, -1, open, ""); }

    private Entry app(String name, int icon, int mb) {
        return new Entry(null, name + ".exe", false, mb * 1048576L, 5, icon, () -> launch(icon), "");
    }

    private List<Entry> entries() {
        if (cache == null) cache = build();
        return cache;
    }

    private List<Entry> build() {
        List<Entry> l = new ArrayList<>();
        String last = path.isEmpty() ? "" : path.get(path.size() - 1);
        PcSpecs.Spec s = PcSpecs.get();
        switch (last) {
            case "" -> { }
            case "C:" -> { l.add(dir("pf")); l.add(dir("users")); l.add(dir("win")); }
            case "D:" -> { if (s.diskD() > 0) l.add(dir("backup")); }
            case "backup" -> { }
            case "pf" -> {
                for (Library.Program p : Library.PROGRAMS) if (!Library.placeOnly(p.id()) && Library.installed(p.id())) l.add(app(Desktop.nameOf(p.icon()), p.icon(), Library.sizeOf(p.id())));
                l.add(dir("games"));
            }
            case "games" -> {
                for (Library.Game gm : Library.GAMES) if (Library.installed(gm.id())) l.add(app(Library.name(gm.id()), Items.ofGame(gm.id()), Library.sizeOf(gm.id())));
            }
            case "users" -> l.add(dir("me"));
            case "me" -> { l.add(dir("desk")); l.add(dir("docs")); l.add(dir("pics")); l.add(dir("music")); }
            case "desk" -> {
                for (int f : Folders.all()) l.add(new Entry("f" + f, Folders.name(f), true, 0, 0, f, null, ""));
            }
            case "docs" -> {
                String n = Store.read("notes");
                if (n != null && !n.isBlank()) l.add(file("notes.txt", n.getBytes(StandardCharsets.UTF_8).length, 2, () -> launch(3)));
            }
            case "pics" -> {
                for (int i = 0; i < Wallpaper.COUNT; i++) {
                    if (i >= Wallpaper.BASE && !Progress.owned("wall" + i)) continue;
                    final int w = i;
                    long size = (180 + (i * 37L) % 400) * 1024L;
                    l.add(new Entry(null, "wallpaper_" + i + ".png", false, size, 3, -1, () -> { if (Wallpaper.locked()) { say(t("cutemod.os.set.wall.locked")); return; } Wallpaper.set(w); cache = null; say(t("cutemod.explorer.wallset")); },
                            Wallpaper.get() == i ? t("cutemod.explorer.current") : ""));
                }
            }
            case "music" -> {
                for (Albums.Album a : Albums.all()) {
                    if (!a.owned()) continue;
                    for (Albums.Track tr : a.tracks()) {
                        long size = Math.max(30, tr.seconds()) * 160_000L;
                        l.add(file(tr.title() + ".ogg", size, 4, () -> launch(7)));
                    }
                }
            }
            case "win" -> {
                l.add(dir("sys32"));
                l.add(file("cuteos.sys", 4_200_000L, 1, null));
                l.add(file("boot.ini", 312, 2, null));
            }
            case "sys32" -> {
                l.add(file("cutekernel.dll", 1_800_000L, 1, null));
                l.add(file("honey32.dll", 640_000L, 1, null));
                l.add(file("pixelgfx.dll", 2_400_000L, 1, null));
                l.add(file("beeservice.exe", 96_000L, 1, null));
            }
            default -> {
                if (last.startsWith("f") && last.length() > 1 && Character.isDigit(last.charAt(1))) {
                    try {
                        for (int item : Folders.items(Integer.parseInt(last.substring(1)))) {
                            final int ic = item;
                            l.add(new Entry(null, Desktop.nameOf(item), false, 1024, 5, item, () -> launch(ic), ""));
                        }
                    } catch (NumberFormatException ignored) { }
                }
            }
        }
        l.sort(Comparator.comparing((Entry e) -> !e.folder()));            // folders first, the order inside stays
        return l;
    }

    private void open(Entry e) {
        if (e.folder()) {
            List<String> p = new ArrayList<>(path);
            p.add(e.key());
            go(p, true);
        } else if (e.open() != null) {
            e.open().run();
        } else {
            say(t("cutemod.explorer.cantopen"));
        }
    }

    // ---------- disk space ----------
    private static long usedCMb(PcSpecs.Spec s) { return Library.usedMb(); }

    private static String one(double d) { return d >= 100 ? Long.toString(Math.round(d)) : String.format(Locale.ROOT, "%.1f", d); }

    private static String size(long b) {
        if (b < 1024) return b + " B";
        if (b < 1048576L) return one(b / 1024.0) + " KB";
        if (b < 1073741824L) return one(b / 1048576.0) + " MB";
        return one(b / 1073741824.0) + " GB";
    }

    // ---------- the side bar ----------
    private List<Side> sideItems() {
        List<Side> l = new ArrayList<>();
        l.add(new Side(t("cutemod.explorer.quick"), List.of(), 0, true));
        for (String k : new String[]{"desk", "docs", "pics", "music"}) l.add(new Side(label(k), userPath(k), 0, false));
        l.add(new Side(t("cutemod.explorer.side.thispc"), List.of(), 1, false));
        l.add(new Side(t("cutemod.explorer.side.c"), List.of("C:"), 2, false));
        if (PcSpecs.get().diskD() > 0) l.add(new Side(t("cutemod.explorer.side.d"), List.of("D:"), 2, false));
        return l;
    }

    private boolean current(Side s) {
        if (s.head()) return false;
        if (s.icon() == 1) return path.isEmpty();
        if (s.icon() == 2) return path.size() == 1 && path.get(0).equals(s.path().get(0));
        return path.size() >= 4 && path.get(3).equals(s.path().get(3));
    }

    private static final int SIDE_Y = TB_H + 4;

    private int sideRowY(int idx, List<Side> items) {
        int y = SIDE_Y;
        for (int i = 0; i < idx; i++) y += items.get(i).head() ? 11 : 12;
        return y;
    }

    // ---------- pictures ----------
    private static void folderIcon(GuiGraphics g, int x, int y) {
        rect(g, x, y + 1, 4, 2, 0xFFE0A22A);
        rect(g, x, y + 2, 10, 7, 0xFFF0B83A);
        rect(g, x, y + 4, 10, 5, 0xFFFFD36B);
    }

    private static void fileIcon(GuiGraphics g, int x, int y, int fold) {
        rect(g, x + 1, y, 8, 10, 0xFFFFFFFF);
        rect(g, x + 1, y, 8, 1, 0xFFB9A8C8); rect(g, x + 1, y + 9, 8, 1, 0xFFB9A8C8);
        rect(g, x + 1, y, 1, 10, 0xFFB9A8C8); rect(g, x + 8, y, 1, 10, 0xFFB9A8C8);
        rect(g, x + 6, y, 3, 3, fold);
    }

    private static void pcIcon(GuiGraphics g, int x, int y) {
        rect(g, x, y + 1, 10, 6, 0xFF6F7788);
        rect(g, x + 1, y + 2, 8, 4, 0xFF8FD3FF);
        rect(g, x + 4, y + 7, 2, 1, 0xFF6F7788);
        rect(g, x + 2, y + 8, 6, 1, 0xFF6F7788);
    }

    private static void driveIcon(GuiGraphics g, int x, int y) {
        rect(g, x, y + 3, 10, 5, 0xFFB8BFCC);
        rect(g, x, y + 7, 10, 1, 0xFF6F7788);
        rect(g, x + 7, y + 5, 2, 1, GOOD);
    }

    private static void entryIcon(GuiGraphics g, Entry e, int x, int y) {
        switch (e.kind()) {
            case 0 -> folderIcon(g, x, y);
            case 2 -> {
                fileIcon(g, x, y, 0xFFD8CCE2);
                rect(g, x + 3, y + 4, 4, 1, MUTED); rect(g, x + 3, y + 6, 4, 1, MUTED); rect(g, x + 3, y + 8, 3, 1, MUTED);
            }
            case 3 -> {
                rect(g, x, y + 1, 10, 8, 0xFF8FD3FF);
                rect(g, x, y + 6, 10, 3, 0xFF6AC85A);
                disc(g, x + 7, y + 3, 1, 0xFFFFE066);
            }
            case 4 -> {
                rect(g, x, y, 10, 10, 0xFF8A6AC6);
                disc(g, x + 4, y + 7, 2, 0xFFFFFFFF);
                rect(g, x + 5, y + 2, 1, 6, 0xFFFFFFFF);
                rect(g, x + 5, y + 2, 3, 1, 0xFFFFFFFF);
            }
            case 5 -> {
                g.pose().pushPose();
                g.pose().translate(x, y, 0);
                g.pose().scale(0.32F, 0.32F, 1F);
                Desktop.drawIcon(g, e.icon(), 0, 0, 0xFF8A7AA8);
                g.pose().popPose();
            }
            default -> fileIcon(g, x, y, 0xFFD8CCE2);
        }
    }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, BG);
        // toolbar
        rect(g, 0, 0, W, TB_H, BAR);
        button(g, f, 4, "<", !back.isEmpty(), mx, my);
        button(g, f, 18, "^", !path.isEmpty(), mx, my);
        roundRect(g, 34, 2, W - 38, 13, 4, 0xFFFFFFFF);
        CuteFont.draw(g, f, address(f, W - 48), 39, 4, INK, false);
        // side bar
        rect(g, 0, TB_H, SB_W, H - TB_H - STATUS_H, SIDE);
        List<Side> side = sideItems();
        for (int i = 0; i < side.size(); i++) {
            Side s = side.get(i);
            int y = sideRowY(i, side);
            if (s.head()) { put(g, f, s.label(), 5, y, SB_W - 8, MUTED); continue; }
            boolean cur = current(s), hov = in(mx, my, 2, y, SB_W - 4, 12);
            if (cur || hov) roundRect(g, 2, y, SB_W - 4, 12, 3, cur ? SEL : HOVER);
            int ix = s.icon() == 2 ? 8 : 5;
            switch (s.icon()) {
                case 1 -> pcIcon(g, ix, y + 1);
                case 2 -> driveIcon(g, ix, y + 1);
                default -> folderIcon(g, ix, y + 1);
            }
            put(g, f, s.label(), ix + 14, y + 2, SB_W - ix - 18, INK);
        }
        // the page
        if (path.isEmpty()) drawThisPc(g, f);
        else drawList(g, f, mx, my);
        // status bar
        rect(g, 0, H - STATUS_H, W, STATUS_H, BAR);
        List<Entry> es = path.isEmpty() ? List.of() : entries();
        String left;
        if (path.isEmpty()) left = t("cutemod.explorer.devices", PcSpecs.get().diskD() > 0 ? 2 : 1);
        else if (sel >= 0 && sel < es.size()) {
            Entry e = es.get(sel);
            left = e.folder() ? e.name() : e.name() + "   " + size(e.bytes());
        } else left = t("cutemod.explorer.items", es.size());
        int flashW = flashT > 0 ? Math.min(f.width(flash), W * 2 / 5) : 0;
        int leftMax = W - 10 - (flashW > 0 ? flashW + 10 : 0);
        CuteFont.draw(g, f, cut(f, left, leftMax), 5, H - STATUS_H + 2, INK, false);
        if (flashT > 0) {
            String fl = cut(f, flash, flashW);
            CuteFont.draw(g, f, fl, W - 5 - f.width(fl), H - STATUS_H + 2, ACCENT, false);
        }
    }

    private void button(GuiGraphics g, Font f, int x, String s, boolean on, int mx, int my) {
        boolean hov = on && in(mx, my, x, 3, 12, 11);
        roundRect(g, x, 3, 12, 11, 3, hov ? 0xFFD9C4EC : 0xFFFFFFFF);
        CuteFont.draw(g, f, s, x + 6 - f.width(s) / 2, 4, on ? INK : 0xFFC9BCD6, false);
    }

    private void drawList(GuiGraphics g, Font f, int mx, int my) {
        List<Entry> es = entries();
        int px = SB_W;
        rect(g, px, HDR_Y, W - px, HDR_H, BAR);
        CuteFont.draw(g, f, t("cutemod.explorer.name"), px + 18, HDR_Y + 2, MUTED, false);
        String sz = t("cutemod.explorer.size");
        CuteFont.draw(g, f, sz, W - 8 - f.width(sz), HDR_Y + 2, MUTED, false);
        int maxScroll = Math.max(0, es.size() - VISIBLE);
        scroll = Math.min(scroll, maxScroll);
        if (es.isEmpty()) {
            String s = cut(f, t("cutemod.explorer.empty"), W - px - 8);
            CuteFont.draw(g, f, s, px + (W - px - f.width(s)) / 2, ROW0 + 30, MUTED, false);
            return;
        }
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= es.size()) break;
            Entry e = es.get(idx);
            int y = ROW0 + v * ROW_H;
            boolean hov = in(mx, my, px, y, W - px - 4, ROW_H);
            rect(g, px, y, W - px, ROW_H, idx == sel ? SEL : hov ? HOVER : (v % 2 == 0 ? 0xFFFFFFFF : 0xFFFBF7FD));
            entryIcon(g, e, px + 4, y + 1);
            String right = cut(f, !e.note().isEmpty() ? e.note() : e.folder() ? "" : size(e.bytes()), 64);
            int rw = f.width(right);
            put(g, f, e.name(), px + 18, y + 2, W - px - 18 - rw - 14, INK);
            if (!right.isEmpty()) CuteFont.draw(g, f, right, W - 8 - rw, y + 2, e.note().isEmpty() ? MUTED : GOOD, false);
        }
        if (maxScroll > 0) {
            int th = Math.max(8, VISIBLE * ROW_H * VISIBLE / es.size());
            rect(g, W - 3, ROW0, 3, VISIBLE * ROW_H, 0xFFE9DDF2);
            rect(g, W - 3, ROW0 + (VISIBLE * ROW_H - th) * scroll / maxScroll, 3, th, ACCENT);
        }
    }

    private static final int TILE_H = 26;

    private int driveTileY(int i) { return TB_H + 4 + 11 + i * (TILE_H + 2); }

    private void drawThisPc(GuiGraphics g, Font f) {
        PcSpecs.Spec s = PcSpecs.get();
        int x = SB_W + 6, pw = W - x - 6, y0 = TB_H + 4;
        put(g, f, t("cutemod.explorer.devices.title"), x, y0, pw, MUTED);
        int drives = s.diskD() > 0 ? 2 : 1;
        for (int i = 0; i < drives; i++) {
            int y = driveTileY(i);
            boolean c = i == 0;
            long total = (c ? s.diskC() : s.diskD()) * 1024L;                     // in MB
            long used = c ? usedCMb(s) : total * s.usedDPct() / 100;
            used = Math.min(used, total);
            boolean hov = in(mx, my, x, y, pw, TILE_H);
            roundRect(g, x, y, pw, TILE_H, 4, hov ? HOVER : 0xFFFBF7FD);
            driveIcon(g, x + 4, y + 6);
            String name = t(c ? "cutemod.explorer.drive.c" : "cutemod.explorer.drive.d");
            put(g, f, name, x + 20, y + 3, pw - 24, INK);
            int bw = pw - 28;
            rect(g, x + 20, y + 13, bw, 5, 0xFFE3D8EE);
            int fill = (int) (bw * (used / (double) total));
            rect(g, x + 20, y + 13, Math.max(1, fill), 5, used / (double) total > 0.9 ? DANGER : ACCENT);
            String free = t("cutemod.explorer.free", size((total - used) * 1048576L), size(total * 1048576L));
            CuteFont.draw(g, f, cut(f, free, bw), x + 20, y + 19 - 1, MUTED, false);
        }
        int cy = driveTileY(drives) + 2;
        String pc = s.pcName();
        int pcW = f.width(pc);
        put(g, f, t("cutemod.explorer.about"), x, cy, pw - pcW - 10, MUTED);
        CuteFont.draw(g, f, pc, x + pw - pcW, cy, ACCENT, false);
        // the labels get one column as wide as the longest one, the values the rest (the most detailed wording that fits)
        String[] names = {t("cutemod.explorer.cpu"), t("cutemod.explorer.ram"), t("cutemod.explorer.gpu"), t("cutemod.explorer.disk"), t("cutemod.explorer.score")};
        int lw = 0;
        for (String n : names) lw = Math.max(lw, f.width(n));
        lw += 8;
        int vw = pw - lw;
        String ghz = one(s.ghz()) + " GHz";
        String gpuFull = s.vramGb() > 0 ? s.gpu() + " (" + s.vramGb() + " GB)" : s.gpu();
        String disks = PcSpecs.gb(s.diskC()) + (s.diskD() > 0 ? " + " + PcSpecs.gb(s.diskD()) : "");
        String[] values = {
                pick(f, vw, s.cpu() + " - " + t("cutemod.explorer.cores", s.cores()) + " - " + ghz, s.cpu() + " - " + ghz, s.cpu()),
                PcSpecs.gb(s.ramGb()),
                pick(f, vw, gpuFull, s.gpu()),
                pick(f, vw, disks, PcSpecs.gb(s.diskC())),
        };
        int ry = cy + 11;
        for (int i = 0; i < 4; i++) {
            put(g, f, names[i], x, ry, lw - 4, MUTED);
            put(g, f, values[i], x + lw, ry, vw, INK);
            ry += 10;
        }
        put(g, f, names[4], x, ry, lw - 4, MUTED);
        String sc = PcSpecs.score(s) + " / 10";
        int bw = Math.max(30, Math.min(90, vw - f.width(sc) - 8));
        rect(g, x + lw, ry + 2, bw, 5, 0xFFE3D8EE);
        int col = s.score() >= 7 ? GOOD : s.score() >= 4 ? 0xFFF0B820 : DANGER;
        rect(g, x + lw, ry + 2, (int) (bw * s.score() / 10.0), 5, col);
        CuteFont.draw(g, f, sc, x + lw + bw + 5, ry, INK, false);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (button == 3 || button == 4) { goBack(); return true; }       // the mouse "back" button
        if (button != 0) return false;
        if (in(x, y, 4, 3, 12, 11)) { goBack(); return true; }
        if (in(x, y, 18, 3, 12, 11)) { up(); return true; }
        List<Side> side = sideItems();
        for (int i = 0; i < side.size(); i++) {
            Side s = side.get(i);
            if (s.head()) continue;
            if (in(x, y, 2, sideRowY(i, side), SB_W - 4, 12)) { go(s.path(), true); return true; }
        }
        if (path.isEmpty()) {
            int drives = PcSpecs.get().diskD() > 0 ? 2 : 1;
            int px = SB_W + 6, pw = W - px - 6;
            for (int i = 0; i < drives; i++) {
                if (!in(x, y, px, driveTileY(i), pw, TILE_H)) continue;
                if (lastClickIdx == 100 + i && ticks - lastClickTick < DOUBLE_TICKS) { go(List.of(i == 0 ? "C:" : "D:"), true); lastClickIdx = -2; }
                else { lastClickIdx = 100 + i; lastClickTick = ticks; }
                return true;
            }
            return false;
        }
        List<Entry> es = entries();
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= es.size()) break;
            if (!in(x, y, SB_W, ROW0 + v * ROW_H, W - SB_W - 4, ROW_H)) continue;
            if (idx == lastClickIdx && ticks - lastClickTick < DOUBLE_TICKS) { open(es.get(idx)); lastClickIdx = -2; }
            else { sel = idx; lastClickIdx = idx; lastClickTick = ticks; }
            return true;
        }
        sel = -1;
        return true;
    }

    @Override
    public boolean scroll(double amount) {
        if (path.isEmpty()) return false;
        int max = Math.max(0, entries().size() - VISIBLE);
        scroll = Math.max(0, Math.min(max, scroll + (amount < 0 ? 1 : -1)));
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        List<Entry> es = path.isEmpty() ? List.of() : entries();
        switch (keyCode) {
            case 259 -> up();                                                    // backspace
            case 257, 335 -> { if (sel >= 0 && sel < es.size()) open(es.get(sel)); }   // enter
            case 264 -> { if (!es.isEmpty()) { sel = Math.min(es.size() - 1, sel + 1); keepVisible(); } }
            case 265 -> { if (!es.isEmpty()) { sel = Math.max(0, sel - 1); keepVisible(); } }
            default -> { return false; }
        }
        return true;
    }

    private void keepVisible() {
        if (sel < scroll) scroll = sel;
        if (sel >= scroll + VISIBLE) scroll = sel - VISIBLE + 1;
    }
}
