package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * The map of the pet's town: ONE plan view that fits the screen, drawn by {@link TownMap} (no scrolling). Click a place and the pet walks
 * to it along the roads. What a place does is decided by {@link PetApp} (the callback {@code go} gets the id of the place, see MapArt.HOME ...);
 * this class only knows what is open, what is locked (the new places behind the Balloon station) and what the pet is allowed to do right now.
 * The Balloon station opens a small panel: the trip planner, and the new places (the cinema, the museum ...) that the old map had on its own.
 * It draws nothing that is saved and keeps no state outside the screen.
 */
final class PetMap {
    private static final int W = App.W, H = App.H, HEAD = MapArt.HEAD;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;

    private final Runnable back;
    private final IntConsumer go;
    private final Supplier<String> blocker;          // "" if the pet can leave on a trip, else a lang key with the reason
    private final IntFunction<String> gate;          // "" if the pet can go to this place (the park, the show), else a lang key with the reason
    private final IntSupplier stage;
    private final Supplier<ComputerColor> color;
    private final int body;

    private int ticks, hover = -1, toastT, pending = -1, waitT;
    // the part of the town that never moves is baked once into this picture (again when the night comes or goes);
    // only what moves is drawn on top of it every tick, see TownMap.
    private int[] stillPx;
    private int stillKey = Integer.MIN_VALUE;
    private String toast = "";
    // the walk of the pet along the roads: the nodes of the way, how long it takes and how far it has got
    private int node;
    private int[] way = new int[0];
    private double wayLen;
    private int walkT, walkDur;
    private boolean walking;
    private double px, py;                                   // where the pet is now (map pixels)
    // the panel of the Balloon station
    private boolean panel;

    /** {@code at} is the place where the pet stands when the map opens: HOME from the room, or the place it comes back from. */
    PetMap(Runnable back, IntConsumer go, Supplier<String> blocker, IntFunction<String> gate, IntSupplier stage, Supplier<ComputerColor> color, int body, int at) {
        this.back = back;
        this.go = go;
        this.blocker = blocker;
        this.gate = gate;
        this.stage = stage;
        this.color = color;
        this.body = body;
        node = TownMap.nodeOf(at >= 0 && at < MapArt.COUNT ? at : MapArt.HOME);
        px = TownMap.nodeX(node);
        py = TownMap.nodeY(node);
    }

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    private static boolean night() {
        int h = LocalTime.now().getHour();
        return h >= 21 || h < 6;
    }

    // ---------- what a place is ----------
    /** The trip place that stands behind a place of the Balloon station (8 .. 14), or -1. */
    private static int dest(int id) { return id >= MapArt.AMUSEMENT && id <= MapArt.QUIET ? id + 3 : -1; }

    /** True for a place that is not on the map yet (the Quiet Place before the first clue). */
    private static boolean hiddenId(int id) { int d = dest(id); return d >= 0 && PlaceUnlock.hidden(d); }

    /** The new places of the Balloon station that are shown in its panel. */
    private static List<Integer> panelPlaces() {
        List<Integer> l = new ArrayList<>();
        for (int id = MapArt.AMUSEMENT; id <= MapArt.QUIET; id++) if (!hiddenId(id)) l.add(id);
        return l;
    }

    /** True for a place where an event is on now. */
    private static boolean litId(int id) { int d = dest(id); return d >= 0 && PlaceUnlock.isEvent(d) && PlaceUnlock.open(d); }

    /** True if some place of the station has an event that was not visited yet (a star over the balloon). */
    private static boolean eventOn() {
        for (int id : panelPlaces()) { int d = dest(id); if (litId(id) && Progress.count("pl_" + d) == 0) return true; }
        return false;
    }

    /** "" = free to go; otherwise the lang key of what is in the way (a locked place, a young pet, a tired pet). */
    private String why(int id) {
        String gt = gate.apply(id);
        if (!gt.isEmpty()) return gt;
        int d = dest(id);
        if (d < 0) return "";
        if (!PlaceUnlock.open(d)) return "cutemod.trip.lock." + d;
        if (stage.getAsInt() < Trip.NEED[d]) return "cutemod.trip.needs." + Trip.NEED[d];
        return blocker.get();
    }

    private String name(int id) {
        int d = dest(id);
        return d >= 0 ? t("cutemod.trip.dest." + d) : t("cutemod.map.n." + id);
    }

    private String sub(int id) {
        int d = dest(id);
        if (d < 0) {
            String gt = gate.apply(id);
            return gt.isEmpty() ? t("cutemod.map.s." + id) : t(gt);
        }
        if (!PlaceUnlock.open(d)) return t("cutemod.trip.lock." + d, PlaceUnlock.progress(d));
        if (stage.getAsInt() < Trip.NEED[d]) return t("cutemod.trip.needs." + Trip.NEED[d]);
        String b = blocker.get();
        if (!b.isEmpty()) return t(b);
        return PlaceUnlock.isEvent(d) && Progress.count("pl_" + d) == 0 ? t("cutemod.map.event") : t("cutemod.trip.takes");
    }

    // ---------- the pointer ----------
    /** The place of the map under the pointer (mx, my on the screen), or -1. */
    private int at(int mx, int my) {
        if (my < HEAD || my >= H - 14) return -1;                              // the header and the bar cover the map
        for (int id : TownMap.PLACES) {
            int[] b = TownMap.box(id);
            if (App.in(mx, my - HEAD, b[0], b[1], b[2], b[3])) return id;
        }
        return -1;
    }

    // the panel of the Balloon station: the card, the planner button, a grid of the new places
    private static final int PX = 16, PY = HEAD + 4, PW = W - 32, PH = 127;
    private static final int CELL_W = (PW - 24) / 2, CELL_H = 16, GRID_Y = PY + 48;

    private static int cellX(int k) { return PX + 10 + (k % 2) * (CELL_W + 4); }

    private static int cellY(int k) { return GRID_Y + (k / 2) * (CELL_H + 3); }

    /** The place of the panel under the pointer, or -1; the planner button is -2. */
    private int panelAt(int mx, int my) {
        if (App.in(mx, my, PX + 10, PY + 18, PW - 20, 20)) return -2;
        List<Integer> l = panelPlaces();
        for (int k = 0; k < l.size(); k++) if (App.in(mx, my, cellX(k), cellY(k), CELL_W, CELL_H)) return l.get(k);
        return -1;
    }

    void tick() {
        ticks++;
        if (toastT > 0) toastT--;
        if (walking) {
            walkT++;
            double f = ease(Math.min(1.0, walkT / (double) walkDur));
            place(f * wayLen);
            if (walkT >= walkDur) { walking = false; node = way[way.length - 1]; waitT = 8; }
        } else if (pending >= 0 && waitT > 0 && --waitT == 0) {
            int p = pending;
            pending = -1;
            if (p == MapArt.BALLOON) panel = true;                    // the station: its panel first
            else go.accept(p);
        }
        GameMusic.keep("trips", false);                          // the travel tune plays while the map is open
    }

    /** Puts the pet at the given distance from the start of its way. */
    private void place(double d) {
        for (int i = 0; i + 1 < way.length; i++) {
            double len = Math.hypot(TownMap.nodeX(way[i + 1]) - TownMap.nodeX(way[i]), TownMap.nodeY(way[i + 1]) - TownMap.nodeY(way[i]));
            if (d <= len || i + 2 == way.length) {
                double f = len == 0 ? 1 : Math.min(1.0, d / len);
                px = TownMap.nodeX(way[i]) + (TownMap.nodeX(way[i + 1]) - TownMap.nodeX(way[i])) * f;
                py = TownMap.nodeY(way[i]) + (TownMap.nodeY(way[i + 1]) - TownMap.nodeY(way[i])) * f;
                return;
            }
            d -= len;
        }
    }

    boolean click(int mx, int my, int button) {
        if (button != 0) return true;
        if (panel) return panelClick(mx, my);
        if (walking || pending >= 0) return true;
        int id = at(mx, my);
        if (id < 0) return true;
        String w = why(id);
        if (!w.isEmpty()) {                                                // a young or tired pet: say why
            toast = t(w, "");
            toastT = 140;
            return true;
        }
        if (id == MapArt.HOME) { back.run(); return true; }
        way = TownMap.route(node, TownMap.nodeOf(id));
        wayLen = 0;
        for (int i = 0; i + 1 < way.length; i++) wayLen += Math.hypot(TownMap.nodeX(way[i + 1]) - TownMap.nodeX(way[i]), TownMap.nodeY(way[i + 1]) - TownMap.nodeY(way[i]));
        pending = id;
        if (wayLen < 1) { waitT = 8; return true; }                          // already there
        walkDur = (int) Math.max(14, Math.min(70, wayLen / 2.2));
        walkT = 0;
        walking = true;
        return true;
    }

    private boolean panelClick(int mx, int my) {
        if (!App.in(mx, my, PX, PY, PW, PH) || App.in(mx, my, PX + PW - 16, PY + 3, 12, 12)) { panel = false; return true; }   // outside or the cross: close
        int hit = panelAt(mx, my);
        if (hit == -2) { panel = false; go.accept(MapArt.BALLOON); return true; }                        // the trip planner
        if (hit >= 0) {
            String w = why(hit);
            if (!w.isEmpty()) {
                int d = dest(hit);
                toast = t(w, d >= 0 ? PlaceUnlock.progress(d) : "");
                toastT = 140;
                return true;
            }
            panel = false;
            go.accept(hit);
        }
        return true;
    }

    boolean drag(int mx, int my, int button) { return false; }

    boolean release(int mx, int my, int button) { return false; }

    boolean scroll(double amount) { return panel; }

    /** True while the panel of the station is open: Back and Escape close it. */
    boolean panelOpen() { return panel; }

    /** The map is the top of CutePet: nothing to go back to (the house on the map leads home); only the panel closes. */
    boolean key(int keyCode) {
        if (panel && keyCode == 256) { panel = false; return true; }
        return false;
    }

    // ---------- the picture ----------
    void render(GuiGraphics g, int mx, int my) {
        Font f = Minecraft.getInstance().font;
        boolean night = night();
        hover = panel ? panelAt(mx, my) : walking || pending >= 0 ? -1 : at(mx, my);
        int mapHover = panel ? -1 : hover;
        // the picture of the town is heavy (thousands of rectangles) and only changes with the game tick, the place under the pointer
        // and the time of day: it is baked into a texture only then, and every other frame is one quad
        TexCache.Tex tex = TexCache.get("petmap", W, H - HEAD);
        int tag = (ticks * 31 + (night ? 1 : 0)) * 31 + mapHover;
        if (tex.tag != tag) {
            tex.tag = tag;
            final int hv = mapHover, tk = ticks;
            final int key = night ? 1 : 0;
            if (stillPx == null || stillKey != key) {
                stillKey = key;
                stillPx = TexCache.bake(W, H, c -> TownMap.still(c, night));
            }
            final int[] still = stillPx;
            TexCache.render(tex, 0, HEAD, c -> TownMap.draw(c, tk, night, hv, still));
        }
        TexCache.blit(g, tex, 0, HEAD);
        chips(g, f);
        badge(g);
        drawPet(g);

        // the header
        Skin.rect(g, 0, 0, W, HEAD, 0xFF5A4A86);
        String title = t("cutemod.map.title");
        Skin.str(g, f, title, W / 2 - f.width(title) / 2, 5, 0xFFFFFFFF, false);
        String clock = String.format("%02d:%02d", LocalTime.now().getHour(), LocalTime.now().getMinute());
        Skin.str(g, f, clock, W - 6 - f.width(clock), 5, 0xFFE4D8FF, false);

        if (panel) drawPanel(g, f);
        // the bar at the bottom: what the place is, or what is in the way
        Skin.rect(g, 0, H - 14, W, 14, 0xE63A2A5A);
        String line = toastT > 0 ? toast : hover >= 0 ? name(hover) + "  ·  " + sub(hover) : hover == -2 ? t("cutemod.map.trips.planner") : t("cutemod.map.pick");
        int col = toastT > 0 ? 0xFFFFD0D0 : hover >= 0 || hover == -2 ? 0xFFFFFFFF : 0xFFC8B8E8;
        Skin.str(g, f, f.plainSubstrByWidth(line, W - 12), 6, H - 11, col, false);
    }

    /** The little name signs over the places (the one under the pointer is lit). */
    private void chips(GuiGraphics g, Font f) {
        for (int id : TownMap.PLACES) {
            int[] c = TownMap.chip(id);
            String s = t("cutemod.map.lbl." + id);
            int w = f.width(s) + 6, x = Math.max(1, Math.min(W - w - 1, c[0] - w / 2)), y = HEAD + c[1];
            boolean on = id == hover && !panel;
            App.roundRect(g, x, y + 1, w, 9, 4, 0x44000000);
            App.roundRect(g, x, y, w, 9, 4, on ? ACCENT : 0xDD231B3D);
            Skin.str(g, f, s, x + 3, y + 1, 0xFFFFFFFF, false);
        }
    }

    /** A bouncing star over the balloon when an event is on at one of the new places. */
    private void badge(GuiGraphics g) {
        if (!eventOn()) return;
        int by = HEAD + 66 - (int) Math.round(Math.abs(Math.sin(ticks / 9.0)) * 3), cx = 278;
        Skin.rect(g, cx - 3, by, 7, 9, 0xFFFFC832);
        Skin.rect(g, cx - 3, by, 7, 1, 0xFFFFE680);
        Skin.rect(g, cx, by + 2, 1, 3, 0xFF3A2A3A);
        Skin.rect(g, cx, by + 6, 1, 1, 0xFF3A2A3A);                    // an exclamation mark
    }

    /** The pet itself, small, on the road: a ring under it, and it hops while it walks. */
    private void drawPet(GuiGraphics g) {
        int x = (int) Math.round(px), y = (int) Math.round(py) + HEAD + 3;
        int hop = walking ? (int) Math.round(Math.abs(Math.sin(walkT * 0.55)) * 3) : 0;
        int st = stage.getAsInt();
        MapArt.oval(g, x, y, 8, 3, 0xCCFFFFFF);
        MapArt.oval(g, x, y, 6, 2, 0x66231B3D);
        float sc = 0.3F * PetArt.scaleOf(st);
        g.pose().pushPose();
        g.pose().translate(x, y - hop, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-x, -(y - hop), 0);
        PetArt.draw(g, color.get(), x, y - hop - 28, 2, ticks, false, false, st, Progress.equipped(), Progress.equippedBody());
        g.pose().popPose();
    }

    /** The panel of the Balloon station: the trip planner and the new places. */
    private void drawPanel(GuiGraphics g, Font f) {
        g.fill(0, HEAD, W, H - 14, 0x99100C20);
        JobsUi.card(g, PX, PY, PW, PH, 7, 0xFFFFF8F2, 0xFFD8CCE8);
        String title = name(MapArt.BALLOON);
        Skin.str(g, f, title, W / 2 - f.width(title) / 2, PY + 6, TEXT, false);
        Skin.str(g, f, "x", PX + PW - 13, PY + 6, MUTED, false);
        boolean ph = hover == -2;
        App.roundRect(g, PX + 10, PY + 19, PW - 20, 20, 7, 0x33000000);
        App.roundRect(g, PX + 10, PY + 18, PW - 20, 20, 7, ph ? 0xFFC99BE6 : ACCENT);
        String pl = t("cutemod.map.trips.planner");
        Skin.str(g, f, pl, W / 2 - f.width(pl) / 2, PY + 24, 0xFFFFFFFF, false);
        String np = t("cutemod.map.trips.places");
        Skin.str(g, f, np, PX + 12, PY + 40, MUTED, false);
        List<Integer> l = panelPlaces();
        for (int k = 0; k < l.size(); k++) {
            int id = l.get(k), x = cellX(k), y = cellY(k);
            boolean block = !why(id).isEmpty(), lit = litId(id) && !block, on = id == hover;
            App.roundRect(g, x, y + 1, CELL_W, CELL_H, 6, 0x22000000);
            App.roundRect(g, x, y, CELL_W, CELL_H, 6, on ? 0xFFE6D6F8 : lit ? 0xFFFFF0B0 : block ? 0xFFEDE6F2 : 0xFFF4ECFC);
            Skin.str(g, f, f.plainSubstrByWidth(name(id), CELL_W - 22), x + 6, y + 4, block ? 0xFF9A8AB0 : TEXT, false);
            if (block) {                                                   // a little padlock
                Skin.rect(g, x + CELL_W - 12, y + 7, 7, 6, 0xFF9A8AB0);
                Skin.rect(g, x + CELL_W - 11, y + 3, 5, 1, 0xFF9A8AB0);
                Skin.rect(g, x + CELL_W - 11, y + 3, 1, 4, 0xFF9A8AB0);
                Skin.rect(g, x + CELL_W - 7, y + 3, 1, 4, 0xFF9A8AB0);
            } else if (lit) {
                Skin.rect(g, x + CELL_W - 11, y + 3, 5, 9, 0xFFFFC832);
                Skin.rect(g, x + CELL_W - 9, y + 5, 1, 3, 0xFF3A2A3A);
            }
        }
    }

    private static double ease(double t) { return t * t * (3 - 2 * t); }
}
