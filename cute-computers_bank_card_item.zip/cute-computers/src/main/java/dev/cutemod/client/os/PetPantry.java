package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.market.Deals;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * The Pantry of the pet: the shop of treats (food, fun and medicine for the pet) on the shopping boulevard of the map. The
 * treats used to be sold in the "Home" tab of CuteMarket; now they are sold here, to the pet, by a bunny. They are paid with
 * coins and put into the stock of the pet at once (no courier). The screen shows the inside of the shop at the left (see
 * {@link PetShops#pantry}) and the shelf at the right: a row for every treat with what it does, its price and a buy button.
 */
final class PetPantry {
    private static final int W = App.W, H = App.H, HEAD = 17;
    private static final int SCENE_W = 96, SCENE_H = H - HEAD;
    private static final int LX = 99, TOP = 21, ROW = 24, VISIBLE = 6, RIGHT_W = 52;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, GOLD = 0xFFB98A10, ACCENT = 0xFF4CAF6A;

    /** The treats in the order of the shelf, with their prices (the same ones the Home tab of CuteMarket used to have). */
    private record Treat(String id, int price) {}

    private static final Treat[] TREATS = {
        new Treat("treat_berry", 3), new Treat("treat_lolly", 4), new Treat("treat_cookie", 5), new Treat("treat_fish", 8),
        new Treat("treat_milk", 10), new Treat("treat_honey", 12), new Treat("treat_cake", 20), new Treat("treat_medicine", 25)};

    private final Runnable back;
    private final Supplier<ComputerColor> color;
    private final IntSupplier stage;
    private final Consumer<Float> snd;

    private int ticks, scroll, hover = -1, sayT, flyT;
    private String say = "cutemod.pantry.hi", flyId = "";

    PetPantry(Runnable back, Supplier<ComputerColor> color, IntSupplier stage, Consumer<Float> snd) {
        this.back = back;
        this.color = color;
        this.stage = stage;
        this.snd = snd;
        sayT = 260;
    }

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    private static int cost(Treat it) { return Deals.price(it.id(), it.price()); }

    private int maxScroll() { return Math.max(0, TREATS.length - VISIBLE); }

    void tick() {
        ticks++;
        if (sayT > 0) sayT--;
        if (flyT > 0) flyT--;
    }

    // ---------------------------------------------------------------- the picture
    void render(GuiGraphics g, int mx, int my) {
        Font f = Minecraft.getInstance().font;
        hover = -1;
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= TREATS.length) break;
            if (App.in(mx, my, LX, TOP + v * ROW, W - LX - 2, ROW - 2)) hover = idx;
        }
        Skin.rect(g, 0, 0, W, H, 0xFFFFF6E4);
        // the inside of the shop, the keeper, the counter in front of her, and the pet
        PetShops.pantry(g, 0, HEAD, SCENE_W, SCENE_H, ticks);
        int fl = HEAD + SCENE_H - 34;
        PetShops.bunnyKeeper(g, 79, fl + 14, ticks, sayT > 0);
        PetShops.pantryCounter(g, 0, HEAD, SCENE_W, SCENE_H, ticks);
        int feet = fl + 22;
        PetActs.pet(g, color.get(), 38, feet, 0.85F, ticks, stage.getAsInt(), hover >= 0 ? 2 : 1);
        if (hover >= 0) {                                                            // the treat that the pet looks at floats over its head
            int by = feet - 52 - (int) Math.round(Math.sin(ticks / 9.0) * 2);
            Skin.rect(g, 28, by - 2, 20, 18, 0xE6FFFFFF); Skin.rect(g, 28, by + 16, 20, 1, 0xFFD8CCE8);
            g.pose().pushPose();
            g.pose().translate(31, by, 0);
            g.pose().scale(1.4F, 1.4F, 1F);
            PetApp.drawTreat(g, TREATS[hover].id(), 0, 0);
            g.pose().popPose();
        }
        if (flyT > 0) {                                                              // a bought treat flies from the counter to the pet
            double p = 1 - flyT / 30.0;
            int fx = (int) Math.round(76 + (36 - 76) * p), fy = (int) Math.round(fl - 6 + (feet - 40 - (fl - 6)) * p - Math.sin(p * Math.PI) * 18);
            g.pose().pushPose();
            g.pose().translate(fx, fy, 0);
            g.pose().scale(1.5F, 1.5F, 1F);
            PetApp.drawTreat(g, flyId, 0, 0);
            g.pose().popPose();
        }
        if (sayT > 0) bubble(g, f);

        // the shelf: the rows of the treats
        Skin.rect(g, SCENE_W, HEAD, 1, SCENE_H, 0xFF8A5A2A);
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= TREATS.length) break;
            row(g, f, TREATS[idx], TOP + v * ROW, idx == hover, mx, my);
        }
        if (maxScroll() > 0) {
            int track = VISIBLE * ROW - 2, th = Math.max(8, track * VISIBLE / TREATS.length);
            Skin.rect(g, W - 3, TOP, 2, track, 0xFFE9DDF2);
            Skin.rect(g, W - 3, TOP + (track - th) * scroll / maxScroll(), 2, th, ACCENT);
        }

        // the header: the name of the shop, the coins
        Skin.rect(g, 0, 0, W, HEAD, 0xFF5A4A86);
        String name = t("cutemod.map.n.22");
        Skin.str(g, f, name, W / 2 - f.width(name) / 2, 5, 0xFFFFFFFF, false);
    }

    private void row(GuiGraphics g, Font f, Treat it, int y, boolean hov, int mx, int my) {
        App.roundRect(g, LX, y, W - LX - 2, ROW - 2, 5, hov ? 0xFFFFFFFF : 0xFFFFFAF0);
        App.roundRect(g, LX, y, W - LX - 2, 1, 0, 0x22A08040);
        // the picture of the treat on a cream tile
        Skin.rect(g, LX + 2, y + 1, 22, 20, 0xFF3A2A4A); Skin.rect(g, LX + 3, y + 2, 20, 18, 0xFFFFF0C0);
        g.pose().pushPose();
        g.pose().translate(LX + 6, y + 4, 0);
        g.pose().scale(1.4F, 1.4F, 1F);
        PetApp.drawTreat(g, it.id(), 0, 0);
        g.pose().popPose();
        int deal = Deals.percent(it.id());
        if (deal > 0) {                                                              // on sale today
            String d = "-" + deal + "%";
            Skin.rect(g, LX + 2, y + 13, f.width(d) + 3, 8, 0xFFE5484D);
            Skin.str(g, f, d, LX + 3, y + 13, 0xFFFFFFFF, false);
        }
        int bx = W - 4 - RIGHT_W, textX = LX + 27, textW = bx - textX - 3;
        int have = Progress.stock(it.id());
        String name = t("cutemod.shop.item." + it.id());
        String stock = have > 0 ? "x" + have : "";
        String shown = cut(f, name, textW - (stock.isEmpty() ? 0 : f.width(stock) + 4));
        Skin.str(g, f, shown, textX, y + 3, TEXT, false);
        if (!stock.isEmpty()) Skin.str(g, f, stock, textX + f.width(shown) + 4, y + 3, GOLD, false);
        Skin.str(g, f, cut(f, t("cutemod.shop.eff." + it.id()), textW), textX, y + 13, MUTED, false);
        // the price over the button
        String p = Integer.toString(cost(it));
        boolean afford = Progress.coins() >= cost(it);
        int px = bx + RIGHT_W - 9 - f.width(p);
        Progress.drawCoin(g, px - 9, y + 2);
        Skin.str(g, f, p, px, y + 2, afford ? TEXT : 0xFFE5484D, false);
        boolean over = App.in(mx, my, bx, y + 11, RIGHT_W, 10);
        App.roundRect(g, bx, y + 11, RIGHT_W, 10, 4, !afford ? 0xFFD8CCE2 : over ? 0xFF3A9A58 : ACCENT);
        String label = cut(f, t("cutemod.shop.btn.buy"), RIGHT_W - 4);
        Skin.str(g, f, label, bx + (RIGHT_W - f.width(label)) / 2, y + 12, afford ? 0xFFFFFFFF : MUTED, false);
    }

    /** What the keeper says: a bubble over the shelves, with a tail to the bunny. */
    private void bubble(GuiGraphics g, Font f) {
        List<FormattedCharSequence> lines = f.split(FormattedText.of(t(say)), 52);
        int n = Math.min(3, lines.size()), bh = n * 9 + 5, bw = 58, bx = SCENE_W - bw - 2, by = HEAD + 84 - bh;
        Skin.rect(g, bx, by, bw, bh, 0xF2FFFFFF); Skin.rect(g, bx, by + bh - 1, bw, 1, 0xFFD8CCE8);
        Skin.rect(g, bx + bw - 22, by + bh, 6, 2, 0xF2FFFFFF); Skin.rect(g, bx + bw - 20, by + bh + 2, 3, 2, 0xF2FFFFFF);
        for (int k = 0; k < n; k++) Skin.str(g, f, lines.get(k), bx + 3, by + 3 + k * 9, TEXT, false);
    }

    private static String cut(Font f, String s, int maxW) {
        if (maxW <= 0) return "";
        if (f.width(s) <= maxW) return s;
        return f.plainSubstrByWidth(s, Math.max(0, maxW - f.width("..."))) + "...";
    }

    // ---------------------------------------------------------------- the input
    boolean click(int mx, int my, int button) {
        if (button != 0) return true;
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= TREATS.length) break;
            int y = TOP + v * ROW, bx = W - 4 - RIGHT_W;
            if (!App.in(mx, my, bx, y + 11, RIGHT_W, 10)) continue;
            Treat it = TREATS[idx];
            if (Progress.buyTreat(it.id(), cost(it))) {
                snd.accept(2.0F);
                flyId = it.id();
                flyT = 30;
                talk("cutemod.pantry.thanks." + (ticks % 3));
            } else {
                snd.accept(0.8F);
                talk("cutemod.pantry.poor");
            }
            return true;
        }
        return true;
    }

    private void talk(String key) { say = key; sayT = 170; }

    boolean scroll(double amount) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll + (amount < 0 ? 1 : -1)));
        return true;
    }

    boolean key(int keyCode) {
        if (keyCode == 256) { back.run(); return true; }
        return false;
    }
}
