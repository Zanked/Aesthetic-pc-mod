package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.CuteMod;
import dev.cutemod.client.game.GameFactory;
import dev.cutemod.client.game.MiniGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * CuteJobs: short one-minute shifts that pay coins. Ten jobs, ranks that raise the pay,
 * and a cooldown after each shift so the coins cannot be farmed forever.
 */
public class JobsApp extends App {
    private static final int BG = 0xFF1B1530, ROW_A = 0xFF231B3D, ROW_B = 0xFF1F1736, HOVER = 0xFF352A58;
    private static final int ACCENT = 0xFFB57BD6, GREEN = 0xFF5BD97A, YELLOW = 0xFFFFD866, MUTED = 0xFF9A90B8;
    private static final int WHITE = 0xFFFFFFFF, RED = 0xFFE5484D, BAR = 18;
    private static final int[] JOB_RGB = {0xFF6AA8F0, 0xFFF0B050, 0xFFF58FB8, 0xFFC98B5A, 0xFF5BBF6A, 0xFFB57BD6, 0xFF8EC3F2, 0xFF4ADE80, 0xFFFF6AD5, 0xFF38BDF8};

    private enum Mode { MENU, READY, SHIFT, RESULT }

    private Mode mode = Mode.MENU;
    private String jobId = "";
    private Shift shift;
    private int ready, shiftTick;
    private float resultQuality;
    private int resultPay;
    private boolean rankUp;
    private int noGamesTimer;
    /** Bursts, confetti, floating texts and the screen shake of the running shift (see {@link JobsGfx.Fx}). */
    private final JobsGfx.Fx fx = new JobsGfx.Fx();

    // ---------- sounds ----------
    // The effects are our own sound events (sounds.json: "jobs.<name>", made by tools/make_jobs_audio.py) and go through Sfx, so the
    // Sounds switch and the system volume of the Settings apply. The music is GameMusic: "jobs" for the list and the result,
    // "job_<id>" for a shift (the tester plays the tune of the game he tests); it follows the Music switch and slider.
    private static final java.util.Map<String, SoundEvent> SND = new java.util.HashMap<>();

    private static SoundEvent snd(String name) {
        return SND.computeIfAbsent(name, n -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "jobs." + n)));
    }

    private static void sfx(String name) { Sfx.ui(snd(name), 1F, 0.7F); }

    private static void sfx(String name, float pitch, float vol) { Sfx.ui(snd(name), pitch, vol); }

    /** The tune that belongs to what is on screen. Called every tick: when the app is left it fades out by itself. */
    private void music() {
        String id = "jobs";
        boolean over = false;
        int rt = 0;
        if (mode == Mode.SHIFT && shift != null) {
            if (shift instanceof Tester tt) { id = tt.gameId; over = tt.game.over; rt = shiftTick; }
            else id = "job_" + jobId;
        }
        GameMusic.keep(id, over, rt);
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.jobs"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.jobs"); }

    @Override
    public Component status() {
        if (mode == Mode.SHIFT && shift != null) return Component.literal(shift.status());
        return Component.translatable("cutemod.job.rank." + Jobs.rank());
    }

    @Override
    public void close() { Jobs.save(); GameMusic.stop(); Sfx.stopGameSounds(); }

    // ---------- flow ----------
    private boolean available(Jobs.Job j) {
        if (Jobs.rank() < j.rank() || Jobs.cooldownLeft(j.id()) > 0) return false;
        return !j.id().equals("tester") || !installedGames().isEmpty();
    }

    private static List<String> installedGames() {
        List<String> out = new ArrayList<>();
        for (Library.Game g : Library.GAMES) if (Library.installed(g.id())) out.add(g.id());
        return out;
    }

    private void start(Jobs.Job j) {
        if (!available(j)) {
            if (j.id().equals("tester") && Jobs.rank() >= j.rank() && Jobs.cooldownLeft(j.id()) == 0) noGamesTimer = 180;
            Sfx.error();                                       // locked, or resting
            return;
        }
        jobId = j.id();
        shift = switch (jobId) {
            case "typing" -> new Typing();
            case "post" -> new Post();
            case "pets" -> new Pets();
            case "cafe" -> new Cafe();
            case "courier" -> new Courier();
            case "artist" -> new Artist();
            case "coder" -> new Coder();
            case "dj" -> new Dj();
            case "pilot" -> new Pilot();
            default -> new Tester();
        };
        fx.clear();
        mode = Mode.READY;
        ready = 150;
        sfx("start");
    }

    private void finish() {
        float q = Math.max(0f, Math.min(1f, shift.quality()));
        resultQuality = q;
        resultPay = Jobs.payout(jobId, q);
        rankUp = Jobs.finish(jobId, q);
        if (resultPay > 0) Progress.earnQuiet(resultPay);      // the shift has its own sounds
        mode = Mode.RESULT;
        // the end of the shift: a bell, then what the work was worth (a jingle for good or poor work, the cash register, a new rank)
        Sfx.stopGameSounds();
        sfx("end");
        resultT = 0;
        jingle = rankUp ? "rankup" : q >= 0.75f ? "win" : q < 0.35f ? "sad" : "";
        jingleAt = 45;
        payAt = resultPay <= 0 ? -1 : jingle.isEmpty() ? 45 : jingle.equals("rankup") ? 190 : 130;
    }

    private int resultT, jingleAt, payAt;
    private String jingle = "";

    @Override
    public void tick() {
        if (noGamesTimer > 0) noGamesTimer--;
        music();
        if (mode == Mode.READY) {
            ready--;
            if (ready == 99 || ready == 49) sfx("count");                                  // 3 - 2 - 1 - go
            if (ready <= 0) { mode = Mode.SHIFT; shiftTick = 0; sfx("go"); }
        } else if (mode == Mode.SHIFT && shift != null) {
            shift.tick();
            fx.tick();
            shiftTick++;
            int rest = shift.duration() - shiftTick;
            if (rest > 0 && rest <= 600 && rest % 60 == 0) sfx("tick", 1F, 0.5F);          // the last ten seconds tick
            if (shiftTick >= shift.duration() || shift.over()) finish();
        } else if (mode == Mode.RESULT) {
            resultT++;
            if (resultT == jingleAt && !jingle.isEmpty()) sfx(jingle, 1F, jingle.equals("sad") ? 0.6F : 0.75F);
            if (resultT == payAt) sfx("payout");
        }
    }

    @Override
    public void mouse(int x, int y) {
        if (shift instanceof Tester tt) tt.mouse(x, y);
        else if (shift instanceof Pilot pl) pl.mouse(x, y);
    }

    // ---------- drawing helpers ----------
    private static void txt(GuiGraphics g, String s, int x, int y, int argb) { Skin.str(g, font(), s, x, y, argb, false); }

    private static void ctxt(GuiGraphics g, String s, int cx, int y, int argb) {
        Skin.str(g, font(), s, cx - font().width(s) / 2, y, argb, false);
    }

    private static void big(GuiGraphics g, String s, int cx, int y, int argb, float scale) {
        g.pose().pushPose();
        g.pose().translate(cx - font().width(s) * scale / 2f, y, 0);
        g.pose().scale(scale, scale, 1f);
        Skin.str(g, font(), s, 0, 0, argb, false);
        g.pose().popPose();
    }

    private static void button(GuiGraphics g, int x, int y, int w, int h, String label, boolean enabled, boolean hover, int color) {
        Skin.rect(g, x, y, w, h, !enabled ? 0xFF3A2F5A : hover ? mix(color & 0xFFFFFF, 0xFFFFFF, 0.25f) : color);
        ctxt(g, label, x + w / 2, y + (h - 8) / 2, enabled ? 0xFF1B1530 : MUTED);
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Skin.rect(g, 0, 0, W, H, BG);
        switch (mode) {
            case MENU -> renderMenu(g, mx, my);
            case READY -> JobsUi.ready(g, jobId, ready, t("cutemod.job.how." + jobId));
            case SHIFT -> {
                int left = Math.max(0, (shift.duration() - shiftTick + 59) / 60);
                float rest = 1f - shiftTick / (float) shift.duration();
                JobsUi.shiftHeader(g, jobId, shift.status(), left, rest);
                g.pose().pushPose();
                g.pose().translate(fx.shakeX(), fx.shakeY(), 0);
                shift.render(g, mx, my);
                g.pose().popPose();
                if (!(shift instanceof Tester)) JobsGfx.vignette(g);       // soft dark edges on every shift but the tested game
                fx.render(g);
            }
            case RESULT -> renderResult(g, mx, my);
        }
    }

    private void renderMenu(GuiGraphics g, int mx, int my) {
        boolean[] ok = new boolean[Jobs.LIST.size()];
        for (int i = 0; i < ok.length; i++) ok[i] = available(Jobs.LIST.get(i));
        JobsUi.menu(g, mx, my, ok, noGamesTimer);
    }

    private void renderResult(GuiGraphics g, int mx, int my) {
        JobsUi.result(g, mx, my, jobId, resultQuality, resultPay, rankUp, Jobs.overCap(), resultT);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int b) {
        switch (mode) {
            case MENU -> {
                int hit = JobsUi.cardAt(x, y);
                if (hit >= 0) start(Jobs.LIST.get(hit));
                return true;
            }
            case RESULT -> {
                if (JobsUi.backHit(x, y)) { mode = Mode.MENU; shift = null; }
                return true;
            }
            case SHIFT -> { return shift != null && shift.click(x, y); }
            default -> { return true; }
        }
    }

    @Override
    public boolean drag(int x, int y, int b) {
        return mode == Mode.SHIFT && shift != null && shift.drag(x, y);
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (mode == Mode.RESULT && (keyCode == 257 || keyCode == 32)) { mode = Mode.MENU; shift = null; return true; }
        if (mode == Mode.SHIFT && shift != null) return shift.key(keyCode);
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        return mode == Mode.SHIFT && shift != null && shift.typed(c);
    }

    // ======================================================================
    //                               the shifts
    // ======================================================================
    private abstract class Shift {
        final Random rnd = new Random();
        abstract int duration();
        void tick() {}
        abstract void render(GuiGraphics g, int mx, int my);
        boolean click(int x, int y) { return false; }
        boolean drag(int x, int y) { return false; }
        boolean key(int k) { return false; }
        boolean typed(char c) { return false; }
        boolean over() { return false; }
        abstract float quality();
        abstract String status();
    }

    // ---------- typist: words fall from the sky, type them before they land ----------
    private final class Typing extends Shift {
        private static final String[][] WORDS = {
                {"cat", "fox", "bee", "pig", "cow", "owl", "egg", "ice", "map", "sun", "bed", "cup", "hat", "jar", "key", "toy"},
                {"panda", "honey", "pixel", "cloud", "music", "apple", "kitten", "button", "screen", "garden", "castle", "rocket",
                        "puzzle", "sunset", "meadow", "pillow", "candle", "forest", "bamboo", "cookie"},
                {"creeper", "penguin", "diamond", "pickaxe", "ladybug", "lantern", "wizard", "blossom", "rainbow", "pancake",
                        "mushroom", "firework", "treasure", "bluebird"}};
        private static final int TOP = 21, GROUND = 138;

        private static final class Word {
            String s;
            float x, y;
            int pos, pop;          // pop > 0: the word is bursting
            boolean gold;
        }

        private final List<Word> words = new ArrayList<>();
        private Word target;
        private int spawnT = 25, spawned, done, miss, errors, flash, groundFlash, combo;
        private float points;

        @Override int duration() { return 3600; }

        /** Words get longer and faster the more of them you have popped; every eighth one is golden (counts double). */
        private void spawn() {
            int tier = spawned < 5 ? 0 : spawned < 14 ? 1 : 2;
            String s = null;
            for (int tries = 0; tries < 12; tries++) {
                int grp = tier == 0 ? (rnd.nextInt(10) < 7 ? 0 : 1)
                        : tier == 1 ? (rnd.nextInt(10) < 7 ? 1 : (rnd.nextBoolean() ? 0 : 2))
                        : (rnd.nextInt(10) < 6 ? 2 : 1);
                String c = WORDS[grp][rnd.nextInt(WORDS[grp].length)];
                boolean clash = false;
                for (Word w : words) if (w.s.equals(c) || w.s.charAt(0) == c.charAt(0)) clash = true; // one first letter per word on screen
                s = c;
                if (!clash) break;
            }
            Word w = new Word();
            w.s = s;
            w.gold = spawned % 8 == 7;
            int ww = font().width(s) + 8;
            w.x = 6 + rnd.nextInt(Math.max(1, W - 12 - ww));
            w.y = TOP;
            words.add(w);
            spawned++;
        }

        @Override void tick() {
            if (flash > 0) flash--;
            if (groundFlash > 0) groundFlash--;
            if (--spawnT <= 0) { spawn(); spawnT = Math.max(66, 150 - spawned * 3); }
            float speed = Math.min(0.5f, 0.22f + spawned * 0.0065f);
            for (int i = words.size() - 1; i >= 0; i--) {
                Word w = words.get(i);
                if (w.pop > 0) { if (--w.pop <= 0) words.remove(i); continue; }
                w.y += speed * (w.gold ? 1.25f : 1f);
                if (w.y >= GROUND - 10) {                    // it landed
                    miss++;
                    combo = 0;
                    groundFlash = 14;
                    fx.shake(8, 2.5f);
                    fx.burst(w.x + font().width(w.s) / 2f + 4, GROUND, RED, 7);
                    sfx("bump", 1.3F, 0.45F);
                    if (w == target) target = null;
                    words.remove(i);
                }
            }
        }

        @Override boolean typed(char c) {
            char ch = Character.toLowerCase(c);
            if (!Character.isLetter(ch)) return false;
            if (target == null) {                            // the first letter picks the lowest word that starts with it
                Word best = null;
                for (Word w : words) if (w.pop == 0 && w.s.charAt(0) == ch && (best == null || w.y > best.y)) best = w;
                if (best == null) { errors++; flash = 8; combo = 0; sfx("bad", 1F, 0.5F); return true; }
                target = best;
                target.pos = 0;
            }
            if (target.s.charAt(target.pos) == ch) {
                if (++target.pos >= target.s.length()) {
                    if (target.gold) sfx("great", 1F, 0.7F); else sfx("pop", 1F + Math.min(combo, 8) * 0.04F, 0.7F);   // the pop rises with the combo
                    int fxX = Math.round(target.x) + (font().width(target.s) + 8) / 2, fxY = Math.round(target.y) + 5;
                    if (target.gold) { fx.burst(fxX, fxY, YELLOW, 14); fx.confetti(fxX, fxY, 10); } else fx.burst(fxX, fxY, GREEN, 8);
                    fx.pop(fxX, fxY - 8, target.gold ? "+2" : combo >= 4 ? "x" + (combo + 1) : "+1", target.gold ? YELLOW : GREEN);
                    target.pop = 14;
                    done += target.gold ? 2 : 1;
                    combo++;
                    points += (target.gold ? 2f : 1f) + (combo >= 5 ? 0.25f : 0f);
                    target = null;
                }
            } else {
                errors++;
                flash = 8;
                combo = 0;
                sfx("bad", 1F, 0.5F);
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            JobsGfx.sky(g, flash > 0 ? 0xFF2E1A3C : 0xFF271C52, flash > 0 ? 0xFF1E1230 : 0xFF140E2C);
            JobsGfx.stars(g, shiftTick, 22, 3, 0xFFFFFFFF);
            JobsGfx.ground(g, GROUND, groundFlash > 0 ? 0xFF7A3040 : 0xFF3A7A54, groundFlash > 0 ? 0xFF4A1E2C : 0xFF254A38);
            if (groundFlash > 0) JobsGfx.rect(g, 0, GROUND, W, 2, RED);
            for (Word w : words) {
                if (w.pop > 0) continue;                                   // the burst is drawn by the effects
                int ww = font().width(w.s) + 8, x = Math.round(w.x), y = Math.round(w.y);
                boolean tgt = w == target;
                if (w.gold) JobsGfx.glow(g, x + ww / 2, y + 5, 14, YELLOW, 0x0C);
                else if (tgt) JobsGfx.halo(g, x, y, ww, 11, 4, ACCENT, 0x30);
                JobsGfx.puffy(g, x, y, ww, 11, 4, w.gold ? 0xFF8A6A14 : tgt ? 0xFF5A4A9A : 0xFF3A2F5E);
                String a = w.s.substring(0, w.pos), b = w.s.substring(w.pos);
                Skin.str(g, font(), a, x + 4, y + 2, GREEN, false);
                Skin.str(g, font(), b, x + 4 + font().width(a), y + 2, w.gold ? YELLOW : WHITE, false);
            }
            String hud = t("cutemod.job.typed", done) + (combo >= 3 ? "   " + t("cutemod.job.combo", combo) : "");
            ctxt(g, hud, W / 2, GROUND + 6, combo >= 5 ? YELLOW : MUTED);
        }

        @Override float quality() { return Math.max(0f, points - miss - errors * 0.1f) / 28f; }
        @Override String status() { return t("cutemod.job.typed", done); }
    }

    // ---------- postman: sort the letters on the belt, the boxes move around ----------
    private final class Post extends Shift {
        private static final int BELT_Y = 48, BOX_Y = 120, LEFT = 30, FLY = 14;
        private final int[] cols = {RED, 0xFF2F7FD6, 0xFF5BBF6A, 0xFFF3D46A};   // one color per town
        private final int[] slot = {0, 1, 2, 3};                                  // box position -> town

        private static final class Letter {
            float x;
            int town, fly = -1, flyTo;                                            // fly >= 0: on its way into a box
            boolean express;
        }

        private final List<Letter> belt = new ArrayList<>();
        private int ok, miss, flash, moved, sorted, age;

        @Override int duration() { return 3600; }

        private void spawn() {
            Letter l = new Letter();
            l.x = W + 8;
            l.town = rnd.nextInt(4);
            l.express = ok >= 5 && rnd.nextInt(8) == 0;                           // gold letters: double points, faster
            belt.add(l);
        }

        /** Every 8 sorted letters the boxes change places: what your fingers learned is wrong again. */
        private void shuffleBoxes() {
            int[] old = slot.clone();
            do {
                for (int i = 3; i > 0; i--) {
                    int j = rnd.nextInt(i + 1), t0 = slot[i];
                    slot[i] = slot[j];
                    slot[j] = t0;
                }
            } while (java.util.Arrays.equals(old, slot));
            moved = 100;
            sfx("power", 1.3F, 0.35F);                                            // the boxes changed places
        }

        private void sort(int s) {
            Letter l = null;
            for (Letter c : belt) if (c.fly < 0) { l = c; break; }               // the front letter (the leftmost)
            if (l == null) return;
            if (slot[s] == l.town) {
                ok += l.express ? 2 : 1;
                sorted++;
                flash = 8;
                if (l.express) sfx("great", 1F, 0.6F); else { sfx("swish", 1F, 0.6F); sfx("good", 1F, 0.35F); }
                l.fly = FLY;
                l.flyTo = s;
                int bxc = 6 + s * 72 + 33;
                fx.burst(bxc, BOX_Y + 8, cols[l.town], l.express ? 12 : 7);
                fx.pop(bxc, BOX_Y - 6, l.express ? "+2" : "+1", l.express ? YELLOW : GREEN);
                if (l.express) fx.confetti(bxc, BOX_Y + 8, 8);
                if (sorted % 8 == 0) shuffleBoxes();
            } else {
                miss++;
                flash = -8;
                sfx("bad");
                fx.shake(8, 2.5f);
                fx.burst(l.x + 15, BELT_Y + 9, RED, 8);
                belt.remove(l);                                                    // sent back
            }
        }

        @Override void tick() {
            age++;
            if (flash > 0) flash--; else if (flash < 0) flash++;
            if (moved > 0) moved--;
            float v = 0.55f + Math.min(0.9f, ok * 0.015f);
            Letter last = null;
            for (Letter l : belt) if (l.fly < 0) last = l;
            if (last == null || last.x < W - 66) spawn();
            for (int i = belt.size() - 1; i >= 0; i--) {
                Letter l = belt.get(i);
                if (l.fly >= 0) { if (--l.fly <= 0) belt.remove(i); continue; }
                l.x -= v * (l.express ? 1.5f : 1f);
                if (l.x < LEFT - 14) { miss++; flash = -8; sfx("bad", 0.85F, 0.6F); fx.shake(6, 2f); fx.burst(LEFT, BELT_Y + 9, RED, 6); belt.remove(i); }       // fell off the end of the belt
            }
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 4; i++) if (in(x, y, 6 + i * 72, BOX_Y, 66, 38)) { sort(i); return true; }
            return true;
        }

        @Override boolean key(int k) {
            if (k >= 49 && k <= 52) { sort(k - 49); return true; }
            return false;
        }

        private void envelope(GuiGraphics g, int x, int y, boolean express, int stamp) {
            if (express) JobsGfx.glow(g, x + 15, y + 9, 20, YELLOW, 0x0E);
            JobsGfx.puffy(g, x, y, 30, 18, 3, express ? 0xFFFFD866 : 0xFFFFF6E0);
            App.roundRect(g, x + 20, y + 4, 7, 7, 2, stamp);
            Skin.rect(g, x + 3, y + 7, 12, 1, 0xFF9A8A70);
            Skin.rect(g, x + 3, y + 10, 9, 1, 0xFF9A8A70);
            if (express) Skin.rect(g, x + 2, y + 14, 26, 3, RED);
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            JobsGfx.sky(g, 0xFF2C2444, 0xFF1A1530);
            JobsGfx.glow(g, 262, 34, 40, 0xFFFFD866, 0x08);
            // the conveyor belt: a metal band with a lit edge, a soft shadow below it and ticks that move
            Skin.grad(g, 0, BELT_Y - 14, W, BELT_Y + 28, 0xFF3C3858, 0xFF201C32);
            JobsGfx.rect(g, 0, BELT_Y - 14, W, 1, 0xFF7A76A0);
            JobsGfx.rect(g, 0, BELT_Y - 13, W, 1, 0x22FFFFFF);
            JobsGfx.rect(g, 0, BELT_Y + 26, W, 2, 0xFF4A4660);
            JobsGfx.rect(g, 0, BELT_Y + 28, W, 5, 0x30000000);
            for (int x = -(age % 12); x < W; x += 12) JobsGfx.rect(g, x, BELT_Y + 22, 6, 2, 0xFF4A4668);
            boolean first = true;
            for (Letter l : belt) {
                int x, y;
                if (l.fly >= 0) {                                                  // flying into its box
                    float p = 1f - l.fly / (float) FLY;
                    int bx = 6 + l.flyTo * 72 + 18;
                    x = Math.round(l.x + (bx - l.x) * p);
                    y = Math.round(BELT_Y + (BOX_Y + 6 - BELT_Y) * p);
                } else {
                    x = Math.round(l.x);
                    y = BELT_Y;
                }
                envelope(g, x, y, l.express, cols[l.town]);
                if (l.fly < 0) {
                    ctxt(g, t("cutemod.job.town." + l.town), x + 15, y + 20, WHITE);   // the address
                    if (first) {                                                        // a bobbing arrow over the letter to sort now
                        int bob = Math.round((float) Math.sin(age / 5.0) * 2f);
                        JobsGfx.rect(g, x + 11, y - 8 + bob, 9, 1, YELLOW);
                        JobsGfx.rect(g, x + 12, y - 7 + bob, 7, 1, YELLOW);
                        JobsGfx.rect(g, x + 13, y - 6 + bob, 5, 1, YELLOW);
                        JobsGfx.rect(g, x + 14, y - 5 + bob, 3, 1, YELLOW);
                        first = false;
                    }
                }
            }
            if (moved > 0 && (moved / 8) % 2 == 0) ctxt(g, t("cutemod.job.moved"), W / 2, 92, YELLOW);
            ctxt(g, t("cutemod.job.delivered", ok), W / 2, 106, MUTED);
            for (int i = 0; i < 4; i++) {                                           // the four mailboxes
                int x = 6 + i * 72, town = slot[i], base = cols[town];
                boolean hov = in(mx, my, x, BOX_Y, 66, 38);
                if (hov) JobsGfx.halo(g, x + 6, BOX_Y + 8, 54, 28, 6, base, 0x3A);
                JobsGfx.puffy(g, x + 10, BOX_Y + 4, 46, 8, 4, JobsGfx.light(base, 0.2f));        // the lid
                JobsGfx.puffy(g, x + 6, BOX_Y + 8, 54, 28, 6, hov ? JobsGfx.light(base, 0.2f) : base);
                JobsGfx.rect(g, x + 58, BOX_Y, 2, 12, RED);
                JobsGfx.rect(g, x + 55, BOX_Y, 5, 4, JobsGfx.light(RED, 0.2f));
                App.roundRect(g, x + 14, BOX_Y + 15, 38, 3, 1, 0x55000000);
                ctxt(g, t("cutemod.job.town." + town), x + 33, BOX_Y + 21, 0xFF1B1530);
                ctxt(g, Integer.toString(i + 1), x + 33, BOX_Y + 28, 0xFF1B1530);
            }
            if (flash != 0) JobsGfx.rect(g, 0, BAR, W, 2, flash > 0 ? GREEN : RED);
        }

        @Override float quality() { return Math.max(0f, ok - miss) / 30f; }
        @Override String status() { return t("cutemod.job.delivered", ok); }
    }

    // ---------- barista: named drinks, a menu to learn and a queue of customers ----------
    private final class Cafe extends Shift {
        private final int[] cols = {0xFFFFFFFF, 0xFF8A5A3A, 0xFFF3E6D0, 0xFFF3D46A, 0xFFF58FB8};
        /** The recipes of the five drinks: the ingredients in order (0 cup, 1 coffee, 2 milk, 3 honey, 4 berry). */
        private static final int[][] RECIPES = {{0, 1, 2}, {0, 1, 2, 3}, {0, 2, 4}, {0, 4, 4, 3}, {0, 1, 4, 2}};
        private static final int[] SKIN = {0xFFFFE0CC, 0xFFF3C9A8, 0xFFD9A57E, 0xFFFFE9D6};
        private static final int[] HAIR = {0xFF3A2A3A, 0xFFB8651B, 0xFFF3D46A, 0xFFF58FB8};
        private final List<int[]> queue = new ArrayList<>();   // a customer: {drink, patience, max patience, look}
        private int prog, served, miss, flash, nextT = 20;
        private float points;

        @Override int duration() { return 3600; }

        /** The menu grows while you work: 3 drinks at first, all 5 after a few customers. */
        private int unlocked() { return served < 2 ? 3 : served < 5 ? 4 : 5; }

        @Override void tick() {
            if (flash > 0) flash--;
            if (queue.size() < 3 && --nextT <= 0) {
                int drink = rnd.nextInt(unlocked());
                int max = Math.max(260, 440 - served * 8) + 55 * RECIPES[drink].length;
                queue.add(new int[]{drink, max, max, rnd.nextInt(4)});
                nextT = Math.max(60, 170 - served * 6);
            }
            for (int i = queue.size() - 1; i >= 0; i--) {   // everyone in the queue gets impatient, not only the first one
                int[] c = queue.get(i);
                if (--c[1] <= 0) {
                    miss++;
                    flash = 12;
                    sfx("bad", 0.85F, 0.7F);                      // the customer left
                    fx.shake(8, 2f);
                    fx.burst(118 + i * 59 + 27, 43, RED, 8);
                    queue.remove(i);
                    if (i == 0) prog = 0;
                }
            }
        }

        private void press(int i) {
            if (queue.isEmpty()) return;
            int[] c = queue.get(0);
            int[] r = RECIPES[c[0]];
            if (i == r[prog]) {
                if (prog + 1 < r.length) sfx("pour", 0.9F + 0.08F * prog, 0.6F);       // every ingredient sounds a bit higher
                fx.burst(206 - (r.length * 40 - 4) / 2 + prog * 40 + 18, 105, cols[r[prog]], 5);
                if (++prog >= r.length) {
                    points += c[1] > c[2] / 2 ? 1.5f : 1f;   // quick service is worth more
                    sfx("serve");
                    boolean quick = c[1] > c[2] / 2;
                    fx.burst(145, 43, quick ? YELLOW : GREEN, quick ? 14 : 9);
                    fx.pop(145, 28, quick ? "+1.5" : "+1", quick ? YELLOW : GREEN);
                    if (quick) fx.confetti(145, 43, 8);
                    if (c[1] > c[2] / 2) sfx("great", 1F, 0.4F);
                    served++;
                    queue.remove(0);
                    prog = 0;
                }
            } else {                                          // wrong ingredient: pour it out, the customer waits longer
                sfx("bad");
                fx.shake(6, 2f);
                fx.burst(206, 105, RED, 6);
                prog = 0;
                flash = 12;
                c[1] -= 30;
            }
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 5; i++) if (in(x, y, 6 + i * 58, 128, 54, 30)) { press(i); return true; }
            return true;
        }

        @Override boolean key(int k) {
            if (k >= 49 && k <= 53) { press(k - 49); return true; }
            return false;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            JobsGfx.sky(g, 0xFF2A2142, 0xFF1A1430);
            JobsGfx.ground(g, 124, 0xFF4A3248, 0xFF2E1E34);                       // the wooden counter under the buttons
            // the menu on the left: the recipe of every drink in colors (you learn them while you work)
            JobsUi.card(g, 4, 22, 108, 100, 6, 0xFF2A2040, 0xFF3B3063);
            ctxt(g, t("cutemod.job.menu"), 58, 25, YELLOW);
            for (int i = 0; i < 5; i++) {
                int y = 37 + i * 17;
                boolean open = i < unlocked();
                App.roundRect(g, 6, y - 2, 104, 15, 4, open ? 0xFF352A58 : 0xFF241C3C);
                txt(g, font().plainSubstrByWidth(t("cutemod.job.drink." + i), 56), 9, y + 1, open ? WHITE : 0xFF5A5078);
                if (open) for (int k = 0; k < RECIPES[i].length; k++) {
                    int sx = 68 + k * 10, sc = cols[RECIPES[i][k]];
                    App.roundRect(g, sx, y + 2, 8, 8, 3, JobsGfx.shade(sc, 0.3f));
                    App.roundRect(g, sx, y + 1, 8, 8, 3, sc);
                }
            }
            // the queue of customers
            for (int i = 0; i < 3; i++) {
                int x = 118 + i * 59;
                if (i >= queue.size()) { App.roundRect(g, x, 24, 55, 38, 5, 0xFF231B3D); continue; }
                int[] c = queue.get(i);
                float f = Math.max(0f, c[1] / (float) c[2]);
                if (i == 0) JobsGfx.halo(g, x, 24, 55, 38, 5, ACCENT, 0x20);
                JobsUi.card(g, x, 24, 55, 38, 5, f < 0.3f ? 0xFF4A2A3A : 0xFF2A2040, i == 0 ? ACCENT : 0xFF3A2F5A);
                JobsGfx.orb(g, x + 12, 37, 7, SKIN[c[3]]);
                App.roundRect(g, x + 5, 29, 14, 5, 2, HAIR[c[3]]);
                Skin.rect(g, x + 9, 37, 1, 2, 0xFF3A2A3A);
                Skin.rect(g, x + 14, 37, 1, 2, 0xFF3A2A3A);
                if (f >= 0.5f) { Skin.rect(g, x + 6, 40, 2, 1, 0x88FF8FA0); Skin.rect(g, x + 17, 40, 2, 1, 0x88FF8FA0); }   // a happy blush
                Skin.rect(g, x + 10, f < 0.3f ? 42 : 41, 5, 1, 0xFF3A2A3A);
                if (f < 0.3f && (JobsGfx.ambient() / 5) % 2 == 0) ctxt(g, "!", x + 47, 26, RED);                        // about to leave
                txt(g, font().plainSubstrByWidth(t("cutemod.job.drink." + c[0]), 50), x + 3, 47, WHITE);
                JobsUi.bar(g, x + 3, 56, 49, 4, f, f > 0.5f ? GREEN : f > 0.25f ? YELLOW : RED, 0xFF3A2F5A);
            }
            // the drink you are making now
            JobsUi.card(g, 118, 68, 176, 54, 6, flash > 0 ? 0xFF4A2A3A : 0xFF231B3D, flash > 0 ? RED : 0xFF3B3063);
            if (queue.isEmpty()) {
                ctxt(g, "...", 206, 90, MUTED);
            } else {
                int[] r = RECIPES[queue.get(0)[0]];
                big(g, t("cutemod.job.drink." + queue.get(0)[0]), 206, 72, YELLOW, 1.5f);
                int total = r.length * 40 - 4, x0 = 206 - total / 2;
                for (int k = 0; k < r.length; k++) {
                    int x = x0 + k * 40;
                    boolean done = k < prog;
                    if (k == prog) JobsGfx.halo(g, x, 95, 36, 20, 6, WHITE, 0x38);
                    JobsGfx.puffy(g, x, 95, 36, 20, 6, done ? 0xFF6A6A7A : cols[r[k]]);
                    ctxt(g, done ? "OK" : Integer.toString(r[k] + 1), x + 18, 101, 0xFF3A2A3A);
                }
            }
            ctxt(g, t("cutemod.job.served", served), 206, 112, MUTED);
            for (int i = 0; i < 5; i++) {
                int x = 6 + i * 58;
                boolean hov = in(mx, my, x, 128, 54, 30);
                if (hov) JobsGfx.halo(g, x, 128, 54, 30, 6, cols[i], 0x30);
                JobsGfx.puffy(g, x, 128, 54, 30, 6, hov ? 0xFF4A3A70 : 0xFF3A2F5A);
                JobsGfx.puffy(g, x + 4, 132, 46, 8, 3, cols[i]);
                ctxt(g, (i + 1) + " " + t("cutemod.job.ing." + i), x + 27, 146, WHITE);
            }
        }

        @Override float quality() { return Math.max(0f, points - miss * 0.7f) / 16f; }
        @Override String status() { return t("cutemod.job.served", served); }
    }

    // ---------- courier: colour-coded parcels, three houses, express orders and traffic ----------
    private final class Courier extends Shift {
        private static final int COLS = 15, ROWS = 7, CELL = 20, OY = 22, EXPRESS_TICKS = 1000;
        private static final int[] PC = {0xFFE5484D, 0xFF2F7FD6, 0xFF5BBF6A};     // colours of the three houses and their parcels
        private final boolean[][] wall = new boolean[COLS][ROWS];
        private final int[] carX = {3, 11}, carRow = {2, 4}, carTick = new int[2];
        private final int[] hx = new int[3], hy = new int[3];
        private final List<int[]> ground = new ArrayList<>();                    // {x, y, colour, express 0/1, ticks left}
        private final List<int[]> carry = new ArrayList<>();                     // {colour, express 0/1, ticks left}
        private int px = 1, py = 3, stun, delivered, miss, flash;
        private float points;

        Courier() {
            java.util.Arrays.fill(hx, -1);
            java.util.Arrays.fill(hy, -1);
            for (int n = 0; n < 16; n++) {
                int x = rnd.nextInt(COLS), y = rnd.nextInt(ROWS);
                if (road(y) || (x == 1 && y == 3)) continue;
                wall[x][y] = true;
            }
            for (int i = 0; i < 3; i++) placeHouse(i);
            while (ground.size() < 3 && spawn()) { }
        }

        @Override int duration() { return 3600; }

        private boolean road(int y) { return y == 2 || y == 4; }

        private boolean houseAt(int x, int y) {
            for (int i = 0; i < 3; i++) if (hx[i] == x && hy[i] == y) return true;
            return false;
        }

        private boolean parcelAt(int x, int y) {
            for (int[] p : ground) if (p[0] == x && p[1] == y) return true;
            return false;
        }

        private boolean expressAround() {
            for (int[] p : ground) if (p[3] == 1) return true;
            for (int[] c : carry) if (c[1] == 1) return true;
            return false;
        }

        private void placeHouse(int i) {
            for (int tries = 0; tries < 200; tries++) {
                int x = rnd.nextInt(COLS), y = rnd.nextInt(ROWS);
                if (wall[x][y] || road(y) || houseAt(x, y) || Math.abs(x - px) + Math.abs(y - py) < 4) continue;
                hx[i] = x;
                hy[i] = y;
                return;
            }
            hx[i] = COLS - 2 - i;                   // row 0 is never a road
            hy[i] = 0;
            wall[hx[i]][0] = false;
        }

        /** A new parcel somewhere free. After two deliveries one of them may be an express parcel (a timer runs). */
        private boolean spawn() {
            for (int tries = 0; tries < 80; tries++) {
                int x = rnd.nextInt(COLS), y = rnd.nextInt(ROWS);
                if (wall[x][y] || road(y) || houseAt(x, y) || parcelAt(x, y) || (x == px && y == py)) continue;
                if (Math.abs(x - px) + Math.abs(y - py) < 3) continue;
                boolean express = delivered >= 2 && rnd.nextInt(4) == 0 && !expressAround();
                ground.add(new int[]{x, y, rnd.nextInt(3), express ? 1 : 0, express ? EXPRESS_TICKS : 0});
                return true;
            }
            return false;
        }

        @Override void tick() {
            if (stun > 0) stun--;
            if (flash > 0) flash--;
            int[] period = {15, delivered >= 4 ? 9 : 15};            // the second car gets faster
            for (int i = 0; i < 2; i++) {
                if (++carTick[i] >= period[i]) { carTick[i] = 0; carX[i] = (carX[i] + (i == 0 ? 1 : COLS - 1)) % COLS; }
            }
            hitCheck();
            for (java.util.Iterator<int[]> it = ground.iterator(); it.hasNext();) {
                int[] p = it.next();
                if (p[3] == 1 && --p[4] <= 0) { it.remove(); miss++; sfx("bad", 0.85F, 0.6F); fx.burst(p[0] * CELL + 10, OY + p[1] * CELL + 10, RED, 6); }       // an express parcel nobody took
            }
            for (java.util.Iterator<int[]> it = carry.iterator(); it.hasNext();) {
                int[] c = it.next();
                if (c[1] == 1 && --c[2] <= 0) { it.remove(); miss++; sfx("bad", 0.85F, 0.6F); }       // an express parcel that came too late
            }
            while (ground.size() < 3 && spawn()) { }
        }

        /** A car hit: the courier is stunned and drops the last parcel he carried (it is lost). */
        private void hitCheck() {
            for (int i = 0; i < 2; i++) {
                if (stun == 0 && py == carRow[i] && px == carX[i]) {
                    stun = 90;
                    sfx("bump"); sfx("honk", 1F, 0.5F);
                    fx.shake(10, 3f);
                    fx.burst(px * CELL + 10, OY + py * CELL + 10, RED, 10);
                    if (!carry.isEmpty()) { carry.remove(carry.size() - 1); miss++; }
                }
            }
        }

        @Override boolean key(int k) {
            if (stun > 0) return true;
            int dx = 0, dy = 0;
            switch (k) {
                case 262, 68 -> dx = 1;
                case 263, 65 -> dx = -1;
                case 264, 83 -> dy = 1;
                case 265, 87 -> dy = -1;
                default -> { return false; }
            }
            int nx = px + dx, ny = py + dy;
            if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS || wall[nx][ny]) return true;
            px = nx;
            py = ny;
            hitCheck();
            pickAndDeliver();
            return true;
        }

        private void pickAndDeliver() {
            for (java.util.Iterator<int[]> it = ground.iterator(); it.hasNext();) {
                int[] p = it.next();
                if (p[0] == px && p[1] == py && carry.size() < 2) { carry.add(new int[]{p[2], p[3], p[4]}); it.remove(); sfx("pop", 1.2F, 0.7F); fx.burst(px * CELL + 10, OY + py * CELL + 10, PC[p[2]], 5); }
            }
            for (int i = 0; i < 3; i++) {
                if (hx[i] != px || hy[i] != py) continue;
                for (java.util.Iterator<int[]> it = carry.iterator(); it.hasNext();) {
                    int[] c = it.next();
                    if (c[0] != i) continue;
                    points += c[1] == 1 ? 2f : 1f;                   // express parcels pay double
                    sfx("deliver");
                    delivered++;
                    flash = 8;
                    fx.burst(px * CELL + 10, OY + py * CELL + 8, c[1] == 1 ? YELLOW : PC[i], c[1] == 1 ? 14 : 9);
                    fx.pop(px * CELL + 10, OY + py * CELL, c[1] == 1 ? "+2" : "+1", c[1] == 1 ? YELLOW : GREEN);
                    if (c[1] == 1) fx.confetti(px * CELL + 10, OY + py * CELL + 8, 8);
                    it.remove();
                }
            }
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            for (int x = 0; x < COLS; x++) {
                for (int y = 0; y < ROWS; y++) {
                    int c = road(y) ? 0xFF4A4A5A : ((x + y) % 2 == 0 ? 0xFF4F9A58 : 0xFF58A862);
                    Skin.rect(g, x * CELL, OY + y * CELL, CELL, CELL, c);
                    if (road(y)) {
                        Skin.rect(g, x * CELL, OY + y * CELL, CELL, 1, 0xFF5E5E70);                      // a lit kerb
                        Skin.rect(g, x * CELL, OY + y * CELL + CELL - 1, CELL, 1, 0xFF3A3A48);
                        App.roundRect(g, x * CELL + 4, OY + y * CELL + 9, 12, 2, 1, 0xFFE0D8A0);
                    }
                    if (wall[x][y]) {                                                                      // a tree
                        JobsGfx.shadow(g, x * CELL + 10, OY + y * CELL + 18, 14);
                        Skin.rect(g, x * CELL + 8, OY + y * CELL + 12, 4, 7, 0xFF6A4A2A);
                        JobsGfx.orb(g, x * CELL + 10, OY + y * CELL + 8, 7, 0xFF3F9A4A);
                    }
                }
            }
            for (int i = 0; i < 3; i++) {                              // the houses, each with the colour of its parcels
                int gx = hx[i] * CELL, gy = OY + hy[i] * CELL;
                JobsGfx.shadow(g, gx + 10, gy + 19, 18);
                JobsGfx.puffy(g, gx + 3, gy + 9, 14, 9, 2, 0xFFF3E6D0);
                JobsGfx.puffy(g, gx + 1, gy + 4, 18, 6, 3, PC[i]);
                App.roundRect(g, gx + 8, gy + 12, 4, 6, 1, 0xFF8A5A3A);
                Skin.rect(g, gx + 4, gy + 11, 3, 3, 0xFFBFE6F8);
            }
            for (int[] p : ground) {                                   // the parcels waiting on the ground
                int gx = p[0] * CELL, gy = OY + p[1] * CELL;
                if (p[3] == 1) JobsGfx.glow(g, gx + 10, gy + 11, 12, YELLOW, 0x0C);
                JobsGfx.shadow(g, gx + 10, gy + 18, 14);
                JobsGfx.puffy(g, gx + 3, gy + 6, 14, 11, 3, PC[p[2]]);
                Skin.rect(g, gx + 9, gy + 6, 2, 11, 0xFFFFE9A0);
                Skin.rect(g, gx + 3, gy + 10, 14, 2, 0x55FFE9A0);
                if (p[3] == 1) {
                    JobsGfx.orb(g, gx + 16, gy + 6, 3, YELLOW);
                    float f = Math.max(0f, p[4] / (float) EXPRESS_TICKS);
                    JobsUi.bar(g, gx + 1, gy + 1, 18, 3, f, f > 0.35f ? YELLOW : RED, 0xFF3A2F5A);
                }
            }
            for (int i = 0; i < 2; i++) {
                int cx = carX[i] * CELL, cy = OY + carRow[i] * CELL;
                JobsGfx.shadow(g, cx + 10, cy + 17, 20);
                JobsGfx.puffy(g, cx + 1, cy + 4, 18, 12, 4, i == 0 ? 0xFFE5484D : 0xFF2F7FD6);
                Skin.rect(g, i == 0 ? cx + 10 : cx + 4, cy + 6, 6, 4, 0xFFBFE6F8);                       // the windscreen is in front
                Skin.rect(g, i == 0 ? cx + 17 : cx + 1, cy + 7, 2, 2, 0xFFFFF3B0);                       // a headlight
                Skin.rect(g, cx + 3, cy + 15, 4, 2, 0xFF1B1530);
                Skin.rect(g, cx + 13, cy + 15, 4, 2, 0xFF1B1530);
            }
            int ppx = px * CELL, ppy = OY + py * CELL;
            boolean blink = stun > 0 && (stun / 6) % 2 == 0;
            if (!blink) {
                JobsGfx.shadow(g, ppx + 10, ppy + 18, 14);
                JobsGfx.orb(g, ppx + 10, ppy + 10, 7, 0xFFFFF3B0);
                App.roundRect(g, ppx + 5, ppy + 3, 10, 4, 2, 0xFF2F7FD6);                                 // a cap
                Skin.rect(g, ppx + 7, ppy + 8, 2, 2, 0xFF3A2A3A);
                Skin.rect(g, ppx + 11, ppy + 8, 2, 2, 0xFF3A2A3A);
                for (int k = 0; k < carry.size(); k++) {                // what he carries, above his head
                    int[] c = carry.get(k);
                    int bx = ppx + 1 + k * 10, by = Math.max(OY - 4, ppy - 6);
                    if (c[1] == 1) JobsGfx.glow(g, bx + 4, by + 3, 8, YELLOW, 0x10);
                    JobsGfx.puffy(g, bx, by, 9, 7, 2, PC[c[0]]);
                }
            }
            if (stun > 0) JobsGfx.sparkle(g, ppx + 10 + (int) Math.round(Math.cos(shiftTick / 4.0) * 8), ppy + 2, 3, YELLOW, 1f);   // dizzy
            if (flash > 0) Skin.rect(g, 0, OY, W, 2, GREEN);
        }

        @Override float quality() { return Math.max(0f, points - miss * 0.5f) / 18f; }
        @Override String status() { return t("cutemod.job.delivered", delivered); }
    }

    // ---------- artist: copy a picture, then paint it from memory, then finish its mirror half ----------
    private final class Artist extends Shift {
        private static final int GW = 8, GH = 6, CELL = 14;
        /** Little pictures (digits are the palette: 0 white, 1 red, 2 blue, 3 yellow, 4 green). Every one is mirror-symmetric. */
        private static final String[][] ART = {
                {"01100110", "11111111", "11111111", "01111110", "00111100", "00011000"},   // heart
                {"00033000", "00333300", "33333333", "03333330", "00333300", "03300330"},   // star
                {"00044000", "00444400", "04444440", "44444444", "00033000", "00033000"},   // tree
                {"00011000", "00111100", "01111110", "03333330", "03322330", "03322330"},   // house
                {"00111100", "01100110", "11111111", "10111101", "00033000", "00033000"},   // mushroom
                {"00222200", "02222220", "22222222", "02222220", "00222200", "00022000"},   // diamond
                {"00333300", "03333330", "33233233", "33333333", "03111130", "00333300"},   // smiley
                {"11111111", "13333331", "13444431", "13422431", "13444431", "13333331"},   // target
        };
        private final int[] pal = {0xFFFFFFFF, RED, 0xFF2F7FD6, 0xFFF3D46A, 0xFF5BBF6A};
        private final int[] target = new int[GW * GH], canvas = new int[GW * GH];
        private int sel = 1, sent, round, mode, peek, peekMax, memRounds, face, faceT;
        private float total, lastAcc;

        Artist() { gen(); }

        @Override int duration() { return 3600; }

        /** Round 0: copy it. Round 1: it is shown for a moment, then hidden. Round 2: only the left half is given. */
        private void gen() {
            mode = round % 3;
            round++;
            String[] pic = ART[rnd.nextInt(ART.length)];
            int[] perm = {0, 1, 2, 3, 4};
            if (rnd.nextBoolean()) {                                 // the same picture in other colours
                for (int i = 4; i > 1; i--) { int j = 1 + rnd.nextInt(i); int tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp; }
            }
            for (int y = 0; y < GH; y++) for (int x = 0; x < GW; x++) target[y * GW + x] = perm[pic[y].charAt(x) - '0'];
            java.util.Arrays.fill(canvas, 0);
            if (mode == 2) for (int y = 0; y < GH; y++) for (int x = 0; x < GW / 2; x++) canvas[y * GW + x] = target[y * GW + x];
            if (mode == 1) { peekMax = Math.max(90, 200 - 16 * memRounds); peek = peekMax; memRounds++; }
            else peek = 0;
        }

        @Override void tick() {
            if (peek > 0) peek--;
            if (faceT > 0) faceT--;
        }

        private boolean paint(int x, int y) {
            int cx = (x - 174) / CELL, cy = (y - 30) / CELL;
            if (x >= 174 && y >= 30 && cx < GW && cy < GH) {
                if (mode == 2 && cx < GW / 2) return true;           // the given half stays
                if (canvas[cy * GW + cx] != sel) {                   // only when the cell really changes, so dragging is not a machine gun
                    sfx("paint", 0.9F + sel * 0.06F, 0.5F);
                    fx.burst(174 + cx * CELL + CELL / 2, 30 + cy * CELL + CELL / 2, pal[sel], 3);
                }
                canvas[cy * GW + cx] = sel;
                return true;
            }
            return false;
        }

        private void send() {
            int ok = 0, all = 0;
            for (int y = 0; y < GH; y++) {
                for (int x = mode == 2 ? GW / 2 : 0; x < GW; x++) {  // in the mirror round only the half you drew counts
                    all++;
                    if (target[y * GW + x] == canvas[y * GW + x]) ok++;
                }
            }
            float acc = ok / (float) all;
            total += acc * acc * (mode == 1 ? 1.15f : mode == 2 ? 1.1f : 1f);
            lastAcc = acc;
            face = acc >= 0.9f ? 2 : acc >= 0.65f ? 1 : 0;
            faceT = 70;
            fx.burst(150, 98, face == 2 ? YELLOW : face == 1 ? 0xFFF3C45A : 0xFFB8A8D8, face == 2 ? 14 : 8);
            fx.pop(150, 78, Math.round(acc * 100) + "%", face == 2 ? YELLOW : face == 1 ? GREEN : RED);
            if (face == 2) fx.confetti(150, 98, 10);
            if (face == 0) fx.shake(6, 1.5f);
            sfx(face == 2 ? "great" : face == 1 ? "good" : "bad");
            sent++;
            gen();
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 5; i++) if (in(x, y, 14 + i * 30, 124, 26, 18)) { sel = i; return true; }
            if (in(x, y, 196, 124, 96, 18)) { send(); return true; }
            paint(x, y);
            return true;
        }

        @Override boolean key(int k) {
            if (k >= 49 && k <= 53) { sel = k - 49; return true; }
            return false;
        }

        @Override boolean drag(int x, int y) { return paint(x, y); }

        @Override void render(GuiGraphics g, int mx, int my) {
            JobsGfx.sky(g, 0xFF2A2142, 0xFF1B1530);
            String[] names = {"copy", "memory", "mirror"};
            ctxt(g, t("cutemod.job.art." + names[mode]), 14 + GW * CELL / 2, 20, YELLOW);
            ctxt(g, t("cutemod.job.canvas"), 174 + GW * CELL / 2, 20, MUTED);
            JobsUi.card(g, 10, 27, GW * CELL + 7, GH * CELL + 6, 5, 0xFF231B3D, 0xFF3B3063);          // the picture and the canvas sit on little boards
            JobsUi.card(g, 170, 27, GW * CELL + 7, GH * CELL + 6, 5, 0xFF231B3D, 0xFF3B3063);
            boolean showTarget = mode == 0 || (mode == 1 && peek > 0);
            for (int x = 0; x < GW; x++) {
                for (int y = 0; y < GH; y++) {
                    if (mode != 2) {
                        int c = showTarget ? pal[target[y * GW + x]] : 0xFF3A2F5A;
                        App.roundRect(g, 14 + x * CELL, 30 + y * CELL, CELL - 1, CELL - 1, 3, c);
                    }
                    App.roundRect(g, 174 + x * CELL, 30 + y * CELL, CELL - 1, CELL - 1, 3, pal[canvas[y * GW + x]]);
                }
            }
            if (mode == 1 && peek <= 0) ctxt(g, "?", 14 + GW * CELL / 2, 30 + GH * CELL / 2 - 4, MUTED);
            if (mode == 1 && peek > 0) {                             // time left to look at it
                JobsUi.bar(g, 14, 30 + GH * CELL + 5, GW * CELL - 1, 3, peek / (float) peekMax, YELLOW, 0xFF3A2F5A);
            }
            if (mode == 2) {
                var lines = font().split(net.minecraft.network.chat.FormattedText.of(t("cutemod.job.art.mirror_hint")), GW * CELL - 4);
                for (int i = 0; i < lines.size() && i < 5; i++) {
                    Skin.str(g, font(), lines.get(i), 14 + (GW * CELL - font().width(lines.get(i))) / 2, 44 + i * 11, 0xFFD8D0EE, false);
                }
                for (int y = 30; y < 30 + GH * CELL; y += 4) Skin.rect(g, 174 + GW / 2 * CELL - 1, y, 1, 2, WHITE);   // the mirror line
            } else {
                ctxt(g, "->", 150, 66, MUTED);
            }
            if (faceT > 0) {                                         // how the customer liked it
                int fy = 98;
                int fc = face == 2 ? 0xFFFFD866 : face == 1 ? 0xFFF3C45A : 0xFFB8A8D8;
                if (face == 2) JobsGfx.glow(g, 150, fy, 16, YELLOW, 0x10);
                JobsGfx.orb(g, 150, fy, 9, fc);
                Skin.rect(g, 146, fy - 3, 2, 2, 0xFF3A2A3A);
                Skin.rect(g, 152, fy - 3, 2, 2, 0xFF3A2A3A);
                if (face == 2) { Skin.rect(g, 145, fy + 2, 10, 2, 0xFF3A2A3A); Skin.rect(g, 146, fy + 4, 8, 1, 0xFF3A2A3A); }
                else if (face == 1) Skin.rect(g, 146, fy + 3, 8, 2, 0xFF3A2A3A);
                else { Skin.rect(g, 146, fy + 5, 8, 2, 0xFF3A2A3A); Skin.rect(g, 145, fy + 6, 2, 1, 0xFF3A2A3A); Skin.rect(g, 153, fy + 6, 2, 1, 0xFF3A2A3A); }
                if (face == 2) { JobsGfx.sparkle(g, 138, fy - 8, 3, YELLOW, faceT / 70f); JobsGfx.sparkle(g, 162, fy - 4, 3, WHITE, faceT / 70f); }
                ctxt(g, Math.round(lastAcc * 100) + "%", 150, fy + 12, MUTED);
            }
            for (int i = 0; i < 5; i++) {
                int x = 14 + i * 30;
                if (i == sel) App.roundRect(g, x - 2, 122, 30, 22, 7, WHITE);
                JobsGfx.puffy(g, x, 124, 26, 18, 5, pal[i]);
                ctxt(g, Integer.toString(i + 1), x + 13, 129, i == 0 || i == 3 ? 0xFF1B1530 : WHITE);
            }
            boolean hov = in(mx, my, 196, 124, 96, 18);
            if (hov) JobsGfx.halo(g, 196, 124, 96, 18, 6, GREEN, 0x30);
            JobsGfx.puffy(g, 196, 124, 96, 18, 6, hov ? JobsGfx.light(GREEN, 0.25f) : GREEN);
            ctxt(g, t("cutemod.job.send"), 244, 129, 0xFF1B1530);
            ctxt(g, t("cutemod.job.sent", sent), W / 2, 150, MUTED);
        }

        @Override float quality() { return Math.min(1f, total / 4.0f); }
        @Override String status() { return t("cutemod.job.sent", sent); }
    }

    // ---------- pet sitter: pick an item, give it to the pet that asks; the sick ones need two steps, runaways must be caught ----------
    private final class Pets extends Shift {
        private static final int N = 4, CX0 = 37, DX = 75, TRAY_Y = 126;
        private final int[] pcol = {0xFFF5B06B, 0xFFB98A60, 0xFFF4F0F0, 0xFFD8C8A0};
        private final int[] ncol = {0xFFE59A6A, 0xFFE5484D, 0xFF6AA8F0, 0xFFB57BD6, 0xFFF4F0F0};   // food, play, wash, sleep, medicine
        private final int[] need = {-1, -1, -1, -1}, timer = new int[N], maxT = new int[N], wait = {30, 70, 110, 150}, stage = new int[N];
        private int held, served, miss, wrong, combo, runnerPet = -1, runnerX, runnerDir;
        private float points;

        @Override int duration() { return 3600; }

        private int nextWait() { return 30 + rnd.nextInt(Math.max(30, 100 - served * 2)); }

        private void startNeed(int i) {
            if (served >= 3 && rnd.nextInt(7) == 0) {               // a sick pet: medicine first, then a pat
                need[i] = 4;
                stage[i] = 1;
                timer[i] = Math.max(300, 460 - served * 5);
            } else {
                need[i] = rnd.nextInt(4);
                stage[i] = 0;
                timer[i] = Math.max(190, 360 - served * 5);
            }
            maxT[i] = timer[i];
        }

        private void done(int i, float base) {
            int fxX = CX0 + i * DX;
            fx.burst(fxX, 64, base > 1.5f ? YELLOW : GREEN, base > 1.5f ? 14 : 9);
            fx.pop(fxX, 34, base > 1.5f ? "+2" : combo >= 3 ? "x" + (combo + 1) : "+1", base > 1.5f ? YELLOW : GREEN);
            if (base > 1.5f) fx.confetti(fxX, 60, 8);
            points += base + (combo >= 3 ? 0.25f : 0f);
            sfx(base > 1.5f ? "great" : "good", 1F + Math.min(combo, 6) * 0.03F, 0.7F);
            served++;
            combo++;
            need[i] = -1;
            stage[i] = 0;
            wait[i] = nextWait();
        }

        @Override void tick() {
            for (int i = 0; i < N; i++) {
                if (runnerPet == i) continue;                        // this one has run away
                if (need[i] < 0) {
                    if (--wait[i] <= 0) startNeed(i);
                } else if (--timer[i] <= 0) {
                    miss++;
                    combo = 0;
                    sfx("bad", 0.85F, 0.6F);
                    fx.shake(6, 2f);
                    fx.burst(CX0 + i * DX, 70, RED, 8);
                    need[i] = -1;
                    stage[i] = 0;
                    wait[i] = nextWait();
                }
            }
            if (runnerPet >= 0) {
                runnerX += runnerDir * 2;
                if (runnerX < -14 || runnerX > W + 14) {             // gone for good: it comes back later, but it counts as missed
                    miss++;
                    sfx("bad", 0.8F, 0.6F);
                    fx.shake(6, 2f);
                    combo = 0;
                    wait[runnerPet] = nextWait();
                    runnerPet = -1;
                }
            } else if (served >= 4 && rnd.nextInt(800) == 0) {
                for (int i = 0; i < N; i++) {
                    if (need[i] < 0) {
                        runnerPet = i;
                        runnerX = CX0 + i * DX;
                        runnerDir = runnerX < W / 2 ? -1 : 1;
                        break;
                    }
                }
            }
        }

        private void give(int i, int item) {
            if (need[i] < 0) return;                                 // it asks for nothing: no harm done
            if (need[i] == 4) {
                if (stage[i] == 1 && item == 4) { stage[i] = 2; timer[i] = Math.max(timer[i], 200); maxT[i] = timer[i]; sfx("pop", 1.2F, 0.7F); }
                else if (stage[i] == 1) mistake(i);
            } else if (need[i] == item) done(i, 1f);
            else mistake(i);
        }

        private void mistake(int i) {
            wrong++;
            combo = 0;
            timer[i] -= 50;
            sfx("bad");
            fx.burst(CX0 + i * DX, 70, RED, 6);
        }

        @Override boolean click(int x, int y) {
            if (runnerPet >= 0 && in(x, y, runnerX - 13, 98, 26, 26)) {
                points += 1.5f;
                sfx("great", 1F, 0.7F);
                fx.burst(runnerX, 108, YELLOW, 12);
                fx.pop(runnerX, 90, "+1.5", YELLOW);
                served++;
                combo++;
                wait[runnerPet] = nextWait();
                runnerPet = -1;
                return true;
            }
            for (int j = 0; j < 5; j++) if (in(x, y, 12 + j * 57, TRAY_Y, 52, 28)) { held = j; return true; }
            for (int i = 0; i < N; i++) {
                if (in(x, y, CX0 + i * DX - 34, 30, 68, 70)) {
                    if (need[i] == 4 && stage[i] == 2) done(i, 2f);      // the pat after the medicine
                    else give(i, held);
                    return true;
                }
            }
            return true;
        }

        @Override boolean key(int k) {
            if (k >= 49 && k <= 53) { held = k - 49; return true; }
            return false;
        }

        /** A 13 x 13 picture of an item or of a heart (5) centered on cx, cy. */
        private void icon(GuiGraphics g, int j, int cx, int cy) {
            switch (j) {
                case 0 -> {
                    Skin.rect(g, cx - 6, cy - 1, 12, 6, 0xFFB07A4A);
                    Skin.rect(g, cx - 4, cy - 4, 8, 3, 0xFFE59A6A);
                }
                case 1 -> {
                    Skin.disc(g, cx, cy, 5, 0xFFE5484D);
                    Skin.rect(g, cx - 5, cy - 1, 10, 2, WHITE);
                }
                case 2 -> {
                    Skin.disc(g, cx - 3, cy + 1, 4, 0xFF6AA8F0);
                    Skin.disc(g, cx + 3, cy - 3, 3, 0xFFBFE6F8);
                    Skin.disc(g, cx + 4, cy + 3, 2, WHITE);
                }
                case 3 -> {
                    Skin.rect(g, cx - 6, cy - 3, 12, 7, 0xFFB57BD6);
                    Skin.str(g, font(), "z", cx - 2, cy - 4, WHITE, false);
                }
                case 4 -> {
                    Skin.rect(g, cx - 5, cy - 5, 10, 10, WHITE);
                    Skin.rect(g, cx - 1, cy - 4, 2, 8, RED);
                    Skin.rect(g, cx - 4, cy - 1, 8, 2, RED);
                }
                default -> {                                        // a heart: pat it
                    Skin.disc(g, cx - 3, cy - 2, 3, RED);
                    Skin.disc(g, cx + 3, cy - 2, 3, RED);
                    Skin.rect(g, cx - 5, cy - 1, 10, 3, RED);
                    Skin.rect(g, cx - 3, cy + 2, 6, 2, RED);
                    Skin.rect(g, cx - 1, cy + 4, 2, 1, RED);
                }
            }
        }

        private void drawPet(GuiGraphics g, int i, int cx) {
            int c = pcol[i], dark = 0xFF3A2A3A, cy = 78 + (int) Math.round(Math.sin((shiftTick + i * 17) / 7.0) * 1.5);
            boolean blink = (shiftTick + i * 37) % 120 < 4;
            JobsGfx.shadow(g, cx, 95, 38);
            switch (i) {
                case 0 -> {                                          // cat: pointed ears, whiskers
                    App.roundRect(g, cx - 14, cy - 20, 7, 9, 3, c);
                    App.roundRect(g, cx + 7, cy - 20, 7, 9, 3, c);
                    Skin.rect(g, cx - 12, cy - 18, 3, 5, 0xFFFFB6D2);
                    Skin.rect(g, cx + 9, cy - 18, 3, 5, 0xFFFFB6D2);
                    JobsGfx.orb(g, cx, cy, 15, c);
                    Skin.rect(g, cx - 20, cy + 2, 10, 1, dark);
                    Skin.rect(g, cx + 10, cy + 2, 10, 1, dark);
                }
                case 1 -> {                                          // dog: floppy ears
                    App.roundRect(g, cx - 20, cy - 12, 7, 16, 3, 0xFF6A4A2A);
                    App.roundRect(g, cx + 13, cy - 12, 7, 16, 3, 0xFF6A4A2A);
                    JobsGfx.orb(g, cx, cy, 15, c);
                    JobsGfx.orb(g, cx, cy + 6, 6, 0xFFE8D0B0);
                }
                case 2 -> {                                          // bunny: tall ears
                    App.roundRect(g, cx - 10, cy - 30, 6, 18, 3, c);
                    App.roundRect(g, cx + 4, cy - 30, 6, 18, 3, c);
                    App.roundRect(g, cx - 8, cy - 27, 2, 12, 1, 0xFFFFB6D2);
                    App.roundRect(g, cx + 6, cy - 27, 2, 12, 1, 0xFFFFB6D2);
                    JobsGfx.orb(g, cx, cy, 15, c);
                }
                default -> {                                         // hamster: round, with cheeks
                    JobsGfx.orb(g, cx - 10, cy - 14, 4, c);
                    JobsGfx.orb(g, cx + 10, cy - 14, 4, c);
                    JobsGfx.orb(g, cx, cy, 16, c);
                    Skin.disc(g, cx - 11, cy + 5, 5, 0xFFF3B6B6);
                    Skin.disc(g, cx + 11, cy + 5, 5, 0xFFF3B6B6);
                }
            }
            if (blink) {
                Skin.rect(g, cx - 6, cy, 3, 1, dark);
                Skin.rect(g, cx + 3, cy, 3, 1, dark);
            } else {
                Skin.rect(g, cx - 6, cy - 2, 2, 3, dark);
                Skin.rect(g, cx + 4, cy - 2, 2, 3, dark);
                Skin.rect(g, cx - 6, cy - 2, 1, 1, 0xCCFFFFFF);          // a tiny shine in the eyes
                Skin.rect(g, cx + 4, cy - 2, 1, 1, 0xCCFFFFFF);
            }
            Skin.rect(g, cx - 2, cy + 4, 4, 2, dark);
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            JobsGfx.sky(g, 0xFF2E2446, 0xFF1C1632);
            JobsGfx.glow(g, W / 2, 50, 60, 0xFFFFD866, 0x05);
            JobsGfx.ground(g, 96, 0xFF4A3A5A, 0xFF2E2240);                         // the floor of the room
            for (int i = 0; i < N; i++) {
                int cx = CX0 + i * DX;
                if (runnerPet == i) {                                // the pet is not here, only its empty spot
                    App.roundRect(g, cx - 20, 92, 40, 3, 1, 0xFF2A2040);
                    continue;
                }
                drawPet(g, i, cx);
                if (need[i] >= 0) {
                    boolean pat = need[i] == 4 && stage[i] == 2;
                    int bc = pat ? 0xFFFFB6D2 : ncol[need[i]];
                    JobsGfx.glow(g, cx, 42, 16, bc, 0x0C);
                    Skin.rect(g, cx - 1, 52, 3, 3, bc);                // the tail of the bubble
                    JobsGfx.orb(g, cx, 42, 11, bc);
                    icon(g, pat ? 5 : need[i], cx, 42);
                    float f = Math.max(0f, timer[i] / (float) maxT[i]);
                    JobsUi.bar(g, cx - 24, 100, 48, 4, f, f > 0.35f ? GREEN : RED, 0xFF3A2F5A);
                }
            }
            if (runnerPet >= 0) {                                    // catch it!
                int cx = runnerX;
                JobsGfx.shadow(g, cx, 121, 16);
                JobsGfx.orb(g, cx, 112, 8, pcol[runnerPet]);
                Skin.rect(g, cx - 3, 110, 2, 2, 0xFF3A2A3A);
                Skin.rect(g, cx + 2, 110, 2, 2, 0xFF3A2A3A);
                ctxt(g, "!", cx, 96, RED);
            }
            for (int j = 0; j < 5; j++) {
                int x = 12 + j * 57;
                boolean hov = in(mx, my, x, TRAY_Y, 52, 28);
                if (j == held) JobsGfx.halo(g, x, TRAY_Y, 52, 28, 6, WHITE, 0x50);
                JobsGfx.puffy(g, x, TRAY_Y, 52, 28, 6, hov ? 0xFF4A3A70 : 0xFF3A2F5A);
                JobsGfx.puffy(g, x + 2, TRAY_Y + 2, 48, 4, 2, ncol[j]);
                icon(g, j, x + 26, TRAY_Y + 16);
                txt(g, Integer.toString(j + 1), x + 4, TRAY_Y + 18, MUTED);
            }
            if (combo >= 3) txt(g, t("cutemod.job.combo", combo), 6, 22, YELLOW);
        }

        @Override float quality() { return Math.max(0f, points - miss * 0.6f - wrong * 0.4f) / 38f; }
        @Override String status() { return t("cutemod.job.cared", served); }
    }

    // ---------- programmer: the odd symbol (easy pairs first), and every 4th round the line with the bug ----------
    private final class Coder extends Shift {
        private static final String[][] EASY = {{"#", "@"}, {"+", "x"}, {"<", ">"}, {"$", "%"}, {"&", "?"}, {"A", "V"}, {"T", "L"}, {"*", "#"}};
        private static final String[][] MEDIUM = {{"E", "F"}, {"P", "R"}, {"O", "Q"}, {"K", "X"}, {"3", "8"}, {"B", "D"}};
        private static final String[][] HARD = {{"0", "O"}, {"5", "S"}, {"8", "B"}};
        /** {right line, line with a bug} */
        private static final String[][] CODE = {
                {"if (x == 5) {", "if (x = 5) {"}, {"for (i = 0; i < 9; i++)", "for (i = 0; i < 9; i--)"},
                {"print(\"hello\");", "print(\"hello\";"}, {"while (true) {", "whle (true) {"},
                {"int n = 3;", "int n = 3"}, {"return a + b;", "retrun a + b;"},
                {"x = list[0];", "x = list[0]];"}, {"} else {", "} esle {"},
                {"name = \"Anna\";", "name = \"Anna;"}, {"if (a > b) {", "if (a > b) }"},
                {"sum += i;", "sum =+ i;"}, {"function go() {", "fucntion go() {"},
        };
        private static final int GX = 10, GY = 38, GW = W - 20, LINE_Y = 40, LINE_H = 21;
        private int cols, rows, oddX, oddY, ok, miss, late, timer, maxTimer, flash, round, badLine;
        private String base, odd;
        private boolean codeRound;
        private final String[] lines = new String[5];

        Coder() { newGrid(); }

        @Override int duration() { return 4500; }

        /** Every find makes the grid bigger and the time shorter; look-alike symbols only come later. */
        private void newGrid() {
            round++;
            codeRound = round % 4 == 0 && ok >= 2;
            if (codeRound) {
                java.util.List<Integer> idx = new ArrayList<>();
                for (int i = 0; i < CODE.length; i++) idx.add(i);
                java.util.Collections.shuffle(idx, rnd);
                badLine = rnd.nextInt(5);
                for (int i = 0; i < 5; i++) lines[i] = CODE[idx.get(i)][i == badLine ? 1 : 0];
                maxTimer = Math.max(260, 440 - ok * 8);
                timer = maxTimer;
                return;
            }
            cols = Math.min(9, 4 + ok / 3);
            rows = Math.min(6, 3 + ok / 4);
            List<String[]> pool = new ArrayList<>(List.of(EASY));
            if (ok >= 6) pool.addAll(List.of(MEDIUM));
            if (ok >= 14) pool.addAll(List.of(HARD));
            String[] p = pool.get(rnd.nextInt(pool.size()));
            boolean swap = rnd.nextBoolean();
            base = swap ? p[0] : p[1];
            odd = swap ? p[1] : p[0];
            oddX = rnd.nextInt(cols);
            oddY = rnd.nextInt(rows);
            maxTimer = Math.max(170, 360 - ok * 10);
            timer = maxTimer;
        }

        private int cw() { return GW / cols; }
        private int ch() { return Math.min(24, 118 / rows); }

        @Override void tick() {
            if (flash > 0) flash--; else if (flash < 0) flash++;
            if (--timer <= 0) { late++; flash = -10; sfx("bad", 0.8F, 0.6F); fx.shake(6, 2f); newGrid(); }
        }

        @Override boolean click(int x, int y) {
            if (codeRound) {
                int i = (y - LINE_Y) / LINE_H;
                if (y < LINE_Y || i >= 5 || x < GX || x >= GX + GW) return true;
                if (i == badLine) {
                    ok++;
                    flash = 8;
                    sfx("great", 1F, 0.6F);
                    fx.burst(W / 2, LINE_Y + i * LINE_H + 10, GREEN, 12);
                    fx.pop(W / 2, LINE_Y + i * LINE_H - 2, "+1", GREEN);
                    newGrid();
                } else {
                    miss++;
                    flash = -8;
                    sfx("bad");
                    fx.shake(4, 1.5f);
                    fx.burst(x, y, RED, 5);
                }
                return true;
            }
            int cx = (x - GX) / cw(), cy = (y - GY) / ch();
            if (x < GX || y < GY || cx >= cols || cy >= rows) return true;
            if (cx == oddX && cy == oddY) {
                int fxX = GX + cx * cw() + cw() / 2, fxY = GY + cy * ch() + ch() / 2;
                ok++;
                flash = 8;
                sfx("good", 1F + Math.min(ok, 12) * 0.02F, 0.7F);
                fx.burst(fxX, fxY, GREEN, 9);
                fx.pop(fxX, fxY - 8, "+1", GREEN);
                newGrid();
            } else {
                miss++;
                flash = -8;
                sfx("bad");
                fx.shake(4, 1.5f);
                fx.burst(x, y, RED, 5);
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            JobsGfx.sky(g, 0xFF171B33, 0xFF0F1226);
            JobsGfx.stars(g, shiftTick, 16, 2, 0xFF5BD97A);                       // faint green dots, like a terminal at night
            float f = Math.max(0f, timer / (float) maxTimer);
            JobsUi.bar(g, GX, 21, GW, 4, Math.min(1f, f), f > 0.35f ? GREEN : RED, 0xFF3A2F5A);
            ctxt(g, t(codeRound ? "cutemod.job.code_bug" : "cutemod.job.code_odd"), W / 2, 27, YELLOW);
            int back = flash > 0 ? 0xFF2A4A3A : flash < 0 ? 0xFF4A2A3A : 0xFF1E1836;
            int rim = flash > 0 ? GREEN : flash < 0 ? RED : 0xFF3B3063;
            if (codeRound) {
                JobsUi.card(g, GX - 3, LINE_Y - 3, GW + 6, 5 * LINE_H + 3, 6, back, rim);
                for (int i = 0; i < 5; i++) {
                    int y = LINE_Y + i * LINE_H;
                    App.roundRect(g, GX, y, GW, LINE_H - 2, 4, in(mx, my, GX, y, GW, LINE_H - 2) ? HOVER : 0xFF2A2145);
                    txt(g, Integer.toString(i + 1), GX + 6, y + 6, MUTED);
                    Skin.rect(g, GX + 20, y + 3, 1, LINE_H - 8, 0xFF3A2F5A);
                    txt(g, lines[i], GX + 24, y + 6, 0xFFD8D0EE);
                }
                return;
            }
            JobsUi.card(g, GX - 3, GY - 3, cols * cw() + 6, rows * ch() + 6, 6, back, rim);
            float sc = ch() >= 22 ? 2f : 1.5f;                       // big letters while the table is small
            for (int cy = 0; cy < rows; cy++) {
                for (int cx = 0; cx < cols; cx++) {
                    int x = GX + cx * cw(), y = GY + cy * ch();
                    if (in(mx, my, x, y, cw(), ch())) App.roundRect(g, x + 1, y + 1, cw() - 2, ch() - 2, 4, HOVER);
                    boolean isOdd = cx == oddX && cy == oddY;
                    int col = isOdd && ok < 4 ? 0xFFFFE9A0 : 0xFFD8D0EE;      // the first finds are helped by a warmer colour
                    big(g, isOdd ? odd : base, x + cw() / 2, y + Math.round((ch() - 8 * sc) / 2f), col, sc);
                }
            }
        }

        @Override float quality() { return Math.max(0f, ok - miss * 0.5f - late * 0.5f) / 20f; }
        @Override String status() { return t("cutemod.job.bugs", ok); }
    }

    // ---------- DJ: a rhythm game: notes fall into four lanes, hit them on the line, keep the crowd happy ----------
    private final class Dj extends Shift {
        private static final int LANE_W = 66, LANE_X0 = 6, LANE_STEP = 72, NOTE_TOP = 34, HIT_Y = 112, PAD_Y = 118, PAD_H = 28;
        private static final float SPEED = 1.05f;                        // pixels per tick: a note falls for about 1.2 seconds
        private final int[] cols = {RED, 0xFF2F7FD6, 0xFF5BBF6A, 0xFFF3D46A};
        private final List<float[]> notes = new ArrayList<>();           // {lane, y, golden 0/1}
        private final List<int[]> pops = new ArrayList<>();              // {lane, ticks left, 0 miss / 1 good / 2 perfect}
        private final List<Integer> queue = new ArrayList<>();           // lanes of a run that are still to come
        private final int[] padT = new int[4];
        private int age, stepT, step, lastLane = -1, combo, bestCombo, energy = 60, dropT, perfect, good, miss, judged, flash;
        private float points;

        @Override int duration() { return 5400; }

        @Override boolean over() { return energy <= 0; }              // the crowd went home

        private int level() { return Math.min(3, age / 1350); }

        private int pickLane() {
            int l;
            do { l = rnd.nextInt(4); } while (l == lastLane && rnd.nextInt(3) != 0);
            lastLane = l;
            return l;
        }

        private void addNote(int lane) { notes.add(new float[]{lane, NOTE_TOP, dropT > 0 ? 1 : 0}); }

        /** The song: 120 bpm, a step every eighth note. The later it gets the more notes, doubles and runs. */
        private void spawnStep() {
            int s = step++ % 8, d = level();
            if (!queue.isEmpty()) { addNote(queue.remove(0)); return; }
            if (d >= 2 && s == 6 && rnd.nextDouble() < (d == 2 ? 0.5 : 0.6)) {   // two notes at the same time
                int a = pickLane(), b;
                do { b = rnd.nextInt(4); } while (b == a);
                addNote(a);
                addNote(b);
                return;
            }
            if (d >= 3 && s == 0 && rnd.nextDouble() < 0.25) {                    // a run of four
                int l = rnd.nextInt(4), dir = l < 2 ? 1 : -1;
                addNote(l);
                for (int k = 1; k < 4; k++) queue.add(Math.floorMod(l + dir * k, 4));
                return;
            }
            double[] quarter = {0.80, 0.90, 0.92, 1.0}, eighth = {0, 0.25, 0.45, 0.7};
            if (rnd.nextDouble() < (s % 2 == 0 ? quarter[d] : eighth[d])) addNote(pickLane());
        }

        private void crowd(int delta) {
            energy = Math.max(0, Math.min(100, energy + delta));
            if (energy >= 100 && dropT == 0) { dropT = 360; flash = 12; sfx("drop", 1F, 0.8F); fx.confetti(W / 2, 62, 24); fx.shake(10, 2.5f); }   // the drop: golden notes, double points
        }

        private void judge(int lane, int kind, boolean golden) {
            judged++;
            pops.add(new int[]{lane, 40, kind});
            int fxX = LANE_X0 + lane * LANE_STEP + LANE_W / 2;
            if (kind == 0) {
                miss++;
                combo = 0;
                crowd(-6);
                fx.burst(fxX, HIT_Y + 8, RED, 4);
                fx.shake(4, 1.5f);
                sfx("scratch", 1F, 0.45F);                                // the note got past: a record scratch
                return;
            }
            if (kind == 2) { perfect++; sfx("star", 1F, 0.35F); } else good++;     // a perfect hit has a little sparkle on top of the pad
            if (golden || dropT > 0) sfx("great", 1.2F, 0.3F);            // golden notes and the drop shine more
            combo++;
            bestCombo = Math.max(bestCombo, combo);
            fx.burst(fxX, HIT_Y, golden || dropT > 0 ? YELLOW : cols[lane], kind == 2 ? 10 : 5);
            if (combo % 10 == 0) fx.confetti(W / 2, 70, 12);
            float v = (kind == 2 ? 1f : 0.6f) * (1f + Math.min(combo, 40) / 40f * 0.5f) * (golden || dropT > 0 ? 2f : 1f);
            points += v;
            if (dropT == 0) crowd(kind == 2 ? 3 : 1);
        }

        @Override void tick() {
            age++;
            if (flash > 0) flash--;
            for (int i = 0; i < 4; i++) if (padT[i] > 0) padT[i]--;
            pops.removeIf(p -> --p[1] <= 0);
            if (dropT > 0 && --dropT == 0) energy = 60;
            if (++stepT >= 15) { stepT = 0; spawnStep(); }
            for (java.util.Iterator<float[]> it = notes.iterator(); it.hasNext();) {
                float[] n = it.next();
                n[1] += SPEED;
                if (n[1] > HIT_Y + 18) { it.remove(); judge((int) n[0], 0, false); }   // it got past the line
            }
        }

        private void press(int lane) {
            padT[lane] = 8;
            sfx("dj" + lane, 1F, 0.8F);                                   // every pad is a note of the tune
            float[] best = null;
            float bd = 99f;
            for (float[] n : notes) {
                if ((int) n[0] != lane) continue;
                float d = Math.abs(n[1] - HIT_Y);
                if (d < bd) { bd = d; best = n; }
            }
            if (best == null || bd > 18f) { crowd(-2); return; }          // a press with no note: the crowd frowns, the combo stays
            notes.remove(best);
            judge(lane, bd <= 7f ? 2 : 1, best[2] == 1);
        }

        @Override boolean click(int x, int y) {
            for (int i = 0; i < 4; i++) if (in(x, y, LANE_X0 + i * LANE_STEP, NOTE_TOP, LANE_W, PAD_Y + PAD_H - NOTE_TOP)) { press(i); return true; }
            return true;
        }

        @Override boolean key(int k) {
            int lane = k >= 49 && k <= 52 ? k - 49 : k == 68 ? 0 : k == 70 ? 1 : k == 74 ? 2 : k == 75 ? 3 : -1;   // 1-4 or D F J K
            if (lane < 0) return false;
            press(lane);
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            boolean drop = dropT > 0;
            float beat = 1f - (age % 30) / 30f;
            JobsGfx.sky(g, drop && (age / 6) % 2 == 0 ? 0xFF3A1A58 : 0xFF1C1040, 0xFF0C0818);
            // stage lights that pulse with the beat
            JobsGfx.glow(g, 36, 22, 30, cols[(age / 30) % 4], drop ? 0x10 : 0x08 + Math.round(beat * 4));
            JobsGfx.glow(g, W - 36, 22, 30, cols[(age / 30 + 2) % 4], drop ? 0x10 : 0x08 + Math.round(beat * 4));
            for (int i = 0; i < 20; i++) {                                 // the equalizer pulses with the beat
                int h = 2 + Math.round(9f * (0.5f + 0.5f * (float) Math.sin(age * 0.17 + i * 0.8)) * (0.55f + 0.45f * beat));
                App.roundRect(g, 8 + i * 14, 31 - h, 10, h, 3, mix(cols[i % 4] & 0xFFFFFF, 0x140C28, 0.35f));
            }
            for (int i = 0; i < 4; i++) {
                int x = LANE_X0 + i * LANE_STEP;
                Skin.grad(g, x, NOTE_TOP, x + LANE_W, HIT_Y + 16, mix(cols[i] & 0xFFFFFF, 0x140C28, 0.93f), mix(cols[i] & 0xFFFFFF, 0x140C28, 0.8f));
                Skin.rect(g, x, NOTE_TOP, 1, HIT_Y - NOTE_TOP + 16, 0x22FFFFFF);
                Skin.rect(g, x + LANE_W - 1, NOTE_TOP, 1, HIT_Y - NOTE_TOP + 16, 0x22FFFFFF);
            }
            for (int k = 1; k <= 3; k++) Skin.rect(g, 0, HIT_Y - k * 2, W, 2, 0x08FFFFFF);       // a soft light over the line
            Skin.rect(g, 0, HIT_Y, W, 2, 0x99FFFFFF);
            if (combo >= 2) ctxt(g, t("cutemod.job.dj_combo", combo), W / 2, 62, combo >= 10 ? YELLOW : 0xFFD8D0EE);
            if (drop) ctxt(g, t("cutemod.job.dj_drop"), W / 2, 76, (age / 4) % 2 == 0 ? YELLOW : WHITE);
            for (float[] n : notes) {
                int lane = (int) n[0], x = LANE_X0 + lane * LANE_STEP, y = Math.round(n[1]);
                boolean gold = n[2] == 1;
                if (gold) JobsGfx.glow(g, x + LANE_W / 2, y, 22, YELLOW, 0x0C);
                JobsGfx.puffy(g, x + 4, y - 5, LANE_W - 8, 10, 4, gold ? YELLOW : cols[lane]);
            }
            for (int[] p : pops) {
                int x = LANE_X0 + p[0] * LANE_STEP + LANE_W / 2, y = HIT_Y - 18 - (40 - p[1]) / 3;
                String s = t(p[2] == 2 ? "cutemod.job.dj_perfect" : p[2] == 1 ? "cutemod.job.dj_good" : "cutemod.job.dj_miss");
                ctxt(g, s, x, Math.max(NOTE_TOP, y), p[2] == 2 ? YELLOW : p[2] == 1 ? GREEN : RED);
            }
            for (int i = 0; i < 4; i++) {
                int x = LANE_X0 + i * LANE_STEP;
                boolean on = padT[i] > 0, hov = in(mx, my, x, PAD_Y, LANE_W, PAD_H);
                int c = on ? mix(cols[i] & 0xFFFFFF, 0xFFFFFF, 0.55f) : hov ? mix(cols[i] & 0xFFFFFF, 0xFFFFFF, 0.2f) : mix(cols[i] & 0xFFFFFF, 0x000000, 0.35f);
                if (on) JobsGfx.halo(g, x, PAD_Y, LANE_W, PAD_H, 7, cols[i], 0x60);
                JobsGfx.puffy(g, x, PAD_Y, LANE_W, PAD_H, 7, c);
                ctxt(g, Integer.toString(i + 1), x + LANE_W / 2, PAD_Y + 10, on ? 0xFF1B1530 : 0xFFD8D0EE);
            }
            if (flash > 0) JobsGfx.rect(g, 0, BAR, W, 2, GREEN);
            JobsUi.bar(g, 6, 152, W - 12, 6, energy / 100f, energy > 50 ? GREEN : energy > 25 ? YELLOW : RED, 0xFF3A2F5A);       // the mood of the crowd
        }

        @Override float quality() { return Math.max(0f, perfect + good * 0.6f - miss * 0.4f) / Math.max(100, judged); }
        @Override String status() { return t("cutemod.job.dj_stat", combo, Math.round(points)); }
    }

    // ---------- pilot: gap walls, moving gaps, rock fields, star trails with rings, shields and slow-motion ----------
    private final class Pilot extends Shift {
        private static final int TOP = 22, BOT = H - 2, SX = 44, WALL_W = 14;
        private static final int WALL = 0, ROCK = 2, STAR = 3, RING = 4, POWER = 5;   // a moving-gap wall is a WALL with an amplitude
        private static final class Obj {
            final int type; float x, y, a, b, c; int state;
            Obj(int type, float x, float y) { this.type = type; this.x = x; this.y = y; }
        }
        private final List<Obj> objs = new ArrayList<>();
        private float shipY = (TOP + BOT) / 2f, targetY = shipY, lastCenter = (TOP + BOT) / 2f, cursor = 60f, score;
        private int segs, lives = 3, hits, stun, slowT, flash, stars, rings, passed;
        private boolean shield;

        @Override int duration() { return 5400; }

        @Override boolean over() { return lives <= 0; }

        void mouse(int x, int y) { targetY = Math.max(TOP + 6, Math.min(BOT - 6, y)); }

        private float clampCenter(float c, float h) { return Math.max(TOP + h / 2 + 4, Math.min(BOT - h / 2 - 4, c)); }

        private float gapTop(Obj o) { return o.y + o.a * (float) Math.sin(o.c) - o.b / 2; }

        private void spawnSegment() {
            segs++;
            float x = W + 10, r = rnd.nextFloat();
            if (segs >= 5 && r < 0.18f) {                                  // a gap that moves up and down
                Obj o = new Obj(WALL, x, 0);
                o.b = Math.max(50f, 60f - segs * 0.2f);
                o.a = 18f;
                o.c = rnd.nextFloat() * 6f;
                o.y = clampCenter(lastCenter + (rnd.nextFloat() - 0.5f) * 80f, o.b + 2 * o.a);
                lastCenter = o.y;
                objs.add(o);
                cursor = 125f;
            } else if (segs >= 3 && r < 0.38f) {                           // three rocks in different bands
                List<Integer> bands = new ArrayList<>(List.of(0, 1, 2, 3, 4));
                java.util.Collections.shuffle(bands, rnd);
                float band = (BOT - TOP - 16f) / 5f;
                for (int k = 0; k < 3; k++) {
                    Obj o = new Obj(ROCK, x + k * 46f, TOP + 8 + band * (bands.get(k) + 0.5f));
                    o.a = 8 + rnd.nextInt(3);
                    o.b = (rnd.nextFloat() - 0.5f) * 0.6f;                  // it drifts up or down
                    objs.add(o);
                }
                cursor = 150f;
            } else if (r < 0.52f) {                                        // a trail of stars, sometimes ending in a ring
                float c = clampCenter(lastCenter, 60f), ph = rnd.nextFloat() * 6f;
                for (int k = 0; k < 6; k++) objs.add(new Obj(STAR, x + k * 18f, clampCenter(c + 20f * (float) Math.sin(ph + k * 0.9f), 24f)));
                if (rnd.nextInt(4) == 0) {
                    Obj ring = new Obj(RING, x + 6 * 18f + 30f, clampCenter(c + 20f * (float) Math.sin(ph + 6 * 0.9f), 34f));
                    ring.a = 15f;
                    objs.add(ring);
                }
                cursor = 150f;
            } else if (segs >= 4 && r < 0.58f && (!shield || rnd.nextInt(3) == 0)) {   // a shield or a slow-motion clock
                Obj o = new Obj(POWER, x, TOP + 16 + rnd.nextFloat() * (BOT - TOP - 32));
                o.b = shield ? 1 : rnd.nextInt(2);
                objs.add(o);
                cursor = 90f;
            } else {                                                       // a wall with a gap
                Obj o = new Obj(WALL, x, 0);
                o.b = Math.max(46f, 60f - segs * 0.25f);
                o.y = clampCenter(lastCenter + (rnd.nextFloat() - 0.5f) * 120f, o.b);
                lastCenter = o.y;
                objs.add(o);
                cursor = 108f;
            }
        }

        private void hurt() {
            if (shield) { shield = false; stun = 40; flash = 10; sfx("bump"); fx.burst(SX, shipY, 0xFF38BDF8, 12); fx.shake(6, 2f); return; }
            sfx("hurt");
            fx.shake(12, 3.5f);
            fx.burst(SX, shipY, RED, 12);
            lives--;
            hits++;
            stun = 90;
            flash = -12;
        }

        @Override void tick() {
            if (stun > 0) stun--;
            if (slowT > 0) slowT--;
            if (flash > 0) flash--; else if (flash < 0) flash++;
            float mul = slowT > 0 ? 0.6f : 1f;
            float v = Math.min(2.8f, 1.7f + segs * 0.014f) * mul;         // faster the longer you fly
            shipY += Math.max(-3.0f, Math.min(3.0f, targetY - shipY));      // the ship follows the mouse, but not instantly
            cursor -= v;
            if (cursor <= 0) spawnSegment();
            for (Obj o : objs) {
                o.x -= v;
                switch (o.type) {
                    case WALL -> {
                        o.c += 0.045f * mul;
                        float top = gapTop(o);
                        boolean overlap = SX + 8 > o.x && SX - 8 < o.x + WALL_W;
                        if (overlap && stun == 0 && (shipY - 4 < top || shipY + 4 > top + o.b)) { hurt(); o.state = 2; }
                        if (o.state == 0 && o.x + WALL_W < SX - 8) { o.state = 1; passed++; score += o.a > 0 ? 1.5f : 1f; }
                    }
                    case ROCK -> {
                        o.y += o.b * mul;
                        if (o.y < TOP + o.a || o.y > BOT - o.a) o.b = -o.b;
                        if (stun == 0 && o.state == 0 && Math.hypot(SX - o.x, shipY - o.y) < o.a + 4) { hurt(); o.state = 2; }
                        if (o.state == 0 && o.x < SX - 14) { o.state = 1; score += 0.4f; }
                    }
                    case STAR -> {
                        if (o.state == 0 && Math.abs(o.x - SX) < 10 && Math.abs(o.y - shipY) < 10) { o.state = 1; stars++; score += 0.5f; sfx("star", 0.9F + (stars % 6) * 0.06F, 0.5F); fx.burst(o.x, o.y, YELLOW, 6); }
                    }
                    case RING -> {
                        if (o.state == 0 && o.x < SX) {
                            o.state = 3;
                            if (Math.abs(shipY - o.y) < o.a - 2) { rings++; score += 3f; flash = 10; o.state = 1; sfx("ring"); fx.burst(SX, shipY, 0xFF38BDF8, 14); fx.pop(SX + 12, shipY - 10, "+3", 0xFF38BDF8); }
                        }
                    }
                    default -> {
                        if (o.state == 0 && Math.abs(o.x - SX) < 11 && Math.abs(o.y - shipY) < 11) {
                            o.state = 1;
                            sfx("power");
                            fx.burst(SX, shipY, o.b == 0 ? 0xFF38BDF8 : 0xFFB57BD6, 10);
                            if (o.b == 0) shield = true; else slowT = 300;
                        }
                    }
                }
            }
            objs.removeIf(o -> o.x < -40 || (o.state == 1 && (o.type == STAR || o.type == POWER || o.type == RING)));
        }

        // drawing that never leaves the screen
        private void box(GuiGraphics g, int x, int y, int w, int h, int c) {
            int x0 = Math.max(0, x), x1 = Math.min(W, x + w), y0 = Math.max(BAR, y), y1 = Math.min(H, y + h);
            if (x1 > x0 && y1 > y0) Skin.rect(g, x0, y0, x1 - x0, y1 - y0, c);
        }

        private void ball(GuiGraphics g, int cx, int cy, int r, int c) {
            for (int dy = -r; dy <= r; dy++) {
                int w = (int) Math.sqrt((double) r * r - (double) dy * dy);
                box(g, cx - w, cy + dy, 2 * w + 1, 1, c);
            }
        }

        /** An outline circle, two dots thick (a ring to fly through, the shield). */
        private void ring(GuiGraphics g, int cx, int cy, int r, int c) {
            for (int k = 0; k < 48; k++) {
                double an = k * Math.PI / 24.0;
                JobsGfx.rect(g, cx + (int) Math.round(Math.cos(an) * r) - 1, cy + (int) Math.round(Math.sin(an) * r) - 1, 2, 2, c);
                JobsGfx.rect(g, cx + (int) Math.round(Math.cos(an) * (r - 2)) - 1, cy + (int) Math.round(Math.sin(an) * (r - 2)) - 1, 2, 2, c);
            }
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            JobsGfx.sky(g, 0xFF0B1432, 0xFF21184A);
            JobsGfx.glow(g, 236, 96, 52, 0xFF6A5AA8, 0x06);                          // a far nebula
            JobsGfx.stars(g, shiftTick * 3, 26, 3, 0xFFFFFFFF);                         // three layers, the near ones are faster
            for (Obj o : objs) {
                int x = Math.round(o.x), y = Math.round(o.y);
                switch (o.type) {
                    case WALL -> {
                        int top = Math.round(gapTop(o)), gh = Math.round(o.b);
                        boolean mv = o.a > 0;
                        int col = mv ? 0xFF8A5AA8 : 0xFF6A5AA8, cap = mv ? 0xFFC88AE0 : 0xFF8A7AC8;
                        if (top > BAR) Skin.grad(g, x, BAR, x + WALL_W, top, JobsGfx.shade(col, 0.35f), col);
                        if (top + gh < H) Skin.grad(g, x, top + gh, x + WALL_W, H, col, JobsGfx.shade(col, 0.35f));
                        box(g, x, BAR, 2, top - BAR, JobsGfx.light(col, 0.25f));                  // the lit edge
                        box(g, x, top + gh, 2, H - top - gh, JobsGfx.light(col, 0.25f));
                        JobsGfx.puffy(g, x - 2, top - 5, WALL_W + 4, 5, 2, cap);
                        JobsGfx.puffy(g, x - 2, top + gh, WALL_W + 4, 5, 2, cap);
                    }
                    case ROCK -> {
                        int ra = (int) o.a;
                        JobsGfx.orb(g, x, y, ra, 0xFF8A7A9A);
                        JobsGfx.disc(g, x + ra / 3, y + ra / 4, Math.max(1, ra / 4), 0xFF6A5A7A);   // a crater
                    }
                    case STAR -> {
                        JobsGfx.glow(g, x, y, 8, YELLOW, 0x10);
                        JobsGfx.sparkle(g, x, y, 4, YELLOW, 1f);
                    }
                    case RING -> {
                        int ra = (int) o.a;
                        if (o.state != 3) JobsGfx.glow(g, x, y, ra + 4, 0xFF38BDF8, 0x07);
                        ring(g, x, y, ra, o.state == 3 ? 0xFF5A5A7A : 0xFF38BDF8);
                    }
                    default -> {
                        JobsGfx.glow(g, x, y, 11, o.b == 0 ? 0xFF38BDF8 : 0xFFB57BD6, 0x0C);
                        JobsGfx.orb(g, x, y, 7, o.b == 0 ? 0xFF38BDF8 : 0xFFB57BD6);
                        if (o.b == 0) box(g, x - 1, y - 4, 2, 8, WHITE);
                        else { box(g, x, y - 4, 1, 5, WHITE); box(g, x, y, 4, 1, WHITE); }
                    }
                }
            }
            int sy = Math.round(shipY);
            if (!(stun > 0 && (stun / 5) % 2 == 0)) {
                for (int k = 1; k <= 6; k++) {                                   // a fading trail
                    int ty = sy + Math.round((float) Math.sin((shiftTick - k * 2) / 5.0) * 1.5f);
                    JobsGfx.rect(g, SX - 12 - k * 5, ty - 1, 3, 2, JobsGfx.alpha(0xFFFFC832, 0x70 - k * 14));
                }
                JobsGfx.glow(g, SX - 13, sy, 7, 0xFFFFC832, 0x14);
                box(g, SX - 12, sy - 3 + (shiftTick / 4) % 2, 3, 2, 0xFFFFC832);
                JobsGfx.puffy(g, SX - 9, sy - 4, 16, 8, 3, 0xFFE8E8F8);
                App.roundRect(g, SX + 5, sy - 2, 5, 4, 2, 0xFFF58FB8);
                box(g, SX - 3, sy - 3, 5, 3, 0xFF38BDF8);
                box(g, SX - 6, sy + 3, 6, 2, 0xFFB0B0D8);
            }
            if (shield) {
                JobsGfx.glow(g, SX, sy, 15, 0xFF38BDF8, 0x10);
                ring(g, SX, sy, 13, 0xCC8EE0FF);
            }
            if (slowT > 0) box(g, 0, BAR, W, H - BAR, 0x1A38BDF8);
            if (flash != 0) box(g, 0, BAR, W, 2, flash > 0 ? GREEN : RED);
            JobsGfx.hearts(g, 6, BAR + 5, lives, 3);
        }

        @Override float quality() { return Math.max(0f, score - hits * 1.5f) / 100f; }
        @Override String status() { return t("cutemod.job.pilot_stat", Math.round(score)); }
    }

    // ---------- game tester ----------
    private final class Tester extends Shift {
        private static final int OX = (W - MiniGame.W) / 2, OY = 22;
        private final String gameId;
        private final MiniGame game;
        private int endDelay;

        Tester() {
            List<String> ids = installedGames();
            gameId = ids.get(rnd.nextInt(ids.size()));
            ComputerColor c = null;
            for (ComputerColor cc : ComputerColor.values()) if (cc.id.equals(gameId)) c = cc;
            game = c != null ? GameFactory.create(c) : GameFactory.createExtra(gameId);
            game.reset();
        }

        void mouse(int x, int y) { game.setMouse(x - OX, y - OY); }

        @Override int duration() { return 3600; }

        @Override void tick() {
            if (!game.over) game.tick();
            else {
                if (endDelay++ == 0) Sfx.gameOver(game.isWin(), GameMusic.dark(gameId));   // like in the game's own window
            }
        }

        @Override boolean over() { return game.over && endDelay > 90; }

        @Override void render(GuiGraphics g, int mx, int my) {
            Skin.rect(g, OX - 2, OY - 2, MiniGame.W + 4, MiniGame.H + 4, 0xFF3A2A4A);
            g.enableScissor(shell.absX() + OX, shell.absY() + OY, shell.absX() + OX + MiniGame.W, shell.absY() + OY + MiniGame.H);
            g.pose().pushPose();
            g.pose().translate(OX, OY, 0);
            game.render(g);
            g.pose().popPose();
            g.disableScissor();
        }

        @Override boolean click(int x, int y) {
            if (game.over) return true;
            int lx = x - OX, ly = y - OY;
            if (in(lx, ly, 0, 0, MiniGame.W, MiniGame.H)) game.click(lx, ly, 0);
            return true;
        }

        @Override boolean key(int k) { return !game.over && game.key(k); }

        @Override float quality() { return Progress.coinsFor(gameId, game.score) / 16f; }
        @Override String status() { return t("cutemod.job.testing", Library.name(gameId)) + "  " + game.score; }
    }
}
