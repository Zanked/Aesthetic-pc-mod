package dev.cutemod.client.game;

import dev.cutemod.net.DurakActionPayload;
import dev.cutemod.net.DurakSyncPayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** The client side of online Durak: what the server last told us, and the messages we send to it. */
public final class DurakNet {
    private DurakNet() {}

    /** Free players, the invitations, and the game we are in (opponent is empty if there is none). */
    public static List<String> players = new ArrayList<>();
    public static String invitedBy = "", invitedTo = "", opponent = "";
    public static boolean youAttack, myTurn;
    public static List<Integer> hand = new ArrayList<>(), atk = new ArrayList<>(), def = new ArrayList<>();
    public static int oppCount, deckCount, trumpCard, limit, result, event, seq;
    /** Goes up with every message from the server. */
    public static int version;
    private static int notice;
    private static long ignoreUntil;       // right after we left a game, an old message must not bring it back

    public static void apply(DurakSyncPayload p) {
        players = new ArrayList<>(p.players());
        invitedBy = p.invitedBy();
        invitedTo = p.invitedTo();
        opponent = System.currentTimeMillis() < ignoreUntil ? "" : p.opponent();
        youAttack = p.youAttack();
        myTurn = p.myTurn();
        hand = new ArrayList<>(p.hand());
        atk = new ArrayList<>(p.atk());
        def = new ArrayList<>(p.def());
        oppCount = p.oppCount();
        deckCount = p.deckCount();
        trumpCard = p.trumpCard();
        limit = p.limit();
        result = p.result();
        event = p.event();
        seq = p.seq();
        if (p.notice() != 0) notice = p.notice();
        version++;
    }

    public static void clear() {
        players = new ArrayList<>();
        invitedBy = invitedTo = opponent = "";
        result = 0;
        notice = 0;
        version++;
    }

    public static boolean inMatch() { return !opponent.isEmpty(); }

    /** The last notice (declined, busy, ...), only once. */
    public static int takeNotice() {
        int n = notice;
        notice = 0;
        return n;
    }

    private static void send(int action, String name, int card, int target) {
        dev.cutemod.client.os.Modem.send(new DurakActionPayload(action, name, card, target));
    }

    public static void request() { send(0, "", 0, 0); }

    public static void invite(String name) { send(1, name, 0, 0); }

    public static void accept(String name) { send(2, name, 0, 0); }

    public static void decline(String name) { send(3, name, 0, 0); }

    public static void cancelInvite() { send(9, "", 0, 0); }

    public static void attack(int card) { send(4, "", card, 0); }

    public static void defend(int card, int target) { send(5, "", card, target); }

    public static void take() { send(6, "", 0, 0); }

    public static void done() { send(7, "", 0, 0); }

    /** Give up, or leave a finished game. We forget the game at once, the server confirms later. */
    public static void leaveGame() {
        send(8, "", 0, 0);
        ignoreUntil = System.currentTimeMillis() + 1500;
        opponent = "";
        result = 0;
        version++;
    }
}
