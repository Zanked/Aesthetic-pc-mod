package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import dev.cutemod.client.os.CuteFont;
import dev.cutemod.data.BedwarsSim;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Bed Wars: a top-down mini version of the server game for four teams of one player. A round is played against 1-3 computer players, or
 * online in a room where people and computer players mix (the rules and the computer players are in {@link BedwarsSim}; the server is
 * {@link dev.cutemod.net.BedwarsServer}). Walk with the arrows or WASD, hit with Space (or a click), hold Shift (or Q) to build a bridge
 * over the void, E puts a wall, 1-4 buy at your shop. Break the other beds and be the last team that stands.
 * Every team is a little animal: a cat, a panda, a fox and a penguin, on the four islands.
 */
public class Bedwars extends MiniGame {
    private static final int MENU = 0, ROOMS = 1, ROOM = 2, PLAY = 3;
    private static final int CP = 8, VIEW_Y = 14, VIEW_H = 120;            // a cell is 8 px wide; the map is seen through a window between the cards and the bottom
    private int BX, BY;                                                  // where the corner of the map is on the screen: the camera moves it (it follows the player)
    private static final int COLS = BedwarsSim.COLS, ROWS = BedwarsSim.ROWS, N = BedwarsSim.N, CELL = BedwarsSim.CELL;
    private static final int[] MAIN = {0xFFF59BC1, 0xFFFFFFFF, 0xFFF5A04A, 0xFF6C9BF2};
    private static final int[] RIM = {0xFFFF6FA3, 0xFFB8B8D0, 0xFFE07B1F, 0xFF3F6FD6};
    private static final int[] RES = {0xFFD9DDE4, 0xFFFFD34D, 0xFF5CE8E8, 0xFF3FD16A};     // iron, gold, diamond, emerald
    private static final int[] SWORD = {0xFFC99A5E, 0xFFAAAAB5, 0xFFE8E8F0, 0xFF5CE8E8};
    private static final int INK = 0xFF2B2233;
    private static final int BG1 = 0xFF2B1F5A, BG2 = 0xFF120C2A;

    private int screen = MENU;
    private boolean online;
    private BedwarsSim sim = new BedwarsSim();
    private int bots = 3, skill = 1;
    private int anim, acc, overWait, noticeT, bannerT, prefDir = -1, sentDir = -2, sendT, atkPulse, wallPress, buyPress, seenState;
    private boolean sentAtk, sentBridge, havePrev;
    private String noticeKey = "", bannerKey = "";
    private final boolean[] heldNow = new boolean[4], heldBefore = new boolean[4], havePos = new boolean[4];
    private final float[] rx = new float[4], ry = new float[4];
    private final byte[] pTile = new byte[N];
    private final int[] pBed = new int[4], pRes = new int[4];
    private final boolean[] pAlive = new boolean[4];
    private int pBlocks;

    private static final class Pt {
        float x, y, vx, vy;
        int life, max, col, kind;
    }

    private final List<Pt> pts = new ArrayList<>();

    private static String m(String key) { return Component.translatable(key).getString(); }

    private static String tr(String key, Object... a) { return Component.translatable(key, a).getString(); }

    private BedwarsSim v() { return online ? BedwarsNet.view : sim; }

    private int me() { return online ? (BedwarsNet.stateSlot >= 0 ? BedwarsNet.stateSlot : BedwarsNet.mySlot) : 0; }

    // ---------------------------------------------------------------- flow
    @Override
    public void reset() {
        score = 0; over = false; overWait = 0; noticeT = 0; bannerT = 0; havePrev = false;
        pts.clear();
        screen = MENU;
        online = false;
        BedwarsNet.request();                                    // maybe we are still in a room: tick() brings us back to it
    }

    @Override
    public void close() {
        if (BedwarsNet.inRoom) BedwarsNet.leave();
    }

    @Override
    public String hintKey() { return "cutemod.hint.bedwars"; }

    @Override
    public Component status() {
        if (screen != PLAY) return Component.translatable("cutemod.ui.score", score);
        BedwarsSim s = v();
        int alive = 0, all = 0;
        for (BedwarsSim.Player p : s.pl) { if (p.active) all++; if (p.active && !p.out) alive++; }
        return Component.translatable("cutemod.bedwars.status", alive, all, s.scoreOf(me()));
    }

    @Override
    public boolean isWin() { return v().isWinner(me()); }

    @Override
    public Component endTitle() {
        BedwarsSim s = v();
        if (s.isWinner(me())) return Component.translatable("cutemod.bedwars.win");
        if (s.winner == BedwarsSim.DRAW) return Component.translatable("cutemod.bedwars.draw");
        if (s.winner >= 0) return Component.translatable("cutemod.bedwars.lose_to", nameOf(s.winner));
        return Component.translatable("cutemod.bedwars.lose");
    }

    private void startSolo() {
        sim = new BedwarsSim();
        sim.setup(0, false, skill);
        int[] order = {3, 1, 2};
        for (int i = 0; i < bots; i++) sim.setup(order[i], true, skill);
        sim.setMap(0);
        sim.start();
        online = false;
        beginRound();
    }

    private void startOnline() {
        online = true;
        beginRound();
        seenState = BedwarsNet.stateVersion - 1;
    }

    private void beginRound() {
        screen = PLAY;
        score = 0; over = false; overWait = 0; acc = 0;
        havePrev = false; bannerT = 0;
        prefDir = -1; sentDir = -2; sendT = 0; atkPulse = 0; wallPress = 0; buyPress = 0;
        pts.clear();
        java.util.Arrays.fill(havePos, false);
    }

    @Override
    public void tick() {
        anim++;
        if (noticeT > 0) noticeT--;
        if (bannerT > 0) bannerT--;
        netTick();
        if (screen == PLAY) playTick();
        stepParticles();
    }

    private void netTick() {
        int n = BedwarsNet.takeNotice();
        if (n != 0) { noticeKey = "cutemod.bedwars.notice." + n; noticeT = 220; }
        if ((screen == ROOMS || screen == ROOM) && anim % 100 == 0) BedwarsNet.request();
        if ((screen == MENU || screen == ROOMS) && BedwarsNet.inRoom && !BedwarsNet.inGame) { screen = ROOM; online = true; }
        if (screen == ROOM && !BedwarsNet.inRoom) screen = ROOMS;
        if (screen == ROOM && BedwarsNet.inGame && BedwarsNet.stateVersion != seenState && BedwarsNet.view.state != BedwarsSim.ST_OVER) startOnline();
        if (screen == PLAY && online && !BedwarsNet.inRoom) { screen = ROOMS; online = false; }
    }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    /** The direction the player holds: the newest key wins. 0 down, 1 left, 2 right, 3 up, -1 none. */
    private int readDir() {
        heldNow[0] = down(83) || down(KEY_DOWN);
        heldNow[1] = down(65) || down(KEY_LEFT);
        heldNow[2] = down(68) || down(KEY_RIGHT);
        heldNow[3] = down(87) || down(KEY_UP);
        for (int i = 0; i < 4; i++) if (heldNow[i] && !heldBefore[i]) prefDir = i;
        System.arraycopy(heldNow, 0, heldBefore, 0, 4);
        if (prefDir >= 0 && heldNow[prefDir]) return prefDir;
        prefDir = -1;
        for (int i = 0; i < 4; i++) if (heldNow[i]) return i;
        return -1;
    }

    private void playTick() {
        BedwarsSim s = v();
        int dir = readDir();
        boolean atk = down(KEY_SPACE) || atkPulse > 0;
        if (atkPulse > 0) atkPulse--;
        boolean bridge = down(340) || down(344) || down(81);               // Shift or Q
        if (online) {
            if (BedwarsNet.stateVersion != seenState) { seenState = BedwarsNet.stateVersion; onSnapshot(s); }
            if (dir != sentDir || atk != sentAtk || bridge != sentBridge || wallPress > 0 || buyPress > 0 || ++sendT >= 30) {
                BedwarsNet.input(dir, atk, bridge, wallPress > 0, buyPress);
                sentDir = dir; sentAtk = atk; sentBridge = bridge; wallPress = 0; buyPress = 0; sendT = 0;
            }
        } else if (++acc >= 3) {
            acc = 0;
            sim.input(0, dir, atk, bridge, wallPress > 0, buyPress);
            wallPress = 0; buyPress = 0;
            sim.tick();
            onSnapshot(s);
        }
        for (int i = 0; i < 4; i++) {
            BedwarsSim.Player p = s.pl[i];
            if (!havePos[i] || Math.abs(p.x - rx[i]) > 3 * CELL || Math.abs(p.y - ry[i]) > 3 * CELL) { rx[i] = p.x; ry[i] = p.y; havePos[i] = true; }
            else { rx[i] += (p.x - rx[i]) * 0.4F; ry[i] += (p.y - ry[i]) * 0.4F; }
        }
        if (s.state == BedwarsSim.ST_OVER && ++overWait >= 36 && !over) {
            over = true;
            score = s.scoreOf(me());
        }
    }

    // ---------------------------------------------------------------- what happened between two pictures: sounds and sparks
    private void banner(String key) { bannerKey = key; bannerT = 140; }

    private void onSnapshot(BedwarsSim s) {
        int me = me();
        if (havePrev) {
            BedwarsSim.Player mp = s.pl[me];
            for (int t = 0; t < 4; t++) {
                if (s.bedHp[t] < pBed[t]) {
                    int bc = BedwarsSim.bedCell(t);
                    if (s.bedHp[t] == 0 && !s.sudden) {
                        burst(bc, 1, 14);
                        sound(SoundEvents.GENERIC_EXPLODE, 0.7F, 1.0F);
                        if (t == me) { banner("cutemod.bedwars.bed_yours"); } else if (s.pl[t].active) banner("cutemod.bedwars.bed_gone");
                    } else {
                        burst(bc, 1, 3);
                        sound(SoundEvents.STONE_BUTTON_CLICK_ON, 0.6F, 0.5F);
                    }
                }
            }
            if (s.sudden && pBed[me] > 0 && s.bedHp[me] == 0) banner("cutemod.bedwars.sudden");
            for (int i = 0; i < N; i++) {
                byte a = pTile[i], b = s.tile[i];
                if (a == b) continue;
                if ((a == BedwarsSim.WALL_F || a == BedwarsSim.WALL_B || a == BedwarsSim.BRIDGE) && b < a) burst(i, 0, 5);
                if (b > a && s.owner[i] == me) sound(SoundEvents.STONE_BUTTON_CLICK_ON, 1.3F, 0.3F);
            }
            for (int i = 0; i < 4; i++) {
                BedwarsSim.Player p = s.pl[i];
                if (pAlive[i] && !p.alive) {
                    int c = Math.max(0, Math.min(N - 1, p.cell()));
                    burst(c, 2, 9);
                    ghost(p);
                    if (i == me) sound(SoundEvents.PLAYER_HURT, 0.7F, 1.0F); else pling(0.6F);
                }
                if (!pAlive[i] && p.alive) burst(BedwarsSim.spawnCell(i), 3, 8);
            }
            int gain = 0;
            for (int r = 0; r < 4; r++) if (mp.res(r) > pRes[r]) gain++;
            if (gain > 0) pling(1.7F);
            if (mp.blocks > pBlocks) pling(1.3F);
            if (mp.hp < pHpLast && mp.alive) sound(SoundEvents.PLAYER_HURT, 1.2F, 0.35F);
        }
        System.arraycopy(s.tile, 0, pTile, 0, N);
        for (int t = 0; t < 4; t++) { pBed[t] = s.bedHp[t]; pAlive[t] = s.pl[t].alive; }
        for (int r = 0; r < 4; r++) pRes[r] = s.pl[me].res(r);
        pBlocks = s.pl[me].blocks;
        pHpLast = s.pl[me].hp;
        havePrev = true;
    }

    private int pHpLast;

    private void burst(int cell, int kind, int n) {
        float cx = (cell % COLS) * CP + CP / 2F, cy = (cell / COLS) * CP + CP / 2F;
        int[] pink = {0xFFFF8FB8, 0xFFFFD1E3, 0xFFFFF2A8, 0xFFFFFFFF};
        for (int i = 0; i < n && pts.size() < 220; i++) {
            Pt p = new Pt();
            p.x = cx + (rnd.nextFloat() - 0.5F) * 5; p.y = cy + (rnd.nextFloat() - 0.5F) * 5;
            double a = rnd.nextFloat() * Math.PI * 2;
            float sp = 0.3F + rnd.nextFloat() * 0.9F;
            p.vx = (float) Math.cos(a) * sp; p.vy = (float) Math.sin(a) * sp - (kind == 0 ? 0.4F : 0);
            p.max = p.life = 16 + rnd.nextInt(16);
            p.kind = kind;
            p.col = switch (kind) {
                case 0 -> rnd.nextBoolean() ? 0xFFFFFFFF : 0xFFC9BEE8;
                case 1 -> pink[rnd.nextInt(4)];
                case 2 -> rnd.nextBoolean() ? 0xFFFFFFFF : 0xFFFFE27A;
                default -> 0xFFFFF27A;
            };
            pts.add(p);
        }
    }

    private void ghost(BedwarsSim.Player pl) {
        Pt p = new Pt();
        p.x = pl.x * CP / (float) CELL; p.y = pl.y * CP / (float) CELL;
        p.vx = 0; p.vy = -0.35F;
        p.max = p.life = 56;
        p.kind = 5;
        p.col = MAIN[pl.idx];
        pts.add(p);
    }

    private void stepParticles() {
        for (int i = pts.size() - 1; i >= 0; i--) {
            Pt p = pts.get(i);
            p.x += p.vx; p.y += p.vy;
            if (p.kind == 0 || p.kind == 1) p.vy += 0.05F;
            p.vx *= 0.97F;
            if (--p.life <= 0) pts.remove(i);
        }
    }

    // ---------------------------------------------------------------- input
    @Override
    public boolean key(int keyCode) {
        if (screen == PLAY) {
            if (keyCode == 69) { wallPress = 1; return true; }                                   // E: a wall
            if (keyCode >= 49 && keyCode <= 52) { buyPress = keyCode - 48; return true; }        // 1..4
            if (keyCode >= 321 && keyCode <= 324) { buyPress = keyCode - 320; return true; }     // the number pad
            return keyCode == KEY_SPACE || keyCode == 340 || keyCode == 344 || keyCode == 81
                    || keyCode == KEY_UP || keyCode == KEY_DOWN || keyCode == KEY_LEFT || keyCode == KEY_RIGHT
                    || keyCode == 87 || keyCode == 65 || keyCode == 83 || keyCode == 68;
        }
        if (screen == MENU && (keyCode == KEY_SPACE || keyCode == 257)) { startSolo(); pling(1.0F); return true; }
        return false;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (screen == PLAY) { atkPulse = 14; return true; }
        if (screen == MENU) return menuClick(x, y);
        if (screen == ROOMS) return roomsClick(x, y);
        if (screen == ROOM) return roomClick(x, y);
        return false;
    }

    private boolean menuClick(int x, int y) {
        if (in(x, y, 24, 43, 172, 14)) { startSolo(); pling(1.0F); return true; }
        if (in(x, y, 24, 59, 172, 14)) { screen = ROOMS; BedwarsNet.request(); pling(1.0F); return true; }
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 112 + i * 28, 76, 24, 12)) { bots = i + 1; beep(); return true; }
            if (in(x, y, 70 + i * 46, 89, 44, 12)) { skill = i; beep(); return true; }
        }
        return false;
    }

    private boolean roomsClick(int x, int y) {
        if (in(x, y, 4, 4, 30, 12)) { screen = MENU; pling(0.8F); return true; }
        if (in(x, y, 140, 3, 76, 14)) { BedwarsNet.create(); pling(1.2F); return true; }
        int rows = Math.min(BedwarsNet.hosts.size(), 5);
        for (int i = 0; i < rows; i++) {
            if (in(x, y, 8, 24 + i * 20, 204, 18)) { BedwarsNet.join(BedwarsNet.hosts.get(i)); pling(1.2F); return true; }
        }
        return false;
    }

    private boolean roomClick(int x, int y) {
        if (in(x, y, 4, 4, 38, 12)) { BedwarsNet.leave(); screen = ROOMS; pling(0.8F); return true; }
        if (!BedwarsNet.youHost) return false;
        for (int i = 1; i < 4; i++) {
            if (in(x, y, 8 + i * 53, 20, 49, 46)) { BedwarsNet.slot(i); beep(); return true; }
        }
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 70 + i * 46, 69, 44, 12)) { BedwarsNet.setLevel(i); beep(); return true; }
        }
        if (in(x, y, 40, 85, 140, 14)) { BedwarsNet.start(); pling(1.4F); return true; }
        return false;
    }

    // ---------------------------------------------------------------- drawing
    private String nameOf(int slot) {
        if (online) {
            int t = BedwarsNet.slotType[slot];
            String n = BedwarsNet.slotName[slot];
            if (t == 3 && !n.isEmpty()) return n;
        } else if (slot == 0) return m("cutemod.bedwars.you");
        return m("cutemod.bedwars.animal." + slot);
    }

    private static void stext(GuiGraphics g, String s, int x, int y, float k, int argb) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(k, k, 1F);
        CuteFont.draw(g, font(), s, 0, 0, argb, false);
        g.pose().popPose();
    }

    /** Centred text; a line that would not fit in the window is made smaller. */
    private static void sctext(GuiGraphics g, String s, int cx, int y, float k, int argb) {
        int w = Math.round(tw(s) * k);
        if (w > W - 8) k = k * (W - 8) / w;
        stext(g, s, cx - Math.round(tw(s) * k / 2F), y, k, argb);
    }

    private void bg(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, BG1, BG2);
        for (int i = 0; i < 18; i++) {
            int sx = (int) (Gfx.hash(i, 1) * W), sy = (int) (Gfx.hash(i, 2) * H);
            Gfx.sparkle(g, sx, sy, 2, anim + i * 17, 0xFFBFD0FF);
        }
        Gfx.vignette(g, W, H, 90);
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String label, int face) {
        boolean hover = in(mx, my, x, y, w, h);
        Gfx.bubble(g, x, y, w, h, 3, hover ? Gfx.lighter(face, 0.3F) : face);
        ctextW(g, label, x + w / 2, y + (h - 8) / 2, w - 6, 0xFF2B2140);
    }

    private void chip(GuiGraphics g, int x, int y, int w, int h, String label, boolean on, boolean enabled) {
        boolean hover = enabled && in(mx, my, x, y, w, h);
        int face = on ? 0xFFFFD866 : 0xFF6A5A92;
        Gfx.bubble(g, x, y, w, h, 3, hover ? Gfx.lighter(face, 0.25F) : face);
        ctextW(g, label, x + w / 2, y + (h - 8) / 2, w - 4, on ? 0xFF3A2A10 : 0xFFE8E0FF);
    }

    @Override
    public void render(GuiGraphics g) {
        bg(g);
        switch (screen) {
            case MENU -> renderMenu(g);
            case ROOMS -> renderRooms(g);
            case ROOM -> renderRoom(g);
            default -> renderPlay(g);
        }
        if (noticeT > 0) {
            int w = 170, x = (W - w) / 2, y = H - 18;
            Gfx.bubble(g, x, y, w, 14, 4, 0xFFFFE9A8);
            ctextW(g, m(noticeKey), W / 2, y + 3, w - 8, 0xFF3A2A10);
        }
    }

    private void renderMenu(GuiGraphics g) {
        sctext(g, m("cutemod.bedwars.title"), W / 2 + 1, 4, 2F, 0xFF1B1030);
        sctext(g, m("cutemod.bedwars.title"), W / 2, 3, 2F, 0xFFFFE27A);
        for (int i = 0; i < 4; i++) {
            int x = 34 + i * 40;
            animal(g, i, x, 19 + (anim / 14 + i) % 2, i == 0 ? 0 : i == 1 ? 2 : i == 2 ? 1 : 0, 0, 1.6F);
            bed(g, x + 20, 27, i, BedwarsSim.BED_HP);
        }
        button(g, 24, 43, 172, 14, m("cutemod.bedwars.vs_ai"), 0xFFF9C6DB);
        button(g, 24, 59, 172, 14, m("cutemod.bedwars.online"), 0xFFB8E8FF);
        stext(g, m("cutemod.bedwars.rivals"), 14, 78, 0.85F, 0xFFE8E0FF);
        for (int i = 0; i < 3; i++) chip(g, 112 + i * 28, 76, 24, 12, Integer.toString(i + 1), bots == i + 1, true);
        stext(g, m("cutemod.bedwars.skill"), 14, 91, 0.85F, 0xFFE8E0FF);
        for (int i = 0; i < 3; i++) chip(g, 70 + i * 46, 89, 44, 12, m("cutemod.bedwars.skill." + i), skill == i, true);
        sctext(g, m("cutemod.bedwars.keys1"), W / 2, 107, 0.7F, 0xFFC9BEE8);
        sctext(g, m("cutemod.bedwars.keys2"), W / 2, 117, 0.7F, 0xFFC9BEE8);
        sctext(g, m("cutemod.bedwars.keys3"), W / 2, 127, 0.7F, 0xFFC9BEE8);
    }

    private void renderRooms(GuiGraphics g) {
        button(g, 4, 4, 30, 12, "<", 0xFFE8E0FF);
        sctext(g, m("cutemod.bedwars.rooms"), 88, 6, 1F, 0xFFFFE27A);
        button(g, 140, 3, 76, 14, m("cutemod.bedwars.create"), 0xFFF9C6DB);
        int rows = Math.min(BedwarsNet.hosts.size(), 5);
        if (rows == 0) {
            ctextW(g, m("cutemod.bedwars.rooms.none"), W / 2, 62, W - 24, 0xFFC9BEE8);
            return;
        }
        for (int i = 0; i < rows; i++) {
            int y = 24 + i * 20;
            boolean hover = in(mx, my, 8, y, 204, 18);
            Gfx.bubble(g, 8, y, 204, 18, 4, hover ? 0xFF7B68AE : 0xFF5E4C8C);
            animal(g, i % 4, 12, y + 3, 0, 0, 1F);
            text(g, clip(BedwarsNet.hosts.get(i), 90), 28, y + 5, 0xFFFFFFFF);
            String free = tr("cutemod.bedwars.free", BedwarsNet.open.get(i));
            stext(g, free, 150 - Math.round(tw(free) * 0.8F), y + 6, 0.8F, 0xFFD6CBF2);
            Gfx.bubble(g, 156, y + 3, 50, 12, 3, 0xFFFFD866);
            ctextW(g, m("cutemod.bedwars.join"), 181, y + 5, 44, 0xFF3A2A10);
        }
    }

    private void renderRoom(GuiGraphics g) {
        button(g, 4, 4, 38, 12, m("cutemod.bedwars.leave"), 0xFFE8E0FF);
        String host = BedwarsNet.slotName[0].isEmpty() ? "" : BedwarsNet.slotName[0];
        sctext(g, tr("cutemod.bedwars.room", host), 130, 6, 0.95F, 0xFFFFE27A);
        for (int i = 0; i < 4; i++) {
            int x = 8 + i * 53, y = 20, t = BedwarsNet.slotType[i];
            boolean click = BedwarsNet.youHost && i > 0;
            boolean hover = click && in(mx, my, x, y, 49, 46);
            Gfx.bubble(g, x, y, 49, 46, 4, hover ? 0xFF7B68AE : 0xFF5E4C8C);
            g.fill(x + 3, y + 3, x + 46, y + 5, MAIN[i]);
            if (t == 1 || t == 2 || t == 3) {
                animal(g, i, x + 13, y + 8 + (anim / 16 + i) % 2, 0, 0, 2F);
                if (t == 1) g.fill(x + 6, y + 6, x + 43, y + 32, hover ? 0x907B68AE : 0x905E4C8C);        // an open place: a bot that a player can replace
            } else {
                Gfx.disc(g, x + 24, y + 20, 8, 0x30FFFFFF);
                ctextW(g, "-", x + 24, y + 16, 20, 0xFFC9BEE8);
            }
            String label = t == 3 ? BedwarsNet.slotName[i] : m("cutemod.bedwars.slot." + t);
            ctextW(g, label, x + 24, y + 34, 45, t == 3 ? 0xFFFFFFFF : 0xFFD6CBF2);
            if (i == 0) stext(g, "*", x + 41, y + 7, 1F, 0xFFFFE27A);
        }
        if (BedwarsNet.youHost) {
            stext(g, m("cutemod.bedwars.skill"), 14, 71, 0.85F, 0xFFE8E0FF);
            for (int i = 0; i < 3; i++) chip(g, 70 + i * 46, 69, 44, 12, m("cutemod.bedwars.skill." + i), BedwarsNet.level == i, true);
            button(g, 40, 85, 140, 14, m("cutemod.bedwars.start"), 0xFFB5F0C0);
            sctext(g, m("cutemod.bedwars.keys1"), W / 2, 108, 0.7F, 0xFFC9BEE8);
            sctext(g, m("cutemod.bedwars.keys2"), W / 2, 118, 0.7F, 0xFFC9BEE8);
            sctext(g, m("cutemod.bedwars.slot_hint"), W / 2, 130, 0.65F, 0xFFA99CCB);
        } else {
            sctext(g, m("cutemod.bedwars.wait"), W / 2, 76, 1F, 0xFFC9BEE8);
            sctext(g, tr("cutemod.bedwars.skill_is", m("cutemod.bedwars.skill." + BedwarsNet.level)), W / 2, 90, 0.85F, 0xFFC9BEE8);
            sctext(g, m("cutemod.bedwars.keys1"), W / 2, 108, 0.7F, 0xFFC9BEE8);
            sctext(g, m("cutemod.bedwars.keys2"), W / 2, 118, 0.7F, 0xFFC9BEE8);
        }
    }

    // ---------------------------------------------------------------- the round
    private static boolean isCenter(int x, int y) { return BedwarsSim.teamIsland(x, y) < 0; }          // the islands of nobody are made of stone

    private static int teamOfCell(int x, int y) { return Math.max(0, BedwarsSim.teamIsland(x, y)); }

    private void renderPlay(GuiGraphics g) {
        BedwarsSim s = v();
        int me = me();
        // the camera follows the player; it stops at the edges of the map
        int camPx = Math.round((havePos[me] ? rx[me] : s.pl[me].x) * CP / CELL), camPy = Math.round((havePos[me] ? ry[me] : s.pl[me].y) * CP / CELL);
        int camX = Math.max(0, Math.min(COLS * CP - W, camPx - W / 2));
        int camY = Math.max(0, Math.min(ROWS * CP - VIEW_H, camPy - VIEW_H / 2));
        BX = -camX;
        BY = VIEW_Y - camY;
        // the ground: first the cliffs under the tiles, then the tops
        for (int i = 0; i < N; i++) {
            if (s.tile[i] == BedwarsSim.VOID) continue;
            int x = i % COLS, y = i / COLS;
            boolean open = y == ROWS - 1 || s.tile[i + COLS] == BedwarsSim.VOID;
            if (!open) continue;
            int px = BX + x * CP, py = BY + y * CP;
            if (!seen(px, py)) continue;
            boolean br = s.tile[i] == BedwarsSim.BRIDGE || s.tile[i] == BedwarsSim.WALL_B;
            g.fill(px, py + CP, px + CP, py + CP + (br ? 1 : 3), br ? 0xFF3A2A4A : 0xFF6B5A4A);
            if (!br) g.fill(px, py + CP + 1, px + CP, py + CP + 2, 0xFF84705A);
        }
        for (int i = 0; i < N; i++) {
            byte tk = s.tile[i];
            if (tk == BedwarsSim.VOID) continue;
            int x = i % COLS, y = i / COLS, px = BX + x * CP, py = BY + y * CP;
            if (!seen(px, py)) continue;
            if (tk == BedwarsSim.BRIDGE || tk == BedwarsSim.WALL_B) {
                int c = MAIN[s.owner[i]];
                g.fill(px, py, px + CP, py + CP, Gfx.darker(c, 0.18F));
                g.fill(px, py + 2, px + CP, py + 3, Gfx.darker(c, 0.32F));
                g.fill(px, py + 5, px + CP, py + 6, Gfx.darker(c, 0.32F));
                g.fill(px, py, px + CP, py + 1, Gfx.lighter(c, 0.25F));
                continue;
            }
            int base;
            if (isCenter(x, y)) base = ((x + y) & 1) == 0 ? 0xFFD8D2E8 : 0xFFCBC4DE;
            else base = Gfx.mix(((x + y) & 1) == 0 ? 0xFFA6E08A : 0xFF97D67B, MAIN[teamOfCell(x, y)], 0.18F);
            g.fill(px, py, px + CP, py + CP, base);
            float h = Gfx.hash(i, 7);
            if (h > 0.86F) g.fill(px + 2 + (int) (h * 40) % 4, py + 2 + (int) (h * 90) % 4, px + 3 + (int) (h * 40) % 4, py + 3 + (int) (h * 90) % 4, isCenter(x, y) ? 0xFFFFFFFF : 0xFFFFF2A8);
        }
        // pads, generators, shops, beds
        for (int t = 0; t < 4; t++) {
            if (!s.pl[t].active) continue;
            int sc = BedwarsSim.spawnCell(t);
            int sx = BX + (sc % COLS) * CP, sy = BY + (sc / COLS) * CP;
            Gfx.outline(g, sx + 1, sy + 1, CP - 2, CP - 2, Gfx.alpha(MAIN[t], 200));
            int gc = BedwarsSim.genCell(t), gx = BX + (gc % COLS) * CP, gy = BY + (gc / COLS) * CP;
            g.fill(gx + 1, gy + 1, gx + CP - 1, gy + CP - 1, 0xFF4A4458);
            for (int k = 0; k < Math.min(4, (s.ironPile[t] + 7) / 8); k++) g.fill(gx + 1 + k * 2, gy + 5, gx + 3 + k * 2, gy + 7, RES[0]);
            for (int k = 0; k < Math.min(3, s.goldPile[t]); k++) g.fill(gx + 1 + k * 2, gy + 2, gx + 3 + k * 2, gy + 4, RES[1]);
            shop(g, BedwarsSim.shopCell(t), t);
            if (s.bedHp[t] > 0) {
                int bc = BedwarsSim.bedCell(t);
                bed(g, BX + (bc % COLS) * CP, BY + (bc / COLS) * CP, t, s.bedHp[t]);
            }
        }
        // the islands in the middle and at the sides: diamonds, and an emerald
        for (int k = 0; k < 4; k++) {
            int c = BedwarsSim.MID_DIA[k], x = BX + (c % COLS) * CP, y = BY + (c / COLS) * CP;
            g.fill(x + 1, y + 1, x + CP - 1, y + CP - 1, 0xFF4A4458);
            for (int d = 0; d < s.diaPile[k]; d++) gem(g, x + 1 + (d % 2) * 3, y + 1 + (d / 2) * 3, RES[2]);
        }
        {
            int c = BedwarsSim.MID_EM, x = BX + (c % COLS) * CP, y = BY + (c / COLS) * CP;
            g.fill(x + 1, y + 1, x + CP - 1, y + CP - 1, 0xFF4A4458);
            for (int d = 0; d < s.emPile; d++) gem(g, x + 1 + (d % 2) * 3, y + 1 + (d / 2) * 3, RES[3]);
        }
        // the walls
        for (int i = 0; i < N; i++) {
            byte tk = s.tile[i];
            if (tk != BedwarsSim.WALL_F && tk != BedwarsSim.WALL_B) continue;
            if (seen(BX + (i % COLS) * CP, BY + (i / COLS) * CP)) wall(g, BX + (i % COLS) * CP, BY + (i / COLS) * CP, MAIN[s.owner[i]], s.hp[i]);
        }
        // the players, the lower ones in front
        Integer[] order = {0, 1, 2, 3};
        java.util.Arrays.sort(order, (a, b) -> Float.compare(ry[a], ry[b]));
        for (int idx : order) {
            BedwarsSim.Player p = s.pl[idx];
            if (!p.active || !p.alive) continue;
            if (p.invuln > 0 && (anim / 3) % 2 == 0) continue;
            int cx = Math.round(BX + rx[idx] * CP / CELL), cy = Math.round(BY + ry[idx] * CP / CELL);
            Gfx.ellipse(g, cx, cy + 4, 4, 1, 0x44000000);
            Gfx.ellipse(g, cx, cy + 4, 3, 1, Gfx.alpha(MAIN[idx], 150));
            animal(g, idx, cx - 4, cy - 6 + (p.moving >= 0 && (anim / 4) % 2 == 0 ? -1 : 0), p.facing, p.moving >= 0 ? 1 + (anim / 4) % 2 : 0, 0.8F);
            if (p.hurt > 0) Gfx.disc(g, cx, cy - 1, 4, 0x66FF3A4A);
            if (p.swing > 0) {                                       // the sword swings in front of him
                int dx = p.facing == 1 ? -1 : p.facing == 2 ? 1 : 0, dy = p.facing == 0 ? 1 : p.facing == 3 ? -1 : 0;
                int ex = cx + dx * 8, ey = cy - 1 + dy * 8;
                Gfx.line(g, cx + dx * 3, cy - 1 + dy * 3, ex, ey, SWORD[Math.min(3, p.sword)]);
                Gfx.star(g, ex, ey, 1, 0xFFFFFFFF);
            }
            if (p.hp < BedwarsSim.MAX_HP) {                          // a little health bar
                int w = Math.max(0, 8 * p.hp / BedwarsSim.MAX_HP);
                g.fill(cx - 4, cy - 9, cx + 4, cy - 8, 0xAA2B1F4A);
                g.fill(cx - 4, cy - 9, cx - 4 + w, cy - 8, p.hp > 8 ? 0xFF7FE08A : 0xFFFF6B6B);
            }
            if (idx == me) {                                         // a little marker over your own head
                int ay = cy - 13 + (anim / 10) % 2;
                g.fill(cx - 1, ay, cx + 2, ay + 1, 0xFFFFE27A);
                g.fill(cx, ay + 1, cx + 1, ay + 2, 0xFFFFE27A);
            }
        }
        // particles
        for (Pt p : pts) {
            float k = p.life / (float) p.max;
            int x = Math.round(p.x + BX), y = Math.round(p.y + BY);
            if (p.kind == 5) { ghostSprite(g, x, y, p.col, k); continue; }
            int col = Gfx.fade(p.col, Math.min(1F, k * 1.6F));
            if (p.kind == 2 || p.kind == 3) Gfx.star(g, x, y, k > 0.5F ? 1 : 0, col);
            else g.fill(x, y, x + (p.kind == 1 ? 2 : 1), y + 1 + (p.kind == 0 ? 0 : 1), col);
        }
        g.fill(0, 0, W, VIEW_Y, 0xFF1E1542);                                // the world is cut off at the cards and at the bottom
        g.fill(0, VIEW_Y + VIEW_H, W, H, 0xFF1E1542);
        cards(g, s);
        minimap(g, s, me, camX, camY);
        inventory(g, s, me);
        if (s.pl[me].alive && s.state == BedwarsSim.ST_PLAY && nearShop(s, me)) shopPanel(g, s, me);
        // messages over the board
        BedwarsSim.Player mp = s.pl[me];
        if (s.state == BedwarsSim.ST_COUNT) {
            int n = Math.max(1, (s.countdown + 19) / 20);
            String txt = s.countdown <= 6 ? m("cutemod.bedwars.go") : Integer.toString(n);
            float k = 3F + (s.countdown % 20) / 20F;
            sctext(g, txt, W / 2 + 1, H / 2 - 12 + 1, k, 0xAA1B1030);
            sctext(g, txt, W / 2, H / 2 - 12, k, 0xFFFFE27A);
        } else if (bannerT > 0 && s.state == BedwarsSim.ST_PLAY) {
            msg(g, m(bannerKey), 0xFFFF9AA5);
        } else if (s.state == BedwarsSim.ST_PLAY && mp.out) {
            msg(g, m("cutemod.bedwars.out"), 0xFFE8E0FF);
        } else if (s.state == BedwarsSim.ST_PLAY && !mp.alive) {
            msg(g, tr("cutemod.bedwars.respawn", (mp.respawn + 19) / 20), 0xFFE8E0FF);
        }
    }

    /** Is a cell with its corner here (on the screen) at least a little in the window? */
    private static boolean seen(int px, int py) { return px > -CP && px < W && py > VIEW_Y - CP && py < VIEW_Y + VIEW_H; }

    /** The whole map, one pixel for a cell, in the lower right corner: the islands, the bridges, the beds, everybody and where the camera looks. */
    private void minimap(GuiGraphics g, BedwarsSim s, int me, int camX, int camY) {
        int x0 = W - COLS - 4, y0 = VIEW_Y + VIEW_H - ROWS - 4;
        Gfx.rrect(g, x0 - 2, y0 - 2, COLS + 4, ROWS + 4, 2, 0xB01E1542);
        for (int i = 0; i < N; i++) {
            byte tk = s.tile[i];
            if (tk == BedwarsSim.VOID) continue;
            int x = i % COLS, y = i / COLS, c;
            if (tk == BedwarsSim.FLOOR) c = BedwarsSim.teamIsland(x, y) < 0 ? 0xFF9C94B8 : Gfx.mix(0xFF7FBF68, MAIN[BedwarsSim.teamIsland(x, y)], 0.25F);
            else c = tk == BedwarsSim.WALL_F ? Gfx.lighter(MAIN[s.owner[i]], 0.3F) : MAIN[s.owner[i]];
            g.fill(x0 + x, y0 + y, x0 + x + 1, y0 + y + 1, c);
        }
        for (int t = 0; t < 4; t++) {
            if (!s.pl[t].active || s.bedHp[t] <= 0) continue;
            int bc = BedwarsSim.bedCell(t);
            g.fill(x0 + bc % COLS - 1, y0 + bc / COLS - 1, x0 + bc % COLS + 2, y0 + bc / COLS + 2, MAIN[t]);
            g.fill(x0 + bc % COLS, y0 + bc / COLS, x0 + bc % COLS + 1, y0 + bc / COLS + 1, 0xFFFFFFFF);
        }
        for (int i = 0; i < 4; i++) {
            BedwarsSim.Player p = s.pl[i];
            if (!p.active || !p.alive) continue;
            int mx2 = x0 + p.x / CELL, my2 = y0 + p.y / CELL;
            if (i == me && (anim / 8) % 2 == 0) g.fill(mx2 - 2, my2 - 2, mx2 + 3, my2 + 3, 0xFFFFFFFF);
            g.fill(mx2 - 1, my2 - 1, mx2 + 2, my2 + 2, MAIN[i]);
            g.fill(mx2, my2, mx2 + 1, my2 + 1, INK);
        }
        Gfx.outline(g, x0 + camX / CP, y0 + camY / CP, W / CP, VIEW_H / CP, 0xAAFFFFFF);
    }

    private void msg(GuiGraphics g, String text, int col) {
        int w = Math.min(W - 40, tw(text) + 14);
        int x = (W - w) / 2, y = 62;
        Gfx.bubble(g, x, y, w, 12, 4, 0xDD2B1F4A);
        ctextW(g, text, W / 2, y + 2, w - 6, col);
    }

    private boolean nearShop(BedwarsSim s, int me) {
        BedwarsSim.Player p = s.pl[me];
        int c = BedwarsSim.shopCell(me);
        int dx = p.x - ((c % COLS) * CELL + CELL / 2), dy = p.y - ((c / COLS) * CELL + CELL / 2);
        return dx * dx + dy * dy <= BedwarsSim.SHOP_RANGE * BedwarsSim.SHOP_RANGE;
    }

    /** The shop of the player: four things with the key and the price. */
    private void shopPanel(GuiGraphics g, BedwarsSim s, int me) {
        BedwarsSim.Player p = s.pl[me];
        int x = 62, y = 16, w = 96, h = 46;
        Gfx.rrect(g, x, y, w, h, 3, 0xDD2B1F4A);
        stext(g, m("cutemod.bedwars.shop"), x + 4, y + 2, 0.7F, 0xFFFFE27A);
        for (int it = 1; it <= 4; it++) {
            int ry = y + 8 + (it - 1) * 9;
            int[] pr = BedwarsSim.price(it, p);
            boolean ok = s.canBuy(p, it);
            int col = ok ? 0xFFFFFFFF : 0xFF8A80A8;
            Gfx.bubble(g, x + 3, ry, 8, 8, 2, ok ? 0xFFFFD866 : 0xFF5E4C8C);
            stext(g, Integer.toString(it), x + 5, ry + 1, 0.8F, ok ? 0xFF3A2A10 : 0xFFC9BEE8);
            String name = it == 2 ? (pr == null ? m("cutemod.bedwars.item.max") : tr("cutemod.bedwars.item.2", p.sword + 1))
                    : it == 3 ? (pr == null ? m("cutemod.bedwars.item.max") : tr("cutemod.bedwars.item.3", p.armor + 1))
                    : m("cutemod.bedwars.item." + it);
            stext(g, clip(name, 70), x + 14, ry + 1, 0.75F, col);
            if (pr != null) {
                String n = Integer.toString(pr[1]);
                int nx = x + w - 4 - Math.round(tw(n) * 0.75F);
                stext(g, n, nx, ry + 1, 0.75F, col);
                g.fill(nx - 6, ry + 2, nx - 2, ry + 6, RES[pr[0]]);
            }
        }
    }

    /** What the player has: the resources, the blocks, the health and the sword and armor. */
    private void inventory(GuiGraphics g, BedwarsSim s, int me) {
        BedwarsSim.Player p = s.pl[me];
        int x = 58, y = 116, w = 104, h = 18;
        Gfx.rrect(g, x, y, w, h, 3, 0xCC2B1F4A);
        for (int r = 0; r < 4; r++) {
            int ix = x + 4 + r * 20;
            if (r == 2 || r == 3) gem(g, ix, y + 2, RES[r]); else g.fill(ix, y + 3, ix + 5, y + 6, RES[r]);
            stext(g, Integer.toString(p.res(r)), ix + 7, y + 2, 0.75F, 0xFFFFE9A8);
        }
        int bx = x + 4 + 4 * 20;
        g.fill(bx, y + 2, bx + 5, y + 7, MAIN[me]);
        g.fill(bx, y + 2, bx + 5, y + 3, Gfx.lighter(MAIN[me], 0.4F));
        stext(g, Integer.toString(p.blocks), bx + 7, y + 2, 0.75F, 0xFFFFE9A8);
        // second row: health, sword, armor
        int hy = y + 11;
        g.fill(x + 4, hy, x + 4 + 50, hy + 4, 0xFF3A2C5E);
        g.fill(x + 4, hy, x + 4 + 50 * Math.max(0, p.hp) / BedwarsSim.MAX_HP, hy + 4, p.hp > 8 ? 0xFF7FE08A : 0xFFFF6B6B);
        for (int k = 0; k < 4; k++) g.fill(x + 60 + k * 5, hy, x + 63 + k * 5, hy + 4, k <= p.sword ? SWORD[Math.min(3, p.sword)] : 0xFF3A2C5E);
        for (int k = 0; k < 3; k++) g.fill(x + 84 + k * 5, hy, x + 87 + k * 5, hy + 4, k < p.armor ? 0xFF9AE0FF : 0xFF3A2C5E);
    }

    private void cards(GuiGraphics g, BedwarsSim s) {
        for (int i = 0; i < 4; i++) {
            BedwarsSim.Player p = s.pl[i];
            int x = 1 + i * 55, y = 0, w = 53, h = 13;
            if (!p.active) {
                Gfx.rrect(g, x, y, w, h, 3, 0x30FFFFFF);
                continue;
            }
            Gfx.rrect(g, x, y, w, h, 3, p.out ? 0xFF2A2142 : 0xFF3A2C5E);
            g.fill(x + 1, y + 2, x + 3, y + h - 2, p.out ? 0xFF55496F : MAIN[i]);
            animal(g, i, x + 3, y + 1, 0, 0, 1F);
            if (p.out) { g.fill(x + 3, y + 1, x + 14, y + h - 1, 0x99221A38); stext(g, "x", x + 6, y + 3, 1.3F, 0xFFFF8FA8); }
            stext(g, clip(nameOf(i), 24), x + 16, y + 1, 0.72F, p.out ? 0xFF8A80A8 : 0xFFFFFFFF);
            // the bed: whole, hurt or gone
            int bx = x + 16, by = y + 8;
            if (s.bedHp[i] > 0) {
                g.fill(bx, by, bx + 7, by + 4, MAIN[i]);
                g.fill(bx, by, bx + 2, by + 4, 0xFFFFFFFF);
                if (s.bedHp[i] < BedwarsSim.BED_HP) g.fill(bx + 7, by, bx + 8, by + 4, 0xFFFF6B6B);
            } else {
                g.fill(bx, by, bx + 7, by + 4, 0xFF55496F);
                Gfx.line(g, bx, by, bx + 6, by + 3, 0xFFFF6B6B);
                Gfx.line(g, bx, by + 3, bx + 6, by, 0xFFFF6B6B);
            }
            Gfx.star(g, x + w - 13, y + 4, 1, 0xFFFFE27A);
            stext(g, Integer.toString(p.kills), x + w - 9, y + 1, 0.72F, 0xFFFFE27A);
        }
    }

    // ---------------------------------------------------------------- pieces
    /** A bed in the 8 x 8 cell at (x, y): a blanket in the colour of the team and a white pillow. */
    private void bed(GuiGraphics g, int x, int y, int team, int hp) {
        int c = MAIN[team];
        g.fill(x + 1, y + 2, x + 7, y + 7, Gfx.darker(c, 0.25F));
        g.fill(x + 1, y + 2, x + 7, y + 6, c);
        g.fill(x + 1, y + 2, x + 3, y + 6, 0xFFFFFFFF);
        g.fill(x + 1, y + 6, x + 2, y + 7, 0xFF6B4A2A); g.fill(x + 6, y + 6, x + 7, y + 7, 0xFF6B4A2A);
        if (hp < BedwarsSim.BED_HP) Gfx.line(g, x + 3, y + 2, x + 5, y + 5, 0xFF3A2A4A);
        if (hp < BedwarsSim.BED_HP / 2) Gfx.line(g, x + 6, y + 2, x + 4, y + 5, 0xFF3A2A4A);
    }

    private void wall(GuiGraphics g, int x, int y, int c, int hp) {
        g.fill(x, y, x + CP, y + CP, Gfx.darker(c, 0.3F));
        g.fill(x, y, x + CP - 1, y + CP - 1, c);
        g.fill(x, y, x + CP - 1, y + 1, Gfx.lighter(c, 0.45F));
        g.fill(x, y, x + 1, y + CP - 1, Gfx.lighter(c, 0.3F));
        g.fill(x + 3, y + 3, x + 5, y + 5, Gfx.darker(c, 0.1F));
        if (hp <= 2) Gfx.line(g, x + 1, y + 1, x + 4, y + 5, 0xFF3A2A4A);
        if (hp <= 1) Gfx.line(g, x + 6, y + 1, x + 3, y + 6, 0xFF3A2A4A);
    }

    private void gem(GuiGraphics g, int x, int y, int col) {
        g.fill(x + 1, y, x + 3, y + 1, Gfx.lighter(col, 0.5F));
        g.fill(x, y + 1, x + 4, y + 3, col);
        g.fill(x + 1, y + 3, x + 3, y + 4, Gfx.darker(col, 0.3F));
    }

    /** The shopkeeper: a little brown villager with a big nose. */
    private void shop(GuiGraphics g, int cell, int team) {
        int x = BX + (cell % COLS) * CP, y = BY + (cell / COLS) * CP;
        g.fill(x + 2, y + 3, x + 6, y + 8, 0xFF8A5A3A);
        g.fill(x + 2, y + 1, x + 6, y + 4, 0xFFE8C9A0);
        g.fill(x + 3, y + 2, x + 4, y + 3, INK); g.fill(x + 5, y + 2, x + 6, y + 3, INK);
        g.fill(x + 4, y + 3, x + 5, y + 5, 0xFFC9946A);
        g.fill(x + 2, y + 5, x + 6, y + 6, 0xFFFFD34D);
        Gfx.outline(g, x + 1, y, 6, 8, Gfx.alpha(MAIN[team], 170));
    }

    private void ghostSprite(GuiGraphics g, int x, int y, int tint, float k) {
        int body = Gfx.fade(Gfx.mix(0xFFFFFFFF, tint, 0.3F), Math.min(1F, k * 1.5F));
        g.fill(x - 3, y - 2, x + 4, y + 3, body);
        g.fill(x - 2, y - 4, x + 3, y - 2, body);
        g.fill(x - 3, y + 3, x - 1, y + 4, body); g.fill(x, y + 3, x + 1, y + 4, body); g.fill(x + 2, y + 3, x + 4, y + 4, body);
        int eye = Gfx.fade(INK, Math.min(1F, k * 1.5F));
        g.fill(x - 2, y - 2, x - 1, y, eye); g.fill(x + 1, y - 2, x + 2, y, eye);
    }

    /**
     * One animal, drawn into an 11 x 11 pixel box at (ox, oy) and scaled by k. slot: 0 cat, 1 panda, 2 fox, 3 penguin.
     * facing: 0 down (the face is seen), 1 left, 2 right, 3 up (the back of the head). step: 0 stands, 1 and 2 are the two steps.
     */
    private void animal(GuiGraphics g, int slot, int ox, int oy, int facing, int step, float k) {
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(k, k, 1F);
        int main = MAIN[slot], rim = RIM[slot];
        int ear = slot == 1 ? 0xFF2B2B35 : slot == 2 ? 0xFFE07B1F : main;
        // ears (the penguin has none, only a tuft)
        if (slot == 3) { px(g, 5, 1, 1, 2, rim); px(g, 4, 2, 1, 1, rim); }
        else {
            px(g, 1, slot == 1 ? 1 : 0, 2, slot == 1 ? 2 : 3, ear); px(g, 8, slot == 1 ? 1 : 0, 2, slot == 1 ? 2 : 3, ear);
            if (slot == 0) { px(g, 2, 1, 1, 2, 0xFFFFD6E6); px(g, 8, 1, 1, 2, 0xFFFFD6E6); }
            if (slot == 2) { px(g, 1, 0, 1, 1, 0xFF5A3A2A); px(g, 9, 0, 1, 1, 0xFF5A3A2A); }
        }
        // the body and the feet
        int body = slot == 1 ? 0xFFF4F4FA : slot == 3 ? 0xFF4F7BE0 : Gfx.darker(main, 0.08F);
        px(g, 3, 8, 5, 2, body);
        if (slot == 3) px(g, 4, 8, 3, 2, 0xFFFFFFFF);
        int foot = slot == 1 ? 0xFF2B2B35 : slot == 2 ? 0xFF6B3F22 : slot == 3 ? 0xFFFFA63A : rim;
        if (step != 2) px(g, 2, 10, 3, 1, foot);                    // one foot is lifted in each step
        if (step != 1) px(g, 6, 10, 3, 1, foot);
        // the head: a darker lip at the bottom, then the face
        head(g, 1, rim);
        head(g, 0, main);
        if (slot == 1) px(g, 3, 4, 5, 3, 0xFFFFFFFF);
        if (slot == 2 && facing != 3) { px(g, 2, 6, 2, 1, 0xFFFFF1DD); px(g, 7, 6, 2, 1, 0xFFFFF1DD); px(g, 4, 7, 3, 1, 0xFFFFF1DD); }
        if (slot == 3 && facing != 3) px(g, 3, 4, 5, 4, 0xFFFFFFFF);
        if (facing == 3) {                                          // the back: no face, just a darker patch of fur
            px(g, 4, 3, 3, 1, rim);
            g.pose().popPose();
            return;
        }
        int dx = facing == 1 ? -1 : facing == 2 ? 1 : 0;
        boolean blink = (anim + slot * 37) % 150 < 6;
        if (slot == 1) {                                            // the dark patches round the eyes
            px(g, 2 + dx, 4, 2, 3, 0xFF2B2B35); px(g, 7 + dx, 4, 2, 3, 0xFF2B2B35);
            if (!blink) { px(g, 3 + dx, 5, 1, 1, 0xFFFFFFFF); px(g, 7 + dx, 5, 1, 1, 0xFFFFFFFF); }
            px(g, 5 + dx, 6, 1, 1, 0xFF2B2B35);
        } else {
            int eh = blink ? 1 : 2;
            px(g, 3 + dx, 5, 1, eh, INK); px(g, 7 + dx, 5, 1, eh, INK);
            if (!blink) { px(g, 3 + dx, 5, 1, 1, 0xFF6B5A7E); px(g, 7 + dx, 5, 1, 1, 0xFF6B5A7E); }
            if (slot == 3) { px(g, 4 + dx, 6, 3, 1, 0xFFFFA63A); px(g, 5 + dx, 7, 1, 1, 0xFFE0841A); }
            else { px(g, 5 + dx, 6, 1, 1, slot == 0 ? 0xFFE0508A : INK); px(g, 2 + dx, 6, 1, 1, 0x88FF6FA3); px(g, 8 + dx, 6, 1, 1, 0x88FF6FA3); }
        }
        g.pose().popPose();
    }

    private static void head(GuiGraphics g, int dy, int col) {
        px(g, 3, 2 + dy, 5, 1, col);
        px(g, 2, 3 + dy, 7, 1, col);
        px(g, 1, 4 + dy, 9, 3, col);
        px(g, 2, 7 + dy, 7, 1, col);
    }

    private static void px(GuiGraphics g, int x, int y, int w, int h, int argb) {
        if (argb == 0 || w <= 0 || h <= 0) return;
        g.fill(x, y, x + w, y + h, argb);
    }
}
