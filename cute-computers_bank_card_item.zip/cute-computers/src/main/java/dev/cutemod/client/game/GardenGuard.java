package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static dev.cutemod.client.game.GardenArt.coin;
import static dev.cutemod.client.game.GardenArt.px;
import static dev.cutemod.client.game.GardenMaps.*;

/**
 * Garden Guard (tower defense). Pests crawl along the path towards the cabbage patch; cute pet guards placed
 * on the grass stop them. Three gardens, three levels of difficulty, eight guards, eight kinds of pests,
 * 20 waves with a different boss every 5th wave (snail king, digger mole, wasp queen, mother caterpillar), and a rain that slows the pests down.
 * Mouse: pick a guard below, click a tile to place it, click a placed guard to upgrade / sell it.
 * Keys: 1-8 pick, U upgrade, S sell, W rain, Space start / speed.
 */
public class GardenGuard extends MiniGame {
    private static final int BAR_Y = 122;                              // the shop bar at the bottom
    private static final int MAX_WAVE = 20;

    // ---------- guards: 0 cat, 1 penguin, 2 fox, 3 panda, 4 bee, 5 frog, 6 owl, 7 hedgehog ----------
    private static final int[] COST = {15, 25, 35, 40, 30, 30, 50, 35};
    private static final int[] RANGE = {32, 30, 62, 38, 0, 36, 72, 22};
    private static final float[] DMG = {2F, 1F, 9F, 4F, 0F, 4F, 6F, 2F};
    private static final int[] CD = {32, 40, 85, 70, 420, 50, 60, 40};
    private static final int[] SHOT = {0xFFFFB347, 0xFFBFE9FF, 0xFFFF8A3C, 0xFF7ED36A, 0xFFFFD84A, 0xFFFF7A9A, 0xFFF0DCB8, 0xFF9C6A3A};
    private static final int[] BEE_GOLD = {3, 4, 6};                   // coins per payout at levels 1..3

    // ---------- pests: 0 aphid, 1 beetle, 2 crow, 3 boss snail, 4 caterpillar, 5 larva, 6 shell snail, 7 ghost aphid ----------
    // bosses: 3 snail king, 8 digger mole, 9 wasp queen (10 is a wasp of her swarm), 11 mother caterpillar
    private static final float[] E_HP = {6F, 16F, 7F, 140F, 14F, 5F, 28F, 8F, 125F, 100F, 4F, 300F};
    private static final float[] E_SPEED = {0.40F, 0.32F, 0.75F, 0.22F, 0.34F, 0.50F, 0.24F, 0.50F, 0.30F, 0.30F, 0.85F, 0.20F};
    private static final int[] E_GOLD = {2, 4, 3, 25, 3, 1, 6, 4, 25, 25, 1, 40};
    private static final int[] E_ARMOR = {0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0};
    private static final int[] E_COL = {0xFF8EE866, 0xFF8A6AD8, 0xFF3D3550, 0xFFE98AB4, 0xFFB8E060, 0xFFC8F08A, 0xFF9AA4BC, 0xFFD8ECFF,
            0xFF8A6238, 0xFFFFD84A, 0xFFFFD84A, 0xFFC878E0};
    private static final int[] LEAK = {1, 1, 1, 2, 1, 1, 1, 1, 3, 3, 1, 4};             // lives lost when a pest gets through
    private static final int[] HB_UP = {8, 8, 11, 13, 9, 7, 10, 8, 14, 15, 8, 16};      // how high its health bar floats
    /** The bosses of waves 5, 10, 15 and 20; the last one listed leads the wave. */
    private static final int[][] BOSSES = {{3}, {3, 8}, {8, 9}, {3, 9, 11}};

    // ---------- difficulty: easy, normal, hard ----------
    private static final float[] DIFF_HP = {0.8F, 1.1F, 1.3F};
    private static final int[] DIFF_GOLD = {80, 60, 50};
    private static final int[] DIFF_LIVES = {15, 10, 8};

    private static final int RAIN_TIME = 360, RAIN_COOLDOWN = 2700;

    private static final class Tower {
        final int col, row, type, phase;
        int level = 1, cd = 20, invested, fire, born, look;
        Tower(int col, int row, int type, int cost) { this.col = col; this.row = row; this.type = type; this.invested = cost; this.phase = (col * 5 + row * 3) & 15; }
    }

    private static final class Enemy {
        final int kind;
        float hp, maxHp, dist, x, y;
        int slow, fx = 1, fy, flash, trail, reveal, phase, timer;
        boolean dead, under;                                   // under: the mole is digging underground
        Enemy(int kind, float hp) { this.kind = kind; this.hp = hp; this.maxHp = hp; }
    }

    private static final class Proj {
        float x, y;
        final Enemy target;
        final int type;
        final float dmg;
        Proj(float x, float y, Enemy target, int type, float dmg) { this.x = x; this.y = y; this.target = target; this.type = type; this.dmg = dmg; }
    }

    private static final class Pop {
        final float x;
        float y;
        int t = 40;
        final String s;
        final int col;
        Pop(float x, float y, String s, int col) { this.x = x; this.y = y; this.s = s; this.col = col; }
    }

    /** A little visual effect: 0 dot, 1 ring, 2 sparkle, 3 slime, 4 puff, 5 tongue. */
    private static final class Fx {
        float x, y, vx, vy, r, ex, ey;
        int t, max, col, kind;
    }

    private final List<Tower> towers = new ArrayList<>();
    private final List<Enemy> enemies = new ArrayList<>();
    private final List<Proj> projs = new ArrayList<>();
    private final List<Pop> pops = new ArrayList<>();
    private final List<Fx> fxs = new ArrayList<>();
    private final List<Integer> queue = new ArrayList<>();
    private final List<Enemy> pending = new ArrayList<>();      // pests born while the others are being moved
    private final float[] pos = new float[4];

    private Map map = ALL[0];
    private int mapIdx, diff = 1;                                    // the choice made in the menu
    private boolean menu = true;
    private int gold, lives, maxLives = 10, wave, qi, spawnT, interval, countdown, banner, bannerMax, bannerKind, flash, t, goldPulse;
    private int rain, rainCd, page;
    private boolean waveActive, fast, won;
    private int sel = 0;            // guard picked in the shop (-1 = none)
    private Tower selT;             // a placed guard that is selected

    @Override
    public void reset() {
        score = 0; over = false; won = false; menu = true;
        towers.clear(); enemies.clear(); projs.clear(); pops.clear(); fxs.clear(); queue.clear(); pending.clear();
        map = ALL[mapIdx];
        gold = 0; lives = maxLives = 10; wave = 0; qi = 0; spawnT = 0; interval = 40;
        countdown = 1500; banner = 0; bannerMax = 60; bannerKind = 0; flash = 0; goldPulse = 0;
        rain = 0; rainCd = 0; page = 0;
        waveActive = false; fast = false; sel = 0; selT = null;
    }

    /** Starts a game on a garden (0 meadow, 1 pond, 2 winter) at a difficulty (0 easy, 1 normal, 2 hard). */
    void start(int mapIndex, int difficulty) {
        mapIdx = mapIndex;
        diff = difficulty;
        reset();
        menu = false;
        gold = DIFF_GOLD[diff];
        lives = maxLives = DIFF_LIVES[diff];
    }

    // ---------- numbers ----------
    private static float dmgOf(Tower tw) { return DMG[tw.type] * (1F + 0.4F * (tw.level - 1)); }
    private static float rangeOf(Tower tw) { return RANGE[tw.type] == 0 ? 0 : RANGE[tw.type] + 4 * (tw.level - 1); }
    private static int cdOf(Tower tw) { return Math.max(8, Math.round(CD[tw.type] * (1F - 0.12F * (tw.level - 1)))); }
    private static int upgradeCost(Tower tw) { return Math.round(COST[tw.type] * (tw.level == 1 ? 0.8F : 1.2F)); }
    private static int sellValue(Tower tw) { return Math.round(tw.invested * 0.6F); }

    private Tower towerAt(int c, int r) {
        for (Tower tw : towers) if (tw.col == c && tw.row == r) return tw;
        return null;
    }

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private static boolean isFlying(int kind) { return kind == 2 || kind == 9 || kind == 10; }

    private static boolean isBoss(int kind) { return kind == 3 || kind == 8 || kind == 9 || kind == 11; }

    // ---------- effects ----------
    private void fx(int kind, float x, float y, float vx, float vy, int life, int col, float r) {
        if (fxs.size() > 240) fxs.remove(0);
        Fx f = new Fx();
        f.kind = kind; f.x = x; f.y = y; f.vx = vx; f.vy = vy; f.t = life; f.max = life; f.col = col; f.r = r;
        fxs.add(f);
    }

    private void tongue(float x1, float y1, float x2, float y2) {
        fx(5, x1, y1, 0, 0, 7, 0xFFFF7A9A, 0);
        Fx f = fxs.get(fxs.size() - 1);
        f.ex = x2; f.ey = y2;
    }

    private void burst(float x, float y, int col, int n) {
        for (int i = 0; i < n; i++) {
            double a = rnd.nextFloat() * Math.PI * 2;
            float sp = 0.4F + rnd.nextFloat() * 0.8F;
            fx(0, x, y, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp - 0.3F, 16 + rnd.nextInt(10), col, 0);
        }
    }

    private void poof(float x, float y) {
        for (int i = 0; i < 5; i++) fx(4, x + (rnd.nextFloat() - 0.5F) * 8, y + 4, (rnd.nextFloat() - 0.5F) * 0.5F, -0.15F, 18, 0xFFFFFFFF, 4);
        for (int i = 0; i < 4; i++) fx(0, x, y + 3, (rnd.nextFloat() - 0.5F) * 1.4F, -0.4F - rnd.nextFloat() * 0.6F, 20, map.index == 2 ? 0xFFE8F4FF : 0xFF7ED36A, 0);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (menu) { menuClick(x, y); return true; }
        if (over) return true;
        if (button == 1) { sel = -1; selT = null; return true; }
        if (y >= BAR_Y) { barClick(x, y); return true; }
        if (y < OY) return true;
        int c = x / T, r = (y - OY) / T;
        if (c < 0 || c >= COLS || r < 0 || r >= ROWS) return true;
        Tower at = towerAt(c, r);
        if (at != null) { selT = at; sel = -1; beep(); return true; }
        if (sel >= 0 && map.buildable(c, r)) {
            if (gold >= COST[sel]) {
                gold -= COST[sel];
                Tower tw = new Tower(c, r, sel, COST[sel]);
                if (sel == 4) tw.cd = cdOf(tw);                      // a bee pays after its first full round, not at once
                towers.add(tw);
                poof(c * T + T / 2F, OY + r * T + T / 2F);
                pling(1.3F);
            } else beep();
            return true;
        }
        selT = null;
        return true;
    }

    private void barClick(int x, int y) {
        for (int i = 0; i < 4; i++) {
            if (in(x, y, 2 + i * 31, BAR_Y + 2, 29, 16)) { sel = page * 4 + i; selT = null; beep(); return; }
        }
        if (in(x, y, 126, BAR_Y + 2, 10, 16)) { page = 1 - page; beep(); return; }
        if (selT != null) {
            if (in(x, y, 139, BAR_Y + 2, 21, 16)) { upgrade(); return; }
            if (in(x, y, 161, BAR_Y + 2, 16, 16)) { sell(); return; }
        }
        if (in(x, y, 179, BAR_Y + 2, 17, 16)) { castRain(); return; }
        if (in(x, y, 198, BAR_Y + 2, 20, 16)) goOrSpeed();
    }

    private void goOrSpeed() {
        if (!waveActive) {
            gold += Math.max(0, countdown / 60);      // calling the wave early pays one coin per second saved
            startWave();
        } else {
            fast = !fast;
            beep();
        }
    }

    private void castRain() {
        if (rain > 0 || rainCd > 0) { beep(); return; }
        rain = RAIN_TIME;
        rainCd = RAIN_COOLDOWN;
        pling(0.8F);
    }

    private void upgrade() {
        if (selT == null || selT.level >= 3) return;
        int c = upgradeCost(selT);
        if (gold < c) { beep(); return; }
        gold -= c; selT.invested += c; selT.level++;
        float cx = selT.col * T + T / 2F, cy = OY + selT.row * T + T / 2F;
        fx(1, cx, cy, 0, 0, 20, 0xFFFFE27A, 11);
        for (int i = 0; i < 4; i++) fx(2, cx + (i - 1.5F) * 3, cy, 0, -0.35F - i * 0.05F, 26, 0xFFFFF2A0, 0);
        pling(1.5F);
    }

    private void sell() {
        if (selT == null) return;
        gold += sellValue(selT);
        float cx = selT.col * T + T / 2F, cy = OY + selT.row * T + T / 2F;
        poof(cx, cy);
        pops.add(new Pop(cx, cy - 6, "+" + sellValue(selT), 0xFFFFE27A));
        goldPulse = 14;
        towers.remove(selT);
        selT = null;
        beep();
    }

    @Override
    public boolean key(int keyCode) {
        if (menu) {
            if (keyCode >= 49 && keyCode <= 51) { mapIdx = keyCode - 49; map = ALL[mapIdx]; beep(); return true; }
            if (keyCode == KEY_LEFT) { diff = Math.max(0, diff - 1); beep(); return true; }
            if (keyCode == KEY_RIGHT) { diff = Math.min(2, diff + 1); beep(); return true; }
            if (keyCode == KEY_SPACE || keyCode == 257) { start(mapIdx, diff); return true; }
            return false;
        }
        if (over) return false;
        if (keyCode >= 49 && keyCode <= 56) { sel = keyCode - 49; page = sel / 4; selT = null; beep(); return true; }
        if (keyCode == 85) { upgrade(); return true; }          // U
        if (keyCode == 83) { sell(); return true; }             // S
        if (keyCode == 87) { castRain(); return true; }         // W
        if (keyCode == KEY_SPACE) { goOrSpeed(); return true; }
        return false;
    }

    // ---------- simulation ----------
    @Override
    public void tick() {
        t++;
        if (menu || over) return;
        int steps = fast ? 2 : 1;
        for (int s = 0; s < steps && !over; s++) step();
    }

    private Enemy makeEnemy(int kind) {
        float mul = 1F + 0.20F * (wave - 1);
        return new Enemy(kind, E_HP[kind] * mul * DIFF_HP[diff]);
    }

    private static boolean targetable(Enemy e) { return !e.dead && !e.under && (e.kind != 7 || e.reveal > 0); }

    /** The pest a guard shoots at: the one furthest along the path, or the toughest, and optionally a crow first. */
    private Enemy pick(float cx, float cy, float rng, boolean strong, boolean air) {
        Enemy best = null;
        float bv = -1;
        for (Enemy e : enemies) {
            if (!targetable(e)) continue;
            float dx = e.x - cx, dy = e.y - cy;
            if (dx * dx + dy * dy > rng * rng) continue;
            float v = strong ? e.hp : e.dist;
            if (air && isFlying(e.kind)) v += 100000F;
            if (v > bv) { bv = v; best = e; }
        }
        return best;
    }

    private Enemy spawnPest(int kind, float dist) {
        Enemy n = makeEnemy(kind);
        n.dist = Math.max(0F, dist);
        place(n);
        pending.add(n);
        return n;
    }

    /** What the bosses do besides walking. */
    private void bossAi(Enemy e) {
        switch (e.kind) {
            case 3 -> {   // the snail king flies into a rage when it is half way down
                if (e.phase == 0 && e.hp < e.maxHp * 0.5F) {
                    e.phase = 1;
                    fx(1, e.x, e.y, 0, 0, 24, 0xFFFF6B6B, 16);
                    burst(e.x, e.y - 4, 0xFFFF6B6B, 8);
                }
            }
            case 8 -> {   // the mole digs underground now and then: nobody can hit it, and it moves faster
                e.timer++;
                if (!e.under && e.timer >= 260) { e.under = true; e.timer = 0; burst(e.x, e.y + 2, 0xFF8A6238, 10); fx(4, e.x, e.y + 3, 0, 0, 16, 0xFFB8905A, 6); }
                else if (e.under && e.timer >= 90) { e.under = false; e.timer = 0; burst(e.x, e.y + 2, 0xFF8A6238, 10); fx(4, e.x, e.y + 3, 0, 0, 16, 0xFFB8905A, 6); }
            }
            case 9 -> {   // the wasp queen sends out her swarm
                if (++e.timer >= 150 && enemies.size() + pending.size() < 70) {
                    e.timer = 0;
                    spawnPest(10, e.dist - 2F);
                    spawnPest(10, e.dist + 2F);
                    fx(1, e.x, e.y - 4, 0, 0, 14, 0xFFFFD84A, 9);
                }
            }
            case 11 -> {  // mother caterpillar: she drops larvae, and bursts into caterpillars at two thirds and one third
                if (++e.timer >= 240) { e.timer = 0; spawnPest(5, e.dist - 6F); }
                if ((e.phase == 0 && e.hp < e.maxHp * 0.66F) || (e.phase == 1 && e.hp < e.maxHp * 0.33F)) {
                    e.phase++;
                    for (int i = 0; i < 4; i++) spawnPest(4, e.dist + (i - 1.5F) * 5F);
                    fx(1, e.x, e.y, 0, 0, 26, 0xFFFF9AE0, 18);
                    burst(e.x, e.y, 0xFFE8A0F0, 12);
                    pling(0.7F);
                }
            }
            default -> { }
        }
    }

    private void step() {
        if (banner > 0) banner--;
        if (flash > 0) flash--;
        if (goldPulse > 0) goldPulse--;
        if (rain > 0) rain--;
        if (rainCd > 0) rainCd--;

        if (!waveActive) {
            if (--countdown <= 0) startWave();
        } else if (qi < queue.size()) {
            if (--spawnT <= 0) {
                Enemy e = makeEnemy(queue.get(qi++));
                place(e);
                enemies.add(e);
                if (isBoss(e.kind)) {                                        // a boss makes an entrance
                    fx(1, e.x, e.y, 0, 0, 26, E_COL[e.kind], 16);
                    burst(e.x, e.y, E_COL[e.kind], 8);
                    pling(0.6F);
                }
                spawnT = interval;
            }
        } else if (enemies.isEmpty()) {
            endWave();
            if (over) return;
        }

        // pests walk
        for (Enemy e : enemies) {
            if (e.dead) continue;
            if (e.flash > 0) e.flash--;
            if (e.reveal > 0) e.reveal--;
            bossAi(e);
            if (rain > 0 && !isFlying(e.kind)) e.slow = Math.max(e.slow, 2);   // the rain slows everything on the ground
            float sp = E_SPEED[e.kind] * (e.slow > 0 ? 0.5F : 1F);
            if (e.kind == 3 && e.phase == 1) sp *= 1.5F;                        // the enraged snail king
            if (e.under) sp *= 1.6F;                                             // the mole is quicker underground
            if (e.slow > 0) e.slow--;
            e.dist += sp;
            if (e.dist >= map.total) {
                e.dead = true;
                lives -= LEAK[e.kind];
                flash = 18;
                burst(e.x, e.y, 0xFFFF6B8A, 6);
                pling(0.5F);
                if (lives <= 0) { lives = 0; over = true; }
            } else {
                place(e);
                if (e.kind == 3 && ++e.trail % 12 == 0) fx(3, e.x, e.y + 3, 0, 0, 70, 0xFFB8F090, 0);
                if (e.under && (t & 3) == 0) fx(0, e.x + (rnd.nextFloat() - 0.5F) * 8, e.y + 2, 0, -0.35F, 12, 0xFF8A6238, 0);   // flying dirt
            }
        }
        if (!pending.isEmpty()) { enemies.addAll(pending); pending.clear(); }

        // the owls light up the ghosts
        for (Tower tw : towers) {
            if (tw.type != 6) continue;
            float cx = tw.col * T + T / 2F, cy = OY + tw.row * T + T / 2F, rng = rangeOf(tw);
            for (Enemy e : enemies) {
                if (e.dead || e.kind != 7) continue;
                float dx = e.x - cx, dy = e.y - cy;
                if (dx * dx + dy * dy <= rng * rng) e.reveal = 14;
            }
        }

        // guards at work
        for (Tower tw : towers) {
            tw.born++;
            if (tw.fire > 0) tw.fire--;
            if (tw.cd > 0) {
                tw.cd--;
                if (rain > 0 && (t & 1) == 0 && tw.cd > 0) tw.cd--;          // in the rain everybody works a bit faster
                continue;
            }
            float cx = tw.col * T + T / 2F, cy = OY + tw.row * T + T / 2F, rng = rangeOf(tw);
            switch (tw.type) {
                case 4 -> {   // the bee pays coins
                    int n = BEE_GOLD[tw.level - 1];
                    gold += n;
                    goldPulse = 14;
                    tw.fire = 12;
                    tw.cd = cdOf(tw);
                    pops.add(new Pop(cx, cy - 8, "+" + n, 0xFFFFE27A));
                    fx(2, cx, cy - 4, 0, -0.3F, 20, 0xFFFFE27A, 0);
                }
                case 5 -> {   // the frog lashes out with its tongue; crows are its favourite
                    Enemy best = pick(cx, cy, rng, false, true);
                    if (best != null) {
                        hurt(best, dmgOf(tw) * (isFlying(best.kind) ? 3F : 1F));
                        tw.cd = cdOf(tw);
                        tw.fire = 8;
                        tw.look = best.x < cx ? -1 : 1;
                        tongue(cx, cy - 1, best.x, best.y);
                        burst(best.x, best.y, SHOT[5], 2);
                    }
                }
                case 7 -> {   // the hedgehog spikes everything next to it that walks
                    boolean any = false;
                    for (Enemy e : enemies) {
                        if (e.dead || e.under || isFlying(e.kind)) continue;     // spikes hit ghosts too, no need to see them
                        float dx = e.x - cx, dy = e.y - cy;
                        if (dx * dx + dy * dy > rng * rng) continue;
                        hurt(e, dmgOf(tw));
                        burst(e.x, e.y, SHOT[7], 2);
                        any = true;
                    }
                    if (any) {
                        tw.cd = cdOf(tw);
                        tw.fire = 8;
                        tw.look = -tw.look == 0 ? 1 : -tw.look;
                        fx(1, cx, cy, 0, 0, 14, 0xFFC09A68, rng);
                    }
                }
                default -> {
                    Enemy best = pick(cx, cy, rng, tw.type == 2, false);      // the fox goes for the toughest pest, the others for the first
                    if (best != null) {
                        projs.add(new Proj(cx, cy - 2, best, tw.type, dmgOf(tw)));
                        tw.cd = cdOf(tw);
                        tw.fire = 8;
                        tw.look = best.x < cx ? -1 : 1;
                    }
                }
            }
        }

        // shots fly
        Iterator<Proj> pit = projs.iterator();
        while (pit.hasNext()) {
            Proj p = pit.next();
            if (p.target.dead) { pit.remove(); continue; }
            float dx = p.target.x - p.x, dy = p.target.y - p.y;
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d <= 3.5F) { hit(p); pit.remove(); continue; }
            p.x += dx / d * 3.2F;
            p.y += dy / d * 3.2F;
            if ((t & 1) == 0) fx(0, p.x, p.y, 0, 0, 9, SHOT[p.type], 0);
        }

        // the fallen
        List<Enemy> born = null;
        Iterator<Enemy> eit = enemies.iterator();
        while (eit.hasNext()) {
            Enemy e = eit.next();
            if (e.dead) { eit.remove(); continue; }
            if (e.hp <= 0) {
                e.dead = true;
                int g = E_GOLD[e.kind] + wave / 6;
                gold += g;
                goldPulse = 14;
                score += e.kind == 11 ? 25 : isBoss(e.kind) ? 10 : 1;
                pops.add(new Pop(e.x, e.y - 4, "+" + g, 0xFFFFE27A));
                burst(e.x, e.y, E_COL[e.kind], isBoss(e.kind) ? 16 : 7);
                fx(2, e.x, e.y, 0, -0.2F, 18, 0xFFFFFFFF, 0);
                if (isBoss(e.kind)) {
                    fx(1, e.x, e.y, 0, 0, 24, 0xFFFFC0DA, 14);
                    for (int i = 0; i < 6; i++) fx(2, e.x + (i - 2.5F) * 3, e.y - 3, 0, -0.3F - i * 0.04F, 30, 0xFFFFF2A0, 0);
                    pling(1.9F);
                }
                if (e.kind == 4) {                                           // a caterpillar falls apart into two larvae
                    if (born == null) born = new ArrayList<>();
                    for (int i = 0; i < 2; i++) {
                        Enemy l = makeEnemy(5);
                        l.dist = Math.max(0F, e.dist + (i == 0 ? -3F : 3F));
                        place(l);
                        born.add(l);
                    }
                }
                eit.remove();
            }
        }
        if (born != null) enemies.addAll(born);

        Iterator<Pop> qit = pops.iterator();
        while (qit.hasNext()) {
            Pop p = qit.next();
            p.y -= 0.3F;
            if (--p.t <= 0) qit.remove();
        }
        Iterator<Fx> fit = fxs.iterator();
        while (fit.hasNext()) {
            Fx f = fit.next();
            f.x += f.vx;
            f.y += f.vy;
            if (f.kind == 0) f.vy += 0.04F;
            if (--f.t <= 0) fit.remove();
        }
    }

    private void hit(Proj p) {
        Enemy e = p.target;
        hurt(e, p.dmg);
        burst(p.x, p.y, SHOT[p.type], 3);
        if (p.type == 1 && !isFlying(e.kind)) e.slow = 100;      // snowballs slow everything that does not fly
        if (p.type == 3) {                                       // the bamboo bomb splashes
            fx(1, e.x, e.y, 0, 0, 14, 0xFF9BE07A, 16);
            for (Enemy o : enemies) {
                if (o == e || !targetable(o)) continue;
                float dx = o.x - e.x, dy = o.y - e.y;
                if (dx * dx + dy * dy <= 16 * 16) hurt(o, p.dmg * 0.7F);
            }
        }
    }

    private static void hurt(Enemy e, float dmg) {
        if (e.under) return;                                     // a digging mole cannot be hurt
        int armor = E_ARMOR[e.kind];
        e.hp -= armor > 0 ? Math.max(1F, dmg - armor) : dmg;     // shells take points off every hit
        e.flash = 3;
    }

    private void place(Enemy e) {
        map.pos(e.dist, pos);
        e.x = pos[0];
        e.y = pos[1];
        e.fx = (int) pos[2];
        e.fy = (int) pos[3];
    }

    private void startWave() {
        wave++;
        queue.clear();
        int n = Math.min(36, 6 + wave * 2);
        // what can turn up: aphids, beetles (3+), crows (4+), caterpillars (6+), shell snails (8+)
        float[] wgt = {4F, wave >= 3 ? 3F : 0F, wave >= 4 ? 2.5F : 0F, 0F, wave >= 6 ? 2F : 0F, 0F, wave >= 8 ? 1.5F : 0F, 0F};
        float sum = 0;
        for (float w : wgt) sum += w;
        for (int i = 0; i < n; i++) {
            float r = rnd.nextFloat() * sum;
            int k = 0;
            for (int j = 0; j < wgt.length; j++) {
                if (wgt[j] <= 0) continue;
                k = j;
                if (r < wgt[j]) break;
                r -= wgt[j];
            }
            queue.add(k);
        }
        if (wave >= 7) for (int i = 0; i < 1 + (wave - 7) / 3; i++) queue.add(rnd.nextInt(queue.size() + 1), 7);   // ghosts, from wave 7
        if (wave % 5 == 0) for (int b : BOSSES[wave / 5 - 1]) queue.add(b);
        qi = 0;
        spawnT = 20;
        interval = Math.max(16, 46 - wave * 2);
        waveActive = true;
        bannerKind = wave % 5 == 0 ? 1 : wave == 7 ? 2 : 0;
        bannerMax = bannerKind == 0 ? 60 : 130;
        if (bannerKind == 1) pling(0.5F);
        banner = bannerMax;
    }

    private void endWave() {
        waveActive = false;
        gold += 8 + wave * 2;
        goldPulse = 14;
        score += 10;
        pling(1.6F);
        if (wave >= MAX_WAVE) {
            won = true;
            score += 60 + 40 * diff;
            over = true;
        } else countdown = 720;
    }

    // ================= drawing =================
    @Override
    public void render(GuiGraphics g) {
        if (menu) { renderMenu(g); return; }
        drawGround(g);

        // ----- build hints, range rings -----
        Tower hover = null;
        int hc = mx / T, hr = (my - OY) / T;
        boolean inGrid = mx >= 0 && my >= OY && my < BAR_Y && hc < COLS && hr < ROWS;
        if (inGrid) hover = towerAt(hc, hr);
        if (sel >= 0) {
            int a = 0x10 + (int) (Math.sin(t * 0.1) * 5 + 5);
            for (int c = 0; c < COLS; c++) {
                for (int r = 0; r < ROWS; r++) {
                    if (map.buildable(c, r) && towerAt(c, r) == null) rect(g, c * T + 1, OY + r * T + 1, T - 2, T - 2, Gfx.alpha(0xFFFFFFFF, a));
                }
            }
        }
        Tower ringOf = selT != null ? selT : hover;
        if (ringOf != null && rangeOf(ringOf) > 0) ring(g, ringOf.col, ringOf.row, rangeOf(ringOf), true);

        // ----- guards -----
        for (Tower tw : towers) {
            int cx = tw.col * T + T / 2, cy = OY + tw.row * T + T / 2;
            if (tw == selT) {
                int al = 150 + (int) (Math.sin(t * 0.15) * 80);
                Gfx.rrect(g, tw.col * T, OY + tw.row * T, T, T, 3, Gfx.alpha(0xFFFFFFFF, 40));
                Gfx.outline(g, tw.col * T, OY + tw.row * T, T, T, Gfx.alpha(0xFFFFFFFF, al));
            }
            int lift = tw.born < 14 ? -(int) Math.round(Math.sin(tw.born / 14.0 * Math.PI) * 4) : 0;
            GardenArt.tower(g, tw.type, cx, cy + lift, tw.level, tw.look, tw.fire > 0, tw.phase, t, tw.born >= 14);
        }
        if (inGrid && sel >= 0 && towerAt(hc, hr) == null) {      // ghost of the guard to place
            int cx = hc * T + T / 2, cy = OY + hr * T + T / 2;
            boolean ok = map.buildable(hc, hr);
            if (ok) {
                if (RANGE[sel] > 0) ring(g, hc, hr, RANGE[sel], false);
                GardenArt.tower(g, sel, cx, cy, 1, 0, false, 0, t, true);
            }
            boolean can = ok && gold >= COST[sel];
            int bc = can ? 0xFF7CFF8A : 0xFFFF6B6B;
            Gfx.rrect(g, hc * T, OY + hr * T, T, T, 3, Gfx.alpha(bc, 50));
            Gfx.outline(g, hc * T, OY + hr * T, T, T, Gfx.alpha(bc, 200));
        }

        // ----- pests (the flying crows are drawn last) -----
        for (Enemy e : enemies) if (!isFlying(e.kind)) drawEnemy(g, e);
        for (Enemy e : enemies) if (isFlying(e.kind)) drawEnemy(g, e);

        // ----- shots and effects -----
        for (Proj p : projs) GardenArt.shot(g, p.type, Math.round(p.x), Math.round(p.y), t);
        for (Fx f : fxs) drawFx(g, f);
        for (Pop p : pops) {
            int a = p.t > 12 ? 255 : p.t * 20;
            int w = tw(p.s);
            int x = Math.round(p.x) - (w + 6) / 2;
            ctext(g, p.s, x + 6 + w / 2, Math.round(p.y), Gfx.alpha(p.col, a));
            if (a > 120) coin(g, x + 1, Math.round(p.y) + 4);
        }

        // ----- ambient life -----
        ambient(g);
        if (rain > 0) drawRain(g);
        Gfx.glow(g, W - 14, OY + 4, 44, map.glow, 70);
        Gfx.vignette(g, W, H, 46);

        hud(g);
        shopBar(g);

        if (flash > 0) {
            rect(g, 0, 0, W, 3, Gfx.alpha(0xFFFF2040, flash * 7)); rect(g, 0, H - 3, W, 3, Gfx.alpha(0xFFFF2040, flash * 7));
            rect(g, 0, 0, 3, H, Gfx.alpha(0xFFFF2040, flash * 7)); rect(g, W - 3, 0, 3, H, Gfx.alpha(0xFFFF2040, flash * 7));
            rect(g, 0, 0, W, H, Gfx.alpha(0xFFFF2040, flash * 3));
        }
        drawBossBar(g);
        if (banner > 0 && wave > 0) drawBanner(g);
    }

    /** A wide health bar with the name of the boss that is on the path (the toughest one if there are several). */
    private void drawBossBar(GuiGraphics g) {
        Enemy boss = null;
        for (Enemy e : enemies) if (!e.dead && isBoss(e.kind) && (boss == null || e.maxHp > boss.maxHp)) boss = e;
        if (boss == null || banner > 0) return;
        int w = 110, x = W / 2 - w / 2, y = 14;
        Gfx.rrect(g, x - 3, y - 1, w + 6, 14, 5, 0xB8201A28);
        ctext(g, tr("cutemod.garden.bn" + boss.kind), W / 2, y, 0xFFFFE9A0);
        rect(g, x, y + 9, w, 3, 0xFF2A2433);
        float r = Math.max(0F, boss.hp / boss.maxHp);
        int fw = Math.max(1, Math.round(w * r));
        int col = r > 0.5F ? Gfx.mix(0xFFE8D84A, 0xFFE0509A, 1F - (r - 0.5F) * 2F) : 0xFFE0402F;
        rect(g, x, y + 9, fw, 3, col);
        rect(g, x, y + 9, fw, 1, 0x60FFFFFF);
    }

    private void drawBanner(GuiGraphics g) {
        int[] bl = wave % 5 == 0 ? BOSSES[wave / 5 - 1] : BOSSES[0];
        int leader = bl[bl.length - 1];
        String s = bannerKind == 1 ? tr("cutemod.garden.bossname", tr("cutemod.garden.bn" + leader)) : bannerKind == 2 ? tr("cutemod.garden.ghost") : tr("cutemod.garden.wave", wave, MAX_WAVE);
        int age = bannerMax - banner;
        float k = Math.min(1F, Math.min(age, banner) / 8F);
        k = 1F - (1F - k) * (1F - k);
        int y = Math.round(-20 + 70 * k);
        int base = bannerKind == 1 ? 0xFFC0386A : bannerKind == 2 ? 0xFF5A6AB8 : 0xFF3F9A5E;
        int bw = bannerKind == 2 ? 164 : bannerKind == 1 ? 156 : 112;
        rect(g, W / 2 - bw / 2 - 6, y + 3, 10, 11, Gfx.darker(base, 0.35F));
        rect(g, W / 2 + bw / 2 - 4, y + 3, 10, 11, Gfx.darker(base, 0.35F));
        Gfx.bubble(g, W / 2 - bw / 2, y, bw, 16, 4, base);
        ctextW(g, s, W / 2, y + 4, bw - 12, 0xFFFFFFFF);
        if (bannerKind == 1) { Gfx.star(g, W / 2 - bw / 2 + 8, y + 8, 2, 0xFFFFE27A); Gfx.star(g, W / 2 + bw / 2 - 8, y + 8, 2, 0xFFFFE27A); }
    }

    /** The meadow, the path, the fence and the scenery: shared by the game and the menu. */
    private void drawGround(GuiGraphics g) {
        boolean winter = map.index == 2;
        g.fillGradient(0, 0, W, H, map.grassTop, map.grassBot);
        for (int c = 0; c < COLS; c++) {
            for (int r = 0; r < ROWS; r++) {
                if (((c + r) & 1) == 0 && !map.path[c][r]) rect(g, c * T, OY + r * T, T, T, winter ? 0x18FFFFFF : 0x16FFFFFF);
            }
        }
        int[] tuft = map.tuft;
        for (int i = 0; i + 1 < tuft.length; i += 2) {
            int x = tuft[i], y = tuft[i + 1];
            if (winter) { px(g, x, y, 0xFFB8D4EC); px(g, x + 1, y, 0xFFC9E1F4); px(g, x + 1, y + 1, 0xFFA9C4DC); }
            else { px(g, x, y, 0xFF58A84A); px(g, x + 2, y, 0xFF58A84A); px(g, x + 1, y + 1, 0xFF4A9A40); px(g, x + 1, y, 0xFF8ED47A); }
        }
        int[] flower = map.flower;
        for (int i = 0; i + 2 < flower.length; i += 3) {
            int x = flower[i], y = flower[i + 1], col = flower[i + 2];
            if (winter) { if (((t / 20 + i) & 3) == 0) Gfx.sparkle(g, x, y, 1, t + i * 7, 0xFFFFFFFF); continue; }
            int sw = ((t / 40 + i) & 3) == 0 ? 1 : 0;                  // now and then a flower nods
            px(g, x, y + 1, 0xFF4A9A40);
            px(g, x + sw, y, col); px(g, x - 1 + sw, y - 1, Gfx.fade(col, 0.75F)); px(g, x + 1 + sw, y - 1, Gfx.fade(col, 0.75F));
            px(g, x + sw, y - 2, Gfx.fade(col, 0.75F));
            px(g, x + sw, y - 1, 0xFFFFD84A);
        }
        // the path: sand, pebbles and soft edges
        boolean[][] path = map.path;
        for (int c = 0; c < COLS; c++) {
            for (int r = 0; r < ROWS; r++) {
                if (!path[c][r]) continue;
                int x = c * T, y = OY + r * T;
                rect(g, x, y, T, T, map.pathCol);
                rect(g, x, y, T, 1, 0x20FFFFFF);
                if (c == 0 || !path[c - 1][r]) rect(g, x, y, 1, T, map.pathEdge);
                if (c == COLS - 1 || !path[c + 1][r]) rect(g, x + T - 1, y, 1, T, map.pathEdge);
                if (r == 0 || !path[c][r - 1]) rect(g, x, y, T, 1, map.pathEdge);
                if (r == ROWS - 1 || !path[c][r + 1]) rect(g, x, y + T - 1, T, 1, map.pathEdge);
                int shade = winter ? 0x30506880 : 0x30406830;
                if (c > 0 && !path[c - 1][r]) rect(g, x - 1, y, 1, T, shade);                       // the grass edge shade
                if (r > 0 && !path[c][r - 1]) rect(g, x, y - 1, T, 1, shade);
            }
        }
        int[] peb = map.pebble;
        for (int i = 0; i + 2 < peb.length; i += 3) {
            rect(g, peb[i], peb[i + 1], peb[i + 2], 1, map.pebA);
            rect(g, peb[i], peb[i + 1] + 1, peb[i + 2], 1, map.pebB);
        }
        // the burrow where the pests come from
        int bx = map.corners[0][0] * T + T / 2, by = OY + map.corners[0][1] * T + T / 2 + 1;
        Gfx.ellipse(g, bx, by, 6, 3, winter ? 0xFF7A5A3A : 0xFF9A6A3C);
        Gfx.ellipse(g, bx, by, 5, 2, 0xFF2A1A0C);
        rect(g, bx - 5, by - 2, 3, 1, winter ? 0xFFF4FAFF : 0xFFB88450);
        // a picket fence along the top
        for (int x = 1; x < W; x += 5) {
            rect(g, x, OY, 3, 4, map.fence); px(g, x + 1, OY - 1, map.fence);
            rect(g, x, OY + 3, 3, 1, Gfx.darker(map.fence, 0.1F));
        }
        rect(g, 0, OY + 1, W, 1, Gfx.darker(map.fence, 0.06F));

        // scenery that blocks tiles
        float sick = 1F - lives / (float) Math.max(1, maxLives);
        for (int c = 0; c < COLS; c++) {
            for (int r = 0; r < ROWS; r++) if (map.block[c][r]) GardenArt.decor(g, map, c, r, t, sick, flash > 0);
        }
        // soft shadow of a drifting cloud
        int cxs = (int) ((t * 0.12F) % (W + 120)) - 60;
        Gfx.ellipse(g, cxs, 70, 38, 16, 0x0C102810);
    }

    private void ambient(GuiGraphics g) {
        if (map.index == 2) {                                           // snow
            for (int i = 0; i < 26; i++) {
                float k = Gfx.hash(i, 90);
                int x = (int) ((k * W + Math.sin(t * 0.02 + i) * 6 + W) % W);
                int y = (int) ((Gfx.hash(i, 91) * H + t * (0.25F + k * 0.3F)) % H);
                int s = i % 3 == 0 ? 2 : 1;
                rect(g, x, y, s, s, Gfx.alpha(0xFFFFFFFF, 200));
            }
            return;
        }
        for (int i = 0; i < 2; i++) {                                   // butterflies (dragonflies at the pond)
            double a = t * 0.012 + i * 2.7;
            int x = (int) (W / 2 + Math.sin(a * 0.7 + i) * 85 + Math.sin(a * 2.3) * 8);
            int y = (int) (OY + 50 + Math.sin(a * 0.9) * 34 + Math.sin(a * 3.1) * 4);
            int wing = ((t / 5 + i) & 1) == 0 ? 2 : 1;
            int col = map.index == 1 ? (i == 0 ? 0xFF8EE8E0 : 0xFFB6D9FF) : (i == 0 ? 0xFFFFB6D9 : 0xFFB6D9FF);
            rect(g, x - wing - 1, y - 1, wing + 1, 2, col);
            rect(g, x + 1, y - 1, wing + 1, 2, col);
            px(g, x, y, 0xFF4A3A5A); px(g, x, y + 1, 0xFF4A3A5A);
        }
        for (int i = 0; i < 7; i++) {                                   // petals
            float k = Gfx.hash(i, 90);
            int x = (int) ((k * W + t * (0.12F + k * 0.1F)) % W);
            int y = OY + 6 + (int) ((Gfx.hash(i, 91) * 100 + Math.sin(t * 0.03 + i) * 6 + 100) % 100);
            px(g, x, y, Gfx.alpha(i % 2 == 0 ? 0xFFFFD6E8 : 0xFFFFFFFF, 170));
        }
    }

    private void drawRain(GuiGraphics g) {
        float k = Math.min(1F, Math.min(rain, RAIN_TIME - rain) / 20F);
        rect(g, 0, OY, W, BAR_Y - OY, Gfx.alpha(0xFF3C6AA0, Math.round(34 * k)));
        for (int i = 0; i < 46; i++) {
            int x = (int) ((Gfx.hash(i, 70) * W + t * 0.6F) % W);
            int y = (int) ((Gfx.hash(i, 71) * 140 + t * (3.4F + Gfx.hash(i, 72) * 1.6F)) % (BAR_Y - OY));
            rect(g, x, OY + y, 1, 3, Gfx.alpha(0xFFC8E4FF, Math.round(150 * k)));
            if (y > BAR_Y - OY - 6 && (t & 1) == 0) px(g, x + 1, OY + y + 3, Gfx.alpha(0xFFFFFFFF, 90));
        }
    }

    private void ring(GuiGraphics g, int col, int row, float r, boolean fill) {
        int cx = col * T + T / 2, cy = OY + row * T + T / 2;
        if (fill) {
            for (int dy = -(int) r; dy <= (int) r; dy += 1) {
                int y = cy + dy;
                if (y < OY || y >= BAR_Y) continue;
                int dx = (int) Math.floor(Math.sqrt(Math.max(0, r * r - dy * dy)));
                int x0 = Math.max(0, cx - dx), x1 = Math.min(W, cx + dx + 1);
                if (x1 > x0) rect(g, x0, y, x1 - x0, 1, 0x1CFFFFFF);
            }
        }
        int n = Math.max(28, (int) (r * 1.6F));
        for (int i = 0; i < n; i++) {
            if (((i + t / 6) & 1) == 0) continue;                  // a dashed ring that slowly turns
            double a = i * Math.PI * 2 / n;
            int x = cx + (int) Math.round(Math.cos(a) * r), y = cy + (int) Math.round(Math.sin(a) * r);
            if (y >= OY && y < BAR_Y && x >= 0 && x < W) { px(g, x, y + 1, 0x38103010); px(g, x, y, 0xF0FFFFFF); }
        }
    }

    private void drawFx(GuiGraphics g, Fx f) {
        float k = f.t / (float) f.max;
        int a = Math.min(255, Math.round(255 * Math.min(1F, k * 1.6F)));
        int x = Math.round(f.x), y = Math.round(f.y);
        switch (f.kind) {
            case 0 -> { int s = k > 0.5F ? 2 : 1; rect(g, x, y, s, s, Gfx.alpha(f.col, a)); }
            case 1 -> {
                float r = f.r * (1F - k) + 2;
                int n = Math.max(12, (int) (r * 2.4F));
                for (int i = 0; i < n; i++) {
                    double an = i * Math.PI * 2 / n;
                    px(g, x + (int) Math.round(Math.cos(an) * r), y + (int) Math.round(Math.sin(an) * r), Gfx.alpha(f.col, a));
                }
            }
            case 2 -> Gfx.star(g, x, y, k > 0.5F ? 2 : 1, Gfx.alpha(f.col, a));
            case 3 -> Gfx.ellipse(g, x, y, 2, 1, Gfx.alpha(f.col, a / 3));
            case 5 -> {
                int ex = Math.round(f.ex), ey = Math.round(f.ey);
                Gfx.line(g, x, y, ex, ey, Gfx.alpha(f.col, a));
                Gfx.disc(g, ex, ey, 1, Gfx.alpha(0xFFFF9AB4, a));
            }
            default -> Gfx.disc(g, x, y, Math.max(1, Math.round(1 + (1F - k) * f.r)), Gfx.alpha(f.col, a / 3));
        }
    }

    private void drawEnemy(GuiGraphics g, Enemy e) {
        int x = Math.round(e.x), y = Math.round(e.y);
        int mode = e.kind == 8 ? (e.under ? 1 : 0) : e.phase;      // what the sprite needs to know: digging, enraged, how many times she burst
        GardenArt.enemy(g, e.kind, x, y, e.fx, e.fy, e.flash > 0, (int) (e.dist * 0.5F), t, e.reveal > 0, mode);
        if (e.kind == 7 && e.reveal <= 0) return;                  // an unseen ghost has no health bar
        if (e.under) return;
        if (e.slow > 0) {
            Gfx.disc(g, x, y, isBoss(e.kind) ? 8 : 4, 0x2890D8FF);
            px(g, x - 3, y - 4 + ((t / 8) & 1), 0xFFFFFFFF); px(g, x + 3, y + 1, 0xFFC8EEFF); px(g, x, y - 5, 0xFFFFFFFF);
        }
        if (e.hp < e.maxHp || isBoss(e.kind)) {
            int w = e.kind == 11 ? 22 : isBoss(e.kind) ? 16 : 9;
            hpBar(g, x - w / 2, y - HB_UP[e.kind], w, Math.max(0F, e.hp / e.maxHp));
        }
    }

    private void hpBar(GuiGraphics g, int x, int y, int w, float ratio) {
        rect(g, x - 1, y - 1, w + 2, 4, 0xB0201A28);
        int fw = Math.max(1, Math.round(w * ratio));
        int col = ratio > 0.5F ? Gfx.mix(0xFFE8D84A, 0xFF6CD64A, (ratio - 0.5F) * 2F) : Gfx.mix(0xFFE0402F, 0xFFE8D84A, ratio * 2F);
        rect(g, x, y, fw, 2, col);
        rect(g, x, y, fw, 1, 0x50FFFFFF);
    }

    // ---------- HUD and shop ----------
    private void hud(GuiGraphics g) {
        g.fillGradient(0, 0, W, OY, 0xCC1E3A24, 0xB0284A30);
        rect(g, 0, OY - 1, W, 1, 0x40FFFFFF);
        // gold
        Gfx.rrect(g, 2, 1, 42, 10, 4, 0x55000000);
        coin(g, 7, 6);
        int gc = goldPulse > 0 ? Gfx.mix(0xFFFFF0B0, 0xFFFFFFFF, goldPulse / 14F) : 0xFFFFE9A0;
        text(g, String.valueOf(gold), 13, 2, gc);
        // lives
        Gfx.rrect(g, 47, 1, 30, 10, 4, 0x55000000);
        Gfx.heart(g, 50, 3, lives <= 3 && (t / 10 & 1) == 0 ? 0xFFFFFFFF : 0xFFFF6B8A);
        text(g, String.valueOf(lives), 60, 2, 0xFFFFFFFF);
        // wave
        Gfx.rrect(g, W / 2 - 32, 1, 64, 10, 4, 0x55000000);
        ctext(g, tr("cutemod.garden.wave", Math.max(1, wave), MAX_WAVE), W / 2, 2, 0xFFFFFFFF);
        int pw = (64 - 8) * Math.min(wave, MAX_WAVE) / MAX_WAVE;
        if (pw > 0) rect(g, W / 2 - 28, 10, pw, 1, 0xFF8EE866);
        // what is coming
        String right = waveActive
                ? String.valueOf(enemies.size() + Math.max(0, queue.size() - qi))
                : tr("cutemod.garden.next", Math.max(0, countdown / 60));
        int rw = tw(right) + 12;
        Gfx.rrect(g, W - rw - 3, 1, rw, 10, 4, 0x55000000);
        if (waveActive) { Gfx.disc(g, W - rw + 3, 6, 2, 0xFF8EE866); px(g, W - rw + 3, 5, 0xFF2A2433); }
        else px(g, W - rw + 3, 6, 0xFFB0FFC0);
        text(g, right, W - rw + 8, 2, waveActive ? 0xFFFFC8C8 : 0xFFC8FFD4);
    }

    private void shopBar(GuiGraphics g) {
        g.fillGradient(0, BAR_Y, W, H, 0xFF7A5638, 0xFF4E3624);
        rect(g, 0, BAR_Y, W, 1, 0xFFB38A5E);
        rect(g, 0, BAR_Y + 1, W, 1, 0x30FFFFFF);
        // tooltip: the name of the picked guard, or what the rain does
        String s = null;
        if (in(mx, my, 179, BAR_Y + 2, 17, 16)) s = tr("cutemod.garden.rain");
        else {
            int tip = selT != null ? selT.type : sel;
            if (tip >= 0) s = tr("cutemod.garden.t" + tip);
        }
        if (s != null) {
            int tipW = Math.min(W - 60, tw(s) + 12);
            Gfx.rrect(g, 4, BAR_Y - 11, tipW, 10, 4, 0xB8201A28);
            ctextW(g, s, 4 + tipW / 2, BAR_Y - 10, tipW - 6, 0xFFFFFFFF);
        }
        for (int i = 0; i < 4; i++) {
            int gi = page * 4 + i, x = 2 + i * 31, y = BAR_Y + 2;
            boolean can = gold >= COST[gi];
            Gfx.bubble(g, x, y, 29, 16, 4, sel == gi ? 0xFF7FA85A : 0xFF6A4E36);
            if (sel == gi) Gfx.outline(g, x - 1, y - 1, 31, 18, Gfx.alpha(0xFFFFFFFF, 150 + (int) (Math.sin(t * 0.15) * 70)));
            Gfx.rrect(g, x + 2, y + 2, 13, 12, 4, 0x40FFF2D0);
            GardenArt.tower(g, gi, x + 8, y + 8, 1, 0, false, 0, t, false);
            text(g, String.valueOf(COST[gi]), x + 17, y + 4, can ? 0xFFFFE9A0 : 0xFFFF9A8A);
            rect(g, x + 2, y + 2, 5, 5, 0x90201A28);                       // the hot key
            text(g, String.valueOf(gi + 1), x + 3, y + 1, 0xFFFFFFFF);
            if (!can) rect(g, x + 1, y + 1, 27, 14, 0x38000000);
        }
        // the page button
        Gfx.bubble(g, 126, BAR_Y + 2, 10, 16, 3, 0xFF6A4E36);
        for (int i = 0; i < 3; i++) rect(g, page == 0 ? 129 + i : 132 - i, BAR_Y + 7 + i, 1, 5 - i * 2, 0xFFFFFFFF);
        px(g, 129, BAR_Y + 15, page == 0 ? 0xFFFFFFFF : 0x80FFFFFF); px(g, 132, BAR_Y + 15, page == 1 ? 0xFFFFFFFF : 0x80FFFFFF);
        if (selT != null) {
            boolean max = selT.level >= 3;
            int uc = max ? 0 : upgradeCost(selT);
            Gfx.bubble(g, 139, BAR_Y + 2, 21, 16, 4, max ? 0xFF6A6A72 : gold >= uc ? 0xFF4E9A5A : 0xFF8A5A5A);
            if (max) ctext(g, "MAX", 149, BAR_Y + 6, 0xFFFFFFFF);
            else {
                for (int i = 0; i < 3; i++) rect(g, 144 - i, BAR_Y + 7 + i, 1 + i * 2, 1, 0xFFFFFFFF);   // a little arrow
                text(g, String.valueOf(uc), 150, BAR_Y + 6, 0xFFFFFFFF);
            }
            Gfx.bubble(g, 161, BAR_Y + 2, 16, 16, 4, 0xFFB07040);
            ctext(g, "$" + sellValue(selT), 169, BAR_Y + 6, 0xFFFFFFFF);
        }
        rainButton(g);
        int gc = waveActive ? (fast ? 0xFF4F9BE8 : 0xFF6A7A9A) : 0xFFE8803A;
        Gfx.bubble(g, 198, BAR_Y + 2, 20, 16, 5, gc);
        // play triangle (start) or one / two chevrons (speed)
        if (!waveActive) {
            for (int i = 0; i < 5; i++) rect(g, 205 + i, BAR_Y + 6 + i, 1, 9 - i * 2 > 0 ? 9 - i * 2 : 1, 0xFFFFFFFF);
        } else {
            int n = fast ? 2 : 1;
            for (int k = 0; k < n; k++) {
                int bx = (n == 1 ? 205 : 201) + k * 7;
                for (int i = 0; i < 4; i++) rect(g, bx + i, BAR_Y + 7 + i, 1, 9 - i * 2 > 0 ? 9 - i * 2 : 1, 0xFFFFFFFF);
            }
        }
    }

    /** The watering can: it casts the rain, and its face drains while it recharges. */
    private void rainButton(GuiGraphics g) {
        int x = 179, y = BAR_Y + 2;
        boolean ready = rain <= 0 && rainCd <= 0;
        int face = rain > 0 ? Gfx.mix(0xFF4F9BE8, 0xFF8FD0FF, (float) (Math.sin(t * 0.2) * 0.5 + 0.5)) : ready ? 0xFF4E8AB8 : 0xFF5A6070;
        Gfx.bubble(g, x, y, 17, 16, 4, face);
        rect(g, x + 4, y + 7, 7, 5, 0xFFDCE6F0); rect(g, x + 4, y + 7, 7, 1, 0xFFFFFFFF); rect(g, x + 4, y + 11, 7, 1, 0xFFA8B8C8);   // the can
        rect(g, x + 2, y + 8, 2, 1, 0xFFA8B8C8); rect(g, x + 2, y + 9, 1, 2, 0xFFA8B8C8);                                              // the handle
        px(g, x + 11, y + 9, 0xFFA8B8C8); px(g, x + 12, y + 8, 0xFFA8B8C8); rect(g, x + 12, y + 6, 2, 2, 0xFF8A98A8);                   // the spout
        int dr = ((t / 5) & 1);
        px(g, x + 13, y + 9 + dr, 0xFF7FD0FF); px(g, x + 12, y + 11 - dr, 0xFF7FD0FF); px(g, x + 14, y + 11 + dr, 0xFF7FD0FF);
        if (rainCd > 0 && rain <= 0) rect(g, x + 1, y + 1, 15, Math.round(14F * rainCd / RAIN_COOLDOWN), 0x78000000);
        text(g, "W", x + 2, y + 1, 0xC0FFFFFF);
    }

    // ================= the menu =================
    private static final int CARD_W = 68, CARD_Y = 19, CARD_H = 50;

    private void menuClick(int x, int y) {
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 5 + i * 72, CARD_Y, CARD_W, CARD_H)) { mapIdx = i; map = ALL[i]; beep(); return; }
            if (in(x, y, 5 + i * 72, 75, CARD_W, 15)) { diff = i; beep(); return; }
        }
        if (in(x, y, W / 2 - 40, 97, 80, 17)) start(mapIdx, diff);
    }

    private void renderMenu(GuiGraphics g) {
        map = ALL[mapIdx];
        drawGround(g);
        rect(g, 0, 0, W, H, 0x4C102010);
        Gfx.vignette(g, W, H, 60);
        Gfx.rrect(g, W / 2 - 64, 3, 128, 12, 5, 0xC01E3A24);
        ctext(g, tr("cutemod.garden.pick"), W / 2, 5, 0xFFFFFFFF);
        for (int i = 0; i < 3; i++) {
            int x = 5 + i * 72, y = CARD_Y;
            boolean on = i == mapIdx, hov = in(mx, my, x, y, CARD_W, CARD_H);
            Gfx.shadow(g, x, y, CARD_W, CARD_H, 4);
            Gfx.bubble(g, x, y, CARD_W, CARD_H, 5, on ? 0xFFFFF0C8 : hov ? 0xFFE8DCC0 : 0xFFC8BC9C);
            if (on) Gfx.outline(g, x - 1, y - 1, CARD_W + 2, CARD_H + 2, Gfx.alpha(0xFFFFFFFF, 160 + (int) (Math.sin(t * 0.15) * 80)));
            Gfx.rrect(g, x + 6, y + 4, 56, 29, 3, 0xFF3A2E22);
            preview(g, ALL[i], x + 7, y + 5);
            ctextW(g, tr("cutemod.garden.m" + i), x + CARD_W / 2, y + 38, CARD_W - 6, 0xFF4A3828);
        }
        String[] dn = {"cutemod.garden.d0", "cutemod.garden.d1", "cutemod.garden.d2"};
        int[] dc = {0xFF5AA85A, 0xFFE0A030, 0xFFC9504A};
        for (int i = 0; i < 3; i++) {
            int x = 5 + i * 72, y = 75;
            boolean on = i == diff, hov = in(mx, my, x, y, CARD_W, 15);
            Gfx.bubble(g, x, y, CARD_W, 15, 4, on ? dc[i] : Gfx.mix(dc[i], 0xFF6A5A4A, hov ? 0.4F : 0.6F));
            if (on) Gfx.outline(g, x - 1, y - 1, CARD_W + 2, 17, Gfx.alpha(0xFFFFFFFF, 160 + (int) (Math.sin(t * 0.15) * 80)));
            ctextW(g, tr(dn[i]), x + 28, y + 4, 46, 0xFFFFFFFF);
            Gfx.heart(g, x + CARD_W - 24, y + 4, 0xFFFFD0DC);
            text(g, String.valueOf(DIFF_LIVES[i]), x + CARD_W - 14, y + 4, 0xFFFFFFFF);
        }
        boolean hov = in(mx, my, W / 2 - 40, 97, 80, 17);
        Gfx.shadow(g, W / 2 - 40, 97, 80, 17, 5);
        Gfx.bubble(g, W / 2 - 40, 97, 80, 17, 6, hov ? 0xFFFF9A4A : 0xFFE8803A);
        for (int i = 0; i < 5; i++) rect(g, W / 2 - 30 + i, 102 + i, 1, 9 - i * 2 > 0 ? 9 - i * 2 : 1, 0xFFFFFFFF);
        ctext(g, tr("cutemod.garden.play"), W / 2 + 6, 102, 0xFFFFFFFF);
        Gfx.rrect(g, W / 2 - 80, 120, 160, 10, 4, 0x80201A28);
        ctextW(g, tr("cutemod.garden.menuhint"), W / 2, 121, 150, 0xFFE8E0D0);
    }

    /** A tiny map: 3 pixels per tile. */
    private void preview(GuiGraphics g, Map m, int x0, int y0) {
        for (int c = 0; c < COLS; c++) {
            for (int r = 0; r < ROWS; r++) {
                int col;
                if (m.path[c][r]) col = m.pathCol;
                else if (m.block[c][r]) {
                    int k = m.kind[c][r];
                    col = k == TREE ? (m.index == 2 ? 0xFF2F6F4A : 0xFF3A8A3A) : k == BUSH ? (m.index == 2 ? 0xFFE8F0F8 : 0xFF58B04A) : k == ROCK ? 0xFF8A8E98
                            : k == CABBAGE ? 0xFFB8F090 : k == WATER || k == LILY ? 0xFF3E96D8 : k == REED ? 0xFF8A9A4A : 0xFFFFFFFF;
                } else col = ((c + r) & 1) == 0 ? Gfx.lighter(m.grassTop, 0.1F) : m.grassBot;
                rect(g, x0 + c * 3, y0 + r * 3, 3, 3, col);
            }
        }
        rect(g, x0 + m.corners[0][0] * 3, y0 + m.corners[0][1] * 3, 3, 3, 0xFF2A1A0C);
        int[] last = m.corners[m.corners.length - 1];
        rect(g, x0 + last[0] * 3, y0 + last[1] * 3, 3, 3, 0xFFE0485A);
    }

    // ---------- framework hooks ----------
    @Override
    public String hintKey() { return "cutemod.hint.garden"; }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return won ? Component.translatable("cutemod.garden.win") : Component.translatable("cutemod.garden.lose");
    }
}
