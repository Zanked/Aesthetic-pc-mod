package dev.cutemod.client.os;

import dev.cutemod.net.StreamActionPayload;
import dev.cutemod.net.StreamSyncPayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** The chat of the LIVE stream on the client: what the server sent (new messages, how many players watch). */
public final class StreamNet {
    private StreamNet() {}

    private static final List<StreamSyncPayload.Msg> queue = new ArrayList<>();
    private static int viewers;
    private static boolean alive;           // the server has answered since we joined

    public static void apply(StreamSyncPayload p) {
        alive = true;
        viewers = p.viewers();
        queue.addAll(p.msgs());
        while (queue.size() > 80) queue.remove(0);
    }

    public static void clear() {
        queue.clear();
        viewers = 0;
        alive = false;
    }

    /** How many real players watch the stream (we are one of them). */
    public static int viewers() { return viewers; }

    /** Has the server answered? If not, what we write is only shown to ourselves. */
    public static boolean alive() { return alive; }

    /** The new messages, once. */
    public static List<StreamSyncPayload.Msg> drain() {
        if (queue.isEmpty()) return List.of();
        List<StreamSyncPayload.Msg> out = new ArrayList<>(queue);
        queue.clear();
        return out;
    }

    public static void join() {
        clear();
        dev.cutemod.client.os.Modem.sendQuiet(new StreamActionPayload(0, ""));
    }

    public static void leave() {
        dev.cutemod.client.os.Modem.sendQuiet(new StreamActionPayload(1, ""));
        clear();
    }

    public static void say(String text) { dev.cutemod.client.os.Modem.sendQuiet(new StreamActionPayload(2, text)); }
}
