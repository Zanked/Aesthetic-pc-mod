package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The picture of the pet's town: ONE plan view on a 6 px grid that fits the screen (no scrolling). Every place has the same
 * scale, the same light (shadows fall to the right and down) and the same soft style as the pets. Only scenery is here; the
 * clicks, the pet, the labels and the texts are in {@link PetMap}.
 * <p>
 * The picture is split in two, like the old map: {@link #still} is what never moves (ground, roads, houses, trees) and is baked once
 * into a texture; {@link #live} is what moves (cars, people, water, smoke, flags, the balloon) and the night, drawn again every tick.
 * All coordinates are "map pixels": x 0..W, y 0..{@link #MH}, the point (0, 0) is under the header ({@link MapArt#HEAD}).
 * The bar at the bottom of the screen covers the last 14 rows, so nothing important stands there.
 */
final class TownMap {
    private TownMap() {}

    static final int W = App.W, H = App.H, OY = MapArt.HEAD, MH = H - OY;

    // ======================================================================
    //  the places, the roads and the pet's way between them
    // ======================================================================
    /** The places of the map (ids of {@link MapArt}), in the order they are drawn and picked. */
    static final int[] PLACES = {MapArt.PARK, MapArt.HOME, MapArt.STAGE, MapArt.SCHOOL, MapArt.BOUTIQUE, MapArt.PANTRY, MapArt.FISHING,
            MapArt.BALLOON, MapArt.FARM, MapArt.CITY};

    /** The box of a place for the pointer (x, y, w, h in map pixels), or null if the id is not a place of this map. */
    static int[] box(int id) {
        return switch (id) {
            case MapArt.PARK -> new int[]{6, 6, 48, 46};
            case MapArt.HOME -> new int[]{70, 20, 34, 38};
            case MapArt.STAGE -> new int[]{106, 4, 34, 42};
            case MapArt.SCHOOL -> new int[]{166, 2, 68, 22};
            case MapArt.BOUTIQUE -> new int[]{166, 42, 24, 17};
            case MapArt.PANTRY -> new int[]{202, 42, 24, 17};
            case MapArt.FISHING -> new int[]{240, 4, 54, 52};
            case MapArt.BALLOON -> new int[]{238, 72, 56, 56};
            case MapArt.FARM -> new int[]{4, 72, 78, 62};
            case MapArt.CITY -> new int[]{84, 74, 58, 58};
            default -> null;
        };
    }

    /** Where the little name sign of a place sits (its centre x and top y). */
    static int[] chip(int id) {
        return switch (id) {
            case MapArt.PARK -> new int[]{26, 44};
            case MapArt.HOME -> new int[]{87, 50};
            case MapArt.STAGE -> new int[]{123, 46};
            case MapArt.SCHOOL -> new int[]{189, 20};
            case MapArt.BOUTIQUE -> new int[]{176, 37};
            case MapArt.PANTRY -> new int[]{216, 37};
            case MapArt.FISHING -> new int[]{268, 46};
            case MapArt.BALLOON -> new int[]{265, 113};
            case MapArt.FARM -> new int[]{30, 73};
            case MapArt.CITY -> new int[]{113, 123};
            default -> null;
        };
    }

    // the roads: a graph of places the pet walks between (x, y on the middle of a road)
    private static final int[][] NODES = {
            {150, 66}, {63, 66}, {63, 40}, {87, 66}, {178, 66}, {214, 66}, {231, 66}, {231, 84},
            {150, 33}, {150, 20}, {189, 33}, {234, 33}, {150, 99}, {112, 99}, {84, 99}, {40, 99}};
    private static final int[][] EDGES = {{1, 2}, {1, 3}, {3, 0}, {0, 4}, {4, 5}, {5, 6}, {6, 7}, {0, 8}, {8, 9}, {8, 10}, {10, 11},
            {0, 12}, {12, 13}, {13, 14}, {14, 15}};

    /** The node where the pet stands for a place of the map (the places that are not on this map, like the old little shops, count as home). */
    static int nodeOf(int id) {
        return switch (id) {
            case MapArt.PARK -> 2;
            case MapArt.HOME -> 3;
            case MapArt.STAGE -> 9;
            case MapArt.SCHOOL -> 10;
            case MapArt.BOUTIQUE -> 4;
            case MapArt.PANTRY -> 5;
            case MapArt.FISHING -> 11;
            case MapArt.FARM -> 15;
            case MapArt.CITY -> 13;
            default -> id == MapArt.BALLOON || (id >= MapArt.AMUSEMENT && id <= MapArt.QUIET) ? 7 : 3;
        };
    }

    static int nodeX(int n) { return NODES[n][0]; }

    static int nodeY(int n) { return NODES[n][1]; }

    /** The shortest way along the roads from one node to another, as the list of nodes (both ends included). */
    static int[] route(int from, int to) {
        int n = NODES.length;
        double[] dist = new double[n];
        int[] prev = new int[n];
        boolean[] done = new boolean[n];
        java.util.Arrays.fill(dist, 1e9);
        java.util.Arrays.fill(prev, -1);
        dist[from] = 0;
        for (int it = 0; it < n; it++) {
            int u = -1;
            for (int i = 0; i < n; i++) if (!done[i] && (u < 0 || dist[i] < dist[u])) u = i;
            if (u < 0 || dist[u] >= 1e9) break;
            done[u] = true;
            for (int[] e : EDGES) {
                int v = e[0] == u ? e[1] : e[1] == u ? e[0] : -1;
                if (v < 0) continue;
                double d = dist[u] + Math.hypot(NODES[u][0] - NODES[v][0], NODES[u][1] - NODES[v][1]);
                if (d < dist[v]) { dist[v] = d; prev[v] = u; }
            }
        }
        List<Integer> path = new ArrayList<>();
        for (int v = to; v >= 0; v = prev[v]) { path.add(0, v); if (v == from) break; }
        if (path.isEmpty() || path.get(0) != from) path = List.of(from);
        int[] r = new int[path.size()];
        for (int i = 0; i < r.length; i++) r[i] = path.get(i);
        return r;
    }

    // ======================================================================
    //  small drawing tools (everything goes through R, so nothing leaves the map)
    // ======================================================================
    static int alpha(int c, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (c & 0xFFFFFF); }

    static int mix(int c, int to, float f) {
        int r = Math.round((c >> 16 & 255) * (1F - f) + (to >> 16 & 255) * f);
        int g = Math.round((c >> 8 & 255) * (1F - f) + (to >> 8 & 255) * f);
        int b = Math.round((c & 255) * (1F - f) + (to & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    static int light(int c, float f) { return mix(c, 0xFFFFFF, f); }

    static int shade(int c, float f) { return mix(c, 0x000000, f); }

    private static void R(GuiGraphics g, int x, int y, int w, int h, int c) {
        int x0 = Math.max(0, x), x1 = Math.min(W, x + w), y0 = Math.max(0, y), y1 = Math.min(MH, y + h);
        if (x1 > x0 && y1 > y0 && (c >>> 24) != 0) g.fill(x0, y0 + OY, x1, y1 + OY, c);
    }

    private static void rr(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int dy = 0; dy < h; dy++) {
            double m = dy + 0.5, e = m < r ? r - m : m > h - r ? m - (h - r) : 0;
            int inset = e > 0 ? (int) Math.round(r - Math.sqrt(Math.max(0, r * r - e * e))) : 0;
            R(g, x + inset, y + dy, w - 2 * inset, 1, c);
        }
    }

    private static void ell(GuiGraphics g, int cx, int cy, int rx, int ry, int c) {
        double a = rx + 0.5, b = ry + 0.5;
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) (a * Math.sqrt(Math.max(0.0, 1.0 - (dy * dy) / (b * b))));
            R(g, cx - dx, cy + dy, 2 * dx + 1, 1, c);
        }
    }

    private static void disc(GuiGraphics g, int cx, int cy, int r, int c) { ell(g, cx, cy, r, r, c); }

    private static void tri(GuiGraphics g, int cx, int y, int wb, int h, int c) {
        for (int i = 0; i < h; i++) {
            int w = Math.max(1, wb * (i + 1) / h);
            R(g, cx - w / 2, y + i, w, 1, c);
        }
    }

    /** A shaded ball: a soft shadow, a dark rim, the colour, a lit side and a highlight. */
    private static void orb(GuiGraphics g, int cx, int cy, int r, int c) {
        disc(g, cx, cy + 1, r, alpha(0x000000, 0x40));
        disc(g, cx, cy, r, shade(c, 0.3F));
        disc(g, cx, cy, Math.max(1, r - 1), c);
        if (r >= 4) {
            disc(g, cx - r / 4, cy - r / 4, Math.max(1, r * 2 / 3), light(c, 0.22F));
            disc(g, cx - r / 3, cy - r / 3, Math.max(1, r / 4), alpha(0xFFFFFF, 0xC0));
        }
    }

    private static void shadow(GuiGraphics g, int x, int y, int w, int h) { rr(g, x + 2, y + 3, w, h, 3, 0x38000000); }

    /** A roof seen from above: a shadow, a darker rim, the colour, a shine and a ridge. */
    private static void roof(GuiGraphics g, int x, int y, int w, int h, int c, boolean ridge) {
        shadow(g, x, y, w, h);
        rr(g, x, y + 1, w, h, 3, shade(c, 0.35F));
        rr(g, x, y, w, h, 3, c);
        rr(g, x + 2, y + 1, w - 4, 2, 1, alpha(light(c, 0.55F), 0xA0));
        if (ridge) R(g, x + 3, y + h / 2, w - 6, 1, light(c, 0.3F));
    }

    private static final List<int[]> WINS = new ArrayList<>();           // the windows (x, y, w, h): they light up at night

    private static void windows(GuiGraphics g, int x, int y, int w, int n, int col) {
        int gap = (w - n * 3) / (n + 1);
        for (int i = 0; i < n; i++) {
            int wx = x + gap + i * (3 + gap);
            R(g, wx, y, 3, 3, col);
            R(g, wx, y, 3, 1, 0xFFFFFFFF);
            WINS.add(new int[]{wx, y, 3, 3});
        }
    }

    private static void door(GuiGraphics g, int x, int y) {
        rr(g, x, y, 4, 5, 1, 0xFF8A5A3A);
        R(g, x + 3, y + 2, 1, 1, 0xFFFFD866);
    }

    private static void tree(GuiGraphics g, int x, int y, int r, int col) {
        rr(g, x - r, y + r - 1, 2 * r + 1, 3, 1, 0x30000000);
        orb(g, x, y, r, col);
    }

    private static void pine(GuiGraphics g, int x, int y) {
        rr(g, x - 4, y + 7, 9, 3, 1, 0x30000000);
        R(g, x, y + 6, 2, 3, 0xFF6A4A2A);
        int[][] tiers = {{11, 6}, {9, 5}, {7, 4}};
        for (int k = 0; k < tiers.length; k++) tri(g, x, y + k * 3, tiers[k][0], tiers[k][1], k % 2 == 0 ? 0xFF2F7A4A : 0xFF3A8A56);
        R(g, x, y, 1, 1, 0xFFB8E8C0);
    }

    private static void bush(GuiGraphics g, int x, int y) {
        rr(g, x - 3, y + 1, 7, 3, 1, 0x28000000);
        orb(g, x, y, 2, 0xFF4FA95A);
    }

    private static void flowerbed(GuiGraphics g, int x, int y, int w, int[] cols) {
        rr(g, x, y, w, 4, 2, 0xFF7A5A3A);
        for (int i = 1; i < w - 1; i += 2) {
            R(g, x + i, y + 1, 1, 1, cols[(i / 2) % cols.length]);
            R(g, x + i + 1, y + 2, 1, 1, cols[(i / 2 + 1) % cols.length]);
        }
    }

    private static void bench(GuiGraphics g, int x, int y) {
        R(g, x, y, 7, 2, 0xFF9A6A3A);
        R(g, x, y + 2, 1, 2, 0xFF5A3A1E);
        R(g, x + 6, y + 2, 1, 2, 0xFF5A3A1E);
    }

    private static void fenceH(GuiGraphics g, int x0, int x1, int y) {
        for (int x = x0; x < x1; x += 3) R(g, x, y - 2, 1, 3, 0xFFF3EAD8);
        R(g, x0, y - 1, x1 - x0, 1, 0xFFE3D5B4);
    }

    private static void fenceV(GuiGraphics g, int x, int y0, int y1) {
        for (int y = y0; y < y1; y += 3) R(g, x, y - 2, 1, 3, 0xFFF3EAD8);
        R(g, x, y0, 1, y1 - y0, 0xFFE3D5B4);
    }

    private static void person(GuiGraphics g, int x, int y, int c) {
        R(g, x, y + 3, 3, 1, 0x30000000);
        R(g, x, y, 2, 3, c);
        R(g, x, y - 1, 2, 1, 0xFFFFE0CC);
    }

    private static void lamp(GuiGraphics g, int x, int y) {
        R(g, x, y, 1, 5, 0xFF5A5470);
        R(g, x - 1, y - 2, 3, 2, 0xFFFFE9A0);
    }

    private static final int[] LAMPS = {36, 55, 114, 55, 190, 55, 262, 55, 24, 74, 100, 74, 214, 74, 276, 74};

    private static final int SAND = 0xFFE3D5B4, EDGE = 0xFFCDBB94;

    private static void road(GuiGraphics g, int x, int y, int w, int h) {
        R(g, x - 1, y - 1, w + 2, h + 2, EDGE);
        R(g, x, y, w, h, SAND);
    }

    // ======================================================================
    //  what never moves
    // ======================================================================
    /** The part of the town that never moves; it is baked once (and again when the night comes or goes). */
    static void still(GuiGraphics g, boolean night) {
        WINS.clear();
        Random rnd = new Random(7);
        // ---- the ground: a soft checker, tufts and flowers (the roads and the houses cover some of them)
        for (int ty = 0; ty < 25; ty++)
            for (int tx = 0; tx < 50; tx++) R(g, tx * 6, ty * 6, 6, 6, (tx + ty) % 2 == 0 ? 0xFF6DB872 : 0xFF67B06C);
        for (int i = 0; i < 170; i++) {
            int x = rnd.nextInt(296), y = rnd.nextInt(146);
            R(g, x, y, 2, 1, 0xFF58A05E);
            R(g, x + 1, y - 1, 1, 1, 0xFF58A05E);
        }
        int[] fl = {0xFFFFFFFF, 0xFFFFD866, 0xFFF58FB8, 0xFFB57BD6, 0xFFFF9A6A};
        for (int i = 0; i < 90; i++) {
            int x = rnd.nextInt(296), y = rnd.nextInt(144), c = fl[rnd.nextInt(fl.length)];
            R(g, x, y, 1, 1, c);
            R(g, x + 2, y + 1, 1, 1, c);
            R(g, x + 1, y + 2, 1, 1, c);
        }
        // ---- the roads: sand with a dark edge, a dashed middle line, zebra crossings
        road(g, 0, 60, 300, 12);
        road(g, 144, 0, 12, MH);
        road(g, 60, 0, 6, 60);
        road(g, 228, 72, 6, MH - 72);
        road(g, 156, 30, 78, 6);
        road(g, 0, 96, 86, 6);
        for (int x = 0; x < W; x += 12) if (x < 126 || x > 172) R(g, x + 2, 65, 6, 1, 0xFFF4EAD0);
        for (int y = 0; y < MH; y += 12) if (y < 46 || y > 86) R(g, 149, y + 2, 1, 6, 0xFFF4EAD0);
        for (int y = 60; y < 72; y += 3) { R(g, 124, y, 9, 2, 0xFFFFFFFF); R(g, 167, y, 9, 2, 0xFFFFFFFF); }
        for (int x = 144; x < 156; x += 3) { R(g, x, 46, 2, 8, 0xFFFFFFFF); R(g, x, 78, 2, 8, 0xFFFFFFFF); }
        for (int i = 0; i < LAMPS.length; i += 2) lamp(g, LAMPS[i], LAMPS[i + 1]);

        // ---- the lake with a beach, lily pads, reeds and a pier (fishing)
        disc(g, 268, 30, 24, 0xFFEBDDB0);
        disc(g, 268, 30, 21, 0xFF5BB5E8);
        disc(g, 264, 24, 12, alpha(0xFFFFFF, 0x22));
        int[][] pads = {{252, 18}, {282, 38}, {274, 42}, {255, 38}};
        for (int[] p : pads) { disc(g, p[0], p[1], 2, 0xFF3F9A4A); R(g, p[0], p[1] - 1, 1, 1, 0xFFF58FB8); }
        for (int x = 250; x < 288; x += 7) { R(g, x, 51, 1, 3, 0xFF4F9A58); R(g, x + 1, 52, 1, 2, 0xFF4F9A58); }
        R(g, 234, 30, 24, 4, 0xFF9A6A3A);
        R(g, 234, 30, 24, 1, 0xFFB88A5A);
        person(g, 252, 27, 0xFFE5484D);
        R(g, 255, 28, 1, 5, 0xFFD8D0EE);

        // ---- the park: a lawn with winding paths, a fountain, benches, flowers and blossom trees
        rr(g, 6, 6, 48, 46, 6, 0xFF57A35F);
        rr(g, 14, 38, 38, 4, 2, SAND);
        rr(g, 24, 22, 4, 18, 2, SAND);
        rr(g, 12, 20, 16, 4, 2, SAND);
        disc(g, 33, 26, 8, 0xFFD8D0EE);
        disc(g, 33, 26, 6, 0xFF5BB5E8);
        int[][] blossom = {{16, 14}, {41, 14}, {46, 36}, {14, 46}};
        for (int[] t : blossom) tree(g, t[0], t[1], 4, 0xFFF3A6C8);
        tree(g, 22, 12, 3, 0xFF3F9A4A);
        tree(g, 11, 32, 3, 0xFF3F9A4A);
        bench(g, 16, 31);
        bench(g, 36, 33);
        flowerbed(g, 38, 44, 12, new int[]{0xFFFF9A6A, 0xFFFFD866, 0xFFF58FB8});
        person(g, 28, 34, 0xFF6AA8F0);
        bush(g, 48, 20);

        // ---- home: a roof with a chimney, a fenced garden with flowers, a path and a mailbox
        fenceH(g, 70, 104, 58);
        fenceV(g, 70, 28, 58);
        fenceV(g, 104, 28, 58);
        roof(g, 72, 24, 30, 22, 0xFFE5707A, true);
        R(g, 92, 20, 4, 6, 0xFF8A5A3A);
        windows(g, 72, 31, 14, 2, 0xFFFFE9A0);
        windows(g, 88, 31, 14, 2, 0xFFFFE9A0);
        door(g, 85, 41);
        rr(g, 85, 46, 4, 12, 1, SAND);
        flowerbed(g, 73, 49, 10, new int[]{0xFFF58FB8, 0xFFFFFFFF});
        flowerbed(g, 91, 49, 10, new int[]{0xFFFFD866, 0xFFF58FB8});
        R(g, 98, 51, 2, 3, 0xFF5A5470);
        R(g, 97, 50, 4, 2, 0xFFE5484D);

        // ---- the stage: a purple roof with curtains, an audience on the lawn
        roof(g, 106, 6, 34, 16, 0xFFB57BD6, true);
        rr(g, 111, 10, 24, 8, 2, 0xFFE5484D);
        R(g, 122, 10, 1, 8, 0xFFA83A3A);
        rr(g, 106, 26, 34, 18, 3, 0xFF5FAD66);
        int[] crowd = {0xFF6AA8F0, 0xFFF58FB8, 0xFFFFD866, 0xFF5BBF6A, 0xFFE5484D, 0xFFB57BD6, 0xFFF0B050};
        for (int i = 0; i < crowd.length; i++) person(g, 110 + (i % 4) * 8, 29 + (i / 4) * 6, crowd[i]);

        // ---- the school: windows, a door, a flag pole, a playground with swings, a slide and a sandbox
        roof(g, 168, 4, 42, 16, 0xFF5B8FD8, true);
        windows(g, 168, 12, 42, 4, 0xFFBFE6F8);
        door(g, 187, 15);
        rr(g, 187, 20, 4, 10, 1, SAND);
        R(g, 206, 0, 1, 12, 0xFFEFE8D8);
        rr(g, 214, 6, 18, 16, 3, 0xFFE9D8A8);
        R(g, 216, 9, 1, 7, 0xFF8A5A3A);
        R(g, 223, 9, 1, 7, 0xFF8A5A3A);
        R(g, 216, 9, 8, 1, 0xFF8A5A3A);
        R(g, 218, 10, 1, 4, 0xFFE5484D);
        R(g, 221, 10, 1, 4, 0xFF2F7FD6);
        R(g, 218, 14, 2, 1, 0xFFFFD866);
        R(g, 221, 14, 2, 1, 0xFFFFD866);
        rr(g, 217, 17, 6, 3, 1, 0xFFF0B050);
        person(g, 196, 24, 0xFFFFD866);
        person(g, 202, 25, 0xFFF58FB8);

        // ---- two shops with striped awnings: the boutique (pink) and the pantry (orange)
        roof(g, 166, 46, 24, 12, 0xFFF58FB8, true);
        roof(g, 202, 46, 24, 12, 0xFFF0B050, true);
        for (int k = 0; k < 24; k += 4) {
            R(g, 166 + k, 54, 2, 4, 0xFFE5484D);
            R(g, 166 + k + 2, 54, 2, 4, 0xFFFFFFFF);
            R(g, 202 + k, 54, 2, 4, 0xFF2F7FD6);
            R(g, 202 + k + 2, 54, 2, 4, 0xFFFFFFFF);
        }
        windows(g, 166, 49, 24, 2, 0xFFFFE9A0);
        windows(g, 202, 49, 24, 2, 0xFFFFE9A0);
        rr(g, 194, 54, 5, 4, 1, 0xFF9A6A3A);
        rr(g, 228, 54, 5, 4, 1, 0xFFE8A04A);

        // ---- the farm: fenced fields with crops, a red barn with a silo, haystacks, a tractor and a scarecrow
        for (int row = 0; row < 4; row++) {
            int fy = row < 2 ? 76 + row * 10 : 106 + (row - 2) * 10;
            for (int c = 0; c < 2; c++) {
                int fx = 6 + c * 24;
                rr(g, fx, fy, 22, 9, 2, 0xFF9A6A44);
                boolean greens = (row + c) % 2 == 0;
                for (int k = 0; k < 20; k += 3) {
                    R(g, fx + 2 + k, fy + 2, 2, 5, greens ? 0xFF5BBF6A : 0xFFF3D46A);
                    R(g, fx + 2 + k, fy + 2, 2, 1, greens ? 0xFFB8E8C0 : 0xFFFFF0A0);
                }
            }
        }
        fenceH(g, 4, 56, 95);
        fenceH(g, 4, 56, 105);
        roof(g, 58, 76, 16, 12, 0xFFD6524E, false);
        R(g, 62, 80, 8, 1, 0xFFFFFFFF);
        rr(g, 76, 74, 7, 14, 3, 0xFFB8BCD0);
        orb(g, 62, 98, 3, 0xFFE8C860);
        orb(g, 69, 98, 3, 0xFFE8C860);
        rr(g, 60, 108, 13, 6, 2, 0xFFE5484D);
        R(g, 67, 106, 4, 3, 0xFFBFE6F8);
        disc(g, 62, 115, 2, 0xFF3A2A3A);
        disc(g, 70, 115, 2, 0xFF3A2A3A);
        R(g, 31, 119, 1, 6, 0xFF8A5A3A);
        R(g, 29, 120, 5, 1, 0xFF8A5A3A);
        R(g, 30, 118, 3, 2, 0xFFF3D46A);

        // ---- the centre: a paved plaza with towers (their roofs have windows), a fountain, planters
        rr(g, 84, 76, 58, 56, 4, 0xFFD8D0C0);
        int[][] towers = {{88, 80, 14, 14, 0xFF8A93B8}, {104, 78, 12, 20, 0xFF9AA3C8}, {120, 82, 16, 12, 0xFF7C86AE}, {88, 106, 12, 18, 0xFFA8B0D0}, {120, 108, 16, 14, 0xFF8A93B8}};
        for (int[] t : towers) {
            rr(g, t[0] + 3, t[1] + 4, t[2], t[3], 2, 0x48000000);
            rr(g, t[0], t[1], t[2], t[3], 2, shade(t[4], 0.3F));
            rr(g, t[0], t[1], t[2], t[3] - 1, 2, t[4]);
            R(g, t[0] + 2, t[1] + 2, t[2] - 4, 1, light(t[4], 0.5F));
            for (int y = t[1] + 5; y < t[1] + t[3] - 3; y += 4)
                for (int x = t[0] + 2; x < t[0] + t[2] - 3; x += 4) {
                    boolean warm = (x + y) % 3 == 0;
                    R(g, x, y, 2, 2, warm ? 0xFFFFE9A0 : 0xFFE6E9F5);
                    WINS.add(new int[]{x, y, 2, 2});
                }
            R(g, t[0] + t[2] - 5, t[1] + 2, 3, 2, shade(t[4], 0.25F));
        }
        disc(g, 110, 112, 7, 0xFFEFE8D8);
        disc(g, 110, 112, 5, 0xFF5BB5E8);
        tree(g, 100, 108, 3, 0xFF4FA95A);
        tree(g, 138, 104, 3, 0xFF4FA95A);

        // ---- the balloon field: grass, a launch circle, a ticket hut, a basket and a tether post
        rr(g, 238, 76, 54, 46, 6, 0xFF7FC47E);
        disc(g, 268, 106, 13, 0xFFEAD9AE);
        disc(g, 268, 106, 11, 0xFFE0CC9A);
        roof(g, 241, 80, 14, 10, 0xFF8A93B8, false);
        R(g, 243, 83, 10, 1, 0xFFE6E9F5);
        door(g, 246, 87);
        rr(g, 264, 108, 8, 6, 2, 0xFF9A6A3A);
        R(g, 265, 108, 6, 1, 0xFFB88A5A);
        R(g, 284, 98, 2, 8, 0xFF5A5470);
        orb(g, 285, 97, 2, 0xFFE5484D);

        // ---- the pine forest with mushrooms and rocks
        int[][] pines = {{166, 90}, {176, 86}, {186, 92}, {196, 88}, {170, 102}, {181, 100}, {192, 104}, {202, 98}, {174, 114}, {186, 116}, {198, 114}, {208, 108}, {162, 120}, {212, 122}};
        for (int[] p : pines) pine(g, p[0], p[1]);
        R(g, 180, 112, 2, 2, 0xFFE5484D);
        R(g, 180, 114, 1, 1, 0xFFF3EAD8);
        R(g, 196, 102, 2, 2, 0xFFE5484D);
        R(g, 196, 104, 1, 1, 0xFFF3EAD8);
        rr(g, 164, 126, 6, 4, 2, 0xFF8A8AA0);
        R(g, 165, 126, 3, 1, 0xFFB8B8CC);
        rr(g, 210, 128, 6, 4, 2, 0xFF8A8AA0);
        R(g, 211, 128, 3, 1, 0xFFB8B8CC);

        // ---- trees, bushes and flowers around, so that no corner is empty
        int[][] trees = {{54, 56, 0xFF3F9A4A}, {112, 46, 0xFFF3A6C8}, {222, 52, 0xFF3F9A4A}, {288, 62, 0xFF4FA95A}, {110, 126, 0xFFE8A04A}, {144, 128, 0xFF3F9A4A}, {298, 128, 0xFFF3A6C8}, {236, 128, 0xFF3F9A4A}};
        for (int[] t : trees) tree(g, t[0], t[1], 3, t[2]);
        int[][] bushes = {{60, 8}, {96, 8}, {126, 48}, {184, 46}, {296, 76}, {98, 56}, {150, 126}, {240, 124}, {290, 124}, {6, 70}};
        for (int[] b : bushes) bush(g, b[0], b[1]);
        int[] petals = {0xFFFF9A6A, 0xFFFFD866, 0xFFF58FB8, 0xFFB57BD6};
        flowerbed(g, 176, 18, 10, petals);
        flowerbed(g, 156, 40, 12, petals);
        flowerbed(g, 148, 106, 8, petals);
        flowerbed(g, 236, 124, 12, petals);
        person(g, 120, 69, 0xFFF58FB8);
        person(g, 176, 53, 0xFF6AA8F0);
    }

    // ======================================================================
    //  what moves, and the night
    // ======================================================================
    private static final int[] CAR_COL = {0xFFE5484D, 0xFF2F7FD6, 0xFFFFD866, 0xFF5BBF6A};

    private static void carH(GuiGraphics g, int x, int y, int col, boolean right) {
        rr(g, x, y + 4, 9, 2, 1, 0x30000000);
        rr(g, x, y, 9, 5, 2, shade(col, 0.3F));
        rr(g, x, y, 9, 4, 2, col);
        R(g, x + (right ? 5 : 1), y + 1, 3, 2, 0xFFBFE6F8);
        R(g, x + (right ? 8 : 0), y + 1, 1, 1, 0xFFFFF3B0);
    }

    private static void carV(GuiGraphics g, int x, int y, int col, boolean down) {
        rr(g, x, y, 5, 9, 2, shade(col, 0.3F));
        rr(g, x, y, 5, 8, 2, col);
        R(g, x + 1, y + (down ? 5 : 1), 3, 3, 0xFFBFE6F8);
    }

    /** The part that moves, and the night. {@code hover} is the place under the pointer (a glow around it), or -1. */
    static void live(GuiGraphics g, int ticks, boolean night, int hover) {
        // cars on the main street (two lanes) and on the avenue
        int a = Math.floorMod(ticks * 3 / 5 + 30, 330) - 20, b = 300 - Math.floorMod(ticks * 2 / 3 + 200, 330);
        carH(g, a, 62, CAR_COL[0], true);
        carH(g, b, 67, CAR_COL[1], false);
        carV(g, 146, Math.floorMod(ticks / 2 + 10, 160) - 20, CAR_COL[2], true);
        carV(g, 151, 130 - Math.floorMod(ticks * 2 / 5 + 60, 160), CAR_COL[3], false);
        // people walking: in the park, on the street, on the plaza, by the school
        int w = Math.floorMod(ticks / 4, 60);
        person(g, 16 + (w < 30 ? w : 60 - w), 39 + (ticks / 6 % 2), 0xFFF0B050);
        person(g, 130 + (w < 30 ? w : 60 - w), 100 + (ticks / 6 % 2), 0xFFE5484D);
        person(g, 92 + (w < 30 ? w : 60 - w) / 2, 74 + (ticks / 6 % 2), 0xFF5BBF6A);
        person(g, 120 + (w < 30 ? w : 60 - w) / 2, 124 + (ticks / 6 % 2), 0xFFB57BD6);
        // the fountains: a little jet and sparkles on the water
        int jet = 2 + (ticks / 4) % 3;
        R(g, 33, 26 - jet, 1, jet, 0xFFFFFFFF);
        R(g, 110, 112 - jet, 1, jet, 0xFFFFFFFF);
        for (int i = 0; i < 6; i++) {
            int sx = 256 + (i * 13 + ticks / 5) % 22, sy = 18 + (i * 7) % 24;
            if ((ticks / 6 + i) % 3 == 0) R(g, sx, sy, 2, 1, alpha(0xFFFFFF, 0xB0));
        }
        // the boat and the ducks on the lake
        int bx = 262 + Math.round((float) Math.sin(ticks / 40.0) * 6), by = 24 + Math.round((float) Math.cos(ticks / 55.0) * 2);
        rr(g, bx, by, 9, 3, 1, 0xFF9A6A3A);
        R(g, bx + 4, by - 6, 1, 6, 0xFFF3EAD8);
        tri(g, bx + 6, by - 6, 5, 6, 0xFFFFFFFF);
        for (int d = 0; d < 2; d++) {
            int dx = 272 + d * 5 + Math.round((float) Math.sin(ticks / 30.0 + d) * 3), dy = 35 + d * 2 + (ticks / 10 + d) % 2;
            rr(g, dx, dy, 4, 3, 1, 0xFFFFD866);
            R(g, dx - 1, dy + 1, 1, 1, 0xFFFF9A3A);
        }
        // the smoke of the chimney, the flags, the string lights of the stage
        for (int k = 0; k < 3; k++) {
            int t = (ticks + k * 16) % 48;
            disc(g, 94 + t / 12, 17 - t / 4, 1 + k, alpha(0xFFFFFF, 0x80 - t));
        }
        int wave = (ticks / 8) % 2;
        R(g, 207, 0, 6, 3, 0xFFE5484D);
        R(g, 213, 1 + wave, 2, 2, 0xFFE5484D);
        for (int x = 108; x < 138; x += 4) R(g, x, 4, 2, 2, ((ticks / 10 + x / 4) % 3 == 0) ? 0xFFFFFFFF : new int[]{0xFFFFD866, 0xFFF58FB8, 0xFF6AA8F0}[(x / 4) % 3]);
        // the balloon bobs over its launch circle
        int bob = Math.round((float) Math.sin(ticks / 22.0) * 3);
        balloon(g, 270, 90 + bob, 268, 108);
        // the place under the pointer glows
        int[] bx2 = hover >= 0 ? box(hover) : null;
        if (bx2 != null) for (int i = 3; i >= 1; i--) rr(g, bx2[0] - i, bx2[1] - i, bx2[2] + 2 * i, bx2[3] + 2 * i, 5 + i, alpha(0xB57BD6, 0x40 / i));
        if (night) {
            g.fill(0, OY, W, H, 0x78101840);
            for (int i = 0; i < LAMPS.length; i += 2) disc(g, LAMPS[i], LAMPS[i + 1] - 1, 9, 0x24FFE9A0);
            for (int[] win : WINS) R(g, win[0] - 1, win[1] - 1, win[2] + 2, win[3] + 2, 0x60FFE080);
            for (int[] win : WINS) R(g, win[0], win[1], win[2], win[3], 0xFFFFE9A0);
        }
    }

    /** A striped hot-air balloon with ropes down to its basket on the launch circle. */
    private static void balloon(GuiGraphics g, int cx, int cy, int bx, int by) {
        int[] stripe = {0xFFE5484D, 0xFFFFFFFF, 0xFF2F7FD6, 0xFFFFFFFF, 0xFFFFD866};
        int r = 11;
        ell(g, cx + 1, 107, 8, 2, 0x20000000);                       // the shadow stays near the ground
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) ((r + 0.5) * Math.sqrt(Math.max(0.0, 1.0 - (dy * dy) / ((r + 0.5) * (r + 0.5)))));
            int x0 = cx - dx, wFull = 2 * dx + 1;
            for (int s = 0; s < stripe.length; s++) {
                int sx0 = x0 + wFull * s / stripe.length, sx1 = x0 + wFull * (s + 1) / stripe.length;
                int c = dy > r - 4 ? shade(stripe[s], 0.2F) : stripe[s];
                R(g, sx0, cy + dy, sx1 - sx0, 1, c);
            }
            R(g, x0, cy + dy, 1, 1, shade(0xFF8A5A3A, 0.1F));                           // a darker rim
            R(g, x0 + wFull - 1, cy + dy, 1, 1, shade(0xFFB0A0A0, 0.4F));
        }
        disc(g, cx - 5, cy - 6, 4, alpha(0xFFFFFF, 0x50));                              // a highlight on the lit side
        R(g, cx - 3, cy + r + 1, 6, 2, 0xFF8A5A3A);                                     // the burner
        R(g, cx - 4, cy + r, 1, by - cy - r, 0xB0F3EAD8);                               // ropes down to the basket
        R(g, cx + 4, cy + r, 1, by - cy - r, 0xB0F3EAD8);
    }

    /** The picture of the town: the part that never moves (from the baked {@code stillPx} if there is one) and what moves on top of it. */
    static void draw(GuiGraphics g, int ticks, boolean night, int hover, int[] stillPx) {
        boolean baked = stillPx != null && g instanceof SoftCanvas sc && sc.loadStill(stillPx);
        if (!baked) still(g, night);
        live(g, ticks, night, hover);
    }
}
