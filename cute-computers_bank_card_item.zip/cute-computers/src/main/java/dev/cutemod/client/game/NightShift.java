package dev.cutemod.client.game;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * Night Shift: a horror game in the spirit of the night-guard classics. You work the night shift (12 AM to 6 AM) in a toy shop
 * where the plush toys wake up. Six nights, twelve cameras and eight toys:
 * <ul>
 * <li>Momo the bunny walks the west side, Mimi the cat the east side (through the kitchen, you can only hear her), Bruno the bear
 * moves only while no camera looks at him;</li>
 * <li>Pip the fox sleeps behind the curtain of the puppet cove and sprints down the west hall when he is left alone too long;</li>
 * <li>Lulu the doll sleeps in the music box as long as you keep winding it;</li>
 * <li>a golden bear sits on the desk if you stare at the wrong poster: put the monitor up and he is gone;</li>
 * <li>Bobo the balloon boy slips under the east door (doors do not stop him) and kills your lights until you squeak the rubber duck;</li>
 * <li>Webby the spider doll crawls through the air vent towards the hatch in your wall: watch the vent camera and seal the hatch.</li>
 * </ul>
 * Every door, light, camera and the hatch drains the power, and when it is gone Bruno comes humming out of the dark. After the six nights
 * the Custom Night opens: set the restlessness of every toy from 0 to 20.
 *
 * <p>Controls: mouse, or A / D = doors (cycle cameras while the monitor is up), Q / E = lights, Space = cameras, 1-9 / 0 / - / = a camera,
 * W = wind the box, V = the vent hatch, F = squeak the duck, M = mute the phone call. The night you reached is remembered (Continue).
 */
public class NightShift extends MiniGame {
    private static final int M_CARD = 0, M_PLAY = 1, M_DAWN = 2, M_SCARE = 3, M_MENU = 4, M_CUSTOM = 5;
    // the places (the first twelve are cameras)
    private static final int STAGE = 0, DINING = 1, PLAYRM = 2, COVE = 3, WHALL = 4, WCORNER = 5, EHALL = 6, ECORNER = 7, STORE = 8,
            KITCHEN = 9, MUSIC = 10, VENT = 11, DOOR_W = 20, DOOR_E = 21;
    private static final int NCAMS = 12, NIGHTS = 6, HOURS = 6, HOUR_TICKS = 2700;
    // the toys by level: 0 bunny, 1 cat, 2 bear, 3 fox, 4 doll, 5 golden bear, 6 Bobo, 7 Webby
    private static final int L_FOX = 3, L_DOLL = 4, L_GHOST = 5, L_BOBO = 6, L_WEB = 7;
    /** How restless each toy is on each of the six nights (0 = it sleeps). */
    private static final int[][] LEVELS = {
            {3, 5, 7, 9, 12, 16}, {0, 3, 5, 7, 10, 14}, {0, 0, 2, 4, 6, 10}, {0, 2, 4, 6, 9, 14},
            {5, 6, 7, 8, 9, 11}, {0, 0, 3, 5, 7, 10}, {0, 0, 3, 5, 8, 11}, {0, 0, 0, 4, 6, 9}};
    private static final int[] BASE_INT = {298, 299, 181};
    /** How many nights of power one battery lasts when only the base load is on. */
    private static final float[] POWER_F = {2.9F, 2.8F, 2.7F, 2.6F, 2.55F, 2.5F};
    private static final int[] CALL_LINES = {3, 3, 4, 4, 3, 1};
    private static final int[] TUNE = {0, 3, 7, 3, 5, 2, 0, -2, 0, 3, 7, 10, 8, 7, 3, 0};
    private static final int CARD_TICKS = 190;
    private static final Path SAVE = Path.of("config", "cutecomputers_nightshift.txt");

    private int mode, t, night, nightT, hour, saved;
    private boolean custom;
    private final int[] cl = {5, 5, 5, 5, 5, 5, 5, 5};
    private final int[] pos = new int[3];
    private final int[] moveT = new int[3], doorT = new int[3];
    private final boolean[] seen = new boolean[3];
    private boolean doorW, doorE, lightW, lightE, cam, winding, win, darkDeath, powerOut, muted, hatch;
    private int keyLightW, keyLightE, camSel, glitchT, flick, noteI, noteT, heartT, knockT, scareWho, emptyT, outT, callT;
    private int foxStage, foxT, foxFreeze, foxRun, foxHits;
    private boolean ghostPoster, ghostOut;
    private int ghostT, ghostStare;
    private int boboPos, boboMoveT, boboT, boboStay, squeaks, squeakCd, duckAnim;
    private boolean boboIn;
    private int webPos, webT, webHatchT, webKnock;
    private float doorWA, doorEA, camA;
    private double power, wind;

    // ================================================================== life cycle
    @Override
    public void reset() {
        score = 0; over = false; win = false; darkDeath = false; custom = false;
        night = 0; mode = M_MENU; t = 0; scareWho = 0;
        saved = loadSaved();
        initNight();
    }

    private static int loadSaved() {
        try { return Math.max(0, Math.min(NIGHTS, Integer.parseInt(Files.readString(SAVE).trim()))); } catch (Exception e) { return 0; }
    }

    private static void store(int n) {
        try { Files.createDirectories(SAVE.getParent()); Files.writeString(SAVE, Integer.toString(n)); } catch (Exception e) { /* no save, no problem */ }
    }

    private int lv(int toy) { return custom ? cl[toy] : LEVELS[toy][night]; }

    private void initNight() {
        nightT = 0; hour = 0; power = 100; wind = 100; emptyT = 0; powerOut = false; outT = 0; callT = 0; muted = false;
        doorW = false; doorE = false; lightW = false; lightE = false; keyLightW = 0; keyLightE = 0; hatch = false;
        cam = false; camSel = 0; camA = 0; doorWA = 0; doorEA = 0; winding = false;
        for (int i = 0; i < 3; i++) { pos[i] = STAGE; moveT[i] = BASE_INT[i] + rnd.nextInt(240); doorT[i] = 0; seen[i] = false; }
        foxStage = 0; foxT = 300; foxFreeze = 0; foxRun = 0; foxHits = 0;
        ghostPoster = false; ghostOut = false; ghostT = 0; ghostStare = 0;
        boboPos = PLAYRM; boboMoveT = 500 + rnd.nextInt(200); boboT = 0; boboIn = false; boboStay = 0; squeaks = 0; squeakCd = 0; duckAnim = 0;
        webPos = 0; webT = 500 + rnd.nextInt(200); webHatchT = 0; webKnock = 0;
        glitchT = 0; flick = 0; noteI = 0; noteT = 30; heartT = 0; knockT = 0;
    }

    @Override
    public String hintKey() { return "cutemod.hint.night"; }

    @Override
    public String musicId() { return mode == M_MENU ? "deep" : mode == M_CUSTOM ? "ward" : mode == M_PLAY && powerOut ? "hell" : null; }

    @Override
    public Component status() { return Component.translatable(custom ? "cutemod.night.status.custom" : "cutemod.night.status", night + 1, (int) Math.ceil(power)); }

    @Override
    public boolean isWin() { return win; }

    @Override
    public Component endTitle() {
        if (win) return Component.translatable("cutemod.night.end.win");
        return Component.translatable(darkDeath ? "cutemod.night.end.dark" : "cutemod.night.end." + scareWho);
    }

    private static String str(String key, Object... a) { return Component.translatable(key, a).getString(); }

    private String hourStr() { return str("cutemod.night.h." + Math.min(hour, 6)); }

    private boolean lightWOn() { return !powerOut && !cam && !boboIn && (lightW || keyLightW > 0); }

    private boolean lightEOn() { return !powerOut && !cam && !boboIn && (lightE || keyLightE > 0); }

    private int usage() {
        if (powerOut) return 0;
        return 1 + (doorW ? 1 : 0) + (doorE ? 1 : 0) + (lightWOn() ? 1 : 0) + (lightEOn() ? 1 : 0) + (cam ? 1 : 0) + (hatch ? 1 : 0);
    }

    private static void thud(float pitch, float vol) { sound(SoundEvents.NOTE_BLOCK_BASEDRUM, pitch, vol); }

    private void beginNight(int n) { night = n; initNight(); mode = M_CARD; t = 0; }

    private int dollLimit() { return Math.max(300, 960 - 30 * lv(L_DOLL)); }

    // ================================================================== the clock
    @Override
    public void tick() {
        if (over) return;
        t++;
        switch (mode) {
            case M_MENU, M_CUSTOM -> { }
            case M_CARD -> {
                if (t == 8) sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 0.5F);
                if (t >= CARD_TICKS) { mode = M_PLAY; t = 0; sound(SoundEvents.NOTE_BLOCK_BASS, 0.6F, 0.6F); }
            }
            case M_PLAY -> playTick();
            case M_DAWN -> {
                if (t >= 10 && t <= 150 && (t - 10) % 28 == 0) sound(SoundEvents.BELL_BLOCK, 1.0F, 0.9F);
                if (t == 160) sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.2F, 0.8F);
                if (t >= 240) {
                    if (custom) { win = true; score += 3 * levelSum(); over = true; return; }
                    if (night + 1 >= NIGHTS) { win = true; score += 80; saved = NIGHTS; store(saved); over = true; return; }
                    beginNight(night + 1);
                }
            }
            default -> { if (t == 70) over = true; }
        }
    }

    private int levelSum() { int s = 0; for (int v : cl) s += v; return s; }

    private void playTick() {
        nightT++;
        camA = cam ? Math.min(1f, camA + 0.2f) : Math.max(0f, camA - 0.2f);
        doorWA += ((doorW ? 1f : 0f) - doorWA) * 0.3f; if (Math.abs((doorW ? 1f : 0f) - doorWA) < 0.02f) doorWA = doorW ? 1f : 0f;
        doorEA += ((doorE ? 1f : 0f) - doorEA) * 0.3f; if (Math.abs((doorE ? 1f : 0f) - doorEA) < 0.02f) doorEA = doorE ? 1f : 0f;
        if (glitchT > 0) glitchT--;
        if (squeakCd > 0) squeakCd--;
        if (duckAnim > 0) duckAnim--;
        if (keyLightW > 0) keyLightW--;
        if (keyLightE > 0) keyLightE--;
        if (flick > 0) flick--; else if (rnd.nextInt(900) == 0) flick = 4 + rnd.nextInt(6);
        callT++;
        if (!custom && !muted && callT < 70 && callT % 12 == 8) sound(SoundEvents.NOTE_BLOCK_BELL, (callT / 12) % 2 == 0 ? 1.9F : 1.5F, 0.35F);

        int h = nightT / HOUR_TICKS;
        if (h != hour) {
            hour = h;
            if (hour >= HOURS) { dawn(); return; }
            score += 2;
            sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.7F, 0.45F);
        }

        if (powerOut) { outTick(); return; }

        power -= usage() * 100.0 / (POWER_F[custom ? NIGHTS - 1 : night] * HOURS * HOUR_TICKS);
        if (power <= 0) { power = 0; goPowerOut(); return; }
        if ((lightWOn() || lightEOn()) && nightT % 14 == 0) sound(SoundEvents.NOTE_BLOCK_BASS, 0.55F, 0.12F);

        // the music box
        int dl = lv(L_DOLL);
        if (dl > 0) {
            wind = Math.max(0, wind - (0.0036 * dl + 0.004));
            if (winding && cam && camSel == MUSIC) wind = Math.min(100, wind + 0.75);
            if (wind > 0) {
                emptyT = 0;
                if (--noteT <= 0) {
                    noteT = 16 + (int) ((100 - wind) * 0.3);
                    float p = (float) Math.pow(2, TUNE[noteI++ % TUNE.length] / 12.0);
                    sound(SoundEvents.NOTE_BLOCK_BELL, p, cam && camSel == MUSIC ? 0.55F : 0.16F);
                }
            } else {
                if (++emptyT == 1) sound(SoundEvents.NOTE_BLOCK_BASS, 0.5F, 0.8F);
                if (emptyT > 160 && emptyT % 70 == 0) sound(SoundEvents.PHANTOM_AMBIENT, 0.6F, 0.35F);
                if (emptyT >= dollLimit()) { scare(3); return; }
            }
        }

        // the walkers
        boolean threat = false, knock = false;
        for (int i = 0; i < 3; i++) {
            int lvl = lv(i);
            if (lvl == 0) continue;
            if (pos[i] == DOOR_W || pos[i] == DOOR_E) {
                boolean west = pos[i] == DOOR_W;
                boolean closed = west ? doorW : doorE;
                boolean lit = west ? lightWOn() : lightEOn();
                if (lit && !seen[i]) { seen[i] = true; sound(SoundEvents.ENDERMAN_STARE, 0.6F, 0.5F); }
                if (closed) knock = true; else threat = true;
                if (--doorT[i] <= 0) {
                    if (closed) {                                         // it bangs on the door and goes away
                        sound(SoundEvents.SHIELD_BLOCK, 0.5F, 0.9F);
                        pos[i] = west ? WHALL : EHALL; seen[i] = false; moveT[i] = BASE_INT[i] + 120; glitchT = 8;
                    } else { scare(i); return; }
                }
            } else {
                if (i == 2 && cam && camSel == pos[i]) continue;                         // the bear freezes while a camera looks at him
                if (--moveT[i] <= 0) {
                    moveT[i] = BASE_INT[i] + rnd.nextInt(30);
                    if (rnd.nextInt(20) < lvl) moveToy(i);
                }
            }
        }
        if (threat && ++heartT % 36 == 0) thud(0.5F, 0.7F);
        if (knock && ++knockT % 30 == 0) thud(0.9F, 0.45F);
        // the cat in the kitchen: pots and pans you can hear on the audio camera
        if (pos[1] == KITCHEN && nightT % 70 == 0) sound(SoundEvents.SHIELD_BLOCK, 1.5F + rnd.nextFloat() * 0.4F, cam && camSel == KITCHEN ? 0.7F : 0.2F);
        if (pos[2] == KITCHEN && nightT % 110 == 0) sound(SoundEvents.ENDERMAN_AMBIENT, 0.5F, cam && camSel == KITCHEN ? 0.6F : 0.15F);

        if (!foxTick()) return;
        if (!ghostTick()) return;
        boboTick();
        if (!webTick()) return;
        if (rnd.nextInt(1400) == 0) sound(SoundEvents.ENDERMAN_AMBIENT, 0.5F, 0.25F);
    }

    /** Pip the fox. False if he caught you. */
    private boolean foxTick() {
        int fl = lv(L_FOX);
        if (fl <= 0) return true;
        if (foxStage < 4) {
            if (cam && camSel == COVE) foxFreeze = 300 + rnd.nextInt(600);            // somebody is watching: he waits
            else if (foxFreeze > 0) foxFreeze--;
            else if (--foxT <= 0) {
                foxT = 300;
                if (rnd.nextInt(20) < fl) {
                    foxStage++;
                    if (foxStage >= 4) { foxRun = 0; sound(SoundEvents.GENERIC_EXPLODE, 0.5F, 0.4F); }
                    else sound(SoundEvents.ENDERMAN_AMBIENT, 0.8F, 0.3F);
                    if (cam && camSel == COVE) glitchT = 7;
                }
            }
        } else {
            foxRun++;
            if (foxRun % 7 == 0) sound(SoundEvents.STONE_STEP, 0.6F + foxRun / 300F, 0.3F + foxRun / 300F);
            if (foxRun >= 170) {                                                       // he reaches the west door
                if (doorW) {
                    sound(SoundEvents.SHIELD_BLOCK, 0.5F, 1.0F); thud(0.45F, 0.9F);
                    power = Math.max(0.5, power - (1 + 4 * foxHits));
                    foxHits++; foxStage = 1 + rnd.nextInt(2); foxT = 420; glitchT = 8;
                } else { scare(4); return false; }
            }
        }
        return true;
    }

    /** The golden bear. False if he caught you. */
    private boolean ghostTick() {
        int gl = lv(L_GHOST);
        if (gl <= 0) return true;
        if (!ghostPoster && !ghostOut && ghostT == 0 && rnd.nextInt(Math.max(2500, 15000 - 800 * gl)) == 0) ghostPoster = true;
        if (ghostPoster && cam && camSel == WHALL && camA >= 1f) { ghostPoster = false; ghostT = 240 + rnd.nextInt(420); }     // you looked at the poster
        if (ghostT > 0 && !cam && --ghostT == 0) { ghostOut = true; ghostStare = 0; sound(SoundEvents.ENDERMAN_STARE, 0.4F, 0.9F); }
        if (ghostOut) {
            if (cam) { ghostOut = false; sound(SoundEvents.NOTE_BLOCK_BASS, 0.5F, 0.5F); }
            else {
                if (++ghostStare % 50 == 0) sound(SoundEvents.PHANTOM_AMBIENT, 0.55F, 0.8F);
                if (ghostStare >= 360) { scare(5); return false; }
            }
        }
        return true;
    }

    /** Bobo: walks to the east corner and slips under the door; in the office he kills the lights. The duck sends him away. */
    private void boboTick() {
        int bl = lv(L_BOBO);
        if (bl <= 0) return;
        if (boboIn) {
            if (nightT % 90 == 30) sound(SoundEvents.NOTE_BLOCK_BELL, 1.8F, 0.45F);                  // his giggle
            if (++boboStay >= 1500) boboLeave();
        } else if (boboPos == ECORNER) {
            if (nightT % 75 == 0) sound(SoundEvents.NOTE_BLOCK_BELL, 1.6F, 0.2F);                    // the propeller
            if (--boboT <= 0) {
                boboIn = true; boboStay = 0; squeaks = 0; boboPos = -1;
                lightW = false; lightE = false; keyLightW = 0; keyLightE = 0;
                sound(SoundEvents.NOTE_BLOCK_BELL, 2.0F, 0.6F); sound(SoundEvents.ENDERMAN_STARE, 0.7F, 0.3F);
            }
        } else if (--boboMoveT <= 0) {
            boboMoveT = 360 + rnd.nextInt(60);
            if (rnd.nextInt(20) < bl) {
                int p = boboPos, np = nextBobo(p, rnd.nextFloat());
                if (cam && (camSel == p || camSel == np)) glitchT = 7;
                boboPos = np;
                if (np == ECORNER) { boboT = Math.max(240, 480 + rnd.nextInt(240) - 25 * night); squeaks = 0; }
                sound(SoundEvents.STONE_STEP, 1.4F, 0.2F);
            }
        }
    }

    private void boboLeave() {
        boboIn = false; boboPos = EHALL; boboMoveT = 600; squeaks = 0;
        sound(SoundEvents.NOTE_BLOCK_BELL, 1.2F, 0.4F);
    }

    /** Webby: crawls through the vent to the hatch, but only while no one is looking. False if she caught you. */
    private boolean webTick() {
        int wl = lv(L_WEB);
        if (wl <= 0) return true;
        if (webPos < 3) {
            boolean watched = cam && camSel == VENT;
            if (!watched && --webT <= 0) {
                webT = 420;
                if (rnd.nextInt(20) < wl) {
                    webPos++;
                    sound(SoundEvents.STONE_STEP, 1.8F, 0.25F + 0.2F * webPos);
                    if (webPos == 3) webHatchT = Math.max(150, 300 + rnd.nextInt(180) - 15 * night);
                }
            }
        } else {
            if (hatch) { if (++webKnock % 40 == 0) { thud(1.1F, 0.5F); sound(SoundEvents.SHIELD_BLOCK, 1.6F, 0.3F); } }
            else if (++webKnock % 25 == 0) sound(SoundEvents.STONE_STEP, 1.9F, 0.5F);
            if (--webHatchT <= 0) {
                if (hatch) {
                    sound(SoundEvents.SHIELD_BLOCK, 0.6F, 1.0F);
                    webPos = 1; webT = 600; glitchT = 8; webKnock = 0;
                } else { scare(7); return false; }
            }
        }
        return true;
    }

    private static int nextBobo(int p, float f) {
        return switch (p) {
            case PLAYRM -> f < 0.4F ? DINING : f < 0.7F ? STORE : KITCHEN;
            case DINING -> f < 0.5F ? PLAYRM : KITCHEN;
            case KITCHEN -> f < 0.7F ? EHALL : DINING;
            case STORE -> f < 0.6F ? EHALL : PLAYRM;
            case EHALL -> f < 0.6F ? ECORNER : KITCHEN;
            default -> PLAYRM;
        };
    }

    private static int nextBunny(int p, float f) {
        return switch (p) {
            case STAGE -> DINING;
            case DINING -> f < 0.5F ? PLAYRM : f < 0.85F ? WHALL : STORE;
            case PLAYRM -> f < 0.55F ? WHALL : f < 0.85F ? STORE : DINING;
            case STORE -> f < 0.7F ? WHALL : f < 0.9F ? WCORNER : PLAYRM;
            case WHALL -> f < 0.6F ? WCORNER : f < 0.8F ? STORE : PLAYRM;
            case WCORNER -> f < 0.8F ? DOOR_W : WHALL;
            default -> PLAYRM;
        };
    }

    private static int nextCat(int p, float f) {
        return switch (p) {
            case STAGE -> DINING;
            case DINING -> f < 0.55F ? KITCHEN : f < 0.8F ? PLAYRM : EHALL;
            case PLAYRM -> f < 0.5F ? KITCHEN : f < 0.8F ? STORE : DINING;
            case KITCHEN -> f < 0.65F ? EHALL : DINING;
            case STORE -> f < 0.6F ? EHALL : PLAYRM;
            case EHALL -> f < 0.6F ? ECORNER : f < 0.85F ? KITCHEN : STORE;
            case ECORNER -> f < 0.8F ? DOOR_E : EHALL;
            default -> DINING;
        };
    }

    private static int nextBear(int p, float f) {
        return switch (p) {
            case STAGE -> DINING;
            case DINING -> f < 0.5F ? KITCHEN : f < 0.8F ? PLAYRM : EHALL;
            case PLAYRM -> f < 0.5F ? STORE : f < 0.8F ? KITCHEN : DINING;
            case KITCHEN -> f < 0.6F ? EHALL : DINING;
            case STORE -> f < 0.6F ? EHALL : f < 0.8F ? WHALL : PLAYRM;
            case WHALL -> f < 0.5F ? WCORNER : STORE;
            case EHALL -> f < 0.65F ? ECORNER : KITCHEN;
            case WCORNER -> f < 0.75F ? DOOR_W : WHALL;
            case ECORNER -> f < 0.8F ? DOOR_E : EHALL;
            default -> DINING;
        };
    }

    private void moveToy(int i) {
        int p = pos[i];
        float f = rnd.nextFloat();
        int np = i == 0 ? nextBunny(p, f) : i == 1 ? nextCat(p, f) : nextBear(p, f);
        if (cam && (camSel == p || camSel == np)) glitchT = 7;
        pos[i] = np;
        seen[i] = false;
        if (np == DOOR_W || np == DOOR_E) {
            doorT[i] = (i == 2 ? 240 : 300) + rnd.nextInt(180) - 20 * Math.min(night, 5);
            sound(SoundEvents.STONE_STEP, 0.5F, 0.8F);
            thud(0.55F, 0.5F);
        } else {
            boolean near = np == WHALL || np == EHALL || np == WCORNER || np == ECORNER;
            sound(SoundEvents.STONE_STEP, 0.6F + rnd.nextFloat() * 0.2F, near ? 0.45F : 0.25F);
            if (i == 2) sound(SoundEvents.ENDERMAN_AMBIENT, 0.5F, 0.4F);
        }
    }

    private void goPowerOut() {
        powerOut = true; outT = 0; darkDeath = false;
        doorW = false; doorE = false; lightW = false; lightE = false; keyLightW = 0; keyLightE = 0; cam = false; winding = false; ghostOut = false; hatch = false;
        sound(SoundEvents.NOTE_BLOCK_BASS, 0.5F, 1.0F);
        sound(SoundEvents.GENERIC_EXPLODE, 0.5F, 0.15F);
    }

    private void outTick() {
        outT++;
        camA = Math.max(0f, camA - 0.2f);
        doorWA = Math.max(0f, doorWA - 0.2f); doorEA = Math.max(0f, doorEA - 0.2f);
        if (outT >= 150 && outT < 150 + 8 * 30 && (outT - 150) % 30 == 0) {          // the bear hums his tune
            float p = (float) Math.pow(2, TUNE[((outT - 150) / 30) % TUNE.length] / 12.0 - 0.5);
            sound(SoundEvents.NOTE_BLOCK_BELL, Math.max(0.5F, p), 0.7F);
        }
        if (outT > 150 && outT % 45 == 0) thud(0.5F, 0.6F);
        if (outT >= 450) { darkDeath = true; scare(2); }
    }

    private void scare(int who) {
        mode = M_SCARE; t = 0; scareWho = who; cam = false; winding = false;
        growl(G_SCREAM); growl(G_ROAR);
        sound(SoundEvents.GLASS_BREAK, 0.5F, 0.7F);
    }

    private void dawn() {
        mode = M_DAWN; t = 0; cam = false; winding = false;
        score += 20 + (int) (power / 4);
        if (!custom) { saved = Math.max(saved, Math.min(night + 1, NIGHTS - 1)); store(saved); }
    }

    // ================================================================== input
    private void toggleCam() {
        if (powerOut) return;
        cam = !cam; glitchT = 5; winding = false;
        if (cam) { lightW = false; lightE = false; keyLightW = 0; keyLightE = 0; }
        sound(SoundEvents.NOTE_BLOCK_BASS, cam ? 1.4F : 1.0F, 0.4F);
    }

    private void selectCam(int i) {
        camSel = Math.floorMod(i, NCAMS); glitchT = 6; winding = false;
        sound(SoundEvents.NOTE_BLOCK_BASS, 1.6F, 0.25F);
    }

    private void toggleDoor(boolean west) {
        if (powerOut) return;
        boolean now = west ? (doorW = !doorW) : (doorE = !doorE);
        sound(SoundEvents.SHIELD_BLOCK, now ? 0.55F : 0.85F, 0.6F);
    }

    private void toggleHatch() {
        if (powerOut) return;
        hatch = !hatch;
        sound(SoundEvents.SHIELD_BLOCK, hatch ? 0.7F : 1.0F, 0.6F);
    }

    private void lightOn(boolean west) {
        if (boboIn) { sound(SoundEvents.NOTE_BLOCK_BASS, 0.4F, 0.3F); return; }       // the lights are dead while Bobo is here
        if (west) lightW = true; else lightE = true;
    }

    private void squeak() {
        if (powerOut || squeakCd > 0) return;
        squeakCd = 18; duckAnim = 10;
        sound(SoundEvents.NOTE_BLOCK_BELL, 2.0F, 0.8F);
        if (boboIn) { if (++squeaks >= 3) boboLeave(); }
        else if (boboPos == ECORNER && lv(L_BOBO) > 0) { if (++squeaks >= 2) { boboPos = EHALL; boboMoveT = 480; squeaks = 0; if (cam && camSel == ECORNER) glitchT = 7; } }
    }

    /** The map of the cameras (bottom right while the monitor is up): x, y, width, height of camera i. */
    private static int[] cell(int i) {
        int[][] c = {{1, 0, 2}, {1, 1, 2}, {1, 2, 1}, {0, 1, 1}, {0, 2, 1}, {0, 3, 1}, {3, 2, 1}, {3, 3, 1}, {2, 2, 1}, {3, 1, 1}, {0, 0, 1}, {3, 0, 1}};
        return new int[]{141 + c[i][0] * 18, 67 + c[i][1] * 13, c[i][2] * 18 - 1, 12};
    }

    private boolean callShown() {
        if (custom || muted || callT < 150) return false;
        return (callT - 150) / 660 < CALL_LINES[night];
    }

    private void startGame(int from) { custom = false; beginNight(from); }

    private void startCustom() {
        custom = true;
        beginNight(NIGHTS - 1);
        sound(SoundEvents.NOTE_BLOCK_BASS, 0.8F, 0.5F);
    }

    private static int[] customCell(int i) { return new int[]{6 + (i / 4) * 110, 28 + (i % 4) * 21}; }

    private void bump(int i, int d) { cl[i] = Math.floorMod(cl[i] + d, 21); beep(); }

    @Override
    public boolean click(int x, int y, int button) {
        if (mode == M_MENU) {
            if (in(x, y, 56, 78, 108, 15)) { startGame(0); return true; }
            if (saved > 0 && in(x, y, 56, 96, 108, 15)) { startGame(Math.min(saved, NIGHTS - 1)); return true; }
            if (saved >= NIGHTS && in(x, y, 56, 114, 108, 15)) { mode = M_CUSTOM; t = 0; beep(); return true; }
            return true;
        }
        if (mode == M_CUSTOM) {
            for (int i = 0; i < 8; i++) {
                int[] c = customCell(i);
                if (in(x, y, c[0] + 58, c[1], 12, 14)) { bump(i, -1); return true; }
                if (in(x, y, c[0] + 86, c[1], 12, 14)) { bump(i, 1); return true; }
            }
            if (in(x, y, 62, 116, 96, 16)) { startCustom(); return true; }
            if (in(x, y, 6, 116, 50, 16)) { mode = M_MENU; t = 0; beep(); return true; }
            if (in(x, y, 164, 116, 50, 16)) { boolean all = true; for (int v : cl) all &= v == 20; java.util.Arrays.fill(cl, all ? 0 : 20); beep(); return true; }
            return true;
        }
        if (mode == M_CARD) { if (t > 40) t = CARD_TICKS; return true; }
        if (mode != M_PLAY || powerOut) return mode == M_PLAY;
        if (callShown() && in(x, y, 180, 78, 36, 11)) { muted = true; return true; }
        if (in(x, y, 4, 126, 52, 12)) { toggleHatch(); return true; }
        if (cam) {
            for (int i = 0; i < NCAMS; i++) { int[] c = cell(i); if (in(x, y, c[0], c[1], c[2], c[3])) { selectCam(i); return true; } }
            if (in(x, y, 60, 126, 100, 12)) { toggleCam(); return true; }
            if (camSel == MUSIC && in(x, y, 8, 100, 88, 18)) winding = true;
            if (camSel == VENT && in(x, y, 8, 100, 88, 18)) toggleHatch();
            return true;
        }
        if (in(x, y, 60, 126, 100, 12)) { toggleCam(); return true; }
        if (in(x, y, 127, 88, 14, 11)) { squeak(); return true; }
        if (in(x, y, 144, 60, 18, 14)) { toggleHatch(); return true; }
        if (in(x, y, 1, 36, 20, 24)) { toggleDoor(true); return true; }
        if (in(x, y, 1, 62, 20, 24)) { lightOn(true); return true; }
        if (in(x, y, 199, 36, 20, 24)) { toggleDoor(false); return true; }
        if (in(x, y, 199, 62, 20, 24)) { lightOn(false); return true; }
        if (in(x, y, 20, 24, 38, 80)) { toggleDoor(true); return true; }
        if (in(x, y, 164, 24, 38, 80)) { toggleDoor(false); return true; }
        return true;
    }

    @Override
    public boolean release(int x, int y, int button) {
        lightW = false; lightE = false; winding = false;
        return false;
    }

    @Override
    public boolean key(int keyCode) {
        if (mode == M_MENU) {
            if (keyCode == 257 || keyCode == 32) { startGame(saved > 0 ? Math.min(saved, NIGHTS - 1) : 0); return true; }
            return false;
        }
        if (mode == M_CUSTOM) {
            if (keyCode == 257) { startCustom(); return true; }
            return false;
        }
        if (mode == M_CARD) { if (t > 40) t = CARD_TICKS; return true; }
        if (mode != M_PLAY || powerOut) return mode == M_PLAY;
        switch (keyCode) {
            case 65, KEY_LEFT -> { if (cam) selectCam(camSel - 1); else toggleDoor(true); }
            case 68, KEY_RIGHT -> { if (cam) selectCam(camSel + 1); else toggleDoor(false); }
            case 81 -> { if (!cam) { if (boboIn) lightOn(true); else keyLightW = 45; } }
            case 69 -> { if (!cam) { if (boboIn) lightOn(false); else keyLightE = 45; } }
            case 32, 83, KEY_DOWN, 258 -> toggleCam();
            case 87, KEY_UP -> { if (cam && camSel == MUSIC) wind = Math.min(100, wind + 7); }
            case 86 -> toggleHatch();
            case 70 -> squeak();
            case 77 -> muted = true;
            default -> {
                int c = keyCode >= 49 && keyCode <= 57 ? keyCode - 49 : keyCode == 48 ? 9 : keyCode == 45 ? 10 : keyCode == 61 ? 11 : -1;
                if (c < 0) return false;
                if (!cam) toggleCam();
                selectCam(c);
            }
        }
        return true;
    }

    // ================================================================== drawing
    @Override
    public void render(GuiGraphics g) {
        switch (mode) {
            case M_MENU -> renderMenu(g);
            case M_CUSTOM -> renderCustom(g);
            case M_CARD -> renderCard(g);
            case M_DAWN -> renderDawn(g);
            case M_SCARE -> renderScare(g);
            default -> {
                if (camA >= 0.5F) renderCam(g); else renderOffice(g);
                if (camA > 0F && camA < 1F) NightArt.r(g, 0, 0, W, H, Gfx.alpha(0xFF000000, (int) ((1 - Math.abs(camA - 0.5F) * 2) * 230)));
                renderHud(g);
                if (camA < 0.5F) renderCall(g);
            }
        }
    }

    private void bigText(GuiGraphics g, String s, int cx, int y, float k, int argb) {
        if (((argb >>> 24) & 255) < 6) return;
        g.pose().pushPose();
        g.pose().translate(cx, y, 0);
        g.pose().scale(k, k, 1f);
        ctext(g, s, 0, 0, argb);
        g.pose().popPose();
    }

    private void vignette(GuiGraphics g, int strength) {
        for (int k = 0; k < 6; k++) {
            int a = strength * (6 - k) / 6 / 3;
            int c = Gfx.alpha(0xFF04020A, a);
            NightArt.r(g, 0, k * 6, W, 6, k == 0 ? c : Gfx.alpha(0xFF04020A, a / 2));
            NightArt.r(g, 0, H - 6 - k * 6, W, 6, c);
            NightArt.r(g, k * 8, 0, 8, H, c);
            NightArt.r(g, W - 8 - k * 8, 0, 8, H, c);
        }
    }

    private void stars(GuiGraphics g, int n, int seed) {
        for (int i = 0; i < n; i++) {
            int sx = (int) (NightArt.rnd01(i, seed) * 218), sy = (int) (NightArt.rnd01(i, seed + 1) * 100);
            NightArt.r(g, sx, sy, 1, 1, Gfx.alpha(0xFFE8E4FF, ((t / 16 + i) % 6 == 0) ? 40 : 140));
        }
    }

    private void renderMenu(GuiGraphics g) {
        NightArt.grad(g, 0, 0, W, H, 0xFF0A0616, 0xFF1C1034);
        stars(g, 34, 71);
        Gfx.disc(g, 110, 74, 38, Gfx.alpha(0xFF6A4AC8, 26));
        NightArt.toy(g, 0, 32, 140, 1.7F, 1, t, 0, 0.82F);
        NightArt.toy(g, 1, 188, 140, 1.7F, 1, t, 0, 0.82F);
        bigText(g, str("cutemod.game.night"), W / 2, 12, 2.3F, 0xFFF4ECFF);
        ctextW(g, str("cutemod.night.card.sub." + Math.min(saved, 5)), W / 2, 46, 190, 0xFF9C8CC8);
        boolean h1 = in(mx, my, 56, 78, 108, 15), h2 = saved > 0 && in(mx, my, 56, 96, 108, 15), h3 = saved >= NIGHTS && in(mx, my, 56, 114, 108, 15);
        Gfx.bubble(g, 56, 78, 108, 15, 5, h1 ? 0xFF5C4C94 : 0xFF3E3468);
        ctextW(g, str("cutemod.night.new"), W / 2, 82, 100, 0xFFF4EEFF);
        if (saved > 0) {
            Gfx.bubble(g, 56, 96, 108, 15, 5, h2 ? 0xFF3C9A84 : 0xFF2A7A68);
            ctextW(g, str("cutemod.night.continue", Math.min(saved, NIGHTS - 1) + 1), W / 2, 100, 100, 0xFFF4FFF8);
        }
        if (saved >= NIGHTS) {
            Gfx.bubble(g, 56, 114, 108, 15, 5, h3 ? 0xFFB05A4A : 0xFF8A3A3A);
            ctextW(g, str("cutemod.night.custom"), W / 2, 118, 100, 0xFFFFEEE8);
        }
        if ((t / 3) % 41 == 0) NightArt.r(g, 0, 0, W, H, Gfx.alpha(0xFFFFFFFF, 14));
        vignette(g, 200);
    }

    private void renderCustom(GuiGraphics g) {
        NightArt.grad(g, 0, 0, W, H, 0xFF0A0616, 0xFF1E1034);
        stars(g, 24, 91);
        bigText(g, str("cutemod.night.custom"), W / 2, 4, 1.5F, 0xFFF4ECFF);
        ctextW(g, str("cutemod.night.custom.sub"), W / 2, 19, 210, 0xFF9C8CC8);
        for (int i = 0; i < 8; i++) {
            int[] c = customCell(i);
            int col = cl[i] == 0 ? 0xFF7A6E98 : cl[i] >= 15 ? 0xFFFF8A8A : 0xFFF0E8FF;
            ctextW(g, str("cutemod.night.toy." + i), c[0] + 28, c[1] + 3, 56, col);
            boolean hm = in(mx, my, c[0] + 58, c[1], 12, 14), hp = in(mx, my, c[0] + 86, c[1], 12, 14);
            Gfx.bubble(g, c[0] + 58, c[1], 12, 14, 3, hm ? 0xFF5C4C94 : 0xFF3E3468);
            Gfx.bubble(g, c[0] + 86, c[1], 12, 14, 3, hp ? 0xFF5C4C94 : 0xFF3E3468);
            ctext(g, "-", c[0] + 64, c[1] + 3, 0xFFFFFFFF); ctext(g, "+", c[0] + 92, c[1] + 3, 0xFFFFFFFF);
            ctext(g, String.valueOf(cl[i]), c[0] + 78, c[1] + 3, col);
        }
        boolean hs = in(mx, my, 62, 116, 96, 16), hb = in(mx, my, 6, 116, 50, 16), ha = in(mx, my, 164, 116, 50, 16);
        Gfx.bubble(g, 62, 116, 96, 16, 5, hs ? 0xFF3C9A84 : 0xFF2A7A68);
        ctextW(g, str("cutemod.night.start"), 110, 120, 90, 0xFFF4FFF8);
        Gfx.bubble(g, 6, 116, 50, 16, 5, hb ? 0xFF5C4C94 : 0xFF3E3468);
        ctextW(g, str("cutemod.night.back"), 31, 120, 44, 0xFFF4EEFF);
        Gfx.bubble(g, 164, 116, 50, 16, 5, ha ? 0xFFB05A4A : 0xFF8A3A3A);
        ctextW(g, str("cutemod.night.all20"), 189, 120, 44, 0xFFFFEEE8);
        vignette(g, 160);
    }

    private void renderCard(GuiGraphics g) {
        NightArt.r(g, 0, 0, W, H, 0xFF06040E);
        for (int i = 0; i < 30; i++) {
            int sx = (int) (NightArt.rnd01(i, 31) * 218), sy = (int) (NightArt.rnd01(i, 32) * 136);
            NightArt.r(g, sx, sy, 1, 1, Gfx.alpha(0xFFE8E4FF, ((t / 14 + i) % 5 == 0) ? 40 : 130));
        }
        Gfx.disc(g, 176, 26, 11, 0xFFE9E4FF); Gfx.disc(g, 181, 22, 10, 0xFF06040E);
        int a = t < 30 ? t * 255 / 30 : t > CARD_TICKS - 30 ? (CARD_TICKS - t) * 255 / 30 : 255;
        a = Math.max(0, Math.min(255, a));
        bigText(g, custom ? str("cutemod.night.custom") : str("cutemod.night.card", night + 1), W / 2, 40, 2.2F, Gfx.alpha(0xFFF0E8FF, a));
        bigText(g, str("cutemod.night.h.0"), W / 2, 72, 1.1F, Gfx.alpha(0xFFB8A8E8, a));
        ctextW(g, str(custom ? "cutemod.night.custom.sub" : "cutemod.night.card.sub." + night), W / 2, 92, 200, Gfx.alpha(0xFFD8C8F0, a * 7 / 10));
        ctextW(g, str("cutemod.night.card.tip"), W / 2, 120, 210, Gfx.alpha(0xFF8A7AB8, a * 6 / 10));
        vignette(g, 120);
    }

    private void renderDawn(GuiGraphics g) {
        float k = Math.min(1f, t / 150f);
        NightArt.grad(g, 0, 0, W, 100, Gfx.mix(0xFF140E34, 0xFF5A78C8, k), Gfx.mix(0xFF2A1E4A, 0xFFFFB878, k));
        NightArt.r(g, 0, 100, W, 40, 0xFF0C0814);
        int sy = 112 - (int) (k * 44);
        Gfx.disc(g, 110, sy, 16, Gfx.mix(0xFFFF8A4A, 0xFFFFE8A0, k));
        Gfx.ellipse(g, 110, sy, 38, 22, Gfx.alpha(0xFFFFC888, (int) (40 * k)));
        for (int x = 0; x < W; x += 12) {                                          // the roofs of the town
            int h = 10 + (int) (NightArt.rnd01(x, 41) * 14);
            NightArt.r(g, x, 100 - h, 12, h, 0xFF120C1E);
            if (NightArt.rnd01(x, 42) > 0.6F) NightArt.r(g, x + 4, 100 - h + 4, 3, 3, Gfx.alpha(0xFFFFD890, 130 - (int) (k * 100)));
        }
        NightArt.r(g, 0, 100, W, 40, 0xFF0C0814);
        bigText(g, str("cutemod.night.h.6"), W / 2, 106, 2.0F, Gfx.alpha(0xFFFFF0D0, Math.min(255, t * 6)));
        if (t > 40) ctextW(g, str(custom ? "cutemod.night.survived.custom" : "cutemod.night.survived", night + 1), W / 2, 126, 210, Gfx.alpha(0xFFE8DCF8, Math.min(255, (t - 40) * 8)));
        if (t > 200) NightArt.r(g, 0, 0, W, H, Gfx.alpha(0xFF000000, Math.min(255, (t - 200) * 6)));
    }

    private void renderScare(GuiGraphics g) {
        int tt = Math.min(t, 70);
        boolean flashOn = tt < 40 && (tt / 2) % 2 == 0;
        NightArt.r(g, 0, 0, W, H, tt < 3 ? 0xFFFFFFFF : flashOn ? 0xFF4A0A14 : 0xFF14030A);
        float s = 2.0F + Math.min(tt, 16) * 0.14F;
        int shx = tt < 55 ? rnd.nextInt(9) - 4 : 0, shy = tt < 55 ? rnd.nextInt(9) - 4 : 0;
        float by = 60 + 20 * s;
        NightArt.toy(g, scareWho, W / 2F + shx, by + shy, s, 2, t, 0, tt > 56 ? 0.45F : 0F);
        for (int i = 0; i < 12; i++) NightArt.r(g, 0, rnd.nextInt(H), W, 1 + rnd.nextInt(2), Gfx.alpha(0xFFFFFFFF, 30 + rnd.nextInt(40)));
        vignette(g, 300);
        if (tt > 60) NightArt.r(g, 0, 0, W, H, Gfx.alpha(0xFF000000, (tt - 60) * 12));
    }

    private void renderOffice(GuiGraphics g) {
        NightArt.office(g, t, hour, night);
        NightArt.ventGrate(g, 146, 62, hatch, webPos >= 3 && !hatch && (t / 6) % 3 != 0 && !powerOut);
        NightArt.duck(g, 129, 90, duckAnim);
        // the guard feels watched: the doll creeps to the window
        if (!powerOut && lv(L_DOLL) > 0 && wind <= 0) {
            float p = Math.min(1f, emptyT / (float) dollLimit());
            NightArt.toy(g, 3, 110, 62 + 8 * p, 0.45F + 0.9F * p, 1, t, 0, 0.55F - 0.3F * p);
            NightArt.r(g, 76, 20, 8, 48, 0xFF4A1830); NightArt.r(g, 136, 20, 8, 48, 0xFF4A1830);
        }
        doorway(g, true);
        doorway(g, false);
        if (boboIn && !powerOut) {                                                  // Bobo has slipped in under the door
            NightArt.toy(g, 6, 82, 103, 1.2F, 1, t, 0, 0.1F);
            if ((t / 4) % 5 == 0) NightArt.r(g, 0, 20 + rnd.nextInt(80), W, 1, Gfx.alpha(0xFFFFFFFF, 40));
        }
        if (ghostOut && !powerOut) {                                                // the golden bear on the desk
            boolean blink = ghostStare > 200 && (t / 3) % 2 == 0;
            if (!blink) NightArt.toy(g, 5, 110, 98, 1.25F + Math.min(ghostStare, 300) / 400F, 1, t, 0, 0.1F);
        }
        panels(g);
        bottomBar(g, false);
        int dark = 60 + (flick > 0 && (flick & 1) == 0 ? 70 : 0) + (powerOut ? 130 : 0) + (power < 15 && !powerOut ? (t / 6 % 3 == 0 ? 40 : 0) : 0);
        NightArt.r(g, 0, 0, W, H, Gfx.alpha(0xFF050210, Math.min(235, dark)));
        vignette(g, powerOut ? 330 : 230);
        if (powerOut && outT > 20 && (outT / 20) % 2 == 0 && outT < 200) ctext(g, str("cutemod.night.out"), 110, 62, 0xFFFF5A5A);
    }

    /** The bar at the bottom: the vent hatch on the left, the monitor in the middle. */
    private void bottomBar(GuiGraphics g, boolean inCam) {
        if (inCam) { NightArt.r(g, 0, 124, W, 16, 0xFF0C0A14); NightArt.r(g, 0, 124, W, 1, 0xFF3A3A4A); }
        boolean hv = in(mx, my, 4, 126, 52, 12);
        Gfx.bubble(g, 4, 126, 52, 12, 4, hatch ? (hv ? 0xFFE0564F : 0xFFC03C3C) : (hv ? 0xFF4A4E64 : 0xFF343850));
        ctextW(g, str("cutemod.night.vent"), 30, 127, 48, 0xFFF0ECFF);
        boolean hc = in(mx, my, 60, 126, 100, 12);
        if (inCam) {
            Gfx.bubble(g, 60, 126, 100, 12, 4, hc ? 0xFF7A3A4A : 0xFF5A2E3C);
            ctextW(g, str("cutemod.night.close"), 110, 127, 90, 0xFFFFE8EC);
        } else {
            Gfx.bubble(g, 60, 126, 100, 12, 4, hc ? 0xFF4C4278 : 0xFF362F58);
            ctext(g, str("cutemod.night.cams"), 110, 127, 0xFFE8E0FF);
        }
    }

    private void doorway(GuiGraphics g, boolean west) {
        int x = west ? 22 : 166;
        float da = west ? doorWA : doorEA;
        boolean lit = west ? lightWOn() : lightEOn();
        NightArt.hallView(g, x, lit, t, !west);
        int here = west ? DOOR_W : DOOR_E;
        if (da < 0.6F) {
            for (int i = 0; i < 3; i++) {
                if (pos[i] != here) continue;
                if (lit) NightArt.toy(g, i, x + 16, 101, 1.15F, 1, t, 0, 0.08F);
                else if (((t + i * 37) % 150) < 6) {                                 // two eyes in the dark
                    int c = i == 2 ? 0xFFFF4A50 : 0xFFF4F0FF;
                    NightArt.r(g, x + 10, 73, 3, 2, c); NightArt.r(g, x + 19, 73, 3, 2, c);
                }
            }
            if (powerOut && outT > 90 && west && ((outT / 7) % 9) < 6) {            // the bear's eyes in the blackout
                NightArt.r(g, x + 9, 70, 4, 3, 0xFFF4F0FF); NightArt.r(g, x + 19, 70, 4, 3, 0xFFF4F0FF);
                if (outT > 300) NightArt.toy(g, 2, x + 16, 101, 1.25F, 1, t, 0, 0.8F);
            }
        }
        NightArt.door(g, x, da, t);
        int fx = west ? 18 : 162;
        NightArt.r(g, fx, 22, 40, 4, 0xFF3C2C48); NightArt.r(g, fx, 26, 4, 76, 0xFF3C2C48); NightArt.r(g, fx + 36, 26, 4, 76, 0xFF3C2C48);
    }

    private void panels(GuiGraphics g) {
        for (int side = 0; side < 2; side++) {
            int px = side == 0 ? 1 : 199;
            boolean west = side == 0;
            boolean closed = west ? doorW : doorE, lit = west ? lightWOn() : lightEOn();
            Gfx.rrect(g, px, 33, 20, 56, 3, 0xFF2A2238);
            Gfx.rrect(g, px + 1, 34, 18, 54, 3, 0xFF372E48);
            boolean hd = in(mx, my, px, 36, 20, 24), hl = in(mx, my, px, 62, 20, 24);
            Gfx.bubble(g, px + 2, 37, 16, 22, 3, closed ? (hd ? 0xFFE0564F : 0xFFC03C3C) : (hd ? 0xFF4A5A78 : 0xFF3C4860));
            NightArt.r(g, px + 6, 41, 8, 13, closed ? 0xFFF0C8C0 : 0xFF8A98B8); NightArt.r(g, px + 12, 47, 1, 2, 0xFF2A2030);
            Gfx.bubble(g, px + 2, 63, 16, 22, 3, lit ? 0xFFF0C84A : boboIn ? 0xFF2E2E3C : (hl ? 0xFF5A5A78 : 0xFF444460));
            Gfx.disc(g, px + 10, 72, 4, lit ? 0xFFFFF6C0 : 0xFF8A8AA8);
            NightArt.r(g, px + 8, 77, 4, 4, lit ? 0xFFB89830 : 0xFF6A6A84);
            if (boboIn) { Gfx.line(g, px + 5, 66, px + 15, 82, 0xFFC03C3C); Gfx.line(g, px + 15, 66, px + 5, 82, 0xFFC03C3C); }
            if (lit) Gfx.ellipse(g, px + 10, 72, 10, 7, Gfx.alpha(0xFFFFE890, 40));
        }
    }

    private void renderCam(GuiGraphics g) {
        if (camSel == KITCHEN) NightArt.audioOnly(g, t);
        else if (camSel == MUSIC) NightArt.music(g, t, wind, winding);
        else if (camSel == VENT) NightArt.vent(g, t);
        else NightArt.room(g, camSel, t, Math.min(night, 5), foxStage, ghostPoster);
        int k = 0;
        for (int i = 0; i < 4; i++) {
            int where = i < 3 ? pos[i] : boboPos;
            if (where != camSel) continue;
            int type = i < 3 ? i : 6;
            float x, by, s;
            switch (camSel) {
                case STAGE -> { x = i == 0 ? 58 : i == 2 ? 110 : 162; by = 95; s = 1.0F; }
                case DINING -> { x = 50 + k * 60; by = 114; s = 1.1F; }
                case PLAYRM -> { x = 64 + k * 44; by = 114; s = 1.25F; }
                case WHALL, EHALL -> { x = 110 + (k - 1) * 12; by = 102; s = 0.95F; }
                case WCORNER, ECORNER -> { x = 110 + k * 14; by = 118; s = 1.55F; }
                default -> { x = 74 + k * 36; by = 109; s = 1.2F; }
            }
            int look = type == 2 ? 0 : (int) Math.round(Math.sin(t * 0.03 + i));
            NightArt.toy(g, type, x, by, s, glitchT > 0 ? 1 : 0, t, look, 0.1F);
            k++;
        }
        if (camSel == WHALL && foxStage >= 4 && foxRun >= 40 && foxRun <= 125) {          // the fox runs past
            float f = (foxRun - 40) / 85F;
            NightArt.toy(g, 4, 110 - (1 - f) * 6, 92 + f * 28, 0.6F + f * 1.0F, 2, t, 0, 0.1F);
            for (int i = 0; i < 4; i++) NightArt.r(g, 40 + rnd.nextInt(130), 60 + rnd.nextInt(50), 30 + rnd.nextInt(30), 1, Gfx.alpha(0xFFFFFFFF, 40));
        }
        if (camSel == VENT) {                                                              // Webby crawls closer, the hatch hides the near end
            if (webPos == 1) NightArt.toy(g, 7, 110, 84, 0.7F, glitchT > 0 ? 1 : 0, t, 0, 0.15F);
            else if (webPos == 2) NightArt.toy(g, 7, 110, 108, 1.5F, glitchT > 0 ? 2 : 1, t, 0, 0.1F);
            else if (webPos >= 3) NightArt.toy(g, 7, 110, 124, 2.2F, 2, t, 0, 0.1F);
            if (hatch) {
                NightArt.r(g, 14, 92, 192, 30, 0xFF6A6E7C); NightArt.r(g, 14, 92, 192, 2, 0xFFA0A4B2); NightArt.r(g, 14, 120, 192, 2, 0xFF3A3E4A);
                for (int i = 0; i < 16; i++) { NightArt.r(g, 20 + i * 12, 96, 6, 22, Gfx.alpha(0xFF000000, 36)); NightArt.r(g, 22 + i * 12, 98, 2, 2, 0xFFB8BCC8); }
            }
        }
        // the camera: green-teal tint, scan lines, rolling bar, noise, glitches
        NightArt.r(g, 0, 0, W, 124, Gfx.alpha(0xFF40FFD0, 26));
        for (int y = 0; y < 124; y += 2) NightArt.r(g, 0, y, W, 1, Gfx.alpha(0xFF000000, 30));
        int roll = (t * 2) % 170 - 20;
        NightArt.r(g, 0, roll, W, 9, Gfx.alpha(0xFFFFFFFF, 11));
        for (int i = 0; i < 26; i++) NightArt.r(g, rnd.nextInt(W), rnd.nextInt(124), 1, 1, Gfx.alpha(0xFFFFFFFF, 28));
        if (glitchT > 0) {
            for (int i = 0; i < 6; i++) NightArt.r(g, 0, rnd.nextInt(124), W, 2 + rnd.nextInt(5), Gfx.alpha(i % 2 == 0 ? 0xFFB0FFE8 : 0xFFFF70D0, 50 + glitchT * 8));
        }
        if (flick > 0 && (flick & 1) == 0) NightArt.r(g, 0, 0, W, 124, Gfx.alpha(0xFF000000, 60));
        if (camSel == KITCHEN) ctext(g, str("cutemod.night.audio"), 110, 84, 0xFF8AF0C8);
        // the music box room has a winding key, the vent a seal
        if (camSel == MUSIC) {
            boolean low = wind < 25;
            NightArt.r(g, 50, 16, 120, 5, 0xAA000000);
            NightArt.r(g, 51, 17, (int) (118 * wind / 100.0), 3, low && (t / 8) % 2 == 0 ? 0xFFFF5A5A : low ? 0xFFE88A4A : 0xFF8AF0C8);
            boolean hd = winding || in(mx, my, 8, 100, 88, 18);
            Gfx.bubble(g, 8, 100, 88, 18, 4, winding ? 0xFF2F8F7A : hd ? 0xFF5A4C8C : 0xFF40386A);
            ctextW(g, str("cutemod.night.wind"), 52, 105, 80, 0xFFF4EEFF);
        }
        if (camSel == VENT) {
            boolean hd = in(mx, my, 8, 100, 88, 18);
            Gfx.bubble(g, 8, 100, 88, 18, 4, hatch ? 0xFFC03C3C : hd ? 0xFF5A4C8C : 0xFF40386A);
            ctextW(g, str(hatch ? "cutemod.night.unseal" : "cutemod.night.seal"), 52, 105, 80, 0xFFF4EEFF);
        }
        vignette(g, 260);
        // the map of the shop
        NightArt.r(g, 139, 65, 76, 56, Gfx.alpha(0xFF050410, 190));
        for (int i = 0; i < NCAMS; i++) {
            int[] c = cell(i);
            boolean sel = i == camSel, hv = in(mx, my, c[0], c[1], c[2], c[3]);
            int col = sel ? ((t / 10) % 2 == 0 ? 0xFF2F8F7A : 0xFF3AAE94) : hv ? 0xFF4A4670 : 0xFF2C2848;
            Gfx.bubble(g, c[0], c[1], c[2], c[3], 2, col);
            ctext(g, String.valueOf(i + 1), c[0] + c[2] / 2, c[1] + 2, 0xFFFFFFFF);
        }
        NightArt.r(g, 159, 106, 35, 12, 0xFF3A2A18); ctext(g, "YOU", 176, 108, 0xFFE8C838);
        bottomBar(g, true);
    }

    private void renderHud(GuiGraphics g) {
        boolean inCam = camA >= 0.5F;
        NightArt.grad(g, 0, 0, W, 28, Gfx.alpha(0xFF000000, 140), Gfx.alpha(0xFF000000, 0));
        if (inCam) {
            text(g, str("cutemod.night.cam", camSel + 1, str("cutemod.night.cam." + camSel)), 5, 3, 0xFFC8FFF0);
        } else {
            text(g, hourStr(), 5, 3, 0xFFEDE6FF);
            text(g, custom ? str("cutemod.night.custom") : str("cutemod.night.card", night + 1), 5, 13, 0xFF9C8CC8);
        }
        int pct = (int) Math.ceil(power);
        String ps = pct + "%";
        int pc = pct > 50 ? 0xFF9CE6A8 : pct > 20 ? 0xFFFFE08A : 0xFFFF6A6A;
        if (pct <= 15 && (t / 8) % 2 == 0) pc = 0xFFFFFFFF;
        text(g, ps, W - 5 - tw(ps), 3, pc);
        int u = usage();
        for (int i = 0; i < u; i++) NightArt.r(g, W - 5 - u * 5 + i * 5, 14, 4, 5, i < 2 ? 0xFF7AE090 : i < 4 ? 0xFFFFD070 : 0xFFFF6A6A);
        if (inCam) {
            if ((t / 30) % 2 == 0) Gfx.disc(g, W - 12 - tw(ps), 7, 2, 0xFFFF3A3A);
            text(g, hourStr(), W - 5 - tw(hourStr()), 21, 0xFFC8FFF0);
        }
    }

    /** The phone call of the guard who worked here before you: subtitles at the bottom. */
    private void renderCall(GuiGraphics g) {
        if (!callShown() || powerOut) return;
        int idx = (callT - 150) / 660;
        List<String> lines = wrap(str("cutemod.night.call." + night + "." + idx), 196);
        int h = 6 + lines.size() * 9;
        int y0 = 123 - h;
        NightArt.r(g, 4, y0, 212, h, Gfx.alpha(0xFF000000, 195));
        for (int i = 0; i < lines.size(); i++) ctext(g, lines.get(i), 106, y0 + 3 + i * 9, 0xFFE8E0FF);
        boolean hv = in(mx, my, 180, 78, 36, 11);
        Gfx.bubble(g, 180, 78, 36, 11, 3, hv ? 0xFF6A4A8A : 0xFF4A3668);
        ctextW(g, str("cutemod.night.mute"), 198, 80, 34, 0xFFF4EEFF);
    }

    private List<String> wrap(String s, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : s.split(" ")) {
            if (cur.length() > 0 && tw(cur + " " + w) > maxW) { out.add(cur.toString()); cur.setLength(0); }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }
}
