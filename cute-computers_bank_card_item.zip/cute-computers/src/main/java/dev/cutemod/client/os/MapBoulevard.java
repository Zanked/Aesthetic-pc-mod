package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.MapArt.ball;
import static dev.cutemod.client.os.MapArt.mix;
import static dev.cutemod.client.os.MapArt.rect;

/** Little pictures of treats that the Pantry and the places use: a heart, a bone, a fish, a cookie. */
final class MapBoulevard {
    private MapBoulevard() {}

    static void heart(GuiGraphics g, int x, int y, int c) {
        rect(g, x, y, 2, 1, c); rect(g, x + 3, y, 2, 1, c); rect(g, x, y + 1, 5, 1, c); rect(g, x + 1, y + 2, 3, 1, c); rect(g, x + 2, y + 3, 1, 1, c);
    }

    static void bone(GuiGraphics g, int x, int y, int c) {
        rect(g, x + 1, y + 1, 7, 1, c);
        rect(g, x, y, 2, 1, c); rect(g, x, y + 2, 2, 1, c); rect(g, x + 7, y, 2, 1, c); rect(g, x + 7, y + 2, 2, 1, c);
    }

    /** A fish swimming to the right, about 8 x 4. */
    static void fish(GuiGraphics g, int x, int y, int c, int eye) {
        rect(g, x + 1, y, 4, 4, c); rect(g, x, y + 1, 6, 2, c); rect(g, x + 6, y, 1, 4, mix(c, 0xFFFFFFFF, 0.2F)); rect(g, x + 7, y - 1, 1, 6, mix(c, 0xFFFFFFFF, 0.2F));
        rect(g, x + 1, y + 1, 1, 1, eye); rect(g, x + 2, y + 3, 2, 1, mix(c, 0xFFFFFFFF, 0.45F));
    }

    static void cookie(GuiGraphics g, int cx, int cy, int r) {
        ball(g, cx, cy, r, 0xFFD9A25E); ball(g, cx - 1, cy - 1, Math.max(1, r - 2), 0xFFE8B878);
        rect(g, cx - 1, cy, 1, 1, 0xFF6A3A1E); rect(g, cx + 1, cy - 1, 1, 1, 0xFF6A3A1E); rect(g, cx, cy + 1, 1, 1, 0xFF6A3A1E);
    }
}
