package dev.cutemod.client.os;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** CuteMarket: order food, music discs, gear and materials, follow the delivery and collect the parcel (real items). */
public class MarketApp extends App {

    @Override
    public boolean needsNet() { return true; }
    private static final int HEAD = 22, PAGE = 8;
    private static final int BG = 0xFFFFF6FB, PINK = 0xFFF58FB8, TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8;
    private static final int ACCENT = 0xFFB57BD6, GREEN = 0xFF5BBF6A, RED = 0xFFE5484D, BORDER = 0xFFEAD6E6, GOLD = 0xFFB98A10;

    private static final int CATS = 6, CAT_PITCH = 38, CAT_W = 36;     // 6 categories (the electronics moved to CuteTech) end at x=224, the page switcher starts at about 249
    private static final int SEG_X = 66, SEG_W = 64, CART_X = 204, ORD_X = 254;

    private int tab, shopKind, page, scroll;
    private boolean express;
    private final HomeGoods home = new HomeGoods();   // the "Home" tab: wallpapers, pet things, songs, treats
    private final Map<String, Integer> cart = new LinkedHashMap<>();

    @Override
    public Component title() { return Component.translatable("cutemod.os.market"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.market"); }

    @Override
    public Component status() {
        int a = Market.active();
        return a > 0 ? Component.translatable("cutemod.market.status", a) : Component.empty();
    }

    @Override
    public void tick() { Market.tick(); }

    private int cartCount() {
        int n = 0;
        for (int v : cart.values()) n += v;
        return n;
    }

    // ---------- small helpers ----------
    private static void btn(GuiGraphics g, int x, int y, int w, int h, String label, boolean enabled, boolean hover, int color) {
        Font f = font();
        App.roundRect(g, x, y, w, h, 4, !enabled ? 0xFFDCCFE0 : hover ? mix(color, 0xFFFFFF, 0.25f) : color);
        Skin.str(g, f, label, x + (w - f.width(label)) / 2, y + (h - 8) / 2 + 1, enabled ? 0xFFFFFFFF : 0xFF9A8FA8, false);
    }

    private static void txt(GuiGraphics g, String s, int x, int y, int argb) { Skin.str(g, font(), s, x, y, argb, false); }

    private static void rtxt(GuiGraphics g, String s, int rx, int y, int argb) { Skin.str(g, font(), s, rx - font().width(s), y, argb, false); }

    /** A shop name: our own text for foods and discs, the game's own name for gear. */
    static String name(String id) {
        String key = "cutemod.market.item." + id;
        if (net.minecraft.locale.Language.getInstance().has(key)) return t(key);
        net.minecraft.world.item.ItemStack st = stack(id);
        return st.isEmpty() ? id : st.getHoverName().getString();
    }

    private static final Map<String, net.minecraft.world.item.ItemStack> STACKS = new java.util.HashMap<>();

    /** The real item behind a catalog id (for its icon and name); empty while no world is loaded. */
    private static net.minecraft.world.item.ItemStack stack(String id) {
        net.minecraft.world.item.ItemStack st = STACKS.get(id);
        if (st != null) return st;
        var level = net.minecraft.client.Minecraft.getInstance().level;
        if (level == null) return net.minecraft.world.item.ItemStack.EMPTY;
        st = dev.cutemod.market.Catalog.create(id, level.registryAccess());
        STACKS.put(id, st);
        return st;
    }

    private static String clip(String s, int w) { return font().plainSubstrByWidth(s, w); }

    /** A neat round disc (no single-pixel tips at the edges), centre cx,cy and radius r. */
    private static void ball(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int hw = (int) Math.floor(Math.sqrt((r + 0.5) * (r + 0.5) - dy * dy));
            Skin.rect(g, cx - hw, cy + dy, hw * 2 + 1, 1, argb);
        }
    }

    // ---------- pictures ----------
    /** A 24 x 20 picture of an item, drawn at x,y and scaled. */
    private static void icon(GuiGraphics g, String id, int x, int y, float s) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(s, s, 1f);
        dev.cutemod.market.Catalog.Entry entry = dev.cutemod.market.Catalog.get(id);
        if (entry != null && (entry.kind() >= dev.cutemod.market.Catalog.TOOL || dev.cutemod.market.Catalog.vanillaFood(id))) {   // gear, supplies and the game's own food: the game's own icon
            net.minecraft.world.item.ItemStack st = stack(id);
            if (!st.isEmpty()) g.renderItem(st, 4, 2);
            g.pose().popPose();
            return;
        }
        switch (id) {
            case "pizza" -> {
                Skin.rect(g, 2, 1, 20, 3, 0xFFD9964A);
                for (int r = 0; r < 14; r++) Skin.rect(g, 2 + r / 2, 4 + r, 20 - r, 1, 0xFFFFC94A);
                Skin.disc(g, 9, 8, 2, 0xFFE5484D); Skin.disc(g, 15, 7, 2, 0xFFE5484D); Skin.disc(g, 12, 13, 2, 0xFFE5484D);
            }
            case "burger" -> {
                Skin.rect(g, 3, 2, 18, 5, 0xFFE0A050); Skin.rect(g, 2, 7, 20, 2, 0xFF5BBF5A);
                Skin.rect(g, 3, 9, 18, 3, 0xFF6B3A20); Skin.rect(g, 3, 12, 18, 2, 0xFFFFD040);
                Skin.rect(g, 3, 14, 18, 4, 0xFFE0A050);
                Skin.rect(g, 7, 3, 2, 1, 0xFFFFFFFF); Skin.rect(g, 13, 4, 2, 1, 0xFFFFFFFF); Skin.rect(g, 17, 3, 2, 1, 0xFFFFFFFF);
            }
            case "sushi" -> {
                Skin.rect(g, 4, 8, 16, 8, 0xFFFFFFFF); Skin.rect(g, 3, 4, 18, 5, 0xFFFF8A6A);
                Skin.rect(g, 10, 4, 3, 12, 0xFF2A3A2A); Skin.rect(g, 5, 16, 14, 1, 0xFFDDDDDD);
            }
            case "ramen" -> {
                Skin.rect(g, 3, 8, 18, 9, 0xFFE5484D); Skin.rect(g, 5, 17, 14, 2, 0xFFB03030);
                Skin.rect(g, 4, 6, 16, 3, 0xFFFFE08A); Skin.disc(g, 9, 6, 3, 0xFFFFFFFF); Skin.disc(g, 9, 6, 1, 0xFFFFC832);
                Skin.rect(g, 14, 3, 1, 3, 0xFFB0B0B0); Skin.rect(g, 17, 2, 1, 4, 0xFFB0B0B0);
            }
            case "bubbletea" -> {
                Skin.rect(g, 7, 3, 11, 2, 0xFFFFFFFF); Skin.rect(g, 8, 5, 9, 13, 0xFFF3D9B1);
                Skin.rect(g, 12, 0, 2, 4, 0xFFE5484D);
                Skin.disc(g, 10, 16, 1, 0xFF3A2A3A); Skin.disc(g, 13, 16, 1, 0xFF3A2A3A); Skin.disc(g, 15, 15, 1, 0xFF3A2A3A); Skin.disc(g, 11, 14, 1, 0xFF3A2A3A);
            }
            case "cupcake" -> {
                Skin.rect(g, 6, 10, 12, 7, 0xFFE5A0C0); for (int k = 0; k < 4; k++) Skin.rect(g, 8 + k * 3, 10, 1, 7, 0xFFC878A0);
                Skin.rect(g, 5, 6, 14, 5, 0xFFFFFFFF); Skin.rect(g, 8, 3, 8, 4, 0xFFFFD6E8);
                Skin.disc(g, 12, 3, 2, 0xFFE5484D);
            }
            case "toast" -> {
                Skin.rect(g, 3, 5, 18, 12, 0xFFE0B060); Skin.rect(g, 4, 6, 16, 10, 0xFFF5D090);
                Skin.rect(g, 4, 6, 16, 3, 0xFFFFC832); Skin.rect(g, 6, 9, 2, 3, 0xFFFFC832); Skin.rect(g, 14, 9, 2, 4, 0xFFFFC832);
                Skin.rect(g, 9, 7, 4, 3, 0xFFFFF0A0);
            }
            case "icecream" -> {
                for (int r = 0; r < 9; r++) Skin.rect(g, 7 + r / 2, 11 + r, 10 - r, 1, 0xFFD9964A);
                Skin.disc(g, 12, 8, 5, 0xFFFFB6D2); Skin.disc(g, 12, 4, 4, 0xFFFFFFFF); Skin.disc(g, 12, 0, 1, 0xFFE5484D);
            }
            default -> {
                int hue = id.hashCode() & 0x7fffffff;
                int color = 0xFF000000 | java.awt.Color.HSBtoRGB((hue % 360) / 360f, 0.55f, 0.95f);
                if (id.startsWith("disc_")) {            // a record: black vinyl with a colored label
                    ball(g, 12, 10, 9, 0xFF2A2A35); ball(g, 12, 10, 4, color); ball(g, 12, 10, 1, 0xFF2A2A35);
                    Skin.rect(g, 5, 6, 4, 1, 0x66FFFFFF); Skin.rect(g, 15, 15, 3, 1, 0x33FFFFFF);
                } else {
                    Skin.disc(g, 12, 10, 8, 0xFFB57BD6);
                }
            }
        }
        g.pose().popPose();
    }

    /** A small rounded header button with a count badge. */
    private static void navPill(GuiGraphics g, int mx, int my, int x, int w, String label, int n, boolean sel) {
        Font f = font();
        boolean hov = in(mx, my, x, 5, w, 13);
        App.roundRect(g, x, 5, w, 13, 6, sel ? 0xFFFFFFFF : hov ? 0x55FFFFFF : 0x33FFFFFF);
        Skin.boxC(g, f, label, x + 2, 8, sel ? 0xFFD0558F : 0xFFFFFFFF, false, w - 4);   // smaller instead of cut
        if (n > 0) {
            String q = n > 9 ? "9+" : Integer.toString(n);
            int bw = Math.max(9, f.width(q) + 4);
            App.roundRect(g, x + w - bw + 3, 1, bw, 9, 4, RED);
            Skin.str(g, f, q, x + w - bw + 3 + (bw - f.width(q)) / 2, 2, 0xFFFFFFFF, false);
        }
    }

    /** A soft card: a faint shadow, a thin border and the fill. */
    private static void card(GuiGraphics g, int x, int y, int w, int h, int fill, int border) {
        App.roundRect(g, x, y + 1, w, h, 4, 0x14703A8A);
        App.roundRect(g, x, y, w, h, 4, border);
        App.roundRect(g, x + 1, y + 1, w - 2, h - 2, 3, fill);
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        Skin.rect(g, 0, 0, W, H, BG);
        Skin.grad(g, 0, 0, W, HEAD, 0xFFF77FB0, 0xFFC58BE0);
        Skin.rect(g, 0, HEAD, W, 1, 0x22000000);
        Skin.box(g, f, t("cutemod.os.market"), 7, 7, 0xFFFFFFFF, true, SEG_X - 12);
        // the two worlds of the market: goods for the game world (delivered) and goods for the PC (instant)
        App.roundRect(g, SEG_X, 4, SEG_W * 2 + 4, 15, 7, 0x40FFFFFF);
        for (int i = 0; i < 2; i++) {
            int sx = SEG_X + 2 + i * (SEG_W + 0);
            boolean sel = (i == 0) == (tab != 1);
            if (sel) App.roundRect(g, sx, 5, SEG_W, 13, 6, 0xFFFFFFFF);
            else if (in(mx, my, sx, 5, SEG_W, 13)) App.roundRect(g, sx, 5, SEG_W, 13, 6, 0x33FFFFFF);
            String s = t(i == 0 ? "cutemod.market.nav.world" : "cutemod.market.nav.pc");
            Skin.str(g, f, s, sx + (SEG_W - f.width(s)) / 2, 8, sel ? 0xFFD0558F : 0xFFFFFFFF, false);
        }
        if (tab != 1) {
            navPill(g, mx, my, CART_X, 48, t("cutemod.market.nav.cart"), cartCount(), tab == 2);
            navPill(g, mx, my, ORD_X, 44, t("cutemod.market.nav.orders"), Market.active(), tab == 3);
        } else {
            String s = t("cutemod.market.nav.instant");
            Skin.str(g, f, s, W - 6 - f.width(s), 8, 0xFFFFFFFF, false);
        }
        switch (tab) {
            case 0 -> renderShop(g, mx, my);
            case 1 -> home.render(g, mx, my, shell.color().bodyColor, shell.absX(), shell.absY());
            case 2 -> renderCart(g, mx, my);
            default -> renderOrders(g, mx, my);
        }
    }

    private static final int CAT_Y = 26, GRID_Y = 41, CARD_W = 70, CARD_H = 56, ROW_H = 59;

    private static final int PG_BTN = 12;

    /**
     * Where the page switcher "< 1/3 >" goes: {left arrow x, numbers x, right arrow x}. It is laid out from the right edge,
     * with a gap on both sides of the numbers, so the arrows never touch them (however many digits they have).
     */
    private int[] pager(Font f, int pages) {
        int right = W - 6 - PG_BTN;
        int text = right - 3 - f.width((page + 1) + "/" + pages);
        return new int[]{text - 3 - PG_BTN, text, right};
    }

    private void renderShop(GuiGraphics g, int mx, int my) {
        Font f = font();
        String[] catNames = new String[CATS];
        for (int k = 0; k < CATS; k++) catNames[k] = t("cutemod.market.cat." + k);
        float catK = Skin.group(f, CAT_W - 2, 0.6F, catNames);       // the names of the categories share one size
        for (int k = 0; k < CATS; k++) {
            int cx = 4 + k * CAT_PITCH;
            boolean sel = shopKind == k;
            App.roundRect(g, cx, CAT_Y, CAT_W, 12, 5, sel ? ACCENT : (in(mx, my, cx, CAT_Y, CAT_W, 12) ? 0xFFEAD6F5 : 0xFFF1E4F7));
            Skin.boxK(g, f, t("cutemod.market.cat." + k), cx + 1, CAT_Y + 2, sel ? 0xFFFFFFFF : TEXT, false, CAT_W - 2, true, catK);
        }
        List<Market.Item> list = Market.items(shopKind);
        int pages = Math.max(1, (list.size() + PAGE - 1) / PAGE);
        page = Math.min(page, pages - 1);
        if (pages > 1) {
            int[] pg = pager(f, pages);
            btn(g, pg[0], CAT_Y, PG_BTN, 12, "<", page > 0, in(mx, my, pg[0], CAT_Y, PG_BTN, 12), ACCENT);
            btn(g, pg[2], CAT_Y, PG_BTN, 12, ">", page < pages - 1, in(mx, my, pg[2], CAT_Y, PG_BTN, 12), ACCENT);
            Skin.str(g, f, (page + 1) + "/" + pages, pg[1], CAT_Y + 2, MUTED, false);
        }
        for (int i = 0; i < PAGE; i++) {
            int idx = page * PAGE + i;
            if (idx >= list.size()) break;
            Market.Item it = list.get(idx);
            int cx = 6 + (i % 4) * 72, cy = GRID_Y + (i / 4) * ROW_H;
            boolean hov = in(mx, my, cx, cy, CARD_W, CARD_H);
            card(g, cx, cy, CARD_W, CARD_H, hov ? 0xFFFFE9F4 : 0xFFFFFFFF, hov ? PINK : BORDER);
            icon(g, it.id(), cx + 23, cy + 3, 1.0f);
            Skin.boxC(g, f, name(it.id()), cx + 3, cy + 25, TEXT, false, CARD_W - 6);        // a long name gets smaller, it is not cut
            Skin.boxC(g, f, subLine(it), cx + 3, cy + 34, MUTED, false, CARD_W - 6);
            // the price pill; under the mouse it turns into "add to cart"
            boolean rich = Progress.coins() >= it.price();
            int py = cy + 44;
            if (hov) {
                App.roundRect(g, cx + 6, py, CARD_W - 12, 10, 5, GREEN);
                String a = t("cutemod.market.add");
                Skin.str(g, f, a, cx + (CARD_W - f.width(a)) / 2, py + 1, 0xFFFFFFFF, false);
            } else {
                App.roundRect(g, cx + 6, py, CARD_W - 12, 10, 5, rich ? 0xFFFFF1C2 : 0xFFFFE0E0);
                String price = Integer.toString(it.price());
                int px = cx + (CARD_W - (f.width(price) + 10)) / 2;
                Progress.drawCoin(g, px, py + 1);
                Skin.str(g, f, price, px + 10, py + 1, rich ? GOLD : RED, false);
            }
            int deal = dev.cutemod.market.Deals.percent(it.id());
            if (deal > 0) {                                           // on sale today
                String d = "-" + deal + "%";
                App.roundRect(g, cx + 2, cy + 2, f.width(d) + 5, 10, 4, RED);
                Skin.str(g, f, d, cx + 4, cy + 3, 0xFFFFFFFF, false);
            }
            Integer in = cart.get(it.id());
            if (in != null) {
                App.roundRect(g, cx + CARD_W - 17, cy + 2, 15, 10, 4, GREEN);
                String q = "x" + in;
                Skin.str(g, f, q, cx + CARD_W - 9 - f.width(q) / 2, cy + 3, 0xFFFFFFFF, false);
            }
        }
    }

    /** The grey line under a product: the effect of a food, the metal of a piece of gear, or its kind. */
    private static String subLine(Market.Item it) {
        if (it.kind() == Market.FOOD) return t("cutemod.market.fx." + it.id());
        if (it.kind() == dev.cutemod.market.Catalog.MATERIAL) {                 // what it is: ingot, gem, dust...
            String key = "cutemod.market.mat." + it.id();
            return t(net.minecraft.locale.Language.getInstance().has(key) ? key : "cutemod.market.sub.5");
        }
        if (it.kind() == dev.cutemod.market.Catalog.PART) return t("cutemod.market.part." + it.id());       // "16 GB", "6 GB video memory"...
        if (it.id().startsWith(dev.cutemod.market.Catalog.HEADPHONES)) return t("cutemod.market.sub.headphones");
        int us = it.id().indexOf('_');
        if (it.kind() >= dev.cutemod.market.Catalog.TOOL && us > 0) {
            String key = "cutemod.market.tier." + it.id().substring(0, us);
            if (net.minecraft.locale.Language.getInstance().has(key)) return t(key);
        }
        return t("cutemod.market.sub." + it.kind());
    }

    private void renderCart(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<Map.Entry<String, Integer>> rows = new java.util.ArrayList<>(cart.entrySet());
        if (rows.isEmpty()) {
            String s = t("cutemod.market.cart_empty");
            Skin.str(g, f, s, (W - f.width(s)) / 2, 74, MUTED, false);
        }
        g.enableScissor(shell.absX(), shell.absY() + HEAD + 2, shell.absX() + W, shell.absY() + 124);
        for (int i = 0; i < rows.size(); i++) {
            int y = HEAD + 4 + i * 17 - scroll;
            if (y < HEAD - 14 || y > 124) continue;
            String id = rows.get(i).getKey();
            Market.Item it = Market.item(id);
            int q = rows.get(i).getValue();
            App.roundRect(g, 4, y, W - 8, 16, 4, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFFEFF7);
            icon(g, id, 6, y + 1, 0.7f);
            Skin.box(g, font(), name(id), 26, y + 4, TEXT, false, 120);
            btn(g, 156, y + 2, 12, 12, "-", true, in(mx, my, 156, y + 2, 12, 12), ACCENT);
            String qs = Integer.toString(q);
            txt(g, qs, 181 - font().width(qs) / 2, y + 4, TEXT);
            boolean canPlus = q < Math.min(9, it.maxQty());
            btn(g, 194, y + 2, 12, 12, "+", canPlus, canPlus && in(mx, my, 194, y + 2, 12, 12), ACCENT);
            rtxt(g, Integer.toString(it.price() * q), W - 20, y + 4, 0xFFB98A10);
            Progress.drawCoin(g, W - 16, y + 4);
        }
        g.disableScissor();
        // bottom bar
        Skin.rect(g, 0, 125, W, H - 125, 0xFFFBEAF3);
        Skin.rect(g, 6, 129, 10, 10, express ? GREEN : 0xFFFFFFFF);
        Skin.rect(g, 6, 129, 10, 1, BORDER); Skin.rect(g, 6, 138, 10, 1, BORDER); Skin.rect(g, 6, 129, 1, 10, BORDER); Skin.rect(g, 15, 129, 1, 10, BORDER);
        if (express) { Skin.rect(g, 8, 133, 2, 2, 0xFFFFFFFF); Skin.rect(g, 10, 134, 2, 2, 0xFFFFFFFF); Skin.rect(g, 12, 131, 2, 4, 0xFFFFFFFF); }
        txt(g, t("cutemod.market.express", Market.EXPRESS_PCT, Market.EXPRESS_SPEED), 21, 131, TEXT);
        int total = Market.total(cart, express);
        txt(g, t("cutemod.market.total", total), 6, 146, TEXT);
        boolean can = !cart.isEmpty() && Progress.coins() >= total;
        if (!cart.isEmpty() && Progress.coins() < total) txt(g, t("cutemod.market.poor"), 90, 146, RED);
        btn(g, W - 92, 140, 86, 20, t("cutemod.market.order"), can, can && in(mx, my, W - 92, 140, 86, 20), GREEN);
    }

    private void renderOrders(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<Market.Order> list = Market.orders();
        if (list.isEmpty()) {
            String s = t("cutemod.market.no_orders");
            Skin.str(g, f, s, (W - f.width(s)) / 2, 74, MUTED, false);
        }
        g.enableScissor(shell.absX(), shell.absY() + HEAD, shell.absX() + W, shell.absY() + H);
        for (int i = 0; i < list.size(); i++) {
            Market.Order o = list.get(i);
            int y = HEAD + 3 + i * 24 - scroll;
            if (y < HEAD - 22 || y > H) continue;
            App.roundRect(g, 4, y, W - 8, 23, 4, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFFEFF7);
            icon(g, o.id, 6, y + 2, 0.8f);
            Skin.box(g, font(), name(o.id) + (o.qty > 1 ? " x" + o.qty : ""), 34, y + 3, TEXT, false, 150);
            if (Market.arrived(o)) {
                txt(g, t("cutemod.market.arrived"), 34, y + 13, GREEN);
                btn(g, W - 76, y + 3, 68, 17, t("cutemod.market.collect"), true, in(mx, my, W - 76, y + 3, 68, 17), GREEN);
            } else {
                int total = Math.max(1000, (int) (Market.item(o.id).secs() * 1000L / 3));
                float frac = Math.max(0f, Math.min(1f, 1f - Market.secondsLeft(o) * 1000f / Math.max(total, Market.item(o.id).secs() * 1000f)));
                Skin.rect(g, 34, y + 14, 150, 5, 0xFFEAD6E6);
                Skin.rect(g, 34, y + 14, Math.round(150 * frac), 5, ACCENT);
                int cx = 34 + Math.round(150 * frac);
                Skin.rect(g, Math.max(34, cx - 3), y + 12, 6, 8, PINK);    // the courier
                int s = Market.secondsLeft(o);
                rtxt(g, (s / 60) + ":" + String.format("%02d", s % 60), W - 10, y + 7, MUTED);
            }
        }
        g.disableScissor();
    }

    // ---------- input ----------
    private void setTab(int t) { tab = t; scroll = 0; }

    @Override
    public boolean click(int x, int y, int button) {
        if (y < HEAD) {
            if (in(x, y, SEG_X + 2, 5, SEG_W, 13)) { if (tab == 1) setTab(0); else if (tab != 0) setTab(0); return true; }
            if (in(x, y, SEG_X + 2 + SEG_W, 5, SEG_W, 13)) { setTab(1); return true; }
            if (tab != 1) {
                if (in(x, y, CART_X, 5, 48, 13)) { setTab(tab == 2 ? 0 : 2); return true; }
                if (in(x, y, ORD_X, 5, 44, 13)) { setTab(tab == 3 ? 0 : 3); return true; }
            }
            return true;
        }
        switch (tab) {
            case 0 -> clickShop(x, y);
            case 1 -> home.click(x, y);
            case 2 -> clickCart(x, y);
            default -> clickOrders(x, y);
        }
        return true;
    }

    private void clickShop(int x, int y) {
        for (int k = 0; k < CATS; k++) if (in(x, y, 4 + k * CAT_PITCH, CAT_Y, CAT_W, 12)) { shopKind = k; page = 0; return; }
        List<Market.Item> list = Market.items(shopKind);
        int pages = Math.max(1, (list.size() + PAGE - 1) / PAGE);
        if (pages > 1) {
            int[] pg = pager(font(), pages);
            if (in(x, y, pg[0], CAT_Y, PG_BTN, 12) && page > 0) { page--; return; }
            if (in(x, y, pg[2], CAT_Y, PG_BTN, 12) && page < pages - 1) { page++; return; }
        }
        for (int i = 0; i < PAGE; i++) {
            int idx = page * PAGE + i;
            if (idx >= list.size()) break;
            int cx = 6 + (i % 4) * 72, cy = GRID_Y + (i / 4) * ROW_H;
            if (!in(x, y, cx, cy, CARD_W, CARD_H)) continue;
            Market.Item it = list.get(idx);
            cart.merge(it.id(), 1, (a, b) -> Math.min(Math.min(9, it.maxQty()), a + b));
            Progress.toast("cutemod.market.added", name(it.id()));
            return;
        }
    }

    private void clickCart(int x, int y) {
        if (in(x, y, 6, 129, 10, 10) || (y >= 129 && y < 140 && x >= 16 && x < 150)) { express = !express; return; }
        int total = Market.total(cart, express);
        if (in(x, y, W - 92, 140, 86, 20)) {
            if (!cart.isEmpty() && Progress.coins() >= total && Market.checkout(cart, express, shell.pos())) {
                cart.clear();
                Progress.toast("cutemod.market.ordered");
                setTab(3);
            }
            return;
        }
        List<Map.Entry<String, Integer>> rows = new java.util.ArrayList<>(cart.entrySet());
        for (int i = 0; i < rows.size(); i++) {
            int ry = HEAD + 4 + i * 17 - scroll;
            if (ry > 124 || ry < HEAD - 14) continue;
            String id = rows.get(i).getKey();
            int q = rows.get(i).getValue();
            if (in(x, y, 156, ry + 2, 12, 12)) {
                if (q <= 1) cart.remove(id); else cart.put(id, q - 1);
                return;
            }
            if (in(x, y, 194, ry + 2, 12, 12) && q < Math.min(9, Market.item(id).maxQty())) { cart.put(id, q + 1); return; }
        }
    }

    private void clickOrders(int x, int y) {
        List<Market.Order> list = Market.orders();
        for (int i = 0; i < list.size(); i++) {
            int ry = HEAD + 3 + i * 24 - scroll;
            if (Market.arrived(list.get(i)) && in(x, y, W - 76, ry + 3, 68, 17)) {
                Market.collect(shell.pos());
                Progress.toast("cutemod.market.collected");
                return;
            }
        }
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        return tab == 1 && home.key(keyCode);
    }

    @Override
    public boolean scroll(double amount) {
        if (tab == 1) { home.scroll(amount); return true; }
        if (tab == 0) {
            int pages = Math.max(1, (Market.items(shopKind).size() + PAGE - 1) / PAGE);
            page = Math.max(0, Math.min(pages - 1, page - (int) Math.signum(amount)));
            return true;
        }
        int rows = switch (tab) {
            case 2 -> cart.size() * 17 - (121 - HEAD - 4);
            case 3 -> Market.orders().size() * 24 - (H - HEAD - 3);
            default -> 0;
        };
        scroll = Math.max(0, Math.min(Math.max(0, rows), scroll - (int) Math.signum(amount) * 14));
        return tab != 0;
    }
}
