package dev.cutemod.client.os;

import dev.cutemod.data.PcHardware;
import net.minecraft.client.Minecraft;

import java.util.Locale;
import java.util.UUID;

/**
 * The random hardware of this player's computer. Everybody gets a different PC, but it never changes for a player:
 * it is worked out from the player's id, so it needs no saving and is the same on every screen (the Explorer, the
 * terminal). The brands are made up. Parts installed from CuteMarket (see PcHardware) are added on top. Shown in the Explorer ("This PC") and by the terminal command "sysinfo".
 */
public final class PcSpecs {
    private PcSpecs() {}

    /** diskD = 0 when the PC has no second drive; usedDPct = how full that drive is; baseGb = what the system takes of C:.
     *  gpuTier / ramIdx / diskIdx are the levels of the parts (see PcHardware): the upgrades bought in CuteMarket are already in. */
    public record Spec(String pcName, String cpu, int cores, double ghz, int ramGb, String gpu, int vramGb,
                       int diskC, int diskD, int usedDPct, int baseGb, double score, int gpuTier, int ramIdx, int diskIdx, int modemIdx) {}

    private static final String[] CPU = {"Pixelon Bee 3", "Pixelon Bee 5", "Pixelon Bee 7", "Honeycore Q9", "Panda Ultra X"};

    private static Spec cached;
    private static UUID cachedFor;
    private static String cachedHw;
    private static int hwStamp;

    /** Changes whenever the hardware may have changed (a new world, an installed part): the things that depend on it look again. */
    public static int version() { return Store.gen() * 31 + hwStamp; }

    /** An upgrade was installed (the server told us): the specs are worked out again. */
    public static void hardwareChanged(String hw) {
        Store.setLocal("hw", hw == null ? "" : hw);
        hwStamp++;
        cached = null;
    }

    /** The specs of the player on this screen: the random PC plus every part the player has installed. */
    public static Spec get() {
        var p = Minecraft.getInstance().player;
        UUID id = p == null ? null : p.getUUID();
        String hw = Store.read("hw");
        if (cached != null && java.util.Objects.equals(cachedFor, id) && java.util.Objects.equals(cachedHw, hw)) return cached;
        Spec s = make(PcHardware.seedOf(id), PcHardware.parse(hw));
        if (id != null) { cached = s; cachedFor = id; cachedHw = hw; }
        return s;
    }

    private static Spec make(long seed, int[] hw) {
        PcHardware.Base b = PcHardware.base(seed);
        int ramIdx = PcHardware.effective(b, hw, PcHardware.Kind.RAM);
        int gpuTier = PcHardware.effective(b, hw, PcHardware.Kind.GPU);
        int cIdx = PcHardware.effective(b, hw, PcHardware.Kind.DISK);
        int modem = PcHardware.effective(b, hw, PcHardware.Kind.MODEM);          // -1 = no modem
        int diskC = PcHardware.DISK_GB[cIdx];
        int baseGb = (int) Math.min(b.baseRand(), diskC * 0.4);
        double raw = b.cpuTier() / 4.0 * 3.0 + ramIdx / 5.0 * 3.0 + gpuTier / 7.0 * 3.0 + (cIdx >= 2 ? 0.3 : 0.0);
        double score = Math.max(1.0, Math.min(9.9, Math.round((1.0 + raw) * 10.0) / 10.0));
        String name = "CUTE-PC-" + String.format(Locale.ROOT, "%04X", (int) ((seed ^ (seed >>> 32)) & 0xFFFF));
        return new Spec(name, CPU[b.cpuTier()], b.cores(), b.ghz(), PcHardware.RAM_GB[ramIdx], PcHardware.GPU_NAMES[gpuTier],
                PcHardware.VRAM_GB[gpuTier], diskC, b.diskD(), b.usedDPct(), baseGb, score, gpuTier, ramIdx, cIdx, modem);
    }

    /** "96 GB". */
    public static String gb(int gb) { return gb >= 1000 ? (gb / 1000) + " TB" : gb + " GB"; }

    public static String score(Spec s) { return String.format(Locale.ROOT, "%.1f", s.score()); }
}
