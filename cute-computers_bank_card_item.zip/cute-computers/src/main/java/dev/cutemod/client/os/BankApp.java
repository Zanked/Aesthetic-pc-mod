package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * CuteBank: a phone-bank in the style of the Kazakh banking apps (a red or a green look, tap the colored dot to switch).
 * It is the ONLY place where the balance of coins can be seen. Three tabs:
 * Home (the player's card, the balance, the latest operations), Operations (the whole statement, from {@link BankLog})
 * and the Piggy bank (put coins in, at most 300; after 7 days take them out with 10% more; earlier you get back only
 * what you put in; a new deposit starts the 7 days again). The pig of the piggy bank is the old drawing, it lives in its tab.
 * Saved as "bank": coins inside + time of the last deposit (seconds); "bank_ui": the look and the hidden balance.
 */
public class BankApp extends KitApp {
    private static final int MAX = 300, WEEK_S = 7 * 86400, PERCENT = 10;
    private static final int[] STEPS = {10, 50, 100};

    // the two looks: main, dark, soft tint
    private static final int[][] SKIN = {
            {0xFFF14635, 0xFFC4281A, 0xFFFDE3E0},     // red
            {0xFF0AA24F, 0xFF05763A, 0xFFDDF3E6}};    // green
    private static final int BG = 0xFFF4F4F8, GREY = 0xFF8E8E9A, RULE = 0xFFE6E6EC, GREEN = 0xFF2E9E57, WHITE = 0xFFFFFFFF;

    private static final int NAV_Y = 142, HEAD_H = 22;
    private static final int CARD_HX = 10, CARD_HY = 36;                       // the 3D card on the home tab
    private static final int ROW_H = 18, ROWS = 5, LIST_Y = 46;

    // the piggy bank: the pig is drawn in "pig space" and moved into the panel by (DX, DY)
    private static final int DX = -1, DY = 9;
    private static final int CARD_X = 9, CARD_Y = 19, CARD_W = 112, CARD_H = 110;
    private static final int PIG_X = 65, PIG_Y = 84, FLOOR = PIG_Y + 33;
    private static final int RX = 130, RW = 158;

    private static final int GOLD = 0xFFFFD34E, GOLD_DARK = 0xFFD68A10;
    private static final int BODY = 0xFFFFB6CB, SHADE = 0xFFF59AB6, LIGHT = 0xFFFFD8E4, LINE = 0xFFD9708C;
    private static final int SNOUT = 0xFFFF94B4, NOSTRIL = 0xFFB04A68, DARK = 0xFF3A2A3A;

    /** A little thing that flies around: kind 0 = a coin falling into the slot, 1 = sparkle, 2 = heart, 3 = a coin that jumps out. */
    private static final class Part {
        float x, y, vx, vy;
        int age, life, kind, color;

        Part(float x, float y, float vx, float vy, int age, int life, int kind, int color) {
            this.x = x; this.y = y; this.vx = vx; this.vy = vy;
            this.age = age; this.life = life; this.kind = kind; this.color = color;
        }
    }

    private final Random rnd = new Random();
    private final List<Part> parts = new ArrayList<>();
    private final List<int[]> queue = new ArrayList<>();     // sounds that wait for their turn: {delay, kind, pitch * 100, volume * 100}

    private int inside;
    private long since;
    private boolean loaded;
    private int hop, shake, oinkT, arrivals;
    private int idleOink = 700 + rnd.nextInt(900);

    private int tab, skin, filter, scroll;
    private boolean hide;
    private final BankCard card = new BankCard();             // the 3D card (it turns round when you tap it)

    private String cardNo = "9000 0000 0000 0000", holder = "PLAYER", expiry = "12/30", cvv = "123";

    @Override protected int accent() { return SKIN[skin][0]; }

    @Override protected String id() { return "bank"; }

    @Override
    public void attach(Shell shell) { super.attach(shell); load(); }

    private void load() {
        loaded = true;
        inside = 0;
        since = 0;
        try {
            String s = Store.read("bank");
            if (s != null) { String[] p = s.split(","); inside = Math.max(0, Math.min(MAX, Integer.parseInt(p[0]))); since = Long.parseLong(p[1]); }
        } catch (Exception ignored) { }
        try {
            String s = Store.read("bank_ui");
            if (s != null) { String[] p = s.split(","); skin = Math.max(0, Math.min(SKIN.length - 1, Integer.parseInt(p[0]))); hide = "1".equals(p[1]); }
        } catch (Exception ignored) { }
        try {                                                  // the card belongs to the player: the same number every time
            var user = Minecraft.getInstance().getUser();
            Random r = new Random(user.getName().hashCode() * 2654435761L + 17);
            StringBuilder no = new StringBuilder("9000");
            for (int i = 0; i < 12; i++) { if (i % 4 == 0) no.append(' '); no.append(r.nextInt(10)); }
            cardNo = no.toString();
            cvv = Integer.toString(100 + r.nextInt(900));
            expiry = String.format(Locale.ROOT, "%02d/%02d", 1 + r.nextInt(12), 29 + r.nextInt(2));
            holder = user.getName().toUpperCase(Locale.ROOT);
        } catch (Exception ignored) { }
    }

    private void save() { Store.write("bank", inside + "," + since); }

    private void saveUi() { Store.write("bank_ui", skin + "," + (hide ? "1" : "0")); }

    private static long now() { return System.currentTimeMillis() / 1000; }

    private long left() { return Math.max(0, since + WEEK_S - now()); }

    private boolean ripe() { return inside > 0 && left() == 0; }

    private int interest() { return inside * PERCENT / 100; }

    // ---------- words ----------

    /** "1 монета", "2 монеты", "5 монет" (English: "1 coin", "2 coins"). */
    private static String coins(int n) {
        String form;
        if ("ru".equals(t("cutemod.bank.lang"))) {
            int m10 = n % 10, m100 = n % 100;
            form = m10 == 1 && m100 != 11 ? "one" : (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) ? "few" : "many";
        } else {
            form = n == 1 ? "one" : "many";
        }
        return t("cutemod.bank.coins." + form, n);
    }

    /** Cuts a text into lines that fit maxW pixels; whatever does not fit in maxLines ends with "...". */
    private static List<String> wrap(Font f, String s, int maxW, int maxLines) {
        List<String> all = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : s.split(" ")) {
            String test = cur.length() == 0 ? w : cur + " " + w;
            if (cur.length() == 0 || CuteFont.width(f, test) <= maxW) {
                cur.setLength(0);
                cur.append(test);
            } else {
                all.add(cur.toString());
                cur.setLength(0);
                cur.append(w);
            }
        }
        if (cur.length() > 0) all.add(cur.toString());
        if (all.size() > maxLines) {
            StringBuilder rest = new StringBuilder();
            for (int i = maxLines - 1; i < all.size(); i++) rest.append(i > maxLines - 1 ? " " : "").append(all.get(i));
            List<String> cut = new ArrayList<>(all.subList(0, maxLines - 1));
            cut.add(CuteFont.cut(f, rest.toString(), maxW));
            return cut;
        }
        return all;
    }

    private static void lines(GuiGraphics g, Font f, List<String> lines, int x, int y, int color) {
        for (int i = 0; i < lines.size(); i++) CuteFont.draw(g, f, lines.get(i), x, y + i * 9, color, false);
    }

    /** 12345 -> "12 345". */
    private static String fmt(int n) {
        String s = Integer.toString(Math.abs(n));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && (s.length() - i) % 3 == 0) sb.append(' ');
            sb.append(s.charAt(i));
        }
        return (n < 0 ? "-" : "") + sb;
    }

    private static String when(long t) {
        return LocalDateTime.ofInstant(Instant.ofEpochSecond(t), ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd.MM HH:mm"));
    }

    // ---------- sounds ----------

    private void queueSound(int delay, int kind, float pitch, float vol) {
        queue.add(new int[]{delay, kind, Math.round(pitch * 100), Math.round(vol * 100)});
    }

    private static void play(int kind, float pitch, float vol) {
        switch (kind) {
            case 0 -> Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), pitch, vol);        // a coin clinks
            case 1 -> Sfx.ui(SoundEvents.PIG_AMBIENT, pitch, vol);                    // oink
            case 2 -> Sfx.ui(SoundEvents.AMETHYST_BLOCK_CHIME, pitch, vol);           // sparkle
            case 3 -> Sfx.ui(SoundEvents.PLAYER_LEVELUP, pitch, vol);                 // happy fanfare
            case 4 -> Sfx.ui(SoundEvents.EXPERIENCE_ORB_PICKUP, pitch, vol);          // coins pour out
            default -> Sfx.ui(SoundEvents.NOTE_BLOCK_BASS.value(), pitch, vol);       // a sad low note
        }
    }

    // ---------- actions ----------

    private int slotX() { return PIG_X + 14; }

    private int slotY() { return PIG_Y - 21; }

    private void sparkle(float x, float y, int color) {
        parts.add(new Part(x, y, (rnd.nextFloat() - 0.5F) * 1.2F, -0.3F - rnd.nextFloat() * 0.8F, 0, 18 + rnd.nextInt(10), 1, color));
    }

    private void heartAt(float x, float y) {
        parts.add(new Part(x, y, (rnd.nextFloat() - 0.5F) * 0.6F, -0.5F, 0, 42, 2, 0xFFFF5C8A));
    }

    private void oink(float vol, boolean love) {
        oinkT = 50;
        queueSound(0, 1, 1.0F + rnd.nextFloat() * 0.5F, vol);
        if (love) {
            hop = Math.max(hop, 12);
            heartAt(PIG_X - 12 + rnd.nextInt(30), PIG_Y - 38);
            heartAt(PIG_X - 12 + rnd.nextInt(30), PIG_Y - 38);
        }
    }

    private void deposit(int n) {
        int room = MAX - inside;
        n = Math.min(n, room);
        if (n <= 0) { say("cutemod.bank.msg.full", MAX); Sfx.error(); return; }
        if (!Progress.bankOut(n, "cutemod.bank.src.deposit")) { say("cutemod.bank.msg.nocoins"); Sfx.error(); shake = 12; return; }
        inside += n;
        since = now();                                           // a new deposit starts the week again
        save();
        int c = n >= 100 ? 4 : n >= 50 ? 3 : 2;                  // a bigger deposit is more coins
        for (int i = 0; i < c; i++) parts.add(new Part(slotX() + rnd.nextInt(5) - 2, CARD_Y + 3, 0, 2.7F, -i * 5, 0, 0, 0));
        queueSound(5 * (c - 1) + 24, 1, 1.6F + rnd.nextFloat() * 0.3F, 0.4F);      // a happy little oink after the last coin
        if (inside >= MAX) {                                     // full to the brim
            queueSound(40, 2, 1.4F, 0.5F);
            queueSound(46, 2, 1.8F, 0.5F);
            queueSound(52, 2, 2.0F, 0.5F);
            for (int i = 0; i < 3; i++) heartAt(PIG_X - 14 + i * 14, PIG_Y - 38 - i * 2);
        }
        say("cutemod.bank.msg.in", coins(n));
    }

    private void withdraw() {
        if (inside <= 0) return;
        boolean early = !ripe();
        int bonus = early ? 0 : interest();
        int back = inside + bonus;
        Progress.bankIn(back, bonus, early ? "cutemod.bank.src.withdraw" : "cutemod.bank.src.interest");
        inside = 0;
        since = 0;
        save();
        shake = 22;
        hop = 20;
        int c = Math.min(14, 4 + back / 25);                     // the coins jump out of the slot
        for (int i = 0; i < c; i++) {
            parts.add(new Part(slotX(), slotY(), (rnd.nextFloat() - 0.5F) * 3.4F, -2.4F - rnd.nextFloat() * 2.2F, -i / 2, 46 + rnd.nextInt(14), 3, 0));
        }
        for (int i = 0; i < Math.min(6, c); i++) queueSound(i * 3, 0, 1.2F + rnd.nextFloat() * 0.9F, 0.5F);
        queueSound(0, 4, 1.0F, 0.5F);
        if (early) {                                             // a sad pig: nothing extra
            queueSound(10, 5, 0.7F, 0.6F);
            queueSound(16, 5, 0.55F, 0.6F);
            queueSound(22, 1, 0.6F, 0.5F);
        } else {                                                 // a happy pig with a crown
            queueSound(8, 3, 1.5F, 0.5F);
            queueSound(14, 2, 1.6F, 0.5F);
            queueSound(20, 2, 2.0F, 0.5F);
            queueSound(26, 1, 1.5F, 0.5F);
            for (int i = 0; i < 4; i++) heartAt(PIG_X - 24 + i * 14, PIG_Y - 36);
            for (int i = 0; i < 8; i++) sparkle(PIG_X - 30 + rnd.nextInt(60), PIG_Y - 30 + rnd.nextInt(30), GOLD);
        }
        oinkT = 60;
        say(early ? "cutemod.bank.msg.early" : "cutemod.bank.msg.out", coins(back));
    }

    private void setTab(int t) {
        if (t == tab) return;
        tab = t;
        scroll = 0;
        card.reset();
        Sfx.click();
    }

    @Override
    public void tick() {
        super.tick();
        if (hop > 0) hop--;
        if (shake > 0) shake--;
        if (oinkT > 0) oinkT--;
        if (--idleOink <= 0) { idleOink = 1500 + rnd.nextInt(2400); if (tab == 2) oink(0.3F, false); }
        if (tab == 2 && loaded && ripe() && ticks % 16 == 0) sparkle(PIG_X - 30 + rnd.nextInt(60), PIG_Y - 22 - rnd.nextInt(16), GOLD);

        for (int i = parts.size() - 1; i >= 0; i--) {
            Part p = parts.get(i);
            if (++p.age < 0) continue;
            if (p.kind == 0) {                                   // falls until it is in the slot
                p.y += p.vy;
                if (p.y >= slotY()) {
                    parts.remove(i);
                    hop = Math.max(hop, 14);
                    queueSound(0, 0, 1.4F + 0.2F * (arrivals++ % 4), 0.55F);
                    sparkle(slotX(), slotY(), GOLD);
                    sparkle(slotX(), slotY(), 0xFFFFFFFF);
                }
                continue;
            }
            p.x += p.vx;
            p.y += p.vy;
            if (p.kind == 3) p.vy += 0.18F;
            if (p.age >= p.life || p.y > CARD_Y + CARD_H) parts.remove(i);
        }

        for (int i = queue.size() - 1; i >= 0; i--) {
            int[] s = queue.get(i);
            if (--s[0] <= 0) {
                play(s[1], s[2] / 100F, s[3] / 100F);
                queue.remove(i);
            }
        }
    }

    // ---------- drawing helpers ----------

    private static void ell(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            double q = 1.0 - (dy * (double) dy) / (ry * (double) ry);
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0, q)));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** A triangle pointing up: the tip at (tipX, tipY), h rows tall, the last row 2 * half + 1 wide and moved by shift. */
    private static void tri(GuiGraphics g, int tipX, int tipY, int half, int h, int shift, int argb) {
        for (int i = 0; i < h; i++) {
            double t = (i + 1) / (double) h;
            int hw = (int) Math.round(half * t);
            int c = tipX + (int) Math.round(shift * t);
            g.fill(c - hw, tipY + i, c + hw + 1, tipY + i + 1, argb);
        }
    }

    private static void coin(GuiGraphics g, int cx, int cy, int rx, int ry) {
        ell(g, cx, cy, rx, ry, GOLD_DARK);
        if (rx > 1) ell(g, cx, cy, rx - 1, ry - 1, GOLD);
        if (rx > 2) rect(g, cx - 1, cy - 1, 1, 2, 0xFFFFF2B0);
    }

    private static void star(GuiGraphics g, int x, int y, int argb) {
        rect(g, x - 1, y, 3, 1, argb);
        rect(g, x, y - 1, 1, 3, argb);
    }

    private static void heart(GuiGraphics g, int x, int y, int argb) {
        rect(g, x, y, 2, 1, argb);
        rect(g, x + 3, y, 2, 1, argb);
        rect(g, x, y + 1, 5, 2, argb);
        rect(g, x + 1, y + 3, 3, 1, argb);
        rect(g, x + 2, y + 4, 1, 1, argb);
    }

    private static void leg(GuiGraphics g, int x, int top, int bottom, int col, int hoof) {
        roundRect(g, x, top, 9, bottom - top, 3, col);
        roundRect(g, x, bottom - 5, 9, 5, 2, hoof);
    }

    /** A rounded box that fades from c1 (top) to c2 (bottom). */
    private static void gradRound(GuiGraphics g, int x, int y, int w, int h, int r, int c1, int c2) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int dy = 0; dy < h; dy++) {
            double m = dy + 0.5;
            double e = m < r ? r - m : m > h - r ? m - (h - r) : 0;
            int inset = e > 0 ? (int) Math.round(r - Math.sqrt(Math.max(0, r * r - e * e))) : 0;
            g.fill(x + inset, y + dy, x + w - inset, y + dy + 1, mix(c1, c2, h <= 1 ? 0F : dy / (float) (h - 1)));
        }
    }

    private static void grad(GuiGraphics g, int x, int y, int w, int h, int c1, int c2) {
        for (int dy = 0; dy < h; dy++) g.fill(x, y + dy, x + w, y + dy + 1, mix(c1, c2, h <= 1 ? 0F : dy / (float) (h - 1)));
    }

    /** A circle that is cut by a box (for the soft shapes on the card). */
    private static void discIn(GuiGraphics g, int cx, int cy, int r, int argb, int x0, int y0, int x1, int y1) {
        for (int dy = -r; dy <= r; dy++) {
            int y = cy + dy;
            if (y < y0 || y >= y1) continue;
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            int a = Math.max(x0, cx - dx), b = Math.min(x1, cx + dx + 1);
            if (b > a) g.fill(a, y, b, y + 1, argb);
        }
    }

    private void eye(GuiGraphics g, int x, int y, boolean closed) {
        int[] c = SKIN[skin];
        ell(g, x + 7, y + 4, 7, 4, WHITE);
        ell(g, x + 7, y + 4, 5, 2, c[1]);
        rect(g, x + 6, y + 3, 3, 3, WHITE);
        if (closed) for (int i = 0; i < 10; i++) { rect(g, x + 2 + i, y + 8 - i * 7 / 9, 2, 1, WHITE); }
    }

    /** The round switch of the look: half red, half green. */
    private void skinDot(GuiGraphics g, int cx, int cy) {
        disc(g, cx, cy, 6, WHITE);
        for (int dy = -4; dy <= 4; dy++) {
            int dx = (int) Math.floor(Math.sqrt(16 - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx, cy + dy + 1, SKIN[0][0]);
            g.fill(cx, cy + dy, cx + dx + 1, cy + dy + 1, SKIN[1][0]);
        }
    }

    private void arrow(GuiGraphics g, int cx, int cy, boolean up, int argb) {
        if (up) {
            rect(g, cx, cy - 3, 1, 1, argb); rect(g, cx - 1, cy - 2, 3, 1, argb); rect(g, cx - 2, cy - 1, 5, 1, argb); rect(g, cx, cy, 1, 3, argb);
        } else {
            rect(g, cx, cy + 3, 1, 1, argb); rect(g, cx - 1, cy + 2, 3, 1, argb); rect(g, cx - 2, cy + 1, 5, 1, argb); rect(g, cx, cy - 3, 1, 3, argb);
        }
    }

    private void navIcon(GuiGraphics g, int i, int x, int y, int c) {
        switch (i) {
            case 0 -> {                                                    // home
                rect(g, x + 4, y, 2, 1, c); rect(g, x + 3, y + 1, 4, 1, c); rect(g, x + 2, y + 2, 6, 1, c);
                rect(g, x + 1, y + 3, 8, 1, c); rect(g, x, y + 4, 10, 1, c);
                rect(g, x + 1, y + 5, 8, 5, c); rect(g, x + 4, y + 7, 2, 3, BG);
            }
            case 1 -> {                                                    // list
                for (int k = 0; k < 3; k++) { rect(g, x, y + 1 + k * 4, 2, 2, c); rect(g, x + 3, y + 1 + k * 4, 7, 2, c); }
            }
            default -> {                                                   // a coin
                disc(g, x + 5, y + 5, 5, c); disc(g, x + 5, y + 5, 3, WHITE); rect(g, x + 4, y + 3, 2, 5, c);
            }
        }
    }

    // ---------- the screen ----------

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        rect(g, 0, 0, W, H, BG);
        switch (tab) {
            case 0 -> home(g, f, mx, my);
            case 1 -> ops(g, f, mx, my);
            default -> piggy(g, f, mx, my);
        }
        nav(g, f, mx, my);
        toast(g, f);
    }

    /** The coloured top of every page: the logo, the name, the eye (hides the numbers) and the dot (changes the look). */
    private void topBar(GuiGraphics g, Font f, int h, String title) {
        int[] c = SKIN[skin];
        grad(g, 0, 0, W, h, c[0], c[1]);
        disc(g, 14, 11, 7, WHITE);
        disc(g, 14, 11, 5, c[0]);
        rect(g, 13, 8, 2, 6, WHITE);
        rect(g, 11, 10, 6, 2, WHITE);
        CuteFont.draw(g, f, title, 26, 7, WHITE, false);
        eye(g, W - 40, 6, hide);
        skinDot(g, W - 14, 11);
    }

    private void nav(GuiGraphics g, Font f, int mx, int my) {
        int[] c = SKIN[skin];
        rect(g, 0, NAV_Y, W, H - NAV_Y, WHITE);
        rect(g, 0, NAV_Y, W, 1, RULE);
        String[] names = {t("cutemod.bank.tab.home"), t("cutemod.bank.tab.ops"), t("cutemod.bank.tab.save")};
        for (int i = 0; i < 3; i++) {
            int cx = 50 + i * 100;
            boolean on = tab == i;
            int col = on ? c[0] : GREY;
            if (on) rect(g, cx - 14, NAV_Y + 1, 28, 2, c[0]);
            navIcon(g, i, cx - 5, NAV_Y + 5, col);
            String s = names[i];
            CuteFont.draw(g, f, s, cx - CuteFont.width(f, s) / 2, NAV_Y + 15, col, false);
        }
    }

    // ---------- tab 1: home ----------

    private void home(GuiGraphics g, Font f, int mx, int my) {
        int[] c = SKIN[skin];
        topBar(g, f, HEAD_H, t("cutemod.bank.name"));

        // the 3D card: the balance lives on it
        String amt = hide ? "****" : fmt(Progress.coins());
        String no = hide ? "**** **** **** ****" : "**** **** **** " + cardNo.substring(cardNo.length() - 4);
        card.render(g, f, mx, my, CARD_HX, CARD_HY, new BankCard.Info(c[0], c[1], c[2],
                t("cutemod.bank.name"), t("cutemod.bank.balance"), amt, t("cutemod.bank.unit"),
                no, holder, expiry, cvv, t("cutemod.bank.cvv"), t("cutemod.bank.valid")));

        // the latest operations
        List<BankLog.Op> ops = BankLog.list();
        fitText(g, f, t("cutemod.bank.recent"), 170, 30, 122, TEXT, false);
        if (ops.isEmpty()) {
            fitText(g, f, t("cutemod.bank.noops"), 170 + 61, 76, 118, GREY, true);
        }
        for (int i = 0; i < Math.min(5, ops.size()); i++) opRow(g, f, ops.get(i), 170, 42 + i * 16, 122, 16);
        boolean hov = in(mx, my, 170, 124, 122, 12);
        String all = t("cutemod.bank.all") + " >";
        CuteFont.draw(g, f, all, 170, 126, hov ? mix(c[0], 0x000000, 0.2F) : c[0], false);
    }

    /** One line of the statement: a round arrow, what it was, when, and the amount. */
    private void opRow(GuiGraphics g, Font f, BankLog.Op o, int x, int y, int w, int h) {
        int[] c = SKIN[skin];
        boolean in = o.amount() > 0;
        int cy = y + h / 2;
        disc(g, x + 6, cy, 6, in ? 0xFFDDF3E6 : c[2]);
        arrow(g, x + 6, cy, in, in ? GREEN : c[0]);
        int ax = x + w;
        String a = hide ? "***" : (in ? "+" : "") + fmt(o.amount());
        int aw = CuteFont.width(f, a);
        CuteFont.draw(g, f, a, ax - aw, cy - 4, in ? GREEN : TEXT, false);
        fitText(g, f, BankLog.text(o), x + 17, y + 1, w - 17 - aw - 4, TEXT, false);
        CuteFont.drawSmall(g, f, when(o.time()), x + 17, y + h - 7, GREY);
    }

    // ---------- tab 2: operations ----------

    private List<BankLog.Op> view() {
        List<BankLog.Op> out = new ArrayList<>();
        for (BankLog.Op o : BankLog.list()) if (filter == 0 || (filter == 1) == (o.amount() > 0)) out.add(o);
        return out;
    }

    private void ops(GuiGraphics g, Font f, int mx, int my) {
        int[] c = SKIN[skin];
        topBar(g, f, HEAD_H, t("cutemod.bank.ops.title"));
        String[] names = {t("cutemod.bank.f.all"), t("cutemod.bank.f.in"), t("cutemod.bank.f.out")};
        for (int i = 0; i < 3; i++) {
            int x = 8 + i * 60;
            boolean on = filter == i, hov = in(mx, my, x, 28, 56, 13);
            roundRect(g, x, 28, 56, 13, 6, on ? c[0] : hov ? mix(c[2], 0x000000, 0.06F) : c[2]);
            fitText(g, f, names[i], x + 28, 30, 50, on ? WHITE : c[0], true);
        }
        List<BankLog.Op> list = view();
        int maxScroll = Math.max(0, list.size() - ROWS);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        roundRect(g, 6, LIST_Y - 2, W - 12, ROWS * ROW_H + 4, 5, WHITE);
        if (list.isEmpty()) {
            fitText(g, f, t("cutemod.bank.noops"), W / 2, LIST_Y + 38, 200, GREY, true);
            return;
        }
        for (int i = 0; i < ROWS; i++) {
            int idx = scroll + i;
            if (idx >= list.size()) break;
            int y = LIST_Y + i * ROW_H;
            if (i > 0) rect(g, 12, y, W - 24, 1, RULE);
            opRow(g, f, list.get(idx), 12, y + 1, W - 30, ROW_H - 1);
        }
        if (maxScroll > 0) {                                                           // the scroll bar
            int th = Math.max(8, ROWS * ROW_H * ROWS / list.size());
            int ty = LIST_Y + (ROWS * ROW_H - th) * scroll / maxScroll;
            rect(g, W - 12, LIST_Y, 3, ROWS * ROW_H, RULE);
            rect(g, W - 12, ty, 3, th, c[0]);
        }
    }

    // ---------- tab 3: the piggy bank ----------

    private void piggy(GuiGraphics g, Font f, int mx, int my) {
        int[] c = SKIN[skin];
        // the pig's own little room (the pig is drawn where it always was, then moved into the panel)
        g.pose().pushPose();
        g.pose().translate(DX, DY, 0);
        piggyCard(g);
        pig(g, f, in(mx - DX, my - DY, PIG_X - 42, PIG_Y - 34, 84, 70));
        g.pose().popPose();

        // the white card on the right hides the coins that fly out of the pig's room
        roundRect(g, RX - 6, 28, RW + 12, 110, 6, WHITE);
        CuteFont.draw(g, f, t("cutemod.bank.inside"), RX, 33, GREY, false);
        coin(g, RX + 6, 52, 5, 5);
        g.pose().pushPose();                                                              // the big number
        g.pose().translate(RX + 16, 46, 0);
        g.pose().scale(1.5F, 1.5F, 1F);
        CuteFont.draw(g, f, inside + " / " + MAX, 0, 0, TEXT, false);
        g.pose().popPose();

        if (inside > 0) {
            long l = left();
            float p = Math.max(0F, Math.min(1F, 1F - l / (float) WEEK_S));
            roundRect(g, RX, 62, RW, 6, 3, RULE);
            if (p > 0F) roundRect(g, RX, 62, Math.max(6, Math.round(RW * p)), 6, 3, ripe() ? GREEN : c[0]);
            String st;
            if (ripe()) st = t("cutemod.bank.ripe", interest());
            else if (l >= 3600 * 24) st = t("cutemod.bank.wait", l / 86400, l / 3600 % 24);
            else st = t("cutemod.bank.wait.short", l / 3600, l / 60 % 60);
            lines(g, f, wrap(f, st, RW, 2), RX, 72, ripe() ? 0xFF3E9A4A : GREY);
        } else {
            lines(g, f, wrap(f, t("cutemod.bank.empty", PERCENT), RW, 2), RX, 65, GREY);
        }

        for (int i = 0; i < STEPS.length; i++) {
            bbtn(g, f, mx, my, RX + i * 54, 92, 50, "+" + STEPS[i], Progress.coins() >= STEPS[i] && inside < MAX ? 0 : 2);
        }
        String take = inside > 0 ? (ripe() ? t("cutemod.bank.take", inside + interest()) : t("cutemod.bank.takeearly", inside)) : t("cutemod.bank.nothing");
        bbtn(g, f, mx, my, RX, 112, RW, take, inside > 0 ? (ripe() ? 1 : 0) : 2);
        lines(g, f, wrap(f, t("cutemod.bank.rule", PERCENT), RW, 1), RX, 130, GREY);
        topBar(g, f, HEAD_H, t("cutemod.bank.tab.save"));                                 // last: it covers whatever flew up
    }

    /** style 0 soft, 1 main, 2 dimmed. */
    private void bbtn(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, String label, int style) {
        int[] c = SKIN[skin];
        boolean hov = style != 2 && in(mx, my, x, y, w, 16);
        int bg = style == 1 ? (hov ? c[1] : c[0]) : style == 2 ? 0xFFEDEDF2 : hov ? mix(c[2], 0x000000, 0.07F) : c[2];
        roundRect(g, x, y, w, 16, 5, bg);
        int fg = style == 1 ? WHITE : style == 2 ? 0xFFB4B4C0 : c[0];
        fitText(g, f, label, x + w / 2, y + 4, w - 6, fg, true);
    }

    /** The soft box the pig lives in. */
    private void piggyCard(GuiGraphics g) {
        boolean r = ripe();
        roundRect(g, CARD_X, CARD_Y, CARD_W, CARD_H, 6, r ? 0xFFF5D88A : 0xFFF3C9DE);
        roundRect(g, CARD_X + 1, CARD_Y + 1, CARD_W - 2, CARD_H - 2, 5, r ? 0xFFFFF6D6 : 0xFFFFF0F7);
        roundRect(g, CARD_X + 1, FLOOR - 4, CARD_W - 2, CARD_Y + CARD_H - FLOOR + 3, 5, r ? 0xFFFFE9A8 : 0xFFFFDDEB);
        rect(g, CARD_X + 4, FLOOR - 4, CARD_W - 8, 1, r ? 0xFFF5D88A : 0xFFF3C9DE);
        int[][] sp = {{20, 31}, {113, 38}, {104, 62}, {17, 74}};
        for (int i = 0; i < sp.length; i++) {
            int ph = (ticks + i * 27) % 100;
            if (ph < 55) star(g, CARD_X + sp[i][0] - 6, sp[i][1], ph < 12 || ph > 43 ? 0x88FFFFFF : r ? 0xFFFFD34E : 0xFFFFC2D8);
        }
    }

    private void pig(GuiGraphics g, Font f, boolean hover) {
        int bob = (int) Math.round(Math.sin(ticks / 22.0) * 1.2);                         // it breathes
        int jump = hop > 0 ? (int) Math.round(Math.sin(hop / 20.0 * Math.PI) * 7) : 0;
        int sx = shake > 0 ? (int) Math.round(Math.sin(shake * 1.7) * 2.5) : 0;
        int cx = PIG_X + sx, cy = PIG_Y + bob - jump;
        boolean happy = hop > 0 || oinkT > 0 || hover || ripe();
        boolean blink = !happy && ticks % 230 < 7;

        ell(g, PIG_X, FLOOR + 1, 31 - jump * 2, 4, 0x40C0607A);                           // the shadow stays on the floor

        // the coins that lie around the pig: one more for every 50 inside
        int stacks = Math.min(6, (inside + 49) / 50);
        for (int i = 0; i < stacks; i++) coin(g, 107 + (i / 3) * 12, FLOOR - (i % 3) * 3, 5, 2);

        particles(g, true);                                                               // falling coins go in behind the body

        // legs: the far ones are darker; the feet stay on the floor while the body breathes
        int top = cy + 17, bottom = FLOOR - jump;
        leg(g, cx - 9, top, bottom, 0xFFE98BA8, 0xFFB85472);
        leg(g, cx + 21, top, bottom, 0xFFE98BA8, 0xFFB85472);
        leg(g, cx - 23, top, bottom, SHADE, 0xFFC9607F);
        leg(g, cx + 9, top, bottom, SHADE, 0xFFC9607F);

        // the ear (it twitches now and then); the body covers its base
        int ey = ticks % 220 < 6 ? 1 : 0;
        tri(g, cx - 19, cy - 34 + ey, 8, 14, 9, LINE);
        tri(g, cx - 19, cy - 33 + ey, 7, 13, 9, BODY);
        tri(g, cx - 18, cy - 30 + ey, 3, 8, 6, 0xFFFF8FB0);

        // the body: outline, shade below, fill, shine
        ell(g, cx, cy, 33, 27, LINE);
        ell(g, cx, cy, 31, 25, SHADE);
        ell(g, cx, cy - 2, 31, 23, BODY);
        ell(g, cx - 10, cy - 14, 10, 5, LIGHT);
        ell(g, cx + 9, cy - 17, 4, 2, LIGHT);

        // the curly tail wags (faster when the pig is happy)
        int wag = (int) Math.round(Math.sin(ticks / (happy ? 2.5 : 7.0)) * (happy ? 2 : 1));
        int[][] tail = {{31, -2}, {33, -4}, {35, -6}, {37, -6}, {39, -4}, {39, -2}, {37, 0}, {35, -2}};
        for (int[] t : tail) rect(g, cx + t[0], cy + t[1] + wag, 2, 2, 0xFFE8809C);

        // the face
        ell(g, cx - 23, cy + 5, 5, 3, 0x88FF6F95);                                        // cheek
        int sn = oinkT > 0 && (oinkT / 3) % 2 == 0 ? -1 : 0;                              // the snout twitches while it oinks
        int snx = cx - 33 + sn;
        ell(g, snx, cy + 5, 9, 8, LINE);
        ell(g, snx, cy + 5, 8, 7, SNOUT);
        rect(g, snx - 4, cy + 1, 3, 1, 0x88FFFFFF);
        ell(g, snx - 3, cy + 5, 1, 2, NOSTRIL);
        ell(g, snx + 2, cy + 5, 1, 2, NOSTRIL);
        int ex = cx - 17, ey2 = cy - 6;
        if (happy) {                                                                      // happy eye: ^
            rect(g, ex - 3, ey2 + 1, 2, 2, DARK);
            rect(g, ex - 1, ey2 - 1, 3, 2, DARK);
            rect(g, ex + 2, ey2 + 1, 2, 2, DARK);
        } else if (blink) {
            rect(g, ex - 3, ey2, 7, 1, DARK);
        } else {
            ell(g, ex, ey2, 3, 4, DARK);
            rect(g, ex - 2, ey2 - 3, 2, 2, 0xFFFFFFFF);
            rect(g, ex + 1, ey2 + 1, 1, 1, 0xCCFFFFFF);
            rect(g, ex + 3, ey2 - 4, 2, 1, DARK);                                         // lashes
            rect(g, ex + 4, ey2 - 2, 2, 1, DARK);
        }

        // the coin slot on the back
        if (hop > 0) rect(g, cx + 7, cy - 19, 15, 5, 0x55FFD34E);
        rect(g, cx + 8, cy - 18, 13, 3, NOSTRIL);
        rect(g, cx + 9, cy - 17, 11, 1, 0xFF6A2A40);

        // a bow, or a crown when the interest is ready
        if (ripe()) {
            rect(g, cx - 3, cy - 31, 13, 4, GOLD);
            tri(g, cx - 2, cy - 36, 2, 5, 0, GOLD);
            tri(g, cx + 3, cy - 38, 2, 7, 0, GOLD);
            tri(g, cx + 8, cy - 36, 2, 5, 0, GOLD);
            rect(g, cx + 3, cy - 30, 2, 2, 0xFFE8506E);
        } else {
            ell(g, cx - 2, cy - 28, 5, 4, 0xFFD93A5C);
            ell(g, cx + 8, cy - 28, 5, 4, 0xFFD93A5C);
            ell(g, cx - 2, cy - 28, 4, 3, 0xFFFF6F8C);
            ell(g, cx + 8, cy - 28, 4, 3, 0xFFFF6F8C);
            rect(g, cx - 4, cy - 30, 3, 1, 0xFFFFB3C4);
            rect(g, cx + 6, cy - 30, 3, 1, 0xFFFFB3C4);
            disc(g, cx + 3, cy - 28, 2, 0xFFD93A5C);
            rect(g, cx + 3, cy - 29, 1, 1, 0xFFFF9AB0);
        }

        particles(g, false);

        if (oinkT > 0) {                                                                  // "Oink!" in a bubble
            String s = t("cutemod.bank.oink");
            int tw = CuteFont.width(f, s) + 10, bx = CARD_X + 3, by = PIG_Y - 44;
            roundRect(g, bx - 1, by - 1, tw + 2, 15, 5, LINE);
            roundRect(g, bx, by, tw, 13, 4, 0xFFFFFFFF);
            rect(g, bx + tw - 10, by + 13, 5, 1, 0xFFFFFFFF);
            rect(g, bx + tw - 9, by + 14, 3, 1, 0xFFFFFFFF);
            rect(g, bx + tw - 8, by + 15, 1, 1, 0xFFFFFFFF);
            CuteFont.draw(g, f, s, bx + 5, by + 3, TEXT, false);
        }
    }

    private void particles(GuiGraphics g, boolean behind) {
        for (Part p : parts) {
            if (p.age < 0 || (p.kind == 0) != behind) continue;
            int px = Math.round(p.x), py = Math.round(p.y);
            int a = Math.max(8, Math.min(255, (int) ((1F - p.age / (float) Math.max(1, p.life)) * 400)));
            int rgb = p.color & 0xFFFFFF;
            switch (p.kind) {
                case 0 -> coin(g, px, py, Math.max(1, (int) Math.round(4 * Math.abs(Math.cos(p.age * 0.45)))), 4);
                case 1 -> star(g, px, py, (a << 24) | rgb);
                case 2 -> heart(g, px - 2, py - 2, (a << 24) | rgb);
                default -> coin(g, px, py, Math.max(1, (int) Math.round(3 * Math.abs(Math.cos(p.age * 0.5)))), 3);
            }
        }
    }

    /** The message at the bottom: it fades out. */
    private void toast(GuiGraphics g, Font f) {
        if (msgT <= 0) return;
        String m = CuteFont.cut(f, msg, W - 24);
        int a = Math.min(255, msgT * 12);
        int tw = CuteFont.width(f, m) + 14, tx = (W - tw) / 2;
        roundRect(g, tx, 124, tw, 14, 5, (a << 24) | 0x3A2A3A);
        CuteFont.draw(g, f, m, tx + 7, 127, (a << 24) | 0xFFFFFF, false);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (!loaded) load();
        if (y >= NAV_Y) { setTab(Math.max(0, Math.min(2, x / 100))); return true; }
        if (in(x, y, W - 42, 3, 20, 16)) { hide = !hide; saveUi(); Sfx.click(); return true; }          // the eye
        if (in(x, y, W - 22, 3, 16, 16)) { skin = (skin + 1) % SKIN.length; saveUi(); Sfx.click(); return true; }   // the colored dot
        switch (tab) {
            case 0 -> {
                if (in(x, y, CARD_HX, CARD_HY, BankCard.W, BankCard.H)) { card.flip(); Sfx.click(); return true; }
                if (in(x, y, 170, 124, 122, 12)) { setTab(1); return true; }
            }
            case 1 -> {
                for (int i = 0; i < 3; i++) if (in(x, y, 8 + i * 60, 28, 56, 13)) { filter = i; scroll = 0; Sfx.click(); return true; }
            }
            default -> {
                for (int i = 0; i < STEPS.length; i++) if (in(x, y, RX + i * 54, 92, 50, 16)) { deposit(STEPS[i]); return true; }
                if (in(x, y, RX, 112, RW, 16)) { withdraw(); return true; }
                if (in(x - DX, y - DY, PIG_X - 42, PIG_Y - 34, 84, 70)) { oink(0.7F, true); return true; }   // pet the pig
            }
        }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        if (tab != 1) return false;
        scroll = Math.max(0, scroll - (int) Math.signum(amount));
        return true;
    }
}
