package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import org.joml.Matrix4f;

/**
 * The 3D bank card of {@link BankApp}. It is a real slab: a front and a back face, a thin edge, a soft shadow and a glare
 * that slides over it. The card is turned by a true rotation (yaw round the vertical axis, pitch round the horizontal one)
 * that is put into the pose matrix, so every pixel of the face (shapes and text) follows it.
 * <ul>
 *   <li>the mouse near the card tilts it towards the pointer (away from it the card slowly sways by itself);</li>
 *   <li>{@link #flip()} turns it round (front: balance, number, holder; back: strip, signature, CVV);</li>
 *   <li>all the motion is smoothed by real time, so it is fluid at any frame rate.</li>
 * </ul>
 * Everything the face shows comes in {@link Info}, so a new feature of the card only has to add a field there and draw it
 * in {@link #front} or {@link #back}. Faces are drawn in "card space": (0,0) is the top-left corner, W x H pixels.
 */
final class BankCard {
    static final int W = 150, H = 94, R = 8;
    private static final int DEPTH = 3, LAYERS = 6;
    private static final float MAX_YAW = 0.45F, MAX_PITCH = 0.32F;

    private static final int GOLD = 0xFFFFD34E, GOLD_DARK = 0xFFC9820E, WHITE = 0xFFFFFFFF;

    /** Everything a face needs. main/dark = the colours of the look, soft = its tint. */
    record Info(int main, int dark, int soft,
                String name, String balanceLabel, String balance, String unit,
                String number, String holder, String expiry,
                String cvv, String cvvLabel, String validLabel) {}

    private float yaw, pitch;
    private float flip, flipTarget;                    // 0 = front, 1 = back
    private float idle;
    private long last = System.nanoTime();

    void flip() { flipTarget = flipTarget > 0.5F ? 0F : 1F; }

    void reset() { flipTarget = 0F; }

    // ---------- the 3D part ----------

    /** Draws the card with its top-left corner (x, y) at rest. mx, my = the mouse in the app. */
    void render(GuiGraphics g, Font f, int mx, int my, int x, int y, Info in) {
        long now = System.nanoTime();
        float dt = Math.min(0.1F, (now - last) / 1e9F);
        last = now;
        idle += dt;

        float cx = x + W / 2F, cy = y + H / 2F;
        float ty, tp;
        if (Math.abs(mx - cx) < W * 1.1F && Math.abs(my - cy) < H * 1.3F) {      // the pointer is near: the card looks at it
            ty = clamp((mx - cx) / (W * 0.9F)) * MAX_YAW;
            tp = clamp((cy - my) / (H * 1.1F)) * MAX_PITCH;
        } else {                                                                  // nobody there: a slow sway
            ty = (float) Math.sin(idle * 0.9) * 0.17F;
            tp = (float) Math.cos(idle * 0.7) * 0.07F + 0.04F;
        }
        float k = 1F - (float) Math.exp(-dt * 9F);
        yaw += (ty - yaw) * k;
        pitch += (tp - pitch) * k;

        if (flip < flipTarget) flip = Math.min(flipTarget, flip + dt * 1.8F);
        else if (flip > flipTarget) flip = Math.max(flipTarget, flip - dt * 1.8F);
        float e = flip * flip * (3F - 2F * flip);                                  // ease in-out

        float a = e * (float) Math.PI + yaw;
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        int sgn = c >= 0 ? 1 : -1;                                                 // which face looks at us
        float cp = (float) Math.cos(pitch), sp = (float) Math.sin(pitch);
        float lift = 1F + 0.07F * (float) Math.sin(e * Math.PI);                  // it rises a little while it turns

        float A = sgn * c * lift;                                                  // screen x of the card's x
        float B = sgn * s * sp * lift;                                             // screen y of the card's x (the shear)
        float D = cp * lift;                                                       // screen y of the card's y

        shadow(g, cx, cy, Math.abs(A) * W, D * H, s, sp);

        // the thickness: the far side of the slab peeks out behind the face, along the depth vector
        float dx = -sgn * s * DEPTH, dy = sgn * c * sp * DEPTH;
        float minA = 1.6F / W;                                                     // an edge-on card still shows its edge
        for (int i = LAYERS; i >= 1; i--) {
            float t = i / (float) LAYERS;
            layer(g, cx + dx * t, cy + dy * t, Math.max(Math.abs(A), minA), B, D,
                    App.mix(in.dark(), 0xFF000000, 0.18F + 0.34F * t));
        }

        if (Math.abs(A) > 0.012F) {
            g.pose().pushPose();
            g.pose().translate(cx, cy, 0);
            g.pose().mulPose(new Matrix4f(A, B, 0, 0, 0, D, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1));
            g.pose().translate(-W / 2F, -H / 2F, 0);
            if (sgn > 0) front(g, f, in); else back(g, f, in);
            glare(g, a, e, sgn);
            g.pose().popPose();
        }
    }

    private static float clamp(float v) { return Math.max(-1F, Math.min(1F, v)); }

    /** One slice of the edge: the silhouette of the card, drawn with the same turn as the face. */
    private static void layer(GuiGraphics g, float cx, float cy, float A, float B, float D, int color) {
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().mulPose(new Matrix4f(A, B, 0, 0, 0, D, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1));
        g.pose().translate(-W / 2F, -H / 2F, 0);
        App.roundRect(g, 0, 0, W, H, R, color);
        g.pose().popPose();
    }

    /** A soft shadow under the card: a few see-through boxes that grow, so the middle is darker. */
    private static void shadow(GuiGraphics g, float cx, float cy, float w, float h, float s, float sp) {
        float ox = -s * 5F + 2F, oy = 7F + sp * 6F;
        for (int i = 0; i < 5; i++) {
            int grow = i * 2;
            int bw = Math.max(4, Math.round(w - 8 + grow * 2)), bh = Math.round(h - 8 + grow * 2);
            App.roundRect(g, Math.round(cx + ox - bw / 2F), Math.round(cy + oy - bh / 2F), bw, bh, 8 + grow / 2, 0x0C000000);
        }
    }

    // ---------- a bright band that slides over the face ----------

    private static void glare(GuiGraphics g, float a, float e, int sgn) {
        float gx = W * (0.5F + 1.25F * (float) Math.sin(a) * sgn);
        float fade = 1F - 0.8F * (float) Math.sin(e * Math.PI);                    // it dims while the card is on its edge
        int wide = (int) (0x1C * fade) << 24 | 0xFFFFFF, narrow = (int) (0x30 * fade) << 24 | 0xFFFFFF;
        for (int dy = 0; dy < H; dy++) {
            float bx = gx - dy * 0.55F;
            span(g, dy, bx - 17, bx + 17, wide);
            span(g, dy, bx - 5, bx + 5, narrow);
            span(g, dy, bx + 20, bx + 23, wide);
        }
    }

    // ---------- helpers that keep a shape inside the rounded card ----------

    private static int inset(int dy) {
        double m = dy + 0.5;
        double e = m < R ? R - m : m > H - R ? m - (H - R) : 0;
        return e > 0 ? (int) Math.round(R - Math.sqrt(Math.max(0, R * R - e * e))) : 0;
    }

    /** A horizontal piece of row dy, cut to the card. */
    private static void span(GuiGraphics g, int dy, float x0, float x1, int argb) {
        if (dy < 0 || dy >= H) return;
        int in = inset(dy);
        int a = Math.max(in, Math.round(x0)), b = Math.min(W - in, Math.round(x1));
        if (b > a) g.fill(a, dy, b, dy + 1, argb);
    }

    private static void discClip(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            span(g, cy + dy, cx - dx, cx + dx + 1, argb);
        }
    }

    private static void ringClip(GuiGraphics g, int cx, int cy, int r, int thick, int argb) {
        int ri = r - thick;
        for (int dy = -r; dy <= r; dy++) {
            int dxo = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            if (Math.abs(dy) < ri) {
                int dxi = (int) Math.floor(Math.sqrt(ri * ri - dy * dy + 0.25));
                span(g, cy + dy, cx - dxo, cx - dxi, argb);
                span(g, cy + dy, cx + dxi + 1, cx + dxo + 1, argb);
            } else {
                span(g, cy + dy, cx - dxo, cx + dxo + 1, argb);
            }
        }
    }

    /** The body of a face: a vertical fade, soft shapes, and a light edge all round. */
    private static void body(GuiGraphics g, int top, int bottom) {
        for (int dy = 0; dy < H; dy++) span(g, dy, 0, W, App.mix(top, bottom, dy / (float) (H - 1)));
        for (int dy = 0; dy < H; dy++) {                                           // a diagonal light from the top left
            float bx = W * 0.15F + dy * 0.9F;
            span(g, dy, bx - 60, bx + 60, 0x0CFFFFFF);
        }
        for (int dy = 0; dy < H; dy++) {                                           // the edge: lit on the top and the left, dark on the bottom and the right
            int in = inset(dy);
            if (dy <= 1) span(g, dy, 0, W, dy == 0 ? 0x55FFFFFF : 0x22FFFFFF);
            if (dy >= H - 2) span(g, dy, 0, W, dy == H - 1 ? 0x44000000 : 0x18000000);
            g.fill(in, dy, in + 1, dy + 1, 0x30FFFFFF);
            g.fill(W - in - 1, dy, W - in, dy + 1, 0x26000000);
        }
    }

    // ---------- the front: the balance ----------

    private static void front(GuiGraphics g, Font f, Info in) {
        body(g, in.main(), in.dark());
        ringClip(g, W - 6, H + 4, 62, 3, 0x14FFFFFF);                              // big soft rings in the corner
        ringClip(g, W - 6, H + 4, 46, 2, 0x10FFFFFF);
        discClip(g, 4, -10, 38, 0x0AFFFFFF);

        // the logo and the name
        App.disc(g, 17, 14, 7, WHITE);
        App.disc(g, 17, 14, 5, in.main());
        g.fill(16, 11, 18, 17, WHITE);
        g.fill(14, 13, 20, 15, WHITE);
        CuteFont.draw(g, f, in.name(), 29, 10, WHITE, true);

        // contactless
        for (int r = 3; r <= 9; r += 3) {
            for (int d = -50; d <= 50; d += 6) {
                double ang = Math.toRadians(d);
                g.fill(W - 24 + (int) Math.round(Math.cos(ang) * r), 14 + (int) Math.round(Math.sin(ang) * r),
                        W - 24 + (int) Math.round(Math.cos(ang) * r) + 1, 14 + (int) Math.round(Math.sin(ang) * r) + 1, 0xDDFFFFFF);
            }
        }

        // the balance
        CuteFont.draw(g, f, in.balanceLabel(), 11, 27, 0xCCFFFFFF, false);
        int unitW = CuteFont.width(f, in.unit());
        int amtW = Math.max(1, CuteFont.width(f, in.balance()));
        float sc = Math.min(2F, (W - 22F - unitW - 4F) / amtW);
        g.pose().pushPose();
        g.pose().translate(11, 37, 0);
        g.pose().scale(sc, sc, 1F);
        CuteFont.draw(g, f, in.balance(), 0, 0, WHITE, true);
        g.pose().popPose();
        CuteFont.draw(g, f, in.unit(), Math.round(11 + amtW * sc + 4), Math.round(37 + 8 * sc - 8), 0xDDFFFFFF, false);

        // the chip and the number
        App.roundRect(g, 11, 58, 19, 14, 3, GOLD);
        g.fill(11, 62, 30, 63, GOLD_DARK);
        g.fill(11, 67, 30, 68, GOLD_DARK);
        g.fill(18, 58, 19, 72, GOLD_DARK);
        g.fill(24, 58, 25, 72, GOLD_DARK);
        g.fill(13, 59, 17, 60, 0x66FFFFFF);
        App.fitText(g, f, in.number(), 37, 61, W - 48, WHITE, false);

        // the holder, the date and the two circles of the payment system
        App.fitText(g, f, in.holder(), 11, 81, 66, 0xDDFFFFFF, false);
        CuteFont.draw(g, f, in.expiry(), 84, 81, 0xDDFFFFFF, false);
        App.disc(g, W - 24, 84, 7, 0xFFE5484D);
        App.disc(g, W - 16, 84, 7, 0xCCFFC34D);
    }

    // ---------- the back: strip, signature, CVV ----------

    private static void back(GuiGraphics g, Font f, Info in) {
        body(g, in.dark(), App.mix(in.dark(), 0xFF000000, 0.4F));
        for (int dy = 10; dy < 26; dy++) span(g, dy, 0, W, dy < 12 ? 0xFF2E2E38 : 0xFF1B1B22);   // the magnetic strip
        for (int i = 0; i < 12; i++) g.fill(11 + i * 8, 38, 15 + i * 8, 49, i % 2 == 0 ? 0xFFEDEDF2 : 0xFFD9D9E2); // the signature
        g.fill(11, 38, 107, 39, 0x22000000);
        App.roundRect(g, W - 11 - 36, 37, 36, 13, 3, WHITE);
        App.fitText(g, f, in.cvvLabel() + " " + in.cvv(), W - 11 - 18, 40, 32, 0xFF22222A, true);

        App.fitText(g, f, in.number(), W / 2, 59, W - 20, WHITE, true);
        App.fitText(g, f, in.validLabel() + " " + in.expiry(), 11, 74, 90, 0xDDFFFFFF, false);
        CuteFont.draw(g, f, in.name(), 11, 83, 0x99FFFFFF, false);

        // a little hologram
        App.disc(g, W - 20, 78, 9, 0x44FFFFFF);
        App.disc(g, W - 20, 78, 7, 0xCC9AD7FF);
        App.disc(g, W - 17, 76, 5, 0xCCFFB0E0);
        App.disc(g, W - 22, 81, 4, 0xCCB8FFC8);
    }
}
