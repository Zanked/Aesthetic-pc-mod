package dev.cutemod.client.os;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/**
 * The albums that music.gradle found in the music/ folder (assets/cutemod/music/albums.json).
 * Loaded once when first needed; {@link #reload()} reads it again.
 */
public final class Albums {
    private Albums() {}

    public record Track(String id, String title, int seconds, SoundEvent sound) {}

    public record Album(String id, String title, String artist, int price, ResourceLocation cover, int coverW, int coverH,
                        List<Track> tracks) {
        public String ownKey() { return "album_" + id; }

        public String delKey() { return "del_" + id; }

        /** Bought (or free): this stays true when the album is deleted from the disk, so it can be put back for free. */
        public boolean purchased() { return price <= 0 || Progress.owned(ownKey()); }

        /** In the library of the PC (on the disk): bought or free, and not deleted. Free albums are in the library from the start. */
        public boolean owned() { return purchased() && !Progress.owned(delKey()); }

        /** Free albums are part of the system and stay; the bought ones can be deleted to free the disk. */
        public boolean canDelete() { return price > 0 && owned(); }

        /** Deletes the album from the disk (and the player): the purchase stays, putting it back is free. */
        public void delete() {
            if (!canDelete()) return;
            setOnPlayer(false);
            Progress.setFlag(delKey(), true);
        }

        /** Is this album loaded onto the portable player? (set in the Music app at the computer) */
        public boolean onPlayer() { return owned() && Progress.owned("plr_" + id); }

        public void setOnPlayer(boolean on) { Progress.setFlag("plr_" + id, on); }

        /** The size on the disk in MB: the same 160 KB per second of music that the Explorer shows for a song. */
        public long sizeMb() {
            long bytes = 0;
            for (Track t : tracks) bytes += Math.max(30, t.seconds()) * 160_000L;
            return Math.max(1, (bytes + 1_048_575L) / 1_048_576L);
        }

        /** Needs room on C:. Returns false (with a message) when the disk is too full for the album. */
        public boolean buy() {
            if (owned()) return true;
            if (Library.freeMb() < sizeMb()) { Progress.toast("cutemod.toast.no_space_music", title); return false; }
            if (purchased()) { Progress.setFlag(delKey(), false); return true; }       // deleted before: back on the disk for free
            return Progress.buyNamed(ownKey(), price, title);
        }
    }

    /** True when every album of the library is on the portable player (and there is at least one). */
    public static boolean allOnPlayer() {
        boolean any = false;
        for (Album a : all()) if (a.owned()) { if (!a.onPlayer()) return false; any = true; }
        return any;
    }

    /** One button: puts every owned album on the player; when they are all there already, takes them all off. Returns how many albums are on the player now. */
    public static int syncAll() {
        boolean on = !allOnPlayer();
        int n = 0;
        for (Album a : all()) if (a.owned()) { a.setOnPlayer(on); if (on) n++; }
        return n;
    }

    /** The MB of the albums that are in the library of the PC (free ones too): they take room on C:. */
    public static long ownedMb() {
        long mb = 0;
        for (Album a : all()) if (a.owned()) mb += a.sizeMb();
        return mb;
    }

    private static List<Album> all;

    public static List<Album> all() {
        if (all == null) load();
        return all;
    }

    public static void reload() { all = null; }

    private static void load() {
        java.util.Map<String, Album> out = new java.util.LinkedHashMap<>();
        all = new ArrayList<>();
        try {
            var rm = Minecraft.getInstance().getResourceManager();
            // the mod itself and the folder of the player each have an albums.json (the lower pack first)
            for (var res : rm.getResourceStack(ResourceLocation.fromNamespaceAndPath("cutemod", "music/albums.json"))) {
                try (Reader r = res.openAsReader()) {
                    JsonArray arr = JsonParser.parseReader(r).getAsJsonObject().getAsJsonArray("albums");
                    for (JsonElement e : arr) {
                        JsonObject a = e.getAsJsonObject();
                        String id = a.get("id").getAsString();
                        List<Track> tracks = new ArrayList<>();
                        for (JsonElement te : a.getAsJsonArray("tracks")) {
                            JsonObject t = te.getAsJsonObject();
                            String tid = t.get("id").getAsString();
                            SoundEvent ev = SoundEvent.createVariableRangeEvent(
                                    ResourceLocation.fromNamespaceAndPath("cutemod", "music." + id + "." + tid));
                            tracks.add(new Track(tid, t.get("title").getAsString(), t.get("seconds").getAsInt(), ev));
                        }
                        boolean cover = a.has("cover") && a.get("cover").getAsBoolean();
                        out.put(id, new Album(id, a.get("title").getAsString(), a.get("artist").getAsString(),
                                a.get("price").getAsInt(),
                                cover ? ResourceLocation.fromNamespaceAndPath("cutemod", "textures/music/" + id + ".png") : null,
                                a.get("coverW").getAsInt(), a.get("coverH").getAsInt(), tracks));
                    }
                } catch (Exception ex) {
                    // one broken albums.json must not break the others
                }
            }
        } catch (Exception ex) {
            // no albums
        }
        all = new ArrayList<>(out.values());
    }
}
