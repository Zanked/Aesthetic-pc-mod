package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/** The mail app: a list of letters and a reading view with a "take the reward" button. */
public class MailApp extends App {

    @Override
    public boolean needsNet() { return true; }
    private static final int HEAD = 17, ROW = 24;
    private static final int[] SENDER = {0xFF8A7AA8, 0xFFF58FB8, 0xFFF3C45A, 0xFF3A2A3A, 0xFF7BCB8A, 0xFFE0A93A, 0xFF8A0A14};

    private Mail.Msg open;
    private int scroll;
    private int oy;          // > 0 when shown inside the browser (BeeMail): offset below the address bar
    private boolean web;     // BeeMail skin: honey header, same inbox
    private int ticks;
    private boolean writing;      // the "write a letter" screen
    private String draft = "";
    private String note = "";     // short message after sending
    private int noteT;
    private int tab;                 // 0 = system letters, 1 = letters from players
    private final PostPanel post = new PostPanel();

    /** Turn this app into BeeMail, the browser version of the same inbox. oy = top of the page area. */
    public MailApp embedded(int oy) { this.oy = oy; this.web = true; return this; }

    /** Height of the area this app can draw in. */
    private int h() { return H - oy; }

    @Override
    public void tick() { ticks++; if (noteT > 0) noteT--; post.tick(); }

    @Override
    public Component title() { return Component.translatable("cutemod.os.mail"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.mail"); }

    private int visibleRows() { return (h() - HEAD) / ROW; }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        Skin.rect(g, 0, 0, W, h(), web ? 0xFFFFFAE6 : 0xFFF6F0FA);
        Skin.rect(g, 0, 0, W, HEAD, web ? 0xFFF5C518 : 0xFF5A4A86);
        if (web) bee(g, (ticks * 2) % (W + 30) - 15, 3 + (int) Math.round(Math.sin(ticks / 5.0) * 2));
        if (tab == 1) {
            post.render(g, f, mx, my, h(), web);
            if (post.onList()) tabs(g, f, mx, my);
            return;
        }
        if (writing) composing(g, f, mx, my);
        else if (open == null) list(g, f, mx, my);
        else reading(g, f, mx, my);
    }

    private void list(GuiGraphics g, Font f, int mx, int my) {
        tabs(g, f, mx, my);
        boolean wHover = in(mx, my, W - 62, 0, 62, HEAD);
        if (wHover) Skin.rect(g, W - 62, 0, 62, HEAD, web ? 0xFFFFD866 : 0xFF8A6AC6);
        String wl = "+ " + t("cutemod.mail.write");
        Skin.str(g, f, wl, W - 31 - f.width(wl) / 2, 5, web ? 0xFF5A3A00 : 0xFFFFFFFF, false);
        List<Mail.Msg> box = Mail.inbox();
        scroll = Math.max(0, Math.min(Math.max(0, box.size() - visibleRows()), scroll));
        for (int i = 0; i < visibleRows() && i + scroll < box.size(); i++) {
            Mail.Msg m = box.get(i + scroll);
            int y = HEAD + i * ROW;
            boolean hover = in(mx, my, 0, y, W, ROW);
            Skin.rect(g, 0, y, W, ROW - 1, hover ? 0xFFEBDDF7 : (Mail.unread(m) ? 0xFFFFFFFF : 0xFFF0E8F7));
            Skin.disc(g, 13, y + 11, 7, SENDER[m.from()]);
            String init = t("cutemod.mail.from." + m.from()).substring(0, 1);
            Skin.str(g, f, init, 13 - f.width(init) / 2, y + 7, 0xFFFFFFFF, false);
            boolean unread = Mail.unread(m);
            Skin.str(g, f, t("cutemod.mail.from." + m.from()), 26, y + 3, unread ? 0xFF3A2A3A : 0xFF8A7AA8, false);
            String subj = f.plainSubstrByWidth(Mail.subject(m), W - 70);
            Skin.str(g, f, subj, 26, y + 13, unread ? 0xFF3A2A3A : 0xFF9A8AB8, false);
            if (unread) Skin.disc(g, W - 10, y + 11, 3, 0xFFE5484D);
            if (m.reward() > 0 && !Mail.claimed(m)) Progress.drawCoin(g, W - 26, y + 8);
        }
        if (noteT > 0) {
            Skin.rect(g, 0, h() - 14, W, 14, 0xFFDFF5E3);
            Skin.str(g, f, note, 6, h() - 11, 0xFF2E6B3A, false);
        }
        if (box.size() > visibleRows()) {
            int track = h() - HEAD, th = Math.max(8, track * visibleRows() / box.size());
            Skin.rect(g, W - 2, HEAD + (track - th) * scroll / (box.size() - visibleRows()), 2, th, 0xFFB57BD6);
        }
    }

    /** The two tabs in the header: system letters and letters from players. */
    private void tabs(GuiGraphics g, Font f, int mx, int my) {
        String[] names = {t("cutemod.mail.tab.system", Mail.unreadCount()), t("cutemod.mail.tab.players", Post.unreadCount())};
        int x = 4;
        for (int i = 0; i < 2; i++) {
            int w = f.width(names[i]) + 10;
            boolean on = i == tab, hover = in(mx, my, x, 2, w, HEAD - 2);
            Skin.rect(g, x, 2, w, HEAD - 2, on ? (web ? 0xFFFFFAE6 : 0xFFF6F0FA) : (hover ? (web ? 0xFFFFD866 : 0xFF8A6AC6) : (web ? 0xFFE0B010 : 0xFF4A3A76)));
            Skin.str(g, f, names[i], x + 5, 6, on ? 0xFF3A2A3A : (web ? 0xFF5A3A00 : 0xFFFFFFFF), false);
            x += w + 2;
        }
    }

    private boolean tabClick(int x, int y) {
        if (y < 2 || y >= HEAD) return false;
        Font f = font();
        String[] names = {t("cutemod.mail.tab.system", Mail.unreadCount()), t("cutemod.mail.tab.players", Post.unreadCount())};
        int tx = 4;
        for (int i = 0; i < 2; i++) {
            int w = f.width(names[i]) + 10;
            if (x >= tx && x < tx + w) { if (tab != i) { tab = i; if (i == 1) Post.request(); } return true; }
            tx += w + 2;
        }
        return false;
    }

    private void composing(GuiGraphics g, Font f, int mx, int my) {
        boolean back = in(mx, my, 0, 0, 50, HEAD);
        if (back) Skin.rect(g, 0, 0, 50, HEAD, web ? 0xFFFFD866 : 0xFF8A6AC6);
        Skin.str(g, f, "< " + t("cutemod.mail.back"), 6, 5, web ? 0xFF5A3A00 : 0xFFFFFFFF, false);
        Skin.str(g, f, t("cutemod.mail.write.title"), 60, 5, web ? 0xFF5A3A00 : 0xFFE9DDF2, false);
        int y = HEAD + 8;
        List<FormattedCharSequence> help = f.split(FormattedText.of(t("cutemod.mail.write.help")), W - 16);
        for (int i = 0; i < help.size() && i < 4; i++) { Skin.str(g, f, help.get(i), 8, y, 0xFF3A2A3A, false); y += 9; }
        int by = HEAD + 52;
        Skin.rect(g, 7, by - 1, W - 14, 16, 0xFFB57BD6);
        Skin.rect(g, 8, by, W - 16, 14, 0xFFFFFFFF);
        String shown = draft;
        while (shown.length() > 1 && f.width(shown) > W - 28) shown = shown.substring(1);
        Skin.str(g, f, shown, 11, by + 3, 0xFF3A2A3A, false);
        if ((ticks / 30) % 2 == 0) Skin.rect(g, 12 + f.width(shown), by + 2, 1, 10, 0xFF3A2A3A);
        int sy = by + 22;
        boolean ok = !draft.isBlank();
        boolean hover = ok && in(mx, my, 8, sy, 80, 16);
        Skin.rect(g, 8, sy, 80, 16, !ok ? 0xFFE6DDF0 : (hover ? 0xFFFFD866 : 0xFFFFC832));
        String s = t("cutemod.mail.send");
        Skin.str(g, f, s, 8 + (80 - f.width(s)) / 2, sy + 4, 0xFF3A2A3A, false);
    }

    private void submit() {
        if (draft.isBlank()) return;
        boolean ok = Mail.send(draft);
        AppSfx.send();
        note = t(ok ? "cutemod.mail.sent" : "cutemod.mail.sent.none");
        noteT = 240;
        draft = "";
        writing = false;
    }

    private void reading(GuiGraphics g, Font f, int mx, int my) {
        boolean back = in(mx, my, 0, 0, 50, HEAD);
        if (back) Skin.rect(g, 0, 0, 50, HEAD, web ? 0xFFFFD866 : 0xFF8A6AC6);
        Skin.str(g, f, "< " + t("cutemod.mail.back"), 6, 5, web ? 0xFF5A3A00 : 0xFFFFFFFF, false);
        int y = HEAD + 6;
        Skin.disc(g, 14, y + 8, 7, SENDER[open.from()]);
        Skin.str(g, f, t("cutemod.mail.from." + open.from()), 26, y + 1, 0xFF3A2A3A, false);
        Skin.str(g, f, Mail.subject(open), 26, y + 11, 0xFFC04A7A, false);
        Skin.rect(g, 6, y + 22, W - 12, 1, 0xFFE9DDF2);
        List<FormattedCharSequence> lines = f.split(FormattedText.of(Mail.body(open)), W - 16);
        int ty = y + 28;
        int tripSlot = Mail.tripSlotOf(open);
        for (int i = 0; i < lines.size() && i < (tripSlot >= 0 ? 4 : 8); i++) { Skin.str(g, f, lines.get(i), 8, ty, 0xFF3A2A3A, false); ty += 9; }
        if (tripSlot >= 0) TripArt.letterPhoto(g, f, 8, 92, tripSlot, ticks);
        if (open.reward() > 0) {
            boolean got = Mail.claimed(open);
            int bx = 8, by = h() - 22, bw = 120, bh = 16;
            boolean hover = !got && in(mx, my, bx, by, bw, bh);
            Skin.rect(g, bx, by, bw, bh, got ? 0xFFDFF5E3 : (hover ? 0xFFFFD866 : 0xFFFFC832));
            String s = got ? t("cutemod.mail.taken") : t("cutemod.mail.take", open.reward());
            Skin.str(g, f, s, bx + (bw - f.width(s)) / 2, by + 4, 0xFF3A2A3A, false);
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (tab == 1) return (post.onList() && tabClick(x, y)) || post.click(x, y, h());
        if (open == null && !writing && tabClick(x, y)) return true;
        if (writing) {
            if (in(x, y, 0, 0, 50, HEAD)) { writing = false; return true; }
            if (in(x, y, 8, HEAD + 74, 80, 16)) { submit(); return true; }
            return false;
        }
        if (open == null && in(x, y, W - 62, 0, 62, HEAD)) { writing = true; draft = ""; return true; }
        if (open != null) {
            if (in(x, y, 0, 0, 50, HEAD)) { open = null; return true; }
            if (open.reward() > 0 && in(x, y, 8, h() - 22, 120, 16)) { Mail.claim(open); return true; }
            return false;
        }
        List<Mail.Msg> box = Mail.inbox();
        int i = (y - HEAD) / ROW;
        if (y >= HEAD && i < visibleRows() && i + scroll < box.size()) {
            open = box.get(i + scroll);
            Mail.markRead(open);
            Progress.onMail(open.id());
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        if (tab == 1) return post.charTyped(c);
        if (!writing || c < 32 || c == 127) return false;
        if (draft.length() < 40) draft += c;
        return true;
    }

    @Override
    public boolean scroll(double amount) {
        if (tab == 1) return post.scroll(amount);
        if (open != null || writing) return false;
        scroll -= (int) Math.signum(amount);
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (tab == 1) return post.key(keyCode, modifiers);
        if (writing) {
            if (keyCode == 257 || keyCode == 335) { submit(); return true; }            // enter
            if (keyCode == 256) { writing = false; return true; }                        // escape: back, don't close
            if (keyCode == 259) { if (!draft.isEmpty()) draft = draft.substring(0, draft.length() - 1); return true; }
            return false;
        }
        if (open != null && keyCode == 259) { open = null; return true; } // backspace
        return false;
    }

    /** The same tiny bee that buzzes across the BeeMail ad banner. */
    private static void bee(GuiGraphics g, int bx, int by) {
        Skin.rect(g, bx + 1, by, 3, 3, 0xDDFFFFFF);
        Skin.rect(g, bx + 7, by, 3, 3, 0xDDFFFFFF);
        Skin.rect(g, bx, by + 3, 10, 6, 0xFF8A5A00);
        Skin.rect(g, bx + 3, by + 3, 1, 6, 0xFF2A2A2A);
        Skin.rect(g, bx + 6, by + 3, 1, 6, 0xFF2A2A2A);
        Skin.rect(g, bx + 8, by + 4, 1, 1, 0xFF2A2A2A);
    }
}
