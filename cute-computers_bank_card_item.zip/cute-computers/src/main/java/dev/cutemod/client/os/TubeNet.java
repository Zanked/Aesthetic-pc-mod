package dev.cutemod.client.os;

import dev.cutemod.net.TubeActionPayload;
import dev.cutemod.net.TubePublishPayload;
import dev.cutemod.net.TubeSyncPayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;

/**
 * The videos of the other players on the client: the list the server sent, and the video that is open (its pictures
 * and comments). Publishing and likes pay a few coins here, because the server answers with the result.
 */
public final class TubeNet {
    private TubeNet() {}

    private static List<TubeSyncPayload.Entry> list = List.of();
    private static long openId;
    private static List<byte[]> frames = List.of();
    private static List<TubeSyncPayload.Comm> comments = List.of();
    private static boolean loaded;
    private static int gen;                  // goes up with every answer, so the screen knows to rebuild its lines

    public static void apply(TubeSyncPayload p) {
        list = p.list();
        openId = p.openId();
        frames = p.frames();
        comments = p.comments();
        loaded = true;
        gen++;
        if (p.result() == 0) {                                                  // published
            Progress.toast("cutemod.tube.pub.ok");
            Progress.bump("tube_pub");
            if (Progress.count("tube_pub") == 1) Progress.earn(5);              // the first video of your own
            if (Haunt.scary && Progress.questDone() && Progress.step3() == 3) Progress.setCount("q3_vid", (int) p.openId());   // part 3, chapter 4: he will comment on it
        } else if (p.result() > 0) {
            Progress.toast("cutemod.tube.err." + p.result());
        }
        int likes = 0;                                                         // 1 coin per 5 likes on your videos, 50 at most
        for (TubeSyncPayload.Entry e : list) if (e.mine()) likes += e.likes();
        int due = Math.min(likes / 5, 50) - Progress.count("tube_lk");
        if (due > 0) {
            Progress.setCount("tube_lk", Progress.count("tube_lk") + due);
            Progress.earn(due);
        }
    }

    public static void clear() {
        list = List.of();
        frames = List.of();
        comments = List.of();
        openId = 0;
        loaded = false;
    }

    public static boolean loaded() { return loaded; }

    public static int gen() { return gen; }

    public static List<TubeSyncPayload.Entry> list() { return list; }

    /** The video the server last opened for us (0 = none), with its pictures and comments. */
    public static long openId() { return openId; }

    public static List<byte[]> frames() { return frames; }

    public static List<TubeSyncPayload.Comm> comments() { return comments; }

    public static TubeSyncPayload.Entry find(long id) {
        for (TubeSyncPayload.Entry e : list) if (e.id() == id) return e;
        return null;
    }

    // ---------- requests ----------
    public static void request() { dev.cutemod.client.os.Modem.sendQuiet(new TubeActionPayload(0, 0, "")); }

    public static void open(long id) { dev.cutemod.client.os.Modem.sendQuiet(new TubeActionPayload(1, id, "")); }

    public static void like(long id) { dev.cutemod.client.os.Modem.sendQuiet(new TubeActionPayload(2, id, "")); }

    public static void comment(long id, String text) { dev.cutemod.client.os.Modem.sendQuiet(new TubeActionPayload(3, id, text)); }

    public static void delete(long id) { dev.cutemod.client.os.Modem.sendQuiet(new TubeActionPayload(4, id, "")); }

    public static void publish(String title, int fps, int tune, List<byte[]> frames) {
        dev.cutemod.client.os.Modem.sendQuiet(new TubePublishPayload(title, fps, tune, frames));
    }
}
