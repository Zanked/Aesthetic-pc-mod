package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The shared graphics kit of CuteJobs: everything the ten shifts (and the list, the countdown and the result) need to look
 * soft and alive instead of flat rectangles. Only drawing and effects live here, no rules.
 * <p>
 * What is in the kit:
 * <ul>
 *   <li>colours: {@link #alpha}, {@link #light}, {@link #shade}</li>
 *   <li>scenery: {@link #sky}, {@link #ground}, {@link #stars} (parallax and twinkle), {@link #vignette}</li>
 *   <li>objects: {@link #puffy} (a soft button-like block), {@link #orb} (a shaded ball), {@link #shadow}, {@link #glow},
 *       {@link #halo}, {@link #sparkle}, {@link #chip}, {@link #hearts}</li>
 *   <li>effects: {@link Fx} (one per app): bursts, confetti, floating texts and a screen shake</li>
 * </ul>
 * Everything drawn through {@link #rect} and {@link #disc} stays under the header ({@link JobsUi#BAR}) and inside the screen,
 * so a shift can never paint over the header.
 */
final class JobsGfx {
    private JobsGfx() {}

    private static final int W = App.W, H = App.H, TOP = JobsUi.BAR;

    // ======================================================================
    //                               colours
    // ======================================================================

    /** The same colour with another opacity (0..255). */
    static int alpha(int argb, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (argb & 0xFFFFFF); }

    /** A lighter colour (f = 0..1 toward white). Opaque. */
    static int light(int c, float f) { return App.mix(c, 0xFFFFFF, f); }

    /** A darker colour (f = 0..1 toward black). Opaque. */
    static int shade(int c, float f) { return App.mix(c, 0x000000, f); }

    /** A running clock for slow ambient animation (twinkling stars on the list); one step = 50 ms. */
    static int ambient() { return (int) (System.currentTimeMillis() / 50L); }

    // ======================================================================
    //                               basic shapes
    // ======================================================================

    /** A filled rectangle that never leaves the game area (under the header, inside the screen). */
    static void rect(GuiGraphics g, int x, int y, int w, int h, int argb) {
        int x0 = Math.max(0, x), x1 = Math.min(W, x + w), y0 = Math.max(TOP, y), y1 = Math.min(H, y + h);
        if (x1 > x0 && y1 > y0 && (argb >>> 24) != 0) Skin.fill(g, x0, y0, x1, y1, argb);
    }

    /** A filled disc, clipped the same way. */
    static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            rect(g, cx - dx, cy + dy, 2 * dx + 1, 1, argb);
        }
    }

    // ======================================================================
    //                               scenery
    // ======================================================================

    /** The background of a scene: a vertical gradient under the header. */
    static void sky(GuiGraphics g, int top, int bottom) { Skin.grad(g, 0, TOP, W, H, top, bottom); }

    /** The floor from y down to the bottom edge: a gradient with a bright rim and a faint second line. */
    static void ground(GuiGraphics g, int y, int top, int bottom) {
        Skin.grad(g, 0, y, W, H, top, bottom);
        rect(g, 0, y, W, 1, light(top, 0.35f));
        rect(g, 0, y + 1, W, 1, alpha(0xFFFFFF, 0x18));
    }

    /**
     * Twinkling stars in {@code layers} depth layers: the far ones are dim and slow, the near ones bright, bigger and faster.
     * tick drives the drift (pass the shift's tick, or {@link #ambient()} on the list).
     */
    static void stars(GuiGraphics g, int tick, int count, int layers, int rgb) {
        int span = Math.max(8, H - TOP - 30);
        for (int i = 0; i < count; i++) {
            int layer = i % layers;
            int x = Math.floorMod(i * 61 + 17 - tick * (layer + 1) / 3, W);
            int y = TOP + 4 + (i * 37 + 11) % span;
            double tw = 0.5 + 0.5 * Math.sin((tick + i * 17) / 14.0);
            int a = (int) (0x30 + layer * 0x28 + tw * 0x40);
            int s = layers > 1 && layer == layers - 1 ? 2 : 1;
            rect(g, x, y, s, s, alpha(rgb, a));
        }
    }

    /** Soft dark edges: six faint frames around the game area. Draw it after the scene, before the effects. */
    static void vignette(GuiGraphics g) {
        for (int i = 0; i < 6; i++) {
            int c = alpha(0x000000, 0x26 - i * 6);
            rect(g, 0, TOP + i, W, 1, c);
            rect(g, 0, H - 1 - i, W, 1, c);
            rect(g, i, TOP + i + 1, 1, H - TOP - 2 * i - 2, c);
            rect(g, W - 1 - i, TOP + i + 1, 1, H - TOP - 2 * i - 2, c);
        }
    }

    // ======================================================================
    //                               objects
    // ======================================================================

    /** A soft oval shadow on the floor, centred on cx, at height y; w = the width of the object above it. */
    static void shadow(GuiGraphics g, int cx, int y, int w) {
        for (int i = 0; i < 3; i++) {
            int ww = w + 6 - i * 3, hh = 5 - i;
            App.roundRect(g, cx - ww / 2, y - hh / 2, ww, hh, Math.max(1, hh / 2), 0x1A000000);
        }
    }

    /** A soft rounded block: a drop shadow, a darker lower rim, the body and a shine on top. Not clipped. */
    static void puffy(GuiGraphics g, int x, int y, int w, int h, int r, int body) {
        App.roundRect(g, x, y + 2, w, h, r, 0x44000000);
        App.roundRect(g, x, y + 1, w, h, r, shade(body, 0.35f));
        App.roundRect(g, x, y, w, h, r, body);
        if (h >= 6 && w >= 8) App.roundRect(g, x + 2, y + 1, w - 4, Math.max(2, h / 4), Math.max(1, r / 2), alpha(light(body, 0.55f), 0xA0));
    }

    /** A shaded ball with a rim, a lit side and a highlight. */
    static void orb(GuiGraphics g, int cx, int cy, int r, int color) {
        disc(g, cx, cy + 1, r, alpha(0x000000, 0x40));
        disc(g, cx, cy, r, shade(color, 0.3f));
        disc(g, cx, cy, Math.max(1, r - 1), color);
        if (r >= 4) {
            disc(g, cx - r / 4, cy - r / 4, Math.max(1, r * 2 / 3), light(color, 0.22f));
            disc(g, cx - r / 3, cy - r / 3, Math.max(1, r / 4), alpha(0xFFFFFF, 0xC0));
        }
    }

    /** A soft light: stacked translucent discs (a is the opacity of ONE layer, about 0x10 is gentle). */
    static void glow(GuiGraphics g, int cx, int cy, int r, int rgb, int a) {
        for (int i = 4; i >= 1; i--) disc(g, cx, cy, r * i / 4, alpha(rgb, a));
    }

    /** A soft coloured edge around a rounded rectangle (hover, a bonus, a warning). Draw it BEFORE the object. */
    static void halo(GuiGraphics g, int x, int y, int w, int h, int r, int rgb, int a) {
        for (int i = 3; i >= 1; i--) App.roundRect(g, x - i, y - i, w + 2 * i, h + 2 * i, r + i, alpha(rgb, a / i));
    }

    /** A four-pointed twinkle; k = 1 is full strength, 0 is gone. */
    static void sparkle(GuiGraphics g, int x, int y, int size, int rgb, float k) {
        int a = Math.round(255 * Math.max(0f, Math.min(1f, k)));
        if (a < 8) return;
        rect(g, x - size, y, 2 * size + 1, 1, alpha(rgb, a / 2));
        rect(g, x, y - size, 1, 2 * size + 1, alpha(rgb, a / 2));
        rect(g, x - 1, y - 1, 3, 3, alpha(rgb, a));
        rect(g, x, y, 1, 1, alpha(0xFFFFFF, a));
    }

    /** A small pill with a label and a soft shadow. */
    static void chip(GuiGraphics g, int x, int y, int w, int h, int fill, String label, int ink) {
        App.roundRect(g, x, y + 1, w, h, h / 2, 0x44000000);
        App.roundRect(g, x, y, w, h, h / 2, fill);
        JobsUi.fit(g, label, x + w / 2, y + (h - 8) / 2, w - 6, ink, true);
    }

    private static final String[] HEART = {".##.##.", "#######", "#######", ".#####.", "..###..", "...#..."};

    /** The lives of a shift: full hearts and empty slots, 10 px apart. y must be at or below the header. */
    static void hearts(GuiGraphics g, int x, int y, int lives, int max) {
        for (int i = 0; i < max; i++) {
            int hx = x + i * 10;
            boolean on = i < lives;
            JobsUi.glyph(g, HEART, hx + 1, y + 1, 1, alpha(0x000000, 0x55));
            JobsUi.glyph(g, HEART, hx, y, 1, on ? 0xFFE5484D : 0xFF3B3063);
            if (on) g.fill(hx + 1, y + 1, hx + 2, y + 2, 0xFFFFC2C8);
        }
    }

    // ======================================================================
    //                               effects
    // ======================================================================

    /**
     * Short effects of one app: bursts of dots, confetti, floating texts and a screen shake. Create one, call {@link #tick()}
     * every tick and {@link #render} after the scene. The shift triggers them where something happens:
     * <pre>
     *   fx.burst(x, y, GREEN, 8);          // a catch, a hit, a pop
     *   fx.pop(x, y - 8, "+1", YELLOW);    // a number that floats up
     *   fx.confetti(x, y, 12);             // a great moment
     *   fx.shake(8, 2.5f);                 // a mistake, a crash
     * </pre>
     * The shake is read with {@link #shakeX()} / {@link #shakeY()} and applied by the app around the scene.
     */
    static final class Fx {
        private static final class P {
            float x, y, vx, vy, grav;
            int life, max, size, color, kind;       // kind: 0 dot, 1 sparkle, 2 text
            String text;
        }

        private static final int[] PARTY = {0xFFFFD866, 0xFFF58FB8, 0xFF6AA8F0, 0xFF5BD97A, 0xFFB57BD6};
        private static final int MAX = 160;

        private final List<P> ps = new ArrayList<>();
        private final Random rnd = new Random();
        private int shake, shakeMax;
        private float amp;

        void clear() {
            ps.clear();
            shake = 0;
        }

        private P add(float x, float y, float vx, float vy, float grav, int life, int size, int color, int kind) {
            if (ps.size() >= MAX) ps.remove(0);
            P p = new P();
            p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.grav = grav;
            p.life = p.max = Math.max(1, life);
            p.size = size; p.color = color; p.kind = kind;
            ps.add(p);
            return p;
        }

        /** A round burst of small dots with a twinkle in the middle. */
        void burst(float x, float y, int color, int n) {
            for (int i = 0; i < n; i++) {
                double a = rnd.nextDouble() * Math.PI * 2;
                float sp = 0.6f + rnd.nextFloat() * 1.4f;
                add(x, y, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp - 0.4f, 0.06f, 16 + rnd.nextInt(10),
                        1 + rnd.nextInt(2), i % 3 == 0 ? light(color, 0.5f) : color, 0);
            }
            add(x, y, 0, 0, 0, 10, 4, color, 1);
        }

        /** Coloured confetti that flies up and falls back. */
        void confetti(float x, float y, int n) {
            for (int i = 0; i < n; i++) {
                float vx = (rnd.nextFloat() - 0.5f) * 2.4f, vy = -1.2f - rnd.nextFloat() * 1.6f;
                add(x, y, vx, vy, 0.08f, 30 + rnd.nextInt(20), 2, PARTY[rnd.nextInt(PARTY.length)], 0);
            }
        }

        /** A text that floats up and fades (a score, a combo). */
        void pop(float x, float y, String text, int color) {
            P p = add(x, y, 0, -0.5f, 0, 30, 0, color, 2);
            p.text = text;
        }

        /** Shakes the scene for the given number of ticks; a stronger shake in progress is not weakened. */
        void shake(int ticks, float amplitude) {
            if (ticks >= shake) { shake = ticks; shakeMax = Math.max(1, ticks); amp = amplitude; }
        }

        int shakeX() { return shake <= 0 ? 0 : Math.round((float) Math.sin(shake * 2.9) * amp * shake / shakeMax); }

        int shakeY() { return shake <= 0 ? 0 : Math.round((float) Math.cos(shake * 3.7) * amp * shake / shakeMax * 0.6f); }

        void tick() {
            if (shake > 0) shake--;
            for (int i = ps.size() - 1; i >= 0; i--) {
                P p = ps.get(i);
                p.x += p.vx;
                p.y += p.vy;
                p.vy += p.grav;
                p.vx *= 0.97f;
                if (--p.life <= 0) ps.remove(i);
            }
        }

        void render(GuiGraphics g) {
            for (P p : ps) {
                float k = p.life / (float) p.max;
                int x = Math.round(p.x), y = Math.round(p.y);
                switch (p.kind) {
                    case 0 -> rect(g, x, y, p.size, p.size, alpha(p.color, Math.round(255 * Math.min(1f, k * 1.6f))));
                    case 1 -> sparkle(g, x, y, p.size + Math.round((1f - k) * 3f), p.color, k);
                    default -> {
                        if (k <= 0.15f || p.text == null) break;
                        int a = Math.round(255 * Math.min(1f, k * 2f)), ty = Math.max(y, TOP + 2);
                        JobsUi.ctext(g, p.text, x, ty + 1, alpha(0x000000, a / 2));
                        JobsUi.ctext(g, p.text, x, ty, alpha(p.color, a));
                    }
                }
            }
        }
    }
}
