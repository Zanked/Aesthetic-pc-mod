package dev.cutemod.client.game;

import java.util.ArrayList;
import java.util.List;

/**
 * The gardens of {@link GardenGuard}: the path the pests walk, the scenery that blocks tiles and the look of each
 * map (0 meadow, 1 pond, 2 winter). Everything is computed once, so nothing jumps around between frames.
 */
final class GardenMaps {
    private GardenMaps() {}

    static final int T = 12, COLS = 18, ROWS = 9, OY = 12;           // tile size, grid size, y of the grid

    /** Scenery kinds: a tree (a pine in winter), a bush, a rock, a cabbage, water, a reed, water with a lily, a snowman. */
    static final int TREE = 0, BUSH = 1, ROCK = 2, CABBAGE = 3, WATER = 4, REED = 5, LILY = 6, SNOWMAN = 7;

    static final class Map {
        final int index;
        final int[][] corners, decor;
        final boolean[][] path = new boolean[COLS][ROWS], block = new boolean[COLS][ROWS], water = new boolean[COLS][ROWS];
        final int[][] kind = new int[COLS][ROWS];                      // the scenery kind of a blocked tile
        final float[] wx, wy, cum;
        final float total;
        final int[] tuft, flower, pebble;
        final int grassTop, grassBot, pathCol, pathEdge, pebA, pebB, fence, glow;

        Map(int index, int[][] corners, int[][] decor, int grassTop, int grassBot, int pathCol, int pathEdge, int pebA, int pebB, int fence, int glow) {
            this.index = index; this.corners = corners; this.decor = decor;
            this.grassTop = grassTop; this.grassBot = grassBot; this.pathCol = pathCol; this.pathEdge = pathEdge;
            this.pebA = pebA; this.pebB = pebB; this.fence = fence; this.glow = glow;
            int n = corners.length;
            wx = new float[n]; wy = new float[n]; cum = new float[n];
            for (int i = 0; i < n; i++) {
                wx[i] = corners[i][0] * T + T / 2F;
                wy[i] = OY + corners[i][1] * T + T / 2F;
                if (i > 0) cum[i] = cum[i - 1] + Math.abs(wx[i] - wx[i - 1]) + Math.abs(wy[i] - wy[i - 1]);
            }
            total = cum[n - 1];
            for (int i = 0; i + 1 < n; i++) {
                int c0 = Math.min(corners[i][0], corners[i + 1][0]), c1 = Math.max(corners[i][0], corners[i + 1][0]);
                int r0 = Math.min(corners[i][1], corners[i + 1][1]), r1 = Math.max(corners[i][1], corners[i + 1][1]);
                for (int c = c0; c <= c1; c++) for (int r = r0; r <= r1; r++) path[c][r] = true;
            }
            for (int[] d : decor) {
                int c = d[0], r = d[1];
                if (path[c][r] || block[c][r]) continue;                 // scenery never covers the path or other scenery
                block[c][r] = true;
                kind[c][r] = d[2];
                if (d[2] == WATER || d[2] == LILY) water[c][r] = true;
            }
            int[] flowerCols = {0xFFFFFFFF, 0xFFFFC2DC, 0xFFFFE27A, 0xFFC9B6FF, 0xFFFFB07A};
            List<Integer> tu = new ArrayList<>(), fl = new ArrayList<>(), pe = new ArrayList<>();
            int seed = index * 977;
            for (int c = 0; c < COLS; c++) {
                for (int r = 0; r < ROWS; r++) {
                    int x = c * T, y = OY + r * T, h = c * 31 + r * 7 + seed;
                    if (path[c][r]) {
                        for (int k = 0; k < 3; k++) {
                            pe.add(x + 1 + (int) (Gfx.hash(h, 10 + k) * 9));
                            pe.add(y + 1 + (int) (Gfx.hash(h, 20 + k) * 9));
                            pe.add(k == 0 ? 3 : 2);
                        }
                    } else if (!block[c][r]) {
                        for (int k = 0; k < 2; k++) {
                            if (Gfx.hash(h, 30 + k) > 0.55F) {
                                tu.add(x + 1 + (int) (Gfx.hash(h, 40 + k) * 9));
                                tu.add(y + 2 + (int) (Gfx.hash(h, 50 + k) * 8));
                            }
                        }
                        if (Gfx.hash(h, 5) > 0.78F) {
                            fl.add(x + 2 + (int) (Gfx.hash(h, 6) * 8));
                            fl.add(y + 2 + (int) (Gfx.hash(h, 7) * 8));
                            fl.add(index == 2 ? 0xFFFFFFFF : flowerCols[(int) (Gfx.hash(h, 8) * flowerCols.length) % flowerCols.length]);
                        }
                    }
                }
            }
            tuft = toArray(tu); flower = toArray(fl); pebble = toArray(pe);
        }

        boolean buildable(int c, int r) { return !path[c][r] && !block[c][r]; }

        /** Where a pest that walked {@code d} pixels stands: out = x, y and the direction it faces (-1, 0, 1). */
        void pos(float d, float[] out) {
            d = Math.max(0F, Math.min(d, total));
            int i = 0;
            while (i < cum.length - 2 && d > cum[i + 1]) i++;
            float seg = cum[i + 1] - cum[i];
            float k = seg <= 0 ? 0 : (d - cum[i]) / seg;
            out[0] = wx[i] + (wx[i + 1] - wx[i]) * k;
            out[1] = wy[i] + (wy[i + 1] - wy[i]) * k;
            out[2] = Math.signum(wx[i + 1] - wx[i]);
            out[3] = Math.signum(wy[i + 1] - wy[i]);
        }
    }

    private static int[] toArray(List<Integer> l) {
        int[] a = new int[l.size()];
        for (int i = 0; i < a.length; i++) a[i] = l.get(i);
        return a;
    }

    static final Map[] ALL = {
            // 0: the meadow
            new Map(0, new int[][]{{0, 1}, {4, 1}, {4, 6}, {9, 6}, {9, 2}, {13, 2}, {13, 7}, {17, 7}},
                    new int[][]{
                            {1, 4, TREE}, {7, 1, TREE}, {11, 4, TREE}, {16, 2, TREE}, {0, 6, BUSH}, {2, 7, BUSH}, {11, 8, BUSH}, {16, 0, BUSH},
                            {6, 3, ROCK}, {15, 5, ROCK}, {7, 8, ROCK}, {16, 8, CABBAGE}, {17, 8, CABBAGE}, {17, 6, CABBAGE}},
                    0xFFB4E58F, 0xFF6DBE5E, 0xFFEBD3A0, 0xFFC9A066, 0xFFD5B67E, 0xFFBC9660, 0xFFFFF6E8, 0xFFFFF4C0),
            // 1: the pond: a long walk round the water
            new Map(1, new int[][]{{0, 7}, {3, 7}, {3, 2}, {7, 2}, {7, 6}, {12, 6}, {12, 2}, {17, 2}},
                    new int[][]{
                            {9, 3, WATER}, {10, 3, LILY}, {9, 4, LILY}, {10, 4, WATER},
                            {8, 3, REED}, {11, 4, REED}, {8, 4, REED}, {11, 3, REED},
                            {1, 4, TREE}, {15, 4, TREE}, {5, 0, TREE}, {10, 0, TREE}, {0, 3, BUSH}, {5, 5, BUSH}, {14, 7, BUSH}, {16, 0, BUSH},
                            {1, 1, ROCK}, {9, 7, ROCK}, {14, 5, ROCK}, {16, 1, CABBAGE}, {17, 1, CABBAGE}, {17, 3, CABBAGE}},
                    0xFFA6E3A6, 0xFF5DBB86, 0xFFDAD3C2, 0xFFA8A090, 0xFFE8E2D4, 0xFFB8B09C, 0xFFD9B98A, 0xFFE8FFE0),
            // 2: the snowy garden
            new Map(2, new int[][]{{0, 4}, {3, 4}, {3, 1}, {8, 1}, {8, 7}, {12, 7}, {12, 3}, {17, 3}},
                    new int[][]{
                            {1, 1, TREE}, {5, 3, TREE}, {6, 6, TREE}, {10, 1, TREE}, {15, 6, TREE}, {15, 0, TREE},
                            {1, 7, SNOWMAN}, {10, 5, SNOWMAN}, {0, 2, BUSH}, {14, 5, BUSH}, {5, 8, BUSH},
                            {7, 4, ROCK}, {13, 1, ROCK}, {16, 8, ROCK}, {16, 2, CABBAGE}, {17, 2, CABBAGE}, {17, 4, CABBAGE}},
                    0xFFF6FBFF, 0xFFC9E1F4, 0xFFC9A27A, 0xFF9A7650, 0xFFB08A60, 0xFF8A6640, 0xFFF4FAFF, 0xFFE8F4FF),
    };
}
