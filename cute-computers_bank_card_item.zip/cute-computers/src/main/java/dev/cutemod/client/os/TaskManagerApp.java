package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * The Task Manager (key F10 on the computer screen): two live graphs (CPU and memory of this player's PC, see PcSpecs)
 * and the list of every program that is running, with what each one "costs". A program can be switched to or ended.
 * The numbers are a game: they follow what the apps really do (the one in front works hardest, a game or a video works
 * more, a minimized one sleeps) and the weaker the PC, the harder it sweats.
 */
public class TaskManagerApp extends App {
    private static final int HIST = 60;                    // samples in a graph (one every half second = 30 s)
    private static final int ROW = 14, ROWS = 4, LIST_Y = 84, CARD_Y = 20, CARD_H = 48, BAR_Y = 146;
    private static final int X0 = 6, X1 = W - 6;           // the table spans X0..X1

    // palette: a deep violet console with a pink (CPU) and a teal (memory) accent, the same in every look
    private static final int BG_TOP = 0xFF1D1633, BG_BOT = 0xFF130E24;
    private static final int CARD_TOP = 0xFF2C2350, CARD_BOT = 0xFF221B40;
    private static final int TEXT = 0xFFF2ECFF, MUTED = 0xFF9A90B8, SEL = 0xFF3B2F6B;
    private static final int PINK = 0xFFFF7AB8, TEAL = 0xFF5BE6D4, GOOD = 0xFF5BD97A, AMBER = 0xFFFFC857, RED = 0xFFE5486F;

    private static final Random RND = new Random();
    private static final Object SYSTEM = new Object();     // the first row: Cute OS itself, it cannot be ended
    private static final Object GHOST = new Object();      // the last row in the story: behind_you.exe, it cannot be ended either

    private static final class St {
        float cpu, target, memBase;
        int next, age;
    }

    private final Map<App, St> st = new IdentityHashMap<>();
    private final float[] cpuHist = new float[HIST], ramHist = new float[HIST];
    private float cpuLive, ramLive, sysCpu = 2f, sysCpuTarget = 2f, usedMb, totalMb;
    private int ticks, scroll;
    private boolean primed;
    private Object sel = SYSTEM;
    private int mx = -1, my = -1;
    private long lastClickAt = 0;
    private Object lastClicked;
    private String endedName = "";
    private long endedUntil;
    private String ghostSay = "";
    private long ghostUntil;
    private final PcSpecs.Spec spec = PcSpecs.get();

    @Override
    public Component title() { return Component.translatable("cutemod.os.taskmgr"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.taskmgr"); }

    @Override
    public Component status() { return Component.translatable("cutemod.tm.procs", procs().size()); }

    @Override
    public void mouse(int x, int y) { mx = x; my = y; }

    // ---------- the story: part 1, chapter 6 ----------
    /** The extra row appears when the story reaches that chapter and stays (part 1 does not need the Spooky switch). */
    private static boolean ghostOn() { return Progress.step() >= 5 && !Traces.finished(); }   // after the easter egg the row is gone

    private int rowCount() { return procs().size() + 1 + (ghostOn() ? 1 : 0); }

    /** 0 = the system, 1..n = the programs, then the ghost row. */
    private Object rowKey(int idx) {
        List<Shell.Proc> ps = procs();
        return idx == 0 ? SYSTEM : idx <= ps.size() ? ps.get(idx - 1).app() : GHOST;
    }

    private void ghostEnd() {
        int n = Progress.count("q_ghost_total") + 1;
        Progress.setCount("q_ghost_total", n);
        String me = net.minecraft.client.Minecraft.getInstance().getUser().getName();
        ghostSay = t("cutemod.tm.ghost.end." + Math.min(3, n - 1), me);
        ghostUntil = System.currentTimeMillis() + 3500;
        Sfx.error();
        if (Progress.step() == 5) {
            Progress.setCount("q_ghost", Math.min(3, Progress.count("q_ghost") + 1));
            if (Progress.count("q_ghost") >= 3) Progress.advanceIf(5);
        }
    }

    // ---------- data ----------
    private List<Shell.Proc> procs() {
        List<Shell.Proc> all = shell == null ? List.of() : shell.processes();
        return all;
    }

    private static float noise() { return RND.nextFloat(); }

    private float target(Shell.Proc p) {
        float t;
        if (p.front()) t = 5f + noise() * 8f;
        else if (p.app().background()) t = 3f + noise() * 3f;
        else t = 0.2f + noise() * 0.9f;
        if (p.app().busy()) t += 22f + noise() * 16f;
        if (p.app() instanceof GameApp && p.front()) t += 12f + noise() * 18f;
        return Math.min(95f, t);
    }

    private static float baseMem(Shell.Proc p) {
        float m = 45f + Math.abs(p.name().hashCode() % 140);
        App a = p.app();
        if (a instanceof GameApp) m += 70f;
        else if (a instanceof BrowserApp) m += 160f;
        else if (a instanceof PetApp) m += 90f;
        else if (a instanceof PaintApp) m += 60f;
        else if (a instanceof MusicApp) m += 40f;
        return m;
    }

    private float cpuScale() { return Math.max(0.5f, Math.min(3f, 8f / Math.max(2, spec.cores()))); }

    private float memOf(Shell.Proc p) {
        St s = st.get(p.app());
        if (s == null) return 0;
        // the same slots that decide how many programs fit (see Memory): the bar is truthful, full means "no room for another program"
        float perSlot = spec.ramGb() * 1024f * (1f - Memory.SYSTEM_SHARE - 0.02f) / Memory.capacity(spec.ramIdx());
        float grow = 1f + Math.min(0.06f, s.age / 60f / 600f * 0.25f);
        float own = 0.92f + (s.memBase % 40f) / 40f * 0.12f;                 // a little different for every program
        float wt = p.app() instanceof MarketApp || p.app() instanceof TechApp || p.app() instanceof RepairApp ? 0.2f : Memory.weight(p.icon());   // these cost no slot (see ComputerScreen.memExempt)
        return wt * perSlot * own * grow * 0.96f + (float) Math.sin(ticks / 90.0 + s.memBase) * 1.5f;
    }

    @Override
    public void tick() {
        List<Shell.Proc> ps = procs();
        for (Shell.Proc p : ps) {
            St s = st.get(p.app());
            if (s == null) {
                s = new St();
                s.memBase = baseMem(p);
                s.cpu = s.target = 12f + noise() * 25f;              // a program that has just started works hard for a moment
                st.put(p.app(), s);
            }
            s.age++;
            if (--s.next <= 0) { s.next = 20 + RND.nextInt(40); s.target = target(p); }
            s.cpu += (s.target - s.cpu) * 0.1f;
        }
        st.keySet().removeIf(a -> ps.stream().noneMatch(p -> p.app() == a));
        if (sel instanceof App a && ps.stream().noneMatch(p -> p.app() == a)) sel = SYSTEM;
        int maxScroll = Math.max(0, rowCount() - ROWS);
        scroll = Math.max(0, Math.min(maxScroll, scroll));

        if (ticks % 25 == 0) sysCpuTarget = 1.5f + noise() * 3f;
        sysCpu += (sysCpuTarget - sysCpu) * 0.1f;

        float sum = sysCpu, mem = spec.ramGb() * 1024f * Memory.SYSTEM_SHARE + (float) Math.sin(ticks / 240.0) * 6f;
        for (Shell.Proc p : ps) { sum += st.get(p.app()).cpu; mem += memOf(p); }
        totalMb = spec.ramGb() * 1024f;
        usedMb = Math.min(totalMb * 0.98f, mem);
        float c = Math.min(100f, sum * cpuScale());
        cpuLive += (c - cpuLive) * 0.25f;
        ramLive = usedMb / totalMb * 100f;

        if (!primed) {                                              // the graphs do not start empty
            primed = true;
            float c0 = Math.max(3f, cpuLive), r0 = ramLive;
            for (int i = 0; i < HIST; i++) {
                cpuHist[i] = Math.max(1f, c0 + (noise() - 0.5f) * 8f);
                ramHist[i] = Math.max(1f, r0 + (noise() - 0.5f) * 2f);
            }
        }
        if (++ticks % 30 == 0) {
            System.arraycopy(cpuHist, 1, cpuHist, 0, HIST - 1);
            System.arraycopy(ramHist, 1, ramHist, 0, HIST - 1);
            cpuHist[HIST - 1] = cpuLive;
            ramHist[HIST - 1] = ramLive;
        }
    }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        if (!primed) tick();
        Font f = font();
        g.fillGradient(0, 0, W, H, BG_TOP, BG_BOT);
        header(g, f);
        card(g, f, X0, t("cutemod.tm.cpu"), PINK, cpuHist, cpuLive, Math.round(cpuLive) + "%",
                CuteFont.cutSmall(f, spec.cpu() + " · " + spec.ghz() + " GHz", 70));
        card(g, f, W / 2 + 3, t("cutemod.tm.ram"), TEAL, ramHist, ramLive, Math.round(ramLive) + "%",
                CuteFont.cutSmall(f, gb(usedMb) + " / " + spec.ramGb() + " GB", 70));
        table(g, f, mx, my);
        bottom(g, f, mx, my);
    }

    private void header(GuiGraphics g, Font f) {
        g.fillGradient(0, 0, W, 16, 0xFF2D2352, 0xFF241C42);
        g.fill(0, 16, W, 17, 0x33FFFFFF);
        // a little heartbeat line as the logo
        int hx = 8, hy = 8;
        int[][] seg = {{0, 0}, {2, 0}, {3, -3}, {4, 4}, {5, -1}, {6, 0}, {9, 0}};
        for (int i = 0; i < seg.length - 1; i++) {
            int xa = hx + seg[i][0], ya = hy + seg[i][1], xb = hx + seg[i + 1][0], yb = hy + seg[i + 1][1];
            g.fill(Math.min(xa, xb), Math.min(ya, yb), Math.max(xa, xb) + 1, Math.max(ya, yb) + 1, PINK);
        }
        CuteFont.draw(g, f, title(), 22, 4, TEXT, false);
        String pc = spec.pcName();
        CuteFont.drawSmall(g, f, pc, W - 8 - CuteFont.widthSmall(f, pc), 5, MUTED);
    }

    private void card(GuiGraphics g, Font f, int x, String name, int accent, float[] hist, float live, String big, String sub) {
        int w = W / 2 - 9, y = CARD_Y;
        roundRect(g, x - 1, y - 1, w + 2, CARD_H + 2, 6, 0x33FFFFFF);
        Theme.rgrad(g, x, y, w, CARD_H, 5, CARD_TOP, CARD_BOT);
        Theme.rgrad(g, x + 1, y + 1, w - 2, 12, 4, 0x1CFFFFFF, 0x00FFFFFF);
        // a colour tab on the left edge
        Theme.rrect(g, x + 5, y + 5, 3, 9, 1, accent);
        CuteFont.draw(g, f, name, x + 12, y + 4, TEXT, false);
        CuteFont.drawSmall(g, f, sub, x + 12, y + 14, MUTED);
        g.pose().pushPose();
        float sc = 1.5f;
        g.pose().translate(x + w - 6 - CuteFont.width(f, big) * sc, y + 4, 0);
        g.pose().scale(sc, sc, 1f);
        CuteFont.draw(g, f, big, 0, 0, live > 85 ? RED : accent, false);
        g.pose().popPose();
        graph(g, x + 6, y + 26, w - 12, 18, hist, live, accent);
    }

    private static void graph(GuiGraphics g, int x, int y, int w, int h, float[] hist, float live, int col) {
        Theme.rrect(g, x, y, w, h, 3, 0x66000000);
        for (int q = 1; q < 4; q++) g.fill(x + 1, y + h * q / 4, x + w - 1, y + h * q / 4 + 1, 0x14FFFFFF);
        int n = hist.length, inner = w - 2;
        int top = (col & 0x00FFFFFF) | 0xCC000000, bot = (col & 0x00FFFFFF) | 0x28000000;
        for (int i = 0; i < n; i++) {
            float v = i == n - 1 ? live : hist[i];
            int bh = Math.round((h - 2) * Math.max(0f, Math.min(100f, v)) / 100f);
            if (bh <= 0) continue;
            int x0 = x + 1 + i * inner / n, x1 = x + 1 + (i + 1) * inner / n;
            if (x1 <= x0) x1 = x0 + 1;
            g.fillGradient(x0, y + h - 1 - bh, x1, y + h - 1, top, bot);
            g.fill(x0, y + h - 1 - bh, x1, y + h - bh, mix(col, 0xFFFFFF, 0.5f));
        }
    }

    private void table(GuiGraphics g, Font f, int mx, int my) {
        CuteFont.drawSmall(g, f, t("cutemod.tm.name"), 30, 73, MUTED);
        String cpu = t("cutemod.tm.cpu"), ram = t("cutemod.tm.ram");
        CuteFont.drawSmall(g, f, cpu, 212 - CuteFont.widthSmall(f, cpu), 73, MUTED);
        CuteFont.drawSmall(g, f, ram, 288 - CuteFont.widthSmall(f, ram), 73, MUTED);
        g.fill(X0, 82, X1, 83, 0x22FFFFFF);

        List<Shell.Proc> ps = procs();
        int total = rowCount();
        int body = shell.color().bodyColor;
        for (int r = 0; r < ROWS; r++) {
            int idx = scroll + r;
            if (idx >= total) break;
            int y = LIST_Y + r * ROW;
            Shell.Proc p = idx == 0 || idx > ps.size() ? null : ps.get(idx - 1);
            Object key = rowKey(idx);
            boolean ghost = key == GHOST;
            boolean selected = key == sel, hov = in(mx, my, X0, y, X1 - X0 - 4, ROW - 1);
            if (selected) {
                Theme.rrect(g, X0, y, X1 - X0 - 4, ROW - 1, 4, SEL);
                Theme.rrect(g, X0, y + 2, 2, ROW - 5, 1, PINK);
            } else if (hov) {
                Theme.rrect(g, X0, y, X1 - X0 - 4, ROW - 1, 4, 0x20FFFFFF);
            }
            if (ghost) { Theme.rrect(g, X0 + 5, y + 1, 12, 12, 3, 0xFF050308); g.fill(X0 + 8, y + 5, X0 + 10, y + 7, 0xFFFF4A4A); g.fill(X0 + 12, y + 5, X0 + 14, y + 7, 0xFFFF4A4A); }
            else icon(g, p, X0 + 5, y + 1, body);
            String name = ghost ? t("cutemod.tm.ghost.name") : p == null ? t("cutemod.tm.system") : p.name();
            float cpuV; float memV;
            if (ghost) { cpuV = 0; memV = 0; }
            else if (p == null) { cpuV = sysCpu * cpuScale(); memV = 330f; }
            else { St s = st.get(p.app()); cpuV = s == null ? 0 : s.cpu * cpuScale(); memV = memOf(p); }
            // status dot: green = the one you were using, amber = sleeping in the background, teal = the system
            disc(g, X0 + 22, y + ROW / 2 - 1, 2, ghost ? 0xFFFF4A4A : p == null ? TEAL : p.front() ? GOOD : AMBER);
            CuteFont.draw(g, f, CuteFont.cut(f, name, 140), 30, y + 3, TEXT, false);
            // the CPU cell is a heat map: the more it works the pinker it glows
            int heat = mix(0xFF2A2248, PINK, Math.min(1f, cpuV / 50f) * 0.75f);
            Theme.rrect(g, 176, y + 1, 40, ROW - 3, 3, heat);
            String cs = Math.round(cpuV) + "%";
            CuteFont.draw(g, f, cs, 212 - CuteFont.width(f, cs), y + 3, TEXT, false);
            int memHeat = mix(0xFF2A2248, TEAL, Math.min(1f, memV / 600f) * 0.5f);
            Theme.rrect(g, 222, y + 1, 68, ROW - 3, 3, memHeat);
            String ms = ghost ? t("cutemod.tm.ghost.mem") : memV >= 1000 ? String.format("%.1f GB", memV / 1024f) : Math.round(memV) + " MB";
            CuteFont.draw(g, f, ms, 286 - CuteFont.width(f, ms), y + 3, TEXT, false);
        }
        if (ps.isEmpty()) {                                           // only the system: a gentle hint under it
            CuteFont.drawSmall(g, f, t("cutemod.tm.empty"), (W - CuteFont.widthSmall(f, t("cutemod.tm.empty"))) / 2, LIST_Y + ROW + 14, MUTED);
        }
        if (total > ROWS) {                                           // scroll bar
            int th = ROWS * ROW;
            Theme.rrect(g, W - 5, LIST_Y, 2, th, 1, 0x22FFFFFF);
            int bh = Math.max(8, th * ROWS / total), by = LIST_Y + (th - bh) * scroll / Math.max(1, total - ROWS);
            Theme.rrect(g, W - 5, by, 2, bh, 1, 0xAAFFFFFF);
        }
    }

    /** A process icon: the Dock icon shrunk to 12 px; a program without one (a tool) gets a plain tile with a gear. */
    private void icon(GuiGraphics g, Shell.Proc p, int x, int y, int body) {
        if (p != null && p.icon() >= 0) {
            g.pose().pushPose();
            g.pose().translate(x, y, 0);
            g.pose().scale(0.375f, 0.375f, 1f);
            Desktop.drawIcon(g, p.icon(), 0, 0, body);
            g.pose().popPose();
            return;
        }
        int a = p == null ? PINK : 0xFF8A86A8, b = p == null ? 0xFFE0508A : 0xFF55527A;
        Theme.rgrad(g, x, y, 12, 12, 3, a, b);
        if (p == null) {                                              // a tiny heart: Cute OS
            g.fill(x + 3, y + 3, x + 5, y + 5, 0xFFFFFFFF); g.fill(x + 7, y + 3, x + 9, y + 5, 0xFFFFFFFF);
            g.fill(x + 3, y + 5, x + 9, y + 7, 0xFFFFFFFF); g.fill(x + 4, y + 7, x + 8, y + 8, 0xFFFFFFFF);
            g.fill(x + 5, y + 8, x + 7, y + 9, 0xFFFFFFFF);
        } else {
            g.fill(x + 3, y + 3, x + 9, y + 9, 0xFFFFFFFF);
            g.fill(x + 5, y + 5, x + 7, y + 7, b);
        }
    }

    // ---------- bottom bar ----------
    private int switchW(Font f) { return CuteFont.widthSmall(f, t("cutemod.tm.switch")) + 14; }

    private int endW(Font f) { return CuteFont.widthSmall(f, t("cutemod.tm.end")) + 14; }

    private void bottom(GuiGraphics g, Font f, int mx, int my) {
        g.fillGradient(0, BAR_Y - 1, W, H, 0xFF241C42, 0xFF1A1431);
        g.fill(0, BAR_Y - 1, W, BAR_Y, 0x33FFFFFF);
        int ew = endW(f), sw = switchW(f);
        int ex = W - 6 - ew, sx = ex - 5 - sw, by = BAR_Y + 3;
        boolean canEnd = sel instanceof App || sel == GHOST;
        pill(g, f, sx, by, sw, 13, t("cutemod.tm.switch"), 0xFF6A56C8, true, in(mx, my, sx, by, sw, 13));
        pill(g, f, ex, by, ew, 13, t("cutemod.tm.end"), RED, canEnd, canEnd && in(mx, my, ex, by, ew, 13));
        String info;
        int col = MUTED;
        if (System.currentTimeMillis() < ghostUntil) { info = ghostSay; col = RED; }
        else if (System.currentTimeMillis() < endedUntil) { info = t("cutemod.tm.ended", endedName); col = GOOD; }
        else info = t("cutemod.tm.procs", procs().size());
        CuteFont.drawSmall(g, f, CuteFont.cutSmall(f, info, sx - 14), 8, by + 3, col);
    }

    private static void pill(GuiGraphics g, Font f, int x, int y, int w, int h, String s, int face, boolean on, boolean hov) {
        if (!on) face = 0xFF4A4468;
        else if (hov) face = mix(face, 0xFFFFFF, 0.22f);
        Theme.rrect(g, x, y + 1, w, h, h / 2, 0x40000000);
        Theme.rgrad(g, x, y, w, h, h / 2, mix(face, 0xFFFFFF, 0.28f), face);
        Theme.rgrad(g, x + 2, y + 1, w - 4, Math.max(2, h / 2 - 1), h / 4, 0x44FFFFFF, 0x00FFFFFF);
        CuteFont.drawSmall(g, f, s, x + (w - CuteFont.widthSmall(f, s)) / 2, y + (h - 7) / 2 + 1, on ? 0xFFFFFFFF : 0xFF9A94B8);
    }

    // ---------- input ----------
    private static String gb(float mb) { return String.format("%.1f GB", mb / 1024f); }

    @Override
    public boolean click(int x, int y, int button) {
        Font f = font();
        int ew = endW(f), sw = switchW(f), ex = W - 6 - ew, sx = ex - 5 - sw, by = BAR_Y + 3;
        if (in(x, y, sx, by, sw, 13)) { doSwitch(); return true; }
        if (in(x, y, ex, by, ew, 13)) { doEnd(); return true; }
        if (in(x, y, X0, LIST_Y, X1 - X0 - 4, ROWS * ROW)) {
            List<Shell.Proc> ps = procs();
            int idx = scroll + (y - LIST_Y) / ROW;
            if (idx < rowCount()) {
                Object key = rowKey(idx);
                long now = System.currentTimeMillis();
                if (key == lastClicked && now - lastClickAt < 350) { sel = key; doSwitch(); lastClicked = null; return true; }
                sel = key; lastClicked = key; lastClickAt = now;
                if (button == 1 && key != SYSTEM) doEnd();            // right click: end it
            }
            return true;
        }
        return true;
    }

    private void doSwitch() {
        if (sel == GHOST) return;
        if (sel instanceof App a) shell.switchTo(a); else shell.switchTo(null);
    }

    private void doEnd() {
        if (sel == GHOST) { ghostEnd(); return; }
        if (!(sel instanceof App a)) return;
        for (Shell.Proc p : procs()) if (p.app() == a) { endedName = p.name(); break; }
        endedUntil = System.currentTimeMillis() + 2500;
        sel = SYSTEM;
        shell.endTask(a);
    }

    @Override
    public boolean scroll(double amount) {
        scroll = Math.max(0, Math.min(Math.max(0, rowCount() - ROWS), scroll - (int) Math.signum(amount)));
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        List<Shell.Proc> ps = procs();
        int cur = 0;
        if (sel == GHOST) cur = ps.size() + 1;
        else if (sel instanceof App a) for (int i = 0; i < ps.size(); i++) if (ps.get(i).app() == a) cur = i + 1;
        switch (keyCode) {
            case 265, 264 -> {                                         // Up / Down
                int n = Math.floorMod(cur + (keyCode == 264 ? 1 : -1), rowCount());
                sel = rowKey(n);
                if (n < scroll) scroll = n;
                if (n >= scroll + ROWS) scroll = n - ROWS + 1;
            }
            case 257, 335 -> doSwitch();                               // Enter
            case 261 -> doEnd();                                       // Delete
            case 256 -> shell.home();                                  // Esc closes the manager
            default -> { return false; }
        }
        return true;
    }
}
