package dev.cutemod.client.os;

import dev.cutemod.data.PcHardware;

/**
 * How nice the games look on THIS computer: it follows the video card (see {@link PcHardware#gpuLevel}). The levels are
 * 0 low, 1 medium, 2 high and 3 ultra. A weak card gets a plain backdrop, no soft shadows, glows or vignettes and a grainy
 * old-screen look; a strong one gets everything (and the ultra ones a little extra shine). It costs the weak PC less to draw too.
 * Installing a better video card changes it at once.
 */
public final class GfxQuality {
    private GfxQuality() {}

    public static final int LOW = 0, MEDIUM = 1, HIGH = 2, ULTRA = 3;

    private static int seen = Integer.MIN_VALUE, level = HIGH;

    /** The current level (cheap: it is looked at again only when the hardware may have changed). */
    /** A game the PC is too weak for draws itself in the plainest way while it is on screen (-1 = no override). */
    private static int forced = -1;

    public static void force(int lv) { forced = lv; }

    public static int level() {
        if (forced >= 0) return forced;
        int v = PcSpecs.version();
        if (v != seen) {
            seen = v;
            level = PcHardware.gpuLevel(PcSpecs.get().gpuTier());
        }
        return level;
    }

    public static boolean low() { return level() == LOW; }

    public static boolean ultra() { return level() == ULTRA; }

    // ---------- content only for strong video cards ----------
    /** Video card level (index in PcHardware.GPU_NAMES) an animated wallpaper of the shop needs: 30-39 a 6 GB card, 40-50 a 12 GB card; the still ones need none. */
    public static int wallNeeds(int wall) { return wall >= 40 && wall <= 50 ? 5 : wall >= 30 && wall <= 39 ? 3 : 0; }

    /** Video card level a screensaver needs: the busy ones (bees, bubbles, the aquarium, the pipes) want a real card. */
    public static int saverNeeds(int saver) { return switch (saver) { case 5, 6 -> 3; case 7 -> 4; case 8 -> 5; default -> 0; }; }

    /** True if this computer's video card is at least that level. A better card only ever comes in: what was bought before stays. */
    public static boolean gpuOk(int need) { return need <= 0 || PcSpecs.get().gpuTier() >= need; }

    /** "RTX 3060", "Radish 9900 XT": the name of the card of this level without the brand, short enough for a button. */
    public static String shortName(int tier) {
        String n = PcHardware.GPU_NAMES[Math.max(0, Math.min(PcHardware.GPU_NAMES.length - 1, tier))];
        int sp = n.indexOf(' ');
        return sp < 0 ? n : n.substring(sp + 1);
    }

    /** The lang key of the name of a level: cutemod.gfx.0 ... cutemod.gfx.3. */
    public static String key(int level) { return "cutemod.gfx." + level; }
}
