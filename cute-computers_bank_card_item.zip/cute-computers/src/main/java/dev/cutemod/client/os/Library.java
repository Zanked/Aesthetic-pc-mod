package dev.cutemod.client.os;

import dev.cutemod.data.PcHardware;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * The catalog of CuteStore and what the player owns: bought games, installs (they take a few seconds
 * of real time, even when the computer screen is closed), play time and best scores.
 * Saved in cutemod_library.txt. Coins are handled by {@link Progress}.
 */
public final class Library {
    private Library() {}

    /** One game in the store. rating is x10 (47 = 4.7), sizeMb is the catalog size: the real size on the disk is
     *  sizeMb x {@link #SIZE_SCALE} MB (see {@link #sizeOf}). */
    public record Game(String id, int price, String genre, int sizeMb, int rating, int rgb) {}

    public static final List<Game> GAMES = List.of(
            new Game("pink", 15, "arcade", 12, 38, 0xF4A7C3),
            new Game("green", 20, "puzzle", 18, 44, 0x8FD39A),
            new Game("white", 15, "arcade", 9, 41, 0xE8EAF0),
            new Game("blue", 20, "arcade", 14, 40, 0x8EC3F2),
            new Game("orange", 20, "puzzle", 11, 36, 0xF5B06B),
            new Game("purple", 25, "arcade", 10, 39, 0x4A3A66),
            new Game("yellow", 20, "arcade", 8, 35, 0xF3D46A),
            new Game("red", 30, "puzzle", 22, 43, 0xE27B72),
            new Game("breakout", 35, "arcade", 16, 42, 0xC98B5A),
            new Game("cubes", 40, "puzzle", 20, 47, 0xB57BD6),
            new Game("pong", 35, "arcade", 13, 37, 0x7ED957),
            new Game("bees", 55, "arcade", 27, 41, 0xF5C518),
            new Game("horror", 80, "horror", 45, 46, 0x8B1A2B),
            new Game("craft", 220, "sandbox", 120, 49, 0x5BBF4A),
            new Game("durak", 90, "cards", 15, 45, 0x2E7D4F),
            new Game("sakura", 70, "anime", 24, 46, 0xF58FB8),
            new Game("blocks", 75, "puzzle", 10, 47, 0x6A8FE0),
            new Game("cakes", 100, "cooking", 17, 48, 0xF4A8B8),
            new Game("cakefactory", 90, "cooking", 14, 46, 0xF7B6D2),
            new Game("racer", 60, "arcade", 16, 45, 0xF58FB8),
            new Game("checkers", 90, "board", 12, 47, 0xC48BB0),
            new Game("slice", 65, "arcade", 14, 46, 0xE8475A),
            new Game("rabbit", 70, "arcade", 18, 47, 0x8ED36A),
            new Game("dash", 80, "arcade", 20, 47, 0x6FC7E8),
            new Game("tower", 15, "arcade", 8, 47, 0x6EC6FF),
            new Game("hangman", 15, "puzzle", 6, 45, 0xF5B06B),
            new Game("billiards", 25, "arcade", 12, 47, 0x2E8B57),
            new Game("bomber", 80, "arcade", 16, 48, 0xF59BC1),
            new Game("hive", 85, "puzzle", 18, 47, 0x7E6BD6),
            new Game("mayhem", 90, "arcade", 22, 48, 0x4F9BE8),
            new Game("funnyfarm", 95, "farm", 22, 48, 0x7BC96F),
            new Game("fighters", 90, "fighting", 24, 48, 0xE0484F),
            new Game("birds", 70, "arcade", 15, 47, 0xE0453A),
            new Game("cicada", 95, "horror", 38, 49, 0xB3262E),
            new Game("frog", 85, "arcade", 24, 48, 0x3FB44A),
            new Game("night", 90, "horror", 32, 48, 0x5A3A9A),
            new Game("ward", 95, "horror", 36, 48, 0x2F7F86),
            new Game("skribbl", 85, "creative", 20, 48, 0xF58FB8),
            new Game("garden", 80, "strategy", 18, 47, 0x6FBF5A),
            new Game("bedwars", 95, "strategy", 22, 47, 0xE8564F));

    /**
     * A downloadable app: the desktop apps that are not part of the system. Until it is installed it is hidden
     * from the Dock and the Start menu. icon = its number in the Dock (see {@link Desktop#drawIcon}). price 0 = free.
     */
    public record Program(String id, int icon, int price, String genre, int sizeMb, int rating, int rgb) {}

    public static final List<Program> PROGRAMS = List.of(
            new Program("calc", 5, 0, "tools", 2, 44, 0x7FA8E8),
            new Program("paint", 4, 0, "creative", 6, 46, 0xF3A6C8),
            new Program("terminal", 11, 0, "tools", 3, 47, 0x2B4A33),
            new Program("mail", 14, 0, "social", 5, 41, 0xE9A0A0),
            new Program("music", 7, 10, "media", 14, 45, 0x8A6AC6),
            new Program("weather", 16, 0, "tools", 4, 46, 0x5AA8F0),
            new Program("farm", 17, 30, "pets", 7, 47, 0x8FD39A),
            new Program("fishing", 18, 25, "pets", 6, 46, 0x6FD0FF),
            new Program("style", 19, 25, "pets", 5, 47, 0xB57BD6),
            new Program("beats", 20, 30, "media", 8, 46, 0x6A4AD0),
            new Program("season", 21, 0, "pets", 4, 47, 0xF0A030),
            new Program("gift", 23, 0, "tools", 3, 47, 0xF08AA8),
            new Program("quiz", 24, 0, "tools", 4, 46, 0x7ACB8A),
            new Program("tictac", 25, 0, "pets", 2, 45, 0x6FB8E8),
            new Program("wheel", 26, 0, "tools", 3, 46, 0xFF9A4A),
            new Program("photo", 28, 20, "creative", 6, 47, 0x8A9AE8),
            new Program("stickers", 29, 15, "creative", 5, 46, 0xE98AC8),
            new Program("bank", 30, 0, "tools", 2, 46, 0xF08A9A),
            new Program("radio", 32, 15, "media", 9, 47, 0x7A8AE8),
            new Program("petstats", 33, 10, "pets", 2, 47, 0xE8A04A),
            new Program("tales", 34, 15, "media", 6, 48, 0xC8905A),
            new Program("school", 35, 0, "pets", 5, 47, 0x5B8DEF));

    /** Icon numbers of removed apps (Habits, Wish list). The numbers of the other apps are saved in the Dock layouts, so they are not reused. */
    private static final int RETIRED_ICON = 27, RETIRED_ICON_2 = 31;

    /** Apps of the pet that live on the town map or in the pet's house only: no Dock icon, no Start menu entry, no store page. The map and the house open them. */
    private static final Set<String> PLACES = Set.of("farm", "fishing", "school", "style", "photo", "stickers", "petstats", "tictac", "season");

    public static boolean placeOnly(String id) { return PLACES.contains(id); }

    /** True for the Dock number of a place app (farm, school, wardrobe...): its back button returns to CutePet. */
    public static boolean petPlace(int icon) {
        Program p = programByIcon(icon);
        return p != null && placeOnly(p.id());
    }

    public static final int DEAL_PERCENT = 30;

    /** The catalog sizes are small numbers; on the disk every unit takes this many MB (so a 120 game is 12 GB). */
    public static final int SIZE_SCALE = 100;

    private static boolean loaded, dirty;
    private static int saveDelay;
    private static final Set<String> owned = new HashSet<>();
    private static final Set<String> notified = new HashSet<>();
    /** Apps that were bought (or free) and then uninstalled: they stay owned, installing them again is free. */
    private static final Set<String> removed = new HashSet<>();
    private static final Map<String, Long> installStart = new HashMap<>();
    private static final Map<String, Integer> playSeconds = new HashMap<>();
    private static final Map<String, Integer> best = new HashMap<>();
    private static final Map<String, Integer> reviewStars = new HashMap<>();
    private static final Map<String, String> reviewText = new HashMap<>();

    // ---------- catalog ----------
    public static Game game(String id) {
        for (Game g : GAMES) if (g.id().equals(id)) return g;
        return GAMES.get(0);
    }

    public static String name(String id) {
        return Component.translatable((isProgram(id) ? "cutemod.os." : "cutemod.game.") + id).getString();
    }

    // ---------- apps ----------
    public static Program program(String id) {
        for (Program p : PROGRAMS) if (p.id().equals(id)) return p;
        return null;
    }

    public static boolean isProgram(String id) { return program(id) != null; }

    /** A game or an app that exists (an old save may still know the Shop app, which was removed). */
    private static boolean known(String id) {
        for (Game g : GAMES) if (g.id().equals(id)) return true;
        return isProgram(id);
    }

    public static Program programByIcon(int icon) {
        for (Program p : PROGRAMS) if (p.icon() == icon) return p;
        return null;
    }

    /** False while a store app (the Dock icon number) is not installed: it is hidden from the Dock and the Start menu. */
    public static boolean available(int icon) {
        if (icon == RETIRED_ICON || icon == RETIRED_ICON_2) return false;                   // an app that was removed (its number stays unused)
        if (Retro.safe()) return Retro.safeAllows(icon);          // Safe Mode: only a few plain apps
        if (Items.isFolder(icon)) return Folders.exists(icon);
        if (icon >= Items.GAME_BASE && icon < Items.FOLDER_BASE)          // a game is an app of its own once it is installed
            return Items.isGame(icon) && installed(Items.gameId(icon));   // (the number of a removed game stays unused)
        if (icon < 2) return false;                               // the old own-game icon and Games folder are gone
        Program p = programByIcon(icon);
        if (p != null && placeOnly(p.id())) return false;         // opened from the map or the pet's house only
        return p == null || installed(p.id());
    }

    /** Like {@link #available}, but a place of the map counts too: it may run (the map opens it), it only has no icon. */
    public static boolean runnable(int icon) {
        Program p = programByIcon(icon);
        if (p != null && placeOnly(p.id())) return !Retro.safe();
        return available(icon);
    }

    // ---------- games and apps alike ----------
    public static int priceOf(String id) { Program p = program(id); return p != null ? p.price() : game(id).price(); }

    /** The size on the disk in MB. */
    public static int sizeOf(String id) { return rawSize(id) * SIZE_SCALE; }

    private static int rawSize(String id) { Program p = program(id); return p != null ? p.sizeMb() : game(id).sizeMb(); }

    // ---------- what a game wants from the PC ----------
    private static boolean isGame(String id) {
        for (Game g : GAMES) if (g.id().equals(id)) return true;
        return false;
    }

    /**
     * The system requirements of EVERY game: {memory level, video card level} (indices in PcHardware.RAM_GB / GPU_NAMES:
     * memory 0 = 2 GB, 1 = 4, 2 = 8, 3 = 16, 4 = 32, 5 = 64; card 0 = the built-in one, 1 = GT 710, 2 = GTX 1050, 3 = Radish 5500,
     * 4 = RTX 3060, 5 = Radish 7800, 6 = RTX 4080, 7 = Radish 9900 XT).
     * <p>How the two numbers are chosen (they are NOT always equal any more):
     * <ul>
     *   <li><b>Memory</b> = what the game has to hold: a big map, many objects or characters, lots of levels or content.</li>
     *   <li><b>Video card</b> = how hard the picture is to draw: painted art, many effects, scaling, dynamic light.</li>
     *   <li><b>Online games</b> (Bed Wars, Dangerous Weapons, Scribble Pals, Bombers, Kitty Dash) are demanding too: many players,
     *       big shared maps and live sync need a good PC. (A weak PC never lags in an online match, it only gets the plain picture.)
     *       The simple online board and card games (Checkers, Billiards, Durak) stay light.</li>
     *   <li>The top of the ladders (32-64 GB, RTX 4080 / 9900 XT) belongs to a few flagship single-player games, so the
     *       expensive parts have a real use.</li>
     * </ul>
     * Small, simple games run on the stock PC. The store page shows the requirements for each game.
     */
    private static final java.util.Map<String, int[]> REQ = java.util.Map.ofEntries(
            // ---- stock PC (2 GB, built-in card): small arcade, cards and board games ----
            e("pink", 0, 0), e("white", 0, 0), e("blue", 0, 0), e("orange", 0, 0), e("purple", 0, 0), e("yellow", 0, 0),
            e("pong", 0, 0), e("tower", 0, 0), e("hangman", 0, 0), e("billiards", 0, 0), e("checkers", 0, 0),
            e("durak", 0, 0), e("blocks", 0, 0),
            // ---- 4 GB / GT 710: the first cheap parts (30 + 50 coins) open a lot ----
            e("green", 1, 1), e("red", 1, 1), e("breakout", 1, 1), e("cubes", 1, 1),
            e("cakefactory", 1, 1), e("racer", 1, 1), e("rabbit", 1, 1),
            e("slice", 0, 1),        // fruit and juice splashes: light on memory, wants a card
            e("skribbl", 2, 3),      // online, 8 players: eight canvases and live drawing
            e("bomber", 2, 3),       // online, 4 players: explosions and many objects
            // ---- 8 GB / GTX 1050: busier screens ----
            e("bees", 1, 2), e("cakes", 1, 2), e("birds", 1, 2),
            e("funnyfarm", 2, 2),    // many animals and objects
            e("mayhem", 3, 4),       // online, 4 fighters: fast physics and effects
            e("bedwars", 3, 4),      // online, 4 teams on a 45 x 31 map with a minimap
            // ---- 16 GB / strong card: big worlds and painted art ----
            e("dash", 2, 3),         // online race, fast scaling track
            e("sakura", 1, 3),       // painted anime art
            e("garden", 3, 3),       // 20 waves, hundreds of pests and plants
            e("fighters", 2, 4),     // detailed hand-drawn fighters: card
            e("frog", 3, 4),
            e("night", 3, 4),        // six cameras, a lot of art
            // ---- the top shelf: 32 GB and the best cards ----
            e("hive", 4, 2),         // the biggest map in the store (120 x 68), eight characters: memory, not card
            e("ward", 4, 5),
            e("cicada", 3, 5),       // eight painted scenes, six faces for each character: card
            e("horror", 2, 6),       // the whole picture is dynamic light and shadow: RTX 4080
            e("craft", 5, 7));       // the flagship: a huge world, 64 GB and the best card

    private static java.util.Map.Entry<String, int[]> e(String id, int ram, int gpu) {
        return java.util.Map.entry(id, new int[]{ram, gpu});
    }

    /** The memory level (index in PcHardware.RAM_GB) a game wants: the table above, and for a game that is not in it, the bigger the game, the more. Apps want nothing. */
    public static int minRam(String id) {
        if (!isGame(id)) return 0;
        int[] r = REQ.get(id);
        if (r != null) return r[0];
        int raw = game(id).sizeMb();
        return raw < 16 ? 0 : raw < 25 ? 1 : raw < 40 ? 2 : 3;
    }

    /** The video card level (index in PcHardware.GPU_NAMES) a game wants. */
    public static int minGpu(String id) {
        if (!isGame(id)) return 0;
        int[] r = REQ.get(id);
        if (r != null) return r[1];
        int raw = game(id).sizeMb();
        return raw < 16 ? 0 : raw < 25 ? 1 : raw < 40 ? 2 : raw < 100 ? 3 : 4;
    }

    /** How many steps this PC is short of the game (memory and video card together, 0 = it runs well). */
    public static int deficit(String id) {
        PcSpecs.Spec s = PcSpecs.get();
        return Math.max(0, minRam(id) - s.ramIdx()) + Math.max(0, minGpu(id) - s.gpuTier());
    }

    /** "4 GB RAM, Meowforce GT 710" (every game has one: the stock PC's "2 GB RAM, any video card" too; empty for apps). */
    public static String reqText(String id) {
        if (!isGame(id)) return "";
        String ram = Component.translatable("cutemod.store.req.ram", PcHardware.RAM_GB[minRam(id)]).getString();
        String gpu = minGpu(id) > 0 ? PcHardware.GPU_NAMES[minGpu(id)] : Component.translatable("cutemod.store.req.anygpu").getString();
        return ram + ", " + gpu;
    }

    /** "600 MB" or "4.5 GB". */
    public static String sizeText(String id) { return mbText(sizeOf(id)); }

    public static String mbText(long mb) {
        if (mb < 1000) return Component.translatable("cutemod.store.size.mb", mb).getString();
        return Component.translatable("cutemod.store.size.gb", String.format(java.util.Locale.ROOT, "%.1f", mb / 1024.0)).getString();
    }

    // ---------- the disk ----------
    /** MB taken on C: by the system and everything that is installed or installing (apps of the map count as always installed). */
    public static long usedMb() {
        ensure();
        PcSpecs.Spec s = PcSpecs.get();
        long mb = s.baseGb() * 1024L + 300;
        for (Game g : GAMES) if (progress(g.id()) >= 0) mb += sizeOf(g.id());
        for (Program p : PROGRAMS) if (placeOnly(p.id()) || system(p.id()) || progress(p.id()) >= 0) mb += sizeOf(p.id());
        return mb + Albums.ownedMb();                       // the music of the music store lives on C: too
    }

    public static long freeMb() { return Math.max(0, PcSpecs.get().diskC() * 1024L - usedMb()); }

    /** False when C: has no room for this game or app: it must not be installed until something is removed. */
    public static boolean hasRoom(String id) { return placeOnly(id) || freeMb() >= sizeOf(id); }

    public static int ratingOf(String id) { Program p = program(id); return p != null ? p.rating() : game(id).rating(); }

    public static String genreOf(String id) { Program p = program(id); return p != null ? p.genre() : game(id).genre(); }

    /** The game on sale today (the same for everybody, changes every day). */
    public static String dealId() {
        if (Halloween.active()) {                       // the event: a horror game is on sale every day
            String[] horror = {"horror"};
            return horror[(int) Math.floorMod(System.currentTimeMillis() / 86_400_000L, (long) horror.length)];
        }
        long day = System.currentTimeMillis() / 86_400_000L;
        return GAMES.get((int) Math.floorMod(day * 7 + 3, (long) GAMES.size())).id();
    }

    /** The discount of the game of the day (bigger during the Halloween event). */
    public static int dealPercent() { return Halloween.active() ? 50 : DEAL_PERCENT; }

    public static int priceNow(String id) {
        if (isProgram(id)) return program(id).price();         // no sales for apps
        int p = game(id).price();
        return id.equals(dealId()) ? Math.max(1, p * (100 - dealPercent()) / 100) : p;
    }

    /** How long the install takes: the download does not care about the disk, writing the files does (HDD slow, NVMe fast). */
    private static long durationMs(String id) {
        int raw = rawSize(id);
        double net = Math.max(0.1, Modem.speed());                 // the better the modem the faster the download
        long download = (long) (((isProgram(id) ? 2500L : 5000L) + raw * 60L) / net);
        long write = (long) (raw * 70L / PcHardware.diskSpeed(PcSpecs.get().diskIdx()));
        return download + write;
    }

    // ---------- state ----------
    public static boolean owned(String id) { ensure(); return owned.contains(id); }

    /** True if the app was uninstalled but is still owned (it can be installed again for free). */
    public static boolean uninstalled(String id) { ensure(); return owned.contains(id) && removed.contains(id); }

    /** 0..1 while installing, 1 when installed, -1 if not installed (not owned, or an app that was removed). */
    public static float progress(String id) {
        ensure();
        if (!owned.contains(id) || removed.contains(id)) return -1;
        Long start = installStart.get(id);
        if (start == null) return 1;
        return Math.max(0f, Math.min(1f, (System.currentTimeMillis() - start) / (float) durationMs(id)));
    }

    /** The Bank is part of the system: it is always installed, it cannot be removed and it is not sold in the store (it is the only place that shows the coins). */
    public static boolean system(String id) { return "bank".equals(id); }

    public static boolean installed(String id) { return placeOnly(id) || system(id) || progress(id) >= 1f; }

    public static int secondsLeft(String id) {
        Long start = installStart.get(id);
        if (start == null) return 0;
        return (int) Math.max(0, Math.ceil((durationMs(id) - (System.currentTimeMillis() - start)) / 1000.0));
    }

    /** How many games the player owns (apps are not counted). */
    public static int ownedCount() {
        ensure();
        int n = 0;
        for (Game g : GAMES) if (owned.contains(g.id())) n++;
        return n;
    }

    /** Buys a game or an app (free apps cost nothing) and starts installing it. Returns false if there are not enough coins. */
    public static boolean buy(String id) {
        ensure();
        if (owned.contains(id)) return false;
        if (!Modem.connected()) { Modem.note(); return false; }          // CuteStore is online
        if (!hasRoom(id)) return false;
        int price = priceNow(id);
        if (price > 0 && !Progress.spend(price)) return false;
        owned.add(id);
        removed.remove(id);
        installStart.put(id, System.currentTimeMillis());
        Progress.toast(isProgram(id) ? "cutemod.toast.app_installing" : "cutemod.toast.store_bought", name(id));
        dirty = true;
        save();
        return true;
    }

    /** Installs an app that was removed earlier (free). */
    public static boolean install(String id) {
        ensure();
        if (!owned.contains(id) || !removed.contains(id)) return false;
        if (!Modem.connected()) { Modem.note(); return false; }
        if (!hasRoom(id)) return false;
        removed.remove(id);
        notified.remove(id);
        installStart.put(id, System.currentTimeMillis());
        Progress.toast("cutemod.toast.app_installing", name(id));
        dirty = true;
        save();
        return true;
    }

    /** Removes a game or an app: it frees the room on the disk and disappears from the Dock and the Start menu, the purchase stays. */
    public static boolean uninstall(String id) {
        ensure();
        Program p = program(id);
        if (placeOnly(id) || !owned.contains(id) || removed.contains(id)) return false;
        removed.add(id);
        installStart.remove(id);
        notified.remove(id);
        if (p != null) DockLayout.unpin(p.icon());
        Progress.toast("cutemod.toast.app_removed", name(id));
        dirty = true;
        save();
        return true;
    }

    /** Gives a game for free (event rewards) and starts installing it. */
    public static void grant(String id) {
        ensure();
        if (owned.contains(id)) return;
        owned.add(id);
        if (!hasRoom(id)) {                                  // a reward is never lost: it waits, owned, until there is room
            removed.add(id);
            Progress.toast("cutemod.toast.no_space", name(id));
            dirty = true;
            save();
            return;
        }
        installStart.put(id, System.currentTimeMillis());
        Progress.toast("cutemod.toast.store_bought", name(id));
        dirty = true;
        save();
    }

    // ---------- reviews ----------
    /** Every game and app has 3 to 5 reviews from "other players" (the texts are cutemod.store.rev.<id>.<n> in the lang files). */
    public static int reviewCount(String id) { return 3 + Math.floorMod(id.hashCode(), 3); }
    private static final String[] NAMES = {"CreeperFan", "BeeKeeper42", "SleepyPanda", "IceCube", "FoxyLady", "EnderBoy",
            "PixelCat", "MossyStone", "NightOwl", "Cookie_Monster", "DiamondDigger", "Zzz_Zed"};

    public static String npcAuthor(String id, int n) { return NAMES[Math.floorMod(id.hashCode() * 31 + n * 7 + 5, NAMES.length)]; }

    public static int npcStars(String id, int n) {
        int base = Math.round(ratingOf(id) / 10f);
        int d = n == 0 ? 0 : Math.floorMod(id.hashCode() + n * 13, 3) - 1;
        return Math.max(1, Math.min(5, base + d));
    }

    /** The player's own review: 0 stars = none yet. */
    public static int reviewStars(String id) { ensure(); return reviewStars.getOrDefault(id, 0); }

    public static String reviewText(String id) { ensure(); return reviewText.getOrDefault(id, ""); }

    /** Saves the review. Returns true if it is the first review for this game. */
    public static boolean setReview(String id, int stars, String text) {
        ensure();
        boolean first = !reviewStars.containsKey(id);
        reviewStars.put(id, Math.max(1, Math.min(5, stars)));
        reviewText.put(id, text == null ? "" : text);
        dirty = true;
        save();
        return first;
    }

    // ---------- play statistics ----------
    public static int playSeconds(String id) { ensure(); return playSeconds.getOrDefault(id, 0); }

    public static int best(String id) { ensure(); return best.getOrDefault(id, 0); }

    public static void addPlaySecond(String id) {
        ensure();
        playSeconds.merge(id, 1, Integer::sum);
        dirty = true;
    }

    public static void recordScore(String id, int score) {
        ensure();
        if (score > best.getOrDefault(id, 0)) { best.put(id, score); dirty = true; }
    }

    public static String playTime(String id) {
        int s = playSeconds(id), h = s / 3600, m = (s % 3600) / 60;
        return h > 0 ? h + "h " + m + "m" : m > 0 ? m + " min" : s + " s";
    }

    // ---------- save / load ----------
    private static int gen = -1;

    private static void ensure() {
        if (loaded && gen == Store.gen()) return;
        loaded = true;
        gen = Store.gen();
        dirty = false;
        owned.clear(); notified.clear(); removed.clear(); installStart.clear(); playSeconds.clear();
        best.clear(); reviewStars.clear(); reviewText.clear();
        try {
            Properties pr = Store.readProps("library");
            if (pr != null) {
                fill(owned, pr.getProperty("own"));
                fill(notified, pr.getProperty("notified"));
                fill(removed, pr.getProperty("removed"));
                owned.removeIf(id -> !known(id)); notified.removeIf(id -> !known(id)); removed.removeIf(id -> !known(id));
                for (String k : pr.stringPropertyNames()) {
                    try {
                        if (k.startsWith("start.")) installStart.put(k.substring(6), Long.parseLong(pr.getProperty(k).trim()));
                        else if (k.startsWith("play.")) playSeconds.put(k.substring(5), Integer.parseInt(pr.getProperty(k).trim()));
                        else if (k.startsWith("best.")) best.put(k.substring(5), Integer.parseInt(pr.getProperty(k).trim()));
                        else if (k.startsWith("rs.")) reviewStars.put(k.substring(3), Integer.parseInt(pr.getProperty(k).trim()));
                        else if (k.startsWith("rt.")) reviewText.put(k.substring(3), pr.getProperty(k));
                    } catch (NumberFormatException ignored) {
                    }
                }
                // a save from before the app store: the player already had the apps, so keep them installed
                if (Store.ready() && pr.getProperty("apps") == null && !owned.isEmpty()) {
                    for (Program p : PROGRAMS) { owned.add(p.id()); notified.add(p.id()); }
                    dirty = true;
                }
            }
        } catch (Exception ignored) {
        }
    }

    private static void fill(Set<String> set, String csv) {
        if (csv == null || csv.isBlank()) return;
        for (String s : csv.split(",")) if (!s.isBlank()) set.add(s.trim());
    }

    /** Saved on the server (through {@link Store}). */
    public static void save() {
        if (!loaded || gen != Store.gen()) return;
        try {
            Properties pr = new Properties();
            pr.setProperty("own", String.join(",", owned));
            pr.setProperty("notified", String.join(",", notified));
            pr.setProperty("removed", String.join(",", removed));
            pr.setProperty("apps", "1");
            installStart.forEach((k, v) -> pr.setProperty("start." + k, Long.toString(v)));
            playSeconds.forEach((k, v) -> pr.setProperty("play." + k, Integer.toString(v)));
            best.forEach((k, v) -> pr.setProperty("best." + k, Integer.toString(v)));
            reviewStars.forEach((k, v) -> pr.setProperty("rs." + k, Integer.toString(v)));
            reviewText.forEach((k, v) -> pr.setProperty("rt." + k, v));
            Store.writeProps("library", pr);
            dirty = false;
        } catch (Exception ignored) {
        }
    }

    /** Called 60 times per second by the computer screen: finishes installs and saves now and then. */
    public static void tick() {
        ensure();
        if (++saveDelay % 30 == 0) {
            for (String id : owned) {
                if (!notified.contains(id) && installed(id)) {
                    notified.add(id);
                    Progress.toast("cutemod.toast.store_installed", name(id));
                    Program prog = program(id);
                    if (prog != null) DockLayout.pin(prog.icon());     // a new app shows up in the Dock
                    dirty = true;
                }
            }
        }
        if (dirty && saveDelay > 600) { saveDelay = 0; save(); }
    }
}
