package dev.cutemod.client.os;

import net.minecraft.client.resources.language.I18n;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * The statement of the bank: every time coins come or go, one line is written here (what, how much, when).
 * It is the only place where the player can read it. Saved as "bank_log": time|amount|label per line, newest first.
 * A label is a lang key ("cutemod.bank.src...") or a plain text.
 */
public final class BankLog {
    private BankLog() {}

    public record Op(long time, int amount, String label) {}

    private static final int MAX = 80;
    private static final long MERGE_S = 90;
    private static final List<Op> ops = new ArrayList<>();
    private static int gen = -1;

    private static boolean ensure() {
        if (!Store.ready()) return false;
        if (gen == Store.gen()) return true;
        gen = Store.gen();
        ops.clear();
        try {
            String s = Store.read("bank_log");
            if (s != null) {
                for (String line : s.split("\n")) {
                    String[] p = line.split("\\|", 3);
                    if (p.length == 3) ops.add(new Op(Long.parseLong(p[0]), Integer.parseInt(p[1]), p[2]));
                }
            }
        } catch (Exception ignored) {
        }
        return true;
    }

    public static List<Op> list() {
        ensure();
        return ops;
    }

    /** One more line. label = null: the bank finds out by itself which app is asking (a game, a shop...). */
    public static void add(int amount, String label) {
        if (amount == 0 || !ensure()) return;
        String l = label != null ? label : guess(amount);
        long now = System.currentTimeMillis() / 1000;
        if (!ops.isEmpty()) {                                       // the same thing again at once (a farm sale): one line
            Op top = ops.get(0);
            if (top.label().equals(l) && Integer.signum(top.amount()) == Integer.signum(amount) && now - top.time() <= MERGE_S) {
                ops.set(0, new Op(now, top.amount() + amount, l));
                save();
                return;
            }
        }
        ops.add(0, new Op(now, amount, l));
        while (ops.size() > MAX) ops.remove(ops.size() - 1);
        save();
    }

    private static void save() {
        StringBuilder sb = new StringBuilder();
        for (Op o : ops) sb.append(o.time()).append('|').append(o.amount()).append('|').append(o.label()).append('\n');
        Store.write("bank_log", sb.toString());
    }

    /** The text of a line. */
    public static String text(Op o) {
        return o.label().startsWith("cutemod.") ? I18n.get(o.label()) : o.label();
    }

    private static String guess(int amount) {
        Optional<String> found = StackWalker.getInstance().walk(s -> s
                .map(StackWalker.StackFrame::getClassName)
                .filter(c -> c.startsWith("dev.cutemod.client.") && !c.contains("BankLog") && !c.contains("Progress"))
                .map(BankLog::known)
                .filter(k -> k != null)
                .findFirst());
        if (found.isPresent()) return found.get();
        return amount > 0 ? "cutemod.bank.src.income" : "cutemod.bank.src.purchase";
    }

    /** The lang key for the app that a class belongs to, or null. */
    private static String known(String cls) {
        String simple = cls.substring(cls.lastIndexOf('.') + 1);
        int d = simple.indexOf('$');
        if (d > 0) simple = simple.substring(0, d);
        String key = "cutemod.bank.src." + simple;
        if (I18n.exists(key)) return key;
        if (cls.startsWith("dev.cutemod.client.game.")) return "cutemod.bank.src.game";
        if (simple.startsWith("Pet")) return "cutemod.bank.src.pet";
        return null;
    }
}
