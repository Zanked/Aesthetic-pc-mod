package dev.cutemod.client.game;

/**
 * The levels of Bird Sling: three worlds of eight (seven ordinary levels and a boss each).
 * Coordinates are game pixels, the ground is at {@link BirdSling#GY}; a block is given by its left edge and its bottom.
 * Birds: R red, B blue, Y yellow, K black, W white, H heavy.
 */
final class BirdLevels {
    static final int COUNT = 32;

    static final String[] QUEUES = {
        // the meadow
        "RRRRR", "RRYRRR", "RBYRRR", "BBYRR", "RYBBRR", "KRRYR", "RBYKRR", "RBYKRR",
        // the frost
        "WRRYR", "RWBRR", "KYRBR", "BBWYRR", "WKRRR", "YWKBRR", "WWBKR", "KWBYRR",
        // the volcano
        "HRRRR", "HBYRRR", "HKWR", "KKYBRR", "HWKR", "HYBKRR", "HKWYR", "HKKWYB",
        // the sky
        "RRBRRR", "ORYBR", "OORBRR", "MRKBR", "OMYRRR", "HKOMR", "MKWORR", "HKMOWB",
    };

    private BirdLevels() { }

    /** A constant push on the flying birds (positive is a tail wind), in pixels per tick squared. */
    static float wind(int lv) {
        return switch (lv) {
            case 8, 11 -> 0.004F;
            case 15 -> 0.003F;
            case 13 -> -0.003F;
            case 22 -> -0.003F;
            default -> 0F;
        };
    }

    static void build(BirdSling s, int lv) {
        int g = BirdSling.GY;
        final int wood = BirdSling.WOOD, ice = BirdSling.ICE, stone = BirdSling.STONE;
        switch (lv) {
            // ------------------------------------------------------------ the meadow
            case 0 -> {                                   // a little ice hut with two piggies
                s.blk(ice, 150, g, 4, 16); s.blk(ice, 174, g, 4, 16); s.blk(ice, 148, g - 16, 34, 4);
                s.pig(163, g); s.pig(165, g - 20);
            }
            case 1 -> {                                   // an ice table and a wooden table
                s.blk(ice, 130, g, 4, 20); s.blk(ice, 146, g, 4, 20); s.blk(ice, 128, g - 20, 26, 4);
                s.pig(139, g); s.pig(141, g - 24);
                s.blk(wood, 172, g, 4, 20); s.blk(wood, 192, g, 4, 20); s.blk(wood, 170, g - 20, 30, 4);
                s.pig(185, g);
            }
            case 2 -> {                                   // a stone wall, the piggies hide behind it
                s.blk(wood, 124, g, 6, 24);
                s.blk(wood, 152, g, 4, 18); s.blk(wood, 174, g, 4, 18); s.blk(wood, 150, g - 18, 30, 4);
                s.pig(165, g); s.pig(165, g - 22); s.pig(194, g);
            }
            case 3 -> {                                   // a tall tower on wooden legs, a piggy behind a stone block
                s.blk(wood, 150, g, 4, 24); s.blk(wood, 170, g, 4, 24); s.blk(wood, 146, g - 24, 32, 4);
                s.blk(wood, 152, g - 28, 4, 16); s.blk(wood, 168, g - 28, 4, 16); s.blk(wood, 148, g - 44, 28, 4);
                s.pig(162, g); s.pig(162, g - 28); s.pig(162, g - 48);
                s.blk(stone, 190, g, 8, 14); s.pig(204, g);
            }
            case 4 -> {                                   // a stone base with a wooden roof
                s.blk(wood, 138, g, 12, 12); s.blk(wood, 176, g, 12, 12); s.blk(wood, 136, g - 12, 54, 4);
                s.blk(wood, 144, g - 16, 4, 16); s.blk(wood, 178, g - 16, 4, 16); s.blk(wood, 140, g - 32, 46, 4);
                s.pig(163, g); s.pig(163, g - 16); s.pig(163, g - 36);
            }
            case 5 -> {                                   // a heavy stone gate
                s.blk(wood, 140, g, 6, 22); s.blk(wood, 170, g, 6, 22); s.blk(wood, 136, g - 22, 44, 4);
                s.pig(158, g); s.pig(158, g - 26);
                s.blk(wood, 196, g, 4, 14); s.pig(208, g);
            }
            case 6 -> {                                   // a pyramid of boxes
                s.blk(wood, 136, g, 10, 10); s.blk(wood, 146, g, 10, 10); s.blk(wood, 170, g, 10, 10); s.blk(wood, 180, g, 10, 10);
                s.blk(ice, 140, g - 10, 46, 4); s.blk(wood, 150, g - 14, 10, 10); s.blk(wood, 166, g - 14, 10, 10);
                s.blk(wood, 146, g - 24, 34, 4);
                s.pig(163, g); s.pig(163, g - 14); s.pig(163, g - 28);
                s.blk(wood, 202, g, 8, 18); s.pig(195, g);
            }
            case 7 -> {                                   // BOSS: the King Pig in his stone fort, with a crate of TNT at the door
                s.blk(wood, 150, g, 6, 28); s.blk(stone, 182, g, 6, 28); s.blk(wood, 146, g - 28, 46, 4);
                s.boss(0, 169, g); s.pig(169, g - 32);
                s.blk(wood, 112, g, 4, 16); s.blk(wood, 130, g, 4, 16); s.blk(wood, 110, g - 16, 28, 4);
                s.pig(121, g);
                s.tnt(140, g);
            }
            // ------------------------------------------------------------ the frost
            case 8 -> {                                   // stone roofs: an egg from above gets under them
                s.blk(wood, 140, g, 4, 18); s.blk(wood, 166, g, 4, 18); s.blk(stone, 136, g - 18, 38, 5);
                s.pig(153, g);
                s.blk(ice, 184, g, 4, 22); s.blk(ice, 206, g, 4, 22); s.blk(ice, 180, g - 22, 34, 4);
                s.pig(195, g); s.pig(197, g - 26);
            }
            case 9 -> {                                   // a tower full of TNT
                s.blk(wood, 146, g, 4, 24); s.blk(wood, 178, g, 4, 24); s.tnt(158, g); s.tnt(166, g);
                s.blk(wood, 142, g - 24, 44, 4);
                s.pig(160, g - 28); s.pig(172, g - 28);
                s.blk(ice, 194, g, 4, 20); s.pig(206, g);
            }
            case 10 -> {                                  // a stone bunker, two piggies in helmets
                s.blk(stone, 126, g, 6, 22);
                s.blk(wood, 150, g, 4, 16); s.blk(wood, 190, g, 4, 16); s.blk(wood, 146, g - 16, 48, 4);
                s.helm(160, g); s.helm(180, g); s.pig(170, g - 20); s.tnt(148, g - 20);
            }
            case 11 -> {                                  // two tall towers, one of ice and one of stone
                s.blk(ice, 135, g, 4, 18); s.blk(ice, 155, g, 4, 18); s.blk(ice, 131, g - 18, 28, 4);
                s.pig(145, g);
                s.blk(wood, 137, g - 22, 4, 14); s.blk(wood, 153, g - 22, 4, 14); s.blk(wood, 133, g - 36, 24, 4);
                s.pig(145, g - 40);
                s.blk(stone, 184, g, 4, 18); s.blk(stone, 204, g, 4, 18); s.blk(wood, 180, g - 18, 28, 4);
                s.helm(194, g); s.pig(194, g - 22);
            }
            case 12 -> {                                  // a bridge on two stone pillars, TNT underneath
                s.blk(stone, 126, g, 8, 30); s.blk(stone, 186, g, 8, 30); s.blk(wood, 126, g - 30, 68, 4);
                s.pig(150, g - 34); s.pig(170, g - 34);
                s.pig(144, g); s.tnt(156, g); s.tnt(164, g); s.pig(178, g);
            }
            case 13 -> {                                  // a snow fort and a hut
                s.blk(stone, 120, g, 6, 20);
                s.blk(ice, 140, g, 4, 26); s.blk(ice, 170, g, 4, 26); s.blk(stone, 136, g - 26, 42, 5);
                s.tnt(146, g); s.helm(162, g); s.pig(157, g - 31);
                s.blk(wood, 192, g, 4, 16); s.blk(wood, 206, g, 4, 16); s.blk(wood, 190, g - 16, 22, 4);
                s.helm(199, g); s.pig(199, g - 20);
            }
            case 14 -> {                                  // two tall towers
                s.blk(wood, 140, g, 4, 26); s.blk(wood, 160, g, 4, 26); s.blk(wood, 136, g - 26, 32, 4);
                s.pig(150, g);
                s.blk(ice, 142, g - 30, 4, 20); s.blk(ice, 158, g - 30, 4, 20); s.blk(ice, 138, g - 50, 28, 4);
                s.pig(152, g - 30); s.pig(152, g - 54);
                s.blk(stone, 184, g, 6, 34); s.blk(stone, 204, g, 6, 34); s.blk(wood, 182, g - 34, 32, 4);
                s.pig(197, g); s.helm(197, g - 38);
            }
            case 15 -> {                                  // BOSS: the Ice Queen in a frozen fort
                s.blk(ice, 150, g, 6, 30); s.blk(ice, 184, g, 6, 30); s.blk(stone, 146, g - 30, 48, 5);
                s.boss(1, 170, g); s.pig(158, g - 35); s.tnt(168, g - 35);
                s.helm(130, g); s.helm(206, g);
            }
            // ------------------------------------------------------------ the volcano
            case 16 -> {                                  // a tall stone wall, a hut behind it
                s.blk(stone, 128, g, 10, 26);
                s.blk(wood, 160, g, 4, 20); s.blk(wood, 184, g, 4, 20); s.blk(wood, 158, g - 20, 34, 4);
                s.pig(172, g); s.pig(172, g - 24); s.pig(204, g);
            }
            case 17 -> {                                  // stone and ice, with a hut at the back
                s.blk(stone, 150, g, 8, 22); s.blk(stone, 176, g, 8, 22); s.blk(ice, 146, g - 22, 42, 4);
                s.helm(167, g); s.pig(167, g - 26);
                s.blk(wood, 194, g, 4, 16); s.blk(wood, 210, g, 4, 16); s.blk(wood, 192, g - 16, 26, 4);
                s.pig(204, g);
            }
            case 18 -> {                                  // a stone bunker with TNT inside
                s.blk(stone, 140, g, 8, 30); s.blk(stone, 176, g, 8, 30); s.blk(stone, 136, g - 30, 52, 6);
                s.helm(155, g); s.tnt(161, g); s.helm(170, g); s.pig(160, g - 37);
            }
            case 19 -> {                                  // the castle: three groups of piggies far from each other
                s.blk(stone, 114, g, 6, 26); s.blk(stone, 134, g, 6, 26); s.blk(wood, 112, g - 26, 30, 4);
                s.pig(127, g); s.pig(127, g - 30);
                s.blk(wood, 156, g, 4, 14); s.blk(wood, 170, g, 4, 14); s.blk(ice, 154, g - 14, 22, 4);
                s.pig(163, g); s.pig(163, g - 18);
                s.blk(stone, 192, g, 6, 26); s.blk(stone, 210, g, 6, 26); s.blk(wood, 190, g - 26, 28, 4);
                s.pig(204, g); s.pig(204, g - 30);
            }
            case 20 -> {                                  // a pile of TNT
                s.blk(stone, 130, g, 6, 24);
                s.tnt(150, g); s.tnt(158, g); s.tnt(154, g - 8); s.pig(154, g - 16);
                s.blk(ice, 180, g, 4, 24); s.blk(ice, 198, g, 4, 24); s.blk(stone, 176, g - 24, 30, 5);
                s.helm(190, g); s.pig(190, g - 29);
            }
            case 21 -> {                                  // a wooden tower and an ice tower
                s.blk(wood, 130, g, 4, 20); s.blk(wood, 150, g, 4, 20); s.blk(wood, 126, g - 20, 32, 4);
                s.helm(140, g);
                s.blk(stone, 132, g - 24, 4, 16); s.blk(stone, 148, g - 24, 4, 16); s.blk(wood, 128, g - 40, 28, 4);
                s.pig(142, g - 28); s.pig(142, g - 44);
                s.blk(ice, 180, g, 4, 26); s.blk(ice, 204, g, 4, 26); s.blk(stone, 176, g - 26, 36, 5);
                s.helm(192, g); s.tnt(182, g - 31); s.pig(202, g - 31);
            }
            case 22 -> {                                  // a wall, a pyramid and a hut
                s.blk(stone, 120, g, 8, 28);
                s.blk(ice, 146, g, 10, 10); s.blk(ice, 156, g, 10, 10); s.blk(ice, 166, g, 10, 10);
                s.blk(wood, 151, g - 10, 10, 10); s.blk(wood, 161, g - 10, 10, 10); s.blk(stone, 146, g - 20, 30, 4);
                s.helm(161, g - 24); s.pig(140, g);
                s.blk(wood, 190, g, 4, 18); s.blk(wood, 206, g, 4, 18); s.blk(stone, 186, g - 18, 28, 5);
                s.helm(198, g); s.pig(198, g - 23); s.tnt(190, g - 23);
            }
            case 23 -> {                                  // BOSS: the Overlord in his stone citadel
                s.blk(ice, 120, g, 4, 30);
                s.blk(wood, 150, g, 8, 34); s.blk(stone, 184, g, 8, 34); s.blk(stone, 146, g - 34, 50, 6);
                s.boss(2, 171, g); s.pig(160, g - 40); s.helm(182, g - 40);
                s.helm(130, g); s.tnt(136, g);
            }
            // ------------------------------------------------------------ the sky
            case 24 -> {                                  // a trampoline in front of a stone wall
                s.pad(100, g, 22);
                s.blk(stone, 126, g, 8, 26);
                s.blk(wood, 156, g, 4, 20); s.blk(wood, 180, g, 4, 20); s.blk(wood, 154, g - 20, 34, 4);
                s.pig(168, g); s.pig(168, g - 24); s.pig(204, g);
            }
            case 25 -> {                                  // piggies on a steel platform in the air
                s.plat(150, g - 44, 44, 4);
                s.pig(162, g - 48); s.helm(182, g - 48);
                s.blk(wood, 160, g, 4, 24); s.blk(wood, 180, g, 4, 24); s.blk(wood, 156, g - 24, 32, 4);
                s.pig(170, g);
            }
            case 26 -> {                                  // a wall in front, the piggies behind it
                s.blk(wood, 150, g, 8, 26);
                s.blk(wood, 170, g, 4, 16); s.blk(wood, 198, g, 4, 16); s.blk(wood, 168, g - 16, 36, 4);
                s.pig(180, g); s.pig(192, g); s.helm(210, g);
            }
            case 27 -> {                                  // TNT under a steel platform
                s.plat(176, g - 40, 40, 4);
                s.pig(186, g - 44); s.pig(204, g - 44);
                s.tnt(190, g); s.tnt(198, g); s.tnt(194, g - 8);
                s.blk(wood, 140, g, 4, 18); s.blk(wood, 160, g, 4, 18); s.blk(wood, 138, g - 18, 26, 4);
                s.pig(150, g);
            }
            case 28 -> {                                  // trampolines and platforms
                s.pad(110, g, 20);
                s.plat(140, g - 30, 30, 4);
                s.pig(152, g - 34); s.pig(150, g);
                s.blk(wood, 176, g, 6, 24); s.blk(wood, 198, g, 6, 24); s.blk(wood, 172, g - 24, 38, 4);
                s.pig(188, g); s.helm(188, g - 28);
            }
            case 29 -> {                                  // a steel wall and two stone towers
                s.pad(98, g, 18);
                s.blk(stone, 124, g, 6, 28);
                s.blk(stone, 150, g, 6, 28); s.blk(stone, 172, g, 6, 28); s.blk(wood, 148, g - 28, 32, 4);
                s.pig(163, g); s.helm(163, g - 32);
                s.blk(stone, 196, g, 6, 28); s.blk(stone, 212, g, 4, 28); s.blk(wood, 194, g - 28, 26, 4);
                s.pig(205, g); s.pig(205, g - 32);
            }
            case 30 -> {                                  // a steel cage with TNT on the roof
                s.plat(150, g, 4, 30); s.plat(190, g, 4, 30); s.blk(wood, 146, g - 30, 52, 4);
                s.helm(165, g); s.helm(178, g);
                s.pig(160, g - 34); s.tnt(176, g - 34);
                s.plat(204, g - 24, 12, 4); s.pig(210, g - 28);
                s.blk(wood, 110, g, 4, 18); s.blk(wood, 128, g, 4, 18); s.blk(wood, 108, g - 18, 28, 4); s.pig(119, g);
            }
            default -> {                                  // BOSS: the Mega Pig in his fort, a trampoline at the front
                s.pad(96, g, 18);
                s.plat(120, g - 26, 28, 4); s.helm(134, g - 30);
                s.blk(wood, 160, g, 6, 40); s.blk(stone, 192, g, 6, 40); s.blk(stone, 156, g - 40, 46, 5);
                s.boss(3, 177, g); s.pig(170, g - 45); s.tnt(184, g - 45);
                s.blk(wood, 206, g, 4, 22); s.pig(212, g);
            }
        }
    }
}
