package dev.cutemod.client.os;

/** What the bank card item asks of the client (kept apart so the server never loads client classes). */
public final class BankHooks {
    private BankHooks() {}

    /** The coins of the player, written like 12 450. */
    public static String balance() {
        int n = Progress.coins();
        String s = Integer.toString(Math.abs(n));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && (s.length() - i) % 3 == 0) sb.append(' ');
            sb.append(s.charAt(i));
        }
        return (n < 0 ? "-" : "") + sb;
    }
}
