package dev.cutemod.client.os;

import dev.cutemod.data.PcHardware;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.HexFormat;

/**
 * What happens before the desktop is usable: the boot (loading) screen, the password screen
 * (only if a password is set in Settings) and the welcome splash. The same overlay also draws the
 * screensaver that starts when nothing is touched for a while, and the lock screen.
 * It covers the whole screen area of the computer and eats every click and key while it is active.
 */
public final class Startup {
    private enum Stage { BOOT, LOCK, WELCOME, DONE, SAVER, UPDATE, BSOD, RECOVERY, WHATSNEW }

    /** The boot time of the computer in ticks: it follows the memory and the drive (see PcHardware#bootTicks). Worked out when a boot starts. */
    private int bootTicks = 150;
    /** The boot can be skipped only after this share of it (so a fast PC really is faster than a slow one): 40 %. */
    private static final int SKIP_MIN = 15;
    private static final int WELCOME_TICKS = 90;
    private static final int MAX_PASSWORD = 24;
    private static final int KEY_ESC = 256, KEY_ENTER = 257, KEY_BACKSPACE = 259, KEY_KP_ENTER = 335, KEY_F8 = 297, KEY_DOWN = 264, KEY_UP = 265;

    private Stage stage = Stage.BOOT;
    private int t;
    private int shake;
    private boolean wrong;
    private final StringBuilder input = new StringBuilder();
    // screensaver heart
    private float hx = 40, hy = 30, vx = 0.6f, vy = 0.45f;
    // notes waiting to be played: {tick when due, semitone, instrument}
    private final java.util.List<int[]> notes = new java.util.ArrayList<>();
    private int clock;
    // the nostalgia pack: blue screen, recovery menu, installing an update, "what's new"
    private int crashCode, sel, updateIdx = -1;
    private boolean newsPending;
    private Runnable onReboot = () -> {};
    private int bodyColor;

    /** Called when the computer restarts (after a crash or an update): the running apps are shut down. */
    public void setRebootHook(Runnable r) { onReboot = r; }

    public Startup() {
        measureBoot();
        Sfx.powerOn();
        Sfx.startFan();
    }

    /** Looks at the memory and the drive of this PC and sets how long the boot lasts. */
    private void measureBoot() {
        PcSpecs.Spec sp = PcSpecs.get();
        bootTicks = PcHardware.bootTicks(sp.ramIdx(), sp.diskIdx());
    }

    /** The tick from which a click or a key may skip the boot screen. */
    private int skipAt() { return Math.max(SKIP_MIN, bootTicks * 2 / 5); }

    private void jingle(int[][] j) {
        for (int[] n : j) notes.add(new int[]{clock + n[0], n[1], n[2]});
    }

    // ================= password storage (this PC only, cutemod_password.txt) =================
    private static int pwGen = -1;
    private static String pwSalt = "", pwHash = "";

    private static void pwLoad() {
        if (pwGen == Store.gen()) return;
        pwGen = Store.gen();
        pwSalt = "";
        pwHash = "";
        String s = Store.read("password");
        if (s != null) {
            String[] parts = s.trim().split(":");
            if (parts.length == 2) {
                pwSalt = parts[0];
                pwHash = parts[1];
            }
        }
    }

    private static String hash(String salt, String pw) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest((salt + pw).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(d);
        } catch (Exception e) {
            return "";
        }
    }

    public static boolean hasPassword() {
        pwLoad();
        return !pwHash.isEmpty();
    }

    public static boolean checkPassword(String pw) {
        pwLoad();
        return !pwHash.isEmpty() && pwHash.equals(hash(pwSalt, pw));
    }

    /** Set a new password; null or empty removes it. It is saved on the server (only a salted hash). */
    public static void setPassword(String pw) {
        pwLoad();
        if (pw == null || pw.isEmpty()) {
            pwSalt = "";
            pwHash = "";
            Store.write("password", "");
            return;
        }
        byte[] s = new byte[8];
        new SecureRandom().nextBytes(s);
        pwSalt = HexFormat.of().formatHex(s);
        pwHash = hash(pwSalt, pw);
        Store.write("password", pwSalt + ":" + pwHash);
    }

    // ================= state =================
    public boolean active() { return stage != Stage.DONE; }

    /** The screensaver may only start while the desktop is in use. */
    public boolean canSave() { return stage == Stage.DONE; }

    public void saver() {
        if (stage != Stage.DONE) return;
        stage = Stage.SAVER;
        t = 0;
    }

    /** "Lock screen" from the logo menu: the password screen, or the screensaver if there is no password. */
    public void lock() {
        if (stage != Stage.DONE) return;
        jingle(Sfx.lock());
        if (hasPassword()) toLock();
        else saver();
    }

    /** A blue screen of death. Only on the bare desktop, and everything was saved before. */
    public void crash() { crash((int) (Math.random() * Crash.CODES.length)); }

    /** The same blue screen with a chosen stop code (an index of {@link Crash#CODES}): the full memory shows CREEPER_IN_THE_RAM. */
    public void crash(int code) {
        if (stage != Stage.DONE) return;
        stage = Stage.BSOD;
        t = 0;
        crashCode = Math.floorMod(code, Crash.CODES.length);
        Sfx.error();
    }

    /** Install update number idx: the update screen, a restart, then the "what's new" window. */
    public void install(int idx) {
        if (stage != Stage.DONE || idx < 0 || idx >= Updates.ALL.size()) return;
        stage = Stage.UPDATE;
        t = 0;
        updateIdx = idx;
    }

    private void reboot() {
        onReboot.run();
        stage = Stage.BOOT;
        t = 0;
        measureBoot();
        Sfx.powerOn();
    }

    private void toRecovery() {
        stage = Stage.RECOVERY;
        t = 0;
        sel = 0;
    }

    private void chooseRecovery() {
        Retro.setSafe(sel == 1);
        reboot();
    }

    private void finishUpdate() {
        Retro.setVersion(updateIdx + 1);
        newsPending = true;
        updateIdx = -1;
        reboot();
    }

    private void afterWelcome() {
        if (newsPending) {
            newsPending = false;
            stage = Stage.WHATSNEW;
            t = 0;
            jingle(Sfx.login());
        } else {
            stage = Stage.DONE;
        }
    }

    private void toLock() {
        stage = Stage.LOCK;
        t = 0;
        input.setLength(0);
        wrong = false;
        shake = 0;
    }

    private void afterBoot() {
        jingle(Sfx.startup());
        if (hasPassword()) toLock();
        else {
            stage = Stage.WELCOME;
            t = 0;
        }
    }

    private void wake() {
        Sfx.click();
        if (hasPassword()) toLock();
        else stage = Stage.DONE;
    }

    public void tick() {
        t++;
        clock++;
        notes.removeIf(n -> {
            if (clock < n[0]) return false;
            Sfx.note(n);
            return true;
        });
        if (shake > 0) shake--;
        if (stage == Stage.BOOT && t <= 2) measureBoot();      // the saved parts of the player may arrive just after the screen opens
        switch (stage) {
            case BOOT -> { if (t >= bootTicks) afterBoot(); }
            case WELCOME -> { if (t >= WELCOME_TICKS) afterWelcome(); }
            case RECOVERY -> { if (t >= Crash.RECOVERY_TICKS) chooseRecovery(); }
            case UPDATE -> { if (t >= Crash.UPDATE_TICKS) finishUpdate(); }
            default -> {}
        }
    }

    // ================= input =================
    public boolean click() {
        switch (stage) {
            case BOOT -> { if (t >= skipAt()) t = bootTicks; }
            case SAVER -> wake();
            case WELCOME -> afterWelcome();
            case BSOD -> { if (t >= Crash.BSOD_TICKS) toRecovery(); }
            case WHATSNEW -> stage = Stage.DONE;
            default -> {}
        }
        return active();
    }

    public boolean key(int keyCode) {
        if (!active()) return false;
        if (keyCode == KEY_ESC && stage != Stage.SAVER) return false;      // Esc still leaves the computer
        switch (stage) {
            case BOOT -> {
                if (keyCode == KEY_F8 && t > 5) toRecovery();            // F8 while it starts: the recovery menu
                else if (t >= skipAt()) t = bootTicks;
            }
            case SAVER -> wake();
            case WELCOME -> afterWelcome();
            case WHATSNEW -> stage = Stage.DONE;
            case BSOD -> { if (t >= Crash.BSOD_TICKS) toRecovery(); }
            case RECOVERY -> {
                if (keyCode == KEY_UP || keyCode == KEY_DOWN) { sel = 1 - sel; Sfx.click(); }
                else if (keyCode == KEY_ENTER || keyCode == KEY_KP_ENTER) chooseRecovery();
            }
            case LOCK -> {
                if (keyCode == KEY_ENTER || keyCode == KEY_KP_ENTER) submit();
                else if (keyCode == KEY_BACKSPACE && input.length() > 0) {
                    input.setLength(input.length() - 1);
                    wrong = false;
                }
            }
            default -> {}
        }
        return true;
    }

    public boolean charTyped(char c) {
        if (!active()) return false;
        if (stage == Stage.LOCK && c >= 32 && c != 127 && input.length() < MAX_PASSWORD) {
            input.append(c);
            Sfx.key();
            wrong = false;
        }
        return true;
    }

    private void submit() {
        if (checkPassword(input.toString())) {
            input.setLength(0);
            stage = Stage.WELCOME;
            t = 0;
            jingle(Sfx.login());
        } else {
            Sfx.error();
            wrong = true;
            shake = 18;
            input.setLength(0);
        }
    }

    // ================= drawing =================
    private static void heart(GuiGraphics g, int x, int y, int s, int argb) {
        g.fill(x + s, y, x + 3 * s, y + s, argb);
        g.fill(x + 4 * s, y, x + 6 * s, y + s, argb);
        g.fill(x, y + s, x + 7 * s, y + 3 * s, argb);
        g.fill(x + s, y + 3 * s, x + 6 * s, y + 4 * s, argb);
        g.fill(x + 2 * s, y + 4 * s, x + 5 * s, y + 5 * s, argb);
        g.fill(x + 3 * s, y + 5 * s, x + 4 * s, y + 6 * s, argb);
    }

    private static void centered(GuiGraphics g, Font f, String s, int cx, int y, int argb) {
        CuteFont.draw(g, f, s, cx - f.width(s) / 2, y, argb, false);
    }

    private static int alpha(int rgb, float a) {
        return ((int) (Math.max(0, Math.min(1, a)) * 255) << 24) | (rgb & 0xFFFFFF);
    }

    private static String playerName() {
        try {
            return Minecraft.getInstance().getUser().getName();
        } catch (Exception e) {
            return "Player";
        }
    }

    /** Draw over the screen area (x, y, w, h); body is the computer's color. */
    public void render(GuiGraphics g, int x, int y, int w, int h, int body, float partial) {
        Font f = Minecraft.getInstance().font;
        int cx = x + w / 2, cy = y + h / 2;
        switch (stage) {
            case BOOT -> renderBoot(g, f, x, y, w, h, cx, cy, body, partial);
            case LOCK -> renderLock(g, f, x, y, w, h, cx, cy, body);
            case WELCOME -> renderWelcome(g, f, x, y, w, h, cx, cy, body);
            case SAVER -> renderSaver(g, f, x, y, w, h, cx, body);
            case BSOD -> Crash.bsod(g, f, x, y, w, h, t, crashCode);
            case RECOVERY -> Crash.recovery(g, f, x, y, w, h, t, sel);
            case UPDATE -> Crash.updating(g, f, x, y, w, h, t);
            case WHATSNEW -> Crash.news(g, f, x, y, w, h, t, body, Retro.version() - 1);
            default -> {}
        }
    }

    private void renderBoot(GuiGraphics g, Font f, int x, int y, int w, int h, int cx, int cy, int body, float partial) {
        g.fillGradient(x, y, x + w, y + h, 0xFF120C1A, 0xFF241838);
        float tt = t + partial;
        // logo: a heart that gently beats
        int s = (Math.sin(tt / 7.0) > 0.6) ? 6 : 5;
        int hw = 7 * s;
        heart(g, cx - hw / 2, cy - 48, s, 0xFFFFB3D9);
        g.fill(cx - hw / 2, cy - 48, cx - hw / 2 + 2 * s, cy - 48 + s, 0x66FFFFFF);
        g.drawCenteredString(f, Component.translatable("cutemod.os.title"), cx, cy - 8, 0xFFFFFFFF);

        // progress bar: it speeds up and stalls a little, like a real boot
        float p = Math.min(1f, tt / bootTicks);
        p = p * p * (3 - 2 * p);
        int bw = 120, bx = cx - bw / 2, by = cy + 8;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 7, 0xFF5A4A72);
        g.fill(bx, by, bx + bw, by + 6, 0xFF1B1422);
        int fill = (int) (bw * p);
        g.fill(bx, by, bx + fill, by + 6, accent(body));
        g.fill(bx, by, bx + fill, by + 2, 0x55FFFFFF);

        String[] msgs = {"cutemod.os.boot.m0", "cutemod.os.boot.m1", "cutemod.os.boot.m2"};
        int mi = Math.min(msgs.length - 1, (int) (p * msgs.length));
        centered(g, f, Component.translatable(msgs[mi]).getString(), cx, by + 14, 0xFFBFB2D6);
        if (t >= skipAt()) centered(g, f, Component.translatable("cutemod.os.boot.skip").getString(), cx, y + h - 12, 0x77BFB2D6);
        CuteFont.draw(g, f, Component.translatable("cutemod.os.boot.f8"), x + 4, y + h - 12, 0x55BFB2D6, false);
        PcSpecs.Spec sp = PcSpecs.get();                                         // like the first lines of a real BIOS
        String[] kind = {"HDD", "SSD", "NVMe"};
        String bios = "RAM " + PcSpecs.gb(sp.ramGb()) + "  C: " + PcSpecs.gb(sp.diskC()) + " " + kind[PcHardware.diskKind(sp.diskIdx())];
        CuteFont.draw(g, f, Component.literal(bios), x + 4, y + 4, 0x66BFB2D6, false);
    }

    /** Pastel pink-ish accent that follows the computer color a little. */
    private static int accent(int body) {
        return App.mix(body, 0xFFB3D9, 0.55f);
    }

    private void renderLock(GuiGraphics g, Font f, int x, int y, int w, int h, int cx, int cy, int body) {
        Wallpaper.drawCached(g, x, y, w, h, body, Wallpaper.shown());
        g.fill(x, y, x + w, y + h, 0xB0140E1C);

        // avatar
        int ay = cy - 36;
        disc(g, cx, ay, 22, 0xFFFFFFFF);
        disc(g, cx, ay, 20, App.mix(body, 0xFFFFFF, 0.2f));
        heart(g, cx - 10, ay - 8, 3, 0xFFFFFFFF);
        centered(g, f, playerName(), cx, ay + 28, 0xFFFFFFFF);

        // password field (shakes when wrong)
        int off = shake > 0 ? (int) Math.round(Math.sin(shake * 1.3) * 4) : 0;
        int fw = 128, fx = cx - fw / 2 + off, fy = ay + 42;
        g.fill(fx - 1, fy - 1, fx + fw + 1, fy + 15, wrong ? 0xFFFF6B6B : 0xFFB9B0C8);
        g.fill(fx, fy, fx + fw, fy + 14, 0xFFF4EFF8);
        if (input.length() == 0) {
            CuteFont.draw(g, f, Component.translatable("cutemod.os.lock.prompt"), fx + 5, fy + 3, 0xFF9A90A8, false);
        } else {
            String dots = "•".repeat(input.length());
            while (f.width(dots) > fw - 12) dots = dots.substring(1);
            CuteFont.draw(g, f, dots, fx + 5, fy + 3, 0xFF3A2A3A, false);
        }
        if ((t / 25) % 2 == 0) {                                       // blinking cursor
            String dots = "•".repeat(Math.min(input.length(), 40));
            int cxp = fx + 5 + Math.min(f.width(dots), fw - 12) + 1;
            g.fill(cxp, fy + 2, cxp + 1, fy + 12, 0xFF3A2A3A);
        }
        if (wrong) centered(g, f, Component.translatable("cutemod.os.lock.wrong").getString(), cx, fy + 20, 0xFFFF8F8F);
        else centered(g, f, Component.translatable("cutemod.os.lock.enter").getString(), cx, fy + 20, 0x99FFFFFF);
    }

    private static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    private void renderWelcome(GuiGraphics g, Font f, int x, int y, int w, int h, int cx, int cy, int body) {
        Wallpaper.drawCached(g, x, y, w, h, body, Wallpaper.shown());
        // the whole splash fades in, stays and fades out, revealing the desktop
        float a = t < 20 ? t / 20f : (t > WELCOME_TICKS - 25 ? (WELCOME_TICKS - t) / 25f : 1f);
        g.fill(x, y, x + w, y + h, alpha(0x140E1C, 0.45f + 0.5f * a));
        int s = 4;
        heart(g, cx - 14, cy - 30, s, alpha(0xFFB3D9, a));
        String msg = Component.translatable("cutemod.os.welcome", playerName()).getString();
        CuteFont.draw(g, f, msg, cx - f.width(msg) / 2, cy + 2, alpha(0xFFFFFF, a), false);
    }

    private void renderSaver(GuiGraphics g, Font f, int x, int y, int w, int h, int cx, int body) {
        Savers.render(g, Retro.saver(), x, y, w, h, t, body);
        centered(g, f, Component.translatable("cutemod.os.saver.hint").getString(), cx, y + h - 12, 0x66FFFFFF);
    }
}
