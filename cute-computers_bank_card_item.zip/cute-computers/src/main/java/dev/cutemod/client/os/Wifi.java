package dev.cutemod.client.os;

import dev.cutemod.block.RouterBlockEntity;
import dev.cutemod.data.WifiNet;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * The Wi-Fi of the computer, like in Windows: the routers within reach are the "networks near you", the player picks one and
 * the computer remembers it (saved with the rest of the player's data). When the player walks out of its range the connection
 * is lost, and it comes back by itself when the player returns. The internet the apps use is whatever the connected network gives
 * (see {@link Modem}); a computer that has an old modem part inside keeps it as a cable connection.
 */
public final class Wifi {
    private Wifi() {}

    private static final String KEY = "wifi";

    /** One network in range: its router, name, level and how strong the signal is (1..4 bars). */
    public record Net(String key, BlockPos pos, String name, int level, double dist, int bars) {
        public int mbps() { return WifiNet.mbps(level); }
    }

    // ---------- what is around ----------
    /** The networks within range of the player, the strongest first. */
    public static List<Net> scan() {
        Minecraft mc = Minecraft.getInstance();
        List<Net> out = new ArrayList<>();
        if (mc.player == null || mc.level == null) return out;
        Vec3 me = mc.player.position();
        for (RouterBlockEntity be : RouterBlockEntity.CLIENT_ROUTERS) {
            if (be.isRemoved() || be.getLevel() != mc.level) continue;
            int lv = be.routerLevel();
            double d = me.distanceTo(be.getBlockPos().getCenter());
            int bars = WifiNet.bars(d, lv);
            if (bars <= 0) continue;
            out.add(new Net(keyOf(be), be.getBlockPos(), be.networkName(), lv, d, bars));
        }
        out.sort(Comparator.comparingInt(Net::bars).reversed().thenComparingDouble(Net::dist));
        return out;
    }

    private static String keyOf(RouterBlockEntity be) {
        BlockPos p = be.getBlockPos();
        return be.getLevel().dimension().location() + "|" + p.getX() + "," + p.getY() + "," + p.getZ();
    }

    // ---------- the connection ----------
    /** What the computer is set to connect to ("" = nothing): the key of a router. */
    public static String chosen() {
        String s = Store.read(KEY);
        return s == null ? "" : s;
    }

    /** True if the player picked "cable" (the old modem part) on purpose, or has never picked a network. */
    public static boolean wired() { return chosen().isEmpty(); }

    /** The network the computer is connected to right now (null: none picked, or the router is out of reach). */
    public static Net current() {
        String key = chosen();
        if (key.isEmpty()) return null;
        for (Net n : scan()) if (n.key().equals(key)) return n;
        return null;
    }

    /** The player picked a network (it is remembered). */
    public static void connect(Net n) {
        Store.write(KEY, n.key());
    }

    /** Wi-Fi off: only the cable (the old modem part inside the computer) is used. */
    public static void disconnect() {
        Store.write(KEY, "");
    }

    /** Is a network picked at all (even if it is out of reach right now)? Used for the "out of range" hint. */
    public static boolean picked() { return !chosen().isEmpty(); }
}
