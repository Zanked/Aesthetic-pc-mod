package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The look of a weak video card (see {@link GfxQuality#low}): the whole monitor gets a pixel filter, a fine grid of dark lines
 * that cuts the picture into chunky 2 x 2 cells, like a tiny low-resolution screen, with a faint dull tint over it.
 * The grid is baked once into one texture ({@link TexCache}), so it costs a single quad a frame. The first video card
 * (50 coins) already switches it off.
 */
public final class PixelFilter {
    private PixelFilter() {}

    private static final int CELL = 2;
    private static final int LINE = 0x30000000, TINT = 0x12606878;

    /** Draws the filter over the box (x, y, w, h). */
    public static void draw(GuiGraphics g, int x, int y, int w, int h) {
        TexCache.Tex t = TexCache.get("pixelfilter", w, h);
        if (t.tag != 1) {
            t.tag = 1;
            TexCache.render(t, 0, 0, c -> bake(c, w, h));
        }
        TexCache.blit(g, t, x, y);
    }

    private static void bake(GuiGraphics c, int w, int h) {
        c.fill(0, 0, w, h, TINT);
        for (int yy = CELL - 1; yy < h; yy += CELL) c.fill(0, yy, w, yy + 1, LINE);
        for (int xx = CELL - 1; xx < w; xx += CELL) c.fill(xx, 0, xx + 1, h, LINE);
    }
}
