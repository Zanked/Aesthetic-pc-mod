package dev.cutemod.client.os;

import dev.cutemod.net.SaveDataPayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * The client's copy of what the SERVER has saved for this player. Reading is local; every write is
 * also sent to the server, which keeps it in the world save. {@link #gen()} changes whenever the
 * copy is replaced (joining another server or world), so the apps know to load again.
 */
public final class Store {
    private Store() {}

    private static final Map<String, String> data = new HashMap<>();
    private static boolean ready;
    private static int gen;

    public static void apply(Map<String, String> m) {
        data.clear();
        data.putAll(m);
        ready = true;
        gen++;
    }

    /** Sets one blob on this side only (the server already has it and told us): nothing is sent back, and the apps do not reload. */
    public static void setLocal(String name, String text) {
        if (text == null || text.isEmpty()) data.remove(name);
        else data.put(name, text);
    }

    public static void clear() {
        data.clear();
        ready = false;
        gen++;
    }

    public static boolean ready() { return ready; }

    public static int gen() { return gen; }

    /** A text longer than this is cut into pieces (the server and the network take only 9000 characters per blob). */
    private static final int CHUNK = 8000;

    private static String part(String name, int i) { return i == 0 ? name : name + "_p" + i; }

    /** Reads a text; a long one that was saved in pieces is put together again. */
    public static String read(String name) {
        String first = data.get(name);
        if (first == null) return null;
        StringBuilder sb = null;
        for (int i = 1; data.containsKey(part(name, i)); i++) {
            if (sb == null) sb = new StringBuilder(first);
            sb.append(data.get(part(name, i)));
        }
        return sb == null ? first : sb.toString();
    }

    /**
     * Save text under a name (an empty text deletes it). Nothing is sent if it did not change. A long text (the progress of a
     * player with a lot of things bought was over the limit, so the server refused it and the purchases were lost at the next
     * login) is saved in pieces: name, name_p1, name_p2...
     */
    public static void write(String name, String text) {
        if (!ready) return;
        int n = 0, from = 0;
        do {
            int to = Math.min(text.length(), from + CHUNK);
            if (to < text.length() && Character.isHighSurrogate(text.charAt(to - 1))) to--;   // never cut a pair in two
            put(part(name, n++), text.substring(from, to));
            from = to;
        } while (from < text.length());
        for (int i = n; data.containsKey(part(name, i)); i++) put(part(name, i), "");          // pieces of an older, longer text
    }

    private static void put(String key, String text) {
        String old = data.get(key);
        if (text.equals(old == null ? "" : old)) return;
        if (text.isEmpty()) data.remove(key);
        else data.put(key, text);
        PacketDistributor.sendToServer(new SaveDataPayload(key, text));
    }

    public static Properties readProps(String name) {
        String s = read(name);
        if (s == null) return null;
        try {
            Properties p = new Properties();
            p.load(new StringReader(s));
            return p;
        } catch (Exception e) {
            return null;
        }
    }

    public static void writeProps(String name, Properties p) {
        try {
            StringWriter w = new StringWriter();
            p.store(w, null);
            StringBuilder sb = new StringBuilder();
            for (String line : w.toString().split("\\R")) if (!line.startsWith("#")) sb.append(line).append('\n');   // no date comment: the text only changes when the data does
            write(name, sb.toString());
        } catch (Exception ignored) {
        }
    }
}
