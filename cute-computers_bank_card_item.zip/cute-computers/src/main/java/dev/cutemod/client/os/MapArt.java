package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The ids of the places of the pet's town and the little drawing helpers that many screens of the pet share (rectangles, balls, ovals,
 * triangles, lines). The picture of the town itself is {@link TownMap}; the clicks, the pet and the texts are in {@link PetMap}.
 * The whole screen is 300 x 166 and the header takes the top 17 pixels.
 */
final class MapArt {
    private MapArt() {}

    static final int W = 300, H = 166, HEAD = 17;

    // the ids of the places. The town map shows HOME, SCHOOL, PARK, STAGE, FARM, FISHING, BALLOON (the station of the trips and of the new
    // places that follow it), BOUTIQUE, PANTRY and CITY. The new places AMUSEMENT .. QUIET are opened from the panel of the balloon station.
    static final int HOME = 0, SCHOOL = 1, PARK = 2, STAGE = 3, FARM = 4, FISHING = 5, MARKET = 6, BALLOON = 7,
            AMUSEMENT = 8, CINEMA = 9, MUSEUM = 10, CAMP = 11, OLD_HOUSE = 12, FAIR = 13, QUIET = 14,
            // the little shops (apps of the pet) that the old map had: PetStyle, photo, stickers, pet stats, tic-tac-toe, the season (not on the map now)
            WARDROBE = 15, PHOTO = 16, STICKERS = 17, PETSTATS = 18, TICTAC = 19, SEASON = 20,
            // the boutique (outfits) and the pantry (treats)
            BOUTIQUE = 21, PANTRY = 22,
            // the long street of the pet (PetCity)
            CITY = 23, COUNT = 24;

    // ---------- tiny helpers (this class stands alone) ----------
    static void rect(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + h, c);
    }

    static void ball(GuiGraphics g, int cx, int cy, int r, int c) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.round(Math.sqrt((r + 0.2) * (r + 0.2) - dy * dy));
            rect(g, cx - dx, cy + dy, dx * 2 + 1, 1, c);
        }
    }

    static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int c) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0, 1 - dy * dy / (double) (ry * ry + 1))));
            rect(g, cx - dx, cy + dy, dx * 2, 1, c);
        }
    }

    static void tri(GuiGraphics g, int cx, int top, int w, int h, int c) {
        for (int r = 0; r < h; r++) {
            int ww = Math.max(1, w * (r + 1) / h);
            rect(g, cx - ww / 2, top + r, ww, 1, c);
        }
    }

    static void ln(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        int n = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)));
        for (int i = 0; i <= n; i++) rect(g, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, 1, 1, c);
    }

    static int mix(int a, int b, float f) { return App.mix(a, b, f); }

    static void shadow(GuiGraphics g, int cx, int b, int rx) { oval(g, cx, b, rx, 3, 0x30000000); }
}
