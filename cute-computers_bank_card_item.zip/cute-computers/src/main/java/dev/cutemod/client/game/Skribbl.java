package dev.cutemod.client.game;

import dev.cutemod.data.SkribblCanvas;
import dev.cutemod.data.SkribblGame;
import dev.cutemod.data.SkribblStamps;
import dev.cutemod.data.SkribblWords;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Scribble Pals: draw and guess with up to eight players (people and computer players), or play "telephone" (write a phrase, the next player
 * draws it, the next one describes the drawing...). One player gets a secret word and draws it, everybody else types guesses in a chat window;
 * the faster you guess, the more points you get. Every finished picture can be kept in the gallery. The rules run on the server
 * ({@link SkribblNet} is the line to it); this class is the screen: menu, rooms, the room (game, rounds, time, word set, own words), the game
 * (board, drawing tools, players, chat, reactions) and the gallery.
 */
public class Skribbl extends MiniGame {
    private static final int MENU = 0, ROOMS = 1, ROOM = 2, PLAY = 3, GALLERY = 4;
    private static final int INK = 0xFF3A3347, MUTED = 0xFF8E8A99, PINK = 0xFFE8566B, MINT = 0xFF3FA88A, SOFT = 0xFFE9B8D0, CARD = 0xFFFFFBF5;
    private static final int[] AVATAR = {0xFFF4A0C8, 0xFF6EC3F2, 0xFF8FD17A, 0xFFF7D860, 0xFFC9B8F5, 0xFFF59B5B, 0xFF7FD6C8, 0xFFE8566B};
    private static final int BX = 5, BY = 18;
    private static final int END_SECONDS = 18;
    private static final int P_PEN = 0, P_ERASER = 1, P_FILL = 2, P_LINE = 3, P_RECT = 4, P_OVAL = 5, P_STAMP = 6;

    private int screen = MENU, anim, notice, noticeT;
    private boolean autoStart, won, wasTele;
    private int prevPhase, lastSecond = -1, seenChatV = -1, seenBoardV = -1;

    // drawing
    private int tool = P_PEN, color = 1, sizeIdx = 1, stampIdx, popup;
    private boolean filled, down, inStroke, flushedAny, runsAreBoard;
    private int curStroke, lastX, lastY, sendT, shapeX, shapeY;
    private final List<int[]> pend = new ArrayList<>();
    private final StringBuilder input = new StringBuilder(), answer = new StringBuilder();
    private boolean focusAnswer;
    private final SkribblCanvas scratch = new SkribblCanvas();

    // what is drawn: the board as runs of one colour
    private int[] runs = new int[1024];
    private int runN;

    // the chat window and the reactions
    private static final class WL { String pre = "", txt = ""; int pc = INK, tc = INK; }
    private final List<WL> lines = new ArrayList<>();
    private static final class Puff { float x, y; int idx, age; String name; }
    private final List<Puff> puffs = new ArrayList<>();
    private int emojiCool;

    // the gallery
    private int gPage, gView = -1, gSure;

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private static String lang() { return Minecraft.getInstance().options.languageCode; }

    /** A word ("english|russian") in our language; a phrase a person wrote stays as it is. */
    private static String wordText(String entry) { return entry == null || entry.isEmpty() ? "" : SkribblWords.word(entry, lang()); }

    @Override
    public String hintKey() { return "cutemod.hint.skribbl"; }

    @Override
    public boolean isWin() { return won; }

    @Override
    public net.minecraft.network.chat.Component endTitle() { return Component.translatable(wasTele ? "cutemod.skribbl.tele_over" : won ? "cutemod.skribbl.won" : "cutemod.ui.gameover"); }

    @Override
    public void reset() {
        score = 0;
        over = false;
        won = false;
        wasTele = false;
        screen = MENU;
        down = inStroke = false;
        popup = 0;
        pend.clear();
        input.setLength(0);
        answer.setLength(0);
        autoStart = false;
        prevPhase = SkribblNet.phase;
        SkribblNet.request();                                    // maybe we are still in a room: tick() brings us back to it
    }

    @Override
    public void close() {
        if (SkribblNet.inRoom) SkribblNet.leave();
    }

    // ------------------------------------------------------------------ time

    @Override
    public void tick() {
        anim++;
        if (emojiCool > 0) emojiCool--;
        int n = SkribblNet.takeNotice();
        if (n != 0) { notice = n; noticeT = 200; }
        if (noticeT > 0) noticeT--;
        if ((screen == ROOMS || screen == ROOM) && anim % 100 == 0) SkribblNet.request();
        if ((screen == MENU || screen == ROOMS) && SkribblNet.inRoom) screen = SkribblNet.inGame ? PLAY : ROOM;
        if (screen == ROOM && !SkribblNet.inRoom) screen = ROOMS;
        if (screen == ROOM && SkribblNet.inGame) { screen = PLAY; input.setLength(0); answer.setLength(0); }
        if (autoStart && SkribblNet.inRoom && SkribblNet.youHost && !SkribblNet.inGame) { SkribblNet.start(); autoStart = false; }

        int ph = SkribblNet.phase;
        if (ph != prevPhase) { onPhase(prevPhase, ph); prevPhase = ph; }
        puffs();
        if (screen == PLAY) {
            score = SkribblNet.scores[SkribblNet.mySlot & 7];
            if (!SkribblNet.inGame) screen = SkribblNet.inRoom ? ROOM : MENU;
            drawTick();
            sounds();
        } else SkribblNet.emojis.clear();
    }

    private void onPhase(int from, int to) {
        if (to == SkribblGame.PICK && SkribblNet.mySlot == SkribblNet.drawer) pling(1.0F);
        if (to == SkribblGame.REVEAL) pling(0.8F);
        if (to == SkribblGame.END) pling(1.4F);
        if (to == SkribblGame.T_WRITE || to == SkribblGame.T_DRAW) { pling(1.0F); focusAnswer = to == SkribblGame.T_WRITE; popup = 0; answer.setLength(0); }
        if (from == SkribblGame.END && to == SkribblGame.LOBBY) {          // the game is over: the coins and the best score count
            int me = SkribblNet.mySlot & 7;
            boolean best = true;
            for (int i = 0; i < SkribblGame.SLOTS; i++) if (i != me && SkribblNet.slotType[i] >= 2 && SkribblNet.scores[i] > SkribblNet.scores[me]) best = false;
            score = SkribblNet.scores[me];
            won = best && score > 0;
            wasTele = false;
            screen = SkribblNet.inRoom ? ROOM : MENU;
            over = true;
        }
        if (from == SkribblGame.T_SHOW && to == SkribblGame.LOBBY) {        // a telephone game that was played to the end
            score = 300;
            won = false;
            wasTele = true;
            screen = SkribblNet.inRoom ? ROOM : MENU;
            over = true;
        }
    }

    private void sounds() {
        if (seenChatV != SkribblNet.chatVersion) {
            rebuildChat();
            for (int i = Math.max(0, SkribblNet.chat.size() - 3); i < SkribblNet.chat.size(); i++) {
                int k = SkribblNet.chat.get(i).kind;
                if (k == SkribblGame.K_GUESSED) pling(1.35F);
                else if (k == SkribblGame.K_CLOSE) pling(0.9F);
                else if (k == 20 || k == 21) pling(1.1F);
            }
        }
        if (SkribblNet.phase == SkribblGame.DRAW || SkribblNet.phase == SkribblGame.T_DRAW || SkribblNet.phase == SkribblGame.T_WRITE) {
            int sec = (SkribblNet.ticksLeft() + 19) / 20;
            if (sec != lastSecond && sec <= 5 && sec > 0) beep();
            lastSecond = sec;
        }
    }

    /** Reactions float up from the bottom of the board. */
    private void puffs() {
        SkribblNet.Emoji e;
        while ((e = SkribblNet.emojis.poll()) != null && screen == PLAY) {
            Puff p = new Puff();
            p.idx = e.idx;
            p.name = e.name;
            p.x = BX + 10 + (float) (Math.random() * (SkribblCanvas.CW - 30));
            p.y = BY + SkribblCanvas.CH - 16;
            puffs.add(p);
            if (puffs.size() > 24) puffs.remove(0);
        }
        for (int i = puffs.size() - 1; i >= 0; i--) {
            Puff p = puffs.get(i);
            p.age++;
            p.y -= 0.55F;
            p.x += (float) Math.sin(p.age / 9.0) * 0.25F;
            if (p.age > 100) puffs.remove(i);
        }
    }

    // ------------------------------------------------------------------ drawing with the mouse

    private boolean tele() { return SkribblNet.phase >= SkribblGame.T_WRITE; }

    private boolean iDone() { return (SkribblNet.guessedMask & (1 << (SkribblNet.mySlot & 7))) != 0; }

    /** True while this player may draw on the board: he is the drawer, or it is a telephone drawing step and he is not done. */
    private boolean canDraw() {
        int ph = SkribblNet.phase;
        if (ph == SkribblGame.DRAW) return SkribblNet.mySlot == SkribblNet.drawer;
        return ph == SkribblGame.T_DRAW && !iDone();
    }

    private int toolCode() {
        return switch (tool) {
            case P_PEN -> SkribblCanvas.PEN;
            case P_ERASER -> SkribblCanvas.ERASER;
            case P_FILL -> SkribblCanvas.FILL;
            case P_LINE -> SkribblCanvas.LINE;
            case P_RECT -> filled ? SkribblCanvas.RECTF : SkribblCanvas.RECT;
            case P_OVAL -> filled ? SkribblCanvas.OVALF : SkribblCanvas.OVAL;
            default -> SkribblCanvas.STAMP + stampIdx;
        };
    }

    private boolean freehand() { return tool == P_PEN || tool == P_ERASER; }

    private boolean dragShape() { return tool == P_LINE || tool == P_RECT || tool == P_OVAL; }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private void drawTick() {
        if (!canDraw()) { if (inStroke) endStroke(); down = false; return; }
        if (!down || !freehand()) return;
        int bx = mx - BX, by = my - BY;
        boolean inside = bx >= 0 && by >= 0 && bx < SkribblCanvas.CW && by < SkribblCanvas.CH;
        if (!inside) { if (inStroke) endStroke(); return; }
        if (!inStroke) { beginStroke(bx, by); return; }
        if (bx != lastX || by != lastY) {
            pend.add(new int[]{bx, by});
            lastX = bx;
            lastY = by;
            if (pend.size() >= 12) flush();
        }
        if (++sendT >= 3) flush();
    }

    private void beginStroke(int bx, int by) {
        inStroke = true;
        flushedAny = false;
        curStroke = ++SkribblNet.strokeNo;
        pend.clear();
        pend.add(new int[]{bx, by});
        lastX = bx;
        lastY = by;
        sendT = 0;
    }

    private void flush() {
        sendT = 0;
        if (pend.isEmpty() || (flushedAny && pend.size() < 2)) return;
        StringBuilder sb = new StringBuilder().append(curStroke).append(',').append(toolCode()).append(',').append(color).append(',').append(sizeIdx);
        for (int[] p : pend) sb.append(',').append(p[0]).append(',').append(p[1]);
        if (pend.size() == 1) sb.append(',').append(pend.get(0)[0]).append(',').append(pend.get(0)[1]);
        SkribblNet.op(sb.toString());
        flushedAny = true;
        int[] last = pend.get(pend.size() - 1);
        pend.clear();
        pend.add(last);
    }

    private void endStroke() {
        if (inStroke) flush();
        inStroke = false;
        pend.clear();
    }

    /** The operation of the shape that is being dragged (or the stamp under the mouse), for the preview; null if there is none. */
    private String previewOp() {
        if (!canDraw() || popup != 0) return null;
        int bx = mx - BX, by = my - BY;
        boolean inside = bx >= 0 && by >= 0 && bx < SkribblCanvas.CW && by < SkribblCanvas.CH;
        if (tool == P_STAMP && inside) return "0," + toolCode() + "," + color + "," + sizeIdx + "," + bx + "," + by;
        if (dragShape() && down) return "0," + toolCode() + "," + color + "," + sizeIdx + "," + shapeX + "," + shapeY + "," + clamp(bx, 0, SkribblCanvas.CW - 1) + "," + clamp(by, 0, SkribblCanvas.CH - 1);
        return null;
    }

    @Override
    public boolean release(int x, int y, int button) {
        if (button != 0 || !down) return false;
        if (dragShape() && canDraw()) {
            SkribblNet.op(++SkribblNet.strokeNo + "," + toolCode() + "," + color + "," + sizeIdx + "," + shapeX + "," + shapeY + ","
                    + clamp(x - BX, 0, SkribblCanvas.CW - 1) + "," + clamp(y - BY, 0, SkribblCanvas.CH - 1));
        } else if (inStroke) endStroke();
        down = false;
        return true;
    }

    // ------------------------------------------------------------------ mouse

    @Override
    public boolean click(int x, int y, int button) {
        switch (screen) {
            case MENU -> clickMenu(x, y);
            case ROOMS -> clickRooms(x, y);
            case ROOM -> clickRoom(x, y);
            case PLAY -> clickPlay(x, y, button);
            default -> clickGallery(x, y);
        }
        return true;
    }

    private void clickMenu(int x, int y) {
        if (in(x, y, 45, 48, 130, 17)) { autoStart = true; SkribblNet.create(); pling(1.3F); }
        else if (in(x, y, 45, 69, 130, 17)) { screen = ROOMS; SkribblNet.request(); pling(1.1F); }
        else if (in(x, y, 45, 90, 130, 17)) { screen = GALLERY; gPage = 0; gView = -1; pling(1.1F); }
    }

    private void clickRooms(int x, int y) {
        if (in(x, y, 4, 3, 24, 12)) { screen = MENU; beep(); return; }
        if (in(x, y, 138, 3, 78, 12)) { SkribblNet.create(); pling(1.2F); return; }
        int rows = Math.min(SkribblNet.hosts.size(), 5);
        for (int i = 0; i < rows; i++) if (in(x, y, 8, 24 + i * 20, 204, 18)) { SkribblNet.join(SkribblNet.hosts.get(i)); pling(1.2F); return; }
    }

    private boolean ownWords() { return SkribblNet.mode == SkribblGame.MODE_CLASSIC && SkribblNet.wordSet == SkribblWords.SET_OWN; }

    private void clickRoom(int x, int y) {
        if (in(x, y, 4, 3, 24, 12)) { SkribblNet.leave(); screen = ROOMS; autoStart = false; beep(); return; }
        if (ownWords()) {                                           // everybody may add words
            if (in(x, y, 190, 114, 20, 10)) { SkribblNet.clearWords(); beep(); return; }
        }
        if (!SkribblNet.youHost) return;
        for (int i = 0; i < SkribblGame.SLOTS; i++) {
            if (i != SkribblNet.mySlot && in(x, y, 6 + (i % 2) * 106, 19 + (i / 2) * 15, 102, 14)) { SkribblNet.slot(i); beep(); return; }
        }
        for (int i = 0; i < 2; i++) if (in(x, y, 40 + i * 86, 81, 84, 10)) { SkribblNet.setMode(i); beep(); return; }
        for (int i = 0; i < 3; i++) {
            if (SkribblNet.mode == SkribblGame.MODE_CLASSIC && in(x, y, 40 + i * 22, 92, 20, 10)) { SkribblNet.setRounds(i); beep(); return; }
            if (in(x, y, 140 + i * 23, 92, 22, 10)) { SkribblNet.setSeconds(i); beep(); return; }
        }
        if (SkribblNet.mode == SkribblGame.MODE_CLASSIC) {
            if (in(x, y, 40, 103, 12, 10)) { SkribblNet.setWordSet((SkribblNet.wordSet + SkribblWords.SETS - 1) % SkribblWords.SETS); beep(); return; }
            if (in(x, y, 170, 103, 12, 10) || in(x, y, 54, 103, 114, 10)) { SkribblNet.setWordSet((SkribblNet.wordSet + 1) % SkribblWords.SETS); beep(); return; }
        }
        if (in(x, y, 60, 126, 100, 12)) { SkribblNet.start(); pling(1.4F); }
    }

    private void clickPlay(int x, int y, int button) {
        int ph = SkribblNet.phase;
        boolean me = SkribblNet.mySlot == SkribblNet.drawer;
        if (ph == SkribblGame.END) {
            if (in(x, y, 70, 120, 80, 12)) { SkribblNet.leave(); screen = MENU; beep(); }
            return;
        }
        for (int i = 0; i < 6; i++) {
            if (in(x, y, 133 + i * 13, 111, 11, 11)) {
                if (emojiCool == 0) { SkribblNet.emoji(i); emojiCool = 36; beep(); }
                return;
            }
        }
        if (in(x, y, 132, 125, 83, 10)) { focusAnswer = false; return; }
        if (ph == SkribblGame.PICK && me) {
            for (int i = 0; i < 3; i++) if (in(x, y, 15, 34 + i * 19, 100, 16)) { SkribblNet.pick(i); pling(1.2F); return; }
        }
        if (ph == SkribblGame.REVEAL && !me && !SkribblNet.liked && !SkribblNet.word.isEmpty() && in(x, y, 92, 105, 30, 16)) { SkribblNet.like(); pling(1.5F); return; }
        if (ph == SkribblGame.T_WRITE) {
            if (in(x, y, 6, 115, 88, 12)) focusAnswer = true;
            else if (in(x, y, 98, 115, 26, 12)) submitAnswer();
            return;
        }
        if (ph == SkribblGame.T_DRAW && !iDone() && in(x, y, 3, 1, 46, 12)) { SkribblNet.teleDone(); pling(1.3F); return; }
        if (!canDraw()) return;
        if (popup != 0) { clickPopup(x, y); return; }
        if (in(x, y, BX, BY, SkribblCanvas.CW, SkribblCanvas.CH)) {
            if (button != 0) return;
            if (tool == P_FILL) {
                SkribblNet.op(++SkribblNet.strokeNo + ",2," + color + ",0," + (x - BX) + "," + (y - BY));
                pling(1.1F);
            } else if (tool == P_STAMP) {
                SkribblNet.op(++SkribblNet.strokeNo + "," + toolCode() + "," + color + "," + sizeIdx + "," + (x - BX) + "," + (y - BY));
                pling(1.25F);
            } else if (dragShape()) {
                shapeX = x - BX;
                shapeY = y - BY;
                down = true;
            } else down = true;
            return;
        }
        for (int i = 0; i < 16; i++) {
            if (in(x, y, 6 + (i % 8) * 9, 104 + (i / 8) * 9, 8, 8)) { color = i; if (tool == P_ERASER) tool = P_PEN; beep(); return; }
        }
        for (int i = 0; i < 8; i++) {
            if (!in(x, y, 81 + (i % 4) * 11, 103 + (i / 4) * 11, 10, 10)) continue;
            if (i == 7) filled = !filled;
            else if (i == P_STAMP) { tool = P_STAMP; popup = 2; }
            else tool = i;
            beep();
            return;
        }
        for (int i = 0; i < 4; i++) if (in(x, y, 81 + i * 11, 125, 10, 9)) { sizeIdx = i; beep(); return; }
        if (in(x, y, 6, 123, 14, 10)) { popup = 1; beep(); }
        else if (in(x, y, 34, 123, 22, 10)) { SkribblNet.undo(); beep(); }
        else if (in(x, y, 58, 123, 20, 10)) { SkribblNet.clearBoard(); pling(0.8F); }
    }

    private void clickPopup(int x, int y) {
        if (popup == 1) {
            for (int t = 0; t < SkribblCanvas.TONES; t++)
                for (int h = 0; h < SkribblCanvas.HUES; h++)
                    if (in(x, y, 9 + h * 9, 33 + t * 11, 8, 10)) { color = SkribblCanvas.BASE + t * SkribblCanvas.HUES + h; if (tool == P_ERASER) tool = P_PEN; popup = 0; beep(); return; }
        } else {
            for (int i = 0; i < SkribblStamps.COUNT; i++)
                if (in(x, y, 18 + (i % 4) * 24, 34 + (i / 4) * 21, 22, 19)) { stampIdx = i; tool = P_STAMP; popup = 0; pling(1.2F); return; }
        }
        popup = 0;
    }

    private void submitAnswer() {
        String t = answer.toString().trim();
        if (t.isEmpty() || iDone()) return;
        SkribblNet.teleText(t);
        answer.setLength(0);
        pling(1.3F);
    }

    private void clickGallery(int x, int y) {
        List<SkribblGallery.Entry> list = SkribblGallery.list();
        if (gView >= 0) {
            if (gView >= list.size()) { gView = -1; return; }
            if (in(x, y, 4, 3, 24, 12)) { gView = -1; gSure = 0; beep(); }
            else if (in(x, y, 14, 112, 24, 12) && gView > 0) { gView--; gSure = 0; beep(); }
            else if (in(x, y, 182, 112, 24, 12) && gView < list.size() - 1) { gView++; gSure = 0; beep(); }
            else if (in(x, y, 76, 112, 68, 12)) {
                if (gSure == 0) { gSure = 1; beep(); }
                else { SkribblGallery.remove(gView); gSure = 0; gView = Math.min(gView, SkribblGallery.count() - 1); pling(0.7F); }
            }
            return;
        }
        if (in(x, y, 4, 3, 24, 12)) { screen = MENU; beep(); return; }
        int pages = Math.max(1, (list.size() + 7) / 8);
        if (in(x, y, 150, 3, 22, 12) && gPage > 0) { gPage--; beep(); return; }
        if (in(x, y, 192, 3, 22, 12) && gPage < pages - 1) { gPage++; beep(); return; }
        for (int i = 0; i < 8; i++) {
            int idx = gPage * 8 + i;
            if (idx < list.size() && in(x, y, 6 + (i % 4) * 53, 22 + (i / 4) * 52, 50, 34)) { gView = idx; gSure = 0; pling(1.2F); return; }
        }
    }

    // ------------------------------------------------------------------ keys

    /** The text box that gets the typing right now. */
    private StringBuilder target() {
        if (screen == ROOM) return ownWords() ? answer : null;
        if (screen != PLAY || SkribblNet.phase == SkribblGame.END) return null;
        return SkribblNet.phase == SkribblGame.T_WRITE && focusAnswer ? answer : input;
    }

    @Override
    public boolean key(int keyCode) {
        StringBuilder t = target();
        if (t == null) return false;
        if (keyCode == 259) {                                       // backspace
            if (t.length() > 0) t.setLength(t.length() - 1);
            return true;
        }
        if (keyCode == 257 || keyCode == 335) {                     // enter
            String text = t.toString().trim();
            if (screen == ROOM) { if (!text.isEmpty()) SkribblNet.addWord(text); t.setLength(0); }
            else if (t == answer) submitAnswer();
            else { if (!text.isEmpty()) SkribblNet.say(text); t.setLength(0); }
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        StringBuilder t = target();
        if (t == null) return false;
        if (c < 32 || c == 127 || t.length() >= (screen == ROOM ? 20 : t == answer ? 40 : 44)) return true;
        t.append(c);
        return true;
    }

    // ------------------------------------------------------------------ drawing helpers

    private static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** A rounded card with a soft shadow. */
    private static void panel(GuiGraphics g, int x, int y, int w, int h, int border, int fill) {
        rect(g, x + 1, y + 2, w, h, 0x26302848);
        rect(g, x + 1, y, w - 2, h, border);
        rect(g, x, y + 1, w, h - 2, border);
        rect(g, x + 2, y + 1, w - 4, h - 2, fill);
        rect(g, x + 1, y + 2, w - 2, h - 4, fill);
        rect(g, x + 2, y + 1, w - 4, 1, 0x80FFFFFF);
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String s, int fill, int textColor) {
        boolean hov = in(mx, my, x, y, w, h);
        panel(g, x, y, w, h, mix(fill, INK, 0.28F), hov ? mix(fill, 0xFFFFFFFF, 0.35F) : fill);
        ctextW(g, s, x + w / 2, y + (h - 8) / 2 + 1, w - 6, textColor);
    }

    private static void stext(GuiGraphics g, String s, float x, float y, float k, int argb) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(k, k, 1F);
        dev.cutemod.client.os.CuteFont.draw(g, font(), s, 0, 0, argb, false);
        g.pose().popPose();
    }

    private static void bigText(GuiGraphics g, String s, int cx, int y, float k, int argb, int shadow) {
        float x = cx - tw(s) * k / 2F;
        stext(g, s, x + 1, y + 1, k, shadow);
        stext(g, s, x, y, k, argb);
    }

    private static void face(GuiGraphics g, int cx, int cy, int r, int col, boolean bot) {
        if (bot) rect(g, cx - r, cy - r + 1, r * 2 + 1, r * 2 - 1, col); else disc(g, cx, cy, r, col);
        rect(g, cx - r / 2 - 1, cy - 1, 1, 1 + r / 4, INK);
        rect(g, cx + r / 2, cy - 1, 1, 1 + r / 4, INK);
        if (bot) rect(g, cx, cy - r - 1, 1, 1, INK);
    }

    private void backdrop(GuiGraphics g) {
        for (int yy = 0; yy < H; yy += 4) rect(g, 0, yy, W, 4, mix(0xFFFFEEF5, 0xFFE4F1FF, yy / (float) H));
        for (int i = 0; i < 16; i++) {
            int x = (i * 47 + anim / 5) % (W + 16) - 8, y = (i * 29 + 11) % H;
            disc(g, x, y, 2 + i % 3, 0x38FFFFFF);
        }
    }

    /** Pixel pictures of the reactions: 9 x 9 dots, one letter per colour. */
    private static final String[][] ICONS = {
            {".rr...rr.", "rrrr.rrrr", "rrrrrrrrr", "rrrrrrrrr", ".rrrrrrr.", "..rrrrr..", "...rrr...", "....r....", "........."},
            {"..yyyyy..", ".yyyyyyy.", "ykkyyykky", "yyyyyyyyy", "ykkkkkkky", "yykwwwkyy", ".yykkkyy.", "..yyyyy..", "........."},
            {"..yyyyy..", ".yyyyyyy.", "yykyyykyy", "yykyyykyy", "yyyyyyyyy", "yyykkkyyy", "yyykwkyyy", ".yykkkyy.", "..yyyyy.."},
            {"....y....", "....y....", "...yyy...", "yyyyyyyyy", ".yyyyyyy.", "..yyyyy..", "..yy.yy..", ".yy...yy.", "........."},
            {"....o....", "...oo.o..", "..ooo.oo.", "..ooyooo.", ".oooyyooo", ".ooyyyyoo", ".ooyyyyoo", "..oyyyyo.", "...oooo.."},
            {"..yyyyy..", ".yyyyyyy.", "yykkyykky", "yybyyybyy", "yybyyybyy", "yyyyyyyyy", "yykkkkkyy", ".yyyyyyy.", "..yyyyy.."}};

    private static int iconColor(char c) {
        return switch (c) {
            case 'k' -> INK;
            case 'y' -> 0xFFF7D860;
            case 'o' -> 0xFFF59B5B;
            case 'r' -> 0xFFE8566B;
            case 'p' -> 0xFFF4A0C8;
            case 'w' -> 0xFFFFFFFF;
            case 'b' -> 0xFF6EC3F2;
            default -> 0;
        };
    }

    private static void bitmap(GuiGraphics g, String[] rows, int x, int y, int k, int alpha) {
        for (int j = 0; j < rows.length; j++)
            for (int i = 0; i < rows[j].length(); i++) {
                int c = iconColor(rows[j].charAt(i));
                if (c != 0) rect(g, x + i * k, y + j * k, k, k, (c & 0xFFFFFF) | (alpha << 24));
            }
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g) {
        backdrop(g);
        switch (screen) {
            case MENU -> renderMenu(g);
            case ROOMS -> renderRooms(g);
            case ROOM -> renderRoom(g);
            case PLAY -> renderPlay(g);
            default -> renderGallery(g);
        }
        if (noticeT > 0 && screen != PLAY) {
            panel(g, 30, 124, 160, 12, 0xFFE8566B, 0xFFFFE4EA);
            ctextW(g, tr("cutemod.skribbl.notice." + notice), W / 2, 126, 150, PINK);
        }
    }

    private void doodle(GuiGraphics g, int x, int y, int k) {
        int wob = (int) Math.round(Math.sin((anim + k * 20) / 14.0) * 2);
        y += wob;
        switch (k % 3) {
            case 0 -> { for (int i = 0; i < 9; i++) rect(g, x + i, y + 9 - i, 3, 3, i < 2 ? 0xFFE8C9A0 : i < 7 ? 0xFFF7D860 : 0xFFE8566B); rect(g, x, y + 9, 2, 2, INK); }
            case 1 -> { disc(g, x + 4, y + 4, 4, 0xFFF4A0C8); disc(g, x + 10, y + 4, 4, 0xFFF4A0C8); rect(g, x + 2, y + 5, 11, 4, 0xFFF4A0C8); rect(g, x + 4, y + 9, 7, 3, 0xFFF4A0C8); rect(g, x + 6, y + 12, 3, 2, 0xFFF4A0C8); }
            default -> { rect(g, x + 4, y, 3, 11, 0xFFF7D860); rect(g, x, y + 4, 11, 3, 0xFFF7D860); rect(g, x + 3, y + 3, 5, 5, 0xFFFFEFA0); }
        }
    }

    private void renderMenu(GuiGraphics g) {
        doodle(g, 14, 16, 0);
        doodle(g, 190, 18, 1);
        doodle(g, 32, 40, 2);
        doodle(g, 176, 38, 2);
        bigText(g, tr("cutemod.game.skribbl"), W / 2, 12, 1.7F, PINK, 0xFFFFD0E4);
        ctextW(g, tr("cutemod.skribbl.tagline"), W / 2, 33, 190, MUTED);
        button(g, 45, 48, 130, 17, tr("cutemod.skribbl.solo"), 0xFFBFEFD6, INK);
        button(g, 45, 69, 130, 17, tr("cutemod.skribbl.online"), 0xFFC9B8F5, INK);
        button(g, 45, 90, 130, 17, tr("cutemod.skribbl.gallery", SkribblGallery.count()), 0xFFF7E49A, INK);
        ctextW(g, tr("cutemod.skribbl.menu_tip"), W / 2, 114, 200, MUTED);
    }

    private void header(GuiGraphics g, String title) {
        panel(g, 3, 1, 214, 15, SOFT, CARD);
        button(g, 4, 3, 24, 12, "<", 0xFFF4C9DC, INK);
        ctextW(g, title, W / 2, 4, 130, INK);
    }

    private void renderRooms(GuiGraphics g) {
        header(g, tr("cutemod.skribbl.rooms"));
        button(g, 138, 3, 78, 12, tr("cutemod.skribbl.create"), 0xFFBFEFD6, INK);
        int rows = Math.min(SkribblNet.hosts.size(), 5);
        if (rows == 0) {
            ctextW(g, tr("cutemod.skribbl.rooms.none"), W / 2, 66, W - 24, MUTED);
            return;
        }
        for (int i = 0; i < rows; i++) {
            int y = 24 + i * 20;
            boolean hover = in(mx, my, 8, y, 204, 18);
            panel(g, 8, y, 204, 18, SOFT, hover ? 0xFFFFF0F6 : CARD);
            face(g, 20, y + 9, 5, AVATAR[i % 8], false);
            String host = SkribblNet.hosts.get(i);
            ctextW(g, host, 30 + Math.min(tw(host), 90) / 2, y + 5, 90, INK);
            String free = tr("cutemod.skribbl.free", SkribblNet.open.get(i));
            text(g, free, 150 - tw(free), y + 5, MUTED);
            button(g, 156, y + 3, 50, 12, tr("cutemod.skribbl.join"), 0xFFF7D860, INK);
        }
    }

    private void chip(GuiGraphics g, int x, int y, int w, int h, String s, boolean on) {
        boolean hov = SkribblNet.youHost && in(mx, my, x, y, w, h);
        panel(g, x, y, w, h, on ? 0xFFE0A800 : SOFT, on ? 0xFFF7D860 : hov ? 0xFFFFF0F6 : CARD);
        ctextW(g, s, x + w / 2, y + (h - 8) / 2 + 1, w - 4, INK);
    }

    private void renderRoom(GuiGraphics g) {
        header(g, tr("cutemod.skribbl.room"));
        for (int i = 0; i < SkribblGame.SLOTS; i++) {
            int x = 6 + (i % 2) * 106, y = 19 + (i / 2) * 15, t = SkribblNet.slotType[i];
            boolean click = SkribblNet.youHost && i != SkribblNet.mySlot;
            boolean hov = click && in(mx, my, x, y, 102, 14);
            panel(g, x, y, 102, 14, t == 3 ? 0xFFB9A6E8 : SOFT, hov ? 0xFFFFF0F6 : t == 0 ? 0xFFF1ECF3 : CARD);
            if (t >= 2) face(g, x + 9, y + 7, 4, AVATAR[i % 8], t == 2);
            else disc(g, x + 9, y + 7, 3, 0xFFD9D2E0);
            String label = t == 3 ? SkribblNet.slotName[i] : tr("cutemod.skribbl.slot." + t);
            ctextW(g, label, x + 58, y + 3, 80, t >= 2 ? INK : MUTED);
        }
        boolean tele = SkribblNet.mode == SkribblGame.MODE_TELEPHONE;
        text(g, tr("cutemod.skribbl.game_label"), 8, 83, INK);
        chip(g, 40, 81, 84, 10, tr("cutemod.skribbl.mode.0"), !tele);
        chip(g, 126, 81, 84, 10, tr("cutemod.skribbl.mode.1"), tele);
        if (!tele) {
            text(g, tr("cutemod.skribbl.rounds_label"), 8, 94, INK);
            for (int i = 0; i < 3; i++) chip(g, 40 + i * 22, 92, 20, 10, Integer.toString(SkribblGame.ROUNDS[i]), SkribblNet.roundsIdx == i);
        }
        text(g, tr("cutemod.skribbl.time_label"), 108, 94, INK);
        for (int i = 0; i < 3; i++) chip(g, 140 + i * 23, 92, 22, 10, tr("cutemod.skribbl.sec", SkribblGame.SECONDS[i]), SkribblNet.secondsIdx == i);
        if (!tele) {
            text(g, tr("cutemod.skribbl.words_label"), 8, 105, INK);
            button(g, 40, 103, 12, 10, "<", 0xFFC9B8F5, INK);
            chip(g, 54, 103, 114, 10, tr("cutemod.skribbl.set." + SkribblNet.wordSet), true);
            button(g, 170, 103, 12, 10, ">", 0xFFC9B8F5, INK);
            if (ownWords()) {
                panel(g, 6, 114, 128, 10, SOFT, 0xFFFFFFFF);
                String shown = answer.toString();
                while (shown.length() > 1 && tw(shown) > 120) shown = shown.substring(1);
                if (shown.isEmpty()) stext(g, tr("cutemod.skribbl.add_word"), 9, 116, 0.7F, 0xFFC4BFCF);
                else {
                    text(g, shown, 9, 115, INK);
                    if ((anim / 25) % 2 == 0) rect(g, 9 + tw(shown), 116, 1, 6, PINK);
                }
                ctextW(g, SkribblNet.customCount + "/" + SkribblGame.MAX_CUSTOM + " (" + SkribblNet.customMine + ")", 163, 115, 48, SkribblNet.customCount >= 3 ? MINT : MUTED);
                button(g, 190, 114, 20, 10, "x", 0xFFF4C9DC, INK);
            } else ctextW(g, tr("cutemod.skribbl.set_tip"), W / 2, 115, 200, MUTED);
        } else ctextW(g, tr("cutemod.skribbl.tele_tip"), W / 2, 105, 206, MUTED);
        if (SkribblNet.youHost) button(g, 60, 126, 100, 12, tr("cutemod.skribbl.start"), 0xFFF58FB8, INK);
        else ctextW(g, tr("cutemod.skribbl.wait"), W / 2, 128, 200, MUTED);
    }

    // ---- the game

    private void renderPlay(GuiGraphics g) {
        int ph = SkribblNet.phase;
        boolean me = SkribblNet.mySlot == SkribblNet.drawer;
        topBar(g, ph);
        panel(g, 3, 16, 124, 84, SOFT, 0xFFFFFFFF);
        switch (ph) {
            case SkribblGame.PICK -> { rect(g, BX, BY, SkribblCanvas.CW, SkribblCanvas.CH, 0xFFFFF6EE); pickOverlay(g, me); }
            case SkribblGame.T_WRITE -> writeView(g);
            case SkribblGame.T_SHOW -> showView(g);
            default -> {
                renderBoard(g);
                if (canDraw() && popup == 0) cursor(g);
            }
        }
        if (canDraw() && popup != 0) popups(g);
        for (Puff p : puffs) {
            int a = p.age < 80 ? 255 : Math.max(0, 255 - (p.age - 80) * 12);
            bitmap(g, ICONS[p.idx % ICONS.length], Math.round(p.x), Math.round(p.y), 2, a);
            if (!p.name.isEmpty()) stext(g, clip(p.name, 40), p.x, p.y + 19, 0.55F, (INK & 0xFFFFFF) | (a << 24));
        }
        playersWindow(g);
        chatWindow(g);
        bottomPanel(g, ph, me);
        if (ph == SkribblGame.END) endOverlay(g);
    }

    private String drawerName() { return SkribblNet.drawer >= 0 ? SkribblNet.slotName[SkribblNet.drawer & 7] : ""; }

    private void topBar(GuiGraphics g, int ph) {
        boolean tele = ph >= SkribblGame.T_WRITE;
        if (ph == SkribblGame.T_DRAW && !iDone()) button(g, 3, 1, 46, 12, tr("cutemod.skribbl.done"), 0xFFBFEFD6, INK);
        else {
            panel(g, 3, 1, 46, 12, SOFT, CARD);
            String chip = tele ? tr("cutemod.skribbl.step", Math.min(SkribblNet.round + 1, Math.max(1, SkribblNet.rounds)), SkribblNet.rounds)
                    : tr("cutemod.skribbl.round", Math.min(SkribblNet.round + 1, Math.max(1, SkribblNet.rounds)), SkribblNet.rounds);
            ctextW(g, chip, 26, 3, 42, INK);
        }
        panel(g, 52, 1, 116, 12, SOFT, CARD);
        String mid = switch (ph) {
            case SkribblGame.PICK -> tr("cutemod.skribbl.picking", drawerName());
            case SkribblGame.DRAW -> SkribblNet.mySlot == SkribblNet.drawer ? tr("cutemod.skribbl.draw_this", wordText(SkribblNet.word)) : tr("cutemod.skribbl.drawing", drawerName());
            case SkribblGame.REVEAL -> tr("cutemod.skribbl.the_word", wordText(SkribblNet.word));
            case SkribblGame.T_WRITE -> tr(SkribblNet.round == 0 ? "cutemod.skribbl.tele_write0" : "cutemod.skribbl.tele_write");
            case SkribblGame.T_DRAW -> tr("cutemod.skribbl.draw_this", wordText(SkribblNet.word));
            case SkribblGame.T_SHOW -> tr("cutemod.skribbl.tele_chain", SkribblNet.items.isEmpty() ? 1 : SkribblNet.items.get(SkribblNet.items.size() - 1).chain + 1);
            default -> tr("cutemod.skribbl.final");
        };
        boolean mine = (ph == SkribblGame.DRAW && SkribblNet.mySlot == SkribblNet.drawer) || ph == SkribblGame.T_DRAW;
        ctextW(g, mid, 110, 3, 110, mine ? PINK : INK);
        panel(g, 171, 1, 46, 12, SOFT, CARD);
        if (ph == SkribblGame.DRAW || ph == SkribblGame.T_DRAW || ph == SkribblGame.T_WRITE) {
            int t = SkribblNet.ticksLeft(), sec = (t + 19) / 20;
            ctextW(g, (sec / 60) + ":" + (sec % 60 < 10 ? "0" : "") + (sec % 60), 194, 3, 40, sec <= 10 ? PINK : INK);
            float f = Math.min(1F, t / (float) Math.max(1, SkribblNet.timeTotal));
            rect(g, 3, 14, 214, 2, 0x33302848);
            rect(g, 3, 14, Math.round(214 * f), 2, f > 0.5F ? MINT : f > 0.2F ? 0xFFF59B5B : PINK);
        }
    }

    private static int[] runsOfPixels(byte[] px) {
        int[] out = new int[256];
        int n = 0;
        for (int y = 0; y < SkribblCanvas.CH; y++) {
            int x = 0;
            while (x < SkribblCanvas.CW) {
                int c = px[y * SkribblCanvas.CW + x], x0 = x;
                while (x < SkribblCanvas.CW && px[y * SkribblCanvas.CW + x] == c) x++;
                if (c == 0) continue;
                if (n + 4 > out.length) out = java.util.Arrays.copyOf(out, out.length * 2);
                out[n++] = x0; out[n++] = y; out[n++] = x - x0; out[n++] = c;
            }
        }
        return java.util.Arrays.copyOf(out, n);
    }

    private void rebuildRuns(byte[] px) {
        int[] r = runsOfPixels(px);
        if (r.length > runs.length) runs = new int[r.length];
        System.arraycopy(r, 0, runs, 0, r.length);
        runN = r.length;
    }

    private byte[] cachePx;
    private int[] cacheRuns = new int[0];

    /** A finished picture (the one to describe, or one that is shown) at its real size. */
    private void picture(GuiGraphics g, byte[] px, int x, int y) {
        if (px != cachePx) { cachePx = px; cacheRuns = runsOfPixels(px); }
        rect(g, x, y, SkribblCanvas.CW, SkribblCanvas.CH, SkribblCanvas.PALETTE[0]);
        for (int i = 0; i < cacheRuns.length; i += 4) rect(g, x + cacheRuns[i], y + cacheRuns[i + 1], cacheRuns[i + 2], 1, SkribblCanvas.PALETTE[cacheRuns[i + 3]]);
    }

    private void renderBoard(GuiGraphics g) {
        String pv = previewOp();
        if (pv != null) {
            scratch.copyPixels(SkribblNet.board);
            scratch.preview(pv);
            rebuildRuns(scratch.px);
            runsAreBoard = false;
        } else if (!runsAreBoard || seenBoardV != SkribblNet.boardVersion) {
            rebuildRuns(SkribblNet.board.px);
            runsAreBoard = true;
            seenBoardV = SkribblNet.boardVersion;
        }
        rect(g, BX, BY, SkribblCanvas.CW, SkribblCanvas.CH, SkribblCanvas.PALETTE[0]);
        for (int i = 0; i < runN; i += 4) rect(g, BX + runs[i], BY + runs[i + 1], runs[i + 2], 1, SkribblCanvas.PALETTE[runs[i + 3]]);
    }

    private void cursor(GuiGraphics g) {
        int bx = mx - BX, by = my - BY;
        if (bx < 0 || by < 0 || bx >= SkribblCanvas.CW || by >= SkribblCanvas.CH) return;
        if (!freehand()) { rect(g, mx - 2, my, 5, 1, INK); rect(g, mx, my - 2, 1, 5, INK); return; }
        int r = SkribblCanvas.SIZES[sizeIdx] - 1;
        int c = tool == P_ERASER ? 0xCCE8566B : 0xAA3A3347;
        rect(g, mx - r - 1, my - r - 1, 2 * r + 3, 1, c);
        rect(g, mx - r - 1, my + r + 1, 2 * r + 3, 1, c);
        rect(g, mx - r - 1, my - r, 1, 2 * r + 1, c);
        rect(g, mx + r + 1, my - r, 1, 2 * r + 1, c);
    }

    /** The two small windows over the board: more colours, and the stamps. */
    private void popups(GuiGraphics g) {
        if (popup == 1) {
            panel(g, 6, 20, 116, 66, SOFT, 0xFFFFFBF5);
            stext(g, tr("cutemod.skribbl.more_colors"), 10, 22, 0.7F, MUTED);
            for (int t = 0; t < SkribblCanvas.TONES; t++)
                for (int h = 0; h < SkribblCanvas.HUES; h++) {
                    int x = 9 + h * 9, y = 33 + t * 11, idx = SkribblCanvas.BASE + t * SkribblCanvas.HUES + h;
                    if (idx == color) rect(g, x - 1, y - 1, 10, 12, INK);
                    rect(g, x, y, 8, 10, SkribblCanvas.PALETTE[idx]);
                }
            return;
        }
        panel(g, 14, 28, 100, 50, SOFT, 0xFFFFFBF5);
        for (int i = 0; i < SkribblStamps.COUNT; i++) {
            int x = 18 + (i % 4) * 24, y = 34 + (i / 4) * 21;
            panel(g, x, y, 22, 19, i == stampIdx ? INK : SOFT, in(mx, my, x, y, 22, 19) ? 0xFFFFF0F6 : CARD);
            for (int j = 0; j < 9; j++) for (int k = 0; k < 9; k++) if (SkribblStamps.on(i, k, j)) rect(g, x + 2 + k * 2, y + 1 + j * 2, 2, 2, SkribblCanvas.PALETTE[color]);
        }
    }

    private void pickOverlay(GuiGraphics g, boolean me) {
        if (me) {
            ctextW(g, tr("cutemod.skribbl.pick"), 65, 21, 110, PINK);
            for (int i = 0; i < 3; i++) {
                String w = i < SkribblNet.choices.size() ? wordText(SkribblNet.choices.get(i)) : "";
                button(g, 15, 34 + i * 19, 100, 16, w, new int[]{0xFFBFEFD6, 0xFFC9B8F5, 0xFFF7E49A}[i], INK);
            }
        } else {
            ctextW(g, tr("cutemod.skribbl.picking", drawerName()), 65, 44, 112, INK);
            String dots = ".".repeat(1 + (anim / 20) % 3);
            ctext(g, dots, 65, 56, MUTED);
            doodle(g, 59, 66, 0);
        }
    }

    // ---- the telephone game

    private List<String> wrapPlain(String s, int maxW) {
        List<String> out = new ArrayList<>();
        int start = 0;
        while (start < s.length() && out.size() < 5) {
            int best = start + 1;
            for (int e = start + 1; e <= s.length(); e++) {
                if (tw(s.substring(start, e)) > maxW) break;
                best = e;
            }
            if (best < s.length()) { int sp = s.lastIndexOf(' ', best - 1); if (sp > start + 2) best = sp + 1; }
            out.add(s.substring(start, best).trim());
            start = best;
        }
        return out;
    }

    private void writeView(GuiGraphics g) {
        if (SkribblNet.round == 0 || SkribblNet.promptPx == null) {
            rect(g, BX, BY, SkribblCanvas.CW, SkribblCanvas.CH, 0xFFFFF6EE);
            ctextW(g, tr("cutemod.skribbl.tele_hint0"), 65, 30, 112, INK);
            ctextW(g, tr("cutemod.skribbl.tele_hint1"), 65, 44, 112, MUTED);
            doodle(g, 59, 60, 1);
        } else {
            picture(g, SkribblNet.promptPx, BX, BY);
            panel(g, 7, 20, 60, 10, SOFT, 0xF0FFFFFF);
            ctextW(g, tr("cutemod.skribbl.what_is_this"), 37, 21, 56, PINK);
        }
    }

    private void showView(GuiGraphics g) {
        if (SkribblNet.items.isEmpty()) {
            rect(g, BX, BY, SkribblCanvas.CW, SkribblCanvas.CH, 0xFFFFF6EE);
            ctextW(g, tr("cutemod.skribbl.tele_ready"), 65, 44, 112, MUTED);
            return;
        }
        SkribblNet.Item it = SkribblNet.items.get(SkribblNet.items.size() - 1);
        String who = SkribblNet.slotName[it.author & 7];
        if (it.px != null) {
            picture(g, it.px, BX, BY);
            panel(g, 7, 20, 70, 10, SOFT, 0xF0FFFFFF);
            ctextW(g, tr("cutemod.skribbl.c.drew", who), 42, 21, 66, INK);
        } else {
            rect(g, BX, BY, SkribblCanvas.CW, SkribblCanvas.CH, 0xFFFFF6EE);
            ctextW(g, tr("cutemod.skribbl.c.wrote_title", who), 65, 24, 112, MUTED);
            List<String> ls = wrapPlain(wordText(it.text), 108);
            int y = 46 - ls.size() * 5;
            for (String l : ls) { ctextW(g, l, 65, y, 112, PINK); y += 11; }
        }
    }

    // ---- the players window

    private void playersWindow(GuiGraphics g) {
        panel(g, 130, 16, 87, 42, SOFT, CARD);
        stext(g, tr("cutemod.skribbl.players"), 134, 17, 0.62F, MUTED);
        int k = 0;
        for (int i = 0; i < SkribblGame.SLOTS; i++) {
            if (SkribblNet.slotType[i] < 2) continue;
            int x = 132 + (k % 2) * 42, y = 24 + (k / 2) * 8;
            k++;
            boolean draws = i == SkribblNet.drawer && SkribblNet.phase != SkribblGame.END;
            boolean got = (SkribblNet.guessedMask & (1 << i)) != 0;
            if (draws) rect(g, x - 1, y, 41, 8, 0x66F7D860);
            else if (got) rect(g, x - 1, y, 41, 8, 0x668FD17A);
            face(g, x + 3, y + 4, 3, AVATAR[i % 8], SkribblNet.slotType[i] == 2);
            String name = clip(SkribblNet.slotName[i], 30);
            stext(g, name, x + 8, y + 1, 0.62F, i == SkribblNet.mySlot ? PINK : INK);
            boolean gain = SkribblNet.phase == SkribblGame.REVEAL && SkribblNet.gains[i] > 0;
            boolean tele = SkribblNet.phase >= SkribblGame.T_WRITE;
            String sc = tele ? (got ? "ok" : "..") : gain ? "+" + SkribblNet.gains[i] : Integer.toString(SkribblNet.scores[i]);
            stext(g, sc, x + 40 - tw(sc) * 0.62F, y + 1, 0.62F, gain || (tele && got) ? MINT : MUTED);
        }
    }

    // ---- the chat window

    private static final int[] CHAT_NAME = {0xFFB85C8A};

    private void rebuildChat() {
        seenChatV = SkribblNet.chatVersion;
        lines.clear();
        List<SkribblNet.Line> all = SkribblNet.chat;
        for (int i = Math.max(0, all.size() - 30); i < all.size(); i++) addWrapped(all.get(i));
    }

    private void addWrapped(SkribblNet.Line l) {
        String pre = "", body;
        int pc = INK, tc = INK;
        switch (l.kind) {
            case SkribblGame.K_SAY -> { pre = l.name + ": "; body = l.text; pc = CHAT_NAME[0]; }
            case SkribblGame.K_WHISPER -> { pre = l.name + ": "; body = l.text; pc = tc = 0xFF6E7BC9; }
            case SkribblGame.K_GUESSED -> { body = tr("cutemod.skribbl.c.guessed", l.name); tc = 0xFF2E9B6E; }
            case SkribblGame.K_CLOSE -> { body = tr("cutemod.skribbl.c.close", l.text); tc = 0xFFD08A00; }
            case SkribblGame.K_WORD -> { body = tr("cutemod.skribbl.c.word", wordText(l.text)); tc = 0xFF9B7BE0; }
            case SkribblGame.K_NOBODY -> { body = tr("cutemod.skribbl.c.nobody"); tc = MUTED; }
            case SkribblGame.K_JOIN, SkribblGame.K_LEAVE -> { body = tr("cutemod.skribbl.c.left", l.name); tc = MUTED; }
            case 20 -> { body = tr("cutemod.skribbl.c.wrote", l.name, wordText(l.text)); tc = 0xFF9B7BE0; }
            case 21 -> { body = tr("cutemod.skribbl.c.drew", l.name); tc = 0xFF6E7BC9; }
            default -> { body = tr("cutemod.skribbl.c.drawer", l.name); tc = MUTED; }
        }
        String full = pre + body;
        int limit = 112, start = 0;
        boolean first = true;
        while (start < full.length()) {
            int best = start + 1;
            for (int e = start + 1; e <= full.length(); e++) {
                if (tw(full.substring(start, e)) > limit) break;
                best = e;
            }
            if (best < full.length()) {
                int sp = full.lastIndexOf(' ', best - 1);
                if (sp > start + 3) best = sp + 1;
            }
            String seg = full.substring(start, best);
            WL w = new WL();
            w.tc = tc;
            w.pc = pc;
            if (first) {
                int pl = Math.min(pre.length(), seg.length());
                w.pre = seg.substring(0, pl);
                w.txt = seg.substring(pl);
            } else w.txt = seg;
            lines.add(w);
            start = best;
            first = false;
        }
    }

    private void chatWindow(GuiGraphics g) {
        panel(g, 130, 60, 87, 77, SOFT, CARD);
        stext(g, tr("cutemod.skribbl.chat"), 134, 61, 0.62F, MUTED);
        if (seenChatV != SkribblNet.chatVersion) rebuildChat();
        int maxLines = 6;
        int y = 69 + (maxLines - 1) * 6 + 1;
        for (int i = lines.size() - 1, n = 0; i >= 0 && n < maxLines; i--, n++, y -= 6) {
            WL w = lines.get(i);
            float x = 133;
            if (!w.pre.isEmpty()) { stext(g, w.pre, x, y, 0.7F, w.pc); x += tw(w.pre) * 0.7F; }
            stext(g, w.txt, x, y, 0.7F, w.tc);
        }
        for (int i = 0; i < 6; i++) {                                      // the reactions
            int x = 133 + i * 13;
            boolean hov = in(mx, my, x, 111, 11, 11);
            panel(g, x, 111, 11, 11, SOFT, hov ? 0xFFFFF0F6 : CARD);
            bitmap(g, ICONS[i], x + 1, hov ? 111 : 112, 1, emojiCool > 0 ? 110 : 255);
        }
        boolean chatFocus = !(SkribblNet.phase == SkribblGame.T_WRITE && focusAnswer);
        panel(g, 132, 125, 83, 10, chatFocus ? PINK : SOFT, 0xFFFFFFFF);
        String shown = input.toString();
        while (shown.length() > 1 && tw(shown) * 0.8F > 74) shown = shown.substring(1);
        if (shown.isEmpty()) stext(g, tr("cutemod.skribbl.type"), 135, 127, 0.7F, 0xFFC4BFCF);
        else {
            stext(g, shown, 135, 126, 0.8F, INK);
            if (chatFocus && (anim / 25) % 2 == 0) rect(g, 135 + Math.round(tw(shown) * 0.8F), 127, 1, 6, PINK);
        }
    }

    // ---- under the board: the tools for the drawer, the hint for the others, the answer box of the telephone game

    private int[] doneCounts() {
        int d = 0, t = 0;
        for (int i = 0; i < SkribblGame.SLOTS; i++) if (SkribblNet.slotType[i] >= 2) { t++; if ((SkribblNet.guessedMask & (1 << i)) != 0) d++; }
        return new int[]{d, t};
    }

    private void bottomPanel(GuiGraphics g, int ph, boolean me) {
        panel(g, 3, 102, 124, 36, SOFT, CARD);
        if (canDraw()) { tools(g); return; }
        int cx = 65;
        switch (ph) {
            case SkribblGame.DRAW -> {
                boolean knows = !SkribblNet.word.isEmpty();
                ctextW(g, tr(knows ? "cutemod.skribbl.you_know" : "cutemod.skribbl.guess_tip"), cx, 105, 116, knows ? MINT : MUTED);
                String h = knows ? wordText(SkribblNet.word) : lang().toLowerCase().startsWith("ru") ? SkribblNet.hintRu : SkribblNet.hintEn;
                float k = Math.min(1.6F, 116F / Math.max(1, tw(h)));
                bigText(g, h, cx, 117, k, knows ? MINT : INK, 0xFFE9DDF0);
            }
            case SkribblGame.REVEAL -> revealPanel(g, me);
            case SkribblGame.PICK -> ctextW(g, tr(me ? "cutemod.skribbl.pick" : "cutemod.skribbl.guess_tip"), cx, 114, 116, me ? PINK : MUTED);
            case SkribblGame.T_WRITE -> answerPanel(g);
            case SkribblGame.T_DRAW -> {
                int[] c = doneCounts();
                ctextW(g, tr("cutemod.skribbl.handed_in"), cx, 108, 116, MINT);
                ctextW(g, tr("cutemod.skribbl.done_count", c[0], c[1]), cx, 122, 116, MUTED);
            }
            case SkribblGame.T_SHOW -> {
                ctextW(g, tr("cutemod.skribbl.tele_watch"), cx, 108, 116, MUTED);
                ctextW(g, tr("cutemod.skribbl.saved"), cx, 122, 116, MUTED);
            }
            default -> { }
        }
    }

    private void answerPanel(GuiGraphics g) {
        stext(g, tr(SkribblNet.round == 0 ? "cutemod.skribbl.tele_phrase" : "cutemod.skribbl.tele_caption"), 8, 105, 0.7F, MUTED);
        int[] c = doneCounts();
        if (iDone()) {
            ctextW(g, tr("cutemod.skribbl.handed_in"), 65, 114, 116, MINT);
            ctextW(g, tr("cutemod.skribbl.done_count", c[0], c[1]), 65, 126, 116, MUTED);
            return;
        }
        panel(g, 6, 115, 88, 12, focusAnswer ? PINK : SOFT, 0xFFFFFFFF);
        String shown = answer.toString();
        while (shown.length() > 1 && tw(shown) > 80) shown = shown.substring(1);
        if (shown.isEmpty()) stext(g, tr("cutemod.skribbl.type"), 9, 118, 0.7F, 0xFFC4BFCF);
        else {
            text(g, shown, 9, 117, INK);
            if (focusAnswer && (anim / 25) % 2 == 0) rect(g, 9 + tw(shown), 118, 1, 6, PINK);
        }
        button(g, 98, 115, 26, 12, tr("cutemod.skribbl.ok"), 0xFFBFEFD6, INK);
        stext(g, tr("cutemod.skribbl.done_count", c[0], c[1]), 8, 129, 0.62F, MUTED);
    }

    private void revealPanel(GuiGraphics g, boolean me) {
        int gain = SkribblNet.gains[SkribblNet.mySlot & 7];
        if (!SkribblNet.word.isEmpty()) {
            String w = wordText(SkribblNet.word);
            boolean heart = !me;
            int room = heart ? 80 : 112;
            float k = Math.min(1.4F, room / (float) Math.max(1, tw(w)));
            bigText(g, w, heart ? 48 : 65, 106, k, 0xFF9B7BE0, 0xFFE4DAF8);
            if (heart) {
                boolean hov = in(mx, my, 92, 105, 30, 16);
                panel(g, 92, 105, 30, 16, softHeart(SkribblNet.liked), hov && !SkribblNet.liked ? 0xFFFFE4EA : CARD);
                int hc = SkribblNet.liked ? PINK : 0xFFF4A0C8;
                disc(g, 99, 111, 2, hc);
                disc(g, 103, 111, 2, hc);
                rect(g, 97, 112, 8, 2, hc);
                rect(g, 99, 114, 4, 2, hc);
                text(g, Integer.toString(SkribblNet.likes), 108, 109, INK);
            } else if (SkribblNet.likes > 0) text(g, "<3 " + SkribblNet.likes, 100, 109, PINK);
        } else ctextW(g, tr("cutemod.skribbl.nobody"), 65, 108, 112, MUTED);
        ctextW(g, gain > 0 ? tr("cutemod.skribbl.points", gain) : tr("cutemod.skribbl.nopoints"), 65, 123, 116, gain > 0 ? MINT : MUTED);
        stext(g, tr("cutemod.skribbl.saved"), 65 - tw(tr("cutemod.skribbl.saved")) * 0.35F, 131, 0.7F, MUTED);
    }

    private static int softHeart(boolean liked) { return liked ? PINK : SOFT; }

    private void tools(GuiGraphics g) {
        for (int i = 0; i < 16; i++) {
            int x = 6 + (i % 8) * 9, y = 104 + (i / 8) * 9;
            rect(g, x - 1, y - 1, 10, 10, i == color && tool != P_ERASER ? INK : 0x00000000);
            rect(g, x, y, 8, 8, i == 0 ? 0xFFD9D2E0 : SkribblCanvas.PALETTE[i]);
            if (i == 0) rect(g, x + 1, y + 1, 6, 6, SkribblCanvas.PALETTE[0]);
        }
        for (int i = 0; i < 8; i++) {
            int x = 81 + (i % 4) * 11, y = 103 + (i / 4) * 11;
            boolean on = i == 7 ? filled : tool == i;
            panel(g, x, y, 10, 10, on ? INK : SOFT, on ? 0xFFF7D860 : in(mx, my, x, y, 10, 10) ? 0xFFFFF0F6 : CARD);
            toolIcon(g, i, x + 1, y + 1);
        }
        for (int i = 0; i < 4; i++) {
            int x = 81 + i * 11;
            boolean on = sizeIdx == i;
            panel(g, x, 125, 10, 9, on ? INK : SOFT, on ? 0xFFF7D860 : CARD);
            disc(g, x + 5, 129, Math.min(i, 3), tool == P_ERASER ? 0xFFE8566B : SkribblCanvas.PALETTE[color]);
        }
        button(g, 6, 123, 14, 10, "+", 0xFFC9B8F5, INK);
        rect(g, 21, 122, 12, 12, INK);
        rect(g, 22, 123, 10, 10, color == 0 ? 0xFFD9D2E0 : SkribblCanvas.PALETTE[color]);
        button(g, 34, 123, 22, 10, tr("cutemod.skribbl.undo"), 0xFFC9B8F5, INK);
        button(g, 58, 123, 20, 10, tr("cutemod.skribbl.clear"), 0xFFF4C9DC, INK);
    }

    private void toolIcon(GuiGraphics g, int i, int x, int y) {
        switch (i) {
            case 0 -> { for (int k = 0; k < 6; k++) rect(g, x + k, y + 6 - k, 2, 2, k == 0 ? INK : 0xFFE8566B); rect(g, x + 6, y, 2, 2, 0xFFE8C9A0); }
            case 1 -> { rect(g, x, y + 2, 8, 5, 0xFFF4A0C8); rect(g, x, y + 2, 3, 5, 0xFF6EC3F2); rect(g, x, y + 7, 8, 1, INK); }
            case 2 -> { rect(g, x + 1, y + 2, 6, 5, 0xFF6EC3F2); rect(g, x + 1, y + 2, 6, 1, INK); rect(g, x + 7, y + 4, 1, 3, 0xFF4A78E0); rect(g, x + 4, y, 1, 2, INK); }
            case 3 -> { for (int k = 0; k < 7; k++) rect(g, x + k, y + 6 - k, 2, 2, INK); }
            case 4 -> { rect(g, x, y + 1, 8, 1, INK); rect(g, x, y + 6, 8, 1, INK); rect(g, x, y + 1, 1, 6, INK); rect(g, x + 7, y + 1, 1, 6, INK); }
            case 5 -> { disc(g, x + 4, y + 4, 3, INK); disc(g, x + 4, y + 4, 2, 0xFFFFFBF5); }
            case 6 -> { for (int j = 0; j < 9; j++) for (int k = 0; k < 9; k++) if (SkribblStamps.on(stampIdx, k, j)) rect(g, x - 1 + k, y - 1 + j, 1, 1, INK); }
            default -> { rect(g, x, y + 1, 8, 6, INK); rect(g, x + 1, y + 2, 6, 4, 0xFFF4A0C8); }
        }
    }

    private void endOverlay(GuiGraphics g) {
        for (int i = 0; i < 40; i++) {
            int x = (i * 53 + anim * (1 + i % 3) / 2) % W, y = (i * 31 + anim * (1 + i % 2)) % H;
            rect(g, x, y, 2, 2, AVATAR[i % 8]);
        }
        panel(g, 16, 18, 188, 117, SOFT, 0xF8FFFBF5);
        bigText(g, tr("cutemod.skribbl.final"), W / 2, 22, 1.2F, PINK, 0xFFFFD0E4);
        Integer[] order = new Integer[SkribblGame.SLOTS];
        int n = 0;
        for (int i = 0; i < SkribblGame.SLOTS; i++) if (SkribblNet.slotType[i] >= 2) order[n++] = i;
        java.util.Arrays.sort(order, 0, n, (a, b) -> SkribblNet.scores[b] - SkribblNet.scores[a]);
        for (int r = 0; r < n; r++) {
            int i = order[r], y = 38 + r * 10;
            if (i == SkribblNet.mySlot) rect(g, 22, y - 1, 176, 10, 0x44F7D860);
            int medal = r == 0 ? 0xFFF2C230 : r == 1 ? 0xFFB9C2CC : r == 2 ? 0xFFCD8B4A : 0xFFE6DDEE;
            disc(g, 29, y + 4, 4, medal);
            ctext(g, Integer.toString(r + 1), 29, y, INK);
            face(g, 42, y + 4, 3, AVATAR[i % 8], SkribblNet.slotType[i] == 2);
            text(g, clip(SkribblNet.slotName[i], 100), 50, y, INK);
            String sc = Integer.toString(SkribblNet.scores[i]);
            text(g, sc, 190 - tw(sc), y, r == 0 ? 0xFFD08A00 : INK);
        }
        long gone = (System.nanoTime() - SkribblNet.stateAt) / 1_000_000_000L;
        ctextW(g, tr("cutemod.skribbl.back_in", Math.max(0, END_SECONDS - gone)), W / 2, 109, 170, MUTED);
        button(g, 70, 120, 80, 12, tr("cutemod.skribbl.leave"), 0xFFF4C9DC, INK);
    }

    // ---- the gallery

    private void renderGallery(GuiGraphics g) {
        List<SkribblGallery.Entry> list = SkribblGallery.list();
        if (gView >= 0 && gView < list.size()) { renderPicture(g, list); return; }
        int pages = Math.max(1, (list.size() + 7) / 8);
        header(g, tr("cutemod.skribbl.gallery", list.size()));
        if (pages > 1) {
            button(g, 150, 3, 22, 12, "<", 0xFFC9B8F5, INK);
            button(g, 192, 3, 22, 12, ">", 0xFFC9B8F5, INK);
            ctext(g, (gPage + 1) + "/" + pages, 182, 5, INK);
        }
        if (list.isEmpty()) {
            ctextW(g, tr("cutemod.skribbl.gallery.none"), W / 2, 66, W - 24, MUTED);
            return;
        }
        for (int i = 0; i < 8; i++) {
            int idx = gPage * 8 + i;
            if (idx >= list.size()) break;
            int x = 6 + (i % 4) * 53, y = 22 + (i / 4) * 52;
            boolean hov = in(mx, my, x, y, 50, 34);
            panel(g, x, y, 50, 34, hov ? PINK : SOFT, 0xFFFFFFFF);
            thumb(g, list.get(idx), x + 1, y + 1, 48F / SkribblCanvas.CW);
            ctextW(g, wordText(list.get(idx).word), x + 25, y + 37, 50, INK);
        }
    }

    /** A picture at the given scale: the paper and its runs of colour. */
    private static void thumb(GuiGraphics g, SkribblGallery.Entry e, int x, int y, float k) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(k, k, 1F);
        rect(g, 0, 0, SkribblCanvas.CW, SkribblCanvas.CH, SkribblCanvas.PALETTE[0]);
        int[] r = e.runs();
        for (int i = 0; i < r.length; i += 4) rect(g, r[i], r[i + 1], r[i + 2], 1, SkribblCanvas.PALETTE[r[i + 3]]);
        g.pose().popPose();
    }

    private void renderPicture(GuiGraphics g, List<SkribblGallery.Entry> list) {
        SkribblGallery.Entry e = list.get(gView);
        header(g, wordText(e.word));
        panel(g, 48, 20, 124, 84, SOFT, 0xFFFFFFFF);
        thumb(g, e, 50, 22, 1F);
        ctextW(g, tr("cutemod.skribbl.by", e.by.isEmpty() ? "?" : e.by), W / 2, 106, 200, MUTED);
        button(g, 14, 112, 24, 12, "<", 0xFFC9B8F5, INK);
        button(g, 182, 112, 24, 12, ">", 0xFFC9B8F5, INK);
        button(g, 76, 112, 68, 12, tr(gSure == 0 ? "cutemod.skribbl.delete" : "cutemod.skribbl.sure"), gSure == 0 ? 0xFFF4C9DC : 0xFFE8566B, INK);
    }
}
