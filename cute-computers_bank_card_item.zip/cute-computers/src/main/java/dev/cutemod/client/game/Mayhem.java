package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import dev.cutemod.data.MayhemSim;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

import static dev.cutemod.data.MayhemSim.*;

/**
 * Dangerous Weapons: a cute platform shooter in the spirit of Gun Mayhem. Four little fighters stand on marble islands
 * high in the sky, every slot is a person or a computer player. Shoot your rivals: the more a fighter is hurt, the farther
 * every hit throws him. Whoever flies off the stage loses a life. Crates with ten different weapons float down on balloons.
 * <p>
 * The rules live in {@link MayhemSim} (no Minecraft classes): solo, it runs here; online, it runs on the server and this class
 * only sends the keys and draws the snapshots. Everything here is looks: the backdrops, the fighters, the particles and sounds
 * that the events of the world turn into, the menu and the rooms.
 */
public class Mayhem extends MiniGame {
    private static final int MENU = 0, ROOMS = 1, ROOM = 2, PLAY = 3, LOADOUT = 4;

    private static final int[] BALLOON = {0, 0xFFFFD34D, 0xFFFF8A5C, 0xFF6FD6FF, 0xFFFF6B8A, 0xFF8ED36A, 0xFFFF9A3D, 0xFFC77DFF, 0xFF9AA3B5, 0xFFB8F0FF,
            0xFFC8924F, 0xFF4FA6EE, 0xFFE0E0F0, 0xFFE8903A, 0xFF7CE04A, 0xFFD28AFF};
    /** The colours of the bonuses: heal, shield, speed, wings, rage, rapid fire, extra life. */
    private static final int[] BONUS_C = {0xFFFF6B8A, 0xFF6FD6FF, 0xFFFFE27A, 0xFFD8E4FF, 0xFFFF5A4A, 0xFFFF9A3D, 0xFF7CE04A};
    private static final String[][] BONUS_ICON = {
            {"01010", "11111", "11111", "01110", "00100"},      // a heart
            {"11111", "11111", "11111", "01110", "00100"},      // a shield
            {"00110", "01100", "11111", "00110", "01100"},      // a bolt
            {"10001", "11011", "11111", "01110", "00100"},      // wings
            {"00100", "01110", "11111", "11111", "01110"},      // a flame
            {"01110", "10101", "10111", "10001", "01110"},      // a clock
            {"00100", "00100", "11111", "00100", "00100"}};     // a plus
    /** The ten colours of a fighter: the body, a darker one for the back and the feet, a light one for the top. */
    private static final int[] BODY = {0xFFE8544E, 0xFF3E8FE8, 0xFF4FC46A, 0xFFF2B33D, 0xFFA668E0, 0xFFF08A3A, 0xFFF273B5, 0xFF3CC8C0, 0xFFEDEDF4, 0xFF4A4E5E};
    private static final int[] SHADE = {0xFFB43A3A, 0xFF2A63B0, 0xFF349A4C, 0xFFC48A1E, 0xFF7A44B4, 0xFFC06420, 0xFFC24C88, 0xFF22968F, 0xFFB4B4C4, 0xFF2E313C};
    private static final int[] LIGHT = {0xFFFF9A90, 0xFF86BEFF, 0xFF93EBA0, 0xFFFFDE85, 0xFFD0A8FF, 0xFFFFB878, 0xFFFFB0D8, 0xFF8CEEE8, 0xFFFFFFFF, 0xFF8890A8};
    private static final int GUN_DARK = 0xFF343949, GUN_MID = 0xFF666E84, GUN_LIGHT = 0xFFABB4CB, WOOD = 0xFF8A5A33;

    // the setup of a solo match, kept between matches: 0 computer player, 1 player one, 2 player two
    static int[] mode = {1, 0, 0, 0};
    static int lives = 3, skill = 1, mapSel = RANDOM_MAP, modeSel;
    /** The look and kit {colour, class, pistol} of the four fighters of a solo match, and of me in online rooms. */
    static int[][] LD = {{0, 0, 0}, {1, 1, 0}, {2, 2, 0}, {3, 3, 0}};
    static int[] MY = {0, 1, 0};

    private static final class Part { float x, y, vx, vy, grav; int life, max, col, size, kind; }

    private static final class Ring { float x, y, r, maxR; int life, max, col; }

    private static final class Beam { float x1, x2, y; int life, max; }

    private static final class Zap { float x1, y1, x2, y2; int life, max; }

    private MayhemSim sim = new MayhemSim();
    private boolean online, won;
    private int screen = MENU, mapNow, ticks, anim, theme, menuTheme, shake, bannerT, bannerCol, p1Click, noticeT, seenState, sendT, sentBits = -1,
            lastPhase, lastCount, snapAge, ox, oy;
    private String banner = "", noticeKey = "";
    private final List<Part> parts = new ArrayList<>();
    private final List<Ring> rings = new ArrayList<>();
    private final List<Beam> beams = new ArrayList<>();
    private final List<Zap> zaps = new ArrayList<>();
    private final int[] shootAnim = new int[N], tagT = new int[N];
    private final String[] tagTxt = {"", "", "", ""};
    private final float[] rx = new float[N], ry = new float[N];
    private final boolean[] havePos = new boolean[N];
    private final boolean[] prevUp = new boolean[3], prevFire = new boolean[3], jumpEdge = new boolean[3], fireEdge = new boolean[3];
    private final Fighter[] preview = new Fighter[N];
    private int lastFuse;
    private int[] editLd = LD[0];
    private boolean editOnline, sentLoad;
    private int editSlot, pv;
    private final Fighter editPreview = new Fighter(0);

    public Mayhem() {
        for (int i = 0; i < N; i++) preview[i] = new Fighter(i);
        reset();
    }

    // ------------------------------------------------------------------ helpers

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private static int mix(int a, int b, float t) {
        t = Math.max(0F, Math.min(1F, t));
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** The colour c with its opacity multiplied by a (0..1). */
    private static int fade(int c, float a) {
        int al = Math.max(0, Math.min(255, Math.round(((c >>> 24) / 255F) * a * 255F)));
        return (al << 24) | (c & 0xFFFFFF);
    }

    private static int sign(float v) { return v < 0 ? -1 : 1; }

    private void R(GuiGraphics g, float x, float y, int w, int h, int c) {
        int ix = Math.round(x) + ox, iy = Math.round(y) + oy;
        g.fill(ix, iy, ix + w, iy + h, c);
    }

    private void D(GuiGraphics g, float cx, float cy, int r, int c) { disc(g, Math.round(cx) + ox, Math.round(cy) + oy, r, c); }

    private void big(GuiGraphics g, String s, int cx, int y, float k, int col) {
        g.pose().pushPose();
        g.pose().scale(k, k, 1F);
        ctext(g, s, Math.round(cx / k) + 1, Math.round(y / k) + 1, 0xAA000000);
        ctext(g, s, Math.round(cx / k), Math.round(y / k), col);
        g.pose().popPose();
    }

    private void say(String s, int col, int t) { banner = s; bannerCol = col; bannerT = t; }

    // ------------------------------------------------------------------ particles

    private void spawn(float x, float y, float vx, float vy, float grav, int life, int col, int size, int kind) {
        if (parts.size() > 500) return;
        Part p = new Part();
        p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.grav = grav; p.life = p.max = life; p.col = col; p.size = size; p.kind = kind;
        parts.add(p);
    }

    private void puff(float x, float y, int n, int col) {
        for (int i = 0; i < n; i++) spawn(x + (rnd.nextFloat() - 0.5F) * 4F, y, (rnd.nextFloat() - 0.5F) * 0.9F, -rnd.nextFloat() * 0.35F, 0F, 14 + rnd.nextInt(8), col, 1, 1);
    }

    private void tickParts() {
        for (int i = parts.size() - 1; i >= 0; i--) {
            Part p = parts.get(i);
            p.x += p.vx; p.y += p.vy; p.vy += p.grav;
            if (--p.life <= 0) parts.remove(i);
        }
        for (int i = beams.size() - 1; i >= 0; i--) if (--beams.get(i).life <= 0) beams.remove(i);
        for (int i = zaps.size() - 1; i >= 0; i--) if (--zaps.get(i).life <= 0) zaps.remove(i);
        for (int i = rings.size() - 1; i >= 0; i--) {
            Ring r = rings.get(i);
            r.r += (r.maxR - r.r) * 0.25F;
            if (--r.life <= 0) rings.remove(i);
        }
    }


    private MayhemSim S() { return online ? MayhemNet.view : sim; }

    /** The colour of a fighter in the round that is drawn. */
    private int col(int id) { return S().f[id].color; }

    private static int packLd(int[] l) { return l[0] | l[1] << 4 | l[2] << 8; }

    private static String colorName(int c) { return tr("cutemod.mayhem.col." + c); }

    private int me() {
        if (online) return MayhemNet.stateSlot >= 0 ? MayhemNet.stateSlot : MayhemNet.mySlot;
        for (int i = 0; i < N; i++) if (mode[i] != 0) return i;
        return 0;
    }

    private boolean mine(Fighter f) { return online ? f.id == me() : f.kind == KIND_HUMAN; }

    private String nameOf(int i) {
        Fighter q = S().f[i];
        if (online) {
            if (q.kind == KIND_HUMAN) return MayhemNet.slotName[i].isEmpty() ? colorName(q.color) : MayhemNet.slotName[i];
            return tr("cutemod.mayhem.bot");
        }
        return mode[i] == 1 ? tr("cutemod.mayhem.p1") : mode[i] == 2 ? tr("cutemod.mayhem.p2") : tr("cutemod.mayhem.bot");
    }

    // ------------------------------------------------------------------ flow

    @Override
    public void reset() {
        score = 0; over = false; won = false;
        screen = MENU; online = false;
        parts.clear(); rings.clear(); beams.clear(); zaps.clear();
        shake = 0; bannerT = 0; ox = 0; oy = 0; noticeT = 0;
        menuTheme = rnd.nextInt(3);
        MayhemNet.request();                                     // maybe we are still in a room: tick() brings us back to it
    }

    @Override
    public void close() {
        if (MayhemNet.inRoom) MayhemNet.leave();
    }

    private void startLocal() {
        boolean human = false;
        for (int m : mode) if (m != 0) human = true;
        if (!human) mode[0] = 1;
        if (modeSel == MODE_WAVES) {                                           // the bots are the enemies: there must be some
            boolean bot = false;
            for (int m : mode) if (m == 0) bot = true;
            if (!bot) mode[N - 1] = 0;
        }
        sim = new MayhemSim();
        for (int i = 0; i < N; i++) { sim.setup(i, mode[i] != 0 ? KIND_HUMAN : KIND_BOT); sim.setLoadout(i, LD[i][0], LD[i][1], LD[i][2]); }
        sim.gameMode = modeSel;
        sim.configure(lives, skill, -1, mapSel);
        sim.start();
        online = false;
        beginRound();
    }

    private void startOnline() {
        online = true;
        beginRound();
        seenState = MayhemNet.stateVersion - 1;
        MayhemNet.pending.clear();
    }

    private void beginRound() {
        screen = PLAY;
        score = 0; over = false; won = false;
        parts.clear(); rings.clear(); beams.clear(); zaps.clear();
        shake = 0; bannerT = 0; snapAge = 0; sentBits = -1; sendT = 0; lastCount = -1; lastFuse = BOMB_FUSE;
        java.util.Arrays.fill(havePos, false);
        java.util.Arrays.fill(shootAnim, 0);
        java.util.Arrays.fill(prevUp, false);
        java.util.Arrays.fill(prevFire, false);
        lastPhase = S().phase;
        theme = S().theme; mapNow = S().map;
        for (int i = 0; i < N; i++) { tagT[i] = 170; tagTxt[i] = nameOf(i); }
    }

    @Override
    public void tick() {
        ticks++; anim++;
        if (shake > 0) shake--;
        if (bannerT > 0) bannerT--;
        if (noticeT > 0) noticeT--;
        if (p1Click > 0) p1Click--;
        netTick();
        if (screen == PLAY) playTick();
        tickFx();
    }

    private void netTick() {
        int n = MayhemNet.takeNotice();
        if (n != 0) { noticeKey = "cutemod.mayhem.notice." + n; noticeT = 220; }
        if ((screen == ROOMS || screen == ROOM) && anim % 100 == 0) MayhemNet.request();
        if ((screen == MENU || screen == ROOMS) && MayhemNet.inRoom && !MayhemNet.inGame) { screen = ROOM; online = true; }
        if (screen == ROOM && !MayhemNet.inRoom) screen = ROOMS;
        if ((screen == ROOM || screen == LOADOUT) && MayhemNet.inRoom && !MayhemNet.inGame) {
            if (!sentLoad) { MayhemNet.setLoad(packLd(MY)); sentLoad = true; }
            int mine = MayhemNet.mySlot >= 0 && MayhemNet.mySlot < N ? MayhemNet.slotLoad[MayhemNet.mySlot] : -1;
            if (mine >= 0 && (mine & 15) != MY[0] && screen == ROOM) MY[0] = mine & 15;     // the server gave me a colour that is free
        } else if (screen != ROOM && screen != LOADOUT) sentLoad = false;
        if (screen == ROOM && MayhemNet.inGame && MayhemNet.stateVersion != seenState && !MayhemNet.view.over) startOnline();
        if (screen == PLAY && online && !MayhemNet.inRoom) { screen = ROOMS; online = false; }
    }

    private void tickFx() {
        for (int i = 0; i < N; i++) { if (shootAnim[i] > 0) shootAnim[i]--; if (tagT[i] > 0) tagT[i]--; }
        tickParts();
    }

    private void playTick() {
        MayhemSim s = S();
        if (online) {
            if (MayhemNet.stateVersion != seenState) { seenState = MayhemNet.stateVersion; snapAge = 0; drain(MayhemNet.pending); }
            else snapAge++;
            int bits = keysFor(0);
            int press = (jumpEdge[0] ? 1 : 0) | (fireEdge[0] ? 2 : 0);
            if (bits != sentBits || press != 0 || ++sendT >= 30) { MayhemNet.input(bits, press); sentBits = bits; sendT = 0; }
            for (Fighter q : s.f) if (q.kind != KIND_OFF && q.alive) q.anim++;
            smooth(s);
        } else {
            boolean two = false;
            for (int m : mode) if (m == 2) two = true;
            for (int i = 0; i < N; i++) {
                if (s.f[i].kind == KIND_HUMAN) s.input(i, keysFor(mode[i] == 2 ? 2 : two ? 1 : 0), false, false);
            }
            sim.tick();
            drain(sim.events);
            for (int i = 0; i < N; i++) { rx[i] = s.f[i].x; ry[i] = s.f[i].y; }
        }
        if (s.phase != lastPhase) {
            if (lastPhase == PH_COUNT && s.phase == PH_PLAY) { say(tr("cutemod.mayhem.fight"), 0xFFFFE27A, 55); pling(1.9F); }
            if (s.phase == PH_END) {
                if (s.gameMode == MODE_TEAMS) {
                    if (s.winTeam >= 0) say(tr("cutemod.mayhem.teamwins", tr("cutemod.mayhem.team." + s.winTeam)), teamColor(s.winTeam), 170);
                    else say(tr("cutemod.mayhem.draw"), 0xFFFFFFFF, 170);
                } else if (s.gameMode == MODE_WAVES) {
                    if (s.winTeam == 0) say(tr("cutemod.mayhem.wavesWon"), 0xFFFFE27A, 170);
                    else say(tr("cutemod.mayhem.wavesLost", s.wave), 0xFFFF6A5A, 170);
                } else if (s.winner >= 0) say(tr("cutemod.mayhem.winner", colorName(s.f[s.winner].color)), BODY[s.f[s.winner].color], 170);
                else say(tr("cutemod.mayhem.draw"), 0xFFFFFFFF, 170);
                pling(1.5F);
            }
            lastPhase = s.phase;
        }
        if (s.phase == PH_COUNT) {
            int n = Math.min(3, s.phaseT / 50 + 1);
            if (n != lastCount) { lastCount = n; pling(n == 3 ? 1.0F : n == 2 ? 1.2F : 1.4F); }
        }
        if (s.gameMode == MODE_BOMB && s.holder >= 0 && s.phase == PH_PLAY && s.fuse < 300) {          // the fuse ticks
            int step = s.fuse < 90 ? 10 : 20;
            if (s.fuse / step != lastFuse / step) pling(s.fuse < 90 ? 1.9F : 1.3F);
        }
        lastFuse = s.fuse;
        if (s.over && !over) {
            over = true;
            int m = me();
            score = s.scoreOf(m);
            if (s.gameMode == MODE_TEAMS) won = s.winTeam >= 0 && s.winTeam == s.teamOf(m);
            else if (s.gameMode == MODE_WAVES) won = s.winTeam == 0;
            else won = s.winner >= 0 && (online ? s.winner == m : s.f[s.winner].kind == KIND_HUMAN);
        }
    }

    /** What a person on a computer sees: where the fighters really are, a little ahead of the last snapshot. */
    private void smooth(MayhemSim s) {
        int age = Math.min(snapAge, 4);
        for (Fighter q : s.f) {
            if (q.kind == KIND_OFF) continue;
            int i = q.id;
            float tx = q.x + q.vx * age, ty = q.y + (q.ground ? 0F : q.vy * age);
            if (!havePos[i] || !q.alive || Math.abs(tx - rx[i]) > 40 || Math.abs(ty - ry[i]) > 40) { rx[i] = tx; ry[i] = ty; havePos[i] = true; }
            else { rx[i] += (tx - rx[i]) * 0.5F; ry[i] += (ty - ry[i]) * 0.5F; }
        }
    }

    // ------------------------------------------------------------------ keys

    /** The keys of one way of playing: 0 alone (WASD and the arrows), 1 player one of two (WASD), 2 player two (arrows). */
    private int keysFor(int sch) {
        boolean l, r, u, d, fire;
        if (sch == 2) {
            l = down(263); r = down(262); u = down(265); d = down(264);
            fire = down(257) || down(335) || down(345) || down(344);
        } else {
            boolean arrows = sch == 0;
            l = down(65) || (arrows && down(263));
            r = down(68) || (arrows && down(262));
            u = down(87) || (arrows && down(265));
            d = down(83) || (arrows && down(264));
            fire = down(32) || down(70) || p1Click > 0 || (arrows && (down(257) || down(345)));
        }
        jumpEdge[sch] = u && !prevUp[sch]; prevUp[sch] = u;
        fireEdge[sch] = fire && !prevFire[sch]; prevFire[sch] = fire;
        return (l ? K_LEFT : 0) | (r ? K_RIGHT : 0) | (d ? K_DOWN : 0) | (fire ? K_FIRE : 0) | (u ? K_JUMP : 0);
    }

    @Override
    public boolean key(int k) {
        if (k == 256) return false;
        if (screen == MENU) {
            if (k == 257 || k == KEY_SPACE || k == 335) { startLocal(); return true; }
            return false;
        }
        if (screen != PLAY) return false;
        return k == 87 || k == 65 || k == 83 || k == 68 || k == KEY_SPACE || k == 70 || k == 257 || k == KEY_UP || k == KEY_DOWN
                || k == KEY_LEFT || k == KEY_RIGHT || k == 345 || k == 344;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (screen == PLAY) { p1Click = 6; return true; }
        if (screen == MENU) return menuClick(x, y);
        if (screen == ROOMS) return roomsClick(x, y);
        if (screen == ROOM) return roomClick(x, y);
        if (screen == LOADOUT) return loadoutClick(x, y);
        return false;
    }

    private boolean menuClick(int x, int y) {
        for (int i = 0; i < N; i++) {
            if (in(x, y, 8 + i * 53 + 37, 26, 11, 10)) { openEditor(false, i); return true; }
            if (in(x, y, 8 + i * 53, 24, 49, 50)) { cycle(i); beep(); return true; }
        }
        for (int m = 0; m <= MAPS; m++) {
            if (in(x, y, 7 + m * 26, 76, 24, 16)) { mapSel = m; beep(); return true; }
        }
        if (in(x, y, 8, 105, 100, 12)) { modeSel = (modeSel + 1) % MODES; beep(); return true; }
        if (in(x, y, 110, 105, 44, 12)) { lives = lives == 3 ? 5 : lives == 5 ? 2 : 3; beep(); return true; }
        if (in(x, y, 156, 105, 56, 12)) { skill = (skill + 1) % 3; beep(); return true; }
        if (in(x, y, 8, 122, 100, 14)) { startLocal(); return true; }
        if (in(x, y, 112, 122, 100, 14)) { screen = ROOMS; MayhemNet.request(); pling(1.0F); return true; }
        return true;
    }

    private void cycle(int i) {
        int m = mode[i];
        for (int k = 0; k < 3; k++) {
            m = (m + 1) % 3;
            boolean used = false;
            for (int j = 0; j < N; j++) if (j != i && m != 0 && mode[j] == m) used = true;
            if (!used) break;
        }
        mode[i] = m;
    }

    private boolean roomsClick(int x, int y) {
        if (in(x, y, 4, 4, 30, 12)) { screen = MENU; pling(0.8F); return true; }
        if (in(x, y, 140, 3, 76, 14)) { MayhemNet.create(); pling(1.2F); return true; }
        int rows = Math.min(MayhemNet.hosts.size(), 5);
        for (int i = 0; i < rows; i++) {
            if (in(x, y, 8, 24 + i * 20, 204, 18)) { MayhemNet.join(MayhemNet.hosts.get(i)); pling(1.2F); return true; }
        }
        return true;
    }

    private boolean roomClick(int x, int y) {
        if (in(x, y, 4, 4, 38, 12)) { MayhemNet.leave(); screen = ROOMS; pling(0.8F); return true; }
        if (in(x, y, 150, 3, 66, 12)) { openEditor(true, MayhemNet.mySlot); return true; }
        if (!MayhemNet.youHost) return false;
        for (int i = 1; i < 4; i++) {
            if (in(x, y, 8 + i * 53, 18, 49, 50)) { MayhemNet.slot(i); beep(); return true; }
        }
        for (int m = 0; m <= MAPS; m++) {
            if (in(x, y, 7 + m * 26, 72, 24, 16)) { MayhemNet.setMap(m); beep(); return true; }
        }
        for (int i = 0; i < MODES; i++) {
            if (in(x, y, 7 + i * 35, 100, 33, 11)) { MayhemNet.setMode(i); beep(); return true; }
        }
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 32 + i * 31, 112, 29, 11)) { MayhemNet.setLevel(i); beep(); return true; }
        }
        int[] lv = {2, 3, 5};
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 160 + i * 19, 112, 17, 11)) { MayhemNet.setLives(lv[i]); beep(); return true; }
        }
        if (in(x, y, 40, 125, 140, 12)) { MayhemNet.start(); pling(1.4F); return true; }
        return true;
    }

    // ------------------------------------------------------------------ events -> particles and sounds

    private void drain(List<int[]> events) {
        for (int[] e : events) fx(e);
        events.clear();
    }

    private void fx(int[] e) {
        MayhemSim s = S();
        switch (e[0]) {
            case EV_SHOOT -> {
                int id = e[1], w = e[2], face = e[5];
                float mx = e[3] / 16F, my = e[4] / 16F;
                shootAnim[id] = 7;
                spawn(mx + face * 2, my, 0, 0, 0, 3, w == ICE || w == TESLA ? 0xFFB8F0FF : w == LASER ? 0xFFE0B8FF : w == SLIME ? 0xFF7CE04A : w == SWAP ? 0xFFD28AFF : 0xFFFFF2A0,
                        w == SHOTGUN || w == ROCKET || w == GRENADE || w == CLUSTER ? 4 : w == SNIPER ? 3 : 2, 2);
                if (w <= SNIPER) spawn(mx - face * 9, my - 1, -face * (0.4F + rnd.nextFloat() * 0.5F), -1.1F - rnd.nextFloat() * 0.6F, 0.12F, 30, 0xFFE6B84A, 1, 3);
                if (w == SHOTGUN || w == ROCKET || w == GRENADE || w == CLUSTER) {
                    for (int i = 0; i < 4; i++) spawn(mx, my, face * (0.3F + rnd.nextFloat() * 0.8F), (rnd.nextFloat() - 0.5F) * 0.6F, 0F, 18, 0xFFD8D8E8, 1, 1);
                }
                if ((w == GRENADE || w == CLUSTER) && s.f[id].has(PERK_QUACKING)) sound(SoundEvents.CHICKEN_HURT, 1.6F, 0.5F);
                switch (w) {
                    case PISTOL -> sound(SoundEvents.ARROW_SHOOT, 2.1F - P_DMG[s.f[id].pistol] * 0.09F, 0.4F);
                    case SMG -> sound(SoundEvents.CROSSBOW_SHOOT, 2.0F, 0.25F);
                    case SHOTGUN -> { sound(SoundEvents.GENERIC_EXPLODE, 1.9F, 0.28F); sound(SoundEvents.CROSSBOW_SHOOT, 0.7F, 0.4F); }
                    case SNIPER -> sound(SoundEvents.FIREWORK_ROCKET_BLAST, 0.7F, 0.55F);
                    case GRENADE -> sound(SoundEvents.CROSSBOW_SHOOT, 0.6F, 0.5F);
                    case FLAME -> { if ((ticks & 3) == 0) sound(SoundEvents.ARROW_SHOOT, 0.5F, 0.25F); }
                    case LASER -> { sound(SoundEvents.ENDERMAN_TELEPORT, 2.0F, 0.35F); sound(SoundEvents.FIREWORK_ROCKET_BLAST, 1.9F, 0.3F); }
                    case MINE -> sound(SoundEvents.PLAYER_ATTACK_KNOCKBACK, 0.6F, 0.5F);
                    case ICE -> sound(SoundEvents.GLASS_HIT, 1.6F, 0.5F);
                    case BOOMER -> sound(SoundEvents.ARROW_SHOOT, 0.8F, 0.4F);
                    case TESLA -> sound(SoundEvents.ENDERMAN_TELEPORT, 2.0F, 0.2F);
                    case HARPOON -> sound(SoundEvents.CROSSBOW_SHOOT, 0.9F, 0.5F);
                    case CLUSTER -> sound(SoundEvents.CROSSBOW_SHOOT, 0.5F, 0.5F);
                    case SLIME -> sound(SoundEvents.SLIME_SQUISH, 1.4F, 0.4F);
                    case SWAP -> sound(SoundEvents.ENDERMAN_TELEPORT, 1.8F, 0.25F);
                    default -> sound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 0.8F, 0.55F);
                }
            }
            case EV_JUMP -> {
                puff(e[2] / 16F, e[3] / 16F, e[4] == 1 ? 5 : 4, e[4] == 1 ? LIGHT[col(e[1])] : 0xFFFFFFFF);
                sound(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, e[4] == 1 ? 1.9F : 1.5F, 0.3F);
            }
            case EV_LAND -> puff(e[1] / 16F, e[2] / 16F, 3, 0xFFFFFFFF);
            case EV_HIT -> {
                int id = e[1], w = e[2];
                float x = e[3] / 16F, y = e[4] / 16F;
                int dir = (e[5] & 1) != 0 ? 1 : -1;
                if (w == ICE) {
                    for (int i = 0; i < 8; i++) spawn(x, y, (rnd.nextFloat() - 0.5F) * 2F, (rnd.nextFloat() - 0.7F) * 1.6F, 0.05F, 20, i % 2 == 0 ? 0xFFB8F0FF : 0xFFFFFFFF, 1, 0);
                } else if (w == SLIME) {
                    for (int i = 0; i < 6; i++) spawn(x, y, (rnd.nextFloat() - 0.5F) * 1.6F, (rnd.nextFloat() - 0.3F) * 1.2F, 0.06F, 18, i % 2 == 0 ? 0xFF7CE04A : 0xFFD8FFB8, 1, 0);
                } else if (w == LASER || w == TESLA) {
                    for (int i = 0; i < 6; i++) spawn(x, y, (rnd.nextFloat() - 0.5F) * 2.4F, (rnd.nextFloat() - 0.5F) * 2.4F, 0F, 12, i % 2 == 0 ? 0xFFE0B8FF : 0xFFFFFFFF, 1, 0);
                } else if (w != ROCKET) {
                    for (int i = 0; i < 4; i++) {
                        spawn(x, y, dir * (0.5F + rnd.nextFloat()), (rnd.nextFloat() - 0.7F) * 1.4F, 0.05F, 14,
                                w == FLAME ? (i % 2 == 0 ? 0xFFFFB347 : 0xFFFF6A3D) : i % 2 == 0 ? 0xFFFFFFFF : LIGHT[col(id)], 1, 0);
                    }
                }
                if ((e[5] & 2) != 0) shake = Math.max(shake, 4);
                if (w != FLAME || (ticks & 3) == 0) sound(SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.4F, 0.35F);
            }
            case EV_EXPLODE -> {
                float x = e[1] / 16F, y = e[2] / 16F, size = e[3] / 10F;
                Ring rg = new Ring(); rg.x = x; rg.y = y; rg.r = 3; rg.maxR = 24 * size; rg.life = rg.max = 16; rg.col = 0xFFFFE27A; rings.add(rg);
                for (int i = 0; i < 22; i++) {
                    float a = rnd.nextFloat() * 6.2832F, sp = 0.4F + rnd.nextFloat() * 2.2F;
                    spawn(x, y, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp, 0.02F, 20 + rnd.nextInt(14),
                            i % 3 == 0 ? 0xFFFF7A3D : i % 3 == 1 ? 0xFFFFD34D : 0xFFE8E8F0, 2, 1);
                }
                spawn(x, y, 0, 0, 0, 7, 0xFFFFF2A0, 9, 2);
                shake = Math.max(shake, 6);
                sound(SoundEvents.GENERIC_EXPLODE, 1.15F, 0.6F);
            }
            case EV_DIE -> {
                int id = e[1];
                float px = e[2] / 16F, py = e[3] / 16F;
                for (int i = 0; i < 26; i++) {
                    float a = rnd.nextFloat() * 6.2832F, sp = 0.6F + rnd.nextFloat() * 2.4F;
                    spawn(px, py, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp, 0.02F, 28 + rnd.nextInt(18), i % 3 == 0 ? 0xFFFFFFFF : BODY[col(id)], 2, 0);
                }
                Ring rg = new Ring(); rg.x = px; rg.y = py; rg.r = 2; rg.maxR = 26; rg.life = rg.max = 22; rg.col = LIGHT[col(id)]; rings.add(rg);
                shake = Math.max(shake, 9);
                sound(SoundEvents.GENERIC_EXPLODE, 0.9F, 0.45F);
                sound(SoundEvents.ENDERMAN_TELEPORT, 0.8F, 0.4F);
                if (s.phase == PH_PLAY) say(tr("cutemod.mayhem.ko"), BODY[col(id)], 32);
            }
            case EV_RESPAWN -> {
                int id = e[1];
                puff(e[2] / 16F, 4, 8, LIGHT[col(id)]);
                sound(SoundEvents.ENDERMAN_TELEPORT, 1.6F, 0.3F);
                tagT[id] = 110; tagTxt[id] = nameOf(id);
            }
            case EV_PICKUP -> {
                int id = e[1], w = e[2];
                Ring rg = new Ring(); rg.x = e[3] / 16F; rg.y = e[4] / 16F; rg.r = 2; rg.maxR = 14; rg.life = rg.max = 14; rg.col = 0xFFFFFFFF; rings.add(rg);
                pling(1.7F);
                tagT[id] = 80; tagTxt[id] = tr("cutemod.mayhem.w." + w);
            }
            case EV_CRATE_LAND -> {
                float x = e[1] / 16F, y = e[2] / 16F;
                if (e[4] == 1) {
                    for (int k = 0; k < 8; k++) spawn(x, y - 9, (rnd.nextFloat() - 0.5F) * 1.6F, (rnd.nextFloat() - 0.9F) * 1.2F, 0.05F, 24, BONUS_C[e[3]], 1, 0);
                } else {
                    for (int k = 0; k < 8; k++) spawn(x, y - 24, (rnd.nextFloat() - 0.5F) * 1.4F, (rnd.nextFloat() - 0.8F) * 1F, 0.05F, 24, BALLOON[e[3]], 2, 0);
                }
            }
            case EV_ZAP -> {
                Zap z = new Zap();
                z.x1 = e[1] / 16F; z.y1 = e[2] / 16F; z.x2 = e[3] / 16F; z.y2 = e[4] / 16F; z.life = z.max = 7;
                zaps.add(z);
            }
            case EV_BONUS -> {
                int id = e[1], b = e[2];
                Ring rg = new Ring(); rg.x = e[3] / 16F; rg.y = e[4] / 16F; rg.r = 2; rg.maxR = 18; rg.life = rg.max = 16; rg.col = BONUS_C[b]; rings.add(rg);
                for (int k = 0; k < 10; k++) {
                    float a = rnd.nextFloat() * 6.2832F, sp = 0.4F + rnd.nextFloat() * 1.4F;
                    spawn(e[3] / 16F, e[4] / 16F, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp - 0.4F, 0.02F, 24, k % 2 == 0 ? BONUS_C[b] : 0xFFFFFFFF, 1, 0);
                }
                sound(SoundEvents.PLAYER_LEVELUP, 1.6F, 0.4F);
                pling(1.9F);
                tagT[id] = 80; tagTxt[id] = tr("cutemod.mayhem.b." + b);
            }
            case EV_BLOCK -> {
                float x = e[2] / 16F, y = e[3] / 16F;
                Ring rg = new Ring(); rg.x = x; rg.y = y; rg.r = 1; rg.maxR = 7; rg.life = rg.max = 8; rg.col = 0xFFB8F0FF; rings.add(rg);
                for (int k = 0; k < 4; k++) spawn(x, y, (rnd.nextFloat() - 0.5F) * 1.8F, (rnd.nextFloat() - 0.5F) * 1.8F, 0F, 10, 0xFFB8F0FF, 1, 0);
                sound(SoundEvents.GLASS_HIT, 2.0F, 0.35F);
            }
            case EV_SWAP -> {
                float x = e[3] / 16F, y = e[4] / 16F;
                for (int k = 0; k < 8; k++) spawn(x, y - 6, (rnd.nextFloat() - 0.5F) * 2F, (rnd.nextFloat() - 0.7F) * 2F, 0.02F, 20, k % 2 == 0 ? 0xFFD28AFF : 0xFFFFFFFF, 1, 0);
                havePos[e[1]] = false;
                sound(SoundEvents.ENDERMAN_TELEPORT, 1.4F, 0.3F);
            }
            case EV_ZONE -> {
                float cx = MAP_X[s.map][e[1]] + MAP_W[s.map][e[1]] / 2F, cy = MAP_Y[s.map][e[1]];
                Ring rg = new Ring(); rg.x = cx; rg.y = cy - 4; rg.r = 3; rg.maxR = 24; rg.life = rg.max = 18; rg.col = 0xFFFFE27A; rings.add(rg);
                for (int k = 0; k < 10; k++) spawn(cx + (rnd.nextFloat() - 0.5F) * 30F, cy - 2, (rnd.nextFloat() - 0.5F) * 0.6F, -0.5F - rnd.nextFloat() * 1.1F, 0F, 26, 0xFFFFE27A, 1, 0);
                sound(SoundEvents.BELL_BLOCK, 1.6F, 0.4F);
            }
            case EV_RUNG -> {
                int id = e[1];
                tagT[id] = 70; tagTxt[id] = tr("cutemod.mayhem.w." + LADDER[Math.min(e[2], LADDER.length - 1)]);
                Ring rg = new Ring(); rg.x = rx[id]; rg.y = ry[id] - 6; rg.r = 2; rg.maxR = 16; rg.life = rg.max = 14; rg.col = LIGHT[col(id)]; rings.add(rg);
                pling(1.6F);
            }
            case EV_PASS -> {
                float x = e[3] / 16F, y = e[4] / 16F;
                Ring rg = new Ring(); rg.x = x; rg.y = y; rg.r = 2; rg.maxR = 14; rg.life = rg.max = 12; rg.col = 0xFFFF6A5A; rings.add(rg);
                for (int k = 0; k < 6; k++) spawn(x, y, (rnd.nextFloat() - 0.5F) * 1.8F, (rnd.nextFloat() - 0.7F) * 1.8F, 0.03F, 16, k % 2 == 0 ? 0xFFFF8A3D : 0xFFFFE27A, 1, 0);
                sound(SoundEvents.SLIME_SQUISH, 1.8F, 0.45F);
                tagT[e[2]] = 45; tagTxt[e[2]] = tr("cutemod.mayhem.bomb");
            }
            case EV_WAVE -> {
                if (e[2] == 2) say(tr("cutemod.mayhem.wave.clear"), 0xFF9BE87A, 100);
                else say(e[2] == 1 ? tr("cutemod.mayhem.wave.boss") : tr("cutemod.mayhem.wave.begin", e[1]), e[2] == 1 ? 0xFFFF6A5A : 0xFFFFE27A, 100);
                pling(e[2] == 1 ? 0.7F : 1.5F);
            }
            case EV_RELOAD -> {
                tagT[e[1]] = 40; tagTxt[e[1]] = tr("cutemod.mayhem.reload");
                sound(SoundEvents.STONE_BUTTON_CLICK_ON, 1.6F, 0.35F);
            }
            case EV_SLOW -> {
                int id = e[1];
                for (int k = 0; k < 6; k++) spawn(rx[id], ry[id] - 8, (rnd.nextFloat() - 0.5F) * 1.2F, -rnd.nextFloat() * 0.8F, 0.06F, 20, k % 2 == 0 ? 0xFF7CE04A : 0xFFD8FFB8, 1, 0);
                sound(SoundEvents.SLIME_SQUISH, 1.2F, 0.4F);
            }
            case EV_FREEZE -> sound(SoundEvents.GLASS_HIT, 1.2F, 0.5F);
            case EV_THAW -> puff(rx[e[1]], ry[e[1]] - 6, 6, 0xFFB8F0FF);
            case EV_LASER -> {
                Beam bm = new Beam(); bm.x1 = e[1] / 16F; bm.y = e[2] / 16F; bm.x2 = e[3] / 16F; bm.life = bm.max = 8; beams.add(bm);
            }
            case EV_EMPTY -> { tagT[e[1]] = 50; tagTxt[e[1]] = tr("cutemod.mayhem.empty"); }
            default -> { }
        }
    }

    private void tag(GuiGraphics g, Fighter f) {
        if (!f.alive) return;
        int id = f.id;
        int tx = Math.round(rx[id]) + ox, ty = Math.round(ry[id]) + oy;
        if (tagT[id] > 0) {
            int tyy = Math.max(21, ty - 26);
            float a = tagT[id] < 20 ? tagT[id] / 20F : 1F;
            ctext(g, tagTxt[id], tx + 1, tyy + 1, fade(0xFF000000, a * 0.8F));
            ctext(g, tagTxt[id], tx, tyy, fade(0xFFFFFFFF, a));
        } else if (mine(f)) {
            int c = LIGHT[col(id)];
            rect(g, tx - 2, ty - 19, 5, 1, c); rect(g, tx - 1, ty - 18, 3, 1, c); rect(g, tx, ty - 17, 1, 1, c);
        }
        MayhemSim tms = S();
        if (tagT[id] <= 0 && (tms.gameMode == MODE_TEAMS || tms.gameMode == MODE_WAVES)) {
            int tc = teamColor(tms.teamOf(id));
            rect(g, tx - 2, ty - 24, 5, 3, tc); rect(g, tx - 1, ty - 21, 3, 1, tc);
        }
        if (ry[id] < 0) {   // above the screen: a little arrow at the top edge
            int mx2 = Math.max(4, Math.min(W - 5, tx));
            rect(g, mx2, 1, 1, 1, BODY[col(id)]); rect(g, mx2 - 1, 2, 3, 1, BODY[col(id)]); rect(g, mx2 - 2, 3, 5, 1, BODY[col(id)]);
        }
    }

    // ------------------------------------------------------------------ drawing: the backdrops

    private static float sin(float v) { return (float) Math.sin(v); }

    private void cloud(GuiGraphics g, float x, float y, float s, int col, int shade) {
        for (int pass = 0; pass < 2; pass++) {
            int c = pass == 0 ? shade : col;
            int yy = (int) y + (pass == 0 ? 2 : 0);
            disc(g, (int) x, yy, Math.max(2, (int) (5 * s)), c);
            disc(g, (int) (x + 8 * s), yy - (int) (3 * s), Math.max(2, (int) (6 * s)), c);
            disc(g, (int) (x + 16 * s), yy, Math.max(2, (int) (5 * s)), c);
            rect(g, (int) x, yy, (int) (16 * s), Math.max(2, (int) (5 * s)), c);
        }
    }

    private void backdropClassic(GuiGraphics g) {
        int[][] sky = {{0xFF4A3F8F, 0xFFD8649A, 0xFFFFC08C}, {0xFF1C74BA, 0xFF2FAAD6, 0xFF8FE3E0}, {0xFF0C0E30, 0xFF282266, 0xFF5A4A9C}};
        int[] s = sky[theme];
        for (int yy = 0; yy < H; yy += 2) {
            float t = yy / (float) H;
            rect(g, 0, yy, W, 2, t < 0.55F ? mix(s[0], s[1], t / 0.55F) : mix(s[1], s[2], (t - 0.55F) / 0.45F));
        }
        float tt = ticks;
        if (theme == 0) {
            disc(g, 158, 88, 24, 0x18FFE0A0); disc(g, 158, 88, 19, 0x28FFD890); disc(g, 158, 88, 14, 0xFFFFF0B8);
            for (int k = 0; k < 4; k++) rect(g, 142, 92 + k * 3, 32, 1, 0x33E8708C);
            island(g, 30, 52, 26, 0xFF5B3F86, 0xFF8ED36A); island(g, 188, 30, 20, 0xFF6B4A94, 0xFF9BE07A);
            for (int i = 0; i < 4; i++) {
                float cx = ((i * 71 + tt * (0.06F + i * 0.025F)) % (W + 50)) - 25;
                cloud(g, cx, 16 + (i * 37) % 70, 1F + (i % 3) * 0.3F, 0xFFFFD6E2, 0xFFEAA6C6);
            }
            for (int i = 0; i < 3; i++) {
                float bx = ((tt * 0.35F + i * 90) % (W + 30)) - 15, by = 22 + i * 9 + sin(tt * 0.05F + i) * 3;
                int wing = ((int) (tt / 8) + i) % 2;
                rect(g, (int) bx, (int) by + wing, 2, 1, 0xFF5B3F86); rect(g, (int) bx + 2, (int) by, 2, 1, 0xFF5B3F86); rect(g, (int) bx + 4, (int) by + wing, 2, 1, 0xFF5B3F86);
            }
            seaOfClouds(g, tt, 0xFFB78AD4, 0xFFD9A8E0, 0xFFF2C4EA);
        } else if (theme == 1) {
            for (int k = 0; k < 4; k++) {
                int bx = 20 + k * 58;
                for (int yy = 0; yy < 118; yy += 2) rect(g, bx + (int) (yy * 0.35F + sin(tt * 0.01F + k) * 6), yy, 12 + k * 2, 2, 0x16FFFFFF);
            }
            for (int i = 0; i < 18; i++) {
                float bx = 6 + (i * 37) % 208 + sin(tt * 0.03F + i) * 3, by = H - ((tt * (0.25F + (i % 4) * 0.08F) + i * 23) % (H + 10));
                int r = 1 + i % 3 / 2;
                disc(g, (int) bx, (int) by, r, 0x44FFFFFF);
                rect(g, (int) bx - r + 1, (int) by - r + 1, 1, 1, 0xAAFFFFFF);
            }
            for (int i = 0; i < 5; i++) {
                float fx = ((tt * (0.4F + i * 0.05F) + i * 49) % (W + 40)) - 20, fy = 40 + i * 14 + sin(tt * 0.04F + i) * 2;
                rect(g, (int) fx, (int) fy, 4, 2, 0xFFFFB86B); rect(g, (int) fx + 4, (int) fy - 1, 1, 4, 0xFFFF8A5C); rect(g, (int) fx + 1, (int) fy, 1, 1, 0xFF2A2A4A);
            }
            // a purple octopus drifts at the bottom right
            float oxp = 176 + sin(tt * 0.015F) * 14, oyp = 108 + sin(tt * 0.03F) * 4;
            disc(g, (int) oxp, (int) oyp, 9, 0xFFA66BD6); disc(g, (int) oxp, (int) oyp - 3, 6, 0xFFB98AE4);
            rect(g, (int) oxp - 4, (int) oyp - 2, 3, 3, 0xFFFFFFFF); rect(g, (int) oxp + 2, (int) oyp - 2, 3, 3, 0xFFFFFFFF);
            rect(g, (int) oxp - 3, (int) oyp - 1, 1, 2, 0xFF2A1E4A); rect(g, (int) oxp + 3, (int) oyp - 1, 1, 2, 0xFF2A1E4A);
            for (int k = 0; k < 5; k++) for (int q = 0; q < 8; q++) rect(g, (int) (oxp - 8 + k * 4 + sin(tt * 0.08F + q * 0.7F + k) * 2), (int) oyp + 5 + q, 2, 1, q < 6 ? 0xFF8F55C4 : 0xFF7A44B0);
            // seabed with coral and kelp
            rect(g, 0, 124, W, 16, 0xFFE8D29A); rect(g, 0, 124, W, 2, 0xFFF6E8B8);
            for (int k = 0; k < 9; k++) {
                int kx = 8 + k * 26;
                int h = 12 + (k * 7) % 10;
                int c = k % 3 == 0 ? 0xFF3FAE6A : k % 3 == 1 ? 0xFFEF7BA6 : 0xFF9B6BD6;
                for (int q = 0; q < h; q++) rect(g, kx + (int) (sin(tt * 0.04F + q * 0.3F + k) * (q * 0.12F)), 124 - q, 3, 1, q % 4 == 3 ? mix(c, 0xFFFFFFFF, 0.25F) : c);
            }
        } else {
            for (int i = 0; i < 44; i++) {
                int sx = (i * 53 + 17) % W, sy = (i * 29 + 7) % 96;
                float tw = 0.5F + 0.5F * sin(tt * 0.05F + i * 1.7F);
                rect(g, sx, sy, 1, 1, fade(0xFFFFFFFF, 0.35F + 0.65F * tw));
                if (i % 9 == 0 && tw > 0.8F) { rect(g, sx - 1, sy, 3, 1, 0x88FFFFFF); rect(g, sx, sy - 1, 1, 3, 0x88FFFFFF); }
            }
            disc(g, 44, 36, 22, 0x14FFF6C8); disc(g, 44, 36, 17, 0x22FFF6C8); disc(g, 44, 36, 13, 0xFFF6F0CC);
            disc(g, 39, 32, 3, 0xFFE4DCAE); disc(g, 49, 41, 2, 0xFFE4DCAE); disc(g, 48, 29, 2, 0xFFE9E2B8);
            float ss = (tt % 420) / 420F;
            if (ss < 0.12F) { float k = ss / 0.12F; for (int q = 0; q < 10; q++) rect(g, (int) (150 - k * 90 + q * 2), (int) (10 + k * 40 - q), 1, 1, fade(0xFFFFFFFF, 1F - q / 10F)); }
            for (int i = 0; i < 3; i++) {
                float cx = ((i * 97 + tt * (0.05F + i * 0.02F)) % (W + 50)) - 25;
                cloud(g, cx, 30 + i * 22, 1.1F, 0xFF4A3F8F, 0xFF3A2F7A);
            }
            seaOfClouds(g, tt, 0xFF3A2F7A, 0xFF4F3F98, 0xFF6A58B4);
            for (int k = 0; k < 6; k++) rect(g, 30 + k * 2, 118 + k * 3, 28 - k * 4, 1, fade(0xFFFFF6C8, 0.18F + 0.1F * sin(tt * 0.05F + k)));
        }
    }

    private void island(GuiGraphics g, int cx, int y, int w, int rock, int grass) {
        for (int k = 0; k < 9; k++) rect(g, cx - w / 2 + k, y + k, w - 2 * k, 1, rock);
        rect(g, cx - w / 2, y - 2, w, 3, grass);
        rect(g, cx - 2, y - 7, 1, 5, 0xFF5B3F2B); disc(g, cx - 1, y - 9, 3, 0xFF4FB86A);
    }

    private void seaOfClouds(GuiGraphics g, float tt, int c0, int c1, int c2) {
        for (int row = 0; row < 3; row++) {
            int c = row == 0 ? c0 : row == 1 ? c1 : c2;
            int yy = 124 + row * 6;
            for (int i = 0; i < 12; i++) {
                float cx = ((i * 22 + tt * (0.05F + row * 0.03F)) % (W + 40)) - 10;
                disc(g, (int) cx, yy + (int) (sin(i + row) * 2), 8 - row, c);
            }
            rect(g, 0, yy + 4, W, 16, c);
        }
    }

    // ------------------------------------------------------------------ drawing: the stage

    private void stageMarble(GuiGraphics g) {
        final int[] PX = MAP_X[0], PY = MAP_Y[0], PW = MAP_W[0];
        // the columns that carry the big platform
        int bx = PX[0], by = PY[0], bw = PW[0];
        int[] cxs = {bx + 24, bx + 68, bx + bw - 68, bx + bw - 24};
        for (int cx : cxs) {
            R(g, cx - 5, by + 8, 11, 3, 0xFFF6F2E8); R(g, cx - 6, by + 8, 13, 1, 0xFFFFFFFF);
            R(g, cx - 3, by + 11, 7, 11, 0xFFE9E3D4);
            R(g, cx - 3, by + 11, 1, 11, 0xFFFFFFFF); R(g, cx - 1, by + 11, 1, 11, 0xFFD3CBB8); R(g, cx + 1, by + 11, 1, 11, 0xFFD3CBB8); R(g, cx + 3, by + 11, 1, 11, 0xFFC4BBA8);
            R(g, cx - 5, by + 22, 11, 3, 0xFFF0EBDD); R(g, cx - 6, by + 24, 13, 2, 0xFFD3CBB8);
        }
        for (int i = 0; i < PX.length; i++) {
            int x = PX[i], y = PY[i], w = PW[i];
            int th = i == 0 ? 5 : 3;
            R(g, x + 2, y + th + 3, w - 4, 1, 0x30000000);
            R(g, x, y, w, 1, 0xFFFFFFFF);
            R(g, x, y + 1, w, th, 0xFFF0EBDD);
            if (i == 0) for (int k = 6; k < w - 6; k += 6) { R(g, x + k, y + 2, 2, 3, 0xFFDCD4C2); }
            R(g, x, y + th + 1, w, 2, 0xFFC9C0AC);
            int r = i == 0 ? 4 : 3;
            for (int side = 0; side < 2; side++) {
                int cx = side == 0 ? x - 1 : x + w;
                D(g, cx, y + 3, r, 0xFFF0EBDD); D(g, cx, y + 3, r - 2, 0xFFD3CBB8); D(g, cx, y + 3, 1, 0xFFF6F2E8);
            }
            if (i > 0) {
                float gl = 0.5F + 0.5F * sin(ticks * 0.06F + i);
                for (int k = 0; k < 5; k++) R(g, x + 8 + k * (w - 16) / 4F, y + th + 4 + (k % 2) * 2, 1, 1, fade(0xFFFFFFFF, 0.3F + 0.5F * gl));
            }
        }
    }

    // ------------------------------------------------------------------ drawing: fighters, guns, crates

    private void gr(GuiGraphics g, float hx, float hy, int fc, int ox2, int oy2, int w, int h, int col) {
        R(g, fc > 0 ? hx + ox2 : hx - ox2 - w, hy + oy2, w, h, col);
    }

    private void gun(GuiGraphics g, float hx, float hy, int fc, int type) {
        switch (type) {
            case PISTOL -> {
                switch (pv) {
                    case 1 -> { gr(g, hx, hy, fc, 0, -2, 8, 3, 0xFFC0C8D8); gr(g, hx, hy, fc, 0, -2, 8, 1, 0xFFE8EEF8); gr(g, hx, hy, fc, 1, 1, 2, 3, 0xFF3A3F4F); gr(g, hx, hy, fc, 7, -1, 2, 1, 0xFF8890A0); }   // the eagle
                    case 2 -> { gr(g, hx, hy, fc, 0, -1, 6, 2, 0xFF2A2D38); gr(g, hx, hy, fc, 0, 1, 2, 3, 0xFF2A2D38); gr(g, hx, hy, fc, 2, -1, 1, 1, 0xFF6A6F82); }                                          // the viper
                    case 3 -> { gr(g, hx, hy, fc, 0, -1, 6, 2, 0xFFB8BCC8); gr(g, hx, hy, fc, 2, -2, 2, 3, 0xFF8A8E9A); gr(g, hx, hy, fc, 0, 1, 2, 3, 0xFF9A1E2E); }                                          // the ruby revolver
                    case 4 -> { gr(g, hx, hy, fc, 0, -1, 4, 2, 0xFFB0B4C0); gr(g, hx, hy, fc, 0, 1, 2, 2, 0xFF7A6A66); gr(g, hx, hy, fc, 3, -1, 1, 1, 0xFF6A6F82); }                                          // the mini
                    case 5 -> { gr(g, hx, hy, fc, 0, -1, 10, 2, 0xFF2E333F); gr(g, hx, hy, fc, 2, -2, 3, 3, 0xFF4A505E); gr(g, hx, hy, fc, 0, 1, 2, 3, 0xFFC8781E); gr(g, hx, hy, fc, 9, -1, 1, 1, 0xFF8890A0); }   // the cannon
                    case 6 -> { gr(g, hx, hy, fc, 0, -1, 6, 2, 0xFFFFD34D); gr(g, hx, hy, fc, 0, -1, 6, 1, 0xFFFFF0A0); gr(g, hx, hy, fc, 0, 1, 2, 3, 0xFF2A2D38); if (ticks / 6 % 4 == 0) gr(g, hx, hy, fc, 3, -2, 1, 1, 0xFFFFFFFF); }   // the golden one
                    default -> { gr(g, hx, hy, fc, 0, -1, 5, 2, GUN_MID); gr(g, hx, hy, fc, 0, 0, 2, 3, GUN_DARK); gr(g, hx, hy, fc, 4, -1, 2, 1, GUN_LIGHT); }                                              // the classic
                }
            }
            case SMG -> {
                gr(g, hx, hy, fc, -1, -1, 8, 3, GUN_DARK); gr(g, hx, hy, fc, 2, 2, 2, 3, GUN_MID); gr(g, hx, hy, fc, 7, 0, 2, 1, GUN_LIGHT); gr(g, hx, hy, fc, 1, -2, 3, 1, GUN_MID);
            }
            case SHOTGUN -> {
                gr(g, hx, hy, fc, -3, 0, 3, 2, WOOD); gr(g, hx, hy, fc, 0, -1, 10, 2, GUN_MID); gr(g, hx, hy, fc, 4, 1, 3, 1, WOOD); gr(g, hx, hy, fc, 9, -1, 2, 1, GUN_LIGHT);
            }
            case SNIPER -> {
                gr(g, hx, hy, fc, -3, 0, 4, 2, WOOD); gr(g, hx, hy, fc, 1, -1, 13, 2, GUN_DARK); gr(g, hx, hy, fc, 4, -3, 5, 2, 0xFF3AB6C8); gr(g, hx, hy, fc, 5, -3, 1, 1, 0xFFB8F4FF); gr(g, hx, hy, fc, 12, -1, 2, 1, GUN_LIGHT);
            }
            case GRENADE -> {
                gr(g, hx, hy, fc, -2, -1, 9, 3, GUN_DARK); gr(g, hx, hy, fc, 6, -2, 4, 5, 0xFF6B8F5A); gr(g, hx, hy, fc, 1, 2, 3, 3, GUN_MID); gr(g, hx, hy, fc, 7, -2, 1, 5, 0xFF8EB878); gr(g, hx, hy, fc, -1, 2, 2, 3, GUN_DARK);
            }
            case FLAME -> {
                gr(g, hx, hy, fc, -3, -1, 3, 4, 0xFFE8A33A); gr(g, hx, hy, fc, 0, -1, 8, 3, 0xFFB5483A); gr(g, hx, hy, fc, 7, -2, 3, 5, GUN_MID); gr(g, hx, hy, fc, 10, -1, 2, 3, ticks / 3 % 2 == 0 ? 0xFFFFE27A : 0xFFFF8A3D); gr(g, hx, hy, fc, 1, 2, 2, 3, GUN_DARK);
            }
            case LASER -> {
                gr(g, hx, hy, fc, 0, -1, 9, 3, 0xFFE8E8F8); gr(g, hx, hy, fc, 1, 0, 6, 1, 0xFFC77DFF); gr(g, hx, hy, fc, 8, -1, 3, 2, 0xFF7BE8FF); gr(g, hx, hy, fc, 1, 2, 2, 3, GUN_DARK); gr(g, hx, hy, fc, 3, -2, 3, 1, 0xFFB8B8D8);
            }
            case MINE -> {
                gr(g, hx, hy, fc, 0, -1, 7, 4, 0xFF8B94A8); gr(g, hx, hy, fc, 2, -2, 3, 1, 0xFFFF4A4A); gr(g, hx, hy, fc, 6, 0, 2, 2, GUN_DARK); gr(g, hx, hy, fc, 1, 3, 2, 2, GUN_DARK);
            }
            case ICE -> {
                gr(g, hx, hy, fc, 0, -1, 8, 3, 0xFF8AD8F0); gr(g, hx, hy, fc, 1, -1, 6, 1, 0xFFFFFFFF); gr(g, hx, hy, fc, 8, -2, 3, 4, 0xFFC8F4FF); gr(g, hx, hy, fc, 1, 2, 2, 3, GUN_DARK);
            }
            case BOOMER -> {
                gr(g, hx, hy, fc, 0, -2, 2, 6, 0xFFC8924F); gr(g, hx, hy, fc, 0, -2, 6, 2, 0xFFC8924F); gr(g, hx, hy, fc, 1, -1, 1, 1, 0xFFE8BC84); gr(g, hx, hy, fc, 5, -1, 1, 1, 0xFF8A5A33);
            }
            case TESLA -> {
                gr(g, hx, hy, fc, 0, -1, 8, 3, 0xFF4A4E78); gr(g, hx, hy, fc, 2, -2, 1, 5, 0xFF7BE8FF); gr(g, hx, hy, fc, 4, -2, 1, 5, 0xFF7BE8FF); gr(g, hx, hy, fc, 6, -2, 1, 5, 0xFF7BE8FF);
                gr(g, hx, hy, fc, 8, 0, 2, 1, 0xFFFFFFFF); if (ticks / 3 % 2 == 0) gr(g, hx, hy, fc, 10, -1, 1, 1, 0xFFB8F0FF); gr(g, hx, hy, fc, 1, 2, 2, 3, GUN_DARK);
            }
            case HARPOON -> {
                gr(g, hx, hy, fc, -2, 0, 8, 2, WOOD); gr(g, hx, hy, fc, 5, -3, 2, 8, GUN_MID); gr(g, hx, hy, fc, 4, -1, 8, 1, 0xFFE0E0F0); gr(g, hx, hy, fc, 11, -2, 1, 3, 0xFFFFFFFF);
            }
            case CLUSTER -> {
                gr(g, hx, hy, fc, -2, -1, 9, 3, 0xFFB5652A); gr(g, hx, hy, fc, 6, -2, 4, 5, 0xFFE8903A); gr(g, hx, hy, fc, 1, 2, 3, 3, GUN_MID); gr(g, hx, hy, fc, 7, -2, 1, 5, 0xFFFFC27A); gr(g, hx, hy, fc, -1, 2, 2, 3, GUN_DARK);
            }
            case SLIME -> {
                gr(g, hx, hy, fc, 0, -1, 7, 3, 0xFF58B83A); gr(g, hx, hy, fc, 2, -3, 4, 2, 0xFF8EE860); gr(g, hx, hy, fc, 7, -1, 2, 3, 0xFF3A8A28); gr(g, hx, hy, fc, 1, 2, 2, 3, GUN_DARK);
            }
            case SWAP -> {
                gr(g, hx, hy, fc, 0, -1, 6, 3, 0xFF7A4AC8); gr(g, hx, hy, fc, 6, -2, 3, 5, 0xFFD28AFF); gr(g, hx, hy, fc, 7, -1, 1, 3, 0xFFFFFFFF); gr(g, hx, hy, fc, 1, 2, 2, 3, GUN_DARK);
            }
            default -> {
                gr(g, hx, hy, fc, -2, -2, 11, 4, 0xFF5E7A3A); gr(g, hx, hy, fc, -2, -2, 11, 1, 0xFF86A857); gr(g, hx, hy, fc, 9, -2, 2, 4, 0xFFFF8A3D); gr(g, hx, hy, fc, 1, 2, 2, 3, GUN_DARK); gr(g, hx, hy, fc, 3, -3, 2, 1, GUN_MID);
            }
        }
    }

    private void fighter(GuiGraphics g, Fighter f, float x, float y, int shoot) {
        int id = f.id;
        int body = BODY[f.color], shade = SHADE[f.color], light = LIGHT[f.color];
        boolean white = f.flash > 0 && (f.flash & 1) == 0;
        if (white) { body = 0xFFFFFFFF; shade = 0xFFDDDDDD; light = 0xFFFFFFFF; }
        int fc = f.face;
        boolean air = !f.ground;
        boolean run = f.ground && Math.abs(f.vx) > 0.3F;
        int step = run ? (f.anim / 4) & 1 : 0;
        int br = (!air && !run && ((f.anim / 36) & 1) == 1) ? 1 : 0;
        if (f.invT > 0) D(g, x, y - 6, 10, fade(0xFFFFFFFF, 0.10F + 0.08F * sin(ticks * 0.3F)));
        if (f.wingsT > 0) {                                                   // wings on the back
            int flap = (f.anim / 5) & 1;
            float wx = fc > 0 ? x - 10 : x + 5;
            R(g, wx, y - 11 - flap, 5, 2, 0xFFFFFFFF); R(g, wx + (fc > 0 ? 1 : 0), y - 9 - flap, 4, 2, 0xFFE8F0FF); R(g, wx + (fc > 0 ? 2 : 0), y - 7 - flap, 3, 2, 0xFFD0DEFF);
        }
        if (f.boss) {                                                         // a boss of the waves: a big dark red aura
            D(g, x, y - 6, 13, fade(0xFFFF1A1A, 0.16F + 0.08F * sin(ticks * 0.25F)));
            D(g, x, y - 6, 10, fade(0xFFFF1A1A, 0.12F));
        }
        if (f.rageT > 0) {                                                    // a red aura with little flames
            D(g, x, y - 6, 10, fade(0xFFFF3A2A, 0.14F + 0.08F * sin(ticks * 0.4F)));
            int fl = (f.anim / 3) & 1;
            R(g, x - 3, y - 14 - fl, 1, 2, 0xFFFF8A3D); R(g, x + 3, y - 14 - (1 - fl), 1, 2, 0xFFFFC04A); R(g, x, y - 15 - fl, 1, 2, 0xFFFF5A2A);
        }
        if (f.speedT > 0 && Math.abs(f.vx) > 0.4F) {                          // speed lines behind
            int back = f.vx > 0 ? -1 : 1;
            for (int k = 0; k < 3; k++) R(g, x + back * (6 + k * 4) - (back < 0 ? 2 : 0), y - 9 + k * 3, 3, 1, fade(0xFFFFE27A, 0.6F - k * 0.15F));
        }
        // shadow of the fighter on the platform he stands on
        if (f.ground) R(g, x - 4, y, 9, 1, 0x28000000);
        int ly = air ? -3 : -2;
        R(g, x - 4, y + ly + (run && step == 1 ? -1 : 0), 3, 2, shade);
        R(g, x + 1, y + ly + (run && step == 0 ? -1 : 0), 3, 2, shade);
        R(g, x - 3, y - 11 + br, 7, 1, light);
        R(g, x - 4, y - 10 + br, 9, 7 - br, body);
        R(g, x - 3, y - 3, 7, 1, shade);
        R(g, fc > 0 ? x - 4 : x + 4, y - 10 + br, 1, 7 - br, shade);
        R(g, fc > 0 ? x + 1 : x - 3, y - 10 + br, 2, 1, light);
        // eyes
        int eyeY = Math.round(y) - 8 + br;
        float e1 = fc > 0 ? x - 1 : x - 3, e2 = fc > 0 ? x + 2 : x;
        boolean blink = (f.anim + id * 37) % 200 < 6, ouch = f.hitT > 3;
        if (ouch || blink) { R(g, e1, eyeY + 1, 2, 1, 0xFF2A2233); R(g, e2, eyeY + 1, 2, 1, 0xFF2A2233); }
        else {
            R(g, e1, eyeY, 2, 3, 0xFFFFFFFF); R(g, e2, eyeY, 2, 3, 0xFFFFFFFF);
            R(g, e1 + (fc > 0 ? 1 : 0), eyeY + 1, 1, 2, 0xFF2A2233); R(g, e2 + (fc > 0 ? 1 : 0), eyeY + 1, 1, 2, 0xFF2A2233);
        }
        R(g, fc > 0 ? x + 2 : x - 3, eyeY + 3, 2, 1, 0xAAFF8FB0);
        // the hat of the class of the fighter
        switch (f.cls) {
            case 0 -> { R(g, x - 4, y - 12 + br, 9, 3, 0xFF3A4660); R(g, x - 3, y - 13 + br, 7, 1, 0xFF3A4660); R(g, x - 2, y - 13 + br, 3, 1, 0xFF6A7A98); R(g, fc > 0 ? x + 1 : x - 4, y - 10 + br, 4, 1, 0xFF9FE0FF); }   // soldier: a helmet
            case 1 -> { R(g, x - 4, y - 10 + br, 9, 1, 0xFFFFFFFF); R(g, fc > 0 ? x - 7 : x + 4, y - 10 + br + (f.anim / 8 & 1), 3, 1, 0xFFFFFFFF); }          // scout: a headband
            case 2 -> { R(g, x - 6, y - 11 + br, 13, 1, 0xFF8A5A33); R(g, x - 3, y - 14 + br, 7, 3, 0xFFA8723F); R(g, x - 3, y - 12 + br, 7, 1, 0xFF5A3A1E); }   // gunslinger: a cowboy hat
            case 3 -> { R(g, x - 4, y - 12 + br, 9, 3, 0xFFF2C230); R(g, x - 3, y - 13 + br, 7, 1, 0xFFF2C230); R(g, x - 1, y - 12 + br, 3, 2, 0xFFFFFFFF); R(g, x, y - 12 + br, 1, 1, 0xFFFFF2A0); }   // demolition: a hard hat with a lamp
            default -> { R(g, x - 3, y - 13 + br, 7, 2, 0xFFFFD34D); R(g, x - 3, y - 14 + br, 1, 1, 0xFFFFD34D); R(g, x, y - 14 + br, 1, 1, 0xFFFFD34D); R(g, x + 3, y - 14 + br, 1, 1, 0xFFFFD34D); R(g, x, y - 12 + br, 1, 1, 0xFFE0394F); }   // gambler: a crown
        }
        // the gun and the hand that holds it
        int kick = shoot > 4 ? 2 : shoot > 0 ? 1 : 0;
        float hx = x + fc * (4 - kick), hy = y - 6 + (air ? -1 : 0);
        pv = f.pistol;
        gun(g, hx, hy, fc, f.weapon);
        R(g, hx - (fc > 0 ? 0 : 1), hy, 2, 2, body);
        if (f.slowT > 0) {                                                    // covered in slime
            R(g, x - 4, y - 10, 9, 7, 0x407CE04A);
            R(g, x - 3 + (f.anim / 6) % 7, y - 3 + (f.anim / 4) % 3, 1, 2, 0xFF7CE04A);
        }
        if (f.hasteT > 0 && (f.anim / 2 & 1) == 0) R(g, x + fc * (5 + f.anim % 6), y - 9 - (f.anim % 3), 1, 1, 0xFFFFE27A);
        if (f.frozenT > 0) {
            float a = f.frozenT < 15 ? f.frozenT / 15F : 1F;
            R(g, x - 6, y - 14, 13, 15, fade(0xAAB8F0FF, a)); R(g, x - 6, y - 14, 13, 1, fade(0xFFFFFFFF, a)); R(g, x - 6, y - 14, 1, 15, fade(0xCCFFFFFF, a));
            R(g, x + 2, y - 11, 2, 1, fade(0xFFFFFFFF, a)); R(g, x - 4, y - 5, 1, 2, fade(0xFFFFFFFF, a));
        }
        if (f.shieldT > 0 && (f.shieldT > 90 || (ticks / 4 & 1) == 0)) {      // the shield bubble
            float pl = 0.5F + 0.5F * sin(ticks * 0.2F);
            D(g, x, y - 6, 11, fade(0xFF6FD6FF, 0.12F + 0.06F * pl));
            for (int k = 0; k < 28; k++) {
                float an = k * 6.2832F / 28F;
                R(g, x + (float) Math.cos(an) * 11, y - 6 + (float) Math.sin(an) * 11, 1, 1, fade(0xFFB8F0FF, 0.75F));
            }
            R(g, x - 7, y - 13, 2, 1, 0xCCFFFFFF); R(g, x - 8, y - 12, 1, 2, 0xCCFFFFFF);
        }
    }

    private static int teamColor(int t) { return t == 0 ? 0xFF58A8FF : 0xFFFF6A5A; }

    /** The zone of the hill: a column of light over a platform. Yellow when it is free, the colour of the king when one holds it, red when it is fought for. */
    private void zone(GuiGraphics g, MayhemSim s) {
        float cx = s.zoneCx(), hw = s.zoneHalf();
        int y = MAP_Y[s.map][s.zonePlat], w = Math.round(hw * 2);
        int col = s.zoneOwner >= 0 ? BODY[s.f[s.zoneOwner].color] : s.zoneOwner == -2 ? 0xFFFF5A4A : 0xFFFFE27A;
        float pulse = 0.7F + 0.3F * sin(ticks * 0.1F);
        for (int k = 0; k < 30; k += 2) R(g, cx - hw, y - 30 + k, w, 2, fade(col, (0.07F + 0.25F * k / 30F) * pulse));
        R(g, cx - hw, y - 2, w, 2, fade(col, 0.95F));
        R(g, cx - hw, y - 32, w, 1, fade(col, 0.6F * pulse));
        R(g, cx - hw - 1, y - 8, 1, 8, col); R(g, cx + hw, y - 8, 1, 8, col);
        for (int k = 0; k < 4; k++) {                                          // sparks that rise
            float t = (ticks * 0.6F + k * 17) % 30F;
            R(g, cx - hw + 4 + (k * 37) % Math.max(1, w - 8), y - 2 - t, 1, 1, fade(0xFFFFFFFF, 1F - t / 30F));
        }
    }

    /** The bomb of the hot-bomb mode over the head of its carrier: it blinks faster and faster. */
    private void bomb(GuiGraphics g, float x, float y, int fuse) {
        boolean hot = fuse < 180 && (ticks / (fuse < 90 ? 3 : 6) & 1) == 0;
        D(g, x, y, 4, hot ? 0xFFFF4A3A : 0xFF2A2D38);
        D(g, x, y, 3, hot ? 0xFFFF8A5A : 0xFF3A3F4F);
        R(g, x - 2, y - 2, 2, 1, 0x88FFFFFF);
        R(g, x + 1, y - 6, 1, 2, 0xFF8A5A33);
        R(g, (ticks / 2 & 1) == 0 ? x + 1 : x, y - 8, 1, 1, (ticks / 2 & 1) == 0 ? 0xFFFFE27A : 0xFFFF8A3D);
    }

    private void icon(GuiGraphics g, float cx, float cy, String[] rows, int col) {
        for (int r = 0; r < 5; r++) for (int c = 0; c < 5; c++) if (rows[r].charAt(c) == '1') R(g, cx - 2 + c, cy - 2 + r, 1, 1, col);
    }

    private void line(GuiGraphics g, float x1, float y1, float x2, float y2, int col) {
        int n = Math.max(1, Math.min(120, (int) Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1))));
        for (int i = 0; i <= n; i++) R(g, x1 + (x2 - x1) * i / n, y1 + (y2 - y1) * i / n, 1, 1, col);
    }

    /** A bonus: a glowing orb with a picture of the gift. */
    private void bonusOrb(GuiGraphics g, Crate c) {
        if (c.landed && c.life < 120 && (ticks / 5 & 1) == 0) return;       // blinks before it is gone
        float cx = c.x, cy = c.y - 9 + sin(ticks * 0.08F + c.x) * 1.5F;
        int col = BONUS_C[c.weapon];
        float pulse = 0.5F + 0.5F * sin(ticks * 0.12F);
        R(g, c.x - 3, c.y - 1, 7, 1, 0x30000000);
        D(g, cx, cy, 10, fade(col, 0.10F + 0.08F * pulse));
        D(g, cx, cy, 8, fade(col, 0.22F));
        D(g, cx, cy, 6, col);
        D(g, cx, cy, 5, 0xFFFFFFFF);
        icon(g, cx, cy, BONUS_ICON[c.weapon], mix(col, 0xFF000000, 0.35F));
        for (int k = 0; k < 3; k++) {
            float a = ticks * 0.07F + k * 2.1F;
            R(g, cx + (float) Math.cos(a) * 10, cy + (float) Math.sin(a) * 10, 1, 1, fade(0xFFFFFFFF, 0.8F));
        }
    }

    private void crate(GuiGraphics g, Crate c) {
        if (c.kind == 1) { bonusOrb(g, c); return; }
        float bob = c.landed ? sin(ticks * 0.08F + c.x) * 1F : 0;
        if (!c.landed) {
            int bc = BALLOON[c.weapon];
            R(g, c.x, c.y - 17, 1, 9, 0x88FFFFFF);
            D(g, c.x, c.y - 24, 6, bc); D(g, c.x - 2, c.y - 26, 2, mix(bc, 0xFFFFFFFF, 0.55F));
            R(g, c.x - 2, c.y - 19, 5, 2, mix(bc, 0xFF000000, 0.25F));
        }
        R(g, c.x - 4, c.y - 8, 9, 8, 0xFFC98B3E);
        R(g, c.x - 4, c.y - 8, 9, 1, 0xFFE8B468); R(g, c.x - 4, c.y - 1, 9, 1, 0xFF8A5A2B);
        R(g, c.x - 4, c.y - 8, 1, 8, 0xFF8A5A2B); R(g, c.x + 4, c.y - 8, 1, 8, 0xFF8A5A2B);
        R(g, c.x, c.y - 8, 1, 8, 0xFFFFE08A); R(g, c.x - 4, c.y - 5, 9, 1, 0xFFFFE08A);
        if (c.landed && (c.life > 150 || (ticks / 6 & 1) == 0)) {
            R(g, c.x - 6, c.y - 17 + bob, 13, 8, 0x55000000);
            gun(g, c.x - (c.weapon == SNIPER ? 6 : 4), c.y - 13 + bob, 1, c.weapon);
        }
    }

    /** The perk "quacking bombs": a rubber duck instead of a grenade. */
    private void duck(GuiGraphics g, Bullet b, int s) {
        boolean small = b.type == MINIBOMB;
        R(g, b.x - 3, b.y - 1, small ? 5 : 6, small ? 3 : 4, 0xFFFFE04A);
        R(g, b.x - 3, b.y + (small ? 1 : 2), small ? 5 : 6, 1, 0xFFE0B020);
        R(g, b.x + (s > 0 ? 1 : -3), b.y - (small ? 3 : 4), small ? 2 : 3, small ? 2 : 3, 0xFFFFE04A);
        R(g, b.x + (s > 0 ? (small ? 3 : 4) : -4), b.y - (small ? 2 : 3), 2, 1, 0xFFFF8A2D);
        R(g, b.x + (s > 0 ? 2 : -2), b.y - (small ? 3 : 4) + 1, 1, 1, 0xFF2A2233);
        R(g, b.x - 2, b.y, 2, 1, 0xFFFFF2A0);
    }

    private void bullet(GuiGraphics g, Bullet b) {
        int s = sign(b.vx);
        if ((b.type == GRENADE || b.type == CLUSTER || b.type == MINIBOMB) && b.owner >= 0 && b.owner < N && S().f[b.owner].has(PERK_QUACKING)) { duck(g, b, s); return; }
        switch (b.type) {
            case SNIPER -> { R(g, b.x - s * 9, b.y, 10, 1, 0xFF7BE8FF); R(g, b.x - s * 4, b.y, 5, 1, 0xFFFFFFFF); R(g, b.x - s * 9, b.y - 1, 10, 3, 0x227BE8FF); }
            case SMG -> R(g, b.x - s * 2, b.y, 3, 1, 0xFFFFE27A);
            case BOOMER -> {
                int k = (ticks / 2) % 4;
                if (k % 2 == 0) { R(g, b.x - 3, b.y - 1, 6, 2, 0xFFC8924F); R(g, b.x - 1, b.y - 3, 2, 6, 0xFF8A5A33); }
                else { R(g, b.x - 3, b.y - 3, 2, 2, 0xFFC8924F); R(g, b.x + 1, b.y + 1, 2, 2, 0xFFC8924F); R(g, b.x + 1, b.y - 3, 2, 2, 0xFF8A5A33); R(g, b.x - 3, b.y + 1, 2, 2, 0xFF8A5A33); }
            }
            case HARPOON -> { R(g, b.x - s * 9, b.y, 10, 1, 0xFFE0E0F0); R(g, b.x + (s > 0 ? 0 : -2), b.y - 1, 2, 3, 0xFFFFFFFF); R(g, b.x - s * 9 - (s > 0 ? 0 : -1), b.y - 1, 2, 3, 0xFFC8924F); }
            case CLUSTER -> { R(g, b.x - 3, b.y - 3, 6, 6, 0xFFE8903A); R(g, b.x - 3, b.y - 3, 6, 1, 0xFFFFC27A); R(g, b.x - 3, b.y, 6, 1, 0xFF8A4A1A); if ((ticks / 4 & 1) == 0) R(g, b.x - 1, b.y - 4, 2, 1, 0xFFFF4A4A); }
            case MINIBOMB -> { R(g, b.x - 1, b.y - 1, 3, 3, 0xFF343949); if ((ticks / 3 & 1) == 0) R(g, b.x, b.y - 2, 1, 1, 0xFFFF4A4A); }
            case SLIME -> { D(g, b.x, b.y, 2, 0xFF7CE04A); R(g, b.x - 1, b.y - 1, 1, 1, 0xFFD8FFB8); R(g, b.x - s * 3, b.y + 1, 1, 2, 0xFF5CB83A); }
            case SWAP -> { D(g, b.x, b.y, 3, 0x55D28AFF); D(g, b.x, b.y, 2, (ticks / 3 & 1) == 0 ? 0xFFD28AFF : 0xFFFFFFFF); }
            case GRENADE -> { R(g, b.x - 2, b.y - 2, 4, 4, 0xFF4A6B4A); R(g, b.x - 2, b.y - 2, 4, 1, 0xFF8EB878); if ((ticks / 5 & 1) == 0) R(g, b.x - 1, b.y - 3, 2, 1, 0xFFFF4A4A); }
            case FLAME -> {
                float a = b.life / (float) LIFE[FLAME];
                int r = 1 + (int) ((1F - a) * 3F);
                D(g, b.x, b.y, r, a > 0.6F ? 0xFFFFE27A : a > 0.3F ? 0xCCFF9A3D : 0x88FF5A3D);
                if (r > 1) D(g, b.x, b.y, r - 1, a > 0.6F ? 0xFFFFFFFF : 0xAAFFD34D);
            }
            case ICE -> { R(g, b.x - 2, b.y - 1, 4, 3, 0xFFB8F0FF); R(g, b.x - 1, b.y, 2, 1, 0xFFFFFFFF); R(g, b.x - s * 4, b.y, 2, 1, 0x88B8F0FF); }
            case SHOTGUN -> { R(g, b.x, b.y, 1, 1, 0xFFFFB347); R(g, b.x - s, b.y, 1, 1, 0x88FFB347); }
            case ROCKET -> {
                R(g, b.x - 3, b.y - 1, 6, 3, 0xFF5E7A3A); R(g, b.x + (s > 0 ? 3 : -4), b.y - 1, 1, 3, 0xFFFF4A4A);
                R(g, b.x - (s > 0 ? 3 : -3), b.y - 2, 1, 5, 0xFFABB4CB);
            }
            default -> { R(g, b.x - s * 2, b.y, 4, 1, 0xFFFFD34D); R(g, b.x - s * 2, b.y - 1, 4, 3, 0x33FFD34D); }
        }
    }

    private void particles(GuiGraphics g) {
        for (Part p : parts) {
            float a = p.life / (float) p.max;
            switch (p.kind) {
                case 1 -> { int sz = p.size + (int) ((1F - a) * 2); R(g, p.x - sz / 2F, p.y - sz / 2F, sz, sz, fade(p.col, a * 0.7F)); }
                case 2 -> { D(g, p.x, p.y, p.size, fade(p.col, 0.5F + 0.5F * a)); if (p.size > 2) D(g, p.x, p.y, p.size - 2, 0xFFFFFFFF); }
                default -> R(g, p.x, p.y, p.size, p.size, fade(p.col, Math.min(1F, a * 1.6F)));
            }
        }
        for (Zap z : zaps) {
            float a = z.life / (float) z.max;
            float dx = z.x2 - z.x1, dy = z.y2 - z.y1;
            int n = Math.max(2, (int) (Math.sqrt(dx * dx + dy * dy) / 7F));
            float qx = z.x1, qy = z.y1;
            for (int k = 1; k <= n; k++) {
                float tx = z.x1 + dx * k / n, ty = z.y1 + dy * k / n;
                if (k < n) { tx += (ticks * 7 + k * 13) % 5 - 2; ty += (ticks * 11 + k * 17) % 5 - 2; }
                line(g, qx, qy + 1, tx, ty + 1, fade(0xFF4FA6EE, a * 0.5F));
                line(g, qx, qy, tx, ty, fade(0xFFE8FAFF, a));
                qx = tx; qy = ty;
            }
        }
        for (Beam bm : beams) {
            float a = bm.life / (float) bm.max;
            float x1 = Math.min(bm.x1, bm.x2), len = Math.abs(bm.x2 - bm.x1);
            R(g, x1, bm.y - 2, (int) len, 5, fade(0xFFC77DFF, a * 0.25F));
            R(g, x1, bm.y - 1, (int) len, 3, fade(0xFFE0B8FF, a * 0.7F));
            R(g, x1, bm.y, (int) len, 1, fade(0xFFFFFFFF, a));
        }
        for (Ring r : rings) {
            float a = r.life / (float) r.max;
            int n = Math.max(10, (int) (r.r * 3));
            for (int i = 0; i < n; i++) {
                float an = i * 6.2832F / n;
                R(g, r.x + (float) Math.cos(an) * r.r, r.y + (float) Math.sin(an) * r.r, 1, 1, fade(r.col, a));
            }
        }
    }


    private void hud(GuiGraphics g) {
        MayhemSim hs = S();
        for (int i = 0; i < N; i++) {
            Fighter f = hs.f[i];
            if (f.kind == KIND_OFF) continue;
            if (hs.gameMode == MODE_WAVES && f.kind == KIND_BOT) continue;                // the enemies have no panel
            int x = 4 + i * 54, y = 2;
            rect(g, x, y, 50, 17, f.out ? 0x66202020 : 0x88101030);
            rect(g, x, y, 50, 1, f.out ? 0xFF555555 : BODY[f.color]);
            if (hs.gameMode == MODE_TEAMS) rect(g, x + 43, y + 2, 5, 5, teamColor(hs.teamOf(i)));
            disc(g, x + 7, y + 8, 4, SHADE[f.color]); disc(g, x + 7, y + 8, 3, f.out ? 0xFF777777 : BODY[f.color]);
            rect(g, x + 7, y + 6, 1, 2, 0xFFFFFFFF); rect(g, x + 9, y + 6, 1, 2, 0xFFFFFFFF);
            if (f.out) { text(g, tr("cutemod.mayhem.out"), x + 14, y + 5, 0xFFAAAAAA); continue; }
            int bx = x + 2;
            int[] bt = {f.shieldT, f.speedT, f.wingsT, f.rageT, f.hasteT, f.slowT};
            int[] bmax = {BONUS_T[B_SHIELD], BONUS_T[B_SPEED], BONUS_T[B_WINGS], BONUS_T[B_RAGE], BONUS_T[B_HASTE], 240};
            int[] bcol = {BONUS_C[B_SHIELD], BONUS_C[B_SPEED], BONUS_C[B_WINGS], BONUS_C[B_RAGE], BONUS_C[B_HASTE], 0xFF7CE04A};
            for (int k = 0; k < 6; k++) {
                if (bt[k] <= 0) continue;
                rect(g, bx, y + 19, 6, 5, fade(bcol[k], 0.85F));
                rect(g, bx, y + 25, Math.max(1, 6 * Math.min(bt[k], bmax[k]) / bmax[k]), 1, 0xFFFFFFFF);
                bx += 8;
            }
            int dm = (int) f.dmg;
            text(g, dm + "%", x + 14, y + 1, mix(0xFFFFFFFF, 0xFFFF5A4A, Math.min(1F, dm / 150F)));
            for (int k = 0; k < (hs.gameMode == MODE_HILL || hs.gameMode == MODE_LADDER ? 0 : Math.min(f.lives, 5)); k++) {
                int hx = x + 14 + k * 5, hy = y + 11;
                int hc = !f.alive ? 0xFF8A4A5A : f.lives > 5 && k == 4 ? 0xFFFFD34D : 0xFFFF6B8A;
                rect(g, hx, hy, 1, 1, hc); rect(g, hx + 2, hy, 1, 1, hc); rect(g, hx, hy + 1, 3, 1, hc); rect(g, hx + 1, hy + 2, 1, 1, hc);
            }
            if (hs.gameMode == MODE_HILL) text(g, f.pts + "/" + HILL_TARGET, x + 14, y + 10, 0xFFFFE27A);
            else if (hs.gameMode == MODE_LADDER) text(g, (f.rung + 1) + "/" + LADDER.length, x + 14, y + 10, 0xFFFFE27A);
            pv = f.pistol;
            gun(g, x + (f.weapon == PISTOL ? 41 : 37), y + 11, 1, f.weapon);
            if (hs.gameMode != MODE_LADDER && !(f.weapon == PISTOL && f.has(PERK_INFINITE_PISTOL))) {
                String am = String.valueOf(f.ammo);
                text(g, am, x + 49 - tw(am), y + 1, f.reloadT > 0 ? 0xFFFF8A5A : 0xFFFFE27A);
            }
            if (f.reloadT > 0 && f.weapon == PISTOL) {
                int tot = P_RELOAD[f.pistol];
                rect(g, x + 14, y + 15, 34 * (tot - Math.min(tot, f.reloadT)) / tot, 1, 0xFFFFE27A);
            }
        }
    }


    private void button(GuiGraphics g, int x, int y, int w, int h, String s) {
        boolean hov = in(mx, my, x, y, w, h);
        rect(g, x, y, w, h, hov ? 0xCC3A3A8A : 0xAA202058);
        rect(g, x, y, w, 1, 0x55FFFFFF);
        ctextW(g, s, x + w / 2, y + 3, w - 6, 0xFFFFFFFF);
    }


    // ------------------------------------------------------------------ the maps: backdrops and platforms

    private static final int[] SKY_T = {0xFF4A3F8F, 0xFF4FA6EE, 0xFF0B1642, 0xFFFF8F5A, 0xFF05061A, 0xFFFFB8E0, 0xFF12060F};
    private static final int[] SKY_B = {0xFFFFC08C, 0xFFDDF3FF, 0xFF9CD0EE, 0xFFFFE8B5, 0xFF3A1E6E, 0xFFC8ECFF, 0xFFD8501E};
    private static final int[] PLAT_C = {0xFFF0EBDD, 0xFF6BCB5B, 0xFFCDEFFF, 0xFFC48A4E, 0xFF8FA0D0, 0xFFFF9EC8, 0xFF7A5C6A};

    private void sky(GuiGraphics g, int c0, int c1, int c2) {
        for (int yy = 0; yy < H; yy += 2) {
            float t = yy / (float) H;
            rect(g, 0, yy, W, 2, t < 0.55F ? mix(c0, c1, t / 0.55F) : mix(c1, c2, (t - 0.55F) / 0.45F));
        }
    }

    private void backdrop(GuiGraphics g) {
        switch (mapNow) {
            case 1 -> bgIslands(g);
            case 2 -> bgIce(g);
            case 3 -> bgCanyon(g);
            case 4 -> bgSpace(g);
            case 5 -> bgCandy(g);
            case 6 -> bgVolcano(g);
            default -> backdropClassic(g);
        }
    }

    private void bird(GuiGraphics g, float tt, int i, int col) {
        float bx = ((tt * 0.35F + i * 90) % (W + 30)) - 15, by = 22 + i * 9 + sin(tt * 0.05F + i) * 3;
        int wing = ((int) (tt / 8) + i) % 2;
        rect(g, (int) bx, (int) by + wing, 2, 1, col); rect(g, (int) bx + 2, (int) by, 2, 1, col); rect(g, (int) bx + 4, (int) by + wing, 2, 1, col);
    }

    private void bgIslands(GuiGraphics g) {
        float tt = ticks;
        sky(g, 0xFF4FA6EE, 0xFF8CCBF6, 0xFFDDF3FF);
        disc(g, 176, 30, 24, 0x1CFFFFCC); disc(g, 176, 30, 18, 0x30FFFFCC); disc(g, 176, 30, 12, 0xFFFFF5B8);
        island(g, 112, 66, 22, 0xFFBDD9F2, 0xFFCFEBEA);          // far away and pale: never mistaken for a platform
        island(g, 206, 40, 16, 0xFFBDD9F2, 0xFFCFEBEA);
        for (int i = 0; i < 5; i++) {
            float cx = ((i * 63 + tt * (0.05F + i * 0.02F)) % (W + 60)) - 30;
            cloud(g, cx, 12 + (i * 29) % 90, 1F + (i % 3) * 0.35F, 0xFFFFFFFF, 0xFFD6E8F8);
        }
        for (int i = 0; i < 3; i++) bird(g, tt, i, 0xFF3A5A8A);
        seaOfClouds(g, tt, 0xFFD8EAFF, 0xFFEAF4FF, 0xFFFFFFFF);
    }

    private void peak(GuiGraphics g, int cx, int base, int h, int w, int col, int cap) {
        for (int r = 0; r < h; r++) {
            int half = Math.max(1, (int) (w / 2F * (r + 1) / h));
            rect(g, cx - half, base - h + r, half * 2, 1, r < h / 4 ? cap : col);
        }
    }

    private void bgIce(GuiGraphics g) {
        float tt = ticks;
        sky(g, 0xFF0B1642, 0xFF2D5C9E, 0xFF9CD0EE);
        for (int i = 0; i < 34; i++) {
            float tw = 0.5F + 0.5F * sin(tt * 0.05F + i * 1.3F);
            rect(g, (i * 53 + 11) % W, (i * 31 + 5) % 70, 1, 1, fade(0xFFFFFFFF, 0.3F + 0.7F * tw));
        }
        for (int k = 0; k < 3; k++) {                                   // the northern lights
            int col = k == 1 ? 0xFFB070FF : 0xFF58F0A8;
            for (int x = 0; x < W; x += 4) {
                float y0 = 16 + k * 9 + sin(tt * 0.02F + x * 0.035F + k * 2F) * 9F;
                int hh = 21 + (int) (sin(tt * 0.015F + x * 0.05F + k) * 7F);
                for (int q = 0; q < 3; q++) rect(g, x, (int) y0 + q * hh / 3, 4, hh / 3 + 1, fade(col, 0.17F - q * 0.05F));
            }
        }
        peak(g, 28, 118, 62, 70, 0xFF35609C, 0xFFEAF6FF); peak(g, 96, 118, 82, 90, 0xFF35609C, 0xFFEAF6FF);
        peak(g, 164, 118, 70, 80, 0xFF35609C, 0xFFEAF6FF); peak(g, 214, 118, 56, 60, 0xFF35609C, 0xFFEAF6FF);
        peak(g, 6, 128, 56, 64, 0xFF244A80, 0xFFD8ECFA); peak(g, 66, 128, 46, 60, 0xFF244A80, 0xFFD8ECFA);
        peak(g, 132, 128, 62, 74, 0xFF244A80, 0xFFD8ECFA); peak(g, 192, 128, 50, 64, 0xFF244A80, 0xFFD8ECFA);
        rect(g, 0, 112, W, 12, 0x30E8F4FF);
        rect(g, 0, 124, W, 16, 0xFFE8F4FF); rect(g, 0, 124, W, 2, 0xFFFFFFFF);
        for (int i = 0; i < 44; i++) {                                  // snow
            float fx = (i * 37 + sin(tt * 0.02F + i) * 5F) % W, fy = (tt * (0.3F + (i % 3) * 0.12F) + i * 17) % H;
            rect(g, (int) fx, (int) fy, 1, 1, fade(0xFFFFFFFF, 0.55F + 0.4F * (i % 2)));
        }
    }

    private void mesa(GuiGraphics g, int x, int base, int w, int h, int col, int cap) {
        rect(g, x, base - h, w, h, col);
        rect(g, x - 2, base - h, w + 4, 4, cap);
        rect(g, x + w / 3, base - h + 8, 1, h - 8, mix(col, 0xFF000000, 0.15F));
    }

    private void bgCanyon(GuiGraphics g) {
        float tt = ticks;
        sky(g, 0xFFFF8F5A, 0xFFFFC27A, 0xFFFFE8B5);
        disc(g, 62, 88, 28, 0x1CFFF0B0); disc(g, 62, 88, 21, 0x30FFF0B0); disc(g, 62, 88, 15, 0xFFFFF2B8);
        mesa(g, 8, 124, 46, 50, 0xFFE0875A, 0xFFEFA070); mesa(g, 84, 124, 38, 36, 0xFFE0875A, 0xFFEFA070); mesa(g, 150, 124, 56, 56, 0xFFE0875A, 0xFFEFA070);
        mesa(g, -8, 140, 56, 58, 0xFFB65034, 0xFFC86644); mesa(g, 98, 140, 66, 40, 0xFFB65034, 0xFFC86644); mesa(g, 184, 140, 52, 64, 0xFFB65034, 0xFFC86644);
        for (int yy = 114; yy < H; yy += 2) rect(g, 0, yy, W, 2, fade(mix(0xFF8A3A28, 0xFF2A1010, (yy - 114) / 26F), 0.92F));
        for (int i = 0; i < 16; i++) {                                  // dust in the wind
            float dx = (i * 41 + tt * (0.25F + (i % 3) * 0.1F)) % (W + 20) - 10, dy = 20 + (i * 23) % 90 + sin(tt * 0.03F + i) * 3F;
            rect(g, (int) dx, (int) dy, 1, 1, 0x88FFE8C0);
        }
        for (int i = 0; i < 2; i++) bird(g, tt * 0.8F, i, 0xFF5A2A1A);
    }

    private void bgSpace(GuiGraphics g) {
        float tt = ticks;
        sky(g, 0xFF05061A, 0xFF1A1048, 0xFF3A1E6E);
        disc(g, 60, 44, 28, 0x16FF70C8); disc(g, 82, 56, 22, 0x14A070FF); disc(g, 150, 100, 30, 0x1440D0FF); disc(g, 190, 70, 20, 0x12FF9AA0);
        for (int i = 0; i < 64; i++) {
            int col = i % 3 == 0 ? 0xFFB8D8FF : i % 3 == 1 ? 0xFFFFFFFF : 0xFFFFE8A8;
            float tw = 0.45F + 0.55F * sin(tt * 0.04F + i * 1.7F);
            rect(g, (i * 47 + 13) % W, (i * 37 + 3) % H, 1, 1, fade(col, 0.3F + 0.7F * tw));
        }
        // a planet with a ring
        for (int a = 0; a < 120; a++) {
            float an = a * 6.2832F / 120F;
            if (Math.sin(an) < 0) rect(g, 168 + (int) (Math.cos(an) * 30), 36 + (int) (Math.sin(an) * 7), 1, 1, 0xAAC8A878);
        }
        disc(g, 168, 36, 17, 0xFFD9885B);
        for (int dy = -14; dy <= 14; dy += 6) {
            int half = (int) Math.sqrt(17 * 17 - dy * dy);
            rect(g, 168 - half, 36 + dy, half * 2, 2, 0xFFC46E48);
        }
        disc(g, 162, 30, 5, 0x26FFFFFF);
        for (int a = 0; a < 120; a++) {
            float an = a * 6.2832F / 120F;
            if (Math.sin(an) >= 0) rect(g, 168 + (int) (Math.cos(an) * 30), 36 + (int) (Math.sin(an) * 7), 1, 1, 0xFFF2D8A8);
        }
        disc(g, 30, 100, 7, 0xFFB8B8CC); disc(g, 28, 98, 2, 0xFF9898AC); disc(g, 33, 103, 1, 0xFF9898AC);
        // a far station
        rect(g, 96, 22, 28, 3, 0xFF4A4E78); rect(g, 106, 14, 8, 20, 0xFF5A5E88); rect(g, 92, 18, 6, 11, 0xFF3A6AA8); rect(g, 122, 18, 6, 11, 0xFF3A6AA8);
        if ((ticks / 20 & 1) == 0) rect(g, 109, 12, 2, 2, 0xFFFF5A5A);
        float ss = (tt % 500) / 500F;
        if (ss < 0.1F) { float k = ss / 0.1F; for (int q = 0; q < 10; q++) rect(g, (int) (190 - k * 120 + q * 2), (int) (8 + k * 40 - q), 1, 1, fade(0xFFFFFFFF, 1F - q / 10F)); }
    }

    private void lollipop(GuiGraphics g, int x, int y, int r, int col) {
        rect(g, x - 1, y + r - 2, 3, 46, 0xFFFFFFFF);
        for (int q = 0; q < 46; q += 6) rect(g, x - 1, y + r + q, 3, 3, 0xFFFF9EC8);
        disc(g, x, y, r + 1, mix(col, 0xFF000000, 0.15F));
        disc(g, x, y, r, col);
        for (int rr = r - 3; rr > 1; rr -= 3) disc(g, x, y, rr, ((r - rr) / 3) % 2 == 0 ? 0xFFFFFFFF : col);
    }

    private void bgCandy(GuiGraphics g) {
        float tt = ticks;
        sky(g, 0xFFFFB8E0, 0xFFFFD8F0, 0xFFC8ECFF);
        lollipop(g, 36, 56 + (int) (sin(tt * 0.02F) * 2F), 16, 0xFFFF6FA8);
        lollipop(g, 190, 46 + (int) (sin(tt * 0.025F + 1F) * 2F), 13, 0xFF58C8F0);
        lollipop(g, 112, 36 + (int) (sin(tt * 0.03F + 2F) * 2F), 10, 0xFFFFD34D);
        for (int i = 0; i < 4; i++) {
            float cx = ((i * 71 + tt * (0.05F + i * 0.02F)) % (W + 50)) - 25;
            if (i % 2 == 0) cloud(g, cx, 18 + (i * 31) % 70, 1.1F, 0xFFFFE6F4, 0xFFF8C4E4);
            else cloud(g, cx, 18 + (i * 31) % 70, 1.0F, 0xFFE4F4FF, 0xFFBCDCF4);
        }
        int[] sc = {0xFFFF5A8A, 0xFFFFD34D, 0xFF58C8F0, 0xFF8ED36A, 0xFFFFFFFF};
        for (int i = 0; i < 26; i++) {                                  // sprinkles fall
            float fx = (i * 43 + sin(tt * 0.02F + i) * 6F) % W, fy = (tt * (0.25F + (i % 3) * 0.1F) + i * 19) % H;
            rect(g, (int) fx, (int) fy, (i & 1) == 0 ? 2 : 1, (i & 1) == 0 ? 1 : 2, sc[i % 5]);
        }
        for (int x = 0; x < W; x += 2) {                                // frosting waves
            int wy = 124 + (int) (sin(x * 0.12F + tt * 0.03F) * 2F);
            rect(g, x, wy, 2, H - wy, 0xFFFF9EC8);
            rect(g, x, wy, 2, 1, 0xFFFFD0E6);
        }
        for (int k = 0; k < 6; k++) { disc(g, 20 + k * 38, 131, 3, 0xFFE0394F); rect(g, 20 + k * 38, 124, 1, 4, 0xFF4F8A3A); }
    }

    private void bgVolcano(GuiGraphics g) {
        float tt = ticks;
        sky(g, 0xFF12060F, 0xFF4A1426, 0xFFD8501E);
        for (int i = 0; i < 14; i++) rect(g, (i * 61 + 7) % W, (i * 23 + 3) % 40, 1, 1, fade(0xFFFFFFFF, 0.25F + 0.3F * (i % 2)));
        peak(g, 28, 124, 44, 76, 0xFF2A1218, 0xFF2A1218); peak(g, 196, 124, 50, 84, 0xFF2A1218, 0xFF2A1218);
        disc(g, 110, 62, 30, 0x20FF8A2D);
        for (int r = 0; r < 60; r++) {
            int half = 10 + (int) (r * 1.3F);
            rect(g, 110 - half, 62 + r, half * 2, 1, r < 3 ? 0xFF4A2226 : 0xFF2A1218);
        }
        rect(g, 99, 61, 22, 3, 0xFFFF8A2D); rect(g, 102, 60, 16, 1, 0xFFFFD34D);
        for (int r = 0; r < 52; r++) {                                  // a river of lava down the side
            int lx = 110 + (int) (sin(r * 0.22F) * 5F) + r / 4;
            rect(g, lx, 64 + r, 3, 1, fade(mix(0xFFFF6A1E, 0xFFFFC04A, 0.5F + 0.5F * sin(tt * 0.06F - r * 0.3F)), 0.95F));
        }
        for (int i = 0; i < 7; i++) {                                   // smoke
            float t = (tt * 0.3F + i * 14) % 70F;
            disc(g, 110 + (int) (sin(i + t * 0.05F) * 8F) + (int) (t * 0.2F), 58 - (int) t, 4 + (int) (t * 0.08F), fade(0xFF3A2A34, 0.6F * (1F - t / 70F)));
        }
        for (int i = 0; i < 30; i++) {                                  // embers
            float ex = (i * 53 + sin(tt * 0.03F + i) * 6F) % W, ey = H - ((tt * (0.35F + (i % 3) * 0.2F) + i * 19) % H);
            rect(g, (int) ex, (int) ey, 1, 1, fade(i % 2 == 0 ? 0xFFFFB347 : 0xFFFF6A3D, 0.85F * (ey / H)));
        }
        rect(g, 0, 108, W, 14, 0x24FF6A1E);
        for (int yy = 122; yy < H; yy += 2) rect(g, 0, yy, W, 2, mix(0xFFFF5A1E, 0xFFFFC04A, (yy - 122) / 18F));
        for (int x = 0; x < W; x += 4) rect(g, x, 121 + (int) (sin(tt * 0.05F + x * 0.1F) * 1.5F), 4, 1, 0xFFFFE08A);
        for (int i = 0; i < 4; i++) {
            float t = (tt * 0.4F + i * 17) % 20F;
            if (t < 6F) disc(g, 20 + i * 55 + (int) (sin(i * 3F) * 10F), 128 - (int) t, 1 + (int) (t / 3F), 0xFFFFE08A);
        }
    }

    /** All platforms of the map in play, in the style of the map. */
    private void stage(GuiGraphics g) {
        if (mapNow == 0) { stageMarble(g); return; }
        int m = mapNow;
        for (int i = 0; i < MAP_X[m].length; i++) {
            int x = MAP_X[m][i], y = MAP_Y[m][i], w = MAP_W[m][i];
            switch (m) {
                case 1 -> {                                              // grass islands
                    R(g, x, y, w, 1, 0xFFA8EE8A); R(g, x, y + 1, w, 2, 0xFF6BCB5B); R(g, x, y + 3, w, 3, 0xFF8A5A33); R(g, x, y + 3, w, 1, 0xFF9E6A3B);
                    for (int k = 0; k < 9; k++) {
                        int inset = Math.min(k * 2, w / 2 - 3);
                        if (w - 2 * inset < 4) break;
                        R(g, x + inset, y + 6 + k, w - 2 * inset, 1, k % 3 == 2 ? 0xFF7A7388 : 0xFF8E879C);
                    }
                    for (int k = 6; k < w - 4; k += 9) { R(g, x + k, y - 2, 1, 2, 0xFF4FB84A); R(g, x + k + 3, y - 1, 1, 1, (k / 9 + i) % 2 == 0 ? 0xFFFF8AB8 : 0xFFFFE27A); }
                    for (int k = 8; k < w - 6; k += 17) R(g, x + k, y + 6, 1, 5 + (k % 4), 0xFF4FB84A);
                }
                case 2 -> {                                              // ice
                    R(g, x, y, w, 1, 0xFFFFFFFF); R(g, x, y + 1, w, 4, 0xFFCDEFFF); R(g, x, y + 5, w, 2, 0xFF8CC8E8);
                    for (int k = 3; k < w - 5; k += 11) R(g, x + k, y - 1, 5, 1, 0xFFFFFFFF);
                    for (int k = 4; k < w - 3; k += 7) { int h = 2 + (k * 5) % 4; R(g, x + k, y + 7, 2, h, 0xFFA8DCF4); R(g, x + k, y + 7 + h, 1, 1, 0xFFA8DCF4); }
                    R(g, x + w / 3, y + 2, 1, 3, 0xFF9BD4EE);
                    R(g, x + (ticks / 2 + i * 13) % (w + 10) - 5, y + 1, 3, 1, 0xAAFFFFFF);
                }
                case 3 -> {
                    if (i == 0) {                                        // the wooden bridge
                        R(g, x, y, w, 3, 0xFFC48A4E); R(g, x, y, w, 1, 0xFFE0A868); R(g, x, y + 3, w, 2, 0xFF8A5A2B);
                        for (int k = 0; k < w; k += 7) R(g, x + k, y, 1, 3, 0xFF8A5A2B);
                        R(g, x, y - 8, w, 1, 0xFFD6B77A);
                        for (int k = 0; k <= w; k += 34) R(g, x + Math.min(k, w - 2), y - 10, 2, 11, 0xFF6B4423);
                        for (int k = 0; k < w; k += 3) R(g, x + k, y + 5 + (int) (Math.sin(k * 0.05F) * 2F + 2F), 3, 1, 0xFFD6B77A);
                    } else {                                             // red rock
                        R(g, x, y, w, 2, 0xFFE89A5C); R(g, x, y + 2, w, 4, 0xFFC9683A);
                        for (int k = 0; k < 9; k++) {
                            int inset = Math.min(k * 2, w / 2 - 3);
                            if (w - 2 * inset < 4) break;
                            R(g, x + inset, y + 6 + k, w - 2 * inset, 1, k % 2 == 0 ? 0xFFA84E2C : 0xFF8A3A24);
                        }
                        if (i == 1) { R(g, x + w / 2, y - 7, 2, 7, 0xFF4FA060); R(g, x + w / 2 - 2, y - 5, 2, 1, 0xFF4FA060); R(g, x + w / 2 - 2, y - 7, 1, 3, 0xFF4FA060); }
                    }
                }
                case 4 -> {                                              // metal plates with lights
                    R(g, x, y, w, 1, 0xFF9FB4E8); R(g, x, y + 1, w, 4, 0xFF4A5478); R(g, x, y + 5, w, 1, 0xFF2C3452);
                    for (int k = 3; k < w - 2; k += 8) R(g, x + k, y + 2, 1, 1, 0xFFC8D4FF);
                    R(g, x - 1, y, 2, 6, 0xFF2C3452); R(g, x + w - 1, y, 2, 6, 0xFF2C3452);
                    float pulse = 0.5F + 0.5F * sin(ticks * 0.08F + i);
                    R(g, x + 4, y + 6, w - 8, 1, fade(0xFF4FD6FF, 0.5F + 0.5F * pulse)); R(g, x + 4, y + 7, w - 8, 2, fade(0xFF4FD6FF, 0.12F + 0.1F * pulse));
                    if (w > 50) R(g, x + w / 2 - 1, y + 7, 2, 2 + (ticks / 2) % 3, 0xFFFFC04A);
                }
                case 5 -> {                                              // cakes with frosting
                    R(g, x, y + 2, w, 5, 0xFFF2C38A); R(g, x, y + 6, w, 1, 0xFFD39A5E);
                    R(g, x, y, w, 3, 0xFFFF9EC8); R(g, x, y, w, 1, 0xFFFFD0E6);
                    int[] sc = {0xFFFF5A8A, 0xFFFFD34D, 0xFF58C8F0, 0xFF8ED36A, 0xFFFFFFFF};
                    for (int k = 3; k < w - 3; k += 9) R(g, x + k, y + 3, 3, 2 + (k * 7) % 3, 0xFFFF9EC8);
                    for (int k = 2; k < w - 3; k += 6) R(g, x + k, y + 1, 2, 1, sc[(k / 6 + i) % 5]);
                    if (w < 40) { D(g, x + w / 2, y - 2, 2, 0xFFE0394F); R(g, x + w / 2, y - 6, 1, 3, 0xFF4F8A3A); }
                }
                default -> {                                             // basalt with lava cracks
                    R(g, x, y, w, 1, 0xFF7A5C6A); R(g, x, y + 1, w, 3, 0xFF4A3440);
                    for (int k = 0; k < 8; k++) {
                        int inset = Math.min(k * 2, w / 2 - 3);
                        if (w - 2 * inset < 4) break;
                        R(g, x + inset, y + 4 + k, w - 2 * inset, 1, k % 2 == 0 ? 0xFF2E2028 : 0xFF3A2A34);
                    }
                    for (int k = 0; k < w - 8; k += 13) {
                        float pulse = 0.5F + 0.5F * sin(ticks * 0.07F + k + i);
                        R(g, x + 6 + k, y + 2, 1, 2, fade(0xFFFF8A2D, 0.6F + 0.4F * pulse));
                        R(g, x + 7 + k, y + 5, 1, 3, fade(0xFFFF6A1E, 0.3F + 0.6F * pulse));
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ the screens

    @Override
    public void render(GuiGraphics g) {
        ox = 0; oy = 0;
        theme = screen == PLAY ? S().theme : menuTheme;
        if (screen == PLAY) mapNow = S().map;
        else {
            int sel = screen == ROOM ? MayhemNet.map : mapSel;
            mapNow = sel < MAPS ? sel : (ticks / 360) % MAPS;       // "random": the maps change one after another
        }
        switch (screen) {
            case MENU -> renderMenu(g);
            case ROOMS -> renderRooms(g);
            case ROOM -> renderRoom(g);
            case LOADOUT -> renderLoadout(g);
            default -> renderPlay(g);
        }
        if (noticeT > 0 && screen != PLAY) {
            rect(g, 25, H - 20, 170, 14, 0xFFFFE9A8);
            ctextW(g, tr(noticeKey), W / 2, H - 17, 162, 0xFF3A2A10);
        }
    }

    private void renderPlay(GuiGraphics g) {
        MayhemSim s = S();
        backdrop(g);
        hud(g);
        if (shake > 0) { int m = Math.min(4, shake / 2 + 1); ox = rnd.nextInt(m * 2 + 1) - m; oy = rnd.nextInt(m * 2 + 1) - m; }
        stage(g);
        if (s.gameMode == MODE_HILL) zone(g, s);
        for (Crate c : s.crates) crate(g, c);
        for (Mine m : s.mines) {
            R(g, m.x - 4, m.y - 3, 8, 3, 0xFF8B94A8); R(g, m.x - 3, m.y - 4, 6, 1, 0xFF6A7186); R(g, m.x - 4, m.y - 1, 8, 1, 0xFF5A6176);
            boolean on = m.arm <= 0 ? (ticks / 8 & 1) == 0 : (ticks / 3 & 1) == 0;
            R(g, m.x - 1, m.y - 5, 2, 1, on ? 0xFFFF4A4A : 0xFF7A2A2A); R(g, m.x, m.y - 5, 1, 1, on ? 0xFFFFB0B0 : 0xFF7A2A2A);
        }
        for (Fighter f : s.f) if (f.kind != KIND_OFF && f.alive) fighter(g, f, rx[f.id], ry[f.id], shootAnim[f.id]);
        if (s.gameMode == MODE_BOMB && s.holder >= 0 && s.f[s.holder].alive) bomb(g, rx[s.holder], ry[s.holder] - 25, s.fuse);
        int age = online ? Math.min(snapAge, 5) : 0;
        for (Bullet b : s.bullets) {
            float bx = b.x, by = b.y;
            b.x += b.vx * age; b.y += b.vy * age;
            bullet(g, b);
            b.x = bx; b.y = by;
        }
        particles(g);
        for (Fighter f : s.f) if (f.kind != KIND_OFF) tag(g, f);
        ox = 0; oy = 0;
        if (s.phase == PH_PLAY && (s.gameMode == MODE_HILL || s.gameMode == MODE_LADDER)) {
            int sec = Math.max(0, s.timeLeft / 60);
            ctextW(g, sec / 60 + ":" + (sec % 60 < 10 ? "0" : "") + sec % 60, 110, 21, 40, 0xFFFFFFFF);
        }
        if (s.gameMode == MODE_WAVES && s.phase != PH_COUNT) {
            int left = s.waveLeft;
            for (Fighter e : s.f) if (e.kind == KIND_BOT && !e.out) left++;
            ctextW(g, tr("cutemod.mayhem.wavehud", Math.max(1, s.wave), WAVES_TO_WIN, left), 110, 21, 150, 0xFFFFE27A);
        }
        if (s.phase == PH_COUNT) {
            int n = Math.min(3, s.phaseT / 50 + 1);
            big(g, String.valueOf(n), 110, 44, 4F, 0xFFFFFFFF);
            ctextW(g, tr("cutemod.mayhem.ready"), 110, 24, 160, 0xFFFFE27A);
            ctextW(g, tr("cutemod.mayhem.mode." + s.gameMode), 110, 92, 200, 0xFFFFE27A);
            ctextW(g, tr("cutemod.mayhem.mode." + s.gameMode + ".d"), 110, 102, 214, 0xFFFFFFFF);
        } else if (bannerT > 0 && !banner.isEmpty()) {
            float k = s.phase == PH_END ? 2.4F : banner.equals(tr("cutemod.mayhem.fight")) ? (bannerT > 30 ? 3F : 2F) : 1.6F;
            if (bannerT < 12) k *= 0.8F + bannerT / 60F;
            big(g, banner, 110, s.phase == PH_END ? 48 : 40, k, bannerCol);
        }
    }

    private void dim(GuiGraphics g, boolean arena) {
        backdrop(g);
        rect(g, 0, 0, W, H, arena ? 0x66101030 : 0x88101030);
    }

    private void card(GuiGraphics g, int i, int x, int y, boolean hov, boolean showFighter, int[] ld) {
        int color = ld[0];
        rect(g, x, y, 49, 50, hov ? 0xAA2A2A66 : 0x88101030);
        rect(g, x, y, 49, 2, BODY[color]);
        rect(g, x, y, 1, 50, fade(BODY[color], 0.5F)); rect(g, x + 48, y, 1, 50, fade(BODY[color], 0.5F));
        if (showFighter) {
            Fighter p = preview[i];
            p.color = color; p.cls = ld[1]; p.pistol = ld[2]; p.perks = CLASS_PERKS[p.cls];
            p.face = i < 2 ? 1 : -1; p.ground = true; p.vx = 0; p.anim = ticks + i * 20; p.weapon = PISTOL;
            p.invT = 0; p.flash = 0; p.hitT = 0; p.frozenT = 0;
            int t = (ticks + i * 25) % 90;
            fighter(g, p, x + 24, y + 33, t < 6 ? 6 - t : 0);
        }
    }

    private void pencil(GuiGraphics g, int x, int y, boolean hov) {
        rect(g, x - 1, y - 1, 11, 10, hov ? 0xCC3A3A8A : 0x88202058);
        int c = hov ? 0xFFFFFFFF : 0xFFC8C8E8;
        for (int k = 0; k < 6; k++) rect(g, x + 2 + k, y + 6 - k, 2, 1, c);
        rect(g, x + 1, y + 7, 2, 1, 0xFFFFE27A);
    }

    /** A little picture of a map: its sky and its platforms. m = RANDOM_MAP draws a question mark. */
    private void thumb(GuiGraphics g, int m, int x, int y, int w, int h, boolean sel) {
        boolean hov = in(mx, my, x, y, w, h);
        if (m >= MAPS) {
            rect(g, x, y, w, h, 0xFF2A2A5C);
            ctextW(g, "?", x + w / 2, y + (h - 8) / 2 + 1, w, 0xFFFFE27A);
        } else {
            for (int r = 0; r < h; r++) rect(g, x, y + r, w, 1, mix(SKY_T[m], SKY_B[m], r / (float) (h - 1)));
            for (int i = 0; i < MAP_X[m].length; i++) {
                int px = x + MAP_X[m][i] * w / 220, py = y + MAP_Y[m][i] * h / 140, pw = Math.max(2, MAP_W[m][i] * w / 220);
                rect(g, px, py, pw, 1, PLAT_C[m]);
                rect(g, px, py + 1, pw, 1, 0x55000000);
            }
        }
        int bc = sel ? 0xFFFFE27A : hov ? 0xFFFFFFFF : 0x66FFFFFF;
        rect(g, x - 1, y - 1, w + 2, 1, bc); rect(g, x - 1, y + h, w + 2, 1, bc);
        rect(g, x - 1, y, 1, h, bc); rect(g, x + w, y, 1, h, bc);
        if (sel) { rect(g, x - 2, y - 2, w + 4, 1, bc); rect(g, x - 2, y + h + 1, w + 4, 1, bc); }
    }

    /** The row of the maps (the last one is "a different one every round"). */
    private void mapRow(GuiGraphics g, int y, int selected) {
        for (int m = 0; m <= MAPS; m++) thumb(g, m, 7 + m * 26, y, 24, 16, m == selected);
        String name = tr("cutemod.mayhem.map." + (selected < 0 || selected > MAPS ? MAPS : selected));
        ctextW(g, name, W / 2, y + 19, 210, 0xFFFFFFFF);
    }

    private void renderMenu(GuiGraphics g) {
        dim(g, true);
        ctextW(g, tr("cutemod.game.mayhem"), 111, 4, 200, 0xAA000000);
        ctextW(g, tr("cutemod.game.mayhem"), 110, 3, 200, 0xFFFFE27A);
        ctextW(g, tr("cutemod.mayhem.mode." + modeSel + ".d"), 110, 13, 214, 0xFFFFFFFF);
        for (int i = 0; i < N; i++) {
            int cx = 8 + i * 53;
            card(g, i, cx, 24, in(mx, my, cx, 24, 49, 50), true, LD[i]);
            pencil(g, cx + 38, 27, in(mx, my, cx + 37, 26, 11, 10));
            int m = mode[i];
            String lab = m == 1 ? tr("cutemod.mayhem.p1") : m == 2 ? tr("cutemod.mayhem.p2") : tr(modeSel == MODE_WAVES ? "cutemod.mayhem.enemy" : "cutemod.mayhem.bot");
            ctextW(g, lab, cx + 24, 62, 45, m == 0 ? 0xFFC8C8E8 : LIGHT[LD[i][0]]);
            ctextW(g, tr("cutemod.mayhem.class." + LD[i][1]), cx + 20, 28, 34, 0xFFFFFFFF);
            if (modeSel == MODE_TEAMS) rect(g, cx + 3, 24 + 46, 43, 2, teamColor(i / 2));
        }
        mapRow(g, 76, mapSel);
        button(g, 8, 105, 100, 12, tr("cutemod.mayhem.mode", tr("cutemod.mayhem.mode." + modeSel)));
        button(g, 110, 105, 44, 12, modeSel == MODE_HILL || modeSel == MODE_LADDER ? "-" : tr("cutemod.mayhem.lives", lives));
        button(g, 156, 105, 56, 12, tr("cutemod.mayhem.skill", tr("cutemod.mayhem.skill." + skill)));
        boolean hs = in(mx, my, 8, 122, 100, 14);
        rect(g, 8, 122, 100, 14, hs ? 0xFFFFE27A : 0xFFF2B33D);
        rect(g, 8, 134, 100, 2, 0xFFC48A1E);
        ctextW(g, tr("cutemod.mayhem.start"), 58, 125, 90, 0xFF3A2A0A);
        boolean ho = in(mx, my, 112, 122, 100, 14);
        rect(g, 112, 122, 100, 14, ho ? 0xFFB5F0C0 : 0xFF86D69A);
        rect(g, 112, 134, 100, 2, 0xFF4FA066);
        ctextW(g, tr("cutemod.mayhem.online"), 162, 125, 90, 0xFF123A20);
    }

    private void renderRooms(GuiGraphics g) {
        dim(g, false);
        button(g, 4, 4, 30, 12, "<");
        ctextW(g, tr("cutemod.mayhem.rooms"), 88, 6, 100, 0xFFFFE27A);
        button(g, 140, 3, 76, 14, tr("cutemod.mayhem.create"));
        int rows = Math.min(MayhemNet.hosts.size(), 5);
        if (rows == 0) {
            ctextW(g, tr("cutemod.mayhem.rooms.none"), W / 2, 62, W - 24, 0xFFC9BEE8);
            return;
        }
        for (int i = 0; i < rows; i++) {
            int y = 24 + i * 20;
            boolean hover = in(mx, my, 8, y, 204, 18);
            rect(g, 8, y, 204, 18, hover ? 0xCC3A3A8A : 0xAA202058);
            disc(g, 18, y + 9, 5, SHADE[i % 4]); disc(g, 18, y + 9, 4, BODY[i % 4]);
            rect(g, 17, y + 7, 1, 2, 0xFFFFFFFF); rect(g, 20, y + 7, 1, 2, 0xFFFFFFFF);
            String host = MayhemNet.hosts.get(i);
            ctextW(g, host, 28 + Math.min(tw(host), 90) / 2, y + 5, 90, 0xFFFFFFFF);
            String free = tr("cutemod.mayhem.free", MayhemNet.open.get(i));
            text(g, free, 150 - tw(free), y + 5, 0xFFD6CBF2);
            rect(g, 156, y + 3, 50, 12, 0xFFFFD866);
            ctextW(g, tr("cutemod.mayhem.join"), 181, y + 5, 44, 0xFF3A2A10);
        }
    }

    private void chip(GuiGraphics g, int x, int y, int w, int h, String s, boolean on) {
        boolean hov = in(mx, my, x, y, w, h);
        rect(g, x, y, w, h, on ? 0xFFFFD866 : hov ? 0xCC3A3A8A : 0xAA202058);
        ctextW(g, s, x + w / 2, y + (h - 8) / 2 + 1, w - 4, on ? 0xFF3A2A10 : 0xFFE8E0FF);
    }

    private void renderRoom(GuiGraphics g) {
        dim(g, false);
        button(g, 4, 4, 38, 12, tr("cutemod.mayhem.leave"));
        ctextW(g, tr("cutemod.mayhem.room", MayhemNet.slotName[0]), 96, 6, 100, 0xFFFFE27A);
        button(g, 150, 3, 66, 12, tr("cutemod.mayhem.myfighter"));
        boolean overSlot = false;
        for (int i = 0; i < N; i++) {
            int x = 8 + i * 53, y = 18, t = MayhemNet.slotType[i];
            boolean click = MayhemNet.youHost && i > 0, hov = click && in(mx, my, x, y, 49, 50);
            overSlot |= hov;
            int packed = MayhemNet.slotLoad[i];
            int[] ld = packed >= 0 ? new int[]{packed & 15, (packed >> 4) & 15, (packed >> 8) & 15} : new int[]{i, i % CLASSES, 0};
            if (i == MayhemNet.mySlot && t == 3) ld = MY;
            card(g, i, x, y, hov, t == 2 || t == 3, ld);
            if (t != 2 && t != 3) {
                disc(g, x + 24, y + 22, 9, 0x30FFFFFF);
                ctextW(g, t == 1 ? "?" : "-", x + 24, y + 18, 20, 0xFFC9BEE8);
            }
            String label = t == 3 ? MayhemNet.slotName[i] : tr("cutemod.mayhem.slot." + t);
            ctextW(g, label, x + 24, y + 39, 45, t == 3 ? 0xFFFFFFFF : 0xFFD6CBF2);
            if (i == 0) text(g, "*", x + 41, y + 4, 0xFFFFE27A);
        }
        if (overSlot) {                                                      // the hint takes the place of the name of the map
            for (int m = 0; m <= MAPS; m++) thumb(g, m, 7 + m * 26, 72, 24, 16, m == MayhemNet.map);
            ctextW(g, tr("cutemod.mayhem.slot_hint"), W / 2, 91, 214, 0xFFC9BEE8);
        } else mapRowAt(g, 72, MayhemNet.map);
        for (int i = 0; i < MODES; i++) chip(g, 7 + i * 35, 100, 33, 11, tr("cutemod.mayhem.mode.s." + i), MayhemNet.gameMode == i);
        if (MayhemNet.youHost) {
            text(g, tr("cutemod.mayhem.bots_label"), 4, 113, 0xFFE8E0FF);
            for (int i = 0; i < 3; i++) chip(g, 32 + i * 31, 112, 29, 11, tr("cutemod.mayhem.skill." + i), MayhemNet.level == i);
            text(g, tr("cutemod.mayhem.lives_label"), 127, 113, 0xFFE8E0FF);
            int[] lv = {2, 3, 5};
            for (int i = 0; i < 3; i++) chip(g, 160 + i * 19, 112, 17, 11, Integer.toString(lv[i]), MayhemNet.lives == lv[i]);
            button(g, 40, 125, 140, 12, tr("cutemod.mayhem.start"));
        } else {
            ctextW(g, tr("cutemod.mayhem.skill_is", tr("cutemod.mayhem.skill." + MayhemNet.level)) + "   " + tr("cutemod.mayhem.lives_is", MayhemNet.lives), W / 2, 114, 214, 0xFFC9BEE8);
            ctextW(g, tr("cutemod.mayhem.wait"), W / 2, 126, 200, 0xFFC9BEE8);
        }
    }

    // ------------------------------------------------------------------ the screen of a fighter: colour, class, pistol

    /** The bars of a pistol, 0..1: how hard it hits, how fast it fires, how much it holds, how much it kicks. */
    private static float[] pistolBars(int p) {
        float power = P_DMG[p] / 13.5F;
        float rate = 1F - (P_CD[p] - 9F) / 39F * 0.85F;
        float mag = P_MAG[p] / 18F;
        float recoil = P_REC[p] / 1.1F;
        return new float[]{Math.max(0.08F, Math.min(1F, power)), Math.max(0.08F, Math.min(1F, rate)), Math.max(0.08F, Math.min(1F, mag)), Math.max(0.08F, Math.min(1F, recoil))};
    }

    /** The colours that the other fighters of the match or of the room have. */
    private boolean colorTaken(int c) {
        for (int j = 0; j < N; j++) {
            if (j == editSlot) continue;
            if (editOnline) { int l = MayhemNet.slotLoad[j]; if (MayhemNet.slotType[j] == 3 && l >= 0 && (l & 15) == c) return true; }
            else if (LD[j][0] == c) return true;
        }
        return false;
    }

    private void openEditor(boolean onlineEdit, int slot) {
        editOnline = onlineEdit; editSlot = slot;
        editLd = onlineEdit ? MY : LD[slot];
        screen = LOADOUT;
        pling(1.2F);
    }

    private void closeEditor() {
        if (editOnline) { MayhemNet.setLoad(packLd(MY)); screen = ROOM; }
        else screen = MENU;
        pling(0.8F);
    }

    private void edited() {
        if (editOnline) MayhemNet.setLoad(packLd(MY));
    }

    private void renderLoadout(GuiGraphics g) {
        dim(g, false);
        button(g, 4, 3, 26, 12, "<");
        ctextW(g, tr("cutemod.mayhem.loadout"), 100, 5, 130, 0xFFFFE27A);
        button(g, 186, 3, 30, 12, "?");
        for (int c = 0; c < COLORS; c++) {                                   // colours
            int x = 7 + c * 21;
            boolean taken = colorTaken(c), sel = editLd[0] == c;
            rect(g, x, 19, 19, 9, BODY[c]); rect(g, x, 26, 19, 2, SHADE[c]);
            if (taken) { rect(g, x, 19, 19, 9, 0xAA101030); rect(g, x + 8, 21, 3, 5, 0xFFFFFFFF); }
            int bc = sel ? 0xFFFFE27A : in(mx, my, x, 19, 19, 9) && !taken ? 0xFFFFFFFF : 0x00000000;
            if (bc != 0) { rect(g, x - 1, 18, 21, 1, bc); rect(g, x - 1, 28, 21, 1, bc); rect(g, x - 1, 19, 1, 9, bc); rect(g, x + 19, 19, 1, 9, bc); }
        }
        for (int k = 0; k < CLASSES; k++) chip(g, 7 + k * 42, 31, 40, 12, tr("cutemod.mayhem.class." + k), editLd[1] == k);
        int ly = 46;                                                         // the perks of the class
        for (int b = 0; b < PERKS; b++) {
            if ((CLASS_PERKS[editLd[1]] & (1 << b)) == 0) continue;
            String line = tr("cutemod.mayhem.perk." + b) + " - " + tr("cutemod.mayhem.perk." + b + ".d");
            rect(g, 8, ly + 3, 2, 2, 0xFFFFE27A);
            text(g, clip(line, 200), 13, ly, 0xFFE8E0FF);
            ly += 9;
        }
        for (int k = 0; k < PISTOLS; k++) {                                  // the pistols
            int x = 7 + k * 30;
            boolean sel = editLd[2] == k, hov = in(mx, my, x, 76, 28, 17);
            rect(g, x, 76, 28, 17, sel ? 0xFFFFD866 : hov ? 0xCC3A3A8A : 0xAA202058);
            g.pose().pushPose();
            g.pose().scale(2F, 2F, 1F);
            pv = k;
            gun(g, (x + 8) / 2F, 85F / 2F, 1, PISTOL);
            g.pose().popPose();
        }
        int pi = editLd[2];
        text(g, tr("cutemod.mayhem.pistol." + pi), 8, 96, 0xFFFFE27A);
        float[] bars = pistolBars(pi);
        for (int k = 0; k < 4; k++) {
            int y = 105 + k * 8;
            text(g, tr("cutemod.mayhem.stat." + k), 8, y, 0xFFE8E0FF);
            rect(g, 70, y + 2, 80, 5, 0xFF2A2A44);
            rect(g, 70, y + 2, Math.round(80 * bars[k]), 5, k == 3 ? 0xFFFF8A5A : 0xFF8ED36A);
            rect(g, 70, y + 2, Math.round(80 * bars[k]), 1, 0x55FFFFFF);
        }
        Fighter p = editPreview;                                             // the fighter, big
        p.color = editLd[0]; p.cls = editLd[1]; p.pistol = editLd[2]; p.perks = CLASS_PERKS[p.cls];
        p.face = 1; p.ground = true; p.vx = 0; p.anim = ticks; p.weapon = PISTOL; p.invT = 0; p.flash = 0; p.hitT = 0; p.frozenT = 0;
        rect(g, 160, 97, 54, 40, 0x66101030);
        g.pose().pushPose();
        g.pose().scale(2F, 2F, 1F);
        int t = ticks % 90;
        fighter(g, p, 187 / 2F, 131 / 2F, t < 6 ? 6 - t : 0);
        g.pose().popPose();
    }

    private boolean loadoutClick(int x, int y) {
        if (in(x, y, 4, 3, 26, 12)) { closeEditor(); return true; }
        if (in(x, y, 186, 3, 30, 12)) {                                       // a random kit
            int c = rnd.nextInt(COLORS);
            for (int k = 0; k < COLORS && colorTaken(c); k++) c = (c + 1) % COLORS;
            editLd[0] = c; editLd[1] = rnd.nextInt(CLASSES); editLd[2] = rnd.nextInt(PISTOLS);
            edited(); pling(1.4F);
            return true;
        }
        for (int c = 0; c < COLORS; c++) {
            if (in(x, y, 7 + c * 21, 19, 19, 9) && !colorTaken(c)) { editLd[0] = c; edited(); beep(); return true; }
        }
        for (int k = 0; k < CLASSES; k++) {
            if (in(x, y, 7 + k * 42, 31, 40, 12)) { editLd[1] = k; edited(); beep(); return true; }
        }
        for (int k = 0; k < PISTOLS; k++) {
            if (in(x, y, 7 + k * 30, 76, 28, 17)) { editLd[2] = k; edited(); beep(); return true; }
        }
        return true;
    }

    private void mapRowAt(GuiGraphics g, int y, int selected) { mapRow(g, y, selected); }

    // ------------------------------------------------------------------ the rest of the MiniGame contract

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        MayhemSim s = S();
        if (s.gameMode == MODE_WAVES) return s.winTeam == 0 ? Component.translatable("cutemod.mayhem.wavesWon") : Component.translatable("cutemod.mayhem.wavesLost", s.wave);
        if (s.gameMode == MODE_TEAMS) {
            if (s.winTeam < 0) return Component.translatable("cutemod.mayhem.draw");
            if (s.winTeam == s.teamOf(me())) return Component.translatable("cutemod.mayhem.victory");
            return Component.translatable("cutemod.mayhem.teamwins", tr("cutemod.mayhem.team." + s.winTeam));
        }
        if (s.winner < 0) return Component.translatable("cutemod.mayhem.draw");
        if (s.winner == me()) return Component.translatable("cutemod.mayhem.victory");
        return Component.translatable("cutemod.mayhem.winner", colorName(s.f[s.winner].color));
    }

    @Override
    public Component status() {
        if (screen != PLAY) return Component.translatable("cutemod.ui.score", score);
        MayhemSim ss = S();
        Fighter m = ss.f[me()];
        if (ss.gameMode == MODE_HILL) return Component.translatable("cutemod.mayhem.status.hill", m.pts);
        if (ss.gameMode == MODE_LADDER) return Component.translatable("cutemod.mayhem.status.ladder", m.rung + 1, LADDER.length);
        if (ss.gameMode == MODE_WAVES) return Component.translatable("cutemod.mayhem.status.waves", Math.max(1, ss.wave));
        return Component.translatable("cutemod.mayhem.status", m.kills, Math.max(0, m.lives));
    }

    @Override
    public String hintKey() { return "cutemod.hint.mayhem"; }
}
