package dev.cutemod.client.os;

import dev.cutemod.data.PcHardware;
import dev.cutemod.item.ModItems;
import dev.cutemod.market.Catalog;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * CuteTech: the electronics store. Laptops, memory, video cards, drives, Wi-Fi routers, portable players, headphones and
 * cases of the players, in one dark "tech" shop (CuteMarket stays the shop of food, gear and materials). It uses the same
 * courier as CuteMarket: the same orders, the same parcels, the same cart rules, so a parcel is collected in either shop.
 */
public class TechApp extends App {

    @Override
    public boolean needsNet() { return true; }

    private static final int HEAD = 22, SIDE_W = 64, PAGE = 6;
    private static final int BG = 0xFF11142A, PANEL = 0xFF181C3A, CARD = 0xFF1F2447, CARD_HOT = 0xFF2A3160, EDGE = 0xFF2E3566;
    private static final int INK = 0xFFE8ECFF, MUTED = 0xFF8E96C8, CYAN = 0xFF4CE0F0, VIOLET = 0xFF9B7BFF;
    private static final int GREEN = 0xFF4CD97B, RED = 0xFFFF6B7A, GOLD = 0xFFFFD36B;

    private static final int CATS = 8, CAT_Y = 27, CAT_PITCH = 17, CAT_H = 15;
    private static final int GRID_X = 70, GRID_Y = 27, CARD_W = 111, CARD_H = 38, COL_PITCH = 114, ROW_PITCH = 41;
    private static final int CART_X = 204, ORD_X = 254;

    // category -> the shop kind and the id prefix of what it shows
    private static final int[] CAT_KIND = {Catalog.LAPTOP, Catalog.PART, Catalog.PART, Catalog.PART, Catalog.PART, Catalog.PLAYER, Catalog.PLAYER, Catalog.PLAYER};
    private static final String[] CAT_PREFIX = {"laptop_", "pc_ram_", "pc_gpu_", "pc_disk_", "wifi_router_", Catalog.PLAYER_BASE, Catalog.HEADPHONES, Catalog.CASE_BASE};

    private int tab, cat, page, scroll;
    private boolean express;
    private final Map<String, Integer> cart = new LinkedHashMap<>();

    @Override
    public Component title() { return Component.translatable("cutemod.os.tech"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.tech"); }

    @Override
    public Component status() {
        int a = Market.active();
        return a > 0 ? Component.translatable("cutemod.market.status", a) : Component.empty();
    }

    @Override
    public void tick() { Market.tick(); }

    private int cartCount() {
        int n = 0;
        for (int v : cart.values()) n += v;
        return n;
    }

    // ---------- helpers ----------
    private static void txt(GuiGraphics g, String s, int x, int y, int argb) { Skin.str(g, font(), s, x, y, argb, false); }

    private static void rtxt(GuiGraphics g, String s, int rx, int y, int argb) { Skin.str(g, font(), s, rx - font().width(s), y, argb, false); }

    private static void btn(GuiGraphics g, int x, int y, int w, int h, String label, boolean enabled, boolean hover, int color) {
        Font f = font();
        App.roundRect(g, x, y, w, h, 4, !enabled ? 0xFF3A3F66 : hover ? mix(color, 0xFFFFFF, 0.25f) : color);
        Skin.str(g, f, label, x + (w - f.width(label)) / 2, y + (h - 8) / 2 + 1, enabled ? 0xFF10132A : 0xFF7A80AA, false);
    }

    /** A card: a faint glow, a thin border and the fill. */
    private static void card(GuiGraphics g, int x, int y, int w, int h, int fill, int border) {
        App.roundRect(g, x, y + 1, w, h, 4, 0x33000000);
        App.roundRect(g, x, y, w, h, 4, border);
        App.roundRect(g, x + 1, y + 1, w - 2, h - 2, 3, fill);
    }

    private static final Map<String, ItemStack> STACKS = new HashMap<>();

    /** The real item behind a catalog id (for its icon); empty while no world is loaded. */
    private static ItemStack stack(String id) {
        ItemStack st = STACKS.get(id);
        if (st != null) return st;
        var level = net.minecraft.client.Minecraft.getInstance().level;
        if (level == null) return ItemStack.EMPTY;
        st = Catalog.create(id, level.registryAccess());
        STACKS.put(id, st);
        return st;
    }

    /** The picture of an item: the item itself, scaled, on a soft round plate. */
    private static void icon(GuiGraphics g, String id, int x, int y, float s) {
        int size = Math.round(16 * s);
        App.roundRect(g, x - 2, y - 2, size + 4, size + 4, 5, 0x33000000);
        ItemStack st = stack(id);
        if (st.isEmpty()) return;
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(s, s, 1f);
        g.renderItem(st, 0, 0);
        g.pose().popPose();
    }

    private static String name(String id) { return MarketApp.name(id); }

    /** What is in a category, in shop order (the prices already include today's sales). */
    private static List<Market.Item> list(int c) {
        List<Market.Item> out = new ArrayList<>();
        String prefix = CAT_PREFIX[c];
        for (Market.Item it : Market.items(CAT_KIND[c])) {
            if (!it.id().startsWith(prefix)) continue;
            if (c == 5 && it.id().startsWith(Catalog.CASE_BASE)) continue;      // "player_case_" does not start with "music_player", but be safe
            out.add(it);
        }
        return out;
    }

    /** The grey line under a product: what it is (the same words as in CuteMarket for the parts). */
    private static String sub(Market.Item it) {
        if (it.kind() == Catalog.PART) return t("cutemod.market.part." + it.id());
        if (it.kind() == Catalog.LAPTOP) return t("cutemod.tech.sub.laptop");
        if (it.id().startsWith(Catalog.HEADPHONES)) return t("cutemod.market.sub.headphones");
        if (it.id().startsWith(Catalog.CASE_BASE)) return t("cutemod.tech.sub.case");
        return t("cutemod.tech.sub.player");
    }

    /** For a part of this PC: 1 = it is already in (or better), 2 = it would be an upgrade, 0 = not a part of the PC (router...). */
    private static int partState(String id) {
        int[] info = ModItems.partInfo(id);
        if (info == null) return 0;
        PcSpecs.Spec s = PcSpecs.get();
        int have = switch (PcHardware.Kind.values()[info[0]]) {
            case RAM -> s.ramIdx();
            case GPU -> s.gpuTier();
            case DISK -> s.diskIdx();
            default -> -1;
        };
        return info[1] <= have ? 1 : 2;
    }

    private static void pill(GuiGraphics g, int x, int y, String s, int fill, int ink) {
        Font f = font();
        App.roundRect(g, x, y, f.width(s) + 6, 9, 4, fill);
        Skin.str(g, f, s, x + 3, y + 1, ink, false);
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        Skin.rect(g, 0, 0, W, H, BG);
        // header: a deep blue gradient with a thin neon edge and the name of the shop
        Skin.grad(g, 0, 0, W, HEAD, 0xFF232A5C, 0xFF171B3E);
        Skin.rect(g, 0, HEAD - 1, W, 1, 0x664CE0F0);
        Skin.rect(g, 7, 6, 3, 10, CYAN);
        Skin.str(g, f, "CuteTech", 14, 4, INK, false);
        Skin.str(g, f, t("cutemod.tech.tagline"), 14, 13, MUTED, false);
        navPill(g, mx, my, CART_X, 48, t("cutemod.market.nav.cart"), cartCount(), tab == 1);
        navPill(g, mx, my, ORD_X, 44, t("cutemod.market.nav.orders"), Market.active(), tab == 2);
        switch (tab) {
            case 0 -> renderShop(g, mx, my);
            case 1 -> renderCart(g, mx, my);
            default -> renderOrders(g, mx, my);
        }
    }

    private static void navPill(GuiGraphics g, int mx, int my, int x, int w, String label, int n, boolean sel) {
        Font f = font();
        boolean hov = in(mx, my, x, 5, w, 13);
        App.roundRect(g, x, 5, w, 13, 6, sel ? CYAN : hov ? 0x554CE0F0 : 0x334CE0F0);
        Skin.boxC(g, f, label, x + 2, 8, sel ? 0xFF10132A : INK, false, w - 4);
        if (n > 0) {
            String q = n > 9 ? "9+" : Integer.toString(n);
            int bw = Math.max(9, f.width(q) + 4);
            App.roundRect(g, x + w - bw + 3, 1, bw, 9, 4, RED);
            Skin.str(g, f, q, x + w - bw + 3 + (bw - f.width(q)) / 2, 2, 0xFFFFFFFF, false);
        }
    }

    private void renderShop(GuiGraphics g, int mx, int my) {
        Font f = font();
        // the side panel with the categories
        Skin.rect(g, 0, HEAD, SIDE_W, H - HEAD, PANEL);
        Skin.rect(g, SIDE_W - 1, HEAD, 1, H - HEAD, 0x22FFFFFF);
        String[] names = new String[CATS];
        for (int k = 0; k < CATS; k++) names[k] = t("cutemod.tech.cat." + k);
        float catK = Skin.group(f, SIDE_W - 16, 0.6F, names);
        for (int k = 0; k < CATS; k++) {
            int cy = CAT_Y + k * CAT_PITCH;
            boolean sel = cat == k;
            boolean hov = in(mx, my, 4, cy, SIDE_W - 9, CAT_H);
            if (sel) {
                App.roundRect(g, 4, cy, SIDE_W - 9, CAT_H, 5, 0xFF2B3470);
                Skin.rect(g, 4, cy + 3, 2, CAT_H - 6, CYAN);
            } else if (hov) {
                App.roundRect(g, 4, cy, SIDE_W - 9, CAT_H, 5, 0xFF222859);
            }
            Skin.boxK(g, f, names[k], 10, cy + 4, sel ? CYAN : hov ? INK : MUTED, false, SIDE_W - 17, false, catK);
        }

        List<Market.Item> items = list(cat);
        int pages = Math.max(1, (items.size() + PAGE - 1) / PAGE);
        page = Math.min(page, pages - 1);
        for (int i = 0; i < PAGE; i++) {
            int idx = page * PAGE + i;
            if (idx >= items.size()) break;
            Market.Item it = items.get(idx);
            int cx = GRID_X + (i % 2) * COL_PITCH, cy = GRID_Y + (i / 2) * ROW_PITCH;
            boolean hov = in(mx, my, cx, cy, CARD_W, CARD_H);
            card(g, cx, cy, CARD_W, CARD_H, hov ? CARD_HOT : CARD, hov ? CYAN : EDGE);
            icon(g, it.id(), cx + 6, cy + 11, 1.0f);
            Skin.box(g, f, name(it.id()), cx + 30, cy + 5, INK, false, CARD_W - 34);
            Skin.box(g, f, sub(it), cx + 30, cy + 15, MUTED, false, CARD_W - 34);
            boolean rich = Progress.coins() >= it.price();
            int py = cy + 26;
            if (hov) {
                App.roundRect(g, cx + 30, py, CARD_W - 36, 10, 5, GREEN);
                String a = t("cutemod.market.add");
                Skin.str(g, f, a, cx + 30 + (CARD_W - 36 - f.width(a)) / 2, py + 1, 0xFF10132A, false);
            } else {
                App.roundRect(g, cx + 30, py, CARD_W - 36, 10, 5, rich ? 0x44FFD36B : 0x44FF6B7A);
                String price = Integer.toString(it.price());
                int px = cx + 30 + (CARD_W - 36 - (f.width(price) + 10)) / 2;
                Progress.drawCoin(g, px, py + 1);
                Skin.str(g, f, price, px + 10, py + 1, rich ? GOLD : RED, false);
            }
            // the little tags in the corner: on sale, already in the PC, an upgrade of it
            int tagX = cx + CARD_W - 3;
            int deal = dev.cutemod.market.Deals.percent(it.id());
            if (deal > 0) {
                String d = "-" + deal + "%";
                tagX -= f.width(d) + 6;
                pill(g, tagX, cy + 2, d, RED, 0xFFFFFFFF);
                tagX -= 2;
            }
            int ps = partState(it.id());
            if (ps != 0) {
                String s = t(ps == 1 ? "cutemod.tech.have" : "cutemod.tech.better");
                tagX -= f.width(s) + 6;
                if (tagX > cx + 30) pill(g, tagX, cy + 2, s, ps == 1 ? 0xFF2F7A4B : 0xFF3A3F8F, ps == 1 ? 0xFFB8FFD0 : CYAN);
            }
            Integer in = cart.get(it.id());
            if (in != null) {
                App.roundRect(g, cx + 2, cy + 2, 15, 10, 4, GREEN);
                String q = "x" + in;
                Skin.str(g, f, q, cx + 9 - f.width(q) / 2, cy + 3, 0xFF10132A, false);
            }
        }
        if (items.isEmpty()) {
            String s = t("cutemod.tech.empty");
            Skin.str(g, f, s, GRID_X + (W - GRID_X - f.width(s)) / 2, 80, MUTED, false);
        }
        if (pages > 1) {                                                   // the page switcher, bottom right
            int ry = H - 15;
            int right = W - 6 - 12;
            String num = (page + 1) + "/" + pages;
            int text = right - 4 - f.width(num);
            int left = text - 4 - 12;
            btn(g, left, ry, 12, 12, "<", page > 0, in(mx, my, left, ry, 12, 12), CYAN);
            btn(g, right, ry, 12, 12, ">", page < pages - 1, in(mx, my, right, ry, 12, 12), CYAN);
            Skin.str(g, f, num, text, ry + 2, MUTED, false);
        }
    }

    private void renderCart(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<Map.Entry<String, Integer>> rows = new ArrayList<>(cart.entrySet());
        if (rows.isEmpty()) {
            String s = t("cutemod.market.cart_empty");
            Skin.str(g, f, s, (W - f.width(s)) / 2, 74, MUTED, false);
        }
        g.enableScissor(shell.absX(), shell.absY() + HEAD + 2, shell.absX() + W, shell.absY() + 124);
        for (int i = 0; i < rows.size(); i++) {
            int y = HEAD + 4 + i * 17 - scroll;
            if (y < HEAD - 14 || y > 124) continue;
            String id = rows.get(i).getKey();
            Market.Item it = Market.item(id);
            int q = rows.get(i).getValue();
            App.roundRect(g, 4, y, W - 8, 16, 4, i % 2 == 0 ? CARD : PANEL);
            icon(g, id, 8, y + 1, 0.8f);
            Skin.box(g, font(), name(id), 28, y + 4, INK, false, 120);
            btn(g, 156, y + 2, 12, 12, "-", true, in(mx, my, 156, y + 2, 12, 12), VIOLET);
            String qs = Integer.toString(q);
            txt(g, qs, 181 - font().width(qs) / 2, y + 4, INK);
            boolean canPlus = q < Math.min(9, it.maxQty());
            btn(g, 194, y + 2, 12, 12, "+", canPlus, canPlus && in(mx, my, 194, y + 2, 12, 12), VIOLET);
            rtxt(g, Integer.toString(it.price() * q), W - 20, y + 4, GOLD);
            Progress.drawCoin(g, W - 16, y + 4);
        }
        g.disableScissor();
        // bottom bar
        Skin.rect(g, 0, 125, W, H - 125, PANEL);
        Skin.rect(g, 0, 125, W, 1, 0x334CE0F0);
        Skin.rect(g, 6, 129, 10, 10, express ? GREEN : CARD);
        Skin.rect(g, 6, 129, 10, 1, EDGE); Skin.rect(g, 6, 138, 10, 1, EDGE); Skin.rect(g, 6, 129, 1, 10, EDGE); Skin.rect(g, 15, 129, 1, 10, EDGE);
        if (express) { Skin.rect(g, 8, 133, 2, 2, 0xFF10132A); Skin.rect(g, 10, 134, 2, 2, 0xFF10132A); Skin.rect(g, 12, 131, 2, 4, 0xFF10132A); }
        txt(g, t("cutemod.market.express", Market.EXPRESS_PCT, Market.EXPRESS_SPEED), 21, 131, INK);
        int total = Market.total(cart, express);
        txt(g, t("cutemod.market.total", total), 6, 146, INK);
        boolean can = !cart.isEmpty() && Progress.coins() >= total;
        if (!cart.isEmpty() && Progress.coins() < total) txt(g, t("cutemod.market.poor"), 90, 146, RED);
        btn(g, W - 92, 140, 86, 20, t("cutemod.market.order"), can, can && in(mx, my, W - 92, 140, 86, 20), GREEN);
    }

    private void renderOrders(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<Market.Order> list = Market.orders();
        if (list.isEmpty()) {
            String s = t("cutemod.market.no_orders");
            Skin.str(g, f, s, (W - f.width(s)) / 2, 74, MUTED, false);
        }
        g.enableScissor(shell.absX(), shell.absY() + HEAD, shell.absX() + W, shell.absY() + H);
        for (int i = 0; i < list.size(); i++) {
            Market.Order o = list.get(i);
            int y = HEAD + 3 + i * 24 - scroll;
            if (y < HEAD - 22 || y > H) continue;
            App.roundRect(g, 4, y, W - 8, 23, 4, i % 2 == 0 ? CARD : PANEL);
            icon(g, o.id, 8, y + 3, 1.0f);
            Skin.box(g, font(), name(o.id) + (o.qty > 1 ? " x" + o.qty : ""), 34, y + 3, INK, false, 150);
            if (Market.arrived(o)) {
                txt(g, t("cutemod.market.arrived"), 34, y + 13, GREEN);
                btn(g, W - 76, y + 3, 68, 17, t("cutemod.market.collect"), true, in(mx, my, W - 76, y + 3, 68, 17), GREEN);
            } else {
                int total = Math.max(1000, (int) (Market.item(o.id).secs() * 1000L / 3));
                float frac = Math.max(0f, Math.min(1f, 1f - Market.secondsLeft(o) * 1000f / Math.max(total, Market.item(o.id).secs() * 1000f)));
                Skin.rect(g, 34, y + 14, 150, 5, 0xFF2E3566);
                Skin.rect(g, 34, y + 14, Math.round(150 * frac), 5, CYAN);
                int cx = 34 + Math.round(150 * frac);
                Skin.rect(g, Math.max(34, cx - 3), y + 12, 6, 8, VIOLET);     // the courier
                int s = Market.secondsLeft(o);
                rtxt(g, (s / 60) + ":" + String.format("%02d", s % 60), W - 10, y + 7, MUTED);
            }
        }
        g.disableScissor();
    }

    // ---------- input ----------
    private void setTab(int t) { tab = t; scroll = 0; }

    private int pages() { return Math.max(1, (list(cat).size() + PAGE - 1) / PAGE); }

    @Override
    public boolean click(int x, int y, int button) {
        if (y < HEAD) {
            if (in(x, y, CART_X, 5, 48, 13)) setTab(tab == 1 ? 0 : 1);
            else if (in(x, y, ORD_X, 5, 44, 13)) setTab(tab == 2 ? 0 : 2);
            else if (tab != 0) setTab(0);                              // the name of the shop leads back to the shelves
            return true;
        }
        switch (tab) {
            case 0 -> clickShop(x, y);
            case 1 -> clickCart(x, y);
            default -> clickOrders(x, y);
        }
        return true;
    }

    private void clickShop(int x, int y) {
        for (int k = 0; k < CATS; k++) {
            if (in(x, y, 4, CAT_Y + k * CAT_PITCH, SIDE_W - 9, CAT_H)) { cat = k; page = 0; return; }
        }
        int pages = pages();
        if (pages > 1) {
            Font f = font();
            int ry = H - 15, right = W - 6 - 12;
            int text = right - 4 - f.width((page + 1) + "/" + pages);
            int left = text - 4 - 12;
            if (in(x, y, left, ry, 12, 12) && page > 0) { page--; return; }
            if (in(x, y, right, ry, 12, 12) && page < pages - 1) { page++; return; }
        }
        List<Market.Item> items = list(cat);
        for (int i = 0; i < PAGE; i++) {
            int idx = page * PAGE + i;
            if (idx >= items.size()) break;
            int cx = GRID_X + (i % 2) * COL_PITCH, cy = GRID_Y + (i / 2) * ROW_PITCH;
            if (!in(x, y, cx, cy, CARD_W, CARD_H)) continue;
            Market.Item it = items.get(idx);
            cart.merge(it.id(), 1, (a, b) -> Math.min(Math.min(9, it.maxQty()), a + b));
            Progress.toast("cutemod.market.added", name(it.id()));
            return;
        }
    }

    private void clickCart(int x, int y) {
        if (in(x, y, 6, 129, 10, 10) || (y >= 129 && y < 140 && x >= 16 && x < 150)) { express = !express; return; }
        int total = Market.total(cart, express);
        if (in(x, y, W - 92, 140, 86, 20)) {
            if (!cart.isEmpty() && Progress.coins() >= total && Market.checkout(cart, express, shell.pos())) {
                cart.clear();
                Progress.toast("cutemod.market.ordered");
                setTab(2);
            }
            return;
        }
        List<Map.Entry<String, Integer>> rows = new ArrayList<>(cart.entrySet());
        for (int i = 0; i < rows.size(); i++) {
            int ry = HEAD + 4 + i * 17 - scroll;
            if (ry > 124 || ry < HEAD - 14) continue;
            String id = rows.get(i).getKey();
            int q = rows.get(i).getValue();
            if (in(x, y, 156, ry + 2, 12, 12)) {
                if (q <= 1) cart.remove(id); else cart.put(id, q - 1);
                return;
            }
            if (in(x, y, 194, ry + 2, 12, 12) && q < Math.min(9, Market.item(id).maxQty())) { cart.put(id, q + 1); return; }
        }
    }

    private void clickOrders(int x, int y) {
        List<Market.Order> list = Market.orders();
        for (int i = 0; i < list.size(); i++) {
            int ry = HEAD + 3 + i * 24 - scroll;
            if (Market.arrived(list.get(i)) && in(x, y, W - 76, ry + 3, 68, 17)) {
                Market.collect(shell.pos());
                Progress.toast("cutemod.market.collected");
                return;
            }
        }
    }

    @Override
    public boolean scroll(double amount) {
        if (tab == 0) {
            page = Math.max(0, Math.min(pages() - 1, page - (int) Math.signum(amount)));
            return true;
        }
        int rows = tab == 1 ? cart.size() * 17 - (121 - HEAD - 4) : Market.orders().size() * 24 - (H - HEAD - 3);
        scroll = Math.max(0, Math.min(Math.max(0, rows), scroll - (int) Math.signum(amount) * 14));
        return true;
    }
}
