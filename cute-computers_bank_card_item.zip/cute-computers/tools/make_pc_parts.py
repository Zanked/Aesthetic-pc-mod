"""
The 3D models of the PC upgrade parts (video cards, memory sticks, drives), one source for everything:

  python tools/make_pc_parts.py [--preview]

writes, for every part id (pc_gpu_1..7, pc_ram_4..64, pc_disk_32..1024):
  src/main/resources/assets/cutemod/textures/item/<id>_3d.png   (128x128 atlas, pastel pixel style like the computers)
  src/main/resources/assets/cutemod/models/item/<id>.json       (the item model: real boxes + the same display settings as the music players)
--preview also writes /tmp/pc_parts_preview.png (a quick isometric contact sheet, only for looking at the result).

The old flat 16x16 icons (textures/item/pc_*.png) stay in the pack, they are just not used any more.
"""
import os, sys, json, math
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, 'src/main/resources/assets/cutemod')
ATLAS = 128                             # the size of the texture of every part (it was 256)
SCALE = 2                               # the faces are drawn 2x larger and shrunk when they go into the atlas
D = 8                                   # texels per model unit while a face is drawn

OUT = (62, 48, 84)                      # the dark purple outline of the computers
GOLD, GOLD_D, GOLD_L = (246, 200, 70), (196, 140, 36), (255, 232, 140)
METAL, METAL_D, METAL_L = (214, 214, 232), (160, 158, 186), (244, 242, 252)
BLACK = (44, 36, 60)
WHITE = (250, 246, 255)
BLUSH = (255, 150, 176)

def mix(a, b, t): return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))
def lighter(c, t=.4): return mix(c, (255, 255, 255), t)
def darker(c, t=.35): return mix(c, (30, 20, 50), t)

DISPLAY = {
    "gui": {"rotation": [20, 30, 0], "translation": [0, -0.6, 0], "scale": [1.05, 1.05, 1.05]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2.5, 0], "scale": [0.5, 0.5, 0.5]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [0.8, 0.8, 0.8]},
    "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 2.2, 1], "scale": [0.45, 0.45, 0.45]},
    "thirdperson_lefthand": {"rotation": [0, 0, 0], "translation": [0, 2.2, 1], "scale": [0.45, 0.45, 0.45]},
    "firstperson_righthand": {"rotation": [-8, -30, 4], "translation": [-2.5, 1.0, 1.0], "scale": [0.48, 0.48, 0.48]},
    "firstperson_lefthand": {"rotation": [-8, 30, -4], "translation": [2.5, 1.0, 1.0], "scale": [0.48, 0.48, 0.48]},
    "head": {"rotation": [0, 180, 0], "translation": [0, 12, 0], "scale": [0.8, 0.8, 0.8]},
}

PENDING = []                            # texts of the face being drawn: they are written after the shrink, so they stay readable

# ------------------------------------------------------------------ atlas + model
class Model:
    def __init__(self):
        self.img = Image.new('RGBA', (ATLAS, ATLAS), (0, 0, 0, 0))
        self.x = 0; self.y = 8; self.rowh = 0
        self.swatch = {}
        self.sx = 0
        self.els = []

    def _alloc(self, w, h):
        w += 2; h += 2                                  # 1 px of space around, so nothing bleeds
        if self.x + w > ATLAS: self.x = 0; self.y += self.rowh; self.rowh = 0
        if self.y + h > ATLAS: raise RuntimeError('atlas full')
        pos = (self.x + 1, self.y + 1)
        self.x += w; self.rowh = max(self.rowh, h)
        return pos

    def _solid(self, c):
        c = tuple(c[:3])
        if c not in self.swatch:
            n = len(self.swatch)
            x, y = (n * 3) % ATLAS, (n * 3) // ATLAS * 3
            for i in range(2):
                for j in range(2): self.img.putpixel((x + i, y + j), c + (255,))
            self.swatch[c] = (x, y)
        x, y = self.swatch[c]
        return [x + .5, y + .5, x + 1.5, y + 1.5]

    def box(self, name, frm, to, **faces):
        """faces: south/north/east/west/up/down = an (r,g,b) colour or a painter(img, w, h) drawn on that face."""
        x1, y1, z1 = frm; x2, y2, z2 = to
        dims = {'south': (x2 - x1, y2 - y1), 'north': (x2 - x1, y2 - y1), 'east': (z2 - z1, y2 - y1),
                'west': (z2 - z1, y2 - y1), 'up': (x2 - x1, z2 - z1), 'down': (x2 - x1, z2 - z1)}
        out = {}
        for f, (wu, hu) in dims.items():
            spec = faces.get(f, faces.get('all', METAL))
            if callable(spec):
                w, h = max(2, round(wu * D)), max(2, round(hu * D))
                fi = Image.new('RGBA', (w, h), (0, 0, 0, 0))
                del PENDING[:]
                spec(fi, w, h)
                w, h = max(1, w // SCALE), max(1, h // SCALE)
                fi = fi.resize((w, h), Image.BOX)
                for (t, cx, cy, c, size) in PENDING: write_text(fi, t, cx // SCALE, cy // SCALE, c, size)
                del PENDING[:]
                px, py = self._alloc(w, h)
                self.img.paste(fi, (px, py))
                uv = [px, py, px + w, py + h]
            else:
                uv = self._solid(spec)
            out[f] = {"uv": [round(v * 16 / ATLAS, 4) for v in uv], "texture": "#t"}
        self.els.append({"name": name, "from": [round(v, 3) for v in frm], "to": [round(v, 3) for v in to], "faces": out})

    def save(self, pid):
        self.img.save(os.path.join(RES, 'textures/item/%s_3d.png' % pid))
        m = {"credit": "cute PC part (3D, same pastel style as the computers)", "ambientocclusion": False,
             "texture_size": [ATLAS, ATLAS], "textures": {"particle": "cutemod:item/%s_3d" % pid, "t": "cutemod:item/%s_3d" % pid},
             "elements": self.els, "display": DISPLAY, "render_type": "minecraft:cutout"}
        with open(os.path.join(RES, 'models/item/%s.json' % pid), 'w') as f: json.dump(m, f, indent=1)

# ------------------------------------------------------------------ painters
def panel(c, outline=True, round_=True):
    """A plain pastel panel with a soft gradient, a light top edge and a dark outline."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        for y in range(h):
            t = y / max(1, h - 1)
            d.line([(0, y), (w, y)], fill=mix(lighter(c, .22), darker(c, .12), t) + (255,))
        if outline:
            o = mix(c, OUT, .6)
            d.rectangle([0, 0, w - 1, h - 1], outline=o + (255,))
            d.line([(1, 1), (w - 2, 1)], fill=lighter(c, .6) + (255,))
            if round_:
                for (x, y) in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)): d.point((x, y), fill=o + (255,))
    return p

def compose(*fs):
    def p(img, w, h):
        for f in fs: f(img, w, h)
    return p

FACES = False                           # the little kawaii faces on the parts (switched off)

def face(cx, cy, s=1.0, eye=BLACK, cheeks=True):
    """The little kawaii face of the icons: two eyes with a shine, a small 'v' mouth, pink cheeks."""
    def p(img, w, h):
        if not FACES: return
        d = ImageDraw.Draw(img)
        ex = int(round(5 * s)); ey = int(round(4 * s)); er = max(1, int(round(2 * s)))
        for sx in (-1, 1):
            X = cx + sx * ex; Y = cy
            d.ellipse([X - er, Y - er - 1, X + er, Y + er + 1], fill=eye + (255,))
            d.point((X - 1 if er > 1 else X, Y - er), fill=WHITE + (255,))
            if er > 1: d.point((X - 1, Y - er + 1), fill=WHITE + (255,))
            if cheeks: d.ellipse([X + sx * 2 - 2, Y + er + 1, X + sx * 2 + 2, Y + er + 3], fill=BLUSH + (200,))
        m = int(round(1.5 * s)) + 1
        for i in range(-m, m + 1):
            d.point((cx + i, cy + er + 2 + (abs(i) < m and 1 or 0) * 0 + (m - abs(i)) // 1 * 0 + (1 if abs(i) <= m // 2 else 0)), fill=eye + (255,))
    return p

def heart(cx, cy, s=1, c=(238, 92, 138)):
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        r = 2 * s
        d.ellipse([cx - 2 * r, cy - r, cx, cy + r - 1], fill=c + (255,))
        d.ellipse([cx, cy - r, cx + 2 * r, cy + r - 1], fill=c + (255,))
        d.polygon([(cx - 2 * r + 1, cy + 1), (cx + 2 * r - 1, cy + 1), (cx, cy + 3 * r + 1)], fill=c + (255,))
        d.point((cx - r - 1, cy - r + 2), fill=lighter(c, .6) + (255,))
    return p

def star(cx, cy, c=GOLD):
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        d.point((cx, cy), fill=c + (255,))
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)): d.point((cx + dx, cy + dy), fill=c + (255,))
        d.point((cx, cy - 2), fill=c + (255,)); d.point((cx, cy + 2), fill=c + (255,))
        d.point((cx - 2, cy), fill=c + (255,)); d.point((cx + 2, cy), fill=c + (255,))
    return p

def dots(color, step=6, off=3):
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        for x in range(off, w - 2, step):
            for y in range(off, h - 2, step): d.point((x, y), fill=color + (120,))
    return p

def fingers(c1=GOLD, c2=GOLD_D, gap=None, pitch=3):
    """Gold contacts, like the bottom of a memory stick or a video card."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        d.rectangle([0, 0, w - 1, h - 1], fill=c2 + (255,))
        x = 1
        while x < w - 1:
            if gap and gap[0] <= x < gap[1]: x += 1; continue
            d.rectangle([x, 1, x + pitch - 2, h - 2], fill=c1 + (255,))
            d.line([(x, 1), (x, h - 2)], fill=GOLD_L + (255,))
            x += pitch
        d.line([(0, 0), (w, 0)], fill=GOLD_L + (255,))
    return p

def chip(x, y, w, h, c=BLACK, shine=True):
    def p(img, W, H):
        d = ImageDraw.Draw(img)
        d.rectangle([x, y, x + w - 1, y + h - 1], fill=c + (255,))
        d.rectangle([x, y, x + w - 1, y + h - 1], outline=darker(c, .3) + (255,))
        d.line([(x + 1, y + 1), (x + w - 2, y + 1)], fill=lighter(c, .22) + (255,))
        if shine and w > 5: d.point((x + 2, y + 2), fill=WHITE + (255,))
    return p

def write_text(img, s, cx, cy, c, size):
    try: f = ImageFont.load_default(size=size)
    except TypeError: f = ImageFont.load_default()
    d = ImageDraw.Draw(img)
    d.fontmode = '1'                                           # no smoothing: crisp pixels
    bb = d.textbbox((0, 0), s, font=f)
    d.text((cx - (bb[2] - bb[0]) // 2 - bb[0], cy - (bb[3] - bb[1]) // 2 - bb[1]), s, font=f, fill=c + (255,))

def text(s, cx, cy, c=BLACK, size=9):
    def p(img, w, h): PENDING.append((s, cx, cy, c, max(7, size - 2)))
    return p

def vents(c, n=5, pad=3):
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        for i in range(n):
            y = pad + i * max(2, (h - 2 * pad) // n)
            d.line([(pad, y), (w - pad - 1, y)], fill=c + (255,))
    return p

def stripes(c, n, vertical=True):
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        for i in range(n):
            if vertical: x = 2 + i * (w - 4) // max(1, n - 1); d.line([(x, 1), (x, h - 2)], fill=c + (255,))
            else: y = 2 + i * (h - 4) // max(1, n - 1); d.line([(1, y), (w - 2, y)], fill=c + (255,))
    return p

def fan(cx, cy, r, acc, blades=7):
    """A fan seen from the front: a dark ring, pastel blades, a hub with a shine (it looks like a big eye)."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=BLACK + (255,))
        d.ellipse([cx - r + 2, cy - r + 2, cx + r - 2, cy + r - 2], fill=darker(acc, .45) + (255,))
        for i in range(blades):
            a = i * 2 * math.pi / blades + .4
            for t in range(2, r - 2):
                x = cx + math.cos(a + t * .07) * t; y = cy + math.sin(a + t * .07) * t
                d.rectangle([x - 1, y - 1, x, y], fill=lighter(acc, .25) + (255,))
        d.ellipse([cx - 3, cy - 3, cx + 3, cy + 3], fill=acc + (255,), outline=BLACK + (255,))
        d.point((cx - 1, cy - 1), fill=WHITE + (255,)); d.point((cx - 2, cy - 1), fill=WHITE + (255,))
    return p

# ------------------------------------------------------------------ the parts
GPU_COL = {1: (160, 168, 188), 2: (120, 214, 140), 3: (248, 128, 176), 4: (100, 212, 166), 5: (250, 98, 152), 6: (64, 212, 212), 7: (210, 206, 232)}

def gpu(level):
    acc = GPU_COL[level]
    n = 1 if level <= 2 else 2 if level <= 5 else 3
    m = Model()
    L, R = 1.5, 15.0                                         # the card runs along x
    W = int(round((R - L) * D)); H = int(round(5 * D))
    shell = acc
    fx = [int(W * (i + .5) / n) for i in range(n)]
    fr = min(int(H * .42), int(W / n * .4))

    def front(img, w, h):
        panel(shell)(img, w, h)
        for x in fx: fan(x, int(h * .48), fr, acc)(img, w, h)
        d = ImageDraw.Draw(img)
        d.rectangle([2, h - 5, w - 3, h - 3], fill=darker(shell, .25) + (255,))           # the lower trim
        if level >= 5:
            d.line([(3, 3), (w - 4, 3)], fill=lighter(acc, .7) + (255,)); d.line([(3, 4), (w - 4, 4)], fill=GOLD + (255,) if level == 7 else lighter(acc, .4) + (255,))
        if n == 1: face(w - 14, h - 11, .7)(img, w, h)
        else: face(w // 2, h - 10, .6)(img, w, h)
    def top(img, w, h):
        panel(shell)(img, w, h)
        stripes(darker(shell, .3), 6)(img, w, h)
        heart(w - 10, h // 2, 1)(img, w, h)
    def back(img, w, h):
        panel(darker(shell, .25))(img, w, h); vents(darker(shell, .55), 4)(img, w, h)
        for i in range(n): chip(int(w * (i + .25) / n), h // 2 - 3, int(w / n * .5), 7, BLACK, False)(img, w, h)
    def capw(img, w, h): panel(darker(shell, .2))(img, w, h)

    m.box('shroud', (L, 6.0, 6.4), (R, 11.0, 9.6), south=front, north=back, up=top, down=darker(shell, .5), east=capw, west=capw)
    m.box('pcb', (L, 5.4, 6.9), (R - 1.0, 6.0, 9.1), all=(70, 170, 150))
    m.box('gold', (2.4, 4.2, 7.3), (10.6, 5.4, 8.7), south=fingers(gap=(int(8.8 * 4.2 / 1 * 0) + 55, 58)), north=fingers(gap=(55, 58)), up=GOLD_D, down=GOLD_D, east=GOLD_D, west=GOLD_D)
    def ports(img, w, h):
        panel(METAL, True, False)(img, w, h)
        d = ImageDraw.Draw(img)
        for i, (hh) in enumerate((8, 8, 6)):
            y = 4 + i * (h - 8) // 3
            d.rectangle([w // 2 - 6, y, w // 2 + 6, y + hh // 2 + 3], fill=BLACK + (255,))
    m.box('bracket', (0.7, 4.3, 6.1), (1.5, 11.5, 9.9), west=ports, east=METAL_D, south=METAL, north=METAL, up=METAL_L, down=METAL_D)
    for i, x in enumerate(fx):
        cxu = L + x / D
        m.box('hub%d' % i, (cxu - .55, 8.1 - .55, 9.6), (cxu + .55, 8.1 + .55, 9.95), all=BLACK, south=compose(panel(darker(acc, .35)), lambda img, w, h: ImageDraw.Draw(img).point((1, 1), fill=WHITE + (255,))))
    if level >= 3:
        m.box('power', (9.0, 11.0, 7.0), (13.2, 11.8, 9.0), all=(70, 64, 92), up=compose(panel((70, 64, 92)), dots(lighter((70, 64, 92), .5), 4, 2)))
    if level >= 5:
        m.box('rgb', (L + 1.2, 10.35, 9.6), (R - 1.2, 10.8, 9.78), all=lighter(acc, .5) if level < 7 else GOLD_L)
    if level == 7:
        m.box('crown', (L + .5, 11.0, 6.9), (L + 3.5, 11.9, 9.1), all=GOLD, up=compose(panel(GOLD), star(12, 8, WHITE)))
    return m

RAM_COL = {4: (110, 190, 148), 8: (96, 164, 206), 16: (204, 118, 150), 32: (150, 118, 206), 64: (214, 176, 70)}

def ram(gb):
    acc = RAM_COL[gb]
    chips = {4: 2, 8: 4, 16: 4, 32: 6, 64: 8}[gb]
    m = Model()
    X1, X2 = 2.0, 14.0
    W = int((X2 - X1) * D); H = int(5.4 * D)
    heat = gb >= 16
    def board(img, w, h):
        panel(acc)(img, w, h)
        d = ImageDraw.Draw(img)
        d.rectangle([2, h - 6, w - 3, h - 3], fill=darker(acc, .2) + (255,))
        for k in range(8): d.point((6 + k * 3, h - 4), fill=lighter(acc, .5) + (255,))
        if not heat:
            per = chips // 2
            cw = (w // 2 - 14) // max(per, 1) if per else 0
            for side in (0, 1):
                for i in range(per):
                    x = 4 + side * (w // 2 + 8) + i * (cw + 1)
                    chip(x, 4, max(8, cw), h - 14)(img, w, h)
            face(w // 2, h // 2 - 2, .8)(img, w, h)
            heart(w // 2 + 20, 7, 1)(img, w, h) if False else None
    def back(img, w, h):
        panel(darker(acc, .2))(img, w, h)
        for i in range(chips // 2 if not heat else 2): chip(6 + i * 20, 4, 14, h - 14, BLACK, False)(img, w, h)
    m.box('pcb', (X1, 5.0, 7.4), (X2, 10.4, 8.6), south=board, north=back, up=darker(acc, .3), down=darker(acc, .4), east=darker(acc, .3), west=darker(acc, .3))
    m.box('gold', (X1 + .4, 3.9, 7.6), (X2 - .4, 5.0, 8.4), south=fingers(gap=(int((7.0 - .4) * D) + 5, int((7.0 - .4) * D) + 8)), north=fingers(gap=(int((7.0 - .4) * D) + 5, int((7.0 - .4) * D) + 8)),
          up=GOLD_D, down=GOLD_D, east=GOLD_D, west=GOLD_D)
    for sx, x in ((0, X1 - .7), (1, X2)):
        m.box('clip%d' % sx, (x, 6.6, 7.5), (x + .7, 8.8, 8.5), all=METAL, south=panel(METAL, True, False), up=METAL_L)
    if heat:
        hc = lighter(acc, .1) if gb != 64 else GOLD
        def spreader(img, w, h):
            panel(hc)(img, w, h)
            d = ImageDraw.Draw(img)
            d.line([(2, h - 4), (w - 3, h - 4)], fill=darker(hc, .3) + (255,))
            face(w // 2, h // 2 - 1, .85)(img, w, h)
            heart(10, h // 2, 1)(img, w, h) if gb >= 32 else None
            star(w - 10, h // 2, WHITE)(img, w, h)
        m.box('spreader', (X1 + .5, 5.9, 8.6), (X2 - .5, 10.0, 9.1), south=spreader, up=compose(panel(hc), stripes(darker(hc, .35), 9)), north=hc, east=darker(hc, .3), west=darker(hc, .3), down=darker(hc, .4))
        m.box('fins', (X1 + 1.0, 10.0, 8.7), (X2 - 1.0, 10.7 if gb < 64 else 11.3, 9.0), all=lighter(hc, .15), up=compose(panel(lighter(hc, .15)), stripes(darker(hc, .3), 12)))
    return m

DISK_COL = {32: (176, 180, 198), 48: (120, 224, 176), 64: (104, 192, 248), 96: (184, 136, 248), 128: (248, 136, 184),
            160: (208, 208, 232), 256: (226, 176, 238), 512: (176, 216, 204), 1024: (248, 176, 56)}

def disk(gb):
    acc = DISK_COL[gb]
    m = Model()
    label = '%s' % ('1TB' if gb == 1024 else '%dGB' % gb)
    short = '1T' if gb == 1024 else str(gb)                 # the small labels only have room for the number
    if gb <= 32:                                             # a plain hard disk: a thick metal case, a spindle and a pastel label
        W, H = int(9 * D), int(11 * D)
        def top(img, w, h):
            panel(METAL)(img, w, h)
            d = ImageDraw.Draw(img)
            for (x, y) in ((4, 4), (w - 5, 4), (4, h - 5), (w - 5, h - 5)): d.ellipse([x - 1, y - 1, x + 1, y + 1], fill=METAL_D + (255,), outline=OUT + (255,))
            d.ellipse([w // 2 - 9, 6, w // 2 + 9, 24], outline=METAL_D + (255,)); d.ellipse([w // 2 - 2, 14, w // 2 + 2, 18], fill=METAL_D + (255,))
            d.rounded_rectangle([8, 28, w - 9, h - 10], radius=3, fill=acc + (255,), outline=mix(acc, OUT, .5) + (255,))
            face(w // 2, 41, .75)(img, w, h)
            text(label, w // 2, h - 17, BLACK, 9)(img, w, h)
        m.box('case', (3.5, 2.6, 6.4), (12.5, 13.6, 9.6), south=top, north=compose(panel(METAL_D), vents(METAL, 5)), up=METAL_L, down=METAL_D, east=panel(METAL_D), west=panel(METAL_D))
        m.box('board', (4.0, 2.0, 6.8), (12.0, 2.6, 9.2), all=(70, 170, 150))
        m.box('sata', (5.0, 1.0, 7.3), (11.0, 2.0, 8.7), south=fingers(pitch=3), north=fingers(pitch=3), up=GOLD_D, down=GOLD_D, east=GOLD_D, west=GOLD_D)
    elif gb <= 64:                                           # a slim 2.5" SSD
        def top(img, w, h):
            panel(METAL)(img, w, h)
            d = ImageDraw.Draw(img)
            d.rounded_rectangle([5, 6, w - 6, h - 20], radius=3, fill=acc + (255,), outline=mix(acc, OUT, .5) + (255,))
            face(w // 2, 24, .8)(img, w, h)
            d.rectangle([5, h - 14, w - 6, h - 6], fill=METAL_D + (255,), outline=OUT + (255,))
            text(short, w // 2, h - 10, BLACK, 9)(img, w, h)
        m.box('case', (3.8, 2.8, 7.1), (12.2, 13.8, 8.9), south=top, north=compose(panel(METAL_D), vents(METAL, 4)), up=METAL_L, down=METAL_D, east=panel(METAL_D), west=panel(METAL_D))
        m.box('sata', (5.0, 1.4, 7.4), (11.0, 2.8, 8.6), south=fingers(pitch=3), north=fingers(pitch=3), up=GOLD_D, down=GOLD_D, east=GOLD_D, west=GOLD_D)
        m.box('bezel', (3.5, 13.8, 7.0), (12.5, 14.4, 9.0), all=lighter(acc, .1), south=panel(lighter(acc, .1)))
    else:                                                    # an M.2 NVMe stick, with a heatsink on the faster ones
        sink = gb >= 256
        def board(img, w, h):
            panel(acc)(img, w, h)
            d = ImageDraw.Draw(img)
            if not sink:
                chip(10, 5, 16, h - 12)(img, w, h); chip(30, 5, 16, h - 12)(img, w, h)
                d.rounded_rectangle([54, 5, w - 8, h - 7], radius=2, fill=WHITE + (255,), outline=mix(acc, OUT, .5) + (255,))
                face(54 + (w - 62) // 2, h // 2 - 4, .6)(img, w, h)
                text(short, 54 + (w - 62) // 2, h - 11, BLACK, 9)(img, w, h)
            d.ellipse([w - 7, h // 2 - 2, w - 3, h // 2 + 2], fill=BLACK + (255,))
        m.box('stick', (2.0, 5.6, 7.4), (14.0, 10.8, 8.6), south=board, north=compose(panel(darker(acc, .2)), chip(10, 5, 14, 18, BLACK, False)), up=darker(acc, .3), down=darker(acc, .4), east=darker(acc, .3), west=darker(acc, .3))
        m.box('gold', (1.0, 6.0, 7.6), (2.0, 10.4, 8.4), east=GOLD_D, west=compose(fingers(pitch=3)), south=GOLD_D, north=GOLD_D, up=fingers(pitch=3), down=GOLD_D)
        if sink:
            hc = lighter(acc, .15)
            def sk(img, w, h):
                panel(hc)(img, w, h); d = ImageDraw.Draw(img)
                d.line([(2, h - 5), (w - 3, h - 5)], fill=darker(hc, .3) + (255,))
                face(w // 2 - 6, h // 2 - 2, .75)(img, w, h)
                text(short, w - 18, h // 2 - 2, BLACK, 9)(img, w, h)
            m.box('heatsink', (3.4, 5.9, 8.6), (12.2, 10.5, 9.2), south=sk, up=compose(panel(hc), stripes(darker(hc, .3), 8)), east=darker(hc, .3), west=darker(hc, .3), north=hc, down=darker(hc, .4))
            m.box('fins', (4.0, 10.5, 8.7), (11.6, 11.1, 9.1), all=lighter(hc, .1), up=compose(panel(lighter(hc, .1)), stripes(darker(hc, .3), 9)))
        if gb == 1024:
            m.box('crown', (11.4, 10.8, 7.6), (13.8, 11.7, 8.4), all=GOLD, up=compose(panel(GOLD), star(8, 4, WHITE)))
    return m

PARTS = {}
for lv in range(1, 8): PARTS['pc_gpu_%d' % lv] = lambda lv=lv: gpu(lv)
for gb in RAM_COL: PARTS['pc_ram_%d' % gb] = lambda gb=gb: ram(gb)
for gb in DISK_COL: PARTS['pc_disk_%d' % gb] = lambda gb=gb: disk(gb)

# ------------------------------------------------------------------ preview (isometric, only for looking at the result)
def preview(models, path):
    S = 22; CW, CH = 360, 330
    cols = 6; rows = (len(models) + cols - 1) // cols
    sheet = Image.new('RGBA', (cols * CW // 2 + 10, rows * CH // 2 + 10), (88, 84, 104, 255))
    ax, ay = math.radians(20), math.radians(30)
    def rot(p):
        x, y, z = p[0] - 8, p[1] - 8, p[2] - 8
        x, z = x * math.cos(ay) + z * math.sin(ay), -x * math.sin(ay) + z * math.cos(ay)
        y, z = y * math.cos(ax) - z * math.sin(ax), y * math.sin(ax) + z * math.cos(ax)
        return x, y, z
    def coeffs(dst, src):
        import numpy as np
        A = []; B = []
        for (X, Y), (x, y) in zip(dst, src):
            A.append([X, Y, 1, 0, 0, 0, -x * X, -x * Y]); A.append([0, 0, 0, X, Y, 1, -y * X, -y * Y]); B += [x, y]
        return list(np.linalg.solve(np.array(A, float), np.array(B, float)))
    for k, (pid, m) in enumerate(models):
        tile = Image.new('RGBA', (CW, CH), (88, 84, 104, 255))
        quads = []
        for e in m.els:
            x1, y1, z1 = e['from']; x2, y2, z2 = e['to']
            F = {'south': [(x1, y2, z2), (x2, y2, z2), (x2, y1, z2), (x1, y1, z2)], 'north': [(x2, y2, z1), (x1, y2, z1), (x1, y1, z1), (x2, y1, z1)],
                 'east': [(x2, y2, z2), (x2, y2, z1), (x2, y1, z1), (x2, y1, z2)], 'west': [(x1, y2, z1), (x1, y2, z2), (x1, y1, z2), (x1, y1, z1)],
                 'up': [(x1, y2, z1), (x2, y2, z1), (x2, y2, z2), (x1, y2, z2)], 'down': [(x1, y1, z2), (x2, y1, z2), (x2, y1, z1), (x1, y1, z1)]}
            for f, pts in F.items():
                r = [rot(p) for p in pts]
                ux, uy = r[1][0] - r[0][0], r[1][1] - r[0][1]; vx, vy = r[3][0] - r[0][0], r[3][1] - r[0][1]
                if ux * vy - uy * vx > 0: continue          # facing away
                uv = e['faces'][f]['uv']
                quads.append((sum(p[2] for p in r) / 4, r, uv))
        quads.sort(key=lambda q: q[0])
        for _, r, uv in quads:
            dst = [(CW / 2 + p[0] * S, CH / 2 - p[1] * S) for p in r]
            u1, v1, u2, v2 = [c * ATLAS / 16 for c in uv]
            src = [(u1, v1), (u2, v1), (u2, v2), (u1, v2)]
            try: c = coeffs(dst, src)
            except Exception: continue
            xs = [p[0] for p in dst]; ys = [p[1] for p in dst]
            box = (int(min(xs)) - 1, int(min(ys)) - 1, int(max(xs)) + 2, int(max(ys)) + 2)
            sub = m.img.transform((CW, CH), Image.PERSPECTIVE, c, Image.NEAREST)
            mask = Image.new('L', (CW, CH), 0); ImageDraw.Draw(mask).polygon(dst, fill=255)
            tile.paste(sub, (0, 0), Image.composite(sub.split()[3], Image.new('L', (CW, CH), 0), mask))
        tile = tile.resize((CW // 2, CH // 2), Image.LANCZOS)
        sheet.paste(tile, (5 + (k % cols) * CW // 2, 5 + (k // cols) * CH // 2))
    sheet.save(path)

if __name__ == '__main__':
    built = []
    for pid, fn in PARTS.items():
        m = fn(); m.save(pid); built.append((pid, m))
    print('wrote', len(built), 'parts')
    if '--preview' in sys.argv: preview(built, '/tmp/pc_parts_preview.png'); print('preview: /tmp/pc_parts_preview.png')
