package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/** Pictures of the trip places and the little photo (a polaroid with the pet in it) of the pet's letters. */
final class TripArt {
    private TripArt() {}

    private static void tri(GuiGraphics g, int cx, int top, int w, int h, int argb) {
        for (int r = 0; r < h; r++) {
            int ww = Math.max(1, w * (r + 1) / h);
            rect(g, cx - ww / 2, top + r, ww, 1, argb);
        }
    }

    /** The place itself, drawn inside the box x,y,w,h (nothing leaves the box). */
    static void scene(GuiGraphics g, int x, int y, int w, int h, int dest, int ticks) {
        int floor = y + h * 70 / 100;
        switch (dest) {
            case 0 -> {      // kindergarten: a rainbow, a soft floor and building blocks
                g.fillGradient(x, y, x + w, y + h, 0xFFFFF3F8, 0xFFFFE0EC);
                int cx = x + w / 2, r = Math.min(h * 55 / 100, w / 2 - 1);
                int[] c = {0xFFFF6B6B, 0xFFFFC832, 0xFF6BCB77, 0xFF4D96FF};
                for (int i = 0; i < 4; i++) disc(g, cx, floor, r - i * Math.max(1, r / 7), c[i]);
                disc(g, cx, floor, Math.max(1, r - 4 * Math.max(1, r / 7)), 0xFFFFF3F8);
                rect(g, x, floor, w, y + h - floor, 0xFFF3D9A4);
                int b = Math.max(3, h / 7);
                rect(g, x + w / 8, floor + 1, b, b, 0xFFE5484D);
                rect(g, x + w / 8 + b, floor + 1, b, b, 0xFF4D96FF);
                rect(g, x + w / 8 + b / 2, floor + 1 - b, b, b, 0xFFFFC832);
            }
            case 1 -> {      // beach
                g.fillGradient(x, y, x + w, floor - h / 8, 0xFF8FD3FF, 0xFFD8F1FF);
                rect(g, x, floor - h / 8, w, h / 8 + 2, 0xFF3FA8E0);
                rect(g, x + (ticks / 6) % 12, floor - h / 8 + 2, 6, 1, 0x99FFFFFF);
                rect(g, x, floor + 2, w, y + h - floor - 2, 0xFFF3D9A4);
                disc(g, x + w * 80 / 100, y + h / 5 + 2, Math.max(3, h / 9), 0xFFFFE066);
                int px = x + w * 20 / 100;                                  // a palm
                rect(g, px, y + h * 35 / 100, 2, floor - y - h * 35 / 100, 0xFF8A5A3A);
                disc(g, px - 5, y + h * 35 / 100, 4, 0xFF3FA55A); disc(g, px + 6, y + h * 35 / 100, 4, 0xFF3FA55A); disc(g, px, y + h * 30 / 100, 4, 0xFF4FB86A);
            }
            case 2 -> {      // forest
                g.fillGradient(x, y, x + w, y + h, 0xFF9ADCA0, 0xFF3FA55A);
                for (int i = 0; i < 4; i++) {
                    int tx = x + w * (12 + i * 24) / 100;
                    rect(g, tx - 1, y + h * 35 / 100, 3, floor - y - h * 35 / 100 + 2, 0xFF6A4228);
                    disc(g, tx, y + h * 30 / 100, Math.max(4, h / 6), i % 2 == 0 ? 0xFF2E8B4A : 0xFF3FA55A);
                }
                rect(g, x, floor + 2, w, y + h - floor - 2, 0xFF2E7A3A);
                int mx = x + w * 55 / 100;                                  // a mushroom
                rect(g, mx, floor, 2, 3, 0xFFF3E8D0);
                disc(g, mx + 1, floor, 3, 0xFFE5484D);
                rect(g, mx, floor - 2, 1, 1, 0xFFFFFFFF);
            }
            case 3 -> {      // mountains with snow
                g.fillGradient(x, y, x + w, y + h, 0xFF7FC4FF, 0xFFD8F1FF);
                tri(g, x + w * 32 / 100, y + h * 15 / 100, w * 55 / 100, floor - y - h * 15 / 100, 0xFF8A94A8);
                tri(g, x + w * 32 / 100, y + h * 15 / 100, w * 18 / 100, h * 16 / 100, 0xFFFFFFFF);
                tri(g, x + w * 72 / 100, y + h * 35 / 100, w * 40 / 100, floor - y - h * 35 / 100, 0xFF7480A0);
                tri(g, x + w * 72 / 100, y + h * 35 / 100, w * 12 / 100, h * 10 / 100, 0xFFFFFFFF);
                rect(g, x, floor, w, y + h - floor, 0xFF5BBF6A);
            }
            case 4 -> {      // a city at dusk
                g.fillGradient(x, y, x + w, y + h, 0xFF3A2A6A, 0xFFF58FB8);
                int[] hh = {42, 62, 38, 70, 50, 58};
                for (int i = 0; i < 6; i++) {
                    int bx = x + i * w / 6, bw = w / 6 - 1, bh = h * hh[i] / 100;
                    rect(g, bx, y + h - bh, bw, bh, i % 2 == 0 ? 0xFF2A2048 : 0xFF3A2D5E);
                    for (int wy = y + h - bh + 3; wy < y + h - 4; wy += 5)
                        for (int wx = bx + 2; wx < bx + bw - 2; wx += 4)
                            if (((wx * 7 + wy * 13 + (ticks / 40)) % 5) != 0) rect(g, wx, wy, 2, 2, 0xFFFFE680);
                }
            }
            case 6 -> {      // bee meadow: flowers, a hive and bees
                g.fillGradient(x, y, x + w, y + h, 0xFFFFF3B0, 0xFFB6E88A);
                rect(g, x, floor, w, y + h - floor, 0xFF5BBF6A);
                int hx = x + w * 22 / 100, hw = Math.max(8, w / 6), rh = Math.max(3, h / 12);
                for (int i = 0; i < 4; i++) {
                    int in = i == 0 || i == 3 ? 2 : 0;
                    rect(g, hx - hw / 2 + in, floor - (i + 1) * rh, hw - in * 2, rh - 1, i % 2 == 0 ? 0xFFF5B800 : 0xFFFFD84D);
                }
                rect(g, hx - 1, floor - rh * 2, 3, 3, 0xFF3A2A3A);
                for (int i = 0; i < 7; i++) rect(g, x + (i * 41 + 9) % (w - 3), floor + 2 + (i * 7) % Math.max(1, y + h - floor - 4), 2, 2, i % 3 == 0 ? 0xFFFFFFFF : i % 3 == 1 ? 0xFFFF8FB8 : 0xFFFFF3B0);
                for (int i = 0; i < 3; i++) {
                    int bx = x + 2 + (ticks * (1 + i) / 2 + i * 37) % Math.max(1, w - 5), by = y + h * (22 + i * 13) / 100 + (int) Math.round(Math.sin((ticks + i * 9) / 6.0) * 3);
                    rect(g, bx, by, 3, 2, 0xFFFFC832);
                    rect(g, bx + 1, by, 1, 2, 0xFF3A2A3A);
                }
            }
            case 7 -> {      // a city in the clouds: floating islands
                g.fillGradient(x, y, x + w, y + h, 0xFF3A6AD8, 0xFFFFB8D8);
                for (int i = 0; i < 3; i++) {
                    int cx = x + (int) ((ticks * (0.08 + i * 0.04) + i * 40) % (w + 20)) - 10, cy = y + h * (15 + i * 20) / 100;
                    disc(g, Math.max(x + 4, Math.min(x + w - 5, cx)), cy, 3, 0xCCFFFFFF);
                }
                for (int i = 0; i < 2; i++) {
                    int ix = x + w * (28 + i * 42) / 100, iy = y + h * (50 + i * 14) / 100, iw = w * 22 / 100;
                    rect(g, ix - iw / 2 + 2, iy + 3, iw - 4, h / 12, 0xFF8A6A4A);
                    rect(g, ix - iw / 2, iy, iw, 3, 0xFF5BBF6A);
                    rect(g, ix - 3, iy - 6, 6, 6, 0xFFFFFFFF);
                    tri(g, ix, iy - 11, 10, 5, 0xFFE5484D);
                }
            }
            case 8 -> {      // a snowy village at night
                g.fillGradient(x, y, x + w, y + h, 0xFF14204A, 0xFF3A4A8A);
                rect(g, x + w * 70 / 100, y + h * 15 / 100, 1, 1, 0xFFFFFFFF);
                rect(g, x + w * 30 / 100, y + h * 10 / 100, 1, 1, 0xFFFFFFFF);
                rect(g, x, floor, w, y + h - floor, 0xFFF4F9FF);
                for (int i = 0; i < 2; i++) {
                    int hx = x + w * (18 + i * 44) / 100, hw = w * 24 / 100, hh = h * 24 / 100;
                    rect(g, hx, floor - hh + 3, hw, hh, 0xFF8A5A3A);
                    tri(g, hx + hw / 2, floor - hh - hh / 2 + 3, hw + 4, hh / 2 + 1, 0xFFFFFFFF);
                    rect(g, hx + hw / 2 - 2, floor - hh / 2 + 1, 4, 4, 0xFFFFE680);
                }
                for (int i = 0; i < 10; i++) rect(g, x + (i * 29 + ticks / 6 * (i % 2 + 1)) % w, y + (i * 17 + ticks / 2) % Math.max(1, floor - y), 1, 1, 0xFFFFFFFF);
            }
            case 9 -> {      // a cherry garden
                g.fillGradient(x, y, x + w, y + h, 0xFFFFE0EC, 0xFFFFF8FB);
                rect(g, x, floor, w, y + h - floor, 0xFF9ADCA0);
                int tx = x + w * 40 / 100;
                rect(g, tx - 2, y + h * 38 / 100, 4, floor - y - h * 38 / 100 + 1, 0xFF6A4228);
                int cr = Math.max(5, h / 5);
                disc(g, tx, y + h * 30 / 100, cr, 0xFFF58FB8);
                disc(g, tx - cr, y + h * 38 / 100, cr * 2 / 3, 0xFFFFB6D2);
                disc(g, Math.min(x + w - cr, tx + cr), y + h * 38 / 100, cr * 2 / 3, 0xFFFFB6D2);
                for (int i = 0; i < 10; i++) rect(g, x + (i * 31 + ticks / 5 * (1 + i % 2)) % w, y + h * 25 / 100 + (i * 13 + ticks / 2) % Math.max(1, floor - y - h * 25 / 100), 2, 1, i % 2 == 0 ? 0xFFFFB6D2 : 0xFFFFFFFF);
            }
            case 10 -> {     // a lighthouse at sunset
                g.fillGradient(x, y, x + w, floor, 0xFFFF8A5C, 0xFFFFE0A0);
                disc(g, x + w * 68 / 100, y + h * 50 / 100, Math.max(3, h / 8), 0xFFFFD84D);
                rect(g, x, y + h * 54 / 100, w, y + h - y - h * 54 / 100, 0xFF3A6AB8);
                rect(g, x + w * 62 / 100, y + h * 56 / 100, w * 12 / 100, 1, 0xAAFFE0A0);
                rect(g, x + w * 64 / 100, y + h * 62 / 100, w * 8 / 100, 1, 0x88FFE0A0);
                int lx = x + w * 26 / 100, lh = h * 52 / 100, base = y + h * 82 / 100;
                for (int r = 0; r < lh; r++) {
                    int ww = Math.max(3, w * 8 / 100 + r * w / 100 / 8);
                    rect(g, lx - ww / 2, base - lh + r, ww, 1, (r / Math.max(2, lh / 5)) % 2 == 0 ? 0xFFE5484D : 0xFFFFFFFF);
                }
                rect(g, lx - 3, base - lh - 4, 6, 4, (ticks / 20) % 2 == 0 ? 0xFFFFE680 : 0xFFFFC832);
                rect(g, lx - 5, base, 11, y + h - base, 0xFF6A6A78);
            }
            case 5 -> {      // the moon: stars, grey ground and the Earth
                rect(g, x, y, w, h, 0xFF0B0B2A);
                for (int i = 0; i < 12; i++) rect(g, x + (i * 37 + 5) % w, y + (i * 23 + 3) % (h * 60 / 100), 1, 1, (ticks / 15 + i) % 4 == 0 ? 0xFF888899 : 0xFFFFFFFF);
                disc(g, x + w * 80 / 100, y + h * 22 / 100, Math.max(4, h / 7), 0xFF4D96FF);
                disc(g, x + w * 80 / 100 - 1, y + h * 22 / 100 - 1, Math.max(2, h / 12), 0xFF6BCB77);
                for (int cx = 0; cx < w; cx++) {                           // the curve of the moon
                    double t = (cx - w / 2.0) / (w * 0.75);
                    int top = (int) (floor + 2 + t * t * h * 0.22);
                    if (top < y + h) rect(g, x + cx, top, 1, y + h - top, 0xFFB8BCC8);
                }
                disc(g, x + w * 30 / 100, floor + h / 8, Math.max(1, h / 14), 0xFF9094A0);
            }
        }
    }

    /** A polaroid: the place, the pet standing in it and the name of the place under it. */
    static void photo(GuiGraphics g, Font f, int x, int y, int w, int h, int dest, ComputerColor color, int stage, int ticks) {
        rect(g, x + 1, y + 2, w, h, 0x33000000);
        rect(g, x, y, w, h, 0xFFFFFFFF);
        int ix = x + 3, iy = y + 3, iw = w - 6, ih = h - 15;
        scene(g, ix, iy, iw, ih, dest, ticks);
        float sc = 0.4F * PetArt.scaleOf(stage);
        int cx = ix + iw / 2 + (dest == 0 ? 0 : 6), fl = iy + ih * 80 / 100;
        g.pose().pushPose();
        g.pose().translate(cx, fl, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-cx, -fl, 0);
        PetArt.draw(g, color, cx, fl - 28, 2, ticks, false, false, stage, Progress.equipped(), Progress.equippedBody());
        g.pose().popPose();
        String name = f.plainSubstrByWidth(Component.translatable("cutemod.trip.dest." + dest).getString(), w - 8);
        g.drawString(f, name, x + (w - f.width(name)) / 2, y + h - 11, 0xFF3A2A3A, false);
    }

    /** The photo of a letter of the ring (slot 0-5) and what the pet found, drawn at x,y. */
    static void letterPhoto(GuiGraphics g, Font f, int x, int y, int slot, int ticks) {
        String p = "tr" + slot + "_";
        int dest = Math.max(0, Progress.count(p + "dest") - 1), find = Math.max(0, Progress.count(p + "find") - 1);
        ComputerColor col = ComputerColor.values()[Math.floorMod(Progress.count(p + "col") - 1, ComputerColor.values().length)];
        photo(g, f, x, y, 104, 64, dest, col, Math.max(0, Math.min(2, Progress.count(p + "stage"))), ticks);
        int tx = x + 114;
        g.drawString(f, Component.translatable("cutemod.trip.found"), tx, y + 4, 0xFF8A7AA8, false);
        g.drawString(f, Component.translatable("cutemod.trip.find." + dest + "." + find), tx, y + 15, 0xFF3A2A3A, false);
        if (Progress.count(p + "new") > 0) g.drawString(f, Component.translatable("cutemod.trip.new"), tx, y + 27, 0xFFE5484D, false);
        int coins = Progress.count(p + "coins");
        if (coins > 0) { Progress.drawCoin(g, tx, y + 41); g.drawString(f, "+" + coins, tx + 10, y + 40, 0xFFC98A00, false); }
        else g.drawString(f, Component.translatable("cutemod.trip.no_coins"), tx, y + 40, 0xFF9A8AB8, false);
    }
}
