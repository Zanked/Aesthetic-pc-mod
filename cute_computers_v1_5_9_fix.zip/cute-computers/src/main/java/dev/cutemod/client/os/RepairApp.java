package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.Random;

/**
 * The way out of Safe Mode: a disk defragmenter. The blocks are scrambled; click two blocks to swap them until
 * every row is one color. Fixing the disk ends Safe Mode.
 */
public class RepairApp extends App {
    private static final int COLS = 10, ROWS = 6, CW = 22, CH = 16, GX = (W - COLS * CW) / 2, GY = 36;
    /** The disk is scrambled with this many swaps, so it can always be fixed with at most as many. */
    private static final int SCRAMBLE = 14;
    private static final int[] COLORS = {0xFF4A9BE0, 0xFFE5484D, 0xFF5BBF6A, 0xFFF3C45A, 0xFFB57BD6, 0xFFFF8FB0};

    private final int[] cell = new int[COLS * ROWS];
    private int picked = -1, swaps, flash = -1, doneTicks = -1, ticks;

    public RepairApp() { scramble(); }

    private void scramble() {
        for (int i = 0; i < cell.length; i++) cell[i] = i / COLS;       // solved
        Random r = new Random(System.nanoTime());
        do {
            for (int k = 0; k < SCRAMBLE; k++) {
                int a = r.nextInt(cell.length), b = r.nextInt(cell.length);
                int tmp = cell[a]; cell[a] = cell[b]; cell[b] = tmp;
            }
        } while (wrong() < 12);
        swaps = 0;
        picked = -1;
        doneTicks = -1;
    }

    private int wrong() {
        int n = 0;
        for (int i = 0; i < cell.length; i++) if (cell[i] != i / COLS) n++;
        return n;
    }

    @Override
    public Component title() { return Component.translatable("cutemod.repair.title"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.repair.hint"); }

    @Override
    public void tick() {
        ticks++;
        if (flash > 0) flash--;
        if (doneTicks >= 0 && ++doneTicks > 70) finish();
    }

    private void finish() {
        Retro.setSafe(false);
        Progress.bump("crash_fixed");
        Progress.toast("cutemod.repair.toast");
        shell.home();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        rect(g, 0, 0, W, H, 0xFF0B1A33);
        g.drawString(font(), t("cutemod.repair.title"), GX, 8, 0xFFBFD8F0, false);
        int frag = 100 * wrong() / cell.length;
        g.drawString(font(), t("cutemod.repair.frag", frag), GX, 20, 0xFFFFFFFF, false);
        String sw = t("cutemod.repair.swaps", swaps);
        g.drawString(font(), sw, GX + COLS * CW - font().width(sw), 20, 0xFF9FB8D0, false);
        // at the left of every row: the color that belongs there (it lights up for the block in hand)
        int want = picked >= 0 ? cell[picked] : -1;
        for (int r = 0; r < ROWS; r++) {
            if (r == want) rect(g, GX - 11, GY + r * CH - 1, 9, CH + 1, 0xFFFFFFFF);
            rect(g, GX - 10, GY + r * CH, 7, CH - 1, COLORS[r]);
        }
        for (int i = 0; i < cell.length; i++) {
            int cx = GX + (i % COLS) * CW, cy = GY + (i / COLS) * CH;
            int c = COLORS[cell[i]];
            boolean hover = in(mx, my, cx, cy, CW, CH);
            rect(g, cx, cy, CW - 1, CH - 1, picked == i ? 0xFFFFFFFF : c);
            if (picked == i) rect(g, cx + 2, cy + 2, CW - 5, CH - 5, c);
            rect(g, cx, cy, CW - 1, 2, 0x55FFFFFF);
            if (hover && picked != i) rect(g, cx, cy, CW - 1, CH - 1, 0x33FFFFFF);
            if (cell[i] == i / COLS && doneTicks < 0) rect(g, cx + CW - 5, cy + CH - 5, 3, 3, 0x66FFFFFF);
            // a block in hand: the places in its row that are still wrong blink, that is where it goes
            if (want >= 0 && i / COLS == want && cell[i] != want && (ticks / 8) % 2 == 0) {
                rect(g, cx, cy, CW - 1, 1, 0xFFFFFFFF); rect(g, cx, cy + CH - 2, CW - 1, 1, 0xFFFFFFFF);
                rect(g, cx, cy, 1, CH - 1, 0xFFFFFFFF); rect(g, cx + CW - 2, cy, 1, CH - 1, 0xFFFFFFFF);
            }
        }
        // the progress bar of the defragmenter
        int bw = COLS * CW, by = GY + ROWS * CH + 10;
        rect(g, GX, by, bw, 8, 0xFF1B2F55);
        rect(g, GX, by, bw * (100 - frag) / 100, 8, 0xFF5BBF6A);
        if (doneTicks >= 0) {
            rect(g, 0, 0, W, H, 0xAA0B1A33);
            g.drawCenteredString(font(), Component.translatable("cutemod.repair.done"), W / 2, H / 2 - 4, 0xFF9BFFB0);
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (doneTicks >= 0) return true;
        for (int i = 0; i < cell.length; i++) {
            if (!in(x, y, GX + (i % COLS) * CW, GY + (i / COLS) * CH, CW - 1, CH - 1)) continue;
            if (picked < 0) { picked = i; Sfx.click(); }
            else if (picked == i) picked = -1;
            else {
                int tmp = cell[picked]; cell[picked] = cell[i]; cell[i] = tmp;
                picked = -1;
                swaps++;
                flash = 8;
                Sfx.disk();
                if (wrong() == 0) doneTicks = 0;
            }
            return true;
        }
        return false;
    }
}
