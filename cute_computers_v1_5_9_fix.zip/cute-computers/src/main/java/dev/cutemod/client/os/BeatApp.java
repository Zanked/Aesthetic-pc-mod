package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

/**
 * Beat Maker: a step sequencer with note block sounds. A grid of 16 steps and 8 rows: three drums (kick, snare, hat)
 * and five notes of a pentatonic scale (so everything you click sounds good together). Click or drag to paint
 * notes, press Play. Pick the instrument of the notes (harp, bell, bass, chime), change the tempo, keep 3 beats on the
 * server ("beats") or load a demo. It keeps playing while the window is minimized. Only the Music volume counts.
 */
public class BeatApp extends App {
    private static final int STEPS = 16, ROWS = 8, DRUMS = 3, SLOTS = 3;
    private static final int GX = 38, GY = 19, CW = 15, CH = 12;
    private static final int[] NOTE = {21, 19, 16, 14, 12};                       // note block notes of the 5 melody rows, high to low
    private static final int[] ROW_COL = {0xFFFF6B6B, 0xFFFFA24A, 0xFFFFD84A, 0xFFF58FB8, 0xFF8FB8FF, 0xFF7ED9A0, 0xFFB57BD6, 0xFF5BD9C8};
    private static final int BG = 0xFF1E1438, TEXT = 0xFFFFFFFF, MUTED = 0xFF9A8AC0, ACCENT = 0xFFB57BD6;
    private static final int[] DEMO = {                                           // one 16-bit pattern per row
            0b1000100010001000, 0b0000100000001000, 0b0010001000100010,
            0b0000000010000000, 0b1000001000100000, 0b0010000010001000, 0b0000100000000010, 0b1000000010000000};

    private final int[] rows = new int[ROWS];
    private int bpm = 110, inst, slot;
    private boolean playing, loaded, paint;
    private int pos, ticks, msgT;
    private double acc;
    private String msg = "";

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        if (!loaded) { loaded = true; System.arraycopy(DEMO, 0, rows, 0, ROWS); }
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.beats"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.beats"); }

    @Override
    public boolean background() { return playing; }

    @Override
    public boolean busy() { return playing; }

    @Override
    public void close() { playing = false; }

    // ---------- sound ----------
    private static SoundEvent instrument(int i) {
        return switch (i) {
            case 0 -> SoundEvents.NOTE_BLOCK_HARP.value();
            case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
            case 2 -> SoundEvents.NOTE_BLOCK_BASS.value();
            default -> SoundEvents.NOTE_BLOCK_CHIME.value();
        };
    }

    private static float pitch(int note) { return (float) Math.pow(2.0, (note - 12) / 12.0); }

    private void play(int row) {
        switch (row) {
            case 0 -> Sfx.musicNote(SoundEvents.NOTE_BLOCK_BASEDRUM.value(), 1.0F, 0.9F);
            case 1 -> Sfx.musicNote(SoundEvents.NOTE_BLOCK_SNARE.value(), 1.0F, 0.7F);
            case 2 -> Sfx.musicNote(SoundEvents.NOTE_BLOCK_HAT.value(), 1.4F, 0.5F);
            default -> Sfx.musicNote(instrument(inst), pitch(NOTE[row - DRUMS]) * (inst == 2 ? 0.5F : 1F), 0.7F);
        }
    }

    private void playColumn(int c) {
        for (int r = 0; r < ROWS; r++) if ((rows[r] >> (STEPS - 1 - c) & 1) != 0) play(r);
    }

    // ---------- save / load ----------
    private String encode() {
        StringBuilder sb = new StringBuilder().append(bpm).append(',').append(inst);
        for (int r : rows) sb.append(',').append(Integer.toHexString(r));
        return sb.toString();
    }

    private boolean decode(String s) {
        try {
            String[] p = s.split(",");
            if (p.length != ROWS + 2) return false;
            int b = Integer.parseInt(p[0]), in = Integer.parseInt(p[1]);
            int[] r = new int[ROWS];
            for (int i = 0; i < ROWS; i++) r[i] = Integer.parseInt(p[2 + i], 16) & 0xFFFF;
            bpm = Math.max(60, Math.min(180, b));
            inst = Math.max(0, Math.min(3, in));
            System.arraycopy(r, 0, rows, 0, ROWS);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String[] slots() {
        String[] out = {"", "", ""};
        try {
            String s = Store.read("beats");
            if (s != null) { String[] p = s.split(";", -1); for (int i = 0; i < SLOTS && i < p.length; i++) out[i] = p[i]; }
        } catch (Exception ignored) { }
        return out;
    }

    private void saveSlot() {
        String[] s = slots();
        s[slot] = encode();
        try { Store.write("beats", String.join(";", s)); } catch (Exception ignored) { }
        say("cutemod.beats.msg.saved", slot + 1);
    }

    private void loadSlot() {
        String s = slots()[slot];
        if (s.isEmpty() || !decode(s)) { say("cutemod.beats.msg.empty", slot + 1); return; }
        say("cutemod.beats.msg.loaded", slot + 1);
    }

    private void say(String key, Object... args) { msg = t(key, args); msgT = 150; }

    // ---------- logic ----------
    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        if (!playing) return;
        acc += 1;
        double step = 900.0 / bpm;                          // ticks per 16th note
        while (acc >= step) {
            acc -= step;
            playColumn(pos);
            pos = (pos + 1) % STEPS;
        }
    }

    private void toggle() {
        playing = !playing;
        if (playing) { pos = 0; acc = 900.0 / bpm; }       // the first column sounds at once
        else pos = 0;
    }

    // ---------- drawing ----------
    private static final int[] CTRL = {4, 52, 100};         // x of the groups on the control rows

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, BG);
        rect(g, 0, 0, W, 14, 0xFF2E1E5A);
        g.drawString(f, t("cutemod.os.beats"), 5, 3, 0xFFFFE9A8, false);
        String bp = t("cutemod.beats.bpm", bpm);
        g.drawString(f, bp, W - 6 - f.width(bp), 3, 0xFFE4D8FF, false);
        int col = playing ? (pos + STEPS - 1) % STEPS : -1;
        for (int r = 0; r < ROWS; r++) {
            int y = GY + r * (CH + 1) + (r >= DRUMS ? 3 : 0);
            String label = r < DRUMS ? t("cutemod.beats.row." + r) : noteName(NOTE[r - DRUMS]);
            g.drawString(f, label, GX - 4 - f.width(label), y + 2, ROW_COL[r], false);
            for (int c = 0; c < STEPS; c++) {
                int x = GX + c * CW;
                boolean on = (rows[r] >> (STEPS - 1 - c) & 1) != 0;
                int bg = c / 4 % 2 == 0 ? 0xFF2E2250 : 0xFF3A2C64;
                rect(g, x, y, CW - 1, CH, c == col ? 0xFF5A4A96 : bg);
                if (on) {
                    rect(g, x + 1, y + 1, CW - 3, CH - 2, c == col ? 0xFFFFFFFF : ROW_COL[r]);
                    rect(g, x + 1, y + 1, CW - 3, 2, 0x44FFFFFF);
                }
            }
        }
        // the beat dots over the grid
        for (int c = 0; c < STEPS; c++) rect(g, GX + c * CW + CW / 2 - 1, GY - 4, 2, 2, c == col ? 0xFFFFE066 : c % 4 == 0 ? 0xFF8A7AC0 : 0xFF4A3A7A);
        controls(g, f, mx, my);
        if (msgT > 0) {
            int w = f.width(msg) + 12, x = (W - w) / 2;
            rect(g, x, 128 - 0, w, 13, 0xEE000000);
            g.drawString(f, msg, x + 6, 131, 0xFFFFFFFF, false);
        }
    }

    private static String noteName(int n) {
        String[] names = {"F#", "G", "G#", "A", "A#", "B", "C", "C#", "D", "D#", "E", "F"};
        return names[Math.floorMod(n, 12)];
    }

    private static final int Y1 = 126, Y2 = 146;

    private void controls(GuiGraphics g, Font f, int mx, int my) {
        btn(g, f, mx, my, 4, Y1, 52, t(playing ? "cutemod.beats.stop" : "cutemod.beats.play"), playing ? 3 : 1);
        btn(g, f, mx, my, 60, Y1, 14, "-", 0);
        btn(g, f, mx, my, 76, Y1, 14, "+", 0);
        String[] names = {"cutemod.beats.inst.0", "cutemod.beats.inst.1", "cutemod.beats.inst.2", "cutemod.beats.inst.3"};
        for (int i = 0; i < 4; i++) btn(g, f, mx, my, 96 + i * 36, Y1, 34, t(names[i]), i == inst ? 1 : 0);
        btn(g, f, mx, my, 242, Y1, 54, t("cutemod.beats.clear"), 0);
        for (int i = 0; i < SLOTS; i++) btn(g, f, mx, my, 4 + i * 18, Y2, 16, Integer.toString(i + 1), i == slot ? 1 : 0);
        btn(g, f, mx, my, 62, Y2, 50, t("cutemod.beats.save"), 0);
        btn(g, f, mx, my, 114, Y2, 50, t("cutemod.beats.load"), slots()[slot].isEmpty() ? 2 : 0);
        btn(g, f, mx, my, 166, Y2, 50, t("cutemod.beats.demo"), 0);
    }

    /** style 0 normal, 1 selected / main, 2 dimmed, 3 warning (stop). */
    private void btn(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, String label, int style) {
        boolean hov = style != 2 && in(mx, my, x, y, w, 16);
        int bg = style == 1 ? (hov ? 0xFF9A6FD0 : ACCENT) : style == 2 ? 0xFF2E2250 : style == 3 ? 0xFFE5486F : hov ? 0xFF5A4A96 : 0xFF3A2C64;
        rect(g, x, y, w, 16, bg);
        rect(g, x, y + 14, w, 2, 0x33000000);
        String l = f.plainSubstrByWidth(label, w - 2);
        g.drawString(f, l, x + (w - f.width(l)) / 2, y + 4, style == 2 ? 0xFF6A5A90 : 0xFFFFFFFF, false);
    }

    // ---------- input ----------
    private int cellRow(int y) {
        for (int r = 0; r < ROWS; r++) {
            int cy = GY + r * (CH + 1) + (r >= DRUMS ? 3 : 0);
            if (y >= cy && y < cy + CH) return r;
        }
        return -1;
    }

    private int cellCol(int x) {
        int c = (x - GX) / CW;
        return x >= GX && c >= 0 && c < STEPS ? c : -1;
    }

    private void setCell(int r, int c, boolean on) {
        int bit = 1 << (STEPS - 1 - c);
        boolean was = (rows[r] & bit) != 0;
        if (was == on) return;
        rows[r] = on ? rows[r] | bit : rows[r] & ~bit;
        if (on) play(r);                                        // a click gives a preview of the sound
    }

    @Override
    public boolean click(int x, int y, int button) {
        int r = cellRow(y), c = cellCol(x);
        if (r >= 0 && c >= 0) {
            paint = (rows[r] >> (STEPS - 1 - c) & 1) == 0;       // the first cell decides: paint or erase while dragging
            setCell(r, c, paint);
            return true;
        }
        if (y >= Y1 && y < Y1 + 16) {
            if (in(x, y, 4, Y1, 52, 16)) { toggle(); return true; }
            if (in(x, y, 60, Y1, 14, 16)) { bpm = Math.max(60, bpm - 5); return true; }
            if (in(x, y, 76, Y1, 14, 16)) { bpm = Math.min(180, bpm + 5); return true; }
            for (int i = 0; i < 4; i++) if (in(x, y, 96 + i * 36, Y1, 34, 16)) { inst = i; play(DRUMS + 2); return true; }
            if (in(x, y, 242, Y1, 54, 16)) { java.util.Arrays.fill(rows, 0); return true; }
        } else if (y >= Y2 && y < Y2 + 16) {
            for (int i = 0; i < SLOTS; i++) if (in(x, y, 4 + i * 18, Y2, 16, 16)) { slot = i; return true; }
            if (in(x, y, 62, Y2, 50, 16)) { saveSlot(); return true; }
            if (in(x, y, 114, Y2, 50, 16)) { loadSlot(); return true; }
            if (in(x, y, 166, Y2, 50, 16)) { System.arraycopy(DEMO, 0, rows, 0, ROWS); bpm = 110; inst = 0; say("cutemod.beats.msg.demo"); return true; }
        }
        return false;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        int r = cellRow(y), c = cellCol(x);
        if (r >= 0 && c >= 0) setCell(r, c, paint);
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (keyCode == 32) { toggle(); return true; }           // space = play / stop
        return false;
    }
}
