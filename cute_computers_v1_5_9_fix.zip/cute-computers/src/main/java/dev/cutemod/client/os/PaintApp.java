package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.Arrays;

/** Pixel paint. The picture stays while the game is running. */
public class PaintApp extends App {
    private static final int GW = 64, GH = 36, CS = 4;
    private static final int OX = 4, OY = (H - GH * CS) / 2;
    private static final int PX = OX + GW * CS + 4;
    static final int[] PALETTE = {
            0xFF3A2A3A, 0xFFFFFFFF, 0xFFE5484D, 0xFFF58FB8, 0xFFF5A623, 0xFFF3D46A, 0xFF8FD39A,
            0xFF2E9E5B, 0xFF8EC3F2, 0xFF2F7FD6, 0xFFB57BD6, 0xFF6B4A2B, 0xFFB0A8B8, 0xFF4A3A66};
    private static final int[] PIXELS = new int[GW * GH]; // 0 = empty

    private int selected = 0;
    private int lastX = -1, lastY = -1;

    /** Does the canvas have anything on it? */
    public static boolean hasPicture() {
        for (int c : PIXELS) if (c != 0) return true;
        return false;
    }

    /** The picture packed for the mail: two pixels per byte, 0 = empty, 1..14 = palette colour. */
    public static byte[] snapshot() {
        byte[] out = new byte[GW * GH / 2];
        for (int i = 0; i < PIXELS.length; i++) {
            int idx = 0;
            for (int k = 0; k < PALETTE.length; k++) if (PALETTE[k] == PIXELS[i]) { idx = k + 1; break; }
            out[i / 2] |= (byte) ((i % 2 == 0) ? idx << 4 : idx);
        }
        return out;
    }

    /** Draws a packed picture (see snapshot) with every pixel scale x scale, or step-sampled when scale is 1 and step is 2. */
    public static void drawPacked(GuiGraphics g, byte[] d, int x, int y, int scale, int step) {
        if (d.length != GW * GH / 2) return;
        rect(g, x - 1, y - 1, GW / step * scale + 2, GH / step * scale + 2, 0xFF3A2A3A);
        rect(g, x, y, GW / step * scale, GH / step * scale, 0xFFFFFFFF);
        for (int py = 0; py < GH; py += step) {
            for (int px = 0; px < GW; px += step) {
                int i = py * GW + px;
                int idx = (i % 2 == 0) ? (d[i / 2] >> 4) & 15 : d[i / 2] & 15;
                if (idx > 0 && idx <= PALETTE.length) rect(g, x + px / step * scale, y + py / step * scale, scale, scale, PALETTE[idx - 1]);
            }
        }
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.paint"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.paint"); }

    private static int swX(int i) { return PX + (i % 2) * 16; }

    private static int swY(int i) { return OY + (i / 2) * 16; }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        rect(g, 0, 0, W, H, 0xFFE9DDF2);
        rect(g, OX - 1, OY - 1, GW * CS + 2, GH * CS + 2, 0xFF3A2A3A);
        rect(g, OX, OY, GW * CS, GH * CS, 0xFFFFFFFF);
        for (int y = 0; y < GH; y++) {
            for (int x = 0; x < GW; x++) {
                int c = PIXELS[y * GW + x];
                if (c != 0) rect(g, OX + x * CS, OY + y * CS, CS, CS, c);
            }
        }
        for (int i = 0; i < PALETTE.length; i++) {
            int x = swX(i), y = swY(i);
            rect(g, x - 1, y - 1, 15, 15, i == selected ? 0xFFFFFFFF : 0xFF3A2A3A);
            if (i == selected) rect(g, x, y, 13, 13, 0xFF3A2A3A);
            rect(g, x + (i == selected ? 1 : 0), y + (i == selected ? 1 : 0),
                    13 - (i == selected ? 2 : 0), 13 - (i == selected ? 2 : 0), PALETTE[i]);
        }
        int by = swY(PALETTE.length - 1) + 18;
        boolean hover = in(mx, my, PX, by, 32, 14);
        rect(g, PX, by, 32, 14, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
        String s = t("cutemod.os.paint.clear");
        g.drawString(font(), s, PX + (32 - font().width(s)) / 2, by + 3, 0xFF3A2A3A, false);
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < PALETTE.length; i++) {
            if (in(x, y, swX(i), swY(i), 14, 14)) { selected = i; return true; }
        }
        int by = swY(PALETTE.length - 1) + 18;
        if (in(x, y, PX, by, 32, 14)) { Arrays.fill(PIXELS, 0); return true; }
        lastX = -1;
        paint(x, y, button);
        return true;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        paint(x, y, button);
        return true;
    }

    private void paint(int x, int y, int button) {
        int cx = Math.floorDiv(x - OX, CS), cy = Math.floorDiv(y - OY, CS);
        if (cx < 0 || cy < 0 || cx >= GW || cy >= GH) { lastX = -1; return; }
        int val = button == 1 ? 0 : PALETTE[selected];
        if (lastX < 0) {
            PIXELS[cy * GW + cx] = val;
        } else {
            int dx = cx - lastX, dy = cy - lastY, n = Math.max(Math.abs(dx), Math.abs(dy));
            for (int i = 0; i <= n; i++) {
                int px = n == 0 ? cx : lastX + Math.round((float) dx * i / n);
                int py = n == 0 ? cy : lastY + Math.round((float) dy * i / n);
                if (px >= 0 && py >= 0 && px < GW && py < GH) PIXELS[py * GW + px] = val;
            }
        }
        lastX = cx;
        lastY = cy;
        if (Progress.step() == 10) { // story, part 2: count the painted pixels
            int n = 0;
            for (int px : PIXELS) if (px != 0) n++;
            Progress.onPaint(n);
        }
    }
}
