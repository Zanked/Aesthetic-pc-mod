package dev.cutemod.client.game;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The rules and the computer player of Russian draughts (shashki). No Minecraft classes in here, so it can be tested alone.
 * <ul>
 *   <li>8 x 8, the pieces stand on the dark squares; white is at the bottom (rows 5-7) and moves up.</li>
 *   <li>A man moves one square forward, captures forward <b>and backward</b>. A king ("damka") flies along a diagonal.</li>
 *   <li>Capturing is a must. A capture must be finished (all jumps); any route may be chosen, not only the longest one.</li>
 *   <li>A man that reaches the last row in the middle of a capture becomes a king and keeps capturing as a king.</li>
 *   <li>Captured pieces are taken off after the move: they block the way and cannot be jumped twice (the Turkish strike).</li>
 * </ul>
 * Board: int[64], index = row * 8 + col. 0 empty, 1 / 2 white man / king, -1 / -2 black man / king.
 */
public final class CheckersEngine {
    private CheckersEngine() {}

    private static final int[] DR = {-1, -1, 1, 1}, DC = {-1, 1, -1, 1};

    /** One legal move: the piece goes from "from" over the landing squares "to" (one square for a plain move), taking "caps". */
    public record Move(int from, int[] to, int[] caps) {
        public int end() { return to[to.length - 1]; }
    }

    public static int[] start() {
        int[] b = new int[64];
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            if ((r + c) % 2 == 0) continue;
            if (r < 3) b[r * 8 + c] = -1;
            else if (r > 4) b[r * 8 + c] = 1;
        }
        return b;
    }

    private static boolean inb(int r, int c) { return r >= 0 && r < 8 && c >= 0 && c < 8; }

    private static boolean mine(int p, boolean white) { return white ? p > 0 : p < 0; }

    private static boolean theirs(int p, boolean white) { return white ? p < 0 : p > 0; }

    private static int promoRow(boolean white) { return white ? 0 : 7; }

    // ---------- move generation ----------
    public static List<Move> moves(int[] b, boolean white) {
        List<Move> out = new ArrayList<>();
        for (int s = 0; s < 64; s++) if (mine(b[s], white)) captures(b, s, white, out);
        if (!out.isEmpty()) return out;            // capturing is a must
        for (int s = 0; s < 64; s++) if (mine(b[s], white)) plain(b, s, white, out);
        return out;
    }

    public static boolean mustCapture(List<Move> moves) {
        return !moves.isEmpty() && moves.get(0).caps().length > 0;
    }

    private static void plain(int[] b, int s, boolean white, List<Move> out) {
        int r = s / 8, c = s % 8;
        boolean king = Math.abs(b[s]) == 2;
        for (int d = 0; d < 4; d++) {
            if (!king && (DR[d] < 0) != white) continue;           // a man only goes forward
            int rr = r + DR[d], cc = c + DC[d];
            while (inb(rr, cc) && b[rr * 8 + cc] == 0) {
                out.add(new Move(s, new int[]{rr * 8 + cc}, new int[0]));
                if (!king) break;
                rr += DR[d];
                cc += DC[d];
            }
        }
    }

    private static void captures(int[] b, int from, boolean white, List<Move> out) {
        int[] work = b.clone();
        boolean king = Math.abs(work[from]) == 2;
        work[from] = 0;                                              // the piece is in the air: its square is empty
        dfs(work, from, king, white, new int[16], 0, new int[16], 0, 0L, from, out);
    }

    /** True if a piece standing on pos (king or not) can still jump something. capMask = squares already jumped. */
    private static boolean hasCapture(int[] w, int pos, boolean king, boolean white, long capMask) {
        int r = pos / 8, c = pos % 8;
        for (int d = 0; d < 4; d++) {
            int rr = r + DR[d], cc = c + DC[d];
            if (king) while (inb(rr, cc) && w[rr * 8 + cc] == 0) { rr += DR[d]; cc += DC[d]; }
            if (!inb(rr, cc)) continue;
            int s = rr * 8 + cc;
            if (!theirs(w[s], white) || (capMask >> s & 1) != 0) continue;
            int r2 = rr + DR[d], c2 = cc + DC[d];
            if (inb(r2, c2) && w[r2 * 8 + c2] == 0) return true;
        }
        return false;
    }

    private static void dfs(int[] w, int pos, boolean king, boolean white, int[] land, int nl, int[] caps, int nc,
                            long capMask, int from, List<Move> out) {
        boolean any = false;
        int r = pos / 8, c = pos % 8;
        for (int d = 0; d < 4; d++) {
            int rr = r + DR[d], cc = c + DC[d];
            if (king) while (inb(rr, cc) && w[rr * 8 + cc] == 0) { rr += DR[d]; cc += DC[d]; }
            if (!inb(rr, cc)) continue;
            int s = rr * 8 + cc;
            if (!theirs(w[s], white) || (capMask >> s & 1) != 0) continue;
            // the squares behind the jumped piece
            List<Integer> spots = new ArrayList<>();
            int r2 = rr + DR[d], c2 = cc + DC[d];
            while (inb(r2, c2) && w[r2 * 8 + c2] == 0) {
                spots.add(r2 * 8 + c2);
                if (!king) break;
                r2 += DR[d];
                c2 += DC[d];
            }
            if (spots.isEmpty()) continue;
            any = true;
            long mask2 = capMask | 1L << s;
            // a flying king must stop where it can go on capturing, if there is such a square
            List<Integer> choice = new ArrayList<>();
            for (int sp : spots) {
                boolean k2 = king || sp / 8 == promoRow(white);
                if (hasCapture(w, sp, k2, white, mask2)) choice.add(sp);
            }
            if (choice.isEmpty()) choice = spots;
            for (int sp : choice) {
                boolean k2 = king || sp / 8 == promoRow(white);
                land[nl] = sp;
                caps[nc] = s;
                dfs(w, sp, k2, white, land, nl + 1, caps, nc + 1, mask2, from, out);
            }
        }
        if (!any && nl > 0) {
            int[] to = new int[nl], cp = new int[nc];
            System.arraycopy(land, 0, to, 0, nl);
            System.arraycopy(caps, 0, cp, 0, nc);
            out.add(new Move(from, to, cp));
        }
    }

    /** The board after the move (a new array). */
    public static int[] apply(int[] b, Move m) {
        int[] nb = b.clone();
        int p = nb[m.from()];
        boolean white = p > 0;
        boolean king = Math.abs(p) == 2;
        nb[m.from()] = 0;
        for (int cp : m.caps()) nb[cp] = 0;
        for (int sq : m.to()) if (sq / 8 == promoRow(white)) king = true;
        nb[m.end()] = white ? (king ? 2 : 1) : (king ? -2 : -1);
        return nb;
    }

    public static int count(int[] b, boolean white) {
        int n = 0;
        for (int p : b) if (mine(p, white)) n++;
        return n;
    }

    // ---------- the computer player ----------
    private static final int MATE = 100000;

    /** The value of the board for white (a man is 100, a king 320, plus small bonuses). */
    public static int eval(int[] b) {
        int v = 0;
        for (int s = 0; s < 64; s++) {
            int p = b[s];
            if (p == 0) continue;
            int r = s / 8, c = s % 8;
            boolean white = p > 0;
            int val;
            if (Math.abs(p) == 2) {
                val = 320 + (c >= 2 && c <= 5 && r >= 2 && r <= 5 ? 6 : 0);
            } else {
                int adv = white ? 7 - r : r;                     // rows walked forward
                val = 100 + adv * 4 + (c >= 2 && c <= 5 ? 3 : 0);
                if (adv == 0) val += 7;                          // the back rank keeps the enemy from a king
                if (adv == 6) val += 8;                          // one step from a king
            }
            v += white ? val : -val;
        }
        return v;
    }

    private static final class Search {
        long deadline;
        long nodes, maxNodes;
        boolean stop;
        final Random rnd;
        final int noise;

        Search(long deadline, long maxNodes, Random rnd, int noise) {
            this.deadline = deadline;
            this.maxNodes = maxNodes;
            this.rnd = rnd;
            this.noise = noise;
        }

        boolean tired() {
            if ((++nodes & 1023) == 0 && (System.nanoTime() > deadline || nodes > maxNodes)) stop = true;
            return stop;
        }

        /** Negamax with alpha-beta. The score is for the side to move. */
        int go(int[] b, boolean white, int depth, int ply, int alpha, int beta) {
            if (tired()) return 0;
            List<Move> ms = moves(b, white);
            if (ms.isEmpty()) return -MATE + ply;                        // no moves: this side lost
            boolean forced = mustCapture(ms);
            if (depth <= 0 && (!forced || ply > 40)) return white ? eval(b) : -eval(b);
            ms.sort((x, y) -> y.caps().length - x.caps().length);
            int best = -MATE * 2;
            for (Move m : ms) {
                int v = -go(apply(b, m), !white, depth - 1, ply + 1, -beta, -alpha);
                if (stop) return 0;
                if (v > best) best = v;
                if (best > alpha) alpha = best;
                if (alpha >= beta) break;
            }
            return best;
        }
    }

    /**
     * Picks a move. level 0 easy (sees one move ahead, and sometimes just plays something), 1 normal, 2 hard.
     * Takes up to about 1.5 seconds on the hard level, so call it from a thread.
     */
    public static Move best(int[] b, boolean white, int level, Random rnd) {
        List<Move> ms = moves(b, white);
        if (ms.isEmpty()) return null;
        if (ms.size() == 1) return ms.get(0);
        if (level <= 0) {
            if (rnd.nextInt(100) < 45) return ms.get(rnd.nextInt(ms.size()));
            return pick(b, white, ms, 1, 4000, 100, 0, rnd);
        }
        if (level == 1) return pick(b, white, ms, 5, 60000, 450, 4, rnd);
        return pick(b, white, ms, 12, 900000, 1500, 0, rnd);
    }

    private static Move pick(int[] b, boolean white, List<Move> ms, int maxDepth, long maxNodes, long millis, int noise, Random rnd) {
        Search s = new Search(System.nanoTime() + millis * 1_000_000L, maxNodes, rnd, noise);
        Move best = ms.get(0);
        List<Move> order = new ArrayList<>(ms);
        java.util.Collections.shuffle(order, rnd);                   // equal moves: not always the first one
        for (int depth = 1; depth <= maxDepth; depth++) {
            int bestV = -MATE * 2;
            Move bestHere = null;
            for (Move m : order) {
                // without noise a move only has to beat the best so far, so the window can be narrow
                int lo = noise == 0 ? bestV : -MATE * 2;
                int v = -s.go(apply(b, m), !white, depth - 1, 1, -MATE * 2, -lo);
                if (s.stop) break;
                if (noise > 0) v += rnd.nextInt(noise * 2 + 1) - noise;
                if (v > bestV) { bestV = v; bestHere = m; }
            }
            if (s.stop) break;                       // an unfinished depth is thrown away
            best = bestHere;
            order.remove(bestHere);
            order.add(0, bestHere);                  // try the best move first on the next depth
            if (Math.abs(bestV) > MATE / 2) break;   // a forced win or loss is found
        }
        return best;
    }
}
