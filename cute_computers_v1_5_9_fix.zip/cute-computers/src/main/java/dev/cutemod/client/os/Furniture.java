package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/**
 * Furniture for the pet's room (Tamagotchi app). The room has 5 places: a rug on the floor, two on the wall, two on the floor.
 * Every place shows one piece at a time. Pieces are bought with coins (Progress.buy, ids start with "furn_") and the chosen
 * piece of each place is saved in the Progress counters room_0 .. room_4 (index in the place's list + 1, 0 = empty).
 * Everything is drawn with rectangles, the same way as the pets. Names: cutemod.shop.item.&lt;id&gt;.
 */
final class Furniture {
    private Furniture() {}

    static final int ZONES = 5;
    /** Where each place is: the centre for the rug and the wall, the middle of the feet for the floor. */
    static final int[] AX = {150, 96, 246, 86, 240};
    static final int[] AY = {128, 52, 56, 124, 124};

    record Item(String id, int zone, int price, int w, int h) {}

    static final Item[] ALL = {
            new Item("furn_rug_pink", 0, 15, 96, 14), new Item("furn_rug_blue", 0, 15, 96, 14),
            new Item("furn_rug_star", 0, 30, 96, 14), new Item("furn_rug_grass", 0, 25, 96, 14),
            new Item("furn_clock", 1, 15, 20, 20), new Item("furn_frame", 1, 20, 24, 20),
            new Item("furn_banner", 1, 20, 42, 16), new Item("furn_neon", 1, 35, 21, 18),
            new Item("furn_poster", 2, 25, 20, 28), new Item("furn_lights", 2, 30, 84, 20),
            new Item("furn_books", 2, 30, 44, 24), new Item("furn_window", 2, 40, 30, 26),
            new Item("furn_plant", 3, 15, 24, 40), new Item("furn_lamp", 3, 25, 28, 44),
            new Item("furn_cactus", 3, 15, 18, 30), new Item("furn_teddy", 3, 30, 22, 24),
            new Item("furn_bed", 4, 40, 62, 28), new Item("furn_sofa", 4, 55, 62, 32),
            new Item("furn_bookcase", 4, 45, 38, 52), new Item("furn_toybox", 4, 30, 36, 24),
            new Item("furn_piano", 4, 80, 62, 42)};

    static List<Item> zone(int z) {
        List<Item> l = new ArrayList<>();
        for (Item it : ALL) if (it.zone() == z) l.add(it);
        return l;
    }

    static int placedIndex(int z) { return Progress.count("room_" + z) - 1; }

    static boolean isPlaced(int z, int idx) { return placedIndex(z) == idx; }

    static int ownedCount() {
        int n = 0;
        for (Item it : ALL) if (Progress.owned(it.id())) n++;
        return n;
    }

    /** Draws the pieces that stand in the room (called by the pet screen before the pet). */
    static void drawRoom(GuiGraphics g, int ticks) {
        for (int z = 0; z < ZONES; z++) {
            List<Item> l = zone(z);
            int idx = placedIndex(z);
            if (idx < 0 || idx >= l.size() || !Progress.owned(l.get(idx).id())) continue;
            draw(g, l.get(idx).id(), AX[z], AY[z], ticks);
        }
    }

    // ---------- helpers ----------
    private static void r(GuiGraphics g, int x, int y, int w, int h, int c) { Skin.rect(g, x, y, w, h, c); }

    private static void d(GuiGraphics g, int x, int y, int rad, int c) { Skin.disc(g, x, y, rad, c); }

    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int c) {
        for (int dy = -ry; dy <= ry; dy++) {
            int half = (int) Math.round(rx * Math.sqrt(1.0 - (double) (dy * dy) / (ry * ry + 0.5)));
            r(g, cx - half, cy + dy, half * 2 + 1, 1, c);
        }
    }

    private static int shade(int c, float f) { return App.mix(c, f < 0 ? 0xFF000000 : 0xFFFFFFFF, Math.abs(f)); }

    private static void hand(GuiGraphics g, int cx, int cy, double ang, int len, int c) {
        for (int i = 1; i <= len; i++) r(g, cx + (int) Math.round(Math.sin(ang) * i), cy - (int) Math.round(Math.cos(ang) * i), 1, 1, c);
    }

    /** Draws one piece. (x, y) is the centre for the rug and wall pieces and the middle of the feet for the floor pieces. */
    static void draw(GuiGraphics g, String id, int x, int y, int t) {
        switch (id) {
            case "furn_rug_pink" -> rug(g, x, y, 0xFFE58AAE, 0xFFFFC2D9, 0xFFF58FB8, 0);
            case "furn_rug_blue" -> rug(g, x, y, 0xFF5A8FD0, 0xFFBFDDFF, 0xFF8FBFF0, 0);
            case "furn_rug_star" -> rug(g, x, y, 0xFFB08A2E, 0xFFFFE9A0, 0xFFF3D46A, 1);
            case "furn_rug_grass" -> rug(g, x, y, 0xFF4E9F3E, 0xFFA8E08C, 0xFF7FCB6A, 2);
            case "furn_clock" -> clock(g, x, y);
            case "furn_frame" -> frame(g, x, y);
            case "furn_banner" -> banner(g, x, y);
            case "furn_neon" -> neon(g, x, y, t);
            case "furn_poster" -> poster(g, x, y);
            case "furn_lights" -> lights(g, x, y, t);
            case "furn_books" -> books(g, x, y);
            case "furn_window" -> window(g, x, y);
            case "furn_plant" -> plant(g, x, y, t);
            case "furn_lamp" -> lamp(g, x, y);
            case "furn_cactus" -> cactus(g, x, y);
            case "furn_teddy" -> teddy(g, x, y);
            case "furn_bed" -> bed(g, x, y);
            case "furn_sofa" -> sofa(g, x, y);
            case "furn_bookcase" -> bookcase(g, x, y);
            case "furn_toybox" -> toybox(g, x, y);
            case "furn_piano" -> piano(g, x, y);
            default -> { }
        }
    }

    // ---------- the rug ----------
    private static void rug(GuiGraphics g, int cx, int cy, int edge, int mid, int in, int kind) {
        oval(g, cx, cy, 48, 7, edge);
        oval(g, cx, cy, 43, 6, mid);
        oval(g, cx, cy, 35, 4, in);
        if (kind == 1) {                                                   // a golden star in the middle
            r(g, cx - 1, cy - 3, 3, 7, 0xFFFFFFFF); r(g, cx - 5, cy - 1, 11, 3, 0xFFFFFFFF); r(g, cx - 3, cy - 2, 7, 5, 0xFFFFFFFF);
        } else if (kind == 2) {                                            // flowers in the grass
            int[][] f = {{-26, -1}, {-12, 2}, {10, -2}, {24, 1}, {0, -3}};
            for (int i = 0; i < f.length; i++) { r(g, cx + f[i][0], cy + f[i][1], 2, 2, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFF8FB8); }
        } else {
            for (int k = -2; k <= 2; k++) r(g, cx + k * 12, cy - 1, 4, 2, edge);   // a row of stitches
        }
    }

    // ---------- the wall ----------
    private static void clock(GuiGraphics g, int cx, int cy) {
        d(g, cx, cy, 10, 0xFF7A5230);
        d(g, cx, cy, 9, 0xFFFFFFFF);
        for (int i = 0; i < 12; i++) {
            double a = i * Math.PI / 6;
            r(g, cx + (int) Math.round(Math.sin(a) * 7), cy - (int) Math.round(Math.cos(a) * 7), 1, 1, 0xFF3A2A3A);
        }
        java.time.LocalTime now = java.time.LocalTime.now();
        hand(g, cx, cy, (now.getHour() % 12 + now.getMinute() / 60.0) * Math.PI / 6, 4, 0xFF3A2A3A);
        hand(g, cx, cy, (now.getMinute() + now.getSecond() / 60.0) * Math.PI / 30, 6, 0xFF3A2A3A);
        hand(g, cx, cy, now.getSecond() * Math.PI / 30, 7, 0xFFE5484D);
        r(g, cx, cy, 1, 1, 0xFF3A2A3A);
    }

    private static void frame(GuiGraphics g, int cx, int cy) {
        r(g, cx - 12, cy - 10, 24, 20, 0xFF8A5A3A);
        r(g, cx - 10, cy - 8, 20, 16, 0xFFFFF3D8);
        r(g, cx - 10, cy + 3, 20, 5, 0xFFA8E08C);                         // grass
        r(g, cx - 5, cy - 2, 1, 6, 0xFF4E9F3E); r(g, cx + 4, cy - 1, 1, 5, 0xFF4E9F3E);
        d(g, cx - 5, cy - 3, 2, 0xFFFF8FB8); d(g, cx + 4, cy - 2, 2, 0xFFFFD84D);
        r(g, cx - 1, cy - 6, 2, 2, 0xFFFFC832);                           // a sun
    }

    private static void banner(GuiGraphics g, int cx, int cy) {
        int[] cols = {0xFFFF5C93, 0xFFFFD84D, 0xFF5BD9C8, 0xFF8FB8FF, 0xFFB57BD6};
        r(g, cx - 21, cy - 7, 42, 1, 0xFF6B4F35);
        for (int i = 0; i < 5; i++) {
            int x0 = cx - 20 + i * 8;
            for (int k = 0; k < 7; k++) r(g, x0 + k / 2, cy - 6 + k, 7 - k, 1, cols[i]);
        }
    }

    private static void neon(GuiGraphics g, int cx, int cy, int t) {
        double p = 0.5 + 0.5 * Math.sin(t / 25.0);
        int core = App.mix(0xFFFF5C93, 0xFFFFC2D9, (float) p);
        r(g, cx - 13, cy - 11, 27, 24, 0x18FF5C93);                        // the glow
        int[][] rows = {{1, 2}, {4, 2}, {0, 7}, {0, 7}, {1, 5}, {2, 3}, {3, 1}};
        for (int i = 0; i < rows.length; i++) r(g, cx - 10 + rows[i][0] * 3, cy - 9 + i * 3, rows[i][1] * 3, 3, core);
    }

    private static void poster(GuiGraphics g, int cx, int cy) {
        r(g, cx - 11, cy - 15, 22, 30, 0xFFE9DDF2);
        r(g, cx - 10, cy - 14, 20, 28, 0xFF1B2250);
        int[][] st = {{-7, -11}, {5, -9}, {-3, -5}, {7, 1}, {-8, 4}, {2, 10}};
        for (int[] s : st) r(g, cx + s[0], cy + s[1], 1, 1, 0xFFFFFFFF);
        d(g, cx - 2, cy - 1, 5, 0xFFE58A4E); d(g, cx - 4, cy - 3, 1, 0xFFF3B27A);
        r(g, cx - 8, cy, 13, 1, 0xFFFFD9A8);                              // the ring
        r(g, cx + 3, cy + 5, 3, 7, 0xFFE9E9F2); r(g, cx + 4, cy + 3, 1, 2, 0xFFE9E9F2); r(g, cx + 3, cy + 12, 3, 2, 0xFFFF5C93);   // a rocket
    }

    private static void lights(GuiGraphics g, int cx, int cy, int t) {
        int[] cols = {0xFFFF5C93, 0xFFFFD84D, 0xFF5BD9C8, 0xFF8FB8FF, 0xFFFFFFFF};
        for (int dx = -42; dx <= 42; dx++) r(g, cx + dx, cy - 9 + dx * dx / 240, 1, 1, 0xFF3A3A44);
        for (int i = 0; i < 9; i++) {
            int dx = -40 + i * 10, by = cy - 9 + dx * dx / 240 + 1;
            boolean on = (t / 25 + i) % 3 != 0;
            int c = cols[i % cols.length];
            if (on) r(g, cx + dx - 2, by - 1, 5, 7, (c & 0xFFFFFF) | 0x33000000);
            r(g, cx + dx - 1, by, 3, 4, on ? c : App.mix(c, 0xFF202028, 0.6f));
        }
    }

    private static void books(GuiGraphics g, int cx, int cy) {
        r(g, cx - 22, cy + 8, 44, 3, 0xFF8A5A3A);
        r(g, cx - 22, cy + 11, 44, 1, 0xFF6B4F35);
        int[] cols = {0xFFE5534B, 0xFF4A90D8, 0xFFF0B90B, 0xFF4CAF50, 0xFFB57BD6, 0xFFFF8FB8};
        int[] hs = {14, 17, 12, 16, 13};
        int x = cx - 20;
        for (int i = 0; i < 5; i++) { r(g, x, cy + 8 - hs[i], 4, hs[i], cols[i]); r(g, x + 1, cy + 10 - hs[i], 2, 1, 0x66FFFFFF); x += 5; }
        r(g, x + 1, cy + 8 - 11, 10, 3, cols[5]);                          // a book lying down
        r(g, x + 1, cy + 8 - 8, 10, 3, cols[0]);
        d(g, cx + 16, cy - 4 + 8, 3, 0xFF5BBF6A); r(g, cx + 14, cy + 8 - 3, 5, 3, 0xFFB5651D);     // a tiny plant
    }

    private static void window(GuiGraphics g, int cx, int cy) {
        r(g, cx - 15, cy - 13, 30, 26, 0xFF8A6A4A);
        r(g, cx - 13, cy - 11, 26, 22, 0xFF9AD8FF);
        r(g, cx - 1, cy - 11, 2, 22, 0xFF8A6A4A); r(g, cx - 13, cy - 1, 26, 2, 0xFF8A6A4A);
        r(g, cx - 10, cy - 8, 6, 2, 0xFFFFFFFF); r(g, cx + 4, cy + 3, 7, 2, 0xFFFFFFFF);
        r(g, cx - 17, cy - 13, 7, 26, 0xFFE58AAE); r(g, cx + 10, cy - 13, 7, 26, 0xFFE58AAE);
        r(g, cx - 14, cy - 13, 1, 26, 0xFFC0587F); r(g, cx + 13, cy - 13, 1, 26, 0xFFC0587F);
    }

    // ---------- the floor, left ----------
    private static void pot(GuiGraphics g, int cx, int by, int w, int h) {
        r(g, cx - w / 2, by - h, w, 3, 0xFFC0703A);
        r(g, cx - w / 2 + 1, by - h + 3, w - 2, h - 3, 0xFFB5651D);
        r(g, cx - w / 2 + 3, by - h + 3, 2, h - 3, 0x33FFFFFF);
    }

    private static void plant(GuiGraphics g, int cx, int by, int t) {
        pot(g, cx, by, 14, 10);
        int sway = (int) Math.round(Math.sin(t / 40.0));
        int[][] lf = {{-6, -22}, {6, -24}, {0, -32}, {-9, -14}, {9, -16}};
        for (int[] l : lf) {
            int x = cx + l[0] + (l[1] < -20 ? sway : 0), y = by + l[1];
            r(g, cx + l[0] / 3, y + 6, 1, -l[1] - 16, 0xFF3F8F34);
            d(g, x, y, 5, 0xFF5BBF6A); d(g, x - 1, y - 1, 2, 0xFF8FDC84);
        }
    }

    private static void lamp(GuiGraphics g, int cx, int by) {
        r(g, cx - 14, by - 46, 28, 36, 0x16FFE08A); r(g, cx - 20, by - 40, 40, 28, 0x10FFE08A);   // warm light
        oval(g, cx, by - 2, 8, 2, 0xFF5A4A66);
        r(g, cx - 1, by - 34, 3, 32, 0xFF6A5A76);
        for (int k = 0; k < 12; k++) r(g, cx - 5 - k / 2, by - 46 + k, 11 + k, 1, k < 2 ? 0xFFFFF3B0 : 0xFFFFE08A);
        r(g, cx - 9, by - 34, 19, 1, 0xFFE0B84A);
    }

    private static void cactus(GuiGraphics g, int cx, int by) {
        pot(g, cx, by, 14, 9);
        r(g, cx - 3, by - 28, 7, 20, 0xFF4E9F3E); r(g, cx - 2, by - 29, 5, 1, 0xFF4E9F3E);
        r(g, cx - 8, by - 22, 5, 3, 0xFF4E9F3E); r(g, cx - 8, by - 26, 3, 5, 0xFF4E9F3E);
        r(g, cx + 4, by - 18, 5, 3, 0xFF4E9F3E); r(g, cx + 7, by - 22, 3, 5, 0xFF4E9F3E);
        r(g, cx - 1, by - 27, 1, 16, 0xFF7FCB6A);
        for (int i = 0; i < 5; i++) r(g, cx + (i % 2) * 2 - 2, by - 24 + i * 3, 1, 1, 0xFFFFFFFF);
        d(g, cx, by - 31, 2, 0xFFFF5C93); r(g, cx, by - 31, 1, 1, 0xFFFFD84D);
    }

    private static void teddy(GuiGraphics g, int cx, int by) {
        int br = 0xFFB5793A, lt = 0xFFD9A468;
        oval(g, cx, by - 1, 9, 2, 0x22000000);
        d(g, cx - 7, by - 3, 3, br); d(g, cx + 7, by - 3, 3, br);          // feet
        d(g, cx, by - 9, 8, br); d(g, cx, by - 8, 5, lt);                   // body
        d(g, cx - 9, by - 11, 3, br); d(g, cx + 9, by - 11, 3, br);        // arms
        d(g, cx, by - 19, 7, br);                                           // head
        d(g, cx - 6, by - 24, 3, br); d(g, cx + 6, by - 24, 3, br);
        d(g, cx - 6, by - 24, 1, lt); d(g, cx + 6, by - 24, 1, lt);
        d(g, cx, by - 17, 3, lt); r(g, cx - 1, by - 18, 3, 2, 0xFF3A2A3A);
        r(g, cx - 4, by - 21, 2, 2, 0xFF3A2A3A); r(g, cx + 3, by - 21, 2, 2, 0xFF3A2A3A);
        r(g, cx - 4, by - 12, 9, 2, 0xFFE5484D); r(g, cx - 1, by - 12, 3, 4, 0xFFC03030);   // a red bow
    }

    // ---------- the floor, right ----------
    private static void bed(GuiGraphics g, int cx, int by) {
        int x0 = cx - 31;
        r(g, x0 + 2, by - 4, 4, 4, 0xFF6B4F35); r(g, x0 + 56, by - 4, 4, 4, 0xFF6B4F35);                 // feet
        r(g, x0, by - 26, 5, 26, 0xFF8A5A3A); r(g, x0 + 1, by - 26, 3, 1, 0xFFB0825A);                   // headboard
        r(g, x0 + 5, by - 12, 55, 8, 0xFF8A5A3A);                                                       // frame
        r(g, x0 + 5, by - 18, 55, 7, 0xFFF3F0FA);                                                       // mattress
        r(g, x0 + 20, by - 19, 41, 8, 0xFFF58FB8); r(g, x0 + 20, by - 19, 41, 2, 0xFFFFC2D9);           // blanket
        for (int i = 0; i < 4; i++) { r(g, x0 + 26 + i * 9, by - 15, 3, 1, 0xFFFFFFFF); }
        r(g, x0 + 7, by - 22, 14, 6, 0xFFFFFFFF); r(g, x0 + 7, by - 22, 14, 1, 0xFFE9DDF2);             // pillow
        r(g, x0 + 57, by - 17, 4, 13, 0xFF8A5A3A);                                                      // footboard
    }

    private static void sofa(GuiGraphics g, int cx, int by) {
        int x0 = cx - 31, c = 0xFFB57BD6, lt = shade(c, 0.25f), dk = shade(c, -0.25f);
        r(g, x0 + 3, by - 3, 4, 3, 0xFF4A3A55); r(g, x0 + 55, by - 3, 4, 3, 0xFF4A3A55);
        r(g, x0 + 4, by - 32, 54, 20, c); r(g, x0 + 4, by - 32, 54, 2, lt);                              // back
        r(g, x0 + 4, by - 14, 54, 10, lt);                                                              // seat
        r(g, x0 + 4, by - 6, 54, 3, dk);
        r(g, x0, by - 24, 8, 21, c); r(g, x0, by - 24, 8, 2, lt);                                       // arms
        r(g, x0 + 54, by - 24, 8, 21, c); r(g, x0 + 54, by - 24, 8, 2, lt);
        r(g, x0 + 31, by - 14, 1, 10, dk);                                                              // between the cushions
        r(g, x0 + 10, by - 28, 14, 12, 0xFFFFD84D); r(g, x0 + 10, by - 28, 14, 2, 0xFFFFEB99);          // a yellow pillow
    }

    private static void bookcase(GuiGraphics g, int cx, int by) {
        int x0 = cx - 19;
        r(g, x0, by - 52, 38, 52, 0xFF8A5A3A);
        r(g, x0 + 2, by - 50, 34, 48, 0xFF5E3C24);
        int[] cols = {0xFFE5534B, 0xFF4A90D8, 0xFFF0B90B, 0xFF4CAF50, 0xFFB57BD6, 0xFFFF8FB8, 0xFF5BD9C8};
        for (int s = 0; s < 3; s++) {
            int sy = by - 50 + s * 16 + 14;
            r(g, x0 + 2, sy, 34, 2, 0xFF8A5A3A);
            int x = x0 + 4;
            for (int i = 0; i < 7; i++) {
                int h = 8 + (i * 5 + s * 3) % 5;
                if (s == 2 && i == 5) { x += 4; continue; }              // a gap
                r(g, x, sy - h, 4, h, cols[(i + s * 2) % cols.length]);
                r(g, x + 1, sy - h + 1, 1, h - 2, 0x44FFFFFF);
                x += 4;
            }
        }
        r(g, x0 + 2, by - 52, 34, 1, 0xFFB0825A);
    }

    private static void toybox(GuiGraphics g, int cx, int by) {
        int x0 = cx - 18;
        d(g, cx - 8, by - 20, 5, 0xFFE5484D); d(g, cx - 9, by - 22, 1, 0xFFFF9C9C);                      // a ball
        r(g, cx + 4, by - 25, 7, 9, 0xFFFFD84D); r(g, cx + 2, by - 29, 6, 5, 0xFFFFD84D); r(g, cx + 8, by - 28, 3, 2, 0xFFFF9C3C);   // a duck
        r(g, cx + 4, by - 27, 1, 1, 0xFF3A2A3A);
        r(g, x0, by - 16, 36, 16, 0xFF4A90D8); r(g, x0, by - 16, 36, 2, 0xFF7FB5F0);
        r(g, x0, by - 2, 36, 2, 0xFF2F6AAD);
        r(g, x0 + 2, by - 18, 32, 3, 0xFF2F6AAD);                                                       // the lid
        r(g, x0 + 14, by - 10, 8, 2, 0xFFFFD84D); r(g, x0 + 17, by - 12, 2, 6, 0xFFFFD84D);             // a star mark
    }

    private static void piano(GuiGraphics g, int cx, int by) {
        int x0 = cx - 31;
        r(g, x0 + 3, by - 4, 4, 4, 0xFF222230); r(g, x0 + 55, by - 4, 4, 4, 0xFF222230);
        r(g, x0, by - 42, 62, 4, 0xFF2A2A38);                                                           // top
        r(g, x0 + 4, by - 38, 54, 12, 0xFF1E1E2A);                                                      // music stand
        for (int i = 0; i < 6; i++) r(g, x0 + 8 + i * 8, by - 35, 5, 1, 0xFFE9E9F2);                    // notes
        r(g, x0, by - 26, 62, 22, 0xFF2A2A38);
        r(g, x0 + 3, by - 24, 56, 12, 0xFFFFFFFF);                                                      // keys
        for (int i = 1; i < 14; i++) r(g, x0 + 3 + i * 4, by - 24, 1, 12, 0xFFC9C2D8);
        for (int i = 0; i < 14; i++) if (i % 7 != 2 && i % 7 != 6) r(g, x0 + 5 + i * 4, by - 24, 3, 7, 0xFF111118);
        r(g, x0, by - 12, 62, 8, 0xFF2A2A38);
    }
}
