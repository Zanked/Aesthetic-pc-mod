package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Pet Farm: a little field of 8 plots (4 are open, the others are unlocked with coins). Buy a seed, plant it, water
 * it (that makes it grow faster) and harvest it when it is ripe. Crops grow in REAL time, also while you are away.
 * Your Tamagotchi walks around the farm: click it and it waters everything (every 5 minutes).
 * The farm is saved on the server under the name "farm" (like the pet). Everything is client side, like the coins.
 */
public class FarmApp extends App {
    // ---------- the crops ----------
    private static final int CROPS = 4;
    private static final int[] GROW = {180, 360, 720, 1500};          // seconds
    private static final int[] SEED = {2, 4, 8, 15};                   // price of a seed
    private static final int[] SELL = {6, 12, 26, 55};                 // coins for a ripe crop
    private static final int[] LEAF = {0xFF5BBF6A, 0xFF4FAE5E, 0xFF5BBF6A, 0xFF4FAE5E};
    private static final int PLOTS = 8, FREE_PLOTS = 4;
    private static final int[] PLOT_PRICE = {0, 0, 0, 0, 15, 30, 50, 80};
    private static final int DAILY_FULL = 120;                         // sales per day at full price, then a quarter
    private static final int HELP_SEC = 300;                           // the pet can help every 5 minutes
    private static final double WATER_CUT = 0.25;                      // watering saves a quarter of the time left

    // ---------- layout ----------
    private static final int PX = 72, PY = 62, PW = 48, PH = 34, PITCH_X = 52, PITCH_Y = 38;
    private static final int SHELF_X = 4, SHELF_Y = 62, SHELF_W = 62, SHELF_H = 17, SHELF_PITCH = 19;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8;

    // ---------- state (saved) ----------
    private int unlocked = FREE_PLOTS, selected, incomeDay, income;
    private long helpAt;
    private final int[] crop = new int[PLOTS];                          // -1 empty
    private final long[] ready = new long[PLOTS];                       // epoch second when ripe
    private final boolean[] watered = new boolean[PLOTS];

    // ---------- state (screen) ----------
    private boolean loaded;
    private int ticks, msgT, petDir = 1;
    private double petX = 120;
    private String msg = "";
    private final List<double[]> pops = new ArrayList<>();             // x, y, life, kind (0 coin text, 1 drop), value
    private final List<String> popText = new ArrayList<>();
    private final Random rnd = new Random();

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        if (!loaded) { loaded = true; load(); }
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.farm"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.farm"); }

    @Override
    public void close() { if (loaded) save(); }

    private static long now() { return System.currentTimeMillis() / 1000L; }

    // ---------- save / load ----------
    private void load() {
        for (int i = 0; i < PLOTS; i++) crop[i] = -1;
        try {
            String s = Store.read("farm");
            if (s == null || s.isBlank()) return;
            String[] a = s.trim().split("\\|");
            unlocked = Math.max(FREE_PLOTS, Math.min(PLOTS, Integer.parseInt(a[1])));
            incomeDay = Integer.parseInt(a[2]);
            income = Integer.parseInt(a[3]);
            helpAt = Long.parseLong(a[4]);
            selected = Math.max(0, Math.min(CROPS - 1, Integer.parseInt(a[5])));
            String[] p = a[6].split(";");
            for (int i = 0; i < PLOTS && i < p.length; i++) {
                if (p[i].equals("-")) continue;
                String[] f = p[i].split(",");
                int c = Integer.parseInt(f[0]);
                if (c < 0 || c >= CROPS) continue;
                crop[i] = c;
                ready[i] = Long.parseLong(f[1]);
                watered[i] = f[2].equals("1");
            }
        } catch (Exception ignored) {
        }
    }

    private void save() {
        StringBuilder sb = new StringBuilder("1|").append(unlocked).append('|').append(incomeDay).append('|').append(income)
                .append('|').append(helpAt).append('|').append(selected).append('|');
        for (int i = 0; i < PLOTS; i++) {
            if (i > 0) sb.append(';');
            if (crop[i] < 0) sb.append('-'); else sb.append(crop[i]).append(',').append(ready[i]).append(',').append(watered[i] ? 1 : 0);
        }
        try { Store.write("farm", sb.toString()); } catch (Exception ignored) { }
    }

    // ---------- logic ----------
    /** 0 seed, 1 growing, 2 almost, 3 ripe. */
    private int stageOf(int i) {
        long left = ready[i] - now();
        if (left <= 0) return 3;
        double done = 1.0 - left / (double) GROW[crop[i]];
        return done < 0.34 ? 0 : done < 0.67 ? 1 : 2;
    }

    private boolean ripe(int i) { return crop[i] >= 0 && ready[i] <= now(); }

    private void say(String key, Object... args) { msg = t(key, args); msgT = 200; }

    private void pop(double x, double y, String text, int kind) {
        pops.add(new double[]{x, y, 50, kind, 0});
        popText.add(text);
    }

    private void sound(float pitch) { Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), pitch, 0.5F); }

    private static int plotX(int i) { return PX + (i % 4) * PITCH_X; }

    private static int plotY(int i) { return PY + (i / 4) * PITCH_Y; }

    private void clickPlot(int i) {
        if (i >= unlocked) {                                              // a locked plot: buy it (they open in order)
            if (i != unlocked) { say("cutemod.farm.msg.order"); return; }
            if (!Progress.spend(PLOT_PRICE[i])) { say("cutemod.farm.msg.nocoins"); return; }
            unlocked++;
            sound(1.6F);
            pop(plotX(i) + PW / 2, plotY(i), "-" + PLOT_PRICE[i], 0);
            say("cutemod.farm.msg.unlocked");
            save();
            return;
        }
        if (crop[i] < 0) {                                                // plant the chosen seed
            if (!Progress.spend(SEED[selected])) { say("cutemod.farm.msg.nocoins"); return; }
            crop[i] = selected;
            ready[i] = now() + GROW[selected];
            watered[i] = false;
            sound(1.2F);
            pop(plotX(i) + PW / 2, plotY(i), "-" + SEED[selected], 0);
            save();
        } else if (ripe(i)) {                                             // harvest
            harvest(i);
        } else if (!watered[i]) {                                         // water: a quarter of the time left is saved
            water(i);
            sound(1.9F);
            save();
        } else {
            say("cutemod.farm.msg.wet");
        }
    }

    private void water(int i) {
        long left = Math.max(0, ready[i] - now());
        ready[i] -= (long) (left * WATER_CUT);
        watered[i] = true;
        for (int k = 0; k < 4; k++) pops.add(new double[]{plotX(i) + 10 + rnd.nextInt(PW - 20), plotY(i) - 4 - rnd.nextInt(6), 22, 1, 0});
        popText.addAll(java.util.Collections.nCopies(4, ""));
    }

    private void harvest(int i) {
        int day = (int) (now() / 86400);
        if (incomeDay != day) { incomeDay = day; income = 0; }
        int pay = SELL[crop[i]];
        if (income >= DAILY_FULL) pay = Math.max(1, pay / 4);        // the market is full for today
        income += pay;
        crop[i] = -1;
        watered[i] = false;
        Progress.earn(pay);
        Progress.bump("farm_harvest");
        pop(plotX(i) + PW / 2, plotY(i), "+" + pay, 0);
        sound(2.0F);
        save();
    }

    private void petHelp() {
        long n = now();
        if (n < helpAt) {
            long s = helpAt - n;
            say("cutemod.farm.msg.rest", s / 60 + ":" + (s % 60 < 10 ? "0" : "") + s % 60);
            return;
        }
        int count = 0;
        for (int i = 0; i < unlocked; i++) if (crop[i] >= 0 && !ripe(i) && !watered[i]) { water(i); count++; }
        if (count == 0) { say("cutemod.farm.msg.nothing"); return; }
        helpAt = n + HELP_SEC;
        sound(1.5F);
        say("cutemod.farm.msg.helped", count);
        Progress.onPet("play");
        save();
    }

    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        petX += petDir * 0.25;
        if (petX > 266) petDir = -1;
        if (petX < 84) petDir = 1;
        for (int i = pops.size() - 1; i >= 0; i--) {
            double[] p = pops.get(i);
            p[1] += p[3] == 1 ? 0.8 : -0.35;
            if (--p[2] <= 0) { pops.remove(i); popText.remove(i); }
        }
        if (ticks % 600 == 0 && loaded) save();
    }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        sky(g);
        rect(g, 0, 56, W, H - 56, 0xFF8FD39A);                                  // the grass
        for (int y = 56; y < H; y += 10) rect(g, 0, y, W, 5, 0xFF86CB92);
        fence(g);
        shelf(g, f, mx, my);
        int hover = -1;
        for (int i = 0; i < PLOTS; i++) {
            boolean hov = in(mx, my, plotX(i), plotY(i), PW, PH);
            if (hov) hover = i;
            plot(g, f, i, hov);
        }
        pet(g, f, mx, my);
        for (int i = 0; i < pops.size(); i++) {
            double[] p = pops.get(i);
            if (p[3] == 1) { rect(g, (int) p[0], (int) p[1], 2, 3, 0xFF6EC1FF); continue; }
            String s = popText.get(i);
            g.drawString(f, s, (int) p[0] - f.width(s) / 2, (int) p[1], s.startsWith("+") ? 0xFFFFD84A : 0xFFFFFFFF, true);
        }
        bar(g, f);
        if (hover >= 0) tip(g, f, hover, mx, my);
        if (msgT > 0) {
            int w = f.width(msg) + 12, x = (W - w) / 2;
            rect(g, x, 18, w, 13, 0xEE3A2A3A);
            g.drawString(f, msg, x + 6, 21, 0xFFFFFFFF, false);
        }
        if (isNight()) rect(g, 0, 14, W, H - 14, 0x33101040);                  // a blue night over the farm
    }

    private static int hour() { return java.time.LocalTime.now().getHour(); }

    private static boolean isNight() { int h = hour(); return h < 6 || h >= 21; }

    private void sky(GuiGraphics g) {
        int h = hour();
        boolean night = isNight(), dusk = h == 6 || h == 7 || h == 19 || h == 20;
        int top = night ? 0xFF1E2A5A : dusk ? 0xFF6A7FD0 : 0xFF78C4FF, bot = night ? 0xFF3A4A8A : dusk ? 0xFFFFB38A : 0xFFD6F0FF;
        for (int y = 0; y < 56; y += 2) rect(g, 0, y, W, 2, mix(top, bot, y / 56f));
        if (night) {
            for (int i = 0; i < 18; i++) if ((ticks / 15 + i) % 5 != 0) rect(g, 6 + (i * 53) % (W - 12), 18 + (i * 29) % 30, 1, 1, 0xFFFFFFFF);
            disc(g, 262, 28, 8, 0xFFF4F0D0);
            disc(g, 265, 26, 7, 0xFF3A4A8A);
        } else {
            int sx = 30 + (h - 6) * 16;                                         // the sun walks over the sky during the day
            disc(g, Math.max(20, Math.min(W - 20, sx)), dusk ? 40 : 24, 9, 0x66FFE070);
            disc(g, Math.max(20, Math.min(W - 20, sx)), dusk ? 40 : 24, 6, 0xFFFFE070);
            for (int c = 0; c < 3; c++) {                                       // clouds drift slowly
                int cx = (int) ((ticks * 0.1 + c * 110) % (W + 60)) - 30, cy = 20 + c * 11;
                disc(g, cx, cy, 5, 0xE6FFFFFF); disc(g, cx + 7, cy - 2, 6, 0xE6FFFFFF); disc(g, cx + 14, cy, 5, 0xE6FFFFFF);
            }
        }
    }

    private void fence(GuiGraphics g) {
        for (int x = 2; x < W; x += 9) {
            rect(g, x, 50, 3, 10, 0xFFE8C68A);
            rect(g, x, 50, 3, 2, 0xFFF5DDA8);
        }
        rect(g, 0, 53, W, 2, 0xFFD6B070);
        rect(g, 0, 57, W, 1, 0xFFC09A5A);
    }

    private void shelf(GuiGraphics g, Font f, int mx, int my) {
        String h = t("cutemod.farm.seeds");
        g.drawString(f, h, SHELF_X + 2, SHELF_Y - 9, 0xFF3A6A3A, false);
        for (int i = 0; i < CROPS; i++) {
            int y = SHELF_Y + i * SHELF_PITCH;
            boolean on = i == selected, hov = in(mx, my, SHELF_X, y, SHELF_W, SHELF_H);
            rect(g, SHELF_X, y, SHELF_W, SHELF_H, on ? 0xFFFFF3B0 : hov ? 0xFFFFFFFF : 0xFFF6F0FA);
            rect(g, SHELF_X, y + SHELF_H - 2, SHELF_W, 2, on ? 0xFFE8A817 : 0xFFB9A8C8);
            cropIcon(g, i, SHELF_X + 8, y + 12);
            String n = f.plainSubstrByWidth(t("cutemod.farm.crop." + i), 30);
            g.drawString(f, n, SHELF_X + 16, y + 2, TEXT, false);
            String pr = Integer.toString(SEED[i]);
            g.drawString(f, pr, SHELF_X + SHELF_W - 12 - f.width(pr), y + 9, MUTED, false);
            Progress.drawCoin(g, SHELF_X + SHELF_W - 10, y + 8);
        }
    }

    private void plot(GuiGraphics g, Font f, int i, boolean hov) {
        int x = plotX(i), y = plotY(i);
        boolean locked = i >= unlocked;
        int soil = locked ? 0xFF9A9A9A : watered[i] && crop[i] >= 0 ? 0xFF6A4228 : 0xFF8A5A3A;
        rect(g, x - 1, y - 1, PW + 2, PH + 2, hov ? 0xFFFFFFFF : 0xFF5A3A22);
        rect(g, x, y, PW, PH, soil);
        for (int r = 0; r < 3; r++) rect(g, x + 2, y + 8 + r * 10, PW - 4, 2, mix(soil, 0x000000, 0.2f));   // furrows
        if (locked) {
            rect(g, x + PW / 2 - 4, y + 12, 8, 7, 0xFF5A5A5A);                   // a padlock
            rect(g, x + PW / 2 - 3, y + 8, 6, 5, 0xFF7A7A7A);
            rect(g, x + PW / 2 - 1, y + 14, 2, 3, 0xFFEEEEEE);
            if (i == unlocked) {
                String p = Integer.toString(PLOT_PRICE[i]);
                g.drawString(f, p, x + PW / 2 - f.width(p) / 2 - 4, y + 22, 0xFFFFFFFF, true);
                Progress.drawCoin(g, x + PW / 2 + f.width(p) / 2 - 2, y + 22);
            }
            return;
        }
        if (crop[i] < 0) {
            if (hov) cropIcon(g, selected, x + PW / 2, y + PH - 6);              // a ghost of the seed you would plant
            return;
        }
        int st = stageOf(i);
        int bob = st == 3 ? (int) Math.round(Math.sin((ticks + i * 9) / 10.0)) : 0;
        drawCrop(g, crop[i], st, x + PW / 2, y + PH - 5 + bob);
        if (st == 3 && (ticks / 12 + i) % 3 == 0) {                              // sparkle: ready!
            rect(g, x + 8, y + 4, 3, 1, 0xFFFFF3B0); rect(g, x + 9, y + 3, 1, 3, 0xFFFFF3B0);
        }
        if (st < 3) {                                                            // a time bar under the plant
            long left = Math.max(0, ready[i] - now());
            float p = 1f - left / (float) GROW[crop[i]];
            rect(g, x + 4, y + PH - 4, PW - 8, 2, 0x66000000);
            rect(g, x + 4, y + PH - 4, (int) ((PW - 8) * p), 2, watered[i] ? 0xFF6EC1FF : 0xFFFFD84A);
        }
    }

    private void drawCrop(GuiGraphics g, int kind, int stage, int cx, int base) {
        int leaf = LEAF[kind];
        if (stage == 0) {                                                        // two tiny leaves
            rect(g, cx - 2, base - 4, 2, 4, leaf); rect(g, cx + 1, base - 5, 2, 5, leaf);
            return;
        }
        if (stage == 1) {
            rect(g, cx - 1, base - 10, 2, 10, leaf);
            rect(g, cx - 5, base - 8, 4, 3, leaf); rect(g, cx + 1, base - 7, 4, 3, leaf);
            return;
        }
        if (stage == 2) {                                                        // grown but not ripe: green with a bud
            rect(g, cx - 1, base - 13, 2, 13, leaf);
            rect(g, cx - 6, base - 10, 5, 4, leaf); rect(g, cx + 1, base - 9, 5, 4, leaf);
            rect(g, cx - 1, base - 15, 3, 3, kind == 0 ? 0xFFFFB070 : kind == 1 ? 0xFFFFC0C0 : kind == 2 ? 0xFFB8D880 : 0xFFE8D860);
            return;
        }
        cropIcon(g, kind, cx, base);
    }

    /** The ripe crop, with its feet at (cx, base). */
    private void cropIcon(GuiGraphics g, int kind, int cx, int base) {
        switch (kind) {
            case 0 -> {                                                          // carrot
                rect(g, cx - 4, base - 14, 2, 6, 0xFF5BBF6A); rect(g, cx - 1, base - 16, 2, 8, 0xFF4FAE5E); rect(g, cx + 2, base - 14, 2, 6, 0xFF5BBF6A);
                rect(g, cx - 5, base - 9, 10, 3, 0xFFFF8A2A); rect(g, cx - 4, base - 6, 8, 3, 0xFFFF8A2A);
                rect(g, cx - 3, base - 3, 6, 2, 0xFFFF8A2A); rect(g, cx - 1, base - 1, 2, 2, 0xFFFF8A2A);
            }
            case 1 -> {                                                          // strawberry bush
                disc(g, cx, base - 7, 7, 0xFF4FAE5E);
                int[][] b = {{-4, -9}, {2, -10}, {-1, -5}, {4, -5}, {-5, -4}};
                for (int[] p : b) { rect(g, cx + p[0], base + p[1], 3, 3, 0xFFE5486F); rect(g, cx + p[0] + 1, base + p[1] + 1, 1, 1, 0xFFFFE0E0); }
            }
            case 2 -> {                                                          // pumpkin
                rect(g, cx - 1, base - 14, 3, 4, 0xFF4FAE5E);
                rect(g, cx - 8, base - 10, 16, 9, 0xFFFF8A2A);
                rect(g, cx - 6, base - 11, 12, 11, 0xFFFF9C3A);
                rect(g, cx - 1, base - 10, 1, 9, 0xFFC96A18); rect(g, cx - 4, base - 9, 1, 7, 0xFFC96A18); rect(g, cx + 3, base - 9, 1, 7, 0xFFC96A18);
            }
            default -> {                                                         // sunflower
                rect(g, cx - 1, base - 12, 2, 12, 0xFF4FAE5E);
                rect(g, cx - 5, base - 7, 4, 3, 0xFF5BBF6A); rect(g, cx + 1, base - 5, 4, 3, 0xFF5BBF6A);
                for (int k = 0; k < 8; k++) {
                    double a = k * Math.PI / 4;
                    rect(g, cx + (int) Math.round(Math.cos(a) * 5) - 1, base - 16 + (int) Math.round(Math.sin(a) * 5) - 1, 3, 3, 0xFFFFD84A);
                }
                disc(g, cx, base - 16, 3, 0xFF8A5A2A);
            }
        }
    }

    private void pet(GuiGraphics g, Font f, int mx, int my) {
        dev.cutemod.ComputerColor spc = PetApp.speciesOf(shell.color());       // the pet of this computer (the player may have chosen it)
        PetBlob.Info info = spc == null ? null : PetBlob.parse(Store.read("pet_" + spc.id));
        if (spc == null) spc = shell.color();
        int stage = info == null ? 2 : info.stage();
        boolean sick = info != null && info.sick();
        int px = (int) petX, floor = H - 3;
        float sc = 0.36F * PetArt.scaleOf(stage);
        int hop = (int) Math.round(Math.abs(Math.sin(ticks / 8.0)) * 2);
        g.pose().pushPose();
        g.pose().translate(px, floor, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-px, -floor - hop * 2.5F, 0);
        PetArt.draw(g, spc, px, floor - 28, sick ? 0 : 2, ticks, false, sick, stage, Progress.equipped(), Progress.equippedBody());
        g.pose().popPose();
        if (now() >= helpAt && !sick) {                                           // a "!" bubble: the pet can help
            rect(g, px - 4, floor - 36 - hop, 9, 9, 0xFFFFFFFF);
            g.drawString(f, "!", px - f.width("!") / 2, floor - 35 - hop, 0xFFE5486F, false);
        }
    }

    private void bar(GuiGraphics g, Font f) {
        rect(g, 0, 0, W, 14, 0xCC2A1450);
        g.drawString(f, t("cutemod.os.farm"), 5, 3, 0xFFFFE9A8, false);
        int day = (int) (now() / 86400);
        int inc = incomeDay == day ? income : 0;                                  // today's sales against the full-price limit
        String s = t("cutemod.farm.market", Math.min(inc, DAILY_FULL), DAILY_FULL);
        int bw = 70, bx = 100;
        rect(g, bx, 4, bw, 6, 0x55FFFFFF);
        rect(g, bx, 4, bw * Math.min(inc, DAILY_FULL) / DAILY_FULL, 6, inc >= DAILY_FULL ? 0xFFE5486F : 0xFF7ED957);
        g.drawString(f, s, bx + bw + 4, 3, 0xFFE4D8FF, false);
    }

    private void tip(GuiGraphics g, Font f, int i, int mx, int my) {
        String s;
        if (i >= unlocked) s = i == unlocked ? t("cutemod.farm.tip.buy", PLOT_PRICE[i]) : t("cutemod.farm.tip.locked");
        else if (crop[i] < 0) s = t("cutemod.farm.tip.plant", t("cutemod.farm.crop." + selected), SEED[selected]);
        else if (ripe(i)) s = t("cutemod.farm.tip.ripe", t("cutemod.farm.crop." + crop[i]), SELL[crop[i]]);
        else {
            long left = Math.max(0, ready[i] - now());
            s = t(watered[i] ? "cutemod.farm.tip.wet" : "cutemod.farm.tip.grow", t("cutemod.farm.crop." + crop[i]), left / 60 + ":" + (left % 60 < 10 ? "0" : "") + left % 60);
        }
        int w = f.width(s) + 8, x = Math.max(2, Math.min(mx + 8, W - w - 2)), y = Math.min(H - 14, my + 12);
        rect(g, x, y, w, 12, 0xEE3A2A3A);
        g.drawString(f, s, x + 4, y + 2, 0xFFFFFFFF, false);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < CROPS; i++) {
            if (in(x, y, SHELF_X, SHELF_Y + i * SHELF_PITCH, SHELF_W, SHELF_H)) { selected = i; sound(1.0F + i * 0.2F); return true; }
        }
        for (int i = 0; i < PLOTS; i++) {
            if (in(x, y, plotX(i), plotY(i), PW, PH)) { clickPlot(i); return true; }
        }
        int floor = H - 3;
        if (x >= petX - 14 && x <= petX + 14 && y >= floor - 22 && y <= floor + 3) { petHelp(); return true; }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (keyCode >= 49 && keyCode < 49 + CROPS) { selected = keyCode - 49; return true; }      // 1-4: pick a seed
        return false;
    }
}
