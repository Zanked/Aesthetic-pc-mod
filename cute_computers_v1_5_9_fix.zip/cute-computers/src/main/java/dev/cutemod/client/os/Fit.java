package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/**
 * Text that never leaves the screen: when a line would run past the right (or left) edge it is drawn smaller
 * (down to 60 %), the way a long Russian translation still fits where the English one did. Used by the apps
 * (through {@link Skin}), the mini games and the toasts. A line that fits is drawn exactly as before.
 * Only for the normal 1:1 scale: inside a scaled pose the line is drawn as is.
 */
public final class Fit {
    public static final int APP_RIGHT = App.W - 2;
    private static final float MIN = 0.6F;

    private Fit() {}

    private static boolean plain(GuiGraphics g) {
        float s = g.pose().last().pose().m00();
        return s > 0.99F && s < 1.01F;
    }

    /** The scale a line of width w drawn at x needs to stay between 2 and right (1 = fits). */
    private static float scale(int x, int w, int right) {
        if (w <= 0 || (x >= 0 && x + w <= right)) return 1F;
        float left = x, avail;
        if (x < 0) {                                         // a centred line that is too wide: keep it centred
            float c = x + w / 2F;
            avail = 2F * Math.min(c - 2F, right - c);
            return Math.max(MIN, Math.min(1F, avail / w));
        }
        avail = right - left;
        return Math.max(MIN, Math.min(1F, avail / w));
    }

    public static int str(GuiGraphics g, Font f, String s, int x, int y, int argb, boolean shadow, int right) {
        int w = f.width(s);
        float k = plain(g) ? scale(x, w, right) : 1F;
        if (k >= 0.999F) return g.drawString(f, s, x, y, argb, shadow);
        float nx = x < 0 ? x + w / 2F - w * k / 2F : x;
        g.pose().pushPose();
        g.pose().translate(nx, y + (1F - k) * 4F, 0);       // keep the line on the same middle height
        g.pose().scale(k, k, 1F);
        int r = g.drawString(f, s, 0, 0, argb, shadow);
        g.pose().popPose();
        return r;
    }

    public static int str(GuiGraphics g, Font f, Component s, int x, int y, int argb, boolean shadow, int right) {
        int w = f.width(s);
        float k = plain(g) ? scale(x, w, right) : 1F;
        if (k >= 0.999F) return g.drawString(f, s, x, y, argb, shadow);
        float nx = x < 0 ? x + w / 2F - w * k / 2F : x;
        g.pose().pushPose();
        g.pose().translate(nx, y + (1F - k) * 4F, 0);
        g.pose().scale(k, k, 1F);
        int r = g.drawString(f, s, 0, 0, argb, shadow);
        g.pose().popPose();
        return r;
    }

    public static int str(GuiGraphics g, Font f, Component s, int x, int y, int argb) { return str(g, f, s, x, y, argb, true, APP_RIGHT); }

    public static int str(GuiGraphics g, Font f, net.minecraft.util.FormattedCharSequence s, int x, int y, int argb, boolean shadow) {
        int w = f.width(s);
        float k = plain(g) ? scale(x, w, APP_RIGHT) : 1F;
        if (k >= 0.999F) return g.drawString(f, s, x, y, argb, shadow);
        float nx = x < 0 ? x + w / 2F - w * k / 2F : x;
        g.pose().pushPose();
        g.pose().translate(nx, y + (1F - k) * 4F, 0);
        g.pose().scale(k, k, 1F);
        int r = g.drawString(f, s, 0, 0, argb, shadow);
        g.pose().popPose();
        return r;
    }

    public static int str(GuiGraphics g, Font f, String s, int x, int y, int argb, boolean shadow) { return str(g, f, s, x, y, argb, shadow, APP_RIGHT); }

    public static int str(GuiGraphics g, Font f, String s, int x, int y, int argb) { return str(g, f, s, x, y, argb, true, APP_RIGHT); }

    public static int str(GuiGraphics g, Font f, Component s, int x, int y, int argb, boolean shadow) { return str(g, f, s, x, y, argb, shadow, APP_RIGHT); }

    // ---------- text that must stay inside a box ----------

    /** s drawn inside maxW pixels from x: smaller (down to 60 %) when it is too wide, cut only as the last resort. */
    public static int box(GuiGraphics g, Font f, String s, int x, int y, int argb, boolean shadow, int maxW) {
        return core(g, f, FormattedText.of(s), x, y, argb, shadow, maxW, false);
    }

    public static int box(GuiGraphics g, Font f, Component s, int x, int y, int argb, boolean shadow, int maxW) {
        return core(g, f, s, x, y, argb, shadow, maxW, false);
    }

    /** The same, centred in the box that starts at x and is maxW wide. */
    public static int boxC(GuiGraphics g, Font f, String s, int x, int y, int argb, boolean shadow, int maxW) {
        return core(g, f, FormattedText.of(s), x, y, argb, shadow, maxW, true);
    }

    private static int core(GuiGraphics g, Font f, FormattedText s, int x, int y, int argb, boolean shadow, int maxW, boolean center) {
        int sw = f.width(s);
        float k = Math.max(MIN, Math.min(1F, (float) maxW / Math.max(1, sw)));
        if (sw * k > maxW + 0.5F) { s = f.substrByWidth(s, (int) (maxW / k)); sw = f.width(s); }
        FormattedCharSequence seq = Language.getInstance().getVisualOrder(s);
        float nx = center ? x + (maxW - sw * k) / 2F : x;
        if (k >= 0.999F) return g.drawString(f, seq, Math.round(nx), y, argb, shadow);
        g.pose().pushPose();
        g.pose().translate(nx, y + (1F - k) * 4F, 0);
        g.pose().scale(k, k, 1F);
        int r = g.drawString(f, seq, 0, 0, argb, shadow);
        g.pose().popPose();
        return r;
    }

    /** A wrapped paragraph that has to fit into w x maxH: it gets smaller (down to 60 %) until all its lines fit. */
    public static int para(GuiGraphics g, Font f, String s, int x, int y, int w, int maxH, int lineH, int argb, boolean shadow) {
        float[] steps = {1F, 0.9F, 0.8F, 0.7F, 0.6F};
        float k = 1F;
        List<FormattedCharSequence> lines = f.split(FormattedText.of(s), w);
        for (float c : steps) {
            k = c;
            lines = f.split(FormattedText.of(s), (int) (w / c));
            if (lines.size() * lineH * c <= maxH + 0.5F) break;
        }
        int n = Math.min(lines.size(), Math.max(1, (int) (maxH / (lineH * k) + 0.01F)));
        if (k >= 0.999F) {
            for (int i = 0; i < n; i++) g.drawString(f, lines.get(i), x, y + i * lineH, argb, shadow);
            return n * lineH;
        }
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(k, k, 1F);
        for (int i = 0; i < n; i++) g.drawString(f, lines.get(i), 0, i * lineH, argb, shadow);
        g.pose().popPose();
        return (int) (n * lineH * k);
    }
}
