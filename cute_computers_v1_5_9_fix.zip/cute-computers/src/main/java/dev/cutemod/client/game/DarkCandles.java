package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Tiny horror game: you walk in a dark room with a flashlight and collect candles.
 * Something creeps up on you - it freezes while the light touches it, but it moves in the dark.
 */
public class DarkCandles extends MiniGame {
    private static final double R = 52, HALF_COS = Math.cos(0.62);
    private static final int CELL = 4;

    private double px, py, fx, fy, ex, ey, cx, cy;
    private int taken, ticks, stun;

    @Override
    public void reset() {
        score = 0; over = false; taken = 0; ticks = 0; stun = 0;
        px = W / 2.0; py = H / 2.0; fx = 1; fy = 0;
        ex = 12; ey = 12;
        placeCandle();
    }

    private void placeCandle() {
        for (int i = 0; i < 30; i++) {
            cx = 10 + rnd.nextInt(W - 20);
            cy = 10 + rnd.nextInt(H - 20);
            if (Math.hypot(cx - px, cy - py) > 35) break;
        }
    }

    private boolean lit() {
        double dx = ex - px, dy = ey - py, d = Math.hypot(dx, dy);
        return d < R && d > 0.001 && (dx * fx + dy * fy) / d > HALF_COS;
    }

    @Override
    public void tick() {
        ticks++;
        double dx = mx - px, dy = my - py, d = Math.hypot(dx, dy);
        if (d > 3) { fx = dx / d; fy = dy / d; }
        if (d > 8) {
            px += fx * 1.3;
            py += fy * 1.3;
        }
        px = Math.max(4, Math.min(W - 4, px));
        py = Math.max(4, Math.min(H - 4, py));

        // it only moves in the dark
        double ddx = px - ex, ddy = py - ey, md = Math.hypot(ddx, ddy);
        if (stun > 0) stun--;
        else if (!lit() && md > 0.001) {
            double sp = Math.min(1.0, 0.4 + 0.05 * taken);
            ex += ddx / md * sp;
            ey += ddy / md * sp;
        }
        md = Math.hypot(px - ex, py - ey);
        if (md < 6) { over = true; beep(); return; }
        if (md < 40 && ticks % 24 == 0) beep(); // heartbeat

        if (Math.hypot(cx - px, cy - py) < 7) {
            taken++;
            score += 10;
            stun = 60;
            pling(1.6F);
            placeCandle();
        }
    }

    private void drawFigure(GuiGraphics g, int x, int y) {
        rect(g, x - 4, y - 8, 8, 16, 0xFF0A0A0F);
        rect(g, x - 3, y - 11, 6, 4, 0xFFE8E4EC);        // pale face
        rect(g, x - 2, y - 10, 1, 2, 0xFF000000);
        rect(g, x + 1, y - 10, 1, 2, 0xFF000000);
        rect(g, x - 7, y - 4, 3, 8, 0xFF0A0A0F);          // long arms
        rect(g, x + 4, y - 4, 3, 8, 0xFF0A0A0F);
    }

    @Override
    public void render(GuiGraphics g) {
        for (int ty = 0; ty < H; ty += 20)               // floor tiles
            for (int tx = 0; tx < W; tx += 20)
                rect(g, tx, ty, 20, 20, ((tx + ty) / 20) % 2 == 0 ? 0xFF3A3042 : 0xFF2F2638);

        boolean lit = lit();
        double md = Math.hypot(px - ex, py - ey);
        if (lit || md < 14) drawFigure(g, (int) ex, (int) ey);

        // darkness, drawn in blocks; the flashlight is a cone with a small glow around you
        for (int y = 0; y < H; y += CELL) {
            for (int x = 0; x < W; x += CELL) {
                double ddx = x + CELL / 2.0 - px, ddy = y + CELL / 2.0 - py, dd = Math.hypot(ddx, ddy);
                int a;
                if (dd < 12) a = 0x30;
                else if (dd < R && (ddx * fx + ddy * fy) / dd > HALF_COS) a = 0x10 + (int) (dd / R * 0x50);
                else a = 0xEE;
                rect(g, x, y, CELL, CELL, a << 24);
            }
        }

        // the candle always glows, the eyes are always watching
        int fl = (ticks / 4) % 2;
        rect(g, (int) cx - 1, (int) cy - 1, 3, 5, 0xFFF3E6C8);
        rect(g, (int) cx, (int) cy - 4 - fl, 1, 3 + fl, 0xFFFFC832);
        if (!lit && (ticks % 140) >= 6) {
            rect(g, (int) ex - 3, (int) ey - 9, 2, 2, 0xFFFF2A2A);
            rect(g, (int) ex + 1, (int) ey - 9, 2, 2, 0xFFFF2A2A);
        }

        // you
        disc(g, (int) px, (int) py, 4, 0xFFF58FB8);
        rect(g, (int) (px + fx * 2) - 1, (int) (py + fy * 2) - 1, 2, 2, 0xFFFFFFFF);

        if (md < 25 && !over && (ticks / 3) % 3 == 0) rect(g, 0, 0, W, H, 0x33FF0000); // panic flicker

        if (over) { // jumpscare face under the game over window
            rect(g, 0, 0, W, H, 0xDD200000);
            rect(g, 70, 15, 80, 100, 0xFFE8E4EC);
            rect(g, 80, 40, 22, 18, 0xFF000000);
            rect(g, 118, 40, 22, 18, 0xFF000000);
            rect(g, 88, 46, 4, 4, 0xFFFF2A2A);
            rect(g, 126, 46, 4, 4, 0xFFFF2A2A);
            rect(g, 85, 80, 50, 22, 0xFF000000);
            for (int i = 0; i < 6; i++) rect(g, 87 + i * 8, 80, 4, 6, 0xFFFFFFFF);
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score", score); }

    @Override
    public String hintKey() { return "cutemod.hint.horror"; }
}
