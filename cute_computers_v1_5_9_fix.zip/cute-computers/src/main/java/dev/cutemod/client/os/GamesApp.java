package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

/** The "Games" folder: the games you bought in CuteStore and that are installed. */
public class GamesApp extends App {
    /** One tile. color == null means a game without a computer of its own. */
    private record Entry(String id, ComputerColor color, int rgb) {}

    private static final int COLS = 5, ROWS = 3, PER_PAGE = COLS * ROWS, TW = 56, TH = 47, GAP = 3;
    private static final int X0 = (W - (COLS * TW + (COLS - 1) * GAP)) / 2;
    private static final int Y0 = 2;
    private static final int NAV_Y = Y0 + ROWS * TH + (ROWS - 1) * GAP + 3;

    private int page;

    @Override
    public Component title() { return Component.translatable("cutemod.os.games"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.games"); }

    /** Installed games only, in the order of the store. */
    private static List<Entry> installed() {
        List<Entry> out = new ArrayList<>();
        for (Library.Game gm : Library.GAMES) {
            if (!Library.installed(gm.id())) continue;
            ComputerColor c = null;
            for (ComputerColor cc : ComputerColor.values()) if (cc.id.equals(gm.id())) c = cc;
            out.add(new Entry(gm.id(), c, gm.rgb()));
        }
        return out;
    }

    private static int tx(int i) { return X0 + (i % COLS) * (TW + GAP); }

    private static int ty(int i) { return Y0 + (i / COLS) * (TH + GAP); }

    private static int pages(int n) { return Math.max(1, (n + PER_PAGE - 1) / PER_PAGE); }

    private boolean prevHit(int x, int y, int pages) { return pages > 1 && in(x, y, W / 2 - 46, NAV_Y, 20, 13); }

    private boolean nextHit(int x, int y, int pages) { return pages > 1 && in(x, y, W / 2 + 26, NAV_Y, 20, 13); }

    private boolean storeBtnHit(int x, int y) { return in(x, y, W / 2 - 55, 100, 110, 18); }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        int body = shell.color().bodyColor;
        Skin.grad(g, 0, 0, W, H, mix(body, 0xFFFFFF, 0.65f), mix(body, 0xFFFFFF, 0.3f));
        List<Entry> list = installed();
        int pages = pages(list.size());
        page = Math.min(page, pages - 1);

        if (list.isEmpty()) {
            List<FormattedCharSequence> lines = font().split(FormattedText.of(t("cutemod.games.empty")), W - 80);
            for (int i = 0; i < lines.size(); i++) {
                FormattedCharSequence s = lines.get(i);
                Skin.str(g, font(), s, (W - font().width(s)) / 2, 62 + i * 10, 0xFF3A2A3A, false);
            }
            boolean hover = storeBtnHit(mx, my);
            Skin.rect(g, W / 2 - 55, 100, 110, 18, hover ? 0xFF8A6AC6 : 0xFFB57BD6);
            String s = t("cutemod.os.store");
            Skin.str(g, font(), s, W / 2 - font().width(s) / 2, 105, 0xFFFFFFFF, false);
            return;
        }

        for (int slot = 0; slot < PER_PAGE; slot++) {
            int idx = page * PER_PAGE + slot;
            if (idx >= list.size()) break;
            Entry e = list.get(idx);
            int x = tx(slot), y = ty(slot);
            boolean hover = in(mx, my, x, y, TW, TH);
            boolean own = e.color() == shell.color();
            Skin.rect(g, x - 1, y - 1, TW + 2, TH + 2, own ? 0xFFFFD866 : 0xFF3A2A4A);
            Skin.rect(g, x, y, TW, TH, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
            CoverArt.draw(g, e.id(), x + TW / 2 - 8, y + 1, 16);
            List<FormattedCharSequence> lines =
                    font().split(FormattedText.of(t("cutemod.game." + e.id())), TW - 4);
            for (int l = 0; l < lines.size() && l < 3; l++) {
                FormattedCharSequence s = lines.get(l);
                Skin.str(g, font(), s, x + (TW - font().width(s)) / 2, y + 19 + l * 9, 0xFF3A2A3A, false);
            }
        }
        if (pages > 1) {
            int bx1 = W / 2 - 46, bx2 = W / 2 + 26;
            Skin.rect(g, bx1, NAV_Y, 20, 13, in(mx, my, bx1, NAV_Y, 20, 13) ? 0xFFFFFFFF : 0xFFF6F0FA);
            Skin.rect(g, bx2, NAV_Y, 20, 13, in(mx, my, bx2, NAV_Y, 20, 13) ? 0xFFFFFFFF : 0xFFF6F0FA);
            Skin.str(g, font(), "<", bx1 + 7, NAV_Y + 3, 0xFF3A2A3A, false);
            Skin.str(g, font(), ">", bx2 + 7, NAV_Y + 3, 0xFF3A2A3A, false);
            String pg = (page + 1) + "/" + pages;
            Skin.str(g, font(), pg, W / 2 - font().width(pg) / 2, NAV_Y + 3, 0xFF3A2A3A, false);
        }
    }

    private void turnPage(int d, int pages) { page = Math.floorMod(page + d, pages); }

    @Override
    public boolean scroll(double amount) {
        int pages = pages(installed().size());
        if (pages <= 1) return false;
        turnPage(amount > 0 ? -1 : 1, pages);
        return true;
    }

    @Override
    public boolean click(int x, int y, int button) {
        List<Entry> list = installed();
        int pages = pages(list.size());
        if (list.isEmpty()) {
            if (storeBtnHit(x, y)) shell.open(new StoreApp());
            return true;
        }
        if (prevHit(x, y, pages)) { turnPage(-1, pages); return true; }
        if (nextHit(x, y, pages)) { turnPage(1, pages); return true; }
        for (int slot = 0; slot < PER_PAGE; slot++) {
            int idx = page * PER_PAGE + slot;
            if (idx >= list.size()) break;
            if (in(x, y, tx(slot), ty(slot), TW, TH)) {
                Entry e = list.get(idx);
                shell.open(e.color() != null ? new GameApp(e.color()) : GameApp.extra(e.id()));
                return true;
            }
        }
        return false;
    }
}
