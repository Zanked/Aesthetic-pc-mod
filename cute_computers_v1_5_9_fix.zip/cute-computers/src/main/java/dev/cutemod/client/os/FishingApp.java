package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Fishing Pond: a calm fishing app. Cast, wait for the bobber to dip, click in time to hook the fish, then click in
 * the green zone to reel it in (rarer fish need more hits and have a smaller zone). 12 fish and 2 pieces of junk fill
 * an album (the first catch of every fish pays a bonus, the full album pays 100 coins). Fish go into your bucket; sell
 * them (full price up to 100 coins a day, then a quarter). Some fish only bite at night. Saved on the server as "fish".
 */
public class FishingApp extends App {
    private static final int SPECIES = 14, FISH = 12;
    // rarity: 0 common, 1 uncommon, 2 rare, 3 legendary, 4 junk
    private static final int[] RARITY = {0, 0, 0, 1, 1, 1, 2, 2, 2, 2, 3, 3, 4, 4};
    private static final int[] PRICE = {2, 5, 6, 12, 15, 18, 30, 40, 45, 55, 120, 100, 1, 1};
    private static final int[] MIN_CM = {6, 25, 15, 25, 30, 15, 8, 40, 15, 20, 50, 40, 25, 10};
    private static final int[] MAX_CM = {12, 60, 30, 55, 80, 35, 20, 90, 28, 40, 100, 70, 30, 12};
    private static final int[] BODY = {0xFFA8B8C8, 0xFFD8A060, 0xFF7EA05A, 0xFF8AB0A0, 0xFF6A6A78, 0xFFE8D060, 0xFFFF9A2A, 0xFFFFFFFF, 0xFFFFB8D0, 0xFFC8D8FF, 0xFFF3C45A, 0xFF9AD8E8, 0, 0};
    private static final int[] BELLY = {0xFFE8F0F8, 0xFFF0D8A8, 0xFFE0D890, 0xFFF0E8E0, 0xFFB8B8C0, 0xFFFFF4C0, 0xFFFFD090, 0xFFF0F0F0, 0xFFFFE0EC, 0xFFEAF0FF, 0xFFFFE9A8, 0xFFE8F8FF, 0, 0};
    private static final int[] RX = {7, 11, 9, 10, 11, 7, 7, 12, 9, 9, 12, 11};
    private static final int[] RY = {3, 5, 4, 4, 4, 6, 5, 5, 4, 6, 5, 4};
    private static final int[] RARITY_COL = {0xFFB8B8C8, 0xFF5BBF6A, 0xFF5BA8F0, 0xFFFFC832, 0xFF9A9AA8};
    private static final int[] FIRST_BONUS = {3, 6, 15, 40, 0};
    private static final int DAILY_FULL = 100, ALBUM_BONUS = 100;

    // phases
    private static final int IDLE = 0, CAST = 1, WAIT = 2, BITE = 3, REEL = 4, RESULT = 5;
    // reel bar
    private static final int BAR_X = 88, BAR_Y = 112, BAR_W = 124, BAR_H = 10;
    private static final int[] ZONE = {44, 34, 22, 14, 52};
    private static final int[] NEED = {1, 1, 2, 3, 1};
    // layout
    private static final int TOP = 14, BOT = 144, WATER_Y = 46;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8;

    // ---------- saved ----------
    private final int[] count = new int[SPECIES], best = new int[SPECIES];
    private int bucketCount, bucketValue, incomeDay, income;
    private boolean albumBonus;

    // ---------- screen ----------
    private boolean loaded;
    private int tab, phase, ticks, timer, cur, size, value, hits, strikes, msgT;
    private boolean first;
    private double cursor, cdir = 1, zoneC;
    private String msg = "";
    private final Random rnd = new Random();
    private final List<double[]> rings = new ArrayList<>();      // x, y, radius, life
    private final List<double[]> pops = new ArrayList<>();       // x, y, life, text index
    private final List<String> popText = new ArrayList<>();

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        if (!loaded) { loaded = true; load(); }
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.fishing"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.fishing"); }

    @Override
    public void close() { if (loaded) save(); }

    private static long now() { return System.currentTimeMillis() / 1000L; }

    // ---------- save / load ----------
    private void load() {
        try {
            String s = Store.read("fish");
            if (s == null || s.isBlank()) return;
            String[] a = s.trim().split("\\|");
            incomeDay = Integer.parseInt(a[1]);
            income = Integer.parseInt(a[2]);
            bucketCount = Integer.parseInt(a[3]);
            bucketValue = Integer.parseInt(a[4]);
            albumBonus = a[5].equals("1");
            String[] p = a[6].split(";");
            for (int i = 0; i < SPECIES && i < p.length; i++) {
                String[] f = p[i].split(",");
                count[i] = Integer.parseInt(f[0]);
                best[i] = Integer.parseInt(f[1]);
            }
        } catch (Exception ignored) {
        }
    }

    private void save() {
        StringBuilder sb = new StringBuilder("1|").append(incomeDay).append('|').append(income).append('|').append(bucketCount)
                .append('|').append(bucketValue).append('|').append(albumBonus ? 1 : 0).append('|');
        for (int i = 0; i < SPECIES; i++) sb.append(i > 0 ? ";" : "").append(count[i]).append(',').append(best[i]);
        try { Store.write("fish", sb.toString()); } catch (Exception ignored) { }
    }

    // ---------- logic ----------
    private static int hour() { return java.time.LocalTime.now().getHour(); }

    private static boolean night() { int h = hour(); return h < 6 || h >= 21; }

    private void say(String key, Object... args) { msg = t(key, args); msgT = 200; }

    private void sound(float pitch) { Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), pitch, 0.5F); }

    private void splash(double x, double y) {
        rings.add(new double[]{x, y, 2, 50});
        rings.add(new double[]{x, y, 0, 32});
        Sfx.ui(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 1.0F, 0.5F);
    }

    /** What bites now: rarity first, then a fish of that rarity (some like the night). */
    private int pick() {
        int roll = rnd.nextInt(100);
        int r = roll < 8 ? 4 : roll < 58 ? 0 : roll < 82 ? 1 : roll < 96 ? 2 : 3;
        boolean n = night();
        int total = 0;
        int[] w = new int[SPECIES];
        for (int i = 0; i < SPECIES; i++) {
            if (RARITY[i] != r) continue;
            int v = 2;
            if (i == 9) v = n ? 2 : 0;                    // the moon fish only comes out at night
            if (i == 8 || i == 4) v = n ? 4 : 1;          // axolotl and catfish like the dark
            w[i] = v;
            total += v;
        }
        if (total == 0) return 0;
        int k = rnd.nextInt(total);
        for (int i = 0; i < SPECIES; i++) { k -= w[i]; if (k < 0) return i; }
        return 0;
    }

    private void cast() {
        phase = CAST;
        timer = 28;
        sound(1.1F);
    }

    private void beginReel() {
        phase = REEL;
        hits = 0; strikes = 0;
        cursor = 0; cdir = 1;
        newZone();
        sound(1.6F);
    }

    private void newZone() {
        int zw = ZONE[RARITY[cur]];
        zoneC = zw / 2.0 + 4 + rnd.nextInt(Math.max(1, BAR_W - zw - 8));
    }

    private void reelClick() {
        int zw = ZONE[RARITY[cur]];
        if (Math.abs(cursor - zoneC) <= zw / 2.0) {
            hits++;
            if (hits >= NEED[RARITY[cur]]) { caught(); return; }
            sound(1.4F + hits * 0.2F);
            pop(BAR_X + zoneC, BAR_Y - 8, t("cutemod.fish.nice"));
            newZone();
        } else {
            strikes++;
            Sfx.ui(SoundEvents.NOTE_BLOCK_BASS.value(), 0.7F, 0.6F);
            if (strikes >= 2) { phase = IDLE; say("cutemod.fish.msg.escaped"); }
            else pop(BAR_X + cursor, BAR_Y - 8, t("cutemod.fish.miss"));
        }
    }

    private void caught() {
        int sp = cur;
        double f = rnd.nextDouble() * rnd.nextDouble() * 0.6 + rnd.nextDouble() * 0.4;     // big fish are rarer
        size = (int) Math.round(MIN_CM[sp] + (MAX_CM[sp] - MIN_CM[sp]) * f);
        value = Math.max(1, (int) Math.round(PRICE[sp] * (1.0 + 0.5 * f)));
        first = count[sp] == 0;
        count[sp]++;
        best[sp] = Math.max(best[sp], size);
        bucketCount++;
        bucketValue += value;
        if (first && FIRST_BONUS[RARITY[sp]] > 0) Progress.earn(FIRST_BONUS[RARITY[sp]]);
        Progress.bump("fish_caught");
        if (!albumBonus && albumDone()) { albumBonus = true; Progress.earn(ALBUM_BONUS); say("cutemod.fish.msg.album", ALBUM_BONUS); }
        phase = RESULT;
        sound(RARITY[sp] >= 2 ? 2.0F : 1.5F);
        save();
    }

    private boolean albumDone() {
        for (int i = 0; i < FISH; i++) if (count[i] == 0) return false;
        return true;
    }

    private int caughtKinds() {
        int n = 0;
        for (int i = 0; i < FISH; i++) if (count[i] > 0) n++;
        return n;
    }

    private void sell() {
        if (bucketCount <= 0) return;
        int day = (int) (now() / 86400);
        if (incomeDay != day) { incomeDay = day; income = 0; }
        int full = Math.max(0, Math.min(bucketValue, DAILY_FULL - income));
        int pay = full + (bucketValue - full) / 4;
        income += pay;
        if (pay > 0) Progress.earn(pay);
        say("cutemod.fish.msg.sold", bucketCount, pay);
        bucketCount = 0;
        bucketValue = 0;
        sound(1.9F);
        save();
    }

    private void pop(double x, double y, String text) {
        pops.add(new double[]{x, y, 40, pops.size()});
        popText.add(text);
    }

    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        switch (phase) {
            case CAST -> { if (--timer <= 0) { phase = WAIT; timer = 120 + rnd.nextInt(360); splash(bobX(), bobY()); } }
            case WAIT -> {
                if (--timer <= 0) { cur = pick(); phase = BITE; timer = 80; splash(bobX(), bobY()); sound(1.8F); }
            }
            case BITE -> { if (--timer <= 0) { phase = IDLE; say("cutemod.fish.msg.late"); } }
            case REEL -> {
                double sp = 1.5 + RARITY[cur] * 0.55 + hits * 0.3;
                cursor += cdir * sp;
                if (cursor >= BAR_W) { cursor = BAR_W; cdir = -1; }
                if (cursor <= 0) { cursor = 0; cdir = 1; }
            }
            default -> { }
        }
        for (int i = rings.size() - 1; i >= 0; i--) {
            double[] r = rings.get(i);
            r[2] += 0.45;
            if (--r[3] <= 0) rings.remove(i);
        }
        for (int i = pops.size() - 1; i >= 0; i--) {
            double[] p = pops.get(i);
            p[1] -= 0.4;
            if (--p[2] <= 0) { pops.remove(i); popText.remove(i); }
        }
        if (ticks % 900 == 0 && loaded) save();
    }

    // ---------- geometry ----------
    private static final int ROD_X = 70, ROD_Y = 100;                 // the tip of the rod

    private double bobX() { return 190; }

    private double bobY() { return 84; }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (tab == 0) { pond(g, f, mx, my); bottom(g, f, mx, my); } else album(g, f, mx, my);
        bar(g, f, mx, my);
        if (msgT > 0 && tab == 0) {
            int w = f.width(msg) + 12, x = (W - w) / 2;
            rect(g, x, 18, w, 13, 0xEE3A2A3A);
            g.drawString(f, msg, x + 6, 21, 0xFFFFFFFF, false);
        }
    }

    private void bar(GuiGraphics g, Font f, int mx, int my) {
        rect(g, 0, 0, W, TOP, 0xCC123A5A);
        g.drawString(f, t("cutemod.os.fishing"), 5, 3, 0xFFD6F0FF, false);
        tabBtn(g, f, mx, my, 112, "cutemod.fish.tab.pond", tab == 0);
        tabBtn(g, f, mx, my, 160, "cutemod.fish.tab.album", tab == 1);
        String c = Integer.toString(Progress.coins());
        Progress.drawCoin(g, W - 12 - f.width(c), 3);
        g.drawString(f, c, W - 4 - f.width(c), 3, 0xFFFFFFFF, false);
    }

    private void tabBtn(GuiGraphics g, Font f, int mx, int my, int x, String key, boolean on) {
        boolean hov = in(mx, my, x, 1, 46, 12);
        rect(g, x, 1, 46, 12, on ? 0xFFF6F0FA : hov ? 0xFF4A8AC0 : 0xFF2F6A9A);
        String s = t(key);
        g.drawString(f, s, x + (46 - f.width(s)) / 2, 3, on ? TEXT : 0xFFFFFFFF, false);
    }

    private void pond(GuiGraphics g, Font f, int mx, int my) {
        boolean n = night();
        int h = hour();
        boolean dusk = h == 6 || h == 7 || h == 19 || h == 20;
        // sky
        int top = n ? 0xFF1E2A5A : dusk ? 0xFF6A7FD0 : 0xFF78C4FF, bot = n ? 0xFF3A4A8A : dusk ? 0xFFFFB38A : 0xFFD6F0FF;
        for (int y = TOP; y < WATER_Y; y += 2) rect(g, 0, y, W, 2, mix(top, bot, (y - TOP) / (float) (WATER_Y - TOP)));
        if (n) {
            for (int i = 0; i < 16; i++) if ((ticks / 15 + i) % 5 != 0) rect(g, 6 + (i * 53) % (W - 12), 18 + (i * 29) % 24, 1, 1, 0xFFFFFFFF);
            disc(g, 250, 28, 8, 0xFFF4F0D0); disc(g, 253, 26, 7, 0xFF3A4A8A);
        } else {
            disc(g, 250, 26, 8, 0x66FFE070); disc(g, 250, 26, 5, 0xFFFFE070);
        }
        for (int i = 0; i < 6; i++) {                                           // far hills and trees
            int hx = i * 56 - 10;
            disc(g, hx + 28, WATER_Y + 4, 30, n ? 0xFF2A5A4A : 0xFF6FBF7A);
        }
        for (int i = 0; i < 9; i++) { int tx = 8 + i * 34; rect(g, tx, WATER_Y - 14 - (i % 3) * 3, 3, 14 + (i % 3) * 3, 0xFF5A3A22); disc(g, tx + 1, WATER_Y - 17 - (i % 3) * 3, 6, n ? 0xFF2A6A4A : 0xFF4FAE5E); }
        // water
        for (int y = WATER_Y; y < BOT; y += 2) rect(g, 0, y, W, 2, mix(n ? 0xFF1E4A7A : 0xFF4FB8E8, n ? 0xFF0E2A4A : 0xFF1F7BC0, (y - WATER_Y) / (float) (BOT - WATER_Y)));
        for (int i = 0; i < 14; i++) {                                           // little sparkles
            int sx = (i * 61 + ticks / 3) % W, sy = WATER_Y + 4 + (i * 37) % (BOT - WATER_Y - 10);
            if ((ticks / 10 + i) % 4 == 0) rect(g, sx, sy, 3, 1, 0x88FFFFFF);
        }
        for (int i = 0; i < 4; i++) {                                            // dark fish shadows swim around
            double sx = 100 + ((ticks * (0.15 + i * 0.05) + i * 90) % 260) - 20, sy = 70 + i * 17 + Math.sin(ticks / 40.0 + i) * 4;
            oval(g, (int) sx, (int) sy, 8 + i % 2 * 3, 3, 0x22000000);
        }
        for (int i = 0; i < 4; i++) {                                            // lily pads
            int lx = 120 + i * 47, ly = 60 + (i * 31) % 70;
            disc(g, lx, ly, 5, 0xFF4FAE5E); rect(g, lx, ly - 1, 6, 2, mix(0xFF4FAE5E, 0xFF4FB8E8, 0.6f));
            if (i == 1) disc(g, lx - 1, ly - 1, 2, 0xFFFFB8D0);
        }
        for (double[] r : rings) {
            int a = (int) Math.min(120, r[3] * 4);
            ring(g, (int) r[0], (int) r[1], (int) r[2], (a << 24) | 0xFFFFFF);
        }
        dock(g);
        petAndRod(g, f);
        bobber(g, f);
        reeds(g);
        if (phase == REEL) reelBar(g, f);
        if (phase == RESULT) resultCard(g, f);
        for (int i = 0; i < pops.size(); i++) {
            double[] p = pops.get(i);
            String s = popText.get(i);
            g.drawString(f, s, (int) p[0] - f.width(s) / 2, (int) p[1], 0xFFFFE066, true);
        }
        if (n) rect(g, 0, TOP, W, BOT - TOP, 0x2A101040);
        // status line
        String st = switch (phase) {
            case IDLE -> t("cutemod.fish.st.idle");
            case CAST, WAIT -> t("cutemod.fish.st.wait");
            case BITE -> t("cutemod.fish.st.bite");
            case REEL -> t("cutemod.fish.st.reel", hits, NEED[RARITY[cur]]);
            default -> "";
        };
        if (!st.isEmpty()) {
            int w = f.width(st) + 10, x = (W - w) / 2;
            rect(g, x, BOT - 14, w, 12, phase == BITE && (ticks / 6) % 2 == 0 ? 0xEEE5486F : 0xCC123A5A);
            g.drawString(f, st, x + 5, BOT - 12, 0xFFFFFFFF, false);
        }
    }

    private void dock(GuiGraphics g) {
        rect(g, 0, 96, 92, 6, 0xFFB07A4A);
        rect(g, 0, 96, 92, 2, 0xFFD09A62);
        for (int x = 6; x < 92; x += 14) rect(g, x, 96, 1, 6, 0xFF8A5A32);
        rect(g, 10, 102, 4, 22, 0xFF6A4228); rect(g, 70, 102, 4, 22, 0xFF6A4228);
        rect(g, 0, 124, 92, 20, 0x2A000000);
    }

    private void petAndRod(GuiGraphics g, Font f) {
        String color = shell.color().id;
        PetBlob.Info info = PetBlob.parse(Store.read("pet_" + color));
        int stage = info == null ? 2 : info.stage();
        int px = 40, floor = 96;
        float sc = 0.5F * PetArt.scaleOf(stage);
        int mood = phase == BITE ? 2 : phase == RESULT ? 2 : 1;
        g.pose().pushPose();
        g.pose().translate(px, floor, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-px, -floor, 0);
        PetArt.draw(g, shell.color(), px, floor - 28, mood, ticks, false, info != null && info.sick(), stage, Progress.equipped(), Progress.equippedBody());
        g.pose().popPose();
        // the rod: from the pet's paws up and out over the water
        int rx0 = px + 8, ry0 = floor - 8;
        line(g, rx0, ry0, ROD_X + 6, ROD_Y - 40, 0xFF8A5A32, 2);
        // the line to the bobber
        if (phase != IDLE && phase != RESULT) line(g, ROD_X + 6, ROD_Y - 40, (int) bobX(), (int) bobY() + (phase == BITE ? 3 : 0), 0xCCFFFFFF, 1);
    }

    private static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int argb, int w) {
        int n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= n; i++) rect(g, x0 + (x1 - x0) * i / Math.max(1, n), y0 + (y1 - y0) * i / Math.max(1, n), w, w, argb);
    }

    private void bobber(GuiGraphics g, Font f) {
        if (phase == IDLE || phase == RESULT) return;
        int x = (int) bobX();
        int y = (int) bobY();
        if (phase == CAST) { double p = 1 - timer / 28.0; x = (int) (ROD_X + 6 + (bobX() - ROD_X - 6) * p); y = (int) (ROD_Y - 40 + (bobY() - ROD_Y + 40) * p - Math.sin(p * Math.PI) * 24); }
        int bob = phase == WAIT ? (int) Math.round(Math.sin(ticks / 14.0)) : phase == BITE ? 3 + (int) Math.round(Math.sin(ticks / 2.0) * 2) : 0;
        disc(g, x, y + bob, 3, 0xFFFFFFFF);
        rect(g, x - 3, y + bob - 1, 7, 2, 0xFFE5486F);
        rect(g, x, y + bob - 5, 1, 3, 0xFFE5486F);
        if (phase == BITE) {
            rect(g, x - 5, y - 18, 11, 11, 0xFFFFFFFF);
            g.drawString(font(), "!", x - 1, y - 16, 0xFFE5486F, false);
        }
    }

    private void reeds(GuiGraphics g) {
        for (int i = 0; i < 7; i++) {
            int x = 100 + i * 28 + (i % 2) * 6, base = BOT;
            double sway = Math.sin(ticks / 30.0 + i) * 1.5;
            for (int k = 0; k < 4; k++) rect(g, x + (int) (sway * k / 3), base - 6 - k * 6, 2, 6, 0xFF3E9A4A);
            rect(g, x - 1 + (int) sway, base - 32, 4, 7, 0xFF8A5A32);
        }
    }

    private void reelBar(GuiGraphics g, Font f) {
        int zw = ZONE[RARITY[cur]];
        rect(g, BAR_X - 3, BAR_Y - 3, BAR_W + 6, BAR_H + 6, 0xFF123A5A);
        rect(g, BAR_X, BAR_Y, BAR_W, BAR_H, 0xFFE8E2F2);
        rect(g, BAR_X + (int) (zoneC - zw / 2.0), BAR_Y, zw, BAR_H, 0xFF5BD97A);
        rect(g, BAR_X + (int) cursor - 1, BAR_Y - 3, 3, BAR_H + 6, 0xFFE5486F);
        for (int i = 0; i < NEED[RARITY[cur]]; i++) {                      // hits needed
            rect(g, BAR_X + i * 9, BAR_Y - 11, 7, 6, i < hits ? 0xFF5BD97A : 0x88FFFFFF);
        }
        for (int i = 0; i < 2; i++) rect(g, BAR_X + BAR_W - 7 - i * 9, BAR_Y - 11, 7, 6, i < strikes ? 0xFFE5486F : 0x88FFFFFF);
    }

    private void resultCard(GuiGraphics g, Font f) {
        int x = 78, y = 36, w = 144, h = 82;
        rect(g, x - 1, y - 1, w + 2, h + 2, 0xFF123A5A);
        rect(g, x, y, w, h, 0xFFF6F0FA);
        rect(g, x, y, w, 12, RARITY_COL[RARITY[cur]]);
        String name = t("cutemod.fish.name." + cur);
        g.drawString(f, name, x + (w - f.width(name)) / 2, y + 2, 0xFF3A2A3A, false);
        String rar = t("cutemod.fish.rarity." + RARITY[cur]);
        g.drawString(f, rar, x + (w - f.width(rar)) / 2, y + 14, RARITY_COL[RARITY[cur]] == 0xFFB8B8C8 ? MUTED : RARITY_COL[RARITY[cur]], false);
        g.pose().pushPose();
        g.pose().translate(x + w / 2f, y + 42, 0);
        g.pose().scale(2F, 2F, 1F);
        drawFish(g, cur, 0, 0, 1, false, ticks);
        g.pose().popPose();
        String s1 = t("cutemod.fish.size", size, value);
        g.drawString(f, s1, x + (w - f.width(s1)) / 2, y + 60, TEXT, false);
        String s2 = first ? t("cutemod.fish.new", FIRST_BONUS[RARITY[cur]]) : t("cutemod.fish.continue");
        g.drawString(f, s2, x + (w - f.width(s2)) / 2, y + 71, first ? 0xFFE5486F : MUTED, false);
    }

    // ---------- the album ----------
    private static final int CELL_W = 40, CELL_H = 50, GRID_X = 10, GRID_Y = 22;

    private void album(GuiGraphics g, Font f, int mx, int my) {
        rect(g, 0, TOP, W, H - TOP, 0xFFEAF4FF);
        int hover = -1;
        for (int i = 0; i < SPECIES; i++) {
            int x = GRID_X + (i % 7) * (CELL_W - 1) + (i % 7), y = GRID_Y + (i / 7) * (CELL_H + 4);
            boolean seen = count[i] > 0, hov = in(mx, my, x, y, CELL_W, CELL_H);
            if (hov) hover = i;
            rect(g, x, y, CELL_W, CELL_H, hov ? 0xFFFFFFFF : 0xFFF6F0FA);
            rect(g, x, y, CELL_W, 2, seen ? RARITY_COL[RARITY[i]] : 0xFFC9B8D8);
            drawFish(g, i, x + CELL_W / 2, y + 22, 1, !seen, 0);
            String nm = seen ? f.plainSubstrByWidth(t("cutemod.fish.name." + i), CELL_W - 2) : "???";
            g.drawString(f, nm, x + (CELL_W - f.width(nm)) / 2, y + 36, seen ? TEXT : MUTED, false);
            if (seen) {
                String c = "x" + count[i];
                g.drawString(f, c, x + CELL_W - f.width(c) - 2, y + 4, MUTED, false);
            }
        }
        String prog = t("cutemod.fish.collected", caughtKinds(), FISH);
        g.drawString(f, prog, 10, BOT - 4, albumBonus ? 0xFF3E9A4A : TEXT, false);
        String bonus = albumBonus ? t("cutemod.fish.complete") : t("cutemod.fish.bonus", ALBUM_BONUS);
        g.drawString(f, bonus, W - 10 - f.width(bonus), BOT - 4, albumBonus ? 0xFF3E9A4A : MUTED, false);
        if (hover >= 0) {
            String s = count[hover] > 0 ? t("cutemod.fish.tip", t("cutemod.fish.name." + hover), t("cutemod.fish.rarity." + RARITY[hover]), best[hover], PRICE[hover])
                    : t("cutemod.fish.tip.unknown", t("cutemod.fish.rarity." + RARITY[hover]));
            int w = f.width(s) + 8, x = Math.max(2, Math.min(mx + 8, W - w - 2)), y = Math.min(H - 14, my + 12);
            rect(g, x, y, w, 12, 0xEE3A2A3A);
            g.drawString(f, s, x + 4, y + 2, 0xFFFFFFFF, false);
        }
    }

    // ---------- the bottom bar (pond) ----------
    private void bottom(GuiGraphics g, Font f, int mx, int my) {
        rect(g, 0, BOT, W, H - BOT, 0xFF123A5A);
        boolean cast = phase == IDLE;
        btn(g, f, mx, my, 4, 70, t("cutemod.fish.btn.cast"), cast ? 1 : 2);
        boolean any = bucketCount > 0;
        btn(g, f, mx, my, W - 128, 124, any ? t("cutemod.fish.btn.sell", bucketCount, bucketValue) : t("cutemod.fish.btn.empty"), any ? 1 : 2);
        String night = night() ? t("cutemod.fish.night") : "";
        g.drawString(f, night, 80, BOT + 8, 0xFFB8C8FF, false);
    }

    private void btn(GuiGraphics g, Font f, int mx, int my, int x, int w, String label, int style) {
        boolean hov = style != 2 && in(mx, my, x, BOT + 3, w, 16);
        rect(g, x, BOT + 3, w, 16, style == 1 ? (hov ? 0xFF9A6FD0 : 0xFFB57BD6) : 0xFF4A6A8A);
        rect(g, x, BOT + 17, w, 2, 0x33000000);
        String l = f.plainSubstrByWidth(label, w - 4);
        g.drawString(f, l, x + (w - f.width(l)) / 2, BOT + 7, style == 2 ? 0xFF9ABAD0 : 0xFFFFFFFF, false);
    }

    // ---------- fish sprites ----------
    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0.0, 1.0 - (dy * dy) / (double) (ry * ry + 1))));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    private static void ring(GuiGraphics g, int cx, int cy, int r, int argb) {
        if (r < 1) return;
        for (int a = 0; a < 24; a++) {
            double ang = a * Math.PI / 12;
            g.fill(cx + (int) Math.round(Math.cos(ang) * r), cy + (int) Math.round(Math.sin(ang) * r * 0.45),
                    cx + (int) Math.round(Math.cos(ang) * r) + 1, cy + (int) Math.round(Math.sin(ang) * r * 0.45) + 1, argb);
        }
    }

    /** One fish (or junk) centered at (cx, cy). sil = a dark silhouette (not caught yet). */
    private static void drawFish(GuiGraphics g, int id, int cx, int cy, int unused, boolean sil, int t) {
        if (id >= FISH) { junk(g, id, cx, cy, sil); return; }
        int d = 1, rx = RX[id], ry = RY[id], body = sil ? 0xFF2A2A44 : BODY[id], belly = sil ? 0xFF2A2A44 : BELLY[id];
        int wob = (int) Math.round(Math.sin(t / 8.0) * 1.0);
        if (id == 9 && !sil) oval(g, cx, cy, rx + 5, ry + 5, 0x33C8D8FF);                         // the moon fish glows
        int th = ry + (id == 6 ? 5 : 2);                                                           // the tail
        for (int k = 0; k < 5; k++) {
            int h = Math.max(2, (th - k) * 2 - 1);
            rect(g, cx - d * (rx + 1 + k) - (d > 0 ? 0 : -1), cy - h / 2 + wob * (k > 2 ? 1 : 0), 1, h, id == 6 && !sil ? 0xFFFF7A1A : body);
        }
        if (id == 4 && !sil) { rect(g, cx + rx - 1, cy + 1, 5, 1, 0xFF3A3A48); rect(g, cx + rx - 1, cy + 3, 5, 1, 0xFF3A3A48); }       // whiskers
        if (id == 8 && !sil) for (int k = 0; k < 3; k++) { rect(g, cx + rx - 5, cy - ry - 2 - k, 3, 1, 0xFFFF7AA8); rect(g, cx + rx - 5, cy + ry + 1 + k, 3, 1, 0xFFFF7AA8); }   // gills
        if (id == 5 && !sil) for (int k = 0; k < 8; k++) { double a = k * Math.PI / 4; rect(g, cx + (int) Math.round(Math.cos(a) * (rx + 2)), cy + (int) Math.round(Math.sin(a) * (ry + 2)), 1, 1, 0xFFB89A30); }   // spikes
        oval(g, cx, cy, rx, ry, body);
        oval(g, cx, cy + ry / 3, Math.max(2, rx - 2), Math.max(1, ry * 2 / 3), belly);
        oval(g, cx, cy - ry / 3, Math.max(2, rx - 1), Math.max(1, ry * 2 / 3), body);
        if (!sil) {
            if (id == 2) for (int k = 0; k < 3; k++) rect(g, cx - 4 + k * 4, cy - ry + 1, 2, ry * 2 - 1, 0xFF4A6A32);                 // stripes
            if (id == 3) for (int k = 0; k < 5; k++) rect(g, cx - 5 + (k * 5) % 11, cy - 2 + (k * 3) % 5, 1, 1, 0xFF4A5A5A);       // spots
            if (id == 7) { disc(g, cx - 3, cy - 1, 3, 0xFFE5486F); disc(g, cx + 4, cy + 1, 2, 0xFFE5486F); }
            if (id == 10) { disc(g, cx - 3, cy - 1, 3, 0xFFFFFFFF); disc(g, cx + 4, cy + 1, 2, 0xFFFFFFFF); rect(g, cx - rx, cy - 1, 2, 2, 0xFFFFE680); }
            if (id == 11) { int[] rb = {0xFFE5486F, 0xFFFFD84A, 0xFF5BD97A, 0xFF5BA8F0}; for (int k = 0; k < 4; k++) rect(g, cx - rx + 2, cy - 3 + k * 2, rx * 2 - 5, 1, rb[k]); }
            rect(g, cx + rx - 4, cy - 2, 2, 2, 0xFFFFFFFF); rect(g, cx + rx - 3, cy - 2, 1, 1, 0xFF2A1A2A);                            // eye
            rect(g, cx - 1, cy - ry - 1, 4, 1, body);                                                                                    // a fin on top
        }
    }

    private static void junk(GuiGraphics g, int id, int cx, int cy, boolean sil) {
        if (id == 12) {                                                                           // an old boot
            int c = sil ? 0xFF2A2A44 : 0xFF7A5232;
            rect(g, cx - 5, cy - 8, 6, 12, c); rect(g, cx - 5, cy + 2, 13, 5, c);
            if (!sil) { rect(g, cx - 5, cy - 8, 6, 2, 0xFF4A3018); rect(g, cx - 3, cy - 2, 3, 1, 0xFFE8D8B8); rect(g, cx - 3, cy, 3, 1, 0xFFE8D8B8); }
        } else {                                                                                  // a tin can
            int c = sil ? 0xFF2A2A44 : 0xFFB8C0C8;
            rect(g, cx - 5, cy - 6, 10, 12, c);
            if (!sil) { rect(g, cx - 5, cy - 6, 10, 2, 0xFFE8EEF4); rect(g, cx - 5, cy - 1, 10, 3, 0xFFE5486F); rect(g, cx - 5, cy + 4, 10, 2, 0xFF8A929A); }
        }
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (in(x, y, 112, 1, 46, 12)) { tab = 0; return true; }
        if (in(x, y, 160, 1, 46, 12)) { tab = 1; return true; }
        if (tab != 0) return true;
        if (y >= BOT) {
            if (phase == IDLE && in(x, y, 4, BOT + 3, 70, 16)) { cast(); return true; }
            if (in(x, y, W - 128, BOT + 3, 124, 16)) { sell(); return true; }
            return true;
        }
        switch (phase) {
            case IDLE -> { if (y > WATER_Y) cast(); }
            case WAIT -> { phase = IDLE; say("cutemod.fish.msg.early"); }
            case BITE -> beginReel();
            case REEL -> reelClick();
            case RESULT -> phase = IDLE;
            default -> { }
        }
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (keyCode == 32 && tab == 0) { click(150, 80, 0); return true; }                    // space = the same as a click on the water
        return false;
    }
}
