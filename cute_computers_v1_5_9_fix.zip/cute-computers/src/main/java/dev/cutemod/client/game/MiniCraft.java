package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * MiniCraft: a tiny side-view Minecraft.
 * Walk (A/D), jump (W / Space), left click = mine / hit a zombie, right click = place a block.
 * Press E for the crafting grid (3x3, real shaped recipes like in Minecraft): logs -> planks -> sticks -> pickaxes,
 * swords, torches and a furnace. A furnace (right click it) melts iron ore with coal into ingots: the iron pickaxe needs
 * 3 ingots. Dig down and find 3 diamonds. Underground it is dark: use torches. Chests hide in caves, lava hides in
 * the deep, apples (H) heal.
 * At night zombies come. You lose when your hearts run out.
 */
public class MiniCraft extends MiniGame {
    private static final int T = 10, WW = 80, WH = 40;          // tile size in px, world size in tiles
    private static final double REACH = 5, PW = 0.7, PH = 1.8, ZW = 0.7, ZH = 1.8;
    private static final int DAY = 7200, NIGHT = 4800, DIAMONDS = 3;

    // blocks
    private static final int AIR = 0, GRASS = 1, DIRT = 2, STONE = 3, LOG = 4, LEAVES = 5, COAL = 6, IRON = 7,
            DIAMOND = 8, BEDROCK = 9, PLANKS = 10, TORCH = 11, CHEST = 12, LAVA = 13, FURNACE = 14,
            INGOT = 15, APPLE = 16;                                                  // the last two are only items
    private static final int[] HARD = {0, 1, 1, 4, 3, 1, 4, 6, 8, 999, 3, 1, 2, 999, 4, 0, 0};   // damage needed to break
    private static final int[] NEED = {0, 0, 0, 1, 0, 0, 1, 2, 3, 9, 0, 0, 0, 9, 0, 0, 0};       // pickaxe tier needed
    private static final int[] POINTS = {0, 1, 1, 2, 3, 0, 5, 10, 50, 0, 0, 0, 0, 0, 0, 0, 0};
    private static final int[] BASE = {0, 0xFF8A5A33, 0xFF8A5A33, 0xFF7C7C84, 0xFF6B4A2B, 0xFF2F8F3A, 0xFF7C7C84,
            0xFF7C7C84, 0xFF7C7C84, 0xFF2A2A30, 0xFFC49A5A, 0xFF000000, 0xFF9A6B2A, 0xFFE8501A, 0xFF7C7C84,
            0xFFE8E8EE, 0xFFE5484D};
    private static final int[] HOTBAR = {DIRT, STONE, LOG, PLANKS, TORCH, FURNACE};    // what keys 1-6 place
    private static final int[] PICK = {0, 0xFFC49A5A, 0xFF9A9AA2, 0xFFE8E8EE};    // pickaxe head colors by tier
    
    // crafting: item ids above the blocks. Tools are not items, crafting one upgrades you at once.
    private static final int STICK = 17, PICK1 = 20, PICK2 = 21, PICK3 = 22, SWORD1 = 23, SWORD2 = 24, SWORD3 = 25;
    private static final int[] PALETTE = {DIRT, STONE, LOG, PLANKS, STICK, COAL, TORCH, IRON, INGOT, DIAMOND, FURNACE, APPLE};
    /** A shaped recipe: rows of letters (P planks, S stick, T stone, I ingot, C coal, L log, . empty). Position in the grid does not matter. */
    private record Recipe(String[] rows, int result, int count) {}
    private static final Recipe[] RECIPES = {
            new Recipe(new String[]{"L"}, PLANKS, 4),
            new Recipe(new String[]{"P", "P"}, STICK, 4),
            new Recipe(new String[]{"C", "S"}, TORCH, 4),
            new Recipe(new String[]{"TTT", "T.T", "TTT"}, FURNACE, 1),
            new Recipe(new String[]{"PPP", ".S.", ".S."}, PICK1, 1),
            new Recipe(new String[]{"TTT", ".S.", ".S."}, PICK2, 1),
            new Recipe(new String[]{"III", ".S.", ".S."}, PICK3, 1),
            new Recipe(new String[]{"P", "P", "S"}, SWORD1, 1),
            new Recipe(new String[]{"T", "T", "S"}, SWORD2, 1),
            new Recipe(new String[]{"I", "I", "S"}, SWORD3, 1)};

    private static final class Zombie {
        final double[] b = new double[4];                       // x, y, vx, vy
        int hp = 5, hurt, knock, stuck;
        boolean ground;
    }

    private int[][] world = new int[WH][WW];
    private final int[] top = new int[WW];                      // height of the ground in every column
    private final int[] inv = new int[32];
    private final double[] pl = new double[4];                  // player x, y, vx, vy
    private final List<Zombie> zs = new ArrayList<>();
    private boolean ground, won;
    private int hp, tier, sel, face, grace, knock, ticks, time, hx, hy, hit, camX, camY, msgT, lavaT;
    private String msg = "";
    private boolean crafting;
    private final int[] cell = new int[9], cnt = new int[9];     // the crafting grid: an item and how many of it
    private int held, sword;                                     // the item you put in with a click, the sword tier (0-3)
    private boolean msgRaw;                                      // msg is a ready text, not a lang key
    private final List<int[]> lights = new ArrayList<>();        // torches and lava: x, y, radius in 1/10 tiles
    private boolean lightDirty = true;

    @Override
    public void reset() {
        score = 0; over = false; won = false;
        hp = 10; tier = 0; sword = 0; sel = 0; lavaT = 0; lightDirty = true; crafting = false; held = 0;
        java.util.Arrays.fill(cell, 0); java.util.Arrays.fill(cnt, 0); face = 1; grace = 0; knock = 0; ticks = 0; time = 600; hit = 0;
        java.util.Arrays.fill(inv, 0);
        zs.clear();
        generate();
        pl[0] = WW / 2.0 - PW / 2;
        pl[1] = Math.min(top[WW / 2 - 1], Math.min(top[WW / 2], top[WW / 2 + 1])) - PH;   // above the highest of the columns we stand on
        pl[2] = pl[3] = 0;
        say("cutemod.craft.start");
    }

    // ---------- the world ----------
    private void generate() {
        double p1 = rnd.nextDouble() * 6.28, p2 = rnd.nextDouble() * 6.28;
        for (int x = 0; x < WW; x++) top[x] = (int) Math.round(16 + 3 * Math.sin(x * 0.12 + p1) + 2 * Math.sin(x * 0.31 + p2));
        for (int x = 1; x < WW; x++) top[x] = Math.max(top[x - 1] - 1, Math.min(top[x - 1] + 1, top[x]));   // hills at most 1 block per step: you can always jump up
        for (int y = 0; y < WH; y++) for (int x = 0; x < WW; x++) {
            int d = y - top[x];
            double r = rnd.nextDouble();
            world[y][x] = y == WH - 1 ? BEDROCK : d < 0 ? AIR : d == 0 ? GRASS : d <= 3 ? DIRT
                    : (d > 3 && r < 0.05) ? COAL : (d > 7 && r > 0.95 && r < 0.975) ? IRON : (d > 14 && r > 0.992) ? DIAMOND : STONE;
        }
        List<int[]> caves = new ArrayList<>();
        for (int i = 0; i < 14; i++) {                            // caves: round holes in the stone
            int cx = 4 + rnd.nextInt(WW - 8), cy = top[cx] + 6 + rnd.nextInt(WH - top[cx] - 10);
            caves.add(new int[]{cx, cy});
            for (int y = cy - 2; y <= cy + 2; y++) for (int x = cx - 2; x <= cx + 2; x++) {
                if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= 5 && y < WH - 1) world[y][x] = AIR;
            }
        }
        for (int[] c : caves) {                                   // half of the caves hide a chest on their floor
            if (rnd.nextInt(2) != 0) continue;
            for (int y = c[1] + 2; y >= c[1] - 2; y--) {
                if (y + 1 < WH && world[y][c[0]] == AIR && world[y + 1][c[0]] != AIR) { world[y][c[0]] = CHEST; break; }
            }
        }
        for (int[] c : caves) {                                   // deep caves can have a lava lake in the bottom
            if (c[1] <= top[c[0]] + 12 || rnd.nextInt(5) >= 2) continue;
            for (int y = c[1] + 1; y <= c[1] + 2; y++) for (int x = c[0] - 2; x <= c[0] + 2; x++) {
                if (x >= 0 && x < WW && y < WH - 1 && world[y][x] == AIR) world[y][x] = LAVA;
            }
        }
        for (int i = 0; i < 3; i++) {                             // and lava pools near the bedrock
            int x0 = 3 + rnd.nextInt(WW - 12), w = 3 + rnd.nextInt(3);
            for (int x = x0; x < x0 + w; x++) for (int y = WH - 3; y <= WH - 2; y++) world[y][x] = LAVA;
        }
        for (int x = 4; x < WW - 4; x++) {                        // trees
            if (rnd.nextInt(8) != 0 || Math.abs(x - WW / 2) < 4) continue;
            int th = 3 + rnd.nextInt(2), ty = top[x] - th;
            for (int i = 1; i <= th; i++) world[top[x] - i][x] = LOG;
            for (int dy = -2; dy <= 0; dy++) for (int dx = -2; dx <= 2; dx++) {
                if (Math.abs(dx) == 2 && dy == -2) continue;
                if (world[ty + dy][x + dx] == AIR) world[ty + dy][x + dx] = LEAVES;
            }
            x += 3;
        }
        int found = 0;                                            // make sure there are enough diamonds
        for (int[] r : world) for (int b : r) if (b == DIAMOND) found++;
        while (found < 5) {
            int x = 2 + rnd.nextInt(WW - 4), y = top[x] + 14 + rnd.nextInt(WH - top[x] - 16);
            if (world[y][x] == STONE) { world[y][x] = DIAMOND; found++; }
        }
    }

    private int at(int x, int y) {
        if (x < 0 || x >= WW || y >= WH) return BEDROCK;
        return y < 0 ? AIR : world[y][x];
    }

    /** Torches and lava can be walked through. */
    private static boolean solid(int b) { return b != AIR && b != TORCH && b != LAVA; }

    private boolean touches(double x, double y, double w, double h, int type) {
        for (int ty = (int) Math.floor(y); ty <= (int) Math.floor(y + h - 0.001); ty++)
            for (int tx = (int) Math.floor(x); tx <= (int) Math.floor(x + w - 0.001); tx++)
                if (at(tx, ty) == type) return true;
        return false;
    }

    private boolean hits(double x, double y, double w, double h) {
        for (int ty = (int) Math.floor(y); ty <= (int) Math.floor(y + h - 0.001); ty++)
            for (int tx = (int) Math.floor(x); tx <= (int) Math.floor(x + w - 0.001); tx++)
                if (solid(at(tx, ty))) return true;
        return false;
    }

    /** Gravity + walls for a box b = {x, y, vx, vy}. Returns true if it stands on something. */
    private boolean move(double[] b, double w, double h) {
        b[3] = Math.min(0.5, b[3] + 0.02);
        if (!hits(b[0] + b[2], b[1], w, h)) b[0] += b[2]; else b[2] = 0;
        double ny = b[1] + b[3];
        if (!hits(b[0], ny, w, h)) { b[1] = ny; return false; }
        boolean down = b[3] > 0;
        if (down) b[1] = Math.floor(ny + h) - h;
        b[3] = 0;
        return down;
    }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private void say(String key) { msg = key; msgRaw = false; msgT = 150; }

    private void sayRaw(String text) { msg = text; msgRaw = true; msgT = 150; }

    private float dark() {
        return time < 300 ? 1 - time / 300F : time < 4200 ? 0 : time < NIGHT ? (time - 4200) / 600F : 1;
    }

    // ---------- game loop ----------
    @Override
    public void tick() {
        ticks++;
        time = (time + 1) % DAY;
        if (msgT > 0) msgT--;
        if (grace > 0) grace--;
        if (ticks % 600 == 0 && hp < 10) hp++;                       // hearts come back slowly

        double dir = crafting ? 0 : (down(68) || down(KEY_RIGHT) ? 1 : 0) - (down(65) || down(KEY_LEFT) ? 1 : 0);
        if (knock > 0) knock--;
        else {
            pl[2] = dir * 0.07;
            if (dir != 0) face = (int) dir;
        }
        boolean step = dir != 0 && knock == 0 && hits(pl[0] + dir * 0.1, pl[1], PW, PH) && !hits(pl[0] + dir * 0.1, pl[1] - 1.05, PW, PH);   // a one block step: jump on it by itself
        if (ground && (step || (!crafting && (down(87) || down(KEY_UP) || down(KEY_SPACE))))) pl[3] = -0.28;
        ground = move(pl, PW, PH);
        if (touches(pl[0], pl[1], PW, PH, LAVA)) {                    // lava burns, and you swim in it slowly (hold W to climb out)
            if (lavaT++ % 40 == 0) { hp--; pling(0.4F); say("cutemod.craft.lava"); }
            pl[3] = Math.min(pl[3], 0.04);
            if (down(87) || down(KEY_UP) || down(KEY_SPACE)) pl[3] = -0.07;
        } else lavaT = 0;

        if (dark() > 0.6F && zs.size() < 4 && ticks % 240 == 0) spawnZombie();
        if (time == 300) zs.clear();                                 // zombies burn at dawn
        for (Zombie z : new ArrayList<>(zs)) {
            double dx = pl[0] + PW / 2 - (z.b[0] + ZW / 2), d = Math.signum(dx);
            if (z.knock > 0) z.knock--; else z.b[2] = d * 0.025;
            boolean blocked = z.ground && z.knock == 0 && hits(z.b[0] + d * 0.15, z.b[1], ZW, ZH);
            if (blocked && !hits(z.b[0] + d * 0.15, z.b[1] - 1.05, ZW, ZH)) z.b[3] = -0.28;   // hop over a one block step
            else if (blocked && ++z.stuck > 40) chew(z, d);                                    // too high: chew through trees
            if (!blocked) z.stuck = 0;
            z.ground = move(z.b, ZW, ZH);
            if (z.hurt > 0) z.hurt--;
            boolean touch = Math.abs(dx) < (PW + ZW) / 2 && Math.abs(pl[1] + PH / 2 - z.b[1] - ZH / 2) < (PH + ZH) / 2;
            if (touch && grace == 0) {                                // ouch
                hp--;
                grace = 60;
                knock = 10;
                pl[2] = -d * 0.15;
                pl[3] = -0.15;
                pling(0.6F);
            }
        }
        if (hp <= 0) { over = true; pling(0.5F); return; }
        if (inv[DIAMOND] >= DIAMONDS) {
            won = true;
            over = true;
            score += 300;
            pling(1.0F); pling(1.5F); pling(2.0F);
        }
    }

    /** A zombie that is stuck breaks the wood, leaves, grass and dirt in front of it. Stone and planks stop it: build a wall! */
    private void chew(Zombie z, double d) {
        int tx = (int) Math.floor(z.b[0] + (d > 0 ? ZW + 0.2 : -0.2));
        for (int ty = (int) Math.floor(z.b[1]); ty <= (int) Math.floor(z.b[1] + ZH - 0.001); ty++) {
            int b = at(tx, ty);
            if (b == LOG || b == LEAVES || b == GRASS || b == DIRT) world[ty][tx] = AIR;
        }
        z.stuck = 0;
    }

    private void spawnZombie() {
        int x = (int) pl[0] + (rnd.nextInt(2) == 0 ? -1 : 1) * (14 + rnd.nextInt(8));
        x = Math.max(1, Math.min(WW - 2, x));
        int y = 0;
        while (y < WH && at(x, y) == AIR) y++;
        Zombie z = new Zombie();
        z.b[0] = x;
        z.b[1] = y - ZH;
        zs.add(z);
    }

    // ---------- mouse and keys ----------
    private void updateCam() {
        camX = Math.max(0, Math.min(WW * T - W, (int) ((pl[0] + PW / 2) * T) - W / 2));
        camY = Math.max(0, Math.min(WH * T - H, (int) ((pl[1] + PH / 2) * T) - H / 2));
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (crafting) { craftClick(x, y, button); return true; }
        int hx0 = (W - HOTBAR.length * 22) / 2;
        if (in(x, y, hx0, H - 20, HOTBAR.length * 22, 20)) { sel = (x - hx0) / 22; return true; }   // click a hotbar slot
        updateCam();
        double wx = (x + camX) / (double) T, wy = (y + camY) / (double) T;
        if (Math.hypot(wx - (pl[0] + PW / 2), wy - (pl[1] + PH / 2)) > REACH) return true;
        int tx = (int) Math.floor(wx), ty = (int) Math.floor(wy), here = at(tx, ty);
        if (button == 0) {
            if (!hitZombie(wx, wy)) mine(tx, ty);
        } else if (here == CHEST) {
            openChest(tx, ty);
        } else if (here == FURNACE) {
            smelt();
        } else {
            place(tx, ty);
        }
        return true;
    }

    private boolean hitZombie(double wx, double wy) {
        for (Zombie z : zs) {
            if (wx >= z.b[0] - 0.2 && wx <= z.b[0] + ZW + 0.2 && wy >= z.b[1] && wy <= z.b[1] + ZH) {
                z.hp -= 1 + tier + sword;
                z.hurt = 8;
                z.knock = 10;
                z.b[2] = face * 0.12;
                z.b[3] = -0.12;
                beep();
                if (z.hp <= 0) { zs.remove(z); score += 10; pling(1.6F); }
                return true;
            }
        }
        return false;
    }

    private void mine(int tx, int ty) {
        int b = at(tx, ty);
        if (b == AIR || b == BEDROCK || b == LAVA) return;
        if (b == CHEST) { openChest(tx, ty); return; }
        if (NEED[b] > tier) { say("cutemod.craft.need"); beep(); return; }
        if (tx != hx || ty != hy) { hx = tx; hy = ty; hit = 0; }
        hit += 1 + tier;                                              // better pickaxe = bigger hits
        beep();
        if (hit < HARD[b]) return;
        world[ty][tx] = AIR;
        lightDirty = true;
        hit = 0;
        if (b == LEAVES && rnd.nextInt(12) == 0) { inv[APPLE]++; pling(1.4F); }       // leaves sometimes drop an apple
        int item = b == GRASS ? DIRT : b == LEAVES ? 0 : b;
        if (item != 0) inv[item]++;
        score += POINTS[b];
        if (b == DIAMOND) { pling(2.0F); say("cutemod.craft.diamond"); }
        else if (b == COAL || b == IRON) pling(1.7F);
        else pling(1.0F);
    }

    private void place(int tx, int ty) {
        int item = HOTBAR[sel];
        int here = at(tx, ty);
        if ((here != AIR && here != LAVA) || inv[item] <= 0) return;      // blocks can cover lava
        if (item != TORCH) {
            if (tx + 1 > pl[0] && tx < pl[0] + PW && ty + 1 > pl[1] && ty < pl[1] + PH) return;   // not inside you
            for (Zombie z : zs) if (tx + 1 > z.b[0] && tx < z.b[0] + ZW && ty + 1 > z.b[1] && ty < z.b[1] + ZH) return;
        }
        world[ty][tx] = item;
        lightDirty = true;
        inv[item]--;
        beep();
    }

    private String itemName(int item) {
        String k = switch (item) {
            case COAL -> "coal";
            case TORCH -> "torch";
            case PLANKS -> "planks";
            case IRON -> "iron";
            case APPLE -> "apple";
            default -> "diamond";
        };
        return Component.translatable("cutemod.craft.it." + k).getString();
    }

    /** A chest gives 3 random things (and very rarely a diamond) and disappears. */
    private void openChest(int tx, int ty) {
        world[ty][tx] = AIR;
        lightDirty = true;
        List<int[]> pool = new ArrayList<>();
        pool.add(new int[]{COAL, 1 + rnd.nextInt(3)});
        pool.add(new int[]{TORCH, 2 + rnd.nextInt(3)});
        pool.add(new int[]{PLANKS, 2 + rnd.nextInt(4)});
        pool.add(new int[]{IRON, 1 + rnd.nextInt(2)});
        pool.add(new int[]{APPLE, 1 + rnd.nextInt(2)});
        Collections.shuffle(pool, new java.util.Random(rnd.nextLong()));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            int[] it = pool.get(i);
            inv[it[0]] += it[1];
            sb.append(i > 0 ? ", " : "").append(itemName(it[0])).append(" x").append(it[1]);
        }
        if (rnd.nextInt(20) == 0) { inv[DIAMOND]++; sb.append(", ").append(itemName(DIAMOND)); }
        score += 20;
        pling(1.8F);
        sayRaw(Component.translatable("cutemod.craft.chest", sb.toString()).getString());
    }

    /** Right click on a furnace: 1 iron ore + 1 coal = 1 ingot. */
    private void smelt() {
        if (inv[IRON] < 1) { say("cutemod.craft.noiron"); beep(); return; }
        if (inv[COAL] < 1) { say("cutemod.craft.nocoal"); beep(); return; }
        inv[IRON]--;
        inv[COAL]--;
        inv[INGOT]++;
        say("cutemod.craft.smelt");
        pling(1.3F);
    }

    // ---------- the crafting grid ----------
    private static int ingredient(char c) {
        return switch (c) {
            case 'P' -> PLANKS;
            case 'S' -> STICK;
            case 'T' -> STONE;
            case 'I' -> INGOT;
            case 'C' -> COAL;
            case 'L' -> LOG;
            default -> AIR;
        };
    }

    /** The recipe the grid shows right now (the pattern may sit anywhere in the 3x3), or null. */
    private Recipe match() {
        int minX = 3, minY = 3, maxX = -1, maxY = -1;
        for (int i = 0; i < 9; i++) {
            if (cell[i] == 0) continue;
            minX = Math.min(minX, i % 3); maxX = Math.max(maxX, i % 3);
            minY = Math.min(minY, i / 3); maxY = Math.max(maxY, i / 3);
        }
        if (maxX < 0) return null;
        int w = maxX - minX + 1, h = maxY - minY + 1;
        for (Recipe r : RECIPES) {
            if (r.rows().length != h || r.rows()[0].length() != w) continue;
            boolean ok = true;
            for (int y = 0; y < h && ok; y++) for (int x = 0; x < w; x++) {
                if (cell[(minY + y) * 3 + minX + x] != ingredient(r.rows()[y].charAt(x))) { ok = false; break; }
            }
            if (ok) return r;
        }
        return null;
    }

    private void openCraft() {
        crafting = true;
        if (held == 0 || inv[held] == 0) {
            held = 0;
            for (int it : PALETTE) if (inv[it] > 0) { held = it; break; }
        }
    }

    private void closeCraft() {                                       // everything in the grid goes back to your pockets
        for (int i = 0; i < 9; i++) { if (cell[i] != 0) inv[cell[i]] += cnt[i]; cell[i] = 0; cnt[i] = 0; }
        crafting = false;
    }

    private void doCraft() {
        Recipe r = match();
        if (r == null) { beep(); return; }
        if (r.result() >= PICK1 && r.result() <= PICK3) {
            int n = r.result() - PICK1 + 1;
            if (tier >= n) { say("cutemod.craft.have"); beep(); return; }
            tier = n;
            say("cutemod.craft.pick" + n);
        } else if (r.result() >= SWORD1) {
            int n = r.result() - SWORD1 + 1;
            if (sword >= n) { say("cutemod.craft.have"); beep(); return; }
            sword = n;
            say("cutemod.craft.sword" + n);
        } else {
            inv[r.result()] += r.count();
        }
        for (int i = 0; i < 9; i++) if (cell[i] != 0 && --cnt[i] <= 0) { cell[i] = 0; cnt[i] = 0; }
        pling(1.4F);
    }

    private void craftClick(int x, int y, int button) {
        if (in(x, y, 194, 7, 10, 10)) { closeCraft(); return; }
        for (int i = 0; i < 9; i++) {
            if (!in(x, y, 16 + (i % 3) * 16, 24 + (i / 3) * 16, 16, 16)) continue;
            if (button == 0) {                                        // left: put one of the chosen item in
                if (held == 0 || inv[held] <= 0 || (cell[i] != 0 && cell[i] != held) || cnt[i] >= 64) { beep(); return; }
                cell[i] = held; cnt[i]++; inv[held]--;
            } else if (cell[i] != 0) {                                // right: take one out
                inv[cell[i]]++;
                if (--cnt[i] <= 0) { cell[i] = 0; cnt[i] = 0; }
            }
            return;
        }
        if (in(x, y, 84, 40, 20, 20)) { doCraft(); return; }
        for (int i = 0; i < PALETTE.length; i++) {
            if (in(x, y, 16 + (i % 9) * 21, 82 + (i / 9) * 20, 19, 18)) { held = PALETTE[i]; return; }
        }
    }

    @Override
    public boolean key(int k) {
        if (k >= 49 && k < 49 + HOTBAR.length) { sel = k - 49; return true; }       // 1-6
        if (k == 69) {                                                // E: the crafting grid
            if (crafting) closeCraft(); else openCraft();
            return true;
        }
        if (crafting) return true;
        if (k == 72) {                                                // H: eat an apple
            if (inv[APPLE] <= 0) say("cutemod.craft.noapple");
            else if (hp >= 10) say("cutemod.craft.hearts_full");
            else { inv[APPLE]--; hp = Math.min(10, hp + 3); say("cutemod.craft.eat"); pling(1.6F); }
            return true;
        }
        return false;
    }

    // ---------- drawing ----------
    private static int lerp(int a, int b, float f) {
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private void rebuildLights() {
        lights.clear();
        for (int y = 0; y < WH; y++) for (int x = 0; x < WW; x++) {
            if (world[y][x] == TORCH) lights.add(new int[]{x, y, 65});
            else if (world[y][x] == LAVA) lights.add(new int[]{x, y, 45});
        }
        lightDirty = false;
    }

    /** 0 = dark, 1 = fully lit: torches and lava glow, and you carry a faint light of your own. */
    private float lightAt(int x, int y) {
        float best = 0;
        for (int[] l : lights) {
            int dx = Math.abs(l[0] - x), dy = Math.abs(l[1] - y);
            if (dx > 7 || dy > 7) continue;
            float v = 1 - (float) Math.hypot(dx, dy) / (l[2] / 10F);
            if (v > best) best = v;
        }
        double pd = Math.hypot(x + 0.5 - pl[0] - PW / 2, y + 0.5 - pl[1] - PH / 2);
        return Math.max(best, (float) Math.max(0, 0.55 * (1 - pd / 3.5)));
    }

    private void tile(GuiGraphics g, int b, int x, int y, int sx, int sy) {
        if (b != TORCH) rect(g, sx, sy, T, T, BASE[b]);
        int h = ((x * 73856093) ^ (y * 19349663)) & 15;
        switch (b) {
            case GRASS -> { rect(g, sx, sy, T, 3, 0xFF6FD45A); rect(g, sx + h % 8, sy + 3, 2, 1, 0xFF6FD45A); rect(g, sx + 2 + h % 5, sy + 6, 2, 2, 0xFF6B4A2B); }
            case DIRT -> { rect(g, sx + h % 7, sy + 2, 2, 2, 0xFF6B4A2B); rect(g, sx + 6 - h % 5, sy + 6, 2, 2, 0xFFA07040); }
            case STONE -> { rect(g, sx + h % 7, sy + 2, 2, 2, 0xFF6A6A72); rect(g, sx + 7 - h % 5, sy + 6, 2, 2, 0xFF8E8E96); }
            case COAL, IRON, DIAMOND -> {
                int c = b == COAL ? 0xFF1A1A1E : b == IRON ? 0xFFD8A878 : 0xFF4AEDD9;
                rect(g, sx + 1, sy + 1, 2, 2, c); rect(g, sx + 6, sy + 2, 2, 2, c);
                rect(g, sx + 2, sy + 6, 2, 2, c); rect(g, sx + 7, sy + 7, 2, 2, c);
            }
            case LOG -> { rect(g, sx + 2, sy, 1, T, 0xFF4A3018); rect(g, sx + 7, sy, 1, T, 0xFF4A3018); }
            case LEAVES -> { rect(g, sx + h % 7, sy + 1, 2, 2, 0xFF4FB85A); rect(g, sx + 7 - h % 6, sy + 6, 2, 2, 0xFF1E6A2A); }
            case PLANKS -> { rect(g, sx, sy + 3, T, 1, 0xFF9A7440); rect(g, sx, sy + 7, T, 1, 0xFF9A7440); }
            case TORCH -> {
                int fl = (ticks / 6 + x) % 3 == 0 ? 1 : 0;
                rect(g, sx + 4, sy + 4, 2, 6, 0xFF8A5A33);
                rect(g, sx + 3, sy + 1 + fl, 4, 4, 0xFFFFA030);
                rect(g, sx + 4, sy + 2 + fl, 2, 2, 0xFFFFF0A0);
            }
            case CHEST -> {
                rect(g, sx, sy, T, 1, 0xFF5A3A14); rect(g, sx, sy + 3, T, 1, 0xFF5A3A14); rect(g, sx, sy + T - 1, T, 1, 0xFF5A3A14);
                rect(g, sx + 4, sy + 3, 2, 3, 0xFFE8D060);
            }
            case LAVA -> {
                rect(g, sx + (ticks / 8 + x * 3) % 8, sy + 3 + (y % 3) * 2, 3, 2, 0xFFFFB030);
                if (at(x, y - 1) != LAVA) rect(g, sx, sy, T, 2, 0xFFFFC040);
            }
            case FURNACE -> {
                rect(g, sx + 2, sy + 4, 6, 4, 0xFF2A2A30);
                rect(g, sx + 3, sy + 6, 2, 1, 0xFFFF8030);
                rect(g, sx, sy, T, 1, 0xFF9A9AA2);
            }
            default -> rect(g, sx + h % 7, sy + 3, 3, 2, 0xFF3C3C44);
        }
        int depth = y - top[x] - 5;
        if (depth > 0 && b != LAVA) {                                  // deeper = darker, unless a torch or lava is near
            int a = (int) (Math.min(0xC0, depth * 8) * (1 - lightAt(x, y)));
            if (a > 0) rect(g, sx, sy, T, T, a << 24);
        }
    }

    private void heart(GuiGraphics g, int x, int y, int col) {
        rect(g, x, y, 2, 1, col); rect(g, x + 3, y, 2, 1, col);
        rect(g, x, y + 1, 5, 1, col); rect(g, x + 1, y + 2, 3, 1, col); rect(g, x + 2, y + 3, 1, 1, col);
    }

    private void person(GuiGraphics g, double[] b, int dir, boolean zombie, int flash) {
        int sx = (int) (b[0] * T) - camX, sy = (int) (b[1] * T) - camY;
        int walk = Math.abs(b[2]) > 0.01 && (ticks / 8) % 2 == 0 ? 1 : 0;
        rect(g, sx + 1 + walk, sy + 13, 2, 5, 0xFF3A3A8A);                 // legs
        rect(g, sx + 4 - walk, sy + 13, 2, 5, 0xFF3A3A8A);
        rect(g, sx, sy + 7, 7, 6, zombie ? 0xFF2A7A8A : 0xFF3AB5D9);        // body
        rect(g, sx, sy, 7, 7, zombie ? 0xFF5A9A4A : 0xFFF0C8A0);           // head
        rect(g, sx, sy, 7, 2, zombie ? 0xFF3A6A30 : 0xFF4A2A14);           // hair
        rect(g, sx + (dir > 0 ? 4 : 1), sy + 3, 2, 1, zombie ? 0xFF111111 : 0xFF2A2A5A);   // eye
        if (zombie) rect(g, sx + (dir > 0 ? 5 : -2), sy + 8, 4, 2, 0xFF5A9A4A);            // arm held out
        else if (sword > 0) {                                               // a sword in hand
            int px = dir > 0 ? sx + 7 : sx - 2;
            rect(g, px, sy + 1, 2, 9, PICK[sword]);
            rect(g, px - 1, sy + 10, 4, 1, 0xFF6B4A2B);
        } else if (tier > 0) {                                                // pickaxe in hand
            int px = dir > 0 ? sx + 7 : sx - 5;
            rect(g, px, sy + 8, 5, 1, 0xFF6B4A2B);
            rect(g, dir > 0 ? px + 3 : px, sy + 6, 2, 3, PICK[tier]);
        }
        if (flash > 0) rect(g, sx, sy, 7, 18, 0x88FF0000);
    }

    @Override
    public void render(GuiGraphics g) {
        updateCam();
        float dk = dark();
        g.fillGradient(0, 0, W, H, lerp(0xFF7EC8F0, 0xFF0A1030, dk), lerp(0xFFCFEFFF, 0xFF1B2850, dk));
        double frac = time < NIGHT ? time / (double) NIGHT : (time - NIGHT) / (double) (DAY - NIGHT);
        int ox = 15 + (int) (frac * 190), oy = 45 - (int) (Math.sin(frac * Math.PI) * 32);
        if (time < NIGHT) disc(g, ox, oy, 6, 0xFFFFE066); else { disc(g, ox, oy, 5, 0xFFEFEFF5); disc(g, ox + 2, oy - 1, 4, lerp(0xFF7EC8F0, 0xFF0A1030, 1)); }
        if (dk > 0.5F) for (int i = 0; i < 14; i++) rect(g, (i * 53 + 7) % W, (i * 31) % 50, 1, 1, 0xFFFFFFFF);

        if (lightDirty) rebuildLights();
        for (int y = Math.max(0, camY / T); y <= Math.min(WH - 1, (camY + H) / T); y++) {
            for (int x = Math.max(0, camX / T); x <= Math.min(WW - 1, (camX + W) / T); x++) {
                int b = world[y][x], sx = x * T - camX, sy = y * T - camY;
                if (b == AIR || b == TORCH) {
                    if (y > top[x]) rect(g, sx, sy, T, T, lerp(0xFF0C0A12, 0xFF4A3C50, lightAt(x, y)));   // inside a cave: lit by torches
                }
                if (b != AIR) tile(g, b, x, y, sx, sy);
            }
        }
        for (Zombie z : zs) person(g, z.b, pl[0] > z.b[0] ? 1 : -1, true, z.hurt);
        if (grace == 0 || (ticks / 4) % 2 == 0) person(g, pl, face, false, 0);

        int tx = (int) Math.floor((mx + camX) / (double) T), ty = (int) Math.floor((my + camY) / (double) T);   // block under the mouse
        if (Math.hypot((mx + camX) / (double) T - pl[0] - PW / 2, (my + camY) / (double) T - pl[1] - PH / 2) <= REACH) {
            int sx = tx * T - camX, sy = ty * T - camY;
            rect(g, sx, sy, T, 1, 0xCCFFFFFF); rect(g, sx, sy + T - 1, T, 1, 0xCCFFFFFF);
            rect(g, sx, sy, 1, T, 0xCCFFFFFF); rect(g, sx + T - 1, sy, 1, T, 0xCCFFFFFF);
            int b = at(tx, ty);
            if (hit > 0 && tx == hx && ty == hy && HARD[b] < 900 && b != AIR) rect(g, sx + 1, sy + 1, T - 2, T - 2, (Math.min(0xA0, hit * 0xA0 / HARD[b]) << 24));   // cracks
        }
        if (dk > 0) rect(g, 0, 0, W, H, ((int) (dk * 0x70) << 24) | 0x000018);                      // night
        if (grace > 40) rect(g, 0, 0, W, H, 0x30FF0000);
        hud(g);
        if (crafting) renderCraft(g);
    }

    /** A 10x10 picture of an item (blocks use their tile). */
    private void icon(GuiGraphics g, int item, int x, int y) {
        switch (item) {
            case STICK -> { rect(g, x + 4, y, 2, 10, 0xFF8A5A33); rect(g, x + 4, y, 1, 10, 0xFFA87848); }
            case INGOT -> { rect(g, x + 1, y + 3, 8, 4, 0xFFE8E8EE); rect(g, x + 1, y + 3, 8, 1, 0xFFFFFFFF); rect(g, x + 1, y + 6, 8, 1, 0xFFB0B0BA); }
            case APPLE -> { rect(g, x + 2, y + 3, 6, 6, 0xFFE5484D); rect(g, x + 3, y + 9, 4, 1, 0xFFE5484D); rect(g, x + 4, y + 1, 2, 2, 0xFF4FB85A); }
            case PICK1, PICK2, PICK3 -> {
                int c = PICK[item - PICK1 + 1];
                rect(g, x + 4, y + 3, 2, 7, 0xFF6B4A2B);
                rect(g, x + 1, y + 1, 8, 2, c); rect(g, x + 1, y + 2, 2, 2, c); rect(g, x + 7, y + 2, 2, 2, c);
            }
            case SWORD1, SWORD2, SWORD3 -> {
                int c = PICK[item - SWORD1 + 1];
                rect(g, x + 4, y, 2, 7, c); rect(g, x + 2, y + 7, 6, 1, 0xFF6B4A2B); rect(g, x + 4, y + 8, 2, 2, 0xFF6B4A2B);
            }
            default -> tile(g, item, 0, 0, x, y);
        }
    }

    private void renderCraft(GuiGraphics g) {
        rect(g, 10, 4, 200, 132, 0xFF3A2A4A);
        rect(g, 11, 5, 198, 130, 0xFF211A2C);
        text(g, Component.translatable("cutemod.craft.ui.title").getString(), 16, 9, 0xFFFFE9A0);
        boolean xh = in(mx, my, 194, 7, 10, 10);
        rect(g, 194, 7, 10, 10, xh ? 0xFFE5484D : 0xFF4A3A5A);
        text(g, "x", 197, 8, 0xFFFFFFFF);
        // the grid
        for (int i = 0; i < 9; i++) {
            int cx = 16 + (i % 3) * 16, cy = 24 + (i / 3) * 16;
            rect(g, cx, cy, 16, 16, in(mx, my, cx, cy, 16, 16) ? 0xFFB0A0C8 : 0xFF6A5A82);
            rect(g, cx + 1, cy + 1, 14, 14, 0xFF1B1422);
            if (cell[i] != 0) {
                icon(g, cell[i], cx + 3, cy + 3);
                if (cnt[i] > 1) text(g, String.valueOf(cnt[i]), cx + 9, cy + 7, 0xFFFFFFFF);
            }
        }
        // the arrow and the result
        rect(g, 68, 47, 9, 2, 0xFFB0A0C8);
        rect(g, 75, 44, 2, 8, 0xFFB0A0C8);
        rect(g, 77, 45, 2, 6, 0xFFB0A0C8);
        Recipe r = match();
        boolean can = r != null;
        rect(g, 84, 40, 20, 20, can && in(mx, my, 84, 40, 20, 20) ? 0xFFFFFFFF : can ? 0xFF7CFF8A : 0xFF6A5A82);
        rect(g, 85, 41, 18, 18, 0xFF1B1422);
        if (can) {
            icon(g, r.result(), 89, 45);
            if (r.count() > 1) text(g, "x" + r.count(), 88, 62, 0xFFFFFFFF);
        }
        // recipe help
        int ly = 22;
        for (String line : Component.translatable("cutemod.craft.ui.recipes").getString().split("\\n")) {
            for (var seq : font().split(FormattedText.of(line), 92)) {
                if (ly > 72) break;
                g.drawString(font(), seq, 112, ly, 0xFFC8D0E0, false);
                ly += 9;
            }
        }
        // what you carry: click an item to choose it, then click grid cells
        for (int i = 0; i < PALETTE.length; i++) {
            int it = PALETTE[i], px = 16 + (i % 9) * 21, py = 82 + (i / 9) * 20;
            rect(g, px, py, 19, 18, it == held ? 0xFFFFFFFF : 0xFF3A2A4A);
            rect(g, px + 1, py + 1, 17, 16, 0xFF1B1422);
            icon(g, it, px + 3, py + 4);
            if (inv[it] == 0) rect(g, px + 1, py + 1, 17, 16, 0xAA1B1422);
            else text(g, String.valueOf(inv[it]), px + 11, py + 9, 0xFFFFFFFF);
        }
        ctext(g, Component.translatable("cutemod.craft.ui.help").getString(), W / 2, 124, 0xFFB0A0C8);
    }

    private void hud(GuiGraphics g) {
        for (int i = 0; i < 10; i++) heart(g, 4 + i * 6, 4, i < hp ? 0xFFE5484D : 0xFF3A2A3A);
        int[] res = {COAL, IRON, INGOT, DIAMOND};                           // coal / iron ore / iron ingots / diamonds
        int[] col = {0xFF1A1A1E, 0xFFD8A878, 0xFFE8E8EE, 0xFF4AEDD9};
        for (int i = 0; i < 4; i++) {
            int x = W - 96 + i * 24;
            rect(g, x, 3, 6, 6, col[i]);
            text(g, i == 3 ? inv[DIAMOND] + "/" + DIAMONDS : String.valueOf(inv[res[i]]), x + 8, 2, 0xFFFFFFFF);
        }
        if (inv[APPLE] > 0) {                                               // apples: press H to eat
            rect(g, 4, 13, 5, 5, 0xFFE5484D);
            rect(g, 6, 11, 1, 2, 0xFF4FB85A);
            text(g, String.valueOf(inv[APPLE]), 11, 11, 0xFFFFFFFF);
        }
        int hx0 = (W - HOTBAR.length * 22) / 2;
        for (int i = 0; i < HOTBAR.length; i++) {                           // hotbar
            int x = hx0 + i * 22, y = H - 20;
            rect(g, x, y, 21, 19, i == sel ? 0xFFFFFFFF : 0xFF3A2A4A);
            rect(g, x + 1, y + 1, 19, 17, 0xFF1B1422);
            tile(g, HOTBAR[i], 0, 0, x + 3, y + 4);
            text(g, String.valueOf(inv[HOTBAR[i]]), x + 14 - (inv[HOTBAR[i]] > 9 ? 4 : 0), y + 10, 0xFFFFFFFF);
        }
        int bx = W - 44, by = H - 17;                                       // [E] opens the crafting grid, and what you hold
        rect(g, bx, by, 40, 14, 0xAA000000);
        text(g, "[E]", bx + 3, by + 3, 0xFFFFE9A0);
        if (tier > 0) { rect(g, bx + 22, by + 5, 6, 2, PICK[tier]); rect(g, bx + 24, by + 7, 2, 5, 0xFF6B4A2B); }
        if (sword > 0) { rect(g, bx + 32, by + 2, 2, 8, PICK[sword]); rect(g, bx + 30, by + 10, 6, 1, 0xFF6B4A2B); }
        if (msgT > 0) ctext(g, msgRaw ? msg : Component.translatable(msg).getString(), W / 2, 16, msgT < 30 ? 0xFFB0A070 : 0xFFFFE9A0);
        if (!zs.isEmpty() && dark() > 0.6F) ctext(g, Component.translatable("cutemod.craft.night").getString(), W / 2, 26, 0xFFFF8A8A);
    }

    @Override
    public String hintKey() { return "cutemod.hint.craft"; }

    @Override
    public Component status() { return Component.translatable("cutemod.craft.status", inv[DIAMOND], DIAMONDS, score); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() { return Component.translatable(won ? "cutemod.craft.win" : "cutemod.craft.dead"); }
}
