package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * First-person horror with TWO WORLDS on one map. You start in the crimson Otherworld (rusty maze, flesh, a siren, and a
 * faceless warden that hunts you). Press SPACE to cross into the quiet living world (grey-green stone). The two worlds
 * have different walls: a wall in one may be a corridor in the other, so you can cut through the maze by crossing, and
 * you can lose the warden by crossing, but only if the place you stand on is open in the other world too.
 * Find 3 seals (each one lies in a certain world, the other world shows only a faint echo of it), then reach the gate,
 * which is in the living world. The living world is safe but it does not hold you: your grip slips and after about
 * 20 seconds you are pulled back into the Otherworld.
 */
public class Otherworld extends MiniGame {
    private static final int N = 15, SEALS = 3;          // the maze is N x N tiles (walls included)
    private static final int GRIP_MAX = 1200, FLIP_CD = 45; // ticks in the living world before you are pulled back, and the pause between two crossings
    private static final int COLS = 110, CW = W / COLS;  // one ray per 2 px
    private static final double PLANE = 0.75;            // field of view (bigger = wider)

    // tiny sprites: one char = one pixel (see pal())
    private static final String[] SEAL = {      // a ring with a cross: the seal
            "..rrrr..", ".r.pp.r.", "r..pp..r", "rppppppr", "r..pp..r", "r..pp..r", ".r.pp.r.", "..rrrr.."};
    private static final String[] GATE = {      // an iron gate: dark bars, and a glow in the gaps (brighter once it can be opened)
            "bbbbbb", "bgbbgb", "bgbbgb", "bgbbgb", "bbbbbb", "bgbbgb", "bgbbgb", "bgpbgb", "bgbbgb", "bbbbbb", "bgbbgb", "bgbbgb"};
    private static final String[] WARDEN = {
            "...kk...", "..kkkk..", "..kddk..", ".kkddkk.", ".kdrrdk.", "kkddddkk", "kkkkkkkk", "..kddk..",
            ".kkddkk.", "kkddddkk", "k.kddk.k", "k.kddk.k", "k.kkkk.k", "..kddk..", "..k..k..", "..k..k.."};
    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    private final int[][] mapA = new int[N][N], mapB = new int[N][N];   // 1 = wall. A = the living world, B = the Otherworld
    private int[][] map = mapB;                         // the world you are in now
    private int world = 1;                              // 0 = living world, 1 = Otherworld
    private final boolean[][][] seen = new boolean[2][N][N]; // for the little map, one per world
    private final int[] sealWorld = new int[SEALS];     // the world each seal lies in
    private final double[] zbuf = new double[COLS];     // wall distance per column (hides sprites behind walls)
    private final double[] sx = new double[SEALS], sy = new double[SEALS];
    private final boolean[] got = new boolean[SEALS];

    private double px, py, ang, ex, ey, tx, ty, light;
    private int ox, oy;                                 // where the warden last heard you
    private double grip = GRIP_MAX;
    private int seals, ticks, msgT, flipCd, flashT;
    private boolean won, awake;
    private String msg = "";

    @Override
    public void reset() {
        score = 0; over = false; won = false; awake = false; ex = ey = tx = ty = -100; seals = 0; ticks = 0; msgT = 0; light = 1;
        world = 1; map = mapB; grip = GRIP_MAX; flipCd = 0; flashT = 0;
        Arrays.fill(got, false);
        for (boolean[][] w : seen) for (boolean[] r : w) Arrays.fill(r, false);
        build();
        px = 1.5; py = 1.5;
        ox = 1; oy = 1;
        ang = map[1][2] == 0 ? 0 : Math.PI / 2;
        say("cutemod.otherworld.start");
    }

    /** Two different random mazes on the same grid (the tiles in the middle of every cell are open in both). */
    private void build() {
        carve(mapA);
        carve(mapB);
        // the seals lie in the middle of random cells, far from the start: one in the living world, one in the Otherworld, one in either
        sealWorld[0] = 0;
        sealWorld[1] = 1;
        sealWorld[2] = rnd.nextInt(2);
        List<int[]> cells = new ArrayList<>();
        for (int y = 1; y < N - 1; y += 2) for (int x = 1; x < N - 1; x += 2) {
            if (x + y >= 8 && !(x == N - 2 && y == N - 2)) cells.add(new int[]{x, y});
        }
        for (int i = 0; i < SEALS; i++) {
            int[] c = cells.remove(rnd.nextInt(cells.size()));
            sx[i] = c[0] + 0.5;
            sy[i] = c[1] + 0.5;
        }
    }

    /** Carve corridors with a depth-first walk, then knock out a few walls to make loops. */
    private void carve(int[][] m) {
        for (int[] r : m) Arrays.fill(r, 1);
        ArrayDeque<int[]> st = new ArrayDeque<>();
        m[1][1] = 0;
        st.push(new int[]{1, 1});
        while (!st.isEmpty()) {
            int[] c = st.peek();
            List<int[]> opts = new ArrayList<>();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0] * 2, ny = c[1] + d[1] * 2;
                if (nx > 0 && ny > 0 && nx < N - 1 && ny < N - 1 && m[ny][nx] == 1) opts.add(d);
            }
            if (opts.isEmpty()) { st.pop(); continue; }
            int[] d = opts.get(rnd.nextInt(opts.size()));
            m[c[1] + d[1]][c[0] + d[0]] = 0;
            m[c[1] + d[1] * 2][c[0] + d[0] * 2] = 0;
            st.push(new int[]{c[0] + d[0] * 2, c[1] + d[1] * 2});
        }
        for (int i = 0; i < 10; i++) {
            int x = 1 + rnd.nextInt(N - 2), y = 1 + rnd.nextInt(N - 2);
            if ((x + y) % 2 == 1) m[y][x] = 0;
        }
    }

    /** After 10 seconds the warden wakes up, far away from you. */
    private void spawn() {
        List<int[]> far = new ArrayList<>();
        for (int y = 1; y < N - 1; y += 2) for (int x = 1; x < N - 1; x += 2) {
            if (Math.abs(x - (int) px) + Math.abs(y - (int) py) >= 10) far.add(new int[]{x, y});
        }
        int[] m = far.get(rnd.nextInt(far.size()));
        ex = tx = m[0] + 0.5;
        ey = ty = m[1] + 0.5;
        ox = (int) px;
        oy = (int) py;
        awake = true;
        say("cutemod.otherworld.wake");
        pling(0.5F);
    }

    private void say(String key) { msg = key; msgT = 150; }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    @Override
    public boolean key(int keyCode) {
        if (keyCode == KEY_SPACE) { cross(false); return true; }
        return false;
    }

    private static boolean open(int[][] m, double x, double y) {
        int ix = (int) x, iy = (int) y;
        return ix > 0 && iy > 0 && ix < N - 1 && iy < N - 1 && m[iy][ix] == 0;
    }

    /** Cross into the other world. It only works if you have room there (the spot is not inside a wall of that world). */
    private void cross(boolean forced) {
        int[][] other = world == 0 ? mapB : mapA;
        if (!forced) {
            if (flipCd > 0) return;
            double r = 0.25;
            if (!(open(other, px, py) && open(other, px + r, py + r) && open(other, px - r, py + r)
                    && open(other, px + r, py - r) && open(other, px - r, py - r))) {
                say("cutemod.otherworld.blocked");
                flipCd = 20;
                pling(0.6F);
                return;
            }
        } else {                                                   // the Otherworld pulls you back: you land in the middle of the cell
            px = ((int) px | 1) + 0.5;
            py = ((int) py | 1) + 0.5;
        }
        world ^= 1;
        map = world == 0 ? mapA : mapB;
        flipCd = FLIP_CD;
        flashT = 16;
        say(forced ? "cutemod.otherworld.pulled" : world == 0 ? "cutemod.otherworld.world.0" : "cutemod.otherworld.world.1");
        pling(world == 0 ? 1.7F : 0.5F);
        if (world == 1) { ox = (int) px; oy = (int) py; }          // the warden feels you come back
    }

    private void move(double dx, double dy) {
        double r = 0.22;
        if (map[(int) py][(int) (px + dx + Math.signum(dx) * r)] == 0) px += dx;
        if (map[(int) (py + dy + Math.signum(dy) * r)][(int) px] == 0) py += dy;
    }

    /** 0 most of the time; every 40 seconds a siren sounds for 5 seconds and this swells to 1 and back. */
    private double siren() {
        int p = ticks % 2400;
        return p < 2100 ? 0 : Math.sin((p - 2100) / 300.0 * Math.PI);
    }

    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        if (flipCd > 0) flipCd--;
        if (flashT > 0) flashT--;
        double md = Math.hypot(ex - px, ey - py);
        light = world == 1 && ((md < 4 && ticks % 11 < 2) || ticks % 500 > 494) ? 0.4 : 1.0;   // the light of the Otherworld flickers
        if (ticks % 2400 == 2100 && world == 1) pling(0.5F);                       // the siren
        if (world == 0) { grip -= 1; if (grip <= 0) { grip = 0; cross(true); } }   // the living world does not hold you for long
        else if (grip < GRIP_MAX) grip = Math.min(GRIP_MAX, grip + 0.6);

        // walk: W/S or up/down, turn: A/D or left/right
        double turn = (down(68) || down(KEY_RIGHT) ? 1 : 0) - (down(65) || down(KEY_LEFT) ? 1 : 0);
        double walk = (down(87) || down(KEY_UP) ? 1 : 0) - (down(83) || down(KEY_DOWN) ? 1 : 0);
        ang += turn * 0.05;
        move(Math.cos(ang) * walk * 0.05, Math.sin(ang) * walk * 0.05);
        for (int dy = -2; dy <= 2; dy++) for (int dx = -2; dx <= 2; dx++) {   // little map: remember what we saw
            int cx = (int) px + dx, cy = (int) py + dy;
            if (cx >= 0 && cy >= 0 && cx < N && cy < N) seen[world][cy][cx] = true;
        }

        // it hears you every 2 s in the Otherworld (always, when close), but only every 10 s when you hide in the living world
        if (world == 1 ? (ticks % 120 == 0 || md < 3) : ticks % 600 == 0) { ox = (int) px; oy = (int) py; }
        if (ticks == 600) spawn();
        if (awake) chase();
        md = Math.hypot(ex - px, ey - py);
        if (md < 0.55 && world == 1) { over = true; pling(0.5F); beep(); return; }   // the warden cannot touch you in the living world
        if (md < 7 && ticks % (int) (14 + md * 6) == 0) pling(world == 1 ? 0.5F : 0.3F);   // heartbeat, faster when it is close

        for (int i = 0; i < SEALS; i++) {
            if (!got[i] && sealWorld[i] == world && Math.hypot(sx[i] - px, sy[i] - py) < 0.5) {
                got[i] = true;
                seals++;
                score += 100;
                pling(1.8F);
                say("cutemod.otherworld.seal");
            }
        }
        if (Math.hypot(N - 1.5 - px, N - 1.5 - py) < 0.8) {
            if (world == 1) { if (msgT == 0) say("cutemod.otherworld.gate_echo"); }     // the gate only opens in the living world
            else if (seals == SEALS) {
                won = true;
                over = true;
                score += 500 + Math.max(0, 600 - ticks / 30);      // faster = more points
                pling(1.0F); pling(1.5F); pling(2.0F);
            } else if (msgT == 0) say("cutemod.otherworld.locked");
        }
    }

    // ---------- the warden: walks tile to tile along the shortest way to you ----------
    private void chase() {
        double sp = 0.013 + 0.0025 * seals + (world == 1 ? 0.004 * siren() : 0);       // slow (you walk 0.05); a little faster with every seal
        double dx = tx - ex, dy = ty - ey, d = Math.hypot(dx, dy);
        if (d <= sp) { ex = tx; ey = ty; next(); }
        else { ex += dx / d * sp; ey += dy / d * sp; }
    }

    private void next() {
        int cx = (int) ex, cy = (int) ey;
        if (cx == (int) px && cy == (int) py) { tx = px; ty = py; return; }   // right on top of you
        if (cx == ox && cy == oy) { tx = cx + 0.5; ty = cy + 0.5; return; }   // reached the last heard spot: waits there
        int[][] dist = new int[N][N];
        for (int[] r : dist) Arrays.fill(r, -1);
        ArrayDeque<int[]> q = new ArrayDeque<>();
        dist[oy][ox] = 0;
        q.add(new int[]{ox, oy});
        while (!q.isEmpty()) {                                     // distance from every tile to where it heard you
            int[] c = q.poll();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0], ny = c[1] + d[1];
                if (mapB[ny][nx] == 0 && dist[ny][nx] < 0) { dist[ny][nx] = dist[c[1]][c[0]] + 1; q.add(new int[]{nx, ny}); }
            }
        }
        int best = dist[cy][cx];
        tx = cx + 0.5;
        ty = cy + 0.5;
        for (int[] d : DIRS) {
            int nx = cx + d[0], ny = cy + d[1];
            if (mapB[ny][nx] == 0 && dist[ny][nx] >= 0 && dist[ny][nx] < best) { best = dist[ny][nx]; tx = nx + 0.5; ty = ny + 0.5; }
        }
    }

    // ---------- the crimson walls ----------
    private static int shade(int rgb, double b) {
        b = Math.max(0, Math.min(1.5, b));
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * b));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * b));
        int bl = Math.min(255, (int) ((rgb & 255) * b));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int mixc(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static double frac(double x) { return x - Math.floor(x); }

    /**
     * The color of one spot of a wall. u = along the wall (0-1), v = up the wall (0-1), t = seconds, ph = a number
     * that is different for every tile. Everything moves, so the walls never lie still: they shimmer between red and black.
     * Three kinds of wall: living flesh with glowing veins, a rusty grate with a red glow behind it, bloody iron plates.
     */
    private static int wall(int type, double u, double v, double t, double ph) {
        switch (type) {
            case 0 -> {                                              // flesh: slow waves, bright veins
                double n = Math.sin(u * 10 + Math.sin(v * 6 + t * 0.9) * 1.8 + t * 0.6 + ph)
                        + Math.sin(v * 8 - u * 3 - t * 1.2 + ph * 2) + Math.sin(u * 4 + v * 7 + t * 0.45);
                n = (n + 3) / 6;
                int c = mixc(0xFF060103, 0xFF9C1020, n * n * (3 - 2 * n));
                return n > 0.8 ? mixc(c, 0xFFFF4050, (n - 0.8) / 0.2 * 0.85) : c;
            }
            case 1 -> {                                              // grate: rusty bars, the holes glow and fade
                double gu = frac(u * 5 + ph), gv = frac(v * 5);
                if (gu < 0.2 || gv < 0.2) return mixc(0xFF1A0305, 0xFF5A0C10, 0.5 + 0.5 * Math.sin(u * 40 + v * 30));
                double pulse = 0.5 + 0.5 * Math.sin(t * 1.6 + Math.floor(u * 5 + ph) * 0.9 + Math.floor(v * 5) * 1.3);
                return mixc(0xFF050102, 0xFFC81C28, pulse * pulse);
            }
            default -> {                                             // iron plates: seams, rivets, red streaks that creep down
                double pu = frac(u * 2 + ph), pv = frac(v * 3);
                if (pu < .06 || pu > .94 || pv < .06 || pv > .94) return 0xFF1F0406;
                if ((pu < .15 || pu > .85) && (pv < .15 || pv > .85)) return 0xFF7A2024;
                double drip = 0.5 + 0.5 * Math.sin(u * 31 + ph * 5) * Math.sin(v * 3 + 0.5 * Math.sin(u * 17) - t * 0.4);
                double sh = 0.5 + 0.5 * Math.sin(t * 1.3 + u * 8 + v * 5);
                return mixc(0xFF22060A, 0xFFB82424, 0.25 * drip + 0.6 * sh * sh);
            }
        }
    }

    /** The living world: calm grey-green stone. Bricks, moss, and cracked plaster. A slow breath of light, nothing more. */
    private static int wallLiving(int type, double u, double v, double t, double ph) {
        double breath = 0.5 + 0.5 * Math.sin(t * 0.7 + ph);
        switch (type) {
            case 0 -> {                                              // bricks
                int row = (int) Math.floor(v * 4);
                double bu = frac(u * 3 + (row % 2) * 0.5 + ph), bv = frac(v * 4);
                if (bu < 0.07 || bv < 0.1) return 0xFF0A1416;
                double n = 0.5 + 0.5 * Math.sin(Math.floor(u * 3 + (row % 2) * 0.5 + ph) * 3.1 + row * 1.7);
                return mixc(mixc(0xFF16282A, 0xFF4C7872, n), 0xFF6CA39A, 0.12 * breath);
            }
            case 1 -> {                                              // moss
                double n = (Math.sin(u * 7 + ph) + Math.sin(v * 9 + u * 3) + Math.sin(t * 0.4 + u * 5 + v * 2) + 3) / 6;
                return mixc(0xFF08160F, 0xFF3C7A56, n * n * (3 - 2 * n) + 0.08 * breath);
            }
            default -> {                                             // pale plaster with cracks
                if (Math.abs(Math.sin(u * 23 + ph * 3 + Math.sin(v * 9) * 2)) < 0.06) return 0xFF0E1A1E;
                double n = 0.5 + 0.5 * Math.sin(u * 5 + v * 3 + ph);
                return mixc(mixc(0xFF2A3C42, 0xFF688A90, n), 0xFF9CC8C8, 0.1 * breath);
            }
        }
    }

    /** A sprite colour seen from the living world: the same picture in cold teal. */
    private static int teal(int c) {
        int gray = (((c >> 16) & 255) * 3 + ((c >> 8) & 255) * 6 + (c & 255)) / 10;
        return mixc(0xFF04100E, 0xFF7EF0D8, gray / 255.0);
    }

    private static int pal(char c, boolean open) {
        return switch (c) {
            case 'k' -> 0xFF14030A;
            case 'd' -> 0xFF5A0A14;
            case 'r' -> 0xFFFF2A3A;
            case 'p' -> 0xFFFF9AA0;
            case 'b' -> 0xFF3A0810;
            case 'g' -> open ? 0xFFFF6A6A : 0xFF7A1018;
            default -> 0xFF2A0A10;
        };
    }

    @Override
    public void render(GuiGraphics g) {
        if (over && !won) { jumpScare(g); return; }
        boolean living = world == 0;
        double t = ticks / 60.0, sir = living ? 0 : siren();
        if (living) {
            g.fillGradient(0, 0, W, H / 2, 0xFF0A1C22, 0xFF000000);    // ceiling
            g.fillGradient(0, H / 2, W, H, 0xFF000000, 0xFF14303A);    // floor
            int mist = (int) (30 + 14 * Math.sin(t * 0.9));           // a soft mist on the floor
            g.fillGradient(0, H - 34, W, H, 0x0060C0B0, (mist << 24) | 0x60C0B0);
        } else {
            g.fillGradient(0, 0, W, H / 2, 0xFF1C0408, 0xFF000000);    // ceiling
            g.fillGradient(0, H / 2, W, H, 0xFF000000, 0xFF3E060A);    // floor
            int glow = (int) (36 + 26 * Math.sin(t * 2.0) + 70 * sir);  // the floor pulses
            g.fillGradient(0, H - 34, W, H, 0x00700010, (Math.min(140, glow) << 24) | 0x700010);
        }

        double dirX = Math.cos(ang), dirY = Math.sin(ang), plX = -dirY * PLANE, plY = dirX * PLANE;
        for (int c = 0; c < COLS; c++) {                           // walls: one ray per column
            double cam = 2.0 * (c + 0.5) / COLS - 1;
            double rdx = dirX + plX * cam, rdy = dirY + plY * cam;
            int mapX = (int) px, mapY = (int) py;
            double ddx = Math.abs(1 / rdx), ddy = Math.abs(1 / rdy), sdx, sdy;
            int stepX, stepY;
            if (rdx < 0) { stepX = -1; sdx = (px - mapX) * ddx; } else { stepX = 1; sdx = (mapX + 1 - px) * ddx; }
            if (rdy < 0) { stepY = -1; sdy = (py - mapY) * ddy; } else { stepY = 1; sdy = (mapY + 1 - py) * ddy; }
            boolean side = false;
            while (map[mapY][mapX] == 0) {                         // walk the grid until a wall is hit
                if (sdx < sdy) { sdx += ddx; mapX += stepX; side = false; }
                else { sdy += ddy; mapY += stepY; side = true; }
            }
            double dist = Math.max(0.05, side ? sdy - ddy : sdx - ddx);
            zbuf[c] = dist;
            double wallX = (side ? px + dist * rdx : py + dist * rdy);
            wallX -= Math.floor(wallX);
            double fog = Math.pow(Math.max(0, 1 - dist / 6.5), 1.2);
            double b = (0.95 * fog + 0.09) * light * (side ? 0.72 : 1) * (1 + 0.4 * sir * (0.6 + 0.4 * Math.sin(t * 9)));
            int type = Math.floorMod(mapX * 3 + mapY * 7, 3);
            double ph = mapX * 0.37 + mapY * 0.61;
            int lh = (int) (H / dist), top = H / 2 - lh / 2;
            int y0 = Math.max(0, top), y1 = Math.min(H, top + lh);
            int seg = Math.max(2, Math.min(8, (y1 - y0) / 12));
            for (int y = y0; y < y1; y += seg) {                   // the wall is drawn in pieces, each with its own color
                int h = Math.min(seg, y1 - y);
                double v = (y + h * 0.5 - top) / (double) lh;
                rect(g, c * CW, y, CW, h, shade(living ? wallLiving(type, wallX, v, t, ph) : wall(type, wallX, v, t, ph), b));
            }
        }

        List<double[]> things = new ArrayList<>();                 // sprites, far ones first
        for (int i = 0; i < SEALS; i++) if (!got[i]) things.add(new double[]{sq(sx[i] - px) + sq(sy[i] - py), sx[i], sy[i], sealWorld[i] == world ? 0 : 3});
        things.add(new double[]{sq(N - 1.5 - px) + sq(N - 1.5 - py), N - 1.5, N - 1.5, living ? 1 : 4});
        if (awake && !living) things.add(new double[]{sq(ex - px) + sq(ey - py), ex, ey, 2});
        things.sort((a, b) -> Double.compare(b[0], a[0]));
        for (double[] s : things) {
            switch ((int) s[3]) {
                case 0 -> sprite(g, s[1], s[2], SEAL, 0.3, 0.12 + Math.sin(ticks / 12.0) * 0.04, 0.8, 10, living);
                case 1 -> sprite(g, s[1], s[2], GATE, 0.9, 0, 0.5, 10, living);
                case 3 -> sprite(g, s[1], s[2], SEAL, 0.3, 0.12 + Math.sin(ticks / 12.0) * 0.04, 0.0, 5, !living, 0.35);   // an echo from the other world
                case 4 -> sprite(g, s[1], s[2], GATE, 0.9, 0, 0.0, 5, true, 0.3);
                default -> sprite(g, s[1], s[2], WARDEN, 0.9, 0, 0.12, 6, false);
            }
        }

        double md = Math.hypot(ex - px, ey - py);
        if (md < 3 && !living) {                                   // it is close: red edges and static
            rect(g, 0, 0, W, H, ((int) ((3 - md) / 3 * 90) << 24) | 0x900010);
            for (int k = 0; k < 6; k++) rect(g, rnd.nextInt(W), rnd.nextInt(H), 40, 1, 0x40FF6060);
        }
        if (sir > 0) rect(g, 0, 0, W, H, ((int) (sir * 46) << 24) | 0xFF0010);   // the siren washes the screen red
        for (int i = 0; i < 4; i++) {                              // dark vignette (red in the Otherworld, teal in the living world)
            int a = (0x78 - i * 0x1E) << 24;
            int vc = living ? 0x02100E : 0x100004;
            rect(g, i * 6, 0, 6, H, a | vc);
            rect(g, W - 6 - i * 6, 0, 6, H, a | vc);
        }
        if (flashT > 0) rect(g, 0, 0, W, H, ((int) (flashT / 16.0 * 150) << 24) | (living ? 0xC8FFF0 : 0xFF2030));   // crossing flash
        hud(g);
        minimap(g);
        if (msgT > 0) small(g, Component.translatable(msg).getString(), msgT < 30 ? 0xFF8A3A40 : 0xFFFFA0A8);
        if (won) rect(g, 0, 0, W, H, 0x50FF8090);
    }

    private static double sq(double v) { return v * v; }

    /** A message at the bottom in small type (3/4 size); a long one is split into two centred lines that stay inside the screen. */
    private static void small(GuiGraphics g, String s, int argb) {
        final float k = 0.75F;
        int maxW = Math.round((W - 16) / k);
        java.util.List<String> lines = new java.util.ArrayList<>();
        String rest = s;
        while (!rest.isEmpty() && lines.size() < 2) {
            if (font().width(rest) <= maxW || lines.size() == 1) { lines.add(font().plainSubstrByWidth(rest, maxW)); break; }
            String head = font().plainSubstrByWidth(rest, maxW);
            int cut = head.lastIndexOf(' ');
            if (cut > 0) head = head.substring(0, cut);
            lines.add(head);
            rest = rest.substring(head.length()).trim();
        }
        int y = H - 19 - (lines.size() - 1) * 8;
        for (String l : lines) {
            g.pose().pushPose();
            g.pose().translate(W / 2f, y, 0);
            g.pose().scale(k, k, 1F);
            g.drawString(font(), l, -font().width(l) / 2, 0, argb, false);
            g.pose().popPose();
            y += 8;
        }
    }

    /** Top-left: the three seals (a lit ring for every one you hold, the colour of the ring is the world it lies in). Bottom: grip. */
    private void hud(GuiGraphics g) {
        for (int i = 0; i < SEALS; i++) {
            int x = 10 + i * 12;
            disc(g, x, 9, 4, sealWorld[i] == 0 ? 0xFF0E2A28 : 0xFF2A0610);
            disc(g, x, 9, 3, got[i] ? (sealWorld[i] == 0 ? 0xFF40E0C8 : 0xFFFF3040) : 0xFF0A0A0C);
            if (got[i]) rect(g, x - 1, 8, 2, 2, 0xFFE8FFFF);
        }
        String wn = Component.translatable("cutemod.otherworld.world." + world).getString();
        g.pose().pushPose();
        g.pose().translate(10, 17, 0);
        g.pose().scale(0.75F, 0.75F, 1F);
        text(g, wn, 0, 0, world == 0 ? 0xFF7EF0D8 : 0xFFFF6A72);
        g.pose().popPose();
        if (world == 0 || grip < GRIP_MAX) {                       // how long the living world still holds you
            int w = 60, x = 10, y = H - 8;
            rect(g, x - 1, y - 1, w + 2, 5, 0x99000000);
            double f = grip / GRIP_MAX;
            boolean low = f < 0.25 && ticks / 8 % 2 == 0;
            rect(g, x, y, (int) (w * f), 3, low ? 0xFFFFFFFF : 0xFF40E0C8);
        }
        if (flipCd > 0 && flipCd <= FLIP_CD) rect(g, 10, H - 13, flipCd * 60 / FLIP_CD, 1, 0x88FFFFFF);
    }

    /** A billboard: a tiny picture that always faces you. Columns behind walls are skipped. */
    private void sprite(GuiGraphics g, double spx, double spy, String[] bmp, double size, double lift, double minB, double range, boolean teal) {
        sprite(g, spx, spy, bmp, size, lift, minB, range, teal, 1.0);
    }

    /** dim = 1 for a real thing, less for an echo of something that lies in the other world (you see it, but you cannot touch it). */
    private void sprite(GuiGraphics g, double spx, double spy, String[] bmp, double size, double lift, double minB, double range, boolean teal, double dim) {
        double rx = spx - px, ry = spy - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);          // how far in front of us
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);         // how far to the right
        if (f < 0.15) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f), sh = (int) (full * size), sw = sh * bmp[0].length() / bmp.length;
        int left = (int) (W / 2.0 * (1 + cam)) - sw / 2, top = H / 2 + full / 2 - sh - (int) (full * lift);
        double b = (Math.max(minB, 1 - f / range) + (Math.abs(cam) < 0.35 ? 0.25 : 0)) * light * dim;
        if (b <= 0.02) return;
        boolean open = seals == SEALS;
        for (int x = Math.floorDiv(left, CW) * CW; x < left + sw; x += CW) {
            int c = x / CW;
            if (x < 0 || c >= COLS || f >= zbuf[c]) continue;
            int u = Math.max(0, Math.min(bmp[0].length() - 1, (x + CW / 2 - left) * bmp[0].length() / sw));
            for (int row = 0; row < bmp.length; row++) {
                char ch = bmp[row].charAt(u);
                if (ch == '.') continue;
                int y0 = top + row * sh / bmp.length, y1 = Math.max(y0 + 1, top + (row + 1) * sh / bmp.length);
                int base = pal(ch, open);
                rect(g, x, y0, CW, y1 - y0, shade(teal ? teal(base) : base, b));
            }
        }
    }

    /** Top-right: only the places you have already been to. A tile that is open in BOTH worlds is lighter: there you can cross safely. */
    private void minimap(GuiGraphics g) {
        int s = 3, x0 = W - N * s - 6, y0 = 6;
        boolean living = world == 0;
        int[][] other = living ? mapB : mapA;
        rect(g, x0 - 2, y0 - 2, N * s + 4, N * s + 4, 0x99000000);
        for (int y = 0; y < N; y++) for (int x = 0; x < N; x++) {
            if (!seen[world][y][x]) continue;
            int c;
            if (map[y][x] == 1) c = living ? 0xFF2A5A56 : 0xFF7A1C24;
            else if (other[y][x] == 0) c = living ? 0xFF4A8A82 : 0xFF6A2A30;   // open in both
            else c = living ? 0xFF0E2A28 : 0xFF2A0A10;
            rect(g, x0 + x * s, y0 + y * s, s, s, c);
        }
        if (seen[world][N - 2][N - 2]) rect(g, x0 + (N - 2) * s, y0 + (N - 2) * s, s, s, living ? (seals == SEALS ? 0xFFE8FFFF : 0xFF40A090) : 0xFF8A2028);
        rect(g, x0 + (int) (px * s) - 1, y0 + (int) (py * s) - 1, 2, 2, living ? 0xFFE8FFFF : 0xFFFFC0C4);
        rect(g, x0 + (int) ((px + Math.cos(ang) * 1.2) * s), y0 + (int) ((py + Math.sin(ang) * 1.2) * s), 1, 1, living ? 0xFF7EF0D8 : 0xFFFF8A90);
    }

    /** You were caught: the warden's triangle head fills the screen. (The "Game over" box is drawn on top of the middle.) */
    private void jumpScare(GuiGraphics g) {
        boolean flick = (System.currentTimeMillis() / 80) % 2 == 0;
        rect(g, 0, 0, W, H, flick ? 0xFF3A0008 : 0xFF000000);
        rect(g, 24, 84, 172, 56, 0xFF14030A);                      // shoulders
        for (int r = 0; r < 76; r++) {                             // the head: a big triangle
            int ww = 8 + r * 2;
            rect(g, W / 2 - ww / 2, 8 + r, ww, 1, r % 6 < 3 ? 0xFF4A0A14 : 0xFF3A0610);
        }
        rect(g, W / 2 - 34, 58, 68, 7, 0xFFFF2A3A);                // the glowing slit
        rect(g, W / 2 - 34, 61, 68, 1, 0xFFFFC0C4);
        for (int k = 0; k < 9; k++) rect(g, 30 + k * 20, 84, 3, 10 + (k * 7) % 14, 0xFF8A0A16);   // blood
    }

    @Override
    public String hintKey() { return "cutemod.hint.otherworld"; }

    @Override
    public Component status() { return Component.translatable("cutemod.otherworld.status", seals, SEALS); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return Component.translatable(won ? "cutemod.otherworld.win" : "cutemod.ui.gameover");
    }
}
