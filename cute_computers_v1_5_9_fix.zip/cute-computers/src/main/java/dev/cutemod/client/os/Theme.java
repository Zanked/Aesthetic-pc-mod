package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The look of the desktop chrome (menu bar, window title bars, the Dock and a soft overlay on the wallpaper).
 * The classic look is the default. <b>Frutiger Aero</b> (glossy blue glass, bubbles, a bright sky glow) is bought
 * in CuteMarket > Style for {@link #AERO_PRICE} coins and can be switched back to classic at any time.
 * The chosen look is saved on the server under the name "theme" (like the wallpaper).
 */
public final class Theme {
    public static final String AERO_ID = "theme_aero";
    public static final int AERO_PRICE = 120;

    private static boolean aero;
    private static int gen = -1;

    private Theme() {}

    /** True when the Aero look is on (it must be bought first). */
    public static boolean aero() {
        if (gen != Store.gen()) {
            gen = Store.gen();
            String s = Store.read("theme");
            aero = s != null && s.trim().equals("aero");
        }
        return aero && Progress.owned(AERO_ID);
    }

    public static void setAero(boolean on) {
        aero();
        aero = on;
        Store.write("theme", on ? "aero" : "");
    }

    /** Colour of the window title text. */
    public static int titleText() { return aero() ? 0xFF14405E : 0xFF3A2A3A; }

    // ---------- the chrome ----------

    /** Blue glass menu bar: a gradient, a bright top edge and a shine on the upper half. */
    public static void menuBar(GuiGraphics g, int x, int y, int w, int h) {
        g.fillGradient(x, y, x + w, y + h, 0xDD3A9BE8, 0xDD1F6FC4);
        g.fill(x, y + 1, x + w, y + 1 + h / 2, 0x2AFFFFFF);
        g.fill(x, y, x + w, y + 1, 0xAAFFFFFF);
        g.fill(x, y + h - 1, x + w, y + h, 0x99124F8F);
    }

    /** Glossy light-blue window title bar. */
    public static void titleBar(GuiGraphics g, int x, int y, int w, int h) {
        g.fillGradient(x, y, x + w, y + h, 0xFFEAF7FF, 0xFFA5D4F2);
        g.fill(x, y + 1, x + w, y + 1 + h / 2, 0x33FFFFFF);
        g.fill(x, y, x + w, y + 1, 0xFFFFFFFF);
        g.fill(x, y + h - 1, x + w, y + h, 0xFF5FA6D8);
    }

    /** The two layers of the Dock pill in Aero: a pale rim and a glossy blue body with a shine on top. */
    public static void dockPill(GuiGraphics g, int x0, int y0, int x1, int y1) {
        Dock.pill(g, x0 - 1, y0 - 1, x1 + 1, y1 + 1, 0x77FFFFFF);
        Dock.pill(g, x0, y0, x1, y1, 0xAA2F8FD8);
        Dock.pill(g, x0 + 1, y0 + 1, x1 - 1, y0 + Math.max(4, (y1 - y0) / 2), 0x44FFFFFF);
    }

    // ---------- the overlay on the wallpaper ----------

    /** A sky glow and slowly rising soap bubbles over the wallpaper (drawn before the windows). */
    public static void overlay(GuiGraphics g, int x, int y, int w, int h) {
        int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        g.enableScissor(x, y, x + w, y + h);      // the overlay is drawn with the plain screen pose, so the scissor is right here
        g.fillGradient(x, y, x + w, y + h * 45 / 100, 0x55FFFFFF, 0x00FFFFFF);
        for (int i = 0; i < 10; i++) {
            int rad = 3 + (i * 5) % 9;
            int rise = (t * (1 + i % 3) / 3 + i * 47) % (h + rad * 4);
            int cy = y + h + rad * 2 - rise;
            int cx = x + rad + (i * 83 + 20) % Math.max(1, w - rad * 2) + (int) (Math.sin(t * 0.04 + i) * 4);
            bubble(g, cx, cy, rad);
        }
        g.disableScissor();
    }

    private static void bubble(GuiGraphics g, int cx, int cy, int rad) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            int inner = Math.abs(dy) >= rad - 1 ? -1 : (int) Math.floor(Math.sqrt((rad - 1) * (rad - 1) - dy * dy + 0.25));
            if (inner < 0) {
                g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, 0x77FFFFFF);
            } else {
                g.fill(cx - dx, cy + dy, cx - inner, cy + dy + 1, 0x77FFFFFF);       // the rim
                g.fill(cx - inner, cy + dy, cx + inner + 1, cy + dy + 1, 0x1CFFFFFF);  // the thin glass inside
                g.fill(cx + inner + 1, cy + dy, cx + dx + 1, cy + dy + 1, 0x77FFFFFF);
            }
        }
        g.fill(cx - rad / 2, cy - rad / 2, cx - rad / 2 + 2, cy - rad / 2 + 2, 0xCCFFFFFF);   // the highlight
    }

    // ---------- the mouse cursor ----------
    private static final String[] ARROW = {
            "B..........", "BB.........", "BwB........", "BwwB.......", "BwwwB......", "BwwwwB.....",
            "BwwwwwB....", "BwwwwwwB...", "BwwwwwwwB..", "BwwwwwwwwB.", "BwwwwwBBBBB", "BwwBwwB....",
            "BwB.BwwB...", "BB..BwwB...", "B....BwwB..", ".....BwwB..", "......BB..."};

    private static final String[] HEART = {".X.X.", "XXXXX", "XXXXX", ".XXX.", "..X.."};

    /**
     * The classic look's cursor: a soft pink arrow with a plum outline and a white shine, and a tiny heart
     * that bobs next to it. The hot spot is the top-left pixel, like every arrow.
     */
    public static void cursorClassic(GuiGraphics g, int mx, int my) {
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                int argb = c == 'B' ? 0xFF5A2A4A : (col < 3 ? 0xFFFFF3F8 : row < 8 ? 0xFFFFC4DE : 0xFFFF8CBC);
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, argb);
            }
        }
        int bob = (int) Math.round(Math.sin(System.currentTimeMillis() / 220.0));
        for (int row = 0; row < HEART.length; row++) {
            for (int col = 0; col < HEART[row].length(); col++) {
                if (HEART[row].charAt(col) == '.') continue;
                g.fill(mx + 10 + col, my + 1 + bob + row, mx + 11 + col, my + 2 + bob + row, row == 0 && col == 1 ? 0xFFFFB3CE : 0xFFFF6B9A);
            }
        }
        g.pose().popPose();
    }

    /** A glossy blue arrow with a white shine; a spinning ring next to it while the app is busy. */
    public static void cursor(GuiGraphics g, int mx, int my, boolean busy) {
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                int argb = c == 'B' ? 0xFF0E4A86 : (col < 3 ? 0xFFFFFFFF : row < 8 ? 0xFFBFE6FF : 0xFF5DB4F0);
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, argb);
            }
        }
        if (busy) {
            long t = System.currentTimeMillis() / 90L;
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4;
                int px = mx + 15 + (int) Math.round(Math.cos(a) * 4), py = my + 15 + (int) Math.round(Math.sin(a) * 4);
                int k = (int) ((t - i) & 7);
                int al = 0x30 + (7 - k) * 0x1E;
                g.fill(px, py, px + 2, py + 2, (Math.min(255, al) << 24) | 0x2F9BEA);
            }
        }
        g.pose().popPose();
    }
}
