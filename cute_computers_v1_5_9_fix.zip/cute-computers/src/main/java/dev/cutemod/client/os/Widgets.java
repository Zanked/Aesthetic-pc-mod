package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;

/**
 * Desktop widgets. Left column: a music player (while a song plays), the parcels of CuteMarket on their way
 * and a timer. Right column: a calendar and a clock. Right-click the empty desktop to add or remove them
 * (right-click a widget removes it). The choice is saved on the server. In the Frutiger Aero theme they are glass.
 */
public final class Widgets {
    private Widgets() {}

    public static final int PLAYER = 1, ORDERS = 2, TIMER = 4, CALENDAR = 8, CLOCK = 16, ALL = 31;
    public static final int NONE = 0, USED = 1, OPEN_MARKET = 2, REMOVED = 3;
    private static final int X = 8, WW = 120, GAP = 4;
    private static final int CAL_W = 46, CAL_H = 48, CLK_H = 22;

    private static int mask = ALL, gen = -1;
    private static boolean timerRun;
    private static long timerEnd, timerLeft;

    // where each left-column widget is this frame (-1 = not shown)
    private static int yPlayer = -1, yOrders = -1, yTimer = -1, hOrders;

    private static int mask() {
        if (gen != Store.gen()) {
            gen = Store.gen();
            mask = ALL;
            String s = Store.read("widgets");
            if (s != null && !s.isBlank()) {
                try { mask = Integer.parseInt(s.trim()) & ALL; } catch (NumberFormatException ignored) { }
            }
        }
        return mask;
    }

    public static boolean on(int bit) { return (mask() & bit) != 0; }

    public static void toggle(int bit) {
        mask();
        mask ^= bit;
        Store.write("widgets", Integer.toString(mask));
    }

    // ---------- the timer keeps running when the desktop is not in front ----------
    private static long left() { return timerRun ? Math.max(0, timerEnd - System.currentTimeMillis()) : timerLeft; }

    public static void tick() {
        if (timerRun && System.currentTimeMillis() >= timerEnd) {
            timerRun = false;
            timerLeft = 0;
            Progress.toast("cutemod.widget.timer_done");
            Sfx.powerOn();
        }
    }

    private static void addTime(long ms) {
        long l = Math.min(99 * 60_000L, left() + ms);
        if (timerRun) timerEnd = System.currentTimeMillis() + l; else timerLeft = l;
    }

    // ---------- look ----------
    private static void box(GuiGraphics g, int x, int y, int w, int h) {
        if (Theme.aero()) {                                           // glass: see-through blue, bright rim, gloss
            g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0x88FFFFFF);
            g.fillGradient(x, y, x + w, y + h, 0x9A4FB4F0, 0x8A1F6FC4);
            g.fill(x, y, x + w, y + h / 2, 0x26FFFFFF);
        } else {
            g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0x33FFFFFF);
            g.fill(x, y, x + w, y + h, 0xCC1B1422);
        }
    }

    private static int text() { return 0xFFFFFFFF; }

    private static int muted() { return Theme.aero() ? 0xFFD6EEFF : 0xFF9A90B8; }

    private static int accent() { return Theme.aero() ? 0xFFFFFFFF : 0xFFF58FB8; }

    private static int good() { return Theme.aero() ? 0xFFB6FFC8 : 0xFF5BD97A; }

    private static void button(GuiGraphics g, Font f, int x, int y, int w, int h, String s, boolean hov) {
        if (Theme.aero()) {
            g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xAAFFFFFF);
            g.fillGradient(x, y, x + w, y + h, hov ? 0xFF7FD0FF : 0xFF3A9BE8, hov ? 0xFF2F8AD8 : 0xFF1F6FC4);
            g.fill(x, y, x + w, y + h / 2, 0x33FFFFFF);
        } else {
            g.fill(x, y, x + w, y + h, hov ? 0xFFB57BD6 : 0xFF3A2F5A);
        }
        g.drawString(f, s, x + (w - f.width(s)) / 2, y + (h - 8) / 2 + 1, 0xFFFFFFFF, false);
    }

    private static boolean in(int px, int py, int x, int y, int w, int h) { return px >= x && py >= y && px < x + w && py < y + h; }

    // ---------- layout ----------
    private static void layout(MusicApp music) {
        int y = 8;
        yPlayer = yOrders = yTimer = -1;
        if (on(PLAYER) && music != null && music.active()) { yPlayer = y; y += 32 + GAP; }
        int parcels = on(ORDERS) ? Market.active() : 0;
        if (parcels > 0) { yOrders = y; hOrders = 13 + Math.min(3, parcels) * 10; y += hOrders + GAP; }
        if (on(TIMER)) yTimer = y;
    }

    private static int calX() { return App.W - 56; }

    private static int clockY() { return 8 + (on(CALENDAR) ? CAL_H + GAP : 0); }

    // ---------- drawing ----------
    public static void render(GuiGraphics g, MusicApp music, int mx, int my) {
        Font f = Minecraft.getInstance().font;
        layout(music);
        if (yPlayer >= 0) {
            int y = yPlayer;
            box(g, X, y, WW, 32);
            g.fill(X + 5, y + 5, X + 7, y + 10, accent()); g.fill(X + 7, y + 4, X + 9, y + 5, accent()); g.fill(X + 3, y + 8, X + 5, y + 11, accent());
            g.drawString(f, f.plainSubstrByWidth(music.trackName(), WW - 24), X + 13, y + 3, text(), false);
            g.fill(X + 6, y + 14, X + WW - 6, y + 17, 0x66000000);
            g.fill(X + 6, y + 14, X + 6 + Math.round((WW - 12) * music.progress()), y + 17, Theme.aero() ? 0xFFFFFFFF : 0xFFB57BD6);
            button(g, f, X + 8, y + 20, 24, 10, "<<", in(mx, my, X + 8, y + 20, 24, 10));
            button(g, f, X + 48, y + 20, 24, 10, music.isPlaying() ? "||" : ">", in(mx, my, X + 48, y + 20, 24, 10));
            button(g, f, X + 88, y + 20, 24, 10, ">>", in(mx, my, X + 88, y + 20, 24, 10));
        }
        if (yOrders >= 0) {
            int y = yOrders;
            box(g, X, y, WW, hOrders);
            g.drawString(f, Component.translatable("cutemod.widget.orders", Market.active()), X + 5, y + 3, accent(), false);
            List<Market.Order> list = Market.orders();
            for (int i = 0; i < list.size() && i < 3; i++) {
                Market.Order o = list.get(i);
                int ry = y + 13 + i * 10;
                g.drawString(f, f.plainSubstrByWidth(MarketApp.name(o.id), 66), X + 5, ry, text(), false);
                String right;
                int col;
                if (Market.arrived(o)) { right = Component.translatable("cutemod.widget.arrived").getString(); col = good(); }
                else { int s = Market.secondsLeft(o); right = (s / 60) + ":" + String.format("%02d", s % 60); col = muted(); }
                g.drawString(f, right, X + WW - 5 - f.width(right), ry, col, false);
            }
        }
        if (yTimer >= 0) {
            int y = yTimer;
            box(g, X, y, WW, 34);
            long l = left();
            String time = (l / 60000) + ":" + String.format("%02d", (l / 1000) % 60);
            g.pose().pushPose();
            g.pose().translate(X + 6, y + 4, 0);
            g.pose().scale(1.6f, 1.6f, 1f);
            g.drawString(f, time, 0, 0, l == 0 && !timerRun ? muted() : (timerRun ? good() : 0xFFFFE680), false);
            g.pose().popPose();
            Component name = Component.translatable("cutemod.widget.timer");
            g.drawString(f, name, X + WW - 5 - f.width(name), y + 3, muted(), false);
            button(g, f, X + 6, y + 22, 24, 10, "+1", in(mx, my, X + 6, y + 22, 24, 10));
            button(g, f, X + 33, y + 22, 24, 10, "+5", in(mx, my, X + 33, y + 22, 24, 10));
            button(g, f, X + 60, y + 22, 26, 10, timerRun ? "||" : ">", in(mx, my, X + 60, y + 22, 26, 10));
            button(g, f, X + 89, y + 22, 26, 10, "0", in(mx, my, X + 89, y + 22, 26, 10));
        }
        if (on(CALENDAR)) calendar(g, f);
        if (on(CLOCK)) clock(g, f);
    }

    private static void calendar(GuiGraphics g, Font f) {
        LocalDate d = LocalDate.now();
        int x = calX(), y = 8, w = CAL_W, h = CAL_H;
        boolean aero = Theme.aero();
        if (aero) {
            g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0x99FFFFFF);
            g.fillGradient(x, y, x + w, y + h, 0xCCFFFFFF, 0xAAB8E2FA);
            g.fillGradient(x, y, x + w, y + 12, 0xEE4FB4F0, 0xEE1F6FC4);
            g.fill(x, y, x + w, y + 6, 0x33FFFFFF);
        } else {
            g.fill(x + 1, y + 2, x + 1 + w, y + 2 + h, 0x44000000);
            g.fill(x, y, x + w, y + h, 0xEEFFFFFF);
            g.fill(x, y, x + w, y + 12, 0xFFE5484D);
        }
        String month = d.getMonth().getDisplayName(TextStyle.SHORT, Locale.getDefault()).toUpperCase(Locale.ROOT);
        g.drawString(f, month, x + (w - f.width(month)) / 2, y + 2, 0xFFFFFFFF, false);
        String day = Integer.toString(d.getDayOfMonth());
        g.pose().pushPose();
        g.pose().translate(x + w / 2f, y + 20, 0);
        g.pose().scale(2.2f, 2.2f, 1f);
        g.drawString(f, day, -f.width(day) / 2, 0, aero ? 0xFF14405E : 0xFF3A2A3A, false);
        g.pose().popPose();
        String dow = d.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.getDefault());
        g.drawString(f, dow, x + (w - f.width(dow)) / 2, y + h - 10, aero ? 0xFF2F6F9F : 0xFF8A7AA8, false);
    }

    private static void clock(GuiGraphics g, Font f) {
        LocalTime now = LocalTime.now();
        int x = calX(), y = clockY(), w = CAL_W;
        box(g, x, y, w, CLK_H);
        String s = String.format("%02d:%02d", now.getHour(), now.getMinute());
        g.pose().pushPose();
        g.pose().translate(x + (w - f.width(s) * 1.3f) / 2f, y + 3, 0);
        g.pose().scale(1.3f, 1.3f, 1f);
        g.drawString(f, s, 0, 0, text(), false);
        g.pose().popPose();
        g.fill(x + 4, y + CLK_H - 5, x + w - 4, y + CLK_H - 3, 0x55000000);
        g.fill(x + 4, y + CLK_H - 5, x + 4 + (w - 8) * now.getSecond() / 60, y + CLK_H - 3, Theme.aero() ? 0xFFFFFFFF : 0xFFB57BD6);
    }

    /** Is this point on a widget? Returns which one (a bit), 0 if none. */
    private static int hit(MusicApp music, int x, int y) {
        layout(music);
        if (yPlayer >= 0 && in(x, y, X, yPlayer, WW, 32)) return PLAYER;
        if (yOrders >= 0 && in(x, y, X, yOrders, WW, hOrders)) return ORDERS;
        if (yTimer >= 0 && in(x, y, X, yTimer, WW, 34)) return TIMER;
        if (on(CALENDAR) && in(x, y, calX(), 8, CAL_W, CAL_H)) return CALENDAR;
        if (on(CLOCK) && in(x, y, calX(), clockY(), CAL_W, CLK_H)) return CLOCK;
        return 0;
    }

    /** A click on the desktop: NONE if no widget was hit. A right click removes the widget. */
    public static int click(MusicApp music, int x, int y, int button) {
        int h = hit(music, x, y);
        if (h == 0) return NONE;
        if (button == 1) { toggle(h); return REMOVED; }
        switch (h) {
            case PLAYER -> {
                if (in(x, y, X + 8, yPlayer + 20, 24, 10)) music.prevTrack();
                else if (in(x, y, X + 48, yPlayer + 20, 24, 10)) music.toggle();
                else if (in(x, y, X + 88, yPlayer + 20, 24, 10)) music.nextTrack();
            }
            case ORDERS -> { return OPEN_MARKET; }
            case TIMER -> {
                if (in(x, y, X + 6, yTimer + 22, 24, 10)) addTime(60_000L);
                else if (in(x, y, X + 33, yTimer + 22, 24, 10)) addTime(300_000L);
                else if (in(x, y, X + 60, yTimer + 22, 26, 10)) {
                    if (timerRun) { timerLeft = left(); timerRun = false; }
                    else if (timerLeft > 0) { timerEnd = System.currentTimeMillis() + timerLeft; timerRun = true; }
                } else if (in(x, y, X + 89, yTimer + 22, 26, 10)) { timerRun = false; timerLeft = 0; }
            }
            default -> { }
        }
        return USED;
    }

    // ---------- the "add widgets" menu (right click on the empty desktop) ----------
    private static final int[] MENU_BITS = {PLAYER, ORDERS, TIMER, CALENDAR, CLOCK};
    private static final String[] MENU_KEYS = {"cutemod.widget.player", "cutemod.widget.orders_name", "cutemod.widget.timer", "cutemod.widget.calendar", "cutemod.widget.clock"};
    private static final int MW = 100, MROW = 12, MHEAD = 12;

    public static int menuH() { return MHEAD + MENU_BITS.length * MROW + 2; }

    public static int menuW() { return MW; }

    public static void renderMenu(GuiGraphics g, int mx, int my, int px, int py) {
        Font f = Minecraft.getInstance().font;
        boolean aero = Theme.aero();
        g.fill(px - 1, py - 1, px + MW + 1, py + menuH() + 1, aero ? 0xAAFFFFFF : 0x55FFFFFF);
        if (aero) g.fillGradient(px, py, px + MW, py + menuH(), 0xEE4FB4F0, 0xEE1F6FC4);
        else g.fill(px, py, px + MW, py + menuH(), 0xF21B1422);
        g.drawString(f, Component.translatable("cutemod.widget.menu"), px + 4, py + 2, muted(), false);
        for (int i = 0; i < MENU_BITS.length; i++) {
            int y = py + MHEAD + i * MROW;
            boolean hov = in(mx, my, px, y, MW, MROW);
            if (hov) g.fill(px, y, px + MW, y + MROW, aero ? 0x66FFFFFF : 0xFFB57BD6);
            boolean on = on(MENU_BITS[i]);
            g.fill(px + 4, y + 2, px + 12, y + 10, on ? good() : 0x66000000);
            g.drawString(f, Component.translatable(MENU_KEYS[i]), px + 16, y + 2, text(), false);
        }
    }

    /** A click inside the menu toggles the row under it; any click closes the menu. */
    public static void clickMenu(int x, int y, int px, int py) {
        for (int i = 0; i < MENU_BITS.length; i++) {
            if (in(x, y, px, py + MHEAD + i * MROW, MW, MROW)) { toggle(MENU_BITS[i]); return; }
        }
    }
}
