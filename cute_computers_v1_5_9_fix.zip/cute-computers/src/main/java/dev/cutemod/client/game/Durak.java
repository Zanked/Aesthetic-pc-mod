package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Durak (the Russian card game), you against the computer. 36 cards (6..A), 6 cards each, the bottom card
 * decides the trump suit. The attacker plays a card, the defender beats it with a higher card of the same suit
 * or with a trump, or takes all cards. After a successful defence the roles swap. Whoever is left with cards
 * when the deck is gone is the fool (durak).
 */
public class Durak extends MiniGame {
    private static final String[] RANKS = {"6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    // 0 spade, 1 heart, 2 diamond, 3 club
    private static final String[][] SUITS = {
            {"..#..", ".###.", "#####", "#####", "..#.."},
            {".#.#.", "#####", "#####", ".###.", "..#.."},
            {"..#..", ".###.", "#####", ".###.", "..#.."},
            {"..#..", ".###.", "#.#.#", "..#..", ".###."}};

    private static final int CW = 22, CH = 30, HAND_Y = 106, TBL_X = 36, TBL_Y = 30, SLOT = 30;
    private static final int BTN_X = 164, BTN_Y = 88, BTN_W = 52, BTN_H = 14;
    private static final int ST_PL_ATK = 0, ST_AI_DEF = 1, ST_AI_ATK = 2, ST_PL_DEF = 3, ST_ROUND_END = 4, ST_END = 5;

    private final List<Integer> deck = new ArrayList<>();
    private final List<Integer> pl = new ArrayList<>();
    private final List<Integer> ai = new ArrayList<>();
    private final int[] atk = new int[6];
    private final int[] def = new int[6];
    private int n, limit, trumpCard, trump, state, wait, attacker, target;
    private boolean took, win, draw;
    private String msg = "";

    // ---------- card helpers ----------
    private static int suit(int c) { return c / 9; }
    private static int rank(int c) { return c % 9; }
    private boolean isTrump(int c) { return suit(c) == trump; }
    private int value(int c) { return rank(c) + (isTrump(c) ? 20 : 0); }
    private int sortKey(int c) { return (isTrump(c) ? 1000 : 0) + suit(c) * 20 + rank(c); }

    private boolean canBeat(int d, int a) {
        if (suit(d) == suit(a)) return rank(d) > rank(a);
        return suit(d) == trump;
    }

    private static String m(String key) { return Component.translatable(key).getString(); }

    private void sortHand() { pl.sort((a, b) -> sortKey(a) - sortKey(b)); }

    // ---------- game flow ----------
    @Override
    public void reset() {
        score = 0; over = false; win = false; draw = false;
        deck.clear(); pl.clear(); ai.clear();
        for (int i = 0; i < 36; i++) deck.add(i);
        for (int i = deck.size() - 1; i > 0; i--) {
            int j = rnd.nextInt(i + 1);
            int tmp = deck.get(i); deck.set(i, deck.get(j)); deck.set(j, tmp);
        }
        trumpCard = deck.get(0);
        trump = suit(trumpCard);
        draw(pl);
        draw(ai);
        int pLow = lowestTrump(pl), aLow = lowestTrump(ai);
        attacker = (aLow >= 0 && (pLow < 0 || aLow < pLow)) ? 1 : 0;
        sortHand();
        startRound();
    }

    private int lowestTrump(List<Integer> hand) {
        int best = -1;
        for (int c : hand) if (isTrump(c) && (best < 0 || rank(c) < best)) best = rank(c);
        return best;
    }

    private void draw(List<Integer> hand) {
        while (hand.size() < 6 && !deck.isEmpty()) hand.add(deck.remove(deck.size() - 1));
    }

    private void startRound() {
        n = 0; took = false; target = -1;
        Arrays.fill(atk, -1);
        Arrays.fill(def, -1);
        List<Integer> defender = attacker == 0 ? ai : pl;
        limit = Math.min(6, defender.size());
        if (attacker == 0) {
            state = ST_PL_ATK;
            msg = m("cutemod.durak.attack");
        } else {
            state = ST_AI_ATK;
            wait = 50;
            msg = m("cutemod.durak.thinking");
        }
    }

    private int undefended() {
        for (int i = 0; i < n; i++) if (def[i] < 0) return i;
        return -1;
    }

    private boolean rankOnTable(int r) {
        for (int i = 0; i < n; i++) {
            if (rank(atk[i]) == r) return true;
            if (def[i] >= 0 && rank(def[i]) == r) return true;
        }
        return false;
    }

    private boolean legalAttack(int c) {
        return state == ST_PL_ATK && n < limit && (n == 0 || rankOnTable(rank(c)));
    }

    private int defendTarget() {
        return (target >= 0 && target < n && def[target] < 0) ? target : undefended();
    }

    private boolean legalDefend(int c) {
        if (state != ST_PL_DEF) return false;
        int t = defendTarget();
        return t >= 0 && canBeat(c, atk[t]);
    }

    private void roundDone() {
        state = ST_ROUND_END;
        wait = 35;
        took = false;
        msg = m("cutemod.durak.beaten");
    }

    private void finishRound() {
        int old = attacker;
        n = 0;
        draw(old == 0 ? pl : ai);
        draw(old == 0 ? ai : pl);
        if (!took) attacker = 1 - old;
        sortHand();
        if (deck.isEmpty() && (pl.isEmpty() || ai.isEmpty())) {
            over = true;
            state = ST_END;
            if (pl.isEmpty() && ai.isEmpty()) { draw = true; score = 40; }
            else if (pl.isEmpty()) { win = true; score = 100; }
            else score = 5;
            pling(win ? 1.6F : 0.7F);
            return;
        }
        startRound();
    }

    // ---------- input ----------
    private int handStep() {
        return pl.size() <= 1 ? 24 : Math.min(24, (W - 8 - CW) / (pl.size() - 1));
    }

    private int handX(int i) { return 4 + i * handStep(); }

    private int hoverIdx() {
        for (int i = pl.size() - 1; i >= 0; i--) if (in(mx, my, handX(i), HAND_Y - 6, CW, CH + 6)) return i;
        return -1;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return true;
        if (in(x, y, BTN_X, BTN_Y, BTN_W, BTN_H)) {
            if (state == ST_PL_ATK && n > 0 && undefended() < 0) {
                roundDone();
            } else if (state == ST_PL_DEF && undefended() >= 0) {
                for (int i = 0; i < n; i++) {
                    pl.add(atk[i]);
                    if (def[i] >= 0) pl.add(def[i]);
                }
                n = 0;
                took = true;
                sortHand();
                state = ST_ROUND_END;
                wait = 30;
                msg = m("cutemod.durak.took_you");
                beep();
            }
            return true;
        }
        if (state == ST_PL_DEF) {
            for (int i = 0; i < n; i++) {
                if (def[i] < 0 && in(x, y, TBL_X + i * SLOT, TBL_Y, CW, CH)) { target = i; beep(); return true; }
            }
        }
        for (int i = pl.size() - 1; i >= 0; i--) {
            if (in(x, y, handX(i), HAND_Y - 6, CW, CH + 6)) { play(i); return true; }
        }
        return true;
    }

    private void play(int i) {
        int c = pl.get(i);
        if (state == ST_PL_ATK && legalAttack(c)) {
            pl.remove(i);
            atk[n] = c; def[n] = -1; n++;
            state = ST_AI_DEF;
            wait = 45;
            msg = m("cutemod.durak.thinking");
            pling(1.2F);
        } else if (state == ST_PL_DEF && legalDefend(c)) {
            int t = defendTarget();
            pl.remove(i);
            def[t] = c;
            target = -1;
            pling(1.0F);
            if (undefended() < 0) {
                state = ST_AI_ATK;
                wait = 45;
                msg = m("cutemod.durak.thinking");
            }
        } else {
            beep();
        }
    }

    // ---------- the computer player ----------
    private int aiDefend(int a) {
        int best = -1, bv = 999;
        for (int i = 0; i < ai.size(); i++) {
            int d = ai.get(i);
            if (canBeat(d, a) && value(d) < bv) { bv = value(d); best = i; }
        }
        if (best >= 0 && isTrump(ai.get(best)) && !isTrump(a) && rank(a) <= 2 && deck.size() > 8) return -1;
        return best;
    }

    @Override
    public void tick() {
        if (over) return;
        if (state == ST_PL_ATK) {
            if (n > 0 && undefended() < 0 && (pl.isEmpty() || ai.isEmpty() || n >= limit)) roundDone();
            return;
        }
        if (state != ST_AI_DEF && state != ST_AI_ATK && state != ST_ROUND_END) return;
        if (--wait > 0) return;
        switch (state) {
            case ST_AI_DEF -> {
                int u = undefended();
                if (u < 0) { state = ST_PL_ATK; msg = m("cutemod.durak.add"); return; }
                int pick = aiDefend(atk[u]);
                if (pick >= 0) {
                    def[u] = ai.remove(pick);
                    beep();
                    if (undefended() >= 0) { wait = 30; return; }
                    state = ST_PL_ATK;
                    msg = m("cutemod.durak.add");
                } else {
                    for (int i = 0; i < n; i++) {
                        ai.add(atk[i]);
                        if (def[i] >= 0) ai.add(def[i]);
                    }
                    n = 0;
                    took = true;
                    state = ST_ROUND_END;
                    wait = 40;
                    msg = m("cutemod.durak.took_ai");
                }
            }
            case ST_AI_ATK -> {
                int pick = -1, best = 999;
                for (int i = 0; i < ai.size(); i++) {
                    int c = ai.get(i);
                    boolean ok = n == 0 || (n < limit && rankOnTable(rank(c)) && (!isTrump(c) || deck.isEmpty()));
                    if (ok && value(c) < best) { best = value(c); pick = i; }
                }
                if (pick < 0) { roundDone(); return; }
                int c = ai.remove(pick);
                atk[n] = c; def[n] = -1; n++;
                target = -1;
                state = ST_PL_DEF;
                msg = m("cutemod.durak.defend");
                pling(1.2F);
            }
            case ST_ROUND_END -> finishRound();
            default -> { }
        }
    }

    // ---------- drawing ----------
    private static void suitIcon(GuiGraphics g, int s, int x, int y, int scale, int argb) {
        for (int row = 0; row < 5; row++) {
            for (int col = 0; col < 5; col++) {
                if (SUITS[s][row].charAt(col) == '#') rect(g, x + col * scale, y + row * scale, scale, scale, argb);
            }
        }
    }

    private static int suitColor(int s) { return (s == 1 || s == 2) ? 0xFFD83A4A : 0xFF2A2A3A; }

    private void card(GuiGraphics g, int c, int x, int y) {
        rect(g, x, y, CW, CH, 0xFF3A3A4A);
        rect(g, x + 1, y + 1, CW - 2, CH - 2, 0xFFFAF6EC);
        int col = suitColor(suit(c));
        text(g, RANKS[rank(c)], x + 3, y + 3, col);
        suitIcon(g, suit(c), x + 3, y + 14, 2, col);
        if (isTrump(c)) rect(g, x + 1, y + CH - 3, CW - 2, 2, 0xFFE0B040);
    }

    private static void back(GuiGraphics g, int x, int y, int w, int h) {
        rect(g, x, y, w, h, 0xFF3A3A4A);
        rect(g, x + 1, y + 1, w - 2, h - 2, 0xFFB57BD6);
        rect(g, x + 3, y + 3, w - 6, h - 6, 0xFFE9C9F5);
        rect(g, x + 4, y + 4, w - 8, h - 8, 0xFFB57BD6);
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF2E7D4F, 0xFF1F5C3A);

        // the computer's hand (backs)
        int an = ai.size();
        int astep = an <= 1 ? 12 : Math.min(12, (W - 70) / an);
        int ax = (W - (astep * Math.max(0, an - 1) + 14)) / 2;
        for (int i = 0; i < an; i++) back(g, ax + i * astep, 2, 14, 18);
        text(g, Integer.toString(an), 4, 7, 0xFFE9FFE9);

        // deck and trump
        if (!deck.isEmpty()) {
            back(g, 6, 22, CW, CH);
            ctext(g, Integer.toString(deck.size()), 6 + CW / 2, 54, 0xFFE9FFE9);
            card(g, trumpCard, 6, 66);
        } else {
            rect(g, 6, 66, CW, CH, 0x44000000);
            suitIcon(g, trump, 6 + 6, 66 + 10, 2, suit(trumpCard) == 1 || suit(trumpCard) == 2 ? 0xFFFF8A9A : 0xFFE9FFE9);
        }

        // the table
        for (int i = 0; i < n; i++) {
            int x = TBL_X + i * SLOT;
            card(g, atk[i], x, TBL_Y);
            if (def[i] >= 0) card(g, def[i], x + 5, TBL_Y + 6);
            else if (state == ST_PL_DEF && i == target) rect(g, x - 1, TBL_Y - 3, CW + 2, 2, 0xFFFFD866);
        }
        ctext(g, msg, TBL_X + (W - TBL_X) / 2, 74, 0xFFFFF6C8);

        // the button
        String label = null;
        if (state == ST_PL_ATK && n > 0 && undefended() < 0) label = m("cutemod.durak.done");
        else if (state == ST_PL_DEF && undefended() >= 0) label = m("cutemod.durak.take");
        if (label != null) {
            boolean hov = in(mx, my, BTN_X, BTN_Y, BTN_W, BTN_H);
            rect(g, BTN_X, BTN_Y, BTN_W, BTN_H, hov ? 0xFFFFE08A : 0xFFFFD866);
            ctext(g, label, BTN_X + BTN_W / 2, BTN_Y + 3, 0xFF3A2A10);
        }

        // your hand
        int hv = hoverIdx();
        for (int i = 0; i < pl.size(); i++) {
            int c = pl.get(i);
            int lift = i == hv ? 6 : ((state == ST_PL_ATK && legalAttack(c)) || (state == ST_PL_DEF && legalDefend(c)) ? 3 : 0);
            card(g, c, handX(i), HAND_Y - lift);
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.durak.status", deck.size(), ai.size()); }

    @Override
    public String hintKey() { return "cutemod.hint.durak"; }

    @Override
    public boolean isWin() { return win; }

    @Override
    public Component endTitle() {
        return Component.translatable(win ? "cutemod.durak.win" : draw ? "cutemod.durak.draw" : "cutemod.durak.lose");
    }
}
