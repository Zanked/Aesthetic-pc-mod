package dev.cutemod.net;

import dev.cutemod.data.NetData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** The server side of CuteNet: leaderboards, "who is at a computer right now" and the "new first place" message. */
public final class NetServer {
    private NetServer() {}

    private record Presence(String name, int app, String game, long seen) {}

    private static final long ALIVE_MS = 20_000L;
    private static final int MAX_SCORE = 10_000_000;
    private static final Map<UUID, Presence> online = new HashMap<>();
    private static final Map<UUID, Long> lastScore = new HashMap<>();
    private static final Map<UUID, Long> lastRequest = new HashMap<>();

    public static boolean validGame(String s) {
        if (s == null || s.length() < 1 || s.length() > 16) return false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!(c >= 'a' && c <= 'z') && !(c >= '0' && c <= '9') && c != '_') return false;
        }
        return true;
    }

    public static void score(ServerPlayer sp, String game, int score) {
        MinecraftServer server = sp.getServer();
        if (server == null || !validGame(game) || score <= 0 || score > MAX_SCORE) return;
        long now = System.currentTimeMillis();
        Long last = lastScore.get(sp.getUUID());
        if (last != null && now - last < 1500) return;                 // a score every 1.5 s at most
        lastScore.put(sp.getUUID(), now);
        NetData data = NetData.get(server);
        UUID before = data.leader(game);
        String name = sp.getGameProfile().getName();
        if (!data.submit(game, sp.getUUID(), name, score)) return;
        if (before != null && !before.equals(sp.getUUID()) && sp.getUUID().equals(data.leader(game))) {
            server.getPlayerList().broadcastSystemMessage(
                    Component.translatable("cutemod.net.new_leader", name, Component.translatable("cutemod.game." + game), score), false);
        }
    }

    public static void ping(ServerPlayer sp, boolean open, int app, String game) {
        if (!open) { online.remove(sp.getUUID()); return; }
        String g = validGame(game) ? game : "";
        online.put(sp.getUUID(), new Presence(sp.getGameProfile().getName(), Math.max(-1, Math.min(16, app)), g, System.currentTimeMillis()));
    }

    public static void leave(UUID id) {
        online.remove(id);
        lastScore.remove(id);
        lastRequest.remove(id);
    }

    public static void request(ServerPlayer sp, String game) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        long now = System.currentTimeMillis();
        Long last = lastRequest.get(sp.getUUID());
        if (last != null && now - last < 700) return;
        lastRequest.put(sp.getUUID(), now);
        for (Iterator<Presence> it = online.values().iterator(); it.hasNext(); ) if (now - it.next().seen() > ALIVE_MS) it.remove();
        List<NetSyncPayload.Online> people = new ArrayList<>();
        for (Presence p : online.values()) {
            people.add(new NetSyncPayload.Online(p.name(), p.app(), p.game()));
            if (people.size() >= 40) break;
        }
        String g = validGame(game) ? game : "";
        List<NetData.Row> top = new ArrayList<>();
        int rank = 0, mine = 0;
        if (!g.isEmpty()) {
            NetData data = NetData.get(server);
            top = data.top(g, 10);
            rank = data.rank(g, sp.getUUID());
            mine = data.best(g, sp.getUUID());
        }
        PacketDistributor.sendToPlayer(sp, new NetSyncPayload(g, top, rank, mine, people));
    }
}
