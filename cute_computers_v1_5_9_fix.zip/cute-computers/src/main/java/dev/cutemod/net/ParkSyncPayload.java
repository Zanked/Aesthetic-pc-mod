package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: the other pets in the Pet Park and what just happened to you.
 * event: 0 nothing, 1 you played with {@code with} (plays = how many times so far, prize = coins), 2 the park is full.
 */
public record ParkSyncPayload(int event, String with, int plays, int prize, List<Pet> pets) implements CustomPacketPayload {
    /** A pet in the park. plays = how many times it played with YOU. */
    public record Pet(String owner, String name, String color, PetLook look, boolean sick, int x, int y, int emote, boolean playing, int plays) {}

    public static final Type<ParkSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "park_sync"));

    private static final StreamCodec<ByteBuf, Pet> PET = StreamCodec.of((buf, p) -> {
        ByteBufCodecs.stringUtf8(40).encode(buf, p.owner());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.name());
        ByteBufCodecs.stringUtf8(16).encode(buf, p.color());
        PetLook.CODEC.encode(buf, p.look());
        ByteBufCodecs.BOOL.encode(buf, p.sick());
        ByteBufCodecs.VAR_INT.encode(buf, p.x());
        ByteBufCodecs.VAR_INT.encode(buf, p.y());
        ByteBufCodecs.VAR_INT.encode(buf, p.emote());
        ByteBufCodecs.BOOL.encode(buf, p.playing());
        ByteBufCodecs.VAR_INT.encode(buf, p.plays());
    }, buf -> new Pet(
            ByteBufCodecs.stringUtf8(40).decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.stringUtf8(16).decode(buf),
            PetLook.CODEC.decode(buf),
            ByteBufCodecs.BOOL.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.BOOL.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf)));

    public static final StreamCodec<RegistryFriendlyByteBuf, ParkSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ParkSyncPayload::event,
            ByteBufCodecs.stringUtf8(32), ParkSyncPayload::with,
            ByteBufCodecs.VAR_INT, ParkSyncPayload::plays,
            ByteBufCodecs.VAR_INT, ParkSyncPayload::prize,
            PET.apply(ByteBufCodecs.list(16)), ParkSyncPayload::pets,
            ParkSyncPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ParkSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onParkSync(p));
    }
}
