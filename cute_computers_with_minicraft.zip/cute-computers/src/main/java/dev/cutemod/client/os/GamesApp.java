package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

/** The "Games" folder: every game, playable on any computer. */
public class GamesApp extends App {
    /** One tile. color == null means a game without a computer of its own. */
    private record Entry(String id, ComputerColor color, int rgb) {}

    private static final List<Entry> ENTRIES = new ArrayList<>();

    static {
        for (ComputerColor c : ComputerColor.values()) ENTRIES.add(new Entry(c.id, c, c.bodyColor));
        ENTRIES.add(new Entry("breakout", null, 0xC98B5A));
        ENTRIES.add(new Entry("cubes", null, 0xB57BD6));
        ENTRIES.add(new Entry("pong", null, 0x7ED957));
        ENTRIES.add(new Entry("bees", null, 0xF5C518));
        ENTRIES.add(new Entry("horror", null, 0x8B1A2B));
        ENTRIES.add(new Entry("maze", null, 0x5A2A6A));
        ENTRIES.add(new Entry("craft", null, 0x5BBF4A));
    }

    private static final int COLS = 5, ROWS = 3, TW = 56, TH = 52, GAP = 4;
    private static final int X0 = (W - (COLS * TW + (COLS - 1) * GAP)) / 2;
    private static final int Y0 = (H - (ROWS * TH + (ROWS - 1) * GAP)) / 2;

    @Override
    public Component title() { return Component.translatable("cutemod.os.games"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.games"); }

    private static int tx(int i) { return X0 + (i % COLS) * (TW + GAP); }

    private static int ty(int i) { return Y0 + (i / COLS) * (TH + GAP); }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        int body = shell.color().bodyColor;
        g.fillGradient(0, 0, W, H, mix(body, 0xFFFFFF, 0.65f), mix(body, 0xFFFFFF, 0.3f));
        for (int i = 0; i < ENTRIES.size(); i++) {
            Entry e = ENTRIES.get(i);
            int x = tx(i), y = ty(i);
            boolean hover = in(mx, my, x, y, TW, TH);
            boolean own = e.color() == shell.color();
            rect(g, x - 1, y - 1, TW + 2, TH + 2, own ? 0xFFFFD866 : 0xFF3A2A4A);
            rect(g, x, y, TW, TH, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
            disc(g, x + TW / 2, y + 8, 5, 0xFF000000 | e.rgb());
            disc(g, x + TW / 2, y + 8, 2, mix(e.rgb(), 0xFFFFFF, 0.5f));
            List<FormattedCharSequence> lines =
                    font().split(FormattedText.of(t("cutemod.game." + e.id())), TW - 4);
            for (int l = 0; l < lines.size() && l < 4; l++) {
                FormattedCharSequence s = lines.get(l);
                g.drawString(font(), s, x + (TW - font().width(s)) / 2, y + 16 + l * 9, 0xFF3A2A3A, false);
            }
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < ENTRIES.size(); i++) {
            if (in(x, y, tx(i), ty(i), TW, TH)) {
                Entry e = ENTRIES.get(i);
                shell.open(e.color() != null ? new GameApp(e.color()) : GameApp.extra(e.id()));
                return true;
            }
        }
        return false;
    }
}
