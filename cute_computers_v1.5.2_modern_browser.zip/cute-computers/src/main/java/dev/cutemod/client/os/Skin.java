package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.time.LocalTime;

/**
 * Light and dark mode of the whole desktop. Light is how the apps were drawn from the start.
 * Dark does not need a second set of colours: every app draws through {@link #fill}, {@link #grad}, {@link #str},
 * {@link #rect} and {@link #disc}, which turn a light colour into a deep one (and a dark text into a light one) while
 * the hue stays. Colours that are already dark, the white of text on buttons and the pixel art (pets, wallpapers,
 * places) are left alone, because the art is drawn with plain GuiGraphics calls.
 * The choice is saved on the server under the name "skin": "" = light, "dark", or "auto" (dark from 20:00 to 07:00).
 */
public final class Skin {
    public static final int LIGHT = 0, DARK = 1, AUTO = 2;
    private static final String[] NAMES = {"", "dark", "auto"};

    private static int mode;
    private static int gen = -1;

    private Skin() {}

    public static int mode() {
        if (gen != Store.gen()) {
            gen = Store.gen();
            String s = Store.read("skin");
            s = s == null ? "" : s.trim();
            mode = s.equals("dark") ? DARK : s.equals("auto") ? AUTO : LIGHT;
        }
        return mode;
    }

    public static void setMode(int m) {
        mode();
        mode = Math.floorMod(m, 3);
        Store.write("skin", NAMES[mode]);
    }

    private static boolean appsKeepColours;

    /** While an app draws the inside of its window the colours are left alone: the apps stay as they were drawn,
     *  only the shell (desktop, menu bar, window frames, dock) goes dark. ComputerScreen switches this around app.render. */
    public static void appsKeepColours(boolean on) { appsKeepColours = on; }

    /** True when the dark colours are in use right now. */
    public static boolean dark() {
        int m = mode();
        if (m == DARK) return true;
        if (m == AUTO) {
            int h = LocalTime.now().getHour();
            return h >= 20 || h < 7;
        }
        return false;
    }

    // ---------- the colour maps (cached: an app can draw thousands of rectangles a frame) ----------

    private static final int N = 2048;
    private static final int[] fk = new int[N], fv = new int[N], tk = new int[N], tv = new int[N];
    private static boolean[] fok = new boolean[N], tok = new boolean[N];

    /** A surface or a shape: light colours become deep, vivid colours get darker, dark colours stay. */
    public static int surface(int c) {
        if (appsKeepColours || !dark()) return c;
        int i = (c ^ (c >>> 11)) & (N - 1);
        if (fok[i] && fk[i] == c) return fv[i];
        int r = convert(c, false);
        fk[i] = c; fv[i] = r; fok[i] = true;
        return r;
    }

    /** A text colour: dark text becomes light, white stays white. */
    public static int ink(int c) {
        if (appsKeepColours || !dark()) return c;
        int i = (c ^ (c >>> 11)) & (N - 1);
        if (tok[i] && tk[i] == c) return tv[i];
        int r = convert(c, true);
        tk[i] = c; tv[i] = r; tok[i] = true;
        return r;
    }

    private static int convert(int c, boolean text) {
        int a = c >>> 24;
        if (a == 0) return c;
        float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float l = (max + min) / 2f, ch = max - min;
        float nl;
        if (text) {
            if (l >= 0.8f) return c;
            nl = Math.max(l, l < 0.3f ? 0.92f - 0.5f * l : 0.77f + (l - 0.3f) * 0.26f);
        } else {
            if (a < 0xD0 && l > 0.88f && ch < 0.12f) return c;          // a see-through white shine stays a shine
            float inv = l <= 0.30f ? l : 0.30f - (l - 0.30f) * 0.257f;      // surfaces: light -> deep
            float vivid = l * 0.62f;                                       // accents: only a bit darker
            float w = Math.max(0f, Math.min(1f, (ch - 0.12f) / 0.18f));
            nl = (1 - w) * inv + w * Math.min(l, vivid);
            if (l <= 0.30f) return c;
        }
        float h;
        if (ch < 0.0001f) h = 0;
        else if (max == r) h = ((g - b) / ch) % 6f;
        else if (max == g) h = (b - r) / ch + 2f;
        else h = (r - g) / ch + 4f;
        float nch = ch * (text ? 0.85f : 0.7f);
        float den = 1f - Math.abs(2f * nl - 1f);
        float s = den < 0.0001f ? 0 : Math.min(1f, nch / den);
        return (a << 24) | hsl(h, s, nl);
    }

    private static int hsl(float h, float s, float l) {
        if (h < 0) h += 6f;
        float c = (1f - Math.abs(2f * l - 1f)) * s, x = c * (1f - Math.abs(h % 2f - 1f)), m = l - c / 2f;
        float r, g, b;
        int k = (int) h;
        switch (k) {
            case 0 -> { r = c; g = x; b = 0; }
            case 1 -> { r = x; g = c; b = 0; }
            case 2 -> { r = 0; g = c; b = x; }
            case 3 -> { r = 0; g = x; b = c; }
            case 4 -> { r = x; g = 0; b = c; }
            default -> { r = c; g = 0; b = x; }
        }
        return (Math.round((r + m) * 255) << 16) | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }

    // ---------- drawing, the same as the GuiGraphics calls but mode aware ----------

    public static void fill(GuiGraphics g, int x0, int y0, int x1, int y1, int argb) {
        g.fill(x0, y0, x1, y1, surface(argb));
    }

    public static void grad(GuiGraphics g, int x0, int y0, int x1, int y1, int top, int bottom) {
        g.fillGradient(x0, y0, x1, y1, surface(top), surface(bottom));
    }

    public static void rect(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + h, surface(argb));
    }

    public static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        int c = surface(argb);
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, c);
        }
    }

    public static int str(GuiGraphics g, Font f, String s, int x, int y, int argb) { return g.drawString(f, s, x, y, ink(argb)); }

    public static int str(GuiGraphics g, Font f, String s, int x, int y, int argb, boolean shadow) { return g.drawString(f, s, x, y, ink(argb), shadow); }

    public static int str(GuiGraphics g, Font f, Component s, int x, int y, int argb) { return g.drawString(f, s, x, y, ink(argb)); }

    public static int str(GuiGraphics g, Font f, Component s, int x, int y, int argb, boolean shadow) { return g.drawString(f, s, x, y, ink(argb), shadow); }

    public static int str(GuiGraphics g, Font f, FormattedCharSequence s, int x, int y, int argb, boolean shadow) { return g.drawString(f, s, x, y, ink(argb), shadow); }

    public static void cstr(GuiGraphics g, Font f, String s, int x, int y, int argb) { g.drawCenteredString(f, s, x, y, ink(argb)); }

    public static void cstr(GuiGraphics g, Font f, Component s, int x, int y, int argb) { g.drawCenteredString(f, s, x, y, ink(argb)); }
}
