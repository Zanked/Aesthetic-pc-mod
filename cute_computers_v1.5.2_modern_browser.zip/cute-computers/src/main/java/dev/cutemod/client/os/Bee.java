package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/**
 * The helper bee in the corner of the screen: gives a tip the first time you open an app, chats now and then,
 * tells about updates. Click it for a menu (a tip / quiet for now / turn off). It is switched off in Settings
 * and does not appear in Safe Mode. In the spooky mode it sometimes glitches.
 */
public final class Bee {
    private static final int ART_W = 26, ART_H = 22, SHOW_TICKS = 380, ARRIVE_TICKS = 50, MENU_ITEMS = 3;
    private static final int CHATS = 8, SPOOKY = 3;
    private static final int HOME_X = App.W - 34, HOME_Y = App.H - 32;

    private final Shell shell;
    private int t, arrive, idleT = 900, bubbleT, action, context = -1;
    private boolean menu, hiddenNow, greeted, updateTold, glitch;
    private String bubble = "";

    public Bee(Shell shell) { this.shell = shell; }

    public void reset() {
        arrive = 0;
        bubbleT = 0;
        menu = false;
        greeted = false;
        idleT = 900;
    }

    private boolean active() { return Retro.bee() && !Retro.safe() && !hiddenNow; }

    private static Font font() { return Minecraft.getInstance().font; }

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    /** The desktop or an app is in front now (-1 = the bare desktop). */
    public void context(int icon) {
        context = icon;
        if (!active() || icon < 0 || icon >= 16) return;
        int bit = 1 << icon;
        if ((Retro.beeSeen() & bit) == 0) {
            Retro.markSeen(bit);
            say("cutemod.bee.app." + icon, 0);
        }
    }

    private void say(String key, int act) {
        bubble = t(key);
        bubbleT = SHOW_TICKS;
        action = act;
        menu = false;
    }

    private void chat() {
        if (Updates.available() >= 0 && !updateTold) {
            updateTold = true;
            say("cutemod.bee.update", 1);
        } else if (Haunt.scary && Math.random() < 0.5) {
            glitch = true;
            say("cutemod.bee.spooky." + (int) (Math.random() * SPOOKY), 0);
        } else {
            glitch = false;
            say("cutemod.bee.chat." + (int) (Math.random() * CHATS), 0);
        }
    }

    private void tip() {
        if (context >= 0 && context < 16) say("cutemod.bee.app." + context, 0);
        else say("cutemod.bee.chat." + (int) (Math.random() * CHATS), 0);
    }

    public void tick() {
        t++;
        if (!active()) return;
        if (arrive < ARRIVE_TICKS + 40) {
            arrive++;
            if (arrive == ARRIVE_TICKS + 40 && !greeted) {
                greeted = true;
                if (Updates.available() >= 0 && !updateTold) { updateTold = true; say("cutemod.bee.update", 1); }
                else say("cutemod.bee.welcome", 0);
            }
            return;
        }
        if (bubbleT > 0 && --bubbleT == 0) { bubble = ""; glitch = false; }
        else if (bubbleT == 0 && !menu && --idleT <= 0) {
            chat();
            idleT = 3600 + (int) (Math.random() * 3600);
        }
    }

    // ---------- geometry ----------
    private int beeX() {
        float fly = Math.min(1f, Math.max(0f, (arrive - 40) / (float) ARRIVE_TICKS));
        float e = 1f - (1f - fly) * (1f - fly);
        return (int) (App.W + 30 + (HOME_X - App.W - 30) * e);
    }

    private int beeY() { return HOME_Y + (int) Math.round(Math.sin(t * 0.08) * 2); }

    private int menuW() { return 100; }

    private int menuX() { return Math.max(2, beeX() - menuW() - 4); }

    private int menuY() { return Math.max(2, beeY() + ART_H - MENU_ITEMS * 14 - 4); }

    private List<FormattedCharSequence> lines() { return font().split(Component.literal(bubble), 118); }

    private int bubbleW() {
        int w = 0;
        for (FormattedCharSequence l : lines()) w = Math.max(w, font().width(l));
        return w + 10;
    }

    private int bubbleH() { return Math.min(lines().size(), 6) * 9 + 7; }

    private int bubbleX() { return Math.max(2, beeX() - bubbleW() - 6); }

    private int bubbleY() { return Math.max(2, Math.min(App.H - bubbleH() - 2, beeY() + 8 - bubbleH())); }

    // ---------- input ----------
    public boolean click(int x, int y) {
        if (!active() || arrive < ARRIVE_TICKS + 40) return false;
        int bx = beeX(), by = beeY();
        if (menu) {
            for (int i = 0; i < MENU_ITEMS; i++) {
                if (App.in(x, y, menuX(), menuY() + i * 14, menuW(), 14)) {
                    menu = false;
                    Sfx.click();
                    switch (i) {
                        case 0 -> tip();
                        case 1 -> { hiddenNow = true; bubble = ""; }
                        default -> { Retro.setBee(false); bubble = ""; }
                    }
                    return true;
                }
            }
            menu = false;                       // a click elsewhere only closes the menu
            return App.in(x, y, bx - 2, by - 4, ART_W + 4, ART_H + 6);
        }
        if (App.in(x, y, bx - 2, by - 4, ART_W + 4, ART_H + 6)) {
            menu = true;
            bubble = "";
            bubbleT = 0;
            glitch = false;
            return true;
        }
        if (!bubble.isEmpty() && App.in(x, y, bubbleX(), bubbleY(), bubbleW(), bubbleH())) {
            int act = action;
            bubble = "";
            bubbleT = 0;
            if (act == 1) shell.launch(6);      // "open Settings"
            return true;
        }
        return false;
    }

    // ---------- drawing ----------
    public void render(GuiGraphics g, int mx, int my) {
        if (!active() || arrive < 40) return;
        int bx = beeX(), by = beeY();
        draw(g, bx, by);
        if (menu) renderMenu(g, mx, my);
        else if (!bubble.isEmpty()) renderBubble(g);
    }

    private static int rgb(int c) { return 0xFF000000 | c; }

    /** The bee, facing left. The outfit comes from the newest installed update. */
    private void draw(GuiGraphics g, int x, int y) {
        int flap = (t / 3) % 2;
        boolean blink = t % 150 < 6;
        boolean red = glitch && (t / 4) % 3 != 0;
        // wings
        g.fill(x + 7, y - 1 - flap, x + 13, y + 6, 0xCCFFFFFF);
        g.fill(x + 13, y - 2 + flap, x + 19, y + 6, 0xCCFFFFFF);
        g.fill(x + 7, y - 1 - flap, x + 13, y - flap, 0x66AEE4FF);
        // antennae
        g.fill(x + 5, y + 1, x + 6, y + 5, 0xFF3A2A3A);
        g.fill(x + 3, y, x + 5, y + 2, 0xFF3A2A3A);
        g.fill(x + 9, y + 2, x + 10, y + 5, 0xFF3A2A3A);
        g.fill(x + 8, y + 1, x + 11, y + 2, 0xFF3A2A3A);
        // body
        g.fill(x + 3, y + 7, x + 22, y + 19, 0xFFFFD23C);
        g.fill(x + 4, y + 5, x + 21, y + 21, 0xFFFFD23C);
        g.fill(x + 4, y + 5, x + 21, y + 6, 0xFFFFE680);
        g.fill(x + 11, y + 5, x + 13, y + 21, 0xFF3A2A3A);
        g.fill(x + 16, y + 6, x + 18, y + 20, 0xFF3A2A3A);
        g.fill(x + 22, y + 11, x + 25, y + 13, 0xFF3A2A3A);          // the stinger
        // face
        g.fill(x + 5, y + 10, x + 7, y + (blink ? 11 : 14), red ? 0xFFD9302A : 0xFF3A2A3A);
        g.fill(x + 8, y + 10, x + 10, y + (blink ? 11 : 14), red ? 0xFFD9302A : 0xFF3A2A3A);
        g.fill(x + 5, y + 16, x + 9, y + 17, 0xFF3A2A3A);
        g.fill(x + 4, y + 15, x + 5, y + 16, 0xFF3A2A3A);
        g.fill(x + 9, y + 15, x + 10, y + 16, 0xFF3A2A3A);
        g.fill(x + 3, y + 14, x + 5, y + 15, 0xFFFF9FB0);
        // the outfit of the newest update
        switch (Updates.outfit()) {
            case 1 -> { // sunglasses
                g.fill(x + 4, y + 9, x + 11, y + 13, 0xFF1B1422);
                g.fill(x + 4, y + 9, x + 6, y + 10, 0xFF6A6A8A);
            }
            case 2 -> { // a party hat
                g.fill(x + 4, y + 1, x + 10, y + 5, 0xFFFF6FB5);
                g.fill(x + 5, y - 2, x + 9, y + 1, 0xFFFF6FB5);
                g.fill(x + 6, y - 4, x + 8, y - 2, 0xFFFFE680);
            }
            case 3 -> { // a scarf
                g.fill(x + 10, y + 17, x + 20, y + 20, 0xFF3C9BE0);
                g.fill(x + 17, y + 20, x + 20, y + 24, 0xFF3C9BE0);
                g.fill(x + 12, y + 17, x + 14, y + 20, 0xFFFFFFFF);
            }
            case 4 -> { // a flower
                g.fill(x + 18, y + 2, x + 22, y + 6, 0xFFFF9FB0);
                g.fill(x + 19, y + 3, x + 21, y + 5, 0xFFFFE680);
            }
            case 5 -> { // a crown
                g.fill(x + 5, y + 2, x + 15, y + 6, 0xFFFFC832);
                g.fill(x + 5, y - 1, x + 7, y + 2, 0xFFFFC832);
                g.fill(x + 9, y - 1, x + 11, y + 2, 0xFFFFC832);
                g.fill(x + 13, y - 1, x + 15, y + 2, 0xFFFFC832);
                g.fill(x + 9, y + 3, x + 11, y + 5, 0xFFE5484D);
            }
            default -> { }
        }
    }

    private String shown() {
        if (!glitch || (t / 5) % 4 != 0) return bubble;
        StringBuilder sb = new StringBuilder();
        for (char c : bubble.toCharArray()) sb.append(c).append(' ');
        return sb.toString();
    }

    private void renderBubble(GuiGraphics g) {
        Font f = font();
        int w = bubbleW(), h = bubbleH(), x = bubbleX(), y = bubbleY();
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF3A2A4A);
        g.fill(x, y, x + w, y + h, 0xFFFFFBEA);
        g.fill(x + w, y + h - 10, x + w + 4, y + h - 6, 0xFF3A2A4A);               // the little tail towards the bee
        g.fill(x + w, y + h - 9, x + w + 3, y + h - 7, 0xFFFFFBEA);
        String text = shown();
        int ly = y + 4;
        for (FormattedCharSequence l : f.split(Component.literal(text), 118)) {
            if (ly > y + h - 8) break;
            g.drawString(f, l, x + 5, ly, glitch ? 0xFFB02020 : 0xFF3A2A3A, false);
            ly += 9;
        }
    }

    private void renderMenu(GuiGraphics g, int mx, int my) {
        Font f = font();
        int x = menuX(), y = menuY(), w = menuW();
        g.fill(x - 1, y - 1, x + w + 1, y + MENU_ITEMS * 14 + 1, 0xFF3A2A4A);
        for (int i = 0; i < MENU_ITEMS; i++) {
            boolean hover = App.in(mx, my, x, y + i * 14, w, 14);
            g.fill(x, y + i * 14, x + w, y + i * 14 + 14, hover ? 0xFFFFE680 : 0xFFFFFBEA);
            g.drawString(f, t("cutemod.bee.m" + i), x + 5, y + i * 14 + 3, 0xFF3A2A3A, false);
        }
    }
}
