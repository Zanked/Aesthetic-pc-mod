package dev.cutemod.client.os;

import dev.cutemod.net.PostSyncPayload;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** The "Players" tab of the mail app: letters and drawings from other players. Drawn by MailApp. */
final class PostPanel {
    private static final int HEAD = 17, ROW = 24, MAX_TEXT = 200;
    private static final int LIST = 0, READ = 1, WRITE = 2;

    private int mode = LIST;
    private int scroll, ticks;
    private PostSyncPayload.Letter open;
    private String to = "", text = "";
    private byte[] attach = new byte[0];
    private int focus;                 // 0 = recipient, 1 = text
    private String note = "";
    private int noteT;
    private boolean waiting;           // a letter was sent, waiting for the server's answer

    /** True on the list screen (MailApp draws the tab strip there). */
    boolean onList() { return mode == LIST; }

    void tick() {
        ticks++;
        if (noteT > 0) noteT--;
        if (waiting && Post.hasResult()) {
            int r = Post.takeResult();
            waiting = false;
            note = t(r == 0 ? "cutemod.post.sent" : "cutemod.post.err." + r);
            noteT = 240;
            if (r == 0) { mode = LIST; to = ""; text = ""; attach = new byte[0]; }
        }
    }

    private static String t(String key, Object... a) { return net.minecraft.network.chat.Component.translatable(key, a).getString(); }

    private static boolean in(int px, int py, int x, int y, int w, int h) { return px >= x && py >= y && px < x + w && py < y + h; }

    private static void rect(GuiGraphics g, int x, int y, int w, int h, int c) { Skin.fill(g, x, y, x + w, y + h, c); }

    /** Fill the header: the tab strip was drawn by MailApp on the list; the other screens draw their own. */
    void render(GuiGraphics g, Font f, int mx, int my, int h, boolean web) {
        int txt = web ? 0xFF5A3A00 : 0xFFFFFFFF, hov = web ? 0xFFFFD866 : 0xFF8A6AC6;
        if (mode == LIST) { list(g, f, mx, my, h, web, txt, hov); return; }
        boolean back = in(mx, my, 0, 0, 50, HEAD);
        if (back) Skin.rect(g, 0, 0, 50, HEAD, hov);
        Skin.str(g, f, "< " + t("cutemod.mail.back"), 6, 5, txt, false);
        if (mode == READ) reading(g, f, mx, my, h);
        else writing(g, f, mx, my, h, web);
    }

    private void list(GuiGraphics g, Font f, int mx, int my, int h, boolean web, int txt, int hov) {
        boolean nHover = in(mx, my, W() - 62, 0, 62, HEAD);
        if (nHover) Skin.rect(g, W() - 62, 0, 62, HEAD, hov);
        String wl = "+ " + t("cutemod.mail.write");
        Skin.str(g, f, wl, W() - 31 - f.width(wl) / 2, 5, txt, false);
        List<PostSyncPayload.Letter> box = Post.inbox();
        int rows = (h - HEAD) / ROW;
        scroll = Math.max(0, Math.min(Math.max(0, box.size() - rows), scroll));
        if (box.isEmpty()) {
            List<FormattedCharSequence> l = f.split(FormattedText.of(t(Post.loaded() ? "cutemod.post.empty" : "cutemod.post.loading")), W() - 24);
            for (int i = 0; i < l.size() && i < 5; i++) Skin.str(g, f, l.get(i), 12, HEAD + 12 + i * 10, 0xFF8A7AA8, false);
        }
        for (int i = 0; i < rows && i + scroll < box.size(); i++) {
            PostSyncPayload.Letter m = box.get(i + scroll);
            int y = HEAD + i * ROW;
            boolean unread = Post.unread(m);
            Skin.rect(g, 0, y, W(), ROW - 1, in(mx, my, 0, y, W(), ROW) ? 0xFFEBDDF7 : (unread ? 0xFFFFFFFF : 0xFFF0E8F7));
            int col = 0xFF000000 | (m.from().toLowerCase(Locale.ROOT).hashCode() & 0x7F7F7F) + 0x303030;
            Skin.fill(g, 6, y + 4, 20, y + 18, col);
            String init = m.from().isEmpty() ? "?" : m.from().substring(0, 1).toUpperCase(Locale.ROOT);
            Skin.str(g, f, init, 13 - f.width(init) / 2, y + 8, 0xFFFFFFFF, false);
            Skin.str(g, f, m.from(), 26, y + 3, unread ? 0xFF3A2A3A : 0xFF8A7AA8, false);
            String prev = (m.drawing().length > 0 ? "[" + t("cutemod.post.pic") + "] " : "") + m.text();
            Skin.str(g, f, f.plainSubstrByWidth(prev, W() - 52), 26, y + 13, unread ? 0xFF3A2A3A : 0xFF9A8AB8, false);
            if (unread) Skin.fill(g, W() - 12, y + 8, W() - 6, y + 14, 0xFFE5484D);
        }
        if (noteT > 0) {
            Skin.rect(g, 0, h - 14, W(), 14, 0xFFDFF5E3);
            Skin.str(g, f, note, 6, h - 11, 0xFF2E6B3A, false);
        }
        if (box.size() > rows) {
            int track = h - HEAD, th = Math.max(8, track * rows / box.size());
            Skin.rect(g, W() - 2, HEAD + (track - th) * scroll / (box.size() - rows), 2, th, 0xFFB57BD6);
        }
    }

    private static int W() { return App.W; }

    private void reading(GuiGraphics g, Font f, int mx, int my, int h) {
        int y = HEAD + 5;
        Skin.str(g, f, t("cutemod.post.from", open.from()), 8, y, 0xFF3A2A3A, false);
        Skin.str(g, f, java.time.format.DateTimeFormatter.ofPattern("dd.MM HH:mm")
                .format(java.time.LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(open.sent()), java.time.ZoneId.systemDefault())),
                W() - 8 - 60, y, 0xFF9A8AB8, false);
        Skin.rect(g, 6, y + 11, W() - 12, 1, 0xFFE9DDF2);
        boolean pic = open.drawing().length > 0;
        int limit = pic ? h - 78 : h - 62;
        List<FormattedCharSequence> lines = f.split(FormattedText.of(open.text()), W() - 16);
        int ty = y + 16;
        for (int i = 0; i < lines.size() && ty + 9 <= limit; i++) { Skin.str(g, f, lines.get(i), 8, ty, 0xFF3A2A3A, false); ty += 9; }
        if (pic) PaintApp.drawPacked(g, open.drawing(), 9, h - 75, 2, 1);
        boolean blocked = Post.isBlocked(open.from());
        button(g, f, mx, my, W() - 90, h - 58, 82, t("cutemod.post.reply"), true);
        button(g, f, mx, my, W() - 90, h - 39, 82, t("cutemod.post.delete"), true);
        button(g, f, mx, my, W() - 90, h - 20, 82, t(blocked ? "cutemod.post.unblock" : "cutemod.post.block"), true);
    }

    private void button(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, String label, boolean on) {
        boolean hover = on && in(mx, my, x, y, w, 16);
        Skin.rect(g, x, y, w, 16, !on ? 0xFFE6DDF0 : (hover ? 0xFFFFD866 : 0xFFFFC832));
        Skin.str(g, f, label, x + (w - f.width(label)) / 2, y + 4, 0xFF3A2A3A, false);
    }

    private List<String> suggestions() {
        List<String> out = new ArrayList<>();
        String q = to.trim().toLowerCase(Locale.ROOT);
        for (String p : Post.players()) {
            if (out.size() >= 4) break;
            if (q.isEmpty() || p.toLowerCase(Locale.ROOT).contains(q)) if (!p.equalsIgnoreCase(to.trim())) out.add(p);
        }
        return out;
    }

    private void writing(GuiGraphics g, Font f, int mx, int my, int h, boolean web) {
        Skin.str(g, f, t("cutemod.post.new.title"), 60, 5, web ? 0xFF5A3A00 : 0xFFE9DDF2, false);
        Skin.str(g, f, t("cutemod.post.to"), 8, HEAD + 8, 0xFF3A2A3A, false);
        int fx = 30, fw = W() - fx - 8;
        Skin.rect(g, fx - 1, HEAD + 3, fw + 2, 16, focus == 0 ? 0xFFB57BD6 : 0xFFD9CEE3);
        Skin.rect(g, fx, HEAD + 4, fw, 14, 0xFFFFFFFF);
        Skin.str(g, f, to, fx + 3, HEAD + 8, 0xFF3A2A3A, false);
        if (focus == 0 && (ticks / 30) % 2 == 0) Skin.rect(g, fx + 4 + f.width(to), HEAD + 6, 1, 10, 0xFF3A2A3A);
        int sx = 8;
        for (String s : suggestions()) {                       // quick picks under the recipient field
            int w = f.width(s) + 8;
            if (sx + w > W() - 8) break;
            boolean hv = in(mx, my, sx, HEAD + 21, w, 12);
            Skin.rect(g, sx, HEAD + 21, w, 12, hv ? 0xFFFFD866 : 0xFFE9DDF2);
            Skin.str(g, f, s, sx + 4, HEAD + 23, 0xFF3A2A3A, false);
            sx += w + 3;
        }
        int ty = HEAD + 37, th = 42;
        Skin.rect(g, 7, ty - 1, W() - 14, th + 2, focus == 1 ? 0xFFB57BD6 : 0xFFD9CEE3);
        Skin.rect(g, 8, ty, W() - 16, th, 0xFFFFFFFF);
        List<FormattedCharSequence> lines = f.split(FormattedText.of(text.isEmpty() ? "" : text), W() - 24);
        int from = Math.max(0, lines.size() - 4);
        for (int i = from; i < lines.size(); i++) Skin.str(g, f, lines.get(i), 11, ty + 3 + (i - from) * 9, 0xFF3A2A3A, false);
        if (text.isEmpty()) Skin.str(g, f, t("cutemod.post.text.ph"), 11, ty + 3, 0xFFB0A8B8, false);
        Skin.str(g, f, text.length() + "/" + MAX_TEXT, W() - 12 - f.width(text.length() + "/" + MAX_TEXT), ty + th - 9, 0xFFB0A8B8, false);
        if (focus == 1 && (ticks / 30) % 2 == 0 && !text.isEmpty()) {
            int li = Math.max(0, lines.size() - 1);
            String last = text.endsWith(" ") && lines.size() > 0 ? "" : "";
            // caret after the last line (approximation: end of the last wrapped line)
            StringBuilder sb = new StringBuilder();
            lines.get(li).accept((i, st, cp) -> { sb.appendCodePoint(cp); return true; });
            Skin.rect(g, 12 + f.width(sb.toString()), ty + 2 + Math.min(li, 3) * 9, 1, 9, 0xFF3A2A3A);
        }
        int by = h - 22;
        boolean hasPic = PaintApp.hasPicture();
        String al = t(attach.length > 0 ? "cutemod.post.detach" : "cutemod.post.attach");
        button(g, f, mx, my, 8, by, 96, al, attach.length > 0 || hasPic);
        if (attach.length > 0) PaintApp.drawPacked(g, attach, 110, by - 1, 1, 2);
        boolean ok = !to.isBlank() && (!text.isBlank() || attach.length > 0) && !waiting;
        button(g, f, mx, my, W() - 88, by, 80, t("cutemod.mail.send"), ok);
        if (attach.length == 0 && !hasPic) Skin.str(g, f, t("cutemod.post.nopic"), 110, by + 4, 0xFFB0A8B8, false);
        if (noteT > 0) { Skin.rect(g, 0, by - 12, W(), 11, 0xFFFBE3E3); Skin.str(g, f, note, 6, by - 10, 0xFF9A2A2A, false); }
    }

    // ---------- input ----------
    boolean click(int x, int y, int h) {
        if (mode == LIST) {
            if (in(x, y, W() - 62, 0, 62, HEAD)) { start(""); return true; }
            List<PostSyncPayload.Letter> box = Post.inbox();
            int i = (y - HEAD) / ROW;
            if (y >= HEAD && i < (h - HEAD) / ROW && i + scroll < box.size()) {
                open = box.get(i + scroll);
                Post.markRead(open);
                mode = READ;
                return true;
            }
            return false;
        }
        if (in(x, y, 0, 0, 50, HEAD)) { mode = LIST; return true; }
        if (mode == READ) {
            if (in(x, y, W() - 90, h - 58, 82, 16)) { start(open.from()); return true; }
            if (in(x, y, W() - 90, h - 39, 82, 16)) { Post.delete(open.id()); mode = LIST; return true; }
            if (in(x, y, W() - 90, h - 20, 82, 16)) { Post.block(open.from(), !Post.isBlocked(open.from())); return true; }
            return false;
        }
        // WRITE
        if (in(x, y, 30, HEAD + 3, W() - 38, 16)) { focus = 0; return true; }
        if (in(x, y, 7, HEAD + 36, W() - 14, 44)) { focus = 1; return true; }
        Font f = net.minecraft.client.Minecraft.getInstance().font;
        int sx = 8;
        for (String s : suggestions()) {
            int w = f.width(s) + 8;
            if (sx + w > W() - 8) break;
            if (in(x, y, sx, HEAD + 21, w, 12)) { to = s; focus = 1; return true; }
            sx += w + 3;
        }
        int by = h - 22;
        if (in(x, y, 8, by, 96, 16)) {
            if (attach.length > 0) attach = new byte[0];
            else if (PaintApp.hasPicture()) attach = PaintApp.snapshot();
            return true;
        }
        if (in(x, y, W() - 88, by, 80, 16)) { submit(); return true; }
        return false;
    }

    private void start(String recipient) {
        mode = WRITE;
        to = recipient;
        text = "";
        attach = new byte[0];
        focus = recipient.isEmpty() ? 0 : 1;
        Post.request();          // fresh list of players
    }

    private void submit() {
        if (to.isBlank() || (text.isBlank() && attach.length == 0) || waiting) return;
        Post.takeResult();
        Post.send(to.trim(), text.trim(), attach);
        waiting = true;
    }

    boolean charTyped(char c) {
        if (mode != WRITE || c < 32 || c == 127) return false;
        if (focus == 0) { if (to.length() < 16 && (Character.isLetterOrDigit(c) || c == '_')) to += c; }
        else if (text.length() < MAX_TEXT) text += c;
        return true;
    }

    boolean key(int keyCode, int modifiers) {
        if (mode == LIST) return false;
        if (keyCode == 256) { mode = LIST; return true; }                       // escape: back, not close
        if (mode == READ) {
            if (keyCode == 259) { mode = LIST; return true; }
            return false;
        }
        if (keyCode == 258) { focus = 1 - focus; return true; }                  // tab
        if (keyCode == 259) {
            if (focus == 0 && !to.isEmpty()) to = to.substring(0, to.length() - 1);
            else if (focus == 1 && !text.isEmpty()) text = text.substring(0, text.length() - 1);
            return true;
        }
        if (keyCode == 257 || keyCode == 335) {
            if (focus == 0) focus = 1; else submit();
            return true;
        }
        return false;
    }

    boolean scroll(double amount) {
        if (mode != LIST) return false;
        scroll -= (int) Math.signum(amount);
        return true;
    }
}
