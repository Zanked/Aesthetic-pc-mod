package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * The desktop. The wallpaper, menu bar and Dock are drawn by the computer screen; this class owns the apps
 * (the Dock launches them with launch(i)) and draws the desktop widget.
 */
public class Desktop extends App {
    public static final int ICONS = 17;

    private BrowserApp browser;
    private NotepadApp notes;
    private PaintApp paint;
    private CalcApp calc;
    private MusicApp music;
    private PetApp pet;
    private QuestApp quest;
    private TerminalApp terminal;
    private StoreApp store;
    private JobsApp jobs;
    private MailApp mail;
    private MarketApp market;
    private NetApp net;
    private WeatherApp weather;
    private boolean widgetMenu;
    private int wmX, wmY;

    @Override
    public Component title() { return Component.translatable("cutemod.os.title"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.desktop"); }

    /** Name of the app with this Dock index. */
    public String label(int i) {
        return switch (i) {
            case 0 -> t("cutemod.game." + shell.color().id);
            case 1 -> t("cutemod.os.games");
            case 2 -> t("cutemod.os.browser");
            case 3 -> t("cutemod.os.notes");
            case 4 -> t("cutemod.os.paint");
            case 5 -> t("cutemod.os.calc");
            case 7 -> t("cutemod.os.music");
            case 8 -> t("cutemod.os.pet");
            case 9 -> t("cutemod.os.market");
            case 10 -> t("cutemod.os.quest");
            case 11 -> t("cutemod.os.terminal");
            case 12 -> t("cutemod.os.store");
            case 13 -> t("cutemod.os.jobs");
            case 14 -> t("cutemod.os.mail");
            case 15 -> t("cutemod.os.net");
            case 16 -> t("cutemod.os.weather");
            default -> t("cutemod.os.settings");
        };
    }

    @Override
    public void tick() { Halloween.tick(); }

    /** The music app, if it was opened (the player widget talks to it). */
    MusicApp music() { return music; }

    private static final int SAFE_BTN_W = 150, SAFE_BTN_H = 18;

    private static int safeBtnX() { return (W - SAFE_BTN_W) / 2; }

    private static int safeBtnY() { return H / 2 - 4; }

    @Override
    public boolean click(int x, int y, int button) {
        if (Retro.safe()) {                                          // Safe Mode: the one thing to do is repair the disk
            if (in(x, y, safeBtnX(), safeBtnY(), SAFE_BTN_W, SAFE_BTN_H)) { Sfx.click(); shell.open(new RepairApp()); }
            return true;
        }
        if (widgetMenu) {                                            // the widgets menu takes this click
            widgetMenu = false;
            Widgets.clickMenu(x, y, wmX, wmY);
            return true;
        }
        int wr = Widgets.click(music, x, y, button);
        if (wr == Widgets.OPEN_MARKET) { launch(9); return true; }
        if (wr != Widgets.NONE) return true;
        if (Halloween.click(shell, x, y)) return true;
        if (button == 1) {                                           // right click on the empty desktop: add or remove widgets
            widgetMenu = true;
            wmX = Math.min(x, W - Widgets.menuW() - 2);
            wmY = Math.min(y, H - Widgets.menuH() - 2);
            return true;
        }
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        if (Retro.safe()) {
            g.drawCenteredString(font(), Component.translatable("cutemod.safe.hint"), W / 2, H / 2 - 24, 0xFFBFBFBF);
            boolean hover = in(mx, my, safeBtnX(), safeBtnY(), SAFE_BTN_W, SAFE_BTN_H);
            rect(g, safeBtnX() - 1, safeBtnY() - 1, SAFE_BTN_W + 2, SAFE_BTN_H + 2, 0xFFBFBFBF);
            rect(g, safeBtnX(), safeBtnY(), SAFE_BTN_W, SAFE_BTN_H, hover ? 0xFF2A4A80 : 0xFF0B1A33);
            g.drawCenteredString(font(), Component.translatable("cutemod.safe.open"), W / 2, safeBtnY() + 5, 0xFFFFFFFF);
            return;
        }
        Halloween.render(g, mx, my);
        Widgets.render(g, music, mx, my);
        if (widgetMenu) Widgets.renderMenu(g, mx, my, wmX, wmY);
    }

    /** Which Dock icon belongs to the running app (-1 = none / the desktop itself). */
    public int activeIndex(App a) {
        if (a instanceof GamesApp) return 1;
        if (a instanceof GameApp) return 0;
        if (a instanceof BrowserApp) return 2;
        if (a instanceof NotepadApp) return 3;
        if (a instanceof PaintApp) return 4;
        if (a instanceof CalcApp) return 5;
        if (a instanceof SettingsApp) return 6;
        if (a instanceof MusicApp) return 7;
        if (a instanceof PetApp) return 8;
        if (a instanceof MarketApp) return 9;
        if (a instanceof QuestApp) return 10;
        if (a instanceof TerminalApp) return 11;
        if (a instanceof StoreApp) return 12;
        if (a instanceof JobsApp) return 13;
        if (a instanceof MailApp) return 14;
        if (a instanceof NetApp) return 15;
        if (a instanceof WeatherApp) return 16;
        return -1;
    }

    /** Draws the 32x32 icon of app number i at x,y (the Dock scales it with the pose). */
    /** Tile colors (top, bottom) of every icon, by its Dock number; 0 (the gamepad) uses the computer's own color. */
    private static final int[][] TILE = {
            {0, 0},                        // 0 gamepad
            {0xFF7BD8FF, 0xFF2F9BF2},      // 1 games folder
            {0xFF5BE6D4, 0xFF1AA7C9},      // 2 browser
            {0xFFFFE97A, 0xFFF7BE1D},      // 3 notes
            {0xFFC59BFF, 0xFF7C4DE6},      // 4 paint
            {0xFF5A5A62, 0xFF1C1C20},      // 5 calculator
            {0xFFB9BEC8, 0xFF727886},      // 6 settings
            {0xFFFF7AB5, 0xFFE02A7A},      // 7 music
            {0xFF9BE88A, 0xFF34B85A},      // 8 pet
            {0xFFFFA070, 0xFFF0603A},      // 9 market
            {0xFFFF7A7A, 0xFFD92B3A},      // 10 diary
            {0xFF48484E, 0xFF0E0E10},      // 11 terminal
            {0xFF6FB0FF, 0xFF2F4FE0},      // 12 store
            {0xFFCFA070, 0xFF8A5F36},      // 13 jobs
            {0xFF63C6FF, 0xFF1F7BF0},      // 14 mail
            {0xFF8BE89A, 0xFF1E9E6A},      // 15 CuteNet
            {0xFF8FD8FF, 0xFF3A8AE0}};     // 16 weather

    /** The macOS-style rounded tile every icon sits on: a soft vertical gradient, a light top edge, a thin dark rim. */
    private static void tile(GuiGraphics g, int x, int y, int top, int bottom) {
        final int r = 8, size = 32;
        if (Theme.aero()) { glassTile(g, x, y, top, bottom); return; }
        for (int dy = 0; dy < size; dy++) {
            double m = dy + 0.5;
            double d = m < r ? r - m : m > size - r ? m - (size - r) : 0;
            int inset = d > 0 ? (int) Math.round(r - Math.sqrt(r * r - d * d)) : 0;
            int c = mix(top, bottom, dy / (float) (size - 1));
            g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, c);
            g.fill(x + inset, y + dy, x + inset + 1, y + dy + 1, 0x26000000);               // the rim
            g.fill(x + size - inset - 1, y + dy, x + size - inset, y + dy + 1, 0x26000000);
            if (dy == 1) g.fill(x + inset + 1, y + dy, x + size - inset - 1, y + dy + 1, 0x55FFFFFF); // light top edge
            if (dy == size - 1) g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, 0x30000000);
        }
    }

    /** Frutiger Aero: a see-through glass tile with a bright rim, a glossy upper half and a glow at the bottom. */
    private static void glassTile(GuiGraphics g, int x, int y, int top, int bottom) {
        final int r = 8, size = 32;
        for (int dy = 0; dy < size; dy++) {
            double m = dy + 0.5;
            double d = m < r ? r - m : m > size - r ? m - (size - r) : 0;
            int inset = d > 0 ? (int) Math.round(r - Math.sqrt(r * r - d * d)) : 0;
            float f = dy / (float) (size - 1);
            int c = (mix(top, bottom, f) & 0xFFFFFF) | ((0xA0 - (int) (0x30 * f)) << 24);       // clear glass: the wallpaper shows through
            g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, c);
            g.fill(x + inset, y + dy, x + inset + 1, y + dy + 1, 0xC0FFFFFF);                  // the bright rim
            g.fill(x + size - inset - 1, y + dy, x + size - inset, y + dy + 1, 0xC0FFFFFF);
            if (dy == 0 || dy == size - 1) g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, 0xC0FFFFFF);
            if (dy >= 1 && dy <= 14) {                                                             // the gloss on the upper half
                int al = 0x58 - dy * 3;
                g.fill(x + inset + 2, y + dy, x + size - inset - 2, y + dy + 1, (Math.max(8, al) << 24) | 0xFFFFFF);
            }
            if (dy >= 25 && dy <= 29) g.fill(x + inset + 3, y + dy, x + size - inset - 3, y + dy + 1, ((dy - 22) * 6 << 24) | 0xBFF1FF);  // glow
        }
    }

    /** One Dock icon: the rounded tile plus a flat glyph. Drawn in a 32 x 32 box at (x, y). */
    public static void drawIcon(GuiGraphics g, int i, int x, int y, int body) {
        int top, bot;
        if (i == 0) { top = mix(body, 0xFFFFFF, 0.3f); bot = mix(body, 0x000000, 0.2f); }
        else { int[] c = TILE[i > 0 && i < TILE.length ? i : 4]; top = c[0]; bot = c[1]; }
        tile(g, x, y, top, bot);
        int mid = mix(top, bot, 0.5f);
        final int WH = 0xFFFFFFFF;
        switch (i) {
            case 0 -> { // gamepad
                int dk = mix(body, 0x000000, 0.45f);
                rect(g, x + 9, y + 9, 4, 2, WH); rect(g, x + 19, y + 9, 4, 2, WH);
                rect(g, x + 6, y + 11, 20, 9, WH);
                disc(g, x + 9, y + 20, 4, WH); disc(g, x + 23, y + 20, 4, WH);
                rect(g, x + 10, y + 15, 6, 2, dk); rect(g, x + 12, y + 13, 2, 6, dk);
                rect(g, x + 19, y + 14, 3, 3, dk); rect(g, x + 22, y + 17, 3, 3, dk);
            }
            case 1 -> { // games folder
                rect(g, x + 6, y + 9, 9, 4, 0xFFD6ECFF);
                rect(g, x + 6, y + 12, 20, 13, WH);
                rect(g, x + 6, y + 12, 20, 1, 0xFFD6ECFF);
                rect(g, x + 13, y + 18, 6, 2, mid); rect(g, x + 15, y + 16, 2, 6, mid);
            }
            case 2 -> { // browser: a compass
                disc(g, x + 16, y + 16, 11, WH);
                disc(g, x + 16, y + 16, 9, mix(top, bot, 0.6f));
                rect(g, x + 15, y + 8, 2, 2, WH); rect(g, x + 15, y + 22, 2, 2, WH);
                rect(g, x + 8, y + 15, 2, 2, WH); rect(g, x + 22, y + 15, 2, 2, WH);
                for (int k = -7; k <= 7; k++) rect(g, x + 15 + k, y + 15 - k, 2, 2, k >= 0 ? 0xFFFF5A4A : WH);
            }
            case 3 -> { // notes
                rect(g, x + 7, y + 6, 18, 21, WH);
                rect(g, x + 7, y + 6, 18, 5, 0xFFF0B000);
                for (int l = 0; l < 4; l++) rect(g, x + 10, y + 14 + l * 3, 12, 1, 0xFFC8CCD8);
            }
            case 5 -> { // calculator
                rect(g, x + 7, y + 6, 18, 6, 0xFF333338);
                rect(g, x + 19, y + 8, 4, 2, 0xFFB6F59A);
                for (int r = 0; r < 3; r++) for (int c = 0; c < 4; c++)
                    rect(g, x + 7 + c * 5, y + 15 + r * 4, 3, 3, c == 3 ? 0xFFFF9F0A : r == 0 ? 0xFFA5A5AA : 0xFF8E8E93);
            }
            case 6 -> { // settings: a gear
                rect(g, x + 14, y + 5, 4, 4, WH); rect(g, x + 14, y + 23, 4, 4, WH);
                rect(g, x + 5, y + 14, 4, 4, WH); rect(g, x + 23, y + 14, 4, 4, WH);
                rect(g, x + 8, y + 8, 4, 4, WH); rect(g, x + 20, y + 8, 4, 4, WH);
                rect(g, x + 8, y + 20, 4, 4, WH); rect(g, x + 20, y + 20, 4, 4, WH);
                disc(g, x + 16, y + 16, 9, WH);
                disc(g, x + 16, y + 16, 3, mid);
            }
            case 7 -> { // music: two beamed notes
                disc(g, x + 11, y + 23, 3, WH); disc(g, x + 21, y + 21, 3, WH);
                rect(g, x + 13, y + 10, 2, 13, WH); rect(g, x + 23, y + 8, 2, 13, WH);
                rect(g, x + 13, y + 9, 12, 3, WH);
            }
            case 8 -> { // pet: an egg with a face
                disc(g, x + 16, y + 19, 9, WH);
                disc(g, x + 16, y + 13, 6, WH);
                rect(g, x + 12, y + 17, 2, 3, 0xFF3A2A3A); rect(g, x + 19, y + 17, 2, 3, 0xFF3A2A3A);
                rect(g, x + 15, y + 22, 3, 1, 0xFF3A2A3A);
                rect(g, x + 10, y + 21, 2, 2, 0xFFFFB6D2); rect(g, x + 21, y + 21, 2, 2, 0xFFFFB6D2);
            }
            case 9 -> { // market: a bag with a heart
                rect(g, x + 12, y + 7, 8, 1, WH); rect(g, x + 12, y + 7, 1, 6, WH); rect(g, x + 19, y + 7, 1, 6, WH);
                rect(g, x + 8, y + 12, 16, 15, WH);
                rect(g, x + 12, y + 16, 3, 2, mid); rect(g, x + 17, y + 16, 3, 2, mid);
                rect(g, x + 12, y + 18, 8, 2, mid); rect(g, x + 14, y + 20, 4, 2, mid);
            }
            case 10 -> { // diary: a book with an exclamation mark
                rect(g, x + 7, y + 6, 3, 20, 0xFFFFD0D0);
                rect(g, x + 9, y + 6, 16, 20, WH);
                rect(g, x + 16, y + 9, 3, 8, bot);
                rect(g, x + 16, y + 19, 3, 3, bot);
            }
            case 11 -> { // terminal: a prompt
                rect(g, x + 8, y + 10, 2, 2, WH); rect(g, x + 10, y + 12, 2, 2, WH); rect(g, x + 12, y + 14, 2, 2, WH);
                rect(g, x + 10, y + 16, 2, 2, WH); rect(g, x + 8, y + 18, 2, 2, WH);
                rect(g, x + 15, y + 19, 8, 2, WH);
            }
            case 12 -> { // store: a play triangle
                for (int c = 0; c < 10; c++) {
                    int h = Math.round(16 - c * 1.5f);
                    rect(g, x + 12 + c, y + 16 - h / 2, 1, h, WH);
                }
            }
            case 13 -> { // jobs: a briefcase
                rect(g, x + 12, y + 7, 8, 2, WH); rect(g, x + 12, y + 7, 2, 5, WH); rect(g, x + 18, y + 7, 2, 5, WH);
                rect(g, x + 7, y + 11, 18, 14, WH);
                rect(g, x + 7, y + 17, 18, 1, mid);
                rect(g, x + 14, y + 16, 4, 3, bot);
            }
            case 15 -> { // CuteNet: two people joined by a signal arc
                disc(g, x + 11, y + 12, 4, WH); disc(g, x + 21, y + 12, 4, WH);
                disc(g, x + 11, y + 24, 6, WH); disc(g, x + 21, y + 24, 6, WH);
                rect(g, x + 5, y + 24, 22, 4, mid);
                rect(g, x + 5, y + 25, 22, 3, WH);
                for (int k = 0; k < 3; k++) rect(g, x + 14 + k, y + 6 + (k == 1 ? -1 : 0), 1, 2, 0xFFFFFFFF);
            }
            case 16 -> { // weather: a sun behind a cloud
                disc(g, x + 20, y + 11, 6, 0xFFFFE070);
                for (int k = 0; k < 8; k++) {
                    double ang = k * Math.PI / 4;
                    rect(g, x + 20 + (int) Math.round(Math.cos(ang) * 10), y + 11 + (int) Math.round(Math.sin(ang) * 10), 2, 2, 0xFFFFE070);
                }
                disc(g, x + 11, y + 21, 5, WH);
                disc(g, x + 17, y + 18, 6, WH);
                disc(g, x + 23, y + 22, 4, WH);
                rect(g, x + 8, y + 21, 17, 5, WH);
            }
            case 14 -> { // mail: an envelope
                rect(g, x + 6, y + 9, 20, 15, WH);
                for (int k = 0; k < 10; k++) { rect(g, x + 6 + k, y + 9 + k / 2, 1, 1, mid); rect(g, x + 25 - k, y + 9 + k / 2, 1, 1, mid); }
            }
            default -> { // paint: a palette
                disc(g, x + 16, y + 16, 11, WH);
                disc(g, x + 21, y + 22, 3, mid);
                disc(g, x + 10, y + 15, 2, 0xFFE5484D);
                disc(g, x + 15, y + 10, 2, 0xFFF3D46A);
                disc(g, x + 21, y + 12, 2, 0xFF5BBF6A);
                disc(g, x + 10, y + 21, 2, 0xFF2F7FD6);
            }
        }
    }

    /** Opens the app with this Dock index. */
    /** The app was shut down: forget its saved instance so it starts fresh next time. */
    public void forget(App a) {
        if (browser == a) browser = null;
        if (notes == a) notes = null;
        if (paint == a) paint = null;
        if (calc == a) calc = null;
        if (music == a) music = null;
        if (pet == a) pet = null;
        if (quest == a) quest = null;
        if (terminal == a) terminal = null;
        if (store == a) store = null;
        if (jobs == a) jobs = null;
        if (mail == a) mail = null;
        if (market == a) market = null;
        if (weather == a) weather = null;
    }

    /** Opens CuteStore on the page of one game. */
    public void openStore(String gameId) {
        if (store == null) store = new StoreApp();
        store.show(gameId);
        shell.open(store);
    }

    public void launch(int i) {
        Library.Program prog = Library.programByIcon(i);
        if (prog != null && !Library.installed(prog.id())) {      // not installed: show its page in the store
            openStore(prog.id());
            return;
        }
        switch (i) {
            case 0 -> {
                if (Library.installed(shell.color().id)) shell.open(new GameApp(shell.color()));
                else openStore(shell.color().id);   // not bought / still installing: show its store page
            }
            case 1 -> shell.open(new GamesApp());
            case 2 -> {
                if (browser == null) browser = new BrowserApp();
                shell.open(browser);
            }
            case 3 -> {
                if (notes == null) notes = new NotepadApp();
                shell.open(notes);
            }
            case 4 -> {
                if (paint == null) paint = new PaintApp();
                shell.open(paint);
            }
            case 5 -> {
                if (calc == null) calc = new CalcApp();
                shell.open(calc);
            }
            case 7 -> {
                if (music == null) music = new MusicApp();
                shell.open(music);
            }
            case 8 -> {
                if (pet == null) pet = new PetApp();
                shell.open(pet);
            }
            case 9 -> {
                if (market == null) market = new MarketApp();
                shell.open(market);
            }
            case 10 -> {
                if (quest == null) quest = new QuestApp();
                shell.open(quest);
            }
            case 11 -> {
                if (terminal == null) terminal = new TerminalApp();
                shell.open(terminal);
            }
            case 12 -> {
                if (store == null) store = new StoreApp();
                shell.open(store);
            }
            case 13 -> {
                if (jobs == null) jobs = new JobsApp();
                shell.open(jobs);
            }
            case 14 -> {
                if (mail == null) mail = new MailApp();
                shell.open(mail);
            }
            case 15 -> {
                if (net == null) net = new NetApp();
                shell.open(net);
            }
            case 16 -> {
                if (weather == null) weather = new WeatherApp();
                shell.open(weather);
            }
            default -> shell.open(new SettingsApp());
        }
    }

    /** Red number on the Dock icon (0 = no badge). */
    public int badge(int i) {
        return i == 14 ? Mail.unreadCount() + Post.unreadCount() : i == 9 ? Market.readyCount() : 0;
    }
}
