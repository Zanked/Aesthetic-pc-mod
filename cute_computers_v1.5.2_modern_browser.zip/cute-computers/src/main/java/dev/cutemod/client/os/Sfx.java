package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.core.Holder;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * The sounds of the computer: the power-on chime, system beeps, key clicks, a quiet disk crackle
 * and the hum of the fan. Everything is made of vanilla sounds (note blocks, UI clicks, the beacon
 * hum), so no sound files are needed. "Sounds" and "Hum" can be switched off in Settings
 * (remembered in cutemod_sound.txt).
 */
public final class Sfx {
    private Sfx() {}

    public static boolean sounds = true;
    public static boolean hum = true;
    public static boolean music = true;
    /** Volumes 0..100: the computer's own sounds (clicks, chimes, fan, game effects) and the music (game tracks and the Music app). */
    public static int volSystem = 100, volMusic = 100;
    private static boolean loaded;

    private static Path file() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("cutemod_sound.txt");
    }

    private static void load() {
        if (loaded) return;
        loaded = true;
        try {
            Path p = file();
            if (Files.exists(p)) {
                String[] v = Files.readString(p).trim().split(",");
                sounds = v[0].equals("1");
                hum = v.length < 2 || v[1].equals("1");
                music = v.length < 3 || v[2].equals("1");
                if (v.length > 3) volSystem = parseVol(v[3]);
                if (v.length > 4) volMusic = parseVol(v[4]);
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Files.writeString(file(), (sounds ? "1" : "0") + "," + (hum ? "1" : "0") + "," + (music ? "1" : "0")
                    + "," + volSystem + "," + volMusic);
        } catch (Exception ignored) {
        }
    }

    private static int parseVol(String s) {
        try { return Math.max(0, Math.min(100, Integer.parseInt(s.trim()))); } catch (Exception e) { return 100; }
    }

    /** System volume, 0..1. */
    public static float systemVol() { load(); return volSystem / 100F; }

    /** Music volume, 0..1. */
    public static float musicVol() { load(); return volMusic / 100F; }

    /** A computer or game effect: respects the Sounds switch and the system volume. */
    public static void ui(SoundEvent e, float pitch, float vol) {
        play(e, pitch, vol);
    }

    /** A note of the Music app or the videos: only the music volume counts (the player chose to listen). */
    public static void musicNote(SoundEvent e, float pitch, float vol) {
        float v = vol * musicVol();
        if (v <= 0F) return;
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(e, pitch, v));
    }

    public static boolean sounds() { load(); return sounds; }

    public static boolean hum() { load(); return hum; }

    /** The music that plays while a game is open (see GameMusic). */
    public static boolean music() { load(); return music; }

    private static void play(Holder<SoundEvent> e, float pitch, float vol) { play(e.value(), pitch, vol); }

    private static void play(SoundEvent e, float pitch, float vol) {
        if (!sounds()) return;
        float v = vol * systemVol();
        if (v <= 0F) return;
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(e, pitch, v));
    }

    /** Note-block pitch for a semitone offset from the middle note. */
    private static float semi(int n) { return (float) Math.pow(2, n / 12.0); }

    // ---------- single sounds ----------
    public static void click() {
        if (Theme.aero()) {                                                              // a bubble pop and a drop
            play(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 1.3F, 1.0F);
            play(SoundEvents.AMETHYST_BLOCK_CHIME, 1.8F, 0.6F);
        }
        else play(SoundEvents.UI_BUTTON_CLICK.value(), 1.7F, 0.35F);
    }

    public static void key() {
        if (Theme.aero()) play(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 1.8F, 0.7F);       // a tiny bubble
        else play(SoundEvents.UI_BUTTON_CLICK.value(), 2.0F, 0.18F);
    }

    /** The end of a game: a bright jingle for a win, a heartbeat for the dark games, a soft low bell otherwise. */
    public static void gameOver(boolean win, boolean dark) {
        if (win) {
            play(ev(SoundEvents.PLAYER_LEVELUP), 1.2F, 0.5F);
            play(ev(SoundEvents.AMETHYST_BLOCK_CHIME), 1.6F, 0.8F);
        } else if (dark) {
            play(ev(SoundEvents.WARDEN_HEARTBEAT), 0.9F, 1.0F);
            play(SoundEvents.NOTE_BLOCK_BASS.value(), 0.5F, 0.7F);
        } else {
            play(SoundEvents.NOTE_BLOCK_BELL.value(), 0.75F, 0.5F);
            play(ev(SoundEvents.NOTE_BLOCK_BASEDRUM), 0.9F, 0.35F);
        }
    }

    public static void disk() { play(SoundEvents.UI_BUTTON_CLICK.value(), 2.0F, 0.1F); }

    public static void error() {
        if (Theme.aero()) {                                                              // two bells, like an old "ding"
            play(SoundEvents.GENERIC_SPLASH, 0.8F, 1.0F);                                // a blurp and a low glass note
            play(SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 1.0F);
            return;
        }
        play(SoundEvents.NOTE_BLOCK_BASS.value(), 0.6F, 0.8F);
        play(SoundEvents.NOTE_BLOCK_BIT.value(), 0.5F, 0.4F);
    }

    public static void powerOn() {
        if (Theme.aero()) {
            play(SoundEvents.GENERIC_SPLASH, 1.5F, 0.9F);                                 // a splash, glass and a shimmer
            play(SoundEvents.AMETHYST_BLOCK_CHIME, 1.4F, 1.0F);
            play(SoundEvents.BEACON_ACTIVATE, 2.0F, 0.5F);
            return;
        }
        play(SoundEvents.UI_BUTTON_CLICK.value(), 0.6F, 0.6F);
        play(SoundEvents.BEACON_ACTIVATE, 1.6F, 0.25F);
    }

    /** Notes of the sounds that need a few steps. {delay in ticks, semitone, instrument (0 chime, 1 bell, 2 bit)}. */
    public static final int[][] STARTUP = {{0, -5, 0}, {5, 0, 0}, {10, 4, 0}, {15, 7, 1}, {22, 12, 1}};
    public static final int[][] LOGIN = {{0, 4, 1}, {4, 9, 1}};
    public static final int[][] LOCK = {{0, 7, 1}, {4, 0, 1}};
    public static final int[][] SHUTDOWN = {{0, 7, 0}, {5, 0, 0}, {10, -5, 0}};

    // the Frutiger Aero set: water drops, glass chimes and bubbles (instrument 4 = glass chime, 5 = bubble pop, 3 = harp)
    private static final int[][] AERO_STARTUP = {{0, -5, 5}, {3, -3, 4}, {7, 0, 5}, {10, 4, 4}, {14, 7, 5}, {17, 12, 4}, {24, 7, 4}, {30, 12, 3}};
    private static final int[][] AERO_LOGIN = {{0, 4, 5}, {3, 7, 4}, {7, 12, 4}};
    private static final int[][] AERO_LOCK = {{0, 12, 4}, {4, 7, 5}, {8, 0, 4}};
    private static final int[][] AERO_SHUTDOWN = {{0, 12, 4}, {5, 7, 5}, {10, 0, 4}, {15, -5, 5}};

    public static int[][] startup() { return Theme.aero() ? AERO_STARTUP : STARTUP; }

    public static int[][] login() { return Theme.aero() ? AERO_LOGIN : LOGIN; }

    public static int[][] lock() { return Theme.aero() ? AERO_LOCK : LOCK; }

    public static int[][] shutdown() { return Theme.aero() ? AERO_SHUTDOWN : SHUTDOWN; }

    private static SoundEvent ev(Object o) { return o instanceof Holder<?> h ? (SoundEvent) h.value() : (SoundEvent) o; }

    public static void note(int[] n) {
        SoundEvent e = switch (n[2]) {
            case 3 -> SoundEvents.NOTE_BLOCK_HARP.value();
            case 4 -> ev(SoundEvents.AMETHYST_BLOCK_CHIME);
            case 5 -> ev(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP);
            case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
            case 2 -> SoundEvents.NOTE_BLOCK_BIT.value();
            default -> SoundEvents.NOTE_BLOCK_CHIME.value();
        };
        play(e, semi(n[1]), n[2] >= 3 && Theme.aero() ? 1.0F : 0.5F);   // the Aero water notes are quiet by nature
    }

    /** Plays a jingle right now (the delays are ignored). Used for the shutdown, when no tick follows. */
    public static void jingleNow(int[][] j) {
        for (int[] n : j) note(n);
    }

    // ---------- the fan ----------
    private static Hum fan;

    /** A quiet looping drone (the beacon hum) that follows the player, so it is heard evenly. */
    private static final class Hum extends AbstractTickableSoundInstance {
        private boolean off;

        Hum() {
            super(SoundEvents.BEACON_AMBIENT, SoundSource.BLOCKS, RandomSource.create());
            this.looping = true;
            this.delay = 0;
            this.volume = 0.12F;
            this.pitch = 1.5F;
            this.relative = true;
            this.attenuation = SoundInstance.Attenuation.NONE;
        }

        void turnOff() { off = true; stop(); }

        @Override
        public void tick() {
            if (off || !Sfx.hum() || Sfx.systemVol() <= 0F) { stop(); return; }
            this.volume = 0.12F * Sfx.systemVol();
        }
    }

    public static void startFan() {
        stopFan();
        if (!hum() || systemVol() <= 0F) return;
        fan = new Hum();
        Minecraft.getInstance().getSoundManager().play(fan);
    }

    /** Called every frame: starts the fan again if it was switched on in Settings (or off). */
    public static void keepFan() {
        if (fan == null || fan.isStopped()) {
            if (hum() && systemVol() > 0F) startFan();
        } else if (!hum()) {
            stopFan();
        }
    }

    public static void stopFan() {
        if (fan != null) fan.turnOff();
        fan = null;
    }
}
