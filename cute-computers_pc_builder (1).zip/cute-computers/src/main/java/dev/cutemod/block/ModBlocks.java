package dev.cutemod.block;

import dev.cutemod.ComputerColor;
import dev.cutemod.CuteMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.Map;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(CuteMod.MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CuteMod.MOD_ID);

    private static final Map<ComputerColor, DeferredBlock<ComputerBlock>> COMPUTERS = new EnumMap<>(ComputerColor.class);
    private static final Map<ComputerColor, DeferredItem<BlockItem>> COMPUTER_ITEMS = new EnumMap<>(ComputerColor.class);

    static {
        for (ComputerColor color : ComputerColor.values()) {
            DeferredBlock<ComputerBlock> block = BLOCKS.registerBlock(
                    color.blockName(),
                    props -> new ComputerBlock(props, color),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_PINK)
                            .strength(1.0F)
                            .sound(SoundType.METAL)
                            .noOcclusion());
            COMPUTERS.put(color, block);
            COMPUTER_ITEMS.put(color, ITEMS.registerSimpleBlockItem(block));
        }
    }

    private static final Map<LaptopModel, DeferredBlock<LaptopBlock>> LAPTOPS = new EnumMap<>(LaptopModel.class);

    static {
        for (LaptopModel model : LaptopModel.values()) {
            String name = model.blockName();
            DeferredBlock<LaptopBlock> block = BLOCKS.registerBlock(
                    name,
                    props -> new LaptopBlock(props, model),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_PINK)
                            .strength(1.0F)
                            .sound(SoundType.METAL)
                            .noOcclusion());
            LAPTOPS.put(model, block);
            ITEMS.registerItem(name, props -> new dev.cutemod.item.LaptopItem(block.get(), props), new net.minecraft.world.item.Item.Properties().stacksTo(1));
        }
    }

    private static final Map<Integer, DeferredBlock<RouterBlock>> ROUTERS = new java.util.LinkedHashMap<>();
    private static final Map<Integer, DeferredItem<BlockItem>> ROUTER_ITEMS = new java.util.LinkedHashMap<>();

    static {
        for (int lv = dev.cutemod.data.WifiNet.FIRST; lv <= dev.cutemod.data.WifiNet.LAST; lv++) {
            final int level = lv;
            DeferredBlock<RouterBlock> block = BLOCKS.registerBlock(
                    dev.cutemod.data.WifiNet.id(lv),
                    props -> new RouterBlock(props, level),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_PINK)
                            .strength(0.8F)
                            .sound(SoundType.METAL)
                            .noOcclusion());
            ROUTERS.put(lv, block);
            ROUTER_ITEMS.put(lv, ITEMS.registerSimpleBlockItem(block));
        }
    }

    /** The Wi-Fi router block of this level (1..5). */
    public static DeferredBlock<RouterBlock> getRouter(int level) { return ROUTERS.get(dev.cutemod.data.WifiNet.level(level)); }

    public static Iterable<DeferredBlock<RouterBlock>> allRouters() { return ROUTERS.values(); }

    /** One router item of this level (1..5). */
    public static net.minecraft.world.item.ItemStack routerStack(int level) {
        DeferredItem<BlockItem> it = ROUTER_ITEMS.get(level);
        return it == null ? net.minecraft.world.item.ItemStack.EMPTY : new net.minecraft.world.item.ItemStack(it.get());
    }

    // ---------- the build-it-yourself PC: a case (the parts go inside), a monitor, a keyboard and a mouse ----------
    /** The white glass tower. Empty when crafted: the parts are put in by hand (see {@link PcCaseBlock}). It glows a little when switched on. */
    public static final DeferredBlock<PcCaseBlock> PC_CASE = BLOCKS.registerBlock("pc_case", PcCaseBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(1.5F).sound(SoundType.METAL).noOcclusion()
                    .lightLevel(s -> s.getValue(PcCaseBlock.LIT) ? 7 : 0));
    public static final DeferredItem<BlockItem> PC_CASE_ITEM = ITEMS.registerSimpleBlockItem(PC_CASE);

    /** The monitor: its screen lights up when a full desk is around it (see {@link PcLink}). */
    public static final DeferredBlock<PcMonitorBlock> PC_MONITOR = BLOCKS.registerBlock("pc_monitor", PcMonitorBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(0.8F).sound(SoundType.METAL).noOcclusion()
                    .lightLevel(s -> s.getValue(PcMonitorBlock.ON) ? 5 : 0));
    public static final DeferredItem<BlockItem> PC_MONITOR_ITEM = ITEMS.registerSimpleBlockItem(PC_MONITOR);

    public static final DeferredBlock<PcPeripheralBlock> PC_KEYBOARD = BLOCKS.registerBlock("pc_keyboard",
            props -> new PcPeripheralBlock(props, PcPeripheralBlock.Kind.KEYBOARD),
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(0.3F).sound(SoundType.METAL).noOcclusion());
    public static final DeferredItem<BlockItem> PC_KEYBOARD_ITEM = ITEMS.registerSimpleBlockItem(PC_KEYBOARD);

    public static final DeferredBlock<PcPeripheralBlock> PC_MOUSE = BLOCKS.registerBlock("pc_mouse",
            props -> new PcPeripheralBlock(props, PcPeripheralBlock.Kind.MOUSE),
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(0.3F).sound(SoundType.METAL).noOcclusion());
    public static final DeferredItem<BlockItem> PC_MOUSE_ITEM = ITEMS.registerSimpleBlockItem(PC_MOUSE);

    public static DeferredBlock<LaptopBlock> getLaptop(LaptopModel model) {
        return LAPTOPS.get(model);
    }

    public static Iterable<DeferredBlock<LaptopBlock>> allLaptops() {
        return LAPTOPS.values();
    }

    public static DeferredBlock<ComputerBlock> get(ComputerColor color) {
        return COMPUTERS.get(color);
    }

    public static Iterable<DeferredBlock<ComputerBlock>> all() {
        return COMPUTERS.values();
    }

    private ModBlocks() {}
}
