package dev.cutemod.block;

import com.mojang.serialization.MapCodec;
import dev.cutemod.data.Build;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The PC case (a white glass tower with three glowing fans). It starts EMPTY: the parts are put in by hand, one after another,
 * and every one of them appears inside, behind the glass:
 * <ul>
 *   <li>right-click with a part: it goes in (see {@link dev.cutemod.item.PcPartItem#installInCase}); a part of the same kind
 *       that is already in is swapped for it and comes back as an item;</li>
 *   <li>sneak + right-click with an empty hand: the part that went in last comes out;</li>
 *   <li>right-click with an empty hand: the power button (needs a board, a processor, memory, a drive and a power supply).</li>
 * </ul>
 * What is inside is kept in {@link PcCaseBlockEntity} and mirrored in the properties below, which the blockstate turns into models.
 * A monitor, a keyboard and a mouse near it (see {@link PcLink}) make a working desk: the monitor opens the OS of this case.
 */
public class PcCaseBlock extends Block implements EntityBlock {
    public static final MapCodec<PcCaseBlock> CODEC = simpleCodec(PcCaseBlock::new);
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final BooleanProperty BOARD = BooleanProperty.create("board");
    public static final BooleanProperty CPU = BooleanProperty.create("cpu");
    public static final BooleanProperty PSU = BooleanProperty.create("psu");
    public static final BooleanProperty DISK = BooleanProperty.create("disk");
    public static final BooleanProperty NET = BooleanProperty.create("net");
    public static final BooleanProperty LIT = BlockStateProperties.LIT;
    /** 0 = no video card, 1..4 = the card of that level (every one looks different). */
    public static final IntegerProperty GPU = IntegerProperty.create("gpu", 0, 4);
    /** How many memory sticks are in. */
    public static final IntegerProperty RAM = IntegerProperty.create("ram", 0, Build.MAX_SLOTS);

    private static final VoxelShape[] SHAPES = new VoxelShape[4];
    static {
        for (int turn = 0; turn < 4; turn++) SHAPES[turn] = ComputerBlock.rotated(1.0, 0, 1.5, 15.0, 15.6, 15.0, turn);
    }

    public PcCaseBlock(BlockBehaviour.Properties props) {
        super(props);
        // a boolean property starts as TRUE unless it is set, so everything is set here: an empty, switched off case
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.SOUTH)
                .setValue(BOARD, false).setValue(CPU, false).setValue(PSU, false).setValue(DISK, false).setValue(NET, false)
                .setValue(LIT, false).setValue(GPU, 0).setValue(RAM, 0));
    }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, BOARD, CPU, PSU, DISK, NET, LIT, GPU, RAM);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());     // the glass looks at the player
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rot) { return state.setValue(FACING, rot.rotate(state.getValue(FACING))); }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) { return state.rotate(mirror.getRotation(state.getValue(FACING))); }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPES[ComputerBlock.turnsOf(state.getValue(FACING))];
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new PcCaseBlockEntity(pos, state); }

    /** A part goes in. */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player,
                                              InteractionHand hand, BlockHitResult hit) {
        if (stack.getItem() instanceof dev.cutemod.item.PcPartItem part) {
            if (!level.isClientSide && player instanceof ServerPlayer sp && level.getBlockEntity(pos) instanceof PcCaseBlockEntity be) {
                part.installInCase(sp, stack, be);
                PcLink.refreshMonitors(level, pos);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    /** Sneak: the last part comes out. Otherwise: the power button. */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.sidedSuccess(true);
        if (!(level.getBlockEntity(pos) instanceof PcCaseBlockEntity be) || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;

        if (player.isShiftKeyDown()) {
            ItemStack out = be.removeLast();
            if (out.isEmpty()) {
                sp.displayClientMessage(Component.translatable("cutemod.case.empty").withStyle(ChatFormatting.GRAY), true);
            } else {
                sp.displayClientMessage(Component.translatable("cutemod.case.removed", out.getHoverName()).withStyle(ChatFormatting.YELLOW), true);
                if (!sp.getInventory().add(out)) sp.drop(out, false);
                level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 0.8F, 0.8F);
            }
        } else if (be.isOn()) {
            be.setOn(false);
            sp.displayClientMessage(Component.translatable("cutemod.case.off").withStyle(ChatFormatting.GRAY), true);
            level.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 0.7F, 1.3F);
        } else if (!be.isComplete()) {
            MutableComponent list = Component.empty();
            var missing = be.missing();
            for (int i = 0; i < missing.size(); i++) {
                if (i > 0) list.append(", ");
                list.append(missing.get(i));
            }
            sp.displayClientMessage(Component.translatable("cutemod.case.missing", list).withStyle(ChatFormatting.GOLD), true);
            level.playSound(null, pos, SoundEvents.VILLAGER_NO, SoundSource.BLOCKS, 0.6F, 1.3F);
        } else {
            be.setOn(true);
            sp.displayClientMessage(Component.translatable("cutemod.case.on").withStyle(ChatFormatting.GREEN), true);
            level.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.BLOCKS, 0.7F, 1.5F);
            level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 0.8F, 1.6F);
            Build b = be.build();
            if (b.powerShort())
                sp.displayClientMessage(Component.translatable("cutemod.part.weakpsu", b.shortWatts()).withStyle(ChatFormatting.GOLD), false);
        }
        PcLink.refreshMonitors(level, pos);
        return InteractionResult.sidedSuccess(false);
    }

    /** A case that is broken drops everything that was inside (the case itself comes from the loot table). */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide && level.getBlockEntity(pos) instanceof PcCaseBlockEntity be) {
            for (ItemStack st : be.allParts()) Block.popResource(level, pos, st);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }
}
