package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * The "night mode" of the video site: when it is night in the Minecraft world (and Spooky is on) the site
 * turns into a bloody, pulsing page full of watching eyes, and the spooky videos appear in the list.
 * By day the site is the usual cute one and the spooky videos are hidden.
 */
public final class BloodSite {
    private BloodSite() {}

    /** Night in the world: from dusk (13000) to just before dawn (23000). */
    public static boolean night() {
        var level = Minecraft.getInstance().level;
        if (level == null) return false;
        long d = level.getDayTime() % 24000L;
        return d >= 13000L && d < 23000L;
    }

    /** True while the site should look (and behave) scary. */
    public static boolean on() { return Haunt.scary && night(); }

    private static int hash(int i) {
        int h = i * 0x9E3779B1;
        h ^= h >>> 15;
        h *= 0x85EBCA6B;
        h ^= h >>> 13;
        return h & 0x7FFFFFFF;
    }

    private static void fill(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + h, argb);
    }

    private static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            double q = 1.0 - (dy * (double) dy) / (ry * (double) ry);
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0, q)));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** A staring eye: a pale rim, a black socket and a pupil that follows the mouse. */
    private static void eye(GuiGraphics g, int cx, int cy, int rx, int ry, int mx, int my, boolean blink) {
        oval(g, cx, cy, rx, ry, 0xFFF4E6E0);
        oval(g, cx, cy, rx - 2, ry - 2, 0xFF120204);
        if (blink) return;
        double dx = mx - cx, dy = my - cy, len = Math.max(1, Math.sqrt(dx * dx + dy * dy));
        int px = cx + (int) Math.round(dx / len * Math.min(rx - 4, len / 8));
        int py = cy + (int) Math.round(dy / len * Math.min(ry - 4, len / 8));
        disc(g, px, py, Math.max(1, ry - 4), 0xFFB01010);
        fill(g, px - 1, py - 1, 1, 1, 0xFFFFFFFF);
    }

    /** Paints the animated bloody page into the rectangle (x, y, w, h). mx / my are in the same coordinates; sx / sy is where (x, y) is on the screen (for the scissor). */
    public static void paint(GuiGraphics g, int ticks, int x, int y, int w, int h, int mx, int my, int sx, int sy) {
        double pulse = 0.5 + 0.5 * Math.sin(ticks / 22.0);                       // the page breathes
        int top = rgb(0xD0 - (int) (pulse * 40), 0x70 - (int) (pulse * 40), 0x68 - (int) (pulse * 40));
        int bot = rgb(0x8A + (int) (pulse * 30), 0x0C, 0x10);
        g.fillGradient(x, y, x + w, y + h, top, bot);

        g.enableScissor(sx, sy, sx + w, sy + h);

        // flesh and blood blotches that slowly drift
        for (int i = 0; i < 34; i++) {
            int hh = hash(i + 1);
            int bx = x + (hh % w) + (int) Math.round(Math.sin((ticks + i * 17) / 70.0) * 3);
            int by = y + ((hh >> 8) % h) + (int) Math.round(Math.cos((ticks + i * 29) / 90.0) * 3);
            int r = 5 + (hh >> 16) % 13;
            disc(g, bx, by, r, (i & 1) == 0 ? 0x70480000 : 0x55FFB8B0);
            if (i % 3 == 0) disc(g, bx + 1, by + 1, Math.max(2, r / 2), 0x88300000);
        }

        // rows of small rimmed holes, like the skin of a lotus pod
        for (int i = 0; i < 70; i++) {
            int hh = hash(i + 200);
            int cx = x + w * 45 / 100 + (hh % (w * 52 / 100));
            int cy = y + 4 + ((hh >> 9) % (h - 8));
            boolean flash = (ticks / 14 + i) % 13 == 0;
            disc(g, cx, cy, 2, flash ? 0xFFFF4040 : 0xFFF2E4DC);
            disc(g, cx, cy, 1, 0xFF000000);
        }

        // the watching eyes
        for (int i = 0; i < 10; i++) {
            int hh = hash(i + 500);
            int cx = x + 14 + (hh % (w - 28)) + (int) Math.round(Math.sin((ticks + i * 41) / 80.0) * 4);
            int cy = y + 12 + ((hh >> 8) % (h - 24)) + (int) Math.round(Math.cos((ticks + i * 23) / 100.0) * 3);
            int rx = 7 + (hh >> 17) % 5;
            boolean blink = (ticks + i * 37) % 160 < 6;
            eye(g, cx, cy, rx, rx * 2 / 3 + 1, mx, my, blink);
        }

        // dripping from the top edge
        for (int i = 0; i < 12; i++) {
            int hh = hash(i + 900);
            int dx = x + 6 + (hh % (w - 12));
            int len = 6 + (hh >> 8) % 18 + (int) (((ticks / 3 + i * 11) % 60) * 0.25);
            fill(g, dx, y, 2, len, 0xFF7A0808);
            disc(g, dx, y + len, 2, 0xFF7A0808);
        }

        // rare glitch: a torn strip of the picture
        int f = ticks % 170;
        if (f < 4) {
            int gy = y + hash(ticks / 170) % Math.max(1, h - 12);
            fill(g, x, gy, w, 3 + f * 2, 0x66000000);
            fill(g, x + (f * 9) % 30, gy + 1, w, 1, 0x88FF2020);
        }
        // grain
        for (int k = 0; k < 8; k++) {
            fill(g, x + (ticks * 13 + k * 37) % w, y + (ticks * 7 + k * 11) % h, 24, 1, 0x30FFFFFF);
        }
        // dark vignette, so the corners feel closer
        fill(g, x, y, w, 2, 0x66000000);
        fill(g, x, y + h - 2, w, 2, 0x66000000);
        fill(g, x, y, 2, h, 0x55000000);
        fill(g, x + w - 2, y, 2, h, 0x55000000);
        g.disableScissor();
    }

    private static int rgb(int r, int gg, int b) {
        return 0xFF000000 | (Math.max(0, Math.min(255, r)) << 16) | (Math.max(0, Math.min(255, gg)) << 8) | Math.max(0, Math.min(255, b));
    }
}
