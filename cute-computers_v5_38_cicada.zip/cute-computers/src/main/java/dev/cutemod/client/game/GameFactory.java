package dev.cutemod.client.game;

import dev.cutemod.ComputerColor;

public class GameFactory {
    public static MiniGame create(ComputerColor color) {
        return switch (color) {
            case PINK -> new FlappyCat();
            case GREEN -> new Minesweeper();
            case WHITE -> new PandaSnake();
            case BLUE -> new PenguinFishing();
            case ORANGE -> new FoxMemory();
            case PURPLE -> new EnderDodge();
            case YELLOW -> new WhackBee();
            case RED -> new LadybugMatch();
        };
    }

    /** Games that are not tied to a computer color (only playable from the Games folder). */
    public static MiniGame createExtra(String id) {
        return switch (id) {
            case "breakout" -> new CookieBreaker();
            case "pong" -> new SlimePong();
            case "bees" -> new BeeInvaders();
            case "horror" -> new DarkCandles();
            case "craft" -> new MiniCraft();
            case "durak" -> new Durak();
            case "sakura" -> new SakuraCatch();
            case "blocks" -> new CuteBlocks();
            case "cakes" -> new CakeBakery();
            case "cakefactory" -> new CakeFactory();
            case "racer" -> new CuteRacer();
            case "checkers" -> new Checkers();
            case "slice" -> new MelonSlice();
            case "rabbit" -> new RabbitRoad();
            case "dash" -> new KittyDash();
            case "tower" -> new StackTower();
            case "hangman" -> new Hangman();
            case "billiards" -> new Billiards();
            case "bomber" -> new Bomber();
            case "hive" -> new Hive();
            case "mayhem" -> new Mayhem();
            case "funnyfarm" -> new FunnyFarm();
            case "fighters" -> new Fighters();
            case "birds" -> new BirdSling();
            case "cicada" -> new Cicada();
            default -> new MergeCubes();
        };
    }

    private GameFactory() {}
}
