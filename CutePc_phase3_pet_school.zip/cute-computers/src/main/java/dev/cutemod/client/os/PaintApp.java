package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Pixel paint. The pictures stay while the game is running. Besides a single picture (for the mail) it makes small
 * animations: up to 12 frames of 64 x 36, shown with the previous frame faintly under the one you draw (onion skin),
 * played back at 4 / 6 / 8 / 12 frames per second, and published to CuteTube for the other players.
 */
public class PaintApp extends App {
    private static final int GW = 64, GH = 36, CS = 4;
    private static final int OX = 4, OY = (H - GH * CS) / 2;
    private static final int PX = OX + GW * CS + 4;
    static final int[] PALETTE = {
            0xFF3A2A3A, 0xFFFFFFFF, 0xFFE5484D, 0xFFF58FB8, 0xFFF5A623, 0xFFF3D46A, 0xFF8FD39A,
            0xFF2E9E5B, 0xFF8EC3F2, 0xFF2F7FD6, 0xFFB57BD6, 0xFF6B4A2B, 0xFFB0A8B8, 0xFF4A3A66};
    static final int MAX_FRAMES = 12;
    private static final int[] FPS = {4, 6, 8, 12};
    private static final int MAX_TITLE = 24;

    private static final int[][] FRAMES = new int[MAX_FRAMES][GW * GH]; // 0 = empty
    private static int frameCount = 1, cur = 0;
    /** The frame that is being edited (the mail and the story use it as "the picture"). */
    private static int[] PIXELS = FRAMES[0];
    private static int fps = 6, tune = 0;
    private static String title = "";

    private int selected = 0;
    private int lastX = -1, lastY = -1;
    private boolean playing, pubOpen;
    private int playT;

    // the strip above the canvas (y 0..9) and the buttons under the palette
    private static final int TOP_H = 10, PUB_X = 190, PUB_W = 104;
    private static final int NAV1 = swY(PALETTE.length - 1) + 18 + 16, NAV2 = NAV1 + 12;

    /** Does the canvas have anything on it? */
    public static boolean hasPicture() {
        for (int c : PIXELS) if (c != 0) return true;
        return false;
    }

    /** The picture packed for the mail: two pixels per byte, 0 = empty, 1..14 = palette colour. */
    public static byte[] snapshot() { return pack(PIXELS); }

    private static byte[] pack(int[] px) {
        byte[] out = new byte[GW * GH / 2];
        for (int i = 0; i < px.length; i++) {
            int idx = 0;
            for (int k = 0; k < PALETTE.length; k++) if (PALETTE[k] == px[i]) { idx = k + 1; break; }
            out[i / 2] |= (byte) ((i % 2 == 0) ? idx << 4 : idx);
        }
        return out;
    }

    /** Draws a packed picture (see snapshot) with every pixel scale x scale, or step-sampled when scale is 1 and step is 2. */
    public static void drawPacked(GuiGraphics g, byte[] d, int x, int y, int scale, int step) {
        if (d.length != GW * GH / 2) return;
        rect(g, x - 1, y - 1, GW / step * scale + 2, GH / step * scale + 2, 0xFF3A2A3A);
        rect(g, x, y, GW / step * scale, GH / step * scale, 0xFFFFFFFF);
        for (int py = 0; py < GH; py += step) {
            for (int px = 0; px < GW; px += step) {
                int i = py * GW + px;
                int idx = (i % 2 == 0) ? (d[i / 2] >> 4) & 15 : d[i / 2] & 15;
                if (idx > 0 && idx <= PALETTE.length) rect(g, x + px / step * scale, y + py / step * scale, scale, scale, PALETTE[idx - 1]);
            }
        }
    }

    // ---------- frames ----------
    private static void select(int i) {
        cur = Math.max(0, Math.min(frameCount - 1, i));
        PIXELS = FRAMES[cur];
    }

    /** A copy of this frame goes right after it (it is easier to animate from a copy). */
    private static void addFrame() {
        if (frameCount >= MAX_FRAMES) return;
        int[] fresh = FRAMES[frameCount];
        for (int i = frameCount; i > cur + 1; i--) FRAMES[i] = FRAMES[i - 1];
        FRAMES[cur + 1] = fresh;
        System.arraycopy(FRAMES[cur], 0, fresh, 0, fresh.length);
        frameCount++;
        select(cur + 1);
    }

    private static void deleteFrame() {
        if (frameCount <= 1) return;
        int[] gone = FRAMES[cur];
        for (int i = cur; i < frameCount - 1; i++) FRAMES[i] = FRAMES[i + 1];
        FRAMES[frameCount - 1] = gone;
        Arrays.fill(gone, 0);
        frameCount--;
        select(Math.min(cur, frameCount - 1));
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.paint"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.paint"); }

    @Override
    public void tick() { if (playing) playT++; }

    @Override
    public boolean busy() { return pubOpen; }

    private static int swX(int i) { return PX + (i % 2) * 16; }

    private static int swY(int i) { return OY + (i / 2) * 16; }

    private void mini(GuiGraphics g, int mx, int my, int x, int y, int w, int h, String s, boolean on) {
        boolean hover = on && in(mx, my, x, y, w, h);
        rect(g, x, y, w, h, on ? (hover ? 0xFFFFFFFF : 0xFFF6F0FA) : 0xFFD8CFE0);
        CuteFont.draw(g, font(), s, x + (w - font().width(s)) / 2, y + (h - 8) / 2, on ? 0xFF3A2A3A : 0xFF9A8FA8, false);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        rect(g, 0, 0, W, H, 0xFFE9DDF2);

        // the strip above the canvas: frame number, delete, speed, publish
        CuteFont.draw(g, font(), t("cutemod.os.paint.frame", cur + 1, frameCount), OX, 1, 0xFF3A2A3A, false);
        mini(g, mx, my, 66, 0, 10, TOP_H, "-", frameCount > 1);
        mini(g, mx, my, 80, 0, 34, TOP_H, t("cutemod.os.paint.fps", fps), true);
        if (frameCount >= 2) mini(g, mx, my, PUB_X, 0, PUB_W, TOP_H, t("cutemod.os.paint.publish"), true);
        else CuteFont.draw(g, font(), t("cutemod.os.paint.tip"), 120, 1, 0xFF8A7AA8, false);

        // the canvas
        rect(g, OX - 1, OY - 1, GW * CS + 2, GH * CS + 2, 0xFF3A2A3A);
        rect(g, OX, OY, GW * CS, GH * CS, 0xFFFFFFFF);
        int[] show = playing ? FRAMES[(playT * fps / 60) % frameCount] : PIXELS;
        if (!playing && cur > 0) {                                           // onion skin: the frame before, faint
            int[] prev = FRAMES[cur - 1];
            for (int y = 0; y < GH; y++) {
                for (int x = 0; x < GW; x++) {
                    int i = y * GW + x;
                    if (prev[i] != 0 && PIXELS[i] == 0) rect(g, OX + x * CS, OY + y * CS, CS, CS, (prev[i] & 0x00FFFFFF) | 0x55000000);
                }
            }
        }
        for (int y = 0; y < GH; y++) {
            for (int x = 0; x < GW; x++) {
                int c = show[y * GW + x];
                if (c != 0) rect(g, OX + x * CS, OY + y * CS, CS, CS, c);
            }
        }
        if (!playing && Haunt.scary && Progress.questDone() && Progress.step3() >= 1) {   // part 3: somebody copies your picture, mirrored and dark
            for (int y = 0; y < GH; y++) {
                for (int x = 0; x < GW; x++) {
                    if (PIXELS[y * GW + x] != 0 && PIXELS[y * GW + (GW - 1 - x)] == 0) {
                        rect(g, OX + (GW - 1 - x) * CS, OY + y * CS, CS, CS, 0x552A1A3A);
                    }
                }
            }
        }

        // the palette and the buttons
        for (int i = 0; i < PALETTE.length; i++) {
            int x = swX(i), y = swY(i);
            rect(g, x - 1, y - 1, 15, 15, i == selected ? 0xFFFFFFFF : 0xFF3A2A3A);
            if (i == selected) rect(g, x, y, 13, 13, 0xFF3A2A3A);
            rect(g, x + (i == selected ? 1 : 0), y + (i == selected ? 1 : 0),
                    13 - (i == selected ? 2 : 0), 13 - (i == selected ? 2 : 0), PALETTE[i]);
        }
        int by = swY(PALETTE.length - 1) + 18;
        boolean hover = in(mx, my, PX, by, 32, 14);
        rect(g, PX, by, 32, 14, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
        String s = t("cutemod.os.paint.clear");
        CuteFont.draw(g, font(), s, PX + (32 - font().width(s)) / 2, by + 3, 0xFF3A2A3A, false);

        mini(g, mx, my, PX, NAV1, 15, 11, "<", cur > 0);
        mini(g, mx, my, PX + 17, NAV1, 15, 11, ">", cur < frameCount - 1);
        mini(g, mx, my, PX, NAV2, 15, 11, "+", frameCount < MAX_FRAMES);
        mini(g, mx, my, PX + 17, NAV2, 15, 11, "", frameCount > 1);
        int ix = PX + 17;
        if (playing) {
            rect(g, ix + 5, NAV2 + 2, 2, 7, 0xFF3A2A3A);
            rect(g, ix + 9, NAV2 + 2, 2, 7, 0xFF3A2A3A);
        } else {
            for (int k = 0; k < 4; k++) rect(g, ix + 5 + k, NAV2 + 2 + k, 1, 7 - 2 * k, frameCount > 1 ? 0xFF3A2A3A : 0xFF9A8FA8);
        }

        if (pubOpen) renderPublish(g, mx, my);
    }

    // ---------- the publish window ----------
    private static final int WX = 48, WY = 34, WW = 204, WH = 96;

    private void renderPublish(GuiGraphics g, int mx, int my) {
        rect(g, 0, 0, W, H, 0x99000000);
        rect(g, WX - 1, WY - 1, WW + 2, WH + 2, 0xFF3A2A3A);
        rect(g, WX, WY, WW, WH, 0xFFF6F0FA);
        CuteFont.draw(g, font(), t("cutemod.os.paint.pub.title"), WX + 8, WY + 6, 0xFF3A2A3A, false);
        rect(g, WX + 8, WY + 17, 188, 14, 0xFF4A7BD0);
        rect(g, WX + 9, WY + 18, 186, 12, 0xFFFFFFFF);
        String shown = title;
        CuteFont.draw(g, font(), shown, WX + 12, WY + 20, 0xFF3A2A3A, false);
        if ((System.currentTimeMillis() / 500) % 2 == 0) rect(g, WX + 12 + font().width(shown), WY + 20, 1, 9, 0xFF3A2A3A);
        CuteFont.draw(g, font(), t("cutemod.os.paint.pub.tune"), WX + 8, WY + 36, 0xFF8A7AA8, false);
        for (int i = 0; i < 4; i++) {
            int x = WX + 8 + i * 48, y = WY + 47;
            boolean sel = i == tune;
            rect(g, x, y, 46, 14, sel ? 0xFF3A2A3A : in(mx, my, x, y, 46, 14) ? 0xFFFFFFFF : 0xFFE9DDF2);
            String n = t("cutemod.tube.tune." + i);
            CuteFont.draw(g, font(), n, x + (46 - font().width(n)) / 2, y + 3, sel ? 0xFFFFFFFF : 0xFF3A2A3A, false);
        }
        CuteFont.draw(g, font(), t("cutemod.os.paint.pub.info", frameCount, fps), WX + 8, WY + 66, 0xFF8A7AA8, false);
        boolean ok = !title.trim().isEmpty();
        mini(g, mx, my, WX + 8, WY + 78, 90, 14, t("cutemod.os.paint.pub.ok"), ok);
        mini(g, mx, my, WX + 104, WY + 78, 60, 14, t("cutemod.os.paint.pub.cancel"), true);
    }

    private boolean publishClick(int x, int y) {
        for (int i = 0; i < 4; i++) {
            if (in(x, y, WX + 8 + i * 48, WY + 47, 46, 14)) { tune = i; MusicApp.note(0, 8 + i * 3, 0.7F); return true; }
        }
        if (in(x, y, WX + 8, WY + 78, 90, 14)) { publish(); return true; }
        if (in(x, y, WX + 104, WY + 78, 60, 14) || !in(x, y, WX, WY, WW, WH)) pubOpen = false;
        return true;
    }

    private void publish() {
        String name = title.trim();
        if (name.isEmpty() || frameCount < 2) return;
        List<byte[]> frames = new ArrayList<>();
        for (int i = 0; i < frameCount; i++) frames.add(pack(FRAMES[i]));
        TubeNet.publish(name, fps, tune, frames);
        pubOpen = false;
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (pubOpen) return publishClick(x, y);
        if (y < TOP_H) {
            if (frameCount > 1 && in(x, y, 66, 0, 10, TOP_H)) { playing = false; deleteFrame(); }
            else if (in(x, y, 80, 0, 34, TOP_H)) {
                int k = 0;
                for (int i = 0; i < FPS.length; i++) if (FPS[i] == fps) k = i;
                fps = FPS[(k + 1) % FPS.length];
            } else if (frameCount >= 2 && in(x, y, PUB_X, 0, PUB_W, TOP_H)) { playing = false; pubOpen = true; }
            return true;
        }
        for (int i = 0; i < PALETTE.length; i++) {
            if (in(x, y, swX(i), swY(i), 14, 14)) { selected = i; return true; }
        }
        int by = swY(PALETTE.length - 1) + 18;
        if (in(x, y, PX, by, 32, 14)) { Arrays.fill(PIXELS, 0); return true; }          // clears this frame only
        if (in(x, y, PX, NAV1, 15, 11)) { playing = false; select(cur - 1); return true; }
        if (in(x, y, PX + 17, NAV1, 15, 11)) { playing = false; select(cur + 1); return true; }
        if (in(x, y, PX, NAV2, 15, 11)) { playing = false; addFrame(); return true; }
        if (in(x, y, PX + 17, NAV2, 15, 11)) { if (frameCount > 1) { playing = !playing; playT = 0; } return true; }
        if (playing) { playing = false; return true; }                                   // a click on the canvas stops the preview first
        lastX = -1;
        paint(x, y, button);
        return true;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (pubOpen || playing) return true;
        paint(x, y, button);
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (!pubOpen) return false;
        switch (keyCode) {
            case 256 -> pubOpen = false;                                                 // escape
            case 257, 335 -> publish();                                                  // enter
            case 259 -> { if (!title.isEmpty()) title = title.substring(0, title.length() - 1); }
            case 86 -> {                                                                 // ctrl+v
                if (Screen.hasControlDown()) {
                    String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                    if (clip != null) {
                        String c = (title + clip.replace("\n", " ").replace("\r", "")).trim();
                        title = c.length() > MAX_TITLE ? c.substring(0, MAX_TITLE) : c;
                    }
                }
            }
            default -> { }
        }
        return true;                                                                     // the window takes every key
    }

    @Override
    public boolean charTyped(char c) {
        if (!pubOpen) return false;
        if (c >= 32 && c != 127 && title.length() < MAX_TITLE) title += c;
        return true;
    }

    private void paint(int x, int y, int button) {
        int cx = Math.floorDiv(x - OX, CS), cy = Math.floorDiv(y - OY, CS);
        if (cx < 0 || cy < 0 || cx >= GW || cy >= GH) { lastX = -1; return; }
        int val = button == 1 ? 0 : PALETTE[selected];
        if (lastX < 0) {
            PIXELS[cy * GW + cx] = val;
        } else {
            int dx = cx - lastX, dy = cy - lastY, n = Math.max(Math.abs(dx), Math.abs(dy));
            for (int i = 0; i <= n; i++) {
                int px = n == 0 ? cx : lastX + Math.round((float) dx * i / n);
                int py = n == 0 ? cy : lastY + Math.round((float) dy * i / n);
                if (px >= 0 && py >= 0 && px < GW && py < GH) PIXELS[py * GW + px] = val;
            }
        }
        lastX = cx;
        lastY = cy;
        if (Progress.step() == 10) { // story, part 2: count the painted pixels
            int n = 0;
            for (int px : PIXELS) if (px != 0) n++;
            Progress.onPaint(n);
        }
        if (Haunt.scary && Progress.questDone() && Progress.step3() == 1) { // story, part 3: the same
            int n = 0;
            for (int px : PIXELS) if (px != 0) n++;
            Progress.onPaint3(n);
        }
    }
}
