package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * The pictures of the fairy tale book, drawn with rectangles and discs (no image files). A picture is a text:
 * {@code "day;sun@100,12;tree@14,56;swan@60,58,130"}: the first word is the background, then the things, back to front.
 * A thing is {@code name@x,y} or {@code name@x,y,size} (size in percent). Its (x, y) is where it stands, bottom centre.
 * A name ending with "&lt;" looks to the left. The picture is {@link #W} x {@link #H}; the ground is at {@link #GROUND}.
 * <p>
 * How it is made: everything is painted into a small pixel buffer first and only then sent to the screen as runs of one colour.
 * That lets every character and object get a dark outline in the colour of its own surface, a light rim on the top and the left,
 * a shade on the bottom and the right and a soft shadow on the ground, and lets the whole picture get a soft vignette: it looks like
 * hand-made pixel art although the figures are written as a few rectangles each.
 */
public final class BookArt {
    private BookArt() {}

    public static final int W = 120, H = 74, GROUND = 54;

    private static final int SKIN = 0xFFFFDDBF, SKIN_D = 0xFFEDB78F, INK = 0xFF3A2A3A, GOLD = 0xFFFFC832, WHITE = 0xFFFFFFFF, OUT = 0xFF2A1A34;

    // ---------- the buffers ----------
    private static final int PW = 168, PH = 136, FOOT = 14;        // the largest area of a thing drawn alone (a cover, the hero on a title page): its feet are FOOT above the bottom
    private static final int[] SCENE = new int[W * H];             // the picture
    private static final int[] LAYER = new int[Math.max(W * H, PW * PH)];   // the thing that is being drawn
    private static final int[] PROC = new int[Math.max(W * H, PW * PH)];    // the same with its outline and shading
    private static int[] T = SCENE;                                // where r() paints now
    private static int tw = W, th = H;
    private static float ox, oy, sc = 1F;                          // the transform of the thing being drawn
    private static boolean inScene;
    private static long clock;                    // real time (ms) of the picture being drawn: it moves only inside a scene
    private static int seed;                      // a number of the thing being drawn, so that two of a kind do not move in step

    /** Animation time, 60 steps a second; 0 when the thing is drawn outside a scene (a cover on the shelf stays still). */
    private static float tm() { return inScene ? (clock % 3_600_000L) / 16.667F : 0F; }

    private static int al(int a, int rgb) { return Math.max(0, Math.min(255, a)) << 24 | (rgb & 0xFFFFFF); }

    private static boolean blink() { return inScene && (clock + seed * 377L) % 3300L < 150L; }

    private static int hash(int n) {
        n ^= n >>> 15; n *= 0x2C1B3C6D; n ^= n >>> 12; n *= 0x297A2D39; n ^= n >>> 15;
        return n & 0x7FFFFFFF;
    }

    // ---------- tiny drawing helpers ----------
    private static void put(int x, int y, int c) {
        if (x < 0 || y < 0 || x >= tw || y >= th) return;
        int a = c >>> 24;
        if (a == 0) return;
        int i = y * tw + x;
        if (a == 255) { T[i] = c; return; }
        int d = T[i], da = d >>> 24;
        if (da == 0) { T[i] = c; return; }
        int inv = 255 - a;
        int rr = ((c >> 16 & 255) * a + (d >> 16 & 255) * inv) / 255, gg = ((c >> 8 & 255) * a + (d >> 8 & 255) * inv) / 255, bb = ((c & 255) * a + (d & 255) * inv) / 255;
        T[i] = Math.max(a, da) << 24 | rr << 16 | gg << 8 | bb;
    }

    private static void r(int x, int y, int w, int h, int c) {
        int x0 = Math.round(ox + x * sc), y0 = Math.round(oy + y * sc), x1 = Math.round(ox + (x + w) * sc), y1 = Math.round(oy + (y + h) * sc);
        if (w > 0 && x1 <= x0) x1 = x0 + 1;                    // a thin line stays visible when the thing is small
        if (h > 0 && y1 <= y0) y1 = y0 + 1;
        x0 = Math.max(x0, 0); y0 = Math.max(y0, 0); x1 = Math.min(x1, tw); y1 = Math.min(y1, th);
        for (int yy = y0; yy < y1; yy++) for (int xx = x0; xx < x1; xx++) put(xx, yy, c);
    }

    private static void d(int cx, int cy, int rad, int c) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            r(cx - dx, cy + dy, dx * 2 + 1, 1, c);
        }
    }

    private static void e(int cx, int cy, int rx, int ry, int c) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0, 1.0 - (double) dy * dy / (ry * ry + 0.25))));
            r(cx - dx, cy + dy, dx * 2 + 1, 1, c);
        }
    }

    /** A triangle with its tip up: x, y = top left of its box. */
    private static void tri(int x, int y, int w, int h, int c) {
        for (int i = 0; i < h; i++) {
            int ww = Math.max(1, w * (i + 1) / h);
            r(x + (w - ww) / 2, y + i, ww, 1, c);
        }
    }

    private static int mix(int a, int b, float t) {
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
        return 0xFF000000 | (int) (ar + (br - ar) * t) << 16 | (int) (ag + (bg - ag) * t) << 8 | (int) (ab + (bb - ab) * t);
    }

    private static int lighten(int c, float t) { return mix(c, WHITE, t); }

    private static int darken(int c, float t) { return mix(c, 0xFF000000, t); }

    /** A round shape with a light on the top left: a dark rim on the bottom right, the colour, a bright spot. */
    private static void ball(int cx, int cy, int rad, int c) {
        d(cx, cy, rad, darken(c, 0.28F));
        d(cx - 1, cy - 1, Math.max(1, rad - 1), c);
        if (rad >= 3) d(cx - rad / 3 - 1, cy - rad / 3 - 1, Math.max(1, rad / 3), lighten(c, 0.35F));
    }

    private static void grad(int x, int y, int w, int h, int top, int bot) {
        for (int i = 0; i < h; i++) r(x, y + i, w, 1, mix(top, bot, h <= 1 ? 0 : i / (float) (h - 1)));
    }

    private static int palette(int[] cols, float t) {
        if (cols.length == 1) return cols[0];
        float s = t * (cols.length - 1);
        int k = Math.min(cols.length - 2, (int) s);
        return mix(cols[k], cols[k + 1], s - k);
    }

    /** nb hard bands of colour from the palette (top to bottom); where two bands meet a row of checker dither blends them. */
    private static void bands(int y0, int y1, int nb, int... cols) {
        int h = y1 - y0, prev = 0;
        for (int i = 0; i < nb; i++) {
            int ya = y0 + h * i / nb, yb = y0 + h * (i + 1) / nb, c = palette(cols, (i + 0.5F) / nb);
            for (int y = ya; y < yb; y++) {
                if (y == ya && i > 0) for (int x = 0; x < W; x += 2) r(x, y, 2, 1, (((x >> 1) + y) & 1) == 0 ? prev : c);
                else r(0, y, W, 1, c);
            }
            prev = c;
        }
    }

    /** A silhouette of hills or mountains: a curve made of two waves, filled down to "bottom", with a light rim on top. */
    private static void ridge(int base, float amp, float f1, float f2, float ph, int col, int rim, int bottom) {
        for (int x = 0; x < W; x++) {
            int y = base - Math.round(amp * (0.6F * (float) Math.sin(x * f1 + ph) + 0.4F * (float) Math.sin(x * f2 + ph * 2.3F)));
            r(x, y, 1, bottom - y, col);
            if (rim != 0) r(x, y, 1, 1, rim);
        }
    }

    /** Tufts of grass (or any speckle): small two-pixel strokes, light and dark, spread over a band of the picture. */
    private static void tufts(int y0, int y1, int n, int light, int dark, int salt) {
        for (int i = 0; i < n; i++) {
            int hv = hash(i * 911 + salt);
            int x = hv % W, y = y0 + 1 + (hv >> 8) % Math.max(1, y1 - y0 - 1);
            r(x, y - 1, 1, 2, (i & 1) == 0 ? light : dark);
            if ((hv >> 17 & 3) == 0) r(x + 1, y, 1, 1, light);
        }
    }

    private static void sprinkle(int y0, int y1, int n, int salt, int... cols) {
        for (int i = 0; i < n; i++) {
            int hv = hash(i * 577 + salt);
            r(hv % W, y0 + (hv >> 8) % Math.max(1, y1 - y0), 1, 1, cols[(hv >> 16) % cols.length]);
        }
    }

    // ---------- looking left or right: the animals are written looking right ----------
    private static void fr(int f, int x, int y, int w, int h, int c) { r(f > 0 ? x : -x - w, y, w, h, c); }

    private static void fd(int f, int cx, int cy, int rad, int c) { d(f * cx, cy, rad, c); }

    private static void fe(int f, int cx, int cy, int rx, int ry, int c) { e(f * cx, cy, rx, ry, c); }

    private static void ftri(int f, int x, int y, int w, int h, int c) { tri(f > 0 ? x : -x - w, y, w, h, c); }

    /** Smoke from a chimney: four puffs that rise, drift, grow and fade. (x, y) = the top of the chimney. */
    private static void smoke(int x, int y) {
        float tt = tm();
        for (int k = 0; k < 4; k++) {
            float p = (tt * 0.012F + k * 0.25F) % 1F;
            int px = x + Math.round(p * 7F + (float) Math.sin(tt * 0.03 + k * 2) * 1.5F), py = y - Math.round(p * 20F);
            d(px, py, 1 + Math.round(p * 2.4F), al(Math.round(150 * (1F - p)), 0xE8E8EE));
        }
    }

    // ---------- backgrounds ----------
    private static void background(String bg) {
        float tt = tm();
        switch (bg) {
            case "dusk" -> {
                bands(0, GROUND, 11, 0xFF4B3C8C, 0xFFB8587F, 0xFFFF8F7E, 0xFFFFD2A0);
                for (int k = 0; k < 5; k++) e(86, 46, 30 - k * 5, 15 - k * 2, al(15, 0xFFC890));      // the low sun spreads its glow
                sprinkle(0, 16, 8, 3, 0xAAFFE8C0, 0x66FFFFFF);
                ridge(43, 7, 0.07F, 0.19F, 2.2F, 0xFF8B5E94, 0xFFB67AA4, GROUND);
                ridge(48, 5, 0.11F, 0.27F, 0.7F, 0xFF5E4A7E, 0xFF7E6296, GROUND);
                bands(GROUND, H, 5, 0xFF3F7C58, 0xFF2D6148, 0xFF234E3E);
                r(0, GROUND, W, 1, 0xFFF0B070);
                tufts(GROUND, H, 45, 0xFF9A9860, 0xFF1F4A38, 11);
            }
            case "night" -> {
                bands(0, GROUND, 11, 0xFF080C26, 0xFF1A2558, 0xFF34478C);
                int[] st = {6, 8, 22, 18, 40, 6, 58, 20, 76, 9, 92, 24, 110, 12, 14, 34, 66, 36, 104, 38, 30, 28, 84, 4};
                for (int i = 0; i < st.length; i += 2) r(st[i], st[i + 1], 1, 1, inScene ? al(110 + (int) (145 * Math.abs(Math.sin(tt * 0.04 + i))), 0xFFF3B0) : 0xFFFFF3B0);
                ridge(43, 7, 0.07F, 0.19F, 1.9F, 0xFF1F2B5E, 0xFF34447E, GROUND);
                ridge(48, 5, 0.11F, 0.27F, 4.1F, 0xFF16204A, 0xFF283A70, GROUND);
                bands(GROUND, H, 5, 0xFF2A5448, 0xFF1D3F3A, 0xFF152F2E);
                r(0, GROUND, W, 1, 0xFF4E7E78);
                tufts(GROUND, H, 60, 0xFF3E6E60, 0xFF102624, 21);
                for (int i = 0; i < 6; i++) {                                                           // fireflies
                    int hv = hash(i * 131 + 7);
                    int fx = hv % W + (int) Math.round(Math.sin(tt * 0.02 + i * 2) * 4), fy = GROUND - 6 + (hv >> 8) % 24 + (int) Math.round(Math.cos(tt * 0.017 + i) * 3);
                    int a = inScene ? 100 + (int) (155 * Math.abs(Math.sin(tt * 0.03 + i * 1.7))) : 200;
                    d(fx, fy, 2, al(a / 5, 0xFFF0A0)); r(fx, fy, 1, 1, al(a, 0xFFF4B0));
                }
            }
            case "sea" -> {
                bands(0, 31, 7, 0xFF64BEFF, 0xFFAFE2FF, 0xFFE2F6FF);
                e(24, 24, 14, 2, al(170, WHITE)); e(30, 22, 8, 2, al(200, WHITE)); e(90, 19, 12, 2, al(170, WHITE)); e(84, 17, 6, 2, al(200, WHITE));
                bands(31, H, 12, 0xFF58B8F0, 0xFF2F86CC, 0xFF1C5CA6, 0xFF15407E);
                r(0, 31, W, 1, al(210, WHITE));
                int sh = (int) (tt * 0.06F) % 12;                                                       // the waves run along the sea
                for (int y = 35; y < H; y += 7) {
                    int dir = y / 7 % 2 == 0 ? 1 : -1;
                    for (int x = (y / 7 % 2) * 6 - 12 + Math.floorMod(dir * sh, 12); x < W; x += 12) { r(x, y, 6, 1, al(72, WHITE)); r(x + 1, y + 1, 4, 1, al(30, 0xFF0A2A5A)); }
                }
                for (int i = 0; i < 16; i++) {                                                          // glints of the sun
                    int hv = hash(i * 313 + 5);
                    if (!inScene || Math.sin(tt * 0.05 + i * 1.9) > 0.4) r(hv % W, 34 + (hv >> 8) % (H - 36), 2, 1, al(190, WHITE));
                }
            }
            case "deep" -> {
                bands(0, 60, 11, 0xFF5CC2F2, 0xFF2B86C8, 0xFF16529A, 0xFF0C2F6A);
                for (int k = 0; k < 4; k++) {                                                           // slanting beams of light, slowly swaying
                    int x0 = 6 + k * 32 + (inScene ? (int) Math.round(Math.sin(tt * 0.012 + k * 1.7) * 5) : 0);
                    for (int y = 0; y < 60; y++) r(x0 + y * 4 / 10, y, 6 + y / 10, 1, al(Math.max(0, 22 - y / 3), 0xFFFFFF));
                }
                for (int i = 0; i < 3; i++) e(16 + i * 40, 36 + (i * 7) % 12, 4, 2, al(34, 0xFF0A2A5A));   // far fish
                bands(60, H, 4, 0xFFF3DB9C, 0xFFE2C686, 0xFFCAA96E);
                r(0, 60, W, 1, 0xFFFFF0C0);
                for (int i = 0; i < 24; i++) {
                    int hv = hash(i * 271 + 9);
                    if (i % 3 == 0) r(hv % W, 62 + (hv >> 8) % 11, 4, 1, al(60, 0xFF8A6A30));
                    else r(hv % W, 62 + (hv >> 8) % 11, 1, 1, i % 3 == 1 ? 0xFFFFF4D0 : 0xFFB89050);
                }
            }
            case "forest" -> {
                bands(0, GROUND + 2, 10, 0xFF2D6A48, 0xFF72B67E, 0xFFBEE8AE);
                for (int i = 0; i < 9; i++) {                                                           // pale trees far away in the mist
                    int x = 2 + i * 15 + (i % 2) * 3;
                    r(x, 6, 3, GROUND - 6, 0xFF6C9C74); r(x, 6, 1, GROUND - 6, 0xFF86B28C);
                    ball(x + 1, 8 + (i % 3) * 3, 7, 0xFF5E9A6C);
                }
                for (int i = 0; i < 6; i++) {                                                           // dark trunks near
                    int x = 4 + i * 21;
                    r(x, 0, 6, GROUND + 2, 0xFF2A5636); r(x, 0, 2, GROUND + 2, 0xFF3E7248); r(x + 5, 0, 1, GROUND + 2, 0xFF1E4228);
                    for (int k = 0; k < 5; k++) r(x + 1 + (k * 3) % 4, 8 + k * 9, 1, 3, 0xFF1E4228);    // the bark
                    ball(x + 3, 4 + (i % 3) * 3, 10, 0xFF2F7A42); ball(x - 4, 9 + (i % 2) * 3, 6, 0xFF3A8A4A);
                }
                for (int k = 0; k < 3; k++) {                                                           // shafts of sunlight
                    int a = inScene ? 22 + (int) (8 * Math.sin(tt * 0.02 + k)) : 26;
                    for (int y = 0; y < GROUND; y++) r(18 + k * 38 + y / 2, y, 7 + y / 14, 1, al(a, 0xFFF6C0));
                }
                bands(GROUND, H, 5, 0xFF4E7E3E, 0xFF3A6A32, 0xFF2C5428);
                for (int y = GROUND; y < H; y++) {                                                      // a winding path
                    int cx = 46 + (int) Math.round(Math.sin(y * 0.28) * 4) - (y - GROUND) / 3, hw = 10 + (y - GROUND);
                    r(cx - hw, y, hw * 2, 1, 0xFFCDAA70); r(cx - hw, y, 2, 1, 0xFFA88A58); r(cx + hw - 2, y, 2, 1, 0xFFA88A58);
                }
                tufts(GROUND, H, 40, 0xFF7CB060, 0xFF1F4A26, 31);
                sprinkle(GROUND, H, 6, 44, 0xFFFFFFFF, 0xFFFFD84A);
                for (int i = 0; i < 7; i++) {                                                           // pollen floating in the light
                    int hv = hash(i * 97 + 3);
                    int px = hv % W + (int) Math.round(Math.sin(tt * 0.015 + i) * 4), py = 6 + (hv >> 8) % 44 - (inScene ? (int) (tt * 0.02F * (1 + i % 3)) % 10 : 0);
                    r(px, py, 1, 1, al(inScene ? 120 + (int) (110 * Math.abs(Math.sin(tt * 0.04 + i))) : 200, 0xFFF8D8));
                }
            }
            case "room" -> {
                r(0, 0, W, 52, 0xFFFFE2C6);
                for (int x = 0; x < W; x += 12) { r(x, 0, 6, 52, 0xFFFFD6B4); r(x + 2, 8 + (x / 12 % 3) * 9, 2, 2, 0xFFF4C0A0); r(x + 8, 20 + (x / 12 % 2) * 12, 2, 2, 0xFFF4C0A0); }
                r(0, 0, W, 5, 0xFF9A6A44); r(0, 5, W, 1, 0xFF6A4224); r(0, 0, W, 1, 0xFFC0905C);
                r(0, 38, W, 14, 0xFFB4804E);                                                            // the wood panels
                for (int x = 0; x < W; x += 20) { r(x, 38, 1, 14, 0xFF8A5A30); r(x + 2, 40, 16, 10, 0xFFC08E5A); r(x + 2, 40, 16, 1, 0xFFD8A874); r(x + 2, 49, 16, 1, 0xFF9A6A3C); }
                r(0, 37, W, 2, 0xFFD8A874); r(0, 50, W, 2, 0xFF8A5A30);
                for (int y = 52; y < H; y += 5) {                                                       // the floor boards
                    int c = mix(0xFFD8A06A, 0xFFA8703E, (y - 52) / 22F);
                    r(0, y, W, Math.min(5, H - y), c); r(0, y, W, 1, 0x22000000);
                    for (int x = (y / 5 % 2) * 14; x < W; x += 28) r(x, y, 1, Math.min(5, H - y), 0x33000000);
                }
                e(60, 67, 38, 4, 0xFFC4505E); e(60, 67, 33, 3, 0xFFE0707A); e(60, 67, 22, 2, 0xFFF4B8B8);    // a rug
            }
            case "hall" -> {
                bands(0, 50, 8, 0xFFA48CC8, 0xFFC8B4E4);
                for (int x = 6; x + 14 <= W - 2; x += 26) {                                             // tall arched windows with the sky in them
                    r(x - 1, 5, 16, 34, 0xFFE8D8F8); d(x + 7, 6, 8, 0xFFE8D8F8);
                    r(x + 1, 7, 12, 31, 0xFF9AD6F6); d(x + 7, 7, 6, 0xFF9AD6F6);
                    r(x + 1, 7, 12, 15, 0xFFB6E4FA); r(x + 7, 2, 1, 36, 0xFFE8D8F8); r(x + 1, 22, 12, 1, 0xFFE8D8F8);
                    e(x + 4, 14, 3, 1, al(190, WHITE));
                }
                for (int x = 19; x < W; x += 26) { r(x, 4, 6, 46, 0xFFEFE4FA); r(x, 4, 2, 46, 0xFFFFFFFF); r(x + 5, 4, 1, 46, 0xFFC4B2DC); r(x - 1, 4, 8, 3, 0xFFFFC832); r(x - 1, 46, 8, 4, 0xFFFFC832); }
                r(2, 0, 8, 22, 0xFFC63A4E); r(2, 0, 2, 22, 0xFFE8586A); tri(2, 18, 8, 8, 0xFFC63A4E); r(W - 10, 0, 8, 22, 0xFFC63A4E); r(W - 10, 0, 2, 22, 0xFFE8586A); tri(W - 10, 18, 8, 8, 0xFFC63A4E);
                for (int y = 50; y < H; y += 8) for (int x = 0; x < W; x += 8) {
                    boolean dark = (x / 8 + y / 8) % 2 == 0;
                    r(x, y, 8, Math.min(8, H - y), mix(dark ? 0xFFE8DCF4 : 0xFFC4B0E0, 0xFF8070A8, (y - 50) / 48F));
                }
                r(0, 48, W, 2, 0xFFFFC832); r(0, 50, W, 1, 0xFFB08A20);
            }
            case "storm" -> {
                bands(0, 34, 9, 0xFF262C3E, 0xFF4E586E, 0xFF8892A8);
                for (int i = 0; i < 9; i++) { int cc = mix(0xFF3A4258, 0xFF6A7488, (i % 3) / 3F); d(i * 14 - 2, 5 + (i % 3) * 4, 11, darken(cc, 0.2F)); d(i * 14 - 2, 4 + (i % 3) * 4, 10, cc); }
                bands(34, H, 10, 0xFF3A5E82, 0xFF234466, 0xFF0E2238);
                int sh = (int) (tt * 0.12F) % 14;
                for (int y = 38; y < H; y += 7) {
                    int dir = y / 7 % 2 == 0 ? 1 : -1;
                    for (int x = (y / 7 % 2) * 7 - 14 + Math.floorMod(dir * sh, 14); x < W; x += 14) { r(x, y, 8, 1, al(150, 0xFFD0E0F0)); r(x + 1, y + 1, 5, 1, al(60, 0xFF061428)); }
                }
            }
            case "snow" -> {
                bands(0, GROUND, 9, 0xFF98B4E0, 0xFFC6D9F2, 0xFFEEF5FF);
                ridge(43, 7, 0.07F, 0.19F, 0.4F, 0xFFD3E2F5, 0xFFF6FAFF, GROUND);
                ridge(48, 5, 0.11F, 0.27F, 2.7F, 0xFFE6F0FB, 0xFFFFFFFF, GROUND);
                bands(GROUND, H, 5, 0xFFF4F9FF, 0xFFDCE8F8, 0xFFC6D6EE);
                r(0, GROUND, W, 1, 0xFFFFFFFF);
                for (int i = 0; i < 12; i++) { int hv = hash(i * 211 + 3); r(hv % W, GROUND + 3 + (hv >> 8) % 16, 5, 1, al(110, 0xFF8AA8D8)); }
                for (int i = 0; i < 20; i++) {                                                          // glints on the snow
                    int hv = hash(i * 419 + 1);
                    if (!inScene || Math.sin(tt * 0.05 + i * 2.3) > 0.5) r(hv % W, GROUND + 1 + (hv >> 8) % 18, 1, 1, WHITE);
                }
            }
            default -> { // "day"
                bands(0, GROUND, 9, 0xFF52B6FF, 0xFFA2DDFF, 0xFFE6F8FF);
                ridge(41, 8, 0.07F, 0.19F, 1.2F, 0xFFB9D2EA, 0xFFDCEBF8, GROUND);
                ridge(47, 5, 0.11F, 0.27F, 3.1F, 0xFF93C9A0, 0xFFB4DEB4, GROUND);
                for (int i = 0; i < 5; i++) r(0, GROUND - 5 + i, W, 1, al(18 + i * 9, WHITE));
                bands(GROUND, H, 5, 0xFF8ED66F, 0xFF62B454, 0xFF4E9A48);
                r(0, GROUND, W, 1, 0xFFB4EE8C);
                tufts(GROUND, H, 70, 0xFFA8E888, 0xFF3F8A3F, 5);
                sprinkle(GROUND, H, 12, 17, 0xFFFFFFFF, 0xFFFFE680, 0xFFFFB0D0);
            }
        }
    }

    // ---------- finishing touches ----------
    /** A soft vignette: the corners of the picture are a little darker, which draws the eye to the middle. */
    private static void vignette() {
        for (int y = 0; y < H; y++) {
            float ey = Math.abs(y - H / 2F) / (H / 2F);
            for (int x = 0; x < W; x++) {
                float ex = Math.abs(x - W / 2F) / (W / 2F);
                float v = ex * ex * 0.55F + ey * ey * 0.75F - 0.55F;
                if (v <= 0) continue;
                int a = Math.min(7, (int) (v * 10F));                       // a few steps keep the picture cheap to send to the screen
                if (a > 0) put(x, y, al(a * 7, 0x140A24));
            }
        }
    }

    // ---------- the outline, the shading and the shadow of a thing ----------
    private static boolean solid(int[] a, int w, int h, int x, int y) {
        if (x < 0 || y < 0 || x >= w || y >= h) return true;
        return (a[y * w + x] >>> 24) >= 160;
    }

    /** LAYER -> PROC: a light rim on the top and the left, a shade on the bottom and the right, and a dark outline round it all. */
    private static void process(int w, int h) {
        System.arraycopy(LAYER, 0, PROC, 0, w * h);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x, c = LAYER[i];
                if ((c >>> 24) >= 160) {
                    if (!solid(LAYER, w, h, x, y - 1)) c = lighten(c, 0.22F);
                    else if (!solid(LAYER, w, h, x - 1, y)) c = lighten(c, 0.10F);
                    if (!solid(LAYER, w, h, x, y + 1)) c = darken(c, 0.22F);
                    else if (!solid(LAYER, w, h, x + 1, y)) c = darken(c, 0.12F);
                    PROC[i] = c | 0xFF000000;
                } else {
                    int n = 0;
                    if (y + 1 < h && solid(LAYER, w, h, x, y + 1)) n = LAYER[i + w];
                    else if (x + 1 < w && solid(LAYER, w, h, x + 1, y)) n = LAYER[i + 1];
                    else if (x > 0 && solid(LAYER, w, h, x - 1, y)) n = LAYER[i - 1];
                    else if (y > 0 && solid(LAYER, w, h, x, y - 1)) n = LAYER[i - w];
                    if (n != 0) PROC[i] = mix(n | 0xFF000000, OUT, 0.7F);
                }
            }
        }
    }

    /** A soft oval shadow on the ground under whatever stands in LAYER (not for things that hang or fly in the air). */
    private static void contactShadow(int w, int h) {
        int yb = -1;
        for (int y = h - 1; y >= 0 && yb < 0; y--) for (int x = 0; x < w; x++) if ((LAYER[y * w + x] >>> 24) >= 160) { yb = y; break; }
        if (yb < GROUND - 8) return;
        int x0 = w, x1 = -1;
        for (int y = Math.max(0, yb - 2); y <= yb; y++) for (int x = 0; x < w; x++) if ((LAYER[y * w + x] >>> 24) >= 160) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); }
        int cx = (x0 + x1) / 2, rx = (x1 - x0) / 2 + 2;
        for (int dy = -2; dy <= 2; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0, 1.0 - dy * dy / 5.0)));
            for (int x = cx - dx; x <= cx + dx; x++) put(x, yb + 1 + dy, al(Math.abs(dy) == 2 ? 34 : 62, 0x1A1030));
        }
    }

    /** Sends a buffer to the screen as runs of one colour (a transparent pixel is skipped). */
    private static void blit(GuiGraphics g, int[] a, int w, int h, int gx, int gy) {
        for (int y = 0; y < h; y++) {
            int x = 0;
            while (x < w) {
                int c = a[y * w + x];
                if ((c >>> 24) == 0) { x++; continue; }
                int x1 = x + 1;
                while (x1 < w && a[y * w + x1] == c) x1++;
                g.fill(gx + x, gy + y, gx + x1, gy + y + 1, c);
                x = x1;
            }
        }
    }

    // ---------- people ----------
    private static final int SHOE = 0xFF6A4A4A;

    /** The face of a person: big eyes with a spark, pink cheeks, a small mouth. (hx, hy) = the middle of the head. */
    private static void face(int hx, int hy) {
        if (blink()) { r(hx - 4, hy, 2, 1, INK); r(hx + 2, hy, 2, 1, INK); }
        else {
            r(hx - 4, hy - 1, 2, 2, INK); r(hx + 2, hy - 1, 2, 2, INK);
            r(hx - 4, hy - 1, 1, 1, WHITE); r(hx + 2, hy - 1, 1, 1, WHITE);
        }
        r(hx - 5, hy + 2, 2, 1, 0xAAFF8FA0); r(hx + 3, hy + 2, 2, 1, 0xAAFF8FA0);
        r(hx - 1, hy + 3, 3, 1, 0xFFD85A66);
    }

    /** A standing person: (0, 0) = the feet. dress = the colour of the dress or tunic, long = long hair, skirt = a skirt. */
    private static void person(int dress, int hair, boolean longHair, boolean skirt) { person(dress, hair, longHair, skirt, SKIN, SKIN_D); }

    private static void person(int dress, int hair, boolean longHair, boolean skirt, int skin, int skinD) {
        int dd = darken(dress, 0.22F), dl = lighten(dress, 0.25F), hd = darken(hair, 0.25F), hl = lighten(hair, 0.35F);
        if (longHair) { r(-6, -28, 12, 15, hair); r(4, -28, 2, 15, hd); r(-6, -14, 3, 2, hair); r(3, -14, 3, 2, hd); }
        r(-3, -7, 2, 5, skin); r(1, -7, 2, 5, skinD);                                   // the legs and the shoes
        r(-4, -2, 3, 2, SHOE); r(1, -2, 3, 2, SHOE);
        if (skirt) {
            tri(-8, -20, 16, 15, dress);
            for (int i = 0; i < 15; i++) {                                              // the right side of the skirt is in shade
                int ww = Math.max(1, 16 * (i + 1) / 15), x0 = -8 + (16 - ww) / 2;
                r(x0 + ww * 2 / 3, -20 + i, ww - ww * 2 / 3, 1, dd);
            }
            r(-2, -14, 1, 8, dd); r(2, -12, 1, 6, dd);                                   // folds
            r(-7, -6, 14, 1, dl);                                                        // the hem
        } else {
            r(-4, -20, 8, 10, dress); r(2, -20, 2, 10, dd); r(-4, -20, 1, 10, dl);
            r(-4, -13, 8, 1, 0xFF6A4A2A); r(-1, -13, 2, 1, GOLD);                        // a belt
            r(-4, -10, 3, 5, darken(dress, 0.35F)); r(1, -10, 3, 5, darken(dress, 0.35F));
        }
        r(-6, -19, 2, 7, dress); r(4, -19, 2, 7, dd);                                    // the sleeves and the hands
        r(-6, -13, 2, 2, skin); r(4, -13, 2, 2, skinD);
        r(-1, -21, 2, 2, skinD);
        d(0, -25, 5, skin); r(3, -27, 2, 5, skinD);                                      // the head, its side in shade
        r(-5, -31, 10, 4, hair); r(-3, -31, 4, 1, hl);
        r(-6, -28, 2, longHair ? 8 : 4, hair); r(4, -28, 2, longHair ? 8 : 4, hd);
        r(-5, -28, 3, 1, hair); r(2, -28, 3, 1, hair);
        face(0, -25);
    }

    private static void crown(int x, int y) {
        r(x - 4, y, 9, 3, GOLD);
        r(x - 4, y - 2, 2, 2, GOLD);
        r(x - 1, y - 3, 2, 3, GOLD);
        r(x + 3, y - 2, 2, 2, GOLD);
        r(x - 4, y, 9, 1, 0xFFFFE680);
        r(x, y + 1, 1, 1, 0xFFE5484D); r(x - 3, y + 1, 1, 1, 0xFF4A8AE0); r(x + 3, y + 1, 1, 1, 0xFF4AC080);
    }

    private static void beard(int color) {
        r(-4, -22, 8, 3, color);
        r(-3, -19, 6, 3, color);
        r(-1, -16, 2, 2, color);
        r(2, -22, 2, 6, darken(color, 0.12F));
    }

    private static void drawPerson(String kind) {
        switch (kind) {
            case "princess" -> { person(0xFFFF9AC8, 0xFFF3C860, true, true); crown(0, -31); r(-1, -18, 2, 2, 0xFFFFE680); r(-5, -7, 10, 1, 0xFFFFD0E8); }
            case "prince" -> { r(-7, -20, 3, 13, 0xFFC63A4E); person(0xFF5A7AE8, 0xFF8A5A3A, false, false); crown(0, -31); r(-4, -19, 8, 2, GOLD); r(-1, -17, 2, 2, GOLD); }
            case "redhood" -> {
                person(0xFFE5484D, 0xFF8A5A3A, true, true);
                e(0, -27, 8, 9, 0xFFB02A3A); e(0, -27, 7, 8, 0xFFE5484D);                       // the red hood
                d(0, -24, 5, SKIN); r(3, -26, 2, 5, SKIN_D); face(0, -24);
                r(-2, -34, 4, 1, 0xFFFF8A8A); r(-6, -21, 12, 2, 0xFFC03040); r(0, -20, 1, 1, GOLD);
                r(6, -12, 7, 5, 0xFFB07A3A); r(7, -14, 5, 2, 0xFF8A5A2A); r(7, -12, 5, 1, WHITE); r(6, -9, 7, 1, 0xFF8A5A2A);   // a basket
                r(8, -16, 3, 1, 0xFF6A4A2A);
            }
            case "grandma" -> {
                person(0xFFB07AC8, 0xFFDDDDE6, false, true);
                r(-5, -31, 10, 3, WHITE); d(0, -33, 3, 0xFFDDDDE6); r(-5, -29, 10, 1, 0xFFE8E8F0);       // a cap and a bun
                for (int s = -1; s <= 1; s += 2) { int x = s < 0 ? -5 : 1; r(x, -27, 4, 1, 0xFF6A5A8A); r(x, -24, 4, 1, 0xFF6A5A8A); r(x, -27, 1, 4, 0xFF6A5A8A); r(x + 3, -27, 1, 4, 0xFF6A5A8A); }
                r(-7, -17, 14, 3, 0xFF8A5AA8); r(-7, -17, 14, 1, 0xFFFFFFFF);
            }
            case "oldman" -> {
                person(0xFF6A7A8A, 0xFFEEEEF4, false, false);
                beard(0xFFEEEEF4);
                r(-6, -31, 12, 3, 0xFF8A5A3A); r(-4, -34, 8, 4, 0xFF8A5A3A); r(-4, -32, 8, 1, 0xFFC8A060);
            }
            case "oldwoman" -> {
                person(0xFF9A6A4A, 0xFFDDDDE6, false, true);
                r(-5, -31, 10, 3, 0xFFE0607A); r(-6, -29, 2, 6, 0xFFE0607A); r(4, -29, 2, 6, 0xFFC04A64); r(-2, -31, 3, 1, 0xFFFF9AAA);
                r(-7, -17, 14, 3, 0xFFB0805A); r(-7, -17, 14, 1, 0xFFE8C898);
            }
            case "witch" -> {
                person(0xFF3A2A5A, 0xFF8A8A9A, true, true, 0xFF9AD08A, 0xFF74A864);
                r(0, -24, 1, 3, 0xFF5A8A4A);                                                      // a long nose
                r(-8, -31, 16, 2, 0xFF2A1A44); tri(-5, -45, 10, 14, 0xFF2A1A44); r(-5, -33, 10, 2, 0xFFB57BD6);
                r(-1, -45, 3, 1, 0xFF4A3A6A); r(2, -32, 2, 2, GOLD);
                r(8, -24, 1, 24, 0xFF8A5A3A); r(8, -24, 1, 24, 0xFF8A5A3A); r(7, -26, 3, 2, 0xFF6A4A2A);   // a stick
            }
            case "hansel" -> { person(0xFF6AAE5A, 0xFF8A5A3A, false, false); r(-5, -31, 10, 1, 0xFF8A5A3A); r(-3, -34, 6, 3, 0xFF5A4A3A); }
            case "gretel" -> {
                person(0xFFE0607A, 0xFFF3C860, true, true);
                r(-7, -29, 2, 9, 0xFFF3C860); r(5, -29, 2, 9, 0xFFD8A840); r(-7, -21, 2, 2, 0xFFE0607A); r(5, -21, 2, 2, 0xFFE0607A);
                r(-7, -17, 2, 1, 0xFFF3C860);
                r(-5, -17, 10, 5, WHITE); r(-5, -17, 10, 1, 0xFFF0F0F8);
            }
            case "snowwhite" -> {
                person(0xFFFFD84A, 0xFF1A1A22, false, true);
                r(-4, -19, 8, 5, 0xFF4A7AE0); r(-4, -19, 8, 1, 0xFF7AA0F0); r(-6, -31, 4, 3, 0xFFE5484D); r(-5, -31, 1, 1, WHITE); r(-3, -31, 1, 1, 0xFFFF8A8A);
                r(-5, -29, 10, 1, 0xFF1A1A22);
            }
            case "queen" -> { person(0xFF5A2A7A, 0xFF1A1A22, true, true); crown(0, -31); r(-4, -19, 8, 3, 0xFF8A4AB0); r(-1, -18, 2, 1, GOLD); r(-5, -7, 10, 1, 0xFF9A5AC0); }
            case "dwarf" -> {
                person(0xFF4A7AE0, 0xFFB07A3A, false, false);
                beard(0xFFEEEEF4);
                tri(-6, -42, 12, 12, 0xFFE5484D); r(-6, -31, 12, 2, 0xFFE5484D); r(-6, -31, 12, 1, 0xFFFF8A8A); r(-2, -41, 3, 1, 0xFFFF9A9A);
            }
            case "cinderella" -> {
                person(0xFF8AD0F8, 0xFFF3C860, false, true);
                r(-4, -30, 8, 2, 0xFFF3C860); d(0, -33, 3, 0xFFF3C860); d(-1, -34, 1, 0xFFFFE8A0);
                r(-7, -8, 14, 2, 0xFFD8F0FF); r(-2, -19, 4, 3, WHITE); r(-7, -6, 14, 1, 0xFFE8F8FF);
                r(-5, -20, 10, 1, 0xFFC8E8FF); r(0, -17, 1, 1, 0xFFFFFFFF);
            }
            case "cinderella_rag" -> {
                person(0xFF9A9A8A, 0xFFF3C860, false, true);
                r(-5, -31, 10, 3, 0xFFB07A5A); r(-7, -9, 3, 2, 0xFF6A6A5A); r(2, -12, 3, 2, 0xFF6A6A5A); r(-2, -15, 2, 2, 0xFF7A8A6A);
                r(3, -8, 2, 1, 0xFF6A6A5A);
            }
            case "fairy" -> {
                float fl = inScene ? (float) Math.sin(tm() * 0.25) : 0F;                          // the wings beat
                e(-11, -22, 6, 9 + Math.round(fl), 0x99F0E4FF); e(11, -22, 6, 9 + Math.round(fl), 0x99F0E4FF);
                e(-10, -23, 3, 4, 0x99FFFFFF); e(10, -23, 3, 4, 0x99FFFFFF);
                person(0xFFB8A0F0, 0xFFF8D890, true, true);
                r(8, -26, 1, 14, 0xFFB07A3A); r(6, -29, 5, 5, GOLD); r(7, -30, 3, 7, GOLD); r(8, -28, 1, 1, WHITE);   // a wand with a star
                if (inScene && Math.sin(tm() * 0.2) > 0.2) r(11, -31, 1, 1, 0xFFFFF4B0);
            }
            case "king" -> {
                person(0xFFE5484D, 0xFFB8B8C8, false, true);
                beard(0xFFB8B8C8); crown(0, -31); r(-6, -19, 12, 2, WHITE);
                for (int i = 0; i < 6; i++) r(-5 + i * 2, -19 + (i % 2), 1, 1, INK);                  // the white fur with black spots
                r(-7, -17, 14, 1, 0xFFC03040);
            }
            case "ogre" -> {
                e(0, -12, 10, 12, 0xFF5A8A3E); e(-1, -14, 7, 8, 0xFF6A9A4A); d(0, -28, 8, 0xFF7AAA5A); d(-1, -29, 6, 0xFF8ABA6A);
                r(-4, -31, 3, 3, 0xFFFFFF99); r(1, -31, 3, 3, 0xFFFFFF99); r(-3, -30, 1, 2, INK); r(2, -30, 1, 2, INK);
                r(-4, -24, 8, 2, 0xFF3A2A2A); r(-4, -26, 1, 3, WHITE); r(3, -26, 1, 3, WHITE); r(-1, -27, 2, 2, 0xFF5A8A3E);
                r(-10, -14, 20, 4, 0xFF5A3A2A); r(-1, -14, 2, 4, GOLD);
                r(-9, -8, 4, 8, 0xFF4A7A30); r(5, -8, 4, 8, 0xFF4A7A30); r(-10, -2, 6, 2, 0xFF3A2A1A); r(4, -2, 6, 2, 0xFF3A2A1A);
            }
            case "thumbelina" -> {
                person(0xFFFF9AC8, 0xFFF3C860, true, true);
                for (int i = 0; i < 4; i++) r(-4 + i * 3, -31, 2, 1, i % 2 == 0 ? 0xFFFFFFFF : 0xFF8AD8FF);   // a little flower wreath
                r(-5, -7, 10, 1, 0xFFFFD0E8);
            }
            default -> { }
        }
    }

    // ---------- animals (written looking right, f = 1, or left, f = -1) ----------
    private static void quad(int f, int body, int dark, int belly, int ear, boolean longEars) {
        fr(f, -6, -7, 3, 7, dark); fr(f, 4, -7, 3, 7, dark);                       // the far legs
        fe(f, 0, -11, 11, 6, body);                                                // the body
        fe(f, 0, -8, 9, 3, belly);                                                 // a lighter belly
        fe(f, -1, -14, 8, 2, lighten(body, 0.22F));                                // light on the back
        fr(f, -9, -7, 3, 7, body); fr(f, 6, -7, 3, 7, body);                       // the near legs and the paws
        fr(f, -9, -1, 3, 1, belly); fr(f, 6, -1, 3, 1, belly);
        fd(f, 10, -16, 5, body); fd(f, 9, -17, 3, lighten(body, 0.2F));            // the head
        fr(f, 12, -15, 5, 4, belly); fr(f, 16, -15, 2, 2, INK);                    // the muzzle and the nose
        if (blink()) fr(f, 11, -16, 2, 1, INK); else { fr(f, 11, -18, 2, 2, INK); fr(f, 11, -18, 1, 1, WHITE); }
        if (longEars) { fr(f, 7, -29, 3, 12, body); fr(f, 11, -28, 3, 11, dark); fr(f, 8, -27, 1, 9, ear); }
        else { ftri(f, 7, -23, 4, 5, dark); ftri(f, 11, -23, 4, 5, dark); ftri(f, 8, -22, 2, 3, ear); }
    }

    private static void drawAnimal(String kind, int f) {
        switch (kind) {
            case "wolf" -> {
                quad(f, 0xFF8C90A4, 0xFF646880, 0xFFB8BCCC, 0xFFFFB0B0, false);
                fe(f, -15, -14, 6, 3, 0xFF8C90A4); fe(f, -19, -12, 4, 3, 0xFF646880); fr(f, -22, -12, 2, 2, 0xFF4A4C60);   // a bushy tail
                fr(f, 15, -12, 3, 2, 0xFFE5484D); fr(f, 15, -13, 1, 1, WHITE);                                           // the tongue
                fr(f, 4, -16, 5, 1, 0xFF707490); fr(f, 0, -15, 5, 1, 0xFF707490);                                          // fur
            }
            case "fox" -> {
                quad(f, 0xFFF08A2A, 0xFF8A4A1A, 0xFFFFF0DC, 0xFF3A2A2A, false);
                fe(f, -17, -13, 8, 4, 0xFFF08A2A); fe(f, -22, -12, 4, 3, WHITE); fr(f, 12, -14, 5, 3, WHITE);          // a tail with a white tip
                fr(f, -9, -3, 3, 3, 0xFF5A3A1A); fr(f, 6, -3, 3, 3, 0xFF5A3A1A);                                       // black socks
            }
            case "dog" -> {
                quad(f, 0xFFC8944E, 0xFF8A5A2A, 0xFFE8C890, 0xFF8A5A2A, false);
                fr(f, 5, -22, 3, 7, 0xFF8A5A2A); fr(f, -14, -17, 4, 7, 0xFFC8944E); fr(f, 17, -16, 2, 2, INK);
                fr(f, 8, -11, 6, 1, 0xFFE5484D);                                                                           // a collar
            }
            case "cat" -> {
                quad(f, 0xFF9A9AAA, 0xFF7A7A8A, 0xFFC8C8D4, 0xFFFFB0C0, false);
                fr(f, -16, -22, 3, 12, 0xFF9A9AAA); fr(f, -15, -22, 1, 4, 0xFF6A6A7A); fr(f, 11, -13, 1, 2, WHITE); fr(f, 16, -14, 4, 1, WHITE);   // a tail, whiskers
                for (int i = 0; i < 3; i++) fr(f, -4 + i * 4, -15, 1, 3, 0xFF6A6A7A);                                    // stripes
            }
            case "puss" -> {                                   // the cat in boots, with a hat, a feather and a curled tail
                quad(f, 0xFFF0903A, 0xFFB86A1A, 0xFFFFE0B0, 0xFFFFB0C0, false);
                fe(f, -13, -13, 3, 3, 0xFFF0903A); fe(f, -15, -17, 3, 3, 0xFFF0903A); fe(f, -14, -21, 3, 3, 0xFFF0903A);   // a tail that curls up
                fe(f, -12, -24, 2, 2, 0xFFFFE0B0);
                for (int i = 0; i < 3; i++) fr(f, -4 + i * 4, -15, 1, 3, 0xFFB86A1A);                                    // stripes
                for (int bx : new int[]{-9, 6}) {                                                                        // boots with cuffs and toes
                    fr(f, bx, -6, 3, 6, 0xFF6A3A1A); fr(f, bx, -6, 3, 2, 0xFFC8944E); fr(f, bx + 1, -1, 4, 1, 0xFF4A2A10); fr(f, bx, -4, 1, 3, 0xFF8A5A2A);
                }
                for (int bx : new int[]{-6, 4}) { fr(f, bx, -6, 3, 6, 0xFF5A2E14); fr(f, bx, -6, 3, 2, 0xFFB8843E); }
                fr(f, 16, -16, 4, 1, WHITE); fr(f, 15, -13, 5, 1, WHITE);                                               // whiskers
                fr(f, 6, -25, 14, 2, 0xFF3A2A5A); fr(f, 6, -25, 14, 1, 0xFF5A4A8A);                                     // the hat: a brim on the head
                fr(f, 8, -31, 9, 6, 0xFF3A2A5A); fr(f, 8, -31, 2, 6, 0xFF5A4A8A); fr(f, 8, -27, 9, 1, GOLD); fr(f, 12, -27, 2, 1, 0xFFFFE680);
                fr(f, 14, -38, 1, 8, 0xFFE5484D); fr(f, 15, -38, 1, 4, 0xFFFF8A8A); fr(f, 13, -36, 1, 3, 0xFFC03040);   // the feather
            }
            case "donkey" -> {
                quad(f, 0xFF9A9AA6, 0xFF7A7A86, 0xFFC8C8D4, 0xFFE8C8C8, true);
                fr(f, 14, -14, 5, 5, 0xFFE8E8EE); fr(f, 8, -20, 6, 2, 0xFF6A6A76); fr(f, -14, -13, 3, 6, 0xFF6A6A76); fr(f, -1, -17, 8, 1, 0xFF7A7A86);
                fr(f, 8, -22, 1, 3, 0xFF6A6A76);
            }
            case "hare" -> {
                quad(f, 0xFFE8E8EE, 0xFFB8B8C6, 0xFFFFFFFF, 0xFFFFB0C0, true);
                fd(f, -12, -13, 3, WHITE); fd(f, -12, -13, 2, 0xFFF4F4FA); fr(f, 16, -14, 2, 2, 0xFFE5484D);
            }
            case "bear" -> {
                quad(f, 0xFF8A5A3A, 0xFF6A3A2A, 0xFFAA7A52, 0xFF6A3A2A, false);
                fe(f, 0, -13, 13, 9, 0xFF8A5A3A); fe(f, -2, -15, 9, 5, 0xFFA87850); fr(f, 14, -14, 5, 4, 0xFFC8946A); fr(f, 18, -14, 2, 2, INK);
                fd(f, 8, -22, 2, 0xFF6A3A2A);
            }
            case "rooster" -> {
                fr(f, -2, -4, 1, 4, GOLD); fr(f, 2, -4, 1, 4, GOLD); fr(f, -3, -1, 3, 1, GOLD); fr(f, 1, -1, 3, 1, GOLD);
                fe(f, 0, -9, 7, 8, 0xFFE8742A); fe(f, 1, -7, 5, 5, 0xFFF4A04A); fe(f, 2, -9, 4, 4, 0xFFC85A1A);
                fd(f, 6, -19, 4, 0xFFE8742A); fd(f, 5, -20, 2, 0xFFF4A04A);
                fr(f, 4, -26, 4, 4, 0xFFE5484D); fr(f, 6, -27, 2, 2, 0xFFFF6A6A); fr(f, 9, -19, 4, 2, GOLD); fr(f, 9, -17, 2, 3, 0xFFE5484D);
                if (blink()) fr(f, 7, -20, 2, 1, INK); else { fr(f, 7, -21, 2, 2, INK); fr(f, 7, -21, 1, 1, WHITE); }
                fr(f, -12, -20, 3, 14, 0xFF2E9A78); fr(f, -10, -23, 3, 15, 0xFF3A6AE0); fr(f, -8, -17, 3, 10, 0xFFE5484D); fr(f, -11, -20, 1, 12, 0xFF6AD8B0);
            }
            case "duck" -> {
                fe(f, 0, -5, 9, 5, 0xFFF8E8A0); fe(f, 0, -3, 7, 3, 0xFFE8D480); fd(f, 8, -12, 4, 0xFFF8E8A0); fd(f, 7, -13, 2, 0xFFFFF8D0);
                fr(f, 11, -12, 4, 2, 0xFFFF9A2A); fr(f, 11, -11, 4, 1, 0xFFE0801A); if (blink()) fr(f, 9, -13, 2, 1, INK); else { fr(f, 9, -14, 2, 2, INK); fr(f, 9, -14, 1, 1, WHITE); }
                fr(f, -3, -6, 7, 3, 0xFFE8D880); fr(f, -3, -6, 7, 1, 0xFFFFF4B0); fr(f, -10, -7, 3, 2, 0xFFF8E8A0);
            }
            case "duckling" -> {
                fe(f, 0, -5, 7, 5, 0xFF9A9080); fe(f, 0, -3, 5, 3, 0xFF857B6C); fd(f, 6, -11, 4, 0xFF9A9080); fd(f, 5, -12, 2, 0xFFB0A898);
                fr(f, 9, -11, 3, 2, 0xFFFF9A2A); if (blink()) fr(f, 7, -12, 2, 1, INK); else { fr(f, 7, -13, 2, 2, INK); fr(f, 7, -13, 1, 1, WHITE); }
                fr(f, -3, -6, 5, 2, 0xFF7A7060); fr(f, -8, -6, 2, 2, 0xFF9A9080);
            }
            case "ducklings" -> {
                for (int i = 0; i < 3; i++) {
                    fe(f, -10 + i * 9, -3, 4, 3, 0xFFFFE680); fe(f, -10 + i * 9, -2, 3, 2, 0xFFF0D060); fd(f, -7 + i * 9, -7, 2, 0xFFFFE680);
                    fr(f, -5 + i * 9, -7, 2, 1, 0xFFFF9A2A); fr(f, -7 + i * 9, -8, 1, 1, INK);
                }
            }
            case "swan" -> {
                fe(f, 0, -7, 11, 6, WHITE); fe(f, 0, -5, 9, 3, 0xFFD8E4F8); fe(f, -1, -9, 7, 3, 0xFFF4F8FF);
                fr(f, -13, -12, 5, 4, WHITE); fr(f, -13, -12, 5, 1, 0xFFF4F8FF);
                for (int i = 0; i < 12; i++) fr(f, 8 + (i < 7 ? 0 : (i - 6)), -10 - i, 3, 2, i % 3 == 0 ? 0xFFF0F4FF : WHITE);   // the neck
                fd(f, 13, -22, 3, WHITE);
                fr(f, 15, -22, 4, 2, 0xFFFF9A2A); fr(f, 15, -22, 1, 2, INK); if (blink()) fr(f, 13, -23, 2, 1, INK); else fr(f, 13, -23, 1, 2, INK);
            }
            case "swallow" -> {
                float fl = inScene ? (float) Math.sin(tm() * 0.3 + seed) : 0F;                          // the wings beat
                fe(f, 0, -4, 6, 3, 0xFF2A3A8A); fe(f, 0, -2, 4, 2, 0xFFF4F0E8);
                fd(f, 6, -6, 3, 0xFF2A3A8A);
                fr(f, 8, -6, 3, 2, GOLD); fr(f, 5, -7, 1, 1, WHITE); fr(f, 7, -5, 2, 2, 0xFFE5484D);
                fr(f, -10, -4, 7, 1, 0xFF2A3A8A); fr(f, -10, -2, 7, 1, 0xFF2A3A8A); fr(f, -3, -10 - Math.round(fl * 2), 6, 4, 0xFF3A4AA8); fr(f, -1, -12 - Math.round(fl * 2), 3, 3, 0xFF4A5AC0);
            }
            case "toad" -> {
                fe(f, 0, -5, 8, 5, 0xFF6AA05A); fe(f, 0, -3, 6, 3, 0xFF9AC878);
                fd(f, 4, -11, 2, 0xFF8AC070); fd(f, -2, -11, 2, 0xFF8AC070);
                fr(f, 4, -11, 1, 1, INK); fr(f, -2, -11, 1, 1, INK); fr(f, -4, -3, 9, 1, 0xFF3A6A3A);
                fr(f, -2, -8, 2, 1, 0xFF4A7A3A); fr(f, 3, -7, 2, 1, 0xFF4A7A3A); fr(f, 0, -5, 2, 1, 0xFF4A7A3A);
                fr(f, -9, -2, 3, 2, 0xFF5A9048); fr(f, 7, -2, 3, 2, 0xFF5A9048);
            }
            case "mouse" -> {
                fe(f, 0, -3, 5, 3, 0xFFB8B8C6); fe(f, 0, -2, 4, 2, 0xFFD8D8E4); fd(f, 5, -4, 2, 0xFFB8B8C6); fd(f, 4, -7, 2, 0xFFFFB0C0); fd(f, 4, -7, 1, 0xFFFFD0D8);
                fr(f, -9, -2, 5, 1, 0xFFFFB0C0); fr(f, -11, -3, 3, 1, 0xFFFFB0C0); fr(f, 6, -5, 1, 1, INK); fr(f, 7, -4, 1, 1, 0xFFFF7A8A);
            }
            default -> { }
        }
    }

    private static boolean isPerson(String k) {
        return switch (k) {
            case "princess", "prince", "redhood", "grandma", "oldman", "oldwoman", "witch", "hansel", "gretel", "snowwhite", "queen",
                 "dwarf", "cinderella", "cinderella_rag", "fairy", "king", "ogre", "thumbelina" -> true;
            default -> false;
        };
    }

    // ---------- things ----------
    /** A triangle (a roof, a fir tier) whose right side is in shade. */
    private static void triShade(int x, int y, int w, int h, int c) {
        tri(x, y, w, h, c);
        int dk = darken(c, 0.2F), lt = lighten(c, 0.18F);
        for (int i = 0; i < h; i++) {
            int ww = Math.max(1, w * (i + 1) / h), x0 = x + (w - ww) / 2;
            r(x0 + ww * 3 / 5, y + i, ww - ww * 3 / 5, 1, dk);
            if (ww > 3) r(x0, y + i, 1, 1, lt);
        }
    }

    private static void thing(String k, int f) {
        if (isPerson(k)) { drawPerson(k); return; }
        switch (k) {
            case "sun" -> {
                float tt = tm();
                for (int i = 4; i >= 1; i--) d(0, -7, 8 + i * 3, al(10 + (inScene ? (int) (5 * Math.sin(tt * 0.04)) : 0), 0xFFE680));   // a soft pulsing halo
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4 + tt * 0.006;                                                  // the rays turn slowly
                    int len = 11 + (inScene ? (int) Math.round(Math.sin(tt * 0.07 + i)) : 0);
                    r((int) Math.round(Math.cos(a) * len) - 1, -7 + (int) Math.round(Math.sin(a) * len) - 1, 2, 2, 0xFFFFD84A);
                    r((int) Math.round(Math.cos(a + 0.39) * 9), -7 + (int) Math.round(Math.sin(a + 0.39) * 9), 1, 1, 0xFFFFE680);
                }
                d(0, -7, 7, 0xFFFFC832); d(0, -7, 6, 0xFFFFD84A); d(-1, -8, 4, 0xFFFFEE90); d(-2, -9, 2, 0xFFFFFAD0);
            }
            case "moon" -> {
                for (int i = 4; i >= 1; i--) d(0, -7, 7 + i * 3, al(8 + (inScene ? (int) (4 * Math.sin(tm() * 0.03)) : 0), 0xFFF3C0));
                d(0, -7, 7, 0xFFE8D890); d(-1, -8, 6, 0xFFFFF3C0); d(-3, -9, 3, 0xFFFFFAE0);
                d(-3, -10, 1, 0xFFE8D890); d(2, -5, 2, 0xFFE8D890); d(3, -10, 1, 0xFFE8D890); d(-2, -4, 1, 0xFFE8D890);
            }
            case "star" -> {
                float tw = inScene ? (float) Math.abs(Math.sin(tm() * 0.05 + seed)) : 1F;
                int c = al(120 + (int) (135 * tw), 0xFFE680);
                r(0, -4, 1, 3, c); r(-1, -3, 3, 1, c);
                if (tw > 0.7F) { r(0, -6, 1, 7, c); r(-3, -3, 7, 1, c); }                          // it flashes
            }
            case "cloud" -> {
                float pox = ox;
                if (inScene) ox += Math.round(Math.sin(tm() * 0.006 + seed) * 3) * sc;                  // the cloud drifts
                r(-8, -3, 17, 3, 0xFFE4EEFA); d(-6, -4, 4, 0xFFE4EEFA); d(0, -6, 6, 0xFFE4EEFA); d(7, -4, 4, 0xFFE4EEFA);   // the shaded underside
                d(-6, -5, 4, WHITE); d(0, -7, 6, WHITE); d(7, -5, 4, WHITE); r(-8, -5, 17, 3, WHITE);
                d(-1, -9, 3, 0xFFFFFFFF); r(-8, -2, 17, 1, 0xFFD0E0F4);
                ox = pox;
            }
            case "tree" -> {
                r(-2, -14, 4, 14, 0xFF7A4A2A); r(-2, -14, 1, 14, 0xFF9A6A3A); r(1, -14, 1, 14, 0xFF5A3A1E); r(-3, -2, 6, 2, 0xFF7A4A2A);
                r(0, -9, 1, 3, 0xFF5A3A1E); r(-1, -5, 1, 2, 0xFF5A3A1E);
                ball(-7, -17, 6, 0xFF3F9E48); ball(7, -17, 6, 0xFF3F9E48); ball(0, -23, 9, 0xFF4FB052); ball(-3, -28, 5, 0xFF63C463);
                r(-5, -22, 1, 1, 0xFF8AE080); r(2, -26, 1, 1, 0xFF8AE080); r(5, -21, 1, 1, 0xFF8AE080);
                r(-2, -18, 2, 1, 0xFF2E7E3A); r(3, -15, 2, 1, 0xFF2E7E3A);
            }
            case "pine" -> {
                r(-1, -6, 3, 6, 0xFF6A4A2A); r(-1, -6, 1, 6, 0xFF8A6A3A);
                triShade(-9, -16, 18, 12, 0xFF2E7A4A); triShade(-7, -25, 14, 11, 0xFF2E7A4A); triShade(-5, -33, 10, 10, 0xFF2E7A4A);
                r(-2, -33, 4, 2, WHITE); r(-4, -24, 8, 2, WHITE); r(-6, -15, 12, 2, WHITE);
                r(-1, -32, 2, 1, 0xFFC8D8F0); r(-3, -23, 6, 1, 0xFFC8D8F0); r(-5, -14, 10, 1, 0xFFC8D8F0);
            }
            case "bush" -> {
                ball(-5, -4, 5, 0xFF3FA04A); ball(4, -5, 6, 0xFF4FB85A); ball(0, -7, 4, 0xFF5FC86A);
                r(-3, -3, 1, 1, 0xFFE5484D); r(3, -6, 1, 1, 0xFFE5484D); r(6, -3, 1, 1, 0xFFE5484D);
            }
            case "flower" -> {
                r(0, -10, 1, 10, 0xFF3FA04A); r(1, -10, 1, 10, 0xFF2E8A3A); r(-3, -4, 3, 1, 0xFF3FA04A); r(-4, -5, 2, 1, 0xFF4FB85A); r(1, -6, 3, 1, 0xFF3FA04A);
                d(-2, -12, 2, 0xFFFF8AB8); d(3, -12, 2, 0xFFFF8AB8); d(0, -15, 2, 0xFFFF8AB8); d(0, -10, 2, 0xFFFF6AA0); d(0, -12, 1, 0xFFFFE680);
                r(-3, -13, 1, 1, 0xFFFFC0DA); r(-1, -16, 1, 1, 0xFFFFC0DA);
            }
            case "bigflower" -> {
                r(-1, -20, 3, 20, 0xFF3FA04A); r(1, -20, 1, 20, 0xFF2E8A3A); triShade(1, -9, 8, 5, 0xFF3FA04A); triShade(-9, -14, 8, 5, 0xFF4FB85A);
                e(0, -26, 9, 7, 0xFFFF6AA0); e(0, -22, 8, 5, 0xFFFF8AB8); r(-7, -26, 14, 1, 0xFFFFB0D0);
                for (int i = -6; i <= 6; i += 3) ball(i, -27 + Math.abs(i) / 3, 3, i % 2 == 0 ? 0xFFFF7AAE : 0xFFFF9AC4);
                d(0, -25, 2, 0xFFFFD84A); r(-1, -26, 1, 1, 0xFFFFF4B0);
            }
            case "pond" -> {
                e(0, -4, 23, 6, 0xFFC4A878); e(0, -4, 22, 5, 0xFF8AD0F0); e(0, -4, 19, 4, 0xFF5FB8F0); e(0, -6, 13, 1, 0xFF9AE0FF);
                float tt = tm();
                int rp = inScene ? (int) Math.round(Math.sin(tt * 0.04) * 3) : 0;
                r(-10 + rp, -5, 6, 1, 0xAAFFFFFF); r(4 - rp, -3, 5, 1, 0xAAFFFFFF); r(-3, -6, 4, 1, 0x88FFFFFF);
                e(-12, -3, 3, 1, 0xFF4FAE4E); e(10, -5, 3, 1, 0xFF4FAE4E); d(-12, -4, 1, 0xFFFF8AB8);                  // lily pads
            }
            case "reeds" -> {
                for (int i = 0; i < 3; i++) {
                    int sw = inScene ? Math.round((float) Math.sin(tm() * 0.03 + i + seed) * 1.2F) : 0;
                    r(-4 + i * 4, -16 + i, 1, 16 - i, 0xFF5A8A3A); r(-5 + i * 4 + sw, -18 + i, 3, 5, 0xFF8A5A2A); r(-5 + i * 4 + sw, -18 + i, 1, 5, 0xFFB07A3A); r(-4 + i * 4 + sw, -20 + i, 1, 2, 0xFF6A4A2A);
                }
                r(2, -10, 4, 1, 0xFF4A7A30); r(-8, -8, 4, 1, 0xFF4A7A30);
            }
            case "cottage" -> {
                r(-14, -17, 28, 17, 0xFFF3DDB0); r(8, -17, 6, 17, 0xFFE0C898); r(-14, -17, 1, 17, 0xFFFFF0D0);
                r(-14, -3, 28, 3, 0xFFB8A488); for (int i = 0; i < 6; i++) r(-13 + i * 5, -3 + (i % 2), 3, 1, 0xFF988468);   // the stone foot
                for (int i = 0; i < 5; i++) r(-12 + i * 6, -14 + (i % 2) * 5, 1, 4, 0xFFD8C090);                           // timber
                r(8, -34, 5, 9, 0xFF9A6A5A); r(8, -34, 1, 9, 0xFFBA8A7A); r(7, -35, 7, 2, 0xFF6A4A3A);                    // the chimney
                triShade(-18, -31, 36, 14, 0xFFC4523A);
                for (int i = 3; i < 14; i += 3) r(-18 + (36 - 36 * (i + 1) / 14) / 2 + 2, -31 + i, 36 * (i + 1) / 14 - 4, 1, 0xFF9A3A2A);   // rows of shingles
                r(-3, -12, 6, 12, 0xFF7A4A2A); r(-3, -12, 1, 12, 0xFF9A6A3A); r(2, -6, 1, 1, GOLD); r(-4, -1, 8, 1, 0xFFB8A488);        // the door
                r(-11, -13, 6, 6, 0xFFA8D8FF); r(6, -13, 6, 6, 0xFFA8D8FF); r(-11, -13, 6, 2, 0xFFD0ECFF); r(6, -13, 6, 2, 0xFFD0ECFF);
                r(-8, -13, 1, 6, 0xFFB07A3A); r(9, -13, 1, 6, 0xFFB07A3A); r(-11, -10, 6, 1, 0xFFB07A3A); r(6, -10, 6, 1, 0xFFB07A3A);
                r(-12, -13, 1, 6, 0xFF6AA05A); r(12, -13, 1, 6, 0xFF6AA05A);                                              // shutters
                r(-12, -6, 8, 2, 0xFF8A5A3A); r(-11, -7, 1, 1, 0xFFFF6AA0); r(-9, -7, 1, 1, 0xFFFFD84A); r(-7, -7, 1, 1, 0xFFFF6AA0);   // a flower box
                if (inScene) smoke(10, -36);
            }
            case "glowhouse" -> {
                r(-14, -17, 28, 17, 0xFF8A6A5A); r(8, -17, 6, 17, 0xFF6A4A3A); triShade(-18, -31, 36, 14, 0xFF4A3A4A);
                r(-3, -12, 6, 12, 0xFF3A2A2A); r(-3, -12, 1, 12, 0xFF5A4A3A);
                float gl = inScene ? 0.5F + 0.5F * (float) Math.sin(tm() * 0.05 + seed) : 1F;
                for (int i = 3; i >= 1; i--) e(-7, -10, 5 + i * 3, 5 + i * 2, al(Math.round(10 + 8 * gl), 0xFFE680));    // light spills out of the window
                r(-11, -14, 8, 8, 0xFFFFE680); r(-11, -14, 8, 3, 0xFFFFF4B8); r(-8, -14, 1, 8, 0xFF8A6A3A); r(-11, -11, 8, 1, 0xFF8A6A3A);
                r(6, -13, 6, 6, 0xFF4A3A3A); r(-14, -3, 28, 3, 0xFF6A5A4A);
            }
            case "candyhouse" -> {
                r(-15, -18, 30, 18, 0xFFC88A4A); r(9, -18, 6, 18, 0xFFA8703A); r(-15, -18, 30, 1, 0xFFE0A860); triShade(-19, -33, 38, 15, 0xFFFF8AB8);
                for (int i = 0; i < 5; i++) { r(-17 + i * 8, -22 + (i % 2) * 2, 4, 2, WHITE); r(-13 + i * 8, -26 + (i % 2) * 2, 2, 4, 0xFF8AE0C0); d(-15 + i * 8, -19, 1, i % 2 == 0 ? 0xFFFF6A8A : 0xFFFFE680); }
                r(-4, -13, 8, 13, 0xFF6A3A1A); for (int i = 0; i < 6; i++) r(-4, -13 + i * 2, 8, 1, i % 2 == 0 ? 0xFFE5484D : WHITE);
                ball(-10, -9, 3, 0xFFFFE680); ball(11, -9, 3, 0xFF8AD0F8); r(-11, -6, 2, 3, WHITE); r(10, -6, 2, 3, WHITE);
                for (int i = 0; i < 6; i++) r(-14 + i * 5, -1, 3, 1, 0xFFFFFFFF);                          // icing on the ground
            }
            case "castle" -> {
                r(-18, -26, 36, 26, 0xFFE8D8F0); r(10, -26, 8, 26, 0xFFD0BEE4); r(-24, -36, 10, 36, 0xFFD8C8E8); r(14, -36, 10, 36, 0xFFC4B2DC); r(-5, -40, 10, 40, 0xFFD8C8E8); r(2, -40, 3, 40, 0xFFC4B2DC);
                for (int y = -24; y < 0; y += 5) { r(-18, y, 36, 1, 0x22000000); for (int x = -17 + (y / 5 % 2) * 4; x < 18; x += 8) r(x, y, 1, 5, 0x18000000); }
                triShade(-26, -50, 14, 14, 0xFFFF6AA0); triShade(12, -50, 14, 14, 0xFFFF6AA0); triShade(-7, -54, 14, 14, 0xFFFF6AA0);
                r(0, -62, 1, 8, 0xFF7A4A2A);
                int wave = inScene ? Math.round((float) Math.sin(tm() * 0.1) * 1.4F) : 0;                       // the flag waves
                r(1, -62, 5, 3, 0xFFE5484D); r(6, -61 + wave, 2, 2, 0xFFE5484D);
                r(-4, -12, 8, 12, 0xFF7A4A2A); d(0, -12, 4, 0xFF7A4A2A); r(-4, -12, 1, 12, 0xFF9A6A3A); r(-3, -2, 6, 2, GOLD); r(2, -6, 1, 1, GOLD);
                for (int wx : new int[]{-21, 17, -2}) { int wy = wx == -2 ? -34 : -28; r(wx, wy, 4, 6, 0xFF9AD0F0); r(wx, wy, 4, 2, 0xFFD0ECFF); r(wx + 1, wy + 6, 2, 1, 0xFFB8A0D0); }
                for (int i = 0; i < 4; i++) r(-18 + i * 10, -29, 6, 3, 0xFFE8D8F0);
                r(-24, -37, 10, 1, 0xFFFFFFFF); r(14, -37, 10, 1, 0xFFFFFFFF);
            }
            case "hill" -> { e(0, -2, 40, 14, 0xFF55AC4A); e(0, -3, 39, 13, 0xFF6AC05A); e(-8, -6, 24, 9, 0xFF7BCB6A); e(-12, -9, 12, 3, 0xFF9ADC80); tufts0(); }
            case "rock" -> { e(0, -5, 9, 6, 0xFF6A6A7A); e(-1, -6, 8, 5, 0xFF8A8A9A); e(-3, -8, 5, 3, 0xFFB0B0C0); r(2, -6, 1, 3, 0xFF6A6A7A); r(3, -3, 3, 1, 0xFF6A6A7A); d(7, -2, 1, 0xFF4FAE4E); }
            case "boat" -> {
                r(-2, -29, 1, 27, 0xFF7A4A2A); triShade(-1, -28, 13, 22, 0xFFFFF3D0); r(-11, -6, 26, 5, 0xFF8A5A3A); r(-9, -2, 22, 2, 0xFF6A3A1A); r(-11, -6, 26, 1, 0xFFB07A4A);
                r(-7, -5, 1, 4, 0xFF6A3A1A); r(0, -5, 1, 4, 0xFF6A3A1A); r(7, -5, 1, 4, 0xFF6A3A1A); r(-2, -31, 4, 2, 0xFFE5484D);
            }
            case "ship" -> {
                r(-1, -36, 2, 34, 0xFF7A4A2A); triShade(1, -36, 14, 24, WHITE); triShade(-15, -32, 14, 20, 0xFFF3E8D0);
                for (int i = 0; i < 4; i++) { r(-14 + i * 2, -26 + i * 5, 12 - i * 2, 1, 0xFFD8CCB0); r(2 + i, -32 + i * 5, 12 - i * 2, 1, 0xFFD0D8E8); }
                r(-18, -8, 38, 6, 0xFF8A5A3A); r(-18, -8, 38, 1, 0xFFB07A4A); r(-14, -2, 30, 3, 0xFF6A3A1A);
                for (int i = 0; i < 5; i++) d(-12 + i * 8, -5, 1, 0xFFFFE680);                              // portholes
                int wave = inScene ? Math.round((float) Math.sin(tm() * 0.12) * 1.2F) : 0;
                r(-2, -40, 6, 3, 0xFFE5484D); r(4, -39 + wave, 2, 2, 0xFFE5484D); r(-18, -9, 2, 4, 0xFF6A3A1A); r(18, -9, 2, 4, 0xFF6A3A1A);
            }
            case "fish" -> {
                float pox = ox, poy = oy;
                if (inScene) { ox += Math.round(Math.sin(tm() * 0.02 + seed) * 4) * sc; oy += Math.round(Math.sin(tm() * 0.05 + seed) * 1.5) * sc; }
                e(0, -4, 5, 3, 0xFFFF9A2A); e(-1, -3, 3, 2, 0xFFFFC060); tri(4, -7, 6, 6, 0xFFFF7A1A); r(-3, -5, 1, 1, INK); r(-3, -5, 1, 1, WHITE); r(-2, -5, 1, 1, INK);
                ox = pox; oy = poy;
            }
            case "goldfish" -> {
                float poy = oy;
                if (inScene) oy += Math.round(Math.sin(tm() * 0.04 + seed)) * sc;
                tri(9, -14, 10, 14, 0xFFFFB020); tri(-3, -17, 8, 7, 0xFFFFB020);
                e(0, -7, 11, 7, 0xFFFFA81A); e(-1, -8, 10, 6, GOLD); e(-2, -10, 7, 3, 0xFFFFE680);
                for (int i = 0; i < 3; i++) for (int j = 0; j < 2; j++) r(1 + i * 3 + j, -7 + j * 3, 2, 1, 0xFFE89A10);   // scales
                r(-7, -9, 2, 2, INK); r(-7, -9, 1, 1, WHITE); r(-1, -9, 1, 9, 0x44FFFFFF);
                oy = poy;
            }
            case "bubbles" -> {
                if (!inScene) { d(0, -3, 3, 0x88FFFFFF); d(7, -10, 2, 0x88FFFFFF); d(-4, -16, 4, 0x88FFFFFF); r(-2, -18, 1, 1, WHITE); }
                else {
                    float tt = tm();
                    int[] bx = {0, 7, -4}, rad = {3, 2, 4};
                    for (int n = 0; n < 3; n++) {                                                          // the bubbles rise and fade
                        float p = (tt * 0.01F + n * 0.34F) % 1F;
                        int x = bx[n] + Math.round((float) Math.sin(tt * 0.04 + n * 2) * 1.5F), y = Math.round(-3 - p * 24F);
                        d(x, y, rad[n], al(Math.round(0x66 * (1F - p * p)), 0xFFFFFF));
                        r(x - 1, y - 2, 1, 1, al(Math.round(255 * (1F - p)), 0xFFFFFF));
                    }
                }
            }
            case "shell" -> {
                e(0, -4, 6, 4, 0xFFFFB0C8); for (int i = -4; i <= 4; i += 2) r(i, -7 + Math.abs(i) / 3, 1, 5 - Math.abs(i) / 3, 0xFFFF8AB8);
                r(-3, -1, 7, 1, 0xFFE8D8C0); r(-2, -6, 3, 1, 0xFFFFD8E4);
            }
            case "coral" -> {
                r(-1, -14, 3, 14, 0xFFFF6A7A); r(-6, -11, 2, 7, 0xFFFF6A7A); r(4, -12, 2, 8, 0xFFFF6A7A); r(-6, -11, 7, 2, 0xFFFF6A7A); r(1, -12, 5, 2, 0xFFFF8A9A);
                r(0, -14, 1, 14, 0xFFFF8A9A); ball(0, -15, 2, 0xFFFF9AAA); ball(-5, -12, 2, 0xFFFF9AAA); ball(5, -13, 2, 0xFFFF9AAA);
            }
            case "seaweed" -> {
                float tt = tm();
                for (int i = 0; i < 14; i++) {                                                             // the weed sways, more at the top
                    int sw = inScene ? (int) Math.round(Math.sin(tt * 0.05 + i * 0.4 + seed) * Math.min(3.0, i * 0.28)) : 0;
                    r((i / 3 % 2 == 0 ? 0 : 2) - 1 + sw, -i - 1, 2, 1, 0xFF3FA04A);
                    r((i / 3 % 2 == 0 ? 0 : 2) - 1 + sw, -i - 1, 1, 1, 0xFF6AC86A);
                }
                for (int i = 0; i < 9; i++) {
                    int sw = inScene ? (int) Math.round(Math.sin(tt * 0.05 + i * 0.5 + seed + 2) * Math.min(2.5, i * 0.3)) : 0;
                    r(6 + (i / 3 % 2 == 0 ? 0 : 2) + sw, -i - 1, 2, 1, 0xFF2E8A3A);
                }
            }
            case "foam" -> {
                float tt = tm();
                for (int i = -2; i <= 2; i++) {                                                            // the foam rocks on the waves
                    int bob = inScene ? (int) Math.round(Math.sin(tt * 0.06 + i * 0.9 + seed)) : 0;
                    int sh = inScene ? (int) Math.round(Math.sin(tt * 0.035 + i + seed) * 2) : 0;
                    e(i * 7 + sh, -2 + bob, 5, 2, 0xDDFFFFFF); e(i * 7 + sh, -3 + bob, 3, 1, WHITE); r(i * 7 + sh - 3, -1 + bob, 6, 1, 0x66A8D0F0);
                }
            }
            case "mermaid" -> {
                r(-7, -27, 14, 17, 0xFFE05A3A); r(4, -27, 3, 17, 0xFFB8402A); r(-7, -12, 3, 3, 0xFFE05A3A);   // long red hair
                int[] tx = {0, 2, 4, 6, 8, 10, 12, 13, 14}, ty = {-10, -8, -6, -4, -3, -3, -4, -6, -8}, trd = {5, 5, 4, 4, 4, 3, 3, 2, 2};
                for (int i = 0; i < 9; i++) {                                                                // the tail: a curve of scaled links that turns up
                    e(tx[i], ty[i], trd[i], Math.max(2, trd[i] - 1), i % 2 == 0 ? 0xFF3CC8B0 : 0xFF36B8A0);
                    r(tx[i] - 2, ty[i] - 2, 2, 1, 0xFF7AE8D0);
                }
                e(0, -12, 5, 4, 0xFF3CC8B0);
                e(14, -12, 2, 4, 0xFF2E9A8A); e(17, -9, 4, 2, 0xFF2E9A8A); e(15, -10, 2, 2, 0xFF3CC8B0); r(14, -15, 1, 3, 0xFF7AE8D0); r(17, -10, 3, 1, 0xFF7AE8D0);   // the tail fin
                r(-4, -19, 8, 7, SKIN); r(3, -19, 1, 7, SKIN_D); r(-4, -17, 3, 3, 0xFFFF9AC8); r(1, -17, 3, 3, 0xFFFF7AB0); r(-3, -17, 1, 1, 0xFFFFD0E8);    // a shell top
                d(0, -24, 5, SKIN); r(3, -26, 2, 5, SKIN_D);
                r(-5, -30, 10, 4, 0xFFE05A3A); r(-6, -27, 2, 6, 0xFFE05A3A); r(-3, -30, 4, 1, 0xFFFF8A6A); r(2, -31, 3, 2, 0xFFFF6AA0);       // a bow
                face(0, -24);
            }
            case "bed" -> {
                r(-17, -34, 3, 34, 0xFF8A5A3A); r(14, -34, 3, 34, 0xFF8A5A3A); r(-17, -34, 1, 34, 0xFFB07A4A); ball(-15, -36, 3, 0xFFB07A3A); ball(15, -36, 3, 0xFFB07A3A);
                int[] cols = {0xFFFF9AC8, 0xFF9AD0F8, 0xFFF8E080, 0xFFB8E8A0, 0xFFD8B0F0};
                for (int i = 0; i < 5; i++) { r(-15, -8 - i * 5, 30, 5, cols[i]); r(-15, -4 - i * 5, 30, 1, 0x22000000); r(-15, -8 - i * 5, 30, 1, 0x33FFFFFF); }
                e(0, -34, 10, 3, WHITE); e(-2, -35, 6, 1, 0xFFF4F8FF);
            }
            case "pea" -> { ball(0, -3, 3, 0xFF6AC85A); }
            case "mirror" -> {
                e(0, -14, 9, 13, 0xFFC89A1A); e(0, -14, 8, 12, GOLD); e(0, -14, 6, 10, 0xFFD8F0FF); e(0, -17, 5, 5, 0xFFEAF8FF);
                r(-4, -22, 2, 8, WHITE); r(3, -8, 1, 3, WHITE); r(-3, 0, 6, 3, GOLD); r(-3, 0, 6, 1, 0xFFFFE680); d(0, -26, 2, 0xFFE5484D);
                if (inScene && Math.sin(tm() * 0.08) > 0.6) r(2, -19, 1, 3, WHITE);
            }
            case "apple" -> { ball(-2, -5, 4, 0xFFE5484D); ball(2, -5, 4, 0xFFD43A42); r(-1, -9, 1, 3, 0xFF6A3A1A); r(0, -10, 3, 2, 0xFF4FAE4E); r(-3, -7, 1, 2, 0xFFFFB0B0); }
            case "pumpkin" -> {
                e(0, -7, 11, 8, 0xFFE87A10); e(-5, -7, 4, 8, 0xFFFF9A2A); e(5, -7, 4, 8, 0xFFE87A10); e(0, -7, 3, 8, 0xFFFFA83A);
                r(-1, -17, 3, 4, 0xFF4A8A2A); r(2, -16, 3, 1, 0xFF4A8A2A); r(-4, -12, 1, 2, 0xFFFFC070);
            }
            case "coach" -> {
                e(0, -12, 14, 11, 0xFFE87A10); e(-6, -12, 5, 11, 0xFFFF9A2A); e(6, -12, 5, 11, 0xFFE87A10); e(0, -12, 3, 11, 0xFFFFAA3A);
                r(-4, -17, 8, 7, 0xFFD8F0FF); r(-4, -17, 8, 2, WHITE); r(0, -17, 1, 7, GOLD); r(-1, -22, 3, 3, 0xFF4A8A2A); r(-12, -9, 24, 1, GOLD);
                for (int s : new int[]{-10, 10}) { d(s, -3, 4, 0xFFC8962A); d(s, -3, 3, GOLD); d(s, -3, 1, 0xFFFFE680); r(s - 3, -3, 7, 1, 0xFFC8962A); r(s, -6, 1, 7, 0xFFC8962A); }
            }
            case "slipper" -> {
                e(0, -4, 7, 3, 0xFFC8E4F8); e(0, -5, 6, 2, 0xFFE4F4FF); r(-7, -9, 4, 6, 0xFFD8F0FF); r(-7, -9, 1, 6, WHITE); r(-2, -8, 8, 1, 0xFFB8D8F8);
                r(-6, -3, 3, 2, 0xFFB8D8F8);                                                                  // the heel
                if (!inScene || Math.sin(tm() * 0.1 + seed) > -0.3) { r(5, -5, 1, 1, WHITE); r(-6, -10, 1, 1, WHITE); r(1, -9, 1, 1, WHITE); r(2, -7, 1, 1, 0xFFFFFFFF); }
            }
            case "clock" -> {
                d(0, -10, 10, 0xFF6A3A1A); d(0, -10, 9, 0xFF8A5A3A); d(0, -10, 8, 0xFFFFF8E8);
                r(0, -17, 1, 7, INK); r(0, -11, 1, 1, INK); r(0, -10, 4, 1, INK);
                for (int i = 0; i < 12; i++) { double a = i * Math.PI / 6; r((int) Math.round(Math.cos(a) * 6.5), -10 + (int) Math.round(Math.sin(a) * 6.5), 1, 1, i % 3 == 0 ? INK : 0xFF9A8A7A); }
                r(-3, -13, 2, 1, 0x66FFFFFF);
            }
            case "crown" -> crown(0, -4);
            case "basket" -> {
                r(-6, -7, 12, 7, 0xFFB07A3A); r(-5, -10, 10, 3, 0xFF8A5A2A); r(-6, -4, 12, 1, 0xFF8A5A2A); r(-5, -8, 10, 1, WHITE);
                for (int i = 0; i < 6; i++) r(-5 + i * 2, -6 + (i % 2), 1, 2, 0xFF8A5A2A);
                r(-4, -14, 1, 5, 0xFF8A5A2A); r(3, -14, 1, 5, 0xFF8A5A2A); r(-4, -14, 8, 1, 0xFF8A5A2A);
            }
            case "sack" -> { e(0, -8, 8, 8, 0xFFD8B880); e(-2, -10, 5, 5, 0xFFE8CC98); r(-3, -17, 6, 3, 0xFFB8985A); r(-4, -15, 8, 1, 0xFF8A5A2A); r(-1, -14, 1, 3, 0xFF8A5A2A); }
            case "bun" -> {
                ball(0, -9, 9, 0xFFE8B060); d(-3, -12, 4, 0xFFF4CC80);
                r(-4, -12, 2, 2, INK); r(2, -12, 2, 2, INK); r(-4, -12, 1, 1, WHITE); r(2, -12, 1, 1, WHITE);
                r(-3, -6, 7, 1, 0xFF8A4A2A); r(-2, -5, 5, 1, 0xFF8A4A2A); r(-7, -9, 2, 2, 0x88FF7A8A); r(5, -9, 2, 2, 0x88FF7A8A);
            }
            case "trough" -> { triShade(-9, -8, 18, 8, 0xFF8A5A3A); r(-10, -9, 20, 3, 0xFFB07A3A); r(-10, -9, 20, 1, 0xFFD8A060); r(1, -7, 1, 6, 0xFF3A2A1A); r(2, -4, 2, 1, 0xFF3A2A1A); }
            case "net" -> {
                for (int i = 0; i < 9; i++) { r(-8 + i, -14 + i, 1, 1, 0xFFB8985A); r(8 - i, -14 + i, 1, 1, 0xFFB8985A); }
                for (int y = 0; y < 3; y++) r(-7 + y * 2, -12 + y * 3, 14 - y * 4, 1, 0xFFB8985A);
                r(-9, -15, 18, 1, 0xFF8A6A3A); r(0, -22, 1, 8, 0xFF7A4A2A);
            }
            case "lightning" -> {
                r(3, -20, 3, 7, 0xFFFFE680); r(0, -14, 6, 3, 0xFFFFE680); r(-3, -12, 3, 9, 0xFFFFE680); r(-4, -4, 2, 4, 0xFFFFE680);
                r(4, -20, 1, 7, WHITE); r(1, -14, 4, 1, WHITE); r(-2, -12, 1, 9, WHITE);
            }
            case "rain" -> {
                float tt = tm();
                for (int i = 0; i < 5; i++) for (int j = 0; j < 3; j++) {
                    int yy = inScene ? -22 + (int) ((tt * 0.45F + i * 5 + j * 8) % 23F) : -18 + j * 7 + i % 2 * 3;
                    r(i * 8 + j * 3 - 16, yy, 1, 4, 0xAA9AC4EC); r(i * 8 + j * 3 - 16, yy, 1, 1, 0xCCFFFFFF);
                }
            }
            case "snowflakes" -> {
                if (!inScene) { for (int i = 0; i < 6; i++) r(-20 + i * 8, -30 + (i * 7) % 20, 2, 2, WHITE); }
                else {
                    float tt = tm();
                    for (int i = 0; i < 14; i++) {                                                         // the snow falls, swaying
                        int yy = -38 + (int) ((tt * (0.10F + (i % 4) * 0.03F) + i * 7.3F) % 52F);
                        int xx = -22 + (i * 11) % 46 + Math.round((float) Math.sin(tt * 0.03 + i) * 2F);
                        int sz = i % 3 == 0 ? 2 : 1;
                        r(xx, yy, sz, sz, WHITE);
                    }
                }
            }
            case "crumbs" -> { for (int i = 0; i < 6; i++) { r(-12 + i * 5, -2 - (i % 2), 2, 2, 0xFFE8C890); r(-12 + i * 5, -2 - (i % 2), 1, 1, 0xFFFFE8B0); } }
            case "oven" -> {
                r(-12, -22, 24, 22, 0xFF8A8A9A); r(-12, -22, 24, 2, 0xFFAAAABA); r(8, -22, 4, 22, 0xFF6A6A7A);
                for (int i = 0; i < 4; i++) for (int j = 0; j < 3; j++) r(-12 + i * 6 + (j % 2) * 3, -20 + j * 6, 1, 6, 0xFF6A6A7A);
                d(0, -12, 7, 0xFF3A2A2A); r(-7, -12, 14, 12, 0xFF3A2A2A);
                for (int i = 3; i >= 1; i--) e(0, -6, 3 + i * 2, 3 + i, al(18, 0xFFA040));
                d(0, -6, inScene ? 3 + (int) Math.round((Math.sin(tm() * 0.3 + seed) + 1) / 2) : 4, 0xFFFF8A1A); d(0, -5, 2, 0xFFFFE680);
                r(-3, -26, 6, 4, 0xFF6A6A7A);
            }
            case "windowlight" -> {
                r(-7, -14, 14, 14, 0xFF6A4A3A); r(-6, -13, 12, 12, inScene && (int) (tm() / 9 + seed) % 11 == 0 ? 0xFFFFD25A : 0xFFFFE680);
                r(-6, -13, 12, 3, 0xFFFFF4B8); r(-1, -13, 1, 12, 0xFF8A6A3A); r(-6, -8, 12, 1, 0xFF8A6A3A); r(-8, -1, 16, 2, 0xFF8A5A3A);
            }
            case "crowdbed" -> {
                r(-16, -8, 32, 8, 0xFF8A5A3A); r(-16, -8, 32, 1, 0xFFB07A4A); r(-14, -12, 28, 6, 0xFFF8E8E8); r(-14, -14, 10, 5, WHITE); r(-14, -14, 10, 1, 0xFFF4F8FF); e(8, -12, 7, 4, 0xFFFF9AC8); e(6, -13, 4, 2, 0xFFFFC0DA);
            }
            default -> { }
        }
    }

    private static void tufts0() { r(14, -8, 1, 2, 0xFF9ADC80); r(-20, -6, 1, 2, 0xFF9ADC80); r(2, -10, 1, 2, 0xFF9ADC80); }

    // ---------- the public API ----------
    private static final Map<String, String[]> CACHE = new HashMap<>();
    /** Things that are light, flat or fill the air: no outline and no shadow. */
    private static final Set<String> DIRECT = Set.of("sun", "moon", "star", "cloud", "rain", "snowflakes", "lightning", "bubbles", "foam", "crumbs", "pond", "hill", "reeds", "seaweed");
    /** Things that hang on a wall or swim or fly: an outline but no shadow on the ground. */
    private static final Set<String> NO_SHADOW = Set.of("fish", "goldfish", "swallow", "fairy", "windowlight");

    private static void draw(String name, int f) {
        if (isAnimal(name)) drawAnimal(name, f); else thing(name, f);
    }

    private static boolean isAnimal(String k) {
        return switch (k) {
            case "wolf", "fox", "dog", "cat", "puss", "donkey", "hare", "bear", "rooster", "duck", "duckling", "ducklings", "swan",
                 "swallow", "toad", "mouse" -> true;
            default -> false;
        };
    }

    /** Draws one thing (a prop) by name at (x, y) (its bottom centre). size = percent. Used for the covers of the books on the shelf. */
    public static void prop(GuiGraphics g, String name, int x, int y, int size) {
        int f = 1;
        if (name.endsWith("<")) { f = -1; name = name.substring(0, name.length() - 1); }
        int bw = size > 150 ? PW : 96, bh = size > 150 ? PH : 96;                    // a small area is cheaper to process: most covers fit in it
        Arrays.fill(LAYER, 0, bw * bh, 0);
        T = LAYER; tw = bw; th = bh;
        ox = bw / 2F; oy = bh - FOOT; sc = size / 100F;
        inScene = false;
        seed = x * 7 + y * 13;
        try {
            draw(name, f);
            process(bw, bh);
            blit(g, PROC, bw, bh, x - bw / 2, y - (bh - FOOT));
        } finally {
            T = SCENE; tw = W; th = H; ox = 0; oy = 0; sc = 1F;
        }
    }

    /** Puts a thing into the picture: the light ones are painted straight into it, the others get an outline, a shadow and shading. */
    private static void place(String name, int px, int py, int size) {
        int f = 1;
        if (name.endsWith("<")) { f = -1; name = name.substring(0, name.length() - 1); }
        seed = px * 7 + py * 13 + name.hashCode();
        sc = size / 100F;
        ox = px; oy = py;
        if (DIRECT.contains(name)) {
            T = SCENE; tw = W; th = H;
            draw(name, f);
        } else {
            Arrays.fill(LAYER, 0, W * H, 0);
            T = LAYER;
            draw(name, f);
            T = SCENE;
            ox = 0; oy = 0; sc = 1F;
            process(W, H);
            if (!NO_SHADOW.contains(name)) contactShadow(W, H);
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) put(x, y, PROC[y * W + x]);
        }
        ox = 0; oy = 0; sc = 1F;
    }

    /** Draws a whole picture (W x H) at (x, y). */
    public static void scene(GuiGraphics g, String spec, int x, int y) {
        String[] parts = CACHE.computeIfAbsent(spec, k -> k.split(";"));
        clock = System.currentTimeMillis();
        inScene = true;
        T = SCENE; tw = W; th = H; ox = 0; oy = 0; sc = 1F;
        try {
            background(parts[0]);
            for (int i = 1; i < parts.length; i++) {
                String p = parts[i];
                int at = p.indexOf('@');
                if (at < 0) continue;
                String[] n = p.substring(at + 1).split(",");
                try {
                    place(p.substring(0, at), Integer.parseInt(n[0].trim()), Integer.parseInt(n[1].trim()), n.length > 2 ? Integer.parseInt(n[2].trim()) : 100);
                } catch (NumberFormatException ignored) {
                    // a typo in a picture must not crash the game: the thing is just not drawn
                }
            }
            T = SCENE; tw = W; th = H; ox = 0; oy = 0; sc = 1F;
            vignette();
            blit(g, SCENE, W, H, x, y);
        } finally {
            inScene = false;
            T = SCENE; tw = W; th = H; ox = 0; oy = 0; sc = 1F;
        }
    }
}
