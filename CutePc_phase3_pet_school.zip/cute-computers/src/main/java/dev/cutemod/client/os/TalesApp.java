package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.IntUnaryOperator;

/**
 * Fairy Tales: a shelf with twelve books (Andersen, Grimm, Perrault, Pushkin, a Russian folk tale). Open one and read it
 * like a real book: two pages, a picture on every scene, and the pages turn. Click the right page (or press the right arrow)
 * to turn forward, the left page (left arrow) to go back. Reading a tale to its end for the first time pays 2 coins.
 * <p>
 * The text never leaves the page: it is cut into lines by the real width of the font ({@link CuteFont#width}), and the
 * lines are cut into pages by the height of the page. A scene that is longer than its spread simply goes on over the next
 * pages, so a long translation or a big font only makes the book thicker. Saved: "tales" (finished tales), "tales_mark"
 * (where you stopped) and "tales_sticker" (the Storyteller sticker of the Sticker Book was given).
 * <p>
 * The books are collected: two are on the shelf from the start, the others are found as pages in other apps or bought ({@link TaleBooks}).
 * The shelf shows an empty place with the pages found so far; a click opens a small card with the price.
 * <p>
 * Cosiness: page, book and shelf sounds and a quiet background for every scene with a music box lullaby ({@link TaleAudio});
 * a wooden table, a warm lamp, a candle, dust in the light, and at night (by the time of the Minecraft world) a blue night with
 * the moon in the window ({@link ReadingRoom}); pages that bend and cast a shadow, the thickness of the book, a ribbon bookmark;
 * a drop cap and flourishes; living pictures ({@link BookArt}); a seal on every tale that is read and a sticker for all twelve.
 * <p>
 * The room lives with the reader: the candle burns down while you read (the stub is saved for the day: "tales_candle"), the lamp and
 * the flame sink and the dust slows when you are away for a couple of minutes, at the end of a tale the flame gutters and the lullaby
 * dies away. Some scenes have sounds of their own ({@link TaleAudio#cues}: a howl, a clock that strikes twelve, thunder with a flash
 * of lightning). Every tale has its own look: the colour of its book tints the paper, the frame, the flourishes and the numbers, and
 * the emblem of its theme (a wave, a leaf, a star, a flower, a sun) sits in the corners and on the plate of the drop cap.
 */
public class TalesApp extends KitApp {
    // the open book: two pages and a spine
    private static final int BX = 8, BY = 18, BW = 284, BH = 140, PW = 138, SPINE = 8;
    private static final int TX = 9, TW = 120, LINE = 9;                  // text: margin, width, line height
    private static final int TOP = BY + 8, BOTTOM = BY + BH - 14;          // where the text of a page may be
    private static final int PIC_Y = TOP, PIC_H = BookArt.H;
    private static final int LEFT_LINES = (BOTTOM - (PIC_Y + PIC_H + 4)) / LINE;   // under the picture
    private static final int FULL_LINES = (BOTTOM - TOP) / LINE;                   // a whole page
    private static final int FLIP = 16;                                    // ticks of a page turn
    private static final double CURL = 0.9;                                // how much a turning page bends (radians)
    private static final int LIFT = 5;                                     // how much its free edge rises towards the reader
    private static final int DROP_LINES = 2;                               // the drop cap is two lines high
    private static final int PAPER = 0xFFFFF8E8, INK = 0xFF4A3A3A, ORNAMENT = 0xFFD9B35A;
    private static final int REWARD = 2;
    private static final int IDLE = 2400;                              // ticks without the reader (2 minutes) before the room falls asleep
    private static final int BURN_ALL = 12000;                         // ticks of reading (10 minutes) that burn a candle down to a stub
    private static final int GUTTER = 34;                              // ticks the flame gutters at the end of a tale

    /** One open book spread: the left and the right page. kind 0 = the title, 1 = the story, 2 = the end. */
    static final class Spread {
        final int kind, scene;                                       // scene: the picture on the left page, -1 = none
        final List<String> left = new ArrayList<>(), right = new ArrayList<>();
        char cap;                                                    // the drop cap of the tale (the first spread only), 0 = none
        int capW;
        boolean endL, endR;                                          // the scene ends on the left / on the right page

        Spread(int kind, int scene) { this.kind = kind; this.scene = scene; }
    }

    private int tale = -1;                                           // the open book, -1 = the shelf
    private final List<Spread> spreads = new ArrayList<>();
    private String builtKey = "";
    private int cur, flipTo = -1, flipT, hover = -1, knockT = -1;
    private int buying = -1, panelMsgT;                              // the card of a book that is not on the shelf yet (-1 = none)
    private String panelMsg = "";
    private boolean justEarned, justSticker;
    private final Set<String> done = new LinkedHashSet<>();
    private String markId = "";
    private int markSpread;
    private boolean loaded;
    private int burnT, savedBurn, idle, flicker, flash, gutterT, shownIdx = -1, lastMx = -1, lastMy = -1;
    private float calm, dustT, lastTm = -1F;
    private final List<Pending> pending = new ArrayList<>();

    /** A cue of the scene that waits for its moment. */
    private static final class Pending {
        final TaleAudio.Cue cue;
        int left;

        Pending(TaleAudio.Cue cue) { this.cue = cue; this.left = cue.delay(); }
    }

    @Override protected int accent() { return 0xFFC8905A; }

    @Override protected String id() { return "tales"; }

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        load();
    }

    private void load() {
        loaded = true;
        done.clear();
        String s = Store.read("tales");
        if (s != null) for (String id : s.split(",")) if (find(id) >= 0) done.add(id);
        String m = Store.read("tales_mark");
        if (m != null && m.contains(":")) {
            try {
                markId = m.substring(0, m.indexOf(':'));
                markSpread = Integer.parseInt(m.substring(m.indexOf(':') + 1));
            } catch (NumberFormatException e) {
                markId = "";
            }
        }
        burnT = 0;                                                   // today's candle
        String cd = Store.read("tales_candle");
        if (cd != null && cd.contains(":")) {
            try {
                if (Long.parseLong(cd.substring(cd.indexOf(':') + 1)) == LocalDate.now().toEpochDay()) burnT = Math.min(BURN_ALL, Integer.parseInt(cd.substring(0, cd.indexOf(':'))));
            } catch (NumberFormatException e) {
                burnT = 0;
            }
        }
        savedBurn = burnT;
        if (Store.ready()) award();                                  // all twelve were read before the sticker existed
    }

    private void saveBurn() {
        if (burnT == savedBurn) return;
        savedBurn = burnT;
        Store.write("tales_candle", burnT + ":" + LocalDate.now().toEpochDay());
    }

    private static int find(String id) {
        for (int i = 0; i < Tales.ALL.size(); i++) if (Tales.ALL.get(i).id().equals(id)) return i;
        return -1;
    }

    /** All twelve tales are read: the Storyteller sticker goes to the Sticker Book (once). */
    private boolean award() {
        if (done.size() < Tales.ALL.size() || "1".equals(Store.read("tales_sticker"))) return false;
        Store.write("tales_sticker", "1");
        Progress.toast("cutemod.toast.tales_sticker");
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.5F, 0.6F);
        return true;
    }

    // ---------- laying the text out ----------
    /** The text cut into lines no wider than "width" pixels in the font that is really used. Words wider than a line are broken. */
    static List<String> wrap(Font f, String text, int width) { return wrapVar(f, text, i -> width); }

    /** The same, but the width may change from line to line (the first lines are shorter next to a drop cap). */
    static List<String> wrapVar(Font f, String text, IntUnaryOperator widthOf) {
        List<String> out = new ArrayList<>();
        for (String para : text.split("\n")) {
            StringBuilder line = new StringBuilder();
            for (String word : para.split(" ")) {
                if (word.isEmpty()) continue;
                int width = widthOf.applyAsInt(out.size());
                while (CuteFont.width(f, word) > width) {
                    if (line.length() > 0) { out.add(line.toString()); line.setLength(0); width = widthOf.applyAsInt(out.size()); }
                    int n = word.length();
                    while (n > 1 && CuteFont.width(f, word.substring(0, n) + "-") > width) n--;
                    out.add(word.substring(0, n) + "-");
                    word = word.substring(n);
                    width = widthOf.applyAsInt(out.size());
                }
                String attempt = line.length() == 0 ? word : line + " " + word;
                if (CuteFont.width(f, attempt) <= width) { line.setLength(0); line.append(attempt); }
                else { out.add(line.toString()); line.setLength(0); line.append(word); }
            }
            if (line.length() > 0) out.add(line.toString());
        }
        return out;
    }

    private static int take(List<String> from, int i, List<String> to, int max) {
        while (i < from.size() && to.size() < max) to.add(from.get(i++));
        return i;
    }

    /** All the spreads of the tale: the title, the scenes (picture + text, going on over more pages if needed), the end. */
    static List<Spread> layout(Font f, Tales.Tale tl, java.util.function.Function<String, String> text) {
        List<Spread> out = new ArrayList<>();
        out.add(new Spread(0, -1));
        for (int s = 0; s < Tales.SCENES; s++) {
            String txt = text.apply("cutemod.tale." + tl.id() + ".s" + (s + 1));
            final int dropLines = s == 0 && !txt.isEmpty() && Character.isLetter(txt.charAt(0)) ? DROP_LINES : 0;
            char cap = 0;
            int capW = 0;
            if (dropLines > 0) {                                     // the first letter of the tale is a big decorated one
                cap = txt.charAt(0);
                capW = Math.max(14, Math.min(26, CuteFont.width(f, String.valueOf(Character.toUpperCase(cap))) * 2 + 6));
                txt = txt.substring(1);
            }
            final int narrow = TW - capW - 3;
            List<String> lines = wrapVar(f, txt, i -> i < dropLines ? narrow : TW);
            Spread first = new Spread(1, s);
            first.cap = cap;
            first.capW = capW;
            int i = take(lines, 0, first.left, LEFT_LINES);
            i = take(lines, i, first.right, FULL_LINES);
            if (i >= lines.size()) { if (first.right.isEmpty()) first.endL = true; else first.endR = true; }
            out.add(first);
            while (i < lines.size()) {
                Spread more = new Spread(1, -1);
                i = take(lines, i, more.left, FULL_LINES);
                i = take(lines, i, more.right, FULL_LINES);
                if (i >= lines.size()) { if (more.right.isEmpty()) more.endL = true; else more.endR = true; }
                out.add(more);
            }
        }
        out.add(new Spread(2, -1));
        return out;
    }

    private void build(Font f) {
        Tales.Tale tl = Tales.ALL.get(tale);
        String key = tale + "|" + CuteFont.width(f, "MWmw\u0416\u044B\u0429 0123") + "|" + t("cutemod.tale." + tl.id() + ".s1").hashCode();
        if (key.equals(builtKey) && !spreads.isEmpty()) return;
        builtKey = key;
        spreads.clear();
        spreads.addAll(layout(f, tl, k -> t(k)));
        if (cur >= spreads.size()) cur = spreads.size() - 1;
    }

    // ---------- opening, turning, finishing ----------
    private void open(int i) {
        if (!TaleBooks.owns(Tales.ALL.get(i).id())) return;
        tale = i;
        cur = 0;
        flipTo = -1;
        justEarned = false;
        justSticker = false;
        shownIdx = -1;
        pending.clear();
        gutterT = 0;
        builtKey = "";
        spreads.clear();
        build(font());
        if (Tales.ALL.get(i).id().equals(markId) && markSpread > 0 && markSpread < spreads.size() - 1) cur = markSpread;
        TaleAudio.open();
    }

    private void toShelf() {
        saveBurn();
        pending.clear();
        shownIdx = -1;
        flash = 0;
        tale = -1;
        buying = -1;
        flipTo = -1;
        TaleAudio.close();
        knockT = 9;                                                  // the knock of the shelf comes a moment after the book closes
    }

    private void go(int to) {
        if (flipTo >= 0 || to < 0 || to >= spreads.size()) return;
        flipTo = to;
        flipT = 0;
        TaleAudio.page();
    }

    private void arrived() {
        String id = Tales.ALL.get(tale).id();
        markId = id;
        markSpread = cur;
        Store.write("tales_mark", id + ":" + cur);
        if (cur == spreads.size() - 1 && !done.contains(id)) {
            done.add(id);
            Store.write("tales", String.join(",", done));
            Progress.earn(REWARD);
            justEarned = true;
            justSticker = award();
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (panelMsgT > 0) panelMsgT--;
        if (flipTo >= 0 && ++flipT >= FLIP) {
            cur = flipTo;
            flipTo = -1;
            arrived();
        }
        if (knockT > 0 && --knockT == 0) { TaleAudio.shelf(); knockT = -1; }
        life();
        audio();
    }

    /** The room lives with the reader: the candle burns, the light sleeps when nobody is there, the scenes make their sounds. */
    private void life() {
        if (idle < 1_000_000) idle++;
        if (idle > IDLE) calm += (1F - calm) * 0.004F;                     // slowly falls asleep
        else calm -= calm * 0.12F;                                          // wakes up fast
        if (calm < 0.002F) calm = 0F;
        if (flicker > 0) flicker--;
        if (flash > 0) flash--;
        if (gutterT > 0) gutterT--;
        if (tale < 0 || spreads.isEmpty()) { pending.clear(); shownIdx = -1; return; }
        if (idle < IDLE) {
            if (burnT < BURN_ALL) burnT++;
            if (burnT % 600 == 0) saveBurn();
        }
        int idx = Math.min(flipTo >= 0 && flipT > FLIP / 2 ? flipTo : cur, spreads.size() - 1);
        if (idx != shownIdx) {                                              // a new spread came on the page
            shownIdx = idx;
            pending.clear();
            Spread sp = spreads.get(idx);
            if (sp.kind == 1 && sp.scene >= 0) for (TaleAudio.Cue c : TaleAudio.cues(Tales.ALL.get(tale).id(), sp.scene)) pending.add(new Pending(c));
            if (sp.kind == 2) gutterT = GUTTER;                             // the flame gutters at the end
        }
        for (int i = pending.size() - 1; i >= 0; i--) {
            Pending p = pending.get(i);
            if (--p.left > 0) continue;
            pending.remove(i);
            TaleAudio.cue(p.cue);
            switch (p.cue.fx()) {
                case "flash" -> flash = 10;
                case "flash2" -> flash = 5;
                case "dim" -> flicker = 8;
                default -> { }
            }
        }
    }

    /** 1 = a steady flame; at the end of a tale it sinks for a moment and comes back. */
    private float gut() {
        return gutterT <= 0 ? 1F : 1F - 0.8F * (float) Math.sin(Math.PI * (1F - gutterT / (float) GUTTER));
    }

    /** The quiet background follows the scene on the page (the one that is turning in counts from the middle of the turn). */
    private void audio() {
        if (!loaded) return;
        if (tale < 0 || spreads.isEmpty()) { TaleAudio.keep(TaleAudio.shelfMood()); return; }
        int idx = Math.min(flipTo >= 0 && flipT > FLIP / 2 ? flipTo : cur, spreads.size() - 1);
        TaleAudio.keep(TaleAudio.mood(Tales.ALL.get(tale), sceneAt(idx), spreads.get(idx).kind == 2));
    }

    /** The scene of this spread (the pages that go on after a picture belong to its scene); -1 for the title and the end. */
    private int sceneAt(int idx) {
        for (int i = Math.min(idx, spreads.size() - 1); i >= 0; i--) {
            Spread s = spreads.get(i);
            if (s.kind != 1) return -1;
            if (s.scene >= 0) return s.scene;
        }
        return -1;
    }

    // ---------- input ----------
    private static int coverX(int i) { return 9 + (i % 6) * 48; }

    private static int coverY(int i) { return 20 + (i / 6) * 62; }

    @Override
    public boolean click(int x, int y, int button) {
        idle = 0;
        if (tale < 0) {
            if (buying >= 0) { buyClick(x, y); return true; }
            for (int i = 0; i < Tales.ALL.size(); i++) {
                if (!in(x, y, coverX(i), coverY(i) - 3, 42, 55)) continue;
                if (TaleBooks.owns(Tales.ALL.get(i).id())) open(i);
                else { buying = i; panelMsgT = 0; Sfx.click(); }
                return true;
            }
            return false;
        }
        if (in(x, y, W - 54, 1, 50, 12)) { toShelf(); return true; }
        if (flipTo >= 0 || !in(x, y, BX, BY, BW, BH)) return true;
        if (x < BX + PW + SPINE / 2) go(cur - 1);
        else if (cur >= spreads.size() - 1) toShelf();
        else go(cur + 1);
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        idle = 0;
        if (tale < 0) {
            if (buying >= 0 && (keyCode == 256 || keyCode == 259)) { buying = -1; return true; }          // Esc or Backspace close the card
            return false;
        }
        if (keyCode == 263) { go(cur - 1); return true; }                         // left arrow
        if (keyCode == 262) { if (cur >= spreads.size() - 1) toShelf(); else go(cur + 1); return true; }   // right arrow
        if (keyCode == 259) { toShelf(); return true; }                           // backspace
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        idle = 0;
        if (tale < 0) return false;
        go(amount > 0 ? cur - 1 : cur + 1);
        return true;
    }

    // ---------- drawing ----------
    private static void ctext(GuiGraphics g, Font f, String s, int cx, int y, int color) {
        CuteFont.draw(g, f, s, cx - CuteFont.width(f, s) / 2, y, color, false);
    }

    private static String trunc(Font f, String s, int max) {
        if (CuteFont.width(f, s) <= max) return s;
        int n = s.length();
        while (n > 1 && CuteFont.width(f, s.substring(0, n) + "...") > max) n--;
        return s.substring(0, n) + "...";
    }

    /** A red wax seal with a gold star: the stamp of a tale that was read. */
    private static void seal(GuiGraphics g, int cx, int cy, int rad) {
        disc(g, cx, cy, rad, 0xFF8E1F2C);
        disc(g, cx, cy, rad - 1, 0xFFD8404E);
        disc(g, cx, cy, Math.max(1, rad - 3), 0xFFB82E3C);
        int gold = 0xFFFFD84A;
        g.fill(cx, cy - rad / 2, cx + 1, cy + rad / 2 + 1, gold);
        g.fill(cx - rad / 2, cy, cx + rad / 2 + 1, cy + 1, gold);
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, gold);
        g.fill(cx - 2, cy - 2, cx - 1, cy - 1, gold); g.fill(cx + 2, cy - 2, cx + 3, cy - 1, gold);
        g.fill(cx - 2, cy + 2, cx - 1, cy + 3, gold); g.fill(cx + 2, cy + 2, cx + 3, cy + 3, gold);
        g.fill(cx - rad + 1, cy - rad + 2, cx - rad + 3, cy - rad + 3, 0x66FFFFFF);        // a glint
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        if (mx != lastMx || my != lastMy) { lastMx = mx; lastMy = my; idle = 0; }
        if (tale < 0) { renderShelf(g, f, mx, my); return; }
        build(f);
        renderBook(g, f, mx, my);
    }

    private static final int[] BANDS = {7, 24, 41};

    /**
     * A book on the shelf, 42 x 52: a rounded spine with gold bands, a board that fades from light to dark with a faint grain and
     * the pattern of its theme, a double gold frame, a medallion with the hero of the tale, the emblem of the theme and the pages
     * showing at the right and at the bottom. A ribbon marks a tale that was read; a bookmark sticks out of one in the middle of reading.
     */
    private void cover(GuiGraphics g, Tales.Tale tl, int x, int y, boolean lifted, boolean read, boolean reading) {
        int c = tl.cover(), th = ReadingRoom.themeOf(tl.id());
        int deep = ReadingRoom.tint(c, 0x000000, 0.55F), dark = ReadingRoom.tint(c, 0x000000, 0.35F), light = ReadingRoom.tint(c, 0xFFFFFF, 0.3F);
        int gold = 0xFFFFD84A, goldD = 0xFFC8962A;
        if (lifted) for (int k = 4; k >= 1; k--) rect(g, x - k, y - k, 42 + 2 * k, 52 + 2 * k, ReadingRoom.argb(0.05F, 0xFFD890));   // a warm halo
        if (reading && !read) {                                                  // a bookmark sticks out of the top: you are in the middle of it
            rect(g, x + 29, y - 5, 5, 9, 0xFF3FA04A); rect(g, x + 29, y - 5, 1, 9, 0xFF6AC86A);
            rect(g, x + 30, y + 2, 3, 2, c);
        }
        rect(g, x + 2, y + 2, 40, 50, 0xFFF4ECD6);                               // the block of pages: it shows at the right and at the bottom
        for (int i = 3; i < 50; i += 3) rect(g, x + 41, y + i, 1, 1, 0xFFD0C098);
        for (int i = 4; i < 42; i += 3) rect(g, x + i, y + 51, 1, 1, 0xFFD0C098);
        rect(g, x + 41, y + 2, 1, 1, 0xFFD8C8A0);
        int top = ReadingRoom.tint(c, 0xFFFFFF, 0.14F), bot = ReadingRoom.tint(c, 0x000000, 0.25F);
        for (int yy = 0; yy < 50; yy++) rect(g, x + 6, y + yy, 34, 1, ReadingRoom.tint(top, bot, yy / 49F));   // the board
        int seed = tl.id().hashCode();
        for (int i = 0; i < 46; i++) {                                           // the grain of the cloth
            int hv = ReadingRoom.hash(seed + i * 7919);
            rect(g, x + 7 + hv % 31, y + 1 + (hv >> 8) % 47, 1 + (hv >> 17) % 2, 1, ReadingRoom.argb(0.11F, i % 2 == 0 ? 0x000000 : 0xFFFFFF));
        }
        ReadingRoom.pattern(g, th, x + 6, y, 34, 50, ReadingRoom.argb(0.10F, 0xFFFFFF));
        rect(g, x, y, 6, 50, c);                                                 // the spine
        rect(g, x, y, 1, 50, deep); rect(g, x + 1, y, 1, 50, dark); rect(g, x + 3, y, 1, 50, light);
        rect(g, x + 4, y, 1, 50, ReadingRoom.tint(c, 0xFFFFFF, 0.12F)); rect(g, x + 5, y, 1, 50, deep);
        for (int by : BANDS) { rect(g, x + 1, y + by, 4, 1, gold); rect(g, x + 1, y + by + 1, 4, 1, goldD); }
        rect(g, x + 9, y + 3, 28, 1, gold); rect(g, x + 9, y + 46, 28, 1, gold);   // the double gold frame
        rect(g, x + 9, y + 3, 1, 44, gold); rect(g, x + 36, y + 3, 1, 44, gold);
        int thin = ReadingRoom.argb(0.5F, 0xFFD84A);
        rect(g, x + 11, y + 5, 24, 1, thin); rect(g, x + 11, y + 44, 24, 1, thin);
        rect(g, x + 11, y + 5, 1, 40, thin); rect(g, x + 34, y + 5, 1, 40, thin);
        rect(g, x + 8, y + 2, 2, 2, gold); rect(g, x + 35, y + 2, 2, 2, gold);
        rect(g, x + 8, y + 45, 2, 2, gold); rect(g, x + 35, y + 45, 2, 2, gold);
        for (int i = 0; i < 5; i += 2) {                                         // dotted lines and the emblem of the theme, above and below
            rect(g, x + 13 + i, y + 8, 1, 1, gold); rect(g, x + 29 + i, y + 8, 1, 1, gold);
            rect(g, x + 13 + i, y + 42, 1, 1, gold); rect(g, x + 29 + i, y + 42, 1, 1, gold);
        }
        ReadingRoom.motif(g, th, x + 23, y + 8, gold);
        ReadingRoom.motif(g, th, x + 23, y + 42, gold);
        disc(g, x + 23, y + 26, 12, goldD);                                      // the medallion with the hero
        disc(g, x + 23, y + 26, 11, gold);
        disc(g, x + 23, y + 26, 10, ReadingRoom.tint(0xFFFFF4D8, c, 0.10F));
        disc(g, x + 23, y + 25, 7, ReadingRoom.tint(0xFFFFFAE8, c, 0.04F));
        BookArt.prop(g, tl.prop(), x + 23, y + 36, tl.propSize() * 6 / 10);
        rect(g, x + 6, y, 34, 1, ReadingRoom.argb(lifted ? 0.45F : 0.30F, 0xFFFFFF));   // the gloss and the edges
        rect(g, x + 39, y, 1, 50, ReadingRoom.argb(0.22F, 0x000000));
        rect(g, x + 6, y + 49, 34, 1, ReadingRoom.argb(0.25F, 0x000000));
        for (int k = 0; k < 14; k++) rect(g, x + 8 + k, y + 14 - k, 2, 1, ReadingRoom.argb(0.10F, 0xFFFFFF));
        if (read) {
            rect(g, x + 35, y, 4, 9, 0xFFE5484D); rect(g, x + 35, y + 9, 2, 2, 0xFFE5484D);   // a ribbon: read
            rect(g, x + 35, y, 1, 9, 0xFFFF8A90);
            seal(g, x + 12, y + 42, 6);                                                         // and the seal
        }
    }

    /** An empty place on the shelf: a dark niche with the ghost of the cover, a dotted gold outline, the pages found so far and five gems. */
    private void locked(GuiGraphics g, Font f, Tales.Tale tl, int x, int y, boolean lifted) {
        int mask = TaleBooks.mask(tl.id()), n = Integer.bitCount(mask);
        rect(g, x, y, 42, 52, ReadingRoom.argb(lifted ? 0.34F : 0.26F, 0x000000));                // a dark niche where the book will stand
        rect(g, x + 6, y + 1, 34, 49, ReadingRoom.argb(lifted ? 0.30F : 0.17F, tl.cover()));      // the ghost of its cover: you can guess the colour
        int dot = lifted ? 0xFFFFD84A : 0x99C8A050;
        for (int i = 0; i < 42; i += 4) { rect(g, x + i, y, 2, 1, dot); rect(g, x + i, y + 51, 2, 1, dot); }
        for (int i = 0; i < 52; i += 4) { rect(g, x, y + i, 1, 2, dot); rect(g, x + 41, y + i, 1, 2, dot); }
        for (int k = 0; k < n; k++) {                                            // the pages that were found lie in the place of the book
            int px = x + 7 + k * 5, py = y + 9 + (k % 2) * 3;
            rect(g, px + 1, py + 1, 13, 19, 0x33000000);
            rect(g, px, py, 13, 19, 0xFFD8C8A0);
            rect(g, px + 1, py + 1, 11, 17, PAPER);
            for (int l = 0; l < 4; l++) rect(g, px + 2, py + 3 + l * 4, 8, 1, 0x33000000);
        }
        if (n == 0) {
            g.pose().pushPose();
            g.pose().translate(x + 21 - CuteFont.width(f, "?"), y + 14, 0);
            g.pose().scale(2F, 2F, 1F);
            CuteFont.draw(g, f, "?", 0, 0, lifted ? 0xFFFFD84A : 0xAAC8A050, false);
            g.pose().popPose();
        }
        for (int s = 0; s < Tales.SCENES; s++) {                                 // five gems: one for every page
            boolean has = (mask & (1 << s)) != 0;
            int gx = x + 7 + s * 7, gy = y + 44, col = has ? 0xFFFFD84A : 0x55000000, hi = has ? 0xFFFFF4B0 : 0x22FFFFFF;
            rect(g, gx - 1, gy - 2, 3, 1, col); rect(g, gx - 2, gy - 1, 5, 3, col); rect(g, gx - 1, gy + 2, 3, 1, col);
            rect(g, gx - 1, gy - 1, 1, 1, hi);
        }
    }

    /** A brass-framed paper plate at the foot of the bookcase: one or two lines of text. */
    private void plaque(GuiGraphics g, Font f, String l1, int c1, String l2, int c2) {
        int x = 34, w = W - 68, y = 144, h = 20;
        rect(g, x - 2, y - 2, w + 4, h + 4, 0xFFC89A3A);
        rect(g, x - 1, y - 1, w + 2, h + 2, 0xFF6A4A1A);
        rect(g, x, y, w, h, 0xFFF6E8CC);
        rect(g, x, y, w, 1, 0x55FFFFFF);
        rect(g, x - 2, y - 2, 2, 2, 0xFFFFE08A); rect(g, x + w, y - 2, 2, 2, 0xFFFFE08A);           // the little rivets
        rect(g, x - 2, y + h, 2, 2, 0xFFFFE08A); rect(g, x + w, y + h, 2, 2, 0xFFFFE08A);
        if (l2 == null) ctext(g, f, trunc(f, l1, w - 10), W / 2, y + 6, c1);
        else {
            ctext(g, f, trunc(f, l1, w - 10), W / 2, y + 3, c1);
            ctext(g, f, trunc(f, l2, w - 10), W / 2, y + 12, c2);
        }
    }

    private void renderShelf(GuiGraphics g, Font f, int mx, int my) {
        hover = -1;
        for (int i = 0; i < Tales.ALL.size(); i++) if (buying < 0 && in(mx, my, coverX(i), coverY(i) - 3, 42, 55)) hover = i;
        header(g, f);
        String cnt = CuteFont.cut(f, t("cutemod.tales.collection", TaleBooks.owned(), Tales.ALL.size(), done.size()), W - 70);
        int cw = CuteFont.width(f, cnt);
        CuteFont.draw(g, f, cnt, W - 6 - cw, 3, 0xFFFFFFFF, false);
        if (!done.isEmpty()) seal(g, W - 14 - cw, 7, 5);
        float night = ReadingRoom.nightness(), tm = ReadingRoom.clock();
        ReadingRoom.bookcase(g, W, H, new int[]{coverY(0) + 52, coverY(6) + 52}, night);       // the bookcase, the planks, the cabinet
        for (int i = 0; i < Tales.ALL.size(); i++) {
            Tales.Tale tl = Tales.ALL.get(i);
            boolean has = TaleBooks.owns(tl.id());
            int x = coverX(i), y = coverY(i) - (hover == i && has ? 3 : 0);
            if (has) {
                rect(g, x + 42, coverY(i) + 3, 3, 49, 0x28000000); rect(g, x + 45, coverY(i) + 4, 2, 48, 0x14000000);   // the shadow on the back wall
                rect(g, x + 1, coverY(i) + 52, 44, 2, 0x55000000);                                                       // and on the plank
                cover(g, tl, x, y, hover == i, done.contains(tl.id()), tl.id().equals(markId) && markSpread > 0);
            } else {
                locked(g, f, tl, x, coverY(i), hover == i);
            }
        }
        if (night > 0.01F) rect(g, 0, 14, W, 128, ((int) (0x34 * night) << 24) | 0x0A1038);     // the blue of the night
        ReadingRoom.shelfLight(g, W, coverY(6) + 52, night, tm);
        ReadingRoom.dust(g, W, coverY(6) + 52, night, tm);
        if (hover >= 0) {
            Tales.Tale tl = Tales.ALL.get(hover);
            String title = t("cutemod.tale." + tl.id() + ".title");
            if (TaleBooks.owns(tl.id())) plaque(g, f, title, TEXT, t("cutemod.tale.author." + tl.author()), MUTED);
            else plaque(g, f, title, TEXT, t("cutemod.tales.locked", TaleBooks.found(tl.id()), Tales.SCENES, TaleBooks.price(tl.id())), 0xFFB8743A);
        } else if (done.size() == Tales.ALL.size()) {
            plaque(g, f, t("cutemod.tales.all"), 0xFFB8743A, null, 0);
        } else {
            plaque(g, f, t("cutemod.tales.pick"), MUTED, null, 0);
        }
        footer(g, f);
        if (buying >= 0) renderBuy(g, f, mx, my);
    }

    // ---------- the card of a book that is not on the shelf yet ----------
    private static final int CX = 40, CY = 20, CW = 220, CH = 132;

    private static boolean pill(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, String label, boolean enabled, boolean main) {
        boolean hov = enabled && mx >= x && mx < x + w && my >= y && my < y + 16;
        int bg = !enabled ? 0xFFE9E2F2 : main ? (hov ? 0xFFA8743A : 0xFFC8905A) : hov ? 0xFFFFEFF8 : 0xFFFFFFFF;
        rect(g, x, y, w, 16, bg);
        rect(g, x, y + 14, w, 2, !enabled ? 0xFFB9A8C8 : main ? 0x33000000 : 0xFFB9A8C8);
        String l = CuteFont.cut(f, label, w - 6);
        CuteFont.draw(g, f, l, x + (w - CuteFont.width(f, l)) / 2, y + 4, !enabled ? 0xFFB8A8D8 : main ? 0xFFFFFFFF : TEXT, false);
        return hov;
    }

    private void renderBuy(GuiGraphics g, Font f, int mx, int my) {
        Tales.Tale tl = Tales.ALL.get(buying);
        int mask = TaleBooks.mask(tl.id()), n = Integer.bitCount(mask), price = TaleBooks.price(tl.id());
        rect(g, 0, 14, W, H - 14, 0xCC1E1438);
        rect(g, CX - 1, CY - 1, CW + 2, CH + 2, 0xFFC8905A);
        rect(g, CX, CY, CW, CH, paperC(tl));
        int gl = ReadingRoom.argb(0.7F, 0xFFD84A);                                  // a thin gold frame inside the card and the emblem of the tale
        rect(g, CX + 3, CY + 3, CW - 6, 1, gl); rect(g, CX + 3, CY + CH - 4, CW - 6, 1, gl);
        rect(g, CX + 3, CY + 3, 1, CH - 6, gl); rect(g, CX + CW - 4, CY + 3, 1, CH - 6, gl);
        ReadingRoom.runner(g, CX + 12, CY + 6, CW - 24, ReadingRoom.tint(0xFFE0CFA0, tl.cover(), 0.45F) & 0xFFFFFF | 0xAA000000, ReadingRoom.themeOf(tl.id()));
        cover(g, tl, CX + 10, CY + 12, false, false, false);
        rect(g, CX + 10, CY + 12, 42, 52, 0x66F3E2C8);                             // faded: it is not yours yet
        int tx = CX + 62, tw = CW - 72;
        CuteFont.draw(g, f, trunc(f, t("cutemod.tale." + tl.id() + ".title"), tw), tx, CY + 10, TEXT, false);
        CuteFont.draw(g, f, trunc(f, t("cutemod.tale.author." + tl.author()), tw), tx, CY + 21, MUTED, false);
        for (int s = 0; s < Tales.SCENES; s++) {                                   // the five pages
            boolean has = (mask & (1 << s)) != 0;
            rect(g, tx + s * 14, CY + 36, 11, 15, has ? 0xFFD8C8A0 : 0xFFE6DCC4);
            rect(g, tx + s * 14 + 1, CY + 37, 9, 13, has ? 0xFFFFF8E8 : 0xFFEFE6D2);
            if (has) { rect(g, tx + s * 14 + 3, CY + 40, 5, 1, 0x44000000); rect(g, tx + s * 14 + 3, CY + 43, 5, 1, 0x44000000); rect(g, tx + s * 14 + 3, CY + 46, 3, 1, 0x44000000); }
            else CuteFont.draw(g, f, "?", tx + s * 14 + 3, CY + 39, 0xFFB8A888, false);
        }
        if (panelMsgT > 0) CuteFont.draw(g, f, trunc(f, panelMsg, tw), tx, CY + 54, 0xFFC0392B, false);
        else CuteFont.draw(g, f, trunc(f, t("cutemod.tales.pages", n, Tales.SCENES), tw), tx, CY + 54, 0xFFB8743A, false);
        List<String> where = wrap(f, t("cutemod.tales.where"), CW - 20);
        if (where.size() > 5) {                                                   // never runs over the buttons: the end is cut with "..."
            String rest = String.join(" ", where.subList(4, where.size()));
            where = new ArrayList<>(where.subList(0, 4));
            where.add(trunc(f, rest, CW - 20));
        }
        for (int i = 0; i < where.size(); i++) CuteFont.draw(g, f, where.get(i), CX + 10, CY + 66 + i * LINE, MUTED, false);
        boolean can = Progress.coins() >= price;
        pill(g, f, mx, my, CX + 10, CY + 114, 142, t("cutemod.tales.buy", price), true, can);
        pill(g, f, mx, my, CX + 158, CY + 114, CW - 168, t("cutemod.tales.close"), true, false);
    }

    private void buyClick(int x, int y) {
        Tales.Tale tl = Tales.ALL.get(buying);
        if (!in(x, y, CX, CY, CW, CH)) { buying = -1; return; }
        if (in(x, y, CX + 158, CY + 114, CW - 168, 16)) { buying = -1; Sfx.click(); return; }
        if (!in(x, y, CX + 10, CY + 114, 142, 16)) return;
        if (Progress.coins() < TaleBooks.price(tl.id())) { panelMsg = t("cutemod.tales.nocoins"); panelMsgT = 150; Sfx.click(); return; }
        if (TaleBooks.buy(tl.id())) {
            buying = -1;
            say("cutemod.tales.bought", t("cutemod.tale." + tl.id() + ".title"));
        }
    }

    /** The paper of a tale: warm white with a breath of the colour of its book. */
    private static int paperC(Tales.Tale tl) { return ReadingRoom.tint(PAPER, tl.cover(), 0.05F); }

    private void paper(GuiGraphics g, Tales.Tale tl, int x, int w, boolean rightPage) {
        int theme = ReadingRoom.themeOf(tl.id());
        rect(g, x, BY, w, BH, paperC(tl));
        int c = ReadingRoom.tint(0xFFE6D8B0, tl.cover(), 0.4F);                 // the filigree in the colour of the tale
        ReadingRoom.corner(g, rightPage ? x + w - 4 : x + 3, BY + 3, rightPage, false, c, theme);
        ReadingRoom.corner(g, rightPage ? x + w - 4 : x + 3, BY + BH - 4, rightPage, true, c, theme);
        ReadingRoom.runner(g, x + TX, BY + 3, TW, ReadingRoom.tint(0xFFE0CFA0, tl.cover(), 0.45F) & 0xFFFFFF | 0xAA000000, theme);
    }

    private void renderBook(GuiGraphics g, Font f, int mx, int my) {
        Tales.Tale tl = Tales.ALL.get(tale);
        float night = ReadingRoom.nightness(), tm = ReadingRoom.clock();
        ReadingRoom.desk(g, W, H, night);                                       // the wooden table
        rect(g, 0, 0, W, 14, accent());
        CuteFont.draw(g, f, trunc(f, t("cutemod.tale." + tl.id() + ".title"), W - 100), 5, 3, 0xFFFFFFFF, false);
        ReadingRoom.window(g, W - 76, 2, night, tm);                            // the sun or the moon in the window
        boolean hb = in(mx, my, W - 54, 1, 50, 12);
        rect(g, W - 54, 1, 50, 12, hb ? 0x66FFFFFF : 0x33FFFFFF);
        ctext(g, f, trunc(f, t("cutemod.tales.shelf"), 46), W - 29, 3, 0xFFFFFFFF);

        // the book: a shadow on the table, the cover around the pages, the thickness of the pages on both sides
        rect(g, BX - 2, BY + 3, BW + 8, BH + 5, 0x40000000);
        rect(g, BX - 4, BY - 4, BW + 8, BH + 8, mix(tl.cover(), 0x000000, 0.2F));
        rect(g, BX - 4, BY - 4, BW + 8, 2, mix(tl.cover(), 0xFFFFFF, 0.25F));
        int gilt = ReadingRoom.argb(0.85F, 0xFFD84A), cap = 0xFFE8C050;           // a gilded line and brass corners on the cover
        rect(g, BX - 3, BY - 3, BW + 6, 1, gilt); rect(g, BX - 3, BY + BH + 2, BW + 6, 1, gilt);
        rect(g, BX - 3, BY - 3, 1, BH + 6, gilt); rect(g, BX + BW + 2, BY - 3, 1, BH + 6, gilt);
        rect(g, BX - 4, BY - 4, 7, 2, cap); rect(g, BX - 4, BY - 4, 2, 7, cap);
        rect(g, BX + BW - 3, BY - 4, 7, 2, cap); rect(g, BX + BW + 2, BY - 4, 2, 7, cap);
        rect(g, BX - 4, BY + BH + 2, 7, 2, cap); rect(g, BX - 4, BY + BH - 3, 2, 7, cap);
        rect(g, BX + BW - 3, BY + BH + 2, 7, 2, cap); rect(g, BX + BW + 2, BY + BH - 3, 2, 7, cap);
        float prog = spreads.size() <= 1 ? 0F : cur / (float) (spreads.size() - 1);
        int thL = 1 + Math.round(2 * prog), thR = 1 + Math.round(2 * (1 - prog)), thB = Math.max(thL, thR);
        for (int k = 0; k < thL; k++) rect(g, BX - 1 - k, BY + 1 + k, 1, BH - 1 - k, k % 2 == 0 ? 0xFFF2E8D0 : 0xFFD8C8A0);
        for (int k = 0; k < thR; k++) rect(g, BX + BW + k, BY + 1 + k, 1, BH - 1 - k, k % 2 == 0 ? 0xFFF2E8D0 : 0xFFD8C8A0);
        for (int k = 0; k < thB + 1; k++) rect(g, BX - 2 + k, BY + BH + k, BW + 4 - 2 * k, 1, k % 2 == 0 ? 0xFFE8DCC0 : 0xFFC8B890);
        paper(g, tl, BX, PW, false);
        paper(g, tl, BX + PW + SPINE, PW, true);
        rect(g, BX + PW, BY, SPINE, BH, 0xFFEADBB8);
        rect(g, BX + PW + 3, BY, 2, BH, 0x33000000);
        for (int i = 0; i < 4; i++) {                                              // the gutter shadow
            rect(g, BX + PW - 1 - i, BY, 1, BH, (0x16 - i * 4) << 24);
            rect(g, BX + PW + SPINE + i, BY, 1, BH, (0x16 - i * 4) << 24);
        }
        Spread now = spreads.get(cur);
        if (flipTo < 0) {
            leftPage(g, f, now, tl, cur * 2 + 1);
            rightPage(g, f, now, tl, cur * 2 + 2);
        } else {
            drawFlip(g, f, tl);
        }
        ribbon(g);
        if (night > 0.01F) rect(g, BX, BY, BW, BH, ((int) (0x2A * night) << 24) | 0x16286B);   // the pages in the blue of the night
        float dt = lastTm < 0F ? 0F : Math.max(0F, Math.min(6F, tm - lastTm));
        lastTm = tm;
        dustT += dt * (1F - 0.75F * calm);                                      // the dust slows down when nobody reads
        ReadingRoom.pageShade(g, BX, BY, BW, BH, night);                        // the edges of the book fall into shadow
        ReadingRoom.light(g, W, H, BX + BW / 2, night, tm, calm, -0.45F * Math.min(1F, flicker / 8F));   // the lamp, the candle light and the moon beams
        ReadingRoom.candle(g, W, H, tm, burnT / (float) BURN_ALL, (1F - 0.45F * calm) * gut());           // it burns down while you read
        ReadingRoom.dust(g, W, H, night, dustT);
        if (flash > 0) {                                                        // lightning
            float k = flash / 10F;
            rect(g, 0, 14, W, H - 14, ((int) (0x96 * k * k) << 24) | 0xDDE8FF);
        }
    }

    /** A page that turns: it lifts, bends (its free edge leads) and throws a shadow on the page under it; its faces show the text. */
    private void drawFlip(GuiGraphics g, Font f, Tales.Tale tl) {
        boolean fwd = flipTo > cur;
        Spread now = spreads.get(cur), to = spreads.get(flipTo);
        if (fwd) { leftPage(g, f, now, tl, -1); rightPage(g, f, to, tl, -1); }
        else { rightPage(g, f, now, tl, -1); leftPage(g, f, to, tl, -1); }

        float p = Math.min(1F, flipT / (float) FLIP), e = p * p * (3 - 2 * p);
        double theta = Math.PI * (fwd ? e : 1 - e), sinT = Math.sin(theta), lead = fwd ? 1 : -1;
        final int d = PW + SPINE / 2, hinge = BX + PW + SPINE / 2;
        double[] xs = new double[d + 1], phis = new double[d];
        xs[0] = hinge;
        for (int i = 0; i < d; i++) {
            phis[i] = theta + lead * CURL * sinT * (i / (double) d - 0.4);
            xs[i + 1] = xs[i] + Math.cos(phis[i]);
        }
        double freeX = xs[d];

        for (int k = 0; k < 18; k++) {                                         // the shadow on the page under the turning one
            int a = (int) (0x48 * sinT * (1 - k / 18.0) * (1 - k / 18.0));
            if (a <= 0) continue;
            if (freeX > hinge) rect(g, (int) freeX + k, BY, 1, BH, a << 24);
            else rect(g, (int) freeX - 1 - k, BY, 1, BH, a << 24);
        }
        for (int i = 0; i < d; i++) {                                          // the page, a column at a time
            double phi = phis[i], s = i / (double) d;
            int xl = (int) Math.round(Math.min(xs[i], xs[i + 1])), xr = (int) Math.round(Math.max(xs[i], xs[i + 1]));
            if (xr <= xl) xr = xl + 1;
            int lift = (int) Math.round(LIFT * Math.sin(phi) * Math.pow(s, 0.7));
            int top = BY - lift, bot = BY + BH + lift;
            boolean back = phi > Math.PI / 2;
            float dark = (float) (0.22 * Math.sin(phi) * (0.5 + 0.5 * s) + 0.10 * (1 - s));
            int c = mix(back ? 0xFFFAF1DC : paperC(tl), 0x2A1A10, Math.min(0.6F, dark));
            rect(g, xl, top, xr - xl, bot - top, c);
            rect(g, xl, top, xr - xl, 1, mix(c, 0x000000, 0.28F));
            rect(g, xl, bot - 1, xr - xl, 1, mix(c, 0x000000, 0.28F));
        }
        int fl = (int) Math.round(freeX);                                       // the edge of the paper
        int liftE = (int) Math.round(LIFT * Math.sin(phis[d - 1]));
        rect(g, fl - 1, BY - liftE, 2, BH + 2 * liftE, 0xFFFFFDF4);
        rect(g, fl + (freeX > hinge ? 1 : -2), BY - liftE, 1, BH + 2 * liftE, 0x33000000);

        double s = Math.abs(freeX - hinge) / d;                                  // what is written on the faces, squeezed to the width of the page
        if (s > 0.05) {
            g.pose().pushPose();
            g.pose().translate(hinge, 0, 0);
            g.pose().scale((float) s, 1F, 1F);
            g.pose().translate(-hinge, 0, 0);
            if (theta < Math.PI / 2) rightPage(g, f, fwd ? now : to, tl, -1);
            else leftPage(g, f, fwd ? to : now, tl, -1);
            g.pose().popPose();
        }
    }

    /** The ribbon bookmark: it lies in the gutter on top of the pages and hangs out of the bottom of the book. */
    private void ribbon(GuiGraphics g) {
        int x = BX + PW + SPINE / 2 - 1, len = BH + 6;
        rect(g, x + 1, BY + 2, 3, len, 0x33000000);
        rect(g, x, BY + 1, 3, len, 0xFFD83A4A);
        rect(g, x, BY + 1, 1, len, 0xFFF0707A);
        rect(g, x + 2, BY + 1, 1, len, 0xFFA82836);
        rect(g, x + 1, BY + 1 + len - 3, 1, 3, 0xFF5A3A28);                      // the swallowtail
        rect(g, x, BY + 1, 3, 1, 0xFFFFD84A);
    }

    private void lines(GuiGraphics g, Font f, List<String> ls, int x, int y) {
        for (int i = 0; i < ls.size(); i++) CuteFont.draw(g, f, ls.get(i), x, y + i * LINE, INK, false);
    }

    private void number(GuiGraphics g, Font f, int n, int cx, Tales.Tale tl) {
        if (n <= 0) return;
        String s = Integer.toString(n);
        int col = ReadingRoom.tint(0xFFB8A888, tl.cover(), 0.3F), th = ReadingRoom.themeOf(tl.id());
        ctext(g, f, s, cx, BY + BH - 11, col);
        int half = CuteFont.width(f, s) / 2 + 8;                                // the emblem of the tale on both sides of the number
        int soft = (0x90 << 24) | (col & 0xFFFFFF);
        ReadingRoom.motif(g, th, cx - half, BY + BH - 8, soft);
        ReadingRoom.motif(g, th, cx + half, BY + BH - 8, soft);
    }

    private void leftPage(GuiGraphics g, Font f, Spread s, Tales.Tale tl, int num) {
        int px = BX + TX, cx = BX + PW / 2;
        switch (s.kind) {
            case 0 -> {                                                           // the cover plate
                rect(g, px, TOP, TW, BOTTOM - TOP, tl.cover());
                rect(g, px + 3, TOP + 3, TW - 6, 1, 0xFFFFD84A); rect(g, px + 3, BOTTOM - 4, TW - 6, 1, 0xFFFFD84A);
                rect(g, px + 3, TOP + 3, 1, BOTTOM - TOP - 6, 0xFFFFD84A); rect(g, px + TW - 4, TOP + 3, 1, BOTTOM - TOP - 6, 0xFFFFD84A);
                for (int k = 0; k < 4; k++) {                                       // gold corner blocks
                    int cxk = k % 2 == 0 ? px + 3 : px + TW - 7, cyk = k < 2 ? TOP + 3 : BOTTOM - 7;
                    rect(g, cxk, cyk, 4, 4, 0xFFFFD84A); rect(g, cxk + 1, cyk + 1, 2, 2, tl.cover());
                }
                BookArt.prop(g, tl.prop(), px + TW / 2, TOP + 78, tl.propSize() * 18 / 10);
            }
            case 2 -> {                                                           // the end: a small cover and "The End"
                BookArt.prop(g, tl.prop(), cx, TOP + 56, tl.propSize());
                String end = t("cutemod.tales.the_end");
                int sc = CuteFont.width(f, end) * 2 <= TW ? 2 : 1;
                g.pose().pushPose();
                g.pose().translate(cx - CuteFont.width(f, end) * sc / 2F, TOP + 70, 0);
                g.pose().scale(sc, sc, 1F);
                CuteFont.draw(g, f, end, 0, 0, 0xFFB8743A, false);
                g.pose().popPose();
            }
            default -> {
                int ty = TOP;
                if (s.scene >= 0) {
                    rect(g, px - 2, PIC_Y - 2, BookArt.W + 4, PIC_H + 4, ReadingRoom.tint(0xFF8A5A3A, tl.cover(), 0.4F));      // the frame in the colour of the tale
                    BookArt.scene(g, tl.pictures()[s.scene], px, PIC_Y);
                    ty = PIC_Y + PIC_H + 4;
                }
                textBlock(g, f, s, s.left, px, ty, tl, s.endL);
            }
        }
        number(g, f, num, cx, tl);
    }

    /** The lines of a page; the first lines of a tale go round the drop cap, and a flourish closes a scene when there is room. */
    private void textBlock(GuiGraphics g, Font f, Spread s, List<String> ls, int px, int ty, Tales.Tale tl, boolean ends) {
        if (s.cap != 0 && ls == s.left) {
            ReadingRoom.dropCap(g, f, s.cap, px, ty, s.capW, tl.cover(), ReadingRoom.themeOf(tl.id()));
            for (int i = 0; i < ls.size(); i++) {
                int ix = i < DROP_LINES ? px + s.capW + 3 : px;
                CuteFont.draw(g, f, ls.get(i), ix, ty + i * LINE, INK, false);
            }
        } else {
            lines(g, f, ls, px, ty);
        }
        int fy = ty + ls.size() * LINE + 5;
        if (ends && fy + 4 <= BOTTOM) ReadingRoom.flourish(g, px + TW / 2, fy, ReadingRoom.tint(ORNAMENT, tl.cover(), 0.35F));
    }

    private void rightPage(GuiGraphics g, Font f, Spread s, Tales.Tale tl, int num) {
        int px = BX + PW + SPINE + TX, cx = BX + PW + SPINE + PW / 2;
        switch (s.kind) {
            case 0 -> {
                String name = t("cutemod.tale." + tl.id() + ".title");
                List<String> big = wrap(f, name, TW / 2);                     // twice as big when no word has to be broken
                boolean twice = big.size() <= 4;
                for (String l : big) if (l.endsWith("-")) twice = false;
                int y = TOP + 18;
                if (twice) {
                    for (String l : big) {
                        g.pose().pushPose();
                        g.pose().translate(cx - CuteFont.width(f, l), y, 0);
                        g.pose().scale(2F, 2F, 1F);
                        CuteFont.draw(g, f, l, 0, 0, tl.cover(), false);
                        g.pose().popPose();
                        y += LINE * 2;
                    }
                } else {
                    for (String l : wrap(f, name, TW)) { ctext(g, f, l, cx, y, tl.cover()); y += LINE + 2; }
                }
                ReadingRoom.flourish(g, cx, y + 5, 0xFFFFC832);
                y += 16;
                for (String l : wrap(f, t("cutemod.tale.author." + tl.author()), TW)) { ctext(g, f, l, cx, y, MUTED); y += LINE; }
                List<String> note = wrap(f, t("cutemod.tales.retold"), TW);
                int ny = BOTTOM - note.size() * LINE;
                for (String l : note) { ctext(g, f, l, cx, ny, 0xFFB8A888); ny += LINE; }
            }
            case 2 -> {
                int y = TOP + 14;
                ReadingRoom.flourish(g, cx, y, ReadingRoom.tint(ORNAMENT, tl.cover(), 0.35F));
                y += 12;
                for (String l : wrap(f, t("cutemod.tales.thanks"), TW)) { ctext(g, f, l, cx, y, INK); y += LINE; }
                if (justEarned) { y += 6; for (String l : wrap(f, t("cutemod.tales.reward", REWARD), TW)) { ctext(g, f, l, cx, y, 0xFFB8743A); y += LINE; } }
                if (justSticker) { y += 4; for (String l : wrap(f, t("cutemod.tales.sticker"), TW)) { ctext(g, f, l, cx, y, 0xFF9A5AC0); y += LINE; } }
                y += 8;
                for (String l : wrap(f, t("cutemod.tales.back"), TW)) { ctext(g, f, l, cx, y, MUTED); y += LINE; }
            }
            default -> textBlock(g, f, s, s.right, px, TOP, tl, s.endR);
        }
        number(g, f, num, cx, tl);
    }
}
