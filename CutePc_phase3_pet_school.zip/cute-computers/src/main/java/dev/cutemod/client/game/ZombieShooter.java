package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * "Zombie Shooter": a simple first-person wave shooter in the style of Call of Duty Zombies.
 * One small arena, endless rounds, points for hits and kills, a wall station to buy a rifle and ammo.
 * Same "one ray per screen column" raycaster as Dark Corridor.
 *
 * Controls: W/S walk, A/D strafe, mouse near the left/right edge or arrow keys to turn,
 * LMB or Space to shoot, R reload, 1/2/3/Q switch weapon, E buy at the golden (rifle) or teal (shotgun) wall,
 * B buy mines, F lay a mine. After every round you pick 1 of 3 perks (keys 1-3 or click).
 * Zombie kinds: normal, runner (round 3+), tank (5+), spitter (7+).
 */
public class ZombieShooter extends MiniGame {
    private static final int N = 17;
    private static final int COLS = 110, CW = W / COLS;
    private static final double PLANE = 0.75;
    private static final int RIFLE_COST = 500, AMMO_COST = 250, SG_COST = 400, SG_AMMO = 200, MINE_COST = 150, MAX_MINES = 6;
    private static final int PERKS = 6, CARD_W = 66;
    private static final double DEAD = 0.1;                      // the middle of the screen where the mouse does not turn you
    private static final int[] PERK_COL = {0xFF5AB0F0, 0xFFE0603A, 0xFFF0D84A, 0xFF5FD35A, 0xFFE070B0, 0xFFB57BD6};
    private static final int[] KIND_PTS = {60, 70, 150, 100};        // points for a kill
    private static final int[] KIND_DMG = {25, 15, 40, 25};          // a bite
    private static final double[] KIND_SIZE = {0.9, 0.8, 1.25, 0.9};   // body height compared with a wall

    private static final String[] LEVEL = {
            "########S########",
            "#...............#",
            "#...............#",
            "#...cc.....cc...#",
            "#...............#",
            "#...............#",
            "#......c.c......#",
            "#...............#",
            "#...c.......c...#",
            "#...............#",
            "#......c.c......#",
            "#...............#",
            "#...............#",
            "#...cc.....cc...#",
            "#...............#",
            "#...............#",
            "########T########"};
    private static final int[][] SPAWNS = {{2, 2}, {14, 2}, {2, 14}, {14, 14}, {8, 15}, {8, 2}};
    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    /** A blocky zombie, one char = one pixel. g/G skin, b shirt, p trousers, r eyes, k shoes. */
    private static final String[] ZOMBIE = {
            "..GGGG..", ".gggggg.", ".grggrg.", ".gggggg.", "..gggg..", "bbbbbbbb", "gbbbbbbg", "gbbbbbbg",
            "gbbbbbbg", ".bbbbbb.", ".bbbbbb.", ".pppppp.", ".pp..pp.", ".pp..pp.", ".pp..pp.", ".kk..kk."};

    private static final class Weapon {
        final boolean auto, infinite;
        final int magSize, maxReserve, dmg, rate, reloadTime;
        int mag, reserve;

        Weapon(boolean auto, boolean infinite, int magSize, int reserve, int dmg, int rate, int reloadTime) {
            this.auto = auto; this.infinite = infinite; this.magSize = magSize; this.maxReserve = reserve;
            this.dmg = dmg; this.rate = rate; this.reloadTime = reloadTime;
            this.mag = magSize; this.reserve = reserve;
        }
    }

    private static final class Zombie {
        double x, y, speed;
        int hp, maxHp, cool, flash, kind, spitT = 60;      // kind: 0 normal, 1 runner, 2 tank, 3 spitter
        Zombie(double x, double y, int hp, double speed, int kind) {
            this.x = x; this.y = y; this.hp = hp; this.maxHp = hp; this.speed = speed; this.kind = kind;
        }
        double radius() { return kind == 2 ? 0.42 : 0.3; }
    }

    private final int[][] map = new int[N][N];     // 0 floor, 1 wall, 2 crate, 3 station
    private final double[] zbuf = new double[COLS];
    private final int[][] flow = new int[N][N];
    private final List<Zombie> zombies = new ArrayList<>();
    private final Weapon pistol = new Weapon(false, true, 8, 0, 2, 16, 70);
    private final Weapon rifle = new Weapon(true, false, 30, 120, 3, 6, 100);
    private final Weapon shotgun = new Weapon(false, false, 6, 24, 2, 42, 110);
    private final int[] perk = new int[PERKS];                // levels of the perks (0-3)
    private final List<double[]> mineList = new ArrayList<>(), spits = new ArrayList<>(), blasts = new ArrayList<>();
    private int[] offer = new int[0];
    private boolean offering, hasShotgun;
    private int offerT, mines, seenKinds;

    private double px, py, ang, hp, turnV;
    private Weapon cur;
    private boolean hasRifle, trigPrev;
    private int round, toSpawn, spawned, spawnT, breakT, kills, points;
    private int cool, reload, kick, flashT, hit, hurtT, noHurt, ticks, msgT, walkT;
    private String msg = "";
    private double lastDist, lastWallX;
    private int lastType;
    private boolean lastSide;

    // ---------- setup ----------
    @Override
    public void reset() {
        score = 0; over = false; round = 1; kills = 0; points = 0; ticks = 0; msgT = 0; breakT = 0;
        turnV = 0; hp = 100; hurtT = 0; noHurt = 0; kick = 0; flashT = 0; hit = 0; reload = 0; cool = 40; walkT = 0;
        hasRifle = false; hasShotgun = false; trigPrev = true;
        pistol.mag = pistol.magSize;
        rifle.mag = rifle.magSize; rifle.reserve = rifle.maxReserve;
        shotgun.mag = shotgun.magSize; shotgun.reserve = shotgun.maxReserve;
        Arrays.fill(perk, 0);
        mineList.clear(); spits.clear(); blasts.clear();
        mines = 0; offering = false; seenKinds = 0;
        cur = pistol;
        zombies.clear();
        for (int y = 0; y < N; y++) for (int x = 0; x < N; x++) {
            char c = LEVEL[y].charAt(x);
            map[y][x] = c == '#' ? 1 : c == 'c' ? 2 : c == 'S' ? 3 : c == 'T' ? 4 : 0;
        }
        px = 8.5; py = 8.5; ang = Math.PI / 2;
        startRound();
        say("cutemod.zombies.start");
    }

    private void startRound() {
        toSpawn = 5 + 3 * round;
        spawned = 0;
        spawnT = 90;
        say("cutemod.zombies.round", round);
    }

    private void say(String key, Object... args) {
        msg = Component.translatable(key, args).getString();
        msgT = 150;
    }

    // ---------- helpers ----------
    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private static boolean lmb() {
        return GLFW.glfwGetMouseButton(Minecraft.getInstance().getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    private static void snd(SoundEvent e, float pitch, float vol) {
        dev.cutemod.client.os.Sfx.ui(e, pitch, vol);
    }

    private static void snd(Holder<SoundEvent> h, float pitch, float vol) { snd(h.value(), pitch, vol); }

    private void earn(int n) {
        int v = (int) Math.round(n * (1 + 0.25 * perk[5]));    // the "greedy" perk
        points += v;
        score += v;
    }

    private boolean free(double x, double y) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        return ix >= 0 && iy >= 0 && ix < N && iy < N && map[iy][ix] == 0;
    }

    private void move(double dx, double dy) {
        double r = 0.22;
        if (free(px + dx + Math.signum(dx) * r, py)) px += dx;
        if (free(px, py + dy + Math.signum(dy) * r)) py += dy;
    }

    /** Distance to the first wall along a direction (also remembers which wall it was). */
    private double ray(double a) {
        double rdx = Math.cos(a), rdy = Math.sin(a);
        int mapX = (int) px, mapY = (int) py;
        double ddx = Math.abs(1 / rdx), ddy = Math.abs(1 / rdy), sdx, sdy;
        int stepX, stepY;
        if (rdx < 0) { stepX = -1; sdx = (px - mapX) * ddx; } else { stepX = 1; sdx = (mapX + 1 - px) * ddx; }
        if (rdy < 0) { stepY = -1; sdy = (py - mapY) * ddy; } else { stepY = 1; sdy = (mapY + 1 - py) * ddy; }
        boolean side = false;
        while (map[mapY][mapX] == 0) {
            if (sdx < sdy) { sdx += ddx; mapX += stepX; side = false; }
            else { sdy += ddy; mapY += stepY; side = true; }
        }
        double dist = Math.max(0.05, side ? sdy - ddy : sdx - ddx);
        lastType = map[mapY][mapX];
        lastSide = side;
        double wx = side ? px + dist * rdx : py + dist * rdy;
        lastWallX = wx - Math.floor(wx);
        return dist;
    }

    // ---------- shooting ----------
    private int dmgOf(Weapon w) { return w.dmg + perk[1]; }

    private void fire() {
        if (reload > 0 || cool > 0) return;
        if (cur.mag <= 0) { startReload(); return; }
        cur.mag--;
        cool = cur.rate;
        kick = cur == pistol ? 7 : cur == shotgun ? 11 : 4;
        flashT = 3;
        snd(SoundEvents.ARROW_SHOOT, cur == rifle ? 1.9F : cur == shotgun ? 0.7F : 1.5F, cur == shotgun ? 0.9F : 0.6F);
        int pellets = cur == shotgun ? 6 : 1;                 // the shotgun throws 6 pellets in a small cone
        for (int i = 0; i < pellets; i++) {
            double a = pellets > 1 ? ang + (rnd.nextDouble() - 0.5) * 0.24 : ang;
            shootRay(a, dmgOf(cur), pellets > 1 ? 4 : 10);
        }
        if (cur.mag == 0) startReload();
    }

    /** One bullet along an angle: hits the nearest zombie in front of the first wall. */
    private void shootRay(double a, int dmg, int pts) {
        double wall = ray(a), bestD = 1e9;
        Zombie best = null;
        double c = Math.cos(a), s = Math.sin(a);
        for (Zombie z : zombies) {
            double dx = z.x - px, dy = z.y - py;
            double f = dx * c + dy * s;
            if (f < 0.1 || f > wall || f >= bestD) continue;
            if (Math.abs(-dx * s + dy * c) < z.radius()) { best = z; bestD = f; }
        }
        if (best != null) { hit = 8; damage(best, dmg, pts); }
    }

    private void damage(Zombie z, int dmg, int pts) {
        if (z.hp <= 0) return;
        z.hp -= dmg;
        z.flash = 6;
        earn(pts);
        if (z.hp <= 0) {
            zombies.remove(z);
            kills++;
            earn(KIND_PTS[z.kind]);
            snd(SoundEvents.ZOMBIE_DEATH, z.kind == 2 ? 0.6F : 1.0F, 0.6F);
        } else {
            snd(SoundEvents.ZOMBIE_HURT, z.kind == 1 ? 1.5F : 1.2F, 0.5F);
        }
    }

    private void startReload() {
        if (reload > 0 || cur.mag >= cur.magSize || (!cur.infinite && cur.reserve <= 0)) return;
        reload = Math.max(20, (int) (cur.reloadTime * (1 - 0.25 * perk[0])));
        snd(SoundEvents.UI_BUTTON_CLICK, 0.6F, 0.7F);
    }

    private void finishReload() {
        int need = cur.magSize - cur.mag;
        int take = cur.infinite ? need : Math.min(need, cur.reserve);
        cur.mag += take;
        if (!cur.infinite) cur.reserve -= take;
        snd(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.7F);
    }

    private void select(Weapon w) {
        if (w == rifle && !hasRifle) return;
        if (w == shotgun && !hasShotgun) return;
        if (cur != w) { cur = w; reload = 0; cool = 12; }
    }

    private void cycle() {
        List<Weapon> own = new ArrayList<>();
        own.add(pistol);
        if (hasRifle) own.add(rifle);
        if (hasShotgun) own.add(shotgun);
        select(own.get((own.indexOf(cur) + 1) % own.size()));
    }

    /** 0 = none, 1 = the golden wall (rifle), 2 = the teal wall (shotgun). */
    private int station() {
        if (Math.hypot(px - 8.5, py - 1.0) < 2.2) return 1;
        if (Math.hypot(px - 8.5, py - 16.0) < 2.2) return 2;
        return 0;
    }

    private void buy() {
        int st = station();
        if (st == 0) return;
        if (st == 1) {
            if (!hasRifle) {
                if (points < RIFLE_COST) { say("cutemod.zombies.poor"); beep(); return; }
                points -= RIFLE_COST;
                hasRifle = true;
                select(rifle);
                say("cutemod.zombies.bought");
                pling(1.6F);
            } else {
                if (rifle.reserve >= rifle.maxReserve && rifle.mag >= rifle.magSize) { say("cutemod.zombies.full"); return; }
                if (points < AMMO_COST) { say("cutemod.zombies.poor"); beep(); return; }
                points -= AMMO_COST;
                rifle.reserve = rifle.maxReserve;
                rifle.mag = rifle.magSize;
                say("cutemod.zombies.ammo");
                pling(1.3F);
            }
        } else {
            if (!hasShotgun) {
                if (points < SG_COST) { say("cutemod.zombies.poor"); beep(); return; }
                points -= SG_COST;
                hasShotgun = true;
                select(shotgun);
                say("cutemod.zombies.bought_sg");
                pling(1.5F);
            } else {
                if (shotgun.reserve >= shotgun.maxReserve && shotgun.mag >= shotgun.magSize) { say("cutemod.zombies.full"); return; }
                if (points < SG_AMMO) { say("cutemod.zombies.poor"); beep(); return; }
                points -= SG_AMMO;
                shotgun.reserve = shotgun.maxReserve;
                shotgun.mag = shotgun.magSize;
                say("cutemod.zombies.ammo");
                pling(1.3F);
            }
        }
    }

    private void buyMines() {
        if (station() == 0) return;
        if (mines >= MAX_MINES) { say("cutemod.zombies.mines_full"); return; }
        if (points < MINE_COST) { say("cutemod.zombies.poor"); beep(); return; }
        points -= MINE_COST;
        mines = Math.min(MAX_MINES, mines + 3);
        say("cutemod.zombies.mines_bought");
        pling(1.4F);
    }

    private void placeMine() {
        if (mines <= 0) { say("cutemod.zombies.nomines"); beep(); return; }
        mines--;
        mineList.add(new double[]{px, py, 45});            // it needs 0.75 s to arm
        snd(SoundEvents.UI_BUTTON_CLICK, 0.5F, 0.8F);
    }

    // ---------- perks: after every round you pick 1 of 3 ----------
    private int maxHp() { return 100 + 25 * perk[3]; }

    private void openOffer() {
        List<Integer> pool = new ArrayList<>();
        for (int i = 0; i < PERKS; i++) if (perk[i] < 3) pool.add(i);
        Collections.shuffle(pool, new java.util.Random(rnd.nextLong()));
        int n = Math.min(3, pool.size());
        offer = new int[n];
        for (int i = 0; i < n; i++) offer[i] = pool.get(i);
        offering = n > 0;
        offerT = 900;
    }

    private void choose(int k) {
        if (!offering || k < 0 || k >= offer.length) return;
        int p = offer[k];
        perk[p]++;
        if (p == 3) hp = Math.min(maxHp(), hp + 25);
        offering = false;
        breakT = Math.min(breakT, 150);
        say("cutemod.zombies.perk_got", Component.translatable("cutemod.zombies.perk." + p + ".name").getString());
        pling(1.7F);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (!offering) return false;
        int n = offer.length, x0 = (W - (n * CARD_W + (n - 1) * 4)) / 2;
        for (int i = 0; i < n; i++) {
            if (in(x, y, x0 + i * (CARD_W + 4), 30, CARD_W, 86)) { choose(i); return true; }
        }
        return false;
    }

    @Override
    public boolean key(int k) {
        switch (k) {
            case 82 -> startReload();                                  // R
            case 69 -> buy();                                          // E
            case 66 -> buyMines();                                     // B
            case 70 -> placeMine();                                    // F
            case 49 -> { if (offering) choose(0); else select(pistol); }   // 1
            case 50 -> { if (offering) choose(1); else select(rifle); }    // 2
            case 51 -> { if (offering) choose(2); else select(shotgun); }  // 3
            case 81 -> cycle();                                        // Q
            default -> { return false; }
        }
        return true;
    }

    // ---------- tick ----------
    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        if (cool > 0) cool--;
        if (kick > 0) kick--;
        if (flashT > 0) flashT--;
        if (hit > 0) hit--;
        if (hurtT > 0) hurtT--;
        if (reload > 0 && --reload == 0) finishReload();

        // --- turning: arrow keys, or the mouse close to the left / right edge ---
        double turn = (down(KEY_RIGHT) ? 1 : 0) - (down(KEY_LEFT) ? 1 : 0);
        ang += turn * 0.045;
        // The farther the mouse is from the middle, the faster you turn: slow and fine near the middle, quick near the
        // edges. It keeps working when the pointer leaves the game area, and the speed is smoothed so aiming does not jerk.
        double target = 0;
        if (!offering) {
            double nx = Math.max(-1.6, Math.min(1.6, (mx - W / 2.0) / (W / 2.0)));
            double d = (Math.abs(nx) - DEAD) / (1 - DEAD);
            if (d > 0) target = Math.signum(nx) * Math.pow(d, 1.6) * 0.06;
        }
        turnV += (target - turnV) * 0.3;
        if (Math.abs(turnV) < 0.0004) turnV = 0;
        ang += turnV;
        // --- walking ---
        double fwd = (down(87) ? 1 : 0) - (down(83) ? 0.75 : 0);
        double str = (down(68) ? 1 : 0) - (down(65) ? 1 : 0);
        double c = Math.cos(ang), s = Math.sin(ang);
        double v = 0.045 * (1 + 0.15 * perk[2]);
        move((c * fwd - s * str) * v, (s * fwd + c * str) * v);
        if (fwd != 0 || str != 0) walkT++;

        // --- trigger (not while you are choosing a perk with the mouse) ---
        boolean trig = (lmb() && !offering) || down(KEY_SPACE);
        if (trig && (cur.auto || !trigPrev)) fire();
        trigPrev = trig;

        // --- waves ---
        if (breakT > 0) {
            if (offering) {
                if (--offerT <= 0) choose(rnd.nextInt(offer.length));      // too slow: a random one
            } else if (--breakT == 0) {
                round++;
                startRound();
            }
        } else {
            int cap = Math.min(14, 6 + round);
            if (spawned < toSpawn && zombies.size() < cap && --spawnT <= 0) {
                spawnT = Math.max(30, 100 - round * 6);
                spawnZombie();
            }
            if (spawned >= toSpawn && zombies.isEmpty()) {
                earn(100);
                breakT = 300;
                say("cutemod.zombies.clear");
                pling(1.9F);
                openOffer();
            }
        }

        // --- zombies ---
        if (ticks % 8 == 0) buildFlow();
        for (Zombie z : new ArrayList<>(zombies)) {
            if (z.flash > 0) z.flash--;
            if (z.kind == 3) {                                  // a spitter stops at a distance and spits
                if (z.spitT > 0) z.spitT--;
                double d = Math.hypot(z.x - px, z.y - py);
                if (d < 5.5 && d > 1.3 && seen(z.x, z.y)) {
                    if (z.spitT <= 0) { spit(z); z.spitT = 110; }
                } else {
                    moveZombie(z);
                }
            } else {
                moveZombie(z);
            }
            if (Math.hypot(z.x - px, z.y - py) < 0.75) {
                if (--z.cool <= 0) {
                    z.cool = 50;
                    hp -= KIND_DMG[z.kind];
                    hurtT = 14;
                    noHurt = 0;
                    snd(SoundEvents.PLAYER_HURT, 1.0F, 0.7F);
                }
            } else if (z.cool > 0) z.cool--;
        }
        for (int i = 0; i < zombies.size(); i++) {           // keep them from stacking on one spot
            for (int j = i + 1; j < zombies.size(); j++) {
                Zombie a = zombies.get(i), b = zombies.get(j);
                double dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy);
                if (d < 0.45 && d > 0.001) {
                    double push = (0.45 - d) * 0.25;
                    if (free(a.x - dx / d * push, a.y)) a.x -= dx / d * push;
                    if (free(a.x, a.y - dy / d * push)) a.y -= dy / d * push;
                    if (free(b.x + dx / d * push, b.y)) b.x += dx / d * push;
                    if (free(b.x, b.y + dy / d * push)) b.y += dy / d * push;
                }
            }
        }
        if (!zombies.isEmpty() && rnd.nextInt(150) == 0) snd(SoundEvents.ZOMBIE_AMBIENT, 0.5F + rnd.nextFloat() * 0.4F, 0.6F);

        // --- mines: they wait, then go off when a zombie walks close ---
        for (Iterator<double[]> it = mineList.iterator(); it.hasNext(); ) {
            double[] m = it.next();
            if (m[2] > 0) { m[2]--; continue; }
            boolean trip = false;
            for (Zombie z : zombies) if (Math.hypot(z.x - m[0], z.y - m[1]) < 0.8) { trip = true; break; }
            if (!trip) continue;
            it.remove();
            blasts.add(new double[]{m[0], m[1], 14});
            snd(SoundEvents.GENERIC_EXPLODE, 1.1F, 0.7F);
            for (Zombie z : new ArrayList<>(zombies)) if (Math.hypot(z.x - m[0], z.y - m[1]) < 2.0) damage(z, 8, 10);
        }
        blasts.removeIf(b -> --b[2] <= 0);

        // --- spit balls ---
        for (Iterator<double[]> it = spits.iterator(); it.hasNext(); ) {
            double[] sp = it.next();
            sp[0] += sp[2];
            sp[1] += sp[3];
            if (!free(sp[0], sp[1]) || --sp[4] <= 0) { it.remove(); continue; }
            if (Math.hypot(sp[0] - px, sp[1] - py) < 0.35) {
                hp -= 12;
                hurtT = 14;
                noHurt = 0;
                snd(SoundEvents.PLAYER_HURT, 1.2F, 0.6F);
                it.remove();
            }
        }

        // --- health comes back if you are not hit for a while ---
        if (++noHurt > 360 - 80 * perk[4] && hp < maxHp()) hp = Math.min(maxHp(), hp + 0.25 + 0.12 * perk[4]);
        if (hp <= 0) { over = true; beep(); snd(SoundEvents.ZOMBIE_VILLAGER_CONVERTED, 0.8F, 0.6F); }
    }

    /** True if nothing solid stands between a point and the player. */
    private boolean seen(double x, double y) {
        double d = Math.hypot(px - x, py - y);
        int steps = (int) (d / 0.25) + 1;
        for (int i = 1; i < steps; i++) {
            double t = i / (double) steps;
            if (!free(x + (px - x) * t, y + (py - y) * t)) return false;
        }
        return true;
    }

    private void spit(Zombie z) {
        double dx = px - z.x, dy = py - z.y, d = Math.max(0.01, Math.hypot(dx, dy));
        spits.add(new double[]{z.x, z.y, dx / d * 0.065, dy / d * 0.065, 200});
        snd(SoundEvents.LLAMA_SPIT, 1.0F, 0.5F);
    }

    private void spawnZombie() {
        int[] best = null;
        int tries = 0;
        while (tries++ < 12) {
            int[] sp = SPAWNS[rnd.nextInt(SPAWNS.length)];
            if (Math.hypot(sp[0] + 0.5 - px, sp[1] + 0.5 - py) >= 6) { best = sp; break; }
        }
        if (best == null) best = SPAWNS[rnd.nextInt(SPAWNS.length)];
        int base = 3 + 2 * (round - 1);
        double sp = Math.min(0.03, 0.012 + 0.0012 * round) * (0.85 + rnd.nextDouble() * 0.3);
        double r = rnd.nextDouble();
        int kind = 0;                                         // new kinds show up in later rounds
        if (round >= 3 && r < 0.22) kind = 1;
        else if (round >= 5 && r < 0.34) kind = 2;
        else if (round >= 7 && r < 0.46) kind = 3;
        int hpz = switch (kind) {
            case 1 -> Math.max(2, base * 6 / 10);
            case 2 -> base * 3;
            case 3 -> Math.max(3, base * 8 / 10);
            default -> base;
        };
        double speed = switch (kind) {
            case 1 -> Math.min(0.043, sp * 1.5);
            case 2 -> sp * 0.6;
            case 3 -> sp * 0.7;
            default -> sp;
        };
        zombies.add(new Zombie(best[0] + 0.5, best[1] + 0.5, hpz, speed, kind));
        spawned++;
        if (kind > 0 && (seenKinds & (1 << kind)) == 0) {
            seenKinds |= 1 << kind;
            say("cutemod.zombies.new." + kind);
        }
    }

    /** Distance (in tiles) from every floor tile to the player. Zombies walk "downhill". */
    private void buildFlow() {
        for (int[] r : flow) Arrays.fill(r, -1);
        ArrayDeque<int[]> q = new ArrayDeque<>();
        int sx = Math.max(1, Math.min(N - 2, (int) px)), sy = Math.max(1, Math.min(N - 2, (int) py));
        flow[sy][sx] = 0;
        q.add(new int[]{sx, sy});
        while (!q.isEmpty()) {
            int[] c = q.poll();
            for (int[] d : DIRS) {
                int nx = c[0] + d[0], ny = c[1] + d[1];
                if (nx >= 0 && ny >= 0 && nx < N && ny < N && map[ny][nx] == 0 && flow[ny][nx] < 0) {
                    flow[ny][nx] = flow[c[1]][c[0]] + 1;
                    q.add(new int[]{nx, ny});
                }
            }
        }
    }

    private void moveZombie(Zombie z) {
        int cx = (int) z.x, cy = (int) z.y;
        double tx = px, ty = py;
        boolean direct = cx == (int) px && cy == (int) py || Math.hypot(z.x - px, z.y - py) < 1.3;
        if (!direct && cx >= 0 && cy >= 0 && cx < N && cy < N && flow[cy][cx] >= 0) {
            int best = flow[cy][cx];
            tx = cx + 0.5; ty = cy + 0.5;
            for (int[] d : DIRS) {
                int nx = cx + d[0], ny = cy + d[1];
                if (nx >= 0 && ny >= 0 && nx < N && ny < N && map[ny][nx] == 0 && flow[ny][nx] >= 0 && flow[ny][nx] < best) {
                    best = flow[ny][nx];
                    tx = nx + 0.5; ty = ny + 0.5;
                }
            }
        }
        double dx = tx - z.x, dy = ty - z.y, d = Math.hypot(dx, dy);
        if (d < 0.001) return;
        double step = Math.min(z.speed, d);
        double nx = z.x + dx / d * step, ny = z.y + dy / d * step;
        if (free(nx, z.y)) z.x = nx;
        if (free(z.x, ny)) z.y = ny;
    }

    // ---------- drawing ----------
    private static int shade(int rgb, double b) {
        b = Math.max(0, Math.min(1.5, b));
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * b));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * b));
        int bl = Math.min(255, (int) ((rgb & 255) * b));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Colors of the 4 kinds: normal, runner (red shirt), tank (big, purple), spitter (yellow-green, glowing eyes). */
    private static int pal(char c, int kind, boolean flash) {
        if (flash) return 0xFFFFE0E0;
        return switch (kind) {
            case 1 -> switch (c) {
                case 'G' -> 0xFF5C9A3C; case 'g' -> 0xFF86C25A; case 'b' -> 0xFFC84040; case 'p' -> 0xFF2C2C34;
                case 'r' -> 0xFFFFE030; default -> 0xFF222222;
            };
            case 2 -> switch (c) {
                case 'G' -> 0xFF3C5A38; case 'g' -> 0xFF557A4C; case 'b' -> 0xFF5A3A7A; case 'p' -> 0xFF2A2030;
                case 'r' -> 0xFFFF3030; default -> 0xFF1A1A1A;
            };
            case 3 -> switch (c) {
                case 'G' -> 0xFF98A82A; case 'g' -> 0xFFBCCB3A; case 'b' -> 0xFF6A8A2A; case 'p' -> 0xFF3A4A22;
                case 'r' -> 0xFF9AFF3A; default -> 0xFF222222;
            };
            default -> switch (c) {
                case 'G' -> 0xFF3F7F34; case 'g' -> 0xFF5FA84A; case 'b' -> 0xFF2AA6B0; case 'p' -> 0xFF3A3A8A;
                case 'r' -> 0xFFFF3030; default -> 0xFF222222;
            };
        };
    }

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H / 2, 0xFF0E121A, 0xFF252E3C);     // ceiling (night sky)
        g.fillGradient(0, H / 2, W, H, 0xFF2A2420, 0xFF4E4438);     // floor
        double dirX = Math.cos(ang), dirY = Math.sin(ang), plX = -dirY * PLANE, plY = dirX * PLANE;

        for (int col = 0; col < COLS; col++) {
            double cam = 2.0 * (col + 0.5) / COLS - 1;
            double a = Math.atan2(dirY + plY * cam, dirX + plX * cam);
            double raw = ray(a);
            double dist = Math.max(0.05, raw * Math.cos(a - ang));          // fix the fish-eye effect
            zbuf[col] = dist;
            int base = lastType == 3 ? 0xFFD8B04A : lastType == 4 ? 0xFF48B0C8 : lastType == 2 ? 0xFF9A6B3A : 0xFF8A8A92;
            double b = 1.0 * Math.max(0.12, 1 - dist / 9.5) * (lastSide ? 0.75 : 1);
            if (lastType == 2 && ((int) (lastWallX * 6) % 2 == 0)) b *= 0.82;                     // crate planks
            if (lastType == 1 && ((int) (lastWallX * 8) % 4 == 0)) b *= 0.85;                     // brick joints
            int lh = (int) (H / dist), y0 = Math.max(0, H / 2 - lh / 2), y1 = Math.min(H, H / 2 + lh / 2);
            rect(g, col * CW, y0, CW, y1 - y0, shade(base, b));
        }

        // mines and explosions lie on the floor
        for (double[] m : mineList) billboard(g, m[0], m[1], 0.11, 0, m[2] > 0 || (ticks / 20) % 2 == 0 ? 0xFFE03A3A : 0xFF4A1A1A);
        for (double[] bl : blasts) billboard(g, bl[0], bl[1], 0.25 + (14 - bl[2]) * 0.05, 0.12, bl[2] > 7 ? 0xFFFFC040 : 0xFFE06020);

        // zombies, far ones first
        List<Zombie> order = new ArrayList<>(zombies);
        order.sort((a, b) -> Double.compare(Math.hypot(b.x - px, b.y - py), Math.hypot(a.x - px, a.y - py)));
        for (Zombie z : order) sprite(g, z);
        for (double[] sp : spits) billboard(g, sp[0], sp[1], 0.09, 0.45, 0xFF9AFF3A);

        // red flash / vignette when hurt or low on health
        double missing = 1 - hp / maxHp();
        int alpha = (int) Math.min(150, missing * 110 + hurtT * 6);
        if (alpha > 4) rect(g, 0, 0, W, H, (alpha << 24) | 0xB00000);
        if (breakT > 0 && breakT < 90 && !offering && ticks % 20 < 10) ctext(g, Component.translatable("cutemod.zombies.next").getString(), W / 2, 30, 0xFFFFE9A0);

        weaponAndHud(g);
        if (offering) renderOffer(g);
        if (over) rect(g, 0, 0, W, H, 0x80900000);
    }

    /** A small square in the world (a mine, a spit ball, a blast), hidden behind walls. */
    private void billboard(GuiGraphics g, double wx, double wy, double size, double lift, int color) {
        double rx = wx - px, ry = wy - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);
        if (f < 0.2) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f);
        int s = Math.max(2, (int) (full * size));
        int sx = (int) (W / 2.0 * (1 + cam));
        int col = Math.floorDiv(sx, CW);
        if (sx < 0 || col >= COLS || f >= zbuf[col]) return;
        int bottom = H / 2 + full / 2 - (int) (full * lift);
        rect(g, sx - s / 2, bottom - s, s, s, color);
    }

    private void sprite(GuiGraphics g, Zombie z) {
        double rx = z.x - px, ry = z.y - py;
        double f = rx * Math.cos(ang) + ry * Math.sin(ang);
        double r = -rx * Math.sin(ang) + ry * Math.cos(ang);
        if (f < 0.2) return;
        double cam = r / (f * PLANE);
        int full = (int) (H / f), sh = (int) (full * KIND_SIZE[z.kind]), sw = sh * ZOMBIE[0].length() / ZOMBIE.length;
        int left = (int) (W / 2.0 * (1 + cam)) - sw / 2, top = H / 2 + full / 2 - sh;
        top += (int) (Math.sin(ticks * (z.kind == 1 ? 0.3 : 0.15) + z.x * 7) * full * 0.015);   // shambling (runners shake faster)
        double b = Math.max(0.22, 1 - f / 9.5);
        boolean flash = z.flash > 0;
        for (int x = Math.floorDiv(left, CW) * CW; x < left + sw; x += CW) {
            int c = x / CW;
            if (x < 0 || c >= COLS || f >= zbuf[c]) continue;
            int u = Math.max(0, Math.min(ZOMBIE[0].length() - 1, (x + CW / 2 - left) * ZOMBIE[0].length() / sw));
            for (int row = 0; row < ZOMBIE.length; row++) {
                char ch = ZOMBIE[row].charAt(u);
                if (ch == '.') continue;
                int y0 = top + row * sh / ZOMBIE.length, y1 = Math.max(y0 + 1, top + (row + 1) * sh / ZOMBIE.length);
                rect(g, x, y0, CW, y1 - y0, shade(pal(ch, z.kind, flash), ch == 'r' ? 1.2 : b));
            }
        }
        // health bar over the head when it is hurt
        if (z.hp < z.maxHp && f < 6) {
            int bw = Math.max(6, sw), bx = left + sw / 2 - bw / 2;
            rect(g, bx, top - 4, bw, 2, 0xAA000000);
            rect(g, bx, top - 4, Math.max(0, bw * z.hp / z.maxHp), 2, 0xFFE03A3A);
        }
    }

    private void weaponAndHud(GuiGraphics g) {
        // crosshair + hit marker
        int cx = W / 2, cy = H / 2;
        int cc = hit > 0 ? 0xFFFF4040 : 0xE0FFFFFF;
        rect(g, cx - 5, cy, 3, 1, cc); rect(g, cx + 3, cy, 3, 1, cc);
        rect(g, cx, cy - 5, 1, 3, cc); rect(g, cx, cy + 3, 1, 3, cc);
        if (hit > 0) { rect(g, cx - 3, cy - 3, 1, 1, 0xFFFF4040); rect(g, cx + 3, cy - 3, 1, 1, 0xFFFF4040);
                       rect(g, cx - 3, cy + 3, 1, 1, 0xFFFF4040); rect(g, cx + 3, cy + 3, 1, 1, 0xFFFF4040); }

        // the gun (bobs while walking, kicks when shooting, drops while reloading)
        int bobX = (int) (Math.sin(walkT * 0.2) * 2), bobY = (int) (Math.abs(Math.cos(walkT * 0.2)) * 2);
        int gx = W / 2 + 22 + bobX, gy = H - 34 + bobY + kick + (reload > 0 ? 14 : 0);
        if (cur == pistol) {
            rect(g, gx - 5, gy + 10, 9, 16, 0xFF2E2E36);
            rect(g, gx - 7, gy, 13, 11, 0xFF55555F);
            rect(g, gx - 7, gy, 13, 2, 0xFF7A7A86);
            rect(g, gx - 3, gy - 5, 5, 6, 0xFF44444E);
        } else if (cur == rifle) {
            rect(g, gx - 4, gy + 12, 8, 20, 0xFF2E2E36);
            rect(g, gx - 8, gy - 4, 16, 18, 0xFF3F4A38);
            rect(g, gx - 3, gy - 14, 6, 12, 0xFF2A2A30);
            rect(g, gx - 8, gy - 4, 16, 2, 0xFF5E6B54);
        } else {                                                    // the shotgun: two fat barrels and a wooden grip
            rect(g, gx - 4, gy + 14, 8, 18, 0xFF6A4424);
            rect(g, gx - 9, gy - 2, 18, 16, 0xFF4A4A54);
            rect(g, gx - 8, gy - 12, 7, 12, 0xFF2A2A30);
            rect(g, gx + 1, gy - 12, 7, 12, 0xFF2A2A30);
            rect(g, gx - 9, gy - 2, 18, 2, 0xFF7A7A86);
        }
        if (flashT > 0) {
            int fy = gy - (cur == pistol ? 9 : cur == rifle ? 18 : 20);
            rect(g, gx - 5, fy - 5, 10, 8, 0xFFFFD84A);
            rect(g, gx - 2, fy - 8, 4, 12, 0xFFFFFFFF);
        }

        // HUD
        rect(g, 4, H - 10, 62, 6, 0xAA000000);
        rect(g, 5, H - 9, (int) (60 * Math.max(0, hp) / maxHp()), 4, hp > maxHp() * 0.4 ? 0xFF5FD35A : 0xFFE03A3A);
        String ammo = cur.mag + "/" + (cur.infinite ? "--" : String.valueOf(cur.reserve));
        text(g, ammo, W - 6 - font().width(ammo), H - 11, reload > 0 ? 0xFFFFD866 : 0xFFFFFFFF);
        if (mines > 0) {
            String mt = Component.translatable("cutemod.zombies.mines", mines).getString();
            text(g, mt, W - 6 - font().width(mt), H - 21, 0xFFFF9A80);
        }
        text(g, Component.translatable("cutemod.zombies.round_hud", round).getString(), 5, 4, 0xFFFFE9A0);
        String pts = Component.translatable("cutemod.zombies.points", points).getString();
        text(g, pts, W - 5 - font().width(pts), 4, 0xFFFFD866);
        int px0 = 5;                                                // taken perks: a small colored square per level
        for (int i = 0; i < PERKS; i++) for (int l = 0; l < perk[i]; l++) { rect(g, px0, 15, 4, 4, PERK_COL[i]); px0 += 5; }
        if (reload > 0) ctext(g, Component.translatable("cutemod.zombies.reload").getString(), W / 2, H / 2 + 12, 0xFFFFD866);
        int st = station();
        if (st != 0 && !offering) {
            String p = Component.translatable(st == 1 ? (hasRifle ? "cutemod.zombies.buy_ammo" : "cutemod.zombies.buy_rifle")
                    : (hasShotgun ? "cutemod.zombies.buy_ammo" : "cutemod.zombies.buy_shotgun"),
                    st == 1 ? (hasRifle ? AMMO_COST : RIFLE_COST) : (hasShotgun ? SG_AMMO : SG_COST)).getString();
            ctext(g, p, W / 2, H - 34, 0xFFFFE9A0);
            ctext(g, Component.translatable("cutemod.zombies.mines_buy", MINE_COST).getString(), W / 2, H - 24, 0xFFFFC8A0);
        }
        if (msgT > 0) ctext(g, msg, W / 2, 16, msgT < 30 ? 0xFFB0A070 : 0xFFFFFFFF);
    }

    /** The perk cards between two rounds: press 1-3 or click one. */
    private void renderOffer(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0x99000000);
        ctext(g, Component.translatable("cutemod.zombies.perk_title").getString(), W / 2, 14, 0xFFFFE9A0);
        int n = offer.length, x0 = (W - (n * CARD_W + (n - 1) * 4)) / 2;
        for (int i = 0; i < n; i++) {
            int p = offer[i], x = x0 + i * (CARD_W + 4), y = 30;
            boolean hv = in(mx, my, x, y, CARD_W, 86);
            rect(g, x, y, CARD_W, 86, hv ? 0xFF3C4E70 : 0xFF2A3348);
            rect(g, x, y, CARD_W, 3, PERK_COL[p]);
            String name = "[" + (i + 1) + "] " + Component.translatable("cutemod.zombies.perk." + p + ".name").getString();
            int ly = y + 8;
            for (var seq : font().split(FormattedText.of(name), CARD_W - 8)) {
                g.drawString(font(), seq, x + 4, ly, 0xFFFFFFFF, false);
                ly += 9;
            }
            ly += 3;
            for (var seq : font().split(FormattedText.of(Component.translatable("cutemod.zombies.perk." + p + ".desc").getString()), CARD_W - 8)) {
                if (ly > y + 70) break;
                g.drawString(font(), seq, x + 4, ly, 0xFFC8D0E0, false);
                ly += 9;
            }
            for (int l = 0; l < 3; l++) rect(g, x + 4 + l * 7, y + 76, 5, 5, l < perk[p] ? PERK_COL[p] : 0xFF4A5468);
        }
    }

    @Override
    public String hintKey() { return "cutemod.hint.zombies"; }

    @Override
    public Component status() { return Component.translatable("cutemod.zombies.status", round, kills, score); }

    @Override
    public Component endTitle() { return Component.translatable("cutemod.zombies.end", round); }
}
