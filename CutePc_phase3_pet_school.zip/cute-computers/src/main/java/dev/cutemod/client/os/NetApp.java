package dev.cutemod.client.os;

import dev.cutemod.net.NetSyncPayload;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * CuteNet, the online mode: the best players of the server in every game and who is at a computer right now.
 * The scores live on the server. (The pet talent show is part of the Tamagotchi app, see {@link PetStage}.)
 */
public class NetApp extends App {
    private static final int HEAD = 17, LIST_X = 4, LIST_Y = 21, LIST_W = 92, ROW = 12, RIGHT_X = 102;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;
    private static final int[] MEDAL = {0xFFF3C45A, 0xFFC4CAD6, 0xFFD08A4E};
    private static final String[] APPS = {"", "games", "browser", "notes", "paint", "calc", "settings", "music", "pet", "market",
            "quest", "terminal", "store", "jobs", "mail", "net", "weather", "farm", "fishing", "style", "beats", "season", "explorer", "gift", "quiz", "tictac", "wheel", "", "photo", "stickers", "bank", "wishlist", "radio", "petstats", "tales", "school"};

    private int tab;                 // 0 = top players, 1 = online
    private int sel;                 // the selected game (index in Library.GAMES)
    private int scroll;
    private int timer = 1000;        // asks at once

    @Override
    public Component title() { return Component.translatable("cutemod.os.net"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.net"); }

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        timer = 1000;
    }

    private static String gameId(int i) { return Library.GAMES.get(i).id(); }

    private static int games() { return Library.GAMES.size(); }

    private int visibleRows() { return (H - LIST_Y - 3) / ROW; }

    private void refresh() {
        Net.request(tab == 0 ? gameId(sel) : "");
        timer = 0;
    }

    @Override
    public void tick() {
        if (++timer >= 120) refresh();         // every 2 seconds while the app is open
    }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        Skin.rect(g, 0, 0, W, H, 0xFFF6F0FA);
        Skin.rect(g, 0, 0, W, HEAD, 0xFF5A4A86);
        tabButton(g, f, mx, my, 4, 80, "cutemod.net.tab.top", tab == 0);
        tabButton(g, f, 88, 70, "cutemod.net.tab.online", tab == 1);
        NetSyncPayload s = Net.last();
        if (s != null) {
            Component n = Component.translatable("cutemod.net.count", s.online().size());
            Skin.str(g, f, n, W - 6 - f.width(n), 5, 0xFFE4D8FF, false);
        }
        if (tab == 0) top(g, f, mx, my, s); else online(g, f, s);
    }

    private void tabButton(GuiGraphics g, Font f, int mx, int my, int x, int w, String key, boolean on) {
        boolean hov = in(mx, my, x, 2, w, 13);
        Skin.rect(g, x, 2, w, 13, on ? 0xFFF6F0FA : hov ? 0xFF8A6AC6 : 0xFF6E5CA0);
        Component c = Component.translatable(key);
        Skin.str(g, f, c, x + (w - f.width(c)) / 2, 5, on ? TEXT : 0xFFFFFFFF, false);
    }

    private void tabButton(GuiGraphics g, Font f, int x, int w, String key, boolean on) {
        tabButton(g, f, -1, -1, x, w, key, on);
    }

    private void top(GuiGraphics g, Font f, int mx, int my, NetSyncPayload s) {
        // the list of games
        int rows = visibleRows();
        scroll = Math.max(0, Math.min(Math.max(0, games() - rows), scroll));
        for (int i = 0; i < rows && i + scroll < games(); i++) {
            int idx = i + scroll, y = LIST_Y + i * ROW;
            boolean on = idx == sel, hov = in(mx, my, LIST_X, y, LIST_W, ROW - 1);
            Skin.rect(g, LIST_X, y, LIST_W, ROW - 1, on ? ACCENT : hov ? 0xFFE4D8FF : 0xFFFFFFFF);
            String name = f.plainSubstrByWidth(t("cutemod.game." + gameId(idx)), LIST_W - 6);
            Skin.str(g, f, name, LIST_X + 3, y + 2, on ? 0xFFFFFFFF : TEXT, false);
        }
        if (games() > rows) {                                          // a thin scroll bar
            int bh = Math.max(8, (H - LIST_Y - 3) * rows / games());
            int by = LIST_Y + (H - LIST_Y - 3 - bh) * scroll / Math.max(1, games() - rows);
            Skin.rect(g, LIST_X + LIST_W + 1, by, 2, bh, 0xFFB8A8D8);
        }
        // the ranking of the selected game
        int x = RIGHT_X, w = W - RIGHT_X - 4;
        Skin.str(g, f, t("cutemod.game." + gameId(sel)), x, LIST_Y + 1, ACCENT, false);
        boolean fresh = s != null && s.game().equals(gameId(sel));
        if (!fresh) {
            Skin.str(g, f, t("cutemod.net.loading"), x, LIST_Y + 18, MUTED, false);
            return;
        }
        List<dev.cutemod.data.NetData.Row> rowsList = s.top();
        if (rowsList.isEmpty()) {
            Skin.str(g, f, t("cutemod.net.nobody"), x, LIST_Y + 18, MUTED, false);
        }
        String me = net.minecraft.client.Minecraft.getInstance().getUser().getName();
        for (int i = 0; i < rowsList.size(); i++) {
            var r = rowsList.get(i);
            int y = LIST_Y + 12 + i * 11;
            boolean mine = r.name().equals(me);
            if (mine) Skin.rect(g, x - 2, y - 1, w + 2, 11, 0xFFE4D8FF);
            if (i < 3) Skin.disc(g, x + 4, y + 4, 4, MEDAL[i]);
            Skin.str(g, f, Integer.toString(i + 1), x + (i < 3 ? 4 - f.width(Integer.toString(i + 1)) / 2 : 1), y + 1, i < 3 ? 0xFF3A2A3A : MUTED, false);
            Skin.str(g, f, f.plainSubstrByWidth(r.name(), w - 60), x + 14, y + 1, mine ? ACCENT : TEXT, false);
            String sc = Integer.toString(r.score());
            Skin.str(g, f, sc, x + w - f.width(sc) - 2, y + 1, TEXT, false);
        }
        Component foot = s.myRank() > 0
                ? Component.translatable("cutemod.net.you", s.myRank(), s.myScore())
                : Component.translatable("cutemod.net.you_none");
        Skin.str(g, f, foot, x, H - 12, s.myRank() == 1 ? 0xFFC98A00 : MUTED, false);
    }

    private void online(GuiGraphics g, Font f, NetSyncPayload s) {
        if (s == null) { Skin.str(g, f, t("cutemod.net.loading"), 8, LIST_Y + 4, MUTED, false); return; }
        if (s.online().isEmpty()) { Skin.str(g, f, t("cutemod.net.nobody_online"), 8, LIST_Y + 4, MUTED, false); return; }
        int y = LIST_Y;
        for (int i = 0; i < s.online().size() && y + 14 <= H - 2; i++) {
            NetSyncPayload.Online o = s.online().get(i);
            Skin.rect(g, 4, y, W - 8, 13, 0xFFFFFFFF);
            Skin.disc(g, 12, y + 6, 3, 0xFF5BD97A);
            Skin.str(g, f, f.plainSubstrByWidth(o.name(), 90), 20, y + 3, TEXT, false);
            String what = activity(o);
            Skin.str(g, f, f.plainSubstrByWidth(what, W - 120), 116, y + 3, MUTED, false);
            y += 14;
        }
    }


    private static String activity(NetSyncPayload.Online o) {
        if (!o.game().isEmpty()) return t("cutemod.net.playing", t("cutemod.game." + o.game()));
        if (o.app() <= 0 || o.app() >= APPS.length || APPS[o.app()].isEmpty()) return t("cutemod.net.desktop");
        return t("cutemod.os." + APPS[o.app()]);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (in(x, y, 4, 2, 80, 13)) { if (tab != 0) { tab = 0; refresh(); } return true; }
        if (in(x, y, 88, 2, 70, 13)) { if (tab != 1) { tab = 1; refresh(); } return true; }
        if (tab == 0) {
            int rows = visibleRows();
            for (int i = 0; i < rows && i + scroll < games(); i++) {
                if (in(x, y, LIST_X, LIST_Y + i * ROW, LIST_W, ROW - 1)) {
                    if (sel != i + scroll) { sel = i + scroll; refresh(); }
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        if (tab != 0) return false;
        scroll -= (int) Math.signum(amount) * 2;
        return true;
    }
}
