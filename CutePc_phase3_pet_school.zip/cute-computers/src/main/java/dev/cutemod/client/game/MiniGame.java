package dev.cutemod.client.game;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;

/**
 * Base class for the mini games. The game area is W x H "pixels" (GUI pixels).
 * tick() is called 60 times per second, render() draws with local coordinates (0,0 = top-left of the screen).
 */
public abstract class MiniGame {
    public static final int W = 220;
    public static final int H = 140;

    public static final int KEY_RIGHT = 262, KEY_LEFT = 263, KEY_DOWN = 264, KEY_UP = 265, KEY_SPACE = 32;

    protected final RandomSource rnd = RandomSource.create();
    protected int mx, my;
    public int score;
    public boolean over;

    public void setMouse(int x, int y) { mx = x; my = y; }

    /** (Re)start the game. Must set score = 0 and over = false. */
    public abstract void reset();

    public abstract void tick();

    public abstract void render(GuiGraphics g);

    public boolean click(int x, int y, int button) { return false; }

    public boolean key(int keyCode) { return false; }

    public abstract String hintKey();

    public Component status() { return Component.translatable("cutemod.ui.score", score); }

    /** True if the game ended with a win (the quest counts it). */
    public boolean isWin() { return false; }

    /** Title of the box shown when the game ends (a game can say "You won" instead). */
    public Component endTitle() { return Component.translatable("cutemod.ui.gameover"); }

    // ---------- drawing helpers ----------
    protected static Font font() { return Minecraft.getInstance().font; }

    protected static void rect(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + h, argb);
    }

    protected static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    protected static void text(GuiGraphics g, String s, int x, int y, int argb) {
        dev.cutemod.client.os.Fit.str(g, font(), s, x, y, argb, false, W - 2);
    }

    protected static void ctext(GuiGraphics g, String s, int cx, int y, int argb) {
        dev.cutemod.client.os.Fit.str(g, font(), s, cx - font().width(s) / 2, y, argb, false, W - 2);
    }

    protected static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && py >= y && px < x + w && py < y + h;
    }

    protected static void beep() {
        dev.cutemod.client.os.Sfx.ui(net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK.value(), 1.4F, 0.35F);
    }

    /** Any vanilla sound, played like the other game sounds (the Sounds switch and the system volume count). */
    protected static void sound(net.minecraft.sounds.SoundEvent e, float pitch, float vol) {
        dev.cutemod.client.os.Sfx.ui(e, pitch, vol);
    }

    protected static void sound(net.minecraft.core.Holder<net.minecraft.sounds.SoundEvent> h, float pitch, float vol) {
        dev.cutemod.client.os.Sfx.ui(h.value(), pitch, vol);
    }

    public static final int G_ZOMBIE = 0, G_DEEP = 1, G_SCREAM = 2, G_ROAR = 3, G_PHANTOM = 4, G_HISS = 5, G_BITE = 6;

    /** A monster noise. Every kind is lowered and shifted a little at random, so it growls instead of just making the vanilla sound. */
    protected void growl(int kind) {
        float r = rnd.nextFloat();
        switch (kind) {
            case G_ZOMBIE -> { sound(net.minecraft.sounds.SoundEvents.ZOMBIE_AMBIENT, 0.55F + r * 0.25F, 0.7F); }
            case G_DEEP -> {
                sound(net.minecraft.sounds.SoundEvents.ZOMBIE_AMBIENT, 0.4F + r * 0.1F, 0.8F);
                sound(net.minecraft.sounds.SoundEvents.ENDERMAN_STARE, 0.45F, 0.35F);
            }
            case G_SCREAM -> {
                sound(net.minecraft.sounds.SoundEvents.ENDERMAN_SCREAM, 0.55F + r * 0.2F, 0.8F);
                sound(net.minecraft.sounds.SoundEvents.ZOMBIE_HURT, 0.5F, 0.6F);
            }
            case G_ROAR -> {
                sound(net.minecraft.sounds.SoundEvents.WARDEN_ROAR, 0.8F + r * 0.15F, 0.9F);
                sound(net.minecraft.sounds.SoundEvents.ENDERMAN_SCREAM, 0.5F, 0.5F);
            }
            case G_PHANTOM -> sound(net.minecraft.sounds.SoundEvents.PHANTOM_AMBIENT, 0.7F + r * 0.3F, 0.8F);
            case G_HISS -> sound(net.minecraft.sounds.SoundEvents.CREEPER_PRIMED, 0.9F + r * 0.2F, 0.7F);
            default -> sound(net.minecraft.sounds.SoundEvents.PHANTOM_BITE, 0.8F, 0.9F);
        }
    }

    protected static void pling(float pitch) {
        dev.cutemod.client.os.Sfx.ui(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_CHIME.value(), pitch, 0.5F);
    }
}
