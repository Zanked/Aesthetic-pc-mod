package dev.cutemod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** The portable music player. The window and the music are client-only, so the server never loads them. */
public class MusicPlayerItem extends Item {
    public MusicPlayerItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            if (player.isShiftKeyDown()) dev.cutemod.client.player.PlayerHooks.toggle();
            else dev.cutemod.client.player.PlayerHooks.open();
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("cutemod.tip.player.use").withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable("cutemod.tip.player.load").withStyle(ChatFormatting.BLUE));
    }
}
