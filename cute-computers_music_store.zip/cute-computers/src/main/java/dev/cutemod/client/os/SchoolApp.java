package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.CuteMod;
import dev.cutemod.data.ParkData;
import dev.cutemod.net.ParkBots;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Pet School: a classroom with Teacher Owl at the blackboard and five pet pupils at their desks (yours sits in the
 * middle). Pick a class (easy, medium or hard); a test has 10 / 15 / 20 questions and a time limit for every question. The
 * teacher "says" each question on the blackboard, you pick the answer, the four classmates (bots) answer too, the pupils
 * cheer or sigh. Right answers pay coins (more in the harder classes, a bonus when every answer is right), with a daily cap. Questions are in the language files:
 * cutemod.school.q.LEVEL.N and cutemod.school.a.LEVEL.N.K (answer K = 0 is the right one; the order is shuffled
 * on the screen). Saved as "school_best" (best result per class) and "school_seen" (questions already asked).
 *
 * Subjects: the first screen is a choice of a subject (the old mixed questions, English, biology, chemistry, physics, world history,
 * philosophy, literature, algebra, geometry), then the class (easy, medium, hard). The mixed subject keeps its old keys; every other subject has
 * cutemod.school.q.SUBJECT.LEVEL.N and cutemod.school.a.SUBJECT.LEVEL.N.K (25 questions per class, written by tools/make_school_subjects.py
 * from tools/school_q/SUBJECT.txt). "school_best" and "school_seen" now hold 10 subjects x 3 classes (the first three numbers are the old mixed ones).
 *
 * The school day: nine subjects come in a random order and never repeat; after every test there is a 3-minute break (it runs on the
 * real clock, you cannot skip it) in the school hall, where the pets walk about, and in the canteen, where one free meal feeds your pet
 * (PetBlob.feed). The bell then calls everybody to the next lesson. The day is saved as "school_day" (day, used subjects, lessons,
 * end of the break, subject, over, ate), the best result of every class in percent as "school_pct".
 *
 * Sound: the owl really talks (every third letter she writes on the board is a soft "hoo", made by tools/make_voices.py as
 * "voice.owl"), the classroom has its own tune (music.school in the menu and on the result, music.school_quiz while a question
 * is on the board, see GameMusic) and its own little sounds (school.bell / ding / boop / chalk / fanfare / aww, made by
 * tools/make_school_audio.py). The pupils cheer with the voices of their pets. The owl's words come in several variants
 * (the .1, .2... keys), she calls a pet by its name, and praises a streak of right answers.
 * Every text of one kind has one size: the names of the subjects, the three class cards, the answers of a question and the two buttons of the
 * result are all shrunk by the same scale (the smallest one any of them needs), so that a long word does not make its neighbours look bigger.
 * A class has up to 64 questions (the "seen" mask is a long); the mixed classes have 60, the subjects 25 in each.
 */
public class SchoolApp extends KitApp {
    private static final String[] LEVEL = {"easy", "medium", "hard"};
    private static final String[] SUBJECT = {"general", "english", "biology", "chemistry", "physics", "history", "philosophy", "literature", "algebra", "geometry"};
    private static final int SUBJECTS = SUBJECT.length;
    private static final int SUBJ_POOL = 25;                     // questions per class in every subject except "general"
    private static final int[] POOL = {60, 60, 60};          // how many questions every class of the mixed subject has in the language files (at most 64)
    private static final int[] OPTIONS = {3, 3, 4};          // answers per question
    private static final int[] LESSON_N = {10, 15, 20};      // questions in a test: easy, medium, hard
    private static final int[] SECS = {25, 20, 15};          // seconds for one question
    private static final int[] MAXPAY = {10, 20, 36};        // coins for a test with every answer right (a part of it for fewer)
    private static final int[] BONUS = {3, 5, 8};            // extra coins when every answer is right
    private static final int[] XP = {4, 7, 10};              // season pass xp for a test with every answer right
    private static final int[] CARD = {0xFFBFEFC4, 0xFFFFE9A8, 0xFFFFC6C6};
    private static final int[] CARD_EDGE = {0xFF6FBF7A, 0xFFE0B84A, 0xFFE08585};
    private static final int MAXQ = 20, DAILY_CAP = 150, DAY_LESSONS = 9;     // the longest test; coins a day; the nine subjects of one school day
    private static final long BREAK_MS = 180_000L;                              // the break: three real minutes
    private static final String PAID = "school_paid";

    private static final int MENU = 0, ASK = 1, RESULT = 2, BREAK = 3, CANTEEN = 4, DAYEND = 5, YARD = 6, HOOP = 7, NURSE = 8;      // MENU = the classes of the lesson's subject

    // the room
    private static final int BX = 74, BY = 17, BW = 218, BH = 40;   // the blackboard
    private static final int AX = 74, AW = 218;                      // the answer buttons
    private static final int FLOOR_Y = 150;                          // where the pupils stand (behind their desks)
    private static final int[] PUPIL_X = {32, 91, 150, 209, 268};
    private static final int BACK_X = 112, BACK_W = 44;             // the "back to the classes" button in the title bar
    private static final int OWN = 2;                                // the middle desk is yours

    private int mode = MENU;
    private int level;
    private int subject;                                             // index in SUBJECT
    private int[] qs = new int[MAXQ];
    private int qi, right;
    private int[] order = new int[4];                                // order[slot] = the original answer index shown there (0 = right)
    private int picked = -1, reveal, react, resultT;
    private boolean lastOk;
    private final int[] best = new int[SUBJECTS * 3];                // best result in percent per subject and class: subject * 3 + level
    private final long[] seen = new long[SUBJECTS * 3];
    private int paid;                                                // coins of the lesson just finished
    private boolean capped;
    private String teach = "";                                       // what the owl says on the board in the menu / result
    private int teachT;
    private String boardLine = "";                                      // the text on the board while a question is asked (a lead-in and the question)
    private int streak, idleN;                                       // right answers in a row; which "I am waiting" line comes next
    private String vText = "";                                       // what the owl is saying out loud right now (empty = she is quiet)
    private int vAge;
    private float vPitch = 1F;
    private static final int[] CHEER_ORDER = {2, 1, 3, 0, 4};        // the pupils cheer one after another, yours first
    private static final Map<String, String> PUPIL_VOICE = Map.of("pink", "kit", "green", "boom", "white", "mei", "blue", "pip",
            "orange", "fox", "purple", "void", "yellow", "honey", "red", "lady");
    private final Random rnd = new Random();
    private boolean loaded;

    // the school day
    private int dayNo = -1, usedMask, lessonsDone;                  // which day, the subjects already taken (bits), tests finished today
    private boolean dayOver, ate;                                    // the day is over; the pet had its free meal in this break
    private long breakEnd;                                           // 0 = no break; 1 = a test is done and the break has not started; else the real time it ends
    private final float[] botSkill = new float[PUPIL_X.length];      // how well every classmate knows things today
    private final int[] botAt = new int[PUPIL_X.length], botRight = new int[PUPIL_X.length];
    private final boolean[] botOk = new boolean[PUPIL_X.length];
    private int qTime, place;                                        // ticks of the question so far; your place in the last test
    private boolean timedOut;
    // the school hall (the break)
    private final float[] hx = new float[PUPIL_X.length], hy = new float[PUPIL_X.length], htx = new float[PUPIL_X.length], hty = new float[PUPIL_X.length];
    private final int[] hWait = new int[PUPIL_X.length], hEmote = new int[PUPIL_X.length];
    private int eatT;

    @Override protected int accent() { return 0xFF5B8DEF; }

    @Override protected String id() { return "school"; }

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        load();
        resumeDay();
    }

    private void load() {
        loaded = true;
        try {
            String s = Store.read("school_pct");
            if (s != null) {
                String[] p = s.split(",");
                for (int i = 0; i < best.length && i < p.length; i++) best[i] = Math.max(0, Math.min(100, Integer.parseInt(p[i])));
            } else if ((s = Store.read("school_best")) != null) {                  // the old saves counted right answers out of five
                String[] p = s.split(",");
                for (int i = 0; i < best.length && i < p.length; i++) best[i] = Math.max(0, Math.min(100, Integer.parseInt(p[i]) * 20));
            }
            s = Store.read("school_seen");
            if (s != null) {
                String[] p = s.split(",");
                for (int i = 0; i < seen.length && i < p.length; i++) seen[i] = Long.parseLong(p[i]);
            }
            s = Store.read("school_day");
            if (s != null) {
                String[] p = s.split(",");
                if (p.length >= 7) {
                    dayNo = Integer.parseInt(p[0]);
                    usedMask = Integer.parseInt(p[1]);
                    lessonsDone = Integer.parseInt(p[2]);
                    breakEnd = Long.parseLong(p[3]);
                    subject = Math.max(0, Math.min(SUBJECTS - 1, Integer.parseInt(p[4])));
                    dayOver = p[5].equals("1");
                    ate = p[6].equals("1");
                }
            }
        } catch (NumberFormatException ignored) { }
    }

    private void save() {
        StringBuilder b = new StringBuilder(), n = new StringBuilder();
        for (int i = 0; i < best.length; i++) { if (i > 0) { b.append(','); n.append(','); } b.append(best[i]); n.append(seen[i]); }
        Store.write("school_pct", b.toString());
        Store.write("school_seen", n.toString());
    }

    private void saveDay() {
        Store.write("school_day", dayNo + "," + usedMask + "," + lessonsDone + "," + breakEnd + "," + subject + "," + (dayOver ? 1 : 0) + "," + (ate ? 1 : 0));
    }

    // ---------- the school day: subjects in a random order that never repeats, a test, a break ----------
    private void initBots() {
        for (int i = 0; i < botSkill.length; i++) botSkill[i] = 0.55F + rnd.nextFloat() * 0.35F;
    }

    /** The app is opened: go on with today's school, or start a new day. */
    private void resumeDay() {
        if (botSkill[0] == 0F) initBots();
        long now = System.currentTimeMillis();
        if (dayNo != today()) { newDay(); return; }
        if (dayOver || lessonsDone >= DAY_LESSONS) { dayEnd(); return; }
        if (breakEnd == 1) { goBreak(); return; }                   // a test was finished and the break has not started yet
        if (breakEnd > now) { mode = BREAK; hallInit(); return; }   // the break goes on (it runs on the real clock)
        if (breakEnd != 0 || subject <= 0 || (usedMask >> subject & 1) == 0) { nextLesson(); return; }    // the bell rang while the player was away
        mode = MENU;
        greet();
    }

    private void newDay() {
        dayNo = today();
        usedMask = 0;
        lessonsDone = 0;
        dayOver = false;
        ate = false;
        breakEnd = 0;
        initBots();
        nextLesson();
    }

    /** The bell: the next subject is drawn by lot among those that have not been today. */
    private void nextLesson() {
        List<Integer> free = new ArrayList<>();
        for (int k = 1; k < SUBJECTS; k++) if ((usedMask >> k & 1) == 0) free.add(k);
        if (free.isEmpty()) { dayEnd(); return; }
        subject = free.get(rnd.nextInt(free.size()));
        usedMask |= 1 << subject;
        breakEnd = 0;
        mode = MENU;
        saveDay();
        Sfx.ui(snd("school.bell"), 1F, 0.6F);
        teach = t("cutemod.school.day.next", t("cutemod.school.subj.full." + SUBJECT[subject]));
        teachT = 0;
        speak(teach, 1F);
    }

    private void dayEnd() {
        mode = DAYEND;
        dayOver = true;
        breakEnd = 0;
        saveDay();
        teach = t("cutemod.school.dayend.say");
        teachT = 0;
        speak(teach, 1F);
    }

    /** The result is shown (or the player pressed the button): the break starts, three real minutes. */
    private void leaveResult() {
        if (lessonsDone >= DAY_LESSONS) dayEnd(); else goBreak();
    }

    private void goBreak() {
        breakEnd = System.currentTimeMillis() + BREAK_MS;
        ate = false;
        eatT = 0;
        saveDay();
        mode = BREAK;
        vText = "";
        Sfx.ui(snd("school.bell"), 0.85F, 0.6F);
        hallInit();
        say("cutemod.school.break.start");
    }

    private int lessonN() { return LESSON_N[level]; }

    private boolean perfect() { return right == lessonN(); }

    /** 0..5: how well the test went (5 = every answer right), for the owl's words and the cheering. */
    private int band() { return perfect() ? 5 : Math.min(4, right * 5 / lessonN()); }

    private int scoreOf(int pupil) { return pupil == OWN ? right : botRight[pupil]; }

    private int secsLeft() { return Math.max(0, (SECS[level] * 60 - qTime + 59) / 60); }

    private String clock() {
        long left = Math.max(0, breakEnd - System.currentTimeMillis()) / 1000;
        return (left / 60) + ":" + (left % 60 < 10 ? "0" : "") + (left % 60);
    }

    /** Index of a class of the chosen subject in best[] and seen[]. */
    private int idx(int lv) { return subject * 3 + lv; }

    /** How many questions the class has in the language files. */
    private int pool(int lv) { return subject == 0 ? POOL[lv] : SUBJ_POOL; }

    /** The language key of a question ("q") or of its answers ("a"): the mixed subject keeps the old keys without a subject. */
    private String key(String kind) { return "cutemod.school." + kind + "." + (subject == 0 ? "" : SUBJECT[subject] + ".") + LEVEL[level] + "."; }

    private void greet() {
        String nm = petName();
        int v = rnd.nextInt(nm.isEmpty() ? 4 : 5);
        teach = v == 4 ? t("cutemod.school.hello.nm", nm) : t(v == 0 ? "cutemod.school.hello" : "cutemod.school.hello." + v);
        teachT = 0;
        speak(teach, 1F);
    }

    // ---------- sounds: a school event, the owl's voice, the pupils' voices ----------
    private static final Map<String, SoundEvent> SND = new HashMap<>();

    /** Our own sound event (sounds.json): "school.ding", "voice.owl", "tales.page"... */
    private static SoundEvent snd(String name) {
        return SND.computeIfAbsent(name, n -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, n)));
    }

    /** The name the player gave the pet, or "" (then the owl does not use a name). */
    private String petName() {
        ComputerColor sp = PetApp.speciesOf(shell.color());
        return PetName.custom((sp == null ? shell.color() : sp).id);
    }

    /** The owl starts to say a text (it is the same text that is written on the board or shown as her answer). */
    private void speak(String text, float pitch) { vText = text; vAge = 0; vPitch = pitch; }

    /** Every tick: one soft "hoo" for every third letter, at the speed the letters appear on the board (a letter every 2 ticks). */
    private void voiceTick() {
        if (vText.isEmpty()) return;
        vAge++;
        if (vAge % 2 != 0) return;
        int shown = vAge / 2;
        if (shown > vText.length()) { vText = ""; return; }
        if (shown % 3 != 0) return;
        char c = vText.charAt(shown - 1);
        if (!Character.isLetterOrDigit(c)) return;
        Sfx.ui(snd("voice.owl"), vPitch * (0.9F + (c % 7) * 0.04F), 0.55F);
    }

    private ComputerColor[] crowd() {
        ComputerColor own = PetApp.speciesOf(shell.color());
        if (own == null) own = shell.color();
        ComputerColor[] all = ComputerColor.values();
        ComputerColor[] out = new ComputerColor[PUPIL_X.length];
        int k = 1;
        for (int i = 0; i < out.length; i++) out[i] = i == OWN ? own : all[(own.ordinal() + k++) % all.length];
        return out;
    }

    /** A pupil answers with the voice of its pet (the same voices as in the Tamagotchi app). */
    private void pupilVoice(int i, float pitch) {
        ComputerColor c = crowd()[i];
        Sfx.ui(snd("voice." + PUPIL_VOICE.getOrDefault(c.id, "kit")), pitch, c == ComputerColor.PURPLE ? 0.6F : 0.42F);
    }

    private void start(int lv) {
        level = lv;
        streak = 0;
        Sfx.ui(snd("school.bell"), 1F, 0.6F);
        // unasked questions first; when fewer than the test needs are left the round starts again
        List<Integer> fresh = new ArrayList<>(), old = new ArrayList<>();
        int k = idx(lv), n = lessonN();
        for (int i = 0; i < pool(lv); i++) (((seen[k] >> i) & 1L) == 0 ? fresh : old).add(i);
        Collections.shuffle(fresh, rnd);
        Collections.shuffle(old, rnd);
        boolean again = fresh.size() < n;
        List<Integer> pick = new ArrayList<>(fresh);
        pick.addAll(old);
        long mask = again ? 0L : seen[k];
        for (int i = 0; i < n; i++) { qs[i] = pick.get(i); mask |= 1L << qs[i]; }
        seen[k] = mask;
        qi = 0;
        right = 0;
        Arrays.fill(botRight, 0);
        mode = ASK;
        nextQuestion();
    }

    private void nextQuestion() {
        int n = OPTIONS[level];
        List<Integer> o = new ArrayList<>();
        for (int i = 0; i < n; i++) o.add(i);
        Collections.shuffle(o, rnd);
        for (int i = 0; i < n; i++) order[i] = o.get(i);
        picked = -1;
        reveal = 0;
        react = 0;
        qTime = 0;
        timedOut = false;
        botsQuestion();
        boardLine = lead() + question();
        speak(boardLine, 1F);
        Sfx.ui(snd("school.chalk"), 0.95F + rnd.nextFloat() * 0.1F, 0.5F);
    }

    /** A little something the owl says before the question: at the start, before the last one, and now and then in between. */
    private String lead() {
        String k;
        if (qi == 0) k = "cutemod.school.lead.first." + rnd.nextInt(3);
        else if (qi == lessonN() - 1) k = "cutemod.school.lead.last";
        else if ((qs[qi] + qi) % 3 == 0) k = "cutemod.school.lead.mid." + rnd.nextInt(6);
        else return "";
        return t(k) + " ";
    }

    private String question() { return t(key("q") + qs[qi]); }

    private String answer(int slot) { return t(key("a") + qs[qi] + "." + order[slot]); }

    private int rightSlot() {
        for (int s = 0; s < OPTIONS[level]; s++) if (order[s] == 0) return s;
        return 0;
    }

    private int revealLen() { return boardLine.length(); }

    private boolean revealed() { return reveal >= revealLen() * 2; }

    private void choose(int slot) {
        picked = slot;
        lastOk = slot == rightSlot();
        react = 0;
        if (lastOk) { right++; streak++; } else streak = 0;
        if (lastOk) {
            Sfx.ui(snd("school.ding"), 1F, 0.7F);
            String nm = petName();
            if (streak >= 3) say("cutemod.school.streak." + Math.min(streak, 5));
            else if (!nm.isEmpty() && rnd.nextInt(4) == 0) say("cutemod.school.right.nm." + rnd.nextInt(3), nm);
            else say("cutemod.school.right." + rnd.nextInt(8));
        } else {
            Sfx.ui(snd("school.boop"), 1F, 0.6F);
            int w = rnd.nextInt(6);
            say(w == 0 ? "cutemod.school.wrong" : "cutemod.school.wrong." + w);
        }
        speak(msg, lastOk ? 1.12F : 0.9F);
        settleBots();
    }

    /** Every classmate decides how it will answer this question and when (a few do not make it in time). */
    private void botsQuestion() {
        int lim = SECS[level] * 60;
        float shift = level == 0 ? 0.08F : level == 2 ? -0.10F : 0F;
        for (int i = 0; i < PUPIL_X.length; i++) {
            if (i == OWN) continue;
            botOk[i] = rnd.nextFloat() < Math.max(0.2F, Math.min(0.97F, botSkill[i] + shift));
            botAt[i] = (int) (lim * (0.25F + rnd.nextFloat() * 0.6F));
            if (rnd.nextInt(30) == 0) { botAt[i] = lim + 1; botOk[i] = false; }
        }
    }

    /** The question is over: the right answers of the classmates are counted. */
    private void settleBots() {
        for (int i = 0; i < PUPIL_X.length; i++) if (i != OWN && botOk[i]) botRight[i]++;
    }

    /** The time of the question has run out: the answer counts as wrong, the right one is shown. */
    private void timeUp() {
        picked = rightSlot();
        timedOut = true;
        lastOk = false;
        react = 0;
        streak = 0;
        Sfx.ui(snd("school.boop"), 0.9F, 0.6F);
        say("cutemod.school.timeout");
        speak(msg, 0.9F);
        settleBots();
    }

    private void advance() {
        if (picked < 0) return;
        Sfx.ui(snd("tales.page"), 1.3F, 0.35F);
        if (qi + 1 < lessonN()) { qi++; nextQuestion(); return; }
        finish();
    }

    private void finish() {
        mode = RESULT;
        resultT = 0;
        int n = lessonN();
        int pay = Math.round(MAXPAY[level] * right / (float) n) + (perfect() ? BONUS[level] : 0);
        int room = Math.max(0, DAILY_CAP - paidToday(PAID));
        capped = pay > room;
        pay = Math.min(pay, room);
        paid = pay;
        if (pay > 0) { addPaid(PAID, pay); Progress.earn(pay); }
        Season.add(XP[level] * right / n);
        int pct = right * 100 / n;
        if (pct > best[idx(level)]) best[idx(level)] = pct;
        place = 1;
        for (int i = 0; i < PUPIL_X.length; i++) if (i != OWN && botRight[i] > right) place++;
        lessonsDone++;
        breakEnd = lessonsDone >= DAY_LESSONS ? 0 : 1;           // 1 = the break is waiting
        saveDay();
        Progress.setCount("school_lessons", Progress.count("school_lessons") + 1);
        Progress.setCount("school_right", Progress.count("school_right") + right);
        save();
        Sfx.ui(snd(band() >= 4 ? "school.fanfare" : band() <= 1 ? "school.aww" : "school.ding"), 1F, 0.7F);
        teach = resultLine();
        teachT = 0;
        speak(teach, band() >= 3 ? 1.1F : 0.92F);
    }

    private String resultLine() {
        String nm = petName();
        int b = band();
        if (b == 5 && !nm.isEmpty() && rnd.nextBoolean()) return t("cutemod.school.result.5.nm", nm);
        int v = rnd.nextInt(3);
        return t(v == 0 ? "cutemod.school.result." + b : "cutemod.school.result." + b + "." + v);
    }

    private void toMenu() { mode = MENU; greet(); }          // the test is given up: back to the classes of the same subject

    @Override
    public void tick() {
        super.tick();
        GameMusic.keep(mode == ASK ? "school_quiz" : "school", false);      // the classroom tune; it fades out by itself when the app is not on screen
        voiceTick();
        if (mode == ASK) {
            if (reveal < revealLen() * 2) reveal++;
            if (picked >= 0) { react++; cheerTick(); }
            else if (revealed() && ++qTime >= SECS[level] * 60) timeUp();
        } else if (mode == BREAK || mode == CANTEEN || mode == YARD || mode == HOOP || mode == NURSE) {
            breakTick();
            if (nurseT > 0) nurseT--;
            if (mode == YARD) yardTick();
            if (mode == HOOP) hoopTick();
            if (eatT > 0 && ++eatT > 150) eatT = 0;
        } else {
            teachT++;
            if (mode == RESULT) {
                resultT++;
                resultCheer();
                if (resultT >= 1800) leaveResult();                       // half a minute on the result: the bell, off to the break
            } else if (mode == MENU && teachT >= 1200 && vText.isEmpty()) {   // nobody has chosen a class for 20 seconds: the owl asks kindly
                teach = t("cutemod.school.idle." + idleN++ % 4);
                teachT = 0;
                speak(teach, 1F);
            }
        }
    }

    @Override
    public void close() { GameMusic.stop(); }

    private void cheerTick() {
        if (lastOk) {
            int k = react - 6;
            if (k >= 0 && k % 3 == 0 && k / 3 < 5) {
                int p = CHEER_ORDER[k / 3];
                if (p == OWN || botOk[p]) pupilVoice(p, 1.12F + 0.05F * (k / 3));        // only those who were right cheer
            }
        } else if (react == 10) {
            pupilVoice(OWN, 0.8F);
        }
    }

    private void resultCheer() {
        if (band() < 4) return;
        int k = resultT - 10, n = perfect() ? 10 : 5;
        if (k >= 0 && k % 5 == 0 && k / 5 < n) pupilVoice(CHEER_ORDER[(k / 5) % 5], 1.1F + 0.04F * ((k / 5) % 5));
    }

    // ---------- drawing ----------
    private static final int CARD_Y = 63, CARD_H = 62, CARD_W = 70, CARD_STEP = 74;
    private static final int NEXT_W = 66, NEXT_Y = 128, RES_Y = 104, ANS_Y = 63;
    private static final int[] BADGE = {0xFFF58FB8, 0xFF6FB0FF, 0xFF7ACB8A, 0xFFF5B84A};
    private static final int WOOD = 0xFF9A6A3C, WOOD_LIGHT = 0xFFC8955C, WOOD_DARK = 0xFF6E4726;

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        rect(g, 0, 0, W, H, 0xFFFDF0F7);
        rect(g, 0, 0, W, 14, accent());
        rect(g, 0, 14, W, 1, 0x55FFFFFF);
        int hy = CuteFont.size() == 2 ? 2 : 3;
        boolean out = mode == BREAK || mode == CANTEEN || mode == YARD || mode == HOOP || mode == NURSE;
        String title = mode == BREAK ? t("cutemod.school.break.title") : mode == CANTEEN ? t("cutemod.school.canteen.title") : mode == YARD ? t("cutemod.school.yard.title") : mode == HOOP ? t("cutemod.school.hoop.title") : mode == NURSE ? t("cutemod.school.nurse.title")
                : mode == DAYEND || subject == 0 ? t("cutemod.os.school") : t("cutemod.school.subj.full." + SUBJECT[subject]);
        fit(g, f, title, 5, hy, BACK_X - 10, 0xFFFFFFFF, false);
        String top;
        if (out) top = t("cutemod.school.break.left", clock());
        else if (mode == ASK) top = t("cutemod.school.question", qi + 1, lessonN()) + (picked < 0 && revealed() ? "  " + t("cutemod.school.timer", secsLeft()) : "");
        else top = t("cutemod.school.lesson", Math.min(DAY_LESSONS, lessonsDone + (mode == MENU ? 1 : 0)), DAY_LESSONS);
        int tw = Math.min(f.width(top), 120);
        fit(g, f, top, W - 6 - tw, hy, 120, 0xFFFFFFFF, false);
        if (out) {                                                    // the break: the hall or the canteen, no way back to the class until the bell
            if (mode == BREAK) hall(g, f, mx, my); else if (mode == YARD) yard(g, f, mx, my); else if (mode == HOOP) hoop(g, f, mx, my); else if (mode == NURSE) nurse(g, f, mx, my); else canteen(g, f, mx, my);
            footer(g, f);
            return;
        }
        room(g);
        board(g, f);
        teacher(g, f);
        pupils(g);
        switch (mode) {
            case MENU -> menu(g, f, mx, my);
            case ASK -> ask(g, f, mx, my);
            case DAYEND -> dayend(g, f, mx, my);
            default -> result(g, f, mx, my);
        }
        if (mode == ASK || mode == MENU) {
            boolean hb = in(mx, my, BACK_X, 1, BACK_W, 12);
            roundRect(g, BACK_X, 1, BACK_W, 12, 5, hb ? 0x77FFFFFF : 0x33FFFFFF);
            fit(g, f, t(mode == ASK ? "cutemod.school.back" : "cutemod.school.home"), BACK_X + BACK_W / 2, 3, BACK_W - 4, 0xFFFFFFFF, true);
        }
        if (mode == RESULT && band() >= 4) confetti(g);
    }

    // ----- small drawing helpers -----
    private static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int color) {
        int n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= n; i++) rect(g, x0 + (x1 - x0) * i / Math.max(1, n), y0 + (y1 - y0) * i / Math.max(1, n), 1, 1, color);
    }

    private static void heart(GuiGraphics g, int cx, int cy, int c) {
        rect(g, cx - 3, cy - 2, 2, 2, c); rect(g, cx + 1, cy - 2, 2, 2, c);
        rect(g, cx - 3, cy - 1, 6, 2, c); rect(g, cx - 2, cy + 1, 4, 1, c); rect(g, cx - 1, cy + 2, 2, 1, c);
    }

    private static void coin(GuiGraphics g, int cx, int cy) {
        disc(g, cx, cy, 4, 0xFFC98A10); disc(g, cx, cy, 3, 0xFFFFD34E); rect(g, cx - 1, cy - 2, 1, 4, 0xFFFFF0A0);
    }

    private static void sparkle(GuiGraphics g, int cx, int cy, int r, int c) {
        rect(g, cx, cy - r, 1, r * 2 + 1, c); rect(g, cx - r, cy, r * 2 + 1, 1, c);
    }

    /** A rounded button with a soft shadow; style 1 = main (accent), 0 = light. */
    private void pill(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, int h, String label, int style) { pill(g, f, mx, my, x, y, w, h, label, style, -1F); }

    /** sc = the scale of the label (the same for buttons that stand together), -1 = as large as fits. */
    private void pill(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, int h, String label, int style, float sc) {
        boolean hov = in(mx, my, x, y, w, h);
        int bg = style == 1 ? (hov ? mix(accent(), 0x000000, 0.12F) : accent()) : hov ? 0xFFFFF3B0 : 0xFFFFFFFF;
        roundRect(g, x, y + 2, w, h, 5, 0x44000000);
        roundRect(g, x, y, w, h, 5, bg);
        rect(g, x + 4, y + 1, w - 8, 1, 0x55FFFFFF);
        int ly = y + (h - 8) / 2 - (CuteFont.size() == 2 ? 1 : 0), ink = style == 1 ? 0xFFFFFFFF : TEXT;
        if (sc < 0) fit(g, f, label, x + w / 2, ly, w - 8, ink, true); else fitS(g, f, label, x + w / 2, ly, w - 8, sc, ink, true);
    }

    /** The wall with soft stripes, a wooden rail, the floor and everything that hangs on the left wall. */
    private void room(GuiGraphics g) {
        rect(g, 0, 15, W, 107, 0xFFFFF3E0);
        for (int x = 0; x < W; x += 14) rect(g, x, 15, 7, 107, 0xFFFFECD2);
        rect(g, 0, 98, W, 20, 0xFFF3C9A0);                         // the wall panel
        rect(g, 0, 98, W, 2, 0xFFE6B07C);
        for (int x = 0; x < W; x += 20) rect(g, x, 100, 1, 18, 0x22A06A3A);
        rect(g, 0, 118, W, 4, WOOD_LIGHT);                         // the skirting
        rect(g, 0, 118, W, 1, 0x55FFFFFF);
        rect(g, 0, 122, W, H - 122, 0xFFE0B27A);                   // the floor
        for (int x = -20; x < W; x += 34) { line(g, x + 10, 122, x, H, 0x22804A1A); }
        rect(g, 0, 122, W, 1, 0x33000000);
        // a pink rug under the pupils
        roundRect(g, 8, 130, W - 16, H - 130, 6, 0x55F4A7C3);
        roundRect(g, 12, 133, W - 24, H - 133, 5, 0x33FFFFFF);
        // the window: sky, a sun, curtains and a sill
        rect(g, 3, 18, 36, 28, WOOD_LIGHT);
        rect(g, 5, 20, 32, 24, 0xFFBFE6FF);
        rect(g, 5, 33, 32, 11, 0xFFD6F2D0);
        disc(g, 13, 28, 3, 0xFFFFE680);
        rect(g, 19, 20, 2, 24, WOOD_LIGHT); rect(g, 5, 31, 32, 2, WOOD_LIGHT);
        rect(g, 4, 19, 6, 25, 0xFFF4A7C3); rect(g, 32, 19, 6, 25, 0xFFF4A7C3);
        rect(g, 6, 19, 1, 25, 0x55FFFFFF); rect(g, 34, 19, 1, 25, 0x55FFFFFF);
        rect(g, 2, 45, 38, 3, WOOD);
        // a wall clock that shows the real time
        disc(g, 55, 29, 10, WOOD); disc(g, 55, 29, 9, 0xFFFFFFFF);
        for (int k = 0; k < 12; k++) { double a = k * Math.PI / 6; rect(g, 55 + (int) Math.round(Math.sin(a) * 7), 29 - (int) Math.round(Math.cos(a) * 7), 1, 1, 0xFF8A7AA8); }
        java.time.LocalTime now = java.time.LocalTime.now();
        double ma = now.getMinute() / 60.0 * Math.PI * 2, ha = (now.getHour() % 12 + now.getMinute() / 60.0) / 12 * Math.PI * 2;
        line(g, 55, 29, 55 + (int) Math.round(Math.sin(ma) * 6), 29 - (int) Math.round(Math.cos(ma) * 6), 0xFF3A2A3A);
        line(g, 55, 29, 55 + (int) Math.round(Math.sin(ha) * 4), 29 - (int) Math.round(Math.cos(ha) * 4), 0xFFE5486F);
    }

    private void board(GuiGraphics g, Font f) {
        roundRect(g, BX - 4, BY - 4, BW + 8, BH + 8, 4, WOOD_DARK);
        roundRect(g, BX - 3, BY - 3, BW + 6, BH + 6, 4, WOOD_LIGHT);
        rect(g, BX - 1, BY - 1, BW + 2, BH + 2, WOOD_DARK);
        rect(g, BX, BY, BW, BH, 0xFF2E5E4A);
        rect(g, BX, BY, BW, BH / 2, 0xFF336651);
        for (int i = 0; i < 6; i++) rect(g, BX + 12 + i * 37, BY + 8 + (i * 17) % 28, 20, 1, 0x12FFFFFF);    // chalk dust
        // chalk doodles in the corner
        sparkle(g, BX + BW - 10, BY + BH - 9, 3, 0x88FFE680);
        heart(g, BX + BW - 22, BY + BH - 8, 0x88FFB0C8);
        rect(g, BX - 3, BY + BH + 3, BW + 6, 3, WOOD);                // the chalk tray
        rect(g, BX + 8, BY + BH + 1, 7, 3, 0xFFFFFFFF);
        rect(g, BX + 18, BY + BH + 1, 6, 3, 0xFFFFB0C8);
        rect(g, BX + BW - 30, BY + BH, 20, 4, 0xFFF0D8A8); rect(g, BX + BW - 30, BY + BH + 2, 20, 2, 0xFF7A5A8A);   // an eraser
        String s = mode == ASK ? boardLine : teach;
        int shown = mode == ASK ? Math.min(s.length(), reveal / 2) : Math.min(s.length(), teachT / 2);
        boardText(g, f, s, shown, mode == MENU ? BH - 17 : mode == ASK ? BH - 12 : BH - 9);
        if (mode == MENU) {
            coin(g, BX + 12, BY + BH - 7);
            fit(g, f, t("cutemod.school.today", paidToday(PAID), DAILY_CAP), BX + 20, BY + BH - 11, BW - 60, 0xFFFFE680, false);
            subjectEmblem(g, subject, BX + BW - 14, BY + BH - 10);
        }
        if (mode == ASK && revealed()) {                              // the time of the question: a chalk bar that gets shorter
            float fr = Math.max(0F, 1F - qTime / (float) (SECS[level] * 60));
            int bw = BW - 12;
            rect(g, BX + 6, BY + BH - 5, bw, 3, 0x33FFFFFF);
            int col = fr > 0.5F ? 0xFF7ACB8A : fr > 0.25F ? 0xFFFFD34E : (ticks / 8) % 2 == 0 ? 0xFFFF6A6A : 0xFFFFA0A0;
            rect(g, BX + 6, BY + BH - 5, Math.round(bw * fr), 3, col);
        }
    }

    /** Width a text really takes in fit(). */
    private static int fitW(Font f, String s, int maxW) {
        int w = f.width(s);
        return w <= maxW ? w : Math.min(maxW, (int) (w * Math.max(0.5F, maxW / (float) w)));
    }

    /** Like fitText, but a long text may shrink down to half size (a big font, a long translation) before it is cut. Returns the width drawn. */
    private static int fit(GuiGraphics g, Font f, String s, int x, int y, int maxW, int color, boolean centered) {
        int w = f.width(s);
        if (w <= maxW) {
            CuteFont.draw(g, f, s, centered ? x - w / 2 : x, y, color, false);
            return w;
        }
        float sc = Math.max(0.5F, maxW / (float) w);
        String cut = w * sc > maxW ? f.plainSubstrByWidth(s, (int) (maxW / sc)) : s;
        float tw = f.width(cut) * sc;
        g.pose().pushPose();
        g.pose().translate(centered ? x - tw / 2f : x, y + (1 - sc) * 4f, 0);
        g.pose().scale(sc, sc, 1f);
        CuteFont.draw(g, f, cut, 0, 0, color, false);
        g.pose().popPose();
        return (int) tw;
    }

    /** The one scale that makes every one of these texts fit maxW (1 = no shrinking, at least 0.5): the same for the whole group, so that the texts look equally big. */
    private static float groupScale(Font f, int maxW, String... texts) {
        float sc = 1F;
        for (String s : texts) {
            int w = f.width(s);
            if (w > maxW) sc = Math.min(sc, maxW / (float) w);
        }
        return Math.max(0.5F, sc);
    }

    /** Draws a text at the scale of its group (see groupScale); a text that is still too wide at that scale is cut. */
    private static void fitS(GuiGraphics g, Font f, String s, int x, int y, int maxW, float sc, int color, boolean centered) {
        if (sc >= 0.999F) { fit(g, f, s, x, y, maxW, color, centered); return; }
        String cut = f.width(s) * sc > maxW ? f.plainSubstrByWidth(s, (int) (maxW / sc)) : s;
        float tw = f.width(cut) * sc;
        g.pose().pushPose();
        g.pose().translate(centered ? x - tw / 2f : x, y + (1 - sc) * 4f, 0);
        g.pose().scale(sc, sc, 1f);
        CuteFont.draw(g, f, cut, 0, 0, color, false);
        g.pose().popPose();
    }

    private static int lineH() { return CuteFont.size() == 0 ? 9 : CuteFont.size() == 1 ? 10 : 12; }

    private static List<String> wrap(Font f, String text, int w) {
        StringBuilder line = new StringBuilder();
        List<String> lines = new ArrayList<>();
        for (String word : text.split(" ")) {
            if (f.width(line + word) > w && line.length() > 0) { lines.add(line.toString()); line.setLength(0); }
            line.append(word).append(' ');
        }
        lines.add(line.toString());
        return lines;
    }

    /** The text of the blackboard: it is made smaller until all its lines fit the board (a big font or a long text), and it is "written" letter by letter. */
    private void boardText(GuiGraphics g, Font f, String text, int budget, int avail) {
        int w = BW - 16, lh = lineH();
        float sc = 1F;
        List<String> lines = wrap(f, text, w);
        for (float tryScale : new float[]{0.88F, 0.78F, 0.68F, 0.6F}) {
            if (lines.size() * lh * sc <= avail) break;
            sc = tryScale;
            lines = wrap(f, text, (int) (w / sc));
        }
        g.pose().pushPose();
        g.pose().translate(BX + 8, BY + 5, 0);
        g.pose().scale(sc, sc, 1F);
        int left = budget;
        for (int i = 0; i < lines.size() && left > 0; i++) {
            String ln = lines.get(i);
            CuteFont.draw(g, f, ln.length() <= left ? ln : ln.substring(0, left), 0, i * lh, 0xFFF4FFF4, false);
            left -= ln.length();
        }
        g.pose().popPose();
    }

    private boolean talking() { return !vText.isEmpty(); }

    /** Teacher Owl: round, brown, round glasses, a bow tie, a graduation cap and a pointer, behind her desk. */
    private void teacher(GuiGraphics g, Font f) {
        int cx = 36, cy = 80;
        // the desk: a top, a front with a drawer, a books stack, an apple and a little plant
        roundRect(g, 2, 92, 68, 5, 2, WOOD_LIGHT);
        rect(g, 4, 96, 64, 24, WOOD);
        rect(g, 4, 96, 64, 1, 0x33FFFFFF);
        rect(g, 4, 118, 64, 2, WOOD_DARK);
        rect(g, 7, 99, 58, 17, 0xFF8A5A2E);
        rect(g, 7, 99, 58, 1, 0x22000000);
        rect(g, 54, 85, 12, 3, 0xFF5B8DEF); rect(g, 55, 82, 10, 3, 0xFFF4A7C3); rect(g, 54, 88, 12, 4, 0xFF7ACB8A);   // books
        disc(g, 12, 89, 3, 0xFFE5484D); rect(g, 12, 84, 1, 3, 0xFF4A7A3A); rect(g, 13, 84, 3, 2, 0xFF6BC46A);        // an apple
        rect(g, 20, 88, 6, 4, 0xFFE0705A); rect(g, 21, 83, 1, 5, 0xFF4A9A4A); rect(g, 23, 82, 1, 6, 0xFF6BC46A); rect(g, 19, 85, 2, 1, 0xFF6BC46A);   // a plant
        int hop = react > 0 && react < 24 && picked >= 0 && lastOk ? (int) Math.round(Math.abs(Math.sin(react / 3.0)) * 4) : 0;
        int bob = (int) Math.round(Math.sin(ticks / 22.0));
        int y = cy - hop + bob - 6;
        boolean happy = mode == ASK && picked >= 0 && lastOk || mode == RESULT && band() >= 3 || mode == DAYEND;
        boolean sad = mode == ASK && picked >= 0 && !lastOk || mode == RESULT && band() <= 1;
        oval(g, cx, 92, 16, 2, 0x33000000);
        // wings and body
        int flap = happy ? (int) Math.round(Math.sin(ticks / 3.0) * 3) : 0;
        disc(g, cx - 15, y + 5 - flap, 5, 0xFF7E5230);
        disc(g, cx + 15, y + 5 - flap, 5, 0xFF7E5230);
        disc(g, cx, y, 15, 0xFF9C6B3F);
        disc(g, cx, y - 3, 13, 0xFFA97745);
        disc(g, cx, y + 6, 9, 0xFFF6E3B8);
        for (int r = 0; r < 3; r++) for (int k = -1; k <= 1; k++) rect(g, cx + k * 4 - 1 + (r % 2) * 2, y + 4 + r * 3, 3, 1, 0xFFD2A878);
        rect(g, cx - 13, y - 17, 5, 5, 0xFF7E5230); rect(g, cx + 8, y - 17, 5, 5, 0xFF7E5230);      // ear tufts
        // glasses and eyes
        for (int s = -1; s <= 1; s += 2) {
            int ex = cx + s * 6;
            disc(g, ex, y - 4, 6, 0xFF3A2A3A);
            disc(g, ex, y - 4, 5, 0xFFFFFFFF);
            if (happy) { rect(g, ex - 2, y - 5, 4, 1, 0xFF3A2A3A); rect(g, ex - 3, y - 4, 1, 1, 0xFF3A2A3A); rect(g, ex + 2, y - 4, 1, 1, 0xFF3A2A3A); }
            else { disc(g, ex + (sad ? 0 : (int) Math.round(Math.sin(ticks / 40.0))), y - 3 + (sad ? 1 : 0), 2, 0xFF3A2A3A); rect(g, ex - 1, y - 4, 1, 1, 0xFFFFFFFF); }
            rect(g, ex + s * 5 - 1, y + 1, 3, 2, 0x88FFA8A8);                                           // a rosy cheek
        }
        rect(g, cx - 1, y - 5, 2, 2, 0xFF3A2A3A);
        boolean open = talking() && (ticks / 4) % 2 == 0;
        rect(g, cx - 2, y + 1, 4, open ? 4 : 2, 0xFFF5A623);
        rect(g, cx - 1, y + 5, 2, open ? 1 : 0, 0xFFB5701A);
        // a bow tie
        rect(g, cx - 5, y + 8, 4, 4, 0xFFE5486F); rect(g, cx + 1, y + 8, 4, 4, 0xFFE5486F); rect(g, cx - 1, y + 9, 2, 2, 0xFFB02A4F);
        rect(g, cx - 8, y + 15, 5, 2, 0xFFF5A623); rect(g, cx + 3, y + 15, 5, 2, 0xFFF5A623);
        // the graduation cap with a tassel
        rect(g, cx - 9, y - 17, 18, 5, 0xFF2A2A3A);
        rect(g, cx - 9, y - 22, 18, 3, 0xFF3A3A4E);
        rect(g, cx - 14, y - 19, 28, 3, 0xFF3A3A4E);
        rect(g, cx - 14, y - 19, 28, 1, 0xFF55557A);
        rect(g, cx + 12, y - 18, 1, 8, 0xFFFFD34E); rect(g, cx + 11, y - 11, 3, 3, 0xFFFFD34E);
        // the pointer
        int px = cx + 19, py = y + 2 - (talking() ? (int) Math.round(Math.sin(ticks / 5.0) * 2) : 0);
        for (int k = 0; k < 12; k++) rect(g, px + k * 3 / 2, py - k, 2, 2, 0xFFE9C46A);
        rect(g, px + 19, py - 12, 3, 3, 0xFFE5484D);
        if (sad && (ticks / 10) % 2 == 0) disc(g, cx + 17, y - 14, 2, 0xFF8AD0FF);
        if (happy) { sparkle(g, cx - 20, y - 12 - (ticks / 4) % 4, 2, 0xFFFFE680); sparkle(g, cx + 22, y - 18 + (ticks / 5) % 3, 1, 0xFFFFFFFF); }
        // the name plate on the desk
        roundRect(g, 8, 104, 56, 11, 3, 0xFFFFF1D6);
        fit(g, f, t("cutemod.school.teacher"), 36, 106, 50, 0xFF6E4726, true);
    }

    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(1 - dy * dy / (double) (ry * ry + 1)));
            g.fill(cx - dx, cy + dy, cx + dx, cy + dy + 1, argb);
        }
    }

    private void pupils(GuiGraphics g) {
        ComputerColor[] crowd = crowd();
        int lim = mode == ASK ? SECS[level] * 60 : 0;
        int n = mode == ASK || mode == RESULT ? lessonN() : 1;
        int top = 0;
        for (int i = 0; i < PUPIL_X.length; i++) top = Math.max(top, scoreOf(i));
        int[] bookColor = {0xFF7ACB8A, 0xFF6FB0FF, 0xFFF58FB8, 0xFFF5B84A, 0xFFB57BD6};
        for (int i = 0; i < PUPIL_X.length; i++) {
            boolean mine = i == OWN;
            ComputerColor c = crowd[i];
            int mood = 1, hop = 0;
            boolean ok = mine ? lastOk : botOk[i];                       // was this pupil right in the question that is over
            if (mode == ASK && picked >= 0 && react < 50) {
                if (ok) { mood = 2; hop = (int) Math.round(Math.abs(Math.sin((react + i * 4) / 4.0)) * 6); }
                else if (mine) mood = 0;
            } else if (mode == RESULT) {
                mood = scoreOf(i) * 100 / n >= 60 ? 2 : mine ? 0 : 1;
                if (scoreOf(i) == n) hop = (int) Math.round(Math.abs(Math.sin((resultT + i * 5) / 4.0)) * 6);
            } else if (mode == MENU || mode == DAYEND) mood = 2;
            int cx = PUPIL_X[i], fl = FLOOR_Y - hop + (int) Math.round(Math.sin(ticks / 24.0 + i * 1.7));
            float sc = 0.5F;
            oval(g, cx, FLOOR_Y, 18, 3, 0x22000000);
            g.pose().pushPose();
            g.pose().translate(cx, fl, 0);
            g.pose().scale(sc, sc, 1F);
            g.pose().translate(-cx, -fl, 0);
            PetArt.draw(g, c, mine ? PetArt.ownVariant(c) : 0, cx, fl - 28, mood, ticks + i * 17, false, false, mine ? 2 : 1,
                    mine ? Progress.equipped() : "", mine ? Progress.equippedBody() : "");
            g.pose().popPose();
            // a classmate that has answered raises a hand
            if (mode == ASK && picked < 0 && revealed() && !mine && botAt[i] <= lim && qTime >= botAt[i]) {
                int wave = (int) Math.round(Math.sin(ticks / 3.0) * 2);
                rect(g, cx + 12, FLOOR_Y - 32 + wave, 3, 9, mix(c.bodyColor, 0x000000, 0.12F));
                rect(g, cx + 11, FLOOR_Y - 34 + wave, 5, 3, mix(c.bodyColor, 0xFFFFFF, 0.2F));
            }
            // the desk: a top with a light edge, a front, an open book and a pencil
            roundRect(g, cx - 25, FLOOR_Y - 1, 50, 5, 2, WOOD_LIGHT);
            rect(g, cx - 24, FLOOR_Y, 48, 1, 0x66FFFFFF);
            rect(g, cx - 22, FLOOR_Y + 4, 44, H - FLOOR_Y - 4, WOOD);
            rect(g, cx - 22, FLOOR_Y + 4, 44, 1, 0x22000000);
            rect(g, cx - 16, FLOOR_Y + 1, 9, 3, bookColor[i]); rect(g, cx - 15, FLOOR_Y, 7, 1, 0xFFFFFFFF);
            rect(g, cx + 6, FLOOR_Y + 1, 9, 1, 0xFFF5B84A); rect(g, cx + 15, FLOOR_Y + 1, 2, 1, 0xFFE5486F);
            if (mode == ASK || mode == RESULT) {                          // the score of every pupil on the front of the desk
                String sc2 = mode == RESULT ? scoreOf(i) + "/" + n : String.valueOf(scoreOf(i));
                fit(g, font(), sc2, cx, FLOOR_Y + 6, 40, mine ? 0xFFFFE680 : 0xFFFFF1D6, true);
            } else if (mine) {
                roundRect(g, cx - 9, FLOOR_Y + 7, 18, 6, 2, 0xFFFFD34E); rect(g, cx - 1, FLOOR_Y + 8, 2, 4, 0xFFB07A10); rect(g, cx - 4, FLOOR_Y + 9, 8, 2, 0xFFB07A10);
            }
            if (mode == RESULT && top > 0 && scoreOf(i) == top) star(g, cx + 14, fl - 30, true, 2);        // the best one gets a star
            // little feelings over the heads
            if (mode == ASK && picked >= 0 && react < 60 && ok)
                heart(g, cx - 12 + (i * 7) % 18, fl - 26 - react / 2, mine ? 0xFFFF5A86 : 0xFFFFA8C4);
            if (mode == ASK && picked >= 0 && !ok && react < 70 && (react / 12) % 2 == 0) {
                roundRect(g, cx + 8, fl - 34, 11, 11, 4, 0xFFFFFFFF);
                if (mine) CuteFont.draw(g, font(), timedOut ? "!" : "?", cx + 12, fl - 32, 0xFF8A7AA8, false);
                else { line(g, cx + 11, fl - 31, cx + 16, fl - 26, 0xFFD03A3A); line(g, cx + 16, fl - 31, cx + 11, fl - 26, 0xFFD03A3A); }
            }
        }
    }

    private void confetti(GuiGraphics g) {
        int[] col = {0xFFFF8AB4, 0xFFFFD34E, 0xFF6FB0FF, 0xFF7ACB8A, 0xFFB57BD6};
        for (int i = 0; i < 28; i++) {
            int x = 4 + (i * 53 + (int) (Math.sin((resultT + i * 9) / 17.0) * 8)) % (W - 8);
            int y = 15 + ((resultT * (1 + i % 3)) / 2 + i * 23) % 108;
            rect(g, x, y, 2, 3, col[i % col.length]);
        }
    }

    // ---------- the screens ----------
    private void menu(GuiGraphics g, Font f, int mx, int my) {
        String[] nm = new String[3], ds = new String[3], pr = new String[3];
        for (int i = 0; i < 3; i++) {
            nm[i] = t("cutemod.school.level." + LEVEL[i]);
            ds[i] = t("cutemod.school.cardinfo", LESSON_N[i], SECS[i]);
            pr[i] = t("cutemod.school.upto", MAXPAY[i]);
        }
        float s1 = groupScale(f, CARD_W - 6, nm), s2 = groupScale(f, CARD_W - 6, ds), s3 = groupScale(f, CARD_W - 20, pr);
        for (int i = 0; i < 3; i++) {
            int x = AX + i * CARD_STEP, y = CARD_Y;
            boolean hov = in(mx, my, x, y, CARD_W, CARD_H);
            if (hov) y -= 1;
            roundRect(g, x, y + 2, CARD_W, CARD_H, 6, 0x44000000);
            roundRect(g, x, y, CARD_W, CARD_H, 6, hov ? 0xFFFFFFFF : CARD[i]);
            roundRect(g, x, y, CARD_W, 14, 6, CARD_EDGE[i]);
            rect(g, x, y + 9, CARD_W, 5, CARD_EDGE[i]);
            fitS(g, f, nm[i], x + CARD_W / 2, y + 3, CARD_W - 6, s1, 0xFFFFFFFF, true);
            emblem(g, i, x + CARD_W / 2, y + 23);
            fitS(g, f, ds[i], x + CARD_W / 2, y + 33, CARD_W - 6, s2, MUTED, true);
            coin(g, x + 9, y + 47);
            fitS(g, f, pr[i], x + 16, y + 44, CARD_W - 20, s3, 0xFFB07A10, false);
            for (int s = 0; s < 5; s++) star(g, x + 11 + s * 12, y + CARD_H - 4, best[idx(i)] >= (s + 1) * 20, 2);
        }
    }

    // ---------- the pictures of the subjects (shown on the board in the menu) ----------
    private static final int[] SUBJ_FILL = {0xFFF4E8FF, 0xFFDDEBFF, 0xFFD8F3D8, 0xFFFFE3C9, 0xFFD6F1F7, 0xFFF3E3BC, 0xFFE6D8F7, 0xFFFFD9E4, 0xFFE3E8FF, 0xFFDDF4E8};
    private static final int[] SUBJ_EDGE = {0xFFB57BD6, 0xFF5B8DEF, 0xFF6FBF7A, 0xFFE08A4A, 0xFF4AB0C8, 0xFFC9A04A, 0xFF8A6AC8, 0xFFE0708F, 0xFF6F7BE0, 0xFF3FAF8F};

    /** A small picture for every subject (about 14 x 14 pixels around the centre). */
    private void subjectEmblem(GuiGraphics g, int s, int cx, int cy) {
        int w = 0xFFFFFFFF;
        switch (s) {
            case 0 -> {                                                     // mixed: four coloured squares
                rect(g, cx - 6, cy - 6, 5, 5, 0xFFF58FB8); rect(g, cx + 1, cy - 6, 5, 5, 0xFF6FB0FF);
                rect(g, cx - 6, cy + 1, 5, 5, 0xFF7ACB8A); rect(g, cx + 1, cy + 1, 5, 5, 0xFFF5B84A);
            }
            case 1 -> {                                                     // English: a speech bubble with an A
                roundRect(g, cx - 7, cy - 6, 14, 11, 3, 0xFF5B8DEF);
                rect(g, cx - 4, cy + 5, 3, 2, 0xFF5B8DEF);
                rect(g, cx - 3, cy - 4, 1, 7, w); rect(g, cx + 2, cy - 4, 1, 7, w); rect(g, cx - 2, cy - 4, 4, 1, w); rect(g, cx - 2, cy - 1, 4, 1, w);
            }
            case 2 -> {                                                     // biology: a leaf
                oval(g, cx, cy - 1, 4, 6, 0xFF4CAF50);
                rect(g, cx, cy - 6, 1, 11, 0xFF2E7D32);
                rect(g, cx - 2, cy - 2, 2, 1, 0xFF2E7D32); rect(g, cx + 1, cy, 2, 1, 0xFF2E7D32); rect(g, cx - 2, cy + 2, 2, 1, 0xFF2E7D32);
                rect(g, cx, cy + 5, 1, 3, 0xFF6E4726);
            }
            case 3 -> {                                                     // chemistry: a flask with a green liquid
                rect(g, cx - 3, cy - 8, 6, 1, 0xFF8AA8C0);
                rect(g, cx - 2, cy - 7, 4, 4, 0xFFB8D8F0);
                for (int r = 0; r < 8; r++) rect(g, cx - (4 + r) / 2, cy - 3 + r, 4 + r, 1, 0xFFB8D8F0);
                for (int r = 3; r < 8; r++) rect(g, cx - (4 + r) / 2 + 1, cy - 3 + r, 2 + r, 1, 0xFF6BCB7A);
                rect(g, cx + 3, cy - 6, 2, 2, w); sparkle(g, cx + 6, cy - 3, 1, 0xFFE08A4A);
            }
            case 4 -> {                                                     // physics: an atom
                for (int o = 0; o < 3; o++) {
                    double phi = o * Math.PI / 3;
                    for (int a = 0; a < 24; a++) {
                        double ang = a * Math.PI / 12, ex = 7 * Math.cos(ang), ey = 2.5 * Math.sin(ang);
                        rect(g, cx + (int) Math.round(ex * Math.cos(phi) - ey * Math.sin(phi)), cy + (int) Math.round(ex * Math.sin(phi) + ey * Math.cos(phi)), 1, 1, 0xFF3A86D8);
                    }
                }
                disc(g, cx, cy, 2, 0xFFE5486F);
            }
            case 5 -> {                                                     // world history: a column
                rect(g, cx - 5, cy - 7, 10, 2, 0xFFB8925A);
                rect(g, cx - 3, cy - 5, 6, 9, 0xFFFFF6DF);
                rect(g, cx - 1, cy - 5, 1, 9, 0xFFE0CBA0); rect(g, cx + 1, cy - 5, 1, 9, 0xFFE0CBA0);
                rect(g, cx - 5, cy + 4, 10, 2, 0xFFB8925A);
            }
            case 6 -> {                                                     // philosophy: a thought cloud
                disc(g, cx - 3, cy - 1, 4, w); disc(g, cx + 3, cy - 1, 4, w); disc(g, cx, cy - 4, 4, w);
                rect(g, cx - 5, cy - 1, 10, 3, w);
                disc(g, cx - 4, cy + 5, 1, w); disc(g, cx - 6, cy + 7, 1, w);
                sparkle(g, cx, cy - 2, 2, 0xFFB57BD6);
            }
            case 8 -> {                                                     // algebra: a big x on a blue square, with a plus and an equals sign
                roundRect(g, cx - 7, cy - 7, 14, 14, 3, 0xFF6F7BE0);
                line(g, cx - 4, cy - 4, cx + 3, cy + 3, w); line(g, cx - 3, cy - 4, cx + 4, cy + 3, w);
                line(g, cx + 3, cy - 4, cx - 4, cy + 3, w); line(g, cx + 4, cy - 4, cx - 3, cy + 3, w);
                rect(g, cx - 6, cy + 5, 4, 1, 0xFFE3E8FF); rect(g, cx - 6, cy + 7, 4, 1, 0xFFE3E8FF);
            }
            case 9 -> {                                                     // geometry: a set square with a right-angle mark and a circle
                for (int r = 0; r < 12; r++) rect(g, cx - 7, cy - 6 + r, 1 + r * 10 / 11, 1, 0xFF3FAF8F);
                rect(g, cx - 7, cy + 5, 11, 1, 0xFF2A8A6E);
                rect(g, cx - 6, cy + 3, 2, 2, w);
                disc(g, cx + 5, cy - 3, 3, 0xFFF5B84A); disc(g, cx + 5, cy - 3, 1, w);
            }
            default -> {                                                    // literature: an open book with a pen
                rect(g, cx - 7, cy - 4, 7, 9, w); rect(g, cx, cy - 4, 7, 9, 0xFFF4F4FF); rect(g, cx - 1, cy - 5, 2, 11, 0xFFE5486F);
                for (int k = 0; k < 3; k++) { rect(g, cx - 6, cy - 2 + k * 3, 4, 1, 0xFFB9A8C8); rect(g, cx + 2, cy - 2 + k * 3, 4, 1, 0xFFB9A8C8); }
                line(g, cx + 3, cy + 5, cx + 8, cy - 6, 0xFF8A5AB5);
            }
        }
    }

    /** A small picture for every class: an apple, an open book, a light bulb. */
    private static void emblem(GuiGraphics g, int lv, int cx, int cy) {
        switch (lv) {
            case 0 -> { disc(g, cx, cy + 1, 6, 0xFFE5484D); disc(g, cx - 2, cy - 1, 2, 0xFFFF8A8F); rect(g, cx, cy - 7, 1, 3, 0xFF6E4726); rect(g, cx + 1, cy - 7, 4, 2, 0xFF4CAF50); }
            case 1 -> { rect(g, cx - 8, cy - 4, 8, 10, 0xFFFFFFFF); rect(g, cx, cy - 4, 8, 10, 0xFFF4F4FF); rect(g, cx - 1, cy - 5, 2, 12, 0xFF5B8DEF);
                for (int k = 0; k < 3; k++) { rect(g, cx - 6, cy - 2 + k * 3, 4, 1, 0xFFB9A8C8); rect(g, cx + 2, cy - 2 + k * 3, 4, 1, 0xFFB9A8C8); } }
            default -> { disc(g, cx, cy - 1, 6, 0xFFFFE680); disc(g, cx - 2, cy - 3, 2, 0xFFFFFFFF); rect(g, cx - 3, cy + 5, 6, 3, 0xFF8A7AA8); rect(g, cx - 2, cy + 8, 4, 1, 0xFF6A5A88);
                sparkle(g, cx + 9, cy - 6, 2, 0xFFF5B84A); sparkle(g, cx - 9, cy - 5, 1, 0xFFF5B84A); }
        }
    }

    private void ask(GuiGraphics g, Font f, int mx, int my) {
        int n = OPTIONS[level];
        boolean wide = n == 4;
        int h = wide ? 15 : 18, step = wide ? 16 : 20, y0 = ANS_Y, r = wide ? 6 : 7;
        boolean ready = revealed();
        int rs = rightSlot();
        String[] an = new String[n];
        for (int s = 0; s < n; s++) an[s] = answer(s);
        float as = groupScale(f, AW - 30 - r * 2, an);
        for (int s = 0; s < n; s++) {
            int y = y0 + s * step;
            boolean hov = picked < 0 && ready && in(mx, my, AX, y, AW, h);
            int bg = ready ? 0xFFFFFFFF : 0xFFF3EEF7;
            if (picked >= 0) bg = s == rs ? 0xFFC8F2CC : s == picked ? 0xFFFAC4C4 : 0xFFEFE9F5;
            else if (hov) bg = 0xFFFFF3B0;
            roundRect(g, AX, y + 1, AW, h, 5, 0x33000000);
            roundRect(g, AX, y, AW, h, 5, bg);
            rect(g, AX + 6, y, AW - 12, 1, 0x66FFFFFF);
            if (ready || picked >= 0) {
                disc(g, AX + 4 + r, y + h / 2, r, picked >= 0 && s != rs && s != picked ? 0xFFC8BCD8 : BADGE[s]);
                String L = String.valueOf((char) ('A' + s));
                fit(g, f, L, AX + 4 + r, y + (h - 8) / 2, r * 2 - 2, 0xFFFFFFFF, true);
                fitS(g, f, an[s], AX + 12 + r * 2, y + (h - 8) / 2, AW - 30 - r * 2, as, TEXT, false);
            }
            if (picked >= 0 && s == rs) { line(g, AX + AW - 14, y + h / 2, AX + AW - 11, y + h / 2 + 3, 0xFF2E9A4A); line(g, AX + AW - 11, y + h / 2 + 3, AX + AW - 6, y + h / 2 - 3, 0xFF2E9A4A); }
            if (picked >= 0 && s == picked && s != rs) { line(g, AX + AW - 13, y + h / 2 - 3, AX + AW - 7, y + h / 2 + 3, 0xFFD03A3A); line(g, AX + AW - 13, y + h / 2 + 3, AX + AW - 7, y + h / 2 - 3, 0xFFD03A3A); }
        }
        if (picked >= 0) {
            String m = msgT > 0 ? msg : "";
            if (!m.isEmpty()) {
                int mw = fitW(f, m, AW - NEXT_W - 22);
                roundRect(g, AX, NEXT_Y, mw + 14, 15, 6, lastOk ? 0xEE2E7A4A : 0xEE7A3A4A);
                fit(g, f, m, AX + 7, NEXT_Y + 4, AW - NEXT_W - 22, 0xFFFFFFFF, false);
            }
            pill(g, f, mx, my, AX + AW - NEXT_W, NEXT_Y - 1, NEXT_W, 15, t(qi + 1 < lessonN() ? "cutemod.school.next" : "cutemod.school.finish"), 1);
        }
    }

    private void result(GuiGraphics g, Font f, int mx, int my) {
        int n = lessonN();
        roundRect(g, AX, CARD_Y + 1, AW, 40, 6, 0x33000000);
        roundRect(g, AX, CARD_Y - 1, AW, 40, 6, 0xFFFFFFFF);
        fit(g, f, t("cutemod.school.score", right, n), AX + 8, CARD_Y + 4, 104, TEXT, false);
        for (int s = 0; s < 5; s++) {
            boolean on = right * 100 / n >= (s + 1) * 20;
            int pulse = on ? (int) Math.round(Math.sin((resultT + s * 6) / 6.0)) : 0;
            star(g, AX + 14 + s * 20, CARD_Y + 24, on);
            if (on && pulse > 0) sparkle(g, AX + 14 + s * 20 + 6, CARD_Y + 17, 2, 0xFFFFE680);
        }
        String pay = capped && paid == 0 ? t("cutemod.school.cap") : t("cutemod.school.paid", paid);
        coin(g, AX + 124, CARD_Y + 9);
        fit(g, f, pay, AX + 132, CARD_Y + 5, AW - 138, 0xFFB07A10, false);
        fit(g, f, t("cutemod.school.place", place, PUPIL_X.length), AX + 124, CARD_Y + 17, AW - 130, TEXT, false);
        if (capped && paid > 0) fit(g, f, t("cutemod.school.cap"), AX + 124, CARD_Y + 28, AW - 130, MUTED, false);
        pill(g, f, mx, my, AX + 34, RES_Y + 2, 150, 16, t(lessonsDone >= DAY_LESSONS ? "cutemod.school.finishday" : "cutemod.school.tobreak"), 1);
    }

    private void dayend(GuiGraphics g, Font f, int mx, int my) {
        roundRect(g, AX, CARD_Y + 1, AW, 32, 6, 0x33000000);
        roundRect(g, AX, CARD_Y - 1, AW, 32, 6, 0xFFFFFFFF);
        fit(g, f, t("cutemod.school.dayend.lessons", lessonsDone, DAY_LESSONS), AX + 8, CARD_Y + 4, AW - 16, TEXT, false);
        coin(g, AX + 12, CARD_Y + 21);
        fit(g, f, t("cutemod.school.today", paidToday(PAID), DAILY_CAP), AX + 22, CARD_Y + 17, AW - 30, 0xFFB07A10, false);
        pill(g, f, mx, my, AX + 34, RES_Y + 2, 150, 16, t("cutemod.school.newday"), 1);
    }

    private static void star(GuiGraphics g, int cx, int cy, boolean on) { star(g, cx, cy, on, 3); }

    private static void star(GuiGraphics g, int cx, int cy, boolean on, int k) {
        int c = on ? 0xFFF0B020 : 0xFFE2D9EC, d = on ? 0xFFFFE680 : 0xFFEEE8F4;
        rect(g, cx - k, cy - k, k * 2, k * 2, c); rect(g, cx - k - 2, cy - 1, k * 2 + 4, 2, c); rect(g, cx - 1, cy - k - 2, 2, k * 2 + 4, c);
        rect(g, cx - 1, cy - 2, 2, 2, d);
    }

    // ---------- the break: the school hall and the canteen (three real minutes, no way out until the bell) ----------
    private static final int HALL_X0 = 20, HALL_X1 = 280, HALL_Y0 = 112, HALL_Y1 = 154;     // where the pets may stand
    private static final int DOOR_X = 232, DOOR_Y = 30, DOOR_W = 52, DOOR_H = 64;           // the canteen door
    private static final int CLASS_X = 140, CLASS_W = 38;                                    // the door of the class (it is shut)
    private static final int DISH_X = 24, DISH_STEP = 66, DISH_Y = 58, DISH_W = 56, DISH_H = 44;
    private static final int CB_X = 6, CB_Y = 146, CB_W = 70, CB_H = 15;                    // "back to the hall"

    private void hallInit() {
        loadLockers();
        for (int i = 0; i < PUPIL_X.length; i++) {
            hx[i] = i == OWN ? 160 : HALL_X0 + rnd.nextInt(HALL_X1 - HALL_X0);
            hy[i] = HALL_Y0 + rnd.nextInt(HALL_Y1 - HALL_Y0);
            htx[i] = hx[i];
            hty[i] = hy[i];
            hWait[i] = rnd.nextInt(120);
            hEmote[i] = 0;
        }
    }

    /** Every tick of the break: the pets walk, and when the time is over the bell calls everybody to the next lesson. */
    private void breakTick() {
        if (breakEnd - System.currentTimeMillis() <= 0) { nextLesson(); return; }
        if (lockerFxT > 0) lockerFxT--;
        for (int i = 0; i < PUPIL_X.length; i++) {
            if (hEmote[i] > 0) hEmote[i]--;
            float dx = htx[i] - hx[i], dy = hty[i] - hy[i], d = (float) Math.sqrt(dx * dx + dy * dy);
            float sp = i == OWN ? 0.9F : 0.45F;
            if (d > sp) { hx[i] += dx / d * sp; hy[i] += dy / d * sp; }
            else if (i != OWN && --hWait[i] <= 0) {
                htx[i] = HALL_X0 + rnd.nextInt(HALL_X1 - HALL_X0);
                hty[i] = HALL_Y0 + rnd.nextInt(HALL_Y1 - HALL_Y0);
                hWait[i] = 60 + rnd.nextInt(240);
            }
        }
    }

    private void hall(GuiGraphics g, Font f, int mx, int my) {
        rect(g, 0, 15, W, 80, 0xFFE9F1FF);                                // the wall with soft stripes
        for (int x = 0; x < W; x += 16) rect(g, x, 15, 8, 80, 0xFFE2ECFB);
        rect(g, 0, 70, W, 25, 0xFFBFD6F2);
        rect(g, 0, 70, W, 2, 0xFFF4F8FF);
        rect(g, 0, 95, W, 4, WOOD_LIGHT);                                 // the skirting
        for (int y = 99, r = 0; y < H; y += 17, r++)                      // the floor: big checkered tiles
            for (int x = 0, c = 0; x < W; x += 20, c++) rect(g, x, y, 20, 17, ((r + c) & 1) == 0 ? 0xFFF7E9D0 : 0xFFEBD7B4);
        int[] lc = {0xFF8FB8F0, 0xFFF4A7C3, 0xFF8FD3A0, 0xFFF5C768};      // the lockers
        for (int i = 0; i < LOCKERS; i++) {
            int x = 6 + i * 18;
            boolean open = (lockerMask >> i & 1) != 0;
            boolean lh = !open && in(mx, my, x, 40, 16, 56);
            rect(g, x, 40, 16, 56, mix(lc[i % 4], 0x000000, 0.18F));
            if (open) {                                                   // opened today: the door stands ajar, the inside is dark
                rect(g, x + 1, 41, 14, 54, mix(lc[i % 4], 0x000000, 0.55F));
                rect(g, x + 2, 62, 11, 1, 0x44FFFFFF);
                rect(g, x + 1, 41, 3, 54, lc[i % 4]);
                rect(g, x + 1, 41, 3, 1, 0x66FFFFFF);
            } else {
                rect(g, x + 1, 41, 14, 54, lh ? mix(lc[i % 4], 0xFFFFFF, 0.3F) : lc[i % 4]);
                rect(g, x + 1, 41, 14, 1, 0x66FFFFFF);
                for (int k = 0; k < 3; k++) rect(g, x + 4, 45 + k * 3, 8, 1, 0x55000000);
                rect(g, x + 11, 66, 2, 5, 0xFFFFFFFF);
                if (i == lockerOwn()) { rect(g, x + 4, 76, 8, 5, 0xFFFFD34E); rect(g, x + 5, 77, 6, 1, 0xFFB07A10); rect(g, x + 5, 79, 4, 1, 0xFFB07A10); }   // your own locker has a gold name tag
            }
        }
        if (lockerFxT > 0) {                                              // what was in the locker floats up for a moment
            int fx = 6 + lockerFx * 18 + 8, fy = 38 - (120 - lockerFxT) / 6;
            if (lockerFxKind == 0) coin(g, fx, fy);
            else if (lockerFxKind == 3) Halloween.candy(g, fx - 4, fy - 2, 0xFFFF6FA5, 0xFFFFFFFF, 2);
            else if (lockerFxKind == 1) { roundRect(g, fx - 4, fy - 4, 9, 8, 2, 0xFFFF8FB8); rect(g, fx - 1, fy - 4, 2, 8, 0xFFFFFFFF); rect(g, fx - 4, fy - 1, 9, 2, 0xFFFFFFFF); }
            else { rect(g, fx - 4, fy - 5, 8, 10, 0xFFFFFFFF); for (int k = 0; k < 3; k++) rect(g, fx - 3, fy - 3 + k * 3, 6, 1, 0xFFB0A8C0); }
        }
        boolean nhov = in(mx, my, NURSE_X, NURSE_Y, NURSE_W, NURSE_H);     // the door of the nurse's office
        rect(g, NURSE_X - 2, NURSE_Y - 2, NURSE_W + 4, NURSE_H + 4, WOOD_DARK);
        rect(g, NURSE_X, NURSE_Y, NURSE_W, NURSE_H, nhov ? 0xFFFFFFFF : 0xFFF2FBF8);
        rect(g, NURSE_X + NURSE_W / 2 - 1, NURSE_Y, 2, NURSE_H, 0xFFC8DDD6);
        rect(g, NURSE_X + 12, NURSE_Y + 14, 8, 20, 0xFFE5486F);
        rect(g, NURSE_X + 6, NURSE_Y + 20, 20, 8, 0xFFE5486F);
        rect(g, NURSE_X + NURSE_W - 7, NURSE_Y + 40, 3, 3, 0xFFFFD34E);
        roundRect(g, NURSE_X - 4, NURSE_Y - 14, NURSE_W + 8, 11, 4, 0xFF3AAFA9);
        fit(g, f, t("cutemod.school.nurse.sign"), NURSE_X + NURSE_W / 2, NURSE_Y - 12, NURSE_W + 2, 0xFFFFFFFF, true);
        rect(g, CLASS_X, 34, CLASS_W, 62, WOOD_DARK);                     // the door of the class: shut until the bell
        rect(g, CLASS_X + 2, 36, CLASS_W - 4, 60, WOOD);
        rect(g, CLASS_X + 6, 41, CLASS_W - 12, 18, 0xFFBFE6FF);
        rect(g, CLASS_X + CLASS_W / 2 - 1, 41, 2, 18, WOOD_LIGHT);
        rect(g, CLASS_X + CLASS_W - 8, 68, 3, 3, 0xFFFFD34E);
        roundRect(g, CLASS_X + 3, 24, CLASS_W - 6, 9, 3, 0xFFFFF1D6);
        fit(g, f, t("cutemod.school.break.class"), CLASS_X + CLASS_W / 2, 25, CLASS_W - 10, WOOD_DARK, true);
        boolean yhov = in(mx, my, YARD_DOOR_X, YARD_DOOR_Y, YARD_DOOR_W, YARD_DOOR_H);   // the glass door to the school yard
        rect(g, YARD_DOOR_X - 2, YARD_DOOR_Y - 2, YARD_DOOR_W + 4, YARD_DOOR_H + 4, WOOD_DARK);
        rect(g, YARD_DOOR_X, YARD_DOOR_Y, YARD_DOOR_W, YARD_DOOR_H, yhov ? 0xFFDFF4FF : 0xFFBFE6FF);
        rect(g, YARD_DOOR_X, YARD_DOOR_Y + 34, YARD_DOOR_W, YARD_DOOR_H - 34, yhov ? 0xFFC8EFC0 : 0xFFA8DDA0);        // the grass behind the glass
        disc(g, YARD_DOOR_X + 9, YARD_DOOR_Y + 12, 3, 0xFFFFE680);
        rect(g, YARD_DOOR_X + YARD_DOOR_W / 2 - 1, YARD_DOOR_Y, 2, YARD_DOOR_H, WOOD_DARK);
        rect(g, YARD_DOOR_X, YARD_DOOR_Y + 30, YARD_DOOR_W, 2, WOOD_DARK);
        rect(g, YARD_DOOR_X + YARD_DOOR_W / 2 - 5, YARD_DOOR_Y + 38, 2, 5, 0xFFFFD34E);
        rect(g, YARD_DOOR_X + YARD_DOOR_W / 2 + 3, YARD_DOOR_Y + 38, 2, 5, 0xFFFFD34E);
        roundRect(g, YARD_DOOR_X - 4, YARD_DOOR_Y - 14, YARD_DOOR_W + 8, 11, 4, 0xFF4CAF50);
        fit(g, f, t("cutemod.school.yard.sign"), YARD_DOOR_X + YARD_DOOR_W / 2, YARD_DOOR_Y - 12, YARD_DOOR_W, 0xFFFFFFFF, true);
        boolean hov = in(mx, my, DOOR_X, DOOR_Y, DOOR_W, DOOR_H);         // the door of the canteen
        rect(g, DOOR_X - 2, DOOR_Y - 2, DOOR_W + 4, DOOR_H + 4, WOOD_DARK);
        rect(g, DOOR_X, DOOR_Y, DOOR_W, DOOR_H, hov ? 0xFFFFE9A8 : 0xFFFFD99A);
        rect(g, DOOR_X + DOOR_W / 2 - 1, DOOR_Y, 2, DOOR_H, WOOD_DARK);
        for (int d = 0; d < 2; d++) {
            int wx = DOOR_X + 13 + d * 26;
            disc(g, wx, DOOR_Y + 22, 7, WOOD_DARK);
            disc(g, wx, DOOR_Y + 22, 6, 0xFFFFF8E8);
            disc(g, wx, DOOR_Y + 22, 3, d == 0 ? 0xFFE5486F : 0xFFF5B84A);
        }
        rect(g, DOOR_X + 4, DOOR_Y + DOOR_H - 3, DOOR_W - 8, 3, 0xFFE5486F);
        for (int k = 0; k < 3; k++) rect(g, DOOR_X + 10 + k * 14, DOOR_Y - 8 - (int) Math.round(Math.sin((ticks + k * 20) / 12.0) * 2), 1, 4, 0x66B0A0C0);    // steam
        roundRect(g, DOOR_X - 4, DOOR_Y - 14, DOOR_W + 8, 11, 4, 0xFFE5486F);
        fit(g, f, t("cutemod.school.canteen.sign"), DOOR_X + DOOR_W / 2, DOOR_Y - 12, DOOR_W, 0xFFFFFFFF, true);
        if (hw()) {                                                       // Halloween in the hall: cobwebs, bats, a string of lights and pumpkins
            rect(g, 0, 15, W, 80, 0x226030A0);
            web(g, 0, 15, 1);
            web(g, W - 1, 15, -1);
            for (int x = 6; x < W; x += 12) rect(g, x, 16, 3, 3, ((ticks / 20 + x / 12) & 1) == 0 ? 0xFFFFB347 : 0xFFB070E0);
            for (int i = 0; i < 3; i++) Halloween.bat(g, 24 + i * 28 + (int) Math.round(Math.sin(ticks / 25.0 + i) * 4), 22 + (int) Math.round(Math.sin(ticks / 13.0 + i * 2) * 3), (ticks / 8 + i) % 2 == 0);
            Halloween.pumpkin(g, 3, 136, 14, true);
            Halloween.pumpkin(g, 283, 138, 14, true);
        }
        // the pets, the lower ones in front
        ComputerColor[] crowd = crowd();
        Integer[] ord = {0, 1, 2, 3, 4};
        Arrays.sort(ord, (a, b) -> Float.compare(hy[a], hy[b]));
        for (int i : ord) {
            boolean mine = i == OWN;
            boolean walking = Math.abs(htx[i] - hx[i]) + Math.abs(hty[i] - hy[i]) > 1F;
            int cx = Math.round(hx[i]), gy = Math.round(hy[i]);
            int fl = gy - (walking ? (int) Math.round(Math.abs(Math.sin(ticks / 4.0 + i)) * 2) : 0);
            oval(g, cx, gy, 14, 3, 0x22000000);
            g.pose().pushPose();
            g.pose().translate(cx, fl, 0);
            g.pose().scale(0.5F, 0.5F, 1F);
            g.pose().translate(-cx, -fl, 0);
            PetArt.draw(g, crowd[i], mine ? PetArt.ownVariant(crowd[i]) : 0, cx, fl - 28, hEmote[i] > 0 ? 2 : 1, ticks + i * 17, false, false, mine ? 2 : 1,
                    mine ? Progress.equipped() : "", mine ? Progress.equippedBody() : "");
            g.pose().popPose();
            if (hEmote[i] > 0) heart(g, cx + 2, fl - 34 - (90 - Math.min(90, hEmote[i])) / 6, 0xFFFF5A86);
            if (mine) { rect(g, cx - 2, fl - 36, 5, 1, 0xFFFFD34E); rect(g, cx - 1, fl - 35, 3, 1, 0xFFFFD34E); rect(g, cx, fl - 34, 1, 1, 0xFFFFD34E); }
        }
        String hint = t("cutemod.school.break.hint");
        int hw = fitW(f, hint, W - 50);
        roundRect(g, (W - hw) / 2 - 6, H - 14, hw + 12, 11, 4, 0xBBFFFFFF);
        fit(g, f, hint, W / 2, H - 12, W - 50, TEXT, true);
    }

    private boolean hallClick(int x, int y) {
        if (in(x, y, YARD_DOOR_X - 4, YARD_DOOR_Y - 14, YARD_DOOR_W + 8, YARD_DOOR_H + 14)) { enterYard(); return true; }
        if (in(x, y, NURSE_X - 4, NURSE_Y - 14, NURSE_W + 8, NURSE_H + 14)) { enterNurse(); return true; }
        for (int i = 0; i < LOCKERS; i++) if (in(x, y, 6 + i * 18, 40, 16, 56)) { openLocker(i); return true; }
        if (in(x, y, DOOR_X - 4, DOOR_Y - 14, DOOR_W + 8, DOOR_H + 14)) {
            mode = CANTEEN;
            Sfx.ui(snd("tales.page"), 0.8F, 0.4F);
            return true;
        }
        if (in(x, y, CLASS_X, 24, CLASS_W, 72)) { say("cutemod.school.break.nodoor"); return true; }
        for (int i = 0; i < PUPIL_X.length; i++) {
            if (Math.abs(x - hx[i]) <= 12 && y >= hy[i] - 30 && y <= hy[i] + 4) { hEmote[i] = 90; pupilVoice(i, 1.1F); return true; }
        }
        if (y >= HALL_Y0 - 8) {
            htx[OWN] = Math.max(HALL_X0, Math.min(HALL_X1, x));
            hty[OWN] = Math.max(HALL_Y0, Math.min(HALL_Y1, y));
            return true;
        }
        return false;
    }

    // ---------- the school yard: through the glass door of the hall, with the residents of the Pet Park ----------
    private static final int YARD_DOOR_X = 186, YARD_DOOR_Y = 34, YARD_DOOR_W = 38, YARD_DOOR_H = 62;      // the glass door in the hall
    private static final int YARD_X0 = 14, YARD_X1 = 286, YARD_Y0 = 84, YARD_Y1 = 150;                      // where your pet may walk in the yard
    private static final float YARD_SCALE = 0.55F;                                                          // the pets are drawn a bit bigger than in the hall
    private final int[] yardEmote = new int[ParkBots.ALL.size()];                                           // a heart over a resident you have greeted
    private String yardSay = "";                                                                            // what the resident you clicked says
    private int yardSayT, yardSayBot = -1;
    private float ballX = 150, ballY = 122, ballVX, ballVY;                                                 // the ball of the yard (a ground position)
    private int ballGap;
    private final int[] botGap = new int[ParkBots.ALL.size()];                                              // a resident that has just kicked the ball waits a little
    private int yardMenuBot = -1, yardMenuX, yardMenuY, yardMenuT;                                          // the little menu of a resident you clicked
    private static final String HOOP_PAID = "school_hoop";
    private static final int HOOP_CAP = 20;                                                                 // coins a day from the hoop

    // ---------- Halloween at school (while the event of the desktop is on: Oct 24 - Nov 3, or the terminal command `halloween`) ----------
    private static final class HwGhost { float x, y; int age, type; }                                      // type 0 = a ghost (1 candy), 1 = a golden one (3 candy)
    private final List<HwGhost> hwGhosts = new ArrayList<>();
    private int hwSpawnT = 60;
    private static final String HW_PAID = "school_hw_candy";
    private static final int HW_CAP = 12;                                                                   // candy a day from the ghosts of the yard and the lockers
    private static final String[] COSTUME = {"acc_bow+acc_witch", "acc_horns", "acc_glasses+acc_ghost", null};  // what the residents wear on Halloween (null = their own look)

    private static boolean hw() { return Halloween.active(); }

    /** A cobweb in a corner: dir = 1 for the left corner, -1 for the right one. */
    private static void web(GuiGraphics g, int x, int y, int dir) {
        int c = 0x99FFFFFF;
        for (int k = 0; k < 5; k++) {
            double a = Math.toRadians(k * 22.5);
            line(g, x, y, x + (int) Math.round(dir * 24 * Math.cos(a)), y + (int) Math.round(24 * Math.sin(a)), c);
        }
        for (int r = 8; r <= 24; r += 8) {
            for (int k = 0; k < 4; k++) {
                double a0 = Math.toRadians(k * 22.5), a1 = Math.toRadians((k + 1) * 22.5);
                int rr = r - (k % 2);                                  // the threads sag a little between the spokes
                line(g, x + (int) Math.round(dir * rr * Math.cos(a0)), y + (int) Math.round(rr * Math.sin(a0)),
                        x + (int) Math.round(dir * rr * Math.cos(a1)), y + (int) Math.round(rr * Math.sin(a1)), c);
            }
        }
    }

    private static void tomb(GuiGraphics g, int x, int y) {
        oval(g, x + 5, y + 1, 8, 2, 0x44000000);
        roundRect(g, x, y - 14, 10, 14, 4, 0xFF8A8AA0);
        rect(g, x + 1, y - 13, 8, 1, 0x55FFFFFF);
        rect(g, x + 4, y - 11, 2, 7, 0xFF5A5A70);
        rect(g, x + 2, y - 9, 6, 2, 0xFF5A5A70);
    }

    /** Candy from a resident: once a day for each of them (the bubble shows its own line). */
    private void trickOrTreat(int bot) {
        String key = "school_tt_" + bot;
        if (paidToday(key) >= 1) { say("cutemod.school.hw.tt.had", ParkBots.ALL.get(bot).name()); return; }
        addPaid(key, 1);
        Halloween.addCandy(2);
        Progress.toast("cutemod.toast.hw_candy", 2);
        yardSay = t("cutemod.school.hw.tt." + bot);
        yardSayBot = bot;
        yardSayT = 180;
        yardEmote[bot] = 120;
        hEmote[OWN] = 90;
        Sfx.ui(snd("school.ding"), 1.1F, 0.6F);
    }

    private void catchGhost(int i) {
        HwGhost gh = hwGhosts.remove(i);
        int n = gh.type == 1 ? 3 : 1;
        int pay = Math.min(n, Math.max(0, HW_CAP - paidToday(HW_PAID)));
        Sfx.ui(snd("school.boop"), gh.type == 1 ? 0.7F : 0.5F, 0.5F);
        if (pay > 0) { addPaid(HW_PAID, pay); Halloween.addCandy(pay); Progress.toast("cutemod.toast.hw_candy", pay); }
        else say("cutemod.school.hw.limit");
    }

    private void enterYard() {
        mode = YARD;
        hx[OWN] = YARD_DOOR_X + YARD_DOOR_W / 2F;
        hy[OWN] = YARD_Y0 + 4;
        htx[OWN] = hx[OWN];
        hty[OWN] = YARD_Y0 + 24;                                       // a few steps out of the door
        yardSay = "";
        yardSayT = 0;
        yardSayBot = -1;
        Arrays.fill(yardEmote, 0);
        hwGhosts.clear();
        hwSpawnT = 60;
        Sfx.ui(snd("tales.page"), 0.7F, 0.45F);
    }

    private void leaveYard() {
        mode = BREAK;
        hx[OWN] = YARD_DOOR_X + YARD_DOOR_W / 2F;
        hy[OWN] = HALL_Y0 + 6;
        htx[OWN] = hx[OWN];
        hty[OWN] = hy[OWN];
        Sfx.ui(snd("tales.page"), 0.9F, 0.4F);
    }

    private void yardTick() {
        if (yardSayT > 0 && --yardSayT == 0) { yardSay = ""; yardSayBot = -1; }
        if (yardMenuT > 0 && --yardMenuT == 0) yardMenuBot = -1;
        for (int i = 0; i < yardEmote.length; i++) if (yardEmote[i] > 0) yardEmote[i]--;
        ballTick();
        if (hw()) {
            for (int i = hwGhosts.size() - 1; i >= 0; i--) if (++hwGhosts.get(i).age >= 600) hwGhosts.remove(i);
            if (--hwSpawnT <= 0) {
                hwSpawnT = 240 + rnd.nextInt(240);
                if (hwGhosts.size() < 3) {
                    HwGhost gh = new HwGhost();
                    gh.x = 20 + rnd.nextInt(250);
                    gh.y = 30 + rnd.nextInt(70);
                    gh.type = rnd.nextInt(5) == 0 ? 1 : 0;
                    hwGhosts.add(gh);
                }
            }
        } else hwGhosts.clear();
    }

    /** The ball rolls and slows down; your pet and the residents kick it when they walk into it (a resident often passes it to you). */
    private void ballTick() {
        ballGap = Math.max(0, ballGap - 1);
        float dx = ballX - hx[OWN], dy = ballY - hy[OWN], d = (float) Math.sqrt(dx * dx + dy * dy);
        if (d < 14F && ballGap == 0) {
            float nx = d < 0.5F ? 1F : dx / d, ny = d < 0.5F ? 0F : dy / d;
            ballVX = nx * 3.2F + (rnd.nextFloat() - 0.5F);
            ballVY = ny * 1.6F;
            ballGap = 20;
            Sfx.ui(snd("school.boop"), 0.7F, 0.3F);
        }
        long now = System.currentTimeMillis();
        for (int i = 0; i < botGap.length; i++) {
            if (botGap[i] > 0) { botGap[i]--; continue; }
            ParkBots.Pos p = ParkBots.at(i, now);
            float bx0 = ballX - p.x(), by0 = ballY - p.y(), bd = (float) Math.sqrt(bx0 * bx0 + by0 * by0);
            if (bd >= 13F) continue;
            float nx, ny;
            if (rnd.nextInt(2) == 0) {                                  // a pass to your pet
                float tx = hx[OWN] - ballX + (rnd.nextFloat() - 0.5F) * 30F, ty = hy[OWN] - ballY + (rnd.nextFloat() - 0.5F) * 12F;
                float td = Math.max(1F, (float) Math.sqrt(tx * tx + ty * ty));
                nx = tx / td; ny = ty / td;
            } else {
                nx = bd < 0.5F ? 1F : bx0 / bd; ny = bd < 0.5F ? 0F : by0 / bd;
            }
            ballVX = nx * 3F + (rnd.nextFloat() - 0.5F);
            ballVY = ny * 1.5F;
            botGap[i] = 40;
            yardEmote[i] = 40;
            Sfx.ui(snd("school.boop"), 0.8F + i * 0.1F, 0.25F);
        }
        ballX += ballVX; ballY += ballVY;
        ballVX *= 0.965F; ballVY *= 0.965F;
        if (ballX < 6) { ballX = 6; ballVX = -ballVX * 0.7F; } else if (ballX > W - 6) { ballX = W - 6; ballVX = -ballVX * 0.7F; }
        if (ballY < YARD_Y0 - 4) { ballY = YARD_Y0 - 4; ballVY = -ballVY * 0.7F; } else if (ballY > YARD_Y1) { ballY = YARD_Y1; ballVY = -ballVY * 0.7F; }
    }

    private void drawYardBall(GuiGraphics g) {
        int cx = Math.round(ballX), cy = Math.round(ballY);
        oval(g, cx, cy + 1, 4, 1, 0x44000000);
        disc(g, cx, cy - 3, 3, 0xFFFFFFFF);
        rect(g, cx - 1, cy - 4, 3, 2, 0xFFE5484D);
        rect(g, cx - 3, cy - 3, 1, 1, 0xFF3A2A3A);
    }

    private float yOf(int id, ParkBots.Pos[] pos) { return id == -1 ? hy[OWN] : id == -2 ? ballY : pos[id].y(); }

    private int friendLevel(int bot) { return Math.min(3, Progress.count("school_fr_" + bot) / 2); }

    /** The little menu over a resident: say hi, or give one of the treats you have (the more treats, the better friends). */
    private int[] yardMenuBox() {
        int bw = 92, bh = hw() ? 38 : 26;
        int y = yardMenuY + 22 + bh <= H - 18 ? yardMenuY + 22 : Math.max(17, yardMenuY - 84);
        return new int[]{Math.max(2, Math.min(W - 2 - bw, yardMenuX - bw / 2)), y, bw, bh};
    }

    private static int giftIndex() {
        for (int i = 0; i < ParkData.GIFTS.length; i++) if (Progress.stock(ParkData.GIFTS[i]) > 0) return i;
        return -1;
    }

    private void giveTreat(int bot) {
        int gi = giftIndex();
        if (gi < 0) { say("cutemod.school.yard.notreat"); return; }
        if (!Progress.useTreat(ParkData.GIFTS[gi])) return;
        int old = Progress.count("school_fr_" + bot);
        Progress.setCount("school_fr_" + bot, old + 1);
        yardSay = t("cutemod.park.bot." + bot + ".9");                         // "A treat?! You're the best!"
        yardSayBot = bot;
        yardSayT = 170;
        yardEmote[bot] = 120;
        hEmote[OWN] = 90;
        Sfx.ui(snd("school.ding"), 1.2F, 0.6F);
        if (Math.min(3, (old + 1) / 2) > Math.min(3, old / 2)) {
            Progress.toast("cutemod.school.yard.friend", ParkBots.ALL.get(bot).name());
            Progress.earn(5);
        }
    }

    /** 0 day, 1 evening, 2 night: the sky of the yard follows the real clock (like in the Pet Park). */
    private static int yardPart() {
        int h = java.time.LocalTime.now().getHour();
        return h >= 22 || h < 5 ? 2 : (h >= 19 || h < 7) ? 1 : 0;
    }

    private void yardScenery(GuiGraphics g, int part) {
        g.fillGradient(0, 15, W, 66, part == 2 ? 0xFF121838 : part == 1 ? 0xFFFFA76A : 0xFF8FD3FF, part == 2 ? 0xFF2C3E78 : part == 1 ? 0xFFFFD9A0 : 0xFFDDF4FF);
        if (part == 2) {
            disc(g, 262, 30, 9, 0xFFF4F1D8);
            disc(g, 266, 27, 8, 0xFF121838);
            for (int i = 0; i < 18; i++) if ((ticks / 20 + i) % 5 != 0) rect(g, (i * 67 + 11) % W, (i * 29) % 40 + 17, 1, 1, 0xFFFFFFFF);
        } else disc(g, 270, part == 1 ? 44 : 30, 9, part == 1 ? 0xFFFF8A4A : 0xFFFFE066);
        for (int i = 0; i < 2; i++) {                                  // clouds that drift
            int cx = (int) ((ticks * (0.12 + i * 0.05) + i * 150) % (W + 80)) - 40, cy = 24 + i * 13;
            disc(g, cx, cy, 5, 0xDDFFFFFF); disc(g, cx + 7, cy + 2, 6, 0xDDFFFFFF); disc(g, cx - 7, cy + 3, 4, 0xDDFFFFFF);
        }
        // the school building behind the fence
        rect(g, 36, 30, 228, 36, 0xFFF3D9B5);
        rect(g, 32, 24, 236, 7, 0xFFC8553D);
        rect(g, 32, 24, 236, 1, 0x55FFFFFF);
        for (int i = 0; i < 6; i++) {
            if (i == 2 || i == 3) continue;
            int wx = 46 + i * 36;
            rect(g, wx, 38, 20, 16, WOOD_LIGHT);
            rect(g, wx + 1, 39, 18, 14, part == 2 ? 0xFFFFE9A0 : 0xFFBFE6FF);
            rect(g, wx + 9, 39, 2, 14, WOOD_LIGHT);
            rect(g, wx + 1, 45, 18, 1, WOOD_LIGHT);
        }
        rect(g, 134, 42, 32, 24, WOOD_DARK);                           // the main door of the school
        rect(g, 136, 44, 28, 22, WOOD);
        rect(g, 149, 44, 2, 22, WOOD_DARK);
        rect(g, 138, 46, 9, 9, 0xFFBFE6FF);
        rect(g, 153, 46, 9, 9, 0xFFBFE6FF);
        disc(g, 150, 33, 6, WOOD_LIGHT);                               // the round clock over the door
        disc(g, 150, 33, 5, 0xFFFFF8E8);
        rect(g, 150, 29, 1, 5, 0xFF3A2A3A);
        rect(g, 150, 33, 3, 1, 0xFF3A2A3A);
        // the grass and the fence
        g.fillGradient(0, 66, W, H, 0xFF86D68A, 0xFF4DB35E);
        for (int i = 0; i < 8; i++) rect(g, 0, 74 + i * 10, W, 4, 0x14FFFFFF);
        rect(g, 0, 69, W, 2, 0xFFEFE6DC);
        rect(g, 0, 74, W, 2, 0xFFEFE6DC);
        for (int x = 2; x < W; x += 9) { rect(g, x, 66, 3, 12, 0xFFFFF8E8); rect(g, x, 66, 3, 1, 0xFFEFE6DC); }
        rect(g, 108, 66, 84, 12, 0xFF86D68A);                          // the gate is open
        oval(g, 150, 84, 40, 6, 0x66C9A678);                           // a path from the gate
        // the yard: hopscotch, a hoop, swings, a bench and a tree
        for (int i = 0; i < 5; i++) {
            int hx0 = 48, hy0 = 134 - i * 9;
            rect(g, hx0, hy0, 12, 8, 0x66FFFFFF);
            rect(g, hx0 + 1, hy0 + 1, 10, 6, i % 2 == 0 ? 0x55FFD34E : 0x55FF8FB8);
        }
        rect(g, 24, 96, 2, 26, 0xFF8A8AA0);                            // a basketball hoop
        rect(g, 20, 90, 12, 8, 0xFFFFFFFF);
        rect(g, 21, 91, 10, 6, 0xFFE5486F);
        rect(g, 22, 98, 8, 1, 0xFFFF8A4A);
        rect(g, 22, 99, 8, 1, 0x88FFFFFF);
        rect(g, 24, 120, 2, 5, 0x44000000);
        int bounce = (int) Math.round(Math.abs(Math.sin(ticks / 9.0)) * 9);                // a ball bounces under the hoop: click it to play
        oval(g, 38, 124, 4, 1, 0x33000000);
        disc(g, 38, 121 - bounce, 3, 0xFFE8742A);
        rect(g, 35, 121 - bounce, 7, 1, 0xFF8A3A10);
        int sway = (int) Math.round(Math.sin(ticks / 24.0) * 5);       // swings
        rect(g, 240, 92, 3, 34, 0xFFC8553D);
        rect(g, 276, 92, 3, 34, 0xFFC8553D);
        rect(g, 238, 90, 42, 3, 0xFFC8553D);
        for (int k = 0; k < 2; k++) {
            int sx = 250 + k * 18 + (k == 0 ? sway : -sway) / 2;
            rect(g, sx, 93, 1, 22, 0xFF8A8AA0);
            rect(g, sx + 6, 93, 1, 22, 0xFF8A8AA0);
            rect(g, sx - 1, 115, 9, 2, 0xFF4A9AE8);
        }
        rect(g, 96, 112, 36, 3, 0xFF9A6A44);                           // a bench
        rect(g, 96, 117, 36, 4, 0xFF8A5A3A);
        rect(g, 98, 121, 3, 6, 0xFF6A4228);
        rect(g, 127, 121, 3, 6, 0xFF6A4228);
        rect(g, 108, 92, 4, 20, 0xFF6A4228);                           // a tree
        disc(g, 110, 86, 14, 0xFF4CAF50);
        disc(g, 103, 90, 9, 0xFF5CC560);
        disc(g, 118, 91, 9, 0xFF3F9E48);
        for (int i = 0; i < 12; i++) {                                  // flowers
            int fx = (i * 83 + 17) % (W - 20) + 10, fy = 100 + (i * 47) % 50;
            rect(g, fx, fy, 2, 2, i % 3 == 0 ? 0xFFFFF3B0 : i % 3 == 1 ? 0xFFFF8FB8 : 0xFFFFFFFF);
        }
        if (part == 2) g.fill(0, 15, W, H, 0x55101840);
        else if (part == 1) g.fill(0, 15, W, H, 0x22FF6A20);
        if (hw()) {                                                    // Halloween: a purple haze, an orange moon, bats, gravestones and glowing pumpkins on the fence
            g.fill(0, 15, W, H, 0x22602080);
            disc(g, 262, 32, 11, 0xFFFFB347);
            disc(g, 258, 29, 3, 0xFFF29A30);
            for (int i = 0; i < 3; i++) {
                int bx = (int) ((ticks * (0.5 + i * 0.2) + i * 110) % (W + 40)) - 20, by = 28 + i * 14 + (int) Math.round(Math.sin(ticks / 17.0 + i) * 6);
                Halloween.bat(g, bx, by, (ticks / 8 + i) % 2 == 0);
            }
            tomb(g, 60, 94);
            tomb(g, 214, 90);
            tomb(g, 227, 97);
            for (int px : new int[]{8, 64, 208, 268}) Halloween.pumpkin(g, px, 53, 14, true);
        }
    }

    /** A speech bubble over a pet of the yard. */
    private void yardBubble(GuiGraphics g, Font f, int cx, int fl, String text) {
        int bw = Math.min(150, fitW(f, text, 150) + 8);
        int x = Math.max(bw / 2 + 2, Math.min(W - bw / 2 - 2, cx));
        int top = Math.max(17, fl - 52);
        roundRect(g, x - bw / 2, top, bw, 12, 4, 0xFFFFFFFF);
        rect(g, cx - 2, top + 12, 4, 3, 0xFFFFFFFF);
        fit(g, f, text, x, top + 2, bw - 6, 0xFF3A2A3A, true);
    }

    private void yard(GuiGraphics g, Font f, int mx, int my) {
        int part = hw() ? 2 : yardPart();
        yardScenery(g, part);
        if (hw()) {
            roundRect(g, 90, 16, 120, 11, 4, 0xDDE8742A);
            fit(g, f, t("cutemod.school.hw.banner"), 150, 18, 112, 0xFFFFFFFF, true);
        }
        long now = System.currentTimeMillis();
        int n = ParkBots.ALL.size();
        // everybody in the yard, the lower ones in front: -1 is your pet, 0.. are the residents of the park
        ParkBots.Pos[] pos = new ParkBots.Pos[n];
        Integer[] ord = new Integer[n + 2];
        for (int i = 0; i < n; i++) { pos[i] = ParkBots.at(i, now); ord[i] = i; }
        ord[n] = -1;
        ord[n + 1] = -2;
        Arrays.sort(ord, (a, b) -> Float.compare(yOf(a, pos), yOf(b, pos)));
        for (int id : ord) {
            if (id == -2) { drawYardBall(g); continue; }
            if (id < 0) {
                ComputerColor own = crowd()[OWN];
                boolean walking = Math.abs(htx[OWN] - hx[OWN]) + Math.abs(hty[OWN] - hy[OWN]) > 1F;
                int cx = Math.round(hx[OWN]), gy = Math.round(hy[OWN]);
                int fl = gy - (walking ? (int) Math.round(Math.abs(Math.sin(ticks / 4.0)) * 2) : 0);
                oval(g, cx, gy, 15, 3, 0x33000000);
                g.pose().pushPose();
                g.pose().translate(cx, fl, 0);
                g.pose().scale(YARD_SCALE, YARD_SCALE, 1F);
                g.pose().translate(-cx, -fl, 0);
                PetArt.draw(g, own, PetArt.ownVariant(own), cx, fl - 28, hEmote[OWN] > 0 ? 2 : 1, ticks, false, false, 2, Progress.equipped(), Progress.equippedBody());
                g.pose().popPose();
                if (hEmote[OWN] > 0) heart(g, cx + 2, fl - 38 - (90 - Math.min(90, hEmote[OWN])) / 6, 0xFFFF5A86);
                rect(g, cx - 2, fl - 40, 5, 1, 0xFFFFD34E); rect(g, cx - 1, fl - 39, 3, 1, 0xFFFFD34E); rect(g, cx, fl - 38, 1, 1, 0xFFFFD34E);
                continue;
            }
            ParkBots.Bot b = ParkBots.ALL.get(id);
            ParkBots.Pos p = pos[id];
            dev.cutemod.net.PetLook look = b.look();
            float sc = YARD_SCALE * PetArt.scaleOf(look.stage());
            boolean hov = in(mx, my, p.x() - 12, p.y() - 34, 24, 38);
            int hop = p.walking() ? (int) Math.round(Math.abs(Math.sin((ticks + id * 9) / 4.0)) * 2) : 0;
            int cx = p.x(), fl = p.y() - hop;
            oval(g, cx, p.y(), 15, 3, 0x33000000);
            if (hov) oval(g, cx, p.y(), 18, 4, 0x66FFFFFF);
            g.pose().pushPose();
            g.pose().translate(cx, fl, 0);
            g.pose().scale(sc, sc, 1F);
            g.pose().translate(-cx, -fl, 0);
            PetArt.draw(g, PetShow.colorOf(b.color()), look.variant(), cx, fl - 28, hov || yardEmote[id] > 0 ? 2 : 1, ticks + b.name().length() * 13, false, false,
                    look.stage(), hw() && id < COSTUME.length && COSTUME[id] != null ? COSTUME[id] : look.head(), look.body());
            g.pose().popPose();
            fit(g, f, b.name(), cx, p.y() + 3, 56, 0xFFB8F5CC, true);                // residents have a mint name, like in the park
            int fr = friendLevel(id);
            for (int k = 0; k < fr; k++) heart(g, cx - fr * 4 + 4 + k * 8, p.y() + 15, 0xFFFF5A86);
            if (yardEmote[id] > 0) heart(g, cx + 2, fl - 40 - (90 - Math.min(90, yardEmote[id])) / 6, 0xFFFF5A86);
            else if (ParkBots.emote(id, p) > 0) heart(g, cx + 2, fl - 40, 0xFFFF8FB8);
        }
        for (HwGhost gh : hwGhosts) {                                                 // ghosts float over the yard: click one for candy
            if (gh.age > 520 && (ticks / 4) % 2 == 0) continue;                       // it blinks before it goes
            int gx = Math.round(gh.x), gy = Math.round(gh.y + (float) Math.sin((ticks + gh.age) / 14.0) * 4F);
            Halloween.ghost(g, gx, gy);
            if (gh.type == 1) { sparkle(g, gx - 2, gy + 2, 2 + (ticks / 6) % 2, 0xFFFFE680); sparkle(g, gx + 20, gy + 14, 2, 0xFFFFE680); }
        }
        for (int id : ord) {                                                          // the bubbles go over everybody
            if (id < 0) continue;
            ParkBots.Pos p = pos[id];
            String text = null;
            if (yardSayBot == id && !yardSay.isEmpty()) text = yardSay;
            else {
                int il = ParkBots.idleLine(id, p);
                if (il > 0) text = t("cutemod.park.bot." + id + "." + il);
            }
            if (text != null) yardBubble(g, f, p.x(), p.y(), text);
        }
        if (yardMenuBot >= 0) {                                                       // the menu of the resident you clicked
            int[] b = yardMenuBox();
            roundRect(g, b[0], b[1] + 1, b[2], b[3], 5, 0x44000000);
            roundRect(g, b[0], b[1], b[2], b[3], 5, 0xFFFFFFFF);
            int gi = giftIndex();
            String hiRow = t("cutemod.school.yard.act.hi"), treatRow = gi < 0 ? t("cutemod.school.yard.act.notreat") : t("cutemod.school.yard.act.treat", t("cutemod.shop.item." + ParkData.GIFTS[gi]));
            String[] rows = hw() ? new String[]{hiRow, treatRow, t("cutemod.school.hw.tt.act")} : new String[]{hiRow, treatRow};
            for (int r = 0; r < rows.length; r++) {
                boolean rh = in(mx, my, b[0], b[1] + 1 + r * 12, b[2], 12);
                if (rh && (r == 0 || gi >= 0)) rect(g, b[0] + 2, b[1] + 1 + r * 12, b[2] - 4, 12, 0xFFFFEFF8);
                fit(g, f, rows[r], b[0] + b[2] / 2, b[1] + 3 + r * 12, b[2] - 8, r == 1 && gi < 0 ? MUTED : r == 2 ? 0xFFE8742A : TEXT, true);
            }
        }
        String hint = t("cutemod.school.yard.hint");
        int hw = fitW(f, hint, W - 90);
        roundRect(g, (W - hw) / 2 + 30, H - 14, hw + 12, 11, 4, 0xBBFFFFFF);
        fit(g, f, hint, W / 2 + 36, H - 12, W - 90, TEXT, true);
        pill(g, f, mx, my, CB_X, CB_Y, CB_W, CB_H, t("cutemod.school.yard.back"), 0);
    }

    private boolean yardClick(int x, int y) {
        if (in(x, y, CB_X, CB_Y, CB_W, CB_H)) { leaveYard(); return true; }
        if (yardMenuBot >= 0) {
            int[] b = yardMenuBox();
            int bot = yardMenuBot;
            if (in(x, y, b[0], b[1], b[2], b[3])) {
                int row = (y - b[1] - 1) / 12;
                yardMenuBot = -1;
                if (row <= 0) {
                    yardSay = t("cutemod.park.bot." + bot + "." + (1 + rnd.nextInt(2)));
                    yardSayBot = bot;
                    yardSayT = 150;
                    yardEmote[bot] = 90;
                    Sfx.ui(snd("school.boop"), 1.1F + bot * 0.08F, 0.5F);
                } else if (row == 1) giveTreat(bot);
                else trickOrTreat(bot);
                return true;
            }
            yardMenuBot = -1;                                          // a click elsewhere closes it and counts as a normal click
        }
        for (int i = hwGhosts.size() - 1; i >= 0; i--) {                       // a ghost first: it floats over everything
            HwGhost gh = hwGhosts.get(i);
            if (in(x, y, Math.round(gh.x) - 2, Math.round(gh.y) - 6, 22, 28)) { catchGhost(i); return true; }
        }
        if (in(x, y, 14, 86, 26, 42)) { enterHoop(); return true; }
        long now = System.currentTimeMillis();
        int hit = -1, hitY = -1;
        for (int i = 0; i < ParkBots.ALL.size(); i++) {                                // a resident: the one in front wins
            ParkBots.Pos p = ParkBots.at(i, now);
            if (Math.abs(x - p.x()) <= 12 && y >= p.y() - 34 && y <= p.y() + 4 && p.y() > hitY) { hit = i; hitY = p.y(); }
        }
        if (hit >= 0) {
            yardSay = t("cutemod.park.bot." + hit + "." + (1 + rnd.nextInt(2)));      // 1 = hello, 2 = let's play
            yardSayBot = hit;
            yardSayT = 150;
            yardEmote[hit] = 90;
            hEmote[OWN] = 90;
            Sfx.ui(snd("school.boop"), 1.1F + hit * 0.08F, 0.5F);
            ParkBots.Pos hp = ParkBots.at(hit, now);
            yardMenuBot = hit;
            yardMenuX = hp.x();
            yardMenuY = hp.y();
            yardMenuT = 300;
            return true;
        }
        if (Math.abs(x - hx[OWN]) <= 12 && y >= hy[OWN] - 34 && y <= hy[OWN] + 4) { hEmote[OWN] = 90; pupilVoice(OWN, 1.15F); return true; }
        if (y >= YARD_Y0 - 8) {
            htx[OWN] = Math.max(YARD_X0, Math.min(YARD_X1, x));
            hty[OWN] = Math.max(YARD_Y0, Math.min(YARD_Y1, y));
            return true;
        }
        return false;
    }


    // ---------- the basketball hoop of the yard: a 20-second shooting game ----------
    private int hoopT, hoopScore, hoopShots, hoopShot, hoopPay;                  // ticks left, baskets, throws, ticks since the throw (0 = none), coins paid
    private float hoopPhase;
    private boolean hoopOk, hoopDone;
    private static final int GAUGE_X = 100, GAUGE_W = 136, GAUGE_Y = 147;

    private void enterHoop() {
        mode = HOOP;
        hoopT = 1200;
        hoopScore = 0;
        hoopShots = 0;
        hoopShot = 0;
        hoopPay = 0;
        hoopPhase = 0F;
        hoopOk = false;
        hoopDone = false;
        yardMenuBot = -1;
        Sfx.ui(snd("tales.page"), 0.8F, 0.4F);
    }

    private float hoopZone() { return Math.max(0.07F, 0.17F - hoopScore * 0.009F); }

    private int hoopStars() { return hoopScore >= 10 ? 3 : hoopScore >= 7 ? 2 : hoopScore >= 4 ? 1 : 0; }

    private void hoopTick() {
        if (!hoopDone) {
            if (hoopT > 0) hoopT--;
            hoopPhase += 0.06F + Math.min(10, hoopScore) * 0.004F;
        }
        if (hoopShot > 0) {
            hoopShot++;
            if (hoopShot == 30) {
                if (hoopOk) { hoopScore++; Sfx.ui(snd("school.ding"), 1.2F, 0.6F); }
                else Sfx.ui(snd("school.boop"), 0.6F, 0.5F);
            }
            if (hoopShot >= 50) hoopShot = 0;
        }
        if (!hoopDone && hoopT <= 0 && hoopShot == 0) finishHoop();
    }

    private void finishHoop() {
        hoopDone = true;
        int st = hoopStars();
        int pay = st * 2 + (st == 3 ? 4 : 0);
        pay = Math.min(pay, Math.max(0, HOOP_CAP - paidToday(HOOP_PAID)));
        hoopPay = pay;
        if (pay > 0) { addPaid(HOOP_PAID, pay); Progress.earn(pay); }
        Sfx.ui(snd(st > 0 ? "school.fanfare" : "school.boop"), 1F, 0.6F);
    }

    private void hoop(GuiGraphics g, Font f, int mx, int my) {
        int part = hw() ? 2 : yardPart();
        g.fillGradient(0, 15, W, 100, part == 2 ? 0xFF121838 : part == 1 ? 0xFFFFA76A : 0xFF8FD3FF, part == 2 ? 0xFF2C3E78 : part == 1 ? 0xFFFFD9A0 : 0xFFDDF4FF);
        rect(g, 0, 70, W, 30, 0xFFC8553D);                                           // the brick wall of the court
        for (int r = 0; r < 4; r++) for (int x = -(r % 2) * 10; x < W; x += 20) rect(g, x, 72 + r * 7, 19, 6, r % 2 == 0 ? 0xFFD66A50 : 0xFFCF5F46);
        rect(g, 0, 100, W, H - 100, 0xFFE0B070);                                     // the court
        for (int x = 0; x < W; x += 30) rect(g, x, 100, 1, H - 100, 0x22000000);
        rect(g, 0, 100, W, 2, 0xFFFFF8E8);
        oval(g, 232, 128, 26, 8, 0x33000000);                                        // the key under the hoop
        rect(g, 262, 40, 4, 62, 0xFF8A8AA0);                                         // the pole, the backboard, the rim and the net
        rect(g, 252, 30, 22, 28, 0xFFFFFFFF);
        rect(g, 252, 30, 22, 1, 0xFFB0B0C0); rect(g, 252, 57, 22, 1, 0xFFB0B0C0); rect(g, 252, 30, 1, 28, 0xFFB0B0C0); rect(g, 273, 30, 1, 28, 0xFFB0B0C0);
        rect(g, 258, 42, 10, 8, 0xFFE5486F);
        rect(g, 259, 43, 8, 6, 0xFFFFFFFF);
        rect(g, 222, 62, 30, 2, 0xFFE8742A);
        for (int k = 0; k < 6; k++) { rect(g, 224 + k * 5, 64, 1, 12 - Math.abs(k - 3), 0xCCFFFFFF); }
        for (int k = 0; k < 3; k++) rect(g, 224, 67 + k * 3, 26, 1, 0x88FFFFFF);
        if (part == 2) g.fill(0, 15, W, H, 0x44101840);
        // your pet throws from the left
        ComputerColor own = crowd()[OWN];
        int cx = 70, fl = 138;
        oval(g, cx, fl, 18, 3, 0x33000000);
        g.pose().pushPose();
        g.pose().translate(cx, fl, 0);
        g.pose().scale(0.85F, 0.85F, 1F);
        g.pose().translate(-cx, -fl, 0);
        PetArt.draw(g, own, PetArt.ownVariant(own), cx, fl - 28, hoopShot > 0 && hoopShot < 14 || hoopDone && hoopStars() > 0 ? 2 : 1, ticks, false, false, 2, Progress.equipped(), Progress.equippedBody());
        g.pose().popPose();
        // the ball
        float bx, by;
        if (hoopShot == 0) { bx = cx + 14; by = fl - 22 + (float) Math.sin(ticks / 8.0) * 1.5F; }
        else if (hoopShot <= 30) {
            float u = hoopShot / 30F, tx = hoopOk ? 236F : 254F;
            bx = cx + 14 + (tx - cx - 14) * u;
            by = (fl - 22) + (62 - (fl - 22)) * u - 34F * 4F * u * (1F - u);
        } else {
            float v = (hoopShot - 30) / 20F;
            bx = hoopOk ? 236F : 254F + v * 14F;
            by = 62 + v * (hoopOk ? 46F : 70F);
        }
        disc(g, Math.round(bx), Math.round(by), 4, 0xFFE8742A);
        rect(g, Math.round(bx) - 4, Math.round(by), 9, 1, 0xFF8A3A10);
        rect(g, Math.round(bx), Math.round(by) - 4, 1, 9, 0xFF8A3A10);
        if (hoopShot > 30 && hoopOk) for (int k = 0; k < 6; k++) rect(g, 224 + k * 5, 64, 1, 12 - Math.abs(k - 3) + 2, 0xEEFFFFFF);     // the net swings
        // score and time
        roundRect(g, 4, 17, 96, 11, 4, 0xBBFFFFFF);
        fit(g, f, t("cutemod.school.hoop.score", hoopScore, hoopShots), 8, 19, 88, TEXT, false);
        roundRect(g, W - 44, 17, 40, 11, 4, 0xBBFFFFFF);
        fit(g, f, t("cutemod.school.hoop.time", (hoopT + 59) / 60), W - 24, 19, 34, hoopT < 300 ? 0xFFE5486F : TEXT, true);
        // the gauge: click when the marker is in the green zone
        if (!hoopDone) {
            roundRect(g, GAUGE_X - 2, GAUGE_Y - 2, GAUGE_W + 4, 11, 4, 0xFF3A2A3A);
            rect(g, GAUGE_X, GAUGE_Y, GAUGE_W, 7, 0xFFFFD0D0);
            int zw = Math.round(hoopZone() * 2 * GAUGE_W);
            rect(g, GAUGE_X + (GAUGE_W - zw) / 2, GAUGE_Y, zw, 7, 0xFF6FBF7A);
            int mxp = GAUGE_X + Math.round((float) (Math.sin(hoopPhase) + 1) / 2F * (GAUGE_W - 2));
            rect(g, mxp, GAUGE_Y - 2, 2, 11, 0xFFFFFFFF);
            rect(g, mxp - 1, GAUGE_Y - 3, 4, 2, 0xFFFFFFFF);
            String hint = t("cutemod.school.hoop.hint");
            int hw = fitW(f, hint, W - 20);
            roundRect(g, (W - hw) / 2 - 6, 31, hw + 12, 11, 4, 0xBBFFFFFF);
            fit(g, f, hint, W / 2, 33, W - 20, TEXT, true);
        } else {
            roundRect(g, 60, 36, 180, 70, 8, 0x44000000);
            roundRect(g, 60, 34, 180, 70, 8, 0xFFFFFFFF);
            fit(g, f, t("cutemod.school.hoop.done", hoopScore), 150, 40, 164, TEXT, true);
            int st = hoopStars();
            for (int k = 0; k < 3; k++) {
                int sx = 120 + k * 30;
                disc(g, sx, 64, 8, k < st ? 0xFFC98A10 : 0xFFD8D0E0);
                disc(g, sx, 64, 7, k < st ? 0xFFFFD34E : 0xFFEFEAF5);
                if (k < st) sparkle(g, sx, 64, 5, 0xFFFFF8C0);
            }
            String prize = hoopPay > 0 ? t("cutemod.school.hoop.prize", hoopPay) : st > 0 ? t("cutemod.school.hoop.limit") : "";
            if (!prize.isEmpty()) fit(g, f, prize, 150, 78, 164, 0xFFB07A10, true);
            pill(g, f, mx, my, 115, 88, 70, 14, t("cutemod.school.hoop.again"), 1);
        }
        pill(g, f, mx, my, CB_X, CB_Y, CB_W, CB_H, t("cutemod.school.yard.back"), 0);
    }

    private boolean hoopClick(int x, int y) {
        if (in(x, y, CB_X, CB_Y, CB_W, CB_H)) {                                    // back to the yard (a game that is not finished pays nothing)
            mode = YARD;
            hx[OWN] = 36;
            hy[OWN] = YARD_Y1 - 6;
            htx[OWN] = hx[OWN];
            hty[OWN] = hy[OWN];
            return true;
        }
        if (hoopDone) {
            if (in(x, y, 115, 88, 70, 14)) { enterHoop(); return true; }
            return false;
        }
        if (hoopShot == 0 && hoopT > 0) {
            float pos = ((float) Math.sin(hoopPhase) + 1F) / 2F;
            hoopOk = Math.abs(pos - 0.5F) <= hoopZone();
            hoopShot = 1;
            hoopShots++;
            Sfx.ui(snd("school.boop"), 1.3F, 0.4F);
            return true;
        }
        return false;
    }

    // ---------- the lockers of the hall: one try for each of them a day ----------
    private static final int LOCKERS = 5;
    private static final String LOCKER_PAID = "school_locker";
    private static final int LOCKER_CAP = 8;                                                                // coins a day from the lockers
    private static final String[] OWN_TREATS = {"treat_cookie", "treat_fish", "treat_honey", "treat_milk", "treat_cake"};
    private int lockerMask, lockerFx, lockerFxT, lockerFxKind;                                              // opened today (bits); the one that was opened last, how long its prize floats, and what it was

    private static int lockerHash(int day, int i) {
        long h = day * 0x9E3779B97F4A7C15L + (i + 1) * 0xC2B2AE3D27D4EB4FL;
        h ^= h >>> 29;
        h *= 0xBF58476D1CE4E5B9L;
        h ^= h >>> 32;
        return (int) (h & 0x7fffffff);
    }

    /** Which locker is yours today (it has a gold name tag and always holds a treat). */
    private static int lockerOwn() { return lockerHash(today(), 99) % LOCKERS; }

    private void loadLockers() {
        lockerMask = 0;
        String v = Store.read("school_lockers");
        try {
            String[] p = v == null ? new String[0] : v.split(",");
            if (p.length == 2 && Integer.parseInt(p[0]) == today()) lockerMask = Integer.parseInt(p[1]);
        } catch (NumberFormatException e) { lockerMask = 0; }
    }

    private void openLocker(int i) {
        if ((lockerMask >> i & 1) != 0) { say("cutemod.school.locker.shut"); return; }
        lockerMask |= 1 << i;
        Store.write("school_lockers", today() + "," + lockerMask);
        int h = lockerHash(today(), i);
        lockerFx = i;
        lockerFxT = 120;
        Sfx.ui(snd("school.boop"), 0.8F, 0.4F);
        if (i == lockerOwn()) {                                                      // your own locker: always a treat
            String id = OWN_TREATS[(h / 10) % OWN_TREATS.length];
            Progress.giveTreat(id, 1);
            lockerFxKind = 1;
            Sfx.ui(snd("school.ding"), 1.2F, 0.6F);
            say("cutemod.school.locker.own", t("cutemod.shop.item." + id));
            return;
        }
        int k = h % 10;
        if (k < 4) {                                                                 // coins
            int pay = Math.min(1 + (h / 10) % 3, Math.max(0, LOCKER_CAP - paidToday(LOCKER_PAID)));
            lockerFxKind = 0;
            if (pay > 0) { addPaid(LOCKER_PAID, pay); Progress.earn(pay); say("cutemod.school.locker.coins", pay); }
            else say("cutemod.school.locker.limit");
        } else if (k < 6) {                                                          // a small treat
            String id = (h / 10) % 2 == 0 ? "treat_berry" : "treat_lolly";
            Progress.giveTreat(id, 1);
            lockerFxKind = 1;
            Sfx.ui(snd("school.ding"), 1.1F, 0.5F);
            say("cutemod.school.locker.treat", t("cutemod.shop.item." + id));
        } else if (k == 6 && hw()) {                                                 // Halloween: candy in the locker
            int pay = Math.min(1 + (h / 10) % 3, Math.max(0, HW_CAP - paidToday(HW_PAID)));
            lockerFxKind = 3;
            if (pay > 0) { addPaid(HW_PAID, pay); Halloween.addCandy(pay); say("cutemod.school.hw.locker.candy", pay); }
            else say("cutemod.school.hw.limit");
        } else {                                                                     // junk and notes
            lockerFxKind = 2;
            say("cutemod.school.locker.note." + (h / 10) % 6);
        }
    }

    // ---------- the nurse's office: free medicine once a day, and a check-up with a lollipop ----------
    private static final int NURSE_X = 100, NURSE_Y = 34, NURSE_W = 32, NURSE_H = 62;                      // the door in the hall
    private static final String NURSE_CURE = "school_nurse_cure", NURSE_GIFT = "school_nurse_gift";
    private String nurseSay = "";
    private int nurseT;                                                                                    // ticks of the check-up (the pet hops, the nurse smiles)

    private String ownSpeciesId() {
        ComputerColor sp = PetApp.speciesOf(shell.color());
        return (sp == null ? shell.color() : sp).id;
    }

    private PetBlob.Info ownPet() { return PetBlob.parse(Store.read("pet_" + ownSpeciesId())); }

    private void enterNurse() {
        mode = NURSE;
        nurseT = 0;
        PetBlob.Info pet = ownPet();
        nurseSay = t(pet == null ? "cutemod.school.nurse.nopet" : pet.sick() ? "cutemod.school.nurse.sick" : "cutemod.school.nurse.hello");
        Sfx.ui(snd("tales.page"), 0.9F, 0.4F);
    }

    private void leaveNurse() {
        mode = BREAK;
        hx[OWN] = NURSE_X + NURSE_W / 2F;
        hy[OWN] = HALL_Y0 + 6;
        htx[OWN] = hx[OWN];
        hty[OWN] = hy[OWN];
        Sfx.ui(snd("tales.page"), 0.9F, 0.4F);
    }

    /** 0 = no button, 1 = cure the pet, 2 = check-up. */
    private int nurseAction(PetBlob.Info pet) {
        if (pet == null) return 0;
        if (pet.sick()) return paidToday(NURSE_CURE) < 1 ? 1 : 0;
        return paidToday(NURSE_GIFT) < 1 ? 2 : 0;
    }

    private void nurse(GuiGraphics g, Font f, int mx, int my) {
        rect(g, 0, 15, W, 85, 0xFFE6F6F0);                                           // the walls: mint, with a white band
        for (int x = 0; x < W; x += 20) rect(g, x, 15, 10, 85, 0xFFDDF0E8);
        rect(g, 0, 84, W, 3, 0xFFFFFFFF);
        for (int y = 100, r = 0; y < H; y += 16, r++)
            for (int x = 0, c = 0; x < W; x += 20, c++) rect(g, x, y, 20, 16, ((r + c) & 1) == 0 ? 0xFFF4FBF8 : 0xFFDDEEE8);
        rect(g, 0, 98, W, 3, 0xFFB9D8CE);
        rect(g, 232, 20, 6, 20, 0xFF3AAFA9);                                         // the green cross on the wall
        rect(g, 225, 27, 20, 6, 0xFF3AAFA9);
        rect(g, 8, 24, 36, 58, WOOD_DARK);                                           // the medicine cabinet
        rect(g, 10, 26, 32, 54, 0xFFEFF8F5);
        for (int sh = 0; sh < 3; sh++) {
            rect(g, 10, 44 + sh * 17, 32, 1, 0xFFB9D8CE);
            for (int k = 0; k < 3; k++) {
                int bx = 13 + k * 10, by = 29 + sh * 17;
                rect(g, bx, by + 4, 6, 10, k % 2 == 0 ? 0xFFE5486F : 0xFF4A9AE8);
                rect(g, bx + 1, by + 1, 4, 3, 0xFFFFFFFF);
                rect(g, bx + 2, by + 7, 2, 3, 0xFFFFFFFF);
            }
        }
        // the bed
        rect(g, 150, 92, 140, 8, 0xFFB9D8CE);
        rect(g, 154, 100, 4, 18, 0xFF8A8AA0);
        rect(g, 282, 100, 4, 18, 0xFF8A8AA0);
        roundRect(g, 150, 84, 140, 14, 5, 0xFFFFFFFF);
        roundRect(g, 150, 84, 36, 11, 5, 0xFFFFF1D6);                                // a pillow
        rect(g, 190, 88, 100, 3, 0xFF8FD3C8);
        // the nurse: a little round friend in a white cap, with a coat and a red cross
        int nx = 76, ny = 68;
        oval(g, nx, 100, 16, 3, 0x22000000);
        roundRect(g, nx - 13, ny + 10, 26, 28, 8, 0xFFFFFFFF);
        rect(g, nx - 3, ny + 18, 6, 14, 0xFFE5486F);
        rect(g, nx - 7, ny + 22, 14, 6, 0xFFE5486F);
        int wave = nurseT > 0 ? (int) Math.round(Math.sin(ticks / 3.0) * 2) : 0;
        disc(g, nx - 15, ny + 18 + wave, 4, 0xFFFFFFFF);
        disc(g, nx + 15, ny + 18 - wave, 4, 0xFFFFFFFF);
        disc(g, nx, ny, 12, 0xFFFFE0C8);
        rect(g, nx - 12, ny - 3, 4, 10, 0xFF7E5230);
        rect(g, nx + 8, ny - 3, 4, 10, 0xFF7E5230);
        if (hw()) {                                                                  // Halloween: a witch hat
            roundRect(g, nx - 15, ny - 10, 30, 4, 2, 0xFF2A1E3A);
            for (int r = 0; r < 12; r++) rect(g, nx - 8 + r / 2 + (r > 8 ? 2 : 0), ny - 11 - r, 16 - r, 1, 0xFF2A1E3A);
            rect(g, nx - 8, ny - 13, 16, 2, 0xFF8A64D8);
        } else {
            roundRect(g, nx - 11, ny - 15, 22, 8, 3, 0xFFFFFFFF);                    // the cap
            rect(g, nx - 1, ny - 14, 2, 6, 0xFFE5486F);
            rect(g, nx - 3, ny - 12, 6, 2, 0xFFE5486F);
        }
        boolean blink = (ticks / 4) % 40 == 0;
        for (int ex = -5; ex <= 5; ex += 10) {
            if (blink) rect(g, nx + ex - 2, ny + 1, 4, 1, 0xFF3A2A3A);
            else { disc(g, nx + ex, ny + 1, 2, 0xFF3A2A3A); rect(g, nx + ex - 1, ny, 1, 1, 0xFFFFFFFF); }
        }
        rect(g, nx - 7, ny + 5, 3, 2, 0xFFFFB0B0); rect(g, nx + 5, ny + 5, 3, 2, 0xFFFFB0B0);
        rect(g, nx - 2, ny + 6, 5, 1, 0xFF3A2A3A);
        if (nurseT > 0) rect(g, nx - 3, ny + 6, 7, 2, 0xFF3A2A3A);
        // her words
        roundRect(g, 104, 22, 118, 28, 6, 0xFFFFFFFF);
        rect(g, 98, 36, 8, 4, 0xFFFFFFFF);
        String[] words = nurseSay.split(" ");
        StringBuilder a = new StringBuilder(), b = new StringBuilder();
        for (String w : words) {
            if (f.width(a + (a.length() > 0 ? " " : "") + w) <= 106 && b.length() == 0) a.append(a.length() > 0 ? " " : "").append(w);
            else b.append(b.length() > 0 ? " " : "").append(w);
        }
        fit(g, f, a.toString(), 163, 27, 108, TEXT, true);
        if (b.length() > 0) fit(g, f, b.toString(), 163, 38, 108, TEXT, true);
        // your pet lies on the bed (a sick one looks it)
        PetBlob.Info pet = ownPet();
        ComputerColor own = crowd()[OWN];
        int cx = 226, fl = 92 - (nurseT > 0 ? (int) Math.round(Math.abs(Math.sin(ticks / 4.0)) * 3) : 0);
        if (pet != null) {
            g.pose().pushPose();
            g.pose().translate(cx, fl, 0);
            g.pose().scale(0.75F, 0.75F, 1F);
            g.pose().translate(-cx, -fl, 0);
            PetArt.draw(g, own, PetArt.ownVariant(own), cx, fl - 28, nurseT > 0 ? 2 : 1, ticks, false, pet.sick(), pet.stage(), Progress.equipped(), Progress.equippedBody());
            g.pose().popPose();
            if (nurseT > 0 && nurseT < 90) heart(g, cx + 16, fl - 44 - (90 - Math.min(90, nurseT)) / 6, 0xFFFF5A86);
        }
        int act = nurseAction(pet);
        if (act > 0) pill(g, f, mx, my, 104, 56, 118, 15, t(act == 1 ? "cutemod.school.nurse.cure" : "cutemod.school.nurse.checkup"), 1);
        pill(g, f, mx, my, CB_X, CB_Y, CB_W, CB_H, t("cutemod.school.yard.back"), 0);
    }

    private boolean nurseClick(int x, int y) {
        if (in(x, y, CB_X, CB_Y, CB_W, CB_H)) { leaveNurse(); return true; }
        PetBlob.Info pet = ownPet();
        int act = nurseAction(pet);
        if (act > 0 && in(x, y, 104, 56, 118, 15)) {
            if (act == 1) {
                if (PetBlob.cure(ownSpeciesId()) == 1) {
                    addPaid(NURSE_CURE, 1);
                    Progress.bump("pet_cured");
                    nurseSay = t("cutemod.school.nurse.cured");
                    nurseT = 150;
                    Sfx.ui(snd("school.fanfare"), 1.2F, 0.6F);
                    pupilVoice(OWN, 1.2F);
                }
            } else {
                addPaid(NURSE_GIFT, 1);
                Progress.giveTreat("treat_lolly", 1);
                nurseSay = t("cutemod.school.nurse.healthy");
                nurseT = 150;
                Sfx.ui(snd("school.ding"), 1.2F, 0.6F);
                pupilVoice(OWN, 1.2F);
            }
            return true;
        }
        if (act == 0 && pet != null && nurseT == 0) {                              // nothing more to do today: she says bye / explains
            nurseSay = t(pet.sick() ? "cutemod.school.nurse.cured_today" : "cutemod.school.nurse.bye");
            return true;
        }
        return false;
    }

    private void canteen(GuiGraphics g, Font f, int mx, int my) {
        rect(g, 0, 15, W, 90, 0xFFFFF3D6);
        for (int x = 0; x < W; x += 14) rect(g, x, 15, 7, 90, 0xFFFFECC2);
        for (int y = 104, r = 0; y < H; y += 16, r++)
            for (int x = 0, c = 0; x < W; x += 20, c++) rect(g, x, y, 20, 16, ((r + c) & 1) == 0 ? 0xFFF7E9D0 : 0xFFEBD7B4);
        roundRect(g, 50, 17, 200, 26, 4, WOOD_DARK);                      // the menu board
        rect(g, 53, 20, 194, 20, 0xFF2E5E4A);
        fit(g, f, t("cutemod.school.canteen.menu"), 150, 26, 186, 0xFFF4FFF4, true);
        roundRect(g, 10, 50, 280, 56, 6, WOOD_DARK);                      // the counter
        roundRect(g, 10, 50, 280, 52, 6, WOOD);
        rect(g, 10, 50, 280, 4, WOOD_LIGHT);
        String[] nm = new String[4];
        for (int i = 0; i < 4; i++) nm[i] = t("cutemod.school.dish." + i);
        float sc = groupScale(f, DISH_W - 4, nm);
        for (int i = 0; i < 4; i++) {
            int x = DISH_X + i * DISH_STEP, y = DISH_Y;
            boolean hov = !ate && in(mx, my, x, y, DISH_W, DISH_H);
            if (hov) y -= 1;
            roundRect(g, x, y + 2, DISH_W, DISH_H, 6, 0x44000000);
            roundRect(g, x, y, DISH_W, DISH_H, 6, ate ? 0xFFEFE6DC : hov ? 0xFFFFF3B0 : 0xFFFFFFFF);
            dish(g, i, x + DISH_W / 2, y + 17);
            fitS(g, f, nm[i], x + DISH_W / 2, y + DISH_H - 12, DISH_W - 4, sc, TEXT, true);
        }
        ComputerColor own = crowd()[OWN];                                 // your pet waits (and eats) in front of the counter
        int hop = eatT > 0 ? (int) Math.round(Math.abs(Math.sin(eatT / 6.0)) * 4) : 0;
        int cx = 150, fl = 154 - hop;
        oval(g, cx, 154, 18, 3, 0x22000000);
        g.pose().pushPose();
        g.pose().translate(cx, fl, 0);
        g.pose().scale(0.6F, 0.6F, 1F);
        g.pose().translate(-cx, -fl, 0);
        PetArt.draw(g, own, PetArt.ownVariant(own), cx, fl - 28, eatT > 0 || ate ? 2 : 1, ticks, false, false, 2, Progress.equipped(), Progress.equippedBody());
        g.pose().popPose();
        if (eatT > 0 && eatT < 90) heart(g, cx + 16, 126 - eatT / 5, 0xFFFF5A86);
        pill(g, f, mx, my, CB_X, CB_Y, CB_W, CB_H, t("cutemod.school.canteen.back"), 0);
    }

    private boolean canteenClick(int x, int y) {
        if (in(x, y, CB_X, CB_Y, CB_W, CB_H)) { mode = BREAK; return true; }
        for (int i = 0; i < 4; i++) {
            if (in(x, y, DISH_X + i * DISH_STEP, DISH_Y, DISH_W, DISH_H)) { eat(i); return true; }
        }
        return false;
    }

    /** One free meal in a break: the pet gets food (but is never filled past what a snack from the shop would give). */
    private void eat(int dish) {
        if (ate) { say("cutemod.school.canteen.had"); return; }
        ComputerColor sp = PetApp.speciesOf(shell.color());
        int r = PetBlob.feed((sp == null ? shell.color() : sp).id, 35, 85);
        if (r < 0) { say("cutemod.school.canteen.nopet"); return; }
        if (r == 0) { say("cutemod.school.canteen.full"); return; }
        ate = true;
        eatT = 1;
        saveDay();
        Sfx.ui(snd("school.ding"), 1.2F, 0.6F);
        pupilVoice(OWN, 1.2F);
        say("cutemod.school.canteen.yum");
    }

    /** The four dishes of the canteen, about 28 x 26 pixels around the centre. */
    private void dish(GuiGraphics g, int i, int cx, int cy) {
        switch (i) {
            case 0 -> {                                                   // noodle soup
                for (int k = 0; k < 3; k++) rect(g, cx - 6 + k * 6, cy - 15 - (int) Math.round(Math.sin((ticks + k * 12) / 10.0) * 2), 1, 5, 0x55B0A0C0);
                roundRect(g, cx - 13, cy - 4, 26, 5, 2, 0xFFFFD34E);
                for (int k = -10; k <= 8; k += 6) rect(g, cx + k, cy - 5, 4, 1, 0xFFF3E3B0);
                disc(g, cx + 6, cy - 5, 3, 0xFFFFFFFF);
                disc(g, cx + 6, cy - 5, 1, 0xFFFFB020);
                roundRect(g, cx - 14, cy, 28, 10, 4, 0xFFE5486F);
                rect(g, cx - 12, cy + 3, 24, 1, 0x55FFFFFF);
                rect(g, cx - 10, cy + 10, 20, 2, 0xFFB02A4F);
            }
            case 1 -> {                                                   // burger
                roundRect(g, cx - 12, cy - 11, 24, 8, 4, 0xFFE0A050);
                for (int k = 0; k < 3; k++) rect(g, cx - 6 + k * 5, cy - 9 + (k % 2), 2, 1, 0xFFFFF0C0);
                rect(g, cx - 13, cy - 3, 26, 3, 0xFF6BC46A);
                rect(g, cx - 12, cy, 24, 2, 0xFFFFD34E);
                roundRect(g, cx - 12, cy + 2, 24, 4, 2, 0xFF7A4A2A);
                roundRect(g, cx - 12, cy + 6, 24, 5, 3, 0xFFE0A050);
            }
            case 2 -> {                                                   // a slice of pizza
                for (int r = 0; r < 18; r++) { int w = 28 - r * 28 / 19; rect(g, cx - w / 2, cy - 11 + r, w, 1, r < 3 ? 0xFFE0A050 : 0xFFF5C04A); }
                disc(g, cx - 5, cy - 4, 2, 0xFFE5484D);
                disc(g, cx + 4, cy - 2, 2, 0xFFE5484D);
                disc(g, cx, cy + 4, 2, 0xFFE5484D);
            }
            default -> {                                                  // a cupcake
                rect(g, cx - 8, cy + 1, 16, 9, 0xFFE8A0C0);
                for (int k = 0; k < 4; k++) rect(g, cx - 6 + k * 4, cy + 2, 1, 8, 0xFFD080A0);
                disc(g, cx, cy - 2, 8, 0xFFFFE3F0);
                disc(g, cx, cy - 7, 5, 0xFFFFE3F0);
                disc(g, cx, cy - 12, 2, 0xFFE5486F);
            }
        }
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        switch (mode) {
            case MENU -> {
                if (in(x, y, BACK_X, 1, BACK_W, 12)) { dayEnd(); return true; }                         // home: the school day is over
                for (int i = 0; i < 3; i++) {
                    if (in(x, y, AX + i * CARD_STEP, CARD_Y, CARD_W, CARD_H)) {
                        start(i);
                        return true;
                    }
                }
            }
            case ASK -> {
                if (in(x, y, BACK_X, 1, BACK_W, 12)) { toMenu(); return true; }
                if (!revealed()) { reveal = revealLen() * 2; vText = ""; return true; }       // a click finishes the writing (and the owl stops talking)
                if (picked >= 0) {
                    if (in(x, y, AX + AW - NEXT_W, NEXT_Y - 1, NEXT_W, 17)) { advance(); return true; }
                    return false;
                }
                boolean wide = OPTIONS[level] == 4;
                int h = wide ? 15 : 18, step = wide ? 16 : 20;
                for (int s = 0; s < OPTIONS[level]; s++) {
                    if (in(x, y, AX, ANS_Y + s * step, AW, h)) { choose(s); return true; }
                }
            }
            case RESULT -> {
                if (in(x, y, AX + 34, RES_Y + 2, 150, 16)) { leaveResult(); return true; }
            }
            case DAYEND -> {
                if (in(x, y, AX + 34, RES_Y + 2, 150, 16)) { newDay(); return true; }
            }
            case BREAK -> { return hallClick(x, y); }
            case CANTEEN -> { return canteenClick(x, y); }
            case YARD -> { return yardClick(x, y); }
            case HOOP -> { return hoopClick(x, y); }
            case NURSE -> { return nurseClick(x, y); }
            default -> { }
        }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (mode != ASK) return false;
        if (picked >= 0 && (keyCode == 257 || keyCode == 335 || keyCode == 32)) { advance(); return true; }   // Enter, Space
        if (picked < 0 && revealed()) {
            int s = keyCode >= 49 && keyCode <= 52 ? keyCode - 49 : keyCode >= 321 && keyCode <= 324 ? keyCode - 321 : -1;
            if (s >= 0 && s < OPTIONS[level]) { choose(s); return true; }
        }
        return false;
    }
}
