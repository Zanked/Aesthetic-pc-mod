package dev.cutemod.client.player;

import dev.cutemod.client.os.Albums;
import dev.cutemod.client.os.CuteFont;
import dev.cutemod.client.os.RoundCover;
import dev.cutemod.client.os.Skin;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * The window of the portable player: albums, songs, search, a seek bar, volume, shuffle and repeat.
 * The music itself is in {@link PlayerEngine}, so closing this window does not stop it.
 */
public class PlayerScreen extends Screen {
    // ---------- colors ----------
    private static final int BG_TOP = 0xF0191330, BG_BOT = 0xF02A1B45, CARD = 0x33FFFFFF, CARD_HOVER = 0x55FFFFFF;
    private static final int TEXT = 0xFFFFFFFF, MUTED = 0xFFB8A8D8, ACCENT = 0xFFF58FB8, ACCENT2 = 0xFFB57BD6, BAR_BG = 0x44FFFFFF;

    private static final int HEADER = 28, FOOTER = 52, GRID_W = 72, GRID_H = 92;

    private int px, py, pw, ph, cx, cy, cw, ch;
    private int view;                       // 0 = all albums, 1 = one album
    private Albums.Album open;
    private String query = "";
    private boolean typing;
    private float scroll, scrollTarget;
    private int drag;                       // 1 = the seek bar, 2 = the volume
    private long dragMs;
    private int ticks;
    private final Random rnd = new Random();

    public PlayerScreen() { super(Component.translatable("cutemod.player.title")); }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void tick() { ticks++; }

    // ---------- helpers ----------
    private Font f() { return font; }

    private int w(String s) { return CuteFont.width(font, s); }

    private void str(GuiGraphics g, String s, int x, int y, int color) { Skin.str(g, font, s, x, y, color, false); }

    private String fit(String s, int maxW) {
        if (maxW <= 4) return "";
        if (w(s) <= maxW) return s;
        while (s.length() > 1 && w(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private static String time(long ms) {
        long s = Math.max(0, ms / 1000);
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    private void round(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        g.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int d = r - i;
            int inset = (int) Math.ceil(r - Math.sqrt((double) r * r - (double) d * d));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    private void disc(GuiGraphics g, int cxx, int cyy, int r, int color) { round(g, cxx - r, cyy - r, r * 2, r * 2, r, color); }

    /** A triangle pointing right (dir 1) or left (dir -1), size = its height. */
    private void tri(GuiGraphics g, int x, int y, int size, int dir, int color) {
        int cols = size / 2 + 1;
        for (int c = 0; c < cols; c++) {
            int xx = dir > 0 ? x + c : x + cols - 1 - c;
            g.fill(xx, y + c, xx + 1, y + size - c, color);
        }
    }

    private void cover(GuiGraphics g, Albums.Album a, int x, int y, int size) {
        RoundCover.draw(g, a, x, y, size);
        if (!RoundCover.hasPicture(a) && size >= 20) {
            String l = RoundCover.letter(a);
            str(g, l, x + (size - w(l)) / 2, y + size / 2 - 4, 0xFFFFFFFF);
        }
    }

    // ---------- data ----------
    private List<Albums.Album> lib() {
        List<Albums.Album> out = new ArrayList<>();
        for (Albums.Album a : Albums.all()) if (a.onPlayer()) out.add(a);
        return out;
    }

    private static List<PlayerEngine.Entry> entries(Albums.Album a) {
        List<PlayerEngine.Entry> l = new ArrayList<>();
        for (Albums.Track t : a.tracks()) l.add(new PlayerEngine.Entry(a, t));
        return l;
    }

    /** kind 0 = a heading, 1 = an album, 2 = a song. */
    private record Row(int kind, Albums.Album album, Albums.Track track, String text) {
        int h() { return kind == 0 ? 14 : kind == 1 ? 22 : 17; }
    }

    private List<Row> rows() {
        List<Row> r = new ArrayList<>();
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (!q.isEmpty()) {
            List<Row> al = new ArrayList<>(), so = new ArrayList<>();
            for (Albums.Album a : lib()) {
                if (a.title().toLowerCase(Locale.ROOT).contains(q) || a.artist().toLowerCase(Locale.ROOT).contains(q)) al.add(new Row(1, a, null, a.title()));
                for (Albums.Track t : a.tracks()) if (t.title().toLowerCase(Locale.ROOT).contains(q)) so.add(new Row(2, a, t, t.title()));
            }
            if (!al.isEmpty()) { r.add(new Row(0, null, null, Component.translatable("cutemod.player.albums").getString())); r.addAll(al); }
            if (!so.isEmpty()) { r.add(new Row(0, null, null, Component.translatable("cutemod.player.songs").getString())); r.addAll(so); }
        } else if (open != null) {
            for (Albums.Track t : open.tracks()) r.add(new Row(2, open, t, t.title()));
        }
        return r;
    }

    private boolean searching() { return !query.trim().isEmpty(); }

    private int albumHeadH() { return searching() || view != 1 ? 0 : 72; }

    private int contentH() {
        if (!searching() && view == 0) {
            int cols = Math.max(1, cw / (GRID_W + 4));
            int rowsN = (lib().size() + cols - 1) / cols;
            return 18 + rowsN * GRID_H;
        }
        int h = albumHeadH();
        for (Row r : rows()) h += r.h();
        return h;
    }

    // ---------- layout ----------
    private void layout() {
        pw = Math.min(width - 12, 420);
        ph = Math.min(height - 12, 250);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cx = px + 8;
        cy = py + HEADER;
        cw = pw - 16;
        ch = ph - HEADER - FOOTER;
    }

    private int searchX() { return px + pw - 8 - 130; }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        layout();
        g.fill(0, 0, width, height, 0x88000000);
        round(g, px - 1, py - 1, pw + 2, ph + 2, 8, 0x33FFFFFF);
        g.enableScissor(px, py, px + pw, py + ph);
        g.fillGradient(px, py, px + pw, py + ph, BG_TOP, BG_BOT);
        g.disableScissor();

        // scroll
        scrollTarget = Math.max(0, Math.min(Math.max(0, contentH() - ch), scrollTarget));
        scroll += (scrollTarget - scroll) * 0.3F;
        if (Math.abs(scrollTarget - scroll) < 0.3F) scroll = scrollTarget;

        renderHeader(g, mx, my);
        g.enableScissor(cx, cy, cx + cw, cy + ch);
        if (lib().isEmpty()) renderEmpty(g);
        else if (!searching() && view == 0) renderGrid(g, mx, my);
        else renderList(g, mx, my);
        g.disableScissor();
        renderScrollBar(g);
        renderFooter(g, mx, my);
    }

    private void renderHeader(GuiGraphics g, int mx, int my) {
        // title / back
        if (open != null && view == 1 && !searching()) {
            boolean hov = in(mx, my, px + 8, py + 6, 60, 16);
            round(g, px + 8, py + 6, 60, 16, 5, hov ? CARD_HOVER : CARD);
            tri(g, px + 13, py + 10, 8, -1, TEXT);
            str(g, fit(Component.translatable("cutemod.player.albums").getString(), 40), px + 23, py + 10, TEXT);
        } else {
            str(g, Component.translatable("cutemod.player.title").getString(), px + 12, py + 10, TEXT);
            g.fill(px + 12, py + 21, px + 12 + w(Component.translatable("cutemod.player.title").getString()), py + 22, ACCENT);
        }
        // search box
        int sx = searchX(), sy = py + 6, sw = 130, sh = 16;
        round(g, sx, sy, sw, sh, 6, typing ? 0x66FFFFFF : CARD);
        if (typing) { g.fill(sx + 1, sy + sh - 1, sx + sw - 1, sy + sh, ACCENT); }
        String shown = query.isEmpty() && !typing ? Component.translatable("cutemod.player.search").getString() : query;
        int tc = query.isEmpty() ? MUTED : TEXT;
        String cut = shown;
        while (cut.length() > 1 && w(cut) > sw - 22) cut = cut.substring(1);   // the end of the text stays visible
        str(g, cut, sx + 18, sy + 4, tc);
        if (typing && (ticks / 10) % 2 == 0) g.fill(sx + 18 + w(cut), sy + 3, sx + 19 + w(cut), sy + sh - 3, TEXT);
        // a small magnifier
        g.fill(sx + 6, sy + 4, sx + 11, sy + 5, MUTED); g.fill(sx + 6, sy + 9, sx + 11, sy + 10, MUTED);
        g.fill(sx + 5, sy + 5, sx + 6, sy + 9, MUTED); g.fill(sx + 11, sy + 5, sx + 12, sy + 9, MUTED);
        g.fill(sx + 11, sy + 10, sx + 13, sy + 12, MUTED);
        if (!query.isEmpty()) {                                              // clear
            boolean hov = in(mx, my, sx + sw - 14, sy + 2, 12, 12);
            str(g, "x", sx + sw - 11, sy + 4, hov ? TEXT : MUTED);
        }
    }

    private void renderEmpty(GuiGraphics g) {
        int y = cy + ch / 2 - 22;
        String a = Component.translatable("cutemod.player.empty").getString();
        String b = Component.translatable("cutemod.player.empty2").getString();
        disc(g, px + pw / 2, y - 6, 12, CARD);
        tri(g, px + pw / 2 - 3, y - 12, 12, 1, MUTED);
        str(g, a, px + (pw - w(a)) / 2, y + 12, TEXT);
        // the second line may be long: split in two at a space
        int max = cw - 20;
        List<String> lines = wrap(b, max);
        for (int i = 0; i < lines.size(); i++) str(g, lines.get(i), px + (pw - w(lines.get(i))) / 2, y + 26 + i * 11, MUTED);
    }

    private List<String> wrap(String s, int max) {
        List<String> out = new ArrayList<>();
        String line = "";
        for (String word : s.split(" ")) {
            String t = line.isEmpty() ? word : line + " " + word;
            if (w(t) > max && !line.isEmpty()) { out.add(line); line = word; } else line = t;
        }
        if (!line.isEmpty()) out.add(line);
        return out;
    }

    private void renderGrid(GuiGraphics g, int mx, int my) {
        List<Albums.Album> l = lib();
        int cols = Math.max(1, cw / (GRID_W + 4));
        int gap = cols > 1 ? (cw - cols * GRID_W) / (cols - 1) : 0;
        int y0 = cy - (int) scroll;
        str(g, Component.translatable("cutemod.player.albums").getString() + "  " + l.size(), cx + 2, y0 + 3, MUTED);
        for (int i = 0; i < l.size(); i++) {
            int x = cx + (i % cols) * (GRID_W + gap), y = y0 + 18 + (i / cols) * GRID_H;
            if (y + GRID_H < cy || y > cy + ch) continue;
            Albums.Album a = l.get(i);
            boolean hov = in(mx, my, x, y, GRID_W, GRID_H - 4) && in(mx, my, cx, cy, cw, ch);
            round(g, x, y, GRID_W, GRID_H - 4, 6, hov ? CARD_HOVER : CARD);
            cover(g, a, x + 4, y + 4, GRID_W - 8);
            boolean cur = PlayerEngine.current() != null && PlayerEngine.current().album().id().equals(a.id());
            if (hov || cur) {                                                  // the play button on the cover
                int bx = x + GRID_W - 16, by = y + GRID_W - 20;
                boolean hb = in(mx, my, bx - 8, by - 8, 16, 16);
                disc(g, bx, by, 8, hb ? ACCENT : ACCENT2);
                if (cur && PlayerEngine.isPlaying()) { g.fill(bx - 3, by - 3, bx - 1, by + 3, TEXT); g.fill(bx + 1, by - 3, bx + 3, by + 3, TEXT); }
                else tri(g, bx - 2, by - 4, 8, 1, TEXT);
            }
            str(g, fit(a.title(), GRID_W - 10), x + 5, y + GRID_W - 1, cur ? ACCENT : TEXT);
            str(g, fit(a.artist().isEmpty() ? Component.translatable("cutemod.player.count", a.tracks().size()).getString() : a.artist(), GRID_W - 10), x + 5, y + GRID_W + 9, MUTED);
        }
    }

    private void renderList(GuiGraphics g, int mx, int my) {
        int y = cy - (int) scroll;
        if (!searching() && view == 1 && open != null) {
            renderAlbumHead(g, mx, my, y);
            y += albumHeadH();
        }
        List<Row> rows = rows();
        if (searching() && rows.isEmpty()) {
            String s = Component.translatable("cutemod.player.none").getString();
            str(g, s, px + (pw - w(s)) / 2, cy + 30, MUTED);
        }
        int n = 0;
        for (Row r : rows) {
            int h = r.h();
            if (y + h >= cy && y <= cy + ch) {
                boolean hov = in(mx, my, cx, y, cw, h) && in(mx, my, cx, cy, cw, ch);
                if (r.kind() == 0) {
                    str(g, r.text().toUpperCase(Locale.ROOT), cx + 4, y + 4, ACCENT2);
                } else if (r.kind() == 1) {
                    round(g, cx, y, cw, h - 2, 5, hov ? CARD_HOVER : 0x18FFFFFF);
                    cover(g, r.album(), cx + 3, y + 2, h - 6);
                    str(g, fit(r.album().title(), cw / 2), cx + h + 4, y + 4, TEXT);
                    String c = Component.translatable("cutemod.player.count", r.album().tracks().size()).getString();
                    str(g, c, cx + cw - 6 - w(c), y + 4, MUTED);
                } else {
                    PlayerEngine.Entry cur = PlayerEngine.current();
                    boolean now = cur != null && cur.album().id().equals(r.album().id()) && cur.track().id().equals(r.track().id());
                    round(g, cx, y, cw, h - 1, 4, now ? 0x55F58FB8 : (hov ? CARD_HOVER : (n % 2 == 0 ? 0x14FFFFFF : 0x00000000)));
                    if (now) {
                        g.fill(cx, y + 3, cx + 2, y + h - 4, ACCENT);
                        if (PlayerEngine.isPlaying()) {                         // a tiny equalizer
                            for (int b = 0; b < 3; b++) {
                                int bh = 2 + (int) (Math.abs(Math.sin((ticks + b * 5) * 0.35)) * 6);
                                g.fill(cx + 7 + b * 3, y + 12 - bh, cx + 9 + b * 3, y + 12, ACCENT);
                            }
                        } else tri(g, cx + 8, y + 4, 8, 1, ACCENT);
                    } else if (searching()) {
                        // no number in the search results
                    } else {
                        str(g, String.valueOf(n + 1), cx + 8, y + 4, MUTED);
                    }
                    int tx = cx + 22;
                    String right = time(r.track().seconds() * 1000L);
                    int rw = w(right);
                    str(g, fit(r.track().title(), cw - 22 - rw - (searching() ? 90 : 12)), tx, y + 4, now ? ACCENT : TEXT);
                    if (searching()) str(g, fit(r.album().title(), 80), cx + cw - 12 - rw - 84, y + 4, MUTED);
                    str(g, right, cx + cw - 6 - rw, y + 4, MUTED);
                }
            }
            if (r.kind() == 2) n++;
            y += h;
        }
    }

    private void renderAlbumHead(GuiGraphics g, int mx, int my, int y) {
        Albums.Album a = open;
        cover(g, a, cx + 2, y + 4, 60);
        int tx = cx + 70, tw = cw - 76;
        str(g, fit(a.title(), tw), tx, y + 6, TEXT);
        if (!a.artist().isEmpty()) str(g, fit(a.artist(), tw), tx, y + 18, MUTED);
        int total = 0;
        for (Albums.Track t : a.tracks()) total += t.seconds();
        str(g, Component.translatable("cutemod.player.count", a.tracks().size()).getString() + "  -  "
                + Component.translatable("cutemod.player.min", Math.max(1, total / 60)).getString(), tx, y + 30, MUTED);
        // buttons
        String play = Component.translatable("cutemod.player.play").getString();
        String mix = Component.translatable("cutemod.player.shuffle").getString();
        int bw = w(play) + 26, mw = w(mix) + 14, by = y + 44;
        boolean h1 = in(mx, my, tx, by, bw, 16), h2 = in(mx, my, tx + bw + 6, by, mw, 16);
        round(g, tx, by, bw, 16, 8, h1 ? ACCENT : 0xFFD0709A);
        tri(g, tx + 8, by + 4, 8, 1, TEXT);
        str(g, play, tx + 20, by + 4, TEXT);
        round(g, tx + bw + 6, by, mw, 16, 8, h2 ? CARD_HOVER : CARD);
        str(g, mix, tx + bw + 13, by + 4, TEXT);
    }

    private void renderScrollBar(GuiGraphics g) {
        int total = contentH();
        if (total <= ch) return;
        int bh = Math.max(12, ch * ch / total);
        int by = cy + (int) ((ch - bh) * (scroll / (float) (total - ch)));
        g.fill(px + pw - 5, cy, px + pw - 3, cy + ch, 0x22FFFFFF);
        round(g, px + pw - 5, by, 2, bh, 1, ACCENT2 | 0xFF000000);
    }

    // ---------- footer: now playing, controls, seek, volume ----------
    private int fy() { return py + ph - FOOTER; }

    private int seekX0() { return px + 130 + 30; }

    private int seekX1() { return px + pw - 100 - 30; }

    private void renderFooter(GuiGraphics g, int mx, int my) {
        int y0 = fy();
        g.fill(px + 8, y0, px + pw - 8, y0 + 1, 0x22FFFFFF);
        PlayerEngine.Entry cur = PlayerEngine.current();

        // the song
        if (cur != null) {
            cover(g, cur.album(), px + 10, y0 + 8, 36);
            str(g, fit(cur.track().title(), 80), px + 52, y0 + 13, TEXT);
            str(g, fit(cur.album().artist().isEmpty() ? cur.album().title() : cur.album().artist(), 80), px + 52, y0 + 25, MUTED);
        } else {
            round(g, px + 10, y0 + 8, 36, 36, 5, CARD);
            str(g, fit(Component.translatable("cutemod.player.nothing").getString(), 80), px + 52, y0 + 19, MUTED);
        }

        // controls (the middle)
        int mid = (seekX0() + seekX1()) / 2, cy2 = y0 + 14;
        boolean playing = PlayerEngine.isPlaying();
        // shuffle / repeat chips
        String sh = Component.translatable("cutemod.player.shuffle.short").getString();
        String rp = Component.translatable("cutemod.player.repeat." + PlayerEngine.repeat().ordinal()).getString();
        int shw = w(sh) + 10, rpw = w(rp) + 10;
        chip(g, mx, my, mid - 70 - shw / 2 + 12, cy2 - 7, shw, sh, PlayerEngine.shuffle());
        chip(g, mx, my, mid + 70 - rpw / 2 - 12, cy2 - 7, rpw, rp, PlayerEngine.repeat() != PlayerEngine.Repeat.OFF);
        // prev, play, next
        boolean hp = in(mx, my, mid - 38, cy2 - 8, 16, 16), hn = in(mx, my, mid + 22, cy2 - 8, 16, 16), hm = in(mx, my, mid - 10, cy2 - 10, 20, 20);
        g.fill(mid - 34, cy2 - 4, mid - 33, cy2 + 4, hp ? ACCENT : TEXT); tri(g, mid - 32, cy2 - 4, 8, -1, hp ? ACCENT : TEXT);
        g.fill(mid + 33, cy2 - 4, mid + 34, cy2 + 4, hn ? ACCENT : TEXT); tri(g, mid + 25, cy2 - 4, 8, 1, hn ? ACCENT : TEXT);
        disc(g, mid, cy2, 10, hm ? ACCENT : 0xFFD0709A);
        if (playing) { g.fill(mid - 4, cy2 - 4, mid - 1, cy2 + 4, TEXT); g.fill(mid + 1, cy2 - 4, mid + 4, cy2 + 4, TEXT); }
        else tri(g, mid - 2, cy2 - 5, 10, 1, TEXT);

        // seek bar
        int sx0 = seekX0(), sx1 = seekX1(), sy = y0 + 33;
        long len = PlayerEngine.length();
        long pos = drag == 1 ? dragMs : PlayerEngine.position();
        float frac = len > 0 ? Math.max(0F, Math.min(1F, pos / (float) len)) : 0F;
        str(g, time(pos), sx0 - 4 - w(time(pos)), sy - 3, MUTED);
        str(g, len > 0 ? time(len) : "-:--", sx1 + 4, sy - 3, MUTED);
        round(g, sx0, sy, sx1 - sx0, 4, 2, BAR_BG);
        int fill = (int) ((sx1 - sx0) * frac);
        if (fill > 0) round(g, sx0, sy, fill, 4, 2, ACCENT);
        boolean hs = drag == 1 || in(mx, my, sx0 - 3, sy - 5, sx1 - sx0 + 6, 14);
        if (hs && cur != null) disc(g, sx0 + fill, sy + 2, 4, TEXT);

        // volume
        int vx = px + pw - 8 - 70, vy = y0 + 17;
        g.fill(vx - 12, vy + 1, vx - 9, vy + 5, MUTED); tri(g, vx - 9, vy - 1, 8, -1, MUTED);
        round(g, vx, vy + 1, 70, 4, 2, BAR_BG);
        int vf = (int) (70 * PlayerEngine.volume());
        if (vf > 0) round(g, vx, vy + 1, vf, 4, 2, ACCENT2 | 0xFF000000);
        if (drag == 2 || in(mx, my, vx - 3, vy - 4, 76, 14)) disc(g, vx + vf, vy + 3, 4, TEXT);
    }

    private void chip(GuiGraphics g, int mx, int my, int x, int y, int w, String s, boolean on) {
        boolean hov = in(mx, my, x, y, w, 14);
        round(g, x, y, w, 14, 6, on ? 0x88B57BD6 : (hov ? CARD_HOVER : CARD));
        str(g, s, x + 5, y + 3, on ? TEXT : MUTED);
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        layout();
        if (button != 0) return super.mouseClicked(mx, my, button);

        // search box
        int sx = searchX(), sy = py + 6;
        if (in(mx, my, sx, sy, 130, 16)) {
            if (!query.isEmpty() && in(mx, my, sx + 116, sy + 2, 12, 12)) { query = ""; scrollTarget = 0; }
            typing = true;
            return true;
        }
        typing = false;
        // back
        if (open != null && view == 1 && !searching() && in(mx, my, px + 8, py + 6, 60, 16)) { view = 0; open = null; scrollTarget = 0; return true; }
        if (clickFooter(mx, my)) return true;
        if (in(mx, my, cx, cy, cw, ch)) return clickContent(mx, my);
        return false;
    }

    private boolean clickFooter(double mx, double my) {
        int y0 = fy(), mid = (seekX0() + seekX1()) / 2, cy2 = y0 + 14;
        if (in(mx, my, mid - 10, cy2 - 10, 20, 20)) { PlayerEngine.toggle(); return true; }
        if (in(mx, my, mid - 38, cy2 - 8, 16, 16)) { PlayerEngine.prev(); return true; }
        if (in(mx, my, mid + 22, cy2 - 8, 16, 16)) { PlayerEngine.next(); return true; }
        String sh = Component.translatable("cutemod.player.shuffle.short").getString();
        String rp = Component.translatable("cutemod.player.repeat." + PlayerEngine.repeat().ordinal()).getString();
        int shw = w(sh) + 10, rpw = w(rp) + 10;
        if (in(mx, my, mid - 70 - shw / 2 + 12, cy2 - 7, shw, 14)) { PlayerEngine.toggleShuffle(); return true; }
        if (in(mx, my, mid + 70 - rpw / 2 - 12, cy2 - 7, rpw, 14)) { PlayerEngine.cycleRepeat(); return true; }
        int sx0 = seekX0(), sx1 = seekX1(), sy = y0 + 33;
        if (PlayerEngine.current() != null && in(mx, my, sx0 - 3, sy - 5, sx1 - sx0 + 6, 14)) { drag = 1; dragTo(mx); return true; }
        int vx = px + pw - 8 - 70, vy = y0 + 17;
        if (in(mx, my, vx - 3, vy - 4, 76, 14)) { drag = 2; dragTo(mx); return true; }
        return false;
    }

    private void dragTo(double mx) {
        if (drag == 1) {
            float fr = (float) ((mx - seekX0()) / (seekX1() - seekX0()));
            dragMs = (long) (Math.max(0F, Math.min(1F, fr)) * PlayerEngine.length());
        } else if (drag == 2) {
            PlayerEngine.setVolume((float) ((mx - (px + pw - 8 - 70)) / 70.0));
        }
    }

    private boolean clickContent(double mx, double my) {
        if (lib().isEmpty()) return false;
        if (!searching() && view == 0) {
            List<Albums.Album> l = lib();
            int cols = Math.max(1, cw / (GRID_W + 4));
            int gap = cols > 1 ? (cw - cols * GRID_W) / (cols - 1) : 0;
            int y0 = cy - (int) scroll;
            for (int i = 0; i < l.size(); i++) {
                int x = cx + (i % cols) * (GRID_W + gap), y = y0 + 18 + (i / cols) * GRID_H;
                if (!in(mx, my, x, y, GRID_W, GRID_H - 4)) continue;
                Albums.Album a = l.get(i);
                int bx = x + GRID_W - 16, by = y + GRID_W - 20;
                if (in(mx, my, bx - 8, by - 8, 16, 16)) {                         // the play button: play it (or pause if it plays)
                    PlayerEngine.Entry cur = PlayerEngine.current();
                    if (cur != null && cur.album().id().equals(a.id())) PlayerEngine.toggle();
                    else PlayerEngine.play(entries(a), 0);
                } else { open = a; view = 1; scrollTarget = 0; scroll = 0; }
                return true;
            }
            return false;
        }
        int y = cy - (int) scroll;
        if (!searching() && view == 1 && open != null) {
            String play = Component.translatable("cutemod.player.play").getString();
            String mix = Component.translatable("cutemod.player.shuffle").getString();
            int tx = cx + 70, bw = w(play) + 26, mw = w(mix) + 14, by = y + 44;
            if (in(mx, my, tx, by, bw, 16)) { PlayerEngine.setShuffle(false); PlayerEngine.play(entries(open), 0); return true; }
            if (in(mx, my, tx + bw + 6, by, mw, 16)) { PlayerEngine.setShuffle(true); PlayerEngine.play(entries(open), rnd.nextInt(open.tracks().size())); return true; }
            y += albumHeadH();
        }
        List<Row> rows = rows();
        // for the search: the queue is all the songs that were found
        List<PlayerEngine.Entry> found = new ArrayList<>();
        for (Row r : rows) if (r.kind() == 2) found.add(new PlayerEngine.Entry(r.album(), r.track()));
        int songNo = 0;
        for (Row r : rows) {
            int h = r.h();
            if (in(mx, my, cx, y, cw, h)) {
                if (r.kind() == 1) { open = r.album(); view = 1; query = ""; typing = false; scrollTarget = 0; scroll = 0; return true; }
                if (r.kind() == 2) {
                    if (searching()) PlayerEngine.play(found, songNo);
                    else PlayerEngine.play(entries(open), songNo);
                    return true;
                }
            }
            if (r.kind() == 2) songNo++;
            y += h;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (drag != 0) { dragTo(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (drag == 1) PlayerEngine.seek(dragMs);
        boolean was = drag != 0;
        drag = 0;
        return was || super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scrollTarget -= (float) (sy * 24);
        return true;
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (!typing) return super.charTyped(c, mods);
        if (c >= 32 && c != 127 && query.length() < 40) { query += c; scrollTarget = 0; scroll = 0; }
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (typing) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); scrollTarget = 0; return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { typing = false; return true; }
            if (key == GLFW.GLFW_KEY_ESCAPE) { if (!query.isEmpty()) query = ""; else typing = false; return true; }
            if (key == GLFW.GLFW_KEY_V && (mods & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = net.minecraft.client.Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) { String all = query + clip.replaceAll("[\\r\\n]", " "); query = all.substring(0, Math.min(40, all.length())); }
                return true;
            }
            return true;   // while typing, no other key does anything
        }
        switch (key) {
            case GLFW.GLFW_KEY_SPACE -> { PlayerEngine.toggle(); return true; }
            case GLFW.GLFW_KEY_RIGHT -> { PlayerEngine.seek(PlayerEngine.position() + 5000); return true; }
            case GLFW.GLFW_KEY_LEFT -> { PlayerEngine.seek(PlayerEngine.position() - 5000); return true; }
            case GLFW.GLFW_KEY_N -> { PlayerEngine.next(); return true; }
            case GLFW.GLFW_KEY_P -> { PlayerEngine.prev(); return true; }
            case GLFW.GLFW_KEY_SLASH -> { typing = true; return true; }
            case GLFW.GLFW_KEY_F -> { if ((mods & GLFW.GLFW_MOD_CONTROL) != 0) { typing = true; return true; } }
            default -> { }
        }
        return super.keyPressed(key, scan, mods);
    }
}
