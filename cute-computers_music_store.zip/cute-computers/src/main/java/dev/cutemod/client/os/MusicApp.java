package dev.cutemod.client.os;

import dev.cutemod.client.player.PlayerEngine;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The music player of the computer. Real songs from the albums (the folder music/ inside the mod and the folder
 * cutemod_music next to the game): albums with covers and artists, a song list, search, shuffle, repeat, volume and a
 * seek bar. The Library tab plays what you own, the Store tab sells albums for coins.
 * The music itself is {@link PlayerEngine}, the same as the portable player uses (so seeking and pausing work).
 */
public class MusicApp extends App {
    // ---------- colors ----------
    private static final int TEXT = 0xFFFFFFFF, MUTED = 0xFFB8A8D8, ACCENT = 0xFFF58FB8, ACCENT2 = 0xFFB57BD6;
    private static final int CARD = 0x26FFFFFF, CARD_H = 0x4CFFFFFF, CARD_SEL = 0x66B57BD6, BAR_BG = 0x44FFFFFF, GOLD = 0xFFFFD25A, GREEN = 0xFF8EE6A0;

    // ---------- layout (the app area is 300 x 166) ----------
    private static final int TAB_Y = 4, TAB_H = 14, TAB_LIB_X = 8, TAB_STORE_X = 60, TAB_W = 50;
    private static final int ICON_FOLDER_X = 116, ICON_RESCAN_X = 134, ICON_W = 16;
    private static final int SEARCH_X = 152, SEARCH_W = 140;
    private static final int BODY_Y = 24, BODY_END = 116;
    private static final int LEFT_X = 8, LEFT_W = 104, ROW = 22, LEFT_VIS = 4;
    private static final int RIGHT_X = 118, RIGHT_W = 174, HEAD_H = 34, TR_Y = 62, TR_H = 10, TR_VIS = 5;
    private static final int FOOT_Y = 117, SEEK_X0 = 36, SEEK_X1 = 264, SEEK_Y = 122;
    private static final int PLAY_CX = 150, PLAY_CY = 146;
    private static final int VOL_X = 236, VOL_W = 52, VOL_Y = 145;
    private static final int BTN_X = 240, BTN_W = 52;

    // ---------- state ----------
    private boolean store;                       // false = Library, true = Store
    private String selId;                        // the album that is open on the right
    private int leftTop, rightTop, resTop;       // first visible row of the three lists
    private String query = "";
    private boolean typing;
    private int drag;                            // 1 = seek bar, 2 = volume
    private long dragMs;
    private int ticks, mx, my;
    private String flash = "";
    private int flashT;
    private boolean started;                     // this app started the music (so closing the app stops it)

    private void say(String s) { flash = s; flashT = 180; }

    // ---------- note-block sounds for the other apps (radio, videos...) ----------
    static void note(int instrument, int n, float volume) {
        SoundEvent ev = switch (instrument) {
            case 0 -> SoundEvents.NOTE_BLOCK_HARP.value();
            case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
            case 2 -> SoundEvents.NOTE_BLOCK_BASS.value();
            default -> SoundEvents.NOTE_BLOCK_CHIME.value();
        };
        float pitch = (float) Math.max(0.5, Math.min(2.0, Math.pow(2.0, (n - 12) / 12.0)));
        Sfx.musicNote(ev, pitch, volume);
    }

    // ---------- for the desktop (taskbar, widget) ----------
    @Override public Component title() { return Component.translatable("cutemod.os.music"); }

    @Override public Component hint() { return Component.translatable("cutemod.os.hint.music"); }

    @Override
    public Component status() {
        return PlayerEngine.isPlaying() ? Component.translatable("cutemod.music.now", trackName())
                : Component.translatable("cutemod.music.paused");
    }

    @Override public boolean busy() { return PlayerEngine.isPlaying(); }

    @Override public boolean background() { return PlayerEngine.isPlaying(); }

    @Override
    public void close() { if (started) { PlayerEngine.stop(); started = false; } }

    boolean active() { return PlayerEngine.current() != null && (PlayerEngine.isPlaying() || PlayerEngine.position() > 0); }

    boolean isPlaying() { return PlayerEngine.isPlaying(); }

    String trackName() { var c = PlayerEngine.current(); return c == null ? "" : c.track().title(); }

    float progress() {
        long len = PlayerEngine.length();
        return len <= 0 ? 0F : Math.min(1F, PlayerEngine.position() / (float) len);
    }

    void toggle() {
        if (PlayerEngine.current() == null) {
            for (Albums.Album a : Albums.all()) if (a.owned()) { playAlbum(a, 0); return; }
            return;
        }
        PlayerEngine.toggle();
    }

    void nextTrack() { PlayerEngine.next(); }

    void prevTrack() { PlayerEngine.prev(); }

    // ---------- data ----------
    private static String norm(String s) { return s.trim().toLowerCase(Locale.ROOT); }

    private static boolean matches(Albums.Album a, String q) {
        return a.title().toLowerCase(Locale.ROOT).contains(q) || a.artist().toLowerCase(Locale.ROOT).contains(q);
    }

    private boolean searching() { return !query.trim().isEmpty(); }

    private List<Albums.Album> leftList() {
        List<Albums.Album> out = new ArrayList<>();
        String q = norm(query);
        for (Albums.Album a : Albums.all()) {
            if (!store && !a.owned()) continue;
            if (store && !q.isEmpty() && !matches(a, q)) continue;
            out.add(a);
        }
        return out;
    }

    private Albums.Album selected(List<Albums.Album> l) {
        if (selId != null) for (Albums.Album a : l) if (a.id().equals(selId)) return a;
        return l.isEmpty() ? null : l.get(0);
    }

    private static List<PlayerEngine.Entry> entries(Albums.Album a) {
        List<PlayerEngine.Entry> l = new ArrayList<>();
        for (Albums.Track t : a.tracks()) l.add(new PlayerEngine.Entry(a, t));
        return l;
    }

    private void playAlbum(Albums.Album a, int from) { playQueue(entries(a), from); }

    private void playQueue(List<PlayerEngine.Entry> q, int from) { started = true; PlayerEngine.play(q, from); }

    private static int totalMinutes(Albums.Album a) {
        int s = 0;
        for (Albums.Track t : a.tracks()) s += t.seconds();
        return Math.max(1, s / 60);
    }

    private static String time(long ms) {
        long s = Math.max(0, ms / 1000);
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    /** kind 0 = a heading, 1 = an album, 2 = a song (the rows of the search results). */
    private record Res(int kind, Albums.Album album, Albums.Track track, String text) {
        int h() { return kind == 0 ? 12 : kind == 1 ? 16 : 12; }
    }

    private List<Res> results() {
        List<Res> out = new ArrayList<>();
        String q = norm(query);
        List<Res> al = new ArrayList<>(), so = new ArrayList<>();
        for (Albums.Album a : Albums.all()) {
            if (!a.owned()) continue;
            if (matches(a, q)) al.add(new Res(1, a, null, a.title()));
            for (Albums.Track t : a.tracks()) if (t.title().toLowerCase(Locale.ROOT).contains(q)) so.add(new Res(2, a, t, t.title()));
        }
        if (!al.isEmpty()) { out.add(new Res(0, null, null, t("cutemod.player.albums"))); out.addAll(al); }
        if (!so.isEmpty()) { out.add(new Res(0, null, null, t("cutemod.player.songs"))); out.addAll(so); }
        return out;
    }

    // ---------- drawing helpers ----------
    private static int tw(String s) { return CuteFont.width(font(), s); }

    private static void str(GuiGraphics g, String s, int x, int y, int color) { Skin.str(g, font(), s, x, y, color, false); }

    private static void cover(GuiGraphics g, Albums.Album a, int x, int y, int size) {
        RoundCover.draw(g, a, x, y, size);
        if (!RoundCover.hasPicture(a) && size >= 12) {
            String l = RoundCover.letter(a);
            str(g, l, x + (size - tw(l)) / 2, y + size / 2 - 4, 0xFFFFFFFF);
        }
    }

    /** A triangle pointing right (dir 1) or left (dir -1); size = its height. */
    private static void tri(GuiGraphics g, int x, int y, int size, int dir, int color) {
        int cols = size / 2 + 1;
        for (int c = 0; c < cols; c++) {
            int xx = dir > 0 ? x + c : x + cols - 1 - c;
            g.fill(xx, y + c, xx + 1, y + size - c, color);
        }
    }

    private void chip(GuiGraphics g, int x, int y, int w, int h, String s, boolean on) {
        boolean hov = in(mx, my, x, y, w, h);
        roundRect(g, x, y, w, h, 5, on ? CARD_SEL : (hov ? CARD_H : CARD));
        fitText(g, font(), s, x + w / 2, y + (h - 8) / 2 + 1, w - 6, on ? TEXT : MUTED, true);
    }

    private void scrollBar(GuiGraphics g, int x, int y, int h, int total, int vis, int top) {
        if (total <= vis) return;
        int bh = Math.max(8, h * vis / total);
        int by = y + (h - bh) * top / Math.max(1, total - vis);
        g.fill(x, y, x + 2, y + h, 0x22FFFFFF);
        roundRect(g, x, by, 2, bh, 1, 0xFFB57BD6);
    }

    // ---------- render ----------
    @Override
    public void mouse(int x, int y) { mx = x; my = y; }

    @Override
    public void tick() {
        ticks++;
        if (flashT > 0) flashT--;
    }

    @Override
    public void render(GuiGraphics g, int mxx, int myy) {
        mx = mxx; my = myy;
        Skin.grad(g, 0, 0, W, H, 0xFF1B1430, 0xFF2A1F4A);
        renderHeader(g);
        if (!store && searching()) renderResults(g);
        else { renderLeft(g); renderRight(g); }
        renderFooter(g);
        if (flashT > 0) {
            int w = Math.min(W - 24, tw(flash) + 16);
            roundRect(g, (W - w) / 2, 98, w, 14, 6, 0xEE3A2A66);
            fitText(g, font(), flash, W / 2, 101, w - 8, TEXT, true);
        }
        // tooltips of the two small icons
        if (in(mx, my, ICON_FOLDER_X, TAB_Y, ICON_W, TAB_H)) tip(g, t("cutemod.music.folder.tip"));
        else if (in(mx, my, ICON_RESCAN_X, TAB_Y, ICON_W, TAB_H)) tip(g, t("cutemod.music.rescan.tip"));
    }

    private void tip(GuiGraphics g, String s) {
        int w = tw(s) + 8, x = Math.min(mx, W - w - 2), y = TAB_Y + TAB_H + 2;
        roundRect(g, x, y, w, 12, 4, 0xF0120E22);
        str(g, s, x + 4, y + 2, TEXT);
    }

    private void renderHeader(GuiGraphics g) {
        // tabs
        chip(g, TAB_LIB_X, TAB_Y, TAB_W, TAB_H, t("cutemod.music.library"), !store);
        chip(g, TAB_STORE_X, TAB_Y, TAB_W, TAB_H, t("cutemod.music.store"), store);
        // folder icon
        boolean hf = in(mx, my, ICON_FOLDER_X, TAB_Y, ICON_W, TAB_H);
        roundRect(g, ICON_FOLDER_X, TAB_Y, ICON_W, TAB_H, 5, hf ? CARD_H : CARD);
        int fx = ICON_FOLDER_X + 3, fy = TAB_Y + 4;
        g.fill(fx, fy, fx + 4, fy + 1, MUTED); g.fill(fx, fy + 1, fx + 10, fy + 7, MUTED); g.fill(fx + 1, fy + 3, fx + 9, fy + 6, 0xFF3A2A66);
        // rescan icon (a ring with an arrow head)
        boolean hr = in(mx, my, ICON_RESCAN_X, TAB_Y, ICON_W, TAB_H);
        roundRect(g, ICON_RESCAN_X, TAB_Y, ICON_W, TAB_H, 5, hr ? CARD_H : CARD);
        int rx = ICON_RESCAN_X + 4, ry = TAB_Y + 3;
        g.fill(rx + 1, ry, rx + 6, ry + 1, MUTED); g.fill(rx + 6, ry + 1, rx + 7, ry + 3, MUTED);
        g.fill(rx, ry + 1, rx + 1, ry + 7, MUTED); g.fill(rx + 1, ry + 7, rx + 6, ry + 8, MUTED);
        g.fill(rx + 6, ry + 5, rx + 7, ry + 7, MUTED); g.fill(rx + 4, ry - 1, rx + 5, ry + 2, MUTED);
        // search box
        roundRect(g, SEARCH_X, TAB_Y, SEARCH_W, TAB_H, 6, typing ? 0x66FFFFFF : CARD);
        if (typing) g.fill(SEARCH_X + 3, TAB_Y + TAB_H - 1, SEARCH_X + SEARCH_W - 3, TAB_Y + TAB_H, ACCENT);
        int sx = SEARCH_X, sy = TAB_Y;
        g.fill(sx + 5, sy + 3, sx + 9, sy + 4, MUTED); g.fill(sx + 5, sy + 7, sx + 9, sy + 8, MUTED);
        g.fill(sx + 4, sy + 4, sx + 5, sy + 7, MUTED); g.fill(sx + 9, sy + 4, sx + 10, sy + 7, MUTED);
        g.fill(sx + 9, sy + 8, sx + 11, sy + 10, MUTED);
        String shown = query.isEmpty() && !typing ? t("cutemod.player.search") : query;
        String cut = shown;
        while (cut.length() > 1 && tw(cut) > SEARCH_W - 32) cut = cut.substring(1);   // the end of the text stays visible
        str(g, cut, sx + 16, sy + 3, query.isEmpty() ? MUTED : TEXT);
        if (typing && (ticks / 30) % 2 == 0) g.fill(sx + 16 + tw(cut), sy + 3, sx + 17 + tw(cut), sy + TAB_H - 3, TEXT);
        if (!query.isEmpty()) str(g, "x", sx + SEARCH_W - 11, sy + 3, in(mx, my, sx + SEARCH_W - 14, sy, 14, TAB_H) ? TEXT : MUTED);
    }

    // ----- left: the albums -----
    private void renderLeft(GuiGraphics g) {
        List<Albums.Album> l = leftList();
        leftTop = Math.max(0, Math.min(Math.max(0, l.size() - LEFT_VIS), leftTop));
        Albums.Album sel = selected(l);
        if (l.isEmpty()) {
            String[] lines = t(store ? "cutemod.music.noalbums" : "cutemod.music.libempty").split("\\|");
            for (int i = 0; i < lines.length; i++) fitText(g, font(), lines[i], LEFT_X + 2, BODY_Y + 6 + i * 11, LEFT_W + 100, MUTED, false);
            return;
        }
        var cur = PlayerEngine.current();
        for (int i = leftTop; i < Math.min(l.size(), leftTop + LEFT_VIS); i++) {
            int y = BODY_Y + (i - leftTop) * ROW;
            Albums.Album a = l.get(i);
            boolean s = a == sel, hov = in(mx, my, LEFT_X, y, LEFT_W, ROW - 2);
            roundRect(g, LEFT_X, y, LEFT_W, ROW - 2, 5, s ? CARD_SEL : (hov ? CARD_H : CARD));
            cover(g, a, LEFT_X + 3, y + 2, ROW - 6);
            int tx = LEFT_X + ROW, tr = LEFT_W - ROW - 4;
            fitText(g, font(), a.title(), tx, y + 3, tr - (cur != null && cur.album().id().equals(a.id()) ? 8 : 0), TEXT, false);
            String tag = "";
            if (store) tag = a.owned() ? t("cutemod.music.owned") : String.valueOf(a.price());
            int tagW = tag.isEmpty() ? 0 : tw(tag) + 3;
            String sub = a.artist().isEmpty() ? t("cutemod.player.count", a.tracks().size()) : a.artist();
            fitText(g, font(), sub, tx, y + 12, tr - tagW, MUTED, false);
            if (!tag.isEmpty()) str(g, tag, LEFT_X + LEFT_W - 4 - tw(tag), y + 12, a.owned() ? GREEN : GOLD);
            if (cur != null && cur.album().id().equals(a.id())) disc(g, LEFT_X + LEFT_W - 6, y + 6, 2, ACCENT);
        }
        scrollBar(g, LEFT_X + LEFT_W + 2, BODY_Y, LEFT_VIS * ROW - 2, l.size(), LEFT_VIS, leftTop);
    }

    // ----- right: the open album and its songs -----
    private void renderRight(GuiGraphics g) {
        List<Albums.Album> l = leftList();
        Albums.Album a = selected(l);
        if (a == null) return;
        // the head
        cover(g, a, RIGHT_X, BODY_Y, 32);
        int tx = RIGHT_X + 38, tr = BTN_X - tx - 4;
        fitText(g, font(), a.title(), tx, BODY_Y + 1, tr, TEXT, false);
        if (!a.artist().isEmpty()) fitText(g, font(), a.artist(), tx, BODY_Y + 12, tr, MUTED, false);
        fitText(g, font(), t("cutemod.player.count", a.tracks().size()) + "  -  " + t("cutemod.player.min", totalMinutes(a)), tx, BODY_Y + 23, tr, MUTED, false);
        if (store) {
            if (a.owned()) {
                fitText(g, font(), t("cutemod.music.owned"), BTN_X + BTN_W / 2, BODY_Y + 5, BTN_W, GREEN, true);
            } else {
                boolean can = Progress.coins() >= a.price(), hov = in(mx, my, BTN_X, BODY_Y, BTN_W, 15);
                roundRect(g, BTN_X, BODY_Y, BTN_W, 15, 7, can ? (hov ? ACCENT : 0xFFD0709A) : 0xFF4A3A66);
                fitText(g, font(), t("cutemod.music.buy", a.price()), BTN_X + BTN_W / 2, BODY_Y + 4, BTN_W - 4, can ? TEXT : 0xFF9A8ABA, true);
            }
        } else {
            boolean hov = in(mx, my, BTN_X, BODY_Y, BTN_W, 15);
            roundRect(g, BTN_X, BODY_Y, BTN_W, 15, 7, hov ? ACCENT : 0xFFD0709A);
            tri(g, BTN_X + 8, BODY_Y + 4, 7, 1, TEXT);
            fitText(g, font(), t("cutemod.player.play"), BTN_X + 14 + (BTN_W - 14) / 2, BODY_Y + 4, BTN_W - 20, TEXT, true);
            chip(g, BTN_X, BODY_Y + 19, BTN_W, 13, t("cutemod.music.toplayer"), a.onPlayer());
        }
        // the songs
        List<Albums.Track> tracks = a.tracks();
        rightTop = Math.max(0, Math.min(Math.max(0, tracks.size() - TR_VIS), rightTop));
        var cur = PlayerEngine.current();
        for (int i = rightTop; i < Math.min(tracks.size(), rightTop + TR_VIS); i++) {
            int y = TR_Y + (i - rightTop) * TR_H;
            Albums.Track tk = tracks.get(i);
            boolean now = !store && cur != null && cur.album().id().equals(a.id()) && cur.track().id().equals(tk.id());
            boolean hov = !store && in(mx, my, RIGHT_X, y, RIGHT_W, TR_H);
            roundRect(g, RIGHT_X, y, RIGHT_W, TR_H - 1, 3, now ? 0x55F58FB8 : (hov ? CARD_H : ((i & 1) == 0 ? 0x14FFFFFF : 0x00000000)));
            if (now) {
                g.fill(RIGHT_X, y + 2, RIGHT_X + 2, y + TR_H - 3, ACCENT);
                if (PlayerEngine.isPlaying()) {
                    for (int b = 0; b < 3; b++) {
                        int bh = 2 + (int) (Math.abs(Math.sin((ticks + b * 9) * 0.1)) * 5);
                        g.fill(RIGHT_X + 5 + b * 3, y + 8 - bh, RIGHT_X + 7 + b * 3, y + 8, ACCENT);
                    }
                } else tri(g, RIGHT_X + 6, y + 2, 6, 1, ACCENT);
            } else {
                str(g, String.valueOf(i + 1), RIGHT_X + 5, y + 1, MUTED);
            }
            String right = time(tk.seconds() * 1000L);
            fitText(g, font(), tk.title(), RIGHT_X + 18, y + 1, RIGHT_W - 18 - tw(right) - 10, store ? MUTED : (now ? ACCENT : TEXT), false);
            str(g, right, RIGHT_X + RIGHT_W - 4 - tw(right), y + 1, MUTED);
        }
        scrollBar(g, RIGHT_X + RIGHT_W + 2, TR_Y, TR_VIS * TR_H, tracks.size(), TR_VIS, rightTop);
    }

    // ----- search results (Library): albums and songs in one list -----
    private void renderResults(GuiGraphics g) {
        List<Res> rs = results();
        resTop = Math.max(0, Math.min(Math.max(0, rs.size() - 1), resTop));
        if (rs.isEmpty()) { fitText(g, font(), t("cutemod.player.none"), W / 2, BODY_Y + 30, 200, MUTED, true); return; }
        int y = BODY_Y, x = LEFT_X, w = 284;
        var cur = PlayerEngine.current();
        int n = 0;
        for (int i = 0; i < rs.size(); i++) if (rs.get(i).kind() == 2 && i < resTop) n++;
        for (int i = resTop; i < rs.size(); i++) {
            Res r = rs.get(i);
            if (y + r.h() > BODY_END) break;
            boolean hov = in(mx, my, x, y, w, r.h());
            if (r.kind() == 0) {
                str(g, r.text().toUpperCase(Locale.ROOT), x + 3, y + 2, ACCENT2);
            } else if (r.kind() == 1) {
                roundRect(g, x, y, w, r.h() - 1, 4, hov ? CARD_H : CARD);
                cover(g, r.album(), x + 2, y + 2, r.h() - 5);
                fitText(g, font(), r.album().title(), x + r.h() + 2, y + 4, 140, TEXT, false);
                String sub = r.album().artist().isEmpty() ? t("cutemod.player.count", r.album().tracks().size()) : r.album().artist();
                fitText(g, font(), sub, x + w - 4 - 100, y + 4, 100, MUTED, false);
            } else {
                boolean now = cur != null && cur.album().id().equals(r.album().id()) && cur.track().id().equals(r.track().id());
                roundRect(g, x, y, w, r.h() - 1, 3, now ? 0x55F58FB8 : (hov ? CARD_H : ((n & 1) == 0 ? 0x14FFFFFF : 0x00000000)));
                String right = time(r.track().seconds() * 1000L);
                fitText(g, font(), r.track().title(), x + 6, y + 2, 150, now ? ACCENT : TEXT, false);
                fitText(g, font(), r.album().title(), x + 164, y + 2, w - 164 - tw(right) - 12, MUTED, false);
                str(g, right, x + w - 4 - tw(right), y + 2, MUTED);
                n++;
            }
            y += r.h();
        }
    }

    // ----- footer: the seek bar, the song, the controls, the volume -----
    private void renderFooter(GuiGraphics g) {
        g.fill(8, FOOT_Y, W - 8, FOOT_Y + 1, 0x22FFFFFF);
        var cur = PlayerEngine.current();
        long len = PlayerEngine.length();
        long pos = drag == 1 ? dragMs : PlayerEngine.position();
        float frac = len > 0 ? Math.max(0F, Math.min(1F, pos / (float) len)) : 0F;
        // seek bar with the times
        String tl = cur == null ? "0:00" : time(pos), tr = cur == null || len <= 0 ? "-:--" : time(len);
        str(g, tl, SEEK_X0 - 4 - tw(tl), SEEK_Y - 2, MUTED);
        str(g, tr, SEEK_X1 + 4, SEEK_Y - 2, MUTED);
        roundRect(g, SEEK_X0, SEEK_Y, SEEK_X1 - SEEK_X0, 4, 2, BAR_BG);
        int fill = (int) ((SEEK_X1 - SEEK_X0) * frac);
        if (fill > 0) roundRect(g, SEEK_X0, SEEK_Y, fill, 4, 2, ACCENT);
        if (cur != null && (drag == 1 || in(mx, my, SEEK_X0 - 3, SEEK_Y - 5, SEEK_X1 - SEEK_X0 + 6, 14))) disc(g, SEEK_X0 + fill, SEEK_Y + 2, 3, TEXT);

        // the song
        if (cur != null) {
            cover(g, cur.album(), 8, 132, 26);
            fitText(g, font(), cur.track().title(), 38, 134, 58, TEXT, false);
            fitText(g, font(), cur.album().artist().isEmpty() ? cur.album().title() : cur.album().artist(), 38, 144, 58, MUTED, false);
        } else {
            roundRect(g, 8, 132, 26, 26, 5, CARD);
            fitText(g, font(), t("cutemod.player.nothing"), 38, 141, 58, MUTED, false);
        }

        // controls
        chip(g, 100, 140, 24, 12, t("cutemod.player.shuffle.short"), PlayerEngine.shuffle());
        boolean hp = in(mx, my, 126, PLAY_CY - 8, 14, 16), hn = in(mx, my, 160, PLAY_CY - 8, 14, 16), hm = in(mx, my, PLAY_CX - 10, PLAY_CY - 10, 20, 20);
        g.fill(129, PLAY_CY - 4, 130, PLAY_CY + 4, hp ? ACCENT : TEXT); tri(g, 131, PLAY_CY - 4, 8, -1, hp ? ACCENT : TEXT);
        g.fill(171, PLAY_CY - 4, 172, PLAY_CY + 4, hn ? ACCENT : TEXT); tri(g, 163, PLAY_CY - 4, 8, 1, hn ? ACCENT : TEXT);
        disc(g, PLAY_CX, PLAY_CY, 10, hm ? ACCENT : 0xFFD0709A);
        if (PlayerEngine.isPlaying()) { g.fill(PLAY_CX - 4, PLAY_CY - 4, PLAY_CX - 1, PLAY_CY + 4, TEXT); g.fill(PLAY_CX + 1, PLAY_CY - 4, PLAY_CX + 4, PLAY_CY + 4, TEXT); }
        else tri(g, PLAY_CX - 2, PLAY_CY - 5, 10, 1, TEXT);
        chip(g, 178, 140, 44, 12, t("cutemod.player.repeat." + PlayerEngine.repeat().ordinal()), PlayerEngine.repeat() != PlayerEngine.Repeat.OFF);

        // volume
        g.fill(VOL_X - 12, VOL_Y, VOL_X - 9, VOL_Y + 4, MUTED); tri(g, VOL_X - 9, VOL_Y - 2, 8, -1, MUTED);
        roundRect(g, VOL_X, VOL_Y, VOL_W, 4, 2, BAR_BG);
        int vf = (int) (VOL_W * PlayerEngine.volume());
        if (vf > 0) roundRect(g, VOL_X, VOL_Y, vf, 4, 2, ACCENT2);
        if (drag == 2 || in(mx, my, VOL_X - 3, VOL_Y - 5, VOL_W + 6, 14)) disc(g, VOL_X + vf, VOL_Y + 2, 3, TEXT);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (button != 0) return false;
        // search box
        if (in(x, y, SEARCH_X, TAB_Y, SEARCH_W, TAB_H)) {
            if (!query.isEmpty() && in(x, y, SEARCH_X + SEARCH_W - 14, TAB_Y, 14, TAB_H)) { query = ""; resTop = 0; leftTop = 0; }
            typing = true;
            return true;
        }
        typing = false;
        // tabs and the two icons
        if (in(x, y, TAB_LIB_X, TAB_Y, TAB_W, TAB_H)) { store = false; leftTop = rightTop = resTop = 0; return true; }
        if (in(x, y, TAB_STORE_X, TAB_Y, TAB_W, TAB_H)) { store = true; leftTop = rightTop = resTop = 0; return true; }
        if (in(x, y, ICON_FOLDER_X, TAB_Y, ICON_W, TAB_H)) {
            try {
                java.nio.file.Files.createDirectories(dev.cutemod.client.player.UserMusic.dir());
                net.minecraft.Util.getPlatform().openFile(dev.cutemod.client.player.UserMusic.dir().toFile());
            } catch (Exception ex) { say(t("cutemod.music.nofolder")); }
            return true;
        }
        if (in(x, y, ICON_RESCAN_X, TAB_Y, ICON_W, TAB_H)) {
            say(t("cutemod.music.rescanning"));
            Minecraft.getInstance().reloadResourcePacks();
            return true;
        }
        if (clickFooter(x, y)) return true;
        if (y >= BODY_Y && y < BODY_END) return !store && searching() ? clickResults(x, y) : (clickLeft(x, y) || clickRight(x, y));
        return false;
    }

    private boolean clickFooter(int x, int y) {
        if (in(x, y, PLAY_CX - 10, PLAY_CY - 10, 20, 20)) { toggle(); return true; }
        if (in(x, y, 126, PLAY_CY - 8, 14, 16)) { PlayerEngine.prev(); return true; }
        if (in(x, y, 160, PLAY_CY - 8, 14, 16)) { PlayerEngine.next(); return true; }
        if (in(x, y, 100, 140, 24, 12)) { PlayerEngine.toggleShuffle(); return true; }
        if (in(x, y, 178, 140, 44, 12)) { PlayerEngine.cycleRepeat(); return true; }
        if (PlayerEngine.current() != null && in(x, y, SEEK_X0 - 3, SEEK_Y - 5, SEEK_X1 - SEEK_X0 + 6, 14)) { drag = 1; dragTo(x); return true; }
        if (in(x, y, VOL_X - 3, VOL_Y - 5, VOL_W + 6, 14)) { drag = 2; dragTo(x); return true; }
        return false;
    }

    private void dragTo(int x) {
        if (drag == 1) {
            float fr = (x - SEEK_X0) / (float) (SEEK_X1 - SEEK_X0);
            dragMs = (long) (Math.max(0F, Math.min(1F, fr)) * PlayerEngine.length());
        } else if (drag == 2) {
            PlayerEngine.setVolume((x - VOL_X) / (float) VOL_W);
        }
    }

    private boolean clickLeft(int x, int y) {
        if (x < LEFT_X || x >= LEFT_X + LEFT_W) return false;
        List<Albums.Album> l = leftList();
        for (int i = leftTop; i < Math.min(l.size(), leftTop + LEFT_VIS); i++) {
            if (in(x, y, LEFT_X, BODY_Y + (i - leftTop) * ROW, LEFT_W, ROW - 2)) { selId = l.get(i).id(); rightTop = 0; return true; }
        }
        return false;
    }

    private boolean clickRight(int x, int y) {
        Albums.Album a = selected(leftList());
        if (a == null || x < RIGHT_X) return false;
        if (store) {
            if (!a.owned() && in(x, y, BTN_X, BODY_Y, BTN_W, 15)) {
                if (a.buy()) { note(3, 22, 0.8F); say(t("cutemod.music.thanks", a.title())); }
                else say(t("cutemod.music.notenough"));
                return true;
            }
            return false;
        }
        if (in(x, y, BTN_X, BODY_Y, BTN_W, 15)) { playAlbum(a, 0); return true; }
        if (in(x, y, BTN_X, BODY_Y + 19, BTN_W, 13)) { a.setOnPlayer(!a.onPlayer()); return true; }
        for (int i = rightTop; i < Math.min(a.tracks().size(), rightTop + TR_VIS); i++) {
            if (in(x, y, RIGHT_X, TR_Y + (i - rightTop) * TR_H, RIGHT_W, TR_H)) { playAlbum(a, i); return true; }
        }
        return false;
    }

    private boolean clickResults(int x, int y) {
        List<Res> rs = results();
        List<PlayerEngine.Entry> found = new ArrayList<>();
        for (Res r : rs) if (r.kind() == 2) found.add(new PlayerEngine.Entry(r.album(), r.track()));
        int no = 0, yy = BODY_Y;
        for (int i = 0; i < rs.size(); i++) if (rs.get(i).kind() == 2 && i < resTop) no++;
        for (int i = resTop; i < rs.size(); i++) {
            Res r = rs.get(i);
            if (yy + r.h() > BODY_END) break;
            if (in(x, y, LEFT_X, yy, 284, r.h())) {
                if (r.kind() == 1) { selId = r.album().id(); query = ""; typing = false; rightTop = leftTop = resTop = 0; return true; }
                if (r.kind() == 2) { playQueue(found, no); return true; }
            }
            if (r.kind() == 2) no++;
            yy += r.h();
        }
        return false;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (drag == 0) return false;
        dragTo(x);
        return true;
    }

    @Override
    public boolean release(int x, int y, int button) {
        if (drag == 1) PlayerEngine.seek(dragMs);
        boolean was = drag != 0;
        drag = 0;
        return was;
    }

    @Override
    public boolean scroll(double amount) {
        int d = -(int) Math.signum(amount);
        if (!store && searching()) { resTop += d; return true; }
        if (in(mx, my, LEFT_X, BODY_Y, LEFT_W + 4, BODY_END - BODY_Y)) { leftTop += d; return true; }
        if (in(mx, my, RIGHT_X, TR_Y, RIGHT_W + 4, BODY_END - TR_Y)) { rightTop += d; return true; }
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        if (!typing) return false;
        if (c >= 32 && c != 127 && query.length() < 40) { query += c; resTop = leftTop = rightTop = 0; }
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (typing) {
            if (keyCode == 259) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); resTop = leftTop = 0; return true; }   // backspace
            if (keyCode == 257 || keyCode == 335) { typing = false; return true; }                                                          // enter
            if (keyCode == 256) { if (!query.isEmpty()) query = ""; else typing = false; return true; }                                      // escape
            if (keyCode == 86 && (modifiers & 2) != 0) {                                                                                     // ctrl+V
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) { String all = query + clip.replaceAll("[\\r\\n]", " "); query = all.substring(0, Math.min(40, all.length())); }
                return true;
            }
            return true;
        }
        switch (keyCode) {
            case 32 -> toggle();                                                       // space
            case 262 -> PlayerEngine.seek(PlayerEngine.position() + 5000);             // right: +5 s
            case 263 -> PlayerEngine.seek(PlayerEngine.position() - 5000);             // left: -5 s
            case 78 -> PlayerEngine.next();                                            // N
            case 80 -> PlayerEngine.prev();                                            // P
            case 47 -> typing = true;                                                  // /
            default -> { return false; }
        }
        return true;
    }
}
