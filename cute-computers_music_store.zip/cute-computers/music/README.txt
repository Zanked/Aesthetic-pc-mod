ALBUMS FOR THE MUSIC APP
========================
One folder = one album. Put your songs there and rebuild the mod (./gradlew build or runClient).

  music/My Album/01 First song.ogg
  music/My Album/02 Second song.ogg
  music/My Album/cover.jpg        <- optional picture (png, jpg, gif, bmp). Names cover/folder/front/album/art,
                                      or if there is none, the first picture in the folder is used
  music/My Album/album.json       <- optional, see below

album.json (all fields optional):
  { "title": "My Album", "artist": "Me", "price": 70 }

- Songs must be .ogg (Vorbis). Convert: ffmpeg -i song.mp3 -c:a libvorbis -q:a 4 song.ogg
- Song names can be in any language: the name of the file is shown as the song title
  (a leading number like "01 - " is removed). Songs play in the order of the file names.
- price = coins in the Store tab. Every album costs 70 by default; put a price in album.json only to change it. price 0 = free album, already in your library.

NO REBUILD NEEDED
-----------------
You can also put the same album folders into the folder "cutemod_music" next to the game
(the Music app has a Folder button that opens it). Then press Rescan in the Music app, or F3+T.
Albums from that folder work the same way (Store, Library, portable player).
