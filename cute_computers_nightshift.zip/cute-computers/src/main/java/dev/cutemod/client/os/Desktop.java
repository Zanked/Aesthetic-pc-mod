package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * The desktop. The wallpaper, menu bar and Dock are drawn by the computer screen; this class owns the apps
 * (the Dock launches them with launch(i)) and draws the desktop widget.
 */
public class Desktop extends App {
    public static final int ICONS = 35;

    private BrowserApp browser;
    private NotepadApp notes;
    private PaintApp paint;
    private CalcApp calc;
    private MusicApp music;
    private PetApp pet;
    private QuestApp quest;
    private TerminalApp terminal;
    private StoreApp store;
    private JobsApp jobs;
    private MailApp mail;
    private MarketApp market;
    private NetApp net;
    private WeatherApp weather;
    private FarmApp farm;
    private FishingApp fishing;
    private StyleApp style;
    private BeatApp beats;
    private ExplorerApp explorer;
    private SeasonApp season;
    private GiftApp gift;
    private QuizApp quiz;
    private TicTacApp ttt;
    private WheelApp wheel;
    private PhotoApp photo;
    private StickersApp stickers;
    private BankApp bank;
    private WishApp wish;
    private RadioApp radio;
    private PetStatsApp petstats;
    private TalesApp tales;
    private boolean widgetMenu;
    private int wmX, wmY;

    // folders on the desktop: press, drag to move, release to open (or drop on the Dock to pin)
    private static final int ICON_W = Folders.DESK_W, ICON_H = Folders.DESK_H, CTX_ROW = 12, ICON_PX = 24, LABEL_W = 46;
    private int mouseX = -1, mouseY = -1;
    private int pressFolder = -1, pressX, pressY, offX, offY, dragX, dragY;
    private boolean dragging;
    private int ctxFolder = -1, ctxX, ctxY;        // the right-click menu of a folder: 0 open, 1 rename, 2 Dock, 3 delete

    @Override
    public Component title() { return Component.translatable("cutemod.os.title"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.desktop"); }

    /** Name of the app / game / folder with this number. */
    public String label(int i) { return nameOf(i); }

    public static String nameOf(int i) {
        if (Items.isFolder(i)) return Folders.name(i);
        if (Items.isGame(i)) return Library.name(Items.gameId(i));
        return switch (i) {
            case 2 -> t("cutemod.os.browser");
            case 3 -> t("cutemod.os.notes");
            case 4 -> t("cutemod.os.paint");
            case 5 -> t("cutemod.os.calc");
            case 7 -> t("cutemod.os.music");
            case 8 -> t("cutemod.os.pet");
            case 9 -> t("cutemod.os.market");
            case 10 -> t("cutemod.os.quest");
            case 11 -> t("cutemod.os.terminal");
            case 12 -> t("cutemod.os.store");
            case 13 -> t("cutemod.os.jobs");
            case 14 -> t("cutemod.os.mail");
            case 15 -> t("cutemod.os.net");
            case 16 -> t("cutemod.os.weather");
            case 17 -> t("cutemod.os.farm");
            case 18 -> t("cutemod.os.fishing");
            case 19 -> t("cutemod.os.style");
            case 20 -> t("cutemod.os.beats");
            case 21 -> t("cutemod.os.season");
            case 22 -> t("cutemod.os.explorer");
            case 23 -> t("cutemod.os.gift");
            case 24 -> t("cutemod.os.quiz");
            case 25 -> t("cutemod.os.tictac");
            case 26 -> t("cutemod.os.wheel");
            case 28 -> t("cutemod.os.photo");
            case 29 -> t("cutemod.os.stickers");
            case 30 -> t("cutemod.os.bank");
            case 31 -> t("cutemod.os.wishlist");
            case 32 -> t("cutemod.os.radio");
            case 33 -> t("cutemod.os.petstats");
            case 34 -> t("cutemod.os.tales");
            default -> t("cutemod.os.settings");
        };
    }

    @Override
    public void tick() { Halloween.tick(); }

    /** The music app, if it was opened (the player widget talks to it). */
    MusicApp music() { return music; }

    private static final int SAFE_BTN_W = 150, SAFE_BTN_H = 18;

    private static int safeBtnX() { return (W - SAFE_BTN_W) / 2; }

    private static int safeBtnY() { return H / 2 - 4; }

    @Override
    public void mouse(int x, int y) { mouseX = x; mouseY = y; }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    /** The folder on the desktop under this point, or -1. */
    private int folderAt(int x, int y) {
        List<Integer> l = Folders.onDesk();
        for (int i = l.size() - 1; i >= 0; i--) {
            int[] p = Folders.deskPos(l.get(i));
            if (p != null && Folders.exists(l.get(i)) && in(x, y, p[0], p[1], ICON_W, ICON_H)) return l.get(i);
        }
        return -1;
    }

    private void openFolder(int id) {
        int[] p = Folders.deskPos(id);
        if (p != null) shell.launchFrom(id, shell.absX() + p[0] + ICON_W / 2, shell.absY() + p[1] + 14);
        else launch(id);
    }

    private void newFolderAt(int x, int y) {
        int id = Folders.create(t("cutemod.folder.default"));
        Folders.deskMove(id, x - ICON_W / 2, y - 14);
        FolderApp.pendingRename = id;
        openFolder(id);
    }

    // ---------- the right-click menu of a folder ----------
    private String ctxLabel(int row) {
        return switch (row) {
            case 0 -> t("cutemod.folder.open");
            case 1 -> t("cutemod.folder.rename");
            case 2 -> t(DockLayout.pinned(ctxFolder) ? "cutemod.folder.dock_remove" : "cutemod.folder.dock_add");
            default -> t("cutemod.folder.delete");
        };
    }

    private int ctxW() {
        int w = 0;
        for (int i = 0; i < 4; i++) w = Math.max(w, font().width(ctxLabel(i)));
        return w + 12;
    }

    private void clickCtx(int x, int y) {
        int id = ctxFolder, w = ctxW(), row = (y - ctxY) / CTX_ROW;
        ctxFolder = -1;
        if (x < ctxX || x >= ctxX + w || y < ctxY || row < 0 || row > 3) return;
        switch (row) {
            case 0 -> openFolder(id);
            case 1 -> { FolderApp.pendingRename = id; openFolder(id); }
            case 2 -> { if (DockLayout.pinned(id)) DockLayout.unpin(id); else DockLayout.pin(id); }
            default -> Folders.delete(id);
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (Retro.safe()) {                                          // Safe Mode: the one thing to do is repair the disk
            if (in(x, y, safeBtnX(), safeBtnY(), SAFE_BTN_W, SAFE_BTN_H)) { Sfx.click(); shell.open(new RepairApp()); }
            return true;
        }
        if (ctxFolder >= 0) { clickCtx(x, y); return true; }          // a folder menu is open: it takes this click
        if (widgetMenu) {                                            // the widgets menu takes this click
            widgetMenu = false;
            if (Widgets.clickMenu(x, y, wmX, wmY)) newFolderAt(wmX + 20, wmY + 16);
            return true;
        }
        int wr = Widgets.click(music, x, y, button);
        if (wr == Widgets.OPEN_MARKET) { launch(9); return true; }
        if (wr != Widgets.NONE) return true;
        if (Halloween.click(shell, x, y)) return true;
        int fid = folderAt(x, y);
        if (fid >= 0) {
            if (button == 1) {                                       // right click on a folder: its menu
                ctxFolder = fid;
                ctxX = clamp(x, 0, W - ctxW() - 2);
                ctxY = clamp(y, 0, H - 4 * CTX_ROW - 4);
            } else if (button == 0) {                                // it opens on release, unless dragged
                int[] p = Folders.deskPos(fid);
                pressFolder = fid; pressX = x; pressY = y; dragX = x; dragY = y; dragging = false;
                offX = x - p[0]; offY = y - p[1];
            }
            return true;
        }
        if (button == 1) {                                           // right click on the empty desktop: new folder, widgets
            widgetMenu = true;
            wmX = Math.min(x, W - Widgets.menuW() - 2);
            wmY = Math.min(y, H - Widgets.menuH() - 2);
            return true;
        }
        return false;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (pressFolder < 0 || button != 0) return false;
        if (!dragging && Math.abs(x - pressX) + Math.abs(y - pressY) > 3) dragging = true;
        dragX = x; dragY = y;
        return true;
    }

    @Override
    public boolean release(int x, int y, int button) {
        if (pressFolder < 0 || button != 0) return false;
        int id = pressFolder;
        boolean was = dragging;
        pressFolder = -1;
        dragging = false;
        if (!Folders.exists(id)) return true;
        if (!was) { openFolder(id); return true; }
        if (y >= H) {                                                // dropped on the Dock: pinned there
            if (DockLayout.pin(id)) Folders.deskRemove(id);
            return true;
        }
        int nx = clamp(x - offX, 0, W - ICON_W), ny = clamp(y - offY, 0, H - ICON_H);
        if (!Widgets.covers(music, nx + ICON_W / 2, ny + 14)) Folders.deskMove(id, nx, ny);   // not under a widget
        return true;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        if (Retro.safe()) {
            g.drawCenteredString(font(), Component.translatable("cutemod.safe.hint"), W / 2, H / 2 - 24, 0xFFBFBFBF);
            boolean hover = in(mx, my, safeBtnX(), safeBtnY(), SAFE_BTN_W, SAFE_BTN_H);
            rect(g, safeBtnX() - 1, safeBtnY() - 1, SAFE_BTN_W + 2, SAFE_BTN_H + 2, 0xFFBFBFBF);
            rect(g, safeBtnX(), safeBtnY(), SAFE_BTN_W, SAFE_BTN_H, hover ? 0xFF2A4A80 : 0xFF0B1A33);
            g.drawCenteredString(font(), Component.translatable("cutemod.safe.open"), W / 2, safeBtnY() + 5, 0xFFFFFFFF);
            return;
        }
        Halloween.render(g, mx, my);
        renderFolders(g, mx, my);
        Widgets.render(g, music, mx, my);
        if (widgetMenu) Widgets.renderMenu(g, mx, my, wmX, wmY);
        if (ctxFolder >= 0) renderCtx(g, mx, my);
    }

    /** One folder on the desktop: the tile and its name under it (white with a soft shadow, readable on any wallpaper). */
    private void folderIcon(GuiGraphics g, Font f, int id, int x, int y, boolean lit) {
        if (lit) roundRect(g, x, y, ICON_W, ICON_H, 6, 0x33FFFFFF);
        g.pose().pushPose();
        g.pose().translate(x + (ICON_W - ICON_PX) / 2f, y + 2, 0);
        g.pose().scale(ICON_PX / 32f, ICON_PX / 32f, 1f);
        drawIcon(g, id, 0, 0, 0);
        g.pose().popPose();
        String name = Folders.name(id);
        int cx = x + ICON_W / 2;
        smallText(g, f, name, cx + 1, y + ICON_PX + 4, LABEL_W, 0xAA000000);
        smallText(g, f, name, cx, y + ICON_PX + 3, LABEL_W, 0xFFFFFFFF);
    }

    private void renderFolders(GuiGraphics g, int mx, int my) {
        Font f = font();
        for (int id : Folders.onDesk()) {
            int[] p = Folders.deskPos(id);
            if (p == null || !Folders.exists(id) || (dragging && pressFolder == id)) continue;
            boolean lit = ctxFolder < 0 && !widgetMenu && in(mx, my, p[0], p[1], ICON_W, ICON_H) && pressFolder < 0;
            folderIcon(g, f, id, p[0], p[1], lit || ctxFolder == id);
        }
        if (dragging && pressFolder >= 0 && Folders.exists(pressFolder)) {        // the dragged one follows the mouse, above everything
            g.pose().pushPose();
            g.pose().translate(0, 0, 40);
            folderIcon(g, f, pressFolder, clamp(dragX - offX, -8, W - ICON_W + 8), clamp(dragY - offY, -8, H + 20), true);
            g.pose().popPose();
        }
    }

    private void renderCtx(GuiGraphics g, int mx, int my) {
        Font f = font();
        int w = ctxW(), h = 4 * CTX_ROW;
        g.pose().pushPose();
        g.pose().translate(0, 0, 60);
        g.fill(ctxX - 1, ctxY - 1, ctxX + w + 1, ctxY + h + 1, 0x55FFFFFF);
        for (int i = 0; i < 4; i++) {
            int ry = ctxY + i * CTX_ROW;
            boolean hov = in(mx, my, ctxX, ry, w, CTX_ROW);
            g.fill(ctxX, ry, ctxX + w, ry + CTX_ROW, hov ? 0xFFB57BD6 : 0xF21B1422);
            CuteFont.draw(g, f, ctxLabel(i), ctxX + 6, ry + 2, i == 3 && !hov ? 0xFFFF8A8F : 0xFFFFFFFF, false);
        }
        g.pose().popPose();
    }

    /** Which Dock icon belongs to the running app (-1 = none / the desktop itself). */
    public int activeIndex(App a) {
        if (a instanceof FolderApp f) return f.id();
        if (a instanceof GameApp ga) return Items.ofGame(ga.gameId());
        if (a instanceof BrowserApp) return 2;
        if (a instanceof NotepadApp) return 3;
        if (a instanceof PaintApp) return 4;
        if (a instanceof CalcApp) return 5;
        if (a instanceof SettingsApp) return 6;
        if (a instanceof MusicApp) return 7;
        if (a instanceof PetApp) return 8;
        if (a instanceof MarketApp) return 9;
        if (a instanceof QuestApp) return 10;
        if (a instanceof TerminalApp) return 11;
        if (a instanceof StoreApp) return 12;
        if (a instanceof JobsApp) return 13;
        if (a instanceof MailApp) return 14;
        if (a instanceof NetApp) return 15;
        if (a instanceof WeatherApp) return 16;
        if (a instanceof FarmApp) return 17;
        if (a instanceof FishingApp) return 18;
        if (a instanceof StyleApp) return 19;
        if (a instanceof BeatApp) return 20;
        if (a instanceof SeasonApp) return 21;
        if (a instanceof ExplorerApp) return 22;
        if (a instanceof GiftApp) return 23;
        if (a instanceof QuizApp) return 24;
        if (a instanceof TicTacApp) return 25;
        if (a instanceof WheelApp) return 26;
        if (a instanceof PhotoApp) return 28;
        if (a instanceof StickersApp) return 29;
        if (a instanceof BankApp) return 30;
        if (a instanceof WishApp) return 31;
        if (a instanceof RadioApp) return 32;
        if (a instanceof PetStatsApp) return 33;
        if (a instanceof TalesApp) return 34;
        return -1;
    }

    /** The old numbering for the places that only know the apps (CuteNet, the helper bee): every game is 0, a folder is the desktop. */
    public int legacyIndex(App a) {
        int i = activeIndex(a);
        return i >= Items.FOLDER_BASE ? -1 : i >= Items.GAME_BASE ? 0 : i;
    }

    /** Draws the 32x32 icon of app number i at x,y (the Dock scales it with the pose). */
    /** Tile colors (top, bottom) of every icon, by its Dock number; 0 (the gamepad) uses the computer's own color. */
    private static final int[] TALES_TILE = {0xFFE8B070, 0xFFB8743A};   // 34 tales: a leather brown book
    private static final int[][] TILE = {
            {0, 0},                        // 0 gamepad
            {0xFF7BD8FF, 0xFF2F9BF2},      // 1 games folder
            {0xFF5BE6D4, 0xFF1AA7C9},      // 2 browser
            {0xFFFFE97A, 0xFFF7BE1D},      // 3 notes
            {0xFFC59BFF, 0xFF7C4DE6},      // 4 paint
            {0xFF5A5A62, 0xFF1C1C20},      // 5 calculator
            {0xFFB9BEC8, 0xFF727886},      // 6 settings
            {0xFFFF7AB5, 0xFFE02A7A},      // 7 music
            {0xFF9BE88A, 0xFF34B85A},      // 8 pet
            {0xFFFFA070, 0xFFF0603A},      // 9 market
            {0xFFFF7A7A, 0xFFD92B3A},      // 10 diary
            {0xFF48484E, 0xFF0E0E10},      // 11 terminal
            {0xFF6FB0FF, 0xFF2F4FE0},      // 12 store
            {0xFFCFA070, 0xFF8A5F36},      // 13 jobs
            {0xFF63C6FF, 0xFF1F7BF0},      // 14 mail
            {0xFF8BE89A, 0xFF1E9E6A},      // 15 CuteNet
            {0xFF8FD8FF, 0xFF3A8AE0},      // 16 weather
            {0xFF9BE08A, 0xFF3E9A4A},      // 17 farm
            {0xFF6FD0FF, 0xFF1F78C8},      // 18 fishing
            {0xFFD9A0F0, 0xFF9A4ACB},      // 19 style
            {0xFF6A4AD0, 0xFF2A1A78},      // 20 beats
            {0xFFFFD36B, 0xFFF08A24},      // 21 season pass
            {0xFFFFE08A, 0xFFF0A93A},
            {0xFFFFA8C8, 0xFFE0508A},
            {0xFF9AE0A0, 0xFF3E9A5A},
            {0xFF9AD0F8, 0xFF3A80D0},
            {0xFFFFC070, 0xFFE06A20},
            {0xFF8AE0C0, 0xFF2E9A78},
            {0xFFB0B8F8, 0xFF5A62D0},
            {0xFFF8A8E0, 0xFFC050A0},
            {0xFFFFB0C0, 0xFFE0607A},
            {0xFFFFA8D0, 0xFFD0508A},
            {0xFF9AA8F8, 0xFF4A52C8},
            {0xFFFFD08A, 0xFFE08A2A}};     // 23-29 gift quiz tictac wheel habits photo stickers

    /** The macOS-style rounded tile every icon sits on: a soft vertical gradient, a light top edge, a thin dark rim. */
    static void tile(GuiGraphics g, int x, int y, int top, int bottom) {
        final int r = 8, size = 32;
        if (Theme.anime()) { animeTile(g, x, y, top, bottom); return; }
        if (Theme.aero()) { glassTile(g, x, y, top, bottom); return; }
        if (Theme.kawaii()) { candyTile(g, x, y, top, bottom); return; }
        if (Theme.retro()) { bevelTile(g, x, y, top, bottom); return; }
        for (int dy = 0; dy < size; dy++) {
            double m = dy + 0.5;
            double d = m < r ? r - m : m > size - r ? m - (size - r) : 0;
            int inset = d > 0 ? (int) Math.round(r - Math.sqrt(r * r - d * d)) : 0;
            int c = mix(top, bottom, dy / (float) (size - 1));
            g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, c);
            g.fill(x + inset, y + dy, x + inset + 1, y + dy + 1, 0x26000000);               // the rim
            g.fill(x + size - inset - 1, y + dy, x + size - inset, y + dy + 1, 0x26000000);
            if (dy == 1) g.fill(x + inset + 1, y + dy, x + size - inset - 1, y + dy + 1, 0x55FFFFFF); // light top edge
            if (dy == size - 1) g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, 0x30000000);
        }
    }

    /** Retro 98: a square grey button with raised edges and the colours of the icon in a flat box. */
    private static void bevelTile(GuiGraphics g, int x, int y, int top, int bottom) {
        final int size = 32;
        g.fill(x, y, x + size, y + size, 0xFF000000);
        g.fill(x + 1, y + 1, x + size - 1, y + size - 1, 0xFFC0C0C0);
        g.fill(x + 1, y + 1, x + size - 1, y + 2, 0xFFFFFFFF);
        g.fill(x + 1, y + 1, x + 2, y + size - 1, 0xFFFFFFFF);
        g.fill(x + 2, y + size - 2, x + size - 1, y + size - 1, 0xFF808080);
        g.fill(x + size - 2, y + 2, x + size - 1, y + size - 1, 0xFF808080);
        g.fillGradient(x + 4, y + 4, x + size - 4, y + size - 4, mix(top, 0xC0C0C0, 0.25f), mix(bottom, 0x808080, 0.25f));
    }

    /** Anime Sakura: a candy "sticker" tile: pastel gradient, a thick white rim, a soft gloss, a pink glow at the bottom and a tiny sparkle. */
    private static void animeTile(GuiGraphics g, int x, int y, int top, int bottom) {
        final int r = 8, size = 32;
        for (int dy = 0; dy < size; dy++) {
            double m = dy + 0.5;
            double d = m < r ? r - m : m > size - r ? m - (size - r) : 0;
            int inset = d > 0 ? (int) Math.round(r - Math.sqrt(r * r - d * d)) : 0;
            float f = dy / (float) (size - 1);
            g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, mix(mix(top, 0xFFFFFF, 0.28f), mix(bottom, 0xFFD6EE, 0.2f), f));
            g.fill(x + inset, y + dy, x + inset + 1, y + dy + 1, 0xFFFFFFFF);                  // the white sticker rim
            g.fill(x + size - inset - 1, y + dy, x + size - inset, y + dy + 1, 0xFFFFFFFF);
            if (dy == 0 || dy == size - 1) g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, 0xFFFFFFFF);
            if (dy >= 2 && dy <= 8) g.fill(x + inset + 3, y + dy, x + size - inset - 3, y + dy + 1, ((0x44 - (dy - 2) * 6) << 24) | 0xFFFFFF);   // gloss
            if (dy >= 24 && dy <= 29) g.fill(x + inset + 3, y + dy, x + size - inset - 3, y + dy + 1, (((dy - 22) * 5) << 24) | 0xFFC0E4);     // pink glow
        }
        g.fill(x + 26, y + 4, x + 27, y + 8, 0xFFFFFFFF);                                        // a tiny sparkle in the corner
        g.fill(x + 25, y + 5, x + 28, y + 6, 0xFFFFFFFF);
    }

    /** Kawaii Pastel: a soft candy tile (the colours are pulled toward white), a white rim and a little sparkle. */
    private static void candyTile(GuiGraphics g, int x, int y, int top, int bottom) {
        final int r = 8, size = 32;
        int t2 = mix(top, 0xFFFFFF, 0.45f), b2 = mix(bottom, 0xFFC4E0, 0.35f);
        for (int dy = 0; dy < size; dy++) {
            double m = dy + 0.5;
            double d = m < r ? r - m : m > size - r ? m - (size - r) : 0;
            int inset = d > 0 ? (int) Math.round(r - Math.sqrt(r * r - d * d)) : 0;
            g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, mix(t2, b2, dy / (float) (size - 1)));
            g.fill(x + inset, y + dy, x + inset + 1, y + dy + 1, 0xFFFFFFFF);                 // the white rim
            g.fill(x + size - inset - 1, y + dy, x + size - inset, y + dy + 1, 0xFFFFFFFF);
            if (dy == 0 || dy == size - 1) g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, 0xFFFFFFFF);
            if (dy == size - 1) g.fill(x + inset + 2, y + dy, x + size - inset - 2, y + dy + 1, 0x30D06090);
        }
        g.fill(x + 5, y + 4, x + 8, y + 5, 0xFFFFFFFF);                                       // a sparkle in the corner
        g.fill(x + 6, y + 3, x + 7, y + 6, 0xFFFFFFFF);
    }

    /** Frutiger Aero: a see-through glass tile with a bright rim, a glossy upper half and a glow at the bottom. */
    private static void glassTile(GuiGraphics g, int x, int y, int top, int bottom) {
        final int r = 8, size = 32;
        for (int dy = 0; dy < size; dy++) {
            double m = dy + 0.5;
            double d = m < r ? r - m : m > size - r ? m - (size - r) : 0;
            int inset = d > 0 ? (int) Math.round(r - Math.sqrt(r * r - d * d)) : 0;
            float f = dy / (float) (size - 1);
            int c = (mix(top, bottom, f) & 0xFFFFFF) | ((0xA0 - (int) (0x30 * f)) << 24);       // clear glass: the wallpaper shows through
            g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, c);
            g.fill(x + inset, y + dy, x + inset + 1, y + dy + 1, 0xC0FFFFFF);                  // the bright rim
            g.fill(x + size - inset - 1, y + dy, x + size - inset, y + dy + 1, 0xC0FFFFFF);
            if (dy == 0 || dy == size - 1) g.fill(x + inset, y + dy, x + size - inset, y + dy + 1, 0xC0FFFFFF);
            if (dy >= 1 && dy <= 14) {                                                             // the gloss on the upper half
                int al = 0x58 - dy * 3;
                g.fill(x + inset + 2, y + dy, x + size - inset - 2, y + dy + 1, (Math.max(8, al) << 24) | 0xFFFFFF);
            }
            if (dy >= 25 && dy <= 29) g.fill(x + inset + 3, y + dy, x + size - inset - 3, y + dy + 1, ((dy - 22) * 6 << 24) | 0xBFF1FF);  // glow
        }
    }

    /** One Dock icon: the rounded tile plus a flat glyph. Drawn in a 32 x 32 box at (x, y). */
    public static void drawIcon(GuiGraphics g, int i, int x, int y, int body) {
        if (Items.isFolder(i)) { Folders.drawIcon(g, i, x, y, body); return; }
        if (Items.isGame(i)) { drawGame(g, Items.gameId(i), x, y); return; }
        int[] tc = i == 34 ? TALES_TILE : TILE[i > 0 && i < TILE.length ? i : 4];
        int top = tc[0], bot = tc[1];
        tile(g, x, y, top, bot);
        int mid = mix(top, bot, 0.5f);
        final int WH = 0xFFFFFFFF;
        switch (i) {
            case 2 -> { // browser: a compass
                disc(g, x + 16, y + 16, 11, WH);
                disc(g, x + 16, y + 16, 9, mix(top, bot, 0.6f));
                rect(g, x + 15, y + 8, 2, 2, WH); rect(g, x + 15, y + 22, 2, 2, WH);
                rect(g, x + 8, y + 15, 2, 2, WH); rect(g, x + 22, y + 15, 2, 2, WH);
                for (int k = -7; k <= 7; k++) rect(g, x + 15 + k, y + 15 - k, 2, 2, k >= 0 ? 0xFFFF5A4A : WH);
            }
            case 3 -> { // notes
                rect(g, x + 7, y + 6, 18, 21, WH);
                rect(g, x + 7, y + 6, 18, 5, 0xFFF0B000);
                for (int l = 0; l < 4; l++) rect(g, x + 10, y + 14 + l * 3, 12, 1, 0xFFC8CCD8);
            }
            case 5 -> { // calculator
                rect(g, x + 7, y + 6, 18, 6, 0xFF333338);
                rect(g, x + 19, y + 8, 4, 2, 0xFFB6F59A);
                for (int r = 0; r < 3; r++) for (int c = 0; c < 4; c++)
                    rect(g, x + 7 + c * 5, y + 15 + r * 4, 3, 3, c == 3 ? 0xFFFF9F0A : r == 0 ? 0xFFA5A5AA : 0xFF8E8E93);
            }
            case 6 -> { // settings: a gear
                rect(g, x + 14, y + 5, 4, 4, WH); rect(g, x + 14, y + 23, 4, 4, WH);
                rect(g, x + 5, y + 14, 4, 4, WH); rect(g, x + 23, y + 14, 4, 4, WH);
                rect(g, x + 8, y + 8, 4, 4, WH); rect(g, x + 20, y + 8, 4, 4, WH);
                rect(g, x + 8, y + 20, 4, 4, WH); rect(g, x + 20, y + 20, 4, 4, WH);
                disc(g, x + 16, y + 16, 9, WH);
                disc(g, x + 16, y + 16, 3, mid);
            }
            case 7 -> { // music: two beamed notes
                disc(g, x + 11, y + 23, 3, WH); disc(g, x + 21, y + 21, 3, WH);
                rect(g, x + 13, y + 10, 2, 13, WH); rect(g, x + 23, y + 8, 2, 13, WH);
                rect(g, x + 13, y + 9, 12, 3, WH);
            }
            case 8 -> { // pet: an egg with a face
                disc(g, x + 16, y + 19, 9, WH);
                disc(g, x + 16, y + 13, 6, WH);
                rect(g, x + 12, y + 17, 2, 3, 0xFF3A2A3A); rect(g, x + 19, y + 17, 2, 3, 0xFF3A2A3A);
                rect(g, x + 15, y + 22, 3, 1, 0xFF3A2A3A);
                rect(g, x + 10, y + 21, 2, 2, 0xFFFFB6D2); rect(g, x + 21, y + 21, 2, 2, 0xFFFFB6D2);
            }
            case 9 -> { // market: a bag with a heart
                rect(g, x + 12, y + 7, 8, 1, WH); rect(g, x + 12, y + 7, 1, 6, WH); rect(g, x + 19, y + 7, 1, 6, WH);
                rect(g, x + 8, y + 12, 16, 15, WH);
                rect(g, x + 12, y + 16, 3, 2, mid); rect(g, x + 17, y + 16, 3, 2, mid);
                rect(g, x + 12, y + 18, 8, 2, mid); rect(g, x + 14, y + 20, 4, 2, mid);
            }
            case 10 -> { // diary: a book with an exclamation mark
                rect(g, x + 7, y + 6, 3, 20, 0xFFFFD0D0);
                rect(g, x + 9, y + 6, 16, 20, WH);
                rect(g, x + 16, y + 9, 3, 8, bot);
                rect(g, x + 16, y + 19, 3, 3, bot);
            }
            case 11 -> { // terminal: a prompt
                rect(g, x + 8, y + 10, 2, 2, WH); rect(g, x + 10, y + 12, 2, 2, WH); rect(g, x + 12, y + 14, 2, 2, WH);
                rect(g, x + 10, y + 16, 2, 2, WH); rect(g, x + 8, y + 18, 2, 2, WH);
                rect(g, x + 15, y + 19, 8, 2, WH);
            }
            case 12 -> { // store: a play triangle
                for (int c = 0; c < 10; c++) {
                    int h = Math.round(16 - c * 1.5f);
                    rect(g, x + 12 + c, y + 16 - h / 2, 1, h, WH);
                }
            }
            case 13 -> { // jobs: a briefcase
                rect(g, x + 12, y + 7, 8, 2, WH); rect(g, x + 12, y + 7, 2, 5, WH); rect(g, x + 18, y + 7, 2, 5, WH);
                rect(g, x + 7, y + 11, 18, 14, WH);
                rect(g, x + 7, y + 17, 18, 1, mid);
                rect(g, x + 14, y + 16, 4, 3, bot);
            }
            case 15 -> { // CuteNet: two people joined by a signal arc
                disc(g, x + 11, y + 12, 4, WH); disc(g, x + 21, y + 12, 4, WH);
                disc(g, x + 11, y + 24, 6, WH); disc(g, x + 21, y + 24, 6, WH);
                rect(g, x + 5, y + 24, 22, 4, mid);
                rect(g, x + 5, y + 25, 22, 3, WH);
                for (int k = 0; k < 3; k++) rect(g, x + 14 + k, y + 6 + (k == 1 ? -1 : 0), 1, 2, 0xFFFFFFFF);
            }
            case 19 -> { // style: a little hanger with a bow
                rect(g, x + 15, y + 5, 2, 4, WH); rect(g, x + 17, y + 5, 3, 2, WH);
                for (int k = 0; k < 9; k++) { rect(g, x + 15 - k, y + 9 + k, 1, 2, WH); rect(g, x + 16 + k, y + 9 + k, 1, 2, WH); }
                rect(g, x + 6, y + 18, 20, 2, WH);
                rect(g, x + 14, y + 22, 4, 4, mid); rect(g, x + 11, y + 21, 3, 3, mid); rect(g, x + 18, y + 21, 3, 3, mid);
            }
            case 20 -> { // beats: a step grid with lit cells
                for (int r = 0; r < 3; r++) for (int c = 0; c < 4; c++) {
                    boolean on = (r * 5 + c * 3) % 4 < 2;
                    rect(g, x + 6 + c * 5, y + 8 + r * 6, 4, 5, on ? WH : mid);
                }
                rect(g, x + 6, y + 26, 19, 1, WH);
            }
            case 23 -> { // gift: a box with a bow
                rect(g, x + 7, y + 13, 18, 12, WH); rect(g, x + 6, y + 10, 20, 4, WH);
                rect(g, x + 15, y + 10, 2, 15, mid);
                rect(g, x + 10, y + 6, 6, 4, WH); rect(g, x + 16, y + 6, 6, 4, WH); rect(g, x + 14, y + 8, 4, 3, mid);
            }
            case 24 -> { // quiz: a question mark
                rect(g, x + 11, y + 7, 10, 3, WH); rect(g, x + 9, y + 9, 3, 5, WH); rect(g, x + 20, y + 9, 3, 6, WH);
                rect(g, x + 17, y + 14, 4, 3, WH); rect(g, x + 14, y + 17, 4, 4, WH); rect(g, x + 14, y + 23, 4, 3, WH);
            }
            case 25 -> { // tic-tac-toe: a grid with a cross and a ring
                rect(g, x + 12, y + 6, 2, 20, WH); rect(g, x + 18, y + 6, 2, 20, WH); rect(g, x + 6, y + 12, 20, 2, WH); rect(g, x + 6, y + 18, 20, 2, WH);
                rect(g, x + 7, y + 7, 4, 4, mid); disc(g, x + 16, y + 16, 2, mid);
            }
            case 26 -> { // wheel: a round wheel with spokes
                disc(g, x + 16, y + 16, 11, WH); disc(g, x + 16, y + 16, 9, mid);
                rect(g, x + 15, y + 6, 2, 20, WH); rect(g, x + 6, y + 15, 20, 2, WH); disc(g, x + 16, y + 16, 2, WH);
                rect(g, x + 14, y + 3, 4, 4, 0xFFE5486F);
            }
            case 28 -> { // photo: a camera
                rect(g, x + 6, y + 11, 20, 14, WH); rect(g, x + 11, y + 8, 6, 3, WH);
                disc(g, x + 16, y + 18, 5, mid); disc(g, x + 16, y + 18, 3, WH); rect(g, x + 22, y + 13, 2, 2, mid);
            }
            case 29 -> { // stickers: a star on a card
                rect(g, x + 7, y + 7, 18, 18, WH);
                rect(g, x + 15, y + 9, 2, 14, mid); rect(g, x + 9, y + 15, 14, 2, mid); rect(g, x + 12, y + 12, 8, 8, mid);
            }
            case 30 -> { // bank: a piggy bank
                disc(g, x + 15, y + 18, 9, WH); rect(g, x + 8, y + 9, 4, 4, WH); rect(g, x + 18, y + 9, 4, 4, WH);
                rect(g, x + 4, y + 17, 5, 5, WH); rect(g, x + 12, y + 8, 7, 2, mid); rect(g, x + 10, y + 24, 3, 3, WH); rect(g, x + 18, y + 24, 3, 3, WH);
                rect(g, x + 11, y + 15, 2, 2, mid);
            }
            case 31 -> { // wishlist: a star over lines
                rect(g, x + 14, y + 6, 4, 12, WH); rect(g, x + 10, y + 9, 12, 5, WH); rect(g, x + 12, y + 7, 8, 9, WH);
                rect(g, x + 8, y + 20, 16, 2, WH); rect(g, x + 8, y + 24, 12, 2, WH);
            }
            case 32 -> { // radio: a box with a dial and an antenna
                rect(g, x + 6, y + 12, 20, 14, WH); rect(g, x + 8, y + 14, 8, 10, mid); disc(g, x + 21, y + 19, 3, mid);
                rect(g, x + 20, y + 5, 1, 7, WH); rect(g, x + 14, y + 5, 7, 1, WH);
            }
            case 33 -> { // pet stats: a paw
                disc(g, x + 16, y + 21, 5, WH); disc(g, x + 9, y + 14, 2, WH); disc(g, x + 14, y + 10, 2, WH); disc(g, x + 19, y + 10, 2, WH); disc(g, x + 24, y + 14, 2, WH);
            }
            case 34 -> { // tales: an open book with a ribbon
                rect(g, x + 5, y + 9, 11, 15, WH); rect(g, x + 16, y + 9, 11, 15, WH);
                rect(g, x + 15, y + 8, 2, 17, mid);
                for (int k = 0; k < 3; k++) { rect(g, x + 7, y + 12 + k * 3, 7, 1, mid); rect(g, x + 18, y + 12 + k * 3, 7, 1, mid); }
                rect(g, x + 22, y + 9, 2, 7, 0xFFE5484D);
            }
            case 22 -> { // explorer: a folder with a tab
                rect(g, x + 6, y + 8, 10, 4, WH);
                rect(g, x + 6, y + 11, 20, 14, WH);
                rect(g, x + 8, y + 13, 16, 10, mid);
                rect(g, x + 8, y + 13, 16, 2, mix(top, bot, 0.2f));
            }
            case 21 -> { // season pass: a ticket with a star
                rect(g, x + 6, y + 9, 20, 14, WH);
                disc(g, x + 6, y + 16, 2, mid); disc(g, x + 26, y + 16, 2, mid);
                for (int k = 0; k < 4; k++) rect(g, x + 10, y + 11 + k * 3, 1, 2, mid);
                rect(g, x + 19, y + 12, 2, 8, mid); rect(g, x + 16, y + 15, 8, 2, mid);
                rect(g, x + 17, y + 13, 6, 6, mid); rect(g, x + 18, y + 14, 4, 4, WH);
            }
            case 18 -> { // fishing: a fish with a hook line
                rect(g, x + 22, y + 4, 1, 9, WH);
                rect(g, x + 20, y + 13, 3, 1, WH);
                for (int dy = -4; dy <= 4; dy++) { int dx = (int) Math.round(8 * Math.sqrt(1 - dy * dy / 17.0)); rect(g, x + 14 - dx, y + 21 + dy, dx * 2, 1, WH); }
                rect(g, x + 21, y + 17, 5, 1, WH); rect(g, x + 22, y + 21, 5, 1, WH); rect(g, x + 22, y + 18, 1, 3, WH);
                rect(g, x + 9, y + 19, 2, 2, mid);
            }
            case 17 -> { // farm: a sprout in a little field
                rect(g, x + 6, y + 22, 20, 6, 0xFF8A5A3A); rect(g, x + 6, y + 22, 20, 2, 0xFFB07A4A);
                rect(g, x + 15, y + 11, 2, 11, WH);
                rect(g, x + 8, y + 12, 7, 4, WH); rect(g, x + 17, y + 8, 7, 4, WH);
                disc(g, x + 25, y + 7, 2, 0xFFFFE070);
            }
            case 16 -> { // weather: a sun behind a cloud
                disc(g, x + 20, y + 11, 6, 0xFFFFE070);
                for (int k = 0; k < 8; k++) {
                    double ang = k * Math.PI / 4;
                    rect(g, x + 20 + (int) Math.round(Math.cos(ang) * 10), y + 11 + (int) Math.round(Math.sin(ang) * 10), 2, 2, 0xFFFFE070);
                }
                disc(g, x + 11, y + 21, 5, WH);
                disc(g, x + 17, y + 18, 6, WH);
                disc(g, x + 23, y + 22, 4, WH);
                rect(g, x + 8, y + 21, 17, 5, WH);
            }
            case 14 -> { // mail: an envelope
                rect(g, x + 6, y + 9, 20, 15, WH);
                for (int k = 0; k < 10; k++) { rect(g, x + 6 + k, y + 9 + k / 2, 1, 1, mid); rect(g, x + 25 - k, y + 9 + k / 2, 1, 1, mid); }
            }
            default -> { // paint: a palette
                disc(g, x + 16, y + 16, 11, WH);
                disc(g, x + 21, y + 22, 3, mid);
                disc(g, x + 10, y + 15, 2, 0xFFE5484D);
                disc(g, x + 15, y + 10, 2, 0xFFF3D46A);
                disc(g, x + 21, y + 12, 2, 0xFF5BBF6A);
                disc(g, x + 10, y + 21, 2, 0xFF2F7FD6);
            }
        }
    }

    /**
     * A game as an app icon: the same rounded glossy tile as every app, in the color of the game, with the little
     * picture of the game on it (the cover of CuteStore without its square background).
     */
    private static void drawGame(GuiGraphics g, String gameId, int x, int y) {
        int base = 0xFF000000 | Library.game(gameId).rgb();
        boolean dark = CoverArt.isDark(gameId);
        tile(g, x, y, dark ? mix(base, 0x000000, 0.55f) : mix(base, 0xFFFFFF, 0.4f), dark ? mix(base, 0x000000, 0.8f) : mix(base, 0x000000, 0.08f));
        CoverArt.glyph(g, gameId, x + 5, y + 5, 22);
    }

    private static ComputerColor colorOf(String gameId) {
        for (ComputerColor cc : ComputerColor.values()) if (cc.id.equals(gameId)) return cc;
        return null;
    }

    /** The app was shut down: forget its saved instance so it starts fresh next time. */
    public void forget(App a) {
        if (browser == a) browser = null;
        if (notes == a) notes = null;
        if (paint == a) paint = null;
        if (calc == a) calc = null;
        if (music == a) music = null;
        if (pet == a) pet = null;
        if (quest == a) quest = null;
        if (terminal == a) terminal = null;
        if (store == a) store = null;
        if (jobs == a) jobs = null;
        if (mail == a) mail = null;
        if (market == a) market = null;
        if (weather == a) weather = null;
    }

    /** Opens CuteStore on the page of one game. */
    public void openStore(String gameId) {
        if (store == null) store = new StoreApp();
        store.show(gameId);
        shell.open(store);
    }

    public void launch(int i) {
        if (Items.isFolder(i)) {
            if (Folders.exists(i)) shell.open(new FolderApp(i));
            return;
        }
        if (Items.isGame(i)) {
            String gid = Items.gameId(i);
            if (!Library.installed(gid)) { openStore(gid); return; }   // not bought / still installing: show its store page
            ComputerColor cc = colorOf(gid);
            shell.open(cc != null ? new GameApp(cc) : GameApp.extra(gid));
            return;
        }
        Library.Program prog = Library.programByIcon(i);
        if (prog != null && !Library.installed(prog.id())) {      // not installed: show its page in the store
            openStore(prog.id());
            return;
        }
        switch (i) {
            case 2 -> {
                if (browser == null) browser = new BrowserApp();
                shell.open(browser);
            }
            case 3 -> {
                if (notes == null) notes = new NotepadApp();
                shell.open(notes);
            }
            case 4 -> {
                if (paint == null) paint = new PaintApp();
                shell.open(paint);
            }
            case 5 -> {
                if (calc == null) calc = new CalcApp();
                shell.open(calc);
            }
            case 7 -> {
                if (music == null) music = new MusicApp();
                shell.open(music);
            }
            case 8 -> {
                if (pet == null) pet = new PetApp();
                shell.open(pet);
            }
            case 9 -> {
                if (market == null) market = new MarketApp();
                shell.open(market);
            }
            case 10 -> {
                if (quest == null) quest = new QuestApp();
                shell.open(quest);
            }
            case 11 -> {
                if (terminal == null) terminal = new TerminalApp();
                shell.open(terminal);
            }
            case 12 -> {
                if (store == null) store = new StoreApp();
                shell.open(store);
            }
            case 13 -> {
                if (jobs == null) jobs = new JobsApp();
                shell.open(jobs);
            }
            case 14 -> {
                if (mail == null) mail = new MailApp();
                shell.open(mail);
            }
            case 15 -> {
                if (net == null) net = new NetApp();
                shell.open(net);
            }
            case 16 -> {
                if (weather == null) weather = new WeatherApp();
                shell.open(weather);
            }
            case 17 -> {
                if (farm == null) farm = new FarmApp();
                shell.open(farm);
            }
            case 18 -> {
                if (fishing == null) fishing = new FishingApp();
                shell.open(fishing);
            }
            case 19 -> {
                if (style == null) style = new StyleApp();
                shell.open(style);
            }
            case 20 -> {
                if (beats == null) beats = new BeatApp();
                shell.open(beats);
            }
            case 21 -> {
                if (season == null) season = new SeasonApp();
                shell.open(season);
            }
            case 22 -> {
                if (explorer == null) explorer = new ExplorerApp();
                shell.open(explorer);
            }
            case 23 -> {
                if (gift == null) gift = new GiftApp();
                shell.open(gift);
            }
            case 24 -> {
                if (quiz == null) quiz = new QuizApp();
                shell.open(quiz);
            }
            case 25 -> {
                if (ttt == null) ttt = new TicTacApp();
                shell.open(ttt);
            }
            case 26 -> {
                if (wheel == null) wheel = new WheelApp();
                shell.open(wheel);
            }
            case 28 -> {
                if (photo == null) photo = new PhotoApp();
                shell.open(photo);
            }
            case 29 -> {
                if (stickers == null) stickers = new StickersApp();
                shell.open(stickers);
            }
            case 30 -> {
                if (bank == null) bank = new BankApp();
                shell.open(bank);
            }
            case 31 -> {
                if (wish == null) wish = new WishApp();
                shell.open(wish);
            }
            case 32 -> {
                if (radio == null) radio = new RadioApp();
                shell.open(radio);
            }
            case 33 -> {
                if (petstats == null) petstats = new PetStatsApp();
                shell.open(petstats);
            }
            case 34 -> {
                if (tales == null) tales = new TalesApp();
                shell.open(tales);
            }
            default -> shell.open(new SettingsApp());
        }
    }

    /** Red number on the Dock icon (0 = no badge). */
    public int badge(int i) {
        return i == 8 ? (Show.alertOn() ? 1 : 0) : i == 14 ? Mail.unreadCount() + Post.unreadCount() : i == 9 ? Market.readyCount() : i == 21 ? Math.min(99, Season.waiting()) : 0;
    }
}
