package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * CuteTube (cutetube.cute): a tiny video site that lives inside the browser.
 * <ul>
 *   <li>every "video" is a little animation drawn with rectangles (see the scene methods at the bottom);</li>
 *   <li>the sound is a looping note-block tune (same sounds as the Music app), or, for some videos, special sounds
 *       (rain, purring, slime squishes, lo-fi beats...) made of vanilla sound events;</li>
 *   <li>talking videos (news, weather, cooking, scary stories) type their text letter by letter and every letter
 *       "squeaks" with its own pitch, like the speech of Animal Crossing. The lines live in the lang files:
 *       {@code cutemod.tube.s.<video>.<line>};</li>
 *   <li>comments: a few ready-made ones per video + the ones you type yourself (kept until the game is closed).</li>
 * </ul>
 * The BrowserApp draws this app under its toolbar and forwards mouse / keyboard to it.
 */
public class TubeApp extends App {
    /** Height of the area the browser gives us (its toolbar is above). */
    public static final int TH = H - 20;
    /** Y of this area inside the app window (set by the browser, needed for scissor). */
    public int oy = 20;

    /**
     * 0-5 the first cute videos, 6 = the old horror, 7 news, 8 weather, 9 cooking, 10-11 ASMR, 12 lo-fi,
     * 13-14 scary stories. Spooky videos are only listed while Spooky is on (see ORDER).
     */
    private static final int COUNT = 21, HORROR = 6, STORY1 = 13, STORY2 = 14, CMT = 3;
    /** The order in the list; the last three (spooky) are hidden when Spooky is off. */
    private static final int[] ORDER = {0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 15, 16, 17, 18, 19, 20, HORROR, STORY1, STORY2};
    private static final int NICE = 18;

    private static final int[] LEN = {1800, 1500, 1200, 1800, 2100, 2400, 1800, 2520, 2100, 2520, 3000, 3000, 3600, 2940, 2940, 2700, 2400, 2400, 3000, 3150, 2700};   // video length in ticks (60 = 1 s)
    private static final int[] VIEWS = {1243, 987, 2210, 5001, 640, 8800, 1, 3120, 1840, 4275, 12040, 9300, 15800, 2, 3, 6800, 5200, 7400, 9100, 4300, 3900};
    private static final int[] LIKES = {120, 87, 301, 512, 64, 940, 666, 410, 220, 530, 1300, 870, 2100, 13, 31, 910, 740, 1020, 1280, 640, 550};
    private static final int[] UNIT = {14, 7, 6, 8, 10, 12, 10, 9, 12, 8, 1, 1, 1, 16, 16, 10, 12, 7, 1, 8, 12};                 // ticks per tune unit
    private static final int[] INSTR = {0, 0, 1, 3, 1, 3, 3, 0, 1, 3, 0, 0, 0, 1, 2, 0, 1, 3, 0, 3, 0};                       // 0 harp, 1 bell, 2 bass, 3 chime
    /** Which tick of a not-hovered video is shown as its thumbnail. */
    private static final int[] PREV = {50, 50, 50, 50, 50, 50, 700, 50, 50, 1700, 50, 66, 50, 1700, 2100, 1900, 500, 1050, 40, 2800, 400};
    /** Talking videos: how many lines they say, ticks per typed letter, voice pitch. 0 lines = no speech. */
    private static final int[] SL = {0, 0, 0, 0, 0, 0, 0, 6, 5, 6, 0, 0, 0, 7, 7, 6, 0, 0, 0, 7, 0};
    private static final int[] SPD = {1, 1, 1, 1, 1, 1, 1, 4, 4, 4, 1, 1, 1, 5, 5, 4, 1, 1, 1, 4, 1};
    private static final float[] VBASE = {1F, 1F, 1F, 1F, 1F, 1F, 1F, 1.1F, 0.8F, 1.35F, 1F, 1F, 1F, 0.55F, 0.6F, 0.7F, 1F, 1F, 1F, 1.15F, 1F};
    /** Tunes as {note, length} pairs (note 0..24, -1 = rest). They loop for the whole video. null = no tune (special sounds). */
    private static final int[][] TUNE = {
            {6, 1, 6, 1, 13, 1, 13, 1, 15, 1, 15, 1, 13, 2, 11, 1, 11, 1, 10, 1, 10, 1, 8, 1, 8, 1, 6, 2},
            {10, 2, 10, 2, 11, 2, 13, 2, 13, 2, 11, 2, 10, 2, 8, 2, 6, 2, 6, 2, 8, 2, 10, 2, 10, 3, 8, 1, 8, 4},
            {13, 1, 15, 1, 18, 2, 15, 1, 13, 1, 10, 2, 13, 1, 15, 1, 18, 2, 20, 4, 18, 1, 15, 1, 13, 2, 10, 4},
            {10, 6, 13, 2, 16, 6, 13, 2, 10, 4, 9, 4, 10, 8, -1, 8},
            {10, 3, 13, 3, 15, 2, 13, 4, 10, 3, 8, 3, 6, 2, 8, 4},
            {6, 6, 10, 6, 13, 6, 18, 10, 15, 6, 13, 6, 10, 6, 8, 10},
            {10, 4, 9, 4, -1, 2, 10, 4, 9, 4, -1, 2, 16, 2, 15, 2, 16, 2, 15, 2, -1, 12},   // horror: a creeping tritone
            {12, 1, 16, 1, 19, 2, 16, 1, 19, 1, 24, 2, 23, 1, 19, 1, 16, 2, 12, 4, -1, 4},   // news: a bright little jingle
            {10, 2, 13, 2, 17, 4, 15, 2, 13, 2, 12, 4, 10, 2, 13, 2, 15, 4, 13, 2, 10, 2, 8, 4},   // weather: gentle bells
            {13, 1, -1, 1, 13, 1, -1, 1, 17, 1, -1, 1, 20, 2, 18, 1, -1, 1, 18, 1, -1, 1, 15, 1, -1, 1, 13, 2},   // cooking: bouncy
            null,                                                                              // ASMR rain (own sounds)
            null,                                                                              // ASMR slime (own sounds)
            null,                                                                              // lo-fi (own chords and beat)
            {10, 2, 16, 2, 15, 2, 10, 2, 9, 2, 15, 2, 14, 2, 9, 2, -1, 4},                    // story 1: a wrong music box
            {1, 8, -1, 4, 0, 8, -1, 4, 3, 4, 2, 4, -1, 8},                                     // story 2: a low drone
            {13, 1, -1, 1, 13, 1, -1, 1, 15, 1, 13, 1, -1, 1, 10, 2, 13, 1, -1, 1, 17, 2, 15, 2},   // creeper's cooking disaster: a nervous bounce
            {8, 4, 10, 4, 13, 8, 10, 4, 8, 4, 6, 8, 8, 4, -1, 4},                              // counting sheep: a slow lullaby
            {10, 1, 13, 1, 17, 2, 15, 1, 17, 1, 20, 2, 18, 1, 20, 1, 22, 2, 20, 4, -1, 2},    // rocket bee: a hopeful march
            null,                                                                              // slime disco (own beat)
            {6, 2, -1, 2, 9, 2, -1, 2, 10, 2, 9, 2, 6, 4, -1, 2, 5, 2, -1, 2, 8, 2, -1, 2, 9, 4, -1, 4},   // detective: a sneaky walk
            {8, 4, 10, 4, 13, 4, 10, 4, 8, 8, -1, 4, 6, 4, 8, 8, -1, 4}                        // ice fishing: calm and cold
    };
    private static final int[] TOTAL = new int[COUNT];
    private static final boolean[] LIKED = new boolean[COUNT];
    private static final List<List<String>> MINE = new ArrayList<>();         // comments typed by the player
    private static final Random RND = new Random();

    static {
        for (int i = 0; i < COUNT; i++) {
            int sum = 0;
            if (TUNE[i] != null) for (int k = 1; k < TUNE[i].length; k += 2) sum += TUNE[i][k];
            TOTAL[i] = Math.max(1, sum * UNIT[i]);
            MINE.add(new ArrayList<>());
        }
    }

    private static boolean spooky(int v) { return v == HORROR || v == STORY1 || v == STORY2; }

    // ---------- layout ----------
    private static final int PX = 4, PY = 4, PW = 146, PH = 82;               // player screen
    private static final int BAR_Y = 89, BTN_Y = 98;                          // progress bar, button row
    private static final int VX = 102, VW = 46;                               // volume slider
    private static final int CX = 156, CY = 16, CW = 136, CH = 100;           // comments list
    private static final int[] HX = {30, 104, 18};                            // x of the floating hearts
    private static final int BW = PW - 16;                                    // width of the speech text

    private record CLine(FormattedCharSequence seq, int color, int y) {}

    private int view;                 // 0 = list of videos, 1 = watching, 2 = the LIVE stream
    private final TubeLive live = new TubeLive();
    private int vid, t, ticks;        // current video, its time in ticks, free-running clock
    private boolean playing, typing;
    private boolean thumb;            // true while a thumbnail of the list is drawn (no text, no speech)

    @Override
    public boolean busy() { return (view == 1 && playing) || view == 2; }
    private float vol = 0.6F;
    private String draft = "";
    private final List<CLine> cl = new ArrayList<>();
    private int cScroll, cH, cy, lScroll;   // comments scroll, comments height, wrap cursor, list scroll
    private int wv = -1, wn = -1;           // which speech line is wrapped in wl
    private List<String> wl = List.of();

    @Override
    public Component title() { return Component.translatable("cutemod.tube.title"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.tube.hint"); }

    @Override
    public void close() {
        playing = false;
        typing = false;
        if (view == 2) { live.close(); view = 0; }   // leaving the site ends the stream
    }

    private void openLive() {
        playing = false;
        typing = false;
        view = 2;
        live.open();
    }

    private void checkLive() {
        if (view == 2 && live.wantsLeave()) { live.close(); view = 0; }
    }

    // ---------- sound helpers (a sound event is either a SoundEvent or a Holder, depending on the sound) ----------
    private static SoundEvent sv(SoundEvent e) { return e; }

    private static SoundEvent sv(Holder<SoundEvent> h) { return h.value(); }

    /** One quiet sound of the video: the video's volume slider and the music volume of the Settings both count. */
    private void snd(SoundEvent e, float pitch, float v) {
        Sfx.musicNote(e, Math.max(0.5F, Math.min(2F, pitch)), v * vol);
    }

    // ---------- logic ----------
    @Override
    public void tick() {
        ticks++;
        if (view == 2) { live.tick(); checkLive(); return; }
        if (view == 1 && spooky(vid) && !Haunt.scary) { view = 0; playing = false; }   // Spooky was switched off
        if (view != 1 || !playing) return;
        music();
        fx();
        voiceTick();
        if (++t >= LEN[vid]) { t = LEN[vid]; playing = false; Progress.onVideoEnd(vid); }                 // video ended
    }

    /** The looping tune (and its bass). Talking videos play it quieter so the voice stays clear. */
    private void music() {
        int[] m = TUNE[vid];
        if (m == null) return;
        float mv = SL[vid] > 0 ? 0.55F : 1F;
        boolean dark = spooky(vid);
        int p = t % TOTAL[vid], at = 0;                  // where we are inside the looping tune
        for (int k = 0; k < m.length; k += 2) {
            if (at == p && m[k] >= 0) MusicApp.note(INSTR[vid], m[k], vol * 0.8F * mv);
            at += m[k + 1] * UNIT[vid];
        }
        int bar = UNIT[vid] * 4;
        if (p % bar == 0) MusicApp.note(2, (p / bar) % 2 == 0 ? (dark ? 1 : 6) : (dark ? 0 : 13), vol * mv);   // bass (a low heartbeat in the dark ones)
        if (vid == HORROR && t == 1440) stinger();                                       // the jump scare: a loud ugly chord
    }

    private void stinger() {
        float loud = Math.min(1F, vol + 0.3F);
        MusicApp.note(2, 0, loud);
        MusicApp.note(3, 23, loud);
        MusicApp.note(3, 24, loud);
        MusicApp.note(0, 1, loud);
    }

    /** Special sounds: rain, purring, slime, lo-fi and the sounds of the scary stories. */
    private void fx() {
        int k = t;
        switch (vid) {
            case 10 -> {                                                                  // ASMR: rain on the window, a purring cat
                if (k % 100 == 0) snd(sv(SoundEvents.WEATHER_RAIN), 1F, 0.3F);
                if (RND.nextInt(45) == 0) snd(sv(SoundEvents.POINTED_DRIPSTONE_DRIP_WATER), 1.2F + RND.nextFloat() * 0.7F, 0.3F);
                if (k % 240 == 120) snd(sv(SoundEvents.CAT_PURR), 1F, 0.55F);
            }
            case 11 -> {                                                                  // ASMR: poking a slime (same phase as the picture)
                int p = k % 120;
                if (p == 0 || p == 12 || p == 24) {
                    snd(sv(SoundEvents.NOTE_BLOCK_HAT), 1.4F + p / 40F, 0.35F);
                    snd(sv(SoundEvents.SLIME_SQUISH_SMALL), 1.3F + p / 60F, 0.3F);
                }
                if (p == 62) snd(sv(SoundEvents.SLIME_SQUISH_SMALL), 0.9F, 0.55F);       // the slow press
                if (p == 88) snd(sv(SoundEvents.SLIME_JUMP_SMALL), 1.2F, 0.4F);          // and the release
                if (p == 100) snd(sv(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP), 1.7F, 0.3F);
            }
            case 12 -> lofi(k);
            case 15 -> {                                                                  // creeper's soup: hissing, then the bang
                int slotLen = slot(15);
                if (k % 200 == 100 && k > 450) snd(sv(SoundEvents.CREEPER_PRIMED), 1.4F, 0.2F);
                if (k == 5 * slotLen + slotLen * 55 / 100) { snd(sv(SoundEvents.GENERIC_EXPLODE), 1F, 0.8F); stinger(); }
            }
            case 16 -> { if (k % 150 == 60) snd(sv(SoundEvents.SHEEP_AMBIENT), 1.2F, 0.35F); }   // a "baa" for every sheep
            case 17 -> {
                if (k >= 480 && k < 600 && k % 60 == 0) snd(sv(SoundEvents.NOTE_BLOCK_HAT), 1.6F, 0.4F);   // the countdown ticks
                if (k < 600 && k % 60 == 0) snd(sv(SoundEvents.NOTE_BLOCK_HAT), 1.2F, 0.25F);
                if (k == 600) snd(sv(SoundEvents.FIREWORK_ROCKET_LAUNCH), 0.8F, 0.7F);
                if (k > 600 && k < 840 && k % 20 == 0) snd(sv(SoundEvents.FIREWORK_ROCKET_BLAST), 0.6F, 0.2F);
                if (k == 1700) snd(sv(SoundEvents.AMETHYST_BLOCK_CHIME), 1.4F, 0.5F);
            }
            case 18 -> {                                                                  // the disco beat: kick, hats, snare and a bass line
                int b = k % 30;
                if (b == 0) snd(sv(SoundEvents.NOTE_BLOCK_BASEDRUM), 0.9F, 0.7F);
                if (b == 15) snd(sv(SoundEvents.NOTE_BLOCK_HAT), 1.5F, 0.3F);
                if (b == 0 && (k / 30) % 2 == 1) snd(sv(SoundEvents.NOTE_BLOCK_SNARE), 1F, 0.4F);
                int[] bass = {6, 6, 9, 6, 11, 9, 8, 6};
                if (b == 0) MusicApp.note(2, bass[(k / 30) % 8], vol * 0.9F);
                if (b == 15) MusicApp.note(0, 18 + (k / 30) % 4 * 2, vol * 0.35F);
                if (b == 0 && (k / 30) % 8 == 0) snd(sv(SoundEvents.SLIME_SQUISH), 1.2F, 0.3F);
            }
            case 19 -> {
                int slotLen = slot(19);
                if (k == 5 * slotLen) snd(sv(SoundEvents.NOTE_BLOCK_BELL), 1.6F, 0.6F);       // gotcha
                if (k == 6 * slotLen + 120) snd(sv(SoundEvents.GENERIC_EAT), 1F, 0.4F);
                if (k % 220 == 110) snd(sv(SoundEvents.FOX_SNIFF), 1F, 0.3F);
            }
            case 20 -> {
                int cyc = k % 450;
                if (cyc == 280) snd(sv(SoundEvents.FISHING_BOBBER_SPLASH), 1F, 0.5F);
                if (cyc == 380) snd(sv(SoundEvents.FISHING_BOBBER_RETRIEVE), 1F, 0.5F);
                if (cyc == 400) snd(sv((k / 450) % 3 == 2 ? SoundEvents.NOTE_BLOCK_CHIME.value() : SoundEvents.NOTE_BLOCK_BASS.value()), (k / 450) % 3 == 2 ? 1.6F : 0.7F, 0.5F);
                if (k % 300 == 150) snd(sv(SoundEvents.POWDER_SNOW_STEP), 1F, 0.25F);
            }
            case STORY1 -> {
                if (k % 600 == 0) snd(sv(SoundEvents.AMBIENT_CAVE), 0.8F, 0.5F);
                if (k == 1260) snd(sv(SoundEvents.WOODEN_DOOR_CLOSE), 0.6F, 0.6F);
                if (k == 2760) stinger();
            }
            case STORY2 -> {
                if (k % 700 == 0) snd(sv(SoundEvents.AMBIENT_CAVE), 0.7F, 0.5F);
                if (k % 140 == 70 && RND.nextInt(2) == 0) snd(sv(SoundEvents.POINTED_DRIPSTONE_DRIP_WATER), 0.8F + RND.nextFloat() * 0.3F, 0.4F);
                if (k >= 1500 && k % 40 == 0) snd(sv(SoundEvents.NOTE_BLOCK_BASEDRUM), 0.6F, Math.min(0.8F, 0.25F + (k - 1500) / 2200F));   // footsteps, closer and closer
                if (k >= 2300 && k % 60 == 0) snd(sv(SoundEvents.WARDEN_HEARTBEAT), 1F, 0.5F);
                if (k == 2760) stinger();
            }
            default -> { }
        }
    }

    /** Lo-fi: four soft chords (a slow arpeggio), a bass, a sleepy beat and some vinyl crackle. */
    private void lofi(int k) {
        int[][] ch = {{12, 16, 19, 23}, {9, 12, 16, 19}, {14, 17, 21, 24}, {7, 11, 14, 17}};
        int[] root = {0, 9, 2, 7};
        int[] pat = {0, 1, 2, 3, 2, 1, 3, 2};
        int b = k % 240, c = (k / 240) % 4;
        if (b % 30 == 0) MusicApp.note(0, ch[c][pat[b / 30]], vol * 0.4F);
        if (b == 0 || b == 120) MusicApp.note(2, root[c], vol * 0.8F);
        if (b == 0 || b == 120) snd(sv(SoundEvents.NOTE_BLOCK_BASEDRUM), 0.9F, 0.5F);
        if (b == 60 || b == 180) snd(sv(SoundEvents.NOTE_BLOCK_SNARE), 1F, 0.22F);
        if (b % 60 == 34) snd(sv(SoundEvents.NOTE_BLOCK_HAT), 1.2F, 0.16F);
        if (RND.nextInt(25) == 0) snd(sv(SoundEvents.UI_BUTTON_CLICK), 2F, 0.06F);        // vinyl crackle
    }

    // ---------- speech ----------
    private int slot(int v) { return LEN[v] / SL[v]; }

    private int lineAt(int v, int tm) { return Math.min(SL[v] - 1, tm / slot(v)); }

    /** The speech line n of video v, wrapped to the bubble width (cached: it is asked every frame). */
    private List<String> wrapped(int v, int n) {
        if (v != wv || n != wn) {
            wv = v;
            wn = n;
            wl = new ArrayList<>();
            for (FormattedText ft : font().getSplitter().splitLines(t("cutemod.tube.s." + v + "." + n), BW, Style.EMPTY)) wl.add(ft.getString());
        }
        return wl;
    }

    private static int total(List<String> ls) {
        int s = 0;
        for (String l : ls) s += l.length();
        return s;
    }

    /** How many letters of the current line are typed at time tm. */
    private int typed(int v, int tm) {
        int n = lineAt(v, tm);
        return Math.min(total(wrapped(v, n)), (tm - n * slot(v)) / SPD[v]);
    }

    private boolean talking(int v, int tm) {
        if (thumb) return (tm / 5) % 3 != 0;
        int n = lineAt(v, tm);
        return typed(v, tm) < total(wrapped(v, n)) && (tm / 4) % 2 == 0;
    }

    /** Plays a squeak for every newly typed letter (not for spaces and punctuation). */
    private void voiceTick() {
        if (SL[vid] == 0) return;
        int n0 = lineAt(vid, t), n1 = lineAt(vid, t + 1);
        int k0 = typed(vid, t), k1 = typed(vid, t + 1);
        if (n0 != n1 || k1 <= k0) return;
        int idx = k1 - 1;
        char c = ' ';
        for (String s : wrapped(vid, n1)) {
            if (idx < s.length()) { c = s.charAt(idx); break; }
            idx -= s.length();
        }
        voice(c);
    }

    /** The letter decides the note: vowels are lower and rounder, consonants higher (a bit random, like a real animal). */
    private void voice(char c) {
        if (!Character.isLetterOrDigit(c)) return;
        char l = Character.toLowerCase(c);
        boolean vowel = "аеёиоуыэюяaeiouy".indexOf(l) >= 0;
        int k = (l * 7 + (l >> 3)) % 9;
        double semi = vowel ? k % 4 : 3 + k % 6;
        float pitch = (float) (VBASE[vid] * Math.pow(2, semi / 12.0) * (0.97 + RND.nextFloat() * 0.06));
        boolean dark = spooky(vid);
        snd(dark ? sv(SoundEvents.NOTE_BLOCK_DIDGERIDOO) : sv(SoundEvents.NOTE_BLOCK_BIT), pitch, dark ? 0.55F : 0.4F);
    }

    private void watch(int i) {
        vid = i;
        t = 0;
        playing = true;
        view = 1;
        typing = false;
        draft = "";
        cScroll = 0;
        wv = -1;
        buildComments();
    }

    private void toggle() {
        if (!playing && t >= LEN[vid]) t = 0;            // replay
        playing = !playing;
    }

    private void seek(int x) { t = Math.max(0, Math.min(LEN[vid] - 1, (x - PX) * LEN[vid] / PW)); }

    private void setVol(int x) { vol = Math.max(0.05F, Math.min(1F, (x - VX) / (float) VW)); }

    private void send() {
        String s = draft.trim();
        if (s.isEmpty()) return;
        MINE.get(vid).add(s);
        draft = "";
        cScroll = 0;
        buildComments();
        MusicApp.note(1, 18, 0.8F);
    }

    // ---------- comments ----------
    private int commentCount() { return CMT + MINE.get(vid).size(); }

    private int maxC() { return Math.max(0, cH - CH); }

    private void addComment(String text, int color) {
        for (FormattedCharSequence s : font().split(FormattedText.of(text), CW - 8)) {
            cl.add(new CLine(s, color, cy));
            cy += 9;
        }
        cy += 4;
    }

    /** Wrap all comments of the current video into lines (the player's own come first). */
    private void buildComments() {
        cl.clear();
        cy = 2;
        String name = Minecraft.getInstance().getUser().getName();
        String me = "@" + name + ": ";
        List<String> mine = MINE.get(vid);
        for (int k = mine.size() - 1; k >= 0; k--) addComment(me + mine.get(k), 0xFFB5427A);
        for (int k = 0; k < CMT; k++) addComment(t("cutemod.tube.c." + vid + "." + k, name), 0xFF3A2A3A);
        cH = cy;
        cScroll = Math.min(cScroll, maxC());
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Skin.rect(g, 0, 0, W, TH, 0xFFF3F4FA);
        if (view == 0) renderList(g, mx, my);
        else if (view == 1) renderWatch(g, mx, my);
        else live.render(g, mx, my, shell.absX(), shell.absY() + oy);
    }

    private static String clock(int ticks) {
        int s = ticks / 60;
        return s / 60 + ":" + (s % 60 < 10 ? "0" : "") + s % 60;
    }

    private static void heart(GuiGraphics g, int x, int y, int col) {
        Skin.rect(g, x + 1, y, 2, 1, col);
        Skin.rect(g, x + 4, y, 2, 1, col);
        Skin.rect(g, x, y + 1, 7, 1, col);
        Skin.rect(g, x + 1, y + 2, 5, 1, col);
        Skin.rect(g, x + 2, y + 3, 3, 1, col);
        Skin.rect(g, x + 3, y + 4, 1, 1, col);
    }

    private void button(GuiGraphics g, int mx, int my, int x, int y, int w, String s) {
        roundRect(g, x, y, w, 14, 6, in(mx, my, x, y, w, 14) ? 0xFFDDE2F3 : 0xFFEEF0F8);
        Skin.str(g, font(), s, x + (w - font().width(s)) / 2, y + 3, 0xFF3A2A3A, false);
    }

    private int shown() { return Haunt.scary ? COUNT : NICE; }

    private int listMax() { return Math.max(0, 19 + (shown() + 1) / 2 * 42 - TH); }

    private void renderList(GuiGraphics g, int mx, int my) {
        lScroll = Math.min(lScroll, listMax());
        Skin.rect(g, 0, 0, W, 16, 0xFFFFFFFF);                                    // a white header with a thin line
        Skin.rect(g, 0, 16, W, 1, 0xFFE4E6EE);
        roundRect(g, 6, 3, 20, 11, 4, 0xFFE02A2A);                                   // logo: red button with a play triangle
        for (int k = 0; k < 4; k++) Skin.rect(g, 13 + k, 5 + k, 1, 7 - 2 * k, 0xFFFFFFFF);
        Skin.str(g, font(), t("cutemod.tube.title"), 30, 4, 0xFF3A2A3A, false);
        boolean liveHover = my < 16 && in(mx, my, W - 52, 3, 46, 11);                // the red LIVE button
        roundRect(g, W - 52, 3, 46, 11, 4, liveHover ? 0xFFFF5A5A : 0xFFE02A2A);
        if ((ticks / 30) % 2 == 0) Skin.disc(g, W - 45, 8, 2, 0xFFFFFFFF);
        Skin.str(g, font(), t("cutemod.live.tab"), W - 39, 4, 0xFFFFFFFF, false);

        g.enableScissor(shell.absX(), shell.absY() + oy + 17, shell.absX() + W, shell.absY() + oy + TH);
        for (int i = 0; i < shown(); i++) {
            int v = ORDER[i];
            int x = 3 + (i % 2) * 148, y = 19 + (i / 2) * 42 - lScroll;
            if (y < -40 || y > TH) continue;
            boolean hover = my >= 17 && in(mx, my, x, y, 146, 40);
            roundRect(g, x, y, 146, 40, 5, hover ? 0xFFF4A3B5 : 0xFFE6E8F0);          // a card with a thin edge
            roundRect(g, x + 1, y + 1, 144, 38, 5, 0xFFFFFFFF);
            g.pose().pushPose();                                              // thumbnail = the scene, scaled down
            g.pose().translate(x + 2, y + 3, 0);
            g.pose().scale(0.41F, 0.41F, 1F);
            thumb = true;
            scene(g, v, hover ? ticks % LEN[v] : PREV[v]);                    // hover = the preview moves
            thumb = false;
            g.pose().popPose();
            String len = clock(LEN[v]);
            int lw = font().width(len);
            roundRect(g, x + 61 - lw - 3, y + 26, lw + 3, 9, 2, 0xCC000000);
            Skin.str(g, font(), len, x + 61 - lw - 1, y + 27, 0xFFFFFFFF, false);

            List<FormattedCharSequence> tl = font().split(FormattedText.of(t("cutemod.tube.v." + v)), 78);
            for (int l = 0; l < tl.size() && l < 2; l++) Skin.str(g, font(), tl.get(l), x + 66, y + 3 + l * 9, 0xFF3A2A3A, false);
            Skin.disc(g, x + 70, y + 26, 4, 0xFF000000 | java.awt.Color.HSBtoRGB(v * 0.17F % 1F, 0.5F, 0.9F));   // the channel avatar
            Skin.str(g, font(), font().plainSubstrByWidth(t("cutemod.tube.ch." + v), 62), x + 77, y + 22, 0xFF8A7AA8, false);
            Skin.str(g, font(), t("cutemod.tube.views", VIEWS[v]), x + 66, y + 31, 0xFF8A7AA8, false);
        }
        g.disableScissor();
        if (listMax() > 0) {                                                  // scrollbar
            Skin.rect(g, W - 3, 17, 2, TH - 17, 0xFFE9DDF2);
            int th = Math.max(12, (TH - 17) * (TH - 17) / (TH - 17 + listMax()));
            Skin.rect(g, W - 3, 17 + (TH - 17 - th) * lScroll / listMax(), 2, th, 0xFFB57BD6);
        }
    }

    private void renderWatch(GuiGraphics g, int mx, int my) {
        // two white cards: the video and the comments
        roundRect(g, 1, 1, PX + PW, 144, 6, 0xFFFFFFFF);
        roundRect(g, CX - 3, 1, W - CX + 1, 144, 6, 0xFFFFFFFF);
        // player
        roundRect(g, PX - 1, PY - 1, PW + 2, PH + 2, 3, 0xFF3A2A3A);
        g.enableScissor(shell.absX() + PX, shell.absY() + oy + PY, shell.absX() + PX + PW, shell.absY() + oy + PY + PH);
        g.pose().pushPose();
        g.pose().translate(PX, PY, 0);
        scene(g, vid, t);
        if (!playing) {                                                       // big "play" sign when paused / ended
            Skin.disc(g, 73, 41, 11, 0xAA000000);
            for (int k = 0; k < 6; k++) Skin.rect(g, 69 + k, 35 + k, 1, 12 - 2 * k, 0xFFFFFFFF);
        }
        g.pose().popPose();
        g.disableScissor();

        // progress bar
        int fill = PW * t / LEN[vid];
        roundRect(g, PX, BAR_Y, PW, 4, 2, 0xFFE3E6F0);
        if (fill > 0) roundRect(g, PX, BAR_Y, Math.max(4, fill), 4, 2, 0xFFE02A2A);
        Skin.disc(g, PX + fill, BAR_Y + 2, 3, 0xFFE02A2A);

        // buttons: play/pause, back to the list, like, volume
        button(g, mx, my, PX, BTN_Y, 22, playing ? "||" : ">");
        button(g, mx, my, PX + 25, BTN_Y, 20, "<");
        boolean lk = LIKED[vid];
        roundRect(g, PX + 48, BTN_Y, 44, 14, 6, lk ? 0xFFF9C6DA : (in(mx, my, PX + 48, BTN_Y, 44, 14) ? 0xFFDDE2F3 : 0xFFEEF0F8));
        heart(g, PX + 53, BTN_Y + 4, lk ? 0xFFE02A2A : 0xFF8A7AA8);
        Skin.str(g, font(), String.valueOf(LIKES[vid] + (lk ? 1 : 0)), PX + 63, BTN_Y + 3, 0xFF3A2A3A, false);
        roundRect(g, VX, BTN_Y + 5, VW, 4, 2, 0xFFE3E6F0);
        roundRect(g, VX, BTN_Y + 5, Math.max(4, (int) (VW * vol)), 4, 2, 0xFFB57BD6);
        Skin.disc(g, VX + (int) (VW * vol), BTN_Y + 7, 3, 0xFFB57BD6);

        // info
        Skin.str(g, font(), font().plainSubstrByWidth(t("cutemod.tube.v." + vid), PW), PX, 116, 0xFF3A2A3A, false);
        Skin.str(g, font(), t("cutemod.tube.ch." + vid) + "  -  " + t("cutemod.tube.views", VIEWS[vid]), PX, 126, 0xFF8A7AA8, false);
        Skin.str(g, font(), clock(t) + " / " + clock(LEN[vid]), PX, 135, 0xFF8A7AA8, false);

        // comments
        Skin.str(g, font(), t("cutemod.tube.comments", commentCount()), CX, 4, 0xFF3A2A3A, false);
        Skin.rect(g, CX, CY - 2, CW, 1, 0xFFE0D4EA);
        g.enableScissor(shell.absX() + CX, shell.absY() + oy + CY, shell.absX() + CX + CW, shell.absY() + oy + CY + CH);
        for (CLine l : cl) {
            int y = CY + l.y() - cScroll;
            if (y < CY - 10 || y > CY + CH) continue;
            Skin.str(g, font(), l.seq(), CX + 2, y, l.color(), false);
        }
        g.disableScissor();
        if (cH > CH) {
            Skin.rect(g, CX + CW + 1, CY, 3, CH, 0xFFE9DDF2);
            int th = Math.max(12, CH * CH / cH);
            Skin.rect(g, CX + CW + 1, CY + (CH - th) * cScroll / maxC(), 3, th, 0xFFB57BD6);
        }

        // comment box
        roundRect(g, CX - 1, 119, CW + 2, 18, 8, typing ? 0xFF4A7BD0 : 0xFFD3D8E6);
        roundRect(g, CX, 120, CW, 16, 8, 0xFFFFFFFF);
        String shown = draft.isEmpty() && !typing ? t("cutemod.tube.add") : draft;
        while (shown.length() > 1 && font().width(shown) > CW - 8) shown = shown.substring(1);
        Skin.str(g, font(), shown, CX + 4, 124, draft.isEmpty() && !typing ? 0xFF9A8FA8 : 0xFF3A2A3A, false);
        if (typing && (ticks / 30) % 2 == 0) Skin.rect(g, CX + 4 + font().width(shown), 123, 1, 10, 0xFF3A2A3A);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (view == 2) { live.click(x, y, button); checkLive(); return true; }
        if (view == 0 && y < 16 && in(x, y, W - 52, 3, 46, 11)) { openLive(); return true; }
        if (view == 0) {
            for (int i = 0; i < shown(); i++) {
                if (y >= 17 && in(x, y, 3 + (i % 2) * 148, 19 + (i / 2) * 42 - lScroll, 146, 40)) { watch(ORDER[i]); return true; }
            }
            return true;
        }
        typing = false;
        if (in(x, y, CX - 1, 119, CW + 2, 18)) { typing = true; return true; }
        if (in(x, y, PX, PY, PW, PH) || in(x, y, PX, BTN_Y, 22, 14)) { toggle(); return true; }
        if (in(x, y, PX, BAR_Y - 3, PW, 10)) { seek(x); return true; }
        if (in(x, y, PX + 25, BTN_Y, 20, 14)) { playing = false; view = 0; return true; }
        if (in(x, y, PX + 48, BTN_Y, 44, 14)) {
            LIKED[vid] = !LIKED[vid];
            if (LIKED[vid]) MusicApp.note(3, 22, 0.8F);
            return true;
        }
        if (in(x, y, VX - 3, BTN_Y, VW + 6, 14)) { setVol(x); return true; }
        return true;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (view == 2) return live.drag(x, y, button);
        if (view != 1) return false;
        if (in(x, y, PX - 6, BAR_Y - 8, PW + 12, 20)) { seek(x); return true; }
        if (in(x, y, VX - 8, BTN_Y - 4, VW + 16, 22)) { setVol(x); return true; }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (view == 2) { boolean r = live.key(keyCode, modifiers); checkLive(); return r; }
        if (view == 0) return false;
        if (typing) {
            switch (keyCode) {
                case 257, 335 -> send();                                      // enter
                case 256 -> typing = false;                                   // escape: leave the box only
                case 259 -> { if (!draft.isEmpty()) draft = draft.substring(0, draft.length() - 1); }
                case 86 -> {                                                  // ctrl+v
                    if (!Screen.hasControlDown()) return false;
                    String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                    if (clip != null) {
                        String s = draft + clip.replace("\n", " ").replace("\r", "");
                        draft = s.length() > 80 ? s.substring(0, 80) : s;
                    }
                }
                default -> { return false; }
            }
            return true;
        }
        switch (keyCode) {
            case 32 -> toggle();                                              // space
            case 262 -> t = Math.min(LEN[vid] - 1, t + 300);                  // right: +5 s
            case 263 -> t = Math.max(0, t - 300);                             // left: -5 s
            case 256 -> { playing = false; view = 0; }                        // escape: back to the list
            default -> { return false; }
        }
        return true;
    }

    @Override
    public boolean charTyped(char c) {
        if (view == 2) return live.charTyped(c);
        if (view != 1 || !typing || c < 32 || c == 127) return false;
        if (draft.length() < 80) draft += c;
        return true;
    }

    @Override
    public boolean scroll(double amount) {
        if (view == 2) return live.scroll(amount);
        if (view == 0) {
            lScroll = Math.max(0, Math.min(listMax(), lScroll - (int) Math.round(amount * 14)));
            return true;
        }
        if (view != 1) return false;
        cScroll = Math.max(0, Math.min(maxC(), cScroll - (int) Math.round(amount * 14)));
        return true;
    }

    // ---------- the "videos": every scene is drawn on a 146 x 82 screen, tm = time in ticks ----------
    private void scene(GuiGraphics g, int v, int tm) {
        switch (v) {
            case 0 -> panda(g, tm);
            case 1 -> slime(g, tm);
            case 2 -> bee(g, tm);
            case 3 -> creeper(g, tm);
            case 4 -> ocean(g, tm);
            case HORROR -> horror(g, Math.min(tm, LEN[HORROR] - 1));
            case 7 -> news(g, tm);
            case 8 -> weather(g, tm);
            case 9 -> cooking(g, tm);
            case 10 -> rainCat(g, tm);
            case 11 -> slimeAsmr(g, tm);
            case 12 -> lofiRoom(g, tm);
            case 15 -> creeperCook(g, tm);
            case 16 -> sheep(g, tm);
            case 17 -> rocketBee(g, tm);
            case 18 -> slimeDisco(g, tm);
            case 19 -> detective(g, tm);
            case 20 -> iceFishing(g, tm);
            case STORY1 -> village(g, Math.min(tm, LEN[STORY1] - 1));
            case STORY2 -> mine(g, Math.min(tm, LEN[STORY2] - 1));
            default -> night(g, tm);
        }
    }

    private void panda(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFFFFD6E8, 0xFFFFB3D1);
        Skin.rect(g, 0, 66, PW, 16, 0xFF9AD6A0);
        int hop = (int) Math.round(Math.abs(Math.sin((tm % 28) * Math.PI / 28)) * 12);   // jumps on the beat
        int cx = 73 + (int) Math.round(Math.sin(tm / 45.0) * 34), y = 56 - hop;
        int arm = (tm / 14) % 2 == 0 ? -4 : 4;
        Skin.rect(g, cx - 9, 66, 18, 2, 0x33000000);                                          // shadow
        Skin.disc(g, cx - 14, y - 2 + arm, 4, 0xFF222222);                                    // arms
        Skin.disc(g, cx + 14, y - 2 - arm, 4, 0xFF222222);
        Skin.disc(g, cx - 7, y + 10, 4, 0xFF222222);                                          // legs
        Skin.disc(g, cx + 7, y + 10, 4, 0xFF222222);
        Skin.disc(g, cx, y, 12, 0xFFFFFFFF);                                                  // body
        Skin.disc(g, cx, y - 15, 10, 0xFFFFFFFF);                                             // head
        Skin.disc(g, cx - 8, y - 23, 4, 0xFF222222);                                          // ears
        Skin.disc(g, cx + 8, y - 23, 4, 0xFF222222);
        Skin.disc(g, cx - 4, y - 15, 3, 0xFF222222);                                          // eyes
        Skin.disc(g, cx + 4, y - 15, 3, 0xFF222222);
        Skin.rect(g, cx - 4, y - 16, 1, 1, 0xFFFFFFFF);
        Skin.rect(g, cx + 4, y - 16, 1, 1, 0xFFFFFFFF);
        Skin.rect(g, cx - 1, y - 11, 3, 2, 0xFF222222);                                       // nose
    }

    private void slime(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFFBFE6FF, 0xFFE8F6FF);
        Skin.rect(g, 0, 66, PW, 16, 0xFF6FBF73);
        int h = (int) Math.round(Math.sin((tm % 40) / 40.0 * Math.PI) * 32);             // height above the ground
        boolean squash = h < 4;
        int w = squash ? 30 : 22, hh = squash ? 12 : 22;
        int cx = 73 + (int) Math.round(Math.sin(tm / 50.0) * 40), top = 66 - h - hh;
        Skin.rect(g, cx - (24 - h / 2) / 2, 66, 24 - h / 2, 2, 0x44000000);                   // shadow
        Skin.rect(g, cx - w / 2, top, w, hh, 0xFF5BBF6A);
        Skin.rect(g, cx - w / 2 + 2, top + 2, w - 4, 3, 0x66FFFFFF);
        Skin.rect(g, cx - 6, top + hh / 2 - 2, 3, 4, 0xFF1B3A1B);
        Skin.rect(g, cx + 3, top + hh / 2 - 2, 3, 4, 0xFF1B3A1B);
    }

    private void bee(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFFBFE6FF, 0xFFFFF3B0);
        for (int k = 0; k < 6; k++) {                                                    // flowers
            int fx = 12 + k * 24, fh = 14 + (k * 7) % 10;
            Skin.rect(g, fx, PH - fh, 2, fh, 0xFF4CAF50);
            Skin.disc(g, fx + 1, PH - fh - 2, 5, k % 3 == 0 ? 0xFFF58FB8 : k % 3 == 1 ? 0xFFFFFFFF : 0xFFB57BD6);
            Skin.disc(g, fx + 1, PH - fh - 2, 2, 0xFFF3D46A);
        }
        int bx = 73 + (int) Math.round(Math.sin(tm / 30.0) * 52);
        int by = 28 + (int) Math.round(Math.sin(tm / 11.0) * 12), flap = (tm / 3) % 2;
        Skin.rect(g, bx + 1, by - 3 - flap * 2, 5, 4, 0xDDFFFFFF);                            // wings
        Skin.rect(g, bx + 8, by - 3 - flap * 2, 5, 4, 0xDDFFFFFF);
        Skin.rect(g, bx, by, 14, 9, 0xFFF5C518);                                              // body
        Skin.rect(g, bx + 4, by, 2, 9, 0xFF2A2A2A);
        Skin.rect(g, bx + 8, by, 2, 9, 0xFF2A2A2A);
        Skin.rect(g, bx + 11, by + 2, 2, 2, 0xFF2A2A2A);
    }

    private void creeper(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFF1E3A2A, 0xFF3A6A4A);
        Skin.rect(g, 0, 70, PW, 12, 0xFF2A4A2A);
        int cx = 73, p = tm % 240;
        Skin.rect(g, cx - 9, 56, 8, 14, 0xFF4CAF50);                                          // legs
        Skin.rect(g, cx + 1, 56, 8, 14, 0xFF4CAF50);
        Skin.rect(g, cx - 8, 34, 16, 22, 0xFF4CAF50);                                         // body
        Skin.rect(g, cx - 11, 12, 22, 22, 0xFF5BBF6A);                                        // head
        Skin.rect(g, cx - 7, 17, 5, 5, 0xFF1B3A1B);                                           // face
        Skin.rect(g, cx + 2, 17, 5, 5, 0xFF1B3A1B);
        Skin.rect(g, cx - 2, 23, 4, 4, 0xFF1B3A1B);
        Skin.rect(g, cx - 4, 27, 2, 4, 0xFF1B3A1B);
        Skin.rect(g, cx + 2, 27, 2, 4, 0xFF1B3A1B);
        if (p >= 120 && p < 132 && (p / 3) % 2 == 0) Skin.rect(g, cx - 11, 12, 22, 58, 0x99FFFFFF);   // "ssss..."
        if (p >= 132) {                                                                  // ...and then: a hug, hearts fly up
            for (int k = 0; k < 3; k++) {
                int a = p - 132 - k * 8, hy = 46 - a * 2 / 5;
                if (a >= 0 && hy > 0) heart(g, HX[k], hy, 0xFFF58FB8);
            }
        }
    }

    private void ocean(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, 46, 0xFFFFC98A, 0xFFFFE9B8);
        Skin.disc(g, 110, 30, 10, 0xFFFFF3B0);
        Skin.rect(g, 0, 46, PW, 36, 0xFF2F7FD6);
        for (int x = 0; x < PW; x += 6) {                                                // waves
            Skin.rect(g, x, 44 + (int) Math.round(Math.sin((x + tm) / 9.0) * 2), 6, 3, 0xFF5BA8F0);
        }
        for (int k = 0; k < 3; k++) Skin.rect(g, (k * 53 + tm / 2) % PW, 58 + k * 8, 14, 1, 0x55FFFFFF);
        double u = (tm % 140) / 140.0;                                                   // a fish jumps out of the water
        int fx = 14 + (int) (u * 118), fy = 46 - (int) Math.round(Math.sin(u * Math.PI) * 32);
        if (fy < 44) {
            Skin.rect(g, fx, fy, 12, 6, 0xFFFF9F43);
            Skin.rect(g, fx - 4, fy + 1, 4, 4, 0xFFFF7A1A);
            Skin.rect(g, fx + 9, fy + 1, 1, 1, 0xFF3A2A3A);
        }
    }

    private void night(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFF0B1030, 0xFF26306A);
        for (int k = 0; k < 28; k++) {                                                   // twinkling stars
            int b = (tm / 12 + k) % 4;
            Skin.rect(g, (k * 37 + 11) % 144, (k * 53 + 7) % 56, b == 0 ? 2 : 1, b == 0 ? 2 : 1, b == 3 ? 0x66FFFFFF : 0xFFFFFFFF);
        }
        Skin.disc(g, 112, 20, 9, 0xFFFFF3B0);                                                 // moon
        Skin.disc(g, 109, 17, 2, 0xFFE8D98A);
        Skin.disc(g, 115, 23, 2, 0xFFE8D98A);
        int s = tm % 300;                                                                // shooting star
        if (s < 30) for (int k = 0; k < 8; k++) Skin.rect(g, 20 + s * 3 - k * 2, 8 + s - k, 2, 1, ((255 - k * 30) << 24) | 0xFFFFFF);
        Skin.rect(g, 0, 68, PW, 14, 0xFF05071A);                                              // hills
        Skin.disc(g, 30, 70, 14, 0xFF05071A);
        Skin.disc(g, 100, 72, 18, 0xFF05071A);
    }

    /** A figure in dark purple with too-long arms. Origin = its feet. */
    private void figure(GuiGraphics g, int cx, int by, float sc, int tm, boolean grin) {
        figure(g, cx, by, sc, tm, grin, true);
    }

    /** Same, with a choice: eyes = false turns its back to us. */
    private void figure(GuiGraphics g, int cx, int by, float sc, int tm, boolean grin, boolean eyes) {
        g.pose().pushPose();
        g.pose().translate(cx, by, 0);
        g.pose().scale(sc, sc, 1F);
        int c = 0xFF1C1424;
        Skin.rect(g, -4, -34, 8, 26, c);                                                      // body
        Skin.rect(g, -4, -8, 3, 8, c);                                                        // legs
        Skin.rect(g, 1, -8, 3, 8, c);
        Skin.rect(g, -8, -33, 2, 28, c);                                                      // arms
        Skin.rect(g, 6, -33, 2, 28, c);
        Skin.disc(g, 0, -38, 5, c);                                                           // head
        if (eyes && tm % 90 < 80) {                                                      // white eyes, they blink
            Skin.rect(g, -3, -39, 2, 1, 0xFFFFFFFF);
            Skin.rect(g, 1, -39, 2, 1, 0xFFFFFFFF);
        }
        if (grin) Skin.rect(g, -3, -35, 6, 1, 0xFFFFFFFF);
        g.pose().popPose();
    }

    private static void eyes(GuiGraphics g, int x, int y, boolean open) {
        Skin.rect(g, x - 2, y - 2, 22, 7, 0x33FF0000);
        if (open) {
            Skin.rect(g, x, y, 6, 3, 0xFFFF2A2A);
            Skin.rect(g, x + 12, y, 6, 3, 0xFFFF2A2A);
            Skin.rect(g, x + 2, y + 1, 2, 1, 0xFF000000);
            Skin.rect(g, x + 14, y + 1, 2, 1, 0xFF000000);
        } else {
            Skin.rect(g, x, y + 1, 6, 1, 0xFF7A1010);
            Skin.rect(g, x + 12, y + 1, 6, 1, 0xFF7A1010);
        }
    }

    /** The giant face of a jump scare. */
    private static void scareFace(GuiGraphics g) {
        Skin.rect(g, 14, 20, 40, 24, 0xFFFFFFFF);
        Skin.rect(g, 92, 20, 40, 24, 0xFFFFFFFF);
        Skin.rect(g, 30, 28, 8, 9, 0xFFC00000);
        Skin.rect(g, 108, 28, 8, 9, 0xFFC00000);
        Skin.rect(g, 6, 56, 134, 2, 0xFFFFFFFF);
        for (int k = 0; k < 9; k++) {
            Skin.rect(g, 12 + k * 14, 49, 4, 7, 0xFFFFFFFF);
            Skin.rect(g, 19 + k * 14, 58, 4, 7, 0xFFFFFFFF);
        }
    }

    /**
     * Only listed while Spooky is on. 30 seconds: 0-10 s a quiet room, eyes in the corner;
     * 10-20 s something stands in the door; 20-24 s it comes closer; 24 s jump scare;
     * then static, and in the end it says your name.
     */
    private void horror(GuiGraphics g, int tm) {
        if (tm >= 1440) {                                                                // the end: all black
            Skin.rect(g, 0, 0, PW, PH, tm < 1500 && (tm / 2) % 2 == 0 ? 0xFF300000 : 0xFF000000);
            for (int k = 0; k < 6; k++) Skin.rect(g, (tm * 13 + k * 37) % PW, (tm * 7 + k * 11) % PH, 30, 1, 0x44FFFFFF);   // static (under everything else)
            if (tm < 1500) {                                                             // jump scare: giant face
                scareFace(g);
            } else if (tm < 1650) {
                eyes(g, 64, 38, (tm / 40) % 5 != 0);
            } else {
                String msg = t("cutemod.tube.see", Minecraft.getInstance().getUser().getName());
                Skin.str(g, font(), msg, (PW - font().width(msg)) / 2, 37, tm % 37 > 31 ? 0xFF3A0A10 : 0xFFD9534F, false);
            }
            return;
        }
        Skin.grad(g, 0, 0, PW, PH, 0xFF05030A, 0xFF140C1C);
        Skin.rect(g, 12, 10, 44, 38, 0xFF2A2030);                                             // window with a pale moon
        Skin.rect(g, 15, 13, 38, 32, 0xFF0B1030);
        Skin.disc(g, 40, 25, 6, 0xFFD8D8C0);
        Skin.rect(g, 32, 13, 2, 32, 0xFF2A2030);
        Skin.rect(g, 15, 28, 38, 2, 0xFF2A2030);
        Skin.rect(g, 0, 62, PW, 20, 0xFF0A0610);                                              // floor
        Skin.rect(g, 96, 14, 36, 48, 0xFF000000);                                             // open door into the dark
        if (tm >= 200 && tm < 320) eyes(g, 8, 66, tm < 270 || tm >= 276);               // eyes in the corner
        if (tm >= 600 && tm < 1200) figure(g, 114 - (tm - 600) / 100, 62, 1F, tm, false);   // it stands in the door
        if (tm >= 1200) {                                                                // ...and comes closer
            float p = (tm - 1200) / 240F;
            figure(g, 114 - (int) (41 * p), 62 + (int) (18 * p), 1F + p * p * 2.2F, tm, p > 0.6F);
        }
        int f = tm % 200;                                                                // flickering light
        if (tm >= 400 && ((f >= 188 && f < 192) || (f >= 196 && f < 198))) Skin.rect(g, 0, 0, PW, PH, 0xB0000000);
        if (tm >= 1200) for (int k = 0; k < 4; k++) Skin.rect(g, (tm * 13 + k * 37) % PW, (tm * 7 + k * 11) % PH, 30, 1, 0x33FFFFFF);
    }

    // ---------- speech bubble / caption ----------
    /**
     * The text of a talking video, typed letter by letter. dark = a caption strip (scary stories),
     * otherwise a white Animal-Crossing-like bubble with the speaker's name tag.
     */
    private void speech(GuiGraphics g, int v, int tm, boolean dark, int tag) {
        if (thumb) return;
        int n = lineAt(v, tm), k = typed(v, tm);
        List<String> ls = wrapped(v, n);
        int rem = k, last = 0;
        for (int i = 0; i < ls.size(); i++) {                                            // the line that is being typed now
            last = i;
            if (rem <= ls.get(i).length()) break;
            rem -= ls.get(i).length();
        }
        int first = Math.max(0, last - 2);
        int tx, ty, col;
        if (dark) {
            Skin.rect(g, 0, PH - 32, PW, 32, 0xCC000000);
            tx = 8;
            ty = PH - 29;
            col = 0xFFD8D0E0;
        } else {
            int bx = 4, by = PH - 33, bw = PW - 8, bh = 31;
            String who = t("cutemod.tube.who." + v);
            int ww = font().width(who) + 8;
            Skin.rect(g, bx + 5, by - 9, ww, 10, tag);                                        // name tag
            Skin.str(g, font(), who, bx + 9, by - 7, 0xFFFFFFFF, false);
            Skin.rect(g, bx - 1, by - 1, bw + 2, bh + 2, 0xFF3A2A3A);
            Skin.rect(g, bx, by, bw, bh, 0xFFFFFDF2);
            tx = 8;
            ty = by + 3;
            col = 0xFF3A2A3A;
            if (k >= total(ls) && (ticks / 20) % 2 == 0) {                               // a blinking "next" arrow
                for (int r = 0; r < 3; r++) Skin.rect(g, bx + bw - 10 + r, by + bh - 7 + r, 5 - 2 * r, 1, 0xFFE02A5A);
            }
        }
        int left = k;
        for (int i = 0; i < ls.size(); i++) {
            String s = ls.get(i);
            int show = Math.max(0, Math.min(s.length(), left));
            left -= s.length();
            if (i < first || i > last) continue;
            Skin.str(g, font(), s.substring(0, show), tx, ty + (i - first) * 9, col, false);
        }
    }

    // ---------- 7: news with a fox ----------
    private void news(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFFBFD8FF, 0xFFEAF2FF);
        Skin.rect(g, 78, 5, 62, 36, 0xFF26306A);                                              // the screen behind
        Skin.rect(g, 80, 7, 58, 32, 0xFF3C58B0);
        Skin.disc(g, 122, 25, 9, 0xFF2F7FD6);                                                 // a globe
        Skin.rect(g, 117, 20, 6, 4, 0xFF6FBF73);
        Skin.rect(g, 123, 27, 5, 5, 0xFF6FBF73);
        Skin.disc(g, 86, 12, 2, (tm / 30) % 2 == 0 ? 0xFFE02A2A : 0xFF8A1A1A);               // LIVE dot + text
        if (!thumb) Skin.str(g, font(), "LIVE", 91, 8, 0xFFFFFFFF, false);
        for (int k = 0; k < 3; k++) Skin.rect(g, 84, 19 + k * 7, 8 + (tm / 10 + k * 5) % 14, 3, 0xFFD8E4FF);   // headline bars
        int cx = 34, hy = 22 + (int) Math.round(Math.sin(tm / 20.0));
        boolean talk = talking(7, tm);
        int fox = 0xFFF0883A;
        Skin.disc(g, cx + 14, 36, 5, fox);                                                    // tail
        Skin.disc(g, cx + 17, 33, 2, 0xFFFFFFFF);
        Skin.rect(g, cx - 10, 31, 20, 14, fox);                                               // body
        Skin.rect(g, cx - 4, 33, 8, 12, 0xFFFFFFFF);                                          // white chest
        Skin.rect(g, cx - 10, hy - 14, 5, 8, fox);                                            // ears
        Skin.rect(g, cx + 5, hy - 14, 5, 8, fox);
        Skin.rect(g, cx - 9, hy - 12, 2, 5, 0xFF3A2A3A);
        Skin.rect(g, cx + 7, hy - 12, 2, 5, 0xFF3A2A3A);
        Skin.disc(g, cx, hy, 10, fox);                                                        // head
        Skin.rect(g, cx - 6, hy + 1, 12, 7, 0xFFFFFFFF);                                      // muzzle
        Skin.rect(g, cx - 1, hy + 1, 3, 2, 0xFF3A2A3A);                                       // nose
        boolean blink = tm % 120 < 5;
        Skin.rect(g, cx - 6, hy - 4, 2, blink ? 1 : 3, 0xFF3A2A3A);                           // eyes
        Skin.rect(g, cx + 4, hy - 4, 2, blink ? 1 : 3, 0xFF3A2A3A);
        if (talk) Skin.rect(g, cx - 2, hy + 4, 4, 3, 0xFF7A2A1A);                             // mouth opens while talking
        Skin.rect(g, 0, 43, 76, 6, 0xFF8A5A3A);                                               // the desk with a mic
        Skin.rect(g, 0, 43, 76, 1, 0xFFB57F55);
        Skin.rect(g, cx + 22, 36, 2, 7, 0xFF3A3A44);
        Skin.disc(g, cx + 23, 35, 2, 0xFF3A3A44);
        speech(g, 7, tm, false, 0xFFE07A2A);
    }

    // ---------- 8: weather with a penguin ----------
    private static void cloud(GuiGraphics g, int x, int y, int col) {
        Skin.disc(g, x - 7, y + 2, 5, col);
        Skin.disc(g, x, y - 2, 7, col);
        Skin.disc(g, x + 8, y + 2, 5, col);
        Skin.rect(g, x - 8, y + 2, 17, 5, col);
    }

    private void wIcon(GuiGraphics g, int kind, int x, int y, int tm) {
        y += (int) Math.round(Math.sin(tm / 18.0) * 2);
        switch (kind) {
            case 0 -> {                                                                  // sun with turning rays
                Skin.disc(g, x, y, 8, 0xFFFFD84A);
                Skin.disc(g, x, y, 5, 0xFFFFE98A);
                for (int k = 0; k < 8; k++) {
                    double a = tm / 40.0 + k * Math.PI / 4;
                    Skin.rect(g, x + (int) Math.round(Math.cos(a) * 13), y + (int) Math.round(Math.sin(a) * 13), 2, 2, 0xFFFFD84A);
                }
            }
            case 1 -> cloud(g, x, y, 0xFFFFFFFF);
            case 2 -> {                                                                  // rain
                cloud(g, x, y - 4, 0xFF9AA8BC);
                for (int k = 0; k < 4; k++) Skin.rect(g, x - 8 + k * 5, y + 5 + (tm / 2 + k * 5) % 12, 1, 3, 0xFF4A9AF0);
            }
            case 3 -> {                                                                  // snow
                cloud(g, x, y - 4, 0xFFDDE6F2);
                for (int k = 0; k < 5; k++) Skin.rect(g, x - 9 + k * 4, y + 5 + (tm / 4 + k * 3) % 12, 2, 2, 0xFFFFFFFF);
            }
            default -> {                                                                 // rainbow
                int[] cols = {0xFFE02A2A, 0xFFFFA23A, 0xFFFFE04A, 0xFF4CAF50, 0xFF3A8AE0, 0xFF8A5AD0};
                for (int b = 0; b < 6; b++) {
                    for (int s = 0; s <= 24; s++) {
                        double a = Math.PI * s / 24;
                        int r = 16 - b * 2;
                        Skin.rect(g, x + (int) Math.round(Math.cos(a) * r), y + 6 - (int) Math.round(Math.sin(a) * r), 2, 2, cols[b]);
                    }
                }
            }
        }
    }

    private void weather(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFF9FD8FF, 0xFFE6F6FF);
        Skin.rect(g, 0, 44, PW, 38, 0xFFBCE3F5);                                              // icy floor
        Skin.rect(g, 64, 4, 78, 38, 0xFF1F5FA8);                                              // the map
        Skin.rect(g, 66, 6, 74, 34, 0xFF2F7FD6);
        Skin.disc(g, 82, 28, 9, 0xFF6FBF73);
        Skin.disc(g, 96, 20, 7, 0xFF6FBF73);
        Skin.disc(g, 126, 30, 10, 0xFF6FBF73);
        Skin.disc(g, 130, 14, 5, 0xFF6FBF73);
        int kind = Math.min(4, tm * 5 / LEN[8]);                                         // the weather changes with every line
        wIcon(g, kind, 104, 22, tm);
        int cx = 30;
        boolean talk = talking(8, tm);
        int wv2 = talk ? (int) Math.round(Math.sin(tm / 6.0) * 2) : 0;
        int dark = 0xFF2A2F3A;
        Skin.rect(g, cx - 9, 44, 7, 2, 0xFFFF9F43);                                           // feet
        Skin.rect(g, cx + 2, 44, 7, 2, 0xFFFF9F43);
        Skin.disc(g, cx, 31, 12, dark);                                                       // body
        Skin.rect(g, cx - 12, 31, 24, 13, dark);
        Skin.disc(g, cx, 33, 8, 0xFFFFFFFF);                                                  // belly
        Skin.rect(g, cx - 8, 33, 16, 11, 0xFFFFFFFF);
        Skin.rect(g, cx - 16, 26, 4, 10, dark);                                               // wings
        Skin.rect(g, cx + 12, 20 + wv2, 4, 10, dark);                                         // the right one points at the map
        Skin.disc(g, cx, 17, 9, dark);                                                        // head
        Skin.disc(g, cx - 4, 16, 2, 0xFFFFFFFF);
        Skin.disc(g, cx + 4, 16, 2, 0xFFFFFFFF);
        Skin.rect(g, cx - 3, 16, 1, 2, dark);
        Skin.rect(g, cx + 5, 16, 1, 2, dark);
        Skin.rect(g, cx - 3, 19, 6, 2, 0xFFFF9F43);                                           // beak
        if (talk) Skin.rect(g, cx - 3, 21, 6, 2, 0xFFE0702A);
        Skin.rect(g, cx - 8, 20, 3, 2, 0xFFFF9AB0);                                           // blush
        Skin.rect(g, cx + 5, 20, 3, 2, 0xFFFF9AB0);
        speech(g, 8, tm, false, 0xFF3A6FB5);
    }

    // ---------- 9: cooking with a panda ----------
    private void cooking(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFFFFE6C8, 0xFFFFF4E0);
        for (int x = 0; x < PW; x += 16) Skin.rect(g, x, 0, 8, 30, 0x22FFFFFF);               // wall stripes
        Skin.rect(g, 0, 38, PW, 44, 0xFFC98A5A);                                              // counter
        Skin.rect(g, 0, 38, PW, 2, 0xFFE0A878);
        int slot = LEN[9] / SL[9], n = Math.min(SL[9] - 1, tm / slot), lt = tm - n * slot;
        // the chef
        int cx = 28, hy = 28 + (int) Math.round(Math.sin(tm / 25.0));
        boolean talk = talking(9, tm);
        Skin.rect(g, cx - 9, 34, 18, 6, 0xFFFFFFFF);
        Skin.rect(g, cx - 5, 35, 10, 5, 0xFFFFB3D1);                                          // apron
        Skin.disc(g, cx - 11, 36, 3, 0xFF222222);                                             // arms on the counter
        Skin.disc(g, cx + 11, 36, 3, 0xFF222222);
        Skin.disc(g, cx, hy, 9, 0xFFFFFFFF);                                                  // head
        Skin.disc(g, cx - 8, hy - 8, 3, 0xFF222222);                                          // ears
        Skin.disc(g, cx + 8, hy - 8, 3, 0xFF222222);
        Skin.disc(g, cx - 4, hy, 2, 0xFF222222);                                              // eyes
        Skin.disc(g, cx + 4, hy, 2, 0xFF222222);
        Skin.rect(g, cx - 1, hy + 3, 3, 2, 0xFF222222);
        if (talk) Skin.rect(g, cx - 2, hy + 6, 4, 2, 0xFFE0607A);
        Skin.rect(g, cx - 7, hy - 15, 14, 6, 0xFFFFFFFF);                                     // chef hat
        Skin.disc(g, cx - 5, hy - 17, 4, 0xFFFFFFFF);
        Skin.disc(g, cx, hy - 19, 5, 0xFFFFFFFF);
        Skin.disc(g, cx + 5, hy - 17, 4, 0xFFFFFFFF);
        Skin.rect(g, cx - 7, hy - 11, 14, 2, 0xFFE6E0F0);
        // the bowl
        int bx = 90;
        Skin.rect(g, bx - 12, 30, 24, 10, 0xFFCFE0F2);
        Skin.rect(g, bx - 10, 40, 20, 2, 0xFFB5CBE3);
        Skin.rect(g, bx - 12, 30, 24, 2, 0xFFE6F0FA);
        if (n == 0) {
            if (lt < 70) {                                                               // an egg falls in
                Skin.disc(g, bx, lt * 28 / 70, 3, 0xFFFFFFFF);
            } else {
                Skin.disc(g, bx, 31, 4, 0xFFFFFFFF);
                Skin.disc(g, bx, 31, 2, 0xFFFFD84A);
            }
        } else if (n == 1) {
            Skin.disc(g, bx, 31, 3, 0xFFFFD84A);
            if (lt < 150) {                                                              // flour and sugar rain down
                for (int k = 0; k < 6; k++) Skin.rect(g, bx - 9 + k * 3, (lt * 2 + k * 13) % 30, 2, 2, k % 2 == 0 ? 0xFFFFFFFF : 0xFFFFC8DC);
            } else {
                Skin.rect(g, bx - 9, 29, 18, 3, 0xFFFFFFFF);
            }
        } else if (n == 2) {
            Skin.rect(g, bx - 10, 29, 20, 3, 0xFFF6DDA0);                                     // batter + a whisk
            int wx = bx + (int) Math.round(Math.sin(tm / 4.0) * 5);
            Skin.rect(g, wx - 1, 14, 2, 17, 0xFFB0B8C8);
            Skin.disc(g, wx, 30, 3, 0xFFB0B8C8);
        } else {
            Skin.rect(g, bx - 10, 29, 20, 3, 0xFFF6DDA0);
        }
        // the oven (from the 4th step on)
        if (n >= 3) {
            Skin.rect(g, 108, 12, 32, 26, 0xFF8A8FA0);
            Skin.rect(g, 113, 18, 22, 14, n == 3 ? 0xFFFF9A3A : 0xFF2A2A32);
            Skin.rect(g, 113, 18, 22, 1, 0xFFB0B8C8);
            Skin.disc(g, 114, 15, 1, 0xFFE02A2A);
            Skin.disc(g, 120, 15, 1, 0xFFE02A2A);
            if (n == 3) {                                                                // the cupcake rises
                int cy2 = 30 - Math.min(6, lt / 40);
                Skin.rect(g, 120, cy2, 8, 3, 0xFFE86A9A);
                Skin.disc(g, 124, cy2 - 1, 4, 0xFFD9A15A);
            }
        }
        // the finished cupcake
        if (n >= 4) {
            Skin.rect(g, 57, 33, 10, 5, 0xFFE86A9A);                                          // paper cup
            Skin.disc(g, 62, 31, 5, 0xFFD9A15A);
            Skin.disc(g, 62, 28, 4, 0xFFFFB3D1);
            Skin.disc(g, 62, 26, 2, 0xFFFFFFFF);
            Skin.disc(g, 62, Math.min(22, lt / 2), 2, 0xFFE02A2A);                            // a cherry drops on top
        }
        if (n == 5) {
            for (int k = 0; k < 3; k++) heart(g, 52 + k * 14, 28 - (lt / 2 + k * 10) % 28, 0xFFF58FB8);
        }
        speech(g, 9, tm, false, 0xFF2A2A2A);
    }

    // ---------- 10: ASMR, rain and a purring cat ----------
    private void rainCat(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFF141A2E, 0xFF22304C);
        for (int k = 0; k < 9; k++) {                                                    // blurry lights of the city
            Skin.disc(g, (k * 37 + 10) % PW, 22 + (k * 11) % 18, 3 + k % 3, (tm / 50 + k) % 6 == 0 ? 0x22FFD27A : 0x44FFD27A);
        }
        for (int k = 0; k < 24; k++) {                                                   // drops running down the glass
            int x = (k * 53 + 9) % PW, y = (tm * (1 + k % 3) / 3 + k * 29) % (PH - 18);
            Skin.rect(g, x, y, 1, 3, 0xAAB8D8FF);
            Skin.rect(g, x, y - 2, 1, 1, 0x55B8D8FF);
        }
        Skin.rect(g, 0, 0, PW, 3, 0xFF4A3A34);                                                // window frame
        Skin.rect(g, 0, 0, 3, PH, 0xFF4A3A34);
        Skin.rect(g, PW - 3, 0, 3, PH, 0xFF4A3A34);
        Skin.rect(g, 71, 0, 3, 58, 0xFF4A3A34);
        Skin.rect(g, 0, 27, PW, 2, 0xFF4A3A34);
        Skin.rect(g, 0, 58, PW, 24, 0xFF3A2A28);                                              // the sill / a blanket
        Skin.rect(g, 0, 58, PW, 2, 0xFF5A423A);
        Skin.disc(g, 20, 78, 40, 0x11FFB45A);                                                 // warm lamp glow
        int br = (int) Math.round(Math.sin(tm / 38.0));                                  // the cat breathes
        int pr = (tm % 240 >= 120 && tm % 240 < 200) ? (tm % 4 < 2 ? 0 : 1) : 0;        // purring trembles
        int cat = 0xFFE0A060, ox = pr;
        Skin.disc(g, 42 + ox, 71, 3, cat);                                                    // tail
        Skin.disc(g, 46 + ox, 74, 3, cat);
        Skin.disc(g, 58 + ox, 68 + br, 10, cat);                                              // body
        Skin.disc(g, 76 + ox, 68 + br, 10, cat);
        Skin.rect(g, 58 + ox, 58 + br, 18, 20, cat);
        Skin.rect(g, 62 + ox, 58 + br, 2, 6, 0xFFB87A40);                                     // stripes
        Skin.rect(g, 68 + ox, 58 + br, 2, 6, 0xFFB87A40);
        Skin.disc(g, 92 + ox, 63, 8, cat);                                                    // head
        Skin.rect(g, 86 + ox, 52, 3, 5, cat);                                                 // ears
        Skin.rect(g, 95 + ox, 52, 3, 5, cat);
        Skin.rect(g, 87 + ox, 54, 1, 2, 0xFFF08A9A);
        Skin.rect(g, 96 + ox, 54, 1, 2, 0xFFF08A9A);
        Skin.rect(g, 87 + ox, 62, 3, 1, 0xFF3A2A3A);                                          // closed eyes
        Skin.rect(g, 94 + ox, 62, 3, 1, 0xFF3A2A3A);
        Skin.rect(g, 91 + ox, 65, 2, 1, 0xFFF08A9A);                                          // nose
        for (int k = 0; k < 2 && !thumb; k++) {                                          // sleepy z-z
            int zy = 46 - ((tm / 6 + k * 14) % 28);
            if (zy > 6) Skin.str(g, font(), "z", 104 + k * 5, zy, 0xAAB8C8E8, false);
        }
        if (!thumb && tm < 420) Skin.str(g, font(), t("cutemod.tube.asmr"), 8, PH - 11, 0xAAB8C8E8, false);
    }

    // ---------- 11: ASMR, poking a slime ----------
    private void slimeAsmr(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFFFFE4F1, 0xFFE8D8FF);
        for (int k = 0; k < 10; k++) {                                                   // sparkles
            int b = (tm / 15 + k) % 5;
            if (b < 2) {
                int sx = (k * 47 + 13) % 136 + 4, sy = (k * 29 + 5) % 50 + 4;
                Skin.rect(g, sx, sy + 1, 3, 1, 0xCCFFFFFF);
                Skin.rect(g, sx + 1, sy, 1, 3, 0xCCFFFFFF);
            }
        }
        int p = tm % 120;
        float press = 0F, depth = 0F;
        int[] taps = {0, 12, 24};
        for (int tp : taps) {
            if (p >= tp && p < tp + 8) { press = (float) Math.sin((p - tp) / 8.0 * Math.PI); depth = 6F * press; }
        }
        if (p >= 60 && p < 90) {                                                         // the slow press
            press = p < 68 ? (p - 60) / 8F : p < 84 ? 1F : (90 - p) / 6F;
            depth = 12F * press;
        }
        int d = Math.round(depth);
        int cx = 73, base = 66, w = 46 + d, h = 28 - d, top = base - h;
        Skin.rect(g, cx - 28, base, 56, 2, 0x22000000);                                       // shadow
        Skin.rect(g, cx - w / 2 + 3, top, w - 6, h, 0xFF8FE0B0);                              // the slime
        Skin.rect(g, cx - w / 2, top + 3, w, h - 3, 0xFF8FE0B0);
        Skin.rect(g, cx - w / 2 + 5, top + 4, 9, 3, 0x88FFFFFF);
        Skin.rect(g, cx - w / 2, base - 4, w, 4, 0xFF6FC896);
        Skin.rect(g, cx - 9, top + h / 2 - 2, 3, 4, 0xFF2A4A3A);                              // eyes
        Skin.rect(g, cx + 6, top + h / 2 - 2, 3, 4, 0xFF2A4A3A);
        Skin.rect(g, cx - 2, top + h / 2 + 3, 5, 1, 0xFF2A4A3A);                              // a tiny smile
        int tip = 24 + Math.round(press * (12 + depth));                                 // a finger pokes it from above
        int fx = cx + 14;
        Skin.rect(g, fx - 3, tip - 22, 7, 22, 0xFFF0C8A0);
        Skin.disc(g, fx, tip, 3, 0xFFF0C8A0);
        if (!thumb && tm < 420) Skin.str(g, font(), t("cutemod.tube.asmr"), 8, PH - 11, 0xFF8A6AA8, false);
    }

    // ---------- 12: lo-fi, a cat doing homework ----------
    private static void note(GuiGraphics g, int x, int y, int col) {
        Skin.disc(g, x, y, 2, col);
        Skin.rect(g, x + 1, y - 6, 1, 6, col);
        Skin.rect(g, x + 1, y - 6, 3, 1, col);
    }

    private void lofiRoom(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFF2A1F4A, 0xFF5A3A6E);
        Skin.rect(g, 4, 4, 70, 40, 0xFF1A1230);                                               // window with a night city
        Skin.grad(g, 6, 6, 72, 42, 0xFF1B1440, 0xFF8A4A7A);
        Skin.disc(g, 60, 16, 5, 0xFFFFF3B0);
        int[] bh = {14, 22, 10, 18, 26, 12, 20};
        for (int i = 0; i < bh.length; i++) {
            int bx = 6 + i * 9, by = 42 - bh[i];
            Skin.rect(g, bx, by, 8, bh[i], 0xFF120C26);
            for (int wy = by + 3; wy < 40; wy += 5) {
                if ((tm / 90 + i * 3 + wy) % 7 != 0) Skin.rect(g, bx + 2, wy, 2, 2, 0xFFFFD27A);
            }
        }
        Skin.rect(g, 4, 4, 70, 1, 0xFF4A3A60);
        Skin.rect(g, 39, 4, 1, 40, 0xFF4A3A60);
        Skin.rect(g, 4, 43, 70, 1, 0xFF4A3A60);
        Skin.rect(g, 120, 24, 2, 22, 0xFF3A3A44);                                             // lamp
        Skin.rect(g, 112, 18, 18, 7, 0xFFFFD27A);
        Skin.disc(g, 121, 30, 24, 0x18FFD27A);
        Skin.disc(g, 121, 30, 14, 0x18FFD27A);
        int beat = (tm % 60 < 30) ? 0 : 1;                                               // the cat nods to the beat
        int cx = 98, hy = 30 + beat;
        int fur = 0xFF8A93A8;
        Skin.rect(g, cx - 9, 36, 18, 10, fur);                                                // body
        Skin.rect(g, cx - 9, hy - 12, 4, 6, fur);                                             // ears
        Skin.rect(g, cx + 5, hy - 12, 4, 6, fur);
        Skin.disc(g, cx, hy, 9, fur);                                                         // head
        Skin.rect(g, cx - 5, hy - 2, 3, 1, 0xFF3A2A3A);                                       // happy closed eyes ^ ^
        Skin.rect(g, cx - 6, hy - 1, 1, 1, 0xFF3A2A3A);
        Skin.rect(g, cx - 2, hy - 1, 1, 1, 0xFF3A2A3A);
        Skin.rect(g, cx + 2, hy - 2, 3, 1, 0xFF3A2A3A);
        Skin.rect(g, cx + 1, hy - 1, 1, 1, 0xFF3A2A3A);
        Skin.rect(g, cx + 5, hy - 1, 1, 1, 0xFF3A2A3A);
        Skin.rect(g, cx - 1, hy + 2, 2, 1, 0xFFF08A9A);
        Skin.rect(g, cx - 10, hy - 11, 20, 2, 0xFFE06A9A);                                    // headphones
        Skin.disc(g, cx - 10, hy, 4, 0xFFE06A9A);
        Skin.disc(g, cx + 10, hy, 4, 0xFFE06A9A);
        Skin.rect(g, 0, 46, PW, 36, 0xFF3A2430);                                              // the desk
        Skin.rect(g, 0, 46, PW, 3, 0xFF5A3A2E);
        Skin.rect(g, 80, 44, 26, 3, 0xFFFFFFFF);                                              // notebook
        Skin.rect(g, 84 + (tm / 4) % 16, 41, 2, 5, 0xFFFFD84A);                               // the pencil writes
        Skin.rect(g, 14, 38, 8, 8, 0xFFFFFFFF);                                               // a mug with steam
        Skin.rect(g, 22, 40, 2, 4, 0xFFFFFFFF);
        for (int k = 0; k < 2; k++) Skin.rect(g, 16 + k * 3, 32 - (tm / 6 + k * 4) % 8, 1, 3, 0x66FFFFFF);
        for (int k = 0; k < 3; k++) {                                                    // floating notes
            int ny = 44 - (tm / 3 + k * 40) % 120 / 3;
            if (ny > 0) note(g, 50 + k * 22 + (int) Math.round(Math.sin((tm + k * 30) / 20.0) * 3), ny, 0xAAFFB3D1);
        }
        if (!thumb) Skin.str(g, font(), t("cutemod.tube.lofi"), 6, PH - 12, 0xFFB8A0D0, false);
    }

    // ---------- 13: scary story, the empty village ----------
    private void village(GuiGraphics g, int tm) {
        if (tm >= 2760) {                                                                // the end
            boolean flash = tm < 2820;
            Skin.rect(g, 0, 0, PW, PH, flash && (tm / 2) % 2 == 0 ? 0xFF300000 : 0xFF000000);
            for (int k = 0; k < 6; k++) Skin.rect(g, (tm * 13 + k * 37) % PW, (tm * 7 + k * 11) % PH, 30, 1, 0x44FFFFFF);
            if (flash) {                                                                 // a face with no face
                Skin.rect(g, 30, 2, 86, 72, 0xFF4A3A40);
                Skin.rect(g, 66, 26, 14, 30, 0xFF2E2228);
                Skin.rect(g, 62, 54, 22, 6, 0xFF2E2228);
            } else {
                String msg = t("cutemod.tube.see3", Minecraft.getInstance().getUser().getName());
                Skin.str(g, font(), msg, (PW - font().width(msg)) / 2, 37, tm % 37 > 31 ? 0xFF3A0A10 : 0xFFD9534F, false);
            }
            return;
        }
        Skin.grad(g, 0, 0, PW, PH, 0xFF02030A, 0xFF0E1428);
        for (int k = 0; k < 14; k++) Skin.rect(g, (k * 37 + 11) % 144, (k * 53 + 7) % 26, 1, 1, (tm / 20 + k) % 6 == 0 ? 0x66FFFFFF : 0xFFFFFFFF);
        Skin.disc(g, 120, 12, 8, 0xFFD8D8C0);                                                 // moon
        Skin.disc(g, 117, 10, 2, 0xFFB8B8A0);
        int dark = Math.max(0, Math.min(8, (tm - 900) / 125));                           // windows go out one by one
        int[] rank = {4, 2, 6, 0, 3, 7, 1, 5};
        for (int i = 0; i < 4; i++) {
            int x0 = 6 + i * 34;
            Skin.rect(g, x0, 30, 26, 16, 0xFF2A2030);
            for (int r = 0; r < 6; r++) Skin.rect(g, x0 - 2 + r * 2, 29 - r, 30 - r * 4, 1, 0xFF1A1220);
            for (int j = 0; j < 2; j++) {
                boolean lit = rank[i * 2 + j] >= dark;
                Skin.rect(g, x0 + 4 + j * 12, 34, 6, 6, lit ? 0xFFFFD27A : 0xFF0E0A14);
            }
        }
        Skin.rect(g, 0, 46, PW, 36, 0xFF0A0610);                                              // the ground
        if (tm >= 840) {                                                                 // a villager, with his back to you
            float sc = 0.7F + Math.min(1F, (tm - 840) / 1700F) * 0.4F;
            boolean turned = tm >= 2400;
            figure(g, 73, 50, sc, tm, false, turned);
            if (turned) Skin.rect(g, 71, 50 - (int) (40 * sc), 4, 3, 0xFF3A2A30);             // the head slowly turns: a nose
        }
        int f = tm % 200;                                                                // flickering
        if (tm >= 1200 && ((f >= 188 && f < 192) || (f >= 196 && f < 198))) Skin.rect(g, 0, 0, PW, PH, 0xA0000000);
        speech(g, STORY1, tm, true, 0);
    }

    // ---------- 14: scary story, the mine ----------
    private void mine(GuiGraphics g, int tm) {
        if (tm >= 2760) {                                                                // the end
            boolean flash = tm < 2820;
            Skin.rect(g, 0, 0, PW, PH, flash && (tm / 2) % 2 == 0 ? 0xFF300000 : 0xFF000000);
            for (int k = 0; k < 6; k++) Skin.rect(g, (tm * 13 + k * 37) % PW, (tm * 7 + k * 11) % PH, 30, 1, 0x44FFFFFF);
            if (flash) {
                scareFace(g);
            } else {
                String msg = t("cutemod.tube.see2", Minecraft.getInstance().getUser().getName());
                Skin.str(g, font(), msg, (PW - font().width(msg)) / 2, 37, tm % 37 > 31 ? 0xFF3A0A10 : 0xFFD9534F, false);
            }
            return;
        }
        Skin.rect(g, 0, 0, PW, PH, 0xFF0A0A0E);
        int[] wall = {0xFF34343C, 0xFF2C2C34, 0xFF24242B, 0xFF1C1C22, 0xFF14141A, 0xFF0A0A0E};
        for (int i = 0; i < 6; i++) {                                                    // the tunnel: frames getting smaller
            int w = 146 - i * 22, h = 82 - i * 11;
            Skin.rect(g, 73 - w / 2, 38 - h / 2, w, h, wall[i]);
        }
        int out = Math.max(0, Math.min(8, (tm - 700) / 230));                            // torches go out one by one
        int[] tx = {12, 23, 34, 45}, ty = {28, 29, 30, 31};
        for (int i = 0; i < 4; i++) {
            for (int side = 0; side < 2; side++) {
                int x = side == 0 ? tx[i] : PW - 3 - tx[i];
                Skin.rect(g, x, ty[i], 2, 5, 0xFF7A5A3A);
                if (i * 2 + side >= out) {
                    int fl = (tm / 4 + i * 3 + side) % 3;
                    Skin.rect(g, x - 1, ty[i] - 3, 4, 3, fl == 0 ? 0xFFFFE08A : 0xFFFFA23A);
                    Skin.disc(g, x + 1, ty[i] - 1, 8, 0x16FFB45A);
                }
            }
        }
        if (tm >= 1500) {                                                                // somebody tall far away, coming closer
            float sc = Math.min(1.5F, 0.3F + (tm - 1500) / 1000F);
            figure(g, 73, 51 + (int) ((sc - 0.3F) * 22), sc, tm, false);
        }
        int dim = (out * 14) << 24;                                                      // the darker, the less you see
        Skin.rect(g, 0, 0, PW, PH, dim);
        if (!thumb) Skin.str(g, font(), "Y: " + (60 - tm * 177 / LEN[STORY2]), 4, 4, 0xFF9AE6A8, false);
        int f = tm % 220;
        if (tm >= 700 && ((f >= 208 && f < 212) || (f >= 216 && f < 218))) Skin.rect(g, 0, 0, PW, PH, 0xB0000000);
        speech(g, STORY2, tm, true, 0);
    }

    // ---------- 15: Creeper's cooking disaster (talking) ----------
    private void creeperCook(GuiGraphics g, int tm) {
        int n = lineAt(15, tm), slot = slot(15), lt = tm - n * slot;
        boolean boom = n == 5 && lt > slot * 55 / 100;
        int bt = boom ? lt - slot * 55 / 100 : 0;
        Skin.grad(g, 0, 0, PW, PH, 0xFFFFF0D0, 0xFFFFE0B0);
        for (int x = 0; x < PW; x += 18) Skin.rect(g, x, 0, 9, 34, 0x22FFFFFF);
        Skin.rect(g, 0, 40, PW, 42, 0xFFB5764A);                                              // the counter
        Skin.rect(g, 0, 40, PW, 2, 0xFFD9A070);
        Skin.rect(g, 106, 8, 30, 22, 0xFF8FB8D8);                                             // a window
        Skin.rect(g, 108, 10, 26, 18, 0xFFCDEBFF);
        Skin.rect(g, 120, 10, 2, 18, 0xFF8FB8D8);
        // the pot
        int px = 82, shake = n >= 4 && !boom ? (int) Math.round(Math.sin(tm / 1.5) * (n == 5 ? 2 : 1)) : 0;
        if (!boom) {
            Skin.rect(g, px - 16 + shake, 28, 32, 14, 0xFF5A6070);
            Skin.rect(g, px - 18 + shake, 26, 36, 3, 0xFF7A8090);
            Skin.rect(g, px - 14 + shake, 30, 28, 4, n >= 1 ? (n >= 2 ? 0xFFE8A040 : 0xFF9AD0F0) : 0xFF4A5060);   // water, then soup
            for (int k = 0; k < 3 && n >= 1; k++) Skin.disc(g, px - 8 + k * 8 + shake, 28 - (tm / 4 + k * 5) % 8, 1 + k % 2, 0x88FFFFFF);   // bubbles
            if (n >= 4) for (int k = 0; k < 3; k++) Skin.rect(g, px - 10 + k * 10 + shake, 14 - (tm / 3 + k * 6) % 8, 1, 4, 0x88DDDDDD);   // hissing steam
        }
        // the creeper cook
        int cx = 36, hop = n == 3 ? (int) Math.round(Math.abs(Math.sin(tm / 20.0)) * 2) : 0;
        int cy = 46 - hop;
        int green = boom && bt > 8 ? 0xFF4A4A44 : 0xFF5BBF6A;                                  // black with soot after the bang
        Skin.rect(g, cx - 8, cy - 22, 16, 16, green);                                         // head
        Skin.rect(g, cx - 5, cy - 18, 3, 3, 0xFF1B3A1B);
        Skin.rect(g, cx + 2, cy - 18, 3, 3, 0xFF1B3A1B);
        Skin.rect(g, cx - 2, cy - 14, 4, 3, 0xFF1B3A1B);
        Skin.rect(g, cx - 3, cy - 11, 2, 3, 0xFF1B3A1B);
        Skin.rect(g, cx + 1, cy - 11, 2, 3, 0xFF1B3A1B);
        Skin.rect(g, cx - 5, cy - 6, 10, 16, green);                                          // body
        Skin.rect(g, cx - 7, cy + 8, 5, 6, green);                                            // feet
        Skin.rect(g, cx + 2, cy + 8, 5, 6, green);
        Skin.rect(g, cx - 6, cy - 6, 12, 8, 0xFFFFFFFF);                                      // apron
        Skin.rect(g, cx - 5, cy - 24, 10, 4, 0xFFFFFFFF);                                     // a little chef hat
        Skin.disc(g, cx, cy - 26, 4, 0xFFFFFFFF);
        int arm = (int) Math.round(Math.sin(tm / 6.0) * 3);                                   // stirring
        Skin.rect(g, cx + 5, cy - 4, 20 + arm, 3, green);
        Skin.rect(g, cx + 24 + arm, cy - 14, 2, 16, 0xFFC98A5A);
        if (talking(15, tm)) Skin.rect(g, cx - 2, cy - 12, 4, 4, 0xFF1B3A1B);
        if (n >= 1 && n <= 2 && lt < 90) for (int k = 0; k < 4; k++) Skin.rect(g, px - 9 + k * 6, (lt * 2 + k * 9) % 28, 2, 2, n == 1 ? 0xFFFF9A2A : 0xFF3A3A3A);   // carrots, then "gunpowder" fall in
        if (boom) {                                                                           // KABOOM
            if (bt < 6) Skin.rect(g, 0, 0, PW, PH, 0xCCFFFFFF);
            int r = Math.min(60, bt * 3);
            if (bt < 30) { Skin.disc(g, px, 34, r, 0x88FFB030); Skin.disc(g, px, 34, r * 2 / 3, 0xAAFFE060); }
            for (int k = 0; k < 14; k++) {                                                    // soup and confetti everywhere
                int dx = (int) Math.round(Math.cos(k * 0.9) * (6 + bt * (1.0 + (k % 4) * 0.35))), dy = (int) Math.round(Math.sin(k * 0.9) * (4 + bt * 0.7)) + bt * bt / 90;
                Skin.rect(g, px + dx, 30 + dy, 3, 3, k % 3 == 0 ? 0xFFE8A040 : k % 3 == 1 ? 0xFFFF7FAF : 0xFFFFE066);
            }
            Skin.rect(g, px - 18, 40, 36, 3, 0xFFE8A040);                                     // the pot is gone, only a puddle
            if (bt > 30) for (int k = 0; k < 3; k++) Skin.disc(g, cx + k * 3, cy - 30 - (bt - 30) / 3 - k * 4, 2 + k, 0x66AAAAAA);   // smoke from the creeper's head
        }
        speech(g, 15, tm, false, 0xFF4FA55E);
    }

    // ---------- 16: Sleepy Panda counts sheep ----------
    private void sheep(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, PH, 0xFF1A1A4A, 0xFF4A3A8A);
        for (int i = 0; i < 16; i++) {
            int sx = (i * 47 + 9) % PW, sy = (i * 23 + 4) % 40;
            Skin.rect(g, sx, sy, 1, 1, (tm / 12 + i) % 5 == 0 ? 0x66FFFFFF : 0xFFFFF6C8);
        }
        Skin.disc(g, 118, 16, 8, 0xFFFFF0B0);                                                 // the moon
        Skin.disc(g, 121, 14, 7, 0xFF2A2468);
        Skin.rect(g, 0, 58, PW, 24, 0xFF2F6A4A);                                              // the hill
        Skin.disc(g, 40, 70, 40, 0xFF3A7A58);
        Skin.rect(g, 66, 48, 3, 20, 0xFFC98A5A);                                              // the fence
        Skin.rect(g, 76, 48, 3, 20, 0xFFC98A5A);
        Skin.rect(g, 62, 52, 20, 2, 0xFFD9A070);
        Skin.rect(g, 62, 59, 20, 2, 0xFFD9A070);
        int per = 150, k = tm / per, ph = tm % per;                                           // one sheep every 150 ticks
        int sx = -14 + ph * 176 / per;
        int jump = (int) Math.round(Math.max(0, Math.sin((sx - 40) * Math.PI / 66.0)) * (sx > 40 && sx < 106 ? 22 : 0));
        int sy = 64 - jump;
        Skin.rect(g, sx - 6, sy + 6, 2, 5, 0xFF3A2A3A);                                       // legs
        Skin.rect(g, sx + 4, sy + 6, 2, 5, 0xFF3A2A3A);
        Skin.disc(g, sx, sy, 8, 0xFFFFFFFF);                                                  // the wool
        Skin.disc(g, sx - 5, sy - 3, 5, 0xFFF4F4FF);
        Skin.disc(g, sx + 5, sy - 3, 5, 0xFFF4F4FF);
        Skin.disc(g, sx + 9, sy - 1, 4, 0xFF3A2A3A);                                          // the face
        Skin.rect(g, sx + 9, sy - 2, 1, 1, 0xFFFFFFFF);
        if (!thumb) {
            String num = Integer.toString(k + 1);
            g.pose().pushPose();
            g.pose().translate(8, 6, 0);
            g.pose().scale(2F, 2F, 1F);
            Skin.str(g, font(), num, 0, 0, 0xFFFFF0B0, true);
            g.pose().popPose();
            if (tm > 1500) for (int z = 0; z < 3; z++) Skin.str(g, font(), "z", 20 + z * 7 + (tm / 10 + z * 3) % 4, 48 - z * 7 - (tm / 14 + z * 4) % 6, 0xCCFFFFFF, false);   // the panda dozes off
        }
        if (tm > 1500) {                                                                       // the sleepy panda in the corner
            Skin.disc(g, 20, 72, 9, 0xFFFFFFFF);
            Skin.disc(g, 13, 66, 3, 0xFF222222);
            Skin.disc(g, 27, 66, 3, 0xFF222222);
            Skin.rect(g, 15, 71, 4, 1, 0xFF222222);
            Skin.rect(g, 22, 71, 4, 1, 0xFF222222);
        }
    }

    // ---------- 17: Rocket Bee, launch day ----------
    private void rocketBee(GuiGraphics g, int tm) {
        int launch = 600, land = 1700;
        int alt = tm < launch ? 0 : Math.min(tm - launch, 1000);                              // how high we are
        boolean space = tm >= launch + 240;
        Skin.grad(g, 0, 0, PW, PH, space ? 0xFF080620 : 0xFF6FB8F0, space ? 0xFF2A1A5A : 0xFFD6EEFF);
        if (space) for (int i = 0; i < 20; i++) Skin.rect(g, (i * 37 + 5) % PW, (i * 19 + tm * (tm < land ? 2 : 0) / 3) % PH, 1, 2, 0xFFFFFFFF);
        if (tm >= land - 300) {                                                               // the moon comes up from below
            int my = Math.max(52, 82 - (tm - (land - 300)) / 4);
            Skin.disc(g, 73, my + 40, 52, 0xFFD8D4E8);
            Skin.disc(g, 56, my + 6, 4, 0xFFB8B4CC);
            Skin.disc(g, 94, my + 10, 3, 0xFFB8B4CC);
        } else if (!space) {
            Skin.rect(g, 0, 70, PW, 12, 0xFF6FBF73);                                          // the grass and the launch pad
            Skin.rect(g, 50, 66, 46, 5, 0xFF8A8FA0);
        }
        int rx = 73, ry = tm < launch ? 38 : tm < land ? 38 - Math.min(14, (tm - launch) / 20) + (int) Math.round(Math.sin(tm / 6.0)) : 40 + Math.min(10, (tm - land) / 6);
        if (tm >= launch && tm < launch + 240) ry = 38 - (tm - launch) * 30 / 240 + (int) Math.round(Math.sin(tm / 2.0));   // lift off
        if (tm >= land) rx = 73;
        int shake = tm >= launch - 60 && tm < launch + 240 ? (int) Math.round(Math.sin(tm / 1.2)) : 0;
        rx += shake;
        Skin.rect(g, rx - 7, ry - 8, 14, 26, 0xFFFFE066);                                     // the rocket body is a bee: yellow with stripes
        Skin.rect(g, rx - 7, ry, 14, 3, 0xFF3A2A3A);
        Skin.rect(g, rx - 7, ry + 8, 14, 3, 0xFF3A2A3A);
        Skin.disc(g, rx, ry - 10, 6, 0xFFE5486F);                                             // a red nose cone
        Skin.rect(g, rx - 3, ry - 3, 6, 6, 0xFF9AD8FF);                                       // the window with the bee inside
        Skin.rect(g, rx - 1, ry - 1, 2, 2, 0xFF3A2A3A);
        Skin.rect(g, rx - 12, ry + 10, 5, 10, 0xFFE5486F);                                    // fins
        Skin.rect(g, rx + 7, ry + 10, 5, 10, 0xFFE5486F);
        if (tm >= launch - 60 && tm < land - 200) {                                           // flames
            int fl = 5 + (tm / 2) % 5;
            Skin.rect(g, rx - 4, ry + 18, 8, fl, 0xFFFF9A2A);
            Skin.rect(g, rx - 2, ry + 18, 4, fl + 3, 0xFFFFE066);
            if (tm < launch + 240) for (int k = 0; k < 5; k++) Skin.disc(g, rx - 12 + k * 6, 70 - (tm / 2 + k * 6) % 6, 3 + k % 2, 0x88FFFFFF);   // smoke on the pad
        }
        if (tm >= land) {                                                                     // landed: a flag and a waving bee
            Skin.rect(g, rx + 22, 38, 1, 14, 0xFFEEEEEE);
            Skin.rect(g, rx + 23, 38, 9, 6, 0xFFE5486F);
            Skin.rect(g, rx + 25, 40, 5, 2, 0xFFFFE066);
            if (!thumb) Skin.str(g, font(), "!", rx + 12, 20 + (tm / 12) % 3, 0xFFFFFFFF, true);
        }
        if (!thumb && tm < launch) {                                                          // the countdown
            int num = 10 - tm / 60;
            if (num >= 1) {
                g.pose().pushPose();
                g.pose().translate(110, 8, 0);
                g.pose().scale(3F, 3F, 1F);
                Skin.str(g, font(), Integer.toString(num), 0, 0, 0xFFE5486F, true);
                g.pose().popPose();
            }
        }
        if (!thumb) Skin.str(g, font(), tm < launch ? "T-" + Math.max(0, 10 - tm / 60) : alt < 800 ? "+" + alt / 10 + " km" : "", 4, 4, 0xFF3A2A3A, false);
    }

    // ---------- 18: Slime disco ----------
    private void slimeDisco(GuiGraphics g, int tm) {
        int beat = tm % 30, bn = tm / 30;
        Skin.grad(g, 0, 0, PW, PH, 0xFF14102E, 0xFF3A1A6A);
        int[] lights = {0x44FF5C93, 0x445BD9C8, 0x44FFD84D, 0x44B57BD6};
        for (int i = 0; i < 4; i++) {                                                         // swinging light beams
            int top = 18 + i * 36, sway = (int) Math.round(Math.sin(tm / 40.0 + i * 1.6) * 22);
            for (int y = 10; y < 62; y += 2) Skin.rect(g, top + (y - 10) * sway / 52 - (y - 8) / 6, y, 3 + (y - 10) / 5, 2, lights[(i + bn / 4) % 4]);
        }
        for (int tx = 0; tx < 8; tx++) {                                                      // a floor of pulsing colour tiles
            for (int ty = 0; ty < 2; ty++) {
                int col = ((tx + ty + bn) % 4 == 0) ? 0xFFFF5C93 : ((tx + ty * 2 + bn) % 4 == 1) ? 0xFF5BD9C8 : 0xFF2A2060;
                Skin.rect(g, tx * 18 + 1, 62 + ty * 10, 17, 9, beat < 6 ? col : App.mix(col, 0x000000, 0.35F));
            }
        }
        int bx = 73, by = 14;                                                                  // the disco ball
        Skin.rect(g, bx, 0, 1, by - 6, 0xFFAAAAAA);
        Skin.disc(g, bx, by, 8, 0xFFD8DCF0);
        for (int k = 0; k < 6; k++) Skin.rect(g, bx - 6 + (k * 5 + tm / 6) % 12, by - 6 + (k * 7) % 12, 2, 2, (k + tm / 8) % 3 == 0 ? 0xFFFFFFFF : 0xFF8A8EC0);
        int[] sc = {0xFF7ED957, 0xFF5BC8F0, 0xFFFF7FAF, 0xFFFFD84D};
        for (int i = 0; i < 4; i++) {                                                          // four dancing slimes
            int cx = 20 + i * 34, hop = (int) Math.round(Math.abs(Math.sin((tm + i * 7) % 30 * Math.PI / 30)) * 12);
            boolean sq = beat < 4;
            int w = sq ? 12 : 9, h = sq ? 7 : 10;
            int y = 66 - hop;
            Skin.rect(g, cx - w, y - h, w * 2, h, sc[i]);
            Skin.rect(g, cx - w + 2, y - h - 2, w * 2 - 4, 2, sc[i]);
            Skin.rect(g, cx - w + 3, y - h + 1, 3, 2, 0x66FFFFFF);
            Skin.rect(g, cx - 4, y - h / 2 - 2, 2, 2, 0xFF1A1030);
            Skin.rect(g, cx + 2, y - h / 2 - 2, 2, 2, 0xFF1A1030);
            Skin.rect(g, cx - 2, y - h / 2 + 2, 4, 1, 0xFF1A1030);
            if (beat < 4) Skin.rect(g, cx - w - 2, y - 2, 2, 2, 0xFFFFFFFF);                  // a drop of sweat on the beat
        }
        if (beat < 3) Skin.rect(g, 0, 0, PW, 3, 0x55FFFFFF);                                  // a flash on every beat
    }

    // ---------- 19: Detective Fox and the missing cookie (talking) ----------
    private void detective(GuiGraphics g, int tm) {
        int n = lineAt(19, tm), slot = slot(19), lt = tm - n * slot;
        Skin.grad(g, 0, 0, PW, PH, 0xFF3A3050, 0xFF6A5A7A);
        Skin.rect(g, 0, 56, PW, 26, 0xFF5A3A2A);                                              // the desk
        Skin.rect(g, 0, 56, PW, 2, 0xFF8A5A3A);
        Skin.rect(g, 100, 6, 36, 28, 0xFF2A2440);                                             // a window with the city
        for (int i = 0; i < 6; i++) Skin.rect(g, 102 + i * 6, 14 + (i * 5) % 12, 4, 20 - (i * 5) % 12, 0xFF14102A);
        Skin.rect(g, 108, 18, 2, 2, 0xFFFFE680);
        Skin.rect(g, 124, 22, 2, 2, 0xFFFFE680);
        Skin.rect(g, 12, 40, 2, 16, 0xFF8A8FA0);                                              // the desk lamp
        Skin.rect(g, 8, 36, 10, 5, 0xFFFFD84A);
        Skin.rect(g, 4, 41, 18, 14, 0x18FFE680);
        Skin.rect(g, 104, 46, 14, 10, 0xFFE8F0F8);                                            // the empty cookie jar
        Skin.rect(g, 106, 43, 10, 3, 0xFFC8D8E8);
        if (n >= 1) for (int k = 0; k < 7; k++) Skin.rect(g, 96 + (k * 9) % 36, 57 + (k * 5) % 5, 1, 1, 0xFFD9A55A);   // crumbs
        if (n >= 2) for (int k = 0; k < 5; k++) {                                              // round paw prints leading to the right
            Skin.disc(g, 20 + k * 16, 70 + (k % 2) * 4, 2, 0xFF222222);
            Skin.rect(g, 18 + k * 16, 66 + (k % 2) * 4, 1, 1, 0xFF222222);
            Skin.rect(g, 22 + k * 16, 66 + (k % 2) * 4, 1, 1, 0xFF222222);
        }
        // Fox, the detective
        int fx = 46, fy = 40 + (int) Math.round(Math.sin(tm / 25.0));
        Skin.rect(g, fx - 9, fy + 4, 18, 14, 0xFF6A4A2A);                                     // trench coat
        Skin.rect(g, fx - 2, fy + 4, 4, 14, 0xFFE8D8B0);
        Skin.disc(g, fx, fy, 9, 0xFFF08A3A);                                                  // head
        Skin.disc(g, fx, fy + 4, 5, 0xFFFFF0E0);
        for (int r = 0; r < 7; r++) { Skin.rect(g, fx - 10 + r / 2, fy - 16 + r, 7 - r, 1, 0xFFF08A3A); Skin.rect(g, fx + 4 + r / 2, fy - 16 + r, 7 - r, 1, 0xFFF08A3A); }   // ears
        Skin.rect(g, fx - 3, fy - 2, 2, 2, 0xFF222222);
        Skin.rect(g, fx + 2, fy - 2, 2, 2, 0xFF222222);
        Skin.rect(g, fx - 1, fy + 2, 3, 2, 0xFF222222);
        if (talking(19, tm)) Skin.rect(g, fx - 1, fy + 5, 3, 2, 0xFFE0607A);
        Skin.rect(g, fx - 11, fy - 9, 22, 3, 0xFF4A3A2A);                                     // the detective hat
        Skin.rect(g, fx - 6, fy - 15, 12, 7, 0xFF5A4A3A);
        if (n >= 3) {                                                                         // the magnifier
            int mx = fx + 20 + (int) Math.round(Math.sin(tm / 18.0) * 6), my = fy + 6;
            Skin.rect(g, mx - 10, my + 4, 10, 2, 0xFF6A4A2A);
            Skin.disc(g, mx + 2, my - 2, 7, 0xFF8A6A3A);
            Skin.disc(g, mx + 2, my - 2, 5, 0x88CDEBFF);
        }
        if (n >= 5) {                                                                         // Panda, caught red-pawed
            int px = 128, py = 54;
            Skin.disc(g, px, py, 8, 0xFFFFFFFF);
            Skin.disc(g, px - 6, py - 6, 3, 0xFF222222);
            Skin.disc(g, px + 6, py - 6, 3, 0xFF222222);
            Skin.disc(g, px - 3, py - 1, 2, 0xFF222222);
            Skin.disc(g, px + 3, py - 1, 2, 0xFF222222);
            Skin.rect(g, px - 1, py + 2, 3, 2, 0xFF222222);
            Skin.rect(g, px + 2, py + 2, 2, 1, 0xFFD9A55A);                                   // the crumbs on the nose
            if (n == 5 && lt > 120 || n == 6) Skin.rect(g, px - 7, py + 1, 3, 2, 0xAAFF7FAF);  // blushing
            if (n == 6) Skin.rect(g, px + 10, py - 8 - (lt / 20) % 4, 3, 3, 0xFFD9A55A);     // a happy new cookie
        }
        if (n == 5 && lt < 20) Skin.rect(g, 0, 0, PW, PH, 0x44FFFFFF);                        // the "Gotcha!" flash
        speech(g, 19, tm, false, 0xFFC96A2A);
    }

    // ---------- 20: Ice fishing with Penguin Pete ----------
    private void iceFishing(GuiGraphics g, int tm) {
        Skin.grad(g, 0, 0, PW, 50, 0xFF2A4A8A, 0xFFBFE0FF);
        for (int i = 0; i < 4; i++) {                                                         // a green aurora in the sky
            int y = 6 + i * 4 + (int) Math.round(Math.sin(tm / 50.0 + i) * 2);
            Skin.rect(g, 10 + i * 6, y, PW - 20 - i * 12, 3, 0x2250FFB0);
        }
        Skin.rect(g, 0, 50, PW, 32, 0xFFE8F4FF);                                              // the ice
        Skin.rect(g, 0, 50, PW, 2, 0xFFFFFFFF);
        for (int i = 0; i < 14; i++) Skin.rect(g, (i * 37 + 5) % PW, 56 + (i * 11) % 24, 8 + i % 5, 1, 0x33A8C8E8);   // cracks
        int hx = 90, hy = 64;                                                                  // the fishing hole
        Skin.rect(g, hx - 14, hy - 4, 28, 10, 0xFF1A3A6A);
        Skin.rect(g, hx - 12, hy - 5, 24, 1, 0xFF1A3A6A);
        Skin.rect(g, hx - 14, hy - 5, 28, 1, 0xFFC8E0F4);
        int cyc = tm % 450, round = tm / 450;
        boolean bite = cyc >= 280 && cyc < 380;
        int fishX = hx - 40 + (cyc * 80 / 450);                                                // a shadow swims under
        if (cyc < 280) Skin.rect(g, fishX, hy - 1, 7, 3, 0xAA0A2A4A);
        // Pete
        int px = 42, py = 46, wob = (int) Math.round(Math.sin(tm / 30.0));
        Skin.disc(g, px, py, 10, 0xFF2A3A5A);                                                  // body
        Skin.disc(g, px, py + 3, 6, 0xFFFFFFFF);
        Skin.disc(g, px, py - 12, 8, 0xFF2A3A5A);                                              // head
        Skin.rect(g, px - 3, py - 13, 2, 2, 0xFFFFFFFF);
        Skin.rect(g, px + 2, py - 13, 2, 2, 0xFFFFFFFF);
        Skin.rect(g, px - 1, py - 10, 4, 2, 0xFFFFA23A);                                       // beak
        Skin.rect(g, px - 9, py - 20, 18, 3, 0xFFE5486F);                                      // a woolly hat
        Skin.rect(g, px - 7, py - 24, 14, 4, 0xFFE5486F);
        Skin.disc(g, px, py - 25, 2, 0xFFFFFFFF);
        Skin.rect(g, px - 3, py + 10, 6, 3, 0xFFFFA23A);                                       // feet
        Skin.rect(g, px + 6, py - 2, 22, 2, 0xFFC98A5A);                                       // the rod
        int tipX = px + 28, tipY = py - 2;
        int bobY = hy - 8 + (bite ? 5 + (int) Math.round(Math.abs(Math.sin(cyc / 4.0)) * 4) : wob);
        Skin.rect(g, tipX, tipY, 1, Math.max(1, bobY - tipY), 0xAAFFFFFF);                     // the line to the hole
        Skin.rect(g, hx - 1 + (bite ? 0 : 0), bobY, 3, 3, 0xFFE5486F);                         // the bobber
        if (cyc >= 380 && cyc < 450) {                                                         // the catch: a boot the first times, a big fish the third
            int up = Math.min(24, (cyc - 380) * 2);
            boolean big = round % 3 == 2;
            if (big) {
                Skin.disc(g, hx, hy - up, 6, 0xFF5BC8F0);
                Skin.rect(g, hx + 4, hy - up - 3, 6, 6, 0xFF5BC8F0);
                Skin.rect(g, hx - 3, hy - up - 2, 2, 2, 0xFF1A1030);
            } else {
                Skin.rect(g, hx - 4, hy - up - 8, 7, 9, 0xFF8A5A3A);
                Skin.rect(g, hx - 4, hy - up, 12, 4, 0xFF8A5A3A);
            }
            if (!thumb && up > 16) Skin.str(g, font(), big ? "!!" : "?", px + 12, py - 30, 0xFF3A2A3A, false);
            for (int k = 0; k < 4; k++) Skin.rect(g, hx - 10 + k * 6, hy - 6 - (cyc / 3 + k * 3) % 8, 1, 2, 0xFFBFE0FF);   // splashing drops
        }
        for (int i = 0; i < 16; i++) Skin.rect(g, (i * 53 + tm / 3) % PW, (i * 31 + tm / 2) % 70, 1, 1, 0xCCFFFFFF);   // snow
    }
}
