package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import java.util.HashMap;
import java.util.Map;

/**
 * The pictures of the fairy tale book, drawn with rectangles and discs (no image files). A picture is a text:
 * {@code "day;sun@100,12;tree@14,56;swan@60,58,130"}: the first word is the background, then the things, back to front.
 * A thing is {@code name@x,y} or {@code name@x,y,size} (size in percent). Its (x, y) is where it stands, bottom centre.
 * A name ending with "&lt;" looks to the left. The picture is {@link #W} x {@link #H}; the ground is at {@link #GROUND}.
 */
public final class BookArt {
    private BookArt() {}

    public static final int W = 120, H = 74, GROUND = 54;

    private static final int SKIN = 0xFFFFD9B8, SKIN_D = 0xFFE8B890, INK = 0xFF3A2A3A, GOLD = 0xFFFFC832, WHITE = 0xFFFFFFFF;

    // ---------- tiny drawing helpers ----------
    // The picture is drawn with its own transform (origin and size of the thing being drawn) and is cut off at the edge of the
    // picture, so nothing can ever stick out of its frame. Drawing is done on the render thread only.
    private static float ox, oy, sc = 1F;
    private static int clipX0, clipY0, clipX1, clipY1;
    private static boolean clipOn, inScene;

    private static void r(GuiGraphics g, int x, int y, int w, int h, int c) {
        int x0 = Math.round(ox + x * sc), y0 = Math.round(oy + y * sc), x1 = Math.round(ox + (x + w) * sc), y1 = Math.round(oy + (y + h) * sc);
        if (w > 0 && x1 <= x0) x1 = x0 + 1;                    // a thin line stays visible when the thing is small
        if (h > 0 && y1 <= y0) y1 = y0 + 1;
        if (clipOn) { x0 = Math.max(x0, clipX0); y0 = Math.max(y0, clipY0); x1 = Math.min(x1, clipX1); y1 = Math.min(y1, clipY1); }
        if (x1 > x0 && y1 > y0) g.fill(x0, y0, x1, y1, c);
    }

    private static void d(GuiGraphics g, int cx, int cy, int rad, int c) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            r(g, cx - dx, cy + dy, dx * 2 + 1, 1, c);
        }
    }

    private static void e(GuiGraphics g, int cx, int cy, int rx, int ry, int c) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0, 1.0 - (double) dy * dy / (ry * ry + 0.25))));
            r(g, cx - dx, cy + dy, dx * 2 + 1, 1, c);
        }
    }

    /** A triangle with its tip up: x, y = top left of its box. */
    private static void tri(GuiGraphics g, int x, int y, int w, int h, int c) {
        for (int i = 0; i < h; i++) {
            int ww = Math.max(1, w * (i + 1) / h);
            r(g, x + (w - ww) / 2, y + i, ww, 1, c);
        }
    }

    private static int mix(int a, int b, float t) {
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
        return 0xFF000000 | (int) (ar + (br - ar) * t) << 16 | (int) (ag + (bg - ag) * t) << 8 | (int) (ab + (bb - ab) * t);
    }

    private static void grad(GuiGraphics g, int x, int y, int w, int h, int top, int bot) {
        for (int i = 0; i < h; i++) r(g, x, y + i, w, 1, mix(top, bot, h <= 1 ? 0 : i / (float) (h - 1)));
    }

    // ---------- looking left or right: the animals are written looking right ----------
    private static void fr(GuiGraphics g, int f, int x, int y, int w, int h, int c) { r(g, f > 0 ? x : -x - w, y, w, h, c); }

    private static void fd(GuiGraphics g, int f, int cx, int cy, int rad, int c) { d(g, f * cx, cy, rad, c); }

    private static void fe(GuiGraphics g, int f, int cx, int cy, int rx, int ry, int c) { e(g, f * cx, cy, rx, ry, c); }

    private static void ftri(GuiGraphics g, int f, int x, int y, int w, int h, int c) { tri(g, f > 0 ? x : -x - w, y, w, h, c); }

    // ---------- backgrounds ----------
    private static void background(GuiGraphics g, String bg) {
        switch (bg) {
            case "dusk" -> {
                grad(g, 0, 0, W, GROUND, 0xFFFF9A7A, 0xFFFFE2B0);
                r(g, 0, GROUND, W, H - GROUND, 0xFF4F8F50);
                r(g, 0, GROUND, W, 1, 0xFF3C7A3E);
            }
            case "night" -> {
                grad(g, 0, 0, W, GROUND, 0xFF12163A, 0xFF34437E);
                r(g, 0, GROUND, W, H - GROUND, 0xFF2C5A44);
                r(g, 0, GROUND, W, 1, 0xFF1E4634);
                int[] st = {6, 8, 22, 18, 40, 6, 58, 20, 76, 9, 92, 24, 110, 12, 14, 34, 66, 36, 104, 38};
                for (int i = 0; i < st.length; i += 2) r(g, st[i], st[i + 1], 1, 1, 0xFFFFF3B0);
            }
            case "sea" -> {
                grad(g, 0, 0, W, 30, 0xFF9AD8FF, 0xFFD8F2FF);
                grad(g, 0, 30, W, H - 30, 0xFF4FA8E0, 0xFF1E5FA8);
                for (int y = 34; y < H; y += 8) for (int x = (y / 8 % 2) * 6; x < W; x += 12) r(g, x, y, 5, 1, 0x66FFFFFF);
            }
            case "deep" -> {
                grad(g, 0, 0, W, 60, 0xFF3A8FD0, 0xFF0E3A78);
                r(g, 0, 60, W, H - 60, 0xFFE8D090);
                r(g, 0, 60, W, 1, 0xFFC8B070);
                for (int i = 0; i < 6; i++) r(g, 8 + i * 20, 20 + (i * 17) % 28, 1, 8, 0x22FFFFFF);
            }
            case "forest" -> {
                grad(g, 0, 0, W, GROUND + 2, 0xFF9AD890, 0xFF3C8A4A);
                for (int i = 0; i < 6; i++) {
                    int x = 4 + i * 21;
                    r(g, x, 0, 5, GROUND + 2, 0xFF2E6A38);
                    d(g, x + 2, 4 + (i % 3) * 3, 9, 0xFF3C8A4A);
                }
                r(g, 0, GROUND, W, H - GROUND, 0xFF4A7A3A);
                r(g, 28, GROUND, 40, 3, 0xFFB89A62);
                r(g, 20, GROUND + 3, 60, 4, 0xFFB89A62);
            }
            case "room" -> {
                r(g, 0, 0, W, 52, 0xFFFFE6D0);
                for (int x = 0; x < W; x += 12) r(g, x, 0, 6, 52, 0xFFFFDCC0);
                r(g, 0, 52, W, H - 52, 0xFFC8905A);
                for (int x = 0; x < W; x += 14) r(g, x, 52, 1, H - 52, 0xFFA8703A);
                r(g, 0, 52, W, 2, 0xFF8A5A3A);
            }
            case "hall" -> {
                r(g, 0, 0, W, 50, 0xFFB8A0D8);
                for (int x = 6; x + 14 <= W - 2; x += 26) { r(g, x, 6, 14, 30, 0xFFD8C8F0); r(g, x + 1, 7, 12, 28, 0xFF9AD0F0); d(g, x + 7, 6, 7, 0xFFD8C8F0); d(g, x + 7, 7, 6, 0xFF9AD0F0); }
                r(g, 0, 50, W, H - 50, 0xFFC8B0E0);
                for (int y = 50; y < H; y += 8) for (int x = 0; x < W; x += 8) if ((x / 8 + y / 8) % 2 == 0) r(g, x, y, 8, Math.min(8, H - y), 0xFFE8D8F0);
                r(g, 0, 48, W, 2, 0xFFFFC832);
            }
            case "storm" -> {
                grad(g, 0, 0, W, 34, 0xFF4A5468, 0xFF8A94A8);
                grad(g, 0, 34, W, H - 34, 0xFF3A5A7A, 0xFF16304A);
                for (int y = 38; y < H; y += 7) for (int x = (y / 7 % 2) * 7; x < W; x += 14) r(g, x, y, 7, 1, 0x88C8D8E8);
            }
            case "snow" -> {
                grad(g, 0, 0, W, GROUND, 0xFFB8D0EC, 0xFFEFF6FF);
                r(g, 0, GROUND, W, H - GROUND, 0xFFF8FCFF);
                r(g, 0, GROUND, W, 1, 0xFFC8D8EC);
                r(g, 0, GROUND + 6, W, 1, 0xFFE0ECF8);
            }
            default -> { // "day"
                grad(g, 0, 0, W, GROUND, 0xFF8FD3FF, 0xFFDDF4FF);
                r(g, 0, GROUND, W, H - GROUND, 0xFF7BCB6A);
                r(g, 0, GROUND, W, 1, 0xFF5BAF52);
                r(g, 0, GROUND + 8, W, 1, 0xFF6CBF5C);
            }
        }
    }

    // ---------- people ----------
    /** A standing person: (0, 0) = the feet. dress = the colour of the dress or tunic, long = long hair, skirt = a skirt. */
    private static void person(GuiGraphics g, int dress, int hair, boolean longHair, boolean skirt) {
        if (longHair) r(g, -5, -28, 10, 14, hair);
        r(g, -3, -6, 2, 6, SKIN_D);
        r(g, 1, -6, 2, 6, SKIN_D);
        if (skirt) tri(g, -7, -20, 14, 15, dress);
        else { r(g, -4, -20, 8, 10, dress); r(g, -4, -10, 3, 5, mix(dress, 0xFF000000, 0.25F)); r(g, 1, -10, 3, 5, mix(dress, 0xFF000000, 0.25F)); }
        r(g, -6, -19, 2, 7, dress);
        r(g, 4, -19, 2, 7, dress);
        r(g, -6, -13, 2, 2, SKIN);
        r(g, 4, -13, 2, 2, SKIN);
        d(g, 0, -25, 5, SKIN);
        if (!longHair) { r(g, -5, -30, 10, 4, hair); r(g, -5, -27, 2, 3, hair); r(g, 3, -27, 2, 3, hair); }
        else r(g, -5, -30, 10, 4, hair);
        r(g, -2, -25, 1, 1, INK);
        r(g, 1, -25, 1, 1, INK);
        r(g, -1, -22, 2, 1, 0xFFE0707A);
        r(g, -4, -23, 1, 1, 0x66FF7A8A);
        r(g, 3, -23, 1, 1, 0x66FF7A8A);
    }

    private static void crown(GuiGraphics g, int x, int y) {
        r(g, x - 4, y, 9, 3, GOLD);
        r(g, x - 4, y - 2, 2, 2, GOLD);
        r(g, x - 1, y - 3, 2, 3, GOLD);
        r(g, x + 3, y - 2, 2, 2, GOLD);
        r(g, x, y + 1, 1, 1, 0xFFE5484D);
    }

    private static void beard(GuiGraphics g, int color) {
        r(g, -4, -22, 8, 3, color);
        r(g, -3, -19, 6, 3, color);
        r(g, -1, -16, 2, 2, color);
    }

    private static void drawPerson(GuiGraphics g, String kind) {
        switch (kind) {
            case "princess" -> { person(g, 0xFFFF9AC8, 0xFFF3C860, true, true); crown(g, 0, -31); }
            case "prince" -> { person(g, 0xFF5A7AE8, 0xFF8A5A3A, false, false); crown(g, 0, -31); r(g, -4, -19, 8, 2, GOLD); }
            case "redhood" -> {
                person(g, 0xFFE5484D, 0xFF8A5A3A, true, true);
                tri(g, -8, -32, 16, 14, 0xFFE5484D);                       // the red hood
                r(g, -4, -29, 8, 7, SKIN); r(g, -2, -26, 1, 1, INK); r(g, 1, -26, 1, 1, INK); r(g, -1, -23, 2, 1, 0xFFE0707A);
                r(g, 6, -12, 7, 5, 0xFFB07A3A); r(g, 7, -14, 5, 2, 0xFF8A5A2A); r(g, 7, -12, 5, 1, WHITE);   // a basket
            }
            case "grandma" -> {
                person(g, 0xFFB07AC8, 0xFFDDDDE6, false, true);
                r(g, -5, -31, 10, 4, 0xFFFFFFFF); d(g, 0, -33, 3, 0xFFDDDDE6);                          // a cap and a bun
                r(g, -3, -26, 2, 2, 0xFF6A5A8A); r(g, 1, -26, 2, 2, 0xFF6A5A8A);                        // glasses
                r(g, -7, -17, 14, 3, 0xFF8A5AA8);
            }
            case "oldman" -> {
                person(g, 0xFF6A7A8A, 0xFFEEEEF4, false, false);
                beard(g, 0xFFEEEEF4);
                r(g, -6, -31, 12, 3, 0xFF8A5A3A); r(g, -4, -34, 8, 4, 0xFF8A5A3A);
            }
            case "oldwoman" -> {
                person(g, 0xFF9A6A4A, 0xFFDDDDE6, false, true);
                r(g, -5, -31, 10, 3, 0xFFE0607A); r(g, -5, -29, 2, 5, 0xFFE0607A); r(g, 3, -29, 2, 5, 0xFFE0607A);
                r(g, -7, -17, 14, 3, 0xFFB0805A);
            }
            case "witch" -> {
                person(g, 0xFF3A2A5A, 0xFF8A8A9A, true, true);
                d(g, 0, -25, 5, 0xFF9AD08A); r(g, -2, -25, 1, 1, INK); r(g, 1, -25, 1, 1, INK); r(g, 0, -23, 1, 3, 0xFF6AA05A);
                r(g, -8, -31, 16, 2, 0xFF2A1A44); tri(g, -5, -43, 10, 12, 0xFF2A1A44); r(g, -5, -33, 10, 2, 0xFFB57BD6);
                r(g, 8, -24, 1, 24, 0xFF8A5A3A);                                                    // a stick
            }
            case "hansel" -> { person(g, 0xFF6AAE5A, 0xFF8A5A3A, false, false); }
            case "gretel" -> { person(g, 0xFFE0607A, 0xFFF3C860, true, true); r(g, -6, -29, 2, 8, 0xFFF3C860); r(g, 4, -29, 2, 8, 0xFFF3C860); r(g, -6, -22, 2, 2, 0xFFE0607A); r(g, 4, -22, 2, 2, 0xFFE0607A); }
            case "snowwhite" -> {
                person(g, 0xFFFFD84A, 0xFF1A1A22, false, true);
                r(g, -4, -19, 8, 5, 0xFF4A7AE0); r(g, -6, -30, 4, 3, 0xFFE5484D); r(g, -5, -29, 1, 1, WHITE);
            }
            case "queen" -> { person(g, 0xFF5A2A7A, 0xFF1A1A22, true, true); crown(g, 0, -31); r(g, -4, -19, 8, 3, 0xFF8A4AB0); }
            case "dwarf" -> {
                person(g, 0xFF4A7AE0, 0xFFB07A3A, false, false);
                beard(g, 0xFFEEEEF4);
                tri(g, -6, -41, 12, 12, 0xFFE5484D); r(g, -6, -31, 12, 2, 0xFFE5484D);
            }
            case "cinderella" -> {
                person(g, 0xFF8AD0F8, 0xFFF3C860, false, true);
                r(g, -4, -29, 8, 2, 0xFFF3C860); d(g, 0, -32, 3, 0xFFF3C860);
                r(g, -7, -9, 14, 2, 0xFFD8F0FF); r(g, -2, -19, 4, 3, 0xFFFFFFFF);
            }
            case "cinderella_rag" -> {
                person(g, 0xFF9A9A8A, 0xFFF3C860, false, true);
                r(g, -5, -31, 10, 3, 0xFFB07A5A); r(g, -7, -9, 3, 2, 0xFF6A6A5A); r(g, 2, -12, 3, 2, 0xFF6A6A5A);
            }
            case "fairy" -> {
                e(g, -11, -22, 6, 9, 0xAAF0E4FF); e(g, 11, -22, 6, 9, 0xAAF0E4FF);                   // wings
                person(g, 0xFFB8A0F0, 0xFFE8E8F8, true, true);
                r(g, 8, -26, 1, 14, 0xFFB07A3A); r(g, 6, -29, 5, 5, GOLD); r(g, 7, -30, 3, 7, GOLD);   // a wand with a star
            }
            case "king" -> {
                person(g, 0xFFE5484D, 0xFFB8B8C8, false, true);
                beard(g, 0xFFB8B8C8); crown(g, 0, -31); r(g, -6, -19, 12, 2, WHITE);
            }
            case "ogre" -> {
                e(g, 0, -12, 10, 12, 0xFF6A9A4A); d(g, 0, -28, 8, 0xFF7AAA5A);
                r(g, -4, -31, 3, 3, 0xFFFFFF99); r(g, 1, -31, 3, 3, 0xFFFFFF99); r(g, -3, -30, 1, 1, INK); r(g, 2, -30, 1, 1, INK);
                r(g, -4, -24, 8, 2, 0xFF3A2A2A); r(g, -4, -26, 1, 3, WHITE); r(g, 3, -26, 1, 3, WHITE);
                r(g, -10, -14, 20, 4, 0xFF5A3A2A);
            }
            case "thumbelina" -> { person(g, 0xFFFF9AC8, 0xFFF3C860, true, true); }
            default -> { }
        }
    }

    // ---------- animals (written looking right, f = 1, or left, f = -1) ----------
    private static void quad(GuiGraphics g, int f, int body, int dark, int ear, boolean longEars) {
        fr(g, f, -7, -7, 3, 7, dark); fr(g, f, -2, -7, 3, 7, dark); fr(g, f, 3, -7, 3, 7, dark); fr(g, f, 7, -7, 3, 7, dark);
        fe(g, f, 0, -11, 11, 6, body);
        fd(g, f, 10, -16, 5, body);
        fr(g, f, 12, -15, 5, 4, mix(body, WHITE, 0.25F));
        fr(g, f, 16, -15, 2, 2, INK);
        fr(g, f, 11, -18, 1, 2, INK);
        if (longEars) { fr(g, f, 7, -29, 3, 12, body); fr(g, f, 11, -28, 3, 11, dark); fr(g, f, 8, -27, 1, 9, ear); }
        else { ftri(g, f, 7, -23, 4, 5, dark); ftri(g, f, 11, -23, 4, 5, dark); }
    }

    private static void drawAnimal(GuiGraphics g, String kind, int f) {
        switch (kind) {
            case "wolf" -> {
                quad(g, f, 0xFF8A8A9A, 0xFF6A6A7A, 0xFFFFB0B0, false);
                fr(g, f, -14, -14, 5, 3, 0xFF8A8A9A); fr(g, f, -17, -12, 4, 3, 0xFF6A6A7A);
                fr(g, f, 15, -12, 3, 2, 0xFFE5484D); fr(g, f, 15, -13, 1, 1, WHITE);
            }
            case "fox" -> {
                quad(g, f, 0xFFF08A2A, 0xFF8A4A1A, 0xFFFFD0A0, false);
                fr(g, f, -18, -14, 9, 6, 0xFFF08A2A); fr(g, f, -20, -12, 4, 4, WHITE); fr(g, f, 12, -14, 5, 3, WHITE);
            }
            case "dog" -> {
                quad(g, f, 0xFFB8864E, 0xFF8A5A2A, 0xFF8A5A2A, false);
                fr(g, f, 5, -22, 3, 7, 0xFF8A5A2A); fr(g, f, -14, -17, 4, 7, 0xFFB8864E); fr(g, f, 17, -16, 2, 2, INK);
            }
            case "cat" -> {
                quad(g, f, 0xFF9A9AAA, 0xFF7A7A8A, 0xFFFFB0C0, false);
                fr(g, f, -16, -22, 3, 12, 0xFF9A9AAA); fr(g, f, 11, -13, 1, 2, WHITE); fr(g, f, 16, -14, 4, 1, WHITE);
            }
            case "puss" -> {                                   // the cat in boots, with a hat and a feather
                quad(g, f, 0xFFF0903A, 0xFFB86A1A, 0xFFFFB0C0, false);
                fr(g, f, -16, -22, 3, 12, 0xFFF0903A);
                for (int bx : new int[]{-7, -2, 3, 7}) fr(g, f, bx, -5, 3, 5, 0xFF6A3A1A);
                fr(g, f, 5, -27, 12, 2, 0xFF3A2A5A); fr(g, f, 7, -31, 8, 4, 0xFF3A2A5A); fr(g, f, 13, -36, 1, 6, 0xFFE5484D);
            }
            case "donkey" -> {
                quad(g, f, 0xFF9A9AA6, 0xFF7A7A86, 0xFFE8C8C8, true);
                fr(g, f, 14, -14, 5, 5, 0xFFE8E8EE); fr(g, f, 8, -20, 6, 2, 0xFF6A6A76); fr(g, f, -14, -13, 3, 6, 0xFF6A6A76);
            }
            case "hare" -> {
                quad(g, f, 0xFFE8E8EE, 0xFFB8B8C6, 0xFFFFB0C0, true);
                fr(g, f, -13, -14, 4, 4, WHITE); fr(g, f, 16, -14, 2, 2, 0xFFE5484D);
            }
            case "bear" -> {
                quad(g, f, 0xFF8A5A3A, 0xFF6A3A2A, 0xFF6A3A2A, false);
                fe(g, f, 0, -13, 13, 9, 0xFF8A5A3A); fr(g, f, 14, -14, 5, 4, 0xFFC8946A);
            }
            case "rooster" -> {
                fe(g, f, 0, -9, 7, 8, 0xFFE8742A);
                fd(g, f, 6, -19, 4, 0xFFE8742A);
                fr(g, f, 5, -25, 3, 3, 0xFFE5484D); fr(g, f, 9, -19, 3, 2, GOLD); fr(g, f, 9, -17, 2, 2, 0xFFE5484D); fr(g, f, 7, -20, 1, 1, INK);
                fr(g, f, -12, -20, 3, 14, 0xFF2E9A78); fr(g, f, -10, -22, 3, 14, 0xFF3A6AE0); fr(g, f, -8, -17, 3, 10, 0xFFE5484D);
                fr(g, f, -2, -2, 1, 2, GOLD); fr(g, f, 2, -2, 1, 2, GOLD);
            }
            case "duck" -> {
                fe(g, f, 0, -5, 9, 5, 0xFFF8E8A0);
                fd(g, f, 8, -12, 4, 0xFFF8E8A0);
                fr(g, f, 11, -12, 4, 2, 0xFFFF9A2A); fr(g, f, 9, -14, 1, 1, INK); fr(g, f, -3, -6, 7, 3, 0xFFE8D880);
            }
            case "duckling" -> {
                fe(g, f, 0, -5, 7, 5, 0xFF9A9080);
                fd(g, f, 6, -11, 4, 0xFF9A9080);
                fr(g, f, 9, -11, 3, 2, 0xFFFF9A2A); fr(g, f, 7, -13, 1, 1, INK); fr(g, f, -3, -6, 5, 2, 0xFF7A7060);
            }
            case "ducklings" -> {
                for (int i = 0; i < 3; i++) { fe(g, f, -10 + i * 9, -3, 4, 3, 0xFFFFE680); fd(g, f, -7 + i * 9, -7, 2, 0xFFFFE680); fr(g, f, -5 + i * 9, -7, 2, 1, 0xFFFF9A2A); }
            }
            case "swan" -> {
                fe(g, f, 0, -7, 11, 6, WHITE);
                fr(g, f, -12, -12, 5, 4, WHITE); fe(g, f, -3, -9, 6, 3, 0xFFE8F0FF);
                for (int i = 0; i < 12; i++) fr(g, f, 8 + (i < 7 ? 0 : (i - 6)), -10 - i, 3, 2, WHITE);   // the neck
                fd(g, f, 13, -22, 3, WHITE);
                fr(g, f, 15, -22, 4, 2, 0xFFFF9A2A); fr(g, f, 13, -23, 1, 1, INK);
            }
            case "swallow" -> {
                fe(g, f, 0, -4, 6, 3, 0xFF2A3A8A);
                fd(g, f, 6, -6, 3, 0xFF2A3A8A);
                fr(g, f, 8, -6, 3, 2, GOLD); fr(g, f, 5, -7, 1, 1, WHITE); fr(g, f, 3, -3, 4, 2, WHITE);
                fr(g, f, -9, -4, 6, 1, 0xFF2A3A8A); fr(g, f, -9, -2, 6, 1, 0xFF2A3A8A); fr(g, f, -2, -9, 6, 3, 0xFF3A4AA8);
            }
            case "toad" -> {
                fe(g, f, 0, -5, 8, 5, 0xFF6AA05A);
                fd(g, f, 4, -11, 2, 0xFF8AC070); fd(g, f, -2, -11, 2, 0xFF8AC070);
                fr(g, f, 4, -11, 1, 1, INK); fr(g, f, -2, -11, 1, 1, INK); fr(g, f, -4, -3, 9, 1, 0xFF3A6A3A);
                fr(g, f, -2, -8, 2, 1, 0xFF4A7A3A); fr(g, f, 3, -7, 2, 1, 0xFF4A7A3A);
            }
            case "mouse" -> {
                fe(g, f, 0, -3, 5, 3, 0xFFB8B8C6); fd(g, f, 5, -4, 2, 0xFFB8B8C6); fd(g, f, 4, -7, 2, 0xFFFFB0C0);
                fr(g, f, -9, -2, 5, 1, 0xFFFFB0C0); fr(g, f, 6, -5, 1, 1, INK);
            }
            default -> { }
        }
    }

    private static boolean isPerson(String k) {
        return switch (k) {
            case "princess", "prince", "redhood", "grandma", "oldman", "oldwoman", "witch", "hansel", "gretel", "snowwhite", "queen",
                 "dwarf", "cinderella", "cinderella_rag", "fairy", "king", "ogre", "thumbelina" -> true;
            default -> false;
        };
    }

    // ---------- things ----------
    private static void thing(GuiGraphics g, String k, int f) {
        if (isPerson(k)) { drawPerson(g, k); return; }
        switch (k) {
            case "sun" -> {
                d(g, 0, -7, 7, 0xFFFFD84A); d(g, 0, -7, 5, 0xFFFFE680);
                for (int i = 0; i < 8; i++) { double a = i * Math.PI / 4; r(g, (int) Math.round(Math.cos(a) * 11) - 1, -7 + (int) Math.round(Math.sin(a) * 11) - 1, 2, 2, 0xFFFFD84A); }
            }
            case "moon" -> { d(g, 0, -7, 7, 0xFFFFF3C0); d(g, -2, -9, 1, 0xFFE8D890); d(g, 2, -5, 2, 0xFFE8D890); d(g, 3, -10, 1, 0xFFE8D890); }
            case "star" -> { r(g, 0, -4, 1, 3, 0xFFFFE680); r(g, -1, -3, 3, 1, 0xFFFFE680); }
            case "cloud" -> { d(g, -6, -4, 4, WHITE); d(g, 0, -6, 6, WHITE); d(g, 7, -4, 4, WHITE); r(g, -8, -4, 17, 4, WHITE); r(g, -8, -1, 17, 1, 0xFFE0ECF8); }
            case "tree" -> {
                r(g, -2, -14, 4, 14, 0xFF7A4A2A);
                d(g, 0, -24, 9, 0xFF4FAE4E); d(g, -7, -18, 6, 0xFF4FAE4E); d(g, 7, -18, 6, 0xFF4FAE4E); d(g, -2, -27, 4, 0xFF6AC86A);
            }
            case "pine" -> {
                r(g, -1, -6, 3, 6, 0xFF6A4A2A);
                tri(g, -9, -16, 18, 12, 0xFF2E7A4A); tri(g, -7, -25, 14, 11, 0xFF2E7A4A); tri(g, -5, -33, 10, 10, 0xFF2E7A4A);
                r(g, -2, -33, 4, 2, WHITE); r(g, -4, -24, 8, 2, WHITE); r(g, -6, -15, 12, 2, WHITE);
            }
            case "bush" -> { d(g, -5, -4, 5, 0xFF3FA04A); d(g, 4, -5, 6, 0xFF4FB85A); d(g, 0, -7, 4, 0xFF5FC86A); }
            case "flower" -> {
                r(g, 0, -10, 1, 10, 0xFF3FA04A); r(g, -3, -4, 3, 1, 0xFF3FA04A);
                d(g, -2, -12, 2, 0xFFFF8AB8); d(g, 3, -12, 2, 0xFFFF8AB8); d(g, 0, -15, 2, 0xFFFF8AB8); d(g, 0, -10, 2, 0xFFFF8AB8); d(g, 0, -12, 1, 0xFFFFE680);
            }
            case "bigflower" -> {
                r(g, -1, -20, 3, 20, 0xFF3FA04A); tri(g, 1, -9, 8, 5, 0xFF3FA04A);
                e(g, 0, -26, 9, 7, 0xFFFF6AA0); e(g, 0, -22, 8, 5, 0xFFFF8AB8); r(g, -7, -26, 14, 1, 0xFFFFB0D0);
            }
            case "pond" -> { e(g, 0, -4, 22, 5, 0xFF8AD0F0); e(g, 0, -4, 19, 4, 0xFF5FB8F0); r(g, -10, -5, 6, 1, 0x88FFFFFF); r(g, 4, -3, 5, 1, 0x88FFFFFF); }
            case "reeds" -> { for (int i = 0; i < 3; i++) { r(g, -4 + i * 4, -16 + i, 1, 16 - i, 0xFF5A8A3A); r(g, -5 + i * 4, -18 + i, 3, 5, 0xFF8A5A2A); } }
            case "cottage" -> {
                r(g, -14, -17, 28, 17, 0xFFF3DDB0); tri(g, -18, -31, 36, 14, 0xFFC4523A);
                r(g, -3, -12, 6, 12, 0xFF7A4A2A); r(g, -11, -13, 6, 6, 0xFFA8D8FF); r(g, 6, -13, 6, 6, 0xFFA8D8FF);
                r(g, -8, -13, 1, 6, 0xFFB07A3A); r(g, 9, -13, 1, 6, 0xFFB07A3A); r(g, 8, -33, 4, 8, 0xFF8A6A5A);
            }
            case "glowhouse" -> {
                r(g, -14, -17, 28, 17, 0xFF8A6A5A); tri(g, -18, -31, 36, 14, 0xFF4A3A4A);
                r(g, -3, -12, 6, 12, 0xFF3A2A2A); r(g, -11, -14, 8, 8, 0xFFFFE680); r(g, -8, -14, 1, 8, 0xFF8A6A3A); r(g, -11, -11, 8, 1, 0xFF8A6A3A);
                r(g, 6, -13, 6, 6, 0xFF4A3A3A);
            }
            case "candyhouse" -> {
                r(g, -15, -18, 30, 18, 0xFFC88A4A); tri(g, -19, -33, 38, 15, 0xFFFF8AB8);
                for (int i = 0; i < 5; i++) { r(g, -17 + i * 8, -22 + (i % 2) * 2, 4, 2, WHITE); r(g, -13 + i * 8, -26 + (i % 2) * 2, 2, 4, 0xFF8AE0C0); }
                r(g, -4, -13, 8, 13, 0xFF6A3A1A); for (int i = 0; i < 6; i++) r(g, -4, -13 + i * 2, 8, 1, i % 2 == 0 ? 0xFFE5484D : WHITE);
                d(g, -10, -9, 3, 0xFFFFE680); d(g, 11, -9, 3, 0xFF8AD0F8); r(g, -11, -6, 2, 3, WHITE); r(g, 10, -6, 2, 3, WHITE);
            }
            case "castle" -> {
                r(g, -18, -26, 36, 26, 0xFFE8D8F0); r(g, -24, -36, 10, 36, 0xFFD8C8E8); r(g, 14, -36, 10, 36, 0xFFD8C8E8); r(g, -5, -40, 10, 40, 0xFFD8C8E8);
                tri(g, -26, -50, 14, 14, 0xFFFF6AA0); tri(g, 12, -50, 14, 14, 0xFFFF6AA0); tri(g, -7, -54, 14, 14, 0xFFFF6AA0);
                r(g, 0, -62, 1, 8, 0xFF7A4A2A); r(g, 1, -62, 5, 3, 0xFFE5484D);
                r(g, -4, -12, 8, 12, 0xFF7A4A2A); d(g, 0, -12, 4, 0xFF7A4A2A);
                r(g, -21, -28, 4, 6, 0xFF9AD0F0); r(g, 17, -28, 4, 6, 0xFF9AD0F0); r(g, -2, -34, 4, 6, 0xFF9AD0F0);
                for (int i = 0; i < 4; i++) r(g, -18 + i * 10, -29, 6, 3, 0xFFE8D8F0);
            }
            case "hill" -> { e(g, 0, -2, 40, 14, 0xFF6AC05A); e(g, -8, -6, 24, 9, 0xFF7BCB6A); }
            case "rock" -> { e(g, 0, -5, 9, 6, 0xFF8A8A9A); e(g, -2, -7, 5, 3, 0xFFA8A8B8); }
            case "boat" -> { tri(g, -1, -28, 12, 22, 0xFFFFF3D0); r(g, -2, -28, 1, 26, 0xFF7A4A2A); r(g, -12, -6, 26, 5, 0xFF8A5A3A); r(g, -10, -2, 22, 2, 0xFF6A3A1A); }
            case "ship" -> {
                r(g, -1, -36, 2, 34, 0xFF7A4A2A); tri(g, 1, -36, 14, 24, WHITE); tri(g, -15, -32, 14, 20, 0xFFF3E8D0);
                r(g, -18, -8, 38, 6, 0xFF8A5A3A); r(g, -14, -2, 30, 3, 0xFF6A3A1A); r(g, -2, -40, 6, 3, 0xFFE5484D);
            }
            case "fish" -> { e(g, 0, -4, 5, 3, 0xFFFF9A2A); tri(g, 4, -7, 6, 6, 0xFFFF9A2A); r(g, -3, -5, 1, 1, INK); }
            case "goldfish" -> {
                e(g, 0, -7, 11, 7, GOLD); e(g, -2, -9, 7, 3, 0xFFFFE680); tri(g, 9, -14, 10, 14, 0xFFFFB020);
                tri(g, -3, -17, 8, 7, 0xFFFFB020); r(g, -7, -9, 2, 2, INK); r(g, -7, -9, 1, 1, WHITE); r(g, -1, -9, 1, 9, 0x44FFFFFF);
            }
            case "bubbles" -> { d(g, 0, -3, 3, 0x88FFFFFF); d(g, 7, -10, 2, 0x88FFFFFF); d(g, -4, -16, 4, 0x88FFFFFF); r(g, -2, -18, 1, 1, WHITE); }
            case "shell" -> { e(g, 0, -4, 6, 4, 0xFFFFB0C8); for (int i = -4; i <= 4; i += 2) r(g, i, -7, 1, 5, 0xFFFF8AB8); r(g, -3, -1, 7, 1, 0xFFE8D8C0); }
            case "coral" -> { r(g, -1, -14, 3, 14, 0xFFFF6A7A); r(g, -6, -11, 2, 7, 0xFFFF6A7A); r(g, 4, -12, 2, 8, 0xFFFF6A7A); r(g, -6, -11, 7, 2, 0xFFFF6A7A); r(g, 1, -12, 5, 2, 0xFFFF8A9A); d(g, 0, -15, 2, 0xFFFF8A9A); d(g, -5, -12, 2, 0xFFFF8A9A); d(g, 5, -13, 2, 0xFFFF8A9A); }
            case "seaweed" -> { for (int i = 0; i < 14; i++) r(g, (i / 3 % 2 == 0 ? 0 : 2) - 1, -i - 1, 2, 1, 0xFF3FA04A); for (int i = 0; i < 9; i++) r(g, 6 + (i / 3 % 2 == 0 ? 0 : 2), -i - 1, 2, 1, 0xFF2E8A3A); }
            case "foam" -> { for (int i = -2; i <= 2; i++) { e(g, i * 7, -2, 5, 2, 0xDDFFFFFF); e(g, i * 7, -3, 3, 1, WHITE); } }
            case "mermaid" -> {
                r(g, -6, -26, 12, 16, 0xFFE05A3A);                                                   // long red hair
                d(g, 0, -24, 5, SKIN); r(g, -5, -29, 10, 4, 0xFFE05A3A); r(g, -2, -24, 1, 1, INK); r(g, 1, -24, 1, 1, INK); r(g, -1, -21, 2, 1, 0xFFE0707A);
                r(g, -4, -19, 8, 7, SKIN); r(g, -4, -17, 3, 2, 0xFFFF9AC8); r(g, 1, -17, 3, 2, 0xFFFF9AC8);
                e(g, 0, -8, 5, 8, 0xFF3CC8B0); e(g, 4, -2, 5, 4, 0xFF3CC8B0); tri(g, 6, -9, 9, 10, 0xFF2E9A8A);
                r(g, -3, -10, 6, 1, 0xFF7AE8D0);
            }
            case "bed" -> {
                r(g, -17, -34, 3, 34, 0xFF8A5A3A); r(g, 14, -34, 3, 34, 0xFF8A5A3A); d(g, -15, -35, 3, 0xFFB07A3A); d(g, 15, -35, 3, 0xFFB07A3A);
                int[] cols = {0xFFFF9AC8, 0xFF9AD0F8, 0xFFF8E080, 0xFFB8E8A0, 0xFFD8B0F0};
                for (int i = 0; i < 5; i++) { r(g, -15, -8 - i * 5, 30, 5, cols[i]); r(g, -15, -4 - i * 5, 30, 1, 0x22000000); }
                e(g, 0, -34, 10, 3, WHITE);
            }
            case "pea" -> { d(g, 0, -3, 3, 0xFF6AC85A); d(g, -1, -4, 1, 0xFFB8F0A0); }
            case "mirror" -> { e(g, 0, -14, 9, 13, GOLD); e(g, 0, -14, 7, 11, 0xFFD8F0FF); r(g, -4, -22, 2, 8, WHITE); r(g, 3, -8, 1, 3, WHITE); r(g, -3, 0, 6, 3, GOLD); }
            case "apple" -> { d(g, -2, -5, 4, 0xFFE5484D); d(g, 2, -5, 4, 0xFFE5484D); r(g, -1, -9, 1, 3, 0xFF6A3A1A); r(g, 0, -10, 3, 2, 0xFF4FAE4E); r(g, -4, -7, 1, 2, 0xFFFF9A9A); }
            case "pumpkin" -> { e(g, 0, -7, 11, 8, 0xFFFF8A1A); e(g, -5, -7, 4, 8, 0xFFE87A10); e(g, 5, -7, 4, 8, 0xFFE87A10); r(g, -1, -17, 3, 4, 0xFF4A8A2A); }
            case "coach" -> {
                e(g, 0, -12, 14, 11, 0xFFFF8A1A); e(g, -6, -12, 5, 11, 0xFFE87A10); e(g, 6, -12, 5, 11, 0xFFE87A10);
                r(g, -4, -17, 8, 7, 0xFFD8F0FF); r(g, -1, -22, 3, 3, 0xFF4A8A2A);
                d(g, -10, -3, 4, GOLD); d(g, 10, -3, 4, GOLD); d(g, -10, -3, 2, 0xFFFFE680); d(g, 10, -3, 2, 0xFFFFE680);
            }
            case "slipper" -> { e(g, 0, -4, 7, 3, 0xFFD8F0FF); r(g, -7, -9, 4, 6, 0xFFD8F0FF); r(g, -2, -8, 8, 1, 0xFFB8D8F8); r(g, 5, -5, 1, 1, WHITE); r(g, -6, -10, 1, 1, WHITE); r(g, 1, -9, 1, 1, WHITE); }
            case "clock" -> { d(g, 0, -10, 10, 0xFF8A5A3A); d(g, 0, -10, 8, WHITE); r(g, 0, -17, 1, 7, INK); r(g, 0, -11, 1, 1, INK); for (int i = 0; i < 4; i++) r(g, i % 2 == 0 ? -1 + (i - 1) * 6 : 0, i % 2 == 0 ? -11 : -10 + (i - 2) * 6 - 1, 1, 1, INK); }
            case "crown" -> crown(g, 0, -4);
            case "basket" -> { r(g, -6, -7, 12, 7, 0xFFB07A3A); r(g, -5, -10, 10, 3, 0xFF8A5A2A); r(g, -6, -4, 12, 1, 0xFF8A5A2A); r(g, -5, -8, 10, 1, WHITE); }
            case "sack" -> { e(g, 0, -8, 8, 8, 0xFFD8B880); r(g, -3, -17, 6, 3, 0xFFB8985A); r(g, -4, -15, 8, 1, 0xFF8A5A2A); }
            case "bun" -> {
                d(g, 0, -9, 9, 0xFFE8B060); d(g, -2, -11, 7, 0xFFF0C070); r(g, -4, -12, 2, 2, INK); r(g, 2, -12, 2, 2, INK);
                r(g, -3, -6, 7, 1, 0xFF8A4A2A); r(g, -2, -5, 5, 1, 0xFF8A4A2A); r(g, -7, -9, 2, 2, 0x66FF7A8A); r(g, 5, -9, 2, 2, 0x66FF7A8A);
            }
            case "trough" -> { tri(g, -9, -8, 18, 8, 0xFF8A5A3A); r(g, -10, -9, 20, 3, 0xFFB07A3A); r(g, 1, -7, 1, 6, 0xFF3A2A1A); r(g, 2, -4, 2, 1, 0xFF3A2A1A); }
            case "net" -> { for (int i = 0; i < 9; i++) { r(g, -8 + i, -14 + i, 1, 1, 0xFFB8985A); r(g, 8 - i, -14 + i, 1, 1, 0xFFB8985A); } for (int y = 0; y < 3; y++) r(g, -7 + y * 2, -12 + y * 3, 14 - y * 4, 1, 0xFFB8985A); }
            case "lightning" -> { r(g, 3, -20, 3, 7, 0xFFFFE680); r(g, 0, -14, 6, 3, 0xFFFFE680); r(g, -3, -12, 3, 9, 0xFFFFE680); r(g, -4, -4, 2, 4, 0xFFFFE680); }
            case "rain" -> { for (int i = 0; i < 5; i++) for (int j = 0; j < 3; j++) r(g, i * 8 + j * 3 - 16, -18 + j * 7 + i % 2 * 3, 1, 4, 0xAA8AB8E0); }
            case "snowflakes" -> { for (int i = 0; i < 6; i++) { r(g, -20 + i * 8, -30 + (i * 7) % 20, 2, 2, WHITE); } }
            case "crumbs" -> { for (int i = 0; i < 6; i++) r(g, -12 + i * 5, -2 - (i % 2), 2, 2, 0xFFE8C890); }
            case "oven" -> { r(g, -12, -22, 24, 22, 0xFF8A8A9A); d(g, 0, -12, 7, 0xFF3A2A2A); r(g, -7, -12, 14, 12, 0xFF3A2A2A); d(g, 0, -6, 4, 0xFFFF8A1A); d(g, 0, -5, 2, 0xFFFFE680); r(g, -3, -26, 6, 4, 0xFF6A6A7A); }
            case "windowlight" -> { r(g, -7, -14, 14, 14, 0xFF6A4A3A); r(g, -6, -13, 12, 12, 0xFFFFE680); r(g, -1, -13, 1, 12, 0xFF8A6A3A); r(g, -6, -8, 12, 1, 0xFF8A6A3A); }
            case "crowdbed" -> { r(g, -16, -8, 32, 8, 0xFF8A5A3A); r(g, -14, -12, 28, 6, 0xFFF8E8E8); r(g, -14, -14, 10, 5, WHITE); e(g, 8, -12, 7, 4, 0xFFFF9AC8); }
            default -> { }
        }
    }

    // ---------- the public API ----------
    private static final Map<String, String[]> CACHE = new HashMap<>();

    /** Draws one thing (a prop) by name at (x, y) (its bottom centre). size = percent. Outside a picture there is no cutting. */
    public static void prop(GuiGraphics g, String name, int x, int y, int size) {
        int f = 1;
        if (name.endsWith("<")) { f = -1; name = name.substring(0, name.length() - 1); }
        float pox = ox, poy = oy, psc = sc;
        boolean pclip = clipOn;
        if (!inScene) { ox = 0; oy = 0; sc = 1F; clipOn = false; }
        ox += x * sc;
        oy += y * sc;
        sc *= size / 100F;
        if (isAnimal(name)) drawAnimal(g, name, f); else thing(g, name, f);
        ox = pox; oy = poy; sc = psc; clipOn = pclip;
    }

    private static boolean isAnimal(String k) {
        return switch (k) {
            case "wolf", "fox", "dog", "cat", "puss", "donkey", "hare", "bear", "rooster", "duck", "duckling", "ducklings", "swan",
                 "swallow", "toad", "mouse" -> true;
            default -> false;
        };
    }

    /** Draws a whole picture (W x H) at (x, y). */
    public static void scene(GuiGraphics g, String spec, int x, int y) {
        String[] parts = CACHE.computeIfAbsent(spec, k -> k.split(";"));
        ox = x; oy = y; sc = 1F;
        clipX0 = x; clipY0 = y; clipX1 = x + W; clipY1 = y + H;
        clipOn = true;
        inScene = true;
        try {
            background(g, parts[0]);
            for (int i = 1; i < parts.length; i++) {
                String p = parts[i];
                int at = p.indexOf('@');
                if (at < 0) continue;
                String[] n = p.substring(at + 1).split(",");
                try {
                    int px = Integer.parseInt(n[0].trim()), py = Integer.parseInt(n[1].trim());
                    prop(g, p.substring(0, at), px, py, n.length > 2 ? Integer.parseInt(n[2].trim()) : 100);
                } catch (NumberFormatException ignored) {
                    // a typo in a picture must not crash the game: the thing is just not drawn
                }
            }
        } finally {
            inScene = false;
            clipOn = false;
            ox = 0; oy = 0; sc = 1F;
        }
    }
}
