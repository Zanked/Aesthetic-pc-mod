package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The LIVE tab of CuteTube (opened with the red button in the header of the video list).
 * <ul>
 *   <li>a panda streamer, Boo, runs a show that repeats every {@link #CYCLE} seconds by the REAL clock, so every
 *       player sees the same scene and the same chat at the same time (the bot messages are a pure function of the
 *       second, no server needed);</li>
 *   <li>you can type in the chat (60 characters, one message per 0.75 s);</li>
 *   <li>with Spooky on, a viewer called {@link #HIM} slowly takes over the chat. How far he has got depends on how
 *       many seconds you have watched in total (counter {@code live_sec}): stage 1 after 45 s, 2 after 120 s,
 *       3 after 210 s. At stage 3, once part 2 of the story is done, the stream is cut ({@link #startScare}) and
 *       chapter 1 of part 3 is finished ({@link Progress#advance3}).</li>
 * </ul>
 * Everything is display-only; the only thing saved is the counter. TubeApp draws this view and forwards the input.
 */
final class TubeLive {
    static final String HIM = "behind_you";

    /** Same layout as the video player of TubeApp. */
    private static final int PX = 4, PY = 4, PW = 146, PH = 82;
    private static final int BTN_Y = 98, VX = 102, VW = 46;
    private static final int CX = 156, CY = 16, CW = 136, CH = 100;

    private static final int CYCLE = 360;                 // seconds of one run of the show
    private static final int BOTS = 30, HIMS = 16, REACTS = 4;
    private static final int RED = 0xFFC0302A;

    private static final String[] NAMES = {"pip_the_bee", "MoonKitty", "creeperfan07", "Toastie", "bluefox", "lil_panda",
            "CookieXx", "penguinPete", "RedLadybug", "mochi_cat", "Sakura_Q", "bumble99"};
    private static final int[] NAME_COL = {0xFFE0A800, 0xFF7A5AC8, 0xFF3AA860, 0xFFD2762A, 0xFF2F7FD6, 0xFF3A2A3A,
            0xFFC04A7A, 0xFF2A9AA8};
    private static final int[] PENTA = {6, 9, 11, 13, 16, 18};

    private record Msg(int color, boolean him, List<FormattedCharSequence> lines) {}

    private final List<Msg> chat = new ArrayList<>();
    private int ticks, session, sendCool, scrollPx, himTimer, reactTimer, himIdx, reactIdx;
    private long lastSec;
    private boolean typing, ended, leave;
    private String draft = "";
    private int scareT = -1;                               // >= 0 while the stream is being cut
    private float vol = 0.6F;

    // ---------- sound helpers (a vanilla sound is either a SoundEvent or a Holder) ----------
    private static SoundEvent sv(SoundEvent e) { return e; }

    private static SoundEvent sv(Holder<SoundEvent> h) { return h.value(); }

    // ---------- open / close ----------
    void open() {
        chat.clear();
        ticks = 0;
        session = 0;
        sendCool = 0;
        scrollPx = 0;
        typing = false;
        draft = "";
        ended = false;
        leave = false;
        scareT = -1;
        reactTimer = -1;
        himTimer = stage() >= 2 ? 4 : 30;                 // he greets you soon if he already knows you
        long now = System.currentTimeMillis() / 1000L;
        lastSec = now;
        for (long s = now - 45; s < now; s++) bot(s);     // the chat is already going when you arrive
    }

    void close() {
        typing = false;
        scareT = -1;
    }

    /** True once if the player pressed "back" (the caller then closes this view). */
    boolean wantsLeave() {
        boolean r = leave;
        leave = false;
        return r;
    }

    // ---------- the creepy viewer ----------
    static int stage() {
        if (!Haunt.scary) return 0;
        int s = Progress.count("live_sec");
        return s >= 210 ? 3 : s >= 120 ? 2 : s >= 45 ? 1 : 0;
    }

    private static String me() { return Minecraft.getInstance().getUser().getName(); }

    private void himSay(int k) {
        add(HIM, RED, true, App.t("cutemod.live.him." + k, me()));
    }

    private void startScare() {
        scareT = 0;
        typing = false;
    }

    // ---------- chat ----------
    private static int hash(long s) {
        long x = s * 0x9E3779B97F4A7C15L;
        x ^= x >>> 29;
        x *= 0xBF58476D1CE4E5B9L;
        x ^= x >>> 32;
        return (int) x;
    }

    /** What the bots say in second s: the same for every player. */
    private void bot(long s) {
        int h = hash(s);
        if (Math.floorMod(h, 5) != 0) return;               // a message every five seconds or so
        int who = Math.floorMod(h >>> 7, NAMES.length), what = Math.floorMod(h >>> 13, BOTS);
        add(NAMES[who], NAME_COL[who % NAME_COL.length], false, App.t("cutemod.live.bot." + what));
    }

    private void add(String name, int color, boolean him, String text) {
        List<FormattedCharSequence> ls = new ArrayList<>(App.font().split(FormattedText.of(name + ": " + text), CW - 8));
        if (ls.size() > 3) ls = new ArrayList<>(ls.subList(0, 3));
        chat.add(new Msg(color, him, ls));
        while (chat.size() > 60) chat.remove(0);
    }

    private void send() {
        String s = draft.trim();
        if (s.isEmpty() || sendCool > 0 || scareT >= 0 || ended) return;
        add(me(), 0xFFB5427A, false, s);
        draft = "";
        sendCool = 45;
        scrollPx = 0;
        MusicApp.note(1, 18, 0.8F);
        if (stage() >= 2 && reactTimer < 0) reactTimer = 3;   // he answers what you write
    }

    // ---------- logic (60 times a second) ----------
    void tick() {
        ticks++;
        if (sendCool > 0) sendCool--;
        if (ended) return;
        long now = System.currentTimeMillis() / 1000L;
        int guard = 0;
        while (lastSec < now && guard++ < 5) {
            lastSec++;
            if (scareT < 0) bot(lastSec);
        }
        if (lastSec < now) lastSec = now;
        if (ticks % 60 == 0) second();
        music();
        if (scareT >= 0) scareTick();
    }

    private void second() {
        session++;
        if (!Haunt.scary || scareT >= 0) return;
        int before = stage();
        Progress.setCount("live_sec", Progress.count("live_sec") + 1);
        int st = stage();
        if (st > before) {                                  // he has just arrived (or came closer)
            himSay(st == 1 ? 0 : st == 2 ? 4 : 9);
            himTimer = 12;
        } else if (st >= 1 && --himTimer <= 0) {
            himTimer = st == 1 ? 25 : st == 2 ? 15 : 8;
            int lo = st == 1 ? 0 : st == 2 ? 4 : 9, hi = st == 1 ? 4 : st == 2 ? 9 : HIMS;
            himSay(lo + himIdx++ % (hi - lo));
        }
        if (reactTimer > 0 && --reactTimer == 0) {
            reactTimer = -1;
            add(HIM, RED, true, App.t("cutemod.live.hr." + reactIdx++ % REACTS, me()));
        }
        if (st >= 3 && session >= 25 && Progress.questDone() && Progress.step3() == 0) startScare();
    }

    private void scareTick() {
        scareT++;
        if (scareT == 1) Sfx.ui(sv(SoundEvents.AMBIENT_CAVE), 0.6F, 0.9F);
        if (scareT == 60) Sfx.ui(sv(SoundEvents.ENDERMAN_STARE), 0.5F, 0.6F);
        if (scareT == 90) add(HIM, RED, true, App.t("cutemod.live.scare.0", me()));
        if (scareT == 200) {
            ended = true;
            scareT = -1;
            Progress.advance3(0);
        }
    }

    private void music() {
        if (ended || scareT >= 40 || ticks % 20 != 0) return;
        long beat = System.currentTimeMillis() / 333L;       // the same beat for everybody
        int h = hash(beat), st = stage();
        if (Math.floorMod(h, 3) != 0) {
            int n = PENTA[Math.floorMod(h >>> 5, PENTA.length)] + (st >= 2 && Math.floorMod(h >>> 11, 4) == 0 ? 1 : 0);   // a wrong note now and then
            MusicApp.note(st >= 3 ? 1 : 0, n, vol * 0.45F);
        }
        if (Math.floorMod(beat, 4) == 0) MusicApp.note(2, st >= 3 ? 0 : 6, vol * 0.5F);
    }

    // ---------- render ----------
    void render(GuiGraphics g, int mx, int my, int ax, int ay) {
        int st = stage();
        long cyc = (System.currentTimeMillis() / 1000L) % CYCLE;
        App.roundRect(g, 1, 1, PX + PW, 144, 6, 0xFFFFFFFF);
        App.roundRect(g, CX - 3, 1, App.W - CX + 1, 144, 6, 0xFFFFFFFF);
        App.roundRect(g, PX - 1, PY - 1, PW + 2, PH + 2, 3, 0xFF3A2A3A);
        g.enableScissor(ax + PX, ay + PY, ax + PX + PW, ay + PY + PH);
        g.pose().pushPose();
        g.pose().translate(PX, PY, 0);
        scene(g, cyc, st);
        g.pose().popPose();
        g.disableScissor();

        // buttons: back and the volume
        button(g, mx, my, PX, BTN_Y, 20, "<");
        App.roundRect(g, VX, BTN_Y + 5, VW, 4, 2, 0xFFE3E6F0);
        App.roundRect(g, VX, BTN_Y + 5, Math.max(4, (int) (VW * vol)), 4, 2, 0xFFB57BD6);
        Skin.disc(g, VX + (int) (VW * vol), BTN_Y + 7, 3, 0xFFB57BD6);

        // info
        String views = App.t("cutemod.live.viewers", viewers(cyc, st));
        Skin.str(g, App.font(), App.font().plainSubstrByWidth(App.t("cutemod.live.title"), PW), PX, 116, 0xFF3A2A3A, false);
        Skin.str(g, App.font(), App.font().plainSubstrByWidth(App.t("cutemod.live.name") + "  -  " + views, PW), PX, 126, 0xFF8A7AA8, false);

        chat(g, ax, ay);
    }

    private int viewers(long cyc, int st) {
        if (ended) return 1;
        int n = 140 + (int) (60 * Math.sin(cyc * Math.PI * 2 / CYCLE));
        return n + (st >= 1 ? 1 : 0);                        // one more than there should be
    }

    private void button(GuiGraphics g, int mx, int my, int x, int y, int w, String s) {
        App.roundRect(g, x, y, w, 14, 6, App.in(mx, my, x, y, w, 14) ? 0xFFDDE2F3 : 0xFFEEF0F8);
        Skin.str(g, App.font(), s, x + (w - App.font().width(s)) / 2, y + 3, 0xFF3A2A3A, false);
    }

    private void chat(GuiGraphics g, int ax, int ay) {
        Skin.str(g, App.font(), App.t("cutemod.live.chat"), CX, 4, 0xFF3A2A3A, false);
        Skin.rect(g, CX, CY - 2, CW, 1, 0xFFE0D4EA);
        int total = 0;
        for (Msg m : chat) total += m.lines().size() * 9 + 3;
        scrollPx = Math.max(0, Math.min(scrollPx, Math.max(0, total - CH)));
        g.enableScissor(ax + CX, ay + CY, ax + CX + CW, ay + CY + CH);
        int bottom = CY + CH - 1 + scrollPx;
        for (int i = chat.size() - 1; i >= 0; i--) {
            Msg m = chat.get(i);
            int h = m.lines().size() * 9 + 3, top = bottom - h;
            bottom = top;
            if (top > CY + CH) continue;
            if (top + h < CY) break;
            Skin.rect(g, CX + 1, top + 1, 2, h - 3, m.color());
            for (int l = 0; l < m.lines().size(); l++) {
                Skin.str(g, App.font(), m.lines().get(l), CX + 5, top + 1 + l * 9, m.him() ? RED : 0xFF3A2A3A, false);
            }
        }
        g.disableScissor();

        // the box
        App.roundRect(g, CX - 1, 119, CW + 2, 18, 8, typing ? 0xFF4A7BD0 : 0xFFD3D8E6);
        App.roundRect(g, CX, 120, CW, 16, 8, 0xFFFFFFFF);
        String shown = draft.isEmpty() && !typing ? App.t("cutemod.live.add") : draft;
        while (shown.length() > 1 && App.font().width(shown) > CW - 8) shown = shown.substring(1);
        Skin.str(g, App.font(), shown, CX + 4, 124, draft.isEmpty() && !typing ? 0xFF9A8FA8 : 0xFF3A2A3A, false);
        if (typing && (ticks / 30) % 2 == 0) Skin.rect(g, CX + 4 + App.font().width(shown), 123, 1, 10, 0xFF3A2A3A);
    }

    // ---------- the picture: 146 x 82 ----------
    private void scene(GuiGraphics g, long cyc, int st) {
        int phase = cyc < 80 ? 0 : cyc < 220 ? 1 : cyc < 320 ? 2 : 3;
        boolean night = phase >= 2;
        int sec = Progress.count("live_sec");

        Skin.rect(g, 0, 0, 146, 82, night ? 0xFF2A2440 : 0xFFF6C9DC);                 // the room
        Skin.rect(g, 0, 62, 146, 20, night ? 0xFF1E1A30 : 0xFFD9A8C0);

        // the window
        Skin.rect(g, 99, 7, 38, 30, 0xFF3A2A3A);
        Skin.rect(g, 101, 9, 34, 26, night ? 0xFF141028 : 0xFF9FD6F2);
        if (night) {
            Skin.disc(g, 126, 16, 4, 0xFFF3E9B5);
            for (int i = 0; i < 5; i++) if ((ticks / 20 + i) % 4 != 0) Skin.rect(g, 104 + i * 6, 12 + (i * 7) % 15, 1, 1, 0xFFFFFFFF);
            if (phase == 2) for (int i = 0; i < 9; i++) App.rect(g, 102 + (i * 11 + ticks / 2) % 32, 10 + (i * 7 + ticks) % 22, 1, 3, 0x99A8C8F0);   // rain
        } else {
            Skin.disc(g, 124, 16, 4, 0xFFF9D56E);
            Skin.rect(g, 104 + (ticks / 40) % 20, 24, 10, 3, 0xFFFFFFFF);              // a cloud drifts by
        }
        Skin.rect(g, 117, 9, 1, 26, 0xFF3A2A3A);
        Skin.rect(g, 101, 21, 34, 1, 0xFF3A2A3A);

        // the doorway, and who may stand in it
        Skin.rect(g, 5, 11, 24, 52, 0xFF3A2A3A);
        Skin.rect(g, 7, 13, 20, 50, 0xFF150F20);
        if (scareT < 60) {
            if (st == 2 && (ticks / 50) % 5 == 0) him(g, 17, 62, 0.55F, false);
            else if (st >= 3) him(g, 17, 62, Math.min(1F, 0.6F + (sec - 210) / 150F), (ticks / 40) % 6 != 5);
        } else {
            him(g, 62, 66, 1.7F, true);                                                  // he is right behind her
        }

        panda(g, st, phase, cyc);

        // monitor and desk
        Skin.rect(g, 24, 58, 98, 5, 0xFF8A5A3C);
        Skin.rect(g, 28, 63, 4, 12, 0xFF6E452B);
        Skin.rect(g, 114, 63, 4, 12, 0xFF6E452B);
        Skin.rect(g, 84, 36, 30, 21, 0xFF3A2A3A);
        Skin.rect(g, 86, 38, 26, 15, 0xFF222244);
        Skin.rect(g, 87 + (int) Math.abs((ticks / 2) % 44 - 22), 40 + (int) Math.abs((ticks / 3) % 20 - 10), 3, 3, 0xFF6BE0A0);
        Skin.rect(g, 96, 53, 6, 4, 0xFF3A2A3A);

        // subtitles
        App.rect(g, 0, 65, 146, 17, 0xAA000000);
        String say = st >= 3 && (ticks / 300) % 2 == 1 ? "cutemod.live.say.8" : "cutemod.live.say." + (phase * 2 + (int) ((cyc / 40) % 2));
        List<FormattedCharSequence> ls = App.font().split(FormattedText.of(App.t(say)), 138);
        for (int i = 0; i < 2 && i < ls.size(); i++) Skin.str(g, App.font(), ls.get(i), 4, 67 + i * 8, 0xFFFFFFFF, false);

        // the badge and the number of viewers
        App.roundRect(g, 3, 3, 24, 10, 4, 0xFFE02A2A);
        Skin.str(g, App.font(), "LIVE", 6, 4, 0xFFFFFFFF, false);
        String v = Integer.toString(viewers(cyc, st));
        int vw = App.font().width(v);
        App.roundRect(g, 146 - vw - 9, 3, vw + 6, 10, 4, 0xAA000000);
        Skin.str(g, App.font(), v, 146 - vw - 6, 4, st >= 1 ? 0xFFFF8A80 : 0xFFFFFFFF, false);

        // the picture goes dark at the edges as he comes closer
        if (st >= 3 && scareT < 0 && !ended) {
            int a = Math.min(0x90, 0x30 + Math.max(0, sec - 210));
            App.rect(g, 0, 0, 146, 8, a << 24);
            App.rect(g, 0, 74, 146, 8, a << 24);
            App.rect(g, 0, 0, 10, 82, a << 24);
            App.rect(g, 136, 0, 10, 82, a << 24);
        }
        if (scareT >= 0 && scareT < 90) {                                                // the signal breaks
            Random r = new Random(ticks / 2);
            int[] cols = {0x66FF00FF, 0x6600FFFF, 0xAA000000, 0x66FFFF00};
            for (int i = 0; i < 7; i++) App.rect(g, r.nextInt(70), r.nextInt(82), 40 + r.nextInt(100), 1 + r.nextInt(6), cols[r.nextInt(cols.length)]);
        } else if (scareT >= 90) {
            App.rect(g, 0, 0, 146, 82, 0xF2000000);
            String s = App.t("cutemod.live.scare.1");
            Skin.str(g, App.font(), s, (146 - App.font().width(s)) / 2, 36, RED, false);
        }
        if (ended) {
            App.rect(g, 0, 0, 146, 82, 0xFF000000);
            String s = App.t("cutemod.live.over");
            Skin.str(g, App.font(), s, (146 - App.font().width(s)) / 2, 36, 0xFF8A7AA8, false);
        }
    }

    /** A dark figure with two pale eyes. s is the size, by the y of his feet. */
    private static void him(GuiGraphics g, int cx, int by, float s, boolean eyes) {
        int hr = Math.max(2, (int) (5 * s)), bw = Math.max(4, (int) (11 * s)), bh = (int) (24 * s), top = by - bh;
        int ink = 0xFF05030A;
        Skin.rect(g, cx - bw / 2, top, bw, bh, ink);
        Skin.disc(g, cx, top - hr + 1, hr, ink);
        Skin.rect(g, cx - bw / 2 - 2, top + 2, 2, (int) (16 * s), ink);                  // the arms just hang
        Skin.rect(g, cx + bw / 2, top + 2, 2, (int) (16 * s), ink);
        if (eyes) {
            int ey = top - hr;
            Skin.rect(g, cx - hr / 2 - 1, ey, 2, 1, 0xFFF4F0E8);
            Skin.rect(g, cx + hr / 2, ey, 2, 1, 0xFFF4F0E8);
        }
    }

    private void panda(GuiGraphics g, int st, int phase, long cyc) {
        int cx = 58;
        boolean blink = ticks % 210 < 6;
        boolean back = st >= 2 && (ticks / 150) % 3 == 2;                               // she glances at the doorway
        boolean talk = scareT < 0 && !ended && !back && (ticks / 6) % 2 == 0;
        boolean wave = phase == 0 && (ticks / 90) % 3 == 0;

        Skin.disc(g, cx, 56, 11, 0xFFFFFFFF);                                            // body (the desk hides the rest)
        Skin.disc(g, cx - 12, 56, 4, 0xFF2A2030);
        if (!wave) Skin.disc(g, cx + 12, 56, 4, 0xFF2A2030);
        else Skin.rect(g, cx + 10, 36 + (int) (Math.sin(ticks * 0.25) * 3), 5, 15, 0xFF2A2030);

        Skin.disc(g, cx, 38, 11, 0xFFFFFFFF);                                            // head
        Skin.disc(g, cx - 9, 28, 4, 0xFF2A2030);
        Skin.disc(g, cx + 9, 28, 4, 0xFF2A2030);
        Skin.disc(g, cx - 5, 38, 3, 0xFF2A2030);
        Skin.disc(g, cx + 5, 38, 3, 0xFF2A2030);
        if (!blink) {
            int dx = back ? -2 : 0;
            Skin.rect(g, cx - 6 + dx, 37, 2, 2, 0xFFFFFFFF);
            Skin.rect(g, cx + 4 + dx, 37, 2, 2, 0xFFFFFFFF);
        }
        Skin.rect(g, cx - 1, 42, 3, 2, 0xFF2A2030);
        Skin.rect(g, cx - 2, 45, 5, talk ? 2 : 1, talk ? 0xFF8A2A3A : 0xFF2A2030);
        Skin.disc(g, cx - 10, 43, 2, 0xFFF6A8C0);
        Skin.disc(g, cx + 10, 43, 2, 0xFFF6A8C0);
        Skin.rect(g, cx - 12, 25, 24, 2, 0xFFE5484D);                                    // headphones
        Skin.rect(g, cx - 13, 34, 3, 8, 0xFFE5484D);
        Skin.rect(g, cx + 10, 34, 3, 8, 0xFFE5484D);
    }

    // ---------- input ----------
    private void setVol(int x) { vol = Math.max(0.05F, Math.min(1F, (x - VX) / (float) VW)); }

    boolean click(int x, int y, int button) {
        typing = false;
        if (App.in(x, y, CX - 1, 119, CW + 2, 18)) { typing = !ended && scareT < 0; return true; }
        if (App.in(x, y, PX, BTN_Y, 20, 14)) { leave = true; return true; }
        if (App.in(x, y, VX - 3, BTN_Y, VW + 6, 14)) { setVol(x); return true; }
        return true;
    }

    boolean drag(int x, int y, int button) {
        if (App.in(x, y, VX - 8, BTN_Y - 4, VW + 16, 22)) { setVol(x); return true; }
        return false;
    }

    boolean key(int keyCode, int modifiers) {
        if (typing) {
            switch (keyCode) {
                case 257, 335 -> send();                                                 // enter
                case 256 -> typing = false;                                              // escape: leave the box only
                case 259 -> { if (!draft.isEmpty()) draft = draft.substring(0, draft.length() - 1); }
                case 86 -> {                                                             // ctrl+v
                    if (!Screen.hasControlDown()) return false;
                    String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                    if (clip != null) {
                        String s = draft + clip.replace("\n", " ").replace("\r", "");
                        draft = s.length() > 60 ? s.substring(0, 60) : s;
                    }
                }
                default -> { return false; }
            }
            return true;
        }
        if (keyCode == 256) { leave = true; return true; }                                // escape: back to the list
        return false;
    }

    boolean charTyped(char c) {
        if (!typing || c < 32 || c == 127) return false;
        if (draft.length() < 60) draft += c;
        return true;
    }

    boolean scroll(double amount) {
        scrollPx = Math.max(0, scrollPx + (int) Math.round(amount * 14));
        return true;
    }
}
