package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;

/**
 * Weather: what the sky of the world looks like right now. The picture follows the real world: the time of day
 * (sun, moon, stars, sunset), rain, snow (in cold biomes), thunder, and the Nether and the End look different.
 * Next to it: the clock, the day number, the moon phase, the dimension, the biome, the height and Pete's forecast
 * (the penguin guesses the next days: a joke, it has nothing to do with the real weather).
 */
public class WeatherApp extends App {
    // the picture
    private static final int SX = 4, SY = 4, SW = 150, SH = 84, GY = 66;
    // the right column
    private static final int RX = 160, RW = 136;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8;

    /** What the app knows about the world right now. */
    private record Info(int dim, boolean rain, boolean snow, boolean storm, boolean dry, long dayTime,
                        int tempC, String biome, int y, boolean cold) {}

    private int ticks;

    @Override
    public Component title() { return Component.translatable("cutemod.os.weather"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.weather"); }

    @Override
    public void tick() { ticks++; }

    // ---------- reading the world ----------
    private static Info info() {
        Minecraft mc = Minecraft.getInstance();
        var level = mc.level;
        var pl = mc.player;
        if (level == null || pl == null) return null;
        BlockPos pos = pl.blockPosition();
        var holder = level.getBiome(pos);
        Biome b = holder.value();
        int dim = level.dimension() == Level.NETHER ? 1 : level.dimension() == Level.END ? 2 : 0;
        float rl = level.getRainLevel(1F);
        boolean wet = dim == 0 && rl > 0.2F;
        boolean precip = b.hasPrecipitation();
        boolean cold = b.coldEnoughToSnow(pos);
        boolean snow = wet && precip && cold;
        boolean rain = wet && precip && !cold;
        boolean dry = wet && !precip;                                   // clouds without rain (a desert)
        boolean storm = wet && level.getThunderLevel(1F) > 0.5F && !snow;
        long dt = Math.floorMod(level.getDayTime(), 24000L);
        double sun = Math.sin(dt / 24000.0 * Math.PI * 2);
        double base = -5 + b.getBaseTemperature() * 30 + sun * 4 - rl * 3;   // a cute "degrees": cold at night and in the rain
        int tempC = (int) Math.round(Math.max(-30, Math.min(dim == 1 ? 48 : 45, base)));
        String name = holder.unwrapKey()
                .map(k -> Component.translatable(k.location().toLanguageKey("biome")).getString())
                .orElse("?");
        return new Info(dim, rain, snow, storm, dry, level.getDayTime(), tempC, name, (int) Math.floor(pl.getY()), cold);
    }

    /** The real weather outside for other apps (the park): 2 rain, 3 snow, 5 storm, or -1 (fine, or not in the Overworld). Cheap enough to call every few seconds. */
    public static int outside() {
        Info in = info();
        if (in == null || in.dim() != 0) return -1;
        int k = currentKind(in);
        return k == 2 || k == 3 || k == 5 ? k : -1;
    }

    /** 0 = full moon ... 4 = new moon (the vanilla order). */
    private static int moonPhase(long dayTime) { return (int) Math.floorMod(dayTime / 24000L, 8L); }

    private static double sunHeight(long dayTime) { return Math.sin(Math.floorMod(dayTime, 24000L) / 24000.0 * Math.PI * 2); }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        int body = shell.color().bodyColor;
        rect(g, 0, 0, W, H, mix(body, 0xFFFFFF, 0.7f));
        Info in = info();
        if (in == null) {
            CuteFont.draw(g, font(), t("cutemod.weather.noworld"), 10, 10, TEXT, false);
            return;
        }
        // the picture
        rect(g, SX - 1, SY - 1, SW + 2, SH + 2, 0xFF3A2A3A);
        g.enableScissor(shell.absX() + SX, shell.absY() + SY, shell.absX() + SX + SW, shell.absY() + SY + SH);
        g.pose().pushPose();
        g.pose().translate(SX, SY, 0);
        scene(g, in);
        g.pose().popPose();
        g.disableScissor();

        // the temperature, the condition and Pete's words
        String deg = in.tempC() + "°C";
        g.pose().pushPose();
        g.pose().translate(SX, SY + SH + 5, 0);
        g.pose().scale(2F, 2F, 1F);
        CuteFont.draw(g, font(), deg, 0, 0, TEXT, false);
        g.pose().popPose();
        int cx = SX + font().width(deg) * 2 + 8;
        Fit.box(g, font(), t("cutemod.weather.c." + condition(in)), cx, SY + SH + 6, TEXT, false, SX + SW - cx);
        Fit.box(g, font(), in.biome(), cx, SY + SH + 16, MUTED, false, SX + SW - cx);
        int ly = SY + SH + 28;
        Fit.para(g, font(), t("cutemod.weather.say." + say(in)), SX, ly, SW, H - ly - 4, 9, MUTED, false);

        // the facts
        long dt = Math.floorMod(in.dayTime(), 24000L);
        int hour = (int) ((dt / 1000 + 6) % 24), min = (int) (dt % 1000 * 60 / 1000);
        int ry = 6;
        row(g, ry, "time", String.format("%02d:%02d", hour, min));
        row(g, ry + 13, "day", String.valueOf(in.dayTime() / 24000L + 1));
        row(g, ry + 26, "moon", t("cutemod.weather.moon." + moonPhase(in.dayTime())));
        if (in.dim() == 0) moonIcon(g, RX + 48, ry + 30, moonPhase(in.dayTime()));
        row(g, ry + 39, "dim", t("cutemod.weather.dim." + in.dim()));
        row(g, ry + 52, "height", String.valueOf(in.y()));

        // Pete's forecast
        rect(g, RX, 82, RW, 1, 0xFFE0D4EA);
        Fit.box(g, font(), t("cutemod.weather.forecast"), RX, 87, TEXT, false, RW);
        if (in.dim() != 0) {
            Fit.para(g, font(), t("cutemod.weather.nodim"), RX, 102, RW, 58, 9, MUTED, false);
            return;
        }
        long day = in.dayTime() / 24000L;
        for (int i = 0; i < 4; i++) {
            int x = RX + i * 34, y = 99;
            rect(g, x, y, 31, 52, 0xFFFFFFFF);
            rect(g, x, y, 31, 1, i == 0 ? 0xFFF58FB8 : 0xFFE0D4EA);
            String lab = i == 0 ? t("cutemod.weather.today") : i == 1 ? t("cutemod.weather.tomorrow") : t("cutemod.weather.plus", i);
            Fit.boxC(g, font(), lab, x + 1, y + 4, TEXT, false, 29);
            int kind = i == 0 ? currentKind(in) : forecastKind(day + i, in.cold());
            int tc = i == 0 ? in.tempC() : in.tempC() + (int) Math.floorMod((day + i) * 7 + 3, 7L) - 3;
            icon(g, kind, x + 16, y + 26, ticks + i * 20);
            String ts = tc + "°";
            CuteFont.draw(g, font(), ts, x + 16 - font().width(ts) / 2, y + 41, MUTED, false);
        }
        Fit.box(g, font(), t("cutemod.weather.disclaimer"), RX, 154, MUTED, false, RW);
    }

    private void row(GuiGraphics g, int y, String key, String value) {
        int vw = font().width(value);
        Fit.box(g, font(), t("cutemod.weather." + key), RX, y, MUTED, false, RW - vw - 6);
        CuteFont.draw(g, font(), value, RX + RW - vw, y, TEXT, false);
    }

    // ---------- what to say ----------
    private static boolean night(Info in) { return sunHeight(in.dayTime()) < -0.1; }

    private static String condition(Info in) {
        if (in.dim() == 1) return "nether";
        if (in.dim() == 2) return "end";
        if (in.storm()) return "storm";
        if (in.snow()) return "snow";
        if (in.rain()) return "rain";
        if (in.dry()) return "dry";
        return night(in) ? "clear_night" : "clear";
    }

    private static String say(Info in) {
        String c = condition(in);
        if (c.equals("clear") && Math.abs(sunHeight(in.dayTime())) < 0.25) return "twilight";
        return c.equals("clear_night") ? "night" : c;
    }

    /** The icon kind of the real weather: 0 sun, 1 cloud, 2 rain, 3 snow, 4 rainbow, 5 storm, 6 moon. */
    private static int currentKind(Info in) {
        if (in.storm()) return 5;
        if (in.snow()) return 3;
        if (in.rain()) return 2;
        if (in.dry()) return 1;
        return night(in) ? 6 : 0;
    }

    /** Pete's guess for a day: always the same for the same day of the world. */
    private static int forecastKind(long day, boolean cold) {
        int v = (int) Math.floorMod(((day * 31 + 7) * 2654435761L) >>> 16, 10L);
        if (v <= 3) return 0;
        if (v <= 5) return 1;
        if (v <= 7) return cold ? 3 : 2;
        if (v == 8) return cold ? 3 : 5;
        return cold ? 1 : 4;
    }

    // ---------- drawing ----------
    private static void cloud(GuiGraphics g, int x, int y, int col) {
        disc(g, x - 7, y + 2, 5, col);
        disc(g, x, y - 2, 7, col);
        disc(g, x + 8, y + 2, 5, col);
        rect(g, x - 8, y + 2, 17, 5, col);
    }

    /** A small weather icon centered at (cx, cy), about 24 px wide. */
    private static void icon(GuiGraphics g, int kind, int cx, int cy, int tm) {
        int y = cy + (int) Math.round(Math.sin(tm / 18.0) * 1.5);
        switch (kind) {
            case 0 -> {
                disc(g, cx, y, 6, 0xFFFFD84A);
                disc(g, cx, y, 4, 0xFFFFE98A);
                for (int k = 0; k < 8; k++) {
                    double a = tm / 40.0 + k * Math.PI / 4;
                    rect(g, cx + (int) Math.round(Math.cos(a) * 10), y + (int) Math.round(Math.sin(a) * 10), 2, 2, 0xFFFFD84A);
                }
            }
            case 1 -> cloud(g, cx, y, 0xFFC8D4E4);
            case 2 -> {
                cloud(g, cx, y - 4, 0xFF9AA8BC);
                for (int k = 0; k < 4; k++) rect(g, cx - 8 + k * 5, y + 4 + (tm / 2 + k * 5) % 10, 1, 3, 0xFF4A9AF0);
            }
            case 3 -> {
                cloud(g, cx, y - 4, 0xFFC8D4E4);
                for (int k = 0; k < 5; k++) rect(g, cx - 9 + k * 4, y + 4 + (tm / 4 + k * 3) % 10, 2, 2, 0xFF8AB8F0);
            }
            case 5 -> {
                cloud(g, cx, y - 4, 0xFF6A7488);
                rect(g, cx, y + 3, 3, 5, 0xFFFFE04A);
                rect(g, cx - 2, y + 7, 3, 5, 0xFFFFE04A);
            }
            case 6 -> {
                disc(g, cx, y, 7, 0xFFF0F0D8);
                disc(g, cx + 4, y - 2, 6, 0xFFFFFFFF);
            }
            default -> {
                int[] cols = {0xFFE02A2A, 0xFFFFA23A, 0xFFFFE04A, 0xFF4CAF50, 0xFF3A8AE0, 0xFF8A5AD0};
                for (int b = 0; b < 6; b++) {
                    for (int s = 0; s <= 20; s++) {
                        double a = Math.PI * s / 20;
                        int r = 12 - b * 2 + 1;
                        rect(g, cx + (int) Math.round(Math.cos(a) * r), y + 6 - (int) Math.round(Math.sin(a) * r), 2, 2, cols[b]);
                    }
                }
            }
        }
    }

    /** The phase of the moon as a little disc (0 = full ... 4 = new). */
    private static void moonIcon(GuiGraphics g, int cx, int cy, int phase) {
        int[] lit = {10, 8, 5, 3, 0, 3, 5, 8};                                   // lit width in pixels of the 11 px disc
        disc(g, cx, cy, 5, 0xFF2A3050);
        boolean waning = phase >= 1 && phase <= 3;
        for (int dy = -5; dy <= 5; dy++) {
            int hw = (int) Math.floor(Math.sqrt(25 - dy * dy + 0.25));
            int w = phase == 0 ? 2 * hw + 1 : Math.min(2 * hw + 1, lit[phase] * (2 * hw + 1) / 10);
            int x0 = phase == 0 ? cx - hw : waning ? cx - hw : cx + hw - w + 1;
            if (w > 0) g.fill(x0, cy + dy, x0 + w, cy + dy + 1, 0xFFF4F0D8);
        }
    }

    private void scene(GuiGraphics g, Info in) {
        if (in.dim() == 1) { nether(g); return; }
        if (in.dim() == 2) { end(g); return; }
        long dt = Math.floorMod(in.dayTime(), 24000L);
        double a = dt / 24000.0 * Math.PI * 2, sunH = Math.sin(a);
        float day = (float) Math.max(0, Math.min(1, sunH * 2 + 0.5));            // 0 = night, 1 = day
        boolean wet = in.rain() || in.snow() || in.dry() || in.storm();
        int top = mix(0xFF0B1030, 0xFF5FB8FF, day), bot = mix(0xFF1A2050, 0xFFBFE8FF, day);
        if (Math.abs(sunH) < 0.3) {                                              // sunrise and sunset
            float tw = 1F - (float) (Math.abs(sunH) / 0.3);
            bot = mix(bot, 0xFFFF9A5A, tw * 0.7F);
            top = mix(top, 0xFFB46AA0, tw * 0.3F);
        }
        if (wet) {                                                               // grey weather
            top = mix(top, 0xFF6A7280, 0.5F);
            bot = mix(bot, 0xFF9AA4B4, 0.5F);
        }
        g.fillGradient(0, 0, SW, GY, top, bot);
        if (day < 0.6F) {                                                        // stars
            int al = (int) ((1F - day) * (wet ? 90 : 255));
            for (int k = 0; k < 26; k++) {
                if ((ticks / 25 + k) % 5 == 0) continue;                         // they twinkle
                g.fill((k * 37 + 11) % SW, (k * 53 + 7) % 50, (k * 37 + 11) % SW + 1, (k * 53 + 7) % 50 + 1, (al << 24) | 0xFFFFFF);
            }
        }
        int sx = (int) Math.round(75 - Math.cos(a) * 60), sy = (int) Math.round(GY - sunH * 54);
        if (sy < GY + 4) {                                                       // the sun
            disc(g, sx, sy, 11, 0x33FFE070);
            disc(g, sx, sy, 7, 0xFFFFE070);
        }
        int mxp = (int) Math.round(75 + Math.cos(a) * 60), myp = (int) Math.round(GY + sunH * 54);
        if (myp < GY + 4) {                                                      // the moon
            disc(g, mxp, myp, 6, 0xFFF0F0E0);
            disc(g, mxp - 2, myp - 1, 1, 0xFFC8C8B8);
            disc(g, mxp + 2, myp + 2, 1, 0xFFC8C8B8);
        }
        // clouds
        int cn = wet ? 6 : 2;
        int cc = wet ? mix(0xFFA8B2C2, 0xFF2A3040, 1F - day) : mix(0xFFFFFFFF, 0xFF404868, 1F - day);
        if (in.storm()) cc = mix(cc, 0xFF1A2030, 0.5F);
        for (int k = 0; k < cn; k++) cloud(g, ((k * 47 + ticks / 4) % 190) - 20, 9 + (k * 23) % 30, cc);
        // the ground with a few trees
        boolean snowy = in.snow() || in.cold();
        int grass = snowy ? 0xFFEFF6FF : 0xFF5FBF63;
        grass = mix(grass, 0xFF0A1A20, (1F - day) * 0.7F);
        rect(g, 0, GY, SW, SH - GY, grass);
        disc(g, 30, GY + 6, 16, grass);
        disc(g, 120, GY + 8, 18, grass);
        for (int k = 0; k < 3; k++) {
            int tx = 50 + k * 36, th = 12 + (k * 5) % 7;
            int leaf = mix(snowy ? 0xFFDDEAF4 : 0xFF3E9E52, 0xFF0A1A20, (1F - day) * 0.7F);
            rect(g, tx, GY - th + 6, 3, th, mix(0xFF7A5A3A, 0xFF0A0A10, (1F - day) * 0.7F));
            disc(g, tx + 1, GY - th + 3, 6, leaf);
        }
        // Pete: a little penguin who comes out whatever the weather (with an umbrella in the rain)
        penguin(g, 22, GY + 4, in.rain() || in.storm() || in.snow());
        // rain, snow, thunder
        if (in.rain() || in.storm()) {
            for (int k = 0; k < 46; k++) {
                int x = (k * 53 + 9) % SW, y = (ticks * 4 + k * 23) % (SH + 8) - 4;
                rect(g, x, y, 1, 4, 0xAA9ACCFF);
            }
        }
        if (in.snow()) {
            for (int k = 0; k < 40; k++) {
                int x = (k * 37 + 5 + (int) Math.round(Math.sin((ticks + k * 9) / 20.0) * 3)) % SW, y = (ticks / 2 + k * 17) % (SH + 6) - 3;
                rect(g, x, y, 2, 2, 0xFFFFFFFF);
            }
        }
        if (in.storm()) {
            int f = ticks % 200;
            if (f < 3 || (f >= 8 && f < 10)) {
                rect(g, 0, 0, SW, SH, 0x66FFFFFF);
                for (int i = 0; i < 6; i++) rect(g, 112 - i * 2 + (i % 2) * 3, 12 + i * 8, 3, 9, 0xFFFFF08A);
            }
        }
    }

    private void penguin(GuiGraphics g, int x, int y, boolean umbrella) {
        int dk = 0xFF2A2F3A;
        rect(g, x - 4, y - 1, 3, 1, 0xFFFF9F43);                                 // feet
        rect(g, x + 1, y - 1, 3, 1, 0xFFFF9F43);
        disc(g, x, y - 6, 5, dk);                                                // body
        rect(g, x - 5, y - 6, 10, 5, dk);
        disc(g, x, y - 5, 3, 0xFFFFFFFF);                                        // belly
        disc(g, x, y - 12, 4, dk);                                               // head
        rect(g, x - 2, y - 13, 1, 1, 0xFFFFFFFF);
        rect(g, x + 1, y - 13, 1, 1, 0xFFFFFFFF);
        rect(g, x - 1, y - 11, 3, 1, 0xFFFF9F43);                                // beak
        if (umbrella) {
            for (int i = 0; i < 5; i++) {
                int w = 6 + i * 3;
                rect(g, x - w / 2, y - 24 + i, w, 1, 0xFFE0405A);
            }
            rect(g, x, y - 18, 1, 8, 0xFF3A2A3A);
        }
    }

    private void nether(GuiGraphics g) {
        g.fillGradient(0, 0, SW, SH, 0xFF3A0808, 0xFF9A2A10);
        for (int k = 0; k < 7; k++) {                                            // stalactites
            int x = k * 24 + 6, h = 10 + (k * 7) % 14;
            for (int r = 0; r < h; r++) {
                int w = Math.max(2, 12 - r * 12 / h);
                rect(g, x + (12 - w) / 2, r, w, 1, 0xFF4A1A18);
            }
        }
        rect(g, 0, GY + 6, SW, SH - GY, 0xFFE05A1A);                             // lava
        for (int x = 0; x < SW; x += 6) rect(g, x, GY + 4 + (int) Math.round(Math.sin((x + ticks / 2) / 7.0) * 2), 6, 3, 0xFFFFA23A);
        for (int k = 0; k < 14; k++) {                                           // embers
            int ex = (k * 37 + 9) % SW, ey = GY - (ticks / 2 + k * 11) % 60;
            rect(g, ex, ey, 1, 1, 0xFFFFD27A);
        }
    }

    private void end(GuiGraphics g) {
        g.fillGradient(0, 0, SW, SH, 0xFF06030E, 0xFF1A1030);
        for (int k = 0; k < 40; k++) {
            if ((ticks / 30 + k) % 6 == 0) continue;
            rect(g, (k * 41 + 7) % SW, (k * 29 + 3) % SH, 1, 1, 0xFFD8C8FF);
        }
        int bob = (int) Math.round(Math.sin(ticks / 40.0) * 2);
        rect(g, 40, 46 + bob, 70, 6, 0xFFD8D4A0);                                // a floating island
        for (int r = 0; r < 12; r++) rect(g, 44 + r * 2, 52 + bob + r, 62 - r * 4, 1, 0xFFA8A478);
        for (int k = 0; k < 5; k++) rect(g, 56 + k * 9, 24 + bob + (k % 2) * 3, 1, 22, 0xFF3A2A5A);   // a few endermen-high obsidian pillars
    }
}
