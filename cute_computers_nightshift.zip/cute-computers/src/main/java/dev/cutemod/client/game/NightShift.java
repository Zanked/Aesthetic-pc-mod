package dev.cutemod.client.game;

import dev.cutemod.client.os.Sfx;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * Night Shift: you are the night guard of a toy shop. From 12 AM to 6 AM five toy animatronics wake up and come for you.
 * Every one of them has its own rule, so there is no single trick that beats them all:
 * <ul>
 *   <li><b>Bzik</b> (bee) flies through the vent to the LEFT door: close the door and she buzzes away again.</li>
 *   <li><b>Kap</b> (slug) slides under any door on the RIGHT: only a flash of light makes him go back.</li>
 *   <li><b>Tik-Tak</b> (bunny) only moves while you are not looking at her camera; at the window stare at her (aisle camera).</li>
 *   <li><b>Kex</b> (bear) is kept asleep by the music box: wind it up (click it on camera 3) before it runs dry.</li>
 *   <li><b>Shepot</b> (fox, night 3+) shows his eyes in a dark corner of the office: click them before he jumps.</li>
 * </ul>
 * Doors, lights and cameras eat the power. When it is gone, Kex comes. A win moves you to the next night (up to 5).
 */
public class NightShift extends MiniGame {
    private static final int HOUR = 2400, HOURS = 6;
    private static final int BEE = 0, SLUG = 1, BUNNY = 2, BEAR = 3, FOX = 4;
    private static final int LAST_NIGHT = 5;

    /** The next night to play: a win moves it on, a loss keeps it (kept while the game is open). */
    private static int nextNight = 1;

    private int night, t, hour;
    private double power, box;
    private boolean doorL, doorR, cam, blackout, won;
    private int lightL, lightR, camIdx;

    private int bee, beeT, beeAtk, beeStay;
    private int slug, slugT, slugAtk;
    private int bun, bunT, bunAtk, bunFlinch;
    private int bearT;
    private int fox, foxT, foxNext;
    private int blackT;

    private String cap = "";
    private int capT, dead, scareF;

    @Override
    public void reset() {
        score = 0; over = false; won = false;
        night = nextNight;
        t = 0; hour = 0; power = 100; box = 100;
        doorL = doorR = cam = blackout = false;
        lightL = lightR = 0; camIdx = 0;
        bee = 0; beeT = 700 + rnd.nextInt(300) - 50 * night; beeAtk = 0; beeStay = 0;
        slug = 0; slugT = 1000 + rnd.nextInt(400) - 60 * night; slugAtk = 0;
        bun = 0; bunT = 800 + rnd.nextInt(300) - 50 * night; bunAtk = 0; bunFlinch = 0;
        bearT = -1;
        fox = -1; foxT = 0; foxNext = 1500 + rnd.nextInt(600);
        blackT = 0;
        cap = ""; capT = 0; dead = -1; scareF = 0;
    }

    // ------------------------------------------------------------------ logic
    private boolean watching(int room) { return cam && !blackout && camIdx == room; }

    private void caption(String key) { cap = key; capT = 130; }

    private void kill(int who) {
        dead = who; over = true; scareF = 0;
    }

    private void win() {
        won = true; over = true;
        score += (int) power + 100 * (night - 1);
        nextNight = Math.min(LAST_NIGHT, night + 1);
        pling(1.5F);
    }

    @Override
    public void tick() {
        t++;
        if (capT > 0) capT--;
        if (lightL > 0) lightL--;
        if (lightR > 0) lightR--;

        int hr = t / HOUR;
        if (hr > hour) {
            hour = hr;
            score += 100;
            pling(1.3F);
            if (hour >= HOURS) { win(); return; }
        }

        if (blackout) {
            if (blackT > 0 && --blackT <= 0) { kill(BEAR); return; }
            if (blackT % 60 == 0) tone(0, 0.55F, 0.5F);
            return;
        }

        // power: the shop itself, doors, lights and the cameras all drain it
        double d = 0.15 + 0.008 * night;
        if (doorL) d += 0.28;
        if (doorR) d += 0.28;
        if (lightL > 0) d += 0.8;
        if (lightR > 0) d += 0.8;
        if (cam) d += 0.18;
        power -= d / 60.0;
        if (power <= 0) {
            power = 0; blackout = true;
            doorL = doorR = cam = false; lightL = lightR = 0;
            blackT = 360 + rnd.nextInt(300);
            caption("cutemod.nightshift.cap.dark");
            tone(1, 0.5F, 0.9F);
            return;
        }

        // Bzik (bee): through the vent to the left door; the door keeps her out
        if (bee < 2) {
            if (--beeT <= 0) {
                beeT = 330 - 25 * night + rnd.nextInt(120);
                if (rnd.nextInt(100) < 50 + 6 * night) {
                    bee++;
                    if (bee == 2) { beeAtk = 170; beeStay = 0; caption("cutemod.nightshift.cap.bee"); tone(2, 1.6F, 0.8F); }
                }
            }
        } else if (doorL) {
            if (++beeStay > 300) { bee = 1; beeT = 420; beeStay = 0; }
            else if (beeStay % 40 == 1) tone(2, 1.8F, 0.4F);
        } else {
            beeStay = 0;
            if (--beeAtk <= 0) { kill(BEE); return; }
        }

        // Kap (slug): slides under doors, so only light makes him go back
        if (slug < 2) {
            if (--slugT <= 0) {
                slugT = 520 - 35 * night + rnd.nextInt(180);
                if (rnd.nextInt(100) < 45 + 6 * night) {
                    slug++;
                    if (slug == 2) { slugAtk = 230; caption("cutemod.nightshift.cap.slug"); tone(0, 0.6F, 0.9F); }
                }
            }
        } else {
            if (lightR > 0) { slug = 0; slugT = 600 + rnd.nextInt(300); tone(1, 0.7F, 0.6F); }
            else if (--slugAtk <= 0) { kill(SLUG); return; }
        }

        // Tik-Tak (bunny): moves only while her room is not on a camera; at the window you must stare at her
        if (bun < 2) {
            int room = bun == 0 ? 0 : 3;
            if (!watching(room) && --bunT <= 0) {
                bunT = 300 - 20 * night + rnd.nextInt(120);
                if (rnd.nextInt(100) < 55 + 6 * night) {
                    bun++;
                    if (bun == 2) { bunAtk = 330 - 10 * night; bunFlinch = 0; caption("cutemod.nightshift.cap.bun"); tone(0, 0.5F, 1.0F); }
                    else { caption("cutemod.nightshift.cap.step"); tone(2, 0.6F, 0.5F); }
                }
            }
        } else if (watching(3)) {
            if (++bunFlinch >= 75) { bun = 1; bunT = 480; bunFlinch = 0; }
        } else {
            bunFlinch = 0;
            if (--bunAtk <= 0) { kill(BUNNY); return; }
        }

        // Kex (bear): the music box keeps him asleep; when it runs dry he comes after a few seconds
        box = Math.max(0, box - (0.028 + 0.0025 * night));
        if (box <= 0) {
            if (bearT < 0) { bearT = 480; caption("cutemod.nightshift.cap.box"); tone(1, 0.6F, 0.8F); }
            else if (--bearT <= 0) { kill(BEAR); return; }
        } else if (box < 25 && t % 240 == 0) {
            caption("cutemod.nightshift.cap.boxlow");
        }

        // Shepot (fox, from night 3): eyes in a dark corner of the office
        if (night >= 3) {
            if (fox < 0) {
                if (hour >= (night >= 4 ? 0 : 1) && --foxNext <= 0) {
                    fox = rnd.nextInt(2);
                    foxT = 240 - 15 * (night - 3);
                    foxNext = 1100 - 120 * (night - 3) + rnd.nextInt(500);
                    caption("cutemod.nightshift.cap.fox");
                    tone(0, 1.9F, 0.7F);
                }
            } else if (--foxT <= 0) { kill(FOX); return; }
        }
    }

    // ------------------------------------------------------------------ input
    private void wind() {
        box = Math.min(100, box + 11);
        if (box > 0) bearT = -1;
        pling(0.8F + (float) box / 250F);
    }

    private void toggleCam() {
        if (blackout) return;
        cam = !cam;
        tone(2, cam ? 1.1F : 0.8F, 0.5F);
    }

    private void doorToggle(boolean left) {
        if (blackout) return;
        if (left) doorL = !doorL; else doorR = !doorR;
        tone(1, 0.7F, 0.7F);
    }

    private void flash(boolean left) {
        if (blackout) return;
        if (left) lightL = lightL > 0 ? 0 : 100; else lightR = lightR > 0 ? 0 : 100;
        beep();
    }

    private int foxX() { return fox == 0 ? 62 : 158; }

    @Override
    public boolean click(int x, int y, int button) {
        if (blackout) return true;
        if (cam) {
            if (y >= 124) {
                for (int i = 0; i < 4; i++) if (in(x, y, 6 + i * 44, 126, 40, 12)) { camIdx = i; beep(); return true; }
                if (in(x, y, 182, 126, 34, 12)) toggleCam();
                return true;
            }
            if (camIdx == 2) wind();
            return true;
        }
        if (in(x, y, 6, 104, 34, 12)) doorToggle(true);
        else if (in(x, y, 6, 119, 34, 12)) flash(true);
        else if (in(x, y, 180, 104, 34, 12)) doorToggle(false);
        else if (in(x, y, 180, 119, 34, 12)) flash(false);
        else if (in(x, y, 72, 122, 76, 14)) toggleCam();
        else if (fox >= 0 && in(x, y, foxX() - 12, 42, 24, 28)) { fox = -1; tone(1, 1.4F, 0.8F); }
        return true;
    }

    @Override
    public boolean key(int k) {
        switch (k) {
            case 65, KEY_LEFT -> doorToggle(true);       // A
            case 68, KEY_RIGHT -> doorToggle(false);     // D
            case 81 -> flash(true);                      // Q
            case 69 -> flash(false);                     // E
            case 67, KEY_SPACE, KEY_UP, KEY_DOWN -> toggleCam();   // C
            case 87 -> { if (cam && camIdx == 2 && !blackout) wind(); }   // W
            case 49, 50, 51, 52 -> {                     // 1-4
                if (!blackout) { camIdx = k - 49; if (!cam) cam = true; beep(); }
            }
            default -> { return false; }
        }
        return true;
    }

    /** Small sound palette: 0 bass, 1 bell, 2 chip. */
    private static void tone(int kind, float pitch, float vol) {
        var ev = switch (kind) {
            case 0 -> SoundEvents.NOTE_BLOCK_BASS.value();
            case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
            default -> SoundEvents.NOTE_BLOCK_BIT.value();
        };
        Sfx.ui(ev, pitch, vol);
    }

    // ------------------------------------------------------------------ drawing
    private static void r(GuiGraphics g, int cx, int cy, int s, int dx, int dy, int w, int h, int c) {
        rect(g, cx + dx * s, cy + dy * s, w * s, h * s, c);
    }

    private static String tr(String key) { return Component.translatable(key).getString(); }

    /** The head of an animatronic around (cx, cy); s is the pixel size. */
    private static void drawHead(GuiGraphics g, int who, int cx, int cy, int s, boolean open) {
        final int W_ = 0xFFFFFFFF;
        switch (who) {
            case BEE -> {
                r(g, cx, cy, s, -5, -12, 1, 5, 0xFF1A1A1A); r(g, cx, cy, s, 4, -12, 1, 5, 0xFF1A1A1A);
                r(g, cx, cy, s, -6, -13, 3, 2, 0xFF1A1A1A); r(g, cx, cy, s, 3, -13, 3, 2, 0xFF1A1A1A);
                r(g, cx, cy, s, -12, -7, 4, 8, 0x99D8F0FF); r(g, cx, cy, s, 8, -7, 4, 8, 0x99D8F0FF);
                r(g, cx, cy, s, -8, -8, 16, 15, 0xFFF5C518);
                r(g, cx, cy, s, -8, -1, 16, 2, 0xFF1A1A1A);
                r(g, cx, cy, s, -6, -6, 4, 4, 0xFF0A0A0A); r(g, cx, cy, s, 2, -6, 4, 4, 0xFF0A0A0A);
                r(g, cx, cy, s, -5, -5, 2, 2, 0xFFFF2A2A); r(g, cx, cy, s, 3, -5, 2, 2, 0xFFFF2A2A);
                if (open) {
                    r(g, cx, cy, s, -5, 3, 10, 4, 0xFF200808);
                    r(g, cx, cy, s, -5, 3, 2, 2, W_); r(g, cx, cy, s, -1, 3, 2, 2, W_); r(g, cx, cy, s, 3, 3, 2, 2, W_);
                    r(g, cx, cy, s, -3, 5, 2, 2, W_); r(g, cx, cy, s, 1, 5, 2, 2, W_);
                } else r(g, cx, cy, s, -4, 4, 8, 1, 0xFF3A1A00);
            }
            case SLUG -> {
                r(g, cx, cy, s, -5, -12, 2, 6, 0xFF4CA83C); r(g, cx, cy, s, 3, -12, 2, 6, 0xFF4CA83C);
                r(g, cx, cy, s, -6, -15, 4, 4, W_); r(g, cx, cy, s, 2, -15, 4, 4, W_);
                r(g, cx, cy, s, -5, -14, 2, 2, 0xFFE02A2A); r(g, cx, cy, s, 3, -14, 2, 2, 0xFFE02A2A);
                r(g, cx, cy, s, -9, -5, 18, 12, 0xFF5BBF4A); r(g, cx, cy, s, -7, -7, 14, 2, 0xFF5BBF4A);
                r(g, cx, cy, s, -6, -5, 4, 2, 0xFF8AE07A);
                if (open) {
                    r(g, cx, cy, s, -5, 1, 10, 5, 0xFF16301A);
                    r(g, cx, cy, s, -4, 1, 2, 2, W_); r(g, cx, cy, s, 0, 1, 2, 2, W_); r(g, cx, cy, s, 3, 1, 2, 2, W_);
                } else r(g, cx, cy, s, -3, 3, 6, 1, 0xFF16301A);
                r(g, cx, cy, s, -6, 7, 2, 4, 0xFF5BBF4A); r(g, cx, cy, s, 3, 7, 2, 6, 0xFF5BBF4A);
            }
            case BUNNY -> {
                r(g, cx, cy, s, -6, -17, 4, 11, 0xFFF2EAF2); r(g, cx, cy, s, 2, -17, 4, 11, 0xFFF2EAF2);
                r(g, cx, cy, s, -5, -16, 2, 8, 0xFFE89AB8); r(g, cx, cy, s, 3, -16, 2, 8, 0xFFE89AB8);
                r(g, cx, cy, s, -8, -7, 16, 14, 0xFFF2EAF2);
                r(g, cx, cy, s, -6, -3, 4, 4, 0xFF0A0A0A); r(g, cx, cy, s, 2, -3, 4, 4, 0xFF0A0A0A);
                r(g, cx, cy, s, -5, -2, 2, 2, 0xFFFF2A2A); r(g, cx, cy, s, 3, -2, 2, 2, 0xFFFF2A2A);
                r(g, cx, cy, s, -1, 1, 2, 1, 0xFFE89AB8);
                r(g, cx, cy, s, -7, 2, 2, 2, 0xFFE89AB8); r(g, cx, cy, s, 5, 2, 2, 2, 0xFFE89AB8);
                if (open) {
                    r(g, cx, cy, s, -6, 3, 12, 4, 0xFF200808);
                    r(g, cx, cy, s, -6, 3, 2, 2, W_); r(g, cx, cy, s, -2, 3, 2, 2, W_); r(g, cx, cy, s, 2, 3, 2, 2, W_);
                } else r(g, cx, cy, s, -4, 4, 8, 1, 0xFF3A1A1A);
            }
            case BEAR -> {
                r(g, cx, cy, s, -9, -9, 4, 4, 0xFF8A5530); r(g, cx, cy, s, 5, -9, 4, 4, 0xFF8A5530);
                r(g, cx, cy, s, -8, -7, 16, 14, 0xFFA8693A);
                r(g, cx, cy, s, -4, 0, 8, 6, 0xFFD9A874);
                r(g, cx, cy, s, -5, -4, 3, 3, 0xFF0A0A0A); r(g, cx, cy, s, 2, -4, 3, 3, 0xFF0A0A0A);
                r(g, cx, cy, s, -4, -3, 1, 1, 0xFFFF2A2A); r(g, cx, cy, s, 3, -3, 1, 1, 0xFFFF2A2A);
                r(g, cx, cy, s, -1, 1, 2, 2, 0xFF1A0A0A);
                r(g, cx, cy, s, -8, -1, 2, 1, 0xFF3A2010); r(g, cx, cy, s, 6, -1, 2, 1, 0xFF3A2010);
                if (open) {
                    r(g, cx, cy, s, -3, 4, 6, 3, 0xFF2A0808);
                    r(g, cx, cy, s, -3, 4, 2, 2, W_); r(g, cx, cy, s, 1, 4, 2, 2, W_);
                } else r(g, cx, cy, s, -2, 5, 4, 1, 0xFF3A1A0A);
            }
            default -> {   // FOX
                r(g, cx, cy, s, -8, -12, 4, 6, 0xFFE8761E); r(g, cx, cy, s, 4, -12, 4, 6, 0xFFE8761E);
                r(g, cx, cy, s, -7, -10, 2, 3, 0xFF3A1A0A); r(g, cx, cy, s, 5, -10, 2, 3, 0xFF3A1A0A);
                r(g, cx, cy, s, -8, -7, 16, 12, 0xFFE8761E);
                r(g, cx, cy, s, -8, 0, 5, 5, 0xFFF8F0E0); r(g, cx, cy, s, 3, 0, 5, 5, 0xFFF8F0E0);
                r(g, cx, cy, s, -6, -3, 4, 2, 0xFFFFE04A); r(g, cx, cy, s, 2, -3, 4, 2, 0xFFFFE04A);
                r(g, cx, cy, s, -5, -3, 1, 2, 0xFF0A0A0A); r(g, cx, cy, s, 3, -3, 1, 2, 0xFF0A0A0A);
                r(g, cx, cy, s, -1, 2, 2, 2, 0xFF0A0A0A);
                if (open) {
                    r(g, cx, cy, s, -3, 4, 6, 3, 0xFF2A0808);
                    r(g, cx, cy, s, -3, 4, 1, 2, W_); r(g, cx, cy, s, 2, 4, 1, 2, W_);
                } else r(g, cx, cy, s, -2, 5, 4, 1, 0xFF3A1A0A);
            }
        }
    }

    private static void drawFigure(GuiGraphics g, int who, int cx, int cy, int s) {
        int body = switch (who) {
            case BEE -> 0xFFF5C518;
            case SLUG -> 0xFF4CA83C;
            case BUNNY -> 0xFFF2EAF2;
            case BEAR -> 0xFFA8693A;
            default -> 0xFFE8761E;
        };
        if (who == SLUG) r(g, cx, cy, s, -10, 8, 20, 8, body);
        else {
            r(g, cx, cy, s, -6, 8, 12, 10, body);
            if (who == BEE) { r(g, cx, cy, s, -6, 11, 12, 2, 0xFF1A1A1A); r(g, cx, cy, s, -6, 15, 12, 2, 0xFF1A1A1A); }
        }
        drawHead(g, who, cx, cy, s, false);
    }

    private void drawDoor(GuiGraphics g, int x, int y, int w, int h, boolean closed, boolean lit, boolean present, int who, boolean drip) {
        rect(g, x - 2, y - 2, w + 4, h + 2, 0xFF3A3048);
        rect(g, x, y, w, h, lit ? 0xFF55503C : 0xFF07050A);
        if (lit) rect(g, x, y, w, 3, 0xFF6A6450);
        if (present && lit) drawFigure(g, who, x + w / 2, y + 30, 2);
        if (closed) {
            rect(g, x, y, w, h, 0xFF4A465E);
            for (int yy = y + 4; yy < y + h; yy += 8) rect(g, x, yy, w, 1, 0xFF38344A);
            rect(g, x + w / 2 - 1, y, 2, h, 0xFF38344A);
            rect(g, x + 4, y + h / 2, 3, 3, 0xFFB8B0C8);
        }
        if (drip && present) {            // slime under the door: a hint even in the dark
            int k = (t / 20) % 3;
            rect(g, x + 8, y + h - 5, 4, 5, 0xFF3FA55A);
            rect(g, x + 24, y + h - 4, 3, 4, 0xFF3FA55A);
            rect(g, x + 10, y + h - 5 + k, 2, 3, 0xFF7ED98A);
        }
    }

    private void btn(GuiGraphics g, int x, int y, int w, int h, String label, boolean on) {
        rect(g, x - 1, y - 1, w + 2, h + 2, 0xFF0A070E);
        rect(g, x, y, w, h, on ? 0xFFB8334A : 0xFF4A3F5C);
        rect(g, x, y, w, 1, on ? 0xFFE0647A : 0xFF6A5C80);
        ctext(g, label, x + w / 2, y + 2, 0xFFFFFFFF);
    }

    private void hud(GuiGraphics g) {
        rect(g, 4, 3, 62, 7, 0xFF0A070E);
        int pw = (int) Math.round(power * 0.6);
        rect(g, 5, 4, pw, 5, power > 50 ? 0xFF7ED957 : power > 20 ? 0xFFF3D46A : 0xFFE05A4A);
        text(g, Math.round(power) + "%", 70, 2, 0xFFD8D0E8);
        int mins = (t % HOUR) * 60 / HOUR;
        String clock = (hour == 0 ? 12 : hour) + ":" + (mins / 10) + "0 AM";
        text(g, clock, W - 4 - font().width(clock), 2, 0xFFFFE9A0);
        if (capT > 0 && !cap.isEmpty()) ctext(g, tr(cap), W / 2, 13, capT < 30 ? 0xFF8A7A9A : 0xFFFFD0D0);
    }

    private void renderOffice(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0xFF14101B);
        rect(g, 0, 0, W, 20, 0xFF0D0A12);
        rect(g, 0, 20, W, 80, 0xFF1F1829);
        for (int x = 0; x < W; x += 22) rect(g, x, 20, 1, 80, 0xFF191321);
        rect(g, 0, 100, W, 40, 0xFF2B2132);
        rect(g, 0, 100, W, 2, 0xFF3A2D44);

        drawDoor(g, 4, 22, 48, 78, doorL, lightL > 0, bee == 2, BEE, false);
        drawDoor(g, 168, 22, 48, 78, doorR, lightR > 0, slug == 2, SLUG, true);

        // the front window (Tik-Tak shows up here)
        rect(g, 74, 26, 72, 56, 0xFF3A3048);
        rect(g, 76, 28, 68, 52, 0xFF0B0910);
        if (bun == 2) drawHead(g, BUNNY, 110, 62, 2, (t / 10) % 2 == 0);
        rect(g, 80, 30, 12, 2, 0x22FFFFFF);

        // Shepot's eyes
        if (fox >= 0 && (t / 7) % 12 != 0) {
            int fx = foxX();
            rect(g, fx - 7, 53, 6, 5, 0x33FFE04A); rect(g, fx + 1, 53, 6, 5, 0x33FFE04A);
            rect(g, fx - 6, 54, 4, 3, 0xFFFFE04A); rect(g, fx + 2, 54, 4, 3, 0xFFFFE04A);
        }

        // the music box on the desk: the lamp blinks when it needs winding
        rect(g, 100, 104, 20, 12, 0xFF6A4A3A);
        rect(g, 100, 104, 20, 2, 0xFF8A6A4A);
        boolean warn = box < 30 || bearT >= 0;
        rect(g, 108, 108, 4, 2, warn && (t / 8) % 2 == 0 ? 0xFFFF2A2A : 0xFF4A1010);

        btn(g, 6, 104, 34, 12, tr("cutemod.nightshift.door"), doorL);
        btn(g, 6, 119, 34, 12, tr("cutemod.nightshift.light"), lightL > 0);
        btn(g, 180, 104, 34, 12, tr("cutemod.nightshift.door"), doorR);
        btn(g, 180, 119, 34, 12, tr("cutemod.nightshift.light"), lightR > 0);
        btn(g, 72, 122, 76, 14, tr("cutemod.nightshift.cams"), false);
        hud(g);
    }

    private void renderCam(GuiGraphics g) {
        int base = switch (camIdx) { case 0 -> 0xFF1E2A28; case 1 -> 0xFF1A1F1E; case 2 -> 0xFF1C2224; default -> 0xFF161C1C; };
        rect(g, 0, 0, W, 124, base);
        switch (camIdx) {
            case 0 -> {
                for (int row = 0; row < 3; row++) {
                    rect(g, 6, 34 + row * 24, 208, 3, 0xFF3A4A46);
                    for (int i = 0; i < 10; i++) rect(g, 12 + i * 20, 22 + row * 24, 14, 12, (i + row) % 2 == 0 ? 0xFF2F4540 : 0xFF35504A);
                }
                rect(g, 20, 100, 180, 20, 0xFF2B3B38);
                if (bee != 0) rect(g, 58, 104, 24, 3, 0xFF16201E);
                if (bun != 0) rect(g, 138, 104, 24, 3, 0xFF16201E);
                if (bee == 0) drawFigure(g, BEE, 70, 80, 2);
                if (bun == 0) drawFigure(g, BUNNY, 150, 80, 2);
            }
            case 1 -> {
                rect(g, 0, 36, W, 56, 0xFF2D3836);
                rect(g, 0, 42, W, 44, 0xFF101615);
                for (int x = 4; x < W; x += 14) rect(g, x, 42, 2, 44, 0xFF2D3836);
                if (bee == 1) drawHead(g, BEE, 110, 66, 3, true);
                else ctext(g, "...", W / 2, 60, 0xFF3A4A46);
            }
            case 2 -> {
                for (int i = 0; i < 6; i++) rect(g, 10 + i * 12, 100, 9, 9, i % 2 == 0 ? 0xFF4A3A5A : 0xFF3A5A4A);
                rect(g, 84, 50, 52, 40, 0xFF6A4A3A);
                rect(g, 84, 44, 52, 8, 0xFF8A6A4A);
                rect(g, 138, 62, 6, 3, 0xFFB8A070); rect(g, 142, 57, 3, 13, 0xFFB8A070);
                rect(g, 60, 98, 100, 6, 0xFF0A0F10);
                int gw = (int) Math.round(box);
                rect(g, 60, 98, gw, 6, box > 40 ? 0xFF7ED957 : box > 15 ? 0xFFF3D46A : 0xFFE05A4A);
                if (slug == 0) drawFigure(g, SLUG, 38, 70, 2);
                if (bearT >= 0) {
                    int s = 1 + (480 - bearT) / 170;
                    drawHead(g, BEAR, 110, 36, s, true);
                    if ((t / 10) % 2 == 0) rect(g, 0, 0, W, 124, 0x33FF0000);
                }
                ctext(g, tr("cutemod.nightshift.wind"), W / 2, 110, 0xFFFFE9A0);
            }
            default -> {
                rect(g, 0, 0, 50, 124, 0xFF1C2524); rect(g, 170, 0, 50, 124, 0xFF1C2524);
                rect(g, 50, 90, 120, 34, 0xFF202B2A);
                rect(g, 50, 20, 120, 70, 0xFF111818);
                rect(g, 96, 36, 28, 54, 0xFF080C0C);
                for (int i = 0; i < 5; i++) rect(g, 50 + i * 12, 96 + i * 5, 120 - i * 24, 1, 0xFF2D3A39);
                if (slug == 1) drawFigure(g, SLUG, 80, 82, 2);
                if (bun == 1) drawFigure(g, BUNNY, 110, 58, 1);
                if (bun == 2) {
                    int sh = bunFlinch > 0 ? rnd.nextInt(3) - 1 : 0;
                    drawFigure(g, BUNNY, 110 + sh, 62, 3);
                }
            }
        }
        for (int y = 0; y < 124; y += 4) rect(g, 0, y, W, 1, 0x22000000);
        for (int i = 0; i < 16; i++) rect(g, rnd.nextInt(W), rnd.nextInt(124), 2 + rnd.nextInt(8), 1, 0x33FFFFFF);
        rect(g, 0, 0, W, 124, 0x1400FF50);

        hud(g);
        text(g, tr("cutemod.nightshift.cam." + camIdx), 4, 22, 0xFFB8F0C8);
        if ((t / 30) % 2 == 0) disc(g, W - 10, 26, 3, 0xFFE02A2A);

        rect(g, 0, 124, W, 16, 0xFF0A070E);
        for (int i = 0; i < 4; i++) btn(g, 6 + i * 44, 126, 40, 12, String.valueOf(i + 1), camIdx == i);
        btn(g, 182, 126, 34, 12, tr("cutemod.nightshift.back"), false);
    }

    @Override
    public void render(GuiGraphics g) {
        if (cam && !blackout) renderCam(g); else renderOffice(g);

        if (blackout) {
            rect(g, 0, 0, W, H, 0xF2000000);
            int left = blackT;
            if (left < 260) {                       // Kex's eyes appear and come closer
                int s = 1 + (260 - left) / 90;
                if ((t / 9) % 7 != 0) {
                    rect(g, 110 - 14 * s / 2 - 2, 56, 3 * s, 2 * s, 0xFFFFE9A0);
                    rect(g, 110 + 14 * s / 2 - 3 * s + 2, 56, 3 * s, 2 * s, 0xFFFFE9A0);
                }
            }
            hud(g);
        }

        if (over && !won && dead >= 0) {             // the jump scare is under the game over window
            scareF++;
            int sx = rnd.nextInt(7) - 3, sy = rnd.nextInt(5) - 2;
            rect(g, 0, 0, W, H, 0xEE200000);
            drawHead(g, dead, 110 + sx, 82 + sy, 4, true);
            if (scareF < 6) rect(g, 0, 0, W, H, 0x99FFFFFF);
        }
    }

    // ------------------------------------------------------------------ status
    @Override
    public Component status() {
        int mins = (t % HOUR) * 60 / HOUR;
        String clock = (hour == 0 ? 12 : hour) + ":" + (mins / 10) + "0 AM";
        return Component.translatable("cutemod.nightshift.status", night, clock, Math.round(power) + "%");
    }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return Component.translatable(won ? "cutemod.nightshift.win" : "cutemod.nightshift.dead." + Math.max(0, dead));
    }

    @Override
    public String hintKey() { return "cutemod.hint.nightshift"; }
}
