package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Fairy Tales: a shelf with twelve books (Andersen, Grimm, Perrault, Pushkin, a Russian folk tale). Open one and read it
 * like a real book: two pages, a picture on every scene, and the pages turn. Click the right page (or press the right arrow)
 * to turn forward, the left page (left arrow) to go back. Reading a tale to its end for the first time pays 2 coins.
 * <p>
 * The text never leaves the page: it is cut into lines by the real width of the font ({@link CuteFont#width}), and the
 * lines are cut into pages by the height of the page. A scene that is longer than its spread simply goes on over the next
 * pages, so a long translation or a big font only makes the book thicker. Saved: "tales" (finished tales) and "tales_mark"
 * (where you stopped).
 */
public class TalesApp extends KitApp {
    // the open book: two pages and a spine
    private static final int BX = 8, BY = 18, BW = 284, BH = 140, PW = 138, SPINE = 8;
    private static final int TX = 9, TW = 120, LINE = 9;                  // text: margin, width, line height
    private static final int TOP = BY + 8, BOTTOM = BY + BH - 14;          // where the text of a page may be
    private static final int PIC_Y = TOP, PIC_H = BookArt.H;
    private static final int LEFT_LINES = (BOTTOM - (PIC_Y + PIC_H + 4)) / LINE;   // under the picture
    private static final int FULL_LINES = (BOTTOM - TOP) / LINE;                   // a whole page
    private static final int FLIP = 12;                                    // ticks of a page turn
    private static final int PAPER = 0xFFFFF8E8, INK = 0xFF4A3A3A;
    private static final int REWARD = 2;

    /** One open book spread: the left and the right page. kind 0 = the title, 1 = the story, 2 = the end. */
    static final class Spread {
        final int kind, scene;                                       // scene: the picture on the left page, -1 = none
        final List<String> left = new ArrayList<>(), right = new ArrayList<>();

        Spread(int kind, int scene) { this.kind = kind; this.scene = scene; }
    }

    private int tale = -1;                                           // the open book, -1 = the shelf
    private final List<Spread> spreads = new ArrayList<>();
    private String builtKey = "";
    private int cur, flipTo = -1, flipT, hover = -1;
    private boolean justEarned;
    private final Set<String> done = new LinkedHashSet<>();
    private String markId = "";
    private int markSpread;
    private boolean loaded;

    @Override protected int accent() { return 0xFFC8905A; }

    @Override protected String id() { return "tales"; }

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        load();
    }

    private void load() {
        loaded = true;
        done.clear();
        String s = Store.read("tales");
        if (s != null) for (String id : s.split(",")) if (find(id) >= 0) done.add(id);
        String m = Store.read("tales_mark");
        if (m != null && m.contains(":")) {
            try {
                markId = m.substring(0, m.indexOf(':'));
                markSpread = Integer.parseInt(m.substring(m.indexOf(':') + 1));
            } catch (NumberFormatException e) {
                markId = "";
            }
        }
    }

    private static int find(String id) {
        for (int i = 0; i < Tales.ALL.size(); i++) if (Tales.ALL.get(i).id().equals(id)) return i;
        return -1;
    }

    // ---------- laying the text out ----------
    /** The text cut into lines no wider than "width" pixels in the font that is really used. Words wider than a line are broken. */
    static List<String> wrap(Font f, String text, int width) {
        List<String> out = new ArrayList<>();
        for (String para : text.split("\n")) {
            StringBuilder line = new StringBuilder();
            for (String word : para.split(" ")) {
                if (word.isEmpty()) continue;
                while (CuteFont.width(f, word) > width) {
                    if (line.length() > 0) { out.add(line.toString()); line.setLength(0); }
                    int n = word.length();
                    while (n > 1 && CuteFont.width(f, word.substring(0, n) + "-") > width) n--;
                    out.add(word.substring(0, n) + "-");
                    word = word.substring(n);
                }
                String attempt = line.length() == 0 ? word : line + " " + word;
                if (CuteFont.width(f, attempt) <= width) { line.setLength(0); line.append(attempt); }
                else { out.add(line.toString()); line.setLength(0); line.append(word); }
            }
            if (line.length() > 0) out.add(line.toString());
        }
        return out;
    }

    private static int take(List<String> from, int i, List<String> to, int max) {
        while (i < from.size() && to.size() < max) to.add(from.get(i++));
        return i;
    }

    /** All the spreads of the tale: the title, the scenes (picture + text, going on over more pages if needed), the end. */
    static List<Spread> layout(Font f, Tales.Tale tl, java.util.function.Function<String, String> text) {
        List<Spread> out = new ArrayList<>();
        out.add(new Spread(0, -1));
        for (int s = 0; s < Tales.SCENES; s++) {
            List<String> lines = wrap(f, text.apply("cutemod.tale." + tl.id() + ".s" + (s + 1)), TW);
            Spread first = new Spread(1, s);
            int i = take(lines, 0, first.left, LEFT_LINES);
            i = take(lines, i, first.right, FULL_LINES);
            out.add(first);
            while (i < lines.size()) {
                Spread more = new Spread(1, -1);
                i = take(lines, i, more.left, FULL_LINES);
                i = take(lines, i, more.right, FULL_LINES);
                out.add(more);
            }
        }
        out.add(new Spread(2, -1));
        return out;
    }

    private void build(Font f) {
        Tales.Tale tl = Tales.ALL.get(tale);
        String key = tale + "|" + CuteFont.width(f, "MWmw\u0416\u044B\u0429 0123") + "|" + t("cutemod.tale." + tl.id() + ".s1").hashCode();
        if (key.equals(builtKey) && !spreads.isEmpty()) return;
        builtKey = key;
        spreads.clear();
        spreads.addAll(layout(f, tl, k -> t(k)));
        if (cur >= spreads.size()) cur = spreads.size() - 1;
    }

    // ---------- opening, turning, finishing ----------
    private void open(int i) {
        tale = i;
        cur = 0;
        flipTo = -1;
        justEarned = false;
        builtKey = "";
        spreads.clear();
        build(font());
        if (Tales.ALL.get(i).id().equals(markId) && markSpread > 0 && markSpread < spreads.size() - 1) cur = markSpread;
        Sfx.click();
    }

    private void toShelf() {
        tale = -1;
        flipTo = -1;
        Sfx.click();
    }

    private void go(int to) {
        if (flipTo >= 0 || to < 0 || to >= spreads.size()) return;
        flipTo = to;
        flipT = 0;
        Sfx.click();
    }

    private void arrived() {
        String id = Tales.ALL.get(tale).id();
        markId = id;
        markSpread = cur;
        Store.write("tales_mark", id + ":" + cur);
        if (cur == spreads.size() - 1 && !done.contains(id)) {
            done.add(id);
            Store.write("tales", String.join(",", done));
            Progress.earn(REWARD);
            justEarned = true;
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (flipTo >= 0 && ++flipT >= FLIP) {
            cur = flipTo;
            flipTo = -1;
            arrived();
        }
    }

    // ---------- input ----------
    private static int coverX(int i) { return 9 + (i % 6) * 48; }

    private static int coverY(int i) { return 20 + (i / 6) * 62; }

    @Override
    public boolean click(int x, int y, int button) {
        if (tale < 0) {
            for (int i = 0; i < Tales.ALL.size(); i++) {
                if (in(x, y, coverX(i), coverY(i) - 3, 42, 55)) { open(i); return true; }
            }
            return false;
        }
        if (in(x, y, W - 54, 1, 50, 12)) { toShelf(); return true; }
        if (flipTo >= 0 || !in(x, y, BX, BY, BW, BH)) return true;
        if (x < BX + PW + SPINE / 2) go(cur - 1);
        else if (cur >= spreads.size() - 1) toShelf();
        else go(cur + 1);
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (tale < 0) return false;
        if (keyCode == 263) { go(cur - 1); return true; }                         // left arrow
        if (keyCode == 262) { if (cur >= spreads.size() - 1) toShelf(); else go(cur + 1); return true; }   // right arrow
        if (keyCode == 259) { toShelf(); return true; }                           // backspace
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        if (tale < 0) return false;
        go(amount > 0 ? cur - 1 : cur + 1);
        return true;
    }

    // ---------- drawing ----------
    private static void ctext(GuiGraphics g, Font f, String s, int cx, int y, int color) {
        CuteFont.draw(g, f, s, cx - CuteFont.width(f, s) / 2, y, color, false);
    }

    private static String trunc(Font f, String s, int max) {
        if (CuteFont.width(f, s) <= max) return s;
        int n = s.length();
        while (n > 1 && CuteFont.width(f, s.substring(0, n) + "...") > max) n--;
        return s.substring(0, n) + "...";
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        if (tale < 0) { renderShelf(g, f, mx, my); return; }
        build(f);
        renderBook(g, f, mx, my);
    }

    private void cover(GuiGraphics g, Tales.Tale tl, int x, int y, boolean lifted, boolean read) {
        int c = tl.cover(), dark = mix(c, 0x000000, 0.3F);
        rect(g, x, y, 42, 52, c);
        rect(g, x, y, 5, 52, dark);
        rect(g, x + 5, y, 1, 52, mix(c, 0xFFFFFF, 0.3F));
        rect(g, x + 8, y + 3, 31, 1, 0xFFFFD84A); rect(g, x + 8, y + 48, 31, 1, 0xFFFFD84A);
        rect(g, x + 8, y + 3, 1, 46, 0xFFFFD84A); rect(g, x + 38, y + 3, 1, 46, 0xFFFFD84A);
        BookArt.prop(g, tl.prop(), x + 23, y + 40, tl.propSize() * 6 / 10);
        if (read) { rect(g, x + 35, y, 4, 9, 0xFFE5484D); rect(g, x + 35, y + 9, 2, 2, 0xFFE5484D); }   // a ribbon: read
        if (lifted) rect(g, x, y, 42, 1, 0x88FFFFFF);
    }

    private void renderShelf(GuiGraphics g, Font f, int mx, int my) {
        hover = -1;
        for (int i = 0; i < Tales.ALL.size(); i++) if (in(mx, my, coverX(i), coverY(i) - 3, 42, 55)) hover = i;
        header(g, f);
        rect(g, 0, 14, W, H - 14, 0xFFF3E2C8);                                   // the wall behind the shelves
        for (int r = 0; r < 2; r++) {
            int py = coverY(r * 6) + 52;
            rect(g, 4, py, W - 8, 6, 0xFF9A6A3A);
            rect(g, 4, py, W - 8, 2, 0xFFC08A52);
            rect(g, 4, py + 6, W - 8, 2, 0x33000000);
        }
        for (int i = 0; i < Tales.ALL.size(); i++) {
            Tales.Tale tl = Tales.ALL.get(i);
            int x = coverX(i), y = coverY(i) - (hover == i ? 3 : 0);
            rect(g, x + 2, coverY(i) + 50, 42, 3, 0x22000000);
            cover(g, tl, x, y, hover == i, done.contains(tl.id()));
        }
        int shown = hover;
        if (shown >= 0) {
            Tales.Tale tl = Tales.ALL.get(shown);
            ctext(g, f, trunc(f, t("cutemod.tale." + tl.id() + ".title"), W - 16), W / 2, 146, TEXT);
            ctext(g, f, trunc(f, t("cutemod.tale.author." + tl.author()), W - 16), W / 2, 156, MUTED);
        } else {
            ctext(g, f, trunc(f, t("cutemod.tales.pick"), W - 16), W / 2, 150, MUTED);
        }
    }

    private void paper(GuiGraphics g, int x, int w) {
        rect(g, x, BY, w, BH, PAPER);
    }

    /** The back of a page that is turning: plain paper with the faint lines of the text. */
    private void turning(GuiGraphics g, int x, int w) {
        if (w <= 0) return;
        rect(g, x, BY, w, BH, 0xFFF4EAD2);
        for (int y = TOP + 4; y < BOTTOM; y += LINE) rect(g, x + Math.min(3, w), y, Math.max(0, w - 6), 1, 0x14000000);
        rect(g, x, BY, 1, BH, 0x33000000);
        rect(g, x + w - 1, BY, 1, BH, 0x33000000);
    }

    private void renderBook(GuiGraphics g, Font f, int mx, int my) {
        Tales.Tale tl = Tales.ALL.get(tale);
        rect(g, 0, 0, W, H, 0xFF6A4A38);
        for (int y = 14; y < H; y += 12) rect(g, 0, y, W, 1, 0x1A000000);          // the planks of the desk
        rect(g, 0, 0, W, 14, accent());
        CuteFont.draw(g, f, trunc(f, t("cutemod.tale." + tl.id() + ".title"), W - 70), 5, 3, 0xFFFFFFFF, false);
        boolean hb = in(mx, my, W - 54, 1, 50, 12);
        rect(g, W - 54, 1, 50, 12, hb ? 0x66FFFFFF : 0x33FFFFFF);
        ctext(g, f, trunc(f, t("cutemod.tales.shelf"), 46), W - 29, 3, 0xFFFFFFFF);
        // the cover of the book around the pages, and the pages
        rect(g, BX - 4, BY - 4, BW + 8, BH + 8, mix(tl.cover(), 0x000000, 0.2F));
        rect(g, BX - 4, BY - 4, BW + 8, 2, mix(tl.cover(), 0xFFFFFF, 0.25F));
        rect(g, BX - 2, BY + BH, BW + 4, 3, 0xFFE8DCC0);
        paper(g, BX, PW);
        paper(g, BX + PW + SPINE, PW);
        rect(g, BX + PW, BY, SPINE, BH, 0xFFEADBB8);
        rect(g, BX + PW + 3, BY, 2, BH, 0x33000000);
        for (int i = 0; i < 4; i++) {                                              // the gutter shadow
            rect(g, BX + PW - 1 - i, BY, 1, BH, (0x16 - i * 4) << 24);
            rect(g, BX + PW + SPINE + i, BY, 1, BH, (0x16 - i * 4) << 24);
        }
        Spread now = spreads.get(cur);
        if (flipTo < 0) {
            leftPage(g, f, now, tl, cur * 2 + 1);
            rightPage(g, f, now, tl, cur * 2 + 2);
            return;
        }
        Spread to = spreads.get(flipTo);
        float p = flipT / (float) FLIP;
        int spineL = BX + PW, spineR = BX + PW + SPINE;
        if (flipTo > cur) {                                                       // turning forward: the right page goes to the left
            leftPage(g, f, now, tl, -1);
            rightPage(g, f, to, tl, -1);
            if (p < 0.5F) { int w = (int) (PW * (1 - 2 * p)); turning(g, spineR, w); }
            else { int w = (int) (PW * (2 * p - 1)); turning(g, spineL - w, w); }
        } else {                                                                  // turning back
            rightPage(g, f, now, tl, -1);
            leftPage(g, f, to, tl, -1);
            if (p < 0.5F) { int w = (int) (PW * (1 - 2 * p)); turning(g, spineL - w, w); }
            else { int w = (int) (PW * (2 * p - 1)); turning(g, spineR, w); }
        }
    }

    private void lines(GuiGraphics g, Font f, List<String> ls, int x, int y) {
        for (int i = 0; i < ls.size(); i++) CuteFont.draw(g, f, ls.get(i), x, y + i * LINE, INK, false);
    }

    private void number(GuiGraphics g, Font f, int n, int cx) {
        if (n > 0) ctext(g, f, Integer.toString(n), cx, BY + BH - 11, 0xFFB8A888);
    }

    private void leftPage(GuiGraphics g, Font f, Spread s, Tales.Tale tl, int num) {
        int px = BX + TX, cx = BX + PW / 2;
        switch (s.kind) {
            case 0 -> {                                                           // the cover plate
                rect(g, px, TOP, TW, BOTTOM - TOP, tl.cover());
                rect(g, px + 3, TOP + 3, TW - 6, 1, 0xFFFFD84A); rect(g, px + 3, BOTTOM - 4, TW - 6, 1, 0xFFFFD84A);
                rect(g, px + 3, TOP + 3, 1, BOTTOM - TOP - 6, 0xFFFFD84A); rect(g, px + TW - 4, TOP + 3, 1, BOTTOM - TOP - 6, 0xFFFFD84A);
                BookArt.prop(g, tl.prop(), px + TW / 2, TOP + 78, tl.propSize() * 18 / 10);
            }
            case 2 -> {                                                           // the end: a small cover and "The End"
                BookArt.prop(g, tl.prop(), cx, TOP + 56, tl.propSize());
                String end = t("cutemod.tales.the_end");
                int sc = CuteFont.width(f, end) * 2 <= TW ? 2 : 1;
                g.pose().pushPose();
                g.pose().translate(cx - CuteFont.width(f, end) * sc / 2F, TOP + 70, 0);
                g.pose().scale(sc, sc, 1F);
                CuteFont.draw(g, f, end, 0, 0, 0xFFB8743A, false);
                g.pose().popPose();
            }
            default -> {
                int ty = TOP;
                if (s.scene >= 0) {
                    rect(g, px - 2, PIC_Y - 2, BookArt.W + 4, PIC_H + 4, 0xFF8A5A3A);
                    BookArt.scene(g, tl.pictures()[s.scene], px, PIC_Y);
                    ty = PIC_Y + PIC_H + 4;
                }
                lines(g, f, s.left, px, ty);
            }
        }
        number(g, f, num, cx);
    }

    private void rightPage(GuiGraphics g, Font f, Spread s, Tales.Tale tl, int num) {
        int px = BX + PW + SPINE + TX, cx = BX + PW + SPINE + PW / 2;
        switch (s.kind) {
            case 0 -> {
                String name = t("cutemod.tale." + tl.id() + ".title");
                List<String> big = wrap(f, name, TW / 2);                     // twice as big when no word has to be broken
                boolean twice = big.size() <= 4;
                for (String l : big) if (l.endsWith("-")) twice = false;
                int y = TOP + 18;
                if (twice) {
                    for (String l : big) {
                        g.pose().pushPose();
                        g.pose().translate(cx - CuteFont.width(f, l), y, 0);
                        g.pose().scale(2F, 2F, 1F);
                        CuteFont.draw(g, f, l, 0, 0, tl.cover(), false);
                        g.pose().popPose();
                        y += LINE * 2;
                    }
                } else {
                    for (String l : wrap(f, name, TW)) { ctext(g, f, l, cx, y, tl.cover()); y += LINE + 2; }
                }
                rect(g, cx - 20, y + 2, 40, 1, 0xFFFFC832);
                rect(g, cx - 2, y + 5, 4, 4, 0xFFFFC832);
                y += 16;
                for (String l : wrap(f, t("cutemod.tale.author." + tl.author()), TW)) { ctext(g, f, l, cx, y, MUTED); y += LINE; }
                List<String> note = wrap(f, t("cutemod.tales.retold"), TW);
                int ny = BOTTOM - note.size() * LINE;
                for (String l : note) { ctext(g, f, l, cx, ny, 0xFFB8A888); ny += LINE; }
            }
            case 2 -> {
                int y = TOP + 22;
                for (String l : wrap(f, t("cutemod.tales.thanks"), TW)) { ctext(g, f, l, cx, y, INK); y += LINE; }
                if (justEarned) { y += 6; for (String l : wrap(f, t("cutemod.tales.reward", REWARD), TW)) { ctext(g, f, l, cx, y, 0xFFB8743A); y += LINE; } }
                y += 8;
                for (String l : wrap(f, t("cutemod.tales.back"), TW)) { ctext(g, f, l, cx, y, MUTED); y += LINE; }
            }
            default -> lines(g, f, s.right, px, TOP);
        }
        number(g, f, num, cx);
    }
}
