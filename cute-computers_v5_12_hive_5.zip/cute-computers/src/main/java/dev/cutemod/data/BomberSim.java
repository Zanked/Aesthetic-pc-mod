package dev.cutemod.data;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Bombers (a Bomberman-like game for up to 4 players: people and / or computer players).
 * <p>
 * The whole game lives here and has no Minecraft classes in it, so the same code runs on the server (online rooms) and on
 * the client (a game against the computer players) and can be tested alone. It ticks {@link #TPS} times a second.
 * <ul>
 *   <li>The field is {@link #COLS} x {@link #ROWS} cells; the pillars sit on every cell with odd x and odd y, crates fill most of
 *       the rest. Every cell is {@link #CELL} units wide; players walk from cell to cell (they may turn back in the middle of a step).</li>
 *   <li>A bomb explodes after {@link #FUSE} ticks (or when a flame reaches it). The flames stop at pillars, break crates (some of
 *       them hide a bonus) and burn bonuses that lie in the open.</li>
 *   <li>Bonuses: more bombs, longer flames, faster steps, a shield (survives one hit).</li>
 *   <li>After {@link #SUDDEN_AT} ticks the field starts to fill up with walls from the edge to the middle, so a round always ends.</li>
 * </ul>
 * Directions: 0 down, 1 left, 2 right, 3 up (the opposite of d is 3 - d); -1 means nothing.
 */
public final class BomberSim {
    public static final int COLS = 15, ROWS = 11, N = COLS * ROWS, CELL = 24;
    public static final int TPS = 20;
    public static final int FUSE = 50, FLAME = 9, COUNTDOWN = 60, SUDDEN_AT = 1600, SUDDEN_STEP = 3, END_DELAY = 40;
    /** The walls leave this many cells in the middle open; if nobody wins in the {@link #TIME_UP} ticks after the walls stop, the round is a draw. */
    public static final int LEFT_OPEN = 8, TIME_UP = 800;
    public static final byte FLOOR = 0, WALL = 1, CRATE = 2;
    public static final int IT_NONE = 0, IT_BOMB = 1, IT_FLAME = 2, IT_SPEED = 3, IT_SHIELD = 4;
    public static final int[] SPEEDS = {3, 4, 5, 6};
    public static final int MAX_BOMBS = 6, MAX_RANGE = 7;
    public static final int ST_COUNT = 0, ST_PLAY = 1, ST_OVER = 2;
    /** winner: a player number, or DRAW (everybody went out together) or HUMANS_OUT (only computer players were left). */
    public static final int NONE = -1, DRAW = -1, HUMANS_OUT = -2;

    static final int[] DX = {0, -1, 1, 0}, DY = {1, 0, 0, -1};
    private static final int INF = 9999;

    public static final class Player {
        public int idx;
        public boolean active, ai, alive;
        public int level;                          // the skill of a computer player: 0 easy, 1 normal, 2 hard
        public int x, y;                           // where the cell the player stands in begins, in units
        public int facing, moving = -1;
        public int speed, maxBombs = 1, range = 2, shield, invuln;
        public int kills, crates, place, deadTick, killer = -1;   // killer: who lit the flame that put him out (himself: -1 or his own number)
        int want = -1;
        boolean bombReq;
        int pause;

        public int cx() { return (x + CELL / 2) / CELL; }

        public int cy() { return (y + CELL / 2) / CELL; }
    }

    public static final class Bomb {
        public int cx, cy, fuse, owner, range, pass;

        Bomb(int cx, int cy, int fuse, int owner, int range) {
            this.cx = cx; this.cy = cy; this.fuse = fuse; this.owner = owner; this.range = range;
        }
    }

    public final byte[] tile = new byte[N];
    public final byte[] item = new byte[N];
    public final int[] flame = new int[N];
    private final int[] flameOwner = new int[N];
    public final Player[] pl = new Player[4];
    public final List<Bomb> bombs = new ArrayList<>();
    public int state = ST_COUNT, countdown = COUNTDOWN, play, tick, winner = NONE, overTicks;
    public boolean sudden, done;

    private final Random rnd;
    private final int[] danger = new int[N], dangerTmp = new int[N], dist = new int[N], first = new int[N], queue = new int[N];
    private final boolean[] bombGrid = new boolean[N];
    private final int[] ray = new int[64];
    private int suddenNext;

    // the order sudden death fills the field in (the pillars are left out)
    private static final int[] SPIRAL;
    private static final int[] SPIRAL_POS = new int[N];

    static {
        List<Integer> order = new ArrayList<>();
        int x0 = 0, y0 = 0, x1 = COLS - 1, y1 = ROWS - 1;
        while (x0 <= x1 && y0 <= y1) {
            for (int x = x0; x <= x1; x++) order.add(y0 * COLS + x);
            for (int y = y0 + 1; y <= y1; y++) order.add(y * COLS + x1);
            if (y0 < y1) for (int x = x1 - 1; x >= x0; x--) order.add(y1 * COLS + x);
            if (x0 < x1) for (int y = y1 - 1; y > y0; y--) order.add(y * COLS + x0);
            x0++; y0++; x1--; y1--;
        }
        List<Integer> cells = new ArrayList<>();
        for (int c : order) if (!isPillar(c % COLS, c / COLS)) cells.add(c);
        SPIRAL = new int[cells.size()];
        Arrays.fill(SPIRAL_POS, -1);
        for (int i = 0; i < SPIRAL.length; i++) { SPIRAL[i] = cells.get(i); SPIRAL_POS[SPIRAL[i]] = i; }
    }

    private static boolean isPillar(int x, int y) { return (x & 1) == 1 && (y & 1) == 1; }

    public BomberSim() { this(new Random()); }

    public BomberSim(Random rnd) {
        this.rnd = rnd;
        for (int i = 0; i < 4; i++) { pl[i] = new Player(); pl[i].idx = i; }
    }

    // ------------------------------------------------------------------ set up

    /** Puts a player (or a computer player) into the corner number slot. Call before {@link #start()}. */
    public void setup(int slot, boolean ai, int level) {
        Player p = pl[slot];
        p.active = true; p.ai = ai; p.level = Math.max(0, Math.min(2, level));
    }

    /** Builds the field and puts the players in their corners. The round begins after the countdown. */
    public void start() {
        Arrays.fill(item, (byte) 0);
        Arrays.fill(flame, 0);
        bombs.clear();
        for (int y = 0; y < ROWS; y++)
            for (int x = 0; x < COLS; x++)
                tile[y * COLS + x] = isPillar(x, y) ? WALL : rnd.nextInt(100) < 72 ? CRATE : FLOOR;
        for (int i = 0; i < 4; i++) {
            int sx = (i & 1) == 0 ? 0 : COLS - 1, sy = i < 2 ? 0 : ROWS - 1;
            int ox = sx == 0 ? 1 : -1, oy = sy == 0 ? 1 : -1;
            int[][] open = {{0, 0}, {1, 0}, {2, 0}, {0, 1}, {0, 2}, {2, 1}, {1, 2}};
            for (int[] o : open) tile[(sy + o[1] * oy) * COLS + sx + o[0] * ox] = FLOOR;
            Player p = pl[i];
            p.x = sx * CELL; p.y = sy * CELL;
            p.alive = p.active;
            p.facing = 0; p.moving = -1; p.speed = 0; p.maxBombs = 1; p.range = 2; p.shield = 0; p.invuln = 0;
            p.kills = 0; p.crates = 0; p.place = 0; p.deadTick = 0; p.killer = -1; p.want = -1; p.bombReq = false; p.pause = 0;
        }
        state = ST_COUNT; countdown = COUNTDOWN; play = 0; tick = 0; winner = NONE; overTicks = 0;
        sudden = false; done = false; suddenNext = 0;
    }

    /** What a person wants right now: a direction (or -1) and whether to drop a bomb (counts once). */
    public void input(int slot, int dir, boolean bomb) {
        Player p = pl[slot];
        if (p.ai) return;
        p.want = dir < 0 || dir > 3 ? -1 : dir;
        if (bomb) p.bombReq = true;
    }

    /** A person leaves the round: he is out. */
    public void drop(int slot) {
        Player p = pl[slot];
        if (p.active && p.alive && state != ST_OVER) kill(p, -1, aliveCount());
    }

    // ------------------------------------------------------------------ the round

    public int aliveCount() {
        int n = 0;
        for (Player p : pl) if (p.alive) n++;
        return n;
    }

    public int bombsOf(int owner) {
        int n = 0;
        for (Bomb b : bombs) if (b.owner == owner) n++;
        return n;
    }

    public Bomb bombAt(int cx, int cy) {
        for (Bomb b : bombs) if (b.cx == cx && b.cy == cy) return b;
        return null;
    }

    public void tick() {
        tick++;
        if (state == ST_COUNT) {
            if (--countdown <= 0) state = ST_PLAY;
            return;
        }
        if (state == ST_OVER) {
            if (++overTicks >= END_DELAY) done = true;
            decay();
            burn(false);
            return;
        }
        play++;
        int aliveStart = aliveCount();

        // sudden death: the walls come in from the edge
        if (play >= SUDDEN_AT) {
            sudden = true;
            while (suddenNext < SPIRAL.length - LEFT_OPEN && SUDDEN_AT + suddenNext * SUDDEN_STEP <= play) closeCell(SPIRAL[suddenNext++], aliveStart);
        }

        for (Bomb b : bombs) b.fuse--;
        decay();
        refreshGrid();
        computeDanger(danger, null);
        for (Player p : pl) if (p.alive && p.ai) think(p);

        for (Player p : pl) {
            if (!p.alive) continue;
            if (p.invuln > 0) p.invuln--;
            if (p.bombReq) { p.bombReq = false; place(p); }
            move(p);
        }
        for (Bomb b : bombs) {
            for (int i = 0; i < 4; i++) {
                if ((b.pass & (1 << i)) != 0 && (pl[i].cx() != b.cx || pl[i].cy() != b.cy)) b.pass &= ~(1 << i);
            }
        }
        burn(true);

        for (Player p : pl) {
            if (!p.alive) continue;
            int c = p.cy() * COLS + p.cx();
            if (tile[c] == WALL) { kill(p, -1, aliveStart); continue; }
            if (flame[c] > 0) hit(p, flameOwner[c], aliveStart);
            if (p.alive && item[c] != 0) pickup(p, c);
        }

        int alive = 0, humans = 0, humansAlive = 0, last = -1;
        for (Player p : pl) {
            if (!p.active) continue;
            if (!p.ai) humans++;
            if (p.alive) { alive++; last = p.idx; if (!p.ai) humansAlive++; }
        }
        boolean timeUp = play >= SUDDEN_AT + (SPIRAL.length - LEFT_OPEN) * SUDDEN_STEP + TIME_UP;
        if (alive <= 1 || (humans > 0 && humansAlive == 0) || timeUp) {
            state = ST_OVER;
            overTicks = 0;
            if (alive == 1 && humansAlive > 0 || alive == 1 && humans == 0) { winner = last; pl[last].place = 1; }
            else winner = alive == 0 || timeUp && humansAlive > 0 ? DRAW : HUMANS_OUT;
        }
    }

    private void decay() {
        for (int i = 0; i < N; i++) if (flame[i] > 0) flame[i]--;
    }

    private void refreshGrid() {
        Arrays.fill(bombGrid, false);
        for (Bomb b : bombs) bombGrid[b.cy * COLS + b.cx] = true;
    }

    /** Bombs whose time has come explode, and so do the bombs they touch. */
    private void burn(boolean count) {
        List<Bomb> queueList = new ArrayList<>();
        for (Bomb b : bombs) if (b.fuse <= 0) queueList.add(b);
        if (queueList.isEmpty()) return;
        List<int[]> drops = new ArrayList<>();
        while (!queueList.isEmpty()) {
            Bomb b = queueList.remove(queueList.size() - 1);
            if (!bombs.remove(b)) continue;
            int n = rayCells(b.cx, b.cy, b.range, ray);
            for (int i = 0; i < n; i++) {
                int c = ray[i];
                flame[c] = FLAME;
                flameOwner[c] = b.owner;
                item[c] = 0;
                if (tile[c] == CRATE) {
                    tile[c] = FLOOR;
                    pl[b.owner].crates++;
                    int r = rnd.nextInt(100);
                    int it = r < 14 ? IT_BOMB : r < 28 ? IT_FLAME : r < 38 ? IT_SPEED : r < 42 ? IT_SHIELD : IT_NONE;
                    if (it != IT_NONE) drops.add(new int[]{c, it});
                }
                Bomb other = bombAt(c % COLS, c / COLS);
                if (other != null && other != b && !queueList.contains(other)) queueList.add(other);
            }
        }
        for (int[] d : drops) item[d[0]] = (byte) d[1];
        refreshGrid();
    }

    /**
     * The cells a bomb of this range lights: its own cell and four rays. A ray stops in front of a pillar, and ends in a
     * crate or in another bomb (that cell is lit as well). Returns how many cells were written into out.
     */
    private int rayCells(int cx, int cy, int range, int[] out) {
        int n = 0;
        out[n++] = cy * COLS + cx;
        for (int d = 0; d < 4; d++) {
            for (int i = 1; i <= range; i++) {
                int x = cx + DX[d] * i, y = cy + DY[d] * i;
                if (x < 0 || y < 0 || x >= COLS || y >= ROWS) break;
                int c = y * COLS + x;
                if (tile[c] == WALL) break;
                out[n++] = c;
                if (tile[c] == CRATE || bombGrid[c]) break;
            }
        }
        return n;
    }

    private void place(Player p) {
        int cx = p.cx(), cy = p.cy();
        if (tile[cy * COLS + cx] != FLOOR || bombAt(cx, cy) != null || bombsOf(p.idx) >= p.maxBombs) return;
        Bomb b = new Bomb(cx, cy, FUSE, p.idx, p.range);
        for (Player o : pl) if (o.alive && o.cx() == cx && o.cy() == cy) b.pass |= 1 << o.idx;
        bombs.add(b);
        bombGrid[cy * COLS + cx] = true;
    }

    private boolean canEnter(Player p, int nx, int ny) {
        if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS) return false;
        if (tile[ny * COLS + nx] != FLOOR) return false;
        Bomb b = bombAt(nx, ny);
        return b == null || (b.pass & (1 << p.idx)) != 0;
    }

    private void move(Player p) {
        int sp = SPEEDS[p.speed];
        boolean aligned = p.x % CELL == 0 && p.y % CELL == 0;
        if (p.moving >= 0 && p.want >= 0 && p.want == 3 - p.moving) p.moving = p.want;      // turning back is allowed in the middle of a step
        if (aligned) {
            p.moving = -1;
            if (p.want >= 0) {
                p.facing = p.want;
                if (canEnter(p, p.cx() + DX[p.want], p.cy() + DY[p.want])) p.moving = p.want;
            }
        }
        if (p.moving >= 0) {
            int d = p.moving;
            p.facing = d;
            int pos = DX[d] != 0 ? p.x : p.y;
            int rem = DX[d] + DY[d] > 0 ? (pos % CELL == 0 ? CELL : CELL - pos % CELL) : (pos % CELL == 0 ? CELL : pos % CELL);
            int step = Math.min(sp, rem);
            p.x += DX[d] * step;
            p.y += DY[d] * step;
        }
    }

    private void pickup(Player p, int c) {
        switch (item[c]) {
            case IT_BOMB -> p.maxBombs = Math.min(MAX_BOMBS, p.maxBombs + 1);
            case IT_FLAME -> p.range = Math.min(MAX_RANGE, p.range + 1);
            case IT_SPEED -> p.speed = Math.min(SPEEDS.length - 1, p.speed + 1);
            case IT_SHIELD -> p.shield = 1;
            default -> { }
        }
        item[c] = 0;
    }

    private void hit(Player p, int killer, int aliveStart) {
        if (!p.alive || p.invuln > 0) return;
        if (p.shield > 0) { p.shield--; p.invuln = 30; return; }
        kill(p, killer, aliveStart);
    }

    private void kill(Player p, int killer, int aliveStart) {
        if (!p.alive) return;
        p.alive = false;
        p.moving = -1;
        p.place = Math.max(1, aliveStart);
        p.deadTick = tick;
        p.killer = killer;
        if (killer >= 0 && killer != p.idx && pl[killer].active) pl[killer].kills++;
    }

    private void closeCell(int c, int aliveStart) {
        if (tile[c] == WALL) return;
        tile[c] = WALL;
        item[c] = 0;
        flame[c] = 0;
        bombs.removeIf(b -> b.cy * COLS + b.cx == c);
        for (Player p : pl) if (p.alive && p.cy() * COLS + p.cx() == c) kill(p, -1, aliveStart);
    }

    // ------------------------------------------------------------------ danger and the computer players

    /** For every cell: in how many ticks a flame comes (INF = none will, with the bombs that are there now; extra is a bomb that is only imagined). */
    private void computeDanger(int[] out, Bomb extra) {
        Arrays.fill(out, INF);
        int n = bombs.size() + (extra == null ? 0 : 1);
        if (n > 0) {
            Bomb[] all = new Bomb[n];
            int[] t = new int[n];
            int k = 0;
            for (Bomb b : bombs) { all[k] = b; t[k++] = Math.max(1, b.fuse); }
            if (extra != null) { all[k] = extra; t[k] = extra.fuse; }
            boolean[] saved = bombGrid.clone();
            if (extra != null) bombGrid[extra.cy * COLS + extra.cx] = true;
            int[][] cells = new int[n][];
            for (int i = 0; i < n; i++) {
                int[] buf = new int[64];
                int m = rayCells(all[i].cx, all[i].cy, all[i].range, buf);
                cells[i] = Arrays.copyOf(buf, m);
            }
            boolean changed = true;
            for (int guard = 0; changed && guard < n + 2; guard++) {       // a bomb in the flame of an earlier one goes off with it
                changed = false;
                for (int i = 0; i < n; i++)
                    for (int c : cells[i])
                        for (int j = 0; j < n; j++)
                            if (j != i && all[j].cy * COLS + all[j].cx == c && t[i] < t[j]) { t[j] = t[i]; changed = true; }
            }
            for (int i = 0; i < n; i++) for (int c : cells[i]) if (t[i] < out[c]) out[c] = t[i];
            System.arraycopy(saved, 0, bombGrid, 0, N);
        }
        if (play >= SUDDEN_AT - 60) {                                       // the walls that are about to close
            for (int k = suddenNext; k < SPIRAL.length - LEFT_OPEN; k++) {
                int when = SUDDEN_AT + k * SUDDEN_STEP - play;
                if (when > 70) break;
                int c = SPIRAL[k];
                if (when < out[c]) out[c] = Math.max(1, when);
            }
        }
    }

    private int ticksPerCell(Player p) {
        int sp = SPEEDS[p.speed];
        return (CELL + sp - 1) / sp;
    }

    /** Breadth-first search over the cells a player can walk to in time; dist is in ticks, first is the first direction of the way. */
    private void bfs(int start, int tpc, int margin, int[] dng) {
        Arrays.fill(dist, INF);
        Arrays.fill(first, -1);
        int head = 0, tail = 0;
        queue[tail++] = start;
        dist[start] = 0;
        while (head < tail) {
            int c = queue[head++];
            int cx = c % COLS, cy = c / COLS;
            for (int d = 0; d < 4; d++) {
                int nx = cx + DX[d], ny = cy + DY[d];
                if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS) continue;
                int n = ny * COLS + nx;
                if (dist[n] != INF || tile[n] != FLOOR || bombGrid[n]) continue;
                int a = dist[c] + tpc, half = tpc / 2;                       // a: when the player is in the middle of cell n; he is "in" it from a - half to a + half
                if (flame[n] > 0 && a - half <= flame[n] + 1) continue;
                if (dng[n] != INF && a + half + margin >= dng[n]) continue;
                dist[n] = a;
                first[n] = c == start ? d : first[c];
                queue[tail++] = n;
            }
        }
    }

    private void think(Player p) {
        boolean aligned = p.x % CELL == 0 && p.y % CELL == 0;
        if (!aligned) { p.want = p.moving; return; }
        int cx = p.cx(), cy = p.cy(), c = cy * COLS + cx;
        int lvl = p.level;
        int margin = lvl == 0 ? 0 : lvl == 1 ? 3 : 5;
        int tpc = ticksPerCell(p);
        p.want = -1;
        boolean threatened = flame[c] > 0 || (danger[c] != INF && (lvl > 0 || danger[c] < 36));
        if (!threatened && p.pause > 0) { p.pause--; return; }

        if (threatened) {
            bfs(c, tpc, margin, danger);
            int best = -1, bestD = INF;
            for (int i = 0; i < N; i++) if (i != c && dist[i] < INF && danger[i] == INF && dist[i] < bestD) { best = i; bestD = dist[i]; }
            if (best < 0) {                                                  // nowhere safe: the place that is hit last
                int latest = danger[c] == INF ? 0 : danger[c];
                for (int i = 0; i < N; i++) if (i != c && dist[i] < INF && danger[i] > latest) { best = i; latest = danger[i]; }
            }
            if (best >= 0) p.want = first[best];
            return;
        }

        if (lvl == 0 && rnd.nextInt(100) < 12) {                             // an easy player sometimes dreams
            p.pause = 2 + rnd.nextInt(6);
            if (rnd.nextBoolean()) { int d = rnd.nextInt(4); if (safeStep(p, cx, cy, d)) p.want = d; }
            return;
        }

        // a bomb here, if it is worth it and there is a way out
        if (bombsOf(p.idx) < p.maxBombs && !bombGrid[c] && rnd.nextInt(100) < (lvl == 0 ? 40 : lvl == 1 ? 75 : 100)) {
            int n = rayCells(cx, cy, p.range, ray);
            boolean worth = false;
            for (int i = 0; i < n && !worth; i++) {
                int rc = ray[i];
                if (tile[rc] == CRATE) worth = true;
                for (Player e : pl) if (e.alive && e != p && e.cy() * COLS + e.cx() == rc) worth = true;
            }
            if (lvl == 2 && !worth)                                          // a hard player also cuts the way of an enemy that is close
                for (Player e : pl) if (e.alive && e != p && Math.abs(e.cx() - cx) + Math.abs(e.cy() - cy) <= 2) worth = true;
            if (worth) {
                computeDanger(dangerTmp, new Bomb(cx, cy, FUSE, p.idx, p.range));
                boolean saved = bombGrid[c];
                bombGrid[c] = true;
                bfs(c, tpc, margin, dangerTmp);
                bombGrid[c] = saved;
                int best = -1, bestD = INF;
                for (int i = 0; i < N; i++) if (i != c && dist[i] < INF && dangerTmp[i] == INF && dist[i] < bestD) { best = i; bestD = dist[i]; }
                if (best >= 0) { p.bombReq = true; p.want = first[best]; return; }
            }
        }

        // walk to something worth walking to: a bonus, a place from where a bomb breaks crates, a place from where it reaches an enemy
        bfs(c, tpc, margin, danger);
        int best = -1, bestCost = INF;
        for (int i = 0; i < N; i++) {
            if (i == c || dist[i] >= INF || danger[i] != INF) continue;
            int cost = dist[i];
            boolean goal = false;
            if (item[i] != 0) { cost -= 70; goal = true; }
            else {
                int n = rayCells(i % COLS, i / COLS, p.range, ray);
                for (int k = 0; k < n; k++) {
                    int rc = ray[k];
                    if (tile[rc] == CRATE) goal = true;
                    if (lvl > 0) for (Player e : pl) if (e.alive && e != p && e.cy() * COLS + e.cx() == rc) { goal = true; cost -= lvl == 2 ? 30 : 10; }
                }
            }
            if (goal && cost < bestCost) { best = i; bestCost = cost; }
        }
        if (best >= 0) { p.want = first[best]; return; }
        if (lvl > 0 || rnd.nextInt(100) < 30) {                              // no crates left: go after the nearest enemy
            int target = -1, targetD = INF;
            for (Player e : pl) {
                if (!e.alive || e == p) continue;
                int d = Math.abs(e.cx() - cx) + Math.abs(e.cy() - cy);
                if (d < targetD) { targetD = d; target = e.cy() * COLS + e.cx(); }
            }
            if (target >= 0) {
                int ex = target % COLS, ey = target / COLS, bestScore = INF;
                for (int i = 0; i < N; i++) {
                    if (i == c || dist[i] >= INF || danger[i] != INF) continue;
                    int score = (Math.abs(i % COLS - ex) + Math.abs(i / COLS - ey)) * 100 + dist[i];
                    if (score < bestScore) { bestScore = score; best = i; }
                }
                int here = (Math.abs(cx - ex) + Math.abs(cy - ey)) * 100;
                if (best >= 0 && bestScore < here) { p.want = first[best]; return; }
            }
        }
        if (rnd.nextInt(100) < 50) {                                         // nothing to do: a little walk
            int d = rnd.nextInt(4);
            if (safeStep(p, cx, cy, d)) p.want = d;
        }
    }

    /** One step from (cx, cy) in direction d: possible, and nothing burns or is about to burn there. */
    private boolean safeStep(Player p, int cx, int cy, int d) {
        int nx = cx + DX[d], ny = cy + DY[d];
        if (!canEnter(p, nx, ny)) return false;
        int n = ny * COLS + nx;
        return danger[n] == INF && flame[n] == 0;
    }

    // ------------------------------------------------------------------ the network form

    /** The whole state as bytes (it is sent to the players 20 times a second). */
    public byte[] pack() {
        ByteBuffer b = ByteBuffer.allocate(32 + N + bombs.size() * 4 + 4 * 16);
        b.put((byte) state).putShort((short) countdown).putShort((short) play).put((byte) (winner + 2));
        b.put((byte) ((sudden ? 1 : 0) | (done ? 2 : 0)));
        for (int i = 0; i < N; i++) b.put((byte) (tile[i] | (item[i] << 2) | (flame[i] > 0 ? 32 : 0)));
        b.put((byte) bombs.size());
        for (Bomb bm : bombs) b.put((byte) bm.cx).put((byte) bm.cy).put((byte) Math.max(0, bm.fuse)).put((byte) (bm.owner | (bm.range << 2)));
        for (Player p : pl) {
            b.put((byte) ((p.active ? 1 : 0) | (p.alive ? 2 : 0) | (p.ai ? 4 : 0) | (p.shield > 0 ? 8 : 0) | (p.invuln > 0 ? 16 : 0) | (p.moving >= 0 ? 32 : 0)));
            b.putShort((short) p.x).putShort((short) p.y);
            b.put((byte) p.facing).put((byte) p.speed).put((byte) p.maxBombs).put((byte) p.range).put((byte) p.kills).put((byte) p.crates).put((byte) p.place);
        }
        return Arrays.copyOf(b.array(), b.position());
    }

    /** The other way: makes this object look like the state that was sent. Returns false if the bytes make no sense. */
    public boolean unpack(byte[] data) {
        try {
            ByteBuffer b = ByteBuffer.wrap(data);
            state = b.get();
            countdown = b.getShort();
            play = b.getShort();
            winner = b.get() - 2;
            int fl = b.get();
            sudden = (fl & 1) != 0;
            done = (fl & 2) != 0;
            for (int i = 0; i < N; i++) {
                int v = b.get() & 255;
                tile[i] = (byte) (v & 3);
                item[i] = (byte) ((v >> 2) & 7);
                flame[i] = (v & 32) != 0 ? 1 : 0;
            }
            int nb = b.get() & 255;
            bombs.clear();
            for (int i = 0; i < nb; i++) {
                int cx = b.get(), cy = b.get(), fuse = b.get() & 255, ow = b.get() & 255;
                Bomb bm = new Bomb(cx, cy, fuse, ow & 3, ow >> 2);
                bombs.add(bm);
            }
            for (Player p : pl) {
                int f = b.get();
                p.active = (f & 1) != 0; p.alive = (f & 2) != 0; p.ai = (f & 4) != 0;
                p.shield = (f & 8) != 0 ? 1 : 0; p.invuln = (f & 16) != 0 ? 1 : 0; p.moving = (f & 32) != 0 ? p.facing : -1;
                p.x = b.getShort(); p.y = b.getShort();
                p.facing = b.get(); p.speed = b.get(); p.maxBombs = b.get(); p.range = b.get(); p.kills = b.get(); p.crates = b.get(); p.place = b.get();
                if (p.speed < 0 || p.speed >= SPEEDS.length) return false;
            }
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** How the round went for a player, for the score: 40 for the win (15 for second place), 20 per player he put out, 1 per crate. */
    public int scoreOf(int slot) {
        Player p = pl[slot];
        int s = p.kills * 20 + p.crates;
        if (winner == slot) s += 40;
        else if (p.place == 2) s += 15;
        return s;
    }
}
