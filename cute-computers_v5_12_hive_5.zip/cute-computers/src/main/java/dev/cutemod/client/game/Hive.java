package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import dev.cutemod.client.os.Fit;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Quiet Hive: an Among Us style game for one player. Eight pets live on a small station, two of them are impostors.
 * You are the crew (do tasks, report bodies, argue and vote) or an impostor (kill, vent, sabotage, lie), every second game
 * the other role. The seven bots are not decoration: each one walks the map, remembers who it saw and where, and at a
 * meeting says what it really saw (or, if it is an impostor, lies). The vote follows what the bots believe.
 * The camera follows the player, the rest of the map is hidden by walls and fog.
 */
public class Hive extends MiniGame {
    private static final int T = 8, MW = 64, MH = 40, N = 8, PER = 4, SIGHT = 70, SPOTS = 18;
    private static final int PH_ROLE = 0, PH_PLAY = 1, PH_MEET = 2, PH_END = 3;
    private static final int M_INTRO = 0, M_TALK = 1, M_VOTE = 2, M_SHOW = 3, M_EJECT = 4;
    private static final int K_WIRES = 0, K_UPLOAD = 1, K_FUEL = 2, K_KEYPAD = 3, K_BUGS = 4, K_CALIB = 5,
            K_SIMON = 6, K_SWITCH = 7, K_SORT = 8, K_PAIRS = 9;
    private static final int A_USE = 0, A_REPORT = 1, A_KILL = 2, A_VENT = 3, A_DARK = 4, A_CORE = 5, A_MAP = 6;
    private static final int[] CREW_ACTS = {A_USE, A_REPORT, A_MAP};
    private static final int[] IMP_ACTS = {A_USE, A_KILL, A_VENT, A_DARK, A_CORE, A_MAP};
    private static final String[] ACT_KEYS = {"use", "report", "kill", "vent", "dark", "core", "map"};
    private static final int KILL_CD = 1500;
    private static final float SPEED = 1.0F, BOT_SPEED = 0.85F;

    // pet = 0 pig, 1 frog, 2 panda, 3 mouse, 4 fox, 5 koala, 6 cat, 7 bear
    private static final int[] COLORS = {0xFFF4A7C3, 0xFF7ED957, 0xFFF4F0E8, 0xFF6FA8F2, 0xFFF5A04A, 0xFFB57BD6, 0xFFF3D46A, 0xFFE0594F};
    // rooms: 0 cafeteria, 1 engine, 2 electrical, 3 storage, 4 lab, 5 navigation, 6 garden, 7 hallway
    private static final int[][] ROOMS = {{23, 13, 18, 14}, {2, 2, 14, 10}, {2, 28, 14, 10}, {25, 29, 14, 9}, {48, 2, 14, 10}, {48, 28, 14, 10}, {25, 2, 14, 9}};
    private static final int[][] HALLS = {{30, 11, 3, 2}, {30, 27, 3, 2}, {7, 12, 3, 16}, {53, 12, 3, 16}, {10, 18, 13, 3}, {41, 18, 12, 3}};
    private static final int[][] BLOCKS = {{31, 19, 2, 2}, {10, 4, 2, 2}, {10, 31, 2, 2}, {54, 4, 2, 2}, {54, 31, 2, 2}, {31, 4, 2, 2}, {31, 32, 2, 2}};
    // floor colours per room (two tones for the checker): cafeteria, engine, electrical, storage, lab, navigation, garden, hallway
    private static final int[] ROOM_A = {0xFFE8CDB0, 0xFF9AA3B5, 0xFF7F8FC4, 0xFFC9A67E, 0xFFCDEBE4, 0xFF7BA6D9, 0xFF9AD27F, 0xFFB9A8E0};
    private static final int[] ROOM_B = {0xFFE0C3A5, 0xFF909AAE, 0xFF7584B9, 0xFFC09D74, 0xFFC2E2DA, 0xFF729DD0, 0xFF90C876, 0xFFB0A0D8};
    private static final int WALL_TOP = 0xFF3E3478, WALL_FRONT = 0xFF6E60BA;
    private static final int[] TX = {13, 3, 13, 4, 27, 36, 50, 59, 50, 59, 36, 27, 24, 39, 39, 8, 57, 56};
    private static final int[] TY = {4, 9, 35, 30, 34, 31, 4, 9, 35, 30, 4, 8, 14, 24, 15, 35, 6, 35};
    private static final int[] KIND = {K_FUEL, K_CALIB, K_SWITCH, K_BUGS, K_UPLOAD, K_SORT, K_BUGS, K_KEYPAD, K_SIMON, K_WIRES, K_PAIRS, K_UPLOAD, K_WIRES, K_FUEL,
            K_SWITCH, K_SORT, K_SIMON, K_PAIRS};
    private static final int[] VX = {3, 3, 26, 60, 60, 26}, VY = {3, 36, 3, 3, 36, 36}, VG = {0, 0, 0, 1, 1, 1};
    private static final int LX = 13, LY = 29;                       // the light panel
    private static final int[] CX = {13, 51}, CY = {9, 30};          // the two reactor consoles
    private static final int BX = 256, BY = 160;                     // the emergency button (pixels)
    private static final int[] WIRE_COL = {0xFFE0594F, 0xFF4A8FE0, 0xFFF3D46A};
    private static final int PX = 14, PY = 6, PW = 192, PH = 128;     // the task window

    private static boolean nextImp, roleSeen;

    private static final class Actor {
        final int id;
        boolean imp, alive = true, vented;
        float x, y;
        int face = 1;
        int[] path = new int[0];
        int pp;
        int mode, timer, taskI = -1, fixKind = -1, hunt = -1, huntT, killCd, ventAt = -1, ventT, bodyT = -1, ghostT, lastRoom;
        int witness = -1, witnessV = -1, ventSaw = -1;
        boolean called;
        final int[] together = new int[N];            // how long this bot has been in company of each other pet
        final int[][] with = new int[N][N];           // when it last saw two pets together
        final int[] seenTick = new int[N], seenRoom = new int[N], susp = new int[N];
        final int[] spot = new int[PER];
        final boolean[] done = new boolean[PER];

        Actor(int id) { this.id = id; }
    }

    private static final class Body { int victim, killer, room, tick; float x, y; boolean reported; }

    private static final class Line {
        final int who;
        final Component text;

        Line(int who, Component text) { this.who = who; this.text = text; }
    }

    private final boolean[][] solid = new boolean[MH][MW];
    private final boolean[][] blk = new boolean[MH][MW];
    private final boolean[][] vis = new boolean[MH][MW];
    private final Actor[] act = new Actor[N];
    private final int[] pet = new int[N];
    private final List<Body> bodies = new ArrayList<>();
    private final List<Line> lines = new ArrayList<>();

    private int phase, phaseT, ticks, kills, doneTasks, totalTasks, killFlash;
    private boolean playerImp, crewWon, won;
    private boolean lightsOut, reactorOn, buttonUsed, mapOpen;
    private int reactorT, sabCd, hold;
    private final boolean[] consoleOk = new boolean[2];

    // task window
    private boolean taskOpen, tFix, tFake;
    private int tKind, tIdx, tDone;
    private final int[] wr = new int[3], wc = new int[3];
    private int wsel, upT, knext, cz, chit;
    private boolean upOn;
    private float fuel, cm, cv;
    private final int[] kx = new int[5], ky = new int[5];
    private final float[] bx = new float[6], by = new float[6], bvx = new float[6], bvy = new float[6];
    private final boolean[] bdead = new boolean[6];
    private final int[] sq = new int[4];                 // the melody
    private int sqIn, sqT, sqFl, sqFlT;
    private boolean sqShow;
    private final boolean[] swT = new boolean[6], swS = new boolean[6];
    private int sortC, sortN;
    private final int[] pcV = new int[6];
    private final boolean[] pcUp = new boolean[6], pcOk = new boolean[6];
    private int pcA, pcWait, pcDone;

    // meeting
    private int mstate, mt, caller, bodyIdx, shown, lineT, sel, pVote, pActs, ejected, skipCount, contras, scoreOut;
    private boolean ejWasImp;
    private final int[] vote = new int[N], tally = new int[N], pub = new int[N];
    private final boolean[] asked = new boolean[N];
    private int insertAt = -1;

    public Hive() { buildMap(); }

    private void buildMap() {
        for (boolean[] r : solid) java.util.Arrays.fill(r, true);
        for (int[] r : ROOMS) carve(r, false);
        for (int[] r : HALLS) carve(r, false);
        for (int[] r : BLOCKS) {
            carve(r, true);
            for (int y = r[1]; y < r[1] + r[3]; y++) for (int x = r[0]; x < r[0] + r[2]; x++) blk[y][x] = true;
        }
    }

    private void carve(int[] r, boolean s) {
        for (int y = r[1]; y < r[1] + r[3]; y++) for (int x = r[0]; x < r[0] + r[2]; x++) solid[y][x] = s;
    }

    // ------------------------------------------------------------------ start

    @Override
    public void reset() {
        score = 0; over = false; won = false; crewWon = false;
        phase = PH_ROLE; phaseT = 200; ticks = 0; kills = 0; doneTasks = 0; killFlash = 0;
        bodies.clear(); lines.clear();
        lightsOut = false; reactorOn = false; reactorT = 0; sabCd = 900; buttonUsed = false; hold = 0;
        taskOpen = false; mapOpen = false;
        int[] perm = {0, 1, 2, 3, 4, 5, 6, 7};
        for (int i = N - 1; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = perm[i]; perm[i] = perm[j]; perm[j] = t; }
        System.arraycopy(perm, 0, pet, 0, N);
        nextImp = roleSeen ? !nextImp : rnd.nextBoolean();      // every second game is the other role
        roleSeen = true;
        playerImp = nextImp;
        boolean[] imp = new boolean[N];
        if (playerImp) imp[0] = true;
        int need = playerImp ? 1 : 2;
        while (need > 0) { int i = 1 + rnd.nextInt(N - 1); if (!imp[i]) { imp[i] = true; need--; } }
        totalTasks = 0;
        for (int i = 0; i < N; i++) {
            Actor a = new Actor(i);
            act[i] = a;
            a.imp = imp[i];
            int c = 0;
            while (c < PER) {
                int s = rnd.nextInt(SPOTS);
                boolean dup = false;
                for (int k = 0; k < c; k++) if (a.spot[k] == s) dup = true;
                if (!dup) a.spot[c++] = s;
            }
            if (!a.imp) totalTasks += PER;
            float ang = i * (float) Math.PI / 4F;
            a.x = BX + (float) Math.cos(ang) * 30F;
            a.y = BY + (float) Math.sin(ang) * 30F;
            a.killCd = 1500 + rnd.nextInt(900);
            for (int k = 0; k < N; k++) { a.seenTick[k] = -99999; a.seenRoom[k] = 0; }
            for (int[] w : a.with) java.util.Arrays.fill(w, -99999);
        }
        act[0].killCd = 600;
    }

    // ------------------------------------------------------------------ helpers

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private String nm(int id) { return tr("cutemod.hive.name." + pet[id]); }

    private static String rm(int r) { return tr("cutemod.hive.room." + Math.max(0, Math.min(7, r))); }

    private static float dist(float x0, float y0, float x1, float y1) {
        float dx = x1 - x0, dy = y1 - y0;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private boolean solidTile(int tx, int ty) { return tx < 0 || ty < 0 || tx >= MW || ty >= MH || solid[ty][tx]; }

    private boolean solidAt(float x, float y) { return solidTile((int) Math.floor(x / T), (int) Math.floor(y / T)); }

    private boolean free(float x, float y) {
        return !solidAt(x - 3, y - 3) && !solidAt(x + 3, y - 3) && !solidAt(x - 3, y + 3) && !solidAt(x + 3, y + 3);
    }

    private int roomTile(int tx, int ty) {
        for (int i = 0; i < ROOMS.length; i++) {
            int[] r = ROOMS[i];
            if (tx >= r[0] && tx < r[0] + r[2] && ty >= r[1] && ty < r[1] + r[3]) return i;
        }
        return 7;
    }

    private int roomAt(float x, float y) { return roomTile((int) (x / T), (int) (y / T)); }

    /** True if nothing solid is between the two points (the tile of the target itself does not count). */
    private boolean los(float x0, float y0, float x1, float y1) {
        int tx = (int) (x1 / T), ty = (int) (y1 / T);
        float dx = x1 - x0, dy = y1 - y0;
        int n = (int) (Math.sqrt(dx * dx + dy * dy) / 3F) + 1;
        for (int i = 1; i < n; i++) {
            float f = i / (float) n;
            int cx = (int) ((x0 + dx * f) / T), cy = (int) ((y0 + dy * f) / T);
            if (cx == tx && cy == ty) return true;
            if (solidTile(cx, cy)) return false;
        }
        return true;
    }

    private boolean near(Actor a, float x, float y, float r) { return dist(a.x, a.y, x, y) < r; }

    private static int clampi(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private int[] bfs(int sx, int sy, int gx, int gy) {
        sx = clampi(sx, 0, MW - 1); sy = clampi(sy, 0, MH - 1); gx = clampi(gx, 0, MW - 1); gy = clampi(gy, 0, MH - 1);
        int[] prev = new int[MW * MH];
        java.util.Arrays.fill(prev, -2);
        int[] q = new int[MW * MH];
        int h = 0, t = 0, s = sy * MW + sx, goal = gy * MW + gx;
        prev[s] = -1; q[t++] = s;
        int[] ddx = {1, -1, 0, 0}, ddy = {0, 0, 1, -1};
        while (h < t) {
            int c = q[h++];
            if (c == goal) break;
            int cx = c % MW, cy = c / MW;
            for (int k = 0; k < 4; k++) {
                int nx = cx + ddx[k], ny = cy + ddy[k];
                if (nx < 0 || ny < 0 || nx >= MW || ny >= MH || solid[ny][nx]) continue;
                int n = ny * MW + nx;
                if (prev[n] != -2) continue;
                prev[n] = c; q[t++] = n;
            }
        }
        if (prev[goal] == -2) return new int[0];
        int len = 0;
        for (int c = goal; c != -1; c = prev[c]) len++;
        int[] out = new int[len];
        int i = len - 1;
        for (int c = goal; c != -1; c = prev[c]) out[i--] = c;
        return out;
    }

    private void setPath(Actor a, int tx, int ty) {
        a.path = bfs((int) (a.x / T), (int) (a.y / T), tx, ty);
        a.pp = a.path.length > 1 ? 1 : 0;
    }

    private boolean walk(Actor a, float sp) {
        if (a.pp >= a.path.length) return false;
        int t = a.path[a.pp];
        float tx = (t % MW) * T + T / 2F, ty = (t / MW) * T + T / 2F;
        float dx = tx - a.x, dy = ty - a.y, d = dist(0, 0, dx, dy);
        if (d <= sp) { a.x = tx; a.y = ty; a.pp++; return a.pp < a.path.length; }
        a.x += dx / d * sp;
        a.y += dy / d * sp;
        if (Math.abs(dx) > 0.4F) a.face = dx > 0 ? 1 : -1;
        return true;
    }

    private int nearVent(float x, float y, float r) {
        int best = -1;
        float bd = r;
        for (int i = 0; i < VX.length; i++) {
            float d = dist(x, y, VX[i] * T + 4, VY[i] * T + 4);
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }

    private int nextVent(int vi, int dir) {
        int n = VX.length;
        for (int k = 1; k <= n; k++) {
            int i = ((vi + dir * k) % n + n) % n;
            if (VG[i] == VG[vi] && i != vi) return i;
        }
        return vi;
    }

    /** How far a pet sees other pets: the lights going out blinds the crew (and only the crew). */
    private int sightOf(Actor w) { return w.imp ? SIGHT : (lightsOut ? 26 : SIGHT); }

    private int vision() {
        Actor p = act[0];
        if (!p.alive) return 999;
        if (p.imp) return 90;
        return lightsOut ? 38 : 90;
    }

    // ------------------------------------------------------------------ play

    @Override
    public void tick() {
        if (phase == PH_ROLE) { if (--phaseT <= 0) phase = PH_PLAY; return; }
        if (phase == PH_END) { if (--phaseT <= 0) over = true; return; }
        if (phase == PH_MEET) { meetTick(); return; }
        playTick();
    }

    private void playTick() {
        ticks++;
        Actor p = act[0];
        if (killFlash > 0) killFlash--;
        if (taskOpen) updateTask(); else movePlayer();
        // hold E at a reactor console
        boolean holding = false;
        if (reactorOn && !p.imp && !p.vented && !taskOpen && down(69)) {
            for (int i = 0; i < 2; i++) {
                if (!consoleOk[i] && near(p, CX[i] * T + 4, CY[i] * T + 4, 16)) {
                    holding = true;
                    if (++hold >= 120) { hold = 0; completeFix(i + 1); }
                }
            }
        }
        if (!holding) hold = 0;
        for (int i = 1; i < N; i++) botTick(act[i]);
        if (p.killCd > 0) p.killCd--;
        if (ticks % 8 == 0) observe();
        if (!lightsOut && !reactorOn) {
            if (sabCd > 0) sabCd--;
            else if (ticks % 60 == 0 && rnd.nextInt(100) < 5 && botImpAlive()) trigger(rnd.nextInt(2));
        } else if (ticks % 300 == 0) assignFixers();
        if (reactorOn && --reactorT <= 0) { reactorOn = false; end(false); }
    }

    private boolean botImpAlive() {
        for (int i = 1; i < N; i++) if (act[i].imp && act[i].alive) return true;
        return false;
    }

    private void movePlayer() {
        Actor p = act[0];
        if (p.vented) return;
        int dx = 0, dy = 0;
        if (down(87) || down(KEY_UP)) dy--;
        if (down(83) || down(KEY_DOWN)) dy++;
        if (down(65) || down(KEY_LEFT)) dx--;
        if (down(68) || down(KEY_RIGHT)) dx++;
        if (dx == 0 && dy == 0) return;
        float sp = p.alive ? SPEED : 1.3F;
        if (dx != 0 && dy != 0) sp *= 0.707F;
        if (dx != 0) p.face = dx;
        float nx = p.x + dx * sp;
        if (!p.alive || free(nx, p.y)) p.x = Math.max(4, Math.min(MW * T - 4, nx));
        float ny = p.y + dy * sp;
        if (!p.alive || free(p.x, ny)) p.y = Math.max(4, Math.min(MH * T - 4, ny));
    }

    /** What the bots see: who is where (for the talk at the meeting) and bodies. */
    private void observe() {
        int[] seen = new int[N];
        for (int i = 1; i < N; i++) {
            Actor b = act[i];
            if (!b.alive || b.vented) continue;
            int sr = sightOf(b), ns = 0;
            for (Actor o : act) {
                if (o == b || !o.alive || o.vented) continue;
                if (dist(b.x, b.y, o.x, o.y) < sr && los(b.x, b.y, o.x, o.y)) {
                    b.seenTick[o.id] = ticks;
                    b.seenRoom[o.id] = roomAt(o.x, o.y);
                    b.together[o.id] = Math.min(3000, b.together[o.id] + 8);
                    seen[ns++] = o.id;
                } else b.together[o.id] = Math.max(0, b.together[o.id] - 4);
            }
            for (int x = 0; x < ns; x++) for (int y = x + 1; y < ns; y++) { b.with[seen[x]][seen[y]] = ticks; b.with[seen[y]][seen[x]] = ticks; }
            if (b.imp || b.bodyT >= 0 || b.mode == 6) continue;       // impostors never report what they find
            for (int k = 0; k < bodies.size(); k++) {
                Body d = bodies.get(k);
                if (!d.reported && dist(b.x, b.y, d.x, d.y) < sr && los(b.x, b.y, d.x, d.y)) {
                    b.bodyT = k; b.mode = 5; b.fixKind = -1;
                    setPath(b, (int) (d.x / T), (int) (d.y / T));
                    break;
                }
            }
        }
    }

    private int nextTask(Actor b) {
        for (int i = 0; i < PER; i++) if (!b.done[i]) return i;
        return -1;
    }

    private void botTick(Actor b) {
        if (!b.alive) {                     // a dead crewmate finishes its tasks slowly
            if (!b.imp && ++b.ghostT >= 1500) {
                b.ghostT = 0;
                for (int i = 0; i < PER; i++) if (!b.done[i]) { b.done[i] = true; doneTasks++; break; }
                checkWin();
            }
            return;
        }
        if (b.killCd > 0) b.killCd--;
        if (b.vented) { if (--b.ventT <= 0) ventExit(b); return; }
        if (b.imp && b.killCd <= 0 && (b.mode == 0 || b.mode == 1 || b.mode == 2) && ticks % 10 == b.id) tryHunt(b);
        if (!b.imp && !b.called && (b.mode == 0 || b.mode == 1 || b.mode == 2) && (b.witness >= 0 || b.ventSaw >= 0)
                && !lightsOut && !reactorOn && ticks % 20 == b.id) { b.mode = 8; setPath(b, BX / T, BY / T + 2); }     // it knows who it is: to the emergency button
        switch (b.mode) {
            case 0 -> {
                int t = nextTask(b);
                if (t >= 0) { b.taskI = t; setPath(b, TX[b.spot[t]], TY[b.spot[t]]); }
                else { b.taskI = -1; int s = rnd.nextInt(SPOTS); setPath(b, TX[s], TY[s]); }
                b.mode = 1;
            }
            case 1 -> {
                if (!walk(b, BOT_SPEED)) { b.mode = 2; b.timer = b.taskI >= 0 ? 260 + rnd.nextInt(260) : 90 + rnd.nextInt(150); }
            }
            case 2 -> {
                if (--b.timer <= 0) {
                    if (b.taskI >= 0) { b.done[b.taskI] = true; if (!b.imp) { doneTasks++; checkWin(); } }
                    b.mode = 0;
                }
            }
            case 3 -> {
                if (fixDone(b.fixKind)) { b.mode = 0; b.fixKind = -1; }
                else if (!walk(b, BOT_SPEED + 0.1F)) { b.mode = 4; b.timer = 150; }
            }
            case 4 -> {
                if (fixDone(b.fixKind)) { b.mode = 0; b.fixKind = -1; }
                else if (--b.timer <= 0) { int k = b.fixKind; b.mode = 0; b.fixKind = -1; completeFix(k); }
            }
            case 5 -> {
                if (b.bodyT < 0 || b.bodyT >= bodies.size() || bodies.get(b.bodyT).reported) { b.bodyT = -1; b.mode = 0; }
                else {
                    Body d = bodies.get(b.bodyT);
                    if (dist(b.x, b.y, d.x, d.y) < 16) startMeeting(b.id, b.bodyT);
                    else if (!walk(b, BOT_SPEED + 0.15F)) setPath(b, (int) (d.x / T), (int) (d.y / T));
                }
            }
            case 6 -> huntTick(b);
            case 8 -> {
                if (lightsOut || reactorOn) b.mode = 0;
                else if (dist(b.x, b.y, BX, BY) < 24 || !walk(b, BOT_SPEED + 0.15F)) { b.called = true; b.mode = 0; startMeeting(b.id, -1); }
            }
            default -> b.mode = 0;
        }
    }

    // ------------------------------------------------------------------ killing

    private int witnesses(Actor killer, Actor victim) {
        int n = 0;
        for (Actor w : act) {
            if (w == killer || w == victim || !w.alive || w.imp || w.vented) continue;
            float r = lightsOut ? 26F : SIGHT + 10F;
            if (dist(w.x, w.y, killer.x, killer.y) < r && los(w.x, w.y, killer.x, killer.y)) n++;
        }
        return n;
    }

    private void tryHunt(Actor b) {
        Actor best = null;
        float bd = 1e9F;
        for (Actor v : act) {
            if (v.imp || !v.alive || v.vented) continue;
            float d = dist(b.x, b.y, v.x, v.y);
            if (d < 72 && d < bd && los(b.x, b.y, v.x, v.y)) { best = v; bd = d; }
        }
        if (best == null) return;
        int wit = witnesses(b, best);
        if (wit > 0 && wit <= 2 && !lightsOut && !reactorOn && sabCd <= 0 && rnd.nextInt(100) < 20) { trigger(0); wit = witnesses(b, best); }   // darkness blinds the witnesses
        if (wit > 0) return;
        if (rnd.nextInt(100) < 35) { b.hunt = best.id; b.huntT = 360; b.mode = 6; }
    }

    private void huntTick(Actor b) {
        Actor v = act[Math.max(0, b.hunt)];
        if (b.hunt < 0 || !v.alive || v.imp || --b.huntT <= 0) { b.mode = 0; b.hunt = -1; return; }
        if (ticks % 15 == 0) setPath(b, (int) (v.x / T), (int) (v.y / T));
        if (dist(b.x, b.y, v.x, v.y) < 11) {
            if (witnesses(b, v) == 0) doKill(b, v);
            else { b.mode = 0; b.hunt = -1; b.killCd = 300; }
            return;
        }
        walk(b, BOT_SPEED + 0.1F);
    }

    private void doKill(Actor k, Actor v) {
        Body d = new Body();
        d.victim = v.id; d.killer = k.id; d.x = v.x; d.y = v.y; d.tick = ticks; d.room = roomAt(v.x, v.y);
        bodies.add(d);
        v.alive = false; v.vented = false;
        for (Actor w : act) {
            if (w == k || w == v || !w.alive || w.imp || w.vented) continue;
            if (dist(w.x, w.y, v.x, v.y) < (lightsOut ? 26F : SIGHT) && los(w.x, w.y, v.x, v.y)) { w.witness = k.id; w.witnessV = v.id; }
        }
        k.x = v.x; k.y = v.y; k.path = new int[0]; k.pp = 0;
        k.killCd = k.id == 0 ? KILL_CD : 2000 + rnd.nextInt(900);
        sound(SoundEvents.PLAYER_HURT, 0.8F, 0.6F);
        if (k.id == 0) kills++;
        else {
            k.hunt = -1; k.mode = 0;
            int r = rnd.nextInt(100);
            if (r < 30) tryBotVent(k);
            else if (r < 50 && witnesses(k, v) == 0) { k.bodyT = bodies.size() - 1; k.mode = 5; }   // reports its own kill
            else if (r < 85) flee(k, d.room);
        }
        if (v.id == 0) { killFlash = 90; taskOpen = false; mapOpen = false; }
        checkWin();
    }

    /** After a kill: away from the body, to a task in another room, as if nothing happened. */
    private void flee(Actor k, int room) {
        int sp = rnd.nextInt(SPOTS);
        for (int tries = 0; tries < 8 && roomTile(TX[sp], TY[sp]) == room; tries++) sp = rnd.nextInt(SPOTS);
        k.taskI = -1;
        setPath(k, TX[sp], TY[sp]);
        k.mode = 1;
    }

    private void tryBotVent(Actor b) {
        int vi = nearVent(b.x, b.y, 32);
        if (vi < 0) return;
        ventWitness(b.x, b.y, b.id);
        b.vented = true; b.ventAt = vi; b.ventT = 100 + rnd.nextInt(120);
        b.x = VX[vi] * T + 4; b.y = VY[vi] * T + 4;
    }

    private void ventExit(Actor b) {
        int vi = nextVent(b.ventAt, 1);
        b.vented = false; b.mode = 0; b.ventAt = -1;
        b.x = VX[vi] * T + 4; b.y = VY[vi] * T + 4;
        ventWitness(b.x, b.y, b.id);
    }

    private void ventWitness(float x, float y, int id) {
        for (Actor w : act) {
            if (w.id == id || !w.alive || w.imp || w.vented || w.id == 0) continue;
            if (dist(w.x, w.y, x, y) < (lightsOut ? 26F : SIGHT) && los(w.x, w.y, x, y)) w.ventSaw = id;
        }
    }

    // ------------------------------------------------------------------ sabotage

    private void trigger(int kind) {
        if (kind == 0) lightsOut = true;
        else { reactorOn = true; reactorT = 2100; consoleOk[0] = false; consoleOk[1] = false; }
        sabCd = 1500;
        assignFixers();
        sound(SoundEvents.BELL_BLOCK, 0.6F, 0.7F);
    }

    private void assignFixers() {
        if (lightsOut) assignNear(LX, LY, 0);
        if (reactorOn) { assignNear(CX[0], CY[0], 1); assignNear(CX[1], CY[1], 2); }
    }

    private void assignNear(int tx, int ty, int kind) {
        int have = 0;
        int want = kind == 0 ? 2 : 1;
        for (int i = 1; i < N; i++) if (act[i].alive && act[i].fixKind == kind) have++;
        while (have < want) {
            Actor best = null;
            float bd = 1e9F;
            for (int i = 1; i < N; i++) {
                Actor b = act[i];
                if (!b.alive || b.imp || b.vented || b.fixKind >= 0 || b.mode == 5) continue;
                float d = dist(b.x, b.y, tx * T + 4, ty * T + 4);
                if (d < bd) { bd = d; best = b; }
            }
            if (best == null) return;
            best.fixKind = kind; best.mode = 3;
            setPath(best, tx, ty);
            have++;
        }
    }

    private boolean fixDone(int kind) {
        if (kind == 0) return !lightsOut;
        return !reactorOn || consoleOk[kind - 1];
    }

    private void completeFix(int kind) {
        if (kind == 0) lightsOut = false;
        else {
            consoleOk[kind - 1] = true;
            if (consoleOk[0] && consoleOk[1]) reactorOn = false;
        }
        pling(1.3F);
    }

    // ------------------------------------------------------------------ the player's actions

    @Override
    public boolean key(int k) {
        if (phase == PH_ROLE) { phaseT = 0; return true; }
        if (phase != PH_PLAY) return false;
        Actor p = act[0];
        if (mapOpen) { mapOpen = false; return true; }
        if (taskOpen) {
            if (tKind == K_FUEL && k == KEY_SPACE && tDone == 0) { fuel = Math.min(100F, fuel + 7F); beep(); }
            return true;
        }
        if (p.vented) {
            if (k == KEY_RIGHT) { hopVent(1); return true; }
            if (k == KEY_LEFT) { hopVent(-1); return true; }
            if (k == KEY_SPACE || k == 86) { doAction(A_VENT); return true; }
            return false;
        }
        if (k == 69) { doAction(A_USE); return true; }
        if (k == 82) { doAction(A_REPORT); return true; }
        if (k == 81) { doAction(A_KILL); return true; }
        if (k == 86) { doAction(A_VENT); return true; }
        if (k == 77) { doAction(A_MAP); return true; }
        if (k == 49) { doAction(A_DARK); return true; }
        if (k == 50) { doAction(A_CORE); return true; }
        return false;
    }

    private void doAction(int a) {
        switch (a) {
            case A_USE -> use();
            case A_REPORT -> report();
            case A_KILL -> kill();
            case A_VENT -> ventAction();
            case A_DARK -> sabotage(0);
            case A_CORE -> sabotage(1);
            default -> mapOpen = !mapOpen;
        }
    }

    private void use() {
        Actor p = act[0];
        if (p.vented || (!p.alive && p.imp)) return;
        if (lightsOut && !p.imp && near(p, LX * T + 4, LY * T + 4, 16)) { startTask(K_KEYPAD, -1, true, false); return; }
        for (int i = 0; i < PER; i++) {
            if (p.done[i]) continue;
            int s = p.spot[i];
            if (near(p, TX[s] * T + 4, TY[s] * T + 4, 14)) { startTask(KIND[s], i, false, p.imp); return; }
        }
        if (p.alive && !buttonUsed && !lightsOut && !reactorOn && near(p, BX, BY, 26)) { buttonUsed = true; startMeeting(0, -1); }
    }

    private void report() {
        Actor p = act[0];
        if (!p.alive || p.vented) return;
        for (int i = 0; i < bodies.size(); i++) {
            Body d = bodies.get(i);
            if (!d.reported && dist(p.x, p.y, d.x, d.y) < 24 && los(p.x, p.y, d.x, d.y)) { startMeeting(0, i); return; }
        }
    }

    private Actor killTarget() {
        Actor p = act[0];
        if (!playerImp || !p.alive || p.vented || phase != PH_PLAY) return null;
        Actor best = null;
        float bd = 22F;
        for (Actor a : act) {
            if (a.imp || !a.alive || a.vented) continue;
            float d = dist(p.x, p.y, a.x, a.y);
            if (d < bd && los(p.x, p.y, a.x, a.y)) { bd = d; best = a; }
        }
        return best;
    }

    private void kill() {
        Actor p = act[0];
        if (!playerImp || p.killCd > 0) return;
        Actor v = killTarget();
        if (v != null) doKill(p, v);
    }

    private void ventAction() {
        Actor p = act[0];
        if (!playerImp || !p.alive) return;
        if (!p.vented) {
            int vi = nearVent(p.x, p.y, 14);
            if (vi < 0) return;
            ventWitness(p.x, p.y, 0);
            p.vented = true; p.ventAt = vi;
            p.x = VX[vi] * T + 4; p.y = VY[vi] * T + 4;
            sound(SoundEvents.ENDERMAN_TELEPORT, 1.2F, 0.5F);
        } else {
            p.vented = false;
            ventWitness(p.x, p.y, 0);
            sound(SoundEvents.ENDERMAN_TELEPORT, 1.4F, 0.5F);
        }
    }

    private void hopVent(int dir) {
        Actor p = act[0];
        p.ventAt = nextVent(p.ventAt, dir);
        p.x = VX[p.ventAt] * T + 4; p.y = VY[p.ventAt] * T + 4;
        beep();
    }

    private void sabotage(int kind) {
        if (!playerImp || sabCd > 0 || lightsOut || reactorOn || phase != PH_PLAY) return;
        trigger(kind);
    }

    // ------------------------------------------------------------------ win

    private void checkWin() {
        if (phase == PH_END) return;
        int ac = 0, ai = 0;
        for (Actor a : act) if (a.alive) { if (a.imp) ai++; else ac++; }
        if (ai == 0) end(true);
        else if (ai >= ac) end(false);
        else if (doneTasks >= totalTasks) end(true);
    }

    private void end(boolean crewWins) {
        if (phase == PH_END) return;
        phase = PH_END; phaseT = 150; crewWon = crewWins; won = crewWins != playerImp;
        taskOpen = false; mapOpen = false;
        int mine = 0;
        for (int i = 0; i < PER; i++) if (act[0].done[i]) mine++;
        score = playerImp ? kills * 20 : mine * 10;
        if (won) score += 60;
        if (won) sound(SoundEvents.PLAYER_LEVELUP, 1.0F, 0.6F); else sound(SoundEvents.VILLAGER_NO, 0.8F, 0.6F);
    }

    // ------------------------------------------------------------------ tasks

    private void startTask(int kind, int idx, boolean fix, boolean fake) {
        taskOpen = true; tKind = kind; tIdx = idx; tFix = fix; tFake = fake; tDone = 0;
        switch (kind) {
            case K_WIRES -> {
                int[] o = {0, 1, 2};
                for (int i = 2; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = o[i]; o[i] = o[j]; o[j] = t; }
                for (int i = 0; i < 3; i++) { wr[i] = o[i]; wc[i] = -1; }
                wsel = -1;
            }
            case K_UPLOAD -> { upT = 0; upOn = false; }
            case K_FUEL -> fuel = 0;
            case K_KEYPAD -> {
                int[] s = {0, 1, 2, 3, 4, 5};
                for (int i = 5; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = s[i]; s[i] = s[j]; s[j] = t; }
                for (int i = 0; i < 5; i++) { kx[i] = 44 + (s[i] % 3) * 56; ky[i] = 54 + (s[i] / 3) * 40; }
                knext = 0;
            }
            case K_BUGS -> {
                for (int i = 0; i < 6; i++) {
                    bx[i] = 40 + rnd.nextInt(140); by[i] = 46 + rnd.nextInt(72);
                    bvx[i] = (rnd.nextBoolean() ? 1 : -1) * (0.5F + rnd.nextFloat() * 0.7F);
                    bvy[i] = (rnd.nextBoolean() ? 1 : -1) * (0.4F + rnd.nextFloat() * 0.6F);
                    bdead[i] = false;
                }
            }
            case K_SIMON -> {
                for (int i = 0; i < 4; i++) sq[i] = rnd.nextInt(4);
                sqIn = 0; sqT = -24; sqShow = true; sqFl = -1; sqFlT = 0;
            }
            case K_SWITCH -> {
                int diff = 0;
                for (int i = 0; i < 6; i++) { swT[i] = rnd.nextBoolean(); swS[i] = rnd.nextBoolean(); if (swT[i] != swS[i]) diff++; }
                for (int i = 0; diff < 3; i++) { if (swT[i] == swS[i]) { swS[i] = !swS[i]; diff++; } }
            }
            case K_SORT -> { sortC = rnd.nextInt(3); sortN = 0; }
            case K_PAIRS -> {
                int[] v = {0, 0, 1, 1, 2, 2};
                for (int i = 5; i > 0; i--) { int j = rnd.nextInt(i + 1); int t = v[i]; v[i] = v[j]; v[j] = t; }
                for (int i = 0; i < 6; i++) { pcV[i] = v[i]; pcUp[i] = false; pcOk[i] = false; }
                pcA = -1; pcWait = 0; pcDone = 0;
            }
            default -> { cm = 0; cv = 1.9F; cz = 20 + rnd.nextInt(100); chit = 0; }
        }
    }

    private void updateTask() {
        if (tDone > 0) { if (--tDone <= 0) closeTask(true); return; }
        switch (tKind) {
            case K_UPLOAD -> { if (upOn && ++upT >= 300) finishTask(); }
            case K_FUEL -> { fuel = Math.max(0F, fuel - 0.22F); if (fuel >= 100F) finishTask(); }
            case K_BUGS -> {
                for (int i = 0; i < 6; i++) {
                    if (bdead[i]) continue;
                    bx[i] += bvx[i]; by[i] += bvy[i];
                    if (bx[i] < 30 || bx[i] > 190) bvx[i] = -bvx[i];
                    if (by[i] < 42 || by[i] > 120) bvy[i] = -bvy[i];
                    if (ticks % 40 == i && rnd.nextInt(100) < 30) { bvx[i] += (rnd.nextFloat() - 0.5F) * 0.4F; bvy[i] += (rnd.nextFloat() - 0.5F) * 0.4F; }
                }
            }
            case K_SIMON -> {
                if (sqFlT > 0) sqFlT--;
                if (sqShow) {
                    sqT++;
                    if (sqT >= 0 && sqT % 32 == 0) {
                        int st = sqT / 32;
                        if (st >= 4) { sqShow = false; sqIn = 0; }
                        else pling(0.8F + sq[st] * 0.25F);
                    }
                }
            }
            case K_PAIRS -> {
                if (pcWait > 0 && --pcWait == 0) {
                    for (int i = 0; i < 6; i++) if (!pcOk[i]) pcUp[i] = false;
                    pcA = -1;
                }
            }
            case K_CALIB -> { cm += cv; if (cm < 0 || cm > 160) { cv = -cv; cm = Math.max(0, Math.min(160, cm)); } }
            default -> { }
        }
    }

    private void finishTask() {
        tDone = 26;
        pling(1.4F);
    }

    private void closeTask(boolean finished) {
        taskOpen = false;
        if (!finished) return;
        Actor p = act[0];
        if (tFix) completeFix(0);
        else if (tIdx >= 0) {
            p.done[tIdx] = true;
            if (!tFake) { doneTasks++; checkWin(); }
        }
    }

    private boolean taskClick(int x, int y) {
        if (in(x, y, PX + PW - 15, PY + 2, 13, 13)) { closeTask(false); return true; }
        if (tDone > 0) return true;
        switch (tKind) {
            case K_WIRES -> {
                for (int i = 0; i < 3; i++) {
                    if (in(x, y, 20, 46 + i * 26, 18, 14) && wc[i] < 0) { wsel = i; beep(); return true; }
                }
                if (wsel >= 0) {
                    for (int j = 0; j < 3; j++) {
                        if (in(x, y, PX + PW - 28, 46 + j * 26, 18, 14)) {
                            if (wr[j] == wsel) {
                                wc[wsel] = j;
                                pling(1.0F + wsel * 0.2F);
                                if (wc[0] >= 0 && wc[1] >= 0 && wc[2] >= 0) finishTask();
                            } else sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F);
                            wsel = -1;
                            return true;
                        }
                    }
                }
            }
            case K_UPLOAD -> { if (!upOn && in(x, y, 80, 62, 60, 20)) { upOn = true; beep(); } }
            case K_FUEL -> { fuel = Math.min(100F, fuel + 7F); beep(); if (fuel >= 100F) finishTask(); }
            case K_KEYPAD -> {
                for (int i = 0; i < 5; i++) {
                    if (in(x, y, kx[i] - 12, ky[i] - 10, 24, 20)) {
                        if (i == knext) { knext++; pling(1.0F + i * 0.15F); if (knext >= 5) finishTask(); }
                        else { knext = 0; sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F); }
                        return true;
                    }
                }
            }
            case K_BUGS -> {
                boolean all = true;
                for (int i = 0; i < 6; i++) {
                    if (!bdead[i] && dist(x, y, bx[i], by[i]) < 8) { bdead[i] = true; sound(SoundEvents.SLIME_SQUISH, 1.4F, 0.5F); }
                    if (!bdead[i]) all = false;
                }
                if (all) finishTask();
            }
            case K_SIMON -> {
                if (sqShow) return true;
                for (int i = 0; i < 4; i++) {
                    if (in(x, y, 60 + (i % 2) * 52, 40 + (i / 2) * 38, 48, 30)) {
                        sqFl = i; sqFlT = 8;
                        pling(0.8F + i * 0.25F);
                        if (i == sq[sqIn]) { if (++sqIn >= 4) finishTask(); }
                        else { sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F); sqShow = true; sqT = -24; sqIn = 0; }
                        return true;
                    }
                }
            }
            case K_SWITCH -> {
                for (int i = 0; i < 6; i++) {
                    if (in(x, y, 28 + i * 28, 62, 20, 38)) {
                        swS[i] = !swS[i]; beep();
                        boolean all = true;
                        for (int k = 0; k < 6; k++) if (swS[k] != swT[k]) all = false;
                        if (all) finishTask();
                        return true;
                    }
                }
            }
            case K_SORT -> {
                for (int i = 0; i < 3; i++) {
                    if (in(x, y, 30 + i * 56, 94, 48, 24)) {
                        if (i == sortC) { sortN++; pling(1.0F + sortN * 0.1F); sortC = rnd.nextInt(3); if (sortN >= 6) finishTask(); }
                        else { sortN = Math.max(0, sortN - 1); sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F); }
                        return true;
                    }
                }
            }
            case K_PAIRS -> {
                if (pcWait > 0) return true;
                for (int i = 0; i < 6; i++) {
                    if (!pcUp[i] && in(x, y, 50 + (i % 3) * 42, 42 + (i / 3) * 40, 36, 34)) {
                        pcUp[i] = true; beep();
                        if (pcA < 0) pcA = i;
                        else if (pcV[pcA] == pcV[i]) {
                            pcOk[pcA] = true; pcOk[i] = true; pcA = -1; pling(1.3F);
                            if (++pcDone >= 3) finishTask();
                        } else pcWait = 30;
                        return true;
                    }
                }
            }
            default -> {
                if (cm >= cz && cm <= cz + 26) {
                    chit++;
                    pling(1.0F + chit * 0.2F);
                    cz = 10 + rnd.nextInt(120);
                    if (chit >= 3) finishTask();
                } else { chit = Math.max(0, chit - 1); sound(SoundEvents.VILLAGER_NO, 1.4F, 0.4F); }
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ meetings

    private void startMeeting(int by, int body) {
        for (Actor a : act) {
            a.lastRoom = roomAt(a.x, a.y);
            a.vented = false; a.mode = 0; a.bodyT = -1; a.hunt = -1; a.fixKind = -1; a.path = new int[0]; a.pp = 0;
        }
        phase = PH_MEET; mstate = M_INTRO; mt = 0; caller = by; bodyIdx = body;
        taskOpen = false; mapOpen = false; hold = 0;
        sel = -1; pVote = -2; pActs = 0; shown = 0; lineT = 30; ejected = -1; insertAt = -1;
        java.util.Arrays.fill(asked, false);
        java.util.Arrays.fill(pub, 0);
        buildLines();
        for (Body d : bodies) d.reported = true;
        sound(SoundEvents.BELL_BLOCK, 1.0F, 0.8F);
    }

    private void say(int who, String key, int variants, Object... args) {
        Line l = new Line(who, Component.translatable(key + "." + rnd.nextInt(variants), args));
        if (insertAt >= 0) lines.add(Math.min(insertAt++, lines.size()), l);      // the player's talk: the answers come right away
        else lines.add(l);
    }

    private void buildLines() {
        lines.clear();
        contras = 0;
        Body d = bodyIdx >= 0 ? bodies.get(bodyIdx) : null;
        if (d != null) say(caller, "cutemod.hive.m.found", 3, nm(d.victim), rm(d.room));
        else say(caller, "cutemod.hive.m.button", 3);
        if (caller > 0 && act[caller].alive) {                    // whoever called the meeting says why first
            Actor c = act[caller];
            if (c.imp || c.witness >= 0 || c.ventSaw >= 0 || (d != null && suspectFor(c, d) >= 0)) statement(c, d);
        }
        List<Actor> order = new ArrayList<>();
        for (Actor a : act) if (a.alive && a.id != 0 && a.id != caller) order.add(a);
        java.util.Collections.shuffle(order, new java.util.Random(rnd.nextLong()));
        int cnt = 0;
        for (Actor b : order) {
            if (cnt >= 6) break;
            statement(b, d);
            cnt++;
        }
        debate();
    }

    /** One bot says what it knows. Crew tells the truth, an impostor lies (and picks a victim of the lie that nobody can easily clear). */
    private void statement(Actor b, Body d) {
        if (!b.imp) {
            if (b.witness >= 0 && b.witnessV >= 0) {
                say(b.id, "cutemod.hive.m.kill", 3, nm(b.witness), nm(b.witnessV));
                accuse(b.id, b.witness, 150);
                return;
            }
            if (b.ventSaw >= 0) {
                say(b.id, "cutemod.hive.m.vent", 3, nm(b.ventSaw));
                accuse(b.id, b.ventSaw, 150);
                return;
            }
            int s = d != null ? suspectFor(b, d) : -1;
            if (s >= 0) {
                int sc = scoreOut;
                say(b.id, "cutemod.hive.m.near", 3, nm(s), rm(d.room));
                b.susp[s] += sc >= 100 ? 90 : 60;                  // it saw this one itself
                accuse(b.id, s, sc >= 100 ? 60 : 40);
                contradict(b, s, d);
                return;
            }
            int o = companion(b);
            if (o >= 0) {
                say(b.id, "cutemod.hive.m.alibi", 3, nm(o), rm(b.seenRoom[o]));
                b.susp[o] = Math.max(0, b.susp[o] - 40);
                return;
            }
            say(b.id, "cutemod.hive.m.nothing", 3, rm(b.lastRoom));
            return;
        }
        int s = scapegoat(b);
        if (s >= 0 && rnd.nextInt(100) < 65) {
            say(b.id, "cutemod.hive.m.near", 3, nm(s), rm(d != null ? d.room : rnd.nextInt(7)));
            accuse(b.id, s, 40);
            contradict(b, s, d);
        } else say(b.id, "cutemod.hive.m.nothing", 3, rm(rnd.nextInt(7)));
    }

    /** Who this bot saw near the victim: in the room of the body shortly before the death, and above all together with the victim. */
    private int suspectFor(Actor b, Body d) {
        int best = -1, bs = 0;
        for (Actor o : act) {
            if (o.id == b.id || o.id == d.victim) continue;
            int sc = 0, t = b.seenTick[o.id], w = b.with[d.victim][o.id];
            if (t >= d.tick - 1200 && t <= d.tick + 300 && b.seenRoom[o.id] == d.room) sc += 40;
            if (w >= d.tick - 1500 && w <= d.tick + 10) sc += 60;
            if (b.together[o.id] >= 900) sc -= 80;                 // it spent a long time with this one: cleared
            if (sc > bs) { bs = sc; best = o.id; }
        }
        scoreOut = bs;
        return bs >= 40 ? best : -1;
    }

    /** Somebody who saw the accused far from the body at that time says so, and the liar (or the mistaken one) loses credit. */
    private void contradict(Actor a, int x, Body d) {
        if (d == null || contras >= 2) return;
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.imp || c.id == a.id || c.id == x) continue;
            int t = c.seenTick[x];
            if (t >= d.tick - 600 && t <= d.tick + 60 && c.seenRoom[x] != d.room) {
                say(c.id, "cutemod.hive.m.contra", 3, nm(x), rm(c.seenRoom[x]), nm(a.id));
                contras++;
                for (int k = 1; k < N; k++) {
                    Actor o = act[k];
                    if (!o.alive || o.id == a.id) continue;
                    o.susp[a.id] += 30;
                    o.susp[x] = Math.max(0, o.susp[x] - 30);
                }
                pub[a.id]++;
                return;
            }
        }
    }

    /** The one who was accused most defends itself; a friend vouches for it, or an impostor's partner backs the lie up. */
    private void debate() {
        int tgt = -1, bv = 1;
        for (int i = 1; i < N; i++) if (act[i].alive && pub[i] > bv) { bv = pub[i]; tgt = i; }
        if (tgt < 0) return;
        Actor x = act[tgt];
        if (!x.imp) {
            Actor v = null;
            for (int i = 1; i < N; i++) {
                Actor c = act[i];
                if (c.alive && !c.imp && c.id != tgt && c.together[tgt] >= 500) { v = c; break; }
            }
            if (v != null) {
                say(v.id, "cutemod.hive.m.vouch", 3, nm(tgt), rm(v.seenRoom[tgt]));
                for (int i = 1; i < N; i++) act[i].susp[tgt] = Math.max(0, act[i].susp[tgt] - 40);
                pub[tgt] = Math.max(0, pub[tgt] - 1);
            } else say(tgt, "cutemod.hive.m.defend", 3, rm(x.lastRoom));
        } else {
            int s = scapegoat(x);
            say(tgt, "cutemod.hive.m.point", 3, nm(s >= 0 ? s : 0));
            if (s >= 0) accuse(tgt, s, 20);
            for (int i = 1; i < N; i++) {
                Actor q = act[i];
                if (q.alive && q.imp && q.id != tgt) { say(q.id, "cutemod.hive.m.alibi", 3, nm(tgt), rm(rnd.nextInt(7))); break; }
            }
        }
    }

    private int companion(Actor b) {
        int best = -1, bt = 299;
        for (Actor o : act) {
            if (o.id == b.id || !o.alive) continue;
            if (b.together[o.id] > bt) { bt = b.together[o.id]; best = o.id; }
        }
        return best >= 0 ? best : recentOther(b);
    }

    private int recentOther(Actor b) {
        int best = -1, bt = ticks - 1800;
        for (Actor o : act) {
            if (o.id == b.id || !o.alive) continue;
            if (b.seenTick[o.id] > bt) { bt = b.seenTick[o.id]; best = o.id; }
        }
        return best;
    }

    /** An impostor accuses someone who has no alibi: the less the crew has seen a pet lately, the better the target. */
    private int scapegoat(Actor b) {
        int best = -1;
        float bw = -1F;
        for (Actor o : act) {
            if (o.imp || !o.alive || o.id == b.id) continue;
            int last = -99999;
            for (Actor c : act) if (!c.imp && c.alive && c.id != o.id) last = Math.max(last, c.seenTick[o.id]);
            float w = (1F + Math.min(5F, (ticks - last) / 600F)) * (0.6F + rnd.nextFloat());
            if (o.id == 0) w *= 1.3F;
            if (w > bw) { bw = w; best = o.id; }
        }
        return best;
    }

    /** A public accusation: the other bots weigh it (less if they know the accused was elsewhere, nothing if they were with the accused for a long time). */
    private void accuse(int speaker, int target, int weight) {
        pub[target]++;
        Body d = bodyIdx >= 0 ? bodies.get(bodyIdx) : null;
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.id == speaker || c.id == target) continue;
            if (weight < 100 && c.together[target] >= 900) continue;
            int w = weight;
            if (d != null && weight < 100) {
                int t = c.seenTick[target];
                if (t > d.tick - 600 && t < d.tick + 600 && c.seenRoom[target] != d.room) w /= 4;
            }
            c.susp[target] += weight >= 100 ? w : w / 2;           // what others say counts less than what you saw
        }
    }

    private void playerAccuse(int t) {
        Actor ta = act[t];
        if (!ta.alive || t == 0) return;
        pActs++;
        insertAt = shown;
        say(0, "cutemod.hive.m.accuse", 3, nm(t));
        if (ta.imp) {
            int s = scapegoat(ta);
            say(t, "cutemod.hive.m.point", 3, nm(s >= 0 ? s : 0));
            if (s >= 0) accuse(t, s, 20);
        } else say(t, "cutemod.hive.m.defend", 3, rm(ta.lastRoom));
        boolean disagreed = false;
        for (int i = 1; i < N && !disagreed; i++) {                // a friend of the accused speaks up
            Actor c = act[i];
            if (c.alive && !c.imp && c.id != t && c.together[t] >= 500) {
                say(c.id, "cutemod.hive.m.disagree", 3, nm(t), rm(c.seenRoom[t]));
                c.susp[t] = Math.max(0, c.susp[t] - 20);
                disagreed = true;
            }
        }
        int n = 0;
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.id == t) continue;
            if (n < 2 && (c.susp[t] >= 25 || rnd.nextInt(100) < 25)) {
                say(c.id, "cutemod.hive.m.agree", 3, nm(t));
                c.susp[t] += 30;
                n++;
            } else c.susp[t] += 8;
        }
        afterPlayerLine();
    }

    /** The player asks one pet what it saw; it answers with what it knows (an impostor lies). */
    private void playerAsk(int t) {
        Actor ta = act[t];
        if (!ta.alive || t == 0) return;
        pActs++;
        insertAt = shown;
        say(0, "cutemod.hive.m.ask", 3, nm(t));
        if (asked[t]) say(t, "cutemod.hive.m.already", 3);
        else {
            asked[t] = true;
            statement(ta, bodyIdx >= 0 ? bodies.get(bodyIdx) : null);
        }
        afterPlayerLine();
    }

    private void playerAlibi() {
        Actor p = act[0];
        pActs++;
        insertAt = shown;
        int room = p.lastRoom;
        if (playerImp) { room = rnd.nextInt(7); if (room == p.lastRoom) room = (room + 1) % 7; }     // an impostor lies
        say(0, "cutemod.hive.m.mine", 3, rm(room));
        boolean said = false, confirmed = false;
        for (int i = 1; i < N; i++) {
            Actor c = act[i];
            if (!c.alive || c.seenTick[0] < ticks - 600) continue;
            if (c.seenRoom[0] == room) {
                c.susp[0] = Math.max(0, c.susp[0] - 25);
                if (!confirmed) { confirmed = true; say(c.id, "cutemod.hive.m.confirm", 3, nm(0), rm(room)); }
            } else {
                c.susp[0] += 30;
                if (!said) { said = true; say(c.id, "cutemod.hive.m.liar", 3, rm(c.seenRoom[0])); }
            }
        }
        if (!said && !confirmed) {                                  // nobody saw the player: somebody asks for proof
            List<Actor> al = new ArrayList<>();
            for (int i = 1; i < N; i++) if (act[i].alive) al.add(act[i]);
            if (!al.isEmpty()) say(al.get(rnd.nextInt(al.size())).id, "cutemod.hive.m.doubt", 3);
        }
        afterPlayerLine();
    }

    private void afterPlayerLine() { insertAt = -1; lineT = Math.min(lineT, 22); }

    private void toVote() {
        if (mstate != M_TALK) return;
        mstate = M_VOTE; mt = 0; sel = -1;
        decideVotes();
    }

    private void decideVotes() {
        java.util.Arrays.fill(vote, -3);
        for (int i = 1; i < N; i++) {
            Actor b = act[i];
            if (!b.alive) continue;
            int best = -1, bv = 0;
            if (!b.imp) {
                for (Actor o : act) if (o.alive && o.id != b.id && b.susp[o.id] > bv && !(b.together[o.id] >= 900 && b.susp[o.id] < 150)) { bv = b.susp[o.id]; best = o.id; }
                if (bv >= 90) vote[i] = best;
                else vote[i] = rnd.nextInt(100) < 85 ? -1 : randomOther(b, false);
            } else {
                for (Actor o : act) if (o.alive && !o.imp && pub[o.id] > bv) { bv = pub[o.id]; best = o.id; }
                if (best >= 0) vote[i] = best;
                else vote[i] = rnd.nextInt(100) < 50 ? -1 : randomOther(b, true);
            }
        }
    }

    private int randomOther(Actor b, boolean crewOnly) {
        List<Integer> c = new ArrayList<>();
        for (Actor o : act) if (o.alive && o.id != b.id && (!crewOnly || !o.imp)) c.add(o.id);
        return c.isEmpty() ? -1 : c.get(rnd.nextInt(c.size()));
    }

    private void finishVote() {
        vote[0] = act[0].alive ? (pVote == -2 ? -1 : pVote) : -3;
        java.util.Arrays.fill(tally, 0);
        skipCount = 0;
        for (int i = 0; i < N; i++) {
            int v = vote[i];
            if (v == -1) skipCount++;
            else if (v >= 0) tally[v]++;
        }
        mstate = M_SHOW; mt = 0;
        beep();
    }

    private void computeEject() {
        int best = -1, bv = 0, ties = 0;
        for (int i = 0; i < N; i++) {
            if (tally[i] > bv) { bv = tally[i]; best = i; ties = 1; }
            else if (tally[i] == bv && bv > 0) ties++;
        }
        if (best >= 0 && ties == 1 && bv > skipCount) {
            ejected = best; ejWasImp = act[best].imp; act[best].alive = false;
        } else ejected = -1;
    }

    private void endMeeting() {
        bodies.clear();
        for (int i = 0; i < N; i++) {
            Actor a = act[i];
            if (!a.alive && i != 0) continue;
            float ang = i * (float) Math.PI / 4F;
            a.x = BX + (float) Math.cos(ang) * 30F;
            a.y = BY + (float) Math.sin(ang) * 30F;
            a.witness = -1; a.witnessV = -1; a.ventSaw = -1; a.mode = 0; a.bodyT = -1;
            if (a.imp) a.killCd = Math.max(a.killCd, 900);
        }
        lightsOut = false; reactorOn = false; sabCd = Math.max(sabCd, 900); hold = 0;
        phase = PH_PLAY;
        checkWin();
    }

    private void meetTick() {
        mt++;
        switch (mstate) {
            case M_INTRO -> { if (mt > 100) { mstate = M_TALK; mt = 0; } }
            case M_TALK -> {
                if (shown < lines.size() && --lineT <= 0) { shown++; lineT = 85; beep(); }
                boolean ghost = !act[0].alive;
                if ((ghost && shown >= lines.size() && mt > 60) || mt > 2600) toVote();
            }
            case M_VOTE -> {
                if (!act[0].alive && mt > 90) finishVote();
                else if (mt > 1500) { pVote = -1; finishVote(); }
            }
            case M_SHOW -> { if (mt > 190) { computeEject(); mstate = M_EJECT; mt = 0; sound(SoundEvents.ENDERMAN_TELEPORT, 0.6F, 0.7F); } }
            default -> { if (mt > 240) endMeeting(); }
        }
    }

    private boolean meetClick(int x, int y) {
        Actor p = act[0];
        if (mstate == M_TALK || mstate == M_VOTE) {
            for (int i = 0; i < N; i++) {
                if (in(x, y, 4 + (i % 4) * 54, 12 + (i / 4) * 32, 50, 30)) {
                    if (act[i].alive && i != 0 && p.alive) { sel = i; beep(); }
                    return true;
                }
            }
        }
        if (!p.alive) return true;
        if (mstate == M_TALK) {
            if (in(x, y, 4, 124, 51, 13) && sel >= 0 && pActs < 4) playerAccuse(sel);
            else if (in(x, y, 57, 124, 51, 13) && sel >= 0 && pActs < 4) playerAsk(sel);
            else if (in(x, y, 110, 124, 51, 13) && pActs < 4) playerAlibi();
            else if (in(x, y, 163, 124, 53, 13)) toVote();
        } else if (mstate == M_VOTE) {
            if (in(x, y, 4, 124, 106, 13) && sel >= 0) { pVote = sel; finishVote(); }
            else if (in(x, y, 114, 124, 102, 13)) { pVote = -1; finishVote(); }
        }
        return true;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (phase == PH_ROLE) { phaseT = 0; return true; }
        if (phase == PH_MEET) return meetClick(x, y);
        if (phase != PH_PLAY) return true;
        if (mapOpen) { mapOpen = false; return true; }
        if (taskOpen) return taskClick(x, y);
        int[] acts = playerImp ? IMP_ACTS : CREW_ACTS;
        if (y >= H - 14 && y < H - 2 && x >= 4) {
            int i = (x - 4) / 36;
            if (i < acts.length && (x - 4) % 36 < 34) doAction(acts[i]);
        }
        return true;
    }

    // ------------------------------------------------------------------ drawing: sprites

    private static void bean(GuiGraphics g, int cx, int cy, int pt, int face, boolean ghost, int step) {
        int c = COLORS[pt], d = Gfx.darker(c, 0.28F), ol = Gfx.darker(c, 0.55F), hi = Gfx.lighter(c, 0.55F);
        int white = 0xFFFFFFFF, dark = 0xFF1A1428, cheek = 0xFFF28BA8;
        if (ghost) {
            c = (c & 0xFFFFFF) | 0x99000000; d = (d & 0xFFFFFF) | 0x99000000; ol = (ol & 0xFFFFFF) | 0x99000000; hi = (hi & 0xFFFFFF) | 0x99000000;
            white = 0x99FFFFFF; dark = 0x99000000; cheek = 0x99F28BA8;
        }
        // ears and other things behind the head
        switch (pt) {
            case 0 -> { rect(g, cx - 5, cy - 9, 3, 4, ol); rect(g, cx + 2, cy - 9, 3, 4, ol); rect(g, cx - 4, cy - 8, 2, 3, d); rect(g, cx + 2, cy - 8, 2, 3, d); }
            case 1 -> { disc(g, cx - 2, cy - 6, 3, ol); disc(g, cx + 2, cy - 6, 3, ol); disc(g, cx - 2, cy - 6, 2, white); disc(g, cx + 2, cy - 6, 2, white); rect(g, cx - 2 + (face > 0 ? 1 : 0), cy - 6, 1, 2, dark); rect(g, cx + 2 + (face > 0 ? 1 : 0), cy - 6, 1, 2, dark); }
            case 2 -> { disc(g, cx - 3, cy - 7, 3, dark); disc(g, cx + 3, cy - 7, 3, dark); }
            case 3 -> { disc(g, cx - 4, cy - 6, 4, ol); disc(g, cx + 4, cy - 6, 4, ol); disc(g, cx - 4, cy - 6, 3, c); disc(g, cx + 4, cy - 6, 3, c); disc(g, cx - 4, cy - 6, 1, 0xFFF4A7C3); disc(g, cx + 4, cy - 6, 1, 0xFFF4A7C3); }
            case 4 -> { rect(g, cx - 5, cy - 11, 3, 5, ol); rect(g, cx + 2, cy - 11, 3, 5, ol); rect(g, cx - 4, cy - 10, 2, 5, c); rect(g, cx + 2, cy - 10, 2, 5, c); rect(g, cx - 4, cy - 10, 2, 2, white); rect(g, cx + 2, cy - 10, 2, 2, white); }
            case 5 -> { disc(g, cx - 5, cy - 5, 4, ol); disc(g, cx + 5, cy - 5, 4, ol); disc(g, cx - 5, cy - 5, 3, 0xFFD8D0E8); disc(g, cx + 5, cy - 5, 3, 0xFFD8D0E8); disc(g, cx - 5, cy - 5, 1, 0xFF8A7AA8); disc(g, cx + 5, cy - 5, 1, 0xFF8A7AA8); }
            case 6 -> { rect(g, cx - 5, cy - 10, 3, 4, ol); rect(g, cx + 2, cy - 10, 3, 4, ol); rect(g, cx - 4, cy - 9, 2, 3, c); rect(g, cx + 2, cy - 9, 2, 3, c); rect(g, cx - 4, cy - 8, 1, 1, cheek); rect(g, cx + 3, cy - 8, 1, 1, cheek); }
            default -> { disc(g, cx - 4, cy - 7, 3, ol); disc(g, cx + 4, cy - 7, 3, ol); disc(g, cx - 4, cy - 7, 2, d); disc(g, cx + 4, cy - 7, 2, d); }
        }
        // the outline, then the body
        rect(g, cx - 5, cy - 6, 10, 10, ol);
        rect(g, cx - 4, cy - 7, 8, 1, ol);
        rect(g, cx - 3, cy - 7, 6, 1, c);
        rect(g, cx - 4, cy - 6, 8, 10, c);
        rect(g, cx + 2, cy - 6, 2, 10, d);                // the shaded side
        rect(g, cx - 3, cy - 6, 2, 1, hi);                // a shine on the head
        rect(g, cx - 4, cy - 5, 1, 2, hi);
        if (ghost) rect(g, cx - 4, cy + 4, 8, 2, c);
        else {                                            // the feet take turns when it walks
            rect(g, cx - 4, cy + 4, 3, step == 0 ? 2 : 1, d);
            rect(g, cx + 1, cy + 4, 3, step == 0 ? 1 : 2, d);
        }
        if (pt == 2) { rect(g, cx - 4, cy - 5, 4, 4, dark); rect(g, cx, cy - 5, 4, 4, dark); }   // the panda's eye patches
        if (pt != 1) {
            int ex = cx - 3 + (face > 0 ? 1 : 0), pxo = face > 0 ? 1 : 0;
            rect(g, ex, cy - 4, 2, 3, white); rect(g, ex + 3, cy - 4, 2, 3, white);
            rect(g, ex + pxo, cy - 3, 1, 2, dark); rect(g, ex + 3 + pxo, cy - 3, 1, 2, dark);
            if (pt != 2) { rect(g, cx - 4, cy, 1, 1, cheek); rect(g, cx + 3, cy, 1, 1, cheek); }
        } else {
            rect(g, cx - 2, cy - 2, 4, 1, dark);
        }
    }

    private static void corpse(GuiGraphics g, int cx, int cy, int pt) {
        int c = COLORS[pt], d = Gfx.darker(c, 0.3F);
        rect(g, cx - 4, cy - 3, 8, 1, c);
        rect(g, cx - 5, cy - 2, 10, 4, c);
        rect(g, cx - 4, cy + 2, 8, 1, d);
        rect(g, cx + 3, cy - 2, 2, 4, d);
        rect(g, cx - 1, cy - 6, 2, 3, 0xFFF4F0E8);
        rect(g, cx - 3, cy - 1, 1, 1, 0xFF1A1428); rect(g, cx - 1, cy - 1, 1, 1, 0xFF1A1428);
        rect(g, cx - 2, cy, 1, 1, 0xFF1A1428);
    }

    private void bigBean(GuiGraphics g, int x, int y, int pt, float scale, boolean ghost) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1F);
        bean(g, 0, 0, pt, 1, ghost, 0);
        g.pose().popPose();
    }

    // ------------------------------------------------------------------ drawing: the world

    @Override
    public void render(GuiGraphics g) {
        if (phase == PH_MEET) { renderMeeting(g); return; }
        renderWorld(g);
        if (phase == PH_PLAY) {
            renderHud(g);
            if (taskOpen) renderTask(g);
            if (mapOpen) renderMap(g);
        }
        if (phase == PH_ROLE) renderRole(g);
        if (phase == PH_END) renderEnd(g);
    }

    private final float[][] lit = new float[MH][MW];
    private final float[][] cl = new float[MH + 2][MW + 2];
    private final float[][] soft = new float[MH][MW];

    private static void fillC(GuiGraphics g, int x0, int y0, int x1, int y1, int col) {
        x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(W, x1); y1 = Math.min(H, y1);
        if (x1 > x0 && y1 > y0) g.fill(x0, y0, x1, y1, col);
    }

    private static float smooth(float t) {
        t = Math.max(0F, Math.min(1F, t));
        return t * t * (3F - 2F * t);
    }

    private void renderWorld(GuiGraphics g) {
        Actor p = act[0];
        g.fill(0, 0, W, H, 0xFF0A0818);
        float camx = Math.max(0, Math.min(MW * T - W, p.x - W / 2F)), camy = Math.max(0, Math.min(MH * T - H, p.y - H / 2F));
        int ox = -(int) camx, oy = -(int) camy;
        boolean full = !p.alive;
        float rad = vision();
        boolean open = full || p.imp || !lightsOut;
        viewOpen = open; viewRad = rad;
        int tx0 = Math.max(0, (int) (camx / T)), ty0 = Math.max(0, (int) (camy / T));
        int tx1 = Math.min(MW - 1, tx0 + W / T + 1), ty1 = Math.min(MH - 1, ty0 + H / T + 1);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                float cx = tx * T + T / 2F, cy = ty * T + T / 2F;
                float d = dist(p.x, p.y, cx, cy);
                boolean v = open || (d < rad && los(p.x, p.y, cx, cy));      // with the lights on the whole floor is drawn, no black fog
                vis[ty][tx] = v;
                lit[ty][tx] = v ? (open ? 1F : 1F - smooth((d / rad - 0.42F) / 0.58F)) : 0F;
                if (v) drawTile(g, tx, ty, tx * T + ox, ty * T + oy);
            }
        }
        for (int i = 0; i < BLOCKS.length; i++) {                  // a big thing is lit as a whole, whichever of its tiles the light reaches
            int[] r = BLOCKS[i];
            boolean any = false;
            float m = 0F;
            for (int k = 0; k < 4; k++) {
                int bxx = r[0] + (k & 1), byy = r[1] + (k >> 1);
                any |= vis[byy][bxx];
                m = Math.max(m, lit[byy][bxx]);
            }
            if (!any) continue;
            for (int k = 0; k < 4; k++) {
                int bxx = r[0] + (k & 1), byy = r[1] + (k >> 1);
                if (!vis[byy][bxx]) drawTile(g, bxx, byy, bxx * T + ox, byy * T + oy);
                vis[byy][bxx] = true;
                lit[byy][bxx] = m;
            }
            drawBlock(g, i, ox, oy);
        }
        for (int i = 0; i < VX.length; i++) {
            if (!visPx(VX[i] * T + 4, VY[i] * T + 4)) continue;
            int sx = VX[i] * T + ox, sy = VY[i] * T + oy;
            rect(g, sx, sy + 1, 8, 7, 0xFF6A6498);
            rect(g, sx + 1, sy + 2, 6, 5, 0xFF1E1A3A);
            rect(g, sx + 1, sy + 3, 6, 1, 0xFF6A6498);
            rect(g, sx + 1, sy + 5, 6, 1, 0xFF6A6498);
        }
        boolean pulse = (ticks / 15) % 2 == 0;
        if (lightsOut) marker(g, LX, LY, ox, oy, 0xFFFFB347, pulse);
        if (reactorOn) for (int i = 0; i < 2; i++) if (!consoleOk[i]) marker(g, CX[i], CY[i], ox, oy, 0xFFE0594F, pulse);
        for (int i = 0; i < PER; i++) {
            if (p.done[i]) continue;
            int s = p.spot[i];
            marker(g, TX[s], TY[s], ox, oy, 0xFFFFE066, true);
        }
        for (Body d : bodies) {
            if (!entVis(d.x, d.y)) continue;
            Gfx.ellipse(g, (int) d.x + ox, (int) d.y + oy + 3, 7, 2, 0x44000000);
            corpse(g, (int) d.x + ox, (int) d.y + oy, pet[d.victim]);
        }
        Actor kt = killTarget();
        for (int n = 1; n <= N; n++) {
            Actor a = act[n % N];
            if (a.vented) continue;
            if (!a.alive && !full) continue;                       // only a ghost sees the ghosts
            if (a.alive && a.id != 0 && !entVis(a.x, a.y)) continue;
            int sx = (int) a.x + ox, sy = (int) a.y + oy;
            if (sx < -12 || sx > W + 12 || sy < -14 || sy > H + 14) continue;
            if (a.alive) Gfx.ellipse(g, sx, sy + 6, 5, 2, 0x55000000);
            bean(g, sx, a.alive ? sy : sy - 2, pet[a.id], a.face, !a.alive, (((int) (a.x + a.y)) / 4) & 1);
            if (a == kt) Gfx.outline(g, sx - 6, sy - 9, 12, 16, 0xFFFF4040);
            if (a.id == 0) { rect(g, sx - 1, sy - 14, 3, 1, 0xFFFFE066); rect(g, sx, sy - 13, 1, 1, 0xFFFFE066); }
            else if (playerImp && a.imp && a.alive) rect(g, sx - 1, sy - 13, 3, 2, 0xFFFF4040);
        }
        if (full) fillC(g, 0, 0, W, H, 0x1830508C);
        else if (!open) {                                    // only when the lights are out: the dark and a small glow
            Gfx.glow(g, (int) p.x + ox, (int) p.y + oy, Math.min(34, (int) (rad * 0.5F)), 0xFFFFE4B0, 26);
            shade(g, ox, oy, tx0, ty0, tx1, ty1);
        }
        if (reactorOn && pulse) g.fill(0, 0, W, H, 0x22FF2020);
        if (killFlash > 0) g.fill(0, 0, W, H, (Math.min(110, killFlash * 3) << 24) | 0xC02020);
    }

    private float softAt(int tx, int ty, int tx0, int ty0, int tx1, int ty1) {
        return soft[clampi(ty, ty0, ty1)][clampi(tx, tx0, tx1)];
    }

    private float litAt(int tx, int ty, int tx0, int ty0, int tx1, int ty1) {
        return lit[clampi(ty, ty0, ty1)][clampi(tx, tx0, tx1)];
    }

    /** The darkness: the light of every tile corner is the average of the four tiles around it, and the picture is darkened in 2x2 pixel steps by the smooth mix of the four corners. */
    private void shade(GuiGraphics g, int ox, int oy, int tx0, int ty0, int tx1, int ty1) {
        for (int j = ty0; j <= ty1; j++)
            for (int i = tx0; i <= tx1; i++)
                soft[j][i] = litAt(i, j, tx0, ty0, tx1, ty1) * 0.5F + (litAt(i - 1, j, tx0, ty0, tx1, ty1) + litAt(i + 1, j, tx0, ty0, tx1, ty1)
                        + litAt(i, j - 1, tx0, ty0, tx1, ty1) + litAt(i, j + 1, tx0, ty0, tx1, ty1)) * 0.125F;
        for (int j = ty0; j <= ty1 + 1; j++)
            for (int i = tx0; i <= tx1 + 1; i++)
                cl[j][i] = (softAt(i - 1, j - 1, tx0, ty0, tx1, ty1) + softAt(i, j - 1, tx0, ty0, tx1, ty1)
                        + softAt(i - 1, j, tx0, ty0, tx1, ty1) + softAt(i, j, tx0, ty0, tx1, ty1)) / 4F;
        final int cell = 2, per = T / cell;
        int endX = (tx1 + 1) * T + ox;
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int sub = 0; sub < per; sub++) {
                int y = ty * T + sub * cell + oy;
                if (y + cell <= 0 || y >= H) continue;
                float fy = (sub + 0.5F) / per;
                int level = -1, start = 0;
                for (int tx = tx0; tx <= tx1; tx++) {
                    float a00 = cl[ty][tx], a10 = cl[ty][tx + 1], a01 = cl[ty + 1][tx], a11 = cl[ty + 1][tx + 1];
                    for (int sx = 0; sx < per; sx++) {
                        float fx = (sx + 0.5F) / per;
                        float top = a00 + (a10 - a00) * fx, bot = a01 + (a11 - a01) * fx;
                        int lv = (int) ((1F - (top + (bot - top) * fy)) * 15.99F);
                        int x = tx * T + sx * cell + ox;
                        if (lv != level) {
                            if (level > 0) fillC(g, start, y, x, y + cell, ((level * 17) << 24) | 0x0A0818);
                            start = x; level = lv;
                        }
                    }
                }
                if (level > 0) fillC(g, start, y, endX, y + cell, ((level * 17) << 24) | 0x0A0818);
            }
        }
    }

    private void drawTile(GuiGraphics g, int tx, int ty, int px, int py) {
        if (solid[ty][tx] && !blk[ty][tx]) {
            boolean front = ty + 1 < MH && !solid[ty + 1][tx];
            if (front) {                                          // the wall seen from the front: panels, a skirting board, now and then a window
                fillC(g, px, py, px + T, py + T, WALL_FRONT);
                fillC(g, px, py, px + T, py + 1, 0xFF9A8CE6);
                fillC(g, px, py + T - 2, px + T, py + T, 0xFF3A3170);
                fillC(g, px + T - 1, py + 1, px + T, py + T - 2, 0xFF5A4EA4);
                if (Gfx.hash(tx, ty * 3 + 1) < 0.22F) {
                    fillC(g, px + 1, py + 1, px + 7, py + 6, 0xFF2A2A60);
                    fillC(g, px + 2, py + 2, px + 6, py + 5, 0xFFB8F0FF);
                    fillC(g, px + 2, py + 2, px + 4, py + 3, 0xFFFFFFFF);
                }
            } else {
                boolean edge = false;                              // only the wall next to a floor is drawn, the rest stays dark space
                for (int dy = -1; dy <= 1 && !edge; dy++)
                    for (int dx = -1; dx <= 1; dx++) if (!solidTile(tx + dx, ty + dy)) { edge = true; break; }
                if (!edge) return;
                fillC(g, px, py, px + T, py + T, WALL_TOP);
                fillC(g, px, py, px + T, py + 1, 0xFF4A3F86);
            }
            return;
        }
        int room = roomTile(tx, ty);
        int c = ((tx + ty) & 1) == 0 ? ROOM_A[room] : ROOM_B[room];
        if (room == 0) {                                          // a round rug under the table
            float ex = (tx * T + 4 - BX) / 56F, ey = (ty * T + 4 - BY) / 44F, q = ex * ex + ey * ey;
            if (q < 0.32F) c = ((tx + ty) & 1) == 0 ? 0xFFE9A3BC : 0xFFE19AB4;
            else if (q < 1F) c = ((tx + ty) & 1) == 0 ? 0xFFD4849F : 0xFFCC7C98;
        }
        fillC(g, px, py, px + T, py + T, c);
        fillC(g, px, py + T - 1, px + T, py + T, 0x14000000);
        fillC(g, px + T - 1, py, px + T, py + T, 0x14000000);
        if (ty > 0 && solid[ty - 1][tx] && !blk[ty - 1][tx]) {    // the shadow of the wall
            fillC(g, px, py, px + T, py + 3, 0x40000000);
            fillC(g, px, py + 3, px + T, py + 5, 0x20000000);
        }
        float h = Gfx.hash(tx * 7 + 3, ty * 13 + 5);
        switch (room) {
            case 6 -> {
                if (h < 0.14F) {
                    fillC(g, px + 2, py + 4, px + 3, py + 7, 0xFF5FA84A); fillC(g, px + 4, py + 3, px + 5, py + 7, 0xFF4E9A3C); fillC(g, px + 6, py + 5, px + 7, py + 7, 0xFF5FA84A);
                } else if (h < 0.2F) {
                    fillC(g, px + 3, py + 3, px + 5, py + 5, h < 0.17F ? 0xFFFFFFFF : 0xFFF58FB8);
                    fillC(g, px + 4, py + 4, px + 5, py + 5, 0xFFF3D46A);
                }
            }
            case 1 -> {
                fillC(g, px + 1, py + 1, px + 2, py + 2, 0xFF6A7488); fillC(g, px + T - 3, py + T - 3, px + T - 2, py + T - 2, 0xFF6A7488);
                if ((tx & 3) == 0) fillC(g, px, py, px + 1, py + T, 0x22000000);
            }
            case 2 -> {
                if ((ty & 3) == 0) {
                    fillC(g, px, py + 3, px + T, py + 4, 0xFF3A4580);
                    if (h < 0.3F) fillC(g, px + 3, py + 2, px + 5, py + 5, 0xFFF3D46A);
                }
            }
            case 3 -> { fillC(g, px, py + 3, px + T, py + 4, 0x22000000); fillC(g, px, py + 7, px + T, py + 8, 0x22000000); }
            case 4 -> {
                fillC(g, px, py, px + T, py + 1, 0x33FFFFFF);
                if (h < 0.08F) fillC(g, px + 3, py + 3, px + 4, py + 4, 0xFFFFFFFF);
            }
            case 5 -> { if (h < 0.2F) fillC(g, px + 2 + (int) (h * 20F) % 4, py + 2 + (int) (h * 40F) % 4, px + 3 + (int) (h * 20F) % 4, py + 3 + (int) (h * 40F) % 4, 0xFFE8F4FF); }
            default -> { }
        }
    }

    /** The big things in the rooms (every one is 2 x 2 tiles). */
    private void drawBlock(GuiGraphics g, int bi, int ox, int oy) {
        int[] r = BLOCKS[bi];
        int x = r[0] * T + ox, y = r[1] * T + oy;
        Gfx.ellipse(g, x + 8, y + 15, 9, 3, 0x44000000);
        switch (bi) {
            case 0 -> {                                           // the round table with the emergency button
                Gfx.ellipse(g, x + 8, y + 9, 9, 7, 0xFFB98A5E);
                Gfx.ellipse(g, x + 8, y + 8, 9, 7, 0xFFF2E3C6);
                Gfx.ellipse(g, x + 8, y + 8, 6, 4, 0xFFE8D2AC);
                disc(g, x + 8, y + 8, 3, 0xFFB03A32); disc(g, x + 8, y + 7, 3, 0xFFE0594F);
                rect(g, x + 7, y + 5, 2, 1, 0xFFFFB0A8);
            }
            case 1 -> {                                           // a glowing engine core
                Gfx.rrect(g, x, y + 3, 16, 12, 3, 0xFF3A4058);
                Gfx.rrect(g, x + 1, y + 3, 14, 10, 3, 0xFF59627E);
                Gfx.glow(g, x + 8, y + 8, 11, 0xFFFFB347, (ticks / 15) % 2 == 0 ? 60 : 44);
                disc(g, x + 8, y + 8, 4, 0xFFFF9A3C); disc(g, x + 8, y + 8, 2, 0xFFFFE9A0);
                rect(g, x + 1, y + 12, 14, 1, 0xFF3A4058);
            }
            case 2 -> {                                           // a fuse box with blinking lights
                Gfx.rrect(g, x + 1, y + 2, 14, 13, 2, 0xFF222C60);
                Gfx.rrect(g, x + 1, y + 2, 14, 11, 2, 0xFF3A47A0);
                for (int i = 0; i < 3; i++) {
                    int on = (ticks / 20 + i) % 3;
                    disc(g, x + 4 + i * 4, y + 5, 1, on == 0 ? 0xFF7ED957 : (on == 1 ? 0xFFF3D46A : 0xFFE0594F));
                }
                rect(g, x + 3, y + 8, 10, 1, 0xFF222C60); rect(g, x + 3, y + 10, 10, 1, 0xFF222C60);
            }
            case 3 -> {                                           // a lab bench with flasks
                Gfx.rrect(g, x, y + 5, 16, 10, 2, 0xFF9ACBC0);
                Gfx.rrect(g, x, y + 4, 16, 9, 2, 0xFFEAF6F2);
                rect(g, x + 4, y + 1, 2, 3, 0xFFD0E8E4); disc(g, x + 5, y + 7, 3, 0xFF7ED957); rect(g, x + 3, y + 6, 1, 1, 0xFFFFFFFF);
                rect(g, x + 10, y + 3, 3, 2, 0xFFD0E8E4); disc(g, x + 11, y + 8, 3, 0xFFF58FB8);
            }
            case 4 -> {                                           // a navigation console with a scanning line
                Gfx.rrect(g, x, y + 2, 16, 13, 2, 0xFF1F2E58);
                rect(g, x + 2, y + 3, 12, 7, 0xFF0E2A44);
                rect(g, x + 2, y + 3 + (ticks / 6) % 7, 12, 1, 0xFF6FE0FF);
                rect(g, x + 4, y + 5, 1, 1, 0xFFFFFFFF); rect(g, x + 10, y + 7, 1, 1, 0xFFFFFFFF); rect(g, x + 7, y + 4, 1, 1, 0xFFFFE066);
                rect(g, x + 3, y + 12, 2, 1, 0xFFE0594F); rect(g, x + 7, y + 12, 2, 1, 0xFF7ED957); rect(g, x + 11, y + 12, 2, 1, 0xFFF3D46A);
            }
            case 5 -> {                                           // a planter with a bush and flowers
                Gfx.rrect(g, x + 1, y + 8, 14, 7, 2, 0xFF6E4524);
                Gfx.rrect(g, x + 1, y + 8, 14, 5, 2, 0xFF8A5A36);
                disc(g, x + 5, y + 6, 4, 0xFF4E9A3C); disc(g, x + 11, y + 5, 4, 0xFF5FB44A); disc(g, x + 8, y + 3, 3, 0xFF7ED957);
                rect(g, x + 4, y + 5, 1, 1, 0xFFF58FB8); rect(g, x + 11, y + 4, 1, 1, 0xFFFFFFFF); rect(g, x + 8, y + 2, 1, 1, 0xFFF3D46A);
            }
            default -> {                                          // crates
                rect(g, x + 1, y + 7, 8, 8, 0xFF8A5A2E); rect(g, x + 2, y + 8, 6, 6, 0xFFC48A52); rect(g, x + 2, y + 8, 6, 1, 0xFFE0AB74);
                rect(g, x + 2, y + 10, 6, 1, 0xFF8A5A2E); rect(g, x + 4, y + 8, 1, 6, 0xFF8A5A2E);
                rect(g, x + 8, y + 3, 7, 12, 0xFF8A5A2E); rect(g, x + 9, y + 4, 5, 10, 0xFFB67A44); rect(g, x + 9, y + 4, 5, 1, 0xFFD39A5E);
                rect(g, x + 9, y + 8, 5, 1, 0xFF8A5A2E); rect(g, x + 11, y + 4, 1, 10, 0xFF8A5A2E);
            }
        }
    }

    private boolean viewOpen;
    private float viewRad;

    /** Pets and bodies are seen through the open space only: walls hide them (the big things in the rooms do not). */
    private boolean entVis(float x, float y) {
        Actor p = act[0];
        if (!p.alive) return true;
        if (!viewOpen) return visPx(x, y);
        return dist(p.x, p.y, x, y) < viewRad && losView(p.x, p.y, x, y);
    }

    private boolean losView(float x0, float y0, float x1, float y1) {
        int tx = (int) (x1 / T), ty = (int) (y1 / T);
        float dx = x1 - x0, dy = y1 - y0;
        int n = (int) (Math.sqrt(dx * dx + dy * dy) / 3F) + 1;
        for (int i = 1; i < n; i++) {
            float f = i / (float) n;
            int cx = (int) ((x0 + dx * f) / T), cy = (int) ((y0 + dy * f) / T);
            if (cx == tx && cy == ty) return true;
            if (solidTile(cx, cy) && !blk[cy][cx]) return false;
        }
        return true;
    }

    private boolean visPx(float x, float y) {
        int tx = (int) (x / T), ty = (int) (y / T);
        return tx >= 0 && ty >= 0 && tx < MW && ty < MH && vis[ty][tx];
    }

    private void marker(GuiGraphics g, int tx, int ty, int ox, int oy, int col, boolean on) {
        if (!visPx(tx * T + 4, ty * T + 4) || !on) return;
        int sx = tx * T + ox + 4, sy = ty * T + oy + 4 - ((ticks / 12) % 2);
        Gfx.ellipse(g, sx, sy + 3, 5, 2, (col & 0xFFFFFF) | 0x66000000);
        Gfx.glow(g, sx, sy - 5, 8, col, 60);
        Gfx.rrect(g, sx - 3, sy - 10, 7, 8, 3, 0xFF3A2A10);
        Gfx.rrect(g, sx - 2, sy - 9, 5, 6, 2, col);
        rect(g, sx, sy - 8, 1, 3, 0xFF3A2A10);
        rect(g, sx, sy - 4, 1, 1, 0xFF3A2A10);
    }

    // ------------------------------------------------------------------ drawing: HUD, tasks, map, splash

    private void renderHud(GuiGraphics g) {
        Actor p = act[0];
        Gfx.bubble(g, 3, 3, 74, 9, 3, 0xCC1A1440);
        int w = totalTasks == 0 ? 0 : 68 * doneTasks / totalTasks;
        if (w > 0) { Gfx.bubble(g, 5, 5, Math.max(3, w), 5, 2, 0xFF7ED957); rect(g, 6, 5, Math.max(1, w - 2), 1, 0x66FFFFFF); }
        Fit.str(g, font(), tr("cutemod.hive.tasks"), 80, 3, 0xFFFFFFFF, true, 140);
        String roleS = tr(playerImp ? "cutemod.hive.role.imp" : "cutemod.hive.role.crew");
        Fit.str(g, font(), roleS, W - 4 - Math.min(tw(roleS), 76), 3, playerImp ? 0xFFFF6A6A : 0xFF7FE0FF, true, W - 2);
        int ti = nextTask(p);
        if (ti >= 0) {
            int s = p.spot[ti];
            Fit.str(g, font(), tr("cutemod.hive.next", tr("cutemod.hive.task." + KIND[s]), rm(roomTile(TX[s], TY[s]))), 5, 13, 0xFFFFE066, true, W - 4);
        }
        boolean flash = (ticks / 15) % 2 == 0;
        if (lightsOut) ctextW(g, tr("cutemod.hive.sab.lights"), W / 2, 25, W - 8, flash ? 0xFFFFB347 : 0xFFFF6A6A);
        if (reactorOn) ctextW(g, tr("cutemod.hive.sab.reactor", (reactorT + 59) / 60), W / 2, 25, W - 8, flash ? 0xFFFF4040 : 0xFFFFB0A8);
        if (hold > 0) {
            rect(g, W / 2 - 30, 38, 60, 6, 0xAA000000);
            rect(g, W / 2 - 29, 39, 58 * hold / 120, 4, 0xFF7ED957);
            ctext(g, tr("cutemod.hive.hold"), W / 2, 46, 0xFFFFFFFF);
        }
        if (p.vented) ctextW(g, tr("cutemod.hive.ventmsg"), W / 2, 25, W - 8, 0xFFFFFFFF);
        else if (!p.alive) ctextW(g, tr(p.imp ? "cutemod.hive.dead.imp" : "cutemod.hive.dead"), W / 2, 25, W - 8, 0xFFB8B0F0);
        Fit.str(g, font(), rm(roomAt(p.x, p.y)), 5, H - 25, 0xFFFFFFFF, true, 100);
        int[] acts = playerImp ? IMP_ACTS : CREW_ACTS;
        for (int i = 0; i < acts.length; i++) {
            int a = acts[i], x = 4 + i * 36, y = H - 14;
            boolean on = actionOn(a);
            boolean hov = on && in(mx, my, x, y, 34, 12);
            Gfx.bubble(g, x, y, 34, 12, 3, !on ? 0xAA2A2550 : (hov ? 0xFF8A78E8 : 0xFF6A58C8));
            String label = tr("cutemod.hive.a." + ACT_KEYS[a]);
            if (a == A_KILL && p.killCd > 0) label = String.valueOf((p.killCd + 59) / 60);
            if ((a == A_DARK || a == A_CORE) && sabCd > 0 && !lightsOut && !reactorOn) label = String.valueOf((sabCd + 59) / 60);
            ctextW(g, label, x + 17, y + 2, 31, on ? 0xFFFFFFFF : 0x88FFFFFF);
        }
    }

    private boolean actionOn(int a) {
        Actor p = act[0];
        switch (a) {
            case A_USE: {
                if (p.vented || (!p.alive && p.imp)) return false;
                if (lightsOut && !p.imp && near(p, LX * T + 4, LY * T + 4, 16)) return true;
                for (int i = 0; i < PER; i++) if (!p.done[i] && near(p, TX[p.spot[i]] * T + 4, TY[p.spot[i]] * T + 4, 14)) return true;
                return p.alive && !buttonUsed && !lightsOut && !reactorOn && near(p, BX, BY, 26);
            }
            case A_REPORT: {
                if (!p.alive || p.vented) return false;
                for (Body d : bodies) if (!d.reported && dist(p.x, p.y, d.x, d.y) < 24 && los(p.x, p.y, d.x, d.y)) return true;
                return false;
            }
            case A_KILL: return p.killCd <= 0 && killTarget() != null;
            case A_VENT: return p.alive && (p.vented || nearVent(p.x, p.y, 14) >= 0);
            case A_DARK:
            case A_CORE: return sabCd <= 0 && !lightsOut && !reactorOn;
            default: return true;
        }
    }

    private void renderTask(GuiGraphics g) {
        g.fill(0, 0, W, H, 0xAA000000);
        Gfx.bubble(g, PX, PY, PW, PH, 6, 0xFF2E2860);
        ctext(g, tr("cutemod.hive.task." + tKind), W / 2, PY + 4, 0xFFFFFFFF);
        ctextW(g, tr("cutemod.hive.t." + tKind), W / 2, PY + 15, PW - 24, 0xFFB8B0F0);
        boolean hx = in(mx, my, PX + PW - 15, PY + 2, 13, 13);
        rect(g, PX + PW - 15, PY + 2, 13, 13, hx ? 0xFFFF7A70 : 0xFFE0594F);
        ctext(g, "x", PX + PW - 8, PY + 4, 0xFFFFFFFF);
        switch (tKind) {
            case K_WIRES -> {
                for (int i = 0; i < 3; i++) {
                    int y = 53 + i * 26;
                    rect(g, 20, y - 7, 18, 14, 0xFF3A3470);
                    rect(g, 24, y - 2, 14, 4, WIRE_COL[i]);
                    if (wsel == i) Gfx.outline(g, 20, y - 7, 18, 14, 0xFFFFFFFF);
                    int ry = 53 + i * 26;
                    rect(g, PX + PW - 28, ry - 7, 18, 14, 0xFF3A3470);
                    rect(g, PX + PW - 28, ry - 2, 14, 4, WIRE_COL[wr[i]]);
                }
                for (int i = 0; i < 3; i++) if (wc[i] >= 0) Gfx.line(g, 38, 53 + i * 26, PX + PW - 28, 53 + wc[i] * 26, WIRE_COL[i]);
                if (wsel >= 0) Gfx.line(g, 38, 53 + wsel * 26, mx, my, WIRE_COL[wsel]);
            }
            case K_UPLOAD -> {
                if (!upOn) {
                    boolean h = in(mx, my, 80, 62, 60, 20);
                    Gfx.bubble(g, 80, 62, 60, 20, 5, h ? 0xFF8A78E8 : 0xFF6A58C8);
                    ctext(g, tr("cutemod.hive.start"), 110, 68, 0xFFFFFFFF);
                }
                rect(g, 40, 96, 140, 12, 0xFF1A1630);
                rect(g, 41, 97, 138 * upT / 300, 10, 0xFF7ED957);
            }
            case K_FUEL -> {
                Gfx.outline(g, 90, 36, 40, 88, 0xFFFFFFFF);
                rect(g, 91, 37, 38, 86, 0xFF1A1630);
                int h = (int) (84 * fuel / 100F);
                rect(g, 92, 122 - h, 36, h, 0xFFF5A04A);
                ctext(g, "SPACE", 160, 76, 0xFFB8B0F0);
            }
            case K_KEYPAD -> {
                for (int i = 0; i < 5; i++) {
                    boolean d = i < knext;
                    boolean h = !d && in(mx, my, kx[i] - 12, ky[i] - 10, 24, 20);
                    Gfx.bubble(g, kx[i] - 12, ky[i] - 10, 24, 20, 4, d ? 0xFF3E8F55 : (h ? 0xFF8A78E8 : 0xFF5A4AA0));
                    ctext(g, String.valueOf(i + 1), kx[i], ky[i] - 4, 0xFFFFFFFF);
                }
            }
            case K_BUGS -> {
                for (int i = 0; i < 6; i++) {
                    if (bdead[i]) continue;
                    int x = (int) bx[i], y = (int) by[i];
                    disc(g, x, y, 4, 0xFFF3D46A);
                    rect(g, x - 1, y - 3, 2, 6, 0xFF3A2A10);
                    rect(g, x - 5, y - 5, 3, 2, 0xAAFFFFFF);
                    rect(g, x + 3, y - 5, 3, 2, 0xAAFFFFFF);
                }
            }
            case K_SIMON -> {
                int[] pc = {0xFFE0594F, 0xFF4A8FE0, 0xFFF3D46A, 0xFF7ED957};
                int lit = sqFlT > 0 ? sqFl : (sqShow && sqT >= 0 && sqT % 32 < 22 && sqT / 32 < 4 ? sq[sqT / 32] : -1);
                for (int i = 0; i < 4; i++) {
                    int x = 60 + (i % 2) * 52, y = 40 + (i / 2) * 38;
                    Gfx.bubble(g, x, y, 48, 30, 5, i == lit ? Gfx.lighter(pc[i], 0.45F) : Gfx.darker(pc[i], 0.45F));
                    if (i == lit) Gfx.outline(g, x, y, 48, 30, 0xFFFFFFFF);
                }
                ctext(g, sqShow ? "..." : sqIn + " / 4", W / 2, 116, 0xFFFFE066);
            }
            case K_SWITCH -> {
                for (int i = 0; i < 6; i++) {
                    int x = 28 + i * 28;
                    disc(g, x + 10, 46, 5, swT[i] ? 0xFFFFE066 : 0xFF1A1630);
                    boolean ok = swS[i] == swT[i];
                    rect(g, x, 62, 20, 38, ok ? 0xFF3E8F55 : 0xFF3A3470);
                    rect(g, x + 4, 64, 12, 34, 0xFF1A1630);
                    rect(g, x + 3, swS[i] ? 66 : 82, 14, 14, 0xFFEAE6FF);
                    rect(g, x + 3, swS[i] ? 66 : 82, 14, 2, 0xFFFFFFFF);
                }
            }
            case K_SORT -> {
                int[] pc = {0xFFE0594F, 0xFF4A8FE0, 0xFFF3D46A};
                for (int i = 0; i < 3; i++) {
                    boolean h = in(mx, my, 30 + i * 56, 94, 48, 24);
                    Gfx.bubble(g, 30 + i * 56, 94, 48, 24, 5, h ? Gfx.lighter(pc[i], 0.2F) : Gfx.darker(pc[i], 0.25F));
                }
                disc(g, W / 2, 62, 11, Gfx.darker(pc[sortC], 0.5F));
                disc(g, W / 2, 61, 10, pc[sortC]);
                rect(g, W / 2 - 4, 56, 3, 2, 0x88FFFFFF);
                ctext(g, sortN + " / 6", W / 2, 124, 0xFFFFE066);
            }
            case K_PAIRS -> {
                int[] pc = {0xFFE0594F, 0xFF4A8FE0, 0xFF7ED957};
                for (int i = 0; i < 6; i++) {
                    int x = 50 + (i % 3) * 42, y = 42 + (i / 3) * 40;
                    boolean up = pcUp[i];
                    Gfx.bubble(g, x, y, 36, 34, 5, up ? 0xFFEAE6FF : (in(mx, my, x, y, 36, 34) ? 0xFF8A78E8 : 0xFF5A4AA0));
                    if (up) {
                        if (pcV[i] == 0) disc(g, x + 18, y + 17, 9, pc[0]);
                        else if (pcV[i] == 1) rect(g, x + 9, y + 8, 18, 18, pc[1]);
                        else { rect(g, x + 15, y + 6, 6, 22, pc[2]); rect(g, x + 7, y + 14, 22, 6, pc[2]); }
                        if (pcOk[i]) Gfx.outline(g, x, y, 36, 34, 0xFF3E8F55);
                    } else ctext(g, "?", x + 18, y + 13, 0xFFFFFFFF);
                }
            }
            default -> {
                rect(g, 30, 70, 160, 14, 0xFF1A1630);
                rect(g, 30 + cz, 70, 26, 14, 0xFF3E8F55);
                rect(g, 30 + (int) cm - 1, 66, 3, 22, 0xFFFFFFFF);
                ctext(g, chit + " / 3", W / 2, 100, 0xFFFFE066);
            }
        }
        if (tDone > 0) ctext(g, "OK!", W / 2, 118, 0xFF7ED957);
    }

    private void renderMap(GuiGraphics g) {
        Actor p = act[0];
        g.fill(0, 0, W, H, 0xDD000000);
        int ox = 14, oy = 10, s = 3;
        for (int ty = 0; ty < MH; ty++) {
            for (int tx = 0; tx < MW; tx++) {
                if (solid[ty][tx] && !blk[ty][tx]) continue;
                int c = blk[ty][tx] ? 0xFFB58A5A : ROOM_A[roomTile(tx, ty)];
                g.fill(ox + tx * s, oy + ty * s, ox + tx * s + s, oy + ty * s + s, Gfx.lighter(c, 0.1F));
            }
        }
        for (int i = 0; i < VX.length; i++) rect(g, ox + VX[i] * s, oy + VY[i] * s, s, s, 0xFF1A1630);
        for (int i = 0; i < PER; i++) if (!p.done[i]) rect(g, ox + TX[p.spot[i]] * s, oy + TY[p.spot[i]] * s, s, s, 0xFFFFE066);
        boolean fl = (ticks / 15) % 2 == 0;
        if (lightsOut && fl) rect(g, ox + LX * s - 1, oy + LY * s - 1, s + 2, s + 2, 0xFFFFB347);
        if (reactorOn && fl) for (int i = 0; i < 2; i++) if (!consoleOk[i]) rect(g, ox + CX[i] * s - 1, oy + CY[i] * s - 1, s + 2, s + 2, 0xFFE0594F);
        if ((ticks / 10) % 2 == 0) disc(g, ox + (int) (p.x / T * s), oy + (int) (p.y / T * s), 2, 0xFFFFFFFF);
        for (int i = 0; i < 7; i++) {
            int[] r = ROOMS[i];
            ctextW(g, rm(i), ox + (r[0] + r[2] / 2) * s, oy + (r[1] + r[3] / 2) * s - 4, r[2] * s, 0xFFFFFFFF);
        }
    }

    private void renderRole(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF1C1546, 0xFF0A0818);
        Gfx.glow(g, W / 2, 80, 90, playerImp ? 0xFFE0594F : 0xFF6FA8F2, 36);
        for (int i = 0; i < 20; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 8) * W), (int) (Gfx.hash(i, 9) * H), 1, i * 13 + phaseT, 0x66FFFFFF);
        int col = playerImp ? 0xFFFF6A6A : 0xFF7FE0FF;
        ctext(g, tr(playerImp ? "cutemod.hive.role.imp" : "cutemod.hive.role.crew"), W / 2, 22, col);
        String partner = "";
        if (playerImp) for (int i = 1; i < N; i++) if (act[i].imp) partner = nm(i);
        ctextW(g, playerImp ? tr("cutemod.hive.role.imp.sub", partner) : tr("cutemod.hive.role.crew.sub"), W / 2, 36, W - 10, 0xFFFFFFFF);
        if (playerImp) {
            bigBean(g, W / 2 - 24, 80, pet[0], 3F, false);
            for (int i = 1; i < N; i++) if (act[i].imp) bigBean(g, W / 2 + 24, 80, pet[i], 3F, false);
        } else {
            for (int i = 0; i < N; i++) bigBean(g, 15 + i * 27, 86, pet[i], 1.6F, false);
        }
        ctext(g, tr("cutemod.hive.go"), W / 2, 122, 0xFFB8B0F0);
    }

    private void renderEnd(GuiGraphics g) {
        g.fill(0, 40, W, 74, 0xCC000000);
        ctext(g, tr(crewWon ? "cutemod.hive.win.crew" : "cutemod.hive.win.imp"), W / 2, 52, crewWon ? 0xFF7FE0FF : 0xFFFF6A6A);
        ctextW(g, tr(won ? "cutemod.hive.you.win" : "cutemod.hive.you.lose"), W / 2, 68, W - 10, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------------ drawing: the meeting

    private void renderMeeting(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF2A1F5C, 0xFF140F30);
        Gfx.glow(g, 40, 30, 70, 0xFF8A78E8, 40); Gfx.glow(g, 190, 120, 80, 0xFFF58FB8, 26);
        for (int i = 0; i < 14; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 5) * W), (int) (Gfx.hash(i, 6) * H), 1, i * 17 + mt, 0x55FFFFFF);
        if (mstate == M_INTRO) { renderIntro(g); return; }
        if (mstate == M_EJECT) { renderEject(g); return; }
        ctext(g, tr(mstate == M_TALK ? "cutemod.hive.discuss" : "cutemod.hive.vote"), W / 2, 1, 0xFFFFFFFF);
        for (int i = 0; i < N; i++) card(g, i);
        renderChat(g);
        Actor p = act[0];
        if (!p.alive) { ctext(g, tr("cutemod.hive.ghostwatch"), W / 2, 126, 0xFFB8B0F0); return; }
        if (mstate == M_TALK) {
            btn(g, 4, 124, 51, 13, tr("cutemod.hive.b.accuse"), sel >= 0 && pActs < 4);
            btn(g, 57, 124, 51, 13, tr("cutemod.hive.b.ask"), sel >= 0 && pActs < 4);
            btn(g, 110, 124, 51, 13, tr("cutemod.hive.b.alibi"), pActs < 4);
            btn(g, 163, 124, 53, 13, tr("cutemod.hive.b.vote"), true);
        } else if (mstate == M_VOTE) {
            btn(g, 4, 124, 106, 13, tr("cutemod.hive.b.vote"), sel >= 0);
            btn(g, 114, 124, 102, 13, tr("cutemod.hive.b.skip"), true);
        }
    }

    /** The text split into rows that fit: the first row is shorter (the speaker's name stands before it). */
    private List<String> wrap(String text, int maxFirst, int maxRest) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        int max = maxFirst;
        for (String word : text.split(" ")) {
            String t = cur.length() == 0 ? word : cur + " " + word;
            if (tw(t) <= max) { cur.setLength(0); cur.append(t); continue; }
            if (cur.length() > 0) { out.add(cur.toString()); max = maxRest; }
            while (tw(word) > max) {
                String piece = clip(word, max);
                if (piece.isEmpty()) break;
                out.add(piece);
                word = word.substring(piece.length());
                max = maxRest;
            }
            cur.setLength(0);
            cur.append(word);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private void renderChat(GuiGraphics g) {
        rect(g, 4, 76, W - 8, 46, 0x66000000);
        List<Object[]> msgs = new ArrayList<>();
        int budget = 4;
        for (int k = shown - 1; k >= 0 && budget > 0; k--) {
            Line l = lines.get(k);
            String prefix = nm(l.who) + ": ";
            List<String> rows = wrap(l.text.getString(), W - 5 - (15 + tw(prefix)), W - 5 - 21);
            if (rows.size() > 3) rows = new ArrayList<>(rows.subList(0, 3));
            if (rows.size() > budget && !msgs.isEmpty()) break;
            msgs.add(0, new Object[]{l.who, prefix, rows});
            budget -= rows.size();
        }
        int y = 78;
        for (Object[] m : msgs) {
            int who = (Integer) m[0];
            String prefix = (String) m[1];
            @SuppressWarnings("unchecked")
            List<String> rows = (List<String>) m[2];
            int col = COLORS[pet[who]];
            disc(g, 9, y + 4, 3, col);
            Fit.str(g, font(), prefix, 15, y, col, false, W - 3);
            for (int r = 0; r < rows.size(); r++) {
                Fit.str(g, font(), rows.get(r), r == 0 ? 15 + tw(prefix) : 21, y, 0xFFFFFFFF, false, W - 3);
                y += 10;
            }
        }
    }

    private void card(GuiGraphics g, int i) {
        Actor a = act[i];
        int x = 4 + (i % 4) * 54, y = 12 + (i / 4) * 32;
        boolean hov = a.alive && i != 0 && in(mx, my, x, y, 50, 30);
        int face = !a.alive ? 0xFF2C2650 : (sel == i ? 0xFF6A58C8 : (hov ? 0xFF4A3F90 : 0xFF3A3070));
        Gfx.bubble(g, x, y, 50, 30, 4, face);
        if (sel == i) Gfx.outline(g, x, y, 50, 30, 0xFFFFE066);
        ctextW(g, nm(i), x + 27, y + 1, 38, a.alive ? 0xFFFFFFFF : 0x88FFFFFF);
        bigBean(g, x + 14, y + 22, pet[i], 1.2F, !a.alive);
        if (i == 0) rect(g, x + 3, y + 3, 3, 3, 0xFFFFE066);
        else if (playerImp && a.imp) rect(g, x + 3, y + 3, 3, 3, 0xFFFF4040);
        if (mstate == M_SHOW) ctext(g, tally[i] > 0 ? String.valueOf(tally[i]) : "-", x + 36, y + 14, tally[i] > 0 ? 0xFFFFE066 : 0x66FFFFFF);
        else if (!a.alive) ctext(g, "x", x + 36, y + 14, 0xFFFF6A6A);
        else if (mstate == M_VOTE && vote[i] != -3) ctext(g, "*", x + 36, y + 14, 0xFF7ED957);
    }

    private void btn(GuiGraphics g, int x, int y, int w, int h, String label, boolean on) {
        boolean hov = on && in(mx, my, x, y, w, h);
        Gfx.bubble(g, x, y, w, h, 4, !on ? 0xFF3A3560 : (hov ? 0xFF8A78E8 : 0xFF6A58C8));
        ctextW(g, label, x + w / 2, y + 3, w - 4, on ? 0xFFFFFFFF : 0x88FFFFFF);
    }

    private void renderIntro(GuiGraphics g) {
        boolean body = bodyIdx >= 0;
        int flash = (mt / 8) % 2 == 0 ? 0xFFFF5A50 : 0xFFFFB0A8;
        Gfx.bubble(g, 16, 36, W - 32, 62, 8, 0xFF3A1F3F);
        ctextW(g, tr(body ? "cutemod.hive.bodyfound" : "cutemod.hive.emergency"), W / 2, 50, W - 40, flash);
        ctextW(g, tr("cutemod.hive.by", nm(caller)), W / 2, 70, W - 40, 0xFFFFFFFF);
        bigBean(g, W / 2, 96, pet[caller], 1F, false);
    }

    private void renderEject(GuiGraphics g) {
        g.fill(0, 0, W, H, 0xFF08061A);
        for (int i = 0; i < 30; i++) Gfx.sparkle(g, (int) (Gfx.hash(i, 3) * W), (int) (Gfx.hash(i, 4) * H), 1, i * 11 + mt, 0x88FFFFFF);
        if (ejected >= 0) {
            float k = Math.min(1F, mt / 120F);
            int x = (int) (-20 + k * (W + 40));
            int y = 60 - (int) (Math.sin(k * Math.PI) * 18);
            bigBean(g, x, y, pet[ejected], 3F, false);
        }
        if (mt > 70) {
            String s = ejected >= 0 ? tr(ejWasImp ? "cutemod.hive.eject.imp" : "cutemod.hive.eject.crew", nm(ejected)) : tr("cutemod.hive.eject.none");
            ctextW(g, s, W / 2, 108, W - 10, ejected >= 0 && ejWasImp ? 0xFFFF6A6A : 0xFFFFFFFF);
        }
    }

    // ------------------------------------------------------------------ the rest of the MiniGame contract

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return Component.translatable(crewWon ? "cutemod.hive.win.crew" : "cutemod.hive.win.imp");
    }

    @Override
    public Component status() {
        if (playerImp) return Component.translatable("cutemod.hive.status.imp", kills);
        return Component.translatable("cutemod.hive.status.crew", totalTasks == 0 ? 0 : doneTasks * 100 / totalTasks);
    }

    @Override
    public String hintKey() { return "cutemod.hint.hive"; }
}
