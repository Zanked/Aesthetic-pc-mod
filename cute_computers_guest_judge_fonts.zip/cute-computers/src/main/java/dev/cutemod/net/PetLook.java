package dev.cutemod.net;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/**
 * What a pet looks like on the show: the growth stage (0-2), the character (0-4), its age in minutes and what it wears:
 * {@code head} is the list of the head and face layers, {@code body} the list of the body, outer and neck layers
 * (ids joined with '+', see PetWear.layers), {@code name} the name the player gave the pet (up to 12 characters, empty = none; only the park shows it).
 */
public record PetLook(int stage, int trait, int ageMin, String head, String body, String name) {
    public static final StreamCodec<ByteBuf, PetLook> CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, PetLook::stage,
            ByteBufCodecs.VAR_INT, PetLook::trait,
            ByteBufCodecs.VAR_INT, PetLook::ageMin,
            ByteBufCodecs.stringUtf8(64), PetLook::head,
            ByteBufCodecs.stringUtf8(64), PetLook::body,
            ByteBufCodecs.stringUtf8(16), PetLook::name,
            PetLook::new);
}
