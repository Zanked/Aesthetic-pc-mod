package dev.cutemod.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** The talent show saved in the world (data/cutemod_show.dat), kept on the SERVER. The rules live in {@link ShowBoard}. */
public class ShowData extends SavedData {
    private final ShowBoard board = new ShowBoard();

    public static ShowData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(new SavedData.Factory<>(ShowData::new, ShowData::load, null), "cutemod_show");
    }

    /** For reading only; change the show through the methods below so that it gets saved. */
    public ShowBoard board() { return board; }

    public int put(UUID owner, String name, String color, int stage, int trait, int ageMin, boolean sick, String head, String body, int act, int skill) {
        int r = board.put(owner, name, color, stage, trait, ageMin, sick, head, body, act, skill, System.currentTimeMillis());
        if (r == ShowBoard.OK) setDirty();
        return r;
    }

    public int remove(UUID owner) {
        int r = board.remove(owner, System.currentTimeMillis());
        if (r == ShowBoard.OK) setDirty();
        return r;
    }

    public boolean removeAll(UUID owner) {
        boolean r = board.removeAll(owner);
        if (r) setDirty();
        return r;
    }

    public void rename(UUID owner, String name) {
        if (board.rename(owner, name)) setDirty();
    }

    public int like(UUID voter, UUID owner) {
        int r = board.like(voter, owner, System.currentTimeMillis());
        if (r == ShowBoard.OK) setDirty();
        return r;
    }

    public int flower(UUID voter, UUID owner) {
        int r = board.flower(voter, owner, System.currentTimeMillis());
        if (r == ShowBoard.OK) setDirty();
        return r;
    }

    public int unlike(UUID voter, UUID owner) {
        int r = board.unlike(voter, owner, System.currentTimeMillis());
        if (r == ShowBoard.OK) setDirty();
        return r;
    }

    /** Work out the prizes of a finished round (once). */
    public List<ShowBoard.Prize> pay(long round) {
        List<ShowBoard.Prize> p = board.pay(round, System.currentTimeMillis());
        setDirty();
        return p;
    }

    /** Moves the random show schedule on (see {@link ShowBoard#tickEvent}). */
    public boolean tickEvent(long now, java.util.Random rnd) {
        boolean c = board.tickEvent(now, rnd);
        if (c) setDirty();
        return c;
    }

    /** Admin: the show starts at the next round. */
    public void startAtNextRound(long now) {
        board.startAtNextRound(now);
        setDirty();
    }

    public void prune() {
        if (board.prune(System.currentTimeMillis())) setDirty();
    }

    /** "v2" marks the round based show; the likes of the old permanent pet show are dropped on purpose. */
    public static ShowData load(CompoundTag tag, HolderLookup.Provider registries) {
        ShowData d = new ShowData();
        if (!tag.getBoolean("v2")) return d;
        d.board.restorePaid(tag.getLong("paid"));
        d.board.restoreEvent(tag.contains("event") ? tag.getLong("event") : -1L, tag.getLong("nextat"));
        ListTag pets = tag.getList("pets", Tag.TAG_COMPOUND);
        for (int i = 0; i < pets.size(); i++) {
            CompoundTag c = pets.getCompound(i);
            try {
                Set<UUID> likes = new LinkedHashSet<>();
                ListTag l = c.getList("likes", Tag.TAG_STRING);
                for (int k = 0; k < l.size(); k++) {
                    try { likes.add(UUID.fromString(l.getString(k))); } catch (IllegalArgumentException ignored) { }
                }
                Set<UUID> flowers = new LinkedHashSet<>();
                ListTag fl = c.getList("flowers", Tag.TAG_STRING);
                for (int k = 0; k < fl.size(); k++) {
                    try { flowers.add(UUID.fromString(fl.getString(k))); } catch (IllegalArgumentException ignored) { }
                }
                d.board.restore(UUID.fromString(c.getString("owner")), c.getString("name"), c.getLong("round"), c.getString("color"),
                        c.getInt("stage"), c.getInt("trait"), c.getInt("age"), c.getString("head"), c.getString("body"),
                        c.getLong("since"), likes, c.contains("act") ? c.getInt("act") : -1, c.getInt("skill"), flowers);
            } catch (IllegalArgumentException ignored) {
            }
        }
        ListTag day = tag.getList("daily", Tag.TAG_COMPOUND);
        for (int i = 0; i < day.size(); i++) {
            CompoundTag c = day.getCompound(i);
            try { d.board.dailyMap().put(UUID.fromString(c.getString("who")), new long[]{c.getLong("day"), c.getLong("coins")}); }
            catch (IllegalArgumentException ignored) { }
        }
        ListTag med = tag.getList("medals", Tag.TAG_COMPOUND);
        for (int i = 0; i < med.size(); i++) {
            CompoundTag c = med.getCompound(i);
            try { d.board.restoreMedals(UUID.fromString(c.getString("who")), c.getInt("g"), c.getInt("s"), c.getInt("b"), c.getInt("n")); }
            catch (IllegalArgumentException ignored) { }
        }
        ListTag hall = tag.getList("hall", Tag.TAG_COMPOUND);
        for (int i = 0; i < hall.size(); i++) {
            CompoundTag c = hall.getCompound(i);
            d.board.restoreWinner(new ShowBoard.Winner(c.getLong("round"), c.getString("name"), c.getString("color"), c.getBoolean("bot"), c.getInt("total")));
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putBoolean("v2", true);
        tag.putLong("paid", board.paidRound());
        tag.putLong("event", board.eventRound());
        tag.putLong("nextat", board.nextAt());
        ListTag pets = new ListTag();
        for (ShowBoard.Pet p : board.all()) {
            CompoundTag c = new CompoundTag();
            c.putString("owner", p.owner.toString());
            c.putString("name", p.ownerName);
            c.putLong("round", p.round);
            c.putString("color", p.color);
            c.putInt("stage", p.stage);
            c.putInt("trait", p.trait);
            c.putInt("age", p.ageMin);
            c.putString("head", p.head);
            c.putString("body", p.body);
            c.putLong("since", p.since);
            ListTag likes = new ListTag();
            for (UUID u : p.likes) likes.add(StringTag.valueOf(u.toString()));
            c.put("likes", likes);
            c.putInt("act", p.act);
            c.putInt("skill", p.skill);
            ListTag fls = new ListTag();
            for (UUID u : p.flowers) fls.add(StringTag.valueOf(u.toString()));
            c.put("flowers", fls);
            pets.add(c);
        }
        tag.put("pets", pets);
        ListTag day = new ListTag();
        for (var e : board.dailyMap().entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putString("who", e.getKey().toString());
            c.putLong("day", e.getValue()[0]);
            c.putLong("coins", e.getValue()[1]);
            day.add(c);
        }
        tag.put("daily", day);
        ListTag med = new ListTag();
        for (var e : board.medalsMap().entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putString("who", e.getKey().toString());
            c.putInt("g", e.getValue()[0]);
            c.putInt("s", e.getValue()[1]);
            c.putInt("b", e.getValue()[2]);
            c.putInt("n", e.getValue()[3]);
            med.add(c);
        }
        tag.put("medals", med);
        ListTag hall = new ListTag();
        for (ShowBoard.Winner w : board.hall()) {
            CompoundTag c = new CompoundTag();
            c.putLong("round", w.round());
            c.putString("name", w.name());
            c.putString("color", w.color());
            c.putBoolean("bot", w.bot());
            c.putInt("total", w.total());
            hall.add(c);
        }
        tag.put("hall", hall);
        return tag;
    }
}
