package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

/**
 * Daily Gift: 7 cards. Open the app every day and take the gift of the day; a missed day starts the week again.
 * Days 3 and 7 also give a treat for the pet. Saved on the server as "gift" (last day taken, how many days in a row).
 */
public class GiftApp extends KitApp {
    private static final int[] COINS = {5, 8, 10, 12, 15, 20, 40};
    private static final int CW = 38, CX = 17, CY = 44, CH = 62;

    private int last = -1, streak;
    private boolean loaded;

    @Override protected int accent() { return 0xFFF08AA8; }

    @Override protected String id() { return "gift"; }

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        load();
    }

    private void load() {
        loaded = true;
        last = -1;
        streak = 0;
        try {
            String s = Store.read("gift");
            if (s != null) { String[] p = s.split(","); last = Integer.parseInt(p[0]); streak = Integer.parseInt(p[1]); }
        } catch (Exception ignored) { }
        if (last >= 0 && last < today() - 1) streak = 0;                  // a day was missed: the week starts again
        if (streak >= 7 && last != today()) streak = 0;                   // a whole week was taken: a new one
    }

    private boolean taken() { return last == today(); }

    /** Index (0..6) of the card that is open today. */
    private int todayIndex() { return taken() ? streak - 1 : streak; }

    private void claim() {
        if (taken()) { say("cutemod.gift.msg.taken"); return; }
        int i = streak;
        Progress.earn(COINS[i]);
        if (i == 2) Progress.giveTreat("treat_cookie", 2);
        if (i == 6) Progress.giveTreat("treat_honey", 3);
        Season.add(10);
        streak++;
        last = today();
        Store.write("gift", last + "," + streak);
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.9F, 0.6F);
        say("cutemod.gift.msg.got", COINS[i]);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        header(g, f);
        center(g, f, t("cutemod.gift.title"), W / 2, 20, TEXT);
        center(g, f, taken() ? t("cutemod.gift.comeback") : t("cutemod.gift.ready"), W / 2, 31, MUTED);
        int cur = todayIndex();
        for (int d = 0; d < 7; d++) {
            int x = CX + d * CW;
            boolean done = d < streak && !(d == cur && !taken()), now = d == cur && !taken();
            int bg = now ? 0xFFFFF3B0 : done ? 0xFFE6F6E4 : 0xFFF1EAF8;
            int bounce = now ? (int) Math.round(Math.sin(ticks / 6.0) * 2) : 0;
            rect(g, x, CY + bounce, CW - 3, CH, bg);
            rect(g, x, CY + bounce, CW - 3, 3, now ? 0xFFF0A030 : done ? 0xFF5BBF6A : 0xFFD9C7EA);
            center(g, f, t("cutemod.gift.day", d + 1), x + (CW - 3) / 2, CY + 6 + bounce, MUTED);
            int cx = x + (CW - 3) / 2, cy = CY + 28 + bounce;
            if (d == 6) chest(g, cx, cy); else if (d == 2) cookie(g, cx, cy); else { disc(g, cx, cy, 7, 0xFFE0A020); disc(g, cx, cy, 5, 0xFFFFD866); }
            center(g, f, "+" + COINS[d], cx, CY + 46 + bounce, TEXT);
            if (done) { rect(g, x + CW - 14, CY + 6, 8, 8, 0xFF5BBF6A); rect(g, x + CW - 12, CY + 9, 2, 2, 0xFFFFFFFF); rect(g, x + CW - 10, CY + 8, 2, 2, 0xFFFFFFFF); }
        }
        int sx = 6;
        CuteFont.draw(g, f, t("cutemod.gift.streak", Math.min(streak, 7)), sx, 118, MUTED, false);
        btn(g, f, mx, my, 70, 142, 160, taken() ? t("cutemod.gift.btn.done") : t("cutemod.gift.btn.take"), taken() ? 2 : 1);
        footer(g, f);
    }

    private static void chest(GuiGraphics g, int cx, int cy) {
        rect(g, cx - 8, cy - 4, 16, 11, 0xFFB07A4A); rect(g, cx - 8, cy - 7, 16, 4, 0xFFD09A62);
        rect(g, cx - 2, cy - 2, 4, 4, 0xFFFFD866); rect(g, cx - 8, cy, 16, 1, 0xFF8A5A32);
    }

    private static void cookie(GuiGraphics g, int cx, int cy) {
        disc(g, cx, cy, 7, 0xFFD08A5A); disc(g, cx, cy, 5, 0xFFE3A878);
        rect(g, cx - 3, cy - 2, 2, 2, 0xFF6A4228); rect(g, cx + 1, cy, 2, 2, 0xFF6A4228); rect(g, cx - 1, cy + 3, 2, 2, 0xFF6A4228);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (in(x, y, 70, 142, 160, 16)) { claim(); return true; }
        return false;
    }
}
