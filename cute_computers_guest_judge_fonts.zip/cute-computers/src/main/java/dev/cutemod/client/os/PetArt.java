package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.data.PetWear;
import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/**
 * How a Tamagotchi looks. Pure drawing, no state: the pet window (PetApp) and the pet show use the same code,
 * so a pet looks the same everywhere. Everything the picture depends on is passed in.
 * <p>
 * The pet is about 60 x 70 GUI pixels around its centre (cx, cy); the head top is cy - 22 (hats sit there).
 */
public final class PetArt {
    private PetArt() {}

    private static final int DARK = 0xFF3A2A3A;
    private static final int WHITE = 0xFFFFFFFF;

    /** 0 baby (first 20 minutes with the pet), 1 teen (up to an hour), 2 grown-up. */
    public static int stageOf(long ageSec) { return ageSec < 1200 ? 0 : ageSec < 3600 ? 1 : 2; }

    /** Size of the drawing for a growth stage: babies are small. */
    public static float scaleOf(int stage) { return stage == 0 ? 0.72F : stage == 1 ? 0.86F : 1F; }

    /** 0 foodie, 1 playful, 2 sleepy, 3 cuddly, 4 not decided yet (needs about 12 caring actions). */
    public static int traitOf(int feed, int play, int sleep, int pet) {
        if (feed + play + sleep + pet < 12) return 4;
        int best = 0, v = feed;
        if (play > v) { best = 1; v = play; }
        if (sleep > v) { best = 2; v = sleep; }
        if (pet > v) { best = 3; }
        return best;
    }

    private static void tri(GuiGraphics g, int x, int y, int w, int h, int argb) {
        for (int r = 0; r < h; r++) {
            int ww = Math.max(1, w * (r + 1) / h);
            rect(g, x + (w - ww) / 2, y + r, ww, 1, argb);
        }
    }

    public static void draw(GuiGraphics g, ComputerColor color, int cx, int cy, int mood, int ticks,
                            boolean sleeping, boolean sick, int stage, String head, String body) {
        int e1 = cx - 11, e2 = cx + 7, ey = cy - 6, ew = 4, eh = 5, mY = cy + 8;
        int eyeCol = DARK, mouthCol = DARK;
        int top = cy - 22; // top of the head (for hats)
        boolean mouth = true, pupil = false;

        switch (color) {
            case PINK -> {
                int c = 0xFFF58FB8;
                tri(g, cx - 23, cy - 33, 13, 13, c);
                tri(g, cx + 10, cy - 33, 13, 13, c);
                tri(g, cx - 20, cy - 29, 7, 8, 0xFFFFC0D6);
                tri(g, cx + 13, cy - 29, 7, 8, 0xFFFFC0D6);
                disc(g, cx, cy, 22, c);
                disc(g, cx, cy + 9, 12, 0xFFFFD3E3);
                rect(g, cx - 1, cy + 2, 3, 2, 0xFFE5486F);
                rect(g, cx - 31, cy + 3, 10, 1, DARK);
                rect(g, cx - 30, cy + 7, 9, 1, DARK);
                rect(g, cx + 21, cy + 3, 10, 1, DARK);
                rect(g, cx + 21, cy + 7, 9, 1, DARK);
            }
            case GREEN -> {
                int c = 0xFF5BBF6A, d = 0xFF1B3A1B;
                rect(g, cx - 19, cy - 22, 38, 44, c);
                rect(g, cx - 17, cy - 20, 8, 8, 0xFF4AA85A);
                rect(g, cx + 8, cy - 8, 9, 9, 0xFF4AA85A);
                rect(g, cx - 14, cy + 10, 10, 9, 0xFF4AA85A);
                e1 = cx - 13; e2 = cx + 5; ey = cy - 14; ew = 8; eh = 8; eyeCol = d;
                mouth = false;
                rect(g, cx - 4, cy - 2, 8, 6, d);
                rect(g, cx - 8, cy + 4, 16, 10, d);
                rect(g, cx - 4, cy + 10, 8, 4, c);
            }
            case WHITE -> {
                disc(g, cx - 17, cy - 19, 7, 0xFF2A2A2F);
                disc(g, cx + 17, cy - 19, 7, 0xFF2A2A2F);
                disc(g, cx, cy, 22, 0xFFFFFFFF);
                disc(g, cx - 20, cy + 14, 6, 0xFF2A2A2F);
                disc(g, cx + 20, cy + 14, 6, 0xFF2A2A2F);
                disc(g, e1 + 2, ey + 2, 6, 0xFF2A2A2F);
                disc(g, e2 + 2, ey + 2, 6, 0xFF2A2A2F);
                rect(g, cx - 3, cy + 2, 6, 3, 0xFF2A2A2F);
                eyeCol = 0xFFFFFFFF; pupil = true; mY = cy + 10;
            }
            case BLUE -> {
                rect(g, cx - 27, cy - 2, 5, 16, 0xFF263B73);
                rect(g, cx + 22, cy - 2, 5, 16, 0xFF263B73);
                disc(g, cx, cy, 22, 0xFF2F4A8A);
                disc(g, cx, cy + 7, 15, 0xFFFFFFFF);
                rect(g, cx - 14, cy + 21, 10, 4, 0xFFF5A623);
                rect(g, cx + 4, cy + 21, 10, 4, 0xFFF5A623);
                rect(g, cx - 3, cy - 1, 6, 4, 0xFFF5A623);
                ey = cy - 12; eyeCol = 0xFFFFFFFF; pupil = true; mouth = false;
            }
            case ORANGE -> {
                int c = 0xFFF08A24;
                disc(g, cx + 25, cy + 12, 8, c);
                disc(g, cx + 29, cy + 17, 4, 0xFFFFFFFF);
                tri(g, cx - 23, cy - 33, 13, 14, c);
                tri(g, cx + 10, cy - 33, 13, 14, c);
                tri(g, cx - 20, cy - 33, 7, 6, DARK);
                tri(g, cx + 13, cy - 33, 7, 6, DARK);
                disc(g, cx, cy, 22, c);
                disc(g, cx - 12, cy + 9, 9, 0xFFFFF3E0);
                disc(g, cx + 12, cy + 9, 9, 0xFFFFF3E0);
                rect(g, cx - 2, cy + 3, 4, 3, DARK);
                mY = cy + 10;
            }
            case PURPLE -> {
                for (int i = 0; i < 6; i++) { // floating particles
                    if ((ticks / 7 + i) % 2 != 0) continue;
                    rect(g, cx + ((i * 37 + ticks / 5 * 7) % 64) - 32, cy - 30 + ((i * 53 + ticks / 4 * 3) % 64), 2, 2, 0xFFB040FF);
                }
                disc(g, cx, cy, 22, 0xFF1A1426);
                e1 = cx - 13; e2 = cx + 5; ey = cy - 6; ew = 8; eh = 3; eyeCol = 0xFFE040FF;
                mouthCol = 0xFFB040FF;
            }
            case YELLOW -> {
                int flap = (ticks / 4) % 2;
                disc(g, cx - 14, cy - 26 + flap * 2, 8, 0xFFDDF4FF);
                disc(g, cx + 14, cy - 26 + flap * 2, 8, 0xFFDDF4FF);
                rect(g, cx - 8, cy - 34, 1, 11, DARK);
                rect(g, cx + 7, cy - 34, 1, 11, DARK);
                disc(g, cx - 8, cy - 34, 2, DARK);
                disc(g, cx + 7, cy - 34, 2, DARK);
                disc(g, cx, cy, 22, 0xFFF5C518);
                for (int dy : new int[]{12, 13, 14, 18, 19, 20}) {
                    int w = (int) Math.sqrt(22 * 22 - dy * dy);
                    rect(g, cx - w, cy + dy, w * 2, 1, 0xFF2A2A2A);
                }
                mY = cy + 6;
            }
            default -> { // RED: ladybug
                disc(g, cx, cy + 4, 21, 0xFFE5484D);
                rect(g, cx, cy - 6, 1, 30, DARK);
                disc(g, cx - 10, cy + 8, 3, DARK);
                disc(g, cx + 10, cy + 8, 3, DARK);
                disc(g, cx - 6, cy + 17, 3, DARK);
                disc(g, cx + 6, cy + 17, 3, DARK);
                disc(g, cx, cy - 16, 11, 0xFF2A2A2F);
                rect(g, cx - 7, cy - 32, 1, 8, DARK);
                rect(g, cx + 6, cy - 32, 1, 8, DARK);
                e1 = cx - 8; e2 = cx + 4; ey = cy - 20; eyeCol = 0xFFFFFFFF; pupil = true;
                mY = cy - 10; mouthCol = 0xFFFFFFFF; top = cy - 27;
            }
        }

        // eyes
        boolean closed = sleeping || (ticks % 200) < 8;
        if (closed) {
            rect(g, e1, ey + eh / 2, ew, 1, eyeCol == DARK ? DARK : (eyeCol == 0xFFFFFFFF ? 0xFFFFFFFF : eyeCol));
            rect(g, e2, ey + eh / 2, ew, 1, eyeCol == DARK ? DARK : (eyeCol == 0xFFFFFFFF ? 0xFFFFFFFF : eyeCol));
        } else {
            rect(g, e1, ey, ew, eh, eyeCol);
            rect(g, e2, ey, ew, eh, eyeCol);
            if (pupil) {
                rect(g, e1 + 1, ey + 2, 2, 3, DARK);
                rect(g, e2 + 1, ey + 2, 2, 3, DARK);
            } else {
                rect(g, e1 + 1, ey + 1, 1, 1, 0xFFFFFFFF);
                rect(g, e2 + 1, ey + 1, 1, 1, 0xFFFFFFFF);
            }
            if (mood == 0) { // a tear
                rect(g, e2 + ew - 1, ey + eh + (ticks / 8) % 6, 1, 2, 0xFF6AB8FF);
            }
        }

        accessory(g, ticks, head, body, cx, cy, top, e1, e2, ey, ew, eh);
        if (stage == 0 && !sleeping) { // baby cheeks
            rect(g, e1 - 3, ey + eh + 2, 3, 2, 0x99FF8FB0);
            rect(g, e2 + ew, ey + eh + 2, 3, 2, 0x99FF8FB0);
        }
        if (stage == 2 && (ticks / 25) % 3 != 0) { // a grown-up sparkles
            rect(g, cx + 27, cy - 34, 1, 5, 0xFFFFE680);
            rect(g, cx + 25, cy - 32, 5, 1, 0xFFFFE680);
        }

        if (sick && !sleeping) { // thermometer and a sweat drop
            rect(g, cx + 2, mY + 2, 12, 2, 0xFFFFFFFF);
            rect(g, cx + 13, mY + 1, 3, 4, 0xFFE5484D);
            rect(g, cx + 22, cy - 14 + (ticks / 10) % 5, 2, 3, 0xFF6AB8FF);
        }

        // mouth
        if (mouth) {
            int mx0 = cx - 1;
            if (sleeping) {
                rect(g, mx0 - 1, mY, 3, 1, mouthCol);
            } else if (mood == 2) {
                rect(g, mx0 - 4, mY, 9, 1, mouthCol);
                rect(g, mx0 - 5, mY - 1, 1, 1, mouthCol);
                rect(g, mx0 + 5, mY - 1, 1, 1, mouthCol);
            } else if (mood == 1) {
                rect(g, mx0 - 3, mY, 7, 1, mouthCol);
            } else {
                rect(g, mx0 - 3, mY, 7, 1, mouthCol);
                rect(g, mx0 - 4, mY + 1, 1, 1, mouthCol);
                rect(g, mx0 + 4, mY + 1, 1, 1, mouthCol);
            }
        }
    }

    /** Rows of the round body from dy0 to dy1 (relative to the centre), as wide as the body is there: for clothes. */
    private static void band(GuiGraphics g, int cx, int cy, int dy0, int dy1, int argb) {
        for (int dy = dy0; dy <= dy1; dy++) {
            int w = (int) Math.round(Math.sqrt(Math.max(0, 21 * 21 - dy * dy)));
            if (w > 0) rect(g, cx - w, cy + dy, w * 2, 1, argb);
        }
    }

    /** The upper half of a disc (a dome for hats and helmets); its flat side is at y. */
    private static void dome(GuiGraphics g, int cx, int y, int r, int argb) {
        for (int dy = -r; dy <= 0; dy++) {
            int w = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            rect(g, cx - w, y + dy, w * 2 + 1, 1, argb);
        }
    }

    /**
     * A little picture (20 x 20) of an outfit for the shop: the item on a cream blob. (ox, oy) is where the app starts
     * on the screen, because the scissor wants screen coordinates.
     */
    public static void icon(GuiGraphics g, String id, int x, int y, int ox, int oy) {
        boolean body = PetWear.isBody(id);
        g.enableScissor(ox + x, oy + y, ox + x + 20, oy + y + 20);
        g.pose().pushPose();
        // wide things (wings, armor) are drawn smaller so that they fit; hats sit high, clothes low
        float sc = id.equals("acc_wings") ? 0.28F : id.equals("acc_armor") ? 0.42F : body ? 0.5F : 0.45F;
        float oy2 = id.equals("acc_wings") ? 10F : body ? 4F : 19F;
        g.pose().translate(x + 10, y + oy2, 0);
        g.pose().scale(sc, sc, 1F);
        disc(g, 0, 0, 22, 0xFFEBDDC4);
        accessoryOne(id, g, 0, 0, 0, -22, -11, 7, -6, 4, 5);
        g.pose().popPose();
        g.disableScissor();
    }

    /** Things bought in the shop (hats, glasses, scarf, cape...). */
    private static void accessory(GuiGraphics g, int ticks, String head, String body, int cx, int cy, int top, int e1, int e2, int ey, int ew, int eh) {
        // every layer, the one next to the body first (body, outer, neck), then the face and the head on top of them
        for (String id : PetWear.layers(body)) accessoryOne(id, g, ticks, cx, cy, top, e1, e2, ey, ew, eh);
        for (String id : PetWear.layers(head)) accessoryOne(id, g, ticks, cx, cy, top, e1, e2, ey, ew, eh);
    }

    private static void accessoryOne(String id, GuiGraphics g, int ticks, int cx, int cy, int top, int e1, int e2, int ey, int ew, int eh) {
        switch (id) {
            case "acc_ushanka" -> {      // a fur hat with ear flaps
                int fur = 0xFF8A6A4A, furL = 0xFFB08A62;
                rect(g, cx - 14, top - 8, 28, 9, fur);
                rect(g, cx - 12, top - 10, 24, 2, furL);
                rect(g, cx - 17, top - 2, 6, 14, fur);
                rect(g, cx + 11, top - 2, 6, 14, fur);
                rect(g, cx - 15, top - 1, 30, 3, furL);
                rect(g, cx - 2, top - 7, 4, 4, 0xFFE5484D);
            }
            case "acc_headphones" -> {   // a band over the head and two pink ear cups
                for (int a = 180; a <= 360; a += 6) {
                    double rad = Math.toRadians(a);
                    int px = cx + (int) Math.round(25 * Math.cos(rad)), py = cy + (int) Math.round(25 * Math.sin(rad));
                    rect(g, px - 1, py - 1, 3, 3, 0xFF3A3A4A);
                }
                rect(g, cx - 29, cy - 7, 7, 14, 0xFF3A3A4A);
                rect(g, cx - 28, cy - 6, 5, 12, 0xFFFF5C93);
                rect(g, cx + 22, cy - 7, 7, 14, 0xFF3A3A4A);
                rect(g, cx + 23, cy - 6, 5, 12, 0xFFFF5C93);
            }
            case "acc_horns" -> {        // little red devil horns
                tri(g, cx - 15, top - 9, 8, 12, 0xFFE5484D);
                tri(g, cx + 7, top - 9, 8, 12, 0xFFE5484D);
                rect(g, cx - 12, top - 5, 1, 4, 0xFFFF9A9A);
                rect(g, cx + 10, top - 5, 1, 4, 0xFFFF9A9A);
            }
            case "acc_witch" -> {        // a pointy black hat with a purple band and a bent tip
                int k = 0xFF2A1A3A;
                tri(g, cx - 8, top - 22, 16, 21, k);
                rect(g, cx + 3, top - 25, 6, 3, k);
                rect(g, cx - 17, top - 2, 34, 3, k);
                rect(g, cx - 8, top - 9, 16, 3, 0xFFB57BD6);
                rect(g, cx + 3, top - 9, 4, 3, 0xFFFFD84A);
            }
            case "acc_scarf" -> {        // a striped red scarf with a tail
                rect(g, cx - 18, cy + 12, 36, 6, 0xFFE5484D);
                for (int i = 0; i < 6; i++) rect(g, cx - 16 + i * 6, cy + 12, 2, 6, 0xFFFFFFFF);
                rect(g, cx + 6, cy + 18, 8, 13, 0xFFE5484D);
                rect(g, cx + 6, cy + 22, 8, 2, 0xFFFFFFFF);
                rect(g, cx + 6, cy + 28, 8, 3, 0xFFFFFFFF);
            }
            case "acc_cape" -> {         // a red cape: drapes on both sides, a collar and a golden clasp
                int c = 0xFFD93A4A, d = 0xFFA82A38;
                rect(g, cx - 28, cy - 2, 8, 30, c);
                rect(g, cx + 20, cy - 2, 8, 30, c);
                rect(g, cx - 28, cy + 24, 8, 4, d);
                rect(g, cx + 20, cy + 24, 8, 4, d);
                rect(g, cx - 18, cy + 12, 36, 4, d);
                rect(g, cx - 2, cy + 13, 4, 4, 0xFFFFD84A);
            }
            case "acc_glasses" -> {
                int k = 0xFF111111;
                rect(g, e1 - 2, ey - 1, ew + 4, eh + 2, k);
                rect(g, e2 - 2, ey - 1, ew + 4, eh + 2, k);
                rect(g, e1 + ew + 2, ey, Math.max(1, e2 - e1 - ew - 4), 1, k);
                rect(g, e1 - 1, ey, 2, 1, 0x88FFFFFF);
                rect(g, e2 - 1, ey, 2, 1, 0x88FFFFFF);
            }
            case "acc_bow" -> {
                disc(g, cx + 11, top + 6, 3, 0xFFFF5C93);
                disc(g, cx + 21, top + 6, 3, 0xFFFF5C93);
                rect(g, cx + 15, top + 4, 3, 5, 0xFFD93A72);
            }
            case "acc_hat" -> {
                int k = 0xFF1A1A22;
                rect(g, cx - 9, top - 13, 18, 13, k);
                rect(g, cx - 14, top - 1, 28, 3, k);
                rect(g, cx - 9, top - 5, 18, 2, 0xFFE5484D);
            }
            case "acc_crown" -> {
                int gold = 0xFFFFD84A;
                rect(g, cx - 10, top - 5, 20, 5, gold);
                tri(g, cx - 10, top - 11, 6, 6, gold);
                tri(g, cx - 3, top - 14, 7, 9, gold);
                tri(g, cx + 4, top - 11, 6, 6, gold);
                rect(g, cx - 1, top - 3, 3, 2, 0xFFE5484D);
                rect(g, cx - 8, top - 3, 2, 2, 0xFF2F9BFF);
                rect(g, cx + 6, top - 3, 2, 2, 0xFF2F9BFF);
            }
            case "acc_champion" -> { // the laurels of a show champion
                int leaf = 0xFF4FB86A, leaf2 = 0xFF8FE08A, gold = 0xFFFFD84A;
                for (int i = 0; i < 5; i++) {
                    int lx = cx - 14 + i * 3, ly = top - 1 - (i < 3 ? i * 3 : 6 + (i - 2));
                    rect(g, lx, ly, 3, 3, i % 2 == 0 ? leaf : leaf2);
                    rect(g, 2 * cx - lx - 3, ly, 3, 3, i % 2 == 0 ? leaf : leaf2);
                }
                rect(g, cx - 1, top - 14, 3, 5, gold);
                rect(g, cx - 2, top - 12, 5, 1, gold);
            }
            case "acc_ghost" -> { // a tiny ghost friend floats next to the head
                int gy = top - 6 + (int) Math.round(Math.sin(ticks / 12.0) * 2), gx = cx + 22;
                disc(g, gx, gy, 6, 0xFFF4F0FF);
                rect(g, gx - 6, gy, 13, 8, 0xFFF4F0FF);
                for (int i = 0; i < 3; i++) rect(g, gx - 6 + i * 5, gy + 8, 3, 2 + (i + ticks / 10) % 2, 0xFFF4F0FF);
                rect(g, gx - 3, gy - 2, 2, 3, 0xFF3A2A3A);
                rect(g, gx + 2, gy - 2, 2, 3, 0xFF3A2A3A);
                rect(g, gx - 1, gy + 3, 3, 1, 0xFFE06A8A);
            }
            case "acc_party" -> {
                tri(g, cx - 8, top - 18, 16, 18, 0xFFB57BD6);
                rect(g, cx - 5, top - 9, 10, 2, 0xFFFFFFFF);
                disc(g, cx, top - 18, 3, 0xFFFFD84A);
            }
            case "acc_halo" -> {
                rect(g, cx - 12, top - 14, 24, 10, 0x33FFF3B0);
                rect(g, cx - 9, top - 12, 18, 2, 0xFFFFE680);
                rect(g, cx - 9, top - 6, 18, 2, 0xFFFFE680);
                rect(g, cx - 11, top - 10, 2, 4, 0xFFFFE680);
                rect(g, cx + 9, top - 10, 2, 4, 0xFFFFE680);
            }
            case "acc_flower" -> {
                int fx = cx - 15, fy = top + 6;
                disc(g, fx - 4, fy, 2, 0xFFFF8AC0);
                disc(g, fx + 4, fy, 2, 0xFFFF8AC0);
                disc(g, fx, fy - 4, 2, 0xFFFF8AC0);
                disc(g, fx, fy + 4, 2, 0xFFFF8AC0);
                disc(g, fx, fy, 3, 0xFFFFD84A);
            }
            case "acc_cap" -> {
                rect(g, cx - 9, top - 7, 18, 7, 0xFF2F9BFF);
                rect(g, cx - 9, top - 1, 24, 2, 0xFF2F7ACF);
                rect(g, cx - 1, top - 9, 2, 2, 0xFF2F7ACF);
            }
            case "acc_sprout" -> {       // a little green sprout with two leaves
                rect(g, cx - 1, top - 6, 2, 6, 0xFF4CAF50);
                disc(g, cx - 4, top - 7, 3, 0xFF7ED957);
                disc(g, cx + 4, top - 8, 3, 0xFF5CC24A);
            }
            case "acc_starclip" -> {     // a golden star hair clip at the side of the head
                int sx2 = cx + 8, sy2 = top + 2;
                rect(g, sx2 - 3, sy2 - 1, 7, 2, 0xFFFFD84A);
                rect(g, sx2 - 1, sy2 - 3, 2, 6, 0xFFFFD84A);
                rect(g, sx2 - 1, sy2 - 1, 2, 2, 0xFFFFF2A0);
            }
            // ---- the second wardrobe: head ----
            case "acc_chef" -> {         // a tall white chef hat
                rect(g, cx - 10, top - 14, 20, 14, WHITE);
                disc(g, cx - 7, top - 15, 6, WHITE);
                disc(g, cx + 7, top - 15, 6, WHITE);
                disc(g, cx, top - 19, 6, WHITE);
                rect(g, cx - 12, top - 4, 24, 5, 0xFFE8EAF2);
                rect(g, cx - 5, top - 12, 1, 7, 0xFFE8EAF2);
                rect(g, cx + 5, top - 12, 1, 7, 0xFFE8EAF2);
            }
            case "acc_pirate" -> {       // a black pirate hat with a tiny skull
                int k = 0xFF1A1A22;
                rect(g, cx - 16, top - 1, 32, 4, k);
                rect(g, cx - 12, top - 9, 24, 9, k);
                rect(g, cx - 8, top - 11, 16, 2, k);
                rect(g, cx - 16, top + 3, 32, 1, 0xFFFFD84A);
                rect(g, cx - 3, top - 7, 6, 3, WHITE);
                rect(g, cx - 2, top - 4, 4, 2, WHITE);
                rect(g, cx - 2, top - 6, 1, 1, k);
                rect(g, cx + 1, top - 6, 1, 1, k);
            }
            case "acc_bunny" -> {        // two tall bunny ears
                for (int s = -1; s <= 1; s += 2) {
                    int ex = cx + s * 9;
                    rect(g, ex - 3, top - 18, 7, 19, WHITE);
                    disc(g, ex, top - 18, 3, WHITE);
                    rect(g, ex - 1, top - 16, 3, 15, 0xFFFFB6D2);
                }
            }
            case "acc_catears" -> {      // a headband with cat ears
                int k = 0xFF3A3A4A;
                tri(g, cx - 17, top - 9, 13, 13, k);
                tri(g, cx + 4, top - 9, 13, 13, k);
                tri(g, cx - 14, top - 5, 7, 8, 0xFFFF9AC0);
                tri(g, cx + 7, top - 5, 7, 8, 0xFFFF9AC0);
                rect(g, cx - 17, top + 2, 34, 2, k);
            }
            case "acc_beret" -> {        // a red beret
                int c = 0xFFC4323A;
                rect(g, cx - 13, top - 6, 26, 6, c);
                rect(g, cx - 10, top - 8, 20, 2, c);
                rect(g, cx - 16, top - 3, 4, 3, c);
                rect(g, cx - 1, top - 11, 2, 3, 0xFF8A1A22);
                rect(g, cx - 13, top, 26, 2, 0xFF8A1A22);
            }
            case "acc_bandana" -> {      // a red dotted bandana, knotted at the side
                int c = 0xFFE5484D;
                rect(g, cx - 15, top + 3, 30, 5, c);
                for (int i = 0; i < 4; i++) rect(g, cx - 11 + i * 7, top + 5, 2, 2, WHITE);
                rect(g, cx + 14, top + 4, 5, 3, c);
                rect(g, cx + 17, top + 7, 3, 6, c);
            }
            case "acc_helmet" -> {       // a glass bubble over the whole head
                disc(g, cx, cy, 25, 0x2290D8FF);
                for (int a = 0; a < 360; a += 5) {
                    double rad = Math.toRadians(a);
                    rect(g, cx + (int) Math.round(25 * Math.cos(rad)) - 1, cy + (int) Math.round(25 * Math.sin(rad)) - 1, 2, 2, 0xFFDDE3F0);
                }
                rect(g, cx - 18, cy + 24, 36, 4, 0xFFC8D0E0);
                rect(g, cx - 18, cy + 24, 36, 1, WHITE);
                rect(g, cx - 15, cy - 17, 6, 2, 0xAAFFFFFF);
                rect(g, cx - 17, cy - 14, 2, 4, 0xAAFFFFFF);
            }
            case "acc_santa" -> {        // a red hat with a white fur edge and a pompom
                tri(g, cx - 12, top - 16, 24, 18, 0xFFE5484D);
                rect(g, cx - 15, top - 3, 30, 5, WHITE);
                disc(g, cx, top - 16, 3, WHITE);
            }
            case "acc_nightcap" -> {     // a floppy blue nightcap with stars
                int c = 0xFF6A8AE0;
                tri(g, cx - 12, top - 13, 24, 15, c);
                rect(g, cx + 3, top - 15, 9, 3, c);
                disc(g, cx + 13, top - 12, 3, WHITE);
                rect(g, cx - 13, top - 3, 26, 4, WHITE);
                rect(g, cx - 3, top - 9, 2, 2, 0xFFFFE680);
                rect(g, cx + 3, top - 6, 2, 2, 0xFFFFE680);
            }
            case "acc_straw" -> {        // a straw hat with a red band
                rect(g, cx - 22, top - 1, 44, 3, 0xFFE8C46A);
                rect(g, cx - 11, top - 9, 22, 8, 0xFFF0D07A);
                rect(g, cx - 11, top - 4, 22, 2, 0xFFE5484D);
                for (int i = 0; i < 4; i++) rect(g, cx - 8 + i * 5, top - 8, 1, 3, 0xFFD8B25A);
            }
            case "acc_mushroom" -> {     // a red mushroom cap with white dots
                dome(g, cx, top + 1, 14, 0xFFE5484D);
                rect(g, cx - 14, top + 1, 29, 2, 0xFFF3E3C8);
                disc(g, cx - 6, top - 6, 2, WHITE);
                disc(g, cx + 5, top - 8, 2, WHITE);
                disc(g, cx + 1, top - 3, 1, WHITE);
            }
            case "acc_knight" -> {       // a steel helmet with a red plume
                dome(g, cx, top + 5, 15, 0xFFB8C0CC);
                rect(g, cx - 15, top + 5, 31, 2, 0xFF8A94A4);
                rect(g, cx - 11, top + 1, 22, 3, 0xFF3A4252);
                rect(g, cx - 1, top - 10, 2, 10, 0xFF8A94A4);
                rect(g, cx - 2, top - 17, 4, 7, 0xFFE5484D);
                rect(g, cx - 1, top - 19, 3, 3, 0xFFE5484D);
            }
            case "acc_pumpkin" -> {      // a jack-o'-lantern on the head
                disc(g, cx, top - 4, 10, 0xFFFF8A1A);
                rect(g, cx - 1, top - 16, 3, 4, 0xFF4A8A2A);
                rect(g, cx - 6, top - 7, 3, 3, 0xFF3A2A1A);
                rect(g, cx + 3, top - 7, 3, 3, 0xFF3A2A1A);
                rect(g, cx - 5, top - 1, 10, 2, 0xFF3A2A1A);
            }
            // ---- the second wardrobe: body ----
            case "acc_hoodie" -> {       // a blue-grey hoodie with a pocket and strings
                int c = 0xFF6A7AA8, d = 0xFF4A5A88;
                band(g, cx, cy, 12, 21, c);
                rect(g, cx - 14, cy + 10, 28, 3, d);
                rect(g, cx - 6, cy + 16, 12, 4, d);
                rect(g, cx - 5, cy + 13, 1, 4, WHITE);
                rect(g, cx + 4, cy + 13, 1, 4, WHITE);
            }
            case "acc_sweater" -> {      // a red winter sweater with white stripes
                band(g, cx, cy, 12, 21, 0xFFE5484D);
                band(g, cx, cy, 15, 16, WHITE);
                band(g, cx, cy, 19, 19, WHITE);
                rect(g, cx - 8, cy + 11, 16, 2, 0xFFC4323A);
            }
            case "acc_tutu" -> {         // a pink ballet skirt
                rect(g, cx - 22, cy + 15, 44, 3, 0xFFFFB6D2);
                rect(g, cx - 24, cy + 18, 48, 3, 0xFFFF8AC0);
                rect(g, cx - 24, cy + 21, 48, 1, 0xFFFFD6E8);
                rect(g, cx - 10, cy + 13, 20, 2, 0xFFD93A72);
            }
            case "acc_tux" -> {          // a black tuxedo with a white shirt and a red bow tie
                band(g, cx, cy, 12, 21, 0xFF1A1A22);
                rect(g, cx - 5, cy + 12, 10, 3, WHITE);
                rect(g, cx - 3, cy + 15, 6, 3, WHITE);
                rect(g, cx - 1, cy + 18, 2, 2, WHITE);
                rect(g, cx - 6, cy + 10, 5, 4, 0xFFE5484D);
                rect(g, cx + 1, cy + 10, 5, 4, 0xFFE5484D);
                rect(g, cx - 1, cy + 11, 2, 2, 0xFF9A2A32);
            }
            case "acc_pajamas" -> {      // light blue pajamas with little stars
                band(g, cx, cy, 12, 21, 0xFF8FC8FF);
                rect(g, cx - 6, cy + 11, 12, 2, WHITE);
                rect(g, cx - 9, cy + 15, 2, 2, 0xFFFFE680);
                rect(g, cx + 5, cy + 14, 2, 2, 0xFFFFE680);
                rect(g, cx - 2, cy + 18, 2, 2, 0xFFFFE680);
                rect(g, cx + 8, cy + 18, 2, 2, 0xFFFFE680);
            }
            case "acc_hawaiian" -> {     // a teal shirt with big flowers
                band(g, cx, cy, 12, 21, 0xFF3FC8B8);
                rect(g, cx - 7, cy + 11, 5, 3, WHITE);
                rect(g, cx + 2, cy + 11, 5, 3, WHITE);
                rect(g, cx - 9, cy + 15, 3, 3, 0xFFFF6A8A);
                rect(g, cx + 4, cy + 14, 3, 3, 0xFFFFE04A);
                rect(g, cx - 3, cy + 18, 3, 3, 0xFFFF8A3A);
            }
            case "acc_apron" -> {        // a white apron with a pocket and a heart
                band(g, cx, cy, 13, 21, WHITE);
                rect(g, cx - 5, cy + 10, 10, 3, WHITE);
                rect(g, cx - 14, cy + 13, 5, 1, 0xFFD0D0D8);
                rect(g, cx + 9, cy + 13, 5, 1, 0xFFD0D0D8);
                rect(g, cx - 5, cy + 17, 10, 4, 0xFFE8E8F0);
                rect(g, cx - 1, cy + 18, 2, 2, 0xFFE5484D);
            }
            case "acc_wings" -> {        // glittering fairy wings that flutter
                int fl = (ticks / 6) % 2;
                for (int s = -1; s <= 1; s += 2) {
                    disc(g, cx + s * 30, cy - 6 - fl, 9, 0xBB9AD4FF);
                    disc(g, cx + s * 28, cy + 8 + fl, 6, 0xBB9AD4FF);
                    rect(g, cx + s * 30 - 1, cy - 12 - fl, 2, 2, 0xCCFFFFFF);
                }
            }
            case "acc_kimono" -> {       // a pink kimono with a purple belt
                band(g, cx, cy, 11, 21, 0xFFFF9AC0);
                rect(g, cx - 5, cy + 11, 2, 5, WHITE);
                rect(g, cx + 3, cy + 11, 2, 5, WHITE);
                band(g, cx, cy, 16, 18, 0xFFB57BD6);
                rect(g, cx - 4, cy + 15, 8, 5, 0xFF8A5AD6);
                rect(g, cx - 11, cy + 13, 2, 2, WHITE);
                rect(g, cx + 9, cy + 13, 2, 2, WHITE);
            }
            case "acc_coat" -> {         // a dark red pirate coat with gold buttons
                band(g, cx, cy, 12, 21, 0xFF8A2A2A);
                rect(g, cx - 9, cy + 11, 5, 3, 0xFF5A1A1A);
                rect(g, cx + 4, cy + 11, 5, 3, 0xFF5A1A1A);
                rect(g, cx - 1, cy + 13, 2, 2, 0xFFFFD84A);
                rect(g, cx - 1, cy + 17, 2, 2, 0xFFFFD84A);
                band(g, cx, cy, 15, 15, 0xFF3A2A1A);
            }
            case "acc_armor" -> {        // silver knight armor with shoulder plates
                band(g, cx, cy, 11, 21, 0xFFB8C0CC);
                band(g, cx, cy, 11, 12, 0xFFE0E6EE);
                rect(g, cx - 1, cy + 13, 2, 9, 0xFF8A94A4);
                rect(g, cx - 8, cy + 15, 2, 2, 0xFF7A8494);
                rect(g, cx + 6, cy + 15, 2, 2, 0xFF7A8494);
                rect(g, cx - 24, cy + 6, 9, 6, 0xFFB8C0CC);
                rect(g, cx + 15, cy + 6, 9, 6, 0xFFB8C0CC);
                rect(g, cx - 24, cy + 6, 9, 1, 0xFFE0E6EE);
                rect(g, cx + 15, cy + 6, 9, 1, 0xFFE0E6EE);
            }
            case "acc_spacesuit" -> {    // a white space suit with an orange stripe and a control panel
                band(g, cx, cy, 11, 21, 0xFFF0F2F8);
                band(g, cx, cy, 16, 17, 0xFFFF8A3A);
                rect(g, cx - 12, cy + 10, 24, 2, 0xFF8FA0C0);
                rect(g, cx - 6, cy + 12, 12, 3, 0xFF8FA0C0);
                rect(g, cx - 4, cy + 13, 2, 1, 0xFF4AE06A);
                rect(g, cx + 1, cy + 13, 2, 1, 0xFFE5484D);
            }
            default -> { }
        }
    }
}
