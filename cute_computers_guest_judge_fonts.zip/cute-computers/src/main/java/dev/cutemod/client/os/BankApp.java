package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

/**
 * Coin Bank: a piggy bank. Put coins in (at most 300 in all); after 7 days you take them out with 10% more.
 * Take them out earlier and you get back only what you put in. Adding coins starts the 7 days again.
 * Saved as "bank": coins inside, time of the last deposit (seconds).
 */
public class BankApp extends KitApp {
    private static final int MAX = 300, WEEK_S = 7 * 86400, PERCENT = 10;
    private static final int[] STEPS = {10, 50, 100};

    private int inside;
    private long since;
    private boolean loaded;
    private int jingle;

    @Override protected int accent() { return 0xFFF08A9A; }

    @Override protected String id() { return "bank"; }

    @Override
    public void attach(Shell shell) { super.attach(shell); load(); }

    private void load() {
        loaded = true;
        inside = 0;
        since = 0;
        try {
            String s = Store.read("bank");
            if (s != null) { String[] p = s.split(","); inside = Math.max(0, Math.min(MAX, Integer.parseInt(p[0]))); since = Long.parseLong(p[1]); }
        } catch (Exception ignored) { }
    }

    private void save() { Store.write("bank", inside + "," + since); }

    private static long now() { return System.currentTimeMillis() / 1000; }

    private long left() { return Math.max(0, since + WEEK_S - now()); }

    private boolean ripe() { return inside > 0 && left() == 0; }

    private int interest() { return inside * PERCENT / 100; }

    private void deposit(int n) {
        int room = MAX - inside;
        n = Math.min(n, room);
        if (n <= 0) { say("cutemod.bank.msg.full", MAX); return; }
        if (!Progress.spend(n)) { say("cutemod.bank.msg.nocoins"); return; }
        inside += n;
        since = now();                                           // a new deposit starts the week again
        jingle = 20;
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.5F, 0.5F);
        save();
        say("cutemod.bank.msg.in", n);
    }

    private void withdraw() {
        if (inside <= 0) return;
        int back = inside + (ripe() ? interest() : 0);
        boolean early = !ripe();
        Progress.earn(back);
        inside = 0;
        since = 0;
        save();
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), early ? 1.0F : 2.0F, 0.6F);
        say(early ? "cutemod.bank.msg.early" : "cutemod.bank.msg.out", back);
    }

    @Override
    public void tick() {
        super.tick();
        if (jingle > 0) jingle--;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        header(g, f);
        String purse = t("cutemod.bank.purse", Progress.coins());
        CuteFont.draw(g, f, purse, W - 6 - f.width(purse), 3, 0xFFFFFFFF, false);
        pig(g, 66, 70, jingle);
        // the numbers
        int x = 140;
        CuteFont.draw(g, f, t("cutemod.bank.inside"), x, 22, MUTED, false);
        CuteFont.draw(g, f, inside + " / " + MAX, x, 33, TEXT, false);
        if (inside > 0) {
            long l = left();
            float p = 1F - l / (float) WEEK_S;
            rect(g, x, 50, 150, 8, 0xFFEBDDF7);
            rect(g, x, 50, (int) (150 * Math.max(0F, Math.min(1F, p))), 8, ripe() ? 0xFF5BBF6A : accent());
            String st = ripe() ? t("cutemod.bank.ripe", interest()) : t("cutemod.bank.wait", l / 86400, l / 3600 % 24);
            CuteFont.draw(g, f, st, x, 62, ripe() ? 0xFF3E9A4A : MUTED, false);
        } else CuteFont.draw(g, f, t("cutemod.bank.empty", PERCENT), x, 50, MUTED, false);
        for (int i = 0; i < STEPS.length; i++) btn(g, f, mx, my, x + i * 52, 80, 48, "+" + STEPS[i], Progress.coins() >= STEPS[i] && inside < MAX ? 0 : 2);
        btn(g, f, mx, my, x, 100, 150, inside > 0 ? (ripe() ? t("cutemod.bank.take", inside + interest()) : t("cutemod.bank.takeearly", inside)) : t("cutemod.bank.nothing"), inside > 0 ? (ripe() ? 1 : 0) : 2);
        CuteFont.draw(g, f, t("cutemod.bank.rule", PERCENT), x, 122, MUTED, false);
        footer(g, f);
    }

    /** The piggy bank (it hops when a coin goes in). */
    private void pig(GuiGraphics g, int cx, int cy, int hop) {
        cy -= hop > 0 ? (int) Math.round(Math.sin(hop / 20.0 * Math.PI) * 6) : 0;
        int body = 0xFFFFB6C8, dark = 0xFFF08AA8;
        disc(g, cx, cy, 30, body);
        disc(g, cx - 14, cy - 28, 8, body); disc(g, cx + 14, cy - 28, 8, body);          // ears
        disc(g, cx - 14, cy - 28, 4, dark); disc(g, cx + 14, cy - 28, 4, dark);
        rect(g, cx - 36 + 8, cy + 2, 14, 16, dark);                                      // snout
        disc(g, cx - 34, cy + 10, 8, dark); rect(g, cx - 37, cy + 7, 2, 4, 0xFFC0607A); rect(g, cx - 32, cy + 7, 2, 4, 0xFFC0607A);
        rect(g, cx - 18, cy - 8, 4, 5, 0xFF3A2A3A);                                       // eye
        rect(g, cx - 10, cy - 22, 24, 4, 0xFFC0607A);                                     // the slot
        rect(g, cx - 20, cy + 26, 10, 8, dark); rect(g, cx + 10, cy + 26, 10, 8, dark);   // legs
        rect(g, cx + 26, cy - 6, 6, 3, dark); rect(g, cx + 30, cy - 9, 3, 3, dark);       // tail
        if (inside > 0) { disc(g, cx + 2, cy + 8, 5, 0xFFE0A020); disc(g, cx + 2, cy + 8, 3, 0xFFFFD866); }
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < STEPS.length; i++) if (in(x, y, 140 + i * 52, 80, 48, 16)) { deposit(STEPS[i]); return true; }
        if (in(x, y, 140, 100, 150, 16)) { withdraw(); return true; }
        return false;
    }
}
