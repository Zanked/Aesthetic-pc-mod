package dev.cutemod.client.os;

import dev.cutemod.CuteMod;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;

/**
 * The cute pixel font of the computer (assets/cutemod/font/cute.json, Latin and Cyrillic, rounded and friendly).
 * Every text of the OS is drawn through here instead of {@code g.drawString}. A character the font does not have
 * (for example a dash or a symbol) falls back to the normal game font. Set {@link #ENABLED} to false to go back
 * to the normal font everywhere. The player picks the weight (cute / bold / normal) in Settings.
 */
public final class CuteFont {
    public static final boolean ENABLED = true;
    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "cute");
    public static final ResourceLocation BOLD_ID = ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "cute_bold");
    /** The fonts of both weights in three sizes: small (glyphs 7 px high), normal (9, the original) and large (11). Each size is its own font file. */
    private static final Style[][] STYLES = {
            {font("cute_s"), font("cute"), font("cute_l")},
            {font("cute_bold_s"), font("cute_bold"), font("cute_bold_l")}};

    private static Style font(String name) { return Style.EMPTY.withFont(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, name)); }

    /** The weight of the font (Settings > Other > Font): 0 = cute, 1 = cute bold, 2 = the normal game font. Kept in the computer's data. */
    public static final int REGULAR_W = 0, BOLD_W = 1, SYSTEM_W = 2;
    /** The size (Settings > Other > Font size): 0 = small, 1 = normal, 2 = large. It belongs to the cute fonts; the game's own font has one size. */
    public static final int SMALL = 0, NORMAL = 1, LARGE = 2;
    private static int weight, size = NORMAL;
    private static long readAt;

    private static void refresh() {
        long now = System.currentTimeMillis();
        if (now - readAt <= 500) return;
        readAt = now;                                               // look at the saved values now and then (they arrive after the login)
        if (!Store.ready()) return;
        try { weight = sane(Integer.parseInt(String.valueOf(Store.read("fontweight")).trim())); }
        catch (NumberFormatException ignored) { weight = REGULAR_W; }
        try { size = Math.max(SMALL, Math.min(LARGE, Integer.parseInt(String.valueOf(Store.read("fontsize")).trim()))); }
        catch (NumberFormatException ignored) { size = NORMAL; }
    }

    public static int weight() { refresh(); return weight; }

    public static int size() { refresh(); return size; }

    public static void setSize(int s) {
        size = Math.max(SMALL, Math.min(LARGE, s));
        readAt = System.currentTimeMillis();
        Store.write("fontsize", Integer.toString(size));
    }

    /** Only the three weights exist. A saved "modern" (3, a font that was removed) becomes the cute one. */
    private static int sane(int w) { return w < 0 || w > SYSTEM_W ? REGULAR_W : w; }

    public static void setWeight(int w) {
        weight = sane(w);
        readAt = System.currentTimeMillis();
        Store.write("fontweight", Integer.toString(weight));
    }

    /** The style to draw with, or null for the normal game font. */
    private static Style style() {
        if (!ENABLED) return null;
        int w = weight();
        return w == SYSTEM_W ? null : STYLES[w][size()];
    }

    private CuteFont() {}

    private static Component cute(String s, Style st) { return Component.literal(s).withStyle(st); }

    private static Component cute(Component s, Style st) {
        MutableComponent root = Component.empty().withStyle(st);   // the parts inherit the font, keep their own colours
        return root.append(s);
    }

    public static int draw(GuiGraphics g, Font f, String s, int x, int y, int argb, boolean shadow) {
        Style st = style();
        return st != null ? g.drawString(f, cute(s, st), x, y, argb, shadow) : g.drawString(f, s, x, y, argb, shadow);
    }

    public static int draw(GuiGraphics g, Font f, String s, int x, int y, int argb) { return draw(g, f, s, x, y, argb, true); }

    public static int draw(GuiGraphics g, Font f, Component s, int x, int y, int argb, boolean shadow) {
        Style st = style();
        return st != null ? g.drawString(f, cute(s, st), x, y, argb, shadow) : g.drawString(f, s, x, y, argb, shadow);
    }

    public static int draw(GuiGraphics g, Font f, Component s, int x, int y, int argb) { return draw(g, f, s, x, y, argb, true); }

    /** A ready line of text keeps the font it has. */
    public static int draw(GuiGraphics g, Font f, FormattedCharSequence s, int x, int y, int argb, boolean shadow) {
        return g.drawString(f, s, x, y, argb, shadow);
    }

    public static int draw(GuiGraphics g, Font f, FormattedCharSequence s, int x, int y, int argb) { return draw(g, f, s, x, y, argb, true); }
}
