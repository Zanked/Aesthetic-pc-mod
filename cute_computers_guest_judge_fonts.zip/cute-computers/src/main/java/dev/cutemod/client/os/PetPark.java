package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.data.ParkData;
import dev.cutemod.net.ParkSyncPayload;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/**
 * The Pet Park screen of the Tamagotchi app: a sunny meadow where the pets of the players on the server walk about.
 * Click the grass to walk, click another pet to go and play with it, use the three emotes to say hi.
 * Everything that counts (friendship, coins) is decided on the server; this class only draws and sends the position.
 */
final class PetPark {
    private static final int W = App.W, H = App.H;
    private static final int Y_MIN = 70, Y_MAX = 150, BAR_Y = 150;
    private static final int[] EMOTE_X = {8, 34, 60, 86, 112, 138};      // heart, Hi, !, a dance, a laugh, a yawn
    private static final float SCALE = 0.55F;

    private final String myColor;
    private final Runnable back, onPlayed;
    private final java.util.function.IntConsumer onAct;
    // what the pet does on the spot: 0 nothing, 1 sits on the bench, 2 splashes in the pond; want = where a click sent it
    private int act, want, actT;
    private double bx = 100, by = 124, bvx, bvy;                  // the ball (only you see it)
    private int kickGap;
    private final List<double[]> drops = new ArrayList<>();       // x, y, vx, vy, life
    private double x = 150, y = 120, tx = 150, ty = 120;
    private int lastRender = -100;
    private int ticks, sendT = 100, emoteOut, myEmote, myEmoteT, toastT, chaseGap;
    private String toast = "", chase = "";
    private boolean noPet;
    private final Map<String, double[]> pos = new HashMap<>();      // owner -> {x, y} (smoothed)
    private final List<double[]> hearts = new ArrayList<>();         // x, y, vy, life

    PetPark(String myColor, Runnable back, Runnable onPlayed, java.util.function.IntConsumer onAct) {
        this.myColor = myColor;
        this.onAct = onAct;
        this.back = back;
        this.onPlayed = onPlayed;
    }

    void open() {
        noPet = !Park.move(myColor, (int) x, (int) y, 0);
        sendT = 0;
    }

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    private void leave() {
        Park.leave();
        back.run();
    }

    private void say(String s) { toast = s; toastT = 180; }

    // ---------- time ----------
    void tick() {
        ticks++;
        if (ticks - lastRender < 5) GameMusic.keep("park", false);    // the park tune, only while the meadow is on screen
        if (noPet) return;
        if (++sendT >= 10) { sendT = 0; if (!Park.move(myColor, (int) x, (int) y, emoteOut)) noPet = true; emoteOut = 0; }
        if (toastT > 0) toastT--;
        if (myEmoteT > 0 && --myEmoteT == 0) myEmote = 0;
        ParkSyncPayload s = Park.last();
        ParkSyncPayload.Pet target = null;
        if (s != null) {
            for (ParkSyncPayload.Pet p : s.pets()) {
                double[] q = pos.computeIfAbsent(p.owner(), k -> new double[]{p.x(), p.y()});
                q[0] += (p.x() - q[0]) * 0.18;
                q[1] += (p.y() - q[1]) * 0.18;
                if (p.owner().equals(chase)) target = p;
                if (p.playing() && ticks % 12 == 0) hearts.add(new double[]{q[0] + (ticks % 24 == 0 ? 6 : -6), q[1] - 30, -0.5, 50});
            }
            pos.keySet().removeIf(k -> s.pets().stream().noneMatch(p -> p.owner().equals(k)));
        }
        if (Park.takeFull()) say(t("cutemod.park.full"));
        if (Park.takePlayed()) {
            onPlayed.run();
            say(t("cutemod.park.played", Park.with()));
            for (int i = 0; i < 6; i++) hearts.add(new double[]{x - 10 + i * 4, y - 30, -0.6 - (i % 3) * 0.2, 60});
        }
        // walk to the target (or to the pet we want to play with)
        if (target != null) {
            double[] q = pos.get(target.owner());
            double dx = q[0] - x, dy = q[1] - y, d = Math.hypot(dx, dy);
            if (d <= 42) {
                if (chaseGap == 0) { Park.play(target.owner()); chaseGap = 90; }
                chase = "";
            } else { tx = q[0] - dx / d * 30; ty = q[1] - dy / d * 30; }
        } else if (!chase.isEmpty()) chase = "";
        if (chaseGap > 0) chaseGap--;
        double dx = tx - x, dy = ty - y, d = Math.hypot(dx, dy);
        if (d > 1.5) { double sp = Math.min(d, 1.5); x += dx / d * sp; y += dy / d * sp; }
        y = Math.max(Y_MIN, Math.min(Y_MAX, y));
        checkTreasure();
        activities();
        ball();
        hearts.removeIf(h -> { h[1] += h[2]; return --h[3] <= 0; });
    }

    // ---------- bench, pond and ball ----------
    private static final int BENCH_X = 136, BENCH_Y = 88, POND_X = 236, POND_Y = 142;

    /** Walking to the bench or the pond ends in sitting or splashing; any other click ends it. */
    private void activities() {
        if (act == 0 && want != 0 && Math.hypot(tx - x, ty - y) < 2) {
            act = want; actT = 0;
            if (act == 1) { x = BENCH_X; y = BENCH_Y; tx = x; ty = y; }
        } else if (act != 0 && Math.hypot(tx - x, ty - y) > 3) { act = 0; want = 0; }
        if (act == 0) return;
        actT++;
        if (act == 1) {
            if (actT % 240 == 0) onAct.accept(1);
            if (actT % 90 == 0) hearts.add(new double[]{x + 8, y - 34, -0.35, 45});
        } else {
            if (actT % 6 == 0) for (int i = 0; i < 2; i++) drops.add(new double[]{x - 10 + (ticks * 7 + i * 13) % 20, y - 8, (i - 0.5) * 0.7, -1.4 - (i % 2) * 0.5, 22});
            if (actT % 120 == 0) onAct.accept(2);
        }
    }

    private void ball() {
        kickGap = Math.max(0, kickGap - 1);
        double dx = bx - x, dy = by - y, d = Math.hypot(dx, dy);
        if (d < 15 && kickGap == 0 && act == 0) {                  // the pet walks into the ball and kicks it
            double nx = d < 0.5 ? 1 : dx / d, ny = d < 0.5 ? 0 : dy / d;
            bvx = nx * 3.2 + (Math.random() - 0.5); bvy = ny * 1.6;
            kickGap = 20;
            onAct.accept(3);
        }
        bx += bvx; by += bvy;
        bvx *= 0.965; bvy *= 0.965;
        if (bx < 6) { bx = 6; bvx = -bvx * 0.7; } else if (bx > W - 6) { bx = W - 6; bvx = -bvx * 0.7; }
        if (by < Y_MIN + 6) { by = Y_MIN + 6; bvy = -bvy * 0.7; } else if (by > Y_MAX) { by = Y_MAX; bvy = -bvy * 0.7; }
        drops.removeIf(p -> { p[0] += p[2]; p[1] += p[3]; p[3] += 0.12; return --p[4] <= 0; });
    }

    private void drawBall(GuiGraphics g) {
        int cx = (int) Math.round(bx), cy = (int) Math.round(by);
        oval(g, cx, cy + 1, 4, 1, 0x44000000);
        disc(g, cx, cy - 3, 3, 0xFFFFFFFF);
        rect(g, cx - 1, cy - 4, 3, 2, 0xFFE5484D);
        rect(g, cx - 3, cy - 3, 1, 1, 0xFF3A2A3A);
    }

    // ---------- drawing ----------
    private void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(1 - (dy * dy) / (double) (ry * ry + 1)));
            rect(g, cx - dx, cy + dy, dx * 2 + 1, 1, argb);
        }
    }

    private void tree(GuiGraphics g, int cx, int base, int sz) {
        rect(g, cx - 3, base - sz, 6, sz, 0xFF8A5A3A);
        disc(g, cx, base - sz - 8, 15, 0xFF3FA55A);
        disc(g, cx - 9, base - sz - 2, 10, 0xFF4FB86A);
        disc(g, cx + 9, base - sz - 2, 10, 0xFF4FB86A);
        disc(g, cx - 4, base - sz - 12, 5, 0xFF7ADC8A);
    }

    /** 0 day, 1 dusk or dawn, 2 night, by the real clock. */
    private static int dayPart() {
        int h = java.time.LocalTime.now().getHour();
        return h >= 22 || h < 5 ? 2 : (h >= 19 || h < 7) ? 1 : 0;
    }

    private void scenery(GuiGraphics g) {
        int part = dayPart();
        g.fillGradient(0, 0, W, 66, part == 2 ? 0xFF121838 : part == 1 ? 0xFFFFA76A : 0xFF8FD3FF, part == 2 ? 0xFF2C3E78 : part == 1 ? 0xFFFFD9A0 : 0xFFDDF4FF);
        if (part == 2) {                                                   // a moon and twinkling stars
            disc(g, 262, 22, 10, 0xFFF4F1D8); disc(g, 266, 19, 9, 0xFF121838);
            for (int i = 0; i < 24; i++) if ((ticks / 20 + i) % 5 != 0) rect(g, (i * 67 + 11) % W, (i * 29) % 56 + 2, 1, 1, 0xFFFFFFFF);
        } else disc(g, 262, part == 1 ? 40 : 22, 11, part == 1 ? 0xFFFF8A4A : 0xFFFFE066);
        for (int i = 0; i < 3; i++) {                                      // clouds that drift
            int cx = (int) ((ticks * (0.12 + i * 0.05) + i * 110) % (W + 80)) - 40, cy = 14 + i * 12;
            disc(g, cx, cy, 6, 0xDDFFFFFF); disc(g, cx + 8, cy + 2, 7, 0xDDFFFFFF); disc(g, cx - 8, cy + 3, 5, 0xDDFFFFFF);
        }
        disc(g, 60, 78, 40, 0xFF7ACB7A); disc(g, 200, 84, 46, 0xFF6BC070);  // far hills
        g.fillGradient(0, 62, W, H, 0xFF86D68A, 0xFF4DB35E);
        for (int i = 0; i < 9; i++) rect(g, 0, 70 + i * 10, W, 4, 0x14FFFFFF);
        oval(g, 150, 138, 90, 8, 0x33C9A678);                              // a sandy path
        oval(g, 236, 128, 34, 10, 0xFF6FC7F0);                              // the pond
        oval(g, 236, 127, 30, 7, 0xFF9ADCF8);
        int r = (ticks / 18) % 4;
        rect(g, 226 + r * 3, 126, 6, 1, 0x88FFFFFF);
        tree(g, 24, 100, 28);
        tree(g, 282, 96, 24);
        for (int i = 0; i < 14; i++) {                                      // flowers
            int fx = (i * 83 + 17) % (W - 20) + 10, fy = 80 + (i * 47) % 66;
            rect(g, fx, fy, 2, 2, i % 3 == 0 ? 0xFFFFF3B0 : i % 3 == 1 ? 0xFFFF8FB8 : 0xFFFFFFFF);
        }
        decor(g);
        if (part == 2) g.fill(0, 0, W, BAR_Y, 0x66101840); else if (part == 1) g.fill(0, 0, W, BAR_Y, 0x22FF6A20);
        if (part == 2) {                                                   // fireflies
            for (int i = 0; i < 12; i++) {
                int fx = (int) (30 + (i * 73) % 250 + Math.sin(ticks / 40.0 + i) * 14), fy = (int) (84 + (i * 41) % 60 + Math.cos(ticks / 33.0 + i * 2) * 8);
                int a = 0x80 + (int) (Math.sin(ticks / 12.0 + i) * 0x60);
                rect(g, fx, fy, 2, 2, (a << 24) | 0xE8FF60); rect(g, fx - 1, fy - 1, 4, 4, ((a / 4) << 24) | 0xE8FF60);
            }
        } else if (part == 0) {                                            // butterflies
            for (int i = 0; i < 3; i++) {
                int bx = (int) (60 + i * 80 + Math.sin(ticks / 50.0 + i * 2) * 40), by = (int) (92 + i * 14 + Math.sin(ticks / 17.0 + i) * 9);
                int wing = (ticks / 6 + i) % 2;
                rect(g, bx - 2 - wing, by, 2 + wing, 2, 0xFFFF8FB8); rect(g, bx + 1, by, 2 + wing, 2, 0xFFFFC83A); rect(g, bx, by, 1, 3, 0xFF3A2A3A);
            }
        }
        treasure(g);
        // a bench
        rect(g, 118, 78, 36, 4, 0xFF8A5A3A); rect(g, 120, 82, 3, 8, 0xFF6A4228); rect(g, 149, 82, 3, 8, 0xFF6A4228);
        rect(g, 118, 72, 36, 3, 0xFF9A6A44);
    }

    /** What the OS updates added to the park (each update brings one thing; see Updates). */
    private void decor(GuiGraphics g) {
        if (Updates.has(0)) {                                              // a beehive in the left tree, with bees
            disc(g, 38, 62, 5, 0xFFF5B800);
            rect(g, 36, 62, 4, 3, 0xFF3A2A3A);
            for (int i = 0; i < 3; i++) {
                int bx = 38 + (int) Math.round(Math.cos(ticks / 10.0 + i * 2.1) * 12), by = 60 + (int) Math.round(Math.sin(ticks / 7.0 + i * 2.1) * 6);
                rect(g, bx, by, 3, 2, 0xFFFFC832);
                rect(g, bx + 1, by, 1, 2, 0xFF3A2A3A);
            }
        }
        if (Updates.has(1)) {                                              // a hot-air balloon drifts by
            int bx = (ticks / 5) % (W + 60) - 30, by = 26 + (int) Math.round(Math.sin(ticks / 40.0) * 3);
            disc(g, bx, by, 8, 0xFFE5484D);
            rect(g, bx - 8, by - 1, 17, 3, 0xFFFFFFFF);
            rect(g, bx - 3, by + 9, 7, 5, 0xFF8A5A3A);
            rect(g, bx - 4, by + 7, 1, 3, 0xFF6A4228); rect(g, bx + 4, by + 7, 1, 3, 0xFF6A4228);
        }
        if (Updates.has(2)) {                                              // a snowman by the pond, a few snowflakes
            disc(g, 200, 142, 6, 0xFFFFFFFF);
            disc(g, 200, 133, 4, 0xFFFFFFFF);
            rect(g, 198, 132, 1, 1, 0xFF3A2A3A); rect(g, 201, 132, 1, 1, 0xFF3A2A3A);
            rect(g, 199, 135, 3, 1, 0xFFE5484D);
            rect(g, 200, 133, 3, 1, 0xFFF59A3A);
            for (int i = 0; i < 12; i++) rect(g, (i * 53 + ticks / 4) % W, (i * 29 + ticks / 2) % 140, 1, 1, 0xCCFFFFFF);
        }
        if (Updates.has(3)) {                                              // the right tree blossoms and drops petals
            disc(g, 282, 66, 15, 0xFFF58FB8);
            disc(g, 273, 72, 10, 0xFFFFB6D2);
            disc(g, 291, 72, 10, 0xFFFFB6D2);
            for (int i = 0; i < 8; i++) rect(g, 260 + (i * 11 + ticks / 6) % 40, 70 + (i * 17 + ticks / 2) % 70, 2, 1, i % 2 == 0 ? 0xFFFFB6D2 : 0xFFFFFFFF);
        }
        if (Updates.has(4)) {                                              // sunset glow and a string of paper lanterns
            g.fillGradient(0, 0, W, 66, 0x55FF8A5C, 0x00FFB870);
            for (int i = 0; i < 8; i++) {
                int lx = 22 + i * 36, ly = 20 + (int) Math.round(Math.sin(i * 0.9) * 3) + (int) Math.round(Math.sin(ticks / 30.0 + i) * 1.5);
                rect(g, lx, 14, 1, ly - 14, 0xFF6A4228);
                rect(g, lx - 3, ly, 7, 8, 0xFFE5484D);
                rect(g, lx - 2, ly + 2, 5, 4, 0xFFFFE680);
            }
        }
    }

    // ---------- the daily treasure ----------
    private boolean treFound = Progress.count("park_tre_day") == (int) dev.cutemod.market.Deals.day();

    private static int treHash() {
        long d = dev.cutemod.market.Deals.day();
        int x = (int) (d * 0x9E3779B1L) ^ 0x5bd1e995;
        x ^= x >>> 15; x *= 0x2C1B3C6D; x ^= x >>> 12; x *= 0x297A2D39; x ^= x >>> 15;
        return x & 0x7fffffff;
    }

    private static int treX() { return 24 + treHash() % 250; }

    private static int treY() { return 90 + (treHash() / 251) % 52; }

    /** A twinkling spot on the grass: walk onto it to dig up something (once a day, the place changes every day). */
    private void treasure(GuiGraphics g) {
        if (treFound) return;
        int cx = treX(), cy = treY();
        int blink = (ticks / 8) % 4;
        rect(g, cx - 1, cy - 3, 2, 7, 0xFFFFE680); rect(g, cx - 3, cy - 1, 7, 2, 0xFFFFE680);
        if (blink < 2) { rect(g, cx - 5, cy, 1, 1, 0xFFFFFFFF); rect(g, cx + 5, cy, 1, 1, 0xFFFFFFFF); rect(g, cx, cy - 5, 1, 1, 0xFFFFFFFF); rect(g, cx, cy + 5, 1, 1, 0xFFFFFFFF); }
    }

    private void checkTreasure() {
        if (treFound || Math.hypot(x - treX(), y - treY()) > 12) return;
        treFound = true;
        Progress.setCount("park_tre_day", (int) dev.cutemod.market.Deals.day());
        int h = treHash();
        int coins = 8 + (h / 7) % 13;                                       // 8-20 coins
        Progress.earn(coins);
        if ((h / 3) % 4 == 0) { Progress.setCount("stock_treat_fish", Progress.stock("treat_fish") + 1); say(t("cutemod.park.treasure_fish", coins)); }
        else say(t("cutemod.park.treasure", coins));
        for (int i = 0; i < 8; i++) hearts.add(new double[]{x - 14 + i * 4, y - 30, -0.5 - (i % 3) * 0.2, 60});
    }

    void render(GuiGraphics g, int mx, int my) {
        lastRender = ticks;
        Font f = net.minecraft.client.Minecraft.getInstance().font;
        scenery(g);
        if (noPet) {
            rect(g, 30, 58, W - 60, 40, 0xE0201828);
            note2(g, f, t("cutemod.park.nopet"), W / 2, 74, W - 76, 0xFFFFFFFF);
            drawBack(g, f, mx, my);
            return;
        }
        ParkSyncPayload s = Park.last();
        // everybody sorted by their feet: the ones lower on the screen are in front
        record Ent(double y, ParkSyncPayload.Pet pet, boolean ball) {}
        List<Ent> list = new ArrayList<>();
        list.add(new Ent(y, null, false));
        String hover = "";
        if (s != null) for (ParkSyncPayload.Pet p : s.pets()) {
            double[] q = pos.get(p.owner());
            if (q == null) continue;
            list.add(new Ent(q[1], p, false));
            if (Math.abs(mx - q[0]) < 18 && my > q[1] - 40 && my < q[1] + 4) hover = p.owner();
        }
        list.add(new Ent(by, null, true));                                // the ball stands among the pets by its feet
        list.sort((a, b) -> Double.compare(a.y(), b.y()));
        for (Ent e : list) {
            if (e.ball()) { drawBall(g); continue; }
            if (e.pet() == null) drawPet(g, f, x, y, myColor, null, true, myEmote == 4, 0, "", "");
            else {
                double[] q = pos.get(e.pet().owner());
                drawPet(g, f, q[0], q[1], e.pet().color(), e.pet().look(), false, e.pet().playing() || e.pet().emote() == 4, ParkData.level(e.pet().plays()),
                        e.pet().name(), hover.equals(e.pet().owner()) ? e.pet().owner() : "");
                emote(g, f, q[0], q[1], e.pet().emote());
            }
        }
        emote(g, f, x, y, myEmote);
        for (double[] d : drops) rect(g, (int) d[0], (int) d[1], 2, 2, 0xCC8FD3FF);
        for (double[] h : hearts) PetShow.heart(g, (int) h[0] - 3, (int) h[1], 0xFFFF5C93);
        drawHud(g, f, mx, my, s, hover);
    }

    private void drawPet(GuiGraphics g, Font f, double px, double py, String color, dev.cutemod.net.PetLook look,
                         boolean mine, boolean playing, int friend, String name, String hovered) {
        int stage = look == null ? stageOfMine() : look.stage();
        String head = look == null ? Progress.equipped() : look.head();
        String body = look == null ? Progress.equippedBody() : look.body();
        float sc = SCALE * PetArt.scaleOf(stage);
        int cx = (int) Math.round(px), fl = (int) Math.round(py);
        boolean walking = mine && Math.hypot(tx - x, ty - y) > 2;
        int hop = playing ? (int) Math.round(Math.abs(Math.sin(ticks / 5.0)) * 8) : walking ? (int) Math.round(Math.abs(Math.sin(ticks / 4.0)) * 3) : 0;
        if (mine && act == 1) hop = -5;                                       // sitting on the bench
        else if (mine && act == 2) hop = (int) Math.round(Math.abs(Math.sin(ticks / 6.0)) * 3);   // splashing
        oval(g, cx, fl + 1, (int) (20 * sc) + 2, 2, 0x44000000);
        if (!hovered.isEmpty()) oval(g, cx, fl + 1, (int) (22 * sc) + 6, 3, 0x88FFFFFF);
        g.pose().pushPose();
        g.pose().translate(cx, fl, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-cx, -fl, 0);
        PetArt.draw(g, PetShow.colorOf(color), cx, fl - 28 - (int) (hop / sc), playing || !hovered.isEmpty() ? 2 : 1, ticks + (mine ? 0 : name.length() * 13),
                false, false, stage, head == null ? "" : head, body == null ? "" : body);
        g.pose().popPose();
        String label = mine ? t("cutemod.park.you") : name;
        String own = mine ? PetName.custom(myColor) : look == null ? "" : look.name();
        int top = fl - (int) (50 * sc) - 10;
        if (own.isEmpty()) {
            CuteFont.draw(g, f, label, keepIn(cx - f.width(label) / 2, f.width(label)), fl + 3, mine ? 0xFFFFE680 : 0xFFFFFFFF, true);
        } else {                                                              // the pet's own name, the player below it in small type
            CuteFont.draw(g, f, own, keepIn(cx - f.width(own) / 2, f.width(own)), fl + 3, mine ? 0xFFFFE680 : 0xFFFFFFFF, true);
            int sw = (int) (f.width(label) * 0.75F);
            g.pose().pushPose();
            g.pose().translate(keepIn(cx - sw / 2, sw) + sw / 2, fl + 12, 0);
            g.pose().scale(0.75F, 0.75F, 1F);
            CuteFont.draw(g, f, label, -f.width(label) / 2, 0, mine ? 0xFFFFE9B0 : 0xFFD8CCE8, true);
            g.pose().popPose();
        }
        for (int i = 0; i < friend; i++) PetShow.heart(g, cx - friend * 5 + i * 10 + 1, top - 8, 0xFFFF5C93);
    }

    private int stageOfMine() {
        PetBlob.Info i = PetBlob.parse(Store.read("pet_" + myColor));
        return i == null ? 2 : i.stage();
    }

    private void emote(GuiGraphics g, Font f, double px, double py, int e) {
        if (e <= 0) return;
        int cx = (int) Math.round(px), by = (int) Math.round(py) - 62;
        rect(g, cx - 12, by, 24, 12, 0xFFFFFFFF);
        rect(g, cx - 2, by + 12, 4, 3, 0xFFFFFFFF);
        switch (e) {
            case 1 -> PetShow.heart(g, cx - 3, by + 3, 0xFFFF5C93);
            case 2 -> CuteFont.draw(g, f, "Hi!", cx - f.width("Hi!") / 2, by + 2, 0xFF3A2A3A, false);
            case 4 -> note(g, cx - 3, by + 2);
            case 5 -> CuteFont.draw(g, f, "Ha!", cx - f.width("Ha!") / 2, by + 2, 0xFFE59A1A, false);
            case 6 -> CuteFont.draw(g, f, "Zz", cx - f.width("Zz") / 2, by + 2, 0xFF5A7AC8, false);
            default -> CuteFont.draw(g, f, "!", cx - f.width("!") / 2, by + 2, 0xFFE5484D, false);
        }
    }

    private static void note(GuiGraphics g, int x, int y) {
        rect(g, x + 4, y, 1, 7, 0xFF3A2A3A); rect(g, x + 4, y, 3, 1, 0xFF3A2A3A); rect(g, x + 1, y + 6, 4, 3, 0xFF3A2A3A);
    }

    /** The width of the "< Back" button: at least 44, wider when the translation needs it. */
    static int backW(Font f) { return Math.max(44, f.width("< " + t("cutemod.park.back")) + 10); }

    private void drawBack(GuiGraphics g, Font f, int mx, int my) {
        int bw = backW(f);
        boolean hov = App.in(mx, my, 3, 3, bw, 12);
        rect(g, 3, 3, bw, 12, hov ? 0xFFFFFFFF : 0xE0F6F0FA);
        CuteFont.draw(g, f, "< " + t("cutemod.park.back"), 7, 5, 0xFF3A2A3A, false);
    }

    /** A short centred message that wraps onto up to two lines inside w pixels: a long translation never leaves its box. */
    private static void note2(GuiGraphics g, Font f, String s, int cx, int y, int w, int argb) {
        List<FormattedCharSequence> lines = f.split(FormattedText.of(s), w);
        int n = Math.min(2, lines.size());
        int y0 = n == 1 ? y : y - 5;
        for (int i = 0; i < n; i++) CuteFont.draw(g, f, lines.get(i), cx - f.width(lines.get(i)) / 2, y0 + i * 10, argb, true);
    }

    /** Keeps a label of width w inside the screen. */
    private static int keepIn(int x, int w) { return Math.max(2, Math.min(W - 2 - w, x)); }

    private void drawHud(GuiGraphics g, Font f, int mx, int my, ParkSyncPayload s, String hover) {
        drawBack(g, f, mx, my);
        String title = t("cutemod.park.title");
        String count = t("cutemod.park.count", (s == null ? 0 : s.pets().size()) + 1);
        int cw = f.width(count), t1 = backW(f) + 8, t2 = W - 6 - cw - 6;
        Fit.boxC(g, f, title, t1, 5, 0xFFFFFFFF, true, Math.max(24, t2 - t1));        // the title never runs into the button or the counter
        CuteFont.draw(g, f, count, W - 6 - cw, 5, 0xFFFFFFFF, true);
        rect(g, 0, BAR_Y, W, H - BAR_Y, 0xCC201828);
        for (int i = 0; i < EMOTE_X.length; i++) {
            boolean hov = App.in(mx, my, EMOTE_X[i], BAR_Y + 2, 24, 12);
            rect(g, EMOTE_X[i], BAR_Y + 2, 24, 12, hov ? 0xFFFFFFFF : 0xFFE4D8FF);
            switch (i) {
                case 0 -> PetShow.heart(g, EMOTE_X[i] + 9, BAR_Y + 5, 0xFFFF5C93);
                case 1 -> CuteFont.draw(g, f, "Hi", EMOTE_X[i] + 12 - f.width("Hi") / 2, BAR_Y + 4, 0xFF3A2A3A, false);
                case 3 -> note(g, EMOTE_X[i] + 9, BAR_Y + 3);
                case 4 -> CuteFont.draw(g, f, "Ha", EMOTE_X[i] + 12 - f.width("Ha") / 2, BAR_Y + 4, 0xFFE59A1A, false);
                case 5 -> CuteFont.draw(g, f, "Zz", EMOTE_X[i] + 12 - f.width("Zz") / 2, BAR_Y + 4, 0xFF5A7AC8, false);
                default -> CuteFont.draw(g, f, "!", EMOTE_X[i] + 12 - f.width("!") / 2, BAR_Y + 4, 0xFFE5484D, false);
            }
        }
        int cyc = (ticks / 300) % 3;
        String line = toastT > 0 ? toast : !hover.isEmpty() ? t("cutemod.park.click_play")
                : (!treFound && cyc == 1) ? t("cutemod.park.treasure_hint") : cyc == 2 ? t("cutemod.park.spots_hint") : t("cutemod.park.hint");
        Fit.para(g, f, line, 166, BAR_Y + 3, W - 3 - 166, H - BAR_Y - 4, 8, toastT > 0 ? 0xFFFFE680 : 0xFFE4D8FF, false);   // two small lines when it is long
    }

    // ---------- input ----------
    boolean click(int mx, int my) {
        if (App.in(mx, my, 3, 3, backW(net.minecraft.client.Minecraft.getInstance().font), 12)) { leave(); return true; }
        if (noPet) return true;
        for (int i = 0; i < EMOTE_X.length; i++) {
            if (App.in(mx, my, EMOTE_X[i], BAR_Y + 2, 24, 12)) { emoteOut = i + 1; myEmote = i + 1; myEmoteT = 180; return true; }
        }
        if (my >= BAR_Y) return true;
        ParkSyncPayload s = Park.last();
        if (s != null) for (ParkSyncPayload.Pet p : s.pets()) {
            double[] q = pos.get(p.owner());
            if (q != null && Math.abs(mx - q[0]) < 18 && my > q[1] - 40 && my < q[1] + 4) { chase = p.owner(); chaseGap = 0; return true; }
        }
        if (App.in(mx, my, 114, 68, 44, 24)) { chase = ""; want = 1; tx = BENCH_X; ty = BENCH_Y; return true; }                 // the bench: sit down
        if (App.in(mx, my, POND_X - 36, POND_Y - 26, 72, 22)) { chase = ""; want = 2; tx = POND_X; ty = POND_Y; return true; }   // the pond: splash
        want = 0;
        chase = "";
        tx = Math.max(8, Math.min(W - 8, mx));
        ty = Math.max(Y_MIN, Math.min(Y_MAX, my + 24));          // the click is where the pet's body is, its feet are lower
        return true;
    }

    boolean key(int keyCode) {
        if (keyCode == 256) { leave(); return true; }            // escape: back to the room, not out of the computer
        return false;
    }

    void close() { Park.leave(); }
}
