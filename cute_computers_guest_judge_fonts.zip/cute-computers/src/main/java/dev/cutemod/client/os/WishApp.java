package dev.cutemod.client.os;

import dev.cutemod.data.PetWear;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Wishlist: choose up to 5 outfits of the shop that you want. For each one you see how many coins are still missing,
 * and a Buy button appears when you have enough. Saved as "wishlist" (the ids). Bought outfits leave the list.
 */
public class WishApp extends KitApp {
    private static final int MAX = 5, ROWS = 8, ROW_H = 13, LX = 6, LY = 36, LW = 130, RX = 144;

    private final List<String> wish = new ArrayList<>();
    private final List<PetWear.Item> shop = new ArrayList<>();
    private int scroll;
    private boolean loaded;

    @Override protected int accent() { return 0xFFE0709A; }

    @Override protected String id() { return "wishlist"; }

    @Override
    public void attach(Shell shell) { super.attach(shell); load(); }

    private static int cost(PetWear.Item it) { return dev.cutemod.market.Deals.price(it.id(), it.price()); }

    private void load() {
        loaded = true;
        wish.clear();
        String s = Store.read("wishlist");
        if (s != null) for (String id : s.split(",")) if (PetWear.get(id) != null && !wish.contains(id) && wish.size() < MAX) wish.add(id);
        refresh();
    }

    private void refresh() {
        shop.clear();
        for (PetWear.Item it : PetWear.ALL)
            if (it.src() == PetWear.Src.SHOP && !it.legacy() && it.price() > 0 && !Progress.owned(it.id())) shop.add(it);
        wish.removeIf(Progress::owned);
        scroll = Math.max(0, Math.min(scroll, Math.max(0, shop.size() - ROWS)));
    }

    private void save() { Store.write("wishlist", String.join(",", wish)); }

    @Override
    public void tick() {
        super.tick();
        if (ticks % 120 == 0) refresh();
    }

    private static String name(String id) { return t("cutemod.shop.item." + id); }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        header(g, f);
        String purse = t("cutemod.bank.purse", Progress.coins());
        CuteFont.draw(g, f, purse, W - 6 - f.width(purse), 3, 0xFFFFFFFF, false);
        CuteFont.draw(g, f, t("cutemod.wish.shop"), LX, 20, MUTED, false);
        CuteFont.draw(g, f, t("cutemod.wish.mine", wish.size(), MAX), RX, 20, MUTED, false);
        // the shop list
        rect(g, LX, LY - 2, LW, ROWS * ROW_H + 4, 0xFFF6F0FA);
        for (int r = 0; r < ROWS && scroll + r < shop.size(); r++) {
            PetWear.Item it = shop.get(scroll + r);
            int y = LY + r * ROW_H;
            boolean on = wish.contains(it.id()), hov = in(mx, my, LX, y, LW, ROW_H);
            if (hov || on) rect(g, LX + 1, y, LW - 2, ROW_H - 1, on ? 0xFFFFE0EC : 0xFFFFFFFF);
            star(g, LX + 6, y + 6, on);
            CuteFont.draw(g, f, f.plainSubstrByWidth(name(it.id()), LW - 46), LX + 14, y + 2, TEXT, false);
            String pr = Integer.toString(cost(it));
            CuteFont.draw(g, f, pr, LX + LW - 4 - f.width(pr), y + 2, MUTED, false);
        }
        if (shop.isEmpty()) CuteFont.draw(g, f, t("cutemod.wish.none"), LX + 6, LY + 4, MUTED, false);
        // my wishes
        if (wish.isEmpty()) CuteFont.draw(g, f, f.plainSubstrByWidth(t("cutemod.wish.empty"), W - RX - 6), RX, 36, MUTED, false);
        for (int i = 0; i < wish.size(); i++) {
            PetWear.Item it = PetWear.get(wish.get(i));
            int y = 32 + i * 21, c = cost(it), have = Progress.coins();
            boolean can = have >= c;
            rect(g, RX, y, W - RX - 6, 19, 0xFFFFF3F8);
            CuteFont.draw(g, f, f.plainSubstrByWidth(name(it.id()), 90), RX + 3, y + 2, TEXT, false);
            rect(g, RX + 3, y + 13, 96, 4, 0xFFEBDDF7);
            rect(g, RX + 3, y + 13, (int) (96 * Math.min(1F, have / (float) c)), 4, can ? 0xFF5BBF6A : accent());
            String need = can ? t("cutemod.wish.enough") : t("cutemod.wish.need", c - have);
            CuteFont.draw(g, f, f.plainSubstrByWidth(need, 52), RX + 103, y + 2, can ? 0xFF3E9A4A : MUTED, false);
            btn(g, f, mx, my, W - 6 - 40, y + 8, 40, t("cutemod.wish.buy"), can ? 1 : 2);
        }
        footer(g, f);
    }

    private static void star(GuiGraphics g, int cx, int cy, boolean on) {
        int c = on ? 0xFFF0B020 : 0xFFD0C4DC;
        rect(g, cx - 3, cy - 3, 6, 6, c); rect(g, cx - 5, cy - 1, 10, 2, c); rect(g, cx - 1, cy - 5, 2, 10, c);
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int r = 0; r < ROWS && scroll + r < shop.size(); r++) {
            if (!in(x, y, LX, LY + r * ROW_H, LW, ROW_H)) continue;
            String id = shop.get(scroll + r).id();
            if (wish.remove(id)) save();
            else if (wish.size() >= MAX) say("cutemod.wish.msg.full", MAX);
            else { wish.add(id); save(); }
            return true;
        }
        for (int i = 0; i < wish.size(); i++) {
            int by = 32 + i * 21 + 8;
            if (!in(x, y, W - 6 - 40, by, 40, 16)) continue;
            PetWear.Item it = PetWear.get(wish.get(i));
            if (Progress.buy(it.id(), cost(it))) {
                Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.6F);
                say("cutemod.wish.msg.bought", name(it.id()));
                wish.remove(i);
                save();
                refresh();
            } else say("cutemod.wish.msg.nocoins");
            return true;
        }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        scroll = Math.max(0, Math.min(Math.max(0, shop.size() - ROWS), scroll + (amount > 0 ? -1 : 1)));
        return true;
    }
}
