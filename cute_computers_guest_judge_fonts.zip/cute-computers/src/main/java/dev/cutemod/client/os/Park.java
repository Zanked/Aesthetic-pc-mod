package dev.cutemod.client.os;

import dev.cutemod.data.ParkData;
import dev.cutemod.net.ParkActionPayload;
import dev.cutemod.net.ParkMovePayload;
import dev.cutemod.net.ParkSyncPayload;
import dev.cutemod.net.PetLook;
import net.neoforged.neoforge.network.PacketDistributor;

/** The Pet Park on the client: sends where our pet stands, keeps the last answer and the news ("we played"). */
public final class Park {
    private Park() {}

    private static ParkSyncPayload last;
    private static boolean played, full;
    private static String with = "";
    private static int plays;

    public static void apply(ParkSyncPayload p) {
        last = p;
        if (p.event() == 2) full = true;
        if (p.prize() > 0) Progress.earn(p.prize());
        if (p.event() == 1) {
            played = true;
            with = p.with();
            plays = p.plays();
            int lvl = ParkData.level(plays);
            if (lvl >= 2 && plays == ParkData.LEVEL_AT[lvl - 1]) Progress.toast("cutemod.park.friend." + lvl, with);
        }
    }

    public static ParkSyncPayload last() { return last; }

    /** True once after we played with somebody. */
    public static boolean takePlayed() { boolean r = played; played = false; return r; }

    public static boolean takeFull() { boolean r = full; full = false; return r; }

    public static String with() { return with; }

    public static int plays() { return plays; }

    public static void clear() { last = null; played = false; full = false; }

    /** Tell the server where the pet of this color stands. False if there is no such pet. */
    public static boolean move(String colorId, int x, int y, int emote) {
        PetBlob.Info i = PetBlob.parse(Store.read("pet_" + colorId));
        if (i == null) return false;
        PacketDistributor.sendToServer(new ParkMovePayload(colorId, i.sick(),
                new PetLook(i.stage(), i.trait(), i.ageMin(), s24(Progress.equipped()), s24(Progress.equippedBody()), PetName.custom(colorId)), x, y, emote));
        return true;
    }

    public static void leave() {
        PacketDistributor.sendToServer(new ParkActionPayload(""));
        last = null;
    }

    public static void play(String ownerId) { PacketDistributor.sendToServer(new ParkActionPayload(ownerId)); }

    private static String s24(String s) { return s == null || s.length() > 64 ? "" : s; }
}
