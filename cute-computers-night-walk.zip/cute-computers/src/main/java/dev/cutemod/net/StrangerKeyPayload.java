package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.item.ModItems;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: "the Stranger's phrase was said in the Terminal" (the end of the big easter egg).
 * The server gives the real item Stranger's Key, once per player (a flag in the player's own data).
 */
public record StrangerKeyPayload() implements CustomPacketPayload {
    public static final Type<StrangerKeyPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "stranger_key"));

    public static final StreamCodec<RegistryFriendlyByteBuf, StrangerKeyPayload> STREAM_CODEC =
            StreamCodec.unit(new StrangerKeyPayload());

    private static final String FLAG = "cutemod_stranger_key";

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(StrangerKeyPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer sp)) return;
            var data = sp.getPersistentData();
            if (data.getBoolean(FLAG)) return;                      // already given
            data.putBoolean(FLAG, true);
            ItemStack stack = new ItemStack(ModItems.STRANGER_KEY.get());
            sp.getInventory().add(stack);
            if (!stack.isEmpty()) sp.drop(stack, false);            // inventory full: it lands at the player's feet
            sp.displayClientMessage(Component.translatable("cutemod.key.given"), true);
        });
    }
}
