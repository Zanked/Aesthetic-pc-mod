package dev.cutemod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * Stranger's Key: the prize of the big easter egg (the Traces of the Stranger). It always glows. Right-click starts
 * "the night walk" for 45 seconds: night vision, slow falling and a high jump, and a trail of little stars behind the
 * player while the key is in a hand. It rests for a minute after that.
 */
public class StrangerKeyItem extends Item {
    private static final int WALK_TICKS = 900, REST_TICKS = 1200;
    private static final String TRAIL = "cutemod_night_walk";

    public StrangerKeyItem(Properties props) { super(props); }

    @Override
    public boolean isFoil(ItemStack stack) { return true; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            for (int i = 0; i < 8; i++) {
                double a = level.random.nextDouble() * Math.PI * 2;
                level.addParticle(ParticleTypes.END_ROD, player.getX() + Math.cos(a) * 0.6, player.getY() + 1.0 + level.random.nextDouble() * 0.8,
                        player.getZ() + Math.sin(a) * 0.6, 0, 0.03 + level.random.nextDouble() * 0.03, 0);
            }
        } else {
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0F, 1.2F);
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, WALK_TICKS, 0, true, false));
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, WALK_TICKS, 0, true, false));
            player.addEffect(new MobEffectInstance(MobEffects.JUMP, WALK_TICKS, 1, true, false));
            player.getPersistentData().putLong(TRAIL, level.getGameTime() + WALK_TICKS);
            player.displayClientMessage(Component.translatable("cutemod.key.walk"), true);
        }
        player.getCooldowns().addCooldown(this, REST_TICKS);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** While the night walk lasts and the key is in a hand, little stars fall behind the player. */
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (!(level instanceof ServerLevel sl) || !(entity instanceof ServerPlayer sp) || level.getGameTime() % 3 != 0) return;
        if (!selected && sp.getOffhandItem() != stack) return;
        if (sp.getPersistentData().getLong(TRAIL) <= level.getGameTime()) return;
        sl.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 0.1, sp.getZ(), 2, 0.25, 0.05, 0.25, 0.01);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("cutemod.tip.key.1").withStyle(ChatFormatting.LIGHT_PURPLE));
        tip.add(Component.translatable("cutemod.tip.key.2").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        tip.add(Component.translatable("cutemod.tip.key.3").withStyle(ChatFormatting.GOLD));
        tip.add(Component.translatable("cutemod.tip.key.4").withStyle(ChatFormatting.DARK_GRAY));
    }
}
