package dev.cutemod.client.os;

import dev.cutemod.data.PetWear;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/**
 * The "Home" tab of CuteMarket: wallpapers, pet accessories, music albums and treats, bought with coins and used
 * at once (no cart, no courier). They used to live in the Shop app, which is gone.
 */
final class HomeGoods {
    private record Item(String id, int price) {}

    private static final Item[] ITEMS = build();

    /** The shop list: wallpapers, the desktop theme, every pet outfit of PetWear, songs and treats. */
    private static Item[] build() {
        List<Item> l = new ArrayList<>(List.of(
            new Item("wall6", 40), new Item("wall7", 40), new Item("wall8", 60),
            new Item("wall9", 50), new Item("wall10", 50), new Item("wall11", 70),
            new Item("wall13", 60), new Item("wall14", 70), new Item("wall15", 70),
            new Item("wall16", 70), new Item("wall17", 60), new Item("wall18", 60),
            new Item("wall19", 50), new Item("wall20", 50), new Item("wall21", 60),
            new Item("wall22", 70), new Item("wall23", 70), new Item("wall24", 70), new Item("wall25", 70),
            new Item("wall26", 15), new Item("wall27", 15), new Item("wall28", 20), new Item("wall29", 25),   // the cheap ones
            new Item("wall30", 90), new Item("wall31", 90), new Item("wall32", 80), new Item("wall33", 80), new Item("wall34", 90),   // animated
            new Item("wall35", 80), new Item("wall36", 90), new Item("wall37", 90), new Item("wall38", 80), new Item("wall39", 90), new Item("wall40", 80),
            new Item("wall41", 90), new Item("wall42", 80), new Item("wall43", 80), new Item("wall44", 80),
            new Item("wall45", 80), new Item("wall46", 85), new Item("wall47", 80),   // golden autumn, dark blue forest, rain on a window
            new Item(Theme.AERO_ID, Theme.AERO_PRICE), new Item(Theme.KAWAII_ID, Theme.KAWAII_PRICE), new Item(Theme.RETRO_ID, Theme.RETRO_PRICE), new Item(Theme.ANIME_ID, Theme.ANIME_PRICE), new Item(Theme.BLOOD_ID, Theme.BLOOD_PRICE), new Item(Theme.STRANGER_ID, 0)));   // the last ones: the looks of the whole desktop
        for (PetWear.Item w : PetWear.ALL) l.add(new Item(w.id(), w.price()));
        l.addAll(List.of(
            new Item("treat_berry", 3), new Item("treat_lolly", 4), new Item("treat_cookie", 5), new Item("treat_fish", 8), new Item("treat_honey", 12),
            new Item("treat_milk", 10), new Item("treat_cake", 20), new Item("treat_medicine", 25)));
        return l.toArray(new Item[0]);
    }
    private static final String[] TAB_KINDS = {"", "wall", "acc", "track", "treat"};
    private static final int CHIP_X = 4, CHIP_Y = 26, CHIP_W = 58, CHIP_H = 12;
    private static final int TOP = 41, ROW = 24, VISIBLE = 5, BTN_W = 78;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;

    private int tab, scroll;

    /** s cut with "..." to at most maxW pixels (the text keeps its size, it never runs under the price or the button). */
    private static String cut(Font f, String s, int maxW) {
        if (maxW <= 0) return "";
        if (f.width(s) <= maxW) return s;
        String dots = "...";
        return f.plainSubstrByWidth(s, Math.max(0, maxW - f.width(dots))) + dots;
    }

    /** The price today: the daily sales of CuteMarket apply here too (albums are always sold at their own price). */
    private static int cost(Item it) { return isAlbum(it.id()) ? it.price() : dev.cutemod.market.Deals.price(it.id(), it.price()); }

    private static boolean isAlbum(String id) { return id.startsWith("album_"); }

    private static boolean alb0(Item it) { return !isAlbum(it.id()); }

    /** The album behind an item id ("album_" + the id of the album), or null. */
    private static Albums.Album albumOf(String id) {
        if (isAlbum(id)) for (Albums.Album a : Albums.all()) if (a.ownKey().equals(id)) return a;
        return null;
    }

    private static String kind(String id) {
        return isAlbum(id) ? "album" : id.startsWith("treat") ? "treat" : id.startsWith("wall") ? "wall" : id.startsWith("theme") ? "theme" : id.startsWith("acc") ? "acc" : "track";
    }

    /** The items of the selected chip. */
    private List<Item> view() {
        List<Item> out = new ArrayList<>();
        for (Item it : ITEMS) {
            String k = kind(it.id());
            if (it.id().equals(Theme.STRANGER_ID) && !Progress.owned(Theme.STRANGER_ID)) continue;   // the prize of the Traces: only when it is won
            if (it.id().equals(Theme.BLOOD_ID) && !Theme.bloodUnlocked()) continue;   // a secret: it shows up after the video 666
            if (tab == 3) continue;                                                                       // tab 3 = Music: only the albums (below)
            if (tab == 0 || k.equals(TAB_KINDS[tab]) || (tab == 1 && k.equals("theme"))) out.add(it);   // tab 1 = Style: wallpapers and themes
        }
        if (tab == 0 || tab == 3) {                                          // the albums of the music player (the free ones are in the library from the start)
            for (Albums.Album a : Albums.all()) if (a.price() > 0) out.add(new Item(a.ownKey(), a.price()));
        }
        return out;
    }

    private int maxScroll() { return Math.max(0, view().size() - VISIBLE); }

    /** Today as month * 100 + day (for the seasonal outfits). */
    private static int today() {
        java.time.LocalDate d = java.time.LocalDate.now();
        return d.getMonthValue() * 100 + d.getDayOfMonth();
    }

    /** The grey line under the name: what it does, how to get it, or which set it belongs to. */
    private static String subline(Item it, boolean treat) {
        if (treat) return App.t("cutemod.shop.eff." + it.id());
        PetWear.Item w = kind(it.id()).equals("acc") ? PetWear.get(it.id()) : null;
        if (w != null && !Progress.owned(it.id()) && !w.legacy() && w.src() != PetWear.Src.SHOP) return App.t("cutemod.shop.how." + it.id());
        if (w != null && !w.set().isEmpty()) return App.t("cutemod.shop.setline", App.t("cutemod.shop.set." + w.set()));
        return App.t("cutemod.shop.kind." + kind(it.id()));
    }

    /** Text of the button for this item. */
    private static String action(Item it) {
        boolean own = Progress.owned(it.id());
        switch (kind(it.id())) {
            case "wall" -> {
                if (!own) return "buy";
                return Wallpaper.get() == Integer.parseInt(it.id().substring(4)) ? "using" : "set";
            }
            case "acc" -> {
                if (!own) {
                    PetWear.Item w = PetWear.get(it.id());
                    if (w == null) return "buy";
                    return switch (w.src()) {
                        case SHOP -> "buy";
                        case SEASON -> PetWear.onSale(w, today()) ? "buy" : "season";
                        case STORY -> "story";
                        case SHOW -> "show";
                        case COUNT -> "play";
                    };
                }
                return Progress.wearing(it.id()) ? "take_off" : "wear";
            }
            case "theme" -> {
                if (!own) return "buy";
                return Theme.active(it.id()) ? "theme_off" : "theme_on";
            }
            case "treat" -> { return "buy"; } // consumable: you can buy as many as you like
            default -> { return own ? "have" : "buy"; }
        }
    }

    void render(GuiGraphics g, int mx, int my, int bodyColor, int ox, int oy) {
        Font f = App.font();
        for (int i = 0; i < 5; i++) {
            int cx = CHIP_X + i * CHIP_W;
            boolean sel = i == tab;
            App.roundRect(g, cx, CHIP_Y, CHIP_W - 2, CHIP_H, 5, sel ? ACCENT : (App.in(mx, my, cx, CHIP_Y, CHIP_W - 1, CHIP_H) ? 0xFFEAD6F5 : 0xFFF1E4F7));
            String s = cut(f, App.t("cutemod.shop.tab." + i), CHIP_W - 8);
            Skin.str(g, f, s, cx + (CHIP_W - 2 - f.width(s)) / 2, CHIP_Y + 2, sel ? 0xFFFFFFFF : TEXT, false);
        }
        List<Item> items = view();
        scroll = Math.min(scroll, maxScroll());
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= items.size()) break;
            Item it = items.get(idx);
            int y = TOP + v * ROW;
            App.roundRect(g, 4, y, App.W - 10, ROW - 2, 5, v % 2 == 0 ? 0xFFFFFFFF : 0xFFFFEFF7);
            icon(g, it.id(), 6, y + 2, bodyColor, ox, oy);
            boolean treat = kind(it.id()).equals("treat");
            boolean priced = it.price() > 0 && (treat || !Progress.owned(it.id()));
            // how far the texts may go to the right: not under the price, the sale tag or the button
            int limit = App.W - BTN_W - 8 - 6, limit2 = limit;
            String p = priced ? Integer.toString(cost(it)) : "";
            int px = App.W - BTN_W - 16 - f.width(p);
            int deal = priced && alb0(it) ? dev.cutemod.market.Deals.percent(it.id()) : 0;
            String d = deal > 0 ? "-" + deal + "%" : "";
            if (priced) {
                limit = px - 10 - 5;
                limit2 = deal > 0 ? Math.min(limit, App.W - BTN_W - 12 - f.width(d) - 4 - 5) : limit;
            }
            Albums.Album alb = albumOf(it.id());
            String name = alb != null ? alb.title() : App.t("cutemod.shop.item." + it.id());
            String sub = alb != null ? (alb.artist().isEmpty() ? "" : alb.artist() + "  -  ") + App.t("cutemod.store.songs", alb.tracks().size()) : subline(it, treat);
            if (kind(it.id()).equals("track")) {                    // "Song: Name (how it sounds)": the name on top, the sound on the grey line
                int open = name.indexOf(" (");
                if (open > 0 && name.endsWith(")")) {
                    sub = name.substring(open + 2, name.length() - 1);
                    name = name.substring(0, open);
                }
                int colon = name.indexOf(": ");
                if (colon > 0 && colon < 14) name = name.substring(colon + 2);   // the tab and the grey line already say it is a song
            }
            String stock = treat && Progress.stock(it.id()) > 0 ? "x" + Progress.stock(it.id()) : "";
            String shown = cut(f, name, limit - 32 - (stock.isEmpty() ? 0 : f.width(stock) + 4));
            Skin.str(g, f, shown, 32, y + 4, TEXT, false);
            if (!stock.isEmpty()) Skin.str(g, f, stock, 32 + f.width(shown) + 4, y + 4, 0xFFB98A10, false);
            Skin.str(g, f, cut(f, sub, limit2 - 32), 32, y + 14, MUTED, false);
            if (priced) {
                Progress.drawCoin(g, px - 10, y + 8);
                Skin.str(g, f, p, px, y + 8, Progress.coins() >= cost(it) ? TEXT : 0xFFE5484D, false);
                if (deal > 0) {                                        // on sale today
                    Skin.rect(g, App.W - BTN_W - 12 - f.width(d) - 4, y + 15, f.width(d) + 4, 9, 0xFFE5484D);
                    Skin.str(g, f, d, App.W - BTN_W - 10 - f.width(d) - 4, y + 15, 0xFFFFFFFF, false);
                }
            }
            String a = action(it);
            boolean can = !(a.equals("using") || a.equals("have") || a.equals("story") || a.equals("show") || a.equals("play") || a.equals("season") || (a.equals("buy") && Progress.coins() < cost(it)));
            boolean hover = can && App.in(mx, my, App.W - BTN_W - 8, y + 3, BTN_W, 17);
            App.roundRect(g, App.W - BTN_W - 8, y + 3, BTN_W, 17, 5, !can ? 0xFFD8CCE2 : hover ? 0xFF8A6AC6 : ACCENT);
            String label = cut(f, App.t("cutemod.shop.btn." + a), BTN_W - 6);
            Skin.str(g, f, label, App.W - BTN_W - 8 + (BTN_W - f.width(label)) / 2, y + 8, can ? 0xFFFFFFFF : MUTED, false);
        }
        if (maxScroll() > 0) { // scroll bar
            App.rect(g, App.W - 3, TOP, 3, VISIBLE * ROW, 0xFFE9DDF2);
            int th = Math.max(8, VISIBLE * ROW * VISIBLE / items.size());
            App.rect(g, App.W - 3, TOP + (VISIBLE * ROW - th) * scroll / maxScroll(), 3, th, ACCENT);
        }
    }

    /** A little picture (20 x 20) of the item. */
    private void icon(GuiGraphics g, String id, int x, int y, int bodyColor, int ox, int oy) {
        App.rect(g, x - 1, y - 1, 22, 22, 0xFF3A2A4A);
        switch (kind(id)) {
            case "wall" -> Wallpaper.draw(g, x, y, 20, 20, bodyColor, Integer.parseInt(id.substring(4)));
            case "treat" -> {
                App.rect(g, x, y, 20, 20, 0xFFFFF0C0);
                PetApp.drawTreat(g, id, x + 5, y + 5);
            }
            case "theme" -> {
                if (id.equals(Theme.STRANGER_ID)) {      // The Stranger: a violet night, a dark bar with a gold line, a moon and stars
                    Skin.grad(g, x, y, x + 20, y + 20, 0xFF140E3A, 0xFF2A1F5C);
                    App.rect(g, x + 2, y + 3, 16, 4, 0xFF2A1F5C);
                    App.rect(g, x + 2, y + 6, 16, 1, 0xFFFFD866);
                    App.disc(g, x + 14, y + 11, 3, 0xFFFFF0C0);
                    App.rect(g, x + 4, y + 10, 1, 1, 0xFFFFFFFF); App.rect(g, x + 8, y + 13, 1, 1, 0xFFFFD866); App.rect(g, x + 6, y + 9, 1, 1, 0xFFFFFFFF);
                    App.rect(g, x, y + 16, 20, 4, 0xFF0C0926);
                    return;
                }
                if (id.equals(Theme.BLOOD_ID)) {         // Blood: a black and crimson desktop, a dark bar with drips, a red moon
                    Skin.grad(g, x, y, x + 20, y + 20, 0xFF3A0508, 0xFF0D0204);
                    App.rect(g, x + 2, y + 3, 16, 4, 0xFF7A0C14);
                    App.rect(g, x + 2, y + 3, 16, 1, 0xFFC01820);
                    App.rect(g, x + 4, y + 7, 1, 3, 0xFFA01018); App.rect(g, x + 10, y + 7, 1, 5, 0xFFA01018); App.rect(g, x + 15, y + 7, 1, 2, 0xFFA01018);
                    App.disc(g, x + 13, y + 13, 3, 0xFFD9302A);
                    App.rect(g, x, y + 16, 20, 4, 0xFF220306);
                    return;
                }
                if (id.equals(Theme.ANIME_ID)) {         // Anime Sakura: a pink and lilac sky, a plum bar, a sparkle, petals and a violet hill
                    Skin.grad(g, x, y, x + 20, y + 20, 0xFFFFB3DA, 0xFFD9C8FF);
                    App.rect(g, x + 2, y + 3, 16, 4, 0xFFE85CA8);
                    App.rect(g, x + 2, y + 3, 16, 1, 0xFFFFFFFF);
                    App.rect(g, x, y + 16, 20, 4, 0xFFA77BDB);
                    App.rect(g, x + 12, y + 9, 1, 5, 0xFFFFFFFF); App.rect(g, x + 10, y + 11, 5, 1, 0xFFFFFFFF); App.rect(g, x + 12, y + 11, 1, 1, 0xFFFFF27A);
                    App.rect(g, x + 4, y + 10, 2, 2, 0xFFFFE0EE); App.rect(g, x + 6, y + 12, 2, 1, 0xFFFFE0EE);
                    return;
                }
                if (id.equals(Theme.RETRO_ID)) {         // Retro 98: a teal desktop, a grey window with a navy title bar and a start button
                    App.rect(g, x, y, 20, 20, 0xFF008080);
                    App.rect(g, x + 3, y + 3, 14, 11, 0xFFC0C0C0);
                    App.rect(g, x + 3, y + 3, 14, 1, 0xFFFFFFFF);
                    App.rect(g, x + 4, y + 4, 12, 3, 0xFF000080);
                    App.rect(g, x + 5, y + 8, 10, 5, 0xFFFFFFFF);
                    App.rect(g, x, y + 16, 20, 4, 0xFFC0C0C0);
                    App.rect(g, x, y + 16, 20, 1, 0xFFFFFFFF);
                    App.rect(g, x + 2, y + 17, 6, 2, 0xFF404040);
                    return;
                }
                if (id.equals(Theme.KAWAII_ID)) {        // Kawaii Pastel: candy pink, a white bar with a bow, hearts
                    Skin.grad(g, x, y, x + 20, y + 20, 0xFFFFC4E0, 0xFFFFF0F8);
                    App.rect(g, x + 2, y + 3, 16, 4, 0xFFFF8CBC);
                    App.rect(g, x + 2, y + 3, 16, 1, 0xFFFFFFFF);
                    App.rect(g, x + 14, y + 4, 3, 2, 0xFFE0508C);
                    App.rect(g, x + 4, y + 11, 3, 2, 0xFFFF6B9A); App.rect(g, x + 8, y + 11, 3, 2, 0xFFFF6B9A); App.rect(g, x + 3, y + 12, 9, 2, 0xFFFF6B9A); App.rect(g, x + 5, y + 14, 5, 1, 0xFFFF6B9A);
                    App.rect(g, x + 14, y + 12, 3, 1, 0xFFFFD84D); App.rect(g, x + 15, y + 11, 1, 3, 0xFFFFD84D);
                    return;
                }
                Skin.grad(g, x, y, x + 20, y + 20, 0xFF6EC8FF, 0xFFE8F8FF);
                App.rect(g, x + 2, y + 3, 16, 4, 0xFF2F8FE0);
                App.rect(g, x + 2, y + 3, 16, 1, 0xFFFFFFFF);
                App.rect(g, x, y + 16, 20, 4, 0xFF6AC85A);
                App.disc(g, x + 13, y + 12, 3, 0x99FFFFFF);
                App.disc(g, x + 6, y + 13, 2, 0x99FFFFFF);
            }
            case "album" -> {
                Albums.Album a = albumOf(id);
                if (a == null) { App.rect(g, x, y, 20, 20, 0xFF6A4A9A); return; }
                RoundCover.draw(g, a, x, y, 20);
                if (!RoundCover.hasPicture(a)) {
                    String l = RoundCover.letter(a);
                    Skin.str(g, App.font(), l, x + (20 - App.font().width(l)) / 2, y + 6, 0xFFFFFFFF, false);
                }
            }
            case "track" -> {
                App.rect(g, x, y, 20, 20, 0xFF6A4A9A);
                App.disc(g, x + 7, y + 14, 3, 0xFFFFFFFF);
                App.rect(g, x + 9, y + 4, 2, 11, 0xFFFFFFFF);
                App.rect(g, x + 9, y + 4, 6, 2, 0xFFFFFFFF);
            }
            default -> {        // a pet outfit: the item on a cream blob, drawn by PetArt
                App.rect(g, x, y, 20, 20, 0xFFFFF0C0);
                PetArt.icon(g, id, x, y, ox, oy);
            }
        }
    }

    boolean click(int x, int y) {
        if (App.in(x, y, CHIP_X, CHIP_Y, CHIP_W * 5, CHIP_H)) {
            int i = (x - CHIP_X) / CHIP_W;
            if (i >= 0 && i < 5 && i != tab) { tab = i; scroll = 0; }
            return true;
        }
        List<Item> items = view();
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= items.size()) break;
            Item it = items.get(idx);
            int ry = TOP + v * ROW;
            if (!App.in(x, y, App.W - BTN_W - 8, ry + 3, BTN_W, 17)) continue;
            switch (action(it)) {
                case "buy" -> {
                    if (kind(it.id()).equals("treat")) Progress.buyTreat(it.id(), cost(it));
                    else if (isAlbum(it.id())) { Albums.Album a = albumOf(it.id()); if (a != null && Progress.coins() >= a.price()) a.buy(); }
                    else if (Progress.buy(it.id(), cost(it))) {
                        if (kind(it.id()).equals("wall")) Wallpaper.set(Integer.parseInt(it.id().substring(4)));
                        else if (kind(it.id()).equals("acc")) Progress.equip(it.id());
                        else if (kind(it.id()).equals("theme")) Theme.setById(it.id(), true);
                    }
                }
                case "set" -> Wallpaper.set(Integer.parseInt(it.id().substring(4)));
                case "wear" -> Progress.equip(it.id());
                case "take_off" -> Progress.unequip(it.id());
                case "theme_on" -> Theme.setById(it.id(), true);
                case "theme_off" -> Theme.setById(it.id(), false);
                default -> { }
            }
            return true;
        }
        return false;
    }

    void scroll(double amount) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll + (amount < 0 ? 1 : -1)));
    }

    boolean key(int keyCode) {
        switch (keyCode) {
            case 264 -> scroll = Math.min(maxScroll(), scroll + 1);                   // down
            case 265 -> scroll = Math.max(0, scroll - 1);                             // up
            case 262 -> { tab = Math.min(4, tab + 1); scroll = 0; }                   // right
            case 263 -> { tab = Math.max(0, tab - 1); scroll = 0; }                   // left
            default -> { return false; }
        }
        return true;
    }
}
