package dev.cutemod.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The cable puzzle of the PC build screen: the plugs of the power supply are on the left, their sockets on the right, and the player
 * drags every cable from its plug to its socket along the little grid, round the parts that stand in the way (processor, memory, fan).
 * Cables cannot cross each other or go over a part. The shorter the cables, the neater the case: the score (20..100) is the "tidy" of
 * the case, and a tidy case lets the air flow better, so the processor and the video card run cooler (see {@code Thermal}).
 *
 * <p>Pure client side: the screen only sends the final score to the server ({@code ACT_TIDY}). Which cables there are depends on the PC:
 * the 24-pin one always, the processor plug, the video card plug and the SATA plug of the drive only when those parts are inside.
 */
final class CableGame {
    static final int AREA_W = 220, AREA_H = 150;
    private static final int COLS = 16, ROWS = 9, CELL = 12;
    private static final int GX = 14, GY = 18;

    private static final int[] SRC_ROW = {1, 3, 5, 7};
    private static final int[] DST_ROW = {0, 2, 5, 8};
    /** The parts in the way: first column, last column, first row, last row. */
    private static final int[][] BLOCKS = {{4, 7, 3, 5}, {9, 10, 1, 3}, {12, 13, 5, 6}};
    private static final String[] BLOCK_LABEL = {"CPU", "RAM", "FAN"};
    /** The length of the shortest set of cables that fits together, for every mix of wanted cables (bits: processor 1, card 2, drive 4). */
    private static final int[] PAR = {16, 36, 35, 55, 32, 52, 51, 71};
    private static final int[] COLORS = {0xFFFFD35A, 0xFFFF6B8A, 0xFF8FA8FF, 0xFFFF9A3C};
    private static final String[] NAMES = {"24-pin", "CPU", "PCIe", "SATA"};

    private final boolean[] want = new boolean[4];
    private final List<List<int[]>> paths = new ArrayList<>();
    private final boolean[] done = new boolean[4];
    private final int par;
    private int drag = -1;
    private int score = -1;
    private boolean cancelled;

    CableGame(boolean cpu, boolean gpu, boolean disk) {
        want[0] = true;
        want[1] = cpu;
        want[2] = gpu;
        want[3] = disk;
        for (int i = 0; i < 4; i++) paths.add(new ArrayList<>());
        par = PAR[(cpu ? 1 : 0) | (gpu ? 2 : 0) | (disk ? 4 : 0)];
    }

    /** The score (0..100) once the player pressed "Done", else -1. */
    int score() { return score; }

    boolean cancelled() { return cancelled; }

    private boolean allDone() {
        for (int i = 0; i < 4; i++) if (want[i] && !done[i]) return false;
        return true;
    }

    private int total() {
        int n = 0;
        for (int i = 0; i < 4; i++) if (want[i] && done[i]) n += Math.max(0, paths.get(i).size() - 1);
        return n;
    }

    /** How neat the cables are now: the extra length over the shortest set costs points. */
    private int neat() { return Math.max(20, Math.min(100, 100 - 4 * Math.max(0, total() - par))); }

    // ---------- the grid ----------
    private static boolean inBlock(int x, int y) {
        for (int[] b : BLOCKS) if (x >= b[0] && x <= b[1] && y >= b[2] && y <= b[3]) return true;
        return false;
    }

    private boolean isEnd(int x, int y, int except) {
        for (int i = 0; i < 4; i++) {
            if (!want[i] || i == except) continue;
            if (x == 0 && y == SRC_ROW[i]) return true;
            if (x == COLS - 1 && y == DST_ROW[i]) return true;
        }
        return false;
    }

    /** Whether cable {@code who} may enter this cell. */
    private boolean free(int x, int y, int who) {
        if (x < 0 || y < 0 || x >= COLS || y >= ROWS) return false;
        if (inBlock(x, y) || isEnd(x, y, who)) return false;
        for (int i = 0; i < 4; i++) {
            if (i == who) continue;
            for (int[] c : paths.get(i)) if (c[0] == x && c[1] == y) return false;
        }
        return true;
    }

    private int[] cellAt(double mx, double my, int x0, int y0) {
        int cx = (int) Math.floor((mx - (x0 + GX)) / CELL), cy = (int) Math.floor((my - (y0 + GY)) / CELL);
        if (cx < 0 || cy < 0 || cx >= COLS || cy >= ROWS) return null;
        return new int[]{cx, cy};
    }

    // ---------- input ----------
    /** A click; returns true if the overlay used it (it always does: it covers the case). */
    boolean mouseClicked(double mx, double my, int button, int x0, int y0) {
        if (button != 0) return true;
        int[] reset = {x0 + 14, y0 + 131, 56, 14}, back = {x0 + 76, y0 + 131, 56, 14}, ok = {x0 + 138, y0 + 131, 68, 14};
        if (hit(reset, mx, my)) { clearAll(); return true; }
        if (hit(back, mx, my)) { cancelled = true; return true; }
        if (hit(ok, mx, my)) {
            if (allDone()) score = neat();
            return true;
        }
        int[] c = cellAt(mx, my, x0, y0);
        if (c == null) return true;
        for (int i = 0; i < 4; i++) {
            if (want[i] && c[0] == 0 && c[1] == SRC_ROW[i]) {            // pick up a cable by its plug
                paths.get(i).clear();
                done[i] = false;
                paths.get(i).add(new int[]{0, SRC_ROW[i]});
                drag = i;
                return true;
            }
        }
        return true;
    }

    boolean mouseDragged(double mx, double my, int x0, int y0) {
        if (drag < 0) return true;
        int[] c = cellAt(mx, my, x0, y0);
        if (c == null) return true;
        List<int[]> p = paths.get(drag);
        for (int guard = 0; guard < 40 && !p.isEmpty(); guard++) {
            int[] head = p.get(p.size() - 1);
            if (head[0] == COLS - 1 && head[1] == DST_ROW[drag]) break;             // it is plugged in: stop
            int dx = c[0] - head[0], dy = c[1] - head[1];
            if (dx == 0 && dy == 0) break;
            boolean horizontalFirst = Math.abs(dx) >= Math.abs(dy);
            int[][] tries = horizontalFirst
                    ? new int[][]{{Integer.signum(dx), 0}, {0, Integer.signum(dy)}}
                    : new int[][]{{0, Integer.signum(dy)}, {Integer.signum(dx), 0}};
            boolean moved = false;
            for (int[] s : tries) {
                if (s[0] == 0 && s[1] == 0) continue;
                if (step(drag, head[0] + s[0], head[1] + s[1])) { moved = true; break; }
            }
            if (!moved) break;
        }
        return true;
    }

    boolean mouseReleased() {
        if (drag >= 0) {
            List<int[]> p = paths.get(drag);
            int[] head = p.isEmpty() ? null : p.get(p.size() - 1);
            if (head != null && head[0] == COLS - 1 && head[1] == DST_ROW[drag]) done[drag] = true;
            else p.clear();                                                         // not plugged in: the cable falls back
            drag = -1;
        }
        return true;
    }

    /** One step of the dragged cable: forward on a free cell, back along itself, or cutting a loop it made. */
    private boolean step(int who, int nx, int ny) {
        List<int[]> p = paths.get(who);
        for (int i = 0; i < p.size(); i++) {
            int[] c = p.get(i);
            if (c[0] == nx && c[1] == ny) {                                         // back onto itself: pull the cable back to there
                while (p.size() > i + 1) p.remove(p.size() - 1);
                return true;
            }
        }
        boolean target = nx == COLS - 1 && ny == DST_ROW[who];
        if (!target && !free(nx, ny, who)) return false;
        if (target) {
            for (int i = 0; i < 4; i++) {                                           // the socket is the cable's own
                if (i == who) continue;
                for (int[] c : paths.get(i)) if (c[0] == nx && c[1] == ny) return false;
            }
        }
        p.add(new int[]{nx, ny});
        return true;
    }

    private void clearAll() {
        for (int i = 0; i < 4; i++) { paths.get(i).clear(); done[i] = false; }
        drag = -1;
    }

    private static boolean hit(int[] r, double x, double y) { return x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]; }

    // ---------- drawing ----------
    void render(GuiGraphics g, Font font, int x0, int y0, int mx, int my, float t, int acc) {
        fill(g, x0, y0, AREA_W, AREA_H, 0xF2100C22);
        outline(g, x0, y0, AREA_W, AREA_H, acc & 0x66FFFFFF | 0x66000000);
        txt(g, font, Component.translatable("cutemod.cable.title").getString(), x0 + 8, y0 + 5, acc, 0.85f);
        String info = allDone()
                ? Component.translatable("cutemod.cable.neat", neat()).getString()
                : Component.translatable("cutemod.cable.hint").getString();
        txt(g, font, info, x0 + AREA_W - 8 - (int) (font.width(info) * 0.7f), y0 + 6, allDone() ? 0xFF8CF0A8 : 0xFF8A8FB0, 0.7f);

        int gx = x0 + GX, gy = y0 + GY;
        fill(g, gx, gy, COLS * CELL, ROWS * CELL, 0xFF0B0818);
        for (int cx = 0; cx < COLS; cx++)
            for (int cy = 0; cy < ROWS; cy++) fill(g, gx + cx * CELL + CELL / 2, gy + cy * CELL + CELL / 2, 1, 1, 0x30FFFFFF);

        for (int b = 0; b < BLOCKS.length; b++) {                                    // the parts in the way
            int[] r = BLOCKS[b];
            int bx = gx + r[0] * CELL + 1, by = gy + r[2] * CELL + 1, bw = (r[1] - r[0] + 1) * CELL - 2, bh = (r[3] - r[2] + 1) * CELL - 2;
            fill(g, bx, by, bw, bh, 0xFF2A2F4C);
            outline(g, bx, by, bw, bh, 0xFF4A5078);
            txt(g, font, BLOCK_LABEL[b], bx + bw / 2 - (int) (font.width(BLOCK_LABEL[b]) * 0.7f / 2), by + bh / 2 - 3, 0xFF8A8FB0, 0.7f);
        }

        for (int i = 0; i < 4; i++) {                                                // plugs and sockets
            if (!want[i]) continue;
            int sx = gx, sy = gy + SRC_ROW[i] * CELL, dx = gx + (COLS - 1) * CELL, dy = gy + DST_ROW[i] * CELL;
            fill(g, sx + 1, sy + 1, CELL - 2, CELL - 2, COLORS[i]);
            fill(g, sx + 3, sy + 3, CELL - 6, CELL - 6, 0xFF1B1636);
            outline(g, dx + 1, dy + 1, CELL - 2, CELL - 2, done[i] ? COLORS[i] : (COLORS[i] & 0x00FFFFFF) | 0x99000000);
            if (done[i]) fill(g, dx + 4, dy + 4, CELL - 8, CELL - 8, COLORS[i]);
            txt(g, font, NAMES[i], sx + 2, sy - 5, COLORS[i], 0.55f);
        }

        for (int i = 0; i < 4; i++) {                                                // the cables
            List<int[]> p = paths.get(i);
            if (p.isEmpty()) continue;
            int col = COLORS[i];
            for (int k = 0; k < p.size(); k++) {
                int cx = gx + p.get(k)[0] * CELL + CELL / 2, cy = gy + p.get(k)[1] * CELL + CELL / 2;
                if (k > 0) {
                    int px = gx + p.get(k - 1)[0] * CELL + CELL / 2, py = gy + p.get(k - 1)[1] * CELL + CELL / 2;
                    fill(g, Math.min(px, cx) - 2, Math.min(py, cy) - 2, Math.abs(px - cx) + 5, Math.abs(py - cy) + 5, 0x55000000);
                    fill(g, Math.min(px, cx) - 1, Math.min(py, cy) - 1, Math.abs(px - cx) + 3, Math.abs(py - cy) + 3, col);
                }
                fill(g, cx - 1, cy - 1, 3, 3, col);
            }
            if (i == drag) {
                int[] h = p.get(p.size() - 1);
                int hx = gx + h[0] * CELL + CELL / 2, hy = gy + h[1] * CELL + CELL / 2;
                int a = 100 + (int) (100 * (0.5 + 0.5 * Math.sin(t * 10)));
                fill(g, hx - 3, hy - 3, 7, 7, (a << 24) | 0xFFFFFF);
            }
        }

        button(g, font, x0 + 14, y0 + 131, 56, 14, Component.translatable("cutemod.cable.reset").getString(), mx, my, true, acc);
        button(g, font, x0 + 76, y0 + 131, 56, 14, Component.translatable("cutemod.cable.back").getString(), mx, my, true, acc);
        button(g, font, x0 + 138, y0 + 131, 68, 14, Component.translatable("cutemod.cable.done").getString(), mx, my, allDone(), acc);
    }

    private static void button(GuiGraphics g, Font font, int x, int y, int w, int h, String label, int mx, int my, boolean enabled, int acc) {
        boolean hov = enabled && hit(new int[]{x, y, w, h}, mx, my);
        fill(g, x, y, w, h, enabled ? (hov ? acc : 0xFF2A2548) : 0xFF1A1630);
        fill(g, x + 1, y + 1, w - 2, h - 2, enabled ? (hov ? 0xFF3A2F5E : 0xFF1B1636) : 0xFF120F24);
        txt(g, font, label, x + w / 2 - (int) (font.width(label) * 0.8f / 2), y + 4, enabled ? 0xFFFFFFFF : 0xFF5A5878, 0.8f);
    }

    private static void fill(GuiGraphics g, int x, int y, int w, int h, int argb) { g.fill(x, y, x + w, y + h, argb); }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + 1, argb);
        g.fill(x, y + h - 1, x + w, y + h, argb);
        g.fill(x, y, x + 1, y + h, argb);
        g.fill(x + w - 1, y, x + w, y + h, argb);
    }

    private static void txt(GuiGraphics g, Font font, String s, int x, int y, int argb, float scale) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, s, 0, 0, argb, false);
        g.pose().popPose();
    }
}
