package dev.cutemod.client;

import com.mojang.math.Axis;
import dev.cutemod.block.PcCaseBlockEntity;
import dev.cutemod.data.Build;
import dev.cutemod.data.PcHardware;
import dev.cutemod.data.PcHardware.Kind;
import dev.cutemod.data.Thermal;
import dev.cutemod.item.ModItems;
import dev.cutemod.item.PcCablesItem;
import dev.cutemod.item.PcCoolerItem;
import dev.cutemod.item.PcPasteItem;
import dev.cutemod.item.PcPartItem;
import dev.cutemod.net.PcBuildActionPayload;
import dev.cutemod.net.PcBuildStatePayload;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * The build screen of a PC case: the inside of the case is drawn as a little blueprint (the motherboard with its socket, memory slots,
 * video card slot, the power supply and the cables), the parts of the player's bag lie in a tray on the right. Pick a part from the
 * tray (it follows the mouse, and the places where it fits glow), click its place: it drops in with a sparkle. Click a part that is
 * inside to take it out. The big pill at the bottom is the power button, the bar next to it shows how much of the power supply the
 * build uses. Nothing is decided here: every click is a {@link PcBuildActionPayload}, the server does it with the rules of the case
 * ({@link PcCaseBlockEntity}) and answers with the new state, which this screen only draws.
 *
 * <p>Places are numbered like in {@link PcCaseBlockEntity}: 0 board, 1 processor, 2 power supply, 3 video card, 4 drive, 5 modem,
 * 6 cables, 7 cooler, 10..13 memory sticks.
 *
 * <p>Under the case: the temperatures of the processor and the card (a hot PC throttles, a too hot one does not start), the cable puzzle
 * ({@link CableGame}: neat cables = cooler PC) and the RGB light of the case. The first start of a build plays the start-up check
 * ({@link PostSequence}) over the case.
 */
public class PcBuildScreen extends Screen {
    // ---------- the layout (the panel is W x H and sits in the middle) ----------
    private static final int W = 340, H = 238;
    private static final int BX = 8, BY = 28, BW = 220, BH = 150;          // the inside of the case
    private static final int TX = 236, TY = 28, TW = 96, TH = 150;         // the tray with the parts of the bag
    private static final int CELL = 22, COLS = 4, HEAD = 14;
    private static final int PX = 74, PY = 6, PW = 140, PH = 140;          // the motherboard, inside the case

    private static final int S_BOARD = 0, S_CPU = 1, S_PSU = 2, S_GPU = 3, S_DISK = 4, S_MODEM = 5, S_CABLES = 6, S_COOLER = 7, S_STICK = 10;
    /** The order the places are hit in: the small ones first, the board last (it lies under them). */
    private static final int[] SLOT_IDS = {S_COOLER, S_CPU, S_GPU, S_DISK, S_MODEM, S_CABLES, S_PSU, 10, 11, 12, 13, S_BOARD};
    /** The colour of the glow of each case colour (white, pink, blue, mint, purple, yellow, red, black). */
    private static final int[] ACCENT = {0xE8E4F5, 0xFF8FC8, 0x7FB8FF, 0x7FF0C8, 0xB48CFF, 0xFFD86B, 0xFF7080, 0x9AA0B8};
    private static final int[] STICK_COL = {0xFF7FB8FF, 0xFF7FF0C8, 0xFFFF8FC8, 0xFFFFD86B};     // 4, 8, 16 GB ... by size

    /** The wires of the board, {x, y, x, y, ...} from the middle of the board (a pulse runs along them when the PC is on). */
    private static final int[][] TRACES = {
            {58, 30, 66, 30, 66, 22, 76, 22}, {58, 40, 70, 40, 70, 50, 76, 50}, {58, 54, 72, 54, 72, 64, 76, 64},
            {36, 66, 36, 82}, {24, 66, 24, 74, 12, 74, 12, 82}, {46, 66, 46, 76, 100, 76, 100, 82},
            {14, 40, 7, 40, 7, 112, 20, 112, 20, 118}, {110, 118, 110, 114, 134, 114, 134, 70}
    };

    private final BlockPos pos;
    private int[] st = new int[17];
    private int color;
    private int ox, oy;

    private final long[] born = new long[14];             // when each place was last filled (for the drop-in)
    private final List<Spark> sparks = new ArrayList<>();
    private final Random rnd = new Random();
    private boolean first = true;

    private int held = -1;                                 // the inventory slot of the part that was picked up
    private int scroll;
    private Component toast = Component.empty();
    private int toastColor;
    private long toastUntil;
    private long shakeUntil;
    private Component lastName = Component.empty();
    private CableGame cable;                               // the cable puzzle, while it is open
    private PostSequence post;                             // the start-up check, while it plays
    private int postBeeped;

    private record Entry(int inv, ItemStack stack) {}
    private static final class Spark { float x, y, vx, vy, size; long born; int rgb; }

    public PcBuildScreen(PcBuildStatePayload p) {
        super(Component.translatable("cutemod.build.title"));
        this.pos = p.pos();
        for (int i = 0; i < st.length; i++) st[i] = i < 6 || i == 12 ? -1 : i == 13 ? Thermal.TIDY_LEGACY : 0;
        apply(p);
    }

    public boolean isFor(BlockPos p) { return pos.equals(p); }

    @Override
    protected void init() {
        ox = (width - W) / 2;
        oy = (height - H) / 2;
    }

    @Override
    public boolean isPauseScreen() { return false; }

    // ---------- the state ----------
    private static int val(int[] s, int id) {
        return switch (id) {
            case S_BOARD -> s[0];
            case S_CPU -> s[1];
            case S_PSU -> s[2];
            case S_GPU -> s[3];
            case S_DISK -> s[4];
            case S_MODEM -> s[5];
            case S_CABLES -> s[6] == 1 ? 0 : -1;
            case S_COOLER -> s.length > 12 && s[12] >= 1 ? s[12] : -1;
            default -> {
                int i = id - S_STICK;
                yield i >= 0 && i < 4 && s[8 + i] > 0 ? s[8 + i] : -1;
            }
        };
    }

    private int val(int id) { return val(st, id); }

    private static ItemStack stackOf(int[] s, int id) {
        int v = val(s, id);
        if (v < 0) return ItemStack.EMPTY;
        return switch (id) {
            case S_BOARD -> ModItems.partStack(Kind.BOARD, v);
            case S_CPU -> ModItems.partStack(Kind.CPU, v);
            case S_PSU -> ModItems.partStack(Kind.PSU, v);
            case S_GPU -> ModItems.partStack(Kind.GPU, v);
            case S_DISK -> ModItems.partStack(Kind.DISK, v);
            case S_MODEM -> ModItems.partStack(Kind.MODEM, v);
            case S_CABLES -> new ItemStack(ModItems.PC_CABLES.get());
            case S_COOLER -> ModItems.coolerStack(v);
            default -> ModItems.stickStack(v);
        };
    }

    private ItemStack stackOf(int id) { return stackOf(st, id); }

    private boolean on() { return st[7] == 1; }

    private int sticks() {
        int n = 0;
        for (int i = 0; i < 4; i++) if (val(S_STICK + i) > 0) n++;
        return n;
    }

    /** The server sent what is inside the case now. */
    public void apply(PcBuildStatePayload p) {
        int[] now = new int[17];
        for (int i = 0; i < now.length; i++) now[i] = i < p.st().size() ? p.st().get(i) : (i < 6 || i == 12 ? -1 : i == 13 ? Thermal.TIDY_LEGACY : 0);
        int[] old = st;
        int[] places = {S_BOARD, S_CPU, S_PSU, S_GPU, S_DISK, S_MODEM, S_CABLES, S_COOLER, 10, 11, 12, 13};
        Component installedName = null;
        for (int id : places) {
            int a = val(old, id), b = val(now, id);
            if (b >= 0 && a != b) {
                born[id] = Util.getMillis();
                if (!first) burst(id);
                if (installedName == null) installedName = stackOf(now, id).getHoverName();
            }
        }
        color = p.color();
        if (!first) {
            switch (p.event()) {
                case PcBuildStatePayload.EV_INSTALLED -> say(Component.translatable("cutemod.part.installed", installedName == null ? lastName : installedName), 0xFF8CF0A8);
                case PcBuildStatePayload.EV_REMOVED -> say(Component.translatable("cutemod.case.removed", stackOf(old, p.detail()).getHoverName()), 0xFFFFD86B);
                case PcBuildStatePayload.EV_ON -> say(Component.translatable("cutemod.build.toast.on"), 0xFF8CF0A8);
                case PcBuildStatePayload.EV_OFF -> say(Component.translatable("cutemod.case.off"), 0xFFB8B4D0);
                case PcBuildStatePayload.EV_POST -> startPost(now, false, 0);
                case PcBuildStatePayload.EV_THERMAL -> { startPost(now, true, p.detail()); shakeUntil = Util.getMillis() + 450; }
                case PcBuildStatePayload.EV_INCOMPLETE -> { say(Component.translatable("cutemod.case.missing", missingText(now)), 0xFFFFB45A); shakeUntil = Util.getMillis() + 450; }
                case PcBuildStatePayload.EV_ERROR -> { say(errorText(p.detail()), 0xFFFF7A8A); shakeUntil = Util.getMillis() + 300; }
                default -> { }
            }
        }
        st = now;
        first = false;
    }

    private Component errorText(int resultOrdinal) {
        PcCaseBlockEntity.Result[] all = PcCaseBlockEntity.Result.values();
        PcCaseBlockEntity.Result r = resultOrdinal >= 0 && resultOrdinal < all.length ? all[resultOrdinal] : PcCaseBlockEntity.Result.SAME;
        String key = switch (r) {
            case NEED_BOARD -> "cutemod.case.need_board";
            case NEED_PSU -> "cutemod.case.need_psu";
            case NEED_CPU -> "cutemod.case.need_cpu";
            case SOCKET -> "cutemod.part.socket";
            case NO_SLOT -> "cutemod.part.noslot";
            case BOARD_SLOTS -> "cutemod.case.board_slots";
            case BUSY -> "cutemod.build.busy";
            default -> "cutemod.case.same";
        };
        return Component.translatable(key, lastName);
    }

    private void say(Component text, int argb) {
        toast = text;
        toastColor = argb;
        toastUntil = Util.getMillis() + 2600;
    }

    private Component missingText(int[] s) {
        List<String> keys = new ArrayList<>();
        if (val(s, S_BOARD) < 0) keys.add("cutemod.case.part.board");
        if (val(s, S_CPU) < 0) keys.add("cutemod.case.part.cpu");
        boolean ram = false;
        for (int i = 0; i < 4; i++) if (val(s, S_STICK + i) > 0) ram = true;
        if (!ram) keys.add("cutemod.case.part.ram");
        if (val(s, S_DISK) < 0) keys.add("cutemod.case.part.disk");
        if (val(s, S_PSU) < 0) keys.add("cutemod.case.part.psu");
        if (val(s, S_CABLES) < 0) keys.add("cutemod.case.part.cables");
        var out = Component.empty();
        for (int i = 0; i < keys.size(); i++) {
            if (i > 0) out.append(", ");
            out.append(Component.translatable(keys.get(i)));
        }
        return out;
    }

    /** The build the case would give to the OS now (the same maths as the case itself). */
    private Build build() {
        Build b = Build.stock();
        b.cpu = Math.max(0, st[1]);
        b.board = Math.max(0, st[0]);
        b.psu = Math.max(0, st[2]);
        b.gpu = Math.max(0, st[3]);
        b.disk = Math.max(0, st[4]);
        b.modem = st[5];
        int slots = b.slots();
        for (int i = 0; i < Build.MAX_SLOTS; i++) b.sticks[i] = i < slots ? Math.max(0, st[8 + i]) : 0;
        return b;
    }

    // ---------- the places ----------
    /** {x, y, w, h} of a place, relative to the inside of the case. */
    private static int[] rel(int id) {
        return switch (id) {
            case S_BOARD -> new int[]{PX, PY, PW, PH};
            case S_CPU -> new int[]{PX + 14, PY + 22, 44, 44};
            case S_GPU -> new int[]{PX + 8, PY + 82, 124, 30};
            case S_DISK -> new int[]{PX + 8, PY + 118, 60, 18};
            case S_MODEM -> new int[]{PX + 72, PY + 118, 60, 18};
            case S_PSU -> new int[]{4, 98, 64, 48};
            case S_CABLES -> new int[]{14, 56, 44, 34};
            case S_COOLER -> new int[]{14, 8, 44, 44};
            default -> new int[]{PX + 76 + (id - S_STICK) * 14, PY + 14, 12, 58};
        };
    }

    private int[] abs(int id) {
        int[] r = rel(id);
        return new int[]{ox + BX + r[0], oy + BY + r[1], r[2], r[3]};
    }

    /** The part of the board you click to take the board out (the board itself is under all the other places). */
    private int[] boardChip() { return new int[]{ox + BX + PX + 4, oy + BY + PY + 3, 72, 11}; }

    private int[] hitRect(int id) { return id == S_BOARD && val(S_BOARD) >= 0 ? boardChip() : abs(id); }

    private static boolean in(int[] r, double x, double y) { return x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]; }

    private int slotAt(double mx, double my) {
        for (int id : SLOT_IDS) if (in(hitRect(id), mx, my)) return id;
        return -1;
    }

    private boolean locked(int id) {
        int i = id - S_STICK;
        return i >= 0 && i < 4 && i >= Build.BOARD_SLOTS[Math.max(0, val(S_BOARD))] && val(S_BOARD) >= 0;
    }

    // ---------- the bag ----------
    private static boolean isPart(ItemStack s) { return s.getItem() instanceof PcPartItem || s.getItem() instanceof PcCablesItem || s.getItem() instanceof PcCoolerItem || s.getItem() instanceof PcPasteItem; }

    private static int sortKey(ItemStack s) {
        if (s.getItem() instanceof PcPartItem p) return p.kind().ordinal() * 100 + p.level() + 1;
        if (s.getItem() instanceof PcCoolerItem c) return 800 + c.level();
        if (s.getItem() instanceof PcPasteItem) return 790;
        return 900;
    }

    private List<Entry> entries() {
        List<Entry> out = new ArrayList<>();
        if (minecraft == null || minecraft.player == null) return out;
        Inventory inv = minecraft.player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && isPart(s)) out.add(new Entry(i, s));
        }
        out.sort(Comparator.comparingInt(e -> sortKey(e.stack())));
        return out;
    }

    private ItemStack heldStack() {
        if (held < 0 || minecraft == null || minecraft.player == null) return ItemStack.EMPTY;
        Inventory inv = minecraft.player.getInventory();
        if (held >= inv.getContainerSize()) return ItemStack.EMPTY;
        ItemStack s = inv.getItem(held);
        return !s.isEmpty() && isPart(s) ? s : ItemStack.EMPTY;
    }

    /** Whether this kind of part belongs in that place at all. */
    private static boolean belongs(ItemStack s, int id) {
        if (s.getItem() instanceof PcCablesItem) return id == S_CABLES;
        if (s.getItem() instanceof PcCoolerItem) return id == S_COOLER;
        if (s.getItem() instanceof PcPasteItem) return id == S_CPU;
        if (!(s.getItem() instanceof PcPartItem p)) return false;
        return switch (p.kind()) {
            case BOARD -> id == S_BOARD;
            case CPU -> id == S_CPU;
            case PSU -> id == S_PSU;
            case GPU -> id == S_GPU;
            case DISK -> id == S_DISK;
            case MODEM -> id == S_MODEM;
            case RAM -> id >= S_STICK;
        };
    }

    /** Why the part cannot go in right now (a translation key), or null if it can. The same rules as the case; the server has the last word. */
    private String reason(ItemStack s) {
        int board = val(S_BOARD);
        if (s.getItem() instanceof PcCablesItem) {
            if (board < 0) return "cutemod.case.need_board";
            if (val(S_PSU) < 0) return "cutemod.case.need_psu";
            return val(S_CABLES) >= 0 ? "cutemod.case.same" : null;
        }
        if (s.getItem() instanceof PcPasteItem) {
            if (board < 0) return "cutemod.case.need_board";
            if (val(S_CPU) < 0) return "cutemod.case.need_cpu";
            if (val(S_COOLER) >= 0) return "cutemod.case.paste_busy";
            return st[16] == 1 ? "cutemod.case.paste_same" : null;
        }
        if (s.getItem() instanceof PcCoolerItem c) {
            if (board < 0) return "cutemod.case.need_board";
            if (val(S_CPU) < 0) return "cutemod.case.need_cpu";
            return c.level() == val(S_COOLER) ? "cutemod.case.same" : null;
        }
        if (!(s.getItem() instanceof PcPartItem p)) return "cutemod.case.same";
        int lv = p.level();
        switch (p.kind()) {
            case BOARD -> {
                if (lv == board) return "cutemod.case.same";
                int cpu = val(S_CPU);
                if (cpu >= 0 && !Build.fits(Build.CPU_SOCKET[cpu], Build.BOARD_SOCKET[lv])) return "cutemod.part.socket";
                int highest = -1;
                for (int i = 0; i < 4; i++) if (val(S_STICK + i) > 0) highest = i;
                if (sticks() > Build.BOARD_SLOTS[lv] || highest >= Build.BOARD_SLOTS[lv]) return "cutemod.case.board_slots";
            }
            case CPU -> {
                if (board < 0) return "cutemod.case.need_board";
                if (lv == val(S_CPU)) return "cutemod.case.same";
                if (!Build.fits(Build.CPU_SOCKET[lv], Build.BOARD_SOCKET[board])) return "cutemod.part.socket";
            }
            case PSU -> { if (lv == val(S_PSU)) return "cutemod.case.same"; }
            case GPU -> {
                if (board < 0) return "cutemod.case.need_board";
                if (lv == val(S_GPU)) return "cutemod.case.same";
            }
            case DISK -> {
                if (board < 0) return "cutemod.case.need_board";
                if (lv == val(S_DISK)) return "cutemod.case.same";
            }
            case MODEM -> {
                if (board < 0) return "cutemod.case.need_board";
                if (lv == val(S_MODEM)) return "cutemod.case.same";
            }
            case RAM -> {
                if (board < 0) return "cutemod.case.need_board";
                boolean free = false;
                for (int i = 0; i < Build.BOARD_SLOTS[board]; i++) if (val(S_STICK + i) < 0) free = true;
                if (!free) return "cutemod.part.noslot";
            }
        }
        return null;
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (post != null) {                                 // the start-up check: a click shows it all, the next one closes it
            long now = Util.getMillis();
            if (!post.finished(now)) post.skip(now);
            else post = null;
            return true;
        }
        if (cable != null) {
            cable.mouseClicked(mx, my, button, ox + BX, oy + BY);
            checkCable();
            return true;
        }
        if (button == 1) {                                  // right click: put the part down
            if (held >= 0) { held = -1; click(0.8f); }
            return true;
        }
        if (button != 0) return super.mouseClicked(mx, my, button);

        int[] pill = {ox + 8, oy + 186, 84, 24};
        if (in(pill, mx, my)) {
            send(PcBuildActionPayload.ACT_POWER, 0);
            click(on() ? 0.9f : 1.5f);
            return true;
        }

        if (in(cablesRect(), mx, my)) {                     // the cable puzzle
            if (val(S_CABLES) < 0) { say(Component.translatable("cutemod.build.cables.first"), 0xFFFFB45A); click(0.6f); return true; }
            held = -1;
            cable = new CableGame(val(S_CPU) >= 0, val(S_GPU) > 0, val(S_DISK) >= 0);
            click(1.3f);
            return true;
        }
        if (in(rgbRect(), mx, my)) {                        // RGB: off, one colour, breathing, rainbow
            send(PcBuildActionPayload.ACT_RGB, ((st[14] + 1) % 4) * 8 + st[15]);
            click(1.4f);
            return true;
        }
        if (in(swatchRect(), mx, my)) {                     // the next colour
            send(PcBuildActionPayload.ACT_RGB, st[14] * 8 + (st[15] + 1) % 8);
            click(1.6f);
            return true;
        }

        List<Entry> list = entries();
        for (int i = 0; i < list.size(); i++) {             // a part of the tray
            int[] c = cell(i);
            if (c[1] < oy + TY + HEAD || c[1] + 20 > oy + TY + TH - 2) continue;
            if (in(new int[]{c[0], c[1], 20, 20}, mx, my)) {
                held = held == list.get(i).inv() ? -1 : list.get(i).inv();
                click(1.5f);
                return true;
            }
        }

        int slot = slotAt(mx, my);
        ItemStack hs = heldStack();
        if (!hs.isEmpty()) {
            lastName = hs.getHoverName();
            if (slot < 0) { held = -1; return true; }
            if (!belongs(hs, slot)) {
                say(Component.translatable("cutemod.build.wrong", lastName), 0xFFFF7A8A);
                shakeUntil = Util.getMillis() + 300;
                click(0.6f);
                return true;
            }
            String why = reason(hs);
            if (why != null) {
                say(Component.translatable(why, lastName), 0xFFFF7A8A);
                shakeUntil = Util.getMillis() + 300;
                click(0.6f);
                return true;
            }
            send(PcBuildActionPayload.ACT_INSTALL, held);
            if (!(hs.getItem() instanceof PcPartItem p && p.kind() == Kind.RAM)) held = -1;     // sticks come in twos and fours: keep holding
            return true;
        }
        if (slot >= 0 && val(slot) >= 0) {                  // a part that is inside: take it out
            send(PcBuildActionPayload.ACT_REMOVE, slot);
            click(0.9f);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (cable != null) { cable.mouseDragged(mx, my, ox + BX, oy + BY); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (cable != null) { cable.mouseReleased(); checkCable(); return true; }
        return super.mouseReleased(mx, my, button);
    }

    /** The puzzle was solved (send the score) or left. */
    private void checkCable() {
        if (cable == null) return;
        if (cable.score() >= 0) {
            send(PcBuildActionPayload.ACT_TIDY, cable.score());
            say(Component.translatable("cutemod.cable.saved", cable.score()), 0xFF8CF0A8);
            cable = null;
        } else if (cable.cancelled()) {
            cable = null;
        }
    }

    private void startPost(int[] now, boolean fail, int fault) {
        post = new PostSequence(now, fail, fault, Util.getMillis());
        postBeeped = 0;
        cable = null;
        held = -1;
    }

    private void beep(SoundEvent sound, float pitch) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound, pitch));
    }

    /** One beep for every new line of the start-up check, a rising chime for a good start, low beeps for a bad one. */
    private void postSounds(long now) {
        int n = post.shown(now);
        while (postBeeped < n) {
            PostSequence.Line l = post.line(postBeeped);
            switch (l.kind()) {
                case PostSequence.HEAD -> beep(SoundEvents.NOTE_BLOCK_PLING.value(), 1.0f);
                case PostSequence.OK -> beep(SoundEvents.NOTE_BLOCK_PLING.value(), 1.3f + 0.04f * postBeeped);
                case PostSequence.WARN -> beep(SoundEvents.NOTE_BLOCK_BASS.value(), 0.9f);
                case PostSequence.FAIL, PostSequence.END_FAIL -> beep(SoundEvents.NOTE_BLOCK_BASS.value(), 0.55f);
                case PostSequence.END_OK -> { beep(SoundEvents.NOTE_BLOCK_PLING.value(), 1.8f); beep(SoundEvents.AMETHYST_BLOCK_CHIME, 1.5f); }
                case PostSequence.END_WARN -> beep(SoundEvents.NOTE_BLOCK_PLING.value(), 0.8f);
                default -> { }
            }
            postBeeped++;
        }
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        if (in(new int[]{ox + TX, oy + TY, TW, TH}, mx, my)) {
            int rows = (entries().size() + COLS - 1) / COLS;
            int vis = (TH - HEAD - 4) / CELL;
            scroll = Math.max(0, Math.min(Math.max(0, rows - vis), scroll - (int) Math.signum(sy)));
            return true;
        }
        return super.mouseScrolled(mx, my, sx, sy);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 256 && (cable != null || post != null)) { cable = null; post = null; return true; }       // Esc closes the overlay first
        if (minecraft != null && minecraft.options.keyInventory.matches(key, scan)) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    private void send(int action, int arg) {
        PacketDistributor.sendToServer(new PcBuildActionPayload(pos, action, arg));
    }

    private void click(float pitch) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), pitch));
    }

    // ---------- colours and little drawing tools ----------
    private int accent() { return 0xFF000000 | ACCENT[Math.floorMod(color, ACCENT.length)]; }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int alpha(int rgb, float a) {
        return (Math.max(0, Math.min(255, (int) (a * 255))) << 24) | (rgb & 0xFFFFFF);
    }

    /** A rectangle with the corners cut off (a pixel-art rounded rectangle). */
    private static void rr(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x + 2, y, x + w - 2, y + h, c);
        g.fill(x, y + 2, x + w, y + h - 2, c);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, c);
    }

    private static void frame(GuiGraphics g, int x, int y, int w, int h, int border, int fill) {
        rr(g, x, y, w, h, border);
        rr(g, x + 1, y + 1, w - 2, h - 2, fill);
    }

    private static void circle(GuiGraphics g, int cx, int cy, int r, int c) {
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.round(Math.sqrt(r * r - dy * dy + 0.5));
            g.fill(cx - w, cy + dy, cx + w, cy + dy + 1, c);
        }
    }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int t, int c) {
        g.fill(x, y, x + w, y + t, c);
        g.fill(x, y + h - t, x + w, y + h, c);
        g.fill(x, y, x + t, y + h, c);
        g.fill(x + w - t, y, x + w, y + h, c);
    }

    private static void dashed(GuiGraphics g, int x, int y, int w, int h, int c) {
        for (int i = 0; i < w; i += 5) {
            int e = Math.min(i + 3, w);
            g.fill(x + i, y, x + e, y + 1, c);
            g.fill(x + i, y + h - 1, x + e, y + h, c);
        }
        for (int i = 0; i < h; i += 5) {
            int e = Math.min(i + 3, h);
            g.fill(x, y + i, x + 1, y + e, c);
            g.fill(x + w - 1, y + i, x + w, y + e, c);
        }
    }

    private void text(GuiGraphics g, String s, float x, float y, int c, float scale) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, s, 0, 0, c, false);
        g.pose().popPose();
    }

    private void text(GuiGraphics g, Component s, float x, float y, int c, float scale) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, s, 0, 0, c, false);
        g.pose().popPose();
    }

    private void textCentered(GuiGraphics g, Component s, float cx, float y, int c, float scale) {
        text(g, s, cx - font.width(s) * scale / 2f, y, c, scale);
    }

    private void icon(GuiGraphics g, ItemStack s, float x, float y, float scale) {
        if (s.isEmpty()) return;
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(scale, scale, 1f);
        g.renderItem(s, 0, 0);
        g.pose().popPose();
    }

    private void fan(GuiGraphics g, int cx, int cy, int r, float angle, int bladeColor, int bgColor) {
        circle(g, cx, cy, r, bgColor);
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0f);
        g.pose().mulPose(Axis.ZP.rotationDegrees(angle));
        g.fill(-r + 2, -1, r - 1, 1, bladeColor);
        g.fill(-1, -r + 2, 1, r - 1, bladeColor);
        g.pose().mulPose(Axis.ZP.rotationDegrees(45f));
        g.fill(-r + 3, 0, r - 2, 1, alpha(bladeColor, 0.55f));
        g.fill(0, -r + 3, 1, r - 2, alpha(bladeColor, 0.55f));
        g.pose().popPose();
        circle(g, cx, cy, 2, mix(bgColor, bladeColor, 0.7f));
    }

    private float dropOffset(int id) {
        float age = (Util.getMillis() - born[id]) / 420f;
        if (age >= 1f || born[id] == 0) return 0f;
        float e = 1f - (1f - age) * (1f - age) * (1f - age);
        float bounce = age > 0.7f ? (float) Math.sin((age - 0.7f) / 0.3f * Math.PI) * 1.5f : 0f;
        return -(1f - e) * 16f - bounce;
    }

    private void burst(int id) {
        int[] r = abs(id);
        float cx = r[0] + r[2] / 2f, cy = r[1] + r[3] / 2f;
        long now = Util.getMillis();
        for (int i = 0; i < 16; i++) {
            Spark s = new Spark();
            s.x = cx + (rnd.nextFloat() - 0.5f) * Math.min(r[2], 40);
            s.y = cy + (rnd.nextFloat() - 0.5f) * Math.min(r[3], 30);
            double a = rnd.nextDouble() * Math.PI * 2;
            float sp = 18f + rnd.nextFloat() * 34f;
            s.vx = (float) Math.cos(a) * sp;
            s.vy = (float) Math.sin(a) * sp - 16f;
            s.size = rnd.nextInt(3) == 0 ? 2f : 1f;
            s.born = now;
            s.rgb = rnd.nextBoolean() ? ACCENT[Math.floorMod(color, ACCENT.length)] : 0xFFFFFF;
            sparks.add(s);
        }
    }

    private int[] cell(int index) {
        return new int[]{ox + TX + 4 + (index % COLS) * CELL, oy + TY + HEAD + (index / COLS - scroll) * CELL};
    }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        long now = Util.getMillis();
        float t = now / 1000f;
        if (held >= 0 && heldStack().isEmpty()) held = -1;

        g.fill(0, 0, width, height, 0xC40B0816);

        int shake = now < shakeUntil ? (int) Math.round(Math.sin(now / 28.0) * 2.0) : 0;
        g.pose().pushPose();
        g.pose().translate(shake, 0f, 0f);
        drawPanel(g, t);
        drawCase(g, mx, my, t);
        drawTray(g, mx, my, t);
        drawBottom(g, mx, my, t);
        drawHeatRow(g, mx, my, t);
        g.pose().popPose();

        if (cable != null) cable.render(g, font, ox + BX, oy + BY, mx, my, t, accent());
        if (post != null) {
            postSounds(now);
            post.render(g, font, ox + BX, oy + BY, now, accent());
            if (post.expired(now)) post = null;
        }

        drawSparks(g, now);
        drawToast(g, now);
        drawHeld(g, mx, my, t);
        if (cable == null && post == null) drawTooltips(g, mx, my);
    }

    private void drawPanel(GuiGraphics g, float t) {
        int acc = accent();
        rr(g, ox - 1, oy - 1, W + 2, H + 2, alpha(acc, 0.55f));
        rr(g, ox, oy, W, H, 0xFF14102A);
        g.fillGradient(ox + 2, oy + 2, ox + W - 2, oy + H - 2, 0xFF2B2548, 0xFF171330);
        g.fill(ox + 2, oy + 22, ox + W - 2, oy + 23, alpha(acc, 0.30f));
        g.fill(ox + 2, oy + 180, ox + W - 2, oy + 181, alpha(acc, 0.18f));
        g.fill(ox + 2, oy + 211, ox + W - 2, oy + 212, alpha(acc, 0.18f));

        // the title
        circle(g, ox + 14, oy + 12, 3, on() ? mix(0xFF1F6B4A, 0xFF8CF0A8, 0.5f + 0.5f * (float) Math.sin(t * 4)) : 0xFF6B4A5A);
        g.drawString(font, title, ox + 24, oy + 8, acc, true);

        Build b = build();
        String stats = Component.translatable("cutemod.build.stats", Build.CPU_CORES[b.cpu], Build.CPU_GHZ[b.cpu], b.ramGb(), PcHardware.VRAM_GB[b.gpu]).getString();
        text(g, stats, ox + W - 10 - font.width(stats) * 0.75f, oy + 9, 0xFFB8B4D0, 0.75f);
    }

    private void drawCase(GuiGraphics g, int mx, int my, float t) {
        int acc = accent();
        int x0 = ox + BX, y0 = oy + BY;
        frame(g, x0, y0, BW, BH, mix(acc, 0xFF2A2640, 0.6f), 0xFF110E24);
        for (int gx = 6; gx < BW - 4; gx += 10)                                    // the dotted floor of the case
            for (int gy = 6; gy < BH - 4; gy += 10) g.fill(x0 + gx, y0 + gy, x0 + gx + 1, y0 + gy + 1, 0x16FFFFFF);
        g.fillGradient(x0 + 2, y0 + 2, x0 + BW - 2, y0 + 30, 0x14FFFFFF, 0x00FFFFFF);          // the glass

        drawRgbGlow(g, x0, y0, t);

        ItemStack hs = heldStack();
        boolean board = val(S_BOARD) >= 0;
        drawBoard(g, t, board);
        drawCables(g);
        for (int id : new int[]{S_PSU, S_CABLES, S_CPU, S_COOLER, S_GPU, S_DISK, S_MODEM, 10, 11, 12, 13}) drawSlot(g, id, t, hs, mx, my);
        if (!board) drawSlot(g, S_BOARD, t, hs, mx, my);
        else drawBoardChip(g, t, mx, my);
    }

    private void drawBoard(GuiGraphics g, float t, boolean present) {
        int[] r = abs(S_BOARD);
        if (!present) return;
        float dy = dropOffset(S_BOARD);
        g.pose().pushPose();
        g.pose().translate(0f, dy, 0f);
        int acc = accent();
        int base = mix(0xFF1B5560, acc, 0.12f);
        rr(g, r[0] - 1, r[1] - 1, r[2] + 2, r[3] + 2, on() ? alpha(acc, 0.35f + 0.25f * (float) Math.sin(t * 3)) : 0x55000000);
        frame(g, r[0], r[1], r[2], r[3], 0xFF0B2A33, base);
        g.fillGradient(r[0] + 2, r[1] + 2, r[0] + r[2] - 2, r[1] + r[3] - 2, mix(base, 0xFFFFFFFF, 0.08f), mix(base, 0xFF000000, 0.25f));
        for (int[] c : new int[][]{{4, 17}, {r[2] - 7, 17}, {4, r[3] - 7}, {r[2] - 7, r[3] - 7}}) {          // the screws
            circle(g, r[0] + c[0] + 1, r[1] + c[1] + 1, 2, 0xFF0B2A33);
            g.fill(r[0] + c[0], r[1] + c[1] + 1, r[0] + c[0] + 3, r[1] + c[1] + 2, 0xFF7FA8B0);
        }
        int dim = alpha(acc, 0.35f);
        for (int i = 0; i < TRACES.length; i++) {
            int[] p = TRACES[i];
            for (int k = 0; k + 3 < p.length; k += 2) {
                int ax = r[0] + p[k], ay = r[1] + p[k + 1], bx = r[0] + p[k + 2], by = r[1] + p[k + 3];
                g.fill(Math.min(ax, bx), Math.min(ay, by), Math.max(ax, bx) + 1, Math.max(ay, by) + 1, dim);
            }
            int lx = r[0] + p[p.length - 2], ly = r[1] + p[p.length - 1];
            g.fill(lx - 1, ly - 1, lx + 2, ly + 2, alpha(acc, 0.6f));
            if (on()) {                                                                            // a pulse runs along the wire
                float[] o = pulse(p, (t * 0.35f + i * 0.173f) % 1f);
                g.fill((int) o[0] + r[0] - 2, (int) o[1] + r[1] - 2, (int) o[0] + r[0] + 3, (int) o[1] + r[1] + 3, alpha(acc, 0.25f));
                g.fill((int) o[0] + r[0] - 1, (int) o[1] + r[1] - 1, (int) o[0] + r[0] + 2, (int) o[1] + r[1] + 2, 0xFFFFFFFF);
            }
        }
        g.pose().popPose();
    }

    private static float[] pulse(int[] pts, float u) {
        float total = 0;
        for (int k = 0; k + 3 < pts.length; k += 2) total += Math.abs(pts[k + 2] - pts[k]) + Math.abs(pts[k + 3] - pts[k + 1]);
        float d = u * total;
        for (int k = 0; k + 3 < pts.length; k += 2) {
            float seg = Math.abs(pts[k + 2] - pts[k]) + Math.abs(pts[k + 3] - pts[k + 1]);
            if (d <= seg) {
                float f = seg == 0 ? 0 : d / seg;
                return new float[]{pts[k] + (pts[k + 2] - pts[k]) * f, pts[k + 1] + (pts[k + 3] - pts[k + 1]) * f};
            }
            d -= seg;
        }
        return new float[]{pts[pts.length - 2], pts[pts.length - 1]};
    }

    private void drawBoardChip(GuiGraphics g, float t, int mx, int my) {
        int[] c = boardChip();
        float dy = dropOffset(S_BOARD);
        boolean hov = in(c, mx, my) && heldStack().isEmpty();
        rr(g, c[0], c[1] + (int) dy, c[2], c[3], hov ? alpha(accent(), 0.65f) : 0x99000000);
        String name = stackOf(S_BOARD).getHoverName().getString();
        text(g, font.plainSubstrByWidth(name, (int) ((c[2] - 6) / 0.7f)), c[0] + 3, c[1] + 2 + dy, 0xFFE8E4F5, 0.7f);
        ItemStack hs = heldStack();
        if (!hs.isEmpty() && belongs(hs, S_BOARD)) glow(g, abs(S_BOARD), reason(hs) == null, t);        // swap the board
    }

    private void drawCables(GuiGraphics g) {
        if (val(S_CABLES) < 0) return;
        float dy = dropOffset(S_CABLES);
        int[] cols = {0xFFFFD35A, 0xFFFF6B8A, 0xFF8A8FB0, 0xFFFF9A3C};
        int x0 = ox + BX, y0 = oy + BY;
        g.pose().pushPose();
        g.pose().translate(0f, dy, 0f);
        for (int k = 0; k < 4; k++) {
            int vx = x0 + 22 + k * 8, top = y0 + 62 + k * 8, bottom = y0 + 100, px = x0 + PX;
            g.fill(vx - 1, top - 1, vx + 3, bottom, 0x55000000);                              // the soft shadow
            g.fill(vx - 1, top - 1, px, top + 3, 0x55000000);
            g.fill(vx, top, vx + 2, bottom, cols[k]);                                          // the wire: up, then to the board
            g.fill(vx, top, px, top + 2, cols[k]);
            g.fill(vx, top, vx + 1, bottom, mix(cols[k], 0xFFFFFFFF, 0.35f));
            g.fill(px - 4, top - 1, px, top + 3, 0xFFE8E4F5);                                  // the plug
        }
        g.pose().popPose();
    }

    private void drawSlot(GuiGraphics g, int id, float t, ItemStack hs, int mx, int my) {
        int[] r = abs(id);
        int v = val(id);
        int acc = accent();
        boolean hov = in(hitRect(id), mx, my);
        boolean fits = !hs.isEmpty() && belongs(hs, id);
        float dy = dropOffset(id);

        if (v < 0) {                                                       // an empty place
            boolean noBoard = val(S_BOARD) < 0 && id != S_BOARD || id == S_COOLER && val(S_CPU) < 0;
            boolean lock = locked(id);
            int line = alpha(acc, lock || noBoard ? 0.18f : hov ? 0.9f : 0.45f);
            dashed(g, r[0], r[1], r[2], r[3], line);
            if (id >= S_STICK) text(g, lock ? "x" : "+", r[0] + 4, r[1] + r[3] / 2f - 3, line, 1f);
            else {
                Component label = Component.translatable(id == S_COOLER && st[12] == -2 ? "cutemod.build.slot.cooler.old" : slotKey(id));
                float sc = r[2] >= 60 ? 0.7f : 0.6f;
                List<FormattedCharSequence> lines = font.split(label, (int) ((r[2] - 4) / sc));
                float ty = r[1] + r[3] / 2f - lines.size() * 4f * sc;
                for (FormattedCharSequence l : lines) {
                    g.pose().pushPose();
                    g.pose().translate(r[0] + r[2] / 2f - font.width(l) * sc / 2f, ty, 0f);
                    g.pose().scale(sc, sc, 1f);
                    g.drawString(font, l, 0, 0, line, false);
                    g.pose().popPose();
                    ty += 9 * sc;
                }
            }
            if (fits && !lock) glow(g, r, reason(hs) == null, t);
            else if (!hs.isEmpty()) g.fill(r[0], r[1], r[0] + r[2], r[1] + r[3], 0x66080614);
            return;
        }

        // a part that is inside
        g.pose().pushPose();
        g.pose().translate(0f, dy, 0f);
        switch (id) {
            case S_CPU -> drawCpu(g, r, t);
            case S_COOLER -> drawCooler(g, r, v, t);
            case S_GPU -> drawGpu(g, r, t);
            case S_DISK, S_MODEM -> drawCard(g, r, stackOf(id), id == S_DISK);
            case S_PSU -> drawPsu(g, r, t);
            case S_CABLES -> { }                                           // drawn with the wires
            default -> drawStick(g, r, v, t);
        }
        g.pose().popPose();
        if (hov && hs.isEmpty()) outline(g, r[0] - 1, r[1] - 1, r[2] + 2, r[3] + 2, 1, alpha(0xFFFFFF, 0.8f));
        if (fits) glow(g, r, reason(hs) == null, t);                      // a swap
        else if (!hs.isEmpty()) g.fill(r[0], r[1], r[0] + r[2], r[1] + r[3], 0x55080614);
        if (id == S_CABLES && hov && hs.isEmpty()) outline(g, r[0], r[1], r[2], r[3], 1, alpha(0xFFFFFF, 0.5f));
    }

    private void glow(GuiGraphics g, int[] r, boolean ok, float t) {
        float k = 0.55f + 0.45f * (float) Math.sin(t * 6f);
        int c = ok ? ACCENT[Math.floorMod(color, ACCENT.length)] : 0xFF5A6A;
        g.fill(r[0], r[1], r[0] + r[2], r[1] + r[3], alpha(c, 0.10f + 0.10f * k));
        outline(g, r[0] - 1, r[1] - 1, r[2] + 2, r[3] + 2, 2, alpha(c, 0.45f + 0.5f * k));
    }

    private static String slotKey(int id) {
        return switch (id) {
            case S_BOARD -> "cutemod.build.slot.board";
            case S_CPU -> "cutemod.build.slot.cpu";
            case S_PSU -> "cutemod.build.slot.psu";
            case S_GPU -> "cutemod.build.slot.gpu";
            case S_DISK -> "cutemod.build.slot.disk";
            case S_MODEM -> "cutemod.build.slot.modem";
            case S_CABLES -> "cutemod.build.slot.cables";
            case S_COOLER -> "cutemod.build.slot.cooler";
            default -> "cutemod.build.slot.ram";
        };
    }

    /** The colour of the RGB light now (0 = off): one colour, breathing, or a rainbow that runs round. */
    private int rgbArgb(float t) {
        int mode = st[14];
        if (mode <= 0) return 0;
        int base = 0xFF000000 | ACCENT[Math.floorMod(st[15], ACCENT.length)];
        return switch (mode) {
            case 1 -> base;
            case 2 -> alpha(base, 0.35f + 0.65f * (0.5f + 0.5f * (float) Math.sin(t * 2.2f)));
            default -> 0xFF000000 | Mth.hsvToRgb((t * 0.25f) % 1f, 0.55f, 1f);
        };
    }

    /** The RGB light of the case glows round the inside, like the strips behind the glass of the real case. */
    private void drawRgbGlow(GuiGraphics g, int x0, int y0, float t) {
        int c = rgbArgb(t);
        if (c == 0) return;
        float k = on() ? 1f : 0.45f;
        outline(g, x0 - 1, y0 - 1, BW + 2, BH + 2, 1, alpha(c, 0.75f * k));
        g.fillGradient(x0 + 2, y0 + BH - 28, x0 + BW - 2, y0 + BH - 2, 0x00000000, alpha(c, 0.20f * k));
        g.fillGradient(x0 + 2, y0 + 2, x0 + BW - 2, y0 + 20, alpha(c, 0.12f * k), 0x00000000);
    }

    /** The cooler: a small air cooler, a tower with fins, or a liquid cooler with two tubes to the processor. */
    private void drawCooler(GuiGraphics g, int[] r, int level, float t) {
        int acc = accent();
        int[] cpu = abs(S_CPU);
        int ty = r[1] + 22;
        g.fill(r[0] + r[2], ty - 1, cpu[0] + 2, ty + 2, 0x55000000);                         // the heat pipe to the processor
        g.fill(r[0] + r[2], ty, cpu[0] + 2, ty + 1, level == 3 ? 0xFF7FB8FF : 0xFFC0C6E0);
        if (level == 3) g.fill(r[0] + r[2], ty + 4, cpu[0] + 2, ty + 5, 0xFFFF8FC8);
        frame(g, r[0], r[1], r[2], r[3], 0xFF4A5078, level == 3 ? 0xFF1F3A55 : 0xFF2A2F4C);
        if (level == 2) for (int i = 0; i < 5; i++) g.fill(r[0] + 4 + i * 8, r[1] + 3, r[0] + 6 + i * 8, r[1] + r[3] - 3, 0xFF5A6290);
        float ang = on() ? t * (level == 3 ? 700f : 480f) : 0f;
        fan(g, r[0] + r[2] / 2, r[1] + r[3] / 2 - 2, level == 1 ? 12 : 15, ang, alpha(acc, 0.95f), 0xFF1A1632);
        String name = Thermal.coolerName(level);
        text(g, font.plainSubstrByWidth(name, (int) ((r[2] - 4) / 0.55f)), r[0] + 3, r[1] + r[3] - 7, 0xFFE8E4F5, 0.55f);
    }

    private void drawCpu(GuiGraphics g, int[] r, float t) {
        frame(g, r[0], r[1], r[2], r[3], 0xFF4A5078, 0xFF262A44);
        for (int i = 3; i < r[2] - 3; i += 4) {                              // the pins around the chip
            g.fill(r[0] + i, r[1] + 2, r[0] + i + 1, r[1] + 4, 0xFFD8C27A);
            g.fill(r[0] + i, r[1] + r[3] - 4, r[0] + i + 1, r[1] + r[3] - 2, 0xFFD8C27A);
            g.fill(r[0] + 2, r[1] + i, r[0] + 4, r[1] + i + 1, 0xFFD8C27A);
            g.fill(r[0] + r[2] - 4, r[1] + i, r[0] + r[2] - 2, r[1] + i + 1, 0xFFD8C27A);
        }
        if (on()) rr(g, r[0] + 5, r[1] + 5, r[2] - 10, r[3] - 10, alpha(accent(), 0.20f + 0.12f * (float) Math.sin(t * 5)));
        icon(g, stackOf(S_CPU), r[0] + 6, r[1] + 6, 2f);
        if (st[16] == 1) {                                                   // a blob of thermal paste on the chip
            circle(g, r[0] + r[2] - 11, r[1] + 11, 3, 0xFFB8C0D8);
            circle(g, r[0] + r[2] - 12, r[1] + 10, 1, 0xFFFFFFFF);
        }
        int cpu = val(S_CPU);
        text(g, Build.CPU_CORES[cpu] + "C", r[0] + r[2] - 17, r[1] + r[3] - 9, 0xFFFFFFFF, 0.7f);
    }

    private void drawGpu(GuiGraphics g, int[] r, float t) {
        int acc = accent();
        frame(g, r[0], r[1], r[2], r[3] - 4, 0xFF4A5078, 0xFF30354F);
        g.fill(r[0] + 2, r[1] + 2, r[0] + r[2] - 2, r[1] + 4, alpha(acc, 0.8f));
        for (int i = 4; i < r[2] - 4; i += 3) g.fill(r[0] + i, r[1] + r[3] - 4, r[0] + i + 2, r[1] + r[3] - 1, 0xFFD8C27A);      // the gold teeth
        icon(g, stackOf(S_GPU), r[0] + 4, r[1] + 3, 1.5f);
        int gpu = val(S_GPU);
        String name = font.plainSubstrByWidth(PcHardware.GPU_NAMES[gpu], (int) (56 / 0.7f));
        text(g, name, r[0] + 32, r[1] + 8, 0xFFFFFFFF, 0.7f);
        text(g, PcHardware.VRAM_GB[gpu] + " GB", r[0] + 32, r[1] + 17, alpha(acc, 0.95f), 0.7f);
        float ang = on() ? t * 540f : 0f;
        fan(g, r[0] + r[2] - 33, r[1] + 12, 9, ang, 0xFFB8C0E8, 0xFF1A1E34);
        fan(g, r[0] + r[2] - 13, r[1] + 12, 9, -ang, 0xFFB8C0E8, 0xFF1A1E34);
    }

    private void drawCard(GuiGraphics g, int[] r, ItemStack s, boolean isDisk) {
        frame(g, r[0], r[1], r[2], r[3], 0xFF4A5078, 0xFF2E3350);
        icon(g, s, r[0] + 1, r[1] + 1, 1f);
        String label;
        if (isDisk) {
            int gb = PcHardware.DISK_GB[val(S_DISK)];
            label = gb >= 1000 ? (gb / 1000) + " TB" : gb + " GB";
        } else {
            label = PcHardware.MODEM_MBPS[val(S_MODEM)] + " Mbit";
        }
        text(g, label, r[0] + 19, r[1] + 5, 0xFFFFFFFF, 0.75f);
        g.fill(r[0] + r[2] - 4, r[1] + 3, r[0] + r[2] - 2, r[1] + 5, on() ? 0xFF8CF0A8 : 0xFF54506C);      // the little light
    }

    private void drawPsu(GuiGraphics g, int[] r, float t) {
        frame(g, r[0], r[1], r[2], r[3], 0xFF50567E, 0xFF353B5C);
        for (int i = 0; i < 4; i++) g.fill(r[0] + 30, r[1] + 6 + i * 4, r[0] + r[2] - 5, r[1] + 7 + i * 4, 0x66000000);       // the grill
        fan(g, r[0] + 17, r[1] + 24, 12, on() ? t * 360f : 0f, 0xFFB8C0E8, 0xFF1D2138);
        int w = Build.PSU_WATTS[val(S_PSU)];
        text(g, w + " W", r[0] + 31, r[1] + 26, accent(), 0.9f);
        text(g, "PSU", r[0] + 31, r[1] + 37, 0xFF8A8FB0, 0.65f);
    }

    private void drawStick(GuiGraphics g, int[] r, int gb, float t) {
        int idx = 0;
        for (int i = 0; i < Build.STICK_GB.length; i++) if (Build.STICK_GB[i] == gb) idx = i + 1;       // 2 GB (stock) = 0
        int body = STICK_COL[Math.min(idx, STICK_COL.length - 1)];
        frame(g, r[0], r[1], r[2], r[3], mix(body, 0xFF000000, 0.5f), mix(body, 0xFF1A1632, 0.55f));
        for (int i = 0; i < 3; i++) {
            g.fill(r[0] + 2, r[1] + 5 + i * 15, r[0] + r[2] - 2, r[1] + 15 + i * 15, 0xFF14122A);
            g.fill(r[0] + 3, r[1] + 6 + i * 15, r[0] + r[2] - 3, r[1] + 7 + i * 15, alpha(0xFFFFFF, 0.25f));
        }
        g.fill(r[0] + 1, r[1] + r[3] - 3, r[0] + r[2] - 1, r[1] + r[3] - 1, 0xFFD8C27A);
        g.fill(r[0] + 2, r[1] + 1, r[0] + r[2] - 2, r[1] + 3, on() ? alpha(body, 0.6f + 0.4f * (float) Math.sin(t * 4 + r[0])) : alpha(body, 0.3f));
        String s = String.valueOf(gb);
        text(g, s, r[0] + r[2] / 2f - font.width(s) * 0.6f / 2f, r[1] + 47, 0xFFFFFFFF, 0.6f);
    }

    private void drawTray(GuiGraphics g, int mx, int my, float t) {
        int acc = accent();
        int x = ox + TX, y = oy + TY;
        frame(g, x, y, TW, TH, mix(acc, 0xFF2A2640, 0.6f), 0xFF110E24);
        text(g, Component.translatable("cutemod.build.tray"), x + 5, y + 4, acc, 0.75f);
        g.fill(x + 4, y + HEAD - 2, x + TW - 4, y + HEAD - 1, alpha(acc, 0.25f));

        List<Entry> list = entries();
        if (list.isEmpty()) {
            List<FormattedCharSequence> lines = font.split(Component.translatable("cutemod.build.tray.empty"), (int) ((TW - 10) / 0.7f));
            float ty = y + HEAD + 6;
            for (FormattedCharSequence l : lines) {
                g.pose().pushPose();
                g.pose().translate(x + 5, ty, 0f);
                g.pose().scale(0.7f, 0.7f, 1f);
                g.drawString(font, l, 0, 0, 0xFF8A8FB0, false);
                g.pose().popPose();
                ty += 7;
            }
            return;
        }
        int rows = (list.size() + COLS - 1) / COLS;
        int vis = (TH - HEAD - 4) / CELL;
        scroll = Math.max(0, Math.min(Math.max(0, rows - vis), scroll));
        g.enableScissor(x + 2, y + HEAD, x + TW - 2, y + TH - 2);
        for (int i = 0; i < list.size(); i++) {
            int[] c = cell(i);
            if (c[1] + 20 < y + HEAD || c[1] > y + TH) continue;
            Entry e = list.get(i);
            boolean sel = e.inv() == held;
            boolean hov = in(new int[]{c[0], c[1], 20, 20}, mx, my) && my >= y + HEAD && my < y + TH - 2;
            rr(g, c[0], c[1], 20, 20, sel ? alpha(acc, 0.9f) : hov ? alpha(acc, 0.5f) : 0xFF2A2548);
            rr(g, c[0] + 1, c[1] + 1, 18, 18, sel ? 0xFF3A2F5E : 0xFF171330);
            float bob = sel ? (float) Math.sin(t * 8) * 0.8f : 0f;
            icon(g, e.stack(), c[0] + 2, c[1] + 2 + bob, 1f);
            g.renderItemDecorations(font, e.stack(), c[0] + 2, c[1] + 2);
            if (sel) g.fill(c[0] + 1, c[1] + 1, c[0] + 19, c[1] + 19, 0x55110E24);
        }
        g.disableScissor();
        if (rows > vis) {                                                          // the scroll bar
            int bh = TH - HEAD - 6;
            int th = Math.max(8, bh * vis / rows);
            int ty = y + HEAD + (bh - th) * scroll / Math.max(1, rows - vis);
            g.fill(x + TW - 4, y + HEAD, x + TW - 3, y + HEAD + bh, 0x33FFFFFF);
            g.fill(x + TW - 4, ty, x + TW - 3, ty + th, alpha(acc, 0.9f));
        }
    }

    private void drawBottom(GuiGraphics g, int mx, int my, float t) {
        int acc = accent();
        Build b = build();
        boolean complete = missingText(st).getString().isEmpty();

        // the power button
        int[] pill = {ox + 8, oy + 186, 84, 24};
        boolean hov = in(pill, mx, my);
        int border = on() ? 0xFF8CF0A8 : complete ? acc : 0xFF6B5A78;
        rr(g, pill[0], pill[1], pill[2], pill[3], hov ? border : alpha(border, 0.7f));
        rr(g, pill[0] + 1, pill[1] + 1, pill[2] - 2, pill[3] - 2, on() ? 0xFF1B3A2E : 0xFF1B1636);
        int led = on() ? mix(0xFF2E8A5A, 0xFF8CF0A8, 0.5f + 0.5f * (float) Math.sin(t * 4)) : complete ? mix(0xFF6B5A78, acc, 0.5f + 0.5f * (float) Math.sin(t * 3)) : 0xFF6B4A5A;
        circle(g, pill[0] + 13, pill[1] + 12, 7, 0xFF0E0B1E);
        circle(g, pill[0] + 13, pill[1] + 12, 5, led);
        g.fill(pill[0] + 12, pill[1] + 6, pill[0] + 15, pill[1] + 12, 0xFF0E0B1E);               // the "power" sign
        g.fill(pill[0] + 13, pill[1] + 6, pill[0] + 14, pill[1] + 12, 0xFFFFFFFF);
        text(g, Component.translatable(on() ? "cutemod.build.power.turnoff" : "cutemod.build.power.turnon"), pill[0] + 26, pill[1] + 8, 0xFFFFFFFF, 0.85f);

        // the power meter
        int mx0 = ox + 100, my0 = oy + 187;
        boolean hasPsu = val(S_PSU) >= 0;
        int load = b.load(), supply = hasPsu ? b.supply() : 0;
        Component meter = hasPsu ? Component.translatable("cutemod.build.watts", load, supply) : Component.translatable("cutemod.build.watts.none");
        text(g, meter, mx0, my0, 0xFFE8E4F5, 0.75f);
        rr(g, mx0, my0 + 10, 128, 6, 0xFF0E0B1E);
        if (hasPsu) {
            float ratio = Math.min(1f, load / (float) supply);
            int fill = load > supply ? 0xFFFF6B7A : ratio > 0.8f ? 0xFFFFD86B : 0xFF7FF0C8;
            int w = Math.max(2, (int) (126 * ratio));
            g.fill(mx0 + 1, my0 + 11, mx0 + 1 + w, my0 + 15, fill);
            g.fill(mx0 + 1, my0 + 11, mx0 + 1 + w, my0 + 12, alpha(0xFFFFFF, 0.3f));
        }
        boolean weak = hasPsu && b.powerShort();
        Component hint = weak ? Component.translatable("cutemod.build.watts.weak")
                : Component.translatable(heldStack().isEmpty() ? "cutemod.build.hint.pick" : "cutemod.build.hint.held");
        text(g, hint, mx0, my0 + 19, weak ? 0xFFFFB45A : 0xFF8A8FB0, 0.65f);

        // the state
        Component state;
        int stateColor;
        if (on()) { state = Component.translatable("cutemod.build.state.on"); stateColor = 0xFF8CF0A8; }
        else if (complete) { state = Component.translatable("cutemod.build.state.ready"); stateColor = acc; }
        else { state = Component.translatable("cutemod.case.missing", missingText(st)); stateColor = 0xFFFFB45A; }
        float ty = oy + 188;
        for (FormattedCharSequence l : font.split(state, (int) ((TW - 4) / 0.7f))) {
            g.pose().pushPose();
            g.pose().translate(ox + TX + 2, ty, 0f);
            g.pose().scale(0.7f, 0.7f, 1f);
            g.drawString(font, l, 0, 0, stateColor, false);
            g.pose().popPose();
            ty += 7;
            if (ty > oy + H - 6) break;
        }
    }

    // ---------- the heat, the cables and the RGB (the row under the case) ----------
    private int[] tempRect(int k) { return new int[]{ox + 8 + k * 66, oy + 215, 62, 18}; }

    private int[] cablesRect() { return new int[]{ox + 142, oy + 215, 90, 18}; }

    private int[] rgbRect() { return new int[]{ox + 238, oy + 215, 62, 18}; }

    private int[] swatchRect() { return new int[]{ox + 304, oy + 215, 22, 18}; }

    /** The full-load temperatures {processor, video card (0 = none)} of what is inside now: the same maths as the server. */
    private int[] temps() {
        int cooler = st[12];
        int cpu = Math.max(0, st[1]), gpu = Math.max(0, st[3]);
        return new int[]{Thermal.cpuTemp(Build.CPU_WATTS[cpu], Math.max(0, cooler), cooler == -2, st[13], st[16] == 1),
                Thermal.gpuTemp(gpu, Build.GPU_WATTS[gpu], Math.max(0, cooler), st[13])};
    }

    private static int heatColor(int temp) {
        return temp >= Thermal.CRIT ? 0xFFFF6B7A : temp >= Thermal.THROTTLE ? 0xFFFF9A3C : temp >= 75 ? 0xFFFFD86B : 0xFF8CF0A8;
    }

    private void drawTemp(GuiGraphics g, int[] r, String label, int temp, float t) {
        boolean none = temp <= 0;
        int c = none ? 0xFF6A7088 : heatColor(temp);
        boolean blink = temp >= Thermal.CRIT && (int) (t * 4) % 2 == 0;
        rr(g, r[0], r[1], r[2], r[3], alpha(c, blink ? 0.9f : 0.55f));
        rr(g, r[0] + 1, r[1] + 1, r[2] - 2, r[3] - 2, 0xFF1B1636);
        circle(g, r[0] + 7, r[1] + 9, 2, c);
        text(g, label, r[0] + 13, r[1] + 3, 0xFF8A8FB0, 0.6f);
        text(g, none ? "-" : temp + "\u00B0C", r[0] + 13, r[1] + 10, c, 0.75f);
    }

    private void drawHeatRow(GuiGraphics g, int mx, int my, float t) {
        int acc = accent();
        int[] tp = temps();
        drawTemp(g, tempRect(0), "CPU", tp[0], t);
        drawTemp(g, tempRect(1), "GPU", tp[1], t);

        int[] cb = cablesRect();
        boolean has = val(S_CABLES) >= 0;
        boolean hov = in(cb, mx, my);
        rr(g, cb[0], cb[1], cb[2], cb[3], hov && has ? acc : alpha(acc, has ? 0.45f : 0.2f));
        rr(g, cb[0] + 1, cb[1] + 1, cb[2] - 2, cb[3] - 2, 0xFF1B1636);
        Component cl = has ? Component.translatable("cutemod.build.cables.btn", st[13]) : Component.translatable("cutemod.build.cables.none");
        text(g, cl, cb[0] + 6, cb[1] + 5, has ? 0xFFFFFFFF : 0xFF6A7088, 0.75f);
        if (has) {                                                                       // a little bar of how neat they are
            g.fill(cb[0] + 6, cb[1] + 14, cb[0] + cb[2] - 6, cb[1] + 15, 0xFF0E0B1E);
            g.fill(cb[0] + 6, cb[1] + 14, cb[0] + 6 + (cb[2] - 12) * st[13] / 100, cb[1] + 15, st[13] >= 70 ? 0xFF8CF0A8 : st[13] >= 40 ? 0xFFFFD86B : 0xFFFF9A3C);
        }

        int[] rg = rgbRect();
        int c = rgbArgb(t);
        boolean rhov = in(rg, mx, my);
        rr(g, rg[0], rg[1], rg[2], rg[3], rhov ? acc : alpha(acc, 0.45f));
        rr(g, rg[0] + 1, rg[1] + 1, rg[2] - 2, rg[3] - 2, 0xFF1B1636);
        text(g, Component.translatable("cutemod.build.rgb." + Math.max(0, Math.min(3, st[14]))), rg[0] + 6, rg[1] + 5, 0xFFFFFFFF, 0.75f);
        int[] sw = swatchRect();
        boolean shov = in(sw, mx, my);
        rr(g, sw[0], sw[1], sw[2], sw[3], shov ? acc : alpha(acc, 0.45f));
        int swc = c != 0 ? c : 0xFF000000 | ACCENT[Math.floorMod(st[15], ACCENT.length)];
        rr(g, sw[0] + 4, sw[1] + 4, sw[2] - 8, sw[3] - 8, c != 0 ? swc : alpha(swc, 0.35f));
    }

    private void drawSparks(GuiGraphics g, long now) {
        sparks.removeIf(s -> now - s.born > 700);
        for (Spark s : sparks) {
            float age = (now - s.born) / 1000f;
            float x = s.x + s.vx * age, y = s.y + s.vy * age + 60f * age * age;
            float a = 1f - age / 0.7f;
            int c = alpha(s.rgb, a);
            int sz = (int) s.size;
            g.fill((int) x, (int) y, (int) x + sz, (int) y + sz, c);
            if (sz > 1) {
                g.fill((int) x - 1, (int) y, (int) x, (int) y + sz, alpha(s.rgb, a * 0.5f));
                g.fill((int) x + sz, (int) y, (int) x + sz + 1, (int) y + sz, alpha(s.rgb, a * 0.5f));
            }
        }
    }

    private void drawToast(GuiGraphics g, long now) {
        if (now >= toastUntil || toast.getString().isEmpty()) return;
        float left = (toastUntil - now) / 2600f;
        float a = Math.min(1f, left * 4f);
        int w = Math.min(W - 20, (int) (font.width(toast) * 0.85f) + 16);
        int x = ox + (W - w) / 2, y = oy + H + 6 - (int) ((1f - a) * 4);
        if (y + 16 > height) y = oy + H - 40;
        rr(g, x, y, w, 15, alpha(toastColor, a * 0.95f));
        rr(g, x + 1, y + 1, w - 2, 13, alpha(0x14102A, a * 0.97f));
        text(g, toast, x + 8, y + 4, alpha(toastColor, a), 0.85f);
    }

    private void drawHeld(GuiGraphics g, int mx, int my, float t) {
        ItemStack hs = heldStack();
        if (hs.isEmpty()) return;
        g.pose().pushPose();
        g.pose().translate(0f, 0f, 300f);
        float bob = (float) Math.sin(t * 8) * 1.5f;
        g.fill(mx - 6, my + 11, mx + 8, my + 13, 0x44000000);
        icon(g, hs, mx - 10, my - 12 + bob, 1.25f);
        g.pose().popPose();
    }

    private void drawTooltips(GuiGraphics g, int mx, int my) {
        // a part of the tray
        List<Entry> list = entries();
        for (int i = 0; i < list.size(); i++) {
            int[] c = cell(i);
            if (my < oy + TY + HEAD || my >= oy + TY + TH - 2) break;
            if (in(new int[]{c[0], c[1], 20, 20}, mx, my)) { g.renderTooltip(font, list.get(i).stack(), mx, my); return; }
        }
        if (in(tempRect(0), mx, my) || in(tempRect(1), mx, my)) {
            g.renderComponentTooltip(font, List.of(Component.translatable("cutemod.build.heat.tip", Thermal.THROTTLE, Thermal.CRIT),
                    Component.translatable("cutemod.build.heat.tip2").withStyle(net.minecraft.ChatFormatting.GRAY)), mx, my);
            return;
        }
        if (in(cablesRect(), mx, my)) {
            g.renderComponentTooltip(font, List.of(Component.translatable("cutemod.build.cables.tip"),
                    Component.translatable("cutemod.build.cables.tip2").withStyle(net.minecraft.ChatFormatting.GRAY)), mx, my);
            return;
        }
        if (in(rgbRect(), mx, my) || in(swatchRect(), mx, my)) {
            g.renderComponentTooltip(font, List.of(Component.translatable("cutemod.build.rgb.tip")), mx, my);
            return;
        }
        int slot = slotAt(mx, my);
        if (slot < 0) return;
        ItemStack hs = heldStack();
        if (!hs.isEmpty()) {                                                      // why it does not fit here
            if (!belongs(hs, slot)) return;
            String why = reason(hs);
            if (why != null) g.renderComponentTooltip(font, List.of(Component.translatable(why, hs.getHoverName()).withStyle(net.minecraft.ChatFormatting.RED)), mx, my);
            return;
        }
        int v = val(slot);
        List<Component> tip = new ArrayList<>();
        if (v >= 0) {
            tip.add(stackOf(slot).getHoverName());
            tip.add(Component.translatable("cutemod.build.take").withStyle(net.minecraft.ChatFormatting.GRAY));
            if (slot == S_CPU) tip.add(Component.translatable(st[16] == 1 ? "cutemod.build.paste.on" : "cutemod.build.paste.off").withStyle(net.minecraft.ChatFormatting.DARK_AQUA));
        } else {
            tip.add(Component.translatable(slotKey(slot)));
            tip.add(Component.translatable(locked(slot) ? "cutemod.build.locked" : "cutemod.build.empty").withStyle(net.minecraft.ChatFormatting.GRAY));
        }
        g.renderComponentTooltip(font, tip, mx, my);
    }
}
