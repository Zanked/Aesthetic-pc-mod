package dev.cutemod.net;

import dev.cutemod.data.ParkData;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The Pet Park on the server: who is in the park right now and where, plays between two pets, friendship and the
 * small coin rewards. The park itself is not saved (only the friendship and the daily totals are, in {@link ParkData}).
 * The pets themselves are sent by the clients and cannot be verified.
 */
public final class ParkServer {
    private ParkServer() {}

    private record Member(String name, String color, boolean sick, PetLook look, int x, int y, int emote, long emoteUntil, long seen, long playUntil) {}

    public static final int MAX_PETS = 16, X_MAX = 300, Y_MIN = 70, Y_MAX = 150, NEAR = 110;
    private static final long ALIVE_MS = 6000, MOVE_GAP_MS = 80, EMOTE_MS = 3000, PLAY_MS = 2500, PAIR_GAP_MS = 15_000;
    private static final int COINS_PER_PLAY = 2, DAILY_CAP = 20;

    private static final Map<UUID, Member> park = new LinkedHashMap<>();
    private static final Map<UUID, Long> lastMove = new HashMap<>();
    private static final Map<String, Long> lastPlay = new HashMap<>();

    private static String clean(String s, int max) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length() && sb.length() < max; i++) { char c = s.charAt(i); if (c >= 32 && c != 127) sb.append(c); }
        return sb.toString();
    }

    private static void expire(long now) {
        for (Iterator<Member> it = park.values().iterator(); it.hasNext(); ) if (now - it.next().seen() > ALIVE_MS) it.remove();
    }

    public static void move(ServerPlayer sp, ParkMovePayload p) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        long now = System.currentTimeMillis();
        Long last = lastMove.get(sp.getUUID());
        if (last != null && now - last < MOVE_GAP_MS) return;
        lastMove.put(sp.getUUID(), now);
        expire(now);
        UUID me = sp.getUUID();
        if (p.sick()) { park.remove(me); sync(sp, 0, "", 0, 0); return; }               // a sick pet rests at home
        if (!park.containsKey(me) && park.size() >= MAX_PETS) { sync(sp, 2, "", 0, 0); return; }
        Member old = park.get(me);
        int x = Math.max(0, Math.min(X_MAX, p.x())), y = Math.max(Y_MIN, Math.min(Y_MAX, p.y()));
        int emote = old == null ? 0 : old.emote();
        long until = old == null ? 0 : old.emoteUntil();
        if (p.emote() >= 1 && p.emote() <= 3) { emote = p.emote(); until = now + EMOTE_MS; }
        if (until < now) emote = 0;
        PetLook l = p.look();
        PetLook look = new PetLook(Math.max(0, Math.min(2, l.stage())), Math.max(0, Math.min(4, l.trait())), Math.max(0, l.ageMin()), clean(l.head(), 64), clean(l.body(), 64));
        park.put(me, new Member(sp.getGameProfile().getName(), clean(p.color(), 16), false, look, x, y, emote, until, now, old == null ? 0 : old.playUntil()));
        sync(sp, 0, "", 0, 0);
    }

    public static void leave(UUID id) {
        park.remove(id);
        lastMove.remove(id);
    }

    /** My pet plays with the pet of the player with this id. */
    public static void play(ServerPlayer sp, String targetId) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        UUID target;
        try { target = UUID.fromString(targetId); } catch (IllegalArgumentException e) { return; }
        UUID me = sp.getUUID();
        long now = System.currentTimeMillis();
        expire(now);
        Member a = park.get(me), b = park.get(target);
        if (a == null || b == null || me.equals(target)) return;
        if (Math.abs(a.x() - b.x()) > NEAR || Math.abs(a.y() - b.y()) > NEAR) return;       // too far from each other
        String pair = ParkData.pair(me, target);
        Long last = lastPlay.get(pair);
        if (last != null && now - last < PAIR_GAP_MS) return;
        lastPlay.put(pair, now);
        ParkData data = ParkData.get(server);
        int n = data.addPlay(me, target);
        long day = now / 86_400_000L;
        int lvl = ParkData.level(n), bonus = n == ParkData.LEVEL_AT[lvl > 0 ? lvl - 1 : 0] ? ParkData.LEVEL_BONUS[Math.max(0, lvl - 1)] : 0;
        park.put(me, new Member(a.name(), a.color(), false, a.look(), a.x(), a.y(), a.emote(), a.emoteUntil(), a.seen(), now + PLAY_MS));
        park.put(target, new Member(b.name(), b.color(), false, b.look(), b.x(), b.y(), b.emote(), b.emoteUntil(), b.seen(), now + PLAY_MS));
        int mine = data.pay(me, COINS_PER_PLAY, DAILY_CAP, day) + bonus;
        int theirs = data.pay(target, COINS_PER_PLAY, DAILY_CAP, day) + bonus;
        sync(sp, 1, b.name(), n, mine);
        ServerPlayer other = server.getPlayerList().getPlayer(target);
        if (other != null) sync(other, 1, a.name(), n, theirs);
    }

    private static void sync(ServerPlayer sp, int event, String with, int plays, int prize) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        long now = System.currentTimeMillis();
        ParkData data = ParkData.get(server);
        List<ParkSyncPayload.Pet> out = new ArrayList<>();
        for (Map.Entry<UUID, Member> e : park.entrySet()) {
            if (e.getKey().equals(sp.getUUID())) continue;
            Member m = e.getValue();
            out.add(new ParkSyncPayload.Pet(e.getKey().toString(), m.name(), m.color(), m.look(), m.sick(), m.x(), m.y(),
                    m.emoteUntil() > now ? m.emote() : 0, m.playUntil() > now, data.plays(sp.getUUID(), e.getKey())));
        }
        PacketDistributor.sendToPlayer(sp, new ParkSyncPayload(event, with, plays, prize, out));
    }
}
