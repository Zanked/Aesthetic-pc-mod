package dev.cutemod.client.os;

import dev.cutemod.data.ShowBoard;
import dev.cutemod.net.PetLook;
import dev.cutemod.net.ShowActionPayload;
import dev.cutemod.net.ShowPutPayload;
import dev.cutemod.net.ShowRequestPayload;
import dev.cutemod.net.ShowSyncPayload;
import net.neoforged.neoforge.network.PacketDistributor;

/** The talent show on the client: sends what the player does and keeps the last stage the server sent. */
public final class Show {
    private Show() {}

    private static ShowSyncPayload last;

    public static void apply(ShowSyncPayload p) {
        last = p;
        // ten gold cups: the champion's laurels are yours for good (they cannot be bought)
        if (p.fame().gold() >= ShowBoard.OUTFIT_GOLD && Progress.grant("acc_champion")) Progress.toast("cutemod.toast.champion");
        // the knight's helmet and armor: gold cups on the way to the laurels
        for (dev.cutemod.data.PetWear.Item w : dev.cutemod.data.PetWear.ALL) {
            if (w.src() == dev.cutemod.data.PetWear.Src.SHOW && !w.id().equals("acc_champion") && p.fame().gold() >= w.at() && Progress.grant(w.id()))
                Progress.toast("cutemod.toast.newwear", net.minecraft.network.chat.Component.translatable("cutemod.shop.item." + w.id()).getString());
        }
        if (p.head().phase() == ShowBoard.RESULTS && p.me().entered() && p.me().rank() > 0) writeLetter(p);
    }

    /** After the results of a round we took part in, one judge writes to us (once per round). */
    private static void writeLetter(ShowSyncPayload p) {
        int round = (int) ShowBoard.roundOf(System.currentTimeMillis());
        var player = net.minecraft.client.Minecraft.getInstance().player;
        if (player == null || Progress.count("show_lr") == round) return;
        String me = player.getUUID().toString();
        ShowSyncPayload.Entry mine = null;
        for (ShowSyncPayload.Entry e : p.pets()) if (!e.bot() && e.who().owner().equals(me)) mine = e;
        if (mine == null || mine.score().stars().size() < 4) return;
        var stars = mine.score().stars();
        int best = 0, weak = 0;                                   // who liked it most / least
        for (int j = 1; j < stars.size(); j++) {
            if (stars.get(j) > stars.get(best)) best = j;
            if (stars.get(j) < stars.get(weak)) weak = j;
        }
        Progress.setCount("show_lr", round);
        Mail.showLetter(best, stars.get(best), mine.score().total(), p.me().rank(), p.head().theme(), weak);
    }

    /** Your cups and the hall of fame (null before the first answer of the server). */
    public static ShowSyncPayload.Fame fame() { return last == null ? null : last.fame(); }

    /** The title your gold cups give you ("" if none yet). */
    public static String myTitle() {
        ShowSyncPayload.Fame f = fame();
        int lvl = f == null ? 0 : ShowBoard.titleLevel(f.gold());
        return lvl > 0 ? net.minecraft.network.chat.Component.translatable("cutemod.show.rank." + lvl).getString() : "";
    }

    /** The last stage (null before the first answer). */
    public static ShowSyncPayload last() { return last; }

    public static void clear() { last = null; }

    /** Ask the server for the stage as it is now. */
    public static void request() { PacketDistributor.sendToServer(new ShowRequestPayload()); }

    /** The show has paid us: the coins are ours (0 = the daily limit of the show is used up). */
    public static void prize(int coins, int rank) {
        if (coins > 0) Progress.earn(coins);
        if (rank >= 1 && rank <= 3) Progress.toast("cutemod.show.cup." + rank);   // a cup for the shelf
        request();                                                                // and the shelf learns about it
    }

    /** Put the pet of this computer color on the stage, as it is right now (or refresh it). False if that pet does not exist yet. */
    public static boolean exhibit(String colorId) {
        PetBlob.Info i = PetBlob.parse(Store.read("pet_" + colorId));
        if (i == null) return false;
        PacketDistributor.sendToServer(new ShowPutPayload(colorId, i.sick(),
                new PetLook(i.stage(), i.trait(), i.ageMin(), short24(Progress.equipped()), short24(Progress.equippedBody()))));
        return true;
    }

    public static void withdraw(String colorId) { PacketDistributor.sendToServer(new ShowActionPayload(ShowActionPayload.WITHDRAW, "", colorId)); }

    public static void like(String owner, String colorId) { PacketDistributor.sendToServer(new ShowActionPayload(ShowActionPayload.LIKE, owner, colorId)); }

    public static void unlike(String owner, String colorId) { PacketDistributor.sendToServer(new ShowActionPayload(ShowActionPayload.UNLIKE, owner, colorId)); }

    private static String short24(String s) { return s == null || s.length() > 64 ? "" : s; }
}
