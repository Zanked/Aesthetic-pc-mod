package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** The shop: spend the coins you earned on wallpapers, pet accessories and songs. */
public class ShopApp extends App {
    private record Item(String id, int price) {}

    private static final Item[] ITEMS = {
            new Item("wall6", 40), new Item("wall7", 40), new Item("wall8", 60),
            new Item("wall9", 50), new Item("wall10", 50), new Item("wall11", 70),
            new Item("acc_flower", 35), new Item("acc_glasses", 30), new Item("acc_bow", 30),
            new Item("acc_cap", 40), new Item("acc_party", 40), new Item("acc_hat", 50),
            new Item("acc_halo", 80),
            new Item("acc_crown", 0), // a reward for finishing the story, not for sale
            new Item("track4", 40), new Item("track5", 60), new Item("track6", 50), new Item("track7", 70),
            new Item("treat_cookie", 5), new Item("treat_fish", 8), new Item("treat_honey", 12),
            new Item("treat_milk", 10), new Item("treat_cake", 20),
    };
    private static final String[] TAB_KINDS = {"", "wall", "acc", "track", "treat"};
    private static final int TAB_Y = 18, TAB_H = 12, TAB_W = 60, TOP = 32, ROW = 24, VISIBLE = 5, BTN_W = 78;

    private int scroll, tab;

    @Override
    public Component title() { return Component.translatable("cutemod.os.shop"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.shop"); }

    private static String kind(String id) { return id.startsWith("treat") ? "treat" : id.startsWith("wall") ? "wall" : id.startsWith("acc") ? "acc" : "track"; }

    /** The items of the selected tab. */
    private List<Item> view() {
        List<Item> out = new ArrayList<>();
        for (Item it : ITEMS) if (tab == 0 || kind(it.id()).equals(TAB_KINDS[tab])) out.add(it);
        return out;
    }

    private int maxScroll() { return Math.max(0, view().size() - VISIBLE); }

    /** Text of the button for this item, or null if there is nothing to press. */
    private String action(Item it) {
        boolean own = Progress.owned(it.id());
        switch (kind(it.id())) {
            case "wall" -> {
                if (!own) return "buy";
                return Wallpaper.get() == Integer.parseInt(it.id().substring(4)) ? "using" : "set";
            }
            case "acc" -> {
                if (!own) return it.price() == 0 ? "story" : "buy";
                return Progress.equipped().equals(it.id()) ? "take_off" : "wear";
            }
            case "treat" -> { return "buy"; } // consumable: you can buy as many as you like
            default -> { return own ? "have" : "buy"; }
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, 0xFFFFF6D8);
        rect(g, 0, 0, W, 17, 0xFFF5C518);
        g.drawString(f, t("cutemod.os.shop"), 6, 5, 0xFF3A2A3A, false);
        String bal = Integer.toString(Progress.coins());
        g.drawString(f, bal, W - 6 - f.width(bal), 5, 0xFF3A2A3A, false);
        Progress.drawCoin(g, W - 16 - f.width(bal), 5);

        // tabs
        for (int i = 0; i < 5; i++) {
            boolean sel = i == tab, hover = in(mx, my, i * TAB_W, TAB_Y, TAB_W, TAB_H);
            rect(g, i * TAB_W, TAB_Y, TAB_W, TAB_H, sel ? 0xFFB57BD6 : (hover ? 0xFFE0D0F0 : 0xFFEFE6F7));
            String s = t("cutemod.shop.tab." + i);
            g.drawString(f, s, i * TAB_W + (TAB_W - f.width(s)) / 2, TAB_Y + 2, sel ? 0xFFFFFFFF : 0xFF3A2A3A, false);
        }

        List<Item> items = view();
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= items.size()) break;
            Item it = items.get(idx);
            int y = TOP + v * ROW;
            rect(g, 0, y, W, ROW - 1, v % 2 == 0 ? 0xFFFFFFFF : 0xFFFFF0C0);
            icon(g, it.id(), 6, y + 2);
            String name = t("cutemod.shop.item." + it.id());
            g.drawString(f, name, 32, y + 4, 0xFF3A2A3A, false);
            boolean treat = kind(it.id()).equals("treat");
            if (treat && Progress.stock(it.id()) > 0) g.drawString(f, "x" + Progress.stock(it.id()), 36 + f.width(name), y + 4, 0xFFB98A10, false);
            g.drawString(f, treat ? t("cutemod.shop.eff." + it.id()) : t("cutemod.shop.kind." + kind(it.id())), 32, y + 14, 0xFF8A7AA8, false);
            if (it.price() > 0 && (treat || !Progress.owned(it.id()))) {
                String p = Integer.toString(it.price());
                int px = W - BTN_W - 14 - f.width(p);
                Progress.drawCoin(g, px - 10, y + 8);
                g.drawString(f, p, px, y + 8, Progress.coins() >= it.price() ? 0xFF3A2A3A : 0xFFE5484D, false);
            }
            String a = action(it);
            boolean can = !(a.equals("using") || a.equals("have") || a.equals("story") || (a.equals("buy") && Progress.coins() < it.price()));
            boolean hover = can && in(mx, my, W - BTN_W - 6, y + 3, BTN_W, 17);
            rect(g, W - BTN_W - 6, y + 3, BTN_W, 17, !can ? 0xFFD8CCE2 : hover ? 0xFF8A6AC6 : 0xFFB57BD6);
            String label = t("cutemod.shop.btn." + a);
            g.drawString(f, label, W - BTN_W - 6 + (BTN_W - f.width(label)) / 2, y + 8, can ? 0xFFFFFFFF : 0xFF8A7AA8, false);
        }

        if (maxScroll() > 0) { // scroll bar
            rect(g, W - 3, TOP, 3, VISIBLE * ROW, 0xFFE9DDF2);
            int th = Math.max(8, VISIBLE * ROW * VISIBLE / items.size());
            rect(g, W - 3, TOP + (VISIBLE * ROW - th) * scroll / maxScroll(), 3, th, 0xFFB57BD6);
        }
    }

    /** A little picture (20 x 20) of the item. */
    private void icon(GuiGraphics g, String id, int x, int y) {
        rect(g, x - 1, y - 1, 22, 22, 0xFF3A2A4A);
        switch (kind(id)) {
            case "wall" -> Wallpaper.draw(g, x, y, 20, 20, shell.color().bodyColor, Integer.parseInt(id.substring(4)));
            case "treat" -> {
                rect(g, x, y, 20, 20, 0xFFFFF0C0);
                PetApp.drawTreat(g, id, x + 5, y + 5);
            }
            case "track" -> {
                rect(g, x, y, 20, 20, 0xFF6A4A9A);
                disc(g, x + 7, y + 14, 3, 0xFFFFFFFF);
                rect(g, x + 9, y + 4, 2, 11, 0xFFFFFFFF);
                rect(g, x + 9, y + 4, 6, 2, 0xFFFFFFFF);
            }
            default -> {
                rect(g, x, y, 20, 20, 0xFFFFF0C0);
                switch (id) {
                    case "acc_glasses" -> {
                        rect(g, x + 2, y + 7, 7, 5, 0xFF111111);
                        rect(g, x + 11, y + 7, 7, 5, 0xFF111111);
                        rect(g, x + 9, y + 8, 2, 1, 0xFF111111);
                    }
                    case "acc_bow" -> {
                        disc(g, x + 5, y + 10, 3, 0xFFFF5C93);
                        disc(g, x + 15, y + 10, 3, 0xFFFF5C93);
                        rect(g, x + 8, y + 8, 4, 5, 0xFFD93A72);
                    }
                    case "acc_hat" -> {
                        rect(g, x + 5, y + 3, 10, 10, 0xFF1A1A22);
                        rect(g, x + 2, y + 13, 16, 3, 0xFF1A1A22);
                        rect(g, x + 5, y + 10, 10, 2, 0xFFE5484D);
                    }
                    case "acc_party" -> {
                        for (int r = 0; r < 14; r++) rect(g, x + 10 - (r / 2 + 1), y + 4 + r, (r / 2 + 1) * 2, 1, 0xFFB57BD6);
                        rect(g, x + 7, y + 11, 6, 1, 0xFFFFFFFF);
                        disc(g, x + 10, y + 4, 2, 0xFFFFD84A);
                    }
                    case "acc_halo" -> {
                        rect(g, x + 4, y + 6, 12, 2, 0xFFFFE680);
                        rect(g, x + 4, y + 12, 12, 2, 0xFFFFE680);
                        rect(g, x + 2, y + 8, 2, 4, 0xFFFFE680);
                        rect(g, x + 16, y + 8, 2, 4, 0xFFFFE680);
                    }
                    case "acc_flower" -> {
                        disc(g, x + 10, y + 5, 2, 0xFFFF8AC0);
                        disc(g, x + 10, y + 15, 2, 0xFFFF8AC0);
                        disc(g, x + 5, y + 10, 2, 0xFFFF8AC0);
                        disc(g, x + 15, y + 10, 2, 0xFFFF8AC0);
                        disc(g, x + 10, y + 10, 3, 0xFFFFD84A);
                    }
                    case "acc_cap" -> {
                        rect(g, x + 4, y + 6, 12, 7, 0xFF2F9BFF);
                        rect(g, x + 4, y + 12, 16, 2, 0xFF2F7ACF);
                        rect(g, x + 9, y + 4, 2, 2, 0xFF2F7ACF);
                    }
                    default -> { // crown
                        rect(g, x + 3, y + 11, 14, 5, 0xFFFFD84A);
                        for (int r = 0; r < 6; r++) {
                            rect(g, x + 3 + r / 3, y + 5 + r, Math.max(1, 3 - r / 3), 1, 0xFFFFD84A);
                            rect(g, x + 9, y + 3 + r, 2, 1, 0xFFFFD84A);
                            rect(g, x + 14 - r / 3, y + 5 + r, Math.max(1, 3 - r / 3), 1, 0xFFFFD84A);
                        }
                        rect(g, x + 9, y + 12, 2, 2, 0xFFE5484D);
                    }
                }
            }
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (in(x, y, 0, TAB_Y, TAB_W * 5, TAB_H)) {
            int i = x / TAB_W;
            if (i >= 0 && i < 5 && i != tab) { tab = i; scroll = 0; }
            return true;
        }
        List<Item> items = view();
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= items.size()) break;
            Item it = items.get(idx);
            int ry = TOP + v * ROW;
            if (!in(x, y, W - BTN_W - 6, ry + 3, BTN_W, 17)) continue;
            switch (action(it)) {
                case "buy" -> {
                    if (kind(it.id()).equals("treat")) Progress.buyTreat(it.id(), it.price());
                    else if (Progress.buy(it.id(), it.price())) {
                        if (kind(it.id()).equals("wall")) Wallpaper.set(Integer.parseInt(it.id().substring(4)));
                        else if (kind(it.id()).equals("acc")) Progress.equip(it.id());
                    }
                }
                case "set" -> Wallpaper.set(Integer.parseInt(it.id().substring(4)));
                case "wear" -> Progress.equip(it.id());
                case "take_off" -> Progress.equip("");
                default -> { }
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll + (amount < 0 ? 1 : -1)));
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        switch (keyCode) {
            case 264 -> scroll = Math.min(maxScroll(), scroll + 1);                   // down
            case 265 -> scroll = Math.max(0, scroll - 1);                             // up
            case 262 -> { tab = Math.min(4, tab + 1); scroll = 0; }                   // right
            case 263 -> { tab = Math.max(0, tab - 1); scroll = 0; }                   // left
            default -> { return false; }
        }
        return true;
    }
}
