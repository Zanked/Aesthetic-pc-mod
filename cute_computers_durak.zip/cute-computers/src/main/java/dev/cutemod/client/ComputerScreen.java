package dev.cutemod.client;

import dev.cutemod.ComputerColor;
import dev.cutemod.block.ComputerBlockEntity;
import dev.cutemod.client.os.App;
import dev.cutemod.client.os.Desktop;
import dev.cutemod.client.os.Dock;
import dev.cutemod.client.os.Haunt;
import dev.cutemod.client.os.Library;
import dev.cutemod.client.os.Progress;
import dev.cutemod.client.os.Shell;
import dev.cutemod.client.os.Wallpaper;
import dev.cutemod.net.ScorePayload;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.net.URI;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** The "monitor": a little desktop with games, a browser and other apps. */
public class ComputerScreen extends Screen implements Shell {
    private static final int PAD = 10;
    private static final int HEADER = 8;     // thin frame above the screen
    private static final int MENU = 12;      // menu bar
    private static final int TB = 12;        // window title bar (traffic lights)
    private static final int DOCK = Dock.HEIGHT;
    private static final int FOOTER = 20;
    private static final int VIEW_W = App.W;
    private static final long STEP_NS = 16_666_667L; // apps run at 60 steps/second
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("EEE HH:mm");

    private final ComputerColor color;
    private final BlockPos pos;
    private final Desktop desktop = new Desktop();
    private final Haunt haunt = new Haunt();
    private final Dock dock = new Dock();
    private boolean menuOpen;
    private App app;

    private int left, top, gx, gy, panelW, panelH, menuY, dockY;
    private long lastNs = 0, acc = 0;

    public ComputerScreen(ComputerColor color, BlockPos pos) {
        super(Component.translatable("cutemod.os.title"));
        this.color = color;
        this.pos = pos;
        open(desktop);
    }

    // ---------- Shell ----------
    @Override
    public void open(App next) {
        if (app != null) app.close();
        app = next;
        app.attach(this);
        acc = 0;
    }

    @Override
    public void home() { open(desktop); }

    @Override
    public ComputerColor color() { return color; }

    @Override
    public void openLink(String url) {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(new ConfirmLinkScreen(accepted -> {
            if (accepted) {
                try {
                    Util.getPlatform().openUri(URI.create(url));
                } catch (Exception ignored) {
                }
            }
            mc.setScreen(this);
        }, url, true));
    }

    @Override
    public void submitScore(ComputerColor game, int score) {
        // only the computer's own game counts for the record stored in the block
        if (game == color) PacketDistributor.sendToServer(new ScorePayload(pos, score));
    }

    @Override
    public int absX() { return gx; }

    @Override
    public int absY() { return gy; }

    // ---------- Screen ----------
    @Override
    protected void init() {
        panelW = VIEW_W + PAD * 2;
        panelH = HEADER + MENU + TB + App.H + DOCK + FOOTER;
        left = (width - panelW) / 2;
        top = (height - panelH) / 2;
        menuY = top + HEADER;
        gx = left + PAD;
        gy = menuY + MENU + TB;       // top-left of the app area
        dockY = gy + App.H;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        app.close();
        Progress.save();
        Library.save();
        super.removed();
    }

    private ComputerBlockEntity be() {
        var level = Minecraft.getInstance().level;
        if (level != null && level.getBlockEntity(pos) instanceof ComputerBlockEntity b) return b;
        return null;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        super.render(g, mouseX, mouseY, partial);

        // --- fixed timestep for the apps ---
        long now = System.nanoTime();
        if (lastNs == 0) lastNs = now;
        acc += now - lastNs;
        lastNs = now;
        if (acc > 100_000_000L) acc = 100_000_000L;
        app.mouse(mouseX - gx, mouseY - gy);
        while (acc >= STEP_NS) {
            acc -= STEP_NS;
            app.tick();
            haunt.tick(app);
            Progress.tick();
            Library.tick();
        }

        // --- computer casing ---
        int body = 0xFF000000 | color.bodyColor;
        boolean darkBody = luminance(color.bodyColor) < 110;
        int textCol = darkBody ? 0xFFFFFFFF : 0xFF3A2A3A;
        int viewH = MENU + TB + App.H + DOCK;
        g.fill(left - 3, top - 3, left + panelW + 3, top + panelH + 3, 0xFF2A2030);
        g.fill(left - 2, top - 2, left + panelW + 2, top + panelH + 2, body);
        g.fill(left - 2, top - 2, left + panelW + 2, top - 1, 0x66FFFFFF);
        g.fill(gx - 4, menuY - 4, gx + VIEW_W + 4, menuY + viewH + 4, 0xFF1B1422);

        // --- wallpaper behind the menu bar, the apps and the Dock ---
        Wallpaper.draw(g, gx, menuY, VIEW_W, viewH, color.bodyColor, Wallpaper.get());

        // --- window title bar with the "traffic lights" (not on the bare desktop) ---
        boolean onDesktop = app == desktop;
        int tbY = gy - TB;
        if (!onDesktop) {
            g.fillGradient(gx, tbY, gx + VIEW_W, gy, 0xFFEEE9F3, 0xFFD9D3E3);
            g.fill(gx, gy - 1, gx + VIEW_W, gy, 0xFFB9B0C8);
            boolean overLights = mouseX >= gx + 2 && mouseX < gx + 36 && mouseY >= tbY && mouseY < gy;
            int[] cols = {0xFFFF5F57, 0xFFFEBC2E, 0xFF28C840};
            for (int i = 0; i < 3; i++) {
                int cx = gx + 8 + i * 10, cy = tbY + TB / 2;
                circle(g, cx, cy, 3, overLights ? cols[i] : (cols[i] & 0x00FFFFFF) | 0xFF000000);
                circle(g, cx, cy, 2, shadeUp(cols[i]));
            }
            Component title = app.title();
            g.drawString(font, title, gx + (VIEW_W - font.width(title)) / 2, tbY + 2, 0xFF3A2A3A, false);
        }

        // --- app ---
        g.enableScissor(gx, gy, gx + VIEW_W, gy + App.H);
        g.pose().pushPose();
        g.pose().translate(gx, gy, 0);
        app.render(g, mouseX - gx, mouseY - gy);
        haunt.render(g, mouseX - gx, mouseY - gy);
        Progress.renderToast(g);
        g.pose().popPose();
        g.disableScissor();

        // --- menu bar ---
        g.fill(gx, menuY, gx + VIEW_W, menuY + MENU, 0x99101018);
        drawLogo(g, gx + 5, menuY + 3);
        Component name = (onDesktop ? Component.translatable("cutemod.os.title") : app.title()).copy().withStyle(ChatFormatting.BOLD);
        g.drawString(font, name, gx + 19, menuY + 2, 0xFFFFFFFF, false);
        Component status = app.status();
        int sx = gx + 19 + font.width(name) + 10;
        if (!status.getString().isEmpty() && sx + font.width(status) < gx + VIEW_W - 80) {
            g.drawString(font, status, sx, menuY + 2, 0xCCFFFFFF, false);
        }
        String clock = LocalDateTime.now().format(CLOCK);
        g.drawString(font, clock, gx + VIEW_W - 5 - font.width(clock), menuY + 2, 0xFFFFFFFF, false);
        String coinText = Integer.toString(Progress.coins());
        int coinX = gx + VIEW_W - 5 - font.width(clock) - 10 - font.width(coinText);
        Progress.drawCoin(g, coinX - 10, menuY + 2);
        g.drawString(font, coinText, coinX, menuY + 2, 0xFFFFE680, false);

        // --- Dock ---
        dock.render(g, desktop, app, color.bodyColor, gx, dockY, VIEW_W, mouseX, mouseY);

        // --- the logo menu ---
        if (menuOpen) {
            int mxp = gx + 2, myp = menuY + MENU, mw = 92, mh = 3 * 12 + 4;
            g.fill(mxp - 1, myp - 1, mxp + mw + 1, myp + mh + 1, 0x55FFFFFF);
            g.fill(mxp, myp, mxp + mw, myp + mh, 0xF01B1422);
            String[] items = {Component.translatable("cutemod.os.desktop").getString(),
                    Component.translatable("cutemod.os.settings").getString(),
                    Component.translatable("cutemod.os.quit").getString()};
            for (int i = 0; i < 3; i++) {
                int iy = myp + 2 + i * 12;
                boolean hov = mouseX >= mxp && mouseX < mxp + mw && mouseY >= iy && mouseY < iy + 12;
                if (hov) g.fill(mxp + 2, iy, mxp + mw - 2, iy + 12, 0xFFB57BD6);
                g.drawString(font, items[i], mxp + 8, iy + 2, 0xFFFFFFFF, false);
            }
        }

        // --- footer: record + hint ---
        if (app.showRecord()) {
            ComputerBlockEntity be = be();
            boolean spooky = haunt.recordHaunted();
            Component rec = spooky
                    ? Component.translatable("cutemod.ui.record", 999999, Component.translatable("cutemod.haunt.holder"))
                    : (be == null || be.getHighScore() <= 0)
                    ? Component.translatable("cutemod.ui.record_none")
                    : Component.translatable("cutemod.ui.record", be.getHighScore(), be.getHolder());
            g.drawString(font, rec, left + PAD, dockY + DOCK + 8, spooky ? 0xFFD9302A : textCol, false);
        }
        Component hint = app.hint();
        g.drawString(font, hint, left + panelW - PAD - font.width(hint), dockY + DOCK + 8, textCol, false);
    }

    private static void circle(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    private static int shadeUp(int argb) {
        int r = Math.min(255, ((argb >> 16) & 255) + 28), gr = Math.min(255, ((argb >> 8) & 255) + 28), b = Math.min(255, (argb & 255) + 28);
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }

    /** A tiny pixel heart, the "logo" of Cute OS. */
    private static void drawLogo(GuiGraphics g, int x, int y) {
        int c = 0xFFFFFFFF;
        g.fill(x + 1, y, x + 3, y + 1, c);
        g.fill(x + 4, y, x + 6, y + 1, c);
        g.fill(x, y + 1, x + 7, y + 3, c);
        g.fill(x + 1, y + 3, x + 6, y + 4, c);
        g.fill(x + 2, y + 4, x + 5, y + 5, c);
        g.fill(x + 3, y + 5, x + 4, y + 6, c);
    }

    private static int luminance(int rgb) {
        int r = (rgb >> 16) & 255, gr = (rgb >> 8) & 255, b = rgb & 255;
        return (int) (0.299 * r + 0.587 * gr + 0.114 * b);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int mx = (int) Math.floor(mouseX), my = (int) Math.floor(mouseY);

        if (menuOpen) {                                         // the logo menu eats the click
            int mxp = gx + 2, myp = menuY + MENU, mw = 92;
            menuOpen = false;
            if (mx >= mxp && mx < mxp + mw && my >= myp + 2 && my < myp + 2 + 3 * 12) {
                switch ((my - myp - 2) / 12) {
                    case 0 -> home();
                    case 1 -> desktop.launch(6);
                    default -> onClose();
                }
                return true;
            }
            if (!(mx >= gx + 2 && mx < gx + 16 && my >= menuY && my < menuY + MENU)) return true;
        }
        if (mx >= gx + 2 && mx < gx + 16 && my >= menuY && my < menuY + MENU) {   // logo
            menuOpen = !menuOpen;
            return true;
        }
        int icon = dock.hit(gx, dockY, VIEW_W, mx, my);
        if (icon >= 0) {
            if (desktop.activeIndex(app) != icon) desktop.launch(icon);
            return true;
        }
        int lx = mx - gx, ly = my - gy;
        if (lx >= 0 && lx < VIEW_W && ly >= 0 && ly < App.H) {
            if (!haunt.click(lx, ly, button)) app.click(lx, ly, button);
            return true;
        }
        if (app != desktop && lx >= 2 && lx < 36 && ly >= -TB && ly < 0) {       // traffic lights
            if (lx < 22) home();                                                  // red and yellow: back to the desktop
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        int lx = (int) Math.floor(mouseX - gx), ly = (int) Math.floor(mouseY - gy);
        if (app.drag(lx, ly, button)) return true;
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (app.scroll(scrollY)) return true;
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (app.key(keyCode, modifiers)) return true;
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (app.charTyped(codePoint)) return true;
        return super.charTyped(codePoint, modifiers);
    }
}
