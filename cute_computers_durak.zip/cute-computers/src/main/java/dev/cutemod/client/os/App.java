package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * A program that runs on the computer desktop. The app area is W x H GUI pixels,
 * all coordinates passed to the app are local (0,0 = top-left of the area).
 */
public abstract class App {
    public static final int W = 300;
    public static final int H = 166;

    protected Shell shell;

    public void attach(Shell shell) { this.shell = shell; }

    public abstract Component title();

    /** Called 60 times per second. */
    public void tick() {}

    public abstract void render(GuiGraphics g, int mx, int my);

    /** Mouse position, called every frame before the ticks. */
    public void mouse(int x, int y) {}

    public boolean click(int x, int y, int button) { return false; }

    public boolean drag(int x, int y, int button) { return false; }

    public boolean key(int keyCode, int modifiers) { return false; }

    public boolean charTyped(char c) { return false; }

    public boolean scroll(double amount) { return false; }

    /** Called when the app is closed / the computer screen is left. */
    public void close() {}

    public Component hint() { return Component.empty(); }

    public Component status() { return Component.empty(); }

    /** Show the computer's high score in the footer. */
    public boolean showRecord() { return false; }

    // ---------- helpers ----------
    protected static Font font() { return Minecraft.getInstance().font; }

    protected static String t(String key, Object... args) {
        return Component.translatable(key, args).getString();
    }

    protected static void rect(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + h, argb);
    }

    protected static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    protected static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && py >= y && px < x + w && py < y + h;
    }

    /** Blend an rgb color toward another one (f = 0..1). Result is opaque ARGB. */
    public static int mix(int rgb, int target, float f) {
        int r = (int) (((rgb >> 16) & 255) * (1 - f) + ((target >> 16) & 255) * f);
        int gr = (int) (((rgb >> 8) & 255) * (1 - f) + ((target >> 8) & 255) * f);
        int b = (int) ((rgb & 255) * (1 - f) + (target & 255) * f);
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }
}
