package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

/**
 * CuteTube (cutetube.cute): a tiny video site that lives inside the browser.
 * <ul>
 *   <li>every "video" is a little animation drawn with rectangles (see the scene methods at the bottom);</li>
 *   <li>the sound is a looping note-block tune (same sounds as the Music app);</li>
 *   <li>comments: a few ready-made ones per video + the ones you type yourself (kept until the game is closed).</li>
 * </ul>
 * The BrowserApp draws this app under its toolbar and forwards mouse / keyboard to it.
 */
public class TubeApp extends App {
    /** Height of the area the browser gives us (its toolbar is above). */
    public static final int TH = H - 20;
    /** Y of this area inside the app window (set by the browser, needed for scissor). */
    public int oy = 20;

    private static final int COUNT = 7, HORROR = 6, CMT = 3;   // the last video is only listed while Spooky is on
    private static final int[] LEN = {1800, 1500, 1200, 1800, 2100, 2400, 1800};   // video length in ticks (60 = 1 s)
    private static final int[] VIEWS = {1243, 987, 2210, 5001, 640, 8800, 1};
    private static final int[] LIKES = {120, 87, 301, 512, 64, 940, 666};
    private static final int[] UNIT = {14, 7, 6, 8, 10, 12, 10};                 // ticks per tune unit
    private static final int[] INSTR = {0, 0, 1, 3, 1, 3, 3};                   // 0 harp, 1 bell, 3 chime
    /** Tunes as {note, length} pairs (note 0..24, -1 = rest). They loop for the whole video. */
    private static final int[][] TUNE = {
            {6, 1, 6, 1, 13, 1, 13, 1, 15, 1, 15, 1, 13, 2, 11, 1, 11, 1, 10, 1, 10, 1, 8, 1, 8, 1, 6, 2},
            {10, 2, 10, 2, 11, 2, 13, 2, 13, 2, 11, 2, 10, 2, 8, 2, 6, 2, 6, 2, 8, 2, 10, 2, 10, 3, 8, 1, 8, 4},
            {13, 1, 15, 1, 18, 2, 15, 1, 13, 1, 10, 2, 13, 1, 15, 1, 18, 2, 20, 4, 18, 1, 15, 1, 13, 2, 10, 4},
            {10, 6, 13, 2, 16, 6, 13, 2, 10, 4, 9, 4, 10, 8, -1, 8},
            {10, 3, 13, 3, 15, 2, 13, 4, 10, 3, 8, 3, 6, 2, 8, 4},
            {6, 6, 10, 6, 13, 6, 18, 10, 15, 6, 13, 6, 10, 6, 8, 10},
            {10, 4, 9, 4, -1, 2, 10, 4, 9, 4, -1, 2, 16, 2, 15, 2, 16, 2, 15, 2, -1, 12}   // horror: a creeping tritone
    };
    private static final int[] TOTAL = new int[COUNT];
    private static final boolean[] LIKED = new boolean[COUNT];
    private static final List<List<String>> MINE = new ArrayList<>();         // comments typed by the player

    static {
        for (int i = 0; i < COUNT; i++) {
            int sum = 0;
            for (int k = 1; k < TUNE[i].length; k += 2) sum += TUNE[i][k];
            TOTAL[i] = sum * UNIT[i];
            MINE.add(new ArrayList<>());
        }
    }

    // ---------- layout ----------
    private static final int PX = 4, PY = 4, PW = 146, PH = 82;               // player screen
    private static final int BAR_Y = 89, BTN_Y = 98;                          // progress bar, button row
    private static final int VX = 102, VW = 46;                               // volume slider
    private static final int CX = 156, CY = 16, CW = 136, CH = 100;           // comments list
    private static final int[] HX = {30, 104, 18};                            // x of the floating hearts

    private record CLine(FormattedCharSequence seq, int color, int y) {}

    private int view;                 // 0 = list of videos, 1 = watching
    private int vid, t, ticks;        // current video, its time in ticks, free-running clock
    private boolean playing, typing;
    private float vol = 0.6F;
    private String draft = "";
    private final List<CLine> cl = new ArrayList<>();
    private int cScroll, cH, cy, lScroll;   // comments scroll, comments height, wrap cursor, list scroll

    @Override
    public Component title() { return Component.translatable("cutemod.tube.title"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.tube.hint"); }

    @Override
    public void close() {
        playing = false;
        typing = false;
    }

    // ---------- logic ----------
    @Override
    public void tick() {
        ticks++;
        if (view == 1 && vid == HORROR && !Haunt.scary) { view = 0; playing = false; }   // Spooky was switched off
        if (view != 1 || !playing) return;
        int[] m = TUNE[vid];
        int p = t % TOTAL[vid], at = 0;                  // where we are inside the looping tune
        for (int k = 0; k < m.length; k += 2) {
            if (at == p && m[k] >= 0) MusicApp.note(INSTR[vid], m[k], vol * 0.8F);
            at += m[k + 1] * UNIT[vid];
        }
        int bar = UNIT[vid] * 4;
        if (p % bar == 0) MusicApp.note(2, (p / bar) % 2 == 0 ? (vid == HORROR ? 1 : 6) : (vid == HORROR ? 0 : 13), vol);   // bass (a low heartbeat in the horror)
        if (vid == HORROR && t == 1440) {                                       // the jump scare: a loud ugly chord
            float loud = Math.min(1F, vol + 0.3F);
            MusicApp.note(2, 0, loud);
            MusicApp.note(3, 23, loud);
            MusicApp.note(3, 24, loud);
            MusicApp.note(0, 1, loud);
        }
        if (++t >= LEN[vid]) { t = LEN[vid]; playing = false; Progress.onVideoEnd(vid); }                 // video ended
    }

    private void watch(int i) {
        vid = i;
        t = 0;
        playing = true;
        view = 1;
        typing = false;
        draft = "";
        cScroll = 0;
        buildComments();
    }

    private void toggle() {
        if (!playing && t >= LEN[vid]) t = 0;            // replay
        playing = !playing;
    }

    private void seek(int x) { t = Math.max(0, Math.min(LEN[vid] - 1, (x - PX) * LEN[vid] / PW)); }

    private void setVol(int x) { vol = Math.max(0.05F, Math.min(1F, (x - VX) / (float) VW)); }

    private void send() {
        String s = draft.trim();
        if (s.isEmpty()) return;
        MINE.get(vid).add(s);
        draft = "";
        cScroll = 0;
        buildComments();
        MusicApp.note(1, 18, 0.8F);
    }

    // ---------- comments ----------
    private int commentCount() { return CMT + MINE.get(vid).size(); }

    private int maxC() { return Math.max(0, cH - CH); }

    private void addComment(String text, int color) {
        for (FormattedCharSequence s : font().split(FormattedText.of(text), CW - 8)) {
            cl.add(new CLine(s, color, cy));
            cy += 9;
        }
        cy += 4;
    }

    /** Wrap all comments of the current video into lines (the player's own come first). */
    private void buildComments() {
        cl.clear();
        cy = 2;
        String name = Minecraft.getInstance().getUser().getName();
        String me = "@" + name + ": ";
        List<String> mine = MINE.get(vid);
        for (int k = mine.size() - 1; k >= 0; k--) addComment(me + mine.get(k), 0xFFB5427A);
        for (int k = 0; k < CMT; k++) addComment(t("cutemod.tube.c." + vid + "." + k, name), 0xFF3A2A3A);
        cH = cy;
        cScroll = Math.min(cScroll, maxC());
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        rect(g, 0, 0, W, TH, 0xFFFFFAFD);
        if (view == 0) renderList(g, mx, my); else renderWatch(g, mx, my);
    }

    private static String clock(int ticks) {
        int s = ticks / 60;
        return s / 60 + ":" + (s % 60 < 10 ? "0" : "") + s % 60;
    }

    private static void heart(GuiGraphics g, int x, int y, int col) {
        rect(g, x + 1, y, 2, 1, col);
        rect(g, x + 4, y, 2, 1, col);
        rect(g, x, y + 1, 7, 1, col);
        rect(g, x + 1, y + 2, 5, 1, col);
        rect(g, x + 2, y + 3, 3, 1, col);
        rect(g, x + 3, y + 4, 1, 1, col);
    }

    private void button(GuiGraphics g, int mx, int my, int x, int y, int w, String s) {
        rect(g, x, y, w, 14, in(mx, my, x, y, w, 14) ? 0xFFFFFFFF : 0xFFF1E6F8);
        g.drawString(font(), s, x + (w - font().width(s)) / 2, y + 3, 0xFF3A2A3A, false);
    }

    private int shown() { return Haunt.scary ? COUNT : COUNT - 1; }

    private int listMax() { return Math.max(0, 19 + (shown() + 1) / 2 * 42 - TH); }

    private void renderList(GuiGraphics g, int mx, int my) {
        lScroll = Math.min(lScroll, listMax());
        rect(g, 0, 16, W, 1, 0xFFE0D4EA);
        rect(g, 6, 3, 20, 11, 0xFFE02A2A);                                   // logo: red button with a play triangle
        for (int k = 0; k < 4; k++) rect(g, 13 + k, 5 + k, 1, 7 - 2 * k, 0xFFFFFFFF);
        g.drawString(font(), t("cutemod.tube.title"), 30, 4, 0xFF3A2A3A, false);

        g.enableScissor(shell.absX(), shell.absY() + oy + 17, shell.absX() + W, shell.absY() + oy + TH);
        for (int i = 0; i < shown(); i++) {
            int x = 3 + (i % 2) * 148, y = 19 + (i / 2) * 42 - lScroll;
            if (y < -40 || y > TH) continue;
            boolean hover = my >= 17 && in(mx, my, x, y, 146, 40);
            if (hover) rect(g, x, y, 146, 40, 0xFFF1E6F8);
            g.pose().pushPose();                                              // thumbnail = the scene, scaled down
            g.pose().translate(x + 2, y + 3, 0);
            g.pose().scale(0.41F, 0.41F, 1F);
            scene(g, i, hover ? ticks % LEN[i] : (i == HORROR ? 700 : 50));   // hover = the preview moves
            g.pose().popPose();
            String len = clock(LEN[i]);
            int lw = font().width(len);
            rect(g, x + 61 - lw - 2, y + 26, lw + 2, 9, 0xAA000000);
            g.drawString(font(), len, x + 61 - lw - 1, y + 27, 0xFFFFFFFF, false);

            List<FormattedCharSequence> tl = font().split(FormattedText.of(t("cutemod.tube.v." + i)), 78);
            for (int l = 0; l < tl.size() && l < 2; l++) g.drawString(font(), tl.get(l), x + 66, y + 3 + l * 9, 0xFF3A2A3A, false);
            g.drawString(font(), t("cutemod.tube.ch." + i), x + 66, y + 22, 0xFF8A7AA8, false);
            g.drawString(font(), t("cutemod.tube.views", VIEWS[i]), x + 66, y + 31, 0xFF8A7AA8, false);
        }
        g.disableScissor();
        if (listMax() > 0) {                                                  // scrollbar
            rect(g, W - 3, 17, 2, TH - 17, 0xFFE9DDF2);
            int th = Math.max(12, (TH - 17) * (TH - 17) / (TH - 17 + listMax()));
            rect(g, W - 3, 17 + (TH - 17 - th) * lScroll / listMax(), 2, th, 0xFFB57BD6);
        }
    }

    private void renderWatch(GuiGraphics g, int mx, int my) {
        // player
        rect(g, PX - 1, PY - 1, PW + 2, PH + 2, 0xFF3A2A3A);
        g.enableScissor(shell.absX() + PX, shell.absY() + oy + PY, shell.absX() + PX + PW, shell.absY() + oy + PY + PH);
        g.pose().pushPose();
        g.pose().translate(PX, PY, 0);
        scene(g, vid, t);
        if (!playing) {                                                       // big "play" sign when paused / ended
            disc(g, 73, 41, 11, 0xAA000000);
            for (int k = 0; k < 6; k++) rect(g, 69 + k, 35 + k, 1, 12 - 2 * k, 0xFFFFFFFF);
        }
        g.pose().popPose();
        g.disableScissor();

        // progress bar
        int fill = PW * t / LEN[vid];
        rect(g, PX, BAR_Y, PW, 4, 0xFFD8CCE2);
        rect(g, PX, BAR_Y, fill, 4, 0xFFE02A2A);
        disc(g, PX + fill, BAR_Y + 2, 3, 0xFFE02A2A);

        // buttons: play/pause, back to the list, like, volume
        button(g, mx, my, PX, BTN_Y, 22, playing ? "||" : ">");
        button(g, mx, my, PX + 25, BTN_Y, 20, "<");
        boolean lk = LIKED[vid];
        rect(g, PX + 48, BTN_Y, 44, 14, lk ? 0xFFF9C6DA : (in(mx, my, PX + 48, BTN_Y, 44, 14) ? 0xFFFFFFFF : 0xFFF1E6F8));
        heart(g, PX + 53, BTN_Y + 4, lk ? 0xFFE02A2A : 0xFF8A7AA8);
        g.drawString(font(), String.valueOf(LIKES[vid] + (lk ? 1 : 0)), PX + 63, BTN_Y + 3, 0xFF3A2A3A, false);
        rect(g, VX, BTN_Y + 5, VW, 4, 0xFFD8CCE2);
        rect(g, VX, BTN_Y + 5, (int) (VW * vol), 4, 0xFFB57BD6);
        disc(g, VX + (int) (VW * vol), BTN_Y + 7, 3, 0xFFB57BD6);

        // info
        g.drawString(font(), font().plainSubstrByWidth(t("cutemod.tube.v." + vid), PW), PX, 116, 0xFF3A2A3A, false);
        g.drawString(font(), t("cutemod.tube.ch." + vid) + "  -  " + t("cutemod.tube.views", VIEWS[vid]), PX, 126, 0xFF8A7AA8, false);
        g.drawString(font(), clock(t) + " / " + clock(LEN[vid]), PX, 135, 0xFF8A7AA8, false);

        // comments
        g.drawString(font(), t("cutemod.tube.comments", commentCount()), CX, 4, 0xFF3A2A3A, false);
        rect(g, CX, CY - 2, CW, 1, 0xFFE0D4EA);
        g.enableScissor(shell.absX() + CX, shell.absY() + oy + CY, shell.absX() + CX + CW, shell.absY() + oy + CY + CH);
        for (CLine l : cl) {
            int y = CY + l.y() - cScroll;
            if (y < CY - 10 || y > CY + CH) continue;
            g.drawString(font(), l.seq(), CX + 2, y, l.color(), false);
        }
        g.disableScissor();
        if (cH > CH) {
            rect(g, CX + CW + 1, CY, 3, CH, 0xFFE9DDF2);
            int th = Math.max(12, CH * CH / cH);
            rect(g, CX + CW + 1, CY + (CH - th) * cScroll / maxC(), 3, th, 0xFFB57BD6);
        }

        // comment box
        rect(g, CX - 1, 119, CW + 2, 18, typing ? 0xFF4A7BD0 : 0xFFB9A8C8);
        rect(g, CX, 120, CW, 16, 0xFFFFFFFF);
        String shown = draft.isEmpty() && !typing ? t("cutemod.tube.add") : draft;
        while (shown.length() > 1 && font().width(shown) > CW - 8) shown = shown.substring(1);
        g.drawString(font(), shown, CX + 4, 124, draft.isEmpty() && !typing ? 0xFF9A8FA8 : 0xFF3A2A3A, false);
        if (typing && (ticks / 30) % 2 == 0) rect(g, CX + 4 + font().width(shown), 123, 1, 10, 0xFF3A2A3A);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (view == 0) {
            for (int i = 0; i < shown(); i++) {
                if (y >= 17 && in(x, y, 3 + (i % 2) * 148, 19 + (i / 2) * 42 - lScroll, 146, 40)) { watch(i); return true; }
            }
            return true;
        }
        typing = false;
        if (in(x, y, CX - 1, 119, CW + 2, 18)) { typing = true; return true; }
        if (in(x, y, PX, PY, PW, PH) || in(x, y, PX, BTN_Y, 22, 14)) { toggle(); return true; }
        if (in(x, y, PX, BAR_Y - 3, PW, 10)) { seek(x); return true; }
        if (in(x, y, PX + 25, BTN_Y, 20, 14)) { playing = false; view = 0; return true; }
        if (in(x, y, PX + 48, BTN_Y, 44, 14)) {
            LIKED[vid] = !LIKED[vid];
            if (LIKED[vid]) MusicApp.note(3, 22, 0.8F);
            return true;
        }
        if (in(x, y, VX - 3, BTN_Y, VW + 6, 14)) { setVol(x); return true; }
        return true;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (view != 1) return false;
        if (in(x, y, PX - 6, BAR_Y - 8, PW + 12, 20)) { seek(x); return true; }
        if (in(x, y, VX - 8, BTN_Y - 4, VW + 16, 22)) { setVol(x); return true; }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (view == 0) return false;
        if (typing) {
            switch (keyCode) {
                case 257, 335 -> send();                                      // enter
                case 256 -> typing = false;                                   // escape: leave the box only
                case 259 -> { if (!draft.isEmpty()) draft = draft.substring(0, draft.length() - 1); }
                case 86 -> {                                                  // ctrl+v
                    if (!Screen.hasControlDown()) return false;
                    String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                    if (clip != null) {
                        String s = draft + clip.replace("\n", " ").replace("\r", "");
                        draft = s.length() > 80 ? s.substring(0, 80) : s;
                    }
                }
                default -> { return false; }
            }
            return true;
        }
        switch (keyCode) {
            case 32 -> toggle();                                              // space
            case 262 -> t = Math.min(LEN[vid] - 1, t + 300);                  // right: +5 s
            case 263 -> t = Math.max(0, t - 300);                             // left: -5 s
            case 256 -> { playing = false; view = 0; }                        // escape: back to the list
            default -> { return false; }
        }
        return true;
    }

    @Override
    public boolean charTyped(char c) {
        if (view != 1 || !typing || c < 32 || c == 127) return false;
        if (draft.length() < 80) draft += c;
        return true;
    }

    @Override
    public boolean scroll(double amount) {
        if (view == 0) {
            lScroll = Math.max(0, Math.min(listMax(), lScroll - (int) Math.round(amount * 14)));
            return true;
        }
        if (view != 1) return false;
        cScroll = Math.max(0, Math.min(maxC(), cScroll - (int) Math.round(amount * 14)));
        return true;
    }

    // ---------- the "videos": every scene is drawn on a 146 x 82 screen, tm = time in ticks ----------
    private void scene(GuiGraphics g, int v, int tm) {
        switch (v) {
            case 0 -> panda(g, tm);
            case 1 -> slime(g, tm);
            case 2 -> bee(g, tm);
            case 3 -> creeper(g, tm);
            case 4 -> ocean(g, tm);
            case HORROR -> horror(g, Math.min(tm, LEN[HORROR] - 1));
            default -> night(g, tm);
        }
    }

    private void panda(GuiGraphics g, int tm) {
        g.fillGradient(0, 0, PW, PH, 0xFFFFD6E8, 0xFFFFB3D1);
        rect(g, 0, 66, PW, 16, 0xFF9AD6A0);
        int hop = (int) Math.round(Math.abs(Math.sin((tm % 28) * Math.PI / 28)) * 12);   // jumps on the beat
        int cx = 73 + (int) Math.round(Math.sin(tm / 45.0) * 34), y = 56 - hop;
        int arm = (tm / 14) % 2 == 0 ? -4 : 4;
        rect(g, cx - 9, 66, 18, 2, 0x33000000);                                          // shadow
        disc(g, cx - 14, y - 2 + arm, 4, 0xFF222222);                                    // arms
        disc(g, cx + 14, y - 2 - arm, 4, 0xFF222222);
        disc(g, cx - 7, y + 10, 4, 0xFF222222);                                          // legs
        disc(g, cx + 7, y + 10, 4, 0xFF222222);
        disc(g, cx, y, 12, 0xFFFFFFFF);                                                  // body
        disc(g, cx, y - 15, 10, 0xFFFFFFFF);                                             // head
        disc(g, cx - 8, y - 23, 4, 0xFF222222);                                          // ears
        disc(g, cx + 8, y - 23, 4, 0xFF222222);
        disc(g, cx - 4, y - 15, 3, 0xFF222222);                                          // eyes
        disc(g, cx + 4, y - 15, 3, 0xFF222222);
        rect(g, cx - 4, y - 16, 1, 1, 0xFFFFFFFF);
        rect(g, cx + 4, y - 16, 1, 1, 0xFFFFFFFF);
        rect(g, cx - 1, y - 11, 3, 2, 0xFF222222);                                       // nose
    }

    private void slime(GuiGraphics g, int tm) {
        g.fillGradient(0, 0, PW, PH, 0xFFBFE6FF, 0xFFE8F6FF);
        rect(g, 0, 66, PW, 16, 0xFF6FBF73);
        int h = (int) Math.round(Math.sin((tm % 40) / 40.0 * Math.PI) * 32);             // height above the ground
        boolean squash = h < 4;
        int w = squash ? 30 : 22, hh = squash ? 12 : 22;
        int cx = 73 + (int) Math.round(Math.sin(tm / 50.0) * 40), top = 66 - h - hh;
        rect(g, cx - (24 - h / 2) / 2, 66, 24 - h / 2, 2, 0x44000000);                   // shadow
        rect(g, cx - w / 2, top, w, hh, 0xFF5BBF6A);
        rect(g, cx - w / 2 + 2, top + 2, w - 4, 3, 0x66FFFFFF);
        rect(g, cx - 6, top + hh / 2 - 2, 3, 4, 0xFF1B3A1B);
        rect(g, cx + 3, top + hh / 2 - 2, 3, 4, 0xFF1B3A1B);
    }

    private void bee(GuiGraphics g, int tm) {
        g.fillGradient(0, 0, PW, PH, 0xFFBFE6FF, 0xFFFFF3B0);
        for (int k = 0; k < 6; k++) {                                                    // flowers
            int fx = 12 + k * 24, fh = 14 + (k * 7) % 10;
            rect(g, fx, PH - fh, 2, fh, 0xFF4CAF50);
            disc(g, fx + 1, PH - fh - 2, 5, k % 3 == 0 ? 0xFFF58FB8 : k % 3 == 1 ? 0xFFFFFFFF : 0xFFB57BD6);
            disc(g, fx + 1, PH - fh - 2, 2, 0xFFF3D46A);
        }
        int bx = 73 + (int) Math.round(Math.sin(tm / 30.0) * 52);
        int by = 28 + (int) Math.round(Math.sin(tm / 11.0) * 12), flap = (tm / 3) % 2;
        rect(g, bx + 1, by - 3 - flap * 2, 5, 4, 0xDDFFFFFF);                            // wings
        rect(g, bx + 8, by - 3 - flap * 2, 5, 4, 0xDDFFFFFF);
        rect(g, bx, by, 14, 9, 0xFFF5C518);                                              // body
        rect(g, bx + 4, by, 2, 9, 0xFF2A2A2A);
        rect(g, bx + 8, by, 2, 9, 0xFF2A2A2A);
        rect(g, bx + 11, by + 2, 2, 2, 0xFF2A2A2A);
    }

    private void creeper(GuiGraphics g, int tm) {
        g.fillGradient(0, 0, PW, PH, 0xFF1E3A2A, 0xFF3A6A4A);
        rect(g, 0, 70, PW, 12, 0xFF2A4A2A);
        int cx = 73, p = tm % 240;
        rect(g, cx - 9, 56, 8, 14, 0xFF4CAF50);                                          // legs
        rect(g, cx + 1, 56, 8, 14, 0xFF4CAF50);
        rect(g, cx - 8, 34, 16, 22, 0xFF4CAF50);                                         // body
        rect(g, cx - 11, 12, 22, 22, 0xFF5BBF6A);                                        // head
        rect(g, cx - 7, 17, 5, 5, 0xFF1B3A1B);                                           // face
        rect(g, cx + 2, 17, 5, 5, 0xFF1B3A1B);
        rect(g, cx - 2, 23, 4, 4, 0xFF1B3A1B);
        rect(g, cx - 4, 27, 2, 4, 0xFF1B3A1B);
        rect(g, cx + 2, 27, 2, 4, 0xFF1B3A1B);
        if (p >= 120 && p < 132 && (p / 3) % 2 == 0) rect(g, cx - 11, 12, 22, 58, 0x99FFFFFF);   // "ssss..."
        if (p >= 132) {                                                                  // ...and then: a hug, hearts fly up
            for (int k = 0; k < 3; k++) {
                int a = p - 132 - k * 8, hy = 46 - a * 2 / 5;
                if (a >= 0 && hy > 0) heart(g, HX[k], hy, 0xFFF58FB8);
            }
        }
    }

    private void ocean(GuiGraphics g, int tm) {
        g.fillGradient(0, 0, PW, 46, 0xFFFFC98A, 0xFFFFE9B8);
        disc(g, 110, 30, 10, 0xFFFFF3B0);
        rect(g, 0, 46, PW, 36, 0xFF2F7FD6);
        for (int x = 0; x < PW; x += 6) {                                                // waves
            rect(g, x, 44 + (int) Math.round(Math.sin((x + tm) / 9.0) * 2), 6, 3, 0xFF5BA8F0);
        }
        for (int k = 0; k < 3; k++) rect(g, (k * 53 + tm / 2) % PW, 58 + k * 8, 14, 1, 0x55FFFFFF);
        double u = (tm % 140) / 140.0;                                                   // a fish jumps out of the water
        int fx = 14 + (int) (u * 118), fy = 46 - (int) Math.round(Math.sin(u * Math.PI) * 32);
        if (fy < 44) {
            rect(g, fx, fy, 12, 6, 0xFFFF9F43);
            rect(g, fx - 4, fy + 1, 4, 4, 0xFFFF7A1A);
            rect(g, fx + 9, fy + 1, 1, 1, 0xFF3A2A3A);
        }
    }

    private void night(GuiGraphics g, int tm) {
        g.fillGradient(0, 0, PW, PH, 0xFF0B1030, 0xFF26306A);
        for (int k = 0; k < 28; k++) {                                                   // twinkling stars
            int b = (tm / 12 + k) % 4;
            rect(g, (k * 37 + 11) % 144, (k * 53 + 7) % 56, b == 0 ? 2 : 1, b == 0 ? 2 : 1, b == 3 ? 0x66FFFFFF : 0xFFFFFFFF);
        }
        disc(g, 112, 20, 9, 0xFFFFF3B0);                                                 // moon
        disc(g, 109, 17, 2, 0xFFE8D98A);
        disc(g, 115, 23, 2, 0xFFE8D98A);
        int s = tm % 300;                                                                // shooting star
        if (s < 30) for (int k = 0; k < 8; k++) rect(g, 20 + s * 3 - k * 2, 8 + s - k, 2, 1, ((255 - k * 30) << 24) | 0xFFFFFF);
        rect(g, 0, 68, PW, 14, 0xFF05071A);                                              // hills
        disc(g, 30, 70, 14, 0xFF05071A);
        disc(g, 100, 72, 18, 0xFF05071A);
    }

    /** A figure in dark purple with too-long arms. Origin = its feet. */
    private void figure(GuiGraphics g, int cx, int by, float sc, int tm, boolean grin) {
        g.pose().pushPose();
        g.pose().translate(cx, by, 0);
        g.pose().scale(sc, sc, 1F);
        int c = 0xFF1C1424;
        rect(g, -4, -34, 8, 26, c);                                                      // body
        rect(g, -4, -8, 3, 8, c);                                                        // legs
        rect(g, 1, -8, 3, 8, c);
        rect(g, -8, -33, 2, 28, c);                                                      // arms
        rect(g, 6, -33, 2, 28, c);
        disc(g, 0, -38, 5, c);                                                           // head
        if (tm % 90 < 80) {                                                              // white eyes, they blink
            rect(g, -3, -39, 2, 1, 0xFFFFFFFF);
            rect(g, 1, -39, 2, 1, 0xFFFFFFFF);
        }
        if (grin) rect(g, -3, -35, 6, 1, 0xFFFFFFFF);
        g.pose().popPose();
    }

    private static void eyes(GuiGraphics g, int x, int y, boolean open) {
        rect(g, x - 2, y - 2, 22, 7, 0x33FF0000);
        if (open) {
            rect(g, x, y, 6, 3, 0xFFFF2A2A);
            rect(g, x + 12, y, 6, 3, 0xFFFF2A2A);
            rect(g, x + 2, y + 1, 2, 1, 0xFF000000);
            rect(g, x + 14, y + 1, 2, 1, 0xFF000000);
        } else {
            rect(g, x, y + 1, 6, 1, 0xFF7A1010);
            rect(g, x + 12, y + 1, 6, 1, 0xFF7A1010);
        }
    }

    /**
     * Only listed while Spooky is on. 30 seconds: 0-10 s a quiet room, eyes in the corner;
     * 10-20 s something stands in the door; 20-24 s it comes closer; 24 s jump scare;
     * then static, and in the end it says your name.
     */
    private void horror(GuiGraphics g, int tm) {
        if (tm >= 1440) {                                                                // the end: all black
            rect(g, 0, 0, PW, PH, tm < 1500 && (tm / 2) % 2 == 0 ? 0xFF300000 : 0xFF000000);
            for (int k = 0; k < 6; k++) rect(g, (tm * 13 + k * 37) % PW, (tm * 7 + k * 11) % PH, 30, 1, 0x44FFFFFF);   // static (under everything else)
            if (tm < 1500) {                                                             // jump scare: giant face
                rect(g, 14, 20, 40, 24, 0xFFFFFFFF);
                rect(g, 92, 20, 40, 24, 0xFFFFFFFF);
                rect(g, 30, 28, 8, 9, 0xFFC00000);
                rect(g, 108, 28, 8, 9, 0xFFC00000);
                rect(g, 6, 56, 134, 2, 0xFFFFFFFF);
                for (int k = 0; k < 9; k++) {
                    rect(g, 12 + k * 14, 49, 4, 7, 0xFFFFFFFF);
                    rect(g, 19 + k * 14, 58, 4, 7, 0xFFFFFFFF);
                }
            } else if (tm < 1650) {
                eyes(g, 64, 38, (tm / 40) % 5 != 0);
            } else {
                String msg = t("cutemod.tube.see", Minecraft.getInstance().getUser().getName());
                g.drawString(font(), msg, (PW - font().width(msg)) / 2, 37, tm % 37 > 31 ? 0xFF3A0A10 : 0xFFD9534F, false);
            }
            return;
        }
        g.fillGradient(0, 0, PW, PH, 0xFF05030A, 0xFF140C1C);
        rect(g, 12, 10, 44, 38, 0xFF2A2030);                                             // window with a pale moon
        rect(g, 15, 13, 38, 32, 0xFF0B1030);
        disc(g, 40, 25, 6, 0xFFD8D8C0);
        rect(g, 32, 13, 2, 32, 0xFF2A2030);
        rect(g, 15, 28, 38, 2, 0xFF2A2030);
        rect(g, 0, 62, PW, 20, 0xFF0A0610);                                              // floor
        rect(g, 96, 14, 36, 48, 0xFF000000);                                             // open door into the dark
        if (tm >= 200 && tm < 320) eyes(g, 8, 66, tm < 270 || tm >= 276);               // eyes in the corner
        if (tm >= 600 && tm < 1200) figure(g, 114 - (tm - 600) / 100, 62, 1F, tm, false);   // it stands in the door
        if (tm >= 1200) {                                                                // ...and comes closer
            float p = (tm - 1200) / 240F;
            figure(g, 114 - (int) (41 * p), 62 + (int) (18 * p), 1F + p * p * 2.2F, tm, p > 0.6F);
        }
        int f = tm % 200;                                                                // flickering light
        if (tm >= 400 && ((f >= 188 && f < 192) || (f >= 196 && f < 198))) rect(g, 0, 0, PW, PH, 0xB0000000);
        if (tm >= 1200) for (int k = 0; k < 4; k++) rect(g, (tm * 13 + k * 37) % PW, (tm * 7 + k * 11) % PH, 30, 1, 0x33FFFFFF);
    }
}
