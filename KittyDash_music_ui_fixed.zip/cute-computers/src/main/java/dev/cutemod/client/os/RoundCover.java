package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import java.util.Locale;

/**
 * Album covers with rounded corners. The picture itself is cut in rows (the rows of the corners are a bit
 * shorter), so nothing has to be painted over it and it looks right on any background.
 */
public final class RoundCover {
    private RoundCover() {}

    /** Corner radius for a cover of this size. */
    public static int radius(int size) { return Math.max(2, Math.min(size / 2, Math.round(size * 0.2F))); }

    /** How many pixels the row dy (of h rows) is shorter on each side. */
    static int inset(int dy, int h, int r) {
        double m = dy + 0.5, e = m < r ? r - m : m > h - r ? m - (h - r) : 0;
        return e > 0 ? (int) Math.round(r - Math.sqrt(Math.max(0, r * r - e * e))) : 0;
    }

    /** The cover of an album (or a coloured tile with a letter if it has none), size x size, rounded. */
    public static void draw(GuiGraphics g, Albums.Album a, int x, int y, int size) {
        if (a.cover() != null && a.coverW() > 0 && a.coverH() > 0) {
            float sc = Math.min(size / (float) a.coverW(), size / (float) a.coverH());
            int w = Math.max(1, (int) (a.coverW() * sc)), h = Math.max(1, (int) (a.coverH() * sc));
            int ox = x + (size - w) / 2, oy = y + (size - h) / 2;
            int r = radius(Math.min(w, h)), tw = a.coverW(), th = a.coverH();
            int d0 = 0;
            while (d0 < h) {                                              // rows with the same inset are drawn in one piece
                int in = inset(d0, h, r), d1 = d0 + 1;
                while (d1 < h && inset(d1, h, r) == in) d1++;
                int dw = Math.max(1, w - 2 * in), dh = d1 - d0;
                float u = in * tw / (float) w, v = d0 * th / (float) h;
                int uw = Math.max(1, Math.min(tw, Math.round(dw * tw / (float) w))), vh = Math.max(1, Math.min(th, Math.round(dh * th / (float) h)));
                g.blit(a.cover(), ox + in, oy + d0, dw, dh, u, v, uw, vh, tw, th);
                d0 = d1;
            }
        } else {
            int hue = Math.abs(a.title().hashCode()) % 360;
            int c1 = 0xFF000000 | java.awt.Color.HSBtoRGB(hue / 360f, 0.45f, 0.75f);
            int c2 = 0xFF000000 | java.awt.Color.HSBtoRGB(((hue + 40) % 360) / 360f, 0.55f, 0.45f);
            int r = radius(size);
            for (int dy = 0; dy < size; dy++) {
                int in = inset(dy, size, r);
                g.fill(x + in, y + dy, x + size - in, y + dy + 1, lerp(c1, c2, size <= 1 ? 0 : dy / (float) (size - 1)));
            }
        }
    }

    /** The letter on a tile without a picture (only when the album has no cover). */
    public static boolean hasPicture(Albums.Album a) { return a.cover() != null && a.coverW() > 0 && a.coverH() > 0; }

    public static String letter(Albums.Album a) { return a.title().isEmpty() ? "?" : a.title().substring(0, 1).toUpperCase(Locale.ROOT); }

    private static int lerp(int a, int b, float f) {
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int gr = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }
}
