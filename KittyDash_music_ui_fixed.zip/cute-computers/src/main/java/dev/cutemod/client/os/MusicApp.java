package dev.cutemod.client.os;

import dev.cutemod.client.player.PlayerEngine;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The music player of the computer, in the style of a modern desktop music app (a frosted light window, or a dark one):
 * a row of pages on top (Home, Songs, Artists, Albums, Store) with the search, a toolbar (rescan, folder, "shuffle all",
 * the sort, an index of letters), a grid of album covers with the name over the picture, and a player bar at the
 * bottom (the song, previous / play / next, shuffle, repeat, the seek bar, the volume).
 * Real songs from the albums (the folder music/ inside the mod and the folder cutemod_music next to the game).
 * The Store page sells albums for coins. The music itself is {@link PlayerEngine}, the same as the portable player uses.
 */
public class MusicApp extends App {
    // ---------- layout (the app area is 300 x 166) ----------
    private static final int NAV_Y = 4, NAV_H = 14, SEARCH_W = 56, GEAR_X = W - 8 - 12;
    private static final int SEARCH_X = GEAR_X - 4 - SEARCH_W;
    private static final int TB_Y = 22, TB_H = 14;
    private static final int BODY_Y = 39, BODY_END = 130, BODY_H = BODY_END - BODY_Y;
    private static final int COLS = 6, TILE = 43, GAP = 6, GX = 6, PITCH = TILE + GAP;
    private static final int ROW_H = 11;
    private static final int FOOT_Y = 131, SEEK_X0 = 38, SEEK_X1 = 262, SEEK_Y = 135;
    private static final int CTRL_Y = 153;
    private static final int SH_X = 106, PREV_X = 130, PLAY_X = 162, NEXT_X = 178, REP_X = 202;
    private static final int SPK_X = 226, VOL_X = 242, VOL_W = 50;

    // ---------- the colours of the two looks ----------
    private int bgTop, bgBot, cText, cMuted, cCard, cCardH, cSel, cBar, cLine, cBtn, cInk;
    private static final int PINK = 0xFFE58AAE, PINK_D = 0xFFD0709A, TEAL = 0xFF2E8B9A, GOLD = 0xFFC9961A, GREEN = 0xFF3E9E5E;

    private void applyTheme() {
        if (Progress.owned("music_dark")) {
            bgTop = 0xFF1B1430; bgBot = 0xFF2A1F4A; cText = 0xFFFFFFFF; cMuted = 0xFFB8A8D8;
            cCard = 0x26FFFFFF; cCardH = 0x4CFFFFFF; cSel = 0x66B57BD6; cBar = 0x44FFFFFF; cLine = 0x22FFFFFF; cBtn = 0x33FFFFFF; cInk = 0xFFFFFFFF;
        } else {
            bgTop = 0xFFE9E4F4; bgBot = 0xFFF6DDE8; cText = 0xFF2B2540; cMuted = 0xFF776F8F;
            cCard = 0x66FFFFFF; cCardH = 0xAAFFFFFF; cSel = 0x66B57BD6; cBar = 0x33000000; cLine = 0x22000000; cBtn = 0x88FFFFFF; cInk = 0xFF3A3450;
        }
    }

    // ---------- state ----------
    private int tab = 3;                         // 0 Home, 1 Songs, 2 Artists, 3 Albums (albums are bought in CuteStore, not here)
    private String openAlbum;                    // the album whose page is open (null = a page of the list)
    private String artistFilter;                 // Albums page: only the albums of this artist
    private int sort;                            // 0 by title, 1 by artist
    private boolean desc;
    private int scroll;                          // pixels, of the grid, the song list or the song list of an album
    private String query = "";
    private boolean typing;
    private int drag;                            // 1 = seek bar, 2 = volume
    private long dragMs;
    private float lastVol = 0.6F;
    private int ticks, mx, my;
    private String flash = "";
    private int flashT;
    private boolean started;                     // this app started the music (so closing the app stops it)

    private void say(String s) { flash = s; flashT = 180; }

    // ---------- note-block sounds for the other apps (radio, videos...) ----------
    static void note(int instrument, int n, float volume) {
        SoundEvent ev = switch (instrument) {
            case 0 -> SoundEvents.NOTE_BLOCK_HARP.value();
            case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
            case 2 -> SoundEvents.NOTE_BLOCK_BASS.value();
            default -> SoundEvents.NOTE_BLOCK_CHIME.value();
        };
        float pitch = (float) Math.max(0.5, Math.min(2.0, Math.pow(2.0, (n - 12) / 12.0)));
        Sfx.musicNote(ev, pitch, volume);
    }

    // ---------- for the desktop (taskbar, widget) ----------
    @Override public Component title() { return Component.translatable("cutemod.os.music"); }

    @Override public Component hint() { return Component.translatable("cutemod.os.hint.music"); }

    @Override
    public Component status() {
        return PlayerEngine.isPlaying() ? Component.translatable("cutemod.music.now", trackName())
                : Component.translatable("cutemod.music.paused");
    }

    @Override public boolean busy() { return PlayerEngine.isPlaying(); }

    @Override public boolean background() { return PlayerEngine.isPlaying(); }

    @Override
    public void close() { if (started) { PlayerEngine.stop(); started = false; } }

    boolean active() { return PlayerEngine.current() != null && (PlayerEngine.isPlaying() || PlayerEngine.position() > 0); }

    boolean isPlaying() { return PlayerEngine.isPlaying(); }

    String trackName() { var c = PlayerEngine.current(); return c == null ? "" : c.track().title(); }

    float progress() {
        long len = PlayerEngine.length();
        return len <= 0 ? 0F : Math.min(1F, PlayerEngine.position() / (float) len);
    }

    void toggle() {
        if (PlayerEngine.current() == null) {
            for (Albums.Album a : Albums.all()) if (a.owned()) { playAlbum(a, 0); return; }
            return;
        }
        PlayerEngine.toggle();
    }

    void nextTrack() { PlayerEngine.next(); }

    void prevTrack() { PlayerEngine.prev(); }

    // ---------- data ----------
    private record Tile(Albums.Album cover, String title, String sub, Albums.Album album, String artist) {}

    private record Song(Albums.Album album, Albums.Track track) {}

    private static String norm(String s) { return s.trim().toLowerCase(Locale.ROOT); }

    private boolean searching() { return !query.trim().isEmpty(); }

    private int effTab() { return tab == 0 && searching() ? 1 : tab; }

    private static String artistOf(Albums.Album a) { return a.artist().isEmpty() ? "?" : a.artist(); }

    private static boolean matches(Albums.Album a, String q) {
        return a.title().toLowerCase(Locale.ROOT).contains(q) || a.artist().toLowerCase(Locale.ROOT).contains(q);
    }

    private static char letterOf(String s) {
        if (s == null || s.isEmpty()) return '#';
        char c = Character.toUpperCase(s.charAt(0));
        return Character.isLetter(c) ? c : '#';
    }

    private Albums.Album albumById(String id) {
        if (id != null) for (Albums.Album a : Albums.all()) if (a.id().equals(id)) return a;
        return null;
    }

    private Albums.Album open() { return albumById(openAlbum); }

    private List<Albums.Album> sortedAlbums(boolean store) {
        List<Albums.Album> out = new ArrayList<>();
        String q = norm(query);
        for (Albums.Album a : Albums.all()) {
            if (!store && !a.owned()) continue;
            if (!q.isEmpty() && !matches(a, q)) continue;
            if (!store && artistFilter != null && !artistOf(a).equals(artistFilter)) continue;
            out.add(a);
        }
        out.sort((x, y) -> {
            int c = sort == 1 ? artistOf(x).compareToIgnoreCase(artistOf(y)) : x.title().compareToIgnoreCase(y.title());
            if (c == 0) c = x.title().compareToIgnoreCase(y.title());
            return desc ? -c : c;
        });
        return out;
    }

    private List<Tile> tiles() {
        List<Tile> out = new ArrayList<>();
        int et = effTab();
        if (et == 2) {                                                       // artists: one tile each
            Map<String, List<Albums.Album>> by = new LinkedHashMap<>();
            String q = norm(query);
            for (Albums.Album a : Albums.all()) {
                if (!a.owned()) continue;
                if (!q.isEmpty() && !artistOf(a).toLowerCase(Locale.ROOT).contains(q)) continue;
                by.computeIfAbsent(artistOf(a), k -> new ArrayList<>()).add(a);
            }
            List<String> names = new ArrayList<>(by.keySet());
            names.sort((x, y) -> desc ? y.compareToIgnoreCase(x) : x.compareToIgnoreCase(y));
            for (String n : names) out.add(new Tile(by.get(n).get(0), n, t("cutemod.music.albums.n", by.get(n).size()), null, n));
            return out;
        }
        for (Albums.Album a : sortedAlbums(false)) {
            out.add(new Tile(a, a.title(), a.artist().isEmpty() ? t("cutemod.player.count", a.tracks().size()) : a.artist(), a, a.artist()));
        }
        return out;
    }

    private List<Song> songs() {
        List<Song> out = new ArrayList<>();
        String q = norm(query);
        for (Albums.Album a : Albums.all()) {
            if (!a.owned()) continue;
            boolean albumHit = !q.isEmpty() && matches(a, q);
            for (Albums.Track tk : a.tracks()) if (q.isEmpty() || albumHit || tk.title().toLowerCase(Locale.ROOT).contains(q)) out.add(new Song(a, tk));
        }
        out.sort((x, y) -> {
            int c = sort == 1 ? artistOf(x.album()).compareToIgnoreCase(artistOf(y.album())) : x.track().title().compareToIgnoreCase(y.track().title());
            return desc ? -c : c;
        });
        return out;
    }

    private static List<PlayerEngine.Entry> entries(Albums.Album a) {
        List<PlayerEngine.Entry> l = new ArrayList<>();
        for (Albums.Track tk : a.tracks()) l.add(new PlayerEngine.Entry(a, tk));
        return l;
    }

    private static List<PlayerEngine.Entry> entriesOf(List<Song> l) {
        List<PlayerEngine.Entry> out = new ArrayList<>();
        for (Song s : l) out.add(new PlayerEngine.Entry(s.album(), s.track()));
        return out;
    }

    private void playAlbum(Albums.Album a, int from) { playQueue(entries(a), from); }

    private void playQueue(List<PlayerEngine.Entry> q, int from) { if (q.isEmpty()) return; started = true; PlayerEngine.play(q, from); }

    private List<Song> allOwnedSongs() {
        List<Song> out = new ArrayList<>();
        for (Albums.Album a : Albums.all()) if (a.owned()) for (Albums.Track tk : a.tracks()) out.add(new Song(a, tk));
        return out;
    }

    private void shuffleAll() {
        List<Song> all = allOwnedSongs();
        if (all.isEmpty()) { say(t("cutemod.music.libempty").replace("|", " ")); return; }
        PlayerEngine.setShuffle(true);
        playQueue(entriesOf(all), (int) (Math.random() * all.size()));
    }

    private void playArtist(String name) {
        List<PlayerEngine.Entry> q = new ArrayList<>();
        for (Albums.Album a : Albums.all()) if (a.owned() && artistOf(a).equals(name)) q.addAll(entries(a));
        playQueue(q, 0);
    }

    private static int totalMinutes(Albums.Album a) {
        int s = 0;
        for (Albums.Track tk : a.tracks()) s += tk.seconds();
        return Math.max(1, s / 60);
    }

    private static String time(long ms) {
        long s = Math.max(0, ms / 1000);
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    // ---------- drawing helpers ----------
    private static int tw(String s) { return CuteFont.width(font(), s); }

    private static void str(GuiGraphics g, String s, int x, int y, int color) { Skin.str(g, font(), s, x, y, color, false); }

    private static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        int n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= n; i++) {
            int x = n == 0 ? x0 : x0 + (x1 - x0) * i / n, y = n == 0 ? y0 : y0 + (y1 - y0) * i / n;
            g.fill(x, y, x + 1, y + 1, c);
        }
    }

    /** A triangle pointing right (dir 1) or left (dir -1); size = its height. */
    private static void tri(GuiGraphics g, int x, int y, int size, int dir, int color) {
        int cols = size / 2 + 1;
        for (int c = 0; c < cols; c++) {
            int xx = dir > 0 ? x + c : x + cols - 1 - c;
            g.fill(xx, y + c, xx + 1, y + size - c, color);
        }
    }

    private static void coverTile(GuiGraphics g, Albums.Album a, int x, int y, int size) {
        RoundCover.draw(g, a, x, y, size);
        if (!RoundCover.hasPicture(a) && size >= 12) {
            String l = RoundCover.letter(a);
            str(g, l, x + (size - tw(l)) / 2, y + size / 2 - 4, 0xFFFFFFFF);
        }
    }

    /** A dark veil over the bottom h rows of a rounded cover (so the name on it can be read on any picture). */
    private static void veil(GuiGraphics g, int x, int y, int size, int h, int maxAlpha) {
        int r = RoundCover.radius(size);
        for (int dy = size - h; dy < size; dy++) {
            int in = RoundCover.inset(dy, size, r);
            float f = (dy - (size - h)) / (float) h;
            g.fill(x + in, y + dy, x + size - in, y + dy + 1, ((int) (maxAlpha * f * f) << 24));
        }
    }

    private void pill(GuiGraphics g, int x, int y, int w, int h, boolean on, boolean hov) {
        roundRect(g, x, y, w, h, h / 2 + 1, on ? 0xAAB57BD6 : (hov ? cCardH : cCard));
    }

    private void scrollBar(GuiGraphics g, int total, int visible) {
        if (total <= visible) return;
        int bh = Math.max(8, BODY_H * visible / total);
        int by = BODY_Y + (BODY_H - bh) * scroll / Math.max(1, total - visible);
        roundRect(g, W - 3, by, 2, bh, 1, 0xFFB57BD6);
    }

    // ---------- the little icons (7 x 7) ----------
    private void iconHome(GuiGraphics g, int x, int y, int c) {
        for (int i = 0; i < 4; i++) g.fill(x + 3 - i, y + i, x + 4 + i, y + i + 1, c);
        g.fill(x + 1, y + 4, x + 6, y + 7, c);
        g.fill(x + 3, y + 5, x + 4, y + 7, bgBot);
    }

    private void iconNote(GuiGraphics g, int x, int y, int c) {
        g.fill(x + 3, y, x + 4, y + 6, c); g.fill(x + 1, y + 5, x + 4, y + 7, c); g.fill(x + 4, y, x + 7, y + 2, c);
    }

    private void iconPeople(GuiGraphics g, int x, int y, int c) {
        disc(g, x + 3, y + 2, 2, c); g.fill(x + 1, y + 5, x + 6, y + 7, c);
    }

    private void iconAlbum(GuiGraphics g, int x, int y, int c) {
        disc(g, x + 3, y + 3, 3, c); disc(g, x + 3, y + 3, 1, bgBot);
    }

    private void iconBag(GuiGraphics g, int x, int y, int c) {
        g.fill(x + 1, y + 2, x + 6, y + 7, c); g.fill(x + 2, y, x + 5, y + 1, c); g.fill(x + 2, y, x + 3, y + 3, c); g.fill(x + 4, y, x + 5, y + 3, c);
        g.fill(x + 2, y + 3, x + 3, y + 4, bgBot); g.fill(x + 4, y + 3, x + 5, y + 4, bgBot);
    }

    private static void iconShuffle(GuiGraphics g, int x, int y, int c) {
        line(g, x, y + 6, x + 7, y, c); line(g, x, y, x + 7, y + 6, c);
        g.fill(x + 6, y - 1, x + 9, y, c); g.fill(x + 8, y - 1, x + 9, y + 2, c);
        g.fill(x + 6, y + 6, x + 9, y + 7, c); g.fill(x + 8, y + 4, x + 9, y + 7, c);
    }

    private static void iconRepeat(GuiGraphics g, int x, int y, int c, boolean one) {
        g.fill(x + 1, y, x + 9, y + 1, c); g.fill(x + 9, y, x + 10, y + 5, c); g.fill(x + 1, y + 5, x + 9, y + 6, c); g.fill(x, y + 1, x + 1, y + 6, c);
        g.fill(x + 7, y - 1, x + 8, y + 2, c); g.fill(x + 8, y, x + 9, y + 1, c);
        g.fill(x + 1, y + 4, x + 2, y + 7, c); g.fill(x + 2, y + 5, x + 3, y + 6, c);
        if (one) g.fill(x + 4, y + 1, x + 6, y + 5, c);
    }

    private static void iconSpeaker(GuiGraphics g, int x, int y, int c, boolean muted) {
        g.fill(x, y + 2, x + 3, y + 6, c); tri(g, x + 3, y, 8, 1, c);
        if (muted) { line(g, x + 7, y + 1, x + 11, y + 7, c); line(g, x + 7, y + 7, x + 11, y + 1, c); }
        else { g.fill(x + 8, y + 3, x + 9, y + 5, c); g.fill(x + 10, y + 1, x + 11, y + 7, c); }
    }

    private static void iconGear(GuiGraphics g, int x, int y, int c, int hole) {
        disc(g, x + 5, y + 5, 3, c);
        g.fill(x + 4, y, x + 7, y + 2, c); g.fill(x + 4, y + 8, x + 7, y + 10, c); g.fill(x, y + 4, x + 2, y + 7, c); g.fill(x + 8, y + 4, x + 10, y + 7, c);
        disc(g, x + 5, y + 5, 1, hole);
    }

    private void iconRefresh(GuiGraphics g, int x, int y, int c) {
        g.fill(x + 1, y, x + 6, y + 1, c); g.fill(x + 6, y + 1, x + 7, y + 3, c);
        g.fill(x, y + 1, x + 1, y + 7, c); g.fill(x + 1, y + 7, x + 6, y + 8, c);
        g.fill(x + 6, y + 5, x + 7, y + 7, c); g.fill(x + 4, y - 1, x + 5, y + 2, c);
    }

    private void iconFolder(GuiGraphics g, int x, int y, int c) {
        g.fill(x, y, x + 4, y + 1, c); g.fill(x, y + 1, x + 10, y + 7, c); g.fill(x + 1, y + 3, x + 9, y + 6, hoverFill());
    }

    private int hoverFill() { return bgBot; }

    private void iconSearch(GuiGraphics g, int x, int y, int c) {
        g.fill(x + 1, y, x + 4, y + 1, c); g.fill(x + 1, y + 4, x + 4, y + 5, c);
        g.fill(x, y + 1, x + 1, y + 4, c); g.fill(x + 4, y + 1, x + 5, y + 4, c);
        g.fill(x + 4, y + 5, x + 6, y + 7, c);
    }

    // ---------- render ----------
    @Override
    public void mouse(int x, int y) { mx = x; my = y; }

    @Override
    public void tick() {
        ticks++;
        if (flashT > 0) flashT--;
    }

    @Override
    public void render(GuiGraphics g, int mxx, int myy) {
        mx = mxx; my = myy;
        applyTheme();
        g.fillGradient(0, 0, W, H, bgTop, bgBot);
        renderNav(g);
        renderToolbar(g);
        g.enableScissor(shell.absX(), shell.absY() + BODY_Y, shell.absX() + W, shell.absY() + BODY_END);
        if (openAlbum != null && open() != null) renderDetail(g);
        else switch (effTab()) {
            case 0 -> renderHome(g);
            case 1 -> renderSongs(g);
            default -> renderGrid(g);
        }
        g.disableScissor();
        renderFooter(g);
        if (flashT > 0) {
            int w = Math.min(W - 24, tw(flash) + 16);
            roundRect(g, (W - w) / 2, 112, w, 14, 6, 0xEE3A2A66);
            fitText(g, font(), flash, W / 2, 115, w - 8, 0xFFFFFFFF, true);
        }
        if (in(mx, my, 6, TB_Y, 14, TB_H) && openAlbum == null) tip(g, t("cutemod.music.rescan.tip"));
        else if (in(mx, my, 22, TB_Y, 14, TB_H) && openAlbum == null) tip(g, t("cutemod.music.folder.tip"));
        else if (in(mx, my, GEAR_X, NAV_Y, 12, NAV_H)) tip(g, t("cutemod.music.theme.tip"));
    }

    private void tip(GuiGraphics g, String s) {
        int w = tw(s) + 8, x = Math.min(mx, W - w - 2), y = TB_Y + TB_H + 2;
        roundRect(g, x, y, w, 12, 4, 0xF0120E22);
        str(g, s, x + 4, y + 2, 0xFFFFFFFF);
    }

    // ----- the pages on top and the search -----
    private static final String[] TAB_KEYS = {"home", "songs", "artists", "albums"};
    private final int[] tabX = new int[4], tabW = new int[4];
    private boolean tabIcons;

    private void layoutNav() {
        int avail = SEARCH_X - 6 - 6, nat = 0;
        int[] w = new int[4];
        for (int i = 0; i < 4; i++) w[i] = tw(t("cutemod.music.tab." + TAB_KEYS[i]));
        for (int i = 0; i < 4; i++) nat += w[i] + 10;
        tabIcons = nat + 4 * 9 <= avail;
        if (tabIcons) for (int i = 0; i < 4; i++) w[i] += 9;
        int sum = 0;
        for (int i = 0; i < 4; i++) sum += w[i] + 10;
        float k = sum > avail ? avail / (float) sum : 1F;
        int x = 6;
        for (int i = 0; i < 4; i++) {
            tabX[i] = x;
            tabW[i] = Math.round((w[i] + 10) * k);
            x += tabW[i];
        }
    }

    private void renderNav(GuiGraphics g) {
        layoutNav();
        for (int i = 0; i < 4; i++) {
            boolean on = openAlbum == null ? effTab() == i : tab == i, hov = in(mx, my, tabX[i], NAV_Y, tabW[i], NAV_H);
            int col = on ? cText : (hov ? cText : cMuted);
            int tx = tabX[i] + 5;
            if (tabIcons) {
                switch (i) { case 0 -> iconHome(g, tx, NAV_Y + 3, col); case 1 -> iconNote(g, tx, NAV_Y + 3, col); case 2 -> iconPeople(g, tx, NAV_Y + 3, col); default -> iconAlbum(g, tx, NAV_Y + 3, col); }
                tx += 9;
            }
            fitText(g, font(), t("cutemod.music.tab." + TAB_KEYS[i]), tx, NAV_Y + 3, tabW[i] - (tx - tabX[i]) - 4, col, false);
            if (on) roundRect(g, tabX[i] + 5, NAV_Y + NAV_H, tabW[i] - 10, 2, 1, TEAL);
        }
        // search box
        roundRect(g, SEARCH_X, NAV_Y, SEARCH_W, NAV_H, 6, typing ? cCardH : cCard);
        if (typing) g.fill(SEARCH_X + 3, NAV_Y + NAV_H - 1, SEARCH_X + SEARCH_W - 3, NAV_Y + NAV_H, TEAL);
        String shown = query.isEmpty() && !typing ? t("cutemod.player.search") : query;
        String cut = shown;
        while (cut.length() > 1 && tw(cut) > SEARCH_W - 22) cut = cut.substring(1);       // the end of the text stays visible
        str(g, cut, SEARCH_X + 5, NAV_Y + 3, query.isEmpty() ? cMuted : cText);
        if (typing && (ticks / 30) % 2 == 0) g.fill(SEARCH_X + 5 + tw(cut), NAV_Y + 3, SEARCH_X + 6 + tw(cut), NAV_Y + NAV_H - 3, cText);
        if (!query.isEmpty()) str(g, "x", SEARCH_X + SEARCH_W - 10, NAV_Y + 3, in(mx, my, SEARCH_X + SEARCH_W - 13, NAV_Y, 13, NAV_H) ? cText : cMuted);
        else iconSearch(g, SEARCH_X + SEARCH_W - 11, NAV_Y + 3, cMuted);
        // the look (light / dark)
        iconGear(g, GEAR_X + 1, NAV_Y + 2, in(mx, my, GEAR_X, NAV_Y, 12, NAV_H) ? cText : cMuted, bgBot);
    }

    // ----- the toolbar: rescan, folder, shuffle all, sort, the letters -----
    private final List<Character> letters = new ArrayList<>();
    private int letterX0, letterStep;

    private void renderToolbar(GuiGraphics g) {
        letters.clear();
        if (openAlbum != null) {
            boolean hov = in(mx, my, 6, TB_Y, 40, TB_H);
            pill(g, 6, TB_Y, 40, TB_H, false, hov);
            tri(g, 11, TB_Y + 4, 6, -1, cText);
            str(g, t("cutemod.music.back"), 20, TB_Y + 3, cText);
            Albums.Album a = open();
            if (a != null) fitText(g, font(), a.title(), 52, TB_Y + 3, W - 60, cMuted, false);
            return;
        }
        int et = effTab();
        pill(g, 6, TB_Y, 14, TB_H, false, in(mx, my, 6, TB_Y, 14, TB_H));
        iconRefresh(g, 9, TB_Y + 4, cMuted);
        pill(g, 22, TB_Y, 14, TB_H, false, in(mx, my, 22, TB_Y, 14, TB_H));
        iconFolder(g, 24, TB_Y + 4, cMuted);
        int x = 40;
        if (artistFilter != null && et == 3) {                                   // the albums of one artist: a chip that clears it
            int w = Math.min(90, tw(artistFilter) + 20);
            pill(g, x, TB_Y, w, TB_H, true, in(mx, my, x, TB_Y, w, TB_H));
            fitText(g, font(), artistFilter, x + 5, TB_Y + 3, w - 16, 0xFFFFFFFF, false);
            str(g, "x", x + w - 9, TB_Y + 3, 0xFFFFFFFF);
            x += w + 4;
        } else {
            String label = t("cutemod.music.shuffleall", et == 1 ? songs().size() : allOwnedSongs().size());
            int w = Math.min(88, tw(label) + 22);
            boolean hov = in(mx, my, x, TB_Y, w, TB_H);
            pill(g, x, TB_Y, w, TB_H, false, hov);
            iconShuffle(g, x + 5, TB_Y + 4, cText);
            fitText(g, font(), label, x + 17, TB_Y + 3, w - 20, cText, false);
            x += w + 4;
        }
        if (et != 0) {
            String sl = t(sort == 0 ? "cutemod.music.sort.title" : "cutemod.music.sort.artist");
            int w = Math.max(40, Math.min(58, tw(sl) + 14));
            boolean hov = in(mx, my, x, TB_Y, w, TB_H);
            pill(g, x, TB_Y, w, TB_H, false, hov);
            fitText(g, font(), sl, x + 5, TB_Y + 3, w - 14, cText, false);
            tri(g, x + w - 9, TB_Y + 5, 4, 1, cMuted);
            x += w + 2;
            boolean ho = in(mx, my, x, TB_Y, 14, TB_H);
            pill(g, x, TB_Y, 14, TB_H, false, ho);
            if (desc) tri(g, x + 5, TB_Y + 4, 6, 1, cText); else tri(g, x + 4, TB_Y + 4, 6, -1, cText);
            x += 16;
        }
        // the index of letters
        if (et != 0) {
            if (et == 1) for (Song s : songs()) letters.add(letterOf(sort == 1 ? artistOf(s.album()) : s.track().title()));
            else for (Tile tl : tiles()) letters.add(letterOf(et == 2 || sort == 0 ? tl.title() : artistOf(tl.cover())));
            List<Character> uniq = new ArrayList<>();
            for (char c : letters) if (!uniq.contains(c)) uniq.add(c);
            uniq.sort(Character::compare);
            int avail = W - 6 - x - 2;
            letterStep = uniq.isEmpty() ? 6 : Math.max(4, Math.min(7, avail / uniq.size()));
            letterX0 = W - 6 - letterStep * uniq.size();
            if (letterX0 >= x + 2 && !uniq.isEmpty()) {
                roundRect(g, letterX0 - 3, TB_Y, letterStep * uniq.size() + 6, TB_H, 6, cCard);
                for (int i = 0; i < uniq.size(); i++) {
                    int lx = letterX0 + i * letterStep;
                    boolean hov = in(mx, my, lx, TB_Y, letterStep, TB_H);
                    smallText(g, font(), String.valueOf(uniq.get(i)), lx + letterStep / 2, TB_Y + 3, letterStep, hov ? TEAL : cText);
                }
            }
            letters.clear();
            letters.addAll(uniq);
            if (letterX0 < x + 2) letters.clear();
        }
    }

    // ----- Home: what plays now and the newest albums -----
    private void renderHome(GuiGraphics g) {
        scroll = 0;
        var cur = PlayerEngine.current();
        int cx = 8, cy = BODY_Y + 4;
        if (cur != null) {
            coverTile(g, cur.album(), cx, cy, 70);
            int tx = cx + 78, tr = 150 - tx + 8;
            str(g, t("cutemod.music.nowplaying").toUpperCase(Locale.ROOT), tx, cy + 2, TEAL);
            fitText(g, font(), cur.track().title(), tx, cy + 14, 70, cText, false);
            fitText(g, font(), artistOf(cur.album()), tx, cy + 25, 70, cMuted, false);
            boolean hp = in(mx, my, tx, cy + 40, 30, 14);
            roundRect(g, tx, cy + 40, 30, 14, 7, hp ? PINK : PINK_D);
            if (PlayerEngine.isPlaying()) { g.fill(tx + 11, cy + 44, tx + 13, cy + 50, 0xFFFFFFFF); g.fill(tx + 16, cy + 44, tx + 18, cy + 50, 0xFFFFFFFF); }
            else tri(g, tx + 12, cy + 43, 8, 1, 0xFFFFFFFF);
            boolean hs = in(mx, my, tx + 34, cy + 40, 24, 14);
            pill(g, tx + 34, cy + 40, 24, 14, PlayerEngine.shuffle(), hs);
            iconShuffle(g, tx + 40, cy + 44, PlayerEngine.shuffle() ? 0xFFFFFFFF : cText);
        } else {
            roundRect(g, cx, cy, 142, 70, 8, cCard);
            fitText(g, font(), t("cutemod.music.welcome"), cx + 71, cy + 14, 130, cText, true);
            fitText(g, font(), t("cutemod.music.welcome2"), cx + 71, cy + 26, 130, cMuted, true);
            boolean hs = in(mx, my, cx + 31, cy + 44, 80, 14);
            roundRect(g, cx + 31, cy + 44, 80, 14, 7, hs ? PINK : PINK_D);
            String lb = t("cutemod.music.shuffleall", allOwnedSongs().size());
            fitText(g, font(), lb, cx + 71, cy + 47, 72, 0xFFFFFFFF, true);
        }
        // the newest albums (the last of the library)
        str(g, t("cutemod.music.recent").toUpperCase(Locale.ROOT), 156, BODY_Y + 2, cMuted);
        List<Albums.Album> own = new ArrayList<>();
        for (Albums.Album a : Albums.all()) if (a.owned()) own.add(a);
        int n = Math.min(6, own.size());
        for (int i = 0; i < n; i++) {
            Albums.Album a = own.get(own.size() - 1 - i);
            int x = 156 + (i % 3) * 40, y = BODY_Y + 14 + (i / 3) * 40;
            boolean hov = in(mx, my, x, y, 36, 36);
            coverTile(g, a, x, y, 36);
            if (hov) { veil(g, x, y, 36, 36, 0x66); }
            veil(g, x, y, 36, 11, 0xB0);
            fitText(g, font(), a.title(), x + 2, y + 26, 32, 0xFFFFFFFF, false);
        }
        if (n == 0) fitText(g, font(), t("cutemod.player.none"), 224, BODY_Y + 40, 130, cMuted, true);
    }

    // ----- the grid of covers: Albums, Artists, Store -----
    private int rowsOf(int n) { return (n + COLS - 1) / COLS; }

    private void renderGrid(GuiGraphics g) {
        List<Tile> l = tiles();
        int et = effTab();
        int content = rowsOf(l.size()) * PITCH + 6;
        scroll = Math.max(0, Math.min(Math.max(0, content - BODY_H), scroll));
        if (l.isEmpty()) {
            String[] lines = t(searching() || artistFilter != null ? "cutemod.player.none" : "cutemod.music.libempty").split("\\|");
            for (int i = 0; i < lines.length; i++) fitText(g, font(), lines[i], W / 2, BODY_Y + 24 + i * 11, 240, cMuted, true);
            return;
        }
        var cur = PlayerEngine.current();
        for (int i = 0; i < l.size(); i++) {
            int x = GX + (i % COLS) * PITCH, y = BODY_Y + 3 + (i / COLS) * PITCH - scroll;
            if (y + TILE < BODY_Y || y > BODY_END) continue;
            Tile tl = l.get(i);
            boolean hov = in(mx, my, x, y, TILE, TILE) && my >= BODY_Y && my < BODY_END;
            coverTile(g, tl.cover(), x, y, TILE);
            if (hov) veil(g, x, y, TILE, TILE, 0x55);
            veil(g, x, y, TILE, 22, 0xD0);
            fitText(g, font(), tl.title(), x + 3, y + TILE - 19, TILE - 6, 0xFFFFFFFF, false);
            fitText(g, font(), tl.sub(), x + 3, y + TILE - 10, TILE - 6, 0xFFD8D0E8, false);
            if (cur != null && tl.album() != null && cur.album().id().equals(tl.album().id())) {
                roundRect(g, x + TILE - 15, y + 3, 12, 10, 4, 0xCC000000);
                for (int b = 0; b < 3; b++) {
                    int bh = PlayerEngine.isPlaying() ? 2 + (int) (Math.abs(Math.sin((ticks + b * 9) * 0.1)) * 4) : 3;
                    g.fill(x + TILE - 13 + b * 3, y + 11 - bh, x + TILE - 11 + b * 3, y + 11, PINK);
                }
            }
            if (hov) {                                                // the play button of a tile
                boolean hp = Math.hypot(mx - (x + TILE / 2), my - (y + 14)) <= 8;
                disc(g, x + TILE / 2, y + 14, 8, hp ? PINK : 0xDDFFFFFF);
                tri(g, x + TILE / 2 - 2, y + 10, 8, 1, hp ? 0xFFFFFFFF : PINK_D);
            }
        }
        scrollBar(g, content, BODY_H);
    }

    // ----- Songs: one long list -----
    private void renderSongs(GuiGraphics g) {
        List<Song> l = songs();
        int content = l.size() * ROW_H + 4;
        scroll = Math.max(0, Math.min(Math.max(0, content - BODY_H), scroll));
        if (l.isEmpty()) {
            String[] lines = t(searching() ? "cutemod.player.none" : "cutemod.music.libempty").split("\\|");
            for (int i = 0; i < lines.length; i++) fitText(g, font(), lines[i], W / 2, BODY_Y + 24 + i * 11, 240, cMuted, true);
            return;
        }
        var cur = PlayerEngine.current();
        for (int i = 0; i < l.size(); i++) {
            int y = BODY_Y + 2 + i * ROW_H - scroll;
            if (y + ROW_H < BODY_Y || y > BODY_END) continue;
            Song s = l.get(i);
            boolean now = cur != null && cur.album().id().equals(s.album().id()) && cur.track().id().equals(s.track().id());
            boolean hov = in(mx, my, 6, y, W - 14, ROW_H) && my >= BODY_Y && my < BODY_END;
            roundRect(g, 6, y, W - 14, ROW_H - 1, 4, now ? 0x55F58FB8 : hov ? cCardH : ((i & 1) == 0 ? 0x18FFFFFF : 0));
            coverTile(g, s.album(), 9, y + 1, 9);
            if (now && PlayerEngine.isPlaying()) {
                for (int b = 0; b < 3; b++) {
                    int bh = 2 + (int) (Math.abs(Math.sin((ticks + b * 9) * 0.1)) * 5);
                    g.fill(W - 24 - 40 + b * 3, y + 9 - bh, W - 22 - 40 + b * 3, y + 9, PINK_D);
                }
            }
            String right = time(s.track().seconds() * 1000L);
            fitText(g, font(), s.track().title(), 22, y + 1, 110, now ? PINK_D : cText, false);
            fitText(g, font(), artistOf(s.album()), 138, y + 1, 70, cMuted, false);
            fitText(g, font(), s.album().title(), 210, y + 1, 50, cMuted, false);
            str(g, right, W - 12 - tw(right), y + 1, cMuted);
        }
        scrollBar(g, content, BODY_H);
    }

    // ----- an open album: the picture, the buttons and the songs -----
    private void renderDetail(GuiGraphics g) {
        Albums.Album a = open();
        coverTile(g, a, 8, BODY_Y + 3, 64);
        fitText(g, font(), a.title(), 8, BODY_Y + 70, 92, cText, false);
        fitText(g, font(), artistOf(a), 8, BODY_Y + 80, 92, cMuted, false);
        fitText(g, font(), t("cutemod.player.count", a.tracks().size()) + " - " + t("cutemod.player.min", totalMinutes(a)), 8, BODY_Y + 89 - 1, 92, cMuted, false);
        int bx = 106;
        if (a.owned()) {
            boolean hp = in(mx, my, bx, BODY_Y + 2, 54, 14);
            roundRect(g, bx, BODY_Y + 2, 54, 14, 7, hp ? PINK : PINK_D);
            tri(g, bx + 8, BODY_Y + 5, 7, 1, 0xFFFFFFFF);
            fitText(g, font(), t("cutemod.player.play"), bx + 14 + 20, BODY_Y + 5, 36, 0xFFFFFFFF, true);
            boolean hm = in(mx, my, bx + 58, BODY_Y + 2, 54, 14);
            pill(g, bx + 58, BODY_Y + 2, 54, 14, a.onPlayer(), hm);
            fitText(g, font(), t("cutemod.music.toplayer"), bx + 58 + 27, BODY_Y + 5, 50, a.onPlayer() ? 0xFFFFFFFF : cText, true);
        } else {
            roundRect(g, bx, BODY_Y + 2, 120, 14, 7, 0xFF8A7AAA);
            fitText(g, font(), t("cutemod.music.instore"), bx + 60, BODY_Y + 5, 114, 0xFFFFFFFF, true);
        }
        List<Albums.Track> tracks = a.tracks();
        int top = BODY_Y + 21, vis = (BODY_END - top) / ROW_H, content = tracks.size() * ROW_H;
        scroll = Math.max(0, Math.min(Math.max(0, content - vis * ROW_H), scroll));
        var cur = PlayerEngine.current();
        g.enableScissor(shell.absX(), shell.absY() + top, shell.absX() + W, shell.absY() + BODY_END);
        for (int i = 0; i < tracks.size(); i++) {
            int y = top + i * ROW_H - scroll;
            if (y + ROW_H < top || y > BODY_END) continue;
            Albums.Track tk = tracks.get(i);
            boolean now = a.owned() && cur != null && cur.album().id().equals(a.id()) && cur.track().id().equals(tk.id());
            boolean hov = a.owned() && in(mx, my, bx - 4, y, W - bx - 4, ROW_H) && my >= top && my < BODY_END;
            roundRect(g, bx - 4, y, W - bx - 4, ROW_H - 1, 4, now ? 0x55F58FB8 : hov ? cCardH : ((i & 1) == 0 ? 0x18FFFFFF : 0));
            if (now && PlayerEngine.isPlaying()) {
                for (int b = 0; b < 3; b++) {
                    int bh = 2 + (int) (Math.abs(Math.sin((ticks + b * 9) * 0.1)) * 5);
                    g.fill(bx + b * 3, y + 9 - bh, bx + 2 + b * 3, y + 9, PINK_D);
                }
            } else if (now) tri(g, bx, y + 2, 6, 1, PINK_D);
            else str(g, String.valueOf(i + 1), bx, y + 1, cMuted);
            String right = time(tk.seconds() * 1000L);
            fitText(g, font(), tk.title(), bx + 14, y + 1, W - bx - 14 - tw(right) - 16, a.owned() ? (now ? PINK_D : cText) : cMuted, false);
            str(g, right, W - 12 - tw(right), y + 1, cMuted);
        }
        g.disableScissor();
    }

    // ----- the player bar -----
    private void renderFooter(GuiGraphics g) {
        g.fill(0, FOOT_Y, W, FOOT_Y + 35, 0x14000000);
        g.fill(0, FOOT_Y, W, FOOT_Y + 1, cLine);
        var cur = PlayerEngine.current();
        long len = PlayerEngine.length();
        long pos = drag == 1 ? dragMs : PlayerEngine.position();
        float frac = len > 0 ? Math.max(0F, Math.min(1F, pos / (float) len)) : 0F;
        String tl = cur == null ? "0:00" : time(pos), trr = cur == null || len <= 0 ? "-:--" : time(len);
        str(g, tl, SEEK_X0 - 4 - tw(tl), SEEK_Y - 3, cMuted);
        str(g, trr, SEEK_X1 + 4, SEEK_Y - 3, cMuted);
        roundRect(g, SEEK_X0, SEEK_Y, SEEK_X1 - SEEK_X0, 3, 1, cBar);
        int fill = (int) ((SEEK_X1 - SEEK_X0) * frac);
        if (fill > 0) roundRect(g, SEEK_X0, SEEK_Y, fill, 3, 1, PINK);
        if (cur != null && (drag == 1 || in(mx, my, SEEK_X0 - 3, SEEK_Y - 5, SEEK_X1 - SEEK_X0 + 6, 12))) disc(g, SEEK_X0 + fill, SEEK_Y + 1, 3, cInk);

        // the song
        if (cur != null) {
            coverTile(g, cur.album(), 8, 142, 22);
            fitText(g, font(), cur.track().title(), 34, 144, 66, cText, false);
            fitText(g, font(), artistOf(cur.album()), 34, 154, 66, cMuted, false);
        } else {
            roundRect(g, 8, 142, 22, 22, 6, cCard);
            fitText(g, font(), t("cutemod.player.nothing"), 34, 150, 66, cMuted, false);
        }
        // the controls
        boolean sh = PlayerEngine.shuffle(), rp = PlayerEngine.repeat() != PlayerEngine.Repeat.OFF;
        boolean hs = in(mx, my, SH_X, CTRL_Y - 8, 16, 16), hr = in(mx, my, REP_X, CTRL_Y - 8, 16, 16);
        if (sh) roundRect(g, SH_X - 1, CTRL_Y - 8, 16, 16, 8, TEAL);
        iconShuffle(g, SH_X + 3, CTRL_Y - 3, sh ? 0xFFFFFFFF : (hs ? cText : cMuted));
        if (rp) roundRect(g, REP_X - 1, CTRL_Y - 8, 16, 16, 8, TEAL);
        iconRepeat(g, REP_X + 2, CTRL_Y - 3, rp ? 0xFFFFFFFF : (hr ? cText : cMuted), PlayerEngine.repeat() == PlayerEngine.Repeat.ONE);
        boolean hp = in(mx, my, PREV_X, CTRL_Y - 8, 16, 16), hn = in(mx, my, NEXT_X, CTRL_Y - 8, 16, 16);
        g.fill(PREV_X + 4, CTRL_Y - 4, PREV_X + 5, CTRL_Y + 4, hp ? PINK_D : cInk); tri(g, PREV_X + 6, CTRL_Y - 4, 8, -1, hp ? PINK_D : cInk);
        g.fill(NEXT_X + 11, CTRL_Y - 4, NEXT_X + 12, CTRL_Y + 4, hn ? PINK_D : cInk); tri(g, NEXT_X + 3, CTRL_Y - 4, 8, 1, hn ? PINK_D : cInk);
        boolean hm = Math.hypot(mx - PLAY_X, my - CTRL_Y) <= 10;
        disc(g, PLAY_X, CTRL_Y, 10, hm ? PINK : PINK_D);
        disc(g, PLAY_X, CTRL_Y, 8, hm ? 0xFFFFE8F0 : 0xFFFFF4F8);
        if (PlayerEngine.isPlaying()) { g.fill(PLAY_X - 3, CTRL_Y - 4, PLAY_X - 1, CTRL_Y + 4, PINK_D); g.fill(PLAY_X + 1, CTRL_Y - 4, PLAY_X + 3, CTRL_Y + 4, PINK_D); }
        else tri(g, PLAY_X - 2, CTRL_Y - 5, 10, 1, PINK_D);
        // the volume
        boolean muted = PlayerEngine.volume() <= 0.01F;
        iconSpeaker(g, SPK_X, CTRL_Y - 4, in(mx, my, SPK_X - 2, CTRL_Y - 8, 14, 16) ? cText : cMuted, muted);
        roundRect(g, VOL_X, CTRL_Y - 1, VOL_W, 3, 1, cBar);
        int vf = (int) (VOL_W * PlayerEngine.volume());
        if (vf > 0) roundRect(g, VOL_X, CTRL_Y - 1, vf, 3, 1, TEAL);
        if (drag == 2 || in(mx, my, VOL_X - 3, CTRL_Y - 7, VOL_W + 6, 14)) disc(g, VOL_X + vf, CTRL_Y, 3, cInk);
    }

    // ---------- input ----------
    private void setTab(int t) { tab = t; openAlbum = null; artistFilter = null; scroll = 0; }

    @Override
    public boolean click(int x, int y, int button) {
        if (button != 0) return false;
        // the search box
        if (in(x, y, SEARCH_X, NAV_Y, SEARCH_W, NAV_H)) {
            if (!query.isEmpty() && in(x, y, SEARCH_X + SEARCH_W - 13, NAV_Y, 13, NAV_H)) { query = ""; scroll = 0; }
            typing = true;
            return true;
        }
        typing = false;
        if (in(x, y, GEAR_X, NAV_Y, 12, NAV_H)) { Progress.setFlag("music_dark", !Progress.owned("music_dark")); return true; }
        if (y >= NAV_Y && y < NAV_Y + NAV_H) {
            for (int i = 0; i < 4; i++) if (in(x, y, tabX[i], NAV_Y, tabW[i], NAV_H)) { setTab(i); return true; }
        }
        if (y >= TB_Y && y < TB_Y + TB_H && clickToolbar(x, y)) return true;
        if (clickFooter(x, y)) return true;
        if (y >= BODY_Y && y < BODY_END) {
            if (openAlbum != null && open() != null) return clickDetail(x, y);
            return switch (effTab()) { case 0 -> clickHome(x, y); case 1 -> clickSongs(x, y); default -> clickGrid(x, y); };
        }
        return false;
    }

    private boolean clickToolbar(int x, int y) {
        if (openAlbum != null) {
            if (in(x, y, 6, TB_Y, 40, TB_H)) { openAlbum = null; scroll = 0; return true; }
            return false;
        }
        if (in(x, y, 6, TB_Y, 14, TB_H)) { say(t("cutemod.music.rescanning")); Minecraft.getInstance().reloadResourcePacks(); return true; }
        if (in(x, y, 22, TB_Y, 14, TB_H)) {
            try {
                java.nio.file.Files.createDirectories(dev.cutemod.client.player.UserMusic.dir());
                net.minecraft.Util.getPlatform().openFile(dev.cutemod.client.player.UserMusic.dir().toFile());
            } catch (Exception ex) { say(t("cutemod.music.nofolder")); }
            return true;
        }
        int et = effTab(), px = 40;
        if (artistFilter != null && et == 3) {
            int w = Math.min(90, tw(artistFilter) + 20);
            if (in(x, y, px, TB_Y, w, TB_H)) { artistFilter = null; scroll = 0; return true; }
            px += w + 4;
        } else {
            String label = t("cutemod.music.shuffleall", et == 1 ? songs().size() : allOwnedSongs().size());
            int w = Math.min(88, tw(label) + 22);
            if (in(x, y, px, TB_Y, w, TB_H)) { shuffleAll(); return true; }
            px += w + 4;
        }
        if (et != 0) {
            String sl = t(sort == 0 ? "cutemod.music.sort.title" : "cutemod.music.sort.artist");
            int w = Math.max(40, Math.min(58, tw(sl) + 14));
            if (in(x, y, px, TB_Y, w, TB_H)) { sort = 1 - sort; scroll = 0; return true; }
            px += w + 2;
            if (in(x, y, px, TB_Y, 14, TB_H)) { desc = !desc; scroll = 0; return true; }
            for (int i = 0; i < letters.size(); i++) {
                if (in(x, y, letterX0 + i * letterStep, TB_Y, letterStep, TB_H)) { jumpToLetter(letters.get(i)); return true; }
            }
        }
        return false;
    }

    private void jumpToLetter(char c) {
        int et = effTab();
        if (et == 1) {
            List<Song> l = songs();
            for (int i = 0; i < l.size(); i++) {
                Song s = l.get(i);
                if (letterOf(sort == 1 ? artistOf(s.album()) : s.track().title()) == c) { scroll = i * ROW_H; return; }
            }
        } else {
            List<Tile> l = tiles();
            for (int i = 0; i < l.size(); i++) {
                Tile tl = l.get(i);
                if (letterOf(et == 2 || sort == 0 ? tl.title() : artistOf(tl.cover())) == c) { scroll = (i / COLS) * PITCH; return; }
            }
        }
    }

    private boolean clickFooter(int x, int y) {
        if (y < FOOT_Y) return false;
        if (Math.hypot(x - PLAY_X, y - CTRL_Y) <= 10) { toggle(); return true; }
        if (in(x, y, PREV_X, CTRL_Y - 8, 16, 16)) { PlayerEngine.prev(); return true; }
        if (in(x, y, NEXT_X, CTRL_Y - 8, 16, 16)) { PlayerEngine.next(); return true; }
        if (in(x, y, SH_X, CTRL_Y - 8, 16, 16)) { PlayerEngine.toggleShuffle(); return true; }
        if (in(x, y, REP_X, CTRL_Y - 8, 16, 16)) { PlayerEngine.cycleRepeat(); return true; }
        if (in(x, y, SPK_X - 2, CTRL_Y - 8, 14, 16)) {
            if (PlayerEngine.volume() > 0.01F) { lastVol = PlayerEngine.volume(); PlayerEngine.setVolume(0F); }
            else PlayerEngine.setVolume(lastVol > 0.01F ? lastVol : 0.6F);
            return true;
        }
        if (PlayerEngine.current() != null && in(x, y, SEEK_X0 - 3, SEEK_Y - 5, SEEK_X1 - SEEK_X0 + 6, 12)) { drag = 1; dragTo(x); return true; }
        if (in(x, y, VOL_X - 3, CTRL_Y - 7, VOL_W + 6, 14)) { drag = 2; dragTo(x); return true; }
        return false;
    }

    private void dragTo(int x) {
        if (drag == 1) {
            float fr = (x - SEEK_X0) / (float) (SEEK_X1 - SEEK_X0);
            dragMs = (long) (Math.max(0F, Math.min(1F, fr)) * PlayerEngine.length());
        } else if (drag == 2) {
            PlayerEngine.setVolume((x - VOL_X) / (float) VOL_W);
        }
    }

    private boolean clickHome(int x, int y) {
        int cx = 8, cy = BODY_Y + 4;
        if (PlayerEngine.current() != null) {
            int tx = cx + 78;
            if (in(x, y, tx, cy + 40, 30, 14)) { PlayerEngine.toggle(); return true; }
            if (in(x, y, tx + 34, cy + 40, 24, 14)) { PlayerEngine.toggleShuffle(); return true; }
        } else if (in(x, y, cx + 31, cy + 44, 80, 14)) { shuffleAll(); return true; }
        List<Albums.Album> own = new ArrayList<>();
        for (Albums.Album a : Albums.all()) if (a.owned()) own.add(a);
        for (int i = 0; i < Math.min(6, own.size()); i++) {
            int ax = 156 + (i % 3) * 40, ay = BODY_Y + 14 + (i / 3) * 40;
            if (in(x, y, ax, ay, 36, 36)) { openAlbum = own.get(own.size() - 1 - i).id(); scroll = 0; return true; }
        }
        return false;
    }

    private boolean clickSongs(int x, int y) {
        List<Song> l = songs();
        int i = (y - BODY_Y - 2 + scroll) / ROW_H;
        if (y - BODY_Y - 2 + scroll >= 0 && i >= 0 && i < l.size()) { playQueue(entriesOf(l), i); return true; }
        return false;
    }

    private boolean clickGrid(int x, int y) {
        List<Tile> l = tiles();
        int et = effTab();
        int col = (x - GX) / PITCH, row = (y - BODY_Y - 3 + scroll) / PITCH;
        if (x < GX || y - BODY_Y - 3 + scroll < 0 || col >= COLS) return false;
        int tx = GX + col * PITCH, ty = BODY_Y + 3 + row * PITCH - scroll;
        if (!in(x, y, tx, ty, TILE, TILE)) return false;
        int i = row * COLS + col;
        if (i < 0 || i >= l.size()) return false;
        Tile tl = l.get(i);
        if (Math.hypot(x - (tx + TILE / 2), y - (ty + 14)) <= 8) {       // the play button of the tile
            if (tl.album() != null) playAlbum(tl.album(), 0); else playArtist(tl.artist());
            return true;
        }
        if (et == 2) { setTab(3); artistFilter = tl.artist(); return true; }         // an artist: his albums
        openAlbum = tl.album().id();
        scroll = 0;
        return true;
    }

    private boolean clickDetail(int x, int y) {
        Albums.Album a = open();
        int bx = 106;
        if (a.owned()) {
            if (in(x, y, bx, BODY_Y + 2, 54, 14)) { playAlbum(a, 0); return true; }
            if (in(x, y, bx + 58, BODY_Y + 2, 54, 14)) { a.setOnPlayer(!a.onPlayer()); return true; }
            int top = BODY_Y + 21;
            int i = (y - top + scroll) / ROW_H;
            if (y >= top && x >= bx - 4 && i >= 0 && i < a.tracks().size()) { playAlbum(a, i); return true; }
        }
        return false;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (drag == 0) return false;
        dragTo(x);
        return true;
    }

    @Override
    public boolean release(int x, int y, int button) {
        if (drag == 1) PlayerEngine.seek(dragMs);
        boolean was = drag != 0;
        drag = 0;
        return was;
    }

    @Override
    public boolean scroll(double amount) {
        if (in(mx, my, 0, BODY_Y, W, BODY_H)) { scroll = Math.max(0, scroll - (int) Math.round(amount * 18)); return true; }
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        if (!typing) return false;
        if (c >= 32 && c != 127 && query.length() < 40) { query += c; scroll = 0; openAlbum = null; }
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (typing) {
            if (keyCode == 259) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); scroll = 0; return true; }   // backspace
            if (keyCode == 257 || keyCode == 335) { typing = false; return true; }                                                  // enter
            if (keyCode == 256) { if (!query.isEmpty()) query = ""; else typing = false; return true; }                              // escape
            if (keyCode == 86 && (modifiers & 2) != 0) {                                                                             // ctrl+V
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) { String all = query + clip.replaceAll("[\\r\\n]", " "); query = all.substring(0, Math.min(40, all.length())); scroll = 0; }
                return true;
            }
            return true;
        }
        switch (keyCode) {
            case 32 -> toggle();                                                       // space
            case 262 -> PlayerEngine.seek(PlayerEngine.position() + 5000);             // right: +5 s
            case 263 -> PlayerEngine.seek(PlayerEngine.position() - 5000);             // left: -5 s
            case 78 -> PlayerEngine.next();                                            // N
            case 80 -> PlayerEngine.prev();                                            // P
            case 47 -> typing = true;                                                  // /
            case 256 -> { if (openAlbum != null) { openAlbum = null; scroll = 0; } else if (artistFilter != null) { artistFilter = null; scroll = 0; } else return false; }   // escape: back
            default -> { return false; }
        }
        return true;
    }
}
