ALBUMS FOR THE MUSIC APP
========================
One folder = one album. Put your songs there and rebuild the mod (./gradlew build or runClient).

  music/My Album/01 First song.ogg
  music/My Album/02 Second song.ogg
  music/My Album/cover.png        <- optional square picture
  music/My Album/album.json       <- optional, see below

album.json (all fields optional):
  { "title": "My Album", "artist": "Me", "price": 70 }

- Songs must be .ogg (Vorbis). Convert: ffmpeg -i song.mp3 -c:a libvorbis -q:a 4 song.ogg
- Song names can be in any language: the name of the file is shown as the song title
  (a leading number like "01 - " is removed). Songs play in the order of the file names.
- price = coins in the Store tab. Every album costs 70 by default; put a price in album.json only to change it. price 0 = free album, already in your library.
