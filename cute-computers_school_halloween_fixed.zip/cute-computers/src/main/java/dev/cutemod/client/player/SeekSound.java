package dev.cutemod.client.player;

import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.AudioStream;
import net.minecraft.client.sounds.SoundBufferLibrary;
import net.minecraft.client.resources.sounds.Sound;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

import javax.sound.sampled.AudioFormat;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.CompletableFuture;

/**
 * A normal streamed sound that can start in the middle (that is how the player seeks and resumes after a pause)
 * and whose volume can be changed while it plays.
 */
final class SeekSound extends SimpleSoundInstance {
    private final long startMs;

    SeekSound(SoundEvent event, float volume, long startMs) {
        super(event.getLocation(), SoundSource.RECORDS, volume, 1F, RandomSource.create(), false, 0,
                SoundInstance.Attenuation.NONE, 0, 0, 0, true);
        this.startMs = startMs;
    }

    void setVol(float v) { this.volume = v; }

    @Override
    public CompletableFuture<AudioStream> getStream(SoundBufferLibrary library, Sound sound, boolean looping) {
        CompletableFuture<AudioStream> f = library.getStream(sound.getPath(), false);
        if (startMs <= 0) return f;
        return f.thenApply(s -> {
            try { return new SkipStream(s, startMs); } catch (IOException e) { return s; }
        });
    }

    /** Throws away the first part of the decoded sound, so the rest starts at the wanted time. */
    private static final class SkipStream implements AudioStream {
        private final AudioStream in;
        private long skip;

        SkipStream(AudioStream in, long ms) throws IOException {
            this.in = in;
            AudioFormat f = in.getFormat();
            long frames = (long) (ms / 1000.0 * f.getSampleRate());
            this.skip = frames * f.getFrameSize();
        }

        @Override
        public AudioFormat getFormat() throws IOException { return in.getFormat(); }

        @Override
        public ByteBuffer read(int size) throws IOException {
            while (skip > 0) {
                ByteBuffer b = in.read(65536);
                if (b == null || !b.hasRemaining()) return b == null ? ByteBuffer.allocate(0) : b;   // the song ended while skipping
                if (b.remaining() <= skip) { skip -= b.remaining(); continue; }
                b.position(b.position() + (int) skip);
                skip = 0;
                return b;
            }
            return in.read(size);
        }

        @Override
        public void close() throws IOException { in.close(); }
    }
}
