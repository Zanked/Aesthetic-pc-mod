package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Fly Catcher: a frog sits on a lily pad in the middle of a night swamp. Insects buzz around it. Aim with the mouse and
 * click to shoot the tongue: it flies to the cursor (but no further than the dashed ring) and sticks to the first
 * insect on the way. Flies, bluebottles, butterflies and dragonflies give points, a firefly also gives a bonus for one of
 * the four jars at the top (slow time, a long tongue, double points, a thunderclap). A wasp costs 200 points.
 * Catches in a row build a combo (the meter on the left): a miss or a wasp breaks it.
 * <p>
 * Eight levels: reach the goal score before the time bar runs out. A level that is lost costs a heart and is replayed.
 */
public class FlyCatcher extends MiniGame {
    private static final int LEVELS = 8, LIVES = 3, FX = 110, FY = 116, TICKS = 3300, COMBO_TIME = 170;
    private static final float RANGE = 66F, OUT = 7F, IN = 6F;
    private static final int FLY = 0, BLUEBOTTLE = 1, BUTTERFLY = 2, DRAGONFLY = 3, FIREFLY = 4, WASP = 5;
    private static final int[] VALUE = {50, 100, 150, 250, 200, -200};
    private static final float[] SPEED = {0.55F, 0.45F, 0.3F, 0.85F, 0.25F, 0.65F};
    private static final float[] RAD = {3F, 3.5F, 4.5F, 4F, 3.5F, 4F};
    private static final int J_SLOW = 0, J_LONG = 1, J_DOUBLE = 2, J_THUNDER = 3;
    private static final int[] JAR_COL = {0xFF6FB8FF, 0xFF7ED957, 0xFFFFD84A, 0xFFB57BFF};
    private static final int S_PLAY = 0, S_CLEAR = 1, S_FAIL = 2;
    private static final int JAR_X = 72, JAR_Y = 2, JAR_W = 16, JAR_H = 17, JAR_STEP = 19;

    private static final class Bug {
        final int kind;
        float x, y, a, turn, boost;
        int age, life, caught;
        boolean dead;

        Bug(int kind) { this.kind = kind; }
    }

    private static final class Fx {
        float x, y, vx, vy;
        int life, max, col, kind;
        String txt;
    }

    private final List<Bug> bugs = new ArrayList<>();
    private final List<Fx> fx = new ArrayList<>();
    private final int[] jars = new int[4];
    private int level, lives, state, stateT, scoreBase, levelPts, timeLeft, time;
    private int combo, comboT, slowT, longT, doubleT, hurtT, flash, bannerT, gulpT;
    private int tState, caughtSlot;
    private float tLen, tGoal, tAng;
    private Bug tCatch;
    private boolean won;

    // ------------------------------------------------------------------ start

    @Override
    public void reset() {
        score = 0; over = false; won = false; lives = LIVES; scoreBase = 0; time = 0;
        java.util.Arrays.fill(jars, 0);
        startLevel(0);
    }

    private void startLevel(int n) {
        level = n;
        state = S_PLAY; stateT = 0;
        levelPts = 0; timeLeft = TICKS; combo = 0; comboT = 0;
        slowT = 0; longT = 0; doubleT = 0; hurtT = 0; flash = 0; gulpT = 0;
        tState = 0; tLen = 0; tCatch = null;
        bannerT = 120;
        bugs.clear(); fx.clear();
        for (int i = 0; i < target() - 2; i++) spawn(true);
        score = scoreBase;
    }

    private int goal() { return 1000 * (level + 1); }

    private int target() { return Math.min(13, 5 + level); }

    private float range() { return RANGE * (longT > 0 ? 1.4F : 1F); }

    // ------------------------------------------------------------------ insects

    private void spawn(boolean inside) {
        float r = rnd.nextFloat();
        float wasp = Math.min(0.3F, 0.08F + 0.03F * level), c = wasp;
        int kind;
        if (r < c) kind = WASP;
        else if (r < (c += 0.04F)) kind = FIREFLY;
        else if (level >= 1 && r < (c += 0.08F)) kind = DRAGONFLY;
        else if (r < (c += 0.12F)) kind = BUTTERFLY;
        else if (r < (c += 0.25F)) kind = BLUEBOTTLE;
        else kind = FLY;
        Bug b = new Bug(kind);
        if (inside) {
            b.x = 10 + rnd.nextInt(W - 20);
            b.y = 14 + rnd.nextInt(H - 40);
            b.a = rnd.nextFloat() * 6.2832F;
        } else {
            switch (rnd.nextInt(3)) {
                case 0 -> { b.x = -8; b.y = 10 + rnd.nextInt(H - 40); }
                case 1 -> { b.x = W + 8; b.y = 10 + rnd.nextInt(H - 40); }
                default -> { b.x = 10 + rnd.nextInt(W - 20); b.y = -8; }
            }
            b.a = (float) Math.atan2(30 + rnd.nextInt(60) - b.y, 20 + rnd.nextInt(W - 40) - b.x);
        }
        b.life = 480 + rnd.nextInt(420);
        bugs.add(b);
    }

    private static float wrap(float a) {
        while (a > Math.PI) a -= 6.2832F;
        while (a < -Math.PI) a += 6.2832F;
        return a;
    }

    private void steer(Bug b, float tx, float ty, float k) {
        float want = (float) Math.atan2(ty - b.y, tx - b.x);
        b.a += wrap(want - b.a) * k;
    }

    private void moveBug(Bug b) {
        b.age++;
        float slow = slowT > 0 ? 0.4F : 1F;
        float sp = SPEED[b.kind] * (1F + 0.06F * level) * slow;
        if (b.age % (b.kind == DRAGONFLY ? 70 : 45) == 0) b.turn = (rnd.nextFloat() - 0.5F) * (b.kind == WASP ? 0.1F : 0.16F);
        if (b.kind == DRAGONFLY && b.age % 70 == 0) { b.boost = 1.8F; b.a += (rnd.nextFloat() - 0.5F) * 2F; }
        if (b.boost > 0) { sp *= 1F + b.boost; b.boost = Math.max(0F, b.boost - 0.03F); }
        b.a += b.turn;
        if (b.kind == BUTTERFLY) b.a += (float) Math.sin(b.age * 0.14F) * 0.05F;
        if (b.age > b.life) steer(b, b.x < W / 2F ? -40 : W + 40, b.y < H / 2F ? -40 : H + 40, 0.02F);
        else if (b.x < 6 || b.x > W - 6 || b.y < 8 || b.y > H - 20) steer(b, W / 2F, H / 2F - 10, 0.06F);
        b.x += (float) Math.cos(b.a) * sp;
        b.y += (float) Math.sin(b.a) * sp;
        if (b.age > b.life && (b.x < -12 || b.x > W + 12 || b.y < -12 || b.y > H + 12)) b.dead = true;
        if (b.age > b.life + 900) b.dead = true;
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        for (int i = 0; i < 4; i++) {
            if (in(x, y, JAR_X + i * JAR_STEP, JAR_Y, JAR_W, JAR_H)) { useJar(i); return true; }
        }
        shoot();
        return true;
    }

    @Override
    public boolean key(int keyCode) {
        if (over) return false;
        if (keyCode >= 49 && keyCode <= 52) { useJar(keyCode - 49); return true; }
        if (keyCode == KEY_SPACE) { shoot(); return true; }
        return false;
    }

    private void shoot() {
        if (state != S_PLAY || tState != 0) return;
        tAng = (float) Math.atan2(my - FY, mx - FX);
        float ox = FX + (float) Math.cos(tAng) * 7F, oy = FY - 1 + (float) Math.sin(tAng) * 7F;
        float d = (float) Math.sqrt((mx - ox) * (mx - ox) + (my - oy) * (my - oy));
        tGoal = Math.max(12F, Math.min(range(), d + 3F));
        tLen = 0; tState = 1; tCatch = null;
        sound(SoundEvents.FROG_TONGUE, 1F + rnd.nextFloat() * 0.2F, 0.8F);
    }

    private void useJar(int i) {
        if (state != S_PLAY || jars[i] <= 0) return;
        jars[i]--;
        switch (i) {
            case J_SLOW -> { slowT = 480; sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 1F); }
            case J_LONG -> { longT = 600; sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.1F, 1F); }
            case J_DOUBLE -> { doubleT = 600; sound(SoundEvents.PLAYER_LEVELUP, 1.4F, 0.6F); }
            default -> thunder();
        }
    }

    private void thunder() {
        flash = 16;
        sound(SoundEvents.LIGHTNING_BOLT_THUNDER, 1.4F, 0.5F);
        int mult = doubleT > 0 ? 2 : 1;
        for (Bug b : bugs) {
            if (b.dead || b.caught > 0) continue;
            float dx = b.x - FX, dy = b.y - FY;
            if (dx * dx + dy * dy > range() * range()) continue;
            b.dead = true;
            puff(b.x, b.y, 0xFFFFF0A0, 6);
            if (b.kind == WASP) continue;
            int v = VALUE[b.kind] * mult;
            levelPts += v;
            pts(b.x, b.y - 4, "+" + v, 0xFFFFFFFF);
            if (b.kind == FIREFLY) gainJar(b.x, b.y);
        }
        sync();
        checkGoal();
    }

    private void gainJar(float x, float y) {
        int t = rnd.nextInt(4);
        jars[t] = Math.min(3, jars[t] + 1);
        puff(x, y, JAR_COL[t], 8);
        sound(SoundEvents.NOTE_BLOCK_CHIME, 1.6F, 0.7F);
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        time++;
        if (bannerT > 0) bannerT--;
        if (hurtT > 0) hurtT--;
        if (gulpT > 0) gulpT--;
        if (flash > 0) flash--;
        tickFx();
        if (state == S_CLEAR) {
            if (--stateT <= 0) {
                if (level + 1 >= LEVELS) { won = true; over = true; }
                else startLevel(level + 1);
            }
            return;
        }
        if (state == S_FAIL) {
            if (--stateT <= 0) {
                if (lives <= 0) { won = false; over = true; }
                else startLevel(level);
            }
            return;
        }
        if (slowT > 0) slowT--;
        if (longT > 0) longT--;
        if (doubleT > 0) doubleT--;
        if (comboT > 0 && --comboT == 0) combo = 0;
        for (Bug b : bugs) if (b.caught == 0) moveBug(b);
        tickTongue();
        bugs.removeIf(b -> b.dead);
        if (bugs.size() < target() && rnd.nextInt(26) == 0) spawn(false);
        if (--timeLeft <= 0) timeUp();
    }

    private void tickTongue() {
        if (tState == 0) return;
        float ox = FX + (float) Math.cos(tAng) * 7F, oy = FY - 1 + (float) Math.sin(tAng) * 7F;
        if (tState == 1) {
            float prev = tLen;
            tLen = Math.min(tGoal, tLen + OUT);
            for (float l = prev; l <= tLen + 0.01F && tCatch == null; l += 2F) {
                float tx = ox + (float) Math.cos(tAng) * l, ty = oy + (float) Math.sin(tAng) * l;
                for (Bug b : bugs) {
                    if (b.dead || b.caught > 0) continue;
                    float dx = b.x - tx, dy = b.y - ty, r = RAD[b.kind] + 2.5F;
                    if (dx * dx + dy * dy <= r * r) { tCatch = b; b.caught = 1; tLen = l; break; }
                }
            }
            if (tCatch != null) {
                sound(tCatch.kind == WASP ? SoundEvents.BEE_STING : SoundEvents.SLIME_SQUISH_SMALL, 1.2F, 0.8F);
                tState = 2;
            } else if (tLen >= tGoal) tState = 2;
        } else {
            tLen -= IN;
            if (tCatch != null) {
                tCatch.x = ox + (float) Math.cos(tAng) * tLen;
                tCatch.y = oy + (float) Math.sin(tAng) * tLen;
            }
            if (tLen <= 4F) deliver();
        }
    }

    private void deliver() {
        tState = 0; tLen = 0;
        Bug b = tCatch;
        tCatch = null;
        if (b == null) { combo = 0; comboT = 0; return; }       // a miss breaks the combo
        b.dead = true;
        float px = FX, py = FY - 16;
        if (b.kind == WASP) {
            levelPts += VALUE[WASP];
            combo = 0; comboT = 0; hurtT = 40;
            pts(px, py, "" + VALUE[WASP], 0xFFFF5A5A);
            sound(SoundEvents.FROG_HURT, 1F, 0.9F);
        } else {
            combo++; comboT = COMBO_TIME; gulpT = 12;
            int v = VALUE[b.kind] * Math.min(5, 1 + combo / 3) * (doubleT > 0 ? 2 : 1);
            levelPts += v;
            pts(px, py, "+" + v, b.kind == FIREFLY ? 0xFFE8FF7A : 0xFFFFFFFF);
            puff(px, py + 6, 0xFFFFE27A, 3);
            sound(SoundEvents.FROG_EAT, 1F, 0.9F);
            if (b.kind == FIREFLY) gainJar(px, py);
        }
        sync();
        checkGoal();
    }

    private void sync() { score = Math.max(0, scoreBase + levelPts); }

    private void checkGoal() {
        if (state != S_PLAY || levelPts < goal()) return;
        int bonus = timeLeft / 60 * 10;
        scoreBase += Math.max(0, levelPts) + bonus;
        score = scoreBase;
        state = S_CLEAR; stateT = 150;
        tState = 0; tCatch = null;
        pts(W / 2F, 52, "+" + bonus, 0xFFFFD866);
        sound(SoundEvents.PLAYER_LEVELUP, 1.1F, 0.8F);
    }

    private void timeUp() {
        lives--;
        score = scoreBase;
        state = S_FAIL; stateT = 120;
        tState = 0; tCatch = null;
        sound(SoundEvents.VILLAGER_NO, 1F, 0.8F);
    }

    // ------------------------------------------------------------------ effects

    private void pts(float x, float y, String s, int col) {
        Fx f = new Fx();
        f.kind = 3; f.x = x; f.y = y; f.vy = -0.4F; f.life = f.max = 55; f.txt = s; f.col = col;
        fx.add(f);
    }

    private void puff(float x, float y, int col, int n) {
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.kind = 1; f.x = x; f.y = y; f.col = col;
            f.vx = (rnd.nextFloat() - 0.5F) * 2.2F; f.vy = (rnd.nextFloat() - 0.5F) * 2.2F;
            f.life = f.max = 16 + rnd.nextInt(10);
            fx.add(f);
        }
    }

    private void tickFx() {
        for (Fx f : fx) {
            f.life--;
            f.x += f.vx; f.y += f.vy;
            if (f.kind == 1) { f.vx *= 0.93F; f.vy *= 0.93F; }
        }
        fx.removeIf(f -> f.life <= 0);
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF0A1442, 0xFF123478);
        scenery(g);
        ringOfRange(g);
        for (Bug b : bugs) drawBug(g, b);
        drawFrog(g);
        drawTongue(g);
        for (Fx f : fx) drawFx(g, f);
        if (flash > 0) g.fill(0, 0, W, H, Gfx.alpha(0xFFFFFFFF, flash * 9));
        if (slowT > 0) g.fill(0, 0, W, H, Gfx.alpha(0xFF3A7AFF, 22));
        Gfx.vignette(g, W, H, 40);
        drawCursor(g);
        hud(g);
    }

    private void scenery(GuiGraphics g) {
        for (int i = 0; i < 70; i++) {                                    // clover specks on the water
            int x = (int) (Gfx.hash(i, 1) * W), y = (int) (Gfx.hash(i, 2) * H), c = Gfx.hash(i, 3) > 0.5F ? 0x663FB04D : 0x4430884A;
            g.fill(x, y - 1, x + 1, y + 2, c);
            g.fill(x - 1, y, x + 2, y + 1, c);
        }
        for (int i = 0; i < 5; i++) Gfx.ellipse(g, (int) (Gfx.hash(i, 4) * W), (int) (Gfx.hash(i, 5) * H), 16, 5, 0x1A000000);
        pad(g, 34, 36, 17, 0xFF3FB44A);
        pad(g, 186, 34, 17, 0xFF39AE4A);
        spotted(g, 112, 27, 15);
        stump(g, 30, 106, 14);
        stump(g, 191, 106, 14);
        flower(g, 66, 40, 0xFFFFFFFF, 0xFFA8C8FF);
        flower(g, 154, 124, 0xFFFFFFFF, 0xFFA8C8FF);
        flower(g, 196, 62, 0xFFFFFFFF, 0xFFFFD84A);
        leaves(g, FX - 40, FY - 8, -1);
        leaves(g, FX + 40, FY - 8, 1);
        float s = (float) Math.sin(time * 0.04F);
        Gfx.ellipse(g, FX, FY + 4, 17, 11, 0xFF1F7A3A);                      // the frog's lily pad
        Gfx.ellipse(g, FX, FY + 3, 16, 10, 0xFF38B04C);
        Gfx.ellipse(g, FX + Math.round(s), FY + 5, 8, 3, 0x22FFFFFF);
    }

    private static void pad(GuiGraphics g, int cx, int cy, int r, int col) {
        Gfx.disc(g, cx, cy, r + 1, Gfx.darker(col, 0.45F));
        Gfx.disc(g, cx, cy, r, col);
        Gfx.disc(g, cx, cy, r - 5, Gfx.lighter(col, 0.18F));
        Gfx.disc(g, cx, cy, r / 4, Gfx.darker(col, 0.2F));
        g.fill(cx, cy - r, cx + 1, cy, Gfx.darker(col, 0.45F));                 // the notch
        g.fill(cx - 1, cy - r, cx + 2, cy - r / 2, 0xFF123478);
    }

    private static void spotted(GuiGraphics g, int cx, int cy, int r) {
        pad(g, cx, cy, r, 0xFF8ED04A);
        int[][] holes = {{-6, -2, 2}, {1, -6, 2}, {5, 0, 3}, {-3, 5, 2}, {2, 4, 2}, {-8, 3, 1}};
        for (int[] h : holes) Gfx.disc(g, cx + h[0], cy + h[1], h[2], 0xFF0F2A66);
    }

    private static void stump(GuiGraphics g, int cx, int cy, int r) {
        Gfx.disc(g, cx, cy, r + 2, 0xFF2E7A34);
        Gfx.disc(g, cx, cy, r, 0xFF8A6A2E);
        Gfx.disc(g, cx, cy, r - 3, 0xFFA88A44);
        Gfx.disc(g, cx, cy, r / 2, 0xFF8A6A2E);
        Gfx.disc(g, cx - 2, cy - 2, 2, 0x55FFFFFF);
    }

    private static void flower(GuiGraphics g, int cx, int cy, int petal, int core) {
        for (int i = 0; i < 5; i++) {
            double a = i * 1.2566 + 0.4;
            Gfx.disc(g, cx + (int) Math.round(Math.cos(a) * 4), cy + (int) Math.round(Math.sin(a) * 4), 2, petal);
        }
        Gfx.disc(g, cx, cy, 2, core);
    }

    private static void leaves(GuiGraphics g, int cx, int cy, int dir) {
        for (int i = 0; i < 4; i++) {
            int ex = cx + dir * (4 + i * 4), ey = cy - 12 + i * 3 - (i == 1 ? 4 : 0);
            Gfx.line(g, cx, cy + 6, ex, ey, 0xFF2E9A44);
            Gfx.line(g, cx + 1, cy + 6, ex + dir, ey, 0xFF52C45E);
        }
    }

    private void ringOfRange(GuiGraphics g) {
        float r = range();
        int col = tState == 0 ? 0xAAE0505A : 0x66E0505A;
        for (int i = 0; i < 90; i++) {
            if (i % 2 == 1) continue;
            double a = i * Math.PI * 2 / 90 + time * 0.003;
            int x = FX + (int) Math.round(Math.cos(a) * r), y = FY + (int) Math.round(Math.sin(a) * r);
            if (x >= 0 && y >= 0 && x < W && y < H) g.fill(x, y, x + 1, y + 1, col);
        }
        if (longT > 0) Gfx.glow(g, FX, FY, 12, 0xFF7ED957, 70);
    }

    private void drawBug(GuiGraphics g, Bug b) {
        int x = Math.round(b.x), y = Math.round(b.y);
        if (x < -8 || x > W + 8 || y < -8 || y > H + 8) return;
        boolean flap = (time / 2 + (int) (b.x * 0.3F)) % 2 == 0;
        int wing = 0xB0E8F4FF;
        switch (b.kind) {
            case FLY -> {
                Gfx.ellipse(g, x - 2, y - 2 + (flap ? 0 : 1), 2, 1, wing);
                Gfx.ellipse(g, x + 2, y - 2 + (flap ? 1 : 0), 2, 1, wing);
                Gfx.disc(g, x, y, 2, 0xFF2A2A34);
                g.fill(x - 1, y - 1, x, y, 0xFFE04040);
                g.fill(x + 1, y - 1, x + 2, y, 0xFFE04040);
            }
            case BLUEBOTTLE -> {
                Gfx.ellipse(g, x - 3, y - 2 + (flap ? 0 : 1), 3, 1, wing);
                Gfx.ellipse(g, x + 3, y - 2 + (flap ? 1 : 0), 3, 1, wing);
                Gfx.ball(g, x, y, 3, 0xFF2FB6A4);
                g.fill(x - 1, y - 1, x + 2, y, 0xFFB8FFF0);
                g.fill(x - 2, y - 3, x - 1, y - 2, 0xFFE04040);
                g.fill(x + 1, y - 3, x + 2, y - 2, 0xFFE04040);
            }
            case BUTTERFLY -> {
                int sp = flap ? 5 : 3;
                Gfx.ellipse(g, x - sp / 2 - 1, y - 1, sp, 3, 0xFFFF8FC8);
                Gfx.ellipse(g, x + sp / 2 + 1, y - 1, sp, 3, 0xFFFF8FC8);
                Gfx.ellipse(g, x - sp / 2, y + 2, sp - 1, 2, 0xFFFFC27A);
                Gfx.ellipse(g, x + sp / 2, y + 2, sp - 1, 2, 0xFFFFC27A);
                g.fill(x, y - 3, x + 1, y + 4, 0xFF4A2A44);
            }
            case DRAGONFLY -> {
                int dx = Math.round((float) Math.cos(b.a) * 4), dy = Math.round((float) Math.sin(b.a) * 4);
                Gfx.line(g, x - dx, y - dy, x + dx, y + dy, 0xFF2FD0E8);
                Gfx.disc(g, x + dx, y + dy, 1, 0xFF1A8AA0);
                Gfx.ellipse(g, x, y - 2 + (flap ? 0 : 1), 5, 1, wing);
                Gfx.ellipse(g, x, y + 2 + (flap ? 1 : 0), 5, 1, wing);
            }
            case FIREFLY -> {
                float p = 0.6F + 0.4F * (float) Math.sin(time * 0.15F + b.x);
                Gfx.glow(g, x, y, 9, 0xFFD8FF50, Math.round(120 * p));
                Gfx.disc(g, x, y, 2, 0xFFEFFF8A);
                g.fill(x - 3, y - 2 + (flap ? 0 : 1), x - 1, y - 1 + (flap ? 0 : 1), wing);
                g.fill(x + 1, y - 2 + (flap ? 1 : 0), x + 3, y - 1 + (flap ? 1 : 0), wing);
                g.fill(x - 1, y - 1, x + 1, y + 1, 0xFFFFFFFF);
            }
            default -> {                                                         // a wasp: yellow and black stripes, angry red eyes
                Gfx.ellipse(g, x - 2, y - 3 + (flap ? 0 : 1), 3, 1, wing);
                Gfx.ellipse(g, x + 2, y - 3 + (flap ? 1 : 0), 3, 1, wing);
                Gfx.ellipse(g, x, y, 4, 3, 0xFFFFD02A);
                g.fill(x - 2, y - 2, x - 1, y + 3, 0xFF2A2420);
                g.fill(x + 1, y - 2, x + 2, y + 3, 0xFF2A2420);
                g.fill(x - 4, y - 1, x - 3, y + 1, 0xFFE03030);
                g.fill(x + 4, y + 2, x + 6, y + 3, 0xFF2A2420);                    // the sting
            }
        }
    }

    private void drawFrog(GuiGraphics g) {
        float ang = (float) Math.atan2(my - FY, mx - FX);
        boolean hurt = hurtT > 0;
        int body = hurt ? 0xFF8FC24A : 0xFF4FCF3F, dark = Gfx.darker(body, 0.35F);
        int shake = hurt ? (time % 4 < 2 ? -1 : 1) : 0;
        int cx = FX + shake, cy = FY;
        Gfx.ellipse(g, cx - 9, cy + 6, 5, 3, dark);                                  // the back legs
        Gfx.ellipse(g, cx + 9, cy + 6, 5, 3, dark);
        Gfx.ellipse(g, cx, cy + 2, 9, 7, body);                                      // the body
        Gfx.ellipse(g, cx, cy + 4, 6, 4, 0xFFE6F7A8);                                // the belly
        Gfx.ellipse(g, cx - 5, cy + 9, 3, 2, body);                                  // the front feet
        Gfx.ellipse(g, cx + 5, cy + 9, 3, 2, body);
        Gfx.ball(g, cx, cy - 3, 8, body);                                            // the head
        int ex = Math.round((float) Math.cos(ang) * 1.4F), ey = Math.round((float) Math.sin(ang) * 1.4F);
        for (int s = -1; s <= 1; s += 2) {                                           // the big eyes follow the cursor
            int ox = cx + s * 5, oy = cy - 9;
            Gfx.ball(g, ox, oy, 3, body);
            Gfx.disc(g, ox, oy, 2, 0xFFFFFFFF);
            if (hurt) { g.fill(ox - 1, oy - 1, ox + 2, oy, 0xFF1A1428); g.fill(ox - 1, oy + 1, ox + 2, oy + 2, 0xFF1A1428); }
            else g.fill(ox + ex, oy + ey, ox + ex + 2, oy + ey + 2, 0xFF1A1428);
        }
        g.fill(cx - 3, cy - 4, cx - 2, cy - 3, dark);                                // the nostrils
        g.fill(cx + 2, cy - 4, cx + 3, cy - 3, dark);
        int my2 = cy - 1;
        if (tState == 0 && gulpT <= 0) {                                             // a smile
            g.fill(cx - 4, my2, cx + 5, my2 + 1, dark);
            g.fill(cx - 5, my2 - 1, cx - 4, my2, dark);
            g.fill(cx + 5, my2 - 1, cx + 6, my2, dark);
        } else if (gulpT > 0) {
            g.fill(cx - 4, my2, cx + 5, my2 + 1, dark);
            g.fill(cx - 3, my2 + 1, cx + 4, my2 + 2, 0xFFFF8FA8);
        } else {
            Gfx.ellipse(g, cx, my2, 3, 2, 0xFF7A1F34);                               // the mouth is open
        }
        g.fill(cx - 6, cy + 1, cx - 4, cy + 3, Gfx.alpha(0xFFFF9FB5, 150));          // the blush
        g.fill(cx + 5, cy + 1, cx + 7, cy + 3, Gfx.alpha(0xFFFF9FB5, 150));
    }

    private void drawTongue(GuiGraphics g) {
        if (tState == 0 || tLen <= 0) return;
        float ox = FX + (float) Math.cos(tAng) * 7F, oy = FY - 1 + (float) Math.sin(tAng) * 7F;
        int tx = Math.round(ox + (float) Math.cos(tAng) * tLen), ty = Math.round(oy + (float) Math.sin(tAng) * tLen);
        Gfx.line(g, Math.round(ox), Math.round(oy), tx, ty, 0xFFC02244);
        Gfx.line(g, Math.round(ox) + 1, Math.round(oy), tx + 1, ty, 0xFFFF5A78);
        Gfx.line(g, Math.round(ox), Math.round(oy) + 1, tx, ty + 1, 0xFFFF5A78);
        Gfx.disc(g, tx, ty, 2, 0xFFFF7A92);
        if (tCatch != null) drawBug(g, tCatch);
    }

    private void drawCursor(GuiGraphics g) {
        if (state != S_PLAY || over) return;
        boolean reach = (mx - FX) * (mx - FX) + (my - FY) * (my - FY) <= range() * range();
        int col = reach ? 0xFFFFFFFF : 0x88FFFFFF;
        Bug under = null;
        for (Bug b : bugs) {
            if (b.dead || b.caught > 0) continue;
            float dx = b.x - mx, dy = b.y - my;
            if (dx * dx + dy * dy < 49) { under = b; break; }
        }
        for (int i = 0; i < 16; i++) {
            double a = i * Math.PI / 8;
            int x = mx + (int) Math.round(Math.cos(a) * 5), y = my + (int) Math.round(Math.sin(a) * 5);
            g.fill(x, y, x + 1, y + 1, col);
        }
        g.fill(mx, my, mx + 1, my + 1, col);
        if (under != null && reach) {
            int v = VALUE[under.kind];
            ctext(g, v > 0 ? "" + v : "" + v, mx, my - 15, v > 0 ? 0xFFFFE27A : 0xFFFF6A6A);
        }
    }

    private void drawFx(GuiGraphics g, Fx f) {
        int x = Math.round(f.x), y = Math.round(f.y);
        float t = f.life / (float) f.max;
        if (f.kind == 1) Gfx.disc(g, x, y, Math.max(1, Math.round(3 * t)), Gfx.fade(f.col, t));
        else ctext(g, f.txt, x, y, Gfx.fade(f.col, Math.min(1F, t * 2F)));
    }

    private void hud(GuiGraphics g) {
        Gfx.rrect(g, 3, 3, 56, 11, 3, Gfx.fade(0xFF000000, 0.4F));
        text(g, Component.translatable("cutemod.frog.level", level + 1, LEVELS).getString(), 7, 5, 0xFFFFD866);
        Gfx.rrect(g, W - 62, 3, 59, 11, 3, Gfx.fade(0xFF000000, 0.4F));
        text(g, Component.translatable("cutemod.frog.goal", goal()).getString(), W - 58, 5, 0xFFFFFFFF);
        int sc = scoreBase + levelPts;
        text(g, "" + sc, W - 6 - tw("" + sc), 16, sc < scoreBase ? 0xFFFF7A7A : 0xFFB8F0FF);
        for (int i = 0; i < 4; i++) {                                                // the four jars
            int x = JAR_X + i * JAR_STEP, y = JAR_Y;
            Gfx.rrect(g, x, y, JAR_W, JAR_H, 3, Gfx.fade(0xFF000000, 0.45F));
            Gfx.outline(g, x, y, JAR_W, JAR_H, jars[i] > 0 ? Gfx.alpha(JAR_COL[i], 220) : 0x44FFFFFF);
            if (jars[i] > 0) {
                Gfx.glow(g, x + 8, y + 8, 7, JAR_COL[i], 90);
                Gfx.disc(g, x + 8, y + 7, 3, JAR_COL[i]);
                text(g, "" + jars[i], x + 11, y + 8, 0xFFFFFFFF);
            } else Gfx.disc(g, x + 8, y + 7, 3, 0x33FFFFFF);
            text(g, "" + (i + 1), x + 2, y + 1, 0x88FFFFFF);
        }
        // the active bonuses
        int ax = 4;
        if (slowT > 0) { Gfx.rrect(g, ax, 112, 5, 5, 1, JAR_COL[J_SLOW]); ax += 7; }
        if (longT > 0) { Gfx.rrect(g, ax, 112, 5, 5, 1, JAR_COL[J_LONG]); ax += 7; }
        if (doubleT > 0) { Gfx.rrect(g, ax, 112, 5, 5, 1, JAR_COL[J_DOUBLE]); }
        // the combo meter on the left
        Gfx.rrect(g, 4, 24, 6, 70, 3, Gfx.fade(0xFF000000, 0.4F));
        int fill = Math.round(66F * comboT / COMBO_TIME);
        if (fill > 0) Gfx.rrect(g, 5, 25 + 68 - fill - 2, 4, Math.max(1, fill), 2, Gfx.mix(0xFFFFC23A, 0xFFFF5A8A, Math.min(1F, combo / 12F)));
        if (combo >= 3) ctext(g, "x" + Math.min(5, 1 + combo / 3) * (doubleT > 0 ? 2 : 1), 7, 96, 0xFFFFE27A);
        // lives and the time bar
        Gfx.heart(g, 4, H - 10, 0xFFFF6A8E);
        text(g, "x" + lives, 13, H - 11, 0xFFFFFFFF);
        int bx = 26, bw = W - 40, by = H - 7;
        Gfx.rrect(g, bx - 1, by - 1, bw + 2, 6, 3, Gfx.fade(0xFF000000, 0.55F));
        float k = Math.max(0F, timeLeft / (float) TICKS);
        int col = k > 0.5F ? 0xFF4A9CF0 : k > 0.2F ? 0xFFF0C23A : 0xFFE0485A;
        if (k > 0) Gfx.rrect(g, bx, by, Math.max(2, Math.round(bw * k)), 4, 2, col);
        int sx = bx + Math.round(bw * (1F - k));
        Gfx.ellipse(g, sx, by - 1, 4, 3, 0xFFD2A060);                                  // a snail crawls along the bar
        Gfx.disc(g, sx, by - 2, 2, 0xFF9A6A38);
        g.fill(sx + 3, by - 4, sx + 4, by - 2, 0xFFE8D8B8);

        if (bannerT > 0 && state == S_PLAY) banner(g, Component.translatable("cutemod.frog.start", goal()).getString());
        if (state == S_CLEAR) banner(g, Component.translatable("cutemod.frog.clear").getString());
        if (state == S_FAIL) banner(g, Component.translatable("cutemod.frog.fail").getString());
    }

    private static void banner(GuiGraphics g, String s) {
        int w = Math.min(W - 20, tw(s) + 24);
        Gfx.rrect(g, (W - w) / 2, 56, w, 16, 5, Gfx.fade(0xFF000000, 0.55F));
        ctext(g, s, W / 2, 60, 0xFFFFD866);
    }

    // ------------------------------------------------------------------ misc

    @Override
    public String hintKey() { return "cutemod.hint.frog"; }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return won ? Component.translatable("cutemod.frog.won") : Component.translatable("cutemod.ui.gameover");
    }
}
