package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Tamagotchi: every computer color has its own pet. Feed it, play with it, let it sleep, pet it.
 * The pet is saved to cutemod_pet_&lt;color&gt;.txt and slowly gets hungry even while you are away.
 */
public class PetApp extends App {
    private static final int CX = 150, CY = 96, FLOOR = 124, BTN_Y = 146, BTN_W = 90, BTN_H = 16;
    private static final int[] BTN_X = {6, 105, 204};
    private static final int DARK = 0xFF3A2A3A;

    private double food = 70, fun = 70, energy = 80;
    private boolean sleeping, loaded;
    private long ageSec;
    private double ageAcc;
    private int ticks, jump, shake, saveTimer, msgTimer;
    private String msg = "";
    private final List<double[]> parts = new ArrayList<>(); // x, y, vx, vy, life, type (0 heart, 1 crumb)
    private final Random rnd = new Random();

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        if (!loaded) { loaded = true; load(); }
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.pet"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.pet"); }

    @Override
    public Component status() {
        return Component.translatable("cutemod.pet.status", t("cutemod.pet.name." + shell.color().id), 1 + ageSec / 600);
    }

    // ---------- save / load ----------
    private Path file() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("cutemod_pet_" + shell.color().id + ".txt");
    }

    private void load() {
        try {
            Path p = file();
            if (!Files.exists(p)) return;
            String[] a = Files.readString(p).trim().split("\\s+");
            food = Double.parseDouble(a[0]);
            fun = Double.parseDouble(a[1]);
            energy = Double.parseDouble(a[2]);
            sleeping = a[3].equals("1");
            ageSec = Long.parseLong(a[4]);
            long away = Math.min(7200, Math.max(0, (System.currentTimeMillis() - Long.parseLong(a[5])) / 1000));
            if (sleeping) {
                energy = Math.min(100, energy + away * 0.05);
                food = Math.max(10, food - away * 0.01);
                if (energy >= 100) sleeping = false;
            } else {
                food = Math.max(15, food - away * 0.01);
                fun = Math.max(15, fun - away * 0.008);
                energy = Math.max(20, energy - away * 0.005);
            }
        } catch (Exception ignored) {
        }
    }

    private void save() {
        try {
            Files.writeString(file(), String.format(Locale.ROOT, "%.2f %.2f %.2f %d %d %d",
                    food, fun, energy, sleeping ? 1 : 0, ageSec, System.currentTimeMillis()));
        } catch (Exception ignored) {
        }
    }

    @Override
    public void close() { if (loaded) save(); }

    // ---------- logic ----------
    private static double clamp(double v) { return Math.max(0, Math.min(100, v)); }

    private static void sound(float pitch) {
        Minecraft.getInstance().getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
                net.minecraft.sounds.SoundEvents.NOTE_BLOCK_CHIME.value(), pitch, 0.5F));
    }

    private void say(String key) { msg = t(key); msgTimer = 150; }

    private void burst(int type, int n) {
        for (int i = 0; i < n; i++) {
            double x = CX - 15 + rnd.nextInt(30);
            if (type == 0) parts.add(new double[]{x, CY - 24, (rnd.nextDouble() - 0.5) * 0.5, -0.5, 55 + rnd.nextInt(20), 0});
            else parts.add(new double[]{x, CY - 44, (rnd.nextDouble() - 0.5) * 0.2, 0.7, 28, 1});
        }
    }

    private void feed() {
        if (sleeping) { say("cutemod.pet.say.zzz"); return; }
        if (food >= 95) { say("cutemod.pet.say.full"); shake = 30; return; }
        food = clamp(food + 25);
        burst(1, 4);
        sound(1.3F);
        Progress.onPet("feed");
    }

    private void play() {
        if (sleeping) { say("cutemod.pet.say.zzz"); return; }
        if (energy < 12) { say("cutemod.pet.say.tired"); shake = 30; return; }
        fun = clamp(fun + 25);
        energy = clamp(energy - 8);
        food = clamp(food - 4);
        jump = 60;
        burst(0, 3);
        sound(1.7F);
        Progress.onPet("play");
    }

    private void toggleSleep() {
        sleeping = !sleeping;
        sound(sleeping ? 0.6F : 1.4F);
    }

    private void pet() {
        fun = clamp(fun + 1.5);
        jump = Math.max(jump, 15);
        burst(0, 1);
        sound(1.5F);
        Progress.onPet("pet");
        if (sleeping) { sleeping = false; say("cutemod.pet.say.pet"); }
    }

    @Override
    public void tick() {
        ticks++;
        if (jump > 0) jump--;
        if (shake > 0) shake--;
        if (msgTimer > 0) msgTimer--;
        double dt = 1 / 60.0;
        if (sleeping) {
            energy += 0.4 * dt;
            food -= 0.02 * dt;
            if (energy >= 100) { sleeping = false; say("cutemod.pet.say.rested"); }
        } else {
            food -= 0.05 * dt;
            fun -= 0.04 * dt;
            energy -= 0.03 * dt;
        }
        food = clamp(food); fun = clamp(fun); energy = clamp(energy);
        ageAcc += dt;
        if (ageAcc >= 1) { ageAcc -= 1; ageSec++; }
        for (int i = parts.size() - 1; i >= 0; i--) {
            double[] p = parts.get(i);
            p[0] += p[2];
            p[1] += p[3];
            if (p[5] == 1) p[3] += 0.03;
            if (--p[4] <= 0) parts.remove(i);
        }
        if (++saveTimer > 1800) { saveTimer = 0; save(); } // every 30 s
    }

    private int mood() {
        double m = (food + fun + energy) / 3;
        return (food < 20 || m < 35) ? 0 : m >= 65 ? 2 : 1;
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        int body = shell.color().bodyColor;

        // room
        g.fillGradient(0, 0, W, FLOOR - 14, mix(body, 0xFFFFFF, 0.75f), mix(body, 0xFFFFFF, 0.5f));
        rect(g, 0, FLOOR - 14, W, H - FLOOR + 14, 0xFFD9B98A);
        for (int x = 0; x < W; x += 30) rect(g, x, FLOOR - 14, 1, H - FLOOR + 14, 0xFFC9A678);
        rect(g, 0, FLOOR - 14, W, 2, 0xFFB98F5E);
        // window
        rect(g, 14, 12, 46, 40, 0xFF8A6A4A);
        rect(g, 17, 15, 40, 34, sleeping ? 0xFF1B2A5A : 0xFF9AD8FF);
        rect(g, 36, 15, 2, 34, 0xFF8A6A4A);
        rect(g, 17, 31, 40, 2, 0xFF8A6A4A);
        if (sleeping) { disc(g, 46, 24, 5, 0xFFFFF3B0); rect(g, 24, 20, 1, 1, 0xFFFFFFFF); rect(g, 28, 40, 1, 1, 0xFFFFFFFF); }
        else { disc(g, 26, 22, 5, 0xFFFFE066); }

        // stats
        stat(g, 8, "cutemod.pet.food", food);
        stat(g, 20, "cutemod.pet.fun", fun);
        stat(g, 32, "cutemod.pet.energy", energy);

        // pet
        int mood = mood();
        double bob = sleeping ? Math.sin(ticks / 40.0) * 1.0 : Math.sin(ticks / 20.0) * 1.5;
        double hop = jump > 0 ? Math.abs(Math.sin(jump * 0.2)) * 14 : 0;
        int px = CX + (shake > 0 ? (int) Math.round(Math.sin(shake * 1.2) * 3) : 0);
        int py = CY + (int) Math.round(bob - hop);
        int sw = (int) (24 - hop / 2); // shadow shrinks while jumping
        rect(g, CX - sw, FLOOR, sw * 2, 3, 0x33000000);
        rect(g, CX - sw + 3, FLOOR + 3, sw * 2 - 6, 1, 0x22000000);
        drawPet(g, px, py, mood);

        if (sleeping) {
            rect(g, 0, 0, W, FLOOR + 10, 0x66102040);
            for (int i = 0; i < 3; i++) {
                int zt = (ticks / 25 + i) % 3;
                g.drawString(f, "z", CX + 20 + zt * 7, py - 26 - zt * 7 - i * 0, 0xFFFFFFFF, false);
            }
        }

        // particles
        for (double[] p : parts) {
            int x = (int) p[0], y = (int) p[1];
            if (p[5] == 0) { // heart
                rect(g, x, y + 1, 5, 2, 0xFFFF5C93);
                rect(g, x + 1, y, 1, 1, 0xFFFF5C93);
                rect(g, x + 3, y, 1, 1, 0xFFFF5C93);
                rect(g, x + 1, y + 3, 3, 1, 0xFFFF5C93);
                rect(g, x + 2, y + 4, 1, 1, 0xFFFF5C93);
            } else {
                rect(g, x, y, 3, 3, 0xFFC98B5A);
            }
        }

        // speech bubble
        String say = bubbleText();
        if (!say.isEmpty()) {
            int w = f.width(say) + 10, bx = CX - w / 2, by = CY - 62;
            rect(g, bx - 1, by - 1, w + 2, 15, 0xFF3A2A3A);
            rect(g, bx, by, w, 13, 0xFFFFFFFF);
            rect(g, CX - 2, by + 13, 4, 1, 0xFFFFFFFF);
            rect(g, CX - 1, by + 14, 2, 2, 0xFF3A2A3A);
            g.drawString(f, say, bx + 5, by + 3, DARK, false);
        }

        // buttons
        rect(g, 0, BTN_Y - 4, W, H - BTN_Y + 4, mix(body, 0x000000, 0.35f));
        String[] labels = {t("cutemod.pet.feed"), t("cutemod.pet.play"), t(sleeping ? "cutemod.pet.wake" : "cutemod.pet.sleep")};
        for (int i = 0; i < 3; i++) {
            boolean hover = in(mx, my, BTN_X[i], BTN_Y, BTN_W, BTN_H);
            rect(g, BTN_X[i], BTN_Y, BTN_W, BTN_H, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
            rect(g, BTN_X[i], BTN_Y + BTN_H - 2, BTN_W, 2, 0xFFB9A8C8);
            g.drawString(f, labels[i], BTN_X[i] + (BTN_W - f.width(labels[i])) / 2, BTN_Y + 4, DARK, false);
        }
    }

    private String bubbleText() {
        if (msgTimer > 0) return msg;
        if (sleeping) return "";
        if (food < 25) return t("cutemod.pet.say.hungry");
        if (energy < 25) return t("cutemod.pet.say.sleepy");
        if (fun < 25) return t("cutemod.pet.say.bored");
        if (mood() == 2 && (ticks / 300) % 2 == 0) return t("cutemod.pet.say.happy");
        return "";
    }

    private void stat(GuiGraphics g, int y, String key, double value) {
        String s = t(key);
        g.drawString(font(), s, 226 - font().width(s), y, 0xFFFFFFFF, true);
        rect(g, 230, y, 62, 8, 0x99000000);
        int col = value > 50 ? 0xFF5BBF6A : value > 25 ? 0xFFF5C518 : 0xFFE5484D;
        rect(g, 231, y + 1, (int) (60 * value / 100), 6, col);
    }

    // ---------- pet sprites ----------
    private static void tri(GuiGraphics g, int x, int y, int w, int h, int argb) {
        for (int r = 0; r < h; r++) {
            int ww = Math.max(1, w * (r + 1) / h);
            rect(g, x + (w - ww) / 2, y + r, ww, 1, argb);
        }
    }

    private void drawPet(GuiGraphics g, int cx, int cy, int mood) {
        int e1 = cx - 11, e2 = cx + 7, ey = cy - 6, ew = 4, eh = 5, mY = cy + 8;
        int eyeCol = DARK, mouthCol = DARK;
        int top = cy - 22; // top of the head (for hats)
        boolean mouth = true, pupil = false;

        switch (shell.color()) {
            case PINK -> {
                int c = 0xFFF58FB8;
                tri(g, cx - 23, cy - 33, 13, 13, c);
                tri(g, cx + 10, cy - 33, 13, 13, c);
                tri(g, cx - 20, cy - 29, 7, 8, 0xFFFFC0D6);
                tri(g, cx + 13, cy - 29, 7, 8, 0xFFFFC0D6);
                disc(g, cx, cy, 22, c);
                disc(g, cx, cy + 9, 12, 0xFFFFD3E3);
                rect(g, cx - 1, cy + 2, 3, 2, 0xFFE5486F);
                rect(g, cx - 31, cy + 3, 10, 1, DARK);
                rect(g, cx - 30, cy + 7, 9, 1, DARK);
                rect(g, cx + 21, cy + 3, 10, 1, DARK);
                rect(g, cx + 21, cy + 7, 9, 1, DARK);
            }
            case GREEN -> {
                int c = 0xFF5BBF6A, d = 0xFF1B3A1B;
                rect(g, cx - 19, cy - 22, 38, 44, c);
                rect(g, cx - 17, cy - 20, 8, 8, 0xFF4AA85A);
                rect(g, cx + 8, cy - 8, 9, 9, 0xFF4AA85A);
                rect(g, cx - 14, cy + 10, 10, 9, 0xFF4AA85A);
                e1 = cx - 13; e2 = cx + 5; ey = cy - 14; ew = 8; eh = 8; eyeCol = d;
                mouth = false;
                rect(g, cx - 4, cy - 2, 8, 6, d);
                rect(g, cx - 8, cy + 4, 16, 10, d);
                rect(g, cx - 4, cy + 10, 8, 4, c);
            }
            case WHITE -> {
                disc(g, cx - 17, cy - 19, 7, 0xFF2A2A2F);
                disc(g, cx + 17, cy - 19, 7, 0xFF2A2A2F);
                disc(g, cx, cy, 22, 0xFFFFFFFF);
                disc(g, cx - 20, cy + 14, 6, 0xFF2A2A2F);
                disc(g, cx + 20, cy + 14, 6, 0xFF2A2A2F);
                disc(g, e1 + 2, ey + 2, 6, 0xFF2A2A2F);
                disc(g, e2 + 2, ey + 2, 6, 0xFF2A2A2F);
                rect(g, cx - 3, cy + 2, 6, 3, 0xFF2A2A2F);
                eyeCol = 0xFFFFFFFF; pupil = true; mY = cy + 10;
            }
            case BLUE -> {
                rect(g, cx - 27, cy - 2, 5, 16, 0xFF263B73);
                rect(g, cx + 22, cy - 2, 5, 16, 0xFF263B73);
                disc(g, cx, cy, 22, 0xFF2F4A8A);
                disc(g, cx, cy + 7, 15, 0xFFFFFFFF);
                rect(g, cx - 14, cy + 21, 10, 4, 0xFFF5A623);
                rect(g, cx + 4, cy + 21, 10, 4, 0xFFF5A623);
                rect(g, cx - 3, cy - 1, 6, 4, 0xFFF5A623);
                ey = cy - 12; eyeCol = 0xFFFFFFFF; pupil = true; mouth = false;
            }
            case ORANGE -> {
                int c = 0xFFF08A24;
                disc(g, cx + 25, cy + 12, 8, c);
                disc(g, cx + 29, cy + 17, 4, 0xFFFFFFFF);
                tri(g, cx - 23, cy - 33, 13, 14, c);
                tri(g, cx + 10, cy - 33, 13, 14, c);
                tri(g, cx - 20, cy - 33, 7, 6, DARK);
                tri(g, cx + 13, cy - 33, 7, 6, DARK);
                disc(g, cx, cy, 22, c);
                disc(g, cx - 12, cy + 9, 9, 0xFFFFF3E0);
                disc(g, cx + 12, cy + 9, 9, 0xFFFFF3E0);
                rect(g, cx - 2, cy + 3, 4, 3, DARK);
                mY = cy + 10;
            }
            case PURPLE -> {
                for (int i = 0; i < 6; i++) { // floating particles
                    if ((ticks / 7 + i) % 2 != 0) continue;
                    rect(g, cx + ((i * 37 + ticks / 5 * 7) % 64) - 32, cy - 30 + ((i * 53 + ticks / 4 * 3) % 64), 2, 2, 0xFFB040FF);
                }
                disc(g, cx, cy, 22, 0xFF1A1426);
                e1 = cx - 13; e2 = cx + 5; ey = cy - 6; ew = 8; eh = 3; eyeCol = 0xFFE040FF;
                mouthCol = 0xFFB040FF;
            }
            case YELLOW -> {
                int flap = (ticks / 4) % 2;
                disc(g, cx - 14, cy - 26 + flap * 2, 8, 0xFFDDF4FF);
                disc(g, cx + 14, cy - 26 + flap * 2, 8, 0xFFDDF4FF);
                rect(g, cx - 8, cy - 34, 1, 11, DARK);
                rect(g, cx + 7, cy - 34, 1, 11, DARK);
                disc(g, cx - 8, cy - 34, 2, DARK);
                disc(g, cx + 7, cy - 34, 2, DARK);
                disc(g, cx, cy, 22, 0xFFF5C518);
                for (int dy : new int[]{12, 13, 14, 18, 19, 20}) {
                    int w = (int) Math.sqrt(22 * 22 - dy * dy);
                    rect(g, cx - w, cy + dy, w * 2, 1, 0xFF2A2A2A);
                }
                mY = cy + 6;
            }
            default -> { // RED: ladybug
                disc(g, cx, cy + 4, 21, 0xFFE5484D);
                rect(g, cx, cy - 6, 1, 30, DARK);
                disc(g, cx - 10, cy + 8, 3, DARK);
                disc(g, cx + 10, cy + 8, 3, DARK);
                disc(g, cx - 6, cy + 17, 3, DARK);
                disc(g, cx + 6, cy + 17, 3, DARK);
                disc(g, cx, cy - 16, 11, 0xFF2A2A2F);
                rect(g, cx - 7, cy - 32, 1, 8, DARK);
                rect(g, cx + 6, cy - 32, 1, 8, DARK);
                e1 = cx - 8; e2 = cx + 4; ey = cy - 20; eyeCol = 0xFFFFFFFF; pupil = true;
                mY = cy - 10; mouthCol = 0xFFFFFFFF; top = cy - 27;
            }
        }

        // eyes
        boolean closed = sleeping || (ticks % 200) < 8;
        if (closed) {
            rect(g, e1, ey + eh / 2, ew, 1, eyeCol == DARK ? DARK : (eyeCol == 0xFFFFFFFF ? 0xFFFFFFFF : eyeCol));
            rect(g, e2, ey + eh / 2, ew, 1, eyeCol == DARK ? DARK : (eyeCol == 0xFFFFFFFF ? 0xFFFFFFFF : eyeCol));
        } else {
            rect(g, e1, ey, ew, eh, eyeCol);
            rect(g, e2, ey, ew, eh, eyeCol);
            if (pupil) {
                rect(g, e1 + 1, ey + 2, 2, 3, DARK);
                rect(g, e2 + 1, ey + 2, 2, 3, DARK);
            } else {
                rect(g, e1 + 1, ey + 1, 1, 1, 0xFFFFFFFF);
                rect(g, e2 + 1, ey + 1, 1, 1, 0xFFFFFFFF);
            }
            if (mood == 0) { // a tear
                rect(g, e2 + ew - 1, ey + eh + (ticks / 8) % 6, 1, 2, 0xFF6AB8FF);
            }
        }

        accessory(g, cx, top, e1, e2, ey, ew, eh);

        // mouth
        if (mouth) {
            int mx0 = cx - 1;
            if (sleeping) {
                rect(g, mx0 - 1, mY, 3, 1, mouthCol);
            } else if (mood == 2) {
                rect(g, mx0 - 4, mY, 9, 1, mouthCol);
                rect(g, mx0 - 5, mY - 1, 1, 1, mouthCol);
                rect(g, mx0 + 5, mY - 1, 1, 1, mouthCol);
            } else if (mood == 1) {
                rect(g, mx0 - 3, mY, 7, 1, mouthCol);
            } else {
                rect(g, mx0 - 3, mY, 7, 1, mouthCol);
                rect(g, mx0 - 4, mY + 1, 1, 1, mouthCol);
                rect(g, mx0 + 4, mY + 1, 1, 1, mouthCol);
            }
        }
    }

    /** Things bought in the shop. */
    private void accessory(GuiGraphics g, int cx, int top, int e1, int e2, int ey, int ew, int eh) {
        switch (Progress.equipped()) {
            case "acc_glasses" -> {
                int k = 0xFF111111;
                rect(g, e1 - 2, ey - 1, ew + 4, eh + 2, k);
                rect(g, e2 - 2, ey - 1, ew + 4, eh + 2, k);
                rect(g, e1 + ew + 2, ey, Math.max(1, e2 - e1 - ew - 4), 1, k);
                rect(g, e1 - 1, ey, 2, 1, 0x88FFFFFF);
                rect(g, e2 - 1, ey, 2, 1, 0x88FFFFFF);
            }
            case "acc_bow" -> {
                disc(g, cx + 11, top + 6, 3, 0xFFFF5C93);
                disc(g, cx + 21, top + 6, 3, 0xFFFF5C93);
                rect(g, cx + 15, top + 4, 3, 5, 0xFFD93A72);
            }
            case "acc_hat" -> {
                int k = 0xFF1A1A22;
                rect(g, cx - 9, top - 13, 18, 13, k);
                rect(g, cx - 14, top - 1, 28, 3, k);
                rect(g, cx - 9, top - 5, 18, 2, 0xFFE5484D);
            }
            case "acc_crown" -> {
                int gold = 0xFFFFD84A;
                rect(g, cx - 10, top - 5, 20, 5, gold);
                tri(g, cx - 10, top - 11, 6, 6, gold);
                tri(g, cx - 3, top - 14, 7, 9, gold);
                tri(g, cx + 4, top - 11, 6, 6, gold);
                rect(g, cx - 1, top - 3, 3, 2, 0xFFE5484D);
                rect(g, cx - 8, top - 3, 2, 2, 0xFF2F9BFF);
                rect(g, cx + 6, top - 3, 2, 2, 0xFF2F9BFF);
            }
            default -> { }
        }
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < 3; i++) {
            if (in(x, y, BTN_X[i], BTN_Y, BTN_W, BTN_H)) {
                switch (i) {
                    case 0 -> feed();
                    case 1 -> play();
                    default -> toggleSleep();
                }
                return true;
            }
        }
        if (in(x, y, CX - 30, CY - 36, 60, 62)) { pet(); return true; }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        switch (keyCode) {
            case 49 -> feed();          // 1
            case 50 -> play();          // 2
            case 51 -> toggleSleep();   // 3
            default -> { return false; }
        }
        return true;
    }
}
