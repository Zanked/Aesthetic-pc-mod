package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** The shop: spend the coins you earned on wallpapers, pet accessories and songs. */
public class ShopApp extends App {
    private record Item(String id, int price) {}

    private static final Item[] ITEMS = {
            new Item("wall6", 40), new Item("wall7", 40), new Item("wall8", 60),
            new Item("acc_glasses", 30), new Item("acc_bow", 30), new Item("acc_hat", 50),
            new Item("acc_crown", 0), // a reward for finishing the story, not for sale
            new Item("track4", 40), new Item("track5", 60),
    };
    private static final int TOP = 20, ROW = 24, VISIBLE = 6, BTN_W = 78;

    private int scroll;

    @Override
    public Component title() { return Component.translatable("cutemod.os.shop"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.shop"); }

    private static String kind(String id) { return id.startsWith("wall") ? "wall" : id.startsWith("acc") ? "acc" : "track"; }

    private int maxScroll() { return Math.max(0, ITEMS.length - VISIBLE); }

    /** Text of the button for this item, or null if there is nothing to press. */
    private String action(Item it) {
        boolean own = Progress.owned(it.id());
        switch (kind(it.id())) {
            case "wall" -> {
                if (!own) return "buy";
                return Wallpaper.get() == Integer.parseInt(it.id().substring(4)) ? "using" : "set";
            }
            case "acc" -> {
                if (!own) return it.price() == 0 ? "story" : "buy";
                return Progress.equipped().equals(it.id()) ? "take_off" : "wear";
            }
            default -> { return own ? "have" : "buy"; }
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, 0xFFFFF6D8);
        rect(g, 0, 0, W, 17, 0xFFF5C518);
        g.drawString(f, t("cutemod.os.shop"), 6, 5, 0xFF3A2A3A, false);
        String bal = Integer.toString(Progress.coins());
        g.drawString(f, bal, W - 6 - f.width(bal), 5, 0xFF3A2A3A, false);
        Progress.drawCoin(g, W - 16 - f.width(bal), 5);

        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= ITEMS.length) break;
            Item it = ITEMS[idx];
            int y = TOP + v * ROW;
            rect(g, 0, y, W, ROW - 1, v % 2 == 0 ? 0xFFFFFFFF : 0xFFFFF0C0);
            icon(g, it.id(), 6, y + 2);
            g.drawString(f, t("cutemod.shop.item." + it.id()), 32, y + 4, 0xFF3A2A3A, false);
            g.drawString(f, t("cutemod.shop.kind." + kind(it.id())), 32, y + 14, 0xFF8A7AA8, false);
            if (it.price() > 0 && !Progress.owned(it.id())) {
                String p = Integer.toString(it.price());
                int px = W - BTN_W - 14 - f.width(p);
                Progress.drawCoin(g, px - 10, y + 8);
                g.drawString(f, p, px, y + 8, Progress.coins() >= it.price() ? 0xFF3A2A3A : 0xFFE5484D, false);
            }
            String a = action(it);
            boolean can = !(a.equals("using") || a.equals("have") || a.equals("story") || (a.equals("buy") && Progress.coins() < it.price()));
            boolean hover = can && in(mx, my, W - BTN_W - 6, y + 3, BTN_W, 17);
            rect(g, W - BTN_W - 6, y + 3, BTN_W, 17, !can ? 0xFFD8CCE2 : hover ? 0xFF8A6AC6 : 0xFFB57BD6);
            String label = t("cutemod.shop.btn." + a);
            g.drawString(f, label, W - BTN_W - 6 + (BTN_W - f.width(label)) / 2, y + 8, can ? 0xFFFFFFFF : 0xFF8A7AA8, false);
        }

        if (maxScroll() > 0) { // scroll bar
            rect(g, W - 3, TOP, 3, VISIBLE * ROW, 0xFFE9DDF2);
            int th = VISIBLE * ROW * VISIBLE / ITEMS.length;
            rect(g, W - 3, TOP + (VISIBLE * ROW - th) * scroll / maxScroll(), 3, th, 0xFFB57BD6);
        }
    }

    /** A little picture (20 x 20) of the item. */
    private void icon(GuiGraphics g, String id, int x, int y) {
        rect(g, x - 1, y - 1, 22, 22, 0xFF3A2A4A);
        switch (kind(id)) {
            case "wall" -> Wallpaper.draw(g, x, y, 20, 20, shell.color().bodyColor, Integer.parseInt(id.substring(4)));
            case "track" -> {
                rect(g, x, y, 20, 20, 0xFF6A4A9A);
                disc(g, x + 7, y + 14, 3, 0xFFFFFFFF);
                rect(g, x + 9, y + 4, 2, 11, 0xFFFFFFFF);
                rect(g, x + 9, y + 4, 6, 2, 0xFFFFFFFF);
            }
            default -> {
                rect(g, x, y, 20, 20, 0xFFFFF0C0);
                switch (id) {
                    case "acc_glasses" -> {
                        rect(g, x + 2, y + 7, 7, 5, 0xFF111111);
                        rect(g, x + 11, y + 7, 7, 5, 0xFF111111);
                        rect(g, x + 9, y + 8, 2, 1, 0xFF111111);
                    }
                    case "acc_bow" -> {
                        disc(g, x + 5, y + 10, 3, 0xFFFF5C93);
                        disc(g, x + 15, y + 10, 3, 0xFFFF5C93);
                        rect(g, x + 8, y + 8, 4, 5, 0xFFD93A72);
                    }
                    case "acc_hat" -> {
                        rect(g, x + 5, y + 3, 10, 10, 0xFF1A1A22);
                        rect(g, x + 2, y + 13, 16, 3, 0xFF1A1A22);
                        rect(g, x + 5, y + 10, 10, 2, 0xFFE5484D);
                    }
                    default -> { // crown
                        rect(g, x + 3, y + 11, 14, 5, 0xFFFFD84A);
                        for (int r = 0; r < 6; r++) {
                            rect(g, x + 3 + r / 3, y + 5 + r, Math.max(1, 3 - r / 3), 1, 0xFFFFD84A);
                            rect(g, x + 9, y + 3 + r, 2, 1, 0xFFFFD84A);
                            rect(g, x + 14 - r / 3, y + 5 + r, Math.max(1, 3 - r / 3), 1, 0xFFFFD84A);
                        }
                        rect(g, x + 9, y + 12, 2, 2, 0xFFE5484D);
                    }
                }
            }
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= ITEMS.length) break;
            Item it = ITEMS[idx];
            int ry = TOP + v * ROW;
            if (!in(x, y, W - BTN_W - 6, ry + 3, BTN_W, 17)) continue;
            switch (action(it)) {
                case "buy" -> {
                    if (Progress.buy(it.id(), it.price())) {
                        if (kind(it.id()).equals("wall")) Wallpaper.set(Integer.parseInt(it.id().substring(4)));
                        else if (kind(it.id()).equals("acc")) Progress.equip(it.id());
                    }
                }
                case "set" -> Wallpaper.set(Integer.parseInt(it.id().substring(4)));
                case "wear" -> Progress.equip(it.id());
                case "take_off" -> Progress.equip("");
                default -> { }
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll + (amount < 0 ? 1 : -1)));
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (keyCode == 264) { scroll = Math.min(maxScroll(), scroll + 1); return true; } // down
        if (keyCode == 265) { scroll = Math.max(0, scroll - 1); return true; }           // up
        return false;
    }
}
