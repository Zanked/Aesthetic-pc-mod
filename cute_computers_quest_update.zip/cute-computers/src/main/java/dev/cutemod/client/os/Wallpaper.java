package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.nio.file.Files;
import java.nio.file.Path;

/** Desktop wallpapers. The chosen one is remembered in cutemod_wallpaper.txt. */
public final class Wallpaper {
    public static final int COUNT = 9; // 0-5 are free (Settings), 6-8 come from the shop
    public static final int BASE = 6;
    private static int index = load();

    private Wallpaper() {}

    public static int get() { return index; }

    public static void set(int i) {
        index = Math.floorMod(i, COUNT);
        try {
            Files.writeString(file(), Integer.toString(index));
        } catch (Exception ignored) {
        }
    }

    private static Path file() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("cutemod_wallpaper.txt");
    }

    private static int load() {
        try {
            Path p = file();
            if (Files.exists(p)) return Math.floorMod(Integer.parseInt(Files.readString(p).trim()), COUNT);
        } catch (Exception ignored) {
        }
        return 0;
    }

    private static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** Draws wallpaper number idx inside the box x,y,w,h (everything stays inside the box). */
    public static void draw(GuiGraphics g, int x, int y, int w, int h, int body, int idx) {
        switch (idx) {
            case 1 -> { // sky
                g.fillGradient(x, y, x + w, y + h, 0xFF9ED8FF, 0xFFEAF7FF);
                for (int i = 0; i < 3; i++) {
                    int cx = x + (i * 97 + 20) % Math.max(1, w - 40), cy = y + 6 + i * (h / 4);
                    g.fill(cx, cy + 3, cx + 30, cy + 11, 0xCCFFFFFF);
                    g.fill(cx + 6, cy, cx + 22, cy + 5, 0xCCFFFFFF);
                }
            }
            case 2 -> { // mint
                g.fillGradient(x, y, x + w, y + h, 0xFFD6F5DE, 0xFF8FD39A);
                for (int i = 0; i < 14; i++) {
                    int dx = x + (i * 61 + 17) % Math.max(1, w - 3), dy = y + (i * 37 + 9) % Math.max(1, h - 3);
                    g.fill(dx, dy, dx + 3, dy + 3, 0x66FFFFFF);
                }
            }
            case 3 -> { // sunset
                g.fillGradient(x, y, x + w, y + h, 0xFFFFC38A, 0xFFE5668A);
                disc(g, x + w * 3 / 4, y + h * 2 / 3, Math.min(w, h) / 6, 0xFFFFF0B0);
            }
            case 4 -> { // night
                g.fillGradient(x, y, x + w, y + h, 0xFF1B1840, 0xFF4A3A66);
                for (int i = 0; i < 24; i++) {
                    int sx = x + (i * 53 + 11) % Math.max(1, w - 2), sy = y + (i * 29 + 5) % Math.max(1, h - 2);
                    int s = i % 5 == 0 ? 2 : 1;
                    g.fill(sx, sy, sx + s, sy + s, 0xCCFFFFFF);
                }
                disc(g, x + w / 5, y + h / 4, Math.min(w, h) / 9, 0xFFFFF0C0);
            }
            case 5 -> { // candy stripes
                for (int r = 0; r * 8 < h; r++) {
                    g.fill(x, y + r * 8, x + w, Math.min(y + h, y + r * 8 + 8), r % 2 == 0 ? 0xFFFFD6E8 : 0xFFFFFFFF);
                }
            }
            case 6 -> { // starry space
                g.fillGradient(x, y, x + w, y + h, 0xFF0B0F2E, 0xFF2A2A6A);
                for (int i = 0; i < 30; i++) {
                    int sx = x + (i * 47 + 13) % Math.max(1, w - 2), sy = y + (i * 31 + 7) % Math.max(1, h - 2);
                    g.fill(sx, sy, sx + (i % 7 == 0 ? 2 : 1), sy + (i % 7 == 0 ? 2 : 1), 0xFFFFFFFF);
                }
                for (int k = 0; k < Math.min(w, h) / 3; k++) g.fill(x + w * 3 / 4 - k, y + h / 5 + k / 2, x + w * 3 / 4 - k + 1, y + h / 5 + k / 2 + 1, 0xAAFFFFFF);
            }
            case 7 -> { // hearts
                g.fillGradient(x, y, x + w, y + h, 0xFFFFE0EC, 0xFFFFB3CF);
                for (int i = 0; i < 18; i++) {
                    int hx = x + (i * 53 + 9) % Math.max(1, w - 8), hy = y + (i * 29 + 4) % Math.max(1, h - 8);
                    int c = i % 2 == 0 ? 0xAAFF5C93 : 0xAAFFFFFF;
                    g.fill(hx, hy + 1, hx + 5, hy + 3, c);
                    g.fill(hx + 1, hy, hx + 2, hy + 1, c);
                    g.fill(hx + 3, hy, hx + 4, hy + 1, c);
                    g.fill(hx + 1, hy + 3, hx + 4, hy + 4, c);
                    g.fill(hx + 2, hy + 4, hx + 3, hy + 5, c);
                }
            }
            case 8 -> { // honeycomb
                g.fillGradient(x, y, x + w, y + h, 0xFFFFE9A0, 0xFFFFC832);
                for (int r = 0; r * 7 < h; r++) {
                    for (int c = 0; c * 12 < w; c++) {
                        int hx = x + c * 12 + (r % 2) * 6, hy = y + r * 7;
                        if (hx + 7 > x + w || hy + 5 > y + h) continue;
                        g.fill(hx + 1, hy, hx + 6, hy + 1, 0x66B98A10);
                        g.fill(hx, hy + 1, hx + 7, hy + 4, 0x33B98A10);
                        g.fill(hx + 1, hy + 4, hx + 6, hy + 5, 0x66B98A10);
                    }
                }
            }
            default -> { // the computer's own color
                g.fillGradient(x, y, x + w, y + h, App.mix(body, 0xFFFFFF, 0.6f), App.mix(body, 0x3A2A4A, 0.35f));
                for (int i = 0; i < 14; i++) {
                    int dx = x + (i * 61 + 17) % Math.max(1, w - 3), dy = y + (i * 37 + 9) % Math.max(1, h - 3);
                    g.fill(dx, dy, dx + 3, dy + 3, 0x30FFFFFF);
                }
            }
        }
    }
}
