package dev.cutemod.block;

import com.mojang.serialization.MapCodec;
import dev.cutemod.ComputerColor;
import dev.cutemod.client.ClientHooks;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The monitor. Its screen is dark until a desk is complete around it (see {@link PcLink}: a PC case that is switched on, a keyboard
 * and a mouse); then the screen lights up with the desktop and a right-click opens the OS of that case. It looks again every second,
 * so it goes dark by itself when the PC is switched off or a part of the desk is taken away.
 */
public class PcMonitorBlock extends Block {
    public static final MapCodec<PcMonitorBlock> CODEC = simpleCodec(PcMonitorBlock::new);
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final BooleanProperty ON = BooleanProperty.create("on");

    private static final VoxelShape[] SHAPES = new VoxelShape[4];
    static {
        for (int turn = 0; turn < 4; turn++) {
            SHAPES[turn] = Shapes.or(
                    ComputerBlock.rotated(3.0, 0, 6.7, 13.0, 0.6, 12.5, turn),           // the legs
                    ComputerBlock.rotated(7.3, 0.5, 7.0, 8.7, 3.6, 8.0, turn),           // the neck
                    ComputerBlock.rotated(0.5, 3.4, 6.4, 15.5, 13.2, 8.8, turn),         // the screen
                    ComputerBlock.rotated(3.5, 0, 12.2, 12.5, 0.7, 15.4, turn),          // the keyboard
                    ComputerBlock.rotated(13.2, 0, 12.6, 14.7, 0.7, 14.8, turn));        // the mouse
        }
    }

    public PcMonitorBlock(BlockBehaviour.Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.SOUTH).setValue(ON, false));
    }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) { builder.add(FACING, ON); }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite()).setValue(ON, false);
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rot) { return state.setValue(FACING, rot.rotate(state.getValue(FACING))); }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) { return state.rotate(mirror.getRotation(state.getValue(FACING))); }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPES[ComputerBlock.turnsOf(state.getValue(FACING))];
    }

    // ---------- the screen lights up by itself ----------
    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (!level.isClientSide && !oldState.is(state.getBlock())) level.scheduleTick(pos, this, 20);
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        refresh(level, pos, state);
        level.scheduleTick(pos, this, 20);
    }

    /** Server side: light the screen if a full desk is around it, darken it if not. */
    public static void refresh(Level level, BlockPos pos, BlockState state) {
        if (level.isClientSide || !(state.getBlock() instanceof PcMonitorBlock)) return;
        boolean ok = PcLink.find(level, pos).ok();
        if (state.getValue(ON) != ok) level.setBlock(pos, state.setValue(ON, ok), 3);
    }

    // ---------- use ----------
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        PcLink.Result link = PcLink.find(level, pos);
        if (level.isClientSide) {
            if (link.ok()) ClientHooks.openComputer(ComputerColor.WHITE, link.casePos());
            return InteractionResult.sidedSuccess(true);
        }
        refresh(level, pos, state);
        if (!link.ok() && player instanceof ServerPlayer sp) {
            String key = !link.caseExists() ? "cutemod.monitor.no_case"
                    : link.casePos() == null ? "cutemod.monitor.case_off"
                    : !link.keyboard() && !link.mouse() ? "cutemod.monitor.no_desk"
                    : !link.keyboard() ? "cutemod.monitor.no_keyboard" : "cutemod.monitor.no_mouse";
            sp.displayClientMessage(Component.translatable(key).withStyle(ChatFormatting.GOLD), true);
            level.playSound(null, pos, SoundEvents.VILLAGER_NO, SoundSource.BLOCKS, 0.5F, 1.4F);
        }
        return InteractionResult.sidedSuccess(false);
    }
}
