package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Billiards: ten coloured balls and a white one. Aim with the mouse (the line shows where the white ball goes), the farther the
 * mouse is from the white ball the harder the shot, click to shoot. Pot every ball before the shots run out.
 */
public class Billiards extends MiniGame {
    private static final int L = 10, R = 210, T = 10, B = 130, CX = 110, CY = 70;
    private static final float BR = 4f, PR = 7.5f;
    private static final int N = 11, SHOTS = 25, SUB = 4;
    private static final float FRICTION = 0.982f, STOP = 0.03f, MAX_PULL = 70f;
    private static final float[][] POCKETS = {{L, T}, {R, T}, {L, B}, {R, B}, {CX, T - 2}, {CX, B + 2}};
    private static final int[] COL = {0xFFFFFFFF, 0xFFF5D84A, 0xFF4A8FE0, 0xFFE0594F, 0xFF9B5FD0, 0xFFF58B25, 0xFF52B85A,
            0xFFA83A3A, 0xFF2A2A32, 0xFFF06AAE, 0xFF4FC9B8};

    private final float[] x = new float[N], y = new float[N], vx = new float[N], vy = new float[N];
    private final boolean[] alive = new boolean[N];
    private boolean moving, scratch, won;
    private int shots, potted, potShot, hitCool, wallCool, msg;
    private String note = "";

    @Override
    public void reset() {
        score = 0; over = false; won = false; shots = SHOTS; potted = 0; potShot = 0; moving = false; scratch = false; msg = 0;
        java.util.Arrays.fill(alive, true);
        java.util.Arrays.fill(vx, 0); java.util.Arrays.fill(vy, 0);
        x[0] = 60; y[0] = CY;
        float d = BR * 2 + 0.6f;
        int k = 1;
        for (int row = 0; row < 4; row++) {
            for (int j = 0; j <= row; j++) {
                x[k] = 150 + row * d * 0.866f;
                y[k] = CY + (j - row / 2f) * d;
                k++;
            }
        }
    }

    private float speedOf(int i) { return (float) Math.sqrt(vx[i] * vx[i] + vy[i] * vy[i]); }

    private float pull() {
        float dx = mx - x[0], dy = my - y[0];
        return Math.min(MAX_PULL, (float) Math.sqrt(dx * dx + dy * dy));
    }

    @Override
    public boolean click(int cx, int cy, int button) {
        if (over || moving) return true;
        float dx = cx - x[0], dy = cy - y[0], len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 6) return true;
        float power = Math.min(MAX_PULL, len) / MAX_PULL, speed = 1.2f + 5.3f * power;
        vx[0] = dx / len * speed; vy[0] = dy / len * speed;
        shots--; potShot = 0; scratch = false; moving = true; note = "";
        // the cue strikes the white ball: a hard tap and a glassy click, louder for a harder shot
        sound(net.minecraft.sounds.SoundEvents.STONE_BUTTON_CLICK_ON, 1.1F, 0.6F + 0.4F * power);
        sound(net.minecraft.sounds.SoundEvents.GLASS_HIT, 1.5F + 0.4F * power, 0.5F + 0.4F * power);
        return true;
    }

    private void step(float dt) {
        for (int i = 0; i < N; i++) {
            if (!alive[i]) continue;
            x[i] += vx[i] * dt; y[i] += vy[i] * dt;
        }
        // pockets first, so a ball near a corner drops in instead of bouncing away
        for (int i = 0; i < N; i++) {
            if (!alive[i]) continue;
            for (float[] p : POCKETS) {
                float dx = x[i] - p[0], dy = y[i] - p[1];
                if (dx * dx + dy * dy < PR * PR) {
                    alive[i] = false; vx[i] = 0; vy[i] = 0;
                    sound(net.minecraft.sounds.SoundEvents.STONE_STEP, 0.55F, 0.8F);                       // the ball drops into the leather pocket
                    sound(net.minecraft.sounds.SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 0.8F, 0.5F);
                    if (i == 0) { scratch = true; sound(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_BASS.value(), 0.6F, 0.7F); }
                    else { potted++; potShot++; score += 10; pling(0.9F + Math.min(potShot, 4) * 0.2F); }
                    break;
                }
            }
        }
        for (int i = 0; i < N; i++) {
            if (!alive[i]) continue;
            boolean bump = false;
            if (x[i] < L + BR) { x[i] = L + BR; if (vx[i] < -0.8f) bump = true; vx[i] = Math.abs(vx[i]) * 0.92f; }
            if (x[i] > R - BR) { x[i] = R - BR; if (vx[i] > 0.8f) bump = true; vx[i] = -Math.abs(vx[i]) * 0.92f; }
            if (y[i] < T + BR) { y[i] = T + BR; if (vy[i] < -0.8f) bump = true; vy[i] = Math.abs(vy[i]) * 0.92f; }
            if (y[i] > B - BR) { y[i] = B - BR; if (vy[i] > 0.8f) bump = true; vy[i] = -Math.abs(vy[i]) * 0.92f; }
            if (bump && wallCool <= 0) { sound(net.minecraft.sounds.SoundEvents.WOODEN_DOOR_CLOSE, 1.9F, 0.22F); wallCool = 5; }   // a dull knock on the cushion
        }
        for (int i = 0; i < N; i++) {
            if (!alive[i]) continue;
            for (int j = i + 1; j < N; j++) {
                if (!alive[j]) continue;
                float dx = x[j] - x[i], dy = y[j] - y[i], d2 = dx * dx + dy * dy, min = BR * 2;
                if (d2 >= min * min || d2 < 0.0001f) continue;
                float d = (float) Math.sqrt(d2), nx = dx / d, ny = dy / d, push = (min - d) / 2;
                x[i] -= nx * push; y[i] -= ny * push; x[j] += nx * push; y[j] += ny * push;
                float rel = (vx[i] - vx[j]) * nx + (vy[i] - vy[j]) * ny;
                if (rel > 0) {
                    vx[i] -= rel * nx; vy[i] -= rel * ny; vx[j] += rel * nx; vy[j] += rel * ny;
                    if (rel > 0.5f && hitCool <= 0) {                                   // balls click together: louder and higher for a hard hit
                        float v = Math.min(1f, rel / 5f);
                        sound(net.minecraft.sounds.SoundEvents.GLASS_HIT, 1.35F + v * 0.5F + rnd.nextFloat() * 0.1F, 0.25F + 0.6F * v);
                        hitCool = 3;
                    }
                }
            }
        }
    }

    @Override
    public void tick() {
        if (hitCool > 0) hitCool--;
        if (wallCool > 0) wallCool--;
        if (msg > 0) msg--;
        if (!moving) return;
        for (int s = 0; s < SUB; s++) step(1f / SUB);
        boolean any = false;
        for (int i = 0; i < N; i++) {
            if (!alive[i]) continue;
            vx[i] *= FRICTION; vy[i] *= FRICTION;
            if (speedOf(i) < STOP) { vx[i] = 0; vy[i] = 0; } else any = true;
        }
        if (!any) settle();
    }

    private void settle() {
        moving = false;
        if (potShot >= 2) { score += 5 * (potShot - 1); note = Component.translatable("cutemod.billiards.combo", potShot).getString(); msg = 90; }
        if (scratch) {                                                      // the white ball dropped: it comes back, and it costs points
            score = Math.max(0, score - 5);
            note = Component.translatable("cutemod.billiards.scratch").getString(); msg = 90;
            alive[0] = true; vx[0] = 0; vy[0] = 0; y[0] = CY;
            for (float px = 60; px >= L + BR; px -= 3) {
                x[0] = px;
                boolean free = true;
                for (int i = 1; i < N; i++) if (alive[i] && Math.abs(x[i] - px) < BR * 2 + 1 && Math.abs(y[i] - CY) < BR * 2 + 1) free = false;
                if (free) break;
            }
        }
        if (potted >= N - 1) {
            won = true; over = true; score += 30 + 5 * shots;
            sound(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, 1.0F, 0.7F);                                  // the table is clear
        }
        else if (shots <= 0) over = true;
    }

    // ---------- drawing ----------
    private static void dot(GuiGraphics g, int px, int py, int c) { rect(g, px, py, 1, 1, c); }

    @Override
    public void render(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0xFF6B4020);                                    // the wooden frame
        rect(g, 2, 2, W - 4, H - 4, 0xFF8A5530);
        rect(g, L - 3, T - 3, R - L + 6, B - T + 6, 0xFF1F6A40);            // cushions
        rect(g, L, T, R - L, B - T, 0xFF2E8B57);                            // the cloth
        rect(g, L, T, R - L, 2, 0x22FFFFFF);
        rect(g, 60, T + 4, 1, B - T - 8, 0x14FFFFFF);                       // the head string
        for (float[] p : POCKETS) disc(g, Math.round(p[0]), Math.round(p[1]), 7, 0xFF14110F);
        for (int i = N - 1; i >= 0; i--) {
            if (!alive[i]) continue;
            int px = Math.round(x[i]), py = Math.round(y[i]);
            disc(g, px + 1, py + 1, 4, 0x55000000);
            disc(g, px, py, 4, COL[i]);
            rect(g, px - 2, py - 2, 2, 1, 0x99FFFFFF);
        }
        if (!moving && !over && alive[0]) aim(g);
        // the shots and the power
        rect(g, 12, H - 8, 62, 4, 0x66000000);
        if (!moving && !over) {
            float p = pull() / MAX_PULL;
            rect(g, 12, H - 8, Math.round(62 * p), 4, p > 0.8f ? 0xFFE5486F : 0xFFFFD866);
        }
        for (int i = 0; i < Math.min(shots, 25); i++) rect(g, 82 + i * 5, H - 8, 3, 4, 0xFFF4F0E8);
        if (msg > 0) ctext(g, note, W / 2, T + 5, 0xFFFFD866);
    }

    private void aim(GuiGraphics g) {
        float dx = mx - x[0], dy = my - y[0], len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 6) return;
        dx /= len; dy /= len;
        float p = pull() / MAX_PULL;
        // a dotted line to the first ball or cushion it meets
        float px = x[0], py = y[0];
        for (int s = 0; s < 120; s++) {
            px += dx * 2; py += dy * 2;
            boolean stop = px < L + BR || px > R - BR || py < T + BR || py > B - BR;
            for (int i = 1; i < N && !stop; i++) {
                if (alive[i] && (px - x[i]) * (px - x[i]) + (py - y[i]) * (py - y[i]) < BR * BR * 4) stop = true;
            }
            if (stop) { disc(g, Math.round(px), Math.round(py), 3, 0x66FFFFFF); break; }
            if (s % 2 == 0 && s > 3) dot(g, Math.round(px), Math.round(py), 0xCCFFFFFF);
        }
        // the cue behind the white ball, pulled back with the power
        float back = 6 + p * 14;
        for (int k = 0; k < 46; k++) {
            int c = k < 3 ? 0xFF5BA8F0 : (k > 36 ? 0xFF3A2A1A : 0xFFE8C890);
            rect(g, Math.round(x[0] - dx * (back + k)), Math.round(y[0] - dy * (back + k)), 2, 2, c);
        }
    }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() { return Component.translatable(won ? "cutemod.billiards.win" : "cutemod.ui.gameover"); }

    @Override
    public Component status() { return Component.translatable("cutemod.billiards.status", score, Math.max(0, shots)); }

    @Override
    public String hintKey() { return "cutemod.hint.billiards"; }
}
