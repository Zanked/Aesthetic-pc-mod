package dev.cutemod.client.os;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;

/**
 * The crimson look of the video 666 ("CuteTube 666" style): for two minutes after the video is watched to the end the
 * whole desktop turns blood red: icons, the Dock, the menu bar, window title bars, the Start menu, the widgets, the
 * notifications, the cursor and the sounds. Then everything goes back by itself, the saved look is never touched.
 * Drawn from the real clock, like {@link HellWallpaper}.
 */
public final class Hell {
    public static final int SECONDS = 120;

    // the colours of the haunted site (see BrowserApp): near black, dried blood, crimson, a pale pink text
    public static final int BLACK = 0xFF0D0204, DARK = 0xFF220306, MAROON = 0xFF3A0508, BLOOD = 0xFF7A0C14, CRIMSON = 0xFFA01018,
            RED = 0xFFD9302A, PALE = 0xFFEBCFC8;

    private static long until;

    private Hell() {}

    /** Start (or restart) the crimson look for this many seconds. */
    public static void start(int seconds) { until = System.currentTimeMillis() + seconds * 1000L; }

    /** Switch it off right now. */
    public static void stop() { until = 0; pending = false; }

    /** True while the temporary look (after the video 666) runs. */
    public static boolean timed() { return System.currentTimeMillis() < until; }

    /** True when the crimson look is on: for two minutes after the video 666, or all the time when the bought theme "Blood" is on. */
    public static boolean active() { return timed() || Theme.bloodTheme(); }

    private static boolean pending;

    /** The video 666 was watched: the look starts, and if the computer stays open until it ends, the player has "survived" it. */
    public static void startAward(int seconds) { start(seconds); pending = true; }

    /** Every tick of the computer screen: the two minutes are over and the computer was never closed in between. */
    public static void tick() {
        if (pending && !timed()) {
            pending = false;
            Progress.bump("hell_survive");                       // the achievement (coins) and a letter from the number
            Sfx.ui(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_CHIME.value(), 0.6F, 0.8F);
        }
    }

    /** The player left the computer: the survival does not count any more. */
    public static void screenClosed() { pending = false; }

    /** Seconds that are left (0 when it is off). */
    public static int secondsLeft() { return (int) Math.max(0, (until - System.currentTimeMillis() + 999) / 1000); }

    /** 0..1: the heartbeat of the desktop (a beat every ~1.1 s, two thumps). */
    public static float pulse() {
        double t = (System.currentTimeMillis() % 1100) / 1100.0;
        double a = Math.exp(-Math.pow((t - 0.05) / 0.06, 2)), b = 0.6 * Math.exp(-Math.pow((t - 0.28) / 0.06, 2));
        return (float) Math.min(1.0, a + b);
    }

    private static int hash(int n) {
        n ^= n >>> 15; n *= 0x2C1B3C6D; n ^= n >>> 12; n *= 0x297A2D39; n ^= n >>> 15;
        return n & 0x7FFFFFFF;
    }

    // ---------- icons ----------

    /** Draws one icon in crimson: everything the icon paints is multiplied by a blood colour, then a few drips run down it. */
    public static void icon(GuiGraphics g, Runnable draw, int ox, int oy, int seed) {
        g.flush();
        float k = 0.80f + 0.14f * pulse();
        RenderSystem.setShaderColor(k, 0.13f, 0.19f, 1f);
        try {
            draw.run();
            g.flush();
        } finally {
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        }
        long t = System.currentTimeMillis();
        int drips = 2 + hash(seed * 31 + 7) % 2;
        for (int d = 0; d < drips; d++) {
            int h = hash(seed * 131 + d * 17 + 3);
            int x = 5 + h % 22;
            int len = 3 + (h >> 8) % 7 + (int) Math.round(2 * Math.sin(t / 650.0 + d * 2 + seed));
            int top = 3 + (h >> 4) % 3;
            x += ox; top += oy;
            g.fill(x, top, x + 2, top + len, 0xFF8A0A14);
            g.fill(x, top + len, x + 2, top + len + 1, 0xFFC01828);      // the drop at the end
            g.fill(x, top, x + 1, top + len, 0xFFB01424);                // a wet highlight
        }
    }

    // ---------- colour helpers for the parts of the shell that draw their own colours ----------

    /** Any colour turned to a shade of blood (the alpha stays). */
    public static int tint(int argb) {
        int r = (argb >> 16) & 255, gr = (argb >> 8) & 255, b = argb & 255;
        float l = (r * 0.3f + gr * 0.59f + b * 0.11f) / 255f;
        int nr = Math.min(255, Math.round(40 + l * 215)), ng = Math.round(l * 0.16f * 255), nb = Math.round(l * 0.2f * 255);
        return (argb & 0xFF000000) | (nr << 16) | (ng << 8) | nb;
    }

    // ---------- the overlay over the wallpaper: red vignette, a heartbeat and blood running from the top ----------

    public static void overlay(GuiGraphics g, int x, int y, int w, int h) {
        long t = System.currentTimeMillis();
        float p = pulse();
        g.enableScissor(x, y, x + w, y + h);
        int edge = 0x30 + (int) (p * 0x30);
        g.fillGradient(x, y, x + w, y + h * 35 / 100, (edge << 24) | 0x600008, 0x00600008);
        g.fillGradient(x, y + h * 55 / 100, x + w, y + h, 0x00600008, ((edge + 0x18) << 24) | 0x400006);
        for (int k = 0; k < 14; k++) {                                              // drips from the top edge
            int hh = hash(k * 977 + 5);
            int dx = x + 6 + hh % Math.max(1, w - 12);
            int speed = 2200 + hh % 2600;
            double ph = ((t + hh % 4000) % speed) / (double) speed;
            int len = (int) (6 + ph * (14 + hh % 22));
            int wd = 1 + (hh >> 5) % 2;
            g.fill(dx, y, dx + wd, y + len, 0xB07A0610);
            g.fill(dx, y + len, dx + wd, y + len + 1, 0xE0B01020);
        }
        g.disableScissor();
    }

    // ---------- chrome ----------

    public static void menuBar(GuiGraphics g, int x, int y, int w, int h) {
        g.fillGradient(x, y, x + w, y + h, 0xF03A0508, 0xF0160204);
        g.fill(x, y, x + w, y + 1, 0xFFB01020);
        g.fill(x, y + h - 1, x + w, y + h, BLOOD);
        for (int px = x + 9; px < x + w - 4; px += 23) {                           // a few little drips under the bar
            int hh = hash(px * 3);
            if (hh % 3 == 0) continue;
            g.fill(px, y + h, px + 1, y + h + 2 + hh % 3, 0xAA8A0A14);
        }
    }

    public static void titleBar(GuiGraphics g, int x, int y, int w, int h) {
        g.fillGradient(x, y, x + w, y + h, 0xFF4A0710, 0xFF200306);
        g.fill(x, y, x + w, y + 1, 0xFFB01020);
        g.fill(x, y + h - 1, x + w, y + h, 0xFF7A0C14);
        for (int px = x + 40; px < x + w - 20; px += 31) {
            int hh = hash(px);
            g.fill(px, y + h - 1, px + 1, y + h + 1 + hh % 3, 0xCC8A0A14);
        }
    }

    public static void dockPill(GuiGraphics g, int x0, int y0, int x1, int y1) {
        Dock.pill(g, x0 - 1, y0 - 1, x1 + 1, y1 + 1, 0xCC8A0A14);
        Dock.pill(g, x0, y0, x1, y1, 0xDD1A0206);
        Dock.pill(g, x0 + 1, y0 + 1, x1 - 1, y0 + Math.max(4, (y1 - y0) / 2), 0x30D9302A);
    }

}
