package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Settings, in three tabs: Wallpapers, Sounds (switches and volume sliders) and Other (Spooky, Pop-ups, password). */
public class SettingsApp extends App {
    private static final int COLS = 3, TW = 88, TH = 40, GAP = 8;
    private static final int X0 = (W - (COLS * TW + (COLS - 1) * GAP)) / 2, Y0 = 28;
    private static final int TAB_Y = 4, TAB_H = 15;
    // Sounds tab
    private static final int SND_TOGGLE_Y = 34, VOL_Y = 70, VOL_STEP = 20;
    // Other tab
    private static final int LIST_Y = 26, RH = 16, UPD_H = 24, CH = 12, LIST_W = TW * 3 + GAP * 2;   // the list of the Other tab
    private int listScroll;
    private static final int BTN_H = 14, MAX_PASSWORD = 24;
    private static final int VOL_LABEL_W = 52, VOL_H = 11;
    private static final int TAB_WALLPAPER = 0, TAB_SOUNDS = 1, TAB_OTHER = 2;
    private int tab;
    private int dragVol = -1;       // 0 = system slider, 1 = music slider, -1 = none
    private static final int KEY_ESC = 256, KEY_ENTER = 257, KEY_BACKSPACE = 259, KEY_KP_ENTER = 335;

    // password dialog: 0 = closed, 1 = type a new password, 2 = repeat it
    private int dialog;
    private final StringBuilder buf = new StringBuilder();
    private String first = "";
    private String message = "";

    @Override
    public Component title() { return Component.translatable("cutemod.os.settings"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.settings"); }

    @Override
    public void close() {
        dialog = 0;
        buf.setLength(0);
        if (dragVol >= 0) { dragVol = -1; Sfx.save(); }
    }

    private static int tx(int i) { return X0 + (i % COLS) * (TW + GAP); }

    private static int ty(int i) { return Y0 + (i / COLS) * (TH + GAP); }

    private static final String[] TAB_KEYS = {"cutemod.os.tab.wallpaper", "cutemod.os.tab.sounds", "cutemod.os.tab.other"};

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Skin.rect(g, 0, 0, W, H, 0xFFE9DDF2);
        if (tab == TAB_OTHER) {
            list(g, mx, my, false);
            Skin.rect(g, 0, 0, W, LIST_Y, 0xFFE9DDF2);       // the tabs cover the rows that scroll up
        }
        for (int i = 0; i < TAB_KEYS.length; i++) {
            int x = bx3(i), w = bw3();
            boolean on = i == tab, hover = in(mx, my, x, TAB_Y, w, TAB_H);
            Skin.rect(g, x, TAB_Y, w, TAB_H, on ? 0xFF9A64BF : (hover ? 0xFFFFFFFF : 0xFFC9B8D8));
            String s = t(TAB_KEYS[i]);
            Skin.str(g, font(), s, x + (w - font().width(s)) / 2, TAB_Y + 4, on ? 0xFFFFFFFF : 0xFF3A2A3A, false);
        }
        Skin.rect(g, X0, TAB_Y + TAB_H + 3, TW * 3 + GAP * 2, 1, 0xFFC9B8D8);

        if (tab == TAB_WALLPAPER) {
            for (int i = 0; i < Wallpaper.BASE; i++) {
                int x = tx(i), y = ty(i);
                boolean selected = i == Wallpaper.get();
                boolean hover = in(mx, my, x, y, TW, TH);
                Skin.rect(g, x - 2, y - 2, TW + 4, TH + 4, selected ? 0xFFFFD866 : (hover ? 0xFFFFFFFF : 0xFF3A2A4A));
                Wallpaper.draw(g, x, y, TW, TH, shell.color().bodyColor, i);
            }
        } else if (tab == TAB_SOUNDS) {
            toggle3(g, mx, my, 0, SND_TOGGLE_Y, "cutemod.os.set.sounds", Sfx.sounds());
            toggle3(g, mx, my, 1, SND_TOGGLE_Y, "cutemod.os.set.hum", Sfx.hum());
            toggle3(g, mx, my, 2, SND_TOGGLE_Y, "cutemod.os.set.music", Sfx.music());
            Skin.str(g, font(), t("cutemod.os.set.volume"), X0, VOL_Y - 14, 0xFF7A6A8A, false);
            slider(g, mx, my, 0, "cutemod.os.set.volsys", Sfx.volSystem);
            slider(g, mx, my, 1, "cutemod.os.set.volmusic", Sfx.volMusic);
        }

        if (dialog > 0) renderDialog(g);
    }

    /** The sound row has three switches instead of two. */
    private static int bw3() { return (TW * 3 + GAP * 2 - 8) / 3; }

    private static int bx3(int i) { return X0 + i * (bw3() + 4); }

    // ---------- volume sliders ----------
    private static int sliderY(int i) { return VOL_Y + i * VOL_STEP; }

    private static int trackX() { return X0 + VOL_LABEL_W; }

    private static int trackW() { return TW * 3 + GAP * 2 - VOL_LABEL_W - 28; }

    private void slider(GuiGraphics g, int mx, int my, int i, String key, int value) {
        int y = sliderY(i), tx = trackX(), tw = trackW();
        Skin.str(g, font(), t(key), X0, y + 2, 0xFF3A2A3A, false);
        Skin.rect(g, tx, y + 4, tw, 3, 0xFFC9B8D8);                                   // the groove
        Skin.rect(g, tx, y + 4, tw * value / Sfx.VOL_MAX, 3, 0xFF9A64BF);             // the filled part
        Skin.rect(g, tx + tw / 2, y + 2, 1, 7, 0xFF7A6A8A);                           // the mark of the normal volume (100 %)
        int kx = tx + tw * value / Sfx.VOL_MAX - 3;
        boolean hot = dragVol == i || in(mx, my, tx - 3, y, tw + 6, VOL_H);
        Skin.rect(g, kx, y + 1, 6, 9, hot ? 0xFFFFFFFF : 0xFFF4EFF8);                // the knob
        Skin.rect(g, kx, y + 1, 6, 1, 0xFF9A64BF);
        Skin.rect(g, kx, y + 9, 6, 1, 0xFF9A64BF);
        Skin.str(g, font(), value + "%", tx + tw + 5, y + 2, 0xFF3A2A3A, false);
    }

    private static int valueAt(int x) {
        int v = Math.max(0, Math.min(Sfx.VOL_MAX, Math.round((float) Sfx.VOL_MAX * (x - trackX()) / trackW())));
        return Math.abs(v - 100) <= 4 ? 100 : v;                  // it snaps to the normal volume
    }

    private void setVol(int i, int value) {
        if (i == 0) Sfx.volSystem = value; else Sfx.volMusic = value;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (dragVol < 0) return false;
        setVol(dragVol, valueAt(x));
        return true;
    }

    @Override
    public void mouse(int x, int y) {
        // called every frame: when the button is let go, save the volume once and play a sample
        if (dragVol >= 0 && org.lwjgl.glfw.GLFW.glfwGetMouseButton(net.minecraft.client.Minecraft.getInstance().getWindow().getWindow(),
                org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT) != org.lwjgl.glfw.GLFW.GLFW_PRESS) {
            int which = dragVol;
            dragVol = -1;
            Sfx.save();
            if (which == 0) Sfx.click();
            else Sfx.musicNote(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_CHIME.value(), 1.0F, 0.6F);
        }
    }

    private void toggle3(GuiGraphics g, int mx, int my, int i, int y, String key, boolean on) {
        int x = bx3(i), w = bw3();
        boolean hover = in(mx, my, x, y, w, BTN_H);
        Skin.rect(g, x, y, w, BTN_H, on ? (hover ? 0xFFB57BD6 : 0xFF9A64BF) : (hover ? 0xFFFFFFFF : 0xFFC9B8D8));
        String s = t(key) + ": " + t(on ? "cutemod.os.on" : "cutemod.os.off");
        Skin.str(g, font(), s, x + (w - font().width(s)) / 2, y + 3, on ? 0xFFFFFFFF : 0xFF3A2A3A, false);
    }

    // ---------- the Other tab: one list, a row for each setting ----------

    private static int listMax() { return Math.max(0, 12 * RH + UPD_H - (H - LIST_Y) + 2); }

    private int bwOf(String s) { return font().width(s) + 10; }

    private void stripe(GuiGraphics g, int row, int y, int h) {
        if (g != null) Skin.rect(g, X0, y, LIST_W, h, row % 2 == 0 ? 0xFFF4EFF8 : 0xFFEDE4F5);
    }

    private void label(GuiGraphics g, String s, int y, int h) {
        if (g != null) Skin.str(g, font(), s, X0 + 5, y + (h - 8) / 2, 0xFF3A2A3A, false);
    }

    /** A small button of a row. Draws it (g != null) and says whether this click (clicking) hit it. */
    private boolean btn(GuiGraphics g, int mx, int my, boolean clicking, int x, int y, int w, String label, boolean on, boolean enabled) {
        boolean hover = enabled && in(mx, my, x, y, w, CH);
        if (g != null) {
            Skin.rect(g, x, y, w, CH, !enabled ? 0xFFD9CEE3 : on ? (hover ? 0xFFB57BD6 : 0xFF9A64BF) : (hover ? 0xFFFFFFFF : 0xFFC9B8D8));
            Skin.str(g, font(), label, x + (w - font().width(label)) / 2, y + 2, !enabled ? 0xFF9A90A8 : on ? 0xFFFFFFFF : 0xFF3A2A3A, false);
        }
        return clicking && hover;
    }

    /** One pass over the list: draws it (g != null), or finds the control under a click and acts on it. One place for the
     *  layout, so the drawing and the clicks cannot drift apart. */
    private boolean list(GuiGraphics g, int mx, int my, boolean clicking) {
        int right = X0 + LIST_W - 4, y = LIST_Y - listScroll, row = 0;

        // appearance: light / dark / auto
        stripe(g, row++, y, RH);
        label(g, t("cutemod.os.skin") + (Skin.mode() == Skin.AUTO ? " (" + t(Skin.dark() ? "cutemod.os.skin.dark" : "cutemod.os.skin.light") + ")" : ""), y, RH);
        String[] names = {"cutemod.os.skin.light", "cutemod.os.skin.dark", "cutemod.os.skin.auto"};
        for (int k = 0; k < 3; k++) {
            if (btn(g, mx, my, clicking, right - 142 + k * 48, y + 2, 46, t(names[k]), Skin.mode() == k, true)) { Skin.setMode(k); Sfx.click(); return true; }
        }
        y += RH;

        // screensaver: < > and a preview
        stripe(g, row++, y, RH);
        label(g, t("cutemod.os.set.saver") + ": " + t("cutemod.saver." + Retro.saver()), y, RH);
        String pv = t("cutemod.os.saver.preview");
        int pw = bwOf(pv), px = right - pw;
        if (btn(g, mx, my, clicking, px, y + 2, pw, pv, true, true)) { shell.saver(); return true; }
        if (btn(g, mx, my, clicking, px - 16, y + 2, 14, ">", true, true)) { Retro.setSaver(Savers.step(Retro.saver(), 1)); return true; }
        if (btn(g, mx, my, clicking, px - 32, y + 2, 14, "<", true, true)) { Retro.setSaver(Savers.step(Retro.saver(), -1)); return true; }
        y += RH;

        // the font: cute / bold / the game's own
        stripe(g, row++, y, RH);
        label(g, t("cutemod.os.set.font"), y, RH);
        int[] fonts = {CuteFont.REGULAR_W, CuteFont.BOLD_W, CuteFont.SYSTEM_W};
        for (int k = 0; k < fonts.length; k++) {
            if (btn(g, mx, my, clicking, right - 136 + k * 46, y + 2, 44, t("cutemod.os.font." + fonts[k]), CuteFont.weight() == fonts[k], true)) { CuteFont.setWeight(fonts[k]); Sfx.click(); return true; }
        }
        y += RH;

        // the size of the font: small / normal / large (the game's own font has only one size)
        stripe(g, row++, y, RH);
        boolean sizable = CuteFont.weight() != CuteFont.SYSTEM_W;
        label(g, t("cutemod.os.set.fontsize") + (sizable ? "" : " (" + t("cutemod.os.fontsize.note") + ")"), y, RH);
        for (int k = 0; k < 3; k++) {
            if (btn(g, mx, my, clicking, right - 136 + k * 46, y + 2, 44, t("cutemod.os.fontsize." + k), sizable && CuteFont.size() == k, sizable)) { CuteFont.setSize(k); Sfx.click(); return true; }
        }
        y += RH;

        // the switches
        String[] swKeys = {"cutemod.os.set.hints", "cutemod.os.set.bee", "cutemod.os.set.scary", "cutemod.os.set.popups", "cutemod.os.set.crash", "cutemod.os.set.mech", "cutemod.os.set.bed"};
        boolean[] sw = {Retro.hints(), Retro.bee(), Haunt.scary, Haunt.popups, Retro.crashes(), Retro.mechClicks(), Retro.bedtime()};
        for (int k = 0; k < sw.length; k++) {
            stripe(g, row++, y, RH);
            label(g, t(swKeys[k]), y, RH);
            if (btn(g, mx, my, clicking, right - 40, y + 2, 40, t(sw[k] ? "cutemod.os.on" : "cutemod.os.off"), sw[k], true)) {
                switch (k) {
                    case 0 -> Retro.setHints(!Retro.hints());
                    case 1 -> Retro.setBee(!Retro.bee());
                    case 2 -> Haunt.scary = !Haunt.scary;
                    case 3 -> Haunt.popups = !Haunt.popups;
                    case 4 -> Retro.setCrashes(!Retro.crashes());
                    case 5 -> Retro.setMechClicks(!Retro.mechClicks());
                    default -> Retro.setBedtime(!Retro.bedtime());
                }
                Sfx.click();
                return true;
            }
            y += RH;
        }

        // password
        boolean has = Startup.hasPassword();
        stripe(g, row++, y, RH);
        label(g, t("cutemod.os.set.password"), y, RH);
        String rm = t("cutemod.os.pw.remove"), ch = t(has ? "cutemod.os.pw.change" : "cutemod.os.pw.set");
        int rw = bwOf(rm), cw = bwOf(ch);
        if (btn(g, mx, my, clicking, right - rw, y + 2, rw, rm, true, has)) { Startup.setPassword(null); return true; }
        if (btn(g, mx, my, clicking, right - rw - 2 - cw, y + 2, cw, ch, true, true)) {
            dialog = 1;
            buf.setLength(0);
            message = "";
            return true;
        }
        y += RH;

        // the update (a taller row: version, then what is new)
        stripe(g, row++, y, UPD_H);
        int av = Updates.available();
        if (g != null) {
            String info = av >= 0 ? t("cutemod.os.upd.available", t("cutemod.update." + Updates.ALL.get(av).id() + ".name"))
                    : Updates.upcoming() != null ? t("cutemod.os.upd.next", Updates.upcoming().date().toString())
                    : t("cutemod.os.upd.uptodate");
            Skin.str(g, font(), t("cutemod.os.upd.version", Updates.versionLabel()), X0 + 5, y + 3, 0xFF3A2A3A, false);
            Skin.str(g, font(), info, X0 + 5, y + 13, av >= 0 ? 0xFF2E7D4F : 0xFF7A6A8A, false);
        }
        String ins = t("cutemod.os.upd.install");
        int iw = bwOf(ins);
        if (btn(g, mx, my, clicking, right - iw, y + 6, iw, ins, true, av >= 0)) { shell.installUpdate(av); return true; }

        // the scroll bar
        if (g != null && listMax() > 0) {
            int track = H - LIST_Y - 4, th = Math.max(12, track * track / (track + listMax()));
            Skin.rect(g, W - 6, LIST_Y, 3, track, 0xFFC9B8D8);
            Skin.rect(g, W - 6, LIST_Y + (track - th) * listScroll / listMax(), 3, th, 0xFF9A64BF);
        }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        if (tab != TAB_OTHER || dialog > 0) return false;
        listScroll = Math.max(0, Math.min(listMax(), listScroll - (int) Math.signum(amount) * RH));
        return true;
    }

    private void renderDialog(GuiGraphics g) {
        Skin.rect(g, 0, 0, W, H, 0xAA140E1C);
        int dw = 180, dh = 74, dx = (W - dw) / 2, dy = (H - dh) / 2;
        Skin.rect(g, dx - 1, dy - 1, dw + 2, dh + 2, 0xFFB9B0C8);
        Skin.rect(g, dx, dy, dw, dh, 0xFFF4EFF8);
        Skin.cstr(g, font(), Component.translatable(dialog == 1 ? "cutemod.os.pw.new" : "cutemod.os.pw.repeat"),
                W / 2, dy + 8, 0xFF3A2A3A);
        int fx = dx + 16, fy = dy + 24, fw = dw - 32;
        Skin.rect(g, fx - 1, fy - 1, fw + 2, 16, 0xFF9A64BF);
        Skin.rect(g, fx, fy, fw, 14, 0xFFFFFFFF);
        String dots = "•".repeat(buf.length());
        while (font().width(dots) > fw - 12) dots = dots.substring(1);
        Skin.str(g, font(), dots, fx + 4, fy + 3, 0xFF3A2A3A, false);
        if ((System.currentTimeMillis() / 400) % 2 == 0) Skin.rect(g, fx + 5 + font().width(dots), fy + 2, 1, 10, 0xFF3A2A3A);
        if (!message.isEmpty()) Skin.cstr(g, font(), Component.literal(message), W / 2, dy + 44, 0xFFD9302A);
        Skin.cstr(g, font(), Component.translatable("cutemod.os.pw.dialog.hint"), W / 2, dy + 58, 0xFF7A6A8A);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (dialog > 0) return true;
        for (int i = 0; i < TAB_KEYS.length; i++) {
            if (in(x, y, bx3(i), TAB_Y, bw3(), TAB_H)) { tab = i; return true; }
        }
        if (tab == TAB_SOUNDS) {
            for (int i = 0; i < 2; i++) {
                if (in(x, y, trackX() - 4, sliderY(i), trackW() + 8, VOL_H)) {
                    dragVol = i;
                    setVol(i, valueAt(x));
                    return true;
                }
            }
            if (in(x, y, bx3(0), SND_TOGGLE_Y, bw3(), BTN_H)) { Sfx.sounds = !Sfx.sounds; Sfx.save(); return true; }
            if (in(x, y, bx3(1), SND_TOGGLE_Y, bw3(), BTN_H)) { Sfx.hum = !Sfx.hum; Sfx.save(); return true; }
            if (in(x, y, bx3(2), SND_TOGGLE_Y, bw3(), BTN_H)) { Sfx.music = !Sfx.music; Sfx.save(); return true; }
        } else if (tab == TAB_OTHER) {
            if (y >= LIST_Y) return list(null, x, y, true);
        } else {
            for (int i = 0; i < Wallpaper.BASE; i++) {
                if (in(x, y, tx(i), ty(i), TW, TH)) {
                    Wallpaper.set(i);
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (dialog == 0) return false;
        if (keyCode == KEY_ESC) {
            dialog = 0;
            buf.setLength(0);
        } else if (keyCode == KEY_BACKSPACE && buf.length() > 0) {
            buf.setLength(buf.length() - 1);
            message = "";
        } else if (keyCode == KEY_ENTER || keyCode == KEY_KP_ENTER) {
            if (dialog == 1) {
                if (buf.length() == 0) return true;
                first = buf.toString();
                buf.setLength(0);
                dialog = 2;
                message = "";
            } else if (buf.toString().equals(first)) {
                Startup.setPassword(first);
                first = "";
                buf.setLength(0);
                dialog = 0;
            } else {
                message = t("cutemod.os.pw.mismatch");
                buf.setLength(0);
                dialog = 1;
                first = "";
            }
        }
        return true;    // while the dialog is open every key belongs to it
    }

    @Override
    public boolean charTyped(char c) {
        if (dialog == 0) return false;
        if (c >= 32 && c != 127 && buf.length() < MAX_PASSWORD) {
            buf.append(c);
            message = "";
        }
        return true;
    }
}
