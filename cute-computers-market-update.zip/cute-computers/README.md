# Cute Computers (NeoForge 1.21.1)

Cute retro computers in 8 colors. **Right-click a computer to open its desktop.**
The desktop looks like macOS: a menu bar on top (logo menu, app name, coins, clock), windows with red/yellow/green buttons and a **Dock** at the bottom whose icons grow under the mouse. All icons share one macOS style: a rounded tile with a soft gradient and a flat white glyph (the gamepad takes the computer's color); they are drawn in code in `Desktop.drawIcon`. The Dock has: your computer's own game, a **Games** folder (all 8 games on any computer), a **Browser**, **Notes**, **Paint**, **Calculator** and **Settings**.
No redstone or energy needed. Every computer remembers its own high score and who set it.

![preview](docs/preview.png)

| Block | Game | Controls |
|---|---|---|
| `pink_computer` | Flappy Cat | click / Space |
| `green_computer` | Creeper Sweeper (minesweeper) | LMB dig, RMB flag |
| `white_computer` | Panda Snake | WASD / arrows |
| `blue_computer` | Penguin Fishing | mouse (avoid the pufferfish!) |
| `orange_computer` | Fox Memory (pairs) | click |
| `purple_computer` | Ender Dodge | mouse |
| `yellow_computer` | Whack-a-Bee | click the bee |
| `red_computer` | Ladybug Match (match-3, 20 moves) | click two neighbors |

## Desktop apps
| App | What it does |
|---|---|
| CuteStore | the game store: **all games cost coins**. Store tab with a *game of the day* (-30%, changes every day), cover art, ratings and descriptions; buying starts an **install** (a few seconds of real time, it keeps going even if you close the screen). Library tab: your games, play time and best scores. **Reviews**: every game has reviews from other players, and once you own a game you can leave your own stars + text (first review = +3 coins) |
| CuteStore apps | the **Apps** tab of CuteStore has 6 downloadable apps: **Calculator, Paint, Terminal, Tamagotchi and Mail are free**; Music costs 10 coins. Every app has a page with a description, size, rating and 3 to 5 reviews (every game has 3 to 5 reviews too), and you can leave your own review once you own it. Installing takes a few seconds of real time. **An app that is not installed is hidden from the Dock and the Start menu**; opening it any other way shows its store page. *Remove* (click twice) uninstalls an app, ends its process and takes it off the Dock; what you bought stays yours, so installing it again is free. Calculator, Paint, Terminal and Tamagotchi are free because the story quest needs them. Notes, Browser, Settings, Diary, CuteJobs, CuteMarket (it now holds the old Shop too), the Games folder and CuteStore itself are part of the system and cannot be removed. Saves from before the app store keep all their apps installed |
| Sakura Catch, Cute Blocks | two more store games: an anime-style catcher (chibi girl with a parasol, petals, onigiri, storm clouds) and a pastel falling-blocks puzzle |
| Cake Bakery | a cake shop game in CuteStore (50 coins), in the spirit of the old Windows bakery games. A day is 90 seconds. Customers (up to 3) order a cake with a **flavor** (vanilla, chocolate, strawberry) and a **topping** (cherry, sprinkles, candle) and lose patience. Click a bowl (or keys 1-2-3) to put batter in one of 2 ovens, take the cake out when the bar turns green and **before it burns** (about 10 s later; it is ready after 3 s), it goes to a plate; pick a topping (or Q-W-E) and click the cake, then click the cake and the customer. A right cake pays 10 + a tip (up to 5, the faster the more) + a streak bonus (up to 5); a wrong cake wastes the cake and costs the customer 15% of their patience; a customer who runs out of patience takes one of your 5 hearts; no hearts, the bakery closes. Score = cash earned, a par day (120) gives 10 coins |
| Cake Factory | a conveyor-belt cake game in CuteStore (45 coins), in the spirit of the cake factory from the old Windows Purble Place. A shift is 90 seconds. A cake rides the belt through 4 stations: **shape** (round, square, two tiers), **batter** (vanilla, chocolate, strawberry), **icing** (pink, white, blue) and **topping** (cherry, sprinkles, candle). While the cake is lit inside a station, click one of its 3 buttons (or press 1-2-3) to add that part, then match the **order** in the top left corner. A right cake pays 10 + a streak bonus (up to 5) + a speed bonus (up to 5); a wrong or unfinished cake costs one of 3 hearts. The belt gets faster with every cake (up to 2.4x). Score = money earned, a par shift (180) gives 10 coins |
| Durak | a card game for two in CuteStore (45 coins): the classic Russian *Durak* against the computer. 36 cards, trump suit, attack / defend / take / add cards |
| CuteJobs | **10 jobs to earn coins** (shifts of 1 to 1.5 minutes): Typist, Postman, Pet Sitter (rank Intern), Cafe, Courier (Employee), Artist, Game Tester (Senior), and three hard ones with better pay: **Programmer** (Senior, 75 s: find the one different symbol in a growing grid before time runs out, up to 26 coins), **DJ** (Manager, 90 s: a Simon-style game, repeat the growing pad sequence with clicks or keys 1-4, up to 32) and **Pilot** (Manager, 90 s: fly through narrowing gaps with the mouse, faster and faster, up to 36). Shifts give experience and ranks (x1 / x1.15 / x1.3 / x1.5 pay); each job has a 3 minute rest after a shift and any shift also locks every job for 90 seconds (so rotating jobs is no faster); the first 300 coins of pay a day are full, after that a shift pays a quarter; a shift with quality under 20% pays nothing |
| CuteMarket | the online shop (also `cutemarket.cute` in the browser): order **8 foods**, **19 music discs** and real **gear from the game** (pickaxes, axes, shovels, hoes, swords, bows, shields and all armor, wooden to netherite) for coins, put them in a cart, pick *Express* (+30% price, 3x faster) and follow the courier in real time. When a parcel has arrived, collect it and you get the real items. |
| Halloween event | Oct 24 - Nov 3 by the real calendar (or any time with the terminal command `halloween`): sweets, golden sweets and ghosts pop up on the desktop with bats and cobwebs. Click the sweets to collect candy (shown in the menu bar), click the pumpkin lantern in the corner to trade candy for coins (3 trades a day), the *Haunted Pumpkin Night* wallpaper, or the horror games (Something in the Dark, Dark Corridor, Zombie Shooter). Horror games are on sale (-50%) in the store, three letters arrive in the mail and there is an achievement for 50 candy |
| Games | the games you bought and installed (any computer; the record in the block counts only for the computer's own game). Extra games: Cookie Breaker (breakout), Merge Cubes (2048), Slime Pong, Bee Invaders, Something in the Dark (horror: the monster only moves while you're not lighting it), **Dark Corridor** (first-person horror: a random dark maze, find 3 keys and the green door while a pale figure hunts you; WASD/arrows, a map of the places you have been in the corner), **MiniCraft** (a tiny side-view Minecraft: A/D walk, W jump, LMB mine / hit, RMB place, 1-4 hotbar, C planks, E next pickaxe; chop a tree, craft wooden, stone and iron pickaxes, dig for coal, iron and **3 diamonds** while zombies come at night; they chew through trees and dirt but stone and planks stop them), **Zombie Shooter** (first-person wave shooter in the style of Call of Duty Zombies: endless rounds in one arena, 10 points per hit and 60 per kill, health regenerates when you are not hit; WASD walk, mouse near the left/right edge or arrows turn, LMB/Space shoot, R reload, 1/2/Q switch weapon, E at the golden wall to buy a rifle (500) and ammo (250)). The Games folder has 2 pages (arrows or mouse wheel) |
| Browser | the **Cute Web**, a made-up internet (GTA 5 style): `peep.cute` search, `chirp.cute`, `creepermart.cute`, `pandapedia.cute`, `beemail.cute`, `cutenews.cute`, `scarystories.cute` (dark theme, flickering light, watching eyes). Also `cutetube.cute` - **CuteTube**: 6 tiny animated videos with note-block sound, a progress bar and volume slider, likes, ready-made comments and your own (type in the box, Enter sends; space = pause, arrows = skip 5 s). With **Spooky** on, a 7th video appears: "Don't Watch at 3 AM" (eyes in the corner, something in the door, a jump scare, and it says your name at the end). Every page has an animated ad banner at the bottom (click it to visit the advertiser, "x" skips to the next ad). Words in the address bar search it; real addresses like `example.com` open in your system browser after the vanilla "open link?" confirmation |
| Haunting | on its own the computer sometimes shows annoying pop-up ads (the "x" runs away, "bad" buttons spawn more windows) and creepy events: watching eyes, screen glitches, whispers, a fake record held by "The One Behind You", a line that types itself in Notes (never saved), corrupted ads in the browser. Everything is display-only. Settings has switches for **Spooky** and **Pop-ups** |
| Music | player with 4 little songs played on note-block sounds (lead + bass), equalizer, volume. Plays while the app is open |
| Tamagotchi | every computer color has its own pet (cat, creeper, panda, penguin, fox, enderman, bee, ladybug): feed it, play, let it sleep, pet it. Saved on the server (per player), gets hungry slowly even while you are away. **It grows up**: baby (first 20 minutes with it, small, with pink cheeks), teen (up to an hour) and grown-up (full size, sparkles); the name line shows the stage. **It gets a character** from how you treat it (after about 12 actions): Foodie, Playful, Sleepy or Cuddly, which changes what it says. **It writes you letters**: after 5 minutes of being really happy (awake, all bars good) it sends a letter to the Mail app, up to 4 of them, each with a few coins. **It can fall sick**: if it is neglected (food, fun or energy almost empty for 90 seconds) or left alone for 2+ hours it gets sick: sad face, thermometer, no playing, bars drop faster, no letters, and a red banner on top. Only **Medicine** (25 coins, CuteMarket > Home, the red-cross slot next to the treats) cures it, and it does not go away by itself. The first time it is sick the vet leaves one free dose. Medicine is not used up on a healthy pet. **Mini-game "Where is the treat?"** (the *Game* button under the window): the pet hides a treat under one of 3 cups, the cups are shuffled (more and faster swaps each of 3 rounds) and you click the right one. **The Game button now opens a menu of 3 games**: the cups, **Catch the treats** (20 seconds, treats fall and you click them, bad green blobs cost 2; 5 / 11 / 18 caught = 1 / 2 / 3 stars) and **Copy the pet** (like Simon: 4 colored pads, the pet lights them one by one and you repeat the order, up to 5 rounds that get longer; 1 / 3 / 5 rounds = 1 / 2 / 3 stars). Prize: 2 coins per star (per found treat in the cups), +4 for 3 stars; at most 5 prized games a day; each game costs 10 energy, needs an awake and healthy pet, and Esc leaves it |
| Diary | the story quest (13 chapters in 2 parts: "Strange Stories" and "The Quiet One"), 3 daily tasks with a login streak bonus, and 14 achievements |
| Terminal | command line: `help`, `whoami`, `scan`, `unlock`, `cat`, `ls`, `bee`, `creeper`, `matrix`, `fortune` and more (some are part of the quest: `archive <code>`, `stay` / `bye`) |
| Coins | you get coins for playing games (each game has its own scale: a good result is worth about 10 coins, at most 25 per game and 150 per day from games), pet care, finished videos, achievements, daily tasks and quest chapters. The balance is shown in the taskbar. Everything is saved on the server, per player (UUID) |
| Notes | text editor, saved on the server, per player |
| Paint | 64x36 pixel drawing (LMB draw, RMB erase) |
| Calculator | mouse or keyboard |
| Settings | 6 wallpapers, saved on the server, per player |

## CuteMarket (real items and home goods)
The app has four tabs: **Goods** (food, discs, gear), **Home**, **Cart** and **Orders**. The **Home** tab is the old Shop app, now part of CuteMarket: 12 wallpapers (6 of them new and animated: Sakura, Aurora, Synthwave, Neon Grid, Winter Forest, Summer Meadow), the paid **Frutiger Aero** desktop theme (120 coins; glossy blue glass menu bar, window title bars and Dock, a sky glow and rising bubbles over the wallpaper; it sits in the **Style** tab with the wallpapers and can be switched back to the classic look at any time), 14 pet accessories (the golden crown and the ghost are story rewards; new: ushanka, headphones, devil horns, witch hat, scarf, cape), 4 extra songs for the player and 5 treats (cookie, fish, honey, milk, cake; buy a stock, then click one under the pet's room to feed it). These are bought with coins and used at once: no cart, no courier. The pet has **two clothing slots**: head or face (hats, glasses, horns, headphones...) and neck or body (scarf, cape), so a hat and a scarf can be worn together; each item has its own Wear / Take off button. The Dock icon of CuteMarket shows a red number when a parcel is ready.

Gear: tools (27), weapons (9) and armor (24 pieces) are the game's own items, priced by metal (a wooden pickaxe 12 coins, a diamond one 360, netherite 1040; netherite armor 1040-2080) and delivered slower the better they are (1 to 5 minutes). Every line holds one piece, and a piece counts as 8 items in the daily limit of 48, so the market brings at most 6 pieces of gear a day.
Everything is a real Minecraft item: the 8 foods of the mod (cupcake, ice cream, bubble tea, honey toast, burger, pizza, ramen, sushi, each with hunger and a short effect), and the game's 19 music discs (12 cheap, 7 rare ones). The shop list lives in one place, `market/Catalog.java`, shared by the app and the server.

An order is kept **on the server**: it checks the items, limits (8 lines, 16 foods or 4 discs per line, 14 parcels, 48 items per day), the delivery time and that you stand near a computer. When a parcel has arrived, press the collect button in CuteMarket (Orders tab) at any computer and the items go to your inventory (or drop at your feet). Coins are still counted by the client; a refused order gives the coins back.

## Crafting
- Pink computer: iron ingots, glass pane, pink dye, redstone (`IGI / IDI / IRI`).
- Any other color: any computer + the matching dye (shapeless).

## Build
Requires Java 21.

```
./gradlew build          # jar in build/libs
./gradlew runClient      # test in game
```
GitHub Actions (`.github/workflows/build.yml`) builds the jar on every push.

## Project layout
- `src/main/java/dev/cutemod` - blocks, block entity (high score), network packet
- `src/main/java/dev/cutemod/client` - the monitor screen, `os/` (desktop and apps) and `game/` (all 8 mini games)
- `src/main/resources/assets/cutemod` - models, blockstates, textures (64x), lang (en, ru)
- `tools/` - Python scripts that generated the colored textures from the original pink pack

## Adding a new app
Extend `App` (`title`, `render`, optionally `tick`/`click`/`key`/`charTyped`) and add an icon in `Desktop`.

## Adding a new game
Extend `MiniGame` (`reset`, `tick` at 60/s, `render`, optionally `click`/`key`) and map it to a color in `GameFactory`.

## License
MIT

## Windows and hotkeys
Every app is a process. The **red** button of a window (or `Ctrl+W`) quits the app and ends its process; the **yellow** one (or `Ctrl+M` / `Ctrl+D`) minimizes it: it keeps running in the background (music goes on playing) and a dim dot under its Dock icon shows it is still alive. Click the icon (or pick it with `Ctrl+Tab`) to bring it back. Right-click a Dock icon for *Quit* and *Remove from Dock*. Leaving the computer ends every process.

| Keys | Action |
|---|---|
| `Ctrl+W` | quit the current app |
| `Ctrl+M`, `Ctrl+D` | minimize to the desktop |
| `Ctrl+Tab`, `Ctrl+Shift+Tab` | switch between running apps |
| `Ctrl+Space` | open / close the Start menu |
| `Ctrl+1` ... `Ctrl+9` | open the 1st ... 9th app of the Dock |
| `Ctrl+L` | lock the screen |
| `Ctrl+Q` | leave the computer |
| `Esc` | close a menu, or leave the computer |
