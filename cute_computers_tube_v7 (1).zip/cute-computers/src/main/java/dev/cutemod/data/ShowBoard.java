package dev.cutemod.data;

import dev.cutemod.ComputerColor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * The pet show: which pets players have put on display and who liked them. Pure logic (no Minecraft classes),
 * so the rules can be tested on their own; {@link ShowData} saves it to the world.
 * <p>
 * A pet on display is a snapshot sent by the client (the server cannot see inside a player's pet), so every value
 * is checked against a white list. A pet is identified by its owner and its color: one player can show
 * {@link #MAX_PER_PLAYER} pets; showing another one pushes the oldest off the stand (and its likes are lost).
 */
public final class ShowBoard {
    public static final int OK = 0, TOO_FAST = 1, REFUSED = 2, SICK = 3, OWN = 4, MISSING = 5, NOOP = 6;
    public static final int SORT_POPULAR = 0, SORT_NEWEST = 1, SORT_ELDEST = 2;

    /** How many pets one player can show at once (1 now; set 8 to let a player show the whole collection). */
    public static final int MAX_PER_PLAYER = 1;
    /** Pets per page of the list. */
    public static final int PAGE = 8;
    public static final int MAX_AGE_MIN = 10_000_000;

    /** Things a pet may wear on its head / face and on its neck / body (see PetArt). */
    public static final Set<String> HEAD = Set.of("acc_ushanka", "acc_headphones", "acc_horns", "acc_witch", "acc_glasses",
            "acc_bow", "acc_hat", "acc_crown", "acc_ghost", "acc_party", "acc_halo", "acc_flower", "acc_cap");
    public static final Set<String> BODY = Set.of("acc_scarf", "acc_cape");

    public static final class Pet {
        public final UUID owner;
        public String ownerName, color, head, body;
        public int stage, trait, ageMin;
        public long since;
        public final Set<UUID> likes = new LinkedHashSet<>();

        Pet(UUID owner) { this.owner = owner; }
    }

    private final Map<UUID, LinkedHashMap<String, Pet>> byOwner = new HashMap<>();

    // ---------- checks ----------
    public static boolean validColor(String c) {
        if (c == null) return false;
        for (ComputerColor v : ComputerColor.values()) if (v.id.equals(c)) return true;
        return false;
    }

    private static String cleanName(String s) {
        String n = s == null ? "" : s.trim();
        if (n.length() > 32) n = n.substring(0, 32);
        return n.isEmpty() ? "?" : n;
    }

    private static boolean validLook(int stage, int trait, int ageMin, String head, String body) {
        return stage >= 0 && stage <= 2 && trait >= 0 && trait <= 4 && ageMin >= 0 && ageMin <= MAX_AGE_MIN
                && head != null && body != null && (head.isEmpty() || HEAD.contains(head)) && (body.isEmpty() || BODY.contains(body));
    }

    // ---------- showing and withdrawing ----------
    /**
     * Put a pet on display (or refresh it: the likes stay while the color is the same).
     * Returns OK, REFUSED (invalid values) or SICK (a sick pet is not shown).
     */
    public int put(UUID owner, String ownerName, String color, int stage, int trait, int ageMin, boolean sick,
                   String head, String body, long now) {
        if (owner == null || !validColor(color) || !validLook(stage, trait, ageMin, head, body)) return REFUSED;
        if (sick) return SICK;
        LinkedHashMap<String, Pet> mine = byOwner.computeIfAbsent(owner, k -> new LinkedHashMap<>());
        Pet p = mine.get(color);
        if (p == null) {
            while (mine.size() >= MAX_PER_PLAYER) mine.remove(mine.keySet().iterator().next());   // the oldest leaves the stand
            p = new Pet(owner);
            p.color = color;
            p.since = now;
            mine.put(color, p);
        }
        p.ownerName = cleanName(ownerName);
        p.stage = stage; p.trait = trait; p.ageMin = ageMin; p.head = head; p.body = body;
        return OK;
    }

    /** Put back a pet read from the save file (checked like any other, sick pets are never saved). */
    public void restore(UUID owner, String ownerName, String color, int stage, int trait, int ageMin, String head, String body,
                        long since, Set<UUID> likes) {
        if (put(owner, ownerName, color, stage, trait, ageMin, false, head, body, since) != OK) return;
        Pet p = byOwner.get(owner).get(color);
        if (p != null) for (UUID u : likes) if (!u.equals(owner)) p.likes.add(u);
    }

    public boolean remove(UUID owner, String color) {
        Map<String, Pet> mine = byOwner.get(owner);
        if (mine == null || mine.remove(color) == null) return false;
        if (mine.isEmpty()) byOwner.remove(owner);
        return true;
    }

    /** Take all the pets of a player off the show. Returns how many there were. */
    public int removeAll(UUID owner) {
        Map<String, Pet> mine = byOwner.remove(owner);
        return mine == null ? 0 : mine.size();
    }

    /** The player changed their name: refresh it on their pets. Returns true if something changed. */
    public boolean rename(UUID owner, String name) {
        Map<String, Pet> mine = byOwner.get(owner);
        if (mine == null) return false;
        String n = cleanName(name);
        boolean changed = false;
        for (Pet p : mine.values()) if (!n.equals(p.ownerName)) { p.ownerName = n; changed = true; }
        return changed;
    }

    // ---------- likes ----------
    /** OK (new like), NOOP (already liked), OWN (your own pet), MISSING (no such pet). */
    public int like(UUID voter, UUID owner, String color) {
        if (voter == null || owner == null) return MISSING;
        if (voter.equals(owner)) return OWN;
        Pet p = get(owner, color);
        if (p == null) return MISSING;
        return p.likes.add(voter) ? OK : NOOP;
    }

    /** OK (the like was taken back), NOOP (there was none), MISSING (no such pet). */
    public int unlike(UUID voter, UUID owner, String color) {
        Pet p = get(owner, color);
        if (p == null) return MISSING;
        return p.likes.remove(voter) ? OK : NOOP;
    }

    // ---------- reading ----------
    public Pet get(UUID owner, String color) {
        Map<String, Pet> mine = byOwner.get(owner);
        return mine == null ? null : mine.get(color);
    }

    public int total() {
        int n = 0;
        for (Map<String, Pet> m : byOwner.values()) n += m.size();
        return n;
    }

    /** The colors of the pets this player has on display. */
    public List<String> colorsOf(UUID owner) {
        Map<String, Pet> mine = byOwner.get(owner);
        return mine == null ? new ArrayList<>() : new ArrayList<>(mine.keySet());
    }

    public List<Pet> all() {
        List<Pet> out = new ArrayList<>();
        for (Map<String, Pet> m : byOwner.values()) out.addAll(m.values());
        return out;
    }

    public static int clampPage(int page, int total) {
        int last = total <= 0 ? 0 : (total - 1) / PAGE;
        return Math.max(0, Math.min(page, last));
    }

    public static int clampSort(int sort) { return sort < 0 || sort > 2 ? SORT_POPULAR : sort; }

    /** One page of the list: popular = most likes, newest = put on display last, eldest = the oldest pets. */
    public List<Pet> page(int sort, int page) {
        List<Pet> all = all();
        Comparator<Pet> byId = Comparator.comparing((Pet p) -> p.owner.toString()).thenComparing(p -> p.color);
        Comparator<Pet> cmp = switch (clampSort(sort)) {
            case SORT_NEWEST -> Comparator.comparingLong((Pet p) -> -p.since).thenComparing(byId);
            case SORT_ELDEST -> Comparator.comparingInt((Pet p) -> -p.ageMin).thenComparing(byId);
            default -> Comparator.comparingInt((Pet p) -> -p.likes.size()).thenComparingLong(p -> -p.since).thenComparing(byId);
        };
        all.sort(cmp);
        int from = clampPage(page, all.size()) * PAGE;
        return new ArrayList<>(all.subList(Math.min(from, all.size()), Math.min(from + PAGE, all.size())));
    }
}
