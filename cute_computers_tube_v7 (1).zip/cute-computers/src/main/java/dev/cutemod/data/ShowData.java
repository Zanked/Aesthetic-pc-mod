package dev.cutemod.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/** The pet show saved in the world (data/cutemod_show.dat), kept on the SERVER. The rules live in {@link ShowBoard}. */
public class ShowData extends SavedData {
    private final ShowBoard board = new ShowBoard();

    public static ShowData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(new SavedData.Factory<>(ShowData::new, ShowData::load, null), "cutemod_show");
    }

    /** For reading only; change the show through the methods below so that it gets saved. */
    public ShowBoard board() { return board; }

    public int put(UUID owner, String name, String color, int stage, int trait, int ageMin, boolean sick, String head, String body) {
        int r = board.put(owner, name, color, stage, trait, ageMin, sick, head, body, System.currentTimeMillis());
        if (r == ShowBoard.OK) setDirty();
        return r;
    }

    public boolean remove(UUID owner, String color) {
        boolean r = board.remove(owner, color);
        if (r) setDirty();
        return r;
    }

    public int removeAll(UUID owner) {
        int n = board.removeAll(owner);
        if (n > 0) setDirty();
        return n;
    }

    public void rename(UUID owner, String name) {
        if (board.rename(owner, name)) setDirty();
    }

    public int like(UUID voter, UUID owner, String color) {
        int r = board.like(voter, owner, color);
        if (r == ShowBoard.OK) setDirty();
        return r;
    }

    public int unlike(UUID voter, UUID owner, String color) {
        int r = board.unlike(voter, owner, color);
        if (r == ShowBoard.OK) setDirty();
        return r;
    }

    public static ShowData load(CompoundTag tag, HolderLookup.Provider registries) {
        ShowData d = new ShowData();
        ListTag pets = tag.getList("pets", Tag.TAG_COMPOUND);
        for (int i = 0; i < pets.size(); i++) {
            CompoundTag c = pets.getCompound(i);
            try {
                Set<UUID> likes = new LinkedHashSet<>();
                ListTag l = c.getList("likes", Tag.TAG_STRING);
                for (int k = 0; k < l.size(); k++) {
                    try { likes.add(UUID.fromString(l.getString(k))); } catch (IllegalArgumentException ignored) { }
                }
                d.board.restore(UUID.fromString(c.getString("owner")), c.getString("name"), c.getString("color"),
                        c.getInt("stage"), c.getInt("trait"), c.getInt("age"), c.getString("head"), c.getString("body"),
                        c.getLong("since"), likes);
            } catch (IllegalArgumentException ignored) {
            }
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag pets = new ListTag();
        for (ShowBoard.Pet p : board.all()) {
            CompoundTag c = new CompoundTag();
            c.putString("owner", p.owner.toString());
            c.putString("name", p.ownerName);
            c.putString("color", p.color);
            c.putInt("stage", p.stage);
            c.putInt("trait", p.trait);
            c.putInt("age", p.ageMin);
            c.putString("head", p.head);
            c.putString("body", p.body);
            c.putLong("since", p.since);
            ListTag likes = new ListTag();
            for (UUID u : p.likes) likes.add(StringTag.valueOf(u.toString()));
            c.put("likes", likes);
            pets.add(c);
        }
        tag.put("pets", pets);
        return tag;
    }
}
