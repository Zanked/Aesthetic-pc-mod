package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Tamagotchi: every computer color has its own pet. Feed it, play with it, let it sleep, pet it.
 * The pet is saved to cutemod_pet_&lt;color&gt;.txt and slowly gets hungry even while you are away.
 */
public class PetApp extends App {
    private static final int CX = 150, CY = 96, FLOOR = 124, BTN_Y = 146, BTN_W = 90, BTN_H = 16;
    private static final int[] BTN_X = {6, 105, 204};
    private static final int DARK = 0xFF3A2A3A;

    // treats bought in the shop: {food, fun, energy} given by each one
    private static final String[] TREATS = {"treat_cookie", "treat_fish", "treat_honey", "treat_milk", "treat_cake", "treat_medicine"};
    private static final int[][] EFFECT = {{30, 5, 0}, {50, 0, 0}, {20, 30, 0}, {0, 0, 50}, {40, 40, 0}, {0, 0, 0}};
    private static final int SLOT_W = 28, SLOT_H = 13, SLOT_X = W - 6 * 28 - 4, SLOT_Y = 129;

    private double food = 70, fun = 70, energy = 80;
    private boolean sleeping, loaded;
    private long ageSec;
    private double ageAcc;
    private int ticks, jump, shake, saveTimer, msgTimer;
    // how the player treats the pet: these decide its character (saved with the pet)
    private int cFeed, cPlay, cSleep, cPet;
    private double happyAcc;    // seconds spent really happy; every 5 minutes the pet writes a letter
    private int lastStage;
    private static final int GIFTS = 4, GIFT_SEC = 300;
    // illness: a pet that is neglected (or left alone for 2+ hours) falls sick and only a bought medicine cures it
    private boolean sick, lonelySick;
    private double neglect;     // seconds spent in a really bad state
    private static final int NEGLECT_SEC = 90;
    private static final int GB_X = 12, GB_Y = 58, GB_W = 50, GB_H = 13;
    // mini-game "where is the treat?": 3 cups, 3 rounds, the pet hides the treat
    // gm: 0 off, 1 treat shown, 2 cups come down, 3 shuffle, 4 you pick, 5 reveal, 6 result
    private int gm, gmTimer, gmRound, gmWins, gmTreat, gmPicked = -1, gmSwapsLeft, gmSwapT, gmSwapDur, gmA, gmB, gmCoins;
    private boolean gmPrize;
    // pet mini-games 2 and 3: gmKind 0 cups, 1 catch the treats, 2 copy the pet
    // gm 7 = the game menu, 8 = catch the treats, 9 = copy the pet (6 = result, shared by all three)
    private int gmKind, gmScore;
    private static final int AX = 104, AW = 188, AY = 44, AG = 118;   // play area of the new games, AG = the ground
    private static final int CATCH_TICKS = 1200;                      // 20 seconds
    private final List<double[]> falls = new ArrayList<>();           // x, y, speed, kind (0-3 treats, 4 = bad one)
    private int ctSpawn;
    private static final int ECHO_ROUNDS = 5, PAD_W = 40, PAD_H = 34, PAD_Y = 76;
    private static final int[] PAD_COL = {0xFFF58FB8, 0xFF8FD3FF, 0xFFFFC832, 0xFF8FD39A};
    private static final float[] PAD_PITCH = {0.9F, 1.1F, 1.35F, 1.65F};
    private final int[] seq = new int[ECHO_ROUNDS + 1];
    private int ecRound, ecShow, ecTimer, ecIn, ecPhase, ecLit = -1, ecLitT, ecBad;
    private final int[] gmSlot = {0, 1, 2};
    private static final int[] CUP_X = {122, 172, 222};
    private static final int CUP_W = 38, CUP_H = 30, CUP_Y = 94, GM_ROUNDS = 3, GM_DAILY = 5;
    private static final int[] CUP_COL = {0xFFF58FB8, 0xFF8FD3FF, 0xFFFFC832};
    private String msg = "";
    private final List<double[]> parts = new ArrayList<>(); // x, y, vx, vy, life, type (0 heart, 1 crumb)
    private final Random rnd = new Random();

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        if (!loaded) { loaded = true; load(); lastStage = stage(); if (lonelySick) fallSick(); }
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.pet"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.pet"); }

    @Override
    public Component status() {
        return Component.translatable("cutemod.pet.status2", t("cutemod.pet.name." + shell.color().id), 1 + ageSec / 600,
                t("cutemod.pet.stage." + stage()), sick ? t("cutemod.pet.sick.label") : t("cutemod.pet.trait." + trait()));
    }

    // ---------- growing up and character ----------
    /** 0 baby (first 20 minutes with it), 1 teen (up to an hour), 2 grown-up. */
    private int stage() { return PetArt.stageOf(ageSec); }

    /** 0 foodie, 1 playful, 2 sleepy, 3 cuddly, 4 not decided yet (needs about 12 caring actions). */
    private int trait() { return PetArt.traitOf(cFeed, cPlay, cSleep, cPet); }

    // ---------- save / load ----------
    private String blob() { return "pet_" + shell.color().id; }

    private void load() {
        try {
            String s = Store.read(blob());
            if (s == null) return;
            String[] a = s.trim().split("\\s+");
            food = Double.parseDouble(a[0]);
            fun = Double.parseDouble(a[1]);
            energy = Double.parseDouble(a[2]);
            sleeping = a[3].equals("1");
            ageSec = Long.parseLong(a[4]);
            if (a.length >= 10) {
                cFeed = Integer.parseInt(a[6]);
                cPlay = Integer.parseInt(a[7]);
                cSleep = Integer.parseInt(a[8]);
                cPet = Integer.parseInt(a[9]);
            }
            if (a.length >= 12) {
                sick = a[10].equals("1");
                neglect = Integer.parseInt(a[11]);
            }
            long away = Math.min(7200, Math.max(0, (System.currentTimeMillis() - Long.parseLong(a[5])) / 1000));
            if (sleeping) {
                energy = Math.min(100, energy + away * 0.05);
                food = Math.max(10, food - away * 0.01);
                if (energy >= 100) sleeping = false;
            } else {
                food = Math.max(15, food - away * 0.01);
                fun = Math.max(15, fun - away * 0.008);
                energy = Math.max(20, energy - away * 0.005);
            }
            // left alone for two hours or more: it gets lonely and hungry and falls sick (a sleeping, fed pet is fine)
            lonelySick = !sick && away >= 7200 && !(sleeping && food >= 30);
        } catch (Exception ignored) {
        }
    }

    private void save() {
        try {
            Store.write(blob(), String.format(Locale.ROOT, "%.2f %.2f %.2f %d %d %d %d %d %d %d %d %d",
                    food, fun, energy, sleeping ? 1 : 0, ageSec, System.currentTimeMillis(), cFeed, cPlay, cSleep, cPet,
                    sick ? 1 : 0, (int) neglect));
        } catch (Exception ignored) {
        }
    }

    @Override
    public void close() { gm = 0; if (loaded) save(); }

    // ---------- logic ----------
    private static double clamp(double v) { return Math.max(0, Math.min(100, v)); }

    private static void sound(float pitch) {
        Sfx.ui(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_CHIME.value(), pitch, 0.5F);
    }

    private void say(String key) { msg = t(key); msgTimer = 150; }

    private void burst(int type, int n) {
        for (int i = 0; i < n; i++) {
            double x = petX() - 15 + rnd.nextInt(30);
            if (type == 0) parts.add(new double[]{x, CY - 24, (rnd.nextDouble() - 0.5) * 0.5, -0.5, 55 + rnd.nextInt(20), 0});
            else parts.add(new double[]{x, CY - 44, (rnd.nextDouble() - 0.5) * 0.2, 0.7, 28, 1});
        }
    }

    private void feed() {
        if (sleeping) { say("cutemod.pet.say.zzz"); return; }
        if (food >= 95) { say("cutemod.pet.say.full"); shake = 30; return; }
        food = clamp(food + (sick ? 15 : 25)); // a sick pet eats less
        cFeed++;
        burst(1, 4);
        sound(1.3F);
        Progress.onPet("feed");
    }

    private void play() {
        if (sleeping) { say("cutemod.pet.say.zzz"); return; }
        if (sick) { say("cutemod.pet.say.sick_play"); shake = 30; return; }
        if (energy < 12) { say("cutemod.pet.say.tired"); shake = 30; return; }
        fun = clamp(fun + 25);
        cPlay++;
        energy = clamp(energy - 8);
        food = clamp(food - 4);
        jump = 60;
        burst(0, 3);
        sound(1.7F);
        Progress.onPet("play");
    }

    private void giveTreat(int i) {
        if (sleeping) { say("cutemod.pet.say.zzz"); return; }
        String id = TREATS[i];
        if (Progress.stock(id) <= 0) { say("cutemod.pet.say.no_treat"); shake = 20; return; }
        if (id.equals("treat_medicine")) { medicine(); return; }
        int[] e = EFFECT[i];
        boolean useful = (e[0] > 0 && food < 98) || (e[1] > 0 && fun < 98) || (e[2] > 0 && energy < 98);
        if (!useful) { say("cutemod.pet.say.full"); shake = 30; return; }
        Progress.useTreat(id);
        cFeed++;
        food = clamp(food + e[0]);
        fun = clamp(fun + e[1]);
        energy = clamp(energy + e[2]);
        burst(1, 4);
        burst(0, 2);
        jump = Math.max(jump, 30);
        sound(1.8F);
        say("cutemod.pet.say.yum");
        Progress.bump("treats_used");
        Progress.onPet("feed");
    }

    /** The pet gets sick. The very first time the vet leaves one free dose so nobody is stuck without coins. */
    private void fallSick() {
        if (sick) return;
        sick = true;
        lonelySick = false;
        neglect = 0;
        Progress.bump("pet_sick");
        boolean free = Progress.count("pet_free_med") == 0;
        if (free) {
            Progress.setCount("pet_free_med", 1);
            Progress.setCount("stock_treat_medicine", Progress.stock("treat_medicine") + 1);
        }
        say(free ? "cutemod.pet.say.fell_sick_free" : "cutemod.pet.say.fell_sick");
        shake = 40;
        sound(0.5F);
    }

    private void medicine() {
        if (!sick) { say("cutemod.pet.say.healthy"); shake = 20; return; } // not used up
        Progress.useTreat("treat_medicine");
        sick = false;
        neglect = 0;
        fun = Math.max(fun, 40);
        burst(0, 6);
        jump = 50;
        sound(1.9F);
        say("cutemod.pet.say.cured");
        Progress.bump("pet_cured");
    }

    /** A small (10 x 10) picture of a treat; also used by the shop. */
    public static void drawTreat(GuiGraphics g, String id, int x, int y) {
        switch (id) {
            case "treat_cookie" -> {
                disc(g, x + 5, y + 5, 5, 0xFFC98B5A);
                rect(g, x + 3, y + 3, 2, 2, 0xFF5A3A28);
                rect(g, x + 6, y + 5, 2, 2, 0xFF5A3A28);
                rect(g, x + 4, y + 7, 1, 1, 0xFF5A3A28);
            }
            case "treat_fish" -> {
                rect(g, x + 1, y + 3, 6, 4, 0xFF8FD3FF);
                rect(g, x + 7, y + 2, 2, 6, 0xFF8FD3FF);
                rect(g, x + 2, y + 4, 1, 1, 0xFF1A1A22);
            }
            case "treat_honey" -> {
                rect(g, x + 2, y + 3, 6, 7, 0xFFFFC832);
                rect(g, x + 2, y + 1, 6, 2, 0xFFC98B5A);
                rect(g, x + 3, y + 4, 1, 4, 0xFFFFE680);
            }
            case "treat_medicine" -> {
                rect(g, x + 2, y + 3, 6, 7, 0xFFFFFFFF);
                rect(g, x + 3, y + 1, 4, 2, 0xFFE5484D);
                rect(g, x + 4, y + 5, 2, 4, 0xFFE5484D);
                rect(g, x + 3, y + 6, 4, 2, 0xFFE5484D);
            }
            case "treat_milk" -> {
                rect(g, x + 3, y + 3, 4, 7, 0xFFFFFFFF);
                rect(g, x + 4, y + 1, 2, 2, 0xFFD8CCE2);
                rect(g, x + 3, y + 6, 4, 2, 0xFF8FD3FF);
            }
            default -> { // cake
                rect(g, x + 1, y + 5, 8, 5, 0xFFFFB3CF);
                rect(g, x + 1, y + 4, 8, 2, 0xFFFFFFFF);
                disc(g, x + 5, y + 3, 2, 0xFFE5484D);
            }
        }
    }

    private void toggleSleep() {
        sleeping = !sleeping;
        if (sleeping) cSleep++;
        sound(sleeping ? 0.6F : 1.4F);
    }

    private void pet() {
        fun = clamp(fun + 1.5);
        cPet++;
        jump = Math.max(jump, 15);
        burst(0, 1);
        sound(1.5F);
        Progress.onPet("pet");
        if (sleeping) { sleeping = false; say("cutemod.pet.say.pet"); }
    }

    @Override
    public void tick() {
        ticks++;
        if (gm != 0) { if (sick || sleeping) gm = 0; else gameTick(); }
        if (jump > 0) jump--;
        if (shake > 0) shake--;
        if (msgTimer > 0) msgTimer--;
        double dt = 1 / 60.0;
        if (sleeping) {
            energy += (sick ? 0.2 : 0.4) * dt;
            food -= 0.02 * dt;
            if (energy >= 100) { sleeping = false; say("cutemod.pet.say.rested"); }
        } else {
            food -= 0.05 * dt;
            fun -= (sick ? 0.08 : 0.04) * dt;
            energy -= (sick ? 0.05 : 0.03) * dt;
        }
        food = clamp(food); fun = clamp(fun); energy = clamp(energy);
        boolean critical = !sleeping && !sick && (food < 12 || fun < 8 || energy < 8);
        if (critical) { neglect += dt; if (neglect >= NEGLECT_SEC) fallSick(); }
        else if (neglect > 0) neglect = Math.max(0, neglect - dt * 2);
        ageAcc += dt;
        if (ageAcc >= 1) { ageAcc -= 1; ageSec++; }
        int st = stage();
        if (st > lastStage) { // it grew up
            lastStage = st;
            say("cutemod.pet.say.grow." + st);
            burst(0, 8);
            jump = 60;
            sound(1.9F);
        }
        if (!sleeping && mood() == 2 && Progress.count("pet_gifts") < GIFTS) {
            happyAcc += dt;
            if (happyAcc >= GIFT_SEC) { // a happy pet writes you a letter (it lands in the Mail app)
                happyAcc = 0;
                Progress.bump("pet_gifts");
                say("cutemod.pet.say.gift");
                burst(0, 6);
                sound(1.6F);
            }
        }
        for (int i = parts.size() - 1; i >= 0; i--) {
            double[] p = parts.get(i);
            p[0] += p[2];
            p[1] += p[3];
            if (p[5] == 1) p[3] += 0.03;
            if (--p[4] <= 0) parts.remove(i);
        }
        if (++saveTimer > 1800) { saveTimer = 0; save(); } // every 30 s
    }

    private int mood() {
        if (sick) return 0;
        double m = (food + fun + energy) / 3;
        return (food < 20 || m < 35) ? 0 : m >= 65 ? 2 : 1;
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        int body = shell.color().bodyColor;

        // room
        g.fillGradient(0, 0, W, FLOOR - 14, mix(body, 0xFFFFFF, 0.75f), mix(body, 0xFFFFFF, 0.5f));
        rect(g, 0, FLOOR - 14, W, H - FLOOR + 14, 0xFFD9B98A);
        for (int x = 0; x < W; x += 30) rect(g, x, FLOOR - 14, 1, H - FLOOR + 14, 0xFFC9A678);
        rect(g, 0, FLOOR - 14, W, 2, 0xFFB98F5E);
        // window
        rect(g, 14, 12, 46, 40, 0xFF8A6A4A);
        rect(g, 17, 15, 40, 34, sleeping ? 0xFF1B2A5A : 0xFF9AD8FF);
        rect(g, 36, 15, 2, 34, 0xFF8A6A4A);
        rect(g, 17, 31, 40, 2, 0xFF8A6A4A);
        if (sleeping) { disc(g, 46, 24, 5, 0xFFFFF3B0); rect(g, 24, 20, 1, 1, 0xFFFFFFFF); rect(g, 28, 40, 1, 1, 0xFFFFFFFF); }
        else { disc(g, 26, 22, 5, 0xFFFFE066); }

        // stats
        stat(g, 8, "cutemod.pet.food", food);
        stat(g, 20, "cutemod.pet.fun", fun);
        stat(g, 32, "cutemod.pet.energy", energy);
        if (gm == 0) { // the "Game" button under the window
            boolean gh = in(mx, my, GB_X, GB_Y, GB_W, GB_H);
            rect(g, GB_X, GB_Y, GB_W, GB_H, gh ? 0xFFFFFFFF : 0xFFF6F0FA);
            rect(g, GB_X, GB_Y + GB_H - 2, GB_W, 2, 0xFFB9A8C8);
            String gl = t("cutemod.pet.game.btn");
            g.drawString(f, gl, GB_X + (GB_W - f.width(gl)) / 2, GB_Y + 3, DARK, false);
        }

        // pet
        int mood = mood();
        double bob = sleeping ? Math.sin(ticks / 40.0) * 1.0 : Math.sin(ticks / 20.0) * 1.5;
        double hop = jump > 0 ? Math.abs(Math.sin(jump * 0.2)) * 14 : 0;
        int px = petX() + (shake > 0 ? (int) Math.round(Math.sin(shake * 1.2) * 3) : 0);
        int py = CY + (int) Math.round(bob - hop);
        int sw = (int) (24 - hop / 2); // shadow shrinks while jumping
        rect(g, petX() - sw, FLOOR, sw * 2, 3, 0x33000000);
        rect(g, petX() - sw + 3, FLOOR + 3, sw * 2 - 6, 1, 0x22000000);
        float sc = PetArt.scaleOf(stage()); // babies are small
        g.pose().pushPose();
        g.pose().translate(px, FLOOR, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-px, -FLOOR, 0);
        drawPet(g, px, py, mood);
        g.pose().popPose();

        if (sleeping) {
            rect(g, 0, 0, W, FLOOR + 10, 0x66102040);
            for (int i = 0; i < 3; i++) {
                int zt = (ticks / 25 + i) % 3;
                g.drawString(f, "z", petX() + 20 + zt * 7, py - 26 - zt * 7 - i * 0, 0xFFFFFFFF, false);
            }
        }

        // particles
        for (double[] p : parts) {
            int x = (int) p[0], y = (int) p[1];
            if (p[5] == 0) { // heart
                rect(g, x, y + 1, 5, 2, 0xFFFF5C93);
                rect(g, x + 1, y, 1, 1, 0xFFFF5C93);
                rect(g, x + 3, y, 1, 1, 0xFFFF5C93);
                rect(g, x + 1, y + 3, 3, 1, 0xFFFF5C93);
                rect(g, x + 2, y + 4, 1, 1, 0xFFFF5C93);
            } else {
                rect(g, x, y, 3, 3, 0xFFC98B5A);
            }
        }

        // speech bubble
        String say = bubbleText();
        if (!say.isEmpty()) {
            int w = f.width(say) + 10, bx = petX() - w / 2, by = CY - 62;
            rect(g, bx - 1, by - 1, w + 2, 15, 0xFF3A2A3A);
            rect(g, bx, by, w, 13, 0xFFFFFFFF);
            rect(g, petX() - 2, by + 13, 4, 1, 0xFFFFFFFF);
            rect(g, petX() - 1, by + 14, 2, 2, 0xFF3A2A3A);
            g.drawString(f, say, bx + 5, by + 3, DARK, false);
        }

        // illness banner
        if (sick) {
            String b = t(Progress.stock("treat_medicine") > 0 ? "cutemod.pet.sick.banner.have" : "cutemod.pet.sick.banner.buy");
            rect(g, 0, 0, W, 9, (ticks / 20) % 2 == 0 ? 0xDDB03030 : 0xDD8A2020);
            g.drawString(f, b, (W - f.width(b)) / 2, 1, 0xFFFFFFFF, false);
        }

        if (gm != 0) { renderGame(g, f, mx, my); return; }

        // treats from the shop: click one to give it to the pet
        String tip = null;
        for (int i = 0; i < TREATS.length; i++) {
            int sx = SLOT_X + i * SLOT_W, have = Progress.stock(TREATS[i]);
            boolean hover = in(mx, my, sx, SLOT_Y, SLOT_W - 2, SLOT_H);
            if (sick && i == TREATS.length - 1 && have > 0 && (ticks / 15) % 2 == 0) rect(g, sx - 1, SLOT_Y - 1, SLOT_W, SLOT_H + 2, 0xFFE5484D);
            rect(g, sx, SLOT_Y, SLOT_W - 2, SLOT_H, hover ? 0xFFFFFFFF : 0xFFFFF0C0);
            drawTreat(g, TREATS[i], sx + 1, SLOT_Y + 2);
            if (have == 0) rect(g, sx, SLOT_Y, SLOT_W - 2, SLOT_H, 0x99D8CCE2);
            g.drawString(f, Integer.toString(have), sx + 13, SLOT_Y + 3, have > 0 ? DARK : 0xFF8A7AA8, false);
            if (hover) tip = t("cutemod.shop.item." + TREATS[i]);
        }
        if (tip != null) g.drawString(f, tip, W - 6 - f.width(tip), SLOT_Y - 11, DARK, false);

        // buttons
        rect(g, 0, BTN_Y - 4, W, H - BTN_Y + 4, mix(body, 0x000000, 0.35f));
        String[] labels = {t("cutemod.pet.feed"), t("cutemod.pet.play"), t(sleeping ? "cutemod.pet.wake" : "cutemod.pet.sleep")};
        for (int i = 0; i < 3; i++) {
            boolean hover = in(mx, my, BTN_X[i], BTN_Y, BTN_W, BTN_H);
            rect(g, BTN_X[i], BTN_Y, BTN_W, BTN_H, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
            rect(g, BTN_X[i], BTN_Y + BTN_H - 2, BTN_W, 2, 0xFFB9A8C8);
            g.drawString(f, labels[i], BTN_X[i] + (BTN_W - f.width(labels[i])) / 2, BTN_Y + 4, DARK, false);
        }
    }

    private String bubbleText() {
        if (msgTimer > 0) return msg;
        if (sleeping) return "";
        if (sick) return t("cutemod.pet.say.sick");
        if (food < 25) return t("cutemod.pet.say.hungry");
        if (energy < 25) return t("cutemod.pet.say.sleepy");
        if (fun < 25) return t("cutemod.pet.say.bored");
        if (mood() == 2) {
            int cyc = (ticks / 300) % 3;
            if (cyc == 0) return t("cutemod.pet.say.happy");
            if (cyc == 1 && trait() < 4) return t("cutemod.pet.say.trait." + trait());
        }
        return "";
    }

    private void stat(GuiGraphics g, int y, String key, double value) {
        String s = t(key);
        g.drawString(font(), s, 226 - font().width(s), y, 0xFFFFFFFF, true);
        rect(g, 230, y, 62, 8, 0x99000000);
        int col = value > 50 ? 0xFF5BBF6A : value > 25 ? 0xFFF5C518 : 0xFFE5484D;
        rect(g, 231, y + 1, (int) (60 * value / 100), 6, col);
    }

    // ---------- pet sprites ----------
    private void drawPet(GuiGraphics g, int cx, int cy, int mood) {
        PetArt.draw(g, shell.color(), cx, cy, mood, ticks, sleeping, sick, stage(), Progress.equipped(), Progress.equippedBody());
    }

    // ---------- mini-game: where is the treat? ----------
    private int petX() { return gm != 0 ? 62 : CX; }

    private void startGame() {
        if (sleeping) { say("cutemod.pet.say.zzz"); return; }
        if (sick) { say("cutemod.pet.say.sick_play"); shake = 30; return; }
        if (energy < 15) { say("cutemod.pet.say.tired"); shake = 30; return; }
        gm = 7; // the game menu
    }

    private void startCups() {
        gmKind = 0;
        gmRound = 0;
        gmWins = 0;
        nextRound();
    }

    private void startCatch() {
        gmKind = 1;
        gmScore = 0;
        gmWins = 0;
        gmTimer = CATCH_TICKS;
        ctSpawn = 20;
        falls.clear();
        gm = 8;
    }

    private void startEcho() {
        gmKind = 2;
        gmScore = 0;
        gmWins = 0;
        for (int i = 0; i < seq.length; i++) seq[i] = rnd.nextInt(4);
        ecRound = 0;
        nextEchoRound();
        gm = 9;
    }

    private void nextEchoRound() {
        ecRound++;
        ecShow = 0;
        ecTimer = 40;
        ecPhase = 0;
        ecLit = -1;
        ecIn = 0;
    }

    private void nextRound() {
        gmRound++;
        gmTreat = rnd.nextInt(3);
        for (int i = 0; i < 3; i++) gmSlot[i] = i;
        gmPicked = -1;
        gm = 1;
        gmTimer = 100;                       // the treat is shown
        gmSwapsLeft = 5 + gmRound * 3;       // more and faster swaps every round
        gmSwapDur = Math.max(9, 24 - gmRound * 6);
        gmSwapT = 0;
    }

    private void pickSwap() {
        gmA = rnd.nextInt(3);
        do { gmB = rnd.nextInt(3); } while (gmB == gmA);
        gmSwapT = 0;
    }

    private void gameTick() {
        switch (gm) {
            case 1 -> { if (--gmTimer <= 0) { gm = 2; gmTimer = 20; } }
            case 2 -> { if (--gmTimer <= 0) { gm = 3; pickSwap(); } }
            case 3 -> {
                if (++gmSwapT >= gmSwapDur) {
                    int t = gmSlot[gmA]; gmSlot[gmA] = gmSlot[gmB]; gmSlot[gmB] = t;
                    if (--gmSwapsLeft <= 0) gm = 4; else pickSwap();
                }
            }
            case 5 -> { if (--gmTimer <= 0) { if (gmRound >= GM_ROUNDS) finishGame(); else nextRound(); } }
            case 6 -> { if (--gmTimer <= 0) gm = 0; }
            case 8 -> catchTick();
            case 9 -> echoTick();
            default -> { }
        }
    }

    private void pickCup(int c) {
        gmPicked = c;
        if (c == gmTreat) {
            gmWins++;
            jump = 60;
            burst(0, 5);
            sound(1.8F);
            say("cutemod.pet.say.game_win");
        } else {
            shake = 30;
            sound(0.7F);
            say("cutemod.pet.say.game_lose");
        }
        gm = 5;
        gmTimer = 70;
    }

    /** Prizes: 2 coins per found treat, +4 for all three; at most 5 prized games a day (it is play, not a job). */
    private void finishGame() {
        int today = (int) (System.currentTimeMillis() / 86_400_000L);
        if (Progress.count("pg_day") != today) { Progress.setCount("pg_day", today); Progress.setCount("pg_n", 0); }
        int n = Progress.count("pg_n");
        gmPrize = n < GM_DAILY;
        Progress.setCount("pg_n", n + 1);
        gmCoins = gmPrize ? gmWins * 2 + (gmWins == GM_ROUNDS ? 4 : 0) : 0;
        if (gmCoins > 0) Progress.earn(gmCoins);
        Progress.bump("pet_games");
        if (gmWins == GM_ROUNDS) Progress.bump("pet_perfect");
        fun = clamp(fun + 15 + gmWins * 5);
        energy = clamp(energy - 10);
        food = clamp(food - 3);
        if (gmWins > 0) { jump = 60; burst(0, 4); }
        gm = 6;
        gmTimer = 160;
    }

    private void gameClick(int x, int y) {
        if (in(x, y, 105, BTN_Y, BTN_W, BTN_H)) { gm = 0; return; } // quit / ok
        if (gm == 7) {
            for (int i = 0; i < 3; i++) {
                if (in(x, y, AX + 4, 50 + i * 28, AW - 8, 24)) {
                    if (i == 0) startCups(); else if (i == 1) startCatch(); else startEcho();
                    return;
                }
            }
            return;
        }
        if (gm == 8) { catchClick(x, y); return; }
        if (gm == 9) { echoClick(x, y); return; }
        if (gm == 4) {
            for (int c = 0; c < 3; c++) {
                if (in(x, y, CUP_X[gmSlot[c]], CUP_Y - 4, CUP_W, CUP_H + 4)) { pickCup(c); return; }
            }
        }
    }

    private int cupLift(int c) {
        return switch (gm) {
            case 1 -> c == gmTreat ? 22 : 0;
            case 2 -> c == gmTreat ? 22 * gmTimer / 20 : 0;
            case 5, 6 -> 22;
            default -> 0;
        };
    }

    // ---------- mini-game 2: catch the treats ----------
    private void catchTick() {
        int elapsed = CATCH_TICKS - gmTimer;
        if (--gmTimer <= 0) { endRun(catchStars()); return; }
        if (--ctSpawn <= 0) {
            ctSpawn = 36 - elapsed * 14 / CATCH_TICKS;
            boolean bad = rnd.nextInt(5) == 0;
            falls.add(new double[]{AX + 8 + rnd.nextInt(AW - 26), AY,
                    0.45 + elapsed * 0.5 / CATCH_TICKS + rnd.nextDouble() * 0.2, bad ? 4 : rnd.nextInt(4)});
        }
        for (int i = falls.size() - 1; i >= 0; i--) {
            double[] p = falls.get(i);
            p[1] += p[2];
            if (p[1] >= AG - 10) falls.remove(i);
        }
    }

    private int catchStars() { return gmScore >= 18 ? 3 : gmScore >= 11 ? 2 : gmScore >= 5 ? 1 : 0; }

    private void catchClick(int x, int y) {
        for (int i = falls.size() - 1; i >= 0; i--) {
            double[] p = falls.get(i);
            if (!in(x, y, (int) p[0] - 3, (int) p[1] - 3, 16, 16)) continue;
            falls.remove(i);
            if (p[3] == 4) { gmScore = Math.max(0, gmScore - 2); shake = 20; sound(0.6F); }
            else { gmScore++; jump = Math.max(jump, 10); sound(1.3F + Math.min(gmScore, 20) * 0.03F); }
            return;
        }
    }

    private void renderCatch(GuiGraphics g, Font f, int mx, int my, int mid) {
        String head = t("cutemod.pet.game.catch_head", gmScore, Math.max(0, (gmTimer + 59) / 60));
        g.drawString(f, head, mid - f.width(head) / 2, 34, DARK, false);
        rect(g, AX, AY - 2, AW, AG - AY + 2, 0x33FFFFFF);
        rect(g, AX, AG, AW, 2, 0xFFB98F5E);
        for (double[] p : falls) {
            int x = (int) p[0], y = (int) p[1];
            if (p[3] == 4) { // a bad one: a green blob with a grumpy face
                disc(g, x + 5, y + 5, 6, 0xFF6A8A3A);
                rect(g, x + 2, y + 3, 2, 2, 0xFF2A1A2A); rect(g, x + 7, y + 3, 2, 2, 0xFF2A1A2A);
                rect(g, x + 3, y + 8, 5, 1, 0xFF2A1A2A);
            } else {
                drawTreat(g, TREATS[(int) p[3]], x, y);
            }
        }
        String hint = t("cutemod.pet.game.catch_hint");
        g.drawString(f, hint, mid - f.width(hint) / 2, FLOOR + 5, DARK, false);
    }

    // ---------- mini-game 3: copy the pet (like Simon) ----------
    private static int padX(int p) { return AX + p * (PAD_W + 8); }

    private void light(int p, int dur) {
        ecLit = p;
        ecLitT = dur;
        sound(PAD_PITCH[p]);
    }

    private void echoTick() {
        if (ecLitT > 0 && --ecLitT == 0) ecLit = -1;
        switch (ecPhase) {
            case 0 -> { // the pet shows the pads one by one
                if (--ecTimer > 0) return;
                if (ecShow >= ecRound + 1) { ecPhase = 1; ecIn = 0; return; }
                light(seq[ecShow++], 24);
                ecTimer = 36;
            }
            case 2 -> { if (--ecTimer <= 0) nextEchoRound(); }          // right: the next round
            case 3 -> { if (--ecTimer <= 0) endRun(echoStars()); }      // wrong: the game ends
            default -> { }
        }
    }

    private int echoStars() { return gmScore >= 5 ? 3 : gmScore >= 3 ? 2 : gmScore >= 1 ? 1 : 0; }

    private void echoClick(int x, int y) {
        if (ecPhase != 1) return;
        for (int p = 0; p < 4; p++) {
            if (!in(x, y, padX(p), PAD_Y, PAD_W, PAD_H)) continue;
            light(p, 12);
            if (p == seq[ecIn]) {
                if (++ecIn >= ecRound + 1) {
                    gmScore++;
                    jump = Math.max(jump, 12);
                    if (ecRound >= ECHO_ROUNDS) { endRun(echoStars()); return; }
                    ecPhase = 2;
                    ecTimer = 45;
                }
            } else {
                ecPhase = 3;
                ecTimer = 45;
                ecBad = p;
                shake = 20;
            }
            return;
        }
    }

    private void renderEcho(GuiGraphics g, Font f, int mx, int my, int mid) {
        String head = t("cutemod.pet.game.echo_head", Math.min(ecRound, ECHO_ROUNDS), ECHO_ROUNDS);
        g.drawString(f, head, mid - f.width(head) / 2, 56, DARK, false);
        for (int p = 0; p < 4; p++) {
            int x = padX(p), col = PAD_COL[p];
            boolean lit = ecLit == p, hover = ecPhase == 1 && in(mx, my, x, PAD_Y, PAD_W, PAD_H);
            if (lit) rect(g, x - 2, PAD_Y - 2, PAD_W + 4, PAD_H + 4, 0xFFFFFFFF);
            rect(g, x, PAD_Y, PAD_W, PAD_H, lit ? mix(col, 0xFFFFFF, 0.55f) : hover ? col : mix(col, 0x000000, 0.2f));
            rect(g, x + 3, PAD_Y + 3, PAD_W - 6, 3, 0x55FFFFFF);
            if (ecPhase == 3 && ecBad == p) rect(g, x, PAD_Y + PAD_H, PAD_W, 3, 0xFFE5484D);
        }
        String hint = ecPhase == 0 ? t("cutemod.pet.game.echo_watch") : ecPhase == 1 ? t("cutemod.pet.game.echo_go") : "";
        if (!hint.isEmpty()) g.drawString(f, hint, mid - f.width(hint) / 2, FLOOR + 5, DARK, false);
    }

    /** A new game ended: 0-3 stars, the same prizes as the cups (2 coins per star, +4 for 3 stars). */
    private void endRun(int stars) {
        gmWins = stars;
        finishGame();
    }

    private void renderMenu(GuiGraphics g, Font f, int mx, int my) {
        String h = t("cutemod.pet.game.menu");
        g.drawString(f, h, AX + AW / 2 - f.width(h) / 2, 38, DARK, false);
        for (int i = 0; i < 3; i++) {
            int y = 50 + i * 28;
            boolean hover = in(mx, my, AX + 4, y, AW - 8, 24);
            rect(g, AX + 4, y, AW - 8, 24, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
            rect(g, AX + 4, y + 22, AW - 8, 2, 0xFFB9A8C8);
            String n = t("cutemod.pet.game.m" + i);
            g.drawString(f, n, AX + AW / 2 - f.width(n) / 2, y + 8, DARK, false);
        }
    }

    private void gameBar(GuiGraphics g, Font f, int mx, int my) {
        rect(g, 0, BTN_Y - 4, W, H - BTN_Y + 4, mix(shell.color().bodyColor, 0x000000, 0.35f));
        boolean hover = in(mx, my, 105, BTN_Y, BTN_W, BTN_H);
        rect(g, 105, BTN_Y, BTN_W, BTN_H, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
        rect(g, 105, BTN_Y + BTN_H - 2, BTN_W, 2, 0xFFB9A8C8);
        String label = t(gm == 6 ? "cutemod.pet.game.ok" : "cutemod.pet.game.quit");
        g.drawString(f, label, 105 + (BTN_W - f.width(label)) / 2, BTN_Y + 4, DARK, false);
    }

    private void renderGame(GuiGraphics g, Font f, int mx, int my) {
        int mid = (CUP_X[0] + CUP_X[2] + CUP_W) / 2;
        if (gm == 7) { renderMenu(g, f, mx, my); gameBar(g, f, mx, my); return; }
        if (gmKind != 0) {
            if (gm == 8) renderCatch(g, f, mx, my, mid);
            else if (gm == 9) renderEcho(g, f, mx, my, mid);
        } else {
        String head = t("cutemod.pet.game.round", Math.min(gmRound, GM_ROUNDS), GM_ROUNDS, gmWins);
        g.drawString(f, head, mid - f.width(head) / 2, 56, DARK, false);
        // cups (the treat sits under the right one)
        for (int c = 0; c < 3; c++) {
            double cx = CUP_X[gmSlot[c]], dy = 0;
            if (gm == 3 && (c == gmA || c == gmB)) {
                double u = gmSwapT / (double) gmSwapDur;
                int other = c == gmA ? gmB : gmA;
                cx = CUP_X[gmSlot[c]] + (CUP_X[gmSlot[other]] - CUP_X[gmSlot[c]]) * u;
                dy = (c == gmA ? -1 : 1) * Math.sin(Math.PI * u) * 7;
            }
            int x = (int) Math.round(cx), lift = cupLift(c), y = CUP_Y + (int) Math.round(dy) - lift;
            if (lift > 0 && c == gmTreat) drawTreat(g, "treat_cookie", x + CUP_W / 2 - 5, CUP_Y + CUP_H - 12);
            boolean hover = gm == 4 && in(mx, my, x, CUP_Y - 4, CUP_W, CUP_H + 4);
            int col = CUP_COL[c];
            rect(g, x - 2, y, CUP_W + 4, 5, mix(col, 0x000000, 0.2f));
            rect(g, x, y + 5, CUP_W, CUP_H - 5, hover ? mix(col, 0xFFFFFF, 0.4f) : col);
            rect(g, x + 4, y + 8, 4, CUP_H - 12, 0x55FFFFFF);
            if (gm >= 5 && c == gmPicked) rect(g, x, y + CUP_H, CUP_W, 2, c == gmTreat ? 0xFF5BBF6A : 0xFFE5484D);
        }
        String hint = switch (gm) {
            case 1 -> t("cutemod.pet.game.watch");
            case 2, 3 -> t("cutemod.pet.game.shuffle");
            case 4 -> t("cutemod.pet.game.pick");
            default -> "";
        };
        if (!hint.isEmpty()) g.drawString(f, hint, mid - f.width(hint) / 2, FLOOR + 5, DARK, false);
        }
        if (gm == 6) {
            String l1 = gmKind == 0 ? t("cutemod.pet.game.found", gmWins, GM_ROUNDS)
                    : t(gmKind == 1 ? "cutemod.pet.game.res.catch" : "cutemod.pet.game.res.echo", gmScore);
            String l2 = gmCoins > 0 ? t("cutemod.pet.game.coins", gmCoins)
                    : t(gmPrize ? "cutemod.pet.game.noprize" : "cutemod.pet.game.limit");
            int w = Math.max(f.width(l1), f.width(l2)) + 14, bx = mid - w / 2;
            rect(g, bx - 1, 41, w + 2, 25, 0xFF3A2A3A);
            rect(g, bx, 42, w, 23, 0xFFFFFFFF);
            g.drawString(f, l1, mid - f.width(l1) / 2, 46, DARK, false);
            g.drawString(f, l2, mid - f.width(l2) / 2, 56, gmCoins > 0 ? 0xFFB98A10 : 0xFF8A7AA8, false);
        }
        gameBar(g, f, mx, my);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (gm != 0) { gameClick(x, y); return true; }
        if (in(x, y, GB_X, GB_Y, GB_W, GB_H)) { startGame(); return true; }
        for (int i = 0; i < TREATS.length; i++) {
            if (in(x, y, SLOT_X + i * SLOT_W, SLOT_Y, SLOT_W - 2, SLOT_H)) { giveTreat(i); return true; }
        }
        for (int i = 0; i < 3; i++) {
            if (in(x, y, BTN_X[i], BTN_Y, BTN_W, BTN_H)) {
                switch (i) {
                    case 0 -> feed();
                    case 1 -> play();
                    default -> toggleSleep();
                }
                return true;
            }
        }
        if (in(x, y, CX - 30, CY - 36, 60, 62)) { pet(); return true; }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (gm != 0) {
            if (keyCode == 256) { gm = 0; return true; } // escape leaves the game, not the computer
            return false;
        }
        switch (keyCode) {
            case 49 -> feed();          // 1
            case 50 -> play();          // 2
            case 51 -> toggleSleep();   // 3
            default -> { return false; }
        }
        return true;
    }
}
