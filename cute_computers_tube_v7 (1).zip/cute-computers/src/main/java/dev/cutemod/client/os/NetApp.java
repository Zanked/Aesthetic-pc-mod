package dev.cutemod.client.os;

import dev.cutemod.data.ShowBoard;
import dev.cutemod.net.NetSyncPayload;
import dev.cutemod.net.ShowSyncPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * CuteNet, the online mode: the best players of the server in every game, who is at a computer right now and
 * the pet show (everyone's Tamagotchi on display, with likes). The scores and the show live on the server.
 */
public class NetApp extends App {
    private static final int HEAD = 17, LIST_X = 4, LIST_Y = 21, LIST_W = 92, ROW = 12, RIGHT_X = 102;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;
    private static final int[] MEDAL = {0xFFF3C45A, 0xFFC4CAD6, 0xFFD08A4E};
    private static final String[] APPS = {"", "games", "browser", "notes", "paint", "calc", "settings", "music", "pet", "market",
            "quest", "terminal", "store", "jobs", "mail", "net"};

    private int tab;                 // 0 = top players, 1 = online, 2 = pet show
    private int sel;                 // the selected game (index in Library.GAMES)
    private int scroll;
    private int timer = 1000;        // asks at once

    // pet show
    private static final int GRID_X = 4, GRID_Y = 21, FOOT_Y = 149, FOOT_H = 14;
    private int showSort, showPage, ticks, toastT, armed, armT;
    private String toast = "", pending = "";
    private ShowSyncPayload lastSeen;      // the last show answer we have already looked at

    @Override
    public Component title() { return Component.translatable("cutemod.os.net"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.net"); }

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        lastSeen = Show.last();            // an old answer from an earlier visit is not news
        pending = "";
        armed = 0;
        timer = 1000;
    }

    private static String gameId(int i) { return Library.GAMES.get(i).id(); }

    private static int games() { return Library.GAMES.size(); }

    private int visibleRows() { return (H - LIST_Y - 3) / ROW; }

    private void refresh() {
        if (tab == 2) Show.request(showSort, showPage);
        Net.request(tab == 0 ? gameId(sel) : "");
        timer = 0;
    }

    @Override
    public void tick() {
        ticks++;
        if (++timer >= 120) refresh();         // every 2 seconds while the app is open
        if (toastT > 0) toastT--;
        if (armT > 0 && --armT == 0) armed = 0;
        ShowSyncPayload s = Show.last();
        if (s != lastSeen) {
            lastSeen = s;
            if (s != null && s.result() >= 0) onResult(s.result());
        }
        if (tab == 2 && s != null && showPage >= pageCount(s) && showPage > 0) {   // the last page vanished (pets were taken off)
            showPage = pageCount(s) - 1;
            refresh();
        }
    }

    private static int pageCount(ShowSyncPayload s) { return Math.max(1, (s.total() + ShowBoard.PAGE - 1) / ShowBoard.PAGE); }

    private void say(String key) { toast = t(key); toastT = 150; }

    /** The answer of the server to what we did (0 done, 1 too fast, 2 refused, 3 sick, 4 own pet, 5 no such pet). */
    private void onResult(int r) {
        String what = pending;
        pending = "";
        switch (r) {
            case 0 -> { if (what.equals("put")) say("cutemod.show.msg.put"); else if (what.equals("take")) say("cutemod.show.msg.taken"); }
            case 1 -> say("cutemod.show.msg.fast");
            case 3 -> say("cutemod.show.msg.sick");
            case 4 -> say("cutemod.show.msg.own");
            case 5 -> say("cutemod.show.msg.missing");
            default -> say("cutemod.show.msg.refused");
        }
    }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, 0xFFF6F0FA);
        rect(g, 0, 0, W, HEAD, 0xFF5A4A86);
        tabButton(g, f, mx, my, 4, 80, "cutemod.net.tab.top", tab == 0);
        tabButton(g, f, 88, 70, "cutemod.net.tab.online", tab == 1);
        tabButton(g, f, mx, my, 162, 70, "cutemod.net.tab.pets", tab == 2);
        NetSyncPayload s = Net.last();
        if (s != null) {
            Component n = Component.translatable("cutemod.net.count", s.online().size());
            g.drawString(f, n, W - 6 - f.width(n), 5, 0xFFE4D8FF, false);
        }
        if (tab == 0) top(g, f, mx, my, s); else if (tab == 1) online(g, f, s); else pets(g, f, mx, my);
    }

    private void tabButton(GuiGraphics g, Font f, int mx, int my, int x, int w, String key, boolean on) {
        boolean hov = in(mx, my, x, 2, w, 13);
        rect(g, x, 2, w, 13, on ? 0xFFF6F0FA : hov ? 0xFF8A6AC6 : 0xFF6E5CA0);
        Component c = Component.translatable(key);
        g.drawString(f, c, x + (w - f.width(c)) / 2, 5, on ? TEXT : 0xFFFFFFFF, false);
    }

    private void tabButton(GuiGraphics g, Font f, int x, int w, String key, boolean on) {
        tabButton(g, f, -1, -1, x, w, key, on);
    }

    private void top(GuiGraphics g, Font f, int mx, int my, NetSyncPayload s) {
        // the list of games
        int rows = visibleRows();
        scroll = Math.max(0, Math.min(Math.max(0, games() - rows), scroll));
        for (int i = 0; i < rows && i + scroll < games(); i++) {
            int idx = i + scroll, y = LIST_Y + i * ROW;
            boolean on = idx == sel, hov = in(mx, my, LIST_X, y, LIST_W, ROW - 1);
            rect(g, LIST_X, y, LIST_W, ROW - 1, on ? ACCENT : hov ? 0xFFE4D8FF : 0xFFFFFFFF);
            String name = f.plainSubstrByWidth(t("cutemod.game." + gameId(idx)), LIST_W - 6);
            g.drawString(f, name, LIST_X + 3, y + 2, on ? 0xFFFFFFFF : TEXT, false);
        }
        if (games() > rows) {                                          // a thin scroll bar
            int bh = Math.max(8, (H - LIST_Y - 3) * rows / games());
            int by = LIST_Y + (H - LIST_Y - 3 - bh) * scroll / Math.max(1, games() - rows);
            rect(g, LIST_X + LIST_W + 1, by, 2, bh, 0xFFB8A8D8);
        }
        // the ranking of the selected game
        int x = RIGHT_X, w = W - RIGHT_X - 4;
        g.drawString(f, t("cutemod.game." + gameId(sel)), x, LIST_Y + 1, ACCENT, false);
        boolean fresh = s != null && s.game().equals(gameId(sel));
        if (!fresh) {
            g.drawString(f, t("cutemod.net.loading"), x, LIST_Y + 18, MUTED, false);
            return;
        }
        List<dev.cutemod.data.NetData.Row> rowsList = s.top();
        if (rowsList.isEmpty()) {
            g.drawString(f, t("cutemod.net.nobody"), x, LIST_Y + 18, MUTED, false);
        }
        String me = net.minecraft.client.Minecraft.getInstance().getUser().getName();
        for (int i = 0; i < rowsList.size(); i++) {
            var r = rowsList.get(i);
            int y = LIST_Y + 12 + i * 11;
            boolean mine = r.name().equals(me);
            if (mine) rect(g, x - 2, y - 1, w + 2, 11, 0xFFE4D8FF);
            if (i < 3) disc(g, x + 4, y + 4, 4, MEDAL[i]);
            g.drawString(f, Integer.toString(i + 1), x + (i < 3 ? 4 - f.width(Integer.toString(i + 1)) / 2 : 1), y + 1, i < 3 ? 0xFF3A2A3A : MUTED, false);
            g.drawString(f, f.plainSubstrByWidth(r.name(), w - 60), x + 14, y + 1, mine ? ACCENT : TEXT, false);
            String sc = Integer.toString(r.score());
            g.drawString(f, sc, x + w - f.width(sc) - 2, y + 1, TEXT, false);
        }
        Component foot = s.myRank() > 0
                ? Component.translatable("cutemod.net.you", s.myRank(), s.myScore())
                : Component.translatable("cutemod.net.you_none");
        g.drawString(f, foot, x, H - 12, s.myRank() == 1 ? 0xFFC98A00 : MUTED, false);
    }

    private void online(GuiGraphics g, Font f, NetSyncPayload s) {
        if (s == null) { g.drawString(f, t("cutemod.net.loading"), 8, LIST_Y + 4, MUTED, false); return; }
        if (s.online().isEmpty()) { g.drawString(f, t("cutemod.net.nobody_online"), 8, LIST_Y + 4, MUTED, false); return; }
        int y = LIST_Y;
        for (int i = 0; i < s.online().size() && y + 14 <= H - 2; i++) {
            NetSyncPayload.Online o = s.online().get(i);
            rect(g, 4, y, W - 8, 13, 0xFFFFFFFF);
            disc(g, 12, y + 6, 3, 0xFF5BD97A);
            g.drawString(f, f.plainSubstrByWidth(o.name(), 90), 20, y + 3, TEXT, false);
            String what = activity(o);
            g.drawString(f, f.plainSubstrByWidth(what, W - 120), 116, y + 3, MUTED, false);
            y += 14;
        }
    }


    // ---------- the pet show ----------
    private static String myId() {
        var p = Minecraft.getInstance().player;
        return p == null ? "" : p.getUUID().toString();
    }

    private static String ageText(int min) {
        return min < 60 ? t("cutemod.show.age.m", min) : min < 1440 ? t("cutemod.show.age.h", min / 60) : t("cutemod.show.age.d", min / 1440);
    }

    private String myColor() { return shell.color().id; }

    private void pets(GuiGraphics g, Font f, int mx, int my) {
        ShowSyncPayload s = Show.last();
        if (s == null) {
            g.drawString(f, t("cutemod.net.loading"), 8, GRID_Y + 4, MUTED, false);
            return;
        }
        String me = myId();
        int hover = PetShow.cardAt(mx, my, GRID_X, GRID_Y, s.pets().size());
        if (s.pets().isEmpty()) {
            String e = t("cutemod.show.empty");
            g.drawString(f, e, (W - f.width(e)) / 2, GRID_Y + 50, MUTED, false);
        }
        for (int i = 0; i < s.pets().size(); i++) {
            ShowSyncPayload.Entry e = s.pets().get(i);
            int medal = showSort == 0 && s.page() == 0 && i < 3 && e.likes() > 0 ? i : -1;     // the 3 favorites of the show
            PetShow.drawCard(g, f, shell.absX(), shell.absY(), PetShow.cardX(i, GRID_X), PetShow.cardY(i, GRID_Y), card(e, me),
                    medal, i == hover, ticks + i * 37);
        }
        footer(g, f, mx, my, s);
        if (toastT > 0) {                                           // a short notice over the cards
            int w = f.width(toast) + 12, x = (W - w) / 2, y = FOOT_Y - 17;
            rect(g, x, y, w, 13, 0xEE3A2A3A);
            g.drawString(f, toast, x + 6, y + 3, 0xFFFFFFFF, false);
        }
        if (hover >= 0) {                                           // who it is, next to the mouse
            ShowSyncPayload.Entry e = s.pets().get(hover);
            String tip = t("cutemod.show.tip", e.who().name(), t("cutemod.pet.name." + e.who().color()),
                    t("cutemod.pet.trait." + e.look().trait()), t("cutemod.pet.stage." + e.look().stage()), ageText(e.look().ageMin()));
            int w = f.width(tip) + 8, x = Math.max(2, Math.min(mx + 6, W - w - 2)), y = my + 12 < FOOT_Y - 2 ? my + 12 : my - 13;
            rect(g, x, y, w, 12, 0xEE3A2A3A);
            g.drawString(f, tip, x + 4, y + 2, 0xFFFFFFFF, false);
        }
    }

    private static PetShow.Card card(ShowSyncPayload.Entry e, String me) {
        return new PetShow.Card(e.who().name(), e.who().color(), e.look().stage(), e.look().trait(), e.look().head(), e.look().body(),
                e.likes(), e.liked(), e.who().owner().equals(me), ageText(e.look().ageMin()));
    }

    // footer: [Top][New][Old]   <  1/3  >   [Show my pet]  or  [Update][Take off]
    private static final int SORT_X = 4, SORT_W = 38, PREV_X = 134, NEXT_X = 176, ARROW_W = 12, ACT_X = 194;

    private void footer(GuiGraphics g, Font f, int mx, int my, ShowSyncPayload s) {
        rect(g, 0, FOOT_Y - 2, W, H - FOOT_Y + 2, 0xFFF6F0FA);
        for (int i = 0; i < 3; i++) button(g, f, mx, my, SORT_X + i * (SORT_W + 2), SORT_W, t("cutemod.show.sort." + i), showSort == i, 0);
        int pages = pageCount(s);
        button(g, f, mx, my, PREV_X, ARROW_W, "<", false, s.page() > 0 ? 0 : 2);
        button(g, f, mx, my, NEXT_X, ARROW_W, ">", false, s.page() < pages - 1 ? 0 : 2);
        String pg = t("cutemod.show.page", s.page() + 1, pages);
        g.drawString(f, pg, PREV_X + ARROW_W + (NEXT_X - PREV_X - ARROW_W - f.width(pg)) / 2, FOOT_Y + 3, MUTED, false);
        boolean on = s.mine().contains(myColor());
        if (on) {
            button(g, f, mx, my, ACT_X, 50, t("cutemod.show.btn.update"), false, 0);
            button(g, f, mx, my, ACT_X + 52, 50, armed == 2 ? t("cutemod.show.btn.sure") : t("cutemod.show.btn.take"), armed == 2, 0);
        } else if (!s.mine().isEmpty()) {                           // another of my pets is on the show: showing this one replaces it
            button(g, f, mx, my, ACT_X, 102, armed == 1 ? t("cutemod.show.btn.sure") : t("cutemod.show.btn.replace"), armed == 1, 0);
        } else {
            button(g, f, mx, my, ACT_X, 102, t("cutemod.show.btn.put"), false, 1);
        }
    }

    /** style 0 normal, 1 highlighted (the main action), 2 dimmed (cannot be used now). */
    private void button(GuiGraphics g, Font f, int mx, int my, int x, int w, String label, boolean on, int style) {
        boolean hov = style != 2 && in(mx, my, x, FOOT_Y, w, FOOT_H);
        int bg = on ? 0xFFE5486F : style == 1 ? (hov ? 0xFF9A6FD0 : ACCENT) : style == 2 ? 0xFFE9E2F2 : hov ? 0xFFE4D8FF : 0xFFFFFFFF;
        rect(g, x, FOOT_Y, w, FOOT_H, bg);
        rect(g, x, FOOT_Y + FOOT_H - 2, w, 2, on || style == 1 ? 0x33000000 : 0xFFB9A8C8);
        int fg = on || style == 1 ? 0xFFFFFFFF : style == 2 ? 0xFFB8A8D8 : TEXT;
        g.drawString(f, label, x + (w - f.width(label)) / 2, FOOT_Y + 3, fg, false);
    }

    private void showClick(int x, int y) {
        ShowSyncPayload s = Show.last();
        if (s == null) return;
        // the cards: a click likes the pet (or takes the like back)
        int i = PetShow.cardAt(x, y, GRID_X, GRID_Y, s.pets().size());
        if (i >= 0) {
            ShowSyncPayload.Entry e = s.pets().get(i);
            if (e.who().owner().equals(myId())) { say("cutemod.show.msg.own"); return; }
            pending = "like";
            if (e.liked()) Show.unlike(e.who().owner(), e.who().color()); else Show.like(e.who().owner(), e.who().color());
            return;
        }
        if (y < FOOT_Y || y >= FOOT_Y + FOOT_H) return;
        for (int k = 0; k < 3; k++) {
            if (in(x, y, SORT_X + k * (SORT_W + 2), FOOT_Y, SORT_W, FOOT_H)) {
                if (showSort != k) { showSort = k; showPage = 0; refresh(); }
                return;
            }
        }
        if (in(x, y, PREV_X, FOOT_Y, ARROW_W, FOOT_H)) { if (showPage > 0) { showPage--; refresh(); } return; }
        if (in(x, y, NEXT_X, FOOT_Y, ARROW_W, FOOT_H)) { if (showPage < pageCount(s) - 1) { showPage++; refresh(); } return; }
        boolean on = s.mine().contains(myColor());
        if (on) {
            if (in(x, y, ACT_X, FOOT_Y, 50, FOOT_H)) { exhibit(); return; }                          // refresh how it looks
            if (in(x, y, ACT_X + 52, FOOT_Y, 50, FOOT_H)) {                                           // take it off (twice: the likes are lost)
                if (armed != 2) { armed = 2; armT = 180; return; }
                armed = 0;
                pending = "take";
                Show.withdraw(myColor());
            }
        } else if (in(x, y, ACT_X, FOOT_Y, 102, FOOT_H)) {
            if (!s.mine().isEmpty() && armed != 1) { armed = 1; armT = 180; return; }                 // replacing loses the likes of the other pet
            armed = 0;
            exhibit();
        }
    }

    private void exhibit() {
        pending = "put";
        if (!Show.exhibit(myColor())) { pending = ""; say("cutemod.show.msg.nopet"); }
    }

    private static String activity(NetSyncPayload.Online o) {
        if (!o.game().isEmpty()) return t("cutemod.net.playing", t("cutemod.game." + o.game()));
        if (o.app() <= 0 || o.app() >= APPS.length) return t("cutemod.net.desktop");
        return t("cutemod.os." + APPS[o.app()]);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (in(x, y, 4, 2, 80, 13)) { if (tab != 0) { tab = 0; refresh(); } return true; }
        if (in(x, y, 88, 2, 70, 13)) { if (tab != 1) { tab = 1; refresh(); } return true; }
        if (in(x, y, 162, 2, 70, 13)) { if (tab != 2) { tab = 2; refresh(); } return true; }
        if (tab == 2) { showClick(x, y); return true; }
        if (tab == 0) {
            int rows = visibleRows();
            for (int i = 0; i < rows && i + scroll < games(); i++) {
                if (in(x, y, LIST_X, LIST_Y + i * ROW, LIST_W, ROW - 1)) {
                    if (sel != i + scroll) { sel = i + scroll; refresh(); }
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        if (tab == 2) {                                              // the wheel turns the pages of the show
            ShowSyncPayload s = Show.last();
            int next = showPage - (int) Math.signum(amount);
            if (s != null && next >= 0 && next < pageCount(s) && next != showPage) { showPage = next; refresh(); }
            return true;
        }
        if (tab != 0) return false;
        scroll -= (int) Math.signum(amount) * 2;
        return true;
    }
}
