package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/**
 * How the pet show looks: the grid of pet cards (4 columns, 2 rows) and one card. Pure drawing with the strings
 * already translated by the caller (NetApp), so the look can be checked without the rest of the game.
 */
public final class PetShow {
    private PetShow() {}

    public static final int CARD_W = 70, CARD_H = 60, PITCH_X = 74, PITCH_Y = 63, COLS = 4;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;
    private static final int[] MEDAL = {0xFFF3C45A, 0xFFC4CAD6, 0xFFD08A4E};

    /** Everything one card shows. name = the owner, age = short text like "2h". */
    public record Card(String name, String colorId, int stage, int trait, String head, String body,
                       int likes, boolean liked, boolean mine, String age) {}

    public static int cardX(int i, int gridX) { return gridX + (i % COLS) * PITCH_X; }

    public static int cardY(int i, int gridY) { return gridY + (i / COLS) * PITCH_Y; }

    /** The index of the card under the mouse, or -1. */
    public static int cardAt(int mx, int my, int gridX, int gridY, int count) {
        for (int i = 0; i < count; i++) {
            int x = cardX(i, gridX), y = cardY(i, gridY);
            if (mx >= x && my >= y && mx < x + CARD_W && my < y + CARD_H) return i;
        }
        return -1;
    }

    public static ComputerColor colorOf(String id) {
        for (ComputerColor c : ComputerColor.values()) if (c.id.equals(id)) return c;
        return ComputerColor.PINK;
    }

    /**
     * Draw one card at (x, y) of the app area. (ox, oy) is where the app area sits on the screen (the clip is in
     * screen coordinates). medal 0-2 puts a gold / silver / bronze medal on it, -1 none.
     */
    public static void drawCard(GuiGraphics g, Font f, int ox, int oy, int x, int y, Card c, int medal, boolean hover, int ticks) {
        rect(g, x, y, CARD_W, CARD_H, c.mine() ? 0xFFE4D8FF : hover ? 0xFFF0E8FB : 0xFFFFFFFF);
        if (c.mine() || hover) {                                   // a thin frame
            int fr = c.mine() ? ACCENT : 0xFFD0C4E8;
            rect(g, x, y, CARD_W, 1, fr);
            rect(g, x, y + CARD_H - 1, CARD_W, 1, fr);
            rect(g, x, y, 1, CARD_H, fr);
            rect(g, x + CARD_W - 1, y, 1, CARD_H, fr);
        }

        int cx = x + CARD_W / 2, floor = y + 41;
        rect(g, cx - 14, floor, 28, 2, 0x22000000);
        g.enableScissor(ox + x + 1, oy + y + 1, ox + x + CARD_W - 1, oy + y + 43);   // hats and sparks stay inside the card, above the name
        float sc = 0.6F * PetArt.scaleOf(c.stage());               // babies are smaller, like in the pet window
        g.pose().pushPose();
        g.pose().translate(cx, floor, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-cx, -floor, 0);
        PetArt.draw(g, colorOf(c.colorId()), cx, floor - 28, 2, ticks, false, false, c.stage(), c.head(), c.body());
        g.pose().popPose();
        g.disableScissor();

        if (medal >= 0 && medal < 3) {
            disc(g, x + 9, y + 9, 6, MEDAL[medal]);
            String n = Integer.toString(medal + 1);
            g.drawString(f, n, x + 9 - f.width(n) / 2, y + 6, TEXT, false);
        }

        String name = f.plainSubstrByWidth(c.name(), CARD_W - 6);
        g.drawString(f, name, x + (CARD_W - f.width(name)) / 2, y + 43, c.mine() ? ACCENT : TEXT, false);
        heart(g, x + 5, y + 52, c.liked() ? 0xFFE5484D : 0xFFD0C4E8);
        g.drawString(f, Integer.toString(c.likes()), x + 15, y + 51, c.liked() ? 0xFFE5484D : MUTED, false);
        g.drawString(f, c.age(), x + CARD_W - 4 - f.width(c.age()), y + 51, MUTED, false);
    }

    /** A 7 x 6 pixel heart. */
    public static void heart(GuiGraphics g, int x, int y, int argb) {
        rect(g, x + 1, y, 2, 1, argb);
        rect(g, x + 4, y, 2, 1, argb);
        rect(g, x, y + 1, 7, 2, argb);
        rect(g, x + 1, y + 3, 5, 1, argb);
        rect(g, x + 2, y + 4, 3, 1, argb);
        rect(g, x + 3, y + 5, 1, 1, argb);
    }
}
