package dev.cutemod.net;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.cutemod.data.PostData;
import dev.cutemod.data.ShowBoard;
import dev.cutemod.data.ShowData;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The server side of the pet show: puts pets on display, likes, pages of the list and the admin command
 * <pre>/cuteshow remove &lt;player&gt;</pre> (permission level 2). The rules are in {@link ShowBoard}; this class
 * adds the rate limits and talks to the clients. What a client sends about its pet cannot be checked (the server
 * does not see inside the pet), so it is only checked against white lists, like the scores of CuteNet.
 */
public final class ShowServer {
    private ShowServer() {}

    private static final long PUT_GAP_MS = 30_000L;      // a pet can be put on display / refreshed every 30 seconds
    private static final long ACT_GAP_MS = 400L;         // likes and withdrawing
    private static final long REQ_GAP_MS = 500L;         // asking for a page
    private static final int[] MILESTONES = {1, 5, 10, 25, 50, 100, 250, 500, 1000};

    private static final Map<UUID, Long> lastPut = new HashMap<>();
    private static final Map<UUID, Long> lastAct = new HashMap<>();
    private static final Map<UUID, Long> lastRequest = new HashMap<>();
    private static final Map<UUID, int[]> view = new HashMap<>();      // the page each player looks at: {sort, page}

    /** A player joined: if they changed their name, their pets get the new one. */
    public static void joined(ServerPlayer sp) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        ShowData.get(server).rename(sp.getUUID(), sp.getGameProfile().getName());
    }

    public static void leave(UUID id) {
        lastPut.remove(id);
        lastAct.remove(id);
        lastRequest.remove(id);
        view.remove(id);
    }

    /** True if the player is still inside the time gap of this kind of request (and if not, starts a new gap). */
    private static boolean tooFast(Map<UUID, Long> last, UUID id, long gap) {
        long now = System.currentTimeMillis();
        Long l = last.get(id);
        if (l != null && now - l < gap) return true;
        last.put(id, now);
        return false;
    }

    public static void put(ServerPlayer sp, ShowPutPayload p) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        if (tooFast(lastPut, sp.getUUID(), PUT_GAP_MS)) { push(sp, ShowBoard.TOO_FAST); return; }
        PetLook l = p.look();
        int r = ShowData.get(server).put(sp.getUUID(), sp.getGameProfile().getName(), p.color(),
                l.stage(), l.trait(), l.ageMin(), p.sick(), l.head(), l.body());
        push(sp, r);
    }

    public static void action(ServerPlayer sp, ShowActionPayload p) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        if (tooFast(lastAct, sp.getUUID(), ACT_GAP_MS)) { push(sp, ShowBoard.TOO_FAST); return; }
        ShowData data = ShowData.get(server);
        UUID me = sp.getUUID();
        int r;
        if (p.kind() == ShowActionPayload.WITHDRAW) {
            r = data.remove(me, p.color()) ? ShowBoard.OK : ShowBoard.MISSING;     // you can only take your own pet off
        } else if (p.kind() == ShowActionPayload.LIKE || p.kind() == ShowActionPayload.UNLIKE) {
            UUID owner;
            try { owner = UUID.fromString(p.owner()); } catch (IllegalArgumentException e) { push(sp, ShowBoard.REFUSED); return; }
            if (p.kind() == ShowActionPayload.LIKE) {
                r = data.like(me, owner, p.color());
                if (r == ShowBoard.OK) milestone(server, data, owner, p.color(), sp.getGameProfile().getName());
            } else {
                r = data.unlike(me, owner, p.color());
            }
            if (r == ShowBoard.NOOP) r = ShowBoard.OK;       // already liked / nothing to take back: the page is just refreshed
        } else {
            r = ShowBoard.REFUSED;
        }
        push(sp, r);
    }

    /** The owner gets a quiet notice on the first like and on round numbers (not on every single one). */
    private static void milestone(MinecraftServer server, ShowData data, UUID owner, String color, String fan) {
        ShowBoard.Pet pet = data.board().get(owner, color);
        ServerPlayer o = server.getPlayerList().getPlayer(owner);
        if (pet == null || o == null) return;
        int n = pet.likes.size();
        for (int m : MILESTONES) if (m == n) { o.displayClientMessage(Component.translatable("cutemod.show.liked", fan, n), true); return; }
    }

    public static void request(ServerPlayer sp, int sort, int page) {
        if (tooFast(lastRequest, sp.getUUID(), REQ_GAP_MS)) return;
        view.put(sp.getUUID(), new int[]{ShowBoard.clampSort(sort), Math.max(0, page)});
        push(sp, -1);
    }

    private static void push(ServerPlayer sp, int result) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        ShowBoard board = ShowData.get(server).board();
        int[] v = view.getOrDefault(sp.getUUID(), new int[]{ShowBoard.SORT_POPULAR, 0});
        int total = board.total();
        int sort = ShowBoard.clampSort(v[0]);
        int page = ShowBoard.clampPage(v[1], total);
        view.put(sp.getUUID(), new int[]{sort, page});
        List<ShowSyncPayload.Entry> out = new ArrayList<>();
        for (ShowBoard.Pet p : board.page(sort, page)) {
            out.add(new ShowSyncPayload.Entry(
                    new ShowSyncPayload.Who(p.owner.toString(), p.ownerName, p.color),
                    new PetLook(p.stage, p.trait, p.ageMin, p.head, p.body),
                    p.likes.size(), p.likes.contains(sp.getUUID())));
        }
        List<String> mine = board.colorsOf(sp.getUUID());
        PacketDistributor.sendToPlayer(sp, new ShowSyncPayload(result, sort, page, total, out,
                mine.size() > 8 ? new ArrayList<>(mine.subList(0, 8)) : mine));
    }

    // ---------- admin command ----------
    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("cuteshow").requires(s -> s.hasPermission(2))
                .then(Commands.literal("remove").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> {
                    CommandSourceStack src = ctx.getSource();
                    MinecraftServer server = src.getServer();
                    String name = StringArgumentType.getString(ctx, "player");
                    UUID id = resolve(server, name);
                    if (id == null) {
                        src.sendFailure(Component.translatable("cutemod.post.cmd.unknown", name));
                        return 0;
                    }
                    int n = ShowData.get(server).removeAll(id);
                    if (n == 0) {
                        src.sendFailure(Component.translatable("cutemod.show.cmd.none", name));
                        return 0;
                    }
                    src.sendSuccess(() -> Component.translatable("cutemod.show.cmd.removed", name, n), true);
                    return 1;
                }))));
    }

    /** An online player by name, or a player the server has seen before. */
    private static UUID resolve(MinecraftServer server, String name) {
        ServerPlayer online = server.getPlayerList().getPlayerByName(name);
        if (online != null) return online.getUUID();
        return PostData.get(server).findByName(name);
    }
}
