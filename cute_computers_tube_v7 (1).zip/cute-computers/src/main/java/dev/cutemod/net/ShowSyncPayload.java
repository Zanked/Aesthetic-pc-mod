package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import dev.cutemod.data.ShowBoard;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: one page of the pet show. result answers the last thing you did (-1 nothing, 0 done, 1 too fast,
 * 2 refused, 3 your pet is sick, 4 that is your own pet, 5 no such pet). mine lists the colors of your pets that are
 * on the show right now (they may be on another page).
 */
public record ShowSyncPayload(int result, int sort, int page, int total, List<Entry> pets, List<String> mine) implements CustomPacketPayload {
    public record Who(String owner, String name, String color) {}

    public record Entry(Who who, PetLook look, int likes, boolean liked) {}

    public static final Type<ShowSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "show_sync"));

    private static final StreamCodec<ByteBuf, Who> WHO = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(36), Who::owner,
            ByteBufCodecs.stringUtf8(32), Who::name,
            ByteBufCodecs.stringUtf8(16), Who::color,
            Who::new);

    private static final StreamCodec<ByteBuf, Entry> ENTRY = StreamCodec.composite(
            WHO, Entry::who,
            PetLook.CODEC, Entry::look,
            ByteBufCodecs.VAR_INT, Entry::likes,
            ByteBufCodecs.BOOL, Entry::liked,
            Entry::new);

    public static final StreamCodec<RegistryFriendlyByteBuf, ShowSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ShowSyncPayload::result,
            ByteBufCodecs.VAR_INT, ShowSyncPayload::sort,
            ByteBufCodecs.VAR_INT, ShowSyncPayload::page,
            ByteBufCodecs.VAR_INT, ShowSyncPayload::total,
            ENTRY.apply(ByteBufCodecs.list(ShowBoard.PAGE)), ShowSyncPayload::pets,
            ByteBufCodecs.stringUtf8(16).apply(ByteBufCodecs.list(8)), ShowSyncPayload::mine,
            ShowSyncPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ShowSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onShowSync(p));
    }
}
