package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client -> server: "send me this page of the pet show" (sort 0 popular, 1 newest, 2 eldest). */
public record ShowRequestPayload(int sort, int page) implements CustomPacketPayload {
    public static final Type<ShowRequestPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "show_request"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ShowRequestPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ShowRequestPayload::sort,
            ByteBufCodecs.VAR_INT, ShowRequestPayload::page,
            ShowRequestPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ShowRequestPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) ShowServer.request(sp, p.sort(), p.page()); });
    }
}
