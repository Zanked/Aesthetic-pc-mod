package dev.cutemod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * Stranger's Key: the prize of the big easter egg (the Traces of the Stranger). It always glows; right-click
 * rings a soft chime and lets a few stars drift up.
 */
public class StrangerKeyItem extends Item {
    public StrangerKeyItem(Properties props) { super(props); }

    @Override
    public boolean isFoil(ItemStack stack) { return true; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            for (int i = 0; i < 8; i++) {
                double a = level.random.nextDouble() * Math.PI * 2;
                level.addParticle(ParticleTypes.END_ROD, player.getX() + Math.cos(a) * 0.6, player.getY() + 1.0 + level.random.nextDouble() * 0.8,
                        player.getZ() + Math.sin(a) * 0.6, 0, 0.03 + level.random.nextDouble() * 0.03, 0);
            }
        } else {
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0F, 1.2F);
        }
        player.getCooldowns().addCooldown(this, 30);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("cutemod.tip.key.1").withStyle(ChatFormatting.LIGHT_PURPLE));
        tip.add(Component.translatable("cutemod.tip.key.2").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        tip.add(Component.translatable("cutemod.tip.key.3").withStyle(ChatFormatting.GOLD));
    }
}
