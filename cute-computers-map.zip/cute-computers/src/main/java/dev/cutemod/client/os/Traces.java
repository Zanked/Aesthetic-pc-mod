package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.neoforged.neoforge.network.PacketDistributor;

import java.time.LocalTime;
import java.util.Locale;
import java.util.function.Predicate;

/**
 * The big easter egg "Traces of the Stranger": 15 clues (a small gold star) hidden in the apps of the whole computer,
 * in 5 chapters of 3. A clue shows its star only in its own app and only when its simple condition is true (the hint in
 * the diary tab "Clues" says what to do). The next chapter opens when the previous one is complete; every finished
 * chapter shows a big "Chapter N" banner with a jingle and gives one word of the secret phrase. The phrase is said in
 * the Terminal ("say ...") and gives the prize: coins and a title (an achievement), and the real item Stranger's Key.
 *
 * Progress is kept in the normal counters of {@link Progress}: sx_<id> for a found clue, sx_done for the finale.
 */
public final class Traces {
    private Traces() {}

    public static final int CHAPTERS = 5;
    public static final int PER_CHAPTER = 3;

    /** One clue: id, chapter (1..5), the simple class name of the app that shows the star, where (local pixels), when. */
    public record Trace(String id, int chapter, String app, int x, int y, Predicate<App> cond) {}

    private static boolean night() { int h = LocalTime.now().getHour(); return h >= 22 || h < 6; }

    // All the conditions are in this one table: change a number here to make a clue easier or harder.
    public static final Trace[] ALL = {
            // chapter 1: Rustle (easy, everyone gets there in the first days)
            new Trace("radio",    1, "RadioApp",    284, 148, a -> night()),
            new Trace("pet",      1, "PetApp",       14, 150, a -> Progress.count("feed") >= 3),
            new Trace("terminal", 1, "TerminalApp", 286, 156, a -> Progress.count("cmds") >= 3),
            // chapter 2: Traces
            new Trace("mail",     2, "MailApp",     150, 156, a -> Progress.step() >= 1),
            new Trace("browser",  2, "BrowserApp",  292, 150, a -> Progress.count("scary_read") >= 4),
            new Trace("store",    2, "StoreApp",    150, 156, a -> Library.ownedCount() >= 2),
            // chapter 3: Echo
            new Trace("music",    3, "MusicApp",    286, 156, a -> a.busy()),
            new Trace("tales",    3, "TalesApp",     14, 156, a -> Progress.streak() >= 3),
            new Trace("beats",    3, "BeatApp",     286, 150, a -> Progress.count("earned") >= 100),
            // chapter 4: Depth
            new Trace("diary1",   4, "QuestApp",    150, 150, a -> Progress.step() >= Progress.PART1),
            new Trace("tube",     4, "TubeApp",      14, 150, a -> Progress.questDone()),
            new Trace("fishing",  4, "FishingApp", 286,  12, a -> Progress.count("pet_gifts") >= 2),
            // chapter 5: The Stranger
            new Trace("school",   5, "SchoolApp",   150, 156, a -> Progress.streak() >= 7),
            new Trace("bank",     5, "BankApp",      14, 156, a -> Progress.count("earned") >= 500),
            new Trace("diary2",   5, "QuestApp",     60, 150, a -> foundCount() >= ALL.length - 1),
    };

    private static final int[] CHAPTER_COINS = {30, 40, 50, 70, 120};
    /** The secret phrase, also accepted in English whatever the language of the game is. */
    private static final String[] PHRASE_EN = {"you", "are", "never", "alone", "here"};

    // ---------- state ----------
    public static boolean found(Trace t) { return Progress.count("sx_" + t.id()) > 0; }

    public static int foundCount() {
        int n = 0;
        for (Trace t : ALL) if (found(t)) n++;
        return n;
    }

    public static boolean started() { return foundCount() > 0; }

    public static boolean chapterDone(int c) {
        for (Trace t : ALL) if (t.chapter() == c && !found(t)) return false;
        return true;
    }

    public static boolean unlocked(int c) { return c <= 1 || chapterDone(c - 1); }

    public static boolean finished() { return Progress.count("sx_done") > 0; }

    public static boolean allChapters() { return chapterDone(CHAPTERS); }

    /** True when this clue can be taken right now in this app. */
    private static boolean visible(Trace t, App app) {
        if (app == null || found(t) || !unlocked(t.chapter())) return false;
        if (!app.getClass().getSimpleName().equals(t.app())) return false;
        try { return t.cond().test(app); } catch (RuntimeException e) { return false; }
    }

    public static String word(int chapter) { return Component.translatable("cutemod.trace.word." + chapter).getString(); }

    // ---------- the star in the app ----------
    private static final int HIT = 10;

    public static void render(GuiGraphics g, App app, int mx, int my) {
        for (Trace t : ALL) {
            if (!visible(t, app)) continue;
            boolean over = Math.abs(mx - t.x()) <= HIT / 2 && Math.abs(my - t.y()) <= HIT / 2;
            double ph = (System.currentTimeMillis() % 2400) / 2400.0 * Math.PI * 2;
            int a = over ? 255 : 110 + (int) (80 * (0.5 + 0.5 * Math.sin(ph + t.x())));     // a slow glow, so it can be noticed
            int col = (a << 24) | 0xFFD866;
            int x = t.x(), y = t.y();
            g.fill(x, y - 2, x + 1, y + 3, col);                    // a four-pointed star
            g.fill(x - 2, y, x + 3, y + 1, col);
            g.fill(x - 1, y - 1, x + 2, y + 2, col);
            if (over) {
                int h = 0x66000000 | 0xFFD866;
                g.fill(x - 4, y, x - 3, y + 1, h); g.fill(x + 4, y, x + 5, y + 1, h);
                g.fill(x, y - 4, x + 1, y - 3, h); g.fill(x, y + 4, x + 1, y + 5, h);
            }
        }
    }

    public static boolean click(App app, int x, int y, int button) {
        if (button != 0) return false;
        for (Trace t : ALL) {
            if (!visible(t, app)) continue;
            if (Math.abs(x - t.x()) <= HIT / 2 && Math.abs(y - t.y()) <= HIT / 2) { take(t); return true; }
        }
        return false;
    }

    private static void take(Trace t) {
        boolean first = !started();
        Progress.setCount("sx_" + t.id(), 1);
        Progress.bump("traces");
        Progress.toast("cutemod.toast.trace", Component.translatable("cutemod.trace." + t.id() + ".name").getString());
        Sfx.ui(SoundEvents.AMETHYST_BLOCK_CHIME, 1.4F, 0.8F);
        if (first) Progress.toast("cutemod.toast.trace.first");
        if (chapterDone(t.chapter())) chapterEnd(t.chapter());
    }

    // ---------- the chapter banner ----------
    private static final int BANNER_TICKS = 280;
    private static int banner, bannerCh;

    private static void chapterEnd(int c) {
        bannerCh = c;
        banner = BANNER_TICKS;
        Progress.earnQuiet(CHAPTER_COINS[c - 1]);
        if (c < CHAPTERS) Progress.toast("cutemod.toast.chapter.next", c + 1);
    }

    /** Called 60 times per second: the jingle of the banner. */
    public static void tick() {
        if (banner <= 0) return;
        banner--;
        int age = BANNER_TICKS - banner;
        if (age == 3) chime(0.75F);
        if (age == 11) chime(0.95F);
        if (age == 19) chime(1.25F);
        if (age == 30) Sfx.ui(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 0.9F);
        if (age == 70 && bannerCh == CHAPTERS) Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 0.6F, 0.9F);
    }

    private static void chime(float pitch) { Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), pitch, 0.9F); }

    public static boolean bannerActive() { return banner > 0; }

    /** The big "Chapter N" over the app area (300 x 166). */
    public static void renderBanner(GuiGraphics g) {
        if (banner <= 0) return;
        Font f = Minecraft.getInstance().font;
        int age = BANNER_TICKS - banner;
        float in = Math.min(1f, age / 22f), out = Math.min(1f, banner / 36f);
        float k = Math.min(in, out);
        int a = (int) (235 * k);
        int y0 = 46, y1 = 120;
        g.fill(0, y0, App.W, y1, (a << 24) | 0x0B0614);
        int line = (int) (255 * k);
        g.fill(0, y0, App.W, y0 + 1, (line << 24) | 0xFFD866);
        g.fill(0, y1 - 1, App.W, y1, (line << 24) | 0xFFD866);
        int ta = Math.max(4, (int) (255 * k));
        String head = Component.translatable("cutemod.trace.chapter", bannerCh).getString().toUpperCase(Locale.ROOT);
        float sc = 2.4f;
        int hw = (int) (CuteFont.width(f, head) * sc);
        g.pose().pushPose();
        g.pose().translate((App.W - hw) / 2f, y0 + 9 + (1f - in) * 6f, 0);
        g.pose().scale(sc, sc, 1f);
        CuteFont.draw(g, f, head, 0, 0, (ta << 24) | 0xFFD866, false);
        g.pose().popPose();
        String title = Component.translatable("cutemod.trace.ch." + bannerCh + ".title").getString();
        CuteFont.draw(g, f, title, (App.W - CuteFont.width(f, title)) / 2, y0 + 36, (ta << 24) | 0xF3EAFF, false);
        String w = Component.translatable("cutemod.trace.banner.word", word(bannerCh)).getString();
        CuteFont.draw(g, f, w, (App.W - CuteFont.width(f, w)) / 2, y0 + 50, (ta << 24) | 0xB57BD6, false);
        String coins = "+" + CHAPTER_COINS[bannerCh - 1];
        CuteFont.draw(g, f, coins, (App.W - CuteFont.width(f, coins)) / 2 - 6, y0 + 61, (ta << 24) | 0xFFE680, false);
        Progress.drawCoin(g, (App.W + CuteFont.width(f, coins)) / 2 - 2, y0 + 61);
    }

    // ---------- the Terminal: "say <phrase>" ----------
    public static final int SAY_WRONG = 0, SAY_LOCKED = 1, SAY_OK = 2, SAY_DONE = 3;

    private static String[] words(String s) {
        String n = s.toLowerCase(Locale.ROOT).replace('\u0451', '\u0435').replaceAll("[^\\p{L}\\s]", " ").trim();
        return n.isEmpty() ? new String[0] : n.split("\\s+");
    }

    private static boolean matches(String[] said, String[] want) {
        if (said.length != want.length) return false;
        for (int i = 0; i < want.length; i++) if (!said[i].equals(want[i])) return false;
        return true;
    }

    /** What the player said in the Terminal. Returns one of the SAY_ results. */
    public static int say(String phrase) {
        if (finished()) return SAY_DONE;
        if (!allChapters()) return SAY_LOCKED;
        String[] said = words(phrase);
        String[] now = new String[CHAPTERS];
        for (int i = 0; i < CHAPTERS; i++) now[i] = words(word(i + 1)).length > 0 ? words(word(i + 1))[0] : "";
        if (!matches(said, now) && !matches(said, PHRASE_EN)) return SAY_WRONG;
        finish();
        return SAY_OK;
    }

    private static void finish() {
        Progress.setCount("sx_done", 1);
        Progress.bump("stranger_end");                              // the achievement: coins and the title
        PacketDistributor.sendToServer(new dev.cutemod.net.StrangerKeyPayload());   // the real item (the server gives it once)
    }
}
