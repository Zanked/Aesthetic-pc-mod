package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The pictures of the pet map: the little town (grass, roads, sea, lake, mountains, fields) and one small building for
 * every place on it. Only scenery is here; the clicks, the pet and the texts are in {@link PetMap}. The whole screen is
 * 300 x 166 and the header takes the top 17 pixels. Everything is drawn from the coordinates it is given, so the
 * places can be moved just by changing their numbers in {@link PetMap}.
 */
final class MapArt {
    private MapArt() {}

    static final int W = 300, H = 166, HEAD = 17;

    // the places (ids of the map): where they stand (centre x, ground y)
    static final int HOME = 0, SCHOOL = 1, PARK = 2, STAGE = 3, FARM = 4, FISHING = 5, MARKET = 6, BALLOON = 7,
            AMUSEMENT = 8, CINEMA = 9, MUSEUM = 10, CAMP = 11, OLD_HOUSE = 12, FAIR = 13, COUNT = 14;
    static final int[][] POS = {
            {128, 110}, {76, 108}, {182, 112}, {236, 108}, {46, 153}, {252, 153}, {116, 153}, {250, 68},
            {188, 68}, {130, 66}, {80, 66}, {28, 68}, {24, 110}, {172, 153}};

    // ---------- tiny helpers (this class stands alone) ----------
    static void rect(GuiGraphics g, int x, int y, int w, int h, int c) { g.fill(x, y, x + w, y + h, c); }

    static void ball(GuiGraphics g, int cx, int cy, int r, int c) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.round(Math.sqrt((r + 0.2) * (r + 0.2) - dy * dy));
            rect(g, cx - dx, cy + dy, dx * 2 + 1, 1, c);
        }
    }

    static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int c) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0, 1 - dy * dy / (double) (ry * ry + 1))));
            rect(g, cx - dx, cy + dy, dx * 2, 1, c);
        }
    }

    static void tri(GuiGraphics g, int cx, int top, int w, int h, int c) {
        for (int r = 0; r < h; r++) {
            int ww = Math.max(1, w * (r + 1) / h);
            rect(g, cx - ww / 2, top + r, ww, 1, c);
        }
    }

    static void ln(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        int n = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)));
        for (int i = 0; i <= n; i++) rect(g, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, 1, 1, c);
    }

    static int mix(int a, int b, float f) { return App.mix(a, b, f); }

    private static void shadow(GuiGraphics g, int cx, int b, int rx) { oval(g, cx, b, rx, 3, 0x30000000); }

    // =====================================================================================================
    //  THE TOWN
    // =====================================================================================================
    static void terrain(GuiGraphics g, int ticks) {
        g.fillGradient(0, HEAD, W, H, 0xFFB8E890, 0xFF8CD07A);
        for (int i = 0; i < 110; i++) {                                         // grass tufts
            int x = (i * 53 + 7) % W, y = HEAD + 2 + (i * 37 + 11) % (H - HEAD - 4);
            rect(g, x, y, 1, 2, 0xFF7CC46A); rect(g, x + 2, y + 1, 1, 1, 0xFF9ADA86);
            if (i % 9 == 0) { rect(g, x + 4, y, 1, 1, 0xFFFFFFFF); rect(g, x + 4, y - 1, 1, 1, 0xFFFFE066); }   // a daisy
        }
        // mountains in the top-left corner
        tri(g, 12, 24, 46, 36, 0xFF8E9AB4); tri(g, 12, 24, 14, 11, 0xFFFFFFFF);
        tri(g, 44, 32, 44, 28, 0xFF7A88A6); tri(g, 44, 32, 12, 8, 0xFFFFFFFF);
        tri(g, 78, 36, 30, 22, 0xFF9AA6BE);
        rect(g, 0, 56, 100, 4, 0xFF6FBF6A);
        // the sea in the top-right corner, with a sandy edge and sparkles that move
        for (int x = 232; x < W; x++) {
            int bottom = HEAD + (x - 232) * 60 / 68;
            g.fillGradient(x, HEAD, x + 1, bottom, 0xFF4DB0E8, 0xFF7ACBF2);
            rect(g, x, bottom, 1, 3, 0xFFF3DDA4); rect(g, x, bottom + 3, 1, 1, 0xFFE0C888);
            if ((x + ticks / 8) % 11 == 0) rect(g, x, HEAD + 2 + (x * 7) % Math.max(1, bottom - HEAD - 2), 2, 1, 0xCCFFFFFF);
        }
        // the lake in the bottom-right corner
        oval(g, 252, 148, 46, 18, 0xFFF3DDA4);
        oval(g, 252, 148, 43, 16, 0xFF4DA8E0);
        oval(g, 252, 147, 40, 14, 0xFF63BBEA);
        for (int i = 0; i < 4; i++) rect(g, 222 + (i * 17 + ticks / 10) % 56, 142 + (i * 5) % 12, 5, 1, 0x88FFFFFF);
        // the fields of the farm (bottom-left)
        for (int r = 0; r < 5; r++) {
            int y = 126 + r * 8;
            rect(g, 4, y, 84, 6, r % 2 == 0 ? 0xFFC9A96A : 0xFFB8935A);
            for (int x = 6; x < 86; x += 6) rect(g, x, y + 1, 2, 3, r % 2 == 0 ? 0xFF8ACB5C : 0xFFE8C84A);
        }
        // the roads
        road(g, 0, 76, W, 4, true); road(g, 0, 122, W, 4, true);
        road(g, 100, 78, 4, 44, false); road(g, 208, 78, 4, 44, false); road(g, 64, 124, 4, 30, false); road(g, 148, 124, 4, 30, false);
        road(g, 40, 62, 4, 16, false); road(g, 156, 62, 4, 16, false);
        // a little river of flowers along the top of the roads (just decoration)
        for (int i = 0; i < 12; i++) {
            int x = 8 + i * 25, y = 72 + (i % 2) * 11;
            rect(g, x, y, 1, 1, i % 2 == 0 ? 0xFFFF8FB8 : 0xFFFFFFFF); rect(g, x + 1, y + 1, 1, 1, 0xFFFFE066);
        }
    }

    private static void road(GuiGraphics g, int x, int y, int w, int h, boolean horiz) {
        rect(g, x, y, w, h, 0xFFF3E3BC);
        if (horiz) { rect(g, x, y, w, 1, 0xFFFFF4D8); rect(g, x, y + h - 1, w, 1, 0xFFD8C090); for (int i = x + 2; i < x + w; i += 10) rect(g, i, y + h / 2, 4, 1, 0xFFFFFFFF); }
        else { rect(g, x, y, 1, h, 0xFFFFF4D8); rect(g, x + w - 1, y, 1, h, 0xFFD8C090); }
    }

    /** A soft light on the ground under the place the pointer is on. */
    static void glow(GuiGraphics g, int cx, int b, int ticks) {
        int p = 18 + (int) Math.round(Math.sin(ticks / 8.0) * 2);
        oval(g, cx, b - 2, p + 4, 8, 0x22FFFFFF); oval(g, cx, b - 2, p, 6, 0x33FFFFFF);
    }

    /** Mist over a place that is still locked: two soft rounds of cloud, a padlock in the middle. */
    static void mist(GuiGraphics g, int cx, int b, int ticks) {
        int dx = (int) Math.round(Math.sin(ticks / 40.0) * 2);
        oval(g, cx + dx, b - 15, 22, 17, 0x40E8EEF8); oval(g, cx - dx, b - 14, 19, 14, 0x55F2F0FA);
        for (int i = 0; i < 3; i++) ball(g, cx - 10 + i * 10 + dx, b - 8 + (i % 2) * 2, 5, 0x66FFFFFF);
        int lx = cx, ly = b - 16;
        rect(g, lx - 4, ly - 1, 9, 7, 0xFF7A6AA0); rect(g, lx - 4, ly - 1, 9, 1, 0xFFB8A8D8);
        rect(g, lx - 3, ly - 6, 1, 5, 0xFF7A6AA0); rect(g, lx + 3, ly - 6, 1, 5, 0xFF7A6AA0); rect(g, lx - 2, ly - 7, 5, 1, 0xFF7A6AA0);
        rect(g, lx, ly + 1, 1, 3, 0xFFF2ECF8);
    }

    // =====================================================================================================
    //  THE PLACES. cx = the middle, b = the ground line; every place is at most 36 wide and 36 high.
    // =====================================================================================================
    static void place(GuiGraphics g, int id, int cx, int b, int ticks, boolean night, boolean lit, int body) {
        shadow(g, cx, b, id == AMUSEMENT || id == PARK ? 16 : 14);
        switch (id) {
            case HOME -> home(g, cx, b, ticks, night, body);
            case SCHOOL -> school(g, cx, b, ticks, night);
            case PARK -> park(g, cx, b, ticks);
            case STAGE -> stage(g, cx, b, ticks);
            case FARM -> farm(g, cx, b, ticks);
            case FISHING -> fishing(g, cx, b, ticks);
            case MARKET -> market(g, cx, b, ticks);
            case BALLOON -> balloon(g, cx, b, ticks);
            case AMUSEMENT -> amusement(g, cx, b, ticks);
            case CINEMA -> cinema(g, cx, b, ticks);
            case MUSEUM -> museum(g, cx, b, ticks);
            case CAMP -> camp(g, cx, b, ticks);
            case OLD_HOUSE -> oldHouse(g, cx, b, ticks, lit);
            case FAIR -> fair(g, cx, b, ticks, lit);
            default -> { }
        }
    }

    private static int win(boolean night) { return night ? 0xFFFFE680 : 0xFFA8DEFF; }

    private static void home(GuiGraphics g, int cx, int b, int ticks, boolean night, int body) {
        int roof = mix(body | 0xFF000000, 0xFF000000, 0.08F), roofL = mix(body | 0xFF000000, 0xFFFFFFFF, 0.3F), roofD = mix(body | 0xFF000000, 0xFF000000, 0.3F);
        rect(g, cx + 5, b - 27, 4, 9, 0xFFC87A5A); rect(g, cx + 5, b - 27, 4, 1, 0xFFE8A07A);
        for (int k = 0; k < 3; k++) ball(g, cx + 7 + (ticks / 12 + k) % 3 - 1, b - 30 - (ticks / 5 + k * 6) % 14, 1, 0x88FFFFFF);   // smoke
        rect(g, cx - 11, b - 13, 22, 13, 0xFFFFF3E0); rect(g, cx - 11, b - 13, 1, 13, 0xFFFFFFFF); rect(g, cx + 10, b - 13, 1, 13, 0xFFE2C9A0);
        for (int r = 0; r < 12; r++) {
            int w = 30 * (r + 1) / 12;
            rect(g, cx - w / 2, b - 25 + r, w, 1, r < 2 ? roofL : roof);
        }
        rect(g, cx - 15, b - 14, 30, 2, roofD);
        rect(g, cx - 2, b - 8, 5, 8, 0xFF8A5A3A); rect(g, cx + 1, b - 4, 1, 1, 0xFFFFD84D);
        for (int s = -1; s <= 1; s += 2) {
            int wx = cx + (s < 0 ? -9 : 5);
            rect(g, wx - 1, b - 11, 6, 6, 0xFFFFFFFF); rect(g, wx, b - 10, 4, 4, win(night)); rect(g, wx + 1, b - 10, 1, 4, 0xFFFFFFFF);
        }
        rect(g, cx - 14, b - 2, 3, 2, 0xFF3FA55A); rect(g, cx - 14, b - 4, 1, 2, 0xFFFF8FB8); rect(g, cx + 12, b - 2, 3, 2, 0xFF3FA55A); rect(g, cx + 13, b - 4, 1, 2, 0xFFFFE066);
    }

    private static void school(GuiGraphics g, int cx, int b, int ticks, boolean night) {
        rect(g, cx - 15, b - 12, 30, 12, 0xFFE8A07A); rect(g, cx - 15, b - 12, 30, 1, 0xFFF4C0A0);
        for (int y = b - 10; y < b; y += 3) rect(g, cx - 15, y, 30, 1, 0x20A04A2A);
        rect(g, cx - 16, b - 15, 32, 3, 0xFF4D6AD0); rect(g, cx - 16, b - 15, 32, 1, 0xFF7A94F0);
        rect(g, cx - 5, b - 24, 11, 10, 0xFFD88A66); rect(g, cx - 5, b - 24, 11, 1, 0xFFF4C0A0);
        tri(g, cx, b - 31, 13, 7, 0xFF4D6AD0);
        ball(g, cx, b - 19, 3, 0xFFFFFFFF); ball(g, cx, b - 19, 2, 0xFFFFF8E8);
        double an = ticks / 30.0; ln(g, cx, b - 19, cx + (int) Math.round(Math.cos(an) * 2), b - 19 + (int) Math.round(Math.sin(an) * 2), 0xFF3A2A3A);
        rect(g, cx, b - 38, 1, 8, 0xFF8A6A5A); rect(g, cx + 1, b - 38, 5 + (ticks / 10) % 2, 3, 0xFFE5484D);          // the flag
        rect(g, cx - 3, b - 7, 7, 7, 0xFF6E4726); rect(g, cx - 3, b - 7, 7, 1, 0xFF9A6A3C); rect(g, cx, b - 7, 1, 7, 0xFF4A2E16);
        for (int s = -1; s <= 1; s += 2) for (int k = 0; k < 2; k++) {
            int wx = cx + s * (8 + k * 5) - 2;
            rect(g, wx, b - 10, 4, 5, win(night)); rect(g, wx + 1, b - 10, 1, 5, 0xFFFFFFFF);
        }
    }

    private static void park(GuiGraphics g, int cx, int b, int ticks) {
        oval(g, cx + 7, b - 5, 13, 5, 0xFF5AB0E8); oval(g, cx + 7, b - 5, 10, 3, 0xFF7ACBF2);
        rect(g, cx + 3 + (ticks / 9) % 8, b - 6, 3, 1, 0x99FFFFFF);
        for (int i = 0; i < 2; i++) {
            int tx = cx - 12 + i * 8, th = 12 + i * 3;
            rect(g, tx - 1, b - th, 3, th, 0xFF7A4A2A);
            ball(g, tx, b - th - 3, 7, i == 0 ? 0xFF2E8B4A : 0xFF3FA55A); ball(g, tx - 2, b - th - 5, 3, 0xFF5DBB6A);
            if (i == 1) { rect(g, tx + 3, b - th - 2, 1, 1, 0xFFFF8FB8); rect(g, tx - 4, b - th, 1, 1, 0xFFFF8FB8); }
        }
        rect(g, cx - 4, b - 4, 8, 1, 0xFF9A6A3C); rect(g, cx - 4, b - 6, 8, 1, 0xFFC8955C); rect(g, cx - 4, b - 4, 1, 4, 0xFF6E4726); rect(g, cx + 3, b - 4, 1, 4, 0xFF6E4726);   // a bench
        rect(g, cx + 6, b - 8, 1, 3, 0xFFFFFFFF); ball(g, cx + 6, b - 9, 1, 0xFFFFC832);                                                              // a duck
    }

    private static void stage(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 15, b - 4, 30, 4, 0xFF8A5A3A); rect(g, cx - 15, b - 4, 30, 1, 0xFFC8955C);
        rect(g, cx - 13, b - 20, 26, 16, 0xFF3A2860);
        rect(g, cx - 13, b - 20, 6, 16, 0xFFC02844); rect(g, cx + 7, b - 20, 6, 16, 0xFFC02844);
        for (int k = 1; k < 6; k += 2) { rect(g, cx - 13 + k, b - 20, 1, 16, 0xFF8A1830); rect(g, cx + 7 + k, b - 20, 1, 16, 0xFF8A1830); }
        rect(g, cx - 14, b - 23, 28, 4, 0xFFFFC832); rect(g, cx - 14, b - 23, 28, 1, 0xFFFFE680);
        int sp = (ticks / 10) % 2;
        rect(g, cx - 1, b - 31 - sp, 3, 7, 0xFFFFD84D); rect(g, cx - 3, b - 29 - sp, 7, 3, 0xFFFFD84D); rect(g, cx, b - 29 - sp, 1, 1, 0xFFFFFFFF);   // the star
        int sw = (int) Math.round(Math.sin(ticks / 25.0) * 4);                               // the spotlights
        tri(g, cx - 4 + sw, b - 20, 10, 16, 0x26FFF0A0); tri(g, cx + 4 - sw, b - 20, 10, 16, 0x1CFFB0E0);
        ball(g, cx, b - 6, 2, 0xFFFFC8E0);
    }

    private static void farm(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 14, b - 12, 18, 12, 0xFFD8483E); rect(g, cx - 14, b - 12, 18, 1, 0xFFF07A6A);
        tri(g, cx - 5, b - 22, 22, 10, 0xFF7A2A2A);
        rect(g, cx - 9, b - 9, 8, 9, 0xFFFFFFFF); ln(g, cx - 9, b - 9, cx - 2, b - 1, 0xFFD8483E); ln(g, cx - 2, b - 9, cx - 9, b - 1, 0xFFD8483E);
        rect(g, cx + 7, b - 18, 7, 18, 0xFFC8D0D8); rect(g, cx + 7, b - 18, 2, 18, 0xFFE8EEF4); ball(g, cx + 10, b - 18, 4, 0xFFA8B0B8);
        for (int i = 0; i < 4; i++) { rect(g, cx - 14 + i * 4, b - 3, 1, 3, 0xFF8A5A3A); }
        rect(g, cx - 14, b - 2, 14, 1, 0xFFB98450);
        int hop = (ticks / 14) % 2; rect(g, cx + 16, b - 3 - hop, 3, 3, 0xFFFFFFFF); rect(g, cx + 18, b - 4 - hop, 2, 2, 0xFFFFFFFF);          // a lamb
    }

    private static void fishing(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 15, b - 9, 22, 4, 0xFFC8955C); rect(g, cx - 15, b - 9, 22, 1, 0xFFE8B880);
        for (int x = cx - 12; x < cx + 6; x += 4) rect(g, x, b - 9, 1, 4, 0xFF9A6A3C);
        for (int x = cx - 14; x < cx + 7; x += 7) rect(g, x, b - 5, 2, 6, 0xFF6E4726);
        int bob = (int) Math.round(Math.sin(ticks / 12.0));
        ln(g, cx - 13, b - 10, cx - 19, b - 20, 0xFF6E4726);
        ln(g, cx - 19, b - 20, cx - 20, b - 6 + bob, 0x99FFFFFF);
        ball(g, cx - 20, b - 5 + bob, 1, 0xFFE5484D);
        int j = ticks % 160;                                                                      // a fish jumps now and then
        if (j < 20) {
            int fx = cx + 6 + j, fy = b - 2 - (int) Math.round(Math.sin(j * Math.PI / 20) * 9);
            rect(g, fx, fy, 4, 2, 0xFFFF9A3C); rect(g, fx - 2, fy - 1, 2, 4, 0xFFFFC832); rect(g, fx + 3, fy, 1, 1, 0xFF3A2A3A);
        }
        for (int k = 0; k < 3; k++) rect(g, cx + 6 + k * 6 - (ticks / 10) % 5, b + 1 + k % 2, 4, 1, 0x88FFFFFF);
    }

    private static void market(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 12, b - 14, 24, 14, 0xFFFFF4DC);
        rect(g, cx - 13, b - 6, 26, 6, 0xFFC8955C); rect(g, cx - 13, b - 6, 26, 1, 0xFFE8B880);
        for (int k = 0; k < 26; k += 4) {
            rect(g, cx - 13 + k, b - 20, Math.min(4, 26 - k), 7, (k / 4) % 2 == 0 ? 0xFFE5484D : 0xFFFFFFFF);
            rect(g, cx - 13 + k, b - 14, Math.min(4, 26 - k), 2, (k / 4) % 2 == 0 ? 0xFFB02A30 : 0xFFE0D8E0);
        }
        ball(g, cx - 7, b - 8, 2, 0xFFE5484D); ball(g, cx - 3, b - 8, 2, 0xFFFF9A3C); ball(g, cx + 2, b - 8, 2, 0xFFFFE066); ball(g, cx + 7, b - 8, 2, 0xFF6BCB77);
        rect(g, cx - 15, b - 3, 4, 3, 0xFF9A6A3C); rect(g, cx + 12, b - 3, 4, 3, 0xFF9A6A3C);
        if ((ticks / 40) % 2 == 0) { rect(g, cx - 2, b - 17, 1, 1, 0xFFFFD84D); }
    }

    private static void balloon(GuiGraphics g, int cx, int b, int ticks) {
        int bob = (int) Math.round(Math.sin(ticks / 25.0) * 2);
        int by = b - 27 + bob;
        int[] band = {0xFFE5484D, 0xFFFFC832, 0xFF4D96FF};
        for (int dy = -9; dy <= 9; dy++) {
            int half = (int) Math.round(Math.sqrt(9.2 * 9.2 - dy * dy) * (dy > 3 ? 1.0 - (dy - 3) * 0.07 : 1.0));
            for (int dx = -half; dx <= half; dx++) rect(g, cx + dx, by + dy, 1, 1, band[Math.floorMod((dx + 16) / 4, 3)]);
        }
        rect(g, cx - 5, by - 6, 2, 2, 0x88FFFFFF);
        ln(g, cx - 5, by + 8, cx - 3, by + 14, 0xFF6E4726); ln(g, cx + 5, by + 8, cx + 3, by + 14, 0xFF6E4726);
        rect(g, cx - 4, by + 14, 8, 5, 0xFFC8955C); rect(g, cx - 4, by + 14, 8, 1, 0xFFE8B880);
        rect(g, cx - 8, b - 2, 16, 2, 0xFF8A6A5A); rect(g, cx - 6, b - 4, 1, 2, 0xFF6E4726); rect(g, cx + 5, b - 4, 1, 2, 0xFF6E4726);
    }

    private static void amusement(GuiGraphics g, int cx, int b, int ticks) {
        int r = 11, cy = b - r - 6;
        ln(g, cx, cy, cx - 6, b, 0xFF8A5A3A); ln(g, cx, cy, cx + 6, b, 0xFF8A5A3A); ln(g, cx + 1, cy, cx - 5, b, 0xFF8A5A3A); ln(g, cx + 1, cy, cx + 7, b, 0xFF8A5A3A);
        for (int a = 0; a < 36; a++) { double an = a * Math.PI / 18; rect(g, cx + (int) Math.round(Math.cos(an) * r), cy + (int) Math.round(Math.sin(an) * r), 1, 1, 0xFFE5484D); }
        int[] gc = {0xFFFFC832, 0xFF4D96FF, 0xFFFF8FB8, 0xFF6BCB77, 0xFFB57BD6, 0xFFFF9A3C};
        for (int i = 0; i < 6; i++) {
            double an = ticks / 90.0 + i * Math.PI / 3;
            int gx = cx + (int) Math.round(Math.cos(an) * r), gy = cy + (int) Math.round(Math.sin(an) * r);
            ln(g, cx, cy, gx, gy, 0x88FFFFFF); rect(g, gx - 1, gy, 3, 3, gc[i]); rect(g, gx - 1, gy + 2, 3, 1, mix(gc[i], 0xFF000000, 0.25F));
        }
        ball(g, cx, cy, 2, 0xFFFFD84D);
        rect(g, cx - 10, b - 2, 20, 2, 0xFF6E4726);
        for (int i = 0; i < 5; i++) rect(g, cx - 12 + i * 6, b - 4, 2, 2, (ticks / 12 + i) % 2 == 0 ? 0xFFFFE680 : 0xFFFF8FB8);     // blinking bulbs
    }

    private static void cinema(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 14, b - 15, 28, 15, 0xFF7A2848); rect(g, cx - 14, b - 15, 28, 1, 0xFF9A3A60);
        rect(g, cx - 16, b - 21, 32, 6, 0xFFFFC832); rect(g, cx - 16, b - 21, 32, 1, 0xFFFFE680); rect(g, cx - 16, b - 16, 32, 1, 0xFFC8952C);
        for (int i = 0; i < 8; i++) rect(g, cx - 14 + i * 4, b - 19, 2, 2, (ticks / 10 + i) % 2 == 0 ? 0xFFFFFFFF : 0xFFE5484D);          // chasing lights
        rect(g, cx - 11, b - 12, 7, 9, 0xFF3A1A5A); rect(g, cx - 10, b - 11, 5, 7, 0xFFB57BD6); ball(g, cx - 8, b - 8, 1, 0xFFFFE680);   // a poster
        rect(g, cx + 3, b - 12, 7, 9, 0xFF1A3A5A); rect(g, cx + 4, b - 11, 5, 7, 0xFF4D96FF); rect(g, cx + 5, b - 8, 3, 1, 0xFFFFFFFF);
        rect(g, cx - 2, b - 7, 4, 7, 0xFF3A1428);
        tri(g, cx, b - 27, 7, 6, 0xFFFF6B8E);
    }

    private static void museum(GuiGraphics g, int cx, int b, int ticks) {
        rect(g, cx - 15, b - 15, 30, 13, 0xFFD8C8A8);
        tri(g, cx, b - 27, 34, 9, 0xFFF0E4CC); rect(g, cx - 17, b - 18, 34, 3, 0xFFFFF8E8); rect(g, cx - 17, b - 16, 34, 1, 0xFFC8B890);
        ball(g, cx, b - 22, 2, 0xFFC8952C);
        for (int i = 0; i < 5; i++) { rect(g, cx - 14 + i * 7, b - 15, 3, 13, 0xFFFFFFFF); rect(g, cx - 12 + i * 7, b - 15, 1, 13, 0xFFD8CDB8); }
        rect(g, cx - 18, b - 2, 36, 2, 0xFFE8DCC8); rect(g, cx - 18, b - 2, 36, 1, 0xFFFFFFFF);
        if ((ticks / 14) % 3 != 0) { rect(g, cx + 12, b - 24, 3, 1, 0xFFFFFFFF); rect(g, cx + 13, b - 25, 1, 3, 0xFFFFFFFF); }
    }

    private static void camp(GuiGraphics g, int cx, int b, int ticks) {
        tri(g, cx - 11, b - 24, 12, 24, 0xFF1A5A38); tri(g, cx - 11, b - 16, 16, 16, 0xFF2A7048);
        rect(g, cx - 12, b - 2, 3, 2, 0xFF6A4228);
        tri(g, cx + 3, b - 17, 20, 17, 0xFFE8803A); tri(g, cx + 3, b - 17, 10, 17, 0xFFF4A860); tri(g, cx + 3, b - 8, 6, 8, 0xFF3A2A3A);
        int fx = cx + 16, fh = 5 + (ticks / 4) % 2;
        ball(g, fx, b - 4, 5, 0x22FFB040);
        rect(g, fx - 3, b - 1, 7, 1, 0xFF6A4228);
        tri(g, fx, b - 1 - fh, 5, fh, 0xFFFF7A2A); tri(g, fx, b - fh + 1, 3, fh - 2, 0xFFFFC832);
        rect(g, fx - 2 + (ticks / 6) % 3, b - fh - 3 - (ticks / 3) % 6, 1, 1, 0xFFFFD84D);
    }

    private static void oldHouse(GuiGraphics g, int cx, int b, int ticks, boolean lit) {
        if (lit) ball(g, cx, b - 14, 18, 0x18B57BD6);
        rect(g, cx - 12, b - 14, 24, 14, 0xFF3A2858); rect(g, cx - 12, b - 14, 1, 14, 0xFF4A3470);
        tri(g, cx, b - 29, 30, 15, 0xFF2A1A44); tri(g, cx - 1, b - 29, 14, 15, 0xFF3A2858);
        rect(g, cx + 6, b - 30, 3, 8, 0xFF2A1A44);
        for (int i = 0; i < 2; i++) {
            boolean on = (ticks / 22 + i * 4) % 7 != 0;
            rect(g, cx - 9 + i * 12, b - 11, 5, 6, on ? 0xFFFFD84D : 0xFF6A5030);
        }
        rect(g, cx - 2, b - 7, 5, 7, 0xFF120A20);
        ball(g, cx + 15, b - 3, 3, 0xFFE8803A); rect(g, cx + 15, b - 7, 1, 2, 0xFF3A7A3A);           // a pumpkin
        rect(g, cx + 14, b - 4, 1, 1, 0xFFFFF0A0); rect(g, cx + 16, b - 4, 1, 1, 0xFFFFF0A0);
        int bx = cx - 14 + (ticks / 3) % 28, by = b - 30 + (int) Math.round(Math.sin(ticks / 5.0) * 2);   // a bat
        boolean up = (ticks / 6) % 2 == 0;
        rect(g, bx + 1, by, 2, 2, 0xFF0A0614); rect(g, bx - 1, by + (up ? -1 : 1), 2, 1, 0xFF0A0614); rect(g, bx + 3, by + (up ? -1 : 1), 2, 1, 0xFF0A0614);
        rect(g, cx - 15, b - 8, 1, 8, 0xFF120A20); ln(g, cx - 15, b - 8, cx - 18, b - 13, 0xFF120A20); ln(g, cx - 15, b - 6, cx - 11, b - 12, 0xFF120A20);   // a bare tree
    }

    private static void fair(GuiGraphics g, int cx, int b, int ticks, boolean lit) {
        rect(g, cx - 11, b - 14, 22, 14, 0xFFFFF4DC);
        rect(g, cx - 12, b - 6, 24, 6, 0xFFC8955C); rect(g, cx - 12, b - 6, 24, 1, 0xFFE8B880);
        for (int k = 0; k < 24; k += 4) {
            rect(g, cx - 12 + k, b - 20, 4, 7, (k / 4) % 2 == 0 ? 0xFF4D96FF : 0xFFFFFFFF);
            rect(g, cx - 12 + k, b - 14, 4, 2, (k / 4) % 2 == 0 ? 0xFF2A5AC0 : 0xFFE0D8E0);
        }
        ball(g, cx - 3, b - 9, 2, 0xFFB57B4A); ball(g, cx + 4, b - 9, 2, 0xFFFF8FB8);
        int[] bc = {0xFFFF6B6B, 0xFFFFC832, 0xFF6BCB77};
        for (int i = 0; i < 3; i++) {
            int bx = cx - 9 + i * 9 + (int) Math.round(Math.sin((ticks + i * 15) / 18.0) * 2), by = b - 28 + (int) Math.round(Math.sin((ticks + i * 9) / 22.0));
            ball(g, bx, by, 3, bc[i]); rect(g, bx - 1, by - 2, 1, 1, 0x99FFFFFF); ln(g, bx, by + 4, cx - 9 + i * 9, b - 20, 0xAA8A7A8A);
        }
        for (int i = 0; i < 24; i += 6) tri(g, cx - 12 + i + 3, b - 22, 5, 3, lit ? ((ticks / 10 + i) % 2 == 0 ? 0xFFFFE680 : 0xFFFF8FB8) : 0xFFE5484D);
    }
}
