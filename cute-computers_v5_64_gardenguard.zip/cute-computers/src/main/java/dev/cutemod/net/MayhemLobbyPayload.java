package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: the open rooms and the room you are in (if any).
 * notice: 0 nothing, 1 the room is gone or full, 2 you were sent away, 3 not enough players to start, 4 the host left (you are the host now).
 * lives: the lives of every fighter (2, 3 or 5). map: the map of the room (0..6, 7 = a different one every round). slotType (4 numbers): 0 empty, 1 open (waiting for a person), 2 computer player, 3 person; slotName: the name of the person; slotLoad: the colour, class and pistol of each slot packed as colour | class << 4 | pistol << 8 (-1 for a computer player or an open slot, which are not chosen yet).
 */
public record MayhemLobbyPayload(int notice, List<String> hosts, List<Integer> open, boolean inRoom, boolean inGame, boolean youHost,
                                 int mySlot, List<Integer> slotType, List<String> slotName, List<Integer> slotLoad, int level, int lives, int map) implements CustomPacketPayload {
    public static final Type<MayhemLobbyPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "mayhem_lobby"));

    private static final StreamCodec<io.netty.buffer.ByteBuf, List<String>> NAMES =
            ByteBufCodecs.stringUtf8(32).apply(ByteBufCodecs.list(100));
    private static final StreamCodec<io.netty.buffer.ByteBuf, List<Integer>> INTS =
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(100));

    public static final StreamCodec<RegistryFriendlyByteBuf, MayhemLobbyPayload> STREAM_CODEC = StreamCodec.of((buf, p) -> {
        ByteBufCodecs.VAR_INT.encode(buf, p.notice());
        NAMES.encode(buf, p.hosts());
        INTS.encode(buf, p.open());
        ByteBufCodecs.BOOL.encode(buf, p.inRoom());
        ByteBufCodecs.BOOL.encode(buf, p.inGame());
        ByteBufCodecs.BOOL.encode(buf, p.youHost());
        ByteBufCodecs.VAR_INT.encode(buf, p.mySlot());
        INTS.encode(buf, p.slotType());
        NAMES.encode(buf, p.slotName());
        INTS.encode(buf, p.slotLoad());
        ByteBufCodecs.VAR_INT.encode(buf, p.level());
        ByteBufCodecs.VAR_INT.encode(buf, p.lives());
        ByteBufCodecs.VAR_INT.encode(buf, p.map());
    }, buf -> {
        int notice = ByteBufCodecs.VAR_INT.decode(buf);
        List<String> hosts = NAMES.decode(buf);
        List<Integer> open = INTS.decode(buf);
        boolean inRoom = ByteBufCodecs.BOOL.decode(buf);
        boolean inGame = ByteBufCodecs.BOOL.decode(buf);
        boolean youHost = ByteBufCodecs.BOOL.decode(buf);
        int mySlot = ByteBufCodecs.VAR_INT.decode(buf);
        List<Integer> types = INTS.decode(buf);
        List<String> names = NAMES.decode(buf);
        List<Integer> loads = INTS.decode(buf);
        int level = ByteBufCodecs.VAR_INT.decode(buf);
        int lives = ByteBufCodecs.VAR_INT.decode(buf);
        int map = ByteBufCodecs.VAR_INT.decode(buf);
        return new MayhemLobbyPayload(notice, hosts, open, inRoom, inGame, youHost, mySlot, types, names, loads, level, lives, map);
    });

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(MayhemLobbyPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onMayhemLobby(p));
    }
}
