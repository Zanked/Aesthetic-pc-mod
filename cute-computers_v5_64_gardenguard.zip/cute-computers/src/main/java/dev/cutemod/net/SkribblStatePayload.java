package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: the picture of a running game of Scribble Pals (everything except the drawing itself and the chat).
 * phase: 0 lobby, 1 the drawer picks a word, 2 drawing and guessing, 3 the word is shown, 4 the final scores.
 * word: the word number if this player may see it (he draws, he guessed it, or the turn is over), otherwise -1.
 * choices: the three words to pick from (only for the drawer, only while picking). hintEn / hintRu: the word as "_ _ A _".
 * guessedMask: the slots that have the word. timeLeft / timeTotal are in server ticks (20 a second).
 */
public record SkribblStatePayload(int phase, int round, int rounds, int drawer, int timeLeft, int timeTotal, int word, List<Integer> choices,
                                  String hintEn, String hintRu, List<Integer> scores, List<Integer> gains, int guessedMask, int likes,
                                  boolean liked) implements CustomPacketPayload {
    public static final Type<SkribblStatePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "skribbl_state"));

    private static final StreamCodec<io.netty.buffer.ByteBuf, List<Integer>> INTS =
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(16));

    public static final StreamCodec<RegistryFriendlyByteBuf, SkribblStatePayload> STREAM_CODEC = StreamCodec.of((buf, p) -> {
        ByteBufCodecs.VAR_INT.encode(buf, p.phase());
        ByteBufCodecs.VAR_INT.encode(buf, p.round());
        ByteBufCodecs.VAR_INT.encode(buf, p.rounds());
        ByteBufCodecs.VAR_INT.encode(buf, p.drawer() + 1);
        ByteBufCodecs.VAR_INT.encode(buf, p.timeLeft());
        ByteBufCodecs.VAR_INT.encode(buf, p.timeTotal());
        ByteBufCodecs.VAR_INT.encode(buf, p.word() + 1);
        INTS.encode(buf, p.choices());
        ByteBufCodecs.stringUtf8(120).encode(buf, p.hintEn());
        ByteBufCodecs.stringUtf8(120).encode(buf, p.hintRu());
        INTS.encode(buf, p.scores());
        INTS.encode(buf, p.gains());
        ByteBufCodecs.VAR_INT.encode(buf, p.guessedMask());
        ByteBufCodecs.VAR_INT.encode(buf, p.likes());
        ByteBufCodecs.BOOL.encode(buf, p.liked());
    }, buf -> new SkribblStatePayload(
            ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf) - 1, ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf) - 1, INTS.decode(buf), ByteBufCodecs.stringUtf8(120).decode(buf),
            ByteBufCodecs.stringUtf8(120).decode(buf), INTS.decode(buf), INTS.decode(buf), ByteBufCodecs.VAR_INT.decode(buf),
            ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.BOOL.decode(buf)));

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(SkribblStatePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onSkribblState(p));
    }
}
