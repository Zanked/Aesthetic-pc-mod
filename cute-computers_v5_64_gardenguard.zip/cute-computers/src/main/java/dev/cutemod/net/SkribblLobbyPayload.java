package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: the open rooms of Scribble Pals and the room you are in (if any).
 * notice: 0 nothing, 1 the room is gone or full, 2 you were sent away, 4 the host left (you are the host now).
 * slotType (8 numbers): 0 empty, 1 open (waiting for a person), 2 computer player, 3 person. roundsIdx / secondsIdx: the picked settings (0..2).
 */
public record SkribblLobbyPayload(int notice, List<String> hosts, List<Integer> open, boolean inRoom, boolean inGame, boolean youHost,
                                  int mySlot, List<Integer> slotType, List<String> slotName, int roundsIdx, int secondsIdx) implements CustomPacketPayload {
    public static final Type<SkribblLobbyPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "skribbl_lobby"));

    private static final StreamCodec<io.netty.buffer.ByteBuf, List<String>> NAMES =
            ByteBufCodecs.stringUtf8(32).apply(ByteBufCodecs.list(100));
    private static final StreamCodec<io.netty.buffer.ByteBuf, List<Integer>> INTS =
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(100));

    public static final StreamCodec<RegistryFriendlyByteBuf, SkribblLobbyPayload> STREAM_CODEC = StreamCodec.of((buf, p) -> {
        ByteBufCodecs.VAR_INT.encode(buf, p.notice());
        NAMES.encode(buf, p.hosts());
        INTS.encode(buf, p.open());
        ByteBufCodecs.BOOL.encode(buf, p.inRoom());
        ByteBufCodecs.BOOL.encode(buf, p.inGame());
        ByteBufCodecs.BOOL.encode(buf, p.youHost());
        ByteBufCodecs.VAR_INT.encode(buf, p.mySlot());
        INTS.encode(buf, p.slotType());
        NAMES.encode(buf, p.slotName());
        ByteBufCodecs.VAR_INT.encode(buf, p.roundsIdx());
        ByteBufCodecs.VAR_INT.encode(buf, p.secondsIdx());
    }, buf -> {
        int notice = ByteBufCodecs.VAR_INT.decode(buf);
        List<String> hosts = NAMES.decode(buf);
        List<Integer> open = INTS.decode(buf);
        boolean inRoom = ByteBufCodecs.BOOL.decode(buf);
        boolean inGame = ByteBufCodecs.BOOL.decode(buf);
        boolean youHost = ByteBufCodecs.BOOL.decode(buf);
        int mySlot = ByteBufCodecs.VAR_INT.decode(buf);
        List<Integer> types = INTS.decode(buf);
        List<String> names = NAMES.decode(buf);
        int ri = ByteBufCodecs.VAR_INT.decode(buf);
        int si = ByteBufCodecs.VAR_INT.decode(buf);
        return new SkribblLobbyPayload(notice, hosts, open, inRoom, inGame, youHost, mySlot, types, names, ri, si);
    });

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(SkribblLobbyPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onSkribblLobby(p));
    }
}
