package dev.cutemod.data;

import java.util.Locale;

/**
 * The words of Scribble Pals, every one in English and in Russian ("en|ru"). The server accepts a guess in either language;
 * every player sees the word in the language of his own game. The first {@link #ART} words are the ones the computer
 * artists know how to draw ({@link SkribblArt}).
 */
public final class SkribblWords {
    private SkribblWords() {}

    private static final String[] WORDS = {
            // the computer players can draw these (keep the order: SkribblArt uses the numbers)
            "sun|солнце", "moon|луна", "star|звезда", "heart|сердце", "flower|цветок", "tree|дерево", "house|дом", "cat|кот",
            "fish|рыба", "apple|яблоко", "cake|торт", "car|машина", "boat|лодка", "umbrella|зонт", "mushroom|гриб", "snowman|снеговик",
            "ghost|привидение", "bee|пчела", "panda|панда", "rabbit|кролик", "ice cream|мороженое", "cloud|облако", "balloon|шарик",
            "pumpkin|тыква", "cup|чашка", "key|ключ", "crown|корона", "rainbow|радуга",
            // only people draw these
            "dog|собака", "bird|птица", "bear|медведь", "penguin|пингвин", "owl|сова", "frog|лягушка", "pig|свинья", "cow|корова",
            "mouse|мышь", "spider|паук", "butterfly|бабочка", "snail|улитка", "turtle|черепаха", "dragon|дракон", "unicorn|единорог",
            "mermaid|русалка", "witch|ведьма", "vampire|вампир", "zombie|зомби", "creeper|крипер", "pickaxe|кирка", "sword|меч",
            "diamond|алмаз", "torch|факел", "bed|кровать", "chair|стул", "table|стол", "door|дверь", "window|окно", "lamp|лампа",
            "clock|часы", "book|книга", "pencil|карандаш", "scissors|ножницы", "glasses|очки", "hat|шляпа", "shoe|ботинок",
            "sock|носок", "scarf|шарф", "dress|платье", "bag|сумка", "phone|телефон", "computer|компьютер", "keyboard|клавиатура",
            "headphones|наушники", "guitar|гитара", "piano|пианино", "drum|барабан", "camera|камера", "pizza|пицца", "burger|бургер",
            "sushi|суши", "donut|пончик", "cookie|печенье", "candy|конфета", "banana|банан", "strawberry|клубника", "carrot|морковь",
            "bread|хлеб", "coffee|кофе", "tea|чай", "egg|яйцо", "plane|самолёт", "train|поезд", "bicycle|велосипед", "rocket|ракета",
            "lighthouse|маяк", "castle|замок", "bridge|мост", "mountain|гора", "volcano|вулкан", "island|остров", "campfire|костёр",
            "tent|палатка", "snowflake|снежинка", "lightning|молния", "tornado|торнадо", "planet|планета", "robot|робот",
            "ninja|ниндзя", "pirate|пират", "angel|ангел", "skeleton|скелет", "popcorn|попкорн", "bubble tea|бабл ти",
            "kitten|котёнок", "teddy bear|плюшевый мишка", "gift|подарок", "bell|колокольчик", "feather|перо", "wizard|волшебник"};

    public static final int ART = 28;

    public static int count() { return WORDS.length; }

    public static String en(int i) { return WORDS[i].substring(0, WORDS[i].indexOf('|')); }

    public static String ru(int i) { return WORDS[i].substring(WORDS[i].indexOf('|') + 1); }

    /** The word in the given language code ("ru_ru", "en_us"...). */
    public static String word(int i, String lang) {
        if (i < 0 || i >= WORDS.length) return "";
        return lang != null && lang.toLowerCase(Locale.ROOT).startsWith("ru") ? ru(i) : en(i);
    }

    /** Lower case, no spaces, ё = е: so that "Ice  Cream" and "icecream" are the same guess. */
    public static String norm(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toLowerCase(Locale.ROOT).toCharArray()) {
            if (c == 'ё') c = 'е';
            if (Character.isLetterOrDigit(c)) b.append(c);
        }
        return b.toString();
    }

    public static boolean matches(int word, String guess) {
        String g = norm(guess);
        return !g.isEmpty() && (g.equals(norm(en(word))) || g.equals(norm(ru(word))));
    }

    /** One letter wrong, missing or extra, in a word of at least four letters: "so close!". */
    public static boolean close(int word, String guess) {
        String g = norm(guess);
        if (g.length() < 4) return false;
        return dist(g, norm(en(word))) == 1 || dist(g, norm(ru(word))) == 1;
    }

    private static int dist(String a, String b) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++)
                cur[j] = Math.min(Math.min(cur[j - 1], prev[j]) + 1, prev[j - 1] + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1));
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }

    /**
     * What the guessers see: one "_" for every letter (spaces stay as gaps) and the letters that were given as hints.
     * {@code reveal} letters are shown, in the order of a shuffle that depends on the seed (all players see the same ones).
     */
    public static String hint(String word, int reveal, long seed) {
        int n = word.length();
        int[] order = new int[n];
        int k = 0;
        for (int i = 0; i < n; i++) if (Character.isLetterOrDigit(word.charAt(i))) order[k++] = i;
        java.util.Random r = new java.util.Random(seed);
        for (int i = k - 1; i > 0; i--) { int j = r.nextInt(i + 1); int t = order[i]; order[i] = order[j]; order[j] = t; }
        boolean[] shown = new boolean[n];
        for (int i = 0; i < Math.min(reveal, Math.max(0, k - 2)); i++) shown[order[i]] = true;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < n; i++) {
            char c = word.charAt(i);
            if (!Character.isLetterOrDigit(c)) b.append("  ");
            else b.append(shown[i] ? Character.toUpperCase(c) : '_').append(' ');
        }
        return b.toString().trim();
    }
}
