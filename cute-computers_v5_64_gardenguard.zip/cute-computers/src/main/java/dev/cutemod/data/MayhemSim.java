package dev.cutemod.data;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The world of Dangerous Weapons, without a single Minecraft class: four fighters (people or computer players) on marble
 * platforms, bullets, grenades, mines, crates, the rules and the computer players. It runs in the single-player game (60 steps a
 * second, in the client) and on the server for online rooms (3 steps per server tick, 20 snapshots a second via {@link #pack()}).
 * The client never decides anything online: it sends the keys, receives the snapshot ({@link #unpack(byte[])}) and draws it.
 * <p>
 * Everything the client needs for the looks and sounds (a shot, a hit, a blast, a jump...) is announced as an <b>event</b>
 * ({@link #events}), so particles and sounds are never part of the rules.
 */
public final class MayhemSim {
    public static final int W = 220, H = 140, N = 4;
    public static final int PH_COUNT = 1, PH_PLAY = 2, PH_END = 3;
    public static final int KIND_OFF = 0, KIND_HUMAN = 1, KIND_BOT = 2;

    public static final int PISTOL = 0, SMG = 1, SHOTGUN = 2, SNIPER = 3, ROCKET = 4, GRENADE = 5, FLAME = 6, LASER = 7, MINE = 8, ICE = 9,
            BOOMER = 10, TESLA = 11, HARPOON = 12, CLUSTER = 13, SLIME = 14, SWAP = 15, WEAPONS = 16;
    /** A little bomb that a cluster bomb throws out (a bullet type, not a weapon). */
    public static final int MINIBOMB = 16;

    // ------------------------------------------------------------------ loadouts: colour, class (perks), starting pistol
    public static final int COLORS = 10, CLASSES = 5, PISTOLS = 7;

    /**
     * Perks: one bit each, and a class is just a set of perks. To add a perk: add a bit here, put it into a class in CLASS_PERKS
     * (or into several), write its effect where it belongs (grep for one of the PERK_ names to see how the others are done)
     * and add its name and its description to the language files (cutemod.mayhem.perk.N and cutemod.mayhem.perk.N.d).
     */
    public static final int PERK_NO_WEIGHT = 1, PERK_TRIPLE_JUMP = 2, PERK_NO_RECOIL = 4, PERK_BLAST_SHIELD = 8, PERK_EXTRA_AMMO = 16,
            PERK_EXTRA_EXPLOSIVES = 32, PERK_RANDOM_GUN = 64, PERK_INFINITE_PISTOL = 128, PERK_QUACKING = 256, PERKS = 9;
    /** Soldier, Scout, Gunslinger, Demolition, Gambler. */
    public static final int[] CLASS_PERKS = {PERK_EXTRA_AMMO | PERK_BLAST_SHIELD, PERK_TRIPLE_JUMP | PERK_NO_WEIGHT,
            PERK_INFINITE_PISTOL | PERK_NO_RECOIL, PERK_EXTRA_EXPLOSIVES | PERK_QUACKING | PERK_BLAST_SHIELD, PERK_RANDOM_GUN | PERK_EXTRA_AMMO};
    /** A small trait of a class that is not a perk: how fast it runs. */
    public static final float[] CLASS_SPEED = {1F, 1F, 1F, 1F, 1F};
    /** How far a class is thrown by a hit: a light fighter flies farther, a heavy one less far. */
    public static final float[] CLASS_KB = {0.95F, 1.36F, 0.97F, 0.95F, 0.9F};

    /**
     * The seven starting pistols: damage, steps between shots, magazine, steps of reloading, the push back on the shooter, the push
     * on the one who is hit, the speed of the bullet, how fast the owner runs, the range (px) and how far a computer player shoots.
     * They are balanced by their sustained damage (damage x magazine / (magazine x pause + reload)), which is about the same for all of
     * them; a pistol is strong where another is weak. The golden pistol has a 15% chance for a double hit.
     */
    public static final float[] P_DMG = {5F, 9.6F, 2.8F, 8.6F, 3.5F, 13.5F, 5F};
    public static final int[] P_CD = {18, 32, 9, 26, 14, 46, 20}, P_MAG = {12, 7, 18, 6, 14, 5, 9}, P_RELOAD = {60, 70, 90, 70, 72, 90, 60};
    public static final float[] P_REC = {0.25F, 0.7F, 0.1F, 0.55F, 0.12F, 1.1F, 0.25F}, P_KB = {1.0F, 1.3F, 0.6F, 1.2F, 0.8F, 1.8F, 1.0F},
            P_SPD = {4.2F, 5F, 4.6F, 5.2F, 3.8F, 5.6F, 4.4F}, P_MOVE = {1F, 1F, 1F, 1F, 1F, 1F, 1F};
    public static final int[] P_RMAX = {120, 125, 120, 122, 120, 128, 120}, P_RANGE = {55, 58, 55, 56, 55, 60, 55};
    public static final int GOLDEN = 6;
    /** How much a weapon in the hands slows a fighter down (the perk "no weight" takes it away). */
    public static final float[] WEIGHT = {1F, 1F, 0.96F, 0.9F, 0.9F, 0.92F, 0.93F, 0.97F, 1F, 1F, 1F, 0.97F, 0.94F, 0.92F, 1F, 1F};

    /** Bonuses: a glowing orb falls from the sky and gives its gift to whoever touches it. */
    public static final int B_HEAL = 0, B_SHIELD = 1, B_SPEED = 2, B_WINGS = 3, B_RAGE = 4, B_HASTE = 5, B_LIFE = 6, BONUSES = 7;
    /** How often a bonus orb holds each bonus (per 100) and how many steps (1/60 s) it lasts. */
    public static final int[] BONUS_W = {16, 12, 20, 16, 18, 14, 4}, BONUS_T = {0, 300, 480, 450, 480, 480, 0};

    /** Keys of a person: left, right, down, fire (held), jump (held). */
    public static final int K_LEFT = 1, K_RIGHT = 2, K_DOWN = 4, K_FIRE = 8, K_JUMP = 16;

    // events (what the client turns into particles and sounds). int[]{type, a, b, c, d, e}; positions are x16.
    public static final int EV_SHOOT = 1;          // a fighter, b weapon, c x, d y (the muzzle), e face
    public static final int EV_JUMP = 2;           // a fighter, b x, c y, d 1 = the second jump
    public static final int EV_LAND = 3;           // a x, b y
    public static final int EV_HIT = 4;            // a victim, b weapon, c x, d y, e bit 1 = thrown to the right, bit 2 = a strong hit
    public static final int EV_EXPLODE = 5;        // a x, b y, c size x10
    public static final int EV_DIE = 6;            // a fighter, b x, c y
    public static final int EV_RESPAWN = 7;        // a fighter, b x
    public static final int EV_PICKUP = 8;         // a fighter, b weapon, c x, d y
    public static final int EV_CRATE_LAND = 9;     // a x, b y, c weapon or bonus, d 1 = a bonus
    public static final int EV_FREEZE = 10;        // a fighter
    public static final int EV_THAW = 11;          // a fighter
    public static final int EV_LASER = 12;         // a x1, b y, c x2
    public static final int EV_EMPTY = 13;         // a fighter (the weapon ran out)
    public static final int EV_ZAP = 14;           // a x1, b y1, c x2, d y2 (a spark of the Tesla coil)
    public static final int EV_BONUS = 15;         // a fighter, b bonus, c x, d y
    public static final int EV_BLOCK = 16;         // a fighter, b x, c y (a shield took a hit)
    public static final int EV_SWAP = 17;          // a fighter, b the other one, c x, d y (where a fighter arrives)
    public static final int EV_SLOW = 18;          // a fighter (covered in slime)
    public static final int EV_RELOAD = 19;        // a fighter (the pistol is empty: reloading)

    /**
     * The maps. Every platform is one-way: jump up through it, S drops down. x, y (the top) and the width of every platform,
     * where the four fighters start (x and the number of the platform), the gravity, how much the floor slips (the closer
     * to 1, the more) and how fast a fighter speeds up on the floor.
     * 0 Marble Isles (3 looks: sunset, ocean, night), 1 Floating Islands, 2 Ice Peaks (slippery), 3 Canyon Bridge,
     * 4 Space Station (low gravity), 5 Candy Land, 6 Volcano.
     */
    public static final int MAPS = 7, RANDOM_MAP = MAPS;
    public static final int[][] MAP_X = {{18, 22, 140, 82}, {66, 6, 164, 34, 134, 94}, {24, 52, 84, 6, 182}, {8, 26, 154, 30, 140, 92},
            {50, 8, 148, 80, 18, 174}, {8, 148, 44, 112, 78, 6, 180}, {44, 4, 182, 78, 26, 158}};
    public static final int[][] MAP_Y = {{104, 72, 72, 42}, {98, 80, 80, 52, 52, 28}, {108, 82, 56, 64, 64}, {92, 58, 58, 120, 120, 40},
            {112, 82, 82, 52, 40, 40}, {112, 112, 86, 86, 58, 58, 58}, {100, 78, 78, 64, 40, 40}};
    public static final int[][] MAP_W = {{184, 58, 58, 56}, {88, 50, 50, 52, 52, 32}, {172, 116, 52, 32, 32}, {204, 40, 40, 50, 50, 36},
            {120, 64, 64, 60, 28, 28}, {64, 64, 64, 64, 64, 34, 34}, {132, 36, 36, 64, 36, 36}};
    public static final int[][] MAP_SPAWN = {{50, 0, 86, 0, 134, 0, 170, 0}, {24, 1, 80, 0, 140, 0, 192, 2}, {44, 0, 84, 0, 136, 0, 176, 0},
            {40, 0, 84, 0, 136, 0, 176, 0}, {62, 0, 92, 0, 128, 0, 158, 0}, {22, 0, 52, 0, 160, 1, 190, 1}, {62, 0, 92, 0, 128, 0, 158, 0}};
    public static final float[] MAP_GRAV = {0.13F, 0.13F, 0.13F, 0.13F, 0.09F, 0.13F, 0.13F};
    public static final float[] MAP_FRIC = {0.78F, 0.78F, 0.94F, 0.78F, 0.78F, 0.78F, 0.78F};
    public static final float[] MAP_ACC = {0.28F, 0.28F, 0.11F, 0.28F, 0.28F, 0.28F, 0.28F};

    // weapons: pistol, SMG, shotgun, sniper rifle, rocket launcher, grenade launcher, flamethrower, laser rifle, mine layer, ice gun
    public static final int[] CD = {20, 5, 42, 62, 56, 50, 3, 40, 60, 26, 34, 26, 52, 64, 24, 70},
            AMMO = {0, 42, 8, 5, 4, 6, 80, 8, 5, 10, 8, 14, 6, 4, 12, 4},
            PEL = {1, 1, 5, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            LIFE = {70, 56, 20, 60, 130, 90, 18, 1, 900, 60, 150, 1, 50, 70, 60, 70};
    public static final float[] DMG = {5F, 2.2F, 2.4F, 14F, 12F, 10F, 2.4F, 9F, 12F, 4F, 5F, 6F, 11F, 9F, 2F, 0F},
            KB = {1.0F, 0.45F, 0.6F, 2.4F, 3.2F, 2.6F, 0.25F, 1.8F, 3.0F, 0.4F, 0.9F, 0.5F, 2.2F, 2.2F, 0.3F, 0F},
            SPD = {4.2F, 4.8F, 4.2F, 9F, 2.1F, 2.4F, 2.3F, 0F, 0F, 3.6F, 3.4F, 0F, 6.5F, 2.5F, 3.2F, 4.5F},
            REC = {0.25F, 0.07F, 1.7F, 2.2F, 1.5F, 0.9F, 0.05F, 0.8F, 0.2F, 0.3F, 0.2F, 0.1F, 1.2F, 1.0F, 0.2F, 0.2F},
            SPR = {0F, 0.07F, 0.2F, 0F, 0F, 0F, 0.22F, 0F, 0F, 0.02F, 0F, 0F, 0F, 0F, 0.04F, 0F};
    public static final int[] RANGE = {55, 50, 28, 95, 80, 60, 18, 90, 20, 55, 70, 50, 85, 65, 55, 70},
            RMAX = {120, 110, 64, 200, 150, 110, 34, 200, 40, 110, 120, 85, 170, 115, 110, 130};
    /** How often a crate holds each weapon (per 100), index = weapon. */
    public static final int[] CRATE_W = {0, 13, 11, 6, 9, 8, 8, 6, 6, 5, 6, 5, 5, 4, 5, 3};
    private static final int[] REACT = {26, 14, 6}, FIRE = {35, 60, 100}, DODGE = {4, 12, 34};

    public static final class Fighter {
        public final int id;
        public int kind;
        public boolean alive, out, ground;
        public int face = 1, jumps, coyote, plat = -1, dropT, weapon, ammo, cd, respT, invT, hitT, flash, kills, deaths, lastHit = -1, lastHitT, anim, lives, frozenT, shieldT, speedT, wingsT, rageT, hasteT, slowT, color, cls, pistol, perks, reloadT;
        public float x, y, vx, vy, dmg, dealt;
        // what the fighter does now (people: from the keys, computer players: from the bot code)
        public boolean inL, inR, inDown, inFire, inJump;
        int bits, target = -1, thinkT, reactT, downT;
        boolean prevJump, jumpReq, fireReq, keepFace;

        public Fighter(int id) { this.id = id; color = id; cls = id % CLASSES; perks = CLASS_PERKS[cls]; }

        public boolean has(int perk) { return (perks & perk) != 0; }
    }

    public static final class Bullet { public float x, y, vx, vy, dmg, ax; public int owner, type, life, aux; }

    public static final class Mine { public float x, y, vx, vy; public int owner, arm, life; boolean ground; }

    /** kind 0: a crate with a weapon (weapon = which); kind 1: a bonus orb (weapon = which bonus). */
    public static final class Crate { public float x, y; public int weapon, life, kind; public boolean landed; }

    public final Fighter[] f = new Fighter[N];
    public final List<Bullet> bullets = new ArrayList<>();
    public final List<Mine> mines = new ArrayList<>();
    public final List<Crate> crates = new ArrayList<>();
    public final List<Integer> elim = new ArrayList<>();
    public final List<int[]> events = new ArrayList<>();

    public int phase, phaseT, ticks, winner = -1, theme, freeze, lives = 3, skill = 1, crateT, bonusT, map, lowY;
    /** The platforms of the map in play (the rows of MAP_X, MAP_Y, MAP_W). */
    public int[] px = MAP_X[0], py = MAP_Y[0], pw = MAP_W[0];
    private float grav = 0.13F, fric = 0.78F, accG = 0.28F;
    public boolean over;
    private final Random rnd;

    public MayhemSim() { this(new Random()); }

    public MayhemSim(Random rnd) {
        this.rnd = rnd;
        for (int i = 0; i < N; i++) f[i] = new Fighter(i);
    }

    // ------------------------------------------------------------------ set up

    /** Puts a person (KIND_HUMAN) or a computer player (KIND_BOT) into a slot, or empties it (KIND_OFF). */
    public void setup(int slot, int kind) {
        f[slot] = new Fighter(slot);
        f[slot].kind = kind;
    }

    /** map: 0..MAPS-1, or anything else (RANDOM_MAP) for a random one; theme (the look of the Marble Isles): 0..2 or -1 for a random one. */
    /** The look and the kit of a fighter: colour 0..COLORS-1, class 0..CLASSES-1, starting pistol 0..PISTOLS-1. Before start(). */
    public void setLoadout(int slot, int color, int cls, int pistol) {
        Fighter q = f[slot];
        q.color = Math.floorMod(color, COLORS); q.cls = Math.floorMod(cls, CLASSES); q.pistol = Math.floorMod(pistol, PISTOLS);
        q.perks = CLASS_PERKS[q.cls];
    }

    // ------------------------------------------------------------------ ammunition

    /** The magazine of the pistol of a fighter. */
    public int pistolMag(Fighter q) { return q.has(PERK_EXTRA_AMMO) ? Math.round(P_MAG[q.pistol] * 1.33F) : P_MAG[q.pistol]; }

    /** How many shots a weapon that a fighter picks up has. */
    public int ammoFor(Fighter q, int w) {
        if (w == PISTOL) return pistolMag(q);
        int a = AMMO[w];
        if (q.has(PERK_EXTRA_EXPLOSIVES) && (w == ROCKET || w == GRENADE || w == CLUSTER || w == MINE)) a += 2;
        return q.has(PERK_EXTRA_AMMO) ? Math.round(a * 1.33F) : a;
    }

    private void giveWeapon(Fighter q, int w) {
        q.weapon = w; q.ammo = ammoFor(q, w); q.reloadT = 0;
    }

    /** The perk "random gun": a random weapon (the same odds as in the crates). */
    private void randomGun(Fighter q) {
        int r = rnd.nextInt(100);
        for (int w = 1, acc = 0; w < CRATE_W.length; w++) { acc += CRATE_W[w]; if (r < acc) { giveWeapon(q, w); return; } }
        giveWeapon(q, SMG);
    }

    private void backToPistol(Fighter q) {
        giveWeapon(q, PISTOL);
        q.cd = Math.max(q.cd, 12);
    }

    private boolean canShoot(Fighter q) {
        if (q.reloadT > 0) return false;
        return q.ammo > 0 || (q.weapon == PISTOL && q.has(PERK_INFINITE_PISTOL));
    }

    private int jumpsOnLand(Fighter q) { return Math.max(q.wingsT > 0 ? 3 : 1, q.has(PERK_TRIPLE_JUMP) ? 2 : 1); }

    private int rangeOf(Fighter q) { return q.weapon == PISTOL ? P_RANGE[q.pistol] : RANGE[q.weapon]; }

    private int rmaxOf(Fighter q) { return q.weapon == PISTOL ? P_RMAX[q.pistol] : RMAX[q.weapon]; }

    public void configure(int lives, int skill, int theme, int map) {
        this.lives = Math.max(1, Math.min(9, lives));
        this.skill = Math.max(0, Math.min(2, skill));
        this.theme = theme < 0 ? rnd.nextInt(3) : theme % 3;
        setMap(map < 0 || map >= MAPS ? rnd.nextInt(MAPS) : map);
    }

    public void setMap(int m) {
        map = Math.max(0, Math.min(MAPS - 1, m));
        px = MAP_X[map]; py = MAP_Y[map]; pw = MAP_W[map];
        grav = MAP_GRAV[map]; fric = MAP_FRIC[map]; accG = MAP_ACC[map];
        lowY = 0;
        for (int y : py) lowY = Math.max(lowY, y);
    }

    public void start() {
        bullets.clear(); mines.clear(); crates.clear(); elim.clear(); events.clear();
        winner = -1; over = false; freeze = 0; ticks = 0;
        boolean[] used = new boolean[COLORS];
        for (int pass = 0; pass < 2; pass++) {
            for (Fighter q : f) {
                if (q.kind == KIND_OFF || (q.kind == KIND_HUMAN) != (pass == 0)) continue;
                while (used[q.color]) q.color = (q.color + 1) % COLORS;
                used[q.color] = true;
            }
        }
        for (int i = 0; i < N; i++) {
            Fighter q = f[i];
            if (q.kind == KIND_OFF) { q.out = true; q.alive = false; continue; }
            q.lives = lives; q.alive = true; q.out = false;
            int[] sp = MAP_SPAWN[map];
            q.x = sp[i * 2]; q.plat = sp[i * 2 + 1]; q.y = py[q.plat]; q.ground = true; q.jumps = jumpsOnLand(q);
            q.weapon = PISTOL; q.ammo = pistolMag(q); q.reloadT = 0;
            if (q.has(PERK_RANDOM_GUN)) randomGun(q);
            q.face = q.x < W / 2F ? 1 : -1;
            q.thinkT = rnd.nextInt(20);
        }
        phase = PH_COUNT; phaseT = 150; crateT = 300; bonusT = 700;
    }

    public int active() {
        int n = 0;
        for (Fighter q : f) if (q.kind != KIND_OFF) n++;
        return n;
    }

    /** A person put in the keys he holds (K_* bits) and what he pressed since the last call (taps would be lost otherwise). */
    public void input(int slot, int bits, boolean jumpPress, boolean firePress) {
        if (slot < 0 || slot >= N) return;
        Fighter q = f[slot];
        q.bits = bits;
        if (jumpPress) q.jumpReq = true;
        if (firePress) q.fireReq = true;
    }

    /** A person leaves a running round: he is out. */
    public void drop(int slot) {
        if (slot < 0 || slot >= N) return;
        Fighter q = f[slot];
        if (q.kind == KIND_OFF || q.out || phase == 0) return;
        q.alive = false; q.out = true; q.lives = 0;
        elim.add(slot);
    }

    // ------------------------------------------------------------------ results

    public int place(int slot) {
        if (winner == slot) return 1;
        int idx = elim.indexOf(slot);
        return idx < 0 ? active() : active() - idx;
    }

    public int scoreOf(int slot) {
        Fighter m = f[slot];
        int p = place(slot);
        return m.kills * 15 + (p == 1 ? 50 : p == 2 ? 25 : p == 3 ? 10 : 0) + (int) (m.dealt / 10F);
    }

    // ------------------------------------------------------------------ helpers

    private static int fx(float v) { return Math.round(v * 16F); }

    private static int sign(float v) { return v < 0 ? -1 : 1; }

    private void ev(int type, int a, int b, int c, int d, int e) {
        if (events.size() < 300) events.add(new int[]{type, a, b, c, d, e});
    }

    // ------------------------------------------------------------------ one step (1/60 s)

    public void tick() {
        if (over || phase == 0) return;
        ticks++;
        if (phase == PH_COUNT) {
            for (Fighter q : f) if (q.kind != KIND_OFF) { q.anim++; q.jumpReq = false; q.fireReq = false; }
            if (--phaseT <= 0) phase = PH_PLAY;
            return;
        }
        if (freeze > 0) { freeze--; return; }
        boolean live = phase == PH_PLAY;
        for (Fighter q : f) {
            if (q.kind == KIND_OFF) continue;
            q.inL = q.inR = q.inDown = q.inFire = q.inJump = false;
            if (live && q.alive) {
                if (q.kind == KIND_BOT) bot(q, true);
                else {
                    boolean jump = (q.bits & K_JUMP) != 0;
                    q.inL = (q.bits & K_LEFT) != 0; q.inR = (q.bits & K_RIGHT) != 0; q.inDown = (q.bits & K_DOWN) != 0;
                    q.inFire = (q.bits & K_FIRE) != 0 || q.fireReq;
                    q.inJump = (jump && !q.prevJump) || q.jumpReq;
                    q.prevJump = jump;
                }
            }
            q.jumpReq = false; q.fireReq = false;
        }
        for (Fighter q : f) if (q.kind != KIND_OFF) step(q);
        if (live) {
            for (Fighter q : f) {
                if (q.kind != KIND_OFF && q.alive && q.inFire && q.cd <= 0 && q.hitT < 10 && canShoot(q)) shoot(q);
            }
        }
        stepBullets();
        stepMines();
        stepCrates(live);
        if (live) {
            int left = 0, last = -1;
            for (Fighter q : f) if (!q.out) { left++; last = q.id; }
            if (left <= 1) {
                winner = left == 1 ? last : -1;
                phase = PH_END; phaseT = 170;
            }
        } else if (--phaseT <= 0) {
            over = true;
        }
    }

    private void step(Fighter f) {
        if (!f.alive) {
            if (!f.out && phase == PH_PLAY && --f.respT <= 0) respawn(f);
            return;
        }
        f.anim++;
        if (f.cd > 0) f.cd--;
        if (f.reloadT > 0 && --f.reloadT == 0 && f.weapon == PISTOL) f.ammo = pistolMag(f);
        if (f.invT > 0) f.invT--;
        if (f.hitT > 0) f.hitT--;
        if (f.flash > 0) f.flash--;
        if (f.lastHitT > 0) f.lastHitT--;
        if (f.dropT > 0) f.dropT--;
        if (f.shieldT > 0) f.shieldT--;
        if (f.speedT > 0) f.speedT--;
        if (f.wingsT > 0) f.wingsT--;
        if (f.rageT > 0) f.rageT--;
        if (f.hasteT > 0) f.hasteT--;
        if (f.slowT > 0) f.slowT--;
        if (f.frozenT > 0) {
            f.frozenT--;
            f.inL = f.inR = f.inJump = f.inDown = f.inFire = false;
            if (f.frozenT == 0) ev(EV_THAW, f.id, 0, 0, 0, 0);
        }
        boolean steer = f.hitT < 8 && f.frozenT <= 0;
        int dir = (f.inR ? 1 : 0) - (f.inL ? 1 : 0);
        float max = 1.2F * (f.speedT > 0 ? 1.5F : 1F) * (f.slowT > 0 ? 0.45F : 1F) * CLASS_SPEED[f.cls]
                * (f.has(PERK_NO_WEIGHT) ? 1F : WEIGHT[f.weapon]) * (f.weapon == PISTOL ? P_MOVE[f.pistol] : 1F);
        if (steer && dir != 0) {
            if (!f.keepFace) f.face = dir;
            float acc = (f.ground ? accG : 0.12F) * (f.speedT > 0 ? 1.4F : 1F) * (f.slowT > 0 ? 0.6F : 1F);
            if (dir > 0 && f.vx < max) f.vx = Math.min(max, f.vx + acc);
            else if (dir < 0 && f.vx > -max) f.vx = Math.max(-max, f.vx - acc);
        } else if (f.ground) f.vx *= fric;
        else f.vx *= 0.995F;
        if (Math.abs(f.vx) > max) f.vx *= f.ground ? Math.max(0.9F, fric) : 0.99F;

        if (f.inJump && steer) {
            if (f.ground || f.coyote > 0) {
                f.vy = f.slowT > 0 ? -2.6F : -3.15F; f.ground = false; f.coyote = 0; f.dropT = 0;
                ev(EV_JUMP, f.id, fx(f.x), fx(f.y), 0, 0);
            } else if (f.jumps > 0) {
                f.vy = f.has(PERK_TRIPLE_JUMP) && f.wingsT <= 0 && f.jumps == 1 ? -2.3F : -2.8F; f.jumps--;
                ev(EV_JUMP, f.id, fx(f.x), fx(f.y - 2), 1, 0);
            }
        }
        if (f.inDown && f.ground && steer) { f.dropT = 12; f.ground = false; f.coyote = 0; }

        f.vy += grav;
        if (f.inDown && !f.ground) f.vy += 0.1F;
        if (f.vy > 4.8F) f.vy = 4.8F;
        float py0 = f.y;
        f.x += f.vx;
        f.y += f.vy;
        boolean was = f.ground;
        f.ground = false;
        if (f.vy >= 0 && f.dropT <= 0) {
            for (int i = 0; i < px.length; i++) {
                if (f.x > px[i] - 1 && f.x < px[i] + pw[i] + 1 && py0 <= py[i] + 0.01F && f.y >= py[i]) {
                    f.y = py[i]; f.vy = 0; f.ground = true; f.plat = i;
                    break;
                }
            }
        }
        if (f.ground) {
            if (!was) ev(EV_LAND, fx(f.x), fx(f.y), 0, 0, 0);
            f.jumps = jumpsOnLand(f); f.coyote = 5;
        } else if (f.coyote > 0) f.coyote--;
        if (f.y > H + 26 || f.y < -60 || f.x < -26 || f.x > W + 26) die(f);
    }

    private void respawn(Fighter f) {
        f.alive = true; f.x = 100 + rnd.nextInt(21); f.y = -14;    // every map has a platform under x = 100..120
        f.vx = 0; f.vy = 0; f.dmg = 0; giveWeapon(f, PISTOL);
        if (f.has(PERK_RANDOM_GUN)) randomGun(f);
        f.invT = 170; f.hitT = 0; f.flash = 0; f.frozenT = 0; f.cd = 20; f.ground = false; f.jumps = jumpsOnLand(f); f.lastHit = -1; f.lastHitT = 0;
        f.shieldT = f.speedT = f.wingsT = f.rageT = f.hasteT = f.slowT = 0;                  // the bonuses are lost
        f.face = f.x < 110 ? 1 : -1;
        ev(EV_RESPAWN, f.id, fx(f.x), 0, 0, 0);
    }

    private void die(Fighter f) {
        f.alive = false; f.deaths++; f.lives--; f.respT = 85;
        float px = Math.max(4, Math.min(W - 4, f.x)), py = Math.max(4, Math.min(H - 4, f.y));
        ev(EV_DIE, f.id, fx(px), fx(py), 0, 0);
        freeze = Math.max(freeze, 5);
        if (f.lastHit >= 0 && f.lastHit != f.id && f.lastHitT > 0) this.f[f.lastHit].kills++;
        if (f.lives <= 0) { f.out = true; elim.add(f.id); }
    }

    /** Hurts a fighter. A shield takes the hit (false); the owner's rage makes it stronger. */
    private boolean hurt(Fighter t, int owner, float dmg, int dir, float kbMul, float up, float hx, float hy, int weapon) {
        if (t.shieldT > 0) { ev(EV_BLOCK, t.id, fx(hx), fx(hy), 0, 0); return false; }
        if (owner >= 0 && owner != t.id && f[owner].rageT > 0) { dmg *= 1.8F; kbMul *= 1.25F; }
        t.dmg += dmg;
        if (owner >= 0 && owner != t.id) f[owner].dealt += dmg;
        kbMul *= CLASS_KB[t.cls];
        float k = (0.6F + t.dmg * 0.02F) * kbMul;
        t.vx = Math.max(-8F, Math.min(8F, t.vx + dir * k));
        t.vy = Math.max(-5.5F, t.vy - k * up * 0.5F);
        t.hitT = kbMul < 0.35F ? Math.max(t.hitT, 3) : 10 + Math.min(10, (int) (k * 2));
        t.flash = 6; t.lastHit = owner; t.lastHitT = 360;
        boolean strong = kbMul > 1.5F;
        if (strong) freeze = Math.max(freeze, 2);
        ev(EV_HIT, t.id, weapon, fx(hx), fx(hy), (dir > 0 ? 1 : 0) | (strong ? 2 : 0));
        return true;
    }

    // ------------------------------------------------------------------ weapons

    private void shoot(Fighter f) {
        int w = f.weapon;
        boolean pistol = w == PISTOL;
        int cdBase = pistol ? P_CD[f.pistol] : CD[w];
        f.cd = f.hasteT > 0 ? Math.max(2, cdBase / 2) : cdBase;
        if (!(pistol && f.has(PERK_INFINITE_PISTOL))) f.ammo--;
        float mx = f.x + f.face * 9, my = f.y - 6.5F;
        ev(EV_SHOOT, f.id, w, fx(mx), fx(my), f.face);
        if (w == LASER) fireLaser(f, mx, my);
        else if (w == TESLA) fireTesla(f, mx, my);
        else if (w == MINE) {
            Mine m = new Mine();
            m.x = f.x + f.face * 6; m.y = f.y - 4; m.vx = f.face * 1.1F; m.vy = -0.8F; m.owner = f.id; m.arm = 45; m.life = 1500;
            mines.add(m);
            if (mines.size() > 8) mines.remove(0);
        } else {
            for (int p = 0; p < PEL[w]; p++) {
                Bullet b = new Bullet();
                float sp = (rnd.nextFloat() - 0.5F) * 2F * SPR[w];
                b.x = mx; b.y = my; b.vx = f.face * SPD[w] * (w == FLAME ? 0.8F + rnd.nextFloat() * 0.4F : 1F); b.vy = sp * SPD[w] * 0.6F;
                if (w == GRENADE || w == CLUSTER) b.vy = -1.7F;
                if (w == BOOMER) b.ax = -f.face * 0.085F;                    // it slows down, turns and comes back
                b.dmg = DMG[w]; b.type = w; b.life = LIFE[w] - (w == SHOTGUN ? rnd.nextInt(5) : w == FLAME ? rnd.nextInt(6) : 0); b.owner = f.id;
                if (pistol) {                                                    // the bullet of the pistol of this fighter
                    int pi = f.pistol;
                    b.vx = f.face * P_SPD[pi]; b.vy = 0;
                    b.dmg = P_DMG[pi] * (pi == GOLDEN && rnd.nextFloat() < 0.15F ? 2F : 1F);
                    b.life = Math.round(P_RMAX[pi] / P_SPD[pi]) + 12;
                }
                bullets.add(b);
            }
        }
        if (!f.has(PERK_NO_RECOIL)) f.vx -= f.face * (pistol ? P_REC[f.pistol] : REC[w]);
        if (f.ammo <= 0 && !(pistol && f.has(PERK_INFINITE_PISTOL))) {
            if (pistol) { f.reloadT = P_RELOAD[f.pistol]; ev(EV_RELOAD, f.id, f.reloadT, 0, 0, 0); }
            else { backToPistol(f); ev(EV_EMPTY, f.id, 0, 0, 0, 0); }
        }
    }

    /** The laser is instant: a beam that goes through everybody who stands in line. */
    private void fireLaser(Fighter f, float mx, float my) {
        ev(EV_LASER, fx(mx), fx(my), fx(f.face > 0 ? W + 30 : -30), 0, 0);
        for (Fighter t : this.f) {
            if (t == f || t.kind == KIND_OFF || !t.alive || t.invT > 0) continue;
            if ((t.x - mx) * f.face < -4F || Math.abs(t.x - mx) > 260) continue;
            if (my > t.y - 13F && my < t.y + 0.5F) hurt(t, f.id, DMG[LASER], f.face, KB[LASER], 0.4F, t.x, my, LASER);
        }
    }

    /** The Tesla coil: a spark jumps to the nearest enemy in front and from him to two more, wherever they stand (it does not need a clear line). */
    private void fireTesla(Fighter f, float mx, float my) {
        float cx = mx, cy = my;
        int mask = 0, hits = 0;
        for (int n = 0; n < 3; n++) {
            Fighter best = null;
            float bd = 1e9F;
            for (Fighter t : this.f) {
                if (t == f || t.kind == KIND_OFF || !t.alive || t.invT > 0 || (mask >> t.id & 1) != 0) continue;
                float dx = t.x - cx, dy = (t.y - 6F) - cy;
                if (n == 0 && (dx * f.face < -6F || Math.abs(dy) > 40F)) continue;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > (n == 0 ? RMAX[TESLA] : 46F) || d >= bd) continue;
                bd = d; best = t;
            }
            if (best == null) break;
            mask |= 1 << best.id;
            hits++;
            ev(EV_ZAP, fx(cx), fx(cy), fx(best.x), fx(best.y - 6F), 0);
            hurt(best, f.id, DMG[TESLA], best.x >= cx ? 1 : -1, KB[TESLA], 0.6F, best.x, best.y - 6F, TESLA);
            cx = best.x; cy = best.y - 6F;
        }
        if (hits == 0) ev(EV_ZAP, fx(mx), fx(my), fx(mx + f.face * 26), fx(my + (rnd.nextFloat() - 0.5F) * 10F), 0);
    }

    private static float bombSize(int type) { return type == ROCKET ? 1F : type == GRENADE ? 0.9F : type == CLUSTER ? 0.8F : type == MINIBOMB ? 0.55F : 0F; }

    private static boolean lobbed(int type) { return type == GRENADE || type == CLUSTER || type == MINIBOMB; }

    /** A bomb goes off; a cluster bomb throws out four little ones. */
    private void detonate(Bullet b) {
        explode(b.x, b.y, b.owner, bombSize(b.type));
        if (b.type == CLUSTER) {
            float[] vxs = {-1.7F, -0.6F, 0.6F, 1.7F};
            for (int k = 0; k < 4; k++) {
                Bullet m = new Bullet();
                m.x = b.x; m.y = b.y - 2; m.vx = vxs[k]; m.vy = -2F - rnd.nextFloat() * 0.8F; m.type = MINIBOMB; m.owner = b.owner; m.life = 26 + rnd.nextInt(12);
                bullets.add(m);
            }
        }
    }

    private void stepBullets() {
        for (int i = bullets.size() - 1; i >= 0; i--) {
            Bullet b = bullets.get(i);
            if (b.ax != 0) {                                                     // a boomerang turns round: it can hit everybody again
                float pv = b.vx;
                b.vx += b.ax;
                if (pv * b.vx < 0) b.aux = 0;
            }
            int steps = Math.max(1, (int) Math.ceil(Math.abs(b.vx) / 3F));
            boolean dead = false;
            if (lobbed(b.type)) b.vy += 0.1F;
            for (int s = 0; s < steps && !dead; s++) {
                float py0 = b.y;
                b.x += b.vx / steps;
                b.y += b.vy / steps;
                if (lobbed(b.type) && b.vy > 0) {
                    for (int p = 0; p < px.length; p++) {
                        if (b.x > px[p] && b.x < px[p] + pw[p] && py0 <= py[p] && b.y >= py[p]) { b.y = py[p]; b.vy = -b.vy * 0.55F; b.vx *= 0.85F; break; }
                    }
                }
                dead = bulletHit(b);
            }
            if (!dead && (--b.life <= 0 || b.x < -30 || b.x > W + 30 || b.y < -40 || b.y > H + 30)) {
                if (bombSize(b.type) > 0 && b.life <= 0) detonate(b);
                dead = true;
            }
            if (dead) bullets.remove(i);
        }
    }

    private boolean bulletHit(Bullet b) {
        for (Fighter t : f) {
            if (t.kind == KIND_OFF || t.id == b.owner || !t.alive || t.invT > 0) continue;
            if (Math.abs(b.x - t.x) >= 5.5F || b.y <= t.y - 13F || b.y >= t.y + 0.5F) continue;
            if (bombSize(b.type) > 0) { detonate(b); return true; }
            if (b.type == HARPOON || b.type == BOOMER) {                        // goes through, hurts everybody once
                if ((b.aux >> t.id & 1) != 0) continue;
                b.aux |= 1 << t.id;
                hurt(t, b.owner, b.dmg, sign(b.vx), KB[b.type], 0.55F, b.x, b.y, b.type);
                continue;
            }
            if (b.type == SWAP) { swap(b, t); return true; }
            float kbm = b.type == PISTOL ? P_KB[f[b.owner].pistol] : KB[b.type];
            if (hurt(t, b.owner, b.dmg, sign(b.vx), kbm, 0.55F, b.x, b.y, b.type)) {
                if (b.type == ICE && t.frozenT <= 0) { t.frozenT = 75; ev(EV_FREEZE, t.id, 0, 0, 0, 0); }
                if (b.type == SLIME) { if (t.slowT <= 0) ev(EV_SLOW, t.id, 0, 0, 0, 0); t.slowT = 240; }
            }
            return true;
        }
        return false;
    }

    /** The swap ray: the shooter and the one who is hit change places. */
    private void swap(Bullet b, Fighter t) {
        Fighter o = f[b.owner];
        if (t.shieldT > 0) { ev(EV_BLOCK, t.id, fx(b.x), fx(b.y), 0, 0); return; }
        if (!o.alive) return;
        float tx = t.x, ty = t.y;
        t.x = o.x; t.y = o.y; o.x = tx; o.y = ty;
        t.vx = t.vy = o.vx = o.vy = 0;
        t.ground = o.ground = false;
        t.hitT = 12; o.invT = Math.max(o.invT, 25);
        t.lastHit = o.id; t.lastHitT = 360;
        ev(EV_SWAP, o.id, t.id, fx(o.x), fx(o.y), 0);
        ev(EV_SWAP, t.id, o.id, fx(t.x), fx(t.y), 0);
    }

    private void explode(float x, float y, int owner, float size) {
        ev(EV_EXPLODE, fx(x), fx(y), Math.round(size * 10F), 0, 0);
        freeze = Math.max(freeze, 3);
        for (Fighter t : f) {
            if (t.kind == KIND_OFF || !t.alive || t.invT > 0) continue;
            float dx = t.x - x, dy = (t.y - 6F) - y, d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d > 24F * size) continue;
            float fall = 1F - d / (24F * size) * 0.6F;
            float dm = DMG[ROCKET] * size * fall * (t.id == owner ? 0.4F : 1F);
            float kbm = KB[ROCKET] * size * fall + 0.3F;
            if (t.has(PERK_BLAST_SHIELD)) { dm *= 0.75F; kbm *= 0.6F; }
            hurt(t, owner, dm, dx == 0 ? (rnd.nextBoolean() ? 1 : -1) : sign(dx), kbm, 1.5F, t.x, t.y - 6F, ROCKET);
            if (t.id == owner) { t.lastHit = -1; t.lastHitT = 0; }
        }
    }

    private void stepMines() {
        for (int i = mines.size() - 1; i >= 0; i--) {
            Mine m = mines.get(i);
            if (m.arm > 0) m.arm--;
            float py0 = m.y;
            m.vy += 0.1F;
            if (m.vy > 3F) m.vy = 3F;
            m.x += m.vx; m.y += m.vy;
            m.ground = false;
            if (m.vy >= 0) {
                for (int p = 0; p < px.length; p++) {
                    if (m.x > px[p] && m.x < px[p] + pw[p] && py0 <= py[p] && m.y >= py[p]) { m.y = py[p]; m.vy = 0; m.ground = true; break; }
                }
            }
            m.vx *= m.ground ? 0.8F : 0.99F;
            boolean boom = false;
            if (m.arm <= 0) {
                for (Fighter t : f) {
                    if (t.kind == KIND_OFF || !t.alive || t.invT > 0) continue;
                    if (Math.abs(t.x - m.x) < 8 && t.y - 12 < m.y + 2 && t.y + 2 > m.y) { boom = true; break; }
                }
            }
            if (boom) { explode(m.x, m.y - 2, m.owner, 1F); mines.remove(i); }
            else if (--m.life <= 0 || m.y > H + 20) mines.remove(i);
        }
    }

    private void spawnCrate(int kind) {
        Crate c = new Crate();
        c.kind = kind;
        int pi = rnd.nextInt(px.length);
        c.x = px[pi] + 6 + rnd.nextInt(Math.max(1, pw[pi] - 12)); c.y = -12; c.life = kind == 0 ? 900 : 700;
        int r = rnd.nextInt(100);
        if (kind == 0) {
            c.weapon = SMG;
            for (int w = 1, acc = 0; w < CRATE_W.length; w++) { acc += CRATE_W[w]; if (r < acc) { c.weapon = w; break; } }
        } else {
            c.weapon = B_HEAL;
            for (int b = 0, acc = 0; b < BONUSES; b++) { acc += BONUS_W[b]; if (r < acc) { c.weapon = b; break; } }
        }
        crates.add(c);
    }

    private void giveBonus(Fighter q, int b) {
        switch (b) {
            case B_HEAL -> q.dmg = Math.max(0F, q.dmg - 40F);
            case B_SHIELD -> q.shieldT = BONUS_T[B_SHIELD];
            case B_SPEED -> q.speedT = BONUS_T[B_SPEED];
            case B_WINGS -> { q.wingsT = BONUS_T[B_WINGS]; q.jumps = Math.max(q.jumps, 3); }
            case B_RAGE -> q.rageT = BONUS_T[B_RAGE];
            case B_HASTE -> q.hasteT = BONUS_T[B_HASTE];
            default -> q.lives = Math.min(9, q.lives + 1);
        }
    }

    private void stepCrates(boolean live) {
        int wc = 0, bc = 0;
        for (Crate c : crates) { if (c.kind == 0) wc++; else bc++; }
        if (live && --crateT <= 0) { if (wc < 2) spawnCrate(0); crateT = 360 + rnd.nextInt(300); }
        if (live && --bonusT <= 0) { if (bc < 1) spawnCrate(1); bonusT = 520 + rnd.nextInt(320); }
        for (int i = crates.size() - 1; i >= 0; i--) {
            Crate c = crates.get(i);
            boolean remove = false;
            if (!c.landed) {
                float py0 = c.y;
                c.y += c.kind == 0 ? 0.45F : 0.38F;
                c.x += (float) Math.sin(ticks * 0.04F + c.weapon) * 0.15F;
                for (int p = 0; p < px.length; p++) {
                    if (c.x > px[p] && c.x < px[p] + pw[p] && py0 <= py[p] && c.y >= py[p]) {
                        c.y = py[p]; c.landed = true;
                        ev(EV_CRATE_LAND, fx(c.x), fx(c.y), c.weapon, c.kind, 0);
                        break;
                    }
                }
                if (c.y > H + 12) remove = true;
            } else if (--c.life <= 0) remove = true;
            if (!remove && live) {
                for (Fighter q : f) {
                    if (q.kind == KIND_OFF || !q.alive || Math.abs(q.x - c.x) > 7 || q.y - 12 > c.y || q.y + 3 < c.y) continue;
                    if (c.kind == 0) {
                        giveWeapon(q, c.weapon);
                        ev(EV_PICKUP, q.id, c.weapon, fx(c.x), fx(c.y - 4), 0);
                    } else {
                        giveBonus(q, c.weapon);
                        ev(EV_BONUS, q.id, c.weapon, fx(c.x), fx(c.y - 4), 0);
                    }
                    remove = true;
                    break;
                }
            }
            if (remove) crates.remove(i);
        }
    }

    // ------------------------------------------------------------------ the computer players

    private int pickTarget(Fighter me) {
        int best = -1;
        float bs = 1e9F;
        for (Fighter t : f) {
            if (t == me || t.kind == KIND_OFF || !t.alive) continue;
            float s = Math.abs(t.x - me.x) + Math.abs(t.y - me.y) * 1.5F - t.dmg * 0.4F;
            if (s < bs) { bs = s; best = t.id; }
        }
        return best;
    }

    /** The crate or bonus a computer player wants and can reach: a weapon when he has only the pistol, a bonus nearly always. */
    private Crate nearestCrate(Fighter me) {
        Crate best = null;
        float bd = 1e9F;
        boolean needGun = me.weapon == PISTOL || me.ammo < 3;
        if (me.has(PERK_RANDOM_GUN)) needGun = needGun && me.weapon == PISTOL;
        for (Crate c : crates) {
            if (c.kind == 0 && !needGun) continue;
            if (c.kind == 1 && c.weapon == B_HEAL && me.dmg < 25F) continue;
            float dx = Math.abs(c.x - me.x), dy = Math.abs(c.y - me.y);
            if (dx > 110 || dy > 75) continue;
            if (dx + dy < bd) { bd = dx + dy; best = c; }
        }
        return best;
    }

    /** The platform a computer player flies back to: the nearest one that is not far below him. */
    private int recoverPlat(Fighter me) {
        int best = 0;
        float bd = 1e9F;
        for (int i = 0; i < px.length; i++) {
            float cx = px[i] + pw[i] / 2F;
            float d = Math.abs(cx - me.x) + (py[i] > me.y + 30 ? 400 : 0) + (py[i] > me.y ? 20 : 0);
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }

    private int platAbove(Fighter me, float gy) {
        int best = -1;
        float bd = 1e9F;
        for (int i = 0; i < px.length; i++) {
            if (py[i] >= me.y - 8 || py[i] < me.y - 46 || py[i] < gy - 10) continue;
            float lo = px[i] + 4, hi = px[i] + pw[i] - 4;
            float d = me.x < lo ? lo - me.x : me.x > hi ? me.x - hi : 0;
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }

    void bot(Fighter f, boolean live) {
        f.keepFace = false;
        if (f.downT > 0) { f.downT--; f.inDown = true; }
        if (--f.thinkT <= 0) { f.thinkT = 18 + rnd.nextInt(18); f.target = pickTarget(f); }
        Fighter t = f.target >= 0 ? this.f[f.target] : null;
        if (t != null && !t.alive) { t = null; f.target = -1; f.thinkT = 0; }
        boolean steer = f.hitT < 8;

        // fell off the stage: swim back to the middle and use the second jump
        if (!f.ground && (f.y > lowY + 3 || f.x < 4 || f.x > W - 4)) {
            int tp = recoverPlat(f);
            if (f.x < px[tp] + pw[tp] / 2F) f.inR = true; else f.inL = true;
            if (f.jumps > 0 && f.vy > 0.3F && f.y > py[tp] - 14) f.inJump = true;
            return;
        }
        // an enemy bullet is coming: hop
        if (f.ground && (ticks & 3) == 0 && rnd.nextInt(100) < DODGE[skill] * 2) {
            for (Bullet b : bullets) {
                if (b.owner == f.id || Math.abs(b.y - (f.y - 6)) > 8) continue;
                float d = f.x - b.x;
                if (d * b.vx > 0 && Math.abs(d) < 36) { f.inJump = true; break; }
            }
        }
        Crate cr = nearestCrate(f);
        float gx = f.x, gy = f.y;
        if (cr != null) { gx = cr.x; gy = cr.y; }
        else if (t != null) {
            float dx = t.x - f.x;
            int rg = rangeOf(f);
            gy = t.y;
            if (Math.abs(dx) > rg + 12) gx = t.x;
            else if (Math.abs(dx) < rg - 20) gx = f.x - sign(dx) * 30;
        }
        float dy = gy - f.y;
        if (dy < -16 && f.ground) {
            int pu = platAbove(f, gy);
            if (pu >= 0) {
                float lo = px[pu] + 4, hi = px[pu] + pw[pu] - 4;
                if (f.x >= lo && f.x <= hi) f.inJump = true;
                else gx = f.x < lo ? lo + 2 : hi - 2;
            }
        } else if (dy > 16 && f.ground && f.plat >= 0 && py[f.plat] < lowY - 2) {
            f.downT = 8; f.inDown = true;
        }
        if (!f.ground && f.jumps > 0 && dy < -10 && f.vy > -0.3F) {
            int pu = platAbove(f, gy);
            if (pu >= 0 && f.y > py[pu] - 2 && f.x > px[pu] - 6 && f.x < px[pu] + pw[pu] + 6) f.inJump = true;
        }
        float adx = gx - f.x;
        int dir = Math.abs(adx) > 3 ? (adx > 0 ? 1 : -1) : 0;
        if (dir != 0 && f.ground && steer) {
            int p = f.plat;
            int mg = fric > 0.9F ? 14 : 4;                      // on ice a fighter slides on: stop early
            boolean atEdge = p >= 0 && ((dir > 0 && f.x > px[p] + pw[p] - mg) || (dir < 0 && f.x < px[p] + mg));
            if (atEdge) {
                boolean cross = t != null && cr == null && Math.abs(dy) < 22 && (!t.ground || t.plat != p);
                if (cross) f.inJump = true;
                else if (dy <= 16) dir = 0;
            }
        }
        if (dir > 0) f.inR = true; else if (dir < 0) f.inL = true;

        if (t != null && live && cr == null) {
            float dx = t.x - f.x;
            boolean inRange = Math.abs(dx) < rmaxOf(f);
            float tol = f.weapon == ROCKET || f.weapon == GRENADE || f.weapon == CLUSTER ? 18 : f.weapon == MINE ? 14 : f.weapon == TESLA ? 34 : 10;
            boolean aligned = Math.abs(t.y - f.y) < tol;
            if (inRange && aligned && t.invT <= 0) {
                if (f.reactT > 0) f.reactT--;
                else {
                    f.face = dx >= 0 ? 1 : -1;
                    f.keepFace = true;
                    if (rnd.nextInt(100) < FIRE[skill]) f.inFire = true;
                }
            } else f.reactT = REACT[skill] + rnd.nextInt(8);
        } else if (t != null && cr != null) f.reactT = REACT[skill];
        if (f.ground && rnd.nextInt(500) == 0) f.inJump = true;
    }

    // ------------------------------------------------------------------ the snapshot (server -> client)

    /** A timer in four-step units for one byte (a bonus lasts up to 600 steps). */
    private static int t4(int t) { return Math.min(255, (t + 3) / 4); }

    private static void s16(DataOutputStream o, float v, float k) throws IOException {
        o.writeShort(Math.max(-32768, Math.min(32767, Math.round(v * k))));
    }

    /** The whole picture (and the events since the last pack, which are cleared): about 300-900 bytes. */
    public byte[] pack() {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream(512);
            DataOutputStream o = new DataOutputStream(bo);
            o.writeByte(1);
            o.writeByte(phase); o.writeShort(phaseT); o.writeByte(winner + 1); o.writeByte(theme); o.writeByte(map); o.writeBoolean(over); o.writeByte(lives);
            for (Fighter q : f) {
                o.writeByte(q.kind);
                if (q.kind == KIND_OFF) continue;
                o.writeByte((q.alive ? 1 : 0) | (q.out ? 2 : 0) | (q.ground ? 4 : 0) | (q.face > 0 ? 8 : 0));
                s16(o, q.x, 16F); s16(o, q.y, 16F); s16(o, q.vx, 64F); s16(o, q.vy, 64F); s16(o, q.dmg, 8F);
                o.writeByte(q.weapon); o.writeByte(q.ammo); o.writeByte(q.lives); o.writeByte(q.kills); o.writeByte(q.deaths);
                o.writeByte(q.hitT); o.writeByte(q.flash); o.writeShort(q.invT); o.writeByte(q.frozenT);
                o.writeByte(q.color); o.writeByte(q.cls); o.writeByte(q.pistol); o.writeByte(t4(q.reloadT));
                o.writeByte(t4(q.shieldT)); o.writeByte(t4(q.speedT)); o.writeByte(t4(q.wingsT)); o.writeByte(t4(q.rageT)); o.writeByte(t4(q.hasteT)); o.writeByte(t4(q.slowT));
                s16(o, q.dealt, 1F);
            }
            o.writeByte(elim.size());
            for (int e : elim) o.writeByte(e);
            int nb = Math.min(bullets.size(), 90);
            o.writeByte(nb);
            for (int i = 0; i < nb; i++) {
                Bullet b = bullets.get(i);
                o.writeByte(b.type); o.writeByte(b.owner);
                s16(o, b.x, 16F); s16(o, b.y, 16F); s16(o, b.vx, 64F); s16(o, b.vy, 64F); o.writeByte(Math.min(127, b.life));
            }
            o.writeByte(mines.size());
            for (Mine m : mines) { s16(o, m.x, 16F); s16(o, m.y, 16F); o.writeByte(m.owner); o.writeBoolean(m.arm <= 0); }
            o.writeByte(crates.size());
            for (Crate c : crates) { s16(o, c.x, 16F); s16(o, c.y, 16F); o.writeByte(c.weapon); o.writeByte(c.kind); o.writeBoolean(c.landed); o.writeShort(c.life); }
            int ne = Math.min(events.size(), 60);
            o.writeByte(ne);
            for (int i = 0; i < ne; i++) {
                int[] e = events.get(i);
                o.writeByte(e[0]);
                for (int k = 1; k < 6; k++) o.writeShort(e[k]);
            }
            events.clear();
            return bo.toByteArray();
        } catch (IOException e) {
            return new byte[0];
        }
    }

    /** Reads a snapshot into this object (it only draws it); the events of the snapshot are in {@link #events} (the old ones are gone). */
    public boolean unpack(byte[] data) {
        try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
            if (in.readByte() != 1) return false;
            phase = in.readByte(); phaseT = in.readShort(); winner = in.readByte() - 1; theme = in.readByte(); int mp = in.readByte(); if (mp != map || lowY == 0) setMap(mp); over = in.readBoolean(); lives = in.readByte();
            for (int i = 0; i < N; i++) {
                Fighter q = f[i];
                q.kind = in.readByte();
                if (q.kind == KIND_OFF) { q.alive = false; q.out = true; continue; }
                int fl = in.readByte();
                q.alive = (fl & 1) != 0; q.out = (fl & 2) != 0; q.ground = (fl & 4) != 0; q.face = (fl & 8) != 0 ? 1 : -1;
                q.x = in.readShort() / 16F; q.y = in.readShort() / 16F; q.vx = in.readShort() / 64F; q.vy = in.readShort() / 64F; q.dmg = in.readShort() / 8F;
                q.weapon = in.readByte(); q.ammo = in.readByte(); q.lives = in.readByte(); q.kills = in.readByte(); q.deaths = in.readByte();
                q.hitT = in.readByte(); q.flash = in.readByte(); q.invT = in.readShort(); q.frozenT = in.readByte();
                q.color = Math.floorMod(in.readByte(), COLORS); q.cls = Math.floorMod(in.readByte(), CLASSES); q.pistol = Math.floorMod(in.readByte(), PISTOLS);
                q.perks = CLASS_PERKS[q.cls]; q.reloadT = in.readUnsignedByte() * 4;
                q.shieldT = in.readUnsignedByte() * 4; q.speedT = in.readUnsignedByte() * 4; q.wingsT = in.readUnsignedByte() * 4;
                q.rageT = in.readUnsignedByte() * 4; q.hasteT = in.readUnsignedByte() * 4; q.slowT = in.readUnsignedByte() * 4;
                q.dealt = in.readShort();
            }
            elim.clear();
            int ne = in.readByte();
            for (int i = 0; i < ne; i++) elim.add((int) in.readByte());
            bullets.clear();
            int nb = in.readByte();
            for (int i = 0; i < nb; i++) {
                Bullet b = new Bullet();
                b.type = in.readByte(); b.owner = in.readByte();
                b.x = in.readShort() / 16F; b.y = in.readShort() / 16F; b.vx = in.readShort() / 64F; b.vy = in.readShort() / 64F; b.life = in.readByte();
                bullets.add(b);
            }
            mines.clear();
            int nm = in.readByte();
            for (int i = 0; i < nm; i++) {
                Mine m = new Mine();
                m.x = in.readShort() / 16F; m.y = in.readShort() / 16F; m.owner = in.readByte(); m.arm = in.readBoolean() ? 0 : 30;
                mines.add(m);
            }
            crates.clear();
            int nc = in.readByte();
            for (int i = 0; i < nc; i++) {
                Crate c = new Crate();
                c.x = in.readShort() / 16F; c.y = in.readShort() / 16F; c.weapon = in.readByte(); c.kind = in.readByte(); c.landed = in.readBoolean(); c.life = in.readShort();
                crates.add(c);
            }
            events.clear();
            int nv = in.readByte();
            for (int i = 0; i < nv; i++) {
                int[] e = new int[6];
                e[0] = in.readByte();
                for (int k = 1; k < 6; k++) e[k] = in.readShort();
                events.add(e);
            }
            return true;
        } catch (IOException | RuntimeException e) {
            return false;
        }
    }
}
