package dev.cutemod.data;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * The drawing board of Scribble Pals: a small grid of palette colours and the list of operations that made it.
 * Plain Java (no Minecraft), so the server, the clients and the bot artists all rebuild exactly the same picture from the
 * same list of operations.
 * <p>
 * An operation is one text line of numbers: {@code stroke,tool,colour,size,x1,y1,x2,y2,...}. A stroke is one drag of the mouse
 * (it may arrive as several operations with the same stroke number: the clients send a chunk every few ticks, so the others see
 * the line grow). tool 0 = pen, 1 = eraser (the pen in paper colour), 2 = fill (one point). Undo removes every operation of the last stroke.
 */
public final class SkribblCanvas {
    public static final int CW = 120, CH = 80;
    public static final int PEN = 0, ERASER = 1, FILL = 2;
    public static final int MAX_POINTS = 24;
    public static final int[] SIZES = {1, 2, 3, 5};

    /** The 16 colours of the palette (ARGB). 0 is the paper. */
    public static final int[] PALETTE = {
            0xFFFFFDF8, 0xFF3A3347, 0xFF8E8A99, 0xFFE8566B, 0xFFF59B5B, 0xFFF7D860, 0xFF8FD17A, 0xFF3FA88A,
            0xFF6EC3F2, 0xFF4A78E0, 0xFF9B7BE0, 0xFFF4A0C8, 0xFFB66A4B, 0xFFE8C9A0, 0xFFBFEFD6, 0xFFC9B8F5};

    public final byte[] px = new byte[CW * CH];
    private final List<String> ops = new ArrayList<>();

    public List<String> ops() { return ops; }

    public int count() { return ops.size(); }

    public void clear() {
        ops.clear();
        java.util.Arrays.fill(px, (byte) 0);
    }

    /** Add one operation and draw it. False if the text is not a good operation (it is dropped). */
    public boolean add(String op) {
        int[] v = parse(op);
        if (v == null) return false;
        ops.add(op);
        apply(v);
        return true;
    }

    /** Remove every operation of the last stroke and draw the rest again. False if there was nothing to undo. */
    public boolean undo() {
        if (ops.isEmpty()) return false;
        int last = strokeOf(ops.get(ops.size() - 1));
        while (!ops.isEmpty() && strokeOf(ops.get(ops.size() - 1)) == last) ops.remove(ops.size() - 1);
        rebuild();
        return true;
    }

    public void rebuild() {
        java.util.Arrays.fill(px, (byte) 0);
        for (String o : ops) { int[] v = parse(o); if (v != null) apply(v); }
    }

    public void setOps(List<String> list) {
        ops.clear();
        java.util.Arrays.fill(px, (byte) 0);
        for (String o : list) add(o);
    }

    public static int strokeOf(String op) {
        int c = op.indexOf(',');
        try { return Integer.parseInt(c < 0 ? op : op.substring(0, c)); } catch (NumberFormatException e) { return -1; }
    }

    /** The numbers of an operation, or null if it is not valid. */
    public static int[] parse(String op) {
        if (op == null || op.length() > 400) return null;
        String[] s = op.split(",");
        if (s.length < 6 || s.length > 4 + MAX_POINTS * 2 || (s.length & 1) != 0) return null;
        int[] v = new int[s.length];
        try { for (int i = 0; i < s.length; i++) v[i] = Integer.parseInt(s[i].trim()); } catch (NumberFormatException e) { return null; }
        if (v[1] < 0 || v[1] > 2 || v[2] < 0 || v[2] >= PALETTE.length || v[3] < 0 || v[3] >= SIZES.length) return null;
        if (v[1] == FILL && v.length != 6) return null;
        for (int i = 4; i < v.length; i += 2) if (v[i] < 0 || v[i] >= CW || v[i + 1] < 0 || v[i + 1] >= CH) return null;
        return v;
    }

    private void apply(int[] v) {
        int tool = v[1], col = tool == ERASER ? 0 : v[2];
        if (tool == FILL) { fill(v[4], v[5], (byte) col); return; }
        int r = SIZES[v[3]] - 1;
        int x = v[4], y = v[5];
        stamp(x, y, r, (byte) col);
        for (int i = 6; i < v.length; i += 2) {
            line(x, y, v[i], v[i + 1], r, (byte) col);
            x = v[i];
            y = v[i + 1];
        }
    }

    private void line(int x0, int y0, int x1, int y1, int r, byte c) {
        int dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx - dy;
        while (true) {
            stamp(x0, y0, r, c);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 < dx) { err += dx; y0 += sy; }
        }
    }

    private void stamp(int cx, int cy, int r, byte c) {
        if (r == 0) { put(cx, cy, c); return; }
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.floor(Math.sqrt((r + 0.5) * (r + 0.5) - dy * dy));
            for (int dx = -w; dx <= w; dx++) put(cx + dx, cy + dy, c);
        }
    }

    private void put(int x, int y, byte c) {
        if (x >= 0 && y >= 0 && x < CW && y < CH) px[y * CW + x] = c;
    }

    private void fill(int sx, int sy, byte c) {
        byte from = px[sy * CW + sx];
        if (from == c) return;
        ArrayDeque<int[]> q = new ArrayDeque<>();
        q.add(new int[]{sx, sy});
        while (!q.isEmpty()) {
            int[] p = q.poll();
            int x = p[0], y = p[1];
            if (x < 0 || y < 0 || x >= CW || y >= CH || px[y * CW + x] != from) continue;
            px[y * CW + x] = c;
            q.add(new int[]{x + 1, y}); q.add(new int[]{x - 1, y}); q.add(new int[]{x, y + 1}); q.add(new int[]{x, y - 1});
        }
    }

    // ------------------------------------------------------------------ packing for the gallery

    /** All operations in one line (separated by ;). */
    public String pack() { return String.join(";", ops); }

    public static List<String> unpack(String s) {
        List<String> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        for (String o : s.split(";")) if (parse(o) != null) out.add(o);
        return out;
    }

    /** True once at least one stroke that is not a fill exists (an empty board is not worth keeping). */
    public boolean hasInk() {
        for (byte b : px) if (b != 0) return true;
        return false;
    }
}
