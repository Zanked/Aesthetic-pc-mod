package dev.cutemod.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The rules of Scribble Pals (a "draw and guess" game for up to eight players, people and computer players), without any
 * network or Minecraft code, so it can be tested on its own. {@code SkribblServer} owns one of these per room, calls
 * {@link #tick()} 20 times a second and sends what changed to the people in the room.
 * <p>
 * A game is {@code rounds} rounds; in a round every player draws once. The drawer gets three words to pick from (a computer
 * player only gets words it knows how to draw), then everybody else has {@code drawSeconds} to type the word in the chat.
 * The earlier a guess, the more points; the drawer is paid for every guesser. After the time (or when everybody has it)
 * the word is shown for a few seconds, people can like the picture, and the next player draws.
 */
public final class SkribblGame {
    public static final int SLOTS = 8;
    public static final int EMPTY = 0, OPEN = 1, BOT = 2, HUMAN = 3;
    public static final int LOBBY = 0, PICK = 1, DRAW = 2, REVEAL = 3, END = 4;
    /** Chat kinds, the client turns them into text in its own language. */
    public static final int K_SAY = 0, K_GUESSED = 1, K_CLOSE = 2, K_WHISPER = 3, K_WORD = 4, K_JOIN = 5, K_LEAVE = 6, K_DRAWER = 7, K_NOBODY = 8;
    public static final int ALL = -1;
    public static final int[] ROUNDS = {2, 3, 4}, SECONDS = {60, 80, 100};

    private static final int PICK_TICKS = 15 * 20, REVEAL_TICKS = 8 * 20, END_TICKS = 18 * 20;
    private static final String[] BOT_NAMES = {"Mochi", "Panko", "Nori", "Kiwi", "Pudding", "Boba", "Miso", "Tofu"};

    public interface Sink {
        /** Something everybody should see changed (phase, scores, hints...): send the picture of the game again. */
        void changed();

        /** A drawing operation for everybody except slot {@code except} (kind 0 add {@code op}, 1 undo, 2 clear). */
        void draw(int kind, String op, int except);

        /** A chat line for the slots in the bit mask {@code audience} (ALL = everybody). */
        void chat(int kind, int from, String text, int arg, int audience);
    }

    private final Sink sink;
    private final Random rnd;

    public final int[] type = new int[SLOTS];
    public final String[] name = new String[SLOTS];
    public final int[] score = new int[SLOTS], gain = new int[SLOTS];
    public final boolean[] guessed = new boolean[SLOTS], liked = new boolean[SLOTS];
    public int rounds = 3, drawSeconds = 80;
    public int phase = LOBBY, round, drawer = -1, word = -1, timeLeft, timeTotal, likes, guessers;
    public int[] choices = new int[0];
    public long seed;
    public final SkribblCanvas canvas = new SkribblCanvas();

    private final List<Integer> order = new ArrayList<>();
    private final List<Integer> usedWords = new ArrayList<>();
    private int turn;
    private int pickLeft, revealLeft, endLeft, tickNo, penStrokes;
    private boolean allIn;
    // computer players
    private final double[] skill = new double[SLOTS];
    private final int[] guessAt = new int[SLOTS];
    private final boolean[] solves = new boolean[SLOTS];
    private final int[] wrongLeft = new int[SLOTS];
    private List<String> botOps = new ArrayList<>();
    private int botNext;
    private double botGap, botClock;

    public SkribblGame(Sink sink, Random rnd) {
        this.sink = sink;
        this.rnd = rnd;
        for (int i = 0; i < SLOTS; i++) name[i] = "";
    }

    // ------------------------------------------------------------------ the room

    public int players() {
        int n = 0;
        for (int t : type) if (t == BOT || t == HUMAN) n++;
        return n;
    }

    public int humans() {
        int n = 0;
        for (int t : type) if (t == HUMAN) n++;
        return n;
    }

    public boolean running() { return phase != LOBBY; }

    /** Start a game: the places still open are dropped and computer players join until there are at least three. */
    public boolean start() {
        if (phase != LOBBY || humans() < 1) return false;
        for (int i = 0; i < SLOTS; i++) if (type[i] == OPEN) type[i] = EMPTY;
        for (int i = 0; i < SLOTS && players() < 3; i++) if (type[i] == EMPTY) type[i] = BOT;
        for (int i = 0; i < SLOTS; i++) {
            score[i] = 0;
            gain[i] = 0;
            if (type[i] == BOT) { name[i] = BOT_NAMES[i % BOT_NAMES.length]; skill[i] = 0.25 + rnd.nextDouble() * 0.75; }
        }
        order.clear();
        for (int i = 0; i < SLOTS; i++) if (type[i] == HUMAN || type[i] == BOT) order.add(i);
        usedWords.clear();
        round = 0;
        turn = -1;
        nextTurn();
        return true;
    }

    /** A person leaves (or is sent away) while the game runs. */
    public void leave(int slot, boolean announce) {
        if (type[slot] != HUMAN) return;
        if (announce && phase != LOBBY) sink.chat(K_LEAVE, slot, name[slot], 0, ALL);
        type[slot] = EMPTY;
        if (phase == LOBBY) return;
        if (humans() == 0) { phase = LOBBY; sink.changed(); return; }
        if (phase == PICK || phase == DRAW) {
            if (slot == drawer) endTurn();
            else checkAllIn();
        }
        sink.changed();
    }

    // ------------------------------------------------------------------ turns

    private void nextTurn() {
        while (true) {
            turn++;
            if (turn >= order.size()) { turn = 0; round++; }
            if (round >= rounds) { finish(); return; }
            int s = order.get(turn);
            if (type[s] == HUMAN || type[s] == BOT) { drawer = s; break; }
        }
        phase = PICK;
        pickLeft = PICK_TICKS;
        word = -1;
        for (int i = 0; i < SLOTS; i++) { guessed[i] = false; liked[i] = false; gain[i] = 0; }
        likes = 0;
        guessers = 0;
        allIn = false;
        penStrokes = 0;
        canvas.clear();
        sink.draw(2, "", -1);
        choices = pickChoices(type[drawer] == BOT);
        sink.chat(K_DRAWER, drawer, name[drawer], 0, ALL);
        sink.changed();
    }

    private int[] pickChoices(boolean artOnly) {
        int pool = artOnly ? SkribblWords.ART : SkribblWords.count();
        int[] c = new int[3];
        for (int i = 0; i < 3; i++) {
            int w, tries = 0;
            do {
                w = rnd.nextInt(pool);
                tries++;
            } while (tries < 60 && (usedWords.contains(w) || contains(c, i, w)));
            c[i] = w;
        }
        return c;
    }

    private static boolean contains(int[] a, int n, int v) {
        for (int i = 0; i < n; i++) if (a[i] == v) return true;
        return false;
    }

    /** The drawer picks one of the three words. */
    public boolean pick(int slot, int index) {
        if (phase != PICK || slot != drawer || index < 0 || index >= choices.length) return false;
        beginDrawing(choices[index]);
        return true;
    }

    private void beginDrawing(int w) {
        word = w;
        usedWords.add(w);
        phase = DRAW;
        timeTotal = drawSeconds * 20;
        timeLeft = timeTotal;
        seed = rnd.nextLong();
        for (int i = 0; i < SLOTS; i++) {
            if (type[i] != BOT || i == drawer) continue;
            solves[i] = rnd.nextDouble() < 0.45 + 0.45 * skill[i];
            guessAt[i] = (int) (timeTotal * (0.3 + 0.5 * rnd.nextDouble() * (1.15 - 0.4 * skill[i])));
            wrongLeft[i] = rnd.nextInt(3);
        }
        if (type[drawer] == BOT) {
            botOps = SkribblArt.draw(w);
            botNext = 0;
            botGap = Math.max(2.0, timeTotal * 0.55 / Math.max(1, botOps.size()));
            botClock = 20;
        }
        sink.changed();
    }

    private void endTurn() {
        if (phase != PICK && phase != DRAW) return;
        if (phase == DRAW && guessers > 0) {
            gain[drawer] += 25 + (allIn ? 25 : 0);
            score[drawer] += 25 + (allIn ? 25 : 0);
        }
        phase = REVEAL;
        revealLeft = REVEAL_TICKS;
        if (word >= 0) sink.chat(K_WORD, drawer, name[drawer], word, ALL);
        else sink.chat(K_NOBODY, drawer, name[drawer], 0, ALL);
        sink.changed();
    }

    private void finish() {
        phase = END;
        endLeft = END_TICKS;
        drawer = -1;
        word = -1;
        sink.changed();
    }

    // ------------------------------------------------------------------ guessing

    private int guessed() {
        int n = 0;
        for (int i = 0; i < SLOTS; i++) if (i != drawer && guessed[i] && (type[i] == HUMAN || type[i] == BOT)) n++;
        return n;
    }

    private int guessable() {
        int n = 0;
        for (int i = 0; i < SLOTS; i++) if (i != drawer && (type[i] == HUMAN || type[i] == BOT)) n++;
        return n;
    }

    private void checkAllIn() {
        if (phase == DRAW && !allIn && guessable() > 0 && guessed() >= guessable()) {
            allIn = true;
            timeLeft = Math.min(timeLeft, 3 * 20);
        } else if (phase == DRAW && guessable() == 0) endTurn();
    }

    /** What a person typed in the chat. */
    public void say(int slot, String text) {
        if (type[slot] != HUMAN) return;
        text = text.trim();
        if (text.isEmpty()) return;
        if (text.length() > 60) text = text.substring(0, 60);
        if (phase == DRAW && slot != drawer && !guessed[slot]) {
            if (SkribblWords.matches(word, text)) { solved(slot); return; }
            sink.chat(K_SAY, slot, text, 0, ALL);
            if (SkribblWords.close(word, text)) sink.chat(K_CLOSE, slot, text, 0, 1 << slot);
            return;
        }
        if (phase == DRAW) {                                  // the drawer and the ones who know the word talk among themselves
            if (SkribblWords.matches(word, text)) return;      // no spoilers
            int mask = 1 << drawer;
            for (int i = 0; i < SLOTS; i++) if (guessed[i]) mask |= 1 << i;
            sink.chat(K_WHISPER, slot, text, 0, mask);
            return;
        }
        sink.chat(K_SAY, slot, text, 0, ALL);
    }

    private void solved(int slot) {
        int pts = 40 + (int) Math.round(160.0 * timeLeft / Math.max(1, timeTotal));
        if (guessed() == 0) pts += 20;
        guessed[slot] = true;
        gain[slot] = pts;
        score[slot] += pts;
        guessers++;
        gain[drawer] += 0;
        sink.chat(K_GUESSED, slot, name[slot], 0, ALL);
        checkAllIn();
        sink.changed();
    }

    /** Somebody clicked the heart on the picture. */
    public void like(int slot) {
        if (phase != REVEAL || slot == drawer || liked[slot] || type[slot] != HUMAN || word < 0 || !canvas.hasInk()) return;
        liked[slot] = true;
        likes++;
        score[drawer] += 5;
        gain[drawer] += 5;
        sink.changed();
    }

    // ------------------------------------------------------------------ the drawer's tools

    /** One drawing operation from the drawer. */
    public boolean op(int slot, String op) {
        if (phase != DRAW || slot != drawer || type[slot] != HUMAN || canvas.count() >= 1500) return false;
        if (!canvas.add(op)) return false;
        penStrokes++;
        sink.draw(0, op, slot);
        return true;
    }

    public boolean undo(int slot) {
        if (phase != DRAW || slot != drawer || type[slot] != HUMAN || !canvas.undo()) return false;
        sink.draw(1, "", slot);
        return true;
    }

    public boolean clearBoard(int slot) {
        if (phase != DRAW || slot != drawer || type[slot] != HUMAN) return false;
        canvas.clear();
        sink.draw(2, "", slot);
        return true;
    }

    // ------------------------------------------------------------------ time

    /** One step: 1/20 of a second. */
    public void tick() {
        tickNo++;
        switch (phase) {
            case PICK -> {
                pickLeft--;
                boolean bot = type[drawer] == BOT;
                if (pickLeft <= 0 || (bot && pickLeft < PICK_TICKS - 30)) pick(drawer, rnd.nextInt(choices.length));
            }
            case DRAW -> drawing();
            case REVEAL -> { if (--revealLeft <= 0) nextTurn(); }
            case END -> { if (--endLeft <= 0) { phase = LOBBY; sink.changed(); } }
            default -> { }
        }
    }

    private int revealCount() {
        int pct = (timeTotal - timeLeft) * 100 / Math.max(1, timeTotal);
        return pct >= 70 ? 2 : pct >= 40 ? 1 : 0;
    }

    private void drawing() {
        int before = revealCount();
        timeLeft--;
        if (revealCount() != before || tickNo % 100 == 0) sink.changed();
        if (type[drawer] == BOT && botNext < botOps.size()) {
            botClock -= 1;
            if (botClock <= 0) {
                String o = botOps.get(botNext++);
                canvas.add(o);
                sink.draw(0, o, -1);
                botClock += botGap;
            }
        }
        int elapsed = timeTotal - timeLeft;
        boolean seen = type[drawer] == BOT ? botNext * 2 >= botOps.size() : penStrokes >= 4;
        for (int i = 0; i < SLOTS && seen && phase == DRAW; i++) {
            if (type[i] != BOT || i == drawer || guessed[i] || elapsed < guessAt[i]) continue;
            if (solves[i]) { solved(i); continue; }
            if (wrongLeft[i] > 0) {                           // a wrong try, like a person would make
                wrongLeft[i]--;
                int w = rnd.nextInt(SkribblWords.count());
                if (w != word) sink.chat(K_SAY, i, SkribblWords.en(w), 0, ALL);
                guessAt[i] = elapsed + 40 + rnd.nextInt(100);
            } else guessAt[i] = Integer.MAX_VALUE;
        }
        if (phase == DRAW && timeLeft <= 0) endTurn();
    }

    // ------------------------------------------------------------------ what the clients are shown

    public String hint(String lang) { return word < 0 ? "" : SkribblWords.hint(SkribblWords.word(word, lang), revealCount(), seed); }

    public int guessedMask() {
        int m = 0;
        for (int i = 0; i < SLOTS; i++) if (guessed[i]) m |= 1 << i;
        return m;
    }

    /** True if slot may see the word right now. */
    public boolean knows(int slot) {
        return word >= 0 && (phase == REVEAL || slot == drawer || guessed[slot]);
    }
}
