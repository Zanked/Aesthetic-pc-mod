package dev.cutemod.client.game;

import dev.cutemod.data.SkribblCanvas;
import dev.cutemod.data.SkribblGame;
import dev.cutemod.data.SkribblWords;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Scribble Pals: draw and guess with up to eight players (people and computer players). One player gets a secret word and draws it,
 * everybody else types guesses in a chat window; the faster you guess, the more points you get. Every finished picture can be kept in
 * the gallery. The rules run on the server ({@link SkribblNet} is the line to it); this class is the screen: menu, rooms, the room,
 * the game itself (board, tools, players, chat) and the gallery.
 */
public class Skribbl extends MiniGame {
    private static final int MENU = 0, ROOMS = 1, ROOM = 2, PLAY = 3, GALLERY = 4;
    private static final int INK = 0xFF3A3347, MUTED = 0xFF8E8A99, PINK = 0xFFE8566B, MINT = 0xFF3FA88A, SOFT = 0xFFE9B8D0, CARD = 0xFFFFFBF5;
    private static final int[] AVATAR = {0xFFF4A0C8, 0xFF6EC3F2, 0xFF8FD17A, 0xFFF7D860, 0xFFC9B8F5, 0xFFF59B5B, 0xFF7FD6C8, 0xFFE8566B};
    private static final int BX = 5, BY = 18;
    private static final int END_SECONDS = 18;

    private int screen = MENU, anim, notice, noticeT;
    private boolean autoStart, won;
    private int prevPhase, lastSecond = -1, seenChatV = -1, seenBoardV = -1, seenVersion = -1;

    // drawing
    private int tool, color = 1, sizeIdx = 1;
    private boolean down, inStroke, flushedAny;
    private int curStroke, lastX, lastY, sendT;
    private final List<int[]> pend = new ArrayList<>();
    private final StringBuilder input = new StringBuilder();

    // what is drawn: the board as runs of one colour
    private int[] runs = new int[1024];
    private int runN;

    // the chat window
    private static final class WL { String pre = "", txt = ""; int pc = INK, tc = INK; }
    private final List<WL> lines = new ArrayList<>();

    // the gallery
    private int gPage, gView = -1, gSure;

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private static String lang() { return Minecraft.getInstance().options.languageCode; }

    private static String wordText(int w) { return w < 0 ? "" : SkribblWords.word(w, lang()); }

    @Override
    public String hintKey() { return "cutemod.hint.skribbl"; }

    @Override
    public boolean isWin() { return won; }

    @Override
    public net.minecraft.network.chat.Component endTitle() { return Component.translatable(won ? "cutemod.skribbl.won" : "cutemod.ui.gameover"); }

    @Override
    public void reset() {
        score = 0;
        over = false;
        won = false;
        screen = MENU;
        down = inStroke = false;
        pend.clear();
        input.setLength(0);
        autoStart = false;
        prevPhase = SkribblNet.phase;
        SkribblNet.request();                                    // maybe we are still in a room: tick() brings us back to it
    }

    @Override
    public void close() {
        if (SkribblNet.inRoom) SkribblNet.leave();
    }

    // ------------------------------------------------------------------ time

    @Override
    public void tick() {
        anim++;
        int n = SkribblNet.takeNotice();
        if (n != 0) { notice = n; noticeT = 200; }
        if (noticeT > 0) noticeT--;
        if ((screen == ROOMS || screen == ROOM) && anim % 100 == 0) SkribblNet.request();
        if ((screen == MENU || screen == ROOMS) && SkribblNet.inRoom) screen = SkribblNet.inGame ? PLAY : ROOM;
        if (screen == ROOM && !SkribblNet.inRoom) screen = ROOMS;
        if (screen == ROOM && SkribblNet.inGame) { screen = PLAY; input.setLength(0); }
        if (autoStart && SkribblNet.inRoom && SkribblNet.youHost && !SkribblNet.inGame) { SkribblNet.start(); autoStart = false; }

        int ph = SkribblNet.phase;
        if (ph != prevPhase) { onPhase(prevPhase, ph); prevPhase = ph; }
        if (screen == PLAY) {
            score = SkribblNet.scores[SkribblNet.mySlot & 7];
            if (!SkribblNet.inGame) screen = SkribblNet.inRoom ? ROOM : MENU;
            drawTick();
            sounds();
        }
    }

    private void onPhase(int from, int to) {
        if (to == SkribblGame.PICK && SkribblNet.mySlot == SkribblNet.drawer) pling(1.0F);
        if (to == SkribblGame.REVEAL) pling(0.8F);
        if (to == SkribblGame.END) pling(1.4F);
        if (from == SkribblGame.END && to == SkribblGame.LOBBY) {          // the game is over: the coins and the best score count
            int me = SkribblNet.mySlot & 7;
            boolean best = true;
            for (int i = 0; i < SkribblGame.SLOTS; i++) if (i != me && SkribblNet.slotType[i] >= 2 && SkribblNet.scores[i] > SkribblNet.scores[me]) best = false;
            score = SkribblNet.scores[me];
            won = best && score > 0;
            screen = SkribblNet.inRoom ? ROOM : MENU;
            over = true;
        }
    }

    private void sounds() {
        if (seenChatV != SkribblNet.chatVersion) {
            rebuildChat();
            for (int i = Math.max(0, SkribblNet.chat.size() - 3); i < SkribblNet.chat.size(); i++) {
                int k = SkribblNet.chat.get(i).kind;
                if (k == SkribblGame.K_GUESSED) pling(1.35F);
                else if (k == SkribblGame.K_CLOSE) pling(0.9F);
            }
        }
        if (SkribblNet.phase == SkribblGame.DRAW) {
            int sec = (SkribblNet.ticksLeft() + 19) / 20;
            if (sec != lastSecond && sec <= 5 && sec > 0) beep();
            lastSecond = sec;
        }
    }

    // ------------------------------------------------------------------ drawing with the mouse

    private boolean iDraw() { return SkribblNet.phase == SkribblGame.DRAW && SkribblNet.mySlot == SkribblNet.drawer; }

    private void drawTick() {
        if (!iDraw()) { if (inStroke) endStroke(); down = false; return; }
        if (!down || tool == 2) return;
        int bx = mx - BX, by = my - BY;
        boolean inside = bx >= 0 && by >= 0 && bx < SkribblCanvas.CW && by < SkribblCanvas.CH;
        if (!inside) { if (inStroke) endStroke(); return; }
        if (!inStroke) { beginStroke(bx, by); return; }
        if (bx != lastX || by != lastY) {
            pend.add(new int[]{bx, by});
            lastX = bx;
            lastY = by;
            if (pend.size() >= 12) flush();
        }
        if (++sendT >= 3) flush();
    }

    private void beginStroke(int bx, int by) {
        inStroke = true;
        flushedAny = false;
        curStroke = ++SkribblNet.strokeNo;
        pend.clear();
        pend.add(new int[]{bx, by});
        lastX = bx;
        lastY = by;
        sendT = 0;
    }

    private void flush() {
        sendT = 0;
        if (pend.isEmpty() || (flushedAny && pend.size() < 2)) return;
        StringBuilder sb = new StringBuilder().append(curStroke).append(',').append(tool).append(',').append(color).append(',').append(sizeIdx);
        for (int[] p : pend) sb.append(',').append(p[0]).append(',').append(p[1]);
        if (pend.size() == 1) sb.append(',').append(pend.get(0)[0]).append(',').append(pend.get(0)[1]);
        SkribblNet.op(sb.toString());
        flushedAny = true;
        int[] last = pend.get(pend.size() - 1);
        pend.clear();
        pend.add(last);
    }

    private void endStroke() {
        if (inStroke) flush();
        inStroke = false;
        pend.clear();
    }

    @Override
    public boolean release(int x, int y, int button) {
        if (button == 0 && down) { if (inStroke) endStroke(); down = false; return true; }
        return false;
    }

    // ------------------------------------------------------------------ mouse

    @Override
    public boolean click(int x, int y, int button) {
        switch (screen) {
            case MENU -> clickMenu(x, y);
            case ROOMS -> clickRooms(x, y);
            case ROOM -> clickRoom(x, y);
            case PLAY -> clickPlay(x, y, button);
            default -> clickGallery(x, y);
        }
        return true;
    }

    private void clickMenu(int x, int y) {
        if (in(x, y, 45, 48, 130, 17)) { autoStart = true; SkribblNet.create(); pling(1.3F); }
        else if (in(x, y, 45, 69, 130, 17)) { screen = ROOMS; SkribblNet.request(); pling(1.1F); }
        else if (in(x, y, 45, 90, 130, 17)) { screen = GALLERY; gPage = 0; gView = -1; pling(1.1F); }
    }

    private void clickRooms(int x, int y) {
        if (in(x, y, 4, 3, 24, 12)) { screen = MENU; beep(); return; }
        if (in(x, y, 138, 3, 78, 12)) { SkribblNet.create(); pling(1.2F); return; }
        int rows = Math.min(SkribblNet.hosts.size(), 5);
        for (int i = 0; i < rows; i++) if (in(x, y, 8, 24 + i * 20, 204, 18)) { SkribblNet.join(SkribblNet.hosts.get(i)); pling(1.2F); return; }
    }

    private void clickRoom(int x, int y) {
        if (in(x, y, 4, 3, 24, 12)) { SkribblNet.leave(); screen = ROOMS; autoStart = false; beep(); return; }
        if (!SkribblNet.youHost) return;
        for (int i = 0; i < SkribblGame.SLOTS; i++) {
            if (i != SkribblNet.mySlot && in(x, y, 6 + (i % 2) * 106, 20 + (i / 2) * 19, 102, 17)) { SkribblNet.slot(i); beep(); return; }
        }
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 62 + i * 36, 99, 32, 11)) { SkribblNet.setRounds(i); beep(); return; }
            if (in(x, y, 62 + i * 36, 112, 32, 11)) { SkribblNet.setSeconds(i); beep(); return; }
        }
        if (in(x, y, 60, 125, 100, 13)) { SkribblNet.start(); pling(1.4F); }
    }

    private void clickPlay(int x, int y, int button) {
        int ph = SkribblNet.phase;
        boolean me = SkribblNet.mySlot == SkribblNet.drawer;
        if (ph == SkribblGame.END) {
            if (in(x, y, 70, 120, 80, 12)) { SkribblNet.leave(); screen = MENU; beep(); }
            return;
        }
        if (ph == SkribblGame.PICK && me) {
            for (int i = 0; i < 3; i++) if (in(x, y, 15, 34 + i * 19, 100, 16)) { SkribblNet.pick(i); pling(1.2F); return; }
        }
        if (ph == SkribblGame.REVEAL && !me && !SkribblNet.liked && SkribblNet.word >= 0 && in(x, y, 92, 105, 30, 16)) { SkribblNet.like(); pling(1.5F); return; }
        if (!iDraw()) return;
        if (in(x, y, BX, BY, SkribblCanvas.CW, SkribblCanvas.CH)) {
            if (button != 0) return;
            if (tool == 2) {
                SkribblNet.op(++SkribblNet.strokeNo + ",2," + color + ",0," + (x - BX) + "," + (y - BY));
                pling(1.1F);
            } else down = true;
            return;
        }
        for (int i = 0; i < 16; i++) {
            if (in(x, y, 6 + (i % 8) * 9, 105 + (i / 8) * 10, 8, 8)) { color = i; if (tool == 1) tool = 0; beep(); return; }
        }
        for (int i = 0; i < 3; i++) if (in(x, y, 82 + i * 13, 104, 12, 11)) { tool = i; beep(); return; }
        for (int i = 0; i < 4; i++) if (in(x, y, 82 + i * 10, 117, 9, 9)) { sizeIdx = i; beep(); return; }
        if (in(x, y, 82, 128, 18, 8)) { SkribblNet.undo(); beep(); }
        else if (in(x, y, 102, 128, 18, 8)) { SkribblNet.clearBoard(); pling(0.8F); }
    }

    private void clickGallery(int x, int y) {
        List<SkribblGallery.Entry> list = SkribblGallery.list();
        if (gView >= 0) {
            if (gView >= list.size()) { gView = -1; return; }
            if (in(x, y, 4, 3, 24, 12)) { gView = -1; gSure = 0; beep(); }
            else if (in(x, y, 14, 112, 24, 12) && gView > 0) { gView--; gSure = 0; beep(); }
            else if (in(x, y, 182, 112, 24, 12) && gView < list.size() - 1) { gView++; gSure = 0; beep(); }
            else if (in(x, y, 76, 112, 68, 12)) {
                if (gSure == 0) { gSure = 1; beep(); }
                else { SkribblGallery.remove(gView); gSure = 0; gView = Math.min(gView, SkribblGallery.count() - 1); pling(0.7F); }
            }
            return;
        }
        if (in(x, y, 4, 3, 24, 12)) { screen = MENU; beep(); return; }
        int pages = Math.max(1, (list.size() + 7) / 8);
        if (in(x, y, 150, 3, 22, 12) && gPage > 0) { gPage--; beep(); return; }
        if (in(x, y, 192, 3, 22, 12) && gPage < pages - 1) { gPage++; beep(); return; }
        for (int i = 0; i < 8; i++) {
            int idx = gPage * 8 + i;
            if (idx < list.size() && in(x, y, 6 + (i % 4) * 53, 22 + (i / 4) * 52, 50, 34)) { gView = idx; gSure = 0; pling(1.2F); return; }
        }
    }

    // ------------------------------------------------------------------ keys

    @Override
    public boolean key(int keyCode) {
        if (screen != PLAY || SkribblNet.phase == SkribblGame.END) return false;
        if (keyCode == 259) {                                       // backspace
            if (input.length() > 0) input.setLength(input.length() - 1);
            return true;
        }
        if (keyCode == 257 || keyCode == 335) {                     // enter
            String t = input.toString().trim();
            if (!t.isEmpty()) { SkribblNet.say(t); }
            input.setLength(0);
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        if (screen != PLAY || SkribblNet.phase == SkribblGame.END) return false;
        if (c < 32 || c == 127 || input.length() >= 44) return true;
        input.append(c);
        return true;
    }

    // ------------------------------------------------------------------ drawing helpers

    private static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** A rounded card with a soft shadow. */
    private static void panel(GuiGraphics g, int x, int y, int w, int h, int border, int fill) {
        rect(g, x + 1, y + 2, w, h, 0x26302848);
        rect(g, x + 1, y, w - 2, h, border);
        rect(g, x, y + 1, w, h - 2, border);
        rect(g, x + 2, y + 1, w - 4, h - 2, fill);
        rect(g, x + 1, y + 2, w - 2, h - 4, fill);
        rect(g, x + 2, y + 1, w - 4, 1, 0x80FFFFFF);
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String s, int fill, int textColor) {
        boolean hov = in(mx, my, x, y, w, h);
        panel(g, x, y, w, h, mix(fill, INK, 0.28F), hov ? mix(fill, 0xFFFFFFFF, 0.35F) : fill);
        ctextW(g, s, x + w / 2, y + (h - 8) / 2 + 1, w - 6, textColor);
    }

    private static void stext(GuiGraphics g, String s, float x, float y, float k, int argb) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(k, k, 1F);
        dev.cutemod.client.os.CuteFont.draw(g, font(), s, 0, 0, argb, false);
        g.pose().popPose();
    }

    private static void bigText(GuiGraphics g, String s, int cx, int y, float k, int argb, int shadow) {
        float x = cx - tw(s) * k / 2F;
        stext(g, s, x + 1, y + 1, k, shadow);
        stext(g, s, x, y, k, argb);
    }

    private static void face(GuiGraphics g, int cx, int cy, int r, int col, boolean bot) {
        if (bot) rect(g, cx - r, cy - r + 1, r * 2 + 1, r * 2 - 1, col); else disc(g, cx, cy, r, col);
        rect(g, cx - r / 2 - 1, cy - 1, 1, 1 + r / 4, INK);
        rect(g, cx + r / 2, cy - 1, 1, 1 + r / 4, INK);
        if (bot) rect(g, cx, cy - r - 1, 1, 1, INK);
    }

    private void backdrop(GuiGraphics g) {
        for (int yy = 0; yy < H; yy += 4) rect(g, 0, yy, W, 4, mix(0xFFFFEEF5, 0xFFE4F1FF, yy / (float) H));
        for (int i = 0; i < 16; i++) {
            int x = (i * 47 + anim / 5) % (W + 16) - 8, y = (i * 29 + 11) % H;
            disc(g, x, y, 2 + i % 3, 0x38FFFFFF);
        }
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g) {
        backdrop(g);
        switch (screen) {
            case MENU -> renderMenu(g);
            case ROOMS -> renderRooms(g);
            case ROOM -> renderRoom(g);
            case PLAY -> renderPlay(g);
            default -> renderGallery(g);
        }
        if (noticeT > 0 && screen != PLAY) {
            panel(g, 30, 124, 160, 12, 0xFFE8566B, 0xFFFFE4EA);
            ctextW(g, tr("cutemod.skribbl.notice." + notice), W / 2, 126, 150, PINK);
        }
    }

    private void doodle(GuiGraphics g, int x, int y, int k) {
        int wob = (int) Math.round(Math.sin((anim + k * 20) / 14.0) * 2);
        y += wob;
        switch (k % 3) {
            case 0 -> { for (int i = 0; i < 9; i++) rect(g, x + i, y + 9 - i, 3, 3, i < 2 ? 0xFFE8C9A0 : i < 7 ? 0xFFF7D860 : 0xFFE8566B); rect(g, x, y + 9, 2, 2, INK); }
            case 1 -> { disc(g, x + 4, y + 4, 4, 0xFFF4A0C8); disc(g, x + 10, y + 4, 4, 0xFFF4A0C8); rect(g, x + 2, y + 5, 11, 4, 0xFFF4A0C8); rect(g, x + 4, y + 9, 7, 3, 0xFFF4A0C8); rect(g, x + 6, y + 12, 3, 2, 0xFFF4A0C8); }
            default -> { rect(g, x + 4, y, 3, 11, 0xFFF7D860); rect(g, x, y + 4, 11, 3, 0xFFF7D860); rect(g, x + 3, y + 3, 5, 5, 0xFFFFEFA0); }
        }
    }

    private void renderMenu(GuiGraphics g) {
        doodle(g, 14, 16, 0);
        doodle(g, 190, 18, 1);
        doodle(g, 32, 40, 2);
        doodle(g, 176, 38, 2);
        bigText(g, tr("cutemod.game.skribbl"), W / 2, 12, 1.7F, PINK, 0xFFFFD0E4);
        ctextW(g, tr("cutemod.skribbl.tagline"), W / 2, 33, 190, MUTED);
        button(g, 45, 48, 130, 17, tr("cutemod.skribbl.solo"), 0xFFBFEFD6, INK);
        button(g, 45, 69, 130, 17, tr("cutemod.skribbl.online"), 0xFFC9B8F5, INK);
        button(g, 45, 90, 130, 17, tr("cutemod.skribbl.gallery", SkribblGallery.count()), 0xFFF7E49A, INK);
        ctextW(g, tr("cutemod.skribbl.menu_tip"), W / 2, 114, 200, MUTED);
    }

    private void header(GuiGraphics g, String title) {
        panel(g, 3, 1, 214, 15, SOFT, CARD);
        button(g, 4, 3, 24, 12, "<", 0xFFF4C9DC, INK);
        ctextW(g, title, W / 2, 4, 130, INK);
    }

    private void renderRooms(GuiGraphics g) {
        header(g, tr("cutemod.skribbl.rooms"));
        button(g, 138, 3, 78, 12, tr("cutemod.skribbl.create"), 0xFFBFEFD6, INK);
        int rows = Math.min(SkribblNet.hosts.size(), 5);
        if (rows == 0) {
            ctextW(g, tr("cutemod.skribbl.rooms.none"), W / 2, 66, W - 24, MUTED);
            return;
        }
        for (int i = 0; i < rows; i++) {
            int y = 24 + i * 20;
            boolean hover = in(mx, my, 8, y, 204, 18);
            panel(g, 8, y, 204, 18, SOFT, hover ? 0xFFFFF0F6 : CARD);
            face(g, 20, y + 9, 5, AVATAR[i % 8], false);
            String host = SkribblNet.hosts.get(i);
            ctextW(g, host, 30 + Math.min(tw(host), 90) / 2, y + 5, 90, INK);
            String free = tr("cutemod.skribbl.free", SkribblNet.open.get(i));
            text(g, free, 150 - tw(free), y + 5, MUTED);
            button(g, 156, y + 3, 50, 12, tr("cutemod.skribbl.join"), 0xFFF7D860, INK);
        }
    }

    private void renderRoom(GuiGraphics g) {
        header(g, tr("cutemod.skribbl.room"));
        for (int i = 0; i < SkribblGame.SLOTS; i++) {
            int x = 6 + (i % 2) * 106, y = 20 + (i / 2) * 19, t = SkribblNet.slotType[i];
            boolean click = SkribblNet.youHost && i != SkribblNet.mySlot;
            boolean hov = click && in(mx, my, x, y, 102, 17);
            panel(g, x, y, 102, 17, t == 3 ? 0xFFB9A6E8 : SOFT, hov ? 0xFFFFF0F6 : t == 0 ? 0xFFF1ECF3 : CARD);
            if (t >= 2) face(g, x + 10, y + 8, 5, AVATAR[i % 8], t == 2);
            else disc(g, x + 10, y + 8, 4, 0xFFD9D2E0);
            String label = t == 3 ? SkribblNet.slotName[i] : tr("cutemod.skribbl.slot." + t);
            ctextW(g, label, x + 58, y + 5, 80, t >= 2 ? INK : MUTED);
        }
        String r = tr("cutemod.skribbl.rounds_label"), s = tr("cutemod.skribbl.time_label");
        text(g, r, 8, 101, INK);
        text(g, s, 8, 114, INK);
        int[] rv = SkribblGame.ROUNDS, sv = SkribblGame.SECONDS;
        for (int i = 0; i < 3; i++) {
            chip(g, 62 + i * 36, 99, 32, 11, Integer.toString(rv[i]), SkribblNet.roundsIdx == i);
            chip(g, 62 + i * 36, 112, 32, 11, tr("cutemod.skribbl.sec", sv[i]), SkribblNet.secondsIdx == i);
        }
        if (SkribblNet.youHost) button(g, 60, 125, 100, 13, tr("cutemod.skribbl.start"), 0xFFF58FB8, INK);
        else ctextW(g, tr("cutemod.skribbl.wait"), W / 2, 128, 200, MUTED);
    }

    private void chip(GuiGraphics g, int x, int y, int w, int h, String s, boolean on) {
        boolean hov = SkribblNet.youHost && in(mx, my, x, y, w, h);
        panel(g, x, y, w, h, on ? 0xFFE0A800 : SOFT, on ? 0xFFF7D860 : hov ? 0xFFFFF0F6 : CARD);
        ctextW(g, s, x + w / 2, y + (h - 8) / 2 + 1, w - 4, INK);
    }

    // ---- the game

    private void renderPlay(GuiGraphics g) {
        int ph = SkribblNet.phase;
        boolean me = SkribblNet.mySlot == SkribblNet.drawer;
        topBar(g, ph);
        panel(g, 3, 16, 124, 84, SOFT, 0xFFFFFFFF);
        if (ph == SkribblGame.PICK) {
            rect(g, BX, BY, SkribblCanvas.CW, SkribblCanvas.CH, 0xFFFFF6EE);
            pickOverlay(g, me);
        } else {
            renderBoard(g);
            if (ph == SkribblGame.DRAW && me) cursor(g);
        }
        playersWindow(g);
        chatWindow(g);
        bottomPanel(g, ph, me);
        if (ph == SkribblGame.END) endOverlay(g);
    }

    private String drawerName() { return SkribblNet.drawer >= 0 ? SkribblNet.slotName[SkribblNet.drawer & 7] : ""; }

    private void topBar(GuiGraphics g, int ph) {
        panel(g, 3, 1, 46, 12, SOFT, CARD);
        ctextW(g, tr("cutemod.skribbl.round", Math.min(SkribblNet.round + 1, Math.max(1, SkribblNet.rounds)), SkribblNet.rounds), 26, 3, 42, INK);
        panel(g, 52, 1, 116, 12, SOFT, CARD);
        String mid = switch (ph) {
            case SkribblGame.PICK -> tr("cutemod.skribbl.picking", drawerName());
            case SkribblGame.DRAW -> SkribblNet.mySlot == SkribblNet.drawer ? tr("cutemod.skribbl.draw_this", wordText(SkribblNet.word)) : tr("cutemod.skribbl.drawing", drawerName());
            case SkribblGame.REVEAL -> tr("cutemod.skribbl.the_word", wordText(SkribblNet.word));
            default -> tr("cutemod.skribbl.final");
        };
        ctextW(g, mid, 110, 3, 110, SkribblNet.mySlot == SkribblNet.drawer && ph == SkribblGame.DRAW ? PINK : INK);
        panel(g, 171, 1, 46, 12, SOFT, CARD);
        if (ph == SkribblGame.DRAW) {
            int t = SkribblNet.ticksLeft(), sec = (t + 19) / 20;
            ctextW(g, (sec / 60) + ":" + (sec % 60 < 10 ? "0" : "") + (sec % 60), 194, 3, 40, sec <= 10 ? PINK : INK);
            float f = Math.min(1F, t / (float) Math.max(1, SkribblNet.timeTotal));
            rect(g, 3, 14, 214, 2, 0x33302848);
            rect(g, 3, 14, Math.round(214 * f), 2, f > 0.5F ? MINT : f > 0.2F ? 0xFFF59B5B : PINK);
        }
    }

    private void rebuildRuns() {
        seenBoardV = SkribblNet.boardVersion;
        byte[] px = SkribblNet.board.px;
        int n = 0;
        for (int y = 0; y < SkribblCanvas.CH; y++) {
            int x = 0;
            while (x < SkribblCanvas.CW) {
                int c = px[y * SkribblCanvas.CW + x], x0 = x;
                while (x < SkribblCanvas.CW && px[y * SkribblCanvas.CW + x] == c) x++;
                if (c == 0) continue;
                if (n + 4 > runs.length) runs = java.util.Arrays.copyOf(runs, runs.length * 2);
                runs[n++] = x0; runs[n++] = y; runs[n++] = x - x0; runs[n++] = c;
            }
        }
        runN = n;
    }

    private void renderBoard(GuiGraphics g) {
        if (seenBoardV != SkribblNet.boardVersion) rebuildRuns();
        rect(g, BX, BY, SkribblCanvas.CW, SkribblCanvas.CH, SkribblCanvas.PALETTE[0]);
        for (int i = 0; i < runN; i += 4) rect(g, BX + runs[i], BY + runs[i + 1], runs[i + 2], 1, SkribblCanvas.PALETTE[runs[i + 3]]);
    }

    private void cursor(GuiGraphics g) {
        int bx = mx - BX, by = my - BY;
        if (bx < 0 || by < 0 || bx >= SkribblCanvas.CW || by >= SkribblCanvas.CH) return;
        if (tool == 2) { rect(g, mx - 2, my, 5, 1, INK); rect(g, mx, my - 2, 1, 5, INK); return; }
        int r = SkribblCanvas.SIZES[sizeIdx] - 1;
        int c = tool == 1 ? 0xCCE8566B : 0xAA3A3347;
        rect(g, mx - r - 1, my - r - 1, 2 * r + 3, 1, c);
        rect(g, mx - r - 1, my + r + 1, 2 * r + 3, 1, c);
        rect(g, mx - r - 1, my - r, 1, 2 * r + 1, c);
        rect(g, mx + r + 1, my - r, 1, 2 * r + 1, c);
    }

    private void pickOverlay(GuiGraphics g, boolean me) {
        if (me) {
            ctextW(g, tr("cutemod.skribbl.pick"), 65, 21, 110, PINK);
            for (int i = 0; i < 3; i++) {
                String w = i < SkribblNet.choices.size() ? wordText(SkribblNet.choices.get(i)) : "";
                button(g, 15, 34 + i * 19, 100, 16, w, new int[]{0xFFBFEFD6, 0xFFC9B8F5, 0xFFF7E49A}[i], INK);
            }
        } else {
            ctextW(g, tr("cutemod.skribbl.picking", drawerName()), 65, 44, 112, INK);
            String dots = ".".repeat(1 + (anim / 20) % 3);
            ctext(g, dots, 65, 56, MUTED);
            doodle(g, 59, 66, 0);
        }
    }

    private void revealPanel(GuiGraphics g, boolean me) {
        int gain = SkribblNet.gains[SkribblNet.mySlot & 7];
        if (SkribblNet.word >= 0) {
            String w = wordText(SkribblNet.word);
            boolean heart = !me;
            int room = heart ? 80 : 112;
            float k = Math.min(1.4F, room / (float) Math.max(1, tw(w)));
            bigText(g, w, heart ? 48 : 65, 106, k, 0xFF9B7BE0, 0xFFE4DAF8);
            if (heart) {
                boolean hov = in(mx, my, 92, 105, 30, 16);
                panel(g, 92, 105, 30, 16, softHeart(SkribblNet.liked), hov && !SkribblNet.liked ? 0xFFFFE4EA : CARD);
                int hc = SkribblNet.liked ? PINK : 0xFFF4A0C8;
                disc(g, 99, 111, 2, hc);
                disc(g, 103, 111, 2, hc);
                rect(g, 97, 112, 8, 2, hc);
                rect(g, 99, 114, 4, 2, hc);
                text(g, Integer.toString(SkribblNet.likes), 108, 109, INK);
            } else if (SkribblNet.likes > 0) text(g, "<3 " + SkribblNet.likes, 100, 109, PINK);
        } else ctextW(g, tr("cutemod.skribbl.nobody"), 65, 108, 112, MUTED);
        ctextW(g, gain > 0 ? tr("cutemod.skribbl.points", gain) : tr("cutemod.skribbl.nopoints"), 65, 123, 116, gain > 0 ? MINT : MUTED);
        stext(g, tr("cutemod.skribbl.saved"), 65 - tw(tr("cutemod.skribbl.saved")) * 0.35F, 131, 0.7F, MUTED);
    }

    private static int softHeart(boolean liked) { return liked ? PINK : SOFT; }

    private void playersWindow(GuiGraphics g) {
        panel(g, 130, 16, 87, 42, SOFT, CARD);
        stext(g, tr("cutemod.skribbl.players"), 134, 17, 0.62F, MUTED);
        int k = 0;
        for (int i = 0; i < SkribblGame.SLOTS; i++) {
            if (SkribblNet.slotType[i] < 2) continue;
            int x = 132 + (k % 2) * 42, y = 24 + (k / 2) * 8;
            k++;
            boolean draws = i == SkribblNet.drawer && SkribblNet.phase != SkribblGame.END;
            boolean got = (SkribblNet.guessedMask & (1 << i)) != 0;
            if (draws) rect(g, x - 1, y, 41, 8, 0x66F7D860);
            else if (got) rect(g, x - 1, y, 41, 8, 0x668FD17A);
            face(g, x + 3, y + 4, 3, AVATAR[i % 8], SkribblNet.slotType[i] == 2);
            String name = clip(SkribblNet.slotName[i], 30);
            stext(g, name, x + 8, y + 1, 0.62F, i == SkribblNet.mySlot ? PINK : INK);
            boolean gain = SkribblNet.phase == SkribblGame.REVEAL && SkribblNet.gains[i] > 0;
            String sc = gain ? "+" + SkribblNet.gains[i] : Integer.toString(SkribblNet.scores[i]);
            stext(g, sc, x + 40 - tw(sc) * 0.62F, y + 1, 0.62F, gain ? MINT : MUTED);
        }
    }

    // ---- the chat window

    private static final int[] CHAT_NAME = {0xFFB85C8A};

    private void rebuildChat() {
        seenChatV = SkribblNet.chatVersion;
        lines.clear();
        List<SkribblNet.Line> all = SkribblNet.chat;
        for (int i = Math.max(0, all.size() - 30); i < all.size(); i++) addWrapped(all.get(i));
    }

    private void addWrapped(SkribblNet.Line l) {
        String pre = "", body;
        int pc = INK, tc = INK;
        switch (l.kind) {
            case SkribblGame.K_SAY -> { pre = l.name + ": "; body = l.text; pc = CHAT_NAME[0]; }
            case SkribblGame.K_WHISPER -> { pre = l.name + ": "; body = l.text; pc = tc = 0xFF6E7BC9; }
            case SkribblGame.K_GUESSED -> { body = tr("cutemod.skribbl.c.guessed", l.name); tc = 0xFF2E9B6E; }
            case SkribblGame.K_CLOSE -> { body = tr("cutemod.skribbl.c.close", l.text); tc = 0xFFD08A00; }
            case SkribblGame.K_WORD -> { body = tr("cutemod.skribbl.c.word", wordText(l.arg)); tc = 0xFF9B7BE0; }
            case SkribblGame.K_NOBODY -> { body = tr("cutemod.skribbl.c.nobody"); tc = MUTED; }
            case SkribblGame.K_JOIN, SkribblGame.K_LEAVE -> { body = tr("cutemod.skribbl.c.left", l.name); tc = MUTED; }
            default -> { body = tr("cutemod.skribbl.c.drawer", l.name); tc = MUTED; }
        }
        String full = pre + body;
        int limit = 112, start = 0;
        boolean first = true;
        while (start < full.length()) {
            int best = start + 1;
            for (int e = start + 1; e <= full.length(); e++) {
                if (tw(full.substring(start, e)) > limit) break;
                best = e;
            }
            if (best < full.length()) {
                int sp = full.lastIndexOf(' ', best - 1);
                if (sp > start + 3) best = sp + 1;
            }
            String seg = full.substring(start, best);
            WL w = new WL();
            w.tc = tc;
            w.pc = pc;
            if (first) {
                int pl = Math.min(pre.length(), seg.length());
                w.pre = seg.substring(0, pl);
                w.txt = seg.substring(pl);
            } else w.txt = seg;
            lines.add(w);
            start = best;
            first = false;
        }
    }

    private void chatWindow(GuiGraphics g) {
        panel(g, 130, 60, 87, 77, SOFT, CARD);
        stext(g, tr("cutemod.skribbl.chat"), 134, 61, 0.62F, MUTED);
        if (seenChatV != SkribblNet.chatVersion) rebuildChat();
        int maxLines = 8;
        int y = 69 + (maxLines - 1) * 6 + 1;
        for (int i = lines.size() - 1, n = 0; i >= 0 && n < maxLines; i--, n++, y -= 6) {
            WL w = lines.get(i);
            float x = 133;
            if (!w.pre.isEmpty()) { stext(g, w.pre, x, y, 0.7F, w.pc); x += tw(w.pre) * 0.7F; }
            stext(g, w.txt, x, y, 0.7F, w.tc);
        }
        panel(g, 132, 125, 83, 10, SOFT, 0xFFFFFFFF);
        String shown = input.toString();
        while (shown.length() > 1 && tw(shown) * 0.8F > 74) shown = shown.substring(1);
        if (shown.isEmpty()) stext(g, tr("cutemod.skribbl.type"), 135, 127, 0.7F, 0xFFC4BFCF);
        else {
            stext(g, shown, 135, 126, 0.8F, INK);
            if ((anim / 25) % 2 == 0) rect(g, 135 + Math.round(tw(shown) * 0.8F), 127, 1, 6, PINK);
        }
    }

    // ---- under the board: the tools for the drawer, the hint for the others

    private void bottomPanel(GuiGraphics g, int ph, boolean me) {
        panel(g, 3, 102, 124, 36, SOFT, CARD);
        if (ph == SkribblGame.DRAW && me) { tools(g); return; }
        int cx = 65;
        if (ph == SkribblGame.DRAW) {
            boolean knows = SkribblNet.word >= 0;
            ctextW(g, tr(knows ? "cutemod.skribbl.you_know" : "cutemod.skribbl.guess_tip"), cx, 105, 116, knows ? MINT : MUTED);
            String h = knows ? wordText(SkribblNet.word) : lang().toLowerCase().startsWith("ru") ? SkribblNet.hintRu : SkribblNet.hintEn;
            float k = Math.min(1.6F, 116F / Math.max(1, tw(h)));
            bigText(g, h, cx, 117, k, knows ? MINT : INK, 0xFFE9DDF0);
        } else if (ph == SkribblGame.REVEAL) {
            revealPanel(g, me);
        } else if (ph == SkribblGame.PICK) {
            ctextW(g, tr(me ? "cutemod.skribbl.pick" : "cutemod.skribbl.guess_tip"), cx, 114, 116, me ? PINK : MUTED);
        }
    }

    private void tools(GuiGraphics g) {
        for (int i = 0; i < 16; i++) {
            int x = 6 + (i % 8) * 9, y = 105 + (i / 8) * 10;
            rect(g, x - 1, y - 1, 10, 10, i == color && tool != 1 ? INK : 0x00000000);
            rect(g, x, y, 8, 8, i == 0 ? 0xFFD9D2E0 : SkribblCanvas.PALETTE[i]);
            if (i == 0) rect(g, x + 1, y + 1, 6, 6, SkribblCanvas.PALETTE[0]);
        }
        for (int i = 0; i < 3; i++) {
            int x = 82 + i * 13;
            boolean on = tool == i;
            panel(g, x, 104, 12, 11, on ? INK : SOFT, on ? 0xFFF7D860 : in(mx, my, x, 104, 12, 11) ? 0xFFFFF0F6 : CARD);
            toolIcon(g, i, x + 2, 106);
        }
        for (int i = 0; i < 4; i++) {
            int x = 82 + i * 10;
            boolean on = sizeIdx == i;
            panel(g, x, 117, 9, 9, on ? INK : SOFT, on ? 0xFFF7D860 : CARD);
            disc(g, x + 4, 121, i, tool == 1 ? 0xFFE8566B : SkribblCanvas.PALETTE[color]);
        }
        button(g, 82, 128, 18, 8, tr("cutemod.skribbl.undo"), 0xFFC9B8F5, INK);
        button(g, 102, 128, 18, 8, tr("cutemod.skribbl.clear"), 0xFFF4C9DC, INK);
        ctextW(g, tr(tool == 0 ? "cutemod.skribbl.pen" : tool == 1 ? "cutemod.skribbl.eraser" : "cutemod.skribbl.fill"), 42, 127, 70, MUTED);
    }

    private static void toolIcon(GuiGraphics g, int tool, int x, int y) {
        switch (tool) {
            case 0 -> { for (int i = 0; i < 6; i++) rect(g, x + i, y + 5 - i, 2, 2, i == 0 ? INK : 0xFFE8566B); rect(g, x + 5, y, 2, 2, 0xFFE8C9A0); }
            case 1 -> { rect(g, x, y + 2, 8, 5, 0xFFF4A0C8); rect(g, x, y + 2, 3, 5, 0xFF6EC3F2); rect(g, x, y + 7, 8, 1, INK); }
            default -> { rect(g, x + 1, y + 2, 6, 5, 0xFF6EC3F2); rect(g, x + 1, y + 2, 6, 1, INK); rect(g, x + 7, y + 4, 1, 3, 0xFF4A78E0); rect(g, x + 4, y, 1, 2, INK); }
        }
    }

    private void endOverlay(GuiGraphics g) {
        for (int i = 0; i < 40; i++) {
            int x = (i * 53 + anim * (1 + i % 3) / 2) % W, y = (i * 31 + anim * (1 + i % 2)) % H;
            rect(g, x, y, 2, 2, AVATAR[i % 8]);
        }
        panel(g, 16, 18, 188, 117, SOFT, 0xF8FFFBF5);
        bigText(g, tr("cutemod.skribbl.final"), W / 2, 22, 1.2F, PINK, 0xFFFFD0E4);
        Integer[] order = new Integer[SkribblGame.SLOTS];
        int n = 0;
        for (int i = 0; i < SkribblGame.SLOTS; i++) if (SkribblNet.slotType[i] >= 2) order[n++] = i;
        java.util.Arrays.sort(order, 0, n, (a, b) -> SkribblNet.scores[b] - SkribblNet.scores[a]);
        for (int r = 0; r < n; r++) {
            int i = order[r], y = 38 + r * 10;
            if (i == SkribblNet.mySlot) rect(g, 22, y - 1, 176, 10, 0x44F7D860);
            int medal = r == 0 ? 0xFFF2C230 : r == 1 ? 0xFFB9C2CC : r == 2 ? 0xFFCD8B4A : 0xFFE6DDEE;
            disc(g, 29, y + 4, 4, medal);
            ctext(g, Integer.toString(r + 1), 29, y, INK);
            face(g, 42, y + 4, 3, AVATAR[i % 8], SkribblNet.slotType[i] == 2);
            text(g, clip(SkribblNet.slotName[i], 100), 50, y, INK);
            String sc = Integer.toString(SkribblNet.scores[i]);
            text(g, sc, 190 - tw(sc), y, r == 0 ? 0xFFD08A00 : INK);
        }
        long gone = (System.nanoTime() - SkribblNet.stateAt) / 1_000_000_000L;
        ctextW(g, tr("cutemod.skribbl.back_in", Math.max(0, END_SECONDS - gone)), W / 2, 109, 170, MUTED);
        button(g, 70, 120, 80, 12, tr("cutemod.skribbl.leave"), 0xFFF4C9DC, INK);
    }

    // ---- the gallery

    private void renderGallery(GuiGraphics g) {
        List<SkribblGallery.Entry> list = SkribblGallery.list();
        if (gView >= 0 && gView < list.size()) { renderPicture(g, list); return; }
        int pages = Math.max(1, (list.size() + 7) / 8);
        header(g, tr("cutemod.skribbl.gallery", list.size()));
        if (pages > 1) {
            button(g, 150, 3, 22, 12, "<", 0xFFC9B8F5, INK);
            button(g, 192, 3, 22, 12, ">", 0xFFC9B8F5, INK);
            ctext(g, (gPage + 1) + "/" + pages, 182, 5, INK);
        }
        if (list.isEmpty()) {
            ctextW(g, tr("cutemod.skribbl.gallery.none"), W / 2, 66, W - 24, MUTED);
            return;
        }
        for (int i = 0; i < 8; i++) {
            int idx = gPage * 8 + i;
            if (idx >= list.size()) break;
            int x = 6 + (i % 4) * 53, y = 22 + (i / 4) * 52;
            boolean hov = in(mx, my, x, y, 50, 34);
            panel(g, x, y, 50, 34, hov ? PINK : SOFT, 0xFFFFFFFF);
            thumb(g, list.get(idx), x + 1, y + 1, 48F / SkribblCanvas.CW);
            ctextW(g, SkribblWords.word(list.get(idx).word, lang()), x + 25, y + 37, 50, INK);
        }
    }

    /** A picture at the given scale: the paper and its runs of colour. */
    private static void thumb(GuiGraphics g, SkribblGallery.Entry e, int x, int y, float k) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(k, k, 1F);
        rect(g, 0, 0, SkribblCanvas.CW, SkribblCanvas.CH, SkribblCanvas.PALETTE[0]);
        int[] r = e.runs();
        for (int i = 0; i < r.length; i += 4) rect(g, r[i], r[i + 1], r[i + 2], 1, SkribblCanvas.PALETTE[r[i + 3]]);
        g.pose().popPose();
    }

    private void renderPicture(GuiGraphics g, List<SkribblGallery.Entry> list) {
        SkribblGallery.Entry e = list.get(gView);
        header(g, SkribblWords.word(e.word, lang()));
        panel(g, 48, 20, 124, 84, SOFT, 0xFFFFFFFF);
        thumb(g, e, 50, 22, 1F);
        ctextW(g, tr("cutemod.skribbl.by", e.by.isEmpty() ? "?" : e.by), W / 2, 106, 200, MUTED);
        button(g, 14, 112, 24, 12, "<", 0xFFC9B8F5, INK);
        button(g, 182, 112, 24, 12, ">", 0xFFC9B8F5, INK);
        button(g, 76, 112, 68, 12, tr(gSure == 0 ? "cutemod.skribbl.delete" : "cutemod.skribbl.sure"), gSure == 0 ? 0xFFF4C9DC : 0xFFE8566B, INK);
    }
}
