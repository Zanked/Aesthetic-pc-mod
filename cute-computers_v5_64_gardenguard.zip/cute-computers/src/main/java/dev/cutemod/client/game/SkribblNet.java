package dev.cutemod.client.game;

import dev.cutemod.data.SkribblCanvas;
import dev.cutemod.data.SkribblGame;
import dev.cutemod.net.SkribblActionPayload;
import dev.cutemod.net.SkribblChatPayload;
import dev.cutemod.net.SkribblDrawPayload;
import dev.cutemod.net.SkribblLobbyPayload;
import dev.cutemod.net.SkribblStatePayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** The client side of online Scribble Pals: what the server last told us (rooms, our room, the running game, the picture, the chat) and the messages we send. */
public final class SkribblNet {
    private SkribblNet() {}

    // ---- the lobby
    public static List<String> hosts = new ArrayList<>();
    public static List<Integer> open = new ArrayList<>();
    public static boolean inRoom, inGame, youHost;
    public static int mySlot, roundsIdx = 1, secondsIdx = 1;
    /** 0 empty, 1 open, 2 computer player, 3 person. */
    public static final int[] slotType = new int[SkribblGame.SLOTS];
    public static final String[] slotName = new String[SkribblGame.SLOTS];
    /** Goes up with every lobby message. */
    public static int version;
    static { java.util.Arrays.fill(slotName, ""); }

    // ---- the running game
    public static int phase, round, rounds, drawer = -1, timeTotal, timeLeft, word = -1, guessedMask, likes;
    public static boolean liked;
    public static List<Integer> choices = new ArrayList<>();
    public static String hintEn = "", hintRu = "";
    public static final int[] scores = new int[SkribblGame.SLOTS], gains = new int[SkribblGame.SLOTS];
    /** When the last state arrived (the timer counts on from there). */
    public static long stateAt;
    public static int stateVersion;

    // ---- the picture and the chat
    public static final SkribblCanvas board = new SkribblCanvas();
    public static int boardVersion;
    public static int strokeNo;

    public static final class Line {
        public final int kind, arg;
        public final String name, text;
        Line(int kind, String name, String text, int arg) { this.kind = kind; this.name = name; this.text = text; this.arg = arg; }
    }

    public static final List<Line> chat = new ArrayList<>();
    public static int chatVersion;

    private static int notice;
    private static long ignoreUntil;

    public static void apply(SkribblLobbyPayload p) {
        hosts = new ArrayList<>(p.hosts());
        open = new ArrayList<>(p.open());
        boolean room = p.inRoom();
        inRoom = System.currentTimeMillis() < ignoreUntil ? false : room;
        inGame = inRoom && p.inGame();
        youHost = p.youHost();
        mySlot = p.mySlot();
        roundsIdx = p.roundsIdx();
        secondsIdx = p.secondsIdx();
        for (int i = 0; i < SkribblGame.SLOTS; i++) {
            slotType[i] = i < p.slotType().size() ? p.slotType().get(i) : 0;
            slotName[i] = i < p.slotName().size() ? p.slotName().get(i) : "";
        }
        if (!inGame) phase = 0;
        if (!inRoom) { chat.clear(); chatVersion++; board.clear(); boardVersion++; }
        else if (!inGame) { chat.clear(); chatVersion++; }
        if (p.notice() != 0) notice = p.notice();
        version++;
    }

    public static void applyState(SkribblStatePayload p) {
        int before = phase;
        phase = p.phase();
        round = p.round();
        rounds = p.rounds();
        drawer = p.drawer();
        timeTotal = p.timeTotal();
        timeLeft = p.timeLeft();
        word = p.word();
        choices = new ArrayList<>(p.choices());
        hintEn = p.hintEn();
        hintRu = p.hintRu();
        guessedMask = p.guessedMask();
        likes = p.likes();
        liked = p.liked();
        for (int i = 0; i < SkribblGame.SLOTS; i++) {
            scores[i] = i < p.scores().size() ? p.scores().get(i) : 0;
            gains[i] = i < p.gains().size() ? p.gains().get(i) : 0;
        }
        stateAt = System.nanoTime();
        stateVersion++;
        // the turn is over and we know the word: keep the picture
        if (phase == SkribblGame.REVEAL && before != SkribblGame.REVEAL && word >= 0 && drawer >= 0) {
            SkribblGallery.add(word, drawer < slotName.length ? slotName[drawer] : "", board.px);
        }
    }

    public static void applyDraw(SkribblDrawPayload p) {
        switch (p.kind()) {
            case 0 -> { for (String o : p.ops()) board.add(o); }
            case 1 -> board.undo();
            case 2 -> { board.clear(); strokeNo = 0; }
            case 3 -> { board.setOps(p.ops()); }
            default -> { }
        }
        boardVersion++;
    }

    public static void applyChat(SkribblChatPayload p) {
        chat.add(new Line(p.kind(), p.name(), p.text(), p.arg()));
        while (chat.size() > 80) chat.remove(0);
        chatVersion++;
    }

    public static void clear() {
        hosts = new ArrayList<>();
        open = new ArrayList<>();
        inRoom = inGame = youHost = false;
        phase = 0;
        notice = 0;
        chat.clear();
        board.clear();
        boardVersion++;
        version++;
    }

    /** The ticks left in this turn (counted on from the last state). */
    public static int ticksLeft() {
        if (phase != SkribblGame.DRAW) return 0;
        long passed = (System.nanoTime() - stateAt) / 50_000_000L;
        return (int) Math.max(0, timeLeft - passed);
    }

    /** The last notice (the room is gone, ...), only once. */
    public static int takeNotice() {
        int n = notice;
        notice = 0;
        return n;
    }

    private static void send(int action, int a, String text) {
        PacketDistributor.sendToServer(new SkribblActionPayload(action, a, text));
    }

    public static void request() { send(0, 0, ""); }

    public static void create() { send(1, 0, ""); }

    public static void join(String host) { send(2, 0, host); }

    /** Leave the room (or the game). We forget the room at once, the server confirms later. */
    public static void leave() {
        send(3, 0, "");
        ignoreUntil = System.currentTimeMillis() + 1500;
        inRoom = inGame = false;
        phase = 0;
        version++;
    }

    public static void slot(int i) { send(4, i, ""); }

    public static void start() { send(5, 0, ""); }

    public static void setRounds(int idx) { send(6, idx, ""); }

    public static void setSeconds(int idx) { send(7, idx, ""); }

    public static void pick(int i) { send(8, i, ""); }

    /** A drawing operation of ours: drawn on our own board at once, the server passes it on. */
    public static void op(String op) {
        if (board.add(op)) { boardVersion++; send(9, 0, op); }
    }

    public static void undo() {
        if (board.undo()) { boardVersion++; send(10, 0, ""); }
    }

    public static void clearBoard() {
        board.clear();
        boardVersion++;
        send(11, 0, "");
    }

    public static void say(String text) { send(12, 0, text); }

    public static void like() { send(13, 0, ""); }
}
