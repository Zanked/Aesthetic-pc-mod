package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Garden Guard (tower defense). Pests crawl along the path towards the cabbage patch; cute pet guards placed
 * on the grass shoot them. 20 waves, a boss snail every 5th wave. Mouse: pick a guard below, click a tile to
 * place it, click a placed guard to upgrade / sell it. Keys: 1-4 pick, U upgrade, S sell, Space start / speed.
 */
public class GardenGuard extends MiniGame {
    // ---------- field ----------
    private static final int T = 12, COLS = 18, ROWS = 9, OY = 12;     // tile size, grid size, y of the grid
    private static final int BAR_Y = 122;                              // the shop bar at the bottom
    private static final int MAX_WAVE = 20;
    /** Corners of the path in tiles (col, row); the pests walk from the first to the last. */
    private static final int[][] CORNERS = {{0, 1}, {4, 1}, {4, 6}, {9, 6}, {9, 2}, {13, 2}, {13, 7}, {17, 7}};
    /** Scenery that blocks a tile: col, row, kind (0 tree, 1 bush, 2 rock, 3 cabbage). */
    private static final int[][] DECOR = {
            {1, 4, 0}, {7, 1, 0}, {11, 4, 0}, {16, 2, 0}, {0, 6, 1}, {2, 7, 1}, {11, 8, 1}, {16, 0, 1},
            {6, 3, 2}, {15, 5, 2}, {7, 8, 2}, {16, 8, 3}, {17, 8, 3}, {17, 6, 3}};
    private static final boolean[][] PATH = new boolean[COLS][ROWS];
    private static final boolean[][] BLOCK = new boolean[COLS][ROWS];
    private static final float[] WX = new float[CORNERS.length], WY = new float[CORNERS.length], CUM = new float[CORNERS.length];
    private static final float TOTAL;
    /** Pre-computed scenery so that nothing jumps around between frames (flat arrays: x, y[, extra]). */
    private static final int[] TUFT, FLOWER, PEBBLE;

    static {
        int n = CORNERS.length;
        for (int i = 0; i < n; i++) {
            WX[i] = CORNERS[i][0] * T + T / 2F;
            WY[i] = OY + CORNERS[i][1] * T + T / 2F;
            if (i > 0) CUM[i] = CUM[i - 1] + Math.abs(WX[i] - WX[i - 1]) + Math.abs(WY[i] - WY[i - 1]);
        }
        TOTAL = CUM[n - 1];
        for (int i = 0; i + 1 < n; i++) {
            int c0 = Math.min(CORNERS[i][0], CORNERS[i + 1][0]), c1 = Math.max(CORNERS[i][0], CORNERS[i + 1][0]);
            int r0 = Math.min(CORNERS[i][1], CORNERS[i + 1][1]), r1 = Math.max(CORNERS[i][1], CORNERS[i + 1][1]);
            for (int c = c0; c <= c1; c++) for (int r = r0; r <= r1; r++) PATH[c][r] = true;
        }
        for (int[] d : DECOR) BLOCK[d[0]][d[1]] = true;
        int[] flowerCols = {0xFFFFFFFF, 0xFFFFC2DC, 0xFFFFE27A, 0xFFC9B6FF, 0xFFFFB07A};
        List<Integer> tuft = new ArrayList<>(), flower = new ArrayList<>(), pebble = new ArrayList<>();
        for (int c = 0; c < COLS; c++) {
            for (int r = 0; r < ROWS; r++) {
                int x = c * T, y = OY + r * T, h = c * 31 + r * 7;
                if (PATH[c][r]) {
                    for (int k = 0; k < 3; k++) {
                        pebble.add(x + 1 + (int) (Gfx.hash(h, 10 + k) * 9));
                        pebble.add(y + 1 + (int) (Gfx.hash(h, 20 + k) * 9));
                        pebble.add(k == 0 ? 3 : 2);
                    }
                } else if (!BLOCK[c][r]) {
                    for (int k = 0; k < 2; k++) {
                        if (Gfx.hash(h, 30 + k) > 0.55F) {
                            tuft.add(x + 1 + (int) (Gfx.hash(h, 40 + k) * 9));
                            tuft.add(y + 2 + (int) (Gfx.hash(h, 50 + k) * 8));
                        }
                    }
                    float f = Gfx.hash(h, 5);
                    if (f > 0.78F) {
                        flower.add(x + 2 + (int) (Gfx.hash(h, 6) * 8));
                        flower.add(y + 2 + (int) (Gfx.hash(h, 7) * 8));
                        flower.add(flowerCols[(int) (Gfx.hash(h, 8) * flowerCols.length) % flowerCols.length]);
                    }
                }
            }
        }
        TUFT = toArray(tuft);
        FLOWER = toArray(flower);
        PEBBLE = toArray(pebble);
    }

    private static int[] toArray(List<Integer> l) {
        int[] a = new int[l.size()];
        for (int i = 0; i < a.length; i++) a[i] = l.get(i);
        return a;
    }

    // ---------- guards (0 cat, 1 penguin, 2 fox, 3 panda) ----------
    private static final int[] COST = {15, 25, 35, 40};
    private static final int[] RANGE = {32, 30, 62, 38};
    private static final float[] DMG = {2F, 1F, 9F, 4F};
    private static final int[] CD = {32, 40, 85, 70};
    private static final int[] SHOT = {0xFFFFB347, 0xFFBFE9FF, 0xFFFF8A3C, 0xFF7ED36A};      // the colour of each guard's shot

    // ---------- pests (0 aphid, 1 beetle, 2 crow, 3 boss snail) ----------
    private static final float[] E_HP = {6F, 16F, 7F, 120F};
    private static final float[] E_SPEED = {0.40F, 0.32F, 0.75F, 0.22F};
    private static final int[] E_GOLD = {2, 4, 3, 25};
    private static final int[] E_COL = {0xFF8EE866, 0xFF8A6AD8, 0xFF3D3550, 0xFFE98AB4};   // for the bursts

    private static final int INK = 0xFF2A2433;

    private static final class Tower {
        final int col, row, type, phase;
        int level = 1, cd = 20, invested, fire, born, look;
        Tower(int col, int row, int type, int cost) { this.col = col; this.row = row; this.type = type; this.invested = cost; this.phase = (col * 5 + row * 3) & 15; }
    }

    private static final class Enemy {
        final int kind;
        float hp, maxHp, dist, x, y;
        int slow, fx = 1, fy, flash, trail;
        boolean dead;
        Enemy(int kind, float hp) { this.kind = kind; this.hp = hp; this.maxHp = hp; }
    }

    private static final class Proj {
        float x, y;
        final Enemy target;
        final int type;
        final float dmg;
        Proj(float x, float y, Enemy target, int type, float dmg) { this.x = x; this.y = y; this.target = target; this.type = type; this.dmg = dmg; }
    }

    private static final class Pop {
        final float x;
        float y;
        int t = 40;
        final String s;
        final int col;
        Pop(float x, float y, String s, int col) { this.x = x; this.y = y; this.s = s; this.col = col; }
    }

    /** A little visual effect: 0 dot, 1 ring, 2 sparkle, 3 slime, 4 puff. */
    private static final class Fx {
        float x, y, vx, vy, r;
        int t, max, col, kind;
    }

    private final List<Tower> towers = new ArrayList<>();
    private final List<Enemy> enemies = new ArrayList<>();
    private final List<Proj> projs = new ArrayList<>();
    private final List<Pop> pops = new ArrayList<>();
    private final List<Fx> fxs = new ArrayList<>();
    private final List<Integer> queue = new ArrayList<>();

    private int gold, lives, wave, qi, spawnT, interval, countdown, banner, bannerMax, flash, t, goldPulse;
    private boolean waveActive, fast, won;
    private int sel = 0;            // guard picked in the shop (-1 = none)
    private Tower selT;             // a placed guard that is selected

    @Override
    public void reset() {
        score = 0; over = false; won = false;
        towers.clear(); enemies.clear(); projs.clear(); pops.clear(); fxs.clear(); queue.clear();
        gold = 60; lives = 10; wave = 0; qi = 0; spawnT = 0; interval = 40;
        countdown = 1500; banner = 0; bannerMax = 60; flash = 0; t = 0; goldPulse = 0;
        waveActive = false; fast = false; sel = 0; selT = null;
    }

    // ---------- numbers ----------
    private static float dmgOf(Tower tw) { return DMG[tw.type] * (1F + 0.4F * (tw.level - 1)); }
    private static float rangeOf(Tower tw) { return RANGE[tw.type] + 4 * (tw.level - 1); }
    private static int cdOf(Tower tw) { return Math.max(8, Math.round(CD[tw.type] * (1F - 0.12F * (tw.level - 1)))); }
    private static int upgradeCost(Tower tw) { return Math.round(COST[tw.type] * (tw.level == 1 ? 0.8F : 1.2F)); }
    private static int sellValue(Tower tw) { return Math.round(tw.invested * 0.6F); }

    private Tower towerAt(int c, int r) {
        for (Tower tw : towers) if (tw.col == c && tw.row == r) return tw;
        return null;
    }

    private static boolean buildable(int c, int r) { return !PATH[c][r] && !BLOCK[c][r]; }

    // ---------- effects ----------
    private void fx(int kind, float x, float y, float vx, float vy, int life, int col, float r) {
        if (fxs.size() > 240) fxs.remove(0);
        Fx f = new Fx();
        f.kind = kind; f.x = x; f.y = y; f.vx = vx; f.vy = vy; f.t = life; f.max = life; f.col = col; f.r = r;
        fxs.add(f);
    }

    private void burst(float x, float y, int col, int n) {
        for (int i = 0; i < n; i++) {
            double a = rnd.nextFloat() * Math.PI * 2;
            float sp = 0.4F + rnd.nextFloat() * 0.8F;
            fx(0, x, y, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp - 0.3F, 16 + rnd.nextInt(10), col, 0);
        }
    }

    private void poof(float x, float y) {
        for (int i = 0; i < 5; i++) fx(4, x + (rnd.nextFloat() - 0.5F) * 8, y + 4, (rnd.nextFloat() - 0.5F) * 0.5F, -0.15F, 18, 0xFFFFFFFF, 4);
        for (int i = 0; i < 4; i++) fx(0, x, y + 3, (rnd.nextFloat() - 0.5F) * 1.4F, -0.4F - rnd.nextFloat() * 0.6F, 20, 0xFF7ED36A, 0);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (over) return true;
        if (button == 1) { sel = -1; selT = null; return true; }
        if (y >= BAR_Y) { barClick(x, y); return true; }
        if (y < OY) return true;
        int c = x / T, r = (y - OY) / T;
        if (c < 0 || c >= COLS || r < 0 || r >= ROWS) return true;
        Tower at = towerAt(c, r);
        if (at != null) { selT = at; sel = -1; beep(); return true; }
        if (sel >= 0 && buildable(c, r)) {
            if (gold >= COST[sel]) {
                gold -= COST[sel];
                towers.add(new Tower(c, r, sel, COST[sel]));
                poof(c * T + T / 2F, OY + r * T + T / 2F);
                pling(1.3F);
            } else beep();
            return true;
        }
        selT = null;
        return true;
    }

    private void barClick(int x, int y) {
        for (int i = 0; i < 4; i++) {
            if (in(x, y, 2 + i * 36, BAR_Y + 1, 34, 17)) { sel = i; selT = null; beep(); return; }
        }
        if (selT != null) {
            if (in(x, y, 146, BAR_Y + 1, 22, 17)) { upgrade(); return; }
            if (in(x, y, 169, BAR_Y + 1, 16, 17)) { sell(); return; }
        }
        if (in(x, y, 187, BAR_Y + 1, 31, 17)) goOrSpeed();
    }

    private void goOrSpeed() {
        if (!waveActive) {
            gold += Math.max(0, countdown / 60);      // calling the wave early pays one coin per second saved
            startWave();
        } else {
            fast = !fast;
            beep();
        }
    }

    private void upgrade() {
        if (selT == null || selT.level >= 3) return;
        int c = upgradeCost(selT);
        if (gold < c) { beep(); return; }
        gold -= c; selT.invested += c; selT.level++;
        float cx = selT.col * T + T / 2F, cy = OY + selT.row * T + T / 2F;
        fx(1, cx, cy, 0, 0, 20, 0xFFFFE27A, 11);
        for (int i = 0; i < 4; i++) fx(2, cx + (i - 1.5F) * 3, cy, 0, -0.35F - i * 0.05F, 26, 0xFFFFF2A0, 0);
        pling(1.5F);
    }

    private void sell() {
        if (selT == null) return;
        gold += sellValue(selT);
        float cx = selT.col * T + T / 2F, cy = OY + selT.row * T + T / 2F;
        poof(cx, cy);
        pops.add(new Pop(cx, cy - 6, "+" + sellValue(selT), 0xFFFFE27A));
        goldPulse = 14;
        towers.remove(selT);
        selT = null;
        beep();
    }

    @Override
    public boolean key(int keyCode) {
        if (over) return false;
        if (keyCode >= 49 && keyCode <= 52) { sel = keyCode - 49; selT = null; beep(); return true; }
        if (keyCode == 85) { upgrade(); return true; }          // U
        if (keyCode == 83) { sell(); return true; }             // S
        if (keyCode == KEY_SPACE) { goOrSpeed(); return true; }
        return false;
    }

    // ---------- simulation ----------
    @Override
    public void tick() {
        if (over) return;
        t++;
        int steps = fast ? 2 : 1;
        for (int s = 0; s < steps && !over; s++) step();
    }

    private void step() {
        if (banner > 0) banner--;
        if (flash > 0) flash--;
        if (goldPulse > 0) goldPulse--;

        if (!waveActive) {
            if (--countdown <= 0) startWave();
        } else if (qi < queue.size()) {
            if (--spawnT <= 0) {
                int k = queue.get(qi++);
                float mul = 1F + 0.20F * (wave - 1);
                Enemy e = new Enemy(k, E_HP[k] * mul);
                place(e);
                enemies.add(e);
                spawnT = interval;
            }
        } else if (enemies.isEmpty()) {
            endWave();
            if (over) return;
        }

        // pests walk
        for (Enemy e : enemies) {
            if (e.dead) continue;
            if (e.flash > 0) e.flash--;
            float sp = E_SPEED[e.kind] * (e.slow > 0 ? 0.5F : 1F);
            if (e.slow > 0) e.slow--;
            e.dist += sp;
            if (e.dist >= TOTAL) {
                e.dead = true;
                lives -= e.kind == 3 ? 3 : 1;
                flash = 18;
                burst(e.x, e.y, 0xFFFF6B8A, 6);
                pling(0.5F);
                if (lives <= 0) { lives = 0; over = true; }
            } else {
                place(e);
                if (e.kind == 3 && ++e.trail % 12 == 0) fx(3, e.x, e.y + 3, 0, 0, 70, 0xFFB8F090, 0);
            }
        }

        // guards shoot
        for (Tower tw : towers) {
            tw.born++;
            if (tw.fire > 0) tw.fire--;
            if (tw.cd > 0) { tw.cd--; continue; }
            float cx = tw.col * T + T / 2F, cy = OY + tw.row * T + T / 2F, rng = rangeOf(tw);
            Enemy best = null;
            float bv = -1;
            for (Enemy e : enemies) {
                if (e.dead) continue;
                float dx = e.x - cx, dy = e.y - cy;
                if (dx * dx + dy * dy > rng * rng) continue;
                float v = tw.type == 2 ? e.hp : e.dist;          // the fox goes for the toughest pest, the others for the first
                if (v > bv) { bv = v; best = e; }
            }
            if (best != null) {
                projs.add(new Proj(cx, cy - 2, best, tw.type, dmgOf(tw)));
                tw.cd = cdOf(tw);
                tw.fire = 8;
                tw.look = best.x < cx ? -1 : 1;
            }
        }

        // shots fly
        Iterator<Proj> pit = projs.iterator();
        while (pit.hasNext()) {
            Proj p = pit.next();
            if (p.target.dead) { pit.remove(); continue; }
            float dx = p.target.x - p.x, dy = p.target.y - p.y;
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d <= 3.5F) { hit(p); pit.remove(); continue; }
            p.x += dx / d * 3.2F;
            p.y += dy / d * 3.2F;
            if ((t & 1) == 0) fx(0, p.x, p.y, 0, 0, 9, SHOT[p.type], 0);
        }

        // the fallen
        Iterator<Enemy> eit = enemies.iterator();
        while (eit.hasNext()) {
            Enemy e = eit.next();
            if (e.dead) { eit.remove(); continue; }
            if (e.hp <= 0) {
                e.dead = true;
                int g = E_GOLD[e.kind] + wave / 6;
                gold += g;
                goldPulse = 14;
                score += e.kind == 3 ? 10 : 1;
                pops.add(new Pop(e.x, e.y - 4, "+" + g, 0xFFFFE27A));
                burst(e.x, e.y, E_COL[e.kind], e.kind == 3 ? 14 : 7);
                fx(2, e.x, e.y, 0, -0.2F, 18, 0xFFFFFFFF, 0);
                if (e.kind == 3) fx(1, e.x, e.y, 0, 0, 24, 0xFFFFC0DA, 14);
                eit.remove();
            }
        }

        Iterator<Pop> qit = pops.iterator();
        while (qit.hasNext()) {
            Pop p = qit.next();
            p.y -= 0.3F;
            if (--p.t <= 0) qit.remove();
        }
        Iterator<Fx> fit = fxs.iterator();
        while (fit.hasNext()) {
            Fx f = fit.next();
            f.x += f.vx;
            f.y += f.vy;
            if (f.kind == 0) f.vy += 0.04F;
            if (--f.t <= 0) fit.remove();
        }
    }

    private void hit(Proj p) {
        Enemy e = p.target;
        hurt(e, p.dmg);
        burst(p.x, p.y, SHOT[p.type], 3);
        if (p.type == 1 && e.kind != 2) e.slow = 100;            // snowballs slow everything but the crows
        if (p.type == 3) {                                       // the bamboo bomb splashes
            fx(1, e.x, e.y, 0, 0, 14, 0xFF9BE07A, 16);
            for (Enemy o : enemies) {
                if (o == e || o.dead) continue;
                float dx = o.x - e.x, dy = o.y - e.y;
                if (dx * dx + dy * dy <= 16 * 16) hurt(o, p.dmg * 0.7F);
            }
        }
    }

    private static void hurt(Enemy e, float dmg) {
        e.hp -= e.kind == 1 ? Math.max(1F, dmg - 1F) : dmg;      // beetle shells take one point off every hit
        e.flash = 3;
    }

    private static void place(Enemy e) {
        float d = Math.min(e.dist, TOTAL);
        int i = 0;
        while (i < CUM.length - 2 && d > CUM[i + 1]) i++;
        float seg = CUM[i + 1] - CUM[i];
        float k = seg <= 0 ? 0 : (d - CUM[i]) / seg;
        e.x = WX[i] + (WX[i + 1] - WX[i]) * k;
        e.y = WY[i] + (WY[i + 1] - WY[i]) * k;
        e.fx = (int) Math.signum(WX[i + 1] - WX[i]);
        e.fy = (int) Math.signum(WY[i + 1] - WY[i]);
    }

    private void startWave() {
        wave++;
        queue.clear();
        int n = Math.min(36, 6 + wave * 2);
        for (int i = 0; i < n; i++) {
            float r = rnd.nextFloat();
            int k = 0;
            if (wave >= 4 && r < 0.25F) k = 2;
            else if (wave >= 3 && r < 0.55F) k = 1;
            queue.add(k);
        }
        if (wave % 5 == 0) for (int b = 0; b < 1 + wave / 10; b++) queue.add(3);
        qi = 0;
        spawnT = 20;
        interval = Math.max(16, 46 - wave * 2);
        waveActive = true;
        bannerMax = wave % 5 == 0 ? 120 : 60;
        banner = bannerMax;
    }

    private void endWave() {
        waveActive = false;
        gold += 8 + wave * 2;
        goldPulse = 14;
        score += 10;
        pling(1.6F);
        if (wave >= MAX_WAVE) {
            won = true;
            score += 100;
            over = true;
        } else countdown = 720;
    }

    // ================= drawing =================
    private static void px(GuiGraphics g, int x, int y, int col) { g.fill(x, y, x + 1, y + 1, col); }

    private static void coin(GuiGraphics g, int cx, int cy) {
        Gfx.disc(g, cx, cy, 3, 0xFFB8860B);
        Gfx.disc(g, cx, cy, 2, 0xFFFFD84A);
        px(g, cx - 1, cy - 1, 0xFFFFF6B0);
        px(g, cx + 1, cy + 1, 0xFFE0A81A);
    }

    @Override
    public void render(GuiGraphics g) {
        // ----- meadow -----
        g.fillGradient(0, 0, W, H, 0xFFB4E58F, 0xFF6DBE5E);
        for (int c = 0; c < COLS; c++) {
            for (int r = 0; r < ROWS; r++) {
                if (((c + r) & 1) == 0 && !PATH[c][r]) rect(g, c * T, OY + r * T, T, T, 0x16FFFFFF);
            }
        }
        for (int i = 0; i + 1 < TUFT.length; i += 2) {
            int x = TUFT[i], y = TUFT[i + 1];
            px(g, x, y, 0xFF58A84A); px(g, x + 2, y, 0xFF58A84A); px(g, x + 1, y + 1, 0xFF4A9A40);
            px(g, x + 1, y, 0xFF8ED47A);
        }
        for (int i = 0; i + 2 < FLOWER.length; i += 3) {
            int x = FLOWER[i], y = FLOWER[i + 1], col = FLOWER[i + 2];
            int sw = ((t / 40 + i) & 3) == 0 ? 1 : 0;                  // now and then a flower nods
            px(g, x, y + 1, 0xFF4A9A40);
            px(g, x + sw, y, col); px(g, x - 1 + sw, y - 1, Gfx.fade(col, 0.75F)); px(g, x + 1 + sw, y - 1, Gfx.fade(col, 0.75F));
            px(g, x + sw, y - 2, Gfx.fade(col, 0.75F));
            px(g, x + sw, y - 1, 0xFFFFD84A);
        }
        // ----- the path: sand, pebbles and soft edges -----
        for (int c = 0; c < COLS; c++) {
            for (int r = 0; r < ROWS; r++) {
                if (!PATH[c][r]) continue;
                int x = c * T, y = OY + r * T;
                rect(g, x, y, T, T, 0xFFEBD3A0);
                rect(g, x, y, T, 1, 0x20FFFFFF);
                if (c == 0 || !PATH[c - 1][r]) rect(g, x, y, 1, T, 0xFFC9A066);
                if (c == COLS - 1 || !PATH[c + 1][r]) rect(g, x + T - 1, y, 1, T, 0xFFC9A066);
                if (r == 0 || !PATH[c][r - 1]) rect(g, x, y, T, 1, 0xFFC9A066);
                if (r == ROWS - 1 || !PATH[c][r + 1]) rect(g, x, y + T - 1, T, 1, 0xFFC9A066);
                if (c > 0 && !PATH[c - 1][r]) rect(g, x - 1, y, 1, T, 0x30406830);    // grass edge shade
                if (r > 0 && !PATH[c][r - 1]) rect(g, x, y - 1, T, 1, 0x30406830);
            }
        }
        for (int i = 0; i + 2 < PEBBLE.length; i += 3) {
            int x = PEBBLE[i], y = PEBBLE[i + 1], w = PEBBLE[i + 2];
            rect(g, x, y, w, 1, 0xFFD5B67E); rect(g, x, y + 1, w, 1, 0xFFBC9660);
        }
        // the burrow where the pests come from
        Gfx.ellipse(g, 6, OY + T + 7, 6, 3, 0xFF9A6A3C);
        Gfx.ellipse(g, 6, OY + T + 7, 5, 2, 0xFF2A1A0C);
        rect(g, 1, OY + T + 5, 3, 1, 0xFFB88450);
        // a picket fence along the top
        for (int x = 1; x < W; x += 5) {
            rect(g, x, OY, 3, 4, 0xFFFFF6E8); px(g, x + 1, OY - 1 + 0, 0xFFFFF6E8);
            rect(g, x, OY + 3, 3, 1, 0xFFE3CDB0);
        }
        rect(g, 0, OY + 1, W, 1, 0xFFE9D6BC);

        // ----- scenery that blocks tiles -----
        for (int[] d : DECOR) decor(g, d[0], d[1], d[2]);

        // soft shadow of a drifting cloud
        int cxs = (int) ((t * 0.12F) % (W + 120)) - 60;
        Gfx.ellipse(g, cxs, 70, 38, 16, 0x0C102810);

        // ----- build hints, range rings -----
        Tower hover = null;
        int hc = mx / T, hr = (my - OY) / T;
        boolean inGrid = mx >= 0 && my >= OY && my < BAR_Y && hc < COLS && hr < ROWS;
        if (inGrid) hover = towerAt(hc, hr);
        if (sel >= 0) {
            int a = 0x10 + (int) (Math.sin(t * 0.1) * 5 + 5);
            for (int c = 0; c < COLS; c++) {
                for (int r = 0; r < ROWS; r++) {
                    if (buildable(c, r) && towerAt(c, r) == null) {
                        int x = c * T, y = OY + r * T;
                        rect(g, x + 1, y + 1, T - 2, T - 2, Gfx.alpha(0xFFFFFFFF, a));
                    }
                }
            }
        }
        Tower ringOf = selT != null ? selT : hover;
        if (ringOf != null) ring(g, ringOf.col, ringOf.row, rangeOf(ringOf), true);

        // ----- guards -----
        for (Tower tw : towers) {
            int cx = tw.col * T + T / 2, cy = OY + tw.row * T + T / 2;
            if (tw == selT) {
                int al = 150 + (int) (Math.sin(t * 0.15) * 80);
                Gfx.rrect(g, tw.col * T, OY + tw.row * T, T, T, 3, Gfx.alpha(0xFFFFFFFF, 40));
                Gfx.outline(g, tw.col * T, OY + tw.row * T, T, T, Gfx.alpha(0xFFFFFFFF, al));
            }
            int lift = tw.born < 14 ? -(int) Math.round(Math.sin(tw.born / 14.0 * Math.PI) * 4) : 0;
            drawTower(g, tw.type, cx, cy + lift, tw.level, tw.look, tw.fire > 0, tw.phase, tw.born < 14 ? 0 : 1);
        }
        if (inGrid && sel >= 0 && towerAt(hc, hr) == null) {      // ghost of the guard to place
            int cx = hc * T + T / 2, cy = OY + hr * T + T / 2;
            boolean ok = buildable(hc, hr);
            if (ok) {
                ring(g, hc, hr, RANGE[sel], false);
                drawTower(g, sel, cx, cy, 1, 0, false, 0, 1);
            }
            boolean can = ok && gold >= COST[sel];
            int bc = can ? 0xFF7CFF8A : 0xFFFF6B6B;
            Gfx.rrect(g, hc * T, OY + hr * T, T, T, 3, Gfx.alpha(bc, 50));
            Gfx.outline(g, hc * T, OY + hr * T, T, T, Gfx.alpha(bc, 200));
        }

        // ----- pests (the flying crows are drawn last) -----
        for (Enemy e : enemies) if (e.kind != 2) drawEnemy(g, e);
        for (Enemy e : enemies) if (e.kind == 2) drawEnemy(g, e);

        // ----- shots and effects -----
        for (Proj p : projs) drawShot(g, p);
        for (Fx f : fxs) drawFx(g, f);
        for (Pop p : pops) {
            int a = p.t > 12 ? 255 : p.t * 20;
            int w = tw(p.s);
            int x = Math.round(p.x) - (w + 6) / 2;
            ctext(g, p.s, x + 6 + w / 2, Math.round(p.y), Gfx.alpha(p.col, a));
            if (a > 120) coin(g, x + 1, Math.round(p.y) + 4);
        }

        // ----- ambient life -----
        for (int i = 0; i < 2; i++) butterfly(g, i);
        for (int i = 0; i < 7; i++) {
            float k = Gfx.hash(i, 90);
            int x = (int) ((k * W + t * (0.12F + k * 0.1F)) % W);
            int y = OY + 6 + (int) ((Gfx.hash(i, 91) * 100 + Math.sin(t * 0.03 + i) * 6 + 100) % 100);
            px(g, x, y, Gfx.alpha(i % 2 == 0 ? 0xFFFFD6E8 : 0xFFFFFFFF, 170));
        }
        Gfx.glow(g, W - 14, OY + 4, 44, 0xFFFFF4C0, 70);
        Gfx.vignette(g, W, H, 46);

        hud(g);
        shopBar(g);

        if (flash > 0) {
            rect(g, 0, 0, W, 3, Gfx.alpha(0xFFFF2040, flash * 7)); rect(g, 0, H - 3, W, 3, Gfx.alpha(0xFFFF2040, flash * 7));
            rect(g, 0, 0, 3, H, Gfx.alpha(0xFFFF2040, flash * 7)); rect(g, W - 3, 0, 3, H, Gfx.alpha(0xFFFF2040, flash * 7));
            rect(g, 0, 0, W, H, Gfx.alpha(0xFFFF2040, flash * 3));
        }
        if (banner > 0 && wave > 0) {
            boolean boss = wave % 5 == 0;
            String s = boss ? Component.translatable("cutemod.garden.boss").getString()
                            : Component.translatable("cutemod.garden.wave", wave, MAX_WAVE).getString();
            int age = bannerMax - banner;
            float k = Math.min(1F, Math.min(age, banner) / 8F);
            k = 1F - (1F - k) * (1F - k);
            int y = Math.round(-20 + 70 * k);
            int base = boss ? 0xFFC0386A : 0xFF3F9A5E;
            rect(g, W / 2 - 62, y + 3, 10, 11, Gfx.darker(base, 0.35F));
            rect(g, W / 2 + 52, y + 3, 10, 11, Gfx.darker(base, 0.35F));
            Gfx.bubble(g, W / 2 - 56, y, 112, 16, 4, base);
            ctextW(g, s, W / 2, y + 4, 100, 0xFFFFFFFF);
            if (boss) { Gfx.star(g, W / 2 - 50, y + 8, 2, 0xFFFFE27A); Gfx.star(g, W / 2 + 50, y + 8, 2, 0xFFFFE27A); }
        }
    }

    private void ring(GuiGraphics g, int col, int row, float r, boolean fill) {
        int cx = col * T + T / 2, cy = OY + row * T + T / 2;
        if (fill) {
            for (int dy = -(int) r; dy <= (int) r; dy += 1) {
                int y = cy + dy;
                if (y < OY || y >= BAR_Y) continue;
                int dx = (int) Math.floor(Math.sqrt(Math.max(0, r * r - dy * dy)));
                int x0 = Math.max(0, cx - dx), x1 = Math.min(W, cx + dx + 1);
                if (x1 > x0) rect(g, x0, y, x1 - x0, 1, 0x1CFFFFFF);
            }
        }
        int n = Math.max(28, (int) (r * 1.6F));
        for (int i = 0; i < n; i++) {
            if (((i + t / 6) & 1) == 0) continue;                  // a dashed ring that slowly turns
            double a = i * Math.PI * 2 / n;
            int x = cx + (int) Math.round(Math.cos(a) * r), y = cy + (int) Math.round(Math.sin(a) * r);
            if (y >= OY && y < BAR_Y && x >= 0 && x < W) { px(g, x, y + 1, 0x38103010); px(g, x, y, 0xF0FFFFFF); }
        }
    }

    private void butterfly(GuiGraphics g, int i) {
        double a = t * 0.012 + i * 2.7;
        int x = (int) (W / 2 + Math.sin(a * 0.7 + i) * 85 + Math.sin(a * 2.3) * 8);
        int y = (int) (OY + 50 + Math.sin(a * 0.9) * 34 + Math.sin(a * 3.1) * 4);
        int wing = ((t / 5 + i) & 1) == 0 ? 2 : 1;
        int col = i == 0 ? 0xFFFFB6D9 : 0xFFB6D9FF;
        rect(g, x - wing - 1, y - 1, wing + 1, 2, col);
        rect(g, x + 1, y - 1, wing + 1, 2, col);
        px(g, x, y, 0xFF4A3A5A); px(g, x, y + 1, 0xFF4A3A5A);
    }

    private void decor(GuiGraphics g, int c, int r, int kind) {
        int cx = c * T + T / 2, cy = OY + r * T + T / 2;
        switch (kind) {
            case 0 -> {   // tree
                Gfx.ellipse(g, cx, cy + 5, 5, 2, 0x28000000);
                rect(g, cx - 1, cy + 1, 3, 5, 0xFF7A4E28);
                rect(g, cx, cy + 1, 1, 5, 0xFFA8733F);
                int sw = ((t / 50 + c) & 3) == 0 ? 1 : 0;
                Gfx.disc(g, cx + sw, cy - 2, 5, 0xFF3A8A3A);
                Gfx.disc(g, cx + sw, cy - 2, 4, 0xFF5CB84E);
                Gfx.disc(g, cx + sw - 1, cy - 3, 2, 0xFF86DC72);
                px(g, cx + sw + 2, cy - 1, 0xFFE0485A); px(g, cx + sw - 2, cy, 0xFFE0485A);
            }
            case 1 -> {   // bush with berries
                Gfx.ellipse(g, cx, cy + 5, 5, 2, 0x28000000);
                Gfx.ellipse(g, cx, cy + 2, 5, 4, 0xFF3A8A3A);
                Gfx.ellipse(g, cx, cy + 2, 4, 3, 0xFF58B04A);
                Gfx.disc(g, cx - 2, cy + 1, 1, 0xFF86DC72);
                px(g, cx + 1, cy + 1, 0xFFFF6B8A); px(g, cx - 1, cy + 3, 0xFFFF6B8A); px(g, cx + 3, cy + 3, 0xFFFF6B8A);
            }
            case 2 -> {   // rock
                Gfx.ellipse(g, cx, cy + 5, 5, 2, 0x28000000);
                Gfx.ellipse(g, cx, cy + 2, 5, 4, 0xFF7C8088);
                Gfx.ellipse(g, cx, cy + 2, 4, 3, 0xFFA9AEB8);
                rect(g, cx - 2, cy, 3, 1, 0xFFD6DAE2);
                px(g, cx + 3, cy + 5, 0xFF58A84A); px(g, cx + 4, cy + 4, 0xFF58A84A);
            }
            default -> {  // cabbage: it wilts as the lives run out
                float sick = 1F - lives / 10F;
                int dark = Gfx.mix(0xFF3A8A3A, 0xFF8A7A30, sick), mid = Gfx.mix(0xFF5CB84E, 0xFFB5A040, sick), light = Gfx.mix(0xFF9BE07A, 0xFFD8C86A, sick);
                int shake = flash > 0 ? ((t & 1) == 0 ? 1 : -1) : 0;
                int bob = ((t / 30 + c) & 1) == 0 ? 0 : 1;
                Gfx.ellipse(g, cx, cy + 5, 5, 2, 0x28000000);
                rect(g, cx - 5, cy + 3, 10, 3, 0xFF8A5A30);
                Gfx.disc(g, cx + shake, cy + 1 - bob / 2, 5, dark);
                Gfx.disc(g, cx + shake, cy + 1 - bob / 2, 4, mid);
                Gfx.disc(g, cx + shake, cy + 1 - bob / 2, 2, light);
                rect(g, cx - 1 + shake, cy - 3, 1, 3, light); rect(g, cx - 3 + shake, cy + 1, 2, 1, light); rect(g, cx + 2 + shake, cy + 1, 2, 1, light);
            }
        }
    }

    private void drawFx(GuiGraphics g, Fx f) {
        float k = f.t / (float) f.max;
        int a = Math.min(255, Math.round(255 * Math.min(1F, k * 1.6F)));
        int x = Math.round(f.x), y = Math.round(f.y);
        switch (f.kind) {
            case 0 -> { int s = k > 0.5F ? 2 : 1; rect(g, x, y, s, s, Gfx.alpha(f.col, a)); }
            case 1 -> {
                float r = f.r * (1F - k) + 2;
                int n = Math.max(12, (int) (r * 2.4F));
                for (int i = 0; i < n; i++) {
                    double an = i * Math.PI * 2 / n;
                    px(g, x + (int) Math.round(Math.cos(an) * r), y + (int) Math.round(Math.sin(an) * r), Gfx.alpha(f.col, a));
                }
            }
            case 2 -> Gfx.star(g, x, y, k > 0.5F ? 2 : 1, Gfx.alpha(f.col, a));
            case 3 -> Gfx.ellipse(g, x, y, 2, 1, Gfx.alpha(f.col, a / 3));
            default -> Gfx.disc(g, x, y, Math.max(1, Math.round(1 + (1F - k) * f.r)), Gfx.alpha(f.col, a / 3));
        }
    }

    private void drawShot(GuiGraphics g, Proj p) {
        int x = Math.round(p.x), y = Math.round(p.y);
        switch (p.type) {
            case 0 -> {   // a little fish
                rect(g, x - 1, y, 3, 2, 0xFFFFB347); px(g, x - 2, y - 1, 0xFFFFB347); px(g, x - 2, y + 1, 0xFFFFB347);
                px(g, x + 1, y, INK);
            }
            case 1 -> { Gfx.disc(g, x, y, 2, 0xFF8FD0F0); Gfx.disc(g, x, y, 1, 0xFFFFFFFF); }
            case 2 -> { Gfx.glow(g, x, y, 4, 0xFFFFA040, 120); Gfx.disc(g, x, y, 1, 0xFFFFE08A); }
            default -> {
                Gfx.disc(g, x, y, 2, 0xFF3F8F3A); px(g, x - 1, y - 1, 0xFF9BE07A);
                if ((t & 2) == 0) px(g, x + 1, y - 3, 0xFFFFE27A); else px(g, x + 2, y - 3, 0xFFFF8A3C);   // the sparking fuse
            }
        }
    }

    private void hpBar(GuiGraphics g, int x, int y, int w, float ratio) {
        rect(g, x - 1, y - 1, w + 2, 4, 0xB0201A28);
        int fw = Math.max(1, Math.round(w * ratio));
        int col = ratio > 0.5F ? Gfx.mix(0xFFE8D84A, 0xFF6CD64A, (ratio - 0.5F) * 2F) : Gfx.mix(0xFFE0402F, 0xFFE8D84A, ratio * 2F);
        rect(g, x, y, fw, 2, col);
        rect(g, x, y, fw, 1, 0x50FFFFFF);
    }

    // ---------- HUD and shop ----------
    private void hud(GuiGraphics g) {
        g.fillGradient(0, 0, W, OY, 0xCC1E3A24, 0xB0284A30);
        rect(g, 0, OY - 1, W, 1, 0x40FFFFFF);
        // gold
        Gfx.rrect(g, 2, 1, 42, 10, 4, 0x55000000);
        coin(g, 7, 6);
        int gc = goldPulse > 0 ? Gfx.mix(0xFFFFF0B0, 0xFFFFFFFF, goldPulse / 14F) : 0xFFFFE9A0;
        text(g, String.valueOf(gold), 13, 2, gc);
        // lives
        Gfx.rrect(g, 47, 1, 30, 10, 4, 0x55000000);
        Gfx.heart(g, 50, 3, lives <= 3 && (t / 10 & 1) == 0 ? 0xFFFFFFFF : 0xFFFF6B8A);
        text(g, String.valueOf(lives), 60, 2, 0xFFFFFFFF);
        // wave
        Gfx.rrect(g, W / 2 - 32, 1, 64, 10, 4, 0x55000000);
        ctext(g, Component.translatable("cutemod.garden.wave", Math.max(1, wave), MAX_WAVE).getString(), W / 2, 2, 0xFFFFFFFF);
        int pw = (64 - 8) * Math.min(wave, MAX_WAVE) / MAX_WAVE;
        if (pw > 0) rect(g, W / 2 - 28, 10, pw, 1, 0xFF8EE866);
        // what is coming
        String right = waveActive
                ? String.valueOf(enemies.size() + Math.max(0, queue.size() - qi))
                : Component.translatable("cutemod.garden.next", Math.max(0, countdown / 60)).getString();
        int rw = tw(right) + 12;
        Gfx.rrect(g, W - rw - 3, 1, rw, 10, 4, 0x55000000);
        if (waveActive) { Gfx.disc(g, W - rw + 3, 6, 2, 0xFF8EE866); px(g, W - rw + 3, 5, 0xFF2A2433); }
        else px(g, W - rw + 3, 6, 0xFFB0FFC0);
        text(g, right, W - rw + 8, 2, waveActive ? 0xFFFFC8C8 : 0xFFC8FFD4);
    }

    private void shopBar(GuiGraphics g) {
        g.fillGradient(0, BAR_Y, W, H, 0xFF7A5638, 0xFF4E3624);
        rect(g, 0, BAR_Y, W, 1, 0xFFB38A5E);
        rect(g, 0, BAR_Y + 1, W, 1, 0x30FFFFFF);
        // tooltip: the name of the picked guard
        int tip = selT != null ? selT.type : sel;
        if (tip >= 0) {
            String s = Component.translatable("cutemod.garden.t" + tip).getString();
            int tipW = Math.min(W - 60, tw(s) + 12);
            Gfx.rrect(g, 4, BAR_Y - 11, tipW, 10, 4, 0xB8201A28);
            ctextW(g, s, 4 + tipW / 2, BAR_Y - 10, tipW - 6, 0xFFFFFFFF);
        }
        for (int i = 0; i < 4; i++) {
            int x = 2 + i * 36, y = BAR_Y + 2;
            boolean can = gold >= COST[i];
            int face = sel == i ? 0xFF7FA85A : 0xFF6A4E36;
            Gfx.bubble(g, x, y, 34, 17, 4, face);
            if (sel == i) Gfx.outline(g, x - 1, y - 1, 36, 19, Gfx.alpha(0xFFFFFFFF, 150 + (int) (Math.sin(t * 0.15) * 70)));
            Gfx.rrect(g, x + 2, y + 2, 14, 13, 4, 0x40FFF2D0);
            drawTower(g, i, x + 9, y + 8, 1, 0, false, 0, 1);
            coin(g, x + 21, y + 11);
            text(g, String.valueOf(COST[i]), x + 26 - (COST[i] > 99 ? 2 : 0), y + 7, can ? 0xFFFFE9A0 : 0xFFFF9A8A);
            rect(g, x + 2, y + 2, 5, 5, 0x90201A28);                       // the hot key
            text(g, String.valueOf(i + 1), x + 3, y + 1, 0xFFFFFFFF);
            if (!can) rect(g, x + 1, y + 1, 32, 15, 0x38000000);
        }
        if (selT != null) {
            boolean max = selT.level >= 3;
            int uc = max ? 0 : upgradeCost(selT);
            Gfx.bubble(g, 146, BAR_Y + 2, 22, 17, 4, max ? 0xFF6A6A72 : gold >= uc ? 0xFF4E9A5A : 0xFF8A5A5A);
            if (max) ctext(g, "MAX", 157, BAR_Y + 7, 0xFFFFFFFF);
            else {
                for (int i = 0; i < 3; i++) rect(g, 150 + 1 - i + 2, BAR_Y + 7 + i, 1 + i * 2, 1, 0xFFFFFFFF);   // a little arrow
                text(g, String.valueOf(uc), 158, BAR_Y + 7, 0xFFFFFFFF);
            }
            Gfx.bubble(g, 169, BAR_Y + 2, 16, 17, 4, 0xFFB07040);
            ctext(g, "$" + sellValue(selT), 177, BAR_Y + 7, 0xFFFFFFFF);
        }
        int gc = waveActive ? (fast ? 0xFF4F9BE8 : 0xFF6A7A9A) : 0xFFE8803A;
        Gfx.bubble(g, 187, BAR_Y + 2, 31, 17, 5, gc);
        // play triangle (start) or one / two chevrons (speed)
        if (!waveActive) {
            for (int i = 0; i < 5; i++) rect(g, 199 + i, BAR_Y + 7 + i, 1, 9 - i * 2 > 0 ? 9 - i * 2 : 1, 0xFFFFFFFF);
        } else {
            int n = fast ? 2 : 1;
            for (int k = 0; k < n; k++) {
                int bx = (n == 1 ? 199 : 195) + k * 7;
                for (int i = 0; i < 4; i++) rect(g, bx + i, BAR_Y + 7 + i, 1, 9 - i * 2 > 0 ? 9 - i * 2 : 1, 0xFFFFFFFF);
            }
        }
    }

    // ---------- the guards ----------
    private void drawTower(GuiGraphics g, int type, int cx, int cy, int level, int look, boolean firing, int ph, int shadow) {
        if (shadow > 0) Gfx.ellipse(g, cx, cy + 5, 6, 2, 0x30000000);
        Gfx.ellipse(g, cx, cy + 5, 5, 2, 0xFFD6D0C2);                     // a little stone plate
        Gfx.ellipse(g, cx, cy + 5, 4, 1, 0xFFEFEAE0);
        if (level >= 3) Gfx.glow(g, cx, cy, 8, 0xFFFFE27A, 60 + (int) (Math.sin(t * 0.12) * 20));
        int b = firing ? 1 : (((t / 22) + ph) & 1) == 0 ? 0 : -1;        // breathing, and a little hop when shooting
        boolean blink = (t + ph * 13) % 170 < 5;
        switch (type) {
            case 0 -> cat(g, cx, cy, b, look, firing, blink);
            case 1 -> penguin(g, cx, cy, b, look, firing, blink);
            case 2 -> fox(g, cx, cy, b, look, firing, blink);
            default -> panda(g, cx, cy, b, look, firing, blink);
        }
        if (level >= 2) Gfx.star(g, cx + 5, cy - 5, 1, 0xFFFFE27A);
        if (level >= 3) Gfx.star(g, cx - 5, cy - 5, 1, 0xFFFFE27A);
    }

    private static void eyes(GuiGraphics g, int x1, int x2, int y, int look, boolean blink) {
        if (blink) { rect(g, x1 + look, y + 1, 1, 1, INK); rect(g, x2 + look, y + 1, 1, 1, INK); }
        else {
            rect(g, x1 + look, y, 1, 2, INK); rect(g, x2 + look, y, 1, 2, INK);
            px(g, x1 + look, y, 0xFF6A5A80); px(g, x2 + look, y, 0xFF6A5A80);
        }
    }

    private void cat(GuiGraphics g, int cx, int cy, int b, int look, boolean fire, boolean blink) {
        int d = 0xFF9C5A26, f = 0xFFF4A84E, l = 0xFFFFE3B8, pk = 0xFFFF9DB5;
        int tx = look < 0 ? cx + 4 : cx - 5, wag = ((t / 8) & 1) == 0 ? 0 : (look < 0 ? 1 : -1);
        rect(g, tx, cy + 2, 2, 3, d); px(g, tx + (look < 0 ? 0 : 1), cy + 2, f); px(g, tx + wag, cy + 1, f);
        Gfx.ellipse(g, cx, cy + 3, 4, 3, d);
        Gfx.ellipse(g, cx, cy + 3, 3, 2, f);
        px(g, cx, cy + 4, l); px(g, cx - 2, cy + 5, l); px(g, cx + 2, cy + 5, l);
        px(g, cx - 3, cy - 6 + b, d); rect(g, cx - 4, cy - 5 + b, 3, 1, d);                      // ears
        px(g, cx + 3, cy - 6 + b, d); rect(g, cx + 2, cy - 5 + b, 3, 1, d);
        Gfx.disc(g, cx, cy - 1 + b, 4, d);
        Gfx.disc(g, cx, cy - 1 + b, 3, f);
        px(g, cx - 3, cy - 5 + b, pk); px(g, cx + 3, cy - 5 + b, pk);
        px(g, cx - 1, cy - 4 + b, d); px(g, cx + 1, cy - 4 + b, d); px(g, cx, cy - 3 + b, d);    // tabby stripes
        eyes(g, cx - 2, cx + 1, cy - 2 + b, look, blink);
        px(g, cx - 3, cy + b, Gfx.alpha(pk, 190)); px(g, cx + 2, cy + b, Gfx.alpha(pk, 190));
        px(g, cx, cy + b, pk);
        if (fire) rect(g, cx - 1, cy + 1 + b, 2, 1, 0xFFE05A6A); else { px(g, cx - 1, cy + 1 + b, d); px(g, cx + 1, cy + 1 + b, d); }
        rect(g, cx - 2, cy + 2 + b, 5, 1, 0xFFE0485A); px(g, cx, cy + 3 + b, 0xFFFFD84A);       // ribbon and bell
    }

    private void penguin(GuiGraphics g, int cx, int cy, int b, int look, boolean fire, boolean blink) {
        int navy = 0xFF34496E, deep = 0xFF263552;
        Gfx.ellipse(g, cx, cy + 2, 4, 4, deep);
        Gfx.ellipse(g, cx, cy + 2, 3, 4, navy);
        Gfx.ellipse(g, cx, cy + 3, 2, 3, 0xFFFFFFFF);
        rect(g, cx - 5, cy + (fire ? -1 : 1), 2, 3, navy); rect(g, cx + 4, cy + (fire ? -1 : 1), 2, 3, navy);   // flippers
        rect(g, cx - 3, cy + 5, 2, 1, 0xFFFFA030); rect(g, cx + 1, cy + 5, 2, 1, 0xFFFFA030);                    // feet
        Gfx.disc(g, cx, cy - 3 + b, 4, deep);
        Gfx.disc(g, cx, cy - 3 + b, 3, navy);
        rect(g, cx - 2, cy - 4 + b, 2, 2, 0xFFFFFFFF); rect(g, cx + 1, cy - 4 + b, 2, 2, 0xFFFFFFFF);            // eye patches
        if (blink) { px(g, cx - 2 + look, cy - 3 + b, INK); px(g, cx + 1 + look, cy - 3 + b, INK); }
        else { px(g, cx - 2 + look, cy - 3 + b, INK); px(g, cx + 1 + look, cy - 3 + b, INK); px(g, cx - 2 + look, cy - 4 + b, 0xFF8A7AA8); px(g, cx + 1 + look, cy - 4 + b, 0xFF8A7AA8); }
        rect(g, cx - 1, cy - 2 + b, 2, 1, 0xFFFFA030); if (fire) px(g, cx, cy - 1 + b, 0xFFE07A10);
        rect(g, cx - 3, cy - 0 + b, 6, 1, 0xFFE0485A); rect(g, cx + 2, cy + 1 + b, 1, 2, 0xFFE0485A);             // scarf
        px(g, cx - 3, cy - 6 + b, 0xFFFFFFFF); px(g, cx - 2, cy - 7 + b, 0xFFFFFFFF);                           // a bit of snow
    }

    private void fox(GuiGraphics g, int cx, int cy, int b, int look, boolean fire, boolean blink) {
        int o = 0xFFE8742C, d = 0xFFA84A14, w = 0xFFFFF4E4;
        int tx = look < 0 ? cx + 3 : cx - 7, sway = ((t / 10) & 1);
        Gfx.ellipse(g, tx + 2, cy + 2 - sway, 3, 3, d);
        Gfx.ellipse(g, tx + 2, cy + 2 - sway, 2, 2, o);
        px(g, tx + (look < 0 ? 4 : 0), cy + 3 - sway, w); px(g, tx + (look < 0 ? 4 : 0), cy + 2 - sway, w);   // white tip
        Gfx.ellipse(g, cx, cy + 3, 4, 3, d);
        Gfx.ellipse(g, cx, cy + 3, 3, 2, o);
        rect(g, cx - 1, cy + 4, 3, 1, w);
        px(g, cx - 2, cy + 5, INK); px(g, cx + 2, cy + 5, INK);                                                  // socks
        rect(g, cx - 4, cy - 7 + b, 1, 3, d); px(g, cx - 3, cy - 6 + b, o); rect(g, cx - 3, cy - 5 + b, 2, 2, d);   // tall ears
        rect(g, cx + 4, cy - 7 + b, 1, 3, d); px(g, cx + 3, cy - 6 + b, o); rect(g, cx + 2, cy - 5 + b, 2, 2, d);
        px(g, cx - 4, cy - 7 + b, INK); px(g, cx + 4, cy - 7 + b, INK);
        Gfx.disc(g, cx, cy - 1 + b, 4, d);
        Gfx.disc(g, cx, cy - 1 + b, 3, 0xFFF08A3C);
        rect(g, cx - 3, cy + b, 2, 1, w); rect(g, cx + 2, cy + b, 2, 1, w); rect(g, cx - 1, cy + b, 3, 2, w);     // cheeks and muzzle
        eyes(g, cx - 2, cx + 1, cy - 2 + b, look, blink);
        px(g, cx, cy + 1 + b, INK);
        if (fire) px(g, cx, cy + 2 + b, 0xFFE05A6A);
        rect(g, cx - 3, cy + 2 + b, 7, 1, 0xFF4FA05A); px(g, cx, cy + 3 + b, 0xFF4FA05A);                         // a leaf bandana
    }

    private void panda(GuiGraphics g, int cx, int cy, int b, int look, boolean fire, boolean blink) {
        int bl = 0xFF2A2433, gr = 0xFFB8B8C4;
        Gfx.disc(g, cx, cy + 2, 4, gr);
        Gfx.disc(g, cx, cy + 2, 3, 0xFFFFFFFF);
        rect(g, cx - 5, cy + 1, 2, 3, bl); rect(g, cx + 4, cy + (fire ? -1 : 1), 2, 3, bl);                       // arms
        rect(g, cx - 3, cy + 5, 2, 1, bl); rect(g, cx + 1, cy + 5, 2, 1, bl);                                     // feet
        int bx = look < 0 ? cx - 6 : cx + 6;
        rect(g, bx, cy - 4, 1, 8, 0xFF6CC04A); px(g, bx, cy - 1, 0xFF3F8F3A); px(g, bx, cy + 2, 0xFF3F8F3A);      // bamboo
        px(g, bx + (look < 0 ? -1 : 1), cy - 3, 0xFF9BE07A);
        Gfx.disc(g, cx - 3, cy - 5 + b, 1, bl); Gfx.disc(g, cx + 3, cy - 5 + b, 1, bl);                           // ears
        Gfx.disc(g, cx, cy - 2 + b, 4, gr);
        Gfx.disc(g, cx, cy - 2 + b, 3, 0xFFFFFFFF);
        rect(g, cx - 3, cy - 3 + b, 2, 2, bl); rect(g, cx + 2, cy - 3 + b, 2, 2, bl);                             // eye patches
        if (!blink) { px(g, cx - 2 + look, cy - 3 + b, 0xFFFFFFFF); px(g, cx + 2 + look, cy - 3 + b, 0xFFFFFFFF); }
        px(g, cx, cy - 1 + b, bl);
        if (fire) rect(g, cx - 1, cy + b, 2, 1, 0xFFE05A6A); else px(g, cx, cy + b, 0xFF6A5A70);
        px(g, cx - 3, cy - 1 + b, 0x90FF9DB5); px(g, cx + 3, cy - 1 + b, 0x90FF9DB5);
        rect(g, cx - 3, cy - 6 + b, 2, 1, 0xFFFF6B8A); rect(g, cx + 2, cy - 6 + b, 2, 1, 0xFFFF6B8A); px(g, cx, cy - 6 + b, 0xFFFF9DB5);   // a bow
    }

    // ---------- the pests ----------
    private void drawEnemy(GuiGraphics g, Enemy e) {
        int x = Math.round(e.x), y = Math.round(e.y);
        int fx = e.fx, fy = e.fy;
        boolean fl = e.flash > 0;
        int step = ((t + (int) (e.dist * 0.5F)) / 5) & 1;
        switch (e.kind) {
            case 0 -> {   // aphid
                Gfx.ellipse(g, x, y + 4, 3, 1, 0x28000000);
                rect(g, x - 3, y + 2 + step, 1, 2, 0xFF3F7F2A); rect(g, x + 2, y + 2 + (1 - step), 1, 2, 0xFF3F7F2A);
                px(g, x - 1, y + 3 + (1 - step), 0xFF3F7F2A); px(g, x + 1, y + 3 + step, 0xFF3F7F2A);
                Gfx.disc(g, x, y, 3, 0xFF3F8F2A);
                Gfx.disc(g, x, y, 2, fl ? 0xFFFFFFFF : 0xFF8EE866);
                px(g, x - 1, y - 1, 0xFFE2FFC8);
                int ex = x + fx, ey = y - 1 + (fy > 0 ? 1 : 0);
                px(g, ex - 1, ey, INK); px(g, ex + 1, ey, INK); px(g, ex - 1, ey - 1, 0xFFFFFFFF); px(g, ex + 1, ey - 1, 0xFFFFFFFF);
                px(g, x - 2 + fx, y - 3 + step, 0xFF3F7F2A); px(g, x + 2 + fx, y - 3 + (1 - step), 0xFF3F7F2A);   // feelers
            }
            case 1 -> {   // beetle
                Gfx.ellipse(g, x, y + 5, 4, 1, 0x28000000);
                px(g, x - 5, y - 1 + step, INK); px(g, x + 5, y - 1 + (1 - step), INK);
                px(g, x - 5, y + 2 + (1 - step), INK); px(g, x + 5, y + 2 + step, INK);
                Gfx.disc(g, x, y, 4, 0xFF4A2A78);
                Gfx.disc(g, x, y, 3, fl ? 0xFFFFFFFF : 0xFF8A6AD8);
                rect(g, x, y - 3, 1, 7, 0xFF4A2A78);
                px(g, x - 2, y - 2, 0xFFD8C8FF); px(g, x - 2, y - 1, 0xFFB8A0F0); px(g, x + 2, y + 1, 0xFF6A4AB0);
                Gfx.disc(g, x + fx * 4, y + fy * 4, 1, 0xFF2A2433);                                                   // head
                px(g, x + fx * 4 + fy, y + fy * 4 - fx - (fy == 0 ? 0 : 0), 0xFFFFFFFF);
            }
            case 2 -> {   // crow: flies above its own shadow
                int fly = y - 4 + (((t / 6) & 1) == 0 ? 0 : 1);
                Gfx.ellipse(g, x, y + 4, 3, 1, 0x30000000);
                int wing = ((t / 3) & 3);
                int wy = wing == 0 ? -4 : wing == 1 ? -2 : wing == 2 ? 0 : -2;
                Gfx.ellipse(g, x, fly, 3, 3, INK);
                Gfx.ellipse(g, x, fly, 2, 2, fl ? 0xFFFFFFFF : 0xFF4A4262);
                rect(g, x - 6, fly + wy, 4, 2, 0xFF3D3550); rect(g, x + 3, fly + wy, 4, 2, 0xFF3D3550);
                px(g, x - 6, fly + wy + 1, 0xFF5A5078); px(g, x + 6, fly + wy + 1, 0xFF5A5078);
                int hx = x + (fx == 0 ? 1 : fx * 3);
                rect(g, hx, fly, 2, 1, 0xFFFFA030);
                px(g, hx - (fx >= 0 ? 1 : -1), fly - 1, 0xFFFFFFFF);
                px(g, x - fx * 3, fly + 1, 0xFF2A2433);
            }
            default -> {  // boss snail
                int bob = ((t / 12) & 1);
                Gfx.ellipse(g, x, y + 7, 8, 2, 0x30000000);
                Gfx.ellipse(g, x, y + 4, 8, 3, 0xFFC96A94);
                Gfx.ellipse(g, x, y + 3, 7, 3, fl ? 0xFFFFFFFF : 0xFFF0A0C4);
                int hx = x + fx * 6;
                Gfx.disc(g, hx, y + 1, 3, 0xFFF0A0C4);
                px(g, hx - 1 + fx, y + 1 + bob, INK); px(g, hx + 1 + fx, y + 1 + bob, INK);
                rect(g, hx - 1, y - 3, 1, 2, 0xFFC96A94); rect(g, hx + 1, y - 3, 1, 2, 0xFFC96A94);                // eye stalks
                rect(g, hx - 2, y - 5 - bob, 2, 2, INK); rect(g, hx + 1, y - 5 - bob, 2, 2, INK);
                px(g, hx - 2, y - 5 - bob, 0xFFFFFFFF); px(g, hx + 1, y - 5 - bob, 0xFFFFFFFF);
                int sx = x - fx * 2;
                Gfx.disc(g, sx, y - 1, 6, 0xFF6A3A8C);
                Gfx.disc(g, sx, y - 1, 5, fl ? 0xFFFFFFFF : 0xFFA878D8);
                Gfx.disc(g, sx, y - 1, 3, 0xFF8A58B8);
                Gfx.disc(g, sx, y - 1, 1, 0xFFD8B8F8);
                px(g, sx - 3, y - 4, 0xFFE8D0FF);
                rect(g, sx - 2, y - 8, 5, 2, 0xFFFFD84A); px(g, sx - 2, y - 9, 0xFFFFD84A); px(g, sx, y - 10, 0xFFFFD84A); px(g, sx + 2, y - 9, 0xFFFFD84A); px(g, sx, y - 7, 0xFFE05A6A);   // a crown on the shell
            }
        }
        if (e.slow > 0) {
            Gfx.disc(g, x, y, e.kind == 3 ? 8 : 4, 0x2890D8FF);
            px(g, x - 3, y - 4 + ((t / 8) & 1), 0xFFFFFFFF); px(g, x + 3, y + 1, 0xFFC8EEFF); px(g, x, y - 5, 0xFFFFFFFF);
        }
        if (e.hp < e.maxHp || e.kind == 3) {
            int w = e.kind == 3 ? 16 : 9;
            hpBar(g, x - w / 2, y - (e.kind == 3 ? 13 : e.kind == 2 ? 11 : 8), w, Math.max(0F, e.hp / e.maxHp));
        }
    }

    // ---------- framework hooks ----------
    @Override
    public String hintKey() { return "cutemod.hint.garden"; }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return won ? Component.translatable("cutemod.garden.win") : Component.translatable("cutemod.garden.lose");
    }
}
