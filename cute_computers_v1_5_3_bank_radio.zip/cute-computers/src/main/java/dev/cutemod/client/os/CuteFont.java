package dev.cutemod.client.os;

import dev.cutemod.CuteMod;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;

/**
 * The cute pixel font of the computer (assets/cutemod/font/cute.json, Latin and Cyrillic, rounded and friendly).
 * Every text of the OS is drawn through here instead of {@code g.drawString}. A character the font does not have
 * (for example a dash or a symbol) falls back to the normal game font. Set {@link #ENABLED} to false to go back
 * to the normal font everywhere. The player picks the weight (cute / bold / normal) in Settings.
 */
public final class CuteFont {
    public static final boolean ENABLED = true;
    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "cute");
    public static final ResourceLocation BOLD_ID = ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "cute_bold");
    public static final ResourceLocation MODERN_ID = ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "modern");
    private static final Style REGULAR = Style.EMPTY.withFont(ID), BOLD = Style.EMPTY.withFont(BOLD_ID), MODERN = Style.EMPTY.withFont(MODERN_ID);

    /** The weight of the font (Settings > Other > Font): 0 = cute, 1 = cute bold, 2 = the normal game font, 3 = modern (a smooth, not pixel font: Carlito). Kept in the computer's data. */
    public static final int REGULAR_W = 0, BOLD_W = 1, SYSTEM_W = 2, MODERN_W = 3;
    private static int weight;
    private static long readAt;

    public static int weight() {
        long now = System.currentTimeMillis();
        if (now - readAt > 500) {                                   // look at the saved value now and then (it arrives after the login)
            readAt = now;
            if (Store.ready()) {
                try { weight = Math.max(0, Math.min(3, Integer.parseInt(String.valueOf(Store.read("fontweight")).trim()))); }
                catch (NumberFormatException ignored) { weight = REGULAR_W; }
            }
        }
        return weight;
    }

    public static void setWeight(int w) {
        weight = Math.max(0, Math.min(3, w));
        readAt = System.currentTimeMillis();
        Store.write("fontweight", Integer.toString(weight));
    }

    /** The style to draw with, or null for the normal game font. */
    private static Style style() {
        if (!ENABLED) return null;
        return switch (weight()) { case BOLD_W -> BOLD; case MODERN_W -> MODERN; case SYSTEM_W -> null; default -> REGULAR; };
    }

    private CuteFont() {}

    private static Component cute(String s, Style st) { return Component.literal(s).withStyle(st); }

    private static Component cute(Component s, Style st) {
        MutableComponent root = Component.empty().withStyle(st);   // the parts inherit the font, keep their own colours
        return root.append(s);
    }

    public static int draw(GuiGraphics g, Font f, String s, int x, int y, int argb, boolean shadow) {
        Style st = style();
        return st != null ? g.drawString(f, cute(s, st), x, y, argb, shadow) : g.drawString(f, s, x, y, argb, shadow);
    }

    public static int draw(GuiGraphics g, Font f, String s, int x, int y, int argb) { return draw(g, f, s, x, y, argb, true); }

    public static int draw(GuiGraphics g, Font f, Component s, int x, int y, int argb, boolean shadow) {
        Style st = style();
        return st != null ? g.drawString(f, cute(s, st), x, y, argb, shadow) : g.drawString(f, s, x, y, argb, shadow);
    }

    public static int draw(GuiGraphics g, Font f, Component s, int x, int y, int argb) { return draw(g, f, s, x, y, argb, true); }

    /** A ready line of text keeps the font it has. */
    public static int draw(GuiGraphics g, Font f, FormattedCharSequence s, int x, int y, int argb, boolean shadow) {
        return g.drawString(f, s, x, y, argb, shadow);
    }

    public static int draw(GuiGraphics g, Font f, FormattedCharSequence s, int x, int y, int argb) { return draw(g, f, s, x, y, argb, true); }
}
