package dev.cutemod.client.os;

import dev.cutemod.CuteMod;
import dev.cutemod.ComputerColor;
import dev.cutemod.data.PetWear;
import dev.cutemod.data.ShowBoard;
import dev.cutemod.data.ShowJudges;
import dev.cutemod.net.ShowSyncPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/**
 * The talent show screen of the Tamagotchi app: a stage with curtains, a marquee, moving spotlights, four judges
 * at their desk and the pets of the round. It only draws what the server says (see {@link ShowSyncPayload}); the
 * rounds, the stars and the prizes are decided on the server.
 * <ul>
 *   <li>doors open: put your pet on the stage, click a pet to like it (click again to take the like back);</li>
 *   <li>judging: the judges show their stars one by one;</li>
 *   <li>results: a podium with confetti, your place and your prize.</li>
 * </ul>
 */
final class PetStage {
    private static final int W = App.W, H = App.H;
    private static final int FOOT_Y = 152, FOOT_H = 14;
    private static final int WALL_TOP = 13, DESK_Y = 50, FLOOR_Y = 58;
    private static final int TEXT = 0xFF3A2A3A, GOLD = 0xFFF3C45A, ACCENT = 0xFFB57BD6;
    private static final int[] JUDGE_COL = {0xFFFFFFFF, 0xFF8FD39A, 0xFFC9A0FF, 0xFFFFD84D, 0xFFFF9A9A, 0xFFFFB070, 0xFFFFB3D9, 0xFF9CCBFF};
    private static final int[] MEDAL = {0xFFF3C45A, 0xFFC4CAD6, 0xFFD08A4E};
    private static final int[] CONFETTI = {0xFFFF5C93, 0xFFFFD84D, 0xFF5BD9C8, 0xFF8FB8FF, 0xFFB57BD6, 0xFFFFFFFF};

    private final String myColor;
    private final Runnable back;
    private final Random rnd = new Random();

    private int ticks, timer = 1000, toastT, armed, armT, bannerT;
    private String toast = "", pending = "";
    private ShowSyncPayload cur, seen;
    private boolean hall;                                       // the Hall of Fame panel is open
    private float curtain;                                       // how far the curtains are open: 0 closed, 1 open
    private int crowdBoost;                                      // the audience cheers for a moment (a like, a judge spoke)
    private boolean room;                                       // the act room (choose an act, rehearse) is open
    private boolean flowerMode;                                 // the next click on a pet gives the golden flower
    private static final int HALL_X = 27, HALL_Y = 26;
    private int curAt;
    private int lastJudges = -1, lastPhase = -1;
    private final int[] flash = new int[ShowJudges.COUNT];
    // what the judges say (like the animals of a village: a speech box, text that types itself and soft blips)
    /** The voices of the eight judges (the index is the judge, see ShowJudges): Mei high and sweet, Boom a little hiss and a round "bwoo",
     *  Void deep and quiet, Honey bright and buzzy, Lady a tiny bell, Fox a bright "yip", Kit a soft "mrrp", Pip a bouncy "pwip".
     *  Our own sounds (sounds/voice/<judge>_<0..7>.ogg, made by tools/make_voices.py), not Minecraft's. */
    private static final SoundEvent[] VOICE = {voice("mei"), voice("boom"), voice("void"), voice("honey"),
            voice("lady"), voice("fox"), voice("kit"), voice("pip")};
    private static final float[] VOICE_VOL = {0.45F, 0.45F, 0.65F, 0.40F, 0.40F, 0.42F, 0.45F, 0.40F};      // Void is quiet by nature, so a little louder

    private static SoundEvent voice(String judge) {
        return SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "voice." + judge));
    }
    private final ArrayDeque<Object[]> queue = new ArrayDeque<>();          // {seat, text, judge}
    private int spkJ = -1, spkP, spkAge, spkHold, idleT = 600, lastTheme = -1, lastRender = -100;   // spkJ = the seat that talks, spkP = the judge that sits there
    private final Map<String, Integer> lastLine = new HashMap<>();          // the last line said from every group of lines (so nobody repeats a line right away)
    private String spkText = "";
    private final Map<String, Integer> lastLikes = new HashMap<>();
    private final List<double[]> hearts = new ArrayList<>();     // x, y, vx, vy, life
    private final List<double[]> confetti = new ArrayList<>();   // x, y, vx, vy, color index, spin

    // the place of every pet on the screen, filled while drawing and used for the mouse
    private int[] px = new int[0], pf = new int[0];
    private float[] ps = new float[0];

    PetStage(String myColor, Runnable back) {
        this.myColor = myColor;
        this.back = back;
    }

    void open() {
        cur = Show.last();
        seen = cur;
        curAt = ticks;
        if (cur != null) {
            lastJudges = cur.head().judges();
            lastPhase = cur.head().phase();
            rememberLikes(cur);
        }
        timer = 1000;
        curtain = 0F;                                               // the curtains open when we come in
        queue.clear();
        spkJ = -1;
        idleT = 300;
        lastTheme = -1;
    }

    private static String myId() {
        var p = Minecraft.getInstance().player;
        return p == null ? "" : p.getUUID().toString();
    }

    private static String t(String key, Object... args) { return net.minecraft.network.chat.Component.translatable(key, args).getString(); }

    private void say(String key) { toast = t(key); toastT = 150; }

    /** The judge (0-7) who sits on a seat (0-3) in this round: a different panel every round (see ShowJudges.panelOf). */
    private int who(int seat) { return ShowJudges.persona(cur == null ? 0 : cur.head().panel(), seat); }

    /** How many lines there are in a group: prefix0, prefix1, ... (so a language file may hold as many as it likes). */
    private static int count(String prefix) {
        int n = 0;
        while (net.minecraft.client.resources.language.I18n.exists(prefix + n)) n++;
        return n;
    }

    /** A random line of a group, never the same one twice in a row. */
    private String line(String prefix, Object... args) {
        int n = count(prefix);
        if (n == 0) return "";
        int k = rnd.nextInt(n);
        Integer last = lastLine.get(prefix);
        if (n > 1 && last != null && k == last) k = (k + 1 + rnd.nextInt(n - 1)) % n;
        lastLine.put(prefix, k);
        return t(prefix + k, args);
    }

    // ---------- time and the news from the server ----------
    void tick() {
        ticks++;
        if (ticks - lastRender < 5) GameMusic.keep("show", false);    // the show tune, only while the stage is on screen
        speechTick();
        if (++timer >= 120) { Show.request(); timer = 0; }
        if (toastT > 0) toastT--;
        if (bannerT > 0) bannerT--;
        if (crowdBoost > 0) crowdBoost--;
        float goal = cur != null && phase() == ShowBoard.IDLE ? 0F : 1F;      // no show: the curtains are closed
        curtain += (goal - curtain) * 0.06F;
        if (Math.abs(goal - curtain) < 0.01F) curtain = goal;
        if (armT > 0 && --armT == 0) armed = 0;
        for (int i = 0; i < flash.length; i++) if (flash[i] > 0) flash[i]--;
        ShowSyncPayload s = Show.last();
        if (s != seen) {
            seen = s;
            if (s != null) { cur = s; curAt = ticks; onNews(s); }
        }
        if (cur != null && leftSec() == 0 && timer > 60) { Show.request(); timer = 0; }   // the phase has just ended: look again
        // hearts
        for (int i = hearts.size() - 1; i >= 0; i--) {
            double[] h = hearts.get(i);
            h[0] += h[2]; h[1] += h[3]; h[4]--;
            if (h[4] <= 0) hearts.remove(i);
        }
        // confetti while the results are on
        boolean results = cur != null && cur.head().phase() == ShowBoard.RESULTS;
        if (results && ticks % 3 == 0 && confetti.size() < 90) spawnConfetti(1);
        for (int i = confetti.size() - 1; i >= 0; i--) {
            double[] c = confetti.get(i);
            c[0] += c[2] + Math.sin((ticks + i * 7) / 12.0) * 0.4;
            c[1] += c[3];
            c[5] += 0.2;
            if (c[1] > FOOT_Y) confetti.remove(i);
        }
    }

    private int leftSec() {
        if (cur == null) return 0;
        return Math.max(0, cur.head().leftSec() - (ticks - curAt) / 60);
    }

    private void spawnConfetti(int n) {
        for (int i = 0; i < n; i++)
            confetti.add(new double[]{24 + rnd.nextInt(W - 48), WALL_TOP + 2, (rnd.nextDouble() - 0.5) * 0.6, 0.5 + rnd.nextDouble() * 0.7, rnd.nextInt(CONFETTI.length), rnd.nextDouble() * 6});
    }

    private static String key(ShowSyncPayload.Entry e) { return e.who().owner() + "/" + e.who().name() + "/" + e.who().color(); }

    private void rememberLikes(ShowSyncPayload s) {
        lastLikes.clear();
        for (ShowSyncPayload.Entry e : s.pets()) lastLikes.put(key(e), e.likes());
    }

    private void onNews(ShowSyncPayload s) {
        if (s.head().result() >= 0) onResult(s.head().result());
        int phase = s.head().phase();
        // judges that have just spoken
        if (lastJudges >= 0 && s.head().judges() > lastJudges) {
            for (int j = lastJudges; j < s.head().judges() && j < flash.length; j++) {
                flash[j] = 90;
                crowdBoost = 120;
                Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 0.9F + 0.15F * j, 0.6F);
                if (phase == ShowBoard.JUDGING) revealSpeech(s, j);
            }
            if (phase == ShowBoard.JUDGING && s.head().judges() >= ShowJudges.COUNT) dispute(s);   // the last judge has spoken: do they agree?
        }
        int theme = s.head().theme();
        if (theme != lastTheme) {
            lastTheme = theme;
            if (phase == ShowBoard.OPEN) {                                  // a random judge announces the theme
                int seat = rnd.nextInt(ShowJudges.COUNT);
                speak(seat, line("cutemod.show.say." + who(seat) + ".theme.", t("cutemod.show.theme." + theme)));
            }
        }
        if (phase == ShowBoard.JUDGING && lastPhase == ShowBoard.OPEN) {
            int seat = rnd.nextInt(ShowJudges.COUNT);
            speak(seat, line("cutemod.show.say." + who(seat) + ".judging."));
        }
        lastJudges = s.head().judges();
        // the results have just begun
        if (phase == ShowBoard.RESULTS && lastPhase >= 0 && lastPhase != ShowBoard.RESULTS) {
            spawnConfetti(70);
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 0.9F, 0.6F);
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.2F, 0.6F);
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.8F, 0.6F);
            bannerT = 600;
            if (!s.pets().isEmpty()) {
                int a = rnd.nextInt(ShowJudges.COUNT), b = (a + 1 + rnd.nextInt(ShowJudges.COUNT - 1)) % ShowJudges.COUNT;   // two different judges
                speak(a, line("cutemod.show.say." + who(a) + ".winner.", s.pets().get(0).who().name()));
                speak(b, line("cutemod.show.say." + who(b) + ".bye."));
            }
        } else if (phase == ShowBoard.RESULTS && lastPhase < 0 && bannerT == 0) {
            bannerT = 600;
            spawnConfetti(40);
        }
        lastPhase = phase;
        // a like has just come: hearts rise from that pet
        for (int i = 0; i < s.pets().size(); i++) {
            ShowSyncPayload.Entry e = s.pets().get(i);
            Integer old = lastLikes.get(key(e));
            if (old != null && e.likes() > old && i < px.length) {
                crowdBoost = Math.max(crowdBoost, 90);
                for (int k = 0; k < Math.min(4, e.likes() - old + 1); k++)
                    hearts.add(new double[]{px[i] - 8 + rnd.nextInt(16), pf[i] - 30, (rnd.nextDouble() - 0.5) * 0.4, -0.5 - rnd.nextDouble() * 0.3, 50 + rnd.nextInt(25)});
            }
        }
        rememberLikes(s);
    }

    /** The answer of the server to what we did. */
    private void onResult(int r) {
        String what = pending;
        pending = "";
        switch (r) {
            case 0 -> { if (what.equals("put")) say("cutemod.show.msg.put"); else if (what.equals("take")) say("cutemod.show.msg.taken"); else if (what.equals("flower")) say("cutemod.show.msg.flower"); }
            case 10 -> say("cutemod.show.msg.stage");
            case 11 -> say("cutemod.show.msg.used");
            case 1 -> say("cutemod.show.msg.fast");
            case 3 -> say("cutemod.show.msg.sick");
            case 4 -> say("cutemod.show.msg.own");
            case 5 -> say("cutemod.show.msg.missing");
            case 7 -> say("cutemod.show.msg.closed");
            case 8 -> say("cutemod.show.msg.full");
            case 9 -> say("cutemod.show.msg.guest");
            default -> say("cutemod.show.msg.refused");
        }
    }

    // ---------- the judges talk ----------
    private void speak(int j, String text) {
        while (queue.size() >= 6) queue.poll();
        queue.add(new Object[]{j, text, who(j)});
    }

    private void speakIdle(int j) { speak(j, line("cutemod.show.say." + who(j) + ".idle.")); }

    /** The pet the judges talk about: yours, or if you are not on the stage, the one that judge j likes best. */
    private ShowSyncPayload.Entry aboutPet(ShowSyncPayload s, int j) {
        ShowSyncPayload.Entry about = null;
        String me = myId();
        for (ShowSyncPayload.Entry e : s.pets()) if (!e.bot() && e.who().owner().equals(me)) about = e;
        if (about == null) {
            int best = -1;
            for (ShowSyncPayload.Entry e : s.pets()) {
                int v = e.score().stars().get(j);
                if (v > best) { best = v; about = e; }
            }
        }
        return about;
    }

    /** After a judge has shown the stars he or she says something about your pet (or the best one if you are not on the stage), and why. */
    private void revealSpeech(ShowSyncPayload s, int j) {
        ShowSyncPayload.Entry about = aboutPet(s, j);
        if (about == null) return;
        int v = about.score().stars().get(j);
        int tier = v <= 2 ? 0 : v == 3 ? 1 : 2;
        speak(j, line("cutemod.show.say." + who(j) + "." + tier + ".", about.who().name()));
        boolean fight = j == ShowJudges.COUNT - 1 && fightOf(s) != null;      // the last judge has enough to do: the quarrel comes next
        String why = fight ? null : why(s, j, about, tier);
        if (why != null && queue.size() < 4) speak(j, why);
    }

    /**
     * The reason for the stars, said out loud: what the judge saw on the pet (the taste of this judge, see PetWear.likes),
     * what is missing, a whole set, or how well the clothes fit the theme. null if there is nothing to say.
     */
    private String why(ShowSyncPayload s, int j, ShowSyncPayload.Entry e, int tier) {
        int p = who(j);
        String head = e.look().head(), body = e.look().body();
        List<String> worn = new ArrayList<>();
        worn.addAll(List.of(PetWear.layers(head)));
        worn.addAll(List.of(PetWear.layers(body)));
        String base = "cutemod.show.why." + p + ".";
        if (worn.isEmpty()) return line(base + "naked.");
        List<String> liked = new ArrayList<>(), missing = new ArrayList<>();
        for (String id : worn) if (PetWear.likes(p, id)) liked.add(id);
        for (String id : PetWear.likedBy(p)) if (!worn.contains(id)) missing.add(id);
        List<String> kinds = new ArrayList<>();
        if (tier == 2) {
            if (!liked.isEmpty()) kinds.add("like");
            if (PetWear.setPieces(head, body).size() >= 2) kinds.add("set");
            if (ShowJudges.themeBonus(s.head().theme(), e.look().stage(), e.look().trait(), head, body) >= 0.6) kinds.add("theme");
        } else if (tier == 1) {
            if (!liked.isEmpty()) kinds.add("like");
            if (!missing.isEmpty()) kinds.add("want");
        } else if (!missing.isEmpty()) {
            kinds.add("want");
        }
        if (kinds.isEmpty()) return null;
        String kind = kinds.get(rnd.nextInt(kinds.size()));
        return switch (kind) {
            case "like" -> line(base + "like.", itemName(liked.get(rnd.nextInt(liked.size()))));
            case "want" -> line(base + "want.", itemName(missing.get(rnd.nextInt(missing.size()))));
            case "set" -> { List<String> pc = PetWear.setPieces(head, body); yield line(base + "set.", itemName(pc.get(0)), itemName(pc.get(1))); }
            default -> line(base + "theme.", t("cutemod.show.theme." + s.head().theme()));
        };
    }

    private static String itemName(String id) { return t("cutemod.shop.item." + id).toLowerCase(java.util.Locale.ROOT); }

    /** The pet two judges quarrel about: yours, or if you are not on the stage, the one the judges disagree about most (a spread of 3 stars or more). */
    private ShowSyncPayload.Entry fightOf(ShowSyncPayload s) {
        if (s.head().judges() < ShowJudges.COUNT) return null;
        ShowSyncPayload.Entry pick = null;
        String me = myId();
        for (ShowSyncPayload.Entry e : s.pets()) if (!e.bot() && e.who().owner().equals(me)) pick = e;
        if (pick == null) {
            int most = 2;
            for (ShowSyncPayload.Entry e : s.pets()) if (spread(e) > most) { most = spread(e); pick = e; }
        }
        return pick != null && spread(pick) >= 3 ? pick : null;
    }

    private static int spread(ShowSyncPayload.Entry e) {
        List<Integer> st = e.score().stars();
        if (st.size() < ShowJudges.COUNT) return 0;
        int lo = 9, hi = 0;
        for (int k = 0; k < ShowJudges.COUNT; k++) { lo = Math.min(lo, st.get(k)); hi = Math.max(hi, st.get(k)); }
        return hi - lo;
    }

    /** Two judges who gave very different stars argue about the pet (the one who gave most speaks first), and a third one calms them down. */
    private void dispute(ShowSyncPayload s) {
        ShowSyncPayload.Entry e = fightOf(s);
        if (e == null) return;
        List<Integer> st = e.score().stars();
        int hi = 0, lo = 0;
        for (int k = 1; k < ShowJudges.COUNT; k++) {
            if (st.get(k) > st.get(hi)) hi = k;
            if (st.get(k) < st.get(lo)) lo = k;
        }
        if (hi == lo) return;
        String hiName = t("cutemod.show.judge." + who(hi)), loName = t("cutemod.show.judge." + who(lo)), pet = e.who().name();
        int calm = hi == 0 || lo == 0 ? (hi == 1 || lo == 1 ? 2 : 1) : 0;      // the first seat that is neither of them
        speak(hi, line("cutemod.show.fight." + who(hi) + ".hi.", loName, pet));
        speak(lo, line("cutemod.show.fight." + who(lo) + ".lo.", hiName, pet));
        speak(calm, line("cutemod.show.fight." + who(calm) + ".peace.", hiName, loName));
    }

    private void speechTick() {
        if (spkJ >= 0) {
            spkAge++;
            int shown = spkAge / 3;                                     // about 20 letters a second
            if (spkAge % 3 == 0 && shown > 0 && shown <= spkText.length() && shown % 2 == 0) {
                char c = spkText.charAt(shown - 1);
                if (Character.isLetterOrDigit(c))                       // one soft blip for every other letter
                    Sfx.ui(VOICE[spkP], 0.92F + (c % 7) * 0.035F, VOICE_VOL[spkP]);   // the letter picks how high the syllable is
            }
            if (shown >= spkText.length() && ++spkHold > 150) spkJ = -1;   // time to read it
        } else if (!queue.isEmpty()) {
            Object[] n = queue.poll();
            spkJ = (Integer) n[0];
            spkText = (String) n[1];
            spkP = (Integer) n[2];
            spkAge = 0;
            spkHold = 0;
        } else if (cur != null && phase() == ShowBoard.OPEN && --idleT <= 0) {
            idleT = 900 + rnd.nextInt(900);
            speakIdle(rnd.nextInt(ShowJudges.COUNT));
        }
    }

    private void speech(GuiGraphics g, Font f) {
        if (spkJ < 0) return;
        int maxW = 190;
        List<String> lines = new ArrayList<>();
        for (var l : f.getSplitter().splitLines(spkText, maxW, Style.EMPTY)) lines.add(l.getString());
        if (lines.size() > 3) lines = lines.subList(0, 3);
        int bw = 0;
        for (String l : lines) bw = Math.max(bw, f.width(l));
        bw += 14;
        int bh = 14 + lines.size() * 10;
        int cx = 70 + spkJ * 53;
        int bx = Math.max(28, Math.min(W - 28 - bw, cx - bw / 2)), by = 62;
        // the box with a tail that points to whoever is talking
        rect(g, bx - 1, by - 1, bw + 2, bh + 2, 0xFF3A2A3A);
        rect(g, bx, by, bw, bh, 0xF8FFFFFF);
        rect(g, cx - 3, by - 3, 7, 3, 0xFF3A2A3A);
        rect(g, cx - 2, by - 3, 5, 3, 0xF8FFFFFF);
        rect(g, cx - 1, by - 4, 3, 1, 0xFF3A2A3A);
        // the name tag
        String name = t("cutemod.show.judge." + spkP);
        int nw = f.width(name) + 10;
        rect(g, bx + 4, by - 6, nw, 10, 0xFF3A2A3A);
        rect(g, bx + 5, by - 5, nw - 2, 8, JUDGE_COL[spkP]);
        Fit.str(g, f, name, bx + 9, by - 4, TEXT, false);
        // the text types itself
        int remaining = spkAge / 3, y = by + 7;
        for (String l : lines) {
            int n = Math.min(l.length(), Math.max(0, remaining));
            Fit.str(g, f, l.substring(0, n), bx + 7, y, TEXT, false);
            remaining -= l.length() + 1;
            y += 10;
        }
        if (spkAge / 3 >= spkText.length() && (ticks / 15) % 2 == 0)       // "more" / done marker
            rect(g, bx + bw - 10, by + bh - 6, 5, 3, ACCENT);
    }

    // ---------- the clock, the phase and the theme ----------
    private static void plate(GuiGraphics g, int x, int y, int w, int h) {
        rect(g, x, y, w, h, 0xFF2A0E3A);
        rect(g, x + 1, y + 1, w - 2, h - 2, 0xFF5A1670);
    }

    private void clock(GuiGraphics g, Font f) {
        int ph = phase(), s = leftSec();
        boolean hurry = cur != null && ph == ShowBoard.OPEN && s <= 10 && (ticks / 10) % 2 == 0;
        int col = hurry ? 0xFFFF6B6B : ph == ShowBoard.OPEN ? 0xFFB6F5C4 : ph == ShowBoard.JUDGING ? 0xFFFFE066 : 0xFFFFB3D9;
        // the big clock on the left: how long until the phase ends
        int x = 27, y = 3, w = 44, h = 13;   // the plates are 44 wide, the sign sits between them
        plate(g, x, y, w, h);
        disc(g, x + 8, y + 6, 4, 0xFFFFFFFF);
        rect(g, x + 8, y + 3, 1, 4, 0xFF3A2A3A);
        rect(g, x + 8, y + 6, 3, 1, 0xFF3A2A3A);
        String tm = cur == null || ph == ShowBoard.IDLE ? "-:--" : (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
        Fit.boxC(g, f, tm, x + 14, y + 3, col, true, w - 17);
        // what is going on, on the right
        int rx = 229;
        plate(g, rx, y, w, h);
        Fit.boxC(g, f, t("cutemod.show.phase.short." + ph), rx + 2, y + 3, col, false, w - 4);
        // the whole round as a bar: open / judging / results
        int bx = 27, bw = 246, by = 17;
        long total = ShowBoard.ROUND_MS;
        int w1 = (int) (bw * ShowBoard.OPEN_MS / total), w2 = (int) (bw * (ShowBoard.RESULTS_AT_MS - ShowBoard.OPEN_MS) / total), w3 = bw - w1 - w2;
        long remaining = s * 1000L + (ph == ShowBoard.OPEN ? total - ShowBoard.OPEN_MS : ph == ShowBoard.JUDGING ? total - ShowBoard.RESULTS_AT_MS : 0);
        int done = cur == null || ph == ShowBoard.IDLE ? 0 : (int) Math.max(0, Math.min(bw, bw * (total - remaining) / total));
        int[] start = {0, w1, w1 + w2}, len = {w1, w2, w3};
        int[] dim = {0xFF1E5A38, 0xFF6A5A18, 0xFF6A2A52}, lit = {0xFF5BD97A, 0xFFFFD84D, 0xFFFF7CC4};
        for (int k = 0; k < 3; k++) {
            rect(g, bx + start[k], by, len[k] - 1, 3, dim[k]);
            int fill = Math.max(0, Math.min(len[k] - 1, done - start[k]));
            if (fill > 0) rect(g, bx + start[k], by, fill, 3, lit[k]);
        }
        rect(g, bx + done - 1, by - 1, 2, 5, 0xFFFFFFFF);
    }

    private void themePill(GuiGraphics g, Font f, int mx, int my) {
        if (cur == null || phase() == ShowBoard.IDLE || (phase() == ShowBoard.RESULTS && bannerT > 0)) return;
        int th = cur.head().theme();
        String label = t("cutemod.show.theme.label", t("cutemod.show.theme." + th));
        int w = f.width(label) + 22, x = (W - w) / 2, y = 22;
        rect(g, x, y, w, 11, 0xCC2A0E3A);
        rect(g, x, y + 10, w, 1, GOLD);
        star(g, x + 4, y + 3, GOLD);
        star(g, x + w - 9, y + 3, GOLD);
        Fit.str(g, f, label, x + 11, y + 2, 0xFFFFE9A8, false);
        if (App.in(mx, my, x, y, w, 11)) {                               // the hint: what the judges like tonight
            String hint = t("cutemod.show.theme.hint." + th) + " " + t("cutemod.show.theme.act", t("cutemod.show.act." + ShowJudges.bestActFor(th)));
            int hw = Math.min(W - 40, f.width(hint) + 8);
            List<String> hl = new ArrayList<>();
            for (var l : f.getSplitter().splitLines(hint, hw - 8, Style.EMPTY)) hl.add(l.getString());
            int hh = hl.size() * 10 + 4, hx = (W - hw) / 2, hy = y + 14;
            rect(g, hx, hy, hw, hh, 0xEE3A2A3A);
            for (int i = 0; i < hl.size(); i++) Fit.str(g, f, hl.get(i), hx + 4, hy + 3 + i * 10, 0xFFFFFFFF, false);
        }
    }

    // ---------- where the pets stand ----------
    /** Fills px / pf / ps for n pets. In the results the first three stand on the podium. */
    private void layout(int n, boolean results) {
        if (px.length != n) { px = new int[n]; pf = new int[n]; ps = new float[n]; }
        if (results) {
            gap = 40;
            for (int i = 0; i < n; i++) {
                switch (i) {
                    case 0 -> { px[i] = 150; pf[i] = 120; ps[i] = 0.62F; }
                    case 1 -> { px[i] = 94; pf[i] = 130; ps[i] = 0.55F; }
                    case 2 -> { px[i] = 206; pf[i] = 136; ps[i] = 0.5F; }
                    default -> {
                        int k = i - 3;
                        boolean left = k % 2 == 0;
                        int col = k / 2;
                        px[i] = left ? 34 + col * 20 : 266 - col * 20;
                        pf[i] = col == 2 ? 134 : 148;
                        ps[i] = 0.4F;
                    }
                }
            }
        } else if (n <= 4) {
            int x0 = 150 - (n - 1) * 33;
            gap = 66;
            for (int i = 0; i < n; i++) { px[i] = x0 + i * 66; pf[i] = 118; ps[i] = 0.75F; }
        } else {
            int back = (n + 1) / 2, front = n - back;
            int step = Math.min(62, 236 / Math.max(1, back - 1));
            gap = step;
            for (int i = 0; i < n; i++) {
                boolean b = i < back;
                int cnt = b ? back : front, idx = b ? i : i - back;
                px[i] = 150 - (cnt - 1) * step / 2 + idx * step;
                pf[i] = b ? 86 : 130;
                ps[i] = 0.5F;
            }
        }
    }

    private int gap = 66;

    private int petAt(int mx, int my) {
        for (int i = px.length - 1; i >= 0; i--) {
            float s = ps[i];
            if (mx >= px[i] - 28 * s - 4 && mx <= px[i] + 28 * s + 4 && my >= pf[i] - 56 * s && my <= pf[i] + 10) return i;
        }
        return -1;
    }

    // ---------- drawing ----------
    void render(GuiGraphics g, int mx, int my) {
        Font f = Minecraft.getInstance().font;
        lastRender = ticks;
        List<ShowSyncPayload.Entry> pets = cur == null ? List.of() : cur.pets();
        int phase = cur == null ? ShowBoard.OPEN : cur.head().phase();
        boolean results = phase == ShowBoard.RESULTS;
        layout(pets.size(), results);
        int hover = room || hall ? -1 : petAt(mx, my);

        wall(g);
        desk(g);
        floor(g);
        spotlights(g);
        if (results) podium(g, f, pets);
        judges(g, f, pets, hover);
        String me = myId();
        // pets: back to front, so the nearer ones cover the farther ones
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < pets.size(); i++) order.add(i);
        order.sort((a, b) -> Integer.compare(pf[a], pf[b]));
        for (int i : order) pet(g, f, pets.get(i), i, me, hover == i, results);
        curtains(g, f);
        marquee(g, f);
        clock(g, f);
        for (double[] c : confetti) {
            int col = CONFETTI[(int) c[4]];
            int w = Math.sin(c[5]) > 0 ? 3 : 2;
            rect(g, (int) c[0], (int) c[1], w, 3, col);
        }
        for (double[] h : hearts) {
            int a = (int) Math.min(255, h[4] * 8);
            PetShow.heart(g, (int) h[0], (int) h[1], (a << 24) | 0xFF5C93);
        }
        g.pose().pushPose();
        g.pose().translate(0, 0, 60);
        speech(g, f);
        g.pose().popPose();
        if (results && bannerT > 0 && !pets.isEmpty()) winnerBanner(g, f, pets.get(0));
        themePill(g, f, mx, my);
        hallButton(g, f, mx, my);
        if (room) {
            g.pose().pushPose();
            g.pose().translate(0, 0, 40);
            roomPanel(g, f, mx, my);
            g.pose().popPose();
        }
        footer(g, f, mx, my);
        g.pose().pushPose();
        g.pose().translate(0, 0, 80);
        if (toastT > 0) {
            int w = Math.min(W - 8, f.width(toast) + 12), x = (W - w) / 2, y = FOOT_Y - 16;
            rect(g, x, y, w, 13, 0xEE3A2A3A);
            Fit.boxC(g, f, toast, x + 6, y + 3, 0xFFFFFFFF, false, w - 12);
        }
        if (hover >= 0 && !hall) tooltip(g, f, pets.get(hover), mx, my);
        g.pose().popPose();
        if (hall) {
            g.pose().pushPose();
            g.pose().translate(0, 0, 90);
            hallPanel(g, f);
            g.pose().popPose();
        }
        if (cur == null) {
            String l = t("cutemod.net.loading");
            Fit.str(g, f, l, (W - f.width(l)) / 2, 100, 0xFFE4D8FF, false);
        }
    }

    private void wall(GuiGraphics g) {
        for (int y = 0; y < FLOOR_Y; y += 3) {                    // a purple night that gets lighter downwards
            int c = App.mix(0x1E0F44, 0x5A2E8F, y / (float) FLOOR_Y);
            rect(g, 0, y, W, 3, c);
        }
        for (int i = 0; i < 12; i++) {                            // a few twinkling stars high on the wall
            int x = 26 + (i * 73) % (W - 52), y = WALL_TOP + 1 + (i * 37) % 6;
            if ((ticks / 12 + i) % 4 != 0) rect(g, x, y, 1, 1, 0xCCFFFFFF);
            else { rect(g, x - 1, y, 3, 1, 0xFFFFE9A8); rect(g, x, y - 1, 1, 3, 0xFFFFE9A8); }
        }
        crowd(g);
        // soft party lights behind the judges
        int[] glow = {0x33FF5C93, 0x335BD9C8, 0x33FFD84D, 0x33B57BD6};
        for (int i = 0; i < 4; i++) {
            int r = 16 + (int) (Math.sin(ticks / 25.0 + i * 1.7) * 3);
            disc(g, 70 + i * 53, 36, r, glow[i]);
        }
    }

    /**
     * The audience: three tiers of little pets seen from the stage as dark silhouettes (the nearer, the darker), behind the
     * judges. They sway to the music, hush while the judges speak and cheer with raised arms and glow sticks in the results,
     * and every like or judge that speaks gets a short burst of cheering.
     */
    private void crowd(GuiGraphics g) {
        int ph = phase();
        double exc = ph == ShowBoard.RESULTS ? 1.0 : ph == ShowBoard.JUDGING ? 0.12 : ph == ShowBoard.OPEN ? 0.4 : 0.2;
        exc = Math.max(exc, Math.min(0.9, crowdBoost / 90.0));
        ComputerColor[] cols = ComputerColor.values();
        int[] rowY = {26, 34, 43}, rad = {2, 3, 3}, step = {10, 11, 13};
        float[] dark = {0.5F, 0.68F, 0.82F};
        for (int row = 0; row < 3; row++) {
            for (int k = 0, x = 27 + (row == 1 ? 5 : 0); x < W - 26; k++, x += step[row]) {
                int id = row * 40 + k;
                int body = cols[(id * 5 + row) % cols.length].bodyColor;
                int c = 0xFF000000 | App.mix(body & 0xFFFFFF, 0x120828, dark[row]);
                double wave = Math.sin(ticks / (ph == ShowBoard.JUDGING ? 22.0 : 7.0) + id * 1.3);
                int y = rowY[row] + (int) Math.round(wave * exc * 1.6) - (row == 2 ? 0 : 0);
                int sway = (int) Math.round(Math.sin(ticks / 30.0 + id) * (ph == ShowBoard.JUDGING ? 0 : 1));
                int r = rad[row], cx = x + sway;
                rect(g, cx - r, y + r, r * 2 + 1, Math.max(1, DESK_Y + 2 - (y + r)), c);                      // shoulders and body (the desk covers the rest)
                disc(g, cx, y, r, c);                                                 // the head
                switch (id % 3) {                                                     // ears: pointed, round or none
                    case 0 -> { rect(g, cx - r, y - r - 1, 1, 2, c); rect(g, cx + r, y - r - 1, 1, 2, c); }
                    case 1 -> { rect(g, cx - r - 1, y - r, 2, 2, c); rect(g, cx + r, y - r, 2, 2, c); }
                    default -> { }
                }
                if (row == 2 && ph == ShowBoard.RESULTS && wave > 0) {               // happy eyes in the front row
                    rect(g, cx - 1, y, 1, 1, 0xFFFFE9A8); rect(g, cx + 1, y, 1, 1, 0xFFFFE9A8);
                }
                if (exc > 0.3 && (id * 7) % 10 < exc * 10) {                         // arms up, with a glow stick
                    int armH = 4 + (int) Math.round((wave + 1) * 1.5);
                    rect(g, cx - r - 1, y - armH, 1, armH, c);
                    rect(g, cx + r + 1, y - armH + 1, 1, armH - 1, c);
                    if ((id + ticks / 5) % 3 != 0) rect(g, cx - r - 1, y - armH - 1, 1, 2, CONFETTI[id % CONFETTI.length]);
                    if (id % 2 == 0) rect(g, cx + r + 1, y - armH, 1, 2, CONFETTI[(id + 2) % CONFETTI.length]);
                }
            }
        }
        if (ph == ShowBoard.OPEN || ph == ShowBoard.RESULTS) {                       // phone lights and camera flashes
            for (int i = 0; i < 6; i++) {
                if ((ticks / 4 + i * 5) % 17 != 0) continue;
                rect(g, 30 + (i * 47 + ticks / 17 * 13) % (W - 60), 22 + (i * 11) % 22, 2, 2, 0xFFFFFFFF);
            }
        }
    }

    private void spotlights(GuiGraphics g) {
        // two cones from the top that sweep over the stage (drawn over the wall and the floor)
        for (int k = 0; k < 2; k++) {
            double sweep = Math.sin(ticks / 70.0 + k * 2.4);
            int topX = (int) (90 + k * 120 + sweep * 18), botX = (int) (90 + k * 120 + sweep * 70);
            int col = k == 0 ? 0x16FFE9A8 : 0x16A8D8FF;
            for (int y = WALL_TOP; y < FOOT_Y; y += 2) {
                float p = (y - WALL_TOP) / (float) (FOOT_Y - WALL_TOP);
                int cx = (int) (topX + (botX - topX) * p), hw = 3 + (int) (p * 26);
                rect(g, cx - hw, y, hw * 2, 2, col);
            }
        }
    }

    private void desk(GuiGraphics g) {
        rect(g, 0, DESK_Y, W, 8, 0xFF6B3A22);
        rect(g, 0, DESK_Y, W, 2, 0xFFA8693E);
        rect(g, 0, DESK_Y + 6, W, 2, 0xFF4A2616);
    }

    private void floor(GuiGraphics g) {
        for (int y = FLOOR_Y, row = 0; y < FOOT_Y; y += 6, row++) {
            float p = (y - FLOOR_Y) / (float) (FOOT_Y - FLOOR_Y);
            int base = App.mix(row % 2 == 0 ? 0xA9784A : 0xB4824F, 0xD9A066, p * 0.35F);
            rect(g, 0, y, W, Math.min(6, FOOT_Y - y), base);
            rect(g, 0, y, W, 1, App.mix(base, 0x000000, 0.18F));
            for (int x = (row * 37) % 60; x < W; x += 60) rect(g, x, y, 1, 6, App.mix(base, 0x000000, 0.12F));
        }
        for (int x = 4; x < W; x += 12) {                         // the footlights along the front edge
            boolean on = (x / 12 + ticks / 20) % 3 != 0;
            rect(g, x, FOOT_Y - 3, 5, 3, on ? 0xFFFFE08A : 0xFF8A6A3A);
            if (on) rect(g, x - 1, FOOT_Y - 4, 7, 1, 0x44FFE08A);
        }
    }

    private void curtains(GuiGraphics g, Font f) {
        int wd = 24 + Math.round((W / 2 - 24 + 1) * (1F - curtain));             // each curtain: 24 pixels at the side, half the stage when closed
        for (int side = 0; side < 2; side++) {
            int x0 = side == 0 ? 0 : W - wd;
            rect(g, x0, 0, wd, FOOT_Y, 0xFFA82840);
            for (int i = 0; i * 4 < wd; i++) {
                int fx = x0 + i * 4;
                rect(g, fx, 0, 2, FOOT_Y, 0xFF8E1F36);
                rect(g, fx + 2, 0, 1, FOOT_Y, 0xFFC03A55);
            }
            int edge = side == 0 ? x0 + wd - 2 : x0;
            rect(g, edge, 0, 2, FOOT_Y, GOLD);
            int tx = side == 0 ? x0 + wd - 7 : x0 + 2;                // the tassel
            rect(g, tx, 70, 5, 3, GOLD);
            rect(g, tx + 1, 73, 3, 8, 0xFFE0A93A);
        }
        for (int x = 0; x < W; x += 12) disc(g, x + 6, 3, 6, 0xFFA82840);   // the scalloped valance at the top
        rect(g, 0, 0, W, 3, 0xFFA82840);
        rect(g, 0, 8, W, 1, GOLD);
        if (curtain < 0.15F) {                                     // closed: a sign on the curtains
            String msg = t("cutemod.show.phase.3");
            List<String> lines = new ArrayList<>();
            for (var l : f.getSplitter().splitLines(msg, 130, Style.EMPTY)) lines.add(l.getString());
            int bw = 0;
            for (String l : lines) bw = Math.max(bw, f.width(l));
            bw += 16;
            int bh = lines.size() * 10 + 14, bx = (W - bw) / 2, by = 70 - bh / 2;
            rect(g, bx - 1, by - 1, bw + 2, bh + 2, 0xFF3A2A3A);
            rect(g, bx, by, bw, bh, 0xFFFFF3B0);
            rect(g, bx, by + bh - 2, bw, 2, GOLD);
            star(g, W / 2 - 2, by + 3, (ticks / 15) % 2 == 0 ? GOLD : 0xFFE5486F);
            for (int i = 0; i < lines.size(); i++) Fit.str(g, f, lines.get(i), (W - f.width(lines.get(i))) / 2, by + 10 + i * 10, TEXT, false);
        }
    }

    private void marquee(GuiGraphics g, Font f) {
        int x = 75, w = 150, y = 3, h = 13;
        rect(g, x, y, w, h, 0xFF2A0E3A);
        rect(g, x + 1, y + 1, w - 2, h - 2, 0xFF5A1670);
        for (int i = 0; i < 16; i++) {                            // bulbs that chase around the sign
            boolean on = (i + ticks / 6) % 3 == 0;
            int bx = x + 3 + i * 9;
            rect(g, bx, y, 3, 2, on ? 0xFFFFF3B0 : 0xFFB8862A);
            rect(g, bx, y + h - 2, 3, 2, on ? 0xFFB8862A : 0xFFFFF3B0);
        }
        String s = t("cutemod.show.title");
        Fit.boxC(g, f, s, x + 6, y + 3, (ticks / 15) % 2 == 0 ? 0xFFFFE066 : 0xFFFFFFFF, true, w - 12);
    }

    private void judges(GuiGraphics g, Font f, List<ShowSyncPayload.Entry> pets, int hover) {
        int revealed = cur == null ? 0 : cur.head().judges();
        for (int j = 0; j < ShowJudges.COUNT; j++) {
            int cx = 70 + j * 53;
            int who = who(j);
            ComputerColor color = PetShow.colorOf(ShowJudges.COLOR[who]);
            boolean talking = spkJ == j && spkAge / 3 < spkText.length();
            int hop = flash[j] > 0 ? (int) Math.abs(Math.sin(flash[j] * 0.3) * 5) : talking ? (ticks / 4) % 2 : 0;
            float sc = 0.4F;
            g.pose().pushPose();
            g.pose().translate(cx, DESK_Y + 2, 0);
            g.pose().scale(sc, sc, 1F);
            g.pose().translate(-cx, -(DESK_Y + 2) - hop * 2.5F, 0);
            PetArt.draw(g, color, cx, DESK_Y + 2 - 28, 2, ticks + j * 11, false, false, 2, ShowJudges.HAT[who], "");
            g.pose().popPose();
            // the score card: the stars of the pet under the mouse (or "?" before the judge has spoken)
            boolean spoke = revealed > j;
            int stars = hover >= 0 && hover < pets.size() && spoke ? pets.get(hover).score().stars().get(j) : -1;
            int cy = 40 - hop;
            rect(g, cx - 9, cy, 18, 11, flash[j] > 0 && (ticks / 4) % 2 == 0 ? 0xFFFFF3B0 : 0xFFFFFFFF);
            rect(g, cx - 9, cy + 9, 18, 2, JUDGE_COL[who]);
            String s = !spoke ? "?" : stars < 0 ? "★" : stars + "★";
            Fit.str(g, f, s, cx - f.width(s) / 2, cy + 1, !spoke ? 0xFF8A7AA8 : 0xFFB98A10, false);
            String name = t("cutemod.show.judge." + who);
            Fit.boxC(g, f, name, cx - 22, DESK_Y + 1, 0xFFFFE9C8, false, 44);
        }
    }

    private void podium(GuiGraphics g, Font f, List<ShowSyncPayload.Entry> pets) {
        int[] top = {120, 130, 136}, left = {122, 66, 178};
        for (int i = 0; i < 3; i++) {
            int y = top[i], x = left[i], h = FOOT_Y - 3 - y;
            rect(g, x, y, 56, h, App.mix(MEDAL[i], 0x000000, 0.35F));
            rect(g, x, y, 56, 3, MEDAL[i]);
            rect(g, x, y + 3, 56, 1, App.mix(MEDAL[i], 0xFFFFFF, 0.4F));
            String n = "#" + (i + 1);
            Fit.str(g, f, n, x + 4, y + 6, 0xFFFFFFFF, true);
            if (i < pets.size()) {
                String nm = f.plainSubstrByWidth(pets.get(i).who().name(), 38);
                Fit.str(g, f, nm, x + 52 - f.width(nm), y + 6, 0xFFFFFFFF, false);
            }
        }
    }

    private void pet(GuiGraphics g, Font f, ShowSyncPayload.Entry e, int i, String me, boolean hover, boolean results) {
        int cx = px[i], fl = pf[i];
        float sc = ps[i];
        boolean mine = !e.bot() && e.who().owner().equals(me);
        int rank = e.score().rank();
        if (hover || mine) oval(g, cx, fl + 1, (int) (22 * sc) + 6, 3, mine ? 0x66FFE066 : 0x55FFFFFF);
        oval(g, cx, fl + 1, (int) (20 * sc) + 2, 2, 0x44000000);
        float s = sc * PetArt.scaleOf(e.look().stage());
        int mood = hover || mine || (results && rank >= 1 && rank <= 3) ? 2 : 1;
        int bob = (int) Math.round(Math.sin((ticks + i * 23) / 18.0) * 1.2);
        g.pose().pushPose();
        g.pose().translate(cx, fl, 0);
        g.pose().scale(s, s, 1F);
        g.pose().translate(-cx, -fl, 0);
        PetArt.draw(g, PetShow.colorOf(e.who().color()), cx, fl - 28 + bob, mood, ticks + i * 37, false, false,
                e.look().stage(), e.look().head(), e.look().body());
        g.pose().popPose();
        if (results && rank >= 1 && rank <= 3) {                  // a little crown sparkle over the podium pets
            if ((ticks / 10 + i) % 2 == 0) sparkle(g, cx + 14, fl - (int) (44 * s) - 2);
            return;
        }
        if (results) {                                            // the rest of the stage: just their place
            String n = "#" + rank;
            Fit.str(g, f, n, cx - f.width(n) / 2, fl - (int) (50 * s) - 8, 0xFFE4D8FF, true);
            return;
        }
        // the name and the hearts under the pet
        int nameMax = Math.max(24, Math.min((int) (66 * Math.min(1F, sc + 0.25F)), gap - 6));
        String name = f.plainSubstrByWidth(e.who().name(), nameMax);
        int nameCol = mine ? GOLD : e.bot() ? 0xFFC9D8FF : 0xFFFFFFFF;
        Fit.str(g, f, name, cx - f.width(name) / 2, fl + 3, nameCol, true);
        if (e.who().act() >= 0 && sc >= 0.45F) actIcon(g, cx + f.width(name) / 2 + 3, fl + 3, e.who().act(), 0xFFFFE9A8, 1);
        String likes = Integer.toString(e.likes());
        int sum = 0;
        for (int v : e.score().stars()) sum += v;
        String st = sum > 0 ? "  ★" + sum : "";
        int w = 8 + f.width(likes) + f.width(st);
        int x0 = cx - w / 2;
        PetShow.heart(g, x0, fl + 13, e.liked() ? 0xFFFF5C7C : 0xFFE4D8FF);
        Fit.str(g, f, likes, x0 + 9, fl + 12, e.liked() ? 0xFFFF9CB0 : 0xFFFFFFFF, true);
        if (!st.isEmpty()) Fit.str(g, f, st, x0 + 9 + f.width(likes), fl + 12, 0xFFFFE066, true);
        if (e.who().flowers() > 0 || (cur != null && !e.bot() && e.who().owner().equals(cur.me().flowerTo()))) {   // golden flowers from the audience
            String fn = Integer.toString(e.who().flowers());
            int fx = x0 + w + 3;
            flowerIcon(g, fx, fl + 12, !e.bot() && e.who().owner().equals(cur.me().flowerTo()));
            Fit.str(g, f, fn, fx + 7, fl + 12, 0xFFFFE066, true);
        }
    }

    /** A 5 x 5 golden flower (brighter when it is the one you gave). */
    private static void flowerIcon(GuiGraphics g, int x, int y, boolean mine) {
        int c = mine ? 0xFFFFF3B0 : 0xFFFFD84D;
        rect(g, x + 2, y, 1, 1, c); rect(g, x, y + 2, 1, 1, c); rect(g, x + 4, y + 2, 1, 1, c); rect(g, x + 2, y + 4, 1, 1, c);
        rect(g, x + 1, y + 1, 3, 3, c);
        rect(g, x + 2, y + 2, 1, 1, 0xFFE5486F);
    }

    /** A little picture of an act (about 7 x 8 pixels, doubled with scale 2): 0 song, 1 dance, 2 magic, 3 acrobatics. */
    private static void actIcon(GuiGraphics g, int x, int y, int act, int c, int scale) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1F);
        switch (act) {
            case 0 -> { rect(g, 4, 0, 1, 6, c); rect(g, 4, 0, 3, 1, c); rect(g, 1, 5, 4, 3, c); }               // a note
            case 1 -> { rect(g, 3, 0, 1, 1, c); rect(g, 2, 1, 3, 1, c); rect(g, 1, 2, 5, 1, c); rect(g, 2, 3, 3, 1, c); rect(g, 3, 4, 1, 1, c); rect(g, 1, 6, 2, 1, c); rect(g, 4, 6, 2, 1, c); }   // a spinning star and feet
            case 2 -> { rect(g, 0, 7, 1, 1, c); rect(g, 1, 6, 1, 1, c); rect(g, 2, 5, 1, 1, c); rect(g, 3, 4, 1, 1, c); rect(g, 5, 0, 1, 3, c); rect(g, 4, 1, 3, 1, c); rect(g, 6, 4, 1, 1, c); }                // a wand with a spark
            default -> { rect(g, 2, 0, 3, 1, c); rect(g, 1, 1, 1, 1, c); rect(g, 5, 1, 1, 1, c); rect(g, 0, 2, 1, 3, c); rect(g, 6, 2, 1, 3, c); rect(g, 1, 5, 1, 1, c); rect(g, 5, 5, 1, 1, c); rect(g, 2, 6, 3, 1, c); rect(g, 3, 7, 1, 1, c); }   // a hoop to jump through
        }
        g.pose().popPose();
    }

    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(1.0 - (dy * dy) / (double) (ry * ry + 1)));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /** A 5 x 5 pixel star. */
    private static void star(GuiGraphics g, int x, int y, int argb) {
        rect(g, x + 2, y, 1, 1, argb);
        rect(g, x + 1, y + 1, 3, 1, argb);
        rect(g, x, y + 2, 5, 1, argb);
        rect(g, x + 1, y + 3, 3, 1, argb);
        rect(g, x + 1, y + 4, 1, 1, argb);
        rect(g, x + 3, y + 4, 1, 1, argb);
    }

    private static void sparkle(GuiGraphics g, int x, int y) {
        rect(g, x - 2, y, 5, 1, 0xFFFFF3B0);
        rect(g, x, y - 2, 1, 5, 0xFFFFF3B0);
    }

    private void winnerBanner(GuiGraphics g, Font f, ShowSyncPayload.Entry w) {
        String s = t("cutemod.show.winner.banner", w.who().name());
        int bw = f.width(s) + 16, x = (W - bw) / 2, y = 17 + (bannerT > 560 ? (bannerT - 560) / 2 : 0);
        rect(g, x - 1, y - 1, bw + 2, 13, 0xFF3A2A3A);
        rect(g, x, y, bw, 11, 0xFFFFF3B0);
        rect(g, x, y + 9, bw, 2, GOLD);
        Fit.str(g, f, s, x + 8, y + 2, TEXT, false);
    }

    // ---------- the Hall of Fame ----------
    private void hallButton(GuiGraphics g, Font f, int mx, int my) {
        boolean hov = App.in(mx, my, HALL_X, HALL_Y, 26, 24);
        rect(g, HALL_X, HALL_Y, 26, 24, hov ? 0xDD5A1670 : 0xAA2A0E3A);
        rect(g, HALL_X, HALL_Y + 23, 26, 1, GOLD);
        PetShow.cup(g, HALL_X + 8, HALL_Y + 3, GOLD);
        String l = t("cutemod.show.hall.btn");
        Fit.boxC(g, f, l, HALL_X + 1, HALL_Y + 14, 0xFFFFE9A8, false, 24);
    }

    private static String ago(long ms) {
        long min = ms / 60_000L;
        if (min < 1) return t("cutemod.show.ago.now");
        if (min < 60) return t("cutemod.show.ago.min", min);
        if (min < 1440) return t("cutemod.show.ago.hour", min / 60);
        return t("cutemod.show.ago.day", min / 1440);
    }

    /** Your cups, your title and the last winners of the show. */
    private void hallPanel(GuiGraphics g, Font f) {
        rect(g, 0, 0, W, FOOT_Y, 0xFF120824);       // opaque: the stage (names, the sign) must not show through
        int x = 34, y = 8, w = 232, h = 142;
        rect(g, x - 1, y - 1, w + 2, h + 2, GOLD);
        rect(g, x, y, w, h, 0xFF2A1450);
        String title = t("cutemod.show.hall.title");
        Fit.str(g, f, title, x + (w - f.width(title)) / 2, y + 4, GOLD, true);
        ShowSyncPayload.Fame fame = cur == null ? null : cur.fame();
        int gold = fame == null ? 0 : fame.gold();
        int[] n = fame == null ? new int[3] : new int[]{fame.gold(), fame.silver(), fame.bronze()};
        for (int i = 0; i < 3; i++) {
            int cx = x + 44 + i * 56;
            PetShow.cup(g, cx, y + 15, MEDAL[i]);
            Fit.str(g, f, "x" + n[i], cx + 15, y + 20, 0xFFFFFFFF, false);
        }
        int lvl = ShowBoard.titleLevel(gold);
        String ti = lvl > 0 ? t("cutemod.show.hall.titleline", t("cutemod.show.rank." + lvl)) : t("cutemod.show.hall.notitle");
        String lau = gold >= ShowBoard.OUTFIT_GOLD ? t("cutemod.show.hall.laurel_done") : t("cutemod.show.hall.laurel", gold, ShowBoard.OUTFIT_GOLD);
        Fit.boxC(g, f, ti + " · " + lau, x + 4, y + 36, 0xFFE4D8FF, false, w - 8);
        rect(g, x + 6, y + 47, w - 12, 1, 0x66F3C45A);
        List<ShowSyncPayload.Winner> list = fame == null ? List.of() : fame.hall();
        if (list.isEmpty()) {
            String e = t("cutemod.show.hall.empty");
            Fit.str(g, f, e, x + (w - f.width(e)) / 2, y + 80, 0xFFB8A8D8, false);
            return;
        }
        String me = Minecraft.getInstance().getUser().getName();
        long now = System.currentTimeMillis();
        for (int i = 0; i < list.size() && i < ShowBoard.HALL_SIZE; i++) {
            ShowSyncPayload.Winner wn = list.get(i);
            int ry = y + 51 + i * 9;
            int col = !wn.bot() && wn.name().equals(me) ? GOLD : 0xFFFFFFFF;
            disc(g, x + 10, ry + 4, 3, PetShow.colorOf(wn.color()).bodyColor | 0xFF000000);
            String nm = wn.name() + (wn.bot() ? " " + t("cutemod.show.hall.guest") : "");
            Fit.box(g, f, nm, x + 18, ry, col, false, 112);
            Fit.str(g, f, wn.total() + "★", x + 138, ry, 0xFFFFE066, false);
            String ago = ago(now - (wn.round() + 1) * ShowBoard.ROUND_MS);
            Fit.str(g, f, ago, x + w - 6 - f.width(ago), ry, 0xFFB8A8D8, false);
        }
    }

    private void tooltip(GuiGraphics g, Font f, ShowSyncPayload.Entry e, int mx, int my) {
        List<String> lines = new ArrayList<>();
        lines.add(e.who().name() + ": " + t("cutemod.pet.name." + e.who().color()) + ", " + t("cutemod.pet.trait." + e.look().trait())
                + ", " + t("cutemod.pet.stage." + e.look().stage()));
        StringBuilder sb = new StringBuilder();
        for (int j = 0; j < ShowJudges.COUNT; j++) {
            int v = e.score().stars().get(j);
            if (v > 0) sb.append(sb.length() > 0 ? "  " : "").append(t("cutemod.show.judge." + who(j))).append(' ').append(v).append('★');
        }
        if (sb.length() > 0) lines.add(sb.toString());
        if (e.who().act() >= 0) lines.add(t("cutemod.show.act.line", t("cutemod.show.act." + e.who().act())));
        if (e.bot()) lines.add(t("cutemod.show.guest"));
        else if (flowerMode) lines.add(t("cutemod.show.flower.tip"));
        int lvl = ShowBoard.titleLevel(e.who().gold());
        if (lvl > 0) lines.add("★ " + t("cutemod.show.rank." + lvl));
        int w = 0;
        for (String l : lines) w = Math.max(w, f.width(l));
        w += 8;
        int h = lines.size() * 10 + 4;
        int x = Math.max(2, Math.min(mx + 8, W - w - 2)), y = my + 14 + h < FOOT_Y ? my + 14 : Math.max(2, my - h - 4);
        rect(g, x, y, w, h, 0xEE3A2A3A);
        for (int i = 0; i < lines.size(); i++) Fit.str(g, f, lines.get(i), x + 4, y + 3 + i * 10, i == 0 ? 0xFFFFFFFF : 0xFFFFE066, false);
    }

    // ---------- the bottom bar ----------
    private boolean entered() { return cur != null && cur.me().entered(); }

    private int phase() { return cur == null ? ShowBoard.OPEN : cur.head().phase(); }

    /** A button of the bottom bar. */
    private record Btn(String id, int x, int w, String label, int style) {}

    private boolean spectator() { return cur != null && !entered() && (phase() == ShowBoard.OPEN || phase() == ShowBoard.JUDGING); }

    /** The buttons of the bottom bar for what is going on (the same list is used to draw and to click). */
    private List<Btn> buttons() {
        List<Btn> l = new ArrayList<>();
        boolean open = phase() == ShowBoard.OPEN && cur != null;
        int x = 4;
        if (room) {
            if (open) { l.add(new Btn("perform", x, 78, t(entered() ? "cutemod.show.btn.update" : "cutemod.show.btn.perform"), 1)); }
            l.add(new Btn("close", W - 46, 42, t("cutemod.show.btn.close"), 0));
            return l;
        }
        if (open && entered()) {
            l.add(new Btn("refresh", x, 54, t("cutemod.show.btn.refresh"), 0)); x += 57;
            l.add(new Btn("act", x, 32, t("cutemod.show.btn.act"), 0)); x += 35;
            l.add(new Btn("leave", x, 34, armed == 1 ? t("cutemod.show.btn.sure") : t("cutemod.show.btn.leave"), armed == 1 ? 3 : 0)); x += 37;
        } else if (open) {
            l.add(new Btn("enter", x, 74, t("cutemod.show.btn.enter"), 1)); x += 77;
        } else {
            l.add(new Btn("act", x, 64, t("cutemod.show.btn.rehearse"), 0)); x += 67;
        }
        if (spectator()) {                                                     // the audience: one golden flower a round
            boolean given = !cur.me().flowerTo().isEmpty();
            l.add(new Btn("flower", x, 46, flowerMode ? t("cutemod.show.btn.pick") : given ? t("cutemod.show.btn.flowered") : t("cutemod.show.btn.flower"), flowerMode ? 1 : 0)); x += 49;
        }
        l.add(new Btn("back", W - 46, 42, t("cutemod.show.btn.back"), 0));
        return l;
    }

    private void footer(GuiGraphics g, Font f, int mx, int my) {
        rect(g, 0, FOOT_Y, W, H - FOOT_Y, 0xFF2A1450);
        rect(g, 0, FOOT_Y, W, 1, GOLD);
        int end = 4;
        for (Btn b : buttons()) {
            button(g, f, mx, my, b.x(), b.w(), b.label(), b.style());
            if (b.x() < W - 50) end = Math.max(end, b.x() + b.w());
        }
        // the clock / your result in the middle (only if there is room for it)
        String mid;
        int col = 0xFFE4D8FF;
        if (cur != null && phase() == ShowBoard.RESULTS && cur.me().rank() > 0) {
            int prize = cur.me().prize();
            mid = prize > 0 ? t("cutemod.show.you", cur.me().rank(), prize)
                    : prize == 0 ? t("cutemod.show.you_limit", cur.me().rank()) : t("cutemod.show.you_place", cur.me().rank());
            col = cur.me().rank() == 1 ? GOLD : 0xFFE4D8FF;
        } else {
            int s = leftSec();
            mid = t("cutemod.show.foot." + phase(), s / 60 + ":" + (s % 60 < 10 ? "0" : "") + s % 60);   // a short line: it has to fit between the buttons
        }
        int maxW = W - 50 - end - 8;
        if (maxW >= 60) Fit.boxC(g, f, mid, end + 4 + maxW / 2, FOOT_Y + 3, col, false, maxW);
    }

    // ---------- the act room ----------
    private static final int RX = 6, RY = 18, RW = 288, RH = 132, CARD_W = 66, CARD_H = 84, CARD_GAP = 4;

    private static int cardX(int k) { return RX + 10 + k * (CARD_W + CARD_GAP); }

    private void roomPanel(GuiGraphics g, Font f, int mx, int my) {
        rect(g, RX - 1, RY - 1, RW + 2, RH + 2, 0xFF3A2A3A);
        rect(g, RX, RY, RW, RH, 0xF0241046);
        rect(g, RX, RY, RW, 1, GOLD);
        Fit.box(g, f, t("cutemod.show.room.title"), RX + 8, RY + 4, 0xFFFFE9A8, false, 100);
        String cost = t("cutemod.show.room.cost", Show.REHEARSAL_COST);
        Fit.boxC(g, f, cost, RX + 112, RY + 4, 0xFFB8A8D8, false, RW - 120);
        int best = cur != null && phase() != ShowBoard.IDLE ? ShowJudges.bestActFor(cur.head().theme()) : -1;
        for (int k = 0; k < Show.ACTS; k++) {
            int cx = cardX(k), cy = RY + 16;
            boolean sel = Show.act() == k;
            boolean hov = App.in(mx, my, cx, cy, CARD_W, CARD_H - 22);
            rect(g, cx - 1, cy - 1, CARD_W + 2, CARD_H + 2, sel ? GOLD : 0xFF5A3A8A);
            rect(g, cx, cy, CARD_W, CARD_H, sel ? 0xFF4A2A7A : hov ? 0xFF3E2670 : 0xFF321C5E);
            actIcon(g, cx + CARD_W / 2 - 7, cy + 6, k, sel ? 0xFFFFE9A8 : 0xFFFFFFFF, 2);
            String nm = t("cutemod.show.act." + k);
            Fit.boxC(g, f, nm, cx + CARD_W / 2, cy + 26, 0xFFFFFFFF, false, CARD_W - 4);
            Fit.boxC(g, f, t("cutemod.show.act.fan." + k), cx + CARD_W / 2, cy + 37, 0xFFB8A8D8, false, CARD_W - 4);
            int sk = Show.skill(k);
            for (int p = 0; p < ShowJudges.MAX_SKILL; p++) {                          // three pips: how well it is rehearsed
                int col = p < sk ? GOLD : 0xFF5A3A8A;
                rect(g, cx + CARD_W / 2 - 14 + p * 10, cy + 49, 8, 5, col);
            }
            if (k == best) {                                                         // the act of tonight
                String tag = t("cutemod.show.act.tonight");
                int tw = Math.min(CARD_W - 4, f.width(tag) + 4);
                rect(g, cx + CARD_W - tw - 1, cy + 2, tw, 9, 0xFFE5486F);
                Fit.boxC(g, f, tag, cx + CARD_W - tw + 1, cy + 3, 0xFFFFFFFF, false, tw - 4);
            }
            // the rehearsal button
            int wait = Show.rehearsalWait(k);
            boolean master = sk >= ShowJudges.MAX_SKILL;
            boolean can = !master && wait == 0 && Progress.coins() >= Show.REHEARSAL_COST;
            String lab = master ? t("cutemod.show.act.master") : wait > 0 ? t("cutemod.show.act.wait", wait) : t("cutemod.show.act.rehearse");
            boolean bh = can && App.in(mx, my, cx + 8, cy + CARD_H - 19, CARD_W - 16, 12);
            rect(g, cx + 8, cy + CARD_H - 19, CARD_W - 16, 12, !can ? 0xFF4A3A66 : bh ? 0xFF9A6FD0 : ACCENT);
            Fit.boxC(g, f, lab, cx + 10, cy + CARD_H - 16, can ? 0xFFFFFFFF : 0xFF8A7AA8, false, CARD_W - 20);
        }
        // the task of the day
        int ty = RY + RH - 25;
        rect(g, RX + 8, ty - 2, RW - 16, 1, 0xFF5A3A8A);
        String task = t("cutemod.show.daily." + Show.dailyKind(), t("cutemod.show.act." + Show.dailyAct()));
        boolean done = Show.dailyDone();
        Fit.str(g, f, t("cutemod.show.daily.title"), RX + 8, ty + 2, 0xFFFFE9A8, false);
        Fit.box(g, f, task, RX + 8, ty + 12, done ? 0xFF8FD39A : 0xFFFFFFFF, false, RW - 70);
        String rw = done ? t("cutemod.show.daily.done") : "+" + Show.DAILY_REWARD;
        int rwx = RX + RW - 10 - f.width(rw);
        Fit.str(g, f, rw, rwx, ty + 12, done ? 0xFF8FD39A : GOLD, false);
        if (!done) Progress.drawCoin(g, rwx - 9, ty + 12);
    }

    private boolean roomClick(int x, int y) {
        for (int k = 0; k < Show.ACTS; k++) {
            int cx = cardX(k), cy = RY + 16;
            if (App.in(x, y, cx + 8, cy + CARD_H - 19, CARD_W - 16, 12)) {
                int r = Show.rehearse(k);
                say(r == 0 ? "cutemod.show.msg.rehearsed" : r == 1 ? "cutemod.show.msg.rest" : r == 2 ? "cutemod.show.msg.poor" : "cutemod.show.msg.master");
                if (r == 0) Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 1.0F + 0.25F * k, 0.6F);
                return true;
            }
            if (App.in(x, y, cx, cy, CARD_W, CARD_H)) { Show.setAct(k); return true; }
        }
        if (!App.in(x, y, RX, RY, RW, RH)) room = false;                 // a click outside closes the room
        return true;
    }

    /** style 0 normal, 1 the main action, 2 dimmed, 3 a red "are you sure". */
    private void button(GuiGraphics g, Font f, int mx, int my, int x, int w, String label, int style) {
        boolean hov = style != 2 && App.in(mx, my, x, FOOT_Y + 1, w, FOOT_H - 1);
        int bg = style == 1 ? (hov ? 0xFF9A6FD0 : ACCENT) : style == 2 ? 0xFF4A3A66 : style == 3 ? 0xFFE5486F : hov ? 0xFFE4D8FF : 0xFFFFFFFF;
        rect(g, x, FOOT_Y + 2, w, FOOT_H - 3, bg);
        rect(g, x, FOOT_Y + FOOT_H - 3, w, 1, 0x33000000);
        int fg = style == 1 || style == 3 ? 0xFFFFFFFF : style == 2 ? 0xFF8A7AA8 : TEXT;
        Fit.boxC(g, f, label, x + 2, FOOT_Y + 4, fg, false, w - 4);
    }

    // ---------- input ----------
    boolean click(int x, int y) {
        if (y >= FOOT_Y) {
            for (Btn b : buttons()) {
                if (!App.in(x, y, b.x(), FOOT_Y, b.w(), FOOT_H)) continue;
                switch (b.id()) {
                    case "back" -> back.run();
                    case "close" -> room = false;
                    case "enter", "act" -> { room = true; flowerMode = false; }
                    case "perform" -> { exhibit(); room = false; }
                    case "refresh" -> exhibit();
                    case "leave" -> {                                                 // leaving loses the likes: ask twice
                        if (armed != 1) { armed = 1; armT = 180; return true; }
                        armed = 0;
                        pending = "take";
                        Show.withdraw(myColor);
                        timer = 100;
                    }
                    case "flower" -> {
                        if (!cur.me().flowerTo().isEmpty()) say("cutemod.show.msg.used");
                        else { flowerMode = !flowerMode; if (flowerMode) say("cutemod.show.msg.pickflower"); }
                    }
                    default -> { }
                }
                return true;
            }
            return true;
        }
        if (room) return roomClick(x, y);
        if (hall) { hall = false; return true; }                       // any click closes the Hall of Fame
        if (App.in(x, y, HALL_X, HALL_Y, 26, 24)) { hall = true; return true; }
        for (int j = 0; j < ShowJudges.COUNT; j++) {
            if (App.in(x, y, 70 + j * 53 - 14, 24, 28, 32)) {
                if (spkJ >= 0) spkJ = -1; else speakIdle(j);
                return true;
            }
        }
        if (cur == null) return true;
        int i = petAt(x, y);
        if (i < 0 || i >= cur.pets().size()) return true;
        if (phase() == ShowBoard.RESULTS) return true;
        ShowSyncPayload.Entry e = cur.pets().get(i);
        if (e.bot()) { say("cutemod.show.msg.guest"); return true; }
        if (e.who().owner().equals(myId())) { say("cutemod.show.msg.own"); return true; }
        pending = flowerMode ? "flower" : "like";
        if (flowerMode) { Show.flower(e.who().owner(), e.who().color()); flowerMode = false; }
        else if (e.liked()) Show.unlike(e.who().owner(), e.who().color()); else Show.like(e.who().owner(), e.who().color());
        timer = 100;
        return true;
    }

    private void exhibit() {
        pending = "put";
        if (!Show.exhibit(myColor)) { pending = ""; say("cutemod.show.msg.nopet"); }
        timer = 100;
    }

    boolean key(int keyCode) {
        if (keyCode == 256) { if (room) { room = false; return true; } if (flowerMode) { flowerMode = false; return true; } if (hall) { hall = false; return true; } back.run(); return true; }       // escape leaves the stage, not the computer
        return false;
    }
}
