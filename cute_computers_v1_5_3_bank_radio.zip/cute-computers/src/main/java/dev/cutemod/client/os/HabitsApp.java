package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Habits: a small list of things you want to do every day (drink water, read, tidy up...). Type one and press Enter or
 * "Add"; tick it when it is done. Each tick is 1 coin, all of them done is 3 more; a habit keeps its streak of days.
 * Five habits at most, so the coins stay small. Saved as "habits" (name, streak, last day done).
 */
public class HabitsApp extends KitApp {
    private static final int MAX = 5, NAME = 22;
    private static final int[] BAR = {0xFFFF9AB8, 0xFFFFC86A, 0xFF9AD88A, 0xFF8AC8F0, 0xFFC8A0F0};

    private record Habit(String name, int streak, int lastDay) {}

    private final List<Habit> list = new ArrayList<>();
    private final StringBuilder input = new StringBuilder();
    private boolean loaded, typing;

    @Override protected int accent() { return 0xFF5BBF9A; }

    @Override protected String id() { return "habits"; }

    @Override
    public void attach(Shell shell) { super.attach(shell); load(); }

    private void load() {
        loaded = true;
        list.clear();
        String s = Store.read("habits");
        if (s == null || s.isBlank()) return;
        for (String row : s.split("\\|")) {
            try {
                String[] p = row.split(";");
                if (p.length == 3 && !p[0].isBlank() && list.size() < MAX) list.add(new Habit(clean(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2])));
            } catch (NumberFormatException ignored) { }
        }
    }

    private static String clean(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) if (c >= 32 && c != ';' && c != '|' && c != 127 && b.length() < NAME) b.append(c);
        return b.toString().trim();
    }

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (Habit h : list) sb.append(sb.length() == 0 ? "" : "|").append(h.name()).append(';').append(h.streak()).append(';').append(h.lastDay());
        Store.write("habits", sb.length() == 0 ? "" : sb.toString());
    }

    private boolean done(Habit h) { return h.lastDay() == today(); }

    /** Streak that is still alive (done today or yesterday). */
    private int alive(Habit h) { return h.lastDay() >= today() - 1 ? h.streak() : 0; }

    private void check(int i) {
        Habit h = list.get(i);
        if (done(h)) { say("cutemod.habits.msg.already"); return; }
        int streak = h.lastDay() == today() - 1 ? h.streak() + 1 : 1;
        list.set(i, new Habit(h.name(), streak, today()));
        int pay = 1;
        boolean all = true;
        for (Habit o : list) if (!done(o)) all = false;
        if (all && list.size() >= 2) pay += 3;
        int left = 8 - paidToday("habits");
        pay = Math.min(pay, Math.max(0, left));
        if (pay > 0) { Progress.earn(pay); addPaid("habits", pay); }
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.4F + Math.min(streak, 7) * 0.08F, 0.5F);
        say(all && list.size() >= 2 ? "cutemod.habits.msg.all" : "cutemod.habits.msg.done", pay);
        save();
    }

    private void add() {
        String n = clean(input.toString());
        if (n.isEmpty()) return;
        if (list.size() >= MAX) { say("cutemod.habits.msg.full", MAX); return; }
        list.add(new Habit(n, 0, 0));
        input.setLength(0);
        save();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        header(g, f);
        int dn = 0;
        for (Habit h : list) if (done(h)) dn++;
        String top = t("cutemod.habits.today", dn, list.size());
        CuteFont.draw(g, f, top, W - 6 - f.width(top), 3, 0xFFFFFFFF, false);
        if (list.isEmpty()) center(g, f, t("cutemod.habits.empty"), W / 2, 52, MUTED);
        for (int i = 0; i < list.size(); i++) {
            Habit h = list.get(i);
            int y = 20 + i * 18;
            boolean d = done(h), hov = in(mx, my, 8, y, W - 16, 16);
            rect(g, 8, y, W - 16, 16, d ? 0xFFE6F6E4 : hov ? 0xFFFFFFFF : 0xFFF6F0FA);
            rect(g, 8, y, 3, 16, BAR[i % BAR.length]);
            rect(g, 16, y + 3, 10, 10, d ? 0xFF5BBF6A : 0xFFFFFFFF);
            rect(g, 16, y + 3, 10, 1, 0xFFB9A8C8); rect(g, 16, y + 12, 10, 1, 0xFFB9A8C8); rect(g, 16, y + 3, 1, 10, 0xFFB9A8C8); rect(g, 25, y + 3, 1, 10, 0xFFB9A8C8);
            if (d) { rect(g, 18, y + 7, 2, 3, 0xFFFFFFFF); rect(g, 20, y + 8, 4, 2, 0xFFFFFFFF); rect(g, 22, y + 6, 2, 2, 0xFFFFFFFF); }
            CuteFont.draw(g, f, f.plainSubstrByWidth(h.name(), 160), 32, y + 4, d ? MUTED : TEXT, false);
            String st = alive(h) > 0 ? t("cutemod.habits.streak", alive(h)) : "";
            CuteFont.draw(g, f, st, W - 28 - f.width(st), y + 4, 0xFFE08A20, false);
            CuteFont.draw(g, f, "x", W - 20, y + 4, hov && in(mx, my, W - 24, y, 16, 16) ? 0xFFE5486F : 0xFFB8A8D8, false);
        }
        // the input line
        int iy = 118;
        rect(g, 8, iy, 200, 16, typing ? 0xFFFFFFFF : 0xFFF6F0FA);
        rect(g, 8, iy + 14, 200, 2, typing ? accent() : 0xFFB9A8C8);
        String shown = input.length() == 0 && !typing ? t("cutemod.habits.hint") : input + (typing && ticks / 20 % 2 == 0 ? "_" : "");
        CuteFont.draw(g, f, f.plainSubstrByWidth(shown, 192), 12, iy + 4, input.length() == 0 && !typing ? 0xFFB8A8D8 : TEXT, false);
        btn(g, f, mx, my, 212, iy, 80, t("cutemod.habits.add"), input.length() > 0 ? 1 : 2);
        CuteFont.draw(g, f, t("cutemod.habits.today.coins", paidToday("habits")), 8, 142, MUTED, false);
        footer(g, f);
    }

    @Override
    public boolean click(int x, int y, int button) {
        typing = in(x, y, 8, 118, 200, 16);
        if (typing) return true;
        if (in(x, y, 212, 118, 80, 16)) { add(); return true; }
        for (int i = 0; i < list.size(); i++) {
            int ry = 20 + i * 18;
            if (in(x, y, W - 24, ry, 16, 16)) { list.remove(i); save(); return true; }
            if (in(x, y, 8, ry, W - 32, 16)) { check(i); return true; }
        }
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        if (!typing || c < 32 || c == 127 || input.length() >= NAME) return false;
        input.append(c);
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (!typing) return false;
        if (keyCode == 259 && input.length() > 0) { input.setLength(input.length() - 1); return true; }   // backspace
        if (keyCode == 257 || keyCode == 335) { add(); return true; }                                      // enter
        return keyCode != 256;                                                                             // typing eats the other keys, but not Escape
    }
}
