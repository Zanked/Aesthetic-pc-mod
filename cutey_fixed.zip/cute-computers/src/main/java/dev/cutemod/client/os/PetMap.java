package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.time.LocalTime;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * The map of the pet's town: all the places in one picture ({@link MapArt}). Click a place and the pet walks there.
 * What a place does is decided by {@link PetApp} (the callback {@code go} gets the id of the place, see MapArt.HOME ...);
 * this class only knows what is open, what is locked (it is hidden in a mist, with the hint in the bottom bar) and what
 * the pet is allowed to do right now. It draws nothing that is saved and keeps no state outside the screen.
 */
final class PetMap {
    private static final int W = App.W, H = App.H, HEAD = MapArt.HEAD;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8;
    private static final int NO_APP = -2;

    private final Runnable back;
    private final IntConsumer go;
    private final Supplier<String> blocker;          // "" if the pet can leave on a trip, else a lang key with the reason
    private final IntFunction<String> gate;          // "" if the pet can go to this place (the park, the show), else a lang key with the reason
    private final IntSupplier stage;
    private final Supplier<ComputerColor> color;
    private final int body;

    private int ticks, hover = -1, toastT, pending = -1, waitT;
    private String toast = "";
    // the walk of the pet: from (fx, fy) to (tx, ty) in walkDur ticks
    private double fx, fy, tx, ty;
    private int walkT, walkDur;
    private boolean walking;

    /** {@code at} is the place where the pet stands when the map opens: HOME from the room, or the place it comes back from. */
    PetMap(Runnable back, IntConsumer go, Supplier<String> blocker, IntFunction<String> gate, IntSupplier stage, Supplier<ComputerColor> color, int body, int at) {
        this.back = back;
        this.go = go;
        this.blocker = blocker;
        this.gate = gate;
        this.stage = stage;
        this.color = color;
        this.body = body;
        int place = at >= 0 && at < MapArt.COUNT ? at : MapArt.HOME;
        int[] h = MapArt.POS[place];
        fx = tx = place == MapArt.HOME ? h[0] + 20 : h[0] + (h[0] < 150 ? 15 : -15);      // beside the place, where the walk to it ends
        fy = ty = h[1] + 3;
    }

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    private static boolean night() {
        int h = LocalTime.now().getHour();
        return h >= 21 || h < 6;
    }

    // ---------- what a place is ----------
    /** The trip place that stands behind a map place (11 and up), or -1 for the other places. */
    private static int dest(int id) { return id >= MapArt.AMUSEMENT ? id + 3 : -1; }

    private static String appOf(int id) {
        return switch (id) { case MapArt.FARM -> "farm"; case MapArt.FISHING -> "fishing"; default -> null; };
    }

    /** True for a place that is not on the map yet (the Quiet Place before the first clue). */
    private static boolean hiddenId(int id) { int d = dest(id); return d >= 0 && PlaceUnlock.hidden(d); }

    private static boolean locked(int id) { int d = dest(id); return d >= 0 && !PlaceUnlock.open(d); }

    private static boolean notInstalled(int id) { return false; }   // the farm, the pond and the school are places of the map, not apps to buy

    /** 0 = free to go; otherwise the lang key of what is in the way (a locked place, a young pet, a tired pet). */
    private String why(int id) {
        String gt = gate.apply(id);
        if (!gt.isEmpty()) return gt;
        int d = dest(id);
        if (d < 0) return "";
        if (!PlaceUnlock.open(d)) return "cutemod.trip.lock." + d;
        if (stage.getAsInt() < Trip.NEED[d]) return "cutemod.trip.needs." + Trip.NEED[d];
        return blocker.get();
    }

    private String name(int id) {
        int d = dest(id);
        return d >= 0 ? t("cutemod.trip.dest." + d) : t("cutemod.map.n." + id);
    }

    private String sub(int id) {
        int d = dest(id);
        if (d < 0) {
            String gt = gate.apply(id);
            if (!gt.isEmpty()) return t(gt);
            return notInstalled(id) ? t("cutemod.map.store", Library.program(appOf(id)).price()) : t("cutemod.map.s." + id);
        }
        if (!PlaceUnlock.open(d)) return t("cutemod.trip.lock." + d, PlaceUnlock.progress(d));
        if (stage.getAsInt() < Trip.NEED[d]) return t("cutemod.trip.needs." + Trip.NEED[d]);
        String b = blocker.get();
        if (!b.isEmpty()) return t(b);
        return PlaceUnlock.isEvent(d) && Progress.count("pl_" + d) == 0 ? t("cutemod.map.event") : t("cutemod.trip.takes");
    }

    // ---------- the pointer ----------
    private int at(int mx, int my) {
        int best = -1;
        double bd = 1e9;
        for (int id = 0; id < MapArt.COUNT; id++) {
            if (hiddenId(id)) continue;
            int cx = MapArt.POS[id][0], b = MapArt.POS[id][1];
            int top = id == MapArt.BALLOON ? b - 40 : id == MapArt.AMUSEMENT || id == MapArt.OLD_HOUSE || id == MapArt.SCHOOL ? b - 38 : b - 32;
            if (!App.in(mx, my, cx - 18, top, 37, b + 4 - top)) continue;
            double d = Math.hypot(mx - cx, my - (b - 12));
            if (d < bd) { bd = d; best = id; }
        }
        return best;
    }

    void tick() {
        ticks++;
        if (toastT > 0) toastT--;
        if (walking && ++walkT >= walkDur) { walking = false; waitT = 8; }
        else if (!walking && pending >= 0 && waitT > 0 && --waitT == 0) { int p = pending; pending = -1; go.accept(p); }
        GameMusic.keep("trips", false);                        // the travel tune plays while the map is open
    }

    boolean click(int mx, int my, int button) {
        if (walking || pending >= 0 || button != 0) return true;
        int id = at(mx, my);
        if (id < 0) return true;
        String w = why(id);
        if (!w.isEmpty()) {                                                // a locked place, a young or tired pet: say why
            toast = t(w, dest(id) >= 0 ? PlaceUnlock.progress(dest(id)) : "");
            toastT = 140;
            return true;
        }
        if (id == MapArt.HOME) { back.run(); return true; }
        fx = tx;
        fy = ty;
        tx = MapArt.POS[id][0] + (MapArt.POS[id][0] < 150 ? 15 : -15);
        ty = MapArt.POS[id][1] + 3;
        walkDur = (int) Math.max(14, Math.min(46, Math.hypot(tx - fx, ty - fy) * 0.45));
        walkT = 0;
        walking = true;
        pending = id;
        return true;
    }

    /** The map is the top of CutePet: nothing to go back to (the house on the map leads home). */
    boolean key(int keyCode) { return false; }

    // ---------- the picture ----------
    void render(GuiGraphics g, int mx, int my) {
        Font f = Minecraft.getInstance().font;
        boolean night = night();
        hover = walking || pending >= 0 ? -1 : at(mx, my);
        MapArt.terrain(g, ticks, night);

        // the places, the far ones first so that the near ones cover them
        Integer[] order = new Integer[MapArt.COUNT];
        for (int i = 0; i < order.length; i++) order[i] = i;
        java.util.Arrays.sort(order, (a, b) -> MapArt.POS[a][1] != MapArt.POS[b][1] ? Integer.compare(MapArt.POS[a][1], MapArt.POS[b][1]) : Integer.compare(MapArt.POS[a][0], MapArt.POS[b][0]));
        for (int id : order) {
            if (hiddenId(id)) continue;
            int cx = MapArt.POS[id][0], b = MapArt.POS[id][1];
            int d = dest(id);
            boolean lit = d >= 0 && PlaceUnlock.isEvent(d) && PlaceUnlock.open(d);
            if (id == hover) MapArt.glow(g, cx, b, ticks);
            MapArt.place(g, id, cx, b - (id == hover ? 1 : 0), ticks, night, lit, body);
            if (locked(id)) MapArt.mist(g, cx, b, ticks);
        }
        if (night) {
            g.fill(0, HEAD, W, H, 0x78101840);
            MapArt.lampGlow(g);
            for (int id : new int[]{MapArt.HOME, MapArt.SCHOOL, MapArt.CINEMA, MapArt.OLD_HOUSE, MapArt.STAGE, MapArt.CAMP, MapArt.MARKET})
                if (!locked(id)) MapArt.oval(g, MapArt.POS[id][0], MapArt.POS[id][1] - 2, 17, 6, 0x30FFD070);
        }
        badges(g, f);
        drawPet(g);

        // the header
        Skin.rect(g, 0, 0, W, HEAD, 0xFF5A4A86);
        String title = t("cutemod.map.title");
        Skin.str(g, f, title, W / 2 - f.width(title) / 2, 5, 0xFFFFFFFF, false);
        String clock = String.format("%02d:%02d", LocalTime.now().getHour(), LocalTime.now().getMinute());
        Skin.str(g, f, clock, W - 6 - f.width(clock), 5, 0xFFE4D8FF, false);

        // the name of the place under the pointer, as a small flag over it
        if (hover >= 0) {
            String n = name(hover);
            int bw = f.width(n) + 10, bx = Math.max(2, Math.min(W - bw - 2, MapArt.POS[hover][0] - bw / 2)), by = Math.max(HEAD + 2, MapArt.POS[hover][1] - 46);
            Skin.rect(g, bx, by, bw, 11, 0xF2FFFFFF);
            Skin.rect(g, bx, by + 10, bw, 1, 0xFFD8CCE8);
            Skin.str(g, f, n, bx + 5, by + 2, TEXT, false);
        }
        // the bar at the bottom: what the place is, or what is in the way
        Skin.rect(g, 0, H - 14, W, 14, 0xE63A2A5A);
        String line = toastT > 0 ? toast : hover >= 0 ? name(hover) + "  ·  " + sub(hover) : t("cutemod.map.pick");
        int col = toastT > 0 ? 0xFFFFD0D0 : hover >= 0 ? 0xFFFFFFFF : 0xFFC8B8E8;
        Skin.str(g, f, f.plainSubstrByWidth(line, W - 12), 6, H - 11, col, false);
    }

    /** Little signs over the places: a bouncing star on an event that is on, a coin on an app that is not bought yet. */
    private void badges(GuiGraphics g, Font f) {
        for (int id = 0; id < MapArt.COUNT; id++) {
            if (hiddenId(id)) continue;
            int cx = MapArt.POS[id][0], b = MapArt.POS[id][1], d = dest(id);
            if (d >= 0 && PlaceUnlock.isEvent(d) && PlaceUnlock.open(d) && Progress.count("pl_" + d) == 0) {
                int by = b - 40 - (int) Math.round(Math.abs(Math.sin(ticks / 9.0)) * 3);
                Skin.rect(g, cx - 3, by, 7, 9, 0xFFFFC832); Skin.rect(g, cx - 3, by, 7, 1, 0xFFFFE680);
                Skin.rect(g, cx, by + 2, 1, 3, 0xFF3A2A3A); Skin.rect(g, cx, by + 6, 1, 1, 0xFF3A2A3A);          // an exclamation mark
            } else if (notInstalled(id)) {
                Progress.drawCoin(g, cx + 12, b - 30);
            }
        }
    }

    /** The pet itself, small, on the road; it hops while it walks. */
    private void drawPet(GuiGraphics g) {
        double f = walking ? ease(walkT / (double) walkDur) : 1;
        int x = (int) Math.round(fx + (tx - fx) * f), y = (int) Math.round(fy + (ty - fy) * f);
        int hop = walking ? (int) Math.round(Math.abs(Math.sin(walkT * 0.55)) * 3) : 0;
        int st = stage.getAsInt();
        MapArt.oval(g, x, y, 6, 2, 0x38000000);
        float sc = 0.3F * PetArt.scaleOf(st);
        g.pose().pushPose();
        g.pose().translate(x, y - hop, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-x, -(y - hop), 0);
        PetArt.draw(g, color.get(), x, y - hop - 28, 2, ticks, false, false, st, Progress.equipped(), Progress.equippedBody());
        g.pose().popPose();
    }

    private static double ease(double t) { return t * t * (3 - 2 * t); }
}
