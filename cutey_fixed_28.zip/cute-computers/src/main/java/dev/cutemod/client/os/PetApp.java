package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Tamagotchi: every computer color has its own pet. Feed it, play with it, let it sleep, pet it.
 * The pet is saved to cutemod_pet_&lt;color&gt;.txt and slowly gets hungry even while you are away.
 */
public class PetApp extends App {
    private static final int CX = 150, CY = 96, FLOOR = 124, BTN_Y = 146, BTN_W = 90, BTN_H = 16;
    private static final int[] BTN_X = {6, 105, 204};
    private static final int DARK = 0xFF3A2A3A;

    // treats bought in the shop: {food, fun, energy} given by each one
    private static final String[] TREATS = {"treat_cookie", "treat_fish", "treat_honey", "treat_milk", "treat_cake", "treat_medicine", "treat_berry", "treat_lolly"};
    private static final int[][] EFFECT = {{30, 5, 0}, {50, 0, 0}, {20, 30, 0}, {0, 0, 50}, {40, 40, 0}, {0, 0, 0}, {15, 5, 0}, {0, 20, 0}};
    private static final int SLOT_W = 26, SLOT_H = 13, SLOT_X = W - 8 * 26 - 4, SLOT_Y = 129;

    private double food = 70, fun = 70, energy = 80;
    private boolean sleeping, loaded;
    // who the pet is: chosen once, on the first start (pick a pet, warm the egg, meet it)
    private ComputerColor sp;                     // the species of this computer's pet (null until the player has chosen one)
    private int setup;                            // 0 normal life, 1 choose a pet, 2 the egg, 3 hatching, 4 name + character, 5 rename
    private int chosen = -1, eggTaps, hatchT;
    // names: setup 4 = name and character of a new pet, 5 = the rename form (once a day)
    private final StringBuilder nameBuf = new StringBuilder();
    private int pickTrait = -1, nameNoteT, pickVar;
    private String nameNote = "";
    private static final int NM_X = 124, NM_Y = 40, NM_W = 164, NM_H = 18, OK_X = 214, OK_Y = 146, OK_W = 80, OK_H = 16;
    private int introStep, introT;                // the first meeting: 1 feed, 2 play, 3 pet, 4 the favourite treat (0 = over / an old pet)
    private long awaySec;                         // how long the player was away (for the greeting)
    private static final int CH_X = 10, CH_W = 70, CH_Y = 30, CH_H = 56;    // the 4 x 2 cards of the pets to choose from
    private static final int AD_X = 90, AD_Y = 146, AD_W = 120, AD_H = 16;  // the "Take the egg" button
    private static final int EGG_Y = 92;
    private long ageSec;
    private double ageAcc;
    private int ticks, jump, shake, saveTimer, msgTimer, fearT = 60;
    // how the player treats the pet: these decide its character (saved with the pet)
    private int cFeed, cPlay, cSleep, cPet;
    private double happyAcc;    // seconds spent really happy; every 5 minutes the pet writes a letter
    private int lastStage;
    private static final int GIFTS = 4, GIFT_SEC = 300;
    // illness: a pet that is neglected (or left alone for 2+ hours) falls sick and only a bought medicine cures it
    private boolean sick, lonelySick;
    private double neglect;     // seconds spent in a really bad state
    private static final int NEGLECT_SEC = 90;
    private static final int GB_X = 12, GB_Y = 58, GB_W = 14, GB_H = 14;   // the four buttons are tiny icons now (game, park, map, room)
    private static final int SB_X = 12, SB_Y = 74, SB_W = 50, SB_H = 13;   // the "Show" button: the talent show
    // the apps of the pet (wardrobe, photo, stickers, stats, tic-tac-toe, season) are little shops on the map now, not icons in the room
    private boolean fameAsked;                                            // the shelf of cups asks the server once
    private static final int TB_X = 12, TB_Y = 74, TB_W = 14, TB_H = 14;   // the "Trips" button
    private static final int RB_X = 12, RB_Y = 90, RB_W = 14, RB_H = 14;   // the "Room" button: furniture
    private PetRoom roomUi;                                              // the furniture shop of the room
    private PetPantry pantryUi;                                          // the treat shop of the boulevard (the Pantry on the map)
    private PetTrip tripUi;                                              // not null while the trips screen is on screen
    private App hosted;                                                    // a little app shown inside CutePet (school, farm, a shop...), see host()
    private int hostAt = MapArt.HOME;                                   // the place of the map it was opened from
    private PetMap mapUi;                                                // not null while the town map is on screen
    private PetPlace placeUi;                                            // not null while a place of the map (or its game) is on screen
    private boolean tripFromMap;                                         // the trips list was opened from the map: "back" returns to it
    private int fromMap = -1;                                            // the place of the map (MapArt.PARK ...) the open screen was entered from; -1 = it was opened from home
    private PetPark parkUi;                                              // not null while the park is on screen
    private PetStage showUi;                                             // not null while the talent show is on screen
    // mini-game "where is the treat?": 3 cups, 3 rounds, the pet hides the treat
    // gm: 0 off, 1 treat shown, 2 cups come down, 3 shuffle, 4 you pick, 5 reveal, 6 result
    private int gm, gmTimer, gmRound, gmWins, gmTreat, gmPicked = -1, gmSwapsLeft, gmSwapT, gmSwapDur, gmA, gmB, gmCoins;
    private boolean gmPrize;
    // pet mini-games 2 and 3: gmKind 0 cups, 1 catch the treats, 2 copy the pet
    // gm 7 = the game menu, 8 = catch the treats, 9 = copy the pet (6 = result, shared by all three)
    private int gmKind, gmScore;
    private static final int AX = 104, AW = 188, AY = 44, AG = 118;   // play area of the new games, AG = the ground
    private static final int CATCH_TICKS = 1200;                      // 20 seconds
    private final List<double[]> falls = new ArrayList<>();           // x, y, speed, kind (0-3 treats, 4 = bad one)
    private int ctSpawn;
    private static final int ECHO_ROUNDS = 5, PAD_W = 40, PAD_H = 34, PAD_Y = 76;
    private static final int[] PAD_COL = {0xFFF58FB8, 0xFF8FD3FF, 0xFFFFC832, 0xFF8FD39A};
    private static final float[] PAD_PITCH = {0.9F, 1.1F, 1.35F, 1.65F};
    private final int[] seq = new int[ECHO_ROUNDS + 1];
    private int ecRound, ecShow, ecTimer, ecIn, ecPhase, ecLit = -1, ecLitT, ecBad;
    private final int[] gmSlot = {0, 1, 2};
    private static final int[] CUP_X = {122, 172, 222};
    private static final int CUP_W = 38, CUP_H = 30, CUP_Y = 94, GM_ROUNDS = 3, GM_DAILY = 5;
    private static final int[] CUP_COL = {0xFFF58FB8, 0xFF8FD3FF, 0xFFFFC832};
    private String msg = "";
    private final List<double[]> parts = new ArrayList<>(); // x, y, vx, vy, life, type (0 heart, 1 crumb, 2-4 music note)
    // the pet uses the furniture: it walks to the bed (asleep), the sofa (awake) or the piano (in a good mood)
    private double spotX = CX, spotLift;
    private static final float[] NOTES = {1.0F, 1.122F, 1.26F, 1.498F, 1.682F, 2.0F};
    private final Random rnd = new Random();
    // small talk: 8 lines for every pet, 6 of its own species, then facts and jokes about our world
    private static final int CHAT_FACTS = 30, CHAT_JOKES = 20, CHAT_NAME = 4, CHAT_TOTAL = 8 + 6 + CHAT_FACTS + CHAT_JOKES + CHAT_NAME;
    private final int chatSeed = rnd.nextInt(CHAT_TOTAL);

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        final boolean firstStart = !loaded;
        if (!loaded) {
            loaded = true;
            sp = speciesOf(shell.color());
            if (sp == null) {
                setup = 1;                                                       // the very first start: choose a pet
            } else if (Store.read("pet_" + sp.id) == null) {
                setup = PetName.get(sp.id) == null ? 4 : 2;                      // chosen: name and character first, then the egg
                pickTrait = -1;
                pickVar = PetArt.ownVariant(sp);
                eggTaps = Progress.count("pet_egg_" + shell.color().id);
            } else {
                load(); lastStage = stage(); if (lonelySick) fallSick();
                introStep = Progress.count("pet_intro_" + sp.id);
                if (introStep > 4) introStep = 0;
                welcomeGift();
                greet();
            }
        }
        // CutePet starts on the map of the town (a new pet first meets its owner at home: introStep > 0).
        // Only the first start: coming back from another app (the style, the shop, the school...) leaves the pet where it was, at home or on the map.
        if (firstStart && setup == 0 && sp != null && introStep == 0 && gm == 0 && mapUi == null && parkUi == null && tripUi == null
                && placeUi == null && roomUi == null && pantryUi == null && showUi == null && !Trip.awayFor(species())) openMap();
    }

    // ---------- who the pet is ----------
    private static int mapped(ComputerColor computer) { return Progress.count("pet_sp_" + computer.id); }

    /**
     * The species of the pet that lives on this computer: the one the player chose, or (for the pets of old
     * saves) the color of the computer. Null on the very first start, before the player has chosen.
     */
    public static ComputerColor speciesOf(ComputerColor computer) {
        int m = mapped(computer);
        ComputerColor[] all = ComputerColor.values();
        if (m > 0) return all[Math.min(m, all.length) - 1];
        if (Store.read("pet_" + computer.id) != null) {
            for (ComputerColor x : all) if (x != computer && mapped(x) == computer.ordinal() + 1) return null;  // chosen on another computer
            return computer;
        }
        return null;
    }

    /** A species is taken when a pet of it exists (the file is named by the species) or another computer chose it. */
    private static boolean taken(ComputerColor species, ComputerColor me) {
        if (Store.read("pet_" + species.id) != null) return true;
        for (ComputerColor x : ComputerColor.values()) if (x != me && mapped(x) == species.ordinal() + 1) return true;
        return false;
    }

    private ComputerColor species() { return sp != null ? sp : shell.color(); }

    /** A welcome gift for every player, once: three cookies. */
    private void welcomeGift() {
        if (Progress.count("food_gift") == 0) {
            Progress.setCount("food_gift", 1);
            Progress.setCount("stock_treat_cookie", Progress.stock("treat_cookie") + 3);
            Progress.toast("cutemod.pet.gift_food");
        }
    }

    /** What the pet says when the app is opened: it missed you, or it is morning / evening. */
    private void greet() {
        String k;
        if (awaySec >= 7200) k = "long";
        else if (awaySec >= 1800) k = "back";
        else {
            int h = LocalTime.now().getHour();
            k = h < 5 ? "night" : h < 11 ? "morning" : h < 18 ? "day" : h < 23 ? "evening" : "night";
        }
        say("cutemod.pet.greet." + k);
    }

    @Override
    public Component title() { return hosted != null ? hosted.title() : Component.translatable("cutemod.os.pet"); }

    @Override
    public Component hint() { return hosted != null ? hosted.hint() : Component.translatable("cutemod.os.hint.pet"); }

    @Override
    public Component status() {
        if (hosted != null) return hosted.status();
        Component base = Component.translatable("cutemod.pet.status2", PetName.display(species().id), 1 + ageSec / 600,
                t("cutemod.pet.stage." + stage()), sick ? t("cutemod.pet.sick.label") : t("cutemod.pet.trait." + trait()));
        String title = Show.myTitle();
        return title.isEmpty() ? base : Component.empty().append(base).append(" · " + title);
    }

    // ---------- growing up and character ----------
    /** 0 baby (first 20 minutes with it), 1 teen (up to an hour), 2 grown-up. */
    private int stage() { return PetArt.stageOf(ageSec); }

    /** 0 foodie, 1 playful, 2 sleepy, 3 cuddly, 4 not decided yet (needs about 12 caring actions). */
    private int trait() { return PetArt.traitOf(cFeed, cPlay, cSleep, cPet); }

    // ---------- save / load ----------
    private String blob() { return "pet_" + species().id; }

    private void load() {
        try {
            String s = Store.read(blob());
            if (s == null) return;
            String[] a = s.trim().split("\\s+");
            food = Double.parseDouble(a[0]);
            fun = Double.parseDouble(a[1]);
            energy = Double.parseDouble(a[2]);
            sleeping = a[3].equals("1");
            ageSec = Long.parseLong(a[4]);
            if (a.length >= 10) {
                cFeed = Integer.parseInt(a[6]);
                cPlay = Integer.parseInt(a[7]);
                cSleep = Integer.parseInt(a[8]);
                cPet = Integer.parseInt(a[9]);
            }
            if (a.length >= 12) {
                sick = a[10].equals("1");
                neglect = Integer.parseInt(a[11]);
            }
            long away = Math.min(7200, Math.max(0, (System.currentTimeMillis() - Long.parseLong(a[5])) / 1000));
            awaySec = away;
            if (sleeping) {
                energy = Math.min(100, energy + away * 0.05);
                food = Math.max(10, food - away * 0.01);
                if (energy >= 100) sleeping = false;
            } else {
                food = Math.max(15, food - away * 0.01);
                fun = Math.max(15, fun - away * 0.008);
                energy = Math.max(20, energy - away * 0.005);
            }
            // left alone for two hours or more: it gets lonely and hungry and falls sick (a sleeping, fed pet is fine)
            lonelySick = !sick && away >= 7200 && !(sleeping && food >= 30);
        } catch (Exception ignored) {
        }
    }

    private void save() {
        if (setup != 0 || sp == null) return;
        try {
            Store.write(blob(), String.format(Locale.ROOT, "%.2f %.2f %.2f %d %d %d %d %d %d %d %d %d",
                    food, fun, energy, sleeping ? 1 : 0, ageSec, System.currentTimeMillis(), cFeed, cPlay, cSleep, cPet,
                    sick ? 1 : 0, (int) neglect));
        } catch (Exception ignored) {
        }
    }

    @Override
    public void close() {
        if (hosted != null) { hosted.close(); hosted = null; }
        gm = 0;
        showUi = null;
        if (parkUi != null) { parkUi.close(); parkUi = null; }
        tripUi = null;
        mapUi = null;
        placeUi = null;
        tripFromMap = false;
        fromMap = -1;
        roomUi = null;
        pantryUi = null;
        if (loaded && setup == 0) save();
    }

    /** Why the pet cannot leave on a trip right now ("" if it can): a lang key. */
    private String tripBlocker() {
        if (sleeping) return "cutemod.trip.block.sleep";
        if (sick) return "cutemod.trip.block.sick";
        if (food < 30 || energy < 30) return "cutemod.trip.block.tired";
        return "";
    }

    /** The Pantry: the treats of the pet are sold here (they used to be in CuteMarket). Back returns to the map in front of the shop. */
    private void openPantry() {
        pantryUi = new PetPantry(() -> { pantryUi = null; leavePlace(); }, this::species, this::stage, PetApp::sound);
        sound(1.5F);
    }

    private void openRoom() {
        roomUi = new PetRoom(() -> roomUi = null);
        sound(1.5F);
    }

    private void openTrips() {
        tripUi = new PetTrip(() -> { tripUi = null; if (tripFromMap) { tripFromMap = false; openMap(MapArt.BALLOON); } }, this::startTrip, this::tripBlocker, this::stage);
        sound(1.5F);
    }

    /** The town map: every place of the pet in one picture. The button of the room opens it. */
    private void openMap() { openMap(MapArt.HOME); }

    /** The town map with the pet standing at a place (it comes back to the map where it left it: HOME when it comes from the room). */
    private void openMap(int at) {
        mapUi = new PetMap(() -> mapUi = null, this::mapGo, this::tripBlocker, this::placeGate, this::stage, this::species, species().bodyColor, at, () -> shell.absX(), () -> shell.absY());
        sound(1.5F);
    }

    /** A screen of a place (the park, the show, a place with a game) is left: back on the map at that place, or home if it was opened from home. */
    private void leavePlace() {
        int at = fromMap;
        fromMap = -1;
        if (at >= 0) openMap(at);
    }

    /** Why the pet cannot go to a place of the map right now (a lang key), or "": a sleeping or a sick pet does not go to the park or to the show. */
    private String placeGate(int id) {
        if (id == MapArt.PARK || id == MapArt.STAGE) {
            if (sleeping) return "cutemod.pet.say.zzz";
            if (sick) return "cutemod.pet.say.sick_play";
        }
        return "";
    }

    /** True while the pet is not in its room (on the map, in the park, at the show, in a place, in the shop): nothing of the room goes on then. */
    private boolean elsewhere() {
        return hosted != null || showUi != null || parkUi != null || tripUi != null || mapUi != null || placeUi != null || roomUi != null || pantryUi != null;
    }

    /** A new place of the map, close up: the Play and Trip buttons. Back returns to the map. */
    private void openPlace(int d) {
        mapUi = null;
        placeUi = new PetPlace(d, () -> { placeUi = null; openMap(d - 3); },
                () -> { placeUi = null; startTrip(d); if (!Trip.awayFor(species())) openPlace(d); }, this::funGiven,
                this::species, this::stage, this::tripBlocker, this::gameBlocker, PetApp::sound);
    }

    /** Why the pet cannot play a game right now (a lang key), or "". */
    private String gameBlocker() {
        if (sleeping) return "cutemod.pet.say.zzz";
        if (sick) return "cutemod.pet.say.sick_play";
        if (energy < 15) return "cutemod.pet.say.tired";
        return "";
    }

    /** A game of a place has ended: the coins and what the pet gets (all changes, can be negative). */
    private void funGiven(int coins, int f, int e, int fd) {
        fun = clamp(fun + f);
        energy = clamp(energy + e);
        food = clamp(food + fd);
        cPlay++;
        jump = 60;
        burst(0, 3);
        Progress.onPet("play");
        Progress.bump("games");
        if (coins > 0) Progress.earn(coins);
    }

    /** The pet has walked to a place of the map (the ids are MapArt.HOME ...). */
    private void mapGo(int id) {
        switch (id) {
            case MapArt.SCHOOL -> host(35, MapArt.SCHOOL);
            case MapArt.FARM -> host(17, MapArt.FARM);
            case MapArt.FISHING -> host(18, MapArt.FISHING);
            case MapArt.MARKET -> host(9, MapArt.MARKET);
            case MapArt.PARK -> { mapUi = null; fromMap = MapArt.PARK; openPark(); }
            case MapArt.STAGE -> { mapUi = null; fromMap = MapArt.STAGE; openStage(); }   // the talent show: only from the map
            case MapArt.BALLOON -> { mapUi = null; tripFromMap = true; openTrips(); }
            case MapArt.BOUTIQUE -> host(19, MapArt.BOUTIQUE);                // the boutique of the boulevard is PetStyle: outfits, wardrobe and the shop
            case MapArt.PANTRY -> { mapUi = null; fromMap = MapArt.PANTRY; openPantry(); }   // the pantry: treats for the pet
            case MapArt.WARDROBE -> host(19, MapArt.WARDROBE);                  // the apps of the pet are little shops of the map: PetStyle,
            case MapArt.PHOTO -> host(28, MapArt.PHOTO);                     // photo,
            case MapArt.STICKERS -> host(29, MapArt.STICKERS);                  // stickers,
            case MapArt.PETSTATS -> host(33, MapArt.PETSTATS);                  // the stats of the pet,
            case MapArt.TICTAC -> host(25, MapArt.TICTAC);                    // tic-tac-toe,
            case MapArt.SEASON -> host(21, MapArt.SEASON);                    // and the season
            default -> {                                                // the new places: a game there, or a trip to them
                if (id >= MapArt.AMUSEMENT && id <= MapArt.QUIET) openPlace(id + 3);
            }
        }
    }

    /**
     * Shows a little app inside CutePet: it takes the whole screen, the Back button and Escape bring you back to the map at the
     * place you came from, and the Task Manager shows only CutePet. An app that already runs as a program of its own (or is not
     * installed) is opened the old way.
     */
    private void host(int icon, int at) {
        App a = shell.embed(icon);
        if (a == null) { shell.launch(icon); return; }
        mapUi = null;
        hosted = a;
        hostAt = at;
        a.attach(shell);
        sound(1.6F);
    }

    private void leaveHosted() {
        App a = hosted;
        hosted = null;
        if (a != null) a.close();
        openMap(hostAt);
    }

    @Override
    public void mouse(int x, int y) { if (hosted != null) hosted.mouse(x, y); }

    @Override
    public boolean drag(int x, int y, int button) { return hosted != null ? hosted.drag(x, y, button) : mapUi != null && mapUi.drag(x, y, button); }

    @Override
    public boolean release(int x, int y, int button) { return hosted != null ? hosted.release(x, y, button) : mapUi != null && mapUi.release(x, y, button); }

    @Override
    public boolean background() { return hosted != null && hosted.background(); }

    @Override
    public boolean busy() { return hosted != null && hosted.busy(); }

    /** The pet leaves for 10 minutes. */
    private void startTrip(int dest) {
        if (!tripBlocker().isEmpty()) return;
        food = clamp(food - 5);
        save();
        if (Trip.start(species(), dest, stage())) { tripUi = null; say("cutemod.trip.say.go"); sound(1.8F); }
    }

    /** The room while the pet is away: the place it went to, and when it is back. */
    private void renderAway(GuiGraphics g, int mx, int my) {
        Font f = font();
        int body = shell.color().bodyColor;
        PetScenes.room(g, body | 0xFF000000, false, ticks);
        int d = Trip.dest();
        Skin.rect(g, 89, 11, 122, 78, 0xFFFFFFFF);
        TripArt.scene(g, 91, 13, 118, 74, d, ticks);
        String l1 = t("cutemod.trip.away", t("cutemod.trip.dest." + d));
        Skin.str(g, f, l1, W / 2 - f.width(l1) / 2, 96, DARK, false);
        int left = Trip.secondsLeft();
        String l2 = t("cutemod.trip.back_in", left / 60 + ":" + String.format("%02d", left % 60));
        Skin.str(g, f, l2, W / 2 - f.width(l2) / 2, 108, 0xFFC04A7A, false);
        String l3 = t("cutemod.trip.away_hint");
        Skin.str(g, f, f.plainSubstrByWidth(l3, W - 20), W / 2 - f.width(f.plainSubstrByWidth(l3, W - 20)) / 2, 122, 0xFF8A7AA8, false);
    }

    /** Open the pet park. The pet is saved first, so the server gets how it looks right now. */
    private void openPark() {
        if (sleeping) { say("cutemod.pet.say.zzz"); return; }
        if (sick) { say("cutemod.pet.say.sick_play"); shake = 30; return; }
        save();
        parkUi = new PetPark(species().id, () -> { parkUi = null; leavePlace(); }, this::parkPlayed, this::parkAct);
        parkUi.open();
        sound(1.5F);
    }

    /** Things the pet does in the park on its own: 1 rests on the bench (energy), 2 splashes in the pond (fun), 3 kicks the ball (a little fun), 4 gives a treat to another pet. */
    private void parkAct(int what) {
        switch (what) {
            case 1 -> { energy = clamp(energy + 3); fun = clamp(fun + 0.5); }
            case 2 -> fun = clamp(fun + 3);
            case 4 -> fun = clamp(fun + 5);                         // it gave a treat to another pet
            default -> fun = clamp(fun + 0.8);
        }
    }

    /** The pet played with a friend in the park: it is happier (and a little tired). */
    private void parkPlayed() {
        fun = clamp(fun + 15);
        energy = clamp(energy - 4);
        cPlay++;
        Progress.onPet("play");
    }

    /** Open the talent show. The pet is saved first, so the server gets how it looks right now. */
    private void openStage() {
        save();
        showUi = new PetStage(species().id, () -> { showUi = null; leavePlace(); });
        showUi.open();
        sound(1.5F);
    }

    // ---------- logic ----------
    private static double clamp(double v) { return Math.max(0, Math.min(100, v)); }

    private static void sound(float pitch) {
        Sfx.ui(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_CHIME.value(), pitch, 0.5F);
    }

    private void say(String key) { msg = t(key); msgTimer = 150; }

    /** A ready text; the longer it is, the longer it stays (it types itself, then the player needs time to read). */
    private void sayText(String text) { msg = text; msgTimer = Math.max(150, 3 * text.length() + 170); }

    // ---------- the pet's cute voice: the text types itself and every other letter is a soft little blip ----------
    /** One voice for every colour: pink pig, green frog, white panda, blue mouse, orange fox, purple koala, yellow cat, red bear.
     *  Our own sounds (sounds/voice/<voice>_<0..7>.ogg, made by tools/make_voices.py). */
    private static net.minecraft.sounds.SoundEvent voice(String name) {
        return net.minecraft.sounds.SoundEvent.createVariableRangeEvent(
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(dev.cutemod.CuteMod.MOD_ID, "voice." + name));
    }

    private static final java.util.Map<String, net.minecraft.sounds.SoundEvent> VOICES = java.util.Map.of(
            "pink", voice("kit"), "green", voice("boom"), "white", voice("mei"), "blue", voice("pip"),
            "orange", voice("fox"), "purple", voice("void"), "yellow", voice("honey"), "red", voice("lady"));
    private static final java.util.Map<String, Float> VOICE_VOL = java.util.Map.of(
            "pink", 0.45F, "green", 0.45F, "white", 0.45F, "blue", 0.45F,
            "orange", 0.45F, "purple", 0.65F, "yellow", 0.40F, "red", 0.45F);
    private String spkSeen = "";
    private int spkAge;

    /** Called every tick: starts the typing when a new line appears and plays one blip for every other letter. */
    private void speechTick() {
        String say = bubbleText();
        if (!say.equals(spkSeen)) { spkSeen = say; spkAge = 0; return; }
        spkAge++;
        int shown = spkAge / 3;                                          // about 20 letters a second
        if (say.isEmpty() || sleeping || spkAge % 3 != 0 || shown <= 0 || shown > say.length() || shown % 2 != 0) return;
        char c = say.charAt(shown - 1);
        if (!Character.isLetterOrDigit(c)) return;
        float young = 1.22F - 0.11F * Math.min(2, stage());                 // babies squeak higher
        float pitch = (0.92F + (c % 7) * 0.035F) * young * (sick ? 0.88F : 1F);
        Sfx.ui(VOICES.get(species().id), pitch, VOICE_VOL.get(species().id));
    }

    private void burst(int type, int n) {
        for (int i = 0; i < n; i++) {
            double x = petX() - 15 + rnd.nextInt(30);
            if (type == 0) parts.add(new double[]{x, CY - 24, (rnd.nextDouble() - 0.5) * 0.5, -0.5, 55 + rnd.nextInt(20), 0});
            else parts.add(new double[]{x, CY - 44, (rnd.nextDouble() - 0.5) * 0.2, 0.7, 28, 1});
        }
    }

    /**
     * "Feed" no longer makes food out of thin air: it gives the pet the cheapest food treat from the stock
     * (cookie, fish, honey, cake). With none left the pet asks for some from CuteMarket. A one-time gift of
     * 3 cookies starts every player off.
     */
    private static final int[] FOODS = {0, 1, 2, 4};       // cookie, fish, honey, cake: the treats that feed

    /** The food this pet loves (the effect is doubled) and the one it does not like (half): fixed for a pet colour. */
    private int favourite() { return FOODS[Math.floorMod(species().id.hashCode() * 31 + 7, FOODS.length)]; }

    private int dislike() { return FOODS[(java.util.Arrays.binarySearch(FOODS, favourite()) + 2) % FOODS.length]; }

    private void feed() {
        if (sleeping) { say("cutemod.pet.say.zzz"); return; }
        if (food >= 95) { say("cutemod.pet.say.full"); shake = 30; return; }
        int fav = favourite(), dis = dislike();
        if (Progress.stock(TREATS[fav]) > 0) { giveTreat(fav); return; }                 // the loved one first
        for (int i : FOODS) {
            if (i != dis && Progress.stock(TREATS[i]) > 0) { giveTreat(i); return; }
        }
        if (Progress.stock("treat_berry") > 0) { giveTreat(6); return; }                  // the cheap berry feeds too
        if (Progress.stock(TREATS[dis]) > 0) { giveTreat(dis); return; }
        say("cutemod.pet.say.no_food");
        shake = 30;
    }

    private void play() {
        if (sleeping) { say("cutemod.pet.say.zzz"); return; }
        if (sick) { say("cutemod.pet.say.sick_play"); shake = 30; return; }
        if (energy < 12) { say("cutemod.pet.say.tired"); shake = 30; return; }
        fun = clamp(fun + 25);
        cPlay++;
        energy = clamp(energy - 8);
        food = clamp(food - 4);
        jump = 60;
        burst(0, 3);
        sound(1.7F);
        Progress.onPet("play");
        introAdvance(2);
    }

    private void giveTreat(int i) {
        if (sleeping) { say("cutemod.pet.say.zzz"); return; }
        String id = TREATS[i];
        if (Progress.stock(id) <= 0) { say("cutemod.pet.say.no_treat"); shake = 20; return; }
        if (id.equals("treat_medicine")) { medicine(); return; }
        int[] e = EFFECT[i];
        boolean useful = (e[0] > 0 && food < 98) || (e[1] > 0 && fun < 98) || (e[2] > 0 && energy < 98);
        if (!useful) { say("cutemod.pet.say.full"); shake = 30; return; }
        Progress.useTreat(id);
        cFeed++;
        boolean loved = i == favourite(), hated = i == dislike();
        double mul = loved ? 2.0 : hated ? 0.5 : 1.0;
        food = clamp(food + e[0] * mul);
        fun = clamp(fun + e[1] * mul);
        energy = clamp(energy + e[2]);
        burst(1, 4);
        burst(0, loved ? 6 : 2);
        jump = Math.max(jump, loved ? 50 : 30);
        sound(loved ? 2.0F : hated ? 1.0F : 1.8F);
        say(loved ? "cutemod.pet.say.love_it" : hated ? "cutemod.pet.say.dislike_it" : "cutemod.pet.say.yum");
        Progress.bump("treats_used");
        Progress.onPet("feed");
        introAdvance(1);
        if (loved) introAdvance(4);
    }

    /** The pet gets sick. The very first time the vet leaves one free dose so nobody is stuck without coins. */
    private void fallSick() {
        if (sick) return;
        sick = true;
        lonelySick = false;
        neglect = 0;
        Progress.bump("pet_sick");
        boolean free = Progress.count("pet_free_med") == 0;
        if (free) {
            Progress.setCount("pet_free_med", 1);
            Progress.setCount("stock_treat_medicine", Progress.stock("treat_medicine") + 1);
        }
        say(free ? "cutemod.pet.say.fell_sick_free" : "cutemod.pet.say.fell_sick");
        shake = 40;
        sound(0.5F);
    }

    private void medicine() {
        if (!sick) { say("cutemod.pet.say.healthy"); shake = 20; return; } // not used up
        Progress.useTreat("treat_medicine");
        sick = false;
        neglect = 0;
        fun = Math.max(fun, 40);
        burst(0, 6);
        jump = 50;
        sound(1.9F);
        say("cutemod.pet.say.cured");
        Progress.bump("pet_cured");
    }

    /** A small (10 x 10) picture of a treat; also used by the shop. */
    public static void drawTreat(GuiGraphics g, String id, int x, int y) {
        switch (id) {
            case "treat_cookie" -> {
                Skin.disc(g, x + 5, y + 5, 5, 0xFFC98B5A);
                Skin.rect(g, x + 3, y + 3, 2, 2, 0xFF5A3A28);
                Skin.rect(g, x + 6, y + 5, 2, 2, 0xFF5A3A28);
                Skin.rect(g, x + 4, y + 7, 1, 1, 0xFF5A3A28);
            }
            case "treat_fish" -> {
                Skin.rect(g, x + 1, y + 3, 6, 4, 0xFF8FD3FF);
                Skin.rect(g, x + 7, y + 2, 2, 6, 0xFF8FD3FF);
                Skin.rect(g, x + 2, y + 4, 1, 1, 0xFF1A1A22);
            }
            case "treat_honey" -> {
                Skin.rect(g, x + 2, y + 3, 6, 7, 0xFFFFC832);
                Skin.rect(g, x + 2, y + 1, 6, 2, 0xFFC98B5A);
                Skin.rect(g, x + 3, y + 4, 1, 4, 0xFFFFE680);
            }
            case "treat_medicine" -> {
                Skin.rect(g, x + 2, y + 3, 6, 7, 0xFFFFFFFF);
                Skin.rect(g, x + 3, y + 1, 4, 2, 0xFFE5484D);
                Skin.rect(g, x + 4, y + 5, 2, 4, 0xFFE5484D);
                Skin.rect(g, x + 3, y + 6, 4, 2, 0xFFE5484D);
            }
            case "treat_milk" -> {
                Skin.rect(g, x + 3, y + 3, 4, 7, 0xFFFFFFFF);
                Skin.rect(g, x + 4, y + 1, 2, 2, 0xFFD8CCE2);
                Skin.rect(g, x + 3, y + 6, 4, 2, 0xFF8FD3FF);
            }
            case "treat_berry" -> {      // two red berries with a green leaf
                Skin.disc(g, x + 3, y + 7, 3, 0xFFD6335A);
                Skin.disc(g, x + 7, y + 6, 2, 0xFFE5484D);
                Skin.rect(g, x + 4, y + 1, 3, 2, 0xFF5CC24A);
                Skin.rect(g, x + 3, y + 5, 1, 1, 0xFFFFC0CC);
            }
            case "treat_lolly" -> {      // a pink swirl lollipop on a stick
                Skin.disc(g, x + 5, y + 4, 4, 0xFFFF7FB0);
                Skin.disc(g, x + 5, y + 4, 2, 0xFFFFFFFF);
                Skin.disc(g, x + 5, y + 4, 1, 0xFFFF7FB0);
                Skin.rect(g, x + 5, y + 8, 1, 2, 0xFFE0D2B8);
            }
            default -> { // cake
                Skin.rect(g, x + 1, y + 5, 8, 5, 0xFFFFB3CF);
                Skin.rect(g, x + 1, y + 4, 8, 2, 0xFFFFFFFF);
                Skin.disc(g, x + 5, y + 3, 2, 0xFFE5484D);
            }
        }
    }

    private int giftT = 240;

    /** The days that bring the pet a present: id, first month/day, last month/day, coins. */
    private static final int[][] HOLIDAYS = {{12, 31, 1, 2, 25}, {2, 13, 2, 15, 15}, {6, 20, 6, 22, 10}, {10, 30, 11, 1, 15}};
    private static final String[] HOLIDAY_IDS = {"newyear", "valentine", "summer", "halloween"};

    /**
     * Seasonal presents: on a few days of the year (and on the pet's birthday) the pet brings a gift once, a few coins and a
     * line to say. Everything is by the real calendar and remembered by year, so it can only happen once for each.
     */
    private void holidayGift() {
        if (setup != 0 || sp == null || sick) return;
        java.time.LocalDate d = java.time.LocalDate.now();
        int md = d.getMonthValue() * 100 + d.getDayOfMonth();
        for (int i = 0; i < HOLIDAYS.length; i++) {
            int[] h = HOLIDAYS[i];
            int from = h[0] * 100 + h[1], to = h[2] * 100 + h[3];
            boolean in = from <= to ? md >= from && md <= to : md >= from || md <= to;
            if (!in) continue;
            int year = h[0] == 12 && h[2] == 1 && d.getMonthValue() == 12 ? d.getYear() + 1 : d.getYear();   // the new year's days belong to the new year
            String key = "pet_hol_" + HOLIDAY_IDS[i];
            if (Progress.count(key) == year) continue;
            Progress.setCount(key, year);
            Progress.earn(h[4]);
            Progress.toast("cutemod.pet.holiday." + HOLIDAY_IDS[i], PetName.display(species().id), h[4]);
            say("cutemod.pet.holiday.say." + HOLIDAY_IDS[i]);
            burst(0, 10); jump = 60; sound(1.7F);
            return;
        }
        int born = Progress.count("pet_born_" + sp.id);
        if (born <= 0) { Progress.setCount("pet_born_" + sp.id, (int) d.toEpochDay()); return; }        // a pet from before: its day is today
        java.time.LocalDate b = java.time.LocalDate.ofEpochDay(born);
        if (b.getMonthValue() == d.getMonthValue() && b.getDayOfMonth() == d.getDayOfMonth() && d.getYear() > b.getYear()
                && Progress.count("pet_bday_" + sp.id) != d.getYear()) {
            Progress.setCount("pet_bday_" + sp.id, d.getYear());
            int age = d.getYear() - b.getYear();
            Progress.earn(20 + 5 * Math.min(age, 5));
            Progress.toast("cutemod.pet.birthday", PetName.display(species().id), age);
            say("cutemod.pet.birthday.say");
            burst(0, 12); jump = 60; sound(1.9F);
        }
    }

    private long bedNight = Long.MIN_VALUE;

    /** Night by the real clock: 22:00 to 07:00. */
    private static boolean nightNow() {
        int h = java.time.LocalTime.now().getHour();
        return h >= 22 || h < 7;
    }

    /** One number for every night (the night that starts at 22:00 ends at 07:00 the next morning). */
    private static long nightKey() { return java.time.LocalDateTime.now().minusHours(7).toLocalDate().toEpochDay(); }

    private void toggleSleep() {
        sleeping = !sleeping;
        if (sleeping) cSleep++;
        sound(sleeping ? 0.6F : 1.4F);
    }

    private void pet() {
        fun = clamp(fun + 1.5);
        cPet++;
        jump = Math.max(jump, 15);
        burst(0, 1);
        sound(1.5F);
        Progress.onPet("pet");
        introAdvance(3);
        if (sleeping) { sleeping = false; say("cutemod.pet.say.pet"); }
        else if (cPet % 4 == 0 && msgTimer == 0) {                                          // a different squeak now and then
            if (rnd.nextInt(3) == 0) sayText(chatLine(8 + 6 + rnd.nextInt(CHAT_FACTS + CHAT_JOKES)));   // or a fact, or a joke
            else say("cutemod.pet.touch." + rnd.nextInt(6));
        }
    }

    @Override
    public void tick() {
        ticks++;
        if (hosted != null) hosted.tick();
        if (setup != 0) { setupTick(); return; }
        if (showUi != null) showUi.tick();
        if (parkUi != null) parkUi.tick();
        if (tripUi != null) tripUi.tick();
        if (mapUi != null) mapUi.tick();
        if (placeUi != null) placeUi.tick();
        if (roomUi != null) roomUi.tick();
        if (pantryUi != null) pantryUi.tick();
        if (Trip.awayFor(species())) return;                       // the pet is on a trip: nothing changes at home
        final boolean out = elsewhere();                           // on the map, in the park, at the show...: the room is quiet then
        if (out) { msgTimer = 0; spkSeen = ""; spkAge = 0; }
        if (!out && Progress.count("trip_bonus") == species().ordinal() + 1) {   // it just came back
            Progress.setCount("trip_bonus", 0);
            fun = clamp(fun + 30);
            food = clamp(food - 10);
            energy = clamp(energy - 10);
            say("cutemod.trip.welcome");
            burst(0, 8);
            jump = 60;
            sound(1.7F);
        }
        if (gm != 0) { if (sick || sleeping) gm = 0; else gameTick(); }
        if (jump > 0) jump--;
        if (shake > 0) shake--;
        if (msgTimer > 0) msgTimer--;
        if (Hell.active() && !sleeping && !out) {                               // the crimson look: the pet trembles and is scared
            if (shake == 0 && ticks % 150 == 0) shake = 25;
            if (msgTimer == 0 && --fearT <= 0) {
                say("cutemod.pet.say.hell." + (int) (Math.random() * 4));
                shake = 40;
                fearT = 500 + (int) (Math.random() * 400);
            }
        } else if (!Hell.active()) fearT = 60;
        if (!out) { speechTick(); furnitureTick(); }    // also in the mini games, or the bubble would stay empty; never on the map, in the park or at the show
        double dt = 1 / 60.0;
        if (++giftT >= 300) { giftT = 0; if (!sleeping && gm == 0 && !out) holidayGift(); }
        if (!out && Retro.bedtime() && !sleeping && !sick && gm == 0 && nightNow() && bedNight != nightKey() && !Trip.awayFor(species())) {
            bedNight = nightKey();                                  // once a night: a tired pet goes to bed by itself (wake it up and it stays up)
            if (energy < 80) { sleeping = true; cSleep++; say("cutemod.pet.say.bedtime"); sound(0.6F); }
        }
        if (sleeping) {
            energy += (sick ? 0.2 : 0.4) * dt;
            food -= 0.02 * dt;
            if (energy >= 100) { sleeping = false; say("cutemod.pet.say.rested"); }
        } else {
            food -= 0.05 * dt;
            fun -= (sick ? 0.08 : 0.04) * dt;
            energy -= (sick ? 0.05 : 0.03) * dt;
        }
        food = clamp(food); fun = clamp(fun); energy = clamp(energy);
        boolean critical = !sleeping && !sick && (food < 12 || fun < 8 || energy < 8);
        if (critical) { neglect += dt; if (neglect >= NEGLECT_SEC && !out) fallSick(); }
        else if (neglect > 0) neglect = Math.max(0, neglect - dt * 2);
        ageAcc += dt;
        if (ageAcc >= 1) { ageAcc -= 1; ageSec++; }
        int st = stage();
        if (st > lastStage && !out) { // it grew up (it tells you at home)
            lastStage = st;
            say("cutemod.pet.say.grow." + st);
            burst(0, 8);
            jump = 60;
            sound(1.9F);
        }
        if (!sleeping && !out && mood() == 2 && Progress.count("pet_gifts") < GIFTS) {
            happyAcc += dt;
            if (happyAcc >= GIFT_SEC) { // a happy pet writes you a letter (it lands in the Mail app)
                happyAcc = 0;
                Progress.bump("pet_gifts");
                say("cutemod.pet.say.gift");
                burst(0, 6);
                sound(1.6F);
            }
        }
        for (int i = parts.size() - 1; i >= 0; i--) {
            double[] p = parts.get(i);
            p[0] += p[2];
            p[1] += p[3];
            if (p[5] == 1) p[3] += 0.03;
            if (--p[4] <= 0) parts.remove(i);
        }
        if (introStep == 4 && ++introT > 1500) introFinish();        // the favourite treat is only a hint, it does not wait forever
        if (++saveTimer > 1800) { saveTimer = 0; save(); } // every 30 s
    }

    /** The piece of furniture the pet is using right now ("" = none). Only one piece stands in that place of the room. */
    private String useId() {
        if (gm != 0 || setup != 0) return "";
        String id = Furniture.floorRight();
        return switch (id) {
            case "furn_bed" -> sleeping ? id : "";
            case "furn_sofa" -> sleeping ? "" : id;
            case "furn_piano" -> !sleeping && !sick && mood() == 2 ? id : "";
            default -> "";
        };
    }

    private boolean playing() {
        int[] sp = Furniture.spot(useId());
        return sp != null && "furn_piano".equals(useId()) && Math.abs(spotX - sp[0]) < 2;
    }

    /** The pet glides to the piece (and climbs on it); at the piano it plays: notes float up over it. */
    private void furnitureTick() {
        int[] sp = Furniture.spot(useId());
        double tx = sp == null ? CX : sp[0];
        spotX += (tx - spotX) * 0.08;
        if (Math.abs(spotX - tx) < 0.5) spotX = tx;
        double tl = sp != null && Math.abs(spotX - tx) < 14 ? sp[1] : 0;
        spotLift += (tl - spotLift) * 0.2;
        if (playing() && ticks % 18 == 0 && rnd.nextInt(3) != 0) {
            parts.add(new double[]{petX() - 12 + rnd.nextInt(24), CY - 34, (rnd.nextDouble() - 0.5) * 0.3, -0.45, 80, 2 + rnd.nextInt(3)});
            sound(NOTES[rnd.nextInt(NOTES.length)]);
        }
    }

    private int mood() {
        if (sick) return 0;
        double m = (food + fun + energy) / 3;
        return (food < 20 || m < 35) ? 0 : m >= 65 ? 2 : 1;
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        if (hosted != null) { hosted.render(g, mx, my); return; }
        if (setup == 1) { renderChoose(g, font(), mx, my); return; }
        if (setup == 4 || setup == 5) { renderDetails(g, font(), mx, my); return; }
        if (showUi != null) { showUi.render(g, mx, my); return; }
        if (parkUi != null) { parkUi.render(g, mx, my); return; }
        if (tripUi != null) { tripUi.render(g, mx, my); return; }
        if (mapUi != null) { mapUi.render(g, mx, my); return; }
        if (placeUi != null) { placeUi.render(g, mx, my); return; }
        if (roomUi != null) { roomUi.render(g, mx, my); return; }
        if (pantryUi != null) { pantryUi.render(g, mx, my); return; }
        if (Trip.awayFor(species())) { renderAway(g, mx, my); return; }
        Font f = font();
        int body = shell.color().bodyColor;

        // room
        PetScenes.room(g, body | 0xFF000000, sleeping, ticks);

        Furniture.drawRoom(g, ticks);          // the furniture the player bought
        if (setup == 2 || setup == 3) { renderEgg(g, f, mx, my); return; }
        shelf(g, f);
        if (gm == 0) nameTag(g, f, mx, my);

        // stats
        int sy = sick ? 12 : 8;                                  // the illness banner covers the top 9 pixels, so the bars move below it
        stat(g, sy, "cutemod.pet.food", food);
        stat(g, sy + 12, "cutemod.pet.fun", fun);
        stat(g, sy + 24, "cutemod.pet.energy", energy);
        if (gm == 0) { // the "Game" button under the window
            sideIcon(g, 0, GB_X, GB_Y, in(mx, my, GB_X, GB_Y, GB_W, GB_H));       // the game
            sideIcon(g, 2, TB_X, TB_Y, in(mx, my, TB_X, TB_Y, TB_W, TB_H));       // the map of the town
            sideIcon(g, 3, RB_X, RB_Y, in(mx, my, RB_X, RB_Y, RB_W, RB_H));       // the room: furniture
        }

        // pet
        int mood = mood();
        double bob = sleeping ? Math.sin(ticks / 40.0) * 1.0 : Math.sin(ticks / 20.0) * 1.5;
        if (playing()) bob = -Math.abs(Math.sin(ticks * 0.16)) * 3;           // it bounces to its own music
        int lift = (int) Math.round(spotLift), surf = FLOOR - lift;           // the height of what it stands on
        double hop = jump > 0 ? Math.abs(Math.sin(jump * 0.2)) * 14 : 0;
        int px = petX() + (shake > 0 ? (int) Math.round(Math.sin(shake * 1.2) * 3) : 0);
        int py = CY - lift + (int) Math.round(bob - hop);
        int sw = (int) (24 - hop / 2); // shadow shrinks while jumping
        Skin.rect(g, petX() - sw, surf, sw * 2, 3, 0x33000000);
        Skin.rect(g, petX() - sw + 3, surf + 3, sw * 2 - 6, 1, 0x22000000);
        float sc = PetArt.scaleOf(stage()); // babies are small
        g.pose().pushPose();
        g.pose().translate(px, surf, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-px, -surf, 0);
        drawPet(g, px, py, mood);
        g.pose().popPose();
        if (lift > 3 && Furniture.floorRight().equals("furn_bed")) Furniture.blanket(g);   // it sleeps under the blanket

        if (sleeping) {
            Skin.rect(g, 0, 0, W, FLOOR + 10, 0x66102040);
            for (int i = 0; i < 3; i++) {
                int zt = (ticks / 25 + i) % 3;
                Skin.str(g, f, "z", petX() + 20 + zt * 7, py - 26 - zt * 7 - i * 0, 0xFFFFFFFF, false);
            }
        }

        // particles
        for (double[] p : parts) {
            int x = (int) p[0], y = (int) p[1];
            if (p[5] == 0) { // heart
                Skin.rect(g, x, y + 1, 5, 2, 0xFFFF5C93);
                Skin.rect(g, x + 1, y, 1, 1, 0xFFFF5C93);
                Skin.rect(g, x + 3, y, 1, 1, 0xFFFF5C93);
                Skin.rect(g, x + 1, y + 3, 3, 1, 0xFFFF5C93);
                Skin.rect(g, x + 2, y + 4, 1, 1, 0xFFFF5C93);
            } else if (p[5] >= 2) { // a music note
                int c = p[5] == 2 ? 0xFFFF5C93 : p[5] == 3 ? 0xFF4A90D8 : 0xFFF0B90B;
                int wx = x + (int) Math.round(Math.sin(p[4] * 0.15) * 3);
                Skin.rect(g, wx, y + 5, 4, 3, c); Skin.rect(g, wx + 3, y, 1, 6, c); Skin.rect(g, wx + 4, y, 3, 2, c);
            } else {
                Skin.rect(g, x, y, 3, 3, 0xFFC98B5A);
            }
        }

        if (sleeping && Retro.bedtime() && nightNow()) g.fill(0, 0, W, H, 0x66101840);   // a night in the room: everything gets dim while it sleeps

        // speech bubble
        String say = bubbleText();
        if (!say.isEmpty()) {
            List<String> ls = bubbleWrap(f, say, 176);
            int tw = 0;
            for (String l : ls) tw = Math.max(tw, f.width(l));
            int w = tw + 10, h = ls.size() * 10 + 3;
            int bx = Math.max(2, Math.min(W - w - 2, petX() - w / 2)), by = Math.max(2, CY - 49 - lift - h);
            int shown = say.equals(spkSeen) ? Math.min(say.length(), spkAge / 3) : 0;      // the text types itself
            g.pose().pushPose();
            g.pose().translate(0, 0, 60);                                                  // above the pet, the buttons and their texts
            Skin.rect(g, bx - 1, by - 1, w + 2, h + 2, 0xFF3A2A3A);
            Skin.rect(g, bx, by, w, h, 0xFFFFFFFF);
            Skin.rect(g, petX() - 2, by + h, 4, 1, 0xFFFFFFFF);
            Skin.rect(g, petX() - 1, by + h + 1, 2, 2, 0xFF3A2A3A);
            int left = shown;
            for (int i = 0; i < ls.size() && left > 0; i++) {
                String l = ls.get(i);
                Skin.str(g, f, l.substring(0, Math.min(left, l.length())), bx + 5, by + 3 + i * 10, DARK, false);
                left -= l.length();
            }
            g.pose().popPose();
        }

        // illness banner
        if (sick) {
            String b = t(Progress.stock("treat_medicine") > 0 ? "cutemod.pet.sick.banner.have" : "cutemod.pet.sick.banner.buy");
            Skin.rect(g, 0, 0, W, 9, (ticks / 20) % 2 == 0 ? 0xDDB03030 : 0xDD8A2020);
            Skin.boxC(g, f, b, 2, 1, 0xFFFFFFFF, false, W - 4);        // the banner text shrinks to fit instead of running off
        }

        if (gm != 0) { renderGame(g, f, mx, my); return; }

        // treats from the shop: click one to give it to the pet
        String tip = null;
        for (int i = 0; i < TREATS.length; i++) {
            int sx = SLOT_X + i * SLOT_W, have = Progress.stock(TREATS[i]);
            boolean hover = in(mx, my, sx, SLOT_Y, SLOT_W - 2, SLOT_H);
            if (sick && TREATS[i].equals("treat_medicine") && have > 0 && (ticks / 15) % 2 == 0) Skin.rect(g, sx - 1, SLOT_Y - 1, SLOT_W, SLOT_H + 2, 0xFFE5484D);
            Skin.rect(g, sx, SLOT_Y, SLOT_W - 2, SLOT_H, hover ? 0xFFFFFFFF : 0xFFFFF0C0);
            drawTreat(g, TREATS[i], sx + 1, SLOT_Y + 2);
            if (have == 0) Skin.rect(g, sx, SLOT_Y, SLOT_W - 2, SLOT_H, 0x99D8CCE2);
            Skin.str(g, f, Integer.toString(have), sx + 12, SLOT_Y + 3, have > 0 ? DARK : 0xFF8A7AA8, false);
            if (i == favourite()) {                                  // a small heart: the loved food
                Skin.rect(g, sx + SLOT_W - 10, SLOT_Y - 4, 2, 2, 0xFFFF5C8A); Skin.rect(g, sx + SLOT_W - 6, SLOT_Y - 4, 2, 2, 0xFFFF5C8A);
                Skin.rect(g, sx + SLOT_W - 10, SLOT_Y - 2, 6, 2, 0xFFFF5C8A); Skin.rect(g, sx + SLOT_W - 9, SLOT_Y, 4, 1, 0xFFFF5C8A);
            }
            if (hover) {
                tip = t("cutemod.shop.item." + TREATS[i]);
                if (i == favourite()) tip += " (" + t("cutemod.pet.fav.word") + ")";
                else if (introStep == 0 && i == dislike()) tip += " (" + t("cutemod.pet.dis.word") + ")";
            }
        }
        if (tip != null) Skin.str(g, f, tip, W - 6 - f.width(tip), SLOT_Y - 11, DARK, false);

        // buttons
        Skin.rect(g, 0, BTN_Y - 4, W, H - BTN_Y + 4, mix(body, 0x000000, 0.35f));
        String[] labels = {t("cutemod.pet.feed"), t("cutemod.pet.play"), t(sleeping ? "cutemod.pet.wake" : "cutemod.pet.sleep")};
        for (int i = 0; i < 3; i++) {
            boolean hover = in(mx, my, BTN_X[i], BTN_Y, BTN_W, BTN_H);
            Skin.rect(g, BTN_X[i], BTN_Y, BTN_W, BTN_H, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
            Skin.rect(g, BTN_X[i], BTN_Y + BTN_H - 2, BTN_W, 2, 0xFFB9A8C8);
            Skin.str(g, f, labels[i], BTN_X[i] + (BTN_W - f.width(labels[i])) / 2, BTN_Y + 4, DARK, false);
        }
        introHints(g);
    }

    private String bubbleText() {
        if (msgTimer > 0) return msg;
        if (gm != 0) return "";                          // in a mini game only its own lines are said
        if (sleeping) return "";
        if (introStep >= 1 && introStep <= 4) return t("cutemod.pet.intro." + introStep, t("cutemod.shop.item." + TREATS[favourite()]));
        if (sick) return t("cutemod.pet.say.sick");
        if (food < 25) return t("cutemod.pet.say.hungry");
        if (energy < 25) return t("cutemod.pet.say.sleepy");
        if (fun < 25) return t("cutemod.pet.say.bored");
        if (mood() == 2) {
            int cyc = (ticks / 300) % 4;
            if (cyc == 0) return t("cutemod.pet.say.happy");
            if (cyc == 1 && trait() < 4) return t("cutemod.pet.say.trait." + trait());
            if (cyc >= 2) return chatter();                 // two phases: a long fact needs time to be typed and read
        }
        return "";
    }

    /** The cups the player won in the talent show stand on a shelf above the pet. */
    /** One of the four tiny buttons at the left (no text): 0 game, 1 park, 2 map, 3 room. A 14 x 14 tile with a little picture. */
    private static void sideIcon(GuiGraphics g, int k, int x, int y, boolean hover) {
        int[] bg = {0xFFF6F0FA, 0xFFC4EDB8, 0xFFC4DFF8, 0xFFFFCCE4};
        int[] edge = {0xFFB9A8C8, 0xFF6FB85F, 0xFF6F9FD8, 0xFFD87AA8};
        if (hover) Skin.rect(g, x - 1, y - 2, 16, 16, 0xCCFFFFFF);
        y -= hover ? 1 : 0;
        Skin.rect(g, x, y, 14, 14, bg[k]);
        Skin.rect(g, x, y + 12, 14, 2, edge[k]);
        switch (k) {
            case 0 -> {                                                           // a gamepad
                Skin.rect(g, x + 2, y + 4, 10, 6, 0xFF7A6A9A);
                Skin.rect(g, x + 3, y + 6, 3, 1, 0xFFFFFFFF); Skin.rect(g, x + 4, y + 5, 1, 3, 0xFFFFFFFF);
                Skin.rect(g, x + 8, y + 5, 2, 2, 0xFFFF7AA8); Skin.rect(g, x + 9, y + 7, 2, 2, 0xFF7AC8FF);
            }
            case 1 -> {                                                           // a tree
                Skin.rect(g, x + 4, y + 1, 6, 2, 0xFF4FA85A); Skin.rect(g, x + 3, y + 3, 8, 3, 0xFF4FA85A); Skin.rect(g, x + 4, y + 6, 6, 1, 0xFF4FA85A);
                Skin.rect(g, x + 6, y + 7, 2, 3, 0xFF8A5A3A);
            }
            case 2 -> {                                                           // a folded map with a pin
                Skin.rect(g, x + 2, y + 2, 10, 8, 0xFFFFF3D0);
                Skin.rect(g, x + 5, y + 2, 1, 8, 0xFFE0C890); Skin.rect(g, x + 8, y + 2, 1, 8, 0xFFE0C890);
                Skin.rect(g, x + 6, y + 4, 2, 2, 0xFFE0594F); Skin.rect(g, x + 6, y + 6, 2, 1, 0xFFE0594F);
            }
            default -> {                                                          // a little house
                Skin.rect(g, x + 6, y + 1, 2, 1, 0xFFD84F7A); Skin.rect(g, x + 5, y + 2, 4, 1, 0xFFD84F7A);
                Skin.rect(g, x + 4, y + 3, 6, 1, 0xFFD84F7A); Skin.rect(g, x + 3, y + 4, 8, 1, 0xFFD84F7A);
                Skin.rect(g, x + 4, y + 5, 6, 5, 0xFFFFF3E8); Skin.rect(g, x + 6, y + 7, 2, 3, 0xFFB07A5A);
            }
        }
    }

    private void shelf(GuiGraphics g, Font f) {
        if (!fameAsked) { fameAsked = true; Show.request(); }
        var fame = Show.fame();
        if (fame == null) return;
        int[] n = {fame.gold(), fame.silver(), fame.bronze()};
        int[] col = {0xFFF3C45A, 0xFFC4CAD6, 0xFFD08A4E};
        if (n[0] + n[1] + n[2] == 0) return;
        Skin.rect(g, 76, 30, 120, 3, 0xFF8A6A4A);
        Skin.rect(g, 76, 33, 120, 1, 0xFF6B4F35);
        int slot = 0;
        for (int i = 0; i < 3; i++) {
            if (n[i] == 0) continue;
            int cx = 88 + slot * 40;
            PetShow.cup(g, cx, 17, col[i]);
            Skin.str(g, f, "x" + n[i], cx + 14, 21, 0xFF3A2A3A, false);
            slot++;
        }
    }

    private void stat(GuiGraphics g, int y, String key, double value) {
        String s = t(key);
        int lw = Math.min(40, font().width(s));                  // the label stays right of the trophy shelf (it shrinks instead of overlapping)
        Skin.box(g, font(), s, 242 - lw, y, 0xFFFFFFFF, true, 40);
        Skin.rect(g, 246, y, 46, 8, 0x99000000);
        int col = value > 50 ? 0xFF5BBF6A : value > 25 ? 0xFFF5C518 : 0xFFE5484D;
        Skin.rect(g, 247, y + 1, (int) (44 * value / 100), 6, col);
    }

    /** Small talk: every line comes once (in a mixed order, different for every pet) before any comes again. */
    private String chatter() {
        return chatLine(Math.floorMod(chatSeed + (ticks / 1200) * 37, CHAT_TOTAL));      // 37 is prime, so it never divides CHAT_TOTAL (68)
    }

    /** 0-7 for every pet, then 6 for its own species, then the facts, then the jokes. */
    private String chatLine(int n) {
        if (n < 8) return t("cutemod.pet.chat." + n, t("cutemod.shop.item." + TREATS[favourite()]));
        n -= 8;
        if (n < 6) return t("cutemod.pet.chat." + species().id + "." + n);
        n -= 6;
        if (n < CHAT_FACTS) return t("cutemod.pet.fact." + n);
        n -= CHAT_FACTS;
        if (n < CHAT_JOKES) return t("cutemod.pet.joke." + n);
        return t("cutemod.pet.chat.name." + (n - CHAT_JOKES), PetName.display(species().id));       // lines with its own name
    }

    /** Splits a text into lines no wider than maxW (by words). */
    private static List<String> bubbleWrap(Font f, String s, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String tryLine = line.length() == 0 ? word : line + " " + word;
            if (line.length() > 0 && f.width(tryLine) > maxW) { out.add(line.toString()); line = new StringBuilder(word); }
            else line = new StringBuilder(tryLine);
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    // ---------- the first meeting ----------
    /** Goes on when the player did what the pet asked for (1 feed, 2 play, 3 pet, 4 give the favourite). */
    private void introAdvance(int from) {
        if (introStep != from) return;
        introStep++;
        introT = 0;
        if (introStep == 4) {                                  // the favourite: one treat of it as a gift
            String id = TREATS[favourite()];
            Progress.setCount("stock_" + id, Progress.stock(id) + 1);
            Progress.setCount("pet_intro_" + sp.id, 4);
        } else if (introStep > 4) {
            introFinish();
        } else {
            Progress.setCount("pet_intro_" + sp.id, introStep);
        }
    }

    private void introFinish() {
        introStep = 0;
        Progress.setCount("pet_intro_" + sp.id, 9);
        Progress.earn(5);
        say("cutemod.pet.intro.done");
        burst(0, 8);
        jump = 50;
        sound(1.9F);
    }

    private static void frame(GuiGraphics g, int x, int y, int w, int h, int col) {
        Skin.rect(g, x, y, w, 2, col);
        Skin.rect(g, x, y + h - 2, w, 2, col);
        Skin.rect(g, x, y, 2, h, col);
        Skin.rect(g, x + w - 2, y, 2, h, col);
    }

    /** A pulsing frame (or ring) around the thing the pet wants you to click, and an arrow that bounces over it. */
    private void introHints(GuiGraphics g) {
        if (introStep < 1 || introStep > 4 || sleeping || gm != 0) return;
        int col = (ticks / 15) % 2 == 0 ? 0xFFFFD84D : 0xFFFFFFFF;
        int bob = (ticks / 8) % 2;
        int ax, ay;
        switch (introStep) {
            case 1, 2 -> {
                int x = BTN_X[introStep - 1];
                frame(g, x - 2, BTN_Y - 2, BTN_W + 4, BTN_H + 4, col);
                ax = x + BTN_W / 2;
                ay = BTN_Y - 10;
            }
            case 3 -> {
                for (int a = 0; a < 24; a++) {
                    double an = a * Math.PI / 12;
                    Skin.rect(g, petX() + (int) Math.round(Math.cos(an) * 38) - 1, CY - 2 - (int) Math.round(spotLift) + (int) Math.round(Math.sin(an) * 40) - 1, 3, 3, col);
                }
                return;
            }
            default -> {
                int x = SLOT_X + favourite() * SLOT_W;
                frame(g, x - 2, SLOT_Y - 2, SLOT_W + 2, SLOT_H + 4, col);
                ax = x + SLOT_W / 2 - 1;
                ay = SLOT_Y - 12;
            }
        }
        for (int i = 0; i < 4; i++) Skin.rect(g, ax - 4 + i, ay + bob + i, 9 - 2 * i, 1, col);   // an arrow that points down
    }

    // ---------- the first start: choose a pet, warm the egg, let it hatch ----------
    private void setupTick() {
        if (shake > 0) shake--;
        if (jump > 0) jump--;
        if (msgTimer > 0) msgTimer--;
        for (int i = parts.size() - 1; i >= 0; i--) {
            double[] p = parts.get(i);
            p[0] += p[2];
            p[1] += p[3];
            if (--p[4] <= 0) parts.remove(i);
        }
        if (setup == 3) {
            hatchT++;
            if (hatchT == 62) { sound(2.0F); jump = 60; burst(0, 10); }
            if (hatchT >= 160) finishHatch();
        }
    }

    private boolean setupClick(int x, int y) {
        if (setup == 4 || setup == 5) return detailsClick(x, y);
        if (setup == 1) {
            ComputerColor[] all = ComputerColor.values();
            for (int i = 0; i < all.length; i++) {
                int cx = CH_X + (i % 4) * CH_W, cy = CH_Y + (i / 4) * CH_H;
                if (in(x, y, cx, cy, CH_W - 4, CH_H - 4) && !taken(all[i], shell.color())) { chosen = i; sound(1.4F + 0.05F * i); return true; }
            }
            if (chosen >= 0 && in(x, y, AD_X, AD_Y, AD_W, AD_H)) {         // adopt: the egg is yours now
                Progress.setCount("pet_sp_" + shell.color().id, chosen + 1);
                Progress.setCount("pet_egg_" + shell.color().id, 0);
                sp = all[chosen];
                eggTaps = 0;
                setup = 4;                                                   // now its name and character
                pickVar = 0;
                nameBuf.setLength(0);
                pickTrait = -1;
                nameNote = "";
                sound(1.8F);
            }
            return true;
        }
        if (setup == 2 && in(x, y, CX - 26, EGG_Y - 30, 52, 62)) tapEgg();
        return true;
    }

    private boolean setupKey(int keyCode) {
        if (setup == 4 || setup == 5) {
            if (keyCode == 256) { if (setup == 5) setup = 0; return true; }          // escape: out of the rename form
            if (keyCode == 257 || keyCode == 335) { confirmDetails(); return true; }
            if (keyCode == 259) { if (nameBuf.length() > 0) nameBuf.setLength(nameBuf.length() - 1); return true; }
            return false;
        }
        if (setup == 2 && (keyCode == 32 || keyCode == 257 || keyCode == 49)) { tapEgg(); return true; }
        return false;
    }

    /** Every tap warms the egg: eight of them and it hatches (the taps are saved, so closing the app does not matter). */
    private void tapEgg() {
        eggTaps++;
        Progress.setCount("pet_egg_" + shell.color().id, eggTaps);
        shake = 14;
        burst(0, 2);
        sound(1.0F + 0.1F * Math.min(eggTaps, 8));
        if (eggTaps >= 8) { setup = 3; hatchT = 0; }
    }

    /** The egg has hatched: a new baby, a little hungry, and the first meeting begins. */
    private void finishHatch() {
        setup = 0;
        ageSec = 0;
        ageAcc = 0;
        food = 55; fun = 70; energy = 85;
        sleeping = false; sick = false; lonelySick = false; neglect = 0;
        cFeed = 0; cPlay = 0; cSleep = 0; cPet = 0;
        PetName.Rec nr = PetName.get(sp.id);                       // the character the player chose: it is settled from the start
        if (nr != null) switch (nr.trait()) {
            case 0 -> cFeed = 12;
            case 1 -> cPlay = 12;
            case 2 -> cSleep = 12;
            case 3 -> cPet = 12;
            default -> { }
        }
        lastStage = stage();
        save();
        Progress.setCount("pet_intro_" + sp.id, 1);
        Progress.setCount("pet_born_" + sp.id, (int) java.time.LocalDate.now().toEpochDay());    // for the birthday gift
        introStep = 1;
        introT = 0;
        welcomeGift();
        say("cutemod.pet.say.hatch");
    }

    // ---------- the name and the character ----------
    private int[] tagRect() {
        int w = font().width(PetName.display(species().id)) + 15;
        return new int[]{CX - w / 2, w};
    }

    /** The name of the pet on a small plate at the top; click it to give a new name (once a day). */
    private void nameTag(GuiGraphics g, Font f, int mx, int my) {
        int[] tg = tagRect();
        boolean h = in(mx, my, tg[0], 2, tg[1], 11);
        Skin.rect(g, tg[0], 2, tg[1], 11, h ? 0xDDFFFFFF : 0x99FFFFFF);
        Skin.str(g, f, PetName.display(species().id), tg[0] + 3, 3, DARK, false);
        int px = tg[0] + tg[1] - 9;                                           // a tiny pencil
        Skin.rect(g, px + 4, 4, 2, 2, 0xFFE5A03A); Skin.rect(g, px + 2, 6, 2, 2, 0xFFE5A03A); Skin.rect(g, px, 8, 2, 2, DARK);
    }

    private void openRename() {
        nameBuf.setLength(0);
        nameBuf.append(PetName.custom(species().id));
        nameNote = "";
        setup = 5;
        sound(1.4F);
    }

    /** The screen for the name (and, for a new pet, its character); the same field is used for a new name later. */
    private void renderDetails(GuiGraphics g, Font f, int mx, int my) {
        boolean rename = setup == 5;
        int body = shell.color().bodyColor;
        Skin.grad(g, 0, 0, W, H, mix(body, 0xFFFFFF, 0.8f), mix(body, 0xFFFFFF, 0.55f));
        Skin.cstr(g, f, t(rename ? "cutemod.pet.rename.title" : "cutemod.pet.name.title"), W / 2, 6, DARK);
        int px = 62, floor = 118;
        Skin.rect(g, px - 34, floor + 1, 68, 3, 0x33000000);
        g.pose().pushPose();
        g.pose().translate(px, floor, 0);
        g.pose().scale(0.95F, 0.95F, 1F);
        g.pose().translate(-px, -floor, 0);
        PetArt.draw(g, species(), rename ? PetArt.ownVariant(species()) : pickVar, px, floor - 28, 2, ticks, false, false, rename ? stage() : 1, rename ? Progress.equipped() : "", rename ? Progress.equippedBody() : "");
        g.pose().popPose();
        Skin.str(g, f, t("cutemod.pet.name.hint"), NM_X, NM_Y - 11, DARK, false);
        Skin.rect(g, NM_X, NM_Y, NM_W, NM_H, 0xFFFFFFFF);
        Skin.rect(g, NM_X, NM_Y, NM_W, 1, 0xFFB57BD6); Skin.rect(g, NM_X, NM_Y + NM_H - 1, NM_W, 1, 0xFFB57BD6);
        Skin.rect(g, NM_X, NM_Y, 1, NM_H, 0xFFB57BD6); Skin.rect(g, NM_X + NM_W - 1, NM_Y, 1, NM_H, 0xFFB57BD6);
        String n = nameBuf.toString();
        if (n.isEmpty()) Skin.str(g, f, t("cutemod.pet.name." + species().id), NM_X + 6, NM_Y + 5, 0xFFC0B4D0, false);
        Skin.str(g, f, n + ((ticks / 25) % 2 == 0 ? "_" : ""), NM_X + 6, NM_Y + 5, DARK, false);
        String cnt = n.length() + "/" + PetName.MAX;
        Skin.str(g, f, cnt, NM_X + NM_W - f.width(cnt), NM_Y + NM_H + 3, 0xFF6A5A78, false);
        if (rename) {
            Skin.str(g, f, t("cutemod.pet.rename.once"), NM_X, NM_Y + 34, 0xFF6A5A78, false);
        } else {
            Skin.str(g, f, t("cutemod.pet.name.trait"), NM_X, NM_Y + 34, DARK, false);
            int hv = -1;
            for (int i = 0; i < 4; i++) {
                int bx = NM_X + (i % 2) * 84, by = NM_Y + 46 + (i / 2) * 17;
                boolean sel = i == pickTrait, hov = in(mx, my, bx, by, 80, 15);
                if (hov) hv = i;
                Skin.rect(g, bx, by, 80, 15, sel ? 0xFFB57BD6 : hov ? 0xFFFFFFFF : 0xFFF6F0FA);
                String tn = t("cutemod.pet.trait." + i);
                Skin.str(g, f, tn, bx + (80 - f.width(tn)) / 2, by + 4, sel ? 0xFFFFFFFF : DARK, false);
            }
            int show = hv >= 0 ? hv : pickTrait;
            String d = show >= 0 ? t("cutemod.pet.name.trait." + show) : t("cutemod.pet.name.trait_none");
            Skin.str(g, f, d, NM_X, NM_Y + 82, 0xFF6A5A78, false);
            String cn = t("cutemod.pet.coat." + pickVar);                                   // the coat: four little color squares
            Skin.cstr(g, f, t("cutemod.pet.coat", cn), px, 126, DARK);
            for (int i = 0; i < PetArt.VARIANTS; i++) {
                int sx = NM_X + i * 22, sy = 135;
                boolean sel = i == pickVar, hov = in(mx, my, sx, sy, 18, 12);
                Skin.rect(g, sx - 1, sy - 1, 20, 14, sel ? 0xFFB57BD6 : hov ? 0xFFFFFFFF : 0x66FFFFFF);
                Skin.rect(g, sx, sy, 18, 12, PetArt.swatch(species(), i));
            }
        }
        if (nameNoteT > 0) { nameNoteT--; Skin.str(g, f, nameNote, 8, 134, 0xFFE5484D, false); }
        boolean oh = in(mx, my, OK_X, OK_Y, OK_W, OK_H);
        Skin.rect(g, OK_X, OK_Y, OK_W, OK_H, oh ? 0xFFFFF3B0 : 0xFFFFE9A8);
        Skin.rect(g, OK_X, OK_Y + OK_H - 2, OK_W, 2, 0xFFD9A93A);
        String ol = t(rename ? "cutemod.pet.rename.ok" : "cutemod.pet.name.ok");
        Skin.str(g, f, ol, OK_X + (OK_W - f.width(ol)) / 2, OK_Y + 4, DARK, false);
    }

    private boolean detailsClick(int x, int y) {
        if (setup == 4) {
            for (int i = 0; i < 4; i++) {
                if (in(x, y, NM_X + (i % 2) * 84, NM_Y + 46 + (i / 2) * 17, 80, 15)) { pickTrait = pickTrait == i ? -1 : i; sound(1.4F + 0.1F * i); return true; }
            }
            for (int i = 0; i < PetArt.VARIANTS; i++) {
                if (in(x, y, NM_X + i * 22, 135, 18, 12)) { pickVar = i; sound(1.2F + 0.1F * i); return true; }
            }
        }
        if (in(x, y, OK_X, OK_Y, OK_W, OK_H)) confirmDetails();
        return true;
    }

    private void confirmDetails() {
        String id = species().id, n = PetName.clean(nameBuf.toString());
        if (n.isEmpty()) { nameNote = t("cutemod.pet.name.empty"); nameNoteT = 180; return; }
        if (setup == 4) {                                                   // a new pet: name and character, then the egg
            PetName.put(id, new PetName.Rec(n, dev.cutemod.market.Deals.day(), pickTrait));
            Progress.setCount("pet_var_" + id, pickVar);                      // the coat is chosen once, with the name
            setup = 2;
            sound(1.8F);
            return;
        }
        if (n.equals(PetName.custom(id))) { setup = 0; return; }
        if (PetName.changedToday(id)) { nameNote = t("cutemod.pet.rename.wait"); nameNoteT = 240; return; }
        PetName.Rec old = PetName.get(id);
        PetName.put(id, new PetName.Rec(n, dev.cutemod.market.Deals.day(), old == null ? -1 : old.trait()));
        setup = 0;
        msg = t("cutemod.pet.rename.done", n);
        msgTimer = 180;
        burst(0, 4);
        jump = 40;
        sound(1.8F);
    }

    @Override
    public boolean charTyped(char c) {
        if (hosted != null) return hosted.charTyped(c);
        if (setup != 4 && setup != 5) return false;
        if (c < 32 || c == 127 || c == ';') return false;
        if (nameBuf.length() < PetName.MAX) nameBuf.append(c);
        return true;
    }

    /** The cards of the 8 pets. The color of this computer is a hint, the pets that are taken are greyed out. */
    private void renderChoose(GuiGraphics g, Font f, int mx, int my) {
        int body = shell.color().bodyColor;
        Skin.grad(g, 0, 0, W, H, mix(body, 0xFFFFFF, 0.8f), mix(body, 0xFFFFFF, 0.55f));
        Skin.cstr(g, f, t("cutemod.pet.choose.title"), W / 2, 6, DARK);
        Skin.cstr(g, f, t("cutemod.pet.choose.sub"), W / 2, 18, 0xFF6A5A78);
        ComputerColor[] all = ComputerColor.values();
        for (int i = 0; i < all.length; i++) {
            int x = CH_X + (i % 4) * CH_W, y = CH_Y + (i / 4) * CH_H, px = x + (CH_W - 4) / 2, floor = y + 34;
            boolean tk = taken(all[i], shell.color()), sel = i == chosen, hov = !tk && in(mx, my, x, y, CH_W - 4, CH_H - 4);
            Skin.rect(g, x - 1, y - 1, CH_W - 2, CH_H - 2, sel ? 0xFFD9A93A : 0xFFB9A8C8);
            Skin.rect(g, x, y, CH_W - 4, CH_H - 4, sel ? 0xFFFFE9A8 : hov ? 0xFFFFFFFF : 0xFFF6F0FA);
            g.pose().pushPose();
            g.pose().translate(px, floor, 0);
            g.pose().scale(0.5F, 0.5F, 1F);
            g.pose().translate(-px, -floor, 0);
            PetArt.draw(g, all[i], px, floor - 28, 2, ticks + i * 11, false, false, 0, "", "");
            g.pose().popPose();
            Skin.cstr(g, f, t("cutemod.pet.name." + all[i].id), px, y + 38, DARK);
            if (tk) {
                Skin.rect(g, x, y, CH_W - 4, CH_H - 4, 0xAAD8CCE2);
                Skin.cstr(g, f, t("cutemod.pet.choose.taken"), px, y + 20, 0xFF5A4A68);
            }
        }
        if (chosen >= 0) {
            boolean h = in(mx, my, AD_X, AD_Y, AD_W, AD_H);
            Skin.rect(g, AD_X, AD_Y, AD_W, AD_H, h ? 0xFFFFF3B0 : 0xFFFFE9A8);
            Skin.rect(g, AD_X, AD_Y + AD_H - 2, AD_W, 2, 0xFFD9A93A);
            String l = t("cutemod.pet.choose.adopt", t("cutemod.pet.name." + all[chosen].id));
            Skin.str(g, f, l, AD_X + (AD_W - f.width(l)) / 2, AD_Y + 4, DARK, false);
        } else {
            Skin.cstr(g, f, t("cutemod.pet.choose.pick"), W / 2, AD_Y + 4, 0xFF6A5A78);
        }
    }

    private void eggRows(GuiGraphics g, int cx, int cy, int from, int to, int fill) {
        for (int dy = from; dy <= to; dy++) {                       // the outline: one pixel wider than the egg
            double k = Math.sqrt(Math.max(0, 1 - (dy / 27.0) * (dy / 27.0)));
            int hw = (int) Math.round(20 * (dy < 0 ? 0.86 : 1.0) * k);
            Skin.rect(g, cx - hw - 1, cy + dy, 2 * hw + 3, 1, DARK);
        }
        for (int dy = from; dy <= to; dy++) {
            double k = Math.sqrt(Math.max(0, 1 - (dy / 27.0) * (dy / 27.0)));
            int hw = (int) Math.round(20 * (dy < 0 ? 0.86 : 1.0) * k);
            Skin.rect(g, cx - hw, cy + dy, 2 * hw + 1, 1, fill);
            if (dy > -20 && dy < 6 && hw > 6) Skin.rect(g, cx - hw + 3, cy + dy, 2, 1, 0x66FFFFFF);
        }
    }

    private static void crack(GuiGraphics g, int x, int y, int len, int dir) {
        int off = 0;
        for (int i = 0; i < len; i++) {
            Skin.rect(g, x + off, y + i * 2, 2, 2, DARK);
            off += (i % 2 == 0 ? 2 : -1) * dir;
        }
    }

    private void renderEgg(GuiGraphics g, Font f, int mx, int my) {
        int hatching = setup == 3 ? hatchT : -1;
        int body = sp.bodyColor | 0xFF000000, shellCol = mix(body, 0xFFFFFF, 0.7f), spot = mix(body, 0xFFFFFF, 0.2f);
        int ex = CX + (shake > 0 ? (int) Math.round(Math.sin(shake * 1.3) * 3) : 0)
                + (hatching >= 0 && hatching < 62 ? (int) Math.round(Math.sin(hatching * 1.1) * (1 + hatching / 15)) : 0);
        int ey = EGG_Y + (int) Math.round(Math.sin(ticks / 25.0) * 1.2);
        Skin.rect(g, CX - 22, FLOOR, 44, 3, 0x33000000);
        if (hatching < 62) {                                           // the whole egg, with cracks that grow
            eggRows(g, ex, ey, -27, 27, shellCol);
            Skin.disc(g, ex - 9, ey - 6, 4, spot);
            Skin.disc(g, ex + 8, ey + 6, 5, spot);
            Skin.disc(g, ex - 3, ey + 17, 3, spot);
            Skin.disc(g, ex + 5, ey - 16, 2, spot);
            int c = eggTaps + (hatching >= 0 ? 3 : 0);
            if (c >= 3) crack(g, ex - 2, ey - 24, 5, 1);
            if (c >= 5) crack(g, ex + 5, ey - 8, 6, -1);
            if (c >= 7) crack(g, ex - 8, ey + 2, 6, 1);
            if (c >= 9) crack(g, ex + 6, ey + 10, 5, 1);
        } else {                                                       // the shell breaks: the top flies away, the bottom stays
            int t = hatchT - 62;
            eggRows(g, CX, ey, 8, 27, shellCol);
            for (int x = -16; x <= 14; x += 6) Skin.rect(g, CX + x, ey + 5, 3, 3, shellCol);
            if (t < 55) eggRows(g, CX - (int) (t * 0.8), ey - (int) (t * 1.3), -27, 3, shellCol);
            float sc = PetArt.scaleOf(0);
            g.pose().pushPose();
            g.pose().translate(CX, FLOOR, 0);
            g.pose().scale(sc, sc, 1F);
            g.pose().translate(-CX, -FLOOR, 0);
            double hop = jump > 0 ? Math.abs(Math.sin(jump * 0.2)) * 14 : 0;
            drawPet(g, CX, CY + 2 - (int) Math.round(hop), 2);
            g.pose().popPose();
        }
        for (double[] p : parts) {                                      // hearts
            int x = (int) p[0], y = (int) p[1];
            Skin.rect(g, x, y + 1, 5, 2, 0xFFFF5C93);
            Skin.rect(g, x + 1, y, 1, 1, 0xFFFF5C93);
            Skin.rect(g, x + 3, y, 1, 1, 0xFFFF5C93);
            Skin.rect(g, x + 1, y + 3, 3, 1, 0xFFFF5C93);
            Skin.rect(g, x + 2, y + 4, 1, 1, 0xFFFF5C93);
        }
        if (hatching >= 58 && hatching < 72) Skin.rect(g, 0, 0, W, H, ((72 - hatching) * 17) << 24 | 0xFFFFFF);   // the flash
        String say = setup == 2 ? t("cutemod.pet.egg.hint") : hatching >= 70 ? t("cutemod.pet.say.hatch") : "";
        if (!say.isEmpty()) {
            int w = f.width(say) + 10, bx = CX - w / 2, by = CY - 62;
            Skin.rect(g, bx - 1, by - 1, w + 2, 15, DARK);
            Skin.rect(g, bx, by, w, 13, 0xFFFFFFFF);
            Skin.rect(g, CX - 2, by + 13, 4, 1, 0xFFFFFFFF);
            Skin.rect(g, CX - 1, by + 14, 2, 2, DARK);
            Skin.str(g, f, say, bx + 5, by + 3, DARK, false);
        }
        if (setup == 2) {                                               // eight hearts: how warm the egg is
            for (int i = 0; i < 8; i++) {
                int hx = CX - 44 + i * 12, hy = 135;
                int col = i < eggTaps ? 0xFFFF5C93 : 0xFFD8CCE2;
                Skin.rect(g, hx, hy + 1, 7, 3, col);
                Skin.rect(g, hx + 1, hy, 2, 1, col);
                Skin.rect(g, hx + 4, hy, 2, 1, col);
                Skin.rect(g, hx + 1, hy + 4, 5, 1, col);
                Skin.rect(g, hx + 2, hy + 5, 3, 1, col);
            }
        }
    }


    // ---------- pet sprites ----------
    private void drawPet(GuiGraphics g, int cx, int cy, int mood) {
        PetArt.draw(g, species(), cx, cy, mood, ticks, sleeping, sick, stage(), Progress.equipped(), Progress.equippedBody());
    }

    // ---------- mini-game: where is the treat? ----------
    private int petX() { return gm != 0 ? 62 : (int) Math.round(spotX); }

    private void startGame() {
        if (sleeping) { say("cutemod.pet.say.zzz"); return; }
        if (sick) { say("cutemod.pet.say.sick_play"); shake = 30; return; }
        if (energy < 15) { say("cutemod.pet.say.tired"); shake = 30; return; }
        gm = 7; // the game menu
    }

    private void startCups() {
        gmKind = 0;
        gmRound = 0;
        gmWins = 0;
        nextRound();
    }

    private void startCatch() {
        gmKind = 1;
        gmScore = 0;
        gmWins = 0;
        gmTimer = CATCH_TICKS;
        gsay("catch_start", 2);
        ctSpawn = 20;
        falls.clear();
        gm = 8;
    }

    private void startEcho() {
        gmKind = 2;
        gmScore = 0;
        gmWins = 0;
        for (int i = 0; i < seq.length; i++) seq[i] = rnd.nextInt(4);
        ecRound = 0;
        nextEchoRound();
        gm = 9;
        gsay("echo_start", 2);
    }

    private void nextEchoRound() {
        ecRound++;
        ecShow = 0;
        ecTimer = 40;
        ecPhase = 0;
        ecLit = -1;
        ecIn = 0;
    }

    /** A short line of the pet during a mini game: one of n of this kind. */
    private void gsay(String kind, int n) { say("cutemod.pet.game.say." + kind + "." + rnd.nextInt(n)); }

    private void nextRound() {
        gmRound++;
        gsay("cups", 4);
        gmTreat = rnd.nextInt(3);
        for (int i = 0; i < 3; i++) gmSlot[i] = i;
        gmPicked = -1;
        gm = 1;
        gmTimer = 100;                       // the treat is shown
        gmSwapsLeft = 5 + gmRound * 3;       // more and faster swaps every round
        gmSwapDur = Math.max(9, 24 - gmRound * 6);
        gmSwapT = 0;
    }

    private void pickSwap() {
        gmA = rnd.nextInt(3);
        do { gmB = rnd.nextInt(3); } while (gmB == gmA);
        gmSwapT = 0;
    }

    private void gameTick() {
        switch (gm) {
            case 1 -> { if (--gmTimer <= 0) { gm = 2; gmTimer = 20; } }
            case 2 -> { if (--gmTimer <= 0) { gm = 3; pickSwap(); } }
            case 3 -> {
                if (++gmSwapT >= gmSwapDur) {
                    int t = gmSlot[gmA]; gmSlot[gmA] = gmSlot[gmB]; gmSlot[gmB] = t;
                    if (--gmSwapsLeft <= 0) gm = 4; else pickSwap();
                }
            }
            case 5 -> { if (--gmTimer <= 0) { if (gmRound >= GM_ROUNDS) finishGame(); else nextRound(); } }
            case 6 -> { if (--gmTimer <= 0) gm = 0; }
            case 8 -> catchTick();
            case 9 -> echoTick();
            default -> { }
        }
    }

    private void pickCup(int c) {
        gmPicked = c;
        if (c == gmTreat) {
            gmWins++;
            jump = 60;
            burst(0, 5);
            sound(1.8F);
            say("cutemod.pet.say.game_win");
        } else {
            shake = 30;
            sound(0.7F);
            say("cutemod.pet.say.game_lose");
        }
        gm = 5;
        gmTimer = 70;
    }

    /** Prizes: 2 coins per found treat, +4 for all three; at most 5 prized games a day (it is play, not a job). */
    private void finishGame() {
        int today = (int) (System.currentTimeMillis() / 86_400_000L);
        if (Progress.count("pg_day") != today) { Progress.setCount("pg_day", today); Progress.setCount("pg_n", 0); }
        int n = Progress.count("pg_n");
        gmPrize = n < GM_DAILY;
        Progress.setCount("pg_n", n + 1);
        gmCoins = gmPrize ? gmWins * 2 + (gmWins == GM_ROUNDS ? 4 : 0) : 0;
        if (gmCoins > 0) Progress.earn(gmCoins);
        Progress.bump("pet_games");
        if (gmWins == GM_ROUNDS) Progress.bump("pet_perfect");
        fun = clamp(fun + 15 + gmWins * 5);
        energy = clamp(energy - 10);
        food = clamp(food - 3);
        if (gmWins > 0) { jump = 60; burst(0, 4); }
        gm = 6;
        gmTimer = 160;
    }

    private void gameClick(int x, int y) {
        if (in(x, y, 105, BTN_Y, BTN_W, BTN_H)) { gm = 0; return; } // quit / ok
        if (gm == 7) {
            for (int i = 0; i < 3; i++) {
                if (in(x, y, AX + 4, 50 + i * 28, AW - 8, 24)) {
                    if (i == 0) startCups(); else if (i == 1) startCatch(); else startEcho();
                    return;
                }
            }
            return;
        }
        if (gm == 8) { catchClick(x, y); return; }
        if (gm == 9) { echoClick(x, y); return; }
        if (gm == 4) {
            for (int c = 0; c < 3; c++) {
                if (in(x, y, CUP_X[gmSlot[c]], CUP_Y - 4, CUP_W, CUP_H + 4)) { pickCup(c); return; }
            }
        }
    }

    private int cupLift(int c) {
        return switch (gm) {
            case 1 -> c == gmTreat ? 22 : 0;
            case 2 -> c == gmTreat ? 22 * gmTimer / 20 : 0;
            case 5, 6 -> 22;
            default -> 0;
        };
    }

    // ---------- mini-game 2: catch the treats ----------
    private void catchTick() {
        int elapsed = CATCH_TICKS - gmTimer;
        if (--gmTimer <= 0) { endRun(catchStars()); return; }
        if (--ctSpawn <= 0) {
            ctSpawn = 36 - elapsed * 14 / CATCH_TICKS;
            boolean bad = rnd.nextInt(5) == 0;
            falls.add(new double[]{AX + 8 + rnd.nextInt(AW - 26), AY,
                    0.45 + elapsed * 0.5 / CATCH_TICKS + rnd.nextDouble() * 0.2, bad ? 4 : rnd.nextInt(4)});
        }
        for (int i = falls.size() - 1; i >= 0; i--) {
            double[] p = falls.get(i);
            p[1] += p[2];
            if (p[1] >= AG - 10) falls.remove(i);
        }
    }

    private int catchStars() { return gmScore >= 18 ? 3 : gmScore >= 11 ? 2 : gmScore >= 5 ? 1 : 0; }

    private void catchClick(int x, int y) {
        for (int i = falls.size() - 1; i >= 0; i--) {
            double[] p = falls.get(i);
            if (!in(x, y, (int) p[0] - 3, (int) p[1] - 3, 16, 16)) continue;
            falls.remove(i);
            if (p[3] == 4) { gmScore = Math.max(0, gmScore - 2); shake = 20; sound(0.6F); gsay("catch_bad", 3); }
            else { gmScore++; jump = Math.max(jump, 10); sound(1.3F + Math.min(gmScore, 20) * 0.03F); if (gmScore % 5 == 0) gsay("catch_good", 3); }
            return;
        }
    }

    private void renderCatch(GuiGraphics g, Font f, int mx, int my, int mid) {
        String head = t("cutemod.pet.game.catch_head", gmScore, Math.max(0, (gmTimer + 59) / 60));
        Skin.str(g, f, head, mid - f.width(head) / 2, 34, DARK, false);
        Skin.rect(g, AX, AY - 2, AW, AG - AY + 2, 0x33FFFFFF);
        Skin.rect(g, AX, AG, AW, 2, 0xFFB98F5E);
        for (double[] p : falls) {
            int x = (int) p[0], y = (int) p[1];
            if (p[3] == 4) { // a bad one: a green blob with a grumpy face
                Skin.disc(g, x + 5, y + 5, 6, 0xFF6A8A3A);
                Skin.rect(g, x + 2, y + 3, 2, 2, 0xFF2A1A2A); Skin.rect(g, x + 7, y + 3, 2, 2, 0xFF2A1A2A);
                Skin.rect(g, x + 3, y + 8, 5, 1, 0xFF2A1A2A);
            } else {
                drawTreat(g, TREATS[(int) p[3]], x, y);
            }
        }
        String hint = t("cutemod.pet.game.catch_hint");
        Skin.str(g, f, hint, mid - f.width(hint) / 2, FLOOR + 5, DARK, false);
    }

    // ---------- mini-game 3: copy the pet (like Simon) ----------
    private static int padX(int p) { return AX + p * (PAD_W + 8); }

    private void light(int p, int dur) {
        ecLit = p;
        ecLitT = dur;
        sound(PAD_PITCH[p]);
    }

    private void echoTick() {
        if (ecLitT > 0 && --ecLitT == 0) ecLit = -1;
        switch (ecPhase) {
            case 0 -> { // the pet shows the pads one by one
                if (--ecTimer > 0) return;
                if (ecShow >= ecRound + 1) { ecPhase = 1; ecIn = 0; return; }
                light(seq[ecShow++], 24);
                ecTimer = 36;
            }
            case 2 -> { if (--ecTimer <= 0) nextEchoRound(); }          // right: the next round
            case 3 -> { if (--ecTimer <= 0) endRun(echoStars()); }      // wrong: the game ends
            default -> { }
        }
    }

    private int echoStars() { return gmScore >= 5 ? 3 : gmScore >= 3 ? 2 : gmScore >= 1 ? 1 : 0; }

    private void echoClick(int x, int y) {
        if (ecPhase != 1) return;
        for (int p = 0; p < 4; p++) {
            if (!in(x, y, padX(p), PAD_Y, PAD_W, PAD_H)) continue;
            light(p, 12);
            if (p == seq[ecIn]) {
                if (++ecIn >= ecRound + 1) {
                    gmScore++;
                    jump = Math.max(jump, 12);
                    if (ecRound >= ECHO_ROUNDS) { endRun(echoStars()); return; }
                    ecPhase = 2;
                    ecTimer = 45;
                    gsay("echo_ok", 3);
                }
            } else {
                ecPhase = 3;
                ecTimer = 45;
                ecBad = p;
                shake = 20;
                gsay("echo_bad", 3);
            }
            return;
        }
    }

    private void renderEcho(GuiGraphics g, Font f, int mx, int my, int mid) {
        String head = t("cutemod.pet.game.echo_head", Math.min(ecRound, ECHO_ROUNDS), ECHO_ROUNDS);
        Skin.str(g, f, head, mid - f.width(head) / 2, 56, DARK, false);
        for (int p = 0; p < 4; p++) {
            int x = padX(p), col = PAD_COL[p];
            boolean lit = ecLit == p, hover = ecPhase == 1 && in(mx, my, x, PAD_Y, PAD_W, PAD_H);
            if (lit) Skin.rect(g, x - 2, PAD_Y - 2, PAD_W + 4, PAD_H + 4, 0xFFFFFFFF);
            Skin.rect(g, x, PAD_Y, PAD_W, PAD_H, lit ? mix(col, 0xFFFFFF, 0.55f) : hover ? col : mix(col, 0x000000, 0.2f));
            Skin.rect(g, x + 3, PAD_Y + 3, PAD_W - 6, 3, 0x55FFFFFF);
            if (ecPhase == 3 && ecBad == p) Skin.rect(g, x, PAD_Y + PAD_H, PAD_W, 3, 0xFFE5484D);
        }
        String hint = ecPhase == 0 ? t("cutemod.pet.game.echo_watch") : ecPhase == 1 ? t("cutemod.pet.game.echo_go") : "";
        if (!hint.isEmpty()) Skin.str(g, f, hint, mid - f.width(hint) / 2, FLOOR + 5, DARK, false);
    }

    /** A new game ended: 0-3 stars, the same prizes as the cups (2 coins per star, +4 for 3 stars). */
    private void endRun(int stars) {
        gmWins = stars;
        finishGame();
    }

    private void renderMenu(GuiGraphics g, Font f, int mx, int my) {
        String h = t("cutemod.pet.game.menu");
        Skin.str(g, f, h, AX + AW / 2 - f.width(h) / 2, 38, DARK, false);
        for (int i = 0; i < 3; i++) {
            int y = 50 + i * 28;
            boolean hover = in(mx, my, AX + 4, y, AW - 8, 24);
            Skin.rect(g, AX + 4, y, AW - 8, 24, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
            Skin.rect(g, AX + 4, y + 22, AW - 8, 2, 0xFFB9A8C8);
            String n = t("cutemod.pet.game.m" + i);
            Skin.str(g, f, n, AX + AW / 2 - f.width(n) / 2, y + 8, DARK, false);
        }
    }

    private void gameBar(GuiGraphics g, Font f, int mx, int my) {
        Skin.rect(g, 0, BTN_Y - 4, W, H - BTN_Y + 4, mix(shell.color().bodyColor, 0x000000, 0.35f));
        boolean hover = in(mx, my, 105, BTN_Y, BTN_W, BTN_H);
        Skin.rect(g, 105, BTN_Y, BTN_W, BTN_H, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
        Skin.rect(g, 105, BTN_Y + BTN_H - 2, BTN_W, 2, 0xFFB9A8C8);
        String label = t(gm == 6 ? "cutemod.pet.game.ok" : "cutemod.pet.game.quit");
        Skin.str(g, f, label, 105 + (BTN_W - f.width(label)) / 2, BTN_Y + 4, DARK, false);
    }

    private void renderGame(GuiGraphics g, Font f, int mx, int my) {
        int mid = (CUP_X[0] + CUP_X[2] + CUP_W) / 2;
        if (gm == 7) { renderMenu(g, f, mx, my); gameBar(g, f, mx, my); return; }
        if (gmKind != 0) {
            if (gm == 8) renderCatch(g, f, mx, my, mid);
            else if (gm == 9) renderEcho(g, f, mx, my, mid);
        } else {
        String head = t("cutemod.pet.game.round", Math.min(gmRound, GM_ROUNDS), GM_ROUNDS, gmWins);
        Skin.str(g, f, head, mid - f.width(head) / 2, 56, DARK, false);
        // cups (the treat sits under the right one)
        for (int c = 0; c < 3; c++) {
            double cx = CUP_X[gmSlot[c]], dy = 0;
            if (gm == 3 && (c == gmA || c == gmB)) {
                double u = gmSwapT / (double) gmSwapDur;
                int other = c == gmA ? gmB : gmA;
                cx = CUP_X[gmSlot[c]] + (CUP_X[gmSlot[other]] - CUP_X[gmSlot[c]]) * u;
                dy = (c == gmA ? -1 : 1) * Math.sin(Math.PI * u) * 7;
            }
            int x = (int) Math.round(cx), lift = cupLift(c), y = CUP_Y + (int) Math.round(dy) - lift;
            if (lift > 0 && c == gmTreat) drawTreat(g, "treat_cookie", x + CUP_W / 2 - 5, CUP_Y + CUP_H - 12);
            boolean hover = gm == 4 && in(mx, my, x, CUP_Y - 4, CUP_W, CUP_H + 4);
            int col = CUP_COL[c];
            Skin.rect(g, x - 2, y, CUP_W + 4, 5, mix(col, 0x000000, 0.2f));
            Skin.rect(g, x, y + 5, CUP_W, CUP_H - 5, hover ? mix(col, 0xFFFFFF, 0.4f) : col);
            Skin.rect(g, x + 4, y + 8, 4, CUP_H - 12, 0x55FFFFFF);
            if (gm >= 5 && c == gmPicked) Skin.rect(g, x, y + CUP_H, CUP_W, 2, c == gmTreat ? 0xFF5BBF6A : 0xFFE5484D);
        }
        String hint = switch (gm) {
            case 1 -> t("cutemod.pet.game.watch");
            case 2, 3 -> t("cutemod.pet.game.shuffle");
            case 4 -> t("cutemod.pet.game.pick");
            default -> "";
        };
        if (!hint.isEmpty()) Skin.str(g, f, hint, mid - f.width(hint) / 2, FLOOR + 5, DARK, false);
        }
        if (gm == 6) {
            String l1 = gmKind == 0 ? t("cutemod.pet.game.found", gmWins, GM_ROUNDS)
                    : t(gmKind == 1 ? "cutemod.pet.game.res.catch" : "cutemod.pet.game.res.echo", gmScore);
            String l2 = gmCoins > 0 ? t("cutemod.pet.game.coins", gmCoins)
                    : t(gmPrize ? "cutemod.pet.game.noprize" : "cutemod.pet.game.limit");
            int w = Math.max(f.width(l1), f.width(l2)) + 14, bx = mid - w / 2;
            Skin.rect(g, bx - 1, 41, w + 2, 25, 0xFF3A2A3A);
            Skin.rect(g, bx, 42, w, 23, 0xFFFFFFFF);
            Skin.str(g, f, l1, mid - f.width(l1) / 2, 46, DARK, false);
            Skin.str(g, f, l2, mid - f.width(l2) / 2, 56, gmCoins > 0 ? 0xFFB98A10 : 0xFF8A7AA8, false);
        }
        gameBar(g, f, mx, my);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (hosted != null) return hosted.click(x, y, button);
        if (setup != 0) return setupClick(x, y);
        if (showUi != null) return showUi.click(x, y);
        if (parkUi != null) return parkUi.click(x, y);
        if (tripUi != null) return tripUi.click(x, y, button);
        if (mapUi != null) return mapUi.click(x, y, button);
        if (placeUi != null) return placeUi.click(x, y, button);
        if (roomUi != null) return roomUi.click(x, y, button);
        if (pantryUi != null) return pantryUi.click(x, y, button);
        if (Trip.awayFor(species())) return true;
        if (gm != 0) { gameClick(x, y); return true; }
        int[] tg = tagRect();
        if (in(x, y, tg[0], 2, tg[1], 11)) { openRename(); return true; }
        if (in(x, y, TB_X, TB_Y, TB_W, TB_H)) { openMap(); return true; }
        if (in(x, y, RB_X, RB_Y, RB_W, RB_H)) { openRoom(); return true; }
        if (in(x, y, GB_X, GB_Y, GB_W, GB_H)) { startGame(); return true; }
        for (int i = 0; i < TREATS.length; i++) {
            if (in(x, y, SLOT_X + i * SLOT_W, SLOT_Y, SLOT_W - 2, SLOT_H)) { giveTreat(i); return true; }
        }
        for (int i = 0; i < 3; i++) {
            if (in(x, y, BTN_X[i], BTN_Y, BTN_W, BTN_H)) {
                switch (i) {
                    case 0 -> feed();
                    case 1 -> play();
                    default -> toggleSleep();
                }
                return true;
            }
        }
        if (in(x, y, petX() - 30, CY - (int) Math.round(spotLift) - 36, 60, 62)) { pet(); return true; }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        if (hosted != null) return hosted.scroll(amount);
        if (roomUi != null) return roomUi.scroll(amount);
        if (pantryUi != null) return pantryUi.scroll(amount);
        if (mapUi != null) return mapUi.scroll(amount);
        return tripUi != null && tripUi.scroll(amount);
    }

    @Override
    public boolean canBack() {
        if (hosted != null) return true;                               // a little app inside: back to the map
        if (setup == 5) return true;                                    // the rename form: back to the room
        if (setup != 0) return false;                                   // choosing the pet, its name, the egg: nothing to go back to
        if (mapUi != null) return false;                                // the map is the top of CutePet
        return parkUi != null || tripUi != null || placeUi != null || roomUi != null || pantryUi != null || showUi != null || gm != 0
                || !Trip.awayFor(species());                            // the room itself: back to the map
    }

    @Override
    public void back() { key(256, 0); }                                   // the same as Escape on every screen of the pet

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (hosted != null) {
            if (keyCode == 256) {                                       // Escape / Back: one step back inside the app, then out to the map
                if (hosted.canBack()) { hosted.back(); return true; }
                if (hosted.key(keyCode, modifiers)) return true;
                leaveHosted();
                return true;
            }
            return hosted.key(keyCode, modifiers);
        }
        if (setup != 0) return setupKey(keyCode);
        if (showUi != null) return showUi.key(keyCode);
        if (parkUi != null) return parkUi.key(keyCode);
        if (tripUi != null) return tripUi.key(keyCode);
        if (mapUi != null) return mapUi.key(keyCode);
        if (placeUi != null) return placeUi.key(keyCode);
        if (roomUi != null) return roomUi.key(keyCode);
        if (pantryUi != null) return pantryUi.key(keyCode);
        if (Trip.awayFor(species())) return false;
        if (gm != 0) {
            if (keyCode == 256) { gm = 0; return true; } // escape leaves the game, not the computer
            return false;
        }
        if (keyCode == 256) { openMap(); return true; }   // the room: back to the map
        switch (keyCode) {
            case 49 -> feed();          // 1
            case 50 -> play();          // 2
            case 51 -> toggleSleep();   // 3
            default -> { return false; }
        }
        return true;
    }
}
