package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;

import java.util.List;

/** What an app can ask of the computer it is running on. */
public interface Shell {
    /** Open an app (the previous one is closed). */
    void open(App app);

    /** Open the app with this Dock number (brings back its process if it is running). */
    default void launch(int icon) {}

    /**
     * The program with this Dock number as a part of the calling app (the pet map shows school, farm, the shops... inside
     * CutePet instead of as separate programs of the Task Manager). Null if it cannot be shown that way right now
     * (it is not installed, or it already runs as a program of its own): then the caller uses {@link #launch}.
     */
    default App embed(int icon) { return null; }

    /** Like {@link #launch}, but the window grows out of this screen position (a folder on the desktop). */
    default void launchFrom(int icon, int screenX, int screenY) { launch(icon); }

    /** Go back to the desktop. */
    void home();
    /** Start the screensaver now (a preview). */
    default void saver() {}
    /** A blue screen (a test, or the terminal command "crash"). */
    default void crash() {}
    /** Install OS update number idx. */
    default void installUpdate(int idx) {}

    /** One running program, for the Task Manager. icon = its Dock number (-1 = none), front = the app the player was using. */
    record Proc(App app, String name, int icon, boolean front) {}

    /** Every program that is running (the Task Manager itself is left out). */
    default List<Proc> processes() { return List.of(); }

    /** Bring this program to the front and close the Task Manager (null = the desktop). */
    default void switchTo(App app) {}

    /** End this program's process. */
    default void endTask(App app) {}

    /** Where this computer stands (the server checks orders and pick-ups against it). */
    net.minecraft.core.BlockPos pos();

    /** Color of this computer (also decides its "own" game). */
    ComputerColor color();

    /** Ask to open a real web address (the player confirms first, then it opens in the system browser). */
    void openLink(String url);

    /** A game finished with this score. Only the computer's own game counts for its record. */
    void submitScore(ComputerColor game, int score);

    /** Absolute GUI position of the top-left corner of the app area (for scissor). */
    int absX();

    int absY();
}
