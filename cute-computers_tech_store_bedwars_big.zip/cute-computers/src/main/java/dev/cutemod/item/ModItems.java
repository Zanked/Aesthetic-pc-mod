package dev.cutemod.item;

import dev.cutemod.CuteMod;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Real Minecraft items that CuteMarket delivers. The ids match {@code Market.ITEMS} (cupcake, icecream...),
 * so the server can hand out exactly what was ordered. Each food gives hunger plus a short effect.
 */
public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CuteMod.MOD_ID);

    /** The portable music player: right-click opens it, sneak + right-click plays or pauses. */
    public static final DeferredItem<Item> MUSIC_PLAYER = ITEMS.register("music_player",
            () -> new MusicPlayerItem(new Item.Properties().stacksTo(1)));

    /** The material of the headphones: no armor at all, only a texture for the head (textures/models/armor/headphones[_colour]_layer_1.png). */
    public static final DeferredRegister<net.minecraft.world.item.ArmorMaterial> ARMOR_MATERIALS =
            DeferredRegister.create(net.minecraft.core.registries.Registries.ARMOR_MATERIAL, CuteMod.MOD_ID);

    private static DeferredHolder<net.minecraft.world.item.ArmorMaterial, net.minecraft.world.item.ArmorMaterial> phonesMaterial(String name) {
        return ARMOR_MATERIALS.register(name, () -> {
            java.util.EnumMap<net.minecraft.world.item.ArmorItem.Type, Integer> def = new java.util.EnumMap<>(net.minecraft.world.item.ArmorItem.Type.class);
            for (net.minecraft.world.item.ArmorItem.Type t : net.minecraft.world.item.ArmorItem.Type.values()) def.put(t, 0);
            return new net.minecraft.world.item.ArmorMaterial(def, 0, net.minecraft.sounds.SoundEvents.ARMOR_EQUIP_GENERIC,
                    () -> net.minecraft.world.item.crafting.Ingredient.EMPTY,
                    List.of(new net.minecraft.world.item.ArmorMaterial.Layer(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, name))),
                    0F, 0F);
        });
    }

    public static final DeferredHolder<net.minecraft.world.item.ArmorMaterial, net.minecraft.world.item.ArmorMaterial> HEADPHONES_MATERIAL = phonesMaterial("headphones");

    /** The headphones (head slot): the portable player plays only in them, and the world gets quieter. */
    public static final DeferredItem<Item> HEADPHONES = ITEMS.register("headphones",
            () -> new HeadphonesItem(HEADPHONES_MATERIAL, new Item.Properties().stacksTo(1)));

    /** The same headphones in the colours of the players (the lavender ones are "headphones"). Dye + any headphones = that colour. */
    public static final Map<String, DeferredItem<Item>> COLOR_HEADPHONES = new LinkedHashMap<>();
    static {
        for (String c : new String[]{"pink", "green", "white", "blue", "orange", "purple", "yellow", "red", "snow", "santa", "ice", "panda", "starry", "sakura", "mint", "bee", "rgb"}) {   // snow..ice: winter, panda..bee: skins, rgb: glowing rainbow
            var mat = phonesMaterial("headphones_" + c);
            COLOR_HEADPHONES.put(c, ITEMS.register("headphones_" + c, () -> new HeadphonesItem(mat, new Item.Properties().stacksTo(1))));
        }
    }

    /** Any of the headphones (every colour)? */
    public static boolean isHeadphones(ItemStack st) { return st.getItem() instanceof HeadphonesItem; }

    /** The same player in the colours of the computers (music_player itself is the lavender one). Dye + any player = that colour. */
    public static final String[] PLAYER_COLORS = {"pink", "green", "white", "blue", "orange", "purple", "yellow", "red", "snow", "santa"};   // snow and santa: the winter ones
    public static final Map<String, DeferredItem<Item>> COLOR_PLAYERS = new LinkedHashMap<>();
    static {
        for (String c : PLAYER_COLORS)
            COLOR_PLAYERS.put(c, ITEMS.register("music_player_" + c, () -> new MusicPlayerItem(new Item.Properties().stacksTo(1))));
    }

    /** The cases of the portable player (the number in the list + 1 is the custom model data of the player, see the player models). */
    public static final String[] CASE_IDS = {"starry", "sakura", "mint", "bee"};
    public static final Map<String, DeferredItem<Item>> CASES = new LinkedHashMap<>();
    static {
        for (int i = 0; i < CASE_IDS.length; i++) {
            int n = i + 1;
            CASES.put(CASE_IDS[i], ITEMS.register("player_case_" + CASE_IDS[i], () -> new PlayerCaseItem(new Item.Properties().stacksTo(16), n)));
        }
    }

    /** The case with this number (1...), or an empty stack. */
    public static ItemStack caseStack(int number) {
        return number < 1 || number > CASE_IDS.length ? ItemStack.EMPTY : new ItemStack(CASES.get(CASE_IDS[number - 1]).get());
    }

    /** The upgrade parts of the computer (memory, video cards, drives), by item id: pc_ram_16, pc_gpu_4, pc_disk_96 (see PcHardware). */
    public static final Map<String, DeferredItem<Item>> PC_PARTS = new LinkedHashMap<>();
    private static final Map<String, int[]> PART_INFO = new LinkedHashMap<>();   // id -> {kind ordinal, level}
    static {
        for (dev.cutemod.data.PcHardware.Kind k : dev.cutemod.data.PcHardware.Kind.values()) {
            for (int lv = dev.cutemod.data.PcHardware.first(k); lv <= dev.cutemod.data.PcHardware.last(k); lv++) {
                final dev.cutemod.data.PcHardware.Kind kind = k;
                final int level = lv;
                String id = dev.cutemod.data.PcHardware.partId(k, lv);
                PART_INFO.put(id, new int[]{k.ordinal(), lv});
                PC_PARTS.put(id, ITEMS.register(id, () -> new PcPartItem(new Item.Properties().stacksTo(16), kind, level)));
            }
        }
    }

    /** One part of this kind and level, or an empty stack if there is no such part. */
    public static ItemStack partStack(dev.cutemod.data.PcHardware.Kind kind, int level) {
        DeferredItem<Item> d = PC_PARTS.get(dev.cutemod.data.PcHardware.partId(kind, level));
        return d == null ? ItemStack.EMPTY : new ItemStack(d.get());
    }

    /** One part by its shop id (pc_ram_16...), or an empty stack. */
    public static ItemStack partStack(String id) {
        int router = dev.cutemod.data.WifiNet.levelOf(id);                  // the Wi-Fi routers are sold next to the parts
        if (router > 0) return dev.cutemod.block.ModBlocks.routerStack(router);
        DeferredItem<Item> d = PC_PARTS.get(id);
        return d == null ? ItemStack.EMPTY : new ItemStack(d.get());
    }

    /** The kind and the level of a part by its id, or null. */
    public static int[] partInfo(String id) { return PART_INFO.get(id); }

    private static final Map<String, DeferredItem<Item>> FOODS = new LinkedHashMap<>();
    private static final Map<String, int[]> SHOP = new LinkedHashMap<>(); // id -> {price in coins, delivery seconds}

    /** A food (or a drink, raised like a potion) that shows its effect in the tooltip. */
    private static final class CuteFood extends Item {
        private final boolean drink;
        private final Holder<MobEffect> effect;
        private final int seconds;

        CuteFood(Properties props, boolean drink, Holder<MobEffect> effect, int seconds) {
            super(props);
            this.drink = drink;
            this.effect = effect;
            this.seconds = seconds;
        }

        @Override
        public UseAnim getUseAnimation(ItemStack stack) { return drink ? UseAnim.DRINK : super.getUseAnimation(stack); }

        @Override
        public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
            if (effect != null) tip.add(Component.translatable("cutemod.tip.effect", effect.value().getDisplayName(), seconds).withStyle(ChatFormatting.BLUE));
        }
    }

    private static void food(String id, int price, int deliverySecs, int nutrition, float saturation, boolean drink,
                             Holder<MobEffect> effect, int seconds, int amplifier) {
        SHOP.put(id, new int[]{price, deliverySecs});
        FoodProperties.Builder b = new FoodProperties.Builder()
                .nutrition(nutrition)
                .saturationModifier(saturation)
                .alwaysEdible(); // the effect is the point, so you can eat when full
        if (effect != null) b.effect(() -> new MobEffectInstance(effect, seconds * 20, amplifier), 1.0F);
        FoodProperties props = b.build();
        FOODS.put(id, ITEMS.register(id, () -> {
            Item.Properties p = new Item.Properties().food(props);
            return new CuteFood(p, drink, effect, seconds);
        }));
    }

    static {
        //   id         coins  delivery  hunger sat    drink  effect                       sec amp
        food("cupcake",     8,  25,  4, 0.4F, false, MobEffects.MOVEMENT_SPEED,    20, 0);
        food("icecream",    9,  25,  3, 0.3F, false, MobEffects.JUMP,              20, 0);
        food("bubbletea",  10,  30,  4, 0.5F, true,  MobEffects.DIG_SPEED,         30, 0);
        food("toast",      12,  30,  5, 0.6F, false, MobEffects.ABSORPTION,        60, 0);
        food("burger",     15,  40,  8, 0.8F, false, MobEffects.DAMAGE_BOOST,      30, 0);
        food("pizza",      18,  45,  9, 0.8F, false, MobEffects.DAMAGE_RESISTANCE, 30, 0);
        food("ramen",      20,  50, 10, 1.0F, false, MobEffects.REGENERATION,      10, 0);
        food("sushi",      22,  60,  8, 1.2F, false, MobEffects.WATER_BREATHING,   90, 0);
    }

    /** The food item for a Market id, or null if the id is not a food. */
    public static Item food(String id) {
        DeferredItem<Item> d = FOODS.get(id);
        return d == null ? null : d.get();
    }

    public static boolean isFood(String id) { return SHOP.containsKey(id); }

    /** Price in coins (the server uses it to refund a refused order). */
    public static int price(String id) { return SHOP.get(id)[0]; }

    /** Normal delivery time in seconds. */
    public static int deliverySecs(String id) { return SHOP.get(id)[1]; }

    /** The ids of all foods, in catalog order. */
    public static List<String> ids() { return new ArrayList<>(SHOP.keySet()); }

    /** All foods in catalog order (for the creative tab). */
    public static List<Item> foods() {
        List<Item> out = new ArrayList<>();
        for (DeferredItem<Item> d : FOODS.values()) out.add(d.get());
        return out;
    }

    private ModItems() {}
}
