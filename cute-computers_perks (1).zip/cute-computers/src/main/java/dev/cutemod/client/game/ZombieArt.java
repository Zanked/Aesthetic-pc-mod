package dev.cutemod.client.game;

/**
 * Pixel art for Zombie Shooter, drawn by code (no image files): four detailed zombies with two walking frames each,
 * the six perk icons for the cards between rounds and the six perk vending machines for the wall.
 * Pure Java on purpose (no Minecraft classes), so tools/ZombiePreview.java can render it to a PNG.
 * Every picture is an int[row][column] of ARGB, 0 = transparent.
 */
final class ZombieArt {
    private ZombieArt() {}

    static final int ZH = 40;                                   // every zombie is 40 rows tall; 20 wide, the tank 28
    static final int ICON = 24;                                 // perk icon size
    static final int MACHINE = 32;                              // a perk machine texture is 32 x 32

    private static final int[][][][] ZOMBIES = new int[4][2][][];
    private static final int[][][] ICONS = new int[6][][];
    private static final int[][][] MACHINES = new int[6][][];
    private static final int[][][] MINI = new int[6][][];
    private static final int[][][] BOXES = new int[2][][];
    private static final int[][][] PAPS = new int[2][][];
    static final int MINI_SIZE = 12;

    /** A zombie of kind 0 normal, 1 runner, 2 tank, 3 spitter in walking frame 0 or 1. */
    static synchronized int[][] zombie(int kind, int frame) {
        int k = Math.max(0, Math.min(3, kind)), f = frame & 1;
        if (ZOMBIES[k][f] == null) ZOMBIES[k][f] = buildZombie(k, f);
        return ZOMBIES[k][f];
    }

    /** The perk card icon (ICON x ICON). perkColor is the main color of the perk. */
    static synchronized int[][] icon(int perk, int perkColor) {
        int p = Math.max(0, Math.min(5, perk));
        if (ICONS[p] == null) {
            Cv c = new Cv(ICON, ICON);
            glyph(c, p, perkColor, 1, 1, ICON - 2);
            ICONS[p] = c.finish(0xFF0C0C12, true);
        }
        return ICONS[p];
    }

    /** A 12 x 12 version of the icon for the HUD (drawn small, not shrunk, so the lines stay clean). */
    static synchronized int[][] miniIcon(int perk, int perkColor) {
        int p = Math.max(0, Math.min(5, perk));
        if (MINI[p] == null) {
            Cv c = new Cv(MINI_SIZE, MINI_SIZE);
            glyph(c, p, perkColor, 0.5, 0.5, MINI_SIZE - 1);
            MINI[p] = c.finish(0xFF0C0C12, false);
        }
        return MINI[p];
    }

    /** The front of a perk vending machine (MACHINE x MACHINE texels). */
    static synchronized int[][] machine(int perk, int perkColor) {
        int p = Math.max(0, Math.min(5, perk));
        if (MACHINES[p] == null) MACHINES[p] = buildMachine(p, perkColor);
        return MACHINES[p];
    }

    /** The front of the mystery box: a long wooden crate with glowing question marks (closed), or with its lid up and a beam of light (open). 32 x 32. */
    static synchronized int[][] mysteryBox(boolean open) {
        int k = open ? 1 : 0;
        if (BOXES[k] == null) BOXES[k] = buildBox(open);
        return BOXES[k];
    }

    /** The front of the Pack-a-Punch machine (32 x 32): a rusty steel bowl on legs with three drums, a green band and a big sign; active = the drums turn and glow. */
    static synchronized int[][] papMachine(boolean active) {
        int k = active ? 1 : 0;
        if (PAPS[k] == null) PAPS[k] = buildPap(active);
        return PAPS[k];
    }

    // =====================================================================================================
    // small drawing kit
    // =====================================================================================================
    static int shade(int c, double f) {
        int a = c >>> 24, r = (int) Math.min(255, ((c >> 16) & 255) * f), g = (int) Math.min(255, ((c >> 8) & 255) * f), b = (int) Math.min(255, (c & 255) * f);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int mix(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t),
                bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int hash(int a, int b) {
        int h = a * 374761393 + b * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        return (h ^ (h >>> 16)) & 0x7FFFFFFF;
    }

    /** A canvas. Shapes are filled by pixel centers, so the same code draws at any size. "fixed" pixels (glow, teeth, eyes) skip the shading. */
    private static final class Cv {
        final int w, h;
        final int[] p;
        final boolean[] fixed;

        Cv(int w, int h) { this.w = w; this.h = h; p = new int[w * h]; fixed = new boolean[w * h]; }

        void set(int x, int y, int c, boolean fx) {
            if (x < 0 || y < 0 || x >= w || y >= h) return;
            p[y * w + x] = c;
            fixed[y * w + x] = fx;
        }

        /** Rectangle from (x0,y0) up to but not including (x1,y1). */
        void rect(double x0, double y0, double x1, double y1, int c) { rect(x0, y0, x1, y1, c, false); }

        void rect(double x0, double y0, double x1, double y1, int c, boolean fx) {
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                double cx = x + 0.5, cy = y + 0.5;
                if (cx >= x0 && cx < x1 && cy >= y0 && cy < y1) set(x, y, c, fx);
            }
        }

        /** Same as rect but with a darker edge of 1 pixel in its own color. */
        void rectO(double x0, double y0, double x1, double y1, int c) {
            rect(x0, y0, x1, y1, shade(c, 0.55));
            rect(x0 + 1, y0 + 1, x1 - 1, y1 - 1, c);
        }

        void ell(double cx, double cy, double rx, double ry, int c) { ell(cx, cy, rx, ry, c, false); }

        void ell(double cx, double cy, double rx, double ry, int c, boolean fx) {
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                double dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
                if (dx * dx + dy * dy <= 1) set(x, y, c, fx);
            }
        }

        void ellO(double cx, double cy, double rx, double ry, int c) {
            ell(cx, cy, rx, ry, shade(c, 0.55));
            ell(cx, cy, rx - 1, ry - 1, c);
        }

        /** A thick line made of discs. */
        void line(double x0, double y0, double x1, double y1, double th, int c) {
            int n = (int) Math.ceil(Math.hypot(x1 - x0, y1 - y0) * 3) + 1;
            for (int i = 0; i <= n; i++) {
                double t = i / (double) n;
                ell(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, th / 2, th / 2, c);
            }
        }

        /** A filled polygon, even-odd rule. */
        void poly(double[] xs, double[] ys, int c) {
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                double px = x + 0.5, py = y + 0.5;
                boolean in = false;
                for (int i = 0, j = xs.length - 1; i < xs.length; j = i++) {
                    if ((ys[i] > py) != (ys[j] > py) && px < (xs[j] - xs[i]) * (py - ys[i]) / (ys[j] - ys[i]) + xs[i]) in = !in;
                }
                if (in) set(x, y, c, false);
            }
        }

        /** A ring (or part of it): radii and an angle range in degrees (0 = right, 90 = down). */
        void ring(double cx, double cy, double r0, double r1, double a0, double a1, int c) {
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                double dx = x + 0.5 - cx, dy = y + 0.5 - cy, d = Math.hypot(dx, dy);
                if (d < r0 || d > r1) continue;
                double a = Math.toDegrees(Math.atan2(dy, dx));
                if (a < 0) a += 360;
                if (a >= a0 && a <= a1) set(x, y, c, false);
            }
        }

        void clear(int x, int y) { if (x >= 0 && y >= 0 && x < w && y < h) { p[y * w + x] = 0; fixed[y * w + x] = false; } }

        boolean solid(int x, int y) { return x >= 0 && y >= 0 && x < w && y < h && (p[y * w + x] >>> 24) != 0; }

        /**
         * Shading and the black outline: pixels on the left / top edge of a shape get brighter, on the right / bottom darker,
         * and every pixel gets a little noise so the skin and cloth do not look flat. Empty pixels next to the shape become the outline.
         */
        int[][] finish(int outline, boolean rim) {
            int[][] out = new int[h][w];
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                int c = p[y * w + x];
                if ((c >>> 24) == 0) {
                    if (outline != 0 && (solid(x - 1, y) || solid(x + 1, y) || solid(x, y - 1) || solid(x, y + 1))) out[y][x] = outline;
                    continue;
                }
                if (!fixed[y * w + x]) {
                    double f = 1;
                    if (rim) {
                        if (!solid(x - 1, y) || !solid(x, y - 1)) f *= 1.16;
                        if (!solid(x + 1, y) || !solid(x, y + 1)) f *= 0.8;
                    }
                    f *= 0.95 + (hash(x, y) % 11) / 100.0;
                    c = shade(c, f);
                }
                out[y][x] = c;
            }
            return out;
        }
    }

    // =====================================================================================================
    // zombies
    // =====================================================================================================
    private static int[][] buildZombie(int kind, int frame) {
        boolean tank = kind == 2, run = kind == 1, spit = kind == 3;
        int w = tank ? 28 : 20;
        double cx = w / 2.0;
        Cv c = new Cv(w, ZH);

        int skin, shirt, pants, eye, hair;
        switch (kind) {
            case 1 -> { skin = 0xFF8DB063; shirt = 0xFFC44444; pants = 0xFF34343E; eye = 0xFFFFE23A; hair = 0xFF5A4A2A; }
            case 2 -> { skin = 0xFF5C8450; shirt = 0xFF5E3E80; pants = 0xFF2E2434; eye = 0xFFFF3030; hair = 0xFF1C1C1C; }
            case 3 -> { skin = 0xFFB9C93C; shirt = 0xFF6E8F2C; pants = 0xFF3C4C24; eye = 0xFF9CFF3C; hair = 0xFF3A4A1A; }
            default -> { skin = 0xFF6FAA5A; shirt = 0xFF2AA6B0; pants = 0xFF3A3A8C; eye = 0xFFFF3030; hair = 0xFF33261A; }
        }
        int skinD = shade(skin, 0.72), shirtD = shade(shirt, 0.7), blood = 0xFF8A1414, bloodD = 0xFF5A0A0A, bone = 0xFFE8E0C4, dark = 0xFF14100C;
        int shoe = 0xFF2A2420;

        // ---- stride: one leg goes forward (long), the other is lifted ----
        int legW = tank ? 7 : run ? 4 : 5;
        int gap = tank ? 0 : run ? 1 : 0;
        int legTop = tank ? 27 : 26;
        int bottomA = frame == 0 ? 38 : (run ? 34 : 36), bottomB = frame == 0 ? (run ? 34 : 36) : 38;     // left, right
        int armBob = frame == 0 ? 0 : 1;
        double headDy = run ? 2 : spit ? 2 : 0, headDx = run ? 1 : 0;

        // ---- legs ----
        int lx0 = (int) (cx - gap / 2.0 - legW), rx0 = (int) (cx + gap / 2.0 + (gap % 2));
        for (int side = 0; side < 2; side++) {
            int x0 = side == 0 ? lx0 : rx0, bot = side == 0 ? bottomA : bottomB;
            c.rectO(x0, legTop, x0 + legW, bot - 2, pants);
            // boot
            int bx0 = side == 0 ? x0 - 1 : x0, bx1 = side == 0 ? x0 + legW : x0 + legW + 1;
            c.rectO(bx0, bot - 3, bx1, bot, shoe);
            c.rect(bx0 + 1, bot - 1, bx1 - 1, bot, 0xFF4A423A);                 // sole
            c.rect(bx0 + 1, bot - 3, bx1 - 2, bot - 2, 0xFF3C342E);             // toe cap highlight
            // knee patch and frayed hem
            c.rect(x0 + 1, legTop + 5, x0 + legW - 1, legTop + 6, shade(pants, 0.78));
            for (int i = 0; i < legW; i += 2) c.clear(x0 + i + (side), bot - 4);
        }
        // torn trouser: a wound on the left leg showing the skin and a dark scratch on the right
        c.rect(lx0 + 1, legTop + 6, lx0 + 3, legTop + 9, skinD);
        c.set(lx0 + 1, legTop + 7, blood, true);
        c.set(rx0 + legW - 2, legTop + 3, shade(pants, 0.6), false);
        c.set(rx0 + legW - 2, legTop + 4, shade(pants, 0.6), false);

        // ---- torso ----
        double th = tank ? 8 : run ? 4.5 : spit ? 6 : 5;          // half width of the torso
        int tTop = tank ? 11 : 13, tBot = legTop;                 // torso rows
        int tx0 = (int) Math.round(cx - th), tx1 = (int) Math.round(cx + th);
        if (spit) {                                               // a hunched, bloated body
            c.ellO(cx, tTop + 7.5, th + 0.8, 7.2, shirt);
            c.rect(tx0 + 1, tBot - 3, tx1 - 1, tBot, shirt);
        } else {
            c.rectO(tx0, tTop, tx1, tBot, shirt);
        }
        // belt
        c.rect(tx0, tBot - 2, tx1, tBot, 0xFF4A3220);
        c.rect((int) cx - 1, tBot - 2, (int) cx + 1, tBot, 0xFFD8B040, true);
        // torn bottom hem of the shirt
        for (int x = tx0 + 1; x < tx1 - 1; x += 3) { c.clear(x, tBot - 3); c.set(x, tBot - 3, skinD, false); }
        // shirt wrinkles
        for (int i = 0; i < (tank ? 5 : 3); i++) {
            int wx = tx0 + 2 + i * (tank ? 3 : 3), wy = tTop + 3 + (i % 2) * 3;
            c.rect(wx, wy, wx + 1, wy + 3, shirtD);
        }
        // collar: the neck coming out of it
        c.rect(cx - 2, tTop - 1, cx + 2, tTop + 2, skin);
        c.rect(cx - 1, tTop + 1, cx + 1, tTop + 3, skinD);
        // bare ribs through a tear (right side of the chest)
        int rx = (int) (cx + 1), ry = tTop + (tank ? 5 : 4);
        int ribW = tank ? 5 : run ? 4 : 3;
        c.rect(rx, ry, rx + ribW, ry + 6, bloodD);
        for (int r = 0; r < 3; r++) c.rect(rx, ry + 1 + r * 2, rx + ribW, ry + 2 + r * 2, bone);
        c.rect(rx + ribW - 1, ry, rx + ribW, ry + 6, bone);
        // blood on the shirt
        c.rect(tx0 + 1, tTop + 1, tx0 + 3, tTop + 2, blood);
        c.set(tx0 + 1, tTop + 2, blood, false); c.set(tx0 + 2, tTop + 3, blood, false);
        c.rect(tx0 + 2, tBot - 6, tx0 + 4, tBot - 5, blood);
        c.set(tx0 + 3, tBot - 5, blood, false);

        // ---- arms (reaching forward: a torn sleeve, rotten forearm, clawed hand) ----
        int aw = tank ? 5 : run ? 3 : 4;
        int ay = tTop + 1 + armBob;
        for (int side = 0; side < 2; side++) {
            int ax0 = side == 0 ? tx0 - aw : tx1;
            int sleeveLen = tank ? 5 : 6;
            int ex = side == 0 ? -1 : 1;                           // arms swing a bit outward
            c.rectO(ax0, ay, ax0 + aw, ay + sleeveLen, shirt);
            c.rect(ax0 + 1, ay + sleeveLen - 1, ax0 + aw - 1, ay + sleeveLen, shirtD);
            for (int i = 0; i < aw; i += 2) c.clear(ax0 + i + side, ay + sleeveLen - 1);
            int fy = ay + sleeveLen;
            int fx0 = ax0 + (run ? ex : 0);
            c.rectO(fx0, fy, fx0 + aw, fy + (tank ? 7 : 5), skin);
            c.rect(fx0 + 1, fy + 2, fx0 + 2, fy + 3, bloodD);                       // a wound
            if (!run) c.rect(fx0 + aw - 2, fy + 1, fx0 + aw - 1, fy + 3, bone);       // a bit of bone
            int hy = fy + (tank ? 7 : 5);
            // the hand: a palm and 3 claws
            int hw = tank ? aw + 1 : aw;
            int hx0 = fx0 - (tank ? 0 : 0);
            c.rectO(hx0, hy, hx0 + hw, hy + 3, skin);
            int claw = run ? 0xFFEDE6C8 : 0xFFD8D0B0;
            for (int f = 0; f < 3; f++) {
                int fxp = hx0 + (hw == 4 ? f * 1 + (f > 0 ? 0 : 0) : f * 2 - (hw > 5 ? 0 : 1)) + (hw == 4 ? 0 : 1);
                fxp = hx0 + Math.min(hw - 1, f * (hw - 1) / 2);
                c.rect(fxp, hy + 3, fxp + 1, hy + 5, skinD);
                c.set(fxp, hy + 5, claw, true);
            }
        }
        // pauldrons for the tank: plates of scrap metal with rivets
        if (tank) {
            for (int side = 0; side < 2; side++) {
                int px0 = side == 0 ? tx0 - 6 : tx1 - 1;
                c.rectO(px0, tTop - 1, px0 + 7, tTop + 4, 0xFF6C727C);
                c.rect(px0 + 1, tTop, px0 + 6, tTop + 1, 0xFF9AA2AE);
                c.set(px0 + 1, tTop + 2, 0xFFD0D6DC, true); c.set(px0 + 5, tTop + 2, 0xFFD0D6DC, true);
            }
            c.rect(tx0, tTop + 8, tx1, tTop + 9, 0xFF6C727C);                         // a chain across the chest
            for (int x = tx0; x < tx1; x += 2) c.set(x, tTop + 9, 0xFFB0B6BE, true);
        }

        // ---- head ----
        double hcx = cx + headDx, hcy = (tank ? 6.4 : 6.5) + headDy;
        double hrx = tank ? 4.2 : spit ? 5 : 4.6, hry = tank ? 4.8 : 5.2;
        // throat sac of the spitter, behind the chin
        if (spit) {
            c.ell(hcx, hcy + 7.5, 3.6, 3.2, 0xFF8BD62C);
            c.ell(hcx, hcy + 7.5, 2.4, 2.0, 0xFFD8FF70, true);
        }
        c.ellO(hcx, hcy, hrx, hry, skin);
        // hair tufts
        int hx = (int) hcx;
        if (!tank) {
            c.rect(hx - 4, (int) (hcy - hry) + 0, hx - 1, (int) (hcy - hry) + 2, hair);
            c.rect(hx + 1, (int) (hcy - hry) + 1, hx + 3, (int) (hcy - hry) + 2, hair);
            c.set(hx - 4, (int) (hcy - hry) + 2, hair, false);
            c.set(hx - 5, (int) (hcy - hry) + 3, hair, false);
        } else {
            c.rect(hx - 3, (int) (hcy - hry) + 0, hx + 3, (int) (hcy - hry) + 1, hair);      // a shaved head with a scar
            c.line(hx - 3, hcy - 2, hx - 1, hcy + 1, 1, bloodD);
        }
        // exposed skull on the right side
        c.rect(hx + 2, (int) (hcy - hry) + 1, hx + 4, (int) (hcy - hry) + 3, bone);
        c.set(hx + 3, (int) (hcy - hry) + 2, dark, false);
        // eyes: dark sockets with a glowing eye (one smaller, one bigger)
        int ey = (int) hcy - 1;
        int eo = tank ? 2 : 3;
        c.rect(hx - eo - 1, ey, hx - eo + 1, ey + 2, dark);
        c.rect(hx + eo - 1, ey, hx + eo + 1, ey + 2, dark);
        c.rect(hx - eo - 1, ey - 1, hx - eo + 2, ey, shade(skinD, 0.8));                    // heavy brows
        c.rect(hx + eo - 2, ey - 1, hx + eo + 1, ey, shade(skinD, 0.8));
        c.set(hx - eo, ey, eye, true);
        c.set(hx + eo, ey, eye, true);
        c.set(hx + eo - 1, ey + 1, shade(eye, 0.7), true);
        if (spit) { c.set(hx - eo - 1, ey, eye, true); c.set(hx + eo, ey + 1, eye, true); }     // bigger glowing eyes
        // nose
        c.set(hx, ey + 2, skinD, false);
        c.set(hx, ey + 3, dark, false);
        // mouth: open, with teeth and blood
        int my = ey + 4;
        int mw = run || spit ? 3 : 2;
        c.rect(hx - mw, my, hx + mw + 1, my + (run || spit ? 3 : 2), dark);
        for (int x = hx - mw; x <= hx + mw; x += 2) c.set(x, my, 0xFFF4F0DC, true);
        for (int x = hx - mw + 1; x <= hx + mw; x += 2) c.set(x, my + (run || spit ? 2 : 1), 0xFFF4F0DC, true);
        if (spit) {                                              // acid drooling out of it
            c.set(hx - 1, my + 3, 0xFF9CFF3C, true); c.set(hx - 1, my + 4, 0xFFC8FF70, true);
            c.set(hx + 2, my + 3, 0xFF9CFF3C, true);
        } else {
            c.set(hx + 1, my + 2, blood, false); c.set(hx + 1, my + 3, blood, false);
        }
        // stitches / scar on the cheek
        c.set(hx - eo - 2, ey + 2, dark, false); c.set(hx - eo - 1, ey + 3, dark, false); c.set(hx - eo - 2, ey + 4, dark, false);
        // ear
        c.rect(hx - (int) hrx - 1, (int) hcy, hx - (int) hrx, (int) hcy + 2, skinD);

        // ---- extras per kind ----
        if (spit) {                                              // glowing pustules on the belly and arms
            int[][] pu = {{(int) cx - 3, tTop + 4}, {(int) cx + 2, tTop + 8}, {(int) cx - 2, tTop + 9}, {(int) cx + 3, tTop + 3}};
            for (int[] q : pu) { c.ell(q[0] + 0.5, q[1] + 0.5, 1.6, 1.6, 0xFF7BC022); c.set(q[0], q[1], 0xFFE8FF98, true); }
        }
        if (run) {                                               // speed lines: torn shirt flap
            c.rect(tx0, tBot - 5, tx0 + 2, tBot - 3, shirtD);
        }
        return c.finish(0xFF0A0806, true);
    }

    // =====================================================================================================
    // perks: glyphs drawn in unit coordinates, used for the cards (big), the HUD (small) and the round signs of the machines
    //   0 Quick Revive, 1 Speed Cola, 2 Stamin-Up, 3 Juggernog, 4 Double Tap Root Beer II, 5 Mule Kick
    // =====================================================================================================
    private static void glyph(Cv c, int perk, int col, double ox, double oy, double s) {
        int hi = mix(col, 0xFFFFFFFF, 0.45), lo = shade(col, 0.55);
        switch (perk) {
            case 0 -> {                                          // Quick Revive: a white cross held by two cupped hands
                int skin = 0xFFF2D2B0;
                c.ring(ox + s * 0.5, oy + s * 0.50, s * 0.27, s * 0.42, 10, 170, skin);
                c.ring(ox + s * 0.5, oy + s * 0.50, s * 0.27, s * 0.30, 10, 170, shade(skin, 0.75));
                c.rect(ox + s * 0.39, oy + s * 0.08, ox + s * 0.61, oy + s * 0.66, 0xFFFFFFFF);
                c.rect(ox + s * 0.19, oy + s * 0.27, ox + s * 0.81, oy + s * 0.47, 0xFFFFFFFF);
                c.rect(ox + s * 0.44, oy + s * 0.13, ox + s * 0.56, oy + s * 0.60, col);
                c.rect(ox + s * 0.25, oy + s * 0.32, ox + s * 0.75, oy + s * 0.42, col);
            }
            case 1 -> {                                          // Speed Cola: a magazine inside a reload arrow
                ringArrow(c, ox, oy, s, 0.34, 0.45, col, 30, 330);
                c.rect(ox + s * 0.40, oy + s * 0.40, ox + s * 0.60, oy + s * 0.72, 0xFF4A4E5A);
                c.rect(ox + s * 0.42, oy + s * 0.40, ox + s * 0.46, oy + s * 0.72, 0xFF7A808E);
                c.rect(ox + s * 0.40, oy + s * 0.66, ox + s * 0.60, oy + s * 0.72, 0xFF2A2E38);
                c.ell(ox + s * 0.5, oy + s * 0.34, s * 0.10, s * 0.09, 0xFFE0B040);
                c.rect(ox + s * 0.40, oy + s * 0.34, ox + s * 0.60, oy + s * 0.42, 0xFFE0B040);
                c.rect(ox + s * 0.44, oy + s * 0.34, ox + s * 0.48, oy + s * 0.42, 0xFFFFE890);
            }
            case 2 -> {                                          // Stamin-Up: a winged boot
                int boot = 0xFF8A5A30, bootHi = 0xFFB07A44;
                c.poly(new double[]{ox + s * 0.36, ox + s * 0.62, ox + s * 0.62, ox + s * 0.86, ox + s * 0.86, ox + s * 0.34},
                        new double[]{oy + s * 0.22, oy + s * 0.22, oy + s * 0.60, oy + s * 0.68, oy + s * 0.84, oy + s * 0.84}, boot);
                c.rect(ox + s * 0.36, oy + s * 0.22, ox + s * 0.62, oy + s * 0.30, 0xFFE8E0D0);    // the cuff
                c.rect(ox + s * 0.36, oy + s * 0.30, ox + s * 0.42, oy + s * 0.84, bootHi);
                c.rect(ox + s * 0.32, oy + s * 0.84, ox + s * 0.88, oy + s * 0.93, 0xFF2A2420);    // the sole
                for (int i = 0; i < 3; i++) c.ell(ox + s * 0.52, oy + s * (0.36 + i * 0.09), s * 0.025, s * 0.025, 0xFFFFE890, true);
                for (int i = 0; i < 3; i++) {                    // the wing: three feathers
                    c.poly(new double[]{ox + s * 0.34, ox + s * (0.10 - i * 0.01), ox + s * (0.16 - i * 0.01), ox + s * 0.34},
                            new double[]{oy + s * (0.40 + i * 0.07), oy + s * (0.20 + i * 0.12), oy + s * (0.30 + i * 0.12), oy + s * (0.52 + i * 0.07)}, i == 0 ? 0xFFFFFFFF : i == 1 ? mix(0xFFFFFFFF, col, 0.3) : mix(0xFFFFFFFF, col, 0.6));
                }
            }
            case 3 -> {                                          // Juggernog: a shield with a heart
                shield(c, ox, oy, s, col);
                heart(c, ox + s * 0.50, oy + s * 0.50, s * 0.30, 0xFFFFFFFF, 0xFFFFD0D6);
            }
            case 4 -> {                                          // Double Tap: two bullets side by side
                int brass = 0xFFE8B84A, brassD = 0xFF9A6A18, tip = 0xFFC86A38;
                for (int i = 0; i < 2; i++) {
                    double bx = ox + s * (0.24 + i * 0.30);
                    c.ell(bx + s * 0.11, oy + s * 0.48, s * 0.11, s * 0.28, tip);
                    c.rect(bx, oy + s * 0.48, bx + s * 0.22, oy + s * 0.88, brass);
                    c.rect(bx, oy + s * 0.48, bx + s * 0.055, oy + s * 0.88, 0xFFFFEE9A);
                    c.rect(bx + s * 0.17, oy + s * 0.48, bx + s * 0.22, oy + s * 0.88, shade(brass, 0.75));
                    c.rect(bx, oy + s * 0.78, bx + s * 0.22, oy + s * 0.88, brassD);
                }
                c.rect(ox + s * 0.80, oy + s * 0.08, ox + s * 0.87, oy + s * 0.30, 0xFFFFFFFF, true);   // sparkle
                c.rect(ox + s * 0.72, oy + s * 0.16, ox + s * 0.95, oy + s * 0.22, 0xFFFFFFFF, true);
            }
            default -> {                                         // Mule Kick: a pistol on a shield
                shield(c, ox, oy, s, col);
                int gun = 0xFFF2F4F8;
                c.rect(ox + s * 0.26, oy + s * 0.28, ox + s * 0.76, oy + s * 0.44, gun);         // the slide
                c.rect(ox + s * 0.26, oy + s * 0.28, ox + s * 0.76, oy + s * 0.31, 0xFFFFFFFF);
                c.rect(ox + s * 0.70, oy + s * 0.31, ox + s * 0.78, oy + s * 0.40, 0xFF8890A0);  // the muzzle
                c.poly(new double[]{ox + s * 0.34, ox + s * 0.48, ox + s * 0.44, ox + s * 0.32},
                        new double[]{oy + s * 0.44, oy + s * 0.44, oy + s * 0.66, oy + s * 0.66}, 0xFFD0D6DE);   // the grip
                c.rect(ox + s * 0.48, oy + s * 0.44, ox + s * 0.58, oy + s * 0.50, 0xFFB0B8C4);  // the trigger guard
            }
        }
    }

    private static void shield(Cv c, double ox, double oy, double s, int col) {
        int hi = mix(col, 0xFFFFFFFF, 0.45), lo = shade(col, 0.55);
        double[] sx = {0.14, 0.86, 0.86, 0.50, 0.14}, sy = {0.10, 0.10, 0.52, 0.94, 0.52};
        double[] ax = new double[5], ay = new double[5];
        for (int i = 0; i < 5; i++) { ax[i] = ox + s * sx[i]; ay[i] = oy + s * sy[i]; }
        c.poly(ax, ay, lo);
        double[] ix = {0.22, 0.78, 0.78, 0.50, 0.22}, iy = {0.18, 0.18, 0.50, 0.85, 0.50};
        for (int i = 0; i < 5; i++) { ax[i] = ox + s * ix[i]; ay[i] = oy + s * iy[i]; }
        c.poly(ax, ay, col);
        c.poly(new double[]{ox + s * 0.22, ox + s * 0.50, ox + s * 0.50, ox + s * 0.22}, new double[]{oy + s * 0.18, oy + s * 0.18, oy + s * 0.85, oy + s * 0.50}, hi);
    }

    private static void heart(Cv c, double cx, double cy, double s, int col, int hi) {
        c.ell(cx - s * 0.26, cy - s * 0.14, s * 0.28, s * 0.28, col);
        c.ell(cx + s * 0.26, cy - s * 0.14, s * 0.28, s * 0.28, col);
        c.poly(new double[]{cx - s * 0.52, cx + s * 0.52, cx}, new double[]{cy - s * 0.02, cy - s * 0.02, cy + s * 0.55}, col);
        c.ell(cx - s * 0.30, cy - s * 0.22, s * 0.09, s * 0.07, hi);
    }

    /** A circular arrow around the middle: the ring, with an arrow head at the end of it. */
    private static void ringArrow(Cv c, double ox, double oy, double s, double r0, double r1, int col, double a0, double a1) {
        c.ring(ox + s * 0.5, oy + s * 0.5, s * r0, s * r1, a0, a1, col);
        double a = Math.toRadians(a0), rm = s * (r0 + r1) / 2;
        double tx = ox + s * 0.5 + Math.cos(a) * rm, ty = oy + s * 0.5 + Math.sin(a) * rm;
        double dx = -Math.sin(a), dy = Math.cos(a);                // direction of travel at the end (backwards along the ring)
        double nx = Math.cos(a), ny = Math.sin(a);
        double hw = s * 0.15, hl = s * 0.17;
        c.poly(new double[]{tx + nx * hw, tx - nx * hw, tx - dx * hl}, new double[]{ty + ny * hw, ty - ny * hw, ty - dy * hl}, col);
    }

    // =====================================================================================================
    // perk machines: 32 x 32 texels, painted like the old Call of Duty Zombies vending machines
    //   0 Quick Revive (blue fridge), 1 Speed Cola (green and white), 2 Stamin-Up (orange jukebox),
    //   3 Juggernog (white and red pump), 4 Double Tap Root Beer II (yellow box with a bottle cap), 5 Mule Kick (polka dots)
    // =====================================================================================================
    private static int[][] buildMachine(int perk, int col) {
        int n = MACHINE;
        Cv m = new Cv(n, n);                                       // the machine alone, on a see-through canvas
        switch (perk) {
            case 0 -> machineRevive(m, col);
            case 1 -> machineCola(m, col);
            case 2 -> machineStamin(m, col);
            case 3 -> machineJugg(m, col);
            case 4 -> machineTap(m, col);
            default -> machineMule(m, col);
        }
        return inNiche(m);
    }

    /** Puts a finished picture (a machine, the mystery box) into its niche: dark bricks behind it, a pool of shadow on the floor. */
    private static int[][] inNiche(Cv m) {
        int n = MACHINE;
        int[][] fg = m.finish(0xFF0A0807, true);                   // light on the left / top, dark on the right / bottom, a black outline
        int[][] out = new int[n][n];
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++) {  // the niche behind it: dark bricks, a pool of shadow on the floor
            int row = y / 4, off = (row & 1) * 4;
            boolean mortar = (y % 4 == 3) || ((x + off) % 8 == 7);
            int bg = mortar ? 0xFF171413 : shade(0xFF2E2825, 0.9 + (hash(x / 8 + row * 3, row) % 9) / 40.0);
            if (y >= n - 2) bg = shade(bg, 0.55);
            out[y][x] = fg[y][x] != 0 ? fg[y][x] : bg;
        }
        return out;
    }

    /** A box with rounded corners. */
    private static void rbox(Cv c, double x0, double y0, double x1, double y1, int col, double r) {
        c.rect(x0 + r, y0, x1 - r, y1, col);
        c.rect(x0, y0 + r, x1, y1 - r, col);
        c.ell(x0 + r, y0 + r, r, r, col); c.ell(x1 - r, y0 + r, r, r, col);
        c.ell(x0 + r, y1 - r, r, r, col); c.ell(x1 - r, y1 - r, r, r, col);
    }

    /** Lettering of a painted sign: tiny squiggles that read as writing from afar. Lit, so they are not shaded. */
    private static void scribble(Cv c, double x0, double y, double x1, int col, int seed, int thick) {
        for (int x = (int) x0; x < (int) x1; x++) {
            int h = hash(x, seed) % 6;
            if (h == 0) continue;                                  // a gap between two letters
            for (int t = 0; t < thick; t++) c.set(x, (int) y + t, col, true);
            if (h == 1 || h == 2) c.set(x, (int) y - 1, col, true);
            if (h == 3) c.set(x, (int) y + thick, col, true);
        }
    }

    /** A round lit sign on top of the machine: a bright rim, a colored face and the perk symbol on it. */
    private static void sign(Cv c, double cx, double cy, double r, int rim, int face, int perk, int perkCol) {
        c.ell(cx, cy, r, r, shade(rim, 0.55), true);
        c.ell(cx, cy, r - 0.7, r - 0.7, rim, true);
        c.ell(cx, cy, r - 1.5, r - 1.5, face, true);
        Cv g = new Cv(c.w, c.h);
        double gs = (r - 1.2) * 2;
        glyph(g, perk, perkCol, cx - gs / 2, cy - gs / 2, gs);
        for (int y = 0; y < c.h; y++) for (int x = 0; x < c.w; x++) {
            if ((g.p[y * c.w + x] >>> 24) == 0) continue;
            double dx = x + 0.5 - cx, dy = y + 0.5 - cy;
            if (dx * dx + dy * dy <= (r - 1.3) * (r - 1.3)) c.set(x, y, g.p[y * c.w + x], true);
        }
        c.set((int) (cx - r * 0.55), (int) (cy - r * 0.6), 0xFFFFFFFF, true);          // a glint on the rim
    }

    // 0: Quick Revive, a blue, squat, fridge-like cooler under a cream "house" roof
    private static void machineRevive(Cv m, int col) {
        int blue = 0xFF4A9CCC, cream = 0xFFF2EBDD, steel = 0xFFB4BAC4;
        m.rect(6, 28, 10, 30.5, 0xFF2C3036); m.rect(22, 28, 26, 30.5, 0xFF2C3036);                  // feet
        rbox(m, 4, 14.5, 28, 29, blue, 2.2);                                                           // the cooler
        m.poly(new double[]{4.2, 8.2, 23.8, 27.8}, new double[]{15.5, 9.5, 9.5, 15.5}, cream);        // the roof
        m.poly(new double[]{4.2, 8.2, 8.2, 4.2}, new double[]{15.5, 9.5, 11.5, 16.5}, shade(cream, 0.82));
        scribble(m, 9, 12, 23, shade(blue, 0.7), 11, 1); scribble(m, 10, 13.6, 22, shade(blue, 0.7), 12, 1);   // "Quick Revive!"
        m.rect(15.4, 6.5, 16.6, 10, steel);                                                              // the stem of the sign
        sign(m, 16, 5.0, 5.0, 0xFFE9EEF2, shade(col, 0.5), 0, col);
        m.rect(8.5, 17.5, 16.5, 27.5, cream);                                                           // the white hatch
        m.rect(8.5, 17.5, 16.5, 18.2, shade(cream, 0.8));
        m.rect(11, 19.5, 14, 21.5, 0xFF2A3038);                                                         // its window
        m.rect(11.6, 22.5, 13.4, 24.5, 0xFF2A3038);
        m.ell(21, 18.8, 1.2, 1.2, steel);                                                                // a knob
        for (int i = 0; i < 4; i++) m.rect(23.5, 18 + i * 2, 26.5, 18.8 + i * 2, shade(blue, 0.6));      // vents
        m.ell(19.5, 24.5, 1.1, 1.1, 0xFFBFE6F6, true); m.ell(21.8, 23, 0.9, 0.9, 0xFFBFE6F6, true); m.ell(21.3, 26, 0.8, 0.8, 0xFFBFE6F6, true);   // bubbles
        m.rect(5, 20, 7.5, 21, 0xFFFFFFFF, true); m.rect(5, 22, 7.5, 23, 0xFFFFFFFF, true);              // "ICE COLD" / "SOLD"
    }

    // 1: Speed Cola, a tall green and white cooler with a glass window and a coin panel
    private static void machineCola(Cv m, int col) {
        int green = 0xFF3FA84A, white = 0xFFF1EEE6, red = 0xFFD23A32;
        rbox(m, 8, 9.5, 24, 30.5, white, 2.2);
        m.rect(8, 18, 24, 30.5, green);
        scribble(m, 10, 11.2, 14, red, 21, 1);                                                          // "Drink"
        scribble(m, 10, 13.2, 22.5, red, 22, 2);                                                        // "Speed Cola"
        scribble(m, 18, 16.2, 22.5, red, 23, 1);                                                        // "ICE COLD"
        m.rect(9.5, 19, 14.5, 28.5, 0xFF2E8A3A);                                                        // the coin panel
        m.rect(10.3, 20, 13.7, 23.2, 0xFFB9D8C4, true);
        m.rect(11.4, 25, 12.6, 27.5, 0xFF0E2A14);
        m.rect(17.2, 19, 22, 28.5, 0xFF2A6E3A);                                                         // the window: frame and glass
        m.rect(17.9, 19.7, 21.3, 27.8, 0xFFBFE2EE, true);
        for (int y = 21; y < 27; y += 2) m.rect(17.9, y, 21.3, y + 0.6, 0xFFFFFFFF, true);
        sign(m, 16, 5.0, 5.0, 0xFFB8C0C8, 0xFFEFE6C8, 1, col);
    }

    // 2: Stamin-Up, an orange jukebox with a chrome arch, a slot-machine window and a wooden belly
    private static void machineStamin(Cv m, int col) {
        int orange = 0xFFE8982A, chrome = 0xFFBAC0C8, wood = 0xFFB5702F;
        m.rect(6, 12, 26, 31, orange);
        m.ell(16, 13.5, 10, 6.5, chrome); m.ell(16, 14, 9, 6, orange);                                  // the arch
        sign(m, 16, 8.4, 5.6, 0xFFC0C6CE, 0xFFF4C060, 2, col);
        m.rect(7.5, 16, 24.5, 23.5, chrome);                                                            // the chrome middle
        m.rect(9, 17, 23, 21, 0xFF1C2028);                                                              // the reels
        int[] reel = {0xFFE04040, 0xFFF0D040, 0xFF50D060, 0xFF40C8F0, 0xFFE060D0};
        for (int i = 0; i < 5; i++) m.rect(9.5 + i * 2.6, 17.6, 11.7 + i * 2.6, 20.4, reel[i], true);
        for (int i = 0; i < 5; i++) m.rect(10 + i * 2.6, 21.7, 11.3 + i * 2.6, 22.9, 0xFF7A808C);
        m.rect(9, 24, 23, 25.2, 0xFF5A7A9A);                                                            // the tray
        m.rect(8, 25.5, 24, 31, wood);
        for (int x = 8; x < 24; x++) if (hash(x, 5) % 3 != 0) m.rect(x, 25.5, x + 1, 31, shade(wood, hash(x, 9) % 2 == 0 ? 0.84 : 0.92));
        m.rect(5, 29.5, 27, 31, chrome);                                                                // the base
    }

    // 3: Juggernog, a white top with red lettering over a red body with a silver coin panel
    private static void machineJugg(Cv m, int col) {
        int white = 0xFFF4F0E8, red = 0xFFD0302E, steel = 0xFF8A919C;
        m.rect(15.3, 8, 16.7, 12, steel);
        rbox(m, 8.5, 11, 23.5, 25, white, 2.8);
        m.rect(8.5, 22.5, 23.5, 31, red);
        scribble(m, 10, 12.8, 22, red, 31, 2);                                                          // "Jugger-"
        scribble(m, 10, 16, 22, red, 32, 2);                                                            // "Nog"
        scribble(m, 17, 19.3, 22, red, 33, 1);                                                          // "ICE COLD"
        m.ell(11.4, 20, 1.5, 1.5, red, true);                                                           // "10 cent"
        m.rect(10, 21.5, 17.5, 29.5, steel);                                                            // the coin panel
        m.rect(11, 22.5, 14, 25, 0xFF20242C);
        for (int i = 0; i < 3; i++) m.rect(11.1 + i * 2.1, 26, 12.3 + i * 2.1, 27.2, i == 1 ? 0xFFE03030 : 0xFF30C050, true);
        m.rect(11.5, 28, 16.5, 29.2, 0xFF0E1014);
        m.rect(19.5, 24, 21.8, 28, shade(red, 0.6));
        sign(m, 16, 5.0, 5.0, 0xFFB8C0C8, 0xFFF4F0E8, 3, col);
    }

    // 4: Double Tap Root Beer II, a mustard box with a big bottle cap, a steel panel and a brown band
    private static void machineTap(Cv m, int col) {
        int mustard = 0xFFD8A236, orange = 0xFFE07A20, steel = 0xFF9AA0A8;
        m.rect(7, 6, 25, 31, mustard);
        m.rect(7, 6, 25, 8, 0xFFF0C050);
        for (int i = 0; i < 14; i++) {                                                                    // the teeth of the cap
            double a = i * Math.PI * 2 / 14;
            m.ell(16 + Math.cos(a) * 6.3, 14 + Math.sin(a) * 6.3, 1.0, 1.0, orange, true);
        }
        m.ell(16, 14, 6.0, 6.0, orange, true);
        m.ell(16, 14, 4.8, 4.8, 0xFFF4B838, true);
        double[] sx = new double[10], sy = new double[10];
        for (int i = 0; i < 10; i++) {                                                                    // a star on the cap
            double a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 == 0 ? 3.8 : 1.6;
            sx[i] = 16 + Math.cos(a) * r; sy[i] = 14 + Math.sin(a) * r;
        }
        Cv st = new Cv(m.w, m.h);
        st.poly(sx, sy, 0xFFFFF2C8);
        for (int y = 0; y < m.h; y++) for (int x = 0; x < m.w; x++) if ((st.p[y * m.w + x] >>> 24) != 0) m.set(x, y, st.p[y * m.w + x], true);
        m.ell(22.6, 9.6, 1.9, 1.9, 0xFFF6EBD2, true);                                                    // the price tag
        m.rect(21.7, 9.2, 23.5, 10, orange, true);
        m.rect(8.5, 20, 23.5, 28, steel);                                                               // the steel panel
        m.rect(8.5, 20, 23.5, 21, 0xFFC8CED6);
        m.rect(10, 22, 22, 27, 0xFF6E747E);
        m.rect(11.5, 23.2, 18, 26, 0xFF14161A);                                                         // the dispenser
        m.rect(19.5, 22.6, 21, 25.4, 0xFFE8C040, true);                                                 // the coin slot
        m.rect(7, 28, 25, 31, 0xFF704A2A);                                                              // the brown band
        scribble(m, 9.5, 29.2, 22.5, 0xFFF4F0E4, 41, 1);                                                // "Double Tap II"
        m.rect(7, 28, 25, 28.8, 0xFF8E6238);
    }

    // 5: Mule Kick, a red dome over a white body with red polka dots, a green stripe and a red panel with a hat
    private static void machineMule(Cv m, int col) {
        int red = 0xFFC82A2A, white = 0xFFF0ECE4, green = 0xFF3A9A4A;
        m.rect(4, 29.5, 28, 31.5, 0xFFD8D8D8);                                                          // the white base
        m.rect(4, 31, 28, 32, 0xFF9A9AA0);
        m.rect(8.5, 15, 23.5, 29.5, white);
        m.ell(16, 15, 7.5, 5.5, red);                                                                    // the dome
        m.rect(8.5, 14.5, 23.5, 16.5, red);
        for (int y = 17; y < 29; y += 3) for (int x = 9 + ((y / 3) & 1) * 1; x < 24; x += 3) m.ell(x + 0.5, y + 0.5, 0.95, 0.95, red);   // polka dots
        m.rect(8.5, 26.8, 23.5, 29.5, green);
        m.rect(5.8, 16.5, 9.2, 30, green);                                                               // the green side
        m.rect(4.4, 19, 6.4, 30, red);
        m.rect(9.8, 17, 14.8, 25.4, 0xFFC2C8D0);                                                         // the glass with bottles
        m.rect(10.4, 17.6, 14.2, 24.8, 0xFF2C3440);
        for (int i = 0; i < 3; i++) m.rect(10.8, 18.6 + i * 2.1, 13.8, 19.5 + i * 2.1, i == 1 ? 0xFFE8B84A : 0xFF8890A0, true);
        m.rect(17.4, 16.6, 23, 24.6, red);                                                               // the red panel
        m.rect(17.4, 16.6, 23, 17.4, shade(red, 1.25));
        m.ell(20.2, 19.6, 2.6, 0.8, 0xFFF0D040, true);                                                   // a sombrero
        m.ell(20.2, 18.8, 1.1, 1.1, 0xFFF0D040, true);
        m.ell(20.2, 21.7, 1.4, 1.3, 0xFFFFFFFF, true);                                                   // a skull
        m.set(19, 21, 0xFF101010, true); m.set(21, 21, 0xFF101010, true);
        scribble(m, 18, 23.4, 22.4, 0xFFFFFFFF, 51, 1);                                                  // "UNO MAS!"
        m.rect(15.4, 9, 16.6, 12, 0xFF8A919C);
        sign(m, 16, 5.0, 5.0, 0xFFB8C0C8, 0xFFF0ECE0, 5, col);
    }

    // =====================================================================================================
    // the mystery box, painted like the crate of CoD Zombies: planks, metal straps, a rope handle, big white "?" on the lid
    // =====================================================================================================
    private static final String[] QMARK = {".####.", "##..##", "....##", "..###.", "..##..", "......", "..##.."};

    private static void qmark(Cv m, int x0, int y0, int col, int halo) {
        for (int r = 0; r < QMARK.length; r++) for (int c = 0; c < 6; c++) {
            if (QMARK[r].charAt(c) != '#') continue;
            for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) if (m.solid(x0 + c + dx, y0 + r + dy)) m.set(x0 + c + dx, y0 + r + dy, halo, true);   // the glow
        }
        for (int r = 0; r < QMARK.length; r++) for (int c = 0; c < 6; c++) if (QMARK[r].charAt(c) == '#') m.set(x0 + c, y0 + r, col, true);
    }

    private static int[][] buildBox(boolean open) {
        int n = MACHINE;
        Cv m = new Cv(n, n);
        int wood = 0xFF8A5A30, woodD = shade(wood, 0.72), woodL = 0xFFA8703A, steel = 0xFF7C828C, steelD = 0xFF4A4E58;
        m.rect(1, 25, 31, 27.5, 0xFF3A2A1E);                                                    // the table
        m.rect(3, 27.5, 5.5, 31.5, 0xFF2E2218); m.rect(26.5, 27.5, 29, 31.5, 0xFF2E2218);
        m.rect(3, 15.5, 29, 25, wood);                                                          // the front of the crate
        for (double y : new double[]{18, 20.6, 23}) m.rect(3, y, 29, y + 0.9, woodD);                  // the joints of the planks
        for (int x = 3; x < 29; x++) if (hash(x, 3) % 4 == 0) m.set(x, 17 + hash(x, 8) % 7, shade(wood, 0.85), false);   // grain
        for (int x : new int[]{8, 21}) {                                                         // the metal straps
            m.rect(x, 15.5, x + 2.6, 25, steel);
            m.rect(x, 15.5, x + 0.8, 25, shade(steel, 1.3));
            m.set(x + 1, 17, steelD, true); m.set(x + 1, 23, steelD, true);                       // rivets
        }
        scribble(m, 11, 19.2, 20, 0xFF4A2E18, 71, 1); scribble(m, 12, 21.4, 20, 0xFF4A2E18, 72, 1);   // the stencil on the planks
        m.ell(2.2, 20.5, 2.0, 2.6, 0xFFB09060);                                                  // the rope handle
        m.ell(2.2, 20.5, 1.0, 1.6, 0xFF3A2A1E);
        if (!open) {
            m.poly(new double[]{5.5, 26.5, 29, 3}, new double[]{8.5, 8.5, 15.8, 15.8}, woodL);     // the lid, seen from above
            m.rect(3, 15, 29, 16.2, woodD);                                                       // its front edge
            m.rect(7, 8.5, 9, 15.8, steel);                                                       // straps over the lid
            m.rect(23, 8.5, 25, 15.8, steel);
            qmark(m, 8, 8, 0xFFFFFFFF, 0xFF8FD8FF); qmark(m, 18, 8, 0xFFFFFFFF, 0xFF8FD8FF);      // the two glowing question marks
            m.rect(15.4, 0, 16.6, 2.5, 0xFF1A1816);                                               // the lamp hangs from a cable...
            m.ell(16, 4.8, 3.3, 3.3, 0xFF7C828C);
            m.ell(16, 4.8, 2.4, 2.4, 0xFF2ECC40, true);                                           // ...in a cage, green
            m.ell(15.3, 4.1, 0.8, 0.8, 0xFFC8FFD0, true);
        } else {
            m.poly(new double[]{7, 25, 28.5, 3.5}, new double[]{8.2, 8.2, 15.8, 15.8}, 0xFFE8FAFF);      // the inside is full of light
            for (int y = 8; y < 16; y++) for (int x = 4; x < 29; x++) if (m.solid(x, y)) m.set(x, y, mix(0xFFE8FAFF, 0xFF7CC8F0, (y - 8) / 8.0), true);
            for (int x = 8; x < 26; x += 3) m.rect(x, 0, x + 1, 8, 0xFFBEE8FF, true);               // rays of light going up
            for (int x = 9; x < 26; x += 6) m.rect(x, 2, x + 1, 8, 0xFFFFFFFF, true);
            m.poly(new double[]{6, 26, 27.5, 4.5}, new double[]{0.5, 0.5, 6.2, 6.2}, woodD);        // the lid, raised: we see its underside
            m.rect(6, 0.5, 26, 1.4, woodL);
            m.rect(4.5, 5.6, 27.5, 6.4, steel);
            m.ell(28.5, 3.6, 2.0, 2.0, 0xFF7C828C);                                               // the lamp is on the side now, bright
            m.ell(28.5, 3.6, 1.3, 1.3, 0xFF6CFF80, true);
            m.set(5, 2, 0xFFFFFFFF, true); m.set(27, 9, 0xFFFFFFFF, true); m.set(14, 5, 0xFFFFFFFF, true);   // sparkles
        }
        return inNiche(m);
    }

    // =====================================================================================================
    // Pack-a-Punch, painted like the machine of CoD Zombies: a big cream sign "PACK A PUNCH", a small oval sign, a rusty steel bowl on legs
    // with three drums inside, a green band with a "hands off" sign
    // =====================================================================================================
    private static int[][] buildPap(boolean active) {
        int n = MACHINE;
        Cv m = new Cv(n, n);
        int teal = 0xFF2C9A78, tealD = shade(teal, 0.6), cream = 0xFFEADFB8, steel = 0xFF8C8F94, steelD = 0xFF4E5258, rust = 0xFF7A4A3A;
        // the legs, splayed
        m.poly(new double[]{5.5, 8.5, 5.5, 2.5}, new double[]{26, 26, 31, 31}, steelD);
        m.poly(new double[]{23.5, 26.5, 29.5, 26.5}, new double[]{26, 26, 31, 31}, steelD);
        m.rect(1.5, 30.5, 5.5, 31.7, steel); m.rect(26.5, 30.5, 30.5, 31.7, steel);
        // the necks
        m.rect(14, 8, 18, 16.5, tealD);
        // the big sign
        rbox(m, 3, 0.5, 29, 9, teal, 2);
        rbox(m, 4.2, 1.6, 27.8, 7.9, cream, 1.4);
        int[] pastel = {0xFFF4B8C8, 0xFFF8C898, 0xFFB8E8C8};
        for (int i = 0; i < 6; i++) {                                                         // pastel diamonds behind the letters
            double dx = 7 + i * 3.6; int pc = pastel[i % 3];
            m.poly(new double[]{dx, dx + 1.6, dx, dx - 1.6}, new double[]{2, 4.3, 6.6, 4.3}, pc);
        }
        scribble(m, 6, 3, 26, 0xFF2A2A30, 61, 1); scribble(m, 6, 5, 26, 0xFF2A2A30, 64, 1);   // PACK A PUNCH
        scribble(m, 8, 7, 24, 0xFF5A4A3A, 62, 1);                                             // Increase your firepower!
        // the small oval sign with two black shapes and a red burst
        m.ell(16, 12.2, 6.4, 2.6, steel);
        m.ell(16, 12.2, 5.6, 2.0, cream, true);
        m.ell(21.2, 12.2, 1.8, 1.6, 0xFFE05050, true);
        m.rect(11.5, 11.2, 14, 13.4, 0xFF202024, true); m.rect(18.6, 11.6, 21.4, 13.2, 0xFF202024, true);
        // the bowl
        m.poly(new double[]{6.5, 25.5, 30.5, 27.5, 4.5, 1.5}, new double[]{16, 16, 20.5, 27.2, 27.2, 20.5}, steel);
        m.poly(new double[]{6.5, 9, 4, 1.5}, new double[]{16, 16.6, 21, 20.5}, shade(steel, 1.25));                  // the lit left shoulder
        m.poly(new double[]{9, 23, 25.8, 24.5, 7.4, 6.2}, new double[]{17.4, 17.4, 20.6, 23.6, 23.6, 20.6}, active ? 0xFFFFB860 : 0xFF14100C);   // the opening
        int drum = active ? 0xFFFFF0B8 : 0xFFD8CFA0;
        for (int i = 0; i < 3; i++) {                                                          // the three drums
            double dx = 8.6 + i * 5.8;
            m.rect(dx, 18.2, dx + 4.6, 22.2, drum, active);
            m.rect(dx, 18.2, dx + 1.2, 22.2, shade(drum, 1.1), active); m.rect(dx + 3.6, 18.2, dx + 4.6, 22.2, shade(drum, 0.7), active);
            m.rect(dx + 4.6, 19, dx + 5.8, 21.6, 0xFF1C1C20);                                  // the black hubs between them
        }
        m.rect(7.6, 22.2, 24.6, 23.6, rust);                                                   // the rusty axle with its rings
        for (int i = 0; i < 3; i++) m.rect(9 + i * 5.8, 21.8, 11 + i * 5.8, 23.9, 0xFF2A1E1A);
        m.poly(new double[]{5.4, 26.6, 26.9, 5.1}, new double[]{24.4, 24.4, 27, 27}, teal);       // the green band
        scribble(m, 7, 25.6, 14, 0xFFEFF6F0, 63, 1);                                           // "pack-a-punch"
        m.ell(23, 25.7, 1.7, 1.5, 0xFFE8E8E8, true); m.ring(23, 25.7, 1.2, 1.7, 0, 360, 0xFFE03030);   // the "hands off" sign
        m.rect(22.4, 25, 23.6, 26.4, 0xFF303034, true);
        for (int i = 0; i < 10; i++) { int rx = 3 + hash(i, 77) % 26, ry = 16 + hash(i, 78) % 11; if (ry >= 17 && ry <= 24 && rx > 7 && rx < 25) continue; if (m.solid(rx, ry)) m.set(rx, ry, rust, false); }   // rust on the steel
        if (active) {
            for (int i = 0; i < 6; i++) m.set(6 + hash(i, 81) % 20, 14 + hash(i, 82) % 5, 0xFFFFFFFF, true);   // sparks over the bowl
        }
        return inNiche(m);
    }
}
