package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The Start menu: a search box, a list of apps (one per row, with the Dock hotkey of each pinned app shown as a hint),
 * and Desktop / Lock / Quit buttons. The hints (the hotkeys on the rows and the help text at the bottom) can be turned
 * off with the switch in the header; the choice is saved on the server as "startmenu". The computer screen owns the
 * "open" flag and does the launching; this class draws the menu and says what was hit.
 */
public final class StartMenu {
    /** Results of {@link #click} and {@link #key}: an app index (0..Desktop.ICONS - 1) means "open it". */
    public static final int OUTSIDE = -1, INSIDE = -2, NOT_HANDLED = -3;
    /** PIN + app index = the app was right-clicked (pin / unpin); BTN + 0..2 = Desktop / Lock / Quit. */
    public static final int PIN = 1000, BTN = 2000;

    public static final int W = 176;
    private static final int PAD = 5, SEARCH_H = 13, HDR_Y = 21, LIST_Y = 32, ROWS = 7, ROW_H = 15, BTN_H = 14;
    private static final int BTN_Y = LIST_Y + ROWS * ROW_H + 4;
    private static final int PANEL = 0xF2181222, FIELD = 0xFF2B2240, ACCENT = 0xFFB57BD6, MUTED = 0xFF8F84B0, WHITE = 0xFFFFFFFF;

    private static boolean hints = true, hintsLoaded;

    private final StringBuilder query = new StringBuilder();
    private int scroll, sel, lastMx = -1, lastMy = -1;

    // ---------- state ----------
    /** Called every time the menu opens: an empty search, the list from the top. */
    public void open() {
        query.setLength(0);
        scroll = 0;
        sel = 0;
        loadHints();
    }

    private static void loadHints() {
        if (hintsLoaded || !Store.ready()) return;
        hintsLoaded = true;
        hints = !"0".equals(Store.read("startmenu"));
    }

    private static void setHints(boolean on) {
        hints = on;
        try { Store.write("startmenu", on ? "1" : "0"); } catch (Exception ignored) { }
    }

    private static Font font() { return Minecraft.getInstance().font; }

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    /** The apps that are installed and match the search, in Dock-number order. */
    private List<Integer> apps(Desktop d) {
        List<Integer> l = new ArrayList<>();
        String q = query.toString().trim().toLowerCase(Locale.ROOT);
        for (int i = 0; i < Desktop.ICONS; i++) {
            if (!Library.available(i)) continue;
            if (!q.isEmpty() && !d.label(i).toLowerCase(Locale.ROOT).contains(q)) continue;
            l.add(i);
        }
        return l;
    }

    private static int hintLines(Font f) {
        Component c = Component.translatable("cutemod.os.start.hint").append(Component.literal("  "))
                .append(Component.translatable("cutemod.os.start.keys2"));
        return Math.min(3, f.split(c, W - 2 * PAD).size());
    }

    /** Height of the whole menu in GUI pixels. */
    public int height() {
        Font f = font();
        return hints ? BTN_Y + BTN_H + 4 + hintLines(f) * 9 + 5 : BTN_Y + BTN_H + 6;
    }

    public boolean inside(int mx, int my, int sx, int sy) {
        return mx >= sx && mx < sx + W && my >= sy && my < sy + height();
    }

    private static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && py >= y && px < x + w && py < y + h;
    }

    private int btnW() { return (W - 2 * PAD - 6) / 3; }

    private int toggleW(Font f) { return f.width(tr("cutemod.os.start.hints")) + 4 + 16; }

    private void fixScroll(int size) {
        sel = Math.max(0, Math.min(size - 1, sel));
        if (sel < scroll) scroll = sel;
        if (sel >= scroll + ROWS) scroll = sel - ROWS + 1;
        scroll = Math.max(0, Math.min(Math.max(0, size - ROWS), scroll));
    }

    // ---------- input ----------
    /** A click: an app index, PIN + index (right-click), BTN + n, INSIDE (the menu ate it) or OUTSIDE (close the menu). */
    public int click(int mx, int my, int button, int sx, int sy, Desktop d) {
        if (!inside(mx, my, sx, sy)) return OUTSIDE;
        Font f = font();
        int rx = mx - sx, ry = my - sy;
        if (in(rx, ry, W - PAD - toggleW(f), HDR_Y, toggleW(f), 10)) {
            setHints(!hints);
            return INSIDE;
        }
        if (in(rx, ry, PAD, LIST_Y, W - 2 * PAD - 5, ROWS * ROW_H)) {
            List<Integer> l = apps(d);
            int idx = scroll + (ry - LIST_Y) / ROW_H;
            if (idx < l.size()) { sel = idx; return button == 1 ? PIN + l.get(idx) : l.get(idx); }
            return INSIDE;
        }
        if (ry >= BTN_Y && ry < BTN_Y + BTN_H && rx >= PAD) {
            int b = (rx - PAD) / (btnW() + 3);
            if (b < 3 && (rx - PAD) - b * (btnW() + 3) < btnW()) return BTN + b;
        }
        return INSIDE;
    }

    public boolean scroll(double amount, Desktop d) {
        int size = apps(d).size();
        scroll = Math.max(0, Math.min(Math.max(0, size - ROWS), scroll + (amount > 0 ? -1 : 1)));
        return true;
    }

    /** A key while the menu is open: an app index to open (Enter), INSIDE if it was used, NOT_HANDLED otherwise. */
    public int key(int keyCode, Desktop d) {
        List<Integer> l = apps(d);
        switch (keyCode) {
            case 259 -> {                                            // Backspace
                if (query.length() > 0) { query.setLength(query.length() - 1); sel = 0; scroll = 0; }
            }
            case 265 -> { sel--; fixScroll(l.size()); lastMx = Integer.MIN_VALUE; }   // Up
            case 264 -> { sel++; fixScroll(l.size()); lastMx = Integer.MIN_VALUE; }   // Down
            case 257, 335 -> {                                       // Enter
                fixScroll(l.size());
                if (!l.isEmpty()) return l.get(sel);
            }
            default -> { return NOT_HANDLED; }
        }
        return INSIDE;
    }

    public boolean charTyped(char c) {
        if (c < 32 || c == 127 || query.length() >= 20) return false;
        query.append(c);
        sel = 0;
        scroll = 0;
        return true;
    }

    /** Esc: clears the search first. Returns true if there was something to clear (the menu stays open then). */
    public boolean clearQuery() {
        if (query.length() == 0) return false;
        query.setLength(0);
        sel = 0;
        scroll = 0;
        return true;
    }

    // ---------- drawing ----------
    private static void rrect(GuiGraphics g, int x, int y, int w, int h, int r, int argb) {
        for (int dy = 0; dy < h; dy++) {
            double m = dy + 0.5;
            double e = m < r ? r - m : m > h - r ? m - (h - r) : 0;
            int inset = e > 0 ? (int) Math.round(r - Math.sqrt(Math.max(0, r * r - e * e))) : 0;
            g.fill(x + inset, y + dy, x + w - inset, y + dy + 1, argb);
        }
    }

    public void render(GuiGraphics g, int sx, int sy, int mx, int my, Desktop d, int body) {
        Font f = font();
        List<Integer> l = apps(d);
        boolean moved = mx != lastMx || my != lastMy;
        lastMx = mx;
        lastMy = my;
        int h = height();
        g.pose().pushPose();
        g.pose().translate(0, 0, 70);
        rrect(g, sx - 1, sy - 1, W + 2, h + 2, 5, 0x55FFFFFF);
        rrect(g, sx, sy, W, h, 4, PANEL);

        // the search box
        int qx = sx + PAD, qy = sy + PAD, qw = W - 2 * PAD;
        rrect(g, qx, qy, qw, SEARCH_H, 3, FIELD);
        g.fill(qx + 2, qy + SEARCH_H - 1, qx + qw - 2, qy + SEARCH_H, ACCENT);
        g.fill(qx + 4, qy + 3, qx + 8, qy + 4, MUTED);                       // a little magnifier
        g.fill(qx + 3, qy + 4, qx + 4, qy + 7, MUTED);
        g.fill(qx + 8, qy + 4, qx + 9, qy + 7, MUTED);
        g.fill(qx + 4, qy + 7, qx + 8, qy + 8, MUTED);
        g.fill(qx + 8, qy + 8, qx + 10, qy + 10, MUTED);
        String qs = query.toString();
        if (qs.isEmpty()) g.drawString(f, tr("cutemod.os.start.search"), qx + 14, qy + 3, MUTED, false);
        else {
            String shown = f.plainSubstrByWidth(qs, qw - 22, true);
            g.drawString(f, shown, qx + 14, qy + 3, WHITE, false);
            if ((System.currentTimeMillis() / 500) % 2 == 0) g.fill(qx + 14 + f.width(shown), qy + 2, qx + 15 + f.width(shown), qy + 10, WHITE);
        }

        // the header: what is listed, and the switch for the hints
        String title = qs.isEmpty() ? tr("cutemod.os.start.apps") : tr("cutemod.os.start.found", l.size());
        g.drawString(f, title, sx + PAD + 2, sy + HDR_Y + 1, MUTED, false);
        int tw = toggleW(f), tx = sx + W - PAD - tw, ty = sy + HDR_Y;
        String hl = tr("cutemod.os.start.hints");
        g.drawString(f, hl, tx, ty + 1, hints ? 0xFFD8CCF0 : MUTED, false);
        int swx = tx + tw - 16;
        rrect(g, swx, ty + 1, 16, 8, 4, hints ? ACCENT : 0xFF4A4060);
        rrect(g, hints ? swx + 9 : swx + 1, ty + 2, 6, 6, 3, WHITE);

        // the list
        fixScroll(l.size());
        int rowW = W - 2 * PAD - 5;
        if (l.isEmpty()) {
            String none = tr("cutemod.os.start.none");
            g.drawString(f, none, sx + (W - f.width(none)) / 2, sy + LIST_Y + 24, MUTED, false);
        }
        List<Integer> pinned = DockLayout.list();
        for (int i = 0; i < ROWS && scroll + i < l.size(); i++) {
            int idx = scroll + i, k = l.get(idx);
            int ex = sx + PAD, ey = sy + LIST_Y + i * ROW_H;
            if (moved && in(mx, my, ex, ey, rowW, ROW_H)) sel = idx;
            boolean on = idx == sel;
            if (on) rrect(g, ex, ey, rowW, ROW_H - 1, 3, ACCENT);
            g.pose().pushPose();
            g.pose().translate(ex + 3, ey + 1.5f, 0);
            g.pose().scale(12 / 32f, 12 / 32f, 1f);
            Desktop.drawIcon(g, k, 0, 0, body);
            g.pose().popPose();
            // the right side: the hotkey of a pinned app (if the hints are on) and the pin marker
            int rightEdge = ex + rowW - 12;
            int nameMax = rowW - 20 - 14;
            if (hints) {
                int n = pinned.indexOf(k);
                if (n >= 0 && n < 9) {
                    String hk = "Ctrl+" + (n + 1);
                    g.drawString(f, hk, rightEdge - f.width(hk), ey + 3, on ? 0xFFF3E8FF : MUTED, false);
                    nameMax -= f.width(hk) + 4;
                }
            }
            g.drawString(f, f.plainSubstrByWidth(d.label(k), nameMax), ex + 20, ey + 3, WHITE, false);
            int px = ex + rowW - 8, py = ey + 4;
            if (DockLayout.pinned(k)) g.fill(px, py, px + 5, py + 5, 0xFFFFE680);
            else {
                int c = on ? 0xCCFFFFFF : 0x77FFFFFF;
                g.fill(px, py, px + 5, py + 1, c); g.fill(px, py + 4, px + 5, py + 5, c);
                g.fill(px, py + 1, px + 1, py + 4, c); g.fill(px + 4, py + 1, px + 5, py + 4, c);
            }
        }
        if (l.size() > ROWS) {                                              // a thin scroll bar
            int bx = sx + W - PAD - 3, by = sy + LIST_Y, bh = ROWS * ROW_H - 1;
            g.fill(bx, by, bx + 2, by + bh, 0xFF2B2240);
            int th = Math.max(8, bh * ROWS / l.size());
            int tyy = by + (bh - th) * scroll / Math.max(1, l.size() - ROWS);
            g.fill(bx, tyy, bx + 2, tyy + th, MUTED);
        }

        // Desktop / Lock / Quit
        String[] names = {tr("cutemod.os.desktop"), tr("cutemod.os.lock"), tr("cutemod.os.quit")};
        int bw = btnW(), by = sy + BTN_Y;
        for (int b = 0; b < 3; b++) {
            int bx = sx + PAD + b * (bw + 3);
            boolean hov = in(mx, my, bx, by, bw, BTN_H);
            rrect(g, bx, by, bw, BTN_H, 3, hov ? ACCENT : 0xFF2F2650);
            String n = f.plainSubstrByWidth(names[b], bw - 4);
            g.drawString(f, n, bx + (bw - f.width(n)) / 2, by + 3, WHITE, false);
        }

        // the hotkey help (hidden with the switch)
        if (hints) {
            Component c = Component.translatable("cutemod.os.start.hint").append(Component.literal("  "))
                    .append(Component.translatable("cutemod.os.start.keys2"));
            int hy = by + BTN_H + 4, n = 0;
            for (var line : f.split(c, W - 2 * PAD)) {
                if (n++ >= 3) break;
                g.drawString(f, line, sx + PAD, hy, MUTED, false);
                hy += 9;
            }
        }
        g.pose().popPose();
    }
}
