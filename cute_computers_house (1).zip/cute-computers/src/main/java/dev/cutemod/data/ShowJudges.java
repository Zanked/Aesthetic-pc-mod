package dev.cutemod.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The cast of the talent show that is not a player: the judges (eight of them, four sit on the panel in every round)
 * and the "guest" pets that fill an empty stage.
 * Pure logic (no Minecraft classes). Everything is a function of the round number, so the server and a test
 * always agree and nothing has to be saved.
 */
public final class ShowJudges {
    private ShowJudges() {}

    /** The seats of the panel. A seat is a taste (0 cute, 1 style, 2 mystery, 3 effort): the stars come from the seat. */
    public static final int COUNT = 4;
    /** The judges of the pool: 2 for every seat. A judge is a seat plus 4 (persona = seat + 4 * alt, so persona % 4 is the seat). */
    public static final int PERSONAS = 8;
    /** The computer color of every judge: its animal is the judge (panda, creeper, enderman, bee, ladybug, fox, cat, penguin). */
    public static final String[] COLOR = {"white", "green", "purple", "yellow", "red", "orange", "pink", "blue"};
    /** What each judge wears in the picture. */
    public static final String[] HAT = {"acc_flower", "acc_party", "acc_witch", "acc_headphones", "acc_bow", "acc_beret", "acc_starclip", "acc_cap"};

    private static final String[] NAMES = {"Mochi", "Biscuit", "Pixel", "Nori", "Pudding", "Waffle", "Sprout", "Bean",
            "Cookie", "Pumpkin", "Luna", "Momo", "Kiwi", "Taco", "Peach", "Zephyr"};
    private static final String[] HATS = PetWear.botItems(false);
    private static final String[] BODIES = PetWear.botItems(true);
    private static final String[] COLORS = {"pink", "green", "white", "blue", "orange", "purple", "yellow", "red"};

    /** A guest pet: it is not a player, it only keeps the stage lively. hearts = the love of the crowd at the end (0-4). */
    public record Bot(String name, String color, int stage, int trait, int ageMin, String head, String body, int hearts) {}

    private static long mix(long x) {
        x += 0x9E3779B97F4A7C15L;
        x = (x ^ (x >>> 30)) * 0xBF58476D1CE4E5B9L;
        x = (x ^ (x >>> 27)) * 0x94D049BB133111EBL;
        return x ^ (x >>> 31);
    }

    /** A number in [-1, 1) that depends only on the inputs. */
    private static double noise(long a, long b, long c) {
        long h = mix(mix(mix(a) ^ b) ^ c);
        return ((h >>> 11) / (double) (1L << 53)) * 2 - 1;
    }

    private static long hash(String s) {
        long h = 1125899906842597L;
        for (int i = 0; i < s.length(); i++) h = 31 * h + s.charAt(i);
        return h;
    }

    /** The themes of the rounds. Every round has one; it gives a bonus to pets that fit it (see {@link #themeBonus}). */
    public static final int THEMES = 10;
    // 0 sweet and cute, 1 spooky night, 2 royal ball, 3 cozy winter, 4 rock star, 5 garden party,
    // 6 beach party, 7 space trip, 8 pirate adventure, 9 cooking show

    /** How many different panels there are: every seat has 2 judges to pick from, so 2^4. */
    public static final int PANELS = 1 << COUNT;

    /** One shuffle of all panels (same idea as {@link #block}). */
    private static int[] panelBlock(long b) {
        int[] p = new int[PANELS];
        for (int i = 0; i < PANELS; i++) p[i] = i;
        Random r = new Random(mix(b * 17 + 11));
        for (int i = PANELS - 1; i > 0; i--) {
            int k = r.nextInt(i + 1), t = p[i];
            p[i] = p[k];
            p[k] = t;
        }
        return p;
    }

    /**
     * Who sits on the panel in a round, as 4 bits: bit s set = the second judge of seat s. A pure function of the round
     * number (so the server, the client and a test always agree and nothing is saved). Every block of {@value #PANELS}
     * rounds shows each panel exactly once, in a shuffled order, and the panel is never the same twice in a row
     * (also not between two blocks), and two rounds in a row always differ in at least one judge.
     */
    public static int panelOf(long round) {
        long b = Math.floorDiv(round, (long) PANELS);
        int i = (int) Math.floorMod(round, (long) PANELS);
        int[] p = panelBlock(b);
        if (p[0] == panelBlock(b - 1)[PANELS - 1]) { int t = p[0]; p[0] = p[1]; p[1] = t; }
        return p[i];
    }

    /** The judge (0-7) that sits on a seat (0-3) of a panel (see {@link #panelOf}). */
    public static int persona(int panel, int seat) { return seat + COUNT * ((panel >> seat) & 1); }

    /** The seat (the taste) of a judge. */
    public static int seatOf(int persona) { return persona % COUNT; }

    /** One shuffle of all themes: every block of THEMES rounds shows each theme exactly once. */
    private static int[] block(long b) {
        int[] p = new int[THEMES];
        for (int i = 0; i < THEMES; i++) p[i] = i;
        Random r = new Random(mix(b * 13 + 5));
        for (int i = THEMES - 1; i > 0; i--) {
            int k = r.nextInt(i + 1), t = p[i];
            p[i] = p[k];
            p[k] = t;
        }
        return p;
    }

    /**
     * The theme of a round: a pure function of the round number. Every theme comes once in every {@value #THEMES}
     * rounds, in a shuffled order, and never the same twice in a row (also not between two blocks).
     */
    public static int themeOf(long round) {
        long b = Math.floorDiv(round, (long) THEMES);
        int i = (int) Math.floorMod(round, (long) THEMES);
        int[] p = block(b);
        if (p[0] == block(b - 1)[THEMES - 1]) { int t = p[0]; p[0] = p[1]; p[1] = t; }
        return p[i];
    }

    /** Up to +1.2 stars for a pet that fits the theme (a naked pet gets nothing, so clothes still matter most). */
    public static double themeBonus(int theme, int stage, int trait, String head, String body) {
        double b = 0;
        switch (theme) {
            case 0 -> { // sweet and cute
                if (has(head, "acc_bow", "acc_flower", "acc_halo")) b += 1.0;
                if (stage == 0) b += 0.4;
                if (trait == 3) b += 0.4;
            }
            case 1 -> { // spooky night
                if (has(head, "acc_ghost", "acc_horns", "acc_witch")) b += 1.0;
                if (has(body, "acc_cape")) b += 0.4;
                if (trait == 2) b += 0.3;
            }
            case 2 -> { // royal ball
                if (has(head, "acc_crown", "acc_champion")) b += 1.1;
                else if (has(head, "acc_hat", "acc_halo")) b += 0.6;
                if (has(body, "acc_cape")) b += 0.6;
                if (stage == 2) b += 0.3;
            }
            case 3 -> { // cozy winter
                if (has(head, "acc_ushanka")) b += 1.0;
                if (has(body, "acc_scarf")) b += 0.8;
                if (trait == 2) b += 0.2;
            }
            case 4 -> { // rock star
                if (has(head, "acc_headphones", "acc_glasses", "acc_cap")) b += 1.0;
                if (trait == 1) b += 0.5;
                if (has(body, "acc_cape")) b += 0.3;
            }
            case 5 -> { // garden party
                if (has(head, "acc_flower")) b += 1.0;
                else if (has(head, "acc_hat", "acc_cap", "acc_bow")) b += 0.6;
                if (trait == 0) b += 0.5;
            }
            case 6 -> { // beach party: the sunny and playful
                if (stage == 0) b += 0.2;
                if (trait == 0 || trait == 1) b += 0.3;
            }
            case 7 -> { // space trip: the mysterious and the grown-up
                if (trait == 2) b += 0.4;
                if (stage == 2) b += 0.3;
            }
            case 8 -> { // pirate adventure: the bold
                if (trait == 1) b += 0.4;
                if (stage >= 1) b += 0.2;
            }
            default -> { // cooking show: the hungry
                if (trait == 0) b += 0.5;
            }
        }
        b += PetWear.themeScore(theme, head, body);   // the clothes: every item says which themes it fits
        return Math.min(1.2, b);
    }

    /** True if the packed list of worn items holds one of these ids. */
    private static boolean has(String packed, String... ids) {
        for (String t : PetWear.layers(packed)) for (String i : ids) if (i.equals(t)) return true;
        return false;
    }

    /** A little extra for a layered look: +0.15 for every item beyond the first two, at most +0.45. */
    private static double layerBonus(String head, String body) {
        int n = PetWear.layers(head).length + PetWear.layers(body).length;
        return Math.min(0.45, 0.15 * Math.max(0, n - 2));
    }

    /**
     * How many stars (1-5) a judge gives to a pet. {@code judge} is the SEAT (0-3), and every seat has a taste: seat 0
     * (Mei or Lady) loves cute things, seat 1 (Boom or Fox) loves style, seat 2 (Void or Kit) loves mystery and seat 3
     * (Honey or Pip) loves effort. A pet in clothes scores better than a naked one,
     * and a pet that fits the theme of the round gets a bonus.
     * key = who it is (the player's UUID text or the name of a guest).
     */
    public static int stars(int judge, long round, String key, String color, int stage, int trait, int ageMin, String head, String body) {
        boolean hat = !head.isEmpty(), cloth = !body.isEmpty();
        double s = 1.6;
        switch (judge) {
            case 0 -> {
                s += stage == 0 ? 0.9 : stage == 1 ? 0.5 : 0.2;
                if (trait == 3) s += 0.7;
                s += has(head, "acc_bow", "acc_flower", "acc_halo", "acc_crown") ? 1.2 : hat ? 0.5 : 0;
                if (cloth) s += 0.4;
            }
            case 1 -> {
                s += has(head, "acc_witch", "acc_crown", "acc_champion", "acc_horns", "acc_cap", "acc_ushanka", "acc_hat") ? 1.3 : hat ? 0.6 : 0;
                s += has(body, "acc_cape") ? 1.2 : cloth ? 0.7 : 0;
                if (trait == 1) s += 0.5;
                if (stage == 2) s += 0.4;
            }
            case 2 -> {
                s += has(head, "acc_ghost", "acc_horns", "acc_witch", "acc_halo") ? 1.3 : hat ? 0.5 : 0;
                s += has(body, "acc_cape") ? 1.0 : cloth ? 0.5 : 0;
                if (trait == 2) s += 0.7;
                s += stage == 2 ? 0.6 : stage == 1 ? 0.3 : 0;
            }
            default -> {
                if (trait == 0 || trait == 1) s += 0.7;
                s += has(head, "acc_headphones", "acc_party", "acc_cap", "acc_glasses") ? 1.2 : hat ? 0.5 : 0;
                s += Math.min(ageMin, 1200) / 1200.0;
                if (stage >= 1) s += 0.3;
                if (cloth) s += 0.4;
            }
        }
        s += themeBonus(themeOf(round), stage, trait, head, body);
        s += PetWear.tasteBonus(judge, head, body);          // the new clothes: what this judge likes
        s += PetWear.setBonus(head, body);                     // whole sets (chef hat + apron...) win every judge
        s += layerBonus(head, body);                           // and so does a layered look
        s += 0.7 * noise(round, judge, hash(key + color));
        return Math.max(1, Math.min(5, (int) Math.round(s)));
    }

    /** The guests of a round (always 4; the stage shows as many as it needs, from the front of the list). */
    public static List<Bot> bots(long round) {
        Random r = new Random(mix(round * 31 + 7));
        List<Bot> out = new ArrayList<>();
        List<Integer> names = new ArrayList<>();
        for (int i = 0; i < NAMES.length; i++) names.add(i);
        java.util.Collections.shuffle(names, r);
        for (int i = 0; i < 4; i++) {
            String head = r.nextInt(100) < 55 ? HATS[1 + r.nextInt(HATS.length - 1)] : "";
            String body = r.nextInt(100) < 35 ? BODIES[1 + r.nextInt(BODIES.length - 1)] : "";
            int stage = 1 + r.nextInt(2);
            out.add(new Bot(NAMES[names.get(i)], COLORS[r.nextInt(COLORS.length)], stage, r.nextInt(4),
                    stage == 1 ? 25 + r.nextInt(30) : 70 + r.nextInt(500), head, body, r.nextInt(5)));
        }
        return out;
    }
}
