"""Generates the slim "Neo" laptops (textures + block models). Run from the project root: python3 tools/make_neo_laptop.py
Four small textures per colour in assets/cutemod/textures/block: <c>_neo_deck (keyboard + trackpad), <c>_neo_screen (wallpaper, menu bar, dock),
<c>_neo_back (the lid, with a heart) and <c>_neo_body (the metal). The models use them with uv 0..16, so every texture has the aspect of its face."""
import json, math, os
from PIL import Image, ImageDraw

TEX = 'src/main/resources/assets/cutemod/textures/block/'
MOD = 'src/main/resources/assets/cutemod/models/block/'
# colour -> (metal, wallpaper dark, wallpaper light)
COLORS = {
    'pink':   (0xF1C6CB, 0xB4456B, 0xFFB4C8),
    'green':  (0xB4DBBF, 0x2B7A5A, 0xA6F0C0),
    'white':  (0xDCDFE4, 0x55607A, 0xC6D2F2),
    'blue':   (0x6F7BC8, 0x2A2F7A, 0x9CB0FF),
    'orange': (0xF6BC92, 0xC0502A, 0xFFD08A),
    'purple': (0xBBA6E3, 0x5B3A9A, 0xE0B8FF),
    'yellow': (0xF3E082, 0xE0902A, 0xFFF3A8),
    'red':    (0xF08D88, 0xA82A3A, 0xFFB09C),
}
def rgb(h): return ((h >> 16) & 255, (h >> 8) & 255, h & 255)
def mix(a, b, t): return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(3))

def rr(d, box, r, fill):
    d.rounded_rectangle(box, radius=r, fill=fill)

def body(c):
    im = Image.new('RGBA', (4, 4), rgb(c) + (255,))
    return im

def deck(c):
    m = rgb(c)
    W, H = 104, 72
    im = Image.new('RGBA', (W, H))
    d = ImageDraw.Draw(im)
    for y in range(H):
        d.line([(0, y), (W, y)], fill=mix(mix(m, (255, 255, 255), 0.10), mix(m, (0, 0, 0), 0.06), y / H) + (255,))
    bed = mix(m, (0, 0, 0), 0.42); key = mix(m, (255, 255, 255), 0.62); legend = mix(m, (0, 0, 0), 0.55)
    rr(d, (4, 6, 99, 51), 2, bed)
    rows = [(8, 4, 14), (13, 6, 14), (20, 6, 14), (27, 6, 13), (34, 6, 12), (41, 6, 0)]
    for (y, h, n) in rows:
        if n:
            x = 6
            for k in range(n):
                kw = 6
                if y == 27 and k == 0: kw = 9
                if y == 34 and k == 0: kw = 11
                if y == 34 and k == n - 1: kw = 11
                if x + kw > 98: break
                d.rectangle((x, y, x + kw - 1, y + h - 1), fill=key)
                if h >= 6: d.point((x + kw // 2, y + h // 2), fill=legend)
                x += kw + 1
    # bottom row: modifiers, a long space bar, arrows
    y = 41
    x = 6
    for kw in (7, 7, 7, 7):
        d.rectangle((x, y, x + kw - 1, y + 5), fill=key); x += kw + 1
    d.rectangle((x, y, x + 33, y + 5), fill=key); x += 34
    for kw in (7, 7):
        d.rectangle((x, y, x + kw - 1, y + 5), fill=key); x += kw + 1
    d.rectangle((x + 1, y, x + 5, y + 2), fill=key); d.rectangle((x + 1, y + 3, x + 5, y + 5), fill=key)
    # trackpad
    edge = mix(m, (0, 0, 0), 0.22)
    rr(d, (34, 54, 69, 69), 3, edge)
    rr(d, (35, 55, 68, 68), 3, mix(m, (255, 255, 255), 0.18))
    # a soft light across the deck
    ov = Image.new('RGBA', (W, H), (0, 0, 0, 0)); od = ImageDraw.Draw(ov)
    for i in range(0, 30):
        od.line([(60 + i, 0), (20 + i, H)], fill=(255, 255, 255, 5))
    im.alpha_composite(ov)
    return im

def screen(c, dark, light):
    W, H = 104, 70
    im = Image.new('RGBA', (W, H), (10, 10, 14, 255))
    d = ImageDraw.Draw(im)
    wp = Image.new('RGBA', (W - 6, H - 6))
    wd = ImageDraw.Draw(wp)
    D, L = rgb(dark), rgb(light)
    for y in range(H - 6):
        for x in range(W - 6):
            t = (x / (W - 6) * 0.55 + (1 - y / (H - 6)) * 0.45)
            wp.putpixel((x, y), mix(D, L, t) + (255,))
    # soft swirls
    sw = Image.new('RGBA', wp.size, (0, 0, 0, 0)); sd = ImageDraw.Draw(sw)
    sd.ellipse((50, -20, 130, 40), fill=(255, 255, 255, 38)); sd.ellipse((-30, 30, 50, 90), fill=(255, 255, 255, 28))
    sd.ellipse((20, 18, 60, 50), fill=mix(L, (255, 255, 255), 0.4) + (40,))
    wp.alpha_composite(sw)
    # menu bar
    mb = Image.new('RGBA', (W - 6, 5), (255, 255, 255, 70)); wp.alpha_composite(mb, (0, 0))
    wd = ImageDraw.Draw(wp)
    wd.ellipse((2, 1, 4, 3), fill=(255, 255, 255, 255))
    for i in range(4): wd.rectangle((8 + i * 7, 2, 12 + i * 7, 2), fill=(255, 255, 255, 220))
    for i in range(3): wd.point((W - 6 - 5 - i * 4, 2), fill=(255, 255, 255, 255))
    # dock
    dk = Image.new('RGBA', wp.size, (0, 0, 0, 0)); dd = ImageDraw.Draw(dk)
    rr(dd, (26, 55, 71, 62), 3, (255, 255, 255, 95))
    wp.alpha_composite(dk)
    wd = ImageDraw.Draw(wp)
    cols = [(0xFF5C5C), (0xFFB84D), (0xFFE34D), (0x5CD65C), (0x4DB8FF), (0xB07CFF)]
    for i, cc in enumerate(cols):
        x = 29 + i * 7
        rr(wd, (x, 56, x + 4, 60), 1, rgb(cc) + (255,))
    # round the screen corners and set it into the bezel
    mask = Image.new('L', wp.size, 0); ImageDraw.Draw(mask).rounded_rectangle((0, 0, wp.size[0] - 1, wp.size[1] - 1), radius=3, fill=255)
    im.paste(wp, (3, 3), mask)
    d = ImageDraw.Draw(im)
    d.point((52, 1), fill=(60, 64, 80, 255))                      # the camera
    # glass glare
    g = Image.new('RGBA', (W, H), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
    for i in range(0, 14): gd.line([(70 + i, 0), (30 + i, H)], fill=(255, 255, 255, 6))
    im.alpha_composite(g)
    return im

def back(c):
    m = rgb(c)
    W, H = 104, 70
    im = Image.new('RGBA', (W, H))
    d = ImageDraw.Draw(im)
    for y in range(H):
        d.line([(0, y), (W, y)], fill=mix(mix(m, (255, 255, 255), 0.12), mix(m, (0, 0, 0), 0.08), y / H) + (255,))
    # a heart in the middle
    cx, cy = 52, 36
    heart = Image.new('RGBA', (W, H), (0, 0, 0, 0)); hd = ImageDraw.Draw(heart)
    sh = mix(m, (0, 0, 0), 0.25)
    for off, col in ((1, sh + (255,)), (0, mix(m, (255, 255, 255), 0.85) + (255,))):
        hd.ellipse((cx - 8, cy - 8 + off, cx, cy + off), fill=col)
        hd.ellipse((cx, cy - 8 + off, cx + 8, cy + off), fill=col)
        hd.polygon([(cx - 8, cy - 3 + off), (cx + 8, cy - 3 + off), (cx, cy + 9 + off)], fill=col)
    im.alpha_composite(heart)
    ov = Image.new('RGBA', (W, H), (0, 0, 0, 0)); od = ImageDraw.Draw(ov)
    for i in range(0, 20): od.line([(80 + i, 0), (30 + i, H)], fill=(255, 255, 255, 6))
    im.alpha_composite(ov)
    return im

def box(name, f, t, faces, rot=None):
    e = {'name': name, 'from': f, 'to': t, 'faces': faces}
    if rot: e['rotation'] = rot
    return e

def faces_all(tex): return {k: {'uv': [0, 0, 16, 16], 'texture': tex} for k in ('north', 'south', 'east', 'west', 'up', 'down')}

# the geometry (1/16 block). width 12.5, depth 8.7, the hinge at the back (z = 4.6)
X0, X1, Z0, Z1 = 1.75, 14.25, 4.6, 13.3
def model(open_):
    els = [box('base', [X0, 0, Z0], [X1, 0.35, Z1], faces_all('#body'))]
    top = faces_all('#body'); top['up'] = {'uv': [0, 0, 16, 16], 'texture': '#deck'}
    els.append(box('deck', [X0 + 0.12, 0.35, Z0 + 0.12], [X1 - 0.12, 0.6, Z1 - 0.12], top))
    if open_:
        els.append(box('hinge', [3, 0.45, Z0 - 0.1], [13, 0.8, Z0 + 0.25], faces_all('#body')))
        lid = faces_all('#body')
        lid['south'] = {'uv': [0, 0, 16, 16], 'texture': '#screen'}
        lid['north'] = {'uv': [0, 0, 16, 16], 'texture': '#back'}
        els.append(box('lid', [X0, 0.6, Z0], [X1, 9.0, Z0 + 0.4], lid,
                       {'origin': [8, 0.6, Z0 + 0.2], 'axis': 'x', 'angle': -22.5}))
    else:
        lid = faces_all('#body'); lid['up'] = {'uv': [0, 0, 16, 16], 'texture': '#back'}
        els.append(box('lid_closed', [X0, 0.6, Z0], [X1, 1.0, Z1], lid))
    return els

if __name__ == '__main__':
    for name, (metal, dark, light) in COLORS.items():
        body(metal).save(TEX + f'{name}_neo_body.png')
        deck(metal).save(TEX + f'{name}_neo_deck.png')
        screen(metal, dark, light).save(TEX + f'{name}_neo_screen.png')
        back(metal).save(TEX + f'{name}_neo_back.png')
        tex = {'particle': f'cutemod:block/{name}_neo_body', 'body': f'cutemod:block/{name}_neo_body', 'deck': f'cutemod:block/{name}_neo_deck',
               'screen': f'cutemod:block/{name}_neo_screen', 'back': f'cutemod:block/{name}_neo_back'}
        for open_, suffix in ((True, ''), (False, '_closed')):
            data = {'credit': 'slim Neo-style laptop (generated by tools/make_neo_laptop.py)', 'ambientocclusion': False, 'textures': tex, 'elements': model(open_)}
            json.dump(data, open(MOD + f'{name}_laptop{suffix}.json', 'w'), indent=1)
    print('done')
