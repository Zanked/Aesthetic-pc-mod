# Cute Computers (NeoForge 1.21.1)

Cute retro computers in 8 colors. **Right-click a computer to open its desktop.**
The desktop looks like macOS: a menu bar on top (logo menu, app name, coins, clock), windows with red/yellow/green buttons and a **Dock** at the bottom whose icons grow under the mouse. The Dock has: your computer's own game, a **Games** folder (all 8 games on any computer), a **Browser**, **Notes**, **Paint**, **Calculator** and **Settings**.
No redstone or energy needed. Every computer remembers its own high score and who set it.

![preview](docs/preview.png)

| Block | Game | Controls |
|---|---|---|
| `pink_computer` | Flappy Cat | click / Space |
| `green_computer` | Creeper Sweeper (minesweeper) | LMB dig, RMB flag |
| `white_computer` | Panda Snake | WASD / arrows |
| `blue_computer` | Penguin Fishing | mouse (avoid the pufferfish!) |
| `orange_computer` | Fox Memory (pairs) | click |
| `purple_computer` | Ender Dodge | mouse |
| `yellow_computer` | Whack-a-Bee | click the bee |
| `red_computer` | Ladybug Match (match-3, 20 moves) | click two neighbors |

## Desktop apps
| App | What it does |
|---|---|
| CuteStore | the game store: **all games cost coins**. Store tab with a *game of the day* (-30%, changes every day), cover art, ratings and descriptions; buying starts an **install** (a few seconds of real time, it keeps going even if you close the screen). Library tab: your games, play time and best scores. **Reviews**: every game has reviews from other players, and once you own a game you can leave your own stars + text (first review = +3 coins) |
| Sakura Catch, Cute Blocks | two more store games: an anime-style catcher (chibi girl with a parasol, petals, onigiri, storm clouds) and a pastel falling-blocks puzzle |
| Durak | a card game for two in CuteStore (45 coins): the classic Russian *Durak* against the computer. 36 cards, trump suit, attack / defend / take / add cards |
| CuteJobs | **7 jobs to earn coins** (short 1-minute shifts): Typist, Postman, Pet Sitter (rank Intern), Cafe, Courier (Employee), Artist, Game Tester (Senior). Shifts give experience and ranks (x1 / x1.25 / x1.5 / x2 pay); each job has a 3 minute rest after a shift; a shift with quality under 20% pays nothing |
| CuteMarket | the online shop (also `cutemarket.cute` in the browser): order **8 foods** and **12 pieces of clothes** for coins, put them in a cart, pick *Express* (+30% price, 3x faster) and follow the delivery in real time (a pink courier runs along a progress bar, the Dock icon shows a badge when a parcel arrives). Meals give a temporary **well fed** bonus to the coins from games and jobs (+5..15% for 5-10 min); every worn piece of clothes gives a permanent **style** bonus (+3%). The Me tab has your doll with a wardrobe and a fridge |
| Halloween event | Oct 24 - Nov 3 by the real calendar (or any time with the terminal command `halloween`): sweets, golden sweets and ghosts pop up on the desktop with bats and cobwebs. Click the sweets to collect candy (shown in the menu bar), click the pumpkin lantern in the corner to trade candy for coins, the *Haunted Pumpkin Night* wallpaper, or the horror games (Something in the Dark, Dark Corridor, Zombie Shooter). Horror games are on sale (-50%) in the store, three letters arrive in the mail and there is an achievement for 50 candy |
| Games | the games you bought and installed (any computer; the record in the block counts only for the computer's own game). Extra games: Cookie Breaker (breakout), Merge Cubes (2048), Slime Pong, Bee Invaders, Something in the Dark (horror: the monster only moves while you're not lighting it), **Dark Corridor** (first-person horror: a random dark maze, find 3 keys and the green door while a pale figure hunts you; WASD/arrows, a map of the places you have been in the corner), **MiniCraft** (a tiny side-view Minecraft: A/D walk, W jump, LMB mine / hit, RMB place, 1-4 hotbar, C planks, E next pickaxe; chop a tree, craft wooden, stone and iron pickaxes, dig for coal, iron and **3 diamonds** while zombies come at night; they chew through trees and dirt but stone and planks stop them), **Zombie Shooter** (first-person wave shooter in the style of Call of Duty Zombies: endless rounds in one arena, 10 points per hit and 60 per kill, health regenerates when you are not hit; WASD walk, mouse near the left/right edge or arrows turn, LMB/Space shoot, R reload, 1/2/Q switch weapon, E at the golden wall to buy a rifle (500) and ammo (250)). The Games folder has 2 pages (arrows or mouse wheel) |
| Browser | the **Cute Web**, a made-up internet (GTA 5 style): `peep.cute` search, `chirp.cute`, `creepermart.cute`, `pandapedia.cute`, `beemail.cute`, `cutenews.cute`, `scarystories.cute` (dark theme, flickering light, watching eyes). Also `cutetube.cute` - **CuteTube**: 6 tiny animated videos with note-block sound, a progress bar and volume slider, likes, ready-made comments and your own (type in the box, Enter sends; space = pause, arrows = skip 5 s). With **Spooky** on, a 7th video appears: "Don't Watch at 3 AM" (eyes in the corner, something in the door, a jump scare, and it says your name at the end). Every page has an animated ad banner at the bottom (click it to visit the advertiser, "x" skips to the next ad). Words in the address bar search it; real addresses like `example.com` open in your system browser after the vanilla "open link?" confirmation |
| Haunting | on its own the computer sometimes shows annoying pop-up ads (the "x" runs away, "bad" buttons spawn more windows) and creepy events: watching eyes, screen glitches, whispers, a fake record held by "The One Behind You", a line that types itself in Notes (never saved), corrupted ads in the browser. Everything is display-only. Settings has switches for **Spooky** and **Pop-ups** |
| Music | player with 4 little songs played on note-block sounds (lead + bass), equalizer, volume. Plays while the app is open |
| Tamagotchi | every computer color has its own pet (cat, creeper, panda, penguin, fox, enderman, bee, ladybug): feed it, play, let it sleep, pet it. Saved on the server (per player), gets hungry slowly even while you are away |
| Shop | spend coins on 6 extra wallpapers, 8 pet accessories (the golden crown is a story reward) and 4 extra songs for the player; tabs filter the list. Treats (cookie, fish, honey, milk, cake) are consumables: buy a stock, then click one under the pet's room to feed it |
| Diary | the story quest (13 chapters in 2 parts: "Strange Stories" and "The Quiet One"), 3 daily tasks with a login streak bonus, and 14 achievements |
| Terminal | command line: `help`, `whoami`, `scan`, `unlock`, `cat`, `ls`, `bee`, `creeper`, `matrix`, `fortune` and more (some are part of the quest: `archive <code>`, `stay` / `bye`) |
| Coins | you get coins for playing games (each game has its own scale: a good result is worth about 10 coins, at most 25 per game and 150 per day from games), pet care, finished videos, achievements, daily tasks and quest chapters. The balance is shown in the taskbar. Everything is saved on the server, per player (UUID) |
| Notes | text editor, saved on the server, per player |
| Paint | 64x36 pixel drawing (LMB draw, RMB erase) |
| Calculator | mouse or keyboard |
| Settings | 6 wallpapers, saved on the server, per player |

## Crafting
- Pink computer: iron ingots, glass pane, pink dye, redstone (`IGI / IDI / IRI`).
- Any other color: any computer + the matching dye (shapeless).

## Build
Requires Java 21.

```
./gradlew build          # jar in build/libs
./gradlew runClient      # test in game
```
GitHub Actions (`.github/workflows/build.yml`) builds the jar on every push.

## Project layout
- `src/main/java/dev/cutemod` - blocks, block entity (high score), network packet
- `src/main/java/dev/cutemod/client` - the monitor screen, `os/` (desktop and apps) and `game/` (all 8 mini games)
- `src/main/resources/assets/cutemod` - models, blockstates, textures (64x), lang (en, ru)
- `tools/` - Python scripts that generated the colored textures from the original pink pack

## Adding a new app
Extend `App` (`title`, `render`, optionally `tick`/`click`/`key`/`charTyped`) and add an icon in `Desktop`.

## Adding a new game
Extend `MiniGame` (`reset`, `tick` at 60/s, `render`, optionally `click`/`key`) and map it to a color in `GameFactory`.

## License
MIT
