package dev.cutemod.client.os;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * CuteMarket: the online shop. Food and clothes are ordered for coins and delivered in real time.
 * Meals give a temporary "well fed" bonus to the coins from games and jobs, worn clothes give a small
 * permanent "style" bonus. Everything is saved on the server through {@link Store} (blob "market").
 */
public final class Market {
    private Market() {}

    public static final int FOOD = 0, CLOTHES = 1;
    public static final int HEAD = 0, TOP = 1, FEET = 2, EXTRA = 3;
    public static final int STYLE_PCT = 3;          // each worn piece
    public static final int MAX_ORDERS = 14;
    public static final int EXPRESS_PCT = 30, EXPRESS_SPEED = 3;

    /** kind, price in coins, slot (clothes), delivery seconds, bonus % and minutes (food). */
    public record Item(String id, int kind, int price, int slot, int secs, int pct, int mins) {}

    public static final Item[] ITEMS = {
            new Item("cupcake", FOOD, 8, 0, 25, 5, 5),
            new Item("icecream", FOOD, 9, 0, 25, 5, 5),
            new Item("bubbletea", FOOD, 10, 0, 30, 8, 6),
            new Item("toast", FOOD, 12, 0, 30, 8, 6),
            new Item("burger", FOOD, 15, 0, 40, 10, 8),
            new Item("pizza", FOOD, 18, 0, 45, 12, 8),
            new Item("ramen", FOOD, 20, 0, 50, 12, 10),
            new Item("sushi", FOOD, 22, 0, 60, 15, 10),
            new Item("cap", CLOTHES, 40, HEAD, 90, 0, 0),
            new Item("beanie", CLOTHES, 45, HEAD, 90, 0, 0),
            new Item("bunny", CLOTHES, 60, HEAD, 120, 0, 0),
            new Item("witch", CLOTHES, 70, HEAD, 120, 0, 0),
            new Item("tee", CLOTHES, 40, TOP, 90, 0, 0),
            new Item("sailor", CLOTHES, 65, TOP, 120, 0, 0),
            new Item("hoodie", CLOTHES, 70, TOP, 120, 0, 0),
            new Item("sneakers", CLOTHES, 55, FEET, 100, 0, 0),
            new Item("boots", CLOTHES, 75, FEET, 120, 0, 0),
            new Item("glasses", CLOTHES, 45, EXTRA, 100, 0, 0),
            new Item("scarf", CLOTHES, 50, EXTRA, 100, 0, 0),
            new Item("wings", CLOTHES, 120, EXTRA, 180, 0, 0)};

    public static final class Order {
        public String id;
        public int qty;
        public long ready;
        public boolean done;
    }

    private static final List<Order> orders = new ArrayList<>();
    private static final Set<String> own = new HashSet<>();
    private static final String[] worn = {"", "", "", ""};
    private static final Map<String, Integer> meals = new HashMap<>();
    private static final Set<Long> notified = new HashSet<>();
    private static long fedUntil;
    private static int fedPct, gen = -1, pollTimer;

    public static Item item(String id) {
        for (Item i : ITEMS) if (i.id().equals(id)) return i;
        return ITEMS[0];
    }

    public static List<Item> of(int kind) {
        List<Item> out = new ArrayList<>();
        for (Item i : ITEMS) if (i.kind() == kind) out.add(i);
        return out;
    }

    // ---------- saving ----------
    private static void ensure() {
        if (gen == Store.gen()) return;
        gen = Store.gen();
        orders.clear(); own.clear(); meals.clear(); notified.clear();
        java.util.Arrays.fill(worn, "");
        fedUntil = 0; fedPct = 0;
        Properties p = Store.readProps("market");
        if (p == null) return;
        try {
            String os = p.getProperty("orders", "");
            for (String part : os.split(";")) {
                String[] f = part.split(":");
                if (f.length < 4) continue;
                Order o = new Order();
                o.id = f[0]; o.qty = Integer.parseInt(f[1]); o.ready = Long.parseLong(f[2]); o.done = f[3].equals("1");
                orders.add(o);
            }
            for (String s : p.getProperty("own", "").split(",")) if (!s.isBlank()) own.add(s.trim());
            String[] w = p.getProperty("wear", "").split(",", -1);
            for (int i = 0; i < worn.length && i < w.length; i++) worn[i] = w[i].trim().equals("-") ? "" : w[i].trim();
            for (String s : p.getProperty("meals", "").split(",")) {
                String[] f = s.split(":");
                if (f.length == 2) meals.put(f[0], Integer.parseInt(f[1]));
            }
            String[] fed = p.getProperty("fed", "0:0").split(":");
            fedUntil = Long.parseLong(fed[0]); fedPct = Integer.parseInt(fed[1]);
        } catch (Exception ignored) {
        }
    }

    private static void save() {
        Properties p = new Properties();
        StringBuilder sb = new StringBuilder();
        for (Order o : orders) sb.append(sb.length() == 0 ? "" : ";").append(o.id).append(':').append(o.qty).append(':').append(o.ready).append(':').append(o.done ? 1 : 0);
        p.setProperty("orders", sb.toString());
        p.setProperty("own", String.join(",", own));
        StringBuilder w = new StringBuilder();
        for (int i = 0; i < worn.length; i++) w.append(i == 0 ? "" : ",").append(worn[i].isEmpty() ? "-" : worn[i]);
        p.setProperty("wear", w.toString());
        StringBuilder m = new StringBuilder();
        meals.forEach((k, v) -> { if (v > 0) m.append(m.length() == 0 ? "" : ",").append(k).append(':').append(v); });
        p.setProperty("meals", m.toString());
        p.setProperty("fed", fedUntil + ":" + fedPct);
        Store.writeProps("market", p);
    }

    // ---------- shopping ----------
    public static boolean owns(String id) { ensure(); return own.contains(id); }

    /** A piece of clothing that is already in an order on its way. */
    public static boolean pending(String id) {
        ensure();
        for (Order o : orders) if (!o.done && o.id.equals(id)) return true;
        return false;
    }

    public static int total(Map<String, Integer> cart, boolean express) {
        int sum = 0;
        for (Map.Entry<String, Integer> e : cart.entrySet()) sum += item(e.getKey()).price() * e.getValue();
        return express ? (int) Math.ceil(sum * (100 + EXPRESS_PCT) / 100.0) : sum;
    }

    /** Pays and creates one order per item. Returns false if there are not enough coins. */
    public static boolean checkout(Map<String, Integer> cart, boolean express) {
        ensure();
        if (cart.isEmpty() || !Progress.spend(total(cart, express))) return false;
        long now = System.currentTimeMillis();
        for (Map.Entry<String, Integer> e : cart.entrySet()) {
            Item it = item(e.getKey());
            Order o = new Order();
            o.id = it.id(); o.qty = e.getValue();
            o.ready = now + it.secs() * 1000L / (express ? EXPRESS_SPEED : 1);
            o.done = false;
            orders.add(o);
        }
        while (orders.size() > MAX_ORDERS) {              // drop the oldest finished order
            int drop = -1;
            for (int i = 0; i < orders.size(); i++) if (orders.get(i).done) { drop = i; break; }
            if (drop < 0) break;
            orders.remove(drop);
        }
        Progress.bump("market_orders");
        save();
        return true;
    }

    /** Newest first. */
    public static List<Order> orders() {
        ensure();
        List<Order> out = new ArrayList<>(orders);
        java.util.Collections.reverse(out);
        return out;
    }

    public static int active() {
        ensure();
        int n = 0;
        for (Order o : orders) if (!o.done) n++;
        return n;
    }

    /** Orders that have arrived and wait to be collected. */
    public static int readyCount() {
        ensure();
        int n = 0;
        for (Order o : orders) if (arrived(o)) n++;
        return n;
    }

    public static int secondsLeft(Order o) { return (int) Math.max(0, (o.ready - System.currentTimeMillis() + 999) / 1000); }

    public static boolean arrived(Order o) { return !o.done && o.ready <= System.currentTimeMillis(); }

    public static void collect(Order o) {
        ensure();
        if (!arrived(o)) return;
        o.done = true;
        Item it = item(o.id);
        if (it.kind() == CLOTHES) own.add(o.id);
        else meals.merge(o.id, o.qty, Integer::sum);
        save();
    }

    /** Called 60 times per second: once a second it tells the player about orders that have just arrived. */
    public static void tick() {
        if (++pollTimer < 60) return;
        pollTimer = 0;
        ensure();
        for (Order o : orders) {
            if (arrived(o) && notified.add(o.ready)) {
                Progress.toast("cutemod.toast.market_arrived", net.minecraft.network.chat.Component.translatable("cutemod.market.item." + o.id).getString());
            }
        }
    }

    // ---------- wardrobe and fridge ----------
    public static String worn(int slot) { ensure(); return worn[slot]; }

    public static void wear(String id) {
        ensure();
        if (!own.contains(id)) return;
        int s = item(id).slot();
        worn[s] = worn[s].equals(id) ? "" : id;
        save();
    }

    public static List<Item> ownedClothes() {
        ensure();
        List<Item> out = new ArrayList<>();
        for (Item i : ITEMS) if (i.kind() == CLOTHES && own.contains(i.id())) out.add(i);
        return out;
    }

    public static int meals(String id) { ensure(); return meals.getOrDefault(id, 0); }

    public static List<Item> fridge() {
        ensure();
        List<Item> out = new ArrayList<>();
        for (Item i : ITEMS) if (i.kind() == FOOD && meals.getOrDefault(i.id(), 0) > 0) out.add(i);
        return out;
    }

    public static boolean eat(String id) {
        ensure();
        if (meals.getOrDefault(id, 0) <= 0) return false;
        Item it = item(id);
        long now = System.currentTimeMillis();
        meals.merge(id, -1, Integer::sum);
        fedPct = Math.max(now < fedUntil ? fedPct : 0, it.pct());
        fedUntil = Math.max(now, fedUntil) + it.mins() * 60_000L;
        Progress.bump("meals_eaten");
        save();
        return true;
    }

    // ---------- the bonuses ----------
    public static int styleCount() {
        ensure();
        int n = 0;
        for (String w : worn) if (!w.isEmpty()) n++;
        return n;
    }

    public static int stylePct() { return styleCount() * STYLE_PCT; }

    public static int fedLeftSec() {
        ensure();
        return (int) Math.max(0, (fedUntil - System.currentTimeMillis()) / 1000);
    }

    public static int fedPctNow() { return fedLeftSec() > 0 ? fedPct : 0; }

    /** Multiplier for the coins from games and jobs. */
    public static float bonus() { return 1f + (stylePct() + fedPctNow()) / 100f; }
}
