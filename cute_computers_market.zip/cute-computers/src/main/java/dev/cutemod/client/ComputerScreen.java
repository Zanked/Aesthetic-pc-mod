package dev.cutemod.client;

import dev.cutemod.ComputerColor;
import dev.cutemod.block.ComputerBlockEntity;
import dev.cutemod.client.os.App;
import dev.cutemod.client.os.Desktop;
import dev.cutemod.client.os.Dock;
import dev.cutemod.client.os.Halloween;
import dev.cutemod.client.os.Market;
import dev.cutemod.client.os.DockLayout;
import dev.cutemod.client.os.Haunt;
import dev.cutemod.client.os.Library;
import dev.cutemod.client.os.Progress;
import dev.cutemod.client.os.Sfx;
import dev.cutemod.client.os.Shell;
import dev.cutemod.client.os.Startup;
import dev.cutemod.client.os.Wallpaper;
import dev.cutemod.net.ScorePayload;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.net.URI;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** The "monitor": a little desktop with games, a browser and other apps. */
public class ComputerScreen extends Screen implements Shell {
    private static final int PAD = 10;
    private static final int HEADER = 8;     // thin frame above the screen
    private static final int MENU = 12;      // menu bar
    private static final int TB = 12;        // window title bar (traffic lights)
    private static final int DOCK = Dock.HEIGHT;
    private static final int FOOTER = 29;     // up to three lines: the record and a hint that wraps to two
    private static final int VIEW_W = App.W;
    private static final long STEP_NS = 16_666_667L; // apps run at 60 steps/second
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("EEE HH:mm");

    private final ComputerColor color;
    private final BlockPos pos;
    private final Desktop desktop = new Desktop();
    private final Haunt haunt = new Haunt();
    private final Dock dock = new Dock();
    private final Startup startup = new Startup();
    private static final int IDLE_TICKS = 60 * 90;   // screensaver after 90 s without input
    // Dock: press on an icon, drag to move it, release to open (or drop it out of the Dock to remove it)
    private int pressApp = -1, pressX, pressY, ctxApp = -1, ctxX;
    private boolean dragging;
    // Start menu geometry
    private static final int SM_COLS = 2, SM_ROWS = 8, SM_CW = 100, SM_RH = 13, SM_PAD = 4, SM_BTN_H = 14;
    // opening animation: the window grows out of the icon (or the Start button) it was launched from
    private static final float ANIM_STEP = 1f / 14f;      // per tick: about 0.23 s
    private float animT = 1f;
    private float animX = Float.NaN, animY;                // launch origin on screen (NaN = the middle of the Dock)
    private boolean linking;      // a link dialog is open on top: not a real shutdown
    private int idle, lastMx = -1, lastMy = -1;
    private boolean menuOpen;
    private App app;

    private int left, top, gx, gy, panelW, panelH, menuY, dockY;
    private long lastNs = 0, acc = 0;

    public ComputerScreen(ComputerColor color, BlockPos pos) {
        super(Component.translatable("cutemod.os.title"));
        this.color = color;
        this.pos = pos;
        open(desktop);
    }

    // ---------- Shell ----------
    @Override
    public void open(App next) {
        if (app != null) app.close();
        app = next;
        app.attach(this);
        acc = 0;
        animT = next == desktop ? 1f : 0f;                  // going home has no animation
    }

    @Override
    public void home() { open(desktop); }

    @Override
    public ComputerColor color() { return color; }

    @Override
    public void openLink(String url) {
        Minecraft mc = Minecraft.getInstance();
        linking = true;
        mc.setScreen(new ConfirmLinkScreen(accepted -> {
            linking = false;
            if (accepted) {
                try {
                    Util.getPlatform().openUri(URI.create(url));
                } catch (Exception ignored) {
                }
            }
            mc.setScreen(this);
        }, url, true));
    }

    @Override
    public void submitScore(ComputerColor game, int score) {
        // only the computer's own game counts for the record stored in the block
        if (game == color) PacketDistributor.sendToServer(new ScorePayload(pos, score));
    }

    @Override
    public int absX() { return gx; }

    @Override
    public int absY() { return gy; }

    // ---------- Screen ----------
    @Override
    protected void init() {
        panelW = VIEW_W + PAD * 2;
        panelH = HEADER + MENU + TB + App.H + DOCK + FOOTER;
        left = (width - panelW) / 2;
        top = (height - panelH) / 2;
        menuY = top + HEADER;
        gx = left + PAD;
        gy = menuY + MENU + TB;       // top-left of the app area
        dockY = gy + App.H;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        Sfx.stopFan();
        if (!linking) Sfx.jingleNow(Sfx.SHUTDOWN);
        app.close();
        Progress.save();
        Library.save();
        super.removed();
    }

    private ComputerBlockEntity be() {
        var level = Minecraft.getInstance().level;
        if (level != null && level.getBlockEntity(pos) instanceof ComputerBlockEntity b) return b;
        return null;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        super.render(g, mouseX, mouseY, partial);

        // --- fixed timestep for the apps ---
        long now = System.nanoTime();
        if (lastNs == 0) lastNs = now;
        acc += now - lastNs;
        lastNs = now;
        if (acc > 100_000_000L) acc = 100_000_000L;
        Sfx.keepFan();
        if (mouseX != lastMx || mouseY != lastMy) { lastMx = mouseX; lastMy = mouseY; idle = 0; }
        app.mouse(mouseX - gx, mouseY - gy);
        while (acc >= STEP_NS) {
            acc -= STEP_NS;
            startup.tick();
            if (animT < 1f) animT = Math.min(1f, animT + ANIM_STEP);
            if (!startup.active()) {                       // nothing runs behind the boot / lock / screensaver
                app.tick();
                haunt.tick(app);
                if (app.busy()) idle = 0;
                else if (++idle >= IDLE_TICKS && startup.canSave()) { startup.saver(); idle = 0; }
            }
            if (!startup.active()) Progress.tick();      // pop-ups wait until the desktop is visible
            Library.tick();
            Market.tick();
        }

        // --- computer casing ---
        int body = 0xFF000000 | color.bodyColor;
        boolean darkBody = luminance(color.bodyColor) < 110;
        int textCol = darkBody ? 0xFFFFFFFF : 0xFF3A2A3A;
        int viewH = MENU + TB + App.H + DOCK;
        g.fill(left - 3, top - 3, left + panelW + 3, top + panelH + 3, 0xFF2A2030);
        g.fill(left - 2, top - 2, left + panelW + 2, top + panelH + 2, body);
        g.fill(left - 2, top - 2, left + panelW + 2, top - 1, 0x66FFFFFF);
        g.fill(gx - 4, menuY - 4, gx + VIEW_W + 4, menuY + viewH + 4, 0xFF1B1422);

        // --- wallpaper behind the menu bar, the apps and the Dock ---
        Wallpaper.draw(g, gx, menuY, VIEW_W, viewH, color.bodyColor, Wallpaper.get());

        // --- the window (title bar + app) grows out of its icon when it opens ---
        g.pose().pushPose();
        if (animT < 1f) {
            float e = 1f - (1f - animT) * (1f - animT) * (1f - animT);      // ease out
            float sc = 0.12f + 0.88f * e;
            float ax = Float.isNaN(animX) ? gx + VIEW_W / 2f : animX, ay = Float.isNaN(animX) ? dockY : animY;
            g.pose().translate(ax * (1 - sc), ay * (1 - sc), 0);
            g.pose().scale(sc, sc, 1f);
        }

        // --- window title bar with the "traffic lights" (not on the bare desktop) ---
        boolean onDesktop = app == desktop;
        int tbY = gy - TB;
        if (!onDesktop) {
            g.fillGradient(gx, tbY, gx + VIEW_W, gy, 0xFFEEE9F3, 0xFFD9D3E3);
            g.fill(gx, gy - 1, gx + VIEW_W, gy, 0xFFB9B0C8);
            boolean overLights = mouseX >= gx + 2 && mouseX < gx + 36 && mouseY >= tbY && mouseY < gy;
            int[] cols = {0xFFFF5F57, 0xFFFEBC2E, 0xFF28C840};
            for (int i = 0; i < 3; i++) {
                int cx = gx + 8 + i * 10, cy = tbY + TB / 2;
                circle(g, cx, cy, 3, overLights ? cols[i] : (cols[i] & 0x00FFFFFF) | 0xFF000000);
                circle(g, cx, cy, 2, shadeUp(cols[i]));
            }
            Component title = app.title();
            g.drawString(font, title, gx + (VIEW_W - font.width(title)) / 2, tbY + 2, 0xFF3A2A3A, false);
        }

        // --- app ---
        g.enableScissor(gx, gy, gx + VIEW_W, gy + App.H);
        g.pose().pushPose();
        g.pose().translate(gx, gy, 0);
        app.render(g, mouseX - gx, mouseY - gy);
        haunt.render(g, mouseX - gx, mouseY - gy);
        Progress.renderToast(g);
        g.pose().popPose();
        g.disableScissor();
        g.pose().popPose();

        // --- menu bar ---
        g.fill(gx, menuY, gx + VIEW_W, menuY + MENU, 0x99101018);
        drawLogo(g, gx + 5, menuY + 3);
        Component name = (onDesktop ? Component.translatable("cutemod.os.title") : app.title()).copy().withStyle(ChatFormatting.BOLD);
        g.drawString(font, name, gx + 19, menuY + 2, 0xFFFFFFFF, false);
        Component status = app.status();
        int sx = gx + 19 + font.width(name) + 10;
        if (!status.getString().isEmpty() && sx + font.width(status) < gx + VIEW_W - 80) {
            g.drawString(font, status, sx, menuY + 2, 0xCCFFFFFF, false);
        }
        String clock = LocalDateTime.now().format(CLOCK);
        g.drawString(font, clock, gx + VIEW_W - 5 - font.width(clock), menuY + 2, 0xFFFFFFFF, false);
        String coinText = Integer.toString(Progress.coins());
        int coinX = gx + VIEW_W - 5 - font.width(clock) - 10 - font.width(coinText);
        Progress.drawCoin(g, coinX - 10, menuY + 2);
        g.drawString(font, coinText, coinX, menuY + 2, 0xFFFFE680, false);
        if (Halloween.active()) {                                   // the event: the candy count next to the coins
            String candyText = Integer.toString(Halloween.candy());
            int candyX = coinX - 18 - font.width(candyText);
            Halloween.drawCandy(g, candyX - 10, menuY + 3);
            g.drawString(font, candyText, candyX, menuY + 2, 0xFFFFA040, false);
        }

        // --- Dock ---
        if (pressApp >= 0 && dragging) dock.setDrag(pressApp, dock.slotAt(gx, VIEW_W, mouseX), mouseX, mouseY, mouseY < dockY - 12);
        else dock.clearDrag();
        dock.render(g, desktop, app, color.bodyColor, gx, dockY, VIEW_W, mouseX, mouseY, app != desktop);

        // --- the Start menu: every app, plus Desktop / Lock / Quit ---
        if (menuOpen) renderStart(g, mouseX, mouseY);

        // --- right-click menu of a Dock icon ---
        if (ctxApp >= 0) {
            String label = Component.translatable("cutemod.os.dock.unpin").getString();
            int w = font.width(label) + 10, lx = Math.max(gx + 2, Math.min(gx + VIEW_W - w - 2, ctxX - w / 2)), ly = dockY - 14;
            boolean hov = mouseX >= lx && mouseX < lx + w && mouseY >= ly && mouseY < ly + 12;
            g.pose().pushPose();
            g.pose().translate(0, 0, 60);
            g.fill(lx - 1, ly - 1, lx + w + 1, ly + 13, 0x55FFFFFF);
            g.fill(lx, ly, lx + w, ly + 12, hov ? 0xFFB57BD6 : 0xF21B1422);
            g.drawString(font, label, lx + 5, ly + 2, 0xFFFFFFFF, false);
            g.pose().popPose();
        }

        // --- boot / password / welcome / screensaver cover the whole screen ---
        if (startup.active()) {
            menuOpen = false;
            g.pose().pushPose();
            g.pose().translate(0, 0, 400);      // above everything, including the Dock badges (they sit at z 50)
            startup.render(g, gx, menuY, VIEW_W, viewH, color.bodyColor, partial);
            g.pose().popPose();
        }

        // --- footer: record + hint (a long hint wraps to a second line instead of leaving the screen) ---
        Component rec = null;
        boolean spooky = false;
        if (app.showRecord()) {
            ComputerBlockEntity be = be();
            spooky = haunt.recordHaunted();
            rec = spooky
                    ? Component.translatable("cutemod.ui.record", 999999, Component.translatable("cutemod.haunt.holder"))
                    : (be == null || be.getHighScore() <= 0)
                    ? Component.translatable("cutemod.ui.record_none")
                    : Component.translatable("cutemod.ui.record", be.getHighScore(), be.getHolder());
        }
        int maxW = panelW - PAD * 2;
        var hintLines = new java.util.ArrayList<>(font.split(app.hint(), maxW));
        while (hintLines.size() > 2) hintLines.remove(hintLines.size() - 1);
        int hintW = 0;
        for (var l : hintLines) hintW = Math.max(hintW, font.width(l));
        boolean sameRow = rec != null && hintLines.size() <= 1 && font.width(rec) + 10 + hintW <= maxW;
        int rows = hintLines.size() + (rec != null && !sameRow ? 1 : 0);
        int fy = dockY + DOCK + Math.max(1, (FOOTER - rows * 9) / 2) + 1;
        if (rec != null) {
            g.drawString(font, rec, left + PAD, fy, spooky ? 0xFFD9302A : textCol, false);
            if (!sameRow) fy += 9;
        }
        for (var l : hintLines) {
            g.drawString(font, l, left + panelW - PAD - font.width(l), fy, textCol, false);
            fy += 9;
        }
    }

    // ---------- Start menu ----------
    private int smX() { return gx + 2; }

    private int smY() { return menuY + MENU; }

    private int smW() { return SM_COLS * SM_CW + SM_PAD * 2; }

    private int smBtnY() { return smY() + SM_PAD + SM_ROWS * SM_RH + 4; }

    private int smH() { return smBtnY() + SM_BTN_H + 4 + 10 + SM_PAD - smY(); }

    /** The app under the mouse in the Start menu, or -1. */
    private int smAppAt(int mx, int my) {
        int rx = mx - smX() - SM_PAD, ry = my - smY() - SM_PAD;
        if (rx < 0 || ry < 0 || rx >= SM_COLS * SM_CW || ry >= SM_ROWS * SM_RH) return -1;
        int k = rx / SM_CW * SM_ROWS + ry / SM_RH;
        return k < Desktop.ICONS ? k : -1;
    }

    private int smBtnW() { return (smW() - SM_PAD * 2 - 6) / 3; }

    /** The bottom button (0 Desktop, 1 Lock, 2 Quit) under the mouse, or -1. */
    private int smBtnAt(int mx, int my) {
        if (my < smBtnY() || my >= smBtnY() + SM_BTN_H) return -1;
        int rx = mx - smX() - SM_PAD;
        if (rx < 0) return -1;
        int b = rx / (smBtnW() + 3);
        return b < 3 && rx - b * (smBtnW() + 3) < smBtnW() ? b : -1;
    }

    private boolean inStart(int mx, int my) {
        return mx >= smX() && mx < smX() + smW() && my >= smY() && my < smY() + smH();
    }

    private void renderStart(GuiGraphics g, int mouseX, int mouseY) {
        int sx = smX(), sy = smY(), sw = smW(), sh = smH();
        g.pose().pushPose();
        g.pose().translate(0, 0, 70);
        g.fill(sx - 1, sy - 1, sx + sw + 1, sy + sh + 1, 0x55FFFFFF);
        g.fill(sx, sy, sx + sw, sy + sh, 0xF51B1422);
        for (int k = 0; k < Desktop.ICONS; k++) {
            int ex = sx + SM_PAD + k / SM_ROWS * SM_CW, ey = sy + SM_PAD + k % SM_ROWS * SM_RH;
            boolean hov = mouseX >= ex && mouseX < ex + SM_CW - 2 && mouseY >= ey && mouseY < ey + SM_RH - 1;
            if (hov) g.fill(ex, ey, ex + SM_CW - 2, ey + SM_RH - 1, 0xFFB57BD6);
            g.pose().pushPose();
            g.pose().translate(ex + 2, ey + 0.5f, 0);
            g.pose().scale(12 / 32f, 12 / 32f, 1f);
            Desktop.drawIcon(g, k, 0, 0, color.bodyColor);
            g.pose().popPose();
            g.drawString(font, font.plainSubstrByWidth(desktop.label(k), SM_CW - 34), ex + 17, ey + 2, 0xFFFFFFFF, false);
            int px = ex + SM_CW - 12, py = ey + 3;           // pin marker: filled = pinned to the Dock
            if (DockLayout.pinned(k)) g.fill(px, py, px + 5, py + 5, 0xFFFFE680);
            else {
                g.fill(px, py, px + 5, py + 1, 0x77FFFFFF); g.fill(px, py + 4, px + 5, py + 5, 0x77FFFFFF);
                g.fill(px, py + 1, px + 1, py + 4, 0x77FFFFFF); g.fill(px + 4, py + 1, px + 5, py + 4, 0x77FFFFFF);
            }
        }
        String[] names = {Component.translatable("cutemod.os.desktop").getString(),
                Component.translatable("cutemod.os.lock").getString(),
                Component.translatable("cutemod.os.quit").getString()};
        int by = smBtnY(), bw = smBtnW();
        for (int b = 0; b < 3; b++) {
            int bx = sx + SM_PAD + b * (bw + 3);
            boolean hov = mouseX >= bx && mouseX < bx + bw && mouseY >= by && mouseY < by + SM_BTN_H;
            g.fill(bx, by, bx + bw, by + SM_BTN_H, hov ? 0xFFB57BD6 : 0xFF3A2F5A);
            String n = font.plainSubstrByWidth(names[b], bw - 4);
            g.drawString(font, n, bx + (bw - font.width(n)) / 2, by + 3, 0xFFFFFFFF, false);
        }
        g.drawString(font, font.plainSubstrByWidth(Component.translatable("cutemod.os.start.hint").getString(), sw - 2 * SM_PAD),
                sx + SM_PAD, by + SM_BTN_H + 4, 0xFF9A90B8, false);
        g.pose().popPose();
    }

    private static void circle(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    private static int shadeUp(int argb) {
        int r = Math.min(255, ((argb >> 16) & 255) + 28), gr = Math.min(255, ((argb >> 8) & 255) + 28), b = Math.min(255, (argb & 255) + 28);
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }

    /** A tiny pixel heart, the "logo" of Cute OS. */
    private static void drawLogo(GuiGraphics g, int x, int y) {
        int c = 0xFFFFFFFF;
        g.fill(x + 1, y, x + 3, y + 1, c);
        g.fill(x + 4, y, x + 6, y + 1, c);
        g.fill(x, y + 1, x + 7, y + 3, c);
        g.fill(x + 1, y + 3, x + 6, y + 4, c);
        g.fill(x + 2, y + 4, x + 5, y + 5, c);
        g.fill(x + 3, y + 5, x + 4, y + 6, c);
    }

    private static int luminance(int rgb) {
        int r = (rgb >> 16) & 255, gr = (rgb >> 8) & 255, b = rgb & 255;
        return (int) (0.299 * r + 0.587 * gr + 0.114 * b);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        idle = 0;
        if (startup.active()) { startup.click(); return true; }
        int mx = (int) Math.floor(mouseX), my = (int) Math.floor(mouseY);

        Sfx.click();
        if (ctxApp >= 0) {                                      // the right-click menu of a Dock icon
            String label = Component.translatable("cutemod.os.dock.unpin").getString();
            int w = font.width(label) + 10, lx0 = Math.max(gx + 2, Math.min(gx + VIEW_W - w - 2, ctxX - w / 2)), ly0 = dockY - 14;
            boolean inside = mx >= lx0 && mx < lx0 + w && my >= ly0 && my < ly0 + 12;
            int which = ctxApp;
            ctxApp = -1;
            if (inside) { DockLayout.unpin(which); return true; }
        }
        boolean onLogo = mx >= gx + 2 && mx < gx + 16 && my >= menuY && my < menuY + MENU;
        if (menuOpen) {                                         // the Start menu eats the click
            int k = smAppAt(mx, my);
            if (k >= 0) {
                if (button == 1) { DockLayout.toggle(k); return true; }       // right-click: pin / unpin
                menuOpen = false;
                animX = gx + 8; animY = menuY + MENU;          // grows out of the Start button
                if (desktop.activeIndex(app) != k) desktop.launch(k);
                animX = Float.NaN;
                return true;
            }
            int b = smBtnAt(mx, my);
            if (b >= 0) {
                menuOpen = false;
                switch (b) {
                    case 0 -> home();
                    case 1 -> startup.lock();
                    default -> onClose();
                }
                return true;
            }
            if (inStart(mx, my)) return true;
            menuOpen = false;
            return true;                                        // a click on the logo closes it too
        }
        if (onLogo) {
            menuOpen = true;
            return true;
        }
        int icon = dock.hit(gx, dockY, VIEW_W, mx, my, app != desktop);
        if (icon >= 0) {
            if (button == 1) { ctxApp = icon; ctxX = mx; return true; }
            pressApp = icon; pressX = mx; pressY = my; dragging = false;   // it opens on release, unless dragged
            return true;
        }
        int lx = mx - gx, ly = my - gy;
        if (lx >= 0 && lx < VIEW_W && ly >= 0 && ly < App.H) {
            if (animT < 1f) return true;                       // not while the window is still growing
            if (!haunt.click(lx, ly, button)) app.click(lx, ly, button);
            return true;
        }
        if (app != desktop && lx >= 2 && lx < 36 && ly >= -TB && ly < 0) {       // traffic lights
            if (lx < 22) home();                                                  // red and yellow: back to the desktop
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (startup.active()) return true;
        if (pressApp >= 0 && button == 0) {
            if (!dragging && Math.abs((int) mouseX - pressX) + Math.abs((int) mouseY - pressY) > 4) dragging = true;
            return true;
        }
        int lx = (int) Math.floor(mouseX - gx), ly = (int) Math.floor(mouseY - gy);
        if (app.drag(lx, ly, button)) return true;
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (pressApp >= 0 && button == 0) {
            int which = pressApp, mx = (int) Math.floor(mouseX), my = (int) Math.floor(mouseY);
            boolean wasDragged = dragging;
            int slot = dock.slotAt(gx, VIEW_W, mx);
            pressApp = -1;
            dragging = false;
            dock.clearDrag();
            if (wasDragged) {
                if (my < dockY - 12) DockLayout.unpin(which);          // dropped out of the Dock
                else DockLayout.move(which, slot);
            } else if (desktop.activeIndex(app) != which) {
                animX = dock.centerX(which, gx, VIEW_W); animY = dockY;   // grows out of its Dock icon
                desktop.launch(which);
                animX = Float.NaN;
            }
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        idle = 0;
        if (startup.active()) return true;
        if (app.scroll(scrollY)) return true;
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        idle = 0;
        if (startup.key(keyCode)) return true;
        if (app.key(keyCode, modifiers)) return true;
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        idle = 0;
        if (startup.charTyped(codePoint)) return true;
        if (app.charTyped(codePoint)) return true;
        return super.charTyped(codePoint, modifiers);
    }
}
