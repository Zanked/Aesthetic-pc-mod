package dev.cutemod.net;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.cutemod.data.PlayerData;
import dev.cutemod.data.PostData;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Properties;
import java.util.UUID;

/**
 * Operator command (permission level 2) for the computers' coins:
 * <pre>
 * /cutecoins add  &lt;player&gt; &lt;amount&gt;
 * /cutecoins take &lt;player&gt; &lt;amount&gt;
 * /cutecoins set  &lt;player&gt; &lt;amount&gt;
 * /cutecoins get  &lt;player&gt;
 * </pre>
 * Coins live in the player's saved "progress" data. An online player gets a packet and the computer updates at once;
 * an offline player (one the server has seen before) has the saved data edited directly and sees it on the next login.
 */
public final class CoinsCommand {
    /** The most coins an operator can set (far below the int limit, so nothing overflows). */
    public static final int MAX = 100_000_000;

    private CoinsCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("cutecoins").requires(s -> s.hasPermission(2));
        root.then(change("add", 1)).then(change("take", -1)).then(change("set", 0));
        root.then(Commands.literal("get").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> {
            CommandSourceStack src = ctx.getSource();
            String name = StringArgumentType.getString(ctx, "player");
            UUID id = resolve(src.getServer(), name);
            if (id == null) return unknown(src, name);
            src.sendSuccess(() -> Component.translatable("cutemod.coins.cmd.get", name, savedCoins(src.getServer(), id)), false);
            return 1;
        })));
        d.register(root);
    }

    /** sign: +1 add, -1 take, 0 set. */
    private static LiteralArgumentBuilder<CommandSourceStack> change(String word, int sign) {
        return Commands.literal(word).then(Commands.argument("player", StringArgumentType.word())
                .then(Commands.argument("amount", IntegerArgumentType.integer(0, MAX)).executes(ctx -> {
                    CommandSourceStack src = ctx.getSource();
                    MinecraftServer server = src.getServer();
                    String name = StringArgumentType.getString(ctx, "player");
                    int amount = IntegerArgumentType.getInteger(ctx, "amount");
                    UUID id = resolve(server, name);
                    if (id == null) return unknown(src, name);
                    boolean set = sign == 0;
                    int delta = sign * amount;
                    ServerPlayer online = server.getPlayerList().getPlayer(id);
                    if (online != null) {
                        PacketDistributor.sendToPlayer(online, new AdminCoinsPayload(set, set ? amount : delta));
                    } else {
                        int now = savedCoins(server, id);
                        saveCoins(server, id, set ? amount : (int) Math.max(0, Math.min(MAX, (long) now + delta)));
                    }
                    src.sendSuccess(() -> Component.translatable("cutemod.coins.cmd." + word, name, amount), true);
                    return 1;
                })));
    }

    private static int unknown(CommandSourceStack src, String name) {
        src.sendFailure(Component.translatable("cutemod.post.cmd.unknown", name));
        return 0;
    }

    /** An online player by name, or a player the server has seen before. */
    private static UUID resolve(MinecraftServer server, String name) {
        ServerPlayer online = server.getPlayerList().getPlayerByName(name);
        if (online != null) return online.getUUID();
        return PostData.get(server).findByName(name);
    }

    private static Properties progress(MinecraftServer server, UUID id) {
        Properties p = new Properties();
        String text = PlayerData.get(server).copyOf(id).get("progress");
        if (text != null) {
            try { p.load(new StringReader(text)); } catch (Exception ignored) { }
        }
        return p;
    }

    private static int savedCoins(MinecraftServer server, UUID id) {
        try { return Integer.parseInt(progress(server, id).getProperty("coins", "0").trim()); } catch (Exception e) { return 0; }
    }

    private static void saveCoins(MinecraftServer server, UUID id, int coins) {
        Properties p = progress(server, id);
        p.setProperty("coins", Integer.toString(coins));
        try {
            StringWriter w = new StringWriter();
            p.store(w, null);
            StringBuilder sb = new StringBuilder();
            for (String line : w.toString().split("\\R")) if (!line.startsWith("#")) sb.append(line).append('\n');
            PlayerData.get(server).put(id, "progress", sb.toString());
        } catch (Exception ignored) { }
    }
}
