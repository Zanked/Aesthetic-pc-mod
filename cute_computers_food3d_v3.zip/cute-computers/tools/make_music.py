#!/usr/bin/env python3
"""
Generates the game music of Cute Computers: one short seamless loop (~25-32 s) per game.
Everything is synthesized here (no samples, no copyrighted material), so every melody is original.

    python3 tools/make_music.py            # all games
    python3 tools/make_music.py horror maze  # only some games

Needs numpy + scipy + ffmpeg (with libvorbis). Output: src/main/resources/assets/cutemod/sounds/music/<id>.ogg
and sounds.json. Tweak a game in the GAMES table at the bottom and run again.

How the loops are seamless: the whole pattern is rendered three times in a row, the effects (reverb, filters)
run over all three copies and only the middle copy is kept. Textures (wind, water...) are built periodic.
"""
import json
import math
import os
import subprocess
import sys
import tempfile
import wave
import zlib

import numpy as np
from scipy.signal import butter, fftconvolve, sosfilt

SR = 32000
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "src/main/resources/assets/cutemod")
OUT = os.path.join(ASSETS, "sounds/music")

SCALES = {
    "major": [0, 2, 4, 5, 7, 9, 11], "minor": [0, 2, 3, 5, 7, 8, 10], "dorian": [0, 2, 3, 5, 7, 9, 10],
    "lydian": [0, 2, 4, 6, 7, 9, 11], "penta": [0, 2, 4, 7, 9], "phrygian": [0, 1, 3, 5, 7, 8, 10],
    "insen": [0, 1, 5, 7, 10], "dim": [0, 2, 3, 5, 6, 8, 9, 11],
}


# ----------------------------------------------------------------------------- helpers
def hz(m): return 440.0 * 2 ** ((m - 69) / 12.0)


def T(n): return np.arange(n) / SR


def _fc(fc): return min(fc, SR * 0.45) / (SR / 2)


def lp(x, fc, order=2): return sosfilt(butter(order, _fc(fc), output="sos"), x)


def hp(x, fc, order=2): return sosfilt(butter(order, _fc(fc), btype="high", output="sos"), x)


def bp(x, lo, hi): return sosfilt(butter(2, [_fc(lo), _fc(hi)], btype="band", output="sos"), x)


def norm(x):
    m = np.max(np.abs(x))
    return x / m if m > 0 else x


def gate(x, dur, rel=0.05):
    t = T(len(x))
    return x * np.clip(1 - (t - dur) / rel, 0, 1)


def sustain_env(t, dur, att, rel):
    return np.minimum(1, t / att) * np.where(t < dur, 1.0, np.clip(1 - (t - dur) / rel, 0, 1))


# ----------------------------------------------------------------------------- instruments (peak = 1)
def i_pluck(f, bright=1.0, drop=0.0):
    n = int(SR * 2.2); t = T(n)
    ph = 2 * np.pi * np.cumsum(f * (1 + drop * np.exp(-t * 25))) / SR
    s = np.zeros(n)
    for k in range(1, 9):
        if f * k > SR * 0.45: break
        s += np.sin(k * ph) / k ** 1.1 * np.exp(-t * (1.4 + k * 1.1 / bright))
    return norm(s * np.minimum(1, t / 0.002))


def i_marimba(f):
    n = int(SR * 1.1); t = T(n)
    s = np.sin(2 * np.pi * f * t) * np.exp(-t * 5)
    if f * 4 < SR * .45: s += 0.5 * np.sin(2 * np.pi * f * 4 * t) * np.exp(-t * 14)
    if f * 10 < SR * .45: s += 0.15 * np.sin(2 * np.pi * f * 10 * t) * np.exp(-t * 32)
    return norm(s * np.minimum(1, t / 0.002))


def i_bell(f):
    n = int(SR * 3.4); t = T(n); s = np.zeros(n)
    for r, a, d in ((1, 1, 1.3), (2.76, .55, 1.9), (5.4, .3, 2.8), (8.93, .15, 4.0)):
        if f * r < SR * .45: s += a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * d)
    return norm(s * np.minimum(1, t / 0.002))


def i_box(f):
    n = int(SR * 1.8); t = T(n); s = np.zeros(n)
    for r, a, d in ((1, 1, 2.6), (2.4, .4, 5.0), (4.1, .25, 9.0)):
        if f * r < SR * .45: s += a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * d)
    return norm(s * np.minimum(1, t / 0.001))


def i_ep(f):
    n = int(SR * 2.8); t = T(n)
    idx = 1.5 * np.exp(-t * 5) + 0.15
    s = np.sin(2 * np.pi * f * t + idx * np.sin(2 * np.pi * f * t)) * np.exp(-t * 1.5)
    if f * 7 < SR * .45: s += 0.12 * np.sin(2 * np.pi * f * 7 * t) * np.exp(-t * 14)
    return norm(s * np.minimum(1, t / 0.003))


def i_piano(f):
    n = int(SR * 4.5); t = T(n); s = np.zeros(n)
    base = 1.0 + f / 260.0
    for k in range(1, 13):
        fk = f * k * math.sqrt(1 + 0.0003 * k * k)
        if fk > SR * .45: break
        a = 1.0 / k ** 1.25
        d = base * (0.8 + 0.5 * k)
        s += a * 0.5 * (np.sin(2 * np.pi * fk * t) + np.sin(2 * np.pi * fk * 1.0013 * t + 1.0)) * np.exp(-t * d)
    return norm(lp(s * np.minimum(1, t / 0.004), 5500))


def i_chip(f, dur, duty=0.25):
    n = int((dur + 0.06) * SR); t = T(n)
    s = np.where(((f * t) % 1) < duty, 1.0, -1.0)
    env = np.minimum(1, t / 0.002) * np.exp(-t * 3.0) * np.clip(np.where(t < dur, 1, 1 - (t - dur) / 0.05), 0, 1)
    return norm(lp(s, 5000) * env)


def i_saw(f, dur, decay=4.5, cut=2600):
    n = int((dur + 0.3) * SR); t = T(n)
    s = ((2 * ((f * t) % 1) - 1) + (2 * ((f * 1.006 * t) % 1) - 1) + (2 * ((f * 0.994 * t) % 1) - 1)) / 3
    env = np.minimum(1, t / 0.003) * np.exp(-t * decay) * np.clip(np.where(t < dur, 1, 1 - (t - dur) / 0.08), 0, 1)
    return norm(lp(s, cut) * env)


def i_bass(f, dur):
    n = int((dur + 0.2) * SR); t = T(n)
    s = np.sin(2 * np.pi * f * t) + 0.35 * np.sin(4 * np.pi * f * t) + 0.12 * np.sin(6 * np.pi * f * t)
    env = np.minimum(1, t / 0.004) * np.exp(-t * 1.6) * np.clip(np.where(t < dur, 1, 1 - (t - dur) / 0.12), 0, 1)
    return norm(s * env)


def i_sub(f, dur):
    n = int((dur + 0.4) * SR); t = T(n)
    s = np.sin(2 * np.pi * f * t) + 0.18 * np.sin(4 * np.pi * f * t)
    return norm(s * sustain_env(t, dur, 0.05, 0.35))


def i_pad(f, dur, att=0.7, rel=1.4, cutoff=1400, wave="saw", voices=3):
    n = int((dur + rel) * SR); t = T(n); s = np.zeros(n)
    for dt in np.linspace(-1, 1, voices) * 0.005:
        ff = f * (1 + dt)
        if wave == "saw":
            s += 2 * ((ff * t) % 1) - 1
        else:
            s += np.sin(2 * np.pi * ff * t) + 0.3 * np.sin(4 * np.pi * ff * t) + 0.1 * np.sin(6 * np.pi * ff * t)
    s /= voices
    return norm(lp(s, cutoff) * sustain_env(t, dur, att, rel))


NATURAL = {"pluck", "koto", "marimba", "bell", "box", "ep", "piano"}
INST = {
    "pluck": lambda f, d: i_pluck(f), "koto": lambda f, d: i_pluck(f, 1.3, 0.012),
    "marimba": lambda f, d: i_marimba(f), "bell": lambda f, d: i_bell(f), "box": lambda f, d: i_box(f),
    "ep": lambda f, d: i_ep(f), "piano": lambda f, d: i_piano(f),
    "chip": i_chip, "saw": i_saw, "stab": lambda f, d: i_saw(f, d, 7.0, 1800),
    "bass": i_bass, "sub": i_sub,
}
_cache = {}


def note(inst, m, dur, stac=None, **kw):
    d = dur * stac if stac else dur
    key = (inst, m, round(d, 3), tuple(sorted(kw.items())))
    if key not in _cache:
        f = hz(m)
        sig = i_pad(f, d, **kw) if inst == "pad" else INST[inst](f, d)
        if stac and inst in NATURAL: sig = gate(sig, d, 0.05)
        _cache[key] = sig
    return _cache[key]


# ----------------------------------------------------------------------------- percussion
def _noise(n, seed): return np.random.default_rng(seed).standard_normal(n)


def make_drums():
    D = {}
    n = int(SR * .45); t = T(n)
    D["kick"] = norm(np.sin(2 * np.pi * np.cumsum(45 + 95 * np.exp(-t * 28)) / SR) * np.exp(-t * 9))
    n = int(SR * .3); t = T(n)
    D["snare"] = norm(bp(_noise(n, 1), 1200, 7000) * np.exp(-t * 22) + 0.5 * np.sin(2 * np.pi * 185 * t) * np.exp(-t * 28))
    n = int(SR * .12); t = T(n)
    D["hat"] = norm(hp(_noise(n, 2), 6500) * np.exp(-t * 50))
    n = int(SR * .35); t = T(n)
    D["ohat"] = norm(hp(_noise(n, 3), 6000) * np.exp(-t * 12))
    n = int(SR * .06); t = T(n)
    D["rim"] = norm(np.sin(2 * np.pi * 1700 * t) * np.exp(-t * 90) + 0.3 * bp(_noise(n, 4), 1500, 5000) * np.exp(-t * 80))
    n = int(SR * .65); t = T(n)
    lub = np.sin(2 * np.pi * np.cumsum(38 + 45 * np.exp(-t * 22)) / SR) * np.exp(-t * 17)
    t2 = np.clip(t - 0.27, 0, None)
    dub = np.sin(2 * np.pi * np.cumsum(36 + 34 * np.exp(-t2 * 22)) / SR) * np.exp(-t2 * 19) * (t >= 0.27)
    D["heart"] = norm(lub + 0.65 * dub)
    n = int(SR * .07); t = T(n)
    D["tick_hi"] = norm(bp(_noise(n, 5), 1800, 4500) * np.exp(-t * 160) + 0.5 * np.sin(2 * np.pi * 1100 * t) * np.exp(-t * 180))
    D["tick_lo"] = norm(bp(_noise(n, 6), 1200, 3500) * np.exp(-t * 160) + 0.5 * np.sin(2 * np.pi * 780 * t) * np.exp(-t * 180))
    n = int(SR * .14); t = T(n)
    D["gear"] = norm(np.sin(2 * np.pi * 140 * t) * np.exp(-t * 40) + 0.8 * bp(_noise(n, 7), 600, 2500) * np.exp(-t * 60))
    return D


DRUMS = make_drums()
PERC_KEYS = (("kick", "gk", .4, 0.0), ("snare", "gs", .25, 0.05), ("hat", "gh", .1, .25), ("ohat", "go", .08, .25),
             ("rim", "gr", .2, -.2), ("heart", "gH", .5, 0.0), ("tick", "gt", .15, .1), ("gear", "gg", .3, -.1))


# ----------------------------------------------------------------------------- textures (periodic: loop-safe)
def add_wrap(arr, sig, pos, gain=1.0):
    idx = (pos + np.arange(len(sig))) % arr.shape[-1]
    np.add.at(arr, idx, sig * gain)


def circ(N, fn, x):
    return fn(np.tile(x, 3))[N:2 * N]


def bed_wind(N, rng, lo=200, hi=1400, depth=0.6, **_):
    out = []
    sec = N / SR; t = T(N)
    for _c in range(2):
        y = circ(N, lambda z: bp(z, lo, hi), rng.standard_normal(N))
        lfo = np.ones(N)
        for k, a in ((1, .5), (2, .3), (3, .2)):
            lfo += depth * a * np.sin(2 * np.pi * k * t / sec + rng.uniform(0, 6.28))
        out.append(norm(y * np.clip(lfo, 0.05, None)))
    return np.array(out)


def bed_water(N, rng, rate=1.2, **_):
    sec = N / SR
    out = np.zeros((2, N))
    for c in range(2):
        out[c] += 0.25 * norm(circ(N, lambda z: lp(z, 260), rng.standard_normal(N)))
    for _i in range(int(sec * rate)):
        L = int(.1 * SR); t = T(L)
        f0 = rng.uniform(700, 1800)
        sig = np.sin(2 * np.pi * np.cumsum(f0 * (1 + 1.3 * t / .1)) / SR) * np.exp(-t * 42)
        pan = rng.uniform(0, 1); pos = int(rng.integers(0, N)); g = rng.uniform(.3, 1)
        add_wrap(out[0], sig, pos, g * (1 - pan)); add_wrap(out[1], sig, pos, g * pan)
    return out


def bed_crackle(N, rng, rate=14, **_):
    out = np.zeros((2, N))
    for c in range(2):
        for _i in range(int(N / SR * rate)):
            out[c, int(rng.integers(0, N))] += rng.exponential(1.0) * rng.choice([-1, 1])
        out[c] = circ(N, lambda z: hp(z, 1800), out[c])
    return norm(out)


def bed_hum(N, rng, f=55.0, **_):
    sec = N / SR; t = T(N)
    q = lambda x: round(x * sec) / sec
    out = []
    for _c in range(2):
        s = np.zeros(N)
        for mult, a in ((1, 1), (1.003, .8), (1.5, .35), (2.004, .25), (3.01, .1)):
            s += a * np.sin(2 * np.pi * q(f * mult) * t + rng.uniform(0, 6.28))
        s *= 0.7 + 0.3 * np.sin(2 * np.pi * 2 * t / sec + rng.uniform(0, 6.28))
        out.append(norm(s))
    return np.array(out)


def _swells(N, rng, count, lenr, f0r, glide, band, trem, saw=True):
    out = np.zeros((2, N))
    for _i in range(count):
        L = int(rng.uniform(*lenr) * SR); t = T(L)
        f0 = rng.uniform(*f0r)
        f = f0 * (1 + glide * rng.uniform(-1, 1) * t / (L / SR)) * (1 + 0.01 * np.sin(2 * np.pi * 5 * t))
        ph = np.cumsum(f) / SR
        s = (2 * (ph % 1) - 1) if saw else np.sin(2 * np.pi * ph)
        s = bp(s, *band)
        env = np.sin(np.pi * t / (L / SR)) ** 2 * (1 + trem * np.sin(2 * np.pi * rng.uniform(5, 8) * t)) / (1 + trem)
        s = norm(s) * env
        pan = rng.uniform(0, 1); pos = int(rng.integers(0, N)); g = rng.uniform(.5, 1)
        add_wrap(out[0], s, pos, g * (1 - pan)); add_wrap(out[1], s, pos, g * pan)
    return out


def bed_creak(N, rng, count=None, **_):
    return norm(_swells(N, rng, count or max(2, int(N / SR / 7)), (1.2, 2.6), (70, 190), .3, (320, 1100), .0, True))


def bed_buzz(N, rng, count=None, **_):
    return norm(_swells(N, rng, count or max(3, int(N / SR / 4)), (1.2, 2.6), (170, 230), .06, (250, 1300), .35, True))


def bed_static(N, rng, count=None, **_):
    out = np.zeros((2, N))
    for _i in range(count or max(3, int(N / SR / 3))):
        L = int(rng.uniform(.02, .12) * SR)
        s = hp(rng.standard_normal(L), 2500) * np.hanning(L)
        add_wrap(out[int(rng.integers(0, 2))], s, int(rng.integers(0, N)), rng.uniform(.3, 1))
    return norm(out)


BEDS = {"wind": bed_wind, "water": bed_water, "crackle": bed_crackle, "hum": bed_hum, "creak": bed_creak,
        "buzz": bed_buzz, "static": bed_static}


def reverb(buf, rt60, damp, seed=7):
    r = np.random.default_rng(seed)
    L = int(rt60 * SR); t = T(L); out = np.zeros_like(buf)
    for c in range(2):
        ir = lp(r.standard_normal(L) * np.exp(-t * 6.9 / rt60), damp)
        k = int(0.012 * SR); ir[:k] *= np.linspace(0, 1, k)
        ir /= math.sqrt(np.sum(ir ** 2))
        out[c] = fftconvolve(buf[c], ir)[:buf.shape[1]]
    return out


# ----------------------------------------------------------------------------- composing
def render(name, spec):
    rng = np.random.default_rng(zlib.crc32(name.encode()))
    bpm = spec["bpm"]
    bars = max(4, 4 * round(28 * bpm / 960))
    N = int(round(bars * 4 * 60 / bpm * SR)); bl = N / (bars * 4); beat_s = 60.0 / bpm
    scale = SCALES[spec["scale"]]; ns = len(scale); root = spec["root"]; prog = spec["prog"]
    swing = spec.get("swing", 0.5)
    buf = np.zeros((2, 3 * N))

    def D(d, o=0): return root + scale[d % ns] + 12 * (d // ns) + 12 * o

    def ext(bar, seventh=False):
        r = prog[bar % len(prog)]
        return [r, r + 2, r + 4, r + 6, r + ns, r + ns + 2, r + ns + 4] if seventh else [r, r + 2, r + 4, r + ns, r + ns + 2, r + ns + 4]

    def pos(bar, beat):
        if abs((beat % 1) - 0.5) < 1e-9: beat += swing - 0.5
        return int(round((bar * 4 + beat) * bl))

    def place(sig, bar, beat, g, pan=0.0):
        a = math.cos((pan + 1) * math.pi / 4); b = math.sin((pan + 1) * math.pi / 4)
        s0 = pos(bar, beat)
        for k in range(3):
            s = s0 + k * N
            if s >= buf.shape[1]: continue
            e = min(buf.shape[1], s + len(sig)); seg = sig[:e - s] * g
            buf[0, s:e] += seg * a; buf[1, s:e] += seg * b

    def fixlow(m):
        while m < 34: m += 12
        return m

    # ---- layers
    def L_pad(p):
        every = p.get("every", 1); seventh = p.get("seventh", False)
        kw = dict(att=p.get("att", .7), rel=p.get("rel", 1.4), cutoff=p.get("cutoff", 1400), wave=p.get("wave", "saw"),
                  voices=p.get("voices", 3))
        for bar in range(0, bars, every):
            r = prog[bar % len(prog)]
            degs = [r, r + 2, r + 4] + ([r + 6] if seventh else [])
            dur = every * 4 * beat_s
            g = p.get("g", .2) / math.sqrt(len(degs))
            for i, d in enumerate(degs):
                place(note("pad", D(d, p.get("oct", 0)), dur, **kw), bar, 0, g, (-.3, .3, 0, .15)[i % 4])

    def L_bass(p):
        for bar in range(bars):
            e = ext(bar, p.get("seventh", False))
            for beat, idx, ln in p["pat"]:
                place(note(p.get("inst", "bass"), fixlow(D(e[idx], p.get("oct", -2))), ln * beat_s, p.get("stac")), bar, beat, p.get("g", .5), 0)

    def L_arp(p):
        rate = p["rate"]; pat = p["pat"]; seventh = p.get("seventh", False)
        for bar in range(bars):
            e = ext(bar, seventh)
            for st in range(4 * rate):
                idx = pat[st % len(pat)]
                if idx is None: continue
                acc = 1.25 if st % rate == 0 else 1.0
                place(note(p["inst"], D(e[idx], p.get("oct", 0)), beat_s / rate * p.get("len", 1.0), p.get("stac")), bar, st / rate, p.get("g", .25) * acc / 1.25, p.get("pan", 0))

    def L_chords(p):
        seventh = p.get("seventh", False); notes = p["notes"]
        for bar in range(bars):
            e = ext(bar, seventh)
            for beat, ln in p["beats"]:
                for i in notes:
                    place(note(p["inst"], D(e[i], p.get("oct", 0)), ln * beat_s, p.get("stac")), bar, beat, p.get("g", .2) / math.sqrt(len(notes)), (-.2, .2, 0, .1)[i % 4])

    def L_mel(p):
        spb = p.get("spb", 2); dens = p.get("dens", .4); lens = p.get("lens", [1, 1, 2, 2, 3, 4])
        lo = p.get("lo", 0); hi = p.get("hi", ns + 3); seventh = p.get("seventh", False)

        def gen_rhy():
            grid = 8 * spb; out = []; i = 0
            while i < grid:
                if rng.random() < (min(1.0, dens * 1.6) if i % spb == 0 else dens):
                    L = min(int(rng.choice(lens)), grid - i)
                    out.append((i / spb, L / spb)); i += L
                else:
                    i += 1
            return out or [(0.0, 2.0)]

        rhyA = gen_rhy(); rhyB = rhyA if rng.random() < .5 else gen_rhy()

        def walk(rhy, bar0, resolve):
            d = prog[bar0 % len(prog)] + 2 + int(rng.integers(0, 3)); out = []
            for i, (b, L) in enumerate(rhy):
                r = prog[(bar0 + int(b // 4)) % len(prog)]
                d = min(max(d + int(rng.choice([-2, -1, -1, 0, 1, 1, 2, 3, -3])), lo), hi)
                last = resolve and i == len(rhy) - 1
                if b % 2 == 0 or last:
                    tones = (0,) if last else (0, 2, 4)
                    cands = [x for x in range(lo, hi + 1) if (x - r) % ns in tones] or [d]
                    d = min(cands, key=lambda x: abs(x - d))
                out.append((b, L, d))
            return out

        plen = max(4, len(prog)); cache = {}
        for bar0 in range(0, bars, 2):
            which = "A" if (bar0 // 2) % 2 == 0 else "B"
            variant = (bar0 // plen) % 2 if which == "B" else 0
            key = (which, bar0 % plen, variant)
            if key not in cache:
                cache[key] = walk(rhyA if which == "A" else rhyB, bar0, which == "B")
            for b, L, d in cache[key]:
                bar = bar0 + int(b // 4)
                if bar >= bars: continue
                place(note(p["inst"], D(d, p.get("oct", 1)), L * beat_s, p.get("stac")), bar, b % 4, p.get("g", .35), p.get("pan", 0))

    def L_perc(p):
        for bar in range(bars):
            for key, gk, gdef, pan in PERC_KEYS:
                for b in p.get(key, []):
                    name_ = key
                    if key == "tick": name_ = "tick_hi" if int(b) % 2 == 0 else "tick_lo"
                    v = 1.0 if (b % 1) == 0 else 0.7
                    place(DRUMS[name_], bar, b, p.get(gk, gdef) * v, pan)

    def L_bed(p):
        kw = {k: v for k, v in p.items() if k not in ("kind", "g")}
        if p["kind"] == "hum" and "f" not in kw: kw["f"] = hz(root - 24)
        bed = BEDS[p["kind"]](N, rng, **kw) * p.get("g", .1)
        buf[:] += np.tile(bed, 3)

    layers = {"pad": L_pad, "bass": L_bass, "arp": L_arp, "chords": L_chords, "mel": L_mel, "perc": L_perc, "bed": L_bed}
    for kind, p in spec["layers"]:
        layers[kind](p)

    # ---- master: reverb, tone, cut the middle copy, loudness
    rt, mix, damp = spec.get("rev", (1.6, .3, 4500))
    buf = buf + reverb(buf, rt, damp) * mix
    for c in range(2):
        buf[c] = lp(hp(buf[c], 28), spec.get("tone", 12000))
    out = buf[:, N:2 * N]
    out = out * (0.10 / max(1e-9, math.sqrt(np.mean(out ** 2))))
    out = np.tanh(out * 1.25) / 1.25
    return out, N


def save_ogg(name, out):
    pcm = (np.clip(out, -1, 1).T * 32767).astype("<i2")
    os.makedirs(OUT, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, name + ".wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "1",
                        os.path.join(OUT, name + ".ogg")], check=True)


# ----------------------------------------------------------------------------- the games
def perc(**k): return ("perc", k)
def pad(**k): return ("pad", k)
def bass(**k): return ("bass", k)
def arp(**k): return ("arp", k)
def mel(**k): return ("mel", k)
def chords(**k): return ("chords", k)
def bed(kind, **k): return ("bed", dict(kind=kind, **k))


EIGHTHS = [(i / 2, 0, .45) for i in range(8)]
H8 = [.5, 1.5, 2.5, 3.5]

GAMES = {
    # ---- the 8 computer games
    "pink": dict(bpm=118, root=60, scale="major", prog=[0, 4, 5, 3], rev=(1.2, .25, 5000), tone=9000, layers=[        # Flappy Cat: bouncy and sweet
        pad(oct=-1, g=.2, cutoff=1800, wave="soft", att=.4, rel=.8),
        bass(pat=[(0, 0, 1.4), (1.5, 0, .4), (2, 2, 1.4), (3.5, 1, .4)], g=.5),
        arp(inst="marimba", rate=2, pat=[0, 1, 2, 1, 0, 1, 2, 3], g=.3, pan=-.25),
        mel(inst="box", oct=1, dens=.5, g=.38, pan=.2),
        perc(kick=[0, 2], rim=[1, 3], hat=H8, gk=.4, gr=.22, gh=.09)]),
    "green": dict(bpm=92, root=57, scale="minor", prog=[0, 5, 0, 4], rev=(2.2, .35, 3000), tone=6000, layers=[         # Minesweeper: tense
        pad(oct=-1, g=.25, cutoff=700, wave="soft", att=1.2, rel=1.5, every=2),
        bass(inst="sub", pat=[(0, 0, 3.8)], g=.45),
        perc(tick=[0, 1, 2, 3], gt=.2),
        mel(inst="bell", oct=1, dens=.1, lens=[2, 3, 4], lo=2, hi=9, g=.3, pan=.3),
        bed("hum", g=.2)]),
    "white": dict(bpm=88, root=62, scale="penta", prog=[0, 3, 1, 4], rev=(1.8, .3, 5000), layers=[                      # Panda Snake: bamboo chill
        pad(oct=-1, g=.2, wave="soft", cutoff=1500),
        arp(inst="marimba", rate=2, pat=[0, 2, 1, 2, 3, 2, 1, 2], g=.33, pan=-.2),
        mel(inst="marimba", oct=1, dens=.35, g=.34, pan=.25),
        bass(pat=[(0, 0, 1.8), (2.5, 2, 1.2)], g=.45),
        perc(kick=[0], rim=[2], gk=.3, gr=.18),
        bed("wind", g=.1, lo=300, hi=1500)]),
    "blue": dict(bpm=68, root=65, scale="lydian", prog=[0, 1, 0, 4], rev=(3.0, .45, 4500), layers=[                     # Penguin Fishing: calm water
        pad(oct=-1, g=.28, wave="soft", cutoff=2200, att=1.5, rel=2.0),
        arp(inst="ep", rate=1, pat=[0, 2, 4, 2], g=.25, pan=-.2),
        mel(inst="bell", oct=1, dens=.16, lens=[2, 3, 4], g=.3, pan=.25),
        bass(inst="sub", pat=[(0, 0, 3.8)], g=.35),
        bed("water", g=.22), bed("wind", g=.08, lo=150, hi=900)]),
    "orange": dict(bpm=108, root=62, scale="dorian", prog=[0, 3, 0, 4], rev=(1.0, .2, 5000), layers=[                   # Fox Memory: sneaky pizzicato
        bass(pat=[(0, 0, .5), (1, 0, .5), (2, 2, .5), (3, 1, .5)], g=.5),
        arp(inst="pluck", rate=2, pat=[0, 2, 1, 2, 0, 2, 3, 2], stac=.4, g=.32, pan=-.3),
        mel(inst="marimba", oct=1, dens=.5, lens=[1, 1, 1, 2], stac=.5, g=.36, pan=.3),
        pad(oct=-1, g=.1, wave="soft"),
        perc(kick=[0, 2.5], rim=[1, 3], hat=H8, gk=.35, gr=.2, gh=.07)]),
    "purple": dict(bpm=108, root=52, scale="minor", prog=[0, 5, 2, 6], rev=(2.6, .35, 3500), tone=7000, layers=[        # Ender Dodge: dark synthwave
        pad(oct=0, g=.22, cutoff=900, att=1.0, rel=1.5, voices=4),
        arp(inst="saw", rate=4, pat=[0, 2, 1, 3, 2, 4, 3, 1], stac=.6, g=.22, pan=-.3),
        bass(oct=-1, pat=EIGHTHS, g=.5),
        perc(kick=[0, 1, 2, 3], snare=[1, 3], hat=H8, gk=.4, gs=.14, gh=.07),
        mel(inst="bell", oct=1, dens=.18, lens=[2, 3, 4], g=.3, pan=.3),
        bed("hum", g=.12), bed("static", g=.04)]),
    "yellow": dict(bpm=140, root=67, scale="major", prog=[0, 3, 4, 0], rev=(.9, .18, 6000), layers=[                    # Whack-a-Bee: fast and buzzy
        bass(pat=[(0, 0, .9), (1, 2, .9), (2, 0, .9), (3, 2, .9)], g=.5),
        arp(inst="chip", rate=4, pat=[0, 2, 4, 2, 0, 2, 4, 5], stac=.6, g=.16, pan=-.3),
        mel(inst="chip", oct=1, dens=.55, lens=[1, 1, 2, 2], g=.2, pan=.3),
        perc(kick=[0, 2], snare=[1, 3], hat=H8, gk=.4, gs=.2, gh=.08),
        bed("buzz", g=.1)]),
    "red": dict(bpm=100, root=64, scale="penta", prog=[0, 3, 1, 4], rev=(2.0, .35, 6000), layers=[                      # Ladybug Match: sparkly
        arp(inst="bell", rate=2, pat=[0, 2, 4, 2, 1, 3, 5, 3], g=.2, pan=-.3),
        mel(inst="box", oct=1, dens=.35, g=.34, pan=.3),
        pad(oct=-1, g=.2, wave="soft"),
        bass(pat=[(0, 0, 1.6), (2, 0, 1.6)], g=.42),
        perc(rim=[1, 3], kick=[0], gk=.25, gr=.15)]),
    # ---- the other games
    "breakout": dict(bpm=126, root=60, scale="major", prog=[0, 5, 3, 4], rev=(.9, .15, 6500), layers=[                  # Cookie Breaker: upbeat
        bass(pat=EIGHTHS, g=.5),
        arp(inst="chip", rate=2, pat=[0, 1, 2, 1], g=.16, pan=-.3),
        mel(inst="marimba", oct=1, dens=.5, g=.4, pan=.25),
        pad(oct=-1, g=.1, wave="soft"),
        perc(kick=[0, 1, 2, 3], snare=[1, 3], hat=H8, gk=.35, gs=.18, gh=.07)]),
    "cubes": dict(bpm=64, root=62, scale="major", prog=[0, 4, 5, 3], rev=(3.2, .45, 4500), layers=[                      # Merge Cubes: zen
        pad(oct=-1, g=.3, wave="soft", cutoff=2000, att=1.8, rel=2.2),
        mel(inst="bell", oct=1, dens=.2, lens=[2, 3, 4, 4], g=.32, pan=.2),
        arp(inst="ep", rate=1, pat=[0, 2, 1, 3], g=.22, pan=-.25),
        bass(inst="sub", pat=[(0, 0, 3.8)], g=.4),
        bed("wind", g=.04)]),
    "pong": dict(bpm=118, root=55, scale="minor", prog=[0, 0, 5, 4], rev=(1.0, .2, 5000), tone=8000, layers=[           # Slime Pong: minimal electro
        bass(oct=-1, pat=[(0, 0, .4), (.75, 0, .3), (1.5, 0, .4), (2, 0, .4), (2.75, 0, .3), (3.5, 2, .4)], g=.5),
        arp(inst="chip", rate=2, pat=[0, None, 2, None, 1, None, 3, None], stac=.4, g=.15, pan=-.3),
        mel(inst="bell", oct=1, dens=.2, g=.3, pan=.3),
        pad(oct=0, g=.1, cutoff=900),
        perc(kick=[0, 1, 2, 3], hat=H8, snare=[3], gk=.4, gs=.12, gh=.07)]),
    "bees": dict(bpm=138, root=50, scale="minor", prog=[0, 5, 2, 6], rev=(1.1, .18, 5000), layers=[                     # Bee Invaders: arcade synthwave
        bass(oct=-1, pat=EIGHTHS, g=.5),
        arp(inst="saw", rate=4, pat=[0, 2, 4, 2, 0, 2, 5, 2], stac=.5, g=.2, pan=-.3),
        mel(inst="chip", oct=1, dens=.4, g=.2, pan=.3),
        pad(oct=0, g=.16, cutoff=1100, voices=4),
        perc(kick=[0, 1, 2, 3], snare=[1, 3], hat=H8, gk=.4, gs=.2, gh=.07),
        bed("buzz", g=.07)]),
    "horror": dict(bpm=60, root=45, scale="phrygian", prog=[0, 0, 1, 0], rev=(3.8, .5, 2500), tone=5000, layers=[       # Something in the Dark
        pad(oct=0, g=.3, cutoff=420, att=2.5, rel=2.5, voices=4, every=2),
        bass(inst="sub", oct=-1, pat=[(0, 0, 3.8)], g=.45),
        mel(inst="bell", oct=1, dens=.07, lens=[3, 4], lo=7, hi=15, g=.28, pan=-.2),
        perc(heart=[0, 2], gH=.5),
        bed("creak", g=.35), bed("wind", g=.15, lo=100, hi=700), bed("crackle", g=.05, rate=3)]),
    "maze": dict(bpm=72, root=43, scale="dim", prog=[0, 0, 3, 0], rev=(2.8, .4, 2800), tone=5500, layers=[              # Dark Corridor
        pad(oct=0, g=.28, cutoff=380, att=2.0, rel=2.0, voices=4, every=2),
        bass(inst="sub", oct=-1, pat=[(0, 0, 3.8)], g=.4),
        perc(tick=[0, 1, 2, 3], gt=.12, heart=[0, 1, 2, 3], gH=.35),
        mel(inst="bell", oct=1, dens=.08, lens=[3, 4], lo=8, hi=17, g=.25, pan=.2),
        bed("hum", g=.2, f=hz(31)), bed("wind", g=.12, lo=120, hi=800), bed("static", g=.05)]),
    "craft": dict(bpm=66, root=60, scale="major", prog=[0, 3, 0, 4], rev=(2.8, .4, 5000), layers=[                      # Mini Craft: calm piano
        mel(inst="piano", oct=0, dens=.3, lens=[2, 3, 4, 4], hi=11, g=.5, pan=.1),
        arp(inst="piano", rate=1, pat=[0, 2, 1, 3], oct=-1, g=.28, pan=-.2),
        pad(oct=-1, g=.14, wave="soft", cutoff=1200, att=2.0, rel=2.0),
        bed("wind", g=.04)]),
    "zombies": dict(bpm=126, root=46, scale="phrygian", prog=[0, 1, 0, 6], rev=(1.6, .28, 3500), tone=6500, layers=[   # Zombie Shooter: action horror
        bass(oct=-1, pat=EIGHTHS, g=.5),
        arp(inst="stab", rate=2, pat=[0, None, None, 0, None, 1, None, None], g=.25, pan=-.2),
        pad(oct=0, g=.18, cutoff=800, voices=4),
        perc(kick=[0, 2, 2.5], snare=[1, 3], hat=H8, gk=.55, gs=.3, gh=.07),
        mel(inst="bell", oct=1, dens=.1, lens=[2, 3], lo=7, hi=15, g=.25, pan=.25),
        bed("static", g=.05), bed("creak", g=.12)]),
    "durak": dict(bpm=84, root=60, scale="major", prog=[1, 4, 0, 5, 1, 4, 0, 0], swing=.62, rev=(1.8, .3, 4500), layers=[  # Durak: lounge jazz
        chords(inst="ep", beats=[(0, 1.6), (2.5, 1.2)], notes=[0, 1, 2, 3], seventh=True, g=.22),
        bass(seventh=True, pat=[(0, 0, .95), (1, 1, .95), (2, 2, .95), (3, 1, .95)], g=.5),
        mel(inst="ep", oct=1, dens=.3, lens=[1, 2, 2, 3], seventh=True, g=.3, pan=.2),
        perc(kick=[0, 2], hat=[0, 1, 1.5, 2, 3, 3.5], gk=.18, gh=.09),
        bed("crackle", g=.06)]),
    "sakura": dict(bpm=72, root=62, scale="insen", prog=[0, 2, 3, 0], rev=(2.4, .4, 5000), layers=[                     # Sakura Catch: koto and wind
        arp(inst="koto", rate=2, pat=[0, 2, 1, 3, 2, 4, 1, 2], g=.34, pan=-.2),
        mel(inst="koto", oct=1, dens=.28, lens=[2, 3, 4], g=.4, pan=.25),
        pad(oct=-1, g=.16, wave="soft", cutoff=1300, att=1.6, rel=2.0),
        perc(kick=[0], gk=.3),
        bass(inst="sub", pat=[(0, 0, 3.8)], g=.3),
        bed("wind", g=.07)]),
    "blocks": dict(bpm=78, root=60, scale="major", prog=[3, 2, 1, 4], swing=.6, rev=(1.8, .3, 3800), tone=5500, layers=[  # Cute Blocks: lo-fi
        chords(inst="ep", beats=[(0, 2.0), (2.5, 1.4)], notes=[0, 1, 2, 3], seventh=True, g=.22),
        bass(seventh=True, pat=[(0, 0, 1.8), (2.5, 0, 1.0), (3.5, 2, .4)], g=.5),
        mel(inst="ep", oct=1, dens=.25, lens=[1, 2, 2, 3], seventh=True, g=.3, pan=.2),
        perc(kick=[0, 2.5], snare=[1, 3], hat=H8, gk=.4, gs=.2, gh=.09),
        bed("crackle", g=.12)]),
    "cakes": dict(bpm=80, root=65, scale="major", prog=[0, 3, 4, 0], rev=(2.2, .35, 5500), layers=[                     # Cake Bakery: cozy
        mel(inst="box", oct=1, dens=.4, lens=[1, 2, 2, 3], g=.36, pan=.2),
        arp(inst="marimba", rate=2, pat=[0, 2, 1, 2, 0, 2, 3, 2], g=.2, pan=-.25),
        pad(oct=-1, g=.22, wave="soft"),
        bass(pat=[(0, 0, 1.8), (2, 2, 1.8)], g=.4),
        perc(rim=[1, 3], kick=[0], gr=.12, gk=.22)]),
    "cakefactory": dict(bpm=112, root=63, scale="major", prog=[0, 4, 3, 4], rev=(1.0, .18, 5500), layers=[             # Cake Factory: cute machines
        perc(kick=[0, 2], gear=[1, 3, 1.5, 3.5], gg=.28, gk=.35),
        bass(pat=[(0, 0, .45), (1, 0, .45), (2, 2, .45), (3, 0, .45)], g=.5),
        arp(inst="marimba", rate=2, pat=[0, 2, 1, 2, 4, 2, 1, 2], g=.3, pan=-.25),
        mel(inst="bell", oct=1, dens=.3, g=.28, pan=.3),
        pad(oct=-1, g=.1, wave="soft")]),
}


def main():
    names = sys.argv[1:] or list(GAMES)
    for name in names:
        out, N = render(name, GAMES[name])
        save_ogg(name, out)
        rms = 20 * math.log10(math.sqrt(np.mean(out ** 2)) + 1e-9)
        seam = float(np.max(np.abs(out[:, 0] - out[:, -1])))
        kb = os.path.getsize(os.path.join(OUT, name + ".ogg")) // 1024
        print(f"{name:12s} {N / SR:5.1f}s  rms {rms:6.1f} dB  peak {np.max(np.abs(out)):.2f}  seam {seam:.3f}  {kb} KB", flush=True)
    sounds = {f"music.{g}": {"sounds": [{"name": f"cutemod:music/{g}"}]} for g in GAMES}
    with open(os.path.join(ASSETS, "sounds.json"), "w", encoding="utf-8") as f:
        json.dump(sounds, f, indent=2)


if __name__ == "__main__":
    main()
