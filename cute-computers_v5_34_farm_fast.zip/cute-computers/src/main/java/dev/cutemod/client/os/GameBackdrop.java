package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import java.util.Map;

/**
 * The backdrop around the game box: every game gets its own, built from the game's colour (the one the store shows) and a
 * pattern that fits it (hearts for the cute ones, petals for Sakura, embers for the red ones, felt for billiards, a faint
 * flickering glow for the horror games...). Everything moves slowly, nothing is bright enough to pull the eye off the game.
 */
final class GameBackdrop {
    private GameBackdrop() {}

    private static final int STARS = 0, HEARTS = 1, PETALS = 2, BUBBLES = 3, CHECKS = 4, LEAVES = 5, EMBERS = 6, HEX = 7,
            CONFETTI = 8, GLOOM = 9, FELT = 10, ROAD = 11, SUITS = 12, SNOW = 13;

    private static final Map<String, Integer> PATTERN = Map.ofEntries(
            Map.entry("pink", HEARTS), Map.entry("green", LEAVES), Map.entry("white", SNOW), Map.entry("blue", BUBBLES),
            Map.entry("orange", EMBERS), Map.entry("purple", STARS), Map.entry("yellow", HEX), Map.entry("red", HEARTS),
            Map.entry("breakout", CONFETTI), Map.entry("cubes", CHECKS), Map.entry("pong", BUBBLES), Map.entry("bees", HEX),
            Map.entry("horror", GLOOM), Map.entry("craft", LEAVES),
            Map.entry("durak", SUITS), Map.entry("sakura", PETALS), Map.entry("blocks", CHECKS),
            Map.entry("cakes", HEARTS), Map.entry("cakefactory", CONFETTI), Map.entry("racer", ROAD), Map.entry("checkers", CHECKS),
            Map.entry("slice", EMBERS), Map.entry("rabbit", LEAVES), Map.entry("dash", STARS),
            Map.entry("tower", SNOW), Map.entry("hangman", CHECKS), Map.entry("billiards", FELT), Map.entry("bomber", CONFETTI), Map.entry("hive", STARS), Map.entry("mayhem", CONFETTI), Map.entry("funnyfarm", LEAVES), Map.entry("fighters", EMBERS), Map.entry("birds", LEAVES));

    private static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static float rnd(int i, int k) {
        int h = i * 374761393 + k * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535f;
    }

    private static int al(int a, int rgb) { return (a << 24) | (rgb & 0xFFFFFF); }

    /** Draws the backdrop of the game over the whole app area; the game box is drawn on top of it. */
    static void draw(GuiGraphics g, String id, int w, int h, int bx, int by, int bw, int bh) {
        int accent = Library.game(id).rgb();
        int pat = PATTERN.getOrDefault(id, CONFETTI);
        boolean gloom = pat == GLOOM;
        int top = mix(0x000000, accent, gloom ? 0.14f : 0.26f), bottom = mix(0x000000, accent, gloom ? 0.07f : 0.13f);
        if ((accent >> 16 & 255) + (accent >> 8 & 255) + (accent & 255) > 600) {          // very pale accents (white): a deep slate instead of grey mud
            top = mix(0x141A2C, accent, 0.12f);
            bottom = mix(0x0C1020, accent, 0.06f);
        }
        g.fillGradient(0, 0, w, h, top, bottom);
        int ink = mix(accent, 0xFFFFFF, 0.25f);
        long t = System.currentTimeMillis();
        float sec = t / 1000f;

        switch (pat) {
            case STARS -> {
                for (int i = 0; i < 34; i++) {
                    int x = (int) (rnd(i, 1) * w), y = (int) (rnd(i, 2) * h);
                    float tw = 0.5f + 0.5f * (float) Math.sin(sec * (0.8f + rnd(i, 3) * 1.4f) + i);
                    int a = 40 + (int) (tw * 90);
                    g.fill(x, y, x + 1, y + 1, al(a, ink));
                    if (i % 5 == 0) { g.fill(x - 1, y, x + 2, y + 1, al(a / 2, ink)); g.fill(x, y - 1, x + 1, y + 2, al(a / 2, ink)); }
                }
            }
            case HEARTS -> {
                for (int i = 0; i < 16; i++) {
                    float p = (rnd(i, 2) + sec * (0.012f + rnd(i, 4) * 0.02f)) % 1f;
                    int x = (int) (rnd(i, 1) * (w - 8)) + (int) (Math.sin(sec * 0.7 + i) * 3), y = h - (int) (p * (h + 10));
                    int a = (int) (70 * Math.min(1f, Math.min(p * 5, (1 - p) * 5)));
                    g.fill(x, y, x + 2, y + 1, al(a, ink)); g.fill(x + 3, y, x + 5, y + 1, al(a, ink));
                    g.fill(x, y + 1, x + 5, y + 2, al(a, ink)); g.fill(x + 1, y + 2, x + 4, y + 3, al(a, ink)); g.fill(x + 2, y + 3, x + 3, y + 4, al(a, ink));
                }
            }
            case PETALS -> {
                for (int i = 0; i < 26; i++) {
                    float p = (rnd(i, 2) + sec * (0.03f + rnd(i, 4) * 0.04f)) % 1f;
                    int x = (int) ((rnd(i, 1) * w + sec * 6 + Math.sin(sec + i) * 6) % w), y = (int) (p * (h + 6)) - 3;
                    int a = 90 + (int) (rnd(i, 5) * 80);
                    g.fill(x, y, x + 3, y + 1, al(a, 0xFFB7D2)); g.fill(x + 1, y + 1, x + 4, y + 2, al(a, 0xFF8FB8));
                }
            }
            case BUBBLES -> {
                for (int i = 0; i < 16; i++) {
                    float p = (rnd(i, 2) + sec * (0.02f + rnd(i, 4) * 0.03f)) % 1f;
                    int x = (int) (rnd(i, 1) * (w - 8)) + (int) (Math.sin(sec * 0.9 + i) * 2), y = h - (int) (p * (h + 8)), r = 2 + (int) (rnd(i, 5) * 2);
                    int a = (int) (80 * Math.min(1f, (1 - p) * 4));
                    g.fill(x + 1, y, x + r, y + 1, al(a, ink)); g.fill(x + 1, y + r, x + r, y + r + 1, al(a, ink));
                    g.fill(x, y + 1, x + 1, y + r, al(a, ink)); g.fill(x + r, y + 1, x + r + 1, y + r, al(a, ink));
                }
            }
            case CHECKS -> {
                int s = 14, off = (int) (sec * 4) % (2 * s);
                for (int yy = -s; yy < h + s; yy += s)
                    for (int xx = -2 * s; xx < w + s; xx += s)
                        if (((xx / s + yy / s) & 1) == 0) g.fill(xx + off, yy, Math.min(w, xx + off + s), Math.min(h, yy + s), al(26, ink));
            }
            case LEAVES -> {
                for (int i = 0; i < 20; i++) {
                    float p = (rnd(i, 2) + sec * (0.02f + rnd(i, 4) * 0.025f)) % 1f;
                    int x = (int) ((rnd(i, 1) * w + Math.sin(sec * 0.8 + i) * 5 + w) % w), y = (int) (p * (h + 6)) - 3;
                    g.fill(x, y, x + 3, y + 1, al(80, ink)); g.fill(x + 1, y + 1, x + 4, y + 2, al(55, ink));
                }
            }
            case EMBERS -> {
                for (int i = 0; i < 24; i++) {
                    float p = (rnd(i, 2) + sec * (0.04f + rnd(i, 4) * 0.05f)) % 1f;
                    int x = (int) (rnd(i, 1) * w) + (int) (Math.sin(sec * 1.4 + i) * 3), y = h - (int) (p * (h + 6));
                    int a = (int) (130 * (1 - p));
                    g.fill(x, y, x + 2, y + 2, al(a, mix(accent, 0xFFE08A, 0.5f)));
                }
            }
            case HEX -> {
                int s = 13;
                for (int row = 0; row * 11 < h + 11; row++)
                    for (int c = 0; c * s < w + s; c++) {
                        int x = c * s + (row & 1) * (s / 2), y = row * 11;
                        g.fill(x, y, x + 3, y + 1, al(46, ink)); g.fill(x - 1, y + 1, x + 4, y + 2, al(34, ink)); g.fill(x, y + 2, x + 3, y + 3, al(46, ink));
                    }
            }
            case CONFETTI -> {
                int[] cols = {mix(accent, 0xFFFFFF, 0.4f), mix(accent, 0xFFD84A, 0.5f), mix(accent, 0x8EC3F2, 0.5f), ink};
                for (int i = 0; i < 26; i++) {
                    float p = (rnd(i, 2) + sec * (0.015f + rnd(i, 4) * 0.02f)) % 1f;
                    int x = (int) (rnd(i, 1) * w), y = (int) (p * (h + 4)) - 2;
                    g.fill(x, y, x + 2, y + 2, al(70 + (int) (rnd(i, 6) * 50), cols[i & 3]));
                }
            }
            case GLOOM -> {
                float flick = 0.75f + 0.25f * (float) Math.sin(sec * 7 + Math.sin(sec * 3.1) * 2);
                for (int i = 0; i < 6; i++) {                                              // a dim glow at the sides, like a candle somewhere out of sight
                    int a = (int) ((9 - i) * 3 * flick);
                    g.fill(0, 0, 8 + i * 6, h, al(a, accent));
                    g.fill(w - 8 - i * 6, 0, w, h, al(a, accent));
                }
                for (int i = 0; i < 12; i++) {                                             // slow dust
                    float p = (rnd(i, 2) + sec * 0.01f) % 1f;
                    g.fill((int) (rnd(i, 1) * w), (int) (p * h), (int) (rnd(i, 1) * w) + 1, (int) (p * h) + 1, al(40, ink));
                }
            }
            case FELT -> {
                for (int yy = 0; yy < h; yy += 4) g.fill(0, yy, w, yy + 1, al(14, 0xFFFFFF));
                for (int xx = 0; xx < w; xx += 4) g.fill(xx, 0, xx + 1, h, al(10, 0xFFFFFF));
            }
            case ROAD -> {
                int off = (int) (sec * 40) % 24;
                for (int yy = -24; yy < h; yy += 24) {
                    g.fill(6, yy + off, 8, yy + off + 12, al(70, 0xFFFFFF));
                    g.fill(w - 8, yy + off, w - 6, yy + off + 12, al(70, 0xFFFFFF));
                }
                g.fill(0, 0, 3, h, al(60, accent)); g.fill(w - 3, 0, w, h, al(60, accent));
            }
            case SUITS -> {
                for (int i = 0; i < 12; i++) {
                    int x = (int) (rnd(i, 1) * (w - 8)), y = (int) (rnd(i, 2) * (h - 8));
                    boolean red = (i & 1) == 0;
                    int c = al(44, red ? 0xE86A7A : 0xE0E8F0);
                    g.fill(x + 2, y, x + 4, y + 2, c); g.fill(x, y + 2, x + 6, y + 4, c); g.fill(x + 2, y + 4, x + 4, y + 6, c);
                }
            }
            default -> {                                                                    // SNOW
                for (int i = 0; i < 28; i++) {
                    float p = (rnd(i, 2) + sec * (0.02f + rnd(i, 4) * 0.03f)) % 1f;
                    int x = (int) ((rnd(i, 1) * w + Math.sin(sec * 0.6 + i) * 4 + w) % w), y = (int) (p * (h + 4)) - 2;
                    g.fill(x, y, x + 1, y + 1, al(90, 0xFFFFFF));
                }
            }
        }
        // a soft vignette so the middle (where the game is) stays calm
        for (int i = 0; i < 5; i++) {
            int a = 22 - i * 4;
            g.fill(0, i, w, i + 1, al(a, 0x000000)); g.fill(0, h - 1 - i, w, h - i, al(a, 0x000000));
        }
        // a glow and a frame around the game box, in the colour of the game
        int frame = mix(accent, 0x000000, 0.45f);
        for (int i = 4; i >= 1; i--) g.fill(bx - i - 1, by - i - 1, bx + bw + i + 1, by + bh + i + 1, al(14 - i * 2, accent));
        g.fill(bx - 2, by - 2, bx + bw + 2, by + bh + 2, frame);
        g.fill(bx - 2, by - 2, bx + bw + 2, by - 1, al(120, mix(accent, 0xFFFFFF, 0.4f)));
        g.fill(bx - 2, by + bh + 1, bx + bw + 2, by + bh + 2, al(90, 0x000000));
    }
}
