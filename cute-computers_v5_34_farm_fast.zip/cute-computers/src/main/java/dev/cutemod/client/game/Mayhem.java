package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import dev.cutemod.data.MayhemSim;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

import static dev.cutemod.data.MayhemSim.*;

/**
 * Dangerous Weapons: a cute platform shooter in the spirit of Gun Mayhem. Four little fighters stand on marble islands
 * high in the sky, every slot is a person or a computer player. Shoot your rivals: the more a fighter is hurt, the farther
 * every hit throws him. Whoever flies off the stage loses a life. Crates with ten different weapons float down on balloons.
 * <p>
 * The rules live in {@link MayhemSim} (no Minecraft classes): solo, it runs here; online, it runs on the server and this class
 * only sends the keys and draws the snapshots. Everything here is looks: the backdrops, the fighters, the particles and sounds
 * that the events of the world turn into, the menu and the rooms.
 */
public class Mayhem extends MiniGame {
    private static final int MENU = 0, ROOMS = 1, ROOM = 2, PLAY = 3;

    private static final int[] BALLOON = {0, 0xFFFFD34D, 0xFFFF8A5C, 0xFF6FD6FF, 0xFFFF6B8A, 0xFF8ED36A, 0xFFFF9A3D, 0xFFC77DFF, 0xFF9AA3B5, 0xFFB8F0FF};
    private static final int[] BODY = {0xFFE8544E, 0xFF3E8FE8, 0xFF4FC46A, 0xFFF2B33D};
    private static final int[] SHADE = {0xFFB43A3A, 0xFF2A63B0, 0xFF349A4C, 0xFFC48A1E};
    private static final int[] LIGHT = {0xFFFF9A90, 0xFF86BEFF, 0xFF93EBA0, 0xFFFFDE85};
    private static final int GUN_DARK = 0xFF343949, GUN_MID = 0xFF666E84, GUN_LIGHT = 0xFFABB4CB, WOOD = 0xFF8A5A33;

    // the setup of a solo match, kept between matches: 0 computer player, 1 player one, 2 player two
    static int[] mode = {1, 0, 0, 0};
    static int lives = 3, skill = 1;

    private static final class Part { float x, y, vx, vy, grav; int life, max, col, size, kind; }

    private static final class Ring { float x, y, r, maxR; int life, max, col; }

    private static final class Beam { float x1, x2, y; int life, max; }

    private MayhemSim sim = new MayhemSim();
    private boolean online, won;
    private int screen = MENU, ticks, anim, theme, menuTheme, shake, bannerT, bannerCol, p1Click, noticeT, seenState, sendT, sentBits = -1,
            lastPhase, lastCount, snapAge, ox, oy;
    private String banner = "", noticeKey = "";
    private final List<Part> parts = new ArrayList<>();
    private final List<Ring> rings = new ArrayList<>();
    private final List<Beam> beams = new ArrayList<>();
    private final int[] shootAnim = new int[N], tagT = new int[N];
    private final String[] tagTxt = {"", "", "", ""};
    private final float[] rx = new float[N], ry = new float[N];
    private final boolean[] havePos = new boolean[N];
    private final boolean[] prevUp = new boolean[3], prevFire = new boolean[3], jumpEdge = new boolean[3], fireEdge = new boolean[3];
    private final Fighter[] preview = new Fighter[N];

    public Mayhem() {
        for (int i = 0; i < N; i++) preview[i] = new Fighter(i);
        reset();
    }

    // ------------------------------------------------------------------ helpers

    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private static int mix(int a, int b, float t) {
        t = Math.max(0F, Math.min(1F, t));
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** The colour c with its opacity multiplied by a (0..1). */
    private static int fade(int c, float a) {
        int al = Math.max(0, Math.min(255, Math.round(((c >>> 24) / 255F) * a * 255F)));
        return (al << 24) | (c & 0xFFFFFF);
    }

    private static int sign(float v) { return v < 0 ? -1 : 1; }

    private void R(GuiGraphics g, float x, float y, int w, int h, int c) {
        int ix = Math.round(x) + ox, iy = Math.round(y) + oy;
        g.fill(ix, iy, ix + w, iy + h, c);
    }

    private void D(GuiGraphics g, float cx, float cy, int r, int c) { disc(g, Math.round(cx) + ox, Math.round(cy) + oy, r, c); }

    private void big(GuiGraphics g, String s, int cx, int y, float k, int col) {
        g.pose().pushPose();
        g.pose().scale(k, k, 1F);
        ctext(g, s, Math.round(cx / k) + 1, Math.round(y / k) + 1, 0xAA000000);
        ctext(g, s, Math.round(cx / k), Math.round(y / k), col);
        g.pose().popPose();
    }

    private void say(String s, int col, int t) { banner = s; bannerCol = col; bannerT = t; }

    // ------------------------------------------------------------------ particles

    private void spawn(float x, float y, float vx, float vy, float grav, int life, int col, int size, int kind) {
        if (parts.size() > 500) return;
        Part p = new Part();
        p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.grav = grav; p.life = p.max = life; p.col = col; p.size = size; p.kind = kind;
        parts.add(p);
    }

    private void puff(float x, float y, int n, int col) {
        for (int i = 0; i < n; i++) spawn(x + (rnd.nextFloat() - 0.5F) * 4F, y, (rnd.nextFloat() - 0.5F) * 0.9F, -rnd.nextFloat() * 0.35F, 0F, 14 + rnd.nextInt(8), col, 1, 1);
    }

    private void tickParts() {
        for (int i = parts.size() - 1; i >= 0; i--) {
            Part p = parts.get(i);
            p.x += p.vx; p.y += p.vy; p.vy += p.grav;
            if (--p.life <= 0) parts.remove(i);
        }
        for (int i = beams.size() - 1; i >= 0; i--) if (--beams.get(i).life <= 0) beams.remove(i);
        for (int i = rings.size() - 1; i >= 0; i--) {
            Ring r = rings.get(i);
            r.r += (r.maxR - r.r) * 0.25F;
            if (--r.life <= 0) rings.remove(i);
        }
    }


    private MayhemSim S() { return online ? MayhemNet.view : sim; }

    private int me() {
        if (online) return MayhemNet.stateSlot >= 0 ? MayhemNet.stateSlot : MayhemNet.mySlot;
        for (int i = 0; i < N; i++) if (mode[i] != 0) return i;
        return 0;
    }

    private boolean mine(Fighter f) { return online ? f.id == me() : f.kind == KIND_HUMAN; }

    private String nameOf(int i) {
        Fighter q = S().f[i];
        if (online) {
            if (q.kind == KIND_HUMAN) return MayhemNet.slotName[i].isEmpty() ? tr("cutemod.mayhem.c." + i) : MayhemNet.slotName[i];
            return tr("cutemod.mayhem.bot");
        }
        return mode[i] == 1 ? tr("cutemod.mayhem.p1") : mode[i] == 2 ? tr("cutemod.mayhem.p2") : tr("cutemod.mayhem.bot");
    }

    // ------------------------------------------------------------------ flow

    @Override
    public void reset() {
        score = 0; over = false; won = false;
        screen = MENU; online = false;
        parts.clear(); rings.clear(); beams.clear();
        shake = 0; bannerT = 0; ox = 0; oy = 0; noticeT = 0;
        menuTheme = rnd.nextInt(3);
        MayhemNet.request();                                     // maybe we are still in a room: tick() brings us back to it
    }

    @Override
    public void close() {
        if (MayhemNet.inRoom) MayhemNet.leave();
    }

    private void startLocal() {
        boolean human = false;
        for (int m : mode) if (m != 0) human = true;
        if (!human) mode[0] = 1;
        sim = new MayhemSim();
        for (int i = 0; i < N; i++) sim.setup(i, mode[i] != 0 ? KIND_HUMAN : KIND_BOT);
        sim.configure(lives, skill, -1);
        sim.start();
        online = false;
        beginRound();
    }

    private void startOnline() {
        online = true;
        beginRound();
        seenState = MayhemNet.stateVersion - 1;
        MayhemNet.pending.clear();
    }

    private void beginRound() {
        screen = PLAY;
        score = 0; over = false; won = false;
        parts.clear(); rings.clear(); beams.clear();
        shake = 0; bannerT = 0; snapAge = 0; sentBits = -1; sendT = 0; lastCount = -1;
        java.util.Arrays.fill(havePos, false);
        java.util.Arrays.fill(shootAnim, 0);
        java.util.Arrays.fill(prevUp, false);
        java.util.Arrays.fill(prevFire, false);
        lastPhase = S().phase;
        theme = S().theme;
        for (int i = 0; i < N; i++) { tagT[i] = 170; tagTxt[i] = nameOf(i); }
    }

    @Override
    public void tick() {
        ticks++; anim++;
        if (shake > 0) shake--;
        if (bannerT > 0) bannerT--;
        if (noticeT > 0) noticeT--;
        if (p1Click > 0) p1Click--;
        netTick();
        if (screen == PLAY) playTick();
        tickFx();
    }

    private void netTick() {
        int n = MayhemNet.takeNotice();
        if (n != 0) { noticeKey = "cutemod.mayhem.notice." + n; noticeT = 220; }
        if ((screen == ROOMS || screen == ROOM) && anim % 100 == 0) MayhemNet.request();
        if ((screen == MENU || screen == ROOMS) && MayhemNet.inRoom && !MayhemNet.inGame) { screen = ROOM; online = true; }
        if (screen == ROOM && !MayhemNet.inRoom) screen = ROOMS;
        if (screen == ROOM && MayhemNet.inGame && MayhemNet.stateVersion != seenState && !MayhemNet.view.over) startOnline();
        if (screen == PLAY && online && !MayhemNet.inRoom) { screen = ROOMS; online = false; }
    }

    private void tickFx() {
        for (int i = 0; i < N; i++) { if (shootAnim[i] > 0) shootAnim[i]--; if (tagT[i] > 0) tagT[i]--; }
        tickParts();
    }

    private void playTick() {
        MayhemSim s = S();
        if (online) {
            if (MayhemNet.stateVersion != seenState) { seenState = MayhemNet.stateVersion; snapAge = 0; drain(MayhemNet.pending); }
            else snapAge++;
            int bits = keysFor(0);
            int press = (jumpEdge[0] ? 1 : 0) | (fireEdge[0] ? 2 : 0);
            if (bits != sentBits || press != 0 || ++sendT >= 30) { MayhemNet.input(bits, press); sentBits = bits; sendT = 0; }
            for (Fighter q : s.f) if (q.kind != KIND_OFF && q.alive) q.anim++;
            smooth(s);
        } else {
            boolean two = false;
            for (int m : mode) if (m == 2) two = true;
            for (int i = 0; i < N; i++) {
                if (s.f[i].kind == KIND_HUMAN) s.input(i, keysFor(mode[i] == 2 ? 2 : two ? 1 : 0), false, false);
            }
            sim.tick();
            drain(sim.events);
            for (int i = 0; i < N; i++) { rx[i] = s.f[i].x; ry[i] = s.f[i].y; }
        }
        if (s.phase != lastPhase) {
            if (lastPhase == PH_COUNT && s.phase == PH_PLAY) { say(tr("cutemod.mayhem.fight"), 0xFFFFE27A, 55); pling(1.9F); }
            if (s.phase == PH_END) {
                if (s.winner >= 0) say(tr("cutemod.mayhem.winner", tr("cutemod.mayhem.c." + s.winner)), BODY[s.winner], 170);
                else say(tr("cutemod.mayhem.draw"), 0xFFFFFFFF, 170);
                pling(1.5F);
            }
            lastPhase = s.phase;
        }
        if (s.phase == PH_COUNT) {
            int n = Math.min(3, s.phaseT / 50 + 1);
            if (n != lastCount) { lastCount = n; pling(n == 3 ? 1.0F : n == 2 ? 1.2F : 1.4F); }
        }
        if (s.over && !over) {
            over = true;
            int m = me();
            score = s.scoreOf(m);
            won = s.winner >= 0 && (online ? s.winner == m : s.f[s.winner].kind == KIND_HUMAN);
        }
    }

    /** What a person on a computer sees: where the fighters really are, a little ahead of the last snapshot. */
    private void smooth(MayhemSim s) {
        int age = Math.min(snapAge, 4);
        for (Fighter q : s.f) {
            if (q.kind == KIND_OFF) continue;
            int i = q.id;
            float tx = q.x + q.vx * age, ty = q.y + (q.ground ? 0F : q.vy * age);
            if (!havePos[i] || !q.alive || Math.abs(tx - rx[i]) > 40 || Math.abs(ty - ry[i]) > 40) { rx[i] = tx; ry[i] = ty; havePos[i] = true; }
            else { rx[i] += (tx - rx[i]) * 0.5F; ry[i] += (ty - ry[i]) * 0.5F; }
        }
    }

    // ------------------------------------------------------------------ keys

    /** The keys of one way of playing: 0 alone (WASD and the arrows), 1 player one of two (WASD), 2 player two (arrows). */
    private int keysFor(int sch) {
        boolean l, r, u, d, fire;
        if (sch == 2) {
            l = down(263); r = down(262); u = down(265); d = down(264);
            fire = down(257) || down(335) || down(345) || down(344);
        } else {
            boolean arrows = sch == 0;
            l = down(65) || (arrows && down(263));
            r = down(68) || (arrows && down(262));
            u = down(87) || (arrows && down(265));
            d = down(83) || (arrows && down(264));
            fire = down(32) || down(70) || p1Click > 0 || (arrows && (down(257) || down(345)));
        }
        jumpEdge[sch] = u && !prevUp[sch]; prevUp[sch] = u;
        fireEdge[sch] = fire && !prevFire[sch]; prevFire[sch] = fire;
        return (l ? K_LEFT : 0) | (r ? K_RIGHT : 0) | (d ? K_DOWN : 0) | (fire ? K_FIRE : 0) | (u ? K_JUMP : 0);
    }

    @Override
    public boolean key(int k) {
        if (k == 256) return false;
        if (screen == MENU) {
            if (k == 257 || k == KEY_SPACE || k == 335) { startLocal(); return true; }
            return false;
        }
        if (screen != PLAY) return false;
        return k == 87 || k == 65 || k == 83 || k == 68 || k == KEY_SPACE || k == 70 || k == 257 || k == KEY_UP || k == KEY_DOWN
                || k == KEY_LEFT || k == KEY_RIGHT || k == 345 || k == 344;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (screen == PLAY) { p1Click = 6; return true; }
        if (screen == MENU) return menuClick(x, y);
        if (screen == ROOMS) return roomsClick(x, y);
        if (screen == ROOM) return roomClick(x, y);
        return false;
    }

    private boolean menuClick(int x, int y) {
        for (int i = 0; i < N; i++) {
            if (in(x, y, 8 + i * 53, 28, 49, 58)) { cycle(i); beep(); return true; }
        }
        if (in(x, y, 8, 92, 100, 14)) { lives = lives == 3 ? 5 : lives == 5 ? 2 : 3; beep(); return true; }
        if (in(x, y, 112, 92, 100, 14)) { skill = (skill + 1) % 3; beep(); return true; }
        if (in(x, y, 8, 110, 100, 16)) { startLocal(); return true; }
        if (in(x, y, 112, 110, 100, 16)) { screen = ROOMS; MayhemNet.request(); pling(1.0F); return true; }
        return true;
    }

    private void cycle(int i) {
        int m = mode[i];
        for (int k = 0; k < 3; k++) {
            m = (m + 1) % 3;
            boolean used = false;
            for (int j = 0; j < N; j++) if (j != i && m != 0 && mode[j] == m) used = true;
            if (!used) break;
        }
        mode[i] = m;
    }

    private boolean roomsClick(int x, int y) {
        if (in(x, y, 4, 4, 30, 12)) { screen = MENU; pling(0.8F); return true; }
        if (in(x, y, 140, 3, 76, 14)) { MayhemNet.create(); pling(1.2F); return true; }
        int rows = Math.min(MayhemNet.hosts.size(), 5);
        for (int i = 0; i < rows; i++) {
            if (in(x, y, 8, 24 + i * 20, 204, 18)) { MayhemNet.join(MayhemNet.hosts.get(i)); pling(1.2F); return true; }
        }
        return true;
    }

    private boolean roomClick(int x, int y) {
        if (in(x, y, 4, 4, 38, 12)) { MayhemNet.leave(); screen = ROOMS; pling(0.8F); return true; }
        if (!MayhemNet.youHost) return false;
        for (int i = 1; i < 4; i++) {
            if (in(x, y, 8 + i * 53, 20, 49, 58)) { MayhemNet.slot(i); beep(); return true; }
        }
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 70 + i * 46, 82, 44, 12)) { MayhemNet.setLevel(i); beep(); return true; }
        }
        int[] lv = {2, 3, 5};
        for (int i = 0; i < 3; i++) {
            if (in(x, y, 70 + i * 34, 96, 30, 12)) { MayhemNet.setLives(lv[i]); beep(); return true; }
        }
        if (in(x, y, 40, 111, 140, 14)) { MayhemNet.start(); pling(1.4F); return true; }
        return true;
    }

    // ------------------------------------------------------------------ events -> particles and sounds

    private void drain(List<int[]> events) {
        for (int[] e : events) fx(e);
        events.clear();
    }

    private void fx(int[] e) {
        MayhemSim s = S();
        switch (e[0]) {
            case EV_SHOOT -> {
                int id = e[1], w = e[2], face = e[5];
                float mx = e[3] / 16F, my = e[4] / 16F;
                shootAnim[id] = 7;
                spawn(mx + face * 2, my, 0, 0, 0, 3, w == ICE ? 0xFFB8F0FF : w == LASER ? 0xFFE0B8FF : 0xFFFFF2A0,
                        w == SHOTGUN || w == ROCKET || w == GRENADE ? 4 : w == SNIPER ? 3 : 2, 2);
                if (w <= SNIPER) spawn(mx - face * 9, my - 1, -face * (0.4F + rnd.nextFloat() * 0.5F), -1.1F - rnd.nextFloat() * 0.6F, 0.12F, 30, 0xFFE6B84A, 1, 3);
                if (w == SHOTGUN || w == ROCKET || w == GRENADE) {
                    for (int i = 0; i < 4; i++) spawn(mx, my, face * (0.3F + rnd.nextFloat() * 0.8F), (rnd.nextFloat() - 0.5F) * 0.6F, 0F, 18, 0xFFD8D8E8, 1, 1);
                }
                switch (w) {
                    case PISTOL -> sound(SoundEvents.ARROW_SHOOT, 1.7F, 0.4F);
                    case SMG -> sound(SoundEvents.CROSSBOW_SHOOT, 2.0F, 0.25F);
                    case SHOTGUN -> { sound(SoundEvents.GENERIC_EXPLODE, 1.9F, 0.28F); sound(SoundEvents.CROSSBOW_SHOOT, 0.7F, 0.4F); }
                    case SNIPER -> sound(SoundEvents.FIREWORK_ROCKET_BLAST, 0.7F, 0.55F);
                    case GRENADE -> sound(SoundEvents.CROSSBOW_SHOOT, 0.6F, 0.5F);
                    case FLAME -> { if ((ticks & 3) == 0) sound(SoundEvents.ARROW_SHOOT, 0.5F, 0.25F); }
                    case LASER -> { sound(SoundEvents.ENDERMAN_TELEPORT, 2.0F, 0.35F); sound(SoundEvents.FIREWORK_ROCKET_BLAST, 1.9F, 0.3F); }
                    case MINE -> sound(SoundEvents.PLAYER_ATTACK_KNOCKBACK, 0.6F, 0.5F);
                    case ICE -> sound(SoundEvents.GLASS_HIT, 1.6F, 0.5F);
                    default -> sound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 0.8F, 0.55F);
                }
            }
            case EV_JUMP -> {
                puff(e[2] / 16F, e[3] / 16F, e[4] == 1 ? 5 : 4, e[4] == 1 ? LIGHT[e[1]] : 0xFFFFFFFF);
                sound(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, e[4] == 1 ? 1.9F : 1.5F, 0.3F);
            }
            case EV_LAND -> puff(e[1] / 16F, e[2] / 16F, 3, 0xFFFFFFFF);
            case EV_HIT -> {
                int id = e[1], w = e[2];
                float x = e[3] / 16F, y = e[4] / 16F;
                int dir = (e[5] & 1) != 0 ? 1 : -1;
                if (w == ICE) {
                    for (int i = 0; i < 8; i++) spawn(x, y, (rnd.nextFloat() - 0.5F) * 2F, (rnd.nextFloat() - 0.7F) * 1.6F, 0.05F, 20, i % 2 == 0 ? 0xFFB8F0FF : 0xFFFFFFFF, 1, 0);
                } else if (w == LASER) {
                    for (int i = 0; i < 6; i++) spawn(x, y, (rnd.nextFloat() - 0.5F) * 2.4F, (rnd.nextFloat() - 0.5F) * 2.4F, 0F, 12, i % 2 == 0 ? 0xFFE0B8FF : 0xFFFFFFFF, 1, 0);
                } else if (w != ROCKET) {
                    for (int i = 0; i < 4; i++) {
                        spawn(x, y, dir * (0.5F + rnd.nextFloat()), (rnd.nextFloat() - 0.7F) * 1.4F, 0.05F, 14,
                                w == FLAME ? (i % 2 == 0 ? 0xFFFFB347 : 0xFFFF6A3D) : i % 2 == 0 ? 0xFFFFFFFF : LIGHT[id], 1, 0);
                    }
                }
                if ((e[5] & 2) != 0) shake = Math.max(shake, 4);
                if (w != FLAME || (ticks & 3) == 0) sound(SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.4F, 0.35F);
            }
            case EV_EXPLODE -> {
                float x = e[1] / 16F, y = e[2] / 16F, size = e[3] / 10F;
                Ring rg = new Ring(); rg.x = x; rg.y = y; rg.r = 3; rg.maxR = 24 * size; rg.life = rg.max = 16; rg.col = 0xFFFFE27A; rings.add(rg);
                for (int i = 0; i < 22; i++) {
                    float a = rnd.nextFloat() * 6.2832F, sp = 0.4F + rnd.nextFloat() * 2.2F;
                    spawn(x, y, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp, 0.02F, 20 + rnd.nextInt(14),
                            i % 3 == 0 ? 0xFFFF7A3D : i % 3 == 1 ? 0xFFFFD34D : 0xFFE8E8F0, 2, 1);
                }
                spawn(x, y, 0, 0, 0, 7, 0xFFFFF2A0, 9, 2);
                shake = Math.max(shake, 6);
                sound(SoundEvents.GENERIC_EXPLODE, 1.15F, 0.6F);
            }
            case EV_DIE -> {
                int id = e[1];
                float px = e[2] / 16F, py = e[3] / 16F;
                for (int i = 0; i < 26; i++) {
                    float a = rnd.nextFloat() * 6.2832F, sp = 0.6F + rnd.nextFloat() * 2.4F;
                    spawn(px, py, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp, 0.02F, 28 + rnd.nextInt(18), i % 3 == 0 ? 0xFFFFFFFF : BODY[id], 2, 0);
                }
                Ring rg = new Ring(); rg.x = px; rg.y = py; rg.r = 2; rg.maxR = 26; rg.life = rg.max = 22; rg.col = LIGHT[id]; rings.add(rg);
                shake = Math.max(shake, 9);
                sound(SoundEvents.GENERIC_EXPLODE, 0.9F, 0.45F);
                sound(SoundEvents.ENDERMAN_TELEPORT, 0.8F, 0.4F);
                if (s.phase == PH_PLAY) say(tr("cutemod.mayhem.ko"), BODY[id], 32);
            }
            case EV_RESPAWN -> {
                int id = e[1];
                puff(e[2] / 16F, 4, 8, LIGHT[id]);
                sound(SoundEvents.ENDERMAN_TELEPORT, 1.6F, 0.3F);
                tagT[id] = 110; tagTxt[id] = nameOf(id);
            }
            case EV_PICKUP -> {
                int id = e[1], w = e[2];
                Ring rg = new Ring(); rg.x = e[3] / 16F; rg.y = e[4] / 16F; rg.r = 2; rg.maxR = 14; rg.life = rg.max = 14; rg.col = 0xFFFFFFFF; rings.add(rg);
                pling(1.7F);
                tagT[id] = 80; tagTxt[id] = tr("cutemod.mayhem.w." + w);
            }
            case EV_CRATE_LAND -> {
                float x = e[1] / 16F, y = e[2] / 16F;
                for (int k = 0; k < 8; k++) spawn(x, y - 24, (rnd.nextFloat() - 0.5F) * 1.4F, (rnd.nextFloat() - 0.8F) * 1F, 0.05F, 24, BALLOON[e[3]], 2, 0);
            }
            case EV_FREEZE -> sound(SoundEvents.GLASS_HIT, 1.2F, 0.5F);
            case EV_THAW -> puff(rx[e[1]], ry[e[1]] - 6, 6, 0xFFB8F0FF);
            case EV_LASER -> {
                Beam bm = new Beam(); bm.x1 = e[1] / 16F; bm.y = e[2] / 16F; bm.x2 = e[3] / 16F; bm.life = bm.max = 8; beams.add(bm);
            }
            case EV_EMPTY -> { tagT[e[1]] = 50; tagTxt[e[1]] = tr("cutemod.mayhem.empty"); }
            default -> { }
        }
    }

    private void tag(GuiGraphics g, Fighter f) {
        if (!f.alive) return;
        int id = f.id;
        int tx = Math.round(rx[id]) + ox, ty = Math.round(ry[id]) + oy;
        if (tagT[id] > 0) {
            int tyy = Math.max(21, ty - 26);
            float a = tagT[id] < 20 ? tagT[id] / 20F : 1F;
            ctext(g, tagTxt[id], tx + 1, tyy + 1, fade(0xFF000000, a * 0.8F));
            ctext(g, tagTxt[id], tx, tyy, fade(0xFFFFFFFF, a));
        } else if (mine(f)) {
            int c = LIGHT[id];
            rect(g, tx - 2, ty - 19, 5, 1, c); rect(g, tx - 1, ty - 18, 3, 1, c); rect(g, tx, ty - 17, 1, 1, c);
        }
        if (ry[id] < 0) {   // above the screen: a little arrow at the top edge
            int mx2 = Math.max(4, Math.min(W - 5, tx));
            rect(g, mx2, 1, 1, 1, BODY[id]); rect(g, mx2 - 1, 2, 3, 1, BODY[id]); rect(g, mx2 - 2, 3, 5, 1, BODY[id]);
        }
    }

    // ------------------------------------------------------------------ drawing: the backdrops

    private static float sin(float v) { return (float) Math.sin(v); }

    private void cloud(GuiGraphics g, float x, float y, float s, int col, int shade) {
        for (int pass = 0; pass < 2; pass++) {
            int c = pass == 0 ? shade : col;
            int yy = (int) y + (pass == 0 ? 2 : 0);
            disc(g, (int) x, yy, Math.max(2, (int) (5 * s)), c);
            disc(g, (int) (x + 8 * s), yy - (int) (3 * s), Math.max(2, (int) (6 * s)), c);
            disc(g, (int) (x + 16 * s), yy, Math.max(2, (int) (5 * s)), c);
            rect(g, (int) x, yy, (int) (16 * s), Math.max(2, (int) (5 * s)), c);
        }
    }

    private void backdrop(GuiGraphics g) {
        int[][] sky = {{0xFF4A3F8F, 0xFFD8649A, 0xFFFFC08C}, {0xFF1C74BA, 0xFF2FAAD6, 0xFF8FE3E0}, {0xFF0C0E30, 0xFF282266, 0xFF5A4A9C}};
        int[] s = sky[theme];
        for (int yy = 0; yy < H; yy += 2) {
            float t = yy / (float) H;
            rect(g, 0, yy, W, 2, t < 0.55F ? mix(s[0], s[1], t / 0.55F) : mix(s[1], s[2], (t - 0.55F) / 0.45F));
        }
        float tt = ticks;
        if (theme == 0) {
            disc(g, 158, 88, 24, 0x18FFE0A0); disc(g, 158, 88, 19, 0x28FFD890); disc(g, 158, 88, 14, 0xFFFFF0B8);
            for (int k = 0; k < 4; k++) rect(g, 142, 92 + k * 3, 32, 1, 0x33E8708C);
            island(g, 30, 52, 26, 0xFF5B3F86, 0xFF8ED36A); island(g, 188, 30, 20, 0xFF6B4A94, 0xFF9BE07A);
            for (int i = 0; i < 4; i++) {
                float cx = ((i * 71 + tt * (0.06F + i * 0.025F)) % (W + 50)) - 25;
                cloud(g, cx, 16 + (i * 37) % 70, 1F + (i % 3) * 0.3F, 0xFFFFD6E2, 0xFFEAA6C6);
            }
            for (int i = 0; i < 3; i++) {
                float bx = ((tt * 0.35F + i * 90) % (W + 30)) - 15, by = 22 + i * 9 + sin(tt * 0.05F + i) * 3;
                int wing = ((int) (tt / 8) + i) % 2;
                rect(g, (int) bx, (int) by + wing, 2, 1, 0xFF5B3F86); rect(g, (int) bx + 2, (int) by, 2, 1, 0xFF5B3F86); rect(g, (int) bx + 4, (int) by + wing, 2, 1, 0xFF5B3F86);
            }
            seaOfClouds(g, tt, 0xFFB78AD4, 0xFFD9A8E0, 0xFFF2C4EA);
        } else if (theme == 1) {
            for (int k = 0; k < 4; k++) {
                int bx = 20 + k * 58;
                for (int yy = 0; yy < 118; yy += 2) rect(g, bx + (int) (yy * 0.35F + sin(tt * 0.01F + k) * 6), yy, 12 + k * 2, 2, 0x16FFFFFF);
            }
            for (int i = 0; i < 18; i++) {
                float bx = 6 + (i * 37) % 208 + sin(tt * 0.03F + i) * 3, by = H - ((tt * (0.25F + (i % 4) * 0.08F) + i * 23) % (H + 10));
                int r = 1 + i % 3 / 2;
                disc(g, (int) bx, (int) by, r, 0x44FFFFFF);
                rect(g, (int) bx - r + 1, (int) by - r + 1, 1, 1, 0xAAFFFFFF);
            }
            for (int i = 0; i < 5; i++) {
                float fx = ((tt * (0.4F + i * 0.05F) + i * 49) % (W + 40)) - 20, fy = 40 + i * 14 + sin(tt * 0.04F + i) * 2;
                rect(g, (int) fx, (int) fy, 4, 2, 0xFFFFB86B); rect(g, (int) fx + 4, (int) fy - 1, 1, 4, 0xFFFF8A5C); rect(g, (int) fx + 1, (int) fy, 1, 1, 0xFF2A2A4A);
            }
            // a purple octopus drifts at the bottom right
            float oxp = 176 + sin(tt * 0.015F) * 14, oyp = 108 + sin(tt * 0.03F) * 4;
            disc(g, (int) oxp, (int) oyp, 9, 0xFFA66BD6); disc(g, (int) oxp, (int) oyp - 3, 6, 0xFFB98AE4);
            rect(g, (int) oxp - 4, (int) oyp - 2, 3, 3, 0xFFFFFFFF); rect(g, (int) oxp + 2, (int) oyp - 2, 3, 3, 0xFFFFFFFF);
            rect(g, (int) oxp - 3, (int) oyp - 1, 1, 2, 0xFF2A1E4A); rect(g, (int) oxp + 3, (int) oyp - 1, 1, 2, 0xFF2A1E4A);
            for (int k = 0; k < 5; k++) for (int q = 0; q < 8; q++) rect(g, (int) (oxp - 8 + k * 4 + sin(tt * 0.08F + q * 0.7F + k) * 2), (int) oyp + 5 + q, 2, 1, q < 6 ? 0xFF8F55C4 : 0xFF7A44B0);
            // seabed with coral and kelp
            rect(g, 0, 124, W, 16, 0xFFE8D29A); rect(g, 0, 124, W, 2, 0xFFF6E8B8);
            for (int k = 0; k < 9; k++) {
                int kx = 8 + k * 26;
                int h = 12 + (k * 7) % 10;
                int c = k % 3 == 0 ? 0xFF3FAE6A : k % 3 == 1 ? 0xFFEF7BA6 : 0xFF9B6BD6;
                for (int q = 0; q < h; q++) rect(g, kx + (int) (sin(tt * 0.04F + q * 0.3F + k) * (q * 0.12F)), 124 - q, 3, 1, q % 4 == 3 ? mix(c, 0xFFFFFFFF, 0.25F) : c);
            }
        } else {
            for (int i = 0; i < 44; i++) {
                int sx = (i * 53 + 17) % W, sy = (i * 29 + 7) % 96;
                float tw = 0.5F + 0.5F * sin(tt * 0.05F + i * 1.7F);
                rect(g, sx, sy, 1, 1, fade(0xFFFFFFFF, 0.35F + 0.65F * tw));
                if (i % 9 == 0 && tw > 0.8F) { rect(g, sx - 1, sy, 3, 1, 0x88FFFFFF); rect(g, sx, sy - 1, 1, 3, 0x88FFFFFF); }
            }
            disc(g, 44, 36, 22, 0x14FFF6C8); disc(g, 44, 36, 17, 0x22FFF6C8); disc(g, 44, 36, 13, 0xFFF6F0CC);
            disc(g, 39, 32, 3, 0xFFE4DCAE); disc(g, 49, 41, 2, 0xFFE4DCAE); disc(g, 48, 29, 2, 0xFFE9E2B8);
            float ss = (tt % 420) / 420F;
            if (ss < 0.12F) { float k = ss / 0.12F; for (int q = 0; q < 10; q++) rect(g, (int) (150 - k * 90 + q * 2), (int) (10 + k * 40 - q), 1, 1, fade(0xFFFFFFFF, 1F - q / 10F)); }
            for (int i = 0; i < 3; i++) {
                float cx = ((i * 97 + tt * (0.05F + i * 0.02F)) % (W + 50)) - 25;
                cloud(g, cx, 30 + i * 22, 1.1F, 0xFF4A3F8F, 0xFF3A2F7A);
            }
            seaOfClouds(g, tt, 0xFF3A2F7A, 0xFF4F3F98, 0xFF6A58B4);
            for (int k = 0; k < 6; k++) rect(g, 30 + k * 2, 118 + k * 3, 28 - k * 4, 1, fade(0xFFFFF6C8, 0.18F + 0.1F * sin(tt * 0.05F + k)));
        }
    }

    private void island(GuiGraphics g, int cx, int y, int w, int rock, int grass) {
        for (int k = 0; k < 9; k++) rect(g, cx - w / 2 + k, y + k, w - 2 * k, 1, rock);
        rect(g, cx - w / 2, y - 2, w, 3, grass);
        rect(g, cx - 2, y - 7, 1, 5, 0xFF5B3F2B); disc(g, cx - 1, y - 9, 3, 0xFF4FB86A);
    }

    private void seaOfClouds(GuiGraphics g, float tt, int c0, int c1, int c2) {
        for (int row = 0; row < 3; row++) {
            int c = row == 0 ? c0 : row == 1 ? c1 : c2;
            int yy = 124 + row * 6;
            for (int i = 0; i < 12; i++) {
                float cx = ((i * 22 + tt * (0.05F + row * 0.03F)) % (W + 40)) - 10;
                disc(g, (int) cx, yy + (int) (sin(i + row) * 2), 8 - row, c);
            }
            rect(g, 0, yy + 4, W, 16, c);
        }
    }

    // ------------------------------------------------------------------ drawing: the stage

    private void stage(GuiGraphics g, boolean menu) {
        // the columns that carry the big platform
        int bx = PX[0], by = PY[0], bw = PW[0];
        int[] cxs = {bx + 24, bx + 68, bx + bw - 68, bx + bw - 24};
        for (int cx : cxs) {
            R(g, cx - 5, by + 8, 11, 3, 0xFFF6F2E8); R(g, cx - 6, by + 8, 13, 1, 0xFFFFFFFF);
            R(g, cx - 3, by + 11, 7, 11, 0xFFE9E3D4);
            R(g, cx - 3, by + 11, 1, 11, 0xFFFFFFFF); R(g, cx - 1, by + 11, 1, 11, 0xFFD3CBB8); R(g, cx + 1, by + 11, 1, 11, 0xFFD3CBB8); R(g, cx + 3, by + 11, 1, 11, 0xFFC4BBA8);
            R(g, cx - 5, by + 22, 11, 3, 0xFFF0EBDD); R(g, cx - 6, by + 24, 13, 2, 0xFFD3CBB8);
        }
        for (int i = 0; i < (menu ? 1 : PX.length); i++) {
            int x = PX[i], y = PY[i], w = PW[i];
            int th = i == 0 ? 5 : 3;
            R(g, x + 2, y + th + 3, w - 4, 1, 0x30000000);
            R(g, x, y, w, 1, 0xFFFFFFFF);
            R(g, x, y + 1, w, th, 0xFFF0EBDD);
            if (i == 0) for (int k = 6; k < w - 6; k += 6) { R(g, x + k, y + 2, 2, 3, 0xFFDCD4C2); }
            R(g, x, y + th + 1, w, 2, 0xFFC9C0AC);
            int r = i == 0 ? 4 : 3;
            for (int side = 0; side < 2; side++) {
                int cx = side == 0 ? x - 1 : x + w;
                D(g, cx, y + 3, r, 0xFFF0EBDD); D(g, cx, y + 3, r - 2, 0xFFD3CBB8); D(g, cx, y + 3, 1, 0xFFF6F2E8);
            }
            if (i > 0) {
                float gl = 0.5F + 0.5F * sin(ticks * 0.06F + i);
                for (int k = 0; k < 5; k++) R(g, x + 8 + k * (w - 16) / 4F, y + th + 4 + (k % 2) * 2, 1, 1, fade(0xFFFFFFFF, 0.3F + 0.5F * gl));
            }
        }
    }

    // ------------------------------------------------------------------ drawing: fighters, guns, crates

    private void gr(GuiGraphics g, float hx, float hy, int fc, int ox2, int oy2, int w, int h, int col) {
        R(g, fc > 0 ? hx + ox2 : hx - ox2 - w, hy + oy2, w, h, col);
    }

    private void gun(GuiGraphics g, float hx, float hy, int fc, int type) {
        switch (type) {
            case PISTOL -> {
                gr(g, hx, hy, fc, 0, -1, 5, 2, GUN_MID); gr(g, hx, hy, fc, 0, 0, 2, 3, GUN_DARK); gr(g, hx, hy, fc, 4, -1, 2, 1, GUN_LIGHT);
            }
            case SMG -> {
                gr(g, hx, hy, fc, -1, -1, 8, 3, GUN_DARK); gr(g, hx, hy, fc, 2, 2, 2, 3, GUN_MID); gr(g, hx, hy, fc, 7, 0, 2, 1, GUN_LIGHT); gr(g, hx, hy, fc, 1, -2, 3, 1, GUN_MID);
            }
            case SHOTGUN -> {
                gr(g, hx, hy, fc, -3, 0, 3, 2, WOOD); gr(g, hx, hy, fc, 0, -1, 10, 2, GUN_MID); gr(g, hx, hy, fc, 4, 1, 3, 1, WOOD); gr(g, hx, hy, fc, 9, -1, 2, 1, GUN_LIGHT);
            }
            case SNIPER -> {
                gr(g, hx, hy, fc, -3, 0, 4, 2, WOOD); gr(g, hx, hy, fc, 1, -1, 13, 2, GUN_DARK); gr(g, hx, hy, fc, 4, -3, 5, 2, 0xFF3AB6C8); gr(g, hx, hy, fc, 5, -3, 1, 1, 0xFFB8F4FF); gr(g, hx, hy, fc, 12, -1, 2, 1, GUN_LIGHT);
            }
            case GRENADE -> {
                gr(g, hx, hy, fc, -2, -1, 9, 3, GUN_DARK); gr(g, hx, hy, fc, 6, -2, 4, 5, 0xFF6B8F5A); gr(g, hx, hy, fc, 1, 2, 3, 3, GUN_MID); gr(g, hx, hy, fc, 7, -2, 1, 5, 0xFF8EB878); gr(g, hx, hy, fc, -1, 2, 2, 3, GUN_DARK);
            }
            case FLAME -> {
                gr(g, hx, hy, fc, -3, -1, 3, 4, 0xFFE8A33A); gr(g, hx, hy, fc, 0, -1, 8, 3, 0xFFB5483A); gr(g, hx, hy, fc, 7, -2, 3, 5, GUN_MID); gr(g, hx, hy, fc, 10, -1, 2, 3, ticks / 3 % 2 == 0 ? 0xFFFFE27A : 0xFFFF8A3D); gr(g, hx, hy, fc, 1, 2, 2, 3, GUN_DARK);
            }
            case LASER -> {
                gr(g, hx, hy, fc, 0, -1, 9, 3, 0xFFE8E8F8); gr(g, hx, hy, fc, 1, 0, 6, 1, 0xFFC77DFF); gr(g, hx, hy, fc, 8, -1, 3, 2, 0xFF7BE8FF); gr(g, hx, hy, fc, 1, 2, 2, 3, GUN_DARK); gr(g, hx, hy, fc, 3, -2, 3, 1, 0xFFB8B8D8);
            }
            case MINE -> {
                gr(g, hx, hy, fc, 0, -1, 7, 4, 0xFF8B94A8); gr(g, hx, hy, fc, 2, -2, 3, 1, 0xFFFF4A4A); gr(g, hx, hy, fc, 6, 0, 2, 2, GUN_DARK); gr(g, hx, hy, fc, 1, 3, 2, 2, GUN_DARK);
            }
            case ICE -> {
                gr(g, hx, hy, fc, 0, -1, 8, 3, 0xFF8AD8F0); gr(g, hx, hy, fc, 1, -1, 6, 1, 0xFFFFFFFF); gr(g, hx, hy, fc, 8, -2, 3, 4, 0xFFC8F4FF); gr(g, hx, hy, fc, 1, 2, 2, 3, GUN_DARK);
            }
            default -> {
                gr(g, hx, hy, fc, -2, -2, 11, 4, 0xFF5E7A3A); gr(g, hx, hy, fc, -2, -2, 11, 1, 0xFF86A857); gr(g, hx, hy, fc, 9, -2, 2, 4, 0xFFFF8A3D); gr(g, hx, hy, fc, 1, 2, 2, 3, GUN_DARK); gr(g, hx, hy, fc, 3, -3, 2, 1, GUN_MID);
            }
        }
    }

    private void fighter(GuiGraphics g, Fighter f, float x, float y, int shoot) {
        int id = f.id;
        int body = BODY[id], shade = SHADE[id], light = LIGHT[id];
        boolean white = f.flash > 0 && (f.flash & 1) == 0;
        if (white) { body = 0xFFFFFFFF; shade = 0xFFDDDDDD; light = 0xFFFFFFFF; }
        int fc = f.face;
        boolean air = !f.ground;
        boolean run = f.ground && Math.abs(f.vx) > 0.3F;
        int step = run ? (f.anim / 4) & 1 : 0;
        int br = (!air && !run && ((f.anim / 36) & 1) == 1) ? 1 : 0;
        if (f.invT > 0) D(g, x, y - 6, 10, fade(0xFFFFFFFF, 0.10F + 0.08F * sin(ticks * 0.3F)));
        // shadow of the fighter on the platform he stands on
        if (f.ground) R(g, x - 4, y, 9, 1, 0x28000000);
        int ly = air ? -3 : -2;
        R(g, x - 4, y + ly + (run && step == 1 ? -1 : 0), 3, 2, shade);
        R(g, x + 1, y + ly + (run && step == 0 ? -1 : 0), 3, 2, shade);
        R(g, x - 3, y - 11 + br, 7, 1, light);
        R(g, x - 4, y - 10 + br, 9, 7 - br, body);
        R(g, x - 3, y - 3, 7, 1, shade);
        R(g, fc > 0 ? x - 4 : x + 4, y - 10 + br, 1, 7 - br, shade);
        R(g, fc > 0 ? x + 1 : x - 3, y - 10 + br, 2, 1, light);
        // eyes
        int eyeY = Math.round(y) - 8 + br;
        float e1 = fc > 0 ? x - 1 : x - 3, e2 = fc > 0 ? x + 2 : x;
        boolean blink = (f.anim + id * 37) % 200 < 6, ouch = f.hitT > 3;
        if (ouch || blink) { R(g, e1, eyeY + 1, 2, 1, 0xFF2A2233); R(g, e2, eyeY + 1, 2, 1, 0xFF2A2233); }
        else {
            R(g, e1, eyeY, 2, 3, 0xFFFFFFFF); R(g, e2, eyeY, 2, 3, 0xFFFFFFFF);
            R(g, e1 + (fc > 0 ? 1 : 0), eyeY + 1, 1, 2, 0xFF2A2233); R(g, e2 + (fc > 0 ? 1 : 0), eyeY + 1, 1, 2, 0xFF2A2233);
        }
        R(g, fc > 0 ? x + 2 : x - 3, eyeY + 3, 2, 1, 0xAAFF8FB0);
        // the hat of every fighter
        switch (id) {
            case 0 -> { R(g, x - 4, y - 10 + br, 9, 1, 0xFFFFFFFF); R(g, fc > 0 ? x - 7 : x + 4, y - 10 + br + (f.anim / 8 & 1), 3, 1, 0xFFFFFFFF); }
            case 1 -> { R(g, x - 4, y - 12 + br, 9, 3, 0xFF2A3F73); R(g, x - 3, y - 13 + br, 7, 1, 0xFF2A3F73); R(g, x - 2, y - 13 + br, 3, 1, 0xFF5B78B8); R(g, fc > 0 ? x + 1 : x - 4, y - 10 + br, 4, 1, 0xFF9FE0FF); }
            case 2 -> { R(g, x, y - 13 + br, 1, 2, 0xFF2E8B3E); R(g, x - 2, y - 14 + br, 2, 1, 0xFF6BD16F); R(g, x + 1, y - 15 + br, 2, 1, 0xFF6BD16F); }
            default -> { R(g, x - 3, y - 13 + br, 7, 2, 0xFFFFD34D); R(g, x - 3, y - 14 + br, 1, 1, 0xFFFFD34D); R(g, x, y - 14 + br, 1, 1, 0xFFFFD34D); R(g, x + 3, y - 14 + br, 1, 1, 0xFFFFD34D); R(g, x, y - 12 + br, 1, 1, 0xFFE0394F); }
        }
        // the gun and the hand that holds it
        int kick = shoot > 4 ? 2 : shoot > 0 ? 1 : 0;
        float hx = x + fc * (4 - kick), hy = y - 6 + (air ? -1 : 0);
        gun(g, hx, hy, fc, f.weapon);
        R(g, hx - (fc > 0 ? 0 : 1), hy, 2, 2, body);
        if (f.frozenT > 0) {
            float a = f.frozenT < 15 ? f.frozenT / 15F : 1F;
            R(g, x - 6, y - 14, 13, 15, fade(0xAAB8F0FF, a)); R(g, x - 6, y - 14, 13, 1, fade(0xFFFFFFFF, a)); R(g, x - 6, y - 14, 1, 15, fade(0xCCFFFFFF, a));
            R(g, x + 2, y - 11, 2, 1, fade(0xFFFFFFFF, a)); R(g, x - 4, y - 5, 1, 2, fade(0xFFFFFFFF, a));
        }
    }

    private void crate(GuiGraphics g, Crate c) {
        float bob = c.landed ? sin(ticks * 0.08F + c.x) * 1F : 0;
        if (!c.landed) {
            int bc = BALLOON[c.weapon];
            R(g, c.x, c.y - 17, 1, 9, 0x88FFFFFF);
            D(g, c.x, c.y - 24, 6, bc); D(g, c.x - 2, c.y - 26, 2, mix(bc, 0xFFFFFFFF, 0.55F));
            R(g, c.x - 2, c.y - 19, 5, 2, mix(bc, 0xFF000000, 0.25F));
        }
        R(g, c.x - 4, c.y - 8, 9, 8, 0xFFC98B3E);
        R(g, c.x - 4, c.y - 8, 9, 1, 0xFFE8B468); R(g, c.x - 4, c.y - 1, 9, 1, 0xFF8A5A2B);
        R(g, c.x - 4, c.y - 8, 1, 8, 0xFF8A5A2B); R(g, c.x + 4, c.y - 8, 1, 8, 0xFF8A5A2B);
        R(g, c.x, c.y - 8, 1, 8, 0xFFFFE08A); R(g, c.x - 4, c.y - 5, 9, 1, 0xFFFFE08A);
        if (c.landed && (c.life > 150 || (ticks / 6 & 1) == 0)) {
            R(g, c.x - 6, c.y - 17 + bob, 13, 8, 0x55000000);
            gun(g, c.x - (c.weapon == SNIPER ? 6 : 4), c.y - 13 + bob, 1, c.weapon);
        }
    }

    private void bullet(GuiGraphics g, Bullet b) {
        int s = sign(b.vx);
        switch (b.type) {
            case SNIPER -> { R(g, b.x - s * 9, b.y, 10, 1, 0xFF7BE8FF); R(g, b.x - s * 4, b.y, 5, 1, 0xFFFFFFFF); R(g, b.x - s * 9, b.y - 1, 10, 3, 0x227BE8FF); }
            case SMG -> R(g, b.x - s * 2, b.y, 3, 1, 0xFFFFE27A);
            case GRENADE -> { R(g, b.x - 2, b.y - 2, 4, 4, 0xFF4A6B4A); R(g, b.x - 2, b.y - 2, 4, 1, 0xFF8EB878); if ((ticks / 5 & 1) == 0) R(g, b.x - 1, b.y - 3, 2, 1, 0xFFFF4A4A); }
            case FLAME -> {
                float a = b.life / (float) LIFE[FLAME];
                int r = 1 + (int) ((1F - a) * 3F);
                D(g, b.x, b.y, r, a > 0.6F ? 0xFFFFE27A : a > 0.3F ? 0xCCFF9A3D : 0x88FF5A3D);
                if (r > 1) D(g, b.x, b.y, r - 1, a > 0.6F ? 0xFFFFFFFF : 0xAAFFD34D);
            }
            case ICE -> { R(g, b.x - 2, b.y - 1, 4, 3, 0xFFB8F0FF); R(g, b.x - 1, b.y, 2, 1, 0xFFFFFFFF); R(g, b.x - s * 4, b.y, 2, 1, 0x88B8F0FF); }
            case SHOTGUN -> { R(g, b.x, b.y, 1, 1, 0xFFFFB347); R(g, b.x - s, b.y, 1, 1, 0x88FFB347); }
            case ROCKET -> {
                R(g, b.x - 3, b.y - 1, 6, 3, 0xFF5E7A3A); R(g, b.x + (s > 0 ? 3 : -4), b.y - 1, 1, 3, 0xFFFF4A4A);
                R(g, b.x - (s > 0 ? 3 : -3), b.y - 2, 1, 5, 0xFFABB4CB);
            }
            default -> { R(g, b.x - s * 2, b.y, 4, 1, 0xFFFFD34D); R(g, b.x - s * 2, b.y - 1, 4, 3, 0x33FFD34D); }
        }
    }

    private void particles(GuiGraphics g) {
        for (Part p : parts) {
            float a = p.life / (float) p.max;
            switch (p.kind) {
                case 1 -> { int sz = p.size + (int) ((1F - a) * 2); R(g, p.x - sz / 2F, p.y - sz / 2F, sz, sz, fade(p.col, a * 0.7F)); }
                case 2 -> { D(g, p.x, p.y, p.size, fade(p.col, 0.5F + 0.5F * a)); if (p.size > 2) D(g, p.x, p.y, p.size - 2, 0xFFFFFFFF); }
                default -> R(g, p.x, p.y, p.size, p.size, fade(p.col, Math.min(1F, a * 1.6F)));
            }
        }
        for (Beam bm : beams) {
            float a = bm.life / (float) bm.max;
            float x1 = Math.min(bm.x1, bm.x2), len = Math.abs(bm.x2 - bm.x1);
            R(g, x1, bm.y - 2, (int) len, 5, fade(0xFFC77DFF, a * 0.25F));
            R(g, x1, bm.y - 1, (int) len, 3, fade(0xFFE0B8FF, a * 0.7F));
            R(g, x1, bm.y, (int) len, 1, fade(0xFFFFFFFF, a));
        }
        for (Ring r : rings) {
            float a = r.life / (float) r.max;
            int n = Math.max(10, (int) (r.r * 3));
            for (int i = 0; i < n; i++) {
                float an = i * 6.2832F / n;
                R(g, r.x + (float) Math.cos(an) * r.r, r.y + (float) Math.sin(an) * r.r, 1, 1, fade(r.col, a));
            }
        }
    }


    private void hud(GuiGraphics g) {
        for (int i = 0; i < N; i++) {
            Fighter f = S().f[i];
            if (f.kind == KIND_OFF) continue;
            int x = 4 + i * 54, y = 2;
            rect(g, x, y, 50, 17, f.out ? 0x66202020 : 0x88101030);
            rect(g, x, y, 50, 1, f.out ? 0xFF555555 : BODY[i]);
            disc(g, x + 7, y + 8, 4, SHADE[i]); disc(g, x + 7, y + 8, 3, f.out ? 0xFF777777 : BODY[i]);
            rect(g, x + 7, y + 6, 1, 2, 0xFFFFFFFF); rect(g, x + 9, y + 6, 1, 2, 0xFFFFFFFF);
            if (f.out) { text(g, tr("cutemod.mayhem.out"), x + 14, y + 5, 0xFFAAAAAA); continue; }
            int dm = (int) f.dmg;
            text(g, dm + "%", x + 14, y + 1, mix(0xFFFFFFFF, 0xFFFF5A4A, Math.min(1F, dm / 150F)));
            for (int k = 0; k < f.lives; k++) {
                int hx = x + 14 + k * 5, hy = y + 11;
                int hc = f.alive ? 0xFFFF6B8A : 0xFF8A4A5A;
                rect(g, hx, hy, 1, 1, hc); rect(g, hx + 2, hy, 1, 1, hc); rect(g, hx, hy + 1, 3, 1, hc); rect(g, hx + 1, hy + 2, 1, 1, hc);
            }
            if (f.weapon != PISTOL) {
                gun(g, x + 37, y + 11, 1, f.weapon);
                String am = String.valueOf(f.ammo);
                text(g, am, x + 49 - tw(am), y + 1, 0xFFFFE27A);
            }
        }
    }


    private void button(GuiGraphics g, int x, int y, int w, int h, String s) {
        boolean hov = in(mx, my, x, y, w, h);
        rect(g, x, y, w, h, hov ? 0xCC3A3A8A : 0xAA202058);
        rect(g, x, y, w, 1, 0x55FFFFFF);
        ctextW(g, s, x + w / 2, y + 3, w - 6, 0xFFFFFFFF);
    }


    // ------------------------------------------------------------------ the screens

    @Override
    public void render(GuiGraphics g) {
        ox = 0; oy = 0;
        theme = screen == PLAY ? S().theme : menuTheme;
        switch (screen) {
            case MENU -> renderMenu(g);
            case ROOMS -> renderRooms(g);
            case ROOM -> renderRoom(g);
            default -> renderPlay(g);
        }
        if (noticeT > 0 && screen != PLAY) {
            rect(g, 25, H - 20, 170, 14, 0xFFFFE9A8);
            ctextW(g, tr(noticeKey), W / 2, H - 17, 162, 0xFF3A2A10);
        }
    }

    private void renderPlay(GuiGraphics g) {
        MayhemSim s = S();
        backdrop(g);
        hud(g);
        if (shake > 0) { int m = Math.min(4, shake / 2 + 1); ox = rnd.nextInt(m * 2 + 1) - m; oy = rnd.nextInt(m * 2 + 1) - m; }
        stage(g, false);
        for (Crate c : s.crates) crate(g, c);
        for (Mine m : s.mines) {
            R(g, m.x - 4, m.y - 3, 8, 3, 0xFF8B94A8); R(g, m.x - 3, m.y - 4, 6, 1, 0xFF6A7186); R(g, m.x - 4, m.y - 1, 8, 1, 0xFF5A6176);
            boolean on = m.arm <= 0 ? (ticks / 8 & 1) == 0 : (ticks / 3 & 1) == 0;
            R(g, m.x - 1, m.y - 5, 2, 1, on ? 0xFFFF4A4A : 0xFF7A2A2A); R(g, m.x, m.y - 5, 1, 1, on ? 0xFFFFB0B0 : 0xFF7A2A2A);
        }
        for (Fighter f : s.f) if (f.kind != KIND_OFF && f.alive) fighter(g, f, rx[f.id], ry[f.id], shootAnim[f.id]);
        int age = online ? Math.min(snapAge, 5) : 0;
        for (Bullet b : s.bullets) {
            float bx = b.x, by = b.y;
            b.x += b.vx * age; b.y += b.vy * age;
            bullet(g, b);
            b.x = bx; b.y = by;
        }
        particles(g);
        for (Fighter f : s.f) if (f.kind != KIND_OFF) tag(g, f);
        ox = 0; oy = 0;
        if (s.phase == PH_COUNT) {
            int n = Math.min(3, s.phaseT / 50 + 1);
            big(g, String.valueOf(n), 110, 44, 4F, 0xFFFFFFFF);
            ctextW(g, tr("cutemod.mayhem.ready"), 110, 24, 160, 0xFFFFE27A);
        } else if (bannerT > 0 && !banner.isEmpty()) {
            float k = s.phase == PH_END ? 2.4F : banner.equals(tr("cutemod.mayhem.fight")) ? (bannerT > 30 ? 3F : 2F) : 1.6F;
            if (bannerT < 12) k *= 0.8F + bannerT / 60F;
            big(g, banner, 110, s.phase == PH_END ? 48 : 40, k, bannerCol);
        }
    }

    private void dim(GuiGraphics g, boolean arena) {
        backdrop(g);
        if (arena) stage(g, true);
        rect(g, 0, 0, W, H, arena ? 0x66101030 : 0x88101030);
    }

    private void card(GuiGraphics g, int i, int x, int y, boolean hov, boolean showFighter, int weapon) {
        rect(g, x, y, 49, 58, hov ? 0xAA2A2A66 : 0x88101030);
        rect(g, x, y, 49, 2, BODY[i]);
        rect(g, x, y, 1, 58, fade(BODY[i], 0.5F)); rect(g, x + 48, y, 1, 58, fade(BODY[i], 0.5F));
        if (showFighter) {
            Fighter p = preview[i];
            p.face = i < 2 ? 1 : -1; p.ground = true; p.vx = 0; p.anim = ticks + i * 20; p.weapon = weapon;
            p.invT = 0; p.flash = 0; p.hitT = 0; p.frozenT = 0;
            int t = (ticks + i * 25) % 90;
            fighter(g, p, x + 24, y + 38, t < 6 ? 6 - t : 0);
        }
    }

    private void renderMenu(GuiGraphics g) {
        dim(g, true);
        ctextW(g, tr("cutemod.game.mayhem"), 111, 5, 200, 0xAA000000);
        ctextW(g, tr("cutemod.game.mayhem"), 110, 4, 200, 0xFFFFE27A);
        ctextW(g, tr("cutemod.mayhem.tip"), 110, 16, 210, 0xFFFFFFFF);
        int[] show = {PISTOL, SMG, SHOTGUN, ROCKET};
        for (int i = 0; i < N; i++) {
            int cx = 8 + i * 53;
            card(g, i, cx, 28, in(mx, my, cx, 28, 49, 58), true, show[i]);
            int m = mode[i];
            String lab = m == 1 ? tr("cutemod.mayhem.p1") : m == 2 ? tr("cutemod.mayhem.p2") : tr("cutemod.mayhem.bot");
            ctextW(g, lab, cx + 24, 73, 45, m == 0 ? 0xFFC8C8E8 : LIGHT[i]);
            ctextW(g, tr("cutemod.mayhem.c." + i), cx + 24, 32, 45, 0xFFFFFFFF);
        }
        button(g, 8, 92, 100, 14, tr("cutemod.mayhem.lives", lives));
        button(g, 112, 92, 100, 14, tr("cutemod.mayhem.skill", tr("cutemod.mayhem.skill." + skill)));
        boolean hs = in(mx, my, 8, 110, 100, 16);
        rect(g, 8, 110, 100, 16, hs ? 0xFFFFE27A : 0xFFF2B33D);
        rect(g, 8, 124, 100, 2, 0xFFC48A1E);
        ctextW(g, tr("cutemod.mayhem.start"), 58, 114, 90, 0xFF3A2A0A);
        boolean ho = in(mx, my, 112, 110, 100, 16);
        rect(g, 112, 110, 100, 16, ho ? 0xFFB5F0C0 : 0xFF86D69A);
        rect(g, 112, 124, 100, 2, 0xFF4FA066);
        ctextW(g, tr("cutemod.mayhem.online"), 162, 114, 90, 0xFF123A20);
        ctextW(g, tr("cutemod.mayhem.keys"), 110, 129, 214, 0xFFE0E0FF);
    }

    private void renderRooms(GuiGraphics g) {
        dim(g, false);
        button(g, 4, 4, 30, 12, "<");
        ctextW(g, tr("cutemod.mayhem.rooms"), 88, 6, 100, 0xFFFFE27A);
        button(g, 140, 3, 76, 14, tr("cutemod.mayhem.create"));
        int rows = Math.min(MayhemNet.hosts.size(), 5);
        if (rows == 0) {
            ctextW(g, tr("cutemod.mayhem.rooms.none"), W / 2, 62, W - 24, 0xFFC9BEE8);
            return;
        }
        for (int i = 0; i < rows; i++) {
            int y = 24 + i * 20;
            boolean hover = in(mx, my, 8, y, 204, 18);
            rect(g, 8, y, 204, 18, hover ? 0xCC3A3A8A : 0xAA202058);
            disc(g, 18, y + 9, 5, SHADE[i % 4]); disc(g, 18, y + 9, 4, BODY[i % 4]);
            rect(g, 17, y + 7, 1, 2, 0xFFFFFFFF); rect(g, 20, y + 7, 1, 2, 0xFFFFFFFF);
            String host = MayhemNet.hosts.get(i);
            ctextW(g, host, 28 + Math.min(tw(host), 90) / 2, y + 5, 90, 0xFFFFFFFF);
            String free = tr("cutemod.mayhem.free", MayhemNet.open.get(i));
            text(g, free, 150 - tw(free), y + 5, 0xFFD6CBF2);
            rect(g, 156, y + 3, 50, 12, 0xFFFFD866);
            ctextW(g, tr("cutemod.mayhem.join"), 181, y + 5, 44, 0xFF3A2A10);
        }
    }

    private void chip(GuiGraphics g, int x, int y, int w, int h, String s, boolean on) {
        boolean hov = in(mx, my, x, y, w, h);
        rect(g, x, y, w, h, on ? 0xFFFFD866 : hov ? 0xCC3A3A8A : 0xAA202058);
        ctextW(g, s, x + w / 2, y + (h - 8) / 2 + 1, w - 4, on ? 0xFF3A2A10 : 0xFFE8E0FF);
    }

    private void renderRoom(GuiGraphics g) {
        dim(g, false);
        button(g, 4, 4, 38, 12, tr("cutemod.mayhem.leave"));
        ctextW(g, tr("cutemod.mayhem.room", MayhemNet.slotName[0]), 130, 6, 160, 0xFFFFE27A);
        for (int i = 0; i < N; i++) {
            int x = 8 + i * 53, y = 20, t = MayhemNet.slotType[i];
            boolean click = MayhemNet.youHost && i > 0;
            card(g, i, x, y, click && in(mx, my, x, y, 49, 58), t == 2 || t == 3, PISTOL);
            if (t != 2 && t != 3) {
                disc(g, x + 24, y + 26, 10, 0x30FFFFFF);
                ctextW(g, t == 1 ? "?" : "-", x + 24, y + 22, 20, 0xFFC9BEE8);
            }
            String label = t == 3 ? MayhemNet.slotName[i] : tr("cutemod.mayhem.slot." + t);
            ctextW(g, label, x + 24, y + 46, 45, t == 3 ? 0xFFFFFFFF : 0xFFD6CBF2);
            if (i == 0) text(g, "*", x + 41, y + 5, 0xFFFFE27A);
        }
        if (MayhemNet.youHost) {
            text(g, tr("cutemod.mayhem.bots_label"), 14, 84, 0xFFE8E0FF);
            for (int i = 0; i < 3; i++) chip(g, 70 + i * 46, 82, 44, 12, tr("cutemod.mayhem.skill." + i), MayhemNet.level == i);
            text(g, tr("cutemod.mayhem.lives_label"), 14, 98, 0xFFE8E0FF);
            int[] lv = {2, 3, 5};
            for (int i = 0; i < 3; i++) chip(g, 70 + i * 34, 96, 30, 12, Integer.toString(lv[i]), MayhemNet.lives == lv[i]);
            button(g, 40, 111, 140, 14, tr("cutemod.mayhem.start"));
            ctextW(g, tr("cutemod.mayhem.slot_hint"), W / 2, 129, 214, 0xFFC9BEE8);
        } else {
            ctextW(g, tr("cutemod.mayhem.wait"), W / 2, 90, 200, 0xFFC9BEE8);
            ctextW(g, tr("cutemod.mayhem.skill_is", tr("cutemod.mayhem.skill." + MayhemNet.level)), W / 2, 104, 200, 0xFFC9BEE8);
            ctextW(g, tr("cutemod.mayhem.lives_is", MayhemNet.lives), W / 2, 116, 200, 0xFFC9BEE8);
        }
    }

    // ------------------------------------------------------------------ the rest of the MiniGame contract

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        MayhemSim s = S();
        if (s.winner < 0) return Component.translatable("cutemod.mayhem.draw");
        if (s.winner == me()) return Component.translatable("cutemod.mayhem.victory");
        return Component.translatable("cutemod.mayhem.winner", tr("cutemod.mayhem.c." + s.winner));
    }

    @Override
    public Component status() {
        if (screen != PLAY) return Component.translatable("cutemod.ui.score", score);
        Fighter m = S().f[me()];
        return Component.translatable("cutemod.mayhem.status", m.kills, Math.max(0, m.lives));
    }

    @Override
    public String hintKey() { return "cutemod.hint.mayhem"; }
}
