package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: something the player did in online Dangerous Weapons.
 * action: 0 refresh (rooms, my room), 1 make a room, 2 join the room of {@code name}, 3 leave the room (or the round),
 * 4 the host clicks slot {@code a} (1..3: open -> computer -> empty; a person in it is sent away), 5 the host picks the skill of the
 * computer players {@code a} (0..2), 6 the host starts a round (or the next one), 8 the host picks the lives {@code a} (2, 3 or 5),
 * 7 what I do: {@code a} = the keys I hold (left 1, right 2, down 4, fire 8, jump 16), {@code b} = what I pressed since the last
 * message (1 jump, 2 fire), so a short tap is never lost.
 */
public record MayhemActionPayload(int action, int a, int b, String name) implements CustomPacketPayload {
    public static final Type<MayhemActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "mayhem_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, MayhemActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, MayhemActionPayload::action,
            ByteBufCodecs.VAR_INT, MayhemActionPayload::a,
            ByteBufCodecs.VAR_INT, MayhemActionPayload::b,
            ByteBufCodecs.stringUtf8(32), MayhemActionPayload::name,
            MayhemActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(MayhemActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) MayhemServer.handle(sp, p); });
    }
}
