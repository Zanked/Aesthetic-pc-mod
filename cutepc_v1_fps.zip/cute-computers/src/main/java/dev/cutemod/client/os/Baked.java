package dev.cutemod.client.os;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A speed-up for pictures made of many small rectangles. Every rectangle drawn with {@code GuiGraphics.fill} is a separate draw
 * call, and a book page needs hundreds of them every frame. Here the same drawing is done once into a small picture in memory
 * (a {@link Canvas}), uploaded as a texture, and every frame after that the whole picture is one textured rectangle.
 * <ul>
 * <li>While a picture is being painted, every rectangle that goes through {@link #fill} lands in the canvas instead of on the
 * screen. The code that paints does not change: it uses the same coordinates as before.</li>
 * <li>Still pictures (a table, a cover, the paper of a page) are painted once; moving ones (a scene) are painted again every
 * {@code maxAgeMs}, so the animation keeps going at that rate while the screen runs at any speed.</li>
 * <li>Only rectangles can be painted this way: no text, no item, no pose changes inside a painted picture.</li>
 * <li>If anything goes wrong with the textures, the baking is switched off and everything is drawn directly, as before.</li>
 * </ul>
 * Render thread only.
 */
final class Baked {
    private Baked() {}

    private static final int MAX_TEXTURES = 64;
    private static final Map<String, Tex> CACHE = new LinkedHashMap<>(64, 0.75F, true);
    private static Canvas cap;                                   // the canvas that is being painted now, null = painting on the screen
    private static boolean broken;
    private static int serial;

    // ---------- the one place where a rectangle is drawn ----------

    /** Draws a rectangle on the screen, or into the picture that is being painted. Same arguments as {@code GuiGraphics.fill}. */
    static void fill(GuiGraphics g, int x0, int y0, int x1, int y1, int argb) {
        if (cap != null) cap.rect(x0, y0, x1, y1, argb);
        else g.fill(x0, y0, x1, y1, argb);
    }

    // ---------- baked pictures ----------

    /** A picture that does not move: it is painted once (until it falls out of the cache). (rx, ry) = its top left corner. */
    static void draw(GuiGraphics g, String key, int rx, int ry, int w, int h, Runnable paint) {
        draw(g, key, rx, ry, w, h, 0L, null, paint);
    }

    /** A picture that moves: it is painted again when it is older than maxAgeMs. */
    static void drawLive(GuiGraphics g, String key, int rx, int ry, int w, int h, long maxAgeMs, Runnable paint) {
        draw(g, key, rx, ry, w, h, maxAgeMs, null, paint);
    }

    /** A picture painted in white or any colour and shown through a colour and a strength: tint = {red, green, blue, alpha} (0..n). */
    static void drawTinted(GuiGraphics g, String key, int rx, int ry, int w, int h, float[] tint, Runnable paint) {
        draw(g, key, rx, ry, w, h, 0L, tint, paint);
    }

    private static void draw(GuiGraphics g, String key, int rx, int ry, int w, int h, long maxAgeMs, float[] tint, Runnable paint) {
        if (cap != null || broken || w <= 0 || h <= 0) { paint.run(); return; }       // inside another picture: just paint into it
        try {
            Tex t = CACHE.get(key);
            if (t != null && (t.w != w || t.h != h)) { CACHE.remove(key); t.release(); t = null; }
            if (t == null) {
                t = new Tex(w, h);
                CACHE.put(key, t);
                evict();
            }
            long now = System.currentTimeMillis();
            if (!t.ready || (maxAgeMs > 0 && now - t.stamp >= maxAgeMs)) {
                t.canvas.clear();
                t.canvas.ox = rx;
                t.canvas.oy = ry;
                cap = t.canvas;
                try { paint.run(); } finally { cap = null; }
                t.upload();
                t.ready = true;
                t.stamp = now;
            }
            if (tint != null) g.setColor(tint[0], tint[1], tint[2], tint[3]);
            try {
                g.blit(t.loc, rx, ry, 0F, 0F, w, h, w, h);
            } finally {
                if (tint != null) g.setColor(1F, 1F, 1F, 1F);
            }
        } catch (RuntimeException e) {
            broken = true;                                                            // no textures: draw everything directly from now on
            cap = null;
            paint.run();
        }
    }

    private static void evict() {
        while (CACHE.size() > MAX_TEXTURES) {
            Iterator<Map.Entry<String, Tex>> it = CACHE.entrySet().iterator();
            Tex old = it.next().getValue();
            it.remove();
            old.release();
        }
    }

    // ---------- the picture in memory ----------

    /** A w x h picture of ARGB pixels. (ox, oy) = the screen position of its top left corner, so the painting code can use screen coordinates. */
    static final class Canvas {
        final int w, h;
        final int[] px;
        int ox, oy;

        Canvas(int w, int h) { this.w = w; this.h = h; this.px = new int[w * h]; }

        void clear() { java.util.Arrays.fill(px, 0); }

        /** Like GuiGraphics.fill: [x0, x1) x [y0, y1), the colour is laid over what is there (by its alpha). */
        void rect(int x0, int y0, int x1, int y1, int c) {
            if (x0 > x1) { int t = x0; x0 = x1; x1 = t; }
            if (y0 > y1) { int t = y0; y0 = y1; y1 = t; }
            x0 = Math.max(0, x0 - ox); x1 = Math.min(w, x1 - ox);
            y0 = Math.max(0, y0 - oy); y1 = Math.min(h, y1 - oy);
            if (x1 <= x0 || y1 <= y0) return;
            int sa = c >>> 24;
            if (sa == 0) return;
            if (sa == 255) {
                for (int y = y0; y < y1; y++) java.util.Arrays.fill(px, y * w + x0, y * w + x1, c);
                return;
            }
            for (int y = y0; y < y1; y++) {
                int i = y * w + x0;
                for (int x = x0; x < x1; x++, i++) px[i] = over(px[i], c, sa);
            }
        }

        /** src (alpha sa, 1..254) laid over dst. */
        static int over(int dst, int src, int sa) {
            int da = dst >>> 24;
            if (da == 0) return src;
            int ia = 255 - sa;
            if (da == 255) {
                int r = ((src >> 16 & 255) * sa + (dst >> 16 & 255) * ia) / 255;
                int g = ((src >> 8 & 255) * sa + (dst >> 8 & 255) * ia) / 255;
                int b = ((src & 255) * sa + (dst & 255) * ia) / 255;
                return 0xFF000000 | r << 16 | g << 8 | b;
            }
            int oa = sa + da * ia / 255;
            if (oa <= 0) return 0;
            int wd = da * ia;                                                         // the weight of what was there
            int ws = sa * 255;                                                        // the weight of the new colour
            int den = oa * 255;
            int r = ((src >> 16 & 255) * ws + (dst >> 16 & 255) * wd) / den;
            int g = ((src >> 8 & 255) * ws + (dst >> 8 & 255) * wd) / den;
            int b = ((src & 255) * ws + (dst & 255) * wd) / den;
            return oa << 24 | Math.min(255, r) << 16 | Math.min(255, g) << 8 | Math.min(255, b);
        }
    }

    private static final class Tex {
        final int w, h;
        final Canvas canvas;
        final DynamicTexture tex;
        final ResourceLocation loc;
        long stamp;
        boolean ready;

        Tex(int w, int h) {
            this.w = w;
            this.h = h;
            this.canvas = new Canvas(w, h);
            this.tex = new DynamicTexture(new NativeImage(NativeImage.Format.RGBA, w, h, true));
            this.loc = ResourceLocation.fromNamespaceAndPath("cutemod", "baked/" + (serial++));
            Minecraft.getInstance().getTextureManager().register(loc, tex);
        }

        void upload() {
            NativeImage img = tex.getPixels();
            if (img == null) return;
            int[] p = canvas.px;
            for (int y = 0, i = 0; y < h; y++) {
                for (int x = 0; x < w; x++, i++) {
                    int c = p[i];
                    img.setPixelRGBA(x, y, (c & 0xFF00FF00) | (c >> 16 & 255) | (c & 255) << 16);   // ARGB -> ABGR
                }
            }
            tex.upload();
        }

        void release() { Minecraft.getInstance().getTextureManager().release(loc); }
    }
}
