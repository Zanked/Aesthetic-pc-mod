package dev.cutemod.data;

import java.util.Random;
import java.util.UUID;

/**
 * A dance duel between two players (pure rules, no Minecraft classes): in every round both pick a move in secret.
 * Spin beats Wave, Wave beats Jump, Jump beats Spin; the Showstopper beats every other move but can be used once
 * per duel (two Showstoppers tie). First to {@value #WIN_AT} round wins, or the better score after {@value #MAX_ROUNDS}
 * rounds (equal = a draw). A player who does not pick in time gets a random normal move.
 */
public final class DuelMatch {
    public static final int SPIN = 0, JUMP = 1, WAVE = 2, STAR = 3;
    public static final int WIN_AT = 3, MAX_ROUNDS = 7;
    public static final long PICK_MS = 20_000L;

    public final UUID a, b;
    public final int[] score = new int[2];
    public final boolean[] starUsed = new boolean[2];
    private final int[] pick = {-1, -1};
    /** The round being played (starts at 1). */
    public int round = 1;
    /** 0 playing, 1 a won, 2 b won, 3 draw. */
    public int result;
    /** Goes up every time a round has been settled. */
    public int seq;
    /** The moves of the last settled round and who won it (0 tie, 1 a, 2 b; -1 = no round yet). */
    public final int[] prevPick = {-1, -1};
    public int prevOutcome = -1;
    public long deadline;
    private final Random rnd = new Random();

    public DuelMatch(UUID a, UUID b, long now) {
        this.a = a;
        this.b = b;
        this.deadline = now + PICK_MS;
    }

    public int index(UUID id) { return id.equals(a) ? 0 : id.equals(b) ? 1 : -1; }

    public UUID other(UUID id) { return id.equals(a) ? b : a; }

    public boolean picked(UUID id) { int i = index(id); return i >= 0 && pick[i] >= 0; }

    /** 0 tie, 1 x wins, 2 y wins. */
    public static int outcome(int x, int y) {
        if (x == y) return 0;
        if (x == STAR) return 1;
        if (y == STAR) return 2;
        boolean xw = (x == SPIN && y == WAVE) || (x == WAVE && y == JUMP) || (x == JUMP && y == SPIN);
        return xw ? 1 : 2;
    }

    /** Pick a move. False if it is not allowed (finished, unknown move, a second Showstopper, already picked, a stranger). */
    public boolean pick(UUID who, int move, long now) {
        int i = index(who);
        if (i < 0 || result != 0 || move < 0 || move > STAR || pick[i] >= 0) return false;
        if (move == STAR && starUsed[i]) return false;
        pick[i] = move;
        if (pick[0] >= 0 && pick[1] >= 0) settle(now);
        return true;
    }

    /** Settles a round whose time has run out. True if something changed. */
    public boolean tick(long now) {
        if (result != 0 || now < deadline) return false;
        for (int i = 0; i < 2; i++) if (pick[i] < 0) pick[i] = rnd.nextInt(3);
        settle(now);
        return true;
    }

    private void settle(long now) {
        int o = outcome(pick[0], pick[1]);
        for (int i = 0; i < 2; i++) if (pick[i] == STAR) starUsed[i] = true;
        prevPick[0] = pick[0]; prevPick[1] = pick[1];
        prevOutcome = o;
        if (o == 1) score[0]++; else if (o == 2) score[1]++;
        pick[0] = pick[1] = -1;
        seq++;
        if (score[0] >= WIN_AT) result = 1;
        else if (score[1] >= WIN_AT) result = 2;
        else if (round >= MAX_ROUNDS) result = score[0] > score[1] ? 1 : score[1] > score[0] ? 2 : 3;
        else { round++; deadline = now + PICK_MS; }
    }

    /** A player gives up: the other one wins. */
    public void resign(UUID who) {
        int i = index(who);
        if (i >= 0 && result == 0) result = i == 0 ? 2 : 1;
    }
}
