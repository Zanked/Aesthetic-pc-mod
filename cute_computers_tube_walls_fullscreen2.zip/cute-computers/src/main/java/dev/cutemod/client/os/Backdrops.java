package dev.cutemod.client.os;

import java.util.Map;

/**
 * The background of every app: while an app is open, the window, the menu bar and the Dock sit on the app's own colour
 * (a soft gradient) instead of the desktop wallpaper. An app can choose its own by overriding {@link App#backdrop()}
 * (the browser does it per site); the others get the colour from this table, found by the class name.
 */
public final class Backdrops {
    private Backdrops() {}

    private static final int FALLBACK = 0xFF5B4B8A;

    private static final Map<String, Integer> BY_APP = Map.ofEntries(
            Map.entry("BankApp", 0xFF2F7D5B), Map.entry("BeatApp", 0xFF7A3FB0), Map.entry("BrowserApp", 0xFF4A6FD0),
            Map.entry("CalcApp", 0xFF4A4F63), Map.entry("ExplorerApp", 0xFF3F7FA8), Map.entry("FarmApp", 0xFF5E9B3A),
            Map.entry("FishingApp", 0xFF2F6FA8), Map.entry("FolderApp", 0xFF5B7FC4), Map.entry("GameApp", 0xFF8A4FB8),
            Map.entry("GiftApp", 0xFFD05A7A), Map.entry("HalloweenApp", 0xFFC8661E), Map.entry("JobsApp", 0xFF6A6F7A),
            Map.entry("KitApp", 0xFF5A8A9A), Map.entry("MailApp", 0xFFE0A030), Map.entry("MarketApp", 0xFFE88AB8),
            Map.entry("MusicApp", 0xFFB04A8F), Map.entry("NetApp", 0xFF3A8F8A), Map.entry("NotepadApp", 0xFFD8B84A),
            Map.entry("PaintApp", 0xFFE06A4A), Map.entry("PetApp", 0xFFF09AB8), Map.entry("PetStatsApp", 0xFFC87AA8),
            Map.entry("PhotoApp", 0xFF5A6FA0), Map.entry("QuestApp", 0xFF8A6A3A), Map.entry("QuizApp", 0xFF4AA0C8),
            Map.entry("RadioApp", 0xFF7A5A9A), Map.entry("RepairApp", 0xFF7A8088), Map.entry("SeasonApp", 0xFF6AAA5A),
            Map.entry("SettingsApp", 0xFF7A7F90), Map.entry("StickersApp", 0xFFE87AA0), Map.entry("StoreApp", 0xFF4AA860),
            Map.entry("StyleApp", 0xFFB86AC8), Map.entry("TalesApp", 0xFF6A4A8A), Map.entry("TerminalApp", 0xFF1E2A22),
            Map.entry("TicTacApp", 0xFF5A9AD0), Map.entry("TubeApp", 0xFFC4302B), Map.entry("WeatherApp", 0xFF5AA0E0),
            Map.entry("WheelApp", 0xFFE0703A), Map.entry("WishApp", 0xFFE0B04A));

    /** The colour of an app's background (opaque ARGB). */
    public static int of(App app) {
        int own = app.backdrop();
        if (own != 0) return own;
        Integer c = BY_APP.get(app.getClass().getSimpleName());
        return c != null ? c : FALLBACK;
    }

    /** The bottom of the gradient: the same colour, darker. */
    public static int darker(int argb) {
        int r = (argb >> 16 & 255) * 62 / 100, g = (argb >> 8 & 255) * 62 / 100, b = (argb & 255) * 62 / 100;
        return 0xFF000000 | r << 16 | g << 8 | b;
    }
}
