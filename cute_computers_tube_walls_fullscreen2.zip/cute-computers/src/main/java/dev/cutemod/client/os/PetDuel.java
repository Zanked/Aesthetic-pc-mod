package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/**
 * The dance duel screen of the Tamagotchi app: a lobby (who is free, challenges) and the duel itself.
 * Moves: Spin beats Wave, Wave beats Jump, Jump beats Spin; the Showstopper beats everything but can be used once.
 * First to 3 round wins. The server decides everything; this class draws and sends the picks.
 */
final class PetDuel {
    private static final int W = App.W, H = App.H;
    private static final int DARK = 0xFF3A2A3A;
    private static final int[] MOVE_COL = {0xFFFF9EC4, 0xFF9ED8FF, 0xFFB6F0A0, 0xFFFFD84A};
    private static final String[] MOVE_KEY = {"cutemod.duel.spin", "cutemod.duel.jump", "cutemod.duel.wave", "cutemod.duel.star"};
    private static final int WIN = 8, DRAW = 4, LOSE = 2, DAILY_CAP = 40;

    private final String myColor;
    private final Runnable back;
    private final int variant;
    private int ticks, revealT, seenRound = -1, seenVersion = -1, noticeT, resignArm, rewarded;
    private String noticeText = "";
    private boolean paid;
    private int prize;

    PetDuel(String myColor, Runnable back, dev.cutemod.net.PetLook mine) {
        this.myColor = myColor;
        this.back = back;
        this.variant = mine.variant();
        Duel.setPet(myColor, mine);
    }

    void open() {
        Duel.request();
    }

    void close() {
        if (Duel.inMatch()) Duel.leave();
        else if (!Duel.invitedTo.isEmpty()) Duel.cancelInvite();
    }

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    private static boolean in(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    void tick() {
        ticks++;
        if (revealT > 0) revealT--;
        if (noticeT > 0) noticeT--;
        if (resignArm > 0) resignArm--;
        if (Duel.version != seenVersion) {
            seenVersion = Duel.version;
            int n = Duel.takeNotice();
            if (n != 0) { noticeText = t("cutemod.duel.notice." + n); noticeT = 100; }
            int[] g = Duel.game;
            if (Duel.inMatch() && g[12] != seenRound) {
                if (seenRound >= 0 && g[7] >= 0) revealT = 70;
                seenRound = g[12];
            }
            if (!Duel.inMatch()) { seenRound = -1; paid = false; }
            if (Duel.inMatch() && g[11] != 0 && !paid) pay(g[11]);
        }
        if (!Duel.inMatch() && ticks % 120 == 0) Duel.request();
        if (Duel.inMatch() && Duel.game[11] == 0 && ticks % 20 == 0) { /* the countdown is shown from the server value */ }
    }

    private void pay(int res) {
        paid = true;
        int today = (int) (System.currentTimeMillis() / 86_400_000L);
        if (Progress.count("duel_day") != today) { Progress.setCount("duel_day", today); Progress.setCount("duel_got", 0); }
        int base = res == 1 ? WIN : res == 3 ? DRAW : LOSE;
        int got = Progress.count("duel_got");
        prize = Math.max(0, Math.min(base, DAILY_CAP - got));
        if (prize > 0) { Progress.earn(prize); Progress.setCount("duel_got", got + prize); }
        if (res == 1) Progress.bump("duel_wins");
    }

    // ---------- drawing ----------
    void render(GuiGraphics g, int mx, int my) {
        Font f = Minecraft.getInstance().font;
        rect(g, 0, 0, W, H, 0xFF2B2140);
        for (int i = 0; i < 20; i++) rect(g, (i * 37 + ticks / 2) % W, (i * 23) % 90, 2, 2, (i + ticks / 12) % 3 == 0 ? 0xFFFFE9A8 : 0x66FFFFFF);
        rect(g, 0, 118, W, H - 118, 0xFF4A3466);
        rect(g, 0, 118, W, 2, 0xFF8A64B8);
        boolean bh = in(mx, my, 4, 4, 38, 12);
        rect(g, 4, 4, 38, 12, bh ? 0xFFFFFFFF : 0xFFF6F0FA);
        Skin.str(g, f, t("cutemod.duel.back"), 8, 6, DARK, false);
        if (Duel.inMatch()) renderMatch(g, f, mx, my); else renderLobby(g, f, mx, my);
        if (noticeT > 0) {
            int w = f.width(noticeText) + 10;
            rect(g, (W - w) / 2, 22, w, 12, 0xEEFFF3B0);
            Skin.str(g, f, noticeText, (W - w) / 2 + 5, 24, DARK, false);
        }
    }

    private void renderLobby(GuiGraphics g, Font f, int mx, int my) {
        Skin.cstr(g, f, t("cutemod.duel.title"), W / 2, 6, 0xFFFFE9A8);
        Skin.cstr(g, f, t("cutemod.duel.sub"), W / 2, 36, 0xFFC9B8E8);
        int y = 48;
        if (Duel.players.isEmpty()) Skin.cstr(g, f, t("cutemod.duel.none"), W / 2, 70, 0xFFC9B8E8);
        int shown = 0;
        for (String n : Duel.players) {
            if (shown++ >= 5) break;
            rect(g, 20, y, 260, 13, 0x33FFFFFF);
            Skin.str(g, f, n, 26, y + 3, 0xFFFFFFFF, false);
            boolean h = in(mx, my, 230, y + 1, 46, 11);
            boolean sent = n.equals(Duel.invitedTo);
            rect(g, 230, y + 1, 46, 11, sent ? 0xFFB9A8C8 : h ? 0xFFFFF3B0 : 0xFFFFE9A8);
            Skin.cstr(g, f, t(sent ? "cutemod.duel.sent" : "cutemod.duel.invite"), 253, y + 3, DARK);
            y += 14;
        }
        if (!Duel.invitedBy.isEmpty()) {
            rect(g, 10, 124, 280, 36, 0xFF6A4A92);
            Skin.str(g, f, t("cutemod.duel.challenge", Duel.invitedBy), 16, 128, 0xFFFFFFFF, false);
            drawBtn(g, f, 16, 142, 70, 13, t("cutemod.duel.accept"), 0xFFB6F0A0, mx, my);
            drawBtn(g, f, 92, 142, 70, 13, t("cutemod.duel.decline"), 0xFFFFB0B0, mx, my);
        } else if (!Duel.invitedTo.isEmpty()) {
            rect(g, 10, 124, 280, 36, 0xFF6A4A92);
            Skin.str(g, f, t("cutemod.duel.waiting", Duel.invitedTo), 16, 128, 0xFFFFFFFF, false);
            drawBtn(g, f, 16, 142, 70, 13, t("cutemod.duel.cancel"), 0xFFFFB0B0, mx, my);
        }
    }

    private void drawBtn(GuiGraphics g, Font f, int x, int y, int w, int h, String s, int col, int mx, int my) {
        boolean hov = in(mx, my, x, y, w, h);
        rect(g, x, y, w, h, hov ? 0xFFFFFFFF : col);
        rect(g, x, y + h - 2, w, 2, 0x33000000);
        Skin.cstr(g, f, s, x + w / 2, y + 3, DARK);
    }

    private void pet(GuiGraphics g, ComputerColor c, int v, int cx, int cy, dev.cutemod.net.PetLook l, boolean me, int dance) {
        int bob = (int) Math.round(Math.sin((ticks + (me ? 0 : 7)) / 4.0) * (dance > 0 ? 4 : 1));
        if (me) PetArt.draw(g, c, cx, cy - 6 + bob, 2, ticks, false, false, l.stage(), l.head(), l.body());
        else PetArt.draw(g, c, v, cx, cy - 6 + bob, 2, ticks, false, false, l.stage(), l.head(), l.body());
    }

    private void renderMatch(GuiGraphics g, Font f, int mx, int my) {
        int[] s = Duel.game;
        ComputerColor mc = PetShow.colorOf(myColor), oc = PetShow.colorOf(Duel.oppColor);
        dev.cutemod.net.PetLook ol = Duel.oppLook;
        // scores
        Skin.str(g, f, t("cutemod.duel.you"), 50, 6, 0xFFFFFFFF, false);
        String on = Duel.opponent;
        Skin.str(g, f, on, 290 - f.width(on), 6, 0xFFFFFFFF, false);
        for (int i = 0; i < 3; i++) {
            disc(g, 52 + i * 12, 24, 4, i < s[0] ? 0xFFFFD84A : 0x55FFFFFF);
            disc(g, 248 - i * 12, 24, 4, i < s[1] ? 0xFFFFD84A : 0x55FFFFFF);
        }
        boolean over = s[11] != 0;
        Skin.cstr(g, f, t("cutemod.duel.round", Math.min(s[2], 7)), W / 2, 6, 0xFFFFE9A8);
        if (!over) {
            int left = Math.max(0, s[10]);
            rect(g, 110, 20, 80, 5, 0x55FFFFFF);
            rect(g, 110, 20, 80 * Math.min(20, left) / 20, 5, left <= 5 ? 0xFFFF7A7A : 0xFFB6F0A0);
        }
        boolean reveal = revealT > 0 && s[7] >= 0;
        pet(g, mc, 0, 80, 100, mePetLook(), true, reveal || over ? 1 : 0);
        pet(g, oc, ol.variant(), 220, 100, ol, false, reveal || over ? 1 : 0);
        Skin.cstr(g, f, "VS", W / 2, 70, 0xFFFFE9A8);
        if (reveal) {
            moveBadge(g, f, 80, 52, s[5]);
            moveBadge(g, f, 220, 52, s[6]);
            String r = s[7] == 0 ? t("cutemod.duel.tie") : s[7] == 1 ? t("cutemod.duel.rwin") : t("cutemod.duel.rlose");
            Skin.cstr(g, f, r, W / 2, 86, s[7] == 1 ? 0xFFB6F0A0 : s[7] == 2 ? 0xFFFF9E9E : 0xFFFFFFFF);
        } else if (!over) {
            if (s[3] == 1) Skin.cstr(g, f, t("cutemod.duel.picked"), 80, 52, 0xFFB6F0A0);
            if (s[4] == 1) Skin.cstr(g, f, "?", 220, 56, 0xFFFFE9A8);
        }
        if (over) {
            int res = s[11];
            rect(g, 60, 40, 180, 54, 0xEE2B2140);
            String h = res == 1 ? t("cutemod.duel.win") : res == 2 ? t("cutemod.duel.lose") : t("cutemod.duel.draw");
            Skin.cstr(g, f, h, W / 2, 46, res == 1 ? 0xFFFFD84A : 0xFFFFFFFF);
            Skin.cstr(g, f, s[0] + " : " + s[1], W / 2, 60, 0xFFFFFFFF);
            Skin.cstr(g, f, prize > 0 ? t("cutemod.duel.prize", prize) : t("cutemod.duel.cap"), W / 2, 74, 0xFFFFE9A8);
            drawBtn(g, f, 110, 120, 80, 14, t("cutemod.duel.leave"), 0xFFFFE9A8, mx, my);
            return;
        }
        // move buttons
        for (int i = 0; i < 4; i++) {
            int x = 8 + i * 72;
            boolean free = i < 3 || s[8] == 1;
            boolean h = in(mx, my, x, 124, 68, 18) && free && s[3] == 0;
            rect(g, x, 124, 68, 18, !free ? 0xFF55466E : s[3] == 1 ? 0xFF6E5A8C : h ? 0xFFFFFFFF : MOVE_COL[i]);
            rect(g, x, 140, 68, 2, 0x33000000);
            Skin.cstr(g, f, t(MOVE_KEY[i]), x + 34, 129, DARK);
        }
        Skin.cstr(g, f, s[3] == 1 ? t("cutemod.duel.waitopp") : t("cutemod.duel.choose"), W / 2, 146, 0xFFC9B8E8);
        boolean rh = in(mx, my, 246, 4, 50, 12);
        rect(g, 246, 4, 50, 12, resignArm > 0 ? 0xFFFF7A7A : rh ? 0xFFFFFFFF : 0xFFF6F0FA);
        Skin.cstr(g, f, t(resignArm > 0 ? "cutemod.duel.sure" : "cutemod.duel.resign"), 271, 6, DARK);
    }

    private dev.cutemod.net.PetLook mePetLook() { return mine; }

    private dev.cutemod.net.PetLook mine;

    void setMine(dev.cutemod.net.PetLook l) { mine = l; }

    private void moveBadge(GuiGraphics g, Font f, int cx, int y, int mv) {
        if (mv < 0 || mv > 3) return;
        String s = t(MOVE_KEY[mv]);
        int w = f.width(s) + 10;
        rect(g, cx - w / 2, y, w, 12, MOVE_COL[mv]);
        Skin.cstr(g, f, s, cx, y + 2, DARK);
    }

    // ---------- input ----------
    boolean click(int x, int y) {
        if (in(x, y, 4, 4, 38, 12)) { close(); back.run(); return true; }
        if (Duel.inMatch()) {
            int[] s = Duel.game;
            if (s[11] != 0) {
                if (in(x, y, 110, 120, 80, 14)) Duel.leave();
                return true;
            }
            if (in(x, y, 246, 4, 50, 12)) {
                if (resignArm > 0) { Duel.leave(); resignArm = 0; } else resignArm = 60;
                return true;
            }
            for (int i = 0; i < 4; i++) {
                if (in(x, y, 8 + i * 72, 124, 68, 18) && s[3] == 0 && (i < 3 || s[8] == 1)) { Duel.pick(i); break; }
            }
            return true;
        }
        int yy = 48, shown = 0;
        for (String n : Duel.players) {
            if (shown++ >= 5) break;
            if (in(x, y, 230, yy + 1, 46, 11) && !n.equals(Duel.invitedTo)) { Duel.invite(n); return true; }
            yy += 14;
        }
        if (!Duel.invitedBy.isEmpty()) {
            if (in(x, y, 16, 142, 70, 13)) Duel.accept(Duel.invitedBy);
            else if (in(x, y, 92, 142, 70, 13)) Duel.decline();
        } else if (!Duel.invitedTo.isEmpty() && in(x, y, 16, 142, 70, 13)) Duel.cancelInvite();
        return true;
    }

    boolean key(int keyCode) {
        if (keyCode == 256) { close(); back.run(); return true; }       // Esc
        return false;
    }
}
