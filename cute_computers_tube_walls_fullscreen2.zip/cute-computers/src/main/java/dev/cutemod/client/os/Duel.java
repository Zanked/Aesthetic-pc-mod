package dev.cutemod.client.os;

import dev.cutemod.net.DuelActionPayload;
import dev.cutemod.net.DuelSyncPayload;
import dev.cutemod.net.PetLook;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** The client side of the pet dance duel: what the server last told us and the messages we send to it. */
public final class Duel {
    private Duel() {}

    public static List<String> players = new ArrayList<>();
    public static String invitedBy = "", invitedTo = "", opponent = "", oppColor = "pink";
    public static PetLook oppLook = new PetLook(1, 0, 30, "", "", "");
    /** my score, their score, round, I picked, they picked, my last move, their last move, last outcome, my star free, their star free, seconds left, result, round counter */
    public static int[] game = new int[13];
    public static int version;
    private static int notice;
    private static long ignoreUntil;

    public static void apply(DuelSyncPayload p) {
        players = new ArrayList<>(p.players());
        invitedBy = p.invitedBy();
        invitedTo = p.invitedTo();
        opponent = System.currentTimeMillis() < ignoreUntil ? "" : p.opponent();
        oppColor = p.oppColor();
        oppLook = p.oppLook();
        int[] g = new int[13];
        for (int i = 0; i < 13 && i < p.game().size(); i++) g[i] = p.game().get(i);
        game = g;
        if (p.notice() != 0) notice = p.notice();
        version++;
    }

    public static void clear() {
        players = new ArrayList<>();
        invitedBy = invitedTo = opponent = "";
        game = new int[13];
        notice = 0;
        version++;
    }

    public static boolean inMatch() { return !opponent.isEmpty(); }

    public static int takeNotice() {
        int n = notice;
        notice = 0;
        return n;
    }

    private static void send(int action, String name, int move, String color, PetLook look) {
        PacketDistributor.sendToServer(new DuelActionPayload(action, name, move, color, look));
    }

    private static String color = "pink";
    private static PetLook look = new PetLook(1, 0, 30, "", "", "");

    /** Remembers how our pet looks right now (it is sent with every message). */
    public static void setPet(String colorId, PetLook l) { color = colorId; look = l; }

    public static void request() { send(0, "", 0, color, look); }
    public static void invite(String name) { send(1, name, 0, color, look); }
    public static void accept(String name) { send(2, name, 0, color, look); }
    public static void decline() { send(3, "", 0, color, look); }
    public static void pick(int move) { send(4, "", move, color, look); }
    public static void cancelInvite() { send(6, "", 0, color, look); }

    /** Give up, or leave a finished duel. We forget it at once; the server confirms later. */
    public static void leave() {
        send(5, "", 0, color, look);
        opponent = "";
        game = new int[13];
        ignoreUntil = System.currentTimeMillis() + 1500;
        version++;
    }
}
