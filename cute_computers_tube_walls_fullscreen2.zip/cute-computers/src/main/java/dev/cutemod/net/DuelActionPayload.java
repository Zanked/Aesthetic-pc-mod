package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: something the player did in the dance duel.
 * action: 0 refresh (who is online, my duel), 1 invite {@code name}, 2 accept the challenge of {@code name}, 3 decline it,
 * 4 pick a move (0 Spin, 1 Jump, 2 Wave, 3 Showstopper), 5 give up / leave the duel, 6 cancel my challenge.
 * color and look are the pet of the player (the opponent sees it); the server only checks them against white lists.
 */
public record DuelActionPayload(int action, String name, int move, String color, PetLook look) implements CustomPacketPayload {
    public static final Type<DuelActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "duel_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, DuelActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, DuelActionPayload::action,
            ByteBufCodecs.stringUtf8(32), DuelActionPayload::name,
            ByteBufCodecs.VAR_INT, DuelActionPayload::move,
            ByteBufCodecs.stringUtf8(16), DuelActionPayload::color,
            PetLook.CODEC, DuelActionPayload::look,
            DuelActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(DuelActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) DuelServer.handle(sp, p); });
    }
}
