package dev.cutemod.net;

import dev.cutemod.data.DuelMatch;
import dev.cutemod.data.PetWear;
import dev.cutemod.data.ShowBoard;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The server side of the dance duel: the list of free players, challenges (they run out after a minute) and the duels.
 * Duels live in memory only. The rules are checked by {@link DuelMatch}; a round that runs out of time is settled by the
 * tick. What a client says about its pet is only checked against white lists (like the talent show).
 */
public final class DuelServer {
    private DuelServer() {}

    private static final long INVITE_MS = 60_000L;
    private record Invite(UUID from, long until) {}
    private record Pet(String color, PetLook look) {}

    private static final Map<UUID, DuelMatch> matches = new HashMap<>();
    private static final Map<UUID, Invite> invites = new HashMap<>();      // key = the player who was challenged
    private static final Map<UUID, Pet> pets = new HashMap<>();
    private static final Map<UUID, Long> lastRequest = new HashMap<>();
    private static MinecraftServer server;
    private static int tickCount;

    private static final PetLook DEFAULT_LOOK = new PetLook(1, 0, 30, "", "", "");

    public static void handle(ServerPlayer sp, DuelActionPayload p) {
        server = sp.getServer();
        if (server == null) return;
        PetLook l = p.look();
        boolean ok = ShowBoard.validColor(p.color()) && l.stage() >= 0 && l.stage() <= 2 && l.trait() >= 0 && l.trait() <= 4
                && l.ageMin() >= 0 && l.ageMin() <= ShowBoard.MAX_AGE_MIN && PetWear.validPacked(l.head(), false) && PetWear.validPacked(l.body(), true);
        pets.put(sp.getUUID(), ok ? new Pet(p.color(), new PetLook(l.stage(), l.trait(), l.ageMin(), l.head(), l.body(), "", Math.max(0, Math.min(3, l.variant())))) : new Pet("pink", DEFAULT_LOOK));
        switch (p.action()) {
            case 0 -> request(sp);
            case 1 -> invite(sp, p.name());
            case 2 -> accept(sp, p.name());
            case 3 -> decline(sp);
            case 4 -> pick(sp, p.move());
            case 5 -> leaveGame(sp.getUUID());
            case 6 -> cancel(sp);
            default -> { }
        }
    }

    /** Called every server tick: settles rounds whose time has run out. */
    public static void tick(MinecraftServer s) {
        if (++tickCount < 10) return;
        tickCount = 0;
        if (matches.isEmpty()) return;
        server = s;
        long now = System.currentTimeMillis();
        List<DuelMatch> seen = new ArrayList<>();
        for (DuelMatch m : new ArrayList<>(matches.values())) {
            if (seen.contains(m)) continue;
            seen.add(m);
            if (m.tick(now)) { pushTo(m.a, 0); pushTo(m.b, 0); }
        }
    }

    private static boolean playing(UUID id) {
        DuelMatch m = matches.get(id);
        return m != null && m.result == 0;
    }

    private static ServerPlayer online(UUID id) { return server == null ? null : server.getPlayerList().getPlayer(id); }

    private static String name(UUID id) {
        ServerPlayer p = online(id);
        return p == null ? "" : p.getGameProfile().getName();
    }

    private static Invite pending(UUID target) {
        Invite i = invites.get(target);
        if (i == null) return null;
        if (System.currentTimeMillis() > i.until()) {
            invites.remove(target);
            ServerPlayer from = online(i.from());
            if (from != null) push(from, 5);
            return null;
        }
        return i;
    }

    /** Sends a player the whole picture (and maybe one notice). */
    private static void push(ServerPlayer sp, int notice) {
        if (server == null) return;
        List<String> free = new ArrayList<>();
        for (ServerPlayer o : server.getPlayerList().getPlayers()) {
            if (o.getUUID().equals(sp.getUUID()) || playing(o.getUUID())) continue;
            free.add(o.getGameProfile().getName());
        }
        free.sort(String.CASE_INSENSITIVE_ORDER);
        String by = "", to = "";
        Invite in = pending(sp.getUUID());
        if (in != null) by = name(in.from());
        for (Map.Entry<UUID, Invite> e : new ArrayList<>(invites.entrySet())) {
            if (e.getValue().from().equals(sp.getUUID()) && pending(e.getKey()) != null) { to = name(e.getKey()); break; }
        }
        DuelMatch m = matches.get(sp.getUUID());
        String opp = "", oppColor = "pink";
        PetLook oppLook = DEFAULT_LOOK;
        List<Integer> game = new ArrayList<>();
        for (int i = 0; i < 13; i++) game.add(0);
        if (m != null) {
            UUID me = sp.getUUID(), ot = m.other(me);
            int mi = m.index(me), oi = 1 - mi;
            opp = name(ot);
            if (opp.isEmpty()) opp = "?";
            Pet op = pets.get(ot);
            if (op != null) { oppColor = op.color(); oppLook = op.look(); }
            int out = m.prevOutcome < 0 ? -1 : m.prevOutcome == 0 ? 0 : m.prevOutcome == mi + 1 ? 1 : 2;
            int res = m.result == 0 ? 0 : m.result == 3 ? 3 : m.result == mi + 1 ? 1 : 2;
            int left = m.result != 0 ? 0 : (int) Math.max(0, (m.deadline - System.currentTimeMillis() + 999) / 1000);
            int[] g = {m.score[mi], m.score[oi], m.round, m.picked(me) ? 1 : 0, m.picked(ot) ? 1 : 0, m.prevPick[mi], m.prevPick[oi],
                    out, m.starUsed[mi] ? 0 : 1, m.starUsed[oi] ? 0 : 1, left, res, m.seq};
            for (int i = 0; i < 13; i++) game.set(i, g[i]);
        }
        PacketDistributor.sendToPlayer(sp, new DuelSyncPayload(notice, free, by, to, opp, oppColor, oppLook, game));
    }

    private static void pushTo(UUID id, int notice) {
        ServerPlayer p = online(id);
        if (p != null) push(p, notice);
    }

    public static void request(ServerPlayer sp) {
        long now = System.currentTimeMillis();
        Long last = lastRequest.get(sp.getUUID());
        if (last != null && now - last < 500) return;
        lastRequest.put(sp.getUUID(), now);
        push(sp, 0);
    }

    private static void cancelFrom(UUID from) {
        List<UUID> targets = new ArrayList<>();
        for (Map.Entry<UUID, Invite> e : invites.entrySet()) if (e.getValue().from().equals(from)) targets.add(e.getKey());
        for (UUID t : targets) { invites.remove(t); pushTo(t, 0); }
    }

    public static void cancel(ServerPlayer sp) {
        cancelFrom(sp.getUUID());
        push(sp, 0);
    }

    private static void invite(ServerPlayer sp, String targetName) {
        ServerPlayer target = server.getPlayerList().getPlayerByName(targetName);
        if (target == null) { push(sp, 3); return; }
        if (target.getUUID().equals(sp.getUUID())) { push(sp, 0); return; }
        if (playing(sp.getUUID()) || playing(target.getUUID())) { push(sp, 2); return; }
        Invite back = pending(sp.getUUID());                              // they already challenged us: this is a yes
        if (back != null && back.from().equals(target.getUUID())) { accept(sp, targetName); return; }
        Invite other = pending(target.getUUID());
        if (other != null && !other.from().equals(sp.getUUID())) { push(sp, 2); return; }
        cancelFrom(sp.getUUID());
        invites.put(target.getUUID(), new Invite(sp.getUUID(), System.currentTimeMillis() + INVITE_MS));
        target.displayClientMessage(Component.translatable("cutemod.duel.invite_msg", sp.getGameProfile().getName()), true);
        push(sp, 0);
        push(target, 0);
    }

    private static void accept(ServerPlayer sp, String fromName) {
        Invite in = pending(sp.getUUID());
        ServerPlayer from = in == null ? null : online(in.from());
        if (in == null || from == null || !from.getGameProfile().getName().equalsIgnoreCase(fromName)) { push(sp, 5); return; }
        if (playing(sp.getUUID()) || playing(from.getUUID())) { invites.remove(sp.getUUID()); push(sp, 2); return; }
        invites.remove(sp.getUUID());
        cancelFrom(from.getUUID());
        cancelFrom(sp.getUUID());
        DuelMatch m = new DuelMatch(from.getUUID(), sp.getUUID(), System.currentTimeMillis());
        matches.put(sp.getUUID(), m);
        matches.put(from.getUUID(), m);
        push(sp, 0);
        push(from, 0);
    }

    private static void decline(ServerPlayer sp) {
        Invite in = pending(sp.getUUID());
        if (in != null) {
            invites.remove(sp.getUUID());
            pushTo(in.from(), 1);
        }
        push(sp, 0);
    }

    private static void pick(ServerPlayer sp, int move) {
        DuelMatch m = matches.get(sp.getUUID());
        if (m == null) { push(sp, 0); return; }
        m.pick(sp.getUUID(), move, System.currentTimeMillis());
        push(sp, 0);                                                       // also when it was refused: the player sees the real state
        pushTo(m.other(sp.getUUID()), 0);
    }

    /** The player gives up, finishes looking at a finished duel, or has left the server. */
    public static void leaveGame(UUID id) {
        cancelFrom(id);
        invites.remove(id);
        DuelMatch m = matches.remove(id);
        if (m != null) {
            boolean wasPlaying = m.result == 0;
            m.resign(id);
            UUID other = m.other(id);
            if (matches.get(other) != m) matches.remove(other);           // nobody is left in it
            else pushTo(other, wasPlaying ? 4 : 0);
        }
        pushTo(id, 0);
    }

    public static void leave(UUID id) {
        leaveGame(id);
        lastRequest.remove(id);
        pets.remove(id);
    }
}
