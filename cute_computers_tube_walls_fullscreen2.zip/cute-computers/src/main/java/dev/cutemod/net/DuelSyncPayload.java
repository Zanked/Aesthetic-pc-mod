package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: who is online (and free), the challenges, and the duel you are in (opponent is empty if there is none).
 * notice: 0 nothing, 1 your challenge was declined, 2 that player is busy, 3 no such player, 4 your opponent left,
 * 5 the challenge ran out.
 * game (13 numbers, all from YOUR point of view): 0 my score, 1 their score, 2 round, 3 I have picked (0/1), 4 they have picked,
 * 5 my last move (-1 none), 6 their last move, 7 outcome of the last round (-1 none, 0 tie, 1 me, 2 them), 8 my Showstopper
 * is still free (0/1), 9 theirs is, 10 seconds left for this round, 11 result (0 playing, 1 I won, 2 I lost, 3 draw), 12 round counter
 * (goes up when a round is settled).
 */
public record DuelSyncPayload(int notice, List<String> players, String invitedBy, String invitedTo, String opponent,
                              String oppColor, PetLook oppLook, List<Integer> game) implements CustomPacketPayload {
    public static final Type<DuelSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "duel_sync"));

    private static final StreamCodec<ByteBuf, List<String>> NAMES = ByteBufCodecs.stringUtf8(32).apply(ByteBufCodecs.list(100));
    private static final StreamCodec<ByteBuf, List<Integer>> GAME = ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(16));

    public static final StreamCodec<RegistryFriendlyByteBuf, DuelSyncPayload> STREAM_CODEC = StreamCodec.of((buf, p) -> {
        ByteBufCodecs.VAR_INT.encode(buf, p.notice());
        NAMES.encode(buf, p.players());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.invitedBy());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.invitedTo());
        ByteBufCodecs.stringUtf8(32).encode(buf, p.opponent());
        ByteBufCodecs.stringUtf8(16).encode(buf, p.oppColor());
        PetLook.CODEC.encode(buf, p.oppLook());
        GAME.encode(buf, p.game());
    }, buf -> new DuelSyncPayload(
            ByteBufCodecs.VAR_INT.decode(buf),
            NAMES.decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.stringUtf8(32).decode(buf),
            ByteBufCodecs.stringUtf8(16).decode(buf),
            PetLook.CODEC.decode(buf),
            GAME.decode(buf)));

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(DuelSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onDuelSync(p));
    }
}
