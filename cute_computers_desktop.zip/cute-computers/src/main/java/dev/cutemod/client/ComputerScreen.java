package dev.cutemod.client;

import dev.cutemod.ComputerColor;
import dev.cutemod.block.ComputerBlockEntity;
import dev.cutemod.client.os.App;
import dev.cutemod.client.os.Desktop;
import dev.cutemod.client.os.Shell;
import dev.cutemod.net.ScorePayload;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.net.URI;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/** The "monitor": a little desktop with games, a browser and other apps. */
public class ComputerScreen extends Screen implements Shell {
    private static final int PAD = 10;
    private static final int HEADER = 24;
    private static final int FOOTER = 20;
    private static final int TASKBAR = 14;
    private static final int VIEW_W = App.W;
    private static final int VIEW_H = App.H + TASKBAR;
    private static final long STEP_NS = 16_666_667L; // apps run at 60 steps/second
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");

    private final ComputerColor color;
    private final BlockPos pos;
    private final Desktop desktop = new Desktop();
    private App app;

    private int left, top, gx, gy, panelW, panelH;
    private long lastNs = 0, acc = 0;

    public ComputerScreen(ComputerColor color, BlockPos pos) {
        super(Component.translatable("cutemod.os.title"));
        this.color = color;
        this.pos = pos;
        open(desktop);
    }

    // ---------- Shell ----------
    @Override
    public void open(App next) {
        if (app != null) app.close();
        app = next;
        app.attach(this);
        acc = 0;
    }

    @Override
    public void home() { open(desktop); }

    @Override
    public ComputerColor color() { return color; }

    @Override
    public void openLink(String url) {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(new ConfirmLinkScreen(accepted -> {
            if (accepted) {
                try {
                    Util.getPlatform().openUri(URI.create(url));
                } catch (Exception ignored) {
                }
            }
            mc.setScreen(this);
        }, url, true));
    }

    @Override
    public void submitScore(ComputerColor game, int score) {
        // only the computer's own game counts for the record stored in the block
        if (game == color) PacketDistributor.sendToServer(new ScorePayload(pos, score));
    }

    @Override
    public int absX() { return gx; }

    @Override
    public int absY() { return gy; }

    // ---------- Screen ----------
    @Override
    protected void init() {
        panelW = VIEW_W + PAD * 2;
        panelH = VIEW_H + HEADER + FOOTER;
        left = (width - panelW) / 2;
        top = (height - panelH) / 2;
        gx = left + PAD;
        gy = top + HEADER;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        app.close();
        super.removed();
    }

    private ComputerBlockEntity be() {
        var level = Minecraft.getInstance().level;
        if (level != null && level.getBlockEntity(pos) instanceof ComputerBlockEntity b) return b;
        return null;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        super.render(g, mouseX, mouseY, partial);

        // --- fixed timestep for the apps ---
        long now = System.nanoTime();
        if (lastNs == 0) lastNs = now;
        acc += now - lastNs;
        lastNs = now;
        if (acc > 100_000_000L) acc = 100_000_000L;
        app.mouse(mouseX - gx, mouseY - gy);
        while (acc >= STEP_NS) {
            acc -= STEP_NS;
            app.tick();
        }

        // --- computer casing ---
        int body = 0xFF000000 | color.bodyColor;
        boolean darkBody = luminance(color.bodyColor) < 110;
        int textCol = darkBody ? 0xFFFFFFFF : 0xFF3A2A3A;
        g.fill(left - 3, top - 3, left + panelW + 3, top + panelH + 3, 0xFF2A2030);
        g.fill(left - 2, top - 2, left + panelW + 2, top + panelH + 2, body);
        g.fill(left - 2, top - 2, left + panelW + 2, top - 1, 0x66FFFFFF);
        g.fill(gx - 4, gy - 4, gx + VIEW_W + 4, gy + VIEW_H + 4, 0xFF1B1422);

        // --- header ---
        g.drawString(font, app.title(), left + PAD, top + 8, textCol, false);
        Component status = app.status();
        g.drawString(font, status, left + panelW - PAD - font.width(status), top + 8, textCol, false);

        // --- app ---
        g.enableScissor(gx, gy, gx + VIEW_W, gy + App.H);
        g.pose().pushPose();
        g.pose().translate(gx, gy, 0);
        app.render(g, mouseX - gx, mouseY - gy);
        g.pose().popPose();
        g.disableScissor();

        // --- taskbar ---
        int ty = gy + App.H;
        g.fill(gx, ty, gx + VIEW_W, ty + TASKBAR, 0xFF2A2030);
        boolean onDesktop = app == desktop;
        boolean overBtn = mouseX >= gx + 2 && mouseX < gx + 82 && mouseY >= ty + 1 && mouseY < ty + TASKBAR - 1;
        g.fill(gx + 2, ty + 1, gx + 82, ty + TASKBAR - 1,
                onDesktop ? 0xFFB57BD6 : (overBtn ? 0xFF6A5A86 : 0xFF4A3A66));
        g.drawString(font, Component.translatable("cutemod.os.desktop"), gx + 6, ty + 3, 0xFFFFFFFF, false);
        if (!onDesktop) g.drawString(font, app.title(), gx + 90, ty + 3, 0xFFD8CCE8, false);
        String clock = LocalTime.now().format(CLOCK);
        g.drawString(font, clock, gx + VIEW_W - 4 - font.width(clock), ty + 3, 0xFFFFFFFF, false);

        // --- footer: record + hint ---
        if (app.showRecord()) {
            ComputerBlockEntity be = be();
            Component rec = (be == null || be.getHighScore() <= 0)
                    ? Component.translatable("cutemod.ui.record_none")
                    : Component.translatable("cutemod.ui.record", be.getHighScore(), be.getHolder());
            g.drawString(font, rec, left + PAD, gy + VIEW_H + 8, textCol, false);
        }
        Component hint = app.hint();
        g.drawString(font, hint, left + panelW - PAD - font.width(hint), gy + VIEW_H + 8, textCol, false);
    }

    private static int luminance(int rgb) {
        int r = (rgb >> 16) & 255, gr = (rgb >> 8) & 255, b = rgb & 255;
        return (int) (0.299 * r + 0.587 * gr + 0.114 * b);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int lx = (int) Math.floor(mouseX - gx), ly = (int) Math.floor(mouseY - gy);
        if (lx >= 0 && lx < VIEW_W && ly >= 0 && ly < App.H) {
            app.click(lx, ly, button);
            return true;
        }
        if (lx >= 2 && lx < 82 && ly >= App.H + 1 && ly < VIEW_H - 1) { // taskbar "Desktop" button
            if (app != desktop) home();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        int lx = (int) Math.floor(mouseX - gx), ly = (int) Math.floor(mouseY - gy);
        if (app.drag(lx, ly, button)) return true;
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (app.scroll(scrollY)) return true;
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (app.key(keyCode, modifiers)) return true;
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (app.charTyped(codePoint)) return true;
        return super.charTyped(codePoint, modifiers);
    }
}
