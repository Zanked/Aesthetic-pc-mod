package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/** The "Games" folder: all 8 games, playable on any computer. */
public class GamesApp extends App {
    private static final int COLS = 4, TW = 66, TH = 64, GAP = 4;
    private static final int X0 = (W - (COLS * TW + (COLS - 1) * GAP)) / 2;
    private static final int Y0 = (H - (2 * TH + GAP)) / 2;

    @Override
    public Component title() { return Component.translatable("cutemod.os.games"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.games"); }

    private static int tx(int i) { return X0 + (i % COLS) * (TW + GAP); }

    private static int ty(int i) { return Y0 + (i / COLS) * (TH + GAP); }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        int body = shell.color().bodyColor;
        g.fillGradient(0, 0, W, H, mix(body, 0xFFFFFF, 0.65f), mix(body, 0xFFFFFF, 0.3f));
        ComputerColor[] all = ComputerColor.values();
        for (int i = 0; i < all.length; i++) {
            ComputerColor c = all[i];
            int x = tx(i), y = ty(i);
            boolean hover = in(mx, my, x, y, TW, TH);
            boolean own = c == shell.color();
            rect(g, x - 1, y - 1, TW + 2, TH + 2, own ? 0xFFFFD866 : 0xFF3A2A4A);
            rect(g, x, y, TW, TH, hover ? 0xFFFFFFFF : 0xFFF6F0FA);
            disc(g, x + TW / 2, y + 13, 8, 0xFF000000 | c.bodyColor);
            disc(g, x + TW / 2, y + 13, 5, mix(c.bodyColor, 0xFFFFFF, 0.5f));
            String name = t("cutemod.game." + c.id);
            List<FormattedCharSequence> lines = font().split(FormattedText.of(name), TW - 6);
            for (int l = 0; l < lines.size() && l < 4; l++) {
                FormattedCharSequence s = lines.get(l);
                g.drawString(font(), s, x + (TW - font().width(s)) / 2, y + 26 + l * 9, 0xFF3A2A3A, false);
            }
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        ComputerColor[] all = ComputerColor.values();
        for (int i = 0; i < all.length; i++) {
            if (in(x, y, tx(i), ty(i), TW, TH)) {
                shell.open(new GameApp(all[i]));
                return true;
            }
        }
        return false;
    }
}
