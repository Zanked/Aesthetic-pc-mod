package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * A tiny browser. "cute://" pages are built into the mod; any other address or search words
 * are opened in the player's real browser (after the vanilla "open link?" confirmation).
 */
public class BrowserApp extends App {
    private record RLine(FormattedCharSequence seq, int kind, String target, int y) {} // kind: 0 text, 1 heading, 2 link

    private static final Set<String> PAGES = Set.of("home", "peep", "chirp", "shop", "wiki", "mail",
            "news", "tips", "about", "notfound");
    /** The fictional internet: domain -> page id. */
    private static final Map<String, String> DOMAINS = Map.of(
            "peep.cute", "peep", "chirp.cute", "chirp", "creepermart.cute", "shop",
            "pandapedia.cute", "wiki", "beemail.cute", "mail", "cutenews.cute", "news");
    private static final String[] SEARCHABLE = {"peep", "chirp", "shop", "wiki", "mail", "news", "tips", "about"};
    private static final int VIEW_Y = 20, VIEW_H = H - VIEW_Y - 2, TEXT_X = 8, TEXT_W = W - 20;
    private static final int BAR_X = 52, BAR_W = W - BAR_X - 4;

    private final List<String> history = new ArrayList<>();
    private int hIdx = -1;
    private String address = "";
    private boolean focus, fresh;
    private final List<RLine> lines = new ArrayList<>();
    private int contentH, scroll, ticks;

    public BrowserApp() {
        open("home");
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.browser"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.browser"); }

    @Override
    public void tick() { ticks++; }

    private String currentId() { return hIdx >= 0 ? history.get(hIdx) : "home"; }

    // ---------- navigation ----------
    private void open(String id) {
        if (!id.startsWith("?") && !PAGES.contains(id)) id = "notfound";
        while (history.size() > hIdx + 1) history.remove(history.size() - 1);
        history.add(id);
        hIdx = history.size() - 1;
        show(id);
    }

    private String addressOf(String id) {
        if (id.startsWith("?")) return "peep.cute/?q=" + id.substring(1);
        for (Map.Entry<String, String> e : DOMAINS.entrySet()) if (e.getValue().equals(id)) return e.getKey();
        return "cute://" + id;
    }

    private void show(String id) {
        address = addressOf(id);
        focus = false;
        fresh = false;
        scroll = 0;
        if (id.startsWith("?")) buildSearch(id.substring(1));
        else layout(t("cutemod.page." + id));
    }

    private void back() {
        if (hIdx > 0) { hIdx--; show(history.get(hIdx)); }
    }

    private void forward() {
        if (hIdx < history.size() - 1) { hIdx++; show(history.get(hIdx)); }
    }

    private void go(String raw) {
        String in = raw.trim();
        if (in.isEmpty()) { address = addressOf(currentId()); return; }
        String low = in.toLowerCase(Locale.ROOT);
        if (low.startsWith("cute://")) { open(low.substring(7)); return; }
        String host = low.replaceFirst("^https?://", "").replaceFirst("^www\\.", "");
        int slash = host.indexOf('/');
        if (slash >= 0) host = host.substring(0, slash);
        if (DOMAINS.containsKey(host)) { open(DOMAINS.get(host)); return; }
        if (PAGES.contains(low)) { open(low); return; }
        if (low.startsWith("http://") || low.startsWith("https://") || (!in.contains(" ") && in.contains("."))) {
            String url = low.startsWith("http") ? in : "https://" + in;
            address = addressOf(currentId());
            shell.openLink(url); // a real address: ask, then open in the system browser
            return;
        }
        open("?" + in); // plain words: search the cute internet
    }

    private void follow(String target) { go(target); }

    // ---------- page layout ----------
    /** Page format: "# heading", "> target | label" for links, blank line = gap. */
    private void layout(String raw) {
        lines.clear();
        Font f = font();
        int y = 4;
        for (String ln : raw.split("\n", -1)) {
            if (ln.isBlank()) { y += 5; continue; }
            int kind = 0;
            String target = null, text = ln;
            if (ln.startsWith("# ")) {
                kind = 1;
                text = ln.substring(2);
            } else if (ln.startsWith("> ") && ln.indexOf('|') > 0) {
                int bar = ln.indexOf('|');
                kind = 2;
                target = ln.substring(2, bar).trim();
                text = ln.substring(bar + 1).trim();
            }
            for (FormattedCharSequence part : f.split(FormattedText.of(text), TEXT_W)) {
                lines.add(new RLine(part, kind, target, y));
                y += 10;
            }
            if (kind == 1) y += 3;
        }
        contentH = y + 4;
    }

    /** Search inside the cute internet: pages are ranked by how many query words they contain. */
    private void buildSearch(String query) {
        String[] words = query.toLowerCase(Locale.ROOT).trim().split("\\s+");
        List<String> ids = new ArrayList<>();
        List<Integer> scores = new ArrayList<>();
        for (String id : SEARCHABLE) {
            String page = t("cutemod.page." + id);
            String low = page.toLowerCase(Locale.ROOT);
            int score = 0;
            for (String w : words) if (!w.isEmpty() && low.contains(w)) score++;
            if (score == 0) continue;
            int at = 0;
            while (at < ids.size() && scores.get(at) >= score) at++;
            ids.add(at, id);
            scores.add(at, score);
        }
        StringBuilder sb = new StringBuilder("# ").append(t("cutemod.os.search.results", query)).append('\n');
        if (ids.isEmpty()) sb.append(t("cutemod.os.search.none")).append('\n');
        for (String id : ids) {
            String page = t("cutemod.page." + id);
            String title = page.startsWith("# ") ? page.substring(2, page.indexOf('\n')) : id;
            sb.append("> cute://").append(id).append(" | ").append(title.replace("|", "/")).append('\n');
            String domain = addressOf(id);
            sb.append(domain.startsWith("cute://") ? domain : "http://" + domain).append("\n\n");
        }
        sb.append("> https://www.google.com/search?q=")
          .append(URLEncoder.encode(query, StandardCharsets.UTF_8))
          .append(" | ").append(t("cutemod.os.search.real")).append('\n');
        layout(sb.toString());
    }

    private int maxScroll() { return Math.max(0, contentH - VIEW_H); }

    private void clampScroll() { scroll = Math.max(0, Math.min(maxScroll(), scroll)); }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, 0xFFFFFAFD);
        rect(g, 0, 0, W, VIEW_Y - 1, 0xFFE9DDF2);
        rect(g, 0, VIEW_Y - 1, W, 1, 0xFFC9B8D8);

        // toolbar buttons: back, forward, home
        drawButton(g, 3, 3, hIdx > 0, mx, my);
        glyph(g, "<", 3 + 5, 6, hIdx > 0);
        drawButton(g, 19, 3, hIdx < history.size() - 1, mx, my);
        glyph(g, ">", 19 + 5, 6, hIdx < history.size() - 1);
        drawButton(g, 35, 3, true, mx, my);
        rect(g, 35 + 4, 3 + 7, 6, 5, 0xFF3A2A3A);
        rect(g, 35 + 3, 3 + 6, 8, 1, 0xFF3A2A3A);
        rect(g, 35 + 4, 3 + 5, 6, 1, 0xFF3A2A3A);
        rect(g, 35 + 5, 3 + 4, 4, 1, 0xFF3A2A3A);
        rect(g, 35 + 6, 3 + 3, 2, 1, 0xFF3A2A3A);

        // address bar
        rect(g, BAR_X - 1, 2, BAR_W + 2, 16, focus ? 0xFF4A7BD0 : 0xFFB9A8C8);
        rect(g, BAR_X, 3, BAR_W, 14, 0xFFFFFFFF);
        String shown = address;
        while (shown.length() > 1 && f.width(shown) > BAR_W - 8) shown = shown.substring(1);
        int tw = f.width(shown);
        if (focus && fresh && !shown.isEmpty()) rect(g, BAR_X + 3, 4, tw + 2, 12, 0xFF4A7BD0);
        g.drawString(f, shown, BAR_X + 4, 6, focus && fresh ? 0xFFFFFFFF : 0xFF3A2A3A, false);
        if (focus && !fresh && (ticks / 30) % 2 == 0) rect(g, BAR_X + 4 + tw, 5, 1, 10, 0xFF3A2A3A);

        // page
        g.enableScissor(shell.absX(), shell.absY() + VIEW_Y, shell.absX() + W, shell.absY() + VIEW_Y + VIEW_H);
        for (RLine l : lines) {
            int y = VIEW_Y + l.y() - scroll;
            if (y < VIEW_Y - 12 || y > VIEW_Y + VIEW_H) continue;
            int w = f.width(l.seq());
            if (l.kind() == 1) {
                g.drawString(f, l.seq(), TEXT_X, y, 0xFFC04A7A, false);
                rect(g, TEXT_X, y + 9, w, 1, 0xFFF58FB8);
            } else if (l.kind() == 2) {
                boolean hover = in(mx, my, TEXT_X, y - 1, w, 10);
                int col = hover ? 0xFF2F9BFF : 0xFF1F5FBF;
                g.drawString(f, l.seq(), TEXT_X, y, col, false);
                rect(g, TEXT_X, y + 9, w, 1, col);
            } else {
                g.drawString(f, l.seq(), TEXT_X, y, 0xFF3A2A3A, false);
            }
        }
        g.disableScissor();

        // scrollbar
        if (contentH > VIEW_H) {
            rect(g, W - 5, VIEW_Y, 3, VIEW_H, 0xFFE9DDF2);
            int th = Math.max(12, VIEW_H * VIEW_H / contentH);
            int ty = VIEW_Y + (VIEW_H - th) * scroll / maxScroll();
            rect(g, W - 5, ty, 3, th, 0xFFB57BD6);
        }
    }

    private void drawButton(GuiGraphics g, int x, int y, boolean enabled, int mx, int my) {
        boolean hover = enabled && in(mx, my, x, y, 14, 14);
        rect(g, x, y, 14, 14, hover ? 0xFFFFFFFF : (enabled ? 0xFFF6F0FA : 0xFFD8CCE2));
    }

    private void glyph(GuiGraphics g, String s, int x, int y, boolean enabled) {
        g.drawString(font(), s, x, y, enabled ? 0xFF3A2A3A : 0xFF9A8FA8, false);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (y < VIEW_Y) {
            if (in(x, y, 3, 3, 14, 14)) { back(); return true; }
            if (in(x, y, 19, 3, 14, 14)) { forward(); return true; }
            if (in(x, y, 35, 3, 14, 14)) { open("home"); return true; }
            if (in(x, y, BAR_X, 3, BAR_W, 14)) {
                if (!focus) { focus = true; fresh = true; }
                return true;
            }
            return true;
        }
        if (focus) { focus = false; fresh = false; address = addressOf(currentId()); }
        Font f = font();
        for (RLine l : lines) {
            if (l.kind() != 2) continue;
            int ly = VIEW_Y + l.y() - scroll;
            if (in(x, y, TEXT_X, ly - 1, f.width(l.seq()), 10)) {
                follow(l.target());
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (focus) {
            if (keyCode == 257 || keyCode == 335) { // enter
                focus = false;
                fresh = false;
                go(address);
                return true;
            }
            if (keyCode == 256) { // escape: leave the address bar, don't close the computer
                focus = false;
                fresh = false;
                address = addressOf(currentId());
                return true;
            }
            if (keyCode == 259) { // backspace
                if (fresh) { address = ""; fresh = false; }
                else if (!address.isEmpty()) address = address.substring(0, address.length() - 1);
                return true;
            }
            if (keyCode == 86 && Screen.hasControlDown()) { // ctrl+v
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) {
                    clip = clip.replace("\n", "").replace("\r", "").trim();
                    if (fresh) { address = ""; fresh = false; }
                    address = (address + clip);
                    if (address.length() > 300) address = address.substring(0, 300);
                }
                return true;
            }
            return false;
        }
        switch (keyCode) {
            case 265 -> scroll -= 12;   // up
            case 264 -> scroll += 12;   // down
            case 266 -> scroll -= VIEW_H - 12; // page up
            case 267 -> scroll += VIEW_H - 12; // page down
            case 268 -> scroll = 0;     // home
            case 269 -> scroll = maxScroll(); // end
            default -> { return false; }
        }
        clampScroll();
        return true;
    }

    @Override
    public boolean charTyped(char c) {
        if (!focus || c < 32 || c == 127) return false;
        if (fresh) { address = ""; fresh = false; }
        if (address.length() < 300) address += c;
        return true;
    }

    @Override
    public boolean scroll(double amount) {
        scroll -= (int) Math.round(amount * 14);
        clampScroll();
        return true;
    }
}
