package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/** The desktop: wallpaper + icons that launch apps. */
public class Desktop extends App {
    private static final int COLS = 3, CW = 84, CH = 66, ICONS = 5;
    private static final int X0 = (W - COLS * CW) / 2, Y0 = 12;

    private BrowserApp browser;
    private NotepadApp notes;
    private PaintApp paint;

    @Override
    public Component title() { return Component.translatable("cutemod.os.title"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.desktop"); }

    private static int cx(int i) { return X0 + (i % COLS) * CW; }

    private static int cy(int i) { return Y0 + (i / COLS) * CH; }

    private String label(int i) {
        return switch (i) {
            case 0 -> t("cutemod.game." + shell.color().id);
            case 1 -> t("cutemod.os.games");
            case 2 -> t("cutemod.os.browser");
            case 3 -> t("cutemod.os.notes");
            default -> t("cutemod.os.paint");
        };
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        int body = shell.color().bodyColor;
        g.fillGradient(0, 0, W, H, mix(body, 0xFFFFFF, 0.6f), mix(body, 0x3A2A4A, 0.35f));
        // a few soft dots on the wallpaper
        for (int i = 0; i < 14; i++) {
            int x = (i * 61 + 17) % W, y = (i * 37 + 9) % H;
            rect(g, x, y, 3, 3, 0x30FFFFFF);
        }
        for (int i = 0; i < ICONS; i++) {
            int x = cx(i), y = cy(i);
            if (in(mx, my, x, y, CW, CH)) rect(g, x + 2, y + 2, CW - 4, CH - 4, 0x44FFFFFF);
            drawIcon(g, i, x + (CW - 32) / 2, y + 6, body);
            List<FormattedCharSequence> lines = font().split(FormattedText.of(label(i)), CW - 8);
            for (int l = 0; l < lines.size() && l < 2; l++) {
                FormattedCharSequence s = lines.get(l);
                g.drawString(font(), s, x + (CW - font().width(s)) / 2, y + 42 + l * 9, 0xFFFFFFFF, true);
            }
        }
    }

    private void drawIcon(GuiGraphics g, int i, int x, int y, int body) {
        switch (i) {
            case 0 -> { // gamepad in the computer's color
                rect(g, x + 1, y + 8, 30, 18, 0xFF3A2A3A);
                rect(g, x + 2, y + 9, 28, 16, 0xFF000000 | body);
                rect(g, x + 7, y + 16, 9, 2, 0xFF3A2A3A);
                rect(g, x + 10, y + 13, 3, 8, 0xFF3A2A3A);
                disc(g, x + 22, y + 15, 2, 0xFFE5484D);
                disc(g, x + 26, y + 19, 2, 0xFF2F7FD6);
            }
            case 1 -> { // folder
                rect(g, x + 2, y + 6, 13, 5, 0xFFE0A93B);
                rect(g, x + 2, y + 10, 28, 18, 0xFFF3C45A);
                rect(g, x + 2, y + 10, 28, 2, 0xFFFFE08A);
                rect(g, x + 12, y + 16, 8, 6, 0xFF3A2A3A);
                rect(g, x + 14, y + 17, 4, 1, 0xFF8FD39A);
            }
            case 2 -> { // globe
                disc(g, x + 16, y + 16, 14, 0xFF2F7FD6);
                rect(g, x + 8, y + 8, 9, 5, 0xFF5BBF6A);
                rect(g, x + 18, y + 16, 8, 7, 0xFF5BBF6A);
                rect(g, x + 7, y + 19, 5, 5, 0xFF5BBF6A);
                rect(g, x + 3, y + 16, 26, 1, 0x66FFFFFF);
                rect(g, x + 16, y + 3, 1, 26, 0x66FFFFFF);
            }
            case 3 -> { // notepad
                rect(g, x + 6, y + 2, 20, 28, 0xFF3A2A3A);
                rect(g, x + 7, y + 3, 18, 26, 0xFFFFFFFF);
                rect(g, x + 7, y + 3, 18, 4, 0xFFF58FB8);
                for (int l = 0; l < 4; l++) rect(g, x + 10, y + 11 + l * 4, 12, 1, 0xFF9AA0C0);
            }
            default -> { // paint palette
                disc(g, x + 16, y + 16, 14, 0xFFF3D9B1);
                disc(g, x + 9, y + 13, 3, 0xFFE5484D);
                disc(g, x + 16, y + 8, 3, 0xFFF3D46A);
                disc(g, x + 23, y + 13, 3, 0xFF5BBF6A);
                disc(g, x + 22, y + 22, 3, 0xFF2F7FD6);
                disc(g, x + 11, y + 22, 3, 0xFFB57BD6);
            }
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < ICONS; i++) {
            if (in(x, y, cx(i), cy(i), CW, CH)) {
                launch(i);
                return true;
            }
        }
        return false;
    }

    private void launch(int i) {
        switch (i) {
            case 0 -> shell.open(new GameApp(shell.color()));
            case 1 -> shell.open(new GamesApp());
            case 2 -> {
                if (browser == null) browser = new BrowserApp();
                shell.open(browser);
            }
            case 3 -> {
                if (notes == null) notes = new NotepadApp();
                shell.open(notes);
            }
            default -> {
                if (paint == null) paint = new PaintApp();
                shell.open(paint);
            }
        }
    }
}
