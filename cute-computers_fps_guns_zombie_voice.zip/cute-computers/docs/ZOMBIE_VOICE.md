# Zombie Shooter: the hero speaks (real speech, RU / EN)

The hero of Zombie Shooter now *says* her lines out loud instead of only showing them as text (the text on the screen stays).
The language follows the game language: Russian -> `ru`, anything else -> `en`.

* Recordings: `sounds/zvoice/<ru|en>/<key>_<n>.ogg` (186 files, about 3 MB), events `zvoice.<lang>.<key>` in `sounds.json`
  (a line with variants is one event with several sounds, Minecraft picks one at random).
* Made by `python3 tools/make_zombie_voice.py --models <folder with the two Piper voices>` (needs `piper-tts`, ffmpeg with libvorbis).
* Played by `ZombieShooter.voice()` through `Sfx.voiceSound()`: one line at a time, a new line cuts the old one off,
  small remarks (not enough points, "ammo full", a headshot...) are skipped while she is talking, the same line is not repeated within 5 seconds.
  Follows the *Sounds* switch and the system volume of the computer and stops when the game is closed.
* Lines: start, round N (2-30), round cleared, out of ammo, shopping (no points, ammo, new gun / junk gun, perk, Pack-a-Punch, mines, doors,
  secret room, mystery box, teddy bear), power on / off, new zombie kinds (runner / tank / spitter), power-ups, a zombie is in the way,
  and three that have no on-screen text: low health, death, and an occasional "Headshot!".
* New line: add it to `LINES` in the script, to `ZombieShooter.VOICED` (and to `LOW` if it must not interrupt), run the script.

## License of the voices (please read before publishing the mod)
The voices are Piper models from https://github.com/rhasspy/piper/releases/tag/v0.0.2:
* `ru-irinia-medium` - trained on the **RHVoice** dataset, whose model card says **GPLv2**. The mod is MIT, so check that this is fine for you
  (or swap in another Russian voice: change `VOICES` in the script).
* `en-us-lessac-medium` - trained on the Lessac data set; check its terms in the model card too.
