#!/usr/bin/env python3
"""
Real speech (not text) for the hero of the "Zombie Shooter" mini game, in Russian and English.

The lines are spoken by a neural text-to-speech voice (Piper, https://github.com/rhasspy/piper), one woman's voice per language:
    ru  ru-irinia-medium   (Irina, from the RHVoice dataset, GPLv2 - see docs/ZOMBIE_VOICE.md)
    en  en-us-lessac-medium

    pip install piper-tts numpy
    # the two voices are on the Piper release page, "voice-<name>.tar.gz" (each has an .onnx and an .onnx.json):
    #   https://github.com/rhasspy/piper/releases/tag/v0.0.2
    python3 tools/make_zombie_voice.py --models /path/to/folder/with/the/onnx/files

Writes sounds/zvoice/<ru|en>/<key>_<n>.ogg and registers one event per line in sounds.json:  zvoice.<lang>.<key>
(a line with several variants is ONE event with several sounds: Minecraft picks one at random).
ZombieShooter picks the language from the game language (Russian -> ru, anything else -> en), see ZombieShooter.voice().

Needs ffmpeg (with libvorbis). The ONE list that matters is LINES below: the key is what the game asks for
(the lang key "cutemod.zombies.drop.3" becomes "drop_3", "cutemod.zombies.round" + number becomes "round_<n>").
If you add a line here, add the key to ZombieShooter.VOICED as well (and to LOW if it must not interrupt another line).
"""
import argparse
import json
import os
import subprocess
import tempfile
import wave

from piper import PiperVoice
from piper.config import SynthesisConfig

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "src/main/resources/assets/cutemod")
OUT = os.path.join(ASSETS, "sounds/zvoice")

VOICES = {"ru": "ru-irinia-medium", "en": "en-us-lessac-medium"}
LENGTH = {"ru": 0.93, "en": 0.95}          # a little quicker than the default: she is being chased by zombies

# ---- numbers as words (the TTS reads words better than digits) ----
RU_ONES = ["", "один", "два", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять", "десять", "одиннадцать",
           "двенадцать", "тринадцать", "четырнадцать", "пятнадцать", "шестнадцать", "семнадцать", "восемнадцать", "девятнадцать"]
RU_TENS = {20: "двадцать", 30: "тридцать"}
EN_ONES = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen",
           "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]
EN_TENS = {20: "twenty", 30: "thirty"}
MAX_ROUND = 30


def num(lang, n):
    ones, tens = (RU_ONES, RU_TENS) if lang == "ru" else (EN_ONES, EN_TENS)
    if n < 20:
        return ones[n]
    t = n // 10 * 10
    return tens[t] + (" " + ones[n - t] if n - t else "")


# ---- the lines: key -> (russian variants, english variants) ----
LINES = {
    "start": (["Так. Нужно выжить. Найди рубильник!", "Они уже близко. Надо найти рубильник."],
              ["Okay. Stay alive. Find the power switch!", "They're close. I need to find the power switch."]),
    "clear": (["Раунд пройден! Можно передохнуть.", "Фух. Раунд пройден."],
              ["Round cleared. Catch your breath.", "Phew. That round's done."]),
    "last_ammo": (["Патроны на исходе... нашлись последние.", "Почти всё потрачено. Ещё немного осталось."],
                  ["I'm almost out of ammo... found a few more.", "Down to the last bullets."]),
    "poor": (["Не хватает очков.", "Очков маловато.", "Нужно больше очков."],
             ["Not enough points.", "I can't afford that.", "I need more points."]),
    "ammo": (["Патроны пополнены.", "Полный магазин. Отлично."],
             ["Ammo restocked.", "Locked and loaded."]),
    "full": (["Патроны уже полные."], ["My ammo is already full."]),
    "got": (["Новая пушка!", "Вот это другое дело!"], ["A new gun!", "Now we're talking!"]),
    "junk": (["Ну и хлам!", "Серьёзно? Вот это хлам."], ["What a piece of junk!", "Seriously? That's junk."]),
    "perk_got": (["Усиление получено!", "Чувствую себя сильнее."], ["Perk acquired!", "I feel stronger already."]),
    "perk_max": (["Больше некуда улучшать."], ["That's already maxed out."]),
    "pap_done": (["Улучшено! Теперь повеселимся.", "Пак-а-Панч сработал!"], ["Upgraded! Now we're talking.", "Pack-a-Punch did it!"]),
    "pap_again": (["Уже улучшено."], ["Already upgraded."]),
    "power_on": (["Свет включён! Перки и Пак-а-Панч работают.", "Есть питание! Автоматы ожили."],
                 ["The power's on! Perks and Pack-a-Punch are online.", "We have power! The machines are alive."]),
    "power_off": (["Нет питания! Найди рубильник.", "Тут всё обесточено. Нужен рубильник."],
                  ["No power! Find the power switch.", "Everything's dead. I need the power switch."]),
    "door_open": (["Дверь открыта! Теперь зомби полезут и из новых окон.", "Дверь открыта. Держись, будет жарко."],
                  ["The door's open! Now they'll come through new windows too.", "Door's open. Brace yourself."]),
    "secret_found": (["Тайная комната!", "Ого, тайник!"], ["A secret room!", "Whoa, a hidden room!"]),
    "mines_bought": (["Три мины! Кнопка эф ставит мину.", "Мины у меня! Ставь на эф."],
                     ["Three mines! Press F to lay one.", "Got mines! F lays one down."]),
    "mines_full": (["Больше мин не унесу."], ["I can't carry any more mines."]),
    "nomines": (["Мин нет. Купи у стены."], ["No mines left. Buy some at the wall."]),
    "new_1": (["Бегун! Быстрый, но хрупкий.", "Осторожно, бегун!"], ["A runner! Fast, but fragile.", "Watch out, a runner!"]),
    "new_2": (["Толстяк! Медленный, но очень крепкий.", "Ого, толстяк! Держи дистанцию."],
              ["A tank! Slow, but very tough.", "Whoa, a tank! Keep your distance."]),
    "new_3": (["Плеватель! Уворачивайся от плевков.", "Плеватель! Не стой на месте."],
              ["A spitter! Dodge the spit.", "A spitter! Keep moving."]),
    "drop_0": (["Максимум патронов!"], ["Max ammo!"]),
    "drop_1": (["Мгновенное убийство!", "Один удар, один зомби!"], ["Insta-kill!", "One hit, one zombie!"]),
    "drop_2": (["Ядерка! Всё взорвалось!", "Ядерка!"], ["Nuke! Boom!", "Nuke!"]),
    "drop_3": (["Двойные очки!"], ["Double points!"]),
    "drop_4": (["Плотник! Окна починены.", "Все окна как новые!"], ["Carpenter! Windows repaired.", "All the windows are fixed!"]),
    "drop_5": (["Аптечка! Уже лучше.", "Аптечка! Чувствую себя лучше."], ["Med kit! Much better.", "Med kit! I feel better."]),
    "box_lost": (["Ящик закрылся. Вот досада!", "Не успела, ящик закрылся."], ["The box closed. Dang it!", "Too slow, the box closed."]),
    "teddy": (["Плюшевый мишка! Очки вернулись.", "Мишка? Хотя бы очки вернулись."],
              ["A teddy bear! Points refunded.", "A teddy bear? At least I got my points back."]),
    "blocked": (["Мешает зомби!", "Зомби мешает!"], ["A zombie's in the way!", "Get out of the way!"]),
    # not tied to a message on the screen: the hero talks by herself
    "low_hp": (["Мне плохо... нужно укрытие!", "Здоровья почти нет!", "Я ранена, надо отступать!"],
               ["I'm hurt... I need cover!", "I'm almost dead!", "I'm hurt, fall back!"]),
    "dead": (["Нет... они добрались до меня...", "Всё... я не смогла."],
             ["No... they got me...", "I couldn't make it..."]),
    "head": (["В голову!", "Прямо в голову!", "Хедшот!"], ["Headshot!", "Right between the eyes!", "Boom, headshot!"]),
}
# "round_2" ... "round_30": the number is spoken
ROUND_RU = "Раунд {}."
ROUND_EN = "Round {}."


def to_ogg(wav_path, ogg_path):
    # cut the silence at both ends, even out the loudness, then Vorbis (mono)
    cut = "silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.03"
    af = cut + ",areverse," + cut + ",areverse,loudnorm=I=-15:TP=-1.5:LRA=7"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav_path, "-af", af, "-ac", "1", "-ar", "44100",
                    "-c:a", "libvorbis", "-q:a", "4", ogg_path], check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", required=True, help="folder with ru-irinia-medium.onnx(.json) and en-us-lessac-medium.onnx(.json)")
    ap.add_argument("only", nargs="*", help="only these keys (default: all)")
    args = ap.parse_args()

    sj = os.path.join(ASSETS, "sounds.json")
    data = json.load(open(sj, encoding="utf-8"))
    data = {k: v for k, v in data.items() if not k.startswith("zvoice.")}        # re-made from scratch every run

    for lang, model in VOICES.items():
        path = os.path.join(args.models, model + ".onnx")
        voice = PiperVoice.load(path, config_path=path + ".json")
        cfg = SynthesisConfig(length_scale=LENGTH[lang], noise_scale=0.6, noise_w_scale=0.7)
        os.makedirs(os.path.join(OUT, lang), exist_ok=True)

        jobs = {}
        for key, (ru, en) in LINES.items():
            jobs[key] = ru if lang == "ru" else en
        for n in range(2, MAX_ROUND + 1):
            jobs["round_%d" % n] = [(ROUND_RU if lang == "ru" else ROUND_EN).format(num(lang, n))]

        for key, texts in jobs.items():
            names = []
            for i, text in enumerate(texts):
                name = "%s_%d" % (key, i)
                names.append(name)
                if args.only and key not in args.only and not any(key.startswith(o) for o in args.only):
                    continue
                with tempfile.TemporaryDirectory() as td:
                    wp = os.path.join(td, "a.wav")
                    with wave.open(wp, "wb") as w:
                        voice.synthesize_wav(text, w, cfg)
                    to_ogg(wp, os.path.join(OUT, lang, name + ".ogg"))
                print("%s %-14s %s" % (lang, name, text))
            data["zvoice.%s.%s" % (lang, key)] = {
                "sounds": [{"name": "cutemod:zvoice/%s/%s" % (lang, n), "stream": False} for n in names]}

    json.dump(data, open(sj, "w", encoding="utf-8"), indent=2)


if __name__ == "__main__":
    main()
