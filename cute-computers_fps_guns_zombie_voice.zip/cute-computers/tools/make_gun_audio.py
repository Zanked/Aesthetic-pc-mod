#!/usr/bin/env python3
"""
Makes the gun sounds of Zombie Shooter: a shot for every gun, the little sounds of a reload (magazine out / in, slide,
shells, pump, cylinder, bolt, ammo box, charge-up...) and the dry click of an empty gun.
Everything is synthesized (no samples), like the other tools/make_*_audio.py.

    python3 tools/make_gun_audio.py     # writes sounds/gun/<name>.ogg and registers gun.<name> in sounds.json

The reload is played in stages by ZombieShooter (RELOAD table): every stage is one of the small sounds below.
Needs numpy + scipy + ffmpeg (with libvorbis).
"""
import json
import os
import subprocess
import sys
import tempfile
import wave

import numpy as np
from scipy.signal import fftconvolve

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_jobs_audio as J                                         # noqa: E402
from make_jobs_audio import SR, T, lp, bp, noise, put               # noqa: E402

ASSETS = J.ASSETS
OUT = os.path.join(ASSETS, "sounds/gun")
_seed = [100]


def nz(n):
    _seed[0] += 1
    return noise(n, _seed[0])


def env(n, decay, att=0.0005):
    t = T(n)
    e = np.exp(-t * decay)
    a = int(att * SR)
    if a > 1: e[:a] *= np.linspace(0, 1, a)
    return e


def burst(dur, lo, hi, decay, gain=1.0):
    n = int(dur * SR)
    return bp(nz(n), lo, hi) * env(n, decay) * gain


def lowburst(dur, fc, decay, gain=1.0):
    n = int(dur * SR)
    return lp(nz(n), fc) * env(n, decay) * gain


def thump(f0, dur, decay, drop=2.5, gain=1.0):
    n = int(dur * SR); t = T(n)
    f = f0 * (1 + (drop - 1) * np.exp(-t * 40))
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * decay) * gain


def ring(f, dur, decay, gain=1.0):
    n = int(dur * SR); t = T(n)
    return (np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * f * 2.76 * t)) * np.exp(-t * decay) * gain


def reverb(x, tail, mix):
    n = int(tail * SR)
    ir = lp(nz(n), 3500) * np.exp(-T(n) * (6.0 / tail))
    ir[0] = 0
    wet = fftconvolve(x, ir)[:len(x)]
    wet = wet / (np.max(np.abs(wet)) + 1e-9) * np.max(np.abs(x))
    return x + wet * mix


def norm(x, peak):
    x = x - np.mean(x)
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    fo = int(0.015 * SR)
    x[-fo:] *= np.linspace(1, 0, fo)
    return x


def bang(dur, fc, d1, f0, rev, mix, crack=1.0, boomy=1.0, peak=0.95):
    """A gun shot: a sharp crack, the blast, the low thump and the echo of the room."""
    n = int(dur * SR)
    b = np.zeros(n)
    put(b, burst(0.02, 1200, 12000, 220, 2.2 * crack), 0)
    put(b, lowburst(0.5, fc, d1, 1.2), 0)
    put(b, thump(f0, 0.35, 11, 2.6, 1.6 * boomy), 0)
    put(b, lowburst(0.25, 900, 14, 0.6 * boomy), 0.004)
    return norm(reverb(b, rev, mix), peak)


# ------------------------------------------------------------------ shots
def shot_pistol():  return bang(0.55, 4800, 48, 150, 0.25, 0.30)
def shot_rifle():   return bang(0.65, 3600, 32, 105, 0.35, 0.35, 1.2)
def shot_smg():     return bang(0.35, 5200, 58, 170, 0.18, 0.22, 1.1, 0.8, 0.85)
def shot_magnum():  return bang(1.0, 2600, 17, 72, 0.5, 0.45, 1.3, 1.5)
def shot_shotgun(): return bang(1.0, 2300, 14, 58, 0.45, 0.40, 1.0, 1.7)
def shot_combat():  return bang(0.7, 3000, 24, 85, 0.35, 0.32, 1.1, 1.3)
def shot_sniper():  return bang(1.8, 5200, 13, 62, 0.95, 0.60, 1.6, 1.3)
def shot_lmg():     return bang(0.45, 3000, 36, 82, 0.25, 0.25, 1.0, 1.3, 0.9)
def shot_minigun(): return bang(0.22, 4200, 70, 120, 0.12, 0.15, 1.0, 0.9, 0.75)


def shot_musket():
    n = int(1.3 * SR); b = np.zeros(n)
    put(b, burst(0.09, 3000, 9000, 40, 0.5), 0)                       # the powder in the pan: "pfft"
    put(b, burst(0.02, 1000, 9000, 200, 2.0), 0.05)
    put(b, lowburst(0.6, 1700, 11, 1.4), 0.05)
    put(b, thump(60, 0.5, 8, 2.5, 1.8), 0.05)
    return norm(reverb(b, 0.6, 0.4), 0.95)


def shot_flare():
    n = int(1.1 * SR); b = np.zeros(n)
    put(b, thump(190, 0.25, 14, 2.0, 1.5), 0)
    put(b, burst(0.03, 800, 6000, 150, 1.8), 0)
    t = T(int(0.9 * SR))
    sw = bp(nz(len(t)), 1500, 7000) * (1 - np.exp(-t * 20)) * np.exp(-t * 3.2) * 0.6    # the hiss of the flare flying off
    put(b, sw, 0.03)
    return norm(reverb(b, 0.4, 0.25), 0.9)


def shot_launcher():
    n = int(1.6 * SR); b = np.zeros(n)
    put(b, thump(48, 0.7, 5, 3.0, 2.0), 0)
    put(b, lowburst(0.4, 1200, 8, 1.3), 0)
    t = T(int(1.2 * SR))
    whoosh = bp(nz(len(t)), 300, 3500) * np.sin(np.pi * np.clip(t / 1.2, 0, 1)) ** 0.7 * 0.9
    put(b, whoosh, 0.05)
    return norm(reverb(b, 0.7, 0.35), 0.95)


def shot_railgun():
    n = int(0.9 * SR); b = np.zeros(n); t = T(n)
    f = 4200 * np.exp(-t * 9) + 140
    z = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 6)                 # a zap that falls
    put(b, z, 0, 1.0)
    put(b, burst(0.35, 2500, 14000, 12, 0.9), 0)
    put(b, thump(60, 0.5, 7, 3, 1.8), 0)
    put(b, burst(0.04, 1000, 12000, 120, 1.5), 0)
    return norm(reverb(b, 0.5, 0.35), 0.95)


def shot_ray():
    n = int(0.55 * SR); t = T(n); b = np.zeros(n)
    f = 1900 * np.exp(-t * 6) + 380 + 60 * np.sin(2 * np.pi * 28 * t)         # "pew-pew-pew" of an old ray gun
    z = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 5.5)
    z += 0.35 * np.sin(2 * np.pi * np.cumsum(f * 2.01) / SR) * np.exp(-t * 9)
    put(b, z, 0)
    put(b, burst(0.05, 3000, 12000, 60, 0.4), 0)
    return norm(lp(b, 12000), 0.9)


def shot_water():
    n = int(0.28 * SR); t = T(n)
    x = bp(nz(n), 1800, 6500) * np.sin(np.pi * np.clip(t / 0.28, 0, 1)) ** 0.5 * 0.9   # a "psshh" squirt
    put(x, burst(0.03, 600, 2500, 90, 0.4), 0)
    return norm(x, 0.7)


def shot_dart():
    n = int(0.3 * SR); b = np.zeros(n)
    put(b, thump(320, 0.12, 30, 1.8, 1.0), 0)                                   # a plastic "pomp"
    put(b, burst(0.04, 1500, 5000, 90, 0.7), 0)
    put(b, burst(0.12, 2000, 7000, 30, 0.25), 0.02)
    return norm(lp(b, 8000), 0.8)


def shot_sling():
    n = int(0.5 * SR); t = T(n); b = np.zeros(n)
    f = 260 * np.exp(-t * 4) + 140                                              # a rubber band "twang"
    b += np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 10) * (1 + 0.4 * np.sin(2 * np.pi * 40 * t))
    put(b, burst(0.25, 1500, 6000, 18, 0.5), 0.01)
    return norm(lp(b, 7000), 0.8)


# ------------------------------------------------------------------ the little sounds of a reload
def add(a, b):
    n = max(len(a), len(b)); r = np.zeros(n); r[:len(a)] += a; r[:len(b)] += b
    return r


def tick(f=3000, gain=1.0, decay=140.0):
    return add(burst(0.03, f * 0.5, f * 2.5, decay, gain), ring(f, 0.06, 90, 0.25 * gain))


def thud(f=130, dur=0.12, gain=1.0):
    return add(thump(f, dur, 28, 1.6, gain), lowburst(0.05, 900, 60, 0.4 * gain))


def scrape(dur, lo, hi, gain=0.5):
    n = int(dur * SR)
    return bp(nz(n), lo, hi) * np.sin(np.pi * np.clip(T(n) / dur, 0, 1)) ** 0.6 * gain


def buf(dur): return np.zeros(int(dur * SR))


def mag_out():
    b = buf(0.25)
    put(b, tick(2600, 0.8), 0); put(b, scrape(0.08, 800, 4000, 0.35), 0.02); put(b, thud(180, 0.1, 0.5), 0.09)
    return norm(b, 0.7)


def mag_in():
    b = buf(0.25)
    put(b, scrape(0.06, 900, 4000, 0.3), 0); put(b, thud(150, 0.12, 1.0), 0.05); put(b, tick(3400, 1.0), 0.055)
    return norm(b, 0.85)


def slide():
    b = buf(0.4)
    put(b, scrape(0.1, 1200, 6000, 0.5), 0); put(b, tick(2200, 0.9), 0.1); put(b, thud(120, 0.1, 0.5), 0.1)
    put(b, scrape(0.05, 1500, 5000, 0.3), 0.19); put(b, tick(3600, 1.2), 0.24); put(b, thud(150, 0.1, 0.7), 0.24)
    return norm(b, 0.9)


def shell():
    b = buf(0.2)
    put(b, ring(3600, 0.12, 60, 0.7), 0); put(b, tick(2800, 0.6), 0); put(b, thud(240, 0.06, 0.4), 0.025)
    return norm(b, 0.6)


def pump():
    b = buf(0.45)
    put(b, scrape(0.08, 600, 3500, 0.5), 0); put(b, thud(100, 0.12, 1.0), 0.07); put(b, tick(1800, 0.7), 0.07)
    put(b, scrape(0.06, 700, 3500, 0.4), 0.2); put(b, thud(90, 0.14, 1.2), 0.25); put(b, tick(2200, 1.0), 0.25)
    return norm(b, 0.95)


def cyl_open():
    b = buf(0.3)
    put(b, tick(3000, 1.0), 0); put(b, scrape(0.07, 1000, 5000, 0.4), 0.04); put(b, tick(2400, 0.8), 0.13)
    return norm(b, 0.8)


def cyl_close():
    b = buf(0.35)
    for i in range(7): put(b, tick(3600 + 80 * i, 0.3, 220), 0.01 + i * 0.022)                # the cylinder spins
    put(b, thud(140, 0.1, 1.0), 0.19); put(b, tick(2600, 1.2), 0.19)
    return norm(b, 0.9)


def bolt_open():
    b = buf(0.35)
    put(b, tick(2400, 0.9), 0); put(b, scrape(0.14, 700, 3500, 0.5), 0.03); put(b, thud(110, 0.1, 0.8), 0.17); put(b, tick(1700, 0.7), 0.17)
    return norm(b, 0.9)


def bolt_close():
    b = buf(0.4)
    put(b, scrape(0.12, 700, 3500, 0.5), 0); put(b, thud(100, 0.12, 0.9), 0.12); put(b, tick(1800, 0.8), 0.12)
    put(b, tick(3000, 1.3), 0.2); put(b, thud(130, 0.12, 1.1), 0.2)
    return norm(b, 0.95)


def box_open():
    b = buf(0.45)
    put(b, ring(520, 0.3, 14, 0.9), 0); put(b, burst(0.04, 400, 5000, 70, 1.0), 0); put(b, scrape(0.12, 500, 2500, 0.35), 0.06)
    put(b, ring(900, 0.15, 30, 0.4), 0.16)
    return norm(b, 0.9)


def belt():
    b = buf(0.8)
    rng = np.random.default_rng(5)
    for i in range(14): put(b, add(tick(float(rng.uniform(2800, 4200)), float(rng.uniform(0.3, 0.7)), 200), ring(float(rng.uniform(4000, 5200)), 0.05, 120, 0.12)), 0.02 + i * 0.05 + float(rng.uniform(-0.01, 0.01)))
    return norm(b, 0.7)


def box_close():
    b = buf(0.5)
    put(b, ring(430, 0.35, 11, 0.9), 0); put(b, thud(80, 0.2, 1.6), 0); put(b, burst(0.05, 300, 5000, 60, 1.0), 0)
    put(b, tick(2000, 0.7), 0.1)
    return norm(b, 1.0)


def charge():
    n = int(0.9 * SR); t = T(n)
    f = 180 + 1700 * (t / 0.9) ** 2                                              # a rising whine
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * (0.3 + 0.7 * (t / 0.9)) * (0.75 + 0.25 * np.sin(2 * np.pi * 14 * t))
    x += 0.25 * np.sin(2 * np.pi * np.cumsum(f * 1.5) / SR) * (t / 0.9)
    x += bp(nz(n), 3000, 9000) * 0.06 * (t / 0.9)
    return norm(lp(x * np.clip(t / 0.05, 0, 1), 9000), 0.7)


def ready():
    b = buf(0.5)
    put(b, J.bell_tone(1760.0, 0.4, 9.0), 0, 0.8); put(b, thud(100, 0.1, 0.6), 0); put(b, tick(3400, 0.8), 0)
    return norm(b, 0.8)


def tube_in():
    b = buf(0.5)
    put(b, scrape(0.25, 300, 2200, 0.5), 0); put(b, thud(70, 0.25, 1.6), 0.25); put(b, ring(380, 0.2, 18, 0.5), 0.25)
    return norm(b, 0.95)


def latch():
    b = buf(0.2)
    put(b, tick(2000, 1.0), 0); put(b, thud(150, 0.06, 0.6), 0); put(b, tick(2800, 0.7), 0.05)
    return norm(b, 0.8)


def ramrod():
    n = int(0.7 * SR); t = T(n)
    x = bp(nz(n), 500, 2600) * (0.5 + 0.5 * np.sin(2 * np.pi * 5 * t)) ** 1.5 * np.sin(np.pi * np.clip(t / 0.7, 0, 1)) ** 0.5
    return norm(x * 0.9, 0.55)


def tamp():
    b = buf(0.3)
    put(b, thud(190, 0.12, 1.0), 0); put(b, thud(170, 0.12, 0.9), 0.12); put(b, burst(0.04, 500, 3000, 60, 0.4), 0)
    return norm(b, 0.8)


def gurgle():
    b = buf(0.9); rng = np.random.default_rng(9)
    for i in range(12):
        f0 = float(rng.uniform(350, 650)); n = int(0.07 * SR); t = T(n)
        blip = np.sin(2 * np.pi * np.cumsum(f0 * (1 + 2.0 * t / 0.07)) / SR) * np.exp(-t * 35)
        put(b, blip, 0.03 + i * 0.065 + float(rng.uniform(0, 0.02)), 0.8)
    put(b, bp(nz(len(b)), 300, 1200) * 0.06 * np.sin(np.pi * np.clip(T(len(b)) / 0.9, 0, 1)), 0)
    return norm(b, 0.7)


def pump_toy():
    n = int(0.3 * SR); t = T(n)
    x = np.sin(2 * np.pi * np.cumsum(620 + 480 * np.clip(t / 0.12, 0, 1) - 200 * np.clip((t - 0.12) / 0.15, 0, 1)) / SR) * 0.35 * np.exp(-t * 7)
    x += burst(0.3, 1500, 6000, 12, 0.5)
    b = buf(0.3); b[:n] += x
    put(b, tick(1500, 0.6), 0.14)
    return norm(b, 0.65)


def plastic():
    b = buf(0.2)
    put(b, tick(1500, 1.0, 110), 0); put(b, thud(300, 0.05, 0.5), 0); put(b, tick(1200, 0.5, 110), 0.07)
    return norm(b, 0.7)


def creak():
    n = int(0.6 * SR); t = T(n)
    f = 140 + 160 * (t / 0.6) + 8 * np.sin(2 * np.pi * 25 * t)
    saw = ((np.cumsum(f) / SR) % 1.0) * 2 - 1
    return norm(lp(saw, 1800) * np.sin(np.pi * np.clip(t / 0.6, 0, 1)) ** 0.7 * 0.6, 0.5)


def dry():
    b = buf(0.12)
    put(b, tick(2300, 0.9, 180), 0); put(b, thud(220, 0.05, 0.3), 0)
    return norm(b, 0.6)


SOUNDS = {k: v for k, v in list(globals().items()) if callable(v) and k.startswith("shot_")}
for _n in ("mag_out", "mag_in", "slide", "shell", "pump", "cyl_open", "cyl_close", "bolt_open", "bolt_close", "box_open", "belt",
           "box_close", "charge", "ready", "tube_in", "latch", "ramrod", "tamp", "gurgle", "pump_toy", "plastic", "creak", "dry"):
    SOUNDS[_n] = globals()[_n]


def save_ogg(name, x):
    os.makedirs(OUT, exist_ok=True)
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, name + ".wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-c:a", "libvorbis", "-q:a", "4",
                        os.path.join(OUT, name + ".ogg")], check=True)


def main():
    sj = os.path.join(ASSETS, "sounds.json")
    data = json.load(open(sj, encoding="utf-8")) if os.path.exists(sj) else {}
    for name, fn in SOUNDS.items():
        x = fn()
        save_ogg(name, x)
        data["gun." + name] = {"sounds": [{"name": "cutemod:gun/" + name, "stream": False}]}
        print("%-10s %.2f s  peak %.2f" % (name, len(x) / SR, np.max(np.abs(x))))
    json.dump(data, open(sj, "w", encoding="utf-8"), indent=2)


if __name__ == "__main__":
    main()
