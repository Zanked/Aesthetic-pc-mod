package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.nio.file.Files;
import java.nio.file.Path;

/** Desktop wallpapers. The chosen one is remembered in cutemod_wallpaper.txt. */
public final class Wallpaper {
    public static final int COUNT = 51; // 0-5 are free (Settings), 6-11 and 13-18 come from the shop, 12 is the Halloween one, 19-21 are the Frutiger Aero ones, 22-25 are the genre-mood ones (neon city, pop diamonds, crimson night, punk stage)
    public static final int BASE = 6;
    /** The tunnel of the video 666: it is shown for a while (see startEcho), it is not a wallpaper the player can pick. */
    public static final int ECHO = 51;
    /** The wallpaper of the prize theme "The Stranger" (see {@link Theme#stranger}): like Blood, it stays while the theme is on. */
    public static final int STRANGER = 52;
    private static long echoUntil;
    private static int index;
    private static int gen = -1;

    private Wallpaper() {}

    /** The chosen wallpaper is saved on the server. */
    public static int get() {
        if (gen != Store.gen()) {
            gen = Store.gen();
            index = 0;
            try {
                String s = Store.read("wallpaper");
                if (s != null) index = Math.floorMod(Integer.parseInt(s.trim()), COUNT);
            } catch (Exception ignored) {
            }
        }
        return index;
    }

    /** The video 666 was watched to the end: the desktop falls into a red tunnel for this many seconds. */
    public static void startEcho(int seconds) { echoUntil = System.currentTimeMillis() + seconds * 1000L; Hell.startAward(seconds); }   // the crimson look runs as long as the tunnel

    /** What the desktop shows now: the chosen wallpaper, or the echo of the video 666. */
    public static int shown() { return Theme.stranger() ? STRANGER : locked() || System.currentTimeMillis() < echoUntil ? ECHO : get(); }

    /** The bought theme "Blood" has its own wallpaper, the red tunnel of the video 666: it stays while the theme is on and cannot be changed (the chosen one comes back with the old theme). */
    public static boolean locked() { return Theme.bloodTheme() || Theme.stranger(); }

    public static void set(int i) {
        if (locked()) return;
        get();
        index = Math.floorMod(i, COUNT);
        Store.write("wallpaper", Integer.toString(index));
    }

    private static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    /**
     * The desktop wallpaper: the simple still ones are drawn directly, the busy and animated ones (12 and up, up to 5000
     * rectangles a frame) go through a texture that is redrawn 20 times a second, so the screen gets a single quad.
     */
    public static void drawCached(GuiGraphics g, int x, int y, int w, int h, int body, int idx) {
        if (idx < 12) { draw(g, x, y, w, h, body, idx); return; }
        TexCache.Tex t = TexCache.get("wallpaper", w, h);
        TexCache.renderStep(t, idx, 0, 0, c -> draw(c, 0, 0, w, h, body, idx));
        TexCache.blit(g, t, x, y);
    }

    /** Draws wallpaper number idx inside the box x,y,w,h (everything stays inside the box). */
    public static void draw(GuiGraphics g, int x, int y, int w, int h, int body, int idx) {
        switch (idx) {
            case 1 -> { // sky
                g.fillGradient(x, y, x + w, y + h, 0xFF9ED8FF, 0xFFEAF7FF);
                for (int i = 0; i < 3; i++) {
                    int cx = x + (i * 97 + 20) % Math.max(1, w - 40), cy = y + 6 + i * (h / 4);
                    g.fill(cx, cy + 3, cx + 30, cy + 11, 0xCCFFFFFF);
                    g.fill(cx + 6, cy, cx + 22, cy + 5, 0xCCFFFFFF);
                }
            }
            case 2 -> { // mint
                g.fillGradient(x, y, x + w, y + h, 0xFFD6F5DE, 0xFF8FD39A);
                for (int i = 0; i < 14; i++) {
                    int dx = x + (i * 61 + 17) % Math.max(1, w - 3), dy = y + (i * 37 + 9) % Math.max(1, h - 3);
                    g.fill(dx, dy, dx + 3, dy + 3, 0x66FFFFFF);
                }
            }
            case 3 -> { // sunset
                g.fillGradient(x, y, x + w, y + h, 0xFFFFC38A, 0xFFE5668A);
                disc(g, x + w * 3 / 4, y + h * 2 / 3, Math.min(w, h) / 6, 0xFFFFF0B0);
            }
            case 4 -> { // night
                g.fillGradient(x, y, x + w, y + h, 0xFF1B1840, 0xFF4A3A66);
                for (int i = 0; i < 24; i++) {
                    int sx = x + (i * 53 + 11) % Math.max(1, w - 2), sy = y + (i * 29 + 5) % Math.max(1, h - 2);
                    int s = i % 5 == 0 ? 2 : 1;
                    g.fill(sx, sy, sx + s, sy + s, 0xCCFFFFFF);
                }
                disc(g, x + w / 5, y + h / 4, Math.min(w, h) / 9, 0xFFFFF0C0);
            }
            case 5 -> { // candy stripes
                for (int r = 0; r * 8 < h; r++) {
                    g.fill(x, y + r * 8, x + w, Math.min(y + h, y + r * 8 + 8), r % 2 == 0 ? 0xFFFFD6E8 : 0xFFFFFFFF);
                }
            }
            case 6 -> { // starry space
                g.fillGradient(x, y, x + w, y + h, 0xFF0B0F2E, 0xFF2A2A6A);
                for (int i = 0; i < 30; i++) {
                    int sx = x + (i * 47 + 13) % Math.max(1, w - 2), sy = y + (i * 31 + 7) % Math.max(1, h - 2);
                    g.fill(sx, sy, sx + (i % 7 == 0 ? 2 : 1), sy + (i % 7 == 0 ? 2 : 1), 0xFFFFFFFF);
                }
                for (int k = 0; k < Math.min(w, h) / 3; k++) g.fill(x + w * 3 / 4 - k, y + h / 5 + k / 2, x + w * 3 / 4 - k + 1, y + h / 5 + k / 2 + 1, 0xAAFFFFFF);
            }
            case 7 -> { // hearts
                g.fillGradient(x, y, x + w, y + h, 0xFFFFE0EC, 0xFFFFB3CF);
                for (int i = 0; i < 18; i++) {
                    int hx = x + (i * 53 + 9) % Math.max(1, w - 8), hy = y + (i * 29 + 4) % Math.max(1, h - 8);
                    int c = i % 2 == 0 ? 0xAAFF5C93 : 0xAAFFFFFF;
                    g.fill(hx, hy + 1, hx + 5, hy + 3, c);
                    g.fill(hx + 1, hy, hx + 2, hy + 1, c);
                    g.fill(hx + 3, hy, hx + 4, hy + 1, c);
                    g.fill(hx + 1, hy + 3, hx + 4, hy + 4, c);
                    g.fill(hx + 2, hy + 4, hx + 3, hy + 5, c);
                }
            }
            case 8 -> { // honeycomb
                g.fillGradient(x, y, x + w, y + h, 0xFFFFE9A0, 0xFFFFC832);
                for (int r = 0; r * 7 < h; r++) {
                    for (int c = 0; c * 12 < w; c++) {
                        int hx = x + c * 12 + (r % 2) * 6, hy = y + r * 7;
                        if (hx + 7 > x + w || hy + 5 > y + h) continue;
                        g.fill(hx + 1, hy, hx + 6, hy + 1, 0x66B98A10);
                        g.fill(hx, hy + 1, hx + 7, hy + 4, 0x33B98A10);
                        g.fill(hx + 1, hy + 4, hx + 6, hy + 5, 0x66B98A10);
                    }
                }
            }
            case 9 -> { // rainbow
                int[] rc = {0xFFFF8A8A, 0xFFFFB27A, 0xFFFFE27A, 0xFF9AE6A0, 0xFF8AD0FF, 0xFFA89AFF, 0xFFE59AFF};
                for (int i = 0; i < 7; i++) g.fill(x, y + i * h / 7, x + w, y + (i + 1) * h / 7, rc[i]);
                g.fill(x + w / 8, y + h / 6, x + w / 8 + Math.max(4, w / 5), y + h / 6 + Math.max(2, h / 12), 0xCCFFFFFF);
                g.fill(x + w * 2 / 3, y + h * 3 / 5, x + w * 2 / 3 + Math.max(4, w / 4), y + h * 3 / 5 + Math.max(2, h / 12), 0xCCFFFFFF);
            }
            case 10 -> { // ocean
                g.fillGradient(x, y, x + w, y + h, 0xFF7FD8FF, 0xFF1E5FA8);
                for (int r = 6; r < h; r += 8) {
                    int off = ((r / 8) % 2) * 5;
                    for (int c = 0; c + off + 6 <= w; c += 10) g.fill(x + c + off, y + r, x + c + off + 6, y + r + 1, 0x55FFFFFF);
                }
                for (int i = 0; i < 6; i++) {
                    int bx = x + (i * 41 + 9) % Math.max(1, w - 3), by = y + (i * 27 + 5) % Math.max(1, h - 3);
                    g.fill(bx, by, bx + 2, by + 2, 0x88FFFFFF);
                }
            }
            case 11 -> { // night city
                g.fillGradient(x, y, x + w, y + h, 0xFF2A1A4A, 0xFFE56A8A);
                for (int b = 0; b * 12 < w; b++) {
                    int bx = x + b * 12, bh = h / 3 + (b * 17) % Math.max(1, h / 3);
                    int bw = Math.min(10, x + w - bx);
                    g.fill(bx, y + h - bh, bx + bw, y + h, 0xFF14122E);
                    for (int wy = y + h - bh + 3; wy < y + h - 3; wy += 5) {
                        for (int wx = bx + 2; wx + 2 <= bx + bw - 1; wx += 4) {
                            if (((wx + wy + b) % 3) == 0) g.fill(wx, wy, wx + 2, wy + 2, 0xFFFFE680);
                        }
                    }
                }
            }
            case 12 -> Halloween.wallpaper(g, x, y, w, h);
            case 13, 14, 15, 16, 17, 18 -> WallpapersExtra.draw(g, x, y, w, h, idx); // newer shop wallpapers
            case 19, 20, 21 -> AeroWallpapers.draw(g, x, y, w, h, idx); // Frutiger Aero wallpapers
            case 22, 23, 24, 25 -> StyleWallpapers.draw(g, x, y, w, h, idx); // genre-mood wallpapers
            case 26, 27, 28, 29 -> CheapWallpapers.draw(g, x, y, w, h, idx); // the cheap simple ones
            case 30, 31, 32, 33, 34 -> AnimeWallpapers.draw(g, x, y, w, h, idx); // animated: girls, forests, a campfire
            case 35, 36, 37, 38, 39, 40 -> FunWallpapers.draw(g, x, y, w, h, idx); // animated: aquarium, space, rainy city, beach, arcade, clouds
            case 41, 42, 43, 44 -> StoryWallpapers.draw(g, x, y, w, h, idx); // animated: fairy tale, block world, koi pond, candy land
            case 45, 46, 47 -> NewWallpapers.draw(g, x, y, w, h, idx); // golden autumn, a dark blue forest, rain on a window
            case 48, 49, 50 -> YellowWallpapers.draw(g, x, y, w, h, idx); // yellow: sunflowers, little chicks, honey bubbles
            case ECHO -> HellWallpaper.draw(g, x, y, w, h); // the echo of the video 666 (not in the list)
            case STRANGER -> strangerWall(g, x, y, w, h);
            default -> { // the computer's own color
                g.fillGradient(x, y, x + w, y + h, App.mix(body, 0xFFFFFF, 0.6f), App.mix(body, 0x3A2A4A, 0.35f));
                for (int i = 0; i < 14; i++) {
                    int dx = x + (i * 61 + 17) % Math.max(1, w - 3), dy = y + (i * 37 + 9) % Math.max(1, h - 3);
                    g.fill(dx, dy, dx + 3, dy + 3, 0x30FFFFFF);
                }
            }
        }
    }

    /** A violet night: twinkling stars, a crescent moon, two dark hills and a lantern with a warm glow. */
    private static void strangerWall(GuiGraphics g, int x, int y, int w, int h) {
        int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        g.fillGradient(x, y, x + w, y + h, 0xFF080722, 0xFF2A1F5C);
        g.fillGradient(x, y + h * 55 / 100, x + w, y + h, 0x00B79CFF, 0x44B79CFF);
        for (int i = 0; i < 70; i++) {
            int sx = x + (i * 53 + 11) % Math.max(1, w - 2), sy = y + (i * 29 + 5) % Math.max(1, h * 70 / 100);
            int c = (t / 6 + i * 7) % 12 < 2 ? 0x66FFFFFF : (i % 9 == 0 ? 0xFFFFD866 : 0xCCFFFFFF);
            int s = i % 11 == 0 ? 2 : 1;
            g.fill(sx, sy, sx + s, sy + s, c);
        }
        int mr = Math.max(5, Math.min(w, h) / 9), mx = x + w * 78 / 100, my = y + h * 24 / 100;
        disc(g, mx, my, mr + 3, 0x22FFF0C0);
        disc(g, mx, my, mr, 0xFFFFF0C0);
        disc(g, mx + mr / 3, my - mr / 4, mr, App.mix(0xFF080722, 0xFF2A1F5C, 0.24F));      // the cut that makes a crescent
        for (int cx = 0; cx < w; cx++) {
            int far = y + h * 70 / 100 + (int) Math.round(Math.sin(cx / 55.0 + 2) * 8);
            g.fill(x + cx, far, x + cx + 1, y + h, 0xFF171046);
            int near = y + h * 80 / 100 + (int) Math.round(Math.sin(cx / 38.0) * 6 + Math.sin(cx / 15.0 + 1) * 2);
            g.fill(x + cx, near, x + cx + 1, y + h, 0xFF0C0926);
        }
        int lx = x + w * 26 / 100, ly = y + h * 80 / 100 - 4;
        g.fill(lx, ly, lx + 1, ly + 12, 0xFF3A2C7A);
        int fl = 8 + (t / 8) % 3;
        disc(g, lx, ly, fl, 0x22FFD866);
        disc(g, lx, ly, 5, 0x44FFD866);
        g.fill(lx - 1, ly - 1, lx + 2, ly + 2, 0xFFFFE680);
    }
}
