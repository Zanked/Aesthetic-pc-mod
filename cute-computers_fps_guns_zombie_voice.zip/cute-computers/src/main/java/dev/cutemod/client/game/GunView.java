package dev.cutemod.client.game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * First-person guns for the Zombie Shooter, drawn like in a modern shooter: you look at the gun from BEHIND,
 * the barrel points away from you into the crosshair, a gloved right hand holds the grip and the left hand holds the fore-end.
 * <p>
 * Every gun is a handful of 3D boxes (see {@link #model(int)}); a tiny software rasterizer (perspective, z-buffer, flat shading,
 * a dark outline) draws them into a W x H pixel buffer, so it stays pixel art. It has no Minecraft classes in it on purpose.
 * Units are meters-ish, x right, y up, z forward (away from you). The origin of a gun is its pistol grip.
 */
final class GunView {
    static final int W = 220, H = 140;           // the same as MiniGame.W / MiniGame.H
    private static final float FOCAL = 150F, NEAR = 0.035F;
    private static final int OUTLINE = 0xFF0B0B10;

    // ---------- colors: one letter per color; A / a = the accent color of the gun (pink when Pack-a-Punched) ----------
    private static final int[] PAL = new int[128];
    static {
        PAL['k'] = 0xFF121216; PAL['d'] = 0xFF2A2A32; PAL['m'] = 0xFF4A4A56; PAL['l'] = 0xFF7A7A88; PAL['h'] = 0xFFB8B8C8;
        PAL['w'] = 0xFF4A2E18; PAL['x'] = 0xFF6E4624; PAL['Y'] = 0xFF95683A;
        PAL['g'] = 0xFF2A3526; PAL['o'] = 0xFF3F4A38; PAL['O'] = 0xFF5E6B54;
        PAL['G'] = 0xFF25252D;                    // the gloves
        PAL['J'] = 0xFF3C4A38;                    // the sleeves
        PAL['r'] = 0xFFC03030; PAL['R'] = 0xFFF06060; PAL['y'] = 0xFFD8B040;
        PAL['b'] = 0xFF70C0FF; PAL['B'] = 0xFF2A5A90; PAL['e'] = 0xFF38C0C0; PAL['E'] = 0xFFB8FFFF;
        PAL['p'] = 0xFF4A3A6A; PAL['P'] = 0xFF7A64A8; PAL['u'] = 0xFF2A1E3E;
        PAL['N'] = 0xFF2A3A6A; PAL['M'] = 0xFF4A6AB0; PAL['i'] = 0xFF9CC8FF; PAL['f'] = 0xFFE08A30;
        PAL['W'] = 0xFFEAEAEA;
    }

    // ---------- the parts of a gun ----------
    private static final class Part {
        final char c; final float x, y, z, w, h, l;     // center and size
        final float[] rot;                              // rotation of the part around its own center
        Part(char c, float x, float y, float z, float w, float h, float l, float rx, float ry, float rz) {
            this.c = c; this.x = x; this.y = y; this.z = z; this.w = w; this.h = h; this.l = l;
            this.rot = (rx == 0 && ry == 0 && rz == 0) ? null : mul(rotY(ry), mul(rotX(rx), rotZ(rz)));
        }
    }

    static final class Model {
        final List<Part> parts = new ArrayList<>();
        float mx, my, mz;                // the muzzle (the flash is drawn there)
        float rx, ry, rz;                // the right hand (on the grip)
        float lx, ly, lz;                // the left hand (on the fore-end)
        boolean cup;                     // pistols: the left hand cups the right one instead of holding a fore-end
        boolean noLeft;                  // no second hand (not used yet)
        float dz;                        // the gun is pushed this much forward (big guns would fill the screen)

        Model b(char c, float x, float y, float z, float w, float h, float l) {
            parts.add(new Part(c, x, y, z, w, h, l, 0, 0, 0)); return this;
        }
        /** A box turned around its own center: degrees around x (pitch, + lifts the front), y (yaw, + turns right), z (roll). */
        Model r(char c, float x, float y, float z, float w, float h, float l, float rx, float ry, float rz) {
            parts.add(new Part(c, x, y, z, w, h, l, rx, ry, rz)); return this;
        }
        /** A round tube along the barrel direction (a box + a smaller box turned 45 degrees = an octagon). */
        Model t(char c, float x, float y, float z, float d, float l) {
            b(c, x, y, z, d, d, l);
            return r(c, x, y, z, d * 0.8F, d * 0.8F, l, 0, 0, 45);
        }
        /** An upright disc (the axis is vertical): the drum of a shotgun. */
        Model disc(char c, float x, float y, float z, float d, float h) {
            b(c, x, y, z, d, h, d);
            return r(c, x, y, z, d * 0.8F, h, d * 0.8F, 0, 45, 0);
        }
        Model muzzle(float x, float y, float z) { mx = x; my = y; mz = z; return this; }
        Model hands(float rx, float ry, float rz, float lx, float ly, float lz) {
            this.rx = rx; this.ry = ry; this.rz = rz; this.lx = lx; this.ly = ly; this.lz = lz; return this;
        }
    }

    // ---------- the guns, in the order of the weapons array of ZombieShooter ----------
    private static final Model[] MODELS = new Model[17];

    private static Model model(int gi) {
        Model m = MODELS[gi];
        if (m == null) MODELS[gi] = m = build(gi);
        return m;
    }

    private static Model build(int gi) {
        Model m = new Model();
        switch (gi) {
            case 0 -> {      // pistol
                m.cup = true;
                m.r('d', 0, -0.050F, -0.020F, 0.034F, 0.095F, 0.048F, -14, 0, 0)          // grip
                 .b('d', 0, 0.004F, 0.060F, 0.032F, 0.030F, 0.170F)                         // frame
                 .b('m', 0, 0.038F, 0.070F, 0.034F, 0.038F, 0.200F)                         // slide
                 .b('l', 0, 0.059F, 0.070F, 0.012F, 0.004F, 0.180F)                         // slide top
                 .b('d', 0, 0.040F, 0.178F, 0.020F, 0.022F, 0.030F)                         // barrel tip
                 .b('d', 0, -0.018F, 0.044F, 0.030F, 0.006F, 0.052F)                        // trigger guard
                 .b('k', 0, 0.066F, 0.150F, 0.007F, 0.009F, 0.010F)                         // front sight
                 .b('k', -0.013F, 0.066F, -0.012F, 0.008F, 0.010F, 0.012F)
                 .b('k', 0.013F, 0.066F, -0.012F, 0.008F, 0.010F, 0.012F)                   // rear sight
                 .b('A', 0, 0.020F, 0.070F, 0.036F, 0.006F, 0.120F)                         // accent stripe
                 .muzzle(0, 0.040F, 0.195F).hands(0, -0.050F, -0.020F, -0.026F, -0.062F, 0.010F);
            }
            case 1 -> {      // assault rifle
                m.b('d', 0, 0.000F, 0.020F, 0.040F, 0.050F, 0.250F)                         // lower receiver
                 .b('m', 0, 0.042F, 0.050F, 0.044F, 0.036F, 0.320F)                         // upper receiver
                 .b('k', 0, 0.066F, 0.050F, 0.022F, 0.014F, 0.300F)                         // top rail
                 .b('k', 0, 0.084F, -0.070F, 0.020F, 0.026F, 0.016F)                        // rear sight
                 .b('k', 0, 0.082F, 0.300F, 0.012F, 0.034F, 0.012F)                         // front sight
                 .b('A', 0, 0.030F, 0.260F, 0.050F, 0.052F, 0.210F)                         // handguard
                 .b('a', 0, 0.058F, 0.260F, 0.030F, 0.008F, 0.210F)
                 .b('k', 0, 0.040F, 0.450F, 0.016F, 0.016F, 0.150F)                         // barrel
                 .b('d', 0, 0.040F, 0.540F, 0.024F, 0.024F, 0.050F)                         // flash hider
                 .r('d', 0, -0.082F, 0.070F, 0.030F, 0.100F, 0.046F, 9, 0, 0)               // magazine
                 .r('d', 0, -0.060F, -0.040F, 0.032F, 0.085F, 0.042F, -16, 0, 0)            // grip
                 .b('A', 0, 0.010F, -0.230F, 0.044F, 0.070F, 0.200F)                        // stock
                 .b('a', 0, 0.046F, -0.230F, 0.046F, 0.014F, 0.200F)
                 .b('d', 0, 0.034F, -0.130F, 0.030F, 0.030F, 0.060F)
                 .muzzle(0, 0.040F, 0.575F).hands(0, -0.052F, -0.015F, 0, -0.030F, 0.270F);
            }
            case 2 -> {      // pump shotgun
                m.b('m', 0, 0.012F, 0.030F, 0.040F, 0.052F, 0.220F)                         // receiver
                 .b('l', 0, 0.040F, 0.030F, 0.020F, 0.005F, 0.200F)
                 .t('d', 0, 0.036F, 0.400F, 0.028F, 0.480F)                                 // barrel
                 .t('d', 0, 0.003F, 0.360F, 0.026F, 0.400F)                                 // magazine tube
                 .b('A', 0, -0.008F, 0.300F, 0.052F, 0.044F, 0.150F)                        // the pump
                 .b('a', 0, 0.016F, 0.300F, 0.050F, 0.006F, 0.150F)
                 .b('y', 0, 0.056F, 0.620F, 0.008F, 0.010F, 0.008F)                         // bead
                 .r('A', 0, -0.004F, -0.200F, 0.046F, 0.075F, 0.320F, -4, 0, 0)             // wooden stock
                 .r('d', 0, -0.052F, -0.035F, 0.030F, 0.070F, 0.040F, -16, 0, 0)            // grip
                 .muzzle(0, 0.036F, 0.645F).hands(0, -0.052F, -0.015F, 0, -0.026F, 0.300F);
            }
            case 3 -> {      // SMG
                m.b('d', 0, 0.016F, 0.050F, 0.042F, 0.056F, 0.270F)                         // body
                 .b('m', 0, 0.047F, 0.050F, 0.030F, 0.010F, 0.250F)
                 .b('A', 0, 0.026F, 0.250F, 0.044F, 0.044F, 0.120F)                         // shroud
                 .b('a', 0, 0.050F, 0.250F, 0.030F, 0.007F, 0.120F)
                 .b('k', 0, 0.030F, 0.350F, 0.014F, 0.014F, 0.070F)                         // barrel
                 .b('d', 0, -0.090F, 0.085F, 0.028F, 0.130F, 0.040F)                        // long magazine
                 .r('d', 0, -0.060F, -0.035F, 0.032F, 0.080F, 0.040F, -14, 0, 0)            // grip
                 .b('m', 0, 0.026F, -0.160F, 0.030F, 0.030F, 0.220F)                        // wire stock
                 .b('m', 0, 0.000F, -0.255F, 0.050F, 0.050F, 0.016F)
                 .b('k', 0, 0.060F, 0.300F, 0.010F, 0.020F, 0.010F)
                 .b('k', 0, 0.060F, -0.040F, 0.014F, 0.018F, 0.012F)
                 .muzzle(0, 0.030F, 0.390F).hands(0, -0.050F, -0.012F, 0, -0.030F, 0.230F);
            }
            case 4 -> {      // magnum revolver
                m.cup = true;
                m.r('x', 0, -0.052F, -0.026F, 0.038F, 0.098F, 0.052F, -18, 0, 0)            // wooden grip
                 .b('m', 0, 0.010F, 0.040F, 0.036F, 0.052F, 0.130F)                         // frame
                 .t('l', 0, 0.026F, 0.085F, 0.056F, 0.080F)                                 // cylinder
                 .b('A', 0, 0.026F, 0.085F, 0.060F, 0.012F, 0.040F)                         // accent ring on the cylinder
                 .b('m', 0, 0.036F, 0.230F, 0.028F, 0.032F, 0.210F)                         // barrel
                 .b('l', 0, 0.056F, 0.230F, 0.008F, 0.010F, 0.210F)                         // rib
                 .b('d', 0, 0.012F, 0.200F, 0.022F, 0.022F, 0.140F)                         // under-lug
                 .b('d', 0, 0.056F, -0.028F, 0.010F, 0.022F, 0.016F)                        // hammer
                 .b('k', 0, 0.056F, 0.330F, 0.008F, 0.012F, 0.010F)
                 .b('d', 0, -0.016F, 0.050F, 0.030F, 0.006F, 0.050F)
                 .muzzle(0, 0.036F, 0.340F).hands(0, -0.054F, -0.026F, -0.028F, -0.064F, 0.008F);
            }
            case 5 -> {      // sniper
                m.b('m', 0, 0.020F, 0.040F, 0.056F, 0.056F, 0.240F)                         // receiver
                 .b('d', 0, 0.036F, 0.560F, 0.020F, 0.020F, 0.620F)                         // long barrel
                 .b('k', 0, 0.036F, 0.880F, 0.032F, 0.032F, 0.070F)                         // muzzle brake
                 .t('k', 0, 0.098F, 0.070F, 0.046F, 0.240F)                                 // scope tube
                 .b('k', 0, 0.098F, -0.050F, 0.062F, 0.062F, 0.050F)                        // scope back bell
                 .b('B', 0, 0.098F, -0.077F, 0.036F, 0.036F, 0.006F)                        // lens
                 .b('k', 0, 0.098F, 0.200F, 0.062F, 0.062F, 0.040F)                         // scope front bell
                 .b('d', 0, 0.066F, 0.020F, 0.020F, 0.022F, 0.020F)                         // scope mounts
                 .b('d', 0, 0.066F, 0.130F, 0.020F, 0.022F, 0.020F)
                 .b('l', 0.034F, 0.048F, -0.020F, 0.044F, 0.010F, 0.010F)                   // bolt handle
                 .b('l', 0.058F, 0.048F, -0.020F, 0.016F, 0.016F, 0.016F)
                 .b('A', 0, 0.006F, 0.330F, 0.044F, 0.046F, 0.300F)                         // fore-end
                 .r('A', 0, 0.006F, -0.225F, 0.046F, 0.090F, 0.340F, -3, 0, 0)              // stock
                 .b('a', 0, 0.056F, -0.225F, 0.040F, 0.020F, 0.200F)                        // cheek rest
                 .b('d', 0, -0.036F, 0.040F, 0.026F, 0.040F, 0.070F)                        // magazine
                 .r('d', 0, -0.052F, -0.040F, 0.030F, 0.075F, 0.040F, -14, 0, 0)
                 .muzzle(0, 0.036F, 0.920F).hands(0, -0.050F, -0.016F, 0, -0.024F, 0.340F);
                m.dz = 0.04F;
            }
            case 6 -> {      // ray gun
                m.b('u', 0, 0.020F, 0.060F, 0.054F, 0.064F, 0.240F)                         // body
                 .b('P', 0, 0.055F, 0.060F, 0.020F, 0.008F, 0.230F)
                 .t('d', 0, 0.034F, 0.320F, 0.030F, 0.400F)                                 // emitter
                 .b('A', 0, 0.034F, 0.220F, 0.074F, 0.074F, 0.016F)                         // coils
                 .b('A', 0, 0.034F, 0.300F, 0.074F, 0.074F, 0.016F)
                 .b('A', 0, 0.034F, 0.380F, 0.074F, 0.074F, 0.016F)
                 .b('E', 0, 0.034F, 0.520F, 0.040F, 0.040F, 0.030F)                         // glowing tip
                 .b('P', 0, 0.090F, 0.080F, 0.018F, 0.052F, 0.180F)                         // fin
                 .b('E', -0.030F, 0.020F, 0.050F, 0.008F, 0.034F, 0.090F)                   // energy cell
                 .b('E', 0, 0.082F, -0.030F, 0.020F, 0.012F, 0.020F)
                 .r('u', 0, -0.052F, -0.030F, 0.034F, 0.080F, 0.044F, -16, 0, 0)
                 .muzzle(0, 0.034F, 0.545F).hands(0, -0.052F, -0.018F, 0, -0.024F, 0.280F);
            }
            case 7 -> {      // LMG
                m.b('m', 0, 0.024F, 0.050F, 0.062F, 0.074F, 0.340F)                         // body
                 .b('d', 0, 0.066F, 0.060F, 0.054F, 0.016F, 0.300F)                         // top cover
                 .b('k', 0, 0.092F, 0.110F, 0.022F, 0.030F, 0.100F)                         // carry handle
                 .b('A', 0, 0.036F, 0.400F, 0.052F, 0.052F, 0.200F)                         // barrel shroud
                 .b('k', 0, 0.036F, 0.570F, 0.018F, 0.018F, 0.180F)
                 .b('d', 0, 0.036F, 0.680F, 0.028F, 0.028F, 0.040F)
                 .b('a', 0, -0.082F, 0.040F, 0.070F, 0.088F, 0.110F)                        // ammo box
                 .b('A', 0, -0.082F, 0.040F, 0.062F, 0.080F, 0.100F)
                 .b('y', -0.040F, -0.020F, 0.010F, 0.014F, 0.014F, 0.060F)                  // belt
                 .r('d', -0.022F, -0.004F, 0.500F, 0.010F, 0.010F, 0.090F, -75, 0, 0)       // folded bipod
                 .r('d', 0.022F, -0.004F, 0.500F, 0.010F, 0.010F, 0.090F, -75, 0, 0)
                 .r('d', 0, -0.060F, -0.050F, 0.034F, 0.085F, 0.042F, -14, 0, 0)
                 .b('A', 0, 0.010F, -0.260F, 0.052F, 0.085F, 0.260F)                        // stock
                 .muzzle(0, 0.036F, 0.705F).hands(0, -0.052F, -0.022F, 0, -0.032F, 0.320F);
                m.dz = 0.05F;
            }
            case 8 -> {      // combat shotgun with a drum
                m.b('d', 0, 0.016F, 0.040F, 0.048F, 0.056F, 0.230F)                         // receiver
                 .b('m', 0, 0.050F, 0.040F, 0.030F, 0.008F, 0.220F)
                 .t('m', 0, 0.034F, 0.290F, 0.032F, 0.300F)                                 // barrel
                 .b('A', 0, 0.034F, 0.250F, 0.044F, 0.040F, 0.200F)                         // heat shield
                 .b('a', 0, 0.056F, 0.250F, 0.030F, 0.007F, 0.200F)
                 .disc('A', 0, -0.074F, 0.090F, 0.100F, 0.056F)                             // drum
                 .disc('a', 0, -0.046F, 0.090F, 0.060F, 0.012F)
                 .b('A', 0, -0.004F, 0.320F, 0.052F, 0.040F, 0.100F)                        // pump
                 .b('d', 0, 0.006F, -0.190F, 0.044F, 0.075F, 0.230F)                        // stock
                 .r('d', 0, -0.056F, -0.040F, 0.032F, 0.075F, 0.040F, -15, 0, 0)
                 .muzzle(0, 0.034F, 0.450F).hands(0, -0.052F, -0.018F, 0, -0.024F, 0.320F);
            }
            case 9 -> {      // rocket launcher
                m.t('o', 0, 0.045F, 0.200F, 0.090F, 0.560F)                                 // tube
                 .t('d', 0, 0.045F, -0.090F, 0.106F, 0.040F)                                // rear flare
                 .t('A', 0, 0.045F, 0.420F, 0.098F, 0.040F)                                 // colored band
                 .t('d', 0, 0.045F, 0.300F, 0.098F, 0.020F)
                 .t('r', 0, 0.045F, 0.490F, 0.064F, 0.040F)                                 // rocket
                 .t('R', 0, 0.045F, 0.520F, 0.040F, 0.030F)
                 .b('k', 0, 0.112F, 0.120F, 0.012F, 0.040F, 0.018F)                         // sight
                 .b('d', 0, 0.040F, -0.140F, 0.060F, 0.020F, 0.130F)                        // bracket
                 .r('d', 0, -0.040F, 0.000F, 0.032F, 0.090F, 0.042F, -14, 0, 0)             // rear grip
                 .b('d', 0, -0.030F, 0.270F, 0.030F, 0.080F, 0.036F)                        // front grip
                 .muzzle(0, 0.045F, 0.540F).hands(0, -0.050F, 0.000F, 0, -0.040F, 0.270F);
                m.dz = 0.16F;
            }
            case 10 -> {     // railgun
                m.b('N', 0, 0.026F, 0.050F, 0.056F, 0.072F, 0.250F)                         // body
                 .b('M', 0, 0.064F, 0.050F, 0.022F, 0.008F, 0.230F)
                 .b('d', -0.022F, 0.040F, 0.360F, 0.012F, 0.034F, 0.560F)                   // the two rails
                 .b('d', 0.022F, 0.040F, 0.360F, 0.012F, 0.034F, 0.560F)
                 .b('b', 0, 0.040F, 0.360F, 0.024F, 0.012F, 0.560F)                         // glowing strip
                 .b('A', 0, 0.040F, 0.230F, 0.072F, 0.072F, 0.012F)                         // coils
                 .b('A', 0, 0.040F, 0.320F, 0.072F, 0.072F, 0.012F)
                 .b('A', 0, 0.040F, 0.410F, 0.072F, 0.072F, 0.012F)
                 .b('A', 0, 0.040F, 0.500F, 0.072F, 0.072F, 0.012F)
                 .b('E', 0, 0.040F, 0.640F, 0.036F, 0.028F, 0.030F)                         // tip
                 .b('e', -0.032F, 0.030F, 0.050F, 0.008F, 0.040F, 0.100F)                   // capacitor light
                 .b('M', 0, 0.040F, -0.170F, 0.044F, 0.080F, 0.200F)                        // stock
                 .r('N', 0, -0.054F, -0.030F, 0.034F, 0.080F, 0.042F, -16, 0, 0)
                 .muzzle(0, 0.040F, 0.660F).hands(0, -0.054F, -0.018F, 0, -0.016F, 0.300F);
            }
            case 11 -> {     // minigun (its barrels are added every frame, they spin)
                m.b('d', 0, 0.045F, 0.060F, 0.090F, 0.090F, 0.200F)                         // housing
                 .b('m', 0, 0.045F, 0.200F, 0.070F, 0.070F, 0.030F)                         // clamp
                 .b('m', 0, 0.045F, 0.380F, 0.080F, 0.080F, 0.016F)
                 .b('k', 0, 0.045F, 0.300F, 0.030F, 0.030F, 0.400F)                         // the hub
                 .b('A', 0, 0.045F, 0.100F, 0.070F, 0.040F, 0.080F)
                 .b('y', -0.060F, 0.020F, 0.020F, 0.014F, 0.014F, 0.090F)                   // belt
                 .b('m', 0, 0.115F, 0.060F, 0.016F, 0.050F, 0.150F)                         // carry handle
                 .b('d', 0, -0.020F, 0.280F, 0.032F, 0.076F, 0.040F)                        // front handle
                 .r('d', 0, -0.055F, -0.040F, 0.034F, 0.085F, 0.042F, -14, 0, 0)
                 .muzzle(0, 0.045F, 0.600F).hands(0, -0.054F, -0.018F, 0, -0.036F, 0.282F);
                m.dz = 0.10F;
            }
            case 12 -> {     // water gun
                m.b('A', 0, 0.016F, 0.060F, 0.056F, 0.064F, 0.240F)                         // body
                 .b('i', 0, 0.066F, 0.030F, 0.046F, 0.040F, 0.140F)                         // tank
                 .b('b', 0, 0.066F, 0.030F, 0.036F, 0.032F, 0.120F)
                 .b('y', 0, 0.034F, 0.200F, 0.032F, 0.032F, 0.120F)                         // nozzle
                 .b('r', 0, 0.034F, 0.270F, 0.038F, 0.038F, 0.030F)                         // nozzle tip
                 .b('y', 0, -0.006F, 0.150F, 0.044F, 0.034F, 0.070F)                        // pump
                 .r('y', 0, -0.054F, -0.024F, 0.036F, 0.085F, 0.046F, -14, 0, 0)
                 .muzzle(0, 0.034F, 0.290F).hands(0, -0.054F, -0.024F, 0, -0.024F, 0.150F);
            }
            case 13 -> {     // dart gun
                m.b('A', 0, 0.016F, 0.050F, 0.050F, 0.060F, 0.230F)                         // body
                 .b('y', 0, 0.050F, 0.050F, 0.030F, 0.008F, 0.210F)                         // stripe
                 .b('y', 0, 0.030F, 0.190F, 0.044F, 0.044F, 0.100F)                         // fat barrel
                 .b('W', -0.010F, 0.042F, 0.255F, 0.012F, 0.012F, 0.050F)                   // darts
                 .b('W', 0.010F, 0.042F, 0.255F, 0.012F, 0.012F, 0.050F)
                 .b('W', 0, 0.020F, 0.255F, 0.012F, 0.012F, 0.050F)
                 .b('r', -0.010F, 0.042F, 0.285F, 0.014F, 0.014F, 0.012F)
                 .b('r', 0.010F, 0.042F, 0.285F, 0.014F, 0.014F, 0.012F)
                 .b('r', 0, 0.020F, 0.285F, 0.014F, 0.014F, 0.012F)
                 .r('a', 0, -0.054F, -0.026F, 0.036F, 0.085F, 0.046F, -14, 0, 0)
                 .muzzle(0, 0.032F, 0.300F).hands(0, -0.054F, -0.026F, -0.026F, -0.060F, 0.000F);
                m.cup = true;
            }
            case 14 -> {     // musket
                m.r('w', 0, -0.006F, -0.170F, 0.040F, 0.085F, 0.420F, -3, 0, 0)              // stock
                 .b('x', 0, 0.034F, 0.040F, 0.050F, 0.060F, 0.200F)                         // lock area
                 .t('m', 0, 0.044F, 0.480F, 0.028F, 0.700F)                                 // long barrel
                 .b('y', 0, 0.044F, 0.250F, 0.034F, 0.034F, 0.014F)                         // brass bands
                 .b('y', 0, 0.044F, 0.430F, 0.034F, 0.034F, 0.014F)
                 .b('y', 0, 0.044F, 0.610F, 0.034F, 0.034F, 0.014F)
                 .b('y', 0, 0.040F, 0.020F, 0.024F, 0.050F, 0.050F)                         // brass lock plate
                 .r('d', 0, 0.070F, -0.010F, 0.012F, 0.040F, 0.020F, -25, 0, 0)             // hammer
                 .b('y', 0, 0.068F, 0.800F, 0.008F, 0.012F, 0.010F)
                 .b('w', 0, -0.030F, 0.200F, 0.040F, 0.040F, 0.400F)                        // fore-stock
                 .muzzle(0, 0.044F, 0.835F).hands(0, -0.040F, -0.020F, 0, -0.012F, 0.380F);
            }
            case 15 -> {     // slingshot, pulled back
                m.b('x', 0, -0.040F, 0.100F, 0.030F, 0.110F, 0.030F)                        // handle
                 .r('x', -0.036F, 0.040F, 0.120F, 0.016F, 0.090F, 0.022F, 0, 0, 22)         // the fork
                 .r('x', 0.036F, 0.040F, 0.120F, 0.016F, 0.090F, 0.022F, 0, 0, -22)
                 .r('r', -0.020F, 0.080F, 0.035F, 0.007F, 0.007F, 0.190F, 5, -13, 0)        // rubber bands
                 .r('r', 0.020F, 0.080F, 0.035F, 0.007F, 0.007F, 0.190F, 5, 13, 0)
                 .b('x', 0, 0.075F, -0.062F, 0.034F, 0.030F, 0.022F)                        // pouch
                 .b('l', 0, 0.082F, -0.048F, 0.016F, 0.016F, 0.016F)                        // stone
                 .b('G', 0.004F, 0.072F, -0.086F, 0.046F, 0.040F, 0.040F)                  // the pulling hand pinches the pouch
                 .b('G', -0.026F, 0.080F, -0.080F, 0.018F, 0.030F, 0.030F)
                 .r('J', 0.020F, 0.040F, -0.230F, 0.074F, 0.070F, 0.260F, 14, -10, 0)    // its sleeve
                 .muzzle(0, 0.080F, 0.140F).hands(0, -0.045F, 0.100F, 0, 0, 0);
                m.noLeft = true;
            }
            default -> {     // 16: flare gun
                m.cup = true;
                m.b('d', 0, 0.012F, 0.050F, 0.044F, 0.048F, 0.180F)                         // frame
                 .t('A', 0, 0.034F, 0.170F, 0.052F, 0.200F)                                 // fat barrel
                 .b('k', 0, 0.034F, 0.272F, 0.040F, 0.040F, 0.010F)                         // dark opening
                 .b('a', 0, 0.062F, 0.170F, 0.020F, 0.008F, 0.190F)
                 .b('d', 0, 0.060F, -0.022F, 0.010F, 0.024F, 0.016F)                        // hammer
                 .r('x', 0, -0.054F, -0.028F, 0.036F, 0.090F, 0.048F, -16, 0, 0)
                 .b('d', 0, -0.016F, 0.040F, 0.030F, 0.006F, 0.050F)
                 .muzzle(0, 0.034F, 0.285F).hands(0, -0.054F, -0.028F, -0.028F, -0.064F, 0.008F);
            }
        }
        return m;
    }

    // ---------- little 3x3 matrices ----------
    private static float[] rotX(float deg) { double a = Math.toRadians(deg); float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{1, 0, 0, 0, c, s, 0, -s, c}; }
    private static float[] rotY(float deg) { double a = Math.toRadians(deg); float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{c, 0, s, 0, 1, 0, -s, 0, c}; }
    private static float[] rotZ(float deg) { double a = Math.toRadians(deg); float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{c, -s, 0, s, c, 0, 0, 0, 1}; }
    private static float[] mul(float[] a, float[] b) {
        float[] r = new float[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) r[i * 3 + j] = a[i * 3] * b[j] + a[i * 3 + 1] * b[3 + j] + a[i * 3 + 2] * b[6 + j];
        return r;
    }
    private static final float[] IDENT = {1, 0, 0, 0, 1, 0, 0, 0, 1};

    // ---------- the frame buffers ----------
    private static final int[] BUF = new int[W * H];
    private static final int[] IDS = new int[W * H];
    private static final float[] ZB = new float[W * H];
    private static final int[] TMP = new int[W * H];

    /** What render() hands back. */
    static final class Out {
        final int[] px = BUF;                // ARGB, 0 = nothing drawn
        int mx, my;                          // the muzzle on the screen
        float md;                            // how far away the muzzle is (the flash gets smaller)
        int y0, y1;                          // the rows that hold something
    }
    private static final Out OUT = new Out();

    // the light, in view space (from the top left, a bit toward you)
    private static final float LX = -0.45F, LY = 0.80F, LZ = -0.40F;

    // ---------- drawing ----------
    /**
     * @param gi      index of the gun (the weapons array)
     * @param accent  the accent color of the gun (ARGB)
     * @param kick    recoil 0..12 (the gun jumps back and up)
     * @param walkT   walking counter for the bob
     * @param reload  0 when not reloading, else 0..1 how far the reload is
     * @param swap    0..1 how much the gun is still coming up after you switched to it (1 = down)
     * @param ticks   game ticks (breathing, the spin of the minigun, sparkles)
     * @param pap     Pack-a-Punched: some sparkles
     */
    static Out render(int gi, int accent, float kick, float walkT, float reload, float swap, int ticks, boolean pap, boolean firing) {
        Arrays.fill(BUF, 0); Arrays.fill(IDS, 0); Arrays.fill(ZB, 0F);
        Model m = model(gi);
        int accentDark = shade(accent, 0.6F);

        // where the gun is: down on the right, the barrel points into the crosshair
        float bobX = (float) Math.sin(walkT * 0.2) * 0.008F, bobY = (float) Math.abs(Math.cos(walkT * 0.2)) * 0.008F;
        float breathe = (float) Math.sin(ticks * 0.07) * 0.0025F;
        float dip = reload > 0 ? (float) Math.sin(Math.PI * Math.min(1F, reload)) : 0F;
        float gx = 0.140F + bobX + dip * 0.03F;
        float gy = -0.135F + bobY + breathe - dip * 0.15F - swap * 0.22F;
        float gz = 0.400F + m.dz - kick * 0.0065F;
        float pitch = 1.5F + kick * 0.9F - dip * 22F - swap * 25F;
        float yaw = -7F + dip * 10F + bobX * 80F;
        float roll = dip * 24F + bobX * 40F;
        float[] G = mul(rotY(yaw), mul(rotX(pitch), rotZ(roll)));

        List<Part> parts = new ArrayList<>(m.parts);
        if (gi == 11) minigunBarrels(parts, ticks, firing);
        addHands(parts, m);

        int id = 0;
        for (Part p : parts) {
            id++;
            int col = p.c == 'A' ? accent : p.c == 'a' ? accentDark : PAL[p.c];
            boolean glow = p.c == 'E' || p.c == 'i';
            drawBox(p, id, col, glow, G, gx, gy, gz);
        }

        // the muzzle on the screen
        float[] mv = apply(G, m.mx, m.my, m.mz);
        float cx = mv[0] + gx, cy = mv[1] + gy, cz = Math.max(NEAR, mv[2] + gz);
        OUT.mx = Math.round(W / 2F + FOCAL * cx / cz);
        OUT.my = Math.round(H / 2F - FOCAL * cy / cz);
        OUT.md = cz;

        outline();

        int y0 = H, y1 = -1, x0 = W, x1 = -1;
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) if (BUF[y * W + x] != 0) { if (y < y0) y0 = y; if (y > y1) y1 = y; if (x < x0) x0 = x; if (x > x1) x1 = x; }
        OUT.y0 = y0; OUT.y1 = y1;
        if (pap && y1 >= y0) {                                      // a pink sparkle or two
            int t = ticks / 5;
            for (int i = 0; i < 3; i++) {
                int sx = x0 + Math.floorMod(t * (7 + i * 4) + i * 23, Math.max(1, x1 - x0 + 1));
                int sy = y0 + Math.floorMod(t * (11 + i * 3) + i * 31, Math.max(1, y1 - y0 + 1));
                if (BUF[sy * W + sx] != 0 && BUF[sy * W + sx] != OUTLINE) BUF[sy * W + sx] = i == 1 ? 0xFFFFC8F0 : 0xFFFFFFFF;
            }
        }
        return OUT;
    }

    /** Six barrels around the axis; they turn while the trigger is held. */
    private static void minigunBarrels(List<Part> parts, int ticks, boolean firing) {
        float spin = firing ? ticks * 38F : ticks * 3F;
        for (int i = 0; i < 6; i++) {
            double a = Math.toRadians(spin + i * 60);
            float bx = (float) Math.cos(a) * 0.026F, by = (float) Math.sin(a) * 0.026F;
            parts.add(new Part(i == 0 ? 'h' : 'l', bx, 0.045F + by, 0.380F, 0.016F, 0.016F, 0.440F, 0, 0, 0));
        }
    }

    /** The hands: gloves on the grip and on the fore-end, sleeves running out of the bottom of the picture. */
    private static void addHands(List<Part> p, Model m) {
        // right hand: a fist around the grip, the thumb along the left side
        p.add(new Part('G', m.rx + 0.002F, m.ry, m.rz, 0.052F, 0.078F, 0.060F, 0, 0, 0));
        p.add(new Part('G', m.rx - 0.032F, m.ry + 0.030F, m.rz + 0.006F, 0.022F, 0.028F, 0.056F, 0, -8, 0));
        p.add(new Part('d', m.rx + 0.002F, m.ry + 0.040F, m.rz, 0.054F, 0.010F, 0.062F, 0, 0, 0));      // knuckle pad
        p.add(new Part('d', m.rx + 0.006F, m.ry - 0.050F, m.rz - 0.044F, 0.060F, 0.058F, 0.034F, 10, 0, 0));    // cuff
        p.add(new Part('J', m.rx + 0.014F, m.ry - 0.080F, m.rz - 0.210F, 0.076F, 0.074F, 0.300F, 18, -8, 0));   // sleeve
        if (m.noLeft) return;
        if (m.cup) {
            // the left hand cups the right one from the left and below
            p.add(new Part('G', m.lx, m.ly, m.lz, 0.040F, 0.050F, 0.070F, 0, 0, 0));
            p.add(new Part('G', m.lx + 0.012F, m.ly + 0.040F, m.lz + 0.036F, 0.020F, 0.030F, 0.036F, 0, 0, 0));    // thumb
            p.add(new Part('d', m.lx - 0.010F, m.ly - 0.030F, m.lz - 0.044F, 0.050F, 0.050F, 0.032F, 22, 18, 0));
            p.add(new Part('J', m.lx - 0.060F, m.ly - 0.062F, m.lz - 0.240F, 0.070F, 0.070F, 0.400F, 26, 24, 0));
        } else {
            // the left hand holds the fore-end from below, the fingers show on the left side, the thumb on top of it
            p.add(new Part('G', m.lx - 0.006F, m.ly - 0.010F, m.lz, 0.074F, 0.060F, 0.100F, 0, 0, 0));
            p.add(new Part('G', m.lx - 0.040F, m.ly + 0.018F, m.lz + 0.004F, 0.026F, 0.058F, 0.092F, 0, 0, 0));    // fingers up the left side
            p.add(new Part('d', m.lx - 0.040F, m.ly + 0.018F, m.lz + 0.004F, 0.028F, 0.006F, 0.094F, 0, 0, 0));
            p.add(new Part('G', m.lx + 0.030F, m.ly + 0.032F, m.lz - 0.010F, 0.020F, 0.030F, 0.050F, 0, 0, 0));    // thumb over the top
            p.add(new Part('d', m.lx - 0.016F, m.ly - 0.030F, m.lz - 0.070F, 0.066F, 0.056F, 0.030F, 22, 16, 0));
            p.add(new Part('J', m.lx - 0.060F, m.ly - 0.075F, m.lz - 0.200F, 0.076F, 0.072F, 0.280F, 30, 22, 0));
        }
    }

    private static float[] apply(float[] M, float x, float y, float z) {
        return new float[]{M[0] * x + M[1] * y + M[2] * z, M[3] * x + M[4] * y + M[5] * z, M[6] * x + M[7] * y + M[8] * z};
    }

    // the six faces of a unit cube: normal, then four corners (as -1 / +1)
    private static final int[][] FACES = {
            {1, 0, 0, 1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1},
            {-1, 0, 0, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, -1, 1},
            {0, 1, 0, -1, 1, -1, 1, 1, -1, 1, 1, 1, -1, 1, 1},
            {0, -1, 0, -1, -1, -1, 1, -1, -1, 1, -1, 1, -1, -1, 1},
            {0, 0, 1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1},
            {0, 0, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, -1, 1, -1}};

    private static void drawBox(Part p, int id, int col, boolean glow, float[] G, float gx, float gy, float gz) {
        float[] R = p.rot == null ? G : mul(G, p.rot);
        float[] c0 = apply(G, p.x, p.y, p.z);
        float tx = c0[0] + gx, ty = c0[1] + gy, tz = c0[2] + gz;
        float hw = p.w / 2, hh = p.h / 2, hl = p.l / 2;
        for (int[] f : FACES) {
            float[] n = apply(R, f[0], f[1], f[2]);
            float[][] v = new float[4][];
            for (int i = 0; i < 4; i++) {
                float[] q = apply(R, f[3 + i * 3] * hw, f[4 + i * 3] * hh, f[5 + i * 3] * hl);
                v[i] = new float[]{q[0] + tx, q[1] + ty, q[2] + tz};
            }
            float fx = (v[0][0] + v[2][0]) / 2, fy = (v[0][1] + v[2][1]) / 2, fz = (v[0][2] + v[2][2]) / 2;
            if (n[0] * fx + n[1] * fy + n[2] * fz >= 0) continue;           // a face that looks away from you
            float lam = Math.max(0F, n[0] * LX + n[1] * LY + n[2] * LZ) / 0.98F;
            float sh = glow ? 1.05F : 0.46F + 0.62F * lam;
            fillPoly(v, id, shade(col, sh));
        }
    }

    /** Clips a quad against the near plane and fills it as triangles. */
    private static void fillPoly(float[][] v, int id, int color) {
        float[][] out = new float[8][];
        int n = 0;
        for (int i = 0; i < 4; i++) {
            float[] a = v[i], b = v[(i + 1) % 4];
            boolean ain = a[2] >= NEAR, bin = b[2] >= NEAR;
            if (ain) out[n++] = a;
            if (ain != bin) {
                float t = (NEAR - a[2]) / (b[2] - a[2]);
                out[n++] = new float[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, NEAR};
            }
        }
        if (n < 3) return;
        float[] sx = new float[n], sy = new float[n], iz = new float[n];
        for (int i = 0; i < n; i++) {
            iz[i] = 1F / out[i][2];
            sx[i] = W / 2F + FOCAL * out[i][0] * iz[i];
            sy[i] = H / 2F - FOCAL * out[i][1] * iz[i];
        }
        for (int i = 1; i + 1 < n; i++) tri(sx[0], sy[0], iz[0], sx[i], sy[i], iz[i], sx[i + 1], sy[i + 1], iz[i + 1], id, color);
    }

    private static void tri(float x0, float y0, float z0, float x1, float y1, float z1, float x2, float y2, float z2, int id, int color) {
        float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (Math.abs(area) < 1e-4F) return;
        int minX = Math.max(0, (int) Math.floor(Math.min(x0, Math.min(x1, x2)))), maxX = Math.min(W - 1, (int) Math.ceil(Math.max(x0, Math.max(x1, x2))));
        int minY = Math.max(0, (int) Math.floor(Math.min(y0, Math.min(y1, y2)))), maxY = Math.min(H - 1, (int) Math.ceil(Math.max(y0, Math.max(y1, y2))));
        float inv = 1F / area;
        for (int y = minY; y <= maxY; y++) {
            float py = y + 0.5F;
            for (int x = minX; x <= maxX; x++) {
                float px = x + 0.5F;
                float w0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) * inv;
                float w1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) * inv;
                float w2 = 1F - w0 - w1;
                if (w0 < -0.001F || w1 < -0.001F || w2 < -0.001F) continue;
                float z = w0 * z0 + w1 * z1 + w2 * z2;                       // 1 / depth: bigger = nearer
                int k = y * W + x;
                if (z > ZB[k]) { ZB[k] = z; BUF[k] = color; IDS[k] = id; }
            }
        }
    }

    /** A dark line around the whole gun, and where a nearer part ends in front of a farther one. */
    private static void outline() {
        System.arraycopy(BUF, 0, TMP, 0, BUF.length);
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int k = y * W + x;
                if (BUF[k] == 0) {
                    if ((x > 0 && BUF[k - 1] != 0) || (x < W - 1 && BUF[k + 1] != 0) || (y > 0 && BUF[k - W] != 0) || (y < H - 1 && BUF[k + W] != 0)) TMP[k] = OUTLINE;
                } else {
                    boolean edge = false;
                    if (x > 0 && IDS[k - 1] != IDS[k] && IDS[k - 1] != 0 && ZB[k - 1] > ZB[k] * 1.04F) edge = true;
                    if (x < W - 1 && IDS[k + 1] != IDS[k] && IDS[k + 1] != 0 && ZB[k + 1] > ZB[k] * 1.04F) edge = true;
                    if (y > 0 && IDS[k - W] != IDS[k] && IDS[k - W] != 0 && ZB[k - W] > ZB[k] * 1.04F) edge = true;
                    if (y < H - 1 && IDS[k + W] != IDS[k] && IDS[k + W] != 0 && ZB[k + W] > ZB[k] * 1.04F) edge = true;
                    if (edge) TMP[k] = shade(BUF[k], 0.55F);
                }
            }
        }
        System.arraycopy(TMP, 0, BUF, 0, BUF.length);
    }

    static int shade(int c, float f) {
        int r = (int) (((c >> 16) & 255) * f), g = (int) (((c >> 8) & 255) * f), b = (int) ((c & 255) * f);
        return 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
    }
}
