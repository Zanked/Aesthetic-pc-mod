package dev.cutemod.client.os;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The candy shop of the Halloween event: trade the candy you collected on the desktop.
 * The list scrolls (mouse wheel, arrow keys) when it does not fit; every text is measured the way it is drawn
 * (CuteFont), so it is cut instead of running into the next thing.
 */
public class HalloweenApp extends App {
    private record Row(String kind, String id, int cost) {}

    private static final Row[] ROWS = {
            new Row("coins", "", 5),
            new Row("wall", "", 20),
            new Row("game", "horror", 15),
            new Row("game", "maze", 30),
            new Row("game", "zombies", 40),
            new Row("game", "otherworld", 35),
            new Row("game", "forest", 35)};
    private static final int TOP = 44, ROW = 23;
    private static final int VIS = (H - TOP - 2) / ROW;                  // the rows that fit under the header; the rest scrolls
    private static final int BTN_X = W - 76, BTN_W = 68;
    private static final int ORANGE = 0xFFFF9A2A, MUTED = 0xFFB8A0D0, GREEN = 0xFF5BD97A;
    private static final int COIN_GAIN = 8, COIN_TRADES_PER_DAY = 3;

    private int scroll;

    @Override
    public Component title() { return Component.translatable("cutemod.hw.title"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.hw.hint"); }

    @Override
    public Component status() { return Component.empty(); }

    @Override
    public void tick() { Halloween.animate(); }

    private String stateOf(Row r) {
        switch (r.kind()) {
            case "wall":
                if (Halloween.hasWallpaper()) return Wallpaper.get() == Halloween.WALL ? "using" : "set";
                return "buy";
            case "game":
                return Library.owned(r.id()) ? "owned" : "buy";
            default:
                return "buy";
        }
    }

    /** s wrapped into at most maxLines lines; what does not fit ends the last line with "...". */
    private static List<String> wrap(Font f, String s, int maxW, int maxLines) {
        List<String> out = new ArrayList<>();
        String[] words = s.trim().split("\\s+");
        String line = "";
        for (int i = 0; i < words.length; i++) {
            String test = line.isEmpty() ? words[i] : line + " " + words[i];
            if (CuteFont.width(f, test) <= maxW) { line = test; continue; }
            if (line.isEmpty()) { line = words[i]; continue; }            // a single word wider than the line: it gets cut below
            if (out.size() == maxLines - 1) {
                StringBuilder rest = new StringBuilder(line);
                for (int j = i; j < words.length; j++) rest.append(' ').append(words[j]);
                out.add(CuteFont.cut(f, rest.toString(), maxW));
                return out;
            }
            out.add(line);
            line = words[i];
        }
        if (!line.isEmpty()) out.add(CuteFont.cut(f, line, maxW));
        return out;
    }

    private int maxScroll() { return Math.max(0, ROWS.length - VIS); }

    @Override
    public boolean scroll(double amount) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll + (amount < 0 ? 1 : -1)));
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (keyCode == 264) { scroll = Math.min(maxScroll(), scroll + 1); return true; }      // arrow down
        if (keyCode == 265) { scroll = Math.max(0, scroll - 1); return true; }                // arrow up
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
        g.fillGradient(0, 0, W, H, 0xFF1A0F2E, 0xFF331A4A);
        for (int i = 0; i < 20; i++) rect(g, (i * 53 + 11) % (W - 2), (i * 29 + 5) % (H - 2), 1, 1, 0x88FFFFFF);
        Halloween.pumpkin(g, 6, 2, 28, false);
        // the title and the candy count share the top line: the title is cut so they never touch
        String cs = Integer.toString(Halloween.candy());
        int cw = CuteFont.width(f, cs), iconX = W - 20 - cw - 14;
        String title = CuteFont.cut(f, t("cutemod.hw.title"), Math.max(30, (iconX - 46) * 9 / 10));
        CuteFont.draw(g, f, Component.literal(title).withStyle(ChatFormatting.BOLD), 40, 5, ORANGE, false);
        Halloween.candy(g, iconX, 8, 0xFFFF6FA5, 0xFFFFFFFF, 2);
        CuteFont.draw(g, f, cs, W - 12 - cw, 6, 0xFFFFFFFF, false);
        List<String> help = wrap(f, t("cutemod.hw.help"), W - 48, 3);
        for (int i = 0; i < help.size(); i++) CuteFont.draw(g, f, help.get(i), 40, 17 + i * 9, MUTED, false);

        int textW = BTN_X - 40 - 6;                                              // from the text column to the button
        for (int i = scroll; i < Math.min(ROWS.length, scroll + VIS); i++) {
            Row r = ROWS[i];
            int y = TOP + (i - scroll) * ROW;
            rect(g, 4, y, W - 8, ROW - 2, i % 2 == 0 ? 0xCC2A1A44 : 0xCC231538);
            switch (r.kind()) {
                case "coins" -> Progress.drawCoin(g, 14, y + 6);
                case "wall" -> Wallpaper.draw(g, 6, y + 2, 28, 18, shell.color().bodyColor, Halloween.WALL);
                default -> CoverArt.draw(g, r.id(), 8, y + 2, 18);
            }
            String name = switch (r.kind()) {
                case "coins" -> t("cutemod.hw.row.coins", COIN_GAIN);
                case "wall" -> t("cutemod.hw.row.wall");
                default -> Library.name(r.id());
            };
            CuteFont.draw(g, f, CuteFont.cut(f, name, textW), 40, y + 3, 0xFFFFFFFF, false);
            boolean coinRow = r.kind().equals("coins");
            int left = Math.max(0, COIN_TRADES_PER_DAY - Progress.dailyCount("hw_coins"));
            String cost = t("cutemod.hw.cost", r.cost()) + (coinRow ? "  " + t("cutemod.hw.left", left) : "");
            CuteFont.draw(g, f, CuteFont.cut(f, cost, textW), 40, y + 12, MUTED, false);

            String st = stateOf(r);
            boolean limit = coinRow && left == 0;
            boolean can = st.equals("set") || (st.equals("buy") && Halloween.candy() >= r.cost() && !limit);
            boolean hov = can && in(mx, my, BTN_X, y + 3, BTN_W, 16);
            int bg = st.equals("owned") || st.equals("using") ? 0xFF3A2F5A : !can ? 0xFF3A2F5A : hov ? 0xFF7BE890 : GREEN;
            rect(g, BTN_X, y + 3, BTN_W, 16, bg);
            String label = CuteFont.cut(f, limit ? t("cutemod.hw.limit") : t("cutemod.hw." + st), BTN_W - 6);
            CuteFont.draw(g, f, label, BTN_X + (BTN_W - CuteFont.width(f, label)) / 2, y + 7, can ? 0xFF12301A : MUTED, false);
        }
        if (maxScroll() > 0) {                                                   // a scroll bar on the right
            int trackH = VIS * ROW - 2;
            int thumbH = Math.max(10, trackH * VIS / ROWS.length);
            rect(g, W - 3, TOP, 2, trackH, 0x55FFFFFF);
            rect(g, W - 3, TOP + (trackH - thumbH) * scroll / maxScroll(), 2, thumbH, ORANGE);
        }
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int i = scroll; i < Math.min(ROWS.length, scroll + VIS); i++) {
            Row r = ROWS[i];
            int ry = TOP + (i - scroll) * ROW;
            if (!in(x, y, BTN_X, ry + 3, BTN_W, 16)) continue;
            String st = stateOf(r);
            switch (r.kind()) {
                case "coins" -> {
                    if (Progress.dailyCount("hw_coins") < COIN_TRADES_PER_DAY && Halloween.spendCandy(r.cost())) {
                        Progress.bump("hw_coins");
                        Progress.earn(COIN_GAIN);
                        Progress.toast("cutemod.toast.hw_trade");
                    }
                }
                case "wall" -> {
                    if (st.equals("set")) Wallpaper.set(Halloween.WALL);
                    else if (st.equals("buy") && Halloween.spendCandy(r.cost())) {
                        Halloween.giveWallpaper();
                        Wallpaper.set(Halloween.WALL);
                        Progress.toast("cutemod.toast.hw_trade");
                    }
                }
                default -> {
                    if (st.equals("buy") && Halloween.spendCandy(r.cost())) {
                        Library.grant(r.id());
                        Progress.toast("cutemod.toast.hw_trade");
                    }
                }
            }
            return true;
        }
        return true;
    }
}
