package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.client.game.GameFactory;
import dev.cutemod.client.game.MiniGame;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Runs one of the mini games inside the computer window. */
public class GameApp extends App {
    /** true = the game is stretched over the whole app area (may look a bit wide); false = scaled evenly, as large as fits. */
    private static final boolean STRETCH = false;
    private static final float SX = STRETCH ? (float) W / MiniGame.W : Math.min((float) W / MiniGame.W, (float) H / MiniGame.H);
    private static final float SY = STRETCH ? (float) H / MiniGame.H : SX;
    private static final float OX = (W - MiniGame.W * SX) / 2f;      // top-left of the scaled game inside the app area
    private static final float OY = (H - MiniGame.H * SY) / 2f;

    private final String id;
    private final ComputerColor color; // null for games that are not tied to a computer color
    private final MiniGame game;
    private boolean submitted = false;
    private int overTicks = 0;
    private int playTicks = 0;
    private int roundTicks = 0;

    public GameApp(ComputerColor color) {
        this(color.id, color, GameFactory.create(color));
    }

    /** A game from the Games folder that has no computer of its own (no block record). */
    public static GameApp extra(String id) {
        return new GameApp(id, null, GameFactory.createExtra(id));
    }

    private GameApp(String id, ComputerColor color, MiniGame game) {
        this.id = id;
        this.color = color;
        this.game = game;
        this.game.reset();
    }

    /** The id of this game (CuteNet shows it as what the player is doing). */
    public String gameId() { return id; }

    @Override
    public Component title() { return Component.translatable("cutemod.game." + id); }

    @Override
    public Component hint() { return Component.translatable(game.hintKey()); }

    @Override
    public Component status() { return game.status(); }

    @Override
    public boolean showRecord() { return color != null && shell != null && shell.color() == color; }

    private void restart() {
        game.reset();
        submitted = false;
        overTicks = 0;
        roundTicks = 0;
    }

    @Override
    public void mouse(int x, int y) { game.setMouse((int) Math.floor((x - OX) / SX), (int) Math.floor((y - OY) / SY)); }

    @Override
    public void close() { GameMusic.stop(); Sfx.stopGameSounds(); }

    @Override
    public void tick() {
        GameMusic.keep(id, game.over, roundTicks);
        if (!game.over) {
            game.tick();
            roundTicks++;
            if (++playTicks >= 60) { playTicks = 0; Library.addPlaySecond(id); }
        } else overTicks++;
        if (game.over && !submitted) {
            submitted = true;
            Sfx.gameOver(game.isWin(), GameMusic.dark(id));
            Library.recordScore(id, game.score);
            Net.submit(id, game.score);
            Progress.onGame(id, game.score, game.isWin());
            if (game.score > 0 && color != null) shell.submitScore(color, game.score);
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        GameBackdrop.draw(g, id, W, H, Math.round(OX), Math.round(OY), Math.round(MiniGame.W * SX), Math.round(MiniGame.H * SY));       // every game has its own backdrop around the box
        g.enableScissor(shell.absX() + (int) Math.floor(OX), shell.absY() + (int) Math.floor(OY),
                shell.absX() + (int) Math.ceil(OX + MiniGame.W * SX), shell.absY() + (int) Math.ceil(OY + MiniGame.H * SY));
        g.pose().pushPose();
        g.pose().translate(OX, OY, 0);
        g.pose().scale(SX, SY, 1f);                                            // the game still thinks it is W x H: it is just drawn larger
        game.render(g);
        if (game.over) renderGameOver(g);
        g.pose().popPose();
        g.disableScissor();
    }

    private void renderGameOver(GuiGraphics g) {
        int w = 150, h = 48, x = (MiniGame.W - w) / 2, y = (MiniGame.H - h) / 2;
        var font = font();
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFFFFFFFF);
        g.fill(x, y, x + w, y + h, 0xE0201828);
        g.drawCenteredString(font, game.endTitle(), x + w / 2, y + 7, 0xFFFFD866);
        g.drawCenteredString(font, Component.translatable("cutemod.ui.score", game.score), x + w / 2, y + 20, 0xFFFFFFFF);
        g.drawCenteredString(font, Component.translatable("cutemod.ui.restart"), x + w / 2, y + 33, 0xFFB8B0C8);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (game.over) {
            if (overTicks > 20) restart();
            return true;
        }
        int lx = (int) Math.floor((x - OX) / SX), ly = (int) Math.floor((y - OY) / SY);
        if (in(lx, ly, 0, 0, MiniGame.W, MiniGame.H)) {
            game.click(lx, ly, button);
            return true;
        }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (game.over) {
            if ((keyCode == 32 || keyCode == 257) && overTicks > 20) { // space / enter
                restart();
                return true;
            }
            return false;
        }
        return game.key(keyCode);
    }
}
