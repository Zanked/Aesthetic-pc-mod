package dev.cutemod.client.game;

/**
 * Pixel art for Zombie Shooter, drawn by code (no image files): four detailed zombies with two walking frames each,
 * the six perk icons for the cards between rounds and the six perk vending machines for the wall.
 * Pure Java on purpose (no Minecraft classes), so tools/ZombiePreview.java can render it to a PNG.
 * Every picture is an int[row][column] of ARGB, 0 = transparent.
 */
final class ZombieArt {
    private ZombieArt() {}

    static final int ZH = 40;                                   // every zombie is 40 rows tall; 20 wide, the tank 28
    static final int ICON = 24;                                 // perk icon size
    static final int MACHINE = 16;                              // a perk machine texture is 16 x 16

    private static final int[][][][] ZOMBIES = new int[4][2][][];
    private static final int[][][] ICONS = new int[6][][];
    private static final int[][][] MACHINES = new int[6][][];
    private static final int[][][] MINI = new int[6][][];
    static final int MINI_SIZE = 12;

    /** A zombie of kind 0 normal, 1 runner, 2 tank, 3 spitter in walking frame 0 or 1. */
    static synchronized int[][] zombie(int kind, int frame) {
        int k = Math.max(0, Math.min(3, kind)), f = frame & 1;
        if (ZOMBIES[k][f] == null) ZOMBIES[k][f] = buildZombie(k, f);
        return ZOMBIES[k][f];
    }

    /** The perk card icon (ICON x ICON). perkColor is the main color of the perk. */
    static synchronized int[][] icon(int perk, int perkColor) {
        int p = Math.max(0, Math.min(5, perk));
        if (ICONS[p] == null) {
            Cv c = new Cv(ICON, ICON);
            glyph(c, p, perkColor, 1, 1, ICON - 2);
            ICONS[p] = c.finish(0xFF0C0C12, true);
        }
        return ICONS[p];
    }

    /** A 12 x 12 version of the icon for the HUD (drawn small, not shrunk, so the lines stay clean). */
    static synchronized int[][] miniIcon(int perk, int perkColor) {
        int p = Math.max(0, Math.min(5, perk));
        if (MINI[p] == null) {
            Cv c = new Cv(MINI_SIZE, MINI_SIZE);
            glyph(c, p, perkColor, 0.5, 0.5, MINI_SIZE - 1);
            MINI[p] = c.finish(0xFF0C0C12, false);
        }
        return MINI[p];
    }

    /** The front of a perk vending machine (MACHINE x MACHINE texels). */
    static synchronized int[][] machine(int perk, int perkColor) {
        int p = Math.max(0, Math.min(5, perk));
        if (MACHINES[p] == null) MACHINES[p] = buildMachine(p, perkColor);
        return MACHINES[p];
    }

    // =====================================================================================================
    // small drawing kit
    // =====================================================================================================
    static int shade(int c, double f) {
        int a = c >>> 24, r = (int) Math.min(255, ((c >> 16) & 255) * f), g = (int) Math.min(255, ((c >> 8) & 255) * f), b = (int) Math.min(255, (c & 255) * f);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int mix(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t),
                bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int hash(int a, int b) {
        int h = a * 374761393 + b * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        return (h ^ (h >>> 16)) & 0x7FFFFFFF;
    }

    /** A canvas. Shapes are filled by pixel centers, so the same code draws at any size. "fixed" pixels (glow, teeth, eyes) skip the shading. */
    private static final class Cv {
        final int w, h;
        final int[] p;
        final boolean[] fixed;

        Cv(int w, int h) { this.w = w; this.h = h; p = new int[w * h]; fixed = new boolean[w * h]; }

        void set(int x, int y, int c, boolean fx) {
            if (x < 0 || y < 0 || x >= w || y >= h) return;
            p[y * w + x] = c;
            fixed[y * w + x] = fx;
        }

        /** Rectangle from (x0,y0) up to but not including (x1,y1). */
        void rect(double x0, double y0, double x1, double y1, int c) { rect(x0, y0, x1, y1, c, false); }

        void rect(double x0, double y0, double x1, double y1, int c, boolean fx) {
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                double cx = x + 0.5, cy = y + 0.5;
                if (cx >= x0 && cx < x1 && cy >= y0 && cy < y1) set(x, y, c, fx);
            }
        }

        /** Same as rect but with a darker edge of 1 pixel in its own color. */
        void rectO(double x0, double y0, double x1, double y1, int c) {
            rect(x0, y0, x1, y1, shade(c, 0.55));
            rect(x0 + 1, y0 + 1, x1 - 1, y1 - 1, c);
        }

        void ell(double cx, double cy, double rx, double ry, int c) { ell(cx, cy, rx, ry, c, false); }

        void ell(double cx, double cy, double rx, double ry, int c, boolean fx) {
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                double dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
                if (dx * dx + dy * dy <= 1) set(x, y, c, fx);
            }
        }

        void ellO(double cx, double cy, double rx, double ry, int c) {
            ell(cx, cy, rx, ry, shade(c, 0.55));
            ell(cx, cy, rx - 1, ry - 1, c);
        }

        /** A thick line made of discs. */
        void line(double x0, double y0, double x1, double y1, double th, int c) {
            int n = (int) Math.ceil(Math.hypot(x1 - x0, y1 - y0) * 3) + 1;
            for (int i = 0; i <= n; i++) {
                double t = i / (double) n;
                ell(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, th / 2, th / 2, c);
            }
        }

        /** A filled polygon, even-odd rule. */
        void poly(double[] xs, double[] ys, int c) {
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                double px = x + 0.5, py = y + 0.5;
                boolean in = false;
                for (int i = 0, j = xs.length - 1; i < xs.length; j = i++) {
                    if ((ys[i] > py) != (ys[j] > py) && px < (xs[j] - xs[i]) * (py - ys[i]) / (ys[j] - ys[i]) + xs[i]) in = !in;
                }
                if (in) set(x, y, c, false);
            }
        }

        /** A ring (or part of it): radii and an angle range in degrees (0 = right, 90 = down). */
        void ring(double cx, double cy, double r0, double r1, double a0, double a1, int c) {
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                double dx = x + 0.5 - cx, dy = y + 0.5 - cy, d = Math.hypot(dx, dy);
                if (d < r0 || d > r1) continue;
                double a = Math.toDegrees(Math.atan2(dy, dx));
                if (a < 0) a += 360;
                if (a >= a0 && a <= a1) set(x, y, c, false);
            }
        }

        void clear(int x, int y) { if (x >= 0 && y >= 0 && x < w && y < h) { p[y * w + x] = 0; fixed[y * w + x] = false; } }

        boolean solid(int x, int y) { return x >= 0 && y >= 0 && x < w && y < h && (p[y * w + x] >>> 24) != 0; }

        /**
         * Shading and the black outline: pixels on the left / top edge of a shape get brighter, on the right / bottom darker,
         * and every pixel gets a little noise so the skin and cloth do not look flat. Empty pixels next to the shape become the outline.
         */
        int[][] finish(int outline, boolean rim) {
            int[][] out = new int[h][w];
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                int c = p[y * w + x];
                if ((c >>> 24) == 0) {
                    if (outline != 0 && (solid(x - 1, y) || solid(x + 1, y) || solid(x, y - 1) || solid(x, y + 1))) out[y][x] = outline;
                    continue;
                }
                if (!fixed[y * w + x]) {
                    double f = 1;
                    if (rim) {
                        if (!solid(x - 1, y) || !solid(x, y - 1)) f *= 1.16;
                        if (!solid(x + 1, y) || !solid(x, y + 1)) f *= 0.8;
                    }
                    f *= 0.95 + (hash(x, y) % 11) / 100.0;
                    c = shade(c, f);
                }
                out[y][x] = c;
            }
            return out;
        }
    }

    // =====================================================================================================
    // zombies
    // =====================================================================================================
    private static int[][] buildZombie(int kind, int frame) {
        boolean tank = kind == 2, run = kind == 1, spit = kind == 3;
        int w = tank ? 28 : 20;
        double cx = w / 2.0;
        Cv c = new Cv(w, ZH);

        int skin, shirt, pants, eye, hair;
        switch (kind) {
            case 1 -> { skin = 0xFF8DB063; shirt = 0xFFC44444; pants = 0xFF34343E; eye = 0xFFFFE23A; hair = 0xFF5A4A2A; }
            case 2 -> { skin = 0xFF5C8450; shirt = 0xFF5E3E80; pants = 0xFF2E2434; eye = 0xFFFF3030; hair = 0xFF1C1C1C; }
            case 3 -> { skin = 0xFFB9C93C; shirt = 0xFF6E8F2C; pants = 0xFF3C4C24; eye = 0xFF9CFF3C; hair = 0xFF3A4A1A; }
            default -> { skin = 0xFF6FAA5A; shirt = 0xFF2AA6B0; pants = 0xFF3A3A8C; eye = 0xFFFF3030; hair = 0xFF33261A; }
        }
        int skinD = shade(skin, 0.72), shirtD = shade(shirt, 0.7), blood = 0xFF8A1414, bloodD = 0xFF5A0A0A, bone = 0xFFE8E0C4, dark = 0xFF14100C;
        int shoe = 0xFF2A2420;

        // ---- stride: one leg goes forward (long), the other is lifted ----
        int legW = tank ? 7 : run ? 4 : 5;
        int gap = tank ? 0 : run ? 1 : 0;
        int legTop = tank ? 27 : 26;
        int bottomA = frame == 0 ? 38 : (run ? 34 : 36), bottomB = frame == 0 ? (run ? 34 : 36) : 38;     // left, right
        int armBob = frame == 0 ? 0 : 1;
        double headDy = run ? 2 : spit ? 2 : 0, headDx = run ? 1 : 0;

        // ---- legs ----
        int lx0 = (int) (cx - gap / 2.0 - legW), rx0 = (int) (cx + gap / 2.0 + (gap % 2));
        for (int side = 0; side < 2; side++) {
            int x0 = side == 0 ? lx0 : rx0, bot = side == 0 ? bottomA : bottomB;
            c.rectO(x0, legTop, x0 + legW, bot - 2, pants);
            // boot
            int bx0 = side == 0 ? x0 - 1 : x0, bx1 = side == 0 ? x0 + legW : x0 + legW + 1;
            c.rectO(bx0, bot - 3, bx1, bot, shoe);
            c.rect(bx0 + 1, bot - 1, bx1 - 1, bot, 0xFF4A423A);                 // sole
            c.rect(bx0 + 1, bot - 3, bx1 - 2, bot - 2, 0xFF3C342E);             // toe cap highlight
            // knee patch and frayed hem
            c.rect(x0 + 1, legTop + 5, x0 + legW - 1, legTop + 6, shade(pants, 0.78));
            for (int i = 0; i < legW; i += 2) c.clear(x0 + i + (side), bot - 4);
        }
        // torn trouser: a wound on the left leg showing the skin and a dark scratch on the right
        c.rect(lx0 + 1, legTop + 6, lx0 + 3, legTop + 9, skinD);
        c.set(lx0 + 1, legTop + 7, blood, true);
        c.set(rx0 + legW - 2, legTop + 3, shade(pants, 0.6), false);
        c.set(rx0 + legW - 2, legTop + 4, shade(pants, 0.6), false);

        // ---- torso ----
        double th = tank ? 8 : run ? 4.5 : spit ? 6 : 5;          // half width of the torso
        int tTop = tank ? 11 : 13, tBot = legTop;                 // torso rows
        int tx0 = (int) Math.round(cx - th), tx1 = (int) Math.round(cx + th);
        if (spit) {                                               // a hunched, bloated body
            c.ellO(cx, tTop + 7.5, th + 0.8, 7.2, shirt);
            c.rect(tx0 + 1, tBot - 3, tx1 - 1, tBot, shirt);
        } else {
            c.rectO(tx0, tTop, tx1, tBot, shirt);
        }
        // belt
        c.rect(tx0, tBot - 2, tx1, tBot, 0xFF4A3220);
        c.rect((int) cx - 1, tBot - 2, (int) cx + 1, tBot, 0xFFD8B040, true);
        // torn bottom hem of the shirt
        for (int x = tx0 + 1; x < tx1 - 1; x += 3) { c.clear(x, tBot - 3); c.set(x, tBot - 3, skinD, false); }
        // shirt wrinkles
        for (int i = 0; i < (tank ? 5 : 3); i++) {
            int wx = tx0 + 2 + i * (tank ? 3 : 3), wy = tTop + 3 + (i % 2) * 3;
            c.rect(wx, wy, wx + 1, wy + 3, shirtD);
        }
        // collar: the neck coming out of it
        c.rect(cx - 2, tTop - 1, cx + 2, tTop + 2, skin);
        c.rect(cx - 1, tTop + 1, cx + 1, tTop + 3, skinD);
        // bare ribs through a tear (right side of the chest)
        int rx = (int) (cx + 1), ry = tTop + (tank ? 5 : 4);
        int ribW = tank ? 5 : run ? 4 : 3;
        c.rect(rx, ry, rx + ribW, ry + 6, bloodD);
        for (int r = 0; r < 3; r++) c.rect(rx, ry + 1 + r * 2, rx + ribW, ry + 2 + r * 2, bone);
        c.rect(rx + ribW - 1, ry, rx + ribW, ry + 6, bone);
        // blood on the shirt
        c.rect(tx0 + 1, tTop + 1, tx0 + 3, tTop + 2, blood);
        c.set(tx0 + 1, tTop + 2, blood, false); c.set(tx0 + 2, tTop + 3, blood, false);
        c.rect(tx0 + 2, tBot - 6, tx0 + 4, tBot - 5, blood);
        c.set(tx0 + 3, tBot - 5, blood, false);

        // ---- arms (reaching forward: a torn sleeve, rotten forearm, clawed hand) ----
        int aw = tank ? 5 : run ? 3 : 4;
        int ay = tTop + 1 + armBob;
        for (int side = 0; side < 2; side++) {
            int ax0 = side == 0 ? tx0 - aw : tx1;
            int sleeveLen = tank ? 5 : 6;
            int ex = side == 0 ? -1 : 1;                           // arms swing a bit outward
            c.rectO(ax0, ay, ax0 + aw, ay + sleeveLen, shirt);
            c.rect(ax0 + 1, ay + sleeveLen - 1, ax0 + aw - 1, ay + sleeveLen, shirtD);
            for (int i = 0; i < aw; i += 2) c.clear(ax0 + i + side, ay + sleeveLen - 1);
            int fy = ay + sleeveLen;
            int fx0 = ax0 + (run ? ex : 0);
            c.rectO(fx0, fy, fx0 + aw, fy + (tank ? 7 : 5), skin);
            c.rect(fx0 + 1, fy + 2, fx0 + 2, fy + 3, bloodD);                       // a wound
            if (!run) c.rect(fx0 + aw - 2, fy + 1, fx0 + aw - 1, fy + 3, bone);       // a bit of bone
            int hy = fy + (tank ? 7 : 5);
            // the hand: a palm and 3 claws
            int hw = tank ? aw + 1 : aw;
            int hx0 = fx0 - (tank ? 0 : 0);
            c.rectO(hx0, hy, hx0 + hw, hy + 3, skin);
            int claw = run ? 0xFFEDE6C8 : 0xFFD8D0B0;
            for (int f = 0; f < 3; f++) {
                int fxp = hx0 + (hw == 4 ? f * 1 + (f > 0 ? 0 : 0) : f * 2 - (hw > 5 ? 0 : 1)) + (hw == 4 ? 0 : 1);
                fxp = hx0 + Math.min(hw - 1, f * (hw - 1) / 2);
                c.rect(fxp, hy + 3, fxp + 1, hy + 5, skinD);
                c.set(fxp, hy + 5, claw, true);
            }
        }
        // pauldrons for the tank: plates of scrap metal with rivets
        if (tank) {
            for (int side = 0; side < 2; side++) {
                int px0 = side == 0 ? tx0 - 6 : tx1 - 1;
                c.rectO(px0, tTop - 1, px0 + 7, tTop + 4, 0xFF6C727C);
                c.rect(px0 + 1, tTop, px0 + 6, tTop + 1, 0xFF9AA2AE);
                c.set(px0 + 1, tTop + 2, 0xFFD0D6DC, true); c.set(px0 + 5, tTop + 2, 0xFFD0D6DC, true);
            }
            c.rect(tx0, tTop + 8, tx1, tTop + 9, 0xFF6C727C);                         // a chain across the chest
            for (int x = tx0; x < tx1; x += 2) c.set(x, tTop + 9, 0xFFB0B6BE, true);
        }

        // ---- head ----
        double hcx = cx + headDx, hcy = (tank ? 6.4 : 6.5) + headDy;
        double hrx = tank ? 4.2 : spit ? 5 : 4.6, hry = tank ? 4.8 : 5.2;
        // throat sac of the spitter, behind the chin
        if (spit) {
            c.ell(hcx, hcy + 7.5, 3.6, 3.2, 0xFF8BD62C);
            c.ell(hcx, hcy + 7.5, 2.4, 2.0, 0xFFD8FF70, true);
        }
        c.ellO(hcx, hcy, hrx, hry, skin);
        // hair tufts
        int hx = (int) hcx;
        if (!tank) {
            c.rect(hx - 4, (int) (hcy - hry) + 0, hx - 1, (int) (hcy - hry) + 2, hair);
            c.rect(hx + 1, (int) (hcy - hry) + 1, hx + 3, (int) (hcy - hry) + 2, hair);
            c.set(hx - 4, (int) (hcy - hry) + 2, hair, false);
            c.set(hx - 5, (int) (hcy - hry) + 3, hair, false);
        } else {
            c.rect(hx - 3, (int) (hcy - hry) + 0, hx + 3, (int) (hcy - hry) + 1, hair);      // a shaved head with a scar
            c.line(hx - 3, hcy - 2, hx - 1, hcy + 1, 1, bloodD);
        }
        // exposed skull on the right side
        c.rect(hx + 2, (int) (hcy - hry) + 1, hx + 4, (int) (hcy - hry) + 3, bone);
        c.set(hx + 3, (int) (hcy - hry) + 2, dark, false);
        // eyes: dark sockets with a glowing eye (one smaller, one bigger)
        int ey = (int) hcy - 1;
        int eo = tank ? 2 : 3;
        c.rect(hx - eo - 1, ey, hx - eo + 1, ey + 2, dark);
        c.rect(hx + eo - 1, ey, hx + eo + 1, ey + 2, dark);
        c.rect(hx - eo - 1, ey - 1, hx - eo + 2, ey, shade(skinD, 0.8));                    // heavy brows
        c.rect(hx + eo - 2, ey - 1, hx + eo + 1, ey, shade(skinD, 0.8));
        c.set(hx - eo, ey, eye, true);
        c.set(hx + eo, ey, eye, true);
        c.set(hx + eo - 1, ey + 1, shade(eye, 0.7), true);
        if (spit) { c.set(hx - eo - 1, ey, eye, true); c.set(hx + eo, ey + 1, eye, true); }     // bigger glowing eyes
        // nose
        c.set(hx, ey + 2, skinD, false);
        c.set(hx, ey + 3, dark, false);
        // mouth: open, with teeth and blood
        int my = ey + 4;
        int mw = run || spit ? 3 : 2;
        c.rect(hx - mw, my, hx + mw + 1, my + (run || spit ? 3 : 2), dark);
        for (int x = hx - mw; x <= hx + mw; x += 2) c.set(x, my, 0xFFF4F0DC, true);
        for (int x = hx - mw + 1; x <= hx + mw; x += 2) c.set(x, my + (run || spit ? 2 : 1), 0xFFF4F0DC, true);
        if (spit) {                                              // acid drooling out of it
            c.set(hx - 1, my + 3, 0xFF9CFF3C, true); c.set(hx - 1, my + 4, 0xFFC8FF70, true);
            c.set(hx + 2, my + 3, 0xFF9CFF3C, true);
        } else {
            c.set(hx + 1, my + 2, blood, false); c.set(hx + 1, my + 3, blood, false);
        }
        // stitches / scar on the cheek
        c.set(hx - eo - 2, ey + 2, dark, false); c.set(hx - eo - 1, ey + 3, dark, false); c.set(hx - eo - 2, ey + 4, dark, false);
        // ear
        c.rect(hx - (int) hrx - 1, (int) hcy, hx - (int) hrx, (int) hcy + 2, skinD);

        // ---- extras per kind ----
        if (spit) {                                              // glowing pustules on the belly and arms
            int[][] pu = {{(int) cx - 3, tTop + 4}, {(int) cx + 2, tTop + 8}, {(int) cx - 2, tTop + 9}, {(int) cx + 3, tTop + 3}};
            for (int[] q : pu) { c.ell(q[0] + 0.5, q[1] + 0.5, 1.6, 1.6, 0xFF7BC022); c.set(q[0], q[1], 0xFFE8FF98, true); }
        }
        if (run) {                                               // speed lines: torn shirt flap
            c.rect(tx0, tBot - 5, tx0 + 2, tBot - 3, shirtD);
        }
        return c.finish(0xFF0A0806, true);
    }

    // =====================================================================================================
    // perks: glyphs drawn in unit coordinates, used for the cards (big) and on the machines (small)
    // =====================================================================================================
    private static void glyph(Cv c, int perk, int col, double ox, double oy, double s) {
        int hi = mix(col, 0xFFFFFFFF, 0.45), lo = shade(col, 0.55);
        switch (perk) {
            case 0 -> {                                          // quick hands: a magazine inside a reload arrow
                ringArrow(c, ox, oy, s, 0.34, 0.45, col, 30, 330);
                c.rect(ox + s * 0.40, oy + s * 0.40, ox + s * 0.60, oy + s * 0.72, 0xFF4A4E5A);
                c.rect(ox + s * 0.42, oy + s * 0.40, ox + s * 0.46, oy + s * 0.72, 0xFF7A808E);
                c.rect(ox + s * 0.40, oy + s * 0.66, ox + s * 0.60, oy + s * 0.72, 0xFF2A2E38);
                c.ell(ox + s * 0.5, oy + s * 0.34, s * 0.10, s * 0.09, 0xFFE0B040);
                c.rect(ox + s * 0.40, oy + s * 0.34, ox + s * 0.60, oy + s * 0.42, 0xFFE0B040);
                c.rect(ox + s * 0.44, oy + s * 0.34, ox + s * 0.48, oy + s * 0.42, 0xFFFFE890);
            }
            case 1 -> {                                          // heavy hand: a fist with impact lines
                int skin = 0xFFE2B48A;
                c.rect(ox + s * 0.30, oy + s * 0.44, ox + s * 0.76, oy + s * 0.82, skin);
                for (int i = 0; i < 4; i++) c.ell(ox + s * (0.365 + i * 0.1), oy + s * 0.42, s * 0.055, s * 0.07, skin);
                for (int i = 1; i < 4; i++) c.rect(ox + s * (0.31 + i * 0.1), oy + s * 0.42, ox + s * (0.325 + i * 0.1), oy + s * 0.56, shade(skin, 0.7));
                c.rect(ox + s * 0.30, oy + s * 0.56, ox + s * 0.76, oy + s * 0.585, shade(skin, 0.75));
                c.ell(ox + s * 0.28, oy + s * 0.62, s * 0.09, s * 0.13, shade(skin, 0.92));       // thumb
                c.rect(ox + s * 0.32, oy + s * 0.82, ox + s * 0.74, oy + s * 0.95, col);          // cuff
                c.rect(ox + s * 0.32, oy + s * 0.82, ox + s * 0.74, oy + s * 0.85, hi);
                c.line(ox + s * 0.82, oy + s * 0.30, ox + s * 0.94, oy + s * 0.18, s * 0.06, hi);
                c.line(ox + s * 0.86, oy + s * 0.46, ox + s * 0.98, oy + s * 0.46, s * 0.06, hi);
                c.line(ox + s * 0.22, oy + s * 0.22, ox + s * 0.12, oy + s * 0.12, s * 0.06, hi);
            }
            case 2 -> {                                          // light feet: a winged boot
                int boot = 0xFF8A5A30, bootHi = 0xFFB07A44;
                c.poly(new double[]{ox + s * 0.36, ox + s * 0.62, ox + s * 0.62, ox + s * 0.86, ox + s * 0.86, ox + s * 0.34},
                        new double[]{oy + s * 0.22, oy + s * 0.22, oy + s * 0.60, oy + s * 0.68, oy + s * 0.84, oy + s * 0.84}, boot);
                c.rect(ox + s * 0.36, oy + s * 0.22, ox + s * 0.62, oy + s * 0.30, 0xFFE8E0D0);    // the cuff
                c.rect(ox + s * 0.36, oy + s * 0.30, ox + s * 0.42, oy + s * 0.84, bootHi);
                c.rect(ox + s * 0.32, oy + s * 0.84, ox + s * 0.88, oy + s * 0.93, 0xFF2A2420);    // the sole
                for (int i = 0; i < 3; i++) c.ell(ox + s * 0.52, oy + s * (0.36 + i * 0.09), s * 0.025, s * 0.025, 0xFFFFE890, true);
                // the wing: three feathers
                for (int i = 0; i < 3; i++) {
                    c.poly(new double[]{ox + s * 0.34, ox + s * (0.10 - i * 0.01), ox + s * (0.16 - i * 0.01), ox + s * 0.34},
                            new double[]{oy + s * (0.40 + i * 0.07), oy + s * (0.20 + i * 0.12), oy + s * (0.30 + i * 0.12), oy + s * (0.52 + i * 0.07)}, i == 0 ? 0xFFFFFFFF : i == 1 ? mix(0xFFFFFFFF, col, 0.3) : mix(0xFFFFFFFF, col, 0.6));
                }
            }
            case 3 -> {                                          // tough: a shield with a heart
                double[] sx = {0.14, 0.86, 0.86, 0.50, 0.14}, sy = {0.10, 0.10, 0.52, 0.94, 0.52};
                double[] ax = new double[5], ay = new double[5];
                for (int i = 0; i < 5; i++) { ax[i] = ox + s * sx[i]; ay[i] = oy + s * sy[i]; }
                c.poly(ax, ay, lo);
                double[] ix = {0.22, 0.78, 0.78, 0.50, 0.22}, iy = {0.18, 0.18, 0.50, 0.85, 0.50};
                for (int i = 0; i < 5; i++) { ax[i] = ox + s * ix[i]; ay[i] = oy + s * iy[i]; }
                c.poly(ax, ay, col);
                c.poly(new double[]{ox + s * 0.22, ox + s * 0.50, ox + s * 0.50, ox + s * 0.22}, new double[]{oy + s * 0.18, oy + s * 0.18, oy + s * 0.85, oy + s * 0.50}, hi);
                heart(c, ox + s * 0.50, oy + s * 0.50, s * 0.30, 0xFFE03A4A, 0xFFFF9AA8);
            }
            case 4 -> {                                          // regen: a green cross in a circular arrow
                ringArrow(c, ox, oy, s, 0.36, 0.47, col, 40, 340);
                c.rect(ox + s * 0.44, oy + s * 0.28, ox + s * 0.56, oy + s * 0.72, 0xFFEFFFEF);
                c.rect(ox + s * 0.28, oy + s * 0.44, ox + s * 0.72, oy + s * 0.56, 0xFFEFFFEF);
                c.rect(ox + s * 0.46, oy + s * 0.30, ox + s * 0.54, oy + s * 0.70, col);
                c.rect(ox + s * 0.30, oy + s * 0.46, ox + s * 0.70, oy + s * 0.54, col);
            }
            default -> {                                         // greedy: a stack of gold coins and a sparkle
                int gold = 0xFFE8B830, goldD = 0xFF9A6A18, goldH = 0xFFFFEE90;
                for (int i = 0; i < 3; i++) {
                    double y = oy + s * (0.80 - i * 0.17);
                    c.ell(ox + s * 0.46, y + s * 0.07, s * 0.32, s * 0.12, goldD);
                    c.rect(ox + s * 0.14, y - s * 0.02, ox + s * 0.78, y + s * 0.07, gold);
                    c.ell(ox + s * 0.46, y - s * 0.02, s * 0.32, s * 0.12, gold);
                    c.ell(ox + s * 0.46, y - s * 0.02, s * 0.22, s * 0.075, goldH);
                }
                c.ell(ox + s * 0.46, oy + s * 0.31, s * 0.09, s * 0.035, goldD);
                c.rect(ox + s * 0.45, oy + s * 0.25, ox + s * 0.47, oy + s * 0.36, goldD);
                c.rect(ox + s * 0.79, oy + s * 0.14, ox + s * 0.87, oy + s * 0.38, 0xFFFFFFFF, true);          // the sparkle
                c.rect(ox + s * 0.70, oy + s * 0.23, ox + s * 0.96, oy + s * 0.29, 0xFFFFFFFF, true);
            }
        }
    }

    private static void heart(Cv c, double cx, double cy, double s, int col, int hi) {
        c.ell(cx - s * 0.26, cy - s * 0.14, s * 0.28, s * 0.28, col);
        c.ell(cx + s * 0.26, cy - s * 0.14, s * 0.28, s * 0.28, col);
        c.poly(new double[]{cx - s * 0.52, cx + s * 0.52, cx}, new double[]{cy - s * 0.02, cy - s * 0.02, cy + s * 0.55}, col);
        c.ell(cx - s * 0.30, cy - s * 0.22, s * 0.09, s * 0.07, hi);
    }

    /** A circular arrow around the middle: the ring, with an arrow head at the end of it. */
    private static void ringArrow(Cv c, double ox, double oy, double s, double r0, double r1, int col, double a0, double a1) {
        c.ring(ox + s * 0.5, oy + s * 0.5, s * r0, s * r1, a0, a1, col);
        double a = Math.toRadians(a0), rm = s * (r0 + r1) / 2;
        double tx = ox + s * 0.5 + Math.cos(a) * rm, ty = oy + s * 0.5 + Math.sin(a) * rm;
        double dx = -Math.sin(a), dy = Math.cos(a);                // direction of travel at the end (backwards along the ring)
        double nx = Math.cos(a), ny = Math.sin(a);
        double hw = s * 0.15, hl = s * 0.17;
        c.poly(new double[]{tx + nx * hw, tx - nx * hw, tx - dx * hl}, new double[]{ty + ny * hw, ty - ny * hw, ty - dy * hl}, col);
    }

    // =====================================================================================================
    // perk machines
    // =====================================================================================================
    private static int[][] buildMachine(int perk, int col) {
        int n = MACHINE;
        Cv c = new Cv(n, n);
        int body = shade(col, 0.34), bodyHi = shade(col, 0.55), steel = 0xFF3A3E48, steelHi = 0xFF6A707C, glass = 0xFF0C1420;
        c.rect(0, 0, n, n, body);
        // side frame, bright edge lines
        c.rect(0, 0, 1, n, steelHi); c.rect(n - 1, 0, n, n, shade(steel, 0.7));
        c.rect(1, 0, 2, n, steel); c.rect(n - 2, 0, n - 1, n, steel);
        // header sign: a lit panel with the perk symbol
        c.rect(2, 0, n - 2, 5, shade(col, 0.28));
        c.rect(2, 0, n - 2, 1, 0xFFFFFFFF, true);
        c.rect(2, 4, n - 2, 5, col, true);
        Cv sym = new Cv(n, n);
        glyph(sym, perk, col, 4.5, 0.5, 7);
        for (int y = 0; y < 5; y++) for (int x = 2; x < n - 2; x++) if ((sym.p[y * n + x] >>> 24) != 0) c.set(x, y, sym.p[y * n + x], true);
        // the glass front with a glowing bottle
        c.rect(3, 6, n - 3, 12, glass);
        for (int y = 6; y < 12; y++) for (int x = 3; x < n - 3; x++) {                  // a soft glow around the bottle
            double d = Math.abs(x + 0.5 - n / 2.0) / 5.0 + Math.abs(y - 9) / 6.0;
            if (d < 1) c.set(x, y, mix(glass, shade(col, 0.6), 1 - d), true);
        }
        c.rect(7, 6, 9, 8, 0xFFE4E8EE, true);                                              // neck
        c.rect(7, 6, 9, 7, 0xFF9AA0AC, true);                                              // cap
        c.rect(6, 8, 10, 12, 0xFFDCE4EE, true);                                            // glass of the bottle
        c.rect(6, 9, 10, 11, col, true);                                                   // the label
        c.rect(6, 9, 7, 11, mix(col, 0xFFFFFFFF, 0.5), true);
        c.rect(6, 11, 10, 12, shade(col, 0.6), true);
        c.set(4, 7, 0xFFFFFFFF, true); c.set(11, 10, 0xFFFFFFFF, true);                    // sparkles on the glass
        c.rect(3, 6, n - 3, 7, steelHi);                                                   // glass frame
        c.rect(3, 11, n - 3, 12, steelHi);
        // control panel: coin slot, buttons and the dispenser tray
        c.rect(2, 12, n - 2, n, steel);
        c.rect(2, 12, n - 2, 13, steelHi);
        c.rect(3, 13, 5, 15, 0xFF14181E);                                                  // coin slot
        c.rect(3, 13, 5, 14, col, true);
        for (int i = 0; i < 3; i++) c.rect(6 + i * 2, 13, 7 + i * 2, 14, i == 1 ? 0xFFE03030 : 0xFF30C050, true);   // buttons
        c.rect(5, 14, 12, 16, 0xFF0A0C10);                                                 // dispenser tray
        c.rect(5, 14, 12, 15, 0xFF22262E);
        c.rect(12, 13, 14, 15, mix(col, 0xFFFFFFFF, 0.2), true);                           // level lamps
        // rivets and wear
        for (int[] r : new int[][]{{2, 5}, {13, 5}, {2, 12}, {13, 12}}) c.set(r[0], r[1], 0xFFB8BEC8, true);
        for (int x = 0; x < n; x += 3) c.set(x, 15, bodyHi, false);
        int[][] out = c.finish(0, false);
        return out;
    }
}
