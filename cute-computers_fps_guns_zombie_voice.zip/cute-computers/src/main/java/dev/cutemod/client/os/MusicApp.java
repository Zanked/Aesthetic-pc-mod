package dev.cutemod.client.os;

import dev.cutemod.client.player.PlayerEngine;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The music player of the computer, in the style of a modern desktop music app (a frosted light window, or a dark one):
 * a row of pages on top (Home, Songs, Artists, Albums) with the search, a toolbar (rescan, folder, "shuffle all",
 * the sort, an index of letters), a grid of album covers with the name over the picture, and a player bar at the
 * bottom (the song, previous / play / next, shuffle, repeat, the seek bar, the volume).
 * Real songs from the albums (the folder music/ inside the mod and the folder cutemod_music next to the game).
 * The albums are bought in CuteMarket (For the PC > Music). The look follows the light / dark mode of the desktop ({@link Skin#dark()})
 * and, when one of the bought desktop themes is on, wears it: <b>Aero</b> (sky glass, a blue glass player bar, bubbles), <b>Kawaii</b>
 * (candy pink, a lace edge, floating hearts), <b>Retro 98</b> (grey bevelled buttons, a white sunken list, square covers, navy selection)
 * and <b>Anime</b> (a violet dusk, a pink title band, falling sakura petals, yellow stars). See {@link #applyTheme}.
 * A line that does not fit scrolls to and fro under the mouse (see {@link #mtext}); lists scroll with the wheel, the keys and the bar.
 * The music itself is {@link PlayerEngine}, the same as the portable player uses.
 */
public class MusicApp extends App {
    // ---------- layout (the app area is 300 x 166) ----------
    private static final int NAV_Y = 4, NAV_H = 14, SEARCH_W = 72;
    private static final int SEARCH_X = W - 8 - SEARCH_W;
    private static final int TB_Y = 22, TB_H = 14;
    private static final int BODY_Y = 39, BODY_END = 130, BODY_H = BODY_END - BODY_Y;
    private static final int COLS = 5, TILE = 52, GAP = 5, GX = 8, PITCH = TILE + GAP;
    private static final int ROW_H = 11;
    private static final int FOOT_Y = 131, SEEK_X0 = 38, SEEK_X1 = 262, SEEK_Y = 135;
    private static final int CTRL_Y = 153;
    private static final int SH_X = 106, PREV_X = 130, PLAY_X = 162, NEXT_X = 178, REP_X = 202;
    private static final int SPK_X = 226, VOL_X = 242, VOL_W = 50;

    // ---------- the colours of the looks ----------
    /** "" = the classic look (light or dark like the desktop), otherwise "aero", "kawaii", "retro" or "anime". */
    private String look = "";
    private boolean retro;
    private int bgTop, bgBot, cText, cMuted, cCard, cCardH, cSel, cBar, cLine, cBtn, cInk;
    private int aHot, aMain, cSecond;                    // the accent (hovered, normal) and the second accent
    private int cNow, cNowBg, cNowBar, cNowMu;           // the song that plays: its text, its row, its bars, the grey text on its row
    private int cRow, cThumb, cOn, cHole;                // the stripe of a list, the scroll thumb, a switched-on pill, the colour inside the little icons
    private int fText, fMuted, fInk, fBar, fFill, fFill2, fOn, fHot;   // the player bar at the bottom (it has its own colours in the themes)
    private int playIn, playInH;                         // the inside of the round play button

    /**
     * Picks the colours. The classic look follows the light / dark mode of the desktop (Settings); the four bought themes
     * (see {@link Theme}) have their own colours that do not depend on it.
     */
    private void applyTheme() {
        String k = Theme.key();
        look = k.equals("aero") || k.equals("kawaii") || k.equals("retro") || k.equals("anime") || k.equals("stranger") || k.equals("sunny") ? k : "";
        retro = look.equals("retro");
        if (Skin.dark()) {
            bgTop = 0xFF1B1430; bgBot = 0xFF2A1F4A; cText = 0xFFFFFFFF; cMuted = 0xFFB8A8D8;
            cCard = 0x26FFFFFF; cCardH = 0x4CFFFFFF; cSel = 0x66B57BD6; cBar = 0x44FFFFFF; cLine = 0x22FFFFFF; cBtn = 0x33FFFFFF; cInk = 0xFFFFFFFF;
        } else {
            bgTop = 0xFFE9E4F4; bgBot = 0xFFF6DDE8; cText = 0xFF2B2540; cMuted = 0xFF776F8F;
            cCard = 0x66FFFFFF; cCardH = 0xAAFFFFFF; cSel = 0x66B57BD6; cBar = 0x33000000; cLine = 0x22000000; cBtn = 0x88FFFFFF; cInk = 0xFF3A3450;
        }
        aHot = 0xFFE58AAE; aMain = 0xFFD0709A; cSecond = 0xFF2E8B9A;
        cNow = aMain; cNowBg = 0x55F58FB8; cNowBar = aMain; cNowMu = cMuted;
        cRow = 0x18FFFFFF; cThumb = 0xFFB57BD6; cOn = 0xAAB57BD6; cHole = bgBot;
        playIn = 0xFFFFF4F8; playInH = 0xFFFFE8F0;
        fText = cText; fMuted = cMuted; fInk = cInk; fBar = cBar; fFill = aHot; fFill2 = cSecond; fOn = cSecond; fHot = aMain;
        switch (look) {
            case "aero" -> {                                                   // Frutiger Aero: sky glass, navy text, green and blue accents
                bgTop = 0xFFD9F0FF; bgBot = 0xFFF2FBFF; cText = 0xFF14405E; cMuted = 0xFF3F6F96;
                cCard = 0x88FFFFFF; cCardH = 0xCCFFFFFF; cSel = 0x663A9BE8; cBar = 0x332F6F9F; cLine = 0x442F8FD8; cBtn = 0xAAFFFFFF; cInk = 0xFF14405E;
                aHot = 0xFF5DB4F0; aMain = 0xFF2F8FD8; cSecond = 0xFF2E9E55;
                cNow = 0xFF1F6FC4; cNowBg = 0x553A9BE8; cNowBar = 0xFF2F8FD8; cNowMu = cMuted;
                cRow = 0x44FFFFFF; cThumb = 0xFF3A9BE8; cOn = 0xDD2F8FD8; cHole = 0xFFCBEAFB;
                playIn = 0xFFF2FAFF; playInH = 0xFFFFFFFF;
                fText = 0xFFFFFFFF; fMuted = 0xFFD6EEFF; fInk = 0xFFFFFFFF; fBar = 0x55103A66; fFill = 0xFFFFFFFF; fFill2 = 0xFFB6FFC8; fOn = 0xFF3DBE6A; fHot = 0xFFB6FFC8;
            }
            case "kawaii" -> {                                                 // Kawaii Pastel: candy pink, plum text, lavender and yellow
                bgTop = 0xFFFFF0F8; bgBot = 0xFFFFDCEC; cText = 0xFF8A3C6A; cMuted = 0xFFC66A9E;
                cCard = 0x99FFFFFF; cCardH = 0xDDFFFFFF; cSel = 0x66F06AAE; cBar = 0x33D9569F; cLine = 0x44F29BC4; cBtn = 0xBBFFFFFF; cInk = 0xFF8A3C6A;
                aHot = 0xFFFF7CBC; aMain = 0xFFD9569F; cSecond = 0xFF9A6CF0;
                cNow = 0xFFD9569F; cNowBg = 0x55F06AAE; cNowBar = 0xFFD9569F; cNowMu = cMuted;
                cRow = 0x55FFFFFF; cThumb = 0xFFF06AAE; cOn = 0xDDE85A9E; cHole = 0xFFFFE6F2;
                playIn = 0xFFFFF6FB; playInH = 0xFFFFE0EE;
                fText = 0xFFFFFFFF; fMuted = 0xFFFFE6F3; fInk = 0xFFFFFFFF; fBar = 0x66B02F78; fFill = 0xFFFFFFFF; fFill2 = 0xFFFFE066; fOn = 0xFFD9569F; fHot = 0xFFFFF27A;
            }
            case "retro" -> {                                                  // Retro 98: grey panels, a white sunken list, navy selection, teal
                bgTop = 0xFFC0C0C0; bgBot = 0xFFC0C0C0; cText = 0xFF000000; cMuted = 0xFF505050;
                cCard = 0xFFC0C0C0; cCardH = 0xFFD8E4F8; cSel = 0xFF000080; cBar = 0xFFFFFFFF; cLine = 0xFFE4E4E4; cBtn = 0xFFC0C0C0; cInk = 0xFF000000;
                aHot = 0xFF1084D0; aMain = 0xFF000080; cSecond = 0xFF008080;
                cNow = 0xFFFFFFFF; cNowBg = 0xFF000080; cNowBar = 0xFFFFFFFF; cNowMu = 0xFFC8C8FF;
                cRow = 0xFFEFEFEF; cThumb = 0xFF808080; cOn = 0xFF000080; cHole = 0xFFC0C0C0;
                playIn = 0xFFC0C0C0; playInH = 0xFFD8D8D8;
                fText = 0xFF000000; fMuted = 0xFF404040; fInk = 0xFF000000; fBar = 0xFFFFFFFF; fFill = 0xFF000080; fFill2 = 0xFF000080; fOn = 0xFF000080; fHot = 0xFF000080;
            }
            case "anime" -> {                                                  // Anime Sakura: a violet dusk, pink band, white text, yellow stars
                bgTop = 0xFF40298A; bgBot = 0xFF7A3AA0; cText = 0xFFFFFFFF; cMuted = 0xFFE6D8FF;
                cCard = 0x30FFFFFF; cCardH = 0x55FFFFFF; cSel = 0x66FF8CC8; cBar = 0x44FFFFFF; cLine = 0x33FFFFFF; cBtn = 0x44FFFFFF; cInk = 0xFFFFFFFF;
                aHot = 0xFFFFA6D8; aMain = 0xFFF47DBB; cSecond = 0xFFFFE86A;
                cNow = 0xFFFFE86A; cNowBg = 0x66FF8CC8; cNowBar = 0xFFFFE86A; cNowMu = 0xFFFFE6F6;
                cRow = 0x18FFFFFF; cThumb = 0xFFFF8CC8; cOn = 0xDDF06AAE; cHole = 0xFFB85CCB;
                playIn = 0xFFFFF4FB; playInH = 0xFFFFE0F2;
                fText = 0xFFFFFFFF; fMuted = 0xFFFFE6F6; fInk = 0xFFFFFFFF; fBar = 0x55200050; fFill = 0xFFFFE86A; fFill2 = 0xFFFFA6D8; fOn = 0xFFFF6BB0; fHot = 0xFFFFE86A;
            }
            case "sunny" -> {                                                  // Sunny Chick: cream and honey, brown text, orange accents
                bgTop = 0xFFFFF6CC; bgBot = 0xFFFFE08A; cText = 0xFF5A3208; cMuted = 0xFF9A6424;
                cCard = 0x99FFFFFF; cCardH = 0xDDFFFFFF; cSel = 0x66FF9A2E; cBar = 0x33B8741C; cLine = 0x44E09A1E; cBtn = 0xBBFFFFFF; cInk = 0xFF5A3208;
                aHot = 0xFFFFA83A; aMain = 0xFFE8750A; cSecond = 0xFF3E9A4A;
                cNow = 0xFFC25A00; cNowBg = 0x55FFA83A; cNowBar = 0xFFE8750A; cNowMu = cMuted;
                cRow = 0x55FFFFFF; cThumb = 0xFFFF9A2E; cOn = 0xDDE8750A; cHole = 0xFFFFEDB0;
                playIn = 0xFFFFFBEA; playInH = 0xFFFFF0C4;
                fText = 0xFFFFFFFF; fMuted = 0xFFFFF0C8; fInk = 0xFFFFFFFF; fBar = 0x66A05000; fFill = 0xFFFFFFFF; fFill2 = 0xFFFFF27A; fOn = 0xFFFFFFFF; fHot = 0xFFFFF27A;
            }
            case "stranger" -> {                                               // The Stranger: a violet night, pale lilac text, gold accents
                bgTop = 0xFF140E3A; bgBot = 0xFF2A1F5C; cText = 0xFFEDE6FF; cMuted = 0xFFA79BD0;
                cCard = 0x26FFFFFF; cCardH = 0x44FFFFFF; cSel = 0x66FFD866; cBar = 0x44FFFFFF; cLine = 0x33FFFFFF; cBtn = 0x33FFFFFF; cInk = 0xFFEDE6FF;
                aHot = 0xFFFFD866; aMain = 0xFFE0A818; cSecond = 0xFFB79CFF;
                cNow = 0xFFFFD866; cNowBg = 0x33FFD866; cNowBar = 0xFFFFD866; cNowMu = 0xFFEDE6FF;
                cRow = 0x18FFFFFF; cThumb = 0xFFFFD866; cOn = 0xDDB79CFF; cHole = 0xFF1A1244;
                playIn = 0xFFF1ECFF; playInH = 0xFFFFFFFF;
                fText = 0xFFEDE6FF; fMuted = 0xFFA79BD0; fInk = 0xFFEDE6FF; fBar = 0x44000000; fFill = 0xFFFFD866; fFill2 = 0xFFB79CFF; fOn = 0xFFB79CFF; fHot = 0xFFFFD866;
            }
            default -> {}
        }
    }

    // ---------- state ----------
    private int tab = 3;                         // 0 Home, 1 Songs, 2 Artists, 3 Albums (albums are bought in CuteMarket, not here)
    private String openAlbum;                    // the album whose page is open (null = a page of the list)
    private String artistFilter;                 // Albums page: only the albums of this artist
    private int sort;                            // 0 by title, 1 by artist
    private boolean desc;
    private int scroll;                          // pixels, of the grid, the song list or the song list of an album
    private String query = "";
    private boolean typing;
    private int drag;                            // 1 = seek bar, 2 = volume, 3 = the scroll bar
    private int vMax, sbTop, sbH, sbTotal, sbVis;   // of the view that was drawn last: the largest scroll and the scroll bar (sbTotal = 0: none)
    private long dragMs;
    private float lastVol = 0.6F;
    private int ticks, mx, my;
    private String flash = "";
    private int flashT;
    private boolean started;                     // this app started the music (so closing the app stops it)
    private boolean portable;                    // inside the portable player: only the albums put on the player, and the music goes on when the window is closed

    /** Turns this app into the window of the portable player (see PlayerScreen): the same look, but the library is the albums put on the player. */
    public MusicApp portable() { portable = true; return this; }

    /** Is this album in the library that is shown (owned on the PC, put on the player in the portable window)? */
    private boolean lib(Albums.Album a) { return portable ? a.onPlayer() : a.owned(); }

    private String emptyKey() { return portable ? "cutemod.music.libempty.player" : "cutemod.music.libempty"; }

    private void say(String s) { flash = s; flashT = 180; }

    // ---------- note-block sounds for the other apps (radio, videos...) ----------
    static void note(int instrument, int n, float volume) {
        SoundEvent ev = switch (instrument) {
            case 0 -> SoundEvents.NOTE_BLOCK_HARP.value();
            case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
            case 2 -> SoundEvents.NOTE_BLOCK_BASS.value();
            default -> SoundEvents.NOTE_BLOCK_CHIME.value();
        };
        float pitch = (float) Math.max(0.5, Math.min(2.0, Math.pow(2.0, (n - 12) / 12.0)));
        Sfx.musicNote(ev, pitch, volume);
    }

    // ---------- for the desktop (taskbar, widget) ----------
    @Override public Component title() { return Component.translatable("cutemod.os.music"); }

    @Override public Component hint() { return Component.translatable("cutemod.os.hint.music"); }

    @Override
    public Component status() {
        return PlayerEngine.isPlaying() ? Component.translatable("cutemod.music.now", trackName())
                : Component.translatable("cutemod.music.paused");
    }

    @Override public boolean busy() { return PlayerEngine.isPlaying(); }

    @Override public boolean background() { return PlayerEngine.isPlaying(); }

    @Override
    public void close() { if (started && !portable) { PlayerEngine.stop(); started = false; } }

    boolean active() { return PlayerEngine.current() != null && (PlayerEngine.isPlaying() || PlayerEngine.position() > 0); }

    boolean isPlaying() { return PlayerEngine.isPlaying(); }

    String trackName() { var c = PlayerEngine.current(); return c == null ? "" : c.track().title(); }

    float progress() {
        long len = PlayerEngine.length();
        return len <= 0 ? 0F : Math.min(1F, PlayerEngine.position() / (float) len);
    }

    void toggle() {
        if (PlayerEngine.current() == null) {
            for (Albums.Album a : Albums.all()) if (lib(a)) { playAlbum(a, 0); return; }
            return;
        }
        PlayerEngine.toggle();
    }

    void nextTrack() { PlayerEngine.next(); }

    void prevTrack() { PlayerEngine.prev(); }

    // ---------- data ----------
    private record Tile(Albums.Album cover, String title, String sub, Albums.Album album, String artist) {}

    private record Song(Albums.Album album, Albums.Track track) {}

    private static String norm(String s) { return s.trim().toLowerCase(Locale.ROOT); }

    private boolean searching() { return !query.trim().isEmpty(); }

    private int effTab() { return tab == 0 && searching() ? 1 : tab; }

    /** The "Artist - " that every track of an album starts with (or ""): it only eats the width of the lists. */
    private static String commonPrefix(Albums.Album a) {
        var tr = a.tracks();
        if (tr.size() < 2) return "";
        String first = tr.get(0).title();
        int i = first.indexOf(" - ");
        if (i <= 0) return "";
        String pre = first.substring(0, i + 3);
        for (var t : tr) if (!t.title().startsWith(pre)) return "";
        return pre;
    }

    private static String shortTitle(Albums.Album a, String title) {
        String pre = commonPrefix(a);
        return !pre.isEmpty() && title.startsWith(pre) && title.length() > pre.length() ? title.substring(pre.length()) : title;
    }

    private static String artistOf(Albums.Album a) {
        if (!a.artist().isEmpty()) return a.artist();
        String pre = commonPrefix(a);
        return pre.isEmpty() ? "?" : pre.substring(0, pre.length() - 3);
    }

    private static boolean matches(Albums.Album a, String q) {
        return a.title().toLowerCase(Locale.ROOT).contains(q) || a.artist().toLowerCase(Locale.ROOT).contains(q);
    }

    private static char letterOf(String s) {
        if (s == null || s.isEmpty()) return '#';
        char c = Character.toUpperCase(s.charAt(0));
        return Character.isLetter(c) ? c : '#';
    }

    private Albums.Album albumById(String id) {
        if (id != null) for (Albums.Album a : Albums.all()) if (a.id().equals(id)) return a;
        return null;
    }

    private Albums.Album open() { return albumById(openAlbum); }

    private List<Albums.Album> sortedAlbums(boolean store) {
        List<Albums.Album> out = new ArrayList<>();
        String q = norm(query);
        for (Albums.Album a : Albums.all()) {
            if (!store && !lib(a)) continue;
            if (!q.isEmpty() && !matches(a, q)) continue;
            if (!store && artistFilter != null && !artistOf(a).equals(artistFilter)) continue;
            out.add(a);
        }
        out.sort((x, y) -> {
            int c = sort == 1 ? artistOf(x).compareToIgnoreCase(artistOf(y)) : x.title().compareToIgnoreCase(y.title());
            if (c == 0) c = x.title().compareToIgnoreCase(y.title());
            return desc ? -c : c;
        });
        return out;
    }

    private List<Tile> tiles() {
        List<Tile> out = new ArrayList<>();
        int et = effTab();
        if (et == 2) {                                                       // artists: one tile each
            Map<String, List<Albums.Album>> by = new LinkedHashMap<>();
            String q = norm(query);
            for (Albums.Album a : Albums.all()) {
                if (!lib(a)) continue;
                if (!q.isEmpty() && !artistOf(a).toLowerCase(Locale.ROOT).contains(q)) continue;
                by.computeIfAbsent(artistOf(a), k -> new ArrayList<>()).add(a);
            }
            List<String> names = new ArrayList<>(by.keySet());
            names.sort((x, y) -> desc ? y.compareToIgnoreCase(x) : x.compareToIgnoreCase(y));
            for (String n : names) out.add(new Tile(by.get(n).get(0), n, t("cutemod.music.albums.n", by.get(n).size()), null, n));
            return out;
        }
        for (Albums.Album a : sortedAlbums(false)) {
            out.add(new Tile(a, a.title(), a.artist().isEmpty() ? t("cutemod.player.count", a.tracks().size()) : a.artist(), a, a.artist()));
        }
        return out;
    }

    private List<Song> songs() {
        List<Song> out = new ArrayList<>();
        String q = norm(query);
        for (Albums.Album a : Albums.all()) {
            if (!lib(a)) continue;
            boolean albumHit = !q.isEmpty() && matches(a, q);
            for (Albums.Track tk : a.tracks()) if (q.isEmpty() || albumHit || tk.title().toLowerCase(Locale.ROOT).contains(q)) out.add(new Song(a, tk));
        }
        out.sort((x, y) -> {
            int c = sort == 1 ? artistOf(x.album()).compareToIgnoreCase(artistOf(y.album())) : x.track().title().compareToIgnoreCase(y.track().title());
            return desc ? -c : c;
        });
        return out;
    }

    private static List<PlayerEngine.Entry> entries(Albums.Album a) {
        List<PlayerEngine.Entry> l = new ArrayList<>();
        for (Albums.Track tk : a.tracks()) l.add(new PlayerEngine.Entry(a, tk));
        return l;
    }

    private static List<PlayerEngine.Entry> entriesOf(List<Song> l) {
        List<PlayerEngine.Entry> out = new ArrayList<>();
        for (Song s : l) out.add(new PlayerEngine.Entry(s.album(), s.track()));
        return out;
    }

    private void playAlbum(Albums.Album a, int from) { playQueue(entries(a), from); }

    private void playQueue(List<PlayerEngine.Entry> q, int from) { if (q.isEmpty()) return; started = true; PlayerEngine.play(q, from, portable); }

    private List<Song> allOwnedSongs() {
        List<Song> out = new ArrayList<>();
        for (Albums.Album a : Albums.all()) if (lib(a)) for (Albums.Track tk : a.tracks()) out.add(new Song(a, tk));
        return out;
    }

    private void shuffleAll() {
        List<Song> all = allOwnedSongs();
        if (all.isEmpty()) { say(t(emptyKey()).replace("|", " ")); return; }
        PlayerEngine.setShuffle(true);
        playQueue(entriesOf(all), (int) (Math.random() * all.size()));
    }

    private void playArtist(String name) {
        List<PlayerEngine.Entry> q = new ArrayList<>();
        for (Albums.Album a : Albums.all()) if (lib(a) && artistOf(a).equals(name)) q.addAll(entries(a));
        playQueue(q, 0);
    }

    private static int totalMinutes(Albums.Album a) {
        int s = 0;
        for (Albums.Track tk : a.tracks()) s += tk.seconds();
        return Math.max(1, s / 60);
    }

    private static String time(long ms) {
        long s = Math.max(0, ms / 1000);
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    // ---------- drawing helpers ----------
    private static int tw(String s) { return CuteFont.width(font(), s); }

    private static void str(GuiGraphics g, String s, int x, int y, int color) { Skin.str(g, font(), s, x, y, color, false); }

    private static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        int n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= n; i++) {
            int x = n == 0 ? x0 : x0 + (x1 - x0) * i / n, y = n == 0 ? y0 : y0 + (y1 - y0) * i / n;
            g.fill(x, y, x + 1, y + 1, c);
        }
    }

    /** A triangle pointing right (dir 1) or left (dir -1); size = its height. */
    private static void tri(GuiGraphics g, int x, int y, int size, int dir, int color) {
        int cols = size / 2 + 1;
        for (int c = 0; c < cols; c++) {
            int xx = dir > 0 ? x + c : x + cols - 1 - c;
            g.fill(xx, y + c, xx + 1, y + size - c, color);
        }
    }

    private static void coverTile(GuiGraphics g, Albums.Album a, int x, int y, int size) {
        RoundCover.draw(g, a, x, y, size);
        if (!RoundCover.hasPicture(a) && size >= 12) {
            String l = RoundCover.letter(a);
            str(g, l, x + (size - tw(l)) / 2, y + size / 2 - 4, 0xFFFFFFFF);
        }
    }

    /** A dark veil over the bottom h rows of a rounded cover (so the name on it can be read on any picture). */
    private static void veil(GuiGraphics g, int x, int y, int size, int h, int maxAlpha) {
        int r = RoundCover.radius(size);
        for (int dy = size - h; dy < size; dy++) {
            int in = RoundCover.inset(dy, size, r);
            float f = (dy - (size - h)) / (float) h;
            g.fill(x + in, y + dy, x + size - in, y + dy + 1, ((int) (maxAlpha * f * f) << 24));
        }
    }

    /** A rounded rectangle; Retro 98 has no round corners. */
    private void rr(GuiGraphics g, int x, int y, int w, int h, int r, int argb) {
        if (retro) g.fill(x, y, x + w, y + h, argb);
        else roundRect(g, x, y, w, h, r, argb);
    }

    /** A filled circle; a square in Retro 98. */
    private void orb(GuiGraphics g, int cx, int cy, int r, int argb) {
        if (retro) g.fill(cx - r, cy - r, cx + r + 1, cy + r + 1, argb);
        else disc(g, cx, cy, r, argb);
    }

    /** A small button / chip. Retro 98: a bevelled grey button (pressed and navy when it is on); the others: a pill with a glass shine. */
    private void pill(GuiGraphics g, int x, int y, int w, int h, boolean on, boolean hov) {
        if (retro) { Theme.bevel(g, x, y, w, h, !on, on ? cOn : (hov ? cCardH : cCard)); return; }
        rr(g, x, y, w, h, h / 2 + 1, on ? cOn : (hov ? cCardH : cCard));
        if (!look.isEmpty() && h >= 8) rr(g, x + 2, y + 1, w - 4, Math.max(2, h / 2 - 1), h / 4 + 1, 0x30FFFFFF);
    }

    /** The big coloured button (play): a pill, or a raised navy button in Retro 98. */
    private void accentBtn(GuiGraphics g, int x, int y, int w, int h, boolean hov) {
        if (retro) { Theme.bevel(g, x, y, w, h, true, hov ? aHot : aMain); return; }
        rr(g, x, y, w, h, 7, hov ? aHot : aMain);
        if (!look.isEmpty()) rr(g, x + 2, y + 1, w - 4, Math.max(2, h / 2 - 1), 3, 0x30FFFFFF);
    }

    /** The round highlight behind a switched-on button of the player bar. */
    private void toggleBox(GuiGraphics g, int x, int y, int w, int h) {
        if (retro) Theme.bevel(g, x, y, w, h, false, fOn);
        else rr(g, x, y, w, h, 8, fOn);
    }

    /** The groove of the seek bar and of the volume: a thin rounded line, or a sunken white groove filled with blocks in Retro 98. */
    private void track(GuiGraphics g, int x, int y, int w, int fillW, int fillColor) {
        if (retro) {
            Theme.bevel(g, x, y - 1, w, 5, false, 0xFFFFFFFF);
            for (int bx = x + 1; bx + 3 <= x + 1 + fillW && bx + 3 <= x + w - 1; bx += 4) g.fill(bx, y, bx + 3, y + 3, fillColor);
            return;
        }
        rr(g, x, y, w, 3, 1, fBar);
        if (fillW > 0) rr(g, x, y, fillW, 3, 1, fillColor);
    }

    /** The handle of a slider: a little ball, or a raised grey block in Retro 98. */
    private void knob(GuiGraphics g, int cx, int cy) {
        if (retro) Theme.bevel(g, cx - 2, cy - 4, 5, 9, true, 0xFFC0C0C0);
        else disc(g, cx, cy, 3, fInk);
    }

    /** The round play / pause button of the player bar (a raised grey square in Retro 98). */
    private void playButton(GuiGraphics g, boolean hov, boolean playing) {
        if (retro) {
            Theme.bevel(g, PLAY_X - 9, CTRL_Y - 9, 18, 18, true, hov ? playInH : playIn);
            if (playing) { g.fill(PLAY_X - 3, CTRL_Y - 4, PLAY_X - 1, CTRL_Y + 4, 0xFF000000); g.fill(PLAY_X + 1, CTRL_Y - 4, PLAY_X + 3, CTRL_Y + 4, 0xFF000000); }
            else tri(g, PLAY_X - 2, CTRL_Y - 5, 10, 1, 0xFF000000);
            return;
        }
        disc(g, PLAY_X, CTRL_Y, 10, hov ? aHot : aMain);
        disc(g, PLAY_X, CTRL_Y, 8, hov ? playInH : playIn);
        if (look.equals("aero")) rr(g, PLAY_X - 5, CTRL_Y - 8, 10, 3, 1, 0x66FFFFFF);        // the gloss of an Aero orb
        if (playing) { g.fill(PLAY_X - 3, CTRL_Y - 4, PLAY_X - 1, CTRL_Y + 4, aMain); g.fill(PLAY_X + 1, CTRL_Y - 4, PLAY_X + 3, CTRL_Y + 4, aMain); }
        else tri(g, PLAY_X - 2, CTRL_Y - 5, 10, 1, aMain);
    }

    /** The background of the window: the gradient, the header band of the look and its floating bits (bubbles, hearts, petals). */
    private void backdrop(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, bgTop, bgBot);
        int hy = BODY_Y - 2;
        switch (look) {
            case "aero" -> {                                                   // a pane of sky glass behind the pages and the toolbar
                g.fillGradient(0, 0, W, hy, 0xFFA9DBF8, 0xFFD8F0FD);
                g.fill(0, 1, W, hy / 2, 0x33FFFFFF);
                g.fill(0, 0, W, 1, 0xFFFFFFFF);
                g.fill(0, hy, W, hy + 1, 0xFF7FB8E0);
            }
            case "kawaii" -> {                                                 // a lace of little scallops under the header
                for (int px = 2; px < W - 2; px += 6) {
                    g.fill(px, hy, px + 4, hy + 1, 0xDDFFFFFF);
                    g.fill(px + 1, hy + 1, px + 3, hy + 2, 0xDDFFFFFF);
                }
                g.fill(0, 0, W, 1, 0xFFFFFFFF);
            }
            case "sunny" -> {                                                  // an amber band, a cream edge, and a chick that sits in the corner
                g.fillGradient(0, 0, W, hy, 0xFFFFB52E, 0xFFF07A0C);
                g.fill(0, 1, W, hy / 2, 0x2AFFFFFF);
                g.fill(0, 0, W, 1, 0xCCFFF2B0);
                g.fill(0, hy, W, hy + 1, 0xFFB8560A);
                Critters.mini(g, 0, W - 11, Math.max(0, hy - 8), 0xFF);
            }
            case "anime" -> {                                                  // the candy pink to violet band of the Anime menu bar
                g.fillGradient(0, 0, W, hy, 0xFFF06AA8, 0xFFA65AD8);
                g.fill(0, 1, W, hy / 2, 0x2AFFFFFF);
                g.fill(0, 0, W, 1, 0xAAFFFFFF);
                g.fill(0, hy, W, hy + 1, 0xFFFFC4E4);
            }
            case "retro" -> Theme.bevel(g, 3, BODY_Y - 1, W - 6, BODY_H + 2, false, 0xFFFFFFFF);   // the white sunken list
            default -> {}
        }
        if (!look.isEmpty() && !retro) {
            g.enableScissor(shell.absX(), shell.absY(), shell.absX() + W, shell.absY() + FOOT_Y);
            Theme.ambient(g, 0, 0, W, FOOT_Y);
            g.disableScissor();
        }
    }

    /** The panel behind the player bar. */
    private void footerBack(GuiGraphics g) {
        int y0 = FOOT_Y, y1 = FOOT_Y + 35;
        switch (look) {
            case "aero" -> {                                                   // blue glass with a shine
                g.fillGradient(0, y0, W, y1, 0xFF5DB4F0, 0xFF1F6FC4);
                g.fill(0, y0 + 1, W, y0 + 18, 0x30FFFFFF);
                g.fill(0, y0, W, y0 + 1, 0xDDFFFFFF);
            }
            case "kawaii" -> {                                                 // candy pink with a white lace edge
                g.fillGradient(0, y0, W, y1, 0xFFFFA6D0, 0xFFF579B4);
                g.fill(0, y0 + 1, W, y0 + 18, 0x30FFFFFF);
                for (int px = 2; px < W - 2; px += 6) {
                    g.fill(px, y0, px + 4, y0 + 1, 0xFFFFFFFF);
                    g.fill(px + 1, y0 + 1, px + 3, y0 + 2, 0xFFFFFFFF);
                }
            }
            case "retro" -> {                                                  // a grey taskbar panel
                g.fill(0, y0, W, y1, 0xFFC0C0C0);
                g.fill(0, y0, W, y0 + 1, 0xFF000000);
                g.fill(0, y0 + 1, W, y0 + 2, 0xFFFFFFFF);
            }
            case "sunny" -> {                                                  // honey to orange with a cream edge and a row of dots
                g.fillGradient(0, y0, W, y1, 0xFFFFB52E, 0xFFF07A0C);
                g.fill(0, y0 + 1, W, y0 + 18, 0x2AFFFFFF);
                g.fill(0, y0, W, y0 + 1, 0xFFFFF2B0);
                for (int px = 3; px < W - 3; px += 6) g.fill(px, y0 + 2, px + 2, y0 + 3, 0x88FFF4C0);
            }
            case "anime" -> {                                                  // plum glass, a pale top edge and a few twinkles
                g.fillGradient(0, y0, W, y1, 0xFFC0509E, 0xFF5E3AA8);
                g.fill(0, y0 + 1, W, y0 + 18, 0x2AFFFFFF);
                g.fill(0, y0, W, y0 + 1, 0xFFFFC4E4);
                int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
                for (int i = 0; i < 4; i++) {
                    if ((t + i * 23) % 50 >= 6) continue;
                    Theme.animeStar(g, 20 + i * 80 + (i % 2) * 13, y0 + 6 + (i % 3) * 10, 1, 0x99FFFFFF);
                }
            }
            default -> {
                g.fill(0, y0, W, y1, 0x14000000);
                g.fill(0, y0, W, y0 + 1, cLine);
            }
        }
    }

    /** The scroll bar at the right edge of a list: remembers where it is so it can be dragged. */
    private void scrollBar(GuiGraphics g, int total, int visible, int top, int h) {
        sbTotal = total; sbVis = visible; sbTop = top; sbH = h;
        vMax = Math.max(0, total - visible);
        if (total <= visible) { sbTotal = 0; return; }
        int bh = Math.max(10, h * visible / total);
        int by = top + (h - bh) * scroll / Math.max(1, total - visible);
        boolean hot = drag == 3 || in(mx, my, W - 9, top, 9, h);
        rr(g, W - 5, top, 3, h, 1, cLine);
        rr(g, W - 5, by, 3, bh, 1, hot ? cSecond : cThumb);
    }

    /**
     * A line that must fit in maxW pixels. It is drawn as it is when it fits; otherwise it is shrunk and cut, and while
     * go is true (the mouse is over it, or it is the song that plays) it slides to and fro so that all of it can be read.
     */
    private void mtext(GuiGraphics g, String s, int x, int y, int maxW, int color, boolean go) {
        int w = tw(s);
        if (w <= maxW) { CuteFont.draw(g, font(), s, x, y, color, false); return; }
        if (!go) { CuteFont.draw(g, font(), CuteFont.cut(font(), s, maxW), x, y, color, false); return; }
        int over = w - maxW + 2;
        long run = over * 28L, hold = 700L;
        long t = System.currentTimeMillis() % (hold * 2 + run * 2);
        long off = t < hold ? 0 : t < hold + run ? (t - hold) / 28L : t < hold * 2 + run ? over : over - (t - hold * 2 - run) / 28L;
        off = Math.max(0, Math.min(over, off));
        g.enableScissor(shell.absX() + x, shell.absY() + y - 1, shell.absX() + x + maxW, shell.absY() + y + 10);
        CuteFont.draw(g, font(), s, x - (int) off, y, color, false);
        g.disableScissor();
    }

    // ---------- the little icons (7 x 7) ----------
    private void iconHome(GuiGraphics g, int x, int y, int c) {
        for (int i = 0; i < 4; i++) g.fill(x + 3 - i, y + i, x + 4 + i, y + i + 1, c);
        g.fill(x + 1, y + 4, x + 6, y + 7, c);
        g.fill(x + 3, y + 5, x + 4, y + 7, cHole);
    }

    private void iconNote(GuiGraphics g, int x, int y, int c) {
        g.fill(x + 3, y, x + 4, y + 6, c); g.fill(x + 1, y + 5, x + 4, y + 7, c); g.fill(x + 4, y, x + 7, y + 2, c);
    }

    private void iconPeople(GuiGraphics g, int x, int y, int c) {
        disc(g, x + 3, y + 2, 2, c); g.fill(x + 1, y + 5, x + 6, y + 7, c);
    }

    private void iconAlbum(GuiGraphics g, int x, int y, int c) {
        disc(g, x + 3, y + 3, 3, c); disc(g, x + 3, y + 3, 1, cHole);
    }

    private void iconBag(GuiGraphics g, int x, int y, int c) {
        g.fill(x + 1, y + 2, x + 6, y + 7, c); g.fill(x + 2, y, x + 5, y + 1, c); g.fill(x + 2, y, x + 3, y + 3, c); g.fill(x + 4, y, x + 5, y + 3, c);
        g.fill(x + 2, y + 3, x + 3, y + 4, cHole); g.fill(x + 4, y + 3, x + 5, y + 4, cHole);
    }

    private static void iconShuffle(GuiGraphics g, int x, int y, int c) {
        line(g, x, y + 6, x + 7, y, c); line(g, x, y, x + 7, y + 6, c);
        g.fill(x + 6, y - 1, x + 9, y, c); g.fill(x + 8, y - 1, x + 9, y + 2, c);
        g.fill(x + 6, y + 6, x + 9, y + 7, c); g.fill(x + 8, y + 4, x + 9, y + 7, c);
    }

    private static void iconRepeat(GuiGraphics g, int x, int y, int c, boolean one) {
        g.fill(x + 1, y, x + 9, y + 1, c); g.fill(x + 9, y, x + 10, y + 5, c); g.fill(x + 1, y + 5, x + 9, y + 6, c); g.fill(x, y + 1, x + 1, y + 6, c);
        g.fill(x + 7, y - 1, x + 8, y + 2, c); g.fill(x + 8, y, x + 9, y + 1, c);
        g.fill(x + 1, y + 4, x + 2, y + 7, c); g.fill(x + 2, y + 5, x + 3, y + 6, c);
        if (one) g.fill(x + 4, y + 1, x + 6, y + 5, c);
    }

    private static void iconSpeaker(GuiGraphics g, int x, int y, int c, boolean muted) {
        g.fill(x, y + 2, x + 3, y + 6, c); tri(g, x + 3, y, 8, 1, c);
        if (muted) { line(g, x + 7, y + 1, x + 11, y + 7, c); line(g, x + 7, y + 7, x + 11, y + 1, c); }
        else { g.fill(x + 8, y + 3, x + 9, y + 5, c); g.fill(x + 10, y + 1, x + 11, y + 7, c); }
    }

    private void iconRefresh(GuiGraphics g, int x, int y, int c) {
        g.fill(x + 1, y, x + 6, y + 1, c); g.fill(x + 6, y + 1, x + 7, y + 3, c);
        g.fill(x, y + 1, x + 1, y + 7, c); g.fill(x + 1, y + 7, x + 6, y + 8, c);
        g.fill(x + 6, y + 5, x + 7, y + 7, c); g.fill(x + 4, y - 1, x + 5, y + 2, c);
    }

    private void iconFolder(GuiGraphics g, int x, int y, int c) {
        g.fill(x, y, x + 4, y + 1, c); g.fill(x, y + 1, x + 10, y + 7, c); g.fill(x + 1, y + 3, x + 9, y + 6, hoverFill());
    }

    private int hoverFill() { return cHole; }

    private void iconSearch(GuiGraphics g, int x, int y, int c) {
        g.fill(x + 1, y, x + 4, y + 1, c); g.fill(x + 1, y + 4, x + 4, y + 5, c);
        g.fill(x, y + 1, x + 1, y + 4, c); g.fill(x + 4, y + 1, x + 5, y + 4, c);
        g.fill(x + 4, y + 5, x + 6, y + 7, c);
    }

    // ---------- render ----------
    @Override
    public void mouse(int x, int y) { mx = x; my = y; }

    @Override
    public void tick() {
        ticks++;
        if (flashT > 0) flashT--;
    }

    @Override
    public void render(GuiGraphics g, int mxx, int myy) {
        mx = mxx; my = myy;
        applyTheme();
        if (!look.isEmpty()) Skin.appTheme(false);               // the player has its own colours for every look: the desktop must not tint them again
        RoundCover.square(retro);
        try { draw(g); } finally { RoundCover.square(false); }
    }

    private void draw(GuiGraphics g) {
        backdrop(g);
        vMax = 0; sbTotal = 0; sbVis = 0;
        renderNav(g);
        renderToolbar(g);
        g.enableScissor(shell.absX(), shell.absY() + BODY_Y, shell.absX() + W, shell.absY() + BODY_END);
        if (openAlbum != null && open() != null) renderDetail(g);
        else switch (effTab()) {
            case 0 -> renderHome(g);
            case 1 -> renderSongs(g);
            default -> renderGrid(g);
        }
        g.disableScissor();
        renderFooter(g);
        if (flashT > 0) {
            int w = Math.min(W - 24, tw(flash) + 16);
            rr(g, (W - w) / 2, 112, w, 14, 6, retro ? 0xFF000080 : 0xEE3A2A66);
            fitText(g, font(), flash, W / 2, 115, w - 8, 0xFFFFFFFF, true);
        }
        if (in(mx, my, 6, TB_Y, 14, TB_H) && openAlbum == null) tip(g, t("cutemod.music.rescan.tip"));
        else if (in(mx, my, 22, TB_Y, 14, TB_H) && openAlbum == null) tip(g, t("cutemod.music.folder.tip"));
    }

    private void tip(GuiGraphics g, String s) {
        int w = tw(s) + 8, x = Math.min(mx, W - w - 2), y = TB_Y + TB_H + 2;
        if (retro) { g.fill(x - 1, y - 1, x + w + 1, y + 13, 0xFF000000); g.fill(x, y, x + w, y + 12, 0xFFFFFFE1); str(g, s, x + 4, y + 2, 0xFF000000); return; }
        rr(g, x, y, w, 12, 4, 0xF0120E22);
        str(g, s, x + 4, y + 2, 0xFFFFFFFF);
    }

    // ----- the pages on top and the search -----
    private static final String[] TAB_KEYS = {"home", "songs", "artists", "albums"};
    private final int[] tabX = new int[4], tabW = new int[4];
    private boolean tabIcons;

    private void layoutNav() {
        int avail = SEARCH_X - 6 - 6, nat = 0;
        int[] w = new int[4];
        for (int i = 0; i < 4; i++) w[i] = tw(t("cutemod.music.tab." + TAB_KEYS[i]));
        for (int i = 0; i < 4; i++) nat += w[i] + 10;
        tabIcons = nat + 4 * 9 <= avail;
        if (tabIcons) for (int i = 0; i < 4; i++) w[i] += 9;
        int sum = 0;
        for (int i = 0; i < 4; i++) sum += w[i] + 10;
        float k = sum > avail ? avail / (float) sum : 1F;
        int x = 6;
        for (int i = 0; i < 4; i++) {
            tabX[i] = x;
            tabW[i] = Math.round((w[i] + 10) * k);
            x += tabW[i];
        }
    }

    private void renderNav(GuiGraphics g) {
        layoutNav();
        for (int i = 0; i < 4; i++) {
            boolean on = openAlbum == null ? effTab() == i : tab == i, hov = in(mx, my, tabX[i], NAV_Y, tabW[i], NAV_H);
            int col = on ? cText : (hov ? cText : cMuted);
            int tx = tabX[i] + 5;
            if (retro) { if (on) Theme.bevel(g, tabX[i] + 1, NAV_Y, tabW[i] - 2, NAV_H, false, 0xFFC0C0C0); else if (hov) Theme.bevel(g, tabX[i] + 1, NAV_Y, tabW[i] - 2, NAV_H, true, 0xFFC0C0C0); }
            else if (on && !look.isEmpty()) rr(g, tabX[i] + 2, NAV_Y, tabW[i] - 4, NAV_H, 6, cCardH);
            if (tabIcons) {
                switch (i) { case 0 -> iconHome(g, tx, NAV_Y + 3, col); case 1 -> iconNote(g, tx, NAV_Y + 3, col); case 2 -> iconPeople(g, tx, NAV_Y + 3, col); default -> iconAlbum(g, tx, NAV_Y + 3, col); }
                tx += 9;
            }
            fitText(g, font(), t("cutemod.music.tab." + TAB_KEYS[i]), tx, NAV_Y + 3, tabW[i] - (tx - tabX[i]) - 4, col, false);
            if (on && look.isEmpty()) rr(g, tabX[i] + 5, NAV_Y + NAV_H, tabW[i] - 10, 2, 1, cSecond);
        }
        // search box
        if (retro) Theme.bevel(g, SEARCH_X, NAV_Y, SEARCH_W, NAV_H, false, 0xFFFFFFFF);
        else {
            rr(g, SEARCH_X, NAV_Y, SEARCH_W, NAV_H, 6, typing ? cCardH : cCard);
            if (typing) g.fill(SEARCH_X + 3, NAV_Y + NAV_H - 1, SEARCH_X + SEARCH_W - 3, NAV_Y + NAV_H, cSecond);
        }
        String shown = query.isEmpty() && !typing ? t("cutemod.player.search") : query;
        String cut = shown;
        while (cut.length() > 1 && tw(cut) > SEARCH_W - 22) cut = cut.substring(1);       // the end of the text stays visible
        str(g, cut, SEARCH_X + 5, NAV_Y + 3, query.isEmpty() ? cMuted : cText);
        if (typing && (ticks / 30) % 2 == 0) g.fill(SEARCH_X + 5 + tw(cut), NAV_Y + 3, SEARCH_X + 6 + tw(cut), NAV_Y + NAV_H - 3, cText);
        if (!query.isEmpty()) str(g, "x", SEARCH_X + SEARCH_W - 10, NAV_Y + 3, in(mx, my, SEARCH_X + SEARCH_W - 13, NAV_Y, 13, NAV_H) ? cText : cMuted);
        else iconSearch(g, SEARCH_X + SEARCH_W - 11, NAV_Y + 3, cMuted);
    }

    // ----- the toolbar: rescan, folder, shuffle all, sort, the letters -----
    private final List<Character> letters = new ArrayList<>();
    private int letterX0, letterStep;

    private void renderToolbar(GuiGraphics g) {
        letters.clear();
        if (openAlbum != null) {
            boolean hov = in(mx, my, 6, TB_Y, 40, TB_H);
            pill(g, 6, TB_Y, 40, TB_H, false, hov);
            tri(g, 11, TB_Y + 4, 6, -1, cText);
            str(g, t("cutemod.music.back"), 20, TB_Y + 3, cText);
            Albums.Album a = open();
            if (a != null) fitText(g, font(), a.title(), 52, TB_Y + 3, W - 60, cMuted, false);
            return;
        }
        int et = effTab();
        pill(g, 6, TB_Y, 14, TB_H, false, in(mx, my, 6, TB_Y, 14, TB_H));
        iconRefresh(g, 9, TB_Y + 4, cMuted);
        pill(g, 22, TB_Y, 14, TB_H, false, in(mx, my, 22, TB_Y, 14, TB_H));
        iconFolder(g, 24, TB_Y + 4, cMuted);
        int x = 40;
        if (artistFilter != null && et == 3) {                                   // the albums of one artist: a chip that clears it
            int w = Math.min(90, tw(artistFilter) + 20);
            pill(g, x, TB_Y, w, TB_H, true, in(mx, my, x, TB_Y, w, TB_H));
            fitText(g, font(), artistFilter, x + 5, TB_Y + 3, w - 16, 0xFFFFFFFF, false);
            str(g, "x", x + w - 9, TB_Y + 3, 0xFFFFFFFF);
            x += w + 4;
        } else {
            String label = t("cutemod.music.shuffleall", et == 1 ? songs().size() : allOwnedSongs().size());
            int w = Math.min(88, tw(label) + 22);
            boolean hov = in(mx, my, x, TB_Y, w, TB_H);
            pill(g, x, TB_Y, w, TB_H, false, hov);
            iconShuffle(g, x + 5, TB_Y + 4, cText);
            fitText(g, font(), label, x + 17, TB_Y + 3, w - 20, cText, false);
            x += w + 4;
        }
        if (et != 0) {
            String sl = t(sort == 0 ? "cutemod.music.sort.title" : "cutemod.music.sort.artist");
            int w = Math.max(40, Math.min(58, tw(sl) + 14));
            boolean hov = in(mx, my, x, TB_Y, w, TB_H);
            pill(g, x, TB_Y, w, TB_H, false, hov);
            fitText(g, font(), sl, x + 5, TB_Y + 3, w - 14, cText, false);
            tri(g, x + w - 9, TB_Y + 5, 4, 1, cMuted);
            x += w + 2;
            boolean ho = in(mx, my, x, TB_Y, 14, TB_H);
            pill(g, x, TB_Y, 14, TB_H, false, ho);
            if (desc) tri(g, x + 5, TB_Y + 4, 6, 1, cText); else tri(g, x + 4, TB_Y + 4, 6, -1, cText);
            x += 16;
        }
        // the index of letters
        if (et != 0) {
            if (et == 1) for (Song s : songs()) letters.add(letterOf(sort == 1 ? artistOf(s.album()) : s.track().title()));
            else for (Tile tl : tiles()) letters.add(letterOf(et == 2 || sort == 0 ? tl.title() : artistOf(tl.cover())));
            List<Character> uniq = new ArrayList<>();
            for (char c : letters) if (!uniq.contains(c)) uniq.add(c);
            uniq.sort(Character::compare);
            int avail = W - 6 - x - 2;
            letterStep = uniq.isEmpty() ? 6 : Math.max(4, Math.min(7, avail / uniq.size()));
            letterX0 = W - 6 - letterStep * uniq.size();
            if (letterX0 >= x + 2 && !uniq.isEmpty()) {
                rr(g, letterX0 - 3, TB_Y, letterStep * uniq.size() + 6, TB_H, 6, cCard);
                for (int i = 0; i < uniq.size(); i++) {
                    int lx = letterX0 + i * letterStep;
                    boolean hov = in(mx, my, lx, TB_Y, letterStep, TB_H);
                    smallText(g, font(), String.valueOf(uniq.get(i)), lx + letterStep / 2, TB_Y + 3, letterStep, hov ? cSecond : cText);
                }
            }
            letters.clear();
            letters.addAll(uniq);
            if (letterX0 < x + 2) letters.clear();
        }
    }

    // ----- Home: what plays now and the newest albums -----
    /** Where the "recently added" albums start on the home page (the text of the playing song lies to the left of it). */
    private static final int RECENT_X = 166;

    private void renderHome(GuiGraphics g) {
        scroll = 0;
        var cur = PlayerEngine.current();
        int cx = 8, cy = BODY_Y + 4;
        if (cur != null) {
            coverTile(g, cur.album(), cx, cy, 70);
            int tx = cx + 74, tr = RECENT_X - 4 - tx;   // tr = the room for the text (the newest albums start at RECENT_X)
            fitText(g, font(), t("cutemod.music.nowplaying").toUpperCase(Locale.ROOT), tx, cy + 2, tr, cSecond, false);
            mtext(g, cur.track().title(), tx, cy + 14, tr, cText, true);
            mtext(g, artistOf(cur.album()), tx, cy + 25, tr, cMuted, true);
            boolean hp = in(mx, my, tx, cy + 40, 30, 14);
            accentBtn(g, tx, cy + 40, 30, 14, hp);
            if (PlayerEngine.isPlaying()) { g.fill(tx + 11, cy + 44, tx + 13, cy + 50, 0xFFFFFFFF); g.fill(tx + 16, cy + 44, tx + 18, cy + 50, 0xFFFFFFFF); }
            else tri(g, tx + 12, cy + 43, 8, 1, 0xFFFFFFFF);
            boolean hs = in(mx, my, tx + 34, cy + 40, 24, 14);
            pill(g, tx + 34, cy + 40, 24, 14, PlayerEngine.shuffle(), hs);
            iconShuffle(g, tx + 40, cy + 44, PlayerEngine.shuffle() ? 0xFFFFFFFF : cText);
        } else {
            rr(g, cx, cy, 142, 70, 8, cCard);
            fitText(g, font(), t("cutemod.music.welcome"), cx + 71, cy + 14, 130, cText, true);
            fitText(g, font(), t("cutemod.music.welcome2"), cx + 71, cy + 26, 130, cMuted, true);
            boolean hs = in(mx, my, cx + 31, cy + 44, 80, 14);
            accentBtn(g, cx + 31, cy + 44, 80, 14, hs);
            String lb = t("cutemod.music.shuffleall", allOwnedSongs().size());
            fitText(g, font(), lb, cx + 71, cy + 47, 72, 0xFFFFFFFF, true);
        }
        // the newest albums (the last of the library)
        fitText(g, font(), t("cutemod.music.recent").toUpperCase(Locale.ROOT), RECENT_X, BODY_Y + 2, W - RECENT_X - 6, cMuted, false);
        List<Albums.Album> own = new ArrayList<>();
        for (Albums.Album a : Albums.all()) if (lib(a)) own.add(a);
        int n = Math.min(6, own.size());
        for (int i = 0; i < n; i++) {
            Albums.Album a = own.get(own.size() - 1 - i);
            int x = RECENT_X + (i % 3) * 40, y = BODY_Y + 14 + (i / 3) * 40;
            boolean hov = in(mx, my, x, y, 36, 36);
            coverTile(g, a, x, y, 36);
            if (hov) { veil(g, x, y, 36, 36, 0x66); }
            veil(g, x, y, 36, 11, 0xB0);
            mtext(g, a.title(), x + 2, y + 26, 32, 0xFFFFFFFF, hov);
        }
        if (n == 0) fitText(g, font(), t("cutemod.player.none"), RECENT_X + 58, BODY_Y + 40, 120, cMuted, true);
    }

    // ----- the grid of covers: Albums, Artists, Store -----
    private int rowsOf(int n) { return (n + COLS - 1) / COLS; }

    private void renderGrid(GuiGraphics g) {
        List<Tile> l = tiles();
        int et = effTab();
        int content = rowsOf(l.size()) * PITCH + 6;
        scroll = Math.max(0, Math.min(Math.max(0, content - BODY_H), scroll));
        if (l.isEmpty()) {
            String[] lines = t(searching() || artistFilter != null ? "cutemod.player.none" : emptyKey()).split("\\|");
            for (int i = 0; i < lines.length; i++) fitText(g, font(), lines[i], W / 2, BODY_Y + 24 + i * 11, 240, cMuted, true);
            return;
        }
        var cur = PlayerEngine.current();
        for (int i = 0; i < l.size(); i++) {
            int x = GX + (i % COLS) * PITCH, y = BODY_Y + 3 + (i / COLS) * PITCH - scroll;
            if (y + TILE < BODY_Y || y > BODY_END) continue;
            Tile tl = l.get(i);
            boolean hov = in(mx, my, x, y, TILE, TILE) && my >= BODY_Y && my < BODY_END;
            coverTile(g, tl.cover(), x, y, TILE);
            if (hov) veil(g, x, y, TILE, TILE, 0x55);
            veil(g, x, y, TILE, 22, 0xD0);
            mtext(g, tl.title(), x + 3, y + TILE - 19, TILE - 6, 0xFFFFFFFF, hov);
            mtext(g, tl.sub(), x + 3, y + TILE - 10, TILE - 6, 0xFFD8D0E8, hov);
            if (cur != null && tl.album() != null && cur.album().id().equals(tl.album().id())) {
                rr(g, x + TILE - 15, y + 3, 12, 10, 4, 0xCC000000);
                for (int b = 0; b < 3; b++) {
                    int bh = PlayerEngine.isPlaying() ? 2 + (int) (Math.abs(Math.sin((ticks + b * 9) * 0.1)) * 4) : 3;
                    g.fill(x + TILE - 13 + b * 3, y + 11 - bh, x + TILE - 11 + b * 3, y + 11, retro ? 0xFFFFFFFF : aHot);
                }
            }
            if (hov) {                                                // the play button of a tile
                boolean hp = Math.hypot(mx - (x + TILE / 2), my - (y + 14)) <= 8;
                orb(g, x + TILE / 2, y + 14, 8, hp ? aHot : 0xDDFFFFFF);
                tri(g, x + TILE / 2 - 2, y + 10, 8, 1, hp ? 0xFFFFFFFF : aMain);
            }
        }
        scrollBar(g, content, BODY_H, BODY_Y, BODY_H);
    }

    // ----- Songs: one long list -----
    private void renderSongs(GuiGraphics g) {
        List<Song> l = songs();
        int content = l.size() * ROW_H + 4;
        scroll = Math.max(0, Math.min(Math.max(0, content - BODY_H), scroll));
        if (l.isEmpty()) {
            String[] lines = t(searching() ? "cutemod.player.none" : emptyKey()).split("\\|");
            for (int i = 0; i < lines.length; i++) fitText(g, font(), lines[i], W / 2, BODY_Y + 24 + i * 11, 240, cMuted, true);
            return;
        }
        var cur = PlayerEngine.current();
        for (int i = 0; i < l.size(); i++) {
            int y = BODY_Y + 2 + i * ROW_H - scroll;
            if (y + ROW_H < BODY_Y || y > BODY_END) continue;
            Song s = l.get(i);
            boolean now = cur != null && cur.album().id().equals(s.album().id()) && cur.track().id().equals(s.track().id());
            boolean hov = in(mx, my, 6, y, W - 14, ROW_H) && my >= BODY_Y && my < BODY_END;
            rr(g, 6, y, W - 14, ROW_H - 1, 4, now ? cNowBg : hov ? cCardH : ((i & 1) == 0 ? cRow : 0));
            coverTile(g, s.album(), 9, y + 1, 9);
            if (now && PlayerEngine.isPlaying()) {
                for (int b = 0; b < 3; b++) {
                    int bh = 2 + (int) (Math.abs(Math.sin((ticks + b * 9) * 0.1)) * 5);
                    g.fill(252 + b * 3, y + 9 - bh, 254 + b * 3, y + 9, cNowBar);
                }
            }
            String right = time(s.track().seconds() * 1000L);
            int mu = now ? cNowMu : cMuted;
            mtext(g, shortTitle(s.album(), s.track().title()), 22, y + 1, 106, now ? cNow : cText, hov);
            mtext(g, artistOf(s.album()), 132, y + 1, 60, mu, hov);
            mtext(g, s.album().title(), 196, y + 1, 50, mu, hov);
            str(g, right, W - 12 - tw(right), y + 1, mu);
        }
        scrollBar(g, content, BODY_H, BODY_Y, BODY_H);
    }

    // ----- an open album: the picture, the buttons and the songs -----
    private void renderDetail(GuiGraphics g) {
        Albums.Album a = open();
        coverTile(g, a, 8, BODY_Y + 2, 54);
        boolean hc = in(mx, my, 8, BODY_Y + 58, 96, 32);
        mtext(g, a.title(), 8, BODY_Y + 60, 92, cText, hc);
        mtext(g, artistOf(a), 8, BODY_Y + 70, 92, cMuted, hc);
        mtext(g, t("cutemod.player.count", a.tracks().size()) + " - " + t("cutemod.player.min", totalMinutes(a)), 8, BODY_Y + 80, 92, cMuted, hc);
        int bx = 106;
        if (lib(a)) {
            boolean hp = in(mx, my, bx, BODY_Y + 2, 54, 14);
            accentBtn(g, bx, BODY_Y + 2, 54, 14, hp);
            tri(g, bx + 8, BODY_Y + 5, 7, 1, 0xFFFFFFFF);
            fitText(g, font(), t("cutemod.player.play"), bx + 14 + 20, BODY_Y + 5, 36, 0xFFFFFFFF, true);
            if (!portable) {                                                    // "put on the portable player" (not in the portable player itself)
                boolean hm = in(mx, my, bx + 58, BODY_Y + 2, 54, 14);
                pill(g, bx + 58, BODY_Y + 2, 54, 14, a.onPlayer(), hm);
                fitText(g, font(), t("cutemod.music.toplayer"), bx + 58 + 27, BODY_Y + 5, 50, a.onPlayer() ? 0xFFFFFFFF : cText, true);
            }
        } else {
            rr(g, bx, BODY_Y + 2, 120, 14, 7, 0xFF8A7AAA);
            fitText(g, font(), t("cutemod.music.instore"), bx + 60, BODY_Y + 5, 114, 0xFFFFFFFF, true);
        }
        List<Albums.Track> tracks = a.tracks();
        int top = BODY_Y + 21, visPx = BODY_END - top, content = tracks.size() * ROW_H + 2;
        scroll = Math.max(0, Math.min(Math.max(0, content - visPx), scroll));
        var cur = PlayerEngine.current();
        g.enableScissor(shell.absX(), shell.absY() + top, shell.absX() + W, shell.absY() + BODY_END);
        for (int i = 0; i < tracks.size(); i++) {
            int y = top + i * ROW_H - scroll;
            if (y + ROW_H < top || y > BODY_END) continue;
            Albums.Track tk = tracks.get(i);
            boolean now = lib(a) && cur != null && cur.album().id().equals(a.id()) && cur.track().id().equals(tk.id());
            boolean hov = lib(a) && in(mx, my, bx - 4, y, W - bx - 4, ROW_H) && my >= top && my < BODY_END;
            rr(g, bx - 4, y, W - bx - 4, ROW_H - 1, 4, now ? cNowBg : hov ? cCardH : ((i & 1) == 0 ? cRow : 0));
            if (now && PlayerEngine.isPlaying()) {
                for (int b = 0; b < 3; b++) {
                    int bh = 2 + (int) (Math.abs(Math.sin((ticks + b * 9) * 0.1)) * 5);
                    g.fill(bx + b * 3, y + 9 - bh, bx + 2 + b * 3, y + 9, cNowBar);
                }
            } else if (now) tri(g, bx, y + 2, 6, 1, cNow);
            else str(g, String.valueOf(i + 1), bx, y + 1, cMuted);
            String right = time(tk.seconds() * 1000L);
            boolean rh = in(mx, my, bx - 4, y, W - bx - 4, ROW_H) && my >= top && my < BODY_END;
            mtext(g, shortTitle(a, tk.title()), bx + 14, y + 1, W - bx - 14 - tw(right) - 16, lib(a) ? (now ? cNow : cText) : cMuted, rh);
            str(g, right, W - 12 - tw(right), y + 1, now ? cNowMu : cMuted);
        }
        g.disableScissor();
        scrollBar(g, content, visPx, top, visPx);
    }

    // ----- the player bar -----
    private void renderFooter(GuiGraphics g) {
        footerBack(g);
        var cur = PlayerEngine.current();
        long len = PlayerEngine.length();
        long pos = drag == 1 ? dragMs : PlayerEngine.position();
        float frac = len > 0 ? Math.max(0F, Math.min(1F, pos / (float) len)) : 0F;
        String tl = cur == null ? "0:00" : time(pos), trr = cur == null || len <= 0 ? "-:--" : time(len);
        str(g, tl, SEEK_X0 - 4 - tw(tl), SEEK_Y - 3, fMuted);
        str(g, trr, SEEK_X1 + 4, SEEK_Y - 3, fMuted);
        int fill = (int) ((SEEK_X1 - SEEK_X0) * frac);
        track(g, SEEK_X0, SEEK_Y, SEEK_X1 - SEEK_X0, fill, fFill);
        if (cur != null && (drag == 1 || in(mx, my, SEEK_X0 - 3, SEEK_Y - 5, SEEK_X1 - SEEK_X0 + 6, 12))) knob(g, SEEK_X0 + fill, SEEK_Y + 1);

        // the song
        if (cur != null) {
            coverTile(g, cur.album(), 8, 142, 22);
            mtext(g, shortTitle(cur.album(), cur.track().title()), 34, 144, 66, fText, true);
            mtext(g, artistOf(cur.album()), 34, 154, 66, fMuted, true);
        } else {
            rr(g, 8, 142, 22, 22, 6, retro ? 0xFFFFFFFF : cCard);
            fitText(g, font(), t("cutemod.player.nothing"), 34, 150, 66, fMuted, false);
        }
        // the controls
        boolean sh = PlayerEngine.shuffle(), rp = PlayerEngine.repeat() != PlayerEngine.Repeat.OFF;
        boolean hs = in(mx, my, SH_X, CTRL_Y - 8, 16, 16), hr = in(mx, my, REP_X, CTRL_Y - 8, 16, 16);
        if (sh) toggleBox(g, SH_X - 1, CTRL_Y - 8, 16, 16);
        iconShuffle(g, SH_X + 3, CTRL_Y - 3, sh ? 0xFFFFFFFF : (hs ? fText : fMuted));
        if (rp) toggleBox(g, REP_X - 1, CTRL_Y - 8, 16, 16);
        iconRepeat(g, REP_X + 2, CTRL_Y - 3, rp ? 0xFFFFFFFF : (hr ? fText : fMuted), PlayerEngine.repeat() == PlayerEngine.Repeat.ONE);
        boolean hp = in(mx, my, PREV_X, CTRL_Y - 8, 16, 16), hn = in(mx, my, NEXT_X, CTRL_Y - 8, 16, 16);
        g.fill(PREV_X + 4, CTRL_Y - 4, PREV_X + 5, CTRL_Y + 4, hp ? fHot : fInk); tri(g, PREV_X + 6, CTRL_Y - 4, 8, -1, hp ? fHot : fInk);
        g.fill(NEXT_X + 11, CTRL_Y - 4, NEXT_X + 12, CTRL_Y + 4, hn ? fHot : fInk); tri(g, NEXT_X + 3, CTRL_Y - 4, 8, 1, hn ? fHot : fInk);
        playButton(g, Math.hypot(mx - PLAY_X, my - CTRL_Y) <= 10, PlayerEngine.isPlaying());
        // the volume
        boolean muted = PlayerEngine.volume() <= 0.01F;
        iconSpeaker(g, SPK_X, CTRL_Y - 4, in(mx, my, SPK_X - 2, CTRL_Y - 8, 14, 16) ? fText : fMuted, muted);
        int vf = (int) (VOL_W * PlayerEngine.volume());
        track(g, VOL_X, CTRL_Y - 1, VOL_W, vf, fFill2);
        if (drag == 2 || in(mx, my, VOL_X - 3, CTRL_Y - 7, VOL_W + 6, 14)) knob(g, VOL_X + vf, CTRL_Y);
    }

    // ---------- input ----------
    private void setTab(int t) { tab = t; openAlbum = null; artistFilter = null; scroll = 0; }

    @Override
    public boolean click(int x, int y, int button) {
        if (button != 0) return false;
        // the search box
        if (in(x, y, SEARCH_X, NAV_Y, SEARCH_W, NAV_H)) {
            if (!query.isEmpty() && in(x, y, SEARCH_X + SEARCH_W - 13, NAV_Y, 13, NAV_H)) { query = ""; scroll = 0; }
            typing = true;
            return true;
        }
        typing = false;
        if (y >= NAV_Y && y < NAV_Y + NAV_H) {
            for (int i = 0; i < 4; i++) if (in(x, y, tabX[i], NAV_Y, tabW[i], NAV_H)) { setTab(i); return true; }
        }
        if (y >= TB_Y && y < TB_Y + TB_H && clickToolbar(x, y)) return true;
        if (clickFooter(x, y)) return true;
        if (sbTotal > 0 && x >= W - 9 && y >= sbTop && y < sbTop + sbH) { drag = 3; dragTo(x, y); return true; }
        if (y >= BODY_Y && y < BODY_END) {
            if (openAlbum != null && open() != null) return clickDetail(x, y);
            return switch (effTab()) { case 0 -> clickHome(x, y); case 1 -> clickSongs(x, y); default -> clickGrid(x, y); };
        }
        return false;
    }

    private boolean clickToolbar(int x, int y) {
        if (openAlbum != null) {
            if (in(x, y, 6, TB_Y, 40, TB_H)) { openAlbum = null; scroll = 0; return true; }
            return false;
        }
        if (in(x, y, 6, TB_Y, 14, TB_H)) { say(t("cutemod.music.rescanning")); Minecraft.getInstance().reloadResourcePacks(); return true; }
        if (in(x, y, 22, TB_Y, 14, TB_H)) {
            try {
                java.nio.file.Files.createDirectories(dev.cutemod.client.player.UserMusic.dir());
                net.minecraft.Util.getPlatform().openFile(dev.cutemod.client.player.UserMusic.dir().toFile());
            } catch (Exception ex) { say(t("cutemod.music.nofolder")); }
            return true;
        }
        int et = effTab(), px = 40;
        if (artistFilter != null && et == 3) {
            int w = Math.min(90, tw(artistFilter) + 20);
            if (in(x, y, px, TB_Y, w, TB_H)) { artistFilter = null; scroll = 0; return true; }
            px += w + 4;
        } else {
            String label = t("cutemod.music.shuffleall", et == 1 ? songs().size() : allOwnedSongs().size());
            int w = Math.min(88, tw(label) + 22);
            if (in(x, y, px, TB_Y, w, TB_H)) { shuffleAll(); return true; }
            px += w + 4;
        }
        if (et != 0) {
            String sl = t(sort == 0 ? "cutemod.music.sort.title" : "cutemod.music.sort.artist");
            int w = Math.max(40, Math.min(58, tw(sl) + 14));
            if (in(x, y, px, TB_Y, w, TB_H)) { sort = 1 - sort; scroll = 0; return true; }
            px += w + 2;
            if (in(x, y, px, TB_Y, 14, TB_H)) { desc = !desc; scroll = 0; return true; }
            for (int i = 0; i < letters.size(); i++) {
                if (in(x, y, letterX0 + i * letterStep, TB_Y, letterStep, TB_H)) { jumpToLetter(letters.get(i)); return true; }
            }
        }
        return false;
    }

    private void jumpToLetter(char c) {
        int et = effTab();
        if (et == 1) {
            List<Song> l = songs();
            for (int i = 0; i < l.size(); i++) {
                Song s = l.get(i);
                if (letterOf(sort == 1 ? artistOf(s.album()) : s.track().title()) == c) { scroll = i * ROW_H; return; }
            }
        } else {
            List<Tile> l = tiles();
            for (int i = 0; i < l.size(); i++) {
                Tile tl = l.get(i);
                if (letterOf(et == 2 || sort == 0 ? tl.title() : artistOf(tl.cover())) == c) { scroll = (i / COLS) * PITCH; return; }
            }
        }
    }

    private boolean clickFooter(int x, int y) {
        if (y < FOOT_Y) return false;
        if (Math.hypot(x - PLAY_X, y - CTRL_Y) <= 10) { toggle(); return true; }
        if (in(x, y, PREV_X, CTRL_Y - 8, 16, 16)) { PlayerEngine.prev(); return true; }
        if (in(x, y, NEXT_X, CTRL_Y - 8, 16, 16)) { PlayerEngine.next(); return true; }
        if (in(x, y, SH_X, CTRL_Y - 8, 16, 16)) { PlayerEngine.toggleShuffle(); return true; }
        if (in(x, y, REP_X, CTRL_Y - 8, 16, 16)) { PlayerEngine.cycleRepeat(); return true; }
        if (in(x, y, SPK_X - 2, CTRL_Y - 8, 14, 16)) {
            if (PlayerEngine.volume() > 0.01F) { lastVol = PlayerEngine.volume(); PlayerEngine.setVolume(0F); }
            else PlayerEngine.setVolume(lastVol > 0.01F ? lastVol : 0.6F);
            return true;
        }
        if (PlayerEngine.current() != null && in(x, y, SEEK_X0 - 3, SEEK_Y - 5, SEEK_X1 - SEEK_X0 + 6, 12)) { drag = 1; dragTo(x, y); return true; }
        if (in(x, y, VOL_X - 3, CTRL_Y - 7, VOL_W + 6, 14)) { drag = 2; dragTo(x, y); return true; }
        return false;
    }

    private void dragTo(int x, int y) {
        if (drag == 3) {                                                       // the scroll bar
            if (sbTotal <= 0) return;
            int bh = Math.max(10, sbH * sbVis / sbTotal);
            float fr = (y - sbTop - bh / 2F) / Math.max(1, sbH - bh);
            scroll = Math.round(Math.max(0F, Math.min(1F, fr)) * (sbTotal - sbVis));
        } else if (drag == 1) {
            float fr = (x - SEEK_X0) / (float) (SEEK_X1 - SEEK_X0);
            dragMs = (long) (Math.max(0F, Math.min(1F, fr)) * PlayerEngine.length());
        } else if (drag == 2) {
            PlayerEngine.setVolume((x - VOL_X) / (float) VOL_W);
        }
    }

    private boolean clickHome(int x, int y) {
        int cx = 8, cy = BODY_Y + 4;
        if (PlayerEngine.current() != null) {
            int tx = cx + 74;
            if (in(x, y, tx, cy + 40, 30, 14)) { PlayerEngine.toggle(); return true; }
            if (in(x, y, tx + 34, cy + 40, 24, 14)) { PlayerEngine.toggleShuffle(); return true; }
        } else if (in(x, y, cx + 31, cy + 44, 80, 14)) { shuffleAll(); return true; }
        List<Albums.Album> own = new ArrayList<>();
        for (Albums.Album a : Albums.all()) if (lib(a)) own.add(a);
        for (int i = 0; i < Math.min(6, own.size()); i++) {
            int ax = RECENT_X + (i % 3) * 40, ay = BODY_Y + 14 + (i / 3) * 40;
            if (in(x, y, ax, ay, 36, 36)) { openAlbum = own.get(own.size() - 1 - i).id(); scroll = 0; return true; }
        }
        return false;
    }

    private boolean clickSongs(int x, int y) {
        List<Song> l = songs();
        int i = (y - BODY_Y - 2 + scroll) / ROW_H;
        if (y - BODY_Y - 2 + scroll >= 0 && i >= 0 && i < l.size()) { playQueue(entriesOf(l), i); return true; }
        return false;
    }

    private boolean clickGrid(int x, int y) {
        List<Tile> l = tiles();
        int et = effTab();
        int col = (x - GX) / PITCH, row = (y - BODY_Y - 3 + scroll) / PITCH;
        if (x < GX || y - BODY_Y - 3 + scroll < 0 || col >= COLS) return false;
        int tx = GX + col * PITCH, ty = BODY_Y + 3 + row * PITCH - scroll;
        if (!in(x, y, tx, ty, TILE, TILE)) return false;
        int i = row * COLS + col;
        if (i < 0 || i >= l.size()) return false;
        Tile tl = l.get(i);
        if (Math.hypot(x - (tx + TILE / 2), y - (ty + 14)) <= 8) {       // the play button of the tile
            if (tl.album() != null) playAlbum(tl.album(), 0); else playArtist(tl.artist());
            return true;
        }
        if (et == 2) { setTab(3); artistFilter = tl.artist(); return true; }         // an artist: his albums
        openAlbum = tl.album().id();
        scroll = 0;
        return true;
    }

    private boolean clickDetail(int x, int y) {
        Albums.Album a = open();
        int bx = 106;
        if (lib(a)) {
            if (in(x, y, bx, BODY_Y + 2, 54, 14)) { playAlbum(a, 0); return true; }
            if (!portable && in(x, y, bx + 58, BODY_Y + 2, 54, 14)) { a.setOnPlayer(!a.onPlayer()); return true; }
            int top = BODY_Y + 21;
            int i = (y - top + scroll) / ROW_H;
            if (y >= top && x >= bx - 4 && i >= 0 && i < a.tracks().size()) { playAlbum(a, i); return true; }
        }
        return false;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (drag == 0) return false;
        dragTo(x, y);
        return true;
    }

    @Override
    public boolean release(int x, int y, int button) {
        if (drag == 1) PlayerEngine.seek(dragMs);
        boolean was = drag != 0;
        drag = 0;
        return was;
    }

    @Override
    public boolean scroll(double amount) {
        if (in(mx, my, SPK_X - 2, FOOT_Y, W - SPK_X + 2, H - FOOT_Y)) {        // the wheel over the volume changes the volume
            PlayerEngine.setVolume(PlayerEngine.volume() + (amount > 0 ? 0.05F : -0.05F));
            return true;
        }
        if (my < NAV_Y + NAV_H || my >= FOOT_Y) return false;                  // anywhere between the pages and the player bar
        scroll = Math.max(0, Math.min(vMax, scroll - (int) Math.round(amount * 22)));
        return true;
    }

    @Override
    public boolean charTyped(char c) {
        if (!typing) return false;
        if (c >= 32 && c != 127 && query.length() < 40) { query += c; scroll = 0; openAlbum = null; }
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (typing) {
            if (keyCode == 259) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); scroll = 0; return true; }   // backspace
            if (keyCode == 257 || keyCode == 335) { typing = false; return true; }                                                  // enter
            if (keyCode == 256) { if (!query.isEmpty()) query = ""; else typing = false; return true; }                              // escape
            if (keyCode == 86 && (modifiers & 2) != 0) {                                                                             // ctrl+V
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) { String all = query + clip.replaceAll("[\\r\\n]", " "); query = all.substring(0, Math.min(40, all.length())); scroll = 0; }
                return true;
            }
            return true;
        }
        switch (keyCode) {
            case 32 -> toggle();                                                       // space
            case 262 -> PlayerEngine.seek(PlayerEngine.position() + 5000);             // right: +5 s
            case 263 -> PlayerEngine.seek(PlayerEngine.position() - 5000);             // left: -5 s
            case 264 -> scroll = Math.max(0, Math.min(vMax, scroll + 22));                                 // down
            case 265 -> scroll = Math.max(0, Math.min(vMax, scroll - 22));                                 // up
            case 267 -> scroll = Math.max(0, Math.min(vMax, scroll + BODY_H - 12));                        // page down
            case 266 -> scroll = Math.max(0, Math.min(vMax, scroll - (BODY_H - 12)));                     // page up
            case 268 -> scroll = 0;                                                                        // home
            case 269 -> scroll = vMax;                                                                     // end
            case 78 -> PlayerEngine.next();                                            // N
            case 80 -> PlayerEngine.prev();                                            // P
            case 47 -> typing = true;                                                  // /
            case 256 -> { if (openAlbum != null) { openAlbum = null; scroll = 0; } else if (artistFilter != null) { artistFilter = null; scroll = 0; } else return false; }   // escape: back
            default -> { return false; }
        }
        return true;
    }
}
