package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * First-person horror in an open, foggy night forest (a raycaster, but there is no maze: the trees are billboards
 * and the fog is the main thing in the game). Light 5 fires, then reach the road.
 * <ul>
 *   <li>You only see a few steps. The fog gets thicker in waves, and a fire you light pushes it back for a while.
 *       Fires are yellow and far away they are only a warm glow; blue lights lie (they wake the monster).</li>
 *   <li>The monster hunts by <b>sound</b>: standing still is almost silent, walking is quiet, running (SHIFT) is loud
 *       and tires you. Close to you it also sees you. Far away you only see its two red eyes.</li>
 *   <li><b>E</b>: throw a stone ahead of you. The monster goes to see what made the noise.</li>
 *   <li>It cannot come close to a lit fire (about 3 steps), so a fire is a safe place. But when the last fire is lit
 *       the whole forest wakes up: the monster is faster and always knows roughly where you are.</li>
 * </ul>
 */
public class FoggyForest extends MiniGame {
    private static final int S = 34;                       // the forest is S x S tiles, the outer ring is a wall of trees
    private static final int FIRES = 5, WISPS = 3, TREES = 170, PEBBLES = 4, DECO = 150, SIL = 70;
    private static final int COLS = 110, CW = W / COLS;    // one ray per 2 px
    private static final double PLANE = 0.75;              // field of view (bigger = wider)
    private static final int FOG = 0x2A3436;               // the colour everything fades into
    private static final double TREE_R = 0.3;              // trunk radius for collisions
    private static final double SAFE_R = 3.0;              // the monster does not come this close to a lit fire
    private static final double MOON = -0.9;               // the world direction of the moon

    // the monster: 12 x 24 pixels, one char = one pixel ('r' = the eyes: they glow through the fog)
    private static final String[] MONSTER = {
            "k..k.kk.k..k", ".k.k.kk.k.k.", ".kkkkkkkkkk.", "..kkkkkkkk..", "..kwwwwwwk..", "..kwrwwrwk..",
            "..kwwwwwwk..", "...kwkkwk...", "....kkkk....", "....kkkk....", "..kkkkkkkk..", ".kkkkkkkkkk.",
            "kk.kkkkkk.kk", "k..kkkkkk..k", "k..kkkkkk..k", "k..kkkkkk..k", "...kkkkkk...", "...kkkkkk...",
            "...kk..kk...", "...kk..kk...", "...kk..kk...", "..kkk..kkk..", "..kk....kk..", "..kk....kk.."};

    private final double[] zbuf = new double[COLS];        // wall distance per column (hides things behind the tree wall)
    private final double[] fx = new double[FIRES], fy = new double[FIRES];
    private final boolean[] lit = new boolean[FIRES];
    private final double[] wx = new double[WISPS], wy = new double[WISPS];
    private final boolean[] wgone = new boolean[WISPS];
    private final double[] trX = new double[TREES], trY = new double[TREES];
    private final int[] trK = new int[TREES];              // 0 pine, 1 dead tree, 2 fat tree
    private int nTrees;
    private final double[] dX = new double[DECO], dY = new double[DECO];   // bushes and stumps: only for looks, you walk through them
    private final int[] dK = new int[DECO];                                 // 3 bush, 4 stump
    private int nDeco;
    private final double[] silA = new double[SIL];                          // the far tree line: only seen in thin fog
    private final int[] silW = new int[SIL], silH = new int[SIL];

    private double px, py, ang, ex, ey, exitX, exitY, ox, oy, gx, gy, stamina = 1, wave, noise;
    private double cA, sA;                                 // cos and sin of the view angle (per frame)
    private int fires, ticks, pebbles, msgT, alert, thickT, nextThick, stepT, whisperT, mstepT, wanderCd, fogBoost, pebbleCd;
    private boolean awake, won, enraged, tired;
    private String msg = "";

    @Override
    public void reset() {
        score = 0; over = false; won = false; awake = false; enraged = false; tired = false;
        fires = 0; ticks = 0; pebbles = PEBBLES; stamina = 1; wave = 0; thickT = 0; fogBoost = 0; pebbleCd = 0;
        nextThick = 1500 + rnd.nextInt(900);
        whisperT = 900 + rnd.nextInt(900);
        alert = 0; msgT = 0; stepT = 0; mstepT = 0; wanderCd = 0; noise = 0;
        ex = ey = -100;
        java.util.Arrays.fill(lit, false);
        java.util.Arrays.fill(wgone, false);
        build();
        say("cutemod.forest.start");
    }

    // ---------- the forest ----------
    /** A random free spot at least minD from everything in taken (the spacing relaxes slowly if there is no room). */
    private double[] spot(List<double[]> taken, double minD) {
        for (int t = 0; t < 600; t++) {
            double x = 3 + rnd.nextDouble() * (S - 6), y = 3 + rnd.nextDouble() * (S - 6);
            double md = minD * (1 - t / 900.0);
            boolean ok = true;
            for (double[] p : taken) if (Math.hypot(p[0] - x, p[1] - y) < md) { ok = false; break; }
            if (ok) { double[] r = {x, y}; taken.add(r); return r; }
        }
        double[] r = {S / 2.0, S / 2.0};
        taken.add(r);
        return r;
    }

    private void build() {
        double sx = rnd.nextBoolean() ? 4.5 : S - 4.5, sy = rnd.nextBoolean() ? 4.5 : S - 4.5;   // you start in a corner, the road is in the opposite one
        px = sx; py = sy;
        exitX = S - sx; exitY = S - sy;
        ang = Math.atan2(S / 2.0 - py, S / 2.0 - px) + (rnd.nextDouble() - 0.5) * 0.6;
        List<double[]> taken = new ArrayList<>();
        taken.add(new double[]{px, py});
        taken.add(new double[]{exitX, exitY});
        for (int i = 0; i < FIRES; i++) { double[] p = spot(taken, 8); fx[i] = p[0]; fy[i] = p[1]; }
        for (int i = 0; i < WISPS; i++) { double[] p = spot(taken, 6); wx[i] = p[0]; wy[i] = p[1]; }
        nTrees = 0;
        for (int i = 0; i < TREES; i++) {
            for (int t = 0; t < 40; t++) {
                double x = 1.8 + rnd.nextDouble() * (S - 3.6), y = 1.8 + rnd.nextDouble() * (S - 3.6);
                if (Math.hypot(x - px, y - py) < 3.5) continue;
                boolean ok = true;
                for (double[] p : taken) if (Math.hypot(p[0] - x, p[1] - y) < 2.0) { ok = false; break; }
                for (int j = 0; ok && j < nTrees; j++) if (Math.hypot(trX[j] - x, trY[j] - y) < 1.5) ok = false;
                if (!ok) continue;
                trX[nTrees] = x;
                trY[nTrees] = y;
                int r = rnd.nextInt(100);
                trK[nTrees] = r < 60 ? 0 : r < 85 ? 1 : 2;
                nTrees++;
                break;
            }
        }
        nDeco = 0;                                                  // bushes and stumps, half of them in a clump round a tree
        for (int i = 0; i < DECO; i++) {
            double x, y;
            if (nTrees > 0 && rnd.nextBoolean()) {
                int t = rnd.nextInt(nTrees);
                double a = rnd.nextDouble() * Math.PI * 2, r = 0.55 + rnd.nextDouble() * 0.7;
                x = trX[t] + Math.cos(a) * r; y = trY[t] + Math.sin(a) * r;
            } else { x = 1.8 + rnd.nextDouble() * (S - 3.6); y = 1.8 + rnd.nextDouble() * (S - 3.6); }
            if (x < 1.5 || y < 1.5 || x > S - 1.5 || y > S - 1.5 || Math.hypot(x - px, y - py) < 2.0) continue;
            boolean ok = true;
            for (double[] p : taken) if (Math.hypot(p[0] - x, p[1] - y) < 1.3) { ok = false; break; }
            if (!ok) continue;
            dX[nDeco] = x; dY[nDeco] = y; dK[nDeco] = rnd.nextInt(100) < 75 ? 3 : 4;
            nDeco++;
        }
        for (int i = 0; i < SIL; i++) {
            silA[i] = (rnd.nextDouble() * 2 - 1) * Math.PI;
            silW[i] = 7 + rnd.nextInt(8);
            silH[i] = 26 + rnd.nextInt(28);
        }
    }

    private void say(String key) { msg = key; msgT = 160; }

    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private static double angDiff(double a, double b) {
        double d = a - b;
        return Math.atan2(Math.sin(d), Math.cos(d));
    }

    /** How far you can see right now: the fog comes in waves, a new fire pushes it back. */
    private double fogRange() {
        return Math.max(2.5, 6.2 - 3.0 * wave + 3.0 * (fogBoost / 900.0) - (enraged ? 0.8 : 0));
    }

    private boolean free(double x, double y) {
        if (x < 1.25 || y < 1.25 || x > S - 1.25 || y > S - 1.25) return false;
        double rr = (TREE_R + 0.18) * (TREE_R + 0.18);
        for (int i = 0; i < nTrees; i++) {
            double dx = trX[i] - x, dy = trY[i] - y;
            if (dx * dx + dy * dy < rr) return false;
        }
        return true;
    }

    private void move(double dx, double dy) {
        if (free(px + dx, py)) px += dx;
        if (free(px, py + dy)) py += dy;
    }

    /** The monster walks through the forest: round the trees and never closer to a lit fire than SAFE_R. */
    private boolean monsterFree(double x, double y) {
        if (x < 1.3 || y < 1.3 || x > S - 1.3 || y > S - 1.3) return false;
        double rr = (TREE_R + 0.15) * (TREE_R + 0.15);
        for (int i = 0; i < nTrees; i++) {
            double dx = trX[i] - x, dy = trY[i] - y;
            if (dx * dx + dy * dy < rr) return false;
        }
        for (int i = 0; i < FIRES; i++) {
            if (!lit[i]) continue;
            double dn = Math.hypot(fx[i] - x, fy[i] - y), dc = Math.hypot(fx[i] - ex, fy[i] - ey);
            if (dn < SAFE_R && dn < dc) return false;      // (a fire lit right on top of it lets it walk out)
        }
        return true;
    }

    private void stepMonster(double tx, double ty, double sp) {
        if (Math.hypot(tx - ex, ty - ey) < 0.05) return;
        double want = Math.atan2(ty - ey, tx - ex);
        double[] offs = {0, 0.6, -0.6, 1.2, -1.2};
        for (double o : offs) {
            double a = want + o, nx = ex + Math.cos(a) * sp, ny = ey + Math.sin(a) * sp;
            if (monsterFree(nx, ny)) { ex = nx; ey = ny; return; }
        }
    }

    /** Something wakes up, far away from you. */
    private void spawn() {
        for (int t = 0; t < 100; t++) {
            double x = 3 + rnd.nextDouble() * (S - 6), y = 3 + rnd.nextDouble() * (S - 6);
            if (Math.hypot(x - px, y - py) >= 16 && monsterFree(x, y)) { ex = x; ey = y; break; }
        }
        if (ex < 0) { ex = S - px; ey = S - py; }
        gx = ex; gy = ey;
        wanderCd = 0;
        awake = true;
        say("cutemod.forest.wake");
        pling(0.5F);
        growl(G_DEEP);
    }

    private boolean nearLitFire(double x, double y) {
        for (int i = 0; i < FIRES; i++) if (lit[i] && Math.hypot(fx[i] - x, fy[i] - y) < SAFE_R) return true;
        return false;
    }

    private void throwStone() {
        if (pebbleCd > 0) return;
        if (pebbles <= 0) { say("cutemod.forest.nopebble"); beep(); return; }
        pebbles--;
        pebbleCd = 40;
        double tx = Math.max(2, Math.min(S - 2, px + Math.cos(ang) * 7)), ty = Math.max(2, Math.min(S - 2, py + Math.sin(ang) * 7));
        sound(SoundEvents.STONE_HIT, 0.8F, 0.7F);
        say("cutemod.forest.pebble");
        if (awake && Math.hypot(ex - tx, ey - ty) < 20) { ox = tx; oy = ty; alert = 420; }     // it goes to see what made the noise
    }

    // ---------- the game ----------
    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        if (alert > 0) alert--;
        if (pebbleCd > 0) pebbleCd--;
        if (fogBoost > 0) fogBoost--;
        if (thickT > 0) { thickT--; wave = Math.min(1, wave + 0.012); }
        else {
            wave = Math.max(0, wave - 0.008);
            if (--nextThick <= 0) { thickT = 600; nextThick = 1800 + rnd.nextInt(1200); say("cutemod.forest.thick"); }
        }

        // walk: W/S or up/down, turn: A/D or left/right, SHIFT: run (loud, and it tires you)
        double turn = (down(68) || down(KEY_RIGHT) ? 1 : 0) - (down(65) || down(KEY_LEFT) ? 1 : 0);
        double walk = (down(87) || down(KEY_UP) ? 1 : 0) - (down(83) || down(KEY_DOWN) ? 1 : 0);
        boolean running = (down(340) || down(344)) && walk > 0 && !tired && stamina > 0;
        if (running) { stamina -= 1 / 260.0; if (stamina <= 0) { stamina = 0; tired = true; } }
        else { stamina = Math.min(1, stamina + (walk == 0 ? 1 / 160.0 : 1 / 360.0)); if (tired && stamina > 0.3) tired = false; }
        double sp = running ? 0.078 : 0.045;
        if (walk < 0) sp *= 0.6;
        ang += turn * 0.05;
        move(Math.cos(ang) * walk * sp, Math.sin(ang) * walk * sp);
        noise = walk == 0 ? 1.0 : running ? 9 : 3.5;
        if (enraged) noise *= 1.25;
        if (walk != 0 && ++stepT >= (running ? 13 : 22)) {
            stepT = 0;
            sound(SoundEvents.GRASS_STEP, 0.7F + rnd.nextFloat() * 0.2F, 0.3F);
        }

        // the fires
        for (int i = 0; i < FIRES; i++) {
            if (lit[i] || Math.hypot(fx[i] - px, fy[i] - py) > 0.9) continue;
            lit[i] = true;
            fires++;
            score += 100;
            fogBoost = 900;
            pling(1.6F);
            pling(2.0F);
            if (fires == FIRES) {                                  // the last one: the forest wakes up
                enraged = true;
                say("cutemod.forest.allit");
                growl(G_ROAR);
                if (!awake) spawn();
                ox = px; oy = py; alert = 600;
            } else say("cutemod.forest.lit");
        }
        // blue lights: not fires. Touch one and the monster knows where you are, and the fog closes in.
        for (int i = 0; i < WISPS; i++) {
            if (wgone[i] || Math.hypot(wx[i] - px, wy[i] - py) > 1.0) continue;
            wgone[i] = true;
            if (!awake) spawn();
            ox = px; oy = py; alert = 600;
            thickT = Math.max(thickT, 300);
            say("cutemod.forest.wisp");
            pling(0.4F);
        }

        if (--whisperT <= 0) {
            whisperT = 1200 + rnd.nextInt(1500);
            if (msgT == 0) say("cutemod.forest.whisper." + rnd.nextInt(5));
        }

        if (!awake && ticks == 900) spawn();
        double d = 99;
        if (awake) {
            d = Math.hypot(ex - px, ey - py);
            boolean safe = nearLitFire(px, py);
            double heard = noise * (thickT > 0 ? 0.85 : 1);
            if (!safe && (d < heard || d < 2.2)) {                  // it hears you (or it is so close that it sees you)
                if (alert == 0 && d < 14) sound(SoundEvents.WOOD_BREAK, 0.6F, 0.35F);   // a branch cracks: it turns towards you
                ox = px; oy = py; alert = Math.max(alert, 300);
            }
            if (enraged && ticks % 180 == 0 && !safe) {             // the awake forest points it your way
                ox = px + (rnd.nextDouble() - 0.5) * 5; oy = py + (rnd.nextDouble() - 0.5) * 5;
                alert = Math.max(alert, 240);
            }
            if (alert > 0) {
                double spd = (d < 3.2 ? 0.036 : 0.028) + 0.002 * fires + (enraged ? 0.004 : 0);
                stepMonster(ox, oy, spd);
                if (Math.hypot(ox - ex, oy - ey) < 0.7) {           // reached the spot: it sniffs around nearby
                    alert = 0;
                    gx = Math.max(3, Math.min(S - 3, ex + (rnd.nextDouble() - 0.5) * 8));
                    gy = Math.max(3, Math.min(S - 3, ey + (rnd.nextDouble() - 0.5) * 8));
                    wanderCd = 400;
                }
            } else {
                if (Math.hypot(gx - ex, gy - ey) < 1.0 || --wanderCd <= 0) {
                    gx = 3 + rnd.nextDouble() * (S - 6);
                    gy = 3 + rnd.nextDouble() * (S - 6);
                    wanderCd = 600 + rnd.nextInt(600);
                }
                stepMonster(gx, gy, 0.022 + 0.001 * fires);
            }
            d = Math.hypot(ex - px, ey - py);
            if (d < 0.6) { over = true; pling(0.5F); beep(); growl(G_SCREAM); return; }
            if (d < 8 && ticks % (int) (14 + d * 6) == 0) pling(0.5F);        // heartbeat, faster when it is close
            if (d < 6 && ticks % 130 == 0) growl(G_DEEP);
            if (d < 10 && ++mstepT >= 28) {                                    // you can hear it walk
                mstepT = 0;
                sound(SoundEvents.GRASS_STEP, 0.5F, (float) (0.6 * (1 - d / 10)));
            }
        }

        if (Math.hypot(exitX - px, exitY - py) < 1.3) {
            if (fires == FIRES) {
                won = true;
                over = true;
                score += 500 + Math.max(0, 600 - ticks / 30);       // faster = more points
                pling(1.0F); pling(1.5F); pling(2.0F);
            } else if (msgT == 0) say("cutemod.forest.locked");
        }
    }

    @Override
    public boolean key(int keyCode) {
        if (over) return false;
        if (keyCode == 69) { throwStone(); return true; }          // E: a stone
        return false;
    }

    // ---------- drawing ----------
    /** The colour of something at distance f: it fades into the fog (the near part stays almost clear). lm = brightness. */
    private static int fogged(int rgb, double f, double fr, double lm) {
        double t = Math.min(1, Math.max(0, f / fr)), k = t * t * (3 - 2 * t);
        int r = (int) Math.min(255, ((rgb >> 16) & 255) * lm * (1 - k) + ((FOG >> 16) & 255) * k);
        int g = (int) Math.min(255, ((rgb >> 8) & 255) * lm * (1 - k) + ((FOG >> 8) & 255) * k);
        int b = (int) Math.min(255, (rgb & 255) * lm * (1 - k) + (FOG & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Where a point is on the screen: {distance in front of you, screen x, height of a wall at that distance}, or null. */
    private double[] proj(double sx, double sy) {
        double rx = sx - px, ry = sy - py;
        double f = rx * cA + ry * sA, r = -rx * sA + ry * cA;
        if (f < 0.2) return null;
        double cam = r / (f * PLANE);
        if (Math.abs(cam) > 1.5) return null;
        return new double[]{f, W / 2.0 * (1 + cam), H / f};
    }

    /** A flat bar of something, as wide as w around the screen x cx, with the columns behind the tree wall left out. */
    private void hbar(GuiGraphics g, double f, double cx, double w, double y, double h, int rgb, double fr, double lm) {
        int x0 = (int) Math.round(cx - w / 2), x1 = (int) Math.round(cx + w / 2);
        int ya = Math.max(0, (int) Math.round(y)), yb = Math.min(H, (int) Math.round(y + h));
        if (yb <= ya) return;
        int col = fogged(rgb, f, fr, lm);
        for (int x = Math.floorDiv(Math.max(0, x0), CW) * CW; x < x1 && x < W; x += CW) {
            if (x + CW <= x0 || f >= zbuf[x / CW]) continue;
            rect(g, x, ya, CW, yb - ya, col);
        }
    }

    /** A filled disc that never leaves the game screen (the glow of something right in front of you is far bigger than the screen). */
    private static void clipDisc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = Math.max(-r, -cy); dy <= Math.min(r, H - 1 - cy); dy++) {
            int dx = (int) Math.sqrt(Math.max(0, (double) r * r - (double) dy * dy));
            int x0 = Math.max(0, cx - dx), x1 = Math.min(W, cx + dx + 1);
            if (x1 > x0) g.fill(x0, cy + dy, x1, cy + dy + 1, argb);
        }
    }

    /** A soft light: many thin discs, one in the other, so it fades out smoothly. Not drawn when the tree wall is in front of it. */
    private void glow(GuiGraphics g, double f, double cx, double cy, double rad, int rgb, int alpha, double maxRange) {
        int c = (int) cx / CW;
        if (cx < 0 || cx >= W || c >= COLS || f >= zbuf[c]) return;
        int a = (int) (alpha * Math.max(0, 1 - f / maxRange) * Math.min(1, f / 1.5));    // fades out when you walk into it
        if (a < 2) return;
        rad = Math.min(rad, 34);
        int rings = 8, per = Math.max(1, a / rings);
        for (int i = 0; i < rings; i++) {
            int r = (int) (rad * (1 - i / (double) rings));
            if (r < 1) continue;
            clipDisc(g, (int) cx, (int) cy, r, (per << 24) | rgb);
        }
    }

    private void tree(GuiGraphics g, double sx, double sy, int kind, double fr) {
        double[] p = proj(sx, sy);
        if (p == null) return;
        double f = p[0], cx = p[1], full = p[2];
        int ground = H / 2 + (int) (full / 2);
        double wd = kind == 2 ? 0.36 : 0.2;
        int tw = Math.max(CW, (int) (full * wd));
        double th = full * (kind == 0 ? 2.1 : kind == 1 ? 1.75 : 1.9);
        int left = (int) cx - tw / 2, top = ground - (int) th;
        int ya = Math.max(0, top), yb = Math.min(H, ground);
        int base = kind == 1 ? 0x3A3228 : 0x2B2118;
        if (yb > ya) {
            for (int x = Math.floorDiv(Math.max(0, left), CW) * CW; x < left + tw && x < W; x += CW) {
                if (x + CW <= left || f >= zbuf[x / CW]) continue;
                int st = (x - left) * 4 / tw;                                  // bark: a light side and a dark side
                double lm = st == 0 ? 1.2 : st >= 3 ? 0.65 : 0.95;
                rect(g, x, ya, CW, yb - ya, fogged(base, f, fr, lm));
            }
        }
        if (kind == 0) {                                                        // a pine: three dark tiers
            for (int t = 0; t < 3; t++) hbar(g, f, cx, full * (0.95 - t * 0.28), top + full * (0.05 + t * 0.32), full * 0.4, 0x0E1A16, fr, 1);
        } else if (kind == 1) {                                                 // a dead tree: bare branches
            for (int i = 0; i < 3; i++) {
                double len = full * (0.36 - i * 0.08), y = top + th * (0.08 + i * 0.18), thick = Math.max(1, full * 0.04);
                hbar(g, f, cx - tw / 2.0 - len / 2, len, y, thick, base, fr, 1);
                hbar(g, f, cx + tw / 2.0 + len / 2, len * 0.8, y + th * 0.06, thick, base, fr, 1);
            }
        } else {                                                                // a fat tree: a round dark crown
            hbar(g, f, cx, full * 0.95, top, full * 0.34, 0x142016, fr, 1);
            hbar(g, f, cx, full * 0.65, top - full * 0.16, full * 0.18, 0x142016, fr, 1);
        }
    }

    /** A bush (a low dark clump) or a stump. They are only for looks: you walk through them. */
    private void deco(GuiGraphics g, double sx, double sy, int kind, double fr) {
        double[] p = proj(sx, sy);
        if (p == null) return;
        double f = p[0], cx = p[1], full = p[2], ground = H / 2.0 + full / 2;
        if (kind == 3) {
            hbar(g, f, cx, full * 0.62, ground - full * 0.2, full * 0.2, 0x0F1E14, fr, 1);
            hbar(g, f, cx - full * 0.06, full * 0.4, ground - full * 0.34, full * 0.15, 0x132616, fr, 1);
            hbar(g, f, cx + full * 0.12, full * 0.22, ground - full * 0.42, full * 0.1, 0x0F1E14, fr, 1);
        } else {
            hbar(g, f, cx, full * 0.3, ground - full * 0.2, full * 0.2, 0x2A2016, fr, 0.9);
            hbar(g, f, cx, full * 0.3, ground - full * 0.2, Math.max(1, full * 0.04), 0x4A3A28, fr, 1);
        }
    }

    /** The dark line of far trees on the horizon, a few shapes that turn with you. Thin fog shows them, thick fog hides them. */
    private void treeLine(GuiGraphics g, double fr) {
        double vis = Math.max(0, Math.min(1, (fr - 2.5) / 7.0));
        int a = (int) (0x60 * (0.3 + 0.7 * vis)) << 24;
        for (int i = 0; i < SIL; i++) {
            double d = angDiff(silA[i], ang);
            if (Math.abs(d) > 1.15) continue;
            int cx = (int) (W / 2.0 * (1 + Math.tan(d) / PLANE)), hw = silW[i], h = silH[i], top = H / 2 - h;
            bar(g, cx - 1, top + h / 3, cx + 2, H / 2 + 2, a | 0x0C1214);
            for (int t = 0; t < 3; t++) {
                int w = (int) (hw * (1.0 - t * 0.3)), y0 = top + (int) (h * 0.2 * t) , y1 = y0 + (int) (h * 0.3);
                bar(g, cx - w, y0, cx + w + 1, y1, a | 0x0C1214);
            }
        }
    }

    private static void bar(GuiGraphics g, int x0, int y0, int x1, int y1, int argb) {
        x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(W, x1); y1 = Math.min(H, y1);
        if (x1 > x0 && y1 > y0) g.fill(x0, y0, x1, y1, argb);
    }

    private void fire(GuiGraphics g, double sx, double sy, boolean on, double fr) {
        double[] p = proj(sx, sy);
        if (p == null) return;
        double f = p[0], cx = p[1], full = p[2];
        double ground = H / 2.0 + full / 2;
        double fr2 = fr * 1.7;                                                  // a lantern is seen through more fog than a tree
        hbar(g, f, cx, Math.max(CW, full * 0.07), ground - full * 0.85, full * 0.85, 0x2A2018, fr, 0.9);   // the post
        double flick = on ? 0.9 + 0.2 * Math.sin(ticks / 3.0 + sx * 7) : 1;
        hbar(g, f, cx, full * 0.22, ground - full * 1.08, full * 0.24, on ? 0xFFD060 : 0x3A2A1A, fr2, on ? 1.15 * flick : 1);   // the lantern
        if (on) {
            glow(g, f, cx, ground - full * 0.96, full * (1.1 + 0.1 * Math.sin(ticks / 4.0 + sx)), 0xFFB040, 0x40, 18);
            hbar(g, f, cx, full * 0.08, ground - full * 1.02, full * 0.1, 0xFFF4C0, fr2, 1.2);
        } else {
            glow(g, f, cx, ground - full * 0.96, full * 0.6, 0xFF8A2A, 0x70, 13);       // a faint ember: a warm dot far away
        }
    }

    private void wisp(GuiGraphics g, double sx, double sy, int i) {
        if ((ticks / 5 + i * 3) % 11 == 0) return;                              // it flickers
        double[] p = proj(sx, sy);
        if (p == null) return;
        double f = p[0], cx = p[1], full = p[2];
        double cy = H / 2.0 + full / 2 - full * (0.6 + 0.08 * Math.sin(ticks / 14.0 + i));
        glow(g, f, cx, cy, full * 0.85, 0x4AA8FF, 0xB0, 15);
        int c = (int) cx / CW;
        if (cx >= 0 && cx < W && c < COLS && f < zbuf[c]) clipDisc(g, (int) cx, (int) cy, Math.max(1, (int) (full * 0.06)), 0xFFD8F0FF);
    }

    private void road(GuiGraphics g, double fr) {
        double[] p = proj(exitX, exitY);
        if (p == null) return;
        double f = p[0], cx = p[1], full = p[2];
        double ground = H / 2.0 + full / 2, fr2 = fr * 2.2;
        hbar(g, f, cx, full * 2.2, ground - Math.max(1, full * 0.05), Math.max(1, full * 0.05), 0x707060, fr2, 1);   // the road
        hbar(g, f, cx, Math.max(CW, full * 0.08), ground - full * 1.4, full * 1.4, 0x3A3A34, fr2, 1);          // a lamp post
        hbar(g, f, cx, full * 0.26, ground - full * 1.55, full * 0.2, 0xD8FFE0, fr2, 1.2);
        glow(g, f, cx, ground - full * 1.45, full * 1.3, 0xA8FFC0, 0x40, 22);
    }

    private void monster(GuiGraphics g, double fr) {
        double[] p = proj(ex, ey);
        if (p == null) return;
        double f = p[0], cx = p[1], full = p[2];
        int sh = (int) (full * 1.55), sw = sh / 2, ground = H / 2 + (int) (full / 2);
        int left = (int) cx - sw / 2, top = ground - sh;
        if (sw < 2) return;
        for (int x = Math.floorDiv(Math.max(0, left), CW) * CW; x < left + sw && x < W; x += CW) {
            if (x + CW <= left || f >= zbuf[x / CW]) continue;
            int u = Math.max(0, Math.min(11, (x + CW / 2 - left) * 12 / sw));
            for (int row = 0; row < MONSTER.length; row++) {
                char ch = MONSTER[row].charAt(u);
                if (ch == '.') continue;
                int y0 = top + row * sh / MONSTER.length, y1 = Math.max(y0 + 1, top + (row + 1) * sh / MONSTER.length);
                int col = ch == 'r' ? fogged(0xFFFF2A2A, f, fr * 3.5, 1.1)             // the eyes glow through the fog
                        : fogged(ch == 'w' ? 0xB8B4BC : 0x0C0A10, f, fr, 1);
                if (y1 <= 0 || y0 >= H) continue;
                rect(g, x, Math.max(0, y0), CW, Math.min(H, y1) - Math.max(0, y0), col);
            }
        }
    }

    @Override
    public void render(GuiGraphics g) {
        if (over && !won) { jumpScare(g); return; }
        cA = Math.cos(ang);
        sA = Math.sin(ang);
        double fr = fogRange();
        double md = awake ? Math.hypot(ex - px, ey - py) : 99;
        double shake = md < 2.8 ? (2.8 - md) * 0.7 : 0;                         // the picture trembles when it is close
        g.pose().pushPose();
        if (shake > 0) g.pose().translate((rnd.nextDouble() - 0.5) * shake * 2, (rnd.nextDouble() - 0.5) * shake * 2, 0);

        int band = H / 2 - 26;                                                  // the sky fades into the fog; ground fades out of it
        g.fillGradient(0, 0, W, band, 0xFF070B10, 0xFF000000 | FOG);
        rect(g, 0, band, W, H / 2 - band, 0xFF000000 | FOG);
        g.fillGradient(0, H / 2, W, H, 0xFF000000 | FOG, 0xFF080B09);
        double md2 = angDiff(MOON, ang);
        if (Math.abs(md2) < 1.3) {                                              // the moon, behind the fog
            int mxp = (int) (W / 2.0 * (1 + Math.tan(md2) / PLANE));
            if (mxp - 20 >= 0 && mxp + 20 <= W) {
                clipDisc(g, mxp, 18, 16, 0x16DCE4D0);
                clipDisc(g, mxp, 18, 10, 0x30E8EEDC);
                clipDisc(g, mxp, 18, 7, 0x70E8EEDC);
            }
        }

        treeLine(g, fr);
        double dirX = cA, dirY = sA, plX = -dirY * PLANE, plY = dirX * PLANE;
        for (int c = 0; c < COLS; c++) {                                        // the wall of trees round the forest: one ray per column
            double cam = 2.0 * (c + 0.5) / COLS - 1;
            double rdx = dirX + plX * cam, rdy = dirY + plY * cam;
            int mapX = (int) px, mapY = (int) py;
            double ddx = Math.abs(1 / rdx), ddy = Math.abs(1 / rdy), sdx, sdy;
            int stepX, stepY;
            if (rdx < 0) { stepX = -1; sdx = (px - mapX) * ddx; } else { stepX = 1; sdx = (mapX + 1 - px) * ddx; }
            if (rdy < 0) { stepY = -1; sdy = (py - mapY) * ddy; } else { stepY = 1; sdy = (mapY + 1 - py) * ddy; }
            boolean side = false;
            while (mapX > 0 && mapY > 0 && mapX < S - 1 && mapY < S - 1) {
                if (sdx < sdy) { sdx += ddx; mapX += stepX; side = false; }
                else { sdy += ddy; mapY += stepY; side = true; }
            }
            double dist = Math.max(0.05, side ? sdy - ddy : sdx - ddx);
            zbuf[c] = dist;
            if (dist >= fr) continue;                                           // lost in the fog
            double wallX = side ? px + dist * rdx : py + dist * rdy;
            wallX -= Math.floor(wallX);
            int ground = H / 2 + (int) (H / dist / 2), top = Math.max(0, ground - (int) (H / dist * 1.9));
            int base = (int) (wallX * 10) % 3 == 0 ? 0x17130F : 0x1F1913;       // trunks side by side
            rect(g, c * CW, top, CW, Math.min(H, ground) - top, fogged(base, dist, fr, side ? 0.8 : 1));
        }

        List<double[]> things = new ArrayList<>();                              // far ones first
        double lim = fr * fr * 1.1;
        for (int i = 0; i < nTrees; i++) {
            double d2 = sq(trX[i] - px) + sq(trY[i] - py);
            if (d2 < lim) things.add(new double[]{d2, 0, trX[i], trY[i], trK[i]});
        }
        for (int i = 0; i < nDeco; i++) {
            double d2 = sq(dX[i] - px) + sq(dY[i] - py);
            if (d2 < lim) things.add(new double[]{d2, 5, dX[i], dY[i], dK[i]});
        }
        for (int i = 0; i < FIRES; i++) {
            double d2 = sq(fx[i] - px) + sq(fy[i] - py);
            if (d2 < 400) things.add(new double[]{d2, 1, fx[i], fy[i], lit[i] ? 1 : 0});
        }
        for (int i = 0; i < WISPS; i++) {
            double d2 = sq(wx[i] - px) + sq(wy[i] - py);
            if (!wgone[i] && d2 < 200) things.add(new double[]{d2, 2, wx[i], wy[i], i});
        }
        if (fires == FIRES) things.add(new double[]{sq(exitX - px) + sq(exitY - py), 3, exitX, exitY, 0});
        if (awake && md < 11) things.add(new double[]{md * md, 4, ex, ey, 0});
        things.sort((a, b) -> Double.compare(b[0], a[0]));
        for (double[] s : things) {
            switch ((int) s[1]) {
                case 0 -> tree(g, s[2], s[3], (int) s[4], fr);
                case 1 -> fire(g, s[2], s[3], s[4] > 0, fr);
                case 2 -> wisp(g, s[2], s[3], (int) s[4]);
                case 3 -> road(g, fr);
                case 5 -> deco(g, s[2], s[3], (int) s[4], fr);
                default -> monster(g, fr);
            }
        }
        g.pose().popPose();

        for (int i = 0; i < 3; i++) {                                           // drifting fog: soft bands
            int w = 150 + i * 30, x = (int) ((ticks * (0.12 + i * 0.05) + i * 90) % (W + w)) - w;
            int xa = Math.max(0, x), xb = Math.min(W, x + w), y = H / 2 - 14 + i * 12;
            if (xb <= xa) continue;
            g.fillGradient(xa, y, xb, y + 7, 0x00B8C8C8, 0x14B8C8C8);
            g.fillGradient(xa, y + 7, xb, y + 14, 0x14B8C8C8, 0x00B8C8C8);
        }
        if (md < 3.5) {                                                         // it is close: red edges and static
            rect(g, 0, 0, W, H, ((int) ((3.5 - md) / 3.5 * 80) << 24) | 0x900000);
            for (int k = 0; k < 6; k++) rect(g, rnd.nextInt(W - 40), rnd.nextInt(H), 40, 1, 0x40FFFFFF);
        }
        for (int i = 0; i < 4; i++) {                                           // dark vignette
            int a = (0x70 - i * 0x1C) << 24;
            rect(g, i * 6, 0, 6, H, a);
            rect(g, W - 6 - i * 6, 0, 6, H, a);
        }
        hud(g);
        if (msgT > 0) ctext(g, Component.translatable(msg).getString(), W / 2, H - 14, msgT < 30 ? 0xFF8A9A90 : 0xFFE8F0E0);
        if (won) rect(g, 0, 0, W, H, 0x40FFFFFF);
    }

    private static double sq(double v) { return v * v; }

    private void hud(GuiGraphics g) {
        // stamina (SHIFT)
        rect(g, 6, 6, 34, 9, 0xAA000000);
        rect(g, 7, 7, 32, 7, 0xFF1A1A22);
        rect(g, 7, 7, (int) Math.round(32 * stamina), 7, tired ? 0xFFFF4A4A : stamina > 0.4 ? 0xFF5BD97A : 0xFFFFD84A);
        // the 5 fires
        for (int i = 0; i < FIRES; i++) rect(g, 7 + i * 7, 18, 5, 5, i < fires ? 0xFFFFC040 : 0xFF3A3028);
        // a loud noise ring: how far you are heard
        int bar = (int) Math.min(32, noise * 2.9);
        rect(g, 7, 26, 32, 2, 0x66000000);
        rect(g, 7, 26, bar, 2, noise > 8 ? 0xFFFF6A4A : noise > 3 ? 0xFFFFD84A : 0xFF7ADFA0);
        compass(g);
    }

    private void compass(GuiGraphics g) {
        int cx = W / 2, y = 4, half = 44;
        rect(g, cx - half, y, half * 2, 11, 0x55000000);
        mark(g, "N", -Math.PI / 2, 0xFFE8E4EC, cx, y, half);
        mark(g, "E", 0, 0xFF9AA8A0, cx, y, half);
        mark(g, "S", Math.PI / 2, 0xFF9AA8A0, cx, y, half);
        mark(g, "W", Math.PI, 0xFF9AA8A0, cx, y, half);
        if (fires == FIRES) mark(g, "*", Math.atan2(exitY - py, exitX - px), 0xFF6AFF9A, cx, y, half);   // the road
        rect(g, cx, y + 11, 1, 2, 0xFFFFD866);
    }

    private void mark(GuiGraphics g, String s, double bearing, int col, int cx, int y, int half) {
        double d = angDiff(bearing, ang);
        if (Math.abs(d) > 0.9) return;
        ctext(g, s, cx + (int) (d / 0.9 * (half - 5)), y + 1, col);
    }

    /** You were caught: a skull with antlers. (The "Game over" box of the computer is drawn on top of the middle.) */
    private void jumpScare(GuiGraphics g) {
        rect(g, 0, 0, W, H, (System.currentTimeMillis() / 80) % 2 == 0 ? 0xFF1A0000 : 0xFF000000);
        for (int i = 0; i < 5; i++) {                                           // antlers
            rect(g, 62 - i * 9, 52 - i * 10, 7, 14, 0xFF2A2018);
            rect(g, 150 + i * 9, 52 - i * 10, 7, 14, 0xFF2A2018);
            rect(g, 46 - i * 6, 20 - i * 4 + 10, 12, 4, 0xFF2A2018);
            rect(g, 162 + i * 6, 20 - i * 4 + 10, 12, 4, 0xFF2A2018);
        }
        rect(g, 62, 30, 96, 96, 0xFFD8D4C8);
        rect(g, 70, 118, 80, 14, 0xFFD8D4C8);
        rect(g, 70, 56, 30, 26, 0xFF000000);
        rect(g, 120, 56, 30, 26, 0xFF000000);
        rect(g, 80, 64, 10, 10, 0xFFFF2A2A);
        rect(g, 130, 64, 10, 10, 0xFFFF2A2A);
        rect(g, 106, 86, 8, 16, 0xFF000000);
        for (int k = 0; k < 8; k++) rect(g, 72 + k * 10, 108, 6, 18, k % 2 == 0 ? 0xFFE8E4DC : 0xFF000000);
    }

    @Override
    public String hintKey() { return "cutemod.hint.forest"; }

    @Override
    public Component status() { return Component.translatable("cutemod.forest.status", fires, FIRES, pebbles); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() { return Component.translatable(won ? "cutemod.forest.win" : "cutemod.forest.lost"); }
}
