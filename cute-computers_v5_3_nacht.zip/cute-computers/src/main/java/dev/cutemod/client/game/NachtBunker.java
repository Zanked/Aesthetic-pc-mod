package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Night of the Dead: a top-down zombie bunker in the spirit of Call of Duty Zombies (the old "Nacht der Untoten" map).
 * Four concrete rooms, boarded windows the zombies tear down plank by plank, doors you open with points, guns on the walls,
 * a Mystery Box, Juggernog, Speed Cola, Pack-a-Punch and power-ups. Round after round, until you go down.
 *
 * Controls: WASD walk, mouse aims, hold the left button to shoot, R reload, E use (hold it at a window to repair), 1 / 2 weapon.
 * The score is the round you reached. Everything is hitscan, drawn with rectangles and discs like the other games.
 */
public class NachtBunker extends MiniGame {
    // ---------------------------------------------------------------- the map (game pixels, W x H = 220 x 140)
    // zones: 0 = start room (bottom left), 1 = main hall (bottom right), 2 = storage (top left), 3 = lab (top right)
    private static final int[][] WALLS = {
            {8, 8, 42, 3}, {66, 8, 84, 3}, {166, 8, 46, 3},                  // top
            {8, 129, 32, 3}, {56, 129, 94, 3}, {166, 129, 46, 3},            // bottom
            {8, 8, 3, 22}, {8, 46, 3, 50}, {8, 112, 3, 20},                  // left
            {209, 8, 3, 22}, {209, 46, 3, 50}, {209, 112, 3, 20},            // right
            {8, 69, 42, 3}, {66, 69, 84, 3}, {166, 69, 46, 3},               // the horizontal divider
            {109, 8, 3, 84}, {109, 108, 3, 24}};                             // the vertical divider

    /** The windows: gate x, y, w, h | outside point x, y | inside point x, y | zone. */
    private static final int[][] WIN = {
            {8, 96, 3, 16, 4, 104, 17, 104, 0}, {40, 129, 16, 3, 48, 136, 48, 123, 0},
            {209, 96, 3, 16, 216, 104, 203, 104, 1}, {150, 129, 16, 3, 158, 136, 158, 123, 1},
            {8, 30, 3, 16, 4, 38, 17, 38, 2}, {50, 8, 16, 3, 58, 4, 58, 17, 2},
            {209, 30, 3, 16, 216, 38, 203, 38, 3}, {150, 8, 16, 3, 158, 4, 158, 17, 3}};

    /** The doors: x, y, w, h | zone a, zone b | cost | centre x, y. */
    private static final int[][] DOORS = {
            {109, 92, 3, 16, 0, 1, 750, 110, 100}, {50, 69, 16, 3, 0, 2, 500, 58, 70}, {150, 69, 16, 3, 1, 3, 1000, 158, 70}};

    private static final int[][] ZONE_RECT = {{11, 72, 98, 57}, {112, 72, 97, 57}, {11, 11, 98, 58}, {112, 11, 97, 58}};
    private static final int[][] ZONE_CENTRE = {{60, 100}, {160, 100}, {60, 40}, {160, 40}};

    private static final int OBJ_WALL = 0, OBJ_BOX = 1, OBJ_JUGG = 2, OBJ_SPEED = 3, OBJ_PAP = 4;
    /** Things to use: kind | x, y | weapon (for a wall gun) | cost | zone. */
    private static final int[][] OBJ = {
            {OBJ_WALL, 30, 76, 1, 200, 0}, {OBJ_WALL, 130, 76, 3, 1200, 1}, {OBJ_WALL, 25, 14, 2, 1000, 2}, {OBJ_WALL, 185, 14, 4, 1800, 3},
            {OBJ_BOX, 100, 40, 0, 950, 2}, {OBJ_JUGG, 190, 76, 0, 2500, 1}, {OBJ_SPEED, 20, 64, 0, 3000, 2}, {OBJ_PAP, 118, 40, 0, 5000, 3}};

    // ---------------------------------------------------------------- weapons
    private record Wp(String name, int dmg, int mag, int res, int delay, int pellets, double spread, boolean auto, int reload,
                      int pierce, int range, int color, int wall, int ammo) {}

    private static final Wp[] WP = {
            new Wp("M1911", 34, 8, 80, 8, 1, 0.03, false, 96, 1, 190, 0xFFFFE9A0, 0, 0),
            new Wp("Kar98k", 160, 5, 50, 30, 1, 0.01, false, 130, 1, 240, 0xFFFFE9A0, 200, 100),
            new Wp("MP40", 30, 32, 192, 5, 1, 0.07, true, 130, 1, 200, 0xFFFFE9A0, 1000, 500),
            new Wp("Double Barrel", 58, 2, 38, 26, 8, 0.2, false, 100, 1, 80, 0xFFFFC080, 1200, 600),
            new Wp("BAR", 62, 20, 160, 7, 1, 0.04, true, 150, 1, 230, 0xFFFFE9A0, 1800, 900),
            new Wp("M1 Garand", 90, 8, 96, 11, 1, 0.02, false, 120, 1, 240, 0xFFFFE9A0, 0, 0),
            new Wp("Ray Gun", 520, 20, 160, 10, 1, 0.02, false, 110, 3, 230, 0xFF7CFFB0, 0, 0)};

    private static final int PU_MAX = 0, PU_INSTA = 1, PU_DOUBLE = 2, PU_NUKE = 3;

    // ---------------------------------------------------------------- state
    private static final class Z {
        double x, y, hp, sp;
        int st, win, t, cd, anim, flash;     // st: 0 tears the boards, 1 climbs in, 2 hunts the player
        boolean dead;
    }

    private final List<Z> zs = new ArrayList<>();
    private final List<double[]> picks = new ArrayList<>();      // x, y, type, life
    private final List<double[]> tracers = new ArrayList<>();    // x1, y1, x2, y2, life, colour
    private final List<int[]> blood = new ArrayList<>();         // x, y, size

    private double px, py, aim, hp, hurtFlash;
    private int maxHp, points, round, toSpawn, spawnT, breakT, introT, t, regen;
    private final int[] slotW = new int[2], mag = new int[2], res = new int[2];
    private final boolean[] pap = new boolean[2];
    private int cur, cool, reloadT, reloadMax, flashT, msgT, repairT, instaT, dblT, boxState, boxT, boxW;
    private boolean jugg, speedCola, prevMouse;
    private final boolean[] prevKey = new boolean[4];
    private final boolean[] zoneOpen = new boolean[4];
    private final boolean[] doorOpen = new boolean[DOORS.length];
    private final int[] boards = new int[WIN.length];
    private Component msg = Component.empty();
    private String prompt = "";

    @Override
    public void reset() {
        score = 0; over = false; t = 0;
        px = 60; py = 100; aim = 0; maxHp = 100; hp = maxHp; hurtFlash = 0; regen = 0;
        points = 500; round = 0; toSpawn = 0; spawnT = 0; breakT = 120; introT = 0;
        slotW[0] = 0; slotW[1] = -1; pap[0] = false; pap[1] = false; cur = 0; setFull(0);
        cool = 0; reloadT = 0; reloadMax = 1; flashT = 0; msgT = 0; repairT = 0; instaT = 0; dblT = 0;
        boxState = 0; boxT = 0; boxW = 1; jugg = false; speedCola = false; prevMouse = false; prompt = "";
        Arrays.fill(prevKey, false); Arrays.fill(zoneOpen, false); zoneOpen[0] = true;
        Arrays.fill(doorOpen, false); Arrays.fill(boards, 3);
        zs.clear(); picks.clear(); tracers.clear(); blood.clear();
    }

    // ---------------------------------------------------------------- input helpers
    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private static boolean leftDown() {
        return GLFW.glfwGetMouseButton(Minecraft.getInstance().getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    private boolean pressed(int i, int key) {
        boolean d = down(key);
        boolean r = d && !prevKey[i];
        prevKey[i] = d;
        return r;
    }

    @Override
    public boolean key(int keyCode) {
        return keyCode == 87 || keyCode == 65 || keyCode == 83 || keyCode == 68 || keyCode == 69 || keyCode == 82 || keyCode == 49 || keyCode == 50;
    }

    // ---------------------------------------------------------------- weapon helpers
    private int magMax(int s) { Wp w = WP[slotW[s]]; return pap[s] ? w.mag() * 3 / 2 : w.mag(); }

    private int resMax(int s) { Wp w = WP[slotW[s]]; return pap[s] ? w.res() * 3 / 2 : w.res(); }

    private double dmgOf(int s) { return WP[slotW[s]].dmg() * (pap[s] ? 2.5 : 1.0); }

    private void setFull(int s) { mag[s] = magMax(s); res[s] = resMax(s); }

    private String wname(int s) { return WP[slotW[s]].name() + (pap[s] ? " PaP" : ""); }

    private int slotOf(int weapon) {
        for (int s = 0; s < 2; s++) if (slotW[s] == weapon) return s;
        return -1;
    }

    private void give(int weapon) {
        int slot = slotOf(weapon);
        if (slot < 0) slot = slotW[1] < 0 ? 1 : cur;
        slotW[slot] = weapon; pap[slot] = false; setFull(slot);
        cur = slot; reloadT = 0; cool = 10;
        sound(SoundEvents.LEVER_CLICK, 1.2F, 0.6F);
    }

    private void say(String key, Object... a) { msg = Component.translatable(key, a); msgT = 130; }

    private void addPts(int n) { points += dblT > 0 ? n * 2 : n; }

    // ---------------------------------------------------------------- geometry
    private static int zoneAt(double x, double y) { return (y < 70 ? 2 : 0) + (x < 110 ? 0 : 1); }

    private static boolean overlaps(int[] r, double x, double y, double rad) {
        return x + rad > r[0] && x - rad < r[0] + r[2] && y + rad > r[1] && y - rad < r[1] + r[3];
    }

    /** Walls, closed doors and the window gates stop walking. */
    private boolean blocked(double x, double y, double rad) {
        for (int[] w : WALLS) if (overlaps(w, x, y, rad)) return true;
        for (int i = 0; i < DOORS.length; i++) if (!doorOpen[i] && overlaps(DOORS[i], x, y, rad)) return true;
        for (int[] w : WIN) if (overlaps(w, x, y, rad)) return true;
        return false;
    }

    /** Walls and closed doors stop bullets (windows do not). */
    private boolean stopsBullet(double x, double y) {
        for (int[] w : WALLS) if (x >= w[0] && x < w[0] + w[2] && y >= w[1] && y < w[1] + w[3]) return true;
        for (int i = 0; i < DOORS.length; i++) {
            int[] d = DOORS[i];
            if (!doorOpen[i] && x >= d[0] && x < d[0] + d[2] && y >= d[1] && y < d[1] + d[3]) return true;
        }
        return false;
    }

    /** The first door to go through to get from zone a to zone b over the open doors, or -1. */
    private int firstDoor(int a, int b) {
        if (a == b) return -1;
        int[] first = new int[4];
        Arrays.fill(first, -2);
        first[a] = -1;
        int[] q = new int[4];
        int head = 0, tail = 0;
        q[tail++] = a;
        while (head < tail) {
            int z = q[head++];
            for (int i = 0; i < DOORS.length; i++) {
                if (!doorOpen[i]) continue;
                int da = DOORS[i][4], db = DOORS[i][5];
                if (da != z && db != z) continue;
                int o = da == z ? db : da;
                if (first[o] != -2) continue;
                first[o] = z == a ? i : first[z];
                q[tail++] = o;
            }
        }
        return first[b] >= 0 ? first[b] : -1;
    }

    // ---------------------------------------------------------------- the tick
    @Override
    public void tick() {
        t++;
        boolean ePressed = pressed(0, 69), rPressed = pressed(1, 82);
        if (pressed(2, 49) && cur != 0 && slotW[0] >= 0) switchTo(0);
        if (pressed(3, 50) && cur != 1 && slotW[1] >= 0) switchTo(1);

        movePlayer();
        aim = Math.atan2(my - py, mx - px);
        weapons(rPressed);
        interact(ePressed);
        waves();
        zombies();
        pickups();

        for (int i = tracers.size() - 1; i >= 0; i--) if (--tracers.get(i)[4] <= 0) tracers.remove(i);
        if (cool > 0) cool--;
        if (flashT > 0) flashT--;
        if (msgT > 0) msgT--;
        if (introT > 0) introT--;
        if (instaT > 0) instaT--;
        if (dblT > 0) dblT--;
        if (hurtFlash > 0) hurtFlash = Math.max(0, hurtFlash - 0.04);
        if (regen > 0) regen--; else if (hp < maxHp) hp = Math.min(maxHp, hp + 0.5);
        if (!zs.isEmpty() && rnd.nextInt(170) == 0) growl(G_ZOMBIE);

        score = round;
        if (hp <= 0) { over = true; beep(); growl(G_SCREAM); }
    }

    private void movePlayer() {
        double dx = 0, dy = 0;
        if (down(87)) dy -= 1;
        if (down(83)) dy += 1;
        if (down(65)) dx -= 1;
        if (down(68)) dx += 1;
        if (dx == 0 && dy == 0) return;
        double l = Math.hypot(dx, dy), s = 0.85;
        dx = dx / l * s; dy = dy / l * s;
        if (!blocked(px + dx, py, 3)) px += dx;
        if (!blocked(px, py + dy, 3)) py += dy;
        px = Math.max(12, Math.min(208, px));
        py = Math.max(12, Math.min(128, py));
    }

    private void switchTo(int s) {
        cur = s; reloadT = 0; cool = 8;
        sound(SoundEvents.LEVER_CLICK, 1.4F, 0.5F);
    }

    // ---------------------------------------------------------------- shooting
    private void weapons(boolean rPressed) {
        int s = cur;
        Wp w = WP[slotW[s]];
        boolean left = leftDown() && mx >= 0 && my >= 0 && mx < W && my < H;
        boolean fresh = left && !prevMouse;
        prevMouse = left;
        if (reloadT > 0) {
            if (--reloadT == 0) {
                int need = Math.min(magMax(s) - mag[s], res[s]);
                mag[s] += need; res[s] -= need;
                sound(SoundEvents.LEVER_CLICK, 0.8F, 0.5F);
            }
            return;
        }
        if (rPressed && mag[s] < magMax(s) && res[s] > 0) { startReload(w); return; }
        if (left && cool <= 0 && (w.auto() || fresh)) {
            if (mag[s] > 0) {
                mag[s]--;
                cool = w.delay();
                shoot(w, s);
                if (mag[s] == 0 && res[s] > 0) startReload(w);
            } else if (res[s] > 0) {
                startReload(w);
            } else if (fresh) {
                beep();
                say("cutemod.nacht.empty");
            }
        }
    }

    private void startReload(Wp w) {
        reloadMax = Math.max(10, (int) (w.reload() * (speedCola ? 0.5 : 1.0)));
        reloadT = reloadMax;
        sound(SoundEvents.LEVER_CLICK, 1.2F, 0.5F);
    }

    private void shoot(Wp w, int s) {
        double dmg = dmgOf(s);
        int col = pap[s] ? 0xFFFFD84A : w.color();
        for (int i = 0; i < w.pellets(); i++) trace(aim + (rnd.nextDouble() - 0.5) * 2 * w.spread(), dmg, w.range(), w.pierce(), col, w.pellets());
        flashT = 3;
        switch (slotW[s]) {
            case 0 -> sound(SoundEvents.CROSSBOW_SHOOT, 1.5F, 0.6F);
            case 1, 5 -> sound(SoundEvents.FIREWORK_ROCKET_BLAST, 0.9F, 0.7F);
            case 2 -> sound(SoundEvents.CROSSBOW_SHOOT, 1.9F, 0.5F);
            case 3 -> sound(SoundEvents.GENERIC_EXPLODE, 1.7F, 0.35F);
            case 4 -> sound(SoundEvents.FIREWORK_ROCKET_BLAST, 1.3F, 0.6F);
            default -> sound(SoundEvents.BLAZE_SHOOT, 1.6F, 0.6F);
        }
    }

    private void trace(double a, double dmg, int range, int pierce, int colour, int pellets) {
        double dx = Math.cos(a), dy = Math.sin(a);
        double x = px + dx * 5, y = py + dy * 5;
        List<Z> hit = new ArrayList<>();
        for (int step = 5; step < range; step += 2) {
            x = px + dx * step; y = py + dy * step;
            if (x < 0 || y < 0 || x > W || y > H || stopsBullet(x, y)) break;
            boolean stop = false;
            for (Z z : zs) {
                if (z.dead || hit.contains(z)) continue;
                double ex = z.x - x, ey = z.y - y;
                if (ex * ex + ey * ey < 20) {
                    hitZombie(z, dmg, pellets);
                    hit.add(z);
                    if (hit.size() >= pierce) { stop = true; break; }
                }
            }
            if (stop) break;
        }
        tracers.add(new double[]{px + dx * 6, py + dy * 6, x, y, 4, colour});
    }

    private void hitZombie(Z z, double dmg, int pellets) {
        if (z.dead) return;
        z.hp -= instaT > 0 ? 100000 : dmg;
        z.flash = 3;
        addPts(pellets > 1 ? 4 : 10);
        blood.add(new int[]{(int) z.x + rnd.nextInt(5) - 2, (int) z.y + rnd.nextInt(5) - 2, 1 + rnd.nextInt(2)});
        if (blood.size() > 150) blood.remove(0);
        if (rnd.nextInt(3) == 0) sound(SoundEvents.ZOMBIE_HURT, 0.55F + rnd.nextFloat() * 0.2F, 0.4F);
        if (z.hp <= 0) {
            z.dead = true;
            addPts(60);
            sound(SoundEvents.ZOMBIE_DEATH, 0.6F + rnd.nextFloat() * 0.2F, 0.5F);
            if (rnd.nextInt(25) == 0 && picks.size() < 3) picks.add(new double[]{z.x, z.y, rnd.nextInt(4), 1800});
        }
    }

    // ---------------------------------------------------------------- using things
    private void interact(boolean ePressed) {
        prompt = "";
        double best = 14 * 14;
        int kind = -1, idx = -1;
        for (int i = 0; i < OBJ.length; i++) {
            if (!zoneOpen[OBJ[i][5]]) continue;
            double d = dist2(OBJ[i][1], OBJ[i][2]);
            if (d < best) { best = d; kind = 0; idx = i; }
        }
        for (int i = 0; i < DOORS.length; i++) {
            if (doorOpen[i]) continue;
            double d = dist2(DOORS[i][7], DOORS[i][8]);
            if (d < best) { best = d; kind = 1; idx = i; }
        }
        for (int i = 0; i < WIN.length; i++) {
            if (boards[i] >= 3 || !zoneOpen[WIN[i][8]]) continue;
            double d = dist2(WIN[i][6], WIN[i][7]);
            if (d < best) { best = d; kind = 2; idx = i; }
        }
        if (kind != 2) repairT = 0;
        if (kind == 1) {
            int cost = DOORS[idx][6];
            prompt = Component.translatable("cutemod.nacht.use.door", cost).getString();
            if (ePressed) {
                if (points < cost) { poor(); return; }
                points -= cost;
                doorOpen[idx] = true; zoneOpen[DOORS[idx][4]] = true; zoneOpen[DOORS[idx][5]] = true;
                sound(SoundEvents.IRON_DOOR_OPEN, 0.7F, 0.6F);
            }
        } else if (kind == 2) {
            if (windowBusy(idx)) return;
            prompt = Component.translatable("cutemod.nacht.use.repair").getString();
            if (down(69) && ++repairT >= 22) {
                repairT = 0;
                boards[idx]++;
                addPts(10);
                sound(SoundEvents.WOOD_PLACE, 1.0F, 0.6F);
            }
        } else if (kind == 0) {
            useObject(OBJ[idx], ePressed);
        }
    }

    private double dist2(double x, double y) { double dx = x - px, dy = y - py; return dx * dx + dy * dy; }

    private boolean windowBusy(int i) {
        for (Z z : zs) if (!z.dead && z.win == i && z.st <= 1) return true;
        return false;
    }

    private void poor() { beep(); say("cutemod.nacht.poor"); }

    private void useObject(int[] o, boolean ePressed) {
        int cost = o[4];
        switch (o[0]) {
            case OBJ_WALL -> {
                Wp w = WP[o[3]];
                int owned = slotOf(o[3]);
                if (owned >= 0) {
                    cost = w.ammo();
                    prompt = Component.translatable("cutemod.nacht.use.ammo", wname(owned), cost).getString();
                } else {
                    prompt = Component.translatable("cutemod.nacht.use.buy", w.name(), cost).getString();
                }
                if (ePressed) {
                    if (points < cost) { poor(); return; }
                    points -= cost;
                    if (owned >= 0) { setFull(owned); sound(SoundEvents.LEVER_CLICK, 1.0F, 0.6F); }
                    else give(o[3]);
                }
            }
            case OBJ_BOX -> {
                if (boxState == 0) {
                    prompt = Component.translatable("cutemod.nacht.use.box", cost).getString();
                    if (ePressed) {
                        if (points < cost) { poor(); return; }
                        points -= cost; boxState = 1; boxT = 110;
                        sound(SoundEvents.NOTE_BLOCK_CHIME.value(), 0.7F, 0.7F);
                    }
                } else if (boxState == 2) {
                    prompt = Component.translatable("cutemod.nacht.use.take", WP[boxW].name()).getString();
                    if (ePressed) { give(boxW); boxState = 0; }
                }
            }
            case OBJ_JUGG, OBJ_SPEED -> {
                boolean has = o[0] == OBJ_JUGG ? jugg : speedCola;
                if (has) return;
                String name = o[0] == OBJ_JUGG ? "Juggernog" : "Speed Cola";
                prompt = Component.translatable("cutemod.nacht.use.perk", name, cost).getString();
                if (ePressed) {
                    if (points < cost) { poor(); return; }
                    points -= cost;
                    if (o[0] == OBJ_JUGG) { jugg = true; maxHp = 200; hp = maxHp; } else speedCola = true;
                    sound(SoundEvents.GENERIC_DRINK, 1.0F, 0.7F);
                }
            }
            default -> {
                if (pap[cur]) return;
                prompt = Component.translatable("cutemod.nacht.use.perk", "Pack-a-Punch", cost).getString();
                if (ePressed) {
                    if (points < cost) { poor(); return; }
                    points -= cost;
                    pap[cur] = true; setFull(cur); reloadT = 0;
                    sound(SoundEvents.ANVIL_USE, 1.4F, 0.5F);
                    say("cutemod.nacht.upgraded", wname(cur));
                }
            }
        }
    }

    // ---------------------------------------------------------------- rounds and zombies
    private void waves() {
        if (boxState == 1 && --boxT <= 0) {
            boxState = 2; boxT = 420;
            for (int tries = 0; tries < 30; tries++) {
                int r = rnd.nextInt(14);
                boxW = r == 0 ? 6 : 1 + r % 5;
                if (slotOf(boxW) < 0) break;
            }
            pling(1.5F);
        } else if (boxState == 2 && --boxT <= 0) boxState = 0;

        if (breakT > 0) {
            if (--breakT == 0) startRound();
            return;
        }
        if (toSpawn > 0) {
            if (--spawnT <= 0 && zs.size() < 8 + Math.min(10, round)) {
                spawnZombie();
                toSpawn--;
                spawnT = Math.max(14, 80 - round * 4);
            }
        } else if (zs.isEmpty()) {
            breakT = 330;
            sound(SoundEvents.BELL_BLOCK, 0.6F, 0.8F);
        }
    }

    private void startRound() {
        round++;
        toSpawn = Math.min(70, 5 + 3 * round);
        spawnT = 30; introT = 170;
        blood.clear();
        sound(SoundEvents.ENDERMAN_STARE, 0.5F, 0.7F);
    }

    private double zombieHp(int r) {
        return r <= 9 ? 100 + (r - 1) * 60 : Math.floor(560 * Math.pow(1.1, r - 9));
    }

    private void spawnZombie() {
        int pz = zoneAt(px, py);
        List<Integer> mine = new ArrayList<>(), all = new ArrayList<>();
        for (int i = 0; i < WIN.length; i++) {
            if (!zoneOpen[WIN[i][8]]) continue;
            all.add(i);
            if (WIN[i][8] == pz) mine.add(i);
        }
        List<Integer> pool = !mine.isEmpty() && rnd.nextInt(10) < 6 ? mine : all;
        int wi = pool.get(rnd.nextInt(pool.size()));
        int[] w = WIN[wi];
        double off = (rnd.nextDouble() - 0.5) * 10;
        Z z = new Z();
        z.win = wi;
        z.x = w[4] + (w[2] == 3 ? 0 : off);
        z.y = w[5] + (w[2] == 3 ? off : 0);
        z.hp = zombieHp(round);
        double sp = 0.2 + rnd.nextDouble() * 0.1;
        if (round >= 3 && rnd.nextDouble() < Math.min(0.8, (round - 2) * 0.15)) sp = 0.42 + rnd.nextDouble() * 0.08;
        if (round >= 7 && rnd.nextDouble() < Math.min(0.6, (round - 6) * 0.12)) sp = 0.62 + rnd.nextDouble() * 0.1;
        z.sp = Math.min(0.8, sp);
        zs.add(z);
    }

    private void zombies() {
        for (int i = zs.size() - 1; i >= 0; i--) {
            Z z = zs.get(i);
            if (z.dead) { zs.remove(i); continue; }
            z.anim++;
            if (z.flash > 0) z.flash--;
            if (z.cd > 0) z.cd--;
            int[] w = WIN[z.win];
            if (z.st == 0) {
                if (boards[z.win] <= 0) z.st = 1;
                else if (++z.t >= 70) {
                    z.t = 0; boards[z.win]--;
                    sound(SoundEvents.WOOD_BREAK, 0.7F + rnd.nextFloat() * 0.2F, 0.5F);
                }
            } else if (z.st == 1) {
                step(z, w[6], w[7], z.sp, false);
                if (Math.abs(z.x - w[6]) < 2 && Math.abs(z.y - w[7]) < 2) z.st = 2;
            } else {
                chase(z);
            }
        }
        // zombies in the rooms do not stand inside each other
        for (int a = 0; a < zs.size(); a++) {
            Z za = zs.get(a);
            if (za.st != 2) continue;
            for (int b = a + 1; b < zs.size(); b++) {
                Z zb = zs.get(b);
                if (zb.st != 2) continue;
                double dx = zb.x - za.x, dy = zb.y - za.y, d2 = dx * dx + dy * dy;
                if (d2 < 25 && d2 > 0.01) {
                    double d = Math.sqrt(d2), push = (5 - d) * 0.25;
                    dx = dx / d * push; dy = dy / d * push;
                    if (!blocked(zb.x + dx, zb.y + dy, 3.5)) { zb.x += dx; zb.y += dy; }
                    if (!blocked(za.x - dx, za.y - dy, 3.5)) { za.x -= dx; za.y -= dy; }
                }
            }
        }
    }

    private void chase(Z z) {
        int zz = zoneAt(z.x, z.y), pz = zoneAt(px, py);
        double tx = px, ty = py;
        if (zz != pz) {
            int di = firstDoor(zz, pz);
            if (di >= 0) {
                int[] d = DOORS[di];
                double ex = d[7] - z.x, ey = d[8] - z.y;
                if (ex * ex + ey * ey < 36) {
                    int nz = d[4] == zz ? d[5] : d[4];
                    tx = ZONE_CENTRE[nz][0]; ty = ZONE_CENTRE[nz][1];
                } else { tx = d[7]; ty = d[8]; }
            }
        }
        double dp = Math.hypot(px - z.x, py - z.y);
        if (dp > 5.5) step(z, tx, ty, z.sp, true);
        if (dp < 8 && z.cd <= 0) {
            z.cd = 45;
            hp -= 34;
            hurtFlash = 1; regen = 300;
            sound(SoundEvents.PLAYER_HURT, 0.8F, 0.6F);
        }
    }

    private void step(Z z, double tx, double ty, double sp, boolean collide) {
        double dx = tx - z.x, dy = ty - z.y, d = Math.hypot(dx, dy);
        if (d < 0.01) return;
        dx = dx / d * sp; dy = dy / d * sp;
        if (!collide) { z.x += dx; z.y += dy; return; }
        if (!blocked(z.x + dx, z.y, 3.5)) z.x += dx;
        if (!blocked(z.x, z.y + dy, 3.5)) z.y += dy;
    }

    private void pickups() {
        for (int i = picks.size() - 1; i >= 0; i--) {
            double[] p = picks.get(i);
            if (--p[3] <= 0) { picks.remove(i); continue; }
            if (dist2(p[0], p[1]) > 49) continue;
            picks.remove(i);
            pling(1.8F);
            switch ((int) p[2]) {
                case PU_MAX -> {
                    for (int s = 0; s < 2; s++) if (slotW[s] >= 0) setFull(s);
                    say("cutemod.nacht.pu.max");
                }
                case PU_INSTA -> { instaT = 1800; say("cutemod.nacht.pu.insta"); }
                case PU_DOUBLE -> { dblT = 1800; say("cutemod.nacht.pu.double"); }
                default -> {
                    for (Z z : zs) z.dead = true;
                    addPts(400);
                    sound(SoundEvents.GENERIC_EXPLODE, 0.8F, 0.6F);
                    say("cutemod.nacht.pu.nuke");
                }
            }
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.nacht.status", round, points); }

    @Override
    public Component endTitle() { return Component.translatable("cutemod.nacht.down", round); }

    @Override
    public String hintKey() { return "cutemod.hint.nacht"; }

    // ---------------------------------------------------------------- drawing
    @Override
    public void render(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0xFF0C0D0E);
        int[] floor = {0xFF4B4136, 0xFF3F4439, 0xFF42393B, 0xFF39414C};
        for (int z = 0; z < 4; z++) {
            int[] r = ZONE_RECT[z];
            rect(g, r[0], r[1], r[2], r[3], floor[z]);
            for (int x = r[0] + 14; x < r[0] + r[2]; x += 14) rect(g, x, r[1], 1, r[3], 0x22000000);
            for (int y = r[1] + 14; y < r[1] + r[3]; y += 14) rect(g, r[0], y, r[2], 1, 0x22000000);
        }
        for (int[] b : blood) rect(g, b[0], b[1], b[2], b[2], 0x99801010);
        for (int i = 0; i < DOORS.length; i++) {
            int[] d = DOORS[i];
            if (doorOpen[i]) rect(g, d[0], d[1], d[2], d[3], 0xFF2E2E2C);
            else { rect(g, d[0], d[1], d[2], d[3], 0xFF7A5A34); rect(g, d[0], d[1], d[2], 1, 0xFFA07C4C); }
        }
        for (int[] o : OBJ) if (zoneOpen[o[5]]) drawObject(g, o);
        for (int[] w : WALLS) { rect(g, w[0], w[1], w[2], w[3], 0xFF77756F); rect(g, w[0], w[1], w[2], 1, 0xFF9A988F); }
        for (int i = 0; i < WIN.length; i++) drawWindow(g, i);
        for (double[] p : picks) drawPickup(g, p);
        for (Z z : zs) drawZombie(g, z);
        drawPlayer(g);
        for (double[] a : tracers) drawTracer(g, a);
        for (int z = 0; z < 4; z++) if (!zoneOpen[z]) { int[] r = ZONE_RECT[z]; rect(g, r[0], r[1], r[2], r[3], 0xE6000000); }
        darkness(g);
        for (Z z : zs) if (!z.dead) drawEyes(g, z);
        hud(g);
    }

    private void drawObject(GuiGraphics g, int[] o) {
        int x = o[1], y = o[2];
        switch (o[0]) {
            case OBJ_WALL -> {
                rect(g, x - 8, y - 4, 16, 8, 0xFF1E1E1E);
                rect(g, x - 7, y - 3, 14, 6, 0xFF3A3A36);
                rect(g, x - 5, y - 1, 10, 2, 0xFFCFCFC8);
                rect(g, x - 6, y, 3, 2, 0xFFA88A5A);
            }
            case OBJ_BOX -> {
                rect(g, x - 7, y - 5, 14, 10, 0xFF1E1408);
                rect(g, x - 6, y - 4, 12, 8, boxState == 0 ? 0xFF8A5E2E : 0xFFB07A38);
                rect(g, x - 6, y - 4, 12, 1, 0xFFC89A5A);
                ctext(g, "?", x, y - 4, 0xFFFFE070);
                if (boxState == 1) ctext(g, WP[(t / 5) % WP.length].name(), x, y - 15, 0xFFFFFFFF);
                else if (boxState == 2) ctext(g, WP[boxW].name(), x, y - 15, 0xFF7CFFB0);
            }
            case OBJ_JUGG, OBJ_SPEED, OBJ_PAP -> {
                int c = o[0] == OBJ_JUGG ? 0xFFC0392B : o[0] == OBJ_SPEED ? 0xFF3FA34D : 0xFF3B6FD0;
                rect(g, x - 5, y - 6, 10, 12, 0xFF14141A);
                rect(g, x - 4, y - 5, 8, 10, c);
                rect(g, x - 3, y - 3, 6, 3, 0xFFFFFFFF);
                if (o[0] == OBJ_PAP) rect(g, x - 4, y + 2, 8, 2, 0xFFFFD84A);
            }
            default -> { }
        }
    }

    private void drawWindow(GuiGraphics g, int i) {
        int[] w = WIN[i];
        rect(g, w[0], w[1], w[2], w[3], 0xFF050608);
        for (int k = 0; k < boards[i]; k++) {
            if (w[2] == 3) rect(g, w[0] - 1, w[1] + 2 + k * 5, 5, 2, 0xFF8A5E2E);
            else rect(g, w[0] + 2 + k * 5, w[1] - 1, 2, 5, 0xFF8A5E2E);
        }
    }

    private void drawPickup(GuiGraphics g, double[] p) {
        if (p[3] < 300 && (t / 6) % 2 == 0) return;
        int x = (int) p[0], y = (int) p[1], type = (int) p[2];
        int[] col = {0xFF4AA3FF, 0xFFFF5A5A, 0xFFFFD84A, 0xFFFFA040};
        String[] ch = {"M", "I", "2", "N"};
        rect(g, x - 5, y - 5, 10, 10, 0xFF101010);
        rect(g, x - 4, y - 4, 8, 8, col[type]);
        ctext(g, ch[type], x, y - 4, 0xFFFFFFFF);
    }

    private void drawZombie(GuiGraphics g, Z z) {
        if (z.dead) return;
        int zx = (int) Math.round(z.x), zy = (int) Math.round(z.y);
        double a = Math.atan2(py - z.y, px - z.x);
        if (z.st == 1) a = Math.atan2(WIN[z.win][7] - z.y, WIN[z.win][6] - z.x);
        int body = z.flash > 0 ? 0xFFFFFFFF : z.sp > 0.55 ? 0xFF8A6A4A : z.sp > 0.35 ? 0xFF7A8A52 : 0xFF5E7A52;
        disc(g, zx, zy, 4, 0xFF1C1F1A);
        disc(g, zx, zy, 3, body);
        double sway = Math.sin(z.anim * 0.3) * 1.2;
        for (int side = -1; side <= 1; side += 2) {
            double ax = Math.cos(a) * (5 + sway * side) - Math.sin(a) * 2.5 * side;
            double ay = Math.sin(a) * (5 + sway * side) + Math.cos(a) * 2.5 * side;
            rect(g, zx + (int) Math.round(ax) - 1, zy + (int) Math.round(ay) - 1, 2, 2, body);
        }
    }

    private void drawEyes(GuiGraphics g, Z z) {
        double a = Math.atan2(py - z.y, px - z.x);
        for (int side = -1; side <= 1; side += 2) {
            int ex = (int) Math.round(z.x + Math.cos(a) * 1.8 - Math.sin(a) * 1.4 * side);
            int ey = (int) Math.round(z.y + Math.sin(a) * 1.8 + Math.cos(a) * 1.4 * side);
            rect(g, ex, ey, 1, 1, 0xFFFF2A2A);
        }
    }

    private void drawPlayer(GuiGraphics g) {
        int x = (int) Math.round(px), y = (int) Math.round(py);
        disc(g, x, y, 4, 0xFF101010);
        disc(g, x, y, 3, 0xFF5B6E3C);
        disc(g, x, y, 2, 0xFF4C5E32);
        double dx = Math.cos(aim), dy = Math.sin(aim);
        for (int k = 3; k <= 9; k++) rect(g, x + (int) Math.round(dx * k) - 1, y + (int) Math.round(dy * k) - 1, 2, 2, 0xFF222222);
        if (flashT > 0) disc(g, x + (int) Math.round(dx * 11), y + (int) Math.round(dy * 11), 2, 0xFFFFE070);
    }

    private void drawTracer(GuiGraphics g, double[] a) {
        double dx = a[2] - a[0], dy = a[3] - a[1], len = Math.hypot(dx, dy);
        int col = ((int) (a[4] * 60) << 24) | ((int) a[5] & 0xFFFFFF);
        for (double s = 0; s < len; s += 3) rect(g, (int) (a[0] + dx / len * s), (int) (a[1] + dy / len * s), 1, 1, col);
    }

    /** The bunker is dark: only the area around the player is lit. */
    private void darkness(GuiGraphics g) {
        for (int ty = 0; ty < H; ty += 6) {
            for (int tx = 0; tx < W; tx += 6) {
                double dx = tx + 3 - px, dy = ty + 3 - py, d = Math.sqrt(dx * dx + dy * dy);
                int al = (int) (Math.max(0, Math.min(1, (d - 38) / 85.0)) * 185);
                if (al > 3) g.fill(tx, ty, tx + 6, ty + 6, al << 24);
            }
        }
    }

    private void outlined(GuiGraphics g, String s, int x, int y, int colour) {
        text(g, s, x + 1, y + 1, 0xFF000000);
        text(g, s, x, y, colour);
    }

    private void hud(GuiGraphics g) {
        // a red edge when hurt
        float f = (float) Math.max(hurtFlash * 0.5, 1 - hp / maxHp);
        int al = (int) (Math.min(1, f) * 150);
        if (al > 4) {
            for (int i = 0; i < 4; i++) {
                int a = (al * (4 - i) / 4) << 24 | 0xA01010, in = i * 3;
                g.fill(0, in, W, in + 3, a); g.fill(0, H - in - 3, W, H - in, a);
                g.fill(in, 0, in + 3, H, a); g.fill(W - in - 3, 0, W - in, H, a);
            }
        }
        // points and the health bar
        outlined(g, String.valueOf(points), 4, H - 14, 0xFFFFE070);
        rect(g, 4, H - 4, 42, 2, 0xAA000000);
        rect(g, 4, H - 4, (int) (42 * Math.max(0, hp) / maxHp), 2, hp / maxHp > 0.4 ? 0xFF6FCF6F : 0xFFE05050);
        if (jugg) rect(g, 50, H - 5, 4, 4, 0xFFC0392B);
        if (speedCola) rect(g, 56, H - 5, 4, 4, 0xFF3FA34D);
        // the round
        g.pose().pushPose();
        g.pose().translate(4, 4, 0);
        g.pose().scale(1.6F, 1.6F, 1F);
        text(g, String.valueOf(round), 1, 1, 0xFF000000);
        text(g, String.valueOf(round), 0, 0, 0xFFC01818);
        g.pose().popPose();
        // the gun
        String ammo = mag[cur] + " / " + res[cur];
        outlined(g, ammo, W - 4 - tw(ammo), H - 14, 0xFFFFFFFF);
        String name = wname(cur);
        outlined(g, name, W - 4 - tw(name), H - 24, pap[cur] ? 0xFFFFD84A : 0xFFCFCFC8);
        if (reloadT > 0) rect(g, W - 46, H - 4, (int) (42 * (1 - reloadT / (float) reloadMax)), 2, 0xFFFFFFFF);
        if (instaT > 0) outlined(g, "INSTA " + (instaT / 60 + 1), W - 4 - tw("INSTA 30"), 4, 0xFFFF6A6A);
        if (dblT > 0) outlined(g, "2x " + (dblT / 60 + 1), W - 4 - tw("2x 30"), instaT > 0 ? 14 : 4, 0xFFFFD84A);
        // texts in the middle
        if (!prompt.isEmpty()) {
            int pw = tw(prompt) + 8;
            rect(g, (W - pw) / 2, H - 38, pw, 11, 0xAA000000);
            ctext(g, prompt, W / 2, H - 36, 0xFFFFFFFF);
        }
        if (msgT > 0) ctext(g, msg.getString(), W / 2, 24, 0xFFFFD84A);
        if (breakT > 0 && round > 0 && !over) ctext(g, Component.translatable("cutemod.nacht.next", breakT / 60 + 1).getString(), W / 2, 14, 0xFFCFCFC8);
        if (introT > 0) {
            int a = Math.min(255, introT * 4);
            g.pose().pushPose();
            g.pose().translate(W / 2F, 52, 0);
            g.pose().scale(2F, 2F, 1F);
            ctext(g, Component.translatable("cutemod.nacht.round", round).getString(), 0, 0, (a << 24) | 0xD01818);
            g.pose().popPose();
        }
        // the cross-hair
        if (mx >= 0 && my >= 0 && mx < W && my < H) {
            rect(g, mx - 5, my, 3, 1, 0xFFFFFFFF); rect(g, mx + 3, my, 3, 1, 0xFFFFFFFF);
            rect(g, mx, my - 5, 1, 3, 0xFFFFFFFF); rect(g, mx, my + 3, 1, 3, 0xFFFFFFFF);
        }
    }
}
