package dev.cutemod.client.os;

import java.util.ArrayList;
import java.util.List;

/**
 * Everything that can sit in the Dock, in the Start menu, on the desktop or in a folder has one number:
 * <ul>
 *   <li>2 .. {@link Desktop#ICONS} - 1: a system or store app (the old Dock numbers; 0 and 1 are gone: the own-game
 *       icon and the Games folder do not exist any more, every game is an app of its own now);</li>
 *   <li>{@link #GAME_BASE} + n: the game with the slot n (see {@link #SLOTS}: the number of a game never changes, even when
 *       games before it are removed, so old Docks and folders keep pointing at the same games);</li>
 *   <li>{@link #FOLDER_BASE} + n: a folder made by the player (see {@link Folders}).</li>
 * </ul>
 */
public final class Items {
    private Items() {}

    public static final int GAME_BASE = 100, FOLDER_BASE = 1000;

    public static boolean isApp(int id) { return id >= 2 && id < Desktop.ICONS; }

    /**
     * The slots of the games, in the order of the ORIGINAL game list. A removed game (maze, otherworld, forest and zombies
     * are gone) keeps its slot, nobody gets it: the numbers saved in Docks, folders and on the desktop stay right.
     * A game that is added later gets the next free slot after these.
     */
    private static final List<String> SLOTS = List.of(
            "pink", "green", "white", "blue", "orange", "purple", "yellow", "red",
            "breakout", "cubes", "pong", "bees", "horror", "maze", "otherworld", "forest",
            "craft", "zombies", "durak", "sakura", "blocks", "cakes", "cakefactory", "racer",
            "checkers", "slice", "rabbit", "dash", "echo", "lights", "targets", "rps",
            "guess", "tower", "hangman", "billiards");

    /** How many slots there are now: the old ones (some may be empty) and the games that came after them. */
    private static int slotCount() {
        int n = SLOTS.size();
        for (Library.Game g : Library.GAMES) if (!SLOTS.contains(g.id())) n++;
        return n;
    }

    public static boolean isGame(int id) { return id >= GAME_BASE && id < GAME_BASE + slotCount() && gameId(id) != null; }

    public static boolean isFolder(int id) { return id >= FOLDER_BASE; }

    public static boolean valid(int id) { return isApp(id) || isGame(id) || isFolder(id); }

    /** The game id ("pink", "craft"...) of a game number, or null (also for the number of a removed game). */
    public static String gameId(int id) {
        int s = id - GAME_BASE;
        if (s < 0 || id >= FOLDER_BASE) return null;
        if (s < SLOTS.size()) {
            String gid = SLOTS.get(s);
            for (Library.Game g : Library.GAMES) if (g.id().equals(gid)) return gid;
            return null;
        }
        int n = SLOTS.size();
        for (Library.Game g : Library.GAMES) {
            if (SLOTS.contains(g.id())) continue;
            if (n == s) return g.id();
            n++;
        }
        return null;
    }

    /** The number of a game id, or -1. */
    public static int ofGame(String gameId) {
        int s = SLOTS.indexOf(gameId);
        if (s >= 0) return Library.GAMES.stream().anyMatch(g -> g.id().equals(gameId)) ? GAME_BASE + s : -1;
        int n = SLOTS.size();
        for (Library.Game g : Library.GAMES) {
            if (SLOTS.contains(g.id())) continue;
            if (g.id().equals(gameId)) return GAME_BASE + n;
            n++;
        }
        return -1;
    }

    /** Apps first, then games: the installed things that fit into a folder. */
    public static List<Integer> pickable() {
        List<Integer> l = new ArrayList<>();
        for (int i = 2; i < Desktop.ICONS; i++) if (Library.available(i)) l.add(i);
        for (int i = 0; i < slotCount(); i++) if (isGame(GAME_BASE + i) && Library.available(GAME_BASE + i)) l.add(GAME_BASE + i);
        return l;
    }

    /** What the Start menu lists: folders, apps, games. */
    public static List<Integer> startList() {
        List<Integer> l = new ArrayList<>();
        for (int f : Folders.all()) if (Library.available(f)) l.add(f);
        l.addAll(pickable());
        return l;
    }
}
