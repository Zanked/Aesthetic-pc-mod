package dev.cutemod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.cutemod.CuteMod;
import dev.cutemod.block.PcCaseBlock;
import dev.cutemod.block.PcCaseBlockEntity;
import dev.cutemod.block.PcCaseMiniBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * The RGB light of a PC case: glowing strips and rings behind the glass (the light bar of the card, of the memory, the ring of the
 * processor cooler, the fans, the lip at the front) in the colour / mode the player chose on the build screen (see PcBuildScreen):
 * one colour, breathing, or a rainbow that runs round. Only while the PC is on. Drawn as additive glowing quads (no depth write), so
 * the glass of the case lies over them like it lies over the rest. The places are the glowing parts of the case models
 * (models/block/pc_case_*_glow_*.json), in block pixels (16 = one block) for the glass facing south; the renderer turns them with the case.
 */
public class PcCaseRgbRenderer implements BlockEntityRenderer<PcCaseBlockEntity> {
    private static final ResourceLocation WHITE = ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "textures/misc/rgb_white.png");
    /** The colours of the cases (the same eight as on the build screen). */
    private static final int[] PALETTE = {0xE8E4F5, 0xFF8FC8, 0x7FB8FF, 0x7FF0C8, 0xB48CFF, 0xFFD86B, 0xFF7080, 0x9AA0B8};

    private static ModelResourceLocation model(String name) {
        return ModelResourceLocation.standalone(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "block/" + name));
    }
    private static final ModelResourceLocation MID_COOLER = model("pc_case_mid_cooler"), MID_COOLER_GLOW = model("pc_case_mid_cooler_glow");
    private static final ModelResourceLocation MINI_COOLER = model("pc_case_mini_cooler"), MINI_COOLER_GLOW = model("pc_case_mini_cooler_glow");
    /** The models that are drawn here and not by the block state: they have to be loaded on their own (see ClientHooks). */
    public static final ModelResourceLocation[] EXTRA_MODELS = {MID_COOLER, MID_COOLER_GLOW, MINI_COOLER, MINI_COOLER_GLOW};

    /** A flat place: x0, y0, x1, y1 (pixels) and z. */
    private record Rect(float x0, float y0, float x1, float y1, float z) {}

    /** The glowing places of one kind of case. */
    private record Layout(Rect lip, Rect cpuRing, Rect fans, Rect ram, float ramStep, Rect[] gpu, Rect glass) {}

    private static final Layout MINI = new Layout(
            new Rect(3.5f, 0.6f, 12.5f, 1.5f, 11.43f),
            new Rect(4.1f, 7.3f, 8.1f, 11.3f, 10.13f),
            null,
            new Rect(8.3f, 7.4f, 8.7f, 11.4f, 8.33f), 0.55f,
            new Rect[]{null, new Rect(4.3f, 6.3f, 7.9f, 7.2f, 10.63f), new Rect(4.3f, 6.0f, 8.7f, 7.2f, 10.63f),
                    new Rect(4.3f, 5.6f, 9.5f, 7.2f, 10.63f), new Rect(4.3f, 5.2f, 10.3f, 7.2f, 10.63f)},
            new Rect(3.95f, 1.5f, 12.05f, 12.15f, 0f));        // the glass opening: the light must never leave it
    private static final Layout MID = new Layout(
            new Rect(2.82f, 0.48f, 9.924f, 1.28f, 13.75f),
            new Rect(4.892f, 8.0f, 7.112f, 10.88f, 11.46f),
            new Rect(10.22f, 4.16f, 12.736f, 10.88f, 12.28f),
            new Rect(7.408f, 7.84f, 7.704f, 11.2f, 9.985f), 0.444f,
            new Rect[]{null, new Rect(4.152f, 4.88f, 8.296f, 5.76f, 12.28f), new Rect(4.152f, 4.56f, 8.888f, 5.76f, 12.28f),
                    new Rect(4.152f, 4.24f, 9.48f, 5.76f, 12.28f), new Rect(4.152f, 3.92f, 9.924f, 5.76f, 12.28f)},
            new Rect(2.9f, 1.3f, 12.8f, 12.1f, 0f));

    public PcCaseRgbRenderer(BlockEntityRendererProvider.Context ctx) {}

    @Override
    public void render(PcCaseBlockEntity be, float partial, PoseStack pose, MultiBufferSource buffers, int light, int overlay) {
        if (be.getLevel() == null) return;
        boolean mini = be.getBlockState().getBlock() instanceof PcCaseMiniBlock;
        drawCooler(be, pose, buffers, light, overlay, mini);
        if (be.rgbMode() <= 0 || !be.isOn()) return;
        Layout lay = mini ? MINI : MID;
        float time = (be.getLevel().getGameTime() + partial) / 20f;

        pose.pushPose();
        pose.translate(0.5, 0.5, 0.5);
        pose.mulPose(Axis.YP.rotationDegrees(-be.getBlockState().getValue(PcCaseBlock.FACING).toYRot()));
        pose.translate(-0.5, -0.5, -0.5);
        VertexConsumer vc = buffers.getBuffer(RenderType.eyes(WHITE));
        PoseStack.Pose p = pose.last();

        int idx = 0;
        lip(vc, p, lay.lip(), lay.glass(), color(be, time, idx++));
        if (be.hasCooler()) ring(vc, p, lay.cpuRing(), lay.glass(), color(be, time, idx++));
        if (lay.fans() != null) {                                                    // the three fans on the front of the big case
            Rect f = lay.fans();
            float h = (f.y1() - f.y0()) / 3f;
            for (int i = 0; i < 3; i++) ring(vc, p, new Rect(f.x0(), f.y0() + i * h, f.x1(), f.y0() + (i + 1) * h, f.z()), lay.glass(), color(be, time, idx++));
        }
        for (int i = 0; i < 4; i++) {
            if (!be.hasStick(i)) continue;
            Rect r = lay.ram();
            glowQuad(vc, p, new Rect(r.x0() + i * lay.ramStep(), r.y0(), r.x1() + i * lay.ramStep(), r.y1(), r.z()), lay.glass(), color(be, time, idx + i));
        }
        int gpu = be.gpuLevel();
        if (gpu > 0 && gpu < lay.gpu().length) glowQuad(vc, p, lay.gpu()[gpu], lay.glass(), color(be, time, idx + 4));
        pose.popPose();
    }

    /** The cooler on the processor: it is there only when the player put one in (it used to be part of the processor model). */
    private static void drawCooler(PcCaseBlockEntity be, PoseStack pose, MultiBufferSource buffers, int light, int overlay, boolean mini) {
        if (!be.hasCpu() || !be.hasCooler()) return;
        Minecraft mc = Minecraft.getInstance();
        BakedModel body = mc.getModelManager().getModel(mini ? MINI_COOLER : MID_COOLER);
        BakedModel glow = mc.getModelManager().getModel(mini ? MINI_COOLER_GLOW : MID_COOLER_GLOW);
        pose.pushPose();
        pose.translate(0.5, 0.5, 0.5);
        pose.mulPose(Axis.YP.rotationDegrees(-be.getBlockState().getValue(PcCaseBlock.FACING).toYRot()));
        pose.translate(-0.5, -0.5, -0.5);
        var renderer = mc.getBlockRenderer().getModelRenderer();
        renderer.renderModel(pose.last(), buffers.getBuffer(RenderType.cutout()), null, body, 1f, 1f, 1f, light, overlay);
        if (be.isOn()) renderer.renderModel(pose.last(), buffers.getBuffer(RenderType.translucent()), null, glow, 1f, 1f, 1f, LightTexture.FULL_BRIGHT, overlay);
        pose.popPose();
    }

    /** The colour (0xRRGGBB) of the strip number {@code idx} now. */
    private static int color(PcCaseBlockEntity be, float time, int idx) {
        int mode = be.rgbMode();
        int base = PALETTE[Math.floorMod(be.rgbColor(), PALETTE.length)];
        if (mode == 1) return base;
        if (mode == 2) {
            float k = 0.35f + 0.65f * (0.5f + 0.5f * Mth.sin(time * 2.2f));
            int r = (int) (((base >> 16) & 255) * k), g = (int) (((base >> 8) & 255) * k), b = (int) ((base & 255) * k);
            return (r << 16) | (g << 8) | b;
        }
        if (mode == 4) {                                                            // a wave of light runs from part to part
            float k = (float) Math.pow(0.5 + 0.5 * Mth.sin(time * 4f - idx * 0.9f), 2) * 0.85f + 0.15f;
            return (((int) (((base >> 16) & 255) * k)) << 16) | (((int) (((base >> 8) & 255) * k)) << 8) | (int) ((base & 255) * k);
        }
        return Mth.hsvToRgb((time * 0.25f + idx * 0.11f) % 1f, 0.6f, 1f);
    }

    /**
     * The light of the lip: a thin line on the bottom edge of the name plate (so the letters stay readable) and a soft glow that
     * fades out upwards over the glass.
     */
    private static void lip(VertexConsumer vc, PoseStack.Pose p, Rect lip, Rect glass, int rgb) {
        float inset = 0.3f, h = Math.min(0.22f, (lip.y1() - lip.y0()) * 0.28f);
        float x0 = lip.x0() + inset, x1 = lip.x1() - inset, y = lip.y0() + 0.14f;
        float gx0 = Math.max(x0, glass.x0()), gx1 = Math.min(x1, glass.x1()), gz = lip.z() - 0.25f;
        poly(vc, p, gz, rgb, gx0, lip.y1(), 0.26f, gx1, lip.y1(), 0.26f, gx1, lip.y1() + 1.4f, 0f, gx0, lip.y1() + 1.4f, 0f);
        poly(vc, p, lip.z() - 0.01f, rgb, x0, y - 0.05f, 0.35f, x1, y - 0.05f, 0.35f, x1, y + h + 0.1f, 0.35f, x0, y + h + 0.1f, 0.35f);
        quad(vc, p, new Rect(x0, y, x1, y + h, lip.z()), null, rgb, 1f);
    }

    /** A ring: the four edges of the rectangle, a glow that fades out round it and a little one inside it. */
    private static void ring(VertexConsumer vc, PoseStack.Pose p, Rect r, Rect clip, int rgb) {
        float t = 0.22f;
        fade(vc, p, r, 0.7f, 0.30f, clip, rgb, true);
        fade(vc, p, new Rect(r.x0() + t, r.y0() + t, r.x1() - t, r.y1() - t, r.z()), 0.5f, 0.18f, clip, rgb, false);
        quad(vc, p, new Rect(r.x0(), r.y0(), r.x1(), r.y0() + t, r.z()), clip, rgb, 1f);
        quad(vc, p, new Rect(r.x0(), r.y1() - t, r.x1(), r.y1(), r.z()), clip, rgb, 1f);
        quad(vc, p, new Rect(r.x0(), r.y0() + t, r.x0() + t, r.y1() - t, r.z()), clip, rgb, 1f);
        quad(vc, p, new Rect(r.x1() - t, r.y0() + t, r.x1(), r.y1() - t, r.z()), clip, rgb, 1f);
    }

    /** A glowing strip with a glow that fades out round it; nothing of it leaves the glass opening. */
    private static void glowQuad(VertexConsumer vc, PoseStack.Pose p, Rect r, Rect clip, int rgb) {
        fade(vc, p, r, 0.55f, 0.30f, clip, rgb, true);
        quad(vc, p, r, clip, rgb, 1f);
    }

    /**
     * A frame of light round (outward) or inside (inward) the rectangle: it has the strength {@code a} next to the rectangle and fades
     * to nothing at {@code spread} pixels from it (the alpha is interpolated between the corners, so there is no hard edge).
     */
    private static void fade(VertexConsumer vc, PoseStack.Pose p, Rect r, float spread, float a, Rect clip, int rgb, boolean outward) {
        float sp = outward ? spread : -spread;
        float x0 = r.x0(), y0 = r.y0(), x1 = r.x1(), y1 = r.y1(), z = r.z() - 0.01f;
        float ox0 = x0 - sp, oy0 = y0 - sp, ox1 = x1 + sp, oy1 = y1 + sp;
        if (!outward && (ox0 >= ox1 || oy0 >= oy1)) return;
        // four sides
        poly(vc, p, z, rgb, c(x0, clip, true), c(y0, clip, false), a, c(x1, clip, true), c(y0, clip, false), a, c(x1, clip, true), c(oy0, clip, false), 0f, c(x0, clip, true), c(oy0, clip, false), 0f, clip);
        poly(vc, p, z, rgb, c(x0, clip, true), c(y1, clip, false), a, c(x1, clip, true), c(y1, clip, false), a, c(x1, clip, true), c(oy1, clip, false), 0f, c(x0, clip, true), c(oy1, clip, false), 0f, clip);
        poly(vc, p, z, rgb, c(x0, clip, true), c(y0, clip, false), a, c(x0, clip, true), c(y1, clip, false), a, c(ox0, clip, true), c(y1, clip, false), 0f, c(ox0, clip, true), c(y0, clip, false), 0f, clip);
        poly(vc, p, z, rgb, c(x1, clip, true), c(y0, clip, false), a, c(x1, clip, true), c(y1, clip, false), a, c(ox1, clip, true), c(y1, clip, false), 0f, c(ox1, clip, true), c(y0, clip, false), 0f, clip);
        // four corners
        float[][] cs = {{x0, y0, ox0, oy0}, {x1, y0, ox1, oy0}, {x1, y1, ox1, oy1}, {x0, y1, ox0, oy1}};
        for (float[] k : cs) {
            poly(vc, p, z, rgb, c(k[0], clip, true), c(k[1], clip, false), a, c(k[2], clip, true), c(k[1], clip, false), 0f,
                    c(k[2], clip, true), c(k[3], clip, false), 0f, c(k[0], clip, true), c(k[3], clip, false), 0f, clip);
        }
    }

    /** Clamps a coordinate into the clip rectangle (x or y). */
    private static float c(float v, Rect clip, boolean x) {
        if (clip == null) return v;
        return x ? Math.max(clip.x0(), Math.min(clip.x1(), v)) : Math.max(clip.y0(), Math.min(clip.y1(), v));
    }

    private static void poly(VertexConsumer vc, PoseStack.Pose p, float z, int rgb, float ax, float ay, float aa, float bx, float by, float ba,
                             float cx, float cy, float ca, float dx, float dy, float da, Rect clip) {
        poly(vc, p, z, rgb, ax, ay, aa, bx, by, ba, cx, cy, ca, dx, dy, da);
    }

    /** A flat quad with an own strength (alpha) at each corner, visible from both sides. Coordinates in block pixels. */
    private static void poly(VertexConsumer vc, PoseStack.Pose p, float z, int rgb, float ax, float ay, float aa, float bx, float by, float ba,
                             float cx, float cy, float ca, float dx, float dy, float da) {
        float zz = z / 16f;
        corner(vc, p, ax, ay, zz, rgb, aa, 0, 0, 1); corner(vc, p, bx, by, zz, rgb, ba, 1, 0, 1);
        corner(vc, p, cx, cy, zz, rgb, ca, 1, 1, 1); corner(vc, p, dx, dy, zz, rgb, da, 0, 1, 1);
        corner(vc, p, dx, dy, zz, rgb, da, 0, 1, -1); corner(vc, p, cx, cy, zz, rgb, ca, 1, 1, -1);
        corner(vc, p, bx, by, zz, rgb, ba, 1, 0, -1); corner(vc, p, ax, ay, zz, rgb, aa, 0, 0, -1);
    }

    /**
     * One corner of a glowing quad. The "eyes" render type adds the colour as it is (blend ONE, ONE: the alpha does nothing), so the
     * strength of the light is put INTO the colour: a corner with strength 0 is black = adds nothing, and the light fades out smoothly.
     */
    private static void corner(VertexConsumer vc, PoseStack.Pose p, float x, float y, float z, int rgb, float strength, float u, float v, float nz) {
        float k = Math.max(0f, Math.min(1f, strength));
        vertex(vc, p, x / 16f, y / 16f, z, (int) (((rgb >> 16) & 255) * k), (int) (((rgb >> 8) & 255) * k), (int) ((rgb & 255) * k), 255, u, v, nz);
    }

    /** A flat glowing rectangle, visible from both sides, cut to {@code clip} (x / y only; null = not cut). */
    private static void quad(VertexConsumer vc, PoseStack.Pose p, Rect r, Rect clip, int rgb, float a) {
        float rx0 = r.x0(), ry0 = r.y0(), rx1 = r.x1(), ry1 = r.y1();
        if (clip != null) {
            rx0 = Math.max(rx0, clip.x0()); ry0 = Math.max(ry0, clip.y0());
            rx1 = Math.min(rx1, clip.x1()); ry1 = Math.min(ry1, clip.y1());
            if (rx1 - rx0 < 0.001f || ry1 - ry0 < 0.001f) return;
        }
        poly(vc, p, r.z(), rgb, rx0, ry0, a, rx1, ry0, a, rx1, ry1, a, rx0, ry1, a);
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose p, float x, float y, float z, int r, int g, int b, int a, float u, float v, float nz) {
        vc.addVertex(p, x, y, z).setColor(r, g, b, a).setUv(u, v).setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT).setNormal(p, 0f, 0f, nz);
    }
}
