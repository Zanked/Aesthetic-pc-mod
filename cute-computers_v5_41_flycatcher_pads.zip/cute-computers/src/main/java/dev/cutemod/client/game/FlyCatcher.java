package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Fly Catcher: a frog sits on a lily pad in the middle of a night swamp. Insects buzz around it. Aim with the mouse and
 * click to shoot the tongue: it flies to the cursor (but no further than the dashed ring) and sticks to the first
 * insect on the way. Flies, bluebottles, butterflies and dragonflies give points, a firefly also gives a bonus for one of
 * the four jars at the top (slow time, a long tongue, double points, a thunderclap). A wasp costs 200 points.
 * Catches in a row build a combo (the meter on the left): a miss or a wasp breaks it.
 * <p>
 * Five parts of five levels. Reach the goal score before the time bar runs out; a level that is lost costs a heart and is
 * replayed. The fifth level of every part is a long final level: a big boss bug joins halfway, and it must be hit with the
 * tongue several times (it cannot be eaten) as well as the goal reached. A new part gives a heart back and a new swamp:
 * 1 night, 2 crimson, 3 frost, 4 toxic, 5 starry.
 * <p>
 * The frog can hop between five lily pads (right click on a pad, or the arrow keys). From part 2 on the pads sink: one
 * shakes, goes under for a few seconds and comes back, and a frog that is still on it falls into the water. Every part has
 * its own tricks: 1 bumblebees (slow to pull in, they give a jar), 2 wasp swarms and sinking pads, 3 frozen bugs and
 * hornets (-400), 4 toxic flies (they make the frog dizzy: the tongue goes the wrong way), 5 falling stars and everything at once.
 */
public class FlyCatcher extends MiniGame {
    private static final int PARTS = 5, PER = 5, LEVELS = PARTS * PER, LIVES = 3, NORMAL_TICKS = 3300, FINAL_TICKS = 7200, COMBO_TIME = 170;
    private static final float RANGE = 66F, OUT = 7F, IN = 6F;
    private static final int FLY = 0, BLUEBOTTLE = 1, BUTTERFLY = 2, DRAGONFLY = 3, FIREFLY = 4, WASP = 5, BOSS = 6, HORNET = 7, BUMBLE = 8, TOXIC = 9, STAR = 10;
    private static final int[] VALUE = {50, 100, 150, 250, 200, -200, 0, -400, 300, -100, 500};
    private static final float[] SPEED = {0.55F, 0.45F, 0.3F, 0.85F, 0.25F, 0.65F, 0.35F, 0.95F, 0.3F, 0.5F, 1.5F};
    private static final float[] RAD = {3F, 3.5F, 4.5F, 4F, 3.5F, 4F, 8F, 5F, 5.5F, 3.5F, 3.5F};
    private static final int J_SLOW = 0, J_LONG = 1, J_DOUBLE = 2, J_THUNDER = 3;
    private static final int[] JAR_COL = {0xFF6FB8FF, 0xFF7ED957, 0xFFFFD84A, 0xFFB57BFF};
    private static final int S_PLAY = 0, S_CLEAR = 1, S_FAIL = 2;
    // the five swamps: night, crimson, frost, toxic, starry
    private static final int[] BG_TOP = {0xFF0A1442, 0xFF2C0610, 0xFF0A2A4A, 0xFF16062A, 0xFF05050F};
    private static final int[] BG_BOT = {0xFF123478, 0xFF640F26, 0xFF1E5A8A, 0xFF3A1262, 0xFF1C1646};
    private static final int[] PAD = {0xFF3FB44A, 0xFF9A1E32, 0xFF7ED0D0, 0xFF5AC03A, 0xFFE0B83A};
    private static final int[] PAD2 = {0xFF8ED04A, 0xFFC8344A, 0xFFB8F0F0, 0xFFB8E85A, 0xFFFFE27A};
    private static final int[] STUMP = {0xFF8A6A2E, 0xFF5A1A22, 0xFF8AA8C0, 0xFF5A3A7A, 0xFF6A5A8A};
    private static final int[] SPECK = {0xFF3FB04D, 0xFFC03048, 0xFFBEE8FF, 0xFF8AE04A, 0xFFFFE27A};
    private static final int[] PETAL = {0xFFFFFFFF, 0xFFFF6A7A, 0xFFE8FAFF, 0xFFE0A0FF, 0xFFFFF4C0};
    private static final int[] BOSS_COL = {0xFFFFD02A, 0xFFD0283A, 0xFF7AD8FF, 0xFFA0E04A, 0xFFFFE27A};
    private static final int[][] PADS = {{110, 116}, {34, 104}, {186, 104}, {52, 70}, {168, 70}};
    private static final int WARN = 100, UNDER = 260, RISE = 40;
    private static final int JAR_X = 72, JAR_Y = 2, JAR_W = 16, JAR_H = 17, JAR_STEP = 19;

    private static final class Bug {
        final int kind;
        float x, y, a, turn, boost;
        int age, life, caught, hp, maxHp, hit, frozen;
        float spd;
        boolean straight;
        boolean dead;

        Bug(int kind) { this.kind = kind; }
    }

    private static final class Fx {
        float x, y, vx, vy;
        int life, max, col, kind;
        String txt;
    }

    private final List<Bug> bugs = new ArrayList<>();
    private final List<Fx> fx = new ArrayList<>();
    private final int[] jars = new int[4];
    private int level, lives, state, stateT, scoreBase, levelPts, timeLeft, time;
    private int combo, comboT, slowT, longT, doubleT, hurtT, flash, bannerT, gulpT;
    private int tState, totalTime, bannerKind;
    private boolean bossSpawned, bossDead, tHitBoss;
    private final int[] padT = new int[PADS.length];
    private int frogX = PADS[0][0], frogY = PADS[0][1], frogPad, hopT, hopMax, hopFx, hopFy, sinkCool, swarmCool, dizzyT;
    private String bannerMsg = "";
    private float tLen, tGoal, tAng;
    private Bug tCatch;
    private boolean won;

    // ------------------------------------------------------------------ start

    @Override
    public void reset() {
        score = 0; over = false; won = false; lives = LIVES; scoreBase = 0; time = 0;
        java.util.Arrays.fill(jars, 0);
        startLevel(0);
    }

    private void startLevel(int n) {
        level = n;
        state = S_PLAY; stateT = 0;
        totalTime = isFinal() ? FINAL_TICKS : NORMAL_TICKS;
        bossSpawned = false; bossDead = false; tHitBoss = false;
        levelPts = 0; timeLeft = totalTime; combo = 0; comboT = 0;
        slowT = 0; longT = 0; doubleT = 0; hurtT = 0; flash = 0; gulpT = 0;
        tState = 0; tLen = 0; tCatch = null;
        java.util.Arrays.fill(padT, 0);
        frogPad = 0; frogX = PADS[0][0]; frogY = PADS[0][1]; hopT = 0; dizzyT = 0;
        sinkCool = 240 + rnd.nextInt(120); swarmCool = 500 + rnd.nextInt(400);
        bannerT = 150;
        if (n % PER == 0) bannerMsg = Component.translatable("cutemod.frog.part." + part()).getString();
        else if (isFinal()) bannerMsg = Component.translatable("cutemod.frog.finalstart", goal()).getString();
        else bannerMsg = Component.translatable("cutemod.frog.start", goal()).getString();
        if (n % PER == 0) bannerT = 190;
        bugs.clear(); fx.clear();
        for (int i = 0; i < target() - 2; i++) spawn(true);
        score = scoreBase;
    }

    private int part() { return level / PER; }

    private boolean isFinal() { return level % PER == PER - 1; }

    /** The goal: it grows with every level; the final level of a part asks for more than twice as much. */
    private int goal() {
        int g = 700 + 380 * level;
        return isFinal() ? Math.round(g * 2.2F / 50F) * 50 : g;
    }

    private int target() { return Math.min(14, 5 + level / 2) + (bossSpawned && !bossDead ? 2 : 0); }

    private float range() { return RANGE * (longT > 0 ? 1.4F : 1F); }

    // ------------------------------------------------------------------ insects

    private void spawn(boolean inside) {
        float r = rnd.nextFloat();
        int p = part();
        float wasp = Math.min(0.35F, 0.08F + 0.012F * level), c = wasp;
        int kind;
        if (r < c) kind = p >= 2 && rnd.nextFloat() < 0.4F ? HORNET : WASP;
        else if (r < (c += 0.04F)) kind = FIREFLY;
        else if (r < (c += p == 0 ? (level >= 2 ? 0.05F : 0F) : 0.06F)) kind = BUMBLE;
        else if (p == 3 && r < (c += 0.10F)) kind = TOXIC;
        else if (p == 4 && r < (c += 0.03F)) kind = STAR;
        else if (level >= 1 && r < (c += 0.08F)) kind = DRAGONFLY;
        else if (r < (c += 0.12F)) kind = BUTTERFLY;
        else if (r < (c += 0.25F)) kind = BLUEBOTTLE;
        else kind = FLY;
        if (inside && kind == STAR) kind = FLY;
        Bug b = new Bug(kind);
        if (inside) {
            b.x = 10 + rnd.nextInt(W - 20);
            b.y = 14 + rnd.nextInt(H - 40);
            b.a = rnd.nextFloat() * 6.2832F;
        } else {
            switch (rnd.nextInt(3)) {
                case 0 -> { b.x = -8; b.y = 10 + rnd.nextInt(H - 40); }
                case 1 -> { b.x = W + 8; b.y = 10 + rnd.nextInt(H - 40); }
                default -> { b.x = 10 + rnd.nextInt(W - 20); b.y = -8; }
            }
            b.a = (float) Math.atan2(30 + rnd.nextInt(60) - b.y, 20 + rnd.nextInt(W - 40) - b.x);
        }
        b.life = 480 + rnd.nextInt(420);
        if (kind == STAR) {                                           // a falling star: straight and fast
            b.x = 10 + rnd.nextInt(W - 20); b.y = -8;
            b.a = (rnd.nextBoolean() ? 1F : 2.1F) + rnd.nextFloat() * 0.3F;
            b.straight = true; b.spd = 1.5F; b.life = 1;
        }
        bugs.add(b);
    }

    /** A line of wasps that flies straight across the screen. */
    private void spawnSwarm() {
        boolean left = rnd.nextBoolean();
        int y0 = 18 + rnd.nextInt(56), n = 3 + (part() >= 3 ? 1 : 0);
        for (int i = 0; i < n; i++) {
            Bug b = new Bug(part() >= 2 && i == 0 ? HORNET : WASP);
            b.x = left ? -8 - i * 13 : W + 8 + i * 13;
            b.y = y0 + (i % 2) * 7;
            b.a = left ? 0F : 3.1416F;
            b.straight = true; b.spd = 0.85F; b.life = 1;
            bugs.add(b);
        }
        pts(left ? 14 : W - 14, y0 - 6, "!", 0xFFFF5A5A);
        sound(SoundEvents.BEE_STING, 0.6F, 0.6F);
    }

    private void spawnBoss() {
        Bug b = new Bug(BOSS);
        b.x = W / 2F; b.y = -10; b.a = 1.5708F;
        b.maxHp = b.hp = 4 + 2 * part();
        b.life = Integer.MAX_VALUE;
        bugs.add(b);
        bossSpawned = true;
        bannerMsg = Component.translatable("cutemod.frog.boss").getString();
        bannerT = 140;
        sound(SoundEvents.BEE_STING, 0.5F, 1F);
    }

    private static float wrap(float a) {
        while (a > Math.PI) a -= 6.2832F;
        while (a < -Math.PI) a += 6.2832F;
        return a;
    }

    private void steer(Bug b, float tx, float ty, float k) {
        float want = (float) Math.atan2(ty - b.y, tx - b.x);
        b.a += wrap(want - b.a) * k;
    }

    private void moveBug(Bug b) {
        b.age++;
        if (b.frozen > 0) { b.frozen--; return; }
        if (b.straight) {
            float sl = slowT > 0 ? 0.4F : 1F, v = (b.spd > 0 ? b.spd : SPEED[b.kind]) * sl;
            b.x += (float) Math.cos(b.a) * v;
            b.y += (float) Math.sin(b.a) * v;
            if (b.x < -40 || b.x > W + 40 || b.y < -30 || b.y > H + 30) b.dead = true;
            return;
        }
        float slow = slowT > 0 ? 0.4F : 1F;
        float sp = SPEED[b.kind] * (1F + (b.kind == BOSS ? 0.015F : 0.03F) * level) * slow;
        if (b.hit > 0) b.hit--;
        if (b.age % (b.kind == DRAGONFLY ? 70 : 45) == 0) b.turn = (rnd.nextFloat() - 0.5F) * (b.kind == WASP || b.kind == HORNET ? 0.1F : b.kind == BUMBLE ? 0.06F : 0.16F);
        if (b.kind == DRAGONFLY && b.age % 70 == 0) { b.boost = 1.8F; b.a += (rnd.nextFloat() - 0.5F) * 2F; }
        if (b.boost > 0) { sp *= 1F + b.boost; b.boost = Math.max(0F, b.boost - 0.03F); }
        b.a += b.turn;
        if (b.kind == BUTTERFLY) b.a += (float) Math.sin(b.age * 0.14F) * 0.05F;
        if (b.kind == BOSS) {
            if (b.age < 60 || b.y > 78 || b.y < 20 || b.x < 34 || b.x > W - 34) steer(b, W / 2F + (float) Math.sin(b.age * 0.02F) * 50F, 46, 0.05F);
        } else if (b.age > b.life) steer(b, b.x < W / 2F ? -40 : W + 40, b.y < H / 2F ? -40 : H + 40, 0.02F);
        else if (b.x < 6 || b.x > W - 6 || b.y < 8 || b.y > H - 20) steer(b, W / 2F, H / 2F - 10, 0.06F);
        b.x += (float) Math.cos(b.a) * sp;
        b.y += (float) Math.sin(b.a) * sp;
        if (b.kind != BOSS && b.age > b.life && (b.x < -12 || b.x > W + 12 || b.y < -12 || b.y > H + 12)) b.dead = true;
        if (b.kind != BOSS && b.age > b.life + 900) b.dead = true;
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean click(int x, int y, int button) {
        if (over) return false;
        if (button == 1) {                                          // right click: hop to the pad under the cursor
            int best = -1;
            float bd = 24F * 24F;
            for (int i = 0; i < PADS.length; i++) {
                float dx = PADS[i][0] - x, dy = PADS[i][1] + 3 - y, d = dx * dx + dy * dy * 2F;
                if (d < bd) { bd = d; best = i; }
            }
            if (best >= 0) hopTo(best, 18);
            return true;
        }
        for (int i = 0; i < 4; i++) {
            if (in(x, y, JAR_X + i * JAR_STEP, JAR_Y, JAR_W, JAR_H)) { useJar(i); return true; }
        }
        shoot();
        return true;
    }

    @Override
    public boolean key(int keyCode) {
        if (over) return false;
        if (keyCode >= 49 && keyCode <= 52) { useJar(keyCode - 49); return true; }
        if (keyCode == KEY_SPACE) { shoot(); return true; }
        if (keyCode == KEY_LEFT) { hopDir(-1, 0); return true; }
        if (keyCode == KEY_RIGHT) { hopDir(1, 0); return true; }
        if (keyCode == KEY_UP) { hopDir(0, -1); return true; }
        if (keyCode == KEY_DOWN) { hopDir(0, 1); return true; }
        return false;
    }

    private boolean padUnder(int i) { return padT[i] > WARN && padT[i] <= WARN + UNDER; }

    private boolean padSolid(int i) { return padT[i] <= WARN; }

    private void hopDir(int dx, int dy) {
        int best = -1;
        float bd = 1e9F;
        for (int i = 0; i < PADS.length; i++) {
            if (i == frogPad) continue;
            float ex = PADS[i][0] - frogX, ey = PADS[i][1] - frogY, d = (float) Math.sqrt(ex * ex + ey * ey);
            if (ex * dx + ey * dy < d * 0.3F) continue;
            if (d < bd) { bd = d; best = i; }
        }
        if (best >= 0) hopTo(best, 18);
    }

    private void hopTo(int pad, int ticks) {
        if (state != S_PLAY || tState != 0 || hopT > 0 || pad == frogPad || !padSolid(pad)) return;
        hopFx = frogX; hopFy = frogY; hopT = hopMax = ticks; frogPad = pad;
        sound(SoundEvents.SLIME_SQUISH_SMALL, 1.3F, 0.7F);
    }

    private void tickHop() {
        if (hopT <= 0) return;
        hopT--;
        float t = 1F - hopT / (float) hopMax;
        frogX = Math.round(hopFx + (PADS[frogPad][0] - hopFx) * t);
        frogY = Math.round(hopFy + (PADS[frogPad][1] - hopFy) * t - (float) Math.sin(t * Math.PI) * 16F);
        if (hopT == 0) { frogX = PADS[frogPad][0]; frogY = PADS[frogPad][1]; }
    }

    /** The pad under the frog went under: it falls in, loses points and jumps to the nearest pad that holds. */
    private void fall() {
        levelPts -= 300;
        combo = 0; comboT = 0; hurtT = 60;
        pts(frogX, frogY - 16, "-300", 0xFFFF5A5A);
        puff(frogX, frogY + 4, 0xFF8AD0FF, 10);
        sound(SoundEvents.FROG_HURT, 0.8F, 1F);
        sound(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 0.8F, 1F);
        if (tCatch != null) tCatch.caught = 0;
        tCatch = null; tState = 0; tLen = 0; tHitBoss = false;
        int best = -1;
        float bd = 1e9F;
        for (int i = 0; i < PADS.length; i++) {
            if (i == frogPad || padT[i] != 0) continue;
            float ex = PADS[i][0] - frogX, ey = PADS[i][1] - frogY, d = ex * ex + ey * ey;
            if (d < bd) { bd = d; best = i; }
        }
        if (best < 0) best = frogPad == 0 ? 1 : 0;
        hopFx = frogX; hopFy = frogY; hopT = hopMax = 14; frogPad = best;
        sync();
    }

    private void tickPads() {
        for (int i = 0; i < PADS.length; i++) if (padT[i] > 0 && ++padT[i] > WARN + UNDER + RISE) padT[i] = 0;
        if (padUnder(frogPad) && hopT == 0) fall();
        if (part() < 1) return;
        if (--sinkCool > 0) return;
        sinkCool = Math.max(150, 380 - 45 * part()) + rnd.nextInt(90);
        int sunk = 0;
        for (int t : padT) if (t > 0) sunk++;
        if (sunk >= (part() >= 3 ? 3 : 2)) return;
        int pick = padT[frogPad] == 0 && rnd.nextFloat() < 0.55F ? frogPad : rnd.nextInt(PADS.length);
        if (padT[pick] != 0) return;
        padT[pick] = 1;
        if (pick == frogPad) pts(frogX, frogY - 24, Component.translatable("cutemod.frog.jump").getString(), 0xFFFFE27A);
    }

    private void shoot() {
        if (state != S_PLAY || tState != 0 || hopT > 0) return;
        tAng = (float) Math.atan2(my - frogY, mx - frogX);
        if (dizzyT > 0) tAng += 3.1416F;                              // a dizzy frog shoots the wrong way
        float ox = frogX + (float) Math.cos(tAng) * 7F, oy = frogY - 1 + (float) Math.sin(tAng) * 7F;
        float d = (float) Math.sqrt((mx - ox) * (mx - ox) + (my - oy) * (my - oy));
        tGoal = Math.max(12F, Math.min(range(), d + 3F));
        tLen = 0; tState = 1; tCatch = null;
        sound(SoundEvents.FROG_TONGUE, 1F + rnd.nextFloat() * 0.2F, 0.8F);
    }

    private void useJar(int i) {
        if (state != S_PLAY || jars[i] <= 0) return;
        jars[i]--;
        switch (i) {
            case J_SLOW -> { slowT = 480; sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 1F); }
            case J_LONG -> { longT = 600; sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.1F, 1F); }
            case J_DOUBLE -> { doubleT = 600; sound(SoundEvents.PLAYER_LEVELUP, 1.4F, 0.6F); }
            default -> thunder();
        }
    }

    private void thunder() {
        flash = 16;
        sound(SoundEvents.LIGHTNING_BOLT_THUNDER, 1.4F, 0.5F);
        int mult = doubleT > 0 ? 2 : 1;
        for (Bug b : bugs) {
            if (b.dead || b.caught > 0) continue;
            float dx = b.x - frogX, dy = b.y - frogY;
            if (dx * dx + dy * dy > range() * range()) continue;
            if (b.kind == BOSS) { b.hit = 14; b.hp = Math.max(1, b.hp - 1); puff(b.x, b.y, 0xFFFFF0A0, 6); continue; }
            b.dead = true;
            puff(b.x, b.y, 0xFFFFF0A0, 6);
            if (VALUE[b.kind] < 0) continue;
            int v = VALUE[b.kind] * mult;
            levelPts += v;
            pts(b.x, b.y - 4, "+" + v, 0xFFFFFFFF);
            if (b.kind == FIREFLY || b.kind == BUMBLE || b.kind == STAR) gainJar(b.x, b.y);
        }
        sync();
        checkGoal();
    }

    private void hitBoss(Bug b) {
        b.hp--; b.hit = 14;
        int v = 300 * (doubleT > 0 ? 2 : 1);
        levelPts += v;
        pts(b.x, b.y - 10, "+" + v, 0xFFFFB84A);
        puff(b.x, b.y, 0xFFFFE27A, 8);
        gainJar(b.x, b.y);
        sound(SoundEvents.FROG_HURT, 0.6F, 1F);
        if (b.hp <= 0) {
            b.dead = true; bossDead = true;
            levelPts += 1000;
            pts(b.x, b.y - 18, "+1000", 0xFFFFE27A);
            for (int i = 0; i < 4; i++) puff(b.x, b.y, BOSS_COL[part()], 8);
            flash = 20;
            sound(SoundEvents.PLAYER_LEVELUP, 0.7F, 1F);
            sound(SoundEvents.LIGHTNING_BOLT_THUNDER, 1F, 0.6F);
        }
        sync();
        checkGoal();
    }

    private void gainJar(float x, float y) {
        int t = rnd.nextInt(4);
        jars[t] = Math.min(3, jars[t] + 1);
        puff(x, y, JAR_COL[t], 8);
        sound(SoundEvents.NOTE_BLOCK_CHIME, 1.6F, 0.7F);
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        time++;
        if (bannerT > 0) bannerT--;
        if (hurtT > 0) hurtT--;
        if (gulpT > 0) gulpT--;
        if (flash > 0) flash--;
        tickFx();
        if (state == S_CLEAR) {
            if (--stateT <= 0) {
                if (level + 1 >= LEVELS) { won = true; over = true; }
                else {
                    if (isFinal()) lives = Math.min(LIVES, lives + 1);     // a new part gives a heart back
                    startLevel(level + 1);
                }
            }
            return;
        }
        if (state == S_FAIL) {
            if (--stateT <= 0) {
                if (lives <= 0) { won = false; over = true; }
                else startLevel(level);
            }
            return;
        }
        if (slowT > 0) slowT--;
        if (dizzyT > 0) dizzyT--;
        tickHop();
        tickPads();
        if (part() >= 1 && --swarmCool <= 0) { spawnSwarm(); swarmCool = Math.max(380, 900 - 90 * part()) + rnd.nextInt(300); }
        if (part() == 2 || part() == 4) {                                    // frost: now and then a bug freezes in the air
            if (time % (part() == 2 ? 150 : 260) == 0 && !bugs.isEmpty()) {
                Bug f = bugs.get(rnd.nextInt(bugs.size()));
                if (f.kind != BOSS && f.caught == 0 && !f.straight && f.frozen == 0) f.frozen = 220;
            }
        }
        if (longT > 0) longT--;
        if (doubleT > 0) doubleT--;
        if (comboT > 0 && --comboT == 0) combo = 0;
        for (Bug b : bugs) if (b.caught == 0) moveBug(b);
        tickTongue();
        bugs.removeIf(b -> b.dead);
        if (isFinal() && !bossSpawned && levelPts >= goal() / 2) spawnBoss();
        if (bugs.size() < target() && rnd.nextInt(26) == 0) spawn(false);
        if (--timeLeft <= 0) timeUp();
    }

    private void tickTongue() {
        if (tState == 0) return;
        float ox = frogX + (float) Math.cos(tAng) * 7F, oy = frogY - 1 + (float) Math.sin(tAng) * 7F;
        if (tState == 1) {
            float prev = tLen;
            tLen = Math.min(tGoal, tLen + OUT);
            for (float l = prev; l <= tLen + 0.01F && tCatch == null && !tHitBoss; l += 2F) {
                float tx = ox + (float) Math.cos(tAng) * l, ty = oy + (float) Math.sin(tAng) * l;
                for (Bug b : bugs) {
                    if (b.dead || b.caught > 0) continue;
                    float dx = b.x - tx, dy = b.y - ty, r = RAD[b.kind] + 2.5F;
                    if (dx * dx + dy * dy <= r * r) {
                        tLen = l;
                        if (b.kind == BOSS) { hitBoss(b); tHitBoss = true; break; }
                        tCatch = b; b.caught = 1;
                        break;
                    }
                }
            }
            if (tHitBoss) tState = 2;
            else if (tCatch != null) {
                sound(VALUE[tCatch.kind] < 0 ? SoundEvents.BEE_STING : SoundEvents.SLIME_SQUISH_SMALL, 1.2F, 0.8F);
                tState = 2;
            } else if (tLen >= tGoal) tState = 2;
        } else {
            tLen -= IN * (tCatch != null && tCatch.kind == BUMBLE ? 0.5F : 1F);     // a bumblebee is heavy
            if (tCatch != null) {
                tCatch.x = ox + (float) Math.cos(tAng) * tLen;
                tCatch.y = oy + (float) Math.sin(tAng) * tLen;
            }
            if (tLen <= 4F) deliver();
        }
    }

    private void deliver() {
        tState = 0; tLen = 0;
        Bug b = tCatch;
        tCatch = null;
        if (b == null && tHitBoss) { tHitBoss = false; return; }          // a hit on the boss is not a miss
        if (b == null) { combo = 0; comboT = 0; return; }       // a miss breaks the combo
        b.dead = true;
        float px = frogX, py = frogY - 16;
        if (VALUE[b.kind] < 0) {
            levelPts += VALUE[b.kind];
            combo = 0; comboT = 0; hurtT = 40;
            if (b.kind == TOXIC) dizzyT = 260;
            pts(px, py, "" + VALUE[b.kind], 0xFFFF5A5A);
            sound(SoundEvents.FROG_HURT, 1F, 0.9F);
        } else {
            combo++; comboT = COMBO_TIME; gulpT = 12;
            int v = VALUE[b.kind] * Math.min(5, 1 + combo / 3) * (doubleT > 0 ? 2 : 1);
            if (b.frozen > 0) v = v * 3 / 2;                          // a frozen bug is worth half as much again
            levelPts += v;
            pts(px, py, "+" + v, b.kind == FIREFLY ? 0xFFE8FF7A : b.frozen > 0 ? 0xFFBEEBFF : 0xFFFFFFFF);
            puff(px, py + 6, 0xFFFFE27A, 3);
            sound(SoundEvents.FROG_EAT, 1F, 0.9F);
            if (b.kind == FIREFLY || b.kind == BUMBLE || b.kind == STAR) gainJar(px, py);
        }
        sync();
        checkGoal();
    }

    private void sync() { score = Math.max(0, scoreBase + levelPts); }

    private void checkGoal() {
        if (state != S_PLAY || levelPts < goal()) return;
        if (isFinal()) {
            if (!bossSpawned) spawnBoss();
            if (!bossDead) return;
        }
        int bonus = timeLeft / 60 * 10;
        scoreBase += Math.max(0, levelPts) + bonus;
        score = scoreBase;
        state = S_CLEAR; stateT = isFinal() ? 260 : 150;
        tState = 0; tCatch = null; tHitBoss = false;
        bannerMsg = level + 1 >= LEVELS ? Component.translatable("cutemod.frog.won").getString()
                : Component.translatable(isFinal() ? "cutemod.frog.partclear" : "cutemod.frog.clear").getString();
        pts(W / 2F, 52, "+" + bonus, 0xFFFFD866);
        sound(SoundEvents.PLAYER_LEVELUP, 1.1F, 0.8F);
    }

    private void timeUp() {
        lives--;
        score = scoreBase;
        state = S_FAIL; stateT = 120;
        tState = 0; tCatch = null; tHitBoss = false;
        bannerMsg = Component.translatable("cutemod.frog.fail").getString();
        sound(SoundEvents.VILLAGER_NO, 1F, 0.8F);
    }

    // ------------------------------------------------------------------ effects

    private void pts(float x, float y, String s, int col) {
        Fx f = new Fx();
        f.kind = 3; f.x = x; f.y = y; f.vy = -0.4F; f.life = f.max = 55; f.txt = s; f.col = col;
        fx.add(f);
    }

    private void puff(float x, float y, int col, int n) {
        for (int i = 0; i < n; i++) {
            Fx f = new Fx();
            f.kind = 1; f.x = x; f.y = y; f.col = col;
            f.vx = (rnd.nextFloat() - 0.5F) * 2.2F; f.vy = (rnd.nextFloat() - 0.5F) * 2.2F;
            f.life = f.max = 16 + rnd.nextInt(10);
            fx.add(f);
        }
    }

    private void tickFx() {
        for (Fx f : fx) {
            f.life--;
            f.x += f.vx; f.y += f.vy;
            if (f.kind == 1) { f.vx *= 0.93F; f.vy *= 0.93F; }
        }
        fx.removeIf(f -> f.life <= 0);
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, BG_TOP[part()], BG_BOT[part()]);
        scenery(g);
        ringOfRange(g);
        for (Bug b : bugs) {
            drawBug(g, b);
            if (b.frozen > 0) {                                                  // a frozen bug sits in a little ice cube
                int x = Math.round(b.x), y = Math.round(b.y), r = Math.round(RAD[b.kind]) + 2;
                g.fill(x - r, y - r, x + r + 1, y + r + 1, Gfx.alpha(0xFFBEEBFF, b.frozen < 40 && b.frozen % 6 < 3 ? 40 : 100));
                Gfx.outline(g, x - r, y - r, 2 * r + 1, 2 * r + 1, 0xCCFFFFFF);
                g.fill(x - r + 1, y - r + 1, x - r + 3, y - r + 2, 0xFFFFFFFF);
            }
        }
        drawFrog(g);
        drawTongue(g);
        for (Fx f : fx) drawFx(g, f);
        if (flash > 0) g.fill(0, 0, W, H, Gfx.alpha(0xFFFFFFFF, flash * 9));
        if (slowT > 0) g.fill(0, 0, W, H, Gfx.alpha(0xFF3A7AFF, 22));
        Gfx.vignette(g, W, H, 40);
        drawCursor(g);
        hud(g);
    }

    private void scenery(GuiGraphics g) {
        for (int i = 0; i < 70; i++) {                                    // clover specks on the water
            int x = (int) (Gfx.hash(i, 1) * W), y = (int) (Gfx.hash(i, 2) * H), c = Gfx.alpha(SPECK[part()], Gfx.hash(i, 3) > 0.5F ? 100 : 64);
            if (part() == 4 && i % 3 == 0) { g.fill(x, y, x + 1, y + 1, Gfx.alpha(0xFFFFFFFF, 60 + (int) (60 * Math.sin(time * 0.05F + i)))); continue; }
            g.fill(x, y - 1, x + 1, y + 2, c);
            g.fill(x - 1, y, x + 2, y + 1, c);
        }
        for (int i = 0; i < 5; i++) Gfx.ellipse(g, (int) (Gfx.hash(i, 4) * W), (int) (Gfx.hash(i, 5) * H), 16, 5, 0x1A000000);
        int pt = part(), hole = Gfx.darker(BG_BOT[pt], 0.4F);
        float[] dm = new float[3];                                    // the pads at the top (only scenery) bob under the water in the later parts
        for (int i = 0; i < 3; i++) dm[i] = pt == 0 ? 1F : Math.max(0F, Math.min(1F, 1.4F * (float) Math.cos(time * 0.007F + i * 2.1F) + 0.7F));
        if (dm[0] > 0.2F) pad(g, 34, 36, Math.round(17 * dm[0]), PAD[pt], BG_BOT[pt]); else ripple(g, 34, 36, 17);
        if (dm[1] > 0.2F) pad(g, 186, 34, Math.round(17 * dm[1]), Gfx.darker(PAD[pt], 0.08F), BG_BOT[pt]); else ripple(g, 186, 34, 17);
        if (dm[2] > 0.2F) spotted(g, 112, 27, Math.round(15 * dm[2]), PAD2[pt], BG_BOT[pt], hole); else ripple(g, 112, 27, 15);
        atmosphere(g, pt);
        flower(g, 66, 40, PETAL[pt], pt == 1 ? 0xFF2A0610 : 0xFFA8C8FF);
        flower(g, 154, 124, PETAL[pt], pt == 1 ? 0xFF2A0610 : 0xFFA8C8FF);
        flower(g, 196, 62, PETAL[pt], 0xFFFFD84A);
        leaves(g, 70, 108, -1, PAD[pt]);
        leaves(g, 150, 108, 1, PAD[pt]);
        for (int i = 0; i < PADS.length; i++) hopPad(g, i, pt);
    }

    /** Rings on the water where a pad is under. */
    private void ripple(GuiGraphics g, int cx, int cy, int r) {
        for (int k = 0; k < 2; k++) {
            float ph = ((time + k * 30) % 60) / 60F;
            int rx = Math.round(4 + r * ph), ry = Math.max(1, Math.round((4 + r * ph) * 0.55F));
            int col = Gfx.alpha(0xFFBEE8FF, Math.round(90 * (1F - ph)));
            for (int i = 0; i < 24; i++) {
                double a = i * Math.PI / 12;
                int x = cx + (int) Math.round(Math.cos(a) * rx), y = cy + 3 + (int) Math.round(Math.sin(a) * ry);
                if (x >= 0 && y >= 0 && x < W && y < H) g.fill(x, y, x + 1, y + 1, col);
            }
        }
    }

    private void hopPad(GuiGraphics g, int i, int pt) {
        int cx = PADS[i][0], cy = PADS[i][1], t = padT[i];
        boolean warn = t > 0 && t <= WARN;
        float sc = 1F;
        if (t > WARN && t <= WARN + UNDER) sc = 0F;
        else if (t > WARN + UNDER) sc = (t - WARN - UNDER) / (float) RISE;
        if (sc < 0.15F) {
            ripple(g, cx, cy, 14);
            if (t > WARN && time % 24 == i) Gfx.disc(g, cx - 6 + rnd.nextInt(12), cy + 2 + rnd.nextInt(5), 1, 0x88DFF4FF);
            return;
        }
        int ox = warn ? (time % 4 < 2 ? -1 : 1) : 0;
        int rx = Math.round(16 * sc), ry = Math.round(10 * sc);
        int col = warn && (t / 8) % 2 == 0 ? Gfx.mix(PAD[pt], 0xFFFFFFFF, 0.35F) : PAD[pt];
        if (warn) { ry = Math.round(ry * (1F - 0.15F * t / WARN)); }
        Gfx.ellipse(g, cx + ox, cy + 4, rx + 1, ry + 1, Gfx.darker(PAD[pt], 0.45F));
        Gfx.ellipse(g, cx + ox, cy + 3, rx, ry, Gfx.lighter(col, 0.08F));
        Gfx.ellipse(g, cx + ox, cy + 5, Math.max(1, rx / 2), Math.max(1, ry / 3), 0x22FFFFFF);
        g.fill(cx + ox, cy + 3 - ry, cx + ox + 1, cy + 3, Gfx.darker(PAD[pt], 0.45F));          // the notch
        if (warn && t > WARN - 40 && time % 6 < 3) Gfx.disc(g, cx + ox + rx - 2, cy + 6, 1, 0xAAFFFFFF);   // bubbles: it is about to sink
    }

    /** Things that float through the air of a swamp: embers, snow, toxic bubbles. */
    private void atmosphere(GuiGraphics g, int pt) {
        if (pt == 1) {
            for (int i = 0; i < 14; i++) {
                int x = (int) (Gfx.hash(i, 8) * W) + (int) (Math.sin(time * 0.03F + i) * 4), y = H - (int) ((time * (0.25F + Gfx.hash(i, 9) * 0.3F) + Gfx.hash(i, 10) * H) % H);
                g.fill(x, y, x + 1, y + 1, Gfx.alpha(0xFFFF7A5A, 120));
            }
        } else if (pt == 2) {
            for (int i = 0; i < 24; i++) {
                int x = (int) (Gfx.hash(i, 11) * W) + (int) (Math.sin(time * 0.02F + i) * 5), y = (int) ((time * (0.2F + Gfx.hash(i, 12) * 0.25F) + Gfx.hash(i, 13) * H) % H);
                g.fill(x, y, x + 2, y + 1, Gfx.alpha(0xFFFFFFFF, 150));
            }
        } else if (pt == 3) {
            for (int i = 0; i < 10; i++) {
                int x = (int) (Gfx.hash(i, 14) * W) + (int) (Math.sin(time * 0.03F + i) * 3), y = H - (int) ((time * (0.2F + Gfx.hash(i, 15) * 0.3F) + Gfx.hash(i, 16) * H) % H);
                int r = 1 + (int) (Gfx.hash(i, 17) * 2);
                Gfx.disc(g, x, y, r, Gfx.alpha(0xFF9AFF5A, 60));
            }
        }
    }

    private static void pad(GuiGraphics g, int cx, int cy, int r, int col, int water) {
        Gfx.disc(g, cx, cy, r + 1, Gfx.darker(col, 0.45F));
        Gfx.disc(g, cx, cy, r, col);
        Gfx.disc(g, cx, cy, r - 5, Gfx.lighter(col, 0.18F));
        Gfx.disc(g, cx, cy, r / 4, Gfx.darker(col, 0.2F));
        g.fill(cx, cy - r, cx + 1, cy, Gfx.darker(col, 0.45F));                 // the notch
        g.fill(cx - 1, cy - r, cx + 2, cy - r / 2, water);
    }

    private static void spotted(GuiGraphics g, int cx, int cy, int r, int col, int water, int hole) {
        pad(g, cx, cy, r, col, water);
        int[][] holes = {{-6, -2, 2}, {1, -6, 2}, {5, 0, 3}, {-3, 5, 2}, {2, 4, 2}, {-8, 3, 1}};
        for (int[] h : holes) Gfx.disc(g, cx + h[0], cy + h[1], h[2], hole);
    }

    private static void stump(GuiGraphics g, int cx, int cy, int r, int col) {
        Gfx.disc(g, cx, cy, r + 2, Gfx.darker(col, 0.5F));
        Gfx.disc(g, cx, cy, r, col);
        Gfx.disc(g, cx, cy, r - 3, Gfx.lighter(col, 0.2F));
        Gfx.disc(g, cx, cy, r / 2, col);
        Gfx.disc(g, cx - 2, cy - 2, 2, 0x55FFFFFF);
    }

    private static void flower(GuiGraphics g, int cx, int cy, int petal, int core) {
        for (int i = 0; i < 5; i++) {
            double a = i * 1.2566 + 0.4;
            Gfx.disc(g, cx + (int) Math.round(Math.cos(a) * 4), cy + (int) Math.round(Math.sin(a) * 4), 2, petal);
        }
        Gfx.disc(g, cx, cy, 2, core);
    }

    private static void leaves(GuiGraphics g, int cx, int cy, int dir, int col) {
        for (int i = 0; i < 4; i++) {
            int ex = cx + dir * (4 + i * 4), ey = cy - 12 + i * 3 - (i == 1 ? 4 : 0);
            Gfx.line(g, cx, cy + 6, ex, ey, Gfx.darker(col, 0.2F));
            Gfx.line(g, cx + 1, cy + 6, ex + dir, ey, Gfx.lighter(col, 0.2F));
        }
    }

    private void ringOfRange(GuiGraphics g) {
        float r = range();
        int col = tState == 0 ? 0xAAE0505A : 0x66E0505A;
        for (int i = 0; i < 90; i++) {
            if (i % 2 == 1) continue;
            double a = i * Math.PI * 2 / 90 + time * 0.003;
            int x = frogX + (int) Math.round(Math.cos(a) * r), y = frogY + (int) Math.round(Math.sin(a) * r);
            if (x >= 0 && y >= 0 && x < W && y < H) g.fill(x, y, x + 1, y + 1, col);
        }
        if (longT > 0) Gfx.glow(g, frogX, frogY, 12, 0xFF7ED957, 70);
    }

    private void drawBug(GuiGraphics g, Bug b) {
        int x = Math.round(b.x), y = Math.round(b.y);
        if (x < -8 || x > W + 8 || y < -8 || y > H + 8) return;
        boolean flap = (time / 2 + (int) (b.x * 0.3F)) % 2 == 0;
        int wing = 0xB0E8F4FF;
        switch (b.kind) {
            case FLY -> {
                Gfx.ellipse(g, x - 2, y - 2 + (flap ? 0 : 1), 2, 1, wing);
                Gfx.ellipse(g, x + 2, y - 2 + (flap ? 1 : 0), 2, 1, wing);
                Gfx.disc(g, x, y, 2, 0xFF2A2A34);
                g.fill(x - 1, y - 1, x, y, 0xFFE04040);
                g.fill(x + 1, y - 1, x + 2, y, 0xFFE04040);
            }
            case BLUEBOTTLE -> {
                Gfx.ellipse(g, x - 3, y - 2 + (flap ? 0 : 1), 3, 1, wing);
                Gfx.ellipse(g, x + 3, y - 2 + (flap ? 1 : 0), 3, 1, wing);
                Gfx.ball(g, x, y, 3, 0xFF2FB6A4);
                g.fill(x - 1, y - 1, x + 2, y, 0xFFB8FFF0);
                g.fill(x - 2, y - 3, x - 1, y - 2, 0xFFE04040);
                g.fill(x + 1, y - 3, x + 2, y - 2, 0xFFE04040);
            }
            case BUTTERFLY -> {
                int sp = flap ? 5 : 3;
                Gfx.ellipse(g, x - sp / 2 - 1, y - 1, sp, 3, 0xFFFF8FC8);
                Gfx.ellipse(g, x + sp / 2 + 1, y - 1, sp, 3, 0xFFFF8FC8);
                Gfx.ellipse(g, x - sp / 2, y + 2, sp - 1, 2, 0xFFFFC27A);
                Gfx.ellipse(g, x + sp / 2, y + 2, sp - 1, 2, 0xFFFFC27A);
                g.fill(x, y - 3, x + 1, y + 4, 0xFF4A2A44);
            }
            case DRAGONFLY -> {
                int dx = Math.round((float) Math.cos(b.a) * 4), dy = Math.round((float) Math.sin(b.a) * 4);
                Gfx.line(g, x - dx, y - dy, x + dx, y + dy, 0xFF2FD0E8);
                Gfx.disc(g, x + dx, y + dy, 1, 0xFF1A8AA0);
                Gfx.ellipse(g, x, y - 2 + (flap ? 0 : 1), 5, 1, wing);
                Gfx.ellipse(g, x, y + 2 + (flap ? 1 : 0), 5, 1, wing);
            }
            case FIREFLY -> {
                float p = 0.6F + 0.4F * (float) Math.sin(time * 0.15F + b.x);
                Gfx.glow(g, x, y, 9, 0xFFD8FF50, Math.round(120 * p));
                Gfx.disc(g, x, y, 2, 0xFFEFFF8A);
                g.fill(x - 3, y - 2 + (flap ? 0 : 1), x - 1, y - 1 + (flap ? 0 : 1), wing);
                g.fill(x + 1, y - 2 + (flap ? 1 : 0), x + 3, y - 1 + (flap ? 1 : 0), wing);
                g.fill(x - 1, y - 1, x + 1, y + 1, 0xFFFFFFFF);
            }
            case BOSS -> drawBoss(g, b, x, y, flap);
            case HORNET -> {                                                     // a big red-orange wasp
                Gfx.ellipse(g, x - 3, y - 4 + (flap ? 0 : 1), 4, 1, wing);
                Gfx.ellipse(g, x + 3, y - 4 + (flap ? 1 : 0), 4, 1, wing);
                Gfx.ellipse(g, x, y, 5, 4, 0xFFE8552A);
                g.fill(x - 3, y - 3, x - 2, y + 4, 0xFF2A1410);
                g.fill(x, y - 3, x + 1, y + 4, 0xFF2A1410);
                g.fill(x + 2, y - 3, x + 3, y + 4, 0xFF2A1410);
                g.fill(x - 5, y - 1, x - 3, y + 1, 0xFFFFE030);
                g.fill(x + 5, y + 3, x + 8, y + 4, 0xFF2A1410);                    // a long sting
            }
            case BUMBLE -> {                                                     // a fat fuzzy bumblebee
                Gfx.ellipse(g, x - 2, y - 5 + (flap ? 0 : 1), 3, 1, wing);
                Gfx.ellipse(g, x + 3, y - 5 + (flap ? 1 : 0), 3, 1, wing);
                Gfx.ball(g, x, y, 5, 0xFFFFD84A);
                g.fill(x - 4, y - 1, x + 5, y + 1, 0xFF3A2A20);
                g.fill(x - 3, y + 2, x + 4, y + 3, 0xFF3A2A20);
                g.fill(x - 5, y - 3, x - 3, y - 1, 0xFFFFF4C0);
                g.fill(x - 4, y - 2, x - 3, y - 1, 0xFF1A1428);
                g.fill(x - 6, y + 1, x - 5, y + 3, 0xFFFFF4C0);
            }
            case TOXIC -> {                                                      // a fly that glows poison green
                Gfx.glow(g, x, y, 8, 0xFF9AFF5A, 90);
                Gfx.ellipse(g, x - 2, y - 2 + (flap ? 0 : 1), 2, 1, 0xB0C8FFC8);
                Gfx.ellipse(g, x + 2, y - 2 + (flap ? 1 : 0), 2, 1, 0xB0C8FFC8);
                Gfx.disc(g, x, y, 2, 0xFF7A3AB0);
                g.fill(x - 1, y - 1, x, y, 0xFFB8FF5A);
                g.fill(x + 1, y - 1, x + 2, y, 0xFFB8FF5A);
                if (time % 20 < 10) Gfx.disc(g, x + 3, y - 4, 1, 0xAA9AFF5A);
            }
            case STAR -> {                                                       // a falling star with a tail
                for (int k = 4; k >= 1; k--) {
                    int tx = x - Math.round((float) Math.cos(b.a) * k * 3), ty = y - Math.round((float) Math.sin(b.a) * k * 3);
                    Gfx.disc(g, tx, ty, Math.max(1, 3 - k / 2), Gfx.alpha(0xFFFFE27A, 150 - k * 30));
                }
                Gfx.glow(g, x, y, 9, 0xFFFFE27A, 110);
                Gfx.star(g, x, y, 4, 0xFFFFF4A0);
            }
            default -> {                                                         // a wasp: yellow and black stripes, angry red eyes
                Gfx.ellipse(g, x - 2, y - 3 + (flap ? 0 : 1), 3, 1, wing);
                Gfx.ellipse(g, x + 2, y - 3 + (flap ? 1 : 0), 3, 1, wing);
                Gfx.ellipse(g, x, y, 4, 3, 0xFFFFD02A);
                g.fill(x - 2, y - 2, x - 1, y + 3, 0xFF2A2420);
                g.fill(x + 1, y - 2, x + 2, y + 3, 0xFF2A2420);
                g.fill(x - 4, y - 1, x - 3, y + 1, 0xFFE03030);
                g.fill(x + 4, y + 2, x + 6, y + 3, 0xFF2A2420);                    // the sting
            }
        }
    }

    private void drawBoss(GuiGraphics g, Bug b, int x, int y, boolean flap) {
        int col = BOSS_COL[part()], dark = Gfx.darker(col, 0.55F);
        if (b.hit > 0 && b.hit % 4 < 2) col = 0xFFFFFFFF;
        Gfx.glow(g, x, y, 16, BOSS_COL[part()], 60);
        Gfx.ellipse(g, x - 8, y - 8 + (flap ? 0 : 2), 8, 3, 0xB0E8F4FF);
        Gfx.ellipse(g, x + 8, y - 8 + (flap ? 2 : 0), 8, 3, 0xB0E8F4FF);
        Gfx.ellipse(g, x, y + 2, 9, 8, col);
        for (int i = -1; i <= 1; i += 2) g.fill(x + i * 3 - 1, y - 4, x + i * 3 + 1, y + 9, dark);
        Gfx.ball(g, x, y - 5, 6, col);
        g.fill(x - 4, y - 7, x - 1, y - 4, 0xFFFFFFFF);
        g.fill(x + 1, y - 7, x + 4, y - 4, 0xFFFFFFFF);
        g.fill(x - 3, y - 6, x - 1, y - 4, 0xFFD02020);
        g.fill(x + 1, y - 6, x + 3, y - 4, 0xFFD02020);
        g.fill(x - 5, y - 9, x + 6, y - 8, dark);                                      // the angry brow
        g.fill(x - 4, y - 14, x - 3, y - 11, 0xFFFFE27A);                              // a little crown
        g.fill(x - 1, y - 15, x, y - 11, 0xFFFFE27A);
        g.fill(x + 2, y - 14, x + 3, y - 11, 0xFFFFE27A);
        g.fill(x - 4, y - 11, x + 3, y - 10, 0xFFFFE27A);
        g.fill(x - 1, y + 10, x + 1, y + 14, dark);                                    // the sting
        int w = 20, hx = x - w / 2, hy = y - 21;
        g.fill(hx - 1, hy - 1, hx + w + 1, hy + 3, 0xAA000000);
        g.fill(hx, hy, hx + Math.round(w * b.hp / (float) b.maxHp), hy + 2, 0xFFFF5A5A);
    }

    private void drawFrog(GuiGraphics g) {
        float ang = (float) Math.atan2(my - frogY, mx - frogX);
        boolean hurt = hurtT > 0;
        int body = hurt ? 0xFF8FC24A : 0xFF4FCF3F, dark = Gfx.darker(body, 0.35F);
        int shake = hurt ? (time % 4 < 2 ? -1 : 1) : 0;
        int cx = frogX + shake, cy = frogY;
        Gfx.ellipse(g, cx - 9, cy + 6, 5, 3, dark);                                  // the back legs
        Gfx.ellipse(g, cx + 9, cy + 6, 5, 3, dark);
        Gfx.ellipse(g, cx, cy + 2, 9, 7, body);                                      // the body
        Gfx.ellipse(g, cx, cy + 4, 6, 4, 0xFFE6F7A8);                                // the belly
        Gfx.ellipse(g, cx - 5, cy + 9, 3, 2, body);                                  // the front feet
        Gfx.ellipse(g, cx + 5, cy + 9, 3, 2, body);
        Gfx.ball(g, cx, cy - 3, 8, body);                                            // the head
        int ex = Math.round((float) Math.cos(ang) * 1.4F), ey = Math.round((float) Math.sin(ang) * 1.4F);
        for (int s = -1; s <= 1; s += 2) {                                           // the big eyes follow the cursor
            int ox = cx + s * 5, oy = cy - 9;
            Gfx.ball(g, ox, oy, 3, body);
            Gfx.disc(g, ox, oy, 2, 0xFFFFFFFF);
            if (hurt) { g.fill(ox - 1, oy - 1, ox + 2, oy, 0xFF1A1428); g.fill(ox - 1, oy + 1, ox + 2, oy + 2, 0xFF1A1428); }
            else g.fill(ox + ex, oy + ey, ox + ex + 2, oy + ey + 2, 0xFF1A1428);
        }
        g.fill(cx - 3, cy - 4, cx - 2, cy - 3, dark);                                // the nostrils
        g.fill(cx + 2, cy - 4, cx + 3, cy - 3, dark);
        int my2 = cy - 1;
        if (tState == 0 && gulpT <= 0) {                                             // a smile
            g.fill(cx - 4, my2, cx + 5, my2 + 1, dark);
            g.fill(cx - 5, my2 - 1, cx - 4, my2, dark);
            g.fill(cx + 5, my2 - 1, cx + 6, my2, dark);
        } else if (gulpT > 0) {
            g.fill(cx - 4, my2, cx + 5, my2 + 1, dark);
            g.fill(cx - 3, my2 + 1, cx + 4, my2 + 2, 0xFFFF8FA8);
        } else {
            Gfx.ellipse(g, cx, my2, 3, 2, 0xFF7A1F34);                               // the mouth is open
        }
        g.fill(cx - 6, cy + 1, cx - 4, cy + 3, Gfx.alpha(0xFFFF9FB5, 150));          // the blush
        g.fill(cx + 5, cy + 1, cx + 7, cy + 3, Gfx.alpha(0xFFFF9FB5, 150));
    }

    private void dizzyStars(GuiGraphics g) {
        if (dizzyT <= 0) return;
        for (int i = 0; i < 3; i++) {
            double a = time * 0.15 + i * 2.0944;
            int x = frogX + (int) Math.round(Math.cos(a) * 9), y = frogY - 17 + (int) Math.round(Math.sin(a) * 3);
            Gfx.star(g, x, y, 2, 0xFFD8A0FF);
        }
        g.fill(0, 0, W, H, Gfx.alpha(0xFF8A3AD0, 14));
    }

    private void drawTongue(GuiGraphics g) {
        dizzyStars(g);
        if (tState == 0 || tLen <= 0) return;
        float ox = frogX + (float) Math.cos(tAng) * 7F, oy = frogY - 1 + (float) Math.sin(tAng) * 7F;
        int tx = Math.round(ox + (float) Math.cos(tAng) * tLen), ty = Math.round(oy + (float) Math.sin(tAng) * tLen);
        Gfx.line(g, Math.round(ox), Math.round(oy), tx, ty, 0xFFC02244);
        Gfx.line(g, Math.round(ox) + 1, Math.round(oy), tx + 1, ty, 0xFFFF5A78);
        Gfx.line(g, Math.round(ox), Math.round(oy) + 1, tx, ty + 1, 0xFFFF5A78);
        Gfx.disc(g, tx, ty, 2, 0xFFFF7A92);
        if (tCatch != null) drawBug(g, tCatch);
    }

    private void drawCursor(GuiGraphics g) {
        if (state != S_PLAY || over) return;
        boolean reach = (mx - frogX) * (mx - frogX) + (my - frogY) * (my - frogY) <= range() * range();
        int col = reach ? 0xFFFFFFFF : 0x88FFFFFF;
        Bug under = null;
        for (Bug b : bugs) {
            if (b.dead || b.caught > 0) continue;
            float dx = b.x - mx, dy = b.y - my;
            if (dx * dx + dy * dy < 49) { under = b; break; }
        }
        for (int i = 0; i < 16; i++) {
            double a = i * Math.PI / 8;
            int x = mx + (int) Math.round(Math.cos(a) * 5), y = my + (int) Math.round(Math.sin(a) * 5);
            g.fill(x, y, x + 1, y + 1, col);
        }
        g.fill(mx, my, mx + 1, my + 1, col);
        if (under != null && reach && under.kind != BOSS) {
            int v = VALUE[under.kind];
            ctext(g, v > 0 ? "" + v : "" + v, mx, my - 15, v > 0 ? 0xFFFFE27A : 0xFFFF6A6A);
        }
    }

    private void drawFx(GuiGraphics g, Fx f) {
        int x = Math.round(f.x), y = Math.round(f.y);
        float t = f.life / (float) f.max;
        if (f.kind == 1) Gfx.disc(g, x, y, Math.max(1, Math.round(3 * t)), Gfx.fade(f.col, t));
        else ctext(g, f.txt, x, y, Gfx.fade(f.col, Math.min(1F, t * 2F)));
    }

    private void hud(GuiGraphics g) {
        Gfx.rrect(g, 3, 3, 66, 11, 3, Gfx.fade(0xFF000000, 0.4F));
        String lv = isFinal() ? Component.translatable("cutemod.frog.hud.final", part() + 1).getString()
                : Component.translatable("cutemod.frog.hud", part() + 1, level % PER + 1, PER).getString();
        text(g, lv, 7, 5, isFinal() ? 0xFFFF8A6A : 0xFFFFD866);
        Gfx.rrect(g, W - 62, 3, 59, 11, 3, Gfx.fade(0xFF000000, 0.4F));
        text(g, Component.translatable("cutemod.frog.goal", goal()).getString(), W - 58, 5, 0xFFFFFFFF);
        int sc = scoreBase + levelPts;
        text(g, "" + sc, W - 6 - tw("" + sc), 16, sc < scoreBase ? 0xFFFF7A7A : 0xFFB8F0FF);
        for (int i = 0; i < 4; i++) {                                                // the four jars
            int x = JAR_X + i * JAR_STEP, y = JAR_Y;
            Gfx.rrect(g, x, y, JAR_W, JAR_H, 3, Gfx.fade(0xFF000000, 0.45F));
            Gfx.outline(g, x, y, JAR_W, JAR_H, jars[i] > 0 ? Gfx.alpha(JAR_COL[i], 220) : 0x44FFFFFF);
            if (jars[i] > 0) {
                Gfx.glow(g, x + 8, y + 8, 7, JAR_COL[i], 90);
                Gfx.disc(g, x + 8, y + 7, 3, JAR_COL[i]);
                text(g, "" + jars[i], x + 11, y + 8, 0xFFFFFFFF);
            } else Gfx.disc(g, x + 8, y + 7, 3, 0x33FFFFFF);
            text(g, "" + (i + 1), x + 2, y + 1, 0x88FFFFFF);
        }
        // the active bonuses
        int ax = 4;
        if (slowT > 0) { Gfx.rrect(g, ax, 112, 5, 5, 1, JAR_COL[J_SLOW]); ax += 7; }
        if (longT > 0) { Gfx.rrect(g, ax, 112, 5, 5, 1, JAR_COL[J_LONG]); ax += 7; }
        if (doubleT > 0) { Gfx.rrect(g, ax, 112, 5, 5, 1, JAR_COL[J_DOUBLE]); }
        // the combo meter on the left
        Gfx.rrect(g, 4, 24, 6, 70, 3, Gfx.fade(0xFF000000, 0.4F));
        int fill = Math.round(66F * comboT / COMBO_TIME);
        if (fill > 0) Gfx.rrect(g, 5, 25 + 68 - fill - 2, 4, Math.max(1, fill), 2, Gfx.mix(0xFFFFC23A, 0xFFFF5A8A, Math.min(1F, combo / 12F)));
        if (combo >= 3) ctext(g, "x" + Math.min(5, 1 + combo / 3) * (doubleT > 0 ? 2 : 1), 7, 96, 0xFFFFE27A);
        // lives and the time bar
        Gfx.heart(g, 4, H - 10, 0xFFFF6A8E);
        text(g, "x" + lives, 13, H - 11, 0xFFFFFFFF);
        int bx = 26, bw = W - 40, by = H - 7;
        Gfx.rrect(g, bx - 1, by - 1, bw + 2, 6, 3, Gfx.fade(0xFF000000, 0.55F));
        float k = Math.max(0F, timeLeft / (float) totalTime);
        int col = k > 0.5F ? 0xFF4A9CF0 : k > 0.2F ? 0xFFF0C23A : 0xFFE0485A;
        if (k > 0) Gfx.rrect(g, bx, by, Math.max(2, Math.round(bw * k)), 4, 2, col);
        int sx = bx + Math.round(bw * (1F - k));
        Gfx.ellipse(g, sx, by - 1, 4, 3, 0xFFD2A060);                                  // a snail crawls along the bar
        Gfx.disc(g, sx, by - 2, 2, 0xFF9A6A38);
        g.fill(sx + 3, by - 4, sx + 4, by - 2, 0xFFE8D8B8);

        if ((bannerT > 0 && state == S_PLAY) || state != S_PLAY) banner(g, bannerMsg);
        if (isFinal() && state == S_PLAY && bossSpawned && !bossDead && levelPts >= goal() && bannerT <= 0)
            banner(g, Component.translatable("cutemod.frog.bossleft").getString());
    }

    private static void banner(GuiGraphics g, String s) {
        int w = Math.min(W - 20, tw(s) + 24);
        if (s == null) return;
        Gfx.rrect(g, (W - w) / 2, 56, w, 16, 5, Gfx.fade(0xFF000000, 0.55F));
        ctextW(g, s, W / 2, 60, w - 8, 0xFFFFD866);
    }

    // ------------------------------------------------------------------ misc

    @Override
    public String hintKey() { return "cutemod.hint.frog"; }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score_lives", score, lives); }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() {
        return won ? Component.translatable("cutemod.frog.won") : Component.translatable("cutemod.ui.gameover");
    }
}
