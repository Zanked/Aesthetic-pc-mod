package dev.cutemod.client.os;

import dev.cutemod.data.PetWear;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/**
 * The "Home" tab of CuteMarket: wallpapers, pet accessories, songs and treats, bought with coins and used
 * at once (no cart, no courier). They used to live in the Shop app, which is gone.
 */
final class HomeGoods {
    private record Item(String id, int price) {}

    private static final Item[] ITEMS = build();

    /** The shop list: wallpapers, the desktop theme, every pet outfit of PetWear, songs and treats. */
    private static Item[] build() {
        List<Item> l = new ArrayList<>(List.of(
            new Item("wall6", 40), new Item("wall7", 40), new Item("wall8", 60),
            new Item("wall9", 50), new Item("wall10", 50), new Item("wall11", 70),
            new Item("wall13", 60), new Item("wall14", 70), new Item("wall15", 70),
            new Item("wall16", 70), new Item("wall17", 60), new Item("wall18", 60),
            new Item("wall19", 50), new Item("wall20", 50), new Item("wall21", 60),
            new Item("wall22", 70), new Item("wall23", 70), new Item("wall24", 70), new Item("wall25", 70),
            new Item(Theme.AERO_ID, Theme.AERO_PRICE)));   // the last one: the Frutiger Aero look of the whole desktop
        for (PetWear.Item w : PetWear.ALL) l.add(new Item(w.id(), w.price()));
        l.addAll(List.of(
            new Item("track4", 40), new Item("track5", 60), new Item("track6", 50), new Item("track7", 70),
            new Item("track8", 60), new Item("track9", 80), new Item("track10", 70),
            new Item("track11", 70), new Item("track12", 80), new Item("track13", 90),
            new Item("treat_cookie", 5), new Item("treat_fish", 8), new Item("treat_honey", 12),
            new Item("treat_milk", 10), new Item("treat_cake", 20), new Item("treat_medicine", 25)));
        return l.toArray(new Item[0]);
    }
    private static final String[] TAB_KINDS = {"", "wall", "acc", "track", "treat"};
    private static final int CHIP_X = 4, CHIP_Y = 26, CHIP_W = 58, CHIP_H = 12;
    private static final int TOP = 41, ROW = 24, VISIBLE = 5, BTN_W = 78;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;

    private int tab, scroll;

    /** The price today: the daily sales of CuteMarket apply here too. */
    private static int cost(Item it) { return dev.cutemod.market.Deals.price(it.id(), it.price()); }

    private static String kind(String id) {
        return id.startsWith("treat") ? "treat" : id.startsWith("wall") ? "wall" : id.startsWith("theme") ? "theme" : id.startsWith("acc") ? "acc" : "track";
    }

    /** The items of the selected chip. */
    private List<Item> view() {
        List<Item> out = new ArrayList<>();
        for (Item it : ITEMS) {
            String k = kind(it.id());
            if (tab == 0 || k.equals(TAB_KINDS[tab]) || (tab == 1 && k.equals("theme"))) out.add(it);   // tab 1 = Style: wallpapers and themes
        }
        return out;
    }

    private int maxScroll() { return Math.max(0, view().size() - VISIBLE); }

    /** Today as month * 100 + day (for the seasonal outfits). */
    private static int today() {
        java.time.LocalDate d = java.time.LocalDate.now();
        return d.getMonthValue() * 100 + d.getDayOfMonth();
    }

    /** The grey line under the name: what it does, how to get it, or which set it belongs to. */
    private static String subline(Item it, boolean treat) {
        if (treat) return App.t("cutemod.shop.eff." + it.id());
        PetWear.Item w = kind(it.id()).equals("acc") ? PetWear.get(it.id()) : null;
        if (w != null && !Progress.owned(it.id()) && !w.legacy() && w.src() != PetWear.Src.SHOP) return App.t("cutemod.shop.how." + it.id());
        if (w != null && !w.set().isEmpty()) return App.t("cutemod.shop.setline", App.t("cutemod.shop.set." + w.set()));
        return App.t("cutemod.shop.kind." + kind(it.id()));
    }

    /** Text of the button for this item. */
    private static String action(Item it) {
        boolean own = Progress.owned(it.id());
        switch (kind(it.id())) {
            case "wall" -> {
                if (!own) return "buy";
                return Wallpaper.get() == Integer.parseInt(it.id().substring(4)) ? "using" : "set";
            }
            case "acc" -> {
                if (!own) {
                    PetWear.Item w = PetWear.get(it.id());
                    if (w == null) return "buy";
                    return switch (w.src()) {
                        case SHOP -> "buy";
                        case SEASON -> PetWear.onSale(w, today()) ? "buy" : "season";
                        case STORY -> "story";
                        case SHOW -> "show";
                        case COUNT -> "play";
                    };
                }
                return Progress.wearing(it.id()) ? "take_off" : "wear";
            }
            case "theme" -> {
                if (!own) return "buy";
                return Theme.aero() ? "theme_off" : "theme_on";
            }
            case "treat" -> { return "buy"; } // consumable: you can buy as many as you like
            default -> { return own ? "have" : "buy"; }
        }
    }

    void render(GuiGraphics g, int mx, int my, int bodyColor, int ox, int oy) {
        Font f = App.font();
        for (int i = 0; i < 5; i++) {
            int cx = CHIP_X + i * CHIP_W;
            boolean sel = i == tab;
            App.roundRect(g, cx, CHIP_Y, CHIP_W - 2, CHIP_H, 5, sel ? ACCENT : (App.in(mx, my, cx, CHIP_Y, CHIP_W - 1, CHIP_H) ? 0xFFEAD6F5 : 0xFFF1E4F7));
            String s = App.t("cutemod.shop.tab." + i);
            Skin.str(g, f, s, cx + (CHIP_W - 1 - f.width(s)) / 2, CHIP_Y + 2, sel ? 0xFFFFFFFF : TEXT, false);
        }
        List<Item> items = view();
        scroll = Math.min(scroll, maxScroll());
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= items.size()) break;
            Item it = items.get(idx);
            int y = TOP + v * ROW;
            App.roundRect(g, 4, y, App.W - 10, ROW - 2, 5, v % 2 == 0 ? 0xFFFFFFFF : 0xFFFFEFF7);
            icon(g, it.id(), 6, y + 2, bodyColor, ox, oy);
            String name = App.t("cutemod.shop.item." + it.id());
            Skin.str(g, f, name, 32, y + 4, TEXT, false);
            boolean treat = kind(it.id()).equals("treat");
            if (treat && Progress.stock(it.id()) > 0) Skin.str(g, f, "x" + Progress.stock(it.id()), 36 + f.width(name), y + 4, 0xFFB98A10, false);
            Skin.str(g, f, subline(it, treat), 32, y + 14, MUTED, false);
            if (it.price() > 0 && (treat || !Progress.owned(it.id()))) {
                String p = Integer.toString(cost(it));
                int px = App.W - BTN_W - 16 - f.width(p);
                Progress.drawCoin(g, px - 10, y + 8);
                Skin.str(g, f, p, px, y + 8, Progress.coins() >= cost(it) ? TEXT : 0xFFE5484D, false);
                int deal = dev.cutemod.market.Deals.percent(it.id());
                if (deal > 0) {                                        // on sale today
                    String d = "-" + deal + "%";
                    Skin.rect(g, App.W - BTN_W - 12 - f.width(d) - 4, y + 15, f.width(d) + 4, 9, 0xFFE5484D);
                    Skin.str(g, f, d, App.W - BTN_W - 10 - f.width(d) - 4, y + 15, 0xFFFFFFFF, false);
                }
            }
            String a = action(it);
            boolean can = !(a.equals("using") || a.equals("have") || a.equals("story") || a.equals("show") || a.equals("play") || a.equals("season") || (a.equals("buy") && Progress.coins() < cost(it)));
            boolean hover = can && App.in(mx, my, App.W - BTN_W - 8, y + 3, BTN_W, 17);
            App.roundRect(g, App.W - BTN_W - 8, y + 3, BTN_W, 17, 5, !can ? 0xFFD8CCE2 : hover ? 0xFF8A6AC6 : ACCENT);
            String label = App.t("cutemod.shop.btn." + a);
            Skin.str(g, f, label, App.W - BTN_W - 8 + (BTN_W - f.width(label)) / 2, y + 8, can ? 0xFFFFFFFF : MUTED, false);
        }
        if (maxScroll() > 0) { // scroll bar
            App.rect(g, App.W - 3, TOP, 3, VISIBLE * ROW, 0xFFE9DDF2);
            int th = Math.max(8, VISIBLE * ROW * VISIBLE / items.size());
            App.rect(g, App.W - 3, TOP + (VISIBLE * ROW - th) * scroll / maxScroll(), 3, th, ACCENT);
        }
    }

    /** A little picture (20 x 20) of the item. */
    private void icon(GuiGraphics g, String id, int x, int y, int bodyColor, int ox, int oy) {
        App.rect(g, x - 1, y - 1, 22, 22, 0xFF3A2A4A);
        switch (kind(id)) {
            case "wall" -> Wallpaper.draw(g, x, y, 20, 20, bodyColor, Integer.parseInt(id.substring(4)));
            case "treat" -> {
                App.rect(g, x, y, 20, 20, 0xFFFFF0C0);
                PetApp.drawTreat(g, id, x + 5, y + 5);
            }
            case "theme" -> {        // Frutiger Aero: sky, a glass window bar, bubbles and a green hill
                Skin.grad(g, x, y, x + 20, y + 20, 0xFF6EC8FF, 0xFFE8F8FF);
                App.rect(g, x + 2, y + 3, 16, 4, 0xFF2F8FE0);
                App.rect(g, x + 2, y + 3, 16, 1, 0xFFFFFFFF);
                App.rect(g, x, y + 16, 20, 4, 0xFF6AC85A);
                App.disc(g, x + 13, y + 12, 3, 0x99FFFFFF);
                App.disc(g, x + 6, y + 13, 2, 0x99FFFFFF);
            }
            case "track" -> {
                App.rect(g, x, y, 20, 20, 0xFF6A4A9A);
                App.disc(g, x + 7, y + 14, 3, 0xFFFFFFFF);
                App.rect(g, x + 9, y + 4, 2, 11, 0xFFFFFFFF);
                App.rect(g, x + 9, y + 4, 6, 2, 0xFFFFFFFF);
            }
            default -> {        // a pet outfit: the item on a cream blob, drawn by PetArt
                App.rect(g, x, y, 20, 20, 0xFFFFF0C0);
                PetArt.icon(g, id, x, y, ox, oy);
            }
        }
    }

    boolean click(int x, int y) {
        if (App.in(x, y, CHIP_X, CHIP_Y, CHIP_W * 5, CHIP_H)) {
            int i = (x - CHIP_X) / CHIP_W;
            if (i >= 0 && i < 5 && i != tab) { tab = i; scroll = 0; }
            return true;
        }
        List<Item> items = view();
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= items.size()) break;
            Item it = items.get(idx);
            int ry = TOP + v * ROW;
            if (!App.in(x, y, App.W - BTN_W - 8, ry + 3, BTN_W, 17)) continue;
            switch (action(it)) {
                case "buy" -> {
                    if (kind(it.id()).equals("treat")) Progress.buyTreat(it.id(), cost(it));
                    else if (Progress.buy(it.id(), cost(it))) {
                        if (kind(it.id()).equals("wall")) Wallpaper.set(Integer.parseInt(it.id().substring(4)));
                        else if (kind(it.id()).equals("acc")) Progress.equip(it.id());
                        else if (kind(it.id()).equals("theme")) Theme.setAero(true);
                    }
                }
                case "set" -> Wallpaper.set(Integer.parseInt(it.id().substring(4)));
                case "wear" -> Progress.equip(it.id());
                case "take_off" -> Progress.unequip(it.id());
                case "theme_on" -> Theme.setAero(true);
                case "theme_off" -> Theme.setAero(false);
                default -> { }
            }
            return true;
        }
        return false;
    }

    void scroll(double amount) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll + (amount < 0 ? 1 : -1)));
    }

    boolean key(int keyCode) {
        switch (keyCode) {
            case 264 -> scroll = Math.min(maxScroll(), scroll + 1);                   // down
            case 265 -> scroll = Math.max(0, scroll - 1);                             // up
            case 262 -> { tab = Math.min(4, tab + 1); scroll = 0; }                   // right
            case 263 -> { tab = Math.max(0, tab - 1); scroll = 0; }                   // left
            default -> { return false; }
        }
        return true;
    }
}
