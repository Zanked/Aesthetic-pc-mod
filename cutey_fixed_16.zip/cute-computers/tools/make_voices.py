#!/usr/bin/env python3
"""
Makes the little speech sounds of the eight judges of the talent show (four of them sit on the panel in every round) (like the babble of the animals of a cozy village):
every judge has his own voice, and 8 slightly different syllables, so the speech never sounds the same twice.
Everything is synthesized here (no samples, no Minecraft sounds).

    python3 tools/make_voices.py            # writes sounds/voice/<judge>_<0..7>.ogg, updates sounds.json
    python3 tools/make_voices.py --demo F.wav   # also writes a demo where every judge "talks" for two seconds
    python3 tools/make_voices.py owl            # only the named voices (the other files stay untouched)

  Mei   (panda)     a soft little bleat, "bwaa", with a gentle wobble
  Boom  (frog)      a short round croak that flutters: "kwa" (ква)
  Void  (koala)     deep and sleepy: a warm "mmuh" that falls like a yawn
  Honey (cat)       a little "mi-aow" (мяу): the vowel slides ee-ah-oh while the pitch arches
  Kit   (pig)       a cute nasal grunt, "hru-oink" (хрю)
  Pip   (mouse)     a tiny quick squeak, "pi!" (every other one a double "pi-pi")
  Fox               a bright nasal "yip"
  Lady  (bear)      a soft, round, purring "mrr-oh" (ур-р)
  Owl   (Teacher Owl of Pet School)  a warm, round, gentle "hoo" (every second syllable is a double "hu-hoo")
(The pets in the Tamagotchi app talk with these 8 voices: PetApp.VOICES. A panda uses Mei, a frog Boom, a koala Void, a cat Honey, a pig Kit, a mouse Pip, a bear Lady.)

Needs numpy + scipy + ffmpeg (with libvorbis). In the game, PetStage plays "voice.<judge>" (one event with the 8 syllables,
the game picks one at random) with a different pitch for every letter.
"""
import json
import math
import os
import subprocess
import sys
import tempfile
import wave
import random

import numpy as np
from scipy.signal import butter, sosfilt

SR = 44100
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "src/main/resources/assets/cutemod")
OUT = os.path.join(ASSETS, "sounds/voice")
JUDGES = ["mei", "boom", "void", "honey"]      # the first four judges of the show (ShowJudges, judge 0-3)
TEACHERS = ["owl"]                             # Teacher Owl of Pet School (SchoolApp plays "voice.owl")
PETS = ["kit", "pip", "fox", "lady"]           # the other four judges (4-7 are bear, fox, pig, mouse); the pets of PetApp talk with all 8 voices
VARIANTS = 8


def T(n): return np.arange(n) / SR


def lp(x, fc, order=2): return sosfilt(butter(order, min(fc, SR * 0.45) / (SR / 2), output="sos"), x)


def bp(x, lo, hi): return sosfilt(butter(2, [lo / (SR / 2), min(hi, SR * 0.45) / (SR / 2)], btype="band", output="sos"), x)


def env(n, attack, tau, release=0.012):
    """Quick attack, soft exponential decay, a short fade at the very end (no clicks)."""
    t = T(n)
    e = np.minimum(1.0, t / attack) * np.exp(-t / tau)
    r = int(release * SR)
    e[-r:] *= np.linspace(1.0, 0.0, r)
    return e


def phase(freq):
    return 2 * np.pi * np.cumsum(freq) / SR


def finish(x, peak):
    x = x - np.mean(x)
    x = x / np.max(np.abs(x)) * peak
    fi, fo = int(0.002 * SR), int(0.010 * SR)             # a tiny fade in and out: never a click
    x[:fi] *= np.linspace(0.0, 1.0, fi)
    x[-fo:] *= np.linspace(1.0, 0.0, fo)
    return x


def vowel(f0, forms, n, rough=0.0, seed=0):
    """Additive 'vocal' tone: harmonics of the pitch curve f0 (array) shaped by moving formants.
    forms = [(centre_array_or_float, bandwidth, gain), ...]"""
    p = phase(f0)
    x = np.zeros(n)
    fmax = float(np.max(f0))
    K = int(min(60, 9000 / max(fmax, 60)))
    for k in range(1, K + 1):
        fk = k * f0
        a = np.zeros(n)
        for c, bw, g in forms:
            a += g * np.exp(-0.5 * ((fk - c) / bw) ** 2)
        a += 0.10 / k                                                   # a little body whatever the formants do
        x += a * np.sin(k * p) / k ** 0.6
    return x


def jitter(n, amount, seed, smooth=0.004):
    r = np.random.default_rng(seed).standard_normal(n)
    r = lp(r, 1.0 / smooth, 1)
    return 1 + amount * r / (np.max(np.abs(r)) + 1e-9)


def mei(i, rng):
    """Panda: a soft little bleat, \"bwaa\", with a gentle wobble."""
    dur = rng.uniform(0.15, 0.18); n = int(dur * SR); t = T(n)
    f0 = [392, 440, 466, 523, 494, 587, 554, 622][i]
    f = f0 * (1 + 0.05 * np.sin(2 * np.pi * 32 * t)) * (1 + 0.08 * (1 - np.exp(-t / 0.03)) - 0.10 * (t / dur) ** 2)
    x = vowel(f, [(np.linspace(450, 800, n), 160, 1.0), (np.linspace(1000, 1350, n), 260, 0.55)], n)
    x *= 1 - 0.25 * (0.5 + 0.5 * np.sin(2 * np.pi * 32 * t))                                 # bleat wobble
    pop = bp(np.random.default_rng(i).standard_normal(n), 300, 1200) * np.exp(-t / 0.008) * 0.25 * np.max(np.abs(x))   # a soft \"b\"
    return finish(lp((x + pop) * env(n, 0.012, 0.09), 4200), 0.75)


def boom(i, rng):
    """Frog: a short, round croak \"kwa\" that rises a little and flutters."""
    dur = rng.uniform(0.15, 0.18); n = int(dur * SR); t = T(n)
    f0 = [262, 294, 311, 349, 330, 392, 370, 415][i]
    f = f0 * (1 + 0.20 * (1 - np.exp(-t / 0.05))) * jitter(n, 0.015, 40 + i)
    x = vowel(f, [(np.linspace(380, 760, n), 130, 1.0), (np.linspace(900, 1250, n), 220, 0.7)], n)
    x *= 1 - 0.55 * (0.5 + 0.5 * np.sin(2 * np.pi * 78 * t))                                  # the rattle of a croak
    click = bp(np.random.default_rng(100 + i).standard_normal(n), 1500, 3500) * np.exp(-t / 0.004) * 0.35 * np.max(np.abs(x))   # \"k\"
    return finish(lp((x + click) * env(n, 0.006, 0.085), 4800), 0.80)


def void(i, rng):
    """Koala: a deep, sleepy, warm \"mmuh\" that falls like a yawn."""
    dur = rng.uniform(0.19, 0.22); n = int(dur * SR); t = T(n)
    f0 = [110, 123, 131, 147, 138, 156, 123, 165][i]
    f = f0 * (1 + 0.05 * (1 - np.exp(-t / 0.03)) - 0.16 * (t / dur) ** 1.5) * (1 + 0.012 * np.sin(2 * np.pi * 6 * t))
    x = vowel(f, [(np.linspace(330, 460, n), 90, 1.0), (np.linspace(700, 820, n), 150, 0.5)], n)
    x *= 1 - 0.30 * (0.5 + 0.5 * np.sin(2 * np.pi * 34 * t))                                  # a soft rumble
    air = lp(np.random.default_rng(200 + i).standard_normal(n), 900) * 0.05
    return finish(lp((x + air * np.max(np.abs(x))) * env(n, 0.020, 0.10, 0.02), 1900), 0.62)


def honey(i, rng):
    """Cat: a little \"mi-aow\" (the vowel slides from ee to ah to oh while the pitch makes an arch)."""
    dur = rng.uniform(0.20, 0.24); n = int(dur * SR); t = T(n); u = t / dur
    f0 = [523, 587, 622, 698, 659, 784, 740, 831][i]
    f = f0 * (0.92 + 0.22 * np.sin(np.pi * np.minimum(1, u) ** 0.8)) * (1 + 0.012 * np.sin(2 * np.pi * 7 * t))
    f1 = np.interp(u, [0, 0.25, 0.55, 1], [320, 420, 800, 520])
    f2 = np.interp(u, [0, 0.25, 0.55, 1], [2100, 2400, 1500, 1000])
    x = vowel(f, [(f1, 140, 1.0), (f2, 320, 0.6)], n)
    a = np.minimum(1, u / 0.12) ** 1.2 * np.exp(-1.6 * np.maximum(0, u - 0.55))                 # starts soft (\"m\"), swells, fades
    return finish(lp(x * a, 5200) * np.minimum(1, t / 0.006), 0.78)


def kit(i, rng):
    """Pig: a short, cute grunt \"hru-oink\" with a nasal tone and a bit of roughness."""
    dur = rng.uniform(0.13, 0.16); n = int(dur * SR); t = T(n); u = t / dur
    f0 = [220, 247, 262, 294, 277, 330, 311, 349][i]
    f = f0 * (1 + 0.35 * np.exp(-t / 0.03) - 0.25 * u) * jitter(n, 0.035, 60 + i, 0.002)
    x = vowel(f, [(480, 110, 1.0), (np.interp(u, [0, 1], [1250, 1000]), 220, 0.8), (2300, 400, 0.25)], n)
    x *= 1 - 0.35 * (0.5 + 0.5 * np.sin(2 * np.pi * 48 * t))                                  # grunty roughness
    puff = bp(np.random.default_rng(300 + i).standard_normal(n), 600, 2500) * np.exp(-t / 0.014) * 0.30 * np.max(np.abs(x))     # \"hr\"
    return finish(lp((x + puff) * env(n, 0.005, 0.07), 4200), 0.80)


def pip(i, rng):
    """Mouse: a tiny, quick squeak, \"pi!\" (every other variant is a double \"pi-pi\")."""
    f0 = [1760, 1865, 1976, 2093, 2217, 2349, 2093, 2489][i]

    def sq(length, base, seed):
        m = int(length * SR); t = T(m)
        f = base * (0.80 + 0.40 * (1 - np.exp(-t / 0.012))) * (1 + 0.02 * np.sin(2 * np.pi * 30 * t))
        p = phase(f)
        tone = np.sin(p) + 0.25 * np.sin(2 * p) + 0.08 * np.sin(3 * p)
        click = bp(np.random.default_rng(seed).standard_normal(m), 3000, 7000) * np.exp(-t / 0.004) * 0.15
        return (tone + click) * env(m, 0.003, 0.028)

    if i % 2 == 0:
        x = sq(rng.uniform(0.07, 0.09), f0, 400 + i)
    else:
        x = np.concatenate([sq(0.05, f0, 410 + i), np.zeros(int(0.018 * SR)), sq(0.06, f0 * 1.12, 420 + i) * 0.9])
    return finish(lp(x, 8000), 0.70)




def fox(i, rng):
    """The fox: a bright, short, slightly nasal "yip"."""
    dur = rng.uniform(0.09, 0.11); n = int(dur * SR); t = T(n)
    f0 = [494, 554, 587, 659, 622, 698, 740, 831][i]
    f = f0 * (1 + 0.18 * np.exp(-t / 0.02) - 0.08 * (t / dur))                                    # starts high, falls: "yip!"
    p = phase(f)
    tone = np.sin(p) + 0.5 * np.sin(2 * p) + 0.3 * np.sin(3 * p) + 0.15 * np.sin(4 * p)
    tone = bp(tone, 700, 3200)                                                                      # a nasal formant
    return finish(tone * env(n, 0.004, 0.04), 0.80)


def lady(i, rng):
    """Bear cub: a soft, round, purring \"mrr-oh\"."""
    dur = rng.uniform(0.15, 0.18); n = int(dur * SR); t = T(n); u = t / dur
    f0 = [175, 196, 208, 233, 220, 262, 247, 277][i]
    f = f0 * (1 + 0.10 * np.sin(np.pi * np.minimum(1, u))) * (1 + 0.01 * np.sin(2 * np.pi * 6 * t))
    x = vowel(f, [(np.interp(u, [0, 1], [420, 560]), 110, 1.0), (np.interp(u, [0, 1], [800, 950]), 170, 0.6)], n)
    x *= 1 - 0.30 * (0.5 + 0.5 * np.sin(2 * np.pi * 27 * t)) * np.exp(-t / 0.08)             # a purr at the start
    return finish(lp(x * env(n, 0.012, 0.09), 2800), 0.72)


def owl(i, rng):
    """Teacher Owl: a warm, round, gentle "hoo". Even variants are one soft "hoo" that rises a little, odd ones are a
    quick double "hu-hoo". A tiny breath at the start, a slow wobble in the tone, and an "oo" vowel (formants near 300 and 850 Hz)."""
    f0 = [330, 349, 392, 415, 370, 440, 392, 466][i]

    def hoo(length, f, rise, seed):
        m = int(length * SR); t = T(m)
        fr = f * (1 + rise * (1 - np.exp(-t / 0.05))) * (1 + 0.012 * np.sin(2 * np.pi * 5.5 * t))
        p = phase(fr)
        s = sum(np.sin(k * p) / k ** 1.2 for k in range(1, 10))
        s = bp(s, 200, 450) + 0.35 * bp(s, 700, 1000) + 0.45 * lp(s, 500)             # the "oo"
        breath = bp(np.random.default_rng(seed).standard_normal(m), 800, 2400) * np.exp(-t / 0.022) * 0.16
        return s / np.max(np.abs(s)) * env(m, 0.02, 0.10, 0.02) + breath

    if i % 2 == 0:
        x = hoo(rng.uniform(0.18, 0.22), f0, 0.07, 300 + i)
    else:
        a = hoo(0.075, f0 * 1.06, 0.0, 310 + i) * 0.7                                   # "hu"
        b = hoo(rng.uniform(0.15, 0.18), f0, 0.09, 320 + i)                             # "hoo"
        x = np.concatenate([a, np.zeros(int(0.02 * SR)), b])
    return finish(lp(x, 3500), 0.70)


MAKERS = {"mei": mei, "boom": boom, "void": void, "honey": honey, "kit": kit, "pip": pip, "fox": fox, "lady": lady, "owl": owl}


def save_wav(path, x):
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())


def save_ogg(name, x):
    os.makedirs(OUT, exist_ok=True)
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, name + ".wav")
        save_wav(wav, x)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-c:a", "libvorbis", "-q:a", "4",
                        os.path.join(OUT, name + ".ogg")], check=True)


def main():
    args = [a for a in sys.argv[1:] if a in MAKERS]                  # python3 tools/make_voices.py owl -> only those
    names = args or JUDGES + PETS + TEACHERS
    ALL = JUDGES + PETS + TEACHERS
    voices = {}
    for j in names:
        voices[j] = [MAKERS[j](i, random.Random(1000 * ALL.index(j) + i)) for i in range(VARIANTS)]
        for i, x in enumerate(voices[j]): save_ogg("%s_%d" % (j, i), x)
    # register: one event per judge with the 8 syllables (the game picks one at random)
    sj = os.path.join(ASSETS, "sounds.json")
    data = json.load(open(sj, encoding="utf-8")) if os.path.exists(sj) else {}
    for j in names:
        data["voice." + j] = {"sounds": [{"name": "cutemod:voice/%s_%d" % (j, i), "stream": False} for i in range(VARIANTS)]}
    json.dump(data, open(sj, "w", encoding="utf-8"), indent=2)
    size = sum(os.path.getsize(os.path.join(OUT, f)) for f in os.listdir(OUT)) // 1024
    print("voices: %d new files (%s), %d KB in the folder" % (len(names) * VARIANTS, ", ".join(names), size))
    if len(sys.argv) > 2 and sys.argv[1] == "--demo":     # each judge "says" about 2 seconds, like the game does
        out = []
        gap = np.zeros(int(0.5 * SR))
        for j in names:
            r = random.Random(7)
            for k in range(11):
                x = voices[j][r.randrange(VARIANTS)]
                pitch = 0.92 + r.randrange(7) * 0.035
                idx = (np.arange(int(len(x) / pitch)) * pitch).astype(int)
                y = x[idx[idx < len(x)]]
                out.append(np.pad(y, (0, int(0.10 * SR) - len(y) if len(y) < int(0.10 * SR) else 0)) * 0.9)
            out.append(gap)
        save_wav(sys.argv[2], np.concatenate(out))
        print("demo:", sys.argv[2])


if __name__ == "__main__":
    main()
