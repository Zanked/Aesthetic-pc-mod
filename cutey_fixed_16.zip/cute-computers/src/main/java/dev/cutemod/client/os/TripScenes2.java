package dev.cutemod.client.os;

import static dev.cutemod.client.os.TripScenes.*;

/** Places 9-17 of {@link TripScenes}: the cherry garden, the lighthouse, the amusement park, the cinema, the museum, the camp, the old house, the fair and the quiet place. */
final class TripScenes2 {
    private TripScenes2() {}

    static void big(C c, int dest) {
        switch (dest) {
            case 9 -> cherry(c);
            case 10 -> lighthouse(c);
            case 11 -> amusement(c);
            case 12 -> cinema(c);
            case 13 -> museum(c);
            case 14 -> camp(c);
            case 15 -> oldHouse(c);
            case 16 -> fair(c);
            default -> quiet(c);
        }
    }

    // ---------- 9: a cherry garden ----------
    private static void cherry(C c) {
        c.grad(0, 0, W, FL, 0xFFFFD6E8, 0xFFFFF8FB);
        sun(c, 250, 24, 9, 0xFFFFF0C8);
        drift(c, 3, 8, 26, 0xDDFFFFFF, 0.07);
        hills(c, FL - 10, 18, 0xFFB8E0C0, 0.03, 0.5, 0, W);
        // Mount Fuji far away
        c.tri(60, FL - 62, 80, 52, 0xFF9AA8D0); c.tri(60, FL - 62, 26, 14, 0xFFFFFFFF);
        c.r(0, FL - 6, W, H - FL + 6, 0xFF9ADCA0); c.grad(0, FL - 6, W, 14, 0xFF7ACB88, 0xFF9ADCA0);
        // a red torii gate
        for (int s = 0; s < 2; s++) { c.r(100 + s * 40, FL - 34, 5, 38, 0xFFD8402A); c.r(100 + s * 40, FL - 34, 1, 38, 0xFFF06A50); }
        c.rr(94, FL - 42, 56, 6, 2, 0xFF2A2030); c.r(94, FL - 43, 56, 2, 0xFFD8402A); c.r(104, FL - 28, 36, 4, 0xFFD8402A);
        // a pond with a bridge, lily pads and koi
        c.o(222, FL + 28, 66, 14, 0xFF4DA8D8); c.o(222, FL + 27, 62, 12, 0xFF8AD0F0);
        for (int i = 0; i < 5; i++) { int lx = 190 + i * 14, ly = FL + 22 + (i * 5) % 12; c.o(lx, ly, 4, 2, 0xFF4FB86A); c.r(lx, ly - 1, 3, 1, 0xFF8AD0F0); if (i % 2 == 0) c.b(lx + 1, ly - 2, 1, 0xFFFF8FB8); }
        for (int i = 0; i < 2; i++) { int kx = 210 + (int) Math.round(Math.sin(c.t / 30.0 + i * 3) * 24), ky = FL + 28 + i * 5; c.o(kx, ky, 5, 2, i == 0 ? 0xFFFF8A4A : 0xFFFFFFFF); c.r(kx - 7, ky - 1, 3, 3, i == 0 ? 0xFFFF8A4A : 0xFFFFFFFF); c.r(kx + 1, ky - 1, 2, 1, 0xFFE5484D); }
        for (int i = 0; i < 3; i++) c.o(200 + (i * 23 + c.t / 9) % 50, FL + 20 + i * 6, 3 + (c.t / 9 + i) % 3, 1, 0x44FFFFFF);
        for (int i = 0; i < 12; i++) c.r(174 + i * 7, FL + 14 - (int) Math.round(Math.sin(i / 11.0 * Math.PI) * 5), 7, 3, 0xFFD8402A);          // the bridge
        c.r(174, FL + 14, 2, 6, 0xFF8A5A3A); c.r(250, FL + 14, 2, 6, 0xFF8A5A3A);
        // cherry trees, big, with blossoms and falling petals
        int[][] tr = {{26, 40}, {278, 36}, {152, 24}};
        for (int[] t : tr) {
            int tx = t[0], tb = t[1];
            c.o(tx, FL + 8, 22, 4, 0x28000000);
            c.r(tx - 3, FL - tb, 6, tb + 8, 0xFF6A4228); c.r(tx - 3, FL - tb, 2, tb + 8, 0xFF8A5A3A);
            c.ln(tx, FL - tb + 6, tx - 14, FL - tb - 10, 0xFF6A4228); c.ln(tx, FL - tb + 10, tx + 14, FL - tb - 8, 0xFF6A4228);
            int cy = FL - tb - 12;
            c.b(tx, cy, 20, 0xFFF58FB8); c.b(tx - 16, cy + 8, 13, 0xFFFFB6D2); c.b(tx + 16, cy + 8, 13, 0xFFFFB6D2); c.b(tx - 6, cy - 8, 10, 0xFFFFC8DC); c.b(tx + 8, cy - 5, 8, 0xFFF58FB8);
            for (int i = 0; i < 12; i++) c.r(tx - 22 + (i * 11) % 44, cy - 14 + (i * 7) % 28, 2, 2, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFF7BA8);
        }
        // a stone lantern, a tea house with a lantern light, a bench
        c.r(70, FL + 12, 8, 18, 0xFF9A9AA8); c.rr(66, FL + 4, 16, 8, 2, 0xFFB8B8C8); c.r(70, FL + 6, 8, 4, 0xFFFFE680); c.tri(74, FL - 2, 20, 7, 0xFF7A7A88); c.r(66, FL + 28, 16, 3, 0xFF8A8A98);
        c.r(24, FL + 22, 32, 14, 0xFF8A5A3A); c.tri(40, FL + 6, 42, 17, 0xFFC8553D); c.r(30, FL + 24, 8, 12, 0xFFFFF0D8); c.r(42, FL + 24, 8, 12, 0xFFFFF0D8); c.r(34, FL + 24, 1, 12, 0xFF8A5A3A); c.r(46, FL + 24, 1, 12, 0xFF8A5A3A);
        for (int i = 0; i < 4; i++) { c.b(30 + i * 7, FL + 20 + (int) Math.round(Math.sin((c.t + i * 10) / 16.0)), 2, i % 2 == 0 ? 0xFFE5484D : 0xFFFFD84D); }
        for (int i = 0; i < 22; i++) c.r((i * 29 + c.t / 4 * (1 + i % 2)) % W, (i * 13 + c.t / 2 * (1 + i % 2) / 1) % (H - 4), 2, 1, i % 2 == 0 ? 0xFFFFB6D2 : 0xFFFFFFFF);
        flowers(c, 12, FL + 14, H - 6, 90, 170, 3, 0xFFFFFFFF, 0xFFFF8FB8);
    }

    // ---------- 10: a lighthouse at sunset ----------
    private static void lighthouse(C c) {
        c.grad(0, 0, W, 66, 0xFF5A3A8A, 0xFFFF8A5C); c.grad(0, 40, W, 40, 0x00FF8A5C, 0xFFFFD890);
        stars(c, 12, 24, 10);
        sun(c, 210, 62, 13, 0xFFFFD060);
        drift(c, 3, 14, 34, 0x99FFC8B0, 0.08);
        c.grad(0, 70, W, FL - 70 + 6, 0xFF4A6AC0, 0xFF2A4A98);
        for (int i = 0; i < 16; i++) { int wy = 72 + i * 2, wx = (i * 41 + c.t / 3 * (1 + i % 2)) % (W + 20) - 10; c.r(wx, wy, 12 - i % 3 * 2, 1, 0x55FFD890); }
        for (int i = 0; i < 6; i++) c.r(196 + i * 2 - 0, 72 + i * 4, 28 - i * 3, 1, 0x88FFD890);              // the sun on the sea
        // a small boat
        int bx = 120 + (int) Math.round(Math.sin(c.t / 60.0) * 20);
        c.r(bx - 8, 86, 17, 4, 0xFF8A5A3A); c.r(bx - 6, 90, 13, 1, 0xFF5A3A22); c.r(bx, 72, 1, 14, 0xFF5A3A22); c.tri(bx + 5, 73, 10, 12, 0xFFFFF0E0); c.tri(bx - 3, 76, 6, 9, 0xFFFFD8A8);
        // the rock cliff with grass and the lighthouse
        c.tri(60, FL - 30, 150, 60, 0xFF6A6A78); c.tri(80, FL - 24, 110, 46, 0xFF7A7A88); c.tri(30, FL - 8, 70, 30, 0xFF5A5A68);
        for (int i = 0; i < 12; i++) c.r(20 + i * 9, FL - 4 + (i * 7) % 18, 6, 1, 0xFF8A8A98);
        c.o(50, FL + 4, 40, 8, 0xFF5BBF6A); c.o(50, FL + 2, 34, 5, 0xFF7ADA7A);
        int lx = 54, lb = FL + 2, lh = 74;
        for (int r = 0; r < lh; r++) { int ww = 10 + r * 6 / lh + 4; c.r(lx - ww / 2, lb - lh + r, ww, 1, (r / 9) % 2 == 0 ? 0xFFE5484D : 0xFFFFF4EC); c.r(lx - ww / 2, lb - lh + r, 2, 1, 0x33FFFFFF); c.r(lx + ww / 2 - 2, lb - lh + r, 2, 1, 0x22000000); }
        c.r(lx - 9, lb - lh - 3, 18, 3, 0xFF3A2A3A); c.bev(lx - 6, lb - lh - 11, 12, 8, 0xFFFFE680, 0xFFFFFFFF, 0xFFE8A800);
        c.tri(lx, lb - lh - 18, 16, 7, 0xFF3A2A3A); c.r(lx, lb - lh - 20, 1, 3, 0xFF3A2A3A);
        c.bev(lx - 2, lb - 28, 5, 8, 0xFF8FD3FF, 0xFFFFFFFF, 0xFF3A2A3A); c.bev(lx - 2, lb - 50, 5, 8, 0xFF8FD3FF, 0xFFFFFFFF, 0xFF3A2A3A);
        c.r(lx - 4, lb - 10, 8, 10, 0xFF5A3A22);
        double ba = c.t / 30.0;                                                                       // the beam turns
        for (int k = 0; k < 90; k++) { int sw = (int) Math.round(Math.cos(ba) * k * 2); c.r(lx + sw, lb - lh - 7 + k / 8, 2, Math.max(1, k / 12), 0x18FFF0A0 + (Math.abs(Math.cos(ba)) > 0.5 ? 0x08000000 : 0)); }
        c.b(lx, lb - lh - 7, 13, 0x20FFE680);
        // a house, a wooden pier with a lamp, rocks in the surf, gulls, a buoy
        house(c, 90, FL + 4, 26, 16, 0xFFFFF0E0, 0xFF4D96FF, false);
        c.r(0, FL + 8, W, H - FL - 8, 0xFFE6C690); c.grad(0, FL + 8, W, H - FL - 8, 0xFFD8B880, 0xFFE6C690);
        for (int x = 0; x < W; x += 3) c.r(x, FL + 6 + (int) Math.round(Math.sin(x / 8.0 + c.t / 16.0) * 2), 3, 2, 0xAAFFFFFF);
        for (int i = 0; i < 11; i++) { c.r(150 + i * 12, FL + 14, 11, 4, 0xFF9A6A3C); c.r(150 + i * 12, FL + 14, 11, 1, 0xFFC8955C); c.r(152 + i * 12, FL + 18, 2, 8, 0xFF5A3A22); }
        c.r(268, FL - 6, 2, 20, 0xFF2A2A3A); c.rr(264, FL - 12, 10, 7, 2, 0xFFFFE680); c.b(269, FL - 9, 11, 0x1CFFE680);
        for (int i = 0; i < 3; i++) c.o(30 + i * 20, FL + 30 + i % 2 * 4, 8, 4, 0xFF6A6A78);
        c.b(180, 88, 3, 0xFFE5484D); c.r(179, 91, 3, 2, 0xFFFFFFFF); c.r(180, 83, 1, 3, 0xFF3A2A3A);
        for (int i = 0; i < 4; i++) bird(c, (c.t / 2 * (1 + i % 2) + i * 70) % (W + 20) - 10, 22 + i * 9 + (int) Math.round(Math.sin(c.t / 13.0 + i) * 2), 0xFFFFF0E0);
    }

    // ---------- 11: the amusement park ----------
    private static void amusement(C c) {
        c.grad(0, 0, W, FL, 0xFF6EC0FF, 0xFFFFE6F0);
        drift(c, 4, 6, 32, 0xEEFFFFFF, 0.1);
        hills(c, FL - 4, 14, 0xFFB8E8B0, 0.03, 0.2, 0, W);
        c.r(0, FL, W, H - FL, 0xFF8ED38F); c.r(0, FL, W, 1, 0xFF6FBF72);
        c.o(150, FL + 36, 150, 10, 0xFFF0D8A8);                                                               // a path
        // a roller coaster in the back
        for (int x = 0; x < 230; x++) { int ty = 40 + (int) Math.round(Math.sin(x / 20.0) * 14 + Math.sin(x / 7.0) * 3); c.r(30 + x, ty, 1, 2, 0xFF8A4A2A); if (x % 12 == 0) c.r(30 + x, ty + 2, 1, FL - ty - 2, 0xFFB86A4A); }
        int cx0 = (c.t * 2) % 230; int cy0 = 40 + (int) Math.round(Math.sin(cx0 / 20.0) * 14 + Math.sin(cx0 / 7.0) * 3);
        for (int k = 0; k < 3; k++) { c.rr(26 + cx0 - k * 9, cy0 - 5 + k, 8, 5, 2, new int[]{0xFFE5484D, 0xFFFFD84D, 0xFF4D96FF}[k]); }
        // the ferris wheel
        int fx = 74, r = 40, fy = FL - r - 2;
        c.ln(fx, fy, fx - 18, FL, 0xFF8A5A3A); c.ln(fx, fy, fx + 18, FL, 0xFF8A5A3A); c.ln(fx + 1, fy, fx - 17, FL, 0xFF8A5A3A); c.ln(fx + 1, fy, fx + 19, FL, 0xFF8A5A3A);
        c.r(fx - 22, FL - 1, 46, 3, 0xFF6E4726);
        for (int a = 0; a < 90; a++) { double an = a * Math.PI / 45; c.r(fx + (int) Math.round(Math.cos(an) * r), fy + (int) Math.round(Math.sin(an) * r), 1, 1, 0xFFE5484D); if (a % 2 == 0) c.r(fx + (int) Math.round(Math.cos(an) * (r - 6)), fy + (int) Math.round(Math.sin(an) * (r - 6)), 1, 1, 0xFFFF9A9A); }
        int[] gc = {0xFFFFC832, 0xFF4D96FF, 0xFFFF8FB8, 0xFF6BCB77, 0xFFB57BD6, 0xFFFF9A3C, 0xFF8FD3FF, 0xFFE5484D};
        for (int i = 0; i < 8; i++) {
            double an = c.t / 110.0 + i * Math.PI / 4;
            int gx = fx + (int) Math.round(Math.cos(an) * r), gy = fy + (int) Math.round(Math.sin(an) * r);
            c.ln(fx, fy, gx, gy, 0x88FFFFFF); c.bev(gx - 3, gy, 7, 6, gc[i], lit(gc[i], 0.4F), dim(gc[i], 0.25F)); c.r(gx - 3, gy, 7, 1, 0xFFFFFFFF);
        }
        c.b(fx, fy, 4, 0xFFFFD84D); c.b(fx, fy, 2, 0xFFFFFFFF);
        // a carousel
        int kx = 210;
        c.o(kx, FL + 6, 38, 6, 0xFFC8955C); c.r(kx - 36, FL - 2, 72, 8, 0xFFE5484D);
        for (int i = 0; i < 8; i++) { c.r(kx - 36 + i * 9, FL - 2, 4, 8, 0xFFFFFFFF); }
        for (int i = 0; i < 5; i++) { int px = kx - 28 + i * 14, bob = (int) Math.round(Math.sin((c.t + i * 12) / 12.0) * 3); c.r(px, FL - 28 + bob / 2, 1, 26, 0xFFFFD84D); c.o(px + 1, FL - 14 + bob, 5, 3, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFFD0E2); c.r(px + 4, FL - 20 + bob, 3, 7, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFFD0E2); c.b(px + 6, FL - 21 + bob, 2, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFFD0E2); }
        c.tri(kx, FL - 52, 84, 24, 0xFFFFC832); c.tri(kx, FL - 52, 84, 10, 0xFFE5484D);
        for (int i = 0; i < 8; i++) { c.b(kx - 36 + i * 10, FL - 29, 1, ((c.t / 8 + i) % 2 == 0) ? 0xFFFFFFFF : 0xFFFFE680); }
        c.r(kx, FL - 58, 1, 8, 0xFF8A5A3A); c.r(kx + 1, FL - 58, 7, 4, 0xFFE5484D);
        // a ticket booth, a balloon seller, bunting, stripey tent, lamps
        c.r(256, FL - 10, 30, 22, 0xFFFFF4DC); c.r(256, FL + 2, 30, 10, 0xFF4D96FF); c.r(262, FL - 2, 18, 8, 0xFF3A2A3A);
        for (int i = 0; i < 30; i += 5) c.r(254 + i, FL - 16, 6, 7, (i / 5) % 2 == 0 ? 0xFFE5484D : 0xFFFFFFFF);
        c.rr(260, FL - 8, 22, 5, 1, 0xFFFFD84D);
        int[] bc = {0xFFFF6B6B, 0xFFFFC832, 0xFF4D96FF, 0xFF6BCB77, 0xFFB57BD6, 0xFFFF8FB8};
        for (int i = 0; i < 6; i++) { int bx = 134 + i * 6 + (int) Math.round(Math.sin((c.t + i * 11) / 16.0) * 2), by = FL - 30 - (i % 3) * 5; c.b(bx, by, 4, bc[i]); c.r(bx - 2, by - 2, 1, 1, 0x99FFFFFF); c.ln(bx, by + 5, 140, FL + 2, 0x889A8A9A); }
        for (int i = 0; i < W; i += 7) { int sag = (int) Math.round(Math.sin(i * Math.PI / W * 4) * 3); c.r(i, 4 + sag, 7, 1, 0xFF8A6A5A); c.tri(i + 3, 5 + sag, 5, 5, bc[(i / 7) % 6]); }
        flowers(c, 14, FL + 14, H - 6, 0, W, 9, 0xFFFFFFFF, 0xFFFF8FB8, 0xFFFFF3B0);
        for (int i = 0; i < 6; i++) if ((c.t / 8 + i) % 3 == 0) { int sx = 24 + (i * 47) % 260, sy = 10 + (i * 29) % 60; c.r(sx, sy - 1, 1, 3, 0xCCFFFFFF); c.r(sx - 1, sy, 3, 1, 0xCCFFFFFF); }
    }

    // ---------- 12: the cinema ----------
    private static void cinema(C c) {
        c.grad(0, 0, W, H, 0xFF2A1030, 0xFF5A1A3A);
        // the projector beam from the back
        for (int k = 0; k < 100; k++) c.r(150 - k * 3 / 2 + 22 - 22 + (k / 4) * 0, 8 + k, 3 + k * 3, 1, 0x0AFFF4D0);
        // the screen with a fancy frame and a flickering picture
        c.rr(60, 8, 180, 80, 4, 0xFF1A0A20); c.rr(63, 11, 174, 74, 2, 0xFFFFD84D);
        boolean flick = (c.t / 3) % 9 != 0;
        c.grad(65, 13, 170, 70, flick ? 0xFF9AD8FF : 0xFF88C0E0, flick ? 0xFFFFE8F0 : 0xFFE0C8D8);
        c.r(65, 58, 170, 25, flick ? 0xFF7ACB7A : 0xFF6ABA6A);                                                  // a movie: a meadow, a sun and a pet
        c.b(98, 28, 8, 0xFFFFE066); cloud(c, 190, 30, 2, 0xFFFFFFFF); cloud(c, 140, 22, 1, 0xFFFFFFFF);
        int hx = 150 + (int) Math.round(Math.sin(c.t / 35.0) * 40);
        c.b(hx, 62, 7, 0xFFF4A7C3); c.b(hx - 5, 55, 3, 0xFFF4A7C3); c.b(hx + 5, 55, 3, 0xFFF4A7C3); c.r(hx - 3, 61, 1, 1, 0xFF3A2A3A); c.r(hx + 2, 61, 1, 1, 0xFF3A2A3A);
        heart(c, hx, 44 - (c.t / 6) % 8, 0xFFFF6B8E);
        for (int i = 0; i < 6; i++) c.b(65 + (i * 37 + c.t) % 170, 14 + (i * 13) % 60, 1, 0x22FFFFFF);          // dust in the light
        // curtains with folds, a gold top and tassels
        for (int sd = 0; sd < 2; sd++) {
            int cx0 = sd == 0 ? 0 : W - 52;
            c.r(cx0, 0, 52, FL + 8, 0xFFC02844);
            for (int k = 1; k < 52; k += 4) { c.r(cx0 + k, 0, 2, FL + 8, 0xFF8A1830); c.r(cx0 + k + 2, 0, 1, FL + 8, 0xFFE05070); }
            c.r(cx0 + (sd == 0 ? 44 : 0), 0, 8, FL + 8, 0xFF8A1830);
            c.r(cx0, 0, 52, 5, 0xFFFFC832); c.r(cx0, 5, 52, 1, 0xFFC8952C);
            for (int k = 0; k < 6; k++) { c.r(cx0 + 4 + k * 8, 6, 1, 4, 0xFFFFC832); c.b(cx0 + 4 + k * 8, 11, 1, 0xFFFFC832); }
        }
        // wall lights, posters
        for (int sd = 0; sd < 2; sd++) { int lx = sd == 0 ? 58 : 238; c.rr(lx - 3, 92, 7, 9, 2, 0xFFFFE680); c.b(lx, 96, 11, 0x16FFE680); }
        c.rr(14, 50, 24, 34, 2, 0xFFFFFFFF); c.r(16, 52, 20, 22, 0xFF4D96FF); c.b(26, 62, 5, 0xFFFFE066);
        // the aisle, the red carpet and rows of seats
        c.r(0, FL + 8, W, H - FL - 8, 0xFF3A1428);
        c.grad(120, FL + 6, 60, H - FL - 6, 0xFFA02040, 0xFF701030);
        for (int i = 0; i < 6; i++) c.r(120, FL + 14 + i * 7, 60, 1, 0xFF8A1830);
        for (int row = 0; row < 3; row++) for (int sd = 0; sd < 2; sd++) for (int i = 0; i < 4; i++) {
            int sx = sd == 0 ? 10 + i * 27 : 190 + i * 25, sy = FL + 10 + row * 14, col = (i + row) % 2 == 0 ? 0xFF8A1830 : 0xFFA02040;
            c.rr(sx, sy, 22, 14, 4, col); c.r(sx, sy, 22, 2, 0xFFD04868); c.r(sx + 3, sy + 8, 16, 4, dim(col, 0.2F));
            if (row > 0 && (i + row + sd) % 3 == 0) { c.b(sx + 11, sy - 1, 3, 0xFF1A0A20); c.r(sx + 8, sy - 1, 1, 1, 0xFFFFF0B0); }
        }
        // popcorn bucket and a drink
        int bx = 262, bt = FL + 12;
        for (int i = 0; i < 5; i++) c.b(bx - 6 + i * 3, bt - 2 - i % 2, 2, i % 2 == 0 ? 0xFFFFF0B0 : 0xFFFFE680);
        c.tri(bx, bt, 16, 14, 0xFFFFFFFF); for (int i = 0; i < 4; i++) c.r(bx - 5 + i * 3, bt + 2, 1, 11, 0xFFE5484D);
        c.r(284, bt + 2, 7, 10, 0xFF4D96FF); c.r(283, bt, 9, 2, 0xFFFFFFFF); c.r(288, bt - 5, 1, 6, 0xFFFFFFFF);
        // the projector at the back, with a glow
        c.rr(136, FL + 4, 28, 8, 2, 0xFF2A2A3A); c.b(160, FL + 8, 3, 0xFFFFF0B0); c.b(160, FL + 8, 6, 0x33FFF0B0); c.b(142, FL + 3, 3, 0xFF3A3A4A); c.b(150, FL + 3, 3, 0xFF3A3A4A);
    }

    // ---------- 13: the museum ----------
    private static void museum(C c) {
        c.grad(0, 0, W, FL + 4, 0xFFFFF6E0, 0xFFEBD4A8);
        for (int x = 0; x < W; x += 30) c.r(x, 0, 1, FL + 4, 0x10A08040);
        // arched windows with light
        for (int i = 0; i < 2; i++) { int wx = 80 + i * 110; c.rr(wx, 10, 30, 52, 12, 0xFFBFE6FF); c.r(wx + 14, 10, 2, 52, 0xFFFFFFFF); c.r(wx, 36, 30, 2, 0xFFFFFFFF); c.r(wx - 2, 10, 2, 52, 0xFFC8955C); c.r(wx + 30, 10, 2, 52, 0xFFC8955C); c.b(wx + 22, 24, 3, 0x66FFFFFF); for (int k = 0; k < 60; k++) c.r(wx + 4 + k / 2, 62 + k, 22, 1, 0x0EFFFFC0); }
        // the cornice, columns with capitals
        c.r(0, 0, W, 5, 0xFFF8F2E6); c.r(0, 5, W, 2, 0xFFC8952C);
        for (int s = 0; s < 4; s++) {
            int cx = s < 2 ? 8 + s * 38 : 218 + (s - 2) * 38;
            c.r(cx, 10, 14, FL - 10, 0xFFF8F2E6); c.r(cx + 10, 10, 4, FL - 10, 0xFFD8CDB8); for (int k = 0; k < 3; k++) c.r(cx + 3 + k * 3, 14, 1, FL - 18, 0xFFE8DCC8);
            c.r(cx - 2, 8, 18, 5, 0xFFFFFFFF); c.r(cx - 2, FL - 4, 18, 5, 0xFFFFFFFF);
        }
        // paintings and a banner
        c.rr(116, 12, 28, 22, 2, 0xFFC8952C); c.r(118, 14, 24, 18, 0xFF8FD3FF); c.r(118, 24, 24, 8, 0xFF6FC66A); c.b(136, 20, 3, 0xFFFFE066);
        c.rr(156, 14, 22, 28, 2, 0xFFC8952C); c.r(158, 16, 18, 24, 0xFFFFD0E2); c.b(167, 26, 6, 0xFFF58FB8); c.b(167, 26, 2, 0xFFFFE066);
        c.r(150, 54, 1, 0, 0);
        // a dinosaur skeleton on the left
        int dx = 56;
        for (int i = 0; i < 18; i++) c.r(dx + i * 2, FL - 34 + Math.abs(i - 9) / 3, 2, 3, 0xFFF4EBDD);                               // the spine
        for (int i = 0; i < 8; i++) c.ln(dx + 12 + i * 3, FL - 31, dx + 12 + i * 3 + 2, FL - 18 - Math.abs(i - 4), 0xFFE8DCC8);       // the ribs
        c.b(dx + 40, FL - 42, 6, 0xFFF4EBDD); c.r(dx + 44, FL - 42, 8, 4, 0xFFF4EBDD); c.r(dx + 47, FL - 38, 5, 1, 0xFF3A2A3A); c.r(dx + 41, FL - 44, 2, 2, 0xFF3A2A3A);
        for (int i = 0; i < 8; i++) c.r(dx + 34 + i, FL - 36 + i / 2, 2, 3, 0xFFF4EBDD);
        c.r(dx + 12, FL - 30, 2, 28, 0xFFF4EBDD); c.r(dx + 24, FL - 30, 2, 28, 0xFFF4EBDD); c.r(dx + 8, FL - 3, 8, 2, 0xFFE8DCC8); c.r(dx + 20, FL - 3, 8, 2, 0xFFE8DCC8);
        for (int i = 0; i < 12; i++) c.r(dx - 20 + i * 2, FL - 28 + i / 2, 2, 3, 0xFFF4EBDD);
        // the chess floor with a long red runner
        for (int yy = FL + 4; yy < H; yy += 6) for (int xx = 0, k = ((yy - FL) / 6) & 1; xx < W; xx += 10, k++) c.r(xx, yy, 10, Math.min(6, H - yy), (k & 1) == 0 ? 0xFFF4EBDD : 0xFFB8946A);
        c.r(0, FL + 2, W, 3, 0xFF9A7A52);
        c.rr(60, FL + 20, 180, 22, 4, 0xFFC02844); c.rr(62, FL + 22, 176, 18, 3, 0xFFD84868); for (int i = 0; i < 22; i++) c.r(66 + i * 8, FL + 24, 3, 1, 0xFFFFC832);
        // pedestals with a gem, a vase and a statue
        int px = 232;
        c.bev(px - 12, FL - 10, 24, 14, 0xFFE8DCC8, 0xFFFFFFFF, 0xFFB8A888);
        int dr = 11;
        for (int dy = -dr; dy <= 0; dy++) { int dxx = (int) Math.round(Math.sqrt(dr * dr - dy * dy)); c.r(px - dxx, FL - 10 + dy, 1, 1, 0xAAB8E8FF); c.r(px + dxx, FL - 10 + dy, 1, 1, 0xAAB8E8FF); }
        c.r(px - dr, FL - 10 - dr, dr * 2 + 1, 1, 0x88FFFFFF);
        c.tri(px, FL - 20, 12, 10, 0xFFB57BD6); c.tri(px - 2, FL - 18, 5, 6, 0xFFD8B0F8); c.b(px, FL - 12, 17, 0x14B8E8FF);
        if ((c.t / 10) % 3 != 0) { c.r(px - 1, FL - 24, 3, 1, 0xFFFFFFFF); c.r(px, FL - 25, 1, 3, 0xFFFFFFFF); }
        c.bev(14, FL - 8, 20, 12, 0xFFE8DCC8, 0xFFFFFFFF, 0xFFB8A888); c.rr(18, FL - 26, 12, 18, 4, 0xFF4D96FF); c.r(20, FL - 29, 8, 4, 0xFF4D96FF); c.r(18, FL - 18, 12, 2, 0xFFFFD84D); c.r(18, FL - 14, 12, 1, 0xFFFFFFFF);
        // a chandelier
        c.r(150, 0, 1, 8, 0xFFC8952C);
        for (int i = 0; i < 5; i++) { int lx = 134 + i * 8, ly = 10 + Math.abs(i - 2) * 2; c.r(lx, ly, 1, 4, 0xFFC8952C); c.b(lx, ly + 5, 2, (c.t / 12 + i) % 4 == 0 ? 0xFFFFFFFF : 0xFFFFE680); }
        c.r(132, 9, 38, 1, 0xFFC8952C);
        // a rope barrier
        for (int i = 0; i < 4; i++) { c.r(200 + i * 14 - 2, FL + 6, 2, 12, 0xFFFFD84D); c.b(200 + i * 14 - 1, FL + 6, 2, 0xFFFFD84D); if (i < 3) for (int k = 0; k < 12; k++) c.r(200 + i * 14 + k, FL + 9 + (int) Math.round(Math.sin(k / 12.0 * Math.PI) * 3), 1, 2, 0xFFC02844); }
    }

    // ---------- 14: a camp ----------
    private static void camp(C c) {
        c.grad(0, 0, W, FL, 0xFF081030, 0xFF2E4A78);
        stars(c, 50, 64, 14);
        c.b(244, 28, 11, 0xFFFFF3B0); c.b(248, 25, 10, 0xFF0E1838);
        hills(c, FL - 12, 24, 0xFF152848, 0.025, 0.7, 0, W);
        hills(c, FL - 4, 14, 0xFF1A3A4A, 0.04, 2.0, 0, W);
        for (int i = 0; i < 11; i++) pine(c, 6 + i * 29, FL - 2, 40 + (i * 11) % 22, 20, i % 2 == 0 ? 0xFF123A2A : 0xFF1A4A34, false);
        // a lake with the moon's reflection
        c.r(0, FL - 2, W, H - FL + 2, 0xFF2A4A2E); c.grad(0, FL - 2, W, 20, 0xFF1A3A24, 0xFF2A4A2E);
        c.o(268, FL + 14, 40, 7, 0xFF14284A); c.o(268, FL + 14, 37, 5, 0xFF1E3A66);
        c.r(262, FL + 12, 12, 1, 0x88FFF3B0); c.r(264, FL + 15, 8, 1, 0x66FFF3B0);
        for (int i = 0; i < 3; i++) c.r(240 + (i * 23 + c.t / 6) % 50, FL + 11 + i * 3, 6, 1, 0x44A8C8F0);
        for (int i = 0; i < 6; i++) { c.r(232 + i * 4, FL + 6, 1, 7 + i % 3, 0xFF3F7A3A); }                       // reeds
        // the tent with a glowing door
        c.o(52, FL + 36, 40, 4, 0x28000000);
        c.tri(52, FL - 20, 74, 52, 0xFFE8803A); c.tri(44, FL - 16, 40, 44, 0xFFF4A860);
        c.tri(52, FL - 4, 22, 36, 0xFF3A2A3A); c.tri(52, FL + 2, 14, 30, 0xFFFFD890); c.tri(52, FL + 8, 8, 24, 0xFFFFE8B0);
        c.ln(52, FL - 20, 28, FL + 32, 0xFF8A4A1A); c.ln(52, FL - 20, 76, FL + 32, 0xFF8A4A1A);
        c.r(52, FL - 26, 1, 8, 0xFF6E4726); c.r(53, FL - 26, 8, 4, 0xFF4D96FF);
        c.ln(20, FL + 30, 28, FL + 32, 0xFFB8A888); c.ln(84, FL + 30, 76, FL + 32, 0xFFB8A888);
        // the campfire with logs, stones, sparks and a warm glow
        int fx = 206, fb = FL + 27;
        c.o(fx, fb, 40, 8, 0x22FF8A2A); c.o(fx, fb, 26, 5, 0x30FFA040); c.b(fx, fb - 10, 20, 0x14FFB040);
        for (int i = 0; i < 9; i++) c.o(fx - 12 + i * 3, fb + 2 + Math.abs(i - 4) / 3, 3, 2, 0xFF7A7E88);
        c.ln(fx - 9, fb + 1, fx + 9, fb - 4, 0xFF6A4228); c.ln(fx - 9, fb - 4, fx + 9, fb + 1, 0xFF8A5A3A); c.ln(fx - 8, fb, fx + 8, fb - 3, 0xFF5A3A22);
        int fh = 14 + (c.t / 3) % 4;
        c.tri(fx, fb - fh - 2, 14, fh, 0xFFFF6A1A); c.tri(fx - 1, fb - fh + 2, 9, fh - 3, 0xFFFFA82A); c.tri(fx, fb - fh + 6, 5, fh - 7, 0xFFFFE070);
        c.tri(fx - 7, fb - fh / 2 - 2, 5, fh / 2, 0xFFFF7A2A); c.tri(fx + 7, fb - fh / 2, 5, fh / 2 - 1, 0xFFFF7A2A);
        for (int i = 0; i < 6; i++) c.r(fx - 6 + (i * 5 + c.t / 5) % 13, fb - fh - 4 - (c.t / 2 + i * 9) % 26, 1, 1, i % 2 == 0 ? 0xFFFFD84D : 0xFFFF8A2A);
        // logs to sit on, a lantern, a guitar, marshmallow sticks, an owl
        c.rr(172, FL + 26, 22, 8, 4, 0xFF7A4A2A); c.o(172, FL + 30, 3, 4, 0xFFD8B070);
        c.rr(238, FL + 28, 24, 8, 4, 0xFF7A4A2A); c.o(262, FL + 32, 3, 4, 0xFFD8B070);
        c.r(124, FL - 10, 1, 8, 0xFF6A4228); c.rr(120, FL - 18, 9, 9, 2, 0xFFFFD84D); c.r(122, FL - 16, 5, 5, 0xFFFFF0B0); c.b(124, FL - 14, 10, 0x1CFFE680);
        c.rr(100, FL + 28, 8, 12, 3, 0xFFC8955C); c.r(103, FL + 21, 2, 9, 0xFF6E4726); c.b(104, FL + 33, 1, 0xFF3A2A3A);
        c.ln(178, FL + 22, 196, FL + 8, 0xFF8A5A3A); c.b(196, FL + 8, 2, 0xFFFFFFFF); c.ln(240, FL + 24, 220, FL + 14, 0xFF8A5A3A); c.b(220, FL + 14, 2, 0xFFFFE0E8);
        c.o(278, 54, 5, 7, 0xFF8A6A4A); c.b(276, 49, 2, 0xFFFFD84D); c.b(281, 49, 2, 0xFFFFD84D); c.r(276, 49, 1, 1, 0xFF3A2A3A); c.r(281, 49, 1, 1, 0xFF3A2A3A); c.r(274, 56, 10, 2, 0xFF5A3A22);
        for (int i = 0; i < 12; i++) { int ffx = (int) (30 + (i * 73) % 250 + Math.sin(c.t / 40.0 + i) * 14), ffy = (int) (FL - 20 + (i * 41) % 60 + Math.cos(c.t / 33.0 + i * 2) * 8); int a = 0x80 + (int) (Math.sin(c.t / 12.0 + i) * 0x60); c.r(ffx, ffy, 2, 2, (a << 24) | 0xE8FF60); c.r(ffx - 1, ffy - 1, 4, 4, ((a / 4) << 24) | 0xE8FF60); }
    }

    // ---------- 15: an old house on Halloween night ----------
    private static void oldHouse(C c) {
        c.grad(0, 0, W, H, 0xFF14082A, 0xFF5A2A60);
        stars(c, 26, 60, 15);
        c.b(222, 30, 24, 0x18FFD890); c.b(222, 30, 18, 0x22FFD890); c.b(222, 30, 15, 0xFFFFE9A8); c.b(217, 26, 3, 0xFFEED890); c.b(228, 36, 4, 0xFFEED890); c.b(226, 24, 2, 0xFFEED890);
        for (int i = 0; i < 4; i++) { int ax = 160 + i * 28 + (c.t / 6) % 8; c.b(ax, 26 + i * 3, 4 + i % 2, 0x305A2A60); }
        hills(c, FL - 6, 16, 0xFF241236, 0.03, 0.4, 0, W);
        c.r(0, FL - 2, W, H - FL + 2, 0xFF1C1030); c.grad(0, FL - 2, W, 24, 0xFF2A1840, 0xFF1C1030);
        // the big old house with towers, a crooked roof, glowing windows and a door
        int hx = 96, hb = FL + 6;
        c.r(hx, hb - 52, 78, 52, 0xFF33224E); c.r(hx, hb - 52, 78, 1, 0xFF4A3A6A); c.r(hx + 76, hb - 52, 2, 52, 0xFF241838);
        c.tri(hx + 39, hb - 86, 92, 36, 0xFF2A1C42); c.tri(hx + 30, hb - 80, 50, 28, 0xFF3A2858);
        c.r(hx + 58, hb - 80, 8, 14, 0xFF33224E); c.r(hx + 57, hb - 82, 10, 3, 0xFF2A1C42);
        for (int i = 0; i < 3; i++) c.b(hx + 62 + (int) Math.round(Math.sin((c.t + i * 14) / 13.0) * 3), hb - 88 - i * 6 - (c.t / 6 + i * 3) % 6, 2 + i / 2, 0x55CCB8E8);
        c.r(hx - 18, hb - 74, 22, 74, 0xFF2E1E48); c.tri(hx - 7, hb - 100, 28, 26, 0xFF241838); c.r(hx - 8, hb - 108, 1, 10, 0xFF241838); c.r(hx - 7, hb - 108, 6, 3, 0xFFE8803A);
        c.r(hx + 78, hb - 66, 20, 66, 0xFF2E1E48); c.tri(hx + 88, hb - 90, 26, 24, 0xFF241838);
        for (int w = 0; w < 6; w++) {
            int wx = hx + 8 + (w % 3) * 24, wy = hb - 46 + (w / 3) * 22;
            boolean on = (c.t / 25 + w * 3) % 9 != 0, big = w == 1;
            c.rr(wx, wy, 11, 14, 4, on ? 0xFFFFD84D : 0xFF6A5030); if (on) { c.r(wx + 5, wy, 1, 14, 0xFF8A5A1A); c.r(wx, wy + 6, 11, 1, 0xFF8A5A1A); c.b(wx + 5, wy + 6, 11, 0x14FFD84D); }
            if (w == 4 && on) { c.b(wx + 4, wy + 6, 2, 0xFF0A0614); c.r(wx + 2, wy + 8, 6, 5, 0xFF0A0614); }              // a silhouette in the window
        }
        c.rr(hx - 14, hb - 60, 7, 10, 3, (c.t / 31) % 5 != 0 ? 0xFFFFD84D : 0xFF6A5030); c.rr(hx + 84, hb - 52, 7, 10, 3, 0xFFFFD84D);
        c.rr(hx + 31, hb - 22, 16, 22, 6, 0xFF120A20); c.r(hx + 39, hb - 22, 1, 22, 0xFF2A1C42); c.b(hx + 44, hb - 10, 1, 0xFFFFD84D);
        for (int i = 0; i < 5; i++) c.r(hx + 28 + i * 5, hb, 4, 3, 0xFF4A3A6A);
        // a wrought-iron fence, the graveyard, a dead tree, pumpkins, a ghost, cobwebs
        for (int i = 0; i < 12; i++) { int fx = 4 + i * 8; c.r(fx, FL + 14, 1, 14, 0xFF120A20); c.tri(fx, FL + 11, 4, 4, 0xFF120A20); }
        c.r(4, FL + 18, 96, 1, 0xFF120A20); c.r(4, FL + 25, 96, 1, 0xFF120A20);
        for (int i = 0; i < 12; i++) { int fx = 200 + i * 8; c.r(fx, FL + 14, 1, 14, 0xFF120A20); c.tri(fx, FL + 11, 4, 4, 0xFF120A20); }
        c.r(200, FL + 18, 96, 1, 0xFF120A20); c.r(200, FL + 25, 96, 1, 0xFF120A20);
        for (int i = 0; i < 3; i++) { int gx = 210 + i * 26, gy = FL + 30 + i % 2 * 6; c.rr(gx, gy - 12, 12, 16, 5, 0xFF8A8A9A); c.rr(gx + 1, gy - 11, 10, 3, 2, 0xFFA8A8B8); c.r(gx + 3, gy - 7, 6, 1, 0xFF6A6A7A); c.r(gx + 5, gy - 9, 2, 5, 0xFF6A6A7A); c.o(gx + 6, gy + 5, 8, 2, 0xFF1C1030); }
        c.r(34, FL - 30, 5, 50, 0xFF120A20); c.ln(36, FL - 20, 18, FL - 40, 0xFF120A20); c.ln(36, FL - 10, 56, FL - 34, 0xFF120A20); c.ln(18, FL - 40, 10, FL - 52, 0xFF120A20); c.ln(56, FL - 34, 66, FL - 46, 0xFF120A20); c.ln(36, FL - 30, 36, FL - 52, 0xFF120A20);
        for (int i = 0; i < 3; i++) { int px = 62 + i * 12, py = FL + 20 + i % 2 * 3, pr = 4 + i % 2 * 2; c.b(px, py, pr, 0xFFE8803A); c.b(px - 3, py, pr - 2, 0xFFF4A04A); c.b(px + 3, py, pr - 2, 0xFFF4A04A); c.r(px, py - pr - 2, 2, 3, 0xFF3A7A3A); c.r(px - 3, py - 2, 2, 2, 0xFFFFF0A0); c.r(px + 2, py - 2, 2, 2, 0xFFFFF0A0); c.r(px - 2, py + 2, 5, 1, 0xFFFFF0A0); c.b(px, py, pr + 6, 0x12FFA030); }
        int gx = 150 + (int) Math.round(Math.sin(c.t / 30.0) * 30), gy = 58 + (int) Math.round(Math.sin(c.t / 12.0) * 4);
        c.rr(gx - 7, gy - 8, 14, 18, 7, 0xAAFFFFFF); for (int i = 0; i < 3; i++) c.b(gx - 5 + i * 5, gy + 10, 2, 0xAAFFFFFF); c.r(gx - 4, gy - 3, 2, 3, 0xFF1A0A2A); c.r(gx + 2, gy - 3, 2, 3, 0xFF1A0A2A); c.rr(gx - 2, gy + 2, 4, 3, 1, 0xFF1A0A2A);
        for (int i = 0; i < 4; i++) { int bx = (c.t * (1 + i % 2) / 2 + i * 80) % (W + 20) - 10, by = 18 + i * 10 + (int) Math.round(Math.sin((c.t + i * 11) / 5.0) * 3); boolean up = (c.t / 6 + i) % 2 == 0; c.r(bx + 2, by, 2, 2, 0xFF0A0614); c.r(bx - 1, by + (up ? -2 : 1), 3, 1, 0xFF0A0614); c.r(bx + 4, by + (up ? -2 : 1), 3, 1, 0xFF0A0614); }
        for (int i = 0; i < 6; i++) c.o((i * 61 + c.t / 5) % W, FL + 30 + i * 3, 30, 3, 0x14B8A0D8);                  // low fog
        for (int i = 0; i < 6; i++) { c.ln(0, 0, 18 - i * 3, i * 3, 0x66FFFFFF); c.ln(W - 1, 0, W - 19 + i * 3, i * 3, 0x66FFFFFF); }
    }

    // ---------- 16: a fair ----------
    private static void fair(C c) {
        c.grad(0, 0, W, FL, 0xFF8AD0FF, 0xFFFFF0F6);
        drift(c, 3, 8, 28, 0xEEFFFFFF, 0.1);
        hills(c, FL - 6, 12, 0xFFBDE8B0, 0.03, 1.1, 0, W);
        c.r(0, FL, W, H - FL, 0xFFF0D8A8); for (int i = 0; i < W; i += 6) { c.r(i, FL + 4, 3, 1, 0xFFD8BC88); c.r(i + 3, FL + 20, 3, 1, 0xFFD8BC88); c.r(i, FL + 36, 3, 1, 0xFFD8BC88); }
        // strings of lights between poles, flags and a big banner
        for (int p = 0; p < 4; p++) { int px = 10 + p * 94; c.r(px, 26, 2, FL - 20, 0xFF8A5A3A); }
        for (int s = 0; s < 3; s++) for (int i = 0; i <= 24; i++) { int lx = 11 + s * 94 + i * 94 / 24, ly = 28 + (int) Math.round(Math.sin(i / 24.0 * Math.PI) * 9); c.r(lx, ly, 1, 1, 0xFF6A5A6A); if (i % 2 == 0) { int col = new int[]{0xFFFF6B6B, 0xFFFFD84D, 0xFF4D96FF, 0xFF6BCB77}[(i / 2 + s) % 4]; boolean on = (c.t / 12 + i / 2) % 3 != 0; c.b(lx, ly + 3, 2, on ? col : dim(col, 0.4F)); if (on) c.b(lx, ly + 3, 4, col & 0x00FFFFFF | 0x20000000); } }
        c.rr(104, 8, 92, 16, 4, 0xFFE5484D); c.rr(106, 10, 88, 12, 3, 0xFFFFD84D); for (int i = 0; i < 9; i++) c.r(112 + i * 9, 14, 5, 4, i % 2 == 0 ? 0xFFE5484D : 0xFF4D96FF);
        // stalls: a prize game, sweets and a snack bar
        int[][] st = {{8, 0xFFE5484D}, {104, 0xFF4D96FF}, {206, 0xFF6BCB77}};
        for (int k = 0; k < 3; k++) {
            int sx = st[k][0], col = st[k][1], sw = 80, sh = 52;
            c.o(sx + sw / 2, FL + 3, sw / 2 + 2, 3, 0x26000000);
            c.r(sx + 4, FL - sh + 12, sw - 8, sh - 8, 0xFFFFF4DC); c.r(sx + 4, FL - sh + 12, 3, sh - 8, 0xFFE8DCC0);
            c.r(sx - 1, FL - 14, sw + 2, 12, 0xFFC8955C); c.r(sx - 1, FL - 14, sw + 2, 1, 0xFFE8B880); c.r(sx - 1, FL - 3, sw + 2, 2, 0xFF7A4A2A);
            for (int i = 0; i < sw; i += 8) { c.r(sx + i, FL - sh, Math.min(8, sw - i), 12, (i / 8) % 2 == 0 ? col : 0xFFFFFFFF); c.tri(sx + i + 4, FL - sh + 12, 8, 4, (i / 8) % 2 == 0 ? col : 0xFFFFFFFF); }
            c.r(sx - 2, FL - sh - 1, sw + 4, 2, dim(col, 0.2F));
            if (k == 0) { for (int i = 0; i < 4; i++) { c.b(sx + 14 + i * 16, FL - 22, 5, new int[]{0xFFB57B4A, 0xFFFFD84D, 0xFFFF8FB8, 0xFF8FD3FF}[i]); c.b(sx + 11 + i * 16, FL - 27, 2, new int[]{0xFFB57B4A, 0xFFFFD84D, 0xFFFF8FB8, 0xFF8FD3FF}[i]); c.b(sx + 17 + i * 16, FL - 27, 2, new int[]{0xFFB57B4A, 0xFFFFD84D, 0xFFFF8FB8, 0xFF8FD3FF}[i]); c.r(sx + 12 + i * 16, FL - 23, 1, 1, 0xFF3A2A3A); c.r(sx + 16 + i * 16, FL - 23, 1, 1, 0xFF3A2A3A); } }
            if (k == 1) { for (int i = 0; i < 5; i++) { c.b(sx + 12 + i * 14, FL - 24, 6, new int[]{0xFFFF9AC8, 0xFFFFFFFF, 0xFF9AD8FF, 0xFFFFF0A0, 0xFFFFC8F0}[i]); c.r(sx + 12 + i * 14, FL - 20, 1, 10, 0xFFF0E0C0); } }
            if (k == 2) { for (int i = 0; i < 4; i++) { c.rr(sx + 12 + i * 16, FL - 28, 12, 14, 3, 0xFFFFD84D); c.r(sx + 14 + i * 16, FL - 24, 8, 2, 0xFFE5484D); c.r(sx + 16 + i * 16, FL - 31, 4, 4, 0xFFF4EBDD); } }
            c.rr(sx + 22, FL - sh - 12, 36, 11, 3, 0xFFFFFFFF); c.r(sx + 26, FL - sh - 8, 28, 3, col);
        }
        // balloons, a carousel pony ride, a cotton candy cart in the front, confetti
        int[] bc = {0xFFFF6B6B, 0xFFFFC832, 0xFF4D96FF, 0xFF6BCB77, 0xFFB57BD6, 0xFFFF8FB8};
        for (int i = 0; i < 8; i++) { int bx = 40 + i * 32 + (int) Math.round(Math.sin((c.t + i * 13) / 18.0) * 3), by = 46 + (i * 17) % 18 + (int) Math.round(Math.sin((c.t + i * 7) / 24.0) * 2); c.b(bx, by, 5, bc[i % 6]); c.r(bx - 2, by - 3, 2, 2, 0x99FFFFFF); c.tri(bx, by + 5, 3, 3, bc[i % 6]); c.ln(bx, by + 8, bx + (i % 2 == 0 ? 2 : -2), by + 22, 0xAA8A7A8A); }
        c.r(130, FL + 22, 2, 22, 0xFF8A8AA0); c.rr(118, FL + 14, 26, 10, 5, 0xFFFF9AC8); c.b(131, FL + 12, 5, 0xFFFFC8E0); c.b(125, FL + 15, 4, 0xFFFFC8E0);
        c.rr(230, FL + 18, 36, 20, 3, 0xFFFFD84D); c.r(230, FL + 18, 36, 3, 0xFFE5484D); c.b(238, FL + 40, 3, 0xFF3A2A3A); c.b(258, FL + 40, 3, 0xFF3A2A3A); c.b(236, FL + 12, 6, 0xFFFFB6D2); c.b(246, FL + 10, 7, 0xFFC8E8FF); c.b(256, FL + 12, 6, 0xFFFFE8A0);
        for (int i = 0; i < 40; i++) c.r((i * 37 + c.t / 3 * (1 + i % 2)) % W, (i * 23 + c.t * (1 + i % 3) / 2) % (FL + 40), 2, 1, bc[i % 6]);
        for (int i = 0; i < 4; i++) bird(c, (c.t / 3 + i * 80) % (W + 20) - 10, 52 + i * 8, 0xFF4A5A7A);
    }

    // ---------- 17: the Quiet Place ----------
    private static void quiet(C c) {
        c.grad(0, 0, W, FL, 0xFF070620, 0xFF2E2268);
        stars(c, 70, 78, 17);
        // a thin glowing galaxy band
        for (int x = 0; x < W; x++) { int gy = 12 + (int) Math.round(Math.sin(x / 40.0) * 10) + x / 8; c.r(x, gy, 1, 6 + (x % 7) / 3, 0x1CB79CFF); c.r(x, gy + 2, 1, 2, 0x22FFFFFF); }
        c.b(236, 30, 17, 0x14FFF0C0); c.b(236, 30, 12, 0x22FFF0C0); c.b(236, 30, 10, 0xFFFFF0C0); c.b(240, 27, 9, 0xFF130F3A);
        for (int i = 0; i < 5; i++) c.ln(30 + i * 9, 22 + (i % 2) * 6, 39 + (i + 1) * 9, 22 + ((i + 1) % 2) * 6, 0x22FFFFFF);       // a constellation
        // layers of hills, very dark, with a lit house far away
        hills(c, FL - 12, 26, 0xFF191246, 0.028, 0.3, 0, W);
        hills(c, FL - 4, 16, 0xFF110C34, 0.045, 1.9, 0, W);
        c.r(240, FL - 20, 10, 8, 0xFF0A0722); c.tri(245, FL - 27, 14, 8, 0xFF0A0722); c.r(242, FL - 17, 2, 3, 0xFFFFD866);
        for (int i = 0; i < 9; i++) pine(c, 8 + i * 38 + (i % 2) * 6, FL - 2, 30 + (i * 9) % 12, 14, 0xFF0A0826, false);
        // the lake and the reflections
        c.grad(0, FL - 2, W, H - FL + 2, 0xFF161040, 0xFF0C0828);
        for (int i = 0; i < 26; i++) { int sx = (i * 53 + 17) % (W - 2), sy = FL + 4 + (i * 7) % 40; if ((c.t / 14 + i) % 4 != 0) c.r(sx, sy, 1, 1, 0x55B79CFF); }
        c.r(228, FL + 4, 16, 2, 0x44FFF0C0); c.r(230, FL + 8, 12, 1, 0x33FFF0C0); c.r(232, FL + 12, 8, 1, 0x22FFF0C0);
        for (int i = 0; i < 7; i++) c.o(60 + (i * 41 + c.t / 6) % 200, FL + 10 + i * 6, 12 + i, 1, 0x18B79CFF);
        // reeds and cattails on both shores, a small boat, a lantern and a bench
        for (int s = 0; s < 2; s++) for (int i = 0; i < 10; i++) { int rx = s == 0 ? 6 + i * 4 : 262 + i * 3, rh = 10 + (i * 5) % 12; int sway = (int) Math.round(Math.sin((c.t + i * 9) / 28.0)); c.r(rx + sway, FL + 20 - rh, 1, rh, 0xFF0E1A2E); if (i % 3 == 0) c.r(rx + sway - 1, FL + 20 - rh - 4, 3, 5, 0xFF2A1810); }
        c.rr(100, FL + 24, 30, 6, 3, 0xFF2A1F5C); c.r(100, FL + 24, 30, 1, 0xFF4A3A8A); c.r(114, FL + 14, 1, 10, 0xFF2A1F5C); c.tri(120, FL + 15, 10, 9, 0xFF3A2C7A);
        int lx = 62, ly = FL - 26;
        c.r(lx, ly, 1, 40, 0xFF3A2C7A); c.r(lx - 4, ly, 5, 1, 0xFF3A2C7A); c.rr(lx - 8, ly + 1, 7, 8, 2, 0xFFFFE680); c.r(lx - 6, ly + 3, 3, 4, 0xFFFFF8C0);
        int fl2 = 9 + (c.t / 8) % 3;
        c.b(lx - 5, ly + 5, fl2 + 6, 0x12FFD866); c.b(lx - 5, ly + 5, fl2, 0x22FFD866); c.b(lx - 5, ly + 5, 6, 0x33FFD866);
        c.o(lx - 5, FL + 36, 14, 2, 0x22FFD866);
        c.r(170, FL + 28, 28, 3, 0xFF2A1F5C); c.r(170, FL + 31, 2, 6, 0xFF2A1F5C); c.r(196, FL + 31, 2, 6, 0xFF2A1F5C); c.r(170, FL + 22, 28, 2, 0xFF2A1F5C); c.r(170, FL + 22, 2, 7, 0xFF2A1F5C); c.r(196, FL + 22, 2, 7, 0xFF2A1F5C);
        // the drifting star, fireflies and slow lights
        int sx2 = 150 + (int) Math.round(Math.sin(c.t / 30.0) * 8), sy2 = 42 + (int) Math.round(Math.sin(c.t / 17.0) * 3);
        c.r(sx2, sy2 - 4, 1, 9, 0xFFFFD866); c.r(sx2 - 4, sy2, 9, 1, 0xFFFFD866); c.r(sx2 - 1, sy2 - 1, 3, 3, 0xFFFFF0A0); c.b(sx2, sy2, 8, 0x14FFD866); c.r(sx2, FL + 6, 1, 4, 0x55FFD866);
        for (int i = 0; i < 14; i++) { int ffx = (int) (20 + (i * 71) % 260 + Math.sin(c.t / 44.0 + i) * 12), ffy = (int) (FL - 16 + (i * 37) % 52 + Math.cos(c.t / 36.0 + i * 2) * 8); int a = 0x70 + (int) (Math.sin(c.t / 14.0 + i) * 0x60); c.r(ffx, ffy, 2, 2, (a << 24) | 0xB79CFF); c.r(ffx - 1, ffy - 1, 4, 4, ((a / 4) << 24) | 0xB79CFF); }
    }
}
