package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/** The pictures of the park (sky, hills, trees, pond, playground ...). Pure drawing; the park keeps the walking and the clicks. */
final class ParkScenes {
    private ParkScenes() {}

    static final int W = 300;

    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(1 - (dy * dy) / (double) (ry * ry + 1)));
            rect(g, cx - dx, cy + dy, dx * 2 + 1, 1, argb);
        }
    }

    private static int mix(int a, int b, float f) {
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int gr = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }

    private static void ln(GuiGraphics g, int x0, int y0, int x1, int y1, int argb) {
        int n = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)));
        for (int i = 0; i <= n; i++) rect(g, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, 1, 1, argb);
    }

    /** Everything from the sky down to the grass and what stands on it. part: 0 day, 1 dusk, 2 night. */
    static void back(GuiGraphics g, int part, int t) {
        sky(g, part, t);
        hills(g, part, t);
        g.fillGradient(0, 62, W, 166, part == 2 ? 0xFF3E8A5A : 0xFF86D68A, part == 2 ? 0xFF2A6A44 : 0xFF4DB35E);
        for (int i = 0; i < 9; i++) rect(g, 0, 70 + i * 10, W, 4, 0x14FFFFFF);       // mown stripes
        for (int i = 0; i < 40; i++) {                                                // grass tufts
            int tx = (i * 71 + 13) % (W - 6) + 3, ty = 70 + (i * 37) % 84;
            rect(g, tx, ty, 1, 2, 0x55306A3A); rect(g, tx + 2, ty + 1, 1, 2, 0x55306A3A);
        }
        path(g);
        fence(g, 0, 84, 7);
        fence(g, 244, 84, 7);
        pond(g, t);
        picnic(g);
        swings(g, t);
        bushes(g);
        flowerBeds(g, t);
        tree(g, 24, 100, 28, 0xFF3FA55A, 0xFF4FB86A, 0xFF7ADC8A);
        tree(g, 282, 96, 24, 0xFF3FA55A, 0xFF4FB86A, 0xFF7ADC8A);
        smallTree(g, 108, 76);
        smallTree(g, 176, 74);
        lamp(g, 100, 100, part);
        lamp(g, 204, 108, part);
        bench(g);
    }

    private static void sky(GuiGraphics g, int part, int t) {
        g.fillGradient(0, 0, W, 66, part == 2 ? 0xFF121838 : part == 1 ? 0xFFFFA76A : 0xFF8FD3FF, part == 2 ? 0xFF2C3E78 : part == 1 ? 0xFFFFD9A0 : 0xFFDDF4FF);
        if (part == 2) {
            for (int i = 0; i < 32; i++) if ((t / 20 + i) % 5 != 0) {
                int sx = (i * 67 + 11) % W, sy = (i * 29) % 56 + 2;
                rect(g, sx, sy, 1, 1, 0xFFFFFFFF);
                if (i % 7 == 0) { rect(g, sx - 1, sy, 3, 1, 0x88FFFFFF); rect(g, sx, sy - 1, 1, 3, 0x88FFFFFF); }
            }
            disc(g, 262, 22, 12, 0x22F4F1D8);
            disc(g, 262, 22, 10, 0xFFF4F1D8); disc(g, 266, 19, 9, 0xFF121838);
            rect(g, 257, 25, 2, 2, 0x44FFFFFF);
        } else {
            int sy = part == 1 ? 40 : 22;
            disc(g, 262, sy, 17, part == 1 ? 0x33FF8A4A : 0x33FFE066);
            disc(g, 262, sy, 11, part == 1 ? 0xFFFF8A4A : 0xFFFFE066);
            disc(g, 260, sy - 3, 4, part == 1 ? 0xFFFFB27A : 0xFFFFF3A0);
            if (part == 0) for (int i = 0; i < 8; i++) {                               // little rays
                double a = i * Math.PI / 4 + t / 120.0;
                rect(g, 262 + (int) Math.round(Math.cos(a) * 16), sy + (int) Math.round(Math.sin(a) * 16), 2, 2, 0x88FFE680);
            }
        }
        for (int i = 0; i < 4; i++) {                                                  // clouds that drift, with shaded bellies
            int cx = (int) ((t * (0.10 + i * 0.04) + i * 85) % (W + 90)) - 45, cy = 12 + i * 10 + (i % 2) * 4;
            int c = part == 2 ? 0x55C0C8E8 : 0xDDFFFFFF, sh = part == 2 ? 0x558890B8 : 0xCCD6E6F4;
            disc(g, cx, cy + 2, 7, sh); disc(g, cx + 10, cy + 4, 6, sh); disc(g, cx - 10, cy + 4, 5, sh);
            disc(g, cx, cy, 6, c); disc(g, cx + 8, cy + 2, 7, c); disc(g, cx - 8, cy + 3, 5, c); disc(g, cx + 15, cy + 4, 4, c);
        }
        if (part != 2) for (int i = 0; i < 3; i++) {                                    // birds
            int bx = (int) ((t * 0.5 + i * 60) % (W + 40)) - 20, by = 28 + i * 7 + (int) Math.round(Math.sin(t / 14.0 + i) * 2);
            boolean up = (t / 8 + i) % 2 == 0;
            rect(g, bx - 2, by + (up ? 0 : 1), 2, 1, 0xFF3A4A6A); rect(g, bx, by + 1, 1, 1, 0xFF3A4A6A); rect(g, bx + 1, by + (up ? 0 : 1), 2, 1, 0xFF3A4A6A);
        }
    }

    private static void hills(GuiGraphics g, int part, int t) {
        int far = part == 2 ? 0xFF2E6A58 : 0xFF9ADCA0, mid = part == 2 ? 0xFF2A7A58 : 0xFF7ACB7A, near = part == 2 ? 0xFF30885E : 0xFF6BC070;
        disc(g, 130, 90, 50, far);
        disc(g, 60, 78, 40, mid); disc(g, 200, 84, 46, near);
        disc(g, 290, 86, 30, mid);
        // a windmill on the far hill
        int wx = 134, wy = 44;
        rect(g, wx - 3, wy, 7, 16, part == 2 ? 0xFF8A8AA8 : 0xFFF2E6D2);
        rect(g, wx - 4, wy - 3, 9, 4, part == 2 ? 0xFF6A4A5A : 0xFFC85A4A);
        rect(g, wx - 1, wy + 9, 3, 7, part == 2 ? 0xFF4A3A4A : 0xFF8A5A3A);
        double a = t / 30.0;
        for (int i = 0; i < 4; i++) {
            double aa = a + i * Math.PI / 2;
            ln(g, wx, wy - 1, wx + (int) Math.round(Math.cos(aa) * 11), wy - 1 + (int) Math.round(Math.sin(aa) * 11), part == 2 ? 0xFFB0B0C8 : 0xFFFFFFFF);
        }
        // far houses
        house(g, 168, 62, part);
        house(g, 82, 60, part);
        // far tree line
        for (int i = 0; i < 10; i++) disc(g, 6 + i * 30 + (i % 3) * 4, 64, 6 + (i % 2) * 2, part == 2 ? 0xFF1F5A44 : 0xFF58B06A);
    }

    private static void house(GuiGraphics g, int x, int y, int part) {
        rect(g, x, y, 12, 8, part == 2 ? 0xFF8A7A90 : 0xFFFFE9C8);
        for (int r = 0; r < 5; r++) rect(g, x - 1 + r, y - 5 + r, 14 - 2 * r, 1, part == 2 ? 0xFF6A3A4A : 0xFFD8584A);
        rect(g, x + 5, y + 3, 3, 5, 0xFF8A5A3A);
        rect(g, x + 1, y + 2, 3, 3, part == 0 ? 0xFFBEE6FF : 0xFFFFE680);
        rect(g, x + 9, y - 6, 2, 4, 0xFF8A5A3A);
    }

    private static void path(GuiGraphics g) {
        oval(g, 150, 138, 96, 9, 0x44C9A678);
        oval(g, 150, 136, 70, 6, 0x55E6CA9A);
        for (int y = 66; y < 140; y += 2) {                                             // winding path up to the bench
            int cx = 136 + (int) Math.round(Math.sin(y / 11.0) * 6) + (140 - y) / 12;
            int w = 5 + (y - 66) / 5;
            rect(g, cx - w, y, w * 2, 2, 0x88E6CA9A);
            rect(g, cx - w, y, 1, 2, 0x55B89A6A); rect(g, cx + w - 1, y, 1, 2, 0x55B89A6A);
        }
        for (int i = 0; i < 10; i++) rect(g, 100 + (i * 37) % 100, 130 + (i * 13) % 12, 2, 1, 0x88B89A6A);    // pebbles
    }

    private static void fence(GuiGraphics g, int x, int y, int n) {
        rect(g, x, y + 3, n * 8, 1, 0xFFF4E6CC); rect(g, x, y + 8, n * 8, 1, 0xFFF4E6CC);
        for (int i = 0; i <= n; i++) {
            rect(g, x + i * 8, y, 2, 13, 0xFFFFF4DC);
            rect(g, x + i * 8, y, 2, 1, 0xFFFFFFFF);
            rect(g, x + i * 8 + 1, y + 13, 1, 2, 0x33000000);
        }
    }

    private static void pond(GuiGraphics g, int t) {
        oval(g, 236, 131, 40, 12, 0xFFB89A6A);                                         // the shore
        oval(g, 236, 130, 37, 11, 0xFF5FB8E8);
        oval(g, 236, 128, 34, 10, 0xFF6FC7F0);
        oval(g, 236, 127, 30, 7, 0xFF9ADCF8);
        rect(g, 216, 124, 10, 1, 0x66FFFFFF); rect(g, 244, 130, 12, 1, 0x55FFFFFF);
        int r = (t / 18) % 4;
        rect(g, 226 + r * 3, 126, 6, 1, 0x88FFFFFF);
        for (int i = 0; i < 3; i++) {                                                   // lily pads
            int lx = 218 + i * 17, ly = 128 + (i % 2) * 3;
            oval(g, lx, ly, 4, 2, 0xFF3FA55A); rect(g, lx, ly, 3, 1, 0xFF6FC7F0);
            if (i == 1) { rect(g, lx - 1, ly - 2, 3, 2, 0xFFFFB6D2); rect(g, lx, ly - 3, 1, 1, 0xFFFFFFFF); }
        }
        // a duck that swims to and fro
        int dx = 236 + (int) Math.round(Math.sin(t / 50.0) * 20), dy = 123;
        boolean right = Math.cos(t / 50.0) > 0;
        rect(g, dx - 3, dy, 7, 3, 0xFFFFFFFF); rect(g, dx - 2, dy - 1, 4, 1, 0xFFFFFFFF);
        int hx = right ? dx + 3 : dx - 4;
        rect(g, hx, dy - 3, 2, 3, 0xFF2E8A4A); rect(g, right ? hx + 2 : hx - 1, dy - 2, 1, 1, 0xFFF59A3A);
        rect(g, dx - 4, dy + 3, 9, 1, 0x55FFFFFF);
        // stones and reeds
        for (int i = 0; i < 7; i++) oval(g, 204 + i * 11, 138 + (i % 2), 3, 1, i % 2 == 0 ? 0xFFA8A8B8 : 0xFFC8C8D8);
        for (int i = 0; i < 4; i++) {
            int rx = 202 + i * 3, sw = (int) Math.round(Math.sin(t / 25.0 + i) * 1);
            rect(g, rx + sw, 112 + i % 2 * 2, 1, 16 - i % 2 * 2, 0xFF3A8A4A); rect(g, rx + sw, 110 + i % 2 * 2, 2, 4, 0xFF8A5A3A);
        }
    }

    private static void picnic(GuiGraphics g) {
        int x = 74, y = 130;
        for (int r = 0; r < 14; r++) for (int c = 0; c < 26; c++) rect(g, x + c, y + r, 1, 1, ((c / 4 + r / 4) % 2 == 0) ? 0xFFFF7A8A : 0xFFFFE9EE);
        rect(g, x, y + 14, 26, 1, 0x33000000);
        rect(g, x + 4, y + 2, 7, 5, 0xFFB8783A); rect(g, x + 4, y + 2, 7, 1, 0xFFD89A5A); rect(g, x + 7, y - 1, 1, 3, 0xFF8A5A3A);
        disc(g, x + 18, y + 6, 3, 0xFFE5484D); rect(g, x + 18, y + 2, 1, 2, 0xFF3A8A4A);   // an apple
        rect(g, x + 14, y + 9, 5, 2, 0xFFF4F4F4);
    }

    private static void swings(GuiGraphics g, int t) {
        int x = 20, y = 108;
        rect(g, x, y, 2, 24, 0xFFE5484D); rect(g, x + 38, y, 2, 24, 0xFFE5484D);
        ln(g, x, y, x + 8, y + 24, 0xFFC03840); ln(g, x + 39, y, x + 31, y + 24, 0xFFC03840);
        rect(g, x - 1, y - 1, 42, 3, 0xFFFFB84A);
        for (int i = 0; i < 2; i++) {
            int sx = x + 10 + i * 18, sw = (int) Math.round(Math.sin(t / 30.0 + i * 1.5) * 4);
            ln(g, sx, y + 2, sx + sw, y + 18, 0xFF8A8A98);
            rect(g, sx - 3 + sw, y + 18, 7, 2, 0xFF8A5A3A);
        }
        oval(g, x + 20, y + 26, 22, 3, 0x22000000);
    }

    private static void bushes(GuiGraphics g) {
        int[][] b = {{8, 88}, {60, 82}, {128, 76}, {162, 74}, {230, 82}, {296, 100}};
        for (int[] p : b) {
            disc(g, p[0], p[1], 6, 0xFF3FA55A); disc(g, p[0] + 6, p[1] + 2, 5, 0xFF4FB86A); disc(g, p[0] - 5, p[1] + 2, 4, 0xFF3A9A52);
            rect(g, p[0] - 2, p[1] - 2, 2, 1, 0xFF8ADC96);
            rect(g, p[0] + 3, p[1], 1, 1, 0xFFFF8FB8); rect(g, p[0] - 4, p[1] + 3, 1, 1, 0xFFFFF3B0);
        }
    }

    private static void flowerBeds(GuiGraphics g, int t) {
        int[] cols = {0xFFFF8FB8, 0xFFFFF3B0, 0xFFFFFFFF, 0xFFB38AFF, 0xFFFF9A6A};
        for (int i = 0; i < 36; i++) {
            int fx = (i * 83 + 17) % (W - 20) + 10, fy = 86 + (i * 47) % 62;
            int sw = (int) Math.round(Math.sin(t / 40.0 + i) * (i % 3 == 0 ? 1 : 0));
            rect(g, fx + sw, fy + 2, 1, 3, 0xFF2E8A4A);
            int c = cols[i % cols.length];
            rect(g, fx - 1 + sw, fy, 3, 1, c); rect(g, fx + sw, fy - 1, 1, 3, c); rect(g, fx + sw, fy, 1, 1, 0xFFF5B800);
        }
        for (int i = 0; i < 4; i++) {                                                   // mushrooms
            int mx = 40 + i * 70, my = 146 - (i % 2) * 4;
            rect(g, mx, my, 2, 3, 0xFFF4F4F4); rect(g, mx - 2, my - 2, 6, 2, 0xFFE5484D); rect(g, mx - 1, my - 2, 1, 1, 0xFFFFFFFF); rect(g, mx + 2, my - 2, 1, 1, 0xFFFFFFFF);
        }
    }

    private static void tree(GuiGraphics g, int cx, int base, int sz, int dark, int mid, int light) {
        oval(g, cx, base + 2, 22, 4, 0x33000000);
        rect(g, cx - 4, base - sz, 8, sz, 0xFF8A5A3A);
        rect(g, cx + 1, base - sz, 3, sz, 0xFF6A4228);
        rect(g, cx - 3, base - sz + 6, 1, 3, 0xFF5A3A22);
        rect(g, cx - 7, base - 2, 14, 2, 0xFF8A5A3A);
        disc(g, cx, base - sz - 8, 15, dark);
        disc(g, cx - 9, base - sz - 2, 10, mid);
        disc(g, cx + 9, base - sz - 2, 10, mid);
        disc(g, cx - 4, base - sz - 12, 5, light);
        disc(g, cx + 6, base - sz - 8, 3, light);
        for (int i = 0; i < 5; i++) rect(g, cx - 12 + i * 6, base - sz - 4 + (i % 2) * 6, 2, 2, 0x33000000);  // leaf shade
        rect(g, cx - 1, base - sz - 18, 1, 1, 0xFFFFFFFF);
    }

    private static void smallTree(GuiGraphics g, int cx, int base) {
        oval(g, cx, base + 1, 8, 2, 0x22000000);
        rect(g, cx - 1, base - 8, 3, 9, 0xFF8A5A3A);
        disc(g, cx, base - 13, 7, 0xFF3FA55A); disc(g, cx - 3, base - 11, 4, 0xFF4FB86A); disc(g, cx - 1, base - 16, 2, 0xFF7ADC8A);
    }

    private static void lamp(GuiGraphics g, int x, int y, int part) {
        rect(g, x, y - 22, 2, 22, 0xFF4A4A5A); rect(g, x - 2, y, 6, 2, 0xFF3A3A4A);
        rect(g, x - 3, y - 27, 8, 5, 0xFF4A4A5A);
        boolean on = part != 0;
        rect(g, x - 2, y - 26, 6, 3, on ? 0xFFFFF0A0 : 0xFFDDEEFF);
        if (on) {
            disc(g, x + 1, y - 24, 12, 0x1AFFF0A0);
            disc(g, x + 1, y - 24, 7, 0x22FFF0A0);
            oval(g, x + 1, y + 1, 16, 4, 0x22FFF0A0);
        }
    }

    private static void bench(GuiGraphics g) {
        oval(g, 136, 92, 22, 3, 0x22000000);
        rect(g, 118, 78, 36, 4, 0xFF8A5A3A); rect(g, 120, 82, 3, 8, 0xFF6A4228); rect(g, 149, 82, 3, 8, 0xFF6A4228);
        rect(g, 118, 72, 36, 3, 0xFF9A6A44);
        rect(g, 118, 75, 36, 1, 0xFF6A4228);
        rect(g, 118, 78, 36, 1, 0xFFAA7A54);
        rect(g, 117, 71, 2, 11, 0xFF6A4228); rect(g, 153, 71, 2, 11, 0xFF6A4228);
    }
}
