package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.function.Consumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * A place of the map, seen close: the picture of the place with the pet standing in it and two buttons, "Play"
 * (the little game of the place, see {@link PetActs}; not every place has one) and "Trip" (the ten minutes away
 * with the finds for the album, see {@link Trip}). While a game runs this screen hands everything to it.
 */
final class PetPlace {
    private static final int W = App.W, H = App.H, HEAD = MapArt.HEAD;
    private static final int TEXT = 0xFF3A2A3A;
    private static final int BY = H - 24, BH = 18;                       // the buttons

    private final int dest;
    private final Runnable back, trip;
    private final Supplier<String> tripBlock, actBlock;
    private final Supplier<ComputerColor> color;
    private final IntSupplier stage;
    private final Consumer<Float> snd;
    private final PetActs.Ctx ctx;
    private PetActs.Act act;
    private int ticks, toastT;
    private String toast = "";

    PetPlace(int dest, Runnable back, Runnable trip, PetActs.Reward reward, Supplier<ComputerColor> color, IntSupplier stage,
             Supplier<String> tripBlock, Supplier<String> actBlock, Consumer<Float> snd) {
        this.dest = dest;
        this.back = back;
        this.trip = trip;
        this.color = color;
        this.stage = stage;
        this.tripBlock = tripBlock;
        this.actBlock = actBlock;
        this.snd = snd;
        this.ctx = new PetActs.Ctx(() -> act = null, reward, color, stage, snd);
    }

    private int n() { return PetActs.count(dest); }

    /** The buttons stand in one row: the activities of the place, then the trip. */
    private int total() { return n() + 1; }
    private int bw() { return total() == 1 ? 132 : (W - 12 - 6 * (total() - 1) - 12) / total(); }
    private int bx(int i) { return total() == 1 ? W / 2 - 66 : 6 + i * (bw() + 6) + 3; }
    private int tripX() { return bx(n()); }

    void tick() {
        ticks++;
        if (toastT > 0) toastT--;
        if (act != null) act.tick();
    }

    boolean key(int keyCode) {
        if (act != null) return act.key(keyCode);
        if (keyCode == 256) { back.run(); return true; }
        return false;
    }

    boolean click(int mx, int my, int button) {
        if (act != null) return act.click(mx, my, button);
        for (int i = 0; i < n(); i++) if (App.in(mx, my, bx(i), BY, bw(), BH)) {
            String why = actBlock.get();
            if (!why.isEmpty()) { say(why); return true; }
            act = PetActs.create(dest, i, ctx);
            snd.accept(1.6F);
            return true;
        }
        if (App.in(mx, my, tripX(), BY, bw(), BH)) {
            String why = tripBlock.get();
            if (!why.isEmpty()) { say(why); return true; }
            trip.run();
        }
        return true;
    }

    private void say(String key) {
        toast = PetActs.t(key);
        toastT = 150;
        snd.accept(0.8F);
    }

    void render(GuiGraphics g, int mx, int my) {
        if (act != null) { act.render(g, mx, my); return; }
        Font f = Minecraft.getInstance().font;
        TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
        int floor = HEAD + (H - HEAD) * 70 / 100;
        PetActs.pet(g, color.get(), W / 2, floor + 14, 0.7F, ticks, stage.getAsInt(), 2);

        // the header: back, the name of the place
        Skin.rect(g, 0, 0, W, HEAD, 0xFF5A4A86);
        String name = PetActs.t("cutemod.trip.dest." + dest);
        Skin.str(g, f, name, W / 2 - f.width(name) / 2, 5, 0xFFFFFFFF, false);

        // what the button under the mouse does, in a small label over the row (the trip when nothing is hovered)
        String cap = PetActs.t("cutemod.place.trip.sub");
        for (int i = 0; i < n(); i++) if (App.in(mx, my, bx(i), BY, bw(), BH)) cap = PetActs.t(PetActs.descKey(dest, i));
        caption(g, f, cap, 0, W);
        for (int i = 0; i < n(); i++) {
            boolean ok = actBlock.get().isEmpty();
            String label = f.plainSubstrByWidth(PetActs.t(PetActs.nameKey(dest, i)), bw() - 4);
            PetActs.btn(g, f, label, bx(i), BY, bw(), BH, App.in(mx, my, bx(i), BY, bw(), BH), ok ? (i == 0 ? 0xFF4CAF50 : i == 1 ? 0xFFE8803A : 0xFFB57BD6) : 0xFF9A90A8);
        }
        boolean tok = tripBlock.get().isEmpty();
        PetActs.btn(g, f, f.plainSubstrByWidth(PetActs.t("cutemod.place.trip"), bw() - 4), tripX(), BY, bw(), BH, App.in(mx, my, tripX(), BY, bw(), BH), tok ? 0xFF4D96FF : 0xFF9A90A8);
        if (toastT > 0) {
            int sw = f.width(toast) + 14, sx = W / 2 - sw / 2;
            Skin.rect(g, sx, BY - 36, sw, 13, 0xF0FFE4E4);
            Skin.str(g, f, toast, sx + 7, BY - 33, 0xFFB02A30, false);
        }
    }

    private static void caption(GuiGraphics g, Font f, String s, int x, int w) {
        String c = f.plainSubstrByWidth(s, w - 6);
        int cw = f.width(c) + 8, cx = x + (w - cw) / 2;
        Skin.rect(g, cx, BY - 13, cw, 11, 0xCC3A2A5A);
        Skin.str(g, f, c, cx + 4, BY - 11, 0xFFFFFFFF, false);
    }
}
