package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.data.PetWear;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Pet Stats: a card with everything about your pet and your play: age, character, how often you fed, played and
 * petted it, plus fish, harvests, stickers, photos, outfits and coins. It only reads, nothing is saved here.
 */
public class PetStatsApp extends KitApp {
    @Override protected int accent() { return 0xFFE8A04A; }

    @Override protected String id() { return "petstats"; }

    private ComputerColor species() {
        ComputerColor c = PetApp.speciesOf(shell.color());
        return c == null ? shell.color() : c;
    }

    private static int stickers() {
        try {
            String s = Store.read("stickers");
            if (s == null) return 0;
            int n = 0;
            for (String c : s.split("\\|")[2].split(",")) if (Integer.parseInt(c) > 0) n++;
            return n;
        } catch (Exception e) {
            return 0;
        }
    }

    private static int photos() {
        String s = Store.read("photos");
        if (s == null) return 0;
        int n = 0;
        for (String p : s.split(";", -1)) if (p.split(",", -1).length == 5 && !p.endsWith(",")) n++;
        return n;
    }

    private static int outfits() {
        int n = 0;
        for (PetWear.Item it : PetWear.ALL) if (Progress.owned(it.id())) n++;
        return n;
    }

    private static String age(long sec) {
        long d = sec / 86400, h = sec / 3600 % 24, m = sec / 60 % 60;
        return d > 0 ? t("cutemod.stats.age.d", d, h) : h > 0 ? t("cutemod.stats.age.h", h, m) : t("cutemod.stats.age.m", m);
    }

    private void row(GuiGraphics g, Font f, int col, int line, String label, String value) {
        int x = col == 0 ? 112 : 206, y = 24 + line * 18;
        rect(g, x - 3, y - 3, 90, 18, 0xCCFFFFFF);
        rect(g, x - 3, y - 3, 2, 18, accent());
        rect(g, x - 3, y + 15, 90, 1, 0x22000000);
        CuteFont.draw(g, f, label, x, y, MUTED, false);
        CuteFont.draw(g, f, value, x, y + 10, TEXT, false);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        header(g, f);
        ComputerColor spc = species();
        PetBlob.Info info = PetBlob.parse(Store.read("pet_" + spc.id));
        // the portrait
        PetShops.trophies(g, 6, 20, 100, 112, ticks);
        if (info == null) {
            center(g, f, t("cutemod.stats.nopet"), 56, 70, MUTED);
            return;
        }
        int stage = info.stage();
        float sc = 1.1F * PetArt.scaleOf(stage);
        int cx = 56, floor = 112, bob = (int) Math.round(Math.sin(ticks / 18.0) * 1.5);
        g.pose().pushPose();
        g.pose().translate(cx, floor, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-cx, -floor, 0);
        PetArt.draw(g, spc, cx, floor - 28 + bob, 2, ticks, false, info.sick(), stage, Progress.equipped(), Progress.equippedBody());
        g.pose().popPose();
        center(g, f, t("cutemod.pet.name." + spc.id), 56, 120, TEXT);
        CuteFont.draw(g, f, t("cutemod.stats.card", t("cutemod.pet.stage." + stage), info.sick() ? t("cutemod.pet.sick.label") : t("cutemod.pet.trait." + info.trait())), 112, 20, TEXT, false);
        CuteFont.draw(g, f, t("cutemod.stats.age", age(info.ageSec())), 112, 30, MUTED, false);
        row(g, f, 0, 1, t("cutemod.stats.fed"), Integer.toString(info.feed()));
        row(g, f, 1, 1, t("cutemod.stats.played"), Integer.toString(info.play()));
        row(g, f, 0, 2, t("cutemod.stats.slept"), Integer.toString(info.sleep()));
        row(g, f, 1, 2, t("cutemod.stats.petted"), Integer.toString(info.pet()));
        row(g, f, 0, 3, t("cutemod.stats.games"), Integer.toString(Progress.count("games")));
        row(g, f, 1, 3, t("cutemod.stats.fish"), Integer.toString(Progress.count("fish_caught")));
        row(g, f, 0, 4, t("cutemod.stats.harvest"), Integer.toString(Progress.count("farm_harvest")));
        row(g, f, 1, 4, t("cutemod.stats.earned"), Integer.toString(Progress.count("earned")));
        row(g, f, 0, 5, t("cutemod.stats.outfits"), Integer.toString(outfits()));
        row(g, f, 1, 5, t("cutemod.stats.stickers"), stickers() + " / 30");
        row(g, f, 0, 6, t("cutemod.stats.photos"), photos() + " / 6");
        row(g, f, 1, 6, t("cutemod.stats.level"), Season.level() + " / " + Season.LEVELS);
    }
}
