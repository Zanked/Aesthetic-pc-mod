package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * More activities of the map places (the first ones are in {@link PetActs}): the strongman bell of the amusement park,
 * the popcorn catch of the cinema, the halls and the guide quiz of the museum, the fireflies of the camp and the moles and
 * lucky boxes of the fair. Which place has which is in {@link PetActs#count} and {@link PetActs#create}; the texts are in the
 * lang files: cutemod.act.name.D.I, cutemod.act.desc.D.I and cutemod.act.s / p / h / q / f / w / b.*.
 */
final class PetActs2 {
    private PetActs2() {}

    private static final int W = PetActs.W, H = PetActs.H, HEAD = PetActs.HEAD, WHITE = 0xFFFFFFFF, TEXT = 0xFF3A2A3A;

    private static String t(String key, Object... a) { return PetActs.t(key, a); }

    private static void centered(GuiGraphics g, Font f, String s, int cx, int y, int color) {
        Skin.str(g, f, s, cx - f.width(s) / 2, y, color, true);
    }

    // =====================================================================================================
    //  AMUSEMENT PARK 2. THE STRONGMAN BELL: stop the swinging power bar near the top, five rounds, it gets faster
    // =====================================================================================================
    static final class Strongman extends PetActs.Act {
        private static final int ROUNDS = 5, TOP = 34, BOT = 138;
        private int round = 1, state, wait, points, last;                // state 0 swinging, 1 the puck flies
        private double pos, dir = 1, puck, target;

        Strongman(int dest, PetActs.Ctx c) { super(dest, c); }

        private double speed() { return 0.010 + round * 0.003; }

        private void reset() { round = 1; state = 0; points = 0; last = 0; pos = 0; dir = 1; puck = 0; over = false; paid = false; }

        @Override void tick() {
            super.tick();
            if (over) return;
            if (state == 0) {
                pos += dir * speed();
                if (pos >= 1) { pos = 1; dir = -1; } else if (pos <= 0) { pos = 0; dir = 1; }
            } else {
                puck += (target - puck) * 0.12;
                if (--wait <= 0) {
                    if (round >= ROUNDS) { over = true; give(Math.min(12, points), 6 + points * 2, -8, 0); }
                    else { round++; state = 0; pos = 0; dir = 1; puck = 0; }
                }
            }
        }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(mx, my);
                if (r == 1) reset(); else if (r == 2) c.exit().run();
                return true;
            }
            if (state == 0) {
                last = pos > 0.88 ? 3 : pos > 0.72 ? 2 : pos > 0.5 ? 1 : 0;
                points += last;
                target = pos; state = 1; wait = 70;
                c.snd().accept(last == 3 ? 2.0F : last > 0 ? 1.5F : 0.8F);
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
            g.fill(0, HEAD, W, H, 0x40201840);
            // the tower with the puck and the bell
            MapArt.rect(g, 138, TOP - 2, 24, BOT - TOP + 8, 0xFF5A3A2A);
            MapArt.rect(g, 142, TOP, 16, BOT - TOP, 0xFFFFF3C8);
            for (int k = 0; k <= 4; k++) MapArt.rect(g, 142, TOP + k * (BOT - TOP) / 5, 16, 1, 0xFFC8955C);
            int py = BOT - 4 - (int) Math.round(puck * (BOT - TOP - 6));
            MapArt.rect(g, 144, py, 12, 5, 0xFFE5484D); MapArt.rect(g, 144, py, 12, 1, 0xFFFF9A9E);
            boolean ring = state == 1 && last == 3 && puck > 0.8;
            MapArt.ball(g, 150, TOP - 6 + (ring && ticks % 6 < 3 ? 1 : 0), 6, 0xFFFFC832); MapArt.rect(g, 148, TOP - 12, 5, 3, 0xFFC8952C);
            if (ring) for (int k = 0; k < 4; k++) PetActs.pixelStar(g, 126 + k * 16, TOP - 16 - (ticks / 4 + k * 3) % 6, 0xFFFFE680);
            // the power bar at the right, with its zones
            int bx = 214;
            MapArt.rect(g, bx - 1, TOP - 1, 12, BOT - TOP + 2, 0xFF1A1020);
            for (int y = 0; y < BOT - TOP; y++) {
                double v = 1 - y / (double) (BOT - TOP);
                MapArt.rect(g, bx, TOP + y, 10, 1, v > 0.88 ? 0xFF6BCB77 : v > 0.72 ? 0xFFFFD84D : v > 0.5 ? 0xFFFF9A3C : 0xFF8A7AA8);
            }
            int my2 = BOT - (int) Math.round(pos * (BOT - TOP));
            MapArt.rect(g, bx - 4, my2 - 1, 18, 3, WHITE); MapArt.rect(g, bx - 4, my2, 18, 1, TEXT);
            // the pet with a hammer
            PetActs.pet(g, c.color().get(), 78, H - 22, 0.62F, ticks, c.stage().getAsInt(), state == 1 && last > 0 ? 2 : 1);
            int lift = state == 0 ? (int) Math.round(Math.sin(ticks / 5.0) * 2) : 0;
            MapArt.ln(g, 100, H - 40 + lift, 118, H - 22, 0xFF8A5A3A); MapArt.rect(g, 114, H - 28, 12, 7, 0xFF8A8A9A);
            header(g, mx, my, t("cutemod.act.s.round", round, ROUNDS));
            Skin.str(g, f, t("cutemod.act.s.pts", points), 54, 5, 0xFFFFE680, false);
            String msg = state == 0 ? t("cutemod.act.s.hit") : t("cutemod.act.s.r." + last);
            centered(g, f, msg, W / 2, H - 12, WHITE);
            if (over) resultBox(g, mx, my, t("cutemod.act.s.end"), t("cutemod.act.s.pts", points), "", Math.min(12, points));
        }
    }

    // =====================================================================================================
    //  CINEMA 2. THE POPCORN CATCH: move the bucket with the mouse, golden kernels are worth more, burnt ones are not
    // =====================================================================================================
    static final class PopcornCatch extends PetActs.Act {
        private static final int DUR = 1500, BY = 138;
        /** x, y, vy, type (0 popcorn, 1 golden, 2 burnt), flash after the catch */
        private final List<double[]> ks = new ArrayList<>();
        private final Random rnd = new Random();
        private int left = DUR, score, spawn = 20, bucket = W / 2, flash;

        PopcornCatch(int dest, PetActs.Ctx c) { super(dest, c); }

        private int coins() { return Math.min(10, score / 3); }

        @Override void tick() {
            super.tick();
            if (over) return;
            left--;
            if (flash > 0) flash--;
            if (--spawn <= 0) {
                int roll = rnd.nextInt(100), type = roll < 72 ? 0 : roll < 86 ? 1 : 2;
                ks.add(new double[]{16 + rnd.nextInt(W - 32), HEAD + 6, 1.1 + rnd.nextDouble() * 0.9 + (DUR - left) / 1500.0, type, 0});
                spawn = 14 + rnd.nextInt(24);
            }
            for (Iterator<double[]> it = ks.iterator(); it.hasNext(); ) {
                double[] k = it.next();
                k[1] += k[2];
                if (k[1] >= BY - 2 && k[1] <= BY + 10 && Math.abs(k[0] - bucket) < 19) {
                    score = Math.max(0, score + (k[3] == 1 ? 3 : k[3] == 2 ? -2 : 1));
                    flash = 8;
                    c.snd().accept(k[3] == 2 ? 0.8F : k[3] == 1 ? 2.0F : 1.6F);
                    it.remove();
                } else if (k[1] > H) it.remove();
            }
            if (left <= 0) { over = true; give(coins(), 8 + Math.min(10, score / 2), -4, 6 + Math.min(10, score / 2)); }
        }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(mx, my);
                if (r == 1) { ks.clear(); left = DUR; score = 0; spawn = 20; over = false; paid = false; }
                else if (r == 2) c.exit().run();
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            if (!over) bucket = Math.max(24, Math.min(W - 24, mx));
            g.fillGradient(0, HEAD, W, H, 0xFF3A1428, 0xFF6A2A3A);
            for (int x = 0; x < W; x += 20) MapArt.rect(g, x, HEAD, 10, 3, x % 40 == 0 ? 0xFFE5484D : 0xFFFFF8F0);     // the striped awning
            for (double[] k : ks) {
                int x = (int) Math.round(k[0]), y = (int) Math.round(k[1]);
                if (k[3] == 1) PetActs.pixelStar(g, x, y, ticks / 6 % 2 == 0 ? 0xFFFFD84D : 0xFFFFE680);
                else if (k[3] == 2) { MapArt.ball(g, x, y, 3, 0xFF4A2A1A); MapArt.rect(g, x - 1, y - 1, 1, 1, 0xFF8A5A3A); }
                else { MapArt.ball(g, x, y, 3, 0xFFFFF3C8); MapArt.ball(g, x - 1, y - 1, 1, WHITE); }
            }
            int bx = bucket - 17;                                             // the bucket
            MapArt.rect(g, bx, BY, 34, 20, 0xFFFFF8F0);
            for (int k = 0; k < 4; k++) MapArt.rect(g, bx + 3 + k * 9, BY, 4, 20, 0xFFE5484D);
            MapArt.rect(g, bx, BY, 34, 2, flash > 0 ? 0xFFFFE680 : 0xFFD8D0C8);
            for (int k = 0; k < 5; k++) MapArt.ball(g, bx + 4 + k * 6, BY - 2, 3, 0xFFFFF3C8);
            header(g, mx, my, null);
            Skin.str(g, f, t("cutemod.act.g.score", score), 54, 5, 0xFFFFE680, false);
            int bw = 70, fill = bw * Math.max(0, left) / DUR;
            Skin.rect(g, W - bw - 6, 5, bw, 7, 0xFF3A2A5A);
            Skin.rect(g, W - bw - 6, 5, fill, 7, left < 300 ? 0xFFE5484D : 0xFF6BCB77);
            if (over) resultBox(g, mx, my, t("cutemod.act.p.end"), t("cutemod.act.g.score", score), "", coins());
        }
    }

    // =====================================================================================================
    //  MUSEUM 2. THE HALLS: one hall for every open place, the finds of the album stand in the cases
    // =====================================================================================================
    static final class Halls extends PetActs.Act {
        static final int HALL_COINS = 5;
        private int page;

        Halls(int dest, PetActs.Ctx c) { super(dest, c); }

        private static List<Integer> halls() {
            List<Integer> l = new ArrayList<>();
            for (int d = 0; d < Trip.DESTS; d++) if (Updates.placeOpen(d)) l.add(d);
            return l;
        }

        private static int finds(int d) {
            int n = 0;
            for (int k = 0; k < Trip.FINDS; k++) if (Trip.found(d, k)) n++;
            return n;
        }

        @Override boolean key(int keyCode) {
            if (keyCode == 263) { page--; return true; }
            if (keyCode == 262) { page++; return true; }
            return super.key(keyCode);
        }

        private int fix(int n) { return n == 0 ? 0 : Math.floorMod(page, n); }

        @Override boolean click(int mx, int my, int button) {
            List<Integer> l = halls();
            if (l.isEmpty()) return true;
            page = fix(l.size());
            if (App.in(mx, my, 6, 70, 16, 26)) { page--; c.snd().accept(1.4F); return true; }
            if (App.in(mx, my, W - 22, 70, 16, 26)) { page++; c.snd().accept(1.4F); return true; }
            int d = l.get(fix(l.size()));
            if (App.in(mx, my, 208, 96, 86, 16) && finds(d) == Trip.FINDS && Progress.count("mh_" + d) == 0) {
                Progress.setCount("mh_" + d, 1);
                Progress.earn(HALL_COINS);
                c.snd().accept(2.0F);
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            g.fillGradient(0, HEAD, W, H, 0xFFF8EEDA, 0xFFE8D4AA);
            for (int x = 0; x < W; x += 16) MapArt.rect(g, x, HEAD, 1, H - HEAD, 0x10A07A40);
            header(g, mx, my, Trip.albumCount() + "/" + Trip.albumSize());
            List<Integer> l = halls();
            if (l.isEmpty()) return;
            page = fix(l.size());
            int d = l.get(page), n = finds(d);
            // the name of the hall and the picture on the wall
            String name = t("cutemod.act.h.hall", page + 1, t("cutemod.trip.dest." + d));
            Skin.str(g, f, f.plainSubstrByWidth(name, W - 60), W / 2 - Math.min(f.width(name), W - 60) / 2, 21, TEXT, false);
            MapArt.rect(g, 96, 33, 108, 74, 0xFFC8952C);
            MapArt.rect(g, 98, 35, 104, 70, 0xFFFFFBF0);
            TripArt.scene(g, 100, 37, 100, 66, d, ticks);
            // arrows
            for (int s = 0; s < 2; s++) {
                int ax = s == 0 ? 6 : W - 22;
                boolean hv = App.in(mx, my, ax, 70, 16, 26);
                Skin.rect(g, ax, 70, 16, 26, hv ? 0xFFB08AE0 : 0xFF9A7AD0);
                Skin.str(g, f, s == 0 ? "<" : ">", ax + 5, 79, WHITE, true);
            }
            // the reward of the hall
            String info;
            int ic;
            if (n < Trip.FINDS) { info = t("cutemod.act.h.have", n, Trip.FINDS); ic = 0xFF8A7AA8; }
            else if (Progress.count("mh_" + d) == 0) { info = t("cutemod.act.h.claim", HALL_COINS); ic = 0; }
            else { info = t("cutemod.act.h.done"); ic = 0xFF2E8B3A; }
            if (ic == 0) PetActs.btn(g, f, f.plainSubstrByWidth(info, 82), 208, 96, 86, 16, App.in(mx, my, 208, 96, 86, 16), 0xFFE8803A);
            else Skin.str(g, f, f.plainSubstrByWidth(info, 86), 208, 100, ic, false);
            // the four cases
            for (int k = 0; k < Trip.FINDS; k++) {
                int x = 17 + k * 68, y = 112;
                boolean got = Trip.found(d, k);
                MapArt.rect(g, x - 1, y - 1, 64, 40, got ? 0xFFC8952C : 0xFFB8A8C8);
                MapArt.rect(g, x, y, 62, 38, got ? 0xFFFFFBF0 : 0xFFEFE8F5);
                if (got) {
                    PetActs.Match.glyph(g, (d + k) % 6, x + 31, y + 14, ticks);
                    String s = f.plainSubstrByWidth(t("cutemod.trip.find." + d + "." + k), 58);
                    Skin.str(g, f, s, x + 31 - f.width(s) / 2, y + 28, TEXT, false);
                } else Skin.str(g, f, "?", x + 28, y + 14, 0xFFB8A8D8, false);
            }
        }
    }

    // =====================================================================================================
    //  MUSEUM 3. THE GUIDE QUIZ: look at a treasure for a moment, then say which one it was (eight rounds)
    // =====================================================================================================
    static final class GuideQuiz extends PetActs.Act {
        private static final int ROUNDS = 8;
        private final Random rnd = new Random();
        private final int[] opts = new int[3];
        private int round, state, timer, shown, pick = -1, right;        // state 0 look, 1 ask, 2 answer shown

        GuideQuiz(int dest, PetActs.Ctx c) { super(dest, c); next(); }

        private void next() {
            round++;
            state = 0; timer = 85; pick = -1;
            shown = rnd.nextInt(6);
            List<Integer> l = new ArrayList<>();
            for (int i = 0; i < 6; i++) if (i != shown) l.add(i);
            Collections.shuffle(l, rnd);
            int[] o = {shown, l.get(0), l.get(1)};
            List<Integer> mix = new ArrayList<>(List.of(o[0], o[1], o[2]));
            Collections.shuffle(mix, rnd);
            for (int i = 0; i < 3; i++) opts[i] = mix.get(i);
        }

        private void reset() { round = 0; right = 0; over = false; paid = false; next(); }

        @Override void tick() {
            super.tick();
            if (over) return;
            if (state == 0 && --timer <= 0) state = 1;
            else if (state == 2 && --timer <= 0) {
                if (round >= ROUNDS) { over = true; give(right, 6 + right * 2, -4, 0); }
                else next();
            }
        }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(mx, my);
                if (r == 1) reset(); else if (r == 2) c.exit().run();
                return true;
            }
            if (state == 1) for (int i = 0; i < 3; i++) if (App.in(mx, my, 20 + i * 90, 110, 80, 26)) {
                pick = i;
                if (opts[i] == shown) right++;
                c.snd().accept(opts[i] == shown ? 2.0F : 0.8F);
                state = 2; timer = 45;
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            g.fillGradient(0, HEAD, W, H, 0xFFF8EEDA, 0xFFE8D4AA);
            MapArt.rect(g, 6, HEAD + 3, W - 12, 2, 0xFFC8952C); MapArt.rect(g, 6, H - 7, W - 12, 2, 0xFFC8952C);
            header(g, mx, my, t("cutemod.act.s.round", Math.min(round, ROUNDS), ROUNDS));
            Skin.str(g, f, t("cutemod.act.q.right", right), 54, 5, 0xFFFFE680, false);
            if (state == 0) {
                centered(g, f, t("cutemod.act.q.look"), W / 2, 26, TEXT);
                big(g, shown, W / 2, 72);
                int bw = 100, fill = bw * timer / 85;
                Skin.rect(g, W / 2 - bw / 2, 120, bw, 4, 0x44000000); Skin.rect(g, W / 2 - bw / 2, 120, fill, 4, 0xFF9A7AD0);
            } else {
                centered(g, f, t("cutemod.act.q.ask"), W / 2, 30, TEXT);
                for (int i = 0; i < 3; i++) {
                    int x = 20 + i * 90;
                    boolean hv = state == 1 && App.in(mx, my, x, 110, 80, 26);
                    int base = state == 2 ? (opts[i] == shown ? 0xFF4CAF50 : i == pick ? 0xFFE5484D : 0xFFB8B0C0) : 0xFF9A7AD0;
                    PetActs.btn(g, f, f.plainSubstrByWidth(t("cutemod.act.q.g." + opts[i]), 74), x, 110, 80, 26, hv, base);
                }
                if (state == 2) big(g, shown, W / 2, 72);
                else Skin.str(g, f, "?", W / 2 - 3, 66, 0xFF9A7AD0, false);
            }
            if (over) resultBox(g, mx, my, t("cutemod.act.q.end"), t("cutemod.act.q.right", right), "", right);
        }

        private static void big(GuiGraphics g, int id, int cx, int cy) {
            g.pose().pushPose();
            g.pose().translate(cx, cy, 0);
            g.pose().scale(2.4F, 2.4F, 1F);
            PetActs.Match.glyph(g, id, 0, 0, 0);
            g.pose().popPose();
        }
    }

    // =====================================================================================================
    //  CAMP 2. THE FIREFLIES: they blink; click one while it is glowing (a dark click scares them)
    // =====================================================================================================
    static final class Fireflies extends PetActs.Act {
        private static final int DUR = 1500;
        /** x, y, vx, vy, phase, caught timer */
        private final List<double[]> fl = new ArrayList<>();
        private final Random rnd = new Random();
        private int left = DUR, score, scared;

        Fireflies(int dest, PetActs.Ctx c) { super(dest, c); for (int i = 0; i < 8; i++) spawn(); }

        private void spawn() {
            fl.add(new double[]{16 + rnd.nextInt(W - 32), HEAD + 14 + rnd.nextInt(H - HEAD - 50), rnd.nextDouble() - 0.5, rnd.nextDouble() - 0.5, rnd.nextDouble() * 6.28, 0});
        }

        private static boolean lit(double[] f) { return Math.sin(f[4]) > 0.35 && f[5] == 0; }

        @Override void tick() {
            super.tick();
            if (over) return;
            left--;
            if (scared > 0) scared--;
            for (double[] f : fl) {
                f[4] += 0.06;
                f[2] = Math.max(-0.7, Math.min(0.7, f[2] + (rnd.nextDouble() - 0.5) * 0.08));
                f[3] = Math.max(-0.7, Math.min(0.7, f[3] + (rnd.nextDouble() - 0.5) * 0.08));
                f[0] += f[2]; f[1] += f[3];
                if (f[0] < 8 || f[0] > W - 8) f[2] = -f[2];
                if (f[1] < HEAD + 10 || f[1] > H - 38) f[3] = -f[3];
                f[0] = Math.max(8, Math.min(W - 8, f[0])); f[1] = Math.max(HEAD + 10, Math.min(H - 38, f[1]));
                if (f[5] > 0 && --f[5] == 0) f[5] = -1;                          // a caught one shows a star, then it is gone
            }
            fl.removeIf(f -> f[5] < 0);
            while (fl.size() < 8) spawn();
            if (left <= 0) { over = true; give(Math.min(10, score / 2), 14 + Math.min(10, score), -6, 0); }
        }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(mx, my);
                if (r == 1) { fl.clear(); for (int i = 0; i < 8; i++) spawn(); left = DUR; score = 0; over = false; paid = false; }
                else if (r == 2) c.exit().run();
                return true;
            }
            double[] best = null;
            double bd = 13;
            for (double[] f : fl) {
                if (f[5] != 0) continue;
                double d = Math.hypot(mx - f[0], my - f[1]);
                if (d < bd) { bd = d; best = f; }
            }
            if (best != null && lit(best)) { score++; best[5] = 16; c.snd().accept(1.8F); }      // caught: it goes out and is replaced
            else if (best != null) { score = Math.max(0, score - 1); scared = 20; c.snd().accept(0.8F); }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
            g.fill(0, HEAD, W, H, 0x90101040);
            for (double[] ff : fl) {
                int x = (int) Math.round(ff[0]), y = (int) Math.round(ff[1]);
                if (ff[5] > 0) { PetActs.pixelStar(g, x, y - (int) (8 - ff[5] / 2), 0xFFFFFF99); continue; }
                if (lit(ff)) { MapArt.ball(g, x, y, 6, 0x30FFF080); MapArt.ball(g, x, y, 3, 0x80FFF080); MapArt.rect(g, x - 1, y - 1, 3, 3, 0xFFFFFFC0); }
                else MapArt.rect(g, x, y, 2, 2, 0xFF6A6A3A);
            }
            // the jar fills up
            int jx = W - 40, jy = H - 40;
            MapArt.rect(g, jx, jy, 26, 30, 0x55FFFFFF);
            int level = Math.min(26, score * 26 / 15);
            MapArt.rect(g, jx + 1, jy + 29 - level, 24, level, 0x70FFF080);
            MapArt.rect(g, jx + 3, jy - 3, 20, 4, 0xFF8A5A3A);
            header(g, mx, my, null);
            Skin.str(g, f, t("cutemod.act.g.score", score), 54, 5, 0xFFFFE680, false);
            int bw = 70, fill = bw * Math.max(0, left) / DUR;
            Skin.rect(g, W - bw - 6, 5, bw, 7, 0xFF3A2A5A);
            Skin.rect(g, W - bw - 6, 5, fill, 7, left < 300 ? 0xFFE5484D : 0xFF6BCB77);
            if (scared > 0) centered(g, f, t("cutemod.act.f.scared"), W / 2, HEAD + 4, 0xFFFFD0D0);
            if (over) resultBox(g, mx, my, t("cutemod.act.f.end"), t("cutemod.act.g.score", score), "", Math.min(10, score / 2));
        }
    }

    // =====================================================================================================
    //  FAIR 1. WHACK THE MOLES: click the moles (golden ones are worth three), do not touch the bees
    // =====================================================================================================
    static final class Moles extends PetActs.Act {
        private static final int DUR = 1500;
        private static final int[] CX = {60, 150, 240}, CY = {74, 126};
        private final int[] type = new int[6], timer = new int[6], poof = new int[6], poofType = new int[6];
        private final Random rnd = new Random();
        private int left = DUR, score, spawn = 30;

        Moles(int dest, PetActs.Ctx c) { super(dest, c); reset(); }

        private void reset() {
            for (int i = 0; i < 6; i++) { type[i] = -1; timer[i] = 0; poof[i] = 0; }
            left = DUR; score = 0; spawn = 30; over = false; paid = false;
        }

        @Override void tick() {
            super.tick();
            if (over) return;
            left--;
            if (--spawn <= 0) {
                int i = rnd.nextInt(6);
                if (type[i] < 0) {
                    int roll = rnd.nextInt(100);
                    type[i] = roll < 70 ? 0 : roll < 82 ? 1 : 2;
                    timer[i] = (type[i] == 1 ? 40 : 60) + rnd.nextInt(30);
                }
                spawn = Math.max(14, 34 - (DUR - left) / 60) + rnd.nextInt(20);
            }
            for (int i = 0; i < 6; i++) {
                if (type[i] >= 0 && --timer[i] <= 0) type[i] = -1;
                if (poof[i] > 0) poof[i]--;
            }
            if (left <= 0) { over = true; give(Math.min(12, score / 2), 16 + Math.min(12, score), -8, 0); }
        }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(mx, my);
                if (r == 1) reset(); else if (r == 2) c.exit().run();
                return true;
            }
            for (int i = 0; i < 6; i++) {
                if (type[i] < 0 || !App.in(mx, my, CX[i % 3] - 26, CY[i / 3] - 20, 52, 34)) continue;
                score = Math.max(0, score + (type[i] == 0 ? 1 : type[i] == 1 ? 3 : -2));
                poof[i] = 14; poofType[i] = type[i]; type[i] = -1;
                c.snd().accept(poofType[i] == 2 ? 0.8F : poofType[i] == 1 ? 2.0F : 1.6F);
                break;
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
            g.fill(0, HEAD, W, H, 0x40305020);
            for (int i = 0; i < 6; i++) {
                int cx = CX[i % 3], cy = CY[i / 3];
                MapArt.oval(g, cx, cy + 10, 27, 7, 0xFF3A2410);                    // the hole
                if (type[i] >= 0) drawMole(g, type[i], cx, cy);
                MapArt.oval(g, cx, cy + 14, 28, 5, 0xFF7A5A3A);                    // the mound hides the lower part
                MapArt.rect(g, cx - 26, cy + 14, 52, 1, 0xFF9A7A52);
                if (poof[i] > 0) {
                    int p = 14 - poof[i];
                    for (int a = 0; a < 8; a++) {
                        double an = a * Math.PI / 4;
                        MapArt.rect(g, cx + (int) Math.round(Math.cos(an) * (4 + p)), cy + (int) Math.round(Math.sin(an) * (4 + p)), 2, 2, poofType[i] == 1 ? 0xFFFFD84D : poofType[i] == 2 ? 0xFFE5484D : WHITE);
                    }
                    Skin.str(g, f, poofType[i] == 0 ? "+1" : poofType[i] == 1 ? "+3" : "-2", cx - 5, cy - 14 - p, 0xFFFFE680, true);
                }
            }
            header(g, mx, my, null);
            Skin.str(g, f, t("cutemod.act.g.score", score), 54, 5, 0xFFFFE680, false);
            int bw = 70, fill = bw * Math.max(0, left) / DUR;
            Skin.rect(g, W - bw - 6, 5, bw, 7, 0xFF3A2A5A);
            Skin.rect(g, W - bw - 6, 5, fill, 7, left < 300 ? 0xFFE5484D : 0xFF6BCB77);
            if (over) resultBox(g, mx, my, t("cutemod.act.g.end"), t("cutemod.act.g.score", score), "", Math.min(12, score / 2));
        }

        private static void drawMole(GuiGraphics g, int type, int cx, int cy) {
            if (type == 2) {                                                        // a bee: it must be left alone
                MapArt.oval(g, cx, cy, 10, 8, 0xFFFFD84D);
                for (int k = -1; k <= 1; k++) MapArt.rect(g, cx + k * 5 - 1, cy - 7, 2, 14, 0xFF3A2A3A);
                MapArt.oval(g, cx - 5, cy - 11, 6, 3, 0xAAD8F0FF); MapArt.oval(g, cx + 5, cy - 11, 6, 3, 0xAAD8F0FF);
                MapArt.rect(g, cx - 5, cy - 2, 2, 2, WHITE); MapArt.rect(g, cx + 3, cy - 2, 2, 2, WHITE);
                return;
            }
            int fur = type == 1 ? 0xFFFFD84D : 0xFF9A6A4A;
            MapArt.ball(g, cx, cy, 11, MapArt.mix(fur, 0xFF000000, 0.2F));
            MapArt.ball(g, cx, cy - 1, 10, fur);
            MapArt.rect(g, cx - 5, cy - 4, 3, 3, 0xFF3A2A3A); MapArt.rect(g, cx + 3, cy - 4, 3, 3, 0xFF3A2A3A);
            MapArt.rect(g, cx - 4, cy - 4, 1, 1, WHITE); MapArt.rect(g, cx + 4, cy - 4, 1, 1, WHITE);
            MapArt.oval(g, cx, cy + 2, 4, 3, 0xFFFFB0B8);
            MapArt.rect(g, cx - 1, cy + 1, 2, 2, 0xFF6A3A3A);
        }
    }

    // =====================================================================================================
    //  FAIR 2. THE LUCKY BOXES: a ticket, three boxes, one prize (sometimes a golden one)
    // =====================================================================================================
    static final class LuckyBoxes extends PetActs.Act {
        static final int COST = 2;
        /** coins, fun, energy, food of the prizes: 0 sticker, 1 three coins, 2 candy, 3 six coins, 4 ten coins, 5 golden */
        private static final int[][] PRIZE = {{0, 10, 0, 0}, {3, 4, 0, 0}, {0, 6, 0, 14}, {6, 6, 0, 0}, {10, 8, 0, 0}, {20, 14, 0, 0}};
        private final Random rnd = new Random();
        private int state, box, prize, anim, toastT;                              // 0 pick, 1 opening, 2 result

        LuckyBoxes(int dest, PetActs.Ctx c) { super(dest, c); }

        @Override void tick() {
            super.tick();
            if (toastT > 0) toastT--;
            if (state == 1 && ++anim >= 34) {
                state = 2;
                int[] p = PRIZE[prize];
                give(p[0], p[1], p[2], p[3]);
            }
        }

        private static int bx(int i) { return 24 + i * 90; }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (state == 2) {
                int r = resultClick(mx, my);
                if (r == 1) { state = 0; paid = false; } else if (r == 2) c.exit().run();
                return true;
            }
            if (state == 0) for (int i = 0; i < 3; i++) if (App.in(mx, my, bx(i), 70, 52, 50)) {
                if (!Progress.spend(COST)) { toastT = 140; c.snd().accept(0.8F); return true; }
                int roll = rnd.nextInt(100);
                prize = roll < 25 ? 0 : roll < 50 ? 1 : roll < 70 ? 2 : roll < 85 ? 3 : roll < 95 ? 4 : 5;
                box = i; state = 1; anim = 0; paid = false;
                c.snd().accept(1.6F);
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
            g.fill(0, HEAD, W, H, 0x50302050);
            header(g, mx, my, null);
            centered(g, f, t("cutemod.act.b.pick", COST), W / 2, 24, 0xFFFFE680);
            int[] cols = {0xFFE5484D, 0xFF4D96FF, 0xFF6BCB77};
            for (int i = 0; i < 3; i++) {
                int x = bx(i), y = 70;
                boolean hv = state == 0 && App.in(mx, my, x, y, 52, 50);
                int lift = state == 0 ? (hv ? -3 : (int) Math.round(Math.sin(ticks / 9.0 + i * 2) * 1)) : 0;
                MapArt.oval(g, x + 26, y + 52, 28, 4, 0x33000000);
                boolean open = state >= 1 && i == box;
                MapArt.rect(g, x, y + 14 + lift, 52, 36, cols[i]);
                MapArt.rect(g, x, y + 14 + lift, 52, 2, MapArt.mix(cols[i], WHITE, 0.4F));
                MapArt.rect(g, x + 22, y + 14 + lift, 8, 36, 0xFFFFE680);
                int lidUp = open ? Math.min(anim, 20) : 0;
                MapArt.rect(g, x - 2, y + 4 + lift - lidUp, 56, 11, MapArt.mix(cols[i], 0xFF000000, 0.12F));
                MapArt.rect(g, x + 22, y + 4 + lift - lidUp, 8, 11, 0xFFFFE680);
                MapArt.ball(g, x + 22, y + lift - lidUp, 3, 0xFFFFE680); MapArt.ball(g, x + 30, y + lift - lidUp, 3, 0xFFFFE680);
                if (open && anim > 8) {
                    for (int k = 0; k < 5; k++) PetActs.pixelStar(g, x + 6 + k * 10, y - 6 - (anim * 2 + k * 5) % 22, k % 2 == 0 ? 0xFFFFE680 : WHITE);
                }
            }
            if (toastT > 0) {
                String s = t("cutemod.act.c.poor", COST);
                int sw = f.width(s) + 14, sx = W / 2 - sw / 2;
                Skin.rect(g, sx, 140, sw, 13, 0xF0FFE4E4);
                Skin.str(g, f, s, sx + 7, 143, 0xFFB02A30, false);
            }
            if (state == 2) resultBox(g, mx, my, t("cutemod.act.b.end"), t("cutemod.act.b.p." + prize), "", PRIZE[prize][0]);
        }
    }

    // =====================================================================================================
    //  OLD HOUSE 1. GHOST HUNT: the mouse is a flashlight, the ghosts only show inside the beam
    // =====================================================================================================
    static final class GhostHunt extends PetActs.Act {
        private static final int DUR = 1500, GHOSTS = 5;
        /** x, y, vx, vy, phase, caught timer (-1 = gone) */
        private final List<double[]> gs = new ArrayList<>();
        private final Random rnd = new Random();
        private int left = DUR, score, mx = W / 2, my = H / 2;

        GhostHunt(int dest, PetActs.Ctx c) { super(dest, c); for (int i = 0; i < GHOSTS; i++) spawn(); }

        private void spawn() {
            gs.add(new double[]{20 + rnd.nextInt(W - 40), HEAD + 20 + rnd.nextInt(H - HEAD - 50), rnd.nextDouble() - 0.5, rnd.nextDouble() - 0.5, rnd.nextDouble() * 6.28, 0});
        }

        private boolean seen(double[] gh) { return gh[5] == 0 && Math.hypot(mx - gh[0], my - gh[1]) < 40; }

        @Override void tick() {
            super.tick();
            if (over) return;
            left--;
            for (double[] gh : gs) {
                gh[4] += 0.07;
                gh[2] = Math.max(-0.8, Math.min(0.8, gh[2] + (rnd.nextDouble() - 0.5) * 0.1));
                gh[3] = Math.max(-0.8, Math.min(0.8, gh[3] + (rnd.nextDouble() - 0.5) * 0.1));
                gh[0] += gh[2]; gh[1] += gh[3];
                if (gh[0] < 12 || gh[0] > W - 12) gh[2] = -gh[2];
                if (gh[1] < HEAD + 14 || gh[1] > H - 24) gh[3] = -gh[3];
                gh[0] = Math.max(12, Math.min(W - 12, gh[0])); gh[1] = Math.max(HEAD + 14, Math.min(H - 24, gh[1]));
                if (gh[5] > 0 && --gh[5] == 0) gh[5] = -1;
            }
            gs.removeIf(gh -> gh[5] < 0);
            while (gs.size() < GHOSTS) spawn();
            if (left <= 0) { over = true; give(Math.min(10, score * 2), 14 + Math.min(12, score * 2), -6, 0); }
        }

        @Override boolean click(int x, int y, int button) {
            if (backHit(x, y)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(x, y);
                if (r == 1) { gs.clear(); for (int i = 0; i < GHOSTS; i++) spawn(); left = DUR; score = 0; over = false; paid = false; }
                else if (r == 2) c.exit().run();
                return true;
            }
            for (double[] gh : gs) if (seen(gh) && Math.hypot(x - gh[0], y - gh[1]) < 13) {
                score++; gh[5] = 14; c.snd().accept(1.8F);
                return true;
            }
            c.snd().accept(0.8F);
            return true;
        }

        @Override void render(GuiGraphics g, int x, int y) {
            Font f = font();
            if (!over) { mx = x; my = y; }
            TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
            for (double[] gh : gs) {
                int gx = (int) Math.round(gh[0]), gy = (int) Math.round(gh[1] + Math.sin(gh[4]) * 3);
                if (gh[5] > 0) { PetActs.pixelStar(g, gx, gy - (int) (14 - gh[5]), 0xFFFFFFFF); continue; }
                MapArt.ball(g, gx, gy, 7, 0xFFE8F0FF);
                MapArt.rect(g, gx - 7, gy, 15, 8, 0xFFE8F0FF);
                for (int k = 0; k < 5; k++) MapArt.rect(g, gx - 7 + k * 3, gy + 8, 3, k % 2 == 0 ? 3 : 1, 0xFFE8F0FF);
                MapArt.rect(g, gx - 3, gy - 2, 2, 3, 0xFF3A2A5A); MapArt.rect(g, gx + 2, gy - 2, 2, 3, 0xFF3A2A5A);
                MapArt.oval(g, gx, gy + 3, 2, 1, 0xFF3A2A5A);
            }
            for (int cx = 0; cx < W; cx += 6) for (int cy = HEAD; cy < H; cy += 6) {          // the dark: clear in the beam, black outside
                double d = Math.hypot(cx + 3 - mx, cy + 3 - my);
                int a = (int) Math.min(0xEE, Math.max(0, (d - 26) * 7));
                if (a > 0) g.fill(cx, cy, cx + 6, cy + 6, (a << 24) | 0x080818);
            }
            header(g, x, y, null);
            Skin.str(g, f, t("cutemod.act.g.score", score), 54, 5, 0xFFFFE680, false);
            int bw = 70, fill = bw * Math.max(0, left) / DUR;
            Skin.rect(g, W - bw - 6, 5, bw, 7, 0xFF3A2A5A);
            Skin.rect(g, W - bw - 6, 5, fill, 7, left < 300 ? 0xFFE5484D : 0xFF6BCB77);
            if (over) resultBox(g, x, y, t("cutemod.act.o.end"), t("cutemod.act.g.score", score), "", Math.min(10, score * 2));
        }
    }

    // =====================================================================================================
    //  OLD HOUSE 2. TRICK OR TREAT: five houses, three doors each; sweets, a big bag, or a spider
    // =====================================================================================================
    static final class TrickTreat extends PetActs.Act {
        private static final int HOUSES = 5;
        private final Random rnd = new Random();
        private int house = 1, state, door, res, timer, coins, fun, candies;       // state 0 pick a door, 1 the door is open

        TrickTreat(int dest, PetActs.Ctx c) { super(dest, c); }

        private static int dx(int i) { return 30 + i * 90; }

        private void reset() { house = 1; state = 0; coins = 0; fun = 0; candies = 0; over = false; paid = false; }

        @Override void tick() {
            super.tick();
            if (over || state != 1) return;
            if (--timer <= 0) {
                if (house >= HOUSES) { over = true; give(coins, 8 + fun, -4, candies * 4); }
                else { house++; state = 0; }
            }
        }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(mx, my);
                if (r == 1) reset(); else if (r == 2) c.exit().run();
                return true;
            }
            if (state == 0) for (int i = 0; i < 3; i++) if (App.in(mx, my, dx(i), 50, 50, 78)) {
                int roll = rnd.nextInt(100);
                res = roll < 55 ? 0 : roll < 75 ? 1 : 2;
                if (res == 0) { coins += 1; fun += 3; candies++; }
                else if (res == 1) { coins += 3; fun += 5; candies += 2; }
                else fun -= 4;
                door = i; state = 1; timer = 60;
                c.snd().accept(res == 2 ? 0.7F : 1.8F);
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
            g.fill(0, HEAD, W, H, 0x60201040);
            MapArt.rect(g, 0, 128, W, H - 128, 0xFF2A1A30);
            for (int i = 0; i < 3; i++) {
                int x = dx(i), y = 50;
                boolean open = state == 1 && i == door, hv = state == 0 && App.in(mx, my, x, y, 50, 78);
                MapArt.rect(g, x - 4, y - 4, 58, 86, 0xFF4A3A5A);
                MapArt.rect(g, x, y, 50, 78, open ? 0xFF1A1020 : hv ? 0xFFB07A4A : 0xFF8A5A3A);
                if (!open) {
                    MapArt.rect(g, x + 4, y + 4, 42, 30, MapArt.mix(0xFF8A5A3A, 0xFF000000, 0.2F));
                    MapArt.ball(g, x + 40, y + 42, 3, 0xFFFFD84D);                 // the knob
                    MapArt.ball(g, x + 25, y + 22, 5, 0xFFFF9A3C);                 // a little pumpkin on the door
                } else if (res == 2) {                                             // a spider
                    MapArt.ball(g, x + 25, y + 36, 7, 0xFF3A2A3A);
                    for (int k = 0; k < 4; k++) { MapArt.ln(g, x + 25, y + 36, x + 6, y + 26 + k * 8, 0xFF3A2A3A); MapArt.ln(g, x + 25, y + 36, x + 44, y + 26 + k * 8, 0xFF3A2A3A); }
                    MapArt.rect(g, x + 21, y + 34, 2, 2, 0xFFE5484D); MapArt.rect(g, x + 28, y + 34, 2, 2, 0xFFE5484D);
                    MapArt.rect(g, x + 25, y, 1, 30, 0xAAFFFFFF);
                } else {                                                           // sweets
                    int n = res == 1 ? 6 : 3;
                    int[] cc = {0xFFFF6B8E, 0xFF6BCB77, 0xFFFFD84D, 0xFF4D96FF, 0xFFB57BD6, 0xFFFF9A3C};
                    for (int k = 0; k < n; k++) { MapArt.ball(g, x + 10 + (k % 3) * 15, y + 40 + (k / 3) * 14 - (ticks / 6 + k) % 3, 5, cc[k]); }
                    PetActs.pixelStar(g, x + 25, y + 18, 0xFFFFE680);
                }
            }
            PetActs.pet(g, c.color().get(), 150, H - 8, 0.5F, ticks, c.stage().getAsInt(), state == 1 && res == 2 ? 0 : 2);
            header(g, mx, my, null);
            String msg = state == 0 ? t("cutemod.act.t.pick", house, HOUSES) : t("cutemod.act.t.r." + res);
            centered(g, f, msg, W / 2, HEAD + 5, WHITE);
            Skin.str(g, f, t("cutemod.act.t.sum", candies), 6, H - 11, 0xFFFFE680, false);
            if (over) resultBox(g, mx, my, t("cutemod.act.t.end"), t("cutemod.act.t.sum", candies), "", coins);
        }
    }

    // =====================================================================================================
    //  QUIET PLACE 1. STARGAZING: the stars light up one after another, repeat the pattern (it gets longer)
    // =====================================================================================================
    static final class Stargaze extends PetActs.Act {
        private static final int[][] STAR = {{60, 56}, {118, 44}, {190, 66}, {244, 48}, {150, 104}};
        private static final int MAX = 8;
        private final Random rnd = new Random();
        private final List<Integer> seq = new ArrayList<>();
        private int state, t0, input, lit = -1, flashT, pause;               // state 0 watch, 1 repeat, 2 well done, 3 ended

        Stargaze(int dest, PetActs.Ctx c) { super(dest, c); reset(); }

        private void reset() {
            seq.clear(); seq.add(rnd.nextInt(5)); seq.add(rnd.nextInt(5));
            state = 0; t0 = -30; input = 0; lit = -1; over = false; paid = false;
        }

        private int done() { return seq.size() - 2; }

        @Override void tick() {
            super.tick();
            if (over) return;
            if (state == 0) {
                t0++;
                if (t0 < 0) return;
                int step = t0 / 40, phase = t0 % 40;
                if (step >= seq.size()) { state = 1; input = 0; lit = -1; return; }
                if (phase == 0) c.snd().accept(1.0F + seq.get(step) * 0.25F);
                lit = phase < 28 ? seq.get(step) : -1;
            } else if (state == 1) {
                if (flashT > 0 && --flashT == 0) lit = -1;
            } else if (state == 2 && --pause <= 0) {
                seq.add(rnd.nextInt(5));
                state = 0; t0 = -30; lit = -1;
            }
        }

        private void end() { over = true; state = 3; give(Math.min(10, done()), 8 + done() * 2, 3, 0); }

        @Override boolean click(int mx, int my, int button) {
            if (backHit(mx, my)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(mx, my);
                if (r == 1) reset(); else if (r == 2) c.exit().run();
                return true;
            }
            if (state != 1) return true;
            for (int i = 0; i < 5; i++) if (Math.hypot(mx - STAR[i][0], my - STAR[i][1]) < 16) {
                lit = i; flashT = 14;
                c.snd().accept(1.0F + i * 0.25F);
                if (i != seq.get(input)) { end(); return true; }
                if (++input >= seq.size()) {
                    if (seq.size() >= MAX) { seq.add(0); end(); } else { state = 2; pause = 40; }
                }
                return true;
            }
            return true;
        }

        @Override void render(GuiGraphics g, int mx, int my) {
            Font f = font();
            TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
            g.fill(0, HEAD, W, H, 0x50101040);
            for (int i = 0; i < 5; i++) {                                            // the faint lines of the pattern
                if (i > 0) MapArt.ln(g, STAR[i - 1][0], STAR[i - 1][1], STAR[i][0], STAR[i][1], 0x33FFFFFF);
            }
            for (int i = 0; i < 5; i++) {
                boolean on = i == lit;
                boolean hv = state == 1 && Math.hypot(mx - STAR[i][0], my - STAR[i][1]) < 16;
                if (on) MapArt.ball(g, STAR[i][0], STAR[i][1], 14, 0x50FFF080);
                PetActs.pixelStar(g, STAR[i][0], STAR[i][1], on ? 0xFFFFFFB0 : hv ? 0xFFE8E0FF : 0xFF8A8AC8);
            }
            header(g, mx, my, null);
            Skin.str(g, f, t("cutemod.act.z.len", seq.size()), 54, 5, 0xFFFFE680, false);
            String msg = state == 0 ? t("cutemod.act.z.watch") : state == 1 ? t("cutemod.act.z.go") : "";
            if (!msg.isEmpty()) centered(g, f, msg, W / 2, H - 14, WHITE);
            if (over) resultBox(g, mx, my, t("cutemod.act.z.end"), t("cutemod.act.z.len", done() == 0 ? 0 : done() + 1), "", Math.min(10, done()));
        }
    }

    // =====================================================================================================
    //  QUIET PLACE 2. FOLLOW THE LANTERN: keep the mouse close to a slowly drifting lantern (a calm, restful game)
    // =====================================================================================================
    static final class LanternFollow extends PetActs.Act {
        private static final int DUR = 1500;
        private int left = DUR, near, mx = W / 2, my = H / 2;

        LanternFollow(int dest, PetActs.Ctx c) { super(dest, c); }

        private double lx() { return W / 2.0 + Math.sin(ticks / 70.0) * 100 + Math.sin(ticks / 29.0) * 22; }
        private double ly() { return 72 + Math.sin(ticks / 53.0) * 28 + Math.cos(ticks / 37.0) * 12; }

        @Override void tick() {
            super.tick();
            if (over) return;
            left--;
            if (Math.hypot(mx - lx(), my - ly()) < 26) near++;
            if (left <= 0) { over = true; give(Math.min(8, near / 180), 10 + near / 150, 8, 0); }
        }

        @Override boolean click(int x, int y, int button) {
            if (backHit(x, y)) { c.exit().run(); return true; }
            if (over) {
                int r = resultClick(x, y);
                if (r == 1) { left = DUR; near = 0; over = false; paid = false; ticks = 0; }
                else if (r == 2) c.exit().run();
            }
            return true;
        }

        @Override void render(GuiGraphics g, int x, int y) {
            Font f = font();
            if (!over) { mx = x; my = y; }
            TripArt.scene(g, 0, HEAD, W, H - HEAD, dest, ticks);
            int px = (int) Math.round(lx()), py = (int) Math.round(ly());
            boolean close = Math.hypot(mx - px, my - py) < 26;
            MapArt.ball(g, px, py, close ? 20 : 14, close ? 0x40FFD070 : 0x25FFD070);
            MapArt.rect(g, px - 5, py - 7, 10, 13, 0xFFE8803A); MapArt.rect(g, px - 3, py - 5, 6, 9, 0xFFFFE680);
            MapArt.rect(g, px - 6, py - 8, 12, 2, 0xFF8A5A3A); MapArt.rect(g, px - 6, py + 6, 12, 2, 0xFF8A5A3A); MapArt.rect(g, px, py - 11, 1, 3, 0xFF8A5A3A);
            if (!over) { MapArt.ball(g, mx, my, 3, close ? 0xAAFFFFB0 : 0x66FFFFFF); }
            header(g, x, y, null);
            Skin.str(g, f, t("cutemod.act.l.calm", Math.min(100, near * 100 / DUR)), 54, 5, 0xFFFFE680, false);
            int bw = 70, fill = bw * Math.max(0, left) / DUR;
            Skin.rect(g, W - bw - 6, 5, bw, 7, 0xFF3A2A5A);
            Skin.rect(g, W - bw - 6, 5, fill, 7, 0xFF9A7AD0);
            if (!over && ticks < 240) centered(g, f, t("cutemod.act.l.hint"), W / 2, H - 14, WHITE);
            if (over) resultBox(g, x, y, t("cutemod.act.l.end"), t("cutemod.act.l.calm", Math.min(100, near * 100 / DUR)), "", Math.min(8, near / 180));
        }
    }
}
