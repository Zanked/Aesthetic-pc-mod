package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The big pictures of the trip places (the screen of a place on the map: 300 x 149 pixels). Every place is a little
 * world with a sky, layers of land far and near, many small details and things that move. The pet stands in the middle at
 * the bottom, so the middle of the floor line is kept calm and the details are on the sides and in the back.
 * Small boxes (the "away" screen, the photos) still use the simple pictures of {@link TripArt}.
 *
 * Places 0-8 are here, 9-17 are in {@link TripScenes2}. Coordinates are local to the box (0,0 = its top left corner).
 */
final class TripScenes {
    private TripScenes() {}

    static final int W = 300, H = 149, FL = 104;      // the box and the line where the ground begins

    /** A small canvas: everything is drawn relative to the top left corner of the box. */
    static final class C {
        final GuiGraphics g;
        final int ox, oy, t;
        C(GuiGraphics g, int ox, int oy, int t) { this.g = g; this.ox = ox; this.oy = oy; this.t = t; }

        void r(int x, int y, int w, int h, int c) { if (w > 0 && h > 0) g.fill(ox + x, oy + y, ox + x + w, oy + y + h, c); }

        void grad(int x, int y, int w, int h, int c1, int c2) { g.fillGradient(ox + x, oy + y, ox + x + w, oy + y + h, c1, c2); }

        void b(int cx, int cy, int rad, int c) {
            for (int dy = -rad; dy <= rad; dy++) {
                int dx = (int) Math.round(Math.sqrt((rad + 0.2) * (rad + 0.2) - dy * dy));
                r(cx - dx, cy + dy, dx * 2 + 1, 1, c);
            }
        }

        void o(int cx, int cy, int rx, int ry, int c) {
            for (int dy = -ry; dy <= ry; dy++) {
                int dx = (int) Math.round(rx * Math.sqrt(1 - dy * dy / (double) (ry * ry + 1)));
                r(cx - dx, cy + dy, dx * 2 + 1, 1, c);
            }
        }

        void tri(int cx, int top, int w, int h, int c) {
            for (int i = 0; i < h; i++) { int ww = Math.max(1, w * (i + 1) / h); r(cx - ww / 2, top + i, ww, 1, c); }
        }

        void ln(int x0, int y0, int x1, int y1, int c) {
            int n = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)));
            for (int i = 0; i <= n; i++) r(x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, 1, 1, c);
        }

        /** rounded box */
        void rr(int x, int y, int w, int h, int rad, int c) {
            rad = Math.max(0, Math.min(rad, Math.min(w, h) / 2));
            for (int dy = 0; dy < h; dy++) {
                double m = dy + 0.5, e = m < rad ? rad - m : m > h - rad ? m - (h - rad) : 0;
                int in = e > 0 ? (int) Math.round(rad - Math.sqrt(Math.max(0, rad * rad - e * e))) : 0;
                r(x + in, y + dy, w - 2 * in, 1, c);
            }
        }

        /** a box with a lit top-left edge and a shaded bottom-right edge */
        void bev(int x, int y, int w, int h, int c, int lit, int dark) {
            r(x, y, w, h, c); r(x, y, w, 1, lit); r(x, y, 1, h, lit); r(x, y + h - 1, w, 1, dark); r(x + w - 1, y, 1, h, dark);
        }
    }

    static int mx(int a, int b, float f) {
        int r = Math.round((a >> 16 & 255) + ((b >> 16 & 255) - (a >> 16 & 255)) * f);
        int gr = Math.round((a >> 8 & 255) + ((b >> 8 & 255) - (a >> 8 & 255)) * f);
        int bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * f);
        return (a & 0xFF000000) | (r << 16) | (gr << 8) | bl;
    }

    static int lit(int c, float f) { return mx(c, 0xFFFFFFFF, f); }

    static int dim(int c, float f) { return mx(c, 0xFF000000, f); }

    // ---------- the shared pieces ----------
    /** A fluffy cloud, s = size (1..3). */
    static void cloud(C c, int cx, int cy, int s, int col) {
        c.b(cx, cy, 3 * s, col); c.b(cx + 4 * s, cy + s, 3 * s, col); c.b(cx - 4 * s, cy + s, 2 * s + 1, col); c.b(cx + 8 * s, cy + 2 * s, 2 * s, col);
        c.r(cx - 6 * s, cy + 2 * s, 14 * s, s + 1, col);
        c.r(cx - 5 * s, cy + 3 * s, 13 * s, 1, lit(col, 0.0F) & 0x00FFFFFF | 0x22000000);
    }

    /** Clouds that drift (n of them) with the given colour. */
    static void drift(C c, int n, int yTop, int ySpread, int col, double speed) {
        for (int i = 0; i < n; i++) {
            int cx = (int) ((c.t * (speed + i * 0.02) + i * (W / n + 17)) % (W + 80)) - 40;
            cloud(c, cx, yTop + (i * 17) % Math.max(1, ySpread), 1 + (i % 2), col);
        }
    }

    static void sun(C c, int cx, int cy, int rad, int col) {
        c.b(cx, cy, rad + 7, col & 0x00FFFFFF | 0x16000000);
        c.b(cx, cy, rad + 4, col & 0x00FFFFFF | 0x26000000);
        c.b(cx, cy, rad, col);
        c.b(cx - rad / 3, cy - rad / 3, Math.max(1, rad / 4), 0x88FFFFFF);
    }

    /** A line of hills / mountains: height from a mix of sines, filled down to the baseline. */
    static void hills(C c, int base, int amp, int col, double f1, double ph, int x0, int x1) {
        for (int x = x0; x < x1; x++) {
            int top = base - (int) Math.round(amp * (0.5 + 0.5 * Math.sin(x * f1 + ph)) + amp * 0.35 * Math.sin(x * f1 * 2.7 + ph * 1.7));
            c.r(x, top, 1, base - top + 1, col);
        }
    }

    static void stars(C c, int n, int yMax, int seed) {
        for (int i = 0; i < n; i++) {
            int sx = (i * 53 + seed * 31 + 7) % (W - 2), sy = (i * 29 + seed * 17 + 3) % Math.max(1, yMax);
            boolean big = i % 7 == 0, tw = (c.t / 14 + i) % 6 == 0;
            c.r(sx, sy, big ? 2 : 1, big ? 2 : 1, tw ? 0x66FFFFFF : 0xEEFFFFFF);
            if (big && !tw) { c.r(sx - 1, sy, 4, 1, 0x44FFFFFF); c.r(sx, sy - 1, 1, 4, 0x44FFFFFF); }
        }
    }

    static void roundTree(C c, int cx, int base, int th, int cr, int crown) {
        c.o(cx, base + 1, cr, 3, 0x28000000);
        c.r(cx - 2, base - th, 4, th + 1, 0xFF6A4228); c.r(cx - 2, base - th, 1, th + 1, 0xFF8A5A3A);
        c.b(cx, base - th - cr / 2, cr, dim(crown, 0.18F));
        c.b(cx - 1, base - th - cr / 2 - 1, cr - 1, crown);
        c.b(cx - cr / 3, base - th - cr / 2 - cr / 3, Math.max(2, cr / 2), lit(crown, 0.22F));
        c.b(cx + cr / 2, base - th - cr / 4, Math.max(2, cr / 3), dim(crown, 0.12F));
    }

    static void pine(C c, int cx, int base, int h, int w, int col, boolean snow) {
        c.o(cx, base + 1, w / 2, 2, 0x26000000);
        c.r(cx - 1, base - 4, 3, 5, 0xFF5A3A22);
        int layers = Math.max(2, h / 9);
        for (int i = 0; i < layers; i++) {
            int top = base - h + i * (h - 6) / layers, lh = (h - 6) / layers + 6, lw = w * (i + 2) / (layers + 1);
            c.tri(cx, top, lw, lh, i % 2 == 0 ? col : dim(col, 0.1F));
            c.tri(cx - lw / 6, top + 1, lw * 2 / 3, lh * 2 / 3, lit(col, 0.12F));
            if (snow) { c.tri(cx, top, lw * 3 / 5, lh / 2, 0xFFFFFFFF); c.r(cx - lw / 2 + 1, top + lh - 1, lw - 2, 1, 0xFFE6F0FF); }
        }
    }

    static void bush(C c, int cx, int base, int s, int col) {
        c.o(cx, base + 1, s * 2, 2, 0x24000000);
        c.b(cx - s, base - s / 2, s, dim(col, 0.1F)); c.b(cx + s, base - s / 2, s, dim(col, 0.1F)); c.b(cx, base - s, s + 1, col);
        c.b(cx - s / 3, base - s - s / 3, Math.max(1, s / 2), lit(col, 0.25F));
    }

    static void flower(C c, int x, int y, int col) {
        c.r(x, y + 1, 1, 3, 0xFF3F9E48);
        c.r(x - 1, y, 3, 1, col); c.r(x, y - 1, 1, 3, col); c.r(x, y, 1, 1, 0xFFFFD34E);
    }

    /** Flowers sprinkled over a band of ground. */
    static void flowers(C c, int n, int y0, int y1, int x0, int x1, int seed, int... cols) {
        for (int i = 0; i < n; i++) {
            int fx = x0 + (i * 83 + seed * 29 + 11) % Math.max(1, x1 - x0), fy = y0 + (i * 47 + seed * 13) % Math.max(1, y1 - y0);
            flower(c, fx, fy, cols[i % cols.length]);
        }
    }

    static void tufts(C c, int n, int y0, int y1, int seed, int col) {
        for (int i = 0; i < n; i++) {
            int gx = (i * 71 + seed * 19 + 13) % (W - 4), gy = y0 + (i * 37 + seed * 7) % Math.max(1, y1 - y0);
            c.r(gx, gy, 1, 2, col); c.r(gx + 2, gy + 1, 1, 1, col); c.r(gx - 1, gy + 1, 1, 1, col);
        }
    }

    static void heart(C c, int cx, int top, int col) {
        String[] m = {".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."};
        for (int r = 0; r < m.length; r++) for (int k = 0; k < 7; k++) if (m[r].charAt(k) == 'X') c.r(cx - 3 + k, top + r, 1, 1, col);
    }

    static void bird(C c, int x, int y, int col) {
        boolean up = (c.t / 7 + x / 9) % 2 == 0;
        c.r(x, y + (up ? 0 : 1), 2, 1, col); c.r(x + 2, y + (up ? 1 : 0), 1, 1, col); c.r(x + 3, y + (up ? 0 : 1), 2, 1, col);
    }

    /** A small house with a roof, a door and two windows. night = the windows glow. */
    static void house(C c, int x, int base, int w, int h, int wall, int roof, boolean night) {
        c.o(x + w / 2, base + 1, w / 2 + 3, 2, 0x28000000);
        c.r(x, base - h, w, h, wall);
        c.r(x, base - h, w, 1, lit(wall, 0.3F)); c.r(x + w - 2, base - h, 2, h, dim(wall, 0.1F));
        c.tri(x + w / 2, base - h - h * 6 / 10, w + 8, h * 6 / 10, roof);
        c.tri(x + w / 2 - w / 8, base - h - h * 5 / 10, w * 3 / 4, h * 4 / 10, lit(roof, 0.15F));
        c.r(x + w / 2 - 2, base - h * 45 / 100, 5, h * 45 / 100, dim(wall, 0.45F));
        c.r(x + w / 2 + 1, base - h * 22 / 100, 1, 1, 0xFFFFD34E);
        int ww = Math.max(4, w / 5);
        for (int s = 0; s < 2; s++) {
            int wx = s == 0 ? x + 3 : x + w - 3 - ww, wy = base - h + 4;
            c.bev(wx, wy, ww, ww, night ? 0xFFFFE680 : 0xFFBFE6FF, 0xFFFFFFFF, dim(wall, 0.4F));
            c.r(wx + ww / 2, wy, 1, ww, dim(wall, 0.4F));
            if (night) c.r(wx - 1, wy - 1, ww + 2, ww + 2, 0x20FFE680);
        }
    }

    // =====================================================================================================
    static void big(GuiGraphics g, int x, int y, int dest, int t) {
        C c = new C(g, x, y, t);
        switch (dest) {
            case 0 -> kindergarten(c);
            case 1 -> beach(c);
            case 2 -> forest(c);
            case 3 -> mountains(c);
            case 4 -> city(c);
            case 5 -> moon(c);
            case 6 -> meadow(c);
            case 7 -> clouds(c);
            case 8 -> village(c);
            default -> TripScenes2.big(c, dest);
        }
    }

    static boolean has(int dest) { return dest >= 0 && dest <= 17; }

    // ---------- 0: the kindergarten ----------
    private static void kindergarten(C c) {
        c.grad(0, 0, W, FL, 0xFFFFF6FA, 0xFFFFE4EF);
        for (int yy = 6; yy < FL - 4; yy += 14) for (int xx = (yy / 14 & 1) * 12; xx < W; xx += 24) {      // little stars on the wallpaper
            c.r(xx + 5, yy, 1, 3, 0x55F4A7C3); c.r(xx + 4, yy + 1, 3, 1, 0x55F4A7C3);
        }
        // the rainbow arch
        int cx = 150, by = FL + 2;
        int[] rc = {0xFFFF6B6B, 0xFFFFA64D, 0xFFFFD84D, 0xFF6BCB77, 0xFF4D96FF, 0xFFB57BD6};
        for (int i = 0; i < rc.length; i++) c.b(cx, by, 74 - i * 5, rc[i]);
        c.b(cx, by, 44, 0xFFFFF0F6);
        c.r(0, FL + 3, W, H - FL - 3, 0xFFF3D9A4);
        // a window with a sunny sky on the left and a painting on the right
        c.bev(14, 16, 42, 36, 0xFFBFE6FF, 0xFFFFFFFF, 0xFF9A6A3C); c.r(34, 16, 2, 36, 0xFFFFFFFF); c.r(14, 33, 42, 2, 0xFFFFFFFF);
        c.b(24, 26, 4, 0xFFFFE066); cloud(c, 44, 40, 1, 0xEEFFFFFF);
        c.r(10, 12, 7, 42, 0xFFF4A7C3); c.r(53, 12, 7, 42, 0xFFF4A7C3); c.r(10, 12, 50, 3, 0xFFC8955C);
        c.bev(238, 18, 40, 30, 0xFFFFF8E0, 0xFFFFD84D, 0xFFC8952C);
        c.b(250, 30, 5, 0xFFFF8FB8); c.b(262, 34, 6, 0xFF8FD3FF); c.b(256, 26, 3, 0xFFFFE066); c.r(246, 40, 28, 3, 0xFF9AD98C);
        // a hanging mobile
        c.r(98, 0, 1, 14, 0xFFB98450);
        for (int i = 0; i < 3; i++) { int mxx = 90 + i * 8, my = 18 + (i % 2) * 6 + (int) Math.round(Math.sin((c.t + i * 20) / 20.0) * 2); c.r(mxx + 1, 14, 1, my - 14, 0xAAB98450); c.b(mxx + 1, my + 2, 3, new int[]{0xFFFFD84D, 0xFFFF8FB8, 0xFF8FD3FF}[i]); }
        // the shelf with toys (left) and a toy box
        c.r(8, 76, 70, 3, 0xFFC8955C); c.r(8, 79, 70, 1, 0xFF9A6A3C);
        c.bev(12, 64, 12, 12, 0xFFE5484D, 0xFFFF9A9A, 0xFFA02A3A); c.r(16, 68, 4, 4, 0xFFFFFFFF);
        c.b(34, 71, 5, 0xFFFFD84D); c.b(34, 69, 3, 0xFFFFE680); c.r(32, 69, 1, 1, 0xFF3A2A3A); c.r(36, 69, 1, 1, 0xFF3A2A3A);   // a duck
        c.r(46, 66, 10, 10, 0xFF4D96FF); c.r(46, 66, 10, 1, 0xFF9AC8FF); c.r(49, 69, 4, 4, 0xFFFFFFFF);
        c.o(66, 72, 7, 4, 0xFFB57B4A); c.b(66, 66, 4, 0xFFC8955C); c.b(63, 63, 2, 0xFFB57B4A); c.b(69, 63, 2, 0xFFB57B4A);        // a teddy
        // ABC blocks (right)
        String[] letters = {"A", "B", "C"};
        for (int i = 0; i < 3; i++) {
            int bx = 232 + i * 17 - (i == 1 ? 0 : 0), byy = FL - 14 - (i == 1 ? 15 : 0);
            int col = new int[]{0xFFFF8FB8, 0xFFFFD84D, 0xFF8FD3FF}[i];
            c.bev(bx, byy, 15, 14, col, lit(col, 0.5F), dim(col, 0.25F));
            c.r(bx + 5, byy + 3, 5, 1, 0xFFFFFFFF); c.r(bx + 4, byy + 4, 1, 6, 0xFFFFFFFF); c.r(bx + 10, byy + 4, 1, 6, 0xFFFFFFFF); c.r(bx + 5, byy + 6, 5, 1, 0xFFFFFFFF);
        }
        // a toy train on the floor
        int tx = 18 + (c.t / 3) % 3;
        c.r(tx - 16, FL + 14, 60, 1, 0xFFB98450);
        for (int i = 0; i < 3; i++) {
            int col = new int[]{0xFFE5484D, 0xFF4D96FF, 0xFF6BCB77}[i];
            c.bev(tx + i * 16, FL + 6, 13, 8, col, lit(col, 0.4F), dim(col, 0.25F));
            c.b(tx + i * 16 + 3, FL + 14, 2, 0xFF3A2A3A); c.b(tx + i * 16 + 10, FL + 14, 2, 0xFF3A2A3A);
        }
        c.r(tx + 2, FL, 4, 6, 0xFF3A2A3A); c.b(tx + 4, FL - 3 - (c.t / 8) % 3, 2, 0x88FFFFFF);
        // balloons on strings
        for (int i = 0; i < 4; i++) {
            int bx = 190 + i * 11 + (int) Math.round(Math.sin((c.t + i * 13) / 18.0) * 2), byy = 18 + (i % 2) * 8;
            int col = new int[]{0xFFFF6B6B, 0xFFFFD84D, 0xFF4D96FF, 0xFF6BCB77}[i];
            c.b(bx, byy, 5, col); c.r(bx - 2, byy - 3, 2, 2, 0x99FFFFFF); c.ln(bx, byy + 6, 196 + i * 3, FL - 2, 0xAA9A8A9A);
        }
        // a round rug with a pattern in front
        c.o(150, FL + 36, 120, 12, 0xFFF4A7C3); c.o(150, FL + 36, 110, 10, 0xFFFFD0E2);
        for (int i = 0; i < 12; i++) { int ax = 150 + (int) Math.round(Math.cos(i * Math.PI / 6) * 90), ay = FL + 36 + (int) Math.round(Math.sin(i * Math.PI / 6) * 7); c.b(ax, ay, 2, i % 2 == 0 ? 0xFFFFD84D : 0xFF8FD3FF); }
    }

    // ---------- 1: the beach ----------
    private static void beach(C c) {
        c.grad(0, 0, W, 60, 0xFF63C0FF, 0xFFCDEEFF);
        sun(c, 238, 24, 11, 0xFFFFE066);
        drift(c, 3, 10, 28, 0xEEFFFFFF, 0.1);
        c.r(0, 60, W, 44, 0xFF2E9BDB);
        c.grad(0, 60, W, 44, 0xFF5CC0F0, 0xFF1F86C8);
        for (int i = 0; i < 12; i++) { int wy = 64 + i * 3, wx = (i * 47 + c.t / 3 * (1 + i % 2)) % (W + 20) - 10; c.r(wx, wy, 14 - i % 3 * 2, 1, 0x66FFFFFF); }
        c.r(190, 62, 36, 1, 0x55FFF0A0); c.r(196, 66, 24, 1, 0x44FFF0A0); c.r(202, 71, 14, 1, 0x33FFF0A0);                 // the sun on the water
        c.o(70, 59, 30, 5, 0xFF7ABAA0); c.o(70, 57, 22, 5, 0xFF6FC66A); c.r(66, 50, 2, 8, 0xFF8A5A3A); c.b(67, 49, 5, 0xFF3FA55A);   // a far island
        // a sailing boat
        int bx = 130 + (int) Math.round(Math.sin(c.t / 70.0) * 14);
        c.r(bx - 8, 71, 17, 4, 0xFF9A6A3C); c.r(bx - 6, 75, 13, 1, 0xFF6E4726); c.r(bx, 56, 1, 15, 0xFF6E4726);
        c.tri(bx + 6, 57, 12, 13, 0xFFFFFFFF); c.tri(bx - 4, 60, 8, 10, 0xFFFF8FB8);
        // the sand with the wet edge and the foam
        c.r(0, FL, W, H - FL, 0xFFF3D9A4);
        c.grad(0, FL, W, 8, 0xFFD8B880, 0xFFF3D9A4);
        for (int x = 0; x < W; x += 3) { int fy = FL - 2 + (int) Math.round(Math.sin(x / 9.0 + c.t / 18.0) * 2); c.r(x, fy, 3, 2, 0xAAFFFFFF); }
        tufts(c, 40, FL + 6, H - 4, 3, 0xFFD8B880);
        // palms on both sides
        for (int s = 0; s < 2; s++) {
            int px = s == 0 ? 22 : 276, lean = s == 0 ? 6 : -6, top = 44;
            for (int i = 0; i < 6; i++) c.r(px + lean * i / 6 + (s == 0 ? 0 : 0), FL - i * 10 + 4, 3, 10, i % 2 == 0 ? 0xFF8A5A3A : 0xFF7A4A2A);
            int tx = px + lean + 1, ty = top + 8;
            for (int k = -3; k <= 3; k++) { c.ln(tx, ty, tx + k * 7, ty - 4 + Math.abs(k) * 3 + (int) Math.round(Math.sin((c.t + k * 5) / 22.0)), 0xFF3FA55A); c.ln(tx, ty + 1, tx + k * 7, ty - 3 + Math.abs(k) * 3, 0xFF4FB86A); }
            c.b(tx - 1, ty + 2, 2, 0xFF6A4228); c.b(tx + 2, ty + 3, 2, 0xFF6A4228);
        }
        // an umbrella, a towel, a ball, a sandcastle and shells
        c.r(228, FL - 12, 1, 28, 0xFFE8E0E8);
        for (int i = 0; i < 24; i += 4) c.r(214 + i, FL - 14 + Math.abs(i - 12) / 4, 4, 5 - Math.abs(i - 12) / 6, (i / 4) % 2 == 0 ? 0xFFE5484D : 0xFFFFFFFF);
        c.o(228, FL + 22, 18, 5, 0xFF4D96FF); c.r(214, FL + 21, 28, 1, 0xFFFFFFFF); c.r(214, FL + 24, 28, 1, 0xFFFFFFFF);
        c.b(256, FL + 14, 4, 0xFFFFFFFF); c.r(253, FL + 12, 7, 2, 0xFFE5484D); c.r(255, FL + 15, 4, 2, 0xFF4D96FF);
        for (int i = 0; i < 3; i++) { int sx = 56 + i * 12; c.bev(sx, FL + 14 - i % 2 * 3, 10, 8 + i % 2 * 3, 0xFFEBC890, 0xFFFFE8B8, 0xFFC8A060); }          // a sandcastle
        c.r(56, FL + 8, 3, 3, 0xFFEBC890); c.r(63, FL + 8, 3, 3, 0xFFEBC890); c.r(60, FL + 6, 1, 4, 0xFF6E4726); c.r(61, FL + 6, 4, 3, 0xFFE5484D);
        c.b(40, FL + 24, 3, 0xFFFFC8D8); c.b(94, FL + 28, 2, 0xFFFFF0E0); c.tri(110, FL + 24, 6, 6, 0xFFFF8A4A);               // shells and a starfish
        // a crab that walks and gulls that fly
        int cxx = 150 + (int) Math.round(Math.sin(c.t / 40.0) * 80) , cy = FL + 34;
        if (cxx < 128 || cxx > 172) { c.o(cxx, cy, 4, 2, 0xFFE8503A); c.r(cxx - 6, cy - 3, 2, 2, 0xFFE8503A); c.r(cxx + 5, cy - 3, 2, 2, 0xFFE8503A); c.r(cxx - 2, cy - 4, 1, 2, 0xFF3A2A3A); c.r(cxx + 2, cy - 4, 1, 2, 0xFF3A2A3A); }
        for (int i = 0; i < 3; i++) bird(c, (c.t / 2 * (i + 1) + i * 90) % (W + 20) - 10, 20 + i * 12 + (int) Math.round(Math.sin(c.t / 12.0 + i) * 2), 0xFFFFFFFF);
    }

    // ---------- 2: the forest ----------
    private static void forest(C c) {
        c.grad(0, 0, W, FL, 0xFFCFEFB0, 0xFF6FBF70);
        for (int i = 0; i < 5; i++) {                                                  // light rays between the trees
            int rx = 40 + i * 56;
            for (int k = 0; k < FL; k++) c.r(rx + k / 3, k, 7 + k / 18, 1, 0x16FFFFC0);
        }
        hills(c, FL - 10, 22, 0xFF4E9F5A, 0.03, 1.0, 0, W);
        for (int i = 0; i < 9; i++) pine(c, 10 + i * 34, FL - 6, 52 + (i * 13) % 14, 24, 0xFF2F7A48, false);   // the far wall of trees
        c.grad(0, 0, W, 30, 0x30206030, 0x00206030);
        c.r(0, FL - 6, W, H - FL + 6, 0xFF3F9A4C);
        c.grad(0, FL - 6, W, 14, 0xFF2E7A3A, 0xFF3F9A4C);
        // big trunks at the edges with canopies
        for (int s = 0; s < 2; s++) {
            int tx = s == 0 ? 14 : 284;
            c.r(tx - 7, 0, 14, FL + 10, 0xFF6A4228); c.r(tx - 7, 0, 4, FL + 10, 0xFF8A5A3A); c.r(tx + 4, 0, 3, FL + 10, 0xFF4A2E1A);
            for (int k = 0; k < 6; k++) c.r(tx - 5 + (k * 3) % 8, 10 + k * 17, 1, 8, 0xFF4A2E1A);
            c.b(tx + (s == 0 ? 14 : -14), 14, 18, 0xFF2E8B4A); c.b(tx + (s == 0 ? 6 : -6), 4, 16, 0xFF3FA55A);
            c.o(tx, FL + 11, 18, 4, 0x2A000000);
        }
        // a stream in the grass with stones
        c.o(210, FL + 28, 60, 7, 0xFF3F9AD0); c.o(210, FL + 27, 56, 5, 0xFF7BC8F0);
        for (int i = 0; i < 4; i++) c.r(176 + (i * 17 + c.t / 4) % 72, FL + 25 + i % 3 * 2, 6, 1, 0x88FFFFFF);
        for (int i = 0; i < 5; i++) c.o(166 + i * 22, FL + 34, 5, 2, 0xFF8A8E98);
        // mushrooms, ferns, a log and flowers
        for (int i = 0; i < 4; i++) {
            int mxp = 52 + i * 11, myp = FL + 12 + (i % 2) * 5, s = 2 + i % 2;
            c.r(mxp, myp, 2, 4, 0xFFF3E8D0); c.o(mxp + 1, myp, s + 2, s, i % 2 == 0 ? 0xFFE5484D : 0xFFF58FB8);
            c.r(mxp - 1, myp - 1, 1, 1, 0xFFFFFFFF); c.r(mxp + 2, myp - 2, 1, 1, 0xFFFFFFFF);
        }
        for (int i = 0; i < 3; i++) { int fx = 100 + i * 60; for (int k = -3; k <= 3; k++) c.ln(fx, FL + 20, fx + k * 3, FL + 12 + Math.abs(k) * 2, 0xFF2E8B4A); }
        c.rr(112, FL + 18, 46, 10, 4, 0xFF7A4A2A); c.o(112, FL + 23, 3, 5, 0xFFD8B070); c.o(112, FL + 23, 1, 2, 0xFF9A6A3C); c.r(120, FL + 19, 30, 1, 0xFF9A6A3C);
        c.r(124, FL + 17, 6, 2, 0xFF5CC560); c.r(136, FL + 17, 8, 2, 0xFF5CC560);
        flowers(c, 14, FL + 6, H - 8, 0, W, 5, 0xFFFFF3B0, 0xFFFF8FB8, 0xFFFFFFFF, 0xFFB57BD6);
        tufts(c, 30, FL, H - 4, 4, 0xFF2E7A3A);
        // a squirrel on the trunk, birds and drifting leaves
        c.o(26, 64, 3, 4, 0xFFB5651D); c.b(28, 59, 2, 0xFFB5651D); c.o(22, 60, 2, 5, 0xFFD08A4A);
        for (int i = 0; i < 8; i++) { int lx = (i * 41 + c.t / 3 * (1 + i % 2)) % W, ly = (i * 23 + c.t / 2) % (FL - 20); c.r(lx, ly, 2, 1, i % 2 == 0 ? 0xFFF5B84A : 0xFF9ADC70); }
        bird(c, (c.t / 3) % (W + 20) - 10, 22, 0xFF3A5A8A); bird(c, (c.t / 4 + 120) % (W + 20) - 10, 34, 0xFFB5481D);
    }

    // ---------- 3: the mountains ----------
    private static void mountains(C c) {
        c.grad(0, 0, W, FL, 0xFF6EB8FF, 0xFFE8F6FF);
        sun(c, 60, 24, 9, 0xFFFFF0A0);
        drift(c, 3, 14, 30, 0xEEFFFFFF, 0.08);
        // far mountains with snow, then near ones
        for (int layer = 0; layer < 2; layer++) {
            int[] px = layer == 0 ? new int[]{60, 170, 270} : new int[]{20, 118, 215};
            int[] ph = layer == 0 ? new int[]{72, 88, 66} : new int[]{54, 62, 50};
            int col = layer == 0 ? 0xFF8C9DC0 : 0xFF6A7898;
            for (int i = 0; i < 3; i++) {
                int base = FL - (layer == 0 ? 8 : 0);
                c.tri(px[i], base - ph[i], ph[i] * 2 + 20, ph[i], col);
                c.tri(px[i] + ph[i] / 4, base - ph[i] + ph[i] / 3, ph[i] + 8, ph[i] * 2 / 3, dim(col, 0.18F));   // the shaded side
                c.tri(px[i], base - ph[i], ph[i] * 6 / 10, ph[i] * 3 / 10 + 2, 0xFFFFFFFF);
                c.r(px[i] - ph[i] * 3 / 10 + 2, base - ph[i] + ph[i] * 3 / 10 + 1, ph[i] * 6 / 10 - 4, 1, 0xFFDDE8F8);
            }
        }
        // pine slopes
        hills(c, FL + 2, 14, 0xFF3F8A58, 0.05, 2.0, 0, W);
        for (int i = 0; i < 12; i++) pine(c, 6 + i * 26 + (i % 3) * 5, FL + 3 + (i % 2) * 2, 26 + (i * 7) % 12, 14, i % 2 == 0 ? 0xFF2F7A48 : 0xFF286A40, i % 3 == 0);
        c.r(0, FL + 4, W, H - FL - 4, 0xFF5BBF6A);
        c.grad(0, FL + 4, W, 10, 0xFF3F8A58, 0xFF5BBF6A);
        // a mountain lake with a reflection
        c.o(222, FL + 30, 62, 9, 0xFF4D96D8); c.o(222, FL + 29, 58, 7, 0xFF8AC8F0);
        c.tri(222, FL + 25, 30, 9, 0x558C9DC0); c.tri(205, FL + 26, 16, 6, 0x44FFFFFF);
        for (int i = 0; i < 4; i++) c.r(190 + (i * 19 + c.t / 5) % 60, FL + 24 + i * 3, 8, 1, 0x77FFFFFF);
        // a log cabin with a chimney and smoke
        c.o(48, FL + 21, 26, 3, 0x28000000);
        c.r(26, FL + 4, 44, 18, 0xFF9A6A3C);
        for (int k = 0; k < 4; k++) c.r(26, FL + 6 + k * 4, 44, 1, 0xFF7A4A2A);
        c.tri(48, FL - 14, 56, 18, 0xFFC8553D); c.tri(44, FL - 12, 34, 13, 0xFFE8806A);
        c.r(58, FL - 14, 6, 10, 0xFF6E4726);
        c.r(44, FL + 10, 8, 12, 0xFF5A3A22); c.r(50, FL + 16, 1, 1, 0xFFFFD34E);
        c.bev(30, FL + 8, 9, 8, 0xFFFFE680, 0xFFFFFFFF, 0xFF5A3A22); c.bev(58, FL + 8, 9, 8, 0xFFFFE680, 0xFFFFFFFF, 0xFF5A3A22);
        for (int i = 0; i < 4; i++) c.b(61 + (int) Math.round(Math.sin((c.t + i * 17) / 14.0) * 2) + i, FL - 18 - i * 6 - (c.t / 5 + i * 5) % 6, 2 + i / 2, 0x77FFFFFF);
        // a flag, a signpost, flowers, rocks
        c.r(102, FL + 4, 1, 26, 0xFF8A5A3A); c.r(103, FL + 5, 10, 4, 0xFFE5484D); c.r(103, FL + 5, 10, 1, 0xFFFF8A8A);
        c.r(250, FL + 8, 2, 20, 0xFF8A5A3A); c.bev(252, FL + 9, 22, 6, 0xFFC8955C, 0xFFE8B880, 0xFF7A4A2A); c.bev(240, FL + 16, 20, 6, 0xFFC8955C, 0xFFE8B880, 0xFF7A4A2A);
        c.o(120, FL + 40, 7, 4, 0xFF8A8E98); c.o(124, FL + 38, 4, 3, 0xFFA0A4B0);
        flowers(c, 16, FL + 10, H - 6, 90, W, 7, 0xFFFFFFFF, 0xFFFF8FB8, 0xFFFFF3B0, 0xFF8FB8F0);
        bird(c, (c.t / 2) % (W + 20) - 10, 18, 0xFF3A4A6A); bird(c, (c.t / 2 + 40) % (W + 20) - 10, 26, 0xFF3A4A6A);
    }

    // ---------- 4: a city at dusk ----------
    private static void city(C c) {
        c.grad(0, 0, W, FL + 10, 0xFF2A1E5E, 0xFFFF9AB8);
        stars(c, 20, 40, 2);
        c.b(240, 30, 10, 0xFFFFE9B0); c.b(244, 27, 9, 0xFF3A2A6A);
        for (int layer = 0; layer < 2; layer++) {                                      // two rows of towers
            int n = layer == 0 ? 14 : 10, col = layer == 0 ? 0xFF3A2D6E : 0xFF241A4A;
            for (int i = 0; i < n; i++) {
                int bw = layer == 0 ? 22 : 30, bx = i * (W / n) + (layer * 9), bh = (layer == 0 ? 38 : 30) + (i * 37 + layer * 11) % (layer == 0 ? 40 : 38);
                int by = FL + 8 - bh;
                c.r(bx, by, bw, bh, col);
                c.r(bx, by, bw, 1, lit(col, 0.2F));
                if (i % 3 == 0) { c.r(bx + bw / 2, by - 8, 1, 8, lit(col, 0.2F)); c.r(bx + bw / 2, by - 8, 1, 1, (c.t / 10) % 2 == 0 ? 0xFFFF4D4D : 0xFF7A1A1A); }
                for (int wy = by + 4; wy < FL + 4; wy += 5) for (int wx = bx + 3; wx < bx + bw - 3; wx += 5) {
                    boolean on = ((wx * 7 + wy * 13 + layer * 5) % 7) > 2;
                    c.r(wx, wy, 3, 3, on ? (((wx + wy) % 11 == 0) ? 0xFFFFC8E8 : 0xFFFFE680) : 0xFF3A3070);
                }
            }
        }
        // the road with a pavement, lamps, a crossing and cars
        c.r(0, FL + 8, W, H - FL - 8, 0xFF3A3A4E);
        c.r(0, FL + 8, W, 7, 0xFF7A7A90); c.r(0, FL + 8, W, 1, 0xFFA0A0B8);
        for (int x = 0; x < W; x += 20) c.r(x + 2, FL + 28, 10, 1, 0xFFFFE680);
        for (int i = 0; i < 6; i++) c.r(236 + i * 6, FL + 17, 4, 24, 0xFFE8E8F0);
        for (int i = 0; i < 5; i++) {
            int lx = 20 + i * 62;
            c.r(lx, FL - 14, 1, 22, 0xFF222030); c.r(lx, FL - 14, 5, 1, 0xFF222030); c.b(lx + 5, FL - 12, 2, 0xFFFFE680);
            c.b(lx + 5, FL - 8, 9, 0x16FFE680); c.b(lx + 5, FL - 8, 5, 0x22FFE680);
        }
        int[] cc = {0xFFE5484D, 0xFFFFD84D, 0xFF4D96FF, 0xFFFF8FB8};
        for (int i = 0; i < 3; i++) {
            int dir = i % 2 == 0 ? 1 : -1, cx = dir > 0 ? (c.t * (1 + i % 2) / 2 + i * 120) % (W + 60) - 30 : W + 30 - (c.t * 2 / 3 + i * 90) % (W + 60), cy = FL + 18 + i * 8;
            c.rr(cx - 9, cy - 5, 19, 7, 2, cc[i]); c.rr(cx - 5, cy - 9, 11, 6, 2, lit(cc[i], 0.15F)); c.r(cx - 3, cy - 8, 3, 3, 0xFFBFE6FF); c.r(cx + 1, cy - 8, 3, 3, 0xFFBFE6FF);
            c.b(cx - 5, cy + 2, 2, 0xFF1A1A24); c.b(cx + 5, cy + 2, 2, 0xFF1A1A24); c.r(cx + (dir > 0 ? 9 : -10), cy - 2, 2, 2, 0xFFFFF0A0);
        }
        // a neon sign and a billboard
        c.rr(18, 28, 44, 14, 3, 0xFF1A1030); c.rr(20, 30, 40, 10, 2, 0xFFFF4DA6); c.r(24, 33, 6, 1, 0xFFFFFFFF); c.r(34, 33, 10, 1, 0xFFFFFFFF); c.r(24, 36, 20, 1, 0xFFFFFFFF);
        c.r(196, 40, 1, 18, 0xFF222030); c.r(220, 40, 1, 18, 0xFF222030); c.rr(190, 20, 38, 22, 2, 0xFF222030); c.r(192, 22, 34, 18, (c.t / 40) % 2 == 0 ? 0xFF8FD3FF : 0xFFFFD0E2);
        c.b(204, 31, 4, 0xFFFFE066); heart(c, 216, 28, 0xFFFF6B8E);
        // trees on the pavement
        for (int i = 0; i < 4; i++) roundTree(c, 56 + i * 62 + 14, FL + 10, 8, 7, 0xFF3F7A5A);
    }

    // ---------- 5: the moon ----------
    private static void moon(C c) {
        c.r(0, 0, W, H, 0xFF08082A);
        c.grad(0, 0, W, FL, 0xFF05051A, 0xFF1A1A4A);
        stars(c, 46, 90, 5);
        // the Earth, big, with clouds
        c.b(228, 40, 22, 0x224D96FF); c.b(228, 40, 19, 0xFF3A86E8); c.b(222, 36, 6, 0xFF5CC878); c.b(234, 46, 7, 0xFF5CC878); c.b(236, 30, 3, 0xFF5CC878);
        c.r(212, 40, 18, 2, 0x99FFFFFF); c.r(224, 28, 14, 2, 0x99FFFFFF); c.r(220, 50, 12, 1, 0x99FFFFFF);
        c.b(240, 48, 12, 0x33000814);
        // far crater rim, the grey ground with craters
        for (int x = 0; x < W; x++) { int top = FL - 6 + (int) Math.round(Math.sin(x / 31.0) * 5 + Math.sin(x / 11.0) * 2); c.r(x, top, 1, H - top, 0xFF8A8EA0); }
        c.grad(0, FL - 2, W, H - FL + 2, 0xFFB4B8C8, 0xFF8A8EA0);
        int[][] cr = {{40, 18, 20, 5}, {96, 40, 14, 4}, {220, 26, 26, 6}, {262, 44, 14, 4}, {166, 50, 10, 3}, {30, 52, 9, 3}};
        for (int[] k : cr) { c.o(k[0], FL + k[1], k[2], k[3], 0xFF7A7E90); c.o(k[0], FL + k[1] + 1, k[2] - 2, k[3] - 1, 0xFF9A9EB0); c.r(k[0] - k[2] + 3, FL + k[1] - 1, k[2] * 2 - 6, 1, 0xFFC8CCDC); }
        // a lander, a flag, a rover
        c.r(56, FL - 2, 3, 12, 0xFFE8E8F0); c.r(52, FL + 8, 11, 2, 0xFFB8B8C8); c.rr(46, FL - 20, 22, 14, 4, 0xFFE8E8F0); c.rr(46, FL - 20, 22, 4, 2, 0xFFFFFFFF); c.bev(52, FL - 15, 10, 6, 0xFF4D96FF, 0xFF9AC8FF, 0xFF2A56A0);
        c.ln(48, FL - 6, 40, FL + 10, 0xFFB8B8C8); c.ln(66, FL - 6, 74, FL + 10, 0xFFB8B8C8); c.r(38, FL + 10, 6, 1, 0xFFB8B8C8); c.r(72, FL + 10, 6, 1, 0xFFB8B8C8);
        c.r(98, FL - 14, 1, 24, 0xFFD8D8E0); c.r(99, FL - 14, 14, 9, 0xFFFF8FB8); c.r(99, FL - 14, 14, 1, 0xFFFFC8DC); heart(c, 106, FL - 12, 0xFFFFFFFF);
        int rx = 200 + (int) Math.round(Math.sin(c.t / 50.0) * 10);
        c.rr(rx - 10, FL + 8, 22, 7, 2, 0xFFD8D8E0); c.r(rx - 3, FL + 3, 8, 5, 0xFFB8B8C8); c.b(rx - 7, FL + 17, 3, 0xFF3A3A4A); c.b(rx + 7, FL + 17, 3, 0xFF3A3A4A); c.b(rx, FL + 17, 3, 0xFF3A3A4A);
        c.ln(rx + 4, FL + 3, rx + 10, FL - 6, 0xFFB8B8C8); c.b(rx + 10, FL - 7, 3, 0xFFFFFFFF);
        // a shooting star and sparkles
        int sx = (c.t * 3) % 500 - 100;
        if (sx > 0 && sx < W) { c.ln(sx, 10 + sx / 6, sx - 14, 6 + sx / 6 - 6, 0x66FFFFFF); c.r(sx, 10 + sx / 6, 2, 2, 0xFFFFFFFF); }
        // rocks, footprints and a little dust that floats
        for (int i = 0; i < 7; i++) { int qx = 14 + (i * 83) % 270, qy = FL + 12 + (i * 29) % 40; if (Math.abs(qx - 150) < 30 && qy < FL + 30) continue; c.o(qx, qy, 3 + i % 3, 2 + i % 2, 0xFF70748A); c.o(qx - 1, qy - 1, 2 + i % 3, 1 + i % 2, 0xFF9A9EB2); }
        for (int i = 0; i < 6; i++) c.r(100 + i * 9, FL + 24 + (i % 2) * 3, 3, 2, 0xFF7A7E90);
        for (int i = 0; i < 5; i++) { int dx = (i * 61 + c.t / 4) % W, dy = FL - 10 - (c.t / 5 + i * 11) % 20; c.r(dx, dy, 1, 1, 0x66C8CCDC); }
        c.b(150, 20, 1, 0x55FFFFFF);
    }

    // ---------- 6: the bee meadow ----------
    private static void meadow(C c) {
        c.grad(0, 0, W, FL, 0xFFA8E0FF, 0xFFFFF6C8);
        sun(c, 40, 24, 11, 0xFFFFE066);
        drift(c, 3, 8, 30, 0xEEFFFFFF, 0.09);
        hills(c, FL - 8, 20, 0xFF9ADB78, 0.025, 0.4, 0, W);
        hills(c, FL, 12, 0xFF7ACB6A, 0.04, 1.6, 0, W);
        // a windmill on a hill and a fence
        c.r(238, FL - 38, 12, 36, 0xFFF3E8D0); c.tri(244, FL - 50, 18, 12, 0xFFC8553D); c.r(240, FL - 38, 1, 36, 0xFFD8CDB8); c.r(243, FL - 12, 5, 10, 0xFF8A5A3A);
        double ang = c.t / 40.0;
        for (int k = 0; k < 4; k++) { double a = ang + k * Math.PI / 2; for (int s = 3; s < 21; s++) c.r(244 + (int) Math.round(Math.cos(a) * s), FL - 44 + (int) Math.round(Math.sin(a) * s), 2, 2, s > 8 ? 0xFFFFFFFF : 0xFFC8955C); }
        c.b(244, FL - 44, 2, 0xFF6E4726);
        c.r(0, FL, W, H - FL, 0xFF6BC85A); c.grad(0, FL, W, 12, 0xFF5BB84A, 0xFF6BC85A);
        for (int i = 0; i < 13; i++) { c.r(i * 8 - 2, FL + 1, 2, 10, 0xFFFFF8E8); c.r(i * 8 - 2, FL + 1, 2, 1, 0xFFFFFFFF); }
        c.r(0, FL + 3, 104, 2, 0xFFFFF8E8); c.r(0, FL + 7, 104, 2, 0xFFFFF8E8);
        // the big hive on a stump with honey, and a honey jar sign
        c.o(40, FL + 28, 22, 3, 0x28000000);
        c.r(32, FL + 22, 16, 6, 0xFF8A5A3A);
        for (int i = 0; i < 5; i++) { int ww = 24 - Math.abs(i - 2) * 3; c.rr(40 - ww / 2, FL + 22 - (i + 1) * 7, ww, 7, 3, i % 2 == 0 ? 0xFFF5B800 : 0xFFFFD84D); c.r(40 - ww / 2 + 2, FL + 22 - (i + 1) * 7 + 1, ww - 4, 1, 0x66FFFFFF); }
        c.b(40, FL - 4, 3, 0xFF3A2A3A); c.r(39, FL - 3, 3, 4, 0xFF3A2A3A);
        c.r(38, FL - 10, 5, 3, 0xFFFFE680); c.r(39, FL - 7, 3, 6, 0xFFE8A800);
        for (int i = 0; i < 4; i++) { int bx = 40 + (int) Math.round(Math.cos(c.t / 9.0 + i * 1.6) * (14 + i * 3)), by = FL - 6 + (int) Math.round(Math.sin(c.t / 6.0 + i * 1.6) * 8); c.r(bx, by, 3, 2, 0xFFFFC832); c.r(bx + 1, by, 1, 2, 0xFF3A2A3A); c.r(bx, by - 1, 2, 1, 0x99FFFFFF); }
        // lots of tall flowers: daisies, tulips, sunflowers
        for (int i = 0; i < 26; i++) {
            int fx = 70 + (i * 41 + 17) % 220, fy = FL + 14 + (i * 23) % 36, kind = i % 4;
            if (Math.abs(fx - 150) < 24 && fy < FL + 30) continue;
            c.r(fx, fy, 1, 9, 0xFF3F9E48); c.r(fx + 1, fy + 4, 2, 1, 0xFF3F9E48);
            if (kind == 0) { c.b(fx, fy, 3, 0xFFFFFFFF); c.b(fx, fy, 1, 0xFFFFD34E); }
            else if (kind == 1) { c.r(fx - 2, fy - 3, 5, 5, 0xFFFF6B8E); c.r(fx - 2, fy - 4, 1, 2, 0xFFFF6B8E); c.r(fx + 2, fy - 4, 1, 2, 0xFFFF6B8E); c.r(fx - 1, fy - 3, 1, 3, 0xFFFF9AB0); }
            else if (kind == 2) { c.b(fx, fy - 1, 4, 0xFFFFC832); c.b(fx, fy - 1, 2, 0xFF6A4228); }
            else { c.b(fx, fy, 3, 0xFFB57BD6); c.b(fx, fy, 1, 0xFFFFF3B0); }
        }
        // butterflies and a ladybird
        for (int i = 0; i < 3; i++) { int bx = 90 + i * 70 + (int) Math.round(Math.sin(c.t / 30.0 + i * 2) * 30), by = 70 + i * 8 + (int) Math.round(Math.sin(c.t / 12.0 + i) * 6); int wg = (c.t / 5 + i) % 2; c.r(bx - 2 - wg, by, 2 + wg, 3, i % 2 == 0 ? 0xFFFF8FB8 : 0xFF8FD3FF); c.r(bx + 1, by, 2 + wg, 3, i % 2 == 0 ? 0xFFFFC83A : 0xFFB57BD6); c.r(bx, by, 1, 3, 0xFF3A2A3A); }
        c.b(262, FL + 36, 2, 0xFFE5484D); c.r(262, FL + 34, 1, 4, 0xFF3A2A3A);
        bird(c, (c.t / 3) % (W + 20) - 10, 30, 0xFF4A5A7A);
    }

    // ---------- 7: a city in the clouds ----------
    private static void clouds(C c) {
        c.grad(0, 0, W, H, 0xFF4A7AE8, 0xFFFFC0DC);
        // a rainbow and a sun glow
        int[] rc = {0xFFFF8A8A, 0xFFFFC890, 0xFFFFF0A0, 0xFFA8E8A8, 0xFF9AC8FF, 0xFFC8A8F0};
        for (int i = 0; i < 6; i++) c.b(80, FL + 40, 100 - i * 3, rc[i] & 0x00FFFFFF | 0x66000000);
        c.b(80, FL + 40, 80, 0xFF6A8AF0 & 0x00FFFFFF | 0x00000000);
        sun(c, 252, 26, 9, 0xFFFFF0B8);
        stars(c, 10, 30, 7);
        // sea of clouds below
        for (int layer = 0; layer < 3; layer++) for (int i = 0; i < 9; i++) {
            int cx = i * 36 - 10 + layer * 12 + (int) ((c.t * (0.04 + layer * 0.03)) % 36), cy = FL + 16 + layer * 12;
            c.b(cx, cy, 14 - layer, lit(0xFFFFFFFF, 0F) & 0x00FFFFFF | (0xFF - layer * 0x1C) << 24);
            c.b(cx + 14, cy + 3, 11 - layer, 0xFFFFFFFF & 0x00FFFFFF | (0xFF - layer * 0x1C) << 24);
        }
        c.r(0, FL + 30, W, H - FL - 30, 0xFFFFE8F4);
        drift(c, 3, 12, 40, 0xCCFFFFFF, 0.12);
        // floating islands with houses, trees, waterfalls
        int[][] isl = {{60, 54, 56}, {208, 44, 70}, {140, 88, 44}};
        for (int k = 0; k < isl.length; k++) {
            int ix = isl[k][0], iy = isl[k][1] + (int) Math.round(Math.sin((c.t + k * 40) / 34.0) * 3), iw = isl[k][2];
            c.tri(ix, iy + 3, iw - 6, 22 + k * 3, 0xFF8A6A4A); c.tri(ix - iw / 5, iy + 4, iw / 2, 14, 0xFF7A5A3A);
            c.o(ix, iy + 2, iw / 2, 5, 0xFF6BCB6A); c.o(ix, iy, iw / 2 - 2, 4, 0xFF8EE08A);
            for (int i = 0; i < 4; i++) c.r(ix - iw / 3 + i * 9, iy + 3, 2, 2 + i % 2, 0xFF4FA84F);
            if (k == 1) {
                c.r(ix + iw / 2 - 12, iy + 4, 3, 26, 0x88BFE6FF); c.r(ix + iw / 2 - 12, iy + 28 + (c.t / 4) % 4, 3, 2, 0xCCFFFFFF);
            }
            if (k == 0) { house(c, ix - 20, iy, 18, 14, 0xFFFFF0E0, 0xFFE5484D, false); roundTree(c, ix + 14, iy, 8, 7, 0xFF3FA55A); }
            if (k == 1) { house(c, ix - 30, iy, 20, 16, 0xFFFFE8F0, 0xFF4D96FF, false); house(c, ix - 6, iy, 16, 12, 0xFFFFF4D0, 0xFFB57BD6, false); roundTree(c, ix + 26, iy, 9, 8, 0xFFF58FB8); }
            if (k == 2) { c.r(ix - 1, iy - 14, 2, 14, 0xFFFFFFFF); c.r(ix + 1, iy - 14, 12, 8, 0xFFFF8FB8); for (int i = 0; i < 3; i++) c.r(ix + 1, iy - 13 + i * 3, 12, 1, 0xFFFFFFFF); }
        }
        // bridges of light between islands
        for (int i = 0; i < 12; i++) c.r(88 + i * 4, 56 - (int) Math.round(Math.sin(i / 12.0 * Math.PI) * 4), 3, 1, 0xCCFFE8A8);
        // an airship, birds and sparkles
        int ax = (c.t / 3) % (W + 80) - 40, ay = 30 + (int) Math.round(Math.sin(c.t / 25.0) * 3);
        c.o(ax, ay, 14, 6, 0xFFE5484D); c.o(ax, ay - 1, 12, 4, 0xFFFF8A8A); c.r(ax - 6, ay + 6, 12, 5, 0xFF8A5A3A); c.r(ax - 14, ay - 2, 3, 4, 0xFFFFD84D);
        for (int i = 0; i < 3; i++) bird(c, (c.t / 2 + i * 70) % (W + 20) - 10, 70 + i * 10, 0xFFFFFFFF);
        for (int i = 0; i < 6; i++) if ((c.t / 10 + i) % 3 == 0) { int sx = 20 + (i * 53) % 260, sy = 20 + (i * 31) % 80; c.r(sx, sy - 1, 1, 3, 0xCCFFFFFF); c.r(sx - 1, sy, 3, 1, 0xCCFFFFFF); }
    }

    // ---------- 8: a snowy village at night ----------
    private static void village(C c) {
        c.grad(0, 0, W, FL, 0xFF0C1438, 0xFF3A4A8A);
        stars(c, 34, 60, 8);
        for (int i = 0; i < 40; i++) {                                                  // the northern lights
            int ax = i * 8, ah = 14 + (int) Math.round(Math.sin(i * 0.4 + c.t / 40.0) * 8);
            c.grad(ax, 10 + (int) Math.round(Math.sin(i * 0.25 + c.t / 60.0) * 6), 8, ah + 20, 0x3A5CFFC0, 0x005CFFC0);
        }
        c.b(250, 28, 9, 0xFFF4F1D8); c.b(254, 25, 8, 0xFF1A2658);
        hills(c, FL - 6, 18, 0xFF2A3A78, 0.03, 0.9, 0, W);
        for (int i = 0; i < 8; i++) pine(c, 8 + i * 42, FL - 4, 36 + (i * 7) % 10, 18, 0xFF1A4A44, true);
        c.r(0, FL - 2, W, H - FL + 2, 0xFFF4F9FF);
        c.grad(0, FL - 2, W, 12, 0xFFC8D8F4, 0xFFF4F9FF);
        for (int i = 0; i < 30; i++) c.r((i * 37 + 9) % W, FL + 4 + (i * 17) % 40, 3, 1, 0xFFDCE8FA);          // snow ripples
        // cottages with glowing windows and smoke
        house(c, 18, FL + 10, 44, 28, 0xFF9A6A3C, 0xFFF4F9FF, true);
        c.tri(50, FL - 38, 10, 10, 0xFF6E4726);
        for (int i = 0; i < 4; i++) c.b(50 + (int) Math.round(Math.sin((c.t + i * 15) / 14.0) * 2), FL - 40 - i * 6 - (c.t / 6 + i * 3) % 6, 2 + i / 2, 0x88FFFFFF);
        house(c, 226, FL + 12, 52, 30, 0xFFC8553D, 0xFFF4F9FF, true);
        house(c, 188, FL + 8, 28, 20, 0xFF7A8AB8, 0xFFF4F9FF, true);
        for (int i = 0; i < 3; i++) c.b(244 + (int) Math.round(Math.sin((c.t + i * 15) / 14.0) * 2), FL - 28 - i * 6 - (c.t / 6 + i * 3) % 6, 2 + i / 2, 0x88FFFFFF);
        // a snowman, a lamp, a sleigh and presents
        c.o(88, FL + 36, 12, 3, 0x22000000); c.b(88, FL + 30, 7, 0xFFFFFFFF); c.b(88, FL + 20, 5, 0xFFFFFFFF); c.b(88, FL + 12, 4, 0xFFFFFFFF);
        c.r(86, FL + 11, 1, 1, 0xFF3A2A3A); c.r(90, FL + 11, 1, 1, 0xFF3A2A3A); c.r(88, FL + 13, 4, 1, 0xFFFF8A4A);
        c.r(84, FL + 15, 9, 2, 0xFFE5484D); c.r(91, FL + 16, 2, 6, 0xFFE5484D); c.rr(83, FL + 6, 11, 3, 1, 0xFF3A2A3A); c.r(85, FL + 2, 7, 5, 0xFF3A2A3A);
        c.ln(81, FL + 20, 76, FL + 16, 0xFF6A4228); c.ln(95, FL + 20, 100, FL + 16, 0xFF6A4228);
        c.r(124, FL - 12, 2, 38, 0xFF2A2A3A); c.rr(120, FL - 18, 10, 8, 2, 0xFFFFE680); c.b(125, FL - 14, 14, 0x16FFE680); c.b(125, FL - 14, 9, 0x24FFE680);
        c.rr(176, FL + 34, 22, 6, 2, 0xFFC8553D); c.r(174, FL + 40, 28, 1, 0xFFD8D8E0); c.r(198, FL + 30, 2, 5, 0xFFC8553D);
        c.bev(206, FL + 32, 8, 8, 0xFF4D96FF, 0xFF9AC8FF, 0xFF2A56A0); c.r(209, FL + 32, 2, 8, 0xFFFFD84D);
        c.bev(216, FL + 35, 7, 5, 0xFF6BCB77, 0xFFB0E8B8, 0xFF3A8A4A); c.r(218, FL + 35, 2, 5, 0xFFFF8FB8);
        // a fence, a wreath, falling snow
        for (int i = 0; i < 9; i++) { c.r(130 + i * 6, FL + 20, 2, 9, 0xFF8A5A3A); c.r(130 + i * 6, FL + 19, 2, 1, 0xFFFFFFFF); }
        c.r(130, FL + 22, 52, 1, 0xFF8A5A3A); c.r(130, FL + 26, 52, 1, 0xFF8A5A3A);
        for (int i = 0; i < 46; i++) c.r(((i * 53 + c.t / 3 * (1 + i % 2) + (int) Math.round(Math.sin((c.t + i * 9) / 22.0) * 4)) % W + W) % W, (i * 37 + c.t * (1 + i % 2) / 2) % (H - 4), 2, 2, 0xCCFFFFFF);
    }
}
