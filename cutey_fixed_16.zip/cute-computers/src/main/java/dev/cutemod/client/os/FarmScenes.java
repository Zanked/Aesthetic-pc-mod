package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/** Pictures for the farm: far hills with a barn and a windmill, the meadow, hay and hens. Pure drawing. */
final class FarmScenes {
    private FarmScenes() {}

    private static final int W = 300, H = 166;

    private static int mix(int a, int b, float f) {
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int shade(int c, boolean night) { return night ? mix(c, 0xFF1E2A5A, 0.55F) : c; }

    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(1 - (dy * dy) / (double) (ry * ry + 1)));
            rect(g, cx - dx, cy + dy, dx * 2 + 1, 1, argb);
        }
    }

    private static void ln(GuiGraphics g, int x0, int y0, int x1, int y1, int argb) {
        int n = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)));
        for (int i = 0; i <= n; i++) rect(g, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, 1, 1, argb);
    }

    /** Over the sky, under the fence (y 14..56): hills, trees, a barn with a silo, a turning windmill. */
    static void far(GuiGraphics g, boolean night, int t) {
        disc(g, 40, 62, 34, shade(0xFFA8DCA8, night)); disc(g, 150, 66, 40, shade(0xFF98D49A, night)); disc(g, 262, 64, 36, shade(0xFFA8DCA8, night));
        for (int i = 0; i < 12; i++) {                                                        // far trees
            int tx = 10 + i * 25 + (i % 3) * 3;
            rect(g, tx, 44 - (i % 2) * 2, 2, 8, shade(0xFF6A4A2A, night));
            disc(g, tx + 1, 42 - (i % 2) * 2, 5, shade(i % 2 == 0 ? 0xFF58B06A : 0xFF4FA55E, night));
        }
        // the barn
        int bx = 214, by = 28;
        rect(g, bx, by + 6, 34, 24, shade(0xFFD8584A, night));
        for (int r = 0; r < 8; r++) rect(g, bx - 2 + r * 2, by - 2 + (7 - r) * 0 + r, 38 - r * 4, 1, shade(0xFFA83A3A, night));
        for (int r = 0; r < 7; r++) { rect(g, bx - 2 + r * 2, by - 1 + r, 2, 1, shade(0xFFB84444, night)); rect(g, bx + 36 - r * 2 - 2, by - 1 + r, 2, 1, shade(0xFFB84444, night)); }
        rect(g, bx + 10, by + 14, 14, 16, shade(0xFFFFF3E0, night));
        rect(g, bx + 10, by + 14, 14, 2, shade(0xFFA83A3A, night));
        ln(g, bx + 10, by + 16, bx + 23, by + 29, shade(0xFFA83A3A, night)); ln(g, bx + 23, by + 16, bx + 10, by + 29, shade(0xFFA83A3A, night));
        rect(g, bx + 15, by + 6, 4, 4, night ? 0xFFFFE680 : shade(0xFFFFF3E0, night));
        rect(g, bx + 38, by + 2, 9, 28, shade(0xFFC8C8D8, night)); disc(g, bx + 42, by + 2, 5, shade(0xFFA8A8B8, night));
        for (int r = 0; r < 28; r += 6) rect(g, bx + 38, by + 6 + r, 9, 1, shade(0xFF9A9AAA, night));
        // the windmill
        int wx = 160, wy = 22;
        for (int r = 0; r < 22; r++) rect(g, wx - 5 + r / 6, wy + r, 11 - r / 3, 1, shade(0xFFF2E6D2, night));
        rect(g, wx - 2, wy + 14, 4, 8, shade(0xFF8A5A3A, night));
        rect(g, wx - 5, wy - 3, 11, 4, shade(0xFFC85A4A, night));
        double a = t / 36.0;
        for (int i = 0; i < 4; i++) {
            double aa = a + i * Math.PI / 2;
            int ex = wx + (int) Math.round(Math.cos(aa) * 13), ey = wy - 1 + (int) Math.round(Math.sin(aa) * 13);
            ln(g, wx, wy - 1, ex, ey, shade(0xFFFFFFFF, night));
            ln(g, wx + 1, wy - 1, ex + 1, ey, shade(0xFFE0D8F0, night));
        }
        disc(g, wx, wy - 1, 2, shade(0xFF8A5A3A, night));
    }

    /** The meadow from y = 56: stripes, tufts, a lane, flowers, hay bales and hens. */
    static void ground(GuiGraphics g, boolean night, int t) {
        g.fillGradient(0, 56, W, H, shade(0xFF92D99C, night), shade(0xFF7CCB88, night));
        for (int y = 56; y < H; y += 10) rect(g, 0, y, W, 5, shade(0xFF86CB92, night));
        for (int i = 0; i < 50; i++) {                                                         // tufts
            int x = (i * 71 + 9) % (W - 6) + 2, y = 62 + (i * 43) % 100;
            rect(g, x, y, 1, 2, 0x44306A3A); rect(g, x + 2, y + 1, 1, 2, 0x44306A3A);
        }
        // a lane along the bottom and a few puddled stones
        oval(g, 150, 152, 150, 8, shade(0xFFD9BC88, night));
        oval(g, 150, 151, 140, 6, shade(0xFFE8CFA0, night));
        for (int i = 0; i < 8; i++) rect(g, 20 + i * 36, 150 + (i % 3) * 2, 2, 1, shade(0xFFB89A6A, night));
        // flowers by the fence, on the right margin and between the shelf and the plots
        int[] cols = {0xFFFF8FB8, 0xFFFFF3B0, 0xFFFFFFFF, 0xFFB38AFF};
        for (int i = 0; i < 26; i++) {
            int fx = i < 14 ? 66 + (i % 2) * 2 : 280 + (i % 3) * 5, fy = i < 14 ? 66 + i * 5 : 62 + (i - 14) * 3;
            int sw = (int) Math.round(Math.sin(t / 40.0 + i) * (i % 2));
            rect(g, fx + sw, fy + 2, 1, 3, shade(0xFF2E8A4A, night));
            rect(g, fx - 1 + sw, fy, 3, 1, cols[i % 4]); rect(g, fx + sw, fy - 1, 1, 3, cols[i % 4]); rect(g, fx + sw, fy, 1, 1, 0xFFF5B800);
        }
        // hay bales and a bucket at the right edge, below the plots
        for (int i = 0; i < 2; i++) {
            int hx = 262 + i * 18, hy = 140;
            rect(g, hx, hy, 16, 11, shade(0xFFE8C45A, night)); rect(g, hx, hy, 16, 2, shade(0xFFF5DC84, night));
            rect(g, hx + 4, hy, 1, 11, shade(0xFFB8963A, night)); rect(g, hx + 11, hy, 1, 11, shade(0xFFB8963A, night));
            for (int k = 0; k < 4; k++) rect(g, hx + 1 + k * 4, hy + 3 + k % 2 * 3, 3, 1, shade(0xFFFFE9A0, night));
            oval(g, hx + 8, hy + 12, 9, 2, 0x22000000);
        }
        // hens that peck
        for (int i = 0; i < 3; i++) {
            int hx = 70 + i * 36 + (int) Math.round(Math.sin(t / 60.0 + i * 2) * 6), hy = 140 + (i % 2) * 5;
            boolean peck = (t / 14 + i) % 4 == 0;
            oval(g, hx + 3, hy + 6, 5, 1, 0x22000000);
            rect(g, hx, hy, 7, 5, i == 1 ? 0xFFE8A04A : 0xFFFFFFFF);
            rect(g, hx + 5, hy - (peck ? 0 : 2), 3, 3, i == 1 ? 0xFFE8A04A : 0xFFFFFFFF);
            rect(g, hx + 8, hy - (peck ? 0 : 1), 1, 1, 0xFFF59A3A);
            rect(g, hx + 6, hy - (peck ? 0 : 3), 2, 1, 0xFFE5484D);
            rect(g, hx + 6, hy + (peck ? 0 : -1), 1, 1, 0xFF3A2A3A);
            rect(g, hx + 2, hy + 5, 1, 2, 0xFFF59A3A); rect(g, hx + 4, hy + 5, 1, 2, 0xFFF59A3A);
            rect(g, hx - 1, hy + 1, 2, 2, i == 1 ? 0xFFC8782A : 0xFFE8E8F4);
        }
        // a scarecrow at the left edge of the plots
        int sx = 289, sy = 106;
        rect(g, sx, sy, 2, 18, shade(0xFF8A5A3A, night)); rect(g, sx - 7, sy + 5, 16, 2, shade(0xFF8A5A3A, night));
        rect(g, sx - 3, sy + 7, 8, 7, shade(0xFF6A8CE8, night));
        disc(g, sx + 1, sy - 2, 4, shade(0xFFF2DCAA, night)); rect(g, sx - 4, sy - 5, 10, 2, shade(0xFFC8962A, night)); rect(g, sx - 2, sy - 9, 6, 4, shade(0xFFC8962A, night));
        rect(g, sx - 1, sy - 3, 1, 1, 0xFF3A2A3A); rect(g, sx + 2, sy - 3, 1, 1, 0xFF3A2A3A);
        rect(g, sx - 9, sy + 6, 2, 3, shade(0xFFF2DCAA, night)); rect(g, sx + 9, sy + 6, 2, 3, shade(0xFFF2DCAA, night));
    }
}
