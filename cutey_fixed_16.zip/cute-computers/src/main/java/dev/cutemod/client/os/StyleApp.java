package dev.cutemod.client.os;

import dev.cutemod.data.PetWear;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * PetStyle: the wardrobe of your pet. The pet wears up to 5 layers (head, face, neck, body, outer). Two tabs:
 * <b>Outfits</b> keeps 5 complete outfits and puts one on with a single click; <b>Items</b> shows everything you
 * have bought, and a click puts a piece on top of what the pet already wears (on its own layer, so a hat, glasses,
 * a scarf, a sweater and a cape can all be worn together) or takes it off again. Point at an outfit or at an item to
 * see the pet wearing it. Only things you own can be worn. The outfits are saved on the server as "wardrobe".
 */
public class StyleApp extends App {
    private static final int SLOTS = 5;
    private static final int ROW_X = 118, ROW_Y = 20, ROW_W = 176, ROW_H = 26, ROW_PITCH = 29;
    private static final int SAVE_X = 208, SAVE_W = 38, WEAR_X = 248, WEAR_W = 44;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;

    // the Items tab: a grid of 8 x 4 cells (scrolls by rows), the layer names are in the language files
    private static final int GX = 118, GY = 20, CELL = 21, COLS = 8, ROWS = 4, INFO_Y = 108;
    private static final int TAB_X = 118, TAB_W = 58;

    private final String[] head = new String[SLOTS], body = new String[SLOTS];
    private boolean loaded;
    private int mode, scroll;                     // 0 outfits, 1 items
    private int ticks, armed = -1, armT, msgT;
    private String msg = "";

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        if (!loaded) { loaded = true; load(); }
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.style"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.style"); }

    // ---------- save / load ----------
    private void load() {
        for (int i = 0; i < SLOTS; i++) { head[i] = ""; body[i] = ""; }
        try {
            String s = Store.read("wardrobe");
            if (s == null || s.isBlank()) return;
            String[] p = s.split(";", -1);
            for (int i = 0; i < SLOTS && i < p.length; i++) {
                String[] f = p[i].split(",", -1);
                if (f.length >= 2 && ok(f[0]) && ok(f[1])) { head[i] = f[0]; body[i] = f[1]; }
            }
        } catch (Exception ignored) {
        }
    }

    /** Item ids are short words like acc_crown: nothing else is accepted from the save. */
    private static boolean ok(String s) { return s.length() <= 64 && s.matches("[a-z0-9_+]*"); }   // '+' joins the layers of one group

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < SLOTS; i++) sb.append(i > 0 ? ";" : "").append(head[i]).append(',').append(body[i]);
        try { Store.write("wardrobe", sb.toString()); } catch (Exception ignored) { }
    }

    // ---------- logic ----------
    private boolean filled(int i) { return !head[i].isEmpty() || !body[i].isEmpty(); }

    private void say(String key, Object... args) { msg = t(key, args); msgT = 180; }

    private void saveSlot(int i) {
        String h = Progress.equipped(), b = Progress.equippedBody();
        if (h.isEmpty() && b.isEmpty()) { say("cutemod.style.msg.naked"); return; }
        if (filled(i) && armed != i) { armed = i; armT = 150; say("cutemod.style.msg.sure"); return; }   // overwriting asks twice
        armed = -1;
        head[i] = h;
        body[i] = b;
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.6F, 0.5F);
        say("cutemod.style.msg.saved", i + 1);
        save();
    }

    private void wear(int i) {
        if (!filled(i)) return;
        int missing = 0;
        Progress.undress();                                              // every layer off, then the saved ones on
        for (String id : PetWear.layers(head[i])) { if (Progress.owned(id)) Progress.equip(id); else missing++; }
        for (String id : PetWear.layers(body[i])) { if (Progress.owned(id)) Progress.equip(id); else missing++; }
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.9F, 0.5F);
        if (missing > 0) say("cutemod.style.msg.missing", missing); else say("cutemod.style.msg.worn", i + 1);
    }

    private void takeOff() {
        Progress.undress();
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.0F, 0.5F);
        say("cutemod.style.msg.off");
    }

    private void setMode(int m) {
        if (m == mode) return;
        mode = m;
        scroll = 0;
        armed = -1;
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.4F, 0.4F);
    }

    /** Everything you own, the hats first and the clothes last (the shop's order inside each layer). */
    private static List<String> ownedItems() {
        List<String> out = new ArrayList<>();
        for (PetWear.Slot sl : new PetWear.Slot[]{PetWear.Slot.HEAD, PetWear.Slot.FACE, PetWear.Slot.NECK, PetWear.Slot.OUTER, PetWear.Slot.BODY})
            for (PetWear.Item it : PetWear.ALL) if (PetWear.slotOf(it.id()) == sl && Progress.owned(it.id())) out.add(it.id());
        return out;
    }

    private static int maxScroll(int n) { return Math.max(0, (n + COLS - 1) / COLS - ROWS); }

    /** The item under the mouse in the grid, or -1. */
    private int itemAt(int x, int y, int n) {
        if (x < GX || y < GY || x >= GX + COLS * CELL || y >= GY + ROWS * CELL) return -1;
        int i = ((y - GY) / CELL + scroll) * COLS + (x - GX) / CELL;
        return i < n ? i : -1;
    }

    /** What the pet would wear if this item were clicked now: the packed head list and the packed body list. */
    private static String[] previewWith(String id) {
        String[] by = new String[PetWear.Slot.values().length];
        for (PetWear.Slot sl : PetWear.Slot.values()) by[sl.ordinal()] = Progress.worn(sl);
        int k = PetWear.slotOf(id).ordinal();
        by[k] = by[k].equals(id) ? "" : id;
        return new String[]{PetWear.pack(by, false), PetWear.pack(by, true)};
    }

    /** Puts a piece on (the piece on the same layer goes off) or takes it off. */
    private void toggle(String id) {
        String name = t("cutemod.shop.item." + id);
        if (Progress.wearing(id)) {
            Progress.unequip(id);
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.0F, 0.5F);
            say("cutemod.style.msg.takeoff", name);
        } else {
            Progress.equip(id);
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.9F, 0.5F);
            say("cutemod.style.msg.on", name);
        }
    }

    @Override
    public boolean scroll(double amount) {
        if (mode != 1) return false;
        scroll = Math.max(0, Math.min(maxScroll(ownedItems().size()), scroll + (amount < 0 ? 1 : -1)));
        return true;
    }

    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        if (armT > 0 && --armT == 0) armed = -1;
    }

    /** The names of a packed list of layers, joined with commas. */
    private static String itemName(String packed) {
        if (packed.isEmpty()) return "-";
        StringBuilder sb = new StringBuilder();
        for (String id : PetWear.layers(packed)) sb.append(sb.length() > 0 ? ", " : "").append(t("cutemod.shop.item." + id));
        return sb.toString();
    }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, 0xFFFDF0F7);
        PetShops.page(g, W, H, 0xFFB57BD6);
        PetShops.bar(g, W, 0xFFB57BD6);
        CuteFont.draw(g, f, t("cutemod.os.style"), 5, 3, 0xFFFFFFFF, false);
        for (int i = 0; i < 2; i++) {                       // the two tabs
            int tx = TAB_X + i * TAB_W;
            boolean sel = i == mode;
            rect(g, tx, 2, TAB_W - 3, 12, sel ? 0xFFFDF0F7 : in(mx, my, tx, 2, TAB_W - 3, 12) ? 0xFFCDA4E8 : 0xFF9A6FD0);
            String tl = f.plainSubstrByWidth(t("cutemod.style.tab." + i), TAB_W - 9);
            CuteFont.draw(g, f, tl, tx + (TAB_W - 3 - f.width(tl)) / 2, 4, sel ? ACCENT : 0xFFFFFFFF, false);
        }
        // which look the big preview shows: the outfit or the item under the mouse, or what the pet wears now
        String ph = Progress.equipped(), pb = Progress.equippedBody();
        boolean showing = false;
        int hover = -1, hoverItem = -1;
        List<String> items = mode == 1 ? ownedItems() : null;
        if (mode == 0) {
            for (int i = 0; i < SLOTS; i++) if (in(mx, my, ROW_X, rowY(i), ROW_W, ROW_H)) hover = i;
            if (hover >= 0 && filled(hover)) { ph = head[hover]; pb = body[hover]; showing = true; }
        } else {
            scroll = Math.min(scroll, maxScroll(items.size()));
            hoverItem = itemAt(mx, my, items.size());
            if (hoverItem >= 0) { String[] pv = previewWith(items.get(hoverItem)); ph = pv[0]; pb = pv[1]; showing = true; }
        }
        preview(g, f, ph, pb, showing);
        if (mode == 0) for (int i = 0; i < SLOTS; i++) row(g, f, i, mx, my);
        else itemGrid(g, f, items, hoverItem);
        boolean oh = in(mx, my, 6, 142, 100, 16);
        rect(g, 6, 142, 100, 16, oh ? 0xFFFFFFFF : 0xFFF6F0FA);
        rect(g, 6, 156, 100, 2, 0xFFB9A8C8);
        String off = t("cutemod.style.btn.off");
        CuteFont.draw(g, f, off, 6 + (100 - f.width(off)) / 2, 146, TEXT, false);
        if (msgT > 0) {
            int w = f.width(msg) + 12, x = (W - w) / 2;
            rect(g, x, 128, w, 13, 0xEE3A2A3A);
            CuteFont.draw(g, f, msg, x + 6, 131, 0xFFFFFFFF, false);
        }
    }

    private dev.cutemod.ComputerColor species() {
        dev.cutemod.ComputerColor c = PetApp.speciesOf(shell.color());
        return c == null ? shell.color() : c;
    }

    private static int rowY(int i) { return ROW_Y + i * ROW_PITCH; }

    private void preview(GuiGraphics g, Font f, String h, String b, boolean showing) {
        PetShops.dressing(g, 6, 20, 106, 104, showing, ticks);
        dev.cutemod.ComputerColor spc = species();
        PetBlob.Info info = PetBlob.parse(Store.read("pet_" + spc.id));
        int stage = info == null ? 2 : info.stage();
        int cx = 59, floor = 112;
        float sc = 1.15F * PetArt.scaleOf(stage);
        int bob = (int) Math.round(Math.sin(ticks / 18.0) * 1.5);
        g.pose().pushPose();
        g.pose().translate(cx, floor, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-cx, -floor, 0);
        PetArt.draw(g, spc, cx, floor - 28 + bob, 2, ticks, false, info != null && info.sick(), stage, h, b);
        g.pose().popPose();
        String l1 = f.plainSubstrByWidth(itemName(h), 100), l2 = f.plainSubstrByWidth(itemName(b), 100);
        CuteFont.draw(g, f, l1, 6 + (106 - f.width(l1)) / 2, 116, TEXT, false);
        CuteFont.draw(g, f, l2, 6 + (106 - f.width(l2)) / 2, 125, MUTED, false);
    }

    private void itemGrid(GuiGraphics g, Font f, List<String> items, int hoverItem) {
        if (items.isEmpty()) {
            String none = f.plainSubstrByWidth(t("cutemod.style.noitems"), 170);
            CuteFont.draw(g, f, none, GX + (COLS * CELL - f.width(none)) / 2, GY + 36, MUTED, false);
            return;
        }
        for (int v = 0; v < ROWS * COLS; v++) {
            int idx = scroll * COLS + v;
            if (idx >= items.size()) break;
            String id = items.get(idx);
            int cx = GX + (v % COLS) * CELL, cy = GY + (v / COLS) * CELL;
            boolean worn = Progress.wearing(id);
            rect(g, cx, cy, CELL - 1, CELL - 1, worn ? ACCENT : idx == hoverItem ? 0xFFFFFFFF : 0xFFF6F0FA);
            rect(g, cx + 1, cy + 1, CELL - 3, CELL - 3, worn ? 0xFFE4D8FF : idx == hoverItem ? 0xFFFFFFFF : 0xFFF6F0FA);
            PetArt.icon(g, id, cx + 1, cy + 1, shell.absX(), shell.absY());
        }
        int rows = (items.size() + COLS - 1) / COLS;           // a thin bar on the right shows where you are in the list
        if (rows > ROWS) {
            int th = ROWS * CELL, bh = Math.max(8, th * ROWS / rows), by = GY + (th - bh) * scroll / maxScroll(items.size());
            rect(g, GX + COLS * CELL + 1, GY, 3, th, 0xFFE9E2F2);
            rect(g, GX + COLS * CELL + 1, by, 3, bh, ACCENT);
        }
        // the line under the grid: the name of the item and its layer
        rect(g, GX, INFO_Y, COLS * CELL + 4, 16, 0xFFF6F0FA);
        String line;
        if (hoverItem >= 0) {
            String id = items.get(hoverItem);
            line = t("cutemod.shop.item." + id) + " - " + t("cutemod.style.layer." + PetWear.slotOf(id).name().toLowerCase(java.util.Locale.ROOT))
                    + (Progress.wearing(id) ? " (" + t("cutemod.style.worn") + ")" : "");
        } else {
            line = t("cutemod.style.pick");
        }
        CuteFont.draw(g, f, f.plainSubstrByWidth(line, COLS * CELL), GX + 3, INFO_Y + 4, hoverItem >= 0 ? TEXT : MUTED, false);
    }

    private void row(GuiGraphics g, Font f, int i, int mx, int my) {
        int y = rowY(i);
        boolean full = filled(i), hov = in(mx, my, ROW_X, y, ROW_W, ROW_H);
        rect(g, ROW_X, y, ROW_W, ROW_H, hov ? 0xFFFFFFFF : 0xFFF6F0FA);
        rect(g, ROW_X, y, 3, ROW_H, full ? ACCENT : 0xFFD9C7EA);
        // a tiny pet wearing the outfit
        dev.cutemod.ComputerColor spc = species();
        PetBlob.Info info = PetBlob.parse(Store.read("pet_" + spc.id));
        int stage = info == null ? 2 : info.stage();
        if (full) {
            int cx = ROW_X + 19, floor = y + 24;
            float sc = 0.3F * PetArt.scaleOf(stage);
            g.pose().pushPose();
            g.pose().translate(cx, floor, 0);
            g.pose().scale(sc, sc, 1F);
            g.pose().translate(-cx, -floor, 0);
            PetArt.draw(g, spc, cx, floor - 28, 2, ticks, false, false, stage, head[i], body[i]);
            g.pose().popPose();
        }
        CuteFont.draw(g, f, t("cutemod.style.outfit", i + 1), ROW_X + 38, y + 3, full ? TEXT : MUTED, false);
        String names = full ? f.plainSubstrByWidth(itemName(body[i].isEmpty() ? head[i] : head[i].isEmpty() ? body[i] : body[i] + PetWear.SEP + head[i]), SAVE_X - ROW_X - 42) : t("cutemod.style.empty");
        CuteFont.draw(g, f, f.plainSubstrByWidth(names, SAVE_X - ROW_X - 42), ROW_X + 38, y + 14, MUTED, false);
        btn(g, f, mx, my, SAVE_X, y + 5, SAVE_W, armed == i ? t("cutemod.style.btn.sure") : t("cutemod.style.btn.save"), armed == i ? 3 : 0);
        btn(g, f, mx, my, WEAR_X, y + 5, WEAR_W, t("cutemod.style.btn.wear"), full ? 1 : 2);
    }

    /** style 0 normal, 1 main, 2 dimmed, 3 warning. */
    private void btn(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, String label, int style) {
        boolean hov = style != 2 && in(mx, my, x, y, w, 16);
        int bg = style == 1 ? (hov ? 0xFF9A6FD0 : ACCENT) : style == 2 ? 0xFFE9E2F2 : style == 3 ? 0xFFE5486F : hov ? 0xFFE4D8FF : 0xFFFFFFFF;
        rect(g, x, y, w, 16, bg);
        rect(g, x, y + 14, w, 2, style == 1 || style == 3 ? 0x33000000 : 0xFFB9A8C8);
        String l = f.plainSubstrByWidth(label, w - 4);
        CuteFont.draw(g, f, l, x + (w - f.width(l)) / 2, y + 4, style == 1 || style == 3 ? 0xFFFFFFFF : style == 2 ? 0xFFB8A8D8 : TEXT, false);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < 2; i++) if (in(x, y, TAB_X + i * TAB_W, 2, TAB_W - 3, 12)) { setMode(i); return true; }
        if (mode == 1) {
            List<String> items = ownedItems();
            int idx = itemAt(x, y, items.size());
            if (idx >= 0) { toggle(items.get(idx)); return true; }
            if (in(x, y, 6, 142, 100, 16)) { takeOff(); return true; }
            return false;
        }
        for (int i = 0; i < SLOTS; i++) {
            int ry = rowY(i) + 5;
            if (in(x, y, SAVE_X, ry, SAVE_W, 16)) { saveSlot(i); return true; }
            if (in(x, y, WEAR_X, ry, WEAR_W, 16)) { wear(i); return true; }
        }
        if (in(x, y, 6, 142, 100, 16)) { takeOff(); return true; }
        return false;
    }
}
