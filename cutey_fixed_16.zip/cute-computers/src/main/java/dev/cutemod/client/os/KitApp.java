package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * The common part of the small apps (gift, quiz, tic-tac-toe, wheel, photo, stickers): the colored title
 * bar, the buttons, a one-line message, and "today" for the things that renew every day (real days since 1970).
 */
public abstract class KitApp extends App {
    protected static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8;

    protected int ticks, msgT;
    protected String msg = "";

    /** Color of the title bar. */
    protected abstract int accent();

    protected abstract String id();

    @Override
    public Component title() { return Component.translatable("cutemod.os." + id()); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint." + id()); }

    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
    }

    protected static int today() { return (int) (System.currentTimeMillis() / 86_400_000L); }

    protected void say(String key, Object... args) { msg = t(key, args); msgT = 180; }

    protected void header(GuiGraphics g, Font f) {
        rect(g, 0, 0, W, H, 0xFFFDF0F7);
        PetShops.page(g, W, H, accent());
        PetShops.bar(g, W, accent());
        CuteFont.draw(g, f, t("cutemod.os." + id()), 5, 3, 0xFFFFFFFF, false);
    }

    protected void center(GuiGraphics g, Font f, String s, int cx, int y, int color) {
        CuteFont.draw(g, f, s, cx - f.width(s) / 2, y, color, false);
    }

    /** The message line at the bottom of the screen (only while there is one). */
    protected void footer(GuiGraphics g, Font f) {
        if (msgT <= 0) return;
        String m = f.plainSubstrByWidth(msg, W - 20);
        int w = f.width(m) + 12, x = (W - w) / 2;
        rect(g, x, 128, w, 13, 0xEE3A2A3A);
        CuteFont.draw(g, f, m, x + 6, 131, 0xFFFFFFFF, false);
    }

    /** style 0 normal, 1 main (accent color), 2 dimmed. */
    protected void btn(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, String label, int style) {
        boolean hov = style != 2 && in(mx, my, x, y, w, 16);
        int bg = style == 1 ? (hov ? mix(accent(), 0x000000, 0.15F) : accent()) : style == 2 ? 0xFFE9E2F2 : hov ? 0xFFFFEFF8 : 0xFFFFFFFF;
        rect(g, x, y, w, 16, bg);
        rect(g, x, y + 14, w, 2, style == 1 ? 0x33000000 : 0xFFB9A8C8);
        String l = f.plainSubstrByWidth(label, w - 4);
        CuteFont.draw(g, f, l, x + (w - f.width(l)) / 2, y + 4, style == 1 ? 0xFFFFFFFF : style == 2 ? 0xFFB8A8D8 : TEXT, false);
    }

    /** The coins of a daily reward with a cap: returns how many were really paid. key = the Store key of the counter. */
    protected static int paidToday(String key) {
        String s = Store.read(key);
        try {
            String[] p = s == null ? new String[0] : s.split(",");
            return p.length == 2 && Integer.parseInt(p[0]) == today() ? Integer.parseInt(p[1]) : 0;
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    protected static void addPaid(String key, int n) { Store.write(key, today() + "," + (paidToday(key) + n)); }
}
