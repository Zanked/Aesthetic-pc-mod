package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * Season Pass: the level track of the running season (see {@link Season}). Two rows of rewards, free on top and premium
 * below; click a reward that is lit up to take it, or "Claim all". Premium is bought once per season with coins.
 */
public class SeasonApp extends App {
    private static final int COLS = 7, COL_W = 38, TRACK_X = 17, LEVEL_Y = 52, FREE_Y = 62, PREM_Y = 94, CELL_H = 28;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, GOLD = 0xFFF0A030;

    private int first = -1;       // the first level (0-based) shown in the track
    private int msgT;
    private String msg = "";

    @Override
    public Component title() { return Component.translatable("cutemod.os.season"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.season"); }

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        first = clampFirst(Season.level() - 3);
    }

    @Override
    public void tick() { if (msgT > 0) msgT--; }

    private static int clampFirst(int v) { return Math.max(0, Math.min(Season.LEVELS - COLS, v)); }

    private void say(String key, Object... args) { msg = t(key, args); msgT = 180; }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (first < 0) first = clampFirst(Season.level() - 3);
        rect(g, 0, 0, W, H, 0xFFFFF7E8);
        PetShops.page(g, W, H, GOLD);
        rect(g, 0, 0, W, 14, GOLD);
        CuteFont.draw(g, f, t("cutemod.season.name." + Season.nameIndex()), 5, 3, 0xFFFFFFFF, false);
        String left = t("cutemod.season.days", Season.daysLeft());
        CuteFont.draw(g, f, left, W - 5 - f.width(left), 3, 0xFFFFFFFF, false);

        // level and the XP bar
        int lvl = Season.level();
        CuteFont.draw(g, f, t("cutemod.season.level", lvl, Season.LEVELS), 6, 20, TEXT, false);
        String today = t("cutemod.season.today", Season.roomToday());
        CuteFont.draw(g, f, today, W - 6 - f.width(today), 20, MUTED, false);
        rect(g, 6, 32, W - 12, 8, 0xFFEBDDF7);
        int fill = (int) ((W - 12) * (Season.xpInLevel() / (float) Season.XP_PER_LEVEL));
        rect(g, 6, 32, fill, 8, GOLD);
        rect(g, 6, 38, fill, 2, 0x33000000);
        String xp = lvl >= Season.LEVELS ? t("cutemod.season.max") : Season.xpInLevel() + " / " + Season.XP_PER_LEVEL + " XP";
        CuteFont.draw(g, f, xp, (W - f.width(xp)) / 2, 41, MUTED, false);

        // the track
        boolean canL = first > 0, canR = first < Season.LEVELS - COLS;
        arrow(g, f, 2, canL, "<", mx, my);
        arrow(g, f, W - 14, canR, ">", mx, my);
        Season.Reward hover = null;
        dev.cutemod.data.SeasonGifts.Gift hoverGift = null;
        boolean hoverPrem = false;
        for (int c = 0; c < COLS; c++) {
            int level = first + c + 1, x = TRACK_X + c * COL_W;
            boolean reached = level <= lvl;
            String num = Integer.toString(level);
            CuteFont.draw(g, f, num, x + (COL_W - 2 - f.width(num)) / 2, LEVEL_Y, reached ? TEXT : MUTED, false);
            for (int row = 0; row < 2; row++) {
                boolean prem = row == 1;
                int y = prem ? PREM_Y : FREE_Y;
                boolean over = in(mx, my, x, y, COL_W - 2, CELL_H);
                cell(g, f, x, y, level, prem, over);
                if (over) { hover = Season.reward(level, prem); hoverGift = Season.gift(level, prem); hoverPrem = prem; }
            }
        }
        CuteFont.draw(g, f, t("cutemod.season.free"), 6, 126, 0xFF6A8F5A, false);
        CuteFont.draw(g, f, t("cutemod.season.premium"), 6 + f.width(t("cutemod.season.free")) + 10, 126, 0xFFC98A10, false);

        // one line of text: the message, or what the pointed reward is
        String line = msgT > 0 ? msg : hover != null ? Season.rewardName(hover) + (hoverGift != null ? " + " + Season.giftName(hoverGift) : "") + (hoverPrem && !Season.premium() ? "  (" + t("cutemod.season.locked") + ")" : "") : "";
        if (!line.isEmpty()) {
            String s = f.plainSubstrByWidth(line, W - 100);
            CuteFont.draw(g, f, s, W - 6 - f.width(s), 126, msgT > 0 ? 0xFF3A2A3A : MUTED, false);
        }

        // buttons
        int waiting = Season.waiting();
        btn(g, f, mx, my, 6, 142, 112, t("cutemod.season.claimall", waiting), waiting > 0 ? 1 : 2);
        String pl = Season.premium() ? t("cutemod.season.active") : t("cutemod.season.buy", Season.PREMIUM_PRICE);
        btn(g, f, mx, my, 124, 142, 170, pl, Season.premium() ? 2 : 0);
    }

    private void arrow(GuiGraphics g, Font f, int x, boolean on, String s, int mx, int my) {
        boolean hov = on && in(mx, my, x, 62, 12, 60);
        rect(g, x, 62, 12, 60, !on ? 0xFFF3ECF8 : hov ? 0xFFFFFFFF : 0xFFEFE4F7);
        CuteFont.draw(g, f, s, x + 4, 88, on ? TEXT : 0xFFC8BCD8, false);
    }

    private void cell(GuiGraphics g, Font f, int x, int y, int level, boolean prem, boolean over) {
        Season.Reward r = Season.reward(level, prem);
        boolean reached = level <= Season.level();
        boolean locked = prem && !Season.premium();
        boolean done = Season.claimed(level, prem);
        boolean ready = Season.canClaim(level, prem);
        int bg = ready ? (over ? 0xFFFFF3B0 : 0xFFFFE680) : prem ? 0xFFFBEFD0 : 0xFFF1EAF8;
        rect(g, x, y, COL_W - 2, CELL_H, bg);
        if (ready) rect(g, x, y, COL_W - 2, 2, GOLD);
        // the picture
        int cx = x + (COL_W - 2) / 2, cy = y + 10;
        switch (r.kind()) {
            case 0 -> { disc(g, cx, cy, 6, 0xFFE0A020); disc(g, cx, cy, 4, 0xFFFFD866); }
            case 1 -> { rect(g, cx - 6, cy - 5, 12, 10, 0xFFD08A5A); rect(g, cx - 4, cy - 3, 8, 3, 0xFFF3C79A); }
            default -> { disc(g, cx, cy, 7, 0xFFB57BD6); rect(g, cx - 1, cy - 4, 2, 8, 0xFFFFFFFF); rect(g, cx - 4, cy - 1, 8, 2, 0xFFFFFFFF); }
        }
        String label = r.kind() == 0 ? "+" + r.n() : r.kind() == 1 ? "x" + r.n() : "*";
        CuteFont.draw(g, f, label, cx - f.width(label) / 2, y + 18, TEXT, false);
        if (Season.gift(level, prem) != null) {                              // a small cube: an item comes to the game inventory too
            rect(g, x + 2, y + CELL_H - 8, 6, 6, 0xFF5BBF6A); rect(g, x + 2, y + CELL_H - 8, 6, 2, 0xFF8BDF8A); rect(g, x + 5, y + CELL_H - 5, 3, 3, 0xFF3F8F4A);
        }
        if (done || !reached) rect(g, x, y, COL_W - 2, CELL_H, 0x66FFF7E8);   // dimmed: taken, or not reached yet
        if (done) { rect(g, x + COL_W - 12, y + 2, 8, 8, 0xFF5BBF6A); rect(g, x + COL_W - 10, y + 5, 2, 2, 0xFFFFFFFF); rect(g, x + COL_W - 8, y + 4, 2, 2, 0xFFFFFFFF); }
        else if (locked) rect(g, x + COL_W - 11, y + 3, 7, 6, 0xFF8A7AA8);
    }

    /** style 0 normal, 1 main, 2 dimmed. */
    private void btn(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, String label, int style) {
        boolean hov = style != 2 && in(mx, my, x, y, w, 16);
        int bg = style == 1 ? (hov ? 0xFFE08A10 : GOLD) : style == 2 ? 0xFFE9E2F2 : hov ? 0xFFFFEFC0 : 0xFFFFFFFF;
        rect(g, x, y, w, 16, bg);
        rect(g, x, y + 14, w, 2, style == 1 ? 0x33000000 : 0xFFB9A8C8);
        String l = f.plainSubstrByWidth(label, w - 4);
        CuteFont.draw(g, f, l, x + (w - f.width(l)) / 2, y + 4, style == 1 ? 0xFFFFFFFF : style == 2 ? 0xFFB8A8D8 : TEXT, false);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (in(x, y, 2, 62, 12, 60)) { first = clampFirst(first - COLS); return true; }
        if (in(x, y, W - 14, 62, 12, 60)) { first = clampFirst(first + COLS); return true; }
        for (int c = 0; c < COLS; c++) {
            int level = first + c + 1, cx = TRACK_X + c * COL_W;
            for (int row = 0; row < 2; row++) {
                boolean prem = row == 1;
                if (!in(x, y, cx, prem ? PREM_Y : FREE_Y, COL_W - 2, CELL_H)) continue;
                if (Season.claim(level, prem)) {
                    Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.8F, 0.5F);
                } else if (prem && !Season.premium()) {
                    say("cutemod.season.msg.needpremium");
                } else if (level > Season.level()) {
                    say("cutemod.season.msg.notyet", level);
                }
                return true;
            }
        }
        if (in(x, y, 6, 142, 112, 16)) {
            int n = Season.claimAll();
            if (n > 0) { Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.5F); say("cutemod.season.msg.claimed", n); }
            else say("cutemod.season.msg.nothing");
            return true;
        }
        if (in(x, y, 124, 142, 170, 16) && !Season.premium()) {
            if (Season.buyPremium()) { Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.6F); say("cutemod.season.msg.bought"); }
            else say("cutemod.season.msg.nocoins", Season.PREMIUM_PRICE);
            return true;
        }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        first = clampFirst(first + (amount > 0 ? -1 : 1));
        return true;
    }
}
