package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/**
 * How a Tamagotchi looks. Pure drawing, no state: the pet window (PetApp) and the pet show use the same code,
 * so a pet looks the same everywhere. Everything the picture depends on is passed in.
 * <p>
 * The pet is about 60 x 70 GUI pixels around its centre (cx, cy); the head top is cy - 22 (hats sit there).
 */
public final class PetArt {
    private PetArt() {}

    private static final int DARK = 0xFF3A2A3A;

    /** 0 baby (first 20 minutes with the pet), 1 teen (up to an hour), 2 grown-up. */
    public static int stageOf(long ageSec) { return ageSec < 1200 ? 0 : ageSec < 3600 ? 1 : 2; }

    /** Size of the drawing for a growth stage: babies are small. */
    public static float scaleOf(int stage) { return stage == 0 ? 0.72F : stage == 1 ? 0.86F : 1F; }

    /** 0 foodie, 1 playful, 2 sleepy, 3 cuddly, 4 not decided yet (needs about 12 caring actions). */
    public static int traitOf(int feed, int play, int sleep, int pet) {
        if (feed + play + sleep + pet < 12) return 4;
        int best = 0, v = feed;
        if (play > v) { best = 1; v = play; }
        if (sleep > v) { best = 2; v = sleep; }
        if (pet > v) { best = 3; }
        return best;
    }

    private static void tri(GuiGraphics g, int x, int y, int w, int h, int argb) {
        for (int r = 0; r < h; r++) {
            int ww = Math.max(1, w * (r + 1) / h);
            rect(g, x + (w - ww) / 2, y + r, ww, 1, argb);
        }
    }

    public static void draw(GuiGraphics g, ComputerColor color, int cx, int cy, int mood, int ticks,
                            boolean sleeping, boolean sick, int stage, String head, String body) {
        int e1 = cx - 11, e2 = cx + 7, ey = cy - 6, ew = 4, eh = 5, mY = cy + 8;
        int eyeCol = DARK, mouthCol = DARK;
        int top = cy - 22; // top of the head (for hats)
        boolean mouth = true, pupil = false;

        switch (color) {
            case PINK -> {
                int c = 0xFFF58FB8;
                tri(g, cx - 23, cy - 33, 13, 13, c);
                tri(g, cx + 10, cy - 33, 13, 13, c);
                tri(g, cx - 20, cy - 29, 7, 8, 0xFFFFC0D6);
                tri(g, cx + 13, cy - 29, 7, 8, 0xFFFFC0D6);
                disc(g, cx, cy, 22, c);
                disc(g, cx, cy + 9, 12, 0xFFFFD3E3);
                rect(g, cx - 1, cy + 2, 3, 2, 0xFFE5486F);
                rect(g, cx - 31, cy + 3, 10, 1, DARK);
                rect(g, cx - 30, cy + 7, 9, 1, DARK);
                rect(g, cx + 21, cy + 3, 10, 1, DARK);
                rect(g, cx + 21, cy + 7, 9, 1, DARK);
            }
            case GREEN -> {
                int c = 0xFF5BBF6A, d = 0xFF1B3A1B;
                rect(g, cx - 19, cy - 22, 38, 44, c);
                rect(g, cx - 17, cy - 20, 8, 8, 0xFF4AA85A);
                rect(g, cx + 8, cy - 8, 9, 9, 0xFF4AA85A);
                rect(g, cx - 14, cy + 10, 10, 9, 0xFF4AA85A);
                e1 = cx - 13; e2 = cx + 5; ey = cy - 14; ew = 8; eh = 8; eyeCol = d;
                mouth = false;
                rect(g, cx - 4, cy - 2, 8, 6, d);
                rect(g, cx - 8, cy + 4, 16, 10, d);
                rect(g, cx - 4, cy + 10, 8, 4, c);
            }
            case WHITE -> {
                disc(g, cx - 17, cy - 19, 7, 0xFF2A2A2F);
                disc(g, cx + 17, cy - 19, 7, 0xFF2A2A2F);
                disc(g, cx, cy, 22, 0xFFFFFFFF);
                disc(g, cx - 20, cy + 14, 6, 0xFF2A2A2F);
                disc(g, cx + 20, cy + 14, 6, 0xFF2A2A2F);
                disc(g, e1 + 2, ey + 2, 6, 0xFF2A2A2F);
                disc(g, e2 + 2, ey + 2, 6, 0xFF2A2A2F);
                rect(g, cx - 3, cy + 2, 6, 3, 0xFF2A2A2F);
                eyeCol = 0xFFFFFFFF; pupil = true; mY = cy + 10;
            }
            case BLUE -> {
                rect(g, cx - 27, cy - 2, 5, 16, 0xFF263B73);
                rect(g, cx + 22, cy - 2, 5, 16, 0xFF263B73);
                disc(g, cx, cy, 22, 0xFF2F4A8A);
                disc(g, cx, cy + 7, 15, 0xFFFFFFFF);
                rect(g, cx - 14, cy + 21, 10, 4, 0xFFF5A623);
                rect(g, cx + 4, cy + 21, 10, 4, 0xFFF5A623);
                rect(g, cx - 3, cy - 1, 6, 4, 0xFFF5A623);
                ey = cy - 12; eyeCol = 0xFFFFFFFF; pupil = true; mouth = false;
            }
            case ORANGE -> {
                int c = 0xFFF08A24;
                disc(g, cx + 25, cy + 12, 8, c);
                disc(g, cx + 29, cy + 17, 4, 0xFFFFFFFF);
                tri(g, cx - 23, cy - 33, 13, 14, c);
                tri(g, cx + 10, cy - 33, 13, 14, c);
                tri(g, cx - 20, cy - 33, 7, 6, DARK);
                tri(g, cx + 13, cy - 33, 7, 6, DARK);
                disc(g, cx, cy, 22, c);
                disc(g, cx - 12, cy + 9, 9, 0xFFFFF3E0);
                disc(g, cx + 12, cy + 9, 9, 0xFFFFF3E0);
                rect(g, cx - 2, cy + 3, 4, 3, DARK);
                mY = cy + 10;
            }
            case PURPLE -> {
                for (int i = 0; i < 6; i++) { // floating particles
                    if ((ticks / 7 + i) % 2 != 0) continue;
                    rect(g, cx + ((i * 37 + ticks / 5 * 7) % 64) - 32, cy - 30 + ((i * 53 + ticks / 4 * 3) % 64), 2, 2, 0xFFB040FF);
                }
                disc(g, cx, cy, 22, 0xFF1A1426);
                e1 = cx - 13; e2 = cx + 5; ey = cy - 6; ew = 8; eh = 3; eyeCol = 0xFFE040FF;
                mouthCol = 0xFFB040FF;
            }
            case YELLOW -> {
                int flap = (ticks / 4) % 2;
                disc(g, cx - 14, cy - 26 + flap * 2, 8, 0xFFDDF4FF);
                disc(g, cx + 14, cy - 26 + flap * 2, 8, 0xFFDDF4FF);
                rect(g, cx - 8, cy - 34, 1, 11, DARK);
                rect(g, cx + 7, cy - 34, 1, 11, DARK);
                disc(g, cx - 8, cy - 34, 2, DARK);
                disc(g, cx + 7, cy - 34, 2, DARK);
                disc(g, cx, cy, 22, 0xFFF5C518);
                for (int dy : new int[]{12, 13, 14, 18, 19, 20}) {
                    int w = (int) Math.sqrt(22 * 22 - dy * dy);
                    rect(g, cx - w, cy + dy, w * 2, 1, 0xFF2A2A2A);
                }
                mY = cy + 6;
            }
            default -> { // RED: ladybug
                disc(g, cx, cy + 4, 21, 0xFFE5484D);
                rect(g, cx, cy - 6, 1, 30, DARK);
                disc(g, cx - 10, cy + 8, 3, DARK);
                disc(g, cx + 10, cy + 8, 3, DARK);
                disc(g, cx - 6, cy + 17, 3, DARK);
                disc(g, cx + 6, cy + 17, 3, DARK);
                disc(g, cx, cy - 16, 11, 0xFF2A2A2F);
                rect(g, cx - 7, cy - 32, 1, 8, DARK);
                rect(g, cx + 6, cy - 32, 1, 8, DARK);
                e1 = cx - 8; e2 = cx + 4; ey = cy - 20; eyeCol = 0xFFFFFFFF; pupil = true;
                mY = cy - 10; mouthCol = 0xFFFFFFFF; top = cy - 27;
            }
        }

        // eyes
        boolean closed = sleeping || (ticks % 200) < 8;
        if (closed) {
            rect(g, e1, ey + eh / 2, ew, 1, eyeCol == DARK ? DARK : (eyeCol == 0xFFFFFFFF ? 0xFFFFFFFF : eyeCol));
            rect(g, e2, ey + eh / 2, ew, 1, eyeCol == DARK ? DARK : (eyeCol == 0xFFFFFFFF ? 0xFFFFFFFF : eyeCol));
        } else {
            rect(g, e1, ey, ew, eh, eyeCol);
            rect(g, e2, ey, ew, eh, eyeCol);
            if (pupil) {
                rect(g, e1 + 1, ey + 2, 2, 3, DARK);
                rect(g, e2 + 1, ey + 2, 2, 3, DARK);
            } else {
                rect(g, e1 + 1, ey + 1, 1, 1, 0xFFFFFFFF);
                rect(g, e2 + 1, ey + 1, 1, 1, 0xFFFFFFFF);
            }
            if (mood == 0) { // a tear
                rect(g, e2 + ew - 1, ey + eh + (ticks / 8) % 6, 1, 2, 0xFF6AB8FF);
            }
        }

        accessory(g, ticks, head, body, cx, cy, top, e1, e2, ey, ew, eh);
        if (stage == 0 && !sleeping) { // baby cheeks
            rect(g, e1 - 3, ey + eh + 2, 3, 2, 0x99FF8FB0);
            rect(g, e2 + ew, ey + eh + 2, 3, 2, 0x99FF8FB0);
        }
        if (stage == 2 && (ticks / 25) % 3 != 0) { // a grown-up sparkles
            rect(g, cx + 27, cy - 34, 1, 5, 0xFFFFE680);
            rect(g, cx + 25, cy - 32, 5, 1, 0xFFFFE680);
        }

        if (sick && !sleeping) { // thermometer and a sweat drop
            rect(g, cx + 2, mY + 2, 12, 2, 0xFFFFFFFF);
            rect(g, cx + 13, mY + 1, 3, 4, 0xFFE5484D);
            rect(g, cx + 22, cy - 14 + (ticks / 10) % 5, 2, 3, 0xFF6AB8FF);
        }

        // mouth
        if (mouth) {
            int mx0 = cx - 1;
            if (sleeping) {
                rect(g, mx0 - 1, mY, 3, 1, mouthCol);
            } else if (mood == 2) {
                rect(g, mx0 - 4, mY, 9, 1, mouthCol);
                rect(g, mx0 - 5, mY - 1, 1, 1, mouthCol);
                rect(g, mx0 + 5, mY - 1, 1, 1, mouthCol);
            } else if (mood == 1) {
                rect(g, mx0 - 3, mY, 7, 1, mouthCol);
            } else {
                rect(g, mx0 - 3, mY, 7, 1, mouthCol);
                rect(g, mx0 - 4, mY + 1, 1, 1, mouthCol);
                rect(g, mx0 + 4, mY + 1, 1, 1, mouthCol);
            }
        }
    }

    /** Things bought in the shop (hats, glasses, scarf, cape...). */
    private static void accessory(GuiGraphics g, int ticks, String head, String body, int cx, int cy, int top, int e1, int e2, int ey, int ew, int eh) {
        accessoryOne(body, g, ticks, cx, cy, top, e1, e2, ey, ew, eh);   // neck / body first,
        accessoryOne(head, g, ticks, cx, cy, top, e1, e2, ey, ew, eh);   // then the head on top of it
    }

    private static void accessoryOne(String id, GuiGraphics g, int ticks, int cx, int cy, int top, int e1, int e2, int ey, int ew, int eh) {
        switch (id) {
            case "acc_ushanka" -> {      // a fur hat with ear flaps
                int fur = 0xFF8A6A4A, furL = 0xFFB08A62;
                rect(g, cx - 14, top - 8, 28, 9, fur);
                rect(g, cx - 12, top - 10, 24, 2, furL);
                rect(g, cx - 17, top - 2, 6, 14, fur);
                rect(g, cx + 11, top - 2, 6, 14, fur);
                rect(g, cx - 15, top - 1, 30, 3, furL);
                rect(g, cx - 2, top - 7, 4, 4, 0xFFE5484D);
            }
            case "acc_headphones" -> {   // a band over the head and two pink ear cups
                for (int a = 180; a <= 360; a += 6) {
                    double rad = Math.toRadians(a);
                    int px = cx + (int) Math.round(25 * Math.cos(rad)), py = cy + (int) Math.round(25 * Math.sin(rad));
                    rect(g, px - 1, py - 1, 3, 3, 0xFF3A3A4A);
                }
                rect(g, cx - 29, cy - 7, 7, 14, 0xFF3A3A4A);
                rect(g, cx - 28, cy - 6, 5, 12, 0xFFFF5C93);
                rect(g, cx + 22, cy - 7, 7, 14, 0xFF3A3A4A);
                rect(g, cx + 23, cy - 6, 5, 12, 0xFFFF5C93);
            }
            case "acc_horns" -> {        // little red devil horns
                tri(g, cx - 15, top - 9, 8, 12, 0xFFE5484D);
                tri(g, cx + 7, top - 9, 8, 12, 0xFFE5484D);
                rect(g, cx - 12, top - 5, 1, 4, 0xFFFF9A9A);
                rect(g, cx + 10, top - 5, 1, 4, 0xFFFF9A9A);
            }
            case "acc_witch" -> {        // a pointy black hat with a purple band and a bent tip
                int k = 0xFF2A1A3A;
                tri(g, cx - 8, top - 22, 16, 21, k);
                rect(g, cx + 3, top - 25, 6, 3, k);
                rect(g, cx - 17, top - 2, 34, 3, k);
                rect(g, cx - 8, top - 9, 16, 3, 0xFFB57BD6);
                rect(g, cx + 3, top - 9, 4, 3, 0xFFFFD84A);
            }
            case "acc_scarf" -> {        // a striped red scarf with a tail
                rect(g, cx - 18, cy + 12, 36, 6, 0xFFE5484D);
                for (int i = 0; i < 6; i++) rect(g, cx - 16 + i * 6, cy + 12, 2, 6, 0xFFFFFFFF);
                rect(g, cx + 6, cy + 18, 8, 13, 0xFFE5484D);
                rect(g, cx + 6, cy + 22, 8, 2, 0xFFFFFFFF);
                rect(g, cx + 6, cy + 28, 8, 3, 0xFFFFFFFF);
            }
            case "acc_cape" -> {         // a red cape: drapes on both sides, a collar and a golden clasp
                int c = 0xFFD93A4A, d = 0xFFA82A38;
                rect(g, cx - 28, cy - 2, 8, 30, c);
                rect(g, cx + 20, cy - 2, 8, 30, c);
                rect(g, cx - 28, cy + 24, 8, 4, d);
                rect(g, cx + 20, cy + 24, 8, 4, d);
                rect(g, cx - 18, cy + 12, 36, 4, d);
                rect(g, cx - 2, cy + 13, 4, 4, 0xFFFFD84A);
            }
            case "acc_glasses" -> {
                int k = 0xFF111111;
                rect(g, e1 - 2, ey - 1, ew + 4, eh + 2, k);
                rect(g, e2 - 2, ey - 1, ew + 4, eh + 2, k);
                rect(g, e1 + ew + 2, ey, Math.max(1, e2 - e1 - ew - 4), 1, k);
                rect(g, e1 - 1, ey, 2, 1, 0x88FFFFFF);
                rect(g, e2 - 1, ey, 2, 1, 0x88FFFFFF);
            }
            case "acc_bow" -> {
                disc(g, cx + 11, top + 6, 3, 0xFFFF5C93);
                disc(g, cx + 21, top + 6, 3, 0xFFFF5C93);
                rect(g, cx + 15, top + 4, 3, 5, 0xFFD93A72);
            }
            case "acc_hat" -> {
                int k = 0xFF1A1A22;
                rect(g, cx - 9, top - 13, 18, 13, k);
                rect(g, cx - 14, top - 1, 28, 3, k);
                rect(g, cx - 9, top - 5, 18, 2, 0xFFE5484D);
            }
            case "acc_crown" -> {
                int gold = 0xFFFFD84A;
                rect(g, cx - 10, top - 5, 20, 5, gold);
                tri(g, cx - 10, top - 11, 6, 6, gold);
                tri(g, cx - 3, top - 14, 7, 9, gold);
                tri(g, cx + 4, top - 11, 6, 6, gold);
                rect(g, cx - 1, top - 3, 3, 2, 0xFFE5484D);
                rect(g, cx - 8, top - 3, 2, 2, 0xFF2F9BFF);
                rect(g, cx + 6, top - 3, 2, 2, 0xFF2F9BFF);
            }
            case "acc_champion" -> { // the laurels of a show champion
                int leaf = 0xFF4FB86A, leaf2 = 0xFF8FE08A, gold = 0xFFFFD84A;
                for (int i = 0; i < 5; i++) {
                    int lx = cx - 14 + i * 3, ly = top - 1 - (i < 3 ? i * 3 : 6 + (i - 2));
                    rect(g, lx, ly, 3, 3, i % 2 == 0 ? leaf : leaf2);
                    rect(g, 2 * cx - lx - 3, ly, 3, 3, i % 2 == 0 ? leaf : leaf2);
                }
                rect(g, cx - 1, top - 14, 3, 5, gold);
                rect(g, cx - 2, top - 12, 5, 1, gold);
            }
            case "acc_ghost" -> { // a tiny ghost friend floats next to the head
                int gy = top - 6 + (int) Math.round(Math.sin(ticks / 12.0) * 2), gx = cx + 22;
                disc(g, gx, gy, 6, 0xFFF4F0FF);
                rect(g, gx - 6, gy, 13, 8, 0xFFF4F0FF);
                for (int i = 0; i < 3; i++) rect(g, gx - 6 + i * 5, gy + 8, 3, 2 + (i + ticks / 10) % 2, 0xFFF4F0FF);
                rect(g, gx - 3, gy - 2, 2, 3, 0xFF3A2A3A);
                rect(g, gx + 2, gy - 2, 2, 3, 0xFF3A2A3A);
                rect(g, gx - 1, gy + 3, 3, 1, 0xFFE06A8A);
            }
            case "acc_party" -> {
                tri(g, cx - 8, top - 18, 16, 18, 0xFFB57BD6);
                rect(g, cx - 5, top - 9, 10, 2, 0xFFFFFFFF);
                disc(g, cx, top - 18, 3, 0xFFFFD84A);
            }
            case "acc_halo" -> {
                rect(g, cx - 12, top - 14, 24, 10, 0x33FFF3B0);
                rect(g, cx - 9, top - 12, 18, 2, 0xFFFFE680);
                rect(g, cx - 9, top - 6, 18, 2, 0xFFFFE680);
                rect(g, cx - 11, top - 10, 2, 4, 0xFFFFE680);
                rect(g, cx + 9, top - 10, 2, 4, 0xFFFFE680);
            }
            case "acc_flower" -> {
                int fx = cx - 15, fy = top + 6;
                disc(g, fx - 4, fy, 2, 0xFFFF8AC0);
                disc(g, fx + 4, fy, 2, 0xFFFF8AC0);
                disc(g, fx, fy - 4, 2, 0xFFFF8AC0);
                disc(g, fx, fy + 4, 2, 0xFFFF8AC0);
                disc(g, fx, fy, 3, 0xFFFFD84A);
            }
            case "acc_cap" -> {
                rect(g, cx - 9, top - 7, 18, 7, 0xFF2F9BFF);
                rect(g, cx - 9, top - 1, 24, 2, 0xFF2F7ACF);
                rect(g, cx - 1, top - 9, 2, 2, 0xFF2F7ACF);
            }
            default -> { }
        }
    }
}
