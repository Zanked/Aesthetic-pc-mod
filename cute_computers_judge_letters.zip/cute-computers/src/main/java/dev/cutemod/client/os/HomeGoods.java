package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/**
 * The "Home" tab of CuteMarket: wallpapers, pet accessories, songs and treats, bought with coins and used
 * at once (no cart, no courier). They used to live in the Shop app, which is gone.
 */
final class HomeGoods {
    private record Item(String id, int price) {}

    private static final Item[] ITEMS = {
            new Item("wall6", 40), new Item("wall7", 40), new Item("wall8", 60),
            new Item("wall9", 50), new Item("wall10", 50), new Item("wall11", 70),
            new Item("wall13", 60), new Item("wall14", 70), new Item("wall15", 70),
            new Item("wall16", 70), new Item("wall17", 60), new Item("wall18", 60),
            new Item("wall19", 50), new Item("wall20", 50), new Item("wall21", 60),
            new Item(Theme.AERO_ID, Theme.AERO_PRICE),      // the Frutiger Aero look of the whole desktop
            new Item("acc_flower", 35), new Item("acc_glasses", 30), new Item("acc_bow", 30),
            new Item("acc_cap", 40), new Item("acc_party", 40), new Item("acc_hat", 50),
            new Item("acc_halo", 80),
            new Item("acc_ushanka", 45), new Item("acc_headphones", 50), new Item("acc_horns", 40),
            new Item("acc_witch", 55), new Item("acc_scarf", 35), new Item("acc_cape", 65),
            new Item("acc_crown", 0), // a reward for finishing the story, not for sale
            new Item("acc_ghost", 0), // a reward for part 2 of the story, not for sale
            new Item("acc_champion", 0), // a reward of the talent show (10 gold cups), not for sale
            new Item("track4", 40), new Item("track5", 60), new Item("track6", 50), new Item("track7", 70),
            new Item("treat_cookie", 5), new Item("treat_fish", 8), new Item("treat_honey", 12),
            new Item("treat_milk", 10), new Item("treat_cake", 20), new Item("treat_medicine", 25),
    };
    private static final String[] TAB_KINDS = {"", "wall", "acc", "track", "treat"};
    private static final int CHIP_X = 4, CHIP_Y = 21, CHIP_W = 58, CHIP_H = 12;
    private static final int TOP = 36, ROW = 24, VISIBLE = 5, BTN_W = 78;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;

    private int tab, scroll;

    private static String kind(String id) {
        return id.startsWith("treat") ? "treat" : id.startsWith("wall") ? "wall" : id.startsWith("theme") ? "theme" : id.startsWith("acc") ? "acc" : "track";
    }

    /** The items of the selected chip. */
    private List<Item> view() {
        List<Item> out = new ArrayList<>();
        for (Item it : ITEMS) {
            String k = kind(it.id());
            if (tab == 0 || k.equals(TAB_KINDS[tab]) || (tab == 1 && k.equals("theme"))) out.add(it);   // tab 1 = Style: wallpapers and themes
        }
        return out;
    }

    private int maxScroll() { return Math.max(0, view().size() - VISIBLE); }

    /** Text of the button for this item. */
    private static String action(Item it) {
        boolean own = Progress.owned(it.id());
        switch (kind(it.id())) {
            case "wall" -> {
                if (!own) return "buy";
                return Wallpaper.get() == Integer.parseInt(it.id().substring(4)) ? "using" : "set";
            }
            case "acc" -> {
                if (!own) return it.price() == 0 ? (it.id().equals("acc_champion") ? "show" : "story") : "buy";
                return Progress.wearing(it.id()) ? "take_off" : "wear";
            }
            case "theme" -> {
                if (!own) return "buy";
                return Theme.aero() ? "theme_off" : "theme_on";
            }
            case "treat" -> { return "buy"; } // consumable: you can buy as many as you like
            default -> { return own ? "have" : "buy"; }
        }
    }

    void render(GuiGraphics g, int mx, int my, int bodyColor) {
        Font f = App.font();
        for (int i = 0; i < 5; i++) {
            int cx = CHIP_X + i * CHIP_W;
            boolean sel = i == tab;
            App.rect(g, cx, CHIP_Y, CHIP_W - 1, CHIP_H, sel ? ACCENT : (App.in(mx, my, cx, CHIP_Y, CHIP_W - 1, CHIP_H) ? 0xFFEAD6F5 : 0xFFF1E4F7));
            String s = App.t("cutemod.shop.tab." + i);
            g.drawString(f, s, cx + (CHIP_W - 1 - f.width(s)) / 2, CHIP_Y + 2, sel ? 0xFFFFFFFF : TEXT, false);
        }
        List<Item> items = view();
        scroll = Math.min(scroll, maxScroll());
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= items.size()) break;
            Item it = items.get(idx);
            int y = TOP + v * ROW;
            App.rect(g, 0, y, App.W, ROW - 1, v % 2 == 0 ? 0xFFFFFFFF : 0xFFFFEFF7);
            icon(g, it.id(), 6, y + 2, bodyColor);
            String name = App.t("cutemod.shop.item." + it.id());
            g.drawString(f, name, 32, y + 4, TEXT, false);
            boolean treat = kind(it.id()).equals("treat");
            if (treat && Progress.stock(it.id()) > 0) g.drawString(f, "x" + Progress.stock(it.id()), 36 + f.width(name), y + 4, 0xFFB98A10, false);
            g.drawString(f, treat ? App.t("cutemod.shop.eff." + it.id()) : App.t("cutemod.shop.kind." + kind(it.id())), 32, y + 14, MUTED, false);
            if (it.price() > 0 && (treat || !Progress.owned(it.id()))) {
                String p = Integer.toString(it.price());
                int px = App.W - BTN_W - 14 - f.width(p);
                Progress.drawCoin(g, px - 10, y + 8);
                g.drawString(f, p, px, y + 8, Progress.coins() >= it.price() ? TEXT : 0xFFE5484D, false);
            }
            String a = action(it);
            boolean can = !(a.equals("using") || a.equals("have") || a.equals("story") || a.equals("show") || (a.equals("buy") && Progress.coins() < it.price()));
            boolean hover = can && App.in(mx, my, App.W - BTN_W - 6, y + 3, BTN_W, 17);
            App.rect(g, App.W - BTN_W - 6, y + 3, BTN_W, 17, !can ? 0xFFD8CCE2 : hover ? 0xFF8A6AC6 : ACCENT);
            String label = App.t("cutemod.shop.btn." + a);
            g.drawString(f, label, App.W - BTN_W - 6 + (BTN_W - f.width(label)) / 2, y + 8, can ? 0xFFFFFFFF : MUTED, false);
        }
        if (maxScroll() > 0) { // scroll bar
            App.rect(g, App.W - 3, TOP, 3, VISIBLE * ROW, 0xFFE9DDF2);
            int th = Math.max(8, VISIBLE * ROW * VISIBLE / items.size());
            App.rect(g, App.W - 3, TOP + (VISIBLE * ROW - th) * scroll / maxScroll(), 3, th, ACCENT);
        }
    }

    /** A little picture (20 x 20) of the item. */
    private void icon(GuiGraphics g, String id, int x, int y, int bodyColor) {
        App.rect(g, x - 1, y - 1, 22, 22, 0xFF3A2A4A);
        switch (kind(id)) {
            case "wall" -> Wallpaper.draw(g, x, y, 20, 20, bodyColor, Integer.parseInt(id.substring(4)));
            case "treat" -> {
                App.rect(g, x, y, 20, 20, 0xFFFFF0C0);
                PetApp.drawTreat(g, id, x + 5, y + 5);
            }
            case "theme" -> {        // Frutiger Aero: sky, a glass window bar, bubbles and a green hill
                g.fillGradient(x, y, x + 20, y + 20, 0xFF6EC8FF, 0xFFE8F8FF);
                App.rect(g, x + 2, y + 3, 16, 4, 0xFF2F8FE0);
                App.rect(g, x + 2, y + 3, 16, 1, 0xFFFFFFFF);
                App.rect(g, x, y + 16, 20, 4, 0xFF6AC85A);
                App.disc(g, x + 13, y + 12, 3, 0x99FFFFFF);
                App.disc(g, x + 6, y + 13, 2, 0x99FFFFFF);
            }
            case "track" -> {
                App.rect(g, x, y, 20, 20, 0xFF6A4A9A);
                App.disc(g, x + 7, y + 14, 3, 0xFFFFFFFF);
                App.rect(g, x + 9, y + 4, 2, 11, 0xFFFFFFFF);
                App.rect(g, x + 9, y + 4, 6, 2, 0xFFFFFFFF);
            }
            default -> {
                App.rect(g, x, y, 20, 20, 0xFFFFF0C0);
                switch (id) {
                    case "acc_glasses" -> {
                        App.rect(g, x + 2, y + 7, 7, 5, 0xFF111111);
                        App.rect(g, x + 11, y + 7, 7, 5, 0xFF111111);
                        App.rect(g, x + 9, y + 8, 2, 1, 0xFF111111);
                    }
                    case "acc_bow" -> {
                        App.disc(g, x + 5, y + 10, 3, 0xFFFF5C93);
                        App.disc(g, x + 15, y + 10, 3, 0xFFFF5C93);
                        App.rect(g, x + 8, y + 8, 4, 5, 0xFFD93A72);
                    }
                    case "acc_hat" -> {
                        App.rect(g, x + 5, y + 3, 10, 10, 0xFF1A1A22);
                        App.rect(g, x + 2, y + 13, 16, 3, 0xFF1A1A22);
                        App.rect(g, x + 5, y + 10, 10, 2, 0xFFE5484D);
                    }
                    case "acc_party" -> {
                        for (int r = 0; r < 14; r++) App.rect(g, x + 10 - (r / 2 + 1), y + 4 + r, (r / 2 + 1) * 2, 1, 0xFFB57BD6);
                        App.rect(g, x + 7, y + 11, 6, 1, 0xFFFFFFFF);
                        App.disc(g, x + 10, y + 4, 2, 0xFFFFD84A);
                    }
                    case "acc_halo" -> {
                        App.rect(g, x + 4, y + 6, 12, 2, 0xFFFFE680);
                        App.rect(g, x + 4, y + 12, 12, 2, 0xFFFFE680);
                        App.rect(g, x + 2, y + 8, 2, 4, 0xFFFFE680);
                        App.rect(g, x + 16, y + 8, 2, 4, 0xFFFFE680);
                    }
                    case "acc_flower" -> {
                        App.disc(g, x + 10, y + 5, 2, 0xFFFF8AC0);
                        App.disc(g, x + 10, y + 15, 2, 0xFFFF8AC0);
                        App.disc(g, x + 5, y + 10, 2, 0xFFFF8AC0);
                        App.disc(g, x + 15, y + 10, 2, 0xFFFF8AC0);
                        App.disc(g, x + 10, y + 10, 3, 0xFFFFD84A);
                    }
                    case "acc_cap" -> {
                        App.rect(g, x + 4, y + 6, 12, 7, 0xFF2F9BFF);
                        App.rect(g, x + 4, y + 12, 16, 2, 0xFF2F7ACF);
                        App.rect(g, x + 9, y + 4, 2, 2, 0xFF2F7ACF);
                    }
                    case "acc_champion" -> {
                        for (int i = 0; i < 4; i++) {
                            App.rect(g, x + 3 + i * 2, y + 14 - i * 3, 3, 3, i % 2 == 0 ? 0xFF4FB86A : 0xFF8FE08A);
                            App.rect(g, x + 14 - i * 2, y + 14 - i * 3, 3, 3, i % 2 == 0 ? 0xFF4FB86A : 0xFF8FE08A);
                        }
                        App.rect(g, x + 9, y + 3, 3, 5, 0xFFFFD84A);
                        App.rect(g, x + 8, y + 5, 5, 1, 0xFFFFD84A);
                    }
                    case "acc_ghost" -> {
                        App.disc(g, x + 10, y + 8, 5, 0xFFF4F0FF);
                        App.rect(g, x + 5, y + 8, 11, 7, 0xFFF4F0FF);
                        App.rect(g, x + 5, y + 15, 3, 2, 0xFFF4F0FF);
                        App.rect(g, x + 10, y + 15, 3, 2, 0xFFF4F0FF);
                        App.rect(g, x + 8, y + 6, 2, 3, 0xFF3A2A3A);
                        App.rect(g, x + 12, y + 6, 2, 3, 0xFF3A2A3A);
                    }
                    case "acc_ushanka" -> {
                        App.rect(g, x + 4, y + 4, 12, 6, 0xFF8A6A4A);
                        App.rect(g, x + 2, y + 8, 4, 9, 0xFF8A6A4A);
                        App.rect(g, x + 14, y + 8, 4, 9, 0xFF8A6A4A);
                        App.rect(g, x + 3, y + 8, 14, 2, 0xFFB08A62);
                        App.rect(g, x + 9, y + 6, 2, 2, 0xFFE5484D);
                    }
                    case "acc_headphones" -> {
                        App.rect(g, x + 4, y + 3, 12, 2, 0xFF3A3A4A);
                        App.rect(g, x + 3, y + 5, 2, 6, 0xFF3A3A4A);
                        App.rect(g, x + 15, y + 5, 2, 6, 0xFF3A3A4A);
                        App.rect(g, x + 1, y + 10, 5, 7, 0xFF3A3A4A);
                        App.rect(g, x + 2, y + 11, 3, 5, 0xFFFF5C93);
                        App.rect(g, x + 14, y + 10, 5, 7, 0xFF3A3A4A);
                        App.rect(g, x + 15, y + 11, 3, 5, 0xFFFF5C93);
                    }
                    case "acc_horns" -> {
                        App.rect(g, x + 4, y + 11, 5, 5, 0xFFE5484D);
                        App.rect(g, x + 5, y + 7, 3, 4, 0xFFE5484D);
                        App.rect(g, x + 5, y + 4, 2, 3, 0xFFE5484D);
                        App.rect(g, x + 11, y + 11, 5, 5, 0xFFE5484D);
                        App.rect(g, x + 12, y + 7, 3, 4, 0xFFE5484D);
                        App.rect(g, x + 13, y + 4, 2, 3, 0xFFE5484D);
                    }
                    case "acc_witch" -> {
                        for (int r = 0; r < 12; r++) App.rect(g, x + 10 - (r / 2 + 1), y + 2 + r, (r / 2 + 1) * 2, 1, 0xFF2A1A3A);
                        App.rect(g, x + 2, y + 14, 16, 3, 0xFF2A1A3A);
                        App.rect(g, x + 6, y + 11, 8, 2, 0xFFB57BD6);
                    }
                    case "acc_scarf" -> {
                        App.rect(g, x + 2, y + 7, 16, 4, 0xFFE5484D);
                        for (int i = 0; i < 4; i++) App.rect(g, x + 3 + i * 4, y + 7, 1, 4, 0xFFFFFFFF);
                        App.rect(g, x + 12, y + 11, 4, 7, 0xFFE5484D);
                        App.rect(g, x + 12, y + 14, 4, 1, 0xFFFFFFFF);
                    }
                    case "acc_cape" -> {
                        App.rect(g, x + 3, y + 4, 14, 3, 0xFFA82A38);
                        App.rect(g, x + 3, y + 7, 4, 10, 0xFFD93A4A);
                        App.rect(g, x + 13, y + 7, 4, 10, 0xFFD93A4A);
                        App.rect(g, x + 9, y + 5, 2, 2, 0xFFFFD84A);
                    }
                    default -> { // crown
                        App.rect(g, x + 3, y + 11, 14, 5, 0xFFFFD84A);
                        for (int r = 0; r < 6; r++) {
                            App.rect(g, x + 3 + r / 3, y + 5 + r, Math.max(1, 3 - r / 3), 1, 0xFFFFD84A);
                            App.rect(g, x + 9, y + 3 + r, 2, 1, 0xFFFFD84A);
                            App.rect(g, x + 14 - r / 3, y + 5 + r, Math.max(1, 3 - r / 3), 1, 0xFFFFD84A);
                        }
                        App.rect(g, x + 9, y + 12, 2, 2, 0xFFE5484D);
                    }
                }
            }
        }
    }

    boolean click(int x, int y) {
        if (App.in(x, y, CHIP_X, CHIP_Y, CHIP_W * 5, CHIP_H)) {
            int i = (x - CHIP_X) / CHIP_W;
            if (i >= 0 && i < 5 && i != tab) { tab = i; scroll = 0; }
            return true;
        }
        List<Item> items = view();
        for (int v = 0; v < VISIBLE; v++) {
            int idx = v + scroll;
            if (idx >= items.size()) break;
            Item it = items.get(idx);
            int ry = TOP + v * ROW;
            if (!App.in(x, y, App.W - BTN_W - 6, ry + 3, BTN_W, 17)) continue;
            switch (action(it)) {
                case "buy" -> {
                    if (kind(it.id()).equals("treat")) Progress.buyTreat(it.id(), it.price());
                    else if (Progress.buy(it.id(), it.price())) {
                        if (kind(it.id()).equals("wall")) Wallpaper.set(Integer.parseInt(it.id().substring(4)));
                        else if (kind(it.id()).equals("acc")) Progress.equip(it.id());
                        else if (kind(it.id()).equals("theme")) Theme.setAero(true);
                    }
                }
                case "set" -> Wallpaper.set(Integer.parseInt(it.id().substring(4)));
                case "wear" -> Progress.equip(it.id());
                case "take_off" -> Progress.unequip(it.id());
                case "theme_on" -> Theme.setAero(true);
                case "theme_off" -> Theme.setAero(false);
                default -> { }
            }
            return true;
        }
        return false;
    }

    void scroll(double amount) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll + (amount < 0 ? 1 : -1)));
    }

    boolean key(int keyCode) {
        switch (keyCode) {
            case 264 -> scroll = Math.min(maxScroll(), scroll + 1);                   // down
            case 265 -> scroll = Math.max(0, scroll - 1);                             // up
            case 262 -> { tab = Math.min(4, tab + 1); scroll = 0; }                   // right
            case 263 -> { tab = Math.max(0, tab - 1); scroll = 0; }                   // left
            default -> { return false; }
        }
        return true;
    }
}
