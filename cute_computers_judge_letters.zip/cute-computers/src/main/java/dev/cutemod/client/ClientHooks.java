package dev.cutemod.client;

import dev.cutemod.ComputerColor;
import dev.cutemod.client.os.Store;
import dev.cutemod.net.RequestDataPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;

/** Kept in a separate class so the dedicated server never loads client-only code. */
public class ClientHooks {
    /** Called once on the client: forget the server's data when we disconnect. */
    public static void init() {
        NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingOut e) -> { Store.clear(); dev.cutemod.client.os.Net.clear(); dev.cutemod.client.os.Post.clear(); dev.cutemod.client.os.Show.clear(); });
    }

    /** The server sent what it has saved for us. */
    public static void onSync(Map<String, String> data) {
        Store.apply(data);
    }

    /** The server told us which parcels are on their way (and maybe gave coins back). */
    public static void onMarketSync(dev.cutemod.net.MarketSyncPayload p) {
        dev.cutemod.client.os.Market.applyServer(p);
    }

    /** An operator changed our coins (/cutecoins). */
    public static void onAdminCoins(dev.cutemod.net.AdminCoinsPayload p) {
        dev.cutemod.client.os.Progress.admin(p.set(), p.amount());
    }

    /** Player mail: the mailbox, the players we can write to and the answer to our last letter. */
    public static void onPostSync(dev.cutemod.net.PostSyncPayload p) {
        dev.cutemod.client.os.Post.apply(p);
    }

    /** CuteNet: the top of a game and who is online. */
    public static void onNetSync(dev.cutemod.net.NetSyncPayload p) {
        dev.cutemod.client.os.Net.apply(p);
    }

    /** The pet show: a page of the list and the answer to our last action. */
    public static void onShowSync(dev.cutemod.net.ShowSyncPayload p) {
        dev.cutemod.client.os.Show.apply(p);
    }

    /** The talent show paid us for our place. */
    public static void onShowPrize(dev.cutemod.net.ShowPrizePayload p) {
        dev.cutemod.client.os.Show.prize(p.coins(), p.rank());
    }

    public static void openComputer(ComputerColor color, BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        if (!Store.ready()) {                       // the server's copy of our data has not arrived yet
            PacketDistributor.sendToServer(new RequestDataPayload());
            if (mc.player != null) mc.player.displayClientMessage(Component.translatable("cutemod.sync.wait"), true);
            return;
        }
        mc.setScreen(new ComputerScreen(color, pos));
    }

    private ClientHooks() {}
}
