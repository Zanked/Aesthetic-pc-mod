package dev.cutemod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * A case for the portable music player. Hold the player in one hand and the case in the other, right-click: the player gets
 * the look of the case (the custom model data of the player is the number of the case, see the overrides of the player models).
 * A new case replaces the old one, which comes back to the player.
 */
public class PlayerCaseItem extends Item {
    /** 1, 2, 3...: the value of custom_model_data that the player gets (0 = no case). */
    private final int number;

    public PlayerCaseItem(Properties props, int number) {
        super(props);
        this.number = number;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack self = player.getItemInHand(hand);
        ItemStack other = player.getItemInHand(hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        if (!(other.getItem() instanceof MusicPlayerItem)) return InteractionResultHolder.pass(self);
        CustomModelData now = other.get(DataComponents.CUSTOM_MODEL_DATA);
        if (now != null && now.value() == number) return InteractionResultHolder.fail(self);   // the same case is already on
        if (!level.isClientSide) {
            if (now != null && now.value() > 0) {
                ItemStack old = ModItems.caseStack(now.value());
                if (!old.isEmpty() && !player.addItem(old)) player.drop(old, false);
            }
            other.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(number));
            if (!player.getAbilities().instabuild) self.shrink(1);
            level.playSound(null, player.blockPosition(), SoundEvents.ARMOR_EQUIP_LEATHER.value(), SoundSource.PLAYERS, 1F, 1.2F);
        }
        return InteractionResultHolder.sidedSuccess(self, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("cutemod.tip.case.use").withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable("cutemod.tip.case.swap").withStyle(ChatFormatting.BLUE));
    }
}
