package dev.cutemod.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Everything the computers remember about each player (progress, shop, password, wallpaper, notes...),
 * kept on the SERVER in the world save (data/cutemod_players.dat) by player UUID. The client only
 * keeps a copy while it is connected. Each entry is a named text blob.
 */
public class PlayerData extends SavedData {
    /** Longest blob in characters (a custom payload from the client may not exceed 32 KiB). */
    public static final int MAX_CHARS = 9000;
    public static final int MAX_BLOBS = 160;   // the pieces of long texts and one blob per pet count too (40 was full for some players, and then the login sync failed)
    private static final String NAME_RE = "[a-z0-9_]{1,40}";

    private final Map<UUID, Map<String, String>> players = new HashMap<>();

    public static PlayerData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(new SavedData.Factory<>(PlayerData::new, PlayerData::load, null), "cutemod_players");
    }

    /** A copy of everything stored for this player. */
    public Map<String, String> copyOf(UUID id) {
        return new HashMap<>(players.getOrDefault(id, Map.of()));
    }

    /** Store one blob (empty text deletes it). Returns false if the request was refused. */
    public boolean put(UUID id, String name, String text) {
        if (name == null || !name.matches(NAME_RE) || text == null || text.length() > MAX_CHARS) return false;
        Map<String, String> m = players.computeIfAbsent(id, k -> new HashMap<>());
        if (text.isEmpty()) {
            if (m.remove(name) == null) return true;
        } else {
            if (!m.containsKey(name) && m.size() >= MAX_BLOBS) return false;
            if (text.equals(m.put(name, text))) return true;
        }
        setDirty();
        return true;
    }

    public static PlayerData load(CompoundTag tag, HolderLookup.Provider registries) {
        PlayerData d = new PlayerData();
        ListTag list = tag.getList("players", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag p = list.getCompound(i);
            try {
                UUID id = UUID.fromString(p.getString("id"));
                CompoundTag blobs = p.getCompound("blobs");
                Map<String, String> m = new HashMap<>();
                for (String k : blobs.getAllKeys()) m.put(k, blobs.getString(k));
                d.players.put(id, m);
            } catch (IllegalArgumentException ignored) {
            }
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        players.forEach((id, m) -> {
            CompoundTag p = new CompoundTag();
            p.putString("id", id.toString());
            CompoundTag blobs = new CompoundTag();
            m.forEach(blobs::putString);
            p.put("blobs", blobs);
            list.add(p);
        });
        tag.put("players", list);
        return tag;
    }
}
