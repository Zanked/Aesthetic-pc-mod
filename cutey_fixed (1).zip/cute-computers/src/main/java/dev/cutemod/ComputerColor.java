package dev.cutemod;

/** The 8 computer variants. Each has its own mini game (see client/game/GameFactory). */
public enum ComputerColor {
    PINK("pink", 0xF4A7C3),
    GREEN("green", 0x8FD39A),
    WHITE("white", 0xE8EAF0),
    BLUE("blue", 0x8EC3F2),
    ORANGE("orange", 0xF5B06B),
    PURPLE("purple", 0x4A3A66),
    YELLOW("yellow", 0xF3D46A),
    RED("red", 0xE27B72);

    public final String id;
    public final int bodyColor;

    ComputerColor(String id, int bodyColor) {
        this.id = id;
        this.bodyColor = bodyColor;
    }

    /** The computer a dye turns a computer into (null: that dye does nothing). */
    public static ComputerColor fromDye(net.minecraft.world.item.DyeColor dye) {
        return switch (dye) {
            case PINK -> PINK;
            case GREEN, LIME -> GREEN;
            case WHITE -> WHITE;
            case BLUE, LIGHT_BLUE, CYAN -> BLUE;
            case ORANGE -> ORANGE;
            case PURPLE, MAGENTA -> PURPLE;
            case YELLOW -> YELLOW;
            case RED -> RED;
            default -> null;
        };
    }

    public String blockName() {
        return id + "_computer";
    }
}
