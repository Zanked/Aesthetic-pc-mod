package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/** Pictures of the trip places and the little photo (a polaroid with the pet in it) of the pet's letters. */
final class TripArt {
    private TripArt() {}

    private static void tri(GuiGraphics g, int cx, int top, int w, int h, int argb) {
        for (int r = 0; r < h; r++) {
            int ww = Math.max(1, w * (r + 1) / h);
            rect(g, cx - ww / 2, top + r, ww, 1, argb);
        }
    }

    /** A round ball with soft corners (the plain disc has a one-pixel nub on top, which looks spiky when it is small). */
    private static void ball(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.round(Math.sqrt((r + 0.2) * (r + 0.2) - dy * dy));
            rect(g, cx - dx, cy + dy, dx * 2 + 1, 1, argb);
        }
    }

    /** A little pixel heart, 7 x 6, its top-left corner at the centre minus 3. */
    private static void heart(GuiGraphics g, int cx, int top, int argb) {
        String[] m = {".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."};
        for (int r = 0; r < m.length; r++) for (int c = 0; c < 7; c++) if (m[r].charAt(c) == 'X') rect(g, cx - 3 + c, top + r, 1, 1, argb);
        rect(g, cx - 2, top + 1, 1, 1, 0xAAFFFFFF);
    }

    private static void ln(GuiGraphics g, int x0, int y0, int x1, int y1, int argb) {
        int n = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)));
        for (int i = 0; i <= n; i++) rect(g, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, 1, 1, argb);
    }

    private static int fl(int c, float f) {             // blends a colour toward white (f > 0) or black (f < 0)
        return App.mix(c, f >= 0 ? 0xFFFFFFFF : 0xFF000000, Math.abs(f));
    }

    /** The place itself, drawn inside the box x,y,w,h (nothing leaves the box). */
    static void scene(GuiGraphics g, int x, int y, int w, int h, int dest, int ticks) {
        int floor = y + h * 70 / 100;
        switch (dest) {
            case 0 -> {      // kindergarten: a rainbow, a soft floor and building blocks
                g.fillGradient(x, y, x + w, y + h, 0xFFFFF3F8, 0xFFFFE0EC);
                int cx = x + w / 2, r = Math.min(h * 55 / 100, w / 2 - 1);
                int[] c = {0xFFFF6B6B, 0xFFFFC832, 0xFF6BCB77, 0xFF4D96FF};
                for (int i = 0; i < 4; i++) disc(g, cx, floor, r - i * Math.max(1, r / 7), c[i]);
                disc(g, cx, floor, Math.max(1, r - 4 * Math.max(1, r / 7)), 0xFFFFF3F8);
                rect(g, x, floor, w, y + h - floor, 0xFFF3D9A4);
                int b = Math.max(3, h / 7);
                rect(g, x + w / 8, floor + 1, b, b, 0xFFE5484D);
                rect(g, x + w / 8 + b, floor + 1, b, b, 0xFF4D96FF);
                rect(g, x + w / 8 + b / 2, floor + 1 - b, b, b, 0xFFFFC832);
            }
            case 1 -> {      // beach
                g.fillGradient(x, y, x + w, floor - h / 8, 0xFF8FD3FF, 0xFFD8F1FF);
                rect(g, x, floor - h / 8, w, h / 8 + 2, 0xFF3FA8E0);
                rect(g, x + (ticks / 6) % 12, floor - h / 8 + 2, 6, 1, 0x99FFFFFF);
                rect(g, x, floor + 2, w, y + h - floor - 2, 0xFFF3D9A4);
                disc(g, x + w * 80 / 100, y + h / 5 + 2, Math.max(3, h / 9), 0xFFFFE066);
                int px = x + w * 20 / 100;                                  // a palm
                rect(g, px, y + h * 35 / 100, 2, floor - y - h * 35 / 100, 0xFF8A5A3A);
                disc(g, px - 5, y + h * 35 / 100, 4, 0xFF3FA55A); disc(g, px + 6, y + h * 35 / 100, 4, 0xFF3FA55A); disc(g, px, y + h * 30 / 100, 4, 0xFF4FB86A);
            }
            case 2 -> {      // forest
                g.fillGradient(x, y, x + w, y + h, 0xFF9ADCA0, 0xFF3FA55A);
                for (int i = 0; i < 4; i++) {
                    int tx = x + w * (12 + i * 24) / 100;
                    rect(g, tx - 1, y + h * 35 / 100, 3, floor - y - h * 35 / 100 + 2, 0xFF6A4228);
                    disc(g, tx, y + h * 30 / 100, Math.max(4, h / 6), i % 2 == 0 ? 0xFF2E8B4A : 0xFF3FA55A);
                }
                rect(g, x, floor + 2, w, y + h - floor - 2, 0xFF2E7A3A);
                int mx = x + w * 55 / 100;                                  // a mushroom
                rect(g, mx, floor, 2, 3, 0xFFF3E8D0);
                disc(g, mx + 1, floor, 3, 0xFFE5484D);
                rect(g, mx, floor - 2, 1, 1, 0xFFFFFFFF);
            }
            case 3 -> {      // mountains with snow
                g.fillGradient(x, y, x + w, y + h, 0xFF7FC4FF, 0xFFD8F1FF);
                tri(g, x + w * 32 / 100, y + h * 15 / 100, w * 55 / 100, floor - y - h * 15 / 100, 0xFF8A94A8);
                tri(g, x + w * 32 / 100, y + h * 15 / 100, w * 18 / 100, h * 16 / 100, 0xFFFFFFFF);
                tri(g, x + w * 72 / 100, y + h * 35 / 100, w * 40 / 100, floor - y - h * 35 / 100, 0xFF7480A0);
                tri(g, x + w * 72 / 100, y + h * 35 / 100, w * 12 / 100, h * 10 / 100, 0xFFFFFFFF);
                rect(g, x, floor, w, y + h - floor, 0xFF5BBF6A);
            }
            case 4 -> {      // a city at dusk
                g.fillGradient(x, y, x + w, y + h, 0xFF3A2A6A, 0xFFF58FB8);
                int[] hh = {42, 62, 38, 70, 50, 58};
                for (int i = 0; i < 6; i++) {
                    int bx = x + i * w / 6, bw = w / 6 - 1, bh = h * hh[i] / 100;
                    rect(g, bx, y + h - bh, bw, bh, i % 2 == 0 ? 0xFF2A2048 : 0xFF3A2D5E);
                    for (int wy = y + h - bh + 3; wy < y + h - 4; wy += 5)
                        for (int wx = bx + 2; wx < bx + bw - 2; wx += 4)
                            if (((wx * 7 + wy * 13 + (ticks / 40)) % 5) != 0) rect(g, wx, wy, 2, 2, 0xFFFFE680);
                }
            }
            case 6 -> {      // bee meadow: flowers, a hive and bees
                g.fillGradient(x, y, x + w, y + h, 0xFFFFF3B0, 0xFFB6E88A);
                rect(g, x, floor, w, y + h - floor, 0xFF5BBF6A);
                int hx = x + w * 22 / 100, hw = Math.max(8, w / 6), rh = Math.max(3, h / 12);
                for (int i = 0; i < 4; i++) {
                    int in = i == 0 || i == 3 ? 2 : 0;
                    rect(g, hx - hw / 2 + in, floor - (i + 1) * rh, hw - in * 2, rh - 1, i % 2 == 0 ? 0xFFF5B800 : 0xFFFFD84D);
                }
                rect(g, hx - 1, floor - rh * 2, 3, 3, 0xFF3A2A3A);
                for (int i = 0; i < 7; i++) rect(g, x + (i * 41 + 9) % (w - 3), floor + 2 + (i * 7) % Math.max(1, y + h - floor - 4), 2, 2, i % 3 == 0 ? 0xFFFFFFFF : i % 3 == 1 ? 0xFFFF8FB8 : 0xFFFFF3B0);
                for (int i = 0; i < 3; i++) {
                    int bx = x + 2 + (ticks * (1 + i) / 2 + i * 37) % Math.max(1, w - 5), by = y + h * (22 + i * 13) / 100 + (int) Math.round(Math.sin((ticks + i * 9) / 6.0) * 3);
                    rect(g, bx, by, 3, 2, 0xFFFFC832);
                    rect(g, bx + 1, by, 1, 2, 0xFF3A2A3A);
                }
            }
            case 7 -> {      // a city in the clouds: floating islands
                g.fillGradient(x, y, x + w, y + h, 0xFF3A6AD8, 0xFFFFB8D8);
                for (int i = 0; i < 3; i++) {
                    int cx = x + (int) ((ticks * (0.08 + i * 0.04) + i * 40) % (w + 20)) - 10, cy = y + h * (15 + i * 20) / 100;
                    disc(g, Math.max(x + 4, Math.min(x + w - 5, cx)), cy, 3, 0xCCFFFFFF);
                }
                for (int i = 0; i < 2; i++) {
                    int ix = x + w * (28 + i * 42) / 100, iy = y + h * (50 + i * 14) / 100, iw = w * 22 / 100;
                    rect(g, ix - iw / 2 + 2, iy + 3, iw - 4, h / 12, 0xFF8A6A4A);
                    rect(g, ix - iw / 2, iy, iw, 3, 0xFF5BBF6A);
                    rect(g, ix - 3, iy - 6, 6, 6, 0xFFFFFFFF);
                    tri(g, ix, iy - 11, 10, 5, 0xFFE5484D);
                }
            }
            case 8 -> {      // a snowy village at night
                g.fillGradient(x, y, x + w, y + h, 0xFF14204A, 0xFF3A4A8A);
                rect(g, x + w * 70 / 100, y + h * 15 / 100, 1, 1, 0xFFFFFFFF);
                rect(g, x + w * 30 / 100, y + h * 10 / 100, 1, 1, 0xFFFFFFFF);
                rect(g, x, floor, w, y + h - floor, 0xFFF4F9FF);
                for (int i = 0; i < 2; i++) {
                    int hx = x + w * (18 + i * 44) / 100, hw = w * 24 / 100, hh = h * 24 / 100;
                    rect(g, hx, floor - hh + 3, hw, hh, 0xFF8A5A3A);
                    tri(g, hx + hw / 2, floor - hh - hh / 2 + 3, hw + 4, hh / 2 + 1, 0xFFFFFFFF);
                    rect(g, hx + hw / 2 - 2, floor - hh / 2 + 1, 4, 4, 0xFFFFE680);
                }
                for (int i = 0; i < 10; i++) rect(g, x + (i * 29 + ticks / 6 * (i % 2 + 1)) % w, y + (i * 17 + ticks / 2) % Math.max(1, floor - y), 1, 1, 0xFFFFFFFF);
            }
            case 9 -> {      // a cherry garden
                g.fillGradient(x, y, x + w, y + h, 0xFFFFE0EC, 0xFFFFF8FB);
                rect(g, x, floor, w, y + h - floor, 0xFF9ADCA0);
                int tx = x + w * 40 / 100;
                rect(g, tx - 2, y + h * 38 / 100, 4, floor - y - h * 38 / 100 + 1, 0xFF6A4228);
                int cr = Math.max(5, h / 5);
                disc(g, tx, y + h * 30 / 100, cr, 0xFFF58FB8);
                disc(g, tx - cr, y + h * 38 / 100, cr * 2 / 3, 0xFFFFB6D2);
                disc(g, Math.min(x + w - cr, tx + cr), y + h * 38 / 100, cr * 2 / 3, 0xFFFFB6D2);
                for (int i = 0; i < 10; i++) rect(g, x + (i * 31 + ticks / 5 * (1 + i % 2)) % w, y + h * 25 / 100 + (i * 13 + ticks / 2) % Math.max(1, floor - y - h * 25 / 100), 2, 1, i % 2 == 0 ? 0xFFFFB6D2 : 0xFFFFFFFF);
            }
            case 10 -> {     // a lighthouse at sunset
                g.fillGradient(x, y, x + w, floor, 0xFFFF8A5C, 0xFFFFE0A0);
                disc(g, x + w * 68 / 100, y + h * 50 / 100, Math.max(3, h / 8), 0xFFFFD84D);
                rect(g, x, y + h * 54 / 100, w, y + h - y - h * 54 / 100, 0xFF3A6AB8);
                rect(g, x + w * 62 / 100, y + h * 56 / 100, w * 12 / 100, 1, 0xAAFFE0A0);
                rect(g, x + w * 64 / 100, y + h * 62 / 100, w * 8 / 100, 1, 0x88FFE0A0);
                int lx = x + w * 26 / 100, lh = h * 52 / 100, base = y + h * 82 / 100;
                for (int r = 0; r < lh; r++) {
                    int ww = Math.max(3, w * 8 / 100 + r * w / 100 / 8);
                    rect(g, lx - ww / 2, base - lh + r, ww, 1, (r / Math.max(2, lh / 5)) % 2 == 0 ? 0xFFE5484D : 0xFFFFFFFF);
                }
                rect(g, lx - 3, base - lh - 4, 6, 4, (ticks / 20) % 2 == 0 ? 0xFFFFE680 : 0xFFFFC832);
                rect(g, lx - 5, base, 11, y + h - base, 0xFF6A6A78);
            }
            case 11 -> {     // an amusement park: a ferris wheel that turns, a striped tent and flags
                g.fillGradient(x, y, x + w, y + h, 0xFF7FC4FF, 0xFFFFE6F0);
                ball(g, x + w * 14 / 100, y + h * 20 / 100, Math.max(3, h / 10), 0x55FFFFFF);
                rect(g, x, floor, w, y + h - floor, 0xFF8ED38F);
                rect(g, x, floor, w, 1, 0xFF6FBF72);
                int cx = x + w * 36 / 100, r = Math.min(h * 34 / 100, w / 4), cy = floor - r - 2;
                ln(g, cx, cy, cx - r / 2, floor, 0xFF8A5A3A); ln(g, cx, cy, cx + r / 2, floor, 0xFF8A5A3A);
                ln(g, cx + 1, cy, cx - r / 2 + 1, floor, 0xFF8A5A3A); ln(g, cx + 1, cy, cx + r / 2 + 1, floor, 0xFF8A5A3A);
                for (int a = 0; a < 40; a++) {                                  // the rim
                    double an = a * Math.PI / 20;
                    rect(g, cx + (int) Math.round(Math.cos(an) * r), cy + (int) Math.round(Math.sin(an) * r), 1, 1, 0xFFE5484D);
                }
                int[] gc = {0xFFFFC832, 0xFF4D96FF, 0xFFFF8FB8, 0xFF6BCB77, 0xFFB57BD6, 0xFFFF9A3C};
                for (int i = 0; i < 6; i++) {
                    double an = ticks / 90.0 + i * Math.PI / 3;
                    int gx = cx + (int) Math.round(Math.cos(an) * r), gy = cy + (int) Math.round(Math.sin(an) * r);
                    ln(g, cx, cy, gx, gy, 0x99FFFFFF);
                    rect(g, gx - 1, gy, 3, 3, fl(gc[i], -0.25F));
                    rect(g, gx - 1, gy, 3, 2, gc[i]);
                }
                ball(g, cx, cy, 2, 0xFFFFD84D);
                int tx = x + w * 76 / 100, tw = w * 26 / 100, th = h * 22 / 100;      // the tent
                for (int i = 0; i < tw; i += 3) rect(g, tx - tw / 2 + i, floor - th + 2, Math.min(3, tw - i), th - 2, (i / 3) % 2 == 0 ? 0xFFE5484D : 0xFFFFFFFF);
                tri(g, tx, floor - th - th / 2 + 2, tw + 4, th / 2 + 1, 0xFFFFC832);
                rect(g, tx - 2, floor - th / 2 + 1, 4, th / 2 - 1, 0xFF6E3A5A);
                int fc[] = {0xFFE5484D, 0xFFFFC832, 0xFF4D96FF, 0xFF6BCB77};         // bunting along the top
                for (int i = 0; i < w; i += 7) {
                    int sag = (int) Math.round(Math.sin(i * Math.PI / w) * 3);
                    rect(g, x + i, y + 2 + sag, 7, 1, 0xFF8A6A5A);
                    tri(g, x + i + 3, y + 3 + sag, 5, 4, fc[(i / 7) % 4]);
                }
            }
            case 12 -> {     // a cinema: curtains, a screen that flickers, seats and popcorn
                g.fillGradient(x, y, x + w, y + h, 0xFF2A1030, 0xFF5A1A3A);
                int sx = x + w * 18 / 100, sw = w * 64 / 100, sy = y + h * 10 / 100, sh = h * 42 / 100;
                rect(g, sx - 1, sy - 1, sw + 2, sh + 2, 0xFF1A0A20);
                boolean flick = (ticks / 3) % 9 != 0;
                g.fillGradient(sx, sy, sx + sw, sy + sh, flick ? 0xFFFFF6D8 : 0xFFE8DCC0, flick ? 0xFFFFD8E8 : 0xFFD8C0D0);
                int hx = sx + sw / 2 + (int) Math.round(Math.sin(ticks / 25.0) * (sw / 5)), hy = sy + sh / 2 + 1;     // a little heart on the screen
                heart(g, hx, hy - 2, 0xFFFF6B8E);
                for (int sd = 0; sd < 2; sd++) {                                  // the red curtains with folds
                    int cx0 = sd == 0 ? x : x + w - w * 15 / 100, cw = w * 15 / 100;
                    rect(g, cx0, y, cw, floor - y + 3, 0xFFC02844);
                    for (int k = 1; k < cw; k += 3) rect(g, cx0 + k, y, 1, floor - y + 3, 0xFF8A1830);
                    rect(g, cx0, y, cw, 3, 0xFFFFC832);
                }
                rect(g, x, floor + 3, w, y + h - floor - 3, 0xFF3A1428);
                for (int i = 0; i < 5; i++) {                                    // seat backs with little heads
                    int bx = x + 3 + i * (w - 6) / 5, bw = (w - 6) / 5 - 2, bh = Math.max(4, h * 22 / 100);
                    rect(g, bx, y + h - bh, bw, bh, i % 2 == 0 ? 0xFF8A1830 : 0xFFA02040);
                    rect(g, bx, y + h - bh, bw, 1, 0xFFC84868);
                    if (i == 1 || i == 3) ball(g, bx + bw / 2, y + h - bh - 1, 2, 0xFF1A0A20);
                }
                int bx = x + w * 86 / 100, bt = floor + 1;                       // popcorn
                ball(g, bx, bt - 1, 2, 0xFFFFF0B0); ball(g, bx - 2, bt, 2, 0xFFFFE680); ball(g, bx + 2, bt, 2, 0xFFFFF0B0);
                rect(g, bx - 3, bt + 1, 7, 4, 0xFFFFFFFF);
                rect(g, bx - 2, bt + 1, 1, 4, 0xFFE5484D); rect(g, bx, bt + 1, 1, 4, 0xFFE5484D); rect(g, bx + 2, bt + 1, 1, 4, 0xFFE5484D);
            }
            case 13 -> {     // a museum: columns, a painting and a glowing treasure under glass
                g.fillGradient(x, y, x + w, y + h, 0xFFFFF4DC, 0xFFEBD4A8);
                for (int yy = floor + 2; yy < y + h; yy += 4)                    // a chess floor
                    for (int xx = 0, k = (yy / 4) & 1; xx < w; xx += 6, k++)
                        rect(g, x + xx, yy, 6, Math.min(4, y + h - yy), (k & 1) == 0 ? 0xFFF4EBDD : 0xFFB8946A);
                rect(g, x, floor, w, 2, 0xFF9A7A52);
                for (int sd = 0; sd < 2; sd++) {                                 // two columns
                    int cx = sd == 0 ? x + w * 9 / 100 : x + w * 91 / 100 - 5;
                    rect(g, cx, y + h * 12 / 100, 6, floor - y - h * 12 / 100, 0xFFF8F2E6);
                    rect(g, cx + 4, y + h * 12 / 100, 2, floor - y - h * 12 / 100, 0xFFD8CDB8);
                    rect(g, cx - 1, y + h * 8 / 100, 8, 3, 0xFFFFFFFF); rect(g, cx - 1, floor - 2, 8, 3, 0xFFFFFFFF);
                }
                int fx = x + w * 22 / 100, fw = w * 22 / 100, fy = y + h * 18 / 100, fh = h * 30 / 100;     // a framed painting
                rect(g, fx - 2, fy - 2, fw + 4, fh + 4, 0xFFC8952C); rect(g, fx - 1, fy - 1, fw + 2, fh + 2, 0xFFFFD84D);
                g.fillGradient(fx, fy, fx + fw, fy + fh, 0xFF8FD3FF, 0xFFD6F2FF);
                rect(g, fx, fy + fh * 60 / 100, fw, fh - fh * 60 / 100, 0xFF6FC66A);
                ball(g, fx + fw * 70 / 100, fy + fh * 28 / 100, Math.max(2, fh / 8), 0xFFFFE066);
                int px = x + w * 62 / 100, pw = w * 22 / 100;                    // the pedestal and the dome
                rect(g, px - pw / 2, floor - h * 16 / 100, pw, h * 16 / 100 + 2, 0xFFE8DCC8);
                rect(g, px - pw / 2, floor - h * 16 / 100, pw, 1, 0xFFFFFFFF);
                int dr = Math.max(4, pw / 2 - 1);
                for (int dy = -dr; dy <= 0; dy++) {
                    int dx = (int) Math.round(Math.sqrt(dr * dr - dy * dy));
                    rect(g, px - dx, floor - h * 16 / 100 + dy, 1, 1, 0xAAB8E8FF); rect(g, px + dx, floor - h * 16 / 100 + dy, 1, 1, 0xAAB8E8FF);
                }
                rect(g, px - dr, floor - h * 16 / 100 - dr, dr * 2 + 1, 1, 0x88FFFFFF);
                tri(g, px, floor - h * 16 / 100 - 8, 7, 7, 0xFFB57BD6);          // a gem inside
                if ((ticks / 12) % 3 != 0) { rect(g, px - 1, floor - h * 16 / 100 - 10, 3, 1, 0xFFFFFFFF); rect(g, px, floor - h * 16 / 100 - 11, 1, 3, 0xFFFFFFFF); }
            }
            case 14 -> {     // a camp: stars, pines, a tent and a campfire that flickers
                g.fillGradient(x, y, x + w, y + h, 0xFF0E1838, 0xFF2E4A78);
                ball(g, x + w * 82 / 100, y + h * 20 / 100, Math.max(3, h / 9), 0xFFFFF3B0);
                ball(g, x + w * 82 / 100 + 2, y + h * 20 / 100 - 1, Math.max(2, h / 11), 0xFF1A2850);
                for (int i = 0; i < 14; i++) rect(g, x + (i * 41 + 7) % w, y + (i * 19 + 3) % Math.max(1, h * 50 / 100), 1, 1, (ticks / 14 + i) % 5 == 0 ? 0xFF8890B8 : 0xFFFFFFFF);
                for (int i = 0; i < 5; i++) {                                    // pine trees
                    int tx = x + w * (4 + i * 22) / 100, th = h * (30 + (i * 17) % 18) / 100;
                    tri(g, tx, floor - th, 12, th * 55 / 100, 0xFF123A2A); tri(g, tx, floor - th * 55 / 100, 16, th * 55 / 100, 0xFF1A4A34);
                }
                rect(g, x, floor, w, y + h - floor, 0xFF2A4A2E);
                int tx = x + w * 28 / 100, tw = w * 24 / 100, th = h * 28 / 100;     // the tent
                tri(g, tx, floor - th + 1, tw, th, 0xFFE8803A);
                tri(g, tx, floor - th + 1, tw / 2, th, 0xFFF4A860);
                tri(g, tx, floor - th / 2 + 1, tw / 4 + 1, th / 2, 0xFF3A2A3A);
                int fx = x + w * 66 / 100, fb = floor + 3;                           // the fire
                ball(g, fx, fb - 4, 9, 0x14FFB040); ball(g, fx, fb - 4, 6, 0x22FFB040);
                rect(g, fx - 5, fb, 10, 2, 0xFF6A4228); rect(g, fx - 4, fb - 1, 8, 1, 0xFF8A5A3A);
                int fh = 8 + (ticks / 4) % 3;
                tri(g, fx, fb - fh, 8, fh, 0xFFFF7A2A); tri(g, fx, fb - fh + 3, 5, fh - 3, 0xFFFFC832); tri(g, fx, fb - 4, 2, 4, 0xFFFFF3B0);
                for (int i = 0; i < 3; i++) rect(g, fx - 3 + (i * 5 + ticks / 7) % 7, fb - fh - 2 - (ticks / 3 + i * 7) % 9, 1, 1, 0xFFFFD84D);   // sparks
            }
            case 15 -> {     // an old house on Halloween night: a big moon, bats and a pumpkin
                g.fillGradient(x, y, x + w, y + h, 0xFF1A0E30, 0xFF5A2A60);
                ball(g, x + w * 72 / 100, y + h * 26 / 100, Math.max(5, h / 5), 0x1CFFD890);
                ball(g, x + w * 72 / 100, y + h * 26 / 100, Math.max(4, h / 7), 0xFFFFE9A8);
                rect(g, x, floor, w, y + h - floor, 0xFF20142C);
                int hx = x + w * 30 / 100, hw = w * 36 / 100, hh = h * 30 / 100;         // the house
                rect(g, hx, floor - hh + 2, hw, hh, 0xFF2E1E44);
                tri(g, hx + hw / 2, floor - hh - hh * 6 / 10 + 2, hw + 6, hh * 6 / 10, 0xFF3A2858);
                rect(g, hx + hw * 70 / 100, floor - hh - hh / 2, 3, hh / 2, 0xFF2E1E44);          // a chimney
                for (int i = 0; i < 2; i++) {
                    int wx = hx + 4 + i * (hw - 12);
                    boolean on = (ticks / 25 + i * 3) % 7 != 0;                          // the windows flicker
                    rect(g, wx, floor - hh + 6, 5, 6, on ? 0xFFFFD84D : 0xFF6A5030);
                    if (on) rect(g, wx + 2, floor - hh + 6, 1, 6, 0xFF8A5A1A);
                }
                rect(g, hx + hw / 2 - 2, floor - hh / 2 + 1, 4, hh / 2 + 1, 0xFF120A20);
                int tx = x + w * 10 / 100;                                              // a bare tree
                rect(g, tx, floor - h * 36 / 100, 2, h * 36 / 100 + 1, 0xFF120A20);
                ln(g, tx + 1, floor - h * 30 / 100, tx - 6, floor - h * 42 / 100, 0xFF120A20); ln(g, tx + 1, floor - h * 24 / 100, tx + 7, floor - h * 38 / 100, 0xFF120A20);
                for (int i = 0; i < 3; i++) {                                            // bats
                    int bx = x + 4 + (ticks * (1 + i % 2) / 3 + i * 41) % Math.max(1, w - 10), by = y + h * (14 + i * 14) / 100 + (int) Math.round(Math.sin((ticks + i * 11) / 5.0) * 2);
                    boolean up = (ticks / 6 + i) % 2 == 0;
                    rect(g, bx + 2, by, 2, 2, 0xFF0A0614);
                    rect(g, bx, by + (up ? -1 : 1), 2, 1, 0xFF0A0614); rect(g, bx + 4, by + (up ? -1 : 1), 2, 1, 0xFF0A0614);
                }
                int px = x + w * 74 / 100, pr = Math.max(2, h / 14), py = floor + 1;     // a pumpkin with a glowing face
                ball(g, px, py, pr, 0xFFE8803A);
                if (pr >= 4) {
                    ball(g, px - 3, py, 3, 0xFFF4A04A); ball(g, px + 3, py, 3, 0xFFF4A04A);
                    rect(g, px, py - 7, 2, 3, 0xFF3A7A3A);
                    rect(g, px - 3, py - 2, 2, 2, 0xFFFFF0A0); rect(g, px + 1, py - 2, 2, 2, 0xFFFFF0A0); rect(g, px - 2, py + 2, 5, 1, 0xFFFFF0A0);
                } else rect(g, px, py - pr - 1, 1, 2, 0xFF3A7A3A);
            }
            case 16 -> {     // a fair: striped stalls, balloons and bunting
                g.fillGradient(x, y, x + w, y + h, 0xFF9AD8FF, 0xFFFFF0F6);
                rect(g, x, floor + 2, w, y + h - floor - 2, 0xFFF0D8A8);
                for (int i = 0; i < w; i += 6) rect(g, x + i, floor + 2, 3, 1, 0xFFD8BC88);
                for (int i = 0; i < 2; i++) {                                           // two stalls
                    int sx = x + w * (6 + i * 40) / 100, sw = w * 34 / 100, sh = h * 36 / 100;
                    int c1 = i == 0 ? 0xFFE5484D : 0xFF4D96FF;
                    rect(g, sx + 2, floor - sh + 6, sw - 4, sh - 4, 0xFFFFF4DC);
                    rect(g, sx, floor - 5, sw, 7, 0xFFC8955C); rect(g, sx, floor - 5, sw, 1, 0xFFE8B880);
                    for (int k = 0; k < sw; k += 4) {
                        rect(g, sx + k, floor - sh, Math.min(4, sw - k), 6, (k / 4) % 2 == 0 ? c1 : 0xFFFFFFFF);
                        rect(g, sx + k, floor - sh + 5, Math.min(4, sw - k), 2, (k / 4) % 2 == 0 ? fl(c1, -0.2F) : 0xFFE8E0E8);
                    }
                    if (i == 0) { ball(g, sx + sw / 2, floor - 8, 3, 0xFFB57B4A); ball(g, sx + sw / 2 - 2, floor - 11, 1, 0xFFB57B4A); ball(g, sx + sw / 2 + 2, floor - 11, 1, 0xFFB57B4A); }   // a prize bear
                    else { ball(g, sx + sw / 2 - 3, floor - 8, 2, 0xFFFFC832); ball(g, sx + sw / 2 + 3, floor - 8, 2, 0xFFFF8FB8); }
                }
                int[] bc = {0xFFFF6B6B, 0xFFFFC832, 0xFF4D96FF, 0xFF6BCB77, 0xFFB57BD6};
                for (int i = 0; i < 5; i++) {                                           // balloons that sway
                    int bx = x + w * (14 + i * 18) / 100 + (int) Math.round(Math.sin((ticks + i * 13) / 18.0) * 2);
                    int by = y + h * (10 + (i * 23) % 22) / 100 + (int) Math.round(Math.sin((ticks + i * 7) / 24.0) * 1.5);
                    int br = Math.max(1, h / 24);
                    ball(g, bx, by, br, bc[i]); if (br > 1) rect(g, bx - 1, by - br + 1, 1, 1, 0x99FFFFFF);
                    ln(g, bx, by + br + 1, bx + (i % 2 == 0 ? 1 : -1), by + br + 1 + Math.max(2, h / 11), 0xAA8A7A8A);
                }
            }
            case 17 -> {     // the Quiet Place: a violet night, a still lake, hills, a lantern and a star that drifts
                g.fillGradient(x, y, x + w, y + h, 0xFF0B0A2A, 0xFF2A1F5C);
                for (int i = 0; i < 28; i++) {
                    int sx = x + (i * 53 + 7) % Math.max(1, w - 2), sy = y + (i * 29 + 3) % Math.max(1, floor - y - 8);
                    rect(g, sx, sy, i % 9 == 0 ? 2 : 1, i % 9 == 0 ? 2 : 1, (ticks / 12 + i) % 7 == 0 ? 0x66FFFFFF : 0xDDFFFFFF);
                }
                int mr = Math.max(4, h / 9), mx = x + w * 78 / 100, my = y + h * 22 / 100;
                disc(g, mx, my, mr + 2, 0x22FFF0C0); disc(g, mx, my, mr, 0xFFFFF0C0); disc(g, mx + mr / 3, my - mr / 4, mr, 0xFF140F38);
                rect(g, x, floor, w, y + h - floor, 0xFF191246);                                   // the lake
                for (int i = 0; i < 5; i++) rect(g, x + (i * 61 + ticks / 4) % Math.max(1, w - 8), floor + 3 + i * Math.max(1, (y + h - floor) / 6), 6, 1, 0x55B79CFF);
                for (int cx = 0; cx < w; cx++) {                                                   // dark hills on the far shore
                    int top = floor - 3 - (int) Math.round(Math.sin(cx / 24.0) * 5 + Math.sin(cx / 9.0 + 1) * 2);
                    rect(g, x + cx, top, 1, floor - top + 1, 0xFF0C0926);
                }
                int lx = x + w * 24 / 100;                                                         // a lantern
                rect(g, lx, floor - h * 22 / 100, 1, h * 22 / 100, 0xFF3A2C7A);
                int fl = 7 + (ticks / 8) % 3;
                disc(g, lx, floor - h * 22 / 100, fl, 0x22FFD866); disc(g, lx, floor - h * 22 / 100, 4, 0x44FFD866);
                rect(g, lx - 1, floor - h * 22 / 100 - 1, 3, 3, 0xFFFFE680);
                int sx2 = x + w * 56 / 100 + (int) Math.round(Math.sin(ticks / 30.0) * 6), sy2 = y + h * 36 / 100 + (int) Math.round(Math.sin(ticks / 17.0) * 3);
                rect(g, sx2, sy2 - 3, 1, 7, 0xFFFFD866); rect(g, sx2 - 3, sy2, 7, 1, 0xFFFFD866); rect(g, sx2 - 1, sy2 - 1, 3, 3, 0xFFFFF0A0);
                rect(g, sx2, floor + 4, 1, 3, 0x55FFD866);                                         // its reflection
            }
            case 5 -> {      // the moon: stars, grey ground and the Earth
                rect(g, x, y, w, h, 0xFF0B0B2A);
                for (int i = 0; i < 12; i++) rect(g, x + (i * 37 + 5) % w, y + (i * 23 + 3) % (h * 60 / 100), 1, 1, (ticks / 15 + i) % 4 == 0 ? 0xFF888899 : 0xFFFFFFFF);
                disc(g, x + w * 80 / 100, y + h * 22 / 100, Math.max(4, h / 7), 0xFF4D96FF);
                disc(g, x + w * 80 / 100 - 1, y + h * 22 / 100 - 1, Math.max(2, h / 12), 0xFF6BCB77);
                for (int cx = 0; cx < w; cx++) {                           // the curve of the moon
                    double t = (cx - w / 2.0) / (w * 0.75);
                    int top = (int) (floor + 2 + t * t * h * 0.22);
                    if (top < y + h) rect(g, x + cx, top, 1, y + h - top, 0xFFB8BCC8);
                }
                disc(g, x + w * 30 / 100, floor + h / 8, Math.max(1, h / 14), 0xFF9094A0);
            }
        }
    }

    /** A polaroid: the place, the pet standing in it and the name of the place under it. */
    static void photo(GuiGraphics g, Font f, int x, int y, int w, int h, int dest, ComputerColor color, int stage, int ticks) {
        rect(g, x + 1, y + 2, w, h, 0x33000000);
        rect(g, x, y, w, h, 0xFFFFFFFF);
        int ix = x + 3, iy = y + 3, iw = w - 6, ih = h - 15;
        scene(g, ix, iy, iw, ih, dest, ticks);
        float sc = 0.4F * PetArt.scaleOf(stage);
        int cx = ix + iw / 2 + (dest == 0 ? 0 : 6), fl = iy + ih * 80 / 100;
        g.pose().pushPose();
        g.pose().translate(cx, fl, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-cx, -fl, 0);
        PetArt.draw(g, color, cx, fl - 28, 2, ticks, false, false, stage, Progress.equipped(), Progress.equippedBody());
        g.pose().popPose();
        String name = f.plainSubstrByWidth(Component.translatable("cutemod.trip.dest." + dest).getString(), w - 8);
        CuteFont.draw(g, f, name, x + (w - f.width(name)) / 2, y + h - 11, 0xFF3A2A3A, false);
    }

    /** The photo of a letter of the ring (slot 0-5) and what the pet found, drawn at x,y. */
    static void letterPhoto(GuiGraphics g, Font f, int x, int y, int slot, int ticks) {
        String p = "tr" + slot + "_";
        int dest = Math.max(0, Progress.count(p + "dest") - 1), find = Math.max(0, Progress.count(p + "find") - 1);
        ComputerColor col = ComputerColor.values()[Math.floorMod(Progress.count(p + "col") - 1, ComputerColor.values().length)];
        photo(g, f, x, y, 104, 64, dest, col, Math.max(0, Math.min(2, Progress.count(p + "stage"))), ticks);
        int tx = x + 114;
        CuteFont.draw(g, f, Component.translatable("cutemod.trip.found"), tx, y + 4, 0xFF8A7AA8, false);
        CuteFont.draw(g, f, Component.translatable("cutemod.trip.find." + dest + "." + find), tx, y + 15, 0xFF3A2A3A, false);
        if (Progress.count(p + "new") > 0) CuteFont.draw(g, f, Component.translatable("cutemod.trip.new"), tx, y + 27, 0xFFE5484D, false);
        int coins = Progress.count(p + "coins");
        if (coins > 0) { Progress.drawCoin(g, tx, y + 41); CuteFont.draw(g, f, "+" + coins, tx + 10, y + 40, 0xFFC98A00, false); }
        else CuteFont.draw(g, f, Component.translatable("cutemod.trip.no_coins"), tx, y + 40, 0xFF9A8AB8, false);
    }
}
