package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * A program that runs on the computer desktop. The app area is W x H GUI pixels,
 * all coordinates passed to the app are local (0,0 = top-left of the area).
 */
public abstract class App {
    public static final int W = 300;
    public static final int H = 166;

    protected Shell shell;

    public void attach(Shell shell) { this.shell = shell; }

    public abstract Component title();

    /** Called 60 times per second. */
    public void tick() {}

    public abstract void render(GuiGraphics g, int mx, int my);

    /** Mouse position, called every frame before the ticks. */
    public void mouse(int x, int y) {}

    public boolean click(int x, int y, int button) { return false; }

    public boolean drag(int x, int y, int button) { return false; }

    /** The mouse button was let go (x, y are local and may lie outside the area, e.g. over the Dock). */
    public boolean release(int x, int y, int button) { return false; }

    public boolean key(int keyCode, int modifiers) { return false; }

    public boolean charTyped(char c) { return false; }

    public boolean scroll(double amount) { return false; }

    /** Called when the app is closed / the computer screen is left. */
    public void close() {}

    /** The back button of the title bar: true if the app can go one step back inside itself (it is shown only then). */
    public boolean canBack() { return false; }

    /** One step back inside the app (called only when {@link #canBack()} is true). */
    public void back() {}

    public Component hint() { return Component.empty(); }

    public Component status() { return Component.empty(); }

    /** True if the app must keep ticking while it is minimized (music keeps playing). */
    public boolean background() { return false; }

    /** True while the app is busy on its own (a video or music plays): the screensaver must not start. */
    public boolean busy() { return false; }

    /** Show the computer's high score in the footer. */
    public boolean showRecord() { return false; }

    // ---------- helpers ----------
    protected static Font font() { return Minecraft.getInstance().font; }

    protected static String t(String key, Object... args) {
        return Component.translatable(key, args).getString();
    }

    /**
     * Draws a text that must fit in maxW pixels (a button, a card, a tooltip): it is shrunk down to 65% and, if it is
     * still too wide, cut. x is the left edge, or the middle when centered. Long translations then stay readable.
     */
    protected static void fitText(GuiGraphics g, Font f, String s, int x, int y, int maxW, int color, boolean centered) {
        int w = f.width(s);
        if (w <= maxW) {
            CuteFont.draw(g, f, s, centered ? x - w / 2 : x, y, color, false);
            return;
        }
        float sc = Math.max(0.65f, maxW / (float) w);
        String cut = w * sc > maxW ? f.plainSubstrByWidth(s, (int) (maxW / sc)) : s;
        float tw = f.width(cut) * sc;
        g.pose().pushPose();
        g.pose().translate(centered ? x - tw / 2f : x, y + (1 - sc) * 4f, 0);
        g.pose().scale(sc, sc, 1f);
        CuteFont.draw(g, f, cut, 0, 0, color, false);
        g.pose().popPose();
    }

    /** The one small size for names under folder icons. */
    protected static final float SMALL_SCALE = 0.65f;

    /** Draws a name centered at x in the one small size; if it is still wider than maxW it is cut and ends with "..". */
    protected static void smallText(GuiGraphics g, Font f, String s, int x, int y, int maxW, int color) {
        String cut = s;
        if (f.width(s) * SMALL_SCALE > maxW)
            cut = f.plainSubstrByWidth(s, (int) (maxW / SMALL_SCALE) - f.width("..")).trim() + "..";
        float tw = f.width(cut) * SMALL_SCALE;
        g.pose().pushPose();
        g.pose().translate(x - tw / 2f, y + (1 - SMALL_SCALE) * 4f, 0);
        g.pose().scale(SMALL_SCALE, SMALL_SCALE, 1f);
        CuteFont.draw(g, f, cut, 0, 0, color, false);
        g.pose().popPose();
    }

    protected static void rect(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + h, argb);
    }

    /** A filled rectangle with rounded corners (radius r). */
    public static void roundRect(GuiGraphics g, int x, int y, int w, int h, int r, int argb) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int dy = 0; dy < h; dy++) {
            double m = dy + 0.5;
            double e = m < r ? r - m : m > h - r ? m - (h - r) : 0;
            int inset = e > 0 ? (int) Math.round(r - Math.sqrt(Math.max(0, r * r - e * e))) : 0;
            g.fill(x + inset, y + dy, x + w - inset, y + dy + 1, argb);
        }
    }

    protected static void disc(GuiGraphics g, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.floor(Math.sqrt(r * r - dy * dy + 0.25));
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    protected static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && py >= y && px < x + w && py < y + h;
    }

    /** Blend an rgb color toward another one (f = 0..1). Result is opaque ARGB. */
    public static int mix(int rgb, int target, float f) {
        int r = (int) (((rgb >> 16) & 255) * (1 - f) + ((target >> 16) & 255) * f);
        int gr = (int) (((rgb >> 8) & 255) * (1 - f) + ((target >> 8) & 255) * f);
        int b = (int) ((rgb & 255) * (1 - f) + (target & 255) * f);
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }
}
