package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

import static dev.cutemod.client.os.App.rect;

/** The trips screen of the Tamagotchi app: pick a place to send the pet to, and the album of the things it found. */
final class PetTrip {
    private static final int W = App.W, H = App.H, HEAD = 17, ROW = 24;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;

    private final Runnable back;
    private final IntConsumer go;
    private final Supplier<String> blocker;       // "" if the pet can leave, else the reason (a lang key)
    private final IntSupplier stage;
    private final PetShelf shelf = new PetShelf();
    private int tab, ticks, scroll, lastRender = -100;
    private static final int VISIBLE = 6;

    PetTrip(Runnable back, IntConsumer go, Supplier<String> blocker, IntSupplier stage) {
        this.back = back;
        this.go = go;
        this.blocker = blocker;
        this.stage = stage;
    }

    private static String t(String key, Object... a) { return Component.translatable(key, a).getString(); }

    void tick() {
        ticks++;
        if (ticks - lastRender < 5) GameMusic.keep("trips", false);    // the travel tune, only while the trips screen is on screen
    }

    /** The places that can be visited now (the first 6, plus those of the installed updates). */
    private static java.util.List<Integer> open() {
        java.util.List<Integer> l = new java.util.ArrayList<>();
        for (int d = 0; d < Trip.DESTS; d++) if (Updates.placeOpen(d)) l.add(d);
        return l;
    }

    /** The places that open by play or by an event and are still locked: they are shown greyed, with what is needed. */
    private static java.util.List<Integer> locked() {
        java.util.List<Integer> l = new java.util.ArrayList<>();
        for (int d = PlaceUnlock.FIRST; d < Trip.DESTS; d++) if (!PlaceUnlock.open(d) && !PlaceUnlock.hidden(d)) l.add(d);
        return l;
    }

    /** The place of the next update (a row with a question mark), or -1. */
    private static int teaser() {
        int a = Updates.available();
        Updates.Update u = a >= 0 ? Updates.ALL.get(a) : Updates.upcoming();
        return u == null ? -1 : u.place();
    }

    private boolean ready(int d) { return stage.getAsInt() >= Trip.NEED[d] && blocker.get().isEmpty(); }

    void render(GuiGraphics g, int mx, int my) {
        lastRender = ticks;
        Font f = net.minecraft.client.Minecraft.getInstance().font;
        Skin.rect(g, 0, 0, W, H, 0xFFF6F0FA);
        Skin.rect(g, 0, 0, W, HEAD, 0xFF5A4A86);
        tabBtn(g, f, mx, my, 54, 46, "cutemod.trip.tab.go", tab == 0);
        tabBtn(g, f, mx, my, 102, 50, "cutemod.trip.tab.album", tab == 1);
        tabBtn(g, f, mx, my, 154, 46, "cutemod.trip.tab.shelf", tab == 2);
        if (tab == 1) {
            String n = Trip.albumCount() + "/" + Trip.albumSize();
            Skin.str(g, f, n, W - 6 - f.width(n), 5, 0xFFE4D8FF, false);
        } else if (tab == 2) {
            String n = PetShelf.placed() + "/" + PetShelf.SLOTS;
            Skin.str(g, f, n, W - 6 - f.width(n), 5, 0xFFE4D8FF, false);
        } else {
            String why = blocker.get();
            if (!why.isEmpty()) Skin.str(g, f, f.plainSubstrByWidth(t(why), W - 210), 206, 5, 0xFFFFD0D0, false);
        }
        if (tab == 2) { shelf.render(g, f, mx, my, ticks); return; }
        java.util.List<Integer> list = open();
        int tz = teaser();
        java.util.List<Integer> lock = tab == 0 ? locked() : java.util.List.of();       // the album shows only the open places
        int total = list.size() + lock.size() + (tz >= 0 ? 1 : 0);
        scroll = Math.max(0, Math.min(Math.max(0, total - VISIBLE), scroll));
        for (int i = 0; i < VISIBLE && i + scroll < total; i++) {
            int y = HEAD + 1 + i * ROW;
            Skin.rect(g, 3, y, W - 6, ROW - 1, 0xFFFFFFFF);
            int idx = i + scroll;
            if (idx >= list.size() + lock.size()) { teaserRow(g, f, y); continue; }
            if (idx >= list.size()) { lockedRow(g, f, lock.get(idx - list.size()), y); continue; }
            int d = list.get(idx);
            TripArt.scene(g, 6, y + 2, 28, 19, d, ticks);
            Skin.str(g, f, t("cutemod.trip.dest." + d), 40, y + 3, TEXT, false);
            if (tab == 0) goRow(g, f, mx, my, d, y); else albumRow(g, f, d, y);
        }
        if (total > VISIBLE) {                                             // a thin scroll bar
            int th = Math.max(8, (H - HEAD) * VISIBLE / total);
            Skin.rect(g, W - 2, HEAD + (H - HEAD - th) * scroll / Math.max(1, total - VISIBLE), 2, th, ACCENT);
        }
    }

    /** A place that is still locked: its picture is faded, a padlock on it, the name, what is needed and a progress bar. */
    private void lockedRow(GuiGraphics g, Font f, int d, int y) {
        TripArt.scene(g, 6, y + 2, 28, 19, d, 0);
        g.fill(6, y + 2, 34, y + 21, 0xC8F2ECF8);
        int cx = 20, cy = y + 12;                                               // a little padlock
        Skin.rect(g, cx - 3, cy - 1, 7, 6, 0xFF8A7AA8);
        Skin.rect(g, cx - 3, cy - 1, 7, 1, 0xFFB8A8D8);
        Skin.rect(g, cx - 2, cy - 5, 1, 4, 0xFF8A7AA8); Skin.rect(g, cx + 2, cy - 5, 1, 4, 0xFF8A7AA8); Skin.rect(g, cx - 1, cy - 5, 3, 1, 0xFF8A7AA8);
        Skin.rect(g, cx, cy + 1, 1, 2, 0xFFF2ECF8);
        Skin.str(g, f, t("cutemod.trip.dest." + d), 40, y + 3, MUTED, false);
        String hint = t("cutemod.trip.lock." + d, PlaceUnlock.progress(d));
        Skin.str(g, f, f.plainSubstrByWidth(hint, PlaceUnlock.isEvent(d) ? W - 50 : W - 120), 40, y + 13, 0xFFB8A8D8, false);
        if (!PlaceUnlock.isEvent(d)) {
            int bw = 60, fill = bw * Math.min(PlaceUnlock.have(d), PlaceUnlock.target(d)) / PlaceUnlock.target(d);
            Skin.rect(g, W - 66, y + 9, bw, 6, 0xFFE4D8F0);
            Skin.rect(g, W - 66, y + 9, fill, 6, 0xFFB57BD6);
            Skin.rect(g, W - 66, y + 9, fill, 1, 0xFFD4B0F0);
        }
    }

    /** A grey row for the place that the next update brings. */
    private void teaserRow(GuiGraphics g, Font f, int y) {
        Skin.rect(g, 6, y + 2, 28, 19, 0xFFD8CCE2);
        Skin.str(g, f, "?", 18, y + 8, 0xFFFFFFFF, false);
        Skin.str(g, f, "???", 40, y + 3, MUTED, false);
        int a = Updates.available();
        String line = a >= 0
                ? t("cutemod.trip.teaser.ready", t("cutemod.update." + Updates.ALL.get(a).id() + ".name"))
                : t("cutemod.trip.teaser.soon", t("cutemod.update." + Updates.upcoming().id() + ".name"), Updates.upcoming().date().toString());
        Skin.str(g, f, f.plainSubstrByWidth(line, W - 50), 40, y + 13, MUTED, false);
    }

    private void goRow(GuiGraphics g, Font f, int mx, int my, int d, int y) {
        boolean young = stage.getAsInt() < Trip.NEED[d];
        String sub = young ? t("cutemod.trip.needs." + Trip.NEED[d]) : t("cutemod.trip.takes");
        Skin.str(g, f, sub, 40, y + 13, young ? 0xFFD9302A : MUTED, false);
        boolean ok = ready(d), hov = ok && App.in(mx, my, W - 66, y + 4, 60, 15);
        Skin.rect(g, W - 66, y + 4, 60, 15, !ok ? 0xFFD8CCE2 : hov ? 0xFFFFD866 : 0xFFFFC832);
        String s = t("cutemod.trip.go");
        Skin.str(g, f, s, W - 36 - f.width(s) / 2, y + 8, ok ? TEXT : 0xFFFFFFFF, false);
    }

    private void albumRow(GuiGraphics g, Font f, int d, int y) {
        for (int k = 0; k < Trip.FINDS; k++) {
            int x = 40 + k * 64;
            boolean got = Trip.found(d, k);
            Skin.rect(g, x, y + 12, 62, 10, got ? 0xFFE4F5E8 : 0xFFEFE8F5);
            String s = got ? f.plainSubstrByWidth(t("cutemod.trip.find." + d + "." + k), 58) : "?";
            Skin.str(g, f, s, x + 2, y + 13, got ? 0xFF2E6B3A : 0xFFB8A8D8, false);
        }
    }

    private void tabBtn(GuiGraphics g, Font f, int mx, int my, int x, int w, String key, boolean on) {
        boolean hov = App.in(mx, my, x, 2, w, 13);
        Skin.rect(g, x, 2, w, 13, on ? 0xFFF6F0FA : hov ? 0xFF8A6AC6 : 0xFF6E5CA0);
        String s = t(key);
        Skin.str(g, f, s, x + (w - f.width(s)) / 2, 5, on ? TEXT : 0xFFFFFFFF, false);
    }

    boolean click(int mx, int my, int button) {
        if (App.in(mx, my, 54, 2, 46, 13)) { tab = 0; return true; }
        if (App.in(mx, my, 102, 2, 50, 13)) { tab = 1; return true; }
        if (App.in(mx, my, 154, 2, 46, 13)) { tab = 2; return true; }
        if (tab == 2) return shelf.click(mx, my, button);
        if (tab == 0) {
            java.util.List<Integer> list = open();
            for (int i = 0; i < VISIBLE && i + scroll < list.size(); i++) {
                int d = list.get(i + scroll);
                if (App.in(mx, my, W - 66, HEAD + 1 + i * ROW + 4, 60, 15) && ready(d)) { go.accept(d); return true; }
            }
        }
        return true;
    }

    boolean scroll(double amount) {
        if (tab == 2) return true;
        scroll -= (int) Math.signum(amount);
        return true;
    }

    boolean key(int keyCode) {
        if (keyCode == 256) { back.run(); return true; }
        return false;
    }
}
