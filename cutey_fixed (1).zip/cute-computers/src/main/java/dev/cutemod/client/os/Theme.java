package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The look of the desktop chrome (menu bar, window title bars, the Dock and a soft overlay on the wallpaper).
 * The classic look is the default. <b>Frutiger Aero</b> (glossy blue glass, bubbles, a bright sky glow) is bought
 * in CuteMarket > Style for {@link #AERO_PRICE} coins and can be switched back to classic at any time.
 * <b>Kawaii Pastel</b> (candy pink glass, bows, floating hearts and stars, a music-box startup tune) is the second one.
 * <b>Retro 98</b> (grey bevelled buttons, navy title bars, a black and white arrow, beeps and a chip-tune startup) is the third one.
 * The chosen look is saved on the server under the name "theme" ("aero", "kawaii", "retro" or empty = classic, like the wallpaper).
 */
public final class Theme {
    public static final String AERO_ID = "theme_aero";
    public static final int AERO_PRICE = 120;

    public static final String KAWAII_ID = "theme_kawaii";
    public static final int KAWAII_PRICE = 120;
    public static final String RETRO_ID = "theme_retro98";
    public static final int RETRO_PRICE = 120;
    public static final String ANIME_ID = "theme_anime";
    public static final int ANIME_PRICE = 150;
    /** "Blood": the crimson look of the video 666 for good. It appears in the shop only after the secret of the video 666 (see {@link #bloodUnlocked}). */
    public static final String BLOOD_ID = "theme_blood";
    public static final int BLOOD_PRICE = 666;
    /** "The Stranger": a deep violet night with gold stars. The prize of the big easter egg (see {@link Traces}); not for sale. */
    public static final String STRANGER_ID = "theme_stranger";

    private static String cur = "";
    private static int gen = -1;

    private Theme() {}

    /** True when the Aero look is on (it must be bought first). */
    public static boolean aero() { return load().equals("aero") && Progress.owned(AERO_ID); }

    /** True when the Kawaii Pastel look is on (it must be bought first). */
    public static boolean kawaii() { return load().equals("kawaii") && Progress.owned(KAWAII_ID); }

    /** True when any look other than the classic one is on. */
    /** True when the Retro 98 look is on (it must be bought first). */
    public static boolean retro() { return load().equals("retro") && Progress.owned(RETRO_ID); }

    /** True when the Anime Sakura look is on (it must be bought first). */
    public static boolean anime() { return load().equals("anime") && Progress.owned(ANIME_ID); }

    /** True while the crimson look of the video 666 is on (temporary, see {@link Hell}); it beats every other look. */
    public static boolean hell() { return Hell.active(); }

    /** True when the bought look "Blood" is on (the temporary one after the video is {@link Hell#timed}). */
    public static boolean bloodTheme() { return load().equals("blood") && Progress.owned(BLOOD_ID); }

    /** True when the prize look "The Stranger" is on (it is owned after the phrase was said in the Terminal). */
    public static boolean stranger() { return load().equals("stranger") && Progress.owned(STRANGER_ID); }

    /** The theme is sold only to those who found the secret: watched the video 666 to the end or paused it at second 66 (or already own it). */
    public static boolean bloodUnlocked() { return Progress.owned(BLOOD_ID) || Progress.count("hell_watch") > 0 || Progress.count("hell_66") > 0; }

    /** The name of the look that is on ("anime", "aero", "kawaii", "retro", "hell", "blood") or "" for the classic one. */
    public static String key() { return hell() ? "hell" : anime() ? "anime" : aero() ? "aero" : kawaii() ? "kawaii" : retro() ? "retro" : bloodTheme() ? "blood" : stranger() ? "stranger" : ""; }

    public static boolean custom() { return hell() || aero() || kawaii() || retro() || anime() || stranger(); }

    private static String load() {
        if (gen != Store.gen()) {
            gen = Store.gen();
            String s = Store.read("theme");
            cur = s == null ? "" : s.trim();
        }
        return cur;
    }

    public static void setAero(boolean on) { set("aero", on); }

    public static void setKawaii(boolean on) { set("kawaii", on); }

    public static void setRetro(boolean on) { set("retro", on); }

    public static void setAnime(boolean on) { set("anime", on); }

    public static void setBlood(boolean on) { set("blood", on); }

    public static void setStranger(boolean on) { set("stranger", on); }

    /** Switch a look on (it replaces the other one) or off (back to classic, only if it is the one that is on). */
    private static void set(String name, boolean on) {
        load();
        if (on) cur = name;
        else if (cur.equals(name)) cur = "";
        Store.write("theme", cur);
    }

    /** True if the shop item of this id is the look that is on now. */
    public static boolean active(String id) { return id.equals(STRANGER_ID) ? stranger() : id.equals(BLOOD_ID) ? bloodTheme() : id.equals(ANIME_ID) ? anime() : id.equals(AERO_ID) ? aero() : id.equals(KAWAII_ID) ? kawaii() : id.equals(RETRO_ID) && retro(); }

    public static void setById(String id, boolean on) {
        if (id.equals(AERO_ID)) setAero(on); else if (id.equals(KAWAII_ID)) setKawaii(on); else if (id.equals(RETRO_ID)) setRetro(on); else if (id.equals(ANIME_ID)) setAnime(on); else if (id.equals(BLOOD_ID)) setBlood(on); else if (id.equals(STRANGER_ID)) setStranger(on);
    }

    /** Colour of the window title text. */
    public static int titleText() { return hell() ? Hell.PALE : stranger() ? 0xFFEDE6FF : anime() ? 0xFF5A2A6A : aero() ? 0xFF14405E : kawaii() ? 0xFF8A3C6A : retro() ? 0xFFFFFFFF : 0xFF3A2A3A; }

    // ---------- the chrome ----------

    /** Blue glass menu bar: a gradient, a bright top edge and a shine on the upper half. (Kawaii: candy pink with a lace edge.) */
    public static void menuBar(GuiGraphics g, int x, int y, int w, int h) {
        if (hell()) { Hell.menuBar(g, x, y, w, h); return; }
        if (stranger()) { strangerBar(g, x, y, w, h); return; }
        if (anime()) { animeMenuBar(g, x, y, w, h); return; }
        if (retro()) {
            g.fillGradient(x, y, x + w, y + h, 0xFF000080, 0xFF1084D0);
            g.fill(x, y, x + w, y + 1, 0xFFFFFFFF);
            g.fill(x, y + h - 1, x + w, y + h, 0xFF404040);
            return;
        }
        if (kawaii()) {
            g.fillGradient(x, y, x + w, y + h, 0xEEFFA6D0, 0xEEF579B4);
            g.fill(x, y + 1, x + w, y + 1 + h / 2, 0x30FFFFFF);
            g.fill(x, y, x + w, y + 1, 0xCCFFFFFF);
            for (int px = x + 2; px < x + w - 2; px += 6) {                                   // a lace of little white scallops
                g.fill(px, y + h - 2, px + 4, y + h - 1, 0xDDFFFFFF);
                g.fill(px + 1, y + h - 1, px + 3, y + h, 0xDDFFFFFF);
            }
            return;
        }
        g.fillGradient(x, y, x + w, y + h, 0xDD3A9BE8, 0xDD1F6FC4);
        g.fill(x, y + 1, x + w, y + 1 + h / 2, 0x2AFFFFFF);
        g.fill(x, y, x + w, y + 1, 0xAAFFFFFF);
        g.fill(x, y + h - 1, x + w, y + h, 0x99124F8F);
    }

    /** Glossy light-blue window title bar. (Kawaii: cream pink, a stitched line and a bow.) */
    public static void titleBar(GuiGraphics g, int x, int y, int w, int h) {
        if (hell()) { Hell.titleBar(g, x, y, w, h); return; }
        if (stranger()) { strangerBar(g, x, y, w, h); return; }
        if (anime()) { animeTitleBar(g, x, y, w, h); return; }
        if (retro()) {
            g.fillGradient(x, y, x + w, y + h, 0xFF000080, 0xFF1084D0);
            g.fill(x, y, x + w, y + 1, 0xFFC0C0C0);
            g.fill(x, y + h - 1, x + w, y + h, 0xFF404040);
            return;
        }
        if (kawaii()) {
            g.fillGradient(x, y, x + w, y + h, 0xFFFFF6FB, 0xFFFFD2E7);
            g.fill(x, y, x + w, y + 1, 0xFFFFFFFF);
            g.fill(x, y + h - 1, x + w, y + h, 0xFFF29BC4);
            for (int px = x + 3; px < x + w - 3; px += 4) g.fill(px, y + h - 3, px + 2, y + h - 2, 0xFFFFFFFF);   // stitches
            bow(g, x + w - 15, y + Math.max(1, h / 2 - 3));
            return;
        }
        g.fillGradient(x, y, x + w, y + h, 0xFFEAF7FF, 0xFFA5D4F2);
        g.fill(x, y + 1, x + w, y + 1 + h / 2, 0x33FFFFFF);
        g.fill(x, y, x + w, y + 1, 0xFFFFFFFF);
        g.fill(x, y + h - 1, x + w, y + h, 0xFF5FA6D8);
    }

    /** The two layers of the Dock pill in Aero: a pale rim and a glossy blue body with a shine on top. */
    public static void dockPill(GuiGraphics g, int x0, int y0, int x1, int y1) {
        if (hell()) { Hell.dockPill(g, x0, y0, x1, y1); return; }
        if (stranger()) {                                                               // a violet night glass with a pale rim
            Dock.pill(g, x0 - 1, y0 - 1, x1 + 1, y1 + 1, 0x88B79CFF);
            Dock.pill(g, x0, y0, x1, y1, 0xD01A1240);
            Dock.pill(g, x0 + 1, y0 + 1, x1 - 1, y0 + Math.max(4, (y1 - y0) / 2), 0x22B79CFF);
            return;
        }
        if (anime()) {                                                                  // candy pink glass with a white rim
            Dock.pill(g, x0 - 1, y0 - 1, x1 + 1, y1 + 1, 0x99FFFFFF);
            Dock.pill(g, x0, y0, x1, y1, 0xB0D468B4);
            Dock.pill(g, x0 + 1, y0 + 1, x1 - 1, y0 + Math.max(4, (y1 - y0) / 2), 0x44FFFFFF);
            return;
        }
        if (retro()) {                                              // a grey taskbar panel with raised edges
            g.fill(x0 - 2, y0 - 2, x1 + 2, y1 + 2, 0xFF000000);
            g.fill(x0 - 1, y0 - 1, x1 + 1, y1 + 1, 0xFFC0C0C0);
            g.fill(x0 - 1, y0 - 1, x1 + 1, y0, 0xFFFFFFFF);
            g.fill(x0 - 1, y0 - 1, x0, y1 + 1, 0xFFFFFFFF);
            g.fill(x0 - 1, y1, x1 + 1, y1 + 1, 0xFF808080);
            g.fill(x1, y0 - 1, x1 + 1, y1 + 1, 0xFF808080);
            return;
        }
        if (kawaii()) {
            Dock.pill(g, x0 - 1, y0 - 1, x1 + 1, y1 + 1, 0xAAFFFFFF);
            Dock.pill(g, x0, y0, x1, y1, 0xAAF98EC0);
            Dock.pill(g, x0 + 1, y0 + 1, x1 - 1, y0 + Math.max(4, (y1 - y0) / 2), 0x55FFFFFF);
            return;
        }
        Dock.pill(g, x0 - 1, y0 - 1, x1 + 1, y1 + 1, 0x77FFFFFF);
        Dock.pill(g, x0, y0, x1, y1, 0xAA2F8FD8);
        Dock.pill(g, x0 + 1, y0 + 1, x1 - 1, y0 + Math.max(4, (y1 - y0) / 2), 0x44FFFFFF);
    }

    // ---------- the overlay on the wallpaper ----------

    /** A sky glow and slowly rising soap bubbles over the wallpaper (drawn before the windows). */
    public static void overlay(GuiGraphics g, int x, int y, int w, int h) {
        if (hell()) { Hell.overlay(g, x, y, w, h); return; }
        if (stranger()) { strangerOverlay(g, x, y, w, h); return; }
        if (anime()) { animeOverlay(g, x, y, w, h); return; }
        int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        g.enableScissor(x, y, x + w, y + h);      // the overlay is drawn with the plain screen pose, so the scissor is right here
        if (retro()) {                            // a faint teal tint and the lines of an old monitor
            g.fill(x, y, x + w, y + h, 0x14008080);
            for (int ly = y + 1; ly < y + h; ly += 2) g.fill(x, ly, x + w, ly + 1, 0x12000000);
            g.disableScissor();
            return;
        }
        if (kawaii()) {                           // a pink haze and little hearts and stars floating up
            g.fillGradient(x, y, x + w, y + h * 40 / 100, 0x44FFE0F0, 0x00FFE0F0);
            g.fillGradient(x, y + h * 70 / 100, x + w, y + h, 0x00FFB6DA, 0x33FFB6DA);
            int[] cols = {0xBBFF8CBC, 0xBBFFD84D, 0xBBB79CFF, 0xBB8FE8D6, 0xBBFFFFFF};
            for (int i = 0; i < 14; i++) {
                int size = 3 + i % 3;
                int rise = (t * (1 + i % 3) / 4 + i * 53) % (h + size * 4);
                int cy = y + h + size * 2 - rise;
                int cx = x + size + (i * 71 + 17) % Math.max(1, w - size * 2) + (int) (Math.sin(t * 0.05 + i) * 5);
                if (i % 2 == 0) heart(g, cx, cy, cols[i % cols.length]); else sparkle(g, cx, cy, size, cols[i % cols.length]);
            }
            g.disableScissor();
            return;
        }
        g.fillGradient(x, y, x + w, y + h * 45 / 100, 0x55FFFFFF, 0x00FFFFFF);
        for (int i = 0; i < 10; i++) {
            int rad = 3 + (i * 5) % 9;
            int rise = (t * (1 + i % 3) / 3 + i * 47) % (h + rad * 4);
            int cy = y + h + rad * 2 - rise;
            int cx = x + rad + (i * 83 + 20) % Math.max(1, w - rad * 2) + (int) (Math.sin(t * 0.04 + i) * 4);
            bubble(g, cx, cy, rad);
        }
        g.disableScissor();
    }

    /**
     * Quiet particles for the inside of an app window (the music player uses it): Aero soap bubbles, Kawaii hearts and
     * stars, Anime sakura petals and sparkles. Classic, Retro and the crimson looks get nothing.
     * x, y, w, h are in the caller's own coordinates; the caller sets the scissor (see MusicApp.render).
     */
    public static void ambient(GuiGraphics g, int x, int y, int w, int h) {
        if (hell()) return;
        int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        int ww = Math.max(1, w);
        if (stranger()) {                                                               // a few gold and white stars drift up
            for (int i = 0; i < 6; i++) {
                int rise = (t * (1 + i % 3) / 6 + i * 43) % (h + 8);
                int cx = x + Math.floorMod(i * 89 + 11 + (int) (Math.sin(t * 0.04 + i) * 4), ww);
                strangerStar(g, cx, y + h - rise, 1 + i % 2, i % 2 == 0 ? 0x99FFD866 : 0x88FFFFFF);
            }
            return;
        }
        if (anime()) {
            for (int i = 0; i < 8; i++) {
                int fall = (t * (2 + i % 3) / 5 + i * 41) % (h + 16);
                int cy = y - 8 + fall;
                int cx = x + Math.floorMod((i * 97 + 13) + fall * 35 / 100 + (int) (Math.sin(t * 0.05 + i) * 5), ww);
                petal(g, cx, cy, i);
            }
            for (int j = 0; j < 4; j++) {
                int ph = (t + j * 37) % 70, cyc = (t + j * 37) / 70;
                int r = ph < 10 ? ph / 4 : ph < 20 ? (20 - ph) / 4 : 0;
                if (r <= 0) continue;
                animeStar(g, x + hash(cyc * 7 + j * 13) % ww, y + hash(cyc * 11 + j * 5 + 3) % Math.max(1, h), r, j % 2 == 0 ? 0xC0FFFFFF : 0xC0FFF27A);
            }
        } else if (kawaii()) {
            int[] cols = {0x99FF8CBC, 0x99FFD84D, 0x99B79CFF, 0x998FE8D6, 0x99FFFFFF};
            for (int i = 0; i < 9; i++) {
                int size = 3 + i % 3;
                int rise = (t * (1 + i % 3) / 5 + i * 53) % (h + size * 4);
                int cy = y + h + size * 2 - rise;
                int cx = x + size + (i * 71 + 17) % Math.max(1, w - size * 2) + (int) (Math.sin(t * 0.05 + i) * 5);
                if (i % 2 == 0) heart(g, cx, cy, cols[i % cols.length]); else sparkle(g, cx, cy, size, cols[i % cols.length]);
            }
        } else if (aero()) {
            for (int i = 0; i < 7; i++) {
                int rad = 3 + (i * 5) % 8;
                int rise = (t * (1 + i % 3) / 4 + i * 47) % (h + rad * 4);
                int cy = y + h + rad * 2 - rise;
                int cx = x + rad + (i * 83 + 20) % Math.max(1, w - rad * 2) + (int) (Math.sin(t * 0.04 + i) * 4);
                bubble(g, cx, cy, rad);
            }
        }
    }

    /** A tiny pink bow (9 x 6). */
    private static void bow(GuiGraphics g, int x, int y) {
        g.fill(x, y, x + 4, y + 5, 0xFFFF7CB4);
        g.fill(x + 5, y, x + 9, y + 5, 0xFFFF7CB4);
        g.fill(x + 1, y + 1, x + 3, y + 2, 0xFFFFC4DE);
        g.fill(x + 6, y + 1, x + 8, y + 2, 0xFFFFC4DE);
        g.fill(x + 3, y + 1, x + 6, y + 4, 0xFFE0508C);
    }

    private static void heart(GuiGraphics g, int cx, int cy, int argb) {
        g.fill(cx - 2, cy - 2, cx, cy - 1, argb);
        g.fill(cx + 1, cy - 2, cx + 3, cy - 1, argb);
        g.fill(cx - 3, cy - 1, cx + 4, cy + 1, argb);
        g.fill(cx - 2, cy + 1, cx + 3, cy + 2, argb);
        g.fill(cx - 1, cy + 2, cx + 2, cy + 3, argb);
        g.fill(cx, cy + 3, cx + 1, cy + 4, argb);
    }

    /** A four-pointed sparkle. */
    private static void sparkle(GuiGraphics g, int cx, int cy, int size, int argb) {
        g.fill(cx - size, cy, cx + size + 1, cy + 1, argb);
        g.fill(cx, cy - size, cx + 1, cy + size + 1, argb);
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, argb);
    }

    private static void bubble(GuiGraphics g, int cx, int cy, int rad) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            int inner = Math.abs(dy) >= rad - 1 ? -1 : (int) Math.floor(Math.sqrt((rad - 1) * (rad - 1) - dy * dy + 0.25));
            if (inner < 0) {
                g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, 0x77FFFFFF);
            } else {
                g.fill(cx - dx, cy + dy, cx - inner, cy + dy + 1, 0x77FFFFFF);       // the rim
                g.fill(cx - inner, cy + dy, cx + inner + 1, cy + dy + 1, 0x1CFFFFFF);  // the thin glass inside
                g.fill(cx + inner + 1, cy + dy, cx + dx + 1, cy + dy + 1, 0x77FFFFFF);
            }
        }
        g.fill(cx - rad / 2, cy - rad / 2, cx - rad / 2 + 2, cy - rad / 2 + 2, 0xCCFFFFFF);   // the highlight
    }

    // ---------- Anime Sakura ----------

    private static int fade(int argb, int num, int den) {
        int a = (argb >>> 24) * num / den;
        return (a << 24) | (argb & 0xFFFFFF);
    }

    private static int hash(int n) {
        n ^= n >>> 15; n *= 0x2C1B3C6D; n ^= n >>> 12; n *= 0x297A2D39; n ^= n >>> 15;
        return n & 0x7FFFFFFF;
    }

    /** A four-point star: a bright centre and four arms of r pixels that fade towards the tips. */
    static void animeStar(GuiGraphics g, int cx, int cy, int r, int argb) {
        g.fill(cx, cy, cx + 1, cy + 1, argb);
        for (int k = 1; k <= r; k++) {
            int c = fade(argb, r - k + 1, r + 1);
            g.fill(cx - k, cy, cx - k + 1, cy + 1, c);
            g.fill(cx + k, cy, cx + k + 1, cy + 1, c);
            g.fill(cx, cy - k, cx + 1, cy - k + 1, c);
            g.fill(cx, cy + k, cx + 1, cy + k + 1, c);
        }
    }

    /** Candy pink to violet menu bar with a shine, a pale lower edge and a few quietly twinkling stars (under the text). */
    private static void animeMenuBar(GuiGraphics g, int x, int y, int w, int h) {
        g.fillGradient(x, y, x + w, y + h, 0xEEF06AA8, 0xEEA65AD8);
        g.fill(x, y + 1, x + w, y + 1 + h / 2, 0x2AFFFFFF);
        g.fill(x, y, x + w, y + 1, 0xAAFFFFFF);
        g.fill(x, y + h - 1, x + w, y + h, 0xFFFFC4E4);
        int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        for (int i = 0; i < 5; i++) {
            if ((t + i * 17) % 40 >= 6) continue;
            animeStar(g, x + w * (i * 2 + 3) / 13, y + h / 2, 1, 0x77FFFFFF);
        }
    }

    /** Pale sakura title bar: a white top edge, a pink lower edge and manga screentone dots that fade out towards the middle. */
    private static void animeTitleBar(GuiGraphics g, int x, int y, int w, int h) {
        g.fillGradient(x, y, x + w, y + h, 0xFFFFF4FA, 0xFFFFC6E2);
        g.fill(x, y + 1, x + w, y + 1 + h / 2, 0x33FFFFFF);
        g.fill(x, y, x + w, y + 1, 0xFFFFFFFF);
        g.fill(x, y + h - 1, x + w, y + h, 0xFFE878B4);
        for (int c = 0; c < 16; c++) {
            int al = 0x66 * (16 - c) / 16;
            if (al < 8) continue;
            int col = (al << 24) | 0xE8629E;
            int dx = c * 3, off = 1 + (c & 1) * 2;
            for (int dy = off; dy < h - 2; dy += 4) {
                g.fill(x + 40 + dx, y + dy, x + 41 + dx, y + dy + 1, col);
                g.fill(x + w - 5 - dx, y + dy, x + w - 4 - dx, y + dy + 1, col);
            }
        }
    }

    /** A warm sakura glow, a lavender haze, screentone corners, falling petals and twinkling sparkles over the wallpaper. */
    private static void animeOverlay(GuiGraphics g, int x, int y, int w, int h) {
        int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        g.enableScissor(x, y, x + w, y + h);
        g.fillGradient(x, y, x + w, y + h * 40 / 100, 0x44FFC6E4, 0x00FFC6E4);
        g.fillGradient(x, y + h * 70 / 100, x + w, y + h, 0x00B48CFF, 0x33B48CFF);
        for (int ry = 0; ry < 10; ry++) {                                              // screentone in the two lower corners
            for (int rx = 0; rx < 14 - ry; rx++) {
                if (((rx + ry) & 1) != 0) continue;
                int c = ((0x60 * (14 - rx - ry) / 14) << 24) | 0xFFFFFF;
                int py = y + h - 4 - ry * 3;
                g.fill(x + 2 + rx * 3, py, x + 3 + rx * 3, py + 1, c);
                g.fill(x + w - 3 - rx * 3, py, x + w - 2 - rx * 3, py + 1, c);
            }
        }
        int ww = Math.max(1, w);
        for (int i = 0; i < 14; i++) {                                                 // sakura petals drifting down and to the side
            int fall = (t * (2 + i % 3) / 4 + i * 61) % (h + 16);
            int cy = y - 8 + fall;
            int cx = x + Math.floorMod((i * 97 + 13) + fall * 35 / 100 + (int) (Math.sin(t * 0.05 + i) * 5), ww);
            petal(g, cx, cy, i);
        }
        for (int j = 0; j < 7; j++) {                                                  // sparkles that pop up at a new place each time
            int ph = (t + j * 29) % 60, cyc = (t + j * 29) / 60;
            int r = ph < 10 ? ph / 4 : ph < 20 ? (20 - ph) / 4 : 0;
            if (r <= 0) continue;
            int px = x + hash(cyc * 7 + j * 13) % ww, py = y + hash(cyc * 11 + j * 5 + 3) % Math.max(1, h * 3 / 4);
            animeStar(g, px, py, r, j % 2 == 0 ? 0xF0FFFFFF : 0xF0FFF27A);
        }
        g.disableScissor();
    }

    private static void petal(GuiGraphics g, int cx, int cy, int i) {
        int base = 0xCCFFB3D1, light = 0xCCFFD9E8;
        boolean left = (i & 1) == 0;
        if (i % 4 == 0) {                                                              // a bigger one
            g.fill(cx + 1, cy, cx + 4, cy + 1, light);
            g.fill(cx, cy + 1, cx + 4, cy + 3, base);
            g.fill(cx + (left ? 0 : 1), cy + 3, cx + (left ? 3 : 4), cy + 4, 0xCCFF9AC2);
        } else if (left) {
            g.fill(cx + 1, cy, cx + 3, cy + 1, light);
            g.fill(cx, cy + 1, cx + 3, cy + 2, base);
            g.fill(cx, cy + 2, cx + 2, cy + 3, base);
        } else {
            g.fill(cx, cy, cx + 2, cy + 1, light);
            g.fill(cx, cy + 1, cx + 3, cy + 2, base);
            g.fill(cx + 1, cy + 2, cx + 3, cy + 3, base);
        }
    }

    /** The Anime cursor: a white and pink arrow with a plum outline, a twinkling yellow star beside it and a ring of petals while busy. */
    private static void cursorAnime(GuiGraphics g, int mx, int my, boolean busy) {
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                int argb = c == 'B' ? 0xFF7A2C6E : (col < 3 ? 0xFFFFFFFF : row < 8 ? 0xFFFFD1EA : 0xFFFF8CC8);
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, argb);
            }
        }
        int r = 1 + (int) Math.round(Math.sin(System.currentTimeMillis() / 160.0) + 1);       // 1..3
        animeStar(g, mx + 14, my + 3, r, 0xFFFFE86A);
        g.fill(mx + 14, my + 3, mx + 15, my + 4, 0xFFFFFFFF);
        if (busy) {
            long k = System.currentTimeMillis() / 90L;
            for (int i = 0; i < 6; i++) {
                double a = i * Math.PI / 3 + k * 0.3;
                int px = mx + 15 + (int) Math.round(Math.cos(a) * 5), py = my + 17 + (int) Math.round(Math.sin(a) * 5);
                g.fill(px, py, px + 2, py + 2, i % 2 == 0 ? 0xFFFF8CC8 : 0xFFFFE86A);
            }
        }
        g.pose().popPose();
    }

    // ---------- the mouse cursor ----------
    private static final String[] ARROW = {
            "B..........", "BB.........", "BwB........", "BwwB.......", "BwwwB......", "BwwwwB.....",
            "BwwwwwB....", "BwwwwwwB...", "BwwwwwwwB..", "BwwwwwwwwB.", "BwwwwwBBBBB", "BwwBwwB....",
            "BwB.BwwB...", "BB..BwwB...", "B....BwwB..", ".....BwwB..", "......BB..."};

    private static final String[] HEART = {".X.X.", "XXXXX", "XXXXX", ".XXX.", "..X.."};

    /**
     * The classic look's cursor: a soft pink arrow with a plum outline and a white shine, and a tiny heart
     * that bobs next to it. The hot spot is the top-left pixel, like every arrow.
     */
    public static void cursorClassic(GuiGraphics g, int mx, int my) {
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                int argb = c == 'B' ? 0xFF5A2A4A : (col < 3 ? 0xFFFFF3F8 : row < 8 ? 0xFFFFC4DE : 0xFFFF8CBC);
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, argb);
            }
        }
        int bob = (int) Math.round(Math.sin(System.currentTimeMillis() / 220.0));
        for (int row = 0; row < HEART.length; row++) {
            for (int col = 0; col < HEART[row].length(); col++) {
                if (HEART[row].charAt(col) == '.') continue;
                g.fill(mx + 10 + col, my + 1 + bob + row, mx + 11 + col, my + 2 + bob + row, row == 0 && col == 1 ? 0xFFFFB3CE : 0xFFFF6B9A);
            }
        }
        g.pose().popPose();
    }

    /** A glossy blue arrow with a white shine; a spinning ring next to it while the app is busy. (Kawaii: a candy arrow with a twinkling star.) */
    public static void cursor(GuiGraphics g, int mx, int my, boolean busy) {
        if (hell()) { cursorHell(g, mx, my, busy); return; }
        if (anime()) { cursorAnime(g, mx, my, busy); return; }
        if (kawaii()) { cursorKawaii(g, mx, my, busy); return; }
        if (retro()) { cursorRetro(g, mx, my, busy); return; }
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                int argb = c == 'B' ? 0xFF0E4A86 : (col < 3 ? 0xFFFFFFFF : row < 8 ? 0xFFBFE6FF : 0xFF5DB4F0);
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, argb);
            }
        }
        if (busy) {
            long t = System.currentTimeMillis() / 90L;
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4;
                int px = mx + 15 + (int) Math.round(Math.cos(a) * 4), py = my + 15 + (int) Math.round(Math.sin(a) * 4);
                int k = (int) ((t - i) & 7);
                int al = 0x30 + (7 - k) * 0x1E;
                g.fill(px, py, px + 2, py + 2, (Math.min(255, al) << 24) | 0x2F9BEA);
            }
        }
        g.pose().popPose();
    }

    /** A blood red arrow with a black outline that beats like a heart; a dripping ring while busy. */
    private static void cursorHell(GuiGraphics g, int mx, int my, boolean busy) {
        float p = Hell.pulse();
        int hi = 0xFF000000 | ((200 + (int) (p * 55)) << 16) | (0x18 << 8) | 0x24;
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                int argb = c == 'B' ? 0xFF1A0004 : (col < 3 ? hi : row < 8 ? 0xFFB01020 : 0xFF7A0C14);
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, argb);
            }
        }
        if (busy) {
            long t = System.currentTimeMillis() / 90L;
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4;
                int px = mx + 15 + (int) Math.round(Math.cos(a) * 4), py = my + 15 + (int) Math.round(Math.sin(a) * 4);
                int k = (int) ((t - i) & 7);
                g.fill(px, py, px + 2, py + 2 + (k < 2 ? 1 : 0), (Math.min(255, 0x30 + (7 - k) * 0x1E) << 24) | 0xD01020);
            }
        }
        g.pose().popPose();
    }

    /** A white and pink arrow with a plum outline, a twinkling star next to it and a ring of little hearts while busy. */
    private static void cursorKawaii(GuiGraphics g, int mx, int my, boolean busy) {
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                int argb = c == 'B' ? 0xFF8A3C78 : (col < 3 ? 0xFFFFFFFF : row < 8 ? 0xFFFFE0EE : 0xFFFFB0D4);
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, argb);
            }
        }
        long t = System.currentTimeMillis() / 260L;
        int star = (t & 1) == 0 ? 0xFFFFE066 : 0xFFFFF6B0;
        int sx = mx + 13, sy = my + 3;
        g.fill(sx - 2, sy, sx + 3, sy + 1, star);
        g.fill(sx, sy - 2, sx + 1, sy + 3, star);
        if (busy) {
            long k = System.currentTimeMillis() / 90L;
            for (int i = 0; i < 6; i++) {
                double a = i * Math.PI / 3 + k * 0.3;
                g.fill(mx + 15 + (int) Math.round(Math.cos(a) * 5), my + 17 + (int) Math.round(Math.sin(a) * 5), mx + 17 + (int) Math.round(Math.cos(a) * 5), my + 19 + (int) Math.round(Math.sin(a) * 5), 0xFFFF6B9A);
            }
        }
        g.pose().popPose();
    }

    private static final String[] HOURGLASS = {
            "BBBBBBBBB", "BwwwwwwwB", ".BwwwwwB.", "..BwwwB..", "...BwB...", "...BwB...", "..BwwwB..", ".BwwwwwB.", "BwwwwwwwB", "BBBBBBBBB"};

    /** The old black and white arrow, and an hourglass next to it while the app is busy. */
    private static void cursorRetro(GuiGraphics g, int mx, int my, boolean busy) {
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, c == 'B' ? 0xFF000000 : 0xFFFFFFFF);
            }
        }
        if (busy) {
            boolean top = (System.currentTimeMillis() / 400L & 1) == 0;                 // the sand flips from time to time
            for (int row = 0; row < HOURGLASS.length; row++) {
                String s = HOURGLASS[row];
                for (int col = 0; col < s.length(); col++) {
                    char c = s.charAt(col);
                    if (c == '.') continue;
                    int argb = c == 'B' ? 0xFF000000 : ((row < 5) == top ? 0xFFE8D060 : 0xFFFFFFFF);
                    g.fill(mx + 12 + col, my + 3 + row, mx + 13 + col, my + 4 + row, argb);
                }
            }
        }
        g.pose().popPose();
    }

    // ---------- the palette and the rounded shapes of menus and widgets ----------

    /**
     * The colours and the shape of the Start menu and the desktop widgets in the look that is on now.
     * panel / panel2 = the card from top to bottom, rim = its outline, field = inputs, tracks and "off" switches,
     * accent / onAccent = a selected row or a hovered button and the text on it, muted / label / text = the greys, the little
     * titles and the main text, button / buttonHover = the small buttons of the widgets, good = "ready", bar = progress fill,
     * head / paper / ink / inkSoft = the calendar (header, page, big number, weekday), radius = corner radius in pixels,
     * shine = strength (0..255) of the gloss on the upper half, bevel = Retro 98 square raised edges instead of rounded ones.
     */
    public record Pal(int panel, int panel2, int rim, int field, int accent, int onAccent, int muted, int label, int text,
                      int button, int buttonHover, int good, int bar, int head, int paper, int ink, int inkSoft,
                      int radius, int shine, boolean bevel) {}

    private static final Pal PAL_CLASSIC = new Pal(0xE81B1422, 0xE8281E38, 0x40FFFFFF, 0xFF2B2240, 0xFFB57BD6, 0xFFFFFFFF, 0xFF9A90B8, 0xFFF58FB8, 0xFFFFFFFF,
            0xFF3A2F5A, 0xFFB57BD6, 0xFF5BD97A, 0xFFB57BD6, 0xFFE5484D, 0xF2FFFFFF, 0xFF3A2A3A, 0xFF8A7AA8, 5, 0x12, false);
    private static final Pal PAL_AERO = new Pal(0xCC4FB4F0, 0xCC1F6FC4, 0xAAFFFFFF, 0x55103A66, 0x77FFFFFF, 0xFFFFFFFF, 0xFFD6EEFF, 0xFFFFFFFF, 0xFFFFFFFF,
            0xFF3A9BE8, 0xFF7FD0FF, 0xFFB6FFC8, 0xFFFFFFFF, 0xFF2F8FD8, 0xDDFFFFFF, 0xFF14405E, 0xFF2F6F9F, 5, 0x30, false);
    private static final Pal PAL_KAWAII = new Pal(0xEEFF9AC8, 0xEEF06AAE, 0xEEFFFFFF, 0x66B02F78, 0xFFFFFFFF, 0xFFD9569F, 0xFFFFE6F3, 0xFFFFFFFF, 0xFFFFFFFF,
            0xFFD9569F, 0xFFFF7CBC, 0xFFD6FFE0, 0xFFFFFFFF, 0xFFF06AAE, 0xF2FFF6FB, 0xFF8A3C6A, 0xFFC66A9E, 6, 0x33, false);
    private static final Pal PAL_RETRO = new Pal(0xFFC0C0C0, 0xFFC0C0C0, 0xFF000000, 0xFFFFFFFF, 0xFF000080, 0xFFFFFFFF, 0xFF404040, 0xFF000080, 0xFF000000,
            0xFFC0C0C0, 0xFFD8D8D8, 0xFF006000, 0xFF000080, 0xFF000080, 0xFFFFFFFF, 0xFF000000, 0xFF404040, 0, 0, true);
    private static final Pal PAL_ANIME = new Pal(0xE06A3FB0, 0xE0402A86, 0xBBFFFFFF, 0x66200050, 0xFFFF8CC8, 0xFFFFFFFF, 0xFFE0D0FF, 0xFFFFE86A, 0xFFFFFFFF,
            0xFFF47DBB, 0xFFFFA6D8, 0xFFB6FFD8, 0xFFFFE86A, 0xFFE0609F, 0xF4FFF4FB, 0xFF4A2A7A, 0xFF9A5AB8, 5, 0x30, false);

    private static final Pal PAL_HELL = new Pal(0xF02A0408, 0xF0120104, 0xFF8A0A14, 0xFF14020A, 0xFFA01018, 0xFFFFE8E4, 0xFFB05A5A, 0xFFE0302A, 0xFFEBCFC8,
            0xFF4A0710, 0xFFA01018, 0xFFD9302A, 0xFFC01828, 0xFF7A0C14, 0xF2E8D0CC, 0xFF3A0508, 0xFF8A3A3A, 4, 0x10, false);

    private static final Pal PAL_STRANGER = new Pal(0xEE1A1240, 0xEE0F0A2C, 0x88B79CFF, 0xFF120C30, 0xFFFFD866, 0xFF1A1240, 0xFFA79BD0, 0xFFFFD866, 0xFFEDE6FF,
            0xFF3A2C7A, 0xFF5A46A8, 0xFF8FE8C0, 0xFFFFD866, 0xFF5A46A8, 0xF2F1ECFF, 0xFF2A1F5C, 0xFF7A6AB0, 5, 0x18, false);

    // ---------- "The Stranger": a violet night with gold stars ----------
    private static void strangerStar(GuiGraphics g, int cx, int cy, int r, int col) {
        g.fill(cx - r, cy, cx + r + 1, cy + 1, col);
        g.fill(cx, cy - r, cx + 1, cy + r + 1, col);
        if (r > 1) g.fill(cx - 1, cy - 1, cx + 2, cy + 2, col);
    }

    /** The menu bar and the window title bar: dark violet glass, a pale top edge, a gold line below and a few tiny stars. */
    private static void strangerBar(GuiGraphics g, int x, int y, int w, int h) {
        g.fillGradient(x, y, x + w, y + h, 0xF02A1F5C, 0xF0140E36);
        g.fill(x, y, x + w, y + 1, 0x66B79CFF);
        g.fill(x, y + h - 1, x + w, y + h, 0x88FFD866);
        for (int px = x + 14; px < x + w - 6; px += 37) g.fill(px, y + 3 + (px % 3), px + 1, y + 4 + (px % 3), 0x66FFFFFF);
    }

    /** Over the wallpaper: a violet haze, stars that twinkle and now and then a shooting star. */
    private static void strangerOverlay(GuiGraphics g, int x, int y, int w, int h) {
        int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        g.enableScissor(x, y, x + w, y + h);
        g.fillGradient(x, y, x + w, y + h * 35 / 100, 0x33B79CFF, 0x00B79CFF);
        for (int i = 0; i < 18; i++) {
            int sx = x + (i * 61 + 13) % Math.max(1, w - 4), sy = y + (i * 37 + 7) % Math.max(1, h - 4);
            int ph = (t + i * 23) % 90;
            int r = ph < 12 ? 1 : ph < 24 ? 2 : ph < 36 ? 1 : 0;
            if (r > 0) strangerStar(g, sx, sy, r, i % 3 == 0 ? 0xCCFFD866 : 0xBBFFFFFF);
        }
        int cyc = t / 260, p = t % 260;
        if (p < 24) {
            int sx0 = x + w / 4 + hash(cyc * 5) % Math.max(1, w * 3 / 4), sy0 = y + hash(cyc * 11 + 3) % Math.max(1, h / 3);
            for (int k = 0; k < 7; k++) g.fill(sx0 + p * 3 - k * 3, sy0 + p * 3 / 2 - k * 3 / 2, sx0 + p * 3 - k * 3 + 2, sy0 + p * 3 / 2 - k * 3 / 2 + 1, ((200 - k * 26) << 24) | 0xFFF0C0);
        }
        g.disableScissor();
    }

    /** The palette of the look that is on (classic when none is). */
    public static Pal pal() {
        return hell() ? PAL_HELL : stranger() ? PAL_STRANGER : anime() ? PAL_ANIME : retro() ? PAL_RETRO : kawaii() ? PAL_KAWAII : aero() ? PAL_AERO : PAL_CLASSIC;
    }

    /** Blend an ARGB colour toward another one, the alpha too (f = 0..1). */
    public static int blend(int a, int b, float f) {
        int al = (int) ((a >>> 24) * (1 - f) + (b >>> 24) * f);
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int gr = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return (al << 24) | (r << 16) | (gr << 8) | bl;
    }

    private static void roundRows(GuiGraphics g, int x, int y, int w, int h, int rt, int rb, int top, int bottom) {
        rt = Math.max(0, Math.min(rt, Math.min(w, h) / 2));
        rb = Math.max(0, Math.min(rb, Math.min(w, h) / 2));
        for (int dy = 0; dy < h; dy++) {
            double m = dy + 0.5;
            double e = 0;
            int r = 0;
            if (m < rt) { e = rt - m; r = rt; }
            else if (m > h - rb) { e = m - (h - rb); r = rb; }
            int inset = e > 0 ? (int) Math.round(r - Math.sqrt(Math.max(0, r * r - e * e))) : 0;
            int c = top == bottom ? top : blend(top, bottom, h <= 1 ? 0f : dy / (float) (h - 1));
            g.fill(x + inset, y + dy, x + w - inset, y + dy + 1, c);
        }
    }

    /** A rounded rectangle (r = corner radius in pixels) with a vertical gradient from top to bottom. */
    public static void rgrad(GuiGraphics g, int x, int y, int w, int h, int r, int top, int bottom) { roundRows(g, x, y, w, h, r, r, top, bottom); }

    /** The same with only the two upper corners rounded (the header of a card). */
    public static void rgradTop(GuiGraphics g, int x, int y, int w, int h, int r, int top, int bottom) { roundRows(g, x, y, w, h, r, 0, top, bottom); }

    /** A rounded rectangle in one colour. */
    public static void rrect(GuiGraphics g, int x, int y, int w, int h, int r, int argb) { roundRows(g, x, y, w, h, r, r, argb, argb); }

    /** A Windows 98 panel: a black outline, white top-left and dark grey bottom-right edges (raised) or the other way round (sunken). */
    public static void bevel(GuiGraphics g, int x, int y, int w, int h, boolean raised, int face) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF000000);
        g.fill(x, y, x + w, y + h, face);
        int hi = raised ? 0xFFFFFFFF : 0xFF808080, lo = raised ? 0xFF808080 : 0xFFFFFFFF;
        g.fill(x, y, x + w, y + 1, hi);
        g.fill(x, y, x + 1, y + h, hi);
        g.fill(x + 1, y + h - 1, x + w, y + h, lo);
        g.fill(x + w - 1, y + 1, x + w, y + h, lo);
    }

    /**
     * A card for menus and widgets in the palette of the look: a soft shadow, a rim, a body that fades from top to bottom
     * and a gloss on the upper half, all with rounded corners. Retro 98 gets a square raised grey panel. Anime and Kawaii
     * add a little sparkle in the corner.
     */
    public static void card(GuiGraphics g, int x, int y, int w, int h) {
        Pal p = pal();
        if (p.bevel()) { bevel(g, x, y, w, h, true, p.panel()); return; }
        int r = p.radius();
        rrect(g, x + 1, y + 2, w, h, r, 0x30000000);
        rrect(g, x - 1, y - 1, w + 2, h + 2, r + 1, p.rim());
        rgrad(g, x, y, w, h, r, p.panel(), p.panel2());
        if (p.shine() > 0 && h > 8) rgrad(g, x + 1, y + 1, w - 2, Math.max(2, h / 2 - 1), Math.max(0, r - 1), (p.shine() << 24) | 0xFFFFFF, 0x00FFFFFF);
        if (w >= 40 && h >= 20) {
            if (anime()) animeStar(g, x + w - 7, y + 6, 2, 0xB0FFFFFF);
            else if (kawaii()) sparkle(g, x + w - 7, y + 6, 2, 0xCCFFFFFF);
        }
    }
}
