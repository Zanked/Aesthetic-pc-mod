package dev.cutemod.client;

import dev.cutemod.ComputerColor;
import dev.cutemod.client.os.Store;
import dev.cutemod.net.RequestDataPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;

/** Kept in a separate class so the dedicated server never loads client-only code. */
public class ClientHooks {
    /** Called once on the client: forget the server's data when we disconnect. */
    public static void init(net.neoforged.bus.api.IEventBus modBus) {
        // the albums of the player: the folder cutemod_music next to the game becomes a resource pack at every reload
        modBus.addListener((net.neoforged.neoforge.event.AddPackFindersEvent e) -> {
            if (e.getPackType() == net.minecraft.server.packs.PackType.CLIENT_RESOURCES)
                e.addRepositorySource(dev.cutemod.client.player.UserMusic::loadPack);
        });
        // after a reload (start, F3+T, the Rescan button) the albums are read again
        modBus.addListener((net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent e) ->
                e.registerReloadListener((net.minecraft.server.packs.resources.ResourceManagerReloadListener) rm -> {
                    dev.cutemod.client.os.Albums.reload();
                    dev.cutemod.client.player.HeadphonesModel.reset();   // the 3D model of the headphones is baked again
                }));
        // the headphones on the head: a real 3D model (band + two cups) instead of the flat helmet texture
        modBus.addListener((net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterLayerDefinitions e) ->
                e.registerLayerDefinition(dev.cutemod.client.player.HeadphonesModel.LAYER, dev.cutemod.client.player.HeadphonesModel::createLayer));
        modBus.addListener((net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent e) ->
                {
                    var ext = new dev.cutemod.client.player.HeadphonesModel.Ext();
                    e.registerItem(ext, dev.cutemod.item.ModItems.HEADPHONES.get());
                    for (var h : dev.cutemod.item.ModItems.COLOR_HEADPHONES.values()) e.registerItem(ext, h.get());
                });
        NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingOut e) -> { dev.cutemod.client.os.StreamNet.clear(); dev.cutemod.client.os.TubeNet.clear(); });
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.client.event.ClientTickEvent.Post e) -> dev.cutemod.client.os.Behind.tick());
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.client.event.ClientTickEvent.Post e) -> dev.cutemod.client.player.PlayerEngine.tick());
        NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingOut e) -> dev.cutemod.client.player.PlayerEngine.stop());
        NeoForge.EVENT_BUS.addListener(dev.cutemod.client.player.Headphones::onPlaySound);
        NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingOut e) -> { Store.clear(); dev.cutemod.client.os.Net.clear(); dev.cutemod.client.os.Post.clear(); dev.cutemod.client.os.Show.clear(); dev.cutemod.client.os.Park.clear(); dev.cutemod.client.game.CheckersNet.clear(); dev.cutemod.client.game.BilliardsNet.clear(); dev.cutemod.client.game.DashNet.clear(); dev.cutemod.client.game.DurakNet.clear(); });
    }

    /** The server sent what it has saved for us. */
    public static void onSync(Map<String, String> data) {
        Store.apply(data);
    }

    /** The server told us which parcels are on their way (and maybe gave coins back). */
    public static void onMarketSync(dev.cutemod.net.MarketSyncPayload p) {
        dev.cutemod.client.os.Market.applyServer(p);
    }

    /** An operator changed our coins (/cutecoins). */
    public static void onAdminCoins(dev.cutemod.net.AdminCoinsPayload p) {
        dev.cutemod.client.os.Progress.admin(p.set(), p.amount());
    }

    /** An operator opened all our jobs (/cutejobs unlock). */
    public static void onAdminJobs() {
        dev.cutemod.client.os.Jobs.adminUnlock();
    }

    /** The LIVE stream of CuteTube: new chat messages and the number of viewers. */
    public static void onStreamSync(dev.cutemod.net.StreamSyncPayload p) {
        dev.cutemod.client.os.StreamNet.apply(p);
    }

    /** The videos of the other players on CuteTube. */
    public static void onTubeSync(dev.cutemod.net.TubeSyncPayload p) {
        dev.cutemod.client.os.TubeNet.apply(p);
    }

    /** Player mail: the mailbox, the players we can write to and the answer to our last letter. */
    public static void onPostSync(dev.cutemod.net.PostSyncPayload p) {
        dev.cutemod.client.os.Post.apply(p);
    }

    /** CuteNet: the top of a game and who is online. */
    public static void onNetSync(dev.cutemod.net.NetSyncPayload p) {
        dev.cutemod.client.os.Net.apply(p);
    }

    /** Online checkers: who is free to play, invitations and our game. */
    public static void onCheckersSync(dev.cutemod.net.CheckersSyncPayload p) {
        dev.cutemod.client.game.CheckersNet.apply(p);
    }

    /** Online billiards: who is free to play, invitations and our game. */
    public static void onBilliardsSync(dev.cutemod.net.BilliardsSyncPayload p) {
        dev.cutemod.client.game.BilliardsNet.apply(p);
    }

    /** Online Kitty Dash: who is free to race, invitations and our race. */
    public static void onDashSync(dev.cutemod.net.DashSyncPayload p) {
        dev.cutemod.client.game.DashNet.apply(p);
    }

    /** Online Durak: the lobby and the game. */
    public static void onDurakSync(dev.cutemod.net.DurakSyncPayload p) {
        dev.cutemod.client.game.DurakNet.apply(p);
    }

    /** The pet show: a page of the list and the answer to our last action. */
    /** The Pet Park: the other pets and what happened to us. */
    public static void onParkSync(dev.cutemod.net.ParkSyncPayload p) {
        dev.cutemod.client.os.Park.apply(p);
    }

    public static void onShowSync(dev.cutemod.net.ShowSyncPayload p) {
        dev.cutemod.client.os.Show.apply(p);
    }

    /** The talent show is coming. */
    public static void onShowAlert(dev.cutemod.net.ShowAlertPayload p) {
        dev.cutemod.client.os.Show.alert(p.opensInSec(), p.theme());
    }

    /** The talent show paid us for our place. */
    public static void onShowPrize(dev.cutemod.net.ShowPrizePayload p) {
        dev.cutemod.client.os.Show.prize(p.coins(), p.rank());
    }

    public static void openComputer(ComputerColor color, BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        if (!Store.ready()) {                       // the server's copy of our data has not arrived yet
            PacketDistributor.sendToServer(new RequestDataPayload());
            if (mc.player != null) mc.player.displayClientMessage(Component.translatable("cutemod.sync.wait"), true);
            return;
        }
        mc.setScreen(new ComputerScreen(color, pos));
    }

    private ClientHooks() {}
}
