package dev.cutemod.client.os;

import java.time.DayOfWeek;
import java.time.LocalDate;

/**
 * The trip places that open by what the player does (not by an OS update): by the progress of the game (trips made,
 * games played, fish caught, finds in the album) or by an event (Halloween, the weekend fair). The names, the finds and
 * the hints are in the lang files: cutemod.trip.dest.N, cutemod.trip.find.N.K, cutemod.trip.lock.N.
 * Event places stay open for good once the pet has been there (the counter pl_N is set by {@link Trip#start}).
 */
final class PlaceUnlock {
    private PlaceUnlock() {}

    /** The first place that is opened here; the places before it come with the first six or with the OS updates. */
    static final int FIRST = 11;
    static final int AMUSEMENT = 11, CINEMA = 12, MUSEUM = 13, CAMP = 14, OLD_HOUSE = 15, FAIR = 16,
            QUIET = 17;   // the Quiet Place: opens for good when the phrase of the Stranger was said (see Traces)

    /** How much the player has to do (0 = an event place, no number). */
    static int target(int d) {
        return switch (d) {
            case AMUSEMENT -> 10;     // trips
            case CINEMA -> 5;         // games played on the computer
            case MUSEUM -> 8;         // finds in the album
            case CAMP -> 5;           // fish caught
            default -> 0;
        };
    }

    static int have(int d) {
        return switch (d) {
            case AMUSEMENT -> Progress.count("trips");
            case CINEMA -> Progress.count("games");
            case MUSEUM -> Trip.albumCount();
            case CAMP -> Progress.count("fish_caught");
            default -> 0;
        };
    }

    static boolean isEvent(int d) { return d == OLD_HOUSE || d == FAIR; }

    private static boolean eventNow(int d) {
        if (d == OLD_HOUSE) return Halloween.active();
        DayOfWeek w = LocalDate.now().getDayOfWeek();
        return w == DayOfWeek.SATURDAY || w == DayOfWeek.SUNDAY;
    }

    static boolean open(int d) {
        if (d < FIRST || d >= Trip.DESTS) return false;
        if (d == QUIET) return Traces.finished();
        if (isEvent(d)) return Progress.count("pl_" + d) > 0 || eventNow(d);
        return have(d) >= target(d);
    }

    /** The text of the lock: how far the player is (or when the event is). */
    /** The Quiet Place is not shown anywhere until the first clue of the Traces is found. */
    static boolean hidden(int d) { return d == QUIET && !Traces.started() && !Traces.finished(); }

    static String progress(int d) { return isEvent(d) || d == QUIET ? "" : Math.min(have(d), target(d)) + "/" + target(d); }
}
