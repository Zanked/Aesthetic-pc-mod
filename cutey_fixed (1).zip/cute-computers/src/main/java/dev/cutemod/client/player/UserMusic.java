package dev.cutemod.client.player;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.PackLocationInfo;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.PathPackResources;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;
import net.neoforged.fml.loading.FMLPaths;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

/**
 * Your music from the folder "cutemod_music" next to the game (no rebuild of the mod needed).
 *
 * Just throw the .ogg files in (folders do not matter, any depth): the tags inside them (title, artist, album artist,
 * album, track and disc number, and the picture) put every song into its album. Optional, like before:
 *
 *   cutemod_music/My Album/cover.png          (a picture file; else the picture inside the songs is used)
 *   cutemod_music/My Album/album.json         ({"title": "...", "artist": "...", "price": 70})
 *
 * Every time the game loads its resources (start, F3+T, the Rescan button of the Music app) the folder is scanned and
 * turned into a small resource pack (in cutemod_music/.cache) that holds the same things music.gradle makes for the
 * albums that are inside the mod: the songs, their entries for sounds.json and albums.json.
 */
public final class UserMusic {
    private UserMusic() {}

    public static final String PACK_ID = "cutemod_user_music";
    private static final int DEFAULT_PRICE = 70;     // every album costs 70 in CuteMarket (an album.json can set another price; 0 = free)
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    /** The folder the player puts the albums into. */
    public static Path dir() { return FMLPaths.GAMEDIR.get().resolve("cutemod_music"); }

    private static Path cache() { return dir().resolve(".cache"); }

    /** A RepositorySource: gives the game the resource pack made from the folder. Runs at every resource reload. */
    public static void loadPack(Consumer<Pack> consumer) {
        try {
            rebuild();
            PackLocationInfo info = new PackLocationInfo(PACK_ID, Component.literal("Cute Computers: your music"),
                    PackSource.BUILT_IN, Optional.empty());
            Pack pack = makePack(info, new PathPackResources.PathResourcesSupplier(cache()));
            if (pack != null) consumer.accept(pack);
        } catch (Exception e) {
            // a problem with the folder must never stop the game from starting: just no user albums
            System.err.println("[cutemod] could not read the music folder: " + e);
        }
    }

    /**
     * Pack.readMetaAndCreate changed its last parameter between Minecraft versions (a "selection config" record, or the
     * position), so it is found and called by reflection: the pack is always on, at the top, and cannot be moved.
     */
    private static Pack makePack(Object info, Object supplier) throws Exception {
        for (java.lang.reflect.Method m : Pack.class.getMethods()) {
            if (!m.getName().equals("readMetaAndCreate") || !java.lang.reflect.Modifier.isStatic(m.getModifiers())) continue;
            Class<?>[] p = m.getParameterTypes();
            if (p.length != 4 || p[0] != PackLocationInfo.class || p[2] != PackType.class) continue;
            Object last;
            if (p[3] == Pack.Position.class) last = Pack.Position.TOP;
            else last = p[3].getConstructor(boolean.class, Pack.Position.class, boolean.class).newInstance(true, Pack.Position.TOP, false);
            return (Pack) m.invoke(null, info, supplier, PackType.CLIENT_RESOURCES, last);
        }
        throw new IllegalStateException("Pack.readMetaAndCreate was not found");
    }

    // ---------- scan the folder and write the pack ----------
    private static void rebuild() throws IOException {
        Path root = dir();
        Files.createDirectories(root);
        readme(root);

        Path pack = cache();
        Path assets = pack.resolve("assets/cutemod");
        Files.createDirectories(assets.resolve("sounds/music"));
        Files.createDirectories(assets.resolve("textures/music"));
        Files.createDirectories(assets.resolve("music"));
        Files.writeString(pack.resolve("pack.mcmeta"),
                "{\"pack\":{\"pack_format\":34,\"description\":\"Cute Computers: your music\"}}", StandardCharsets.UTF_8);

        JsonObject sounds = new JsonObject();
        JsonArray albums = new JsonArray();
        Set<String> ids = new HashSet<>();
        Set<String> coverFiles = new HashSet<>();

        // 1. every .ogg anywhere under cutemod_music (in folders or just thrown in), with its tags
        List<Path> files = new ArrayList<>();
        try (Stream<Path> s = Files.walk(root, 8)) {
            s.filter(p -> Files.isRegularFile(p) && isAudio(p) && !hidden(root, p)).forEach(files::add);
        }
        files.sort((a, b) -> natural(root.relativize(a).toString(), root.relativize(b).toString()));
        List<Src> all = new ArrayList<>();
        for (Path f : files) {
            try {
                byte[] data = Files.readAllBytes(f);
                all.add(new Src(f, f.getParent(), OggTags.read(data), oggSeconds(data)));
            } catch (IOException ignored) { /* a file that cannot be read is skipped */ }
        }

        // 2. the songs go to albums by their tags (a song without an album tag: by its folder, else "Singles")
        Map<String, List<Src>> groups = new LinkedHashMap<>();
        for (Src sr : all) {
            String key = albumNameOf(sr, root).toLowerCase(Locale.ROOT) + "|" + sr.tags().albumArtist().toLowerCase(Locale.ROOT);
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(sr);
        }
        Map<String, List<Src>> albumsOf = new LinkedHashMap<>();
        for (Map.Entry<String, List<Src>> e : groups.entrySet()) {
            List<Src> l = e.getValue();
            // two different albums with the same name and no album artist tag: the same track number twice -> split by artist
            if (l.get(0).tags().albumArtist().isEmpty() && hasDuplicateNumbers(l)) {
                for (Src sr : l) albumsOf.computeIfAbsent(e.getKey() + "|" + sr.tags().artist().toLowerCase(Locale.ROOT), k -> new ArrayList<>()).add(sr);
            } else albumsOf.put(e.getKey(), l);
        }
        List<List<Src>> ordered = new ArrayList<>(albumsOf.values());
        ordered.sort((a, b) -> natural(albumNameOf(a.get(0), root), albumNameOf(b.get(0), root)));

        for (List<Src> songs : ordered) {
            songs.sort((a, b) -> {
                int c = Integer.compare(Math.max(1, a.tags().disc()), Math.max(1, b.tags().disc()));
                if (c == 0) c = Integer.compare(a.tags().track() > 0 ? a.tags().track() : Integer.MAX_VALUE,
                        b.tags().track() > 0 ? b.tags().track() : Integer.MAX_VALUE);
                return c != 0 ? c : natural(a.file().getFileName().toString(), b.file().getFileName().toString());
            });
            String name = albumNameOf(songs.get(0), root);
            String artist = albumArtistOf(songs);

            // an album.json (old way, optional) is read when the whole album lies in one folder
            Path one = songs.get(0).folder();
            boolean oneFolder = !one.equals(root);
            for (Src sr : songs) if (!sr.folder().equals(one)) oneFolder = false;
            JsonObject meta = new JsonObject();
            if (oneFolder && Files.exists(one.resolve("album.json"))) {
                try { meta = JsonParser.parseString(Files.readString(one.resolve("album.json"), StandardCharsets.UTF_8)).getAsJsonObject(); }
                catch (Exception ignored) { /* a broken album.json: use the tags */ }
            }

            String seed = name + (artist.isEmpty() ? "" : " | " + artist);
            String id = "u_" + slug(meta.has("id") ? meta.get("id").getAsString() : seed, seed);
            while (!ids.add(id)) id += "x";

            Path songDir = assets.resolve("sounds/music/" + id);
            Files.createDirectories(songDir);
            JsonArray tracks = new JsonArray();
            Set<String> wanted = new HashSet<>();
            byte[] embedded = null;                                  // the picture stored inside a song (the first one that has it)
            for (int i = 0; i < songs.size(); i++) {
                Src sr = songs.get(i);
                String tid = String.format("t%02d", i + 1);
                wanted.add(tid + ".ogg");
                copyIfChanged(sr.file(), songDir.resolve(tid + ".ogg"));

                JsonObject ev = new JsonObject();
                JsonArray list = new JsonArray();
                JsonObject snd = new JsonObject();
                snd.addProperty("name", "cutemod:music/" + id + "/" + tid);
                snd.addProperty("stream", true);
                list.add(snd);
                ev.add("sounds", list);
                sounds.add("music." + id + "." + tid, ev);

                String title = sr.tags().title().isEmpty() ? prettyTitle(sr.file().getFileName().toString()) : sr.tags().title();
                String by = sr.tags().artist();
                if (artist.equals(VARIOUS) && !by.isEmpty()) title = by + " - " + title;     // a compilation: who sings it
                JsonObject t = new JsonObject();
                t.addProperty("id", tid);
                t.addProperty("title", title);
                t.addProperty("seconds", sr.seconds());
                if (embedded == null) embedded = OggCover.extract(Files.readAllBytes(sr.file()));
                tracks.add(t);
            }
            try (Stream<Path> old = Files.list(songDir)) {          // songs that were removed from the folder
                for (Path p : (Iterable<Path>) old::iterator) if (!wanted.contains(p.getFileName().toString())) Files.deleteIfExists(p);
            }

            boolean hasCover = false;
            int cw = 0, ch = 0;
            Path cover = oneFolder ? findCover(one, meta) : null;
            Path coverOut = assets.resolve("textures/music/" + id + ".png");
            int[] size = cover != null ? makeCover(cover, coverOut) : null;
            if (size == null && embedded != null) size = makeCover(embedded, coverOut);      // no picture file: the one inside the songs
            if (size != null) { coverFiles.add(id + ".png"); hasCover = true; cw = size[0]; ch = size[1]; }

            JsonObject a = new JsonObject();
            a.addProperty("id", id);
            a.addProperty("title", meta.has("title") ? meta.get("title").getAsString() : name);
            a.addProperty("artist", meta.has("artist") ? meta.get("artist").getAsString() : artist);
            a.addProperty("price", meta.has("price") ? meta.get("price").getAsInt() : DEFAULT_PRICE);
            a.addProperty("cover", hasCover);
            a.addProperty("coverW", cw);
            a.addProperty("coverH", ch);
            a.add("tracks", tracks);
            albums.add(a);
        }

        // albums that were removed from the folder
        try (Stream<Path> old = Files.list(assets.resolve("sounds/music"))) {
            for (Path p : (Iterable<Path>) old::iterator) if (!ids.contains(p.getFileName().toString())) deleteTree(p);
        }
        try (Stream<Path> old = Files.list(assets.resolve("textures/music"))) {
            for (Path p : (Iterable<Path>) old::iterator) if (!coverFiles.contains(p.getFileName().toString())) Files.deleteIfExists(p);
        }

        Files.writeString(assets.resolve("sounds.json"), GSON.toJson(sounds), StandardCharsets.UTF_8);
        JsonObject manifest = new JsonObject();
        manifest.add("albums", albums);
        Files.writeString(assets.resolve("music/albums.json"), GSON.toJson(manifest), StandardCharsets.UTF_8);
    }

    private static void readme(Path root) throws IOException {
        Path f = root.resolve("README.txt");                 // written again every time: it is the manual, not your data
        Files.writeString(f, String.join("\n",
                "YOUR MUSIC FOR THE MUSIC APP / ТВОЯ МУЗЫКА ДЛЯ ПРИЛОЖЕНИЯ «МУЗЫКА»",
                "",
                "Just drop your .ogg songs here - no folders needed.",
                "Просто кидай сюда .ogg песни - папки создавать не нужно.",
                "",
                "The songs are sorted by their tags: album, artist, album artist, title, track and disc number, and the cover inside.",
                "Песни сами раскладываются по альбомам по тегам: альбом, исполнитель, название, номер трека и диска, обложка внутри файла.",
                "A song without an album tag goes to the album of its folder, or to \"Singles\".",
                "Песня без тега альбома попадает в альбом по имени её папки, а если лежит просто здесь - в «Singles».",
                "",
                "Every album costs 70 coins in CuteMarket (price 0 in album.json = free). Optional, in a folder with the songs: cover.jpg (png, jpg, gif, bmp), album.json:",
                "Каждый альбом стоит 70 монет в КьютМаркете (price 0 в album.json = бесплатно). Необязательно, в папке с песнями: cover.jpg, album.json:",
                "  { \"title\": \"My Album\", \"artist\": \"Me\", \"price\": 70 }",
                "",
                "Songs must be .ogg. Convert with: ffmpeg -i song.mp3 -c:a libvorbis -q:a 4 -map_metadata 0 song.ogg",
                "Песни должны быть в формате .ogg. Конвертация (теги сохраняются): ffmpeg -i song.mp3 -c:a libvorbis -q:a 4 -map_metadata 0 song.ogg",
                "",
                "After adding songs press Rescan in the Music app (or F3+T in the game).",
                "Добавил песни? Нажми «Обновить» в приложении «Музыка» (или F3+T в игре).",
                ""), StandardCharsets.UTF_8);
    }

    // ---------- covers: png, jpg, gif or bmp, any of the usual names; the game gets a small png ----------
    private static final List<String> IMAGE_EXTS = List.of("png", "jpg", "jpeg", "gif", "bmp");
    private static final List<String> COVER_NAMES = List.of("cover", "folder", "front", "album", "albumart", "art", "artwork");

    private static boolean isImage(Path p) {
        String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
        int dot = n.lastIndexOf('.');
        return dot > 0 && Files.isRegularFile(p) && IMAGE_EXTS.contains(n.substring(dot + 1));
    }

    /** album.json "cover", else cover/folder/front/... (any case, any of the picture formats), else the first picture. */
    private static Path findCover(Path folder, JsonObject meta) throws IOException {
        if (meta.has("cover") && meta.get("cover").isJsonPrimitive()) {
            Path p = folder.resolve(meta.get("cover").getAsString()).normalize();
            if (p.startsWith(folder) && isImage(p)) return p;
        }
        List<Path> images = new ArrayList<>();
        try (Stream<Path> s = Files.list(folder)) { s.filter(UserMusic::isImage).forEach(images::add); }
        if (images.isEmpty()) return null;
        for (String name : COVER_NAMES) {
            for (Path p : images) {
                String n = p.getFileName().toString();
                if (n.substring(0, n.lastIndexOf('.')).equalsIgnoreCase(name)) return p;
            }
        }
        images.sort((a, b) -> natural(a.getFileName().toString(), b.getFileName().toString()));
        return images.get(0);
    }

    /** Writes the picture as a png of at most 128 px (smoothly shrunk: the game draws it tiny); returns {width, height} or null. */
    private static int[] makeCover(Path src, Path dest) {
        try {
            if (Files.exists(dest) && Files.getLastModifiedTime(dest).toMillis() >= Files.getLastModifiedTime(src).toMillis()) {
                int[] known = pngSize(Files.readAllBytes(dest));
                if (known[0] > 0 && known[1] > 0) return known;
            }
            return writeCover(ImageIO.read(src.toFile()), dest);
        } catch (Exception e) {
            return null;   // not a picture the game can read: the album just has no cover
        }
    }

    /** The same for a picture that was taken out of a song (bytes of a png / jpg / ...). */
    private static int[] makeCover(byte[] image, Path dest) {
        try {
            return writeCover(ImageIO.read(new java.io.ByteArrayInputStream(image)), dest);
        } catch (Exception e) {
            return null;
        }
    }

    private static int[] writeCover(BufferedImage img, Path dest) {
        try {
            if (img == null) return null;
            int w = img.getWidth(), h = img.getHeight(), max = 128;
            if (Math.max(w, h) > max) {
                double sc = max / (double) Math.max(w, h);
                w = Math.max(1, (int) Math.round(w * sc));
                h = Math.max(1, (int) Math.round(h * sc));
            }
            BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            java.awt.Graphics2D g = out.createGraphics();
            g.drawImage(img.getScaledInstance(w, h, java.awt.Image.SCALE_AREA_AVERAGING), 0, 0, null);
            g.dispose();
            Files.createDirectories(dest.getParent());
            ImageIO.write(out, "png", dest.toFile());
            return new int[]{w, h};
        } catch (Exception e) {
            return null;   // not a picture the game can read: the album just has no cover
        }
    }

    // ---------- sorting by tags ----------
    private static final String VARIOUS = "Various Artists";
    private static final String SINGLES = "Singles";

    /** A song of the folder with what is needed to put it into an album. */
    private record Src(Path file, Path folder, OggTags.Tags tags, int seconds) {}

    private static boolean isAudio(Path p) {
        String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
        return n.endsWith(".ogg") || n.endsWith(".oga");
    }

    /** Anything under a folder or file whose name starts with a dot (.cache and the like). */
    private static boolean hidden(Path root, Path p) {
        for (Path part : root.relativize(p)) if (part.toString().startsWith(".")) return true;
        return false;
    }

    /** The album tag; without it the name of the folder; a song thrown loose into the main folder goes to "Singles". */
    private static String albumNameOf(Src s, Path root) {
        if (!s.tags().album().isEmpty()) return s.tags().album();
        if (!s.folder().equals(root)) return s.folder().getFileName().toString();
        return SINGLES;
    }

    /** The album artist tag, else the artist when it is the same on all songs, else "Various Artists". */
    private static String albumArtistOf(List<Src> songs) {
        for (Src s : songs) if (!s.tags().albumArtist().isEmpty()) return s.tags().albumArtist();
        Set<String> by = new LinkedHashSet<>();
        for (Src s : songs) if (!s.tags().artist().isEmpty()) by.add(s.tags().artist());
        return by.isEmpty() ? "" : by.size() == 1 ? by.iterator().next() : VARIOUS;
    }

    private static boolean hasDuplicateNumbers(List<Src> l) {
        Set<Integer> seen = new HashSet<>();
        for (Src s : l) if (s.tags().track() > 0 && !seen.add(Math.max(1, s.tags().disc()) * 10000 + s.tags().track())) return true;
        return false;
    }

    // ---------- helpers (the same rules as music.gradle) ----------
    private static void copyIfChanged(Path src, Path dest) throws IOException {
        if (Files.exists(dest) && Files.size(dest) == Files.size(src)
                && Files.getLastModifiedTime(dest).toMillis() == Files.getLastModifiedTime(src).toMillis()) return;
        Files.createDirectories(dest.getParent());
        Files.copy(src, dest, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.COPY_ATTRIBUTES);
    }

    private static void deleteTree(Path p) throws IOException {
        if (Files.isDirectory(p)) {
            try (Stream<Path> s = Files.list(p)) { for (Path c : (Iterable<Path>) s::iterator) deleteTree(c); }
        }
        Files.deleteIfExists(p);
    }

    /** a-z, 0-9 and _ only; anything else (Cyrillic names...) becomes a short stable hash of the folder name. */
    private static String slug(String wanted, String folderName) {
        String s = wanted.toLowerCase(Locale.ROOT).trim().replaceAll("\\s+", "_");
        if (s.matches("[a-z0-9_]+")) return s;
        try {
            byte[] h = MessageDigest.getInstance("MD5").digest(folderName.getBytes(StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder("a");
            for (int i = 0; i < 4; i++) b.append(String.format("%02x", h[i]));
            return b.toString();
        } catch (Exception e) { return "a" + Math.abs(folderName.hashCode()); }
    }

    private static String prettyTitle(String file) {
        String s = file.replaceAll("(?i)\\.ogg$", "");
        s = s.replaceFirst("^\\s*\\d+\\s*[-_.)]*\\s*", "").replace('_', ' ').trim();
        return s.isEmpty() ? file.replaceAll("(?i)\\.ogg$", "") : s;
    }

    /** "2 a" before "10 a". */
    private static int natural(String a, String b) {
        a = a.toLowerCase(Locale.ROOT);
        b = b.toLowerCase(Locale.ROOT);
        int i = 0, j = 0;
        while (i < a.length() && j < b.length()) {
            char x = a.charAt(i), y = b.charAt(j);
            if (Character.isDigit(x) && Character.isDigit(y)) {
                int i2 = i, j2 = j;
                while (i2 < a.length() && Character.isDigit(a.charAt(i2))) i2++;
                while (j2 < b.length() && Character.isDigit(b.charAt(j2))) j2++;
                int c = new BigInteger(a.substring(i, i2)).compareTo(new BigInteger(b.substring(j, j2)));
                if (c != 0) return c;
                i = i2; j = j2;
            } else {
                if (x != y) return Character.compare(x, y);
                i++; j++;
            }
        }
        return Integer.compare(a.length() - i, b.length() - j);
    }

    /** Length of an .ogg in whole seconds: sample rate from the Vorbis header, sample count from the last Ogg page. */
    private static int oggSeconds(byte[] b) {
        int rate = 0;
        for (int i = 0; i < Math.min(b.length - 16, 4096); i++) {
            if (b[i] == 1 && b[i + 1] == 'v' && b[i + 2] == 'o' && b[i + 3] == 'r' && b[i + 4] == 'b' && b[i + 5] == 'i' && b[i + 6] == 's') {
                int o = i + 12;
                rate = (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
                break;
            }
        }
        long gran = -1;
        for (int i = b.length - 14; i >= 0; i--) {
            if (b[i] == 'O' && b[i + 1] == 'g' && b[i + 2] == 'g' && b[i + 3] == 'S') {
                gran = 0;
                for (int k = 7; k >= 0; k--) gran = (gran << 8) | (b[i + 6 + k] & 0xFF);
                break;
            }
        }
        return (rate > 0 && gran > 0) ? (int) Math.ceil(gran / (double) rate) : 0;
    }

    private static int[] pngSize(byte[] b) {
        if (b.length < 24) return new int[]{0, 0};
        int w = ((b[16] & 0xFF) << 24) | ((b[17] & 0xFF) << 16) | ((b[18] & 0xFF) << 8) | (b[19] & 0xFF);
        int h = ((b[20] & 0xFF) << 24) | ((b[21] & 0xFF) << 16) | ((b[22] & 0xFF) << 8) | (b[23] & 0xFF);
        return new int[]{w, h};
    }
}
