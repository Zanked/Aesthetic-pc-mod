package dev.cutemod.block;

import com.mojang.serialization.MapCodec;
import dev.cutemod.ComputerColor;
import dev.cutemod.client.ClientHooks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class ComputerBlock extends Block implements EntityBlock {
    public static final MapCodec<ComputerBlock> CODEC = simpleCodec(p -> new ComputerBlock(p, ComputerColor.PINK));
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    // Shapes for the 4 directions, computed from the model (front of the model = south).
    private static final VoxelShape[] SHAPES = new VoxelShape[4];
    static {
        // quarter turns clockwise (seen from above): south=0, west=1, north=2, east=3
        for (int turn = 0; turn < 4; turn++) {
            VoxelShape body = rotated(0.5, 0, 2.5, 15, 10.75, 12, turn);
            VoxelShape keys = rotated(0.5, 0, 12, 15, 1.75, 15.75, turn);
            SHAPES[turn] = Shapes.or(body, keys);
        }
    }

    private static VoxelShape rotated(double x0, double y0, double z0, double x1, double y1, double z1, int turns) {
        for (int i = 0; i < turns; i++) {
            // (x, z) -> (16 - z, x)
            double nx0 = 16 - z1, nx1 = 16 - z0, nz0 = x0, nz1 = x1;
            x0 = nx0; x1 = nx1; z0 = nz0; z1 = nz1;
        }
        return Block.box(x0, y0, z0, x1, y1, z1);
    }

    private final ComputerColor color;

    public ComputerBlock(BlockBehaviour.Properties props, ComputerColor color) {
        super(props);
        this.color = color;
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.SOUTH));
    }

    public ComputerColor getColor() { return color; }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        // The screen should look at the player.
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rot) {
        return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }

    private static int turnsOf(Direction facing) {
        return switch (facing) {
            case WEST -> 1;
            case NORTH -> 2;
            case EAST -> 3;
            default -> 0;
        };
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPES[turnsOf(state.getValue(FACING))];
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) {
            ClientHooks.openComputer(color, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** A dye on a computer paints it in the colour of the dye (the direction and the high score stay). */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player,
                                              InteractionHand hand, BlockHitResult hit) {
        if (stack.getItem() instanceof DyeItem dye) {
            ComputerColor target = ComputerColor.fromDye(dye.getDyeColor());
            if (target != null && target != color) {
                if (!level.isClientSide) {
                    BlockEntity old = level.getBlockEntity(pos);
                    CompoundTag data = old == null ? null : old.saveWithoutMetadata(level.registryAccess());
                    BlockState painted = ModBlocks.get(target).get().defaultBlockState().setValue(FACING, state.getValue(FACING));
                    level.setBlock(pos, painted, 3);
                    BlockEntity fresh = level.getBlockEntity(pos);
                    if (data != null && fresh != null) {
                        fresh.loadWithComponents(data, level.registryAccess());
                        fresh.setChanged();
                        level.sendBlockUpdated(pos, painted, painted, 3);
                    }
                    if (!player.getAbilities().instabuild) stack.shrink(1);
                    level.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 1F, 1F);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ComputerBlockEntity(pos, state);
    }
}
