"""
Winter players and cases of the portable player, drawn smooth:

  python tools/make_player_skins.py

Takes textures/item/music_player_white_3d.png (128x128), blows it up x4, paints the body in a soft gradient and draws the pattern
(stars, blossoms, snowflakes, dots, stripes) with anti-aliased shapes only on the plain body of the player (never over the screen,
the wheel or the heart), then shrinks it back to 128x128. The layout of the atlas is not changed.
Writes music_player_{snow,santa}_3d.png and music_player_case_{starry,sakura,mint,bee}_3d.png.
"""
import os, math, random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
T = os.path.join(ROOT, 'src/main/resources/assets/cutemod/textures/item/')
S = 4                                    # x4 work size (128 -> 512)
# the big faces of the atlas at 128 px: x, y, w, h
FACES = {'front': (0, 0, 48, 80), 'back': (50, 0, 48, 80), 'side': (100, 0, 18, 80), 'top': (50, 85, 48, 18), 'bottom': (50, 106, 48, 18)}


def mix(a, b, t): return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


# ---- shapes (all drawn on an RGBA layer at the work size) -----------------------------------------------------------
def star(d, cx, cy, r, col, points=4, inner=0.38, rot=0.0):
    pts = []
    for i in range(points * 2):
        rr = r if i % 2 == 0 else r * inner
        a = rot - math.pi / 2 + i * math.pi / points
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    d.polygon(pts, fill=col)


def flower(d, cx, cy, r, petal, centre, rot=0.0):
    for i in range(5):
        a = rot + i * 2 * math.pi / 5
        px, py = cx + r * 0.52 * math.cos(a), cy + r * 0.52 * math.sin(a)
        d.ellipse((px - r * 0.5, py - r * 0.5, px + r * 0.5, py + r * 0.5), fill=petal)
    d.ellipse((cx - r * 0.22, cy - r * 0.22, cx + r * 0.22, cy + r * 0.22), fill=centre)


def snowflake(d, cx, cy, r, col, w):
    for k in range(3):
        a = k * math.pi / 3
        ex, ey = r * math.cos(a), r * math.sin(a)
        d.line([(cx - ex, cy - ey), (cx + ex, cy + ey)], fill=col, width=w)
        for sg in (-1, 1):
            bx, by = cx + sg * ex * 0.55, cy + sg * ey * 0.55
            for da in (-0.8, 0.8):
                d.line([(bx, by), (bx + sg * r * 0.3 * math.cos(a + da), by + sg * r * 0.3 * math.sin(a + da))], fill=col, width=max(1, w - 1))


# ---- the body ----------------------------------------------------------------------------------------------------
def body_mask(rgb, a):
    """1 on the plain body (light and grey), 0 on the screen, the wheel, the heart, the stickers, the swatches and the outline."""
    mx, mn = rgb.max(-1), rgb.min(-1)
    m = ((a > 200) & ((mx - mn) < 34) & (mx > 120)).astype(np.float32)
    im = Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.MinFilter(5)).filter(ImageFilter.GaussianBlur(1.2))   # a little inside the edge, soft
    return np.asarray(im, np.float32) / 255


def positions(rng, mask, face, n, r_min, r_max, tries=900):
    """Places n shapes on one face: spread out (no two close), only where the body is plain all around."""
    x0, y0, w, h = [v * S for v in FACES[face]]
    out = []
    for _ in range(tries):
        if len(out) >= n: break
        r = rng.uniform(r_min, r_max) * S
        x, y = rng.uniform(x0 + r + 6, x0 + w - r - 6), rng.uniform(y0 + r + 6, y0 + h - r - 6)
        if any(math.hypot(x - ox, y - oy) < (r + orr) * 1.9 for ox, oy, orr in out): continue
        yy, xx = np.ogrid[:mask.shape[0], :mask.shape[1]]
        ys, xs = int(y - r * 1.25), int(x - r * 1.25)
        sub = mask[max(0, ys):int(y + r * 1.25), max(0, xs):int(x + r * 1.25)]
        if sub.size == 0 or sub.min() < 0.9: continue
        out.append((x, y, r))
    return out


SKINS = {
    # name: (top colour, bottom colour of the body gradient)
    'snow':   ((246, 250, 255), (196, 222, 248)),
    'santa':  ((236, 84, 96),   (190, 40, 58)),
    'starry': ((60, 74, 156),   (26, 34, 92)),
    'sakura': ((255, 214, 230), (246, 164, 196)),
    'mint':   ((190, 240, 214), (132, 208, 176)),
    'bee':    ((255, 226, 110), (246, 190, 60)),
}
OUT = {'snow': 'music_player_snow_3d.png', 'santa': 'music_player_santa_3d.png', 'starry': 'music_player_case_starry_3d.png',
       'sakura': 'music_player_case_sakura_3d.png', 'mint': 'music_player_case_mint_3d.png', 'bee': 'music_player_case_bee_3d.png'}


def make(name):
    rng = random.Random(name)
    src = Image.open(T + 'music_player_white_3d.png').convert('RGBA')
    big = src.resize((128 * S, 128 * S), Image.LANCZOS)
    arr = np.asarray(big).astype(np.float32)
    rgb, a = arr[..., :3], arr[..., 3]
    mask = body_mask(rgb, a)
    H, W = mask.shape
    # 1. the body colour: a soft vertical gradient on every face, the light and shade of the old texture stay
    top, bot = SKINS[name]
    lum = (rgb.mean(-1) / 255.0)
    shade = np.clip((lum - 0.55) / 0.45, 0, 1.15)[..., None]            # 1 = the lightest body, lower = shaded edge
    t = np.zeros((H, W), np.float32)
    for f, (x0, y0, w, h) in FACES.items():
        t[y0 * S:(y0 + h) * S, x0 * S:(x0 + w) * S] = np.linspace(0, 1, h * S)[:, None]
    grad = np.array(top, np.float32) * (1 - t[..., None]) + np.array(bot, np.float32) * t[..., None]
    base = grad * (0.72 + 0.28 * shade)
    out = rgb * (1 - mask[..., None]) + base * mask[..., None]
    img = Image.fromarray(np.dstack([np.clip(out, 0, 255), a]).astype(np.uint8), 'RGBA')

    # 2. the pattern
    layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for face in FACES:
        big_face = face in ('front', 'back')
        n = 7 if big_face else 3
        if name in ('starry', 'snow', 'santa'):
            r0, r1 = (3.4, 5.6) if big_face else (2.2, 3.2)
        else:
            r0, r1 = (3.6, 5.4) if big_face else (2.4, 3.4)
        if name == 'bee':
            continue
        for x, y, r in positions(rng, mask, face, n, r0, r1):
            if name == 'starry':
                glow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
                ImageDraw.Draw(glow).ellipse((x - r * 1.5, y - r * 1.5, x + r * 1.5, y + r * 1.5), fill=(255, 240, 170, 70))
                layer.alpha_composite(glow.filter(ImageFilter.GaussianBlur(r * 0.6)))
                d = ImageDraw.Draw(layer)
                star(d, x, y, r * 1.15, (255, 246, 190, 255), 4, 0.32, rng.uniform(-0.2, 0.2))
            elif name == 'sakura':
                flower(d, x, y, r, (255, 255, 255, 235), (240, 120, 160, 255), rng.uniform(0, 6.28))
            elif name == 'mint':
                d.ellipse((x - r * .7, y - r * .7, x + r * .7, y + r * .7), fill=(255, 255, 255, 230))
            else:                                                       # snow, santa: little snowflakes
                snowflake(d, x, y, r * 1.1, (255, 255, 255, 245) if name == 'santa' else (120, 170, 230, 235), max(2, int(S * 0.7)))
    if name == 'bee':                                                   # even straight honey stripes
        for f, (x0, y0, w, h) in FACES.items():
            for k in range(6, h, 14):
                d.rectangle((x0 * S, (y0 + k) * S, (x0 + w) * S, (y0 + k + 5) * S), fill=(96, 64, 38, 225))
    layer_a = np.asarray(layer).astype(np.float32)
    m3 = (layer_a[..., 3] / 255.0) * mask
    res = np.asarray(img).astype(np.float32)
    res[..., :3] = res[..., :3] * (1 - m3[..., None]) + layer_a[..., :3] * m3[..., None]
    final = Image.fromarray(np.clip(res, 0, 255).astype(np.uint8), 'RGBA')
    final.resize((128, 128), Image.LANCZOS).save(T + OUT[name])


if __name__ == '__main__':
    for n in SKINS: make(n)
    print('ok')
