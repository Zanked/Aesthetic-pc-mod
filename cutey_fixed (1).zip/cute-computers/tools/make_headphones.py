"""
The headphones, one source for everything:

  python tools/make_headphones.py

writes
  src/main/resources/assets/cutemod/textures/models/armor/headphones_layer_1.png   (64x32, what is drawn on the head)
  src/main/resources/assets/cutemod/textures/item/headphones_3d.png                (512x256 smooth, the item in the inventory / hand)
  src/main/resources/assets/cutemod/models/item/headphones.json                    (the item model, same shape as on the head)
  src/main/java/dev/cutemod/client/player/HeadphonesModel.java                     (the 3D model on the head: band + two cups)
  ... and the same for every colour of VARIANTS: headphones_<colour>_layer_1.png, headphones_<colour>_3d.png and
      models/item/headphones_<colour>.json (lavender + pink cushions is the original "headphones").

Before, the headphones on the head were only a flat 64x32 armor texture glued to the helmet box, so the cups looked like thin
sticks.  Now they are real boxes: a band over the head, two risers, two cushioned cups with a heart plate.
"""
import os, math, json
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, 'src/main/resources/assets/cutemod')
JAVA = os.path.join(ROOT, 'src/main/java/dev/cutemod/client/player/HeadphonesModel.java')

LAV, LAV_L, LAV_D = (204, 190, 238), (236, 228, 252), (150, 128, 200)
PINK, PINK_D = (250, 178, 202), (226, 122, 162)
CREAM = (248, 242, 253)
HEART, HEART_L = (238, 92, 138), (255, 160, 188)
LINE = (104, 78, 150)
MOTIF = 'heart'

# the colours: name -> shell colour (the light / dark tints are made from it) and the colour of the cushions (None = the pink ones)
VARIANTS = {
    'pink':   ((250, 178, 202), (204, 190, 238)),
    'green':  ((150, 214, 140), None),
    'white':  ((240, 240, 248), None),
    'blue':   ((140, 190, 240), None),
    'orange': ((252, 184, 110), None),
    'purple': ((172, 124, 226), None),
    'yellow': ((252, 226, 110), None),
    'red':    ((238, 110, 112), None),
}
# the winter ones: shell, cushions (fluffy), plate colour, snowflake colours (the plate shows a snowflake instead of the heart)
WINTER = {
    'snow':  dict(main=(236, 244, 252), cushion=(190, 222, 250), plate=(214, 234, 252), flake=(90, 150, 220), flake_l=(150, 200, 245)),
    'santa': dict(main=(226, 66, 78),   cushion=(252, 250, 252), plate=(252, 250, 252), flake=(226, 66, 78),  flake_l=(240, 130, 138)),
    'ice':   dict(main=(150, 206, 244), cushion=(246, 250, 255), plate=(236, 246, 255), flake=(70, 130, 210), flake_l=(130, 184, 236)),
}
# the skins: the same, plus a pattern drawn over the band and the cups ('deco'); the plate keeps the heart
SKINS = {
    'panda':  dict(main=(246, 246, 250), cushion=(52, 52, 62),    plate=(246, 246, 250), flake=(238, 92, 138), flake_l=(255, 160, 188), motif='heart', deco=None),
    'starry': dict(main=(52, 66, 142),   cushion=(255, 236, 160), plate=(248, 242, 253), flake=(238, 92, 138), flake_l=(255, 160, 188), motif='heart', deco='starry'),
    'sakura': dict(main=(250, 176, 204), cushion=(255, 255, 255), plate=(255, 246, 250), flake=(238, 92, 138), flake_l=(255, 160, 188), motif='heart', deco='sakura'),
    'mint':   dict(main=(150, 222, 190), cushion=(255, 255, 255), plate=(248, 253, 250), flake=(238, 92, 138), flake_l=(255, 160, 188), motif='heart', deco='mint'),
    'bee':    dict(main=(252, 214, 80),  cushion=(70, 52, 34),    plate=(255, 250, 230), flake=(238, 92, 138), flake_l=(255, 160, 188), motif='heart', deco='bee'),
}

BASE = dict(LAV=LAV, LAV_L=LAV_L, LAV_D=LAV_D, PINK=PINK, PINK_D=PINK_D, CREAM=CREAM, HEART=HEART, HEART_L=HEART_L, MOTIF='heart')

def mix(a, b, t): return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))

def set_palette(name):
    """Makes the painting use the colours of one variant (None = the original lavender headphones)."""
    if name is None:
        globals().update(BASE)
        return
    if name in WINTER or name in SKINS:
        w = WINTER.get(name) or SKINS[name]; main = w['main']
        globals().update(LAV=main, LAV_L=mix(main, (255, 255, 255), 0.55), LAV_D=mix(main, (60, 80, 130), 0.30),
                         PINK=w['cushion'], PINK_D=mix(w['cushion'], (60, 80, 130), 0.22), CREAM=w['plate'],
                         HEART=w['flake'], HEART_L=w['flake_l'], MOTIF=w.get('motif', 'snow'))
        return
    main, cushion = VARIANTS[name]
    globals().update(MOTIF='heart', LAV=main, LAV_L=mix(main, (255, 255, 255), 0.55), LAV_D=mix(main, (70, 40, 90), 0.32),
                     PINK=cushion or BASE['PINK'], PINK_D=mix(cushion, (70, 40, 90), 0.22) if cushion else BASE['PINK_D'])

# ---- the cubes -------------------------------------------------------------------------------------------------------
# name, role, origin (x,y,z) in the head part (y grows DOWN, 0 = the neck, the head box is -8..0), size (dx,dy,dz) = size on the
# texture, grow (the box is made bigger by this on every side, the texture stays the same)
CUBES = []
def cube(name, role, o, d, g=0.0, side=0):
    CUBES.append(dict(name=name, role=role, o=o, d=d, g=g, side=side))

cube('bar',      'bar',   (-4.0, -9.6, -1.0), (8, 1, 2))
for s, sx in (('r', 1), ('l', -1)):   # r = +x, l = -x
    x = 4.0 if sx > 0 else -5.0
    cube('step_' + s,  'bar',   (x, -9.1, -1.0), (1, 1, 2))
    x = 4.6 if sx > 0 else -5.6
    cube('riser_' + s, 'bar',   (x, -8.6, -1.0), (1, 3, 2))
    x = 3.9 if sx > 0 else -5.9
    cube('cup_' + s,   'shell', (x, -6.0, -2.0), (2, 4, 4), 0.2, sx)
    x = 5.8 if sx > 0 else -6.8
    cube('plate_' + s, 'plate', (x, -5.5, -1.5), (1, 3, 3), -0.15, sx)

def unwrap_size(c):
    dx, dy, dz = c['d']
    return 2 * (dx + dz), dz + dy

def pack():
    """Simple shelf packing into the 64x32 atlas (the same way as vanilla boxes are unwrapped)."""
    x = y = rowh = 0
    for c in sorted(CUBES, key=lambda c: -unwrap_size(c)[1]):
        w, h = unwrap_size(c)
        if x + w > 64:
            x, y, rowh = 0, y + rowh, 0
        c['uv'] = (x, y)
        x += w; rowh = max(rowh, h)
    assert y + rowh <= 32, 'atlas is full'

def regions(c):
    """face -> (x, y, w, h) in atlas px (vanilla box unwrap)."""
    u, v = c['uv']; dx, dy, dz = c['d']
    return {
        'up':    (u + dz,           v,      dx, dz),
        'down':  (u + dz + dx,      v,      dx, dz),
        'west':  (u,                v + dz, dz, dy),   # -x
        'north': (u + dz,           v + dz, dx, dy),   # -z (the front)
        'east':  (u + dz + dx,      v + dz, dz, dy),   # +x
        'south': (u + 2 * dz + dx,  v + dz, dx, dy),   # +z (the back)
    }

# ---- painting --------------------------------------------------------------------------------------------------------
def lerp(a, b, t): return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))

def heart_mask(n, ss=4):
    """n x n anti-aliased heart (0..1)."""
    N = n * ss
    im = Image.new('L', (N, N), 0)
    pts = []
    for i in range(400):
        t = i / 400 * 2 * math.pi
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((N * (0.5 + x / 36), N * (0.52 + (y + 1.5) / 36)))
    ImageDraw.Draw(im).polygon(pts, fill=255)
    return np.asarray(im.resize((n, n), Image.LANCZOS), np.float32) / 255

PIXEL_HEART = ['X.X', 'XXX', '.X.']
PIXEL_SNOW = ['X.X', '.X.', 'X.X']

def snow_mask(n, ss=4):
    """n x n anti-aliased snowflake (0..1): three crossing arms with little branches."""
    N = n * ss
    im = Image.new('L', (N, N), 0)
    d = ImageDraw.Draw(im); c = N / 2; r = N * 0.46; wd = max(2, int(N * 0.075))
    for a in range(3):
        t = a * math.pi / 3
        for sgn in (-1, 1):
            ex, ey = c + sgn * r * math.cos(t), c + sgn * r * math.sin(t)
            d.line([(c, c), (ex, ey)], fill=255, width=wd)
            for f in (0.55,):
                bx, by = c + sgn * r * f * math.cos(t), c + sgn * r * f * math.sin(t)
                for da in (-0.9, 0.9):
                    d.line([(bx, by), (bx + r * 0.3 * math.cos(t + da) * sgn, by + r * 0.3 * math.sin(t + da) * sgn)], fill=255, width=max(2, wd - 1))
    return np.asarray(im.resize((n, n), Image.LANCZOS), np.float32) / 255

def paint(k):
    """Atlas painted at scale k (1 = 64x32 pixel art, 8 = smooth 512x256)."""
    W, H = 64 * k, 32 * k
    img = np.zeros((H, W, 4), np.float32)
    for c in CUBES:
        for face, (rx, ry, rw, rh) in regions(c).items():
            X0, Y0, w, h = rx * k, ry * k, rw * k, rh * k
            ys = (np.arange(h)[:, None] + 0.5) / h
            xs = (np.arange(w)[None, :] + 0.5) / w
            role = c['role']
            if face == 'up':
                top, bot = lerp(LAV, LAV_L, 0.9), lerp(LAV, LAV_L, 0.5)
            elif face == 'down':
                top = bot = PINK if role == 'bar' else LAV_D
            else:
                top, bot = lerp(LAV, LAV_L, 0.55), lerp(LAV, LAV_D, 0.55)
            col = np.zeros((h, w, 3), np.float32)
            for i in range(3):
                col[..., i] = top[i] + (bot[i] - top[i]) * ys
            if role == 'shell':
                outer = 'east' if c['side'] > 0 else 'west'
                if face in ('north', 'south', 'up', 'down'):
                    # the cushion (pink) is the half that looks at the head
                    inner = xs < 0.5 if c['side'] > 0 else xs >= 0.5
                    pad = np.broadcast_to(inner, (h, w))
                    pc = np.zeros((h, w, 3), np.float32)
                    for i in range(3):
                        pc[..., i] = PINK[i] + (PINK_D[i] - PINK[i]) * ys
                    col = np.where(pad[..., None], pc, col)
                elif face == outer:
                    # outer side of the cup: soft ring + lighter centre
                    d = np.maximum(np.abs(xs - 0.5), np.abs(ys - 0.5)) * 2
                    ring = np.clip((d - 0.78) / 0.22, 0, 1) if k > 1 else (d > 0.9).astype(np.float32)
                    cen = np.clip(1 - d / 0.8, 0, 1) * 0.35
                    col = col * (1 - ring[..., None] * 0.22) + (np.array(LAV_L, np.float32) - col) * cen[..., None]
                    if k == 1:
                        col = np.where((ring > 0.5)[..., None], np.array(LAV_D, np.float32), col)
            if role == 'plate':
                outer = 'east' if c['side'] > 0 else 'west'
                if face == outer:
                    col[...] = CREAM
                    if k == 1:
                        for yy, row in enumerate(PIXEL_SNOW if MOTIF == 'snow' else PIXEL_HEART):
                            for xx, ch in enumerate(row):
                                if ch == 'X':
                                    col[yy, xx] = HEART
                        col[0, 0] = HEART_L
                    else:
                        hc = np.zeros((h, w, 3), np.float32)
                        for i in range(3):
                            hc[..., i] = HEART_L[i] + (HEART[i] - HEART_L[i]) * np.clip(ys * 1.4 - 0.1, 0, 1)
                        # heart covers ~70% of the plate
                        sm = snow_mask(h) if MOTIF == 'snow' else heart_mask(h)
                        s2 = np.zeros((h, w), np.float32)
                        q = int(h * 0.74); off = (h - q) // 2
                        sm2 = np.asarray(Image.fromarray((sm * 255).astype(np.uint8)).resize((q, q), Image.LANCZOS), np.float32) / 255
                        s2[off:off + q, off:off + q] = sm2
                        col = col * (1 - s2[..., None]) + hc * s2[..., None]
                else:
                    col = np.array(lerp(PINK, PINK_D, 0.4), np.float32) + np.zeros((h, w, 3), np.float32)
            # a thin darker rim on every face makes the toy look (only on the smooth version)
            if k > 1:
                e = np.minimum(np.minimum(xs, 1 - xs) * w, np.minimum(ys, 1 - ys) * h)
                rim = np.clip(1 - e / (0.55 * k), 0, 1)[..., None] * 0.16
                col = col * (1 - rim) + np.array(LINE, np.float32) * rim
            img[Y0:Y0 + h, X0:X0 + w, :3] = col
            img[Y0:Y0 + h, X0:X0 + w, 3] = 255
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), 'RGBA')

def skin_deco(img, k, kind):
    """Draws the pattern of a skin over the band and the cups (never over the plate with the heart): shapes with soft edges,
    laid out evenly on every face (done on a x4 canvas and shrunk, so nothing looks like loose pixels)."""
    Z = 4
    W, H = img.size
    big = img.resize((W * Z, H * Z), Image.NEAREST if k == 1 else Image.LANCZOS)
    layer = Image.new('RGBA', big.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for c in CUBES:
        if c['role'] == 'plate':
            continue
        for face, (rx, ry, rw, rh) in regions(c).items():
            X0, Y0, w, h = rx * k * Z, ry * k * Z, rw * k * Z, rh * k * Z
            u = min(w, h)                                   # the size the shapes are made from
            if kind == 'bee':
                per = int(3.0 * k * Z)
                for yy in range(int(0.9 * k * Z), h, per):
                    d.rectangle((X0, Y0 + yy, X0 + w - 1, Y0 + min(h, yy + int(1.1 * k * Z)) - 1), fill=(120, 80, 40, 225))
                continue
            if w < 2 * k * Z or h < 2 * k * Z:
                continue
            cx, cy = X0 + w / 2, Y0 + h / 2
            if kind == 'mint':                               # one dot in the middle (a row of them on the long band)
                n = max(1, int(round(w / (3.2 * k * Z)))) if w > h * 1.6 else 1
                for i in range(n):
                    x = X0 + w * (i + 0.5) / n
                    r = min(u * 0.26, 1.0 * k * Z)
                    d.ellipse((x - r, cy - r, x + r, cy + r), fill=(255, 255, 255, 240))
            elif kind == 'starry':
                n = max(1, int(round(w / (3.4 * k * Z)))) if w > h * 1.6 else 1
                for i in range(n):
                    x = X0 + w * (i + 0.5) / n
                    r = min(u * 0.34, 1.25 * k * Z)
                    pts = []
                    for j in range(8):
                        rr = r if j % 2 == 0 else r * 0.34
                        a = -math.pi / 2 + j * math.pi / 4
                        pts.append((x + rr * math.cos(a), cy + rr * math.sin(a)))
                    d.polygon(pts, fill=(255, 244, 176, 255))
            elif kind == 'sakura':
                n = max(1, int(round(w / (3.6 * k * Z)))) if w > h * 1.6 else 1
                for i in range(n):
                    x = X0 + w * (i + 0.5) / n
                    r = min(u * 0.34, 1.2 * k * Z)
                    for j in range(5):
                        a = j * 2 * math.pi / 5 - math.pi / 2
                        px, py = x + r * 0.55 * math.cos(a), cy + r * 0.55 * math.sin(a)
                        d.ellipse((px - r * .5, py - r * .5, px + r * .5, py + r * .5), fill=(255, 255, 255, 240))
                    d.ellipse((x - r * .2, cy - r * .2, x + r * .2, cy + r * .2), fill=(238, 120, 160, 255))
    out = big.copy()
    out.alpha_composite(Image.composite(layer, Image.new('RGBA', big.size, (0, 0, 0, 0)), big.getchannel('A')))
    return out.resize((W, H), Image.BOX if k == 1 else Image.LANCZOS)

# ---- item model json --------------------------------------------------------------------------------------------------
def item_json(color=None):
    cy = 2.35
    els = []
    for c in CUBES:
        x, y, z = c['o']; dx, dy, dz = c['d']; g = c['g']
        frm = [8 + x - g, cy - (y + dy + g), 8 + z - g]
        to = [8 + x + dx + g, cy - (y - g), 8 + z + dz + g]
        faces = {}
        for f, (rx, ry, rw, rh) in regions(c).items():
            faces[f] = {'uv': [round(rx / 4, 4), round(ry / 2, 4), round((rx + rw) / 4, 4), round((ry + rh) / 2, 4)], 'texture': '#t'}
        els.append({'name': c['name'], 'from': [round(v, 4) for v in frm], 'to': [round(v, 4) for v in to], 'faces': faces})
    if color:   # same shape, other texture
        t = 'cutemod:item/headphones_%s_3d' % color
        return {'parent': 'cutemod:item/headphones', 'textures': {'particle': t, 't': t}, 'render_type': 'minecraft:cutout'}
    return {
        'credit': 'cute headphones: same shape as on the head (made by tools/make_headphones.py)',
        'ambientocclusion': False,
        'texture_size': [128, 64],
        'textures': {'particle': 'cutemod:item/headphones_3d', 't': 'cutemod:item/headphones_3d'},
        'elements': els,
        'display': {
            'gui': {'rotation': [20, 30, 0], 'translation': [0, -0.4, 0], 'scale': [1.0, 1.0, 1.0]},
            'ground': {'rotation': [0, 0, 0], 'translation': [0, 2.5, 0], 'scale': [0.5, 0.5, 0.5]},
            'fixed': {'rotation': [0, 180, 0], 'translation': [0, 0, 0], 'scale': [0.9, 0.9, 0.9]},
            'thirdperson_righthand': {'rotation': [0, 0, 0], 'translation': [0, 2.5, 1], 'scale': [0.45, 0.45, 0.45]},
            'thirdperson_lefthand': {'rotation': [0, 0, 0], 'translation': [0, 2.5, 1], 'scale': [0.45, 0.45, 0.45]},
            'firstperson_righthand': {'rotation': [0, 35, 0], 'translation': [0, 0, 0], 'scale': [0.5, 0.5, 0.5]},
            'firstperson_lefthand': {'rotation': [0, -35, 0], 'translation': [0, 0, 0], 'scale': [0.5, 0.5, 0.5]},
        },
        'render_type': 'minecraft:cutout',
    }

# ---- java --------------------------------------------------------------------------------------------------------------
def f(v):
    s = ('%.2f' % v).rstrip('0').rstrip('.')
    return (s if s not in ('', '-0') else '0') + 'F'

def java():
    lines = []
    for c in CUBES:
        x, y, z = c['o']; dx, dy, dz = c['d']; u, v = c['uv']
        grow = '' if c['g'] == 0 else ', new CubeDeformation(%s)' % f(c['g'])
        lines.append('                // %s\n                .texOffs(%d, %d).addBox(%s, %s, %s, %s, %s, %s%s)'
                     % (c['name'], u, v, f(x), f(y), f(z), f(dx), f(dy), f(dz), grow))
    cubes = '\n'.join(lines)
    return JAVA_TEMPLATE.replace('%CUBES%', cubes)

JAVA_TEMPLATE = '''package dev.cutemod.client.player;

import dev.cutemod.CuteMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;

/**
 * The headphones on the head: a real 3D model (band over the head, two risers, two cups with a heart plate) instead of the flat
 * armor texture glued to the helmet box. The cubes are written by tools/make_headphones.py (do not edit them by hand: edit the
 * script and run it again, it also redraws textures/models/armor/headphones_layer_1.png and the item model).
 * The texture is still the armor layer of the material, so everything else (slot, right click) stays as it was.
 */
public final class HeadphonesModel {
    private HeadphonesModel() {}

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "headphones"), "main");

    private static HumanoidModel<LivingEntity> baked;

    /** Called after every resource reload: the model is baked again at the next frame. */
    public static void reset() { baked = null; }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create()
%CUBES%,
                PartPose.ZERO);
        // the humanoid model wants all of its parts, the others stay empty
        for (String n : new String[]{"hat", "body", "right_arm", "left_arm", "right_leg", "left_leg"})
            root.addOrReplaceChild(n, CubeListBuilder.create(), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 32);
    }

    private static HumanoidModel<LivingEntity> model() {
        if (baked == null) baked = new HumanoidModel<>(Minecraft.getInstance().getEntityModels().bakeLayer(LAYER));
        return baked;
    }

    /** Tells the armor layer to draw our model instead of the helmet box. */
    public static final class Ext implements IClientItemExtensions {
        @Override
        public HumanoidModel<?> getHumanoidArmorModel(LivingEntity entity, ItemStack stack, EquipmentSlot slot, HumanoidModel<?> original) {
            return model();
        }
    }
}
'''

if __name__ == '__main__':
    pack()
    paint(1).save(os.path.join(RES, 'textures/models/armor/headphones_layer_1.png'))
    paint(8).resize((128, 64), Image.LANCZOS).save(os.path.join(RES, 'textures/item/headphones_3d.png'))
    json.dump(item_json(), open(os.path.join(RES, 'models/item/headphones.json'), 'w'), indent=1)
    open(JAVA, 'w').write(java())
    for col in list(VARIANTS) + list(WINTER) + list(SKINS):
        set_palette(col)
        deco = SKINS.get(col, {}).get('deco')
        small, big = paint(1), paint(8)
        if deco:                                   # the pattern is only on the item: on the head (64x32) it would be loose pixels
            big = skin_deco(big, 8, deco)
        small.save(os.path.join(RES, 'textures/models/armor/headphones_%s_layer_1.png' % col))
        big.resize((128, 64), Image.LANCZOS).save(os.path.join(RES, 'textures/item/headphones_%s_3d.png' % col))
        json.dump(item_json(col), open(os.path.join(RES, 'models/item/headphones_%s.json' % col), 'w'), indent=1)
    set_palette(None)
    print('ok', len(CUBES), 'cubes')
