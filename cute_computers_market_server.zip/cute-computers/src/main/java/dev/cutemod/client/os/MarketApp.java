package dev.cutemod.client.os;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** CuteMarket: order food and clothes, follow the delivery, dress up and eat. */
public class MarketApp extends App {
    private static final int HEAD = 18, PAGE = 8;
    private static final int BG = 0xFFFFF6FB, PINK = 0xFFF58FB8, TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8;
    private static final int ACCENT = 0xFFB57BD6, GREEN = 0xFF5BBF6A, RED = 0xFFE5484D, BORDER = 0xFFEAD6E6;

    private int tab, shopKind, page, meSub, scroll;
    private boolean express;
    private final Map<String, Integer> cart = new LinkedHashMap<>();

    @Override
    public Component title() { return Component.translatable("cutemod.os.market"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.market"); }

    @Override
    public Component status() {
        int a = Market.active();
        return a > 0 ? Component.translatable("cutemod.market.status", a) : Component.empty();
    }

    @Override
    public void tick() { Market.tick(); }

    private int cartCount() {
        int n = 0;
        for (int v : cart.values()) n += v;
        return n;
    }

    // ---------- small helpers ----------
    private static void btn(GuiGraphics g, int x, int y, int w, int h, String label, boolean enabled, boolean hover, int color) {
        Font f = font();
        rect(g, x, y, w, h, !enabled ? 0xFFDCCFE0 : hover ? mix(color, 0xFFFFFF, 0.25f) : color);
        g.drawString(f, label, x + (w - f.width(label)) / 2, y + (h - 8) / 2 + 1, enabled ? 0xFFFFFFFF : 0xFF9A8FA8, false);
    }

    private static void txt(GuiGraphics g, String s, int x, int y, int argb) { g.drawString(font(), s, x, y, argb, false); }

    private static void rtxt(GuiGraphics g, String s, int rx, int y, int argb) { g.drawString(font(), s, rx - font().width(s), y, argb, false); }

    private static String name(String id) { return t("cutemod.market.item." + id); }

    private static String clip(String s, int w) { return font().plainSubstrByWidth(s, w); }

    // ---------- pictures ----------
    /** A 24 x 20 picture of an item, drawn at x,y and scaled. */
    private static void icon(GuiGraphics g, String id, int x, int y, float s) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(s, s, 1f);
        switch (id) {
            case "pizza" -> {
                rect(g, 2, 1, 20, 3, 0xFFD9964A);
                for (int r = 0; r < 14; r++) rect(g, 2 + r / 2, 4 + r, 20 - r, 1, 0xFFFFC94A);
                disc(g, 9, 8, 2, 0xFFE5484D); disc(g, 15, 7, 2, 0xFFE5484D); disc(g, 12, 13, 2, 0xFFE5484D);
            }
            case "burger" -> {
                rect(g, 3, 2, 18, 5, 0xFFE0A050); rect(g, 2, 7, 20, 2, 0xFF5BBF5A);
                rect(g, 3, 9, 18, 3, 0xFF6B3A20); rect(g, 3, 12, 18, 2, 0xFFFFD040);
                rect(g, 3, 14, 18, 4, 0xFFE0A050);
                rect(g, 7, 3, 2, 1, 0xFFFFFFFF); rect(g, 13, 4, 2, 1, 0xFFFFFFFF); rect(g, 17, 3, 2, 1, 0xFFFFFFFF);
            }
            case "sushi" -> {
                rect(g, 4, 8, 16, 8, 0xFFFFFFFF); rect(g, 3, 4, 18, 5, 0xFFFF8A6A);
                rect(g, 10, 4, 3, 12, 0xFF2A3A2A); rect(g, 5, 16, 14, 1, 0xFFDDDDDD);
            }
            case "ramen" -> {
                rect(g, 3, 8, 18, 9, 0xFFE5484D); rect(g, 5, 17, 14, 2, 0xFFB03030);
                rect(g, 4, 6, 16, 3, 0xFFFFE08A); disc(g, 9, 6, 3, 0xFFFFFFFF); disc(g, 9, 6, 1, 0xFFFFC832);
                rect(g, 14, 3, 1, 3, 0xFFB0B0B0); rect(g, 17, 2, 1, 4, 0xFFB0B0B0);
            }
            case "bubbletea" -> {
                rect(g, 7, 3, 11, 2, 0xFFFFFFFF); rect(g, 8, 5, 9, 13, 0xFFF3D9B1);
                rect(g, 12, 0, 2, 4, 0xFFE5484D);
                disc(g, 10, 16, 1, 0xFF3A2A3A); disc(g, 13, 16, 1, 0xFF3A2A3A); disc(g, 15, 15, 1, 0xFF3A2A3A); disc(g, 11, 14, 1, 0xFF3A2A3A);
            }
            case "cupcake" -> {
                rect(g, 6, 10, 12, 7, 0xFFE5A0C0); for (int k = 0; k < 4; k++) rect(g, 8 + k * 3, 10, 1, 7, 0xFFC878A0);
                rect(g, 5, 6, 14, 5, 0xFFFFFFFF); rect(g, 8, 3, 8, 4, 0xFFFFD6E8);
                disc(g, 12, 3, 2, 0xFFE5484D);
            }
            case "toast" -> {
                rect(g, 3, 5, 18, 12, 0xFFE0B060); rect(g, 4, 6, 16, 10, 0xFFF5D090);
                rect(g, 4, 6, 16, 3, 0xFFFFC832); rect(g, 6, 9, 2, 3, 0xFFFFC832); rect(g, 14, 9, 2, 4, 0xFFFFC832);
                rect(g, 9, 7, 4, 3, 0xFFFFF0A0);
            }
            case "icecream" -> {
                for (int r = 0; r < 9; r++) rect(g, 7 + r / 2, 11 + r, 10 - r, 1, 0xFFD9964A);
                disc(g, 12, 8, 5, 0xFFFFB6D2); disc(g, 12, 4, 4, 0xFFFFFFFF); disc(g, 12, 0, 1, 0xFFE5484D);
            }
            case "cap" -> { rect(g, 4, 6, 14, 7, 0xFFE5484D); rect(g, 12, 11, 11, 3, 0xFFB03030); rect(g, 10, 5, 2, 1, 0xFFB03030); }
            case "beanie" -> {
                rect(g, 5, 6, 14, 10, 0xFF5A8AE0); rect(g, 5, 13, 14, 3, 0xFF3A5ABF); disc(g, 12, 5, 3, 0xFFFFFFFF);
            }
            case "bunny" -> {
                rect(g, 6, 0, 4, 13, 0xFFF58FB8); rect(g, 14, 0, 4, 13, 0xFFF58FB8);
                rect(g, 7, 2, 2, 8, 0xFFFFD6E8); rect(g, 15, 2, 2, 8, 0xFFFFD6E8); rect(g, 4, 12, 16, 3, 0xFFFFFFFF);
            }
            case "witch" -> {
                rect(g, 10, 0, 5, 4, 0xFF6A3AA0); rect(g, 8, 4, 9, 4, 0xFF6A3AA0); rect(g, 6, 8, 13, 3, 0xFF6A3AA0);
                rect(g, 6, 9, 13, 2, 0xFFFFC832); rect(g, 1, 11, 22, 3, 0xFF4A2A6A);
            }
            case "tee" -> {
                rect(g, 6, 4, 12, 13, 0xFFF7F7F7); rect(g, 2, 4, 5, 5, 0xFFF7F7F7); rect(g, 17, 4, 5, 5, 0xFFF7F7F7);
                rect(g, 10, 4, 4, 2, 0xFFDDD6E0); rect(g, 10, 9, 2, 2, 0xFFF58FB8); rect(g, 13, 9, 2, 2, 0xFFF58FB8); rect(g, 11, 11, 3, 2, 0xFFF58FB8);
            }
            case "sailor" -> {
                rect(g, 6, 4, 12, 13, 0xFF4A6FC8); rect(g, 2, 4, 5, 6, 0xFF4A6FC8); rect(g, 17, 4, 5, 6, 0xFF4A6FC8);
                rect(g, 8, 4, 8, 4, 0xFFFFFFFF); rect(g, 11, 8, 3, 3, 0xFFE5484D);
            }
            case "hoodie" -> {
                rect(g, 6, 4, 12, 13, 0xFFF0801C); rect(g, 2, 4, 5, 9, 0xFFF0801C); rect(g, 17, 4, 5, 9, 0xFFF0801C);
                rect(g, 8, 2, 8, 3, 0xFFC86010); rect(g, 8, 12, 8, 4, 0xFFD97A20); rect(g, 11, 5, 1, 4, 0xFFFFFFFF); rect(g, 13, 5, 1, 4, 0xFFFFFFFF);
            }
            case "sneakers" -> {
                rect(g, 2, 8, 9, 7, 0xFFFFFFFF); rect(g, 2, 14, 10, 3, 0xFFF58FB8); rect(g, 6, 8, 4, 1, 0xFFB57BD6);
                rect(g, 13, 8, 9, 7, 0xFFFFFFFF); rect(g, 13, 14, 10, 3, 0xFFF58FB8); rect(g, 17, 8, 4, 1, 0xFFB57BD6);
            }
            case "boots" -> {
                rect(g, 3, 3, 6, 11, 0xFF8A5A3A); rect(g, 3, 12, 9, 5, 0xFF6A4026);
                rect(g, 14, 3, 6, 11, 0xFF8A5A3A); rect(g, 14, 12, 9, 5, 0xFF6A4026);
            }
            case "glasses" -> {
                rect(g, 2, 7, 9, 7, 0xFF3A2A3A); rect(g, 13, 7, 9, 7, 0xFF3A2A3A); rect(g, 11, 9, 2, 2, 0xFF3A2A3A);
                rect(g, 3, 8, 7, 5, 0xFF5A4A7A); rect(g, 14, 8, 7, 5, 0xFF5A4A7A);
            }
            case "scarf" -> {
                rect(g, 2, 5, 20, 5, 0xFFE5484D); rect(g, 15, 9, 5, 10, 0xFFE5484D);
                rect(g, 7, 5, 2, 5, 0xFFFFFFFF); rect(g, 16, 14, 4, 2, 0xFFFFFFFF);
            }
            case "wings" -> {
                rect(g, 1, 3, 9, 12, 0xFFFFFFFF); rect(g, 3, 14, 6, 3, 0xFFFFFFFF); rect(g, 14, 3, 9, 12, 0xFFFFFFFF); rect(g, 15, 14, 6, 3, 0xFFFFFFFF);
                rect(g, 4, 5, 1, 8, 0xFFDDD6F0); rect(g, 7, 5, 1, 8, 0xFFDDD6F0); rect(g, 16, 5, 1, 8, 0xFFDDD6F0); rect(g, 19, 5, 1, 8, 0xFFDDD6F0);
            }
            default -> disc(g, 12, 10, 8, 0xFFB57BD6);
        }
        g.pose().popPose();
    }

    /** The player's doll. Logical size 32 x 56, s = size of one pixel. */
    public static void drawAvatar(GuiGraphics g, int x, int y, int s) {
        String head = Market.worn(Market.HEAD), top = Market.worn(Market.TOP), feet = Market.worn(Market.FEET), ex = Market.worn(Market.EXTRA);
        int skin = 0xFFFFE0CC, hair = 0xFF6B4226;
        if (ex.equals("wings")) {
            p(g, x, y, s, 1, 22, 8, 12, 0xFFFFFFFF); p(g, x, y, s, 23, 22, 8, 12, 0xFFFFFFFF);
            p(g, x, y, s, 3, 24, 1, 8, 0xFFDDD6F0); p(g, x, y, s, 27, 24, 1, 8, 0xFFDDD6F0);
        }
        // hair (back), head
        p(g, x, y, s, 8, 12, 16, 14, hair);
        p(g, x, y, s, 9, 14, 14, 12, skin);
        p(g, x, y, s, 8, 12, 16, 5, hair);
        p(g, x, y, s, 8, 16, 2, 8, hair); p(g, x, y, s, 22, 16, 2, 8, hair);
        p(g, x, y, s, 12, 19, 2, 3, 0xFF3A2A5A); p(g, x, y, s, 18, 19, 2, 3, 0xFF3A2A5A);
        p(g, x, y, s, 12, 19, 1, 1, 0xFFFFFFFF); p(g, x, y, s, 18, 19, 1, 1, 0xFFFFFFFF);
        p(g, x, y, s, 10, 23, 2, 1, 0xFFFF9FA8); p(g, x, y, s, 20, 23, 2, 1, 0xFFFF9FA8);
        p(g, x, y, s, 15, 24, 2, 1, 0xFFC85A6A);
        // body, arms, legs
        p(g, x, y, s, 7, 28, 3, 11, skin); p(g, x, y, s, 22, 28, 3, 11, skin);
        p(g, x, y, s, 10, 27, 12, 13, 0xFFFFFFFF);
        p(g, x, y, s, 10, 40, 12, 6, 0xFF5A6AA8);
        p(g, x, y, s, 11, 46, 4, 8, skin); p(g, x, y, s, 17, 46, 4, 8, skin);
        // clothes
        switch (top) {
            case "tee" -> { p(g, x, y, s, 10, 27, 12, 13, 0xFFF7F7F7); p(g, x, y, s, 7, 27, 3, 5, 0xFFF7F7F7); p(g, x, y, s, 22, 27, 3, 5, 0xFFF7F7F7);
                p(g, x, y, s, 13, 31, 2, 2, 0xFFF58FB8); p(g, x, y, s, 17, 31, 2, 2, 0xFFF58FB8); p(g, x, y, s, 14, 33, 4, 2, 0xFFF58FB8); }
            case "sailor" -> { p(g, x, y, s, 10, 27, 12, 13, 0xFF4A6FC8); p(g, x, y, s, 7, 27, 3, 9, 0xFF4A6FC8); p(g, x, y, s, 22, 27, 3, 9, 0xFF4A6FC8);
                p(g, x, y, s, 11, 27, 10, 4, 0xFFFFFFFF); p(g, x, y, s, 15, 31, 2, 3, 0xFFE5484D); }
            case "hoodie" -> { p(g, x, y, s, 10, 27, 12, 14, 0xFFF0801C); p(g, x, y, s, 7, 27, 3, 12, 0xFFF0801C); p(g, x, y, s, 22, 27, 3, 12, 0xFFF0801C);
                p(g, x, y, s, 9, 25, 14, 3, 0xFFC86010); p(g, x, y, s, 12, 34, 8, 5, 0xFFD97A20); }
            default -> { }
        }
        switch (feet) {
            case "sneakers" -> { p(g, x, y, s, 10, 51, 6, 4, 0xFFFFFFFF); p(g, x, y, s, 16, 51, 6, 4, 0xFFFFFFFF); p(g, x, y, s, 10, 54, 6, 1, 0xFFF58FB8); p(g, x, y, s, 16, 54, 6, 1, 0xFFF58FB8); }
            case "boots" -> { p(g, x, y, s, 10, 47, 5, 8, 0xFF8A5A3A); p(g, x, y, s, 17, 47, 5, 8, 0xFF8A5A3A); p(g, x, y, s, 9, 53, 7, 2, 0xFF6A4026); p(g, x, y, s, 16, 53, 7, 2, 0xFF6A4026); }
            default -> { }
        }
        switch (ex) {
            case "glasses" -> { p(g, x, y, s, 10, 18, 6, 5, 0xFF3A2A3A); p(g, x, y, s, 16, 18, 6, 5, 0xFF3A2A3A);
                p(g, x, y, s, 11, 19, 4, 3, 0xFF5A4A7A); p(g, x, y, s, 17, 19, 4, 3, 0xFF5A4A7A); p(g, x, y, s, 15, 19, 2, 1, 0xFF3A2A3A); }
            case "scarf" -> { p(g, x, y, s, 9, 25, 14, 3, 0xFFE5484D); p(g, x, y, s, 19, 27, 3, 9, 0xFFE5484D); p(g, x, y, s, 19, 31, 3, 1, 0xFFFFFFFF); }
            default -> { }
        }
        switch (head) {
            case "cap" -> { p(g, x, y, s, 8, 9, 16, 6, 0xFFE5484D); p(g, x, y, s, 6, 14, 14, 2, 0xFFB03030); }
            case "beanie" -> { p(g, x, y, s, 8, 8, 16, 8, 0xFF5A8AE0); p(g, x, y, s, 8, 14, 16, 2, 0xFF3A5ABF); p(g, x, y, s, 14, 5, 4, 4, 0xFFFFFFFF); }
            case "bunny" -> { p(g, x, y, s, 10, 0, 3, 13, 0xFFF58FB8); p(g, x, y, s, 19, 0, 3, 13, 0xFFF58FB8);
                p(g, x, y, s, 11, 2, 1, 9, 0xFFFFD6E8); p(g, x, y, s, 20, 2, 1, 9, 0xFFFFD6E8); p(g, x, y, s, 8, 12, 16, 2, 0xFFFFFFFF); }
            case "witch" -> { p(g, x, y, s, 13, 0, 6, 5, 0xFF6A3AA0); p(g, x, y, s, 11, 5, 10, 5, 0xFF6A3AA0); p(g, x, y, s, 9, 10, 14, 3, 0xFF6A3AA0);
                p(g, x, y, s, 9, 11, 14, 1, 0xFFFFC832); p(g, x, y, s, 5, 12, 22, 2, 0xFF4A2A6A); }
            default -> { }
        }
    }

    private static void p(GuiGraphics g, int x, int y, int s, int px, int py, int pw, int ph, int argb) {
        g.fill(x + px * s, y + py * s, x + (px + pw) * s, y + (py + ph) * s, argb);
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, BG);
        rect(g, 0, 0, W, HEAD, PINK);
        String[] tabs = {t("cutemod.market.tab.shop"), t("cutemod.market.tab.cart", cartCount()), t("cutemod.market.tab.orders", Market.active()), t("cutemod.market.tab.me")};
        for (int i = 0; i < 4; i++) {
            int tx = 4 + i * 74;
            boolean sel = i == tab;
            rect(g, tx, 3, 72, HEAD - 3, sel ? BG : (in(mx, my, tx, 3, 72, HEAD - 3) ? 0xFFFFB6D2 : 0xFFF9A3C4));
            g.drawString(f, tabs[i], tx + (72 - f.width(tabs[i])) / 2, 6, sel ? PINK : 0xFFFFFFFF, false);
        }
        switch (tab) {
            case 0 -> renderShop(g, mx, my);
            case 1 -> renderCart(g, mx, my);
            case 2 -> renderOrders(g, mx, my);
            default -> renderMe(g, mx, my);
        }
    }

    private void renderShop(GuiGraphics g, int mx, int my) {
        Font f = font();
        for (int k = 0; k < 2; k++) {
            int cx = 6 + k * 62;
            boolean sel = shopKind == k;
            rect(g, cx, 21, 58, 12, sel ? ACCENT : (in(mx, my, cx, 21, 58, 12) ? 0xFFEAD6F5 : 0xFFF1E4F7));
            String s = t("cutemod.market.kind." + k);
            g.drawString(f, s, cx + (58 - f.width(s)) / 2, 23, sel ? 0xFFFFFFFF : TEXT, false);
        }
        List<Market.Item> list = Market.of(shopKind);
        int pages = Math.max(1, (list.size() + PAGE - 1) / PAGE);
        page = Math.min(page, pages - 1);
        if (pages > 1) {
            btn(g, W - 52, 21, 14, 12, "<", page > 0, in(mx, my, W - 52, 21, 14, 12), ACCENT);
            btn(g, W - 20, 21, 14, 12, ">", page < pages - 1, in(mx, my, W - 20, 21, 14, 12), ACCENT);
            String ps = (page + 1) + "/" + pages;
            g.drawString(f, ps, W - 36 - f.width(ps) / 2, 23, MUTED, false);
        }
        for (int i = 0; i < PAGE; i++) {
            int idx = page * PAGE + i;
            if (idx >= list.size()) break;
            Market.Item it = list.get(idx);
            int cx = 6 + (i % 4) * 72, cy = 36 + (i / 4) * 61;
            boolean hov = in(mx, my, cx, cy, 70, 58);
            rect(g, cx, cy, 70, 58, hov ? 0xFFFFE6F2 : 0xFFFFFFFF);
            rect(g, cx, cy, 70, 1, BORDER); rect(g, cx, cy + 57, 70, 1, BORDER);
            rect(g, cx, cy, 1, 58, BORDER); rect(g, cx + 69, cy, 1, 58, BORDER);
            icon(g, it.id(), cx + 23, cy + 4, 1.0f);
            String nm = clip(name(it.id()), 66);
            g.drawString(f, nm, cx + (70 - f.width(nm)) / 2, cy + 27, TEXT, false);
            boolean owned = it.kind() == Market.CLOTHES && Market.owns(it.id());
            String price = owned ? t("cutemod.market.owned") : Integer.toString(it.price());
            int pw = f.width(price) + (owned ? 0 : 10);
            int px = cx + (70 - pw) / 2;
            if (!owned) Progress.drawCoin(g, px, cy + 38);
            g.drawString(f, price, px + (owned ? 0 : 10), cy + 38, owned ? GREEN : (Progress.coins() >= it.price() ? 0xFFB98A10 : RED), false);
            String sub = it.kind() == Market.FOOD ? t("cutemod.market.fx", it.pct(), it.mins()) : t("cutemod.market.slot." + it.slot());
            g.drawString(f, clip(sub, 66), cx + (70 - Math.min(66, f.width(sub))) / 2, cy + 48, MUTED, false);
            Integer in = cart.get(it.id());
            if (in != null) {
                rect(g, cx + 54, cy + 2, 14, 11, GREEN);
                String q = "x" + in;
                g.drawString(f, q, cx + 61 - f.width(q) / 2, cy + 4, 0xFFFFFFFF, false);
            }
        }
    }

    private void renderCart(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<Map.Entry<String, Integer>> rows = new java.util.ArrayList<>(cart.entrySet());
        if (rows.isEmpty()) {
            String s = t("cutemod.market.cart_empty");
            g.drawString(f, s, (W - f.width(s)) / 2, 70, MUTED, false);
        }
        g.enableScissor(shell.absX(), shell.absY() + HEAD + 2, shell.absX() + W, shell.absY() + 124);
        for (int i = 0; i < rows.size(); i++) {
            int y = 22 + i * 17 - scroll;
            if (y < HEAD - 14 || y > 124) continue;
            String id = rows.get(i).getKey();
            Market.Item it = Market.item(id);
            int q = rows.get(i).getValue();
            rect(g, 4, y, W - 8, 16, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFFEFF7);
            icon(g, id, 6, y + 1, 0.7f);
            txt(g, clip(name(id), 120), 26, y + 4, TEXT);
            btn(g, 156, y + 2, 12, 12, "-", true, in(mx, my, 156, y + 2, 12, 12), ACCENT);
            String qs = Integer.toString(q);
            txt(g, qs, 181 - font().width(qs) / 2, y + 4, TEXT);
            boolean canPlus = it.kind() == Market.FOOD && q < 9;
            btn(g, 194, y + 2, 12, 12, "+", canPlus, canPlus && in(mx, my, 194, y + 2, 12, 12), ACCENT);
            rtxt(g, Integer.toString(it.price() * q), W - 20, y + 4, 0xFFB98A10);
            Progress.drawCoin(g, W - 16, y + 4);
        }
        g.disableScissor();
        // bottom bar
        rect(g, 0, 125, W, H - 125, 0xFFFBEAF3);
        rect(g, 6, 129, 10, 10, express ? GREEN : 0xFFFFFFFF);
        rect(g, 6, 129, 10, 1, BORDER); rect(g, 6, 138, 10, 1, BORDER); rect(g, 6, 129, 1, 10, BORDER); rect(g, 15, 129, 1, 10, BORDER);
        if (express) { rect(g, 8, 133, 2, 2, 0xFFFFFFFF); rect(g, 10, 134, 2, 2, 0xFFFFFFFF); rect(g, 12, 131, 2, 4, 0xFFFFFFFF); }
        txt(g, t("cutemod.market.express", Market.EXPRESS_PCT, Market.EXPRESS_SPEED), 21, 131, TEXT);
        int total = Market.total(cart, express);
        txt(g, t("cutemod.market.total", total), 6, 146, TEXT);
        boolean can = !cart.isEmpty() && Progress.coins() >= total;
        if (!cart.isEmpty() && Progress.coins() < total) txt(g, t("cutemod.market.poor"), 90, 146, RED);
        btn(g, W - 92, 140, 86, 20, t("cutemod.market.order"), can, can && in(mx, my, W - 92, 140, 86, 20), GREEN);
    }

    private void renderOrders(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<Market.Order> list = Market.orders();
        if (list.isEmpty()) {
            String s = t("cutemod.market.no_orders");
            g.drawString(f, s, (W - f.width(s)) / 2, 70, MUTED, false);
        }
        g.enableScissor(shell.absX(), shell.absY() + HEAD, shell.absX() + W, shell.absY() + H);
        for (int i = 0; i < list.size(); i++) {
            Market.Order o = list.get(i);
            int y = 21 + i * 24 - scroll;
            if (y < HEAD - 22 || y > H) continue;
            rect(g, 4, y, W - 8, 23, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFFEFF7);
            icon(g, o.id, 6, y + 2, 0.8f);
            txt(g, clip(name(o.id) + (o.qty > 1 ? " x" + o.qty : ""), 150), 34, y + 3, TEXT);
            if (o.done) {
                txt(g, t("cutemod.market.delivered"), 34, y + 13, MUTED);
            } else if (Market.arrived(o)) {
                txt(g, t("cutemod.market.arrived"), 34, y + 13, GREEN);
                btn(g, W - 76, y + 3, 68, 17, t("cutemod.market.collect"), true, in(mx, my, W - 76, y + 3, 68, 17), GREEN);
            } else {
                int total = Math.max(1000, (int) (Market.item(o.id).secs() * 1000L / 3));
                float frac = Math.max(0f, Math.min(1f, 1f - Market.secondsLeft(o) * 1000f / Math.max(total, Market.item(o.id).secs() * 1000f)));
                rect(g, 34, y + 14, 150, 5, 0xFFEAD6E6);
                rect(g, 34, y + 14, Math.round(150 * frac), 5, ACCENT);
                int cx = 34 + Math.round(150 * frac);
                rect(g, Math.max(34, cx - 3), y + 12, 6, 8, PINK);    // the courier
                int s = Market.secondsLeft(o);
                rtxt(g, (s / 60) + ":" + String.format("%02d", s % 60), W - 10, y + 7, MUTED);
            }
        }
        g.disableScissor();
    }

    private void renderMe(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 4, 20, 100, 144, 0xFFFFFFFF);
        rect(g, 4, 20, 100, 1, BORDER); rect(g, 4, 163, 100, 1, BORDER); rect(g, 4, 20, 1, 144, BORDER); rect(g, 103, 20, 1, 144, BORDER);
        drawAvatar(g, 4 + (100 - 64) / 2, 22, 2);
        int sp = Market.stylePct(), fp = Market.fedPctNow();
        txt(g, t("cutemod.market.style", sp), 8, 135, TEXT);
        int left = Market.fedLeftSec();
        txt(g, left > 0 ? t("cutemod.market.fed", fp, left / 60, String.format("%02d", left % 60)) : t("cutemod.market.hungry"), 8, 146, left > 0 ? GREEN : MUTED);
        txt(g, t("cutemod.market.bonus", Math.round((Market.bonus() - 1f) * 100)), 8, 156, 0xFFB98A10);

        for (int k = 0; k < 2; k++) {
            int cx = 108 + k * 64;
            boolean sel = meSub == k;
            rect(g, cx, 21, 60, 12, sel ? ACCENT : (in(mx, my, cx, 21, 60, 12) ? 0xFFEAD6F5 : 0xFFF1E4F7));
            String s = t("cutemod.market.me." + k);
            g.drawString(f, s, cx + (60 - f.width(s)) / 2, 23, sel ? 0xFFFFFFFF : TEXT, false);
        }
        g.enableScissor(shell.absX() + 106, shell.absY() + 35, shell.absX() + W, shell.absY() + H);
        if (meSub == 0) {
            List<Market.Item> list = Market.ownedClothes();
            if (list.isEmpty()) wrap(g, t("cutemod.market.no_clothes"), 112, 60);
            for (int i = 0; i < list.size(); i++) {
                Market.Item it = list.get(i);
                int y = 36 + i * 17 - scroll;
                boolean on = Market.worn(it.slot()).equals(it.id());
                rect(g, 108, y, W - 112, 16, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFFEFF7);
                icon(g, it.id(), 110, y + 1, 0.7f);
                txt(g, clip(name(it.id()), 70), 130, y + 4, TEXT);
                btn(g, W - 62, y + 2, 56, 13, t(on ? "cutemod.market.takeoff" : "cutemod.market.wear"), true, in(mx, my, W - 62, y + 2, 56, 13), on ? RED : GREEN);
            }
        } else {
            List<Market.Item> list = Market.fridge();
            if (list.isEmpty()) wrap(g, t("cutemod.market.no_food"), 112, 60);
            for (int i = 0; i < list.size(); i++) {
                Market.Item it = list.get(i);
                int y = 36 + i * 17 - scroll;
                rect(g, 108, y, W - 112, 16, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFFEFF7);
                icon(g, it.id(), 110, y + 1, 0.7f);
                txt(g, clip(name(it.id()) + " x" + Market.meals(it.id()), 74), 130, y + 2, TEXT);
                txt(g, t("cutemod.market.fx", it.pct(), it.mins()), 130, y + 9, MUTED);
                btn(g, W - 50, y + 2, 44, 13, t("cutemod.market.eat"), true, in(mx, my, W - 50, y + 2, 44, 13), GREEN);
            }
        }
        g.disableScissor();
    }

    private void wrap(GuiGraphics g, String s, int x, int y) {
        Font f = font();
        List<net.minecraft.util.FormattedCharSequence> lines = f.split(net.minecraft.network.chat.FormattedText.of(s), W - x - 8);
        for (int i = 0; i < lines.size() && i < 5; i++) g.drawString(f, lines.get(i), x, y + i * 10, MUTED, false);
    }

    // ---------- input ----------
    private void setTab(int t) { tab = t; scroll = 0; }

    @Override
    public boolean click(int x, int y, int button) {
        if (y < HEAD) {
            for (int i = 0; i < 4; i++) if (in(x, y, 4 + i * 74, 3, 72, HEAD - 3)) { setTab(i); return true; }
            return true;
        }
        switch (tab) {
            case 0 -> clickShop(x, y);
            case 1 -> clickCart(x, y);
            case 2 -> clickOrders(x, y);
            default -> clickMe(x, y);
        }
        return true;
    }

    private void clickShop(int x, int y) {
        for (int k = 0; k < 2; k++) if (in(x, y, 6 + k * 62, 21, 58, 12)) { shopKind = k; page = 0; return; }
        List<Market.Item> list = Market.of(shopKind);
        int pages = Math.max(1, (list.size() + PAGE - 1) / PAGE);
        if (in(x, y, W - 52, 21, 14, 12) && page > 0) { page--; return; }
        if (in(x, y, W - 20, 21, 14, 12) && page < pages - 1) { page++; return; }
        for (int i = 0; i < PAGE; i++) {
            int idx = page * PAGE + i;
            if (idx >= list.size()) break;
            int cx = 6 + (i % 4) * 72, cy = 36 + (i / 4) * 61;
            if (!in(x, y, cx, cy, 70, 58)) continue;
            Market.Item it = list.get(idx);
            if (it.kind() == Market.CLOTHES) {
                if (Market.owns(it.id()) || Market.pending(it.id()) || cart.containsKey(it.id())) { Progress.toast("cutemod.market.have"); return; }
                cart.put(it.id(), 1);
            } else {
                cart.merge(it.id(), 1, (a, b) -> Math.min(9, a + b));
            }
            Progress.toast("cutemod.market.added", name(it.id()));
            return;
        }
    }

    private void clickCart(int x, int y) {
        if (in(x, y, 6, 129, 10, 10) || (y >= 129 && y < 140 && x >= 16 && x < 150)) { express = !express; return; }
        int total = Market.total(cart, express);
        if (in(x, y, W - 92, 140, 86, 20)) {
            if (!cart.isEmpty() && Progress.coins() >= total && Market.checkout(cart, express, shell.pos())) {
                cart.clear();
                Progress.toast("cutemod.market.ordered");
                setTab(2);
            }
            return;
        }
        List<Map.Entry<String, Integer>> rows = new java.util.ArrayList<>(cart.entrySet());
        for (int i = 0; i < rows.size(); i++) {
            int ry = 22 + i * 17 - scroll;
            if (ry > 124 || ry < HEAD - 14) continue;
            String id = rows.get(i).getKey();
            int q = rows.get(i).getValue();
            if (in(x, y, 156, ry + 2, 12, 12)) {
                if (q <= 1) cart.remove(id); else cart.put(id, q - 1);
                return;
            }
            if (in(x, y, 194, ry + 2, 12, 12) && Market.item(id).kind() == Market.FOOD && q < 9) { cart.put(id, q + 1); return; }
        }
    }

    private void clickOrders(int x, int y) {
        List<Market.Order> list = Market.orders();
        for (int i = 0; i < list.size(); i++) {
            int ry = 21 + i * 24 - scroll;
            if (Market.arrived(list.get(i)) && in(x, y, W - 76, ry + 3, 68, 17)) {
                Market.collect(list.get(i), shell.pos());
                Progress.toast("cutemod.market.collected");
                return;
            }
        }
    }

    private void clickMe(int x, int y) {
        for (int k = 0; k < 2; k++) if (in(x, y, 108 + k * 64, 21, 60, 12)) { meSub = k; scroll = 0; return; }
        if (meSub == 0) {
            List<Market.Item> list = Market.ownedClothes();
            for (int i = 0; i < list.size(); i++) {
                int ry = 36 + i * 17 - scroll;
                if (in(x, y, W - 62, ry + 2, 56, 13) && y >= 35) { Market.wear(list.get(i).id()); return; }
            }
        } else {
            List<Market.Item> list = Market.fridge();
            for (int i = 0; i < list.size(); i++) {
                int ry = 36 + i * 17 - scroll;
                if (in(x, y, W - 50, ry + 2, 44, 13) && y >= 35) {
                    if (Market.eat(list.get(i).id())) Progress.toast("cutemod.market.eaten", Market.fedPctNow());
                    return;
                }
            }
        }
    }

    @Override
    public boolean scroll(double amount) {
        int rows = switch (tab) {
            case 1 -> cart.size() * 17 - 100;
            case 2 -> Market.orders().size() * 24 - (H - 21);
            case 3 -> (meSub == 0 ? Market.ownedClothes().size() : Market.fridge().size()) * 17 - 118;
            default -> 0;
        };
        scroll = Math.max(0, Math.min(Math.max(0, rows), scroll - (int) Math.signum(amount) * 14));
        return tab != 0;
    }
}
