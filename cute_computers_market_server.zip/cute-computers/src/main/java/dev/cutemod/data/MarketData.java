package dev.cutemod.data;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * CuteMarket parcels, kept on the SERVER (data/cutemod_market.dat). Unlike {@link PlayerData}, the client
 * can never write here: it can only ask the server to order or pick up, and the server decides.
 */
public class MarketData extends SavedData {
    /** One ordered item that is on its way (or waiting in the computer). ready = server time in ms. */
    public record Parcel(String id, int qty, long ready) {}

    private static final class Player {
        final List<Parcel> parcels = new ArrayList<>();
        long day;
        int dayCount;
    }

    private final Map<UUID, Player> players = new HashMap<>();

    public static MarketData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(new SavedData.Factory<>(MarketData::new, MarketData::load, null), "cutemod_market");
    }

    public List<Parcel> of(UUID id) {
        Player p = players.get(id);
        return p == null ? List.of() : new ArrayList<>(p.parcels);
    }

    public int pending(UUID id) {
        Player p = players.get(id);
        return p == null ? 0 : p.parcels.size();
    }

    /** Counts items ordered today; returns false (and counts nothing) if that would pass the daily limit. */
    public boolean tryDaily(UUID id, int items, int cap, long today) {
        Player p = players.computeIfAbsent(id, k -> new Player());
        if (p.day != today) { p.day = today; p.dayCount = 0; }
        if (p.dayCount + items > cap) return false;
        p.dayCount += items;
        setDirty();
        return true;
    }

    public void add(UUID id, Parcel parcel) {
        players.computeIfAbsent(id, k -> new Player()).parcels.add(parcel);
        setDirty();
    }

    /** Removes and returns every parcel that has arrived. */
    public List<Parcel> takeReady(UUID id, long now) {
        List<Parcel> out = new ArrayList<>();
        Player p = players.get(id);
        if (p == null) return out;
        for (Iterator<Parcel> it = p.parcels.iterator(); it.hasNext(); ) {
            Parcel x = it.next();
            if (x.ready() <= now) { out.add(x); it.remove(); }
        }
        if (!out.isEmpty()) setDirty();
        return out;
    }

    public static MarketData load(CompoundTag tag, HolderLookup.Provider registries) {
        MarketData d = new MarketData();
        ListTag list = tag.getList("players", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            try {
                UUID id = UUID.fromString(c.getString("id"));
                Player p = new Player();
                p.day = c.getLong("day");
                p.dayCount = c.getInt("count");
                ListTag ps = c.getList("parcels", Tag.TAG_COMPOUND);
                for (int k = 0; k < ps.size(); k++) {
                    CompoundTag x = ps.getCompound(k);
                    p.parcels.add(new Parcel(x.getString("id"), x.getInt("qty"), x.getLong("ready")));
                }
                d.players.put(id, p);
            } catch (IllegalArgumentException ignored) {
            }
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        players.forEach((id, p) -> {
            CompoundTag c = new CompoundTag();
            c.putString("id", id.toString());
            c.putLong("day", p.day);
            c.putInt("count", p.dayCount);
            ListTag ps = new ListTag();
            for (Parcel x : p.parcels) {
                CompoundTag t = new CompoundTag();
                t.putString("id", x.id());
                t.putInt("qty", x.qty());
                t.putLong("ready", x.ready());
                ps.add(t);
            }
            c.put("parcels", ps);
            list.add(c);
        });
        tag.put("players", list);
        return tag;
    }
}
