package dev.cutemod.market;

import dev.cutemod.block.ComputerBlockEntity;
import dev.cutemod.data.MarketData;
import dev.cutemod.item.ModItems;
import dev.cutemod.net.MarketOrderPayload;
import dev.cutemod.net.MarketSyncPayload;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;

/**
 * The rules of CuteMarket, enforced on the server. The client pays with its own coins (those are not
 * checked), but it can only order real food through here: items must exist, amounts and the number of
 * parcels are limited, delivery time is the server's, and everything must happen next to a computer.
 */
public final class MarketServer {
    public static final int MAX_LINES = 8;        // different items in one order
    public static final int MAX_QTY = 16;         // of one item
    public static final int MAX_PENDING = 14;     // parcels waiting at the same time
    public static final int DAILY_ITEMS = 48;     // food items per real day
    public static final int EXPRESS_PCT = 30, EXPRESS_SPEED = 3;

    private MarketServer() {}

    private static boolean nearComputer(ServerPlayer p, BlockPos pos) {
        return p.distanceToSqr(pos.getCenter()) <= 100 && p.level().getBlockEntity(pos) instanceof ComputerBlockEntity;
    }

    /** What the player paid for these items (used to refund an order that was refused). */
    private static int price(List<MarketOrderPayload.Entry> items, boolean express) {
        int sum = 0;
        for (MarketOrderPayload.Entry e : items) {
            if (ModItems.isFood(e.id()) && e.qty() > 0) sum += ModItems.price(e.id()) * Math.min(e.qty(), 1000);
        }
        return express ? (int) Math.ceil(sum * (100 + EXPRESS_PCT) / 100.0) : sum;
    }

    public static void order(ServerPlayer player, BlockPos pos, List<MarketOrderPayload.Entry> items, boolean express) {
        var server = player.getServer();
        if (server == null || items.isEmpty()) return;
        if (!nearComputer(player, pos)) return;
        MarketData data = MarketData.get(server);

        boolean ok = items.size() <= MAX_LINES;
        int total = 0;
        for (MarketOrderPayload.Entry e : items) {
            if (!ModItems.isFood(e.id()) || e.qty() < 1 || e.qty() > MAX_QTY) ok = false;
            else total += e.qty();
        }
        long now = System.currentTimeMillis();
        if (ok && data.pending(player.getUUID()) + items.size() > MAX_PENDING) ok = false;
        if (ok && !data.tryDaily(player.getUUID(), total, DAILY_ITEMS, now / 86_400_000L)) ok = false;

        if (!ok) { // refused: give the coins back
            sync(player, price(items, express));
            return;
        }
        for (MarketOrderPayload.Entry e : items) {
            long secs = ModItems.deliverySecs(e.id());
            long ready = now + secs * 1000L / (express ? EXPRESS_SPEED : 1);
            data.add(player.getUUID(), new MarketData.Parcel(e.id(), e.qty(), ready));
        }
        sync(player, 0);
    }

    public static void pickup(ServerPlayer player, BlockPos pos) {
        var server = player.getServer();
        if (server == null || !nearComputer(player, pos)) return;
        MarketData data = MarketData.get(server);
        List<MarketData.Parcel> ready = data.takeReady(player.getUUID(), System.currentTimeMillis());
        for (MarketData.Parcel p : ready) {
            var item = ModItems.food(p.id());
            if (item == null) continue;
            ItemStack stack = new ItemStack(item, p.qty());
            player.getInventory().add(stack);
            if (!stack.isEmpty()) player.drop(stack, false); // inventory full: it lands at the player's feet
        }
        if (!ready.isEmpty()) player.displayClientMessage(Component.translatable("cutemod.market.picked", ready.size()), true);
        sync(player, 0);
    }

    /** Tell the player's client what is on its way (and how many coins to give back, if any). */
    public static void sync(ServerPlayer player, int refund) {
        var server = player.getServer();
        if (server == null) return;
        List<MarketData.Parcel> list = MarketData.get(server).of(player.getUUID());
        PacketDistributor.sendToPlayer(player, new MarketSyncPayload(System.currentTimeMillis(), refund, list));
    }
}
