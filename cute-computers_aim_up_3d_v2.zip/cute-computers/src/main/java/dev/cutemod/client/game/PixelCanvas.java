package dev.cutemod.client.game;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.Arrays;

/**
 * A GuiGraphics that draws nowhere on the screen: a game that draws its picture with fill() and fillGradient() (in the
 * W x H "game pixels" of {@link MiniGame}) paints into an array of ARGB pixels instead, {@code sc} times finer than the game
 * screen. {@link PixelView} then shows the array as ONE textured quad, so a picture of 5000 rectangles costs one quad.
 * Same idea as the SoftCanvas of the OS, but with a finer pixel grid so that games can also add per-pixel drawing on top.
 */
final class PixelCanvas extends GuiGraphics {
    private final int sc, pw, ph;
    private final int[] px;

    PixelCanvas(Minecraft mc, int sc) {
        super(mc, mc.renderBuffers().bufferSource());
        this.sc = sc;
        this.pw = MiniGame.W * sc;
        this.ph = MiniGame.H * sc;
        this.px = new int[pw * ph];
    }

    int[] pixels() { return px; }

    /** Clears the canvas (fully see-through). */
    void begin() { Arrays.fill(px, 0); }

    @Override
    public void fill(int x0, int y0, int x1, int y1, int argb) {
        if (x0 > x1) { int t = x0; x0 = x1; x1 = t; }
        if (y0 > y1) { int t = y0; y0 = y1; y1 = t; }
        x0 = Math.max(x0 * sc, 0); x1 = Math.min(x1 * sc, pw);
        y0 = Math.max(y0 * sc, 0); y1 = Math.min(y1 * sc, ph);
        if (x0 >= x1 || y0 >= y1) return;
        int a = argb >>> 24;
        if (a == 0) return;
        for (int y = y0; y < y1; y++) {
            int i = y * pw + x0, end = y * pw + x1;
            if (a == 255) { Arrays.fill(px, i, end, argb); continue; }
            for (; i < end; i++) px[i] = over(argb, px[i]);
        }
    }

    /** A vertical gradient, top colour to bottom colour, like the real one (one step per canvas row, so it is smooth). */
    @Override
    public void fillGradient(int x0, int y0, int x1, int y1, int from, int to) {
        if (y0 > y1) { int t = y0; y0 = y1; y1 = t; }
        int rows = (y1 - y0) * sc;
        if (rows <= 0) return;
        int xa = Math.max(Math.min(x0, x1) * sc, 0), xb = Math.min(Math.max(x0, x1) * sc, pw);
        for (int r = 0; r < rows; r++) {
            int y = y0 * sc + r;
            if (y < 0 || y >= ph) continue;
            float f = (r + 0.5F) / rows;
            int a = lerp(from >>> 24, to >>> 24, f), rr = lerp(from >> 16 & 255, to >> 16 & 255, f);
            int g = lerp(from >> 8 & 255, to >> 8 & 255, f), b = lerp(from & 255, to & 255, f);
            int argb = a << 24 | rr << 16 | g << 8 | b;
            if (a == 0) continue;
            for (int x = xa; x < xb; x++) px[y * pw + x] = a == 255 ? argb : over(argb, px[y * pw + x]);
        }
    }

    private static int lerp(int a, int b, float f) { return Math.round(a + (b - a) * f); }

    /** Source over destination, both ARGB with straight (not premultiplied) alpha. */
    private static int over(int s, int d) {
        int sa = s >>> 24, da = d >>> 24;
        if (da == 0) return s;
        if (da == 255) {
            int ia = 255 - sa;
            int r = ((s >> 16 & 255) * sa + (d >> 16 & 255) * ia) / 255;
            int g = ((s >> 8 & 255) * sa + (d >> 8 & 255) * ia) / 255;
            int b = ((s & 255) * sa + (d & 255) * ia) / 255;
            return 0xFF000000 | r << 16 | g << 8 | b;
        }
        int den = sa * 255 + da * (255 - sa);
        int oa = (den + 127) / 255;
        int r = ((s >> 16 & 255) * sa * 255 + (d >> 16 & 255) * da * (255 - sa)) / den;
        int g = ((s >> 8 & 255) * sa * 255 + (d >> 8 & 255) * da * (255 - sa)) / den;
        int b = ((s & 255) * sa * 255 + (d & 255) * da * (255 - sa)) / den;
        return oa << 24 | r << 16 | g << 8 | b;
    }
}
