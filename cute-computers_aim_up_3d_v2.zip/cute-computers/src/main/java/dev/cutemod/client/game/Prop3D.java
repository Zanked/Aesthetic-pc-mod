package dev.cutemod.client.game;

/**
 * A solid object that stands in front of a wall in the Zombie Shooter raycaster: a perk machine, Pack-a-Punch, the mystery box.
 * Before, they were only a picture on a wall tile, so they looked like a part of the wall. Now the wall tile is plain brick and
 * the object is a real body in the room in front of it: its front picture is cut into LAYERS (slices) that stand behind each other,
 * so from the side you see its depth (every deeper slice is a little darker), a low object shows its top, and you cannot walk through it.
 * Pure Java on purpose (no Minecraft classes), so tools/Prop3DPreview.java can render it to a PNG.
 *
 * Coordinates: a wall is 1.0 high, a floor tile 1.0 wide; "n" is the distance from the wall plane out into the room, "a" the way along the wall.
 */
final class Prop3D {
    static final int LAYERS = 7;                // slices from the back (0) to the front (LAYERS - 1)
    static final int BACK_LAYERS = 2;           // the first slices may use a different picture (the raised lid of the open box)

    /** What the renderer has to give: a vertical run of pixels in the current column and the light (haze) of a color. */
    interface Sink {
        void fill(int y0, int y1, int argb);
        int lit(int rgb, double b);
    }

    final int tx, ty;                           // the wall tile the object stands at
    final int fx, fy;                           // the direction out of the wall into the room
    final double wid, dep, sc;                  // width and depth, and the height of one texel of the picture (32 rows = 32 * sc high)
    final int kind;                             // 0 perk machine, 1 Pack-a-Punch, 2 mystery box (the game picks glow and light by it)
    int[][] body, back;                         // the picture of the front, and of the back slices (the game swaps them: the box opens, Pack-a-Punch works)
    final double hgt;                           // how high the tallest part of the FRONT picture is (a bullet flies over anything lower)
    private final double bx, by, cx, cy, ax, ay;
    private final double aLo, aHi;              // the part of the width that is really filled (the footprint is as wide as the picture's drawing, not as the 32 texels)

    Prop3D(int tx, int ty, int fx, int fy, int kind, double wid, double dep, double sc, int[][] body, int[][] back) {
        this.tx = tx; this.ty = ty; this.fx = fx; this.fy = fy; this.kind = kind;
        this.wid = wid; this.dep = dep; this.sc = sc; this.body = body; this.back = back == null ? body : back;
        cx = tx + 0.5; cy = ty + 0.5;           // the middle of the wall tile
        bx = cx + fx * 0.5; by = cy + fy * 0.5; // the middle of the wall plane (where the object touches the wall)
        ax = fy; ay = -fx;                      // along the wall, to the right as you look at the front of the object
        int w = this.body[0].length, minX = w, maxX = -1, top = this.body.length;
        for (int[][] t : new int[][][]{this.body, this.back}) {
            for (int y = 0; y < t.length; y++) for (int x = 0; x < t[y].length; x++) {
                if (t[y][x] == 0) continue;
                minX = Math.min(minX, x); maxX = Math.max(maxX, x);
                if (t == this.body) top = Math.min(top, y);
            }
        }
        if (maxX < 0) { minX = 0; maxX = w - 1; }
        aLo = ((double) minX / w - 0.5) * wid - 0.03;
        aHi = ((double) (maxX + 1) / w - 0.5) * wid + 0.03;
        hgt = (this.body.length - top) * sc;
    }

    private static final int OUTLINE = 0xFF0A0807;
    private static final java.util.Map<int[][], int[][]> SIDES = new java.util.IdentityHashMap<>();

    /**
     * The picture for the slices behind the front one: the black outline is replaced by the color of the body next to it,
     * otherwise the sides of every machine would be pitch black. Cached by the picture (there are only a few).
     */
    private static synchronized int[][] side(int[][] tex) {
        int[][] s = SIDES.get(tex);
        if (s != null) return s;
        int h = tex.length, w = tex[0].length;
        s = new int[h][w];
        int[][] dirs = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int c = tex[y][x];
            if (c == OUTLINE) {
                for (int[] d : dirs) {
                    int nx = x + d[0], ny = y + d[1];
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                    int n = tex[ny][nx];
                    if (n != 0 && n != OUTLINE) { c = 0xFF000000 | (((n >> 16 & 255) * 7 / 10) << 16) | (((n >> 8 & 255) * 7 / 10) << 8) | ((n & 255) * 7 / 10); break; }
                }
            }
            s[y][x] = c;
        }
        SIDES.put(tex, s);
        return s;
    }

    /** True if the point is inside the footprint of the object (a little bigger, for the radius of whoever walks). */
    boolean blocks(double x, double y) {
        double n = (x - bx) * fx + (y - by) * fy, a = (x - cx) * ax + (y - cy) * ay;
        return n > -0.02 && n < dep && a > aLo && a < aHi;
    }

    /** Where a ray from (x,y) along (dx,dy) first enters the footprint (a straight box, the height is not checked here); -1 for a miss. */
    double enter(double x, double y, double dx, double dy) {
        double pn = (x - bx) * fx + (y - by) * fy, pa = (x - cx) * ax + (y - cy) * ay;
        double rn = dx * fx + dy * fy, ra = dx * ax + dy * ay;
        double t0 = 0, t1 = 1e9;
        if (Math.abs(rn) < 1e-9) { if (pn < 0 || pn > dep) return -1; }
        else {
            double s0 = (0 - pn) / rn, s1 = (dep - pn) / rn;
            t0 = Math.max(t0, Math.min(s0, s1)); t1 = Math.min(t1, Math.max(s0, s1));
        }
        if (Math.abs(ra) < 1e-9) { if (pa < aLo || pa > aHi) return -1; }
        else {
            double s0 = (aLo - pa) / ra, s1 = (aHi - pa) / ra;
            t0 = Math.max(t0, Math.min(s0, s1)); t1 = Math.min(t1, Math.max(s0, s1));
        }
        return t0 <= t1 && t1 > 0 ? t0 : -1;
    }

    /**
     * Paints this object into one screen column, slices from the back to the front, over what is already there.
     * px, py, rdx, rdy: the eye and the direction of the ray; cosD: cos(ray angle - view angle) (fish-eye fix);
     * wallRaw: how far the wall behind is on this ray (slices behind it are not drawn); hor, H: horizon and screen height;
     * glow: the least brightness (0 = none); dim: factor for the whole object (a machine without power is dark).
     * Returns the distance (fish-eye corrected) of the nearest slice that painted a pixel, or 0 if nothing was painted.
     */
    double drawColumn(Sink out, double px, double py, double rdx, double rdy, double cosD, double wallRaw, int hor, int H, double glow, double dim) {
        double pn = (px - bx) * fx + (py - by) * fy, pa = (px - cx) * ax + (py - cy) * ay;
        double rn = rdx * fx + rdy * fy, ra = rdx * ax + rdy * ay;
        if (rn > -1e-6) return 0;               // the ray goes away from the front of the object (or along it)
        double nearest = 0;
        for (int k = 0; k < LAYERS; k++) {
            double n = dep * (k + 1) / LAYERS;
            double t = (n - pn) / rn;
            if (t <= 0.02 || t >= wallRaw) continue;
            double u = (pa + t * ra) / wid + 0.5;
            if (u < 0 || u >= 1) continue;
            int[][] tex = k < BACK_LAYERS ? side(back) : k < LAYERS - 1 ? side(body) : body;
            int rows = tex.length, w = tex[0].length;
            int c = Math.min(w - 1, (int) (u * w));
            double d = Math.max(0.05, t * cosD);
            int lh = (int) (H / d), floorY = hor + lh / 2;
            double b = Math.max(0.12, 1 - d / 9.5);
            if (glow > 0) b = Math.max(b, glow);
            b *= dim * (0.5 + 0.5 * (k + 1) / LAYERS);     // the deeper the slice, the darker: that is what the sides look like
            int runY = 0, runC = 0;
            boolean any = false;
            for (int r = 0; r <= rows; r++) {
                int px0 = r < rows ? tex[r][c] : 0;
                int yy = floorY - (int) ((rows - r) * sc * lh);
                if (r > 0 && px0 != runC) {
                    if (runC != 0) { out.fill(runY, yy, out.lit(runC, b)); any = true; }
                    runY = yy; runC = px0;
                } else if (r == 0) { runY = yy; runC = px0; }
            }
            if (any && (nearest == 0 || d < nearest)) nearest = d;
        }
        return nearest;
    }
}
