package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * A picture that a game draws itself into an array of ARGB pixels (see {@link ForestScene}). Every frame the array is copied
 * into one texture and drawn as ONE textured quad, instead of thousands of GUI rectangles. Same idea (and the same calls) as
 * the TexCache of the OS, but for a game that makes a new picture on every frame.
 */
final class PixelView {
    private static int counter;
    private final ResourceLocation rl;
    private final DynamicTexture tex;
    private final int w, h;
    private boolean closed;

    PixelView(int w, int h) {
        this.w = w; this.h = h;
        Minecraft mc = Minecraft.getInstance();
        rl = ResourceLocation.fromNamespaceAndPath("cutemod", "baked/view" + (counter++));
        tex = new DynamicTexture(w, h, false);
        mc.getTextureManager().register(rl, tex);
        tex.setFilter(true, false);        // a little smoothing: the picture is shown at a size that is not a whole multiple of it
    }

    boolean isClosed() { return closed; }

    /** Copies the pixels (ARGB, w x h) into the texture. */
    void upload(int[] argb) {
        NativeImage img = tex.getPixels();
        if (img == null) return;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int c = argb[row + x];
                img.setPixelRGBA(x, y, (c & 0xFF00FF00) | (c >> 16 & 255) | (c & 255) << 16);   // ARGB -> ABGR
            }
        }
        tex.upload();
    }

    /** Puts the picture on the screen in the box (x, y, dw, dh). */
    void draw(GuiGraphics g, int x, int y, int dw, int dh) {
        g.flush();   // fill() only collects rectangles in a batch, blit() draws at once: without this the picture goes UNDER everything drawn before it
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        g.blit(rl, x, y, dw, dh, 0F, 0F, w, h, w, h);
    }

    void close() {
        if (closed) return;
        closed = true;
        Minecraft.getInstance().getTextureManager().release(rl);
        tex.close();
    }
}
