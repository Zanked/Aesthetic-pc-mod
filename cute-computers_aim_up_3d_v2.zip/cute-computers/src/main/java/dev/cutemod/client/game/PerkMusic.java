package dev.cutemod.client.game;

import dev.cutemod.CuteMod;
import dev.cutemod.client.os.Sfx;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

import java.util.List;

/**
 * The music of the perk machines in Zombie Shooter, like the jingles of the old Call of Duty Zombies machines.
 * Every machine has its own tune (assets/cutemod/sounds/perk/, made by tools/make_perk_music.py, all of them original):
 * <ul>
 * <li>a <b>loop</b> that plays while the power is on and you are near the machine: it gets louder the closer you come,
 * fades out when you walk away, and only the nearest machine plays at a time (the tunes cross-fade);</li>
 * <li>a <b>jingle</b> that plays once when you buy the perk (the loops keep quiet while it plays).</li>
 * </ul>
 * Both follow the Music switch and slider of the computer's Settings, and closing the game cuts them off.
 */
final class PerkMusic {
    /** Quick Revive, Speed Cola, Stamin-Up, Juggernog, Double Tap II, Mule Kick: the same order as the perks. */
    static final String[] NAME = {"revive", "cola", "stamin", "jugg", "tap", "mule", "pap"};   // the last one is Pack-a-Punch
    private static final int JINGLE_SECONDS = 8;                    // every jingle file is 8 seconds long
    private static final double RANGE = 7.0, CLOSE = 1.5;           // you hear a machine from 7 tiles, at full volume within 1.5
    private static final float LEVEL = 0.75F;
    private static final SoundEvent[] LOOP = new SoundEvent[7], JINGLE = new SoundEvent[7];

    private Tune tune;
    private int quiet;                                               // game ticks (60 a second) during which the loops keep quiet (a jingle plays)

    private static SoundEvent event(String name) {
        return SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "perk." + name));
    }

    private static synchronized SoundEvent loopEvent(int p) {
        if (LOOP[p] == null) LOOP[p] = event("loop_" + NAME[p]);
        return LOOP[p];
    }

    private static synchronized SoundEvent jingleEvent(int p) {
        if (JINGLE[p] == null) JINGLE[p] = event("jingle_" + NAME[p]);
        return JINGLE[p];
    }

    /** The sounds of the mystery box: "box_open" (the lid creaks, a glitter), "box_roll" (a music box plays while the guns flip, 5 s)
     *  and "box_teddy" (a mocking jack-in-the-box). Made by tools/make_perk_music.py, played like the jingles. */
    static void box(String name) {
        Sfx.gameTune(event(name), 1.0F, 0.9F);
    }

    /** A sound effect of a machine ("pap_work": the gun is being upgraded, "pap_ready": a chime): follows the Sounds slider. */
    static void fx(String name) {
        Sfx.gameSound(event(name), 1.0F, 0.9F);
    }

    /** A new game: whatever was playing fades out. */
    void reset() {
        quiet = 0;
        if (tune != null) { tune.fadeOut(); tune = null; }
    }

    /** The perk was bought (or Quick Revive saved you): its jingle plays and the machine loops wait for it to end. */
    void jingle(int perk) {
        int p = Math.max(0, Math.min(NAME.length - 1, perk));
        quiet = JINGLE_SECONDS * 60;
        if (tune != null) { tune.fadeOut(); tune = null; }
        Sfx.gameTune(jingleEvent(p), 1.0F, 0.9F);
    }

    /** Called every game tick: starts, steers and stops the loop of the nearest machine. machines = x, y, kind (2-7 = perk 0-5). */
    void update(double px, double py, List<int[]> machines, boolean on) {
        if (quiet > 0) quiet--;
        int best = -1;
        double bd = RANGE;
        if (on && quiet == 0 && Sfx.music() && Sfx.musicVol() > 0F) {
            for (int[] m : machines) {
                if (m[2] < 1) continue;                                // 0 is the power switch, 1 Pack-a-Punch (tune 6), 2-7 the perks (tunes 0-5)
                double d = Math.hypot(px - (m[0] + 0.5), py - (m[1] + 0.5));
                if (d < bd) { bd = d; best = m[2] == 1 ? 6 : m[2] - 2; }
            }
        }
        if (tune != null && (tune.isStopped() || tune.perk != best)) {   // another machine is the nearest now, or nothing is near
            tune.fadeOut();
            tune = null;
        }
        if (best < 0) return;
        double k = Math.max(0, Math.min(1, (RANGE - bd) / (RANGE - CLOSE)));
        float target = (float) Math.min(1.0, LEVEL * k * k * Sfx.musicVol());
        if (tune == null) {
            tune = new Tune(best);
            Minecraft.getInstance().getSoundManager().play(tune);
            Sfx.trackGameSound(tune);
        }
        tune.target = target;
        tune.idle = 0;
    }

    /** The loop of one machine: a looping sound without a place in the world (so it is heard evenly), whose volume we steer. */
    private static final class Tune extends AbstractTickableSoundInstance {
        final int perk;
        float target;
        int idle;
        private boolean out;

        Tune(int perk) {
            super(loopEvent(perk), SoundSource.MASTER, RandomSource.create());   // MASTER, like the game music: the Music switch and slider of Settings decide
            this.perk = perk;
            this.looping = true;
            this.delay = 0;
            this.volume = 0.01F;                                       // a sound that starts at exactly 0 is skipped
            this.relative = true;
            this.attenuation = SoundInstance.Attenuation.NONE;
        }

        void fadeOut() { out = true; }

        @Override
        public void tick() {
            if (++idle > 8) out = true;                                // the game does not call any more (closed, minimized): fade away by itself
            float goal = out ? 0F : target;
            this.volume += (goal - this.volume) * 0.15F;
            if (out && this.volume < 0.02F) stop();
            else if (this.volume < 0.01F) this.volume = 0.01F;
        }
    }
}
