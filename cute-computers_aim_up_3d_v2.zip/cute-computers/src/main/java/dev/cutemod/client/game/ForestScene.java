package dev.cutemod.client.game;

import java.util.Arrays;

/**
 * The 3D picture of the Foggy Forest, drawn by the CPU into one array of pixels (352 x 224, the same shape as the 220 x 140
 * game screen, 1.6 times finer). It has NO Minecraft classes in it on purpose (like {@link GunView}), so it can be tested alone.
 * <p>
 * What is different from the old one-rectangle-per-column drawing:
 * <ul>
 *   <li>the picture is made in an array and goes to the screen as ONE textured quad (see PixelView): thousands of GUI rectangles less;</li>
 *   <li>the ground is a real perspective floor, every pixel of it has its own fog and its own light;</li>
 *   <li>the lit fires really light the ground, the trunks and the sprites near them (warm light, and the fog gets thinner there);</li>
 *   <li>trees, bushes, the lantern and the monster are drawn pixel by pixel from their shape (round trunks lit by the moon,
 *       pine tiers with a ragged edge, branches), not from flat bars.</li>
 * </ul>
 * The game fills the public fields below before each {@link #render()} and then copies {@link #pix} to a texture.
 */
final class ForestScene {
    static final int RW = 352, RH = 224, HOR = RH / 2;
    static final double PLANE = 0.75;                // field of view, the same as in the game
    static final double F = RH;                      // pixels of height of a 1 unit wall at distance 1
    static final int FOG = 0x2A3436;                 // the colour everything fades into
    static final double MOON = -0.9;                 // the world direction of the moon
    private static final double GAIN = 2.6;          // how strongly a fire lights up dark things

    /** The finished picture: ARGB, row by row. */
    final int[] pix = new int[RW * RH];
    private final double[] zbuf = new double[RW];    // wall distance per screen column (hides sprites behind the tree wall)

    // ---------- what the game fills in before every render() ----------
    int size;                                        // the forest is size x size tiles, the outer ring is a wall of trees
    double posX, posY, ang, fogR;
    int ticks;
    int nTrees; double[] trX, trY; int[] trK;        // 0 pine, 1 dead tree, 2 fat tree
    int nDeco; double[] dX, dY; int[] dK;            // 3 bush, 4 stump
    int nFires; double[] fx, fy; boolean[] lit;
    int nWisps; double[] wx, wy; boolean[] wgone;
    boolean showRoad; double exitX, exitY;
    boolean showMonster; double ex, ey;
    int nSil; double[] silA; int[] silW, silH;       // the far tree line
    String[] monsterBits;                            // 12 x 24, one char = one pixel ('r' = the eyes)

    // ---------- per frame ----------
    private double cA, sA, dirX, dirY, plX, plY, moonSide, fm = 1;
    private double lr, lg, lb;                       // the fire light at the last point asked about
    private int nl;
    private final double[] lx = new double[16], ly = new double[16], lk = new double[16];
    private double pf, pcx, pfull;                   // the last projected point
    private final long[] order = new long[640];
    private final double[] oX = new double[640], oY = new double[640];
    private final int[] oKind = new int[640], oSub = new int[640];

    // ---------- small helpers ----------
    private static double hash(int x, int y) {
        int h = x * 374761393 + y * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535.0;
    }

    /** Smooth noise: the value changes softly between the grid points (for big soft patches on the ground). */
    private static double vnoise(double x, double y) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        double fx = x - ix, fy = y - iy;
        fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
        double a = hash(ix, iy), b = hash(ix + 1, iy), c = hash(ix, iy + 1), d = hash(ix + 1, iy + 1);
        return (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy;
    }

    private static double clamp01(double v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

    private static double angDiff(double a, double b) {
        double d = a - b;
        while (d > Math.PI) d -= Math.PI * 2;
        while (d < -Math.PI) d += Math.PI * 2;
        return d;
    }

    private static int mul(int rgb, double m) {
        int r = (int) Math.min(255, ((rgb >> 16) & 255) * m), g = (int) Math.min(255, ((rgb >> 8) & 255) * m), b = (int) Math.min(255, (rgb & 255) * m);
        return (r << 16) | (g << 8) | b;
    }

    /** The fire light at a point of the ground: lr, lg, lb (0 = dark). */
    private void lightAt(double x, double y) {
        double s = 0;
        for (int i = 0; i < nl; i++) {
            double dx = x - lx[i], dy = y - ly[i], d2 = dx * dx + dy * dy;
            if (d2 >= 90) continue;
            s += lk[i] * 1.5 / (1 + d2 * 0.35) * (1 - d2 / 90);
        }
        lr = s; lg = s * 0.62; lb = s * 0.3;
    }

    /** The final colour of a lit thing at distance f: its own light, the fire light and the fog (thinner near a fire). */
    private int fin(int rgb, double lm, double f) {
        double r = ((rgb >> 16) & 255) * lm * (1 + GAIN * lr);
        double g = ((rgb >> 8) & 255) * lm * (1 + GAIN * lg);
        double b = (rgb & 255) * lm * (1 + GAIN * lb);
        double t = clamp01(f / (fogR * fm)), k = t * t * (3 - 2 * t);
        k *= 1 - Math.min(0.55, lr * 0.3) * (1 - t);        // thinner near a fire, but what is far away stays in the fog
        r = r * (1 - k) + ((FOG >> 16) & 255) * k;
        g = g * (1 - k) + ((FOG >> 8) & 255) * k;
        b = b * (1 - k) + (FOG & 255) * k;
        return 0xFF000000 | ((int) Math.min(255, r) << 16) | ((int) Math.min(255, g) << 8) | (int) Math.min(255, b);
    }

    /** A thing that shines by itself (eyes, a lantern): no fire light, and the fog takes it far later. */
    private int finGlow(int rgb, double lm, double f, double fogMul) {
        double t = clamp01(f / (fogR * fogMul)), k = t * t * (3 - 2 * t);
        double r = ((rgb >> 16) & 255) * lm * (1 - k) + ((FOG >> 16) & 255) * k;
        double g = ((rgb >> 8) & 255) * lm * (1 - k) + ((FOG >> 8) & 255) * k;
        double b = (rgb & 255) * lm * (1 - k) + (FOG & 255) * k;
        return 0xFF000000 | ((int) Math.min(255, r) << 16) | ((int) Math.min(255, g) << 8) | (int) Math.min(255, b);
    }

    private void addPix(int i, int rgb, double a) {
        int c = pix[i];
        int r = Math.min(255, (int) (((c >> 16) & 255) + ((rgb >> 16) & 255) * a));
        int g = Math.min(255, (int) (((c >> 8) & 255) + ((rgb >> 8) & 255) * a));
        int b = Math.min(255, (int) ((c & 255) + (rgb & 255) * a));
        pix[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void blendPix(int i, int rgb, double a) {
        int c = pix[i];
        int r = (int) (((c >> 16) & 255) * (1 - a) + ((rgb >> 16) & 255) * a);
        int g = (int) (((c >> 8) & 255) * (1 - a) + ((rgb >> 8) & 255) * a);
        int b = (int) ((c & 255) * (1 - a) + (rgb & 255) * a);
        pix[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Where a point of the world is on the screen (pf = distance in front of you, pcx = screen x, pfull = pixels per unit), false if not in front. */
    private boolean proj(double sx, double sy) {
        double rx = sx - posX, ry = sy - posY;
        double f = rx * cA + ry * sA, r = -rx * sA + ry * cA;
        if (f < 0.2) return false;
        double cam = r / (f * PLANE);
        if (Math.abs(cam) > 1.6) return false;
        pf = f; pcx = RW / 2.0 * (1 + cam); pfull = F / f;
        return true;
    }

    // ---------- the picture ----------
    void render() {
        cA = Math.cos(ang); sA = Math.sin(ang);
        dirX = cA; dirY = sA; plX = -dirY * PLANE; plY = dirX * PLANE;
        moonSide = Math.sin(angDiff(MOON, ang));
        nl = 0;
        for (int i = 0; i < nFires && nl < 16; i++) {
            if (!lit[i]) continue;
            lx[nl] = fx[i]; ly[nl] = fy[i];
            lk[nl] = 0.9 + 0.2 * Math.sin(ticks / 3.0 + fx[i] * 7);
            nl++;
        }
        fm = 1;
        sky();
        floor();
        walls();
        sprites();
    }

    private void sky() {
        int band = HOR - 41;                                      // the sky fades into the fog
        for (int y = 0; y < HOR; y++) {
            int c;
            if (y >= band) c = FOG;
            else {
                double t = y / (double) band;
                int r = (int) (0x07 + (((FOG >> 16) & 255) - 0x07) * t), g = (int) (0x0B + (((FOG >> 8) & 255) - 0x0B) * t), b = (int) (0x10 + ((FOG & 255) - 0x10) * t);
                c = (r << 16) | (g << 8) | b;
            }
            Arrays.fill(pix, y * RW, y * RW + RW, 0xFF000000 | c);
        }
        double md = angDiff(MOON, ang);                           // the moon, behind the fog
        if (Math.abs(md) < 1.3) {
            int mx = (int) (RW / 2.0 * (1 + Math.tan(md) / PLANE)), my = 29, rad = 27;
            for (int y = Math.max(0, my - rad); y <= Math.min(HOR - 1, my + rad); y++) {
                for (int x = Math.max(0, mx - rad); x <= Math.min(RW - 1, mx + rad); x++) {
                    double d = Math.hypot(x - mx, y - my);
                    if (d >= rad) continue;
                    double halo = (1 - d / rad);
                    double a = halo * halo * 0.22 + (d < 17 ? 0.16 : 0) + (d < 11 ? 0.34 : 0);
                    addPix(y * RW + x, 0xE8EEDC, a * 0.5);
                }
            }
        }
        double vis = clamp01((fogR - 2.5) / 7.0);                 // the far tree line: thin fog shows it, thick fog hides it
        double alpha = 0.38 * (0.3 + 0.7 * vis);
        for (int i = 0; i < nSil; i++) {
            double d = angDiff(silA[i], ang);
            if (Math.abs(d) > 1.15) continue;
            int cx = (int) (RW / 2.0 * (1 + Math.tan(d) / PLANE));
            int hw = (int) (silW[i] * 1.6), h = (int) (silH[i] * 1.6), top = HOR - h;
            for (int y = top + h / 3; y < HOR + 3 && y < RH; y++) for (int x = cx - 2; x <= cx + 2; x++) if (x >= 0 && x < RW && y >= 0) blendPix(y * RW + x, 0x0C1214, alpha);
            for (int t = 0; t < 3; t++) {
                int w = (int) (hw * (1.0 - t * 0.3)), y0 = top + (int) (h * 0.2 * t), y1 = y0 + (int) (h * 0.34);
                for (int y = Math.max(0, y0); y < y1 && y < RH; y++) {
                    int rw = (int) (w * (y - y0 + 2) / (double) (y1 - y0 + 2));
                    for (int x = cx - rw; x <= cx + rw; x++) if (x >= 0 && x < RW) blendPix(y * RW + x, 0x0C1214, alpha);
                }
            }
        }
    }

    private void floor() {
        for (int y = HOR; y < RH; y++) {
            double f = F / (2.0 * (y - HOR + 0.5));
            int row = y * RW;
            if (f >= fogR * 1.1 && nl == 0) { Arrays.fill(pix, row, row + RW, 0xFF000000 | FOG); continue; }
            double contrast = clamp01(1 - f / fogR);
            for (int x = 0; x < RW; x++) {
                double cam = 2.0 * (x + 0.5) / RW - 1;
                double gx = posX + (dirX + plX * cam) * f, gy = posY + (dirY + plY * cam) * f;
                double n = hash((int) Math.floor(gx * 12), (int) Math.floor(gy * 12));
                double patch = vnoise(gx * 0.7, gy * 0.7) * 0.6 + vnoise(gx * 2.3, gy * 2.3) * 0.4;
                double v = 1 + (n - 0.5) * 0.55 * contrast;
                int r = (int) ((0x0E + patch * 7) * v), g = (int) ((0x18 + patch * 12) * v), b = (int) ((0x13 + patch * 6) * v);
                if (n > 0.965) { r += (int) (16 * contrast); g += (int) (22 * contrast); b += (int) (12 * contrast); }   // tufts of grass
                lightAt(gx, gy);
                pix[row + x] = fin((Math.max(0, r) << 16) | (Math.max(0, g) << 8) | Math.max(0, b), 1, f);
            }
        }
    }

    private void walls() {
        for (int x = 0; x < RW; x++) {                             // the wall of trees round the forest: one ray per column
            double cam = 2.0 * (x + 0.5) / RW - 1;
            double rdx = dirX + plX * cam, rdy = dirY + plY * cam;
            int mapX = (int) posX, mapY = (int) posY;
            double ddx = Math.abs(1 / rdx), ddy = Math.abs(1 / rdy), sdx, sdy;
            int stepX, stepY;
            if (rdx < 0) { stepX = -1; sdx = (posX - mapX) * ddx; } else { stepX = 1; sdx = (mapX + 1 - posX) * ddx; }
            if (rdy < 0) { stepY = -1; sdy = (posY - mapY) * ddy; } else { stepY = 1; sdy = (mapY + 1 - posY) * ddy; }
            boolean side = false;
            while (mapX > 0 && mapY > 0 && mapX < size - 1 && mapY < size - 1) {
                if (sdx < sdy) { sdx += ddx; mapX += stepX; side = false; }
                else { sdy += ddy; mapY += stepY; side = true; }
            }
            double dist = Math.max(0.05, side ? sdy - ddy : sdx - ddx);
            zbuf[x] = dist;
            if (dist >= fogR) continue;                            // lost in the fog
            double hx = posX + dist * rdx, hy = posY + dist * rdy;
            double wallX = side ? hx : hy;
            wallX -= Math.floor(wallX);
            double full = F / dist;
            int ground = HOR + (int) (full / 2), top = Math.max(0, ground - (int) (full * 1.9));
            lightAt(hx, hy);
            int seg = (int) (wallX * 10);
            int base = seg % 3 == 0 ? 0x17130F : 0x1F1913;         // trunks side by side
            double lm = side ? 0.8 : 1;
            double round = Math.sin((wallX * 10 - seg) * Math.PI);  // each trunk is round: darker at its edges
            lm *= 0.55 + 0.55 * round;
            int u = (int) Math.floor(wallX * 60);
            for (int y = top; y < Math.min(RH, ground); y++) {
                double h = (ground - y - 0.5) / full;
                double streak = 0.8 + 0.4 * hash(u, (int) Math.floor(h * 4));
                double crown = h > 1.45 ? 0.55 : 1;                // the dark crowns above
                pix[y * RW + x] = fin(base, lm * streak * crown, dist);
            }
        }
    }

    // ---------- sprites: trees, bushes, fires, wisps, the road, the monster ----------
    private static final int K_PINE = 0, K_DEAD = 1, K_FAT = 2, K_BUSH = 3, K_STUMP = 4, K_FIRE = 5, K_WISP = 6, K_ROAD = 7, K_MONSTER = 8;

    private void sprites() {
        int n = 0;
        double lim = fogR * fogR * 1.1;
        for (int i = 0; i < nTrees && n < 630; i++) {
            double d2 = sq(trX[i] - posX) + sq(trY[i] - posY);
            if (d2 < lim) add(n++, d2, K_PINE + trK[i], trX[i], trY[i], i);
        }
        for (int i = 0; i < nDeco && n < 630; i++) {
            double d2 = sq(dX[i] - posX) + sq(dY[i] - posY);
            if (d2 < lim) add(n++, d2, dK[i], dX[i], dY[i], i);
        }
        for (int i = 0; i < nFires; i++) {
            double d2 = sq(fx[i] - posX) + sq(fy[i] - posY);
            if (d2 < 400) add(n++, d2, K_FIRE, fx[i], fy[i], lit[i] ? 1 : 0);
        }
        for (int i = 0; i < nWisps; i++) {
            double d2 = sq(wx[i] - posX) + sq(wy[i] - posY);
            if (!wgone[i] && d2 < 200) add(n++, d2, K_WISP, wx[i], wy[i], i);
        }
        if (showRoad) add(n++, sq(exitX - posX) + sq(exitY - posY), K_ROAD, exitX, exitY, 0);
        double md = Math.hypot(ex - posX, ey - posY);
        if (showMonster && md < 11) add(n++, md * md, K_MONSTER, ex, ey, 0);
        long[] ord = Arrays.copyOf(order, n);
        Arrays.sort(ord);
        for (int k = n - 1; k >= 0; k--) {                         // far ones first
            int i = (int) (ord[k] & 1023);
            switch (oKind[i]) {
                case K_PINE -> sprite(i, 0.65, 2.4);
                case K_DEAD -> sprite(i, 0.75, 1.85);
                case K_FAT -> sprite(i, 0.75, 2.5);
                case K_BUSH -> sprite(i, 0.45, 0.4);
                case K_STUMP -> sprite(i, 0.2, 0.25);
                case K_FIRE -> fire(i);
                case K_WISP -> wisp(i);
                case K_ROAD -> road(i);
                default -> monster(i);
            }
        }
    }

    private void add(int i, double d2, int kind, double x, double y, int sub) {
        order[i] = ((long) (d2 * 256) << 10) | i;
        oKind[i] = kind; oX[i] = x; oY[i] = y; oSub[i] = sub;
    }

    private static double sq(double v) { return v * v; }

    /** Draws a thing pixel by pixel: for every pixel, its sideways position a and its height h above the ground in world units. */
    private void sprite(int i, double aMax, double hMax) {
        int kind = oKind[i], sub = oSub[i];
        if (!proj(oX[i], oY[i])) return;
        double f = pf, cx = pcx, full = pfull;
        int ground = HOR + (int) Math.round(full / 2);
        int x0 = Math.max(0, (int) Math.floor(cx - aMax * full)), x1 = Math.min(RW, (int) Math.ceil(cx + aMax * full));
        int y0 = Math.max(0, (int) Math.floor(ground - hMax * full)), y1 = Math.min(RH, ground + 1);
        if (x1 <= x0 || y1 <= y0) return;
        lightAt(oX[i], oY[i]);
        fm = 1;
        for (int x = x0; x < x1; x++) {
            if (f >= zbuf[x]) continue;
            double a = (x + 0.5 - cx) / full;
            for (int y = y0; y < y1; y++) {
                double h = (ground - (y + 0.5)) / full;
                int c = switch (kind) {
                    case K_PINE -> pine(a, h, sub);
                    case K_DEAD -> dead(a, h, sub);
                    case K_FAT -> fat(a, h, sub);
                    case K_BUSH -> bush(a, h, sub);
                    default -> stump(a, h);
                };
                if (c != 0) pix[y * RW + x] = fin(c & 0xFFFFFF, 1, f);
            }
        }
    }

    private int bark(int base, double nx, double a, double h) {
        double lm = 0.78 + 0.4 * moonSide * nx;
        double streak = 0.88 + 0.24 * hash((int) Math.floor((a + 2) * 18), (int) Math.floor(h * 0.7));
        return mul(base, lm * streak);
    }

    private int pine(double a, double h, int sub) {
        double aa = Math.abs(a);
        for (int t = 3; t >= 0; t--) {                              // four tiers of needles, the lowest is the widest
            double hb = 0.5 + 0.36 * t, ht = hb + 0.7;
            if (h < hb || h >= ht) continue;
            double w = 0.62 * (1 - 0.12 * t) * (1 - (h - hb) / (ht - hb));
            double jag = 0.07 * (hash((int) Math.floor(h * 16), t + sub * 7) - 0.5);
            if (aa < w + jag) {
                double nx = w > 0.01 ? a / w : 0;
                double lm = 0.85 + 0.3 * moonSide * nx - ((h - hb) / (ht - hb) < 0.12 ? 0.25 : 0);   // the lower edge of a tier is darker
                double sp = 0.85 + 0.3 * hash((int) Math.floor(a * 26), (int) Math.floor(h * 26));
                return 0xFF000000 | mul(0x10201A, lm * sp);
            }
        }
        if (aa < 0.09 && h < 2.0) return 0xFF000000 | bark(0x2B2118, a / 0.09, a, h);
        return 0;
    }

    private static double segD(double a, double h, double a0, double h0, double a1, double h1) {
        double da = a1 - a0, dh = h1 - h0, l2 = da * da + dh * dh;
        double t = l2 == 0 ? 0 : clamp01(((a - a0) * da + (h - h0) * dh) / l2);
        return Math.hypot(a - (a0 + da * t), h - (h0 + dh * t));
    }

    private int dead(double a, double h, int sub) {
        double aa = Math.abs(a);
        if (h < 1.75) {
            double w = 0.1 - 0.05 * h / 1.75;
            if (aa < w) return 0xFF000000 | bark(0x3A3228, a / w, a, h);
        }
        for (int s = -1; s <= 1; s += 2) {                           // bare branches, left and right
            for (int i = 0; i < 3; i++) {
                double len = (0.46 - i * 0.1) * (0.8 + 0.4 * hash(sub, i + (s > 0 ? 5 : 0)));
                double h0 = 0.72 + 0.3 * i, w0 = 0.07 - 0.02 * i;
                if (segD(a, h, s * w0, h0, s * (w0 + len), h0 + len * 0.7) < 0.032 - 0.006 * i) return 0xFF000000 | bark(0x3A3228, s * 0.3, a, h);
            }
        }
        return 0;
    }

    private static double blob(double a, double h, double ca, double ch, double ra, double rh) {
        return sq((a - ca) / ra) + sq((h - ch) / rh);
    }

    private int fat(double a, double h, int sub) {
        double aa = Math.abs(a);
        double e = Math.min(blob(a, h, 0, 1.7, 0.62, 0.5), Math.min(blob(a, h, -0.1, 2.15, 0.42, 0.32), blob(a, h, 0.25, 1.95, 0.35, 0.3)));
        double edge = 1 + 0.3 * (hash((int) Math.floor(a * 13), (int) Math.floor(h * 13)) - 0.5);
        if (e < edge) {
            double nx = clampPm(a / 0.62);
            double lm = 0.85 + 0.3 * moonSide * nx + 0.18 * clampPm((h - 1.7) / 0.5);
            double sp = 0.8 + 0.4 * hash((int) Math.floor(a * 22), (int) Math.floor(h * 22));
            return 0xFF000000 | mul(0x142016, lm * sp);
        }
        if (h < 1.5) {
            double w = 0.17 - 0.05 * h / 1.5;
            if (aa < w) return 0xFF000000 | bark(0x2B2118, a / w, a, h);
        }
        return 0;
    }

    private static double clampPm(double v) { return v < -1 ? -1 : v > 1 ? 1 : v; }

    private int bush(double a, double h, int sub) {
        double e = Math.min(blob(a, h, 0, 0.1, 0.33, 0.22), Math.min(blob(a, h, -0.18, 0.14, 0.2, 0.2), blob(a, h, 0.2, 0.12, 0.18, 0.16)));
        double edge = 1 + 0.35 * (hash((int) Math.floor(a * 20), (int) Math.floor(h * 20)) - 0.5);
        if (e >= edge || h < 0) return 0;
        double sp = 0.8 + 0.5 * hash((int) Math.floor(a * 28), (int) Math.floor(h * 28));
        return 0xFF000000 | mul(hash(sub, 3) > 0.5 ? 0x132616 : 0x0F1E14, sp * (0.85 + 0.3 * moonSide * clampPm(a / 0.33)));
    }

    private int stump(double a, double h) {
        if (Math.abs(a) >= 0.14 || h >= 0.2) return 0;
        if (h > 0.17) return 0xFF000000 | mul(0x4A3A28, 0.9 + 0.1 * moonSide);
        return 0xFF000000 | bark(0x2A2016, a / 0.14, a, h);
    }

    /** A soft light: added to what is behind it, hidden where the tree wall is in front of it. */
    private void glow(double wxs, double wys, double hUnits, double radUnits, int rgb, double alpha, double maxRange) {
        if (!proj(wxs, wys)) return;
        double f = pf, full = pfull;
        double a = alpha * Math.max(0, 1 - f / maxRange) * Math.min(1, f / 1.5);    // it fades out when you walk into it
        if (a < 0.01) return;
        double cy = HOR + full / 2 - hUnits * full, cx = pcx, rad = Math.min(radUnits * full, 60);
        int ya = Math.max(0, (int) (cy - rad)), yb = Math.min(RH - 1, (int) (cy + rad));
        int xa = Math.max(0, (int) (cx - rad)), xb = Math.min(RW - 1, (int) (cx + rad));
        for (int x = xa; x <= xb; x++) {
            if (f >= zbuf[x]) continue;
            for (int y = ya; y <= yb; y++) {
                double d = Math.hypot(x - cx, y - cy);
                if (d >= rad) continue;
                double t = 1 - d / rad;
                addPix(y * RW + x, rgb, a * t * t * 1.1);
            }
        }
    }

    private void fire(int i) {
        boolean on = oSub[i] > 0;
        double sx = oX[i], sy = oY[i];
        if (!proj(sx, sy)) return;
        double f = pf, cx = pcx, full = pfull;
        int ground = HOR + (int) Math.round(full / 2);
        int x0 = Math.max(0, (int) Math.floor(cx - 0.16 * full)), x1 = Math.min(RW, (int) Math.ceil(cx + 0.16 * full));
        int y0 = Math.max(0, (int) Math.floor(ground - 1.3 * full)), y1 = Math.min(RH, ground + 1);
        lightAt(sx, sy);
        double flick = on ? 0.9 + 0.2 * Math.sin(ticks / 3.0 + sx * 7) : 1;
        for (int x = x0; x < x1; x++) {
            if (f >= zbuf[x]) continue;
            double a = Math.abs((x + 0.5 - cx) / full);
            for (int y = y0; y < y1; y++) {
                double h = (ground - (y + 0.5)) / full;
                if (a < 0.035 && h < 0.85) { fm = 1; pix[y * RW + x] = fin(0x1E1812, 0.9, f); continue; }      // the post
                if (a < 0.13 && h >= 1.2 && h < 1.25) { fm = 1.7; pix[y * RW + x] = fin(0x1A1410, 1, f); continue; }   // the cap
                if (a < 0.11 && h >= 0.96 && h < 1.2) {                                                       // the lantern
                    boolean core = a < 0.05 && h > 1.02 && h < 1.14;
                    pix[y * RW + x] = on ? finGlow(core ? 0xFFF4C0 : 0xFFD060, (core ? 1.25 : 1.1) * flick, f, 1.7) : finGlow(0x3A2A1A, 1, f, 1.7);
                }
            }
        }
        if (on) glow(sx, sy, 1.08, 1.1 + 0.1 * Math.sin(ticks / 4.0 + sx), 0xFFB040, 0.5, 18);
        else glow(sx, sy, 1.08, 0.6, 0xFF8A2A, 0.44, 13);         // a faint ember: a warm dot far away
    }

    private void wisp(int i) {
        int w = oSub[i];
        if ((ticks / 5 + w * 3) % 11 == 0) return;                // it flickers
        double sx = oX[i], sy = oY[i];
        if (!proj(sx, sy)) return;
        double f = pf, cx = pcx, full = pfull;
        double hh = 0.6 + 0.08 * Math.sin(ticks / 14.0 + w);
        glow(sx, sy, hh, 0.85, 0x4AA8FF, 0.7, 15);
        double cy = HOR + full / 2 - hh * full, r = Math.max(1.5, full * 0.06);
        for (int x = Math.max(0, (int) (cx - r)); x <= Math.min(RW - 1, (int) (cx + r)); x++) {
            if (f >= zbuf[x]) continue;
            for (int y = Math.max(0, (int) (cy - r)); y <= Math.min(RH - 1, (int) (cy + r)); y++) {
                if (Math.hypot(x - cx, y - cy) <= r) pix[y * RW + x] = finGlow(0xD8F0FF, 1, f, 15 / fogR);
            }
        }
    }

    private void road(int i) {
        double sx = oX[i], sy = oY[i];
        if (!proj(sx, sy)) return;
        double f = pf, cx = pcx, full = pfull;
        int ground = HOR + (int) Math.round(full / 2);
        int x0 = Math.max(0, (int) Math.floor(cx - 1.15 * full)), x1 = Math.min(RW, (int) Math.ceil(cx + 1.15 * full));
        int y0 = Math.max(0, (int) Math.floor(ground - 1.7 * full)), y1 = Math.min(RH, ground + 1);
        lightAt(sx, sy);
        fm = 2.2;
        for (int x = x0; x < x1; x++) {
            if (f >= zbuf[x]) continue;
            double a = Math.abs((x + 0.5 - cx) / full);
            for (int y = y0; y < y1; y++) {
                double h = (ground - (y + 0.5)) / full;
                if (h < 0.05 && a < 1.1) pix[y * RW + x] = fin(0x707060, 1, f);                              // the road
                else if (a < 0.04 && h < 1.4) pix[y * RW + x] = fin(0x3A3A34, 1, f);                         // a lamp post
                else if (a < 0.13 && h >= 1.45 && h < 1.65) pix[y * RW + x] = finGlow(0xD8FFE0, 1.2, f, 2.2);
            }
        }
        fm = 1;
        glow(sx, sy, 1.45, 1.3, 0xA8FFC0, 0.25, 22);
    }

    private void monster(int i) {
        double sx = oX[i], sy = oY[i];
        if (!proj(sx, sy)) return;
        double f = pf, cx = pcx, full = pfull;
        int ground = HOR + (int) Math.round(full / 2);
        double hw = 0.39, ht = 1.55;
        int x0 = Math.max(0, (int) Math.floor(cx - hw * full)), x1 = Math.min(RW, (int) Math.ceil(cx + hw * full));
        int y0 = Math.max(0, (int) Math.floor(ground - ht * full)), y1 = Math.min(RH, ground + 1);
        if (full * ht < 3) return;
        lightAt(sx, sy);
        fm = 1;
        int rows = monsterBits.length;
        for (int x = x0; x < x1; x++) {
            if (f >= zbuf[x]) continue;
            int u = Math.max(0, Math.min(11, (int) ((x + 0.5 - cx + hw * full) / (2 * hw * full) * 12)));
            for (int y = y0; y < y1; y++) {
                double h = (ground - (y + 0.5)) / full;
                int row = (int) ((ht - h) / ht * rows);
                if (row < 0 || row >= rows) continue;
                char ch = monsterBits[row].charAt(u);
                if (ch == '.') continue;
                if (ch == 'r') pix[y * RW + x] = finGlow(0xFF2A2A, 1.1, f, 3.5);                // the eyes glow through the fog
                else pix[y * RW + x] = fin(ch == 'w' ? 0xB8B4BC : 0x0C0A10, 1, f);
            }
        }
        glow(sx, sy, 1.25, 0.28, 0xFF2020, 0.35, 13);              // a red haze round the eyes
    }
}
