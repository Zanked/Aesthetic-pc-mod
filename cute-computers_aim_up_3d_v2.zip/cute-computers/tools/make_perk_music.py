#!/usr/bin/env python3
"""
Makes the music of the perk machines of Zombie Shooter: for every machine a LOOP that plays while you stand near it
(8 bars, seamless) and a JINGLE (8 seconds) that plays once when you buy the perk.

    python3 tools/make_perk_music.py     # writes sounds/perk/{loop,jingle}_<name>.ogg and registers perk.<...> in sounds.json

All six tunes are ORIGINAL (composed for this mod, in the spirit of 1950s jingles; they are not the songs of any game):
    revive  Quick Revive      a gentle waltz on a music box
    cola    Speed Cola        a quick ragtime on a honky-tonk piano
    stamin  Stamin-Up         a running shuffle with brass and a walking bass
    jugg    Juggernog         a heavy stomp in D minor
    tap     Double Tap II     a country shuffle where every note is tapped twice
    mule    Mule Kick         a little mariachi with guitars, a trumpet and castanets
    pap     Pack-a-Punch      an eerie bell tune over a dark drone and clanking iron
The MYSTERY BOX has three more sounds (sounds/perk/box_*.ogg): box_open (the lid creaks, a glitter), box_roll (an eerie music-box lullaby,
exactly 5 seconds + a ring-out, played while the guns flip) and box_teddy (a mocking jack-in-the-box, played when the teddy bear comes up).
Everything is synthesized (no samples), like the other tools/make_*_audio.py. Needs numpy + scipy + ffmpeg (with libvorbis).
The names and the 8 second length of the jingles are also used by client/game/PerkMusic.java.
"""
import json
import os
import re
import subprocess
import tempfile
import wave

import numpy as np
from scipy.signal import butter, lfilter

SR = 32000
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "src/main/resources/assets/cutemod")
OUT = os.path.join(ASSETS, "sounds/perk")
JINGLE_SECONDS = 8.0
_rng = np.random.default_rng(1957)


# ---------------------------------------------------------------- notes
def midi(name):
    m = re.fullmatch(r"([A-G])([#b]?)(-?\d)", name)
    base = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}[m.group(1)]
    base += {"#": 1, "b": -1, "": 0}[m.group(2)]
    return 12 * (int(m.group(3)) + 1) + base


def freq(name):
    return 440.0 * 2 ** ((midi(name) - 69) / 12.0)


def tt(n):
    return np.arange(n) / SR


def filt(x, kind, lo, hi=None, order=2):
    nyq = SR / 2.0
    if kind == "bp":
        b, a = butter(order, [lo / nyq, min(hi, nyq * 0.95) / nyq], btype="band")
    else:
        b, a = butter(order, min(lo, nyq * 0.95) / nyq, btype=kind)
    return lfilter(b, a, x)


def noise(n):
    return _rng.standard_normal(n)


# ---------------------------------------------------------------- instruments (each returns the whole sound incl. the ring-out)
def music_box(f, dur):
    n = int((dur + 1.0) * SR); t = tt(n)
    x = (np.sin(2 * np.pi * f * t) * np.exp(-t * 4.5)
         + 0.35 * np.sin(2 * np.pi * f * 3.99 * t) * np.exp(-t * 9)
         + 0.12 * np.sin(2 * np.pi * f * 9.8 * t) * np.exp(-t * 20))
    x[:40] *= np.linspace(0, 1, 40)
    return x * 0.5


def piano(f, dur, honky=True):
    n = int((dur + 0.8) * SR); t = tt(n)
    x = np.zeros(n)
    detune = [1.0045, 0.9955] if honky else [1.0]
    for d in detune:
        for h in range(1, 8):
            x += np.sin(2 * np.pi * f * d * h * t) * (1.0 / h ** 1.15) * np.exp(-t * (2.2 + h * 1.6))
    x /= len(detune)
    x[:60] *= np.linspace(0, 1, 60)
    rel = int(0.09 * SR); end = int(dur * SR)
    if end + rel < n:
        x[end:end + rel] *= np.linspace(1, 0, rel); x[end + rel:] = 0
    return x * 0.5


def brass(f, dur, vib=True, bright=1.0):
    n = int((dur + 0.15) * SR); t = tt(n)
    ph = 2 * np.pi * f * t
    if vib:
        ph = ph + 0.012 * np.sin(2 * np.pi * 5.5 * t) * np.clip((t - 0.12) * 4, 0, 1) * 2 * np.pi * f / 40
    bright_env = 1 - np.exp(-t * 14)
    dull = sum(np.sin(h * ph) / h for h in range(1, 4))
    full = sum(np.sin(h * ph) / h for h in range(1, int(min(16, SR / 2 / f)) + 1))
    x = dull * (1 - bright_env * bright) + full * bright_env * bright
    env = np.minimum(1, t / 0.03) * 0.85
    rel = int(0.09 * SR); end = int(dur * SR)
    env[end:] *= np.linspace(1, 0, max(1, n - end)) ** 2 if n > end else 1
    return x * env * 0.28


def pluck(f, dur, g=0.992):
    """Karplus-Strong string: a burst of noise in a feedback loop."""
    period = int(round(SR / f))
    n = int((dur + 0.5) * SR)
    x = np.zeros(n)
    burst = filt(noise(period), "lp", 5000) if period > 8 else noise(period)
    x[:period] = burst
    a = np.zeros(period + 2); a[0] = 1.0; a[period] = -g / 2; a[period + 1] = -g / 2
    y = lfilter([1.0], a, x)
    y = filt(y, "lp", 4200)
    return y * 0.5


def bass_pluck(f, dur):
    n = int((dur + 0.4) * SR); t = tt(n)
    x = np.sin(2 * np.pi * f * t) * np.exp(-t * 5) + 0.45 * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t * 9)
    x[:30] *= np.linspace(0, 1, 30)
    return x * 0.8


def sawpad(f, dur):
    n = int((dur + 0.3) * SR); t = tt(n)
    x = sum(np.sin(2 * np.pi * f * h * t * (1 + 0.002 * (h % 2))) / h for h in range(1, 7))
    env = np.minimum(1, t / 0.12)
    end = int(dur * SR)
    env[end:] *= np.linspace(1, 0, max(1, n - end))
    return filt(x, "lp", 1800) * env * 0.25


def kick(depth=1.0):
    n = int(0.28 * SR); t = tt(n)
    f = 45 + 95 * np.exp(-t * 28)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 14 / depth)
    x += 0.25 * filt(noise(n), "lp", 900) * np.exp(-t * 60)
    return x * 0.9


def snare():
    n = int(0.22 * SR); t = tt(n)
    x = filt(noise(n), "bp", 1200, 7000) * np.exp(-t * 22) + 0.4 * np.sin(2 * np.pi * 190 * t) * np.exp(-t * 28)
    return x * 0.6


def hat(open_=False):
    n = int((0.25 if open_ else 0.06) * SR); t = tt(n)
    return filt(noise(n), "hp", 6500) * np.exp(-t * (12 if open_ else 70)) * 0.3


def clap():
    n = int(0.2 * SR); t = tt(n)
    x = np.zeros(n)
    for k, d in enumerate([0, 0.011, 0.022]):
        s = int(d * SR)
        x[s:] += filt(noise(n - s), "bp", 900, 3500) * np.exp(-t[:n - s] * (60 if k < 2 else 26))
    return x * 0.55


def castanet():
    n = int(0.08 * SR); t = tt(n)
    x = filt(noise(n), "bp", 1800, 5200) * np.exp(-t * 110)
    s = int(0.012 * SR)
    x[s:] += 0.6 * filt(noise(n - s), "bp", 1800, 5200) * np.exp(-t[:n - s] * 130)
    return x * 0.7


def clank(pitch=1.0):
    """A hit on an iron anvil: inharmonic ringing partials and a burst of noise."""
    n = int(0.7 * SR); t = tt(n)
    x = sum(a * np.sin(2 * np.pi * f * pitch * t) * np.exp(-t * d) for f, a, d in
            [(620, 1.0, 9), (1130, 0.6, 12), (1710, 0.4, 16), (2490, 0.25, 22)])
    x += filt(noise(n), "bp", 2500, 7000) * np.exp(-t * 70) * 0.8
    return x * 0.35


def cymbal():
    n = int(1.6 * SR); t = tt(n)
    return filt(noise(n), "hp", 5000) * np.exp(-t * 3.2) * 0.3


# ---------------------------------------------------------------- the mixer
class Track:
    def __init__(self, seconds, wrap):
        self.n = int(seconds * SR)
        self.wrap = wrap
        self.x = np.zeros(self.n + (0 if wrap else 3 * SR))

    def add(self, sig, sec, gain=1.0):
        s = int(round(sec * SR))
        sig = sig * gain
        if self.wrap:
            s %= self.n
            for i in range(0, len(sig), self.n):          # a sound may ring around the end of the loop
                part = sig[i:i + self.n]
                a = (s + i) % self.n
                m = min(len(part), self.n - a)
                self.x[a:a + m] += part[:m]
                if m < len(part): self.x[:len(part) - m] += part[m:]
        else:
            e = min(len(self.x), s + len(sig))
            if s < e: self.x[s:e] += sig[:e - s]

    def done(self, seconds=None):
        x = self.x if seconds is None else self.x[:int(seconds * SR)]
        x = np.tanh(x * 1.4) / np.tanh(1.4)
        x = x / max(1e-9, np.max(np.abs(x))) * 0.82
        return x


# ---------------------------------------------------------------- songs
def parse(line):
    """'A4:1 C5:.5 r:1' -> [(note or None, beats)]"""
    out = []
    for tok in line.split():
        nm, b = tok.split(":")
        out.append((None if nm == "r" else nm, float(b)))
    return out


class Song:
    def __init__(self, name, bpm, beats, style, swing, bars, tonic, tonic_note):
        self.name, self.bpm, self.beats, self.style, self.swing = name, bpm, beats, style, swing
        self.bars = bars                       # [(chord notes, bass note, melody string)]
        self.tonic, self.tonic_note = tonic, tonic_note
        self.spb = 60.0 / bpm
        for i, (_, _, mel) in enumerate(bars):
            tot = sum(b for _, b in parse(mel))
            assert abs(tot - beats) < 1e-6, f"{name} bar {i + 1}: {tot} beats instead of {beats}"

    def at(self, bar, beat):
        """time in seconds of a position (swing: the off-beat eighths are late)."""
        frac = beat % 1.0
        if self.swing and abs(frac - 0.5) < 1e-6: beat += self.swing
        return (bar * self.beats + beat) * self.spb

    @property
    def loop_seconds(self):
        return len(self.bars) * self.beats * self.spb


def render_bars(song, tr, bar_range):
    st, spb = song.style, song.spb
    for bi in bar_range:
        chord, bass, mel = song.bars[bi]
        root_f = freq(bass)
        # ---- the melody
        pos = 0.0
        for note, b in parse(mel):
            if note is not None:
                t0, dur = song.at(bi, pos), b * spb * 0.92
                f = freq(note)
                if st == "waltz":
                    tr.add(music_box(f, dur), t0, 0.9)
                    tr.add(music_box(f * 2, dur), t0, 0.18)
                elif st == "ragtime":
                    tr.add(piano(f, dur), t0, 0.9)
                    tr.add(piano(f * 2, dur), t0, 0.15)
                elif st == "sport":
                    tr.add(brass(f, dur), t0, 0.9)
                    tr.add(brass(f / 2, dur, vib=False, bright=0.5), t0, 0.35)
                elif st == "stomp":
                    tr.add(brass(f, dur, bright=0.8), t0, 1.0)
                    tr.add(brass(f / 2, dur, vib=False, bright=0.4), t0, 0.5)
                elif st == "honky":
                    tr.add(piano(f, dur), t0, 0.9)
                    tr.add(pluck(f * 2, dur), t0, 0.35)
                elif st == "pap":
                    tr.add(music_box(f, dur * 1.5), t0, 0.85)
                    tr.add(music_box(f * 1.007, dur * 1.5), t0 + 0.01, 0.5)
                    tr.add(brass(f / 2, dur, vib=False, bright=0.25), t0, 0.28)
                elif st == "mariachi":
                    tr.add(brass(f, dur, bright=1.0), t0, 0.8)
                    third = freq(note) / 2 ** (4 / 12.0) if (midi(note) % 12) in (0, 4, 5, 7, 9, 11) else freq(note) / 2 ** (3 / 12.0)
                    tr.add(brass(third, dur, vib=False, bright=0.8), t0, 0.35)
            pos += b
        # ---- the band
        cf = [freq(n) for n in chord]
        beats = song.beats
        if st == "waltz":
            tr.add(bass_pluck(root_f, spb * 1.6), song.at(bi, 0), 0.9)
            for k in (1, 2):
                for j, f in enumerate(cf):                                   # a soft broken chord on beats 2 and 3
                    tr.add(music_box(f, spb * 0.8), song.at(bi, k) + j * 0.025, 0.28)
            tr.add(hat(), song.at(bi, 1), 0.35); tr.add(hat(), song.at(bi, 2), 0.35)
        elif st == "ragtime":
            for k in range(beats):
                if k % 2 == 0:
                    tr.add(piano(root_f / (2 if k == 0 else 1.5), spb * 0.9), song.at(bi, k), 0.75)
                    tr.add(kick(0.6), song.at(bi, k), 0.35)
                else:
                    for f in cf: tr.add(piano(f, spb * 0.5), song.at(bi, k), 0.3)
                    tr.add(snare(), song.at(bi, k), 0.3)
            for k in range(beats): tr.add(hat(), song.at(bi, k + 0.5), 0.3)
        elif st == "sport":
            walk = [root_f, root_f * 1.5, root_f * 2, root_f * 1.5]
            for k in range(beats):
                tr.add(bass_pluck(walk[k % 4], spb * 0.9), song.at(bi, k), 0.8)
                tr.add(hat(), song.at(bi, k + 0.5), 0.35); tr.add(hat(), song.at(bi, k), 0.2)
                if k % 2 == 0: tr.add(kick(), song.at(bi, k), 0.6)
                else: tr.add(clap(), song.at(bi, k), 0.55)
            for f in cf: tr.add(sawpad(f, beats * spb * 0.95), song.at(bi, 0), 0.22)
        elif st == "stomp":
            for k in range(beats):
                tr.add(kick(1.3), song.at(bi, k), 0.85)
                if k % 2 == 1: tr.add(clap(), song.at(bi, k), 0.7); tr.add(snare(), song.at(bi, k), 0.35)
            for k in range(beats * 2):
                tr.add(bass_pluck(root_f / 2 if k % 2 == 0 else root_f, spb * 0.45), song.at(bi, k / 2.0), 0.7)
            for f in cf: tr.add(sawpad(f / 2, beats * spb * 0.97), song.at(bi, 0), 0.3)
            if bi % 4 == 3:                                                    # a snare roll at the end of a phrase
                for j in range(6): tr.add(snare(), song.at(bi, beats - 1 + j / 6.0), 0.2 + 0.08 * j)
        elif st == "honky":
            for k in range(beats):
                tr.add(bass_pluck(root_f if k % 2 == 0 else root_f * 1.5, spb * 0.8), song.at(bi, k), 0.8)
                if k % 2 == 0: tr.add(kick(0.7), song.at(bi, k), 0.45)
                else: tr.add(snare(), song.at(bi, k), 0.4)
                for j, f in enumerate(cf):                                      # banjo-like chords on the off-beats
                    tr.add(pluck(f * 2, spb * 0.4), song.at(bi, k + 0.5) + j * 0.012, 0.28)
                tr.add(hat(), song.at(bi, k + 0.5), 0.25)
        elif st == "pap":
            for f in cf: tr.add(sawpad(f / 2, beats * spb * 0.98), song.at(bi, 0), 0.34)          # a dark drone
            tr.add(bass_pluck(root_f / 2, spb * 1.5), song.at(bi, 0), 0.9)
            tr.add(kick(1.1), song.at(bi, 0), 0.6)
            tr.add(clank(1.0), song.at(bi, 1), 0.5); tr.add(clank(0.8), song.at(bi, 3), 0.4)     # iron on iron
            tr.add(clank(1.5), song.at(bi, 2.5), 0.22)
            for k in range(beats * 2): tr.add(hat(), song.at(bi, k / 2.0), 0.14)
        elif st == "mariachi":
            for k in range(beats):
                tr.add(bass_pluck(root_f / (1 if k != 1 else 1.5), spb * 0.9), song.at(bi, k), 0.85)
                strum = [0, 1, 2] if k != 0 else [0, 1, 2, 3]
                for j, f in enumerate(cf):                                      # a guitar strum: the strings one after another
                    tr.add(pluck(f * 2, spb * 0.7), song.at(bi, k + 0.5) + j * 0.014, 0.4)
                tr.add(castanet(), song.at(bi, k), 0.45)
                tr.add(castanet(), song.at(bi, k + 0.5), 0.3)
            tr.add(castanet(), song.at(bi, 0.25), 0.2)


def render_loop(song):
    tr = Track(song.loop_seconds, wrap=True)
    render_bars(song, tr, range(len(song.bars)))
    return tr.done()


def render_jingle(song):
    """The first bars of the tune, then the tonic chord as a stinger (the cymbal rings out to the end of the 8 seconds)."""
    nb = max(2, int((JINGLE_SECONDS - 2.4) / (song.beats * song.spb)))
    tr = Track(JINGLE_SECONDS, wrap=False)
    render_bars(song, tr, range(nb))
    t0 = nb * song.beats * song.spb
    for j, n in enumerate(song.tonic):
        f = freq(n)
        if song.style in ("waltz",):
            tr.add(music_box(f, 2.0), t0 + j * 0.05, 0.7)
        elif song.style in ("ragtime", "honky"):
            tr.add(piano(f, 1.8), t0 + j * 0.02, 0.8)
        else:
            tr.add(brass(f, 1.8, bright=0.9), t0 + j * 0.02, 0.6)
    tr.add(brass(freq(song.tonic_note), 1.9, bright=0.8) if song.style not in ("waltz", "ragtime", "honky")
           else piano(freq(song.tonic_note), 1.9), t0, 0.9)
    tr.add(bass_pluck(freq(song.tonic_note) / 2, 1.8), t0, 0.9)
    tr.add(kick(1.2), t0, 0.8); tr.add(cymbal(), t0, 0.6)
    x = tr.done(JINGLE_SECONDS)
    fade = int(0.6 * SR)
    x[-fade:] *= np.linspace(1, 0, fade)                                       # the tail fades out, so the file ends in silence
    return x


# ---------------------------------------------------------------- the six tunes
SONGS = [
    Song("revive", 96, 3, "waltz", 0, [                                       # Quick Revive: a waltz in F
        (["F3", "A3", "C4"], "F2", "A4:1 C5:1 F5:1"),
        (["D3", "F3", "A3"], "D2", "D5:1.5 C5:.5 A4:1"),
        (["Bb3", "D4", "F4"], "Bb2", "Bb4:1 D5:1 F5:1"),
        (["C4", "E4", "G4", "Bb4"], "C2", "E5:2 r:1"),
        (["F3", "A3", "C4"], "F2", "A4:1 C5:1 F5:1"),
        (["A3", "C4", "E4"], "A2", "E5:1.5 D5:.5 C5:1"),
        (["Bb3", "D4", "F4"], "Bb2", "D5:1 C5:.5 Bb4:.5 A4:1"),
        (["C4", "E4", "G4"], "C2", "G4:2 r:1"),
    ], ["F4", "A4", "C5", "F5"], "F5"),
    Song("cola", 168, 4, "ragtime", 0.17, [                                    # Speed Cola: a quick ragtime in C
        (["E4", "G4", "C5"], "C3", "E5:.5 G5:.5 E5:.5 C5:.5 D5:.5 E5:.5 G5:1"),
        (["E4", "G4", "C#5"], "A2", "A5:.5 G5:.5 E5:.5 C#5:.5 E5:1 A4:1"),
        (["F#4", "A4", "C5"], "D3", "F#5:.5 A5:.5 F#5:.5 D5:.5 E5:.5 F#5:.5 A5:1"),
        (["F4", "B4", "D5"], "G2", "B5:.5 A5:.5 G5:.5 F5:.5 D5:2"),
        (["E4", "G4", "C5"], "C3", "E5:.5 G5:.5 C6:1 B5:.5 A5:.5 G5:1"),
        (["F4", "A4", "C5"], "F2", "A5:.5 C6:.5 A5:.5 F5:.5 G5:.5 A5:.5 C6:1"),
        (["F4", "B4", "D5"], "G2", "D6:1 B5:.5 G5:.5 F5:1 D5:1"),
        (["E4", "G4", "C5"], "C3", "C6:.5 G5:.5 E5:.5 G5:.5 C5:2"),
    ], ["C4", "E4", "G4", "C5"], "C6"),
    Song("stamin", 132, 4, "sport", 0.17, [                                    # Stamin-Up: a running shuffle in G
        (["B3", "D4", "G4"], "G2", "G4:.5 B4:.5 D5:1 B4:.5 D5:.5 G5:1"),
        (["C4", "E4", "G4"], "C3", "E5:1 D5:.5 C5:.5 E5:1 G5:1"),
        (["B3", "D4", "G4"], "G2", "D5:.5 G5:.5 B5:1 A5:.5 G5:.5 B4:1"),
        (["A3", "D4", "F#4"], "D3", "A4:.5 D5:.5 F#5:1 A5:2"),
        (["B3", "D4", "G4"], "G2", "G5:.5 B5:.5 D6:1 B5:.5 G5:.5 D5:1"),
        (["C4", "E4", "G4"], "C3", "E5:.5 G5:.5 C6:1 G5:.5 E5:.5 C5:1"),
        (["A3", "D4", "F#4"], "D3", "F#5:1 A5:.5 F#5:.5 D5:1 A4:1"),
        (["B3", "D4", "G4"], "G2", "G4:.5 B4:.5 D5:.5 G5:.5 B5:2"),
    ], ["G3", "B3", "D4", "G4"], "G5"),
    Song("jugg", 100, 4, "stomp", 0, [                                          # Juggernog: a heavy stomp in D minor
        (["D3", "F3", "A3"], "D2", "D4:1 D4:.5 F4:.5 A4:1 G4:1"),
        (["D3", "F3", "A3"], "D2", "F4:1.5 E4:.5 D4:2"),
        (["Bb3", "D4", "F4"], "Bb1", "Bb3:1 D4:.5 F4:.5 Bb4:1 A4:1"),
        (["A3", "C#4", "E4"], "A1", "E4:1 C#4:.5 E4:.5 A4:2"),
        (["D3", "F3", "A3"], "D2", "D4:1 F4:.5 A4:.5 D5:1 C5:1"),
        (["G3", "Bb3", "D4"], "G1", "Bb4:1 A4:.5 G4:.5 D4:2"),
        (["A3", "C#4", "E4"], "A1", "E4:.5 F4:.5 E4:.5 C#4:.5 A3:2"),
        (["D3", "F3", "A3"], "D2", "D4:3 r:1"),
    ], ["D3", "F3", "A3", "D4"], "D4"),
    Song("tap", 124, 4, "honky", 0.1, [                                         # Double Tap II: every note is tapped twice
        (["A3", "C#4", "E4"], "A2", "A4:.25 A4:.25 C#5:.25 C#5:.25 E5:.25 E5:.25 A5:.25 A5:.25 E5:1 C#5:1"),
        (["A3", "D4", "F#4"], "D3", "D5:.25 D5:.25 F#5:.25 F#5:.25 A5:1 F#5:.5 D5:.5 A4:1"),
        (["A3", "C#4", "E4"], "A2", "C#5:.25 C#5:.25 E5:.25 E5:.25 A5:.5 G#5:.5 A5:1 r:1"),
        (["G#3", "B3", "E4"], "E3", "B4:.25 B4:.25 D5:.25 D5:.25 E5:1 G#5:.5 E5:.5 B4:1"),
        (["A3", "C#4", "E4"], "A2", "A4:.25 A4:.25 C#5:.25 C#5:.25 E5:.25 E5:.25 A5:.25 A5:.25 C#6:1 A5:1"),
        (["A3", "D4", "F#4"], "D3", "F#5:.25 F#5:.25 A5:.25 A5:.25 D6:1 C#6:.5 A5:.5 F#5:1"),
        (["G#3", "B3", "E4"], "E3", "G#5:.5 B5:.5 E6:1 D6:.5 B5:.5 G#5:1"),
        (["A3", "C#4", "E4"], "A2", "A5:.5 E5:.5 C#5:.5 A4:.5 A4:2"),
    ], ["A3", "C#4", "E4", "A4"], "A5"),
    Song("mule", 138, 3, "mariachi", 0, [                                       # Mule Kick: a little mariachi in A minor
        (["A3", "C4", "E4"], "A2", "A4:1 C5:.5 B4:.5 A4:1"),
        (["G#3", "B3", "E4"], "E2", "G#4:1 B4:.5 D5:.5 E5:1"),
        (["A3", "C4", "E4"], "A2", "C5:1 E5:.5 D5:.5 C5:1"),
        (["G#3", "B3", "E4"], "E2", "B4:1 G#4:1 E4:1"),
        (["A3", "D4", "F4"], "D3", "D5:1 F5:.5 E5:.5 D5:1"),
        (["A3", "C4", "E4"], "A2", "C5:.5 D5:.5 E5:1 A5:1"),
        (["G#3", "B3", "E4"], "E2", "G#5:.5 F5:.5 E5:1 B4:1"),
        (["A3", "C4", "E4"], "A2", "A4:2 r:1"),
    ], ["A3", "C4", "E4", "A4"], "A4"),
    Song("pap", 90, 4, "pap", 0, [                                              # Pack-a-Punch: an eerie bell tune in E minor
        (["E3", "G3", "B3"], "E2", "E5:1 G5:.5 F#5:.5 E5:1 B4:1"),
        (["C4", "E4", "G4"], "C3", "C5:1 E5:1 D5:1 B4:1"),
        (["A3", "C4", "E4"], "A2", "A4:1 C5:.5 B4:.5 A4:1 E4:1"),
        (["B3", "D#4", "F#4", "A4"], "B2", "D#5:1 F#5:1 B5:1 A5:.5 F#5:.5"),
        (["E3", "G3", "B3"], "E2", "E5:1 G5:.5 F#5:.5 E5:1 B4:1"),
        (["C4", "E4", "G4"], "C3", "C5:1 E5:.5 D5:.5 C5:1 G4:1"),
        (["A3", "C4", "E4"], "A2", "A4:1 C5:1 B4:.5 A4:.5 G#4:1"),
        (["B3", "D#4", "F#4", "A4"], "B2", "B4:2 D#5:1 F#5:1"),
    ], ["E3", "G3", "B3", "E4"], "E5"),
]



# ---------------------------------------------------------------- the mystery box
def box_open():
    """The lid creaks open (noise through a rising band-pass, shaken), then a glitter of bells."""
    n = int(1.5 * SR); t = tt(n)
    sweep = np.cumsum(260 + 520 * np.clip(t / 0.7, 0, 1)) / SR
    creak = np.sin(2 * np.pi * sweep) * 0.5 + filt(noise(n), "bp", 300, 1400) * 0.9
    creak *= (0.55 + 0.45 * np.sign(np.sin(2 * np.pi * 23 * t))) * np.exp(-np.maximum(t - 0.55, 0) * 9) * (t < 0.8)
    x = creak * 0.5
    x[:int(0.02 * SR)] *= np.linspace(0, 1, int(0.02 * SR))
    tr = Track(1.5, wrap=False)
    tr.add(x, 0.0, 0.9)
    for i, nm in enumerate(["E5", "A5", "C6", "E6", "A6", "C7"]):                       # the glitter
        tr.add(music_box(freq(nm), 0.2), 0.55 + i * 0.085, 0.55)
    tr.add(filt(noise(int(0.9 * SR)), "hp", 4000) * np.exp(-tt(int(0.9 * SR)) * 4) * 0.25, 0.6, 0.6)
    out = tr.done(1.5)
    f = int(0.3 * SR); out[-f:] *= np.linspace(1, 0, f)
    return out


def box_roll():
    """An eerie lullaby on two slightly out-of-tune music boxes: three bars of 3/4 (Am, Dm, E7) = 5.0 seconds, left hanging on the E7
    so that the 'ready' chime of the game resolves it."""
    bpm = 108; spb = 60.0 / bpm; total = 9 * spb
    tr = Track(total, wrap=False)
    mel = ["E5", "A5", "G5", "F5", "E5", "D5", "B4", "G#4", "E4"]
    for i, nm in enumerate(mel):
        f = freq(nm); t0 = i * spb
        tr.add(music_box(f, spb), t0, 0.95)
        tr.add(music_box(f * 1.006, spb), t0 + 0.012, 0.5)                              # the second box, a little sharp: eerie
        tr.add(music_box(f * 2, spb), t0, 0.14)
    chords = [(["A3", "C4", "E4"], "A2"), (["D3", "F3", "A3"], "D2"), (["E3", "G#3", "B3", "D4"], "E2")]
    for bar, (ch, root) in enumerate(chords):
        tr.add(music_box(freq(root), spb * 2), bar * 3 * spb, 0.7)
        for k in (1, 2):
            for j, nm in enumerate(ch):
                tr.add(music_box(freq(nm), spb * 0.8), (bar * 3 + k) * spb + j * 0.03, 0.22)
    for i in range(9): tr.add(hat(), i * spb, 0.12)                                       # a clock ticking
    for j, nm in enumerate(["E6", "G#6", "B6", "D7"]):                                    # a rising glitter on the last beat
        tr.add(music_box(freq(nm), 0.4), 8 * spb + j * spb / 4.5, 0.3)
    out = tr.done(total + 1.2)
    f = int(0.7 * SR); out[-f:] *= np.linspace(1, 0, f)
    return out


def box_teddy():
    """A jack-in-the-box that laughs at you: a mocking, flat music-box tune and then four sad trombone notes."""
    spb = 0.5
    tr = Track(5.6, wrap=False)
    mel = [("E5", .5), ("C5", .5), ("A4", 1), ("E5", .5), ("C5", .5), ("A4", 1), ("G5", .5), ("E5", .5), ("C5", .5), ("A4", .5)]
    pos = 0.0
    for nm, b in mel:
        f = freq(nm) * 0.985                                                                # a little flat
        tr.add(music_box(f, b * spb), pos * spb, 0.9)
        tr.add(music_box(f * 1.012, b * spb), pos * spb, 0.45)
        pos += b
    t0 = pos * spb + 0.1
    for i, (nm, d) in enumerate([("A3", .45), ("G#3", .45), ("G3", .45), ("F#3", 1.3)]):   # wah wah wah wahhh
        n = int((d + 0.2) * SR); t = tt(n)
        f = freq(nm) * (1 - 0.03 * (t / d)) if i == 3 else freq(nm)
        ph = np.cumsum(f * (1 + 0.012 * np.sin(2 * np.pi * 6 * t))) / SR
        x = sum(np.sin(2 * np.pi * h * ph) / h for h in range(1, 9))
        x = filt(x, "lp", 1100) * np.minimum(1, t / 0.04) * np.exp(-np.maximum(t - d, 0) * 25) * 0.35
        tr.add(x, t0, 0.9)
        t0 += d
    tr.add(kick(1.2), t0 - 1.3, 0.5)
    out = tr.done(5.6)
    f = int(0.5 * SR); out[-f:] *= np.linspace(1, 0, f)
    return out

def pap_work():
    """The machine upgrades the gun: a low rumble, drums turning, hammer blows, a rising whine, and a last heavy 'ka-chunk' at 4.6 s (5 s in all)."""
    total = 5.2
    n = int(total * SR); t = tt(n)
    tr = Track(total, wrap=False)
    rumble = filt(noise(n), "lp", 160) * (0.6 + 0.4 * np.sin(2 * np.pi * 9 * t)) * np.minimum(1, t / 0.3) * 0.9
    whirr_f = 90 + 380 * (t / 4.6) ** 1.6
    whirr = sum(np.sin(2 * np.pi * h * np.cumsum(whirr_f) / SR) / h for h in range(1, 5)) * (0.5 + 0.5 * np.sin(2 * np.pi * 14 * t))
    whirr = filt(whirr, "lp", 1800) * np.minimum(1, t / 0.4) * 0.22
    tr.add(rumble + whirr, 0.0, 1.0)
    for i in range(10):                                                                   # hammer blows, faster and faster
        at = 0.4 + 4.0 * (i / 10.0) ** 0.8
        tr.add(clank(0.7 + 0.08 * (i % 3)), at, 0.5)
        tr.add(kick(0.8), at, 0.4)
    tr.add(filt(noise(int(0.5 * SR)), "hp", 3000) * np.exp(-tt(int(0.5 * SR)) * 6) * 0.3, 4.55, 0.7)   # steam
    tr.add(kick(1.6), 4.6, 1.0); tr.add(clank(0.55), 4.6, 0.9)                            # ka-chunk
    out = tr.done(total)
    f = int(0.4 * SR); out[-f:] *= np.linspace(1, 0, f)
    return out


def pap_ready():
    """The gun is ready: a bright, rising ding-ding."""
    tr = Track(1.6, wrap=False)
    for i, nm in enumerate(["E5", "B5", "E6", "G6"]):
        tr.add(music_box(freq(nm), 0.5), i * 0.11, 0.8)
        tr.add(clank(1.9), i * 0.11, 0.18)
    out = tr.done(1.6)
    f = int(0.4 * SR); out[-f:] *= np.linspace(1, 0, f)
    return out


# ---------------------------------------------------------------- files
def save_ogg(name, x):
    os.makedirs(OUT, exist_ok=True)
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, name + ".wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-c:a", "libvorbis", "-q:a", "4",
                        os.path.join(OUT, name + ".ogg")], check=True)


def register(names):
    path = os.path.join(ASSETS, "sounds.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    for n in names:
        data["perk." + n] = {"sounds": [{"name": "cutemod:perk/" + n, "stream": False}]}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)          # same layout as the file had (no newline at the end)


def main():
    names = []
    for s in SONGS:
        lo, jg = render_loop(s), render_jingle(s)
        save_ogg("loop_" + s.name, lo); save_ogg("jingle_" + s.name, jg)
        names += ["loop_" + s.name, "jingle_" + s.name]
        print(f"{s.name:7s} loop {len(lo) / SR:5.2f} s  jingle {len(jg) / SR:4.1f} s  ({s.bpm} bpm, {s.beats}/4, {s.style})")
    for nm, fn in (("box_open", box_open), ("box_roll", box_roll), ("box_teddy", box_teddy), ("pap_work", pap_work), ("pap_ready", pap_ready)):
        x = fn(); save_ogg(nm, x); names.append(nm)
        print(f"{nm:9s} {len(x) / SR:5.2f} s")
    register(names)
    print("registered", len(names), "sounds in sounds.json")


if __name__ == "__main__":
    main()
