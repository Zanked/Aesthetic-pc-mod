package dev.cutemod.client.game;

import java.io.*;
import java.util.*;

/**
 * Renders a little test room with the 3D props of Zombie Shooter (perk machines, Pack-a-Punch, the mystery box) to a PPM, without Minecraft.
 * Build and run from the project folder:
 *   javac -d /tmp/p3d src/main/java/dev/cutemod/client/game/Prop3D.java src/main/java/dev/cutemod/client/game/ZombieArt.java tools/Prop3DPreview.java
 *   java -cp /tmp/p3d dev.cutemod.client.game.Prop3DPreview out.ppm viewX viewY angleDegrees [boxOpen 0/1] [papWorking 0/1]
 * e.g.  ... out.ppm 18.6 2.6 -130 1   (the open box from the side). The wall is at y = 0, the props stand at x = 2.5, 4.5 ... 16.5.
 */
public class Prop3DPreview {
    static final int W = 220, H = 140, COLS = 110, CW = W / COLS;
    static final double PLANE = 0.75;
    static int[] px = new int[W * H];
    static int hor = H / 2;

    static int shade(int c, double b) {
        b = Math.max(0, Math.min(1.5, b));
        int r = Math.min(255, (int) (((c >> 16) & 255) * b)), g = Math.min(255, (int) (((c >> 8) & 255) * b)), bl = Math.min(255, (int) ((c & 255) * b));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static void main(String[] a) throws Exception {
        double ex = Double.parseDouble(a[1]), ey = Double.parseDouble(a[2]), ang = Math.toRadians(Double.parseDouble(a[3]));
        boolean open = a.length > 4 && a[4].equals("1"), papOn = a.length > 5 && a[5].equals("1");
        int[] cols = {0xFF4AA8E0, 0xFF3FAE4A, 0xFFF08A1A, 0xFFD0302E, 0xFFE8B030, 0xFF2F9A4A};
        List<Prop3D> props = new ArrayList<>();
        for (int i = 0; i < 6; i++) props.add(new Prop3D(2 + i * 2, 0, 0, 1, 0, 32 * 0.0285, 0.38, 0.0285, ZombieArt.machineBare(i, cols[i]), null));
        props.add(new Prop3D(14, 0, 0, 1, 1, 32 * 0.0285, 0.42, 0.0285, ZombieArt.papBare(papOn), null));
        props.add(new Prop3D(16, 0, 0, 1, 2, 32 * 0.029, 0.45, 0.029, ZombieArt.chest(open ? 1 : 0), ZombieArt.chest(open ? 2 : 0)));
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) px[y * W + x] = y < hor ? shade(0xFF222733, 0.8 + 0.4 * y / hor) : shade(0xFF3A342E, 0.6 + 0.8 * (y - hor) / (H - hor));
        double dirX = Math.cos(ang), dirY = Math.sin(ang), plX = -dirY * PLANE, plY = dirX * PLANE;
        for (int col = 0; col < COLS; col++) {
            double cam = 2.0 * (col + 0.5) / COLS - 1;
            double rdx = dirX + plX * cam, rdy = dirY + plY * cam, len = Math.hypot(rdx, rdy);
            rdx /= len; rdy /= len;
            double cosD = Math.cos(Math.atan2(rdy, rdx) - ang);
            double raw = 1e9, wx = 0; boolean side = false;
            if (rdy < -1e-9) { double t = (0 - ey) / rdy; if (t > 0) { raw = t; wx = ex + t * rdx; } }
            if (rdx < -1e-9) { double t = (1 - ex) / rdx; if (t > 0 && t < raw) { raw = t; wx = ey + t * rdy; side = true; } }
            if (rdx > 1e-9) { double t = (19 - ex) / rdx; if (t > 0 && t < raw) { raw = t; wx = ey + t * rdy; side = true; } }
            if (raw > 1e8) continue;
            double d = Math.max(0.05, raw * cosD);
            double b = Math.max(0.12, 1 - d / 9.5) * (side ? 0.75 : 1);
            int lh = (int) (H / d), top = hor - lh / 2;
            for (int y = Math.max(0, top); y < Math.min(H, top + lh); y++) {
                double v = (y - top) * 8.0 / lh, u = wx - Math.floor(wx);
                int row = (int) v;
                int brick = (((int) (u * 8 + (row % 2) * 0.5)) % 2 == 0) ? 0xFF6A4636 : 0xFF74503E;
                if (v - row < 0.12) brick = 0xFF2A1E18;
                for (int xx = col * CW; xx < col * CW + CW; xx++) px[y * W + xx] = shade(brick, b);
            }
            final int fcol = col;
            Prop3D.Sink sink = new Prop3D.Sink() {
                public void fill(int y0, int y1, int argb) {
                    y0 = Math.max(0, y0); y1 = Math.min(H, y1);
                    for (int y = y0; y < y1; y++) for (int xx = fcol * CW; xx < fcol * CW + CW; xx++) px[y * W + xx] = argb;
                }
                public int lit(int rgb, double bb) { return shade(rgb, bb); }
            };
            for (Prop3D p : props) {
                double glow = 0.45;
                if (p.kind == 2 && open) glow = 1.1;
                if (p.kind == 1 && papOn) glow = 1.1;
                double dn = p.drawColumn(sink, ex, ey, rdx, rdy, cosD, raw, hor, H, glow, 1);
                if (dn > 0) {
                    int lhn = (int) (H / dn), fy = hor + lhn / 2;
                    for (int y = fy; y < Math.min(H, fy + Math.max(2, lhn / 12)); y++) for (int xx = col * CW; xx < col * CW + CW; xx++) px[y * W + xx] = shade(px[y * W + xx], 0.5);
                }
            }
        }
        try (OutputStream o = new BufferedOutputStream(new FileOutputStream(a[0]))) {
            o.write(("P6\n" + W + " " + H + "\n255\n").getBytes());
            for (int i = 0; i < W * H; i++) { o.write((px[i] >> 16) & 255); o.write((px[i] >> 8) & 255); o.write(px[i] & 255); }
        }
    }
}
