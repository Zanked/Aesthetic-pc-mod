package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

/**
 * Music player: little songs played on note-block sounds. Each track has a lead voice and a bass voice,
 * stored as {note, length} pairs (note 0..24 = note block range, -1 = rest, length in units).
 * Music plays while the player is open.
 */
public class MusicApp extends App {
    // note numbers: C4 = 6, D4 = 8, E4 = 10, F4 = 11, G4 = 13, A4 = 15, B4 = 17, C5 = 18, D5 = 20, E5 = 22
    private static final int[][] MELODY = {
            // 0: Ode to Joy (traditional, public domain)
            {10, 2, 10, 2, 11, 2, 13, 2, 13, 2, 11, 2, 10, 2, 8, 2, 6, 2, 6, 2, 8, 2, 10, 2, 10, 3, 8, 1, 8, 4,
                    10, 2, 10, 2, 11, 2, 13, 2, 13, 2, 11, 2, 10, 2, 8, 2, 6, 2, 6, 2, 8, 2, 10, 2, 8, 3, 6, 1, 6, 4},
            // 1: Calm Night
            {10, 3, 13, 3, 15, 2, 13, 4, 10, 3, 8, 3, 6, 2, 8, 4, 10, 3, 13, 3, 15, 2, 18, 4, 15, 3, 13, 3, 10, 2, 13, 4},
            // 2: Bee Waltz
            {13, 1, 15, 1, 18, 2, 15, 1, 13, 1, 10, 2, 13, 1, 15, 1, 18, 2, 20, 4,
                    18, 1, 15, 1, 13, 2, 10, 1, 13, 1, 15, 2, 13, 2, 10, 2, 6, 4},
            // 3: Creepy Lullaby
            {10, 6, 13, 2, 16, 6, 13, 2, 10, 4, 9, 4, 10, 8, -1, 8},
            // 4: Rain (shop)
            {15, 2, -1, 2, 13, 2, -1, 2, 10, 2, -1, 2, 13, 2, -1, 2, 15, 3, 18, 1, 15, 2, -1, 2, 13, 4, -1, 4,
                    10, 2, -1, 2, 8, 2, -1, 2, 10, 4, -1, 4},
            // 5: Creeper March (shop)
            {6, 2, 6, 2, 13, 2, 6, 2, 11, 2, 10, 2, 8, 2, 6, 2, 6, 2, 6, 2, 13, 2, 6, 2, 15, 2, 13, 2, 11, 2, 10, 2},
            // 6: Panda Dance (shop)
            {10, 1, 13, 1, 15, 2, 13, 1, 10, 1, 8, 2, 10, 1, 13, 1, 15, 2, 18, 4, 15, 1, 13, 1, 10, 2,
                    8, 1, 10, 1, 13, 2, 10, 2, 6, 2},
            // 7: Starry Night (shop)
            {13, 4, 18, 4, 20, 4, 18, 4, 22, 6, 20, 2, 18, 4, 15, 4, 13, 8},
            // 8: Gray wings (shop)
            {15, 4, 18, 2, 17, 2, 15, 4, 13, 4, 10, 6, 13, 2, 15, 8, 18, 4, 22, 2, 20, 2, 18, 4, 17, 4, 15, 6, 13, 2, 10, 8},
            // 9: Freebird jam (shop)
            {15, 6, 13, 2, 10, 6, 13, 2, 15, 4, 17, 4, 18, 8, 22, 1, 20, 1, 18, 1, 17, 1, 15, 1, 17, 1, 18, 1, 20, 1, 22, 1, 18, 1, 15, 1, 18, 1, 22, 1, 24, 1, 22, 1, 20, 1, 20, 1, 17, 1, 13, 1, 17, 1, 20, 1, 22, 1, 20, 1, 18, 1, 18, 1, 15, 1, 11, 1, 15, 1, 18, 1, 22, 1, 18, 1, 15, 1},
            // 10: Menacing pose (shop)
            {8, 2, -1, 1, 8, 1, 11, 2, -1, 1, 13, 1, 14, 2, 13, 2, 11, 2, 8, 4, -1, 2, 8, 2, -1, 1, 8, 1, 11, 2, -1, 1, 13, 1, 16, 2, 15, 2, 13, 2, 11, 4, -1, 2, 20, 1, -1, 1, 20, 1, -1, 1, 20, 2, 19, 2, 16, 2, 15, 2, 13, 4, -1, 4},
            // 11: Midnight hunter (shop)
            {8, 4, 11, 2, 13, 2, 15, 6, 16, 2, 15, 4, 13, 4, 11, 2, 10, 2, 8, 8, 15, 4, 16, 2, 19, 2, 20, 6, 19, 2, 16, 4, 15, 4, 13, 2, 11, 2, 10, 4, 8, 4},
            // 12: Stomp stomp clap (shop)
            {15, 2, 15, 2, -1, 2, 18, 2, 17, 2, 15, 2, 13, 4, 13, 2, 13, 2, -1, 2, 17, 2, 15, 2, 13, 2, 10, 4, 15, 2, 15, 2, -1, 2, 18, 2, 17, 2, 15, 2, 13, 4, 18, 2, 17, 2, 15, 2, 13, 2, 15, 8},
            // 13: Stairs to cloud nine (shop)
            {10, 1, 15, 1, 18, 1, 22, 1, 18, 1, 15, 1, 18, 1, 15, 1, 13, 1, 17, 1, 20, 1, 24, 1, 20, 1, 17, 1, 20, 1, 17, 1, 11, 1, 15, 1, 18, 1, 22, 1, 18, 1, 15, 1, 18, 1, 15, 1, 10, 1, 14, 1, 17, 1, 22, 1, 17, 1, 14, 1, 17, 1, 14, 1, 10, 1, 15, 1, 18, 1, 22, 1, 18, 1, 15, 1, 18, 1, 15, 1, 13, 1, 17, 1, 20, 1, 24, 1, 20, 1, 17, 1, 20, 1, 17, 1, 11, 1, 15, 1, 18, 1, 22, 1, 18, 1, 15, 1, 18, 1, 15, 1, 10, 1, 14, 1, 17, 1, 22, 1, 17, 1, 14, 1, 17, 1, 14, 1}
    };
    private static final int[][] BASS = {
            {6, 8, 13, 8, 6, 8, 13, 8, 6, 8, 13, 8, 13, 8, 6, 8},
            {6, 12, 15, 12, 11, 12, 13, 12},
            {6, 4, 13, 4, 6, 4, 13, 4, 11, 4, 6, 4, 13, 4, 6, 4},
            {3, 20, 2, 20},
            {6, 16, 11, 16, 6, 16},
            {6, 4, 6, 4, 11, 4, 11, 4, 6, 4, 6, 4, 13, 4, 13, 4},
            {6, 8, 13, 8, 11, 8, 6, 4},
            {6, 16, 11, 12, 13, 12},
            {3, 16, 0, 16, 6, 16, 1, 16},
            {3, 8, 6, 8, 1, 8, 8, 8, 3, 4, 3, 4, 6, 4, 6, 4, 1, 4, 1, 4, 8, 4, 8, 4},
            {1, 2, -1, 2, 1, 2, -1, 2, 3, 2, -1, 2, 3, 2, -1, 2, 1, 2, -1, 2, 1, 2, -1, 2, 3, 2, -1, 2, 3, 2, -1, 2, 1, 2, -1, 2, 1, 2, -1, 2, 3, 2, -1, 2, 3, 2, -1, 2, 1, 2, -1, 2, 1, 2, -1, 2, 3, 2, -1, 2, 3, 2, -1, 2},
            {8, 16, 8, 16, 3, 16, 8, 16},
            {6, 2, 6, 2, -1, 4, 6, 2, 6, 2, -1, 4, 6, 2, 6, 2, -1, 4, 6, 2, 6, 2, -1, 4, 6, 2, 6, 2, -1, 4, 6, 2, 6, 2, -1, 4, 6, 2, 6, 2, -1, 4, 6, 2, 6, 2, -1, 4, 6, 2, 6, 2, -1, 4, 6, 2, 6, 2, -1, 4},
            {3, 8, 1, 8, 0, 8, 2, 8, 3, 8, 1, 8, 0, 8, 2, 8}
    };
    private static final int[] UNIT = {8, 10, 5, 9, 9, 6, 6, 10, 11, 7, 6, 10, 6, 8};           // ticks per unit
    private static final int[] LEAD = {0, 1, 0, 3, 1, 0, 0, 3, 1, 0, 0, 3, 0, 0};             // 0 harp, 1 bell, 3 chime
    private static final int COUNT = MELODY.length;
    private static final int[] TOTAL = new int[COUNT];

    static {
        for (int i = 0; i < COUNT; i++) {
            int sum = 0;
            for (int k = 1; k < MELODY[i].length; k += 2) sum += MELODY[i][k];
            TOTAL[i] = sum * UNIT[i];
        }
    }

    private int track = 0, t = 0, ticks = 0, listTop = 0;
    private static final int VIS = 10;
    private boolean playing;

    @Override
    public boolean busy() { return playing; }
    private final int[] cur = new int[2], next = new int[2];
    private float vol = 0.6F;
    private final float[] bars = new float[12];

    @Override
    public Component title() { return Component.translatable("cutemod.os.music"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.music"); }

    @Override
    public Component status() {
        return playing ? Component.translatable("cutemod.music.now", t("cutemod.music." + track))
                : Component.translatable("cutemod.music.paused");
    }

    @Override
    public void close() { playing = false; }

    @Override
    public boolean background() { return playing; }

    // ---------- for the desktop player widget ----------
    boolean active() { return playing || t > 0; }

    boolean isPlaying() { return playing; }

    String trackName() { return t("cutemod.music." + track); }

    float progress() { return Math.min(1f, t / (float) Math.max(1, TOTAL[track])); }

    void toggle() { if (playing) playing = false; else if (t == 0) startTrack(track); else playing = true; }

    void nextTrack() { startTrack(track + 1); }

    void prevTrack() { startTrack(track - 1); }

    private static boolean unlocked(int i) { return i < 4 || Progress.owned("track" + i); }

    private void startTrack(int i) {
        track = Math.floorMod(i, COUNT);
        while (!unlocked(track)) track = (track + 1) % COUNT; // shop tracks you do not own are skipped
        t = 0;
        cur[0] = cur[1] = 0;
        next[0] = next[1] = 0;
        playing = true;
    }

    static void note(int instrument, int n, float volume) {
        SoundEvent ev = switch (instrument) {
            case 0 -> SoundEvents.NOTE_BLOCK_HARP.value();
            case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
            case 2 -> SoundEvents.NOTE_BLOCK_BASS.value();
            default -> SoundEvents.NOTE_BLOCK_CHIME.value();
        };
        float pitch = (float) Math.max(0.5, Math.min(2.0, Math.pow(2.0, (n - 12) / 12.0)));
        Sfx.musicNote(ev, pitch, volume);
    }

    @Override
    public void tick() {
        ticks++;
        for (int i = 0; i < bars.length; i++) bars[i] *= 0.92F;
        if (!playing) return;
        int unit = UNIT[track];
        for (int v = 0; v < 2; v++) {
            int[] arr = v == 0 ? MELODY[track] : BASS[track];
            while (cur[v] < arr.length && t >= next[v]) {
                int n = arr[cur[v]], len = arr[cur[v] + 1];
                if (n >= 0) {
                    note(v == 0 ? LEAD[track] : 2, n, v == 0 ? vol * 0.8F : vol);
                    bars[(n + v * 5) % 12] = 1F;
                }
                next[v] += len * unit;
                cur[v] += 2;
            }
        }
        t++;
        if (t >= TOTAL[track] + 8) startTrack(track + 1); // next track
    }

    // ---------- layout ----------
    private static final int LIST_X = 8, LIST_Y = 10, ROW_H = 11, LIST_W = 132;
    private static final int BAR_X = 8, BAR_Y = 112, BAR_W = 284;
    private static final int VOL_X = 190, VOL_Y = 133, VOL_W = 90;

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Skin.grad(g, 0, 0, W, H, 0xFF1B1430, 0xFF3A2A5A);

        // track list
        if (track < listTop) listTop = track;
        if (track >= listTop + VIS) listTop = track - VIS + 1;
        listTop = Math.max(0, Math.min(Math.max(0, COUNT - VIS), listTop));
        for (int i = listTop; i < Math.min(COUNT, listTop + VIS); i++) {
            int y = LIST_Y + (i - listTop) * ROW_H;
            boolean sel = i == track, hover = in(mx, my, LIST_X, y, LIST_W, ROW_H - 2);
            Skin.rect(g, LIST_X, y, LIST_W, ROW_H - 2, sel ? 0xFFB57BD6 : (hover ? 0xFF5A4A86 : 0xFF3A2A66));
            boolean open = unlocked(i);
            Skin.str(g, font(), t("cutemod.music." + i), LIST_X + 6, y + 1, open ? (sel ? 0xFFFFFFFF : 0xFFD8CCE8) : 0xFF7A6A9A, false);
            if (!open) Skin.str(g, font(), t("cutemod.music.locked"), LIST_X + LIST_W - 6 - font().width(t("cutemod.music.locked")), y + 1, 0xFFB98A10, false);
            if (sel && playing) Skin.str(g, font(), (ticks / 15) % 2 == 0 ? ">" : ">>", LIST_X + LIST_W - 12, y + 1, 0xFFFFFFFF, false);
        }

        // equalizer
        Skin.rect(g, 150, 10, 142, 86, 0xFF14102A);
        for (int i = 0; i < bars.length; i++) {
            int h = 3 + (int) (bars[i] * 74);
            int col = 0xFF000000 | java.awt.Color.HSBtoRGB(i / 12f, 0.55f, 0.95f);
            Skin.rect(g, 154 + i * 11, 92 - h, 9, h, col);
            Skin.rect(g, 154 + i * 11, 92 - h, 9, 1, 0x88FFFFFF);
        }

        // now playing + progress
        Skin.str(g, font(), t("cutemod.music." + track), BAR_X, 100, 0xFFFFFFFF, false);
        Skin.rect(g, BAR_X, BAR_Y, BAR_W, 6, 0xFF14102A);
        int done = playing || t > 0 ? Math.min(BAR_W, BAR_W * t / Math.max(1, TOTAL[track])) : 0;
        Skin.rect(g, BAR_X, BAR_Y, done, 6, 0xFFF58FB8);

        // buttons
        button(g, mx, my, 8, 128, 28, "|<");
        button(g, mx, my, 40, 128, 40, playing ? "||" : ">");
        button(g, mx, my, 84, 128, 28, ">|");

        // volume
        Skin.str(g, font(), t("cutemod.music.volume"), 120, 132, 0xFFD8CCE8, false);
        Skin.rect(g, VOL_X, VOL_Y, VOL_W, 8, 0xFF14102A);
        Skin.rect(g, VOL_X, VOL_Y, (int) (VOL_W * vol), 8, 0xFFB57BD6);
    }

    private void button(GuiGraphics g, int mx, int my, int x, int y, int w, String s) {
        boolean hover = in(mx, my, x, y, w, 16);
        Skin.rect(g, x, y, w, 16, hover ? 0xFF8A6AC6 : 0xFF5A4A86);
        Skin.str(g, font(), s, x + (w - font().width(s)) / 2, y + 4, 0xFFFFFFFF, false);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        for (int i = listTop; i < Math.min(COUNT, listTop + VIS); i++) {
            if (in(x, y, LIST_X, LIST_Y + (i - listTop) * ROW_H, LIST_W, ROW_H - 2)) { if (unlocked(i)) startTrack(i); return true; }
        }
        if (in(x, y, 8, 128, 28, 16)) { startTrack(track - 1); return true; }
        if (in(x, y, 40, 128, 40, 16)) {
            if (playing) playing = false; else if (t == 0) startTrack(track); else playing = true;
            return true;
        }
        if (in(x, y, 84, 128, 28, 16)) { startTrack(track + 1); return true; }
        if (in(x, y, VOL_X - 2, VOL_Y - 3, VOL_W + 4, 14)) { setVol(x); return true; }
        return false;
    }

    @Override
    public boolean scroll(double amount) {
        listTop = Math.max(0, Math.min(Math.max(0, COUNT - VIS), listTop - (int) Math.signum(amount)));
        return true;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        if (in(x, y, VOL_X - 6, VOL_Y - 8, VOL_W + 12, 24)) { setVol(x); return true; }
        return false;
    }

    private void setVol(int x) { vol = Math.max(0.05F, Math.min(1F, (x - VOL_X) / (float) VOL_W)); }

    @Override
    public boolean key(int keyCode, int modifiers) {
        switch (keyCode) {
            case 32 -> { if (playing) playing = false; else if (t == 0) startTrack(track); else playing = true; } // space
            case 262 -> startTrack(track + 1);
            case 263 -> startTrack(track - 1);
            default -> { return false; }
        }
        return true;
    }
}
