package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Text that never leaves the screen: when a line would run past the right (or left) edge it is drawn smaller
 * (down to 60 %), the way a long Russian translation still fits where the English one did. Used by the apps
 * (through {@link Skin}), the mini games and the toasts. A line that fits is drawn exactly as before.
 * Only for the normal 1:1 scale: inside a scaled pose the line is drawn as is.
 */
public final class Fit {
    public static final int APP_RIGHT = App.W - 2;
    private static final float MIN = 0.6F;

    private Fit() {}

    private static boolean plain(GuiGraphics g) {
        float s = g.pose().last().pose().m00();
        return s > 0.99F && s < 1.01F;
    }

    /** The scale a line of width w drawn at x needs to stay between 2 and right (1 = fits). */
    private static float scale(int x, int w, int right) {
        if (w <= 0 || (x >= 0 && x + w <= right)) return 1F;
        float left = x, avail;
        if (x < 0) {                                         // a centred line that is too wide: keep it centred
            float c = x + w / 2F;
            avail = 2F * Math.min(c - 2F, right - c);
            return Math.max(MIN, Math.min(1F, avail / w));
        }
        avail = right - left;
        return Math.max(MIN, Math.min(1F, avail / w));
    }

    public static int str(GuiGraphics g, Font f, String s, int x, int y, int argb, boolean shadow, int right) {
        int w = f.width(s);
        float k = plain(g) ? scale(x, w, right) : 1F;
        if (k >= 0.999F) return g.drawString(f, s, x, y, argb, shadow);
        float nx = x < 0 ? x + w / 2F - w * k / 2F : x;
        g.pose().pushPose();
        g.pose().translate(nx, y + (1F - k) * 4F, 0);       // keep the line on the same middle height
        g.pose().scale(k, k, 1F);
        int r = g.drawString(f, s, 0, 0, argb, shadow);
        g.pose().popPose();
        return r;
    }

    public static int str(GuiGraphics g, Font f, Component s, int x, int y, int argb, boolean shadow, int right) {
        int w = f.width(s);
        float k = plain(g) ? scale(x, w, right) : 1F;
        if (k >= 0.999F) return g.drawString(f, s, x, y, argb, shadow);
        float nx = x < 0 ? x + w / 2F - w * k / 2F : x;
        g.pose().pushPose();
        g.pose().translate(nx, y + (1F - k) * 4F, 0);
        g.pose().scale(k, k, 1F);
        int r = g.drawString(f, s, 0, 0, argb, shadow);
        g.pose().popPose();
        return r;
    }

    public static int str(GuiGraphics g, Font f, Component s, int x, int y, int argb) { return str(g, f, s, x, y, argb, true, APP_RIGHT); }

    public static int str(GuiGraphics g, Font f, net.minecraft.util.FormattedCharSequence s, int x, int y, int argb, boolean shadow) {
        int w = f.width(s);
        float k = plain(g) ? scale(x, w, APP_RIGHT) : 1F;
        if (k >= 0.999F) return g.drawString(f, s, x, y, argb, shadow);
        float nx = x < 0 ? x + w / 2F - w * k / 2F : x;
        g.pose().pushPose();
        g.pose().translate(nx, y + (1F - k) * 4F, 0);
        g.pose().scale(k, k, 1F);
        int r = g.drawString(f, s, 0, 0, argb, shadow);
        g.pose().popPose();
        return r;
    }

    public static int str(GuiGraphics g, Font f, String s, int x, int y, int argb, boolean shadow) { return str(g, f, s, x, y, argb, shadow, APP_RIGHT); }

    public static int str(GuiGraphics g, Font f, String s, int x, int y, int argb) { return str(g, f, s, x, y, argb, true, APP_RIGHT); }

    public static int str(GuiGraphics g, Font f, Component s, int x, int y, int argb, boolean shadow) { return str(g, f, s, x, y, argb, shadow, APP_RIGHT); }
}
