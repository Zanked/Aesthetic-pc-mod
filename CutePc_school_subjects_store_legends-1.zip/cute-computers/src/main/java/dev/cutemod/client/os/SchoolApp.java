package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.CuteMod;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Pet School: a classroom with Teacher Owl at the blackboard and five pet pupils at their desks (yours sits in the
 * middle). Pick a class (easy, medium or hard); a lesson is five questions. The teacher "says" each question on the
 * blackboard, you pick the answer, the pupils cheer or sigh. Right answers pay coins (more in the harder classes,
 * a bonus for five out of five), with a daily cap. Questions are in the language files:
 * cutemod.school.q.LEVEL.N and cutemod.school.a.LEVEL.N.K (answer K = 0 is the right one; the order is shuffled
 * on the screen). Saved as "school_best" (best result per class) and "school_seen" (questions already asked).
 *
 * Subjects: the first screen is a choice of a subject (the old mixed questions, English, biology, chemistry, physics, world history,
 * philosophy, literature), then the class (easy, medium, hard). The mixed subject keeps its old keys; every other subject has
 * cutemod.school.q.SUBJECT.LEVEL.N and cutemod.school.a.SUBJECT.LEVEL.N.K (25 questions per class, written by tools/make_school_subjects.py
 * from tools/school_q/SUBJECT.txt). "school_best" and "school_seen" now hold 8 subjects x 3 classes (the first three numbers are the old mixed ones).
 *
 * Sound: the owl really talks (every third letter she writes on the board is a soft "hoo", made by tools/make_voices.py as
 * "voice.owl"), the classroom has its own tune (music.school in the menu and on the result, music.school_quiz while a question
 * is on the board, see GameMusic) and its own little sounds (school.bell / ding / boop / chalk / fanfare / aww, made by
 * tools/make_school_audio.py). The pupils cheer with the voices of their pets. The owl's words come in several variants
 * (the .1, .2... keys), she calls a pet by its name, and praises a streak of right answers.
 * A class has up to 64 questions (the "seen" mask is a long); the mixed classes have 60, the subjects 25 in each.
 */
public class SchoolApp extends KitApp {
    private static final String[] LEVEL = {"easy", "medium", "hard"};
    private static final String[] SUBJECT = {"general", "english", "biology", "chemistry", "physics", "history", "philosophy", "literature"};
    private static final int SUBJECTS = SUBJECT.length;
    private static final int SUBJ_POOL = 25;                     // questions per class in every subject except "general"
    private static final int[] POOL = {60, 60, 60};          // how many questions every class of the mixed subject has in the language files (at most 64)
    private static final int[] OPTIONS = {3, 3, 4};          // answers per question
    private static final int[] PER_RIGHT = {1, 2, 3};        // coins per right answer
    private static final int[] BONUS = {2, 4, 6};            // extra coins for five out of five
    private static final int[] XP = {4, 7, 10};              // season pass xp for a lesson with five right
    private static final int[] CARD = {0xFFBFEFC4, 0xFFFFE9A8, 0xFFFFC6C6};
    private static final int[] CARD_EDGE = {0xFF6FBF7A, 0xFFE0B84A, 0xFFE08585};
    private static final int LESSON = 5, DAILY_CAP = 60;
    private static final String PAID = "school_paid";

    private static final int MENU = 0, ASK = 1, RESULT = 2, PICK = 3;      // MENU = the classes of one subject, PICK = the subjects

    // the room
    private static final int BX = 74, BY = 17, BW = 218, BH = 40;   // the blackboard
    private static final int AX = 74, AW = 218;                      // the answer buttons
    private static final int FLOOR_Y = 150;                          // where the pupils stand (behind their desks)
    private static final int[] PUPIL_X = {32, 91, 150, 209, 268};
    private static final int BACK_X = 112, BACK_W = 44;             // the "back to the classes" button in the title bar
    private static final int OWN = 2;                                // the middle desk is yours

    private int mode = PICK;
    private int level;
    private int subject;                                             // index in SUBJECT
    private int[] qs = new int[LESSON];
    private int qi, right;
    private int[] order = new int[4];                                // order[slot] = the original answer index shown there (0 = right)
    private int picked = -1, reveal, react, resultT;
    private boolean lastOk;
    private final int[] best = new int[SUBJECTS * 3];                // best result per subject and class: subject * 3 + level
    private final long[] seen = new long[SUBJECTS * 3];
    private int paid;                                                // coins of the lesson just finished
    private boolean capped;
    private String teach = "";                                       // what the owl says on the board in the menu / result
    private int teachT;
    private String boardLine = "";                                      // the text on the board while a question is asked (a lead-in and the question)
    private int streak, idleN;                                       // right answers in a row; which "I am waiting" line comes next
    private String vText = "";                                       // what the owl is saying out loud right now (empty = she is quiet)
    private int vAge;
    private float vPitch = 1F;
    private static final int[] CHEER_ORDER = {2, 1, 3, 0, 4};        // the pupils cheer one after another, yours first
    private static final Map<String, String> PUPIL_VOICE = Map.of("pink", "kit", "green", "boom", "white", "mei", "blue", "pip",
            "orange", "fox", "purple", "void", "yellow", "honey", "red", "lady");
    private final Random rnd = new Random();
    private boolean loaded;

    @Override protected int accent() { return 0xFF5B8DEF; }

    @Override protected String id() { return "school"; }

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        load();
        if (mode == MENU || mode == PICK) { mode = PICK; greetPick(); } else greet();
    }

    // ---------- saving ----------
    private void load() {
        loaded = true;
        try {
            String s = Store.read("school_best");
            if (s != null) {
                String[] p = s.split(",");
                for (int i = 0; i < best.length && i < p.length; i++) best[i] = Math.max(0, Math.min(LESSON, Integer.parseInt(p[i])));
            }
            s = Store.read("school_seen");
            if (s != null) {
                String[] p = s.split(",");
                for (int i = 0; i < seen.length && i < p.length; i++) seen[i] = Long.parseLong(p[i]);
            }
        } catch (NumberFormatException ignored) { }
    }

    private void save() {
        StringBuilder b = new StringBuilder(), n = new StringBuilder();
        for (int i = 0; i < best.length; i++) { if (i > 0) { b.append(','); n.append(','); } b.append(best[i]); n.append(seen[i]); }
        Store.write("school_best", b.toString());
        Store.write("school_seen", n.toString());
    }

    /** Index of a class of the chosen subject in best[] and seen[]. */
    private int idx(int lv) { return subject * 3 + lv; }

    /** How many questions the class has in the language files. */
    private int pool(int lv) { return subject == 0 ? POOL[lv] : SUBJ_POOL; }

    /** The language key of a question ("q") or of its answers ("a"): the mixed subject keeps the old keys without a subject. */
    private String key(String kind) { return "cutemod.school." + kind + "." + (subject == 0 ? "" : SUBJECT[subject] + ".") + LEVEL[level] + "."; }

    private void greet() {
        String nm = petName();
        int v = rnd.nextInt(nm.isEmpty() ? 4 : 5);
        teach = v == 4 ? t("cutemod.school.hello.nm", nm) : t(v == 0 ? "cutemod.school.hello" : "cutemod.school.hello." + v);
        teachT = 0;
        speak(teach, 1F);
    }

    /** The owl greets on the screen with the subjects. */
    private void greetPick() {
        String nm = petName();
        int v = rnd.nextInt(nm.isEmpty() ? 3 : 4);
        teach = v == 3 ? t("cutemod.school.subj.hello.nm", nm) : t(v == 0 ? "cutemod.school.subj.hello" : "cutemod.school.subj.hello." + v);
        teachT = 0;
        speak(teach, 1F);
    }

    /** A subject is chosen: the owl says what it is about and the classes of this subject open. */
    private void pickSubject(int s) {
        subject = s;
        mode = MENU;
        Sfx.ui(snd("school.chalk"), 1.05F, 0.5F);
        teach = t("cutemod.school.subj.say." + SUBJECT[s]);
        teachT = 0;
        speak(teach, 1F);
    }

    // ---------- sounds: a school event, the owl's voice, the pupils' voices ----------
    private static final Map<String, SoundEvent> SND = new HashMap<>();

    /** Our own sound event (sounds.json): "school.ding", "voice.owl", "tales.page"... */
    private static SoundEvent snd(String name) {
        return SND.computeIfAbsent(name, n -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, n)));
    }

    /** The name the player gave the pet, or "" (then the owl does not use a name). */
    private String petName() {
        ComputerColor sp = PetApp.speciesOf(shell.color());
        return PetName.custom((sp == null ? shell.color() : sp).id);
    }

    /** The owl starts to say a text (it is the same text that is written on the board or shown as her answer). */
    private void speak(String text, float pitch) { vText = text; vAge = 0; vPitch = pitch; }

    /** Every tick: one soft "hoo" for every third letter, at the speed the letters appear on the board (a letter every 2 ticks). */
    private void voiceTick() {
        if (vText.isEmpty()) return;
        vAge++;
        if (vAge % 2 != 0) return;
        int shown = vAge / 2;
        if (shown > vText.length()) { vText = ""; return; }
        if (shown % 3 != 0) return;
        char c = vText.charAt(shown - 1);
        if (!Character.isLetterOrDigit(c)) return;
        Sfx.ui(snd("voice.owl"), vPitch * (0.9F + (c % 7) * 0.04F), 0.55F);
    }

    private ComputerColor[] crowd() {
        ComputerColor own = PetApp.speciesOf(shell.color());
        if (own == null) own = shell.color();
        ComputerColor[] all = ComputerColor.values();
        ComputerColor[] out = new ComputerColor[PUPIL_X.length];
        int k = 1;
        for (int i = 0; i < out.length; i++) out[i] = i == OWN ? own : all[(own.ordinal() + k++) % all.length];
        return out;
    }

    /** A pupil answers with the voice of its pet (the same voices as in the Tamagotchi app). */
    private void pupilVoice(int i, float pitch) {
        ComputerColor c = crowd()[i];
        Sfx.ui(snd("voice." + PUPIL_VOICE.getOrDefault(c.id, "kit")), pitch, c == ComputerColor.PURPLE ? 0.6F : 0.42F);
    }

    // ---------- the lesson ----------
    private void start(int lv) {
        level = lv;
        streak = 0;
        Sfx.ui(snd("school.bell"), 1F, 0.6F);
        // unasked questions first; when fewer than five are left the round starts again
        List<Integer> fresh = new ArrayList<>(), old = new ArrayList<>();
        int k = idx(lv);
        for (int i = 0; i < pool(lv); i++) (((seen[k] >> i) & 1L) == 0 ? fresh : old).add(i);
        Collections.shuffle(fresh, rnd);
        Collections.shuffle(old, rnd);
        boolean again = fresh.size() < LESSON;
        List<Integer> pick = new ArrayList<>(fresh);
        pick.addAll(old);
        long mask = again ? 0L : seen[k];
        for (int i = 0; i < LESSON; i++) { qs[i] = pick.get(i); mask |= 1L << qs[i]; }
        seen[k] = mask;
        qi = 0;
        right = 0;
        mode = ASK;
        nextQuestion();
    }

    private void nextQuestion() {
        int n = OPTIONS[level];
        List<Integer> o = new ArrayList<>();
        for (int i = 0; i < n; i++) o.add(i);
        Collections.shuffle(o, rnd);
        for (int i = 0; i < n; i++) order[i] = o.get(i);
        picked = -1;
        reveal = 0;
        react = 0;
        boardLine = lead() + question();
        speak(boardLine, 1F);
        Sfx.ui(snd("school.chalk"), 0.95F + rnd.nextFloat() * 0.1F, 0.5F);
    }

    /** A little something the owl says before the question: at the start, before the last one, and now and then in between. */
    private String lead() {
        String k;
        if (qi == 0) k = "cutemod.school.lead.first." + rnd.nextInt(3);
        else if (qi == LESSON - 1) k = "cutemod.school.lead.last";
        else if ((qs[qi] + qi) % 3 == 0) k = "cutemod.school.lead.mid." + rnd.nextInt(6);
        else return "";
        return t(k) + " ";
    }

    private String question() { return t(key("q") + qs[qi]); }

    private String answer(int slot) { return t(key("a") + qs[qi] + "." + order[slot]); }

    private int rightSlot() {
        for (int s = 0; s < OPTIONS[level]; s++) if (order[s] == 0) return s;
        return 0;
    }

    private int revealLen() { return boardLine.length(); }

    private boolean revealed() { return reveal >= revealLen() * 2; }

    private void choose(int slot) {
        picked = slot;
        lastOk = slot == rightSlot();
        react = 0;
        if (lastOk) { right++; streak++; } else streak = 0;
        if (lastOk) {
            Sfx.ui(snd("school.ding"), 1F, 0.7F);
            String nm = petName();
            if (streak >= 3) say("cutemod.school.streak." + Math.min(streak, 5));
            else if (!nm.isEmpty() && rnd.nextInt(4) == 0) say("cutemod.school.right.nm." + rnd.nextInt(3), nm);
            else say("cutemod.school.right." + rnd.nextInt(8));
        } else {
            Sfx.ui(snd("school.boop"), 1F, 0.6F);
            int w = rnd.nextInt(6);
            say(w == 0 ? "cutemod.school.wrong" : "cutemod.school.wrong." + w);
        }
        speak(msg, lastOk ? 1.12F : 0.9F);
    }

    private void advance() {
        if (picked < 0) return;
        Sfx.ui(snd("tales.page"), 1.3F, 0.35F);
        if (qi + 1 < LESSON) { qi++; nextQuestion(); return; }
        finish();
    }

    private void finish() {
        mode = RESULT;
        resultT = 0;
        int pay = right * PER_RIGHT[level] + (right == LESSON ? BONUS[level] : 0);
        int room = Math.max(0, DAILY_CAP - paidToday(PAID));
        capped = pay > room;
        pay = Math.min(pay, room);
        paid = pay;
        if (pay > 0) { addPaid(PAID, pay); Progress.earn(pay); }
        Season.add(XP[level] * right / LESSON);
        if (right > best[idx(level)]) best[idx(level)] = right;
        Progress.setCount("school_lessons", Progress.count("school_lessons") + 1);
        Progress.setCount("school_right", Progress.count("school_right") + right);
        save();
        Sfx.ui(snd(right >= 4 ? "school.fanfare" : right <= 1 ? "school.aww" : "school.ding"), 1F, 0.7F);
        teach = resultLine();
        teachT = 0;
        speak(teach, right >= 3 ? 1.1F : 0.92F);
    }

    private String resultLine() {
        String nm = petName();
        if (right == LESSON && !nm.isEmpty() && rnd.nextBoolean()) return t("cutemod.school.result.5.nm", nm);
        int v = rnd.nextInt(3);
        return t(v == 0 ? "cutemod.school.result." + right : "cutemod.school.result." + right + "." + v);
    }

    private void toMenu() { mode = MENU; greet(); }

    @Override
    public void tick() {
        super.tick();
        GameMusic.keep(mode == ASK ? "school_quiz" : "school", false);      // the classroom tune; it fades out by itself when the app is not on screen
        voiceTick();
        if (mode == ASK) {
            if (reveal < revealLen() * 2) reveal++;
            if (picked >= 0) { react++; cheerTick(); }
        } else {
            teachT++;
            if (mode == RESULT) { resultT++; resultCheer(); }
            else if (teachT >= 1200 && vText.isEmpty()) {              // nobody has chosen a class for 20 seconds: the owl asks kindly
                teach = t((mode == PICK ? "cutemod.school.subj.idle." : "cutemod.school.idle.") + idleN++ % 4);
                teachT = 0;
                speak(teach, 1F);
            }
        }
    }

    @Override
    public void close() { GameMusic.stop(); }

    /** After a right answer the pupils cheer one by one (yours first); after a wrong one yours says a small "oh". */
    private void cheerTick() {
        if (lastOk) {
            int k = react - 6;
            if (k >= 0 && k % 3 == 0 && k / 3 < 5) pupilVoice(CHEER_ORDER[k / 3], 1.12F + 0.05F * (k / 3));
        } else if (react == 10) {
            pupilVoice(OWN, 0.8F);
        }
    }

    /** On the result of 4 or 5 right the whole class cheers (twice for five). */
    private void resultCheer() {
        if (right < 4) return;
        int k = resultT - 10, n = right == LESSON ? 10 : 5;
        if (k >= 0 && k % 5 == 0 && k / 5 < n) pupilVoice(CHEER_ORDER[(k / 5) % 5], 1.1F + 0.04F * ((k / 5) % 5));
    }

    // ---------- drawing ----------
    private static final int CARD_Y = 63, CARD_H = 62, CARD_W = 70, CARD_STEP = 74;
    private static final int NEXT_W = 66, NEXT_Y = 128, RES_Y = 104, ANS_Y = 63;
    private static final int[] BADGE = {0xFFF58FB8, 0xFF6FB0FF, 0xFF7ACB8A, 0xFFF5B84A};
    private static final int WOOD = 0xFF9A6A3C, WOOD_LIGHT = 0xFFC8955C, WOOD_DARK = 0xFF6E4726;

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        rect(g, 0, 0, W, H, 0xFFFDF0F7);
        rect(g, 0, 0, W, 14, accent());
        rect(g, 0, 14, W, 1, 0x55FFFFFF);
        int hy = CuteFont.size() == 2 ? 2 : 3;
        fit(g, f, mode == PICK || subject == 0 ? t("cutemod.os.school") : t("cutemod.school.subj.full." + SUBJECT[subject]), 5, hy, BACK_X - 10, 0xFFFFFFFF, false);
        String top = mode == ASK ? t("cutemod.school.question", qi + 1, LESSON) : t("cutemod.school.total", Progress.count("school_right"));
        int tw = Math.min(f.width(top), 120);
        fit(g, f, top, W - 6 - tw, hy, 120, 0xFFFFFFFF, false);
        room(g);
        board(g, f);
        teacher(g, f);
        pupils(g);
        switch (mode) {
            case PICK -> pick(g, f, mx, my);
            case MENU -> menu(g, f, mx, my);
            case ASK -> ask(g, f, mx, my);
            default -> result(g, f, mx, my);
        }
        if (mode == ASK || mode == MENU) {
            boolean hb = in(mx, my, BACK_X, 1, BACK_W, 12);
            roundRect(g, BACK_X, 1, BACK_W, 12, 5, hb ? 0x77FFFFFF : 0x33FFFFFF);
            fit(g, f, t(mode == ASK ? "cutemod.school.back" : "cutemod.school.subj.back"), BACK_X + BACK_W / 2, 3, BACK_W - 4, 0xFFFFFFFF, true);
        }
        if (mode == RESULT && right >= 4) confetti(g);
    }

    // ----- small drawing helpers -----
    private static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int color) {
        int n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= n; i++) rect(g, x0 + (x1 - x0) * i / Math.max(1, n), y0 + (y1 - y0) * i / Math.max(1, n), 1, 1, color);
    }

    private static void heart(GuiGraphics g, int cx, int cy, int c) {
        rect(g, cx - 3, cy - 2, 2, 2, c); rect(g, cx + 1, cy - 2, 2, 2, c);
        rect(g, cx - 3, cy - 1, 6, 2, c); rect(g, cx - 2, cy + 1, 4, 1, c); rect(g, cx - 1, cy + 2, 2, 1, c);
    }

    private static void coin(GuiGraphics g, int cx, int cy) {
        disc(g, cx, cy, 4, 0xFFC98A10); disc(g, cx, cy, 3, 0xFFFFD34E); rect(g, cx - 1, cy - 2, 1, 4, 0xFFFFF0A0);
    }

    private static void sparkle(GuiGraphics g, int cx, int cy, int r, int c) {
        rect(g, cx, cy - r, 1, r * 2 + 1, c); rect(g, cx - r, cy, r * 2 + 1, 1, c);
    }

    /** A rounded button with a soft shadow; style 1 = main (accent), 0 = light. */
    private void pill(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, int h, String label, int style) {
        boolean hov = in(mx, my, x, y, w, h);
        int bg = style == 1 ? (hov ? mix(accent(), 0x000000, 0.12F) : accent()) : hov ? 0xFFFFF3B0 : 0xFFFFFFFF;
        roundRect(g, x, y + 2, w, h, 5, 0x44000000);
        roundRect(g, x, y, w, h, 5, bg);
        rect(g, x + 4, y + 1, w - 8, 1, 0x55FFFFFF);
        fit(g, f, label, x + w / 2, y + (h - 8) / 2 - (CuteFont.size() == 2 ? 1 : 0), w - 8, style == 1 ? 0xFFFFFFFF : TEXT, true);
    }

    /** The wall with soft stripes, a wooden rail, the floor and everything that hangs on the left wall. */
    private void room(GuiGraphics g) {
        rect(g, 0, 15, W, 107, 0xFFFFF3E0);
        for (int x = 0; x < W; x += 14) rect(g, x, 15, 7, 107, 0xFFFFECD2);
        rect(g, 0, 98, W, 20, 0xFFF3C9A0);                         // the wall panel
        rect(g, 0, 98, W, 2, 0xFFE6B07C);
        for (int x = 0; x < W; x += 20) rect(g, x, 100, 1, 18, 0x22A06A3A);
        rect(g, 0, 118, W, 4, WOOD_LIGHT);                         // the skirting
        rect(g, 0, 118, W, 1, 0x55FFFFFF);
        rect(g, 0, 122, W, H - 122, 0xFFE0B27A);                   // the floor
        for (int x = -20; x < W; x += 34) { line(g, x + 10, 122, x, H, 0x22804A1A); }
        rect(g, 0, 122, W, 1, 0x33000000);
        // a pink rug under the pupils
        roundRect(g, 8, 130, W - 16, H - 130, 6, 0x55F4A7C3);
        roundRect(g, 12, 133, W - 24, H - 133, 5, 0x33FFFFFF);
        // the window: sky, a sun, curtains and a sill
        rect(g, 3, 18, 36, 28, WOOD_LIGHT);
        rect(g, 5, 20, 32, 24, 0xFFBFE6FF);
        rect(g, 5, 33, 32, 11, 0xFFD6F2D0);
        disc(g, 13, 28, 3, 0xFFFFE680);
        rect(g, 19, 20, 2, 24, WOOD_LIGHT); rect(g, 5, 31, 32, 2, WOOD_LIGHT);
        rect(g, 4, 19, 6, 25, 0xFFF4A7C3); rect(g, 32, 19, 6, 25, 0xFFF4A7C3);
        rect(g, 6, 19, 1, 25, 0x55FFFFFF); rect(g, 34, 19, 1, 25, 0x55FFFFFF);
        rect(g, 2, 45, 38, 3, WOOD);
        // a wall clock that shows the real time
        disc(g, 55, 29, 10, WOOD); disc(g, 55, 29, 9, 0xFFFFFFFF);
        for (int k = 0; k < 12; k++) { double a = k * Math.PI / 6; rect(g, 55 + (int) Math.round(Math.sin(a) * 7), 29 - (int) Math.round(Math.cos(a) * 7), 1, 1, 0xFF8A7AA8); }
        java.time.LocalTime now = java.time.LocalTime.now();
        double ma = now.getMinute() / 60.0 * Math.PI * 2, ha = (now.getHour() % 12 + now.getMinute() / 60.0) / 12 * Math.PI * 2;
        line(g, 55, 29, 55 + (int) Math.round(Math.sin(ma) * 6), 29 - (int) Math.round(Math.cos(ma) * 6), 0xFF3A2A3A);
        line(g, 55, 29, 55 + (int) Math.round(Math.sin(ha) * 4), 29 - (int) Math.round(Math.cos(ha) * 4), 0xFFE5486F);
    }

    private void board(GuiGraphics g, Font f) {
        roundRect(g, BX - 4, BY - 4, BW + 8, BH + 8, 4, WOOD_DARK);
        roundRect(g, BX - 3, BY - 3, BW + 6, BH + 6, 4, WOOD_LIGHT);
        rect(g, BX - 1, BY - 1, BW + 2, BH + 2, WOOD_DARK);
        rect(g, BX, BY, BW, BH, 0xFF2E5E4A);
        rect(g, BX, BY, BW, BH / 2, 0xFF336651);
        for (int i = 0; i < 6; i++) rect(g, BX + 12 + i * 37, BY + 8 + (i * 17) % 28, 20, 1, 0x12FFFFFF);    // chalk dust
        // chalk doodles in the corner
        sparkle(g, BX + BW - 10, BY + BH - 9, 3, 0x88FFE680);
        heart(g, BX + BW - 22, BY + BH - 8, 0x88FFB0C8);
        rect(g, BX - 3, BY + BH + 3, BW + 6, 3, WOOD);                // the chalk tray
        rect(g, BX + 8, BY + BH + 1, 7, 3, 0xFFFFFFFF);
        rect(g, BX + 18, BY + BH + 1, 6, 3, 0xFFFFB0C8);
        rect(g, BX + BW - 30, BY + BH, 20, 4, 0xFFF0D8A8); rect(g, BX + BW - 30, BY + BH + 2, 20, 2, 0xFF7A5A8A);   // an eraser
        String s = mode == ASK ? boardLine : teach;
        int shown = mode == ASK ? Math.min(s.length(), reveal / 2) : Math.min(s.length(), teachT / 2);
        boardText(g, f, s, shown, mode == MENU || mode == PICK ? BH - 17 : BH - 9);
        if (mode == MENU || mode == PICK) {
            coin(g, BX + 12, BY + BH - 7);
            fit(g, f, t("cutemod.school.today", paidToday(PAID), DAILY_CAP), BX + 20, BY + BH - 11, BW - 60, 0xFFFFE680, false);
        }
    }

    /** Width a text really takes in fit(). */
    private static int fitW(Font f, String s, int maxW) {
        int w = f.width(s);
        return w <= maxW ? w : Math.min(maxW, (int) (w * Math.max(0.5F, maxW / (float) w)));
    }

    /** Like fitText, but a long text may shrink down to half size (a big font, a long translation) before it is cut. Returns the width drawn. */
    private static int fit(GuiGraphics g, Font f, String s, int x, int y, int maxW, int color, boolean centered) {
        int w = f.width(s);
        if (w <= maxW) {
            CuteFont.draw(g, f, s, centered ? x - w / 2 : x, y, color, false);
            return w;
        }
        float sc = Math.max(0.5F, maxW / (float) w);
        String cut = w * sc > maxW ? f.plainSubstrByWidth(s, (int) (maxW / sc)) : s;
        float tw = f.width(cut) * sc;
        g.pose().pushPose();
        g.pose().translate(centered ? x - tw / 2f : x, y + (1 - sc) * 4f, 0);
        g.pose().scale(sc, sc, 1f);
        CuteFont.draw(g, f, cut, 0, 0, color, false);
        g.pose().popPose();
        return (int) tw;
    }

    private static int lineH() { return CuteFont.size() == 0 ? 9 : CuteFont.size() == 1 ? 10 : 12; }

    private static List<String> wrap(Font f, String text, int w) {
        StringBuilder line = new StringBuilder();
        List<String> lines = new ArrayList<>();
        for (String word : text.split(" ")) {
            if (f.width(line + word) > w && line.length() > 0) { lines.add(line.toString()); line.setLength(0); }
            line.append(word).append(' ');
        }
        lines.add(line.toString());
        return lines;
    }

    /** The text of the blackboard: it is made smaller until all its lines fit the board (a big font or a long text), and it is "written" letter by letter. */
    private void boardText(GuiGraphics g, Font f, String text, int budget, int avail) {
        int w = BW - 16, lh = lineH();
        float sc = 1F;
        List<String> lines = wrap(f, text, w);
        for (float tryScale : new float[]{0.88F, 0.78F, 0.68F, 0.6F}) {
            if (lines.size() * lh * sc <= avail) break;
            sc = tryScale;
            lines = wrap(f, text, (int) (w / sc));
        }
        g.pose().pushPose();
        g.pose().translate(BX + 8, BY + 5, 0);
        g.pose().scale(sc, sc, 1F);
        int left = budget;
        for (int i = 0; i < lines.size() && left > 0; i++) {
            String ln = lines.get(i);
            CuteFont.draw(g, f, ln.length() <= left ? ln : ln.substring(0, left), 0, i * lh, 0xFFF4FFF4, false);
            left -= ln.length();
        }
        g.pose().popPose();
    }

    private boolean talking() { return !vText.isEmpty(); }

    /** Teacher Owl: round, brown, round glasses, a bow tie, a graduation cap and a pointer, behind her desk. */
    private void teacher(GuiGraphics g, Font f) {
        int cx = 36, cy = 80;
        // the desk: a top, a front with a drawer, a books stack, an apple and a little plant
        roundRect(g, 2, 92, 68, 5, 2, WOOD_LIGHT);
        rect(g, 4, 96, 64, 24, WOOD);
        rect(g, 4, 96, 64, 1, 0x33FFFFFF);
        rect(g, 4, 118, 64, 2, WOOD_DARK);
        rect(g, 7, 99, 58, 17, 0xFF8A5A2E);
        rect(g, 7, 99, 58, 1, 0x22000000);
        rect(g, 54, 85, 12, 3, 0xFF5B8DEF); rect(g, 55, 82, 10, 3, 0xFFF4A7C3); rect(g, 54, 88, 12, 4, 0xFF7ACB8A);   // books
        disc(g, 12, 89, 3, 0xFFE5484D); rect(g, 12, 84, 1, 3, 0xFF4A7A3A); rect(g, 13, 84, 3, 2, 0xFF6BC46A);        // an apple
        rect(g, 20, 88, 6, 4, 0xFFE0705A); rect(g, 21, 83, 1, 5, 0xFF4A9A4A); rect(g, 23, 82, 1, 6, 0xFF6BC46A); rect(g, 19, 85, 2, 1, 0xFF6BC46A);   // a plant
        int hop = react > 0 && react < 24 && picked >= 0 && lastOk ? (int) Math.round(Math.abs(Math.sin(react / 3.0)) * 4) : 0;
        int bob = (int) Math.round(Math.sin(ticks / 22.0));
        int y = cy - hop + bob - 6;
        boolean happy = picked >= 0 && lastOk || mode == RESULT && right >= 3;
        boolean sad = picked >= 0 && !lastOk || mode == RESULT && right <= 1;
        oval(g, cx, 92, 16, 2, 0x33000000);
        // wings and body
        int flap = happy ? (int) Math.round(Math.sin(ticks / 3.0) * 3) : 0;
        disc(g, cx - 15, y + 5 - flap, 5, 0xFF7E5230);
        disc(g, cx + 15, y + 5 - flap, 5, 0xFF7E5230);
        disc(g, cx, y, 15, 0xFF9C6B3F);
        disc(g, cx, y - 3, 13, 0xFFA97745);
        disc(g, cx, y + 6, 9, 0xFFF6E3B8);
        for (int r = 0; r < 3; r++) for (int k = -1; k <= 1; k++) rect(g, cx + k * 4 - 1 + (r % 2) * 2, y + 4 + r * 3, 3, 1, 0xFFD2A878);
        rect(g, cx - 13, y - 17, 5, 5, 0xFF7E5230); rect(g, cx + 8, y - 17, 5, 5, 0xFF7E5230);      // ear tufts
        // glasses and eyes
        for (int s = -1; s <= 1; s += 2) {
            int ex = cx + s * 6;
            disc(g, ex, y - 4, 6, 0xFF3A2A3A);
            disc(g, ex, y - 4, 5, 0xFFFFFFFF);
            if (happy) { rect(g, ex - 2, y - 5, 4, 1, 0xFF3A2A3A); rect(g, ex - 3, y - 4, 1, 1, 0xFF3A2A3A); rect(g, ex + 2, y - 4, 1, 1, 0xFF3A2A3A); }
            else { disc(g, ex + (sad ? 0 : (int) Math.round(Math.sin(ticks / 40.0))), y - 3 + (sad ? 1 : 0), 2, 0xFF3A2A3A); rect(g, ex - 1, y - 4, 1, 1, 0xFFFFFFFF); }
            rect(g, ex + s * 5 - 1, y + 1, 3, 2, 0x88FFA8A8);                                           // a rosy cheek
        }
        rect(g, cx - 1, y - 5, 2, 2, 0xFF3A2A3A);
        boolean open = talking() && (ticks / 4) % 2 == 0;
        rect(g, cx - 2, y + 1, 4, open ? 4 : 2, 0xFFF5A623);
        rect(g, cx - 1, y + 5, 2, open ? 1 : 0, 0xFFB5701A);
        // a bow tie
        rect(g, cx - 5, y + 8, 4, 4, 0xFFE5486F); rect(g, cx + 1, y + 8, 4, 4, 0xFFE5486F); rect(g, cx - 1, y + 9, 2, 2, 0xFFB02A4F);
        rect(g, cx - 8, y + 15, 5, 2, 0xFFF5A623); rect(g, cx + 3, y + 15, 5, 2, 0xFFF5A623);
        // the graduation cap with a tassel
        rect(g, cx - 9, y - 17, 18, 5, 0xFF2A2A3A);
        rect(g, cx - 9, y - 22, 18, 3, 0xFF3A3A4E);
        rect(g, cx - 14, y - 19, 28, 3, 0xFF3A3A4E);
        rect(g, cx - 14, y - 19, 28, 1, 0xFF55557A);
        rect(g, cx + 12, y - 18, 1, 8, 0xFFFFD34E); rect(g, cx + 11, y - 11, 3, 3, 0xFFFFD34E);
        // the pointer
        int px = cx + 19, py = y + 2 - (talking() ? (int) Math.round(Math.sin(ticks / 5.0) * 2) : 0);
        for (int k = 0; k < 12; k++) rect(g, px + k * 3 / 2, py - k, 2, 2, 0xFFE9C46A);
        rect(g, px + 19, py - 12, 3, 3, 0xFFE5484D);
        if (sad && (ticks / 10) % 2 == 0) disc(g, cx + 17, y - 14, 2, 0xFF8AD0FF);
        if (happy) { sparkle(g, cx - 20, y - 12 - (ticks / 4) % 4, 2, 0xFFFFE680); sparkle(g, cx + 22, y - 18 + (ticks / 5) % 3, 1, 0xFFFFFFFF); }
        // the name plate on the desk
        roundRect(g, 8, 104, 56, 11, 3, 0xFFFFF1D6);
        fit(g, f, t("cutemod.school.teacher"), 36, 106, 50, 0xFF6E4726, true);
    }

    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(1 - dy * dy / (double) (ry * ry + 1)));
            g.fill(cx - dx, cy + dy, cx + dx, cy + dy + 1, argb);
        }
    }

    private void pupils(GuiGraphics g) {
        ComputerColor[] crowd = crowd();
        ComputerColor own = crowd[OWN];
        int hand = mode == ASK && picked < 0 && revealed() ? (qs[qi] * 3 + level) % 5 : -1;
        if (hand == OWN) hand = (hand + 1) % 5;
        int[] bookColor = {0xFF7ACB8A, 0xFF6FB0FF, 0xFFF58FB8, 0xFFF5B84A, 0xFFB57BD6};
        for (int i = 0; i < PUPIL_X.length; i++) {
            boolean mine = i == OWN;
            ComputerColor c = crowd[i];
            int mood = 1, hop = 0;
            if (mode == ASK && picked >= 0 && react < 50) {
                if (lastOk) { mood = 2; hop = (int) Math.round(Math.abs(Math.sin((react + i * 4) / 4.0)) * 6); }
                else if (mine) mood = 0;
            } else if (mode == RESULT) {
                mood = right >= 3 ? 2 : mine ? 0 : 1;
                if (right == LESSON) hop = (int) Math.round(Math.abs(Math.sin((resultT + i * 5) / 4.0)) * 6);
            } else if (mode == MENU || mode == PICK) mood = 2;
            int cx = PUPIL_X[i], fl = FLOOR_Y - hop + (int) Math.round(Math.sin(ticks / 24.0 + i * 1.7));
            float sc = 0.5F;
            oval(g, cx, FLOOR_Y, 18, 3, 0x22000000);
            g.pose().pushPose();
            g.pose().translate(cx, fl, 0);
            g.pose().scale(sc, sc, 1F);
            g.pose().translate(-cx, -fl, 0);
            PetArt.draw(g, c, mine ? PetArt.ownVariant(c) : 0, cx, fl - 28, mood, ticks + i * 17, false, false, mine ? 2 : 1,
                    mine ? Progress.equipped() : "", mine ? Progress.equippedBody() : "");
            g.pose().popPose();
            if (i == hand) {
                int wave = (int) Math.round(Math.sin(ticks / 3.0) * 2);
                rect(g, cx + 12, FLOOR_Y - 32 + wave, 3, 9, mix(c.bodyColor, 0x000000, 0.12F));
                rect(g, cx + 11, FLOOR_Y - 34 + wave, 5, 3, mix(c.bodyColor, 0xFFFFFF, 0.2F));
            }
            // the desk: a top with a light edge, a front, an open book and a pencil
            roundRect(g, cx - 25, FLOOR_Y - 1, 50, 5, 2, WOOD_LIGHT);
            rect(g, cx - 24, FLOOR_Y, 48, 1, 0x66FFFFFF);
            rect(g, cx - 22, FLOOR_Y + 4, 44, H - FLOOR_Y - 4, WOOD);
            rect(g, cx - 22, FLOOR_Y + 4, 44, 1, 0x22000000);
            rect(g, cx - 16, FLOOR_Y + 1, 9, 3, bookColor[i]); rect(g, cx - 15, FLOOR_Y, 7, 1, 0xFFFFFFFF);
            rect(g, cx + 6, FLOOR_Y + 1, 9, 1, 0xFFF5B84A); rect(g, cx + 15, FLOOR_Y + 1, 2, 1, 0xFFE5486F);
            if (mine) { roundRect(g, cx - 9, FLOOR_Y + 7, 18, 6, 2, 0xFFFFD34E); rect(g, cx - 1, FLOOR_Y + 8, 2, 4, 0xFFB07A10); rect(g, cx - 4, FLOOR_Y + 9, 8, 2, 0xFFB07A10); }
            // little feelings over the heads
            if (mode == ASK && picked >= 0 && react < 60 && lastOk)
                heart(g, cx - 12 + (i * 7) % 18, fl - 26 - react / 2, mine ? 0xFFFF5A86 : 0xFFFFA8C4);
            if (mode == ASK && picked >= 0 && !lastOk && mine && react < 70 && (react / 12) % 2 == 0) {
                roundRect(g, cx + 8, fl - 34, 11, 11, 4, 0xFFFFFFFF);
                CuteFont.draw(g, font(), "?", cx + 12, fl - 32, 0xFF8A7AA8, false);
            }
        }
    }

    private void confetti(GuiGraphics g) {
        int[] col = {0xFFFF8AB4, 0xFFFFD34E, 0xFF6FB0FF, 0xFF7ACB8A, 0xFFB57BD6};
        for (int i = 0; i < 28; i++) {
            int x = 4 + (i * 53 + (int) (Math.sin((resultT + i * 9) / 17.0) * 8)) % (W - 8);
            int y = 15 + ((resultT * (1 + i % 3)) / 2 + i * 23) % 108;
            rect(g, x, y, 2, 3, col[i % col.length]);
        }
    }

    // ---------- the screens ----------
    private void menu(GuiGraphics g, Font f, int mx, int my) {
        for (int i = 0; i < 3; i++) {
            int x = AX + i * CARD_STEP, y = CARD_Y;
            boolean hov = in(mx, my, x, y, CARD_W, CARD_H);
            if (hov) y -= 1;
            roundRect(g, x, y + 2, CARD_W, CARD_H, 6, 0x44000000);
            roundRect(g, x, y, CARD_W, CARD_H, 6, hov ? 0xFFFFFFFF : CARD[i]);
            roundRect(g, x, y, CARD_W, 14, 6, CARD_EDGE[i]);
            rect(g, x, y + 9, CARD_W, 5, CARD_EDGE[i]);
            fit(g, f, t("cutemod.school.level." + LEVEL[i]), x + CARD_W / 2, y + 3, CARD_W - 6, 0xFFFFFFFF, true);
            emblem(g, i, x + CARD_W / 2, y + 23);
            fit(g, f, t("cutemod.school.level.desc." + LEVEL[i]), x + CARD_W / 2, y + 33, CARD_W - 6, MUTED, true);
            coin(g, x + 9, y + 47);
            fit(g, f, t("cutemod.school.per", PER_RIGHT[i]), x + 16, y + 44, CARD_W - 20, 0xFFB07A10, false);
            for (int s = 0; s < LESSON; s++) star(g, x + 11 + s * 12, y + CARD_H - 4, s < best[idx(i)], 2);
        }
    }

    // ---------- the screen with the subjects ----------
    private static final int TILE_W = 51, TILE_H = 29, TILE_DX = 55, TILE_DY = 32;
    private static final int[] SUBJ_FILL = {0xFFF4E8FF, 0xFFDDEBFF, 0xFFD8F3D8, 0xFFFFE3C9, 0xFFD6F1F7, 0xFFF3E3BC, 0xFFE6D8F7, 0xFFFFD9E4};
    private static final int[] SUBJ_EDGE = {0xFFB57BD6, 0xFF5B8DEF, 0xFF6FBF7A, 0xFFE08A4A, 0xFF4AB0C8, 0xFFC9A04A, 0xFF8A6AC8, 0xFFE0708F};

    private static int tileX(int i) { return AX + (i % 4) * TILE_DX; }

    private static int tileY(int i) { return CARD_Y + (i / 4) * TILE_DY; }

    private void pick(GuiGraphics g, Font f, int mx, int my) {
        for (int i = 0; i < SUBJECTS; i++) {
            int x = tileX(i), y = tileY(i);
            boolean hov = in(mx, my, x, y, TILE_W, TILE_H);
            if (hov) y -= 1;
            roundRect(g, x, y + 2, TILE_W, TILE_H, 5, 0x44000000);
            roundRect(g, x, y, TILE_W, TILE_H, 5, hov ? 0xFFFFFFFF : SUBJ_FILL[i]);
            rect(g, x + 5, y, TILE_W - 10, 1, 0x88FFFFFF);
            subjectEmblem(g, i, x + TILE_W / 2, y + 9);
            fit(g, f, t("cutemod.school.subj.name." + SUBJECT[i]), x + TILE_W / 2, y + (CuteFont.size() == 2 ? 15 : 17), TILE_W - 4, TEXT, true);
            for (int lv = 0; lv < 3; lv++)                                  // a gold dot for every class finished with five out of five
                rect(g, x + TILE_W / 2 - 5 + lv * 4, y + TILE_H - 3, 2, 2, best[i * 3 + lv] >= LESSON ? 0xFFF0B020 : (SUBJ_EDGE[i] & 0xFFFFFF) | 0x66000000);
        }
    }

    /** A small picture for every subject (about 14 x 14 pixels around the centre). */
    private void subjectEmblem(GuiGraphics g, int s, int cx, int cy) {
        int w = 0xFFFFFFFF;
        switch (s) {
            case 0 -> {                                                     // mixed: four coloured squares
                rect(g, cx - 6, cy - 6, 5, 5, 0xFFF58FB8); rect(g, cx + 1, cy - 6, 5, 5, 0xFF6FB0FF);
                rect(g, cx - 6, cy + 1, 5, 5, 0xFF7ACB8A); rect(g, cx + 1, cy + 1, 5, 5, 0xFFF5B84A);
            }
            case 1 -> {                                                     // English: a speech bubble with an A
                roundRect(g, cx - 7, cy - 6, 14, 11, 3, 0xFF5B8DEF);
                rect(g, cx - 4, cy + 5, 3, 2, 0xFF5B8DEF);
                rect(g, cx - 3, cy - 4, 1, 7, w); rect(g, cx + 2, cy - 4, 1, 7, w); rect(g, cx - 2, cy - 4, 4, 1, w); rect(g, cx - 2, cy - 1, 4, 1, w);
            }
            case 2 -> {                                                     // biology: a leaf
                oval(g, cx, cy - 1, 4, 6, 0xFF4CAF50);
                rect(g, cx, cy - 6, 1, 11, 0xFF2E7D32);
                rect(g, cx - 2, cy - 2, 2, 1, 0xFF2E7D32); rect(g, cx + 1, cy, 2, 1, 0xFF2E7D32); rect(g, cx - 2, cy + 2, 2, 1, 0xFF2E7D32);
                rect(g, cx, cy + 5, 1, 3, 0xFF6E4726);
            }
            case 3 -> {                                                     // chemistry: a flask with a green liquid
                rect(g, cx - 3, cy - 8, 6, 1, 0xFF8AA8C0);
                rect(g, cx - 2, cy - 7, 4, 4, 0xFFB8D8F0);
                for (int r = 0; r < 8; r++) rect(g, cx - (4 + r) / 2, cy - 3 + r, 4 + r, 1, 0xFFB8D8F0);
                for (int r = 3; r < 8; r++) rect(g, cx - (4 + r) / 2 + 1, cy - 3 + r, 2 + r, 1, 0xFF6BCB7A);
                rect(g, cx + 3, cy - 6, 2, 2, w); sparkle(g, cx + 6, cy - 3, 1, 0xFFE08A4A);
            }
            case 4 -> {                                                     // physics: an atom
                for (int o = 0; o < 3; o++) {
                    double phi = o * Math.PI / 3;
                    for (int a = 0; a < 24; a++) {
                        double ang = a * Math.PI / 12, ex = 7 * Math.cos(ang), ey = 2.5 * Math.sin(ang);
                        rect(g, cx + (int) Math.round(ex * Math.cos(phi) - ey * Math.sin(phi)), cy + (int) Math.round(ex * Math.sin(phi) + ey * Math.cos(phi)), 1, 1, 0xFF3A86D8);
                    }
                }
                disc(g, cx, cy, 2, 0xFFE5486F);
            }
            case 5 -> {                                                     // world history: a column
                rect(g, cx - 5, cy - 7, 10, 2, 0xFFB8925A);
                rect(g, cx - 3, cy - 5, 6, 9, 0xFFFFF6DF);
                rect(g, cx - 1, cy - 5, 1, 9, 0xFFE0CBA0); rect(g, cx + 1, cy - 5, 1, 9, 0xFFE0CBA0);
                rect(g, cx - 5, cy + 4, 10, 2, 0xFFB8925A);
            }
            case 6 -> {                                                     // philosophy: a thought cloud
                disc(g, cx - 3, cy - 1, 4, w); disc(g, cx + 3, cy - 1, 4, w); disc(g, cx, cy - 4, 4, w);
                rect(g, cx - 5, cy - 1, 10, 3, w);
                disc(g, cx - 4, cy + 5, 1, w); disc(g, cx - 6, cy + 7, 1, w);
                sparkle(g, cx, cy - 2, 2, 0xFFB57BD6);
            }
            default -> {                                                    // literature: an open book with a pen
                rect(g, cx - 7, cy - 4, 7, 9, w); rect(g, cx, cy - 4, 7, 9, 0xFFF4F4FF); rect(g, cx - 1, cy - 5, 2, 11, 0xFFE5486F);
                for (int k = 0; k < 3; k++) { rect(g, cx - 6, cy - 2 + k * 3, 4, 1, 0xFFB9A8C8); rect(g, cx + 2, cy - 2 + k * 3, 4, 1, 0xFFB9A8C8); }
                line(g, cx + 3, cy + 5, cx + 8, cy - 6, 0xFF8A5AB5);
            }
        }
    }

    /** A small picture for every class: an apple, an open book, a light bulb. */
    private static void emblem(GuiGraphics g, int lv, int cx, int cy) {
        switch (lv) {
            case 0 -> { disc(g, cx, cy + 1, 6, 0xFFE5484D); disc(g, cx - 2, cy - 1, 2, 0xFFFF8A8F); rect(g, cx, cy - 7, 1, 3, 0xFF6E4726); rect(g, cx + 1, cy - 7, 4, 2, 0xFF4CAF50); }
            case 1 -> { rect(g, cx - 8, cy - 4, 8, 10, 0xFFFFFFFF); rect(g, cx, cy - 4, 8, 10, 0xFFF4F4FF); rect(g, cx - 1, cy - 5, 2, 12, 0xFF5B8DEF);
                for (int k = 0; k < 3; k++) { rect(g, cx - 6, cy - 2 + k * 3, 4, 1, 0xFFB9A8C8); rect(g, cx + 2, cy - 2 + k * 3, 4, 1, 0xFFB9A8C8); } }
            default -> { disc(g, cx, cy - 1, 6, 0xFFFFE680); disc(g, cx - 2, cy - 3, 2, 0xFFFFFFFF); rect(g, cx - 3, cy + 5, 6, 3, 0xFF8A7AA8); rect(g, cx - 2, cy + 8, 4, 1, 0xFF6A5A88);
                sparkle(g, cx + 9, cy - 6, 2, 0xFFF5B84A); sparkle(g, cx - 9, cy - 5, 1, 0xFFF5B84A); }
        }
    }

    private void ask(GuiGraphics g, Font f, int mx, int my) {
        int n = OPTIONS[level];
        boolean wide = n == 4;
        int h = wide ? 15 : 18, step = wide ? 16 : 20, y0 = ANS_Y, r = wide ? 6 : 7;
        boolean ready = revealed();
        int rs = rightSlot();
        for (int s = 0; s < n; s++) {
            int y = y0 + s * step;
            boolean hov = picked < 0 && ready && in(mx, my, AX, y, AW, h);
            int bg = ready ? 0xFFFFFFFF : 0xFFF3EEF7;
            if (picked >= 0) bg = s == rs ? 0xFFC8F2CC : s == picked ? 0xFFFAC4C4 : 0xFFEFE9F5;
            else if (hov) bg = 0xFFFFF3B0;
            roundRect(g, AX, y + 1, AW, h, 5, 0x33000000);
            roundRect(g, AX, y, AW, h, 5, bg);
            rect(g, AX + 6, y, AW - 12, 1, 0x66FFFFFF);
            if (ready || picked >= 0) {
                disc(g, AX + 4 + r, y + h / 2, r, picked >= 0 && s != rs && s != picked ? 0xFFC8BCD8 : BADGE[s]);
                String L = String.valueOf((char) ('A' + s));
                fit(g, f, L, AX + 4 + r, y + (h - 8) / 2, r * 2 - 2, 0xFFFFFFFF, true);
                fit(g, f, answer(s), AX + 12 + r * 2, y + (h - 8) / 2, AW - 30 - r * 2, TEXT, false);
            }
            if (picked >= 0 && s == rs) { line(g, AX + AW - 14, y + h / 2, AX + AW - 11, y + h / 2 + 3, 0xFF2E9A4A); line(g, AX + AW - 11, y + h / 2 + 3, AX + AW - 6, y + h / 2 - 3, 0xFF2E9A4A); }
            if (picked >= 0 && s == picked && s != rs) { line(g, AX + AW - 13, y + h / 2 - 3, AX + AW - 7, y + h / 2 + 3, 0xFFD03A3A); line(g, AX + AW - 13, y + h / 2 + 3, AX + AW - 7, y + h / 2 - 3, 0xFFD03A3A); }
        }
        if (picked >= 0) {
            String m = msgT > 0 ? msg : "";
            if (!m.isEmpty()) {
                int mw = fitW(f, m, AW - NEXT_W - 22);
                roundRect(g, AX, NEXT_Y, mw + 14, 15, 6, lastOk ? 0xEE2E7A4A : 0xEE7A3A4A);
                fit(g, f, m, AX + 7, NEXT_Y + 4, AW - NEXT_W - 22, 0xFFFFFFFF, false);
            }
            pill(g, f, mx, my, AX + AW - NEXT_W, NEXT_Y - 1, NEXT_W, 15, t(qi + 1 < LESSON ? "cutemod.school.next" : "cutemod.school.finish"), 1);
        }
    }

    private void result(GuiGraphics g, Font f, int mx, int my) {
        roundRect(g, AX, CARD_Y + 1, AW, 36, 6, 0x33000000);
        roundRect(g, AX, CARD_Y - 1, AW, 36, 6, 0xFFFFFFFF);
        fit(g, f, t("cutemod.school.score", right, LESSON), AX + 8, CARD_Y + 4, 104, TEXT, false);
        for (int s = 0; s < LESSON; s++) {
            boolean on = s < right;
            int pulse = on ? (int) Math.round(Math.sin((resultT + s * 6) / 6.0)) : 0;
            star(g, AX + 14 + s * 20, CARD_Y + 24, on);
            if (on && pulse > 0) sparkle(g, AX + 14 + s * 20 + 6, CARD_Y + 17, 2, 0xFFFFE680);
        }
        String pay = capped && paid == 0 ? t("cutemod.school.cap") : t("cutemod.school.paid", paid);
        coin(g, AX + 124, CARD_Y + 9);
        fit(g, f, pay, AX + 132, CARD_Y + 5, AW - 138, 0xFFB07A10, false);
        if (capped && paid > 0) fit(g, f, t("cutemod.school.cap"), AX + 124, CARD_Y + 18, AW - 130, MUTED, false);
        pill(g, f, mx, my, AX, RES_Y, 104, 16, t("cutemod.school.again"), 1);
        pill(g, f, mx, my, AX + 112, RES_Y, 104, 16, t("cutemod.school.menu"), 0);
    }

    private static void star(GuiGraphics g, int cx, int cy, boolean on) { star(g, cx, cy, on, 3); }

    private static void star(GuiGraphics g, int cx, int cy, boolean on, int k) {
        int c = on ? 0xFFF0B020 : 0xFFE2D9EC, d = on ? 0xFFFFE680 : 0xFFEEE8F4;
        rect(g, cx - k, cy - k, k * 2, k * 2, c); rect(g, cx - k - 2, cy - 1, k * 2 + 4, 2, c); rect(g, cx - 1, cy - k - 2, 2, k * 2 + 4, c);
        rect(g, cx - 1, cy - 2, 2, 2, d);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        switch (mode) {
            case PICK -> {
                for (int i = 0; i < SUBJECTS; i++) {
                    if (in(x, y, tileX(i), tileY(i), TILE_W, TILE_H)) { pickSubject(i); return true; }
                }
            }
            case MENU -> {
                if (in(x, y, BACK_X, 1, BACK_W, 12)) { mode = PICK; greetPick(); return true; }          // back to the subjects
                for (int i = 0; i < 3; i++) {
                    if (in(x, y, AX + i * CARD_STEP, CARD_Y, CARD_W, CARD_H)) {
                        start(i);
                        return true;
                    }
                }
            }
            case ASK -> {
                if (in(x, y, BACK_X, 1, BACK_W, 12)) { toMenu(); return true; }
                if (!revealed()) { reveal = revealLen() * 2; vText = ""; return true; }       // a click finishes the writing (and the owl stops talking)
                if (picked >= 0) {
                    if (in(x, y, AX + AW - NEXT_W, NEXT_Y - 1, NEXT_W, 17)) { advance(); return true; }
                    return false;
                }
                boolean wide = OPTIONS[level] == 4;
                int h = wide ? 15 : 18, step = wide ? 16 : 20;
                for (int s = 0; s < OPTIONS[level]; s++) {
                    if (in(x, y, AX, ANS_Y + s * step, AW, h)) { choose(s); return true; }
                }
            }
            default -> {
                if (in(x, y, AX, RES_Y, 104, 16)) { start(level); return true; }
                if (in(x, y, AX + 112, RES_Y, 104, 16)) { toMenu(); return true; }
            }
        }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (mode != ASK) return false;
        if (picked >= 0 && (keyCode == 257 || keyCode == 335 || keyCode == 32)) { advance(); return true; }   // Enter, Space
        if (picked < 0 && revealed()) {
            int s = keyCode >= 49 && keyCode <= 52 ? keyCode - 49 : keyCode >= 321 && keyCode <= 324 ? keyCode - 321 : -1;
            if (s >= 0 && s < OPTIONS[level]) { choose(s); return true; }
        }
        return false;
    }
}
