package dev.cutemod.block;

import dev.cutemod.data.Build;
import dev.cutemod.data.PcHardware.Kind;
import dev.cutemod.item.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/**
 * The inside of a PC case that is being built: which parts are physically in it. Unlike an old computer (which always has a
 * "stock" part of every kind) a case starts EMPTY and every part has to be put in by hand, in an order that makes sense: the
 * board first, then the processor, memory, drive, card; the power supply goes in on its own.
 *
 * <p>What is inside is shown on the block itself (properties of {@link PcCaseBlock}, one model per part, see the blockstate), so
 * the player watches the PC being assembled through the glass. This class is the truth; {@link #syncState} copies it to the
 * block state. It extends {@link ComputerBlockEntity}, so the OS, the records and the shop treat it like any computer: the build
 * it gives out ({@link #build()}) is made of exactly the parts that are inside.
 *
 * <p>Saved as: Board, Cpu, Psu, Gpu, Disk, Modem (-1 = not installed, else the level in the ladders of {@link Build}),
 * Sticks (the size of the memory stick of each slot in GB, 0 = empty slot) and On (the PC is switched on).
 */
public class PcCaseBlockEntity extends ComputerBlockEntity {
    /** Why a part did not go in. */
    public enum Result { OK, SAME, NEED_BOARD, NEED_PSU, SOCKET, NO_SLOT, BOARD_SLOTS, BUSY }

    /** The places of the case, as the build screen names them (see {@link #remove}). The memory sticks are S_STICK + 0..3. */
    public static final int S_BOARD = 0, S_CPU = 1, S_PSU = 2, S_GPU = 3, S_DISK = 4, S_MODEM = 5, S_CABLES = 6, S_STICK = 10;

    private int board = -1, cpu = -1, psu = -1, gpu = -1, disk = -1, modem = -1;
    private final int[] sticks = new int[Build.MAX_SLOTS];
    private boolean cables;
    private boolean on;
    /** The answer of the last install / remove (for the build screen, which tells the player why a part did not go in). Not saved. */
    private Result last = Result.OK;

    public PcCaseBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.PC_CASE.get(), pos, state);
    }

    // ---------- what is inside ----------
    public boolean hasBoard() { return board >= 0; }
    public boolean hasCpu() { return cpu >= 0; }
    public boolean hasPsu() { return psu >= 0; }
    public boolean hasDisk() { return disk >= 0; }
    public boolean hasModem() { return modem >= 0; }
    public boolean hasCables() { return cables; }
    public int gpuLevel() { return Math.max(0, gpu); }
    public boolean isOn() { return on; }

    public int stickCount() {
        int n = 0;
        for (int s : sticks) if (s > 0) n++;
        return n;
    }

    /** The parts a PC cannot start without, as the names to show: the ones that are still missing (empty = it is ready). */
    public List<Component> missing() {
        List<Component> out = new ArrayList<>();
        if (!hasBoard()) out.add(Component.translatable("cutemod.case.part.board"));
        if (!hasCpu()) out.add(Component.translatable("cutemod.case.part.cpu"));
        if (stickCount() == 0) out.add(Component.translatable("cutemod.case.part.ram"));
        if (!hasDisk()) out.add(Component.translatable("cutemod.case.part.disk"));
        if (!hasPsu()) out.add(Component.translatable("cutemod.case.part.psu"));
        if (!hasCables()) out.add(Component.translatable("cutemod.case.part.cables"));
        return out;
    }

    /** True when the PC has everything it needs to start (the video card and the modem are optional: the processor draws, the modem is for the internet). */
    public boolean isComplete() { return missing().isEmpty(); }

    /** The build of the parts that are inside: this is what the OS, the games and the shop see. */
    @Override
    public Build build() {
        Build b = Build.stock();
        b.cpu = Math.max(0, cpu);
        b.board = Math.max(0, board);
        b.psu = Math.max(0, psu);
        b.gpu = Math.max(0, gpu);
        b.disk = Math.max(0, disk);
        b.modem = modem;
        int slots = b.slots();
        for (int i = 0; i < Build.MAX_SLOTS; i++) b.sticks[i] = i < slots ? sticks[i] : 0;
        return b;
    }

    // ---------- installing and taking out ----------
    /**
     * Tries to put a part in. On OK the part is in and {@code out[0]} is what came out of its place (a swapped part, as an item;
     * EMPTY if the place was free). A change always switches the PC off. {@code level} is the level in the ladders of
     * {@link Build}, for a memory stick its size in GB.
     */
    public Result install(Kind kind, int level, ItemStack[] out) { return last = installPart(kind, level, out); }

    private Result installPart(Kind kind, int level, ItemStack[] out) {
        out[0] = ItemStack.EMPTY;
        switch (kind) {
            case BOARD -> {
                if (level < 0 || level >= Build.BOARD_NAMES.length) return Result.SAME;
                if (level == board) return Result.SAME;
                if (cpu >= 0 && !Build.fits(Build.CPU_SOCKET[cpu], Build.BOARD_SOCKET[level])) return Result.SOCKET;
                if (stickCount() > Build.BOARD_SLOTS[level] || highestUsedSlot() >= Build.BOARD_SLOTS[level]) return Result.BOARD_SLOTS;
                if (board >= 0) out[0] = ModItems.partStack(Kind.BOARD, board);
                board = level;
            }
            case CPU -> {
                if (level < 0 || level >= Build.CPU_NAMES.length) return Result.SAME;
                if (board < 0) return Result.NEED_BOARD;
                if (level == cpu) return Result.SAME;
                if (!Build.fits(Build.CPU_SOCKET[level], Build.BOARD_SOCKET[board])) return Result.SOCKET;
                if (cpu >= 0) out[0] = ModItems.partStack(Kind.CPU, cpu);
                cpu = level;
            }
            case PSU -> {
                if (level < 0 || level >= Build.PSU_NAMES.length) return Result.SAME;
                if (level == psu) return Result.SAME;
                if (psu >= 0) out[0] = ModItems.partStack(Kind.PSU, psu);
                psu = level;
            }
            case GPU -> {
                if (level < 1 || level >= dev.cutemod.data.PcHardware.GPU_NAMES.length) return Result.SAME;
                if (board < 0) return Result.NEED_BOARD;
                if (level == gpu) return Result.SAME;
                if (gpu >= 0) out[0] = ModItems.partStack(Kind.GPU, gpu);
                gpu = level;
            }
            case DISK -> {
                if (level < 0 || level >= dev.cutemod.data.PcHardware.DISK_GB.length) return Result.SAME;
                if (board < 0) return Result.NEED_BOARD;
                if (level == disk) return Result.SAME;
                if (disk >= 0) out[0] = ModItems.partStack(Kind.DISK, disk);
                disk = level;
            }
            case MODEM -> {
                if (level < dev.cutemod.data.PcHardware.MODEM_FIRST || level > dev.cutemod.data.PcHardware.MODEM_LAST) return Result.SAME;
                if (board < 0) return Result.NEED_BOARD;
                if (level == modem) return Result.SAME;
                if (modem >= 0) out[0] = ModItems.partStack(Kind.MODEM, modem);
                modem = level;
            }
            case RAM -> {                                           // level = the size of the stick in GB
                if (Build.stickPrice(level) < 0) return Result.SAME;
                if (board < 0) return Result.NEED_BOARD;
                int slot = -1;
                for (int i = 0; i < Build.BOARD_SLOTS[board] && slot < 0; i++) if (sticks[i] == 0) slot = i;
                if (slot < 0) return Result.NO_SLOT;
                sticks[slot] = level;
            }
        }
        on = false;
        changed();
        return Result.OK;
    }

    /**
     * Puts the cables in: they join the power supply to the board, so both have to be inside already. A change switches the PC off.
     */
    public Result installCables() { return last = installCablesInner(); }

    private Result installCablesInner() {
        if (board < 0) return Result.NEED_BOARD;
        if (psu < 0) return Result.NEED_PSU;
        if (cables) return Result.SAME;
        cables = true;
        on = false;
        changed();
        return Result.OK;
    }

    /** How the last install / remove ended. */
    public Result lastResult() { return last; }

    /** What is inside, for the build screen: board, cpu, psu, gpu, disk, modem (-1 = none), cables (0/1), on (0/1), then the four memory sticks (GB, 0 = empty). */
    public int[] snapshot() {
        int[] s = new int[8 + Build.MAX_SLOTS];
        s[0] = board; s[1] = cpu; s[2] = psu; s[3] = gpu; s[4] = disk; s[5] = modem;
        s[6] = cables ? 1 : 0;
        s[7] = on ? 1 : 0;
        for (int i = 0; i < Build.MAX_SLOTS; i++) s[8 + i] = sticks[i];
        return s;
    }

    /**
     * Takes ONE chosen part out (the build screen lets the player pick it; {@link #removeLast} is the sneak shortcut). A part that others
     * sit on cannot come out: the board needs the processor, memory, card, drive, modem and cables out first, the power supply the cables.
     * On OK {@code out[0]} is the part as an item. A change always switches the PC off.
     */
    public Result remove(int slot, ItemStack[] out) { return last = removeInner(slot, out); }

    private Result removeInner(int slot, ItemStack[] out) {
        out[0] = ItemStack.EMPTY;
        switch (slot) {
            case S_BOARD -> {
                if (board < 0) return Result.SAME;
                if (cpu >= 0 || gpu >= 0 || disk >= 0 || modem >= 0 || cables || stickCount() > 0) return Result.BUSY;
                out[0] = ModItems.partStack(Kind.BOARD, board);
                board = -1;
            }
            case S_CPU -> {
                if (cpu < 0) return Result.SAME;
                out[0] = ModItems.partStack(Kind.CPU, cpu);
                cpu = -1;
            }
            case S_PSU -> {
                if (psu < 0) return Result.SAME;
                if (cables) return Result.BUSY;
                out[0] = ModItems.partStack(Kind.PSU, psu);
                psu = -1;
            }
            case S_GPU -> {
                if (gpu < 0) return Result.SAME;
                out[0] = ModItems.partStack(Kind.GPU, gpu);
                gpu = -1;
            }
            case S_DISK -> {
                if (disk < 0) return Result.SAME;
                out[0] = ModItems.partStack(Kind.DISK, disk);
                disk = -1;
            }
            case S_MODEM -> {
                if (modem < 0) return Result.SAME;
                out[0] = ModItems.partStack(Kind.MODEM, modem);
                modem = -1;
            }
            case S_CABLES -> {
                if (!cables) return Result.SAME;
                out[0] = new ItemStack(ModItems.PC_CABLES.get());
                cables = false;
            }
            default -> {
                int i = slot - S_STICK;
                if (i < 0 || i >= sticks.length || sticks[i] == 0) return Result.SAME;
                out[0] = ModItems.stickStack(sticks[i]);
                sticks[i] = 0;
            }
        }
        if (out[0].isEmpty()) return Result.SAME;
        on = false;
        changed();
        return Result.OK;
    }

    private int highestUsedSlot() {
        int hi = -1;
        for (int i = 0; i < sticks.length; i++) if (sticks[i] > 0) hi = i;
        return hi;
    }

    /**
     * Takes the part that went in last out of the case (the order of a real build, backwards: the card and the modem, the drive,
     * the memory, the cables, the processor, the board, the power supply) and gives it back as an item. EMPTY if the case is empty.
     */
    public ItemStack removeLast() {
        ItemStack out = ItemStack.EMPTY;
        if (modem >= 0) { out = ModItems.partStack(Kind.MODEM, modem); modem = -1; }
        else if (gpu >= 0) { out = ModItems.partStack(Kind.GPU, gpu); gpu = -1; }
        else if (disk >= 0) { out = ModItems.partStack(Kind.DISK, disk); disk = -1; }
        else if (highestUsedSlot() >= 0) { int i = highestUsedSlot(); out = ModItems.stickStack(sticks[i]); sticks[i] = 0; }
        else if (cables) { out = new ItemStack(ModItems.PC_CABLES.get()); cables = false; }
        else if (cpu >= 0) { out = ModItems.partStack(Kind.CPU, cpu); cpu = -1; }
        else if (board >= 0) { out = ModItems.partStack(Kind.BOARD, board); board = -1; }
        else if (psu >= 0) { out = ModItems.partStack(Kind.PSU, psu); psu = -1; }
        else return ItemStack.EMPTY;
        on = false;
        changed();
        return out;
    }

    /** Every part that is inside, as items (when the case is broken they drop). */
    public List<ItemStack> allParts() {
        List<ItemStack> out = new ArrayList<>();
        if (modem >= 0) out.add(ModItems.partStack(Kind.MODEM, modem));
        if (gpu >= 0) out.add(ModItems.partStack(Kind.GPU, gpu));
        if (disk >= 0) out.add(ModItems.partStack(Kind.DISK, disk));
        for (int s : sticks) if (s > 0) out.add(ModItems.stickStack(s));
        if (cables) out.add(new ItemStack(ModItems.PC_CABLES.get()));
        if (cpu >= 0) out.add(ModItems.partStack(Kind.CPU, cpu));
        if (board >= 0) out.add(ModItems.partStack(Kind.BOARD, board));
        if (psu >= 0) out.add(ModItems.partStack(Kind.PSU, psu));
        out.removeIf(ItemStack::isEmpty);
        return out;
    }

    /** Server side: switch the PC on or off. A PC that is not complete stays off. Returns whether it is on now. */
    public boolean setOn(boolean value) {
        boolean now = value && isComplete();
        if (now != on) {
            on = now;
            changed();
        }
        return on;
    }

    // ---------- keeping the block in step ----------
    /** Copies what is inside to the block state (so the model shows it) and tells the clients. */
    private void changed() {
        setChanged();
        if (level == null) return;
        BlockState s = syncState(getBlockState());
        if (s != getBlockState()) level.setBlock(worldPosition, s, 3);
        else level.sendBlockUpdated(worldPosition, s, s, 3);
    }

    /** The given state of the case with the properties of what is inside. */
    public BlockState syncState(BlockState s) {
        if (!(s.getBlock() instanceof PcCaseBlock)) return s;
        return s.setValue(PcCaseBlock.BOARD, board >= 0)
                .setValue(PcCaseBlock.CPU, cpu >= 0)
                .setValue(PcCaseBlock.PSU, psu >= 0)
                .setValue(PcCaseBlock.DISK, disk >= 0)
                .setValue(PcCaseBlock.NET, modem >= 0)
                .setValue(PcCaseBlock.CABLES, cables)
                .setValue(PcCaseBlock.GPU, Math.max(0, gpu))
                .setValue(PcCaseBlock.RAM, stickCount())
                .setValue(PcCaseBlock.LIT, on);
    }

    // ---------- saving ----------
    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Board", board);
        tag.putInt("Cpu", cpu);
        tag.putInt("Psu", psu);
        tag.putInt("Gpu", gpu);
        tag.putInt("Disk", disk);
        tag.putInt("Modem", modem);
        tag.putBoolean("Cables", cables);
        tag.putIntArray("Sticks", sticks);
        tag.putBoolean("On", on);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        board = tag.contains("Board") ? tag.getInt("Board") : -1;
        cpu = tag.contains("Cpu") ? tag.getInt("Cpu") : -1;
        psu = tag.contains("Psu") ? tag.getInt("Psu") : -1;
        gpu = tag.contains("Gpu") ? tag.getInt("Gpu") : -1;
        disk = tag.contains("Disk") ? tag.getInt("Disk") : -1;
        modem = tag.contains("Modem") ? tag.getInt("Modem") : -1;
        // a case built before the cables existed keeps working: it counts as already wired (the cables are "in" when the board and the power supply are)
        cables = tag.contains("Cables") ? tag.getBoolean("Cables") : (board >= 0 && psu >= 0);
        int[] s = tag.getIntArray("Sticks");
        for (int i = 0; i < sticks.length; i++) sticks[i] = i < s.length ? s[i] : 0;
        on = tag.getBoolean("On");
    }
}
