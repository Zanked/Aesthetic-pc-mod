package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Number Hunt: a number from 1 to 100 is hidden. Click on the line to guess, the game says higher or lower. 7 tries. */
public class GuessLine extends MiniGame {
    private static final int LX = 10, LY = 70, LW = 200, LH = 22, TRIES = 7;

    private int secret, lo, hi, tries, last, hint;    // hint: 0 none, 1 higher, 2 lower
    private boolean won;

    @Override
    public void reset() {
        score = 0; over = false; won = false;
        secret = 1 + rnd.nextInt(100); lo = 1; hi = 100; tries = TRIES; last = -1; hint = 0;
    }

    private static int numAt(int x) { return Math.max(1, Math.min(100, (x - LX) / 2 + 1)); }

    @Override
    public boolean click(int x, int y, int button) {
        if (over || !in(x, y, LX, LY - 6, LW, LH + 12)) return true;
        int n = numAt(x);
        last = n; tries--;
        if (n == secret) { won = true; over = true; score = 20 + 10 * tries; pling(1.6F); return true; }
        if (n < secret) { lo = Math.max(lo, n + 1); hint = 1; } else { hi = Math.min(hi, n - 1); hint = 2; }
        pling(n < secret ? 0.8F : 1.1F);
        if (tries <= 0) over = true;
        return true;
    }

    @Override
    public void tick() {}

    @Override
    public void render(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, 0xFF2C5A5A, 0xFF16302E);
        ctext(g, Component.translatable("cutemod.guess.title").getString(), W / 2, 10, 0xFFFFD866);
        if (hint != 0 && !over) ctext(g, Component.translatable(hint == 1 ? "cutemod.guess.higher" : "cutemod.guess.lower", last).getString(), W / 2, 30, hint == 1 ? 0xFFB6FFC8 : 0xFFFFB6A8);
        else if (!over) ctext(g, Component.translatable("cutemod.guess.start").getString(), W / 2, 30, 0xFFFFFFFF);
        if (over) ctext(g, Component.translatable(won ? "cutemod.guess.found" : "cutemod.guess.lost", secret).getString(), W / 2, 30, won ? 0xFFB6FFC8 : 0xFFFF9AA8);
        // the line: every number is 2 pixels wide, the part that is still possible is bright
        rect(g, LX - 1, LY - 1, LW + 2, LH + 2, 0xFF0B1A19);
        rect(g, LX, LY, LW, LH, 0xFF284A48);
        rect(g, LX + (lo - 1) * 2, LY, (hi - lo + 1) * 2, LH, 0xFF5BBFA8);
        rect(g, LX + (lo - 1) * 2, LY, (hi - lo + 1) * 2, 3, 0x55FFFFFF);
        for (int n = 10; n < 100; n += 10) rect(g, LX + (n - 1) * 2, LY + LH - 4, 1, 4, 0x66FFFFFF);
        if (last > 0) rect(g, LX + (last - 1) * 2, LY - 4, 2, LH + 8, 0xFFFFD866);
        if (over) rect(g, LX + (secret - 1) * 2, LY - 6, 2, LH + 12, won ? 0xFF5BD97A : 0xFFE5486F);
        if (!over && in(mx, my, LX, LY - 6, LW, LH + 12)) {
            int n = numAt(mx);
            rect(g, LX + (n - 1) * 2, LY - 3, 2, LH + 6, 0xFFFFFFFF);
            ctext(g, String.valueOf(n), Math.max(LX + 10, Math.min(LX + LW - 10, LX + (n - 1) * 2)), LY + LH + 8, 0xFFFFFFFF);
        }
        for (int i = 0; i < TRIES; i++) disc(g, W / 2 - (TRIES - 1) * 7 + i * 14, 118, 4, i < tries ? 0xFFFFD866 : 0xFF3A4A48);
    }

    @Override
    public boolean isWin() { return won; }

    @Override
    public Component endTitle() { return Component.translatable(won ? "cutemod.guess.win" : "cutemod.ui.gameover"); }

    @Override
    public Component status() { return Component.translatable("cutemod.guess.tries", tries); }

    @Override
    public String hintKey() { return "cutemod.hint.guess"; }
}
