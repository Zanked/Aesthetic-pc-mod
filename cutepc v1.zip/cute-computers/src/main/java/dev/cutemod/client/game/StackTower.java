package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Block Tower: a block slides to and fro, click to drop it. What sticks out is cut off, a perfect drop keeps the whole block. */
public class StackTower extends MiniGame {
    private static final int BH = 10, BASE_W = 84, MAXN = 400, GROUND = 8;
    private static final int[] PAL = {0xFFF06AAE, 0xFFF5A04A, 0xFFF3D46A, 0xFF7ED957, 0xFF4FC9B8, 0xFF4A8FE0, 0xFF9B6AE0};

    private final int[] bx = new int[MAXN], bw = new int[MAXN];
    private int n, cw, perfect, flash;
    private float cx, dir, cam, camT;
    private boolean deb;
    private float dx, dy, dvy;
    private int dw, dc;

    @Override
    public void reset() {
        score = 0; over = false; perfect = 0; flash = 0; deb = false; cam = 0; camT = 0;
        bx[0] = (W - BASE_W) / 2; bw[0] = BASE_W; n = 1;
        spawn();
    }

    private void spawn() {
        cw = bw[n - 1];
        boolean left = n % 2 == 0;
        cx = left ? 0 : W - cw;
        dir = left ? 1 : -1;
    }

    private float speed() { return Math.min(3.4F, 1.1F + n * 0.05F); }

    private void drop(int x, int w, int level, int color) {
        deb = true; dx = x; dw = w; dc = color; dy = (H - GROUND) - (level + 1) * BH; dvy = 0;
    }

    private void place() {
        if (over) return;
        int left = bx[n - 1], right = left + bw[n - 1];
        int cl = Math.round(cx), cr = cl + cw;
        int ol = Math.max(left, cl), or = Math.min(right, cr), ow = or - ol;
        if (ow <= 0) { over = true; drop(cl, cw, n, PAL[n % PAL.length]); beep(); return; }
        if (Math.abs(cl - left) <= 2) {                              // a perfect drop: snap, keep the width
            ol = left; ow = bw[n - 1];
            perfect++; score += 2; flash = 40;
            pling(1.1F + Math.min(perfect, 8) * 0.07F);
        } else {
            perfect = 0; score += 1;
            if (cl < left) drop(cl, left - cl, n, PAL[n % PAL.length]);
            else drop(right, cr - right, n, PAL[n % PAL.length]);
            pling(0.8F);
        }
        bx[n] = ol; bw[n] = ow; n++;
        if (n >= MAXN - 1) { over = true; return; }
        spawn();
    }

    @Override
    public boolean click(int x, int y, int button) { place(); return true; }

    @Override
    public boolean key(int keyCode) {
        if (keyCode == KEY_SPACE) { place(); return true; }
        return false;
    }

    @Override
    public void tick() {
        if (flash > 0) flash--;
        if (deb) {
            dvy += 0.3F; dy += dvy;
            if (dy - cam > H + 20) deb = false;
        }
        camT = Math.max(0, (n + 1) * BH - (H - GROUND - 36));
        cam += (camT - cam) * 0.1F;
        if (over) return;
        cx += dir * speed();
        if (cx < 0) { cx = 0; dir = 1; }
        else if (cx > W - cw) { cx = W - cw; dir = -1; }
    }

    private static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    @Override
    public void render(GuiGraphics g) {
        float f = Math.min(1f, n / 60f);                                   // the sky gets dark as the tower grows
        g.fillGradient(0, 0, W, H, lerp(0xFF6EC6FF, 0xFF1B1440, f), lerp(0xFFFFD6E6, 0xFF3A2A6A, f));
        if (f > 0.4f) for (int i = 0; i < 18; i++) rect(g, (i * 53 + 11) % W, (i * 29 + 7) % (H - 20), 1, 1, 0xCCFFFFFF);
        int cam0 = Math.round(cam);
        int gy = H - GROUND + cam0;
        if (gy < H) { rect(g, 0, gy, W, H - gy, 0xFF5BBF4A); rect(g, 0, gy, W, 2, 0xFF8EE07A); }
        for (int i = 0; i < n; i++) {
            int y = (H - GROUND) - (i + 1) * BH + cam0;
            if (y > H || y < -BH) continue;
            int c = PAL[i % PAL.length];
            rect(g, bx[i], y, bw[i], BH, c);
            rect(g, bx[i], y, bw[i], 2, 0x55FFFFFF);
            rect(g, bx[i], y + BH - 2, bw[i], 2, 0x33000000);
        }
        if (deb) rect(g, Math.round(dx), Math.round(dy) + cam0, dw, BH, dc);
        if (!over) {
            int y = (H - GROUND) - (n + 1) * BH + cam0;
            int c = PAL[n % PAL.length];
            rect(g, Math.round(cx), y, cw, BH, c);
            rect(g, Math.round(cx), y, cw, 2, 0x55FFFFFF);
        }
        if (flash > 0) ctext(g, Component.translatable("cutemod.tower.perfect").getString(), W / 2, 12, 0xFFFFD866);
    }

    @Override
    public Component status() { return Component.translatable("cutemod.ui.score", score); }

    @Override
    public String hintKey() { return "cutemod.hint.tower"; }
}
