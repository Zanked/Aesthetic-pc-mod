package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Funny Farm: a cosy farm manager in the spirit of the classic "farm frenzy" games.
 * Click the well to fetch water, click the pasture to plant grass, let the hens, sheep and cows eat it and click the
 * eggs, wool and milk to put them into the warehouse. Click the truck to sell what is in the warehouse, click a workshop
 * to turn eggs into cakes, wool into sweaters and milk into cheese (worth much more). Buy more animals and upgrades,
 * cage the bears before they eat your animals. Every level has a goal (coins in hand and some sold goods) and a time
 * limit; the faster you are the more stars (gold / silver / bronze) you get.
 *
 * Everything is drawn at twice the game resolution (440 x 280 "virtual" units), the texts and the interface in game pixels.
 */
public class FunnyFarm extends MiniGame {
    // ---------- layout (virtual units, 2 per game pixel) ----------
    private static final int VW = W * 2, VH = H * 2;
    private static final int PX0 = 62, PY0 = 88, CW = 14, CH = 12, COLS = 22, ROWS = 11;
    private static final int PX1 = PX0 + COLS * CW, PY1 = PY0 + ROWS * CH;
    private static final int WELL_X = 30, WELL_Y = 62;
    private static final int[] FX = {130, 210, 290};
    private static final int FY = 54;
    private static final int BARN_X = 406, BARN_Y = 56;
    private static final int PARK_X = 404, ROAD_Y = 226;
    private static final int BAR_Y = 123;                       // game pixels: the shop bar

    // ---------- kinds ----------
    private static final int EGG = 0, WOOL = 1, MILK = 2, CAKE = 3, SWEATER = 4, CHEESE = 5, BEARK = 6;
    private static final int HEN = 0, SHEEP = 1, COW = 2;

    private static final int[] VALUE = {10, 30, 65, 40, 105, 190};
    private static final int[] A_PRICE = {100, 250, 500};
    private static final int[] F_PRICE = {250, 400, 600};
    private static final int[] F_TIME = {360, 480, 540};
    private static final int[] PROD = {480, 840, 1200};
    private static final float[] DRAIN = {1 / 1500f, 1 / 1700f, 1 / 1900f};
    private static final float[] BITE = {0.25f, 0.2f, 0.16f};
    private static final float[] SPEED = {0.55f, 0.38f, 0.3f};
    private static final int[] UP_COST = {150, 400};
    private static final int[] WELL_CAP = {4, 6, 9}, WELL_TIME = {150, 105, 75};
    private static final int[] BARN_CAP = {12, 24, 40};
    private static final int[] TRUCK_CAP = {10, 20, 40}, TRUCK_TIME = {720, 480, 300};
    private static final int BOUNTY = 60;

    // ---------- levels ----------
    private static final int LEVELS = 6;
    private static final int[] L_COINS = {350, 700, 1500, 2800, 4500, 7000};
    private static final int[] L_LIMIT = {270, 330, 360, 390, 420, 480};
    private static final int[] L_GOLD = {130, 190, 210, 235, 255, 300};
    private static final int[] L_SILVER = {190, 250, 280, 310, 340, 400};
    private static final int[] L_START = {100, 150, 200, 250, 300, 400};
    private static final int[] L_ANIMALS = {1, 1, 3, 7, 7, 7};
    private static final int[] L_FACT = {0, 1, 3, 7, 7, 7};
    private static final int[] L_BEAR = {0, 0, 0, 0, 3000, 2100};
    private static final int[][] L_NEED = {
            {0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 6, 0, 0, 0},
            {0, 6, 0, 6, 0, 0, 0},
            {0, 0, 5, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 3, 2},
            {0, 0, 0, 8, 5, 5, 3}};
    /** Stars earned in this session (the host does not save anything for the games). */
    private static final int[] BEST = new int[LEVELS];

    private static final int MENU = 0, PLAY = 1, DONE = 2;

    // ---------- things ----------
    private static final class A {
        int kind, look, prod, wait, eat, starve, dir = 1, bubble;
        double x, y, tx, ty;
        float food = 1f;
        boolean moving;
    }

    private static final class Item {
        int kind, life = 1500;
        double x, y, z, vz;
        boolean bounced;
    }

    private static final class Fly {
        int kind, p;
        double sx, sy;
    }

    private static final class P {
        int type, life, max, c;
        double x, y, vx, vy;
        String s;
    }

    private static final class Bear {
        int state, timer, kills;
        double x, y;
        int dir = 1;
    }

    private final List<A> animals = new ArrayList<>();
    private final List<Item> items = new ArrayList<>();
    private final List<Fly> flies = new ArrayList<>();
    private final List<P> parts = new ArrayList<>();
    private final List<Bear> bears = new ArrayList<>();
    private final List<Object> draw = new ArrayList<>();

    private final byte[][] grass = new byte[ROWS][COLS];
    private final int[][] plantT = new int[ROWS][COLS];
    private final int[] stock = new int[6], sold = new int[7], cargo = new int[6];
    private final boolean[] built = new boolean[3];
    private final int[] fT = new int[3], fN = new int[3], fPop = new int[3];

    private int state, level, t, pt, coins, earned, water, wellT, wellLvl, barnLvl, truckLvl;
    private int msgT, tipT, doneT, barnShake, bearT, stars, hoverBtn, wellDip;
    private int truckState, truckT;
    private double truckX = PARK_X;
    private boolean won;
    private String[] tipLines = new String[0];
    private String msg = "";

    private static final A ICON = new A();

    // ---------- helpers ----------
    private static String tr(String key, Object... args) { return Component.translatable(key, args).getString(); }

    private void say(String key, Object... args) { msg = tr(key, args); msgT = 110; }

    private static int clampI(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }

    private static float hashf(int a, int b) { return Gfx.hash(a, b); }

    private int totalStock() {
        int n = 0;
        for (int v : stock) n += v;
        return n + flies.size();
    }

    private boolean hasAnimal(int k) { return (L_ANIMALS[level] & (1 << k)) != 0; }

    private boolean hasFactory(int k) { return (L_FACT[level] & (1 << k)) != 0; }

    // ---------- lifecycle ----------
    @Override
    public void reset() {
        score = 0;
        over = false;
        state = MENU;
        won = false;
        t = 0;
        level = 0;
        clearWorld();
        // a few animals walk around behind the menu
        for (int i = 0; i < 6; i++) addAnimal(i < 3 ? HEN : i < 5 ? SHEEP : COW, true);
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++)
            if (hashf(c, r + 40) < 0.28f) { grass[r][c] = 3; plantT[r][c] = -200; }
    }

    private void clearWorld() {
        animals.clear(); items.clear(); flies.clear(); parts.clear(); bears.clear();
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) { grass[r][c] = 0; plantT[r][c] = -999; }
        java.util.Arrays.fill(stock, 0);
        java.util.Arrays.fill(sold, 0);
        java.util.Arrays.fill(cargo, 0);
        java.util.Arrays.fill(built, false);
        java.util.Arrays.fill(fT, 0);
        java.util.Arrays.fill(fN, 0);
        java.util.Arrays.fill(fPop, 0);
        truckState = 0; truckX = PARK_X; truckT = 0;
        msgT = 0; msg = ""; hoverBtn = -1;
    }

    private void startLevel(int l) {
        level = l;
        clearWorld();
        state = PLAY;
        pt = 0;
        coins = L_START[l];
        earned = 0;
        wellLvl = barnLvl = truckLvl = 0;
        water = WELL_CAP[0];
        wellT = 0;
        stars = 0;
        won = false;
        doneT = 0;
        tipT = 480;
        tipLines = tr("cutemod.ff.tip." + (l + 1)).split("\n");
        bearT = L_BEAR[l] > 0 ? L_BEAR[l] / 2 : 0;
        addAnimal(HEN, false);
        addAnimal(HEN, false);
        beep();
    }

    private void addAnimal(int kind, boolean demo) {
        A a = new A();
        a.kind = kind;
        a.look = rnd.nextInt(3);
        a.x = PX0 + 20 + rnd.nextInt(COLS * CH - 20);
        a.y = PY0 + 14 + rnd.nextInt(ROWS * CH - 26);
        a.tx = a.x; a.ty = a.y;
        a.wait = 10 + rnd.nextInt(60);
        a.food = demo ? 1f : 0.8f;
        a.dir = rnd.nextBoolean() ? 1 : -1;
        a.prod = rnd.nextInt(PROD[kind] / 2);
        animals.add(a);
    }

    private static int col(double x) { return (int) Math.floor((x - PX0) / CW); }

    private static int row(double y) { return (int) Math.floor((y - PY0) / CH); }

    private boolean ready(int c, int r) {
        return c >= 0 && r >= 0 && c < COLS && r < ROWS && grass[r][c] > 0 && t - plantT[r][c] >= 60;
    }

    // ---------- tick ----------
    @Override
    public void tick() {
        t++;
        if (state == MENU) {
            for (A a : animals) { a.food = 1f; a.prod = 0; stepAnimal(a); }
            for (int i = parts.size() - 1; i >= 0; i--) if (!stepPart(parts.get(i))) parts.remove(i);
            return;
        }
        if (state == PLAY) pt++;
        if (msgT > 0) msgT--;
        if (tipT > 0) tipT--;
        if (barnShake > 0) barnShake--;
        if (wellDip > 0) wellDip--;
        if (state == PLAY) {
            if (wellT > 0 && --wellT == 0) {
                water = WELL_CAP[wellLvl];
                sound(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 1.3f, 0.5f);
                for (int i = 0; i < 6; i++) spark(WELL_X, WELL_Y - 6, 0xFF9AD8FF);
            }
            for (int i = animals.size() - 1; i >= 0; i--) {
                A a = animals.get(i);
                if (!updateAnimal(a)) animals.remove(i);
            }
            for (int i = items.size() - 1; i >= 0; i--) {
                Item it = items.get(i);
                stepItem(it);
                if (--it.life <= 0) { puff(it.x, it.y, 3); items.remove(i); }
            }
            updateFlies();
            updateBears();
            updateFactories();
            updateTruck();
            if (L_BEAR[level] > 0 && --bearT <= 0) {
                bearT = L_BEAR[level] + rnd.nextInt(600);
                if (!animals.isEmpty() && bears.size() < 2) spawnBear();
            }
            if (goalMet()) finish(true);
            else if (pt >= L_LIMIT[level] * 60) finish(false);
        } else {
            for (A a : animals) stepAnimal(a);
            doneT++;
            if (doneT > (won ? 150 : 100)) over = true;
        }
        for (int i = parts.size() - 1; i >= 0; i--) if (!stepPart(parts.get(i))) parts.remove(i);
    }

    private boolean goalMet() {
        if (coins < L_COINS[level]) return false;
        for (int k = 0; k < 7; k++) if (sold[k] < L_NEED[level][k]) return false;
        return true;
    }

    private void finish(boolean win) {
        state = DONE;
        won = win;
        flies.clear();
        doneT = 0;
        if (win) {
            int secs = pt / 60;
            stars = secs <= L_GOLD[level] ? 3 : secs <= L_SILVER[level] ? 2 : 1;
            BEST[level] = Math.max(BEST[level], stars);
            score = earned + (stars == 3 ? 300 : stars == 2 ? 150 : 50);
            for (int i = 0; i < 24; i++) spark(110 * 2 + rnd.nextInt(60) - 30, 90 + rnd.nextInt(40), i % 2 == 0 ? 0xFFFFE066 : 0xFFFF9FC8);
        } else {
            score = earned / 2;
        }
    }

    @Override
    public boolean isWin() { return state == DONE && won; }

    @Override
    public Component endTitle() {
        return Component.translatable(won ? "cutemod.ff.win" : "cutemod.ff.lose");
    }

    @Override
    public Component status() {
        if (state == MENU) return Component.translatable("cutemod.ff.pick");
        return Component.translatable("cutemod.ff.status", level + 1, coins);
    }

    @Override
    public String hintKey() { return "cutemod.hint.funnyfarm"; }

    // ---------- animals ----------
    private boolean updateAnimal(A a) {
        a.food -= DRAIN[a.kind];
        if (a.food <= 0) {
            a.food = 0;
            if (++a.starve > 360) {
                ghost(a.x, a.y);
                sound(SoundEvents.VILLAGER_NO, 1.3f, 0.4f);
                say("cutemod.ff.msg.starved");
                return false;
            }
        } else a.starve = 0;
        if (a.food > 0.45f && ++a.prod >= PROD[a.kind]) {
            a.prod = 0;
            Item it = new Item();
            it.kind = a.kind;
            it.x = a.x + a.dir * 7;
            it.y = a.y + 5;
            it.vz = 2.6;
            items.add(it);
            sound(a.kind == HEN ? SoundEvents.CHICKEN_EGG : SoundEvents.SLIME_SQUISH, 1.2f, 0.25f);
        }
        stepAnimal(a);
        return true;
    }

    /** Walking, eating and picking a target; used in the menu too. */
    private void stepAnimal(A a) {
        a.moving = false;
        if (a.eat > 0) {
            int c = col(a.x), r = row(a.y);
            if (ready(c, r)) {
                a.eat++;
                if (a.eat % 36 == 0) {
                    grass[r][c]--;
                    a.food = Math.min(1f, a.food + BITE[a.kind]);
                    if (state != MENU && rnd.nextInt(3) == 0) heart(a.x + a.dir * 4, a.y - 12);
                    if (state != MENU) sound(SoundEvents.GENERIC_EAT, 1.6f + a.kind * 0.0f, 0.12f);
                }
                if (a.food >= 0.98f || grass[r][c] <= 0) { a.eat = 0; a.wait = 18 + rnd.nextInt(40); }
            } else { a.eat = 0; a.wait = 6; }
            return;
        }
        if (a.wait > 0) {
            if (--a.wait == 0) pickTarget(a);
            return;
        }
        double dx = a.tx - a.x, dy = a.ty - a.y, d = Math.sqrt(dx * dx + dy * dy);
        if (d < 2.0) {
            if (ready(col(a.x), row(a.y)) && a.food < 0.9f) a.eat = 1;
            else a.wait = 30 + rnd.nextInt(100);
            return;
        }
        double sp = SPEED[a.kind];
        a.x += dx / d * sp;
        a.y += dy / d * sp * 0.8;
        a.moving = true;
        if (Math.abs(dx) > 1.5) a.dir = dx > 0 ? 1 : -1;
    }

    private void pickTarget(A a) {
        if (a.food < 0.7f) {
            double best = 1e9; int bc = -1, br = -1;
            for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) {
                if (!ready(c, r)) continue;
                double cx = PX0 + c * CW + CW / 2.0, cy = PY0 + r * CH + CH / 2.0;
                double d = Math.abs(cx - a.x) + Math.abs(cy - a.y) * 1.3 + rnd.nextInt(8);
                if (d < best) { best = d; bc = c; br = r; }
            }
            if (bc >= 0) { a.tx = PX0 + bc * CW + CW / 2.0; a.ty = PY0 + br * CH + CH - 3; return; }
        }
        a.tx = clampI((int) (a.x + rnd.nextInt(121) - 60), PX0 + 12, PX1 - 12);
        a.ty = clampI((int) (a.y + rnd.nextInt(61) - 30), PY0 + 14, PY1 - 4);
    }

    // ---------- items ----------
    private void stepItem(Item it) {
        if (it.z > 0 || it.vz > 0) {
            it.z += it.vz;
            it.vz -= 0.3;
            if (it.z <= 0) {
                it.z = 0;
                if (!it.bounced) { it.bounced = true; it.vz = 1.2; } else it.vz = 0;
            }
        }
    }

    private boolean collect(Item it) {
        if (totalStock() >= BARN_CAP[barnLvl]) {
            if (msgT < 60) { say("cutemod.ff.msg.full"); sound(SoundEvents.VILLAGER_NO, 1.5f, 0.4f); }
            barnShake = 20;
            return false;
        }
        items.remove(it);
        Fly f = new Fly();
        f.kind = it.kind; f.sx = it.x; f.sy = it.y - it.z;
        flies.add(f);
        pling(1.2f + rnd.nextFloat() * 0.3f);
        return true;
    }

    private void updateFlies() {
        for (int i = flies.size() - 1; i >= 0; i--) {
            Fly f = flies.get(i);
            if (++f.p >= 24) {
                flies.remove(i);
                stock[f.kind]++;
                barnShake = 6;
                spark(BARN_X, BARN_Y + 10, 0xFFFFE066);
            }
        }
    }

    // ---------- workshops ----------
    private void clickFactory(int i) {
        if (!hasFactory(i)) return;
        if (!built[i]) {
            if (coins < F_PRICE[i]) { say("cutemod.ff.msg.money"); sound(SoundEvents.VILLAGER_NO, 1.5f, 0.4f); return; }
            coins -= F_PRICE[i];
            built[i] = true;
            say("cutemod.ff.msg.built");
            sound(SoundEvents.PLAYER_LEVELUP, 1.4f, 0.4f);
            for (int k = 0; k < 10; k++) { puff(FX[i] + rnd.nextInt(50) - 25, FY + 20, 6); spark(FX[i], FY, 0xFFFFE066); }
            return;
        }
        if (fT[i] > 0) { say("cutemod.ff.msg.busy"); return; }
        int n = Math.min(4, stock[i]);
        if (n <= 0) { say("cutemod.ff.msg.noraw"); sound(SoundEvents.VILLAGER_NO, 1.5f, 0.3f); return; }
        stock[i] -= n;
        fN[i] = n;
        fT[i] = F_TIME[i];
        sound(SoundEvents.WOODEN_DOOR_CLOSE, 1.2f, 0.5f);
    }

    private void updateFactories() {
        for (int i = 0; i < 3; i++) {
            if (fT[i] <= 0) continue;
            if (t % 12 == 0) puffUp(FX[i] + 14, FY - 18);
            if (--fT[i] == 0) {
                for (int k = 0; k < fN[i]; k++) {
                    Item it = new Item();
                    it.kind = 3 + i;
                    it.x = FX[i] - 20 + k * 13;
                    it.y = FY + 38;
                    it.vz = 2.8;
                    items.add(it);
                }
                fN[i] = 0;
                sound(SoundEvents.BELL_BLOCK, 1.6f, 0.4f);
                for (int k = 0; k < 6; k++) spark(FX[i], FY + 20, 0xFFFFFFFF);
            }
        }
    }

    // ---------- truck ----------
    private void clickTruck() {
        if (truckState != 0) { say("cutemod.ff.msg.away"); return; }
        int room = TRUCK_CAP[truckLvl], took = 0;
        for (int k = 5; k >= 0 && room > 0; k--) {          // the most valuable goods go first
            int n = Math.min(room, stock[k]);
            stock[k] -= n; cargo[k] += n; room -= n; took += n;
        }
        if (took == 0) { say("cutemod.ff.msg.empty"); sound(SoundEvents.VILLAGER_NO, 1.5f, 0.3f); return; }
        truckState = 1;
        sound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 0.7f, 0.25f);
    }

    private void updateTruck() {
        switch (truckState) {
            case 1 -> {
                truckX += 3.4;
                if (t % 4 == 0) puff(truckX - 26, ROAD_Y + 14, 3);
                if (truckX > VW + 60) { truckState = 2; truckT = TRUCK_TIME[truckLvl]; }
            }
            case 2 -> { if (--truckT <= 0) { truckState = 3; truckX = VW + 60; } }
            case 3 -> {
                truckX -= 3.4;
                if (t % 4 == 0) puff(truckX + 26, ROAD_Y + 14, 3);
                if (truckX <= PARK_X) {
                    truckX = PARK_X;
                    truckState = 0;
                    int cash = 0;
                    for (int k = 0; k < 6; k++) { cash += cargo[k] * VALUE[k]; sold[k] += cargo[k]; cargo[k] = 0; }
                    coins += cash;
                    earned += cash;
                    pop("+" + cash, PARK_X - 10, ROAD_Y - 10, 0xFFFFE066);
                    for (int k = 0; k < 8; k++) coinBurst(PARK_X, ROAD_Y);
                    sound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0f, 0.6f);
                    sound(SoundEvents.PLAYER_LEVELUP, 1.8f, 0.25f);
                }
            }
            default -> { }
        }
    }

    // ---------- bears ----------
    private void spawnBear() {
        Bear b = new Bear();
        boolean left = rnd.nextBoolean();
        b.x = left ? -24 : VW + 24;
        b.y = PY0 + 20 + rnd.nextInt(ROWS * CH - 40);
        b.dir = left ? 1 : -1;
        bears.add(b);
        say("cutemod.ff.msg.bear");
        sound(SoundEvents.POLAR_BEAR_WARNING, 0.8f, 0.7f);
    }

    private void updateBears() {
        for (int i = bears.size() - 1; i >= 0; i--) {
            Bear b = bears.get(i);
            switch (b.state) {
                case 0 -> {
                    A tg = null; double best = 1e9;
                    for (A a : animals) {
                        double d = Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
                        if (d < best) { best = d; tg = a; }
                    }
                    if (tg == null || b.kills >= 2) { b.state = 3; break; }
                    double dx = tg.x - b.x, dy = tg.y - b.y, d = Math.sqrt(dx * dx + dy * dy);
                    if (d < 16) {
                        animals.remove(tg);
                        ghost(tg.x, tg.y);
                        b.kills++;
                        b.state = 1; b.timer = 80;
                        sound(SoundEvents.PHANTOM_BITE, 0.7f, 0.5f);
                    } else {
                        b.x += dx / d * 0.62; b.y += dy / d * 0.5;
                        if (Math.abs(dx) > 2) b.dir = dx > 0 ? 1 : -1;
                    }
                }
                case 1 -> { if (--b.timer <= 0) b.state = 0; }
                case 2 -> {
                    if (--b.timer <= 0) {
                        coins += BOUNTY; earned += BOUNTY; sold[BEARK]++;
                        pop("+" + BOUNTY, b.x, b.y - 24, 0xFFFFE066);
                        for (int k = 0; k < 6; k++) coinBurst(b.x, b.y);
                        sound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.2f, 0.6f);
                        bears.remove(i);
                    }
                }
                default -> {
                    b.x += (b.x < VW / 2.0 ? -1 : 1) * 0.9;
                    b.dir = b.x < VW / 2.0 ? -1 : 1;
                    if (b.x < -40 || b.x > VW + 40) bears.remove(i);
                }
            }
        }
    }

    // ---------- particles ----------
    private P newPart(int type, double x, double y, int life, int c) {
        P p = new P();
        p.type = type; p.x = x; p.y = y; p.life = p.max = life; p.c = c;
        parts.add(p);
        return p;
    }

    private void puff(double x, double y, int n) {
        for (int i = 0; i < n; i++) {
            P p = newPart(0, x + rnd.nextInt(9) - 4, y + rnd.nextInt(5) - 2, 30 + rnd.nextInt(16), 0xFFFFFFFF);
            p.vx = (rnd.nextFloat() - 0.5) * 0.6; p.vy = -0.2 - rnd.nextFloat() * 0.3;
        }
    }

    private void puffUp(double x, double y) {
        P p = newPart(0, x, y, 50, 0xFFF4F0F8);
        p.vx = 0.15; p.vy = -0.45;
    }

    private void spark(double x, double y, int c) {
        P p = newPart(1, x, y, 24 + rnd.nextInt(14), c);
        p.vx = (rnd.nextFloat() - 0.5) * 2.2; p.vy = -0.4 - rnd.nextFloat() * 1.6;
    }

    private void heart(double x, double y) {
        P p = newPart(5, x, y, 36, 0xFFFF7FA8);
        p.vy = -0.5;
    }

    private void ghost(double x, double y) {
        P p = newPart(4, x, y, 70, 0xFFFFFFFF);
        p.vy = -0.6;
    }

    private void coinBurst(double x, double y) {
        P p = newPart(6, x, y, 40 + rnd.nextInt(10), 0xFFFFD84A);
        p.vx = (rnd.nextFloat() - 0.5) * 3.2; p.vy = -2.2 - rnd.nextFloat() * 1.6;
    }

    private void pop(String s, double x, double y, int c) {
        P p = newPart(3, x, y, 70, c);
        p.s = s; p.vy = -0.6;
    }

    private void drop(double x, double y) {
        P p = newPart(2, x, y, 22 + rnd.nextInt(8), 0xFF7CC8FF);
        p.vx = (rnd.nextFloat() - 0.5) * 2.4; p.vy = -1.2 - rnd.nextFloat() * 1.4;
    }

    private boolean stepPart(P p) {
        p.x += p.vx; p.y += p.vy;
        if (p.type == 1 || p.type == 2 || p.type == 6) p.vy += 0.12;
        return --p.life > 0;
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (state == MENU) {
            for (int i = 0; i < LEVELS; i++) {
                if (in(x, y, cardX(i), cardY(i), CARD_W, CARD_H)) { startLevel(i); return true; }
            }
            return false;
        }
        if (state != PLAY) return false;
        if (y >= BAR_Y) return clickBar(x, y);
        if (in(x, y, 206, 1, 11, 10)) { reset(); return true; }       // the menu button
        if (y < 12) return false;
        int vx = x * 2, vy = y * 2;
        for (Bear b : bears) {
            if (b.state != 2 && Math.abs(vx - b.x) < 20 && vy > b.y - 26 && vy < b.y + 14) {
                b.state = 2; b.timer = 130;
                sound(SoundEvents.GLASS_HIT, 0.7f, 0.7f);
                return true;
            }
        }
        Item best = null; double bd = 15;
        for (Item it : items) {
            double d = Math.hypot(vx - it.x, vy - (it.y - it.z - 2));
            if (d < bd) { bd = d; best = it; }
        }
        if (best != null) {
            // one click gathers the goods lying close to each other as well
            List<Item> near = new ArrayList<>();
            for (Item it : items) if (it == best || Math.hypot(it.x - best.x, it.y - best.y) < 30) near.add(it);
            for (Item it : near) if (!collect(it)) break;
            return true;
        }
        if (in(vx, vy, PARK_X - 34, ROAD_Y - 24, 72, 44) && truckState == 0) { clickTruck(); return true; }
        if (truckState != 0 && in(vx, vy, PARK_X - 34, ROAD_Y - 24, 72, 44)) { clickTruck(); return true; }
        for (int i = 0; i < 3; i++) {
            if (hasFactory(i) && in(vx, vy, FX[i] - 32, FY - 28, 64, 62)) { clickFactory(i); return true; }
        }
        if (in(vx, vy, WELL_X - 24, WELL_Y - 34, 50, 56)) {
            if (water >= WELL_CAP[wellLvl]) { say("cutemod.ff.msg.fullwater"); return true; }
            if (wellT == 0) { wellT = WELL_TIME[wellLvl]; wellDip = WELL_TIME[wellLvl]; sound(SoundEvents.GENERIC_SPLASH, 1.5f, 0.3f); }
            return true;
        }
        if (in(vx, vy, BARN_X - 30, BARN_Y - 34, 62, 62)) { barnShake = 10; return true; }
        if (in(vx, vy, PX0 - 6, PY0 - 6, COLS * CW + 12, ROWS * CH + 10)) {
            if (water <= 0) { say("cutemod.ff.msg.nowater"); sound(SoundEvents.VILLAGER_NO, 1.6f, 0.25f); return true; }
            plant(clampI(col(vx), 0, COLS - 1), clampI(row(vy), 0, ROWS - 1), vx, vy);
            return true;
        }
        return false;
    }

    private void plant(int cc, int cr, int vx, int vy) {
        water--;
        for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
            int c = cc + dc, r = cr + dr;
            if (c < 0 || r < 0 || c >= COLS || r >= ROWS) continue;
            if (grass[r][c] < 3) { grass[r][c] = 3; plantT[r][c] = t + Math.abs(dc) * 6 + Math.abs(dr) * 6; }
        }
        for (int i = 0; i < 7; i++) drop(vx, vy - 8);
        sound(SoundEvents.GENERIC_SPLASH, 1.8f, 0.22f);
    }

    private static final int BTN_W = 33, BTN_H = 15;

    private static int btnX(int i) { return 6 + i * 35; }

    private boolean clickBar(int x, int y) {
        for (int i = 0; i < 6; i++) if (in(x, y, btnX(i), BAR_Y + 1, BTN_W, BTN_H)) { buy(i); return true; }
        return false;
    }

    private void buy(int i) {
        if (i < 3) {
            if (!hasAnimal(i)) return;
            if (coins < A_PRICE[i]) { say("cutemod.ff.msg.money"); sound(SoundEvents.VILLAGER_NO, 1.5f, 0.4f); return; }
            if (animals.size() >= 26) { say("cutemod.ff.msg.crowd"); return; }
            coins -= A_PRICE[i];
            addAnimal(i, false);
            A a = animals.get(animals.size() - 1);
            a.x = PX0 + 10; a.y = PY0 + 60; a.tx = a.x + 20; a.ty = a.y;
            sound(i == HEN ? SoundEvents.CHICKEN_AMBIENT : i == SHEEP ? SoundEvents.SHEEP_AMBIENT : SoundEvents.COW_AMBIENT, 1.2f, 0.5f);
            for (int k = 0; k < 6; k++) spark(a.x, a.y - 6, 0xFFFFE066);
            return;
        }
        int[] lvl = i == 3 ? new int[]{wellLvl} : i == 4 ? new int[]{barnLvl} : new int[]{truckLvl};
        if (lvl[0] >= 2) { say("cutemod.ff.msg.max"); return; }
        int cost = UP_COST[lvl[0]];
        if (coins < cost) { say("cutemod.ff.msg.money"); sound(SoundEvents.VILLAGER_NO, 1.5f, 0.4f); return; }
        coins -= cost;
        if (i == 3) { wellLvl++; water = WELL_CAP[wellLvl]; wellT = 0; }
        else if (i == 4) barnLvl++;
        else truckLvl++;
        say("cutemod.ff.msg.upgraded");
        sound(SoundEvents.PLAYER_LEVELUP, 1.5f, 0.4f);
    }

    @Override
    public boolean key(int keyCode) {
        if (state != PLAY) return false;
        if (keyCode >= 49 && keyCode <= 51) { buy(keyCode - 49); return true; }
        if (keyCode == KEY_SPACE) { clickTruck(); return true; }
        return false;
    }

    // ---------- menu geometry ----------
    private static final int CARD_W = 62, CARD_H = 34;

    private static int cardX(int i) { return 14 + (i % 3) * 66; }

    private static int cardY(int i) { return 46 + (i / 3) * 40; }

    // ====================================================================================================
    //                                              DRAWING
    // ====================================================================================================
    private static final int WOOD = 0xFFB77A45, WOOD_D = 0xFF8A5A33, WOOD_L = 0xFFDDA46A;
    private static final int RED = 0xFFE0564F, GOLD = 0xFFFFD84A, INK = 0xFF4A3322;


    // ---------- cheap shapes: the whole farm is ~9000 rectangles otherwise ----------
    /** An ellipse with as few fills as possible: neighbouring rows of the same width are merged into one rectangle. */
    private static void ell(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        double rr = (ry + 0.5) * (ry + 0.5);
        int start = -ry, prev = 0;
        for (int dy = -ry; dy <= ry + 1; dy++) {
            int dx = dy > ry ? -2 : (int) Math.floor((rx + 0.5) * Math.sqrt(Math.max(0, 1.0 - dy * dy / rr)));
            if (dy == -ry) { prev = dx; continue; }
            if (dx != prev) { g.fill(cx - prev, cy + start, cx + prev + 1, cy + dy, argb); start = dy; prev = dx; }
        }
    }

    private static void dsc(GuiGraphics g, int cx, int cy, int r, int argb) { ell(g, cx, cy, r, r, argb); }

    /** A ball: dark rim, body, one shaded band and a highlight (cheaper than Gfx.ball). */
    private static void ball(GuiGraphics g, int cx, int cy, int r, int argb) {
        dsc(g, cx, cy, r, Gfx.darker(argb, 0.45f));
        dsc(g, cx, cy, r - 1, argb);
        if (r >= 5) g.fill(cx - r + 3, cy + r / 2, cx + r - 3, cy + r - 2, Gfx.alpha(0xFF000000, 28));
        dsc(g, cx - r / 3, cy - r / 3, Math.max(1, r / 3), Gfx.alpha(0xFFFFFFFF, 150));
    }

    /** A faint soft blob in 5 rectangles (for the mottling of the lawn, cloud shadows and glows). */
    private static void soft(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        int a = rx * 6 / 10, b = rx * 9 / 10, y1 = ry * 6 / 10, y2 = Math.max(1, ry * 2 / 10);
        g.fill(cx - a, cy - ry, cx + a, cy - y1, argb);
        g.fill(cx - b, cy - y1, cx + b, cy - y2, argb);
        g.fill(cx - rx, cy - y2, cx + rx, cy + y2, argb);
        g.fill(cx - b, cy + y2, cx + b, cy + y1, argb);
        g.fill(cx - a, cy + y1, cx + a, cy + ry, argb);
    }

    // noise that never changes: worked out once, not 60 times a second
    private static final float[][][] BLADE = new float[ROWS][COLS][18];
    private static final int[] SPK = new int[ROWS * COLS * 4];
    private static final int SPK_N;
    static {
        int n = 0;
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) {
            for (int i = 0; i < 9; i++) { BLADE[r][c][i * 2] = Gfx.hash(c * 31 + i, r + 7); BLADE[r][c][i * 2 + 1] = Gfx.hash(c + 5, r * 13 + i); }
            if (Gfx.hash(c, r + 90) < 0.25f) {
                int x = PX0 + c * CW + (int) (Gfx.hash(c, r + 91) * 10), y = PY0 + r * CH + (int) (Gfx.hash(c, r + 92) * 8) + 2;
                SPK[n++] = x; SPK[n++] = y; SPK[n++] = PX0 + c * CW + 12; SPK[n++] = y + 3;
            }
        }
        SPK_N = n;
    }

    private static void blob(GuiGraphics g, int cx, int cy, int rx, int ry, int c) {
        ell(g, cx, cy, rx + 1, ry + 1, Gfx.darker(c, 0.42f));
        ell(g, cx, cy, rx, ry, c);
        if (rx >= 6 && ry >= 4) ell(g, cx - rx / 3, cy - ry / 2, Math.max(1, rx / 2), Math.max(1, ry / 3), Gfx.alpha(0xFFFFFFFF, 70));
    }

    private static void fluff(GuiGraphics g, int cx, int cy, int[][] parts, int c) {
        int dark = Gfx.darker(c, 0.4f);
        for (int[] p : parts) ell(g, cx + p[0], cy + p[1], p[2] + 1, p[3] + 1, dark);
        for (int[] p : parts) ell(g, cx + p[0], cy + p[1], p[2], p[3], c);
        for (int[] p : parts) if (p[2] >= 8) ell(g, cx + p[0] - p[2] / 3, cy + p[1] - p[3] / 2, Math.max(1, p[2] / 2), Math.max(1, p[3] / 3), Gfx.alpha(0xFFFFFFFF, 90));
    }

    private static void shadow(GuiGraphics g, int cx, int cy, int rx, int ry) {
        ell(g, cx, cy, rx, ry, Gfx.alpha(0xFF2A4A1A, 55));
    }

    private static void coin(GuiGraphics g, int cx, int cy, int r) {
        dsc(g, cx, cy, r, 0xFFB8801A);
        dsc(g, cx, cy, r - 1, GOLD);
        if (r >= 4) {
            dsc(g, cx, cy, r - 3, 0xFFFFE98A);
            g.fill(cx - 1, cy - r + 2, cx + 1, cy + r - 2, 0xFFE8B02A);
            g.fill(cx - r + 1, cy - r + 1, cx - r / 2, cy - r / 2, 0xAAFFFFFF);
        }
    }

    private void bubbleBang(GuiGraphics g, int x, int y, boolean urgent) {
        int c = urgent && (t / 8) % 2 == 0 ? 0xFFFFD0D0 : 0xFFFFFFFF;
        Gfx.rrect(g, x - 6, y - 5, 12, 11, 3, 0xFF8A4A4A);
        Gfx.rrect(g, x - 5, y - 4, 10, 9, 2, c);
        g.fill(x - 1, y + 6, x + 1, y + 8, 0xFF8A4A4A);
        g.fill(x - 1, y - 2, x + 1, y + 2, 0xFFE0443F);
        g.fill(x - 1, y + 3, x + 1, y + 5, 0xFFE0443F);
    }

    // ----- animals -----
    private void drawAnimal(GuiGraphics g, A a) {
        int x = (int) a.x, y = (int) a.y;
        double ph = t * (a.kind == HEN ? 0.55 : 0.35) + a.look * 2.1;
        int bob = a.moving ? (int) Math.round(Math.abs(Math.sin(ph)) * (a.kind == HEN ? 1.6 : 1.0)) : 0;
        int sw = a.moving ? (int) Math.round(Math.sin(ph) * 2) : 0;
        int peck = a.eat > 0 ? (int) Math.round(Math.max(0, Math.sin(t * 0.45 + a.look)) * (a.kind == COW ? 4 : 3)) : 0;
        switch (a.kind) {
            case HEN -> drawHen(g, a, x, y, bob, sw, peck);
            case SHEEP -> drawSheep(g, a, x, y, bob, sw, peck);
            default -> drawCow(g, a, x, y, bob, sw, peck);
        }
        if (a.food < 0.3f) bubbleBang(g, x, y - (a.kind == COW ? 22 : a.kind == SHEEP ? 20 : 20) - ((t / 10) % 2), a.food < 0.12f);
    }

    private void drawHen(GuiGraphics g, A a, int x, int y, int bob, int sw, int peck) {
        int f = a.dir;
        int body = a.look == 1 ? 0xFFE8B070 : a.look == 2 ? 0xFFFFF0D0 : 0xFFFFFDF6;
        int wing = Gfx.darker(body, 0.1f), tail = Gfx.darker(body, 0.16f);
        shadow(g, x, y + 8, 10, 3);
        int legC = 0xFFF0A030;
        g.fill(x - 4 + sw, y + 3, x - 3 + sw, y + 8, legC);
        g.fill(x + 2 - sw, y + 3, x + 3 - sw, y + 8, legC);
        g.fill(x - 4 + sw + (f > 0 ? 0 : -2), y + 8, x - 1 + sw + (f > 0 ? 2 : 0), y + 9, legC);
        g.fill(x + 2 - sw + (f > 0 ? 0 : -2), y + 8, x + 5 - sw + (f > 0 ? 2 : 0), y + 9, legC);
        blob(g, x - f * 8, y - 4 - bob, 3, 5, tail);
        blob(g, x - f * 6, y - 6 - bob, 2, 4, tail);
        blob(g, x, y - bob, 8, 6, body);
        ell(g, x - f, y + 1 - bob, 4, 3, wing);
        ell(g, x - f * 2, y - bob, 2, 1, Gfx.alpha(0xFFFFFFFF, 110));
        int hy = y - 6 - bob + peck;
        blob(g, x + f * 6, hy, 4, 4, body);
        dsc(g, x + f * 6, hy - 5, 2, RED);
        dsc(g, x + f * 4, hy - 4, 1, RED);
        dsc(g, x + f * 8, hy - 4, 1, RED);
        g.fill(f > 0 ? x + f * 10 : x + f * 10 - 3, hy, f > 0 ? x + f * 10 + 3 : x + f * 10, hy + 2, 0xFFFFA83A);
        g.fill(f > 0 ? x + f * 10 : x + f * 10 - 2, hy + 2, f > 0 ? x + f * 10 + 2 : x + f * 10, hy + 3, 0xFFE8892A);
        g.fill(f > 0 ? x + 7 : x - 8, hy - 1, f > 0 ? x + 9 : x - 6, hy + 1, 0xFF2A2030);
        g.fill(f > 0 ? x + 7 : x - 7, hy - 1, f > 0 ? x + 8 : x - 6, hy, 0xFFFFFFFF);
        g.fill(f > 0 ? x + 9 : x - 10, hy + 3, f > 0 ? x + 10 : x - 9, hy + 5, RED);
        g.fill(f > 0 ? x + 4 : x - 6, hy + 1, f > 0 ? x + 6 : x - 4, hy + 2, Gfx.alpha(0xFFFF8FA8, 150));
    }

    private void drawSheep(GuiGraphics g, A a, int x, int y, int bob, int sw, int peck) {
        int f = a.dir;
        int wool = a.look == 1 ? 0xFFF7E8F0 : 0xFFFFFCF4;
        shadow(g, x, y + 9, 13, 3);
        int leg = 0xFF5B4859;
        g.fill(x - 6 + sw, y + 4, x - 3 + sw, y + 9, leg);
        g.fill(x + 3 - sw, y + 4, x + 6 - sw, y + 9, leg);
        // the head is drawn first so that the wool hangs over its back
        int hy = y - 2 - bob + peck;
        blob(g, x + f * 11, hy, 4, 5, 0xFF6A5568);
        blob(g, x + f * 8, hy - 4, 3, 2, 0xFF6A5568);
        g.fill(f > 0 ? x + 11 : x - 14, hy - 1, f > 0 ? x + 14 : x - 11, hy + 1, 0xFF2A2030);
        g.fill(f > 0 ? x + 12 : x - 13, hy - 1, f > 0 ? x + 13 : x - 12, hy, 0xFFFFFFFF);
        g.fill(f > 0 ? x + 9 : x - 12, hy + 2, f > 0 ? x + 11 : x - 10, hy + 3, Gfx.alpha(0xFFFF9FB0, 200));
        fluff(g, x, y - bob, new int[][]{{0, 0, 10, 7}, {-8, -2, 4, 4}, {7, -3, 4, 4}, {-4, -7, 5, 3}, {3, -8, 5, 3}, {0, 5, 6, 3}, {f * 8, -7, 4, 3}}, wool);
    }

    private void drawCow(GuiGraphics g, A a, int x, int y, int bob, int sw, int peck) {
        int f = a.dir;
        shadow(g, x, y + 10, 16, 3);
        int hoof = 0xFF5A4558;
        g.fill(x - 9 + sw, y + 4, x - 6 + sw, y + 10, 0xFFFFFFFF); g.fill(x - 9 + sw, y + 9, x - 6 + sw, y + 11, hoof);
        g.fill(x + 6 - sw, y + 4, x + 9 - sw, y + 10, 0xFFFFFFFF); g.fill(x + 6 - sw, y + 9, x + 9 - sw, y + 11, hoof);
        // tail
        g.fill(f > 0 ? x - 15 : x + 14, y - 5 - bob, f > 0 ? x - 14 : x + 15, y + 3 - bob, 0xFF5A4558);
        dsc(g, f > 0 ? x - 15 : x + 15, y + 4 - bob, 2, 0xFF3F3040);
        blob(g, x, y - bob, 13, 8, 0xFFFFFFFF);
        ell(g, x - 5, y - 3 - bob, 4, 3, 0xFF4F4057);
        ell(g, x + 5, y + 2 - bob, 3, 3, 0xFF4F4057);
        ell(g, x - 1, y + 4 - bob, 2, 2, 0xFF4F4057);
        blob(g, x - f * 2, y + 7 - bob, 3, 2, 0xFFFFA8BE);
        int hy = y - 3 - bob + peck;
        blob(g, x + f * 14, hy, 6, 5, 0xFFFFFFFF);
        g.fill(x + f * 12 - 1, hy - 8, x + f * 12 + 1, hy - 5, 0xFFF2DCA0);
        g.fill(x + f * 16 - 1, hy - 8, x + f * 16 + 1, hy - 5, 0xFFF2DCA0);
        blob(g, x + f * 9, hy - 3, 3, 2, 0xFF4F4057);
        blob(g, x + f * 18, hy + 2, 4, 3, 0xFFFFB6C8);
        g.fill(x + f * 17, hy + 2, x + f * 17 + 1, hy + 3, 0xFFB06A80);
        g.fill(x + f * 19, hy + 2, x + f * 19 + 1, hy + 3, 0xFFB06A80);
        g.fill(f > 0 ? x + 14 : x - 16, hy - 2, f > 0 ? x + 16 : x - 14, hy, 0xFF2A2030);
        g.fill(f > 0 ? x + 14 : x - 15, hy - 2, f > 0 ? x + 15 : x - 14, hy - 1, 0xFFFFFFFF);
    }

    private void drawBear(GuiGraphics g, Bear b) {
        int x = (int) b.x, y = (int) b.y, f = b.dir;
        boolean eating = b.state == 1;
        int sway = b.state == 2 ? 0 : (int) Math.round(Math.sin(t * 0.25) * 1.5);
        int br = 0xFF9A6240, belly = 0xFFC99A6A;
        shadow(g, x, y + 13, 17, 4);
        int cageY = 0;
        blob(g, x - 8 + sway, y + 10, 4, 3, br);
        blob(g, x + 8 - sway, y + 10, 4, 3, br);
        blob(g, x, y - 1, 13, 11, br);
        ell(g, x, y + 2, 7, 6, belly);
        int hy = y - 10 + (eating ? (int) Math.round(Math.sin(t * 0.5) * 2) : 0);
        blob(g, x + f * 3 - 6, hy - 6, 3, 3, br);
        blob(g, x + f * 3 + 6, hy - 6, 3, 3, br);
        dsc(g, x + f * 3 - 6, hy - 6, 1, 0xFFE8A0A0);
        dsc(g, x + f * 3 + 6, hy - 6, 1, 0xFFE8A0A0);
        blob(g, x + f * 3, hy, 9, 7, br);
        blob(g, x + f * 6, hy + 3, 5, 3, belly);
        dsc(g, x + f * 7, hy + 2, 1, 0xFF2A1A20);
        int ey = hy - 2;
        g.fill(x + f * 3 - 5, ey, x + f * 3 - 3, ey + 2, 0xFF2A1A20);
        g.fill(x + f * 3 + 2, ey, x + f * 3 + 4, ey + 2, 0xFF2A1A20);
        Gfx.line(g, x + f * 3 - 6, ey - 2, x + f * 3 - 2, ey - 1, 0xFF3A2218);
        Gfx.line(g, x + f * 3 + 5, ey - 2, x + f * 3 + 1, ey - 1, 0xFF3A2218);
        if (eating) g.fill(x + f * 5, hy + 5, x + f * 5 + 3, hy + 6, 0xFFC0443F);
        if (b.state == 2) {
            double p = Math.min(1.0, (130 - b.timer) / 14.0);
            cageY = (int) Math.round(-(1 - p) * 44);
            int cx0 = x - 20, cx1 = x + 20, top = y - 28 + cageY, bot = y + 14 + cageY;
            for (int bx = cx0; bx <= cx1; bx += 6) g.fill(bx, top, bx + 2, bot, 0xFF6F7690);
            for (int bx = cx0; bx <= cx1; bx += 6) g.fill(bx, top, bx + 1, bot, 0xFFB8C0D8);
            g.fill(cx0 - 2, top - 3, cx1 + 4, top + 1, 0xFF4F566E);
            g.fill(cx0 - 2, bot - 1, cx1 + 4, bot + 2, 0xFF4F566E);
            g.fill(cx0 - 2, top - 3, cx1 + 4, top - 2, 0xFF9AA2BE);
        }
    }

    // ----- items -----
    private void drawItem(GuiGraphics g, int kind, int x, int y) {
        switch (kind) {
            case EGG -> {
                ell(g, x, y, 5, 6, 0xFFB08A60);
                ell(g, x, y, 4, 5, 0xFFFFF6E4);
                ell(g, x + 1, y + 2, 3, 3, Gfx.alpha(0xFFE8C898, 120));
                ell(g, x - 1, y - 2, 1, 2, 0xFFFFFFFF);
            }
            case WOOL -> {
                fluff(g, x, y, new int[][]{{0, 0, 5, 4}, {-4, 1, 3, 3}, {4, 1, 3, 3}, {0, -3, 4, 3}}, 0xFFFBF8FF);
                Gfx.line(g, x - 3, y + 1, x + 3, y - 1, 0xFFE8A8D0);
                Gfx.line(g, x - 2, y + 3, x + 2, y + 1, 0xFFE8A8D0);
            }
            case MILK -> {
                Gfx.rrect(g, x - 5, y - 4, 10, 11, 3, 0xFF7FA6C8);
                Gfx.rrect(g, x - 4, y - 3, 8, 9, 2, 0xFFFFFFFF);
                g.fill(x - 3, y - 6, x + 3, y - 3, 0xFF7FA6C8);
                g.fill(x - 4, y - 8, x + 4, y - 6, RED);
                g.fill(x - 3, y + 1, x + 3, y + 3, 0xFF9AD0F0);
                g.fill(x - 3, y - 2, x - 2, y + 4, 0xAAFFFFFF);
            }
            case CAKE -> {
                ell(g, x, y + 5, 8, 3, 0xFFD8D0E8);
                Gfx.rrect(g, x - 6, y - 2, 12, 8, 2, 0xFF9C5A6C);
                Gfx.rrect(g, x - 5, y - 1, 10, 7, 2, 0xFFF9B4CC);
                Gfx.rrect(g, x - 6, y - 4, 12, 4, 2, 0xFFFFFFFF);
                g.fill(x - 4, y, x - 3, y + 2, 0xFFFFFFFF);
                g.fill(x + 1, y, x + 2, y + 3, 0xFFFFFFFF);
                dsc(g, x, y - 6, 2, 0xFFE0344F);
                g.fill(x, y - 9, x + 1, y - 7, 0xFF5A9A3A);
            }
            case SWEATER -> {
                Gfx.rrect(g, x - 8, y - 3, 16, 5, 2, 0xFF4A74B8);
                Gfx.rrect(g, x - 5, y - 6, 10, 13, 2, 0xFF4A74B8);
                Gfx.rrect(g, x - 4, y - 5, 8, 11, 2, 0xFF86B6F4);
                Gfx.rrect(g, x - 7, y - 2, 14, 3, 1, 0xFF86B6F4);
                g.fill(x - 4, y - 1, x + 4, y, 0xFFFFFFFF);
                g.fill(x - 4, y + 2, x + 4, y + 3, 0xFFFFFFFF);
                g.fill(x - 2, y - 6, x + 2, y - 5, 0xFFFFD0E0);
            }
            default -> {
                int[] xs = {x - 8, x + 8, x + 8, x - 8}, ys = {y - 1, y - 5, y + 5, y + 5};
                Gfx.poly(g, new int[]{x - 9, x + 9, x + 9, x - 9}, new int[]{y - 2, y - 6, y + 6, y + 6}, 0xFFB5811E);
                Gfx.poly(g, xs, ys, 0xFFFFD84A);
                g.fill(x - 8, y - 1, x + 8, y, 0xFFFFE98A);
                dsc(g, x - 3, y + 2, 1, 0xFFE2A82A);
                dsc(g, x + 3, y + 1, 1, 0xFFE2A82A);
                dsc(g, x + 6, y + 3, 1, 0xFFE2A82A);
            }
        }
    }

    /** An item drawn in game pixels (the interface): size is its virtual scale. */
    private void icon(GuiGraphics g, int kind, int gx, int gy, float s) {
        g.pose().pushPose();
        g.pose().translate(gx, gy, 0);
        g.pose().scale(0.5f * s, 0.5f * s, 1f);
        if (kind == BEARK) {
            blob(g, -5, -5, 3, 3, 0xFF9A6240); blob(g, 5, -5, 3, 3, 0xFF9A6240);
            blob(g, 0, 0, 8, 7, 0xFF9A6240); blob(g, 0, 3, 4, 3, 0xFFC99A6A);
            dsc(g, 0, 2, 1, 0xFF2A1A20);
            g.fill(-4, -2, -2, 0, 0xFF2A1A20); g.fill(2, -2, 4, 0, 0xFF2A1A20);
        } else drawItem(g, kind, 0, 0);
        g.pose().popPose();
    }

    private void animalIcon(GuiGraphics g, int kind, int gx, int gy, float s) {
        g.pose().pushPose();
        g.pose().translate(gx, gy, 0);
        g.pose().scale(0.5f * s, 0.5f * s, 1f);
        ICON.kind = kind; ICON.dir = 1; ICON.moving = false; ICON.eat = 0; ICON.food = 1f; ICON.look = 2;
        switch (kind) {
            case HEN -> drawHen(g, ICON, 0, 0, 0, 0, 0);
            case SHEEP -> drawSheep(g, ICON, 0, 0, 0, 0, 0);
            default -> drawCow(g, ICON, 0, 0, 0, 0, 0);
        }
        g.pose().popPose();
    }

    // ----- scenery -----
    private void drawTree(GuiGraphics g, int x, int y, int r, int seed) {
        shadow(g, x + 3, y + 10, r + 3, 4);
        g.fill(x - 3, y, x + 3, y + 11, 0xFF6F4A2A);
        g.fill(x - 3, y, x - 1, y + 11, 0xFF8A5E36);
        ball(g, x - r / 2, y - 2, r * 2 / 3, 0xFF4FB05A);
        ball(g, x + r / 2, y - 3, r * 2 / 3, 0xFF58BC62);
        ball(g, x, y - r / 2 - 2, r - 1, 0xFF66C96E);
        for (int i = 0; i < 4; i++) {
            int ax = x - r / 2 + (int) (hashf(seed, i) * r), ay = y - r / 2 + (int) (hashf(seed, i + 9) * r * 0.9f);
            dsc(g, ax, ay - 2, 1, 0xFFE8505A);
        }
    }

    private void drawBush(GuiGraphics g, int x, int y, int seed) {
        shadow(g, x + 2, y + 5, 11, 3);
        fluff(g, x, y, new int[][]{{0, 0, 8, 5}, {-7, 2, 5, 4}, {7, 2, 5, 4}, {0, -3, 6, 4}}, 0xFF4FAE5A);
        for (int i = 0; i < 3; i++) dsc(g, x - 6 + (int) (hashf(seed, i) * 12), y - 2 + (int) (hashf(seed, i + 5) * 5), 1, i == 1 ? 0xFFFFE066 : 0xFFFF8FB8);
    }

    private void drawFlower(GuiGraphics g, int x, int y, int c) {
        g.fill(x, y + 1, x + 1, y + 5, 0xFF3F9A4A);
        dsc(g, x, y - 1, 1, c);
        g.fill(x - 2, y - 1, x + 3, y, c);
        g.fill(x, y - 3, x + 1, y + 2, c);
        g.fill(x, y - 1, x + 1, y, 0xFFFFF0A0);
    }

    private void drawFence(GuiGraphics g, int x0, int x1, int y, boolean front) {
        g.fill(x0, y + 3, x1, y + 5, WOOD_D);
        g.fill(x0, y + 8, x1, y + 10, WOOD_D);
        g.fill(x0, y + 3, x1, y + 4, WOOD_L);
        g.fill(x0, y + 8, x1, y + 9, WOOD_L);
        for (int x = x0; x <= x1 - 2; x += 14) {
            g.fill(x, y, x + 4, y + 13, WOOD);
            g.fill(x, y, x + 1, y + 13, WOOD_L);
        }
        if (front) g.fill(x0, y + 13, x1, y + 15, Gfx.alpha(0xFF2A4A1A, 40));
    }

    private void drawFenceSide(GuiGraphics g, int x, int y0, int y1) {
        g.fill(x, y0, x + 4, y1, WOOD);
        g.fill(x, y0, x + 1, y1, WOOD_L);
        g.fill(x + 3, y0, x + 4, y1, WOOD_D);
        for (int y = y0; y < y1; y += 24) {
            g.fill(x - 2, y + 4, x + 6, y + 8, WOOD);
            g.fill(x - 2, y + 4, x + 6, y + 5, WOOD_L);
        }
    }

    private void drawWell(GuiGraphics g) {
        int x = WELL_X, y = WELL_Y;
        shadow(g, x, y + 22, 24, 5);
        blob(g, x, y + 8, 17, 11, 0xFFB5AEC4);
        ell(g, x, y + 5, 13, 7, 0xFF5A5470);
        ell(g, x, y + 6, 12, 6, 0xFF4A9AE0);
        ell(g, x - 3, y + 4, 5, 2, Gfx.alpha(0xFFFFFFFF, 90));
        for (int i = 0; i < 6; i++) g.fill(x - 14 + i * 5, y + 12 + (i % 2), x - 12 + i * 5, y + 13 + (i % 2), Gfx.alpha(0xFF6F6890, 120));
        g.fill(x - 17, y - 26, x - 14, y + 8, WOOD_D);
        g.fill(x + 14, y - 26, x + 17, y + 8, WOOD_D);
        g.fill(x - 17, y - 26, x - 16, y + 8, WOOD);
        g.fill(x + 14, y - 26, x + 15, y + 8, WOOD);
        // roof
        Gfx.poly(g, new int[]{x - 24, x, x + 24}, new int[]{y - 20, y - 38, y - 20}, 0xFF7A3F32);
        Gfx.poly(g, new int[]{x - 21, x, x + 21}, new int[]{y - 21, y - 36, y - 21}, 0xFFE0705A);
        for (int i = 0; i < 4; i++) g.fill(x - 18 + i * 3, y - 26 + i * 0, x - 17 + i * 3, y - 22, Gfx.alpha(0xFFA03F32, 140));
        g.fill(x - 22, y - 21, x + 23, y - 19, 0xFF7A3F32);
        // rope and bucket
        boolean busy = wellT > 0;
        int dip = busy ? (int) Math.round(Math.sin(wellT * 0.12) * 6) : 0;
        int by = y - 12 + (busy ? 12 + dip : 0);
        g.fill(x, y - 20, x + 1, by, 0xFFC8B088);
        Gfx.rrect(g, x - 5, by, 10, 8, 2, 0xFF6F4A2A);
        Gfx.rrect(g, x - 4, by + 1, 8, 6, 1, WOOD);
        g.fill(x - 4, by + 3, x + 4, by + 4, 0xFF9AA0B0);
        // droplets: the water that is left
        int cap = WELL_CAP[wellLvl];
        int step = Math.min(8, 52 / cap);
        int sx = x - (cap * step) / 2 + step / 2;
        for (int i = 0; i < cap; i++) {
            int dx = sx + i * step;
            boolean full = i < water;
            int c = full ? 0xFF4AA8F0 : 0xFFB8C4D8;
            dsc(g, dx, y + 33, 2, c);
            Gfx.poly(g, new int[]{dx - 2, dx, dx + 2}, new int[]{y + 32, y + 28, y + 32}, c);
            if (full) g.fill(dx - 1, y + 32, dx, y + 33, 0xCCFFFFFF);
        }
        if (wellT > 0) {
            int w = 40, p = (int) (w * (1 - wellT / (float) WELL_TIME[wellLvl]));
            Gfx.rrect(g, x - 20, y + 38, w, 4, 2, 0xFF5A6A8A);
            Gfx.rrect(g, x - 20, y + 38, Math.max(2, p), 4, 2, 0xFF7CD0FF);
        }
    }

    private void drawBarn(GuiGraphics g) {
        int shake = barnShake > 0 ? (int) Math.round(Math.sin(barnShake * 1.6) * 2) : 0;
        int x = BARN_X + shake, y = BARN_Y;
        shadow(g, x, y + 32, 34, 6);
        // body
        Gfx.rrect(g, x - 28, y - 8, 56, 40, 3, 0xFF8F2F34);
        Gfx.rrect(g, x - 27, y - 7, 54, 38, 3, 0xFFD9504F);
        for (int i = -24; i < 26; i += 6) g.fill(x + i, y - 6, x + i + 1, y + 30, Gfx.alpha(0xFF8F2F34, 90));
        // roof
        Gfx.poly(g, new int[]{x - 34, x - 22, x, x + 22, x + 34}, new int[]{y - 8, y - 26, y - 34, y - 26, y - 8}, 0xFF5E3A2A);
        Gfx.poly(g, new int[]{x - 31, x - 20, x, x + 20, x + 31}, new int[]{y - 9, y - 25, y - 32, y - 25, y - 9}, 0xFFA8694A);
        for (int i = 0; i < 4; i++) g.fill(x - 28 + i * 2, y - 10 - i * 3, x + 28 - i * 2, y - 9 - i * 3, Gfx.alpha(0xFF5E3A2A, 130));
        // hay window
        Gfx.rrect(g, x - 7, y - 24, 14, 10, 2, 0xFFFFFFFF);
        Gfx.rrect(g, x - 6, y - 23, 12, 8, 1, 0xFFE8C860);
        g.fill(x - 5, y - 20, x + 5, y - 19, 0xFFC8A040);
        // doors
        Gfx.rrect(g, x - 15, y + 6, 30, 26, 2, 0xFFFFFFFF);
        Gfx.rrect(g, x - 14, y + 7, 28, 24, 1, 0xFFC03F44);
        Gfx.line(g, x - 14, y + 7, x + 13, y + 30, 0xFFFFFFFF);
        Gfx.line(g, x + 13, y + 7, x - 14, y + 30, 0xFFFFFFFF);
        g.fill(x - 1, y + 7, x + 1, y + 31, 0xFFFFFFFF);
        g.fill(x - 28, y + 28, x + 28, y + 32, 0xFFB93F40);
        // full barn gets a little "!"
        if (totalStock() >= BARN_CAP[barnLvl]) bubbleBang(g, x + 24, y - 30, true);
    }

    private void drawFactory(GuiGraphics g, int i) {
        int x = FX[i], y = FY;
        if (!hasFactory(i)) { drawBush(g, x - 10, y + 12, 30 + i); drawBush(g, x + 14, y + 20, 36 + i); return; }
        shadow(g, x, y + 32, 34, 5);
        if (!built[i]) {
            // a building plot with a "for sale" sign
            Gfx.rrect(g, x - 30, y + 2, 60, 32, 4, Gfx.alpha(0xFF6F4A2A, 90));
            for (int k = -28; k < 28; k += 8) { g.fill(x + k, y + 3, x + k + 4, y + 4, 0xFFC8A070); g.fill(x + k, y + 32, x + k + 4, y + 33, 0xFFC8A070); }
            for (int k = 6; k < 32; k += 8) { g.fill(x - 30, y + k, x - 29, y + k + 4, 0xFFC8A070); g.fill(x + 29, y + k, x + 30, y + k + 4, 0xFFC8A070); }
            g.fill(x - 14, y - 10, x - 12, y + 24, WOOD_D);
            Gfx.rrect(g, x - 26, y - 14, 28, 14, 2, WOOD_D);
            Gfx.rrect(g, x - 25, y - 13, 26, 12, 2, 0xFFFFE9B0);
            dsc(g, x - 18, y - 7, 3, GOLD);
            int bob = coins >= F_PRICE[i] ? (int) Math.round(Math.sin(t * 0.15) * 2) : 0;
            // a little hammer
            g.fill(x + 8, y + 8 + bob, x + 10, y + 22 + bob, WOOD);
            Gfx.rrect(g, x + 3, y + 5 + bob, 12, 6, 2, 0xFF8890A8);
            return;
        }
        boolean work = fT[i] > 0;
        int wall = i == 0 ? 0xFFFFE6D6 : i == 1 ? 0xFFE0D8FA : 0xFFDDF1FA;
        int roof = i == 0 ? 0xFFF07BA0 : i == 1 ? 0xFF7C6CD6 : 0xFF3FA6B6;
        int roofD = Gfx.darker(roof, 0.35f);
        // chimney
        g.fill(x + 12, y - 22, x + 20, y - 4, 0xFF9A6A58);
        g.fill(x + 11, y - 24, x + 21, y - 21, 0xFF7A5040);
        Gfx.rrect(g, x - 28, y - 4, 56, 36, 3, Gfx.darker(wall, 0.35f));
        Gfx.rrect(g, x - 27, y - 3, 54, 34, 3, wall);
        Gfx.poly(g, new int[]{x - 34, x - 20, x + 20, x + 34}, new int[]{y - 2, y - 20, y - 20, y - 2}, roofD);
        Gfx.poly(g, new int[]{x - 31, x - 19, x + 19, x + 31}, new int[]{y - 3, y - 19, y - 19, y - 3}, roof);
        g.fill(x - 30, y - 4, x + 30, y - 2, roofD);
        for (int k = 0; k < 4; k++) g.fill(x - 26 + k * 2, y - 8 - k * 4, x + 26 - k * 2, y - 7 - k * 4, Gfx.alpha(roofD, 110));
        // awning
        for (int k = 0; k < 8; k++) g.fill(x - 24 + k * 6, y + 3, x - 18 + k * 6, y + 9, k % 2 == 0 ? 0xFFFFFFFF : roof);
        g.fill(x - 24, y + 9, x + 24, y + 10, Gfx.alpha(0xFF000000, 40));
        // door and window
        Gfx.rrect(g, x - 20, y + 12, 12, 20, 2, 0xFF7A5238);
        Gfx.rrect(g, x - 19, y + 13, 10, 19, 2, 0xFFB07A50);
        dsc(g, x - 11, y + 23, 1, GOLD);
        Gfx.rrect(g, x - 2, y + 12, 22, 14, 2, 0xFF6F8AA8);
        Gfx.rrect(g, x - 1, y + 13, 20, 12, 1, work ? 0xFFFFF0A0 : 0xFFBEE4FA);
        g.fill(x + 8, y + 13, x + 9, y + 25, 0xFFFFFFFF);
        g.fill(x - 1, y + 19, x + 19, y + 20, 0xFFFFFFFF);
        // the sign: what it makes
        Gfx.rrect(g, x - 8, y - 14, 16, 14, 3, 0xFFFFFFFF);
        icon(g, 3 + i, (x * 1) / 2, (y - 7) / 2, 0.85f);
        if (work) {
            int w = 48, p = (int) (w * (1 - fT[i] / (float) F_TIME[i]));
            Gfx.rrect(g, x - 24, y + 34, w, 4, 2, 0xFF5A6A8A);
            Gfx.rrect(g, x - 24, y + 34, Math.max(2, p), 4, 2, i == 0 ? 0xFFFF8FB8 : i == 1 ? 0xFFA896F8 : 0xFF7CD0E8);
            // a wheel or a churn works at the side
            double ang = t * 0.2;
            dsc(g, x + 24, y + 22, 5, 0xFFC8A070);
            for (int k = 0; k < 4; k++) Gfx.line(g, x + 24, y + 22, x + 24 + (int) Math.round(Math.cos(ang + k * Math.PI / 2) * 5), y + 22 + (int) Math.round(Math.sin(ang + k * Math.PI / 2) * 5), 0xFF7A5238);
        }
    }

    private void drawTruck(GuiGraphics g) {
        int x = (int) truckX, y = ROAD_Y;
        if (truckState == 2) return;
        int bob = truckState == 0 ? 0 : (int) Math.round(Math.sin(t * 0.7));
        shadow(g, x, y + 16, 28, 4);
        double spin = t * (truckState == 0 ? 0 : 0.6) * (truckState == 3 ? -1 : 1);
        int dir = truckState == 3 ? -1 : 1;            // the truck faces the way it drives (right when it leaves)
        int fx = dir;
        // cargo box
        Gfx.rrect(g, x - fx * 26 + (fx > 0 ? 0 : -8), y - 18 + bob, 34, 24, 3, 0xFF2F8A86);
        Gfx.rrect(g, x - fx * 26 + 1 + (fx > 0 ? 0 : -8), y - 17 + bob, 32, 22, 3, 0xFF4FC4BC);
        int bx = x - fx * 26 + (fx > 0 ? 0 : -8);
        g.fill(bx + 3, y - 14 + bob, bx + 31, y - 13 + bob, Gfx.alpha(0xFFFFFFFF, 120));
        // goods peek out when it is loaded
        if (truckState != 0 || true) {
            int shown = 0;
            for (int k = 0; k < 6; k++) if (cargo[k] > 0 && shown < 3) { drawItem(g, k, bx + 8 + shown * 10, y - 6 + bob); shown++; }
        }
        // cab
        int cx = x + fx * 14 - (fx > 0 ? 0 : 14);
        Gfx.rrect(g, cx, y - 12 + bob, 16, 18, 3, 0xFF9C3A3A);
        Gfx.rrect(g, cx + 1, y - 11 + bob, 14, 17, 3, 0xFFF06A62);
        Gfx.rrect(g, fx > 0 ? cx + 7 : cx + 2, y - 9 + bob, 7, 7, 2, 0xFFCDEBFF);
        g.fill(fx > 0 ? cx + 8 : cx + 3, y - 8 + bob, fx > 0 ? cx + 9 : cx + 4, y - 4 + bob, 0xAAFFFFFF);
        g.fill(fx > 0 ? cx + 15 : cx, y + 1 + bob, fx > 0 ? cx + 17 : cx + 2, y + 4 + bob, 0xFFFFE066);
        // wheels
        for (int w = 0; w < 2; w++) {
            int wx = w == 0 ? x - 12 : x + 14;
            dsc(g, wx, y + 8, 6, 0xFF3A3040);
            dsc(g, wx, y + 8, 3, 0xFFC8CCD8);
            Gfx.line(g, wx, y + 8, wx + (int) Math.round(Math.cos(spin) * 3), y + 8 + (int) Math.round(Math.sin(spin) * 3), 0xFF6F7690);
        }
    }

    // ----- grass -----
    private void drawTuft(GuiGraphics g, int c, int r) {
        int bites = grass[r][c];
        if (bites <= 0) return;
        float grow = Math.max(0f, Math.min(1f, (t - plantT[r][c]) / 60f));
        if (grow <= 0f) return;
        int cx = PX0 + c * CW + CW / 2, by = PY0 + r * CH + CH - 1;
        int n = 3 + bites * 2;
        for (int i = 0; i < n; i++) {
            float h1 = BLADE[r][c][i * 2], h2 = BLADE[r][c][i * 2 + 1];
            int bx = cx + Math.round((i - (n - 1) / 2f) * 2.2f + (h1 - 0.5f) * 2f);
            int h = Math.max(2, Math.round((3 + bites * 2 + h2 * 3) * grow));
            int col = i % 3 == 0 ? 0xFF3DA84E : i % 3 == 1 ? 0xFF58C264 : 0xFF2F9444;
            g.fill(bx, by - h, bx + 1 + (i & 1), by + 1, col);
            g.fill(bx, by - h, bx + 1, by - h + 1, 0xFF9CEA84);
        }
        if (bites == 3 && grow >= 1f && (c * 7 + r * 3) % 5 == 0) {
            g.fill(cx + 3, by - 8, cx + 6, by - 7, 0xFFFF9FC8);
            g.fill(cx + 4, by - 9, cx + 5, by - 6, 0xFFFF9FC8);
            g.fill(cx + 4, by - 8, cx + 5, by - 7, 0xFFFFF0A0);
        }
    }

    // ====================================================================================================
    @Override
    public void render(GuiGraphics g) {
        if (state == MENU) { renderWorld(g); renderMenu(g); return; }
        renderWorld(g);
        renderHud(g);
    }

    private void renderWorld(GuiGraphics g) {
        g.pose().pushPose();
        g.pose().scale(0.5f, 0.5f, 1f);
        // lawn
        g.fillGradient(0, 0, VW, VH, 0xFF9AD878, 0xFF7EC466);
        for (int i = 0; i < 40; i++) {
            int x = (int) (hashf(i, 1) * VW), y = (int) (hashf(i, 2) * VH), rx = 14 + (int) (hashf(i, 3) * 26);
            soft(g, x, y, rx, rx / 3, i % 2 == 0 ? Gfx.alpha(0xFFB6EC8E, 60) : Gfx.alpha(0xFF5FAE5A, 50));
        }
        for (int i = 0; i < 34; i++) {
            int x = (int) (hashf(i, 11) * VW), y = 30 + (int) (hashf(i, 12) * (VH - 60));
            if (x > PX0 - 8 && x < PX1 + 6 && y > PY0 - 10 && y < PY1 + 14) continue;
            if (y < 90 && x > 80 && x < 340) continue;
            if (y > 190 && x > 350) continue;
            int[] pc = {0xFFFFFFFF, 0xFFFF8FB8, 0xFFFFE066, 0xFFB9A0FF};
            drawFlower(g, x, y, pc[i & 3]);
        }
        // road
        g.fill(0, ROAD_Y + 2, VW, ROAD_Y + 20, 0xFFC9A87C);
        g.fill(0, ROAD_Y + 2, VW, ROAD_Y + 4, 0xFFE2C89C);
        g.fill(0, ROAD_Y + 18, VW, ROAD_Y + 20, 0xFFAE8C62);
        for (int x = 0; x < VW; x += 26) g.fill(x, ROAD_Y + 11, x + 12, ROAD_Y + 12, Gfx.alpha(0xFFFFF0C8, 160));
        for (int i = 0; i < 26; i++) g.fill((int) (hashf(i, 21) * VW), ROAD_Y + 5 + (int) (hashf(i, 22) * 11), (int) (hashf(i, 21) * VW) + 2, ROAD_Y + 6 + (int) (hashf(i, 22) * 11), 0xFFB89868);
        // decor
        drawTree(g, 22, 126, 13, 1);
        drawTree(g, 40, 176, 12, 2);
        drawTree(g, 20, 208, 11, 3);
        drawTree(g, 80, 44, 11, 4);
        drawTree(g, 352, 50, 11, 5);
        drawTree(g, 424, 168, 12, 6);
        drawBush(g, 52, 100, 7);
        drawBush(g, 392, 120, 8);
        drawBush(g, 384, 196, 9);
        // pasture
        Gfx.rrect(g, PX0 - 4, PY0 - 4, COLS * CW + 8, ROWS * CH + 8, 5, 0xFFB9A26A);
        Gfx.rrect(g, PX0 - 2, PY0 - 2, COLS * CW + 4, ROWS * CH + 4, 4, 0xFFD8D690);
        for (int r = 0; r < ROWS; r += 2) g.fill(PX0, PY0 + r * CH, PX1, PY0 + r * CH + CH, Gfx.alpha(0xFFFFFFFF, 16));
        for (int i = 0; i < SPK_N; i += 4) g.fill(SPK[i], SPK[i + 1], SPK[i + 2], SPK[i + 3], Gfx.alpha(0xFFB8B070, 90));
        drawFence(g, PX0 - 8, PX1 + 8, PY0 - 16, false);
        drawFenceSide(g, PX0 - 8, PY0 - 4, PY1 + 2);
        drawFenceSide(g, PX1 + 4, PY0 - 4, PY1 + 2);
        // buildings
        drawWell(g);
        for (int i = 0; i < 3; i++) drawFactory(g, i);
        drawBarn(g);
        // grass
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) drawTuft(g, c, r);
        // soak ring where grass has just been planted
        // depth sorted: animals, bears, items
        draw.clear();
        draw.addAll(animals); draw.addAll(bears); draw.addAll(items);
        draw.sort((p, q) -> Double.compare(depth(p), depth(q)));
        for (Object o : draw) {
            if (o instanceof A a) drawAnimal(g, a);
            else if (o instanceof Bear b) drawBear(g, b);
            else if (o instanceof Item it) drawGroundItem(g, it);
        }
        drawFence(g, PX0 - 8, PX1 + 8, PY1 - 3, true);
        drawTruck(g);
        for (Fly f : flies) {
            double p = f.p / 24.0, e = p * p * (3 - 2 * p);
            double x = f.sx + (BARN_X - f.sx) * e, y = f.sy + (BARN_Y + 12 - f.sy) * e - Math.sin(p * Math.PI) * 30;
            drawItem(g, f.kind, (int) x, (int) y);
        }
        for (P p : parts) drawPart(g, p);
        // soft cloud shadows and butterflies
        for (int i = 0; i < 2; i++) {
            double cx = ((t * (0.12 + i * 0.05) + i * 260) % (VW + 200)) - 100;
            soft(g, (int) cx, 80 + i * 110, 70, 26, Gfx.alpha(0xFF1F4A2A, 16));
        }
        for (int i = 0; i < 3; i++) {
            double bx = 120 + i * 110 + Math.sin(t * 0.017 + i * 2) * 60, by = 110 + i * 40 + Math.sin(t * 0.04 + i) * 14;
            int flap = (int) Math.round(Math.abs(Math.sin(t * 0.35 + i)) * 3);
            int bc = i == 0 ? 0xFFFFA0C8 : i == 1 ? 0xFFA0C8FF : 0xFFFFE070;
            ell(g, (int) bx - 2, (int) by - 1, 1 + flap, 2, bc);
            ell(g, (int) bx + 2, (int) by - 1, 1 + flap, 2, bc);
            g.fill((int) bx, (int) by - 2, (int) bx + 1, (int) by + 2, 0xFF4A3A4A);
        }
        g.pose().popPose();
    }

    private static double depth(Object o) {
        if (o instanceof A a) return a.y;
        if (o instanceof Bear b) return b.y + 6;
        if (o instanceof Item i) return i.y - 3;
        return 0;
    }

    private void drawGroundItem(GuiGraphics g, Item it) {
        if (it.life < 240 && (it.life / 6) % 2 == 0) return;                   // blinks before it is gone
        int x = (int) it.x, y = (int) it.y - (int) it.z - 3;
        ell(g, x, (int) it.y + 3, 6, 2, Gfx.alpha(0xFF2A4A1A, 60));
        soft(g, x, y, 10, 8, Gfx.alpha(0xFFFFF4B0, 55));
        drawItem(g, it.kind, x, y);
        if (it.z <= 0 && ((t / 5 + (int) it.x) & 7) == 0) Gfx.sparkle(g, x + 5, y - 6, 2, t, 0xFFFFFFFF);
    }

    private void drawPart(GuiGraphics g, P p) {
        float k = p.life / (float) p.max;
        int x = (int) p.x, y = (int) p.y;
        switch (p.type) {
            case 0 -> dsc(g, x, y, 2 + Math.round((1 - k) * 5), Gfx.alpha(p.c, Math.round(110 * k)));
            case 1 -> Gfx.star(g, x, y, k > 0.5f ? 2 : 1, Gfx.alpha(p.c, Math.round(255 * Math.min(1f, k * 1.6f))));
            case 2 -> { dsc(g, x, y, 1, Gfx.alpha(p.c, Math.round(255 * k))); g.fill(x, y - 2, x + 1, y, Gfx.alpha(0xFFFFFFFF, Math.round(200 * k))); }
            case 4 -> {
                int a = Math.round(220 * Math.min(1f, k * 1.5f));
                int wob = (int) Math.round(Math.sin(p.life * 0.2) * 2);
                ell(g, x + wob, y - 4, 5, 6, Gfx.alpha(0xFFFFFFFF, a));
                g.fill(x + wob - 5, y - 4, x + wob + 6, y + 3, Gfx.alpha(0xFFFFFFFF, a));
                g.fill(x + wob - 3, y - 6, x + wob - 1, y - 4, Gfx.alpha(0xFF3A3050, a));
                g.fill(x + wob + 2, y - 6, x + wob + 4, y - 4, Gfx.alpha(0xFF3A3050, a));
                ell(g, x + wob, y - 13, 5, 2, Gfx.alpha(GOLD, a));
                ell(g, x + wob, y - 13, 3, 1, Gfx.alpha(0xFF9AD878, 0));
            }
            case 5 -> Gfx.heart(g, x - 3, y - 3, Gfx.alpha(p.c, Math.round(255 * Math.min(1f, k * 1.8f))));
            case 6 -> { int w = Math.abs((int) Math.round(Math.cos(p.life * 0.5) * 3)) + 1; ell(g, x, y, w, 3, Gfx.alpha(GOLD, Math.round(255 * Math.min(1f, k * 2f)))); }
            default -> { }
        }
    }

    // ====================================================================================================
    //                                        interface (game pixels)
    // ====================================================================================================
    private static void stext(GuiGraphics g, String s, int x, int y, int c) {
        text(g, s, x + 1, y + 1, 0xAA2A1A10);
        text(g, s, x, y, c);
    }

    private static void sctext(GuiGraphics g, String s, int cx, int y, int maxW, int c) {
        ctextW(g, s, cx + 1, y + 1, maxW, 0xAA2A1A10);
        ctextW(g, s, cx, y, maxW, c);
    }

    private static String clock(int secs) {
        secs = Math.max(0, secs);
        return (secs / 60) + ":" + (secs % 60 < 10 ? "0" : "") + (secs % 60);
    }

    private void renderHud(GuiGraphics g) {
        // top bar
        g.fillGradient(0, 0, W, 12, 0xFF9A6A40, 0xFF7A4E2E);
        g.fill(0, 0, W, 1, 0x66FFFFFF);
        g.fill(0, 12, W, 13, 0x55000000);
        // time bar
        int lim = L_LIMIT[level] * 60;
        float used = Math.min(1f, pt / (float) lim);
        g.fill(0, 13, W, 15, 0x66000000);
        int secs = pt / 60;
        int medal = secs <= L_GOLD[level] ? 0xFFFFD84A : secs <= L_SILVER[level] ? 0xFFD8DCEC : 0xFFE0955A;
        g.fill(0, 13, Math.round(W * used), 15, medal);
        g.fill(Math.round(W * L_GOLD[level] / (float) L_LIMIT[level]), 13, Math.round(W * L_GOLD[level] / (float) L_LIMIT[level]) + 1, 15, 0xFFFFFFFF);
        g.fill(Math.round(W * L_SILVER[level] / (float) L_LIMIT[level]), 13, Math.round(W * L_SILVER[level] / (float) L_LIMIT[level]) + 1, 15, 0xFFFFFFFF);
        // coins and goal
        coin(g, 7, 6, 4);
        String cs = String.valueOf(coins);
        boolean metMoney = coins >= L_COINS[level];
        stext(g, cs, 13, 2, metMoney ? 0xFFA8FFB0 : 0xFFFFFFFF);
        int x = 13 + tw(cs) + 1;
        stext(g, "/" + L_COINS[level], x, 2, 0xFFFFE9A8);
        x += tw("/" + L_COINS[level]) + 6;
        for (int k = 0; k < 7; k++) {
            int need = L_NEED[level][k];
            if (need <= 0) continue;
            icon(g, k, x + 3, 6, 0.8f);
            String s = Math.min(sold[k], need) + "/" + need;
            stext(g, s, x + 8, 2, sold[k] >= need ? 0xFFA8FFB0 : 0xFFFFFFFF);
            x += 9 + tw(s) + 4;
        }
        // clock and menu button
        String tm = clock(L_LIMIT[level] - secs);
        stext(g, tm, 186 - tw(tm), 2, L_LIMIT[level] - secs < 30 && (t / 15) % 2 == 0 ? 0xFFFF8F8F : 0xFFFFFFFF);
        dsc(g, 192, 6, 3, 0xFF8A5A20);
        dsc(g, 192, 6, 2, medal);
        Gfx.bubble(g, 206, 1, 11, 10, 2, 0xFFE87A70);
        g.fill(209, 4, 210, 5, 0xFFFFFFFF); g.fill(210, 5, 211, 6, 0xFFFFFFFF); g.fill(211, 6, 212, 7, 0xFFFFFFFF);
        g.fill(213, 4, 214, 5, 0xFFFFFFFF); g.fill(212, 5, 213, 6, 0xFFFFFFFF); g.fill(210, 7, 211, 8, 0xFFFFFFFF); g.fill(209, 8, 210, 9, 0xFFFFFFFF); g.fill(213, 8, 214, 9, 0xFFFFFFFF);
        g.fill(211, 6, 212, 7, 0xFFFFFFFF); g.fill(212, 7, 213, 8, 0xFFFFFFFF);

        // pop-ups of coins
        for (P p : parts) if (p.type == 3) {
            int a = Math.round(255 * Math.min(1f, p.life / (float) p.max * 2f));
            if (a > 40) stext(g, p.s, (int) p.x / 2 - tw(p.s) / 2, (int) p.y / 2, Gfx.alpha(p.c, a));
        }
        // workshop prices and truck timer
        for (int i = 0; i < 3; i++) {
            if (!hasFactory(i) || built[i]) continue;
            String s = String.valueOf(F_PRICE[i]);
            stext(g, s, FX[i] / 2 - 12 + (13 - tw(s) / 2), (FY - 12) / 2, coins >= F_PRICE[i] ? 0xFFFFFFFF : 0xFFFFC8C0);
        }
        if (truckState == 2) {
            String s = ((truckT + 59) / 60) + "s";
            Gfx.rrect(g, PARK_X / 2 - 14, ROAD_Y / 2 - 4, 28, 12, 3, 0xAA2A1A10);
            sctext(g, s, PARK_X / 2, ROAD_Y / 2 - 2, 26, 0xFFFFFFFF);
        }
        // stock board next to the barn
        int bx = 186, by = 46;
        int rawRows = 0, prodRows = 0;
        for (int k = 0; k < 3; k++) { if (hasAnimal(k)) rawRows++; if (hasFactory(k)) prodRows++; }
        int rows = Math.max(1, Math.max(rawRows, prodRows));
        Gfx.panel(g, bx, by, 33, 11 + rows * 7 + 1, 0xFFC8935A, 0xFFA8733F);
        String cap = (totalStock()) + "/" + BARN_CAP[barnLvl];
        sctext(g, cap, bx + 17, by + 1, 30, totalStock() >= BARN_CAP[barnLvl] ? 0xFFFFB0A8 : 0xFFFFFFFF);
        for (int k = 0; k < 6; k++) {
            boolean avail = k < 3 ? hasAnimal(k) : hasFactory(k - 3);
            if (!avail) continue;
            int row = 0;
            for (int q = (k / 3) * 3; q < k; q++) if (q < 3 ? hasAnimal(q) : hasFactory(q - 3)) row++;
            int cx = bx + 3 + (k / 3) * 15, cy = by + 11 + row * 7;
            icon(g, k, cx + 3, cy + 3, 0.75f);
            stext(g, String.valueOf(stock[k]), cx + 8, cy - 1, stock[k] > 0 ? 0xFFFFFFFF : 0xFFE0C8A8);
        }
        renderBar(g);
        // messages
        if (tipT > 0 && state == PLAY) {
            String[] ls = tipLines;
            int h = ls.length * 9 + 4;
            float al = Math.min(1f, tipT / 40f);
            Gfx.rrect(g, 20, 18, 180, h, 4, Gfx.alpha(0xFF2A1A10, Math.round(170 * al)));
            for (int i = 0; i < ls.length; i++) sctext(g, ls[i], 110, 20 + i * 9, 172, Gfx.alpha(0xFFFFF4D0, Math.round(255 * al)));
        }
        if (msgT > 0) {
            int w = Math.min(190, tw(msg) + 12);
            Gfx.rrect(g, 110 - w / 2, 110, w, 11, 4, Gfx.alpha(0xFF2A1A10, Math.min(200, msgT * 6)));
            sctext(g, msg, 110, 112, 186, Gfx.alpha(0xFFFFFFFF, Math.min(255, msgT * 8)));
        }
        if (state == DONE && !over) renderBanner(g);
    }

    private void renderBar(GuiGraphics g) {
        g.fillGradient(0, BAR_Y - 1, W, H, 0xFFA8733F, 0xFF7A4E2E);
        g.fill(0, BAR_Y - 1, W, BAR_Y, 0xFFDDA46A);
        g.fill(0, BAR_Y, W, BAR_Y + 1, 0x33000000);
        for (int i = 0; i < 6; i++) {
            int bx = btnX(i), by = BAR_Y + 1;
            boolean lock = i < 3 ? !hasAnimal(i) : false;
            int lvl = i == 3 ? wellLvl : i == 4 ? barnLvl : truckLvl;
            boolean max = i >= 3 && lvl >= 2;
            int price = i < 3 ? A_PRICE[i] : max ? 0 : UP_COST[lvl];
            boolean can = !lock && !max && coins >= price;
            boolean hov = in(mx, my, bx, by, BTN_W, BTN_H);
            int face = lock ? 0xFF9A8A78 : can ? (hov ? 0xFFFFF0C8 : 0xFFFFE3A0) : max ? 0xFFC8E8B0 : 0xFFE4D4BA;
            Gfx.bubble(g, bx, by, BTN_W, BTN_H, 3, face);
            if (i < 3) animalIcon(g, i, bx + 8, by + 8 + (i == 2 ? 0 : 1), i == 2 ? 0.52f : 0.62f);
            else drawUpIcon(g, i, bx + 8, by + 8);
            if (lock) {
                g.fill(bx + 20, by + 6, bx + 28, by + 11, 0xFF5A4A40);
                g.fill(bx + 22, by + 3, bx + 23, by + 6, 0xFF5A4A40); g.fill(bx + 25, by + 3, bx + 26, by + 6, 0xFF5A4A40); g.fill(bx + 22, by + 3, bx + 26, by + 4, 0xFF5A4A40);
            } else if (max) sctext(g, tr("cutemod.ff.max"), bx + 22, by + 4, 20, 0xFF2F7A3A);
            else {
                String ps = String.valueOf(price);
                ctextW(g, ps, bx + 22, by + 4, 20, can ? 0xFF4A2A14 : 0xFFB0382E);
            }
            if (i >= 3 && !max) for (int p = 0; p < lvl; p++) g.fill(bx + 3 + p * 4, by + 13, bx + 6 + p * 4, by + 14, 0xFF4AA84F);
        }
    }

    private void drawUpIcon(GuiGraphics g, int i, int gx, int gy) {
        g.pose().pushPose();
        g.pose().translate(gx, gy, 0);
        g.pose().scale(0.5f * 0.62f, 0.5f * 0.62f, 1f);
        if (i == 3) {
            blob(g, 0, 6, 12, 8, 0xFFB5AEC4);
            ell(g, 0, 4, 9, 5, 0xFF4A9AE0);
            g.fill(-12, -14, -10, 6, WOOD_D); g.fill(10, -14, 12, 6, WOOD_D);
            Gfx.poly(g, new int[]{-16, 0, 16}, new int[]{-12, -24, -12}, 0xFFE0705A);
        } else if (i == 4) {
            Gfx.rrect(g, -13, -8, 26, 20, 2, 0xFFD9504F);
            Gfx.poly(g, new int[]{-16, -9, 0, 9, 16}, new int[]{-8, -16, -20, -16, -8}, 0xFFA8694A);
            Gfx.rrect(g, -7, 0, 14, 12, 1, 0xFFFFFFFF);
            Gfx.line(g, -6, 1, 6, 11, 0xFFD9504F); Gfx.line(g, 6, 1, -6, 11, 0xFFD9504F);
        } else {
            Gfx.rrect(g, -14, -8, 16, 14, 2, 0xFF4FC4BC);
            Gfx.rrect(g, 3, -4, 11, 10, 2, 0xFFF06A62);
            g.fill(7, -2, 12, 2, 0xFFCDEBFF);
            dsc(g, -7, 8, 3, 0xFF3A3040); dsc(g, 8, 8, 3, 0xFF3A3040);
        }
        g.pose().popPose();
    }

    private void renderBanner(GuiGraphics g) {
        float k = Math.min(1f, doneT / 14f);
        int h = won ? 50 : 34, y = 48 - Math.round((1 - k) * 20);
        Gfx.panel(g, 40, y, 140, h, won ? 0xFFFFF0B8 : 0xFFE8D0D0, won ? 0xFFFFC870 : 0xFFC8A0A0);
        sctext(g, tr(won ? "cutemod.ff.win" : "cutemod.ff.lose"), 110, y + 5, 130, won ? 0xFFFFFFFF : 0xFFFFFFFF);
        if (won) {
            for (int i = 0; i < 3; i++) {
                int cx = 80 + i * 30, cy = y + 28;
                boolean on = i < stars && doneT > 18 + i * 12;
                int pulse = on && doneT < 40 + i * 12 ? 1 : 0;
                Gfx.star5(g, cx, cy + 1, 12 + pulse, 5, on ? 0xFFB8801A : 0xFF9A8A70);
                Gfx.star5(g, cx, cy, 11 + pulse, 4, on ? GOLD : 0xFFC8BCA8);
            }
        } else sctext(g, tr("cutemod.ff.lose.sub"), 110, y + 19, 130, 0xFFFFE8E8);
    }

    private void renderMenu(GuiGraphics g) {
        g.fill(0, 0, W, H, 0x33FFFFFF);
        Gfx.panel(g, 10, 6, 200, 128, 0xF0FFF6E0, 0xF0F6DCA8);
        // title with a little chick on each side
        String title = tr("cutemod.ff.title");
        g.pose().pushPose();
        g.pose().translate(110 - tw(title), 12, 0);
        g.pose().scale(2f, 2f, 1f);
        dev.cutemod.client.os.CuteFont.draw(g, font(), title, 1, 1, 0xFFB5793F, false);
        dev.cutemod.client.os.CuteFont.draw(g, font(), title, 0, 0, 0xFFE06A4F, false);
        g.pose().popPose();
        animalIcon(g, HEN, 34, 22, 1.0f);
        animalIcon(g, COW, 186, 22, 0.85f);
        ctextW(g, tr("cutemod.ff.pick"), 110, 36, 180, 0xFF7A5A3A);
        for (int i = 0; i < LEVELS; i++) {
            int x = cardX(i), y = cardY(i);
            boolean hov = in(mx, my, x, y, CARD_W, CARD_H);
            Gfx.shadow(g, x, y, CARD_W, CARD_H, 3);
            Gfx.bubble(g, x, y, CARD_W, CARD_H, 4, hov ? 0xFFFFF2C8 : 0xFFFFE6AC);
            ball(g, x + 9, y + 9, 6, BEST[i] > 0 ? 0xFF6CC070 : 0xFFE8905A);
            ctext(g, String.valueOf(i + 1), x + 9, y + 5, 0xFFFFFFFF);
            ctextW(g, tr("cutemod.ff.lv." + (i + 1)), x + CARD_W / 2 + 9, y + 4, CARD_W - 25, 0xFF5A3A20);
            for (int s = 0; s < 3; s++) {
                int cx = x + 11 + s * 14, cy = y + 25;
                Gfx.star5(g, cx, cy, 6, 2, s < BEST[i] ? GOLD : 0xFFD8C8A8);
            }
            if (L_BEAR[i] > 0) icon(g, BEARK, x + CARD_W - 9, y + 25, 0.9f);
            else if (L_FACT[i] > 0) icon(g, CAKE, x + CARD_W - 9, y + 25, 0.9f);
            else icon(g, EGG, x + CARD_W - 9, y + 25, 0.9f);
        }
    }
}
