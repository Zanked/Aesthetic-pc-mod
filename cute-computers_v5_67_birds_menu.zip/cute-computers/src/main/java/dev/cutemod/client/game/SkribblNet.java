package dev.cutemod.client.game;

import dev.cutemod.data.SkribblCanvas;
import dev.cutemod.data.SkribblGame;
import dev.cutemod.net.SkribblActionPayload;
import dev.cutemod.net.SkribblChatPayload;
import dev.cutemod.net.SkribblDrawPayload;
import dev.cutemod.net.SkribblLobbyPayload;
import dev.cutemod.net.SkribblStatePayload;
import dev.cutemod.net.SkribblTelePayload;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/** The client side of online Scribble Pals: what the server last told us (rooms, our room, the running game, the picture, the chat) and the messages we send. */
public final class SkribblNet {
    private SkribblNet() {}

    // ---- the lobby
    public static List<String> hosts = new ArrayList<>();
    public static List<Integer> open = new ArrayList<>();
    public static boolean inRoom, inGame, youHost;
    public static int mySlot, roundsIdx = 1, secondsIdx = 1;
    /** 0 draw and guess, 1 telephone; the word set (see SkribblWords.SET_*); how many own words the room has and how many are ours. */
    public static int mode, wordSet, customCount, customMine;
    /** 0 empty, 1 open, 2 computer player, 3 person. */
    public static final int[] slotType = new int[SkribblGame.SLOTS];
    public static final String[] slotName = new String[SkribblGame.SLOTS];
    /** Goes up with every lobby message. */
    public static int version;
    static { java.util.Arrays.fill(slotName, ""); }

    // ---- the running game
    public static int phase, round, rounds, drawer = -1, timeTotal, timeLeft, guessedMask, likes;
    /** The word we may see ("english|russian"; in the telephone game the phrase to draw), or empty. */
    public static String word = "";
    public static boolean liked;
    public static List<String> choices = new ArrayList<>();
    public static String hintEn = "", hintRu = "";
    public static final int[] scores = new int[SkribblGame.SLOTS], gains = new int[SkribblGame.SLOTS];
    /** When the last state arrived (the timer counts on from there). */
    public static long stateAt;
    public static int stateVersion;

    // ---- the picture and the chat
    public static final SkribblCanvas board = new SkribblCanvas();
    public static int boardVersion;
    public static int strokeNo;

    public static final class Line {
        public final int kind, arg;
        public final String name, text;
        Line(int kind, String name, String text, int arg) { this.kind = kind; this.name = name; this.text = text; this.arg = arg; }
    }

    public static final List<Line> chat = new ArrayList<>();
    public static int chatVersion;

    // ---- the telephone game: the picture we have to describe, and the finished chains that are being shown
    public static byte[] promptPx;
    public static int promptVersion;

    public static final class Item {
        public final int chain, step, author;
        public final String text;
        public final byte[] px;
        Item(int chain, int step, int author, String text, byte[] px) { this.chain = chain; this.step = step; this.author = author; this.text = text; this.px = px; }
    }

    public static final List<Item> items = new ArrayList<>();
    public static int itemsVersion;
    private static int lastStep = -1;

    // ---- reactions that float over the board
    public static final class Emoji {
        public final String name;
        public final int idx;
        Emoji(String name, int idx) { this.name = name; this.idx = idx; }
    }

    public static final java.util.ArrayDeque<Emoji> emojis = new java.util.ArrayDeque<>();

    private static int notice;
    private static long ignoreUntil;

    public static void apply(SkribblLobbyPayload p) {
        hosts = new ArrayList<>(p.hosts());
        open = new ArrayList<>(p.open());
        boolean room = p.inRoom();
        inRoom = System.currentTimeMillis() < ignoreUntil ? false : room;
        inGame = inRoom && p.inGame();
        youHost = p.youHost();
        mySlot = p.mySlot();
        roundsIdx = p.roundsIdx();
        secondsIdx = p.secondsIdx();
        mode = p.mode();
        wordSet = p.wordSet();
        customCount = p.customCount();
        customMine = p.customMine();
        for (int i = 0; i < SkribblGame.SLOTS; i++) {
            slotType[i] = i < p.slotType().size() ? p.slotType().get(i) : 0;
            slotName[i] = i < p.slotName().size() ? p.slotName().get(i) : "";
        }
        if (!inGame) phase = 0;
        if (!inRoom) { chat.clear(); chatVersion++; board.clear(); boardVersion++; }
        else if (!inGame) { chat.clear(); chatVersion++; }
        if (p.notice() != 0) notice = p.notice();
        version++;
    }

    public static void applyState(SkribblStatePayload p) {
        int before = phase;
        phase = p.phase();
        round = p.round();
        rounds = p.rounds();
        drawer = p.drawer();
        timeTotal = p.timeTotal();
        timeLeft = p.timeLeft();
        word = p.word();
        choices = new ArrayList<>(p.choices());
        int step = p.round();
        hintEn = p.hintEn();
        hintRu = p.hintRu();
        guessedMask = p.guessedMask();
        likes = p.likes();
        liked = p.liked();
        for (int i = 0; i < SkribblGame.SLOTS; i++) {
            scores[i] = i < p.scores().size() ? p.scores().get(i) : 0;
            gains[i] = i < p.gains().size() ? p.gains().get(i) : 0;
        }
        stateAt = System.nanoTime();
        stateVersion++;
        if (phase == SkribblGame.T_WRITE && round == 0 && before != SkribblGame.T_WRITE) {            // a new telephone game
            items.clear();
            itemsVersion++;
            promptPx = null;
            promptVersion++;
        }
        if (phase == SkribblGame.T_DRAW && (before != SkribblGame.T_DRAW || step != lastStep)) {      // a fresh board for every drawing step
            board.clear();
            boardVersion++;
            strokeNo = 0;
        }
        lastStep = step;
        // the turn is over and we know the word: keep the picture
        if (phase == SkribblGame.REVEAL && before != SkribblGame.REVEAL && !word.isEmpty() && drawer >= 0) {
            SkribblGallery.add(word, drawer < slotName.length ? slotName[drawer] : "", board.px);
        }
    }

    public static void applyDraw(SkribblDrawPayload p) {
        switch (p.kind()) {
            case 0 -> { for (String o : p.ops()) board.add(o); }
            case 1 -> board.undo();
            case 2 -> { board.clear(); strokeNo = 0; }
            case 3 -> { board.setOps(p.ops()); }
            default -> { }
        }
        boardVersion++;
    }

    public static void applyTele(SkribblTelePayload p) {
        byte[] px = p.pic().length > 0 ? SkribblCanvas.unzip(p.pic()) : null;
        if (p.kind() == 0) {
            promptPx = px;
            promptVersion++;
            return;
        }
        String who = p.author() >= 0 && p.author() < slotName.length ? slotName[p.author()] : "";
        items.add(new Item(p.chain(), p.step(), p.author(), p.text(), px));
        itemsVersion++;
        chat.add(new Line(px != null ? 21 : 20, who, p.text(), 0));
        chatVersion++;
        if (px != null) {                                    // keep the picture with the phrase that was drawn
            String phrase = null;
            for (Item o : items) if (o.chain == p.chain() && o.step == p.step() - 1 && o.px == null) phrase = o.text;
            if (phrase != null && !phrase.isEmpty()) SkribblGallery.add(phrase.indexOf('|') >= 0 ? phrase : phrase + "|" + phrase, who, px);
        }
    }

    public static void applyChat(SkribblChatPayload p) {
        if (p.kind() == SkribblGame.K_EMOJI) {
            emojis.add(new Emoji(p.name(), p.arg()));
            while (emojis.size() > 30) emojis.poll();
            return;
        }
        chat.add(new Line(p.kind(), p.name(), p.text(), p.arg()));
        while (chat.size() > 80) chat.remove(0);
        chatVersion++;
    }

    public static void clear() {
        hosts = new ArrayList<>();
        open = new ArrayList<>();
        inRoom = inGame = youHost = false;
        phase = 0;
        notice = 0;
        chat.clear();
        board.clear();
        boardVersion++;
        items.clear();
        itemsVersion++;
        promptPx = null;
        emojis.clear();
        version++;
    }

    /** The ticks left in this turn (counted on from the last state). */
    public static int ticksLeft() {
        if (phase != SkribblGame.DRAW) return 0;
        long passed = (System.nanoTime() - stateAt) / 50_000_000L;
        return (int) Math.max(0, timeLeft - passed);
    }

    /** The last notice (the room is gone, ...), only once. */
    public static int takeNotice() {
        int n = notice;
        notice = 0;
        return n;
    }

    private static void send(int action, int a, String text) {
        PacketDistributor.sendToServer(new SkribblActionPayload(action, a, text));
    }

    public static void request() { send(0, 0, ""); }

    public static void create() { send(1, 0, ""); }

    public static void join(String host) { send(2, 0, host); }

    /** Leave the room (or the game). We forget the room at once, the server confirms later. */
    public static void leave() {
        send(3, 0, "");
        ignoreUntil = System.currentTimeMillis() + 1500;
        inRoom = inGame = false;
        phase = 0;
        version++;
    }

    public static void slot(int i) { send(4, i, ""); }

    public static void start() { send(5, 0, ""); }

    public static void setRounds(int idx) { send(6, idx, ""); }

    public static void setSeconds(int idx) { send(7, idx, ""); }

    public static void pick(int i) { send(8, i, ""); }

    /** A drawing operation of ours: drawn on our own board at once, the server passes it on. */
    public static void op(String op) {
        if (board.add(op)) { boardVersion++; send(9, 0, op); }
    }

    public static void undo() {
        if (board.undo()) { boardVersion++; send(10, 0, ""); }
    }

    public static void clearBoard() {
        board.clear();
        boardVersion++;
        send(11, 0, "");
    }

    public static void say(String text) { send(12, 0, text); }

    public static void like() { send(13, 0, ""); }

    public static void addWord(String text) { send(14, 0, text); }

    public static void clearWords() { send(15, 0, ""); }

    public static void setWordSet(int set) { send(16, set, ""); }

    public static void emoji(int idx) { send(17, idx, ""); }

    public static void teleText(String text) { send(18, 0, text); }

    public static void teleDone() { send(19, 0, ""); }

    public static void setMode(int m) { send(20, m, ""); }
}
