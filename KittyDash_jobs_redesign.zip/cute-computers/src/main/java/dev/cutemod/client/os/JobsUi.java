package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/**
 * The look of CuteJobs (the list of jobs, the countdown, the header of a shift and the result screen).
 * Only drawing lives here: what a job does and what it pays stays in {@link JobsApp} and {@link Jobs}.
 * <p>
 * Design: a deep violet background, rounded cards with a soft shadow, a coloured tile with a small pixel
 * icon for every job, pills for the status, a wallet chip with the coins, stars for the quality of a shift.
 * The mini games draw under the 18 px header ({@link #BAR}); that height is the one thing that must not change.
 */
final class JobsUi {
    private JobsUi() {}

    /** Height of the header; every shift draws its own game below it. */
    static final int BAR = 18;

    // ---------- palette ----------
    static final int BG_TOP = 0xFF1C1633, BG_BOT = 0xFF120D24;
    static final int HEAD_TOP = 0xFF33275A, HEAD_BOT = 0xFF261D45;
    static final int CARD = 0xFF261E44, CARD_HOT = 0xFF33295C, CARD_OFF = 0xFF1F1938, RIM = 0xFF3B3063;
    static final int INK = 0xFF1B1530;
    static final int WHITE = 0xFFFFFFFF, MUTED = 0xFF9A90B8, SOFT = 0xFFD8D0EE;
    static final int ACCENT = 0xFFB57BD6, GREEN = 0xFF5BD97A, YELLOW = 0xFFFFD866, RED = 0xFFE5484D;

    private static final int[] JOB_RGB = {0xFF6AA8F0, 0xFFF0B050, 0xFFF58FB8, 0xFFC98B5A, 0xFF5BBF6A, 0xFFB57BD6, 0xFF8EC3F2, 0xFF4ADE80, 0xFFFF6AD5, 0xFF38BDF8};

    // ---------- menu geometry (two columns of cards) ----------
    private static final int GX = 8, GY = 30, CW = 139, CH = 22, GAP_X = 6, GAP_Y = 3;

    // ---------- pixel icons, 8 x 8 ----------
    private static final String[][] ICON = {
            // typing: a keyboard
            {"........", "########", "#.#.#.##", "########", "#.####.#", "########", "........", "........"},
            // post: an envelope
            {"........", "########", "##....##", "#.#..#.#", "#..##..#", "#......#", "########", "........"},
            // pets: a heart (care)
            {"........", ".##..##.", "########", "########", "########", ".######.", "..####..", "...##..."},
            // cafe: a cup with steam
            {"..#..#..", "...#..#.", "######..", "######.#", "######.#", "######.#", ".####.#.", "........"},
            // courier: a map pin
            {"..####..", ".######.", "###..###", "###..###", ".######.", "..####..", "...##...", "........"},
            // artist: a brush
            {".....###", "....###.", "...###..", "..###...", ".##.#...", "###.....", "##......", "........"},
            // tester: a game pad
            {"........", ".######.", "########", "#.##.#.#", "########", "##....##", ".#....#.", "........"},
            // coder: < >
            {"........", "..#..#..", ".#....#.", "#......#", ".#....#.", "..#..#..", "........", "........"},
            // dj: a note
            {"...#####", "...#####", "...#...#", "...#...#", "..##..##", ".###.###", "..#...#.", "........"},
            // pilot: a plane
            {"...##...", "...##...", "..####..", ".######.", "########", "...##...", "..####..", "........"}};
    private static final String[] LOCK = {".###.", "#...#", "#...#", "#####", "##.##", "#####", "#####"};
    private static final String[] STAR = {"...#...", "...#...", "#######", ".#####.", "..###..", ".##.##.", ".#...#."};

    // ---------- small helpers ----------
    private static Font font() { return Minecraft.getInstance().font; }

    private static int tw(String s) { return CuteFont.width(font(), s); }

    static void text(GuiGraphics g, String s, int x, int y, int argb) { CuteFont.draw(g, font(), s, x, y, argb, false); }

    static void ctext(GuiGraphics g, String s, int cx, int y, int argb) { CuteFont.draw(g, font(), s, cx - tw(s) / 2, y, argb, false); }

    /** A text that must fit in maxW: shrunk down to 60 %, then cut. x is the left edge, or the middle when centered. */
    static void fit(GuiGraphics g, String s, int x, int y, int maxW, int argb, boolean centered) {
        int w = tw(s);
        if (w <= maxW) { text(g, s, centered ? x - w / 2 : x, y, argb); return; }
        float k = Math.max(0.6f, maxW / (float) w);
        String cut = w * k > maxW ? font().plainSubstrByWidth(s, (int) (maxW / k)) : s;
        float cw = tw(cut) * k;
        g.pose().pushPose();
        g.pose().translate(centered ? x - cw / 2f : x, y + (1 - k) * 4f, 0);
        g.pose().scale(k, k, 1f);
        CuteFont.draw(g, font(), cut, 0, 0, argb, false);
        g.pose().popPose();
    }

    /** A text at a fixed scale (small captions). */
    static void scaled(GuiGraphics g, String s, int x, int y, float k, int argb) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(k, k, 1f);
        CuteFont.draw(g, font(), s, 0, 0, argb, false);
        g.pose().popPose();
    }

    static void big(GuiGraphics g, String s, int cx, int y, float k, int argb) {
        g.pose().pushPose();
        g.pose().translate(cx - tw(s) * k / 2f, y, 0);
        g.pose().scale(k, k, 1f);
        CuteFont.draw(g, font(), s, 0, 0, argb, false);
        g.pose().popPose();
    }

    private static void rr(GuiGraphics g, int x, int y, int w, int h, int r, int argb) { App.roundRect(g, x, y, w, h, r, argb); }

    /** A card: a soft shadow, a rim and the body. */
    static void card(GuiGraphics g, int x, int y, int w, int h, int r, int body, int rim) {
        rr(g, x, y + 1, w, h, r, 0x55000000);
        rr(g, x, y, w, h, r, rim);
        rr(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), body);
    }

    /** A pill with a label. */
    private static void pill(GuiGraphics g, int x, int y, int w, int h, int fill, String label, int ink) {
        rr(g, x, y, w, h, h / 2, fill);
        fit(g, label, x + w / 2, y + (h - 8) / 2, w - 6, ink, true);
    }

    /** A rounded bar that fills from the left; f = 0..1. */
    static void bar(GuiGraphics g, int x, int y, int w, int h, float f, int fill, int back) {
        rr(g, x, y, w, h, h / 2, back);
        int fw = Math.round(w * Math.max(0f, Math.min(1f, f)));
        if (fw >= h) rr(g, x, y, fw, h, h / 2, fill);
        else if (fw > 0) g.fill(x, y + 1, x + fw, y + h - 1, fill);
    }

    /** A bitmap: every '#' is one square of size k. */
    static void glyph(GuiGraphics g, String[] rows, int x, int y, int k, int argb) {
        for (int r = 0; r < rows.length; r++) {
            String row = rows[r];
            int c = 0;
            while (c < row.length()) {
                if (row.charAt(c) != '#') { c++; continue; }
                int s = c;
                while (c < row.length() && row.charAt(c) == '#') c++;
                g.fill(x + s * k, y + r * k, x + c * k, y + (r + 1) * k, argb);
            }
        }
    }

    static int index(String jobId) {
        for (int i = 0; i < Jobs.LIST.size(); i++) if (Jobs.LIST.get(i).id().equals(jobId)) return i;
        return 0;
    }

    private static int color(int i) { return JOB_RGB[Math.floorMod(i, JOB_RGB.length)]; }

    /** The coloured tile with the icon of a job; size = 12, 16, 24... (the icon is 8 px, drawn at 1x or 2x). */
    static void tile(GuiGraphics g, int i, int x, int y, int size, boolean dim) {
        int c = dim ? App.mix(color(i), 0xFF3B3063, 0.65f) : color(i);
        rr(g, x, y + 1, size, size, size >= 20 ? 5 : 3, 0x55000000);
        rr(g, x, y, size, size, size >= 20 ? 5 : 3, c);
        rr(g, x + 1, y + 1, size - 2, Math.max(2, size / 3), 2, App.mix(c, 0xFFFFFF, 0.25f));        // a soft shine on top
        int k = size >= 20 ? 2 : 1;
        int off = (size - 8 * k) / 2;
        glyph(g, ICON[Math.floorMod(i, ICON.length)], x + off, y + off, k, dim ? 0xFF2A2145 : INK);
    }

    static void background(GuiGraphics g) {
        g.fillGradient(0, 0, App.W, App.H, BG_TOP, BG_BOT);
    }

    private static void headBar(GuiGraphics g) {
        g.fillGradient(0, 0, App.W, BAR, HEAD_TOP, HEAD_BOT);
        g.fill(0, BAR, App.W, BAR + 1, 0x66000000);
    }

    // ======================================================================
    //                               the list
    // ======================================================================

    /** The card under the mouse (index into Jobs.LIST) or -1. */
    static int cardAt(int x, int y) {
        for (int i = 0; i < Jobs.LIST.size(); i++) {
            int cx = GX + (i % 2) * (CW + GAP_X), cy = GY + (i / 2) * (CH + GAP_Y);
            if (x >= cx && y >= cy && x < cx + CW && y < cy + CH) return i;
        }
        return -1;
    }

    static void menu(GuiGraphics g, int mx, int my, boolean[] ok, int noGamesTimer) {
        background(g);
        menuHeader(g);
        int hover = cardAt(mx, my);
        for (int i = 0; i < Jobs.LIST.size(); i++) {
            Jobs.Job j = Jobs.LIST.get(i);
            int x = GX + (i % 2) * (CW + GAP_X), y = GY + (i / 2) * (CH + GAP_Y);
            boolean can = ok[i], hot = hover == i && can;
            boolean locked = Jobs.rank() < j.rank();
            int left = Jobs.cooldownLeft(j.id());

            card(g, x, y, CW, CH, 5, hot ? CARD_HOT : can ? CARD : CARD_OFF, hot ? ACCENT : RIM);
            tile(g, i, x + 3, y + 3, 16, !can);

            int nameCol = can ? WHITE : MUTED;
            String name = App.t("cutemod.job.name." + j.id());
            int pillW = 42, textW = CW - 25 - (locked ? 5 : pillW + 8);
            fit(g, name, x + 23, y + 2, textW, nameCol, false);

            // the second line: what it pays, or what is missing
            if (locked) {
                glyph(g, LOCK, x + 23, y + 12, 1, RED);
                fit(g, App.t("cutemod.job.locked", App.t("cutemod.job.rank." + j.rank())), x + 31, y + 11, CW - 36, RED, false);
            } else {
                Progress.drawCoin(g, x + 23, y + 12);
                int pay = Math.round(j.maxPay() * Jobs.multiplier());
                scaled(g, App.t("cutemod.job.upto", pay), x + 32, y + 12, 0.8f, can ? YELLOW : MUTED);
            }

            // the right side: a pill with the state
            if (can) {
                pill(g, x + CW - pillW - 4, y + 5, pillW, 12, hot ? 0xFF8CF0A4 : GREEN, App.t("cutemod.job.start"), INK);
            } else if (!locked && left > 0) {
                pill(g, x + CW - pillW - 4, y + 5, pillW, 12, 0xFF3B3063, App.t("cutemod.job.time", left), SOFT);
                // the rest runs out from left to right along the bottom edge
                bar(g, x + 6, y + CH - 3, CW - 12, 2, Math.min(1f, left / (float) Jobs.COOLDOWN_SEC), ACCENT, 0x33000000);
            } else if (!locked) {
                pill(g, x + CW - pillW - 4, y + 5, pillW, 12, 0xFF5A2A3A, App.t("cutemod.job.nogames"), 0xFFFFC2C8);
            }
        }
        String foot = noGamesTimer > 0 ? App.t("cutemod.job.nogames_hint") : App.t("cutemod.job.footer", Jobs.COOLDOWN_SEC, Jobs.totalShifts());
        fit(g, foot, App.W / 2, 156, App.W - 16, noGamesTimer > 0 ? RED : MUTED, true);
    }

    private static void menuHeader(GuiGraphics g) {
        int rank = Jobs.rank();
        g.fillGradient(0, 0, App.W, 26, HEAD_TOP, HEAD_BOT);
        g.fill(0, 26, App.W, 27, 0x66000000);

        // rank: a star, the name and the pay multiplier
        glyph(g, STAR, 8, 4, 1, YELLOW);
        String rname = App.t("cutemod.job.rank." + rank);
        text(g, rname, 18, 3, WHITE);
        String mult = "x" + trim(Jobs.RANK_MULT[rank]);
        int mw = tw(mult) + 8;
        pill(g, 22 + tw(rname), 3, mw, 10, 0x55FFD866, mult, YELLOW);

        // the way to the next rank
        if (rank + 1 < Jobs.RANK_XP.length) {
            int from = Jobs.RANK_XP[rank], to = Jobs.RANK_XP[rank + 1];
            float f = (Jobs.xp() - from) / (float) (to - from);
            bar(g, 8, 17, 150, 5, f, ACCENT, 0xFF1B1530);
            text(g, Jobs.xp() + "/" + to, 164, 14, MUTED);
        } else {
            bar(g, 8, 17, 150, 5, 1f, GREEN, 0xFF1B1530);
            fit(g, App.t("cutemod.job.maxrank"), 164, 14, 70, GREEN, false);
        }

        // the wallet
        String coins = Integer.toString(Progress.coins());
        int w = Math.max(40, tw(coins) + 24);
        int x = App.W - 8 - w;
        rr(g, x, 6, w, 14, 7, 0xFF1B1530);
        Progress.drawCoin(g, x + 5, 9);
        text(g, coins, x + 16, 8, YELLOW);
    }

    static String trim(float f) { return f == Math.floor(f) ? Integer.toString((int) f) : Float.toString(f); }

    // ======================================================================
    //                               inside a shift
    // ======================================================================

    /** The header of a running shift: icon, name, score in the middle, a time pill and the timer line below. */
    static void shiftHeader(GuiGraphics g, String jobId, String score, int left, float rest) {
        headBar(g);
        int i = index(jobId);
        tile(g, i, 4, 3, 11, false);
        String name = App.t("cutemod.job.name." + jobId);
        text(g, name, 19, 3, WHITE);

        boolean hurry = left <= 10;
        String tm = App.t("cutemod.job.time", left);
        int pw = tw(tm) + 10, px = App.W - 6 - pw;
        rr(g, px, 2, pw, 11, 5, hurry ? 0xFF5A1F2C : 0xFF1B1530);
        text(g, tm, px + 5, 3, hurry ? RED : YELLOW);

        // the score sits between the name and the pill and is cut to fit, so nothing overlaps
        int from = 19 + tw(name) + 10, to = px - 8;
        String s = font().plainSubstrByWidth(score, Math.max(0, to - from));
        text(g, s, from + Math.max(0, (to - from - tw(s)) / 2), 3, SOFT);

        // the timer is a thin line on the lower edge of the header
        g.fill(0, BAR - 3, App.W, BAR, 0xFF1B1530);
        int fw = Math.max(0, Math.round(App.W * rest));
        g.fill(0, BAR - 3, fw, BAR, hurry ? RED : GREEN);
        g.fill(0, BAR - 3, fw, BAR - 2, 0x44FFFFFF);
    }

    // ======================================================================
    //                               get ready
    // ======================================================================

    /** The countdown before a shift. ready counts 150 -> 0 (3, 2, 1). */
    static void ready(GuiGraphics g, String jobId, int ready, String how) {
        background(g);
        headBar(g);
        int i = index(jobId);
        tile(g, i, 4, 3, 11, false);
        text(g, App.t("cutemod.job.name." + jobId), 19, 3, WHITE);

        card(g, 12, 24, App.W - 24, 128, 7, CARD, RIM);
        // the tile pops in a little at the start
        int size = 26;
        tile(g, i, App.W / 2 - size / 2, 30, size, false);
        ctext(g, App.t("cutemod.job.name." + jobId), App.W / 2, 60, WHITE);

        int digit = Math.max(1, ready / 50 + 1);
        float pulse = 1f + 0.12f * (1f - (ready % 50) / 50f);                  // the number is biggest right after it changes
        big(g, Integer.toString(digit), App.W / 2, 72, 2f * pulse, YELLOW);
        bar(g, App.W / 2 - 40, 94, 80, 4, 1f - ready / 150f, ACCENT, 0xFF1B1530);

        var lines = font().split(net.minecraft.network.chat.FormattedText.of(how), 250);
        for (int l = 0; l < lines.size() && l < 4; l++) {
            int w = font().width(lines.get(l));
            CuteFont.draw(g, font(), lines.get(l), (App.W - w) / 2, 104 + l * 10, SOFT, false);
        }
    }

    // ======================================================================
    //                               the result
    // ======================================================================

    static final int BTN_X = 100, BTN_Y = 148, BTN_W = 100, BTN_H = 16;

    static boolean backHit(int x, int y) { return x >= BTN_X && y >= BTN_Y && x < BTN_X + BTN_W && y < BTN_Y + BTN_H; }

    /** t counts ticks since the shift ended: the stars pop in, the coins count up, confetti falls on a good result. */
    static void result(GuiGraphics g, int mx, int my, String jobId, float q, int pay, boolean rankUp, boolean tired, int t) {
        background(g);
        headBar(g);
        int i = index(jobId);
        tile(g, i, 4, 3, 11, false);
        text(g, App.t("cutemod.job.name." + jobId), 19, 3, WHITE);

        card(g, 40, 24, App.W - 80, 90, 7, CARD, rankUp ? GREEN : RIM);
        ctext(g, App.t("cutemod.job.done"), App.W / 2, 30, YELLOW);

        // stars: 3 for a great shift, 2 for a good one, 1 for an average one
        int stars = q >= 0.9f ? 3 : q >= 0.6f ? 2 : q >= 0.3f ? 1 : 0;
        for (int s = 0; s < 3; s++) {
            int sx = App.W / 2 - 27 + s * 20, sy = 42;
            boolean full = s < stars;
            int appear = 10 + s * 10;
            if (!full) { glyph(g, STAR, sx, sy, 2, 0xFF3B3063); continue; }
            if (t < appear) { glyph(g, STAR, sx, sy, 2, 0xFF3B3063); continue; }
            int age = t - appear;
            if (age < 8) glyph(g, STAR, sx - 1, sy - 1, 2, 0xFFFFF2B0);                    // a short flash
            else glyph(g, STAR, sx, sy, 2, YELLOW);
        }

        // quality
        int qc = q >= 0.75f ? GREEN : q >= 0.4f ? YELLOW : RED;
        ctext(g, App.t("cutemod.job.quality", Math.round(q * 100)), App.W / 2, 60, SOFT);
        bar(g, App.W / 2 - 55, 72, 110, 5, Math.min(1f, q * Math.min(1f, t / 25f)), qc, 0xFF1B1530);

        // coins count up
        float f = Math.max(0f, Math.min(1f, (t - 20) / 40f));
        int shown = Math.round(pay * f);
        String amount = "+" + shown;
        int aw = Math.round(tw(amount) * 2f);
        int cx = App.W / 2 - (aw + 12) / 2;
        Progress.drawCoin(g, cx, 91);
        big(g, amount, cx + 12 + aw / 2, 86, 2f, pay > 0 ? YELLOW : MUTED);

        // notes under the card
        int y = 118;
        if (rankUp) {
            String r = App.t("cutemod.job.rankup", App.t("cutemod.job.rank." + Jobs.rank()));
            int w = Math.min(App.W - 24, tw(r) + 20);
            pill(g, App.W / 2 - w / 2, y, w, 12, GREEN, r, INK);
            y += 15;
        }
        if (tired) { fit(g, App.t("cutemod.job.tired"), App.W / 2, y, App.W - 16, MUTED, true); y += 10; }
        fit(g, App.t("cutemod.job.cooldown_note", Jobs.COOLDOWN_SEC), App.W / 2, y, App.W - 16, MUTED, true);

        boolean hov = backHit(mx, my);
        rr(g, BTN_X, BTN_Y + 1, BTN_W, BTN_H, 8, 0x55000000);
        rr(g, BTN_X, BTN_Y, BTN_W, BTN_H, 8, hov ? App.mix(ACCENT, 0xFFFFFF, 0.25f) : ACCENT);
        fit(g, App.t("cutemod.job.back"), BTN_X + BTN_W / 2, BTN_Y + 4, BTN_W - 10, INK, true);

        if (q >= 0.75f || rankUp) confetti(g, t);
    }

    private static final int[] CONFETTI = {0xFFFFD866, 0xFFF58FB8, 0xFF6AA8F0, 0xFF5BD97A, 0xFFB57BD6};

    private static void confetti(GuiGraphics g, int t) {
        if (t > 260) return;
        for (int i = 0; i < 26; i++) {
            int seed = i * 7919;
            int x = (seed * 31 + 13) % App.W;
            int delay = (seed / 7) % 50;
            int age = t - delay;
            if (age < 0) continue;
            int y = age * (1 + i % 3) / 2 - 8;
            if (y > App.H) continue;
            x += (int) (Math.sin((age + i * 9) / 9.0) * 4);
            g.fill(x, y, x + 2, y + 2, CONFETTI[i % CONFETTI.length]);
        }
    }
}
