"""
The RGB headphones (dark shell, glowing rings on the cups and a glowing stripe on the band).

  python tools/make_rgb_headphones.py

writes
  textures/models/armor/headphones_rgb_layer_1.png   (64x32; the glowing parts are WHITE, the client tints the whole model with a
                                                      running rainbow colour, see HeadphonesModel.RgbModel, so dark parts stay dark)
  textures/item/headphones_rgb_3d.png (+ .mcmeta)    (animated: 16 frames of 128x64, the colour runs along the band)
  models/item/headphones_rgb.json
It reuses the shape and the painter of make_headphones.py.
"""
import os, sys, json, colorsys
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_headphones as mh

RES = mh.RES
FRAMES = 16

def palette():
    mh.LAV, mh.LAV_L, mh.LAV_D = (104, 106, 134), (150, 154, 186), (64, 66, 90)
    mh.PINK, mh.PINK_D = (52, 52, 70), (34, 34, 48)
    mh.CREAM = (255, 255, 255)
    mh.HEART, mh.HEART_L = (40, 40, 58), (96, 96, 128)
    mh.MOTIF = 'heart'

def glow(img, k):
    """White glow: ring on the outer side of the cups, stripe on the top of the band."""
    a = np.asarray(img, np.float32).copy()
    for c in mh.CUBES:
        for face, (rx, ry, rw, rh) in mh.regions(c).items():
            X0, Y0, w, h = rx * k, ry * k, rw * k, rh * k
            ys = (np.arange(h)[:, None] + 0.5) / h
            xs = (np.arange(w)[None, :] + 0.5) / w
            m = None
            if c['role'] == 'shell' and face == ('east' if c['side'] > 0 else 'west'):
                d = np.maximum(np.abs(xs - 0.5), np.abs(ys - 0.5)) * 2
                m = np.clip((d - 0.58) / 0.12, 0, 1) * np.clip((0.97 - d) / 0.08, 0, 1) if k > 1 else (d > 0.6).astype(np.float32)
            elif c['name'] == 'bar' and face in ('up', 'north', 'south'):
                m = np.ones((h, w), np.float32) if k == 1 else np.clip(1 - np.abs(ys - 0.5) * 0 , 0, 1) * np.ones((h, w), np.float32)
            if m is None: continue
            m = np.broadcast_to(m, (h, w))[..., None]
            reg = a[Y0:Y0 + h, X0:X0 + w, :3]
            a[Y0:Y0 + h, X0:X0 + w, :3] = reg * (1 - m) + 255 * m
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), 'RGBA')

def main():
    mh.pack(); palette()
    small = glow(mh.paint(1), 1)
    big = glow(mh.paint(8), 8).resize((128, 64), Image.LANCZOS)
    small.save(os.path.join(RES, 'textures/models/armor/headphones_rgb_layer_1.png'))
    base = np.asarray(big, np.float32)
    xs = np.arange(128)[None, :] / 128.0
    sheet = Image.new('RGBA', (128, 64 * FRAMES))
    for f in range(FRAMES):
        hue = (f / FRAMES + xs * 0.6) % 1.0                       # the rainbow runs along the texture
        rgb = np.zeros((1, 128, 3), np.float32)
        for x in range(128):
            rgb[0, x] = colorsys.hsv_to_rgb(float(hue[0, x]), 0.9, 1.0)
        out = base.copy()
        out[..., :3] = base[..., :3] * rgb                        # same multiplication the game does on the head
        sheet.paste(Image.fromarray(np.clip(out, 0, 255).astype(np.uint8), 'RGBA'), (0, 64 * f))
    p = os.path.join(RES, 'textures/item/headphones_rgb_3d.png')
    sheet.save(p)
    json.dump({'animation': {'frametime': 3, 'interpolate': True, 'width': 128, 'height': 64}}, open(p + '.mcmeta', 'w'), indent=1)
    json.dump(mh.item_json('rgb'), open(os.path.join(RES, 'models/item/headphones_rgb.json'), 'w'), indent=1)
    print('ok')

if __name__ == '__main__':
    main()
