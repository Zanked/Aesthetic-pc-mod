package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import dev.cutemod.data.PetWear;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

/**
 * Pet Photo: a little photo studio. The viewfinder shows the pet live on a paper backdrop; pick the backdrop (paper rolls),
 * the pose, a colour filter, a frame, mirror the pet, set the self-timer and press the shutter (or Space). The photo
 * "develops" in the album: a wall of prints hanging on a string. The album keeps 6 photos; a photo is only a note
 * (backdrop, pose, filter, frame, mirror, clothes, species, day), the picture is drawn again when you look at it, so
 * nothing big is saved. Saved as "photos" (the old notes of 5 fields still load).
 */
public class PhotoApp extends KitApp {
    private static final int SLOTS = 6, BGS = StudioArt.BGS, POSES = StudioArt.POSES, FILTERS = StudioArt.FILTERS, FRAMES = StudioArt.FRAMES;
    private static final int VW = StudioArt.VW, VH = StudioArt.VH, VX = 6, VY = 19;
    private static final int PX = 184;                                      // the control panel: x = 184 .. 294
    private static final int ALBUM_Y = 125, CARD_W = 47, CARD_H = 38, CARD_PITCH = 49;

    /** A photo: backdrop, pose (0 happy, 1 calm, 2 asleep, 3 sulking), filter, frame, mirrored, day (days since 1970), clothes, species. */
    private record Photo(int bg, int pose, String head, String body, String species, int filter, int frame, boolean flip, int day) {}

    private final Photo[] album = new Photo[SLOTS];
    private final int[] developing = new int[SLOTS];
    private int bg, pose, filter, frame, timer, cd, view = -1, flash, armedDel;
    private boolean flip, loaded;

    @Override protected int accent() { return 0xFF8A9AE8; }

    @Override protected String id() { return "photo"; }

    @Override
    public void attach(Shell shell) { super.attach(shell); if (!loaded) load(); }

    @Override public boolean canBack() { return view >= 0; }

    @Override public void back() { view = -1; armedDel = 0; }

    private static boolean ok(String s) { return s.length() <= 80 && s.matches("[a-z0-9_+]*"); }

    private void load() {
        loaded = true;
        String s = Store.read("photos");
        if (s == null) return;
        String[] rows = s.split(";", -1);
        for (int i = 0; i < SLOTS && i < rows.length; i++) {
            String[] p = rows[i].split(",", -1);
            if ((p.length != 5 && p.length != 9) || !ok(p[2]) || !ok(p[3]) || !ok(p[4]) || p[4].isEmpty()) continue;
            try {
                boolean ext = p.length == 9;
                album[i] = new Photo(Math.floorMod(Integer.parseInt(p[0]), BGS), Math.floorMod(Integer.parseInt(p[1]), POSES), p[2], p[3], p[4],
                        ext ? Math.floorMod(Integer.parseInt(p[5]), FILTERS) : 0, ext ? Math.floorMod(Integer.parseInt(p[6]), FRAMES) : 0,
                        ext && p[7].equals("1"), ext ? Math.max(0, Integer.parseInt(p[8])) : 0);
            } catch (NumberFormatException ignored) { }
        }
    }

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < SLOTS; i++) {
            Photo p = album[i];
            sb.append(i > 0 ? ";" : "");
            sb.append(p == null ? ",,,,,,,," : p.bg() + "," + p.pose() + "," + p.head() + "," + p.body() + "," + p.species() + ","
                    + p.filter() + "," + p.frame() + "," + (p.flip() ? 1 : 0) + "," + p.day());
        }
        Store.write("photos", sb.toString());
    }

    private ComputerColor species() {
        ComputerColor c = PetApp.speciesOf(shell.color());
        return c == null ? shell.color() : c;
    }

    private static ComputerColor byId(String id) {
        for (ComputerColor c : ComputerColor.values()) if (c.id.equals(id)) return c;
        return ComputerColor.PINK;
    }

    // ---------- shooting ----------
    private int freeSlot() {
        for (int i = 0; i < SLOTS; i++) if (album[i] == null) return i;
        return -1;
    }

    /** The shutter button: shoots now, or starts (or cancels) the self-timer. */
    private void shoot() {
        if (cd > 0) { cd = 0; say("cutemod.photo.msg.cancel"); return; }
        if (freeSlot() < 0) { say("cutemod.photo.msg.full"); return; }
        if (timer == 0) { capture(); return; }
        cd = timer == 1 ? 180 : 300;
        Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 1.0F, 0.5F);
    }

    private void capture() {
        int slot = freeSlot();
        if (slot < 0) { say("cutemod.photo.msg.full"); return; }
        album[slot] = new Photo(bg, pose, Progress.equipped(), Progress.equippedBody(), species().id, filter, frame, flip, today());
        save();
        flash = 14;
        developing[slot] = 100;
        Sfx.ui(SoundEvents.UI_BUTTON_CLICK.value(), 1.4F, 0.6F);
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.9F, 0.4F);
        say("cutemod.photo.msg.saved", slot + 1);
    }

    /** Takes the settings of a photo back into the studio (to shoot the same picture again). */
    private void repeat(Photo p) {
        bg = p.bg(); pose = p.pose(); filter = p.filter(); frame = p.frame(); flip = p.flip();
        view = -1;
        armedDel = 0;
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.5F, 0.4F);
        say("cutemod.photo.msg.repeat");
    }

    @Override
    public void tick() {
        super.tick();
        if (flash > 0) flash--;
        if (armedDel > 0) armedDel--;
        for (int i = 0; i < SLOTS; i++) if (developing[i] > 0) developing[i]--;
        if (cd > 0) {
            cd--;
            if (cd == 0) capture();
            else if (cd % 60 == 0) Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 1.0F + (cd < 61 ? 0.5F : 0F), 0.5F);
        }
    }

    // ---------- the scene (drawn in a 170 x 100 box, scaled for the small prints) ----------
    private void scene(GuiGraphics g, int x, int y, float s, Photo p, boolean live) {
        ComputerColor spc = p == null ? species() : byId(p.species());
        int b = p == null ? bg : p.bg(), po = p == null ? pose : p.pose(), fl = p == null ? filter : p.filter(), fr = p == null ? frame : p.frame();
        boolean mirror = p == null ? flip : p.flip();
        String head = p == null ? Progress.equipped() : p.head(), body = p == null ? Progress.equippedBody() : p.body();
        int t = live ? ticks : 0;
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(s, s, 1F);
        StudioArt.backdrop(g, b, t);
        PetBlob.Info info = PetBlob.parse(Store.read("pet_" + spc.id));
        int stage = info == null ? 2 : info.stage();
        float sc = 1.25F * PetArt.scaleOf(stage);
        int px = VW / 2, floor = 88, bob = live ? (int) Math.round(Math.sin(ticks / 18.0) * 1.2) : 0;
        StudioArt.oval(g, px, floor + 3, 30, 4, b == 6 ? 0x2A000000 : 0x33000000);
        g.pose().pushPose();
        g.pose().translate(px, floor, 0);
        g.pose().scale(mirror ? -sc : sc, sc, 1F);
        g.pose().translate(-px, -floor, 0);
        // the mood of the face: 2 happy, 1 calm, 0 a tear; asleep is a pose of its own
        PetArt.draw(g, spc, px, floor - 28 + bob, po == 0 ? 2 : po == 3 ? 0 : 1, t, po == 2, false, stage, head, body);
        g.pose().popPose();
        StudioArt.filter(g, fl, t);
        StudioArt.frame(g, fr);
        g.pose().popPose();
    }

    private static String date(int day) {
        if (day <= 0) return "-";
        java.time.LocalDate d = java.time.LocalDate.ofEpochDay(day);
        return String.format("%02d.%02d.%d", d.getDayOfMonth(), d.getMonthValue(), d.getYear());
    }

    private static String itemName(String packed) {
        if (packed.isEmpty()) return "-";
        StringBuilder sb = new StringBuilder();
        for (String id : PetWear.layers(packed)) sb.append(sb.length() > 0 ? ", " : "").append(t("cutemod.shop.item." + id));
        return sb.toString();
    }

    // ---------- screen ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!loaded) load();
        header(g, f);
        // the camera body around the viewfinder
        rect(g, VX - 3, VY - 3, VW + 6, VH + 6, 0xFF3A3548);
        rect(g, VX - 3, VY - 3, VW + 6, 1, 0xFF5A5470);
        rect(g, VX - 3, VY + VH + 2, VW + 6, 1, 0xFF2A2638);
        rect(g, VX - 1, VY - 1, VW + 2, VH + 2, 0xFF14101C);
        Photo showing = view >= 0 ? album[view] : null;
        scene(g, VX, VY, 1F, showing, showing == null);
        if (showing == null) StudioArt.viewfinder(g, VX, VY, ticks, cd > 0);
        else if (developing[view] > 0) rect(g, VX, VY, VW, VH, (Math.min(255, developing[view] * 2) << 24) | 0xFFFFFF);
        if (flash > 0) rect(g, VX, VY, VW, VH, (flash * 16 << 24) | 0xFFFFFF);
        if (cd > 0 && view < 0) countdown(g, f);
        if (view >= 0 && album[view] != null) viewPanel(g, f, mx, my); else controls(g, f, mx, my);
        albumWall(g, f, mx, my);
        toast(g, f);
    }

    private void countdown(GuiGraphics g, Font f) {
        String d = Integer.toString((cd + 59) / 60);
        float sc = 4F;
        int cx = VX + VW / 2, cy = VY + VH / 2;
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().scale(sc, sc, 1F);
        CuteFont.draw(g, f, d, -f.width(d) / 2 + 1, -4 + 1, 0x88000000, false);
        CuteFont.draw(g, f, d, -f.width(d) / 2, -4, 0xFFFFFFFF, false);
        g.pose().popPose();
    }

    private void toast(GuiGraphics g, Font f) {
        if (msgT <= 0) return;
        String m = f.plainSubstrByWidth(msg, VW - 16);
        int w = f.width(m) + 12, x = VX + (VW - w) / 2;
        rect(g, x, VY + VH - 16, w, 13, 0xEE3A2A3A);
        CuteFont.draw(g, f, m, x + 6, VY + VH - 13, 0xFFFFFFFF, false);
    }

    private static int swX(int i) { return PX + (i % 4) * 28; }
    private static int swY(int i) { return 29 + (i / 4) * 11; }

    private void mini(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, int h, String label, boolean on) {
        boolean hov = in(mx, my, x, y, w, h);
        rect(g, x, y, w, h, on ? accent() : hov ? 0xFFFFEFF8 : 0xFFFFFFFF);
        rect(g, x, y + h - 2, w, 2, on ? 0x33000000 : 0xFFB9A8C8);
        String l = f.plainSubstrByWidth(label, w - 4);
        CuteFont.draw(g, f, l, x + (w - f.width(l)) / 2, y + (h - 8) / 2, on ? 0xFFFFFFFF : TEXT, false);
    }

    /** A selectable chip: the frame of the chosen one is the accent colour. */
    private void chip(GuiGraphics g, int mx, int my, int x, int y, int w, int h, boolean on) {
        boolean hov = in(mx, my, x, y, w, h);
        rect(g, x, y, w, h, on ? accent() : hov ? 0xFFB9C4F4 : 0xFFE4DDF0);
        rect(g, x + 1, y + 1, w - 2, h - 2, hov || on ? 0xFFFFFFFF : 0xFFF6F2FB);
    }

    private void controls(GuiGraphics g, Font f, int mx, int my) {
        // what the mouse points at: shown in the caption
        String cap = t("cutemod.photo.bg") + ": " + t("cutemod.photo.bg." + bg);
        for (int i = 0; i < BGS; i++) if (in(mx, my, swX(i), swY(i), 26, 10)) cap = t("cutemod.photo.bg") + ": " + t("cutemod.photo.bg." + i);
        for (int i = 0; i < POSES; i++) if (in(mx, my, PX + i * 28, 52, 26, 12)) cap = t("cutemod.photo.pose") + ": " + t("cutemod.photo.pose." + i);
        for (int i = 0; i < FILTERS; i++) if (in(mx, my, PX + i * 18, 65, 17, 12)) cap = t("cutemod.photo.filter") + ": " + t("cutemod.photo.filter." + i);
        for (int i = 0; i < FRAMES; i++) if (in(mx, my, PX + i * 22, 78, 20, 12)) cap = t("cutemod.photo.frame") + ": " + t("cutemod.photo.frame." + i);
        CuteFont.draw(g, f, f.plainSubstrByWidth(cap, 110), PX, 19, MUTED, false);
        // the paper rolls: the backdrops
        for (int i = 0; i < BGS; i++) {
            int x = swX(i), y = swY(i);
            boolean on = i == bg, hov = in(mx, my, x, y, 26, 10);
            rect(g, x - 1, y - 1, 28, 12, on ? accent() : hov ? 0xFFB9C4F4 : 0xFFE4DDF0);
            rect(g, x, y, 26, 5, StudioArt.ROLL[i][0]);
            rect(g, x, y + 5, 26, 5, StudioArt.ROLL[i][1]);
            rect(g, x, y, 26, 1, 0x44FFFFFF);
            rect(g, x + 1, y - 1, 3, 12, 0x33000000); rect(g, x + 22, y - 1, 3, 12, 0x22000000);        // the cardboard tube ends
        }
        for (int i = 0; i < POSES; i++) {
            int x = PX + i * 28;
            chip(g, mx, my, x, 52, 26, 12, i == pose);
            StudioArt.pose(g, i, x + 13, 58, i == pose ? accent() : 0xFF8A7AA8);
        }
        for (int i = 0; i < FILTERS; i++) {
            int x = PX + i * 18;
            chip(g, mx, my, x, 65, 17, 12, i == filter);
            StudioArt.filterChip(g, i, x + 2, 67);
        }
        for (int i = 0; i < FRAMES; i++) {
            int x = PX + i * 22;
            chip(g, mx, my, x, 78, 20, 12, i == frame);
            StudioArt.frameChip(g, i, x + 2, 80);
        }
        mini(g, f, mx, my, PX, 92, 54, 12, t("cutemod.photo.timer." + timer), timer != 0);
        mini(g, f, mx, my, PX + 56, 92, 54, 12, t("cutemod.photo.flip"), flip);
        boolean full = freeSlot() < 0;
        btn(g, f, mx, my, PX, 106, 110, cd > 0 ? t("cutemod.photo.stop") : t("cutemod.photo.shoot"), full && cd == 0 ? 2 : cd > 0 ? 0 : 1);
        if (!(full && cd == 0)) StudioArt.camera(g, PX + 8, 110, 0xFFFFFFFF);
    }

    /** The panel for a photo of the album: when it was taken, what the settings were, and what to do with it. */
    private void viewPanel(GuiGraphics g, Font f, int mx, int my) {
        Photo p = album[view];
        CuteFont.draw(g, f, t("cutemod.photo.no", view + 1), PX, 19, TEXT, false);
        CuteFont.draw(g, f, date(p.day()), PX, 29, MUTED, false);
        String[] lines = {
            t("cutemod.photo.bg") + ": " + t("cutemod.photo.bg." + p.bg()),
            t("cutemod.photo.pose") + ": " + t("cutemod.photo.pose." + p.pose()),
            t("cutemod.photo.filter") + ": " + t("cutemod.photo.filter." + p.filter()),
            t("cutemod.photo.frame") + ": " + t("cutemod.photo.frame." + p.frame()),
            itemName(p.head()), itemName(p.body())};
        for (int i = 0; i < lines.length; i++) CuteFont.draw(g, f, f.plainSubstrByWidth(lines[i], 110), PX, 42 + i * 8, i < 4 ? MUTED : 0xFF6A5A8A, false);
        btn(g, f, mx, my, PX, 90, 110, t("cutemod.photo.repeat"), 0);
        btn(g, f, mx, my, PX, 106, 54, t("cutemod.photo.back"), 1);
        btn(g, f, mx, my, PX + 56, 106, 54, armedDel > 0 ? t("cutemod.photo.sure") : t("cutemod.photo.delete"), 0);
    }

    /** The prints on a string, held by pegs. */
    private void albumWall(GuiGraphics g, Font f, int mx, int my) {
        rect(g, 3, ALBUM_Y - 3, 294, 1, 0xFFB9A8C8);
        for (int i = 0; i < SLOTS; i++) {
            int x = 6 + i * CARD_PITCH, y = ALBUM_Y;
            boolean sel = i == view, hov = in(mx, my, x, y, CARD_W, CARD_H) && album[i] != null;
            if (sel || hov) rect(g, x - 1, y - 1, CARD_W + 2, CARD_H + 2, sel ? 0xFFFFD84A : 0xFFB9C4F4);
            rect(g, x + 1, y + CARD_H, CARD_W, 2, 0x22000000);
            rect(g, x, y, CARD_W, CARD_H, 0xFFFFFFFF);
            StudioArt.peg(g, x + CARD_W / 2 - 2, y - 5);
            if (album[i] != null) {
                scene(g, x + 2, y + 2, 43F / VW, album[i], false);
                if (developing[i] > 0) rect(g, x + 2, y + 2, 43, 26, (Math.min(255, developing[i] * 2) << 24) | 0xFFFFFF);
                center(g, f, "#" + (i + 1), x + CARD_W / 2, y + 29, MUTED);
            } else {
                rect(g, x + 2, y + 2, 43, 26, 0xFFEFE7F6);
                center(g, f, "+", x + CARD_W / 2, y + 11, 0xFFC8BCD8);
            }
        }
    }

    // ---------- input ----------
    @Override
    public boolean key(int keyCode, int modifiers) {
        if (view >= 0) return false;
        if (keyCode == 32 || keyCode == 257) { shoot(); return true; }                     // Space, Enter
        if (keyCode == 263) { bg = Math.floorMod(bg - 1, BGS); return true; }                // arrows: the backdrop
        if (keyCode == 262) { bg = Math.floorMod(bg + 1, BGS); return true; }
        return false;
    }

    @Override
    public boolean click(int x, int y, int button) {
        // the prints
        for (int i = 0; i < SLOTS; i++) {
            if (in(x, y, 6 + i * CARD_PITCH, ALBUM_Y, CARD_W, CARD_H) && album[i] != null) {
                view = view == i ? -1 : i;
                armedDel = 0;
                Sfx.ui(SoundEvents.UI_BUTTON_CLICK.value(), 1.6F, 0.4F);
                return true;
            }
        }
        if (view >= 0 && album[view] != null) {
            if (in(x, y, PX, 90, 110, 16)) { repeat(album[view]); return true; }
            if (in(x, y, PX, 106, 54, 16)) { view = -1; armedDel = 0; return true; }
            if (in(x, y, PX + 56, 106, 54, 16)) {
                if (armedDel == 0) { armedDel = 150; say("cutemod.photo.msg.sure"); return true; }
                album[view] = null;
                developing[view] = 0;
                view = -1;
                armedDel = 0;
                save();
                say("cutemod.photo.msg.deleted");
                return true;
            }
            return false;
        }
        for (int i = 0; i < BGS; i++) if (in(x, y, swX(i), swY(i), 26, 10)) { bg = i; pick(); return true; }
        for (int i = 0; i < POSES; i++) if (in(x, y, PX + i * 28, 52, 26, 12)) { pose = i; pick(); return true; }
        for (int i = 0; i < FILTERS; i++) if (in(x, y, PX + i * 18, 65, 17, 12)) { filter = i; pick(); return true; }
        for (int i = 0; i < FRAMES; i++) if (in(x, y, PX + i * 22, 78, 20, 12)) { frame = i; pick(); return true; }
        if (in(x, y, PX, 92, 54, 12)) { timer = (timer + 1) % 3; pick(); return true; }
        if (in(x, y, PX + 56, 92, 54, 12)) { flip = !flip; pick(); return true; }
        if (in(x, y, PX, 106, 110, 16)) { shoot(); return true; }
        return false;
    }

    private void pick() { Sfx.ui(SoundEvents.UI_BUTTON_CLICK.value(), 1.7F, 0.3F); }
}
