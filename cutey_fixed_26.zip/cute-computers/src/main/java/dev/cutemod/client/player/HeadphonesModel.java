package dev.cutemod.client.player;

import dev.cutemod.CuteMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;

/**
 * The headphones on the head: a real 3D model (band over the head, two risers, two cups with a heart plate) instead of the flat
 * armor texture glued to the helmet box. The cubes are written by tools/make_headphones.py (do not edit them by hand: edit the
 * script and run it again, it also redraws textures/models/armor/headphones_layer_1.png and the item model).
 * The texture is still the armor layer of the material, so everything else (slot, right click) stays as it was.
 */
public final class HeadphonesModel {
    private HeadphonesModel() {}

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "headphones"), "main");

    private static HumanoidModel<LivingEntity> baked;
    private static HumanoidModel<LivingEntity> bakedRgb;

    /** Called after every resource reload: the model is baked again at the next frame. */
    public static void reset() { baked = null; bakedRgb = null; }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create()
                // bar
                .texOffs(0, 8).addBox(-4F, -9.6F, -1F, 8F, 1F, 2F)
                // step_r
                .texOffs(20, 8).addBox(4F, -9.1F, -1F, 1F, 1F, 2F)
                // riser_r
                .texOffs(40, 0).addBox(4.6F, -8.6F, -1F, 1F, 3F, 2F)
                // cup_r
                .texOffs(0, 0).addBox(3.9F, -6F, -2F, 2F, 4F, 4F, new CubeDeformation(0.2F))
                // plate_r
                .texOffs(24, 0).addBox(5.8F, -5.5F, -1.5F, 1F, 3F, 3F, new CubeDeformation(-0.15F))
                // step_l
                .texOffs(26, 8).addBox(-5F, -9.1F, -1F, 1F, 1F, 2F)
                // riser_l
                .texOffs(46, 0).addBox(-5.6F, -8.6F, -1F, 1F, 3F, 2F)
                // cup_l
                .texOffs(12, 0).addBox(-5.9F, -6F, -2F, 2F, 4F, 4F, new CubeDeformation(0.2F))
                // plate_l
                .texOffs(32, 0).addBox(-6.8F, -5.5F, -1.5F, 1F, 3F, 3F, new CubeDeformation(-0.15F)),
                PartPose.ZERO);
        // the humanoid model wants all of its parts, the others stay empty
        for (String n : new String[]{"hat", "body", "right_arm", "left_arm", "right_leg", "left_leg"})
            root.addOrReplaceChild(n, CubeListBuilder.create(), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 32);
    }

    private static HumanoidModel<LivingEntity> model() {
        if (baked == null) baked = new HumanoidModel<>(Minecraft.getInstance().getEntityModels().bakeLayer(LAYER));
        return baked;
    }

    /**
     * The RGB headphones: the same shape, but the whole model is tinted with a running rainbow colour and drawn at full brightness
     * (it glows in the dark). The texture is dark with white glowing parts, so only the glowing parts really take the colour.
     */
    private static final class RgbModel extends HumanoidModel<LivingEntity> {
        RgbModel(ModelPart root) { super(root); }

        @Override
        public void renderToBuffer(PoseStack pose, VertexConsumer buf, int light, int overlay, int color) {
            float hue = (net.minecraft.Util.getMillis() % 4000L) / 4000F;
            super.renderToBuffer(pose, buf, LightTexture.FULL_BRIGHT, overlay, 0xFF000000 | net.minecraft.util.Mth.hsvToRgb(hue, 0.85F, 1F));
        }
    }

    private static HumanoidModel<LivingEntity> rgbModel() {
        if (bakedRgb == null) bakedRgb = new RgbModel(Minecraft.getInstance().getEntityModels().bakeLayer(LAYER));
        return bakedRgb;
    }

    /** Tells the armor layer to draw our model instead of the helmet box. */
    public static final class Ext implements IClientItemExtensions {
        @Override
        public HumanoidModel<?> getHumanoidArmorModel(LivingEntity entity, ItemStack stack, EquipmentSlot slot, HumanoidModel<?> original) {
            var rgb = dev.cutemod.item.ModItems.COLOR_HEADPHONES.get("rgb");
            return rgb != null && stack.is(rgb.get()) ? rgbModel() : model();
        }
    }
}
