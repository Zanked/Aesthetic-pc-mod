package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/** Pictures for the little shops of the pet: the dressing room, the trophy room, the page backgrounds. Pure drawing. */
final class PetShops {
    private PetShops() {}

    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(1 - (dy * dy) / (double) (ry * ry + 1)));
            rect(g, cx - dx, cy + dy, dx * 2 + 1, 1, argb);
        }
    }

    private static void ln(GuiGraphics g, int x0, int y0, int x1, int y1, int argb) {
        int n = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)));
        for (int i = 0; i < n + 1; i++) rect(g, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, 1, 1, argb);
    }

    private static void sparkle(GuiGraphics g, int x, int y, int argb) {
        rect(g, x, y - 2, 1, 5, argb); rect(g, x - 2, y, 5, 1, argb);
    }

    /** The backdrop of the dressing room: x,y,w,h = 106 x 104 (floor line at y + 92). */
    static void dressing(GuiGraphics g, int x, int y, int w, int h, boolean showing, int t) {
        int fl = y + h - 12;
        g.fillGradient(x, y, x + w, fl, showing ? 0xFFFFF6C8 : 0xFFF3E6FA, showing ? 0xFFFFE9A0 : 0xFFE4D2F2);
        for (int i = 0; i < w; i += 8) rect(g, x + i, y, 3, fl - y, 0x14B57BD6);                   // soft wall stripes
        rect(g, x, fl - 14, w, 14, 0x22B57BD6);                                                     // wainscot
        rect(g, x, fl - 14, w, 1, 0x55FFFFFF);
        for (int i = 0; i < w; i += 14) rect(g, x + i, fl - 12, 1, 12, 0x15000000);
        // floor boards and a round rug
        g.fillGradient(x, fl, x + w, y + h, 0xFFD9B58A, 0xFFC09468);
        for (int i = 0; i < w; i += 13) rect(g, x + i, fl, 1, y + h - fl, 0x22000000);
        rect(g, x, fl, w, 1, 0xFF8A6642);
        oval(g, x + w / 2, fl + 6, 42, 5, 0xFFF59AB8); oval(g, x + w / 2, fl + 6, 36, 4, 0xFFFFD0E0); oval(g, x + w / 2, fl + 6, 28, 3, 0xFFF59AB8);
        // the spotlight on the pet
        for (int i = 0; i < 6; i++) rect(g, x + w / 2 - 8 - i * 3, y + i * 3, 16 + i * 6, 3, showing ? 0x18FFFFFF : 0x0CFFFFFF);
        rect(g, x + w / 2 - 6, y, 12, 3, 0xFF8A7A9A); rect(g, x + w / 2 - 4, y + 3, 8, 2, 0xFFFFF3B0);
        // curtains left and right, tied back
        for (int side = 0; side < 2; side++) {
            int cx = side == 0 ? x : x + w - 14;
            rect(g, cx, y, 14, fl - y, 0xFFC84A7A);
            for (int i = 0; i < 14; i += 4) rect(g, cx + i, y, 2, fl - y, 0x30000000);
            for (int i = 2; i < 14; i += 4) rect(g, cx + i, y, 1, fl - y, 0x30FFFFFF);
            rect(g, cx, y + 40, 14, 3, 0xFFF5C84A);                                                // the tie
            int ew = side == 0 ? 14 : 0;
            rect(g, cx + (side == 0 ? 12 : 0), y + 40, 2, 3, 0xFFFFE8A0);
        }
        rect(g, x, y, w, 4, 0xFF8A4A2A); rect(g, x, y + 4, w, 1, 0x33000000);                      // the rod
        for (int i = 0; i < 7; i++) rect(g, x + 3 + i * 16, y + 4, 4, 2, 0xFFF5C84A);               // rings
        // a mirror at the right, a hanger with a hat at the left
        int mx = x + w - 38, my = y + 14;
        rect(g, mx - 2, my - 2, 20, 52, 0xFFF5C84A); rect(g, mx, my, 16, 48, 0xFFCFEAF8); rect(g, mx, my, 16, 48, 0x22FFFFFF);
        for (int i = 0; i < 5; i++) ln(g, mx + 2 + i * 3, my + 44, mx + 8 + i * 3, my + 24, 0x33FFFFFF);
        rect(g, mx + 2, my + 3, 3, 6, 0x88FFFFFF);
        rect(g, mx + 4, my + 50, 8, 2, 0xFF8A4A2A);
        int hx = x + 20;
        rect(g, hx, y + 18, 1, 5, 0xFF8A7A9A); rect(g, hx - 3, y + 22, 8, 1, 0xFF8A7A9A);
        rect(g, hx - 6, y + 24, 14, 3, 0xFF6A8CE8); rect(g, hx - 3, y + 18 + 8, 8, 1, 0xFF6A8CE8);
        disc(g, hx + 1, y + 31, 3, 0xFFFFFFFF);
        if (showing) for (int i = 0; i < 6; i++) {
            int a = (t / 6 + i * 3) % 12;
            if (a < 6) sparkle(g, x + 24 + (i * 37) % 60, y + 14 + (i * 23) % 60, 0xCCFFFFFF);
        }
        oval(g, x + w / 2, fl + 4, 20, 3, 0x2A000000);
    }

    /** The trophy room behind the portrait of the stats: x,y,w,h = 100 x 112 (floor line at y + 96). */
    static void trophies(GuiGraphics g, int x, int y, int w, int h, int t) {
        int fl = y + h - 16;
        g.fillGradient(x, y, x + w, fl, 0xFFFFF3D8, 0xFFFFE6B0);
        for (int r = 0; r < fl - y; r += 6) for (int c = (r / 6 % 2) * 5; c < w; c += 10) rect(g, x + c, y + r, 2, 2, 0x14E8A04A);    // wallpaper dots
        rect(g, x, y, w, 3, 0xFFC87A2A); rect(g, x, y + 3, w, 1, 0x33000000);                     // crown moulding
        g.fillGradient(x, fl, x + w, y + h, 0xFFE0B880, 0xFFC89A60);
        rect(g, x, fl, w, 2, 0xFF8A5A2A);
        for (int i = 0; i < w; i += 16) rect(g, x + i, fl + 2, 1, y + h - fl - 2, 0x22000000);
        // a shelf with three little trophies
        int sy = y + 50;
        rect(g, x + 6, sy, 88, 3, 0xFF8A5A2A); rect(g, x + 6, sy + 3, 88, 1, 0x33000000);
        rect(g, x + 12, sy + 4, 3, 4, 0xFF6A4228); rect(g, x + 85, sy + 4, 3, 4, 0xFF6A4228);
        // cup
        rect(g, x + 14, sy - 10, 9, 6, 0xFFF5C84A); rect(g, x + 16, sy - 4, 5, 2, 0xFFF5C84A); rect(g, x + 13, sy - 2, 11, 2, 0xFFC8962A);
        rect(g, x + 12, sy - 9, 2, 3, 0xFFF5C84A); rect(g, x + 23, sy - 9, 2, 3, 0xFFF5C84A); rect(g, x + 15, sy - 9, 2, 3, 0x66FFFFFF);
        // medal on a ribbon
        rect(g, x + 46, sy - 12, 2, 6, 0xFFE5484D); rect(g, x + 50, sy - 12, 2, 6, 0xFF4D96FF);
        disc(g, x + 49, sy - 5, 4, 0xFFF5C84A); disc(g, x + 49, sy - 5, 2, 0xFFFFE9A0);
        // a small heart statue
        rect(g, x + 76, sy - 9, 3, 3, 0xFFE0508A); rect(g, x + 80, sy - 9, 3, 3, 0xFFE0508A); rect(g, x + 76, sy - 7, 7, 3, 0xFFE0508A);
        rect(g, x + 77, sy - 4, 5, 1, 0xFFE0508A); rect(g, x + 78, sy - 3, 3, 1, 0xFFE0508A);
        rect(g, x + 76, sy - 2, 7, 2, 0xFF8A5A2A);
        // a frame with a star, a window on the other side
        rect(g, x + 8, y + 8, 22, 16, 0xFF8A5A2A); rect(g, x + 10, y + 10, 18, 12, 0xFFFFF3B0);
        int sx = x + 19, sy2 = y + 16;
        rect(g, sx - 1, sy2 - 4, 3, 9, 0xFFF0B020); rect(g, sx - 4, sy2 - 1, 9, 3, 0xFFF0B020);
        rect(g, x + 66, y + 7, 26, 18, 0xFF8A5A2A); rect(g, x + 68, y + 9, 22, 14, 0xFF9AD8FF);
        rect(g, x + 78, y + 9, 2, 14, 0xFF8A5A2A);
        disc(g, x + 72 + (t / 40) % 6, y + 14, 3, 0xDDFFFFFF);
        // a rug and lights
        oval(g, x + w / 2, fl + 8, 40, 4, 0xFFE8A04A); oval(g, x + w / 2, fl + 8, 34, 3, 0xFFFFD890);
        for (int i = 0; i < 9; i++) {
            int bx = x + 4 + i * 11, by = y + 4 + (i % 2) * 2;
            rect(g, bx, by, 3, 3, i % 3 == 0 ? 0xFFE5484D : i % 3 == 1 ? 0xFFFFD84A : 0xFF4D96FF);
            if ((t / 12 + i) % 4 == 0) rect(g, bx - 1, by - 1, 5, 5, 0x33FFFFFF);
        }
        oval(g, x + w / 2, fl + 6, 22, 3, 0x2A000000);
    }

    /** The wooden board under the noughts and crosses: x,y,w,h. */
    static void board(GuiGraphics g, int x, int y, int w, int h) {
        rect(g, x + 2, y + h, w, 3, 0x33000000);
        rect(g, x, y, w, h, 0xFFB07840);
        rect(g, x + 2, y + 2, w - 4, h - 4, 0xFFD9A468);
        for (int i = 0; i < h; i += 7) rect(g, x + 2, y + 4 + i, w - 4, 1, 0x1A6A4228);
        rect(g, x, y, w, 1, 0x44FFFFFF);
        for (int[] p : new int[][]{{x + 3, y + 3}, {x + w - 5, y + 3}, {x + 3, y + h - 5}, {x + w - 5, y + h - 5}}) rect(g, p[0], p[1], 2, 2, 0xFFF5C84A);
    }

    /** A soft pattern for the page of a little shop: dots in the colour of the app, fading to the bottom. */
    static void page(GuiGraphics g, int w, int h, int accent) {
        g.fillGradient(0, 14, w, h, 0xFFFFF4FA, 0xFFFBE8F4);
        int c = (accent & 0xFFFFFF) | 0x12000000;
        for (int r = 16; r < h; r += 8) for (int cc = (r / 8 % 2) * 6; cc < w; cc += 12) rect(g, cc, r, 2, 2, c);
    }

    /** The bar at the top: a lighter band, a scalloped edge and two sparkles. */
    static void bar(GuiGraphics g, int w, int accent) {
        rect(g, 0, 0, w, 14, accent);
        rect(g, 0, 0, w, 2, 0x33FFFFFF);
        rect(g, 0, 12, w, 2, 0x22000000);
        for (int i = 0; i < w; i += 6) { rect(g, i, 14, 4, 1, accent); rect(g, i + 1, 15, 2, 1, accent & 0x00FFFFFF | 0x88000000); }
        sparkle(g, w - 14, 7, 0x55FFFFFF);
    }

    // ---------------------------------------------------------------- the boutique (PetStyle)

    /** The accent of the shop awning for each tab: outfits, wardrobe, shop. */
    private static final int[] AWNING = {0xFFB57BD6, 0xFF6FB8E8, 0xFFFF8AB0};
    private static final int[] GARMENT = {0xFFFF8AB0, 0xFF6FB8E8, 0xFFFFD84A, 0xFF7ED9A0, 0xFFB57BD6};

    /**
     * The fitting room of a little clothes shop: x,y,w,h = 106 x 100 (floor line at y + h - 12). An awning, a rail with
     * hangers and little garments, a mirror, a table with folded clothes, a round fitting stage under the pet.
     * mode: 0 outfits, 1 wardrobe, 2 shop (a hanging price tag swings at the left).
     */
    static void boutique(GuiGraphics g, int x, int y, int w, int h, boolean showing, int t, int mode) {
        int fl = y + h - 12;
        int ac = AWNING[Math.floorMod(mode, 3)];
        g.fillGradient(x, y, x + w, fl, showing ? 0xFFFFF6D8 : 0xFFFFEEF6, showing ? 0xFFFFE6B8 : 0xFFF8DDEB);
        for (int i = 0; i < w; i += 10) rect(g, x + i, y, 1, fl - y, 0x10B57BD6);                   // soft wall stripes
        rect(g, x, fl - 12, w, 12, 0x22B57BD6);                                                     // wainscot
        rect(g, x, fl - 12, w, 1, 0x66FFFFFF);
        // the floor: boards, and the round fitting stage
        g.fillGradient(x, fl, x + w, y + h, 0xFFE0C093, 0xFFC49A6A);
        for (int i = 0; i < w; i += 13) rect(g, x + i, fl, 1, y + h - fl, 0x22000000);
        rect(g, x, fl, w, 1, 0xFF8A6642);
        oval(g, x + w / 2, fl + 3, 34, 6, 0x33000000);
        oval(g, x + w / 2, fl + 1, 32, 5, 0xFFF3E6FA); oval(g, x + w / 2, fl, 29, 4, 0xFFFFFFFF); oval(g, x + w / 2, fl, 20, 3, 0xFFFFE4F0);
        // the spotlight on the pet
        for (int i = 0; i < 6; i++) rect(g, x + w / 2 - 8 - i * 3, y + 12 + i * 8, 16 + i * 6, 8, showing ? 0x16FFFFFF : 0x0AFFFFFF);
        // the rail with hangers and little garments
        rect(g, x + 6, y + 17, w - 12, 2, 0xFFB9A8C8); rect(g, x + 4, y + 15, 2, 6, 0xFF8A7A9A); rect(g, x + w - 6, y + 15, 2, 6, 0xFF8A7A9A);
        for (int i = 0; i < 5; i++) {
            int hx = x + 14 + i * 19, sway = ((t / 40 + i) % 5 == 0) ? 1 : 0, col = GARMENT[(i + mode) % GARMENT.length];
            rect(g, hx + sway, y + 19, 1, 2, 0xFF8A7A9A);
            rect(g, hx - 4 + sway, y + 21, 9, 1, 0xFF8A7A9A);
            rect(g, hx - 4 + sway, y + 22, 9, 6, col);
            rect(g, hx - 6 + sway, y + 22, 3, 3, col); rect(g, hx + 4 + sway, y + 22, 3, 3, col);
            rect(g, hx - 1 + sway, y + 22, 3, 1, 0x55FFFFFF);
            rect(g, hx - 4 + sway, y + 27, 9, 1, 0x22000000);
        }
        // the awning: stripes with a scalloped edge
        for (int i = 0; i * 8 < w; i++) {
            int sx = x + i * 8, sw = Math.min(8, x + w - sx), col = i % 2 == 0 ? ac : 0xFFFFFFFF;
            rect(g, sx, y, sw, 9, col);
            rect(g, sx, y + 9, sw, 1, col);
            if (sw >= 8) { rect(g, sx + 1, y + 10, 6, 1, col); rect(g, sx + 2, y + 11, 4, 1, col); }
        }
        rect(g, x, y, w, 2, 0x33FFFFFF); rect(g, x, y + 8, w, 1, 0x14000000);
        // a mirror at the right
        int mx = x + w - 17, my = y + 34;
        rect(g, mx - 1, my - 1, 14, 40, 0xFFF5C84A); rect(g, mx, my, 12, 38, 0xFFCFEAF8);
        for (int i = 0; i < 4; i++) ln(g, mx + 2 + i * 3, my + 34, mx + 6 + i * 3, my + 20, 0x33FFFFFF);
        rect(g, mx + 2, my + 3, 2, 5, 0x99FFFFFF);
        rect(g, mx + 3, my + 39, 6, 2, 0xFF8A4A2A);
        // a little table with folded clothes at the left
        rect(g, x + 2, fl - 9, 17, 2, 0xFF9A6A3A); rect(g, x + 3, fl - 7, 2, 8, 0xFF7A4A2A); rect(g, x + 16, fl - 7, 2, 8, 0xFF7A4A2A);
        rect(g, x + 3, fl - 12, 14, 3, 0xFF6FB8E8); rect(g, x + 4, fl - 15, 12, 3, 0xFFFF8AB0); rect(g, x + 5, fl - 18, 10, 3, 0xFFFFD84A);
        rect(g, x + 4, fl - 12, 12, 1, 0x44FFFFFF); rect(g, x + 5, fl - 15, 10, 1, 0x44FFFFFF);
        if (mode == 2) {                                                                              // a price tag on a string (swings a little)
            int tx = x + 24 + ((t / 24) % 2), ty = y + 32;
            rect(g, tx + 3, y + 12, 1, ty - y - 12, 0xFFB9A8C8);
            rect(g, tx, ty, 8, 11, 0xFFFFF3B0); rect(g, tx + 3, ty + 2, 2, 2, 0xFF8A7A9A);
            rect(g, tx + 1, ty + 5, 6, 1, 0xFFE5486F); rect(g, tx + 1, ty + 7, 6, 1, 0xFFE5486F);
        }
        if (showing) for (int i = 0; i < 6; i++) {
            int a = (t / 6 + i * 3) % 12;
            if (a < 6) sparkle(g, x + 24 + (i * 37) % 54, y + 38 + (i * 23) % 46, 0xCCFFFFFF);
        }
    }

    /** A wooden shelf board under a row of things: x,y,w. */
    static void plank(GuiGraphics g, int x, int y, int w) {
        rect(g, x, y, w, 3, 0xFFC49A60);
        rect(g, x, y, w, 1, 0x66FFFFFF);
        rect(g, x, y + 2, w, 1, 0x33000000);
        rect(g, x + 1, y + 3, w - 2, 1, 0x14000000);
    }

    /** The little pictures of the layer chips (about 9 x 8, centred on cx, cy): 0 all, 1 head, 2 face, 3 neck, 4 over the body, 5 body. */
    static void chip(GuiGraphics g, int kind, int cx, int cy, int col, int bg) {
        switch (kind) {
            case 0 -> { rect(g, cx - 4, cy - 3, 3, 3, col); rect(g, cx + 1, cy - 3, 3, 3, col); rect(g, cx - 4, cy + 1, 3, 3, col); rect(g, cx + 1, cy + 1, 3, 3, col); }
            case 1 -> { rect(g, cx - 4, cy, 9, 3, col); rect(g, cx - 4, cy - 3, 2, 3, col); rect(g, cx - 1, cy - 4, 3, 4, col); rect(g, cx + 3, cy - 3, 2, 3, col); }
            case 2 -> { rect(g, cx - 5, cy - 2, 5, 5, col); rect(g, cx + 1, cy - 2, 5, 5, col); rect(g, cx - 4, cy - 1, 3, 3, bg); rect(g, cx + 2, cy - 1, 3, 3, bg); rect(g, cx - 1, cy - 1, 2, 1, col); }
            case 3 -> { rect(g, cx - 4, cy - 3, 9, 3, col); rect(g, cx + 1, cy, 3, 4, col); rect(g, cx - 3, cy - 2, 2, 1, bg); }
            case 4 -> { rect(g, cx - 3, cy - 3, 7, 1, col); rect(g, cx - 4, cy - 2, 9, 1, col); rect(g, cx - 5, cy - 1, 11, 4, col); rect(g, cx - 1, cy - 2, 1, 5, bg); }
            default -> { rect(g, cx - 3, cy - 3, 7, 7, col); rect(g, cx - 5, cy - 3, 2, 3, col); rect(g, cx + 4, cy - 3, 2, 3, col); rect(g, cx - 1, cy - 3, 3, 1, bg); }
        }
    }

    /** A little padlock (5 x 7). */
    static void lock(GuiGraphics g, int x, int y, int col) {
        rect(g, x + 1, y, 3, 1, col); rect(g, x, y + 1, 1, 2, col); rect(g, x + 4, y + 1, 1, 2, col);
        rect(g, x, y + 3, 5, 4, col); rect(g, x + 2, y + 4, 1, 2, 0xFFFFFFFF);
    }

    /** A tiny heart (5 x 5): the mark of a thing that is worn now. */
    static void heart5(GuiGraphics g, int x, int y, int col) {
        rect(g, x, y, 2, 2, col); rect(g, x + 3, y, 2, 2, col); rect(g, x, y + 1, 5, 2, col); rect(g, x + 1, y + 3, 3, 1, col); rect(g, x + 2, y + 4, 1, 1, col);
    }

    /** A little dice (11 x 11) with five pips: the button of a surprise look. */
    static void dice(GuiGraphics g, int x, int y, int col) {
        rect(g, x, y, 11, 11, col); rect(g, x + 1, y + 1, 9, 9, 0xFFFFFFFF);
        for (int[] p : new int[][]{{2, 2}, {7, 2}, {4, 4}, {2, 7}, {7, 7}}) rect(g, x + p[0], y + p[1], 2, 2, col);
    }
}
