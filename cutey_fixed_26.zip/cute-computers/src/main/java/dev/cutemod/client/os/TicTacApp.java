package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;

import java.util.Random;

/**
 * Tic-Tac-Toe with your pet, on a wooden board. You are the hearts, the pet plays the stars; the pet sits next to the
 * board in its own little room (in its clothes), thinks, talks in a speech bubble and cheers or cries. Three levels:
 * easy (random), normal (wins and blocks when it can) and hard (never loses). You choose who starts (or toss a coin).
 * A win pays 2 / 4 / 6 coins, at most 30 coins a day. Score, win streak and best streak are kept ("tttstat").
 * Keys 1-9 play the cells in reading order.
 */
public class TicTacApp extends KitApp {
    private static final int BX = 99, BY = 23, CELL = 33;
    private static final int[][] LINES = {{0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, {0, 4, 8}, {2, 4, 6}};
    private static final int CAP = 30;

    private static final String[] HEART = {
        ".###...###.",
        "#####.#####",
        "###########",
        "###########",
        ".#########.",
        "..#######..",
        "...#####...",
        "....###....",
        ".....#....."};
    private static final String[] STAR = {
        ".....#.....",
        ".....#.....",
        "....###....",
        "###########",
        ".#########.",
        "..#######..",
        "..#######..",
        ".####.####.",
        ".###...###.",
        ".#.......#."};

    private final int[] b = new int[9];            // 0 empty, 1 you, 2 the pet
    private final int[] age = new int[9];          // ticks since a mark was placed (for the pop-in)
    private final Random rnd = new Random();
    private int level = 1, first;                  // first: 0 you, 1 the pet, 2 a coin toss
    private int wins, losses, draws, streak, best;
    private int over;                              // 0 playing, 1 you won, 2 pet won, 3 draw
    private int petWait;                           // ticks until the pet moves
    private int winT, celebrate, bubbleT;
    private int[] winLine;
    private String bubble = "";

    @Override protected int accent() { return 0xFF6FB8E8; }

    @Override protected String id() { return "tictac"; }

    private void reset() {
        java.util.Arrays.fill(b, 0);
        java.util.Arrays.fill(age, 100);
        over = 0;
        winLine = null;
        winT = 0;
        celebrate = 0;
        boolean petStarts = first == 1 || (first == 2 && rnd.nextBoolean());
        petWait = petStarts ? 40 : 0;
        chat(petStarts ? "think" : "idle");
    }

    @Override
    public void attach(Shell shell) { super.attach(shell); loadStats(); reset(); }

    // ---------- the score is kept ----------
    private void loadStats() {
        try {
            String s = Store.read("tttstat");
            if (s == null || s.isBlank()) return;
            String[] p = s.split(",", -1);
            if (p.length < 4) return;
            wins = Math.max(0, Integer.parseInt(p[0]));
            losses = Math.max(0, Integer.parseInt(p[1]));
            draws = Math.max(0, Integer.parseInt(p[2]));
            best = Math.max(0, Integer.parseInt(p[3]));
        } catch (NumberFormatException ignored) { }
    }

    private void saveStats() { Store.write("tttstat", wins + "," + losses + "," + draws + "," + best); }

    private void chat(String state) {
        bubble = t("cutemod.ttt.say." + state + "." + rnd.nextInt(2));
        bubbleT = 300;
    }

    // ---------- the game ----------
    private int winner() {
        for (int[] l : LINES) if (b[l[0]] != 0 && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) { winLine = l; return b[l[0]]; }
        for (int v : b) if (v == 0) return 0;
        return 3;
    }

    private void finish() {
        int w = winner();
        if (w == 0) return;
        over = w;
        if (w == 1) {
            wins++;
            streak++;
            best = Math.max(best, streak);
            int pay = Math.min(level == 0 ? 2 : level == 1 ? 4 : 6, CAP - paidToday("ttt"));
            if (pay > 0) { Progress.earn(pay); addPaid("ttt", pay); }
            celebrate = 160;
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.6F, 0.6F);
            Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.6F);
            say(pay > 0 ? "cutemod.ttt.msg.win" : "cutemod.ttt.msg.wincap", pay);
            chat("lose");
        } else if (w == 2) {
            losses++;
            streak = 0;
            Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 0.7F, 0.5F);
            say("cutemod.ttt.msg.lose");
            chat("win");
        } else {
            draws++;
            Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 1.1F, 0.4F);
            say("cutemod.ttt.msg.draw");
            chat("draw");
        }
        saveStats();
    }

    private int pick() {
        if (level == 0) return randomFree();
        int m = finishing(2); if (m >= 0) return m;
        m = finishing(1); if (m >= 0) return m;
        if (level == 2) return best();
        return b[4] == 0 && rnd.nextInt(3) > 0 ? 4 : randomFree();
    }

    private int finishing(int who) {
        for (int[] l : LINES) {
            int n = 0, free = -1;
            for (int c : l) { if (b[c] == who) n++; else if (b[c] == 0) free = c; }
            if (n == 2 && free >= 0) return free;
        }
        return -1;
    }

    private int randomFree() {
        int n = 0;
        for (int v : b) if (v == 0) n++;
        int k = rnd.nextInt(Math.max(1, n));
        for (int i = 0; i < 9; i++) if (b[i] == 0 && k-- == 0) return i;
        return -1;
    }

    /** Perfect play (minimax): the best cell for the pet. */
    private int best() {
        int bestCell = -1, bestScore = -2;
        for (int i = 0; i < 9; i++) {
            if (b[i] != 0) continue;
            b[i] = 2;
            int sc = -search(1);
            b[i] = 0;
            if (sc > bestScore || (sc == bestScore && rnd.nextInt(3) == 0)) { bestScore = sc; bestCell = i; }
        }
        return bestCell;
    }

    /** Score for the player to move (who): 1 win, 0 draw, -1 loss. */
    private int search(int who) {
        int w = lineWinner();
        if (w != 0) return w == who ? 1 : -1;
        boolean any = false;
        int best = -2;
        for (int i = 0; i < 9; i++) {
            if (b[i] != 0) continue;
            any = true;
            b[i] = who;
            best = Math.max(best, -search(3 - who));
            b[i] = 0;
        }
        return any ? best : 0;
    }

    private int lineWinner() {
        for (int[] l : LINES) if (b[l[0]] != 0 && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) return b[l[0]];
        return 0;
    }

    private void play(int i) {
        if (over != 0 || petWait > 0 || i < 0 || i > 8 || b[i] != 0) return;
        b[i] = 1;
        age[i] = 0;
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.5F, 0.4F);
        finish();
        if (over == 0) { petWait = level == 2 ? 32 : 22; if (rnd.nextInt(3) == 0) chat("think"); }
    }

    @Override
    public void tick() {
        super.tick();
        for (int i = 0; i < 9; i++) if (age[i] < 100) age[i]++;
        if (over == 1 || over == 2) { if (winT < 40) winT++; }
        if (celebrate > 0) celebrate--;
        if (bubbleT > 0) bubbleT--;
        if (over == 0 && petWait > 0 && --petWait == 0) {
            int c = pick();
            if (c >= 0) { b[c] = 2; age[c] = 0; Sfx.ui(SoundEvents.NOTE_BLOCK_BELL.value(), 1.2F, 0.4F); }
            finish();
        }
    }

    // ---------- drawing ----------
    /** A little picture from a bitmap (each '#' is one square of px pixels), centred on cx, cy. */
    private static void bmp(GuiGraphics g, String[] rows, int cx, int cy, int px, int col, int outline, int shine) {
        int w = rows[0].length(), h = rows.length, x0 = cx - w * px / 2, y0 = cy - h * px / 2;
        if (outline != 0) {
            for (int[] o : new int[][]{{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {0, 2}})
                for (int r = 0; r < h; r++) for (int c = 0; c < w; c++) if (rows[r].charAt(c) == '#') rect(g, x0 + c * px + o[0], y0 + r * px + o[1], px, px, outline);
        }
        for (int r = 0; r < h; r++) for (int c = 0; c < w; c++) if (rows[r].charAt(c) == '#') rect(g, x0 + c * px, y0 + r * px, px, px, col);
        if (shine != 0) rect(g, x0 + px, y0 + px, px * 2, px, shine);
    }

    static void heart(GuiGraphics g, int cx, int cy) { bmp(g, HEART, cx, cy, 2, 0xFFE0508A, 0xFFA02458, 0xFFFFB0CC); }

    static void star(GuiGraphics g, int cx, int cy) { bmp(g, STAR, cx, cy, 2, 0xFFF5BE28, 0xFFB07A10, 0xFFFFEFA0); }

    /** A mark that pops in: it grows past its size and settles. */
    private static void mark(GuiGraphics g, boolean heart, int cx, int cy, int age) {
        float s = age >= 12 ? 1F : age >= 8 ? 1.12F - 0.12F * (age - 8) / 4F : 0.3F + 0.82F * age / 8F;
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().scale(s, s, 1F);
        if (heart) heart(g, 0, 0); else star(g, 0, 0);
        g.pose().popPose();
    }

    private ComputerColor species() {
        ComputerColor c = PetApp.speciesOf(shell.color());
        return c == null ? shell.color() : c;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        header(g, f);
        left(g, f, mx, my);
        board(g, mx, my);
        stage(g, f);
        legend(g, f);
        // under the board: whose turn it is, or how it ended (the coins you got are shown for a few seconds)
        String st;
        int pill;
        if (over == 0) { st = petWait > 0 ? t("cutemod.ttt.thinks") : t("cutemod.ttt.yourmove"); pill = 0xFFFFFFFF; }
        else { st = msgT > 0 ? msg : t("cutemod.ttt.over." + over); pill = over == 1 ? 0xFFFFE890 : over == 2 ? 0xFFFFD0DC : 0xFFE4E0F0; }
        st = f.plainSubstrByWidth(st, 104);
        int pw = f.width(st) + 12, px = BX + CELL * 3 / 2 - pw / 2;
        rect(g, px, 131, pw, 11, pill);
        rect(g, px, 140, pw, 2, 0x22000000);
        CuteFont.draw(g, f, st, px + 6, 133, TEXT, false);
        btn(g, f, mx, my, BX, 144, CELL * 3, t("cutemod.ttt.again"), over != 0 ? 1 : 0);
        if (celebrate > 0) confetti(g);
    }

    private void left(GuiGraphics g, Font f, int mx, int my) {
        CuteFont.draw(g, f, t("cutemod.ttt.level"), 8, 20, MUTED, false);
        for (int l = 0; l < 3; l++) {
            int y = 30 + l * 16;
            boolean on = l == level, hov = in(mx, my, 8, y, 82, 14);
            rect(g, 8, y, 82, 14, on ? accent() : hov ? 0xFFFFEFF8 : 0xFFFFFFFF);
            rect(g, 8, y + 12, 82, 2, on ? 0x33000000 : 0xFFB9A8C8);
            CuteFont.draw(g, f, f.plainSubstrByWidth(t("cutemod.ttt.lv." + l), 52), 12, y + 3, on ? 0xFFFFFFFF : TEXT, false);
            for (int s = 0; s <= l; s++) bmp(g, STAR, 70 + s * 6 - l * 3, y + 7, 1, on ? 0xFFFFE890 : 0xFFF5BE28, 0, 0);
        }
        // who starts
        boolean hf = in(mx, my, 8, 80, 82, 14);
        rect(g, 8, 80, 82, 14, hf ? 0xFFFFEFF8 : 0xFFFFFFFF);
        rect(g, 8, 92, 82, 2, 0xFFB9A8C8);
        String fs = f.plainSubstrByWidth(t("cutemod.ttt.first." + first), 76);
        CuteFont.draw(g, f, fs, 8 + (82 - f.width(fs)) / 2, 83, TEXT, false);
        // the score card: wins, losses, draws, and the streak
        rect(g, 8, 98, 82, 38, 0xFFFFFFFF);
        rect(g, 8, 134, 82, 2, 0xFFE4D8F0);
        for (int i = 0; i < 3; i++) {
            int cx = 8 + 14 + i * 27;
            if (i == 0) bmp(g, HEART, cx, 106, 1, 0xFFE0508A, 0, 0);
            else if (i == 1) bmp(g, STAR, cx, 106, 1, 0xFFF5BE28, 0, 0);
            else { rect(g, cx - 4, 104, 9, 2, 0xFF8A7AA8); rect(g, cx - 4, 108, 9, 2, 0xFF8A7AA8); }
            center(g, f, Integer.toString(i == 0 ? wins : i == 1 ? losses : draws), cx, 114, TEXT);
        }
        rect(g, 12, 124, 74, 1, 0xFFE4D8F0);
        String sk = f.plainSubstrByWidth(t("cutemod.ttt.streak", streak, best), 78);
        CuteFont.draw(g, f, sk, 8 + (82 - f.width(sk)) / 2, 126, streak > 1 ? 0xFFE0508A : MUTED, false);
        // today's coins
        int paid = paidToday("ttt");
        CuteFont.draw(g, f, f.plainSubstrByWidth(t("cutemod.ttt.today", paid, CAP), 82), 8, 140, MUTED, false);
        rect(g, 8, 151, 82, 4, 0xFFE9E2F2);
        rect(g, 8, 151, 82 * Math.min(paid, CAP) / CAP, 4, 0xFFF5BE28);
    }

    private void board(GuiGraphics g, int mx, int my) {
        PetShops.board(g, BX - 6, BY - 6, CELL * 3 + 12, CELL * 3 + 12);
        for (int i = 0; i < 9; i++) {
            int x = BX + i % 3 * CELL, y = BY + i / 3 * CELL, w = CELL - 3;
            boolean win = winLine != null && (winLine[0] == i || winLine[1] == i || winLine[2] == i) && over != 3;
            boolean hov = over == 0 && petWait == 0 && b[i] == 0 && in(mx, my, x, y, w, w);
            int tile = win ? ((ticks / 8) % 2 == 0 ? 0xFFFFEFA0 : 0xFFFFE070) : hov ? 0xFFFFFFFF : 0xFFFFF6E8;
            rect(g, x, y + 2, w, w, 0x22000000);
            rect(g, x, y, w, w, tile);
            rect(g, x, y, w, 1, 0x88FFFFFF);
            rect(g, x, y + w - 1, w, 1, 0x14000000);
            int cx = x + w / 2, cy = y + w / 2;
            if (b[i] == 1) mark(g, true, cx, cy, age[i]);
            else if (b[i] == 2) mark(g, false, cx, cy, age[i]);
            else if (hov) bmp(g, HEART, cx, cy, 2, 0x55E0508A, 0, 0);          // a pale heart shows where you would play
        }
        if (winLine != null && over != 3) {                                     // the line is drawn across the three cells
            int a = winLine[0], c = winLine[2];
            int ax = BX + a % 3 * CELL + (CELL - 3) / 2, ay = BY + a / 3 * CELL + (CELL - 3) / 2;
            int cx = BX + c % 3 * CELL + (CELL - 3) / 2, cy = BY + c / 3 * CELL + (CELL - 3) / 2;
            int n = 48, upto = n * Math.min(winT, 30) / 30;
            int col = over == 1 ? 0xFFE0508A : 0xFFB07A10;
            for (int k = 0; k <= upto; k++) {
                int x = ax + (cx - ax) * k / n, y = ay + (cy - ay) * k / n;
                rect(g, x - 2, y - 2, 5, 5, col);
                rect(g, x - 1, y - 1, 3, 3, 0xFFFFFFFF);
            }
        }
    }

    /** The pet's own little room next to the board: the pet in its clothes, a speech bubble, and its mood. */
    private void stage(GuiGraphics g, Font f) {
        int x = 208, y = 20, w = 88, h = 100, fl = y + h - 16;
        g.fillGradient(x, y, x + w, fl, 0xFFFFF8E8, 0xFFFFE9C8);
        for (int i = 0; i < w; i += 11) rect(g, x + i, y, 1, fl - y, 0x10E8A04A);
        rect(g, x, y, w, 2, 0xFFC87A2A);
        g.fillGradient(x, fl, x + w, y + h, 0xFFE0B880, 0xFFC89A60);
        rect(g, x, fl, w, 1, 0xFF8A5A2A);
        for (int i = 0; i < w; i += 14) rect(g, x + i, fl + 1, 1, y + h - fl, 0x22000000);
        StudioArt.oval(g, x + w / 2, fl + 8, 34, 5, 0xFFF59AB8); StudioArt.oval(g, x + w / 2, fl + 8, 28, 4, 0xFFFFD0E0);
        // the pet
        ComputerColor spc = species();
        PetBlob.Info info = PetBlob.parse(Store.read("pet_" + spc.id));
        int stage = info == null ? 2 : info.stage();
        int mood = over == 1 ? 0 : over == 2 ? 2 : over == 3 ? 1 : petWait > 0 ? 1 : 2;
        int cx = x + w / 2, floor = fl + 8;
        int bob = over == 2 ? -(int) Math.round(Math.abs(Math.sin(ticks / 6.0)) * 6) : (int) Math.round(Math.sin(ticks / 18.0) * 1.5);
        float sc = 0.95F * PetArt.scaleOf(stage);
        StudioArt.oval(g, cx, floor + 1, 20, 3, 0x33000000);
        g.pose().pushPose();
        g.pose().translate(cx, floor, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-cx, -floor, 0);
        PetArt.draw(g, spc, cx, floor - 28 + bob, mood, ticks, false, false, stage, Progress.equipped(), Progress.equippedBody());
        g.pose().popPose();
        // the speech bubble
        if (bubbleT > 0 && !bubble.isEmpty()) {
            String s = f.plainSubstrByWidth(bubble, 76);
            int bw = Math.max(40, f.width(s) + 10), bx = x + (w - bw) / 2, by = y + 5;
            rect(g, bx, by, bw, 15, 0xFFFFFFFF);
            rect(g, bx, by + 13, bw, 2, 0xFFE0D6EC);
            rect(g, bx + 1, by - 1, bw - 2, 1, 0xFFFFFFFF);
            rect(g, cx - 3, by + 15, 7, 1, 0xFFFFFFFF); rect(g, cx - 2, by + 16, 5, 1, 0xFFFFFFFF); rect(g, cx - 1, by + 17, 3, 1, 0xFFFFFFFF);
            CuteFont.draw(g, f, s, bx + (bw - f.width(s)) / 2, by + 4, TEXT, false);
        }
    }

    /** You are the hearts, the pet is the stars: the side whose turn it is gets a yellow tag. */
    private void legend(GuiGraphics g, Font f) {
        boolean mine = over == 0 && petWait == 0, its = over == 0 && petWait > 0;
        rect(g, 210, 123, 84, 11, mine ? 0xFFFFF0B0 : 0xFFFFFFFF);
        rect(g, 210, 135, 84, 11, its ? 0xFFFFF0B0 : 0xFFFFFFFF);
        bmp(g, HEART, 218, 128, 1, 0xFFE0508A, 0, 0);
        bmp(g, STAR, 218, 140, 1, 0xFFF5BE28, 0, 0);
        CuteFont.draw(g, f, f.plainSubstrByWidth(t("cutemod.ttt.you"), 66), 228, 125, TEXT, false);
        CuteFont.draw(g, f, f.plainSubstrByWidth(t("cutemod.ttt.pet"), 66), 228, 137, TEXT, false);
    }

    private void confetti(GuiGraphics g) {
        int[] cc = {0xFFFF8AB0, 0xFF6FB8F0, 0xFF7ED9A0, 0xFFB57BD6, 0xFFFFA24A};
        int t = 160 - celebrate;
        for (int i = 0; i < 36; i++) {
            int x = (i * 53 + (int) (Math.sin((t + i * 7) / 14.0) * 6)) % W;
            int y = (t * (1 + i % 3) + i * 29) % (H + 10) - 10;
            if (y > 18) rect(g, x, y, 3, 3, cc[i % 5]);
        }
    }

    // ---------- input ----------
    @Override
    public boolean key(int keyCode, int modifiers) {
        if (keyCode >= 49 && keyCode <= 57) { play(keyCode - 49); return true; }       // 1 - 9
        return false;
    }

    @Override
    public boolean click(int x, int y, int button) {
        for (int l = 0; l < 3; l++) if (in(x, y, 8, 30 + l * 16, 82, 14)) { if (level != l) { level = l; reset(); } return true; }
        if (in(x, y, 8, 80, 82, 14)) { first = (first + 1) % 3; Sfx.ui(SoundEvents.UI_BUTTON_CLICK.value(), 1.5F, 0.4F); reset(); return true; }
        if (in(x, y, BX, 144, CELL * 3, 16)) { reset(); return true; }
        if (over == 0 && petWait == 0) {
            for (int i = 0; i < 9; i++) {
                if (b[i] == 0 && in(x, y, BX + i % 3 * CELL, BY + i / 3 * CELL, CELL - 3, CELL - 3)) { play(i); return true; }
            }
        }
        return false;
    }
}
