package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/** The diary: the story ("the computer is haunted"), daily tasks and achievements. */
public class QuestApp extends App {
    private static final int HEAD = 17;

    private int tab, scroll, maxScroll;   // the story and the achievements scroll when they do not fit

    @Override
    public Component title() { return Component.translatable("cutemod.os.quest"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.quest"); }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        Skin.rect(g, 0, 0, W, H, 0xFFF6F0FA);

        // tabs
        int tabs = tabCount(), tw = W / tabs;
        for (int i = 0; i < tabs; i++) {
            boolean sel = i == tab, hover = in(mx, my, i * tw, 0, tw, HEAD);
            Skin.rect(g, i * tw, 0, tw, HEAD, sel ? 0xFFB57BD6 : (hover ? 0xFF8A6AC6 : 0xFF5A4A86));
            String s = t("cutemod.quest.tab." + i);
            fitText(g, f, s, i * tw + tw / 2, 5, tw - 4, 0xFFFFFFFF, true);
        }

        switch (tab) {
            case 1 -> daily(g);
            case 3 -> evidence(g, mx, my);
            default -> scrolled(g, tab == 0);
        }
    }

    // ---------- scrolling (mouse wheel, or the Up / Down keys) ----------
    /** The height of one line of text in the font size the player picked (Settings > Font size). */
    private static int lineStep() {
        int sz = CuteFont.size();
        return sz == CuteFont.SMALL ? 9 : sz == CuteFont.LARGE ? 13 : 10;
    }

    /** Draws the story or the achievements under the tabs, moved up by "scroll"; nothing is drawn over the tabs. */
    private void scrolled(GuiGraphics g, boolean story) {
        boolean clip = shell != null;
        if (clip) g.enableScissor(shell.absX(), shell.absY() + HEAD, shell.absX() + W, shell.absY() + H);
        g.pose().pushPose();
        g.pose().translate(0, -scroll, 0);
        int end;
        try { end = story ? story(g) : achievements(g); }
        finally { g.pose().popPose(); if (clip) g.disableScissor(); }
        maxScroll = Math.max(0, end + 6 - H);
        if (scroll > maxScroll) scroll = maxScroll;
        if (maxScroll > 0) {   // a thin scroll bar on the right edge
            int th = HEAD + 2, tl = H - HEAD - 4;
            int bh = Math.max(12, tl * (H - HEAD) / (end + 6 - HEAD)), by = th + (tl - bh) * scroll / maxScroll;
            Skin.rect(g, W - 4, th, 2, tl, 0xFFE9DDF2);
            Skin.rect(g, W - 4, by, 2, bh, 0xFFB57BD6);
        }
    }

    private void setTab(int i) {
        if (i != tab) { tab = i; scroll = 0; }
    }

    @Override
    public boolean scroll(double amount) {
        if (tab != 0 && tab != 2) return false;
        scroll = Math.max(0, Math.min(maxScroll, scroll - (int) Math.signum(amount) * 16));
        return true;
    }

    /** The words of s wrapped into lines of at most maxW pixels (measured with the font that is drawn). */
    private static List<String> wrapLines(Font f, String s, int maxW) {
        List<String> out = new java.util.ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String word : s.split(" ")) {
            if (word.isEmpty()) continue;
            String tryLine = cur.length() == 0 ? word : cur + " " + word;
            if (CuteFont.width(f, tryLine) <= maxW) { cur.setLength(0); cur.append(tryLine); continue; }
            if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); }
            String rest = word;
            while (rest.length() > 1 && CuteFont.width(f, rest) > maxW) {
                int n = rest.length() - 1;
                while (n > 1 && CuteFont.width(f, rest.substring(0, n)) > maxW) n--;
                out.add(rest.substring(0, n));
                rest = rest.substring(n);
            }
            cur.append(rest);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    /** A whole paragraph, as many lines as it needs; returns the y under it. */
    private int wrapAll(GuiGraphics g, String text, int x, int y, int width, int color) {
        Font f = font();
        for (String line : wrapLines(f, text, width)) {
            Skin.str(g, f, line, x, y, color, false);
            y += lineStep();
        }
        return y;
    }

    private int wrap(GuiGraphics g, String text, int x, int y, int width, int color, int maxLines) {
        Font f = font();
        List<FormattedCharSequence> lines = f.split(FormattedText.of(text), width);
        for (int i = 0; i < lines.size() && i < maxLines; i++) {
            Skin.str(g, f, lines.get(i), x, y, color, false);
            y += 9;
        }
        return y;
    }

    // ---------- story ----------
    /** Returns the y under the last line (the scroll needs it). */
    private int story(GuiGraphics g) {
        Font f = font();
        int step = Progress.step(), y = 24, ls = lineStep();
        if (Progress.questDone()) {
            if (Progress.step3() < Progress.Q3_STEPS) return story3(g);   // part 3 goes on
            Skin.str(g, f, t("cutemod.quest.done"), 8, y, 0xFF5BBF6A, false);
            int ey = wrapAll(g, t("cutemod.quest.end.1"), 8, y + ls + 4, W - 16, 0xFF3A2A3A) + 4;
            return wrapAll(g, t("cutemod.q3.end.1"), 8, ey, W - 16, 0xFFC04A7A);
        }
        Skin.str(g, f, t("cutemod.quest.chapter", step + 1, Progress.QUEST_STEPS, t("cutemod.quest." + step + ".title")), 8, y, 0xFFC04A7A, false);
        Skin.rect(g, 8, y + ls, W - 16, 1, 0xFFE9DDF2);
        y = wrapAll(g, t("cutemod.quest." + step + ".text"), 8, y + ls + 5, W - 16, 0xFF3A2A3A) + 3;
        y = wrapAll(g, t("cutemod.quest." + step + ".goal"), 8, y, W - 16, 0xFF2F5FBF) + 3;
        String progress = progressText(step);
        if (!progress.isEmpty()) {
            Skin.str(g, f, progress, 8, y, 0xFF5BBF6A, false);
            y += ls + 1;
        }
        y = wrapAll(g, t("cutemod.quest." + step + ".hint"), 8, y, W - 16, 0xFF8A7AA8) + 3;
        Skin.str(g, f, t("cutemod.quest.reward", Progress.QUEST_REWARD[step]), 8, y, 0xFFB98A10, false);
        y += ls + 6;
        Skin.str(g, f, t("cutemod.quest.passed", step, Progress.QUEST_STEPS), 8, y, 0xFF9A8AB8, false);
        if (step >= Progress.PART1) {
            String part = t("cutemod.quest.part2");
            Skin.str(g, f, part, W - 12 - f.width(part), y, 0xFFB57BD6, false);
        }
        return y + ls;
    }

    /** Part 3, "Behind You": one chapter at a time, like the others. */
    private int story3(GuiGraphics g) {
        Font f = font();
        int s = Progress.step3(), y = 24, ls = lineStep();
        Skin.str(g, f, t("cutemod.q3.chapter", s + 1, Progress.Q3_STEPS, t("cutemod.q3." + s + ".title")), 8, y, 0xFFC04A7A, false);
        Skin.rect(g, 8, y + ls, W - 16, 1, 0xFFE9DDF2);
        y = wrapAll(g, t("cutemod.q3." + s + ".text"), 8, y + ls + 5, W - 16, 0xFF3A2A3A) + 3;
        y = wrapAll(g, t("cutemod.q3." + s + ".goal"), 8, y, W - 16, 0xFF2F5FBF) + 3;
        if (s == 1) {
            Skin.str(g, f, t("cutemod.q3.p1", Math.min(40, Progress.count("q3_paint"))), 8, y, 0xFF5BBF6A, false);
            y += ls + 1;
        }
        y = wrapAll(g, t("cutemod.q3." + s + ".hint"), 8, y, W - 16, 0xFF8A7AA8) + 3;
        if (!Haunt.scary) y = wrapAll(g, t("cutemod.q3.off"), 8, y, W - 16, 0xFFE5484D) + 3;
        Skin.str(g, f, t("cutemod.quest.reward", Progress.Q3_REWARD[s]), 8, y, 0xFFB98A10, false);
        y += ls + 6;
        Skin.str(g, f, t("cutemod.quest.passed", s, Progress.Q3_STEPS), 8, y, 0xFF9A8AB8, false);
        String part = t("cutemod.quest.part3");
        Skin.str(g, f, part, W - 12 - f.width(part), y, 0xFFB57BD6, false);
        return y + ls;
    }

    private String progressText(int step) {
        return switch (step) {
            case 0 -> t("cutemod.quest.p0", Math.min(4, Progress.count("scary_read")));
            case 10 -> t("cutemod.quest.p10", Math.min(60, Progress.count("q_paint")));
            case 11 -> t("cutemod.quest.p11", Math.min(40, Progress.count("q_note")));
            case 5 -> t("cutemod.quest.p5", Math.min(3, Progress.count("q_ghost")));
            default -> "";
        };
    }

    // ---------- clues: the board of the big easter egg (see Traces) ----------
    private static int tabCount() { return Traces.started() ? 4 : 3; }

    /** A small four-pointed star in 5 x 5 pixels. */
    private static void star(GuiGraphics g, int x, int y, int col) {
        g.fill(x + 2, y, x + 3, y + 5, col);
        g.fill(x, y + 2, x + 5, y + 3, col);
        g.fill(x + 1, y + 1, x + 4, y + 4, col);
    }

    /** The whisper of the Stranger; the plain hint shows after a click on the cell (and for a clue that is found). */
    private static String hintFor(Traces.Trace tr, boolean hovering) {
        if (Traces.found(tr) || Progress.count("sxh_" + tr.id()) > 0) return t("cutemod.trace." + tr.id() + ".hint");
        String w = t("cutemod.trace." + tr.id() + ".whisper");
        return hovering ? w + " " + t("cutemod.trace.tap") : w;
    }

    /** A click on a cell of the board: the whisper turns into the plain hint. */
    private static boolean tapCell(int x, int y) {
        int ry = y - 20, row = ry / 23, col = (x - 98) / 66;
        if (ry < 0 || x < 98 || row >= Traces.CHAPTERS || col >= Traces.PER_CHAPTER || ry % 23 < 3 || ry % 23 >= 18 || (x - 98) % 66 >= 62) return false;
        if (!Traces.unlocked(row + 1)) return false;
        int n = 0;
        for (Traces.Trace tr : Traces.ALL) {
            if (tr.chapter() != row + 1) continue;
            if (n++ == col) { if (!Traces.found(tr)) Progress.setCount("sxh_" + tr.id(), 1); return true; }
        }
        return false;
    }

    private void evidence(GuiGraphics g, int mx, int my) {
        Font f = font();
        Traces.Trace hover = null, firstOpen = null;
        int y = 20;
        for (int c = 1; c <= Traces.CHAPTERS; c++) {
            boolean open = Traces.unlocked(c), done = Traces.chapterDone(c);
            Skin.rect(g, 4, y, W - 8, 21, done ? 0xFFDFF5E3 : open ? 0xFFFFFFFF : 0xFFE8E0F0);
            Skin.rect(g, 4, y, 2, 21, done ? 0xFF5BBF6A : open ? 0xFFB57BD6 : 0xFFC8BCD6);
            String head = t("cutemod.trace.chapter", c) + " \u00b7 " + (open ? t("cutemod.trace.ch." + c + ".title") : "???");
            fitText(g, f, head, 10, y + 7, 84, open ? 0xFF3A2A3A : 0xFF9A8AB8, false);
            int i = 0;
            for (Traces.Trace tr : Traces.ALL) {
                if (tr.chapter() != c) continue;
                int cx = 98 + i * 66, cy = y + 3;
                i++;
                boolean got = Traces.found(tr), over = open && in(mx, my, cx, cy, 62, 15);
                if (over) hover = tr;
                if (open && !got && firstOpen == null) firstOpen = tr;
                Skin.rect(g, cx, cy, 62, 15, got ? 0xFFFFF1C2 : open ? (over ? 0xFFE3D6F3 : 0xFFF3ECFA) : 0xFFD9CFE5);
                if (got) {
                    star(g, cx + 4, cy + 5, 0xFFE0A818);
                    fitText(g, f, t("cutemod.trace." + tr.id() + ".name"), cx + 12, cy + 4, 46, 0xFF6A4A10, false);
                } else {
                    fitText(g, f, open ? "?" : "\u00b7", cx + 31, cy + 4, 50, open ? 0xFF8A6AC6 : 0xFFB0A4C4, true);
                }
            }
            y += 23;
        }
        StringBuilder words = new StringBuilder();
        for (int c = 1; c <= Traces.CHAPTERS; c++) words.append(Traces.chapterDone(c) ? Traces.word(c) : "?").append(c < Traces.CHAPTERS ? "  " : "");
        Skin.str(g, f, t("cutemod.trace.words", words.toString()), 8, 137, 0xFFB57BD6, false);
        String hint;
        if (hover != null) hint = hintFor(hover, true);
        else if (Traces.finished()) hint = t("cutemod.trace.finished");
        else if (Traces.allChapters()) hint = t("cutemod.trace.say");
        else hint = firstOpen != null ? hintFor(firstOpen, false) : "";
        wrap(g, hint, 8, 147, W - 16, 0xFF8A7AA8, 2);
    }

    // ---------- daily tasks ----------
    private void daily(GuiGraphics g) {
        Font f = font();
        Skin.str(g, f, t("cutemod.quest.streak", Progress.streak(), Math.min(Progress.streak(), 7) * 3), 8, 24, 0xFFC04A7A, false);
        int y = 42;
        for (Progress.Daily d : Progress.DAILY) {
            boolean done = Progress.dailyDone(d.counter());
            int have = Math.min(d.target(), Progress.dailyCount(d.counter()));
            Skin.rect(g, 8, y, W - 16, 28, done ? 0xFFDFF5E3 : 0xFFFFFFFF);
            Skin.rect(g, 8, y, 2, 28, done ? 0xFF5BBF6A : 0xFFB57BD6);
            Skin.str(g, f, t("cutemod.task." + d.counter()), 16, y + 4, 0xFF3A2A3A, false);
            String rw = "+" + d.reward();
            Skin.str(g, f, rw, W - 28 - f.width(rw), y + 4, 0xFFB98A10, false);
            Progress.drawCoin(g, W - 22, y + 4);
            Skin.rect(g, 16, y + 17, 150, 6, 0xFFE9DDF2);
            Skin.rect(g, 16, y + 17, 150 * have / d.target(), 6, done ? 0xFF5BBF6A : 0xFFB57BD6);
            Skin.str(g, f, have + "/" + d.target(), 172, y + 16, 0xFF8A7AA8, false);
            y += 33;
        }
        int got = Progress.gameCoinsToday();
        Skin.str(g, f, t("cutemod.quest.cap", got, Progress.GAME_COIN_CAP), 8, 148, got >= Progress.GAME_COIN_CAP ? 0xFFE5484D : 0xFF8A7AA8, false);
    }

    // ---------- achievements ----------
    private int achievements(GuiGraphics g) {
        Font f = font();
        int y = 22, step = lineStep() + 2;                                          // a long list: it scrolls instead of being squeezed
        for (Progress.Ach a : Progress.ACHS) {
            boolean done = Progress.hasAch(a.id()), secret = !done && (a.id().equals("hell_66") || a.id().equals("stranger_end") || a.id().equals("stranger_alone"));
            Skin.rect(g, 8, y + 1, 8, 8, done ? 0xFF5BBF6A : 0xFFD8CCE2);
            if (done) { Skin.rect(g, 10, y + 5, 2, 2, 0xFFFFFFFF); Skin.rect(g, 12, y + 3, 2, 4, 0xFFFFFFFF); }
            Skin.str(g, f, secret ? "???" : t("cutemod.ach." + a.id()), 22, y + 1, done ? 0xFF3A2A3A : 0xFF8A7AA8, false);
            String right = done ? "+" + a.reward() : secret ? "?" : Math.min(a.target(), Progress.count(a.counter())) + "/" + a.target();
            Skin.str(g, f, right, W - 8 - f.width(right), y + 1, done ? 0xFFB98A10 : 0xFF8A7AA8, false);
            y += step;
        }
        return y;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (tab == 3 && y >= HEAD && tapCell(x, y)) return true;
        if (y < HEAD) {
            int i = x / (W / tabCount());
            if (i >= 0 && i < tabCount()) { setTab(i); return true; }
        }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (keyCode == 262) { setTab(Math.min(tabCount() - 1, tab + 1)); return true; } // right
        if (keyCode == 263) { setTab(Math.max(0, tab - 1)); return true; } // left
        if (keyCode == 264) return scroll(-1);   // down
        if (keyCode == 265) return scroll(1);    // up
        return false;
    }
}
