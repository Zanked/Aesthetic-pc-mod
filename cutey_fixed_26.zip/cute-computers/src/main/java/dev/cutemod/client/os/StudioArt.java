package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

import static dev.cutemod.client.os.App.disc;
import static dev.cutemod.client.os.App.rect;

/**
 * Pictures for the pet photo studio: the paper backdrops, the colour filters, the frames of the prints and the little
 * icons of the control panel. Everything is drawn in a {@link #VW} x {@link #VH} box (the picture); pure drawing.
 */
final class StudioArt {
    private StudioArt() {}

    static final int VW = 170, VH = 100;
    static final int BGS = 8, POSES = 4, FILTERS = 6, FRAMES = 5;

    /** The two colours of every backdrop (the top and the floor): the little paper rolls of the control panel. */
    static final int[][] ROLL = {
        {0xFF9AD8FF, 0xFF8FD39A}, {0xFF1E1A4A, 0xFF2A3A5A}, {0xFF9AD8FF, 0xFFF0D8A0}, {0xFFFFD8E8, 0xFFE8B8C8},
        {0xFFE8708A, 0xFF3A2A4A}, {0xFFFFF0B0, 0xFFE8C98A}, {0xFFF4F4FA, 0xFFD0D4E0}, {0xFF14102E, 0xFF5A3A8A}};
    /** The tint of every filter, as shown on its chip (0 = none). */
    static final int[] TINT = {0xFFFFFFFF, 0xFFFFB45A, 0xFFFF8AB0, 0xFF6FB8E8, 0xFF3A3548, 0xFFE8D8FF};

    static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(1 - (dy * dy) / (double) (ry * ry + 1)));
            rect(g, cx - dx, cy + dy, dx * 2 + 1, 1, argb);
        }
    }

    private static void spark(GuiGraphics g, int x, int y, int argb) {
        rect(g, x, y - 1, 1, 3, argb); rect(g, x - 1, y, 3, 1, argb);
    }

    /** The paper backdrop and the floor sweep (t = animation ticks, 0 for a still picture). */
    static void backdrop(GuiGraphics g, int b, int t) {
        switch (b) {
            case 0 -> {                                                   // park
                rect(g, 0, 0, VW, 62, 0xFF9AD8FF); rect(g, 0, 62, VW, 38, 0xFF8FD39A);
                disc(g, 138, 20, 10, 0xFFFFE066);
                rect(g, 20, 14, 26, 6, 0xFFFFFFFF); rect(g, 26, 10, 14, 6, 0xFFFFFFFF); rect(g, 80, 28, 22, 5, 0xFFFFFFFF);
                rect(g, 10, 54, 4, 12, 0xFF8A5A32); disc(g, 12, 50, 9, 0xFF5BBF6A);
                for (int i = 0; i < 7; i++) rect(g, 20 + i * 23, 72 + (i * 7) % 18, 2, 2, i % 2 == 0 ? 0xFFFFFFFF : 0xFFFFD84A);   // daisies
            }
            case 1 -> {                                                   // night
                rect(g, 0, 0, VW, 66, 0xFF1E1A4A); rect(g, 0, 66, VW, 34, 0xFF2A3A5A);
                for (int i = 0; i < 24; i++) if ((t / 10 + i) % 6 != 0) rect(g, (i * 37) % VW, 4 + (i * 23) % 54, 1, 1, 0xFFFFFFFF);
                disc(g, 136, 22, 11, 0xFFFFF3B0); disc(g, 141, 19, 9, 0xFF1E1A4A);
            }
            case 2 -> {                                                   // beach
                rect(g, 0, 0, VW, 50, 0xFF9AD8FF); rect(g, 0, 50, VW, 20, 0xFF4AB0E8); rect(g, 0, 70, VW, 30, 0xFFF0D8A0);
                disc(g, 30, 22, 10, 0xFFFFE066);
                for (int i = 0; i < 6; i++) rect(g, 10 + i * 30 + (t / 20 % 2) * 4, 56, 12, 1, 0xFFB8E8FF);
                rect(g, 140, 56, 2, 22, 0xFF8A5A32); rect(g, 130, 52, 22, 3, 0xFFE5486F); rect(g, 134, 49, 14, 3, 0xFFE5486F);   // a parasol
            }
            case 3 -> {                                                   // pink room
                rect(g, 0, 0, VW, 66, 0xFFFFD8E8); rect(g, 0, 66, VW, 34, 0xFFE8B8C8);
                for (int i = 0; i < 8; i++) { int hx = 10 + i * 21, hy = 8 + (i % 2) * 14; PetShops.heart5(g, hx, hy, 0xFFFF8AB0); }
                rect(g, 120, 30, 28, 22, 0xFFFFF0F6); rect(g, 122, 32, 24, 18, 0xFFBDE4FF);
                rect(g, 133, 32, 2, 18, 0xFFFFF0F6); rect(g, 122, 40, 24, 2, 0xFFFFF0F6);
            }
            case 4 -> {                                                   // sunset
                for (int i = 0; i < 6; i++) rect(g, 0, i * 11, VW, 11, new int[]{0xFF6A4AA8, 0xFFA85AB0, 0xFFE8708A, 0xFFF0985A, 0xFFF8C060, 0xFFFFE08A}[i]);
                disc(g, 85, 66, 16, 0xFFFFF3B0); rect(g, 0, 66, VW, 34, 0xFF3A2A4A);
            }
            case 5 -> {                                                   // party
                rect(g, 0, 0, VW, VH, 0xFFFFF0B0);
                int[] cc = {0xFFFF8AB0, 0xFF6FB8F0, 0xFF7ED9A0, 0xFFB57BD6, 0xFFFFA24A};
                for (int i = 0; i < 28; i++) rect(g, (i * 53) % VW, (i * 29 + t / 4) % 80, 3, 3, cc[i % 5]);
                for (int i = 0; i < 9; i++) { rect(g, i * 20, 0, 12, 2, cc[i % 5]); rect(g, i * 20 + 3, 2, 6, 4, cc[(i + 2) % 5]); }
                rect(g, 0, 90, VW, 10, 0xFFE8C98A);
            }
            case 6 -> {                                                   // white studio: a seamless paper sweep and two softbox lights
                g.fillGradient(0, 0, VW, 66, 0xFFE4E8F2, 0xFFFAFAFF);
                g.fillGradient(0, 66, VW, VH, 0xFFF0F0F6, 0xFFCDD2E0);
                for (int s = 0; s < 2; s++) {
                    int lx = s == 0 ? 6 : VW - 22;
                    rect(g, lx + 7, 22, 2, 60, 0xFF8A8A9A); rect(g, lx + 2, 80, 12, 2, 0xFF6A6A7A);
                    rect(g, lx, 6, 16, 18, 0xFF4A4A5A); rect(g, lx + 2, 8, 12, 14, 0xFFFFFDF0);
                    for (int i = 0; i < 4; i++) rect(g, (s == 0 ? lx + 16 : lx - 4 - i * 4), 10 + i * 3, 4 + i * 4, 1, 0x14FFF3B0);
                }
            }
            default -> {                                                  // space
                g.fillGradient(0, 0, VW, 74, 0xFF0C0A24, 0xFF2A1A5A);
                for (int i = 0; i < 40; i++) if ((t / 8 + i) % 7 != 0) rect(g, (i * 41) % VW, 3 + (i * 19) % 66, i % 5 == 0 ? 2 : 1, i % 5 == 0 ? 2 : 1, i % 3 == 0 ? 0xFFFFF3B0 : 0xFFFFFFFF);
                disc(g, 130, 26, 14, 0xFFB57BD6); disc(g, 126, 22, 9, 0xFFCDA4E8);
                rect(g, 108, 28, 46, 3, 0xAAFFE08A); rect(g, 112, 31, 38, 1, 0x66FFE08A);
                g.fillGradient(0, 74, VW, VH, 0xFF4A3A7A, 0xFF2A2050);
                for (int i = 0; i < 6; i++) oval(g, 14 + i * 30, 80 + (i * 5) % 14, 6, 2, 0x33000000);                 // craters
            }
        }
    }

    /** A soft colour over the picture (filter 0 = none) and a little vignette. */
    static void filter(GuiGraphics g, int fl, int t) {
        if (fl <= 0) return;
        int[] over = {0, 0x30FF9A30, 0x2EFF70B0, 0x2E4090FF, 0x44000020, 0x2AFFFFFF};
        rect(g, 0, 0, VW, VH, over[Math.min(fl, over.length - 1)]);
        g.fillGradient(0, 0, VW, 14, 0x38000000, 0x00000000);
        g.fillGradient(0, VH - 14, VW, VH, 0x00000000, 0x38000000);
        if (fl == 4) { rect(g, 0, 0, VW, 9, 0xFF000000); rect(g, 0, VH - 9, VW, 9, 0xFF000000); }
        if (fl == 5) for (int i = 0; i < 9; i++) {
            if (t > 0 && (t / 12 + i) % 5 == 0) continue;
            spark(g, (i * 43 + t / 3) % VW, 8 + (i * 29 + t / 5) % (VH - 16), 0xDDFFFFFF);
        }
    }

    /** The frame of the print (0 = none): polaroid, hearts, stars, film strip. */
    static void frame(GuiGraphics g, int fr) {
        switch (fr) {
            case 1 -> {                                                   // polaroid
                rect(g, 0, 0, VW, 5, 0xFFFFFFFF); rect(g, 0, 0, 5, VH, 0xFFFFFFFF); rect(g, VW - 5, 0, 5, VH, 0xFFFFFFFF); rect(g, 0, VH - 15, VW, 15, 0xFFFFFFFF);
                rect(g, 5, 5, VW - 10, 1, 0x22000000); rect(g, 5, VH - 16, VW - 10, 1, 0x22000000);
                PetShops.heart5(g, VW / 2 - 2, VH - 10, 0xFFFF8AB0);
            }
            case 2 -> {                                                   // hearts
                rect(g, 0, 0, VW, 7, 0xFFFFB8D0); rect(g, 0, VH - 7, VW, 7, 0xFFFFB8D0); rect(g, 0, 0, 7, VH, 0xFFFFB8D0); rect(g, VW - 7, 0, 7, VH, 0xFFFFB8D0);
                for (int i = 2; i < VW - 8; i += 12) { PetShops.heart5(g, i, 1, 0xFFFFFFFF); PetShops.heart5(g, i + 6, VH - 6, 0xFFE0508A); }
                for (int j = 12; j < VH - 8; j += 12) { PetShops.heart5(g, 1, j, 0xFFE0508A); PetShops.heart5(g, VW - 6, j + 6, 0xFFFFFFFF); }
            }
            case 3 -> {                                                   // stars
                rect(g, 0, 0, VW, 7, 0xFF2A2A5A); rect(g, 0, VH - 7, VW, 7, 0xFF2A2A5A); rect(g, 0, 0, 7, VH, 0xFF2A2A5A); rect(g, VW - 7, 0, 7, VH, 0xFF2A2A5A);
                for (int i = 4; i < VW - 6; i += 11) { spark(g, i, 3, 0xFFFFE066); spark(g, i + 5, VH - 4, 0xFFFFFFFF); }
                for (int j = 12; j < VH - 6; j += 11) { spark(g, 3, j, 0xFFFFFFFF); spark(g, VW - 4, j + 5, 0xFFFFE066); }
            }
            case 4 -> {                                                   // film strip
                rect(g, 0, 0, VW, 10, 0xFF1A1A1E); rect(g, 0, VH - 10, VW, 10, 0xFF1A1A1E);
                for (int i = 3; i < VW - 4; i += 10) { rect(g, i, 3, 5, 4, 0xFFE8E8EE); rect(g, i, VH - 7, 5, 4, 0xFFE8E8EE); }
            }
            default -> { }
        }
    }

    /** The viewfinder over the live picture: corner brackets, thirds, a focus box (green when ready), a blinking dot. */
    static void viewfinder(GuiGraphics g, int x, int y, int t, boolean counting) {
        int c = 0xCCFFFFFF, n = 10;
        for (int[] k : new int[][]{{0, 0, 1, 1}, {VW, 0, -1, 1}, {0, VH, 1, -1}, {VW, VH, -1, -1}}) {
            int cx = x + k[0] + k[2] * 5, cy = y + k[1] + k[3] * 5;
            rect(g, k[2] > 0 ? cx : cx - n + 1, cy, n, 1, c);
            rect(g, cx, k[3] > 0 ? cy : cy - n + 1, 1, n, c);
        }
        for (int i = 1; i < 3; i++) {                                     // the rule of thirds, very faint
            rect(g, x + VW * i / 3, y, 1, VH, 0x18FFFFFF);
            rect(g, x, y + VH * i / 3, VW, 1, 0x18FFFFFF);
        }
        int fc = counting ? 0xFFFFD84A : 0xFF7EE08A, grow = counting ? (t / 6) % 2 : 0;
        int fx = x + VW / 2 - 14 - grow, fy = y + VH / 2 - 10 - grow, fw = 28 + grow * 2, fh = 20 + grow * 2;
        rect(g, fx, fy, 5, 1, fc); rect(g, fx, fy, 1, 5, fc);
        rect(g, fx + fw - 5, fy, 5, 1, fc); rect(g, fx + fw - 1, fy, 1, 5, fc);
        rect(g, fx, fy + fh - 1, 5, 1, fc); rect(g, fx, fy + fh - 5, 1, 5, fc);
        rect(g, fx + fw - 5, fy + fh - 1, 5, 1, fc); rect(g, fx + fw - 1, fy + fh - 5, 1, 5, fc);
        if ((t / 30) % 2 == 0) disc(g, x + 12, y + 12, 2, 0xFFE5484D);
    }

    // ---------- the icons of the control panel ----------

    /** A tiny face on a chip: 0 happy, 1 calm, 2 asleep, 3 sulking. */
    static void pose(GuiGraphics g, int kind, int cx, int cy, int col) {
        switch (kind) {
            case 0 -> { rect(g, cx - 4, cy - 3, 2, 2, col); rect(g, cx + 3, cy - 3, 2, 2, col); rect(g, cx - 3, cy + 1, 7, 1, col); rect(g, cx - 4, cy, 1, 1, col); rect(g, cx + 4, cy, 1, 1, col); }
            case 1 -> { rect(g, cx - 4, cy - 2, 2, 2, col); rect(g, cx + 3, cy - 2, 2, 2, col); rect(g, cx - 2, cy + 2, 5, 1, col); }
            case 2 -> { rect(g, cx - 4, cy - 2, 3, 1, col); rect(g, cx + 2, cy - 2, 3, 1, col); rect(g, cx - 1, cy + 2, 3, 1, col); rect(g, cx + 5, cy - 4, 2, 1, col); rect(g, cx + 6, cy - 3, 1, 1, col); rect(g, cx + 5, cy - 2, 2, 1, col); }
            default -> { rect(g, cx - 4, cy - 2, 2, 2, col); rect(g, cx + 3, cy - 2, 2, 2, col); rect(g, cx - 2, cy + 1, 5, 1, col); rect(g, cx - 3, cy + 2, 1, 1, col); rect(g, cx + 3, cy + 2, 1, 1, col); rect(g, cx - 4, cy, 1, 3, 0xFF6FB8E8); }
        }
    }

    /** A colour chip of a filter (13 x 8 swatch with a slash for "none"). */
    static void filterChip(GuiGraphics g, int kind, int x, int y) {
        rect(g, x, y, 13, 8, 0xFFFFFFFF);
        if (kind == 0) { for (int i = 0; i < 8; i++) rect(g, x + 2 + i, y + 7 - i, 2, 1, 0xFFC8BCD8); return; }
        rect(g, x + 1, y + 1, 11, 6, TINT[Math.min(kind, TINT.length - 1)]);
        if (kind == 5) { spark(g, x + 4, y + 3, 0xFFFFFFFF); spark(g, x + 9, y + 5, 0xFFB57BD6); }
        if (kind == 4) { rect(g, x + 1, y + 1, 11, 1, 0xFF000000); rect(g, x + 1, y + 6, 11, 1, 0xFF000000); }
    }

    /** A tiny sample of a frame (16 x 8). */
    static void frameChip(GuiGraphics g, int kind, int x, int y) {
        switch (kind) {
            case 0 -> { rect(g, x, y, 16, 8, 0xFFC8BCD8); rect(g, x + 1, y + 1, 14, 6, 0xFFFFFFFF); }
            case 1 -> { rect(g, x, y, 16, 8, 0xFFFFFFFF); rect(g, x + 1, y + 1, 14, 4, 0xFF9AD8FF); rect(g, x, y, 16, 1, 0xFFC8BCD8); rect(g, x, y + 7, 16, 1, 0xFFC8BCD8); }
            case 2 -> { rect(g, x, y, 16, 8, 0xFFFFB8D0); rect(g, x + 2, y + 2, 12, 4, 0xFFFFF0F6); PetShops.heart5(g, x + 5, y + 2, 0xFFE0508A); }
            case 3 -> { rect(g, x, y, 16, 8, 0xFF2A2A5A); rect(g, x + 2, y + 2, 12, 4, 0xFF4A4A8A); spark(g, x + 4, y + 4, 0xFFFFE066); spark(g, x + 11, y + 3, 0xFFFFFFFF); }
            default -> { rect(g, x, y, 16, 8, 0xFF1A1A1E); rect(g, x + 2, y + 2, 12, 4, 0xFF5A5A6A); for (int i = 1; i < 16; i += 4) { rect(g, x + i, y, 2, 1, 0xFFE8E8EE); rect(g, x + i, y + 7, 2, 1, 0xFFE8E8EE); } }
        }
    }

    /** A little camera (13 x 9) for the shutter button. */
    static void camera(GuiGraphics g, int x, int y, int col) {
        rect(g, x, y + 2, 13, 7, col); rect(g, x + 3, y, 5, 2, col);
        rect(g, x + 4, y + 3, 5, 5, 0xFFFFFFFF); rect(g, x + 5, y + 4, 3, 3, 0xFF4A4A6A); rect(g, x + 10, y + 3, 2, 1, 0xFFFFFFFF);
    }

    /** A polaroid clothes-peg (4 x 6). */
    static void peg(GuiGraphics g, int x, int y) {
        rect(g, x, y, 4, 6, 0xFFD9A468); rect(g, x + 1, y + 1, 2, 2, 0xFFB07840); rect(g, x, y + 3, 4, 1, 0x33000000);
    }
}
