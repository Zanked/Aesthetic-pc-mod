package dev.cutemod.block;

import com.mojang.serialization.MapCodec;
import dev.cutemod.ComputerColor;
import dev.cutemod.client.ClientHooks;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The laptop: the same OS as the computer of its colour (and the same record), but with a lid.
 * Closed: right-click opens the lid. Open: right-click opens the OS, sneak + right-click with an empty hand closes the lid.
 * The item ({@link dev.cutemod.item.LaptopItem}) opens the OS right in the hand, so a laptop can be carried around.
 */
public class LaptopBlock extends ComputerBlock {
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;
    public static final MapCodec<LaptopBlock> CODEC = simpleCodec(p -> new LaptopBlock(p, ComputerColor.PINK));

    private static final VoxelShape[] OPEN_SHAPES = new VoxelShape[4];
    private static final VoxelShape[] CLOSED_SHAPES = new VoxelShape[4];
    static {
        for (int turn = 0; turn < 4; turn++) {
            OPEN_SHAPES[turn] = Shapes.or(rotated(2, 0, 4.5, 14, 1.25, 14, turn), rotated(2, 1.25, 1.8, 14, 9.6, 6.4, turn));
            CLOSED_SHAPES[turn] = rotated(2, 0, 4.5, 14, 2.05, 14, turn);
        }
    }

    public LaptopBlock(BlockBehaviour.Properties props, ComputerColor color) {
        super(props, color);
        registerDefaultState(defaultBlockState().setValue(OPEN, true));
    }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(OPEN);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        BlockState s = super.getStateForPlacement(ctx);
        return s == null ? null : s.setValue(OPEN, true);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        int turns = turnsOf(state.getValue(FACING));
        return state.getValue(OPEN) ? OPEN_SHAPES[turns] : CLOSED_SHAPES[turns];
    }

    private static void setOpen(Level level, BlockPos pos, BlockState state, boolean open, Player player) {
        level.setBlock(pos, state.setValue(OPEN, open), 3);
        level.playSound(null, pos, open ? SoundEvents.IRON_TRAPDOOR_OPEN : SoundEvents.IRON_TRAPDOOR_CLOSE,
                SoundSource.BLOCKS, 0.7F, open ? 1.5F : 1.3F);
        level.gameEvent(player, open ? GameEvent.BLOCK_OPEN : GameEvent.BLOCK_CLOSE, pos);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!state.getValue(OPEN)) {                                   // closed: lift the lid
            if (!level.isClientSide) setOpen(level, pos, state, true, player);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (player.isShiftKeyDown()) {                                 // open + sneak: close it
            if (!level.isClientSide) setOpen(level, pos, state, false, player);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (level.isClientSide) ClientHooks.openComputer(getColor(), pos, true);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** A dye paints the laptop in the colour of the dye (direction, lid and record stay). */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player,
                                              InteractionHand hand, BlockHitResult hit) {
        if (stack.getItem() instanceof DyeItem dye) {
            ComputerColor target = ComputerColor.fromDye(dye.getDyeColor());
            if (target != null && target != getColor()) {
                if (!level.isClientSide) {
                    BlockEntity old = level.getBlockEntity(pos);
                    CompoundTag data = old == null ? null : old.saveWithoutMetadata(level.registryAccess());
                    BlockState painted = ModBlocks.getLaptop(target).get().defaultBlockState()
                            .setValue(FACING, state.getValue(FACING)).setValue(OPEN, state.getValue(OPEN));
                    level.setBlock(pos, painted, 3);
                    BlockEntity fresh = level.getBlockEntity(pos);
                    if (data != null && fresh != null) {
                        fresh.loadWithComponents(data, level.registryAccess());
                        fresh.setChanged();
                        level.sendBlockUpdated(pos, painted, painted, 3);
                    }
                    if (!player.getAbilities().instabuild) stack.shrink(1);
                    level.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 1F, 1F);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }
}
