package dev.cutemod.item;

import dev.cutemod.block.LaptopBlock;
import dev.cutemod.client.ClientHooks;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * The laptop in the hand: right-click opens the OS right here (the screen is a bit smaller than the monitor of a computer), and
 * sneak + right-click on a block puts the laptop down (open, facing the player).
 */
public class LaptopItem extends BlockItem {
    public LaptopItem(LaptopBlock block, Item.Properties props) { super(block, props); }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Player p = ctx.getPlayer();
        if (p == null || !p.isShiftKeyDown()) return InteractionResult.PASS;     // not placing: use() opens the OS
        return super.useOn(ctx);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide && getBlock() instanceof LaptopBlock lb) ClientHooks.openComputer(lb.getColor(), BlockPos.ZERO, true);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("cutemod.tip.laptop.use").withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable("cutemod.tip.laptop.place").withStyle(ChatFormatting.BLUE));
        tip.add(Component.translatable("cutemod.tip.laptop.lid").withStyle(ChatFormatting.LIGHT_PURPLE));
    }
}
