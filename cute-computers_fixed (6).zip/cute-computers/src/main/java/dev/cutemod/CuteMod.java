package dev.cutemod;

import dev.cutemod.block.ModBlockEntities;
import dev.cutemod.block.ModBlocks;
import dev.cutemod.net.RequestDataPayload;
import dev.cutemod.net.SaveDataPayload;
import dev.cutemod.net.ScorePayload;
import dev.cutemod.net.SyncDataPayload;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

@Mod(CuteMod.MOD_ID)
public class CuteMod {
    public static final String MOD_ID = "cutemod";

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    // The creative tabs, in this order (registration order is the order on the screen):
    //   1) PARTS  - the inside parts of a PC (and the routers)
    //   2) DESK   - monitors, mice, cases, keyboards
    //   3) FOOD
    //   4) MAIN   - the cute computers, laptops, players, headphones and the rest
    public static final Supplier<CreativeModeTab> TAB_PARTS = TABS.register("parts", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.cutemod.parts"))
                    .icon(() -> new ItemStack(dev.cutemod.item.ModItems.BASIC_PARTS.values().iterator().next().get()))
                    .displayItems((params, out) -> {
                        for (var basic : dev.cutemod.item.ModItems.BASIC_PARTS.values()) out.accept(basic.get());
                        out.accept(dev.cutemod.item.ModItems.PC_CABLES.get());
                        for (var part : dev.cutemod.item.ModItems.PC_PARTS.values()) {
                            if (part.get() instanceof dev.cutemod.item.PcPartItem pp && pp.kind() == dev.cutemod.data.PcHardware.Kind.MODEM) continue;   // old modems: only kept so old worlds work
                            out.accept(part.get());
                        }
                        for (var router : ModBlocks.allRouters()) out.accept(router.get());
                    })
                    .build());

    public static final Supplier<CreativeModeTab> TAB_DESK = TABS.register("desk", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.cutemod.desk"))
                    .icon(() -> new ItemStack(ModBlocks.PC_MONITOR_ITEM.get()))
                    .displayItems((params, out) -> {
                        // monitors, then mice, then PC cases, then keyboards (every colour / RGB / Sakura Edition)
                        out.accept(ModBlocks.PC_MONITOR_ITEM.get());
                        for (var coloured : ModBlocks.PC_COLORED_ITEMS)
                            if (coloured.get() instanceof dev.cutemod.item.PcColoredItem pc && pc.getBlock() instanceof dev.cutemod.block.PcMonitorBlock) out.accept(pc);
                        for (var ms : ModBlocks.MOUSE_ITEMS.values()) out.accept(ms.get());
                        out.accept(ModBlocks.PC_CASE_MID_ITEM.get());
                        out.accept(ModBlocks.PC_CASE_MINI_ITEM.get());
                        for (var coloured : ModBlocks.PC_COLORED_ITEMS)
                            if (coloured.get() instanceof dev.cutemod.item.PcColoredItem pc && !(pc.getBlock() instanceof dev.cutemod.block.PcMonitorBlock)) out.accept(pc);
                        for (var kb : ModBlocks.KEYBOARD_ITEMS.values()) out.accept(kb.get());
                    })
                    .build());

    public static final Supplier<CreativeModeTab> TAB_FOOD = TABS.register("food", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.cutemod.food"))
                    .icon(() -> {
                        var foods = dev.cutemod.item.ModItems.foods();
                        return new ItemStack(foods.isEmpty() ? net.minecraft.world.item.Items.CAKE : foods.get(0));
                    })
                    .displayItems((params, out) -> {
                        for (net.minecraft.world.item.Item food : dev.cutemod.item.ModItems.foods()) out.accept(food);
                    })
                    .build());

    /** "main": the cute computers, the laptops, the players, the headphones, the bank card. (The id stays "main" so nothing old breaks.) */
    public static final Supplier<CreativeModeTab> TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.cutemod"))
                    .icon(() -> new ItemStack(ModBlocks.get(ComputerColor.PINK).get()))
                    .displayItems((params, out) -> {
                        for (var m : dev.cutemod.block.LaptopModel.values()) out.accept(ModBlocks.getLaptop(m).get());
                        for (ComputerColor c : ComputerColor.values()) {
                            out.accept(ModBlocks.get(c).get());
                        }
                        out.accept(dev.cutemod.item.ModItems.MUSIC_PLAYER.get());
                        for (var player : dev.cutemod.item.ModItems.COLOR_PLAYERS.values()) out.accept(player.get());
                        out.accept(dev.cutemod.item.ModItems.HEADPHONES.get());
                        for (var phones : dev.cutemod.item.ModItems.COLOR_HEADPHONES.values()) out.accept(phones.get());
                        for (var cs : dev.cutemod.item.ModItems.CASES.values()) out.accept(cs.get());
                        out.accept(dev.cutemod.item.ModItems.BANK_CARD.get());
                    })
                    .build());

    public CuteMod(IEventBus modBus) {
        ModBlocks.BLOCKS.register(modBus);
        ModBlocks.ITEMS.register(modBus);
        dev.cutemod.item.ModItems.ARMOR_MATERIALS.register(modBus);
        dev.cutemod.item.ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        TABS.register(modBus);
        modBus.addListener(CuteMod::registerPayloads);
        // the server sends each player what it has saved for them as soon as they join
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedInEvent e) -> {
            RequestDataPayload.sendTo(e.getEntity());
            if (e.getEntity() instanceof net.minecraft.server.level.ServerPlayer sp) { dev.cutemod.net.PostServer.joined(sp); dev.cutemod.net.ShowServer.joined(sp); }
        });
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.RegisterCommandsEvent e) -> { dev.cutemod.net.PostServer.register(e.getDispatcher()); dev.cutemod.net.CoinsCommand.register(e.getDispatcher()); dev.cutemod.net.JobsCommand.register(e.getDispatcher()); dev.cutemod.net.ShowServer.register(e.getDispatcher()); dev.cutemod.net.TubeServer.register(e.getDispatcher()); });
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedOutEvent e) -> { dev.cutemod.net.NetServer.leave(e.getEntity().getUUID()); dev.cutemod.net.PostServer.leave(e.getEntity().getUUID()); dev.cutemod.net.ShowServer.leave(e.getEntity().getUUID()); dev.cutemod.net.ParkServer.leave(e.getEntity().getUUID()); dev.cutemod.net.StreamServer.leave(e.getEntity().getUUID()); dev.cutemod.net.TubeServer.leave(e.getEntity().getUUID()); dev.cutemod.net.CheckersServer.leave(e.getEntity().getUUID()); dev.cutemod.net.BilliardsServer.leave(e.getEntity().getUUID()); dev.cutemod.net.DashServer.leave(e.getEntity().getUUID()); dev.cutemod.net.DurakServer.leave(e.getEntity().getUUID()); });
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.tick.ServerTickEvent.Post e) -> dev.cutemod.net.ShowServer.tick(e.getServer()));
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.tick.ServerTickEvent.Post e) -> dev.cutemod.net.BomberServer.tick(e.getServer()));
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedOutEvent e) -> dev.cutemod.net.BomberServer.forget(e.getEntity().getUUID()));
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.tick.ServerTickEvent.Post e) -> dev.cutemod.net.BedwarsServer.tick(e.getServer()));
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedOutEvent e) -> dev.cutemod.net.BedwarsServer.forget(e.getEntity().getUUID()));
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.tick.ServerTickEvent.Post e) -> dev.cutemod.net.MayhemServer.tick(e.getServer()));
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedOutEvent e) -> dev.cutemod.net.MayhemServer.forget(e.getEntity().getUUID()));
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.tick.ServerTickEvent.Post e) -> dev.cutemod.net.SkribblServer.tick(e.getServer()));
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedOutEvent e) -> dev.cutemod.net.SkribblServer.forget(e.getEntity().getUUID()));
        if (FMLEnvironment.dist.isClient()) dev.cutemod.client.ClientHooks.init(modBus);
    }

    private static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("31");   // 31: the PC build screen, 30: the bigger Bed Wars map, 29: the game mode of a Dangerous Weapons room, 28: online Bed Wars, 27: colour, class and pistol of a Dangerous Weapons player, 26: the map of a Dangerous Weapons room, 25: online Dangerous Weapons, 24: online Bombers, 23: the Stranger's Key packet is gone (the prize is now the Star Set for the pet), 22: the Stranger's Key packet, 21: online Kitty Dash (20: online billiards, 19: the LIVE chat and the player videos of CuteTube)
        registrar.playToServer(ScorePayload.TYPE, ScorePayload.STREAM_CODEC, ScorePayload::handle);
        registrar.playToServer(SaveDataPayload.TYPE, SaveDataPayload.STREAM_CODEC, SaveDataPayload::handle);
        registrar.playToServer(RequestDataPayload.TYPE, RequestDataPayload.STREAM_CODEC, RequestDataPayload::handle);
        registrar.playToClient(SyncDataPayload.TYPE, SyncDataPayload.STREAM_CODEC, SyncDataPayload::handle);
        registrar.playToClient(dev.cutemod.net.HardwarePayload.TYPE, dev.cutemod.net.HardwarePayload.STREAM_CODEC, dev.cutemod.net.HardwarePayload::handle);
        registrar.playToClient(dev.cutemod.net.PcBuildStatePayload.TYPE, dev.cutemod.net.PcBuildStatePayload.STREAM_CODEC, dev.cutemod.net.PcBuildStatePayload::handle);
        registrar.playToServer(dev.cutemod.net.PcBuildActionPayload.TYPE, dev.cutemod.net.PcBuildActionPayload.STREAM_CODEC, dev.cutemod.net.PcBuildActionPayload::handle);
        registrar.playToServer(dev.cutemod.net.MarketOrderPayload.TYPE, dev.cutemod.net.MarketOrderPayload.STREAM_CODEC, dev.cutemod.net.MarketOrderPayload::handle);
        registrar.playToServer(dev.cutemod.net.MarketPickupPayload.TYPE, dev.cutemod.net.MarketPickupPayload.STREAM_CODEC, dev.cutemod.net.MarketPickupPayload::handle);
        registrar.playToServer(dev.cutemod.net.NetScorePayload.TYPE, dev.cutemod.net.NetScorePayload.STREAM_CODEC, dev.cutemod.net.NetScorePayload::handle);
        registrar.playToServer(dev.cutemod.net.NetPingPayload.TYPE, dev.cutemod.net.NetPingPayload.STREAM_CODEC, dev.cutemod.net.NetPingPayload::handle);
        registrar.playToServer(dev.cutemod.net.NetRequestPayload.TYPE, dev.cutemod.net.NetRequestPayload.STREAM_CODEC, dev.cutemod.net.NetRequestPayload::handle);
        registrar.playToClient(dev.cutemod.net.NetSyncPayload.TYPE, dev.cutemod.net.NetSyncPayload.STREAM_CODEC, dev.cutemod.net.NetSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.PostSendPayload.TYPE, dev.cutemod.net.PostSendPayload.STREAM_CODEC, dev.cutemod.net.PostSendPayload::handle);
        registrar.playToServer(dev.cutemod.net.PostRequestPayload.TYPE, dev.cutemod.net.PostRequestPayload.STREAM_CODEC, dev.cutemod.net.PostRequestPayload::handle);
        registrar.playToServer(dev.cutemod.net.PostDeletePayload.TYPE, dev.cutemod.net.PostDeletePayload.STREAM_CODEC, dev.cutemod.net.PostDeletePayload::handle);
        registrar.playToServer(dev.cutemod.net.PostBlockPayload.TYPE, dev.cutemod.net.PostBlockPayload.STREAM_CODEC, dev.cutemod.net.PostBlockPayload::handle);
        registrar.playToClient(dev.cutemod.net.PostSyncPayload.TYPE, dev.cutemod.net.PostSyncPayload.STREAM_CODEC, dev.cutemod.net.PostSyncPayload::handle);
        registrar.playToClient(dev.cutemod.net.AdminCoinsPayload.TYPE, dev.cutemod.net.AdminCoinsPayload.STREAM_CODEC, dev.cutemod.net.AdminCoinsPayload::handle);
        registrar.playToClient(dev.cutemod.net.AdminJobsPayload.TYPE, dev.cutemod.net.AdminJobsPayload.STREAM_CODEC, dev.cutemod.net.AdminJobsPayload::handle);
        registrar.playToClient(dev.cutemod.net.MarketSyncPayload.TYPE, dev.cutemod.net.MarketSyncPayload.STREAM_CODEC, dev.cutemod.net.MarketSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.ShowPutPayload.TYPE, dev.cutemod.net.ShowPutPayload.STREAM_CODEC, dev.cutemod.net.ShowPutPayload::handle);
        registrar.playToServer(dev.cutemod.net.ShowActionPayload.TYPE, dev.cutemod.net.ShowActionPayload.STREAM_CODEC, dev.cutemod.net.ShowActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.ShowPrizePayload.TYPE, dev.cutemod.net.ShowPrizePayload.STREAM_CODEC, dev.cutemod.net.ShowPrizePayload::handle);
        registrar.playToClient(dev.cutemod.net.ShowAlertPayload.TYPE, dev.cutemod.net.ShowAlertPayload.STREAM_CODEC, dev.cutemod.net.ShowAlertPayload::handle);
        registrar.playToServer(dev.cutemod.net.ShowRequestPayload.TYPE, dev.cutemod.net.ShowRequestPayload.STREAM_CODEC, dev.cutemod.net.ShowRequestPayload::handle);
        registrar.playToServer(dev.cutemod.net.ParkMovePayload.TYPE, dev.cutemod.net.ParkMovePayload.STREAM_CODEC, dev.cutemod.net.ParkMovePayload::handle);
        registrar.playToServer(dev.cutemod.net.ParkActionPayload.TYPE, dev.cutemod.net.ParkActionPayload.STREAM_CODEC, dev.cutemod.net.ParkActionPayload::handle);
        registrar.playToServer(dev.cutemod.net.ParkSayPayload.TYPE, dev.cutemod.net.ParkSayPayload.STREAM_CODEC, dev.cutemod.net.ParkSayPayload::handle);
        registrar.playToServer(dev.cutemod.net.StreamActionPayload.TYPE, dev.cutemod.net.StreamActionPayload.STREAM_CODEC, dev.cutemod.net.StreamActionPayload::handle);
        registrar.playToServer(dev.cutemod.net.TubePublishPayload.TYPE, dev.cutemod.net.TubePublishPayload.STREAM_CODEC, dev.cutemod.net.TubePublishPayload::handle);
        registrar.playToServer(dev.cutemod.net.TubeActionPayload.TYPE, dev.cutemod.net.TubeActionPayload.STREAM_CODEC, dev.cutemod.net.TubeActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.StreamSyncPayload.TYPE, dev.cutemod.net.StreamSyncPayload.STREAM_CODEC, dev.cutemod.net.StreamSyncPayload::handle);
        registrar.playToClient(dev.cutemod.net.TubeSyncPayload.TYPE, dev.cutemod.net.TubeSyncPayload.STREAM_CODEC, dev.cutemod.net.TubeSyncPayload::handle);
        registrar.playToClient(dev.cutemod.net.ParkSyncPayload.TYPE, dev.cutemod.net.ParkSyncPayload.STREAM_CODEC, dev.cutemod.net.ParkSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.CheckersActionPayload.TYPE, dev.cutemod.net.CheckersActionPayload.STREAM_CODEC, dev.cutemod.net.CheckersActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.CheckersSyncPayload.TYPE, dev.cutemod.net.CheckersSyncPayload.STREAM_CODEC, dev.cutemod.net.CheckersSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.BilliardsActionPayload.TYPE, dev.cutemod.net.BilliardsActionPayload.STREAM_CODEC, dev.cutemod.net.BilliardsActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.BilliardsSyncPayload.TYPE, dev.cutemod.net.BilliardsSyncPayload.STREAM_CODEC, dev.cutemod.net.BilliardsSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.DashActionPayload.TYPE, dev.cutemod.net.DashActionPayload.STREAM_CODEC, dev.cutemod.net.DashActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.DashSyncPayload.TYPE, dev.cutemod.net.DashSyncPayload.STREAM_CODEC, dev.cutemod.net.DashSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.DurakActionPayload.TYPE, dev.cutemod.net.DurakActionPayload.STREAM_CODEC, dev.cutemod.net.DurakActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.DurakSyncPayload.TYPE, dev.cutemod.net.DurakSyncPayload.STREAM_CODEC, dev.cutemod.net.DurakSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.BomberActionPayload.TYPE, dev.cutemod.net.BomberActionPayload.STREAM_CODEC, dev.cutemod.net.BomberActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.BomberLobbyPayload.TYPE, dev.cutemod.net.BomberLobbyPayload.STREAM_CODEC, dev.cutemod.net.BomberLobbyPayload::handle);
        registrar.playToClient(dev.cutemod.net.BomberStatePayload.TYPE, dev.cutemod.net.BomberStatePayload.STREAM_CODEC, dev.cutemod.net.BomberStatePayload::handle);
        registrar.playToServer(dev.cutemod.net.BedwarsActionPayload.TYPE, dev.cutemod.net.BedwarsActionPayload.STREAM_CODEC, dev.cutemod.net.BedwarsActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.BedwarsLobbyPayload.TYPE, dev.cutemod.net.BedwarsLobbyPayload.STREAM_CODEC, dev.cutemod.net.BedwarsLobbyPayload::handle);
        registrar.playToClient(dev.cutemod.net.BedwarsStatePayload.TYPE, dev.cutemod.net.BedwarsStatePayload.STREAM_CODEC, dev.cutemod.net.BedwarsStatePayload::handle);
        registrar.playToServer(dev.cutemod.net.MayhemActionPayload.TYPE, dev.cutemod.net.MayhemActionPayload.STREAM_CODEC, dev.cutemod.net.MayhemActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.MayhemLobbyPayload.TYPE, dev.cutemod.net.MayhemLobbyPayload.STREAM_CODEC, dev.cutemod.net.MayhemLobbyPayload::handle);
        registrar.playToClient(dev.cutemod.net.MayhemStatePayload.TYPE, dev.cutemod.net.MayhemStatePayload.STREAM_CODEC, dev.cutemod.net.MayhemStatePayload::handle);
        registrar.playToServer(dev.cutemod.net.SkribblActionPayload.TYPE, dev.cutemod.net.SkribblActionPayload.STREAM_CODEC, dev.cutemod.net.SkribblActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.SkribblLobbyPayload.TYPE, dev.cutemod.net.SkribblLobbyPayload.STREAM_CODEC, dev.cutemod.net.SkribblLobbyPayload::handle);
        registrar.playToClient(dev.cutemod.net.SkribblStatePayload.TYPE, dev.cutemod.net.SkribblStatePayload.STREAM_CODEC, dev.cutemod.net.SkribblStatePayload::handle);
        registrar.playToClient(dev.cutemod.net.SkribblDrawPayload.TYPE, dev.cutemod.net.SkribblDrawPayload.STREAM_CODEC, dev.cutemod.net.SkribblDrawPayload::handle);
        registrar.playToClient(dev.cutemod.net.SkribblChatPayload.TYPE, dev.cutemod.net.SkribblChatPayload.STREAM_CODEC, dev.cutemod.net.SkribblChatPayload::handle);
        registrar.playToClient(dev.cutemod.net.SkribblTelePayload.TYPE, dev.cutemod.net.SkribblTelePayload.STREAM_CODEC, dev.cutemod.net.SkribblTelePayload::handle);
        registrar.playToServer(dev.cutemod.net.SeasonClaimPayload.TYPE, dev.cutemod.net.SeasonClaimPayload.STREAM_CODEC, dev.cutemod.net.SeasonClaimPayload::handle);
        registrar.playToClient(dev.cutemod.net.ShowSyncPayload.TYPE, dev.cutemod.net.ShowSyncPayload.STREAM_CODEC, dev.cutemod.net.ShowSyncPayload::handle);
    }
}
