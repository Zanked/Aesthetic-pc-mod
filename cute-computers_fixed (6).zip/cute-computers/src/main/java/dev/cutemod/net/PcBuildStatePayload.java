package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: what is inside a PC case, for the build screen ({@code PcBuildScreen}).
 * {@code open}: open the screen (the first message); otherwise just update the one that is open.
 * {@code event} (EV_*) says what the last action of the player did, {@code detail} gives more (an error code or the slot that was emptied).
 * {@code color}: ordinal of the colour of the case. {@code st} = board, cpu, psu, gpu, disk, modem (-1 = none), cables (0/1), on (0/1), four memory sticks (GB, 0 = empty).
 */
public record PcBuildStatePayload(BlockPos pos, boolean open, int event, int detail, int color, List<Integer> st) implements CustomPacketPayload {
    public static final int EV_NONE = 0, EV_INSTALLED = 1, EV_REMOVED = 2, EV_ON = 3, EV_OFF = 4, EV_ERROR = 5, EV_INCOMPLETE = 6;

    public static final Type<PcBuildStatePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "pc_build_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PcBuildStatePayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, PcBuildStatePayload::pos,
            ByteBufCodecs.BOOL, PcBuildStatePayload::open,
            ByteBufCodecs.VAR_INT, PcBuildStatePayload::event,
            ByteBufCodecs.VAR_INT, PcBuildStatePayload::detail,
            ByteBufCodecs.VAR_INT, PcBuildStatePayload::color,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(16)), PcBuildStatePayload::st,
            PcBuildStatePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(PcBuildStatePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onPcBuild(p));
    }
}
