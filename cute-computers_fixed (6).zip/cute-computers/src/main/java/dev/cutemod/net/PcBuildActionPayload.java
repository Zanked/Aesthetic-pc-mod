package dev.cutemod.net;

import dev.cutemod.CuteMod;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Client -> server: something the player did on the build screen of the PC case at {@code pos}.
 * ACT_INSTALL: {@code arg} = the inventory slot of the part (or the cables) to put in;
 * ACT_REMOVE: {@code arg} = the slot of the case to empty (0 board, 1 cpu, 2 psu, 3 gpu, 4 disk, 5 modem, 6 cables, 10..13 memory sticks);
 * ACT_POWER: the power button; ACT_REFRESH: send the state again.
 */
public record PcBuildActionPayload(BlockPos pos, int action, int arg) implements CustomPacketPayload {
    public static final int ACT_INSTALL = 0, ACT_REMOVE = 1, ACT_POWER = 2, ACT_REFRESH = 3;

    public static final Type<PcBuildActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "pc_build_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PcBuildActionPayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, PcBuildActionPayload::pos,
            ByteBufCodecs.VAR_INT, PcBuildActionPayload::action,
            ByteBufCodecs.VAR_INT, PcBuildActionPayload::arg,
            PcBuildActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(PcBuildActionPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> { if (ctx.player() instanceof ServerPlayer sp) PcBuildServer.handle(sp, p); });
    }
}
