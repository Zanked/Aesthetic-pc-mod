package dev.cutemod.block;

import net.neoforged.neoforge.client.model.data.ModelProperty;

/**
 * What can be seen inside a PC case, packed into one int. It is NOT part of the block state any more (that gave the case 102 400
 * states, and the game keeps a lot of data for every state): the case's block entity hands it to the model as {@code ModelData}
 * and the blockstate model ({@code client/SharedMultipart}) reads it under the same names the old properties had.
 * Bits: 0 board, 1 cpu, 2 psu, 3 disk, 4 net (modem), 5 cables, 6-8 gpu (0..4), 9-11 ram (0..4).
 */
public final class CaseLook {
    private CaseLook() {}

    public static final ModelProperty<Integer> PROPERTY = new ModelProperty<>();

    public static int pack(boolean board, boolean cpu, boolean psu, boolean disk, boolean net, boolean cables, int gpu, int ram) {
        return (board ? 1 : 0) | (cpu ? 2 : 0) | (psu ? 4 : 0) | (disk ? 8 : 0) | (net ? 16 : 0) | (cables ? 32 : 0)
                | (Math.max(0, Math.min(7, gpu)) << 6) | (Math.max(0, Math.min(7, ram)) << 9);
    }

    /** The value of one of the old property names as the model's conditions write it ("true" / "false" / "3"), or null for another name. */
    public static String value(String name, int look) {
        return switch (name) {
            case "board" -> Boolean.toString((look & 1) != 0);
            case "cpu" -> Boolean.toString((look & 2) != 0);
            case "psu" -> Boolean.toString((look & 4) != 0);
            case "disk" -> Boolean.toString((look & 8) != 0);
            case "net" -> Boolean.toString((look & 16) != 0);
            case "cables" -> Boolean.toString((look & 32) != 0);
            case "gpu" -> Integer.toString(look >> 6 & 7);
            case "ram" -> Integer.toString(look >> 9 & 7);
            default -> null;
        };
    }
}
