package dev.cutemod.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.shapes.VoxelShape;

/** The compact slim case: works exactly like the big {@link PcCaseBlock}, only smaller (its models are the big ones squeezed by tools/make_pc_case_sizes.py). */
public class PcCaseMiniBlock extends PcCaseBlock {
    public static final MapCodec<PcCaseMiniBlock> CODEC = simpleCodec(PcCaseMiniBlock::new);
    private static final VoxelShape[] SHAPES = shapes(0.6, 0.74, 0.46);

    public PcCaseMiniBlock(BlockBehaviour.Properties props) { super(props, SHAPES); }

    @Override
    protected MapCodec<? extends net.minecraft.world.level.block.Block> codec() { return CODEC; }
}
