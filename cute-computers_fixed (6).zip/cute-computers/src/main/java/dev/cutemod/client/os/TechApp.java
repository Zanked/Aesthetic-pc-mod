package dev.cutemod.client.os;

import dev.cutemod.data.Build;
import dev.cutemod.data.PcHardware;
import dev.cutemod.item.ModItems;
import dev.cutemod.market.Catalog;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * CuteTech: the electronics store. Laptops, memory, video cards, drives, Wi-Fi routers, portable players, headphones and
 * cases of the players, in one dark "tech" shop (CuteMarket stays the shop of food, gear and materials). It uses the same
 * courier as CuteMarket: the same orders, the same parcels, the same cart rules, so a parcel is collected in either shop.
 *
 * Layout rules (so that nothing sticks out and everything looks the same):
 *  - every text is measured with {@link CuteFont#width} (the font that is really drawn), never with the plain font;
 *  - all the cards have the same size and the same rows; the texts of all the cards share ONE scale ({@link #textScale}),
 *    and what still does not fit is cut with "..." instead of growing out of the card;
 *  - the page margin is 6 px on every side, the gaps are 4-5 px.
 */
public class TechApp extends App {

    @Override
    public boolean needsNet() { return true; }

    // ---------- palette ----------
    // black and red with white cards (the look of a PC-store site): black pages, red accents, red "buy" strips on white cards
    private static final int BG = 0xFF0C0C0F, PANEL = 0xFF121216, ROW_A = 0xFF1A1A1F, ROW_B = 0xFF141418, LINE = 0xFF2A2A31, TRACK = 0xFF2E2E33;
    private static final int RED = 0xFFE31B23, RED_HOT = 0xFFFF3B3F, RED_DEEP = 0xFFB8141B;
    private static final int PAPER = 0xFFF3F3F5, PAPER_HOT = 0xFFFFFFFF, PLATE_L = 0xFFE2E2E8, PLATE_L_EDGE = 0xFFC9C9D1, PLATE_D = 0xFF0C0C0F;
    private static final int TXT = 0xFF16161A, TXT_GRAY = 0xFF70707A;
    private static final int INK = 0xFFF2F2F5, MUTED = 0xFF9A9AA6, SIDE_TXT = 0xFFB4B4BE, WHITE = 0xFFFFFFFF;
    private static final int GREEN = 0xFF2FBF5F, AMBER = 0xFFFFA81C, GREY = 0xFF6B6B75, GOLD = 0xFFFFD36B, DARK = 0xFF16161A;

    // ---------- layout (everything is in app pixels, the app is W x H = 300 x 166) ----------
    private static final int M = 6;                                         // the margin of the page
    private static final int HEAD = 22;
    private static final int SIDE_W = 66;                                   // the categories panel
    private static final int CATS = 11, CAT_Y = 28, CAT_PITCH = 12, CAT_H = 11;
    private static final int PILL_W = 56, PILL_H = 13, PILL_Y = 5;
    private static final int ORD_X = W - M - PILL_W, CART_X = ORD_X - 4 - PILL_W;
    private static final int MENU_W = 38, MENU_X = CART_X - 4 - MENU_W;      // the "Menu" button (leads back to the main menu)

    // the main menu
    private static final int HERO_X = M, HERO_Y = 26, HERO_W = W - 2 * M, HERO_H = 44;
    private static final int BIG_Y = 74, BIG_W = (W - 2 * M - 4) / 2, BIG_H = 50;
    private static final int SMALL_Y = 128, SMALL_H = 32, SMALL_W = (W - 2 * M - 12) / 4;
    private static final int[] SMALL_CATS = {7, 8, 9, 10};

    private static final int PAGE = 6;                                      // 2 columns x 3 rows
    private static final int GRID_X = SIDE_W + 5, GRID_Y = 28;
    private static final int CARD_W = 109, CARD_H = 36, COL_PITCH = CARD_W + 5, ROW_PITCH = CARD_H + 4;
    private static final int TEXT_X = 33, TEXT_W = CARD_W - TEXT_X - 4;     // the text column of a card
    private static final int PAGER_Y = 148, PAGER_H = 12, PG_BTN = 12;
    private static final float MIN_K = 0.75F;                               // the smallest shared scale of the card texts

    // the cart and the orders
    private static final int ROW_X = 4, ROW_W = W - 8;
    private static final int MINUS_X = 160, PLUS_X = 196, QTY_CX = 184;
    private static final int BAR_Y = 125;                                   // the bottom bar of the cart
    private static final int ORDER_W = 86, ORDER_H = 20, ORDER_X = W - M - ORDER_W, ORDER_Y = 140;

    // category -> the shop kind and the id prefix of what it shows
    // laptops, processors, motherboards, power supplies, memory, video cards, drives, Wi-Fi, players, headphones, cases
    private static final int[] CAT_KIND = {Catalog.LAPTOP, Catalog.PART, Catalog.PART, Catalog.PART, Catalog.PART, Catalog.PART, Catalog.PART, Catalog.PART, Catalog.PLAYER, Catalog.PLAYER, Catalog.PLAYER};
    private static final String[] CAT_PREFIX = {"laptop_", "pc_cpu_", "pc_board_", "pc_psu_", "pc_ram_", "pc_gpu_", "pc_disk_", "wifi_router_", Catalog.PLAYER_BASE, Catalog.HEADPHONES, Catalog.CASE_BASE};

    private static final int HOME = 3;                                      // the main menu: banner and picture tiles
    private int tab = HOME, from = HOME, cat, page, scroll;
    private boolean express;
    private final Map<String, Integer> cart = new LinkedHashMap<>();

    @Override
    public Component title() { return Component.translatable("cutemod.os.tech"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.tech"); }

    @Override
    public Component status() {
        int a = Market.active();
        return a > 0 ? Component.translatable("cutemod.market.status", a) : Component.empty();
    }

    @Override
    public void tick() { Market.tick(); }

    private int cartCount() {
        int n = 0;
        for (int v : cart.values()) n += v;
        return n;
    }

    // ---------- helpers ----------
    /** The width of a line exactly as it is drawn (the mod's font), the only right way to lay text out. */
    private static int tw(String s) { return CuteFont.width(font(), s); }

    private static void txt(GuiGraphics g, String s, int x, int y, int argb) { Skin.str(g, font(), s, x, y, argb, false); }

    /** A line that ends at rx. */
    private static void rtxt(GuiGraphics g, String s, int rx, int y, int argb) { Skin.str(g, font(), s, rx - tw(s), y, argb, false); }

    /** A line inside a box of maxW pixels: at scale k, and cut with "..." if it is still too wide (it never leaves the box). */
    private static void label(GuiGraphics g, String s, int x, int y, int argb, int maxW, float k) {
        Font f = font();
        String c = CuteFont.cut(f, s, Math.max(4, Math.round(maxW / k)));
        if (k >= 0.999F) { Skin.str(g, f, c, x, y, argb, false); return; }
        g.pose().pushPose();
        g.pose().translate(x, y + (1F - k) * 4F, 0);
        g.pose().scale(k, k, 1F);
        Skin.str(g, f, c, 0, 0, argb, false);
        g.pose().popPose();
    }

    /** A line centred in a box of maxW pixels (smaller when it is too wide, never cut unless it must be). */
    private static void centered(GuiGraphics g, String s, int x, int y, int argb, int maxW) {
        Skin.boxC(g, font(), s, x, y, argb, false, maxW);
    }

    private static void btn(GuiGraphics g, int x, int y, int w, int h, String label, boolean enabled, boolean hover, int color) {
        App.roundRect(g, x, y, w, h, 4, !enabled ? TRACK : hover ? mix(color, 0xFFFFFF, 0.2f) : color);
        centered(g, label, x + 2, y + (h - 8) / 2 + 1, enabled ? WHITE : 0xFF77777F, w - 4);
    }

    /** A white card with a thin red outline and a shadow; the bottom {@link #STRIP_H} px are the red strip (drawn by {@link #strip}). */
    private static void card(GuiGraphics g, int x, int y, int w, int h, int fill, int border) {
        App.roundRect(g, x, y + 1, w, h, 5, 0x66000000);
        App.roundRect(g, x, y, w, h, 5, border);
        App.roundRect(g, x + 1, y + 1, w - 2, h - 2, 4, fill);
    }

    private static final int STRIP_H = 10;

    /** The strip at the bottom of a card: square on top, round at the bottom corners (inside the 1 px outline). */
    private static void strip(GuiGraphics g, int x, int y, int w, int h, int argb) {
        int r = 4;
        for (int dy = 0; dy < h; dy++) {
            double m = dy + 0.5;
            int inset = 0;
            if (m > h - r) {
                double e = m - (h - r);
                inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - e * e)));
            }
            Skin.rect(g, x + inset, y + dy, w - 2 * inset, 1, argb);
        }
    }

    private static final Map<String, ItemStack> STACKS = new HashMap<>();

    /** The real item behind a catalog id (for its icon); empty while no world is loaded. */
    private static ItemStack stack(String id) {
        ItemStack st = STACKS.get(id);
        if (st != null) return st;
        var level = net.minecraft.client.Minecraft.getInstance().level;
        if (level == null) return ItemStack.EMPTY;
        st = Catalog.create(id, level.registryAccess());
        STACKS.put(id, st);
        return st;
    }

    /** The picture of an item (16 px at scale 1, its top-left corner at x,y) on a soft round plate that is pad px bigger on every side. */
    private static void icon(GuiGraphics g, String id, int x, int y, float s, int pad) { icon(g, id, x, y, s, pad, LINE, PLATE_D); }

    private static void icon(GuiGraphics g, String id, int x, int y, float s, int pad, int edge, int fill) {
        int size = Math.round(16 * s);
        App.roundRect(g, x - pad, y - pad, size + pad * 2, size + pad * 2, 5, edge);
        App.roundRect(g, x - pad + 1, y - pad + 1, size + pad * 2 - 2, size + pad * 2 - 2, 4, fill);
        ItemStack st = stack(id);
        if (st.isEmpty()) return;
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(s, s, 1f);
        g.renderItem(st, 0, 0);
        g.pose().popPose();
    }

    private static String name(String id) { return MarketApp.name(id); }

    /** What is in a category, in shop order (the prices already include today's sales). */
    private static List<Market.Item> list(int c) {
        List<Market.Item> out = new ArrayList<>();
        String prefix = CAT_PREFIX[c];
        for (Market.Item it : Market.items(CAT_KIND[c])) {
            if (!it.id().startsWith(prefix)) continue;
            if (c == 8 && it.id().startsWith(Catalog.CASE_BASE)) continue;      // "player_case_" does not start with "music_player", but be safe
            out.add(it);
        }
        return out;
    }

    /** The grey line under a product: what it is (the same words as in CuteMarket for the parts). */
    private static String sub(Market.Item it) {
        if (it.kind() == Catalog.PART) return t("cutemod.market.part." + it.id());
        if (it.kind() == Catalog.LAPTOP) {                                       // the soldered parts: processor, card, memory
            var m = dev.cutemod.block.LaptopModel.byId(it.id().substring(Catalog.LAPTOP_BASE.length() + 1));
            if (m == null) return t("cutemod.tech.sub.laptop");
            Build b = m.line.build();
            return Build.CPU_NAMES[b.cpu] + " \u00B7 " + (b.gpu == 0 ? "iGPU" : PcHardware.GPU_NAMES[b.gpu]) + " \u00B7 " + b.ramGb() + " GB";
        }
        if (it.id().startsWith(Catalog.HEADPHONES)) return t("cutemod.market.sub.headphones");
        if (it.id().startsWith(Catalog.CASE_BASE)) return t("cutemod.tech.sub.case");
        return t("cutemod.tech.sub.player");
    }

    /** For a part of this PC: 1 = it is already in (or better), 2 = it would be an upgrade, 3 = it does not fit (socket, no free slot), 0 = not a part of the PC (router...). */
    private static int partState(String id) {
        int[] info = ModItems.partInfo(id);
        if (info == null) return 0;
        PcHardware.Kind kind = PcHardware.Kind.values()[info[0]];
        Build b = PcSpecs.build().copy();
        int lv = kind == PcHardware.Kind.RAM ? Build.STICK_GB[info[1]] : info[1];
        Build.Result r = b.install(kind, lv, new int[1]);
        return r == Build.Result.OK ? 2 : r == Build.Result.SOCKET || r == Build.Result.NO_SLOT ? 3 : 1;
    }

    // one scale for the texts of ALL the cards of ALL the categories, so every card looks the same
    private static float textK = 1F;
    private static long textAt;

    private static float textScale(Font f) {
        long now = System.currentTimeMillis();
        if (now - textAt < 1500) return textK;
        textAt = now;
        List<String> all = new ArrayList<>();
        for (int c = 0; c < CATS; c++) {
            for (Market.Item it : list(c)) { all.add(name(it.id())); all.add(sub(it)); }
        }
        textK = all.isEmpty() ? 1F : Skin.group(f, TEXT_W, MIN_K, all.toArray(new String[0]));
        return textK;
    }

    /** A round status badge (9 x 9) centred at cx,cy: a tick (already in the PC), an arrow up (an upgrade) or a cross (does not fit). */
    private static void badge(GuiGraphics g, int cx, int cy, int state, int ring) {
        int col = state == 1 ? GREEN : state == 3 ? GREY : AMBER;
        int ink = state == 1 ? WHITE : state == 3 ? WHITE : DARK;
        Skin.disc(g, cx, cy, 5, ring);
        Skin.disc(g, cx, cy, 4, col);
        if (state == 1) {                                                   // the tick
            Skin.rect(g, cx - 2, cy, 1, 1, ink); Skin.rect(g, cx - 1, cy + 1, 1, 1, ink);
            Skin.rect(g, cx, cy, 1, 1, ink); Skin.rect(g, cx + 1, cy - 1, 1, 1, ink); Skin.rect(g, cx + 2, cy - 2, 1, 1, ink);
        } else if (state == 3) {                                            // the cross
            for (int i = -2; i <= 2; i++) { Skin.rect(g, cx + i, cy + i, 1, 1, ink); Skin.rect(g, cx + i, cy - i, 1, 1, ink); }
        } else {                                                            // the arrow up
            Skin.rect(g, cx, cy - 2, 1, 1, ink);
            Skin.rect(g, cx - 1, cy - 1, 3, 1, ink);
            Skin.rect(g, cx - 2, cy, 5, 1, ink);
            Skin.rect(g, cx, cy + 1, 1, 2, ink);
        }
    }

    // ---------- render ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        Skin.rect(g, 0, 0, W, H, BG);
        // header: black with a red top edge and a red line under it, the red chip logo and the name "Cute" + red "Tech"
        Skin.grad(g, 0, 0, W, HEAD, 0xFF1C1C22, 0xFF0C0C0F);
        Skin.rect(g, 0, 0, W, 2, RED);
        Skin.rect(g, 0, HEAD - 1, W, 1, RED);
        for (int i = 0; i < 2; i++) {                                       // the pins of the chip
            Skin.rect(g, 9 + i * 4, 3, 1, 2, RED); Skin.rect(g, 9 + i * 4, 17, 1, 2, RED);
            Skin.rect(g, 4, 8 + i * 4, 2, 1, RED); Skin.rect(g, 18, 8 + i * 4, 2, 1, RED);
        }
        App.roundRect(g, 6, 5, 12, 12, 3, RED);
        Skin.rect(g, 9, 8, 6, 6, WHITE);
        Skin.rect(g, 11, 10, 2, 2, RED);
        int titleW = (tab != HOME ? MENU_X : CART_X) - 8 - 24;
        int cuteW = tw("Cute");
        Skin.str(g, f, "Cute", 24, 4, WHITE, false);
        Skin.box(g, f, "Tech", 24 + cuteW, 4, RED_HOT, false, titleW - cuteW);
        Skin.box(g, f, t("cutemod.tech.tagline"), 24, 12, MUTED, false, titleW);
        String[] navNames = {t("cutemod.market.nav.cart"), t("cutemod.market.nav.orders")};
        float navK = Skin.group(f, PILL_W - 17, 0.7F, navNames);
        if (tab != HOME) {
            boolean mh = in(mx, my, MENU_X, PILL_Y, MENU_W, PILL_H);
            App.roundRect(g, MENU_X, PILL_Y, MENU_W, PILL_H, 6, mh ? 0xFF3A3A42 : 0xFF26262C);
            Skin.boxK(g, f, t("cutemod.tech.menu"), MENU_X + 3, PILL_Y + 3, WHITE, false, MENU_W - 6, true, 0.85F);
        }
        navPill(g, mx, my, CART_X, navNames[0], cartCount(), tab == 1, navK);
        navPill(g, mx, my, ORD_X, navNames[1], Market.active(), tab == 2, navK);
        switch (tab) {
            case 0 -> renderShop(g, mx, my);
            case HOME -> renderHome(g, mx, my);
            case 1 -> renderCart(g, mx, my);
            default -> renderOrders(g, mx, my);
        }
    }

    /** A header button: the name in the left part, a round counter in the right part (the counter never leaves the button). */
    private static void navPill(GuiGraphics g, int mx, int my, int x, String label, int n, boolean sel, float k) {
        Font f = font();
        boolean hov = in(mx, my, x, PILL_Y, PILL_W, PILL_H);
        App.roundRect(g, x, PILL_Y, PILL_W, PILL_H, 6, sel ? RED : hov ? 0xFF3A3A42 : 0xFF26262C);
        Skin.boxK(g, f, label, x + 4, PILL_Y + 3, WHITE, false, PILL_W - 17, true, k);
        if (n > 0) {
            String q = n > 9 ? "9+" : Integer.toString(n);
            int bw = Math.max(9, tw(q) + 4);
            App.roundRect(g, x + PILL_W - 3 - bw, PILL_Y + 2, bw, 9, 4, WHITE);
            Skin.str(g, f, q, x + PILL_W - 3 - bw + (bw - tw(q)) / 2, PILL_Y + 2, RED, false);
        }
    }


    // ---------- the main menu ----------
    /** A bare item picture (no plate), top-left corner at x,y, scale s (1 = 16 px). */
    private static void bare(GuiGraphics g, String id, int x, int y, float s) {
        ItemStack st = stack(id);
        if (st.isEmpty()) return;
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(s, s, 1f);
        g.renderItem(st, 0, 0);
        g.pose().popPose();
    }

    /** The id of the n-th product of a category (n < 0 counts from the end); "" when the shelf is empty. */
    private static String pick(int c, int n) {
        List<Market.Item> l = list(c);
        if (l.isEmpty()) return "";
        return l.get(n < 0 ? Math.max(0, l.size() + n) : Math.min(n, l.size() - 1)).id();
    }

    /** The lowest price on the shelves of categories a..b (0 when they are all empty). */
    private static int cheapest(int a, int b) {
        int best = Integer.MAX_VALUE;
        for (int c = a; c <= b; c++) for (Market.Item it : list(c)) best = Math.min(best, it.price());
        return best == Integer.MAX_VALUE ? 0 : best;
    }

    private static int count(int a, int b) {
        int n = 0;
        for (int c = a; c <= b; c++) n += list(c).size();
        return n;
    }

    /** Big text (scale up to cap, smaller when it would not fit maxW). */
    private static void big(GuiGraphics g, String s, int x, int y, int argb, int maxW, float cap) {
        float k = Math.min(cap, maxW / (float) Math.max(1, tw(s)));
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(k, k, 1F);
        Skin.str(g, font(), s, 0, 0, argb, false);
        g.pose().popPose();
    }

    /** The picture of the banner: a monitor with a glowing screen, drawn in code. */
    private static void monitor(GuiGraphics g, int x, int y) {
        App.roundRect(g, x - 2, y - 2, 68, 40, 6, 0x55E31B23);                 // the glow
        App.roundRect(g, x, y, 64, 36, 4, 0xFF2A2A31);
        App.roundRect(g, x + 1, y + 1, 62, 34, 3, RED_DEEP);
        Skin.grad(g, x + 3, y + 3, x + 61, y + 31, 0xFF3A0A10, 0xFFE31B23);
        Skin.rect(g, x + 7, y + 8, 22, 3, 0xFFFFFFFF);                          // the lines of a little screen
        Skin.rect(g, x + 7, y + 14, 34, 2, 0xAAFFFFFF);
        Skin.rect(g, x + 7, y + 19, 28, 2, 0x88FFFFFF);
        App.roundRect(g, x + 41, y + 20, 16, 8, 2, 0xFFFFFFFF);
        Skin.rect(g, x + 45, y + 23, 8, 2, RED);
        Skin.rect(g, x + 29, y + 36, 6, 3, 0xFF2A2A31);                         // the stand
        App.roundRect(g, x + 20, y + 38, 24, 3, 1, 0xFF3A3A42);
    }

    private void renderHome(GuiGraphics g, int mx, int my) {
        Font f = font();
        // ----- the banner -----
        App.roundRect(g, HERO_X, HERO_Y, HERO_W, HERO_H, 6, RED_DEEP);
        App.roundRect(g, HERO_X + 1, HERO_Y + 1, HERO_W - 2, HERO_H - 2, 5, 0xFF0C0C0F);
        for (int sx = HERO_X + 70; sx < HERO_X + HERO_W - 4; sx += 3) {         // a red glow that grows to the right
            float t = (sx - (HERO_X + 70)) / (float) (HERO_W - 74);
            Skin.rect(g, sx, HERO_Y + 3, 3, HERO_H - 6, mix(0x0C0C0F, 0x6A0C12, t * t));
        }
        int tx = HERO_X + 8, tw0 = 136;
        String tag = t("cutemod.tech.home.tag");
        int tagW = Math.min(tw0, tw(tag) + 8);
        App.roundRect(g, tx, HERO_Y + 5, tagW, 9, 4, RED);
        Skin.boxK(g, f, tag, tx + 4, HERO_Y + 6, WHITE, false, tagW - 6, false, 0.8F);
        big(g, t("cutemod.tech.home.t1"), tx, HERO_Y + 16, WHITE, tw0, 1.3F);
        big(g, t("cutemod.tech.home.t2"), tx, HERO_Y + 27, RED_HOT, tw0, 1.3F);
        int bx = HERO_X + 98, by = HERO_Y + HERO_H - 14, bw = 38, bh = 11;
        btn(g, bx, by, bw, bh, t("cutemod.tech.home.go"), true, in(mx, my, bx, by, bw, bh), RED);
        monitor(g, HERO_X + 152, HERO_Y + 3);
        bare(g, pick(0, 0), HERO_X + 224, HERO_Y + 5, 2F);                      // a laptop and a video card by the monitor
        bare(g, pick(5, -1), HERO_X + 262, HERO_Y + 22, 1.5F);

        // ----- two big picture tiles: computers and components -----
        String[] bigName = {t("cutemod.tech.home.pc"), t("cutemod.tech.home.parts")};
        float bk = Skin.group(f, BIG_W - 80, 0.7F, bigName);
        for (int i = 0; i < 2; i++) {
            int x = HERO_X + i * (BIG_W + 4);
            boolean hov = in(mx, my, x, BIG_Y, BIG_W, BIG_H);
            card(g, x, BIG_Y, BIG_W, BIG_H, hov ? PAPER_HOT : PAPER, hov ? RED_HOT : RED_DEEP);
            int n = i == 0 ? count(0, 0) : count(1, 6);
            label(g, bigName[i], x + 7, y0(BIG_Y, 6), TXT, BIG_W - 80, bk);
            label(g, t("cutemod.tech.home.items", n), x + 7, BIG_Y + 17, TXT_GRAY, BIG_W - 80, 0.85F);
            String[] ids = i == 0 ? new String[]{pick(0, 0), pick(0, 4), pick(0, -1)} : new String[]{pick(1, -1), pick(5, -1), pick(4, -1)};
            App.roundRect(g, x + BIG_W - 74, BIG_Y + 4, 70, 34, 5, PLATE_L_EDGE);
            App.roundRect(g, x + BIG_W - 73, BIG_Y + 5, 68, 32, 4, PLATE_L);
            for (int k = 0; k < 3; k++) bare(g, ids[k], x + BIG_W - 72 + k * 22, BIG_Y + 10 + (k == 1 ? -2 : 1), 1.25F);
            int sy = BIG_Y + BIG_H - 1 - STRIP_H;
            strip(g, x + 1, sy, BIG_W - 2, STRIP_H, hov ? RED_HOT : RED);
            int low = i == 0 ? cheapest(0, 0) : cheapest(1, 6);
            String fromS = t("cutemod.tech.home.from");
            String price = Integer.toString(low);
            int cw = tw(fromS) + 4 + 7 + 3 + tw(price);
            int px = x + (BIG_W - cw) / 2;
            Skin.str(g, f, fromS, px, sy + 1, WHITE, false);
            Progress.drawCoin(g, px + tw(fromS) + 4, sy + 2);
            Skin.str(g, f, price, px + tw(fromS) + 14, sy + 1, WHITE, false);
        }

        // ----- four small tiles: Wi-Fi, players, headphones, cases -----
        String[] smallName = new String[4];
        for (int i = 0; i < 4; i++) smallName[i] = t("cutemod.tech.cat." + SMALL_CATS[i]);
        float sk = Skin.group(f, SMALL_W - 30, 0.7F, smallName);
        for (int i = 0; i < 4; i++) {
            int x = HERO_X + i * (SMALL_W + 4);
            boolean hov = in(mx, my, x, SMALL_Y, SMALL_W, SMALL_H);
            card(g, x, SMALL_Y, SMALL_W, SMALL_H, hov ? PAPER_HOT : PAPER, hov ? RED_HOT : RED_DEEP);
            icon(g, pick(SMALL_CATS[i], 0), x + 6, SMALL_Y + 8, 1.0f, 2, PLATE_L_EDGE, PLATE_L);
            label(g, smallName[i], x + 27, SMALL_Y + 8, TXT, SMALL_W - 30, sk);
            int low = cheapest(SMALL_CATS[i], SMALL_CATS[i]);
            Progress.drawCoin(g, x + 27, SMALL_Y + 19);
            Skin.str(g, f, t("cutemod.tech.home.from") + " " + low, x + 37, SMALL_Y + 18, TXT_GRAY, false);
        }
    }

    private static int y0(int y, int dy) { return y + dy; }

    private void renderShop(GuiGraphics g, int mx, int my) {
        Font f = font();
        // the side panel with the categories (their names share one scale)
        Skin.rect(g, 0, HEAD, SIDE_W, H - HEAD, PANEL);
        Skin.rect(g, SIDE_W - 1, HEAD, 1, H - HEAD, LINE);
        String[] names = new String[CATS];
        for (int k = 0; k < CATS; k++) names[k] = t("cutemod.tech.cat." + k);
        float catK = Skin.group(f, SIDE_W - 18, 0.7F, names);
        for (int k = 0; k < CATS; k++) {
            int cy = CAT_Y + k * CAT_PITCH;
            boolean sel = cat == k;
            boolean hov = in(mx, my, 4, cy, SIDE_W - 9, CAT_H);
            if (sel) {
                App.roundRect(g, 4, cy, SIDE_W - 9, CAT_H, 5, RED);
            } else if (hov) {
                App.roundRect(g, 4, cy, SIDE_W - 9, CAT_H, 5, 0xFF26262C);
            }
            Skin.boxK(g, f, names[k], 10, cy + 2, sel ? WHITE : hov ? WHITE : SIDE_TXT, false, SIDE_W - 18, false, catK);
        }

        List<Market.Item> items = list(cat);
        int pages = Math.max(1, (items.size() + PAGE - 1) / PAGE);
        page = Math.min(page, pages - 1);
        float k = textScale(f);
        for (int i = 0; i < PAGE; i++) {
            int idx = page * PAGE + i;
            if (idx >= items.size()) break;
            Market.Item it = items.get(idx);
            int cx = GRID_X + (i % 2) * COL_PITCH, cy = GRID_Y + (i / 2) * ROW_PITCH;
            boolean hov = in(mx, my, cx, cy, CARD_W, CARD_H);
            int fill = hov ? PAPER_HOT : PAPER;
            card(g, cx, cy, CARD_W, CARD_H, fill, hov ? RED_HOT : RED_DEEP);
            icon(g, it.id(), cx + 8, cy + 5, 1.0f, 2, PLATE_L_EDGE, PLATE_L);
            int ps = partState(it.id());
            int tx = cx + TEXT_X;
            // row 1: the name, row 2: what it is (on hover: how it fits your PC), then the red strip with the price or "add to cart"
            label(g, name(it.id()), tx, cy + 4, TXT, TEXT_W, k);
            if (hov && ps != 0) {
                String s = t(ps == 1 ? "cutemod.tech.have" : ps == 3 ? "cutemod.tech.nofit" : "cutemod.tech.better");
                label(g, s, tx, cy + 14, ps == 1 ? 0xFF1E9E4A : ps == 3 ? RED_DEEP : 0xFFD98200, TEXT_W, k);
            } else {
                label(g, sub(it), tx, cy + 14, TXT_GRAY, TEXT_W, k);
            }
            int sy = cy + CARD_H - 1 - STRIP_H;                             // the strip: y of its top
            boolean rich = Progress.coins() >= it.price();
            strip(g, cx + 1, sy, CARD_W - 2, STRIP_H, hov ? RED_HOT : rich ? RED : 0xFF3A3A42);
            if (hov) {
                centered(g, t("cutemod.market.add"), cx + 2, sy + 1, WHITE, CARD_W - 4);
            } else {
                String price = Integer.toString(it.price());
                int cw = 7 + 3 + tw(price);
                int px = cx + (CARD_W - cw) / 2;
                Progress.drawCoin(g, px, sy + 2);
                Skin.str(g, f, price, px + 10, sy + 1, rich ? WHITE : 0xFFFF9A9E, false);
                int deal = dev.cutemod.market.Deals.percent(it.id());
                if (deal > 0) {                                             // on sale today: a light tag at the right end of the strip
                    String d = "-" + deal + "%";
                    int dx = cx + CARD_W - 5 - tw(d);
                    if (dx > px + cw + 4) Skin.str(g, f, d, dx, sy + 1, 0xFFFFD2D4, false);
                }
            }
            Integer inCart = cart.get(it.id());
            if (inCart != null) {
                String q = "x" + inCart;
                int bw = Math.max(13, tw(q) + 5);
                App.roundRect(g, cx + 2, cy + 2, bw, 10, 4, TXT);
                Skin.str(g, f, q, cx + 2 + (bw - tw(q)) / 2, cy + 3, WHITE, false);
            }
            if (ps != 0) badge(g, cx + 24, cy + 19, ps, fill);
        }
        if (items.isEmpty()) {
            centered(g, t("cutemod.tech.empty"), GRID_X, 80, MUTED, W - M - GRID_X);
        }
        // the bottom row: the page switcher in the middle of the shelves (the balance is shown only in the bank)
        if (pages > 1) {
            int[] pg = pager(f, pages);
            btn(g, pg[0], PAGER_Y, PG_BTN, PAGER_H, "<", page > 0, in(mx, my, pg[0], PAGER_Y, PG_BTN, PAGER_H), RED);
            btn(g, pg[2], PAGER_Y, PG_BTN, PAGER_H, ">", page < pages - 1, in(mx, my, pg[2], PAGER_Y, PG_BTN, PAGER_H), RED);
            Skin.str(g, f, (page + 1) + "/" + pages, pg[1], PAGER_Y + 2, MUTED, false);
        }
    }

    /** Where the page switcher goes: {left arrow x, numbers x, right arrow x}, centred under the shelves with a gap on both sides of the numbers. */
    private int[] pager(Font f, int pages) {
        String num = (page + 1) + "/" + pages;
        int w = tw(num);
        int mid = GRID_X + (W - M - GRID_X) / 2;
        int text = mid - w / 2;
        return new int[]{text - 4 - PG_BTN, text, text + w + 4};
    }

    private void renderCart(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<Map.Entry<String, Integer>> rows = new ArrayList<>(cart.entrySet());
        if (rows.isEmpty()) {
            centered(g, t("cutemod.market.cart_empty"), M, 74, MUTED, W - M * 2);
        }
        g.enableScissor(shell.absX(), shell.absY() + HEAD + 2, shell.absX() + W, shell.absY() + BAR_Y - 1);
        for (int i = 0; i < rows.size(); i++) {
            int y = HEAD + 4 + i * 17 - scroll;
            if (y < HEAD - 14 || y > BAR_Y - 1) continue;
            String id = rows.get(i).getKey();
            Market.Item it = Market.item(id);
            int q = rows.get(i).getValue();
            App.roundRect(g, ROW_X, y, ROW_W, 16, 4, i % 2 == 0 ? ROW_A : ROW_B);
            icon(g, id, ROW_X + 5, y + 2, 0.75f, 1);
            label(g, name(id), ROW_X + 22, y + 4, WHITE, MINUS_X - 8 - (ROW_X + 22), 1F);
            btn(g, MINUS_X, y + 2, 12, 12, "-", true, in(mx, my, MINUS_X, y + 2, 12, 12), RED);
            String qs = Integer.toString(q);
            txt(g, qs, QTY_CX - tw(qs) / 2, y + 4, WHITE);
            boolean canPlus = q < Math.min(9, it.maxQty());
            btn(g, PLUS_X, y + 2, 12, 12, "+", canPlus, canPlus && in(mx, my, PLUS_X, y + 2, 12, 12), RED);
            Progress.drawCoin(g, W - M - 7 - 4, y + 5);
            rtxt(g, Integer.toString(it.price() * q), W - M - 7 - 8, y + 4, WHITE);
        }
        g.disableScissor();
        // bottom bar
        Skin.rect(g, 0, BAR_Y, W, H - BAR_Y, PANEL);
        Skin.rect(g, 0, BAR_Y, W, 1, RED);
        Skin.rect(g, M, 129, 10, 10, express ? RED : ROW_A);
        Skin.rect(g, M, 129, 10, 1, LINE); Skin.rect(g, M, 138, 10, 1, LINE); Skin.rect(g, M, 129, 1, 10, LINE); Skin.rect(g, M + 9, 129, 1, 10, LINE);
        if (express) { Skin.rect(g, 8, 133, 2, 2, WHITE); Skin.rect(g, 10, 134, 2, 2, WHITE); Skin.rect(g, 12, 131, 2, 4, WHITE); }
        Skin.box(g, f, t("cutemod.market.express", Market.EXPRESS_PCT, Market.EXPRESS_SPEED), 21, 130, 0xFFE0E0E6, false, W - M - 21);
        int total = Market.total(cart, express);
        String ts = t("cutemod.market.total", total);
        txt(g, ts, M, 147, WHITE);
        boolean can = !cart.isEmpty() && Progress.coins() >= total;
        if (!cart.isEmpty() && Progress.coins() < total) {
            int px = M + tw(ts) + 8;
            Skin.box(g, f, t("cutemod.market.poor"), px, 147, RED_HOT, false, ORDER_X - 6 - px);
        }
        btn(g, ORDER_X, ORDER_Y, ORDER_W, ORDER_H, t("cutemod.market.order"), can, can && in(mx, my, ORDER_X, ORDER_Y, ORDER_W, ORDER_H), RED);
    }

    private void renderOrders(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<Market.Order> list = Market.orders();
        if (list.isEmpty()) {
            centered(g, t("cutemod.market.no_orders"), M, 74, MUTED, W - M * 2);
        }
        g.enableScissor(shell.absX(), shell.absY() + HEAD, shell.absX() + W, shell.absY() + H);
        for (int i = 0; i < list.size(); i++) {
            Market.Order o = list.get(i);
            int y = HEAD + 3 + i * 24 - scroll;
            if (y < HEAD - 22 || y > H) continue;
            App.roundRect(g, ROW_X, y, ROW_W, 23, 4, i % 2 == 0 ? ROW_A : ROW_B);
            icon(g, o.id, ROW_X + 6, y + 4, 1.0f, 2);
            label(g, name(o.id) + (o.qty > 1 ? " x" + o.qty : ""), 34, y + 3, WHITE, 150, 1F);
            if (Market.arrived(o)) {
                label(g, t("cutemod.market.arrived"), 34, y + 13, GREEN, 150, 1F);
                btn(g, W - 76, y + 3, 68, 17, t("cutemod.market.collect"), true, in(mx, my, W - 76, y + 3, 68, 17), RED);
            } else {
                int total = Math.max(1000, (int) (Market.item(o.id).secs() * 1000L / 3));
                float frac = Math.max(0f, Math.min(1f, 1f - Market.secondsLeft(o) * 1000f / Math.max(total, Market.item(o.id).secs() * 1000f)));
                App.roundRect(g, 34, y + 14, 150, 5, 2, TRACK);
                int fill = Math.round(150 * frac);
                if (fill > 0) App.roundRect(g, 34, y + 14, Math.max(4, fill), 5, 2, RED);
                int cx = 34 + fill;
                App.roundRect(g, Math.max(34, Math.min(184 - 6, cx - 3)), y + 12, 6, 8, 2, WHITE);     // the courier
                int s = Market.secondsLeft(o);
                rtxt(g, (s / 60) + ":" + String.format("%02d", s % 60), W - M - 4, y + 7, MUTED);
            }
        }
        g.disableScissor();
    }

    // ---------- input ----------
    private void setTab(int t) { tab = t; scroll = 0; }

    /** Remember where the cart and the orders lead back to: the shelves or the main menu. */
    private void keepFrom() { if (tab == 0 || tab == HOME) from = tab; }

    private void openShelf(int c) { cat = c; page = 0; from = 0; setTab(0); }

    private void clickHome(int x, int y) {
        if (in(x, y, HERO_X + 98, HERO_Y + HERO_H - 14, 38, 11)) { openShelf(0); return; }
        for (int i = 0; i < 2; i++) {
            if (in(x, y, HERO_X + i * (BIG_W + 4), BIG_Y, BIG_W, BIG_H)) { openShelf(i == 0 ? 0 : 1); return; }
        }
        for (int i = 0; i < 4; i++) {
            if (in(x, y, HERO_X + i * (SMALL_W + 4), SMALL_Y, SMALL_W, SMALL_H)) { openShelf(SMALL_CATS[i]); return; }
        }
    }

    private int pages() { return Math.max(1, (list(cat).size() + PAGE - 1) / PAGE); }

    @Override
    public boolean click(int x, int y, int button) {
        if (y < HEAD) {
            if (in(x, y, CART_X, PILL_Y, PILL_W, PILL_H)) { if (tab == 1) setTab(from); else { keepFrom(); setTab(1); } }
            else if (in(x, y, ORD_X, PILL_Y, PILL_W, PILL_H)) { if (tab == 2) setTab(from); else { keepFrom(); setTab(2); } }
            else if (tab != HOME) setTab(HOME);                        // the name of the shop and the Menu button lead to the main menu
            return true;
        }
        switch (tab) {
            case 0 -> clickShop(x, y);
            case HOME -> clickHome(x, y);
            case 1 -> clickCart(x, y);
            default -> clickOrders(x, y);
        }
        return true;
    }

    private void clickShop(int x, int y) {
        for (int k = 0; k < CATS; k++) {
            if (in(x, y, 4, CAT_Y + k * CAT_PITCH, SIDE_W - 9, CAT_H)) { cat = k; page = 0; return; }
        }
        int pages = pages();
        if (pages > 1) {
            int[] pg = pager(font(), pages);
            if (in(x, y, pg[0], PAGER_Y, PG_BTN, PAGER_H) && page > 0) { page--; return; }
            if (in(x, y, pg[2], PAGER_Y, PG_BTN, PAGER_H) && page < pages - 1) { page++; return; }
        }
        List<Market.Item> items = list(cat);
        for (int i = 0; i < PAGE; i++) {
            int idx = page * PAGE + i;
            if (idx >= items.size()) break;
            int cx = GRID_X + (i % 2) * COL_PITCH, cy = GRID_Y + (i / 2) * ROW_PITCH;
            if (!in(x, y, cx, cy, CARD_W, CARD_H)) continue;
            Market.Item it = items.get(idx);
            cart.merge(it.id(), 1, (a, b) -> Math.min(Math.min(9, it.maxQty()), a + b));
            Progress.toast("cutemod.market.added", name(it.id()));
            return;
        }
    }

    private void clickCart(int x, int y) {
        if (in(x, y, M, 129, 10, 10) || (y >= 129 && y < 140 && x >= 16 && x < 150)) { express = !express; return; }
        int total = Market.total(cart, express);
        if (in(x, y, ORDER_X, ORDER_Y, ORDER_W, ORDER_H)) {
            if (!cart.isEmpty() && Progress.coins() >= total && Market.checkout(cart, express, shell.pos())) {
                cart.clear();
                Progress.toast("cutemod.market.ordered");
                setTab(2);
            }
            return;
        }
        List<Map.Entry<String, Integer>> rows = new ArrayList<>(cart.entrySet());
        for (int i = 0; i < rows.size(); i++) {
            int ry = HEAD + 4 + i * 17 - scroll;
            if (ry > BAR_Y - 1 || ry < HEAD - 14) continue;
            String id = rows.get(i).getKey();
            int q = rows.get(i).getValue();
            if (in(x, y, MINUS_X, ry + 2, 12, 12)) {
                if (q <= 1) cart.remove(id); else cart.put(id, q - 1);
                return;
            }
            if (in(x, y, PLUS_X, ry + 2, 12, 12) && q < Math.min(9, Market.item(id).maxQty())) { cart.put(id, q + 1); return; }
        }
    }

    private void clickOrders(int x, int y) {
        List<Market.Order> list = Market.orders();
        for (int i = 0; i < list.size(); i++) {
            int ry = HEAD + 3 + i * 24 - scroll;
            if (Market.arrived(list.get(i)) && in(x, y, W - 76, ry + 3, 68, 17)) {
                Market.collect(shell.pos());
                Progress.toast("cutemod.market.collected");
                return;
            }
        }
    }

    @Override
    public boolean scroll(double amount) {
        if (tab == 0) {
            page = Math.max(0, Math.min(pages() - 1, page - (int) Math.signum(amount)));
            return true;
        }
        if (tab == HOME) return true;
        int rows = tab == 1 ? cart.size() * 17 - (BAR_Y - 4 - HEAD - 4) : Market.orders().size() * 24 - (H - HEAD - 3);
        scroll = Math.max(0, Math.min(Math.max(0, rows), scroll - (int) Math.signum(amount) * 14));
        return true;
    }
}
