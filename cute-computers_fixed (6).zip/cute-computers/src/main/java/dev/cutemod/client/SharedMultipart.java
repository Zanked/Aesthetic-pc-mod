package dev.cutemod.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import dev.cutemod.block.CaseLook;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.BlockModelRotation;
import net.minecraft.client.resources.model.Material;
import net.minecraft.client.resources.model.ModelBaker;
import net.minecraft.client.resources.model.ModelState;
import net.minecraft.client.resources.model.MultiPartBakedModel;
import net.minecraft.client.resources.model.UnbakedModel;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.neoforged.neoforge.client.ChunkRenderTypeSet;
import net.neoforged.neoforge.client.model.data.ModelData;
import net.neoforged.neoforge.client.model.geometry.IGeometryBakingContext;
import net.neoforged.neoforge.client.model.geometry.IGeometryLoader;
import net.neoforged.neoforge.client.model.geometry.IUnbakedGeometry;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * A multipart model that is baked ONCE for the whole block instead of once per block state, and that can read part of what it
 * shows from the block entity's {@code ModelData} instead of the block state.
 *
 * Why: the PC case and the monitor have a huge number of block states, and with a vanilla {@code "multipart"} blockstate the
 * game bakes a separate MultiPartBakedModel for EVERY state (about 8 GB of heap in total). The selectors only read the state they
 * are asked about, so one model serves all the states: the blockstate file is {@code {"variants": {"": {"model": "..._shared"}}}}
 * and the shared model file holds the list of parts: {@code {"loader": "cutemod:shared_multipart", "parts": [{"when": {...}, "apply": {"model": "...", "y": 90}}, ...]}}.
 * "when" works like the vanilla one (property -> value, "|" for several values, "!" for not, "AND" / "OR" lists). A property name that
 * the block state does not have is looked up in the case's {@link CaseLook} (board, cpu, psu, disk, net, cables, gpu, ram).
 */
public final class SharedMultipart implements IUnbakedGeometry<SharedMultipart> {
    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("cutemod", "shared_multipart");

    public static final IGeometryLoader<SharedMultipart> LOADER = (json, context) -> {
        JsonArray arr = json.getAsJsonArray("parts");
        if (arr == null || arr.isEmpty()) throw new JsonParseException("shared_multipart needs a non-empty \"parts\" list");
        List<Part> parts = new ArrayList<>();
        for (JsonElement e : arr) {
            JsonObject p = e.getAsJsonObject(), apply = p.getAsJsonObject("apply");
            Cond when = p.has("when") ? condition(p.getAsJsonObject("when")) : (s, look) -> true;
            ResourceLocation model = ResourceLocation.parse(apply.get("model").getAsString());
            int x = apply.has("x") ? apply.get("x").getAsInt() : 0, y = apply.has("y") ? apply.get("y").getAsInt() : 0;
            parts.add(new Part(when, model, x, y));
        }
        return new SharedMultipart(parts);
    };

    /** look = the CaseLook of the block entity, or -1 when the model gets none. */
    @FunctionalInterface
    private interface Cond { boolean test(BlockState state, int look); }

    private record Part(Cond when, ResourceLocation model, int x, int y) {}

    private final List<Part> parts;

    private SharedMultipart(List<Part> parts) { this.parts = parts; }

    @Override
    public void resolveParents(Function<ResourceLocation, UnbakedModel> modelGetter, IGeometryBakingContext context) {
        for (Part p : parts) modelGetter.apply(p.model()).resolveParents(modelGetter);
    }

    @Override
    public BakedModel bake(IGeometryBakingContext context, ModelBaker baker, Function<Material, TextureAtlasSprite> spriteGetter,
                           ModelState modelState, ItemOverrides overrides) {
        List<Cond> conds = new ArrayList<>();
        List<BakedModel> models = new ArrayList<>();
        for (Part p : parts) {
            BakedModel m = baker.bake(p.model(), BlockModelRotation.by(p.x(), p.y()));
            if (m != null) { conds.add(p.when()); models.add(m); }
        }
        return new Model(conds.toArray(new Cond[0]), models.toArray(new BakedModel[0]));
    }

    // ---------- the baked model ----------
    private static final class Model extends MultiPartBakedModel {
        private record Key(BlockState state, int look) {}

        private final Cond[] conds;
        private final BakedModel[] models;
        private final ConcurrentHashMap<Key, BakedModel[]> cache = new ConcurrentHashMap<>();

        Model(Cond[] conds, BakedModel[] models) {
            super(always(models));          // the vanilla class only takes its looks (light, particle, transforms) from the first part
            this.conds = conds;
            this.models = models;
        }

        private static List<Pair<Predicate<BlockState>, BakedModel>> always(BakedModel[] models) {
            List<Pair<Predicate<BlockState>, BakedModel>> l = new ArrayList<>();
            for (BakedModel m : models) l.add(Pair.<Predicate<BlockState>, BakedModel>of(s -> true, m));
            return l;
        }

        private BakedModel[] select(BlockState state, ModelData data) {
            Integer v = data == null ? null : data.get(CaseLook.PROPERTY);
            int look = v == null ? -1 : v;
            return cache.computeIfAbsent(new Key(state, look), k -> {
                List<BakedModel> out = new ArrayList<>();
                for (int i = 0; i < conds.length; i++) if (conds[i].test(k.state(), k.look())) out.add(models[i]);
                return out.toArray(new BakedModel[0]);
            });
        }

        @Override
        public List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction side, RandomSource rand) {
            return getQuads(state, side, rand, ModelData.EMPTY, null);
        }

        @Override
        public List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction side, RandomSource rand, ModelData data, @Nullable RenderType renderType) {
            if (state == null) return List.of();
            List<BakedQuad> out = new ArrayList<>();
            long seed = rand.nextLong();
            for (BakedModel m : select(state, data)) {
                rand.setSeed(seed);
                out.addAll(m.getQuads(state, side, rand, data, renderType));
            }
            return out;
        }

        @Override
        public ChunkRenderTypeSet getRenderTypes(BlockState state, RandomSource rand, ModelData data) {
            List<ChunkRenderTypeSet> sets = new ArrayList<>();
            long seed = rand.nextLong();
            for (BakedModel m : select(state, data)) {
                rand.setSeed(seed);
                sets.add(m.getRenderTypes(state, rand, data));
            }
            return ChunkRenderTypeSet.union(sets);
        }
    }

    // ---------- the conditions: the same language as the vanilla multipart "when" ----------
    private static Cond condition(JsonObject w) {
        if (w.size() == 1 && (w.has("OR") || w.has("AND"))) {
            boolean or = w.has("OR");
            List<Cond> subs = new ArrayList<>();
            for (JsonElement e : w.getAsJsonArray(or ? "OR" : "AND")) subs.add(condition(e.getAsJsonObject()));
            return (s, look) -> {
                for (Cond c : subs) if (c.test(s, look) == or) return or;
                return !or;
            };
        }
        List<Cond> all = new ArrayList<>();
        for (var e : w.entrySet()) {
            String name = e.getKey(), raw = e.getValue().getAsString();
            boolean not = raw.startsWith("!");
            Set<String> values = Set.of((not ? raw.substring(1) : raw).split("\\|"));
            all.add((s, look) -> {
                String cur = null;
                for (Property<?> prop : s.getProperties()) {
                    if (prop.getName().equals(name)) { cur = valueName(s, prop); break; }
                }
                if (cur == null && look >= 0) cur = CaseLook.value(name, look);     // not a block state property: it comes from the block entity
                return cur != null && values.contains(cur) != not;
            });
        }
        return (s, look) -> {
            for (Cond c : all) if (!c.test(s, look)) return false;
            return true;
        };
    }

    private static <T extends Comparable<T>> String valueName(BlockState s, Property<T> prop) { return prop.getName(s.getValue(prop)); }
}
