package dev.cutemod.client.os;

import dev.cutemod.data.Build;
import dev.cutemod.data.PcHardware;

import java.util.Locale;

/**
 * The hardware of the computer the player is sitting at. Every computer block has its own build (see {@link Build}); when a
 * computer is opened, ClientHooks tells this class which build it is ({@link #use}); a laptop in the hand keeps its build in the item. The Explorer ("This PC"), the terminal ("sysinfo"), the games and the shop all read the numbers from here.
 */
public final class PcSpecs {
    private PcSpecs() {}

    /** diskD = 0 when the PC has no second drive; usedDPct = how full that drive is; baseGb = what the system takes of C:.
     *  gpuTier / ramIdx / diskIdx / cpuTier are the levels of the parts (see PcHardware and Build). watts = the load of the build,
     *  supply = what its power supply gives; powerShort = the supply is too weak (the PC restarts and crashes). */
    public record Spec(String pcName, String cpu, int cores, double ghz, int ramGb, String gpu, int vramGb,
                       int diskC, int diskD, int usedDPct, int baseGb, double score, int gpuTier, int ramIdx, int diskIdx, int modemIdx,
                       int cpuTier, int watts, int supply, boolean powerShort) {}

    private static Build current = Build.stock();
    private static String name = "CUTE-PC-0000";
    private static Spec cached;
    private static int hwStamp;

    /** Changes whenever the hardware may have changed (a new world, another computer, a part): the things that depend on it look again. */
    public static int version() { return Store.gen() * 31 + hwStamp; }

    /** The player sat down at a computer with this build (the saved text of a block, or null for the stock PC); pos is its place, for the name. */
    public static void use(String buildText, long placeSeed) {
        current = Build.parse(buildText);
        name = "CUTE-PC-" + String.format(Locale.ROOT, "%04X", (int) ((placeSeed ^ (placeSeed >>> 32)) & 0xFFFF));
        hwStamp++;
        cached = null;
    }

    /** The build of the computer in use. */
    public static Build build() { return current; }

    /** The specs of the computer in use. */
    public static Spec get() {
        if (cached == null) cached = make(current);
        return cached;
    }

    private static Spec make(Build b) {
        int ramIdx = b.ramIdx();
        int gpuTier = b.gpu;
        int cIdx = b.disk;
        int diskC = PcHardware.DISK_GB[cIdx];
        int baseGb = (int) Math.min(8, diskC * 0.4);
        double raw = b.cpu / 4.0 * 3.0 + ramIdx / 5.0 * 3.0 + gpuTier / 4.0 * 3.0 + (cIdx >= 2 ? 0.3 : 0.0);
        double score = Math.max(1.0, Math.min(9.9, Math.round((1.0 + raw) * 10.0) / 10.0));
        return new Spec(name, Build.CPU_NAMES[b.cpu], Build.CPU_CORES[b.cpu], Build.CPU_GHZ[b.cpu], b.ramGb(), PcHardware.GPU_NAMES[gpuTier],
                PcHardware.VRAM_GB[gpuTier], diskC, 0, 0, baseGb, score, gpuTier, ramIdx, cIdx, b.modem, b.cpu, b.load(), b.supply(), b.powerShort());
    }

    /** "96 GB". */
    public static String gb(int gb) { return gb >= 1000 ? (gb / 1000) + " TB" : gb + " GB"; }

    public static String score(Spec s) { return String.format(Locale.ROOT, "%.1f", s.score()); }
}
