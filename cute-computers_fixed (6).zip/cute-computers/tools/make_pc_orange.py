#!/usr/bin/env python3
"""
The "orange" look of the yellow PC items: a compact console-style case and a peach / orange keyboard.

  python3 tools/make_pc_orange.py        (run from the repo root, AFTER make_pc_colors.py and make_pc_peripherals.py: it paints over their yellow files)

  textures/block/pc_case_mini_atlas_yellow.png   the mini case: a white body, an orange frame round the glass, and on its right side a little
                                                 console face (a screen with a paw, a D-pad, two round buttons, ports) and vents
  textures/block/pc_keyboard_yellow.png          a white-orange keyboard with peach keys and orange modifier keys

Everything is original pixel art (a paw print, a plus, two dots): nothing here copies a brand or a character.
"""
import os, sys, json, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image, ImageDraw
import make_pc_peripherals as P

RES = "src/main/resources/assets/cutemod"
TEX = f"{RES}/textures/block"
MOD = f"{RES}/models/block"
S = 4

WHITE = (252, 248, 242, 255)
WHITE_D = (226, 216, 206, 255)
OUTLINE = (196, 168, 146, 255)
OR = (255, 156, 48, 255)
OR_D = (214, 100, 22, 255)
OR_L = (255, 196, 112, 255)
CREAM = (255, 238, 204, 255)
INK = (120, 62, 38, 255)


def mix(a, b, t): return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(4))


def face_rects(name, faces=None):
    """The pixels of the faces of one element of the mini body model: {face: (x0, y0, x1, y1)}."""
    d = json.load(open(f"{MOD}/pc_case_mini_body.json"))
    for e in d["elements"]:
        if e["name"] == name:
            return {f: (round(v["uv"][0] * 1024 / 16), round(v["uv"][1] * 752 / 16), round(v["uv"][2] * 1024 / 16), round(v["uv"][3] * 752 / 16))
                    for f, v in e["faces"].items() if faces is None or f in faces}
    raise KeyError(name)


def canvas(w, h, c=(0, 0, 0, 0)): return Image.new("RGBA", (w * S, h * S), c)


def rrect(im, box, r, fill, outline=None, width=1):
    d = ImageDraw.Draw(im)
    x0, y0, x1, y1 = box
    d.rounded_rectangle([x0 * S, y0 * S, x1 * S - 1, y1 * S - 1], radius=r * S, fill=fill, outline=outline, width=round(width * S) if outline else 0)


def circle(im, cx, cy, r, fill, outline=None):
    d = ImageDraw.Draw(im)
    d.ellipse([(cx - r) * S, (cy - r) * S, (cx + r) * S - 1, (cy + r) * S - 1], fill=fill, outline=outline, width=S if outline else 0)


def gradient(im, box, c0, c1):
    d = ImageDraw.Draw(im)
    x0, y0, x1, y1 = [round(v * S) for v in box]
    for y in range(y0, y1):
        t = (y - y0) / max(1, y1 - y0 - 1)
        d.line([(x0, y), (x1, y)], fill=mix(c0, c1, t))


def paw(im, cx, cy, s, col):
    circle(im, cx, cy + 2.2 * s, 2.5 * s, col)
    for dx, dy, r in ((-4.2, -0.4, 1.2), (-1.5, -3.6, 1.3), (1.5, -3.6, 1.3), (4.2, -0.4, 1.2)):
        circle(im, cx + dx * s, cy + dy * s + 1.2 * s, r * s, col)


def finish(im, w, h): return im.resize((w, h), Image.BOX)


# ------------------------------------------------------------------ the case
def console_side(w=67, h=144):
    """The right side of the compact case: a little game console, the screen and buttons on a white body."""
    im = canvas(w, h, WHITE)
    rrect(im, (0.5, 0.5, w - 0.5, h - 0.5), 4, WHITE, WHITE_D, 1)
    gradient(im, (2, 2, w - 2, h - 2), (255, 252, 247, 255), (244, 234, 222, 255))
    for i in range(14):                                                    # the vent slits at the glass edge
        rrect(im, (4, 12 + i * 5.2, 9.5, 14.2 + i * 5.2), 1, (214, 120, 70, 255))
    rrect(im, (13, 9, 62, 52), 5, OR, OR_D, 1)                             # the orange screen frame
    for i in range(4): rrect(im, (15 + i * 3.4, 11.2, 17.2 + i * 3.4, 12.2), 0.5, OR_L)
    rrect(im, (17, 15, 58, 47), 3, CREAM, INK, 1)                          # the screen
    gradient(im, (18, 16, 57, 46), (255, 244, 214, 255), (255, 222, 168, 255))
    paw(im, 37.5, 28.5, 2.6, OR_D)
    circle(im, 22, 20, 1.1, OR_L); circle(im, 53, 42, 1.1, OR_L)
    circle(im, 15, 54.5, 1.1, (120, 230, 150, 255), OR_D)                  # the little light
    # the D-pad
    cx, cy = 22, 90
    rrect(im, (cx - 12, cy - 4, cx + 12, cy + 4), 2, OR_D); rrect(im, (cx - 4, cy - 12, cx + 4, cy + 12), 2, OR_D)
    rrect(im, (cx - 11, cy - 3, cx + 11, cy + 3), 2, OR); rrect(im, (cx - 3, cy - 11, cx + 3, cy + 11), 2, OR)
    rrect(im, (cx - 10, cy - 2.6, cx + 10, cy - 1.2), 0.5, OR_L); rrect(im, (cx - 2.6, cy - 10, cx - 1.2, cy + 10), 0.5, OR_L)
    circle(im, cx, cy, 2.2, OR_D)
    # the two round buttons
    for bx, by in ((50, 84), (41, 95)):
        circle(im, bx, by + 0.8, 6, (205, 120, 60, 255))
        circle(im, bx, by, 6, OR, OR_D)
        circle(im, bx - 1.6, by - 2, 1.8, (255, 228, 170, 255))
    for k in range(2): rrect(im, (24 + k * 10, 113, 31 + k * 10, 114.6), 0.8, (214, 120, 70, 255))
    # the ports at the bottom
    circle(im, 14, 128, 2, (60, 44, 44, 255), OR_D)
    for px in (26, 40): rrect(im, (px, 126, px + 8, 130), 1, (60, 44, 44, 255), OR, 0.8)
    return finish(im, w, h)


def plain_side(w=67, h=144):
    """The left side: white, with rows of vents and an orange stripe."""
    im = canvas(w, h, WHITE)
    rrect(im, (0.5, 0.5, w - 0.5, h - 0.5), 4, WHITE, WHITE_D, 1)
    gradient(im, (2, 2, w - 2, h - 2), (255, 252, 247, 255), (244, 234, 222, 255))
    for r in range(8):
        for c in range(3): rrect(im, (12 + c * 16, 14 + r * 6.5, 24 + c * 16, 16.4 + r * 6.5), 1, (214, 120, 70, 255))
    rrect(im, (0, h - 24, w, h - 18), 0, OR)
    for k in range(5): paw(im, 8 + k * 13, h - 10, 0.8, OR_L)
    return finish(im, w, h)


def top_panel(w=98, h=67):
    im = canvas(w, h, WHITE)
    rrect(im, (0.5, 0.5, w - 0.5, h - 0.5), 4, WHITE, WHITE_D, 1)
    gradient(im, (2, 2, w - 2, h - 2), (255, 252, 247, 255), (246, 236, 224, 255))
    rrect(im, (6, h - 12, w - 6, h - 8), 1.5, OR)
    for k in range(6): paw(im, 10 + k * 15.5, 22, 1.0, (255, 214, 160, 255))
    return finish(im, w, h)


def back_panel(w=108, h=144):
    im = canvas(w, h, WHITE)
    rrect(im, (0.5, 0.5, w - 0.5, h - 0.5), 4, WHITE, WHITE_D, 1)
    gradient(im, (2, 2, w - 2, h - 2), (255, 252, 247, 255), (244, 234, 222, 255))
    for r in range(10):
        for c in range(5): rrect(im, (10 + c * 18, 14 + r * 12, 22 + c * 18, 17 + r * 12), 1, (232, 196, 170, 255))
    return finish(im, w, h)


def frame_panel(w, h):
    """The orange frame of the glass: a warm orange with a lighter line on top and a few lighter paws and stripes."""
    im = canvas(w, h, OR)
    gradient(im, (0, 0, w, h), OR_L if h > 3 else OR, OR)
    if h > 3 and w > 3:
        rrect(im, (0, h - 1, w, h), 0, OR_D)
        for k in range(0, w, 11): rrect(im, (k, 1, k + 4, max(2, h - 1)), 0, mix(OR, OR_L, 0.55))
    return finish(im, w, h)


def paint_case():
    base = Image.open(f"{TEX}/pc_case_mini_atlas.png").convert("RGBA")           # the white case: the body and the parts inside
    def put(box, img): base.paste(img, box[:2])
    rect = face_rects("right")["east"]; put(rect, console_side(rect[2] - rect[0], rect[3] - rect[1]))
    rect = face_rects("left")["west"]; put(rect, plain_side(rect[2] - rect[0], rect[3] - rect[1]))
    rect = face_rects("top")["up"]; put(rect, top_panel(rect[2] - rect[0], rect[3] - rect[1]))
    rect = face_rects("back")["north"]; put(rect, back_panel(rect[2] - rect[0], rect[3] - rect[1]))
    for name in ("topfront", "lip", "post_l", "post_r"):                         # the frame round the glass
        for f, rect in face_rects(name).items(): put(rect, frame_panel(rect[2] - rect[0], rect[3] - rect[1]))
    for i in range(4):                                                              # the feet
        for f, rect in face_rects("foot%d" % i).items(): put(rect, frame_panel(rect[2] - rect[0], rect[3] - rect[1]))
    base.save(f"{TEX}/pc_case_mini_atlas_yellow.png")


# ------------------------------------------------------------------ the keyboard
def kb_top():
    W, H = 156, 60
    frame, frame2, plate = (255, 170, 84, 255), (255, 214, 164, 255), (255, 240, 222, 255)
    peach, peach2, cream, mod, space = (255, 208, 168, 255), (255, 226, 196, 255), (255, 240, 222, 255), (255, 150, 66, 255), (255, 238, 214, 255)
    im = P.canvas(W, H, frame)
    P.rr(im, (0.4, 0.4, W - 0.4, H - 0.4), 2.6, frame2, outline=P.mix(frame, (0, 0, 0, 255), 0.30), width=0.8)
    P.rr(im, (2.2, 2.2, W - 2.2, H - 2.2), 1.8, plate)
    for (x0, y0, x1, y1, kind) in P.kb_layout("yellow"):
        col = int((x0 + y0 / 6) / 10.5) % 3
        base = mod if kind == "mod" else space if kind == "space" else (peach, peach2, mix(peach, mod, 0.25))[col]
        lo = P.mix(base, (60, 20, 0, 255), 0.22)
        P.rr(im, (x0, y0 + 0.7, x1, y1 + 0.2), 1.3, lo)
        P.rr(im, (x0, y0, x1, y1 - 0.5), 1.3, base)
        P.line_h(im, x0 + 1.0, x1 - 1.0, y0 + 0.25, 0.45, P.mix(base, (255, 255, 255, 255), 0.55))
        cx, mid = (x0 + x1) / 2, (y0 + y1) / 2 - 0.3
        leg = (214, 96, 40, 255)
        if kind == "key": P.over(im, (cx - 1.4, mid - 0.7, cx + 1.4, mid + 0.7), 0.6, leg[:3] + (200,))
        elif kind == "mod": P.over(im, (cx - 1.0, mid - 0.5, cx + 1.0, mid + 0.5), 0.5, (255, 255, 255, 190))
        elif kind == "space": P.over(im, (cx - 12, mid - 0.5, cx + 12, mid + 0.5), 0.5, leg[:3] + (170,))
    return P.down(im, W, H)


def kb_front():
    W, H = 156, 11
    im = Image.new("RGBA", (W, H))
    d = ImageDraw.Draw(im)
    for y in range(H):
        d.line([(0, y), (W, y)], fill=mix((255, 214, 164, 255), (240, 136, 56, 255), y / (H - 1)))
    d.line([(0, 0), (W, 0)], fill=(255, 238, 214, 255))
    return im


def paint_keyboard():
    path = f"{TEX}/pc_keyboard_yellow.png"
    im = Image.open(path).convert("RGBA")
    im.paste(kb_top(), P.KB_TOP[:2])
    im.paste(kb_front(), P.KB_FRONT[:2])
    im.save(path)


if __name__ == "__main__":
    paint_case()
    paint_keyboard()
    print("orange case + keyboard painted")
