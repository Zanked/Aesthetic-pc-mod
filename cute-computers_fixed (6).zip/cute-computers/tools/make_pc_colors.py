#!/usr/bin/env python3
"""
Colour variants of the PC case (mid + mini) and of the monitor, and the plain-colour textures of the keyboard / mouse (they have their OWN look, see make_pc_peripherals.py).

  python3 tools/make_pc_colors.py            (run from the repo root, AFTER make_pc_case.py and make_pc_case_sizes.py)

It only post-processes what the other tools wrote, and it can be run again and again:

  textures/block/pc_case_atlas_<color>.png     the white body panels of the case atlas, painted (the parts inside stay as they are)
  textures/block/pc_monitor_{on,off}_<color>.png, pc_keyboard_<color>.png, pc_mouse_<color>.png
  models/block/pc_monitor_{on,off}.json        the monitor ALONE (the keyboard and the mouse boxes are cut out of it)
  models/block/pc_monitor_keyboard[_<c>].json, pc_monitor_mouse[_<c>].json   the two parts that are drawn when they are connected
  models/block/pc_monitor_<c>_{on,off}.json, pc_case_{mid,mini}_{body,item}_<c>.json   children of the white models with another texture
  blockstates/pc_monitor.json, pc_case_{mid,mini}.json   (multipart; the property "color" picks the body; the keyboard / mouse parts of the
                                                         monitor are added by tools/make_pc_peripherals.py, which must be run AFTER this script)
  models/item/pc_monitor_<c>.json, pc_case_{mid,mini}_<c>.json
  data/cutemod/loot_table/blocks/pc_monitor.json, pc_case_{mid,mini}.json   (the drop has the colour of the block)
  lang: item names of the coloured items (en_us / ru_ru), added once

The colours must be the same as in dev.cutemod.block.PcColor.
"""
import os, json, colorsys, copy
from PIL import Image

RES = "src/main/resources/assets/cutemod"
DATA = "src/main/resources/data/cutemod"
TEX = f"{RES}/textures/block"
MOD = f"{RES}/models/block"
ITM = f"{RES}/models/item"

# name -> (hue in degrees, saturation of the lightest panels, value multiplier)  ("black" is handled separately)
COLORS = {
    "pink":   (336, 0.22, 0.99),
    "blue":   (208, 0.26, 0.98),
    "mint":   (152, 0.24, 0.98),
    "purple": (268, 0.30, 0.96),
    "yellow": (46,  0.30, 1.00),
    "red":    (356, 0.36, 0.96),
    "black":  (262, 0.13, 1.00),
}
RU = {"white": "белый", "pink": "розовый", "blue": "голубой", "mint": "мятный", "purple": "фиолетовый",
      "yellow": "жёлтый", "red": "красный", "black": "чёрный"}
EN = {"white": "White", "pink": "Pink", "blue": "Blue", "mint": "Mint", "purple": "Purple",
      "yellow": "Yellow", "red": "Red", "black": "Black"}
FACINGS = (("south", 0), ("west", 90), ("north", 180), ("east", 270))

# parts of the case atlas that are the body (see the uv of pc_case_<size>_body): back, right, top, topfront, lip, io, shroud, shroud top, tray
BODY_RECTS = [(1, 9, 169, 189), (171, 9, 326, 189), (328, 9, 491, 164), (493, 9, 656, 14), (658, 9, 773, 21),
              (775, 9, 823, 26), (825, 9, 983, 14), (1, 191, 159, 341), (161, 191, 319, 318)]
# the monitor: the screen itself (the picture of the desktop) must not be painted
SCREEN_RECT = (3, 11, 178, 115)


def paint_pixel(px, color):
    """White / lilac plastic (light and not very saturated) gets the colour; dark outlines, text and pictures are left alone."""
    r, g, b, a = px
    if a == 0:
        return px
    h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
    if v < 0.55 or s > 0.36:
        return px
    hue, sat, vm = COLORS[color]
    t = (v - 0.55) / 0.45                                   # 0 = the darkest plastic, 1 = the brightest
    if color == "black":
        nv = 0.12 + 0.32 * t * vm
        ns = sat * (1.0 - 0.4 * t)
    else:
        k = 0.55 + 0.45 * min(1.0, (1 - v) / 0.35)          # the shadows are a bit more saturated, like real plastic
        ns = min(1.0, sat * k)
        nv = min(1.0, v * vm)
    nr, ng, nb = colorsys.hsv_to_rgb(hue / 360, ns, nv)
    return (round(nr * 255), round(ng * 255), round(nb * 255), a)


def paint(src, dst, color, rects=None, skip=None):
    im = Image.open(f"{TEX}/{src}.png").convert("RGBA")
    out = im.copy()
    px, po = im.load(), out.load()
    W, H = im.size
    def inside(x, y, rs):
        return any(x0 - 1 <= x <= x1 + 1 and y0 - 1 <= y <= y1 + 1 for x0, y0, x1, y1 in rs)
    for y in range(H):
        for x in range(W):
            if rects is not None and not inside(x, y, rects):
                continue
            if skip is not None and skip[0] <= x <= skip[2] and skip[1] <= y <= skip[3]:
                continue
            po[x, y] = paint_pixel(px[x, y], color)
    out.save(f"{TEX}/{dst}.png")


def jload(path): return json.load(open(path))
def jsave(path, d): json.dump(d, open(path, "w"), indent=1)


def child(parent, textures, extra=None):
    d = {"parent": parent, "textures": textures}
    if extra: d.update(extra)
    return d


def main():
    # ------------------------------------------------------------------ textures
    for c in COLORS:
        paint("pc_case_atlas", f"pc_case_atlas_{c}", c, rects=BODY_RECTS)
        paint("pc_monitor_on", f"pc_monitor_on_{c}", c, skip=SCREEN_RECT)
        paint("pc_monitor_off", f"pc_monitor_off_{c}", c, skip=SCREEN_RECT)
        paint("pc_keyboard", f"pc_keyboard_{c}", c)
        paint("pc_mouse", f"pc_mouse_{c}", c)

    # ------------------------------------------------------------------ the monitor alone + the two parts
    kb_els, ms_els = None, None
    for st in ("on", "off"):
        path = f"{MOD}/pc_monitor_{st}.json"
        m = jload(path)
        k = [e for e in m["elements"] if e["name"].startswith("k_")]
        ms = [e for e in m["elements"] if e["name"].startswith("m_")]
        if k: kb_els = k
        if ms: ms_els = ms
        m["elements"] = [e for e in m["elements"] if not e["name"].startswith(("k_", "m_"))]
        m["textures"] = {kk: v for kk, v in m["textures"].items() if kk not in ("k", "m")}
        jsave(path, m)
    # (when the script runs a second time the elements are already gone: the parts are kept from the files)
    def part(name, els, key, tex):
        path = f"{MOD}/{name}.json"
        if els is None:
            return
        jsave(path, {"credit": "generated by tools/make_pc_colors.py", "ambientocclusion": False, "texture_size": [1024, 1024],
                     "textures": {"particle": f"cutemod:block/{tex}", key: f"cutemod:block/{tex}"}, "elements": els,
                     "render_type": "minecraft:cutout"})
    part("pc_monitor_keyboard", kb_els, "k", "pc_keyboard")
    part("pc_monitor_mouse", ms_els, "m", "pc_mouse")
    for c in COLORS:
        for st in ("on", "off"):
            jsave(f"{MOD}/pc_monitor_{c}_{st}.json", child(f"cutemod:block/pc_monitor_{st}", {
                "particle": f"cutemod:block/pc_monitor_{st}_{c}", "t": f"cutemod:block/pc_monitor_{st}_{c}"}))
        jsave(f"{MOD}/pc_monitor_keyboard_{c}.json", child("cutemod:block/pc_monitor_keyboard", {
            "particle": f"cutemod:block/pc_keyboard_{c}", "k": f"cutemod:block/pc_keyboard_{c}"}))
        jsave(f"{MOD}/pc_monitor_mouse_{c}.json", child("cutemod:block/pc_monitor_mouse", {
            "particle": f"cutemod:block/pc_mouse_{c}", "m": f"cutemod:block/pc_mouse_{c}"}))

    # ------------------------------------------------------------------ the monitor blockstate (multipart)
    mp = []
    for color in ["white"] + list(COLORS):
        sfx = "" if color == "white" else f"_{color}"
        for facing, y in FACINGS:
            for st, flag in (("on", "true"), ("off", "false")):
                mp.append({"when": {"facing": facing, "color": color, "on": flag},
                           "apply": {"model": f"cutemod:block/pc_monitor{sfx}_{st}" if sfx else f"cutemod:block/pc_monitor_{st}", "y": y}})
            # (the keyboard and the mouse parts are NOT added here: they follow their own block states kb_style / ms_style,
            #  not the colour of the monitor: tools/make_pc_peripherals.py adds them, run it after this script)
    jsave(f"{RES}/blockstates/pc_monitor.json", {"multipart": mp})

    # ------------------------------------------------------------------ the cases
    for size in ("mid", "mini"):
        for c in COLORS:
            tex = f"cutemod:block/pc_case_atlas_{c}"
            for kind in ("body", "item"):
                jsave(f"{MOD}/pc_case_{size}_{kind}_{c}.json", child(f"cutemod:block/pc_case_{size}_{kind}", {"particle": tex, "t": tex}))
        bs_path = f"{RES}/blockstates/pc_case_{size}.json"
        bs = jload(bs_path)
        body = f"cutemod:block/pc_case_{size}_body"
        rest = [p for p in bs["multipart"] if not p["apply"]["model"].startswith(body)]
        bodies = []
        for color in ["white"] + list(COLORS):
            sfx = "" if color == "white" else f"_{color}"
            for facing, y in FACINGS:
                bodies.append({"when": {"facing": facing, "color": color}, "apply": {"model": body + sfx, "y": y}})
        bs["multipart"] = bodies + rest
        jsave(bs_path, bs)

    # ------------------------------------------------------------------ item models (the display part is copied from the white item)
    for white, parent_of in (("pc_monitor", lambda c: f"cutemod:block/pc_monitor_{c}_on"),
                             ("pc_case_mid", lambda c: f"cutemod:block/pc_case_mid_item_{c}"),
                             ("pc_case_mini", lambda c: f"cutemod:block/pc_case_mini_item_{c}")):
        base = jload(f"{ITM}/{white}.json")
        for c in COLORS:
            d = copy.deepcopy(base)
            d["parent"] = parent_of(c)
            jsave(f"{ITM}/{white}_{c}.json", d)

    # ------------------------------------------------------------------ loot tables: the drop has the colour of the block
    for name in ("pc_monitor", "pc_case_mid", "pc_case_mini"):
        children = []
        for c in COLORS:
            children.append({"type": "minecraft:item", "name": f"cutemod:{name}_{c}",
                             "conditions": [{"condition": "minecraft:block_state_property", "block": f"cutemod:{name}",
                                             "properties": {"color": c}}]})
        children.append({"type": "minecraft:item", "name": f"cutemod:{name}"})
        loot = {"type": "minecraft:block",
                "pools": [{"rolls": 1.0, "bonus_rolls": 0.0,
                           "entries": [{"type": "minecraft:alternatives", "children": children}],
                           "conditions": [{"condition": "minecraft:survives_explosion"}]}],
                "random_sequence": f"cutemod:blocks/{name}"}
        jsave(f"{DATA}/loot_table/blocks/{name}.json", loot)

    # ------------------------------------------------------------------ lang (added once: the lines go before the last one)
    add_lang("en_us", lambda c, thing: f"{EN[c]} {thing}", {"pc_monitor": "Monitor", "pc_case_mid": "PC Case", "pc_case_mini": "PC Case (Compact Slim)"},
             {"cutemod.monitor.hint": "Right-click a monitor with this to connect it",
              "cutemod.monitor.bare": "Right-click the monitor with a keyboard or a mouse to connect them",
              "cutemod.monitor.has_keyboard": "The monitor already has a keyboard",
              "cutemod.monitor.has_mouse": "The monitor already has a mouse",
              "cutemod.monitor.attached": "Connected: %s",
              "cutemod.monitor.detached": "Disconnected: %s",
              "item.cutemod.pc_keyboard": "Keyboard", "item.cutemod.pc_mouse": "Mouse"})
    add_lang("ru_ru", lambda c, thing: f"{RU[c].capitalize()} {thing[0].lower() + thing[1:]}",
             {"pc_monitor": "Монитор", "pc_case_mid": "Корпус ПК", "pc_case_mini": "Корпус ПК (компактный, тонкий)"},
             {"cutemod.monitor.hint": "Нажми этим ПКМ по монитору, чтобы подключить",
              "cutemod.monitor.bare": "Нажми ПКМ по монитору клавиатурой или мышью, чтобы подключить их",
              "cutemod.monitor.has_keyboard": "К монитору уже подключена клавиатура",
              "cutemod.monitor.has_mouse": "К монитору уже подключена мышь",
              "cutemod.monitor.attached": "Подключено: %s",
              "cutemod.monitor.detached": "Отключено: %s",
              "item.cutemod.pc_keyboard": "Клавиатура", "item.cutemod.pc_mouse": "Мышь"})
    print("ok")


def add_lang(code, namer, things, extra):
    path = f"{RES}/lang/{code}.json"
    text = open(path, encoding="utf-8").read()
    data = json.loads(text)
    lines = {}
    for name, thing in things.items():
        for c in COLORS:
            lines[f"item.cutemod.{name}_{c}"] = namer(c, thing)
    lines.update(extra)
    lines = {k: v for k, v in lines.items() if k not in data}
    # the three messages that changed their meaning (the keyboard and the mouse are connected to the monitor now)
    changed = {
        "en_us": {"cutemod.monitor.no_desk": "Connect a keyboard and a mouse to the monitor (right-click it with them)",
                  "cutemod.monitor.no_keyboard": "No keyboard is connected to the monitor (right-click it with a keyboard)",
                  "cutemod.monitor.no_mouse": "No mouse is connected to the monitor (right-click it with a mouse)"},
        "ru_ru": {"cutemod.monitor.no_desk": "Подключи к монитору клавиатуру и мышь (ПКМ по монитору с ними в руке)",
                  "cutemod.monitor.no_keyboard": "К монитору не подключена клавиатура (ПКМ по монитору с клавиатурой)",
                  "cutemod.monitor.no_mouse": "К монитору не подключена мышь (ПКМ по монитору с мышью)"}}[code]
    for k, v in changed.items():
        old = f'  {json.dumps(k)}: {json.dumps(data[k], ensure_ascii=False)}'
        new = f'  {json.dumps(k)}: {json.dumps(v, ensure_ascii=False)}'
        assert old in text, k
        text = text.replace(old, new)
    if lines:
        body = ",\n".join(f"  {json.dumps(k)}: {json.dumps(v, ensure_ascii=False)}" for k, v in lines.items())
        idx = text.rstrip().rfind("\n}")
        text = text[:idx] + ",\n" + body + text[idx:]
    json.loads(text)                                  # still valid
    open(path, "w", encoding="utf-8").write(text)


if __name__ == "__main__":
    main()
