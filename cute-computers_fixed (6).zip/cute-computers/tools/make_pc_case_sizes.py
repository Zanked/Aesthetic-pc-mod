#!/usr/bin/env python3
"""Makes the smaller PC cases (mid tower, compact cube) from the big glass tower models.

The big glass tower is NOT in the mod any more: its models are kept in tools/pc_case_big/ only as the source for these.
Every model there (body, glass, parts, glow) is copied with its boxes squeezed toward the middle of the block floor,
so the parts keep their places inside the case. The blockstate and the item model are copied the same way.
Run from the repo root:  python3 tools/make_pc_case_sizes.py
"""
import json, glob, os, re

RES = "src/main/resources/assets/cutemod"
# name -> (scale x, scale y, scale z)
# mid = a normal mid tower; mini = a slim compact case: narrow and shallow (the glass front stays the big face), like an ITX case
SIZES = {"mid": (0.74, 0.80, 0.82), "mini": (0.60, 0.74, 0.46)}
SRC = "tools/pc_case_big"

def squeeze(el, s):
    sx, sy, sz = s
    f, t = el["from"], el["to"]
    el["from"] = [round(8 + (f[0] - 8) * sx, 4), round(f[1] * sy, 4), round(8 + (f[2] - 8) * sz, 4)]
    el["to"] = [round(8 + (t[0] - 8) * sx, 4), round(t[1] * sy, 4), round(8 + (t[2] - 8) * sz, 4)]
    if "rotation" in el and "origin" in el["rotation"]:
        o = el["rotation"]["origin"]
        el["rotation"]["origin"] = [round(8 + (o[0] - 8) * sx, 4), round(o[1] * sy, 4), round(8 + (o[2] - 8) * sz, 4)]

for tag, s in SIZES.items():
    for path in sorted(glob.glob(f"{SRC}/models/pc_case_*.json")):
        name = os.path.basename(path)[len("pc_case_"):-5]
        d = json.load(open(path))
        for el in d.get("elements", []):
            squeeze(el, s)
        json.dump(d, open(f"{RES}/models/block/pc_case_{tag}_{name}.json", "w"), indent=1)
    bs = open(f"{SRC}/blockstates/pc_case.json").read().replace("cutemod:block/pc_case_", f"cutemod:block/pc_case_{tag}_")
    open(f"{RES}/blockstates/pc_case_{tag}.json", "w").write(bs)
    it = open(f"{SRC}/item/pc_case.json").read().replace("cutemod:block/pc_case_item", f"cutemod:block/pc_case_{tag}_item")
    open(f"{RES}/models/item/pc_case_{tag}.json", "w").write(it)
print("ok")
