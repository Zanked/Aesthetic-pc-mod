package dev.cutemod.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The cast of the talent show that is not a player: the four judges and the "guest" pets that fill an empty stage.
 * Pure logic (no Minecraft classes). Everything is a function of the round number, so the server and a test
 * always agree and nothing has to be saved.
 */
public final class ShowJudges {
    private ShowJudges() {}

    public static final int COUNT = 4;
    /** The computer color of every judge: its animal is the judge (panda, creeper, enderman, bee). */
    public static final String[] COLOR = {"white", "green", "purple", "yellow"};
    /** What each judge wears in the picture. */
    public static final String[] HAT = {"acc_flower", "acc_party", "acc_witch", "acc_headphones"};

    private static final String[] NAMES = {"Mochi", "Biscuit", "Pixel", "Nori", "Pudding", "Waffle", "Sprout", "Bean",
            "Cookie", "Pumpkin", "Luna", "Momo", "Kiwi", "Taco", "Peach", "Zephyr"};
    private static final String[] HATS = {"", "acc_ushanka", "acc_headphones", "acc_horns", "acc_witch", "acc_glasses", "acc_bow", "acc_hat",
            "acc_crown", "acc_ghost", "acc_party", "acc_halo", "acc_flower", "acc_cap"};
    private static final String[] BODIES = {"", "acc_scarf", "acc_cape"};
    private static final String[] COLORS = {"pink", "green", "white", "blue", "orange", "purple", "yellow", "red"};

    /** A guest pet: it is not a player, it only keeps the stage lively. hearts = the love of the crowd at the end (0-4). */
    public record Bot(String name, String color, int stage, int trait, int ageMin, String head, String body, int hearts) {}

    private static long mix(long x) {
        x += 0x9E3779B97F4A7C15L;
        x = (x ^ (x >>> 30)) * 0xBF58476D1CE4E5B9L;
        x = (x ^ (x >>> 27)) * 0x94D049BB133111EBL;
        return x ^ (x >>> 31);
    }

    /** A number in [-1, 1) that depends only on the inputs. */
    private static double noise(long a, long b, long c) {
        long h = mix(mix(mix(a) ^ b) ^ c);
        return ((h >>> 11) / (double) (1L << 53)) * 2 - 1;
    }

    private static long hash(String s) {
        long h = 1125899906842597L;
        for (int i = 0; i < s.length(); i++) h = 31 * h + s.charAt(i);
        return h;
    }

    private static boolean has(String s, String... ids) {
        for (String i : ids) if (i.equals(s)) return true;
        return false;
    }

    /**
     * How many stars (1-5) a judge gives to a pet. Every judge has a taste: Mei (0) loves cute things, Boom (1) loves
     * style, Void (2) loves mystery and Honey (3) loves effort. A pet in clothes scores better than a naked one.
     * key = who it is (the player's UUID text or the name of a guest).
     */
    public static int stars(int judge, long round, String key, String color, int stage, int trait, int ageMin, String head, String body) {
        boolean hat = !head.isEmpty(), cloth = !body.isEmpty();
        double s = 1.6;
        switch (judge) {
            case 0 -> {
                s += stage == 0 ? 0.9 : stage == 1 ? 0.5 : 0.2;
                if (trait == 3) s += 0.7;
                s += has(head, "acc_bow", "acc_flower", "acc_halo", "acc_crown") ? 1.2 : hat ? 0.5 : 0;
                if (cloth) s += 0.4;
            }
            case 1 -> {
                s += has(head, "acc_witch", "acc_crown", "acc_horns", "acc_cap", "acc_ushanka", "acc_hat") ? 1.3 : hat ? 0.6 : 0;
                s += body.equals("acc_cape") ? 1.2 : cloth ? 0.7 : 0;
                if (trait == 1) s += 0.5;
                if (stage == 2) s += 0.4;
            }
            case 2 -> {
                s += has(head, "acc_ghost", "acc_horns", "acc_witch", "acc_halo") ? 1.3 : hat ? 0.5 : 0;
                s += body.equals("acc_cape") ? 1.0 : cloth ? 0.5 : 0;
                if (trait == 2) s += 0.7;
                s += stage == 2 ? 0.6 : stage == 1 ? 0.3 : 0;
            }
            default -> {
                if (trait == 0 || trait == 1) s += 0.7;
                s += has(head, "acc_headphones", "acc_party", "acc_cap", "acc_glasses") ? 1.2 : hat ? 0.5 : 0;
                s += Math.min(ageMin, 1200) / 1200.0;
                if (stage >= 1) s += 0.3;
                if (cloth) s += 0.4;
            }
        }
        s += 0.7 * noise(round, judge, hash(key + color));
        return Math.max(1, Math.min(5, (int) Math.round(s)));
    }

    /** The guests of a round (always 4; the stage shows as many as it needs, from the front of the list). */
    public static List<Bot> bots(long round) {
        Random r = new Random(mix(round * 31 + 7));
        List<Bot> out = new ArrayList<>();
        List<Integer> names = new ArrayList<>();
        for (int i = 0; i < NAMES.length; i++) names.add(i);
        java.util.Collections.shuffle(names, r);
        for (int i = 0; i < 4; i++) {
            String head = r.nextInt(100) < 55 ? HATS[1 + r.nextInt(HATS.length - 1)] : "";
            String body = r.nextInt(100) < 35 ? BODIES[1 + r.nextInt(BODIES.length - 1)] : "";
            int stage = 1 + r.nextInt(2);
            out.add(new Bot(NAMES[names.get(i)], COLORS[r.nextInt(COLORS.length)], stage, r.nextInt(4),
                    stage == 1 ? 25 + r.nextInt(30) : 70 + r.nextInt(500), head, body, r.nextInt(5)));
        }
        return out;
    }
}
