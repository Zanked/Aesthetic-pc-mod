package dev.cutemod.client.os;

import dev.cutemod.net.PetLook;
import dev.cutemod.net.ShowActionPayload;
import dev.cutemod.net.ShowPutPayload;
import dev.cutemod.net.ShowRequestPayload;
import dev.cutemod.net.ShowSyncPayload;
import net.neoforged.neoforge.network.PacketDistributor;

/** The talent show on the client: sends what the player does and keeps the last stage the server sent. */
public final class Show {
    private Show() {}

    private static ShowSyncPayload last;

    public static void apply(ShowSyncPayload p) { last = p; }

    /** The last stage (null before the first answer). */
    public static ShowSyncPayload last() { return last; }

    public static void clear() { last = null; }

    /** Ask the server for the stage as it is now. */
    public static void request() { PacketDistributor.sendToServer(new ShowRequestPayload()); }

    /** The show has paid us: the coins are ours (0 = the daily limit of the show is used up). */
    public static void prize(int coins, int rank) {
        if (coins > 0) Progress.earn(coins);
    }

    /** Put the pet of this computer color on the stage, as it is right now (or refresh it). False if that pet does not exist yet. */
    public static boolean exhibit(String colorId) {
        PetBlob.Info i = PetBlob.parse(Store.read("pet_" + colorId));
        if (i == null) return false;
        PacketDistributor.sendToServer(new ShowPutPayload(colorId, i.sick(),
                new PetLook(i.stage(), i.trait(), i.ageMin(), short24(Progress.equipped()), short24(Progress.equippedBody()))));
        return true;
    }

    public static void withdraw(String colorId) { PacketDistributor.sendToServer(new ShowActionPayload(ShowActionPayload.WITHDRAW, "", colorId)); }

    public static void like(String owner, String colorId) { PacketDistributor.sendToServer(new ShowActionPayload(ShowActionPayload.LIKE, owner, colorId)); }

    public static void unlike(String owner, String colorId) { PacketDistributor.sendToServer(new ShowActionPayload(ShowActionPayload.UNLIKE, owner, colorId)); }

    private static String short24(String s) { return s == null || s.length() > 24 ? "" : s; }
}
