package dev.cutemod.net;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.cutemod.data.PostData;
import dev.cutemod.data.ShowBoard;
import dev.cutemod.data.ShowData;
import dev.cutemod.data.ShowJudges;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The server side of the talent show (see {@link ShowBoard} for the rules and the rounds): puts pets on the stage,
 * likes, the stage for the clients, the payment of the prizes once a round and the admin command
 * <pre>/cuteshow remove &lt;player&gt;</pre> (permission level 2). What a client sends about its pet cannot be
 * checked (the server does not see inside the pet), so it is only checked against white lists, like the scores of CuteNet.
 */
public final class ShowServer {
    private ShowServer() {}

    private static final long PUT_GAP_MS = 10_000L;      // a pet can be put on the stage / refreshed every 10 seconds
    private static final long ACT_GAP_MS = 400L;         // likes and withdrawing
    private static final long REQ_GAP_MS = 500L;         // asking for the stage
    private static final int[] MILESTONES = {1, 5, 10, 25, 50, 100};

    private static final Map<UUID, Long> lastPut = new HashMap<>();
    private static final Map<UUID, Long> lastAct = new HashMap<>();
    private static final Map<UUID, Long> lastRequest = new HashMap<>();

    /** What the last round paid (so the screen can say "+8 coins"): the round and the coins of every player. */
    private static long paidRound = -1;
    private static final Map<UUID, Integer> granted = new HashMap<>();

    private static int tickCount;

    /** Called every server tick; the work is done once a second. */
    public static void tick(MinecraftServer server) {
        if (++tickCount < 20) return;
        tickCount = 0;
        payDue(server);
    }

    /** Pay a round that has ended (or reached its results) and forget old pets. Safe to call at any time. */
    private static void payDue(MinecraftServer server) {
        ShowData data = ShowData.get(server);
        long now = System.currentTimeMillis();
        long due;
        while ((due = data.board().unpaidRound(now)) >= 0) payRound(server, data, due);
        data.prune();
    }

    private static void payRound(MinecraftServer server, ShowData data, long round) {
        List<ShowBoard.Prize> prizes = data.pay(round);
        granted.clear();
        paidRound = round;
        for (ShowBoard.Prize p : prizes) {
            granted.put(p.owner(), p.coins());
            give(server, p.owner(), p.coins(), p.rank());
            if (p.rank() == 1) {
                server.getPlayerList().broadcastSystemMessage(Component.translatable("cutemod.show.winner", p.name()), false);
            }
        }
    }

    /** Coins to an online player (the computer adds them at once) or to the saved data of an offline one. */
    private static void give(MinecraftServer server, UUID id, int coins, int rank) {
        ServerPlayer online = server.getPlayerList().getPlayer(id);
        if (online != null) {
            PacketDistributor.sendToPlayer(online, new ShowPrizePayload(coins, rank));
        } else if (coins > 0) {
            int now = CoinsCommand.savedCoins(server, id);
            CoinsCommand.saveCoins(server, id, (int) Math.min(CoinsCommand.MAX, (long) now + coins));
        }
    }

    /** A player joined: if they changed their name, their pet gets the new one. */
    public static void joined(ServerPlayer sp) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        ShowData.get(server).rename(sp.getUUID(), sp.getGameProfile().getName());
    }

    public static void leave(UUID id) {
        lastPut.remove(id);
        lastAct.remove(id);
        lastRequest.remove(id);
    }

    /** True if the player is still inside the time gap of this kind of request (and if not, starts a new gap). */
    private static boolean tooFast(Map<UUID, Long> last, UUID id, long gap) {
        long now = System.currentTimeMillis();
        Long l = last.get(id);
        if (l != null && now - l < gap) return true;
        last.put(id, now);
        return false;
    }

    public static void put(ServerPlayer sp, ShowPutPayload p) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        if (tooFast(lastPut, sp.getUUID(), PUT_GAP_MS)) { push(sp, ShowBoard.TOO_FAST); return; }
        payDue(server);                      // a pet of an old round is paid before it is replaced
        PetLook l = p.look();
        int r = ShowData.get(server).put(sp.getUUID(), sp.getGameProfile().getName(), p.color(),
                l.stage(), l.trait(), l.ageMin(), p.sick(), l.head(), l.body());
        push(sp, r);
    }

    public static void action(ServerPlayer sp, ShowActionPayload p) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        if (tooFast(lastAct, sp.getUUID(), ACT_GAP_MS)) { push(sp, ShowBoard.TOO_FAST); return; }
        ShowData data = ShowData.get(server);
        UUID me = sp.getUUID();
        int r;
        if (p.kind() == ShowActionPayload.WITHDRAW) {
            r = data.remove(me);                                        // you can only take your own pet off
        } else if (p.kind() == ShowActionPayload.LIKE || p.kind() == ShowActionPayload.UNLIKE) {
            UUID owner;
            try { owner = UUID.fromString(p.owner()); } catch (IllegalArgumentException e) { push(sp, ShowBoard.BOT); return; }
            if (p.kind() == ShowActionPayload.LIKE) {
                r = data.like(me, owner);
                if (r == ShowBoard.OK) milestone(server, data, owner, sp.getGameProfile().getName());
            } else {
                r = data.unlike(me, owner);
            }
            if (r == ShowBoard.NOOP) r = ShowBoard.OK;       // already liked / nothing to take back: the stage is just refreshed
        } else {
            r = ShowBoard.REFUSED;
        }
        push(sp, r);
    }

    /** The owner gets a quiet notice on the first like and on round numbers (not on every single one). */
    private static void milestone(MinecraftServer server, ShowData data, UUID owner, String fan) {
        ServerPlayer o = server.getPlayerList().getPlayer(owner);
        if (o == null) return;
        int n = 0;
        for (ShowBoard.Standing s : data.board().standings(ShowBoard.roundOf(System.currentTimeMillis()), System.currentTimeMillis())) {
            if (!s.bot && s.owner.equals(owner)) n = s.likes;
        }
        for (int m : MILESTONES) if (m == n) { o.displayClientMessage(Component.translatable("cutemod.show.liked", fan, n), true); return; }
    }

    public static void request(ServerPlayer sp) {
        if (tooFast(lastRequest, sp.getUUID(), REQ_GAP_MS)) return;
        push(sp, -1);
    }

    private static void push(ServerPlayer sp, int result) {
        MinecraftServer server = sp.getServer();
        if (server == null) return;
        payDue(server);
        ShowBoard board = ShowData.get(server).board();
        long now = System.currentTimeMillis();
        long round = ShowBoard.roundOf(now);
        int phase = ShowBoard.phaseOf(now);
        int judges = phase == ShowBoard.OPEN ? 0 : phase == ShowBoard.JUDGING ? ShowBoard.revealed(now) : ShowJudges.COUNT;
        List<ShowBoard.Standing> list = board.standings(round, now);
        if (phase == ShowBoard.RESULTS) ShowBoard.rank(list);
        UUID me = sp.getUUID();
        int myRank = -1;
        List<ShowSyncPayload.Entry> out = new ArrayList<>();
        for (ShowBoard.Standing s : list) {
            List<Integer> stars = new ArrayList<>();
            for (int j = 0; j < ShowJudges.COUNT; j++) stars.add(j < judges ? s.stars[j] : 0);
            boolean results = phase == ShowBoard.RESULTS;
            if (!s.bot && s.owner.equals(me) && results) myRank = s.rank;
            out.add(new ShowSyncPayload.Entry(
                    new ShowSyncPayload.Who(s.bot ? "" : s.owner.toString(), s.name, s.color),
                    new PetLook(s.stage, s.trait, s.ageMin, s.head, s.body),
                    s.likes, !s.bot && board.liked(s.owner, me, now), s.bot,
                    new ShowSyncPayload.Score(stars, results ? s.rank : 0, results ? s.total : 0)));
        }
        int prize = phase == ShowBoard.RESULTS && paidRound == round ? granted.getOrDefault(me, -1) : -1;
        int left = (int) ((ShowBoard.phaseLeftMs(now) + 999) / 1000);
        PacketDistributor.sendToPlayer(sp, new ShowSyncPayload(
                new ShowSyncPayload.Head(result, phase, left, judges),
                new ShowSyncPayload.Mine(board.entered(me, now), myRank, prize), out));
    }

    // ---------- admin command ----------
    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("cuteshow").requires(s -> s.hasPermission(2))
                .then(Commands.literal("remove").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> {
                    CommandSourceStack src = ctx.getSource();
                    MinecraftServer server = src.getServer();
                    String name = StringArgumentType.getString(ctx, "player");
                    UUID id = resolve(server, name);
                    if (id == null) {
                        src.sendFailure(Component.translatable("cutemod.post.cmd.unknown", name));
                        return 0;
                    }
                    if (!ShowData.get(server).removeAll(id)) {
                        src.sendFailure(Component.translatable("cutemod.show.cmd.none", name));
                        return 0;
                    }
                    src.sendSuccess(() -> Component.translatable("cutemod.show.cmd.removed", name, 1), true);
                    return 1;
                }))));
    }

    /** An online player by name, or a player the server has seen before. */
    private static UUID resolve(MinecraftServer server, String name) {
        ServerPlayer online = server.getPlayerList().getPlayerByName(name);
        if (online != null) return online.getUUID();
        return PostData.get(server).findByName(name);
    }
}
