package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import dev.cutemod.data.ShowBoard;
import dev.cutemod.data.ShowJudges;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * Server -> client: the stage of the talent show as it is right now.
 * <ul>
 *   <li>{@link Head}: result answers the last thing you did (-1 nothing, 0 done, 1 too fast, 2 refused, 3 your pet is
 *       sick, 4 your own pet, 5 not there, 7 the doors are closed, 8 the stage is full, 9 a guest cannot be liked);
 *       phase 0 open / 1 judging / 2 results; leftSec = seconds until the phase ends; judges = how many judges have
 *       shown their stars.</li>
 *   <li>{@link Mine}: entered = your pet is on this stage; rank and prize (coins) are set in the results phase, -1 before.</li>
 *   <li>pets: everybody on the stage. In the results phase the list is in order of place.</li>
 * </ul>
 * The stars of a judge who has not spoken yet are 0.
 */
public record ShowSyncPayload(Head head, Mine me, List<Entry> pets) implements CustomPacketPayload {
    public record Head(int result, int phase, int leftSec, int judges) {}

    public record Mine(boolean entered, int rank, int prize) {}

    public record Who(String owner, String name, String color) {}

    public record Score(List<Integer> stars, int rank, int total) {}

    /** bot = a guest pet (owner is empty). */
    public record Entry(Who who, PetLook look, int likes, boolean liked, boolean bot, Score score) {}

    public static final Type<ShowSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "show_sync"));

    private static final StreamCodec<ByteBuf, Head> HEAD = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, Head::result,
            ByteBufCodecs.VAR_INT, Head::phase,
            ByteBufCodecs.VAR_INT, Head::leftSec,
            ByteBufCodecs.VAR_INT, Head::judges,
            Head::new);

    private static final StreamCodec<ByteBuf, Mine> MINE = StreamCodec.composite(
            ByteBufCodecs.BOOL, Mine::entered,
            ByteBufCodecs.VAR_INT, Mine::rank,
            ByteBufCodecs.VAR_INT, Mine::prize,
            Mine::new);

    private static final StreamCodec<ByteBuf, Who> WHO = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(36), Who::owner,
            ByteBufCodecs.stringUtf8(32), Who::name,
            ByteBufCodecs.stringUtf8(16), Who::color,
            Who::new);

    private static final StreamCodec<ByteBuf, Score> SCORE = StreamCodec.composite(
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(ShowJudges.COUNT)), Score::stars,
            ByteBufCodecs.VAR_INT, Score::rank,
            ByteBufCodecs.VAR_INT, Score::total,
            Score::new);

    private static final StreamCodec<ByteBuf, Entry> ENTRY = StreamCodec.composite(
            WHO, Entry::who,
            PetLook.CODEC, Entry::look,
            ByteBufCodecs.VAR_INT, Entry::likes,
            ByteBufCodecs.BOOL, Entry::liked,
            ByteBufCodecs.BOOL, Entry::bot,
            SCORE, Entry::score,
            Entry::new);

    public static final StreamCodec<RegistryFriendlyByteBuf, ShowSyncPayload> STREAM_CODEC = StreamCodec.composite(
            HEAD, ShowSyncPayload::head,
            MINE, ShowSyncPayload::me,
            ENTRY.apply(ByteBufCodecs.list(ShowBoard.MAX_HUMANS)), ShowSyncPayload::pets,
            ShowSyncPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ShowSyncPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onShowSync(p));
    }
}
