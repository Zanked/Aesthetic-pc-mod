package dev.cutemod.client.game;

import dev.cutemod.ComputerColor;

public class GameFactory {
    public static MiniGame create(ComputerColor color) {
        return switch (color) {
            case PINK -> new FlappyCat();
            case GREEN -> new Minesweeper();
            case WHITE -> new PandaSnake();
            case BLUE -> new PenguinFishing();
            case ORANGE -> new FoxMemory();
            case PURPLE -> new EnderDodge();
            case YELLOW -> new WhackBee();
            case RED -> new LadybugMatch();
        };
    }

    private GameFactory() {}
}
