package dev.cutemod.client;

import dev.cutemod.ComputerColor;
import dev.cutemod.block.ComputerBlockEntity;
import dev.cutemod.client.game.GameFactory;
import dev.cutemod.client.game.MiniGame;
import dev.cutemod.net.ScorePayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** The "monitor": shows the mini game of this computer color. */
public class ComputerScreen extends Screen {
    private static final int PAD = 14;
    private static final int HEADER = 26;
    private static final int FOOTER = 22;
    private static final long STEP_NS = 16_666_667L; // games run at 60 steps/second

    private final ComputerColor color;
    private final BlockPos pos;
    private final MiniGame game;

    private int left, top, gx, gy, panelW, panelH;
    private long lastNs = 0, acc = 0;
    private boolean submitted = false;
    private int overTicks = 0;

    public ComputerScreen(ComputerColor color, BlockPos pos) {
        super(Component.translatable("cutemod.game." + color.id));
        this.color = color;
        this.pos = pos;
        this.game = GameFactory.create(color);
        this.game.reset();
    }

    @Override
    protected void init() {
        panelW = MiniGame.W + PAD * 2;
        panelH = MiniGame.H + HEADER + FOOTER;
        left = (width - panelW) / 2;
        top = (height - panelH) / 2;
        gx = left + PAD;
        gy = top + HEADER;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private ComputerBlockEntity be() {
        var level = Minecraft.getInstance().level;
        if (level != null && level.getBlockEntity(pos) instanceof ComputerBlockEntity b) return b;
        return null;
    }

    private void restart() {
        game.reset();
        submitted = false;
        overTicks = 0;
        acc = 0;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        super.render(g, mouseX, mouseY, partial);

        // --- fixed timestep for the game ---
        long now = System.nanoTime();
        if (lastNs == 0) lastNs = now;
        acc += now - lastNs;
        lastNs = now;
        if (acc > 100_000_000L) acc = 100_000_000L;
        game.setMouse(mouseX - gx, mouseY - gy);
        while (acc >= STEP_NS) {
            acc -= STEP_NS;
            if (!game.over) game.tick();
            else overTicks++;
        }
        if (game.over && !submitted) {
            submitted = true;
            if (game.score > 0) PacketDistributor.sendToServer(new ScorePayload(pos, game.score));
        }

        // --- computer casing ---
        int body = 0xFF000000 | color.bodyColor;
        boolean darkBody = luminance(color.bodyColor) < 110;
        int textCol = darkBody ? 0xFFFFFFFF : 0xFF3A2A3A;
        g.fill(left - 3, top - 3, left + panelW + 3, top + panelH + 3, 0xFF2A2030);
        g.fill(left - 2, top - 2, left + panelW + 2, top + panelH + 2, body);
        g.fill(left - 2, top - 2, left + panelW + 2, top - 1, 0x66FFFFFF);
        g.fill(gx - 4, gy - 4, gx + MiniGame.W + 4, gy + MiniGame.H + 4, 0xFF1B1422);

        // --- header ---
        g.drawString(font, title, left + PAD, top + 8, textCol, false);
        Component status = game.status();
        g.drawString(font, status, left + panelW - PAD - font.width(status), top + 8, textCol, false);

        // --- game ---
        g.enableScissor(gx, gy, gx + MiniGame.W, gy + MiniGame.H);
        g.pose().pushPose();
        g.pose().translate(gx, gy, 0);
        game.render(g);
        if (game.over) renderGameOver(g);
        g.pose().popPose();
        g.disableScissor();

        // --- footer: record + hint ---
        ComputerBlockEntity be = be();
        Component rec = (be == null || be.getHighScore() <= 0)
                ? Component.translatable("cutemod.ui.record_none")
                : Component.translatable("cutemod.ui.record", be.getHighScore(), be.getHolder());
        g.drawString(font, rec, left + PAD, gy + MiniGame.H + 8, textCol, false);
        Component hint = Component.translatable(game.hintKey());
        g.drawString(font, hint, left + panelW - PAD - font.width(hint), gy + MiniGame.H + 8, textCol, false);
    }

    private void renderGameOver(GuiGraphics g) {
        int w = 150, h = 48, x = (MiniGame.W - w) / 2, y = (MiniGame.H - h) / 2;
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFFFFFFFF);
        g.fill(x, y, x + w, y + h, 0xE0201828);
        g.drawCenteredString(font, Component.translatable("cutemod.ui.gameover"), x + w / 2, y + 7, 0xFFFFD866);
        g.drawCenteredString(font, Component.translatable("cutemod.ui.score", game.score), x + w / 2, y + 20, 0xFFFFFFFF);
        g.drawCenteredString(font, Component.translatable("cutemod.ui.restart"), x + w / 2, y + 33, 0xFFB8B0C8);
    }

    private static int luminance(int rgb) {
        int r = (rgb >> 16) & 255, gr = (rgb >> 8) & 255, b = rgb & 255;
        return (int) (0.299 * r + 0.587 * gr + 0.114 * b);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (game.over) {
            if (overTicks > 20) restart();
            return true;
        }
        int lx = (int) Math.floor(mouseX - gx), ly = (int) Math.floor(mouseY - gy);
        if (lx >= 0 && ly >= 0 && lx < MiniGame.W && ly < MiniGame.H) {
            game.click(lx, ly, button);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (game.over) {
            if ((keyCode == 32 || keyCode == 257) && overTicks > 20) { // space / enter
                restart();
                return true;
            }
        } else if (game.key(keyCode)) {
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
