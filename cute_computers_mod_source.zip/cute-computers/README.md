# Cute Computers (NeoForge 1.21.1)

Cute retro computers in 8 colors. **Right-click a computer to play its mini game.**
No redstone or energy needed. Every computer remembers its own high score and who set it.

![preview](docs/preview.png)

| Block | Game | Controls |
|---|---|---|
| `pink_computer` | Flappy Cat | click / Space |
| `green_computer` | Creeper Sweeper (minesweeper) | LMB dig, RMB flag |
| `white_computer` | Panda Snake | WASD / arrows |
| `blue_computer` | Penguin Fishing | mouse (avoid the pufferfish!) |
| `orange_computer` | Fox Memory (pairs) | click |
| `purple_computer` | Ender Dodge | mouse |
| `yellow_computer` | Whack-a-Bee | click the bee |
| `red_computer` | Ladybug Match (match-3, 20 moves) | click two neighbors |

## Crafting
- Pink computer: iron ingots, glass pane, pink dye, redstone (`IGI / IDI / IRI`).
- Any other color: any computer + the matching dye (shapeless).

## Build
Requires Java 21.

```
./gradlew build          # jar in build/libs
./gradlew runClient      # test in game
```
GitHub Actions (`.github/workflows/build.yml`) builds the jar on every push.

## Project layout
- `src/main/java/dev/cutemod` - blocks, block entity (high score), network packet
- `src/main/java/dev/cutemod/client` - the monitor screen and `game/` (all 8 mini games)
- `src/main/resources/assets/cutemod` - models, blockstates, textures (64x), lang (en, ru)
- `tools/` - Python scripts that generated the colored textures from the original pink pack

## Adding a new game
Extend `MiniGame` (`reset`, `tick` at 60/s, `render`, optionally `click`/`key`) and map it to a color in `GameFactory`.

## License
MIT
