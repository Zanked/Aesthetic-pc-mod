package dev.cutemod.item;

import dev.cutemod.CuteMod;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Real Minecraft items that CuteMarket delivers. The ids match {@code Market.ITEMS} (cupcake, icecream...),
 * so the server can hand out exactly what was ordered. Each food gives hunger plus a short effect.
 */
public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CuteMod.MOD_ID);

    /** The portable music player: right-click opens it, sneak + right-click plays or pauses. */
    public static final DeferredItem<Item> MUSIC_PLAYER = ITEMS.register("music_player",
            () -> new MusicPlayerItem(new Item.Properties().stacksTo(1)));

    /** The same player in the colours of the computers (music_player itself is the lavender one). Dye + any player = that colour. */
    public static final String[] PLAYER_COLORS = {"pink", "green", "white", "blue", "orange", "purple", "yellow", "red"};
    public static final Map<String, DeferredItem<Item>> COLOR_PLAYERS = new LinkedHashMap<>();
    static {
        for (String c : PLAYER_COLORS)
            COLOR_PLAYERS.put(c, ITEMS.register("music_player_" + c, () -> new MusicPlayerItem(new Item.Properties().stacksTo(1))));
    }

    private static final Map<String, DeferredItem<Item>> FOODS = new LinkedHashMap<>();
    private static final Map<String, int[]> SHOP = new LinkedHashMap<>(); // id -> {price in coins, delivery seconds}

    /** A food (or a drink, raised like a potion) that shows its effect in the tooltip. */
    private static final class CuteFood extends Item {
        private final boolean drink;
        private final Holder<MobEffect> effect;
        private final int seconds;

        CuteFood(Properties props, boolean drink, Holder<MobEffect> effect, int seconds) {
            super(props);
            this.drink = drink;
            this.effect = effect;
            this.seconds = seconds;
        }

        @Override
        public UseAnim getUseAnimation(ItemStack stack) { return drink ? UseAnim.DRINK : super.getUseAnimation(stack); }

        @Override
        public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
            if (effect != null) tip.add(Component.translatable("cutemod.tip.effect", effect.value().getDisplayName(), seconds).withStyle(ChatFormatting.BLUE));
        }
    }

    private static void food(String id, int price, int deliverySecs, int nutrition, float saturation, boolean drink,
                             Holder<MobEffect> effect, int seconds, int amplifier) {
        SHOP.put(id, new int[]{price, deliverySecs});
        FoodProperties.Builder b = new FoodProperties.Builder()
                .nutrition(nutrition)
                .saturationModifier(saturation)
                .alwaysEdible(); // the effect is the point, so you can eat when full
        if (effect != null) b.effect(() -> new MobEffectInstance(effect, seconds * 20, amplifier), 1.0F);
        FoodProperties props = b.build();
        FOODS.put(id, ITEMS.register(id, () -> {
            Item.Properties p = new Item.Properties().food(props);
            return new CuteFood(p, drink, effect, seconds);
        }));
    }

    static {
        //   id         coins  delivery  hunger sat    drink  effect                       sec amp
        food("cupcake",     8,  25,  4, 0.4F, false, MobEffects.MOVEMENT_SPEED,    20, 0);
        food("icecream",    9,  25,  3, 0.3F, false, MobEffects.JUMP,              20, 0);
        food("bubbletea",  10,  30,  4, 0.5F, true,  MobEffects.DIG_SPEED,         30, 0);
        food("toast",      12,  30,  5, 0.6F, false, MobEffects.ABSORPTION,        60, 0);
        food("burger",     15,  40,  8, 0.8F, false, MobEffects.DAMAGE_BOOST,      30, 0);
        food("pizza",      18,  45,  9, 0.8F, false, MobEffects.DAMAGE_RESISTANCE, 30, 0);
        food("ramen",      20,  50, 10, 1.0F, false, MobEffects.REGENERATION,      10, 0);
        food("sushi",      22,  60,  8, 1.2F, false, MobEffects.WATER_BREATHING,   90, 0);
    }

    /** The food item for a Market id, or null if the id is not a food. */
    public static Item food(String id) {
        DeferredItem<Item> d = FOODS.get(id);
        return d == null ? null : d.get();
    }

    public static boolean isFood(String id) { return SHOP.containsKey(id); }

    /** Price in coins (the server uses it to refund a refused order). */
    public static int price(String id) { return SHOP.get(id)[0]; }

    /** Normal delivery time in seconds. */
    public static int deliverySecs(String id) { return SHOP.get(id)[1]; }

    /** The ids of all foods, in catalog order. */
    public static List<String> ids() { return new ArrayList<>(SHOP.keySet()); }

    /** All foods in catalog order (for the creative tab). */
    public static List<Item> foods() {
        List<Item> out = new ArrayList<>();
        for (DeferredItem<Item> d : FOODS.values()) out.add(d.get());
        return out;
    }

    private ModItems() {}
}
