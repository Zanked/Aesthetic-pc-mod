package dev.cutemod;

import dev.cutemod.block.ModBlockEntities;
import dev.cutemod.block.ModBlocks;
import dev.cutemod.net.RequestDataPayload;
import dev.cutemod.net.SaveDataPayload;
import dev.cutemod.net.ScorePayload;
import dev.cutemod.net.SyncDataPayload;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

@Mod(CuteMod.MOD_ID)
public class CuteMod {
    public static final String MOD_ID = "cutemod";

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final Supplier<CreativeModeTab> TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.cutemod"))
                    .icon(() -> new ItemStack(ModBlocks.get(ComputerColor.PINK).get()))
                    .displayItems((params, out) -> {
                        for (ComputerColor c : ComputerColor.values()) {
                            out.accept(ModBlocks.get(c).get());
                        }
                        out.accept(dev.cutemod.item.ModItems.MUSIC_PLAYER.get());
                        for (var player : dev.cutemod.item.ModItems.COLOR_PLAYERS.values()) out.accept(player.get());
                        for (net.minecraft.world.item.Item food : dev.cutemod.item.ModItems.foods()) {
                            out.accept(food);
                        }
                    })
                    .build());

    public CuteMod(IEventBus modBus) {
        ModBlocks.BLOCKS.register(modBus);
        ModBlocks.ITEMS.register(modBus);
        dev.cutemod.item.ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        TABS.register(modBus);
        modBus.addListener(CuteMod::registerPayloads);
        // the server sends each player what it has saved for them as soon as they join
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedInEvent e) -> {
            RequestDataPayload.sendTo(e.getEntity());
            if (e.getEntity() instanceof net.minecraft.server.level.ServerPlayer sp) { dev.cutemod.net.PostServer.joined(sp); dev.cutemod.net.ShowServer.joined(sp); }
        });
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.RegisterCommandsEvent e) -> { dev.cutemod.net.PostServer.register(e.getDispatcher()); dev.cutemod.net.CoinsCommand.register(e.getDispatcher()); dev.cutemod.net.JobsCommand.register(e.getDispatcher()); dev.cutemod.net.ShowServer.register(e.getDispatcher()); dev.cutemod.net.TubeServer.register(e.getDispatcher()); });
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedOutEvent e) -> { dev.cutemod.net.NetServer.leave(e.getEntity().getUUID()); dev.cutemod.net.PostServer.leave(e.getEntity().getUUID()); dev.cutemod.net.ShowServer.leave(e.getEntity().getUUID()); dev.cutemod.net.ParkServer.leave(e.getEntity().getUUID()); dev.cutemod.net.StreamServer.leave(e.getEntity().getUUID()); dev.cutemod.net.TubeServer.leave(e.getEntity().getUUID()); dev.cutemod.net.CheckersServer.leave(e.getEntity().getUUID()); dev.cutemod.net.BilliardsServer.leave(e.getEntity().getUUID()); dev.cutemod.net.DashServer.leave(e.getEntity().getUUID()); dev.cutemod.net.DurakServer.leave(e.getEntity().getUUID()); });
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.tick.ServerTickEvent.Post e) -> dev.cutemod.net.ShowServer.tick(e.getServer()));
        if (FMLEnvironment.dist.isClient()) dev.cutemod.client.ClientHooks.init(modBus);
    }

    private static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("21");   // 21: online Kitty Dash (20: online billiards, 19: the LIVE chat and the player videos of CuteTube)
        registrar.playToServer(ScorePayload.TYPE, ScorePayload.STREAM_CODEC, ScorePayload::handle);
        registrar.playToServer(SaveDataPayload.TYPE, SaveDataPayload.STREAM_CODEC, SaveDataPayload::handle);
        registrar.playToServer(RequestDataPayload.TYPE, RequestDataPayload.STREAM_CODEC, RequestDataPayload::handle);
        registrar.playToClient(SyncDataPayload.TYPE, SyncDataPayload.STREAM_CODEC, SyncDataPayload::handle);
        registrar.playToServer(dev.cutemod.net.MarketOrderPayload.TYPE, dev.cutemod.net.MarketOrderPayload.STREAM_CODEC, dev.cutemod.net.MarketOrderPayload::handle);
        registrar.playToServer(dev.cutemod.net.MarketPickupPayload.TYPE, dev.cutemod.net.MarketPickupPayload.STREAM_CODEC, dev.cutemod.net.MarketPickupPayload::handle);
        registrar.playToServer(dev.cutemod.net.NetScorePayload.TYPE, dev.cutemod.net.NetScorePayload.STREAM_CODEC, dev.cutemod.net.NetScorePayload::handle);
        registrar.playToServer(dev.cutemod.net.NetPingPayload.TYPE, dev.cutemod.net.NetPingPayload.STREAM_CODEC, dev.cutemod.net.NetPingPayload::handle);
        registrar.playToServer(dev.cutemod.net.NetRequestPayload.TYPE, dev.cutemod.net.NetRequestPayload.STREAM_CODEC, dev.cutemod.net.NetRequestPayload::handle);
        registrar.playToClient(dev.cutemod.net.NetSyncPayload.TYPE, dev.cutemod.net.NetSyncPayload.STREAM_CODEC, dev.cutemod.net.NetSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.PostSendPayload.TYPE, dev.cutemod.net.PostSendPayload.STREAM_CODEC, dev.cutemod.net.PostSendPayload::handle);
        registrar.playToServer(dev.cutemod.net.PostRequestPayload.TYPE, dev.cutemod.net.PostRequestPayload.STREAM_CODEC, dev.cutemod.net.PostRequestPayload::handle);
        registrar.playToServer(dev.cutemod.net.PostDeletePayload.TYPE, dev.cutemod.net.PostDeletePayload.STREAM_CODEC, dev.cutemod.net.PostDeletePayload::handle);
        registrar.playToServer(dev.cutemod.net.PostBlockPayload.TYPE, dev.cutemod.net.PostBlockPayload.STREAM_CODEC, dev.cutemod.net.PostBlockPayload::handle);
        registrar.playToClient(dev.cutemod.net.PostSyncPayload.TYPE, dev.cutemod.net.PostSyncPayload.STREAM_CODEC, dev.cutemod.net.PostSyncPayload::handle);
        registrar.playToClient(dev.cutemod.net.AdminCoinsPayload.TYPE, dev.cutemod.net.AdminCoinsPayload.STREAM_CODEC, dev.cutemod.net.AdminCoinsPayload::handle);
        registrar.playToClient(dev.cutemod.net.AdminJobsPayload.TYPE, dev.cutemod.net.AdminJobsPayload.STREAM_CODEC, dev.cutemod.net.AdminJobsPayload::handle);
        registrar.playToClient(dev.cutemod.net.MarketSyncPayload.TYPE, dev.cutemod.net.MarketSyncPayload.STREAM_CODEC, dev.cutemod.net.MarketSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.ShowPutPayload.TYPE, dev.cutemod.net.ShowPutPayload.STREAM_CODEC, dev.cutemod.net.ShowPutPayload::handle);
        registrar.playToServer(dev.cutemod.net.ShowActionPayload.TYPE, dev.cutemod.net.ShowActionPayload.STREAM_CODEC, dev.cutemod.net.ShowActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.ShowPrizePayload.TYPE, dev.cutemod.net.ShowPrizePayload.STREAM_CODEC, dev.cutemod.net.ShowPrizePayload::handle);
        registrar.playToClient(dev.cutemod.net.ShowAlertPayload.TYPE, dev.cutemod.net.ShowAlertPayload.STREAM_CODEC, dev.cutemod.net.ShowAlertPayload::handle);
        registrar.playToServer(dev.cutemod.net.ShowRequestPayload.TYPE, dev.cutemod.net.ShowRequestPayload.STREAM_CODEC, dev.cutemod.net.ShowRequestPayload::handle);
        registrar.playToServer(dev.cutemod.net.ParkMovePayload.TYPE, dev.cutemod.net.ParkMovePayload.STREAM_CODEC, dev.cutemod.net.ParkMovePayload::handle);
        registrar.playToServer(dev.cutemod.net.ParkActionPayload.TYPE, dev.cutemod.net.ParkActionPayload.STREAM_CODEC, dev.cutemod.net.ParkActionPayload::handle);
        registrar.playToServer(dev.cutemod.net.ParkSayPayload.TYPE, dev.cutemod.net.ParkSayPayload.STREAM_CODEC, dev.cutemod.net.ParkSayPayload::handle);
        registrar.playToServer(dev.cutemod.net.StreamActionPayload.TYPE, dev.cutemod.net.StreamActionPayload.STREAM_CODEC, dev.cutemod.net.StreamActionPayload::handle);
        registrar.playToServer(dev.cutemod.net.TubePublishPayload.TYPE, dev.cutemod.net.TubePublishPayload.STREAM_CODEC, dev.cutemod.net.TubePublishPayload::handle);
        registrar.playToServer(dev.cutemod.net.TubeActionPayload.TYPE, dev.cutemod.net.TubeActionPayload.STREAM_CODEC, dev.cutemod.net.TubeActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.StreamSyncPayload.TYPE, dev.cutemod.net.StreamSyncPayload.STREAM_CODEC, dev.cutemod.net.StreamSyncPayload::handle);
        registrar.playToClient(dev.cutemod.net.TubeSyncPayload.TYPE, dev.cutemod.net.TubeSyncPayload.STREAM_CODEC, dev.cutemod.net.TubeSyncPayload::handle);
        registrar.playToClient(dev.cutemod.net.ParkSyncPayload.TYPE, dev.cutemod.net.ParkSyncPayload.STREAM_CODEC, dev.cutemod.net.ParkSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.CheckersActionPayload.TYPE, dev.cutemod.net.CheckersActionPayload.STREAM_CODEC, dev.cutemod.net.CheckersActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.CheckersSyncPayload.TYPE, dev.cutemod.net.CheckersSyncPayload.STREAM_CODEC, dev.cutemod.net.CheckersSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.BilliardsActionPayload.TYPE, dev.cutemod.net.BilliardsActionPayload.STREAM_CODEC, dev.cutemod.net.BilliardsActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.BilliardsSyncPayload.TYPE, dev.cutemod.net.BilliardsSyncPayload.STREAM_CODEC, dev.cutemod.net.BilliardsSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.DashActionPayload.TYPE, dev.cutemod.net.DashActionPayload.STREAM_CODEC, dev.cutemod.net.DashActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.DashSyncPayload.TYPE, dev.cutemod.net.DashSyncPayload.STREAM_CODEC, dev.cutemod.net.DashSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.DurakActionPayload.TYPE, dev.cutemod.net.DurakActionPayload.STREAM_CODEC, dev.cutemod.net.DurakActionPayload::handle);
        registrar.playToClient(dev.cutemod.net.DurakSyncPayload.TYPE, dev.cutemod.net.DurakSyncPayload.STREAM_CODEC, dev.cutemod.net.DurakSyncPayload::handle);
        registrar.playToServer(dev.cutemod.net.SeasonClaimPayload.TYPE, dev.cutemod.net.SeasonClaimPayload.STREAM_CODEC, dev.cutemod.net.SeasonClaimPayload::handle);
        registrar.playToClient(dev.cutemod.net.ShowSyncPayload.TYPE, dev.cutemod.net.ShowSyncPayload.STREAM_CODEC, dev.cutemod.net.ShowSyncPayload::handle);
    }
}
