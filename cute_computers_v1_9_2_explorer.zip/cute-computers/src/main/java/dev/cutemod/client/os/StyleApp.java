package dev.cutemod.client.os;

import dev.cutemod.data.PetWear;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * PetStyle: the wardrobe of your pet. The pet wears up to 5 layers (head, face, neck, body, outer); here you
 * can keep 5 complete outfits and put one on with a single click (instead of dressing the pet piece by piece in the
 * shop). Point at an outfit to see the pet wearing it. Only things you own can be worn. Saved on the server as "wardrobe".
 */
public class StyleApp extends App {
    private static final int SLOTS = 5;
    private static final int ROW_X = 118, ROW_Y = 20, ROW_W = 176, ROW_H = 26, ROW_PITCH = 29;
    private static final int SAVE_X = 208, SAVE_W = 38, WEAR_X = 248, WEAR_W = 44;
    private static final int TEXT = 0xFF3A2A3A, MUTED = 0xFF8A7AA8, ACCENT = 0xFFB57BD6;

    private final String[] head = new String[SLOTS], body = new String[SLOTS];
    private boolean loaded;
    private int ticks, armed = -1, armT, msgT;
    private String msg = "";

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        if (!loaded) { loaded = true; load(); }
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.style"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.style"); }

    // ---------- save / load ----------
    private void load() {
        for (int i = 0; i < SLOTS; i++) { head[i] = ""; body[i] = ""; }
        try {
            String s = Store.read("wardrobe");
            if (s == null || s.isBlank()) return;
            String[] p = s.split(";", -1);
            for (int i = 0; i < SLOTS && i < p.length; i++) {
                String[] f = p[i].split(",", -1);
                if (f.length >= 2 && ok(f[0]) && ok(f[1])) { head[i] = f[0]; body[i] = f[1]; }
            }
        } catch (Exception ignored) {
        }
    }

    /** Item ids are short words like acc_crown: nothing else is accepted from the save. */
    private static boolean ok(String s) { return s.length() <= 64 && s.matches("[a-z0-9_+]*"); }   // '+' joins the layers of one group

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < SLOTS; i++) sb.append(i > 0 ? ";" : "").append(head[i]).append(',').append(body[i]);
        try { Store.write("wardrobe", sb.toString()); } catch (Exception ignored) { }
    }

    // ---------- logic ----------
    private boolean filled(int i) { return !head[i].isEmpty() || !body[i].isEmpty(); }

    private void say(String key, Object... args) { msg = t(key, args); msgT = 180; }

    private void saveSlot(int i) {
        String h = Progress.equipped(), b = Progress.equippedBody();
        if (h.isEmpty() && b.isEmpty()) { say("cutemod.style.msg.naked"); return; }
        if (filled(i) && armed != i) { armed = i; armT = 150; say("cutemod.style.msg.sure"); return; }   // overwriting asks twice
        armed = -1;
        head[i] = h;
        body[i] = b;
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.6F, 0.5F);
        say("cutemod.style.msg.saved", i + 1);
        save();
    }

    private void wear(int i) {
        if (!filled(i)) return;
        int missing = 0;
        Progress.undress();                                              // every layer off, then the saved ones on
        for (String id : PetWear.layers(head[i])) { if (Progress.owned(id)) Progress.equip(id); else missing++; }
        for (String id : PetWear.layers(body[i])) { if (Progress.owned(id)) Progress.equip(id); else missing++; }
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.9F, 0.5F);
        if (missing > 0) say("cutemod.style.msg.missing", missing); else say("cutemod.style.msg.worn", i + 1);
    }

    private void takeOff() {
        Progress.undress();
        Sfx.ui(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.0F, 0.5F);
        say("cutemod.style.msg.off");
    }

    @Override
    public void tick() {
        ticks++;
        if (msgT > 0) msgT--;
        if (armT > 0 && --armT == 0) armed = -1;
    }

    /** The names of a packed list of layers, joined with commas. */
    private static String itemName(String packed) {
        if (packed.isEmpty()) return "-";
        StringBuilder sb = new StringBuilder();
        for (String id : PetWear.layers(packed)) sb.append(sb.length() > 0 ? ", " : "").append(t("cutemod.shop.item." + id));
        return sb.toString();
    }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, 0xFFFDF0F7);
        rect(g, 0, 0, W, 14, 0xFFB57BD6);
        g.drawString(f, t("cutemod.os.style"), 5, 3, 0xFFFFFFFF, false);
        // which outfit the big preview shows: the one under the mouse, or what the pet wears now
        int hover = -1;
        for (int i = 0; i < SLOTS; i++) if (in(mx, my, ROW_X, rowY(i), ROW_W, ROW_H)) hover = i;
        String ph = hover >= 0 && filled(hover) ? head[hover] : Progress.equipped();
        String pb = hover >= 0 && filled(hover) ? body[hover] : Progress.equippedBody();
        preview(g, f, ph, pb, hover >= 0 && filled(hover));
        for (int i = 0; i < SLOTS; i++) row(g, f, i, mx, my);
        boolean oh = in(mx, my, 6, 142, 100, 16);
        rect(g, 6, 142, 100, 16, oh ? 0xFFFFFFFF : 0xFFF6F0FA);
        rect(g, 6, 156, 100, 2, 0xFFB9A8C8);
        String off = t("cutemod.style.btn.off");
        g.drawString(f, off, 6 + (100 - f.width(off)) / 2, 146, TEXT, false);
        if (msgT > 0) {
            int w = f.width(msg) + 12, x = (W - w) / 2;
            rect(g, x, 128, w, 13, 0xEE3A2A3A);
            g.drawString(f, msg, x + 6, 131, 0xFFFFFFFF, false);
        }
    }

    private dev.cutemod.ComputerColor species() {
        dev.cutemod.ComputerColor c = PetApp.speciesOf(shell.color());
        return c == null ? shell.color() : c;
    }

    private static int rowY(int i) { return ROW_Y + i * ROW_PITCH; }

    private void preview(GuiGraphics g, Font f, String h, String b, boolean showing) {
        rect(g, 6, 20, 106, 104, showing ? 0xFFFFF3B0 : 0xFFEBDDF7);
        rect(g, 6, 114, 106, 10, 0xFFD9C7EA);
        dev.cutemod.ComputerColor spc = species();
        PetBlob.Info info = PetBlob.parse(Store.read("pet_" + spc.id));
        int stage = info == null ? 2 : info.stage();
        int cx = 59, floor = 112;
        float sc = 1.15F * PetArt.scaleOf(stage);
        int bob = (int) Math.round(Math.sin(ticks / 18.0) * 1.5);
        g.pose().pushPose();
        g.pose().translate(cx, floor, 0);
        g.pose().scale(sc, sc, 1F);
        g.pose().translate(-cx, -floor, 0);
        PetArt.draw(g, spc, cx, floor - 28 + bob, 2, ticks, false, info != null && info.sick(), stage, h, b);
        g.pose().popPose();
        String l1 = f.plainSubstrByWidth(itemName(h), 100), l2 = f.plainSubstrByWidth(itemName(b), 100);
        g.drawString(f, l1, 6 + (106 - f.width(l1)) / 2, 116, TEXT, false);
        g.drawString(f, l2, 6 + (106 - f.width(l2)) / 2, 125, MUTED, false);
    }

    private void row(GuiGraphics g, Font f, int i, int mx, int my) {
        int y = rowY(i);
        boolean full = filled(i), hov = in(mx, my, ROW_X, y, ROW_W, ROW_H);
        rect(g, ROW_X, y, ROW_W, ROW_H, hov ? 0xFFFFFFFF : 0xFFF6F0FA);
        rect(g, ROW_X, y, 3, ROW_H, full ? ACCENT : 0xFFD9C7EA);
        // a tiny pet wearing the outfit
        dev.cutemod.ComputerColor spc = species();
        PetBlob.Info info = PetBlob.parse(Store.read("pet_" + spc.id));
        int stage = info == null ? 2 : info.stage();
        if (full) {
            int cx = ROW_X + 19, floor = y + 24;
            float sc = 0.3F * PetArt.scaleOf(stage);
            g.pose().pushPose();
            g.pose().translate(cx, floor, 0);
            g.pose().scale(sc, sc, 1F);
            g.pose().translate(-cx, -floor, 0);
            PetArt.draw(g, spc, cx, floor - 28, 2, ticks, false, false, stage, head[i], body[i]);
            g.pose().popPose();
        }
        g.drawString(f, t("cutemod.style.outfit", i + 1), ROW_X + 38, y + 3, full ? TEXT : MUTED, false);
        String names = full ? f.plainSubstrByWidth(itemName(body[i].isEmpty() ? head[i] : head[i].isEmpty() ? body[i] : body[i] + PetWear.SEP + head[i]), SAVE_X - ROW_X - 42) : t("cutemod.style.empty");
        g.drawString(f, f.plainSubstrByWidth(names, SAVE_X - ROW_X - 42), ROW_X + 38, y + 14, MUTED, false);
        btn(g, f, mx, my, SAVE_X, y + 5, SAVE_W, armed == i ? t("cutemod.style.btn.sure") : t("cutemod.style.btn.save"), armed == i ? 3 : 0);
        btn(g, f, mx, my, WEAR_X, y + 5, WEAR_W, t("cutemod.style.btn.wear"), full ? 1 : 2);
    }

    /** style 0 normal, 1 main, 2 dimmed, 3 warning. */
    private void btn(GuiGraphics g, Font f, int mx, int my, int x, int y, int w, String label, int style) {
        boolean hov = style != 2 && in(mx, my, x, y, w, 16);
        int bg = style == 1 ? (hov ? 0xFF9A6FD0 : ACCENT) : style == 2 ? 0xFFE9E2F2 : style == 3 ? 0xFFE5486F : hov ? 0xFFE4D8FF : 0xFFFFFFFF;
        rect(g, x, y, w, 16, bg);
        rect(g, x, y + 14, w, 2, style == 1 || style == 3 ? 0x33000000 : 0xFFB9A8C8);
        String l = f.plainSubstrByWidth(label, w - 4);
        g.drawString(f, l, x + (w - f.width(l)) / 2, y + 4, style == 1 || style == 3 ? 0xFFFFFFFF : style == 2 ? 0xFFB8A8D8 : TEXT, false);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        for (int i = 0; i < SLOTS; i++) {
            int ry = rowY(i) + 5;
            if (in(x, y, SAVE_X, ry, SAVE_W, 16)) { saveSlot(i); return true; }
            if (in(x, y, WEAR_X, ry, WEAR_W, 16)) { wear(i); return true; }
        }
        if (in(x, y, 6, 142, 100, 16)) { takeOff(); return true; }
        return false;
    }
}
