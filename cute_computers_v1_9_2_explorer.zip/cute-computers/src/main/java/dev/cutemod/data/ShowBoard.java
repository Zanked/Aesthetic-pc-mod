package dev.cutemod.data;

import dev.cutemod.ComputerColor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * The talent show of the Tamagotchis. Pure logic (no Minecraft classes), so the rules can be tested on their own;
 * {@link ShowData} saves it to the world.
 * <p>
 * The show is a <b>random event</b>: it only happens in the round {@link #eventRound()} (planned at a random time, see {@link #tickEvent}).
 * A round follows the clock ({@code round = now / ROUND_MS}), so nothing has to be started
 * and the server and every client agree:
 * <ul>
 *   <li><b>OPEN</b> (3 min): players put their pet on the stage and like each other's pets;</li>
 *   <li><b>JUDGING</b> (2 min): the doors close, the four judges show their stars one by one, likes still count;</li>
 *   <li><b>RESULTS</b> (1 min): the podium. Coins are paid once, at the start of this phase.</li>
 * </ul>
 * One player has one pet on the stage. If fewer than {@link #MIN_ON_STAGE} players take part, guest pets
 * ({@link ShowJudges#bots}) fill the stage so it is never empty. Guests can win places but never get coins.
 * The pet is a snapshot sent by the client (the server cannot look inside it), so every value is checked against
 * white lists, like the scores of CuteNet.
 */
public final class ShowBoard {
    public static final int OK = 0, TOO_FAST = 1, REFUSED = 2, SICK = 3, OWN = 4, MISSING = 5, NOOP = 6, CLOSED = 7, FULL = 8, BOT = 9;
    public static final int OPEN = 0, JUDGING = 1, RESULTS = 2;
    /** No show is on right now (the show is a random event, see {@link #live}). */
    public static final int IDLE = 3;

    /** The show is a random event: after one has ended, the next one comes after a random pause of this length. */
    public static final long EVENT_MIN_GAP_MS = 30 * 60_000L;
    public static final long EVENT_MAX_GAP_MS = 120 * 60_000L;

    /** A round is 6 minutes: 3 open, 2 judging, 1 results (it used to be 10 minutes, which felt too long). */
    public static final long ROUND_MS = 6 * 60_000L;
    public static final long OPEN_MS = 3 * 60_000L;
    public static final long RESULTS_AT_MS = 5 * 60_000L;
    /** The judges show their stars at these moments of the round (every 30 s, while they chat). */
    public static final long[] REVEAL_MS = {OPEN_MS + 15_000L, OPEN_MS + 45_000L, OPEN_MS + 75_000L, OPEN_MS + 105_000L};

    public static final int MAX_HUMANS = 8;
    public static final int MIN_ON_STAGE = 4;
    public static final int MAX_AGE_MIN = 10_000_000;
    /** Coins by place (1st, 2nd, 3rd), and for everybody else who took part. */
    public static final int[] PRIZE = {12, 8, 5};
    public static final int PRIZE_PART = 2;
    /** The most coins one player can get from the show in a day. */
    public static final int DAILY_CAP = 60;
    private static final long DAY_MS = 86_400_000L;

    /** Gold cups that win the show's own outfit (the champion's laurels), and how many gold cups each title needs. */
    public static final int OUTFIT_GOLD = 10;
    private static final int[] TITLE_GOLD = {1, 3, 6, 10};
    /** How many winners the hall of fame remembers. */
    public static final int HALL_SIZE = 10;

    /** The title level of a player with this many gold cups: 0 none, 1 to 4 (see cutemod.show.rank.N). */
    public static int titleLevel(int gold) {
        int lvl = 0;
        for (int i = 0; i < TITLE_GOLD.length; i++) if (gold >= TITLE_GOLD[i]) lvl = i + 1;
        return lvl;
    }

    /** The winner of one round (a guest can win too). */
    public record Winner(long round, String name, String color, boolean bot, int total) {}

    /** Things a pet may wear on its head / face and on its neck / body (see PetArt). */
    public static final Set<String> HEAD = PetWear.HEAD_IDS;
    public static final Set<String> BODY = PetWear.BODY_IDS;

    public static final class Pet {
        public final UUID owner;
        public long round;
        public String ownerName, color, head, body;
        public int stage, trait, ageMin;
        public long since;
        public final Set<UUID> likes = new LinkedHashSet<>();

        Pet(UUID owner, long round) { this.owner = owner; this.round = round; }
    }

    /** One pet on the stage (a player's or a guest) with its score. rank is 0 until the results. */
    public static final class Standing {
        public final boolean bot;
        public final UUID owner;               // null for a guest
        public final String name, color, head, body;
        public final int stage, trait, ageMin;
        public int likes;
        public final int[] stars = new int[ShowJudges.COUNT];
        public int total, rank;
        public long since;

        Standing(boolean bot, UUID owner, String name, String color, int stage, int trait, int ageMin, String head, String body) {
            this.bot = bot; this.owner = owner; this.name = name; this.color = color;
            this.stage = stage; this.trait = trait; this.ageMin = ageMin; this.head = head; this.body = body;
        }

        public int starSum() { int s = 0; for (int v : stars) s += v; return s; }
    }

    /** Coins for one player at the end of a round. */
    public record Prize(UUID owner, String name, int rank, int coins) {}

    private final Map<UUID, Pet> entries = new HashMap<>();
    private long paidRound = -1;
    private long eventRound = -1;     // the round that is the show (-1 = none planned); the show is only on during this round
    private long nextAt;              // when the next event gets planned (0 = not set yet)
    private final Map<UUID, long[]> daily = new HashMap<>();      // {day, coins taken from the show that day}
    private final Map<UUID, int[]> medals = new HashMap<>();      // {gold, silver, bronze, rounds played}
    private final List<Winner> hall = new ArrayList<>();          // the last winners, newest first

    // ---------- the clock ----------
    public static long roundOf(long now) { return Math.floorDiv(now, ROUND_MS); }

    private static long offset(long now) { return Math.floorMod(now, ROUND_MS); }

    public static int phaseOf(long now) {
        long o = offset(now);
        return o < OPEN_MS ? OPEN : o < RESULTS_AT_MS ? JUDGING : RESULTS;
    }

    /** Milliseconds until the current phase ends. */
    public static long phaseLeftMs(long now) {
        long o = offset(now);
        return (o < OPEN_MS ? OPEN_MS : o < RESULTS_AT_MS ? RESULTS_AT_MS : ROUND_MS) - o;
    }

    /** How many judges have shown their stars by now (0-4). */
    public static int revealed(long now) {
        long o = offset(now);
        int n = 0;
        for (long r : REVEAL_MS) if (o >= r) n++;
        return n;
    }

    // ---------- the random event ----------
    /** True while the show is on: the current round is the planned event round. */
    public boolean live(long now) { return eventRound >= 0 && roundOf(now) == eventRound; }

    public long eventRound() { return eventRound; }

    public long nextAt() { return nextAt; }

    public void restoreEvent(long eventRound, long nextAt) { this.eventRound = eventRound; this.nextAt = nextAt; }

    /** Plan the show for the next round (admin command / the random timer). */
    public void startAtNextRound(long now) { eventRound = roundOf(now) + 1; nextAt = 0; }

    /**
     * Moves the random schedule on. Returns true if something changed (so the world must be saved):
     * a finished event is forgotten and the next one is set after a random pause; when the pause is over the
     * show is planned for the next round (so every client sees a clean start).
     */
    public boolean tickEvent(long now, java.util.Random rnd) {
        if (eventRound >= 0) {
            if (roundOf(now) <= eventRound) return false;                 // still to come, or on now
            eventRound = -1;                                              // it is over
            nextAt = now + randomGap(rnd);
            return true;
        }
        if (nextAt == 0) { nextAt = now + randomGap(rnd); return true; }
        if (now >= nextAt) { startAtNextRound(now); return true; }
        return false;
    }

    private static long randomGap(java.util.Random rnd) {
        return EVENT_MIN_GAP_MS + (long) (rnd.nextDouble() * (EVENT_MAX_GAP_MS - EVENT_MIN_GAP_MS));
    }

    // ---------- checks ----------
    public static boolean validColor(String c) {
        if (c == null) return false;
        for (ComputerColor v : ComputerColor.values()) if (v.id.equals(c)) return true;
        return false;
    }

    private static String cleanName(String s) {
        String n = s == null ? "" : s.trim();
        if (n.length() > 32) n = n.substring(0, 32);
        return n.isEmpty() ? "?" : n;
    }

    private static boolean validLook(int stage, int trait, int ageMin, String head, String body) {
        return stage >= 0 && stage <= 2 && trait >= 0 && trait <= 4 && ageMin >= 0 && ageMin <= MAX_AGE_MIN
                && PetWear.validPacked(head, false) && PetWear.validPacked(body, true);
    }

    // ---------- the stage ----------
    private int humans(long round) {
        int n = 0;
        for (Pet p : entries.values()) if (p.round == round) n++;
        return n;
    }

    /** True if this player's pet is on the stage of the current round. */
    public boolean entered(UUID owner, long now) {
        Pet p = entries.get(owner);
        return p != null && p.round == roundOf(now);
    }

    /**
     * Put a pet on the stage (or refresh how it looks: the likes stay while the color is the same).
     * OK, CLOSED (the doors are shut), FULL, REFUSED (invalid values) or SICK (a sick pet is not shown).
     */
    public int put(UUID owner, String ownerName, String color, int stage, int trait, int ageMin, boolean sick,
                   String head, String body, long now) {
        if (owner == null || !validColor(color) || !validLook(stage, trait, ageMin, head, body)) return REFUSED;
        if (sick) return SICK;
        if (!live(now) || phaseOf(now) != OPEN) return CLOSED;
        long round = roundOf(now);
        Pet p = entries.get(owner);
        if (p == null || p.round != round) {
            if (humans(round) >= MAX_HUMANS) return FULL;
            p = new Pet(owner, round);
            p.since = now;
            entries.put(owner, p);
        } else if (!p.color.equals(color)) {                 // a pet of another color is a new act: the likes are lost
            p.likes.clear();
            p.since = now;
        }
        p.color = color;
        p.ownerName = cleanName(ownerName);
        p.stage = stage; p.trait = trait; p.ageMin = ageMin; p.head = head; p.body = body;
        return OK;
    }

    /** Put back a pet read from the save file. Entries of a finished round are kept until they are paid. */
    public void restore(UUID owner, String ownerName, long round, String color, int stage, int trait, int ageMin,
                        String head, String body, long since, Set<UUID> likes) {
        if (owner == null || !validColor(color) || !validLook(stage, trait, ageMin, head, body)) return;
        Pet p = new Pet(owner, round);
        p.ownerName = cleanName(ownerName);
        p.color = color; p.stage = stage; p.trait = trait; p.ageMin = ageMin; p.head = head; p.body = body; p.since = since;
        for (UUID u : likes) if (!u.equals(owner)) p.likes.add(u);
        entries.put(owner, p);
    }

    /** Take the pet off the stage (only while the doors are open). */
    public int remove(UUID owner, long now) {
        Pet p = entries.get(owner);
        if (p == null || p.round != roundOf(now)) return MISSING;
        if (!live(now) || phaseOf(now) != OPEN) return CLOSED;
        entries.remove(owner);
        return OK;
    }

    /** Take a player's pet away whatever the phase (admin command). */
    public boolean removeAll(UUID owner) { return entries.remove(owner) != null; }

    /** The player changed their name: refresh it on their pet. */
    public boolean rename(UUID owner, String name) {
        Pet p = entries.get(owner);
        String n = cleanName(name);
        if (p == null || n.equals(p.ownerName)) return false;
        p.ownerName = n;
        return true;
    }

    // ---------- likes ----------
    /** OK (new like), NOOP (already liked), OWN, MISSING (no such pet on this stage), CLOSED. */
    public int like(UUID voter, UUID owner, long now) {
        if (voter == null || owner == null) return MISSING;
        if (voter.equals(owner)) return OWN;
        if (!live(now) || phaseOf(now) == RESULTS) return CLOSED;
        Pet p = entries.get(owner);
        if (p == null || p.round != roundOf(now)) return MISSING;
        return p.likes.add(voter) ? OK : NOOP;
    }

    public int unlike(UUID voter, UUID owner, long now) {
        if (!live(now) || phaseOf(now) == RESULTS) return CLOSED;
        Pet p = entries.get(owner);
        if (p == null || p.round != roundOf(now)) return MISSING;
        return p.likes.remove(voter) ? OK : NOOP;
    }

    /** True if this voter has liked the pet of that owner on the current stage. */
    public boolean liked(UUID owner, UUID voter, long now) {
        Pet p = entries.get(owner);
        return p != null && p.round == roundOf(now) && p.likes.contains(voter);
    }

    // ---------- the standings ----------
    /** The hearts a guest has by now: they grow while the doors are open, like a crowd cheering. */
    private static int botHearts(ShowJudges.Bot b, long now) {
        long o = Math.min(offset(now), OPEN_MS);
        return (int) (b.hearts() * o / OPEN_MS);
    }

    /**
     * Everybody on the stage of a round, with their stars and hearts. Humans come in the order they arrived, then the
     * guests. A pet is judged as it looks (the stars do not depend on the time); {@code now} only decides how many
     * hearts the guests have. In the results phase (or later) {@link #rank} gives every pet its place.
     */
    public List<Standing> standings(long round, long now) {
        List<Pet> humans = new ArrayList<>();
        for (Pet p : entries.values()) if (p.round == round) humans.add(p);
        humans.sort(Comparator.comparingLong((Pet p) -> p.since).thenComparing(p -> p.owner.toString()));
        List<Standing> out = new ArrayList<>();
        for (Pet p : humans) {
            Standing s = new Standing(false, p.owner, p.ownerName, p.color, p.stage, p.trait, p.ageMin, p.head, p.body);
            s.likes = p.likes.size();
            s.since = p.since;
            for (int j = 0; j < ShowJudges.COUNT; j++)
                s.stars[j] = ShowJudges.stars(j, round, p.owner.toString(), p.color, p.stage, p.trait, p.ageMin, p.head, p.body);
            out.add(s);
        }
        List<ShowJudges.Bot> bots = ShowJudges.bots(round);
        int need = Math.max(0, MIN_ON_STAGE - humans.size());
        for (int i = 0; i < need && i < bots.size(); i++) {
            ShowJudges.Bot b = bots.get(i);
            Standing s = new Standing(true, null, b.name(), b.color(), b.stage(), b.trait(), b.ageMin(), b.head(), b.body());
            s.likes = botHearts(b, now);
            s.since = Long.MAX_VALUE;
            for (int j = 0; j < ShowJudges.COUNT; j++)
                s.stars[j] = ShowJudges.stars(j, round, "guest:" + b.name(), b.color(), b.stage(), b.trait(), b.ageMin(), b.head(), b.body());
            out.add(s);
        }
        for (Standing s : out) s.total = s.starSum() + s.likes;
        return out;
    }

    /** Sort by place (best first) and number the pets 1, 2, 3... Ties: more likes, then who came first, humans before guests. */
    public static void rank(List<Standing> list) {
        list.sort(Comparator.comparingInt((Standing s) -> -s.total).thenComparingInt(s -> -s.likes)
                .thenComparing(s -> s.bot ? 1 : 0).thenComparingLong(s -> s.since).thenComparing(s -> s.name));
        for (int i = 0; i < list.size(); i++) list.get(i).rank = i + 1;
    }

    public static int prizeFor(int rank) { return rank >= 1 && rank <= PRIZE.length ? PRIZE[rank - 1] : PRIZE_PART; }

    // ---------- paying ----------
    /** A round that has ended but has not been paid yet (the newest one), or -1. */
    public long unpaidRound(long now) {
        long cur = roundOf(now), best = -1;
        for (Pet p : entries.values()) {
            if (p.round > paidRound && (p.round < cur || (p.round == cur && phaseOf(now) == RESULTS))) best = Math.max(best, p.round);
        }
        return best;
    }

    /**
     * Work out the prizes of a round and mark it as paid (only once). The coins already count the daily limit: a player
     * gets at most {@link #DAILY_CAP} coins a day from the show.
     */
    public List<Prize> pay(long round, long now) {
        List<Prize> out = new ArrayList<>();
        if (round <= paidRound) return out;
        paidRound = round;
        List<Standing> list = standings(round, (round + 1) * ROUND_MS - 1);
        rank(list);
        if (!list.isEmpty()) {                               // the hall of fame remembers who won (a guest too)
            Standing w = list.get(0);
            hall.add(0, new Winner(round, w.name, w.color, w.bot, w.total));
            while (hall.size() > HALL_SIZE) hall.remove(hall.size() - 1);
        }
        for (Standing s : list) {
            if (s.bot) continue;
            int[] m = medals.computeIfAbsent(s.owner, k -> new int[4]);   // cups: places 1 to 3 (a guest in front pushes you down)
            m[3]++;
            if (s.rank >= 1 && s.rank <= 3) m[s.rank - 1]++;
            int coins = prizeFor(s.rank);
            long day = now / DAY_MS;
            long[] d = daily.computeIfAbsent(s.owner, k -> new long[]{day, 0});
            if (d[0] != day) { d[0] = day; d[1] = 0; }
            coins = (int) Math.max(0, Math.min(coins, DAILY_CAP - d[1]));
            d[1] += coins;
            out.add(new Prize(s.owner, s.name, s.rank, coins));
        }
        return out;
    }

    /** Forget the pets of rounds that are over and paid. */
    public boolean prune(long now) {
        long cur = roundOf(now);
        return entries.values().removeIf(p -> p.round < cur && p.round <= paidRound);
    }

    public long paidRound() { return paidRound; }

    public void restorePaid(long round) { paidRound = round; }

    public Map<UUID, long[]> dailyMap() { return daily; }

    /** {gold, silver, bronze, rounds played} of a player (zeros for a newcomer). */
    public int[] medals(UUID id) {
        int[] m = id == null ? null : medals.get(id);
        return m == null ? new int[4] : m.clone();
    }

    public Map<UUID, int[]> medalsMap() { return medals; }

    public void restoreMedals(UUID id, int gold, int silver, int bronze, int shows) {
        if (id != null) medals.put(id, new int[]{Math.max(0, gold), Math.max(0, silver), Math.max(0, bronze), Math.max(0, shows)});
    }

    /** The last winners, newest first. */
    public List<Winner> hall() { return new ArrayList<>(hall); }

    /** Put back a winner read from the save file (they are saved newest first). */
    public void restoreWinner(Winner w) { if (w != null && hall.size() < HALL_SIZE) hall.add(w); }

    public List<Pet> all() { return new ArrayList<>(entries.values()); }
}
