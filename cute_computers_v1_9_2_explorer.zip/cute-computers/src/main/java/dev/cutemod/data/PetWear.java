package dev.cutemod.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Everything a pet can wear: which slot (head or body), the price, where it comes from, which set it belongs to,
 * which judge likes it and which themes of the talent show it fits. Pure logic (no Minecraft classes), so the
 * shop, the stage, the server check and the judges all read the same list.
 * <p>
 * A "set" is a head item and a body item that belong together (chef hat + apron). A pet that wears both gets a
 * bonus from every judge. The old items ("legacy") keep the tastes written in {@link ShowJudges}; the new ones are
 * scored through the tags here.
 */
public final class PetWear {
    private PetWear() {}

    /** What every judge loves: Mei (0) cute, Boom (1) style, Void (2) mystery, Honey (3) fun. */
    public static final int CUTE = 1, STYLE = 2, MYSTERY = 4, FUN = 8;

    /** Where an item comes from. */
    public enum Src { SHOP, STORY, SHOW, COUNT, SEASON }

    /**
     * @param taste  bit mask of the judges that like it (new items only)
     * @param themes bit mask of the show themes it fits (bit 0 = theme 0 ...)
     * @param key    COUNT: the counter that unlocks it; at = the value needed (SHOW: the gold cups needed)
     * @param from   SEASON: first day on sale as month * 100 + day; to = last day (may wrap over the new year)
     */
    public record Item(String id, boolean body, int price, Src src, String set, int taste, int themes, boolean legacy,
                       String key, int at, int from, int to) {}

    private static final List<Item> ALL_LIST = new ArrayList<>();
    private static final Map<String, Item> BY_ID = new HashMap<>();

    /**
     * The layers a pet can wear, from the one next to the body to the one on top (this is also the drawing order).
     * Head and face are the upper group, body, outer and neck the lower one: the network, the stage and the judges
     * still carry two strings ("head" = upper group, "body" = lower group), each one a packed list of ids joined with
     * {@link #SEP}, at most one id per layer (see {@link #layers} and {@link #validPacked}).
     */
    public enum Slot {
        BODY(true), OUTER(true), NECK(true), FACE(false), HEAD(false);
        public final boolean lower;
        Slot(boolean lower) { this.lower = lower; }
    }

    /** Separates the ids of a packed list of layers ("acc_crown+acc_glasses"). */
    public static final char SEP = '+';

    private static final Map<String, Slot> SLOT = new HashMap<>();
    private static final String[] NONE = new String[0];

    /** Which layer an item goes to: the old two-slot flag says the group, this says the exact layer. */
    private static Slot slotFor(String id, boolean body) {
        switch (id) {
            case "acc_glasses", "acc_bow", "acc_flower", "acc_bandana": return Slot.FACE;
            case "acc_scarf": return Slot.NECK;
            case "acc_cape", "acc_coat", "acc_tux", "acc_apron", "acc_armor", "acc_wings": return Slot.OUTER;
            default: return body ? Slot.BODY : Slot.HEAD;
        }
    }

    /** The layer of an item (an unknown id counts as a head item, like before). */
    public static Slot slotOf(String id) {
        Slot s = id == null ? null : SLOT.get(id);
        return s == null ? Slot.HEAD : s;
    }

    /** The items of a packed list, in drawing order (the layer next to the body first). */
    public static String[] layers(String packed) {
        if (packed == null || packed.isEmpty()) return NONE;
        if (packed.indexOf(SEP) < 0) return new String[]{packed};
        String[] p = packed.split("\\" + SEP);
        for (int i = 1; i < p.length; i++) {
            String k = p[i];
            int j = i - 1;
            while (j >= 0 && slotOf(p[j]).ordinal() > slotOf(k).ordinal()) { p[j + 1] = p[j]; j--; }
            p[j + 1] = k;
        }
        return p;
    }

    /** Packs what is worn (one id or "" per layer, indexed by {@link Slot#ordinal()}) into the list of one group. */
    public static String pack(String[] bySlot, boolean lower) {
        StringBuilder sb = new StringBuilder();
        for (Slot s : Slot.values()) {
            if (s.lower != lower) continue;
            String id = bySlot[s.ordinal()];
            if (id == null || id.isEmpty()) continue;
            if (sb.length() > 0) sb.append(SEP);
            sb.append(id);
        }
        return sb.toString();
    }

    /** True for "" or a list of known items of the right group with at most one per layer (the server checks this). */
    public static boolean validPacked(String packed, boolean lower) {
        if (packed == null || packed.length() > 64) return false;
        if (packed.isEmpty()) return true;
        boolean[] seen = new boolean[Slot.values().length];
        for (String id : packed.split("\\" + SEP, -1)) {
            if (!BY_ID.containsKey(id)) return false;
            Slot s = slotOf(id);
            if (s.lower != lower || seen[s.ordinal()]) return false;
            seen[s.ordinal()] = true;
        }
        return true;
    }

    private static int th(int... t) {
        int m = 0;
        for (int i : t) m |= 1 << i;
        return m;
    }

    private static void add(Item it) {
        ALL_LIST.add(it);
        BY_ID.put(it.id(), it);
        SLOT.put(it.id(), slotFor(it.id(), it.body()));
    }

    /** An item from before the wardrobe grew: judged by the old rules, only the new themes (6+) and sets use the tags. */
    private static void old(String id, boolean body, int price, Src src, String set, int themes, String key, int at) {
        add(new Item(id, body, price, src, set, 0, themes, true, key, at, 0, 0));
    }

    private static void shop(String id, boolean body, int price, String set, int taste, int themes) {
        add(new Item(id, body, price, Src.SHOP, set, taste, themes, false, "", 0, 0, 0));
    }

    private static void season(String id, boolean body, int price, int from, int to, String set, int taste, int themes) {
        add(new Item(id, body, price, Src.SEASON, set, taste, themes, false, "", 0, from, to));
    }

    private static void count(String id, boolean body, String key, int at, String set, int taste, int themes) {
        add(new Item(id, body, 0, Src.COUNT, set, taste, themes, false, key, at, 0, 0));
    }

    private static void gold(String id, boolean body, int cups, String set, int taste, int themes) {
        add(new Item(id, body, 0, Src.SHOW, set, taste, themes, false, "gold", cups, 0, 0));
    }

    // themes: 0 sweet, 1 spooky, 2 royal, 3 cozy winter, 4 rock star, 5 garden, 6 beach, 7 space, 8 pirates, 9 cooking show
    static {
        // the first wardrobe (same order and prices as before)
        old("acc_flower", false, 35, Src.SHOP, "fairy", th(6), "", 0);
        old("acc_glasses", false, 30, Src.SHOP, "", th(6, 7), "", 0);
        old("acc_bow", false, 30, Src.SHOP, "", th(9), "", 0);
        old("acc_cap", false, 40, Src.SHOP, "", th(6, 9), "", 0);
        old("acc_party", false, 40, Src.SHOP, "", 0, "", 0);
        old("acc_hat", false, 50, Src.SHOP, "gentleman", th(8), "", 0);
        old("acc_halo", false, 80, Src.SHOP, "", th(7), "", 0);
        old("acc_ushanka", false, 45, Src.SHOP, "", 0, "", 0);
        old("acc_headphones", false, 50, Src.SHOP, "", th(7), "", 0);
        old("acc_horns", false, 40, Src.SHOP, "", 0, "", 0);
        old("acc_witch", false, 55, Src.SHOP, "", 0, "", 0);
        old("acc_scarf", true, 35, Src.SHOP, "", 0, "", 0);
        old("acc_cape", true, 65, Src.SHOP, "spooky", th(8), "", 0);
        old("acc_crown", false, 0, Src.STORY, "", 0, "", 0);       // a reward for finishing the story
        old("acc_ghost", false, 0, Src.STORY, "", 0, "", 0);       // a reward for part 2 of the story
        old("acc_champion", false, 0, Src.SHOW, "", 0, "gold", 10); // ten gold cups

        // new, for sale: head
        shop("acc_chef", false, 45, "chef", FUN, th(9));
        shop("acc_pirate", false, 55, "pirate", STYLE | MYSTERY, th(8));
        shop("acc_bunny", false, 40, "bunny", CUTE, th(0, 5));
        shop("acc_catears", false, 35, "kawaii", CUTE | FUN, th(0, 4));
        shop("acc_beret", false, 35, "", STYLE, th(2, 5));
        shop("acc_straw", false, 40, "beach", FUN, th(5, 6));
        shop("acc_mushroom", false, 50, "", CUTE | MYSTERY, th(5, 0));
        shop("acc_sprout", false, 15, "", CUTE | FUN, th(5));          // cheap: a little green sprout
        shop("acc_starclip", false, 20, "", CUTE | STYLE, th(0, 7));   // cheap: a golden star hair clip
        // new, for sale: body
        shop("acc_hoodie", true, 60, "street", FUN | STYLE, th(3, 4));
        shop("acc_sweater", true, 50, "winter", CUTE, th(3));
        shop("acc_tutu", true, 55, "bunny", CUTE, th(0, 2));
        shop("acc_tux", true, 70, "gentleman", STYLE, th(2, 4));
        shop("acc_pajamas", true, 50, "sleepover", CUTE | FUN, th(3, 0));
        shop("acc_hawaiian", true, 55, "beach", FUN, th(6, 5));
        shop("acc_apron", true, 45, "chef", FUN, th(9, 5));
        shop("acc_wings", true, 75, "fairy", CUTE | MYSTERY, th(0, 5));
        shop("acc_kimono", true, 70, "kawaii", STYLE | CUTE, th(2, 5));
        shop("acc_coat", true, 65, "pirate", STYLE | MYSTERY, th(8, 1));
        // seasonal: on sale only for a while every year, yours for good once bought
        season("acc_pumpkin", false, 45, 1001, 1107, "spooky", MYSTERY | FUN, th(1));
        season("acc_santa", false, 45, 1201, 110, "winter", CUTE | FUN, th(3, 0));
        // rewards: played, cured, or won
        count("acc_helmet", false, "pet_games", 15, "astronaut", MYSTERY | FUN, th(7));
        count("acc_spacesuit", true, "pet_games", 30, "astronaut", MYSTERY | FUN, th(7));
        count("acc_bandana", false, "pet_perfect", 3, "street", FUN | STYLE, th(4, 8));
        count("acc_nightcap", false, "pet_cured", 2, "sleepover", CUTE, th(3, 0));
        gold("acc_knight", false, 3, "knight", STYLE | MYSTERY, th(2));
        gold("acc_armor", true, 6, "knight", STYLE | MYSTERY, th(2, 8));
    }

    /** Every item, in the order of the shop. */
    public static final List<Item> ALL = Collections.unmodifiableList(ALL_LIST);

    public static final Set<String> HEAD_IDS, BODY_IDS;

    static {
        Set<String> h = new LinkedHashSet<>(), b = new LinkedHashSet<>();
        for (Item it : ALL_LIST) (it.body() ? b : h).add(it.id());
        HEAD_IDS = Collections.unmodifiableSet(h);
        BODY_IDS = Collections.unmodifiableSet(b);
    }

    public static Item get(String id) { return id == null ? null : BY_ID.get(id); }

    public static boolean isBody(String id) { return BODY_IDS.contains(id); }

    public static String setOf(String id) {
        Item it = get(id);
        return it == null ? "" : it.set();
    }

    /** Two or more worn items of the same set. */
    public static boolean setPair(String head, String body) { return setBonus(head, body) > 0; }

    /** Extra stars from every judge for whole sets (chef hat + apron...): +0.5 for every set with 2 or more pieces, at most +1. */
    public static double setBonus(String head, String body) {
        Map<String, Integer> n = new HashMap<>();
        for (String id : layers(head)) { String st = setOf(id); if (!st.isEmpty()) n.merge(st, 1, Integer::sum); }
        for (String id : layers(body)) { String st = setOf(id); if (!st.isEmpty()) n.merge(st, 1, Integer::sum); }
        double b = 0;
        for (int c : n.values()) if (c >= 2) b += 0.5;
        return Math.min(1.0, b);
    }

    /** Extra stars from a judge for the NEW items it likes (the old ones are judged by {@link ShowJudges}). At most +1.6. */
    public static double tasteBonus(int judge, String head, String body) {
        int tag = 1 << judge;
        double b = 0;
        for (String id : layers(head)) { Item it = get(id); if (it != null && !it.legacy() && (it.taste() & tag) != 0) b += 0.6; }
        for (String id : layers(body)) { Item it = get(id); if (it != null && !it.legacy() && (it.taste() & tag) != 0) b += 0.4; }
        return Math.min(1.6, b);
    }

    /** How much the clothes fit the theme of the round, from the item tags (the caller caps the sum). */
    public static double themeScore(int theme, String head, String body) {
        return fit(theme, head, 1.0, 0.4) + fit(theme, body, 0.7, 0.3);
    }

    /** The first fitting item of a group counts fully, every other one a little. */
    private static double fit(int theme, String packed, double first, double more) {
        double b = 0;
        boolean any = false;
        for (String id : layers(packed)) {
            Item it = get(id);
            if (it == null || (it.themes() >> theme & 1) == 0) continue;
            b += any ? more : first;
            any = true;
        }
        return b;
    }

    /** True if the item is on sale on this day (month * 100 + day). Not seasonal items are always on sale. */
    public static boolean onSale(Item it, int monthDay) {
        if (it.src() != Src.SEASON) return true;
        return it.from() <= it.to() ? monthDay >= it.from() && monthDay <= it.to() : monthDay >= it.from() || monthDay <= it.to();
    }

    /** What the guest pets of the show may wear: "" first (nothing), then everything that is not a special reward. */
    public static String[] botItems(boolean body) {
        List<String> out = new ArrayList<>();
        out.add("");
        for (Item it : ALL_LIST) {
            if (it.body() != body || it.id().equals("acc_champion")) continue;
            out.add(it.id());
        }
        return out.toArray(new String[0]);
    }
}
