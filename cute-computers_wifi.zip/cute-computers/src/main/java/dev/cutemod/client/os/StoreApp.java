package dev.cutemod.client.os;

import dev.cutemod.ComputerColor;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

/**
 * CuteStore: buy games with coins, watch them install, play them from the library.
 * <p>
 * The look is a modern dark store: a top bar with a search box and the coin balance, a rail on the left (Games, Apps, Library),
 * round cards with a lift on hover, a game of the day on a glowing banner, filter chips, big pill buttons and a banner on the
 * page of every game. Tabs: Games (game of the day + all games), Apps (free and paid desktop apps that can be installed and
 * removed; apps that are not installed are hidden from the Dock and the Start menu) and Library (everything you own).
 */
public class StoreApp extends App {

    @Override
    public boolean needsNet() { return true; }
    // ---------- layout ----------
    private static final int TOP = 22, RAIL = 44, PAD = 8, CX = RAIL + PAD, CWID = W - RAIL - PAD * 2, FILT = 16, VIEW_Y = TOP + FILT;
    private static final int CW = 118, CH = 36, GAP = 4, HERO_H = 58, LROW = 30, LGAP = 4;
    // ---------- colours ----------
    private static final int BG = 0xFF14102A, RAIL_BG = 0xFF0F0B22, BAR_BG = 0xFF19143A, CARD = 0xFF1F1943, CARD_HOVER = 0xFF2B2360, LINE = 0xFF2E2666;
    private static final int WHITE = 0xFFFFFFFF, SOFT = 0xFFD9D3F5, MUTED = 0xFF9A92C6, FAINT = 0xFF5E5790;
    private static final int GREEN = 0xFF3DDC97, GREEN_D = 0xFF1FA874, YELLOW = 0xFFFFD166, RED = 0xFFFF5C7A, ACCENT = 0xFF8B5CF6, ACCENT_2 = 0xFFEC4899;

    private static final String[][] CHIPS = {
            {"all", "arcade", "puzzle", "horror", "other"},
            {"all", "tools", "creative", "pets", "media", "other"}};

    private int tab;                          // 0 games, 1 apps, 2 library (the albums are sold in CuteMarket)
    private String detail;
    private final int[] scrolls = new int[3];
    private final int[] chip = new int[2];
    private String sure;                      // an app waiting for the second click of "Remove"
    private long sureAt;
    private String query = "";
    private boolean searching;
    // reviews page of a game
    private boolean reviews, typing;
    private int revScroll, pick;
    private int descScroll, descMax;          // the long description on the page of a game scrolls
    private String draft = "";

    private record Rev(String author, int stars, String text, boolean mine) {}

    @Override
    public Component title() { return Component.translatable("cutemod.os.store"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.store"); }

    /** Open the page of one game or app (used when you try to start something that is not installed). */
    public void show(String id) { tab = Library.isProgram(id) ? 1 : 0; openDetail(id); }

    private void openDetail(String id) {
        detail = id;
        reviews = false;
        typing = false;
        searching = false;
        revScroll = 0;
        descScroll = 0;
    }

    private void openReviews() {
        reviews = true;
        revScroll = 0;
        typing = false;
        pick = Library.reviewStars(detail);
        draft = Library.reviewText(detail);
    }

    private List<Rev> reviewList(String id) {
        List<Rev> out = new ArrayList<>();
        if (Library.reviewStars(id) > 0) {
            out.add(new Rev(t("cutemod.store.you", Minecraft.getInstance().getUser().getName()), Library.reviewStars(id), Library.reviewText(id), true));
        }
        for (int i = 0; i < Library.reviewCount(id); i++) {
            out.add(new Rev(Library.npcAuthor(id, i), Library.npcStars(id, i), t("cutemod.store.rev." + id + "." + i), false));
        }
        return out;
    }

    // ---------- text helpers ----------
    private static void text(GuiGraphics g, String s, int x, int y, int argb) { Skin.str(g, font(), s, x, y, argb, false); }

    private static void bold(GuiGraphics g, String s, int x, int y, int argb) {
        Skin.str(g, font(), Component.literal(s).withStyle(ChatFormatting.BOLD), x, y, argb, false);
    }

    /** Text that has to stay inside w pixels: smaller instead of cut. */
    private static void textW(GuiGraphics g, String s, int w, int x, int y, int argb) { Skin.box(g, font(), s, x, y, argb, false, w); }

    /** One line in w pixels: smaller when it is too wide (down to half the size, a little more than textW allows), cut only after that. */
    private static void squeeze(GuiGraphics g, String s, int w, int x, int y, int argb) {
        Font f = font();
        int sw = CuteFont.width(f, s);
        if (sw <= w) { CuteFont.draw(g, f, s, x, y, argb, false); return; }
        float k = Math.max(0.5F, w / (float) sw);
        String cut = sw * k > w + 0.5F ? CuteFont.cut(f, s, (int) (w / k)) : s;
        g.pose().pushPose();
        g.pose().translate(x, y + (1F - k) * 4F, 0);
        g.pose().scale(k, k, 1F);
        CuteFont.draw(g, f, cut, 0, 0, argb, false);
        g.pose().popPose();
    }

    private static void boldW(GuiGraphics g, String s, int w, int x, int y, int argb) {
        Skin.box(g, font(), Component.literal(s).withStyle(ChatFormatting.BOLD), x, y, argb, false, w);
    }

    private static void textCW(GuiGraphics g, String s, int w, int x, int y, int argb) { Skin.boxC(g, font(), s, x, y, argb, false, w); }

    /** The end of s that fits into w pixels (the search and review boxes show the last letters you typed), measured in the drawn font. */
    private static String tail(Font f, String s, int w) {
        int from = 0;
        while (from < s.length() && CuteFont.width(f, s.substring(from)) > w) from++;
        return s.substring(from);
    }

    private static String genre(String id) { return t("cutemod.store.genre." + Library.genreOf(id)); }

    private static String rating(String id) { int r = Library.ratingOf(id); return (r / 10) + "." + (r % 10); }

    // ---------- shapes ----------
    private static int lighten(int c, float f) { return mix(c, 0xFFFFFF, f); }

    private static int darken(int c, float f) { return mix(c, 0x000000, f); }

    private static int al(int a, int rgb) { return a << 24 | (rgb & 0xFFFFFF); }

    private static void rr(GuiGraphics g, int x, int y, int w, int h, int r, int argb) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int dy = 0; dy < h; dy++) {
            double m = dy + 0.5, e = m < r ? r - m : m > h - r ? m - (h - r) : 0;
            int inset = e > 0 ? (int) Math.round(r - Math.sqrt(Math.max(0, r * r - e * e))) : 0;
            Skin.fill(g, x + inset, y + dy, x + w - inset, y + dy + 1, argb);
        }
    }

    /** A rounded rectangle with a vertical gradient. */
    private static void rrGrad(GuiGraphics g, int x, int y, int w, int h, int r, int top, int bottom) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int dy = 0; dy < h; dy++) {
            double m = dy + 0.5, e = m < r ? r - m : m > h - r ? m - (h - r) : 0;
            int inset = e > 0 ? (int) Math.round(r - Math.sqrt(Math.max(0, r * r - e * e))) : 0;
            Skin.fill(g, x + inset, y + dy, x + w - inset, y + dy + 1, mix(top, bottom, h <= 1 ? 0 : dy / (float) (h - 1)));
        }
    }

    /** Hides the square corners of a picture that was drawn into a rounded card (bg = the colour behind it). */
    private static void roundMask(GuiGraphics g, int x, int y, int w, int h, int r, int bg) {
        for (int dy = 0; dy < r; dy++) {
            double e = r - (dy + 0.5);
            int inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - e * e)));
            if (inset <= 0) continue;
            Skin.fill(g, x, y + dy, x + inset, y + dy + 1, bg);
            Skin.fill(g, x + w - inset, y + dy, x + w, y + dy + 1, bg);
            Skin.fill(g, x, y + h - 1 - dy, x + inset, y + h - dy, bg);
            Skin.fill(g, x + w - inset, y + h - 1 - dy, x + w, y + h - dy, bg);
        }
    }

    /** A soft drop shadow under a rounded shape. */
    private static void shadow(GuiGraphics g, int x, int y, int w, int h, int r) {
        rr(g, x - 1, y + 2, w + 2, h, r + 1, 0x14000000);
        rr(g, x, y + 1, w, h + 1, r, 0x30000000);
    }

    /** A card: a shadow, a thin border, the body; hover = lifted, with an accent border. */
    private static void card(GuiGraphics g, int x, int y, int w, int h, boolean hover) {
        shadow(g, x, y, w, h, 4);
        rr(g, x, y, w, h, 4, hover ? ACCENT : LINE);
        rr(g, x + 1, y + 1, w - 2, h - 2, 3, hover ? CARD_HOVER : CARD);
        Skin.fill(g, x + 3, y + 1, x + w - 3, y + 2, al(hover ? 0x30 : 0x14, 0xFFFFFF));
    }

    private static void scrollbar(GuiGraphics g, int top, int h, int content, int scroll) {
        if (content <= h) return;
        int th = Math.max(10, h * h / content), max = content - h;
        rr(g, W - 4, top, 2, h, 1, al(0x40, 0x000000));
        rr(g, W - 4, top + (h - th) * scroll / max, 2, th, 1, ACCENT);
    }

    // ---------- icons ----------
    private static void star(GuiGraphics g, int x, int y, boolean filled) { star(g, x, y, filled, YELLOW); }

    private static void star(GuiGraphics g, int x, int y, boolean filled, int on) {
        int c = filled ? on : 0xFF4A4280;
        Skin.fill(g, x + 2, y, x + 3, y + 1, c);
        Skin.fill(g, x + 1, y + 1, x + 4, y + 2, c);
        Skin.fill(g, x, y + 2, x + 5, y + 3, c);
        Skin.fill(g, x + 1, y + 3, x + 4, y + 4, c);
        Skin.fill(g, x + 1, y + 4, x + 2, y + 5, c);
        Skin.fill(g, x + 3, y + 4, x + 4, y + 5, c);
    }

    private static void stars(GuiGraphics g, int x, int y, int n) {
        for (int i = 0; i < 5; i++) star(g, x + i * 7, y, i < n);
    }

    private static void iconGames(GuiGraphics g, int x, int y, int c) {              // a game pad, 14 x 9
        rr(g, x, y + 1, 14, 8, 3, c);
        rr(g, x + 1, y, 5, 3, 1, c); rr(g, x + 8, y, 5, 3, 1, c);
        int hole = al(0xFF, BAR_BG);
        Skin.fill(g, x + 3, y + 4, x + 6, y + 5, hole); Skin.fill(g, x + 4, y + 3, x + 5, y + 6, hole);
        Skin.fill(g, x + 9, y + 4, x + 10, y + 5, hole); Skin.fill(g, x + 11, y + 5, x + 12, y + 6, hole);
    }

    private static void iconApps(GuiGraphics g, int x, int y, int c) {               // four tiles, 12 x 12
        rr(g, x, y, 5, 5, 1, c); rr(g, x + 7, y, 5, 5, 1, c); rr(g, x, y + 7, 5, 5, 1, c); rr(g, x + 7, y + 7, 5, 5, 1, c);
    }

    private static void iconLibrary(GuiGraphics g, int x, int y, int c) {            // an arrow into a tray, 12 x 12
        Skin.fill(g, x + 5, y, x + 7, y + 6, c);
        Skin.fill(g, x + 3, y + 4, x + 9, y + 5, c); Skin.fill(g, x + 4, y + 5, x + 8, y + 6, c); Skin.fill(g, x + 5, y + 6, x + 7, y + 7, c);
        Skin.fill(g, x, y + 8, x + 2, y + 12, c); Skin.fill(g, x + 10, y + 8, x + 12, y + 12, c); Skin.fill(g, x, y + 10, x + 12, y + 12, c);
    }

    private static void iconSearch(GuiGraphics g, int x, int y, int c) {             // a magnifier, 8 x 8
        Skin.fill(g, x + 1, y, x + 4, y + 1, c); Skin.fill(g, x + 1, y + 5, x + 4, y + 6, c);
        Skin.fill(g, x, y + 1, x + 1, y + 5, c); Skin.fill(g, x + 4, y + 1, x + 5, y + 5, c);
        Skin.fill(g, x + 5, y + 5, x + 6, y + 6, c); Skin.fill(g, x + 6, y + 6, x + 8, y + 8, c);
    }

    private static void iconBack(GuiGraphics g, int x, int y, int c) {               // a chevron, 4 x 7
        Skin.fill(g, x + 3, y, x + 4, y + 1, c); Skin.fill(g, x + 2, y + 1, x + 3, y + 2, c); Skin.fill(g, x + 1, y + 2, x + 2, y + 3, c);
        Skin.fill(g, x, y + 3, x + 1, y + 4, c);
        Skin.fill(g, x + 1, y + 4, x + 2, y + 5, c); Skin.fill(g, x + 2, y + 5, x + 3, y + 6, c); Skin.fill(g, x + 3, y + 6, x + 4, y + 7, c);
    }

    private static void iconCheck(GuiGraphics g, int x, int y, int c) {              // a check mark, 7 x 5
        Skin.fill(g, x, y + 2, x + 1, y + 3, c); Skin.fill(g, x + 1, y + 3, x + 2, y + 4, c); Skin.fill(g, x + 2, y + 4, x + 3, y + 5, c);
        Skin.fill(g, x + 3, y + 3, x + 4, y + 4, c); Skin.fill(g, x + 4, y + 2, x + 5, y + 3, c); Skin.fill(g, x + 5, y + 1, x + 6, y + 2, c);
        Skin.fill(g, x + 6, y, x + 7, y + 1, c);
    }

    private static void iconPlay(GuiGraphics g, int x, int y, int c) {               // a play triangle, 5 x 7
        for (int i = 0; i < 4; i++) Skin.fill(g, x + i, y + i, x + 1 + i, y + 7 - i, c);
    }

    // ---------- pieces ----------
    private boolean confirming(String id) { return id.equals(sure) && System.currentTimeMillis() - sureAt < 3000; }

    /** First click arms the button ("Sure?"), the second one within 3 seconds removes the app. */
    private void removeClick(String id) {
        if (confirming(id)) { Library.uninstall(id); sure = null; }
        else { sure = id; sureAt = System.currentTimeMillis(); }
    }

    private void launchProgram(String id) {
        Library.Program p = Library.program(id);
        if (p != null) shell.launch(p.icon());
    }

    private AppAction play(String id) {
        return () -> {
            for (ComputerColor c : ComputerColor.values()) {
                if (c.id.equals(id)) { shell.open(new GameApp(c)); return; }
            }
            shell.open(GameApp.extra(id));
        };
    }

    private interface AppAction { void run(); }

    private void scissor(GuiGraphics g, int y0, int y1) {
        g.enableScissor(shell.absX(), shell.absY() + y0, shell.absX() + W, shell.absY() + y1);
    }

    /** The cover of a game, or the tile of an app (its Dock icon on a colored square); bg = what lies behind it. */
    private static void cover(GuiGraphics g, String id, int x, int y, int size, int bg) {
        Library.Program p = Library.program(id);
        if (p == null) {
            CoverArt.draw(g, id, x, y, size);
            roundMask(g, x, y, size, size, size >= 40 ? 5 : 3, bg);
            return;
        }
        float sc = size / 32f; // the icon brings its own rounded tile
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(sc, sc, 1f);
        Desktop.drawIcon(g, p.icon(), 0, 0, 0xF4A7C3);
        g.pose().popPose();
    }

    /** A button: a rounded pill with a light edge on top. Returns true while the mouse is over it. */
    private static boolean button(GuiGraphics g, int mx, int my, int x, int y, int w, int h, String label, int top, int bottom, int ink, boolean enabled) {
        boolean hover = enabled && in(mx, my, x, y, w, h);
        shadow(g, x, y, w, h, h / 2);
        rrGrad(g, x, y, w, h, h / 2, hover ? lighten(top, 0.18F) : top, hover ? lighten(bottom, 0.12F) : bottom);
        Skin.fill(g, x + h / 3, y + 1, x + w - h / 3, y + 2, al(enabled ? 0x44 : 0x18, 0xFFFFFF));
        textCW(g, label, w - 8, x + 4, y + (h - 8) / 2, enabled ? ink : MUTED);
        return hover;
    }

    private static void pill(GuiGraphics g, int x, int y, int w, int h, int argb) { rr(g, x, y, w, h, h / 2, argb); }

    /** The price of a game with the old price crossed out on sale, "Free", or an install state. Left aligned at x; returns its width. */
    private int statusSmall(GuiGraphics g, String id, int x, int y, int maxW) {
        Font f = font();
        float p = Library.progress(id);
        if (p < 0) {
            if (Library.owned(id)) {                         // an app that was removed: installing it again is free
                String s = t("cutemod.store.owned");
                textW(g, s, maxW, x, y, MUTED);
                return Math.min(maxW, CuteFont.width(f, s));
            }
            int now = Library.priceNow(id), old = Library.priceOf(id);
            if (now == 0) {
                pill(g, x, y - 1, CuteFont.width(f, t("cutemod.store.free")) + 8, 10, al(0x30, GREEN));
                text(g, t("cutemod.store.free"), x + 4, y, GREEN);
                return CuteFont.width(f, t("cutemod.store.free")) + 8;
            }
            boolean afford = Progress.coins() >= now;
            String ns = Integer.toString(now);
            Progress.drawCoin(g, x, y);
            text(g, ns, x + 10, y, afford ? (now != old ? GREEN : WHITE) : RED);
            int w = 10 + CuteFont.width(f, ns);
            if (now != old) {
                String os = Integer.toString(old);
                text(g, os, x + w + 4, y, FAINT);
                Skin.rect(g, x + w + 4, y + 4, CuteFont.width(f, os), 1, FAINT);
                w += 4 + CuteFont.width(f, os);
            }
            return w;
        } else if (p < 1f) {
            int bw = Math.min(40, maxW - 22);
            rr(g, x, y + 2, bw, 5, 2, al(0x60, 0x000000));
            if (p > 0.02f) rrGrad(g, x, y + 2, Math.max(3, (int) (bw * p)), 5, 2, ACCENT_2, ACCENT);
            text(g, (int) (p * 100) + "%", x + bw + 4, y, MUTED);
            return bw + 4 + CuteFont.width(f, "100%");
        } else {
            iconCheck(g, x, y + 1, GREEN);
            String s = t("cutemod.store.installed");
            squeeze(g, s, maxW - 10, x + 10, y, GREEN);
            return 10 + Math.min(maxW - 10, CuteFont.width(f, s));
        }
    }

    // ---------- render ----------
    private static final int[] RAIL_Y = {TOP + 3, TOP + 3 + 35, TOP + 3 + 70};

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Skin.rect(g, 0, 0, W, H, BG);
        if (detail != null) {
            if (reviews) renderReviews(g, mx, my); else renderDetail(g, mx, my);
        } else if (tab == 2) renderLibrary(g, mx, my);
        else renderGrid(g, mx, my);
        renderRail(g, mx, my);
        renderBar(g, mx, my);
    }

    private void renderBar(GuiGraphics g, int mx, int my) {
        Font f = font();
        Skin.rect(g, 0, 0, W, TOP, BAR_BG);
        Skin.rect(g, 0, TOP - 1, W, 1, LINE);
        rrGrad(g, 6, 4, 14, 14, 4, ACCENT_2, ACCENT);                               // the logo: a little bag with a star
        Skin.fill(g, 9, 6, 17, 7, al(0xAA, 0xFFFFFF));
        star(g, 10, 9, true, WHITE);
        bold(g, t("cutemod.os.store"), 25, 7, WHITE);
        // the search box
        int sx = 92, sw = 124;
        boolean over = in(mx, my, sx, 4, sw, 14);
        rr(g, sx - 1, 3, sw + 2, 16, 8, searching ? ACCENT : LINE);
        rr(g, sx, 4, sw, 14, 7, searching ? 0xFF2A2260 : (over ? 0xFF241D50 : 0xFF1B1640));
        iconSearch(g, sx + 6, 7, searching ? WHITE : MUTED);
        String shown = query.isEmpty() && !searching ? t("cutemod.store.search") : query + (searching && (System.currentTimeMillis() / 400) % 2 == 0 ? "_" : "");
        Skin.str(g, f, tail(f, shown, sw - 24), sx + 18, 7, query.isEmpty() && !searching ? FAINT : WHITE, false);
        // the coins
        String c = Integer.toString(Progress.coins());
        int cw = CuteFont.width(f, c) + 20;
        rr(g, W - cw - 6, 4, cw, 14, 7, al(0x30, YELLOW));
        Progress.drawCoin(g, W - cw - 1, 7);
        text(g, c, W - cw + 10, 7, YELLOW);
    }

    private void renderRail(GuiGraphics g, int mx, int my) {
        Skin.rect(g, 0, TOP, RAIL, H - TOP, RAIL_BG);
        Skin.rect(g, RAIL - 1, TOP, 1, H - TOP, LINE);
        float railK = Skin.group(font(), RAIL - 3, 0.6F, t("cutemod.store.tab.0"), t("cutemod.store.tab.1"), t("cutemod.store.tab.2"));   // the labels share one size
        for (int i = 0; i < 3; i++) {
            int y = RAIL_Y[i];
            boolean sel = tab == i, hover = in(mx, my, 3, y, RAIL - 7, 34);
            if (sel) {
                rr(g, 4, y, RAIL - 9, 34, 5, al(0x30, ACCENT));
                rrGrad(g, 0, y + 8, 3, 18, 1, ACCENT_2, ACCENT);
            } else if (hover) rr(g, 4, y, RAIL - 9, 34, 5, al(0x18, 0xFFFFFF));
            int c = sel ? WHITE : (hover ? SOFT : MUTED);
            int cx = RAIL / 2 - 1;
            if (i == 0) iconGames(g, cx - 6, y + 6, c);
            else if (i == 1) iconApps(g, cx - 5, y + 5, c);
            else iconLibrary(g, cx - 5, y + 5, c);
            Skin.boxK(g, font(), t("cutemod.store.tab." + i), 1, y + 22, c, false, RAIL - 3, true, railK);   // nearly the whole width of the rail
            if (i == 2) {                                                                  // a badge: how many things are installing
                int n = 0;
                for (String id : ownedIds()) if (Library.progress(id) < 1f) n++;
                if (n > 0) { rr(g, cx + 5, y + 2, 9, 9, 4, RED); textCW(g, Integer.toString(n), 9, cx + 5, y + 3, WHITE); }
            }
        }
    }

    // ---------- the lists ----------
    private boolean heroShown() { return tab == 0 && chip[0] == 0 && query.trim().isEmpty(); }

    private boolean chipOk(String id, int ci) {
        String key = CHIPS[tab][ci];
        if (key.equals("all")) return true;
        String gen = Library.genreOf(id);
        if (key.equals("other")) {
            for (int k = 1; k < CHIPS[tab].length - 1; k++) if (CHIPS[tab][k].equals(gen)) return false;
            return true;
        }
        return key.equals(gen);
    }

    private boolean queryOk(String id) {
        String q = query.trim().toLowerCase();
        return q.isEmpty() || Library.name(id).toLowerCase().contains(q);
    }

    /** The games or the apps shown now (the filter chip and the search box applied). */
    private List<String> gridIds() {
        List<String> out = new ArrayList<>();
        if (tab == 0) { for (Library.Game gm : Library.GAMES) if (queryOk(gm.id()) && chipOk(gm.id(), chip[0])) out.add(gm.id()); }
        else { for (Library.Program p : Library.PROGRAMS) if (!Library.placeOnly(p.id()) && queryOk(p.id()) && chipOk(p.id(), chip[1])) out.add(p.id()); }
        return out;
    }

    private int gridTop() { return heroShown() ? HERO_H + 8 : 4; }

    private int gridContent(int n) { return gridTop() + (n + 1) / 2 * (CH + GAP) + 4; }

    private int gridMax() { return Math.max(0, gridContent(gridIds().size()) - (H - VIEW_Y)); }

    private int itemX(int i) { return CX + (i % 2) * (CW + GAP); }

    private int itemY(int i) { return VIEW_Y + gridTop() + i / 2 * (CH + GAP) - scrolls[tab]; }

    private void renderGrid(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<String> ids = gridIds();
        scrolls[tab] = Math.max(0, Math.min(gridMax(), scrolls[tab]));
        scissor(g, VIEW_Y, H);
        if (heroShown()) renderHero(g, mx, my, VIEW_Y + 4 - scrolls[tab]);
        if (ids.isEmpty()) {
            int cy = VIEW_Y + 44;
            iconSearch(g, CX + CWID / 2 - 4, cy - 14, FAINT);
            textCW(g, t("cutemod.store.nothing"), CWID, CX, cy, MUTED);
        }
        java.util.List<Component> titles = new ArrayList<>();             // the names and genres of all cards share one size
        java.util.List<String> genres = new ArrayList<>();
        for (String gid : ids) { titles.add(Component.literal(Library.name(gid)).withStyle(ChatFormatting.BOLD)); genres.add(genre(gid)); }
        float titleK = Skin.group(f, CW - 40, 0.7F, titles), genreK = Skin.group(f, CW - 40, 0.7F, genres.toArray(new String[0]));
        for (int i = 0; i < ids.size(); i++) {
            int x = itemX(i), y = itemY(i);
            if (y + CH < VIEW_Y || y > H) continue;
            String id = ids.get(i);
            boolean hover = in(mx, my, x, Math.max(VIEW_Y, y), CW, CH) && my >= VIEW_Y;
            int ly = hover ? y - 1 : y;
            card(g, x, ly, CW, CH, hover);
            cover(g, id, x + 4, ly + 4, 28, hover ? CARD_HOVER : CARD);
            Skin.boxK(g, f, Component.literal(Library.name(id)).withStyle(ChatFormatting.BOLD), x + 37, ly + 4, WHITE, false, CW - 40, false, titleK);
            Skin.boxK(g, f, genre(id), x + 37, ly + 14, MUTED, false, CW - 40, false, genreK);
            String rt = rating(id);
            int rw = CuteFont.width(f, rt);
            statusSmall(g, id, x + 37, ly + 24, CW - 54 - rw);      // up to the star of the rating
            star(g, x + CW - 8 - rw - 7, ly + 25, true);
            text(g, rt, x + CW - 6 - rw, ly + 24, SOFT);
        }
        g.disableScissor();
        scrollbar(g, VIEW_Y, H - VIEW_Y, gridContent(ids.size()), scrolls[tab]);
        renderChips(g, mx, my);
    }

    private static int chipW(String key, int n) {
        return Math.min(CWID / n, CuteFont.width(font(), t(key.equals("all") ? "cutemod.store.chip.all" : key.equals("other") ? "cutemod.store.chip.other" : "cutemod.store.genre." + key)) + 12);
    }

    private static String chipName(String key) {
        return t(key.equals("all") ? "cutemod.store.chip.all" : key.equals("other") ? "cutemod.store.chip.other" : "cutemod.store.genre." + key);
    }

    private int chipX(int i) {
        int x = CX;
        for (int k = 0; k < i; k++) x += chipW(CHIPS[tab][k], CHIPS[tab].length) + 3;
        return x;
    }

    /** The row of filter chips under the top bar (it stays in place while the list scrolls). */
    private void renderChips(GuiGraphics g, int mx, int my) {
        Skin.rect(g, RAIL, TOP, W - RAIL, FILT, BG);
        Skin.rect(g, RAIL, VIEW_Y - 1, W - RAIL, 1, al(0x60, 0x000000));
        String[] keys = CHIPS[tab];
        float chipK = 1F;                                                  // all chips share one text size
        for (int i = 0; i < keys.length; i++) {
            int sw = CuteFont.width(font(), chipName(keys[i]));
            int avail = chipW(keys[i], keys.length) - 4;
            if (sw > avail) chipK = Math.min(chipK, avail / (float) sw);
        }
        chipK = Math.max(0.6F, chipK);
        for (int i = 0; i < keys.length; i++) {
            int x = chipX(i), w = chipW(keys[i], keys.length);
            boolean sel = chip[tab] == i, hover = in(mx, my, x, TOP + 2, w, 12);
            if (sel) rrGrad(g, x, TOP + 2, w, 12, 6, ACCENT, darken(ACCENT, 0.2F));
            else rr(g, x, TOP + 2, w, 12, 6, hover ? 0xFF2B2360 : 0xFF1F1943);
            Skin.boxK(g, font(), chipName(keys[i]), x + 2, TOP + 4, sel ? WHITE : (hover ? WHITE : MUTED), false, w - 4, true, chipK);
        }
    }

    /** The game of the day: a glowing banner with the cover, the sale and a button. */
    private void renderHero(GuiGraphics g, int mx, int my, int y) {
        Font f = font();
        String deal = Library.dealId();
        Library.Game dg = Library.game(deal);
        int x = CX, w = CWID;
        boolean hover = in(mx, my, x, Math.max(VIEW_Y, y), w, HERO_H) && my >= VIEW_Y;
        int tint = mix(0xFF000000 | dg.rgb(), 0x3B2A7A, 0.55F);
        shadow(g, x, y, w, HERO_H, 6);
        rr(g, x, y, w, HERO_H, 6, hover ? lighten(ACCENT, 0.2F) : al(0xFF, mix(tint, 0xFFFFFF, 0.15F)));
        rrGrad(g, x + 1, y + 1, w - 2, HERO_H - 2, 5, darken(tint, 0.1F), 0xFF1A1440);
        int tt = (int) (System.currentTimeMillis() / 20 % 400);                           // a sheen sweeps across now and then
        for (int row = 3; row < HERO_H - 3; row++) {
            int sx = x + tt * 2 - 120 + row / 2;
            int a = Math.max(x + 4, sx), b = Math.min(x + w - 4, sx + 12);
            if (b > a) Skin.fill(g, a, y + row, b, y + row + 1, al(0x10, 0xFFFFFF));
        }
        shadow(g, x + 8, y + 8, 42, 42, 5);
        cover(g, deal, x + 8, y + 8, 42, darken(tint, 0.1F));
        int tx = x + 58;
        pill(g, tx, y + 8, CuteFont.width(f, t("cutemod.store.deal")) + 8, 10, al(0x40, YELLOW));
        text(g, t("cutemod.store.deal"), tx + 4, y + 9, YELLOW);
        boldW(g, Library.name(deal), 104, tx, y + 21, WHITE);
        star(g, tx, y + 34, true);
        textW(g, rating(deal) + "  -  " + genre(deal), 96, tx + 8, y + 33, SOFT);
        rr(g, x + w - 40, y + 7, 32, 12, 6, RED);
        textCW(g, "-" + Library.dealPercent() + "%", 32, x + w - 40, y + 9, WHITE);
        int bx = x + w - 76, by = y + 38;                                                  // the price button
        float p = Library.progress(deal);
        if (p < 0) {
            int now = Library.priceNow(deal), old = Library.priceOf(deal);
            boolean afford = Progress.coins() >= now;
            rr(g, bx, by, 68, 16, 8, al(0x55, 0x000000));
            Progress.drawCoin(g, bx + 5, by + 4);
            text(g, Integer.toString(now), bx + 16, by + 4, afford ? GREEN : RED);
            String os = Integer.toString(old);
            int ox = bx + 68 - 6 - CuteFont.width(f, os);
            text(g, os, ox, by + 4, FAINT);
            Skin.rect(g, ox, by + 8, CuteFont.width(f, os), 1, FAINT);
        } else {
            rr(g, bx, by, 68, 16, 8, al(0x55, 0x000000));
            statusSmall(g, deal, bx + 8, by + 4, 56);
        }
    }

    // ---------- the library ----------
    /** Everything that is owned and installed (or installing): games first, then apps. */
    private List<String> ownedIds() {
        List<String> out = new ArrayList<>();
        for (Library.Game gm : Library.GAMES) if (Library.owned(gm.id())) out.add(gm.id());
        for (Library.Program p : Library.PROGRAMS) if (!Library.placeOnly(p.id()) && Library.progress(p.id()) >= 0) out.add(p.id());
        return out;
    }

    private List<String> libraryIds() {
        List<String> out = new ArrayList<>();
        for (String id : ownedIds()) if (queryOk(id)) out.add(id);
        return out;
    }

    private int libContent(int n) { return 8 + n * (LROW + LGAP); }

    private int libMax() { return Math.max(0, libContent(libraryIds().size()) - (H - TOP)); }

    private int libY(int i) { return TOP + 8 + i * (LROW + LGAP) - scrolls[2]; }

    private void renderLibrary(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<String> ids = libraryIds();
        if (ids.isEmpty()) {
            iconLibrary(g, CX + CWID / 2 - 5, 66, FAINT);
            List<FormattedCharSequence> lines = f.split(FormattedText.of(t(ownedIds().isEmpty() ? "cutemod.store.empty" : "cutemod.store.nothing")), CWID - 20);
            for (int i = 0; i < lines.size(); i++) {
                FormattedCharSequence s = lines.get(i);
                Skin.str(g, f, s, CX + (CWID - f.width(s)) / 2, 86 + i * 10, MUTED, false);
            }
            return;
        }
        scrolls[2] = Math.max(0, Math.min(libMax(), scrolls[2]));
        scissor(g, TOP, H);
        for (int i = 0; i < ids.size(); i++) {
            int y = libY(i);
            if (y + LROW < TOP || y > H) continue;
            String id = ids.get(i);
            boolean prog = Library.isProgram(id), hover = in(mx, my, CX, y, CWID, LROW) && my >= TOP;
            card(g, CX, hover ? y - 1 : y, CWID, LROW, hover);
            y = hover ? y - 1 : y;
            cover(g, id, CX + 4, y + 3, 24, hover ? CARD_HOVER : CARD);
            boldW(g, Library.name(id), 100, CX + 33, y + 5, WHITE);
            float p = Library.progress(id);
            if (p >= 1f) {
                String sub = prog ? genre(id) + "  -  " + Library.sizeText(id)
                        : t("cutemod.store.played", Library.playTime(id)) + "   " + t("cutemod.store.best", Library.best(id));
                textW(g, sub, 100, CX + 33, y + 16, MUTED);
                int bx = CX + CWID - 56;
                button(g, mx, my, bx, y + 7, 50, 16, t(prog ? "cutemod.store.open" : "cutemod.store.play"), 0xFF4ADE9A, GREEN_D, 0xFF08281B, true);
                {                                                                          // remove (two clicks), games too: it frees the disk
                    boolean armed = confirming(id);
                    button(g, mx, my, bx - 52, y + 7, 48, 16, t(armed ? "cutemod.store.confirm" : "cutemod.store.remove"),
                            armed ? 0xFFFF6A86 : 0xFF3A3070, armed ? 0xFFD13A5C : 0xFF2A2258, WHITE, true);
                }
            } else {
                text(g, t("cutemod.store.installing", (int) (p * 100)), CX + 33, y + 16, MUTED);
                int bw = 84, bx = CX + CWID - bw - 8;
                rr(g, bx, y + 12, bw, 6, 3, al(0x60, 0x000000));
                if (p > 0.02f) rrGrad(g, bx, y + 12, Math.max(4, (int) (bw * p)), 6, 3, ACCENT_2, ACCENT);
                int sh = (int) (System.currentTimeMillis() / 60 % (bw + 10));            // a shimmer runs along the bar
                int a = bx + Math.max(0, sh - 10), b = Math.min(bx + (int) (bw * p), bx + sh);
                if (b > a) Skin.fill(g, a, y + 13, b, y + 15, al(0x40, 0xFFFFFF));
            }
        }
        g.disableScissor();
        scrollbar(g, TOP, H - TOP, libContent(ids.size()), scrolls[2]);
    }

    // ---------- the page of a game or an app ----------
    private static final int BAR_Y = H - 34;

    private void renderDetail(GuiGraphics g, int mx, int my) {
        Font f = font();
        String id = detail;
        boolean prog = Library.isProgram(id);
        int rgb = 0xFF000000 | (prog ? Library.program(id).rgb() : Library.game(id).rgb());
        int tint = mix(rgb, 0x3B2A7A, 0.5F);
        // the banner
        Skin.grad(g, RAIL, TOP, W, TOP + 44, darken(tint, 0.05F), BG);
        for (int k = 3; k >= 1; k--) Skin.disc(g, W - 40, TOP + 8, 8 + k * 9, al(0x0C, mix(tint, 0xFFFFFF, 0.5F)));
        boolean backHover = in(mx, my, CX - 2, TOP + 4, 40, 13);
        rr(g, CX - 2, TOP + 4, 40, 13, 6, backHover ? al(0x70, 0x000000) : al(0x48, 0x000000));
        iconBack(g, CX + 3, TOP + 7, WHITE);
        textCW(g, t("cutemod.store.back").replace("<", "").trim(), 28, CX + 9, TOP + 6, WHITE);
        String rb = t("cutemod.store.reviews", Library.reviewCount(id) + (Library.reviewStars(id) > 0 ? 1 : 0));
        int rbw = Math.min(96, CuteFont.width(f, rb) + 14);
        boolean rbHover = in(mx, my, W - rbw - 8, TOP + 4, rbw, 13);
        rr(g, W - rbw - 8, TOP + 4, rbw, 13, 6, rbHover ? al(0x70, 0x000000) : al(0x48, 0x000000));
        textCW(g, rb, rbw - 6, W - rbw - 5, TOP + 6, WHITE);
        // the cover
        int cvx = CX, cvy = TOP + 22;
        shadow(g, cvx - 2, cvy - 2, 54, 54, 7);
        rr(g, cvx - 2, cvy - 2, 54, 54, 7, BG);
        cover(g, id, cvx, cvy, 50, BG);
        // the title and the facts
        int tx = cvx + 62;
        boldW(g, Library.name(id), W - tx - 8, tx, TOP + 29, WHITE);
        int cxp = tx;
        String gn = genre(id);
        int gw = CuteFont.width(f, gn) + 10;
        pill(g, cxp, TOP + 42, gw, 11, al(0x40, ACCENT)); textCW(g, gn, gw, cxp, TOP + 44, SOFT);
        cxp += gw + 4;
        String sz = Library.sizeText(id);
        int zw = CuteFont.width(f, sz) + 10;
        pill(g, cxp, TOP + 42, zw, 11, al(0x30, 0xFFFFFF)); textCW(g, sz, zw, cxp, TOP + 44, SOFT);
        int r5 = Math.round(Library.ratingOf(id) / 10f);
        stars(g, tx, TOP + 58, r5);
        text(g, rating(id), tx + 38, TOP + 57, SOFT);
        // the description: all of it, scrolled (it can be much longer than the room under the title)
        int dTop = TOP + 74, dBot = BAR_Y - 2;
        List<FormattedCharSequence> dl = f.split(CuteFont.styled(t("cutemod.store.blurb." + id)), CWID - 8);
        int dls = CuteFont.size() == CuteFont.SMALL ? 9 : CuteFont.size() == CuteFont.LARGE ? 12 : 10, dh = dl.size() * dls + 4;
        descMax = Math.max(0, dh - (dBot - dTop));
        descScroll = Math.max(0, Math.min(descMax, descScroll));
        scissor(g, dTop, dBot);
        for (int i = 0; i < dl.size(); i++) {
            int yy = dTop + 2 + i * dls - descScroll;
            if (yy + dls < dTop || yy > dBot) continue;
            CuteFont.draw(g, f, dl.get(i), CX, yy, SOFT, false);
        }
        g.disableScissor();
        scrollbar(g, dTop, dBot - dTop, dh, descScroll);
        // the bar with the price and the buttons
        rr(g, CX - 2, BAR_Y, CWID + 4, 28, 8, al(0xFF, 0x1A1540));
        rr(g, CX - 2, BAR_Y, CWID + 4, 28, 8, al(0x30, 0xFFFFFF));
        rr(g, CX - 1, BAR_Y + 1, CWID + 2, 26, 7, 0xFF1A1540);
        float p = Library.progress(id);
        int by = BAR_Y + 6;
        if (p < 0) {
            boolean again = Library.owned(id);                 // an app that was removed earlier
            int now = Library.priceNow(id), old = Library.priceOf(id);
            boolean room = Library.hasRoom(id);
            boolean afford = (again || Progress.coins() >= now) && room;
            int px = CX + 6;
            if (again) {
                text(g, t("cutemod.store.owned"), px, BAR_Y + 10, MUTED);
            } else if (now == 0) {
                pill(g, px, BAR_Y + 8, CuteFont.width(f, t("cutemod.store.free")) + 10, 12, al(0x30, GREEN));
                text(g, t("cutemod.store.free"), px + 5, BAR_Y + 10, GREEN);
            } else {
                Progress.drawCoin(g, px, BAR_Y + 10);
                String ns = Integer.toString(now);
                text(g, ns, px + 11, BAR_Y + 10, afford ? WHITE : RED);
                int cx = px + 11 + CuteFont.width(f, ns) + 5;
                if (now != old) {
                    String os = Integer.toString(old);
                    text(g, os, cx, BAR_Y + 10, FAINT);
                    Skin.rect(g, cx, BAR_Y + 14, CuteFont.width(f, os), 1, FAINT);
                    rr(g, cx + CuteFont.width(f, os) + 5, BAR_Y + 8, 28, 12, 6, RED);
                    textCW(g, "-" + Library.dealPercent() + "%", 28, cx + CuteFont.width(f, os) + 5, BAR_Y + 10, WHITE);
                }
            }
            String s = !room ? t("cutemod.store.nospace") : !afford ? t("cutemod.store.poor") : (again || now == 0) ? t("cutemod.store.install") : t("cutemod.store.buy");
            button(g, mx, my, CX + CWID - 112, by, 106, 16, s, afford ? 0xFF4ADE9A : 0xFF3A3070, afford ? GREEN_D : 0xFF2A2258, afford ? 0xFF08281B : MUTED, afford);
        } else if (p < 1f) {
            text(g, t("cutemod.store.installing", (int) (p * 100)), CX + 8, BAR_Y + 4, WHITE);
            int bw = 150;
            rr(g, CX + 8, BAR_Y + 15, bw, 7, 3, al(0x70, 0x000000));
            if (p > 0.02f) rrGrad(g, CX + 8, BAR_Y + 15, Math.max(5, (int) (bw * p)), 7, 3, ACCENT_2, ACCENT);
            int sh = (int) (System.currentTimeMillis() / 50 % (bw + 14));
            int a = CX + 8 + Math.max(0, sh - 14), b = Math.min(CX + 8 + (int) (bw * p), CX + 8 + sh);
            if (b > a) Skin.fill(g, a, BAR_Y + 16, b, BAR_Y + 19, al(0x45, 0xFFFFFF));
            String eta = t("cutemod.store.eta", Library.secondsLeft(id));
            text(g, eta, CX + CWID - 8 - CuteFont.width(f, eta), BAR_Y + 10, MUTED);
        } else {
            int bx = CX + CWID - 106;
            boolean armed = confirming(id);                                                  // remove (two clicks), apps and games
            button(g, mx, my, bx - 62, by, 58, 16, t(armed ? "cutemod.store.confirm" : "cutemod.store.remove"),
                    armed ? 0xFFFF6A86 : 0xFF3A3070, armed ? 0xFFD13A5C : 0xFF2A2258, WHITE, true);
            if (!prog) {
                textW(g, t("cutemod.store.played", Library.playTime(id)), CWID - 176, CX + 8, BAR_Y + 5, MUTED);   // the room left of the Remove button
                textW(g, t("cutemod.store.best", Library.best(id)), CWID - 176, CX + 8, BAR_Y + 15, MUTED);
            }
            button(g, mx, my, bx, by, 106, 16, t(prog ? "cutemod.store.open" : "cutemod.store.play"), 0xFF4ADE9A, GREEN_D, 0xFF08281B, true);
            iconPlay(g, bx + 8, by + 5, 0xFF08281B);
        }
    }

    // ---------- the reviews ----------
    private static final int REV_TOP = TOP + 24, REV_BOTTOM = H - 36;

    private int revHeight(Rev r) {
        int lines = Math.max(1, Math.min(2, font().split(CuteFont.styled(r.text()), CWID - 36).size()));
        return 14 + lines * 9 + 8;
    }

    private int revContent(List<Rev> list) {
        int h = 0;
        for (Rev r : list) h += revHeight(r) + 3;
        return h;
    }

    private static int avatarColor(String name) {
        int[] cols = {0xFF8B5CF6, 0xFFEC4899, 0xFF38BDF8, 0xFF34D399, 0xFFF59E0B, 0xFFFB7185};
        return cols[Math.floorMod(name.hashCode(), cols.length)];
    }

    private void renderReviews(GuiGraphics g, int mx, int my) {
        Font f = font();
        String id = detail;
        boolean backHover = in(mx, my, CX - 2, TOP + 4, 40, 13);
        rr(g, CX - 2, TOP + 4, 40, 13, 6, backHover ? 0xFF3A3070 : 0xFF2A2258);
        iconBack(g, CX + 3, TOP + 7, WHITE);
        textCW(g, t("cutemod.store.back").replace("<", "").trim(), 28, CX + 9, TOP + 6, WHITE);
        List<Rev> list = reviewList(id);
        boldW(g, Library.name(id), 110, CX + 46, TOP + 6, WHITE);
        String sum = rating(id) + " (" + list.size() + ")";
        text(g, sum, W - 8 - CuteFont.width(f, sum), TOP + 6, MUTED);
        star(g, W - 16 - CuteFont.width(f, sum), TOP + 7, true);

        scissor(g, REV_TOP, REV_BOTTOM);
        int y = REV_TOP - revScroll;
        for (Rev r : list) {
            int h = revHeight(r);
            if (y + h >= REV_TOP && y <= REV_BOTTOM) {
                rr(g, CX, y, CWID, h, 5, r.mine() ? ACCENT : LINE);
                rr(g, CX + 1, y + 1, CWID - 2, h - 2, 4, r.mine() ? 0xFF2D2466 : CARD);
                Skin.disc(g, CX + 12, y + 12, 7, avatarColor(r.author()));
                String ini = r.author().isEmpty() ? "?" : r.author().substring(0, 1).toUpperCase();
                textCW(g, ini, 14, CX + 5, y + 8, WHITE);
                boldW(g, r.author(), 120, CX + 24, y + 4, r.mine() ? YELLOW : WHITE);
                stars(g, CX + CWID - 40, y + 5, r.stars());
                Skin.para(g, f, r.text(), CX + 24, y + 15, CWID - 32, 18, 9, SOFT, false);
            }
            y += h + 3;
        }
        g.disableScissor();
        int max = Math.max(0, revContent(list) - (REV_BOTTOM - REV_TOP));
        revScroll = Math.min(revScroll, max);
        scrollbar(g, REV_TOP, REV_BOTTOM - REV_TOP, revContent(list), revScroll);

        // write your own
        rr(g, CX - 2, REV_BOTTOM + 2, CWID + 4, H - REV_BOTTOM - 4, 8, 0xFF1A1540);
        if (!Library.owned(id)) {
            textCW(g, t("cutemod.store.rev_locked"), CWID, CX, REV_BOTTOM + 14, MUTED);
            return;
        }
        textW(g, t("cutemod.store.your_rating"), 60, CX + 4, REV_BOTTOM + 7, SOFT);
        for (int k = 0; k < 5; k++) star(g, CX + 66 + k * 12, REV_BOTTOM + 7, k < pick);
        Skin.para(g, f, t("cutemod.store.rev_hint"), CX + 132, REV_BOTTOM + 3, 104, 14, 7, FAINT, false);   // two small lines instead of one cut line
        rr(g, CX + 2, REV_BOTTOM + 17, 168, 13, 6, typing ? ACCENT : LINE);
        rr(g, CX + 3, REV_BOTTOM + 18, 166, 11, 5, typing ? 0xFF2A2260 : 0xFF1B1640);
        String shown = draft.isEmpty() && !typing ? t("cutemod.store.write_hint") : draft + (typing && (System.currentTimeMillis() / 400) % 2 == 0 ? "_" : "");
        Skin.str(g, f, tail(f, shown, 156), CX + 8, REV_BOTTOM + 20, draft.isEmpty() && !typing ? FAINT : WHITE, false);
        boolean can = pick > 0;
        String post = t(Library.reviewStars(id) > 0 ? "cutemod.store.update" : "cutemod.store.post");
        button(g, mx, my, CX + 176, REV_BOTTOM + 16, 58, 14, post, can ? 0xFF4ADE9A : 0xFF3A3070, can ? GREEN_D : 0xFF2A2258, can ? 0xFF08281B : MUTED, can);
    }

    private void postReview() {
        if (pick <= 0 || detail == null || !Library.owned(detail)) return;
        boolean first = Library.setReview(detail, pick, draft.trim());
        Progress.toast("cutemod.toast.review_posted");
        if (first) Progress.earn(3);
        typing = false;
        revScroll = 0;
    }

    // ---------- input ----------
    private void switchTab(int i) {
        tab = i;
        detail = null;
        reviews = false;
        typing = false;
        searching = false;
        sure = null;
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (y < TOP) {                                                     // the top bar
            if (in(x, y, 92, 4, 124, 14) && detail == null) { searching = true; typing = false; return true; }
            if (x < 90) { switchTab(0); query = ""; return true; }
            searching = false;
            return true;
        }
        if (x < RAIL) {                                                    // the rail
            for (int i = 0; i < 3; i++) if (in(x, y, 3, RAIL_Y[i], RAIL - 7, 34)) { switchTab(i); return true; }
            return true;
        }
        if (detail != null && reviews) {
            if (in(x, y, CX - 2, TOP + 4, 40, 13)) { reviews = false; typing = false; return true; }
            if (Library.owned(detail)) {
                for (int k = 0; k < 5; k++) if (in(x, y, CX + 66 + k * 12 - 1, REV_BOTTOM + 5, 12, 11)) { pick = k + 1; typing = false; return true; }
                if (in(x, y, CX + 2, REV_BOTTOM + 17, 168, 13)) { typing = true; return true; }
                if (in(x, y, CX + 176, REV_BOTTOM + 16, 58, 14)) { postReview(); return true; }
            }
            typing = false;
            return true;
        }
        if (detail != null) {
            String id = detail;
            if (in(x, y, CX - 2, TOP + 4, 40, 13)) { detail = null; return true; }
            String rb = t("cutemod.store.reviews", Library.reviewCount(id) + (Library.reviewStars(id) > 0 ? 1 : 0));
            int rbw = Math.min(96, CuteFont.width(font(), rb) + 14);
            if (in(x, y, W - rbw - 8, TOP + 4, rbw, 13)) { openReviews(); return true; }
            boolean prog = Library.isProgram(id);
            float p = Library.progress(id);
            int by = BAR_Y + 6;
            if (p < 0 && in(x, y, CX + CWID - 112, by, 106, 16)) {
                if (!Library.hasRoom(id)) return true;                     // C: is full: remove something first
                if (Library.owned(id)) Library.install(id); else Library.buy(id);
                return true;
            }
            if (p >= 1f && in(x, y, CX + CWID - 106, by, 106, 16)) {
                if (prog) launchProgram(id); else play(id).run();
                return true;
            }
            if (p >= 1f && in(x, y, CX + CWID - 168, by, 58, 16)) { removeClick(id); return true; }
            return true;
        }
        searching = false;
        if (tab == 2) {
            List<String> ids = libraryIds();
            for (int i = 0; i < ids.size(); i++) {
                int ry = libY(i);
                if (y < ry || y >= ry + LROW || x < CX || x >= CX + CWID) continue;
                String id = ids.get(i);
                boolean prog = Library.isProgram(id);
                int bx = CX + CWID - 56;
                if (Library.installed(id) && in(x, y, bx, ry + 7, 50, 16)) {
                    if (prog) launchProgram(id); else play(id).run();
                } else if (Library.installed(id) && in(x, y, bx - 52, ry + 7, 48, 16)) {
                    removeClick(id);
                } else {
                    openDetail(id);
                }
                return true;
            }
            return true;
        }
        if (y < VIEW_Y) {                                                  // the filter chips
            String[] keys = CHIPS[tab];
            for (int i = 0; i < keys.length; i++) {
                if (in(x, y, chipX(i), TOP + 2, chipW(keys[i], keys.length), 12)) { chip[tab] = i; scrolls[tab] = 0; return true; }
            }
            return true;
        }
        if (heroShown()) {
            int hy = VIEW_Y + 4 - scrolls[tab];
            if (in(x, y, CX, hy, CWID, HERO_H)) { openDetail(Library.dealId()); return true; }
        }
        List<String> ids = gridIds();
        for (int i = 0; i < ids.size(); i++) {
            if (in(x, y, itemX(i), itemY(i), CW, CH)) { openDetail(ids.get(i)); return true; }
        }
        return true;
    }

    @Override
    public boolean scroll(double amount) {
        int dir = (int) Math.signum(amount);
        if (detail != null && reviews) {
            int max = Math.max(0, revContent(reviewList(detail)) - (REV_BOTTOM - REV_TOP));
            revScroll = Math.max(0, Math.min(max, revScroll - dir * 14));
            return true;
        }
        if (detail != null) {                                  // the description of a game
            descScroll = Math.max(0, Math.min(descMax, descScroll - dir * 12));
            return true;
        }
        if (tab == 2) scrolls[2] = Math.max(0, Math.min(libMax(), scrolls[2] - dir * (LROW + LGAP)));
        else scrolls[tab] = Math.max(0, Math.min(gridMax(), scrolls[tab] - dir * (CH + GAP) * 2));
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (searching) {
            if (keyCode == 259) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); scrolls[tab] = 0; return true; }   // Backspace
            if (keyCode == 257 || keyCode == 335) { searching = false; return true; }                                                    // Enter
            return false;
        }
        if (typing) {
            if (keyCode == 259) { if (!draft.isEmpty()) draft = draft.substring(0, draft.length() - 1); return true; }   // Backspace
            if (keyCode == 257 || keyCode == 335) { postReview(); return true; }                                          // Enter
            return false;
        }
        if (keyCode == 259 && detail != null) {                                  // Backspace: one page back
            if (reviews) reviews = false; else detail = null;
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char c) {
        if (searching) {
            if (c < 32 || c == 127 || query.length() >= 24) return false;
            query += c;
            scrolls[tab] = 0;
            return true;
        }
        if (!typing || c < 32 || c == 127 || draft.length() >= 70) return false;
        draft += c;
        return true;
    }
}
