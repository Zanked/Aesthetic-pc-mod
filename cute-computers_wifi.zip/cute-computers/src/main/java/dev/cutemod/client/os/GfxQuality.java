package dev.cutemod.client.os;

import dev.cutemod.data.PcHardware;

/**
 * How nice the games look on THIS computer: it follows the video card (see {@link PcHardware#gpuLevel}). The levels are
 * 0 low, 1 medium, 2 high and 3 ultra. A weak card gets a plain backdrop, no soft shadows, glows or vignettes and a grainy
 * old-screen look; a strong one gets everything (and the ultra ones a little extra shine). It costs the weak PC less to draw too.
 * Installing a better video card changes it at once.
 */
public final class GfxQuality {
    private GfxQuality() {}

    public static final int LOW = 0, MEDIUM = 1, HIGH = 2, ULTRA = 3;

    private static int seen = Integer.MIN_VALUE, level = HIGH;

    /** The current level (cheap: it is looked at again only when the hardware may have changed). */
    public static int level() {
        int v = PcSpecs.version();
        if (v != seen) {
            seen = v;
            level = PcHardware.gpuLevel(PcSpecs.get().gpuTier());
        }
        return level;
    }

    public static boolean low() { return level() == LOW; }

    public static boolean ultra() { return level() == ULTRA; }

    /** The lang key of the name of a level: cutemod.gfx.0 ... cutemod.gfx.3. */
    public static String key(int level) { return "cutemod.gfx." + level; }
}
