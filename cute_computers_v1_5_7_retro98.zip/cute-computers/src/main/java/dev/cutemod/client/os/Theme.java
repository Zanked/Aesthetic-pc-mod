package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The look of the desktop chrome (menu bar, window title bars, the Dock and a soft overlay on the wallpaper).
 * The classic look is the default. <b>Frutiger Aero</b> (glossy blue glass, bubbles, a bright sky glow) is bought
 * in CuteMarket > Style for {@link #AERO_PRICE} coins and can be switched back to classic at any time.
 * <b>Kawaii Pastel</b> (candy pink glass, bows, floating hearts and stars, a music-box startup tune) is the second one.
 * <b>Retro 98</b> (grey bevelled buttons, navy title bars, a black and white arrow, beeps and a chip-tune startup) is the third one.
 * The chosen look is saved on the server under the name "theme" ("aero", "kawaii", "retro" or empty = classic, like the wallpaper).
 */
public final class Theme {
    public static final String AERO_ID = "theme_aero";
    public static final int AERO_PRICE = 120;

    public static final String KAWAII_ID = "theme_kawaii";
    public static final int KAWAII_PRICE = 120;
    public static final String RETRO_ID = "theme_retro98";
    public static final int RETRO_PRICE = 120;

    private static String cur = "";
    private static int gen = -1;

    private Theme() {}

    /** True when the Aero look is on (it must be bought first). */
    public static boolean aero() { return load().equals("aero") && Progress.owned(AERO_ID); }

    /** True when the Kawaii Pastel look is on (it must be bought first). */
    public static boolean kawaii() { return load().equals("kawaii") && Progress.owned(KAWAII_ID); }

    /** True when any look other than the classic one is on. */
    /** True when the Retro 98 look is on (it must be bought first). */
    public static boolean retro() { return load().equals("retro") && Progress.owned(RETRO_ID); }

    public static boolean custom() { return aero() || kawaii() || retro(); }

    private static String load() {
        if (gen != Store.gen()) {
            gen = Store.gen();
            String s = Store.read("theme");
            cur = s == null ? "" : s.trim();
        }
        return cur;
    }

    public static void setAero(boolean on) { set("aero", on); }

    public static void setKawaii(boolean on) { set("kawaii", on); }

    public static void setRetro(boolean on) { set("retro", on); }

    /** Switch a look on (it replaces the other one) or off (back to classic, only if it is the one that is on). */
    private static void set(String name, boolean on) {
        load();
        if (on) cur = name;
        else if (cur.equals(name)) cur = "";
        Store.write("theme", cur);
    }

    /** True if the shop item of this id is the look that is on now. */
    public static boolean active(String id) { return id.equals(AERO_ID) ? aero() : id.equals(KAWAII_ID) ? kawaii() : id.equals(RETRO_ID) && retro(); }

    public static void setById(String id, boolean on) {
        if (id.equals(AERO_ID)) setAero(on); else if (id.equals(KAWAII_ID)) setKawaii(on); else if (id.equals(RETRO_ID)) setRetro(on);
    }

    /** Colour of the window title text. */
    public static int titleText() { return aero() ? 0xFF14405E : kawaii() ? 0xFF8A3C6A : retro() ? 0xFFFFFFFF : 0xFF3A2A3A; }

    // ---------- the chrome ----------

    /** Blue glass menu bar: a gradient, a bright top edge and a shine on the upper half. (Kawaii: candy pink with a lace edge.) */
    public static void menuBar(GuiGraphics g, int x, int y, int w, int h) {
        if (retro()) {
            g.fillGradient(x, y, x + w, y + h, 0xFF000080, 0xFF1084D0);
            g.fill(x, y, x + w, y + 1, 0xFFFFFFFF);
            g.fill(x, y + h - 1, x + w, y + h, 0xFF404040);
            return;
        }
        if (kawaii()) {
            g.fillGradient(x, y, x + w, y + h, 0xEEFFA6D0, 0xEEF579B4);
            g.fill(x, y + 1, x + w, y + 1 + h / 2, 0x30FFFFFF);
            g.fill(x, y, x + w, y + 1, 0xCCFFFFFF);
            for (int px = x + 2; px < x + w - 2; px += 6) {                                   // a lace of little white scallops
                g.fill(px, y + h - 2, px + 4, y + h - 1, 0xDDFFFFFF);
                g.fill(px + 1, y + h - 1, px + 3, y + h, 0xDDFFFFFF);
            }
            return;
        }
        g.fillGradient(x, y, x + w, y + h, 0xDD3A9BE8, 0xDD1F6FC4);
        g.fill(x, y + 1, x + w, y + 1 + h / 2, 0x2AFFFFFF);
        g.fill(x, y, x + w, y + 1, 0xAAFFFFFF);
        g.fill(x, y + h - 1, x + w, y + h, 0x99124F8F);
    }

    /** Glossy light-blue window title bar. (Kawaii: cream pink, a stitched line and a bow.) */
    public static void titleBar(GuiGraphics g, int x, int y, int w, int h) {
        if (retro()) {
            g.fillGradient(x, y, x + w, y + h, 0xFF000080, 0xFF1084D0);
            g.fill(x, y, x + w, y + 1, 0xFFC0C0C0);
            g.fill(x, y + h - 1, x + w, y + h, 0xFF404040);
            return;
        }
        if (kawaii()) {
            g.fillGradient(x, y, x + w, y + h, 0xFFFFF6FB, 0xFFFFD2E7);
            g.fill(x, y, x + w, y + 1, 0xFFFFFFFF);
            g.fill(x, y + h - 1, x + w, y + h, 0xFFF29BC4);
            for (int px = x + 3; px < x + w - 3; px += 4) g.fill(px, y + h - 3, px + 2, y + h - 2, 0xFFFFFFFF);   // stitches
            bow(g, x + w - 15, y + Math.max(1, h / 2 - 3));
            return;
        }
        g.fillGradient(x, y, x + w, y + h, 0xFFEAF7FF, 0xFFA5D4F2);
        g.fill(x, y + 1, x + w, y + 1 + h / 2, 0x33FFFFFF);
        g.fill(x, y, x + w, y + 1, 0xFFFFFFFF);
        g.fill(x, y + h - 1, x + w, y + h, 0xFF5FA6D8);
    }

    /** The two layers of the Dock pill in Aero: a pale rim and a glossy blue body with a shine on top. */
    public static void dockPill(GuiGraphics g, int x0, int y0, int x1, int y1) {
        if (retro()) {                                              // a grey taskbar panel with raised edges
            g.fill(x0 - 2, y0 - 2, x1 + 2, y1 + 2, 0xFF000000);
            g.fill(x0 - 1, y0 - 1, x1 + 1, y1 + 1, 0xFFC0C0C0);
            g.fill(x0 - 1, y0 - 1, x1 + 1, y0, 0xFFFFFFFF);
            g.fill(x0 - 1, y0 - 1, x0, y1 + 1, 0xFFFFFFFF);
            g.fill(x0 - 1, y1, x1 + 1, y1 + 1, 0xFF808080);
            g.fill(x1, y0 - 1, x1 + 1, y1 + 1, 0xFF808080);
            return;
        }
        if (kawaii()) {
            Dock.pill(g, x0 - 1, y0 - 1, x1 + 1, y1 + 1, 0xAAFFFFFF);
            Dock.pill(g, x0, y0, x1, y1, 0xAAF98EC0);
            Dock.pill(g, x0 + 1, y0 + 1, x1 - 1, y0 + Math.max(4, (y1 - y0) / 2), 0x55FFFFFF);
            return;
        }
        Dock.pill(g, x0 - 1, y0 - 1, x1 + 1, y1 + 1, 0x77FFFFFF);
        Dock.pill(g, x0, y0, x1, y1, 0xAA2F8FD8);
        Dock.pill(g, x0 + 1, y0 + 1, x1 - 1, y0 + Math.max(4, (y1 - y0) / 2), 0x44FFFFFF);
    }

    // ---------- the overlay on the wallpaper ----------

    /** A sky glow and slowly rising soap bubbles over the wallpaper (drawn before the windows). */
    public static void overlay(GuiGraphics g, int x, int y, int w, int h) {
        int t = (int) (System.currentTimeMillis() / 50L % 1_000_000L);
        g.enableScissor(x, y, x + w, y + h);      // the overlay is drawn with the plain screen pose, so the scissor is right here
        if (retro()) {                            // a faint teal tint and the lines of an old monitor
            g.fill(x, y, x + w, y + h, 0x14008080);
            for (int ly = y + 1; ly < y + h; ly += 2) g.fill(x, ly, x + w, ly + 1, 0x12000000);
            g.disableScissor();
            return;
        }
        if (kawaii()) {                           // a pink haze and little hearts and stars floating up
            g.fillGradient(x, y, x + w, y + h * 40 / 100, 0x44FFE0F0, 0x00FFE0F0);
            g.fillGradient(x, y + h * 70 / 100, x + w, y + h, 0x00FFB6DA, 0x33FFB6DA);
            int[] cols = {0xBBFF8CBC, 0xBBFFD84D, 0xBBB79CFF, 0xBB8FE8D6, 0xBBFFFFFF};
            for (int i = 0; i < 14; i++) {
                int size = 3 + i % 3;
                int rise = (t * (1 + i % 3) / 4 + i * 53) % (h + size * 4);
                int cy = y + h + size * 2 - rise;
                int cx = x + size + (i * 71 + 17) % Math.max(1, w - size * 2) + (int) (Math.sin(t * 0.05 + i) * 5);
                if (i % 2 == 0) heart(g, cx, cy, cols[i % cols.length]); else sparkle(g, cx, cy, size, cols[i % cols.length]);
            }
            g.disableScissor();
            return;
        }
        g.fillGradient(x, y, x + w, y + h * 45 / 100, 0x55FFFFFF, 0x00FFFFFF);
        for (int i = 0; i < 10; i++) {
            int rad = 3 + (i * 5) % 9;
            int rise = (t * (1 + i % 3) / 3 + i * 47) % (h + rad * 4);
            int cy = y + h + rad * 2 - rise;
            int cx = x + rad + (i * 83 + 20) % Math.max(1, w - rad * 2) + (int) (Math.sin(t * 0.04 + i) * 4);
            bubble(g, cx, cy, rad);
        }
        g.disableScissor();
    }

    /** A tiny pink bow (9 x 6). */
    private static void bow(GuiGraphics g, int x, int y) {
        g.fill(x, y, x + 4, y + 5, 0xFFFF7CB4);
        g.fill(x + 5, y, x + 9, y + 5, 0xFFFF7CB4);
        g.fill(x + 1, y + 1, x + 3, y + 2, 0xFFFFC4DE);
        g.fill(x + 6, y + 1, x + 8, y + 2, 0xFFFFC4DE);
        g.fill(x + 3, y + 1, x + 6, y + 4, 0xFFE0508C);
    }

    private static void heart(GuiGraphics g, int cx, int cy, int argb) {
        g.fill(cx - 2, cy - 2, cx, cy - 1, argb);
        g.fill(cx + 1, cy - 2, cx + 3, cy - 1, argb);
        g.fill(cx - 3, cy - 1, cx + 4, cy + 1, argb);
        g.fill(cx - 2, cy + 1, cx + 3, cy + 2, argb);
        g.fill(cx - 1, cy + 2, cx + 2, cy + 3, argb);
        g.fill(cx, cy + 3, cx + 1, cy + 4, argb);
    }

    /** A four-pointed sparkle. */
    private static void sparkle(GuiGraphics g, int cx, int cy, int size, int argb) {
        g.fill(cx - size, cy, cx + size + 1, cy + 1, argb);
        g.fill(cx, cy - size, cx + 1, cy + size + 1, argb);
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, argb);
    }

    private static void bubble(GuiGraphics g, int cx, int cy, int rad) {
        for (int dy = -rad; dy <= rad; dy++) {
            int dx = (int) Math.floor(Math.sqrt(rad * rad - dy * dy + 0.25));
            int inner = Math.abs(dy) >= rad - 1 ? -1 : (int) Math.floor(Math.sqrt((rad - 1) * (rad - 1) - dy * dy + 0.25));
            if (inner < 0) {
                g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, 0x77FFFFFF);
            } else {
                g.fill(cx - dx, cy + dy, cx - inner, cy + dy + 1, 0x77FFFFFF);       // the rim
                g.fill(cx - inner, cy + dy, cx + inner + 1, cy + dy + 1, 0x1CFFFFFF);  // the thin glass inside
                g.fill(cx + inner + 1, cy + dy, cx + dx + 1, cy + dy + 1, 0x77FFFFFF);
            }
        }
        g.fill(cx - rad / 2, cy - rad / 2, cx - rad / 2 + 2, cy - rad / 2 + 2, 0xCCFFFFFF);   // the highlight
    }

    // ---------- the mouse cursor ----------
    private static final String[] ARROW = {
            "B..........", "BB.........", "BwB........", "BwwB.......", "BwwwB......", "BwwwwB.....",
            "BwwwwwB....", "BwwwwwwB...", "BwwwwwwwB..", "BwwwwwwwwB.", "BwwwwwBBBBB", "BwwBwwB....",
            "BwB.BwwB...", "BB..BwwB...", "B....BwwB..", ".....BwwB..", "......BB..."};

    private static final String[] HEART = {".X.X.", "XXXXX", "XXXXX", ".XXX.", "..X.."};

    /**
     * The classic look's cursor: a soft pink arrow with a plum outline and a white shine, and a tiny heart
     * that bobs next to it. The hot spot is the top-left pixel, like every arrow.
     */
    public static void cursorClassic(GuiGraphics g, int mx, int my) {
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                int argb = c == 'B' ? 0xFF5A2A4A : (col < 3 ? 0xFFFFF3F8 : row < 8 ? 0xFFFFC4DE : 0xFFFF8CBC);
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, argb);
            }
        }
        int bob = (int) Math.round(Math.sin(System.currentTimeMillis() / 220.0));
        for (int row = 0; row < HEART.length; row++) {
            for (int col = 0; col < HEART[row].length(); col++) {
                if (HEART[row].charAt(col) == '.') continue;
                g.fill(mx + 10 + col, my + 1 + bob + row, mx + 11 + col, my + 2 + bob + row, row == 0 && col == 1 ? 0xFFFFB3CE : 0xFFFF6B9A);
            }
        }
        g.pose().popPose();
    }

    /** A glossy blue arrow with a white shine; a spinning ring next to it while the app is busy. (Kawaii: a candy arrow with a twinkling star.) */
    public static void cursor(GuiGraphics g, int mx, int my, boolean busy) {
        if (kawaii()) { cursorKawaii(g, mx, my, busy); return; }
        if (retro()) { cursorRetro(g, mx, my, busy); return; }
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                int argb = c == 'B' ? 0xFF0E4A86 : (col < 3 ? 0xFFFFFFFF : row < 8 ? 0xFFBFE6FF : 0xFF5DB4F0);
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, argb);
            }
        }
        if (busy) {
            long t = System.currentTimeMillis() / 90L;
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4;
                int px = mx + 15 + (int) Math.round(Math.cos(a) * 4), py = my + 15 + (int) Math.round(Math.sin(a) * 4);
                int k = (int) ((t - i) & 7);
                int al = 0x30 + (7 - k) * 0x1E;
                g.fill(px, py, px + 2, py + 2, (Math.min(255, al) << 24) | 0x2F9BEA);
            }
        }
        g.pose().popPose();
    }

    /** A white and pink arrow with a plum outline, a twinkling star next to it and a ring of little hearts while busy. */
    private static void cursorKawaii(GuiGraphics g, int mx, int my, boolean busy) {
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                int argb = c == 'B' ? 0xFF8A3C78 : (col < 3 ? 0xFFFFFFFF : row < 8 ? 0xFFFFE0EE : 0xFFFFB0D4);
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, argb);
            }
        }
        long t = System.currentTimeMillis() / 260L;
        int star = (t & 1) == 0 ? 0xFFFFE066 : 0xFFFFF6B0;
        int sx = mx + 13, sy = my + 3;
        g.fill(sx - 2, sy, sx + 3, sy + 1, star);
        g.fill(sx, sy - 2, sx + 1, sy + 3, star);
        if (busy) {
            long k = System.currentTimeMillis() / 90L;
            for (int i = 0; i < 6; i++) {
                double a = i * Math.PI / 3 + k * 0.3;
                g.fill(mx + 15 + (int) Math.round(Math.cos(a) * 5), my + 17 + (int) Math.round(Math.sin(a) * 5), mx + 17 + (int) Math.round(Math.cos(a) * 5), my + 19 + (int) Math.round(Math.sin(a) * 5), 0xFFFF6B9A);
            }
        }
        g.pose().popPose();
    }

    private static final String[] HOURGLASS = {
            "BBBBBBBBB", "BwwwwwwwB", ".BwwwwwB.", "..BwwwB..", "...BwB...", "...BwB...", "..BwwwB..", ".BwwwwwB.", "BwwwwwwwB", "BBBBBBBBB"};

    /** The old black and white arrow, and an hourglass next to it while the app is busy. */
    private static void cursorRetro(GuiGraphics g, int mx, int my, boolean busy) {
        g.pose().pushPose();
        g.pose().translate(0, 0, 450);
        for (int row = 0; row < ARROW.length; row++) {
            String s = ARROW[row];
            for (int col = 0; col < s.length(); col++) {
                char c = s.charAt(col);
                if (c == '.') continue;
                g.fill(mx + col, my + row, mx + col + 1, my + row + 1, c == 'B' ? 0xFF000000 : 0xFFFFFFFF);
            }
        }
        if (busy) {
            boolean top = (System.currentTimeMillis() / 400L & 1) == 0;                 // the sand flips from time to time
            for (int row = 0; row < HOURGLASS.length; row++) {
                String s = HOURGLASS[row];
                for (int col = 0; col < s.length(); col++) {
                    char c = s.charAt(col);
                    if (c == '.') continue;
                    int argb = c == 'B' ? 0xFF000000 : ((row < 5) == top ? 0xFFE8D060 : 0xFFFFFFFF);
                    g.fill(mx + 12 + col, my + 3 + row, mx + 13 + col, my + 4 + row, argb);
                }
            }
        }
        g.pose().popPose();
    }
}
