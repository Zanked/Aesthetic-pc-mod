package dev.cutemod.item;

import dev.cutemod.block.PcColor;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * A PC case or a monitor of one colour: the same block as the white one, placed with its "color" property set
 * (so the item in the inventory has its own picture and its own name).
 */
public class PcColoredItem extends BlockItem {
    private final PcColor color;
    private final String descriptionId;

    public PcColoredItem(Block block, Properties props, PcColor color, String descriptionId) {
        super(block, props);
        this.color = color;
        this.descriptionId = descriptionId;
    }

    public PcColor color() { return color; }

    @Override
    protected BlockState getPlacementState(BlockPlaceContext ctx) {
        BlockState state = super.getPlacementState(ctx);
        return state == null ? null : state.setValue(PcColor.PROPERTY, color);
    }

    @Override
    public String getDescriptionId() { return descriptionId; }
}
