package dev.cutemod.item;

import dev.cutemod.block.PcCaseBlockEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * A tube of thermal paste. It goes on the processor BEFORE the cooler: right-click a case that has a processor and no cooler yet
 * (or drop it on the processor in the build screen). A cooler on a processor without paste carries away only 85% of its watts
 * (see {@code Thermal#NO_PASTE}); the paste dries when the cooler or the processor comes out, so it is a consumable.
 */
public class PcPasteItem extends Item {
    public PcPasteItem(Properties props) { super(props); }

    /** Server side: put paste on the processor of the case that is being built. */
    public void installInCase(ServerPlayer sp, ItemStack stack, PcCaseBlockEntity be) {
        if (be == null) return;
        PcCaseBlockEntity.Result r = be.applyPaste();
        if (r != PcCaseBlockEntity.Result.OK) {
            String key = switch (r) {
                case NEED_BOARD -> "cutemod.case.need_board";
                case NEED_CPU -> "cutemod.case.need_cpu";
                case BUSY -> "cutemod.case.paste_busy";
                default -> "cutemod.case.paste_same";
            };
            sp.displayClientMessage(Component.translatable(key, Component.translatable(getDescriptionId())).withStyle(ChatFormatting.RED), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.PLAYERS, 0.7F, 1.2F);
            return;
        }
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        sp.displayClientMessage(Component.translatable("cutemod.case.paste_on").withStyle(ChatFormatting.GREEN), true);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.SLIME_BLOCK_PLACE, SoundSource.PLAYERS, 0.8F, 1.4F);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.PLAYERS, 0.8F, 1.6F);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("cutemod.tip.paste.what").withStyle(ChatFormatting.AQUA));
        tip.add(Component.translatable("cutemod.tip.paste.order").withStyle(ChatFormatting.LIGHT_PURPLE));
        tip.add(Component.translatable("cutemod.tip.paste.install").withStyle(ChatFormatting.GRAY));
    }
}
