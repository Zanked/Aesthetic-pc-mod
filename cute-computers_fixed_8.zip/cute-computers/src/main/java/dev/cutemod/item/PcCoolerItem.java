package dev.cutemod.item;

import dev.cutemod.block.PcCaseBlockEntity;
import dev.cutemod.data.Build;
import dev.cutemod.data.Thermal;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * A processor cooler (level 1 = a small air cooler, 2 = a tower, 3 = a liquid cooler). It goes into the cooler place of a PC case
 * (see {@link PcCaseBlockEntity#installCooler}): the better the cooler, the cooler the processor and the whole case run, so the strong
 * parts do not throttle. Right-click a case with it, or put it in from the build screen. A cooler of the same place is swapped for it.
 */
public class PcCoolerItem extends Item {
    private final int level;

    public PcCoolerItem(Properties props, int level) {
        super(props);
        this.level = level;
    }

    public int level() { return level; }

    /** Server side: put this cooler (one of the stack) into the case that is being built. */
    public void installInCase(ServerPlayer sp, ItemStack stack, PcCaseBlockEntity be) {
        if (be == null) return;
        ItemStack[] out = {ItemStack.EMPTY};
        PcCaseBlockEntity.Result r = be.installCooler(level, out);
        if (r != PcCaseBlockEntity.Result.OK) {
            String key = switch (r) {
                case NEED_BOARD -> "cutemod.case.need_board";
                case NEED_CPU -> "cutemod.case.need_cpu";
                default -> "cutemod.case.same";
            };
            sp.displayClientMessage(Component.translatable(key, Component.translatable(getDescriptionId())).withStyle(ChatFormatting.RED), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.PLAYERS, 0.7F, 1.2F);
            return;
        }
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        boolean swapped = !out[0].isEmpty();
        if (swapped && !sp.getInventory().add(out[0])) sp.drop(out[0], false);
        sp.displayClientMessage(Component.translatable(swapped ? "cutemod.case.swapped" : "cutemod.part.installed", Component.translatable(getDescriptionId()))
                .withStyle(ChatFormatting.GREEN), true);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1F, 1.3F);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.PLAYERS, 0.8F, 1.4F);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("cutemod.tip.cooler.what", Thermal.COOLER_CAP[level]).withStyle(ChatFormatting.AQUA));
        tip.add(Component.translatable("cutemod.tip.cooler.cpu", Build.CPU_NAMES[Math.min(Build.CPU_NAMES.length - 1, level + 1)]).withStyle(ChatFormatting.LIGHT_PURPLE));
        tip.add(Component.translatable("cutemod.tip.cooler.install").withStyle(ChatFormatting.GRAY));
    }
}
