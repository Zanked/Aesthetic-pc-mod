package dev.cutemod.item;

import dev.cutemod.block.PcCaseBlockEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * The cables of a PC: the coil of wires (the 24-pin plug, the SATA and the video card plugs) that joins the power supply to the
 * board, the drive and the card. A PC case does not start without them. Right-click a case that already has a motherboard and a
 * power supply: the cables go inside (see {@link PcCaseBlockEntity#installCables}); sneak + right-click the case with an empty
 * hand takes them out again, in the order of a real build (after the card, the drive and the memory, before the processor).
 */
public class PcCablesItem extends Item {
    public PcCablesItem(Properties props) { super(props); }

    /** Server side: put one set of cables into the case that is being built. */
    public void installInCase(ServerPlayer sp, ItemStack stack, PcCaseBlockEntity be) {
        if (be == null) return;
        PcCaseBlockEntity.Result r = be.installCables();
        if (r != PcCaseBlockEntity.Result.OK) {
            String key = switch (r) {
                case NEED_BOARD -> "cutemod.case.need_board";
                case NEED_PSU -> "cutemod.case.need_psu";
                default -> "cutemod.case.same";
            };
            sp.displayClientMessage(Component.translatable(key, Component.translatable(getDescriptionId())).withStyle(ChatFormatting.RED), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.PLAYERS, 0.7F, 1.2F);
            return;
        }
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        sp.displayClientMessage(Component.translatable("cutemod.case.cables_in").withStyle(ChatFormatting.GREEN), true);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1F, 1.1F);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.PLAYERS, 0.8F, 1.6F);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.WOOL_PLACE, SoundSource.PLAYERS, 0.8F, 1.5F);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("cutemod.tip.cables.what").withStyle(ChatFormatting.AQUA));
        tip.add(Component.translatable("cutemod.tip.cables.need").withStyle(ChatFormatting.LIGHT_PURPLE));
        tip.add(Component.translatable("cutemod.tip.cables.install").withStyle(ChatFormatting.GRAY));
    }
}
