package dev.cutemod.item;

import dev.cutemod.block.LaptopBlock;
import dev.cutemod.data.Build;
import dev.cutemod.data.PcHardware;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.component.CustomData;
import dev.cutemod.client.ClientHooks;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * The laptop in the hand: right-click opens the OS right here (the screen is a bit smaller than the monitor of a computer), and
 * sneak + right-click on a block puts the laptop down (open, facing the player).
 */
public class LaptopItem extends BlockItem {
    public LaptopItem(LaptopBlock block, Item.Properties props) { super(block, props); }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Player p = ctx.getPlayer();
        if (p == null || !p.isShiftKeyDown()) return InteractionResult.PASS;     // not placing: use() opens the OS
        return super.useOn(ctx);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide && getBlock() instanceof LaptopBlock lb) ClientHooks.openLaptopInHand(lb.getColor(), buildOf(stack).write());
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** The build of the laptop in this stack: as it was sold, plus the memory and the drive it has been upgraded with. */
    public static Build buildOf(ItemStack stack) {
        if (!(stack.getItem() instanceof LaptopItem li) || !(li.getBlock() instanceof LaptopBlock lb)) return Build.stock();
        var cd = stack.get(DataComponents.CUSTOM_DATA);
        if (cd != null && cd.contains("Build")) return Build.parse(cd.copyTag().getString("Build"));
        return lb.line().build();
    }

    /** Keeps a changed build in the stack (as custom_data, the same place the placed laptop copies it to and from). */
    public static void setBuild(ItemStack stack, Build b) {
        CompoundTag tag = new CompoundTag();
        tag.putString("Build", b.write());
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        Build b = buildOf(stack);
        tip.add(Component.translatable("cutemod.tip.laptop.spec", Build.CPU_NAMES[b.cpu], PcHardware.GPU_NAMES[b.gpu], b.ramGb(), PcHardware.DISK_GB[b.disk]).withStyle(ChatFormatting.AQUA));
        tip.add(Component.translatable("cutemod.tip.laptop.soldered").withStyle(ChatFormatting.DARK_GRAY));
        tip.add(Component.translatable("cutemod.tip.laptop.use").withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable("cutemod.tip.laptop.place").withStyle(ChatFormatting.BLUE));
        tip.add(Component.translatable("cutemod.tip.laptop.lid").withStyle(ChatFormatting.LIGHT_PURPLE));
    }
}
