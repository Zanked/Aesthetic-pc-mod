package dev.cutemod.item;

import dev.cutemod.block.ComputerBlockEntity;
import dev.cutemod.data.Build;
import dev.cutemod.data.PcHardware;
import dev.cutemod.data.PcHardware.Kind;
import dev.cutemod.data.PlayerData;
import dev.cutemod.market.MarketServer;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.UUID;

/**
 * A part for the computer: processor, motherboard, power supply, memory stick, video card or drive. Right-click a computer
 * with it and the part goes inside THAT computer (every computer block has its own build, see {@link Build}). A part only goes in
 * if it fits and is better than what the computer has; the part it replaces is sold back to the shop for {@link #TRADE_IN_PCT} percent
 * of its price in coins. Laptops are bought ready and cannot be upgraded.
 */
public class PcPartItem extends Item {
    /** How much of the price of the old part the player gets back when a better one replaces it. */
    public static final int TRADE_IN_PCT = 70;

    private final Kind kind;
    private final int level;

    public PcPartItem(Properties props, Kind kind, int level) {
        super(props);
        this.kind = kind;
        this.level = level;
    }

    public Kind kind() { return kind; }

    public int level() { return level; }

    /** What goes into {@link Build#install}: for a memory stick its size in GB, for the rest the level. */
    private int buildLevel() { return kind == Kind.RAM ? stickGb() : level; }

    /** The size of this memory stick in GB (level -1 is the crafted stock stick). */
    private int stickGb() { return level < 0 ? Build.STOCK_STICK_GB : Build.STICK_GB[level]; }

    /** Server side: put this part (one of the stack) into the computer of this block. */
    public void install(ServerPlayer sp, ItemStack stack, ComputerBlockEntity be) {
        if (be == null) return;
        Build b = be.build();
        if (apply(sp, stack, b)) be.setBuild(b);
    }

    /** Server side: put this part into the laptop in the hand (its build is kept in the item). */
    public void installInLaptop(ServerPlayer sp, ItemStack part, ItemStack laptop) {
        Build b = LaptopItem.buildOf(laptop);
        if (apply(sp, part, b)) LaptopItem.setBuild(laptop, b);
    }

    /** Tries the part on this build: on success the build is changed, one part is used up and the old one is sold back. Returns whether it went in. */
    private boolean apply(ServerPlayer sp, ItemStack stack, Build b) {
        int[] out = new int[1];
        Build.Result r = b.install(kind, buildLevel(), out);
        if (r != Build.Result.OK) {
            String key = switch (r) {
                case SOCKET -> "cutemod.part.socket";
                case NO_SLOT -> "cutemod.part.noslot";
                default -> "cutemod.part.worse";
            };
            sp.displayClientMessage(Component.translatable(key, Component.translatable(getDescriptionId())).withStyle(ChatFormatting.RED), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.PLAYERS, 0.7F, 1.2F);
            return false;
        }
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        int back = Math.round(out[0] * TRADE_IN_PCT / 100f);
        if (back > 0) {                                                // the old part is sold back for coins
            MarketServer.sync(sp, back);
            sp.displayClientMessage(Component.translatable("cutemod.part.traded", Component.translatable(getDescriptionId()), back).withStyle(ChatFormatting.GREEN), true);
        } else {
            sp.displayClientMessage(Component.translatable("cutemod.part.installed", Component.translatable(getDescriptionId())).withStyle(ChatFormatting.GREEN), true);
        }
        if (b.powerShort())
            sp.displayClientMessage(Component.translatable("cutemod.part.weakpsu", b.shortWatts()).withStyle(ChatFormatting.GOLD), false);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1F, 1.3F);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.PLAYERS, 0.8F, 1.4F);
        return true;
    }

    /**
     * Server side: put this part (one of the stack) into a PC CASE that is being built. Unlike an old computer, a case starts empty:
     * every part goes into its own place (the board first), a part of the same kind that is already there is swapped for it and
     * comes back as an item (a hand-built PC pays no coins).
     */
    public void installInCase(ServerPlayer sp, ItemStack stack, dev.cutemod.block.PcCaseBlockEntity be) {
        if (be == null) return;
        ItemStack[] out = {ItemStack.EMPTY};
        dev.cutemod.block.PcCaseBlockEntity.Result r = be.install(kind, buildLevel(), out);
        if (r != dev.cutemod.block.PcCaseBlockEntity.Result.OK) {
            String key = switch (r) {
                case NEED_BOARD -> "cutemod.case.need_board";
                case SOCKET -> "cutemod.part.socket";
                case NO_SLOT -> "cutemod.part.noslot";
                case BOARD_SLOTS -> "cutemod.case.board_slots";
                default -> "cutemod.case.same";
            };
            sp.displayClientMessage(Component.translatable(key, Component.translatable(getDescriptionId())).withStyle(ChatFormatting.RED), true);
            sp.level().playSound(null, sp.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.PLAYERS, 0.7F, 1.2F);
            return;
        }
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        boolean swapped = !out[0].isEmpty();
        if (swapped && !sp.getInventory().add(out[0])) sp.drop(out[0], false);
        sp.displayClientMessage(Component.translatable(swapped ? "cutemod.case.swapped" : "cutemod.part.installed", Component.translatable(getDescriptionId()))
                .withStyle(ChatFormatting.GREEN), true);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1F, 1.3F);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.PLAYERS, 0.8F, 1.4F);
    }

    /** A laptop is bought ready: tell the player. */
    public static void laptopFixed(ServerPlayer sp) {
        sp.displayClientMessage(Component.translatable("cutemod.part.laptop").withStyle(ChatFormatting.RED), true);
        sp.level().playSound(null, sp.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.PLAYERS, 0.7F, 1.2F);
    }

    /** The name of the blob where the server notes that the player got the free first modem. */
    private static final String GIFT_KEY = "modemgift";

    /** Once per player: the first (weakest) modem as a gift, so the online apps can be switched on at all. Server side. */
    public static void giveStarterModem(ServerPlayer sp) {
        var server = sp.getServer();
        if (server == null) return;
        PlayerData data = PlayerData.get(server);
        UUID id = sp.getUUID();
        if (data.copyOf(id).get(GIFT_KEY) != null) return;
        data.put(id, GIFT_KEY, "1");
        ItemStack modem = ModItems.partStack(Kind.MODEM, PcHardware.MODEM_FIRST);
        if (modem.isEmpty()) return;
        if (!sp.getInventory().add(modem)) sp.drop(modem, false);
        sp.displayClientMessage(Component.translatable("cutemod.part.modemgift").withStyle(ChatFormatting.AQUA), false);
    }

    /** With a laptop in the other hand the part can be installed without a block. */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        ItemStack other = player.getItemInHand(hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        if (other.getItem() instanceof LaptopItem) {                  // a laptop in the hand: only memory and the drive go in
            if (!level.isClientSide && player instanceof ServerPlayer sp) {
                if (!dev.cutemod.data.LaptopLine.upgradable(kind)) laptopFixed(sp);
                else installInLaptop(sp, stack, other);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        return InteractionResultHolder.pass(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        switch (kind) {
            case RAM -> tip.add(Component.translatable("cutemod.tip.part.ram", gb(stickGb())).withStyle(ChatFormatting.AQUA));
            case CPU -> {
                tip.add(Component.translatable("cutemod.tip.part.cpu", Build.CPU_CORES[level], Build.CPU_WATTS[level]).withStyle(ChatFormatting.AQUA));
                tip.add(Component.translatable("cutemod.tip.part.socket", Build.CPU_SOCKET[level]).withStyle(ChatFormatting.LIGHT_PURPLE));
                if (Build.CPU_SOCKET[level] > 1) tip.add(Component.translatable("cutemod.tip.part.swap.cpu").withStyle(ChatFormatting.DARK_GRAY));
            }
            case BOARD -> {
                tip.add(Component.translatable("cutemod.tip.part.board", Build.BOARD_SLOTS[level]).withStyle(ChatFormatting.AQUA));
                tip.add(Component.translatable("cutemod.tip.part.socket", Build.BOARD_SOCKET[level]).withStyle(ChatFormatting.LIGHT_PURPLE));
                if (Build.BOARD_SOCKET[level] > 1) tip.add(Component.translatable("cutemod.tip.part.swap.board").withStyle(ChatFormatting.DARK_GRAY));
            }
            case PSU -> tip.add(Component.translatable("cutemod.tip.part.psu", Build.PSU_WATTS[level]).withStyle(ChatFormatting.AQUA));
            case DISK -> tip.add(Component.translatable("cutemod.tip.part.disk", gb(PcHardware.DISK_GB[level])).withStyle(ChatFormatting.AQUA));
            case MODEM -> {
                tip.add(Component.translatable("cutemod.tip.part.modem", PcHardware.MODEM_MBPS[level]).withStyle(ChatFormatting.AQUA));
                if (level <= 2) tip.add(Component.translatable("cutemod.tip.part.modem.flaky").withStyle(ChatFormatting.RED));
            }
            case GPU -> {
                tip.add(Component.translatable("cutemod.tip.part.gpu", PcHardware.VRAM_GB[level], Build.GPU_WATTS[level]).withStyle(ChatFormatting.AQUA));
                tip.add(Component.translatable("cutemod.tip.part.gfx", Component.translatable("cutemod.gfx." + PcHardware.gpuLevel(level))).withStyle(ChatFormatting.LIGHT_PURPLE));
            }
        }
        tip.add(Component.translatable("cutemod.tip.part.install").withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable("cutemod.tip.part.better").withStyle(ChatFormatting.DARK_GRAY));
    }

    private static String gb(int gb) { return gb >= 1000 ? (gb / 1000) + " TB" : gb + " GB"; }
}
