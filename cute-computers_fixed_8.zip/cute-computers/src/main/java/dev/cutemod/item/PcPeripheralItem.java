package dev.cutemod.item;

import dev.cutemod.block.PcMonitorBlock;
import dev.cutemod.block.PcPeriphStyle;
import dev.cutemod.block.PcPeripheralBlock;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * A keyboard or a mouse. It is not put on the table any more: right-click a monitor with it and it is connected to the monitor
 * (and drawn in front of it, in ITS OWN colour / style: it does not take the colour of the monitor). See {@link PcMonitorBlock#attach}.
 */
public class PcPeripheralItem extends Item {
    private final PcPeripheralBlock.Kind kind;
    private final PcPeriphStyle style;

    public PcPeripheralItem(Properties props, PcPeripheralBlock.Kind kind, PcPeriphStyle style) {
        super(props);
        this.kind = kind;
        this.style = style;
    }

    public PcPeripheralBlock.Kind kind() { return kind; }

    public PcPeriphStyle style() { return style; }

    /**
     * The monitor itself takes the item in its own right-click code; this is for the case when the player sneaks (a block does not
     * get the click of a sneaking player who holds an item) and for every other block, where it only says what to do.
     */
    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockState state = level.getBlockState(ctx.getClickedPos());
        if (state.getBlock() instanceof PcMonitorBlock) {
            PcMonitorBlock.attach(ctx.getItemInHand(), kind, style, state, level, ctx.getClickedPos(), ctx.getPlayer());
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!level.isClientSide && ctx.getPlayer() instanceof ServerPlayer sp)
            sp.displayClientMessage(Component.translatable("cutemod.monitor.hint"), true);
        return InteractionResult.PASS;
    }
}
