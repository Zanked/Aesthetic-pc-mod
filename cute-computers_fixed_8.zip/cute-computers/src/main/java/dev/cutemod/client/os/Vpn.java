package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;

import java.util.List;

/**
 * The VPN of the computer (the bought app "ShadeVPN", see {@link VpnApp}). It needs a working internet connection; while it is on,
 * the computer's address is hidden and the hidden sites (".onion", the dark market {@link DarkMarketApp}) can be opened.
 * It is a session thing: the connection is not kept when the computer is switched off or the world is left, but the player's
 * favourite server and the "I have found the hidden network" flag are saved with the rest of the player's data.
 */
public final class Vpn {
    private Vpn() {}

    /** A VPN server: id (translated as cutemod.vpn.srv.<id>), colour of its badge, base ping in ms and speed in percent. */
    public record Server(String id, int rgb, int ping, int speed, boolean hidden) {}

    public static final List<Server> SERVERS = List.of(
            new Server("nl", 0xFF5AA8F0, 34, 96, false),
            new Server("is", 0xFF7AE0D0, 58, 88, false),
            new Server("ch", 0xFFE5484D, 41, 92, false),
            new Server("sg", 0xFFF0B820, 112, 80, false),
            new Server("pa", 0xFF9A6AE6, 148, 70, true));      // the Panama node: the one the hidden network is reached through

    /** The dark market's address. It is typed into the browser (or opened from the VPN app once it is found). */
    public static final String DARK_HOST = "noir.onion";

    public static final String APP_ID = "vpn";
    private static final String KEY_SERVER = "vpn_srv", KEY_FOUND = "vpn_found";
    private static final long CONNECT_MS = 2600;

    private static int server = -1;
    private static long readyAt;          // when the handshake ends (0 = off)
    private static long since;            // when the tunnel went up
    private static int gen = -1;
    private static boolean wasOn;

    private static void ensure() {
        if (gen != Store.gen()) {          // another world or server: the tunnel is gone
            gen = Store.gen();
            server = -1;
            readyAt = 0;
            since = 0;
            wasOn = false;
        }
    }

    public static boolean installed() { return Library.installed(APP_ID); }

    // ---------- state ----------
    /** The handshake is running (the shield spins). */
    public static boolean connecting() {
        ensure();
        return readyAt != 0 && System.currentTimeMillis() < readyAt;
    }

    /** 0..1 of the handshake. */
    public static float progress() {
        if (!connecting()) return readyAt == 0 ? 0f : 1f;
        return 1f - (readyAt - System.currentTimeMillis()) / (float) CONNECT_MS;
    }

    /**
     * True while the tunnel is up: the handshake is done, the app is installed and the internet works. A tunnel that loses the
     * connection (the router is out of reach, a weak router drops) falls down by itself, like a real one.
     */
    public static boolean on() {
        ensure();
        if (readyAt == 0 || server < 0) return false;
        if (System.currentTimeMillis() < readyAt) return false;
        if (!installed() || !Modem.connected()) {
            readyAt = 0;
            wasOn = false;
            return false;
        }
        if (!wasOn) {
            wasOn = true;
            since = System.currentTimeMillis();
            if (!found()) markFound();
        }
        return true;
    }

    public static int server() { ensure(); return server; }

    public static Server current() { ensure(); return server >= 0 ? SERVERS.get(server) : null; }

    /** Starts the tunnel to this server (the old one is dropped). Needs the internet. */
    public static boolean connect(int index) {
        ensure();
        if (index < 0 || index >= SERVERS.size() || !Modem.connected()) return false;
        server = index;
        readyAt = System.currentTimeMillis() + CONNECT_MS;
        wasOn = false;
        Store.write(KEY_SERVER, SERVERS.get(index).id());
        return true;
    }

    public static void disconnect() {
        ensure();
        readyAt = 0;
        wasOn = false;
        since = 0;
    }

    /** The server the player used last (0 = the first one). */
    public static int favourite() {
        String id = Store.read(KEY_SERVER);
        if (id == null) return 0;
        for (int i = 0; i < SERVERS.size(); i++) if (SERVERS.get(i).id().equals(id.trim())) return i;
        return 0;
    }

    public static int secondsUp() { return on() ? (int) ((System.currentTimeMillis() - since) / 1000) : 0; }

    // ---------- numbers for the screen ----------
    private static int hash(int n) {
        n ^= n >>> 15; n *= 0x2C1B3C6D; n ^= n >>> 12; n *= 0x297A2D39; n ^= n >>> 15;
        return n & 0x7FFFFFFF;
    }

    private static int seed() {
        var p = Minecraft.getInstance().player;
        return p == null ? 1 : p.getUUID().hashCode();
    }

    /** The real address of this computer (made up, but always the same for one player). */
    public static String realIp() {
        int h = hash(seed());
        return (80 + h % 120) + "." + ((h >> 8) % 250) + "." + ((h >> 16) % 250) + "." + (1 + (h >> 4) % 250);
    }

    /** The address the world sees: the server's. */
    public static String maskedIp(int srv) {
        int h = hash(seed() * 31 + srv * 7919 + 11);
        return (20 + h % 180) + "." + ((h >> 9) % 250) + "." + ((h >> 17) % 250) + "." + (1 + (h >> 3) % 250);
    }

    /** Ping in ms with a little living jitter. */
    public static int ping(int srv) {
        long t = System.currentTimeMillis() / 700;
        int jitter = hash((int) t * 13 + srv * 101) % 9 - 4;
        return Math.max(8, SERVERS.get(srv).ping() + jitter);
    }

    // ---------- the hidden network ----------
    /** True once the player has connected to a server (the first connection shows them where the hidden sites are). */
    public static boolean found() { return "1".equals(Store.read(KEY_FOUND)); }

    private static void markFound() { Store.write(KEY_FOUND, "1"); }

    /** Convenience for the browser and the apps: is the dark market reachable right now? */
    public static boolean darkReachable() { return on(); }
}
