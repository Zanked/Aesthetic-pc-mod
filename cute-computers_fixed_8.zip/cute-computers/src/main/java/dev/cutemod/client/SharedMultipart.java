package dev.cutemod.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.BlockModelRotation;
import net.minecraft.client.resources.model.Material;
import net.minecraft.client.resources.model.ModelBaker;
import net.minecraft.client.resources.model.ModelState;
import net.minecraft.client.resources.model.MultiPartBakedModel;
import net.minecraft.client.resources.model.UnbakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.neoforged.neoforge.client.model.geometry.IGeometryBakingContext;
import net.neoforged.neoforge.client.model.geometry.IGeometryLoader;
import net.neoforged.neoforge.client.model.geometry.IUnbakedGeometry;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * A multipart model that is baked ONCE for the whole block instead of once per block state.
 *
 * The PC case and the monitor have a lot of block states (the case: 102 400, the monitor: 30 976). With a vanilla
 * {@code "multipart"} blockstate the game bakes a separate MultiPartBakedModel for EVERY state, each one with its own
 * 136-152 selectors and their condition lambdas: about 8 GB of heap in total. The selectors only read the state they are
 * asked about, so one model can serve all the states. The blockstate file is now {@code {"variants": {"": {"model": "..._shared"}}}}
 * (one variant for all states, and the game shares one baked model between equal variants), and the shared model file holds
 * the same list of parts as the old multipart: {@code {"loader": "cutemod:shared_multipart", "parts": [{"when": {...}, "apply": {"model": "...", "y": 90}}, ...]}}.
 * "when" works like the vanilla one: property -> value, several values with "|", "!" in front for "not", and "AND" / "OR" lists.
 */
public final class SharedMultipart implements IUnbakedGeometry<SharedMultipart> {
    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("cutemod", "shared_multipart");

    public static final IGeometryLoader<SharedMultipart> LOADER = (json, context) -> {
        JsonArray arr = json.getAsJsonArray("parts");
        if (arr == null || arr.isEmpty()) throw new JsonParseException("shared_multipart needs a non-empty \"parts\" list");
        List<Part> parts = new ArrayList<>();
        for (JsonElement e : arr) {
            JsonObject p = e.getAsJsonObject(), apply = p.getAsJsonObject("apply");
            Predicate<BlockState> when = p.has("when") ? condition(p.getAsJsonObject("when")) : s -> true;
            ResourceLocation model = ResourceLocation.parse(apply.get("model").getAsString());
            int x = apply.has("x") ? apply.get("x").getAsInt() : 0, y = apply.has("y") ? apply.get("y").getAsInt() : 0;
            parts.add(new Part(when, model, x, y));
        }
        return new SharedMultipart(parts);
    };

    private record Part(Predicate<BlockState> when, ResourceLocation model, int x, int y) {}

    private final List<Part> parts;

    private SharedMultipart(List<Part> parts) { this.parts = parts; }

    @Override
    public void resolveParents(Function<ResourceLocation, UnbakedModel> modelGetter, IGeometryBakingContext context) {
        for (Part p : parts) modelGetter.apply(p.model()).resolveParents(modelGetter);
    }

    @Override
    public BakedModel bake(IGeometryBakingContext context, ModelBaker baker, Function<Material, TextureAtlasSprite> spriteGetter,
                           ModelState modelState, ItemOverrides overrides) {
        List<Pair<Predicate<BlockState>, BakedModel>> list = new ArrayList<>();
        for (Part p : parts) {
            BakedModel m = baker.bake(p.model(), BlockModelRotation.by(p.x(), p.y()));
            if (m != null) list.add(Pair.of(p.when(), m));
        }
        return new MultiPartBakedModel(list);
    }

    // ---------- the conditions: the same language as the vanilla multipart "when" ----------
    private static Predicate<BlockState> condition(JsonObject w) {
        if (w.size() == 1 && (w.has("OR") || w.has("AND"))) {
            boolean or = w.has("OR");
            List<Predicate<BlockState>> subs = new ArrayList<>();
            for (JsonElement e : w.getAsJsonArray(or ? "OR" : "AND")) subs.add(condition(e.getAsJsonObject()));
            return s -> {
                for (Predicate<BlockState> p : subs) if (p.test(s) == or) return or;
                return !or;
            };
        }
        List<Predicate<BlockState>> all = new ArrayList<>();
        for (var e : w.entrySet()) {
            String name = e.getKey(), raw = e.getValue().getAsString();
            boolean not = raw.startsWith("!");
            Set<String> values = Set.of((not ? raw.substring(1) : raw).split("\\|"));
            all.add(s -> {
                for (Property<?> prop : s.getProperties()) {
                    if (prop.getName().equals(name)) return values.contains(valueName(s, prop)) != not;
                }
                return false;
            });
        }
        return s -> {
            for (Predicate<BlockState> p : all) if (!p.test(s)) return false;
            return true;
        };
    }

    private static <T extends Comparable<T>> String valueName(BlockState s, Property<T> prop) { return prop.getName(s.getValue(prop)); }
}
