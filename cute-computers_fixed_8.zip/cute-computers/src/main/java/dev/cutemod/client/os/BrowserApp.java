package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * A tiny browser. "cute://" pages are built into the mod; any other address or search words
 * are opened in the player's real browser (after the vanilla "open link?" confirmation).
 */
public class BrowserApp extends App {

    @Override
    public boolean needsNet() { return true; }
    private record RLine(FormattedCharSequence seq, int kind, String target, int y) {} // kind: 0 text, 1 heading, 2 link, 3 picture, 4 small grey, 5 accent bar, 6 post, 7 divider, 8 product

    private static final Set<String> PAGES = Set.of("home", "peep", "chirp", "shop", "wiki",
            "news", "tips", "about", "tube", "tube666", "mail", "notfound", "scary", "scary1", "scary2", "scary3", "scary4", "scary5", "scary6", "scary7", "scary8", "scary9", "deep", "deep0", "deep1", "deep2", "deep2a", "deep2b", "deep2c", "deep3", "deep3a", "deep4", "deep4a", "deep4b", "deep4c", "deep5", "deep5a", "deep5b", "deep6", "deep6a",
            "wiki1", "wiki2", "wiki3", "wiki4", "wiki5", "wiki6", "wiki7", "wiki8", "wiki9", "market", "onionwall");
    /** The fictional internet: domain -> page id. */
    private static final Map<String, String> DOMAINS = Map.of(
            "peep.cute", "peep", "chirp.cute", "chirp", "creepermart.cute", "shop",
            "pandapedia.cute", "wiki", "cutenews.cute", "news",
            "scarystories.cute", "scary", "cutetube.cute", "tube", "beemail.cute", "mail", "cutemarket.cute", "market");
    private static final String[] SEARCHABLE = {"peep", "chirp", "shop", "wiki", "news", "tips", "about", "tube",
            "scary", "scary1", "scary2", "scary3", "scary4", "scary5", "scary6", "scary7", "scary8",
            "wiki1", "wiki2", "wiki3", "wiki4", "wiki5", "wiki6", "wiki7", "wiki8"};
    private static final int WIKI_ARTICLES = 8;
    private static final int AD_H = 18, AD_Y = H - AD_H - 1, AD_COUNT = 4, AD_TICKS = 300;
    private static final int VIEW_Y = 24, VIEW_H = H - VIEW_Y - 2 - AD_H, TEXT_X = 10, TEXT_W = W - 24;
    private static final int BAR_X = 76, BAR_Y = 4, BAR_H = 15, BAR_W = W - BAR_X - 5;
    private static final int BTN_Y = 4, BTN = 15, BTN_BACK = 4, BTN_FWD = 21, BTN_RELOAD = 38, BTN_HOME = 55;
    private static final int LINK_IND = 9;       // room for the little dot in front of a link
    private static final float HEAD_SCALE = 1.3f;
    private static final int ACCENT = 0xFF4A7BD0;
    // start page: the shortcut tiles
    private static final String[] TILE_ID = {"peep", "chirp", "shop", "market", "wiki", "news", "tube", "mail", "scary"};
    private static final String[] TILE_NAME = {"Peep!", "Chirp", "CreeperMart", "CuteMarket", "Pandapedia", "Cute News", "CuteTube", "BeeMail", "Scary Stories"};
    private static final String[] TILE_LETTER = {"P", "C", "C", "M", "P", "N", "T", "B", "S"};
    private static final int[] TILE_COLOR = {0xFFF06FA6, 0xFF4AA8F0, 0xFF4CAF50, 0xFFFF9A3C, 0xFF8A8AA0, 0xFFE5534B, 0xFFB24AE0, 0xFFF0B90B, 0xFF6A4A7A};
    private static final int TILE_COLS = 3, TILE_W = 100, TILE_H = 22; // 3 x 3 shortcuts: a round icon with the name next to it
    private static final int SEARCH_X = 50, SEARCH_W = 200, SEARCH_H = 15;

    private final List<String> history = new ArrayList<>();
    private int hIdx = -1;
    private String address = "";
    private boolean focus, fresh;
    private final List<RLine> lines = new ArrayList<>();
    /** The blocks of a page, drawn as cards: {top y, bottom y, 1 = the title banner}. */
    private final List<int[]> cards = new ArrayList<>();
    // the scary stories: the typewriter (a story is told letter by letter the first time) and the mood (ScaryStories)
    private final ScaryStories scary = new ScaryStories();
    private int story;                       // 1..9 on a story page, 0 elsewhere
    private int reveal, revealPause, totalChars;
    private boolean typing;
    // the deep site (scarystories.cute/???): the cipher page has hidden words that only the flashlight shows
    private record DeepWord(int row, int x, String text) {}
    private final List<DeepWord> deepSpec = new ArrayList<>();
    private final List<Integer> deepRowY = new ArrayList<>();
    private boolean deepAmbient;
    private final List<String> plains = new ArrayList<>();
    private int[] starts = new int[0];
    private static final java.util.regex.Pattern PRICE = java.util.regex.Pattern.compile("^(.+?) - (\\d+) (\\S+)$");
    private static final java.util.regex.Pattern POST = java.util.regex.Pattern.compile("^@\\w+: .+");
    private static final int POST_IND = 22, CARD_X = 4, CARD_W = W - 12;
    private int contentH, scroll, ticks;
    private float scrollY;        // what is drawn: it eases toward `scroll`
    private int loadT = 99;       // ticks since the page started to "load" (drives the progress line)
    private int adSkip; // ticks added by closing an ad (jumps to the next one)
    private final TubeApp tube = new TubeApp(); // cutetube.cute draws itself
    private final MailApp mail = new MailApp().embedded(VIEW_Y); // beemail.cute: the same inbox as the Mail app
    /** The "no connection" page (cute://notfound, unknown addresses): a runner to play while you wait. It takes the whole area. */
    private final dev.cutemod.client.game.DinoRun dino = new dev.cutemod.client.game.DinoRun(W, H - VIEW_Y);

    public BrowserApp() {
        tube.oy = VIEW_Y;
        open("home");
    }

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        tube.attach(shell);
        mail.attach(shell);
    }

    /** True on the haunted site (address 666): its pop-up ads are drawn in the same crimson style. */
    public boolean cursedSite() { return inTube() && tube.haunted(); }

    private boolean inTube() { return currentId().startsWith("tube"); }   // "tube666" = the haunted site

    /** True on the normal CuteTube page (not the haunted one at 666): the Traces of the Stranger hide a star there. */
    public boolean onCuteTube() { return currentId().equals("tube"); }

    private boolean inMail() { return currentId().equals("mail"); }

    private boolean inDino() { return currentId().equals("notfound"); }

    /** The screensaver must not start while the runner is running. */
    @Override
    public boolean busy() { return inDino() && dino.isRunning(); }

    @Override
    public void close() { tube.close(); }

    @Override
    public Component title() { return Component.translatable("cutemod.os.browser"); }

    @Override
    public Component hint() {
        return Component.translatable(inTube() ? "cutemod.tube.hint" : inMail() ? "cutemod.os.hint.mail" : inDino() ? "cutemod.dino.hint" : "cutemod.os.hint.browser");
    }

    @Override
    public void tick() {
        ticks++;
        if (loadT < 99) loadT++;
        scrollY += (scroll - scrollY) * 0.35f;
        if (Math.abs(scroll - scrollY) < 0.6f) scrollY = scroll;
        if (inTube()) tube.tick();
        if (inMail()) mail.tick();
        if (inDino()) {
            boolean was = dino.over;
            dino.tick();
            if (!was && dino.over) Sfx.gameOver(false, false);
        }
        if (story > 0) storyTick();
        else {
            if (deepAmbient) GameMusic.keep("deep", false);          // the deep site has its own track: quiet crying and a scream (tools/make_deep_music.py)
            typeTick();                                                    // the deep pages are told letter by letter too
        }
    }

    /** The plain text of every line and where its letters start in the whole text (for the typewriter). */
    private void indexText() {
        plains.clear();
        starts = new int[lines.size()];
        int cum = 0;
        for (int i = 0; i < lines.size(); i++) {
            RLine l = lines.get(i);
            String sx = "";
            if (l.kind() == 0 || l.kind() == 4) {
                StringBuilder sb = new StringBuilder();
                l.seq().accept((idx, style, cp) -> { sb.appendCodePoint(cp); return true; });
                sx = sb.toString();
            }
            plains.add(sx);
            starts[i] = cum;
            if (!sx.isEmpty()) cum += sx.length() + 1;
        }
        totalChars = cum;
    }

    private int lineOfChar(int c) {
        for (int i = 0; i < lines.size(); i++) {
            int len = plains.get(i).length();
            if (len > 0 && c >= starts[i] && c < starts[i] + len + 1) return i;
        }
        return -1;
    }

    private void beginStory(String id) {
        int n = id.startsWith("scary") && id.length() == 6 && Character.isDigit(id.charAt(5)) ? id.charAt(5) - '0' : 0;
        story = n;
        if (n == 0) return;
        startTyping();                                                        // a story is told slowly every time, not only the first
        scary.enter(n);
        if (!typing) ScaryStories.markRead(n);
    }

    /** The page is told letter by letter (every time it is opened, with the scary things on). A click shows the rest at once. */
    private void startTyping() {
        typing = Haunt.scary && totalChars > 0;
        reveal = typing ? 0 : Integer.MAX_VALUE;
        revealPause = 30;
    }

    private void finishReading() {
        typing = false;
        reveal = Integer.MAX_VALUE;
        if (story > 0) ScaryStories.markRead(story);
    }

    /** 0..1: how far the reader is (by scrolling or by the letters shown); it drives the vignette, the grain and the heartbeat. */
    private float storyProgress() {
        int ms = maxScroll();
        float sf = ms > 0 ? Math.min(1F, sy() / (float) ms) : -1F;
        float tf = typing && totalChars > 0 ? Math.min(1F, reveal / (float) totalChars) : -1F;
        if (sf < 0 && tf < 0) return 0.5F;
        return Math.max(sf, tf);
    }

    private void storyTick() {
        typeTick();
        scary.tick(Halloween.active(), storyProgress());
    }

    /** One tick of the typewriter (stories and the deep site). */
    private void typeTick() {
        if (typing) {
            if (revealPause > 0) revealPause--;
            else if (reveal >= totalChars) finishReading();
            else {
                int li = lineOfChar(reveal);
                if (li < 0 || lines.get(li).y() - sy() < VIEW_H - 8) {         // the story waits until the line is on the screen
                    String sx = plains.get(Math.max(0, li));
                    int at = li >= 0 ? reveal - starts[li] : 0;
                    char c = at < sx.length() ? sx.charAt(at) : '\n';
                    reveal++;
                    revealPause = c == '.' || c == '!' || c == '?' || c == '\u2026' ? 9 : c == ',' || c == ';' || c == ':' ? 4 : c == '\n' ? 7 : 0;
                }
            }
        }
    }

    /** A line of text; while a story is being told only the letters shown so far, with a blinking cursor. */
    private void text(GuiGraphics g, Font f, int li, RLine l, int x, int y, int color) {
        if (typing && li < plains.size()) {
            int total = plains.get(li).length();
            final int shown = Math.max(0, Math.min(total, reveal - starts[li]));
            if (shown <= 0) return;
            final FormattedCharSequence whole = l.seq();
            // the first letters of the line in the very same font and style as the finished line (no jump when the story ends)
            FormattedCharSequence part = sink -> {
                int[] n = {0};
                return whole.accept((idx, style, cp) -> n[0]++ < shown && sink.accept(idx, style, cp));
            };
            Skin.str(g, f, part, x, y, color, false);
            if (reveal < starts[li] + total + 1 && ticks % 30 < 18) Skin.rect(g, x + f.width(part) + 1, y, 1, 8, color);
            return;
        }
        Skin.str(g, f, l.seq(), x, y, color, false);
    }

    private String currentId() { return hIdx >= 0 ? history.get(hIdx) : "home"; }

    private boolean inHome() { return currentId().equals("home"); }

    private boolean inDeep() { return currentId().startsWith("deep"); }

    private boolean inSearch() { return currentId().startsWith("?"); }

    private boolean loading() { return loadT < 18; }

    private int sy() { return Math.round(scrollY); }

    private void reload() {
        String id = currentId();
        int keep = scroll;
        show(id);
        scroll = keep;
        clampScroll();
    }

    // ---------- navigation ----------
    private void open(String id) {
        if (id.equals("market")) { shell.open(new MarketApp()); return; }   // CuteMarket is a full app
        if (id.equals("wikirandom")) id = "wiki" + (1 + new java.util.Random().nextInt(WIKI_ARTICLES));
        if (id.equals("scary9") && !ScaryStories.ninthUnlocked()) id = "notfound";   // the ninth story does not exist yet
        if (id.startsWith("deep") && !(ScaryStories.deepUnlocked() && Haunt.scary)) id = "notfound";   // the deep site opens after every story
        if (id.equals("onionwall") && !Vpn.installed()) id = "notfound";            // the denied page is a secret until the VPN is bought
        if (!id.startsWith("?") && !PAGES.contains(id)) id = "notfound";
        while (history.size() > hIdx + 1) history.remove(history.size() - 1);
        history.add(id);
        hIdx = history.size() - 1;
        show(id);
    }

    private String addressOf(String id) {
        if (id.equals("home")) return "";
        if (id.equals("tube666")) return "cutetube.cute/666";
        if (id.equals("onionwall")) return Vpn.DARK_HOST;
        if (id.startsWith("?")) return "peep.cute/?q=" + id.substring(1);
        if (id.equals("deep")) return "scarystories.cute/???";
        if (id.startsWith("deep") && id.length() > 4) return "scarystories.cute/???/" + id.substring(4);
        if (id.startsWith("scary") && id.length() > 5) return "scarystories.cute/" + id.substring(5);
        if (id.startsWith("wiki") && id.length() > 4) return "pandapedia.cute/" + id.substring(4);
        for (Map.Entry<String, String> e : DOMAINS.entrySet()) if (e.getValue().equals(id)) return e.getKey();
        return "cute://" + id;
    }

    private void show(String id) {
        story = 0;
        typing = false;
        deepAmbient = false;
        deepSpec.clear();
        deepRowY.clear();
        scary.leave();
        address = addressOf(id);
        focus = false;
        fresh = false;
        scroll = 0;
        scrollY = 0;
        loadT = 0;
        if (!id.startsWith("?")) Progress.onPage(id);
        if (id.equals("home")) { lines.clear(); cards.clear(); contentH = 0; tube.close(); return; } // the start page is drawn by hand
        if (id.startsWith("tube")) { tube.setCursed(id.equals("tube666")); return; } // CuteTube draws itself (666 = the haunted one)
        tube.close(); // leaving it stops the video and the sound
        if (id.equals("mail")) return; // BeeMail draws itself
        if (id.equals("notfound")) { dino.reset(); return; } // the runner draws itself
        if (id.startsWith("?")) buildSearch(id.substring(1));
        else { layout(pageText(id)); beginStory(id); beginDeep(id); }
    }

    /** On the deep site every page after the entrance has the mood; the cipher page also learns where its hidden words are. */
    private void beginDeep(String id) {
        if (!id.startsWith("deep") || !Haunt.scary) return;
        if (id.length() > 4) {
            deepAmbient = true;
            ScaryStories.markDeep(id.charAt(4) - '0');
            if (id.equals("deep1")) for (RLine l : lines) if (l.kind() == 0) deepRowY.add(l.y());
        }
        if (!id.equals("deep1")) startTyping();                              // every page of the deep site is told letter by letter, every time (the cipher is just noise)
    }

    /**
     * The cipher page: rows of noise, and in some rows a gap that holds a real word. The word is drawn only near the flashlight.
     * The noise uses only letters the font has; it is the same for one player on one day.
     */
    private String deepCipher() {
        Font f = font();
        String name = ScaryStories.deepName().toUpperCase(Locale.ROOT);
        String[] words = {t("cutemod.deep.w0"), t("cutemod.deep.w1"), name, t("cutemod.deep.w3", ScaryStories.deepTime()),
                t("cutemod.deep.w4"), t("cutemod.deep.w5")};
        java.util.Random r = new java.util.Random(name.hashCode() * 31L + java.time.LocalDate.now().toEpochDay());
        final String alpha = "\u0410\u0411\u0412\u0413\u0414\u0415\u0416\u0417\u0418\u041a\u041b\u041c\u041d\u041e\u041f\u0420\u0421\u0422\u0423\u0424\u0425\u0426\u0427\u0428\u0429\u042d\u042e\u042f0123456789%=+*?/-\u042a\u042b\u042c";
        int max = TEXT_W - 6;
        StringBuilder sb = new StringBuilder("# ???\n");
        for (int row = 0; row < 30; row++) {
            int wi = row % 5 == 3 ? row / 5 : -1;                       // rows 3, 8, 13, 18, 23 and 28 hold the six words
            StringBuilder ln = new StringBuilder();
            if (wi >= 0 && wi < words.length) {
                int pre = 2 + r.nextInt(6);
                for (int i = 0; i < pre; i++) ln.append(alpha.charAt(r.nextInt(alpha.length())));
                int x = f.width(ln.toString());
                int need = f.width(words[wi]) + 10;
                StringBuilder gap = new StringBuilder();
                for (int i = 0; i < 80 && f.width(gap.toString()) < need; i++) gap.append(' ');
                ln.append(gap);
                deepSpec.add(new DeepWord(row, x, words[wi]));
            }
            for (int i = 0; i < 120 && f.width(ln.toString()) < max - 8; i++) ln.append(alpha.charAt(r.nextInt(alpha.length())));
            sb.append(f.plainSubstrByWidth(ln.toString(), max)).append('\n');
        }
        sb.append("\n~ ").append(t("cutemod.deep.foot")).append("\n> cute://deep0 | ").append(t("cutemod.deep.back"));
        return sb.toString();
    }

    /** The hidden words: invisible, they come out of the dark where the light of the flashlight is. */
    private void renderDeepWords(GuiGraphics g, Font f, int mx, int my, int scr) {
        for (DeepWord w : deepSpec) {
            if (w.row() >= deepRowY.size()) continue;
            int y = VIEW_Y + deepRowY.get(w.row()) - scr;
            if (y < VIEW_Y - 10 || y > VIEW_Y + VIEW_H) continue;
            int x = TEXT_X + w.x();
            double d = Math.hypot(mx - (x + f.width(w.text()) / 2.0), my - (y + 4));
            float k = (float) Math.max(0.0, Math.min(1.0, (60.0 - d) / 34.0));
            if (k < 0.04F) continue;
            Skin.str(g, f, w.text(), x, y, App.mix(0xFF2A060B, 0xFFFF3A3A, k), false);
        }
    }

    private String pageText(String id) {
        if (id.equals("deep1")) return deepCipher();
        String raw = id.equals("scary9") ? ScaryStories.ninth() : t("cutemod.page." + id);
        if (id.equals("scary")) raw = ScaryStories.index(raw);
        if (id.equals("wiki") && Progress.step() >= Progress.PART1) { // part 2: a ninth link appears
            raw = raw.replace("\n> cute://wikirandom", "\n> cute://wiki9 | " + t("cutemod.page.wiki.me") + "\n> cute://wikirandom");
        }
        return raw;
    }

    @Override
    public void back() {
        if (hIdx > 0) { hIdx--; show(history.get(hIdx)); }
    }

    private void forward() {
        if (hIdx < history.size() - 1) { hIdx++; show(history.get(hIdx)); }
    }

    private void go(String raw) {
        String in = raw.trim();
        if (in.isEmpty()) { address = addressOf(currentId()); return; }
        String low = in.toLowerCase(Locale.ROOT);
        if (low.startsWith("cute://")) { open(low.substring(7)); return; }
        String host = low.replaceFirst("^https?://", "").replaceFirst("^www\\.", "");
        String path = "";
        int slash = host.indexOf('/');
        if (slash >= 0) { path = host.substring(slash + 1); host = host.substring(0, slash); }
        if (host.equals("scarystories.cute") && path.matches("[1-9]")) { open("scary" + path); return; }
        if ((low.equals("???") || host.equals("scarystories.cute") && path.matches("\\?\\?\\?(/[0-9][a-c]?)?"))
                && ScaryStories.deepUnlocked() && Haunt.scary) {                 // the question marks open the deep site, but only after every story
            open(path.length() > 3 ? "deep" + path.substring(4) : "deep");
            return;
        }
        if (host.equals("pandapedia.cute") && path.matches("[1-8]")) { open("wiki" + path); return; }
        if (host.equals("pandapedia.cute") && path.equals("9") && Progress.step() >= Progress.PART1) { open("wiki9"); return; }
        if (host.equals("pandapedia.cute") && path.equals("random")) { open("wikirandom"); return; }
        if (host.equals("cutetube.cute") && path.equals("666") || low.equals("666")) { open("tube666"); return; }   // the secret address
        if (host.endsWith(".onion")) { openOnion(host); return; }            // the hidden sites: only through the VPN
        if (DOMAINS.containsKey(host)) { open(DOMAINS.get(host)); return; }
        if (PAGES.contains(low)) { open(low); return; }
        if (low.startsWith("http://") || low.startsWith("https://") || (!in.contains(" ") && in.contains("."))) {
            String url = low.startsWith("http") ? in : "https://" + in;
            address = addressOf(currentId());
            shell.openLink(url); // a real address: ask, then open in the system browser
            return;
        }
        open("?" + in); // plain words: search the cute internet
    }

    /** A hidden (.onion) address: the dark market opens only while the VPN tunnel is up, else the "access denied" page shows. */
    private void openOnion(String host) {
        if (!host.equals(Vpn.DARK_HOST) || !Vpn.installed()) { open("notfound"); return; }   // no such site (and no hint that there is one without the VPN app)
        if (Vpn.on()) {
            address = addressOf(currentId());
            shell.open(new DarkMarketApp());
        } else {
            open("onionwall");
        }
    }

    private void follow(String target) { go(target); }

    // ---------- page layout ----------
    /** Page format: "# heading", "> target | label" for links, "~ text" for small grey text, blank line = gap. */
    private void layout(String raw) {
        lines.clear();
        cards.clear();
        Font f = font();
        String page = currentId();
        int y = 8, cardTop = -1;
        for (String ln : raw.split("\n", -1)) {
            if (ln.isBlank()) {                                   // a blank line ends a block (a card)
                if (cardTop >= 0) { cards.add(new int[]{cardTop, y, 0}); cardTop = -1; }
                y += 12;
                continue;
            }
            if (cardTop < 0) cardTop = y;
            int kind = 0;
            String target = null, text = ln;
            if (ln.startsWith("@ ")) { // "@ name" = a picture (animated, drawn by WikiArt)
                lines.add(new RLine(FormattedCharSequence.EMPTY, 3, ln.substring(2).trim(), y));
                y += WikiArt.H + 6;
                continue;
            }
            int width = TEXT_W;
            if (ln.startsWith("# ")) {
                kind = 1;
                text = ln.substring(2);
                width = (int) (TEXT_W / HEAD_SCALE);
            } else if (ln.startsWith("~ ")) {
                kind = 4;
                text = ln.substring(2);
            } else if (ln.startsWith("> ") && ln.indexOf('|') > 0) {
                int bar = ln.indexOf('|');
                kind = 2;
                target = ln.substring(2, bar).trim();
                text = ln.substring(bar + 1).trim();
                width = TEXT_W - LINK_IND;
            }
            FormattedText ft = FormattedText.of(text);
            if (kind == 0 && POST.matcher(ln).matches()) {            // "@name: message" = a post with an avatar
                kind = 6;
                int c = ln.indexOf(": ");
                String handle = ln.substring(0, c);
                target = handle;
                ft = Component.literal(handle).withStyle(net.minecraft.network.chat.Style.EMPTY.withBold(true).withColor(handleColor(handle) & 0xFFFFFF))
                        .append(Component.literal(ln.substring(c)));
                width = TEXT_W - POST_IND;
            } else if (kind == 0 && page.equals("shop")) {            // "thing - 3 emeralds" = a product with a price tag
                java.util.regex.Matcher m = PRICE.matcher(ln);
                if (m.matches()) {
                    kind = 8;
                    target = m.group(2) + " " + m.group(3);
                    ft = FormattedText.of(m.group(1));
                    width = TEXT_W - 76;
                }
            }
            List<FormattedCharSequence> parts = f.split(ft, width);
            for (int i = 0; i < parts.size(); i++) {
                lines.add(new RLine(parts.get(i), kind, i == 0 ? target : null, y));
                y += kind == 1 ? 13 : kind == 2 ? 14 : kind == 8 ? (i == parts.size() - 1 ? 16 : 10) : 10;
            }
            if (kind == 1) {
                lines.add(new RLine(FormattedCharSequence.EMPTY, 5, null, y));   // short accent bar under the heading
                y += 8;
                cards.add(new int[]{cardTop, y, 1});                           // the title is a banner of its own
                cardTop = -1;
                y += 6;
            } else if (kind == 6 || (kind == 0 && page.equals("news"))) {
                y += 2;
                lines.add(new RLine(FormattedCharSequence.EMPTY, 7, null, y));   // a thin line between posts / headlines
                y += 5;
            }
        }
        if (cardTop >= 0) cards.add(new int[]{cardTop, y, 0});
        contentH = y + 8;
        indexText();
    }

    /** The colour of a site: the title banner, the link buttons and the price tags. */
    private int brand() {
        String id = currentId();
        if (id.startsWith("scary")) return 0xFFB3202A;
        if (id.startsWith("deep")) return 0xFF8A0F18;
        if (id.startsWith("wiki")) return 0xFF7A6AD0;
        return switch (id) {
            case "peep" -> 0xFFF06FA6;
            case "chirp" -> 0xFF4AA8F0;
            case "shop" -> 0xFF4CAF50;
            case "news" -> 0xFFE5534B;
            default -> ACCENT;
        };
    }

    private static int handleColor(String handle) {
        return java.awt.Color.HSBtoRGB(((handle.hashCode() & 0x7fffffff) % 360) / 360f, 0.55f, 0.85f);
    }

    private boolean inBanner(int ly) {
        for (int[] c : cards) if (c[2] == 1 && ly >= c[0] && ly < c[1]) return true;
        return false;
    }

    /** True for the divider that would hang at the bottom edge of its card. */
    private boolean lastInCard(int ly) {
        for (int[] c : cards) if (ly >= c[0] && ly < c[1]) return ly > c[1] - 7;
        return false;
    }

    private static String snippet(String page) {
        for (String ln : page.split("\n")) {
            String s = ln.trim();
            if (s.isEmpty() || s.startsWith("#") || s.startsWith(">") || s.startsWith("@") || s.startsWith("~")) continue;
            return s.length() > 90 ? s.substring(0, 87) + "..." : s;
        }
        return "";
    }

    /** Search inside the cute internet: pages are ranked by how many query words they contain. */
    private void buildSearch(String query) {
        String[] words = query.toLowerCase(Locale.ROOT).trim().split("\\s+");
        List<String> ids = new ArrayList<>();
        List<Integer> scores = new ArrayList<>();
        for (String id : SEARCHABLE) {
            String page = t("cutemod.page." + id);
            String low = page.toLowerCase(Locale.ROOT);
            int score = 0;
            for (String w : words) if (!w.isEmpty() && low.contains(w)) score++;
            if (score == 0) continue;
            int at = 0;
            while (at < ids.size() && scores.get(at) >= score) at++;
            ids.add(at, id);
            scores.add(at, score);
        }
        StringBuilder sb = new StringBuilder("# ").append(t("cutemod.os.search.results", query)).append('\n');
        if (ids.isEmpty()) sb.append(t("cutemod.os.search.none")).append('\n');
        for (String id : ids) {
            String page = t("cutemod.page." + id);
            int nl = page.indexOf('\n');
            String title = page.startsWith("# ") && nl > 2 ? page.substring(2, nl) : id;
            String domain = addressOf(id);
            sb.append("~ ").append(domain.startsWith("cute://") ? domain : "http://" + domain).append('\n');
            sb.append("> cute://").append(id).append(" | ").append(title.replace("|", "/")).append('\n');
            String snip = snippet(page);
            if (!snip.isEmpty()) sb.append("~ ").append(snip).append('\n');
            sb.append('\n');
        }
        sb.append("~ https://www.google.com\n");
        sb.append("> https://www.google.com/search?q=")
          .append(URLEncoder.encode(query, StandardCharsets.UTF_8))
          .append(" | ").append(t("cutemod.os.search.real")).append('\n');
        layout(sb.toString());
    }

    private int maxScroll() { return Math.max(0, contentH - VIEW_H); }

    private void clampScroll() { scroll = Math.max(0, Math.min(maxScroll(), scroll)); }

    // ---------- render ----------
    /** A rounded bar: h must be odd (radius = (h - 1) / 2). */
    private static void pill(GuiGraphics g, int x, int y, int w, int h, int col) {
        int r = (h - 1) / 2;
        Skin.rect(g, x + r, y, w - 2 * r, h, col);
        Skin.disc(g, x + r, y + r, r, col);
        Skin.disc(g, x + w - 1 - r, y + r, r, col);
    }

    /** A rounded VERTICAL bar (the scrollbar thumb): w must be odd (radius = (w - 1) / 2) and h >= w. */
    private static void vpill(GuiGraphics g, int x, int y, int w, int h, int col) {
        int r = (w - 1) / 2;
        Skin.rect(g, x, y + r, w, h - 2 * r, col);
        Skin.disc(g, x + r, y + r, r, col);
        Skin.disc(g, x + r, y + h - 1 - r, r, col);
    }

    private static void px(GuiGraphics g, int x, int y, int col) { Skin.rect(g, x, y, 1, 1, col); }

    private static void arrow(GuiGraphics g, int cx, int cy, int dir, int col) {
        Skin.rect(g, cx - 3, cy, 7, 1, col);
        for (int i = 0; i < 4; i++) {
            int x = dir < 0 ? cx - 3 + i : cx + 3 - i;
            px(g, x, cy - i, col);
            px(g, x, cy + i, col);
        }
    }

    private static void lock(GuiGraphics g, int x, int y, int col, int hole) {
        Skin.rect(g, x + 1, y, 3, 1, col);
        Skin.rect(g, x, y + 1, 1, 2, col);
        Skin.rect(g, x + 4, y + 1, 1, 2, col);
        Skin.rect(g, x - 1, y + 3, 7, 5, col);
        Skin.rect(g, x + 2, y + 5, 1, 2, hole);
    }

    private static void magnifier(GuiGraphics g, int x, int y, int col, int hole) {
        Skin.disc(g, x + 3, y + 3, 3, col);
        Skin.disc(g, x + 3, y + 3, 2, hole);
        for (int k = 0; k < 3; k++) px(g, x + 5 + k, y + 5 + k, col);
    }

    private void toolButton(GuiGraphics g, int x, boolean enabled, int mx, int my, int hoverCol) {
        if (enabled && in(mx, my, x, BTN_Y, BTN, BTN)) Skin.disc(g, x + 7, BTN_Y + 7, 7, hoverCol);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        boolean haunted = (inTube() && tube.haunted()) || inDeep();                 // the site at the address 666 and the deep site: a crimson toolbar
        boolean dark = currentId().startsWith("scary") || haunted;
        boolean deep = inDeep();                                                   // the deep site: the whole toolbar and the address bar are blood red
        int acc = deep ? 0xFFE01820 : haunted ? 0xFFA01018 : ACCENT;
        int ink = deep ? 0xFFFFB4AA : haunted ? 0xFFEBCFC8 : dark ? 0xFFE4DCEA : 0xFF3A2A3A, muted = deep ? 0xFFD05A5A : haunted ? 0xFFB05A5A : dark ? 0xFF8E8496 : 0xFF8A7A98;
        int tbA = deep ? 0xFF5A0810 : haunted ? 0xFF3A0508 : dark ? 0xFF1F1824 : 0xFFF8F3FC, tbB = deep ? 0xFF32050A : haunted ? 0xFF220306 : dark ? 0xFF181320 : 0xFFEDE4F5;
        int hoverCol = deep ? 0xFF7A0F1A : haunted ? 0xFF5A0A12 : dark ? 0xFF3A3044 : 0xFFDCD0EA;
        Skin.rect(g, 0, 0, W, H, deep ? 0xFF1A0004 : haunted ? 0xFF0D0204 : dark ? 0xFF0D0A10 : 0xFFFFFAFD);

        // ----- toolbar -----
        Skin.grad(g, 0, 0, W, VIEW_Y - 1, tbA, tbB);
        Skin.rect(g, 0, VIEW_Y - 1, W, 1, deep ? 0xFFB01420 : haunted ? 0xFF7A0C14 : dark ? 0xFF3A2E44 : 0xFFD6C8E4);
        boolean canBack = hIdx > 0, canFwd = hIdx < history.size() - 1;
        toolButton(g, BTN_BACK, canBack, mx, my, hoverCol);
        toolButton(g, BTN_FWD, canFwd, mx, my, hoverCol);
        toolButton(g, BTN_RELOAD, true, mx, my, hoverCol);
        toolButton(g, BTN_HOME, true, mx, my, hoverCol);
        int off = deep ? 0xFF7A3A3A : haunted ? 0xFF5A2A2A : dark ? 0xFF4A4054 : 0xFFB7AAC4;
        arrow(g, BTN_BACK + 7, BTN_Y + 7, -1, canBack ? ink : off);
        arrow(g, BTN_FWD + 7, BTN_Y + 7, 1, canFwd ? ink : off);
        // reload (a cross while the page is loading)
        int rx = BTN_RELOAD + 7, ry = BTN_Y + 7;
        if (loading()) {
            for (int i = -3; i <= 3; i++) { px(g, rx + i, ry + i, ink); px(g, rx + i, ry - i, ink); }
        } else {
            int rbg = in(mx, my, BTN_RELOAD, BTN_Y, BTN, BTN) ? hoverCol : tbB;
            Skin.disc(g, rx, ry, 4, ink);
            Skin.disc(g, rx, ry, 2, rbg);
            Skin.rect(g, rx + 1, ry - 5, 5, 4, rbg);
            Skin.rect(g, rx + 1, ry - 4, 3, 1, ink);
            px(g, rx + 3, ry - 5, ink); px(g, rx + 3, ry - 3, ink); px(g, rx + 4, ry - 4, ink);
            px(g, rx + 3, ry - 4, ink);
        }
        // home
        int hx = BTN_HOME + 3, hy = BTN_Y + 3;
        Skin.rect(g, hx + 1, hy + 4, 6, 5, ink);
        Skin.rect(g, hx, hy + 3, 8, 1, ink);
        Skin.rect(g, hx + 1, hy + 2, 6, 1, ink);
        Skin.rect(g, hx + 2, hy + 1, 4, 1, ink);
        Skin.rect(g, hx + 3, hy, 2, 1, ink);

        // address pill
        boolean overBar = in(mx, my, BAR_X, BAR_Y, BAR_W, BAR_H);
        if (focus) pill(g, BAR_X - 1, BAR_Y - 1, BAR_W + 2, BAR_H + 2, acc);
        int pillCol = deep ? (focus || overBar ? 0xFF8A1220 : 0xFF6A0C16) : haunted ? (focus || overBar ? 0xFF2E060A : 0xFF1A0204) : focus || overBar ? (dark ? 0xFF3A3042 : 0xFFFFFFFF) : (dark ? 0xFF2C2433 : 0xFFEAE2F3);
        pill(g, BAR_X, BAR_Y, BAR_W, BAR_H, pillCol);
        boolean searchy = focus || inHome() || inSearch();
        if (searchy) magnifier(g, BAR_X + 6, BAR_Y + 4, muted, pillCol);
        else lock(g, BAR_X + 7, BAR_Y + 3, muted, pillCol);
        int tx = BAR_X + 17, tmax = BAR_W - 17 - 8;
        if (focus) {
            String shown = address;
            while (shown.length() > 1 && f.width(shown) > tmax) shown = shown.substring(1);
            int tw = f.width(shown);
            if (fresh && !shown.isEmpty()) Skin.rect(g, tx - 1, BAR_Y + 2, tw + 2, 11, acc);
            Skin.str(g, f, shown, tx, BAR_Y + 4, fresh ? 0xFFFFFFFF : ink, false);
            if (!fresh && (ticks / 30) % 2 == 0) Skin.rect(g, tx + tw, BAR_Y + 3, 1, 9, ink);
        } else if (address.isEmpty()) {
            Skin.str(g, f, f.plainSubstrByWidth(t("cutemod.os.browser.search"), tmax), tx, BAR_Y + 4, muted, false);
        } else {
            String shown = f.plainSubstrByWidth(address, tmax);
            int slash = address.startsWith("cute://") ? -1 : shown.indexOf('/');
            if (slash < 0) {
                Skin.str(g, f, shown, tx, BAR_Y + 4, ink, false);
            } else {
                String host = shown.substring(0, slash);
                Skin.str(g, f, host, tx, BAR_Y + 4, ink, false);
                Skin.str(g, f, shown.substring(slash), tx + f.width(host), BAR_Y + 4, muted, false);
            }
        }
        // loading line under the toolbar
        if (loadT < 26) {
            float p = Math.min(1f, loadT / 18f);
            p = 1 - (1 - p) * (1 - p);
            int alpha = loadT < 18 ? 255 : Math.max(0, (26 - loadT) * 32);
            Skin.rect(g, 0, VIEW_Y - 3, Math.round(W * p), 2, (alpha << 24) | (acc & 0xFFFFFF));
        }

        if (inMail()) { // BeeMail: no page, no ad, the inbox takes the whole area
            g.pose().pushPose();
            g.pose().translate(0, VIEW_Y, 0);
            mail.render(g, mx, my - VIEW_Y);
            g.pose().popPose();
            return;
        }

        if (inTube()) { // no page, no ad: the video site takes the whole area
            g.pose().pushPose();
            g.pose().translate(0, VIEW_Y, 0);
            tube.render(g, mx, my - VIEW_Y);
            g.pose().popPose();
            return;
        }

        if (inDino()) { // no page, no ad: the runner takes the whole area
            g.enableScissor(shell.absX(), shell.absY() + VIEW_Y, shell.absX() + W, shell.absY() + H);
            g.pose().pushPose();
            g.pose().translate(0, VIEW_Y, 0);
            dino.render(g);
            g.pose().popPose();
            g.disableScissor();
            return;
        }

        // ----- page -----
        g.enableScissor(shell.absX(), shell.absY() + VIEW_Y, shell.absX() + W, shell.absY() + VIEW_Y + VIEW_H);
        if (!inHome()) Skin.rect(g, 0, VIEW_Y, W, VIEW_H, inDeep() ? 0xFF1A0004 : dark ? 0xFF0D0A10 : 0xFFF1F3F9);
        if (inHome()) renderHome(g, mx, my);
        int scr = sy();
        int brand = brand(), brandDark = App.mix(brand, 0xFF000000, 0.28f);
        for (int[] c : cards) {                                              // the cards (and the title banner) behind the text
            int cy = VIEW_Y + c[0] - scr - 4, ch = c[1] - c[0] + 7;
            if (cy > VIEW_Y + VIEW_H || cy + ch < VIEW_Y) continue;
            if (c[2] == 1) {
                int rr = Math.min(20, ch / 2 - 2);
                roundRect(g, CARD_X + 1, cy + 1, CARD_W, ch, 6, 0x22000000);
                roundRect(g, CARD_X, cy, CARD_W, ch, 6, dark ? App.mix(brand, 0xFF000000, 0.55f) : brand);
                if (rr > 4) Skin.disc(g, CARD_X + CARD_W - rr - 8, cy + ch / 2, rr, 0x22FFFFFF);
            } else {
                roundRect(g, CARD_X + 1, cy + 1, CARD_W, ch, 5, dark ? 0x55000000 : 0x14203050);
                roundRect(g, CARD_X, cy, CARD_W, ch, 5, inDeep() ? 0xFF2A060B : dark ? 0xFF1A141F : 0xFFFFFFFF);
            }
        }
        for (int li = 0; li < lines.size(); li++) {
            RLine l = lines.get(li);
            int y = VIEW_Y + l.y() - scr;
            int rowH = l.kind() == 3 ? WikiArt.H : 16;
            if (typing && l.kind() == 2) continue;                       // the links wait until the story is told
            if (y < VIEW_Y - rowH || y > VIEW_Y + VIEW_H) continue;
            boolean banner = inBanner(l.y());
            int body = inDeep() ? (currentId().equals("deep1") ? 0xFF6E1620 : 0xFFD8A8A8) : dark ? 0xFFC9C2CC : banner ? 0xFFEAF2FF : 0xFF3A2A3A;
            switch (l.kind()) {
                case 3 -> { if (y + WikiArt.H >= VIEW_Y) WikiArt.draw(g, l.target(), TEXT_X, y, ticks); }
                case 5 -> Skin.rect(g, TEXT_X, y, 22, 2, banner ? 0xAAFFFFFF : (dark ? 0xFFB3202A : brand));
                case 7 -> { if (!lastInCard(l.y())) Skin.rect(g, TEXT_X, y, TEXT_W, 1, dark ? 0xFF2A2230 : 0xFFECEEF5); }
                case 1 -> {
                    g.pose().pushPose();
                    g.pose().translate(TEXT_X, y, 0);
                    g.pose().scale(HEAD_SCALE, HEAD_SCALE, 1f);
                    Skin.str(g, f, l.seq(), 0, 0, banner ? 0xFFFFFFFF : dark ? 0xFFD9363F : brandDark, false);
                    g.pose().popPose();
                }
                case 2 -> {                                                  // a link is a soft button in the colour of the site
                    int w = f.width(l.seq());
                    boolean hover = in(mx, my, TEXT_X - 3, y - 2, w + LINK_IND + 6, 13) && my >= VIEW_Y && my < VIEW_Y + VIEW_H;
                    int tint = dark ? (hover ? 0xFF3A2028 : 0xFF2A1A22) : App.mix(brand, 0xFFFFFFFF, hover ? 0.72f : 0.88f);
                    int col = dark ? (hover ? 0xFFFF8A80 : 0xFFD9534F) : brandDark;
                    pill(g, TEXT_X - 3, y - 2, w + LINK_IND + 6, 13, tint);
                    for (int k = 0; k < 3; k++) { px(g, TEXT_X + 1 + k, y + 2 + k, col); px(g, TEXT_X + 1 + k, y + 6 - k, col); }
                    Skin.str(g, f, l.seq(), TEXT_X + LINK_IND, y, col, false);
                }
                case 4 -> text(g, f, li, l, TEXT_X, y, banner ? 0xCCFFFFFF : muted);
                case 6 -> {                                                  // a post: avatar + "@name: message"
                    if (l.target() != null) {
                        int cx = TEXT_X + 8, cyy = y + 5;
                        Skin.disc(g, cx, cyy, 7, handleColor(l.target()));
                        Skin.cstr(g, f, String.valueOf(Character.toUpperCase(l.target().charAt(1))), cx, cyy - 4, 0xFFFFFFFF);
                    }
                    Skin.str(g, f, l.seq(), TEXT_X + POST_IND, y, body, false);
                }
                case 8 -> {                                                  // a product: a little tile, the name, a price tag
                    if (l.target() != null) {
                        roundRect(g, TEXT_X, y - 1, 9, 9, 2, brand);
                        String price = l.target();
                        int pw = f.width(price) + 10;
                        pill(g, CARD_X + CARD_W - 6 - pw, y - 2, pw, 13, brand);
                        Skin.str(g, f, price, CARD_X + CARD_W - 6 - pw + 5, y, 0xFFFFFFFF, false);
                    }
                    Skin.str(g, f, l.seq(), TEXT_X + 14, y, body, false);
                }
                default -> text(g, f, li, l, TEXT_X, y, body);
            }
        }
        if (deepAmbient && currentId().equals("deep1")) renderDeepWords(g, f, mx, my, scr);
        if (dark) renderScareEffects(g);
        if ((story > 0 || deepAmbient) && Haunt.scary) scary.renderFx(g, mx, my, W, VIEW_Y, VIEW_H, storyProgress(), Halloween.active() || deepAmbient, ticks);
        if (scr > 2) Skin.grad(g, 0, VIEW_Y, W, VIEW_Y + 4, dark ? 0x66000000 : 0x24402060, 0x00000000); // shadow under the toolbar
        g.disableScissor();

        // scrollbar
        if (contentH > VIEW_H) {
            boolean overBarZone = mx >= W - 9 && my >= VIEW_Y && my < VIEW_Y + VIEW_H;
            int bw = overBarZone ? 5 : 3;                      // odd, so the round ends are symmetric
            int th = Math.max(14, VIEW_H * VIEW_H / contentH);
            int ty = VIEW_Y + (VIEW_H - th) * Math.min(scr, maxScroll()) / Math.max(1, maxScroll());
            vpill(g, W - 3 - bw, ty, bw, th, dark ? 0xFF6A4A7A : 0xFFC3A4DC);
        }

        renderAd(g, mx, my);
    }

    // ---------- start page ----------
    private void renderHome(GuiGraphics g, int mx, int my) {
        Font f = font();
        int y0 = VIEW_Y;
        // title, every letter has its own color
        String title = "Cute Web";
        g.pose().pushPose();
        g.pose().translate((W - f.width(title) * 2) / 2f, y0 + 6, 0);
        g.pose().scale(2f, 2f, 1f);
        int acc = 0;
        for (int i = 0; i < title.length(); i++) {
            String c = String.valueOf(title.charAt(i));
            int col = 0xFF000000 | java.awt.Color.HSBtoRGB((i * 0.11f + 0.88f) % 1f, 0.45f, 0.88f);
            Skin.str(g, f, c, acc, 0, col, false);
            acc += f.width(c);
        }
        g.pose().popPose();

        // search box
        int sx = SEARCH_X, sy = y0 + 30;
        boolean over = in(mx, my, sx, sy, SEARCH_W, SEARCH_H);
        pill(g, sx - 1, sy - 1, SEARCH_W + 2, SEARCH_H + 2, focus ? ACCENT : over ? 0xFFB9A3D6 : 0xFFDCCFEA);
        pill(g, sx, sy, SEARCH_W, SEARCH_H, 0xFFFFFFFF);
        magnifier(g, sx + 7, sy + 4, 0xFF8A7A98, 0xFFFFFFFF);
        int tx = sx + 19, tmax = SEARCH_W - 19 - 10;
        if (focus) {
            String shown = address;
            while (shown.length() > 1 && f.width(shown) > tmax) shown = shown.substring(1);
            int tw = f.width(shown);
            if (fresh && !shown.isEmpty()) Skin.rect(g, tx - 1, sy + 2, tw + 2, 11, ACCENT);
            Skin.str(g, f, shown, tx, sy + 4, fresh ? 0xFFFFFFFF : 0xFF3A2A3A, false);
            if (!fresh && (ticks / 30) % 2 == 0) Skin.rect(g, tx + tw, sy + 3, 1, 9, 0xFF3A2A3A);
        } else {
            Skin.str(g, f, f.plainSubstrByWidth(t("cutemod.os.browser.search"), tmax), tx, sy + 4, 0xFF9A8FA8, false);
        }

        // shortcut tiles: 3 x 3 (a round icon, the name to the right of it)
        for (int i = 0; i < TILE_ID.length; i++) {
            int tx0 = (i % TILE_COLS) * TILE_W, cx = tx0 + 15, cy = y0 + 62 + (i / TILE_COLS) * TILE_H;
            boolean hover = in(mx, my, tx0, cy - TILE_H / 2, TILE_W, TILE_H);
            if (hover) Skin.disc(g, cx, cy, 11, App.mix(TILE_COLOR[i], 0xFFFFFFFF, 0.78f));
            Skin.disc(g, cx, cy, 9, TILE_COLOR[i]);
            Skin.disc(g, cx - 3, cy - 4, 2, App.mix(TILE_COLOR[i], 0xFFFFFFFF, 0.35f)); // a little shine
            Skin.cstr(g, f, TILE_LETTER[i], cx, cy - 4, 0xFFFFFFFF);
            Skin.str(g, f, f.plainSubstrByWidth(TILE_NAME[i], TILE_W - 30), tx0 + 29, cy - 4, hover ? 0xFF1F5FBF : 0xFF5A4A68, false);
        }
    }

    /** Creepy extras for the scary site: flickering light and a pair of eyes that watch from the corners. */
    private void renderScareEffects(GuiGraphics g) {
        int phase = (Halloween.active() ? ticks * 3 / 2 : ticks) % 400;       // in the event the eyes and the dark come more often
        if ((phase >= 380 && phase < 384) || (phase >= 390 && phase < 392)) {
            Skin.rect(g, 0, VIEW_Y, W, VIEW_H, 0xB0000000);
        }
        if (phase >= 150 && phase < 200) {
            boolean blink = phase >= 172 && phase < 178;
            int slot = (ticks / 400) % 4;
            int ex = slot == 0 ? 14 : slot == 1 ? W - 40 : slot == 2 ? 24 : W - 60;
            int ey = slot == 0 ? VIEW_Y + VIEW_H - 18 : slot == 1 ? VIEW_Y + 30 : slot == 2 ? VIEW_Y + 70 : VIEW_Y + VIEW_H - 40;
            Skin.rect(g, ex - 2, ey - 2, 22, 7, 0x33FF0000);
            if (!blink) {
                Skin.rect(g, ex, ey, 6, 3, 0xFFFF2A2A);
                Skin.rect(g, ex + 12, ey, 6, 3, 0xFFFF2A2A);
                Skin.rect(g, ex + 2, ey + 1, 2, 1, 0xFF000000);
                Skin.rect(g, ex + 14, ey + 1, 2, 1, 0xFF000000);
            } else {
                Skin.rect(g, ex, ey + 1, 6, 1, 0xFF7A1010);
                Skin.rect(g, ex + 12, ey + 1, 6, 1, 0xFF7A1010);
            }
        }
    }

    // ---------- animated ads ----------
    private int adTime() { return ticks + adSkip; }

    private int adIndex() { return (adTime() / AD_TICKS) % AD_COUNT; }

    /** Every sixth ad is "corrupted" (only when the scary stuff is switched on). */
    private boolean hauntedAd() { return Haunt.scary && (inDeep() || (adTime() / AD_TICKS) % 6 == 5); }   // on the deep site every ad is the corrupted one

    private String adTarget(int idx) {
        if (hauntedAd()) return "scary";
        return switch (idx) {
            case 0 -> "shop";
            case 1 -> "mail";
            case 2 -> "chirp";
            default -> "scary";
        };
    }

    private void renderAd(GuiGraphics g, int mx, int my) {
        Font f = font();
        int idx = adIndex();
        int t = adTime() % AD_TICKS;
        int slide = t < 16 ? (int) ((1 - t / 16.0) * (1 - t / 16.0) * W) : 0; // slides in from the right

        g.enableScissor(shell.absX(), shell.absY() + AD_Y, shell.absX() + W, shell.absY() + AD_Y + AD_H);
        g.pose().pushPose();
        g.pose().translate(slide, AD_Y, 0);
        String msg = hauntedAd() ? t("cutemod.ad.h" + (adTime() / AD_TICKS / 6) % 3) : t("cutemod.ad." + idx);
        int tw = f.width(msg);
        String adLabel = t("cutemod.ad.label");
        int textRight = W - f.width(adLabel) - 26;                          // the text must end before the "Ad" label and the close button
        if (hauntedAd()) { // corrupted ad: flickers, shakes and stares back
            Skin.rect(g, 0, 0, W, AD_H, 0xFF000000);
            int shake = (t % 9 < 2) ? (t % 3) - 1 : 0;
            boolean off = (t % 37) > 31;
            Skin.box(g, f, msg, 6 + shake, 5, off ? 0xFF3A0A10 : 0xFFFF2A2A, false, textRight - 6 - 24);
            if (t % 60 < 45) {
                Skin.rect(g, 205, 6, 6, 3, 0xFFFF2A2A);
                Skin.rect(g, 217, 6, 6, 3, 0xFFFF2A2A);
            }
            for (int k = 0; k < 3; k++) { // static noise
                int ny = (t * 7 + k * 5) % AD_H;
                Skin.rect(g, (t * 13 + k * 90) % W, ny, 30, 1, 0x55FFFFFF);
            }
        } else switch (idx) {
            case 0 -> { // CreeperMart: blinking sale, pulsing creeper
                Skin.rect(g, 0, 0, W, AD_H, (t / 12) % 2 == 0 ? 0xFF2E7D32 : 0xFF388E3C);
                int pulse = (int) Math.round(Math.sin(t / 6.0) * 1.5);
                int cs = 12 + pulse, cx = 4 - pulse / 2, cy = (AD_H - cs) / 2;
                Skin.rect(g, cx, cy, cs, cs, 0xFF5BBF6A);
                Skin.rect(g, cx + 2, cy + 3, 3, 3, 0xFF1B3A1B);
                Skin.rect(g, cx + cs - 5, cy + 3, 3, 3, 0xFF1B3A1B);
                Skin.rect(g, cx + cs / 2 - 1, cy + 6, 2, 4, 0xFF1B3A1B);
                Skin.box(g, f, msg, 24, 5, (t / 10) % 2 == 0 ? 0xFFFFEB3B : 0xFFFFFFFF, true, textRight - 24);
            }
            case 1 -> { // BeeMail: a bee buzzes across the banner
                Skin.rect(g, 0, 0, W, AD_H, 0xFFFFF3B0);
                Skin.boxC(g, f, msg, 4, 5, 0xFF5A3A00, false, textRight - 4);
                int bx = (t * 3) % (W + 40) - 20;
                int by = 4 + (int) Math.round(Math.sin(t / 5.0) * 3);
                int flap = (t / 4) % 2;
                Skin.rect(g, bx + 1, by + flap * 2, 3, 3, 0xDDFFFFFF);
                Skin.rect(g, bx + 7, by + flap * 2, 3, 3, 0xDDFFFFFF);
                Skin.rect(g, bx, by + 3, 10, 6, 0xFFF5C518);
                Skin.rect(g, bx + 3, by + 3, 1, 6, 0xFF2A2A2A);
                Skin.rect(g, bx + 6, by + 3, 1, 6, 0xFF2A2A2A);
                Skin.rect(g, bx + 8, by + 4, 1, 1, 0xFF2A2A2A);
            }
            case 2 -> { // Panda Pizza: rainbow marquee
                Skin.grad(g, 0, 0, W, AD_H, 0xFFFFD6E8, 0xFFFFB3D1);
                int span = tw + 40;
                for (int k = 0; k < 2; k++) {
                    int x = W - (t * 2) % span + k * span - span;
                    int col = java.awt.Color.HSBtoRGB(((t + k * 30) % 120) / 120f, 0.7f, 0.85f);
                    CuteFont.draw(g, f, msg, x, 5, Skin.ink(0xFF000000 | col), false);
                }
                Skin.rect(g, 0, 0, 3, AD_H, 0xFFFFFFFF);
                Skin.rect(g, W - 3, 0, 3, AD_H, 0xFFFFFFFF);
            }
            default -> { // Scary stories: dark banner with flickering text and eyes
                Skin.rect(g, 0, 0, W, AD_H, 0xFF0D0A10);
                boolean off = (t % 70) > 62 && (t % 4) < 2;
                Skin.box(g, f, msg, 6, 5, off ? 0xFF3A0A10 : 0xFFD9534F, false, textRight - 6 - 24);
                if ((t % 90) < 70) {
                    int ex = 200 + (t / 90 % 2) * 15;
                    Skin.rect(g, ex, 7, 5, 3, 0xFFFF2A2A);
                    Skin.rect(g, ex + 10, 7, 5, 3, 0xFFFF2A2A);
                }
            }
        }
        // "Ad" label and a close button that only closes this one ad
        String label = adLabel;
        Skin.rect(g, W - f.width(label) - 22, 1, f.width(label) + 3, 9, 0x88000000);
        Skin.str(g, f, label, W - f.width(label) - 20, 2, 0xFFFFFFFF, false);
        boolean hoverX = in(mx, my, W - 14, AD_Y + 2, 11, 11);
        Skin.rect(g, W - 14, 2, 11, 11, hoverX ? 0xFFFFFFFF : 0xCCFFFFFF);
        Skin.str(g, f, "x", W - 11, 3, 0xFF3A2A3A, false);
        g.pose().popPose();
        g.disableScissor();
        Skin.rect(g, 0, AD_Y - 1, W, 1, inDeep() ? 0xFF7A0C14 : 0xFFC9B8D8);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (inMail() && y >= VIEW_Y) {
            if (focus) { focus = false; fresh = false; address = addressOf(currentId()); }
            mail.click(x, y - VIEW_Y, button);
            return true;
        }
        if (inDino() && y >= VIEW_Y) {
            if (focus) { focus = false; fresh = false; address = addressOf(currentId()); }
            dino.click(x, y - VIEW_Y, button);
            return true;
        }
        if (inTube() && y >= VIEW_Y) {
            if (focus) { focus = false; fresh = false; address = addressOf(currentId()); }
            tube.click(x, y - VIEW_Y, button);
            return true;
        }
        if (y >= AD_Y) {
            if (in(x, y, W - 14, AD_Y + 2, 11, 11)) { // close: the next ad takes its place
                adSkip += AD_TICKS - adTime() % AD_TICKS;
            } else {
                follow(adTarget(adIndex()));
            }
            return true;
        }
        if (y < VIEW_Y) {
            if (in(x, y, BTN_BACK, BTN_Y, BTN, BTN)) { back(); return true; }
            if (in(x, y, BTN_FWD, BTN_Y, BTN, BTN)) { forward(); return true; }
            if (in(x, y, BTN_RELOAD, BTN_Y, BTN, BTN)) {
                if (loading()) loadT = 99; else reload();   // a cross while loading just stops the line
                return true;
            }
            if (in(x, y, BTN_HOME, BTN_Y, BTN, BTN)) { open("home"); return true; }
            if (in(x, y, BAR_X, BAR_Y, BAR_W, BAR_H)) {
                if (!focus) { focus = true; fresh = true; }
                return true;
            }
            return true;
        }
        if (inHome()) {
            if (in(x, y, SEARCH_X, VIEW_Y + 30, SEARCH_W, SEARCH_H)) {
                if (!focus) { focus = true; fresh = false; address = ""; }
                return true;
            }
            if (focus) { focus = false; fresh = false; address = addressOf("home"); }
            for (int i = 0; i < TILE_ID.length; i++) {
                int tx0 = (i % TILE_COLS) * TILE_W, cy = VIEW_Y + 62 + (i / TILE_COLS) * TILE_H;
                if (in(x, y, tx0, cy - TILE_H / 2, TILE_W, TILE_H)) { open(TILE_ID[i]); return true; }
            }
            return true;
        }
        if (focus) { focus = false; fresh = false; address = addressOf(currentId()); }
        if (typing) { finishReading(); return true; }       // a click tells the rest of the story at once
        Font f = font();
        for (RLine l : lines) {
            if (l.kind() != 2) continue;
            int ly = VIEW_Y + l.y() - sy();
            if (in(x, y, TEXT_X - 3, ly - 2, f.width(l.seq()) + LINK_IND + 6, 13)) {
                follow(l.target());
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (focus) {
            if (keyCode == 257 || keyCode == 335) { // enter
                focus = false;
                fresh = false;
                go(address);
                return true;
            }
            if (keyCode == 256) { // escape: leave the address bar, don't close the computer
                focus = false;
                fresh = false;
                address = addressOf(currentId());
                return true;
            }
            if (keyCode == 259) { // backspace
                if (fresh) { address = ""; fresh = false; }
                else if (!address.isEmpty()) address = address.substring(0, address.length() - 1);
                return true;
            }
            if (keyCode == 65 && Screen.hasControlDown()) { // ctrl+a: select the whole address
                fresh = !address.isEmpty();
                return true;
            }
            if (keyCode == 67 && Screen.hasControlDown()) { // ctrl+c: copy the address
                Minecraft.getInstance().keyboardHandler.setClipboard(address);
                return true;
            }
            if (keyCode == 86 && Screen.hasControlDown()) { // ctrl+v
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) {
                    clip = clip.replace("\n", "").replace("\r", "").trim();
                    if (fresh) { address = ""; fresh = false; }
                    address = (address + clip);
                    if (address.length() > 300) address = address.substring(0, 300);
                }
                return true;
            }
            return false;
        }
        if (keyCode == 294 || (keyCode == 82 && Screen.hasControlDown())) { reload(); return true; } // F5, Ctrl+R
        if (Screen.hasAltDown() && keyCode == 263) { back(); return true; }                         // Alt+Left
        if (Screen.hasAltDown() && keyCode == 262) { forward(); return true; }                      // Alt+Right
        if (inTube()) return tube.key(keyCode, modifiers);
        if (inMail()) return mail.key(keyCode, modifiers);
        if (inDino()) return dino.key(keyCode);
        switch (keyCode) {
            case 265 -> scroll -= 12;   // up
            case 264 -> scroll += 12;   // down
            case 266 -> scroll -= VIEW_H - 12; // page up
            case 267 -> scroll += VIEW_H - 12; // page down
            case 268 -> scroll = 0;     // home
            case 269 -> scroll = maxScroll(); // end
            default -> { return false; }
        }
        clampScroll();
        return true;
    }

    @Override
    public boolean charTyped(char c) {
        if (!focus) {
            if (inHome() && c >= 32 && c != 127) { focus = true; fresh = false; address = String.valueOf(c); return true; }
            return (inTube() && tube.charTyped(c)) || (inMail() && mail.charTyped(c));
        }
        if (c < 32 || c == 127) return false;
        if (fresh) { address = ""; fresh = false; }
        if (address.length() < 300) address += c;
        return true;
    }

    @Override
    public boolean drag(int x, int y, int button) {
        return inTube() && tube.drag(x, y - VIEW_Y, button);
    }

    @Override
    public boolean scroll(double amount) {
        if (inTube()) return tube.scroll(amount);
        if (inMail()) return mail.scroll(amount);
        if (inDino()) return true;
        scroll -= (int) Math.round(amount * 24);
        clampScroll();
        return true;
    }
}
