package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.core.Holder;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * ShadeVPN: a bought app (CuteStore). A big neon shield with a power button, a list of servers and, once the first tunnel has been
 * up, a banner that shows where the hidden network is. While the tunnel is up the dark market (noir.onion) can be opened,
 * from here or by typing its address into the browser.
 */
public class VpnApp extends App {

    @Override
    public boolean needsNet() { return true; }

    private static final int BG1 = 0xFF080B1E, BG2 = 0xFF1C0F40;
    private static final int CYAN = 0xFF4CE0F0, MAGENTA = 0xFFFF4FD8, GREEN = 0xFF3DF2A0, AMBER = 0xFFF0B820, RED = 0xFFFF5470;
    private static final int TEXT = 0xFFE8ECFF, MUTED = 0xFF8A93C8, PANEL = 0xCC121838, LINE = 0xFF2A3266;

    private static final int PX = 67, PY = 66, PR = 31;                 // the power button
    private static final int LIST_X = 136, LIST_Y = 30, ROW_H = 22, ROW_W = 156;
    private static final int BANNER_Y = 140, BANNER_H = 22;

    private int ticks, sel = -1, mx = -1, my = -1;
    private boolean wasOn, wasConnecting;

    @Override
    public Component title() { return Component.translatable("cutemod.os.vpn"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.vpn"); }

    @Override
    public Component status() {
        return Vpn.on() ? Component.translatable("cutemod.vpn.status.on", t("cutemod.vpn.srv." + Vpn.current().id())) : Component.empty();
    }

    @Override
    public boolean background() { return true; }          // the tunnel stays up while the window is minimized

    @Override
    public void mouse(int x, int y) { mx = x; my = y; }

    @Override
    public void tick() {
        ticks++;
        if (sel < 0) sel = Vpn.server() >= 0 ? Vpn.server() : Vpn.favourite();
        boolean on = Vpn.on();
        boolean connecting = Vpn.connecting();
        if (on && !wasOn) Sfx.ui(sv(SoundEvents.BEACON_ACTIVATE), 1.3f, 0.5f);
        if (!on && wasOn && !connecting) Sfx.ui(sv(SoundEvents.BEACON_DEACTIVATE), 1.1f, 0.4f);
        if (connecting && !wasConnecting) Sfx.ui(sv(SoundEvents.NOTE_BLOCK_BIT), 1.6f, 0.4f);
        wasOn = on;
        wasConnecting = connecting;
    }

    private static SoundEvent sv(SoundEvent e) { return e; }

    private static SoundEvent sv(Holder<SoundEvent> h) { return h.value(); }

    // ---------- drawing helpers ----------
    private static void txt(GuiGraphics g, String s, int x, int y, int argb) { Skin.str(g, font(), s, x, y, argb, false); }

    private static void ctxt(GuiGraphics g, String s, int cx, int y, int argb) { Skin.str(g, font(), s, cx - font().width(s) / 2, y, argb, false); }

    private static int alpha(int rgb, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF); }

    /** A shield made of rows: a flat top and a rounded point at the bottom. */
    private static void shield(GuiGraphics g, int cx, int top, int w, int h, int argb) {
        for (int dy = 0; dy < h; dy++) {
            double hw = w / 2.0;
            double k = dy < h * 0.42 ? 1.0 : 1.0 - Math.pow((dy - h * 0.42) / (h * 0.58), 1.7);
            int half = (int) Math.round(hw * Math.max(0.0, k));
            if (dy < 2) half = Math.max(0, half - 1 + dy);          // softened top corners
            if (half > 0) g.fill(cx - half, top + dy, cx + half, top + dy + 1, argb);
        }
    }

    private static void ring(GuiGraphics g, int cx, int cy, int r, int argb, int from, int to) {
        for (int a = from; a < to; a += 4) {
            double rad = Math.toRadians(a - 90);
            int x = cx + (int) Math.round(Math.cos(rad) * r), y = cy + (int) Math.round(Math.sin(rad) * r);
            g.fill(x - 1, y - 1, x + 1, y + 1, argb);
        }
    }

    private void paintBackground(GuiGraphics g, boolean on) {
        g.fillGradient(0, 0, W, H, BG1, on ? 0xFF0E2A4A : BG2);
        // a drifting dot grid, like a map of a network
        for (int gy = 0; gy < H; gy += 10) {
            for (int gx = 0; gx < W; gx += 10) {
                int pulse = (gx * 7 + gy * 3 + ticks) % 90;
                int a = pulse < 8 ? 0x60 - pulse * 6 : 0x16;
                g.fill(gx, gy, gx + 1, gy + 1, alpha(on ? CYAN : 0x8A93FF, a));
            }
        }
        // a slow scan line
        int sy = (ticks / 2) % (H + 40) - 20;
        g.fillGradient(0, sy, W, sy + 14, 0x00000000, alpha(on ? CYAN : MAGENTA, 0x14));
    }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        boolean on = Vpn.on(), busy = Vpn.connecting();
        paintBackground(g, on);

        // ----- left: the shield and the power button -----
        int accent = on ? GREEN : busy ? CYAN : MAGENTA;
        double breathe = 0.5 + 0.5 * Math.sin(ticks / 18.0);
        // the glow
        for (int i = 3; i >= 1; i--) disc(g, PX, PY, PR + i * 5, alpha(accent, (int) ((on ? 22 : busy ? 16 : 10) + breathe * (on ? 10 : 4)) / i));
        shield(g, PX, PY - 44, 70, 88, alpha(accent, 0x30));
        shield(g, PX, PY - 42, 64, 84, 0xFF0F1432);
        shield(g, PX, PY - 40, 58, 78, 0xFF151B42);
        // the outline of the shield
        for (int dy = 0; dy < 88; dy += 1) {
            double k = dy < 88 * 0.42 ? 1.0 : 1.0 - Math.pow((dy - 88 * 0.42) / (88 * 0.58), 1.7);
            int half = (int) Math.round(35 * Math.max(0.0, k));
            if (half > 0) {
                g.fill(PX - half, PY - 44 + dy, PX - half + 1, PY - 44 + dy + 1, alpha(accent, 0xC0));
                g.fill(PX + half - 1, PY - 44 + dy, PX + half, PY - 44 + dy + 1, alpha(accent, 0xC0));
            }
        }
        g.fill(PX - 30, PY - 44, PX + 30, PY - 43, alpha(accent, 0xC0));

        // the button
        boolean hover = in(mx, my, PX - PR, PY - PR, PR * 2, PR * 2) && (mx - PX) * (mx - PX) + (my - PY) * (my - PY) <= PR * PR;
        disc(g, PX, PY, 24, alpha(accent, hover ? 0x70 : 0x45));
        disc(g, PX, PY, 21, hover ? 0xFF1E2552 : 0xFF161C44);
        if (busy) {
            int head = (ticks * 9) % 360;
            for (int k = 0; k < 14; k++) ring(g, PX, PY, 24, alpha(CYAN, 0xFF - k * 17), head - k * 12 + 360, head - k * 12 + 366);
        } else {
            ring(g, PX, PY, 24, alpha(accent, on ? 0xFF : 0x90), 0, 360);
        }
        // the power symbol: an open ring and a bar
        ring(g, PX, PY, 10, on ? GREEN : busy ? CYAN : 0xFFB9BFE8, 42, 318);
        g.fill(PX - 1, PY - 13, PX + 1, PY - 2, on ? GREEN : busy ? CYAN : 0xFFB9BFE8);

        String st = Vpn.connecting() ? t("cutemod.vpn.connecting") : on ? t("cutemod.vpn.on") : t("cutemod.vpn.off");
        ctxt(g, st, PX, PY + 52, accent);
        // the addresses
        int srv = Vpn.server() >= 0 ? Vpn.server() : Math.max(0, sel);
        String ip = on ? Vpn.maskedIp(srv) : Vpn.realIp();
        ctxt(g, ip, PX, PY + 63, on ? TEXT : RED);
        ctxt(g, t(on ? "cutemod.vpn.ip.hidden" : "cutemod.vpn.ip.real"), PX, PY + 73, MUTED);

        // ----- right: the servers -----
        roundRect(g, LIST_X - 4, 8, ROW_W + 8, 21, 5, PANEL);
        g.fill(LIST_X - 4, 8, LIST_X - 2, 29, accent);
        txt(g, "ShadeVPN", LIST_X + 4, 12, TEXT);
        String up = on ? uptime(Vpn.secondsUp()) : t("cutemod.vpn.servers");
        txt(g, up, LIST_X + ROW_W - f.width(up), 12, on ? GREEN : MUTED);

        for (int i = 0; i < Vpn.SERVERS.size(); i++) {
            Vpn.Server s = Vpn.SERVERS.get(i);
            int y = LIST_Y + 4 + i * (ROW_H + 1);
            boolean selected = i == sel, live = (on || busy) && i == Vpn.server(), over = in(mx, my, LIST_X, y, ROW_W, ROW_H);
            roundRect(g, LIST_X - 4, y, ROW_W + 8, ROW_H, 5, live ? alpha(accent, 0x38) : selected ? 0xCC1A2250 : over ? 0xCC161C42 : PANEL);
            if (selected || live) g.fill(LIST_X - 4, y + 3, LIST_X - 2, y + ROW_H - 3, live ? accent : CYAN);
            // the badge
            disc(g, LIST_X + 10, y + ROW_H / 2, 8, alpha(s.rgb(), 0x60));
            disc(g, LIST_X + 10, y + ROW_H / 2, 6, s.rgb() | 0xFF000000);
            String cc = s.id().toUpperCase();
            ctxt(g, cc, LIST_X + 10, y + ROW_H / 2 - 4, 0xFF10142C);
            fitText(g, f, t("cutemod.vpn.srv." + s.id()), LIST_X + 24, y + 3, 64, live ? TEXT : 0xFFC8D0F8, false);
            // ping
            int ping = Vpn.ping(i);
            int pc = ping < 60 ? GREEN : ping < 120 ? AMBER : RED;
            txt(g, ping + " ms", LIST_X + 24, y + 12, alpha(pc, 0xFF));
            // the speed bars
            int bars = Math.max(1, Math.min(5, (s.speed() + 9) / 20));
            for (int b = 0; b < 5; b++) {
                int bh = 3 + b * 2;
                g.fill(LIST_X + ROW_W - 30 + b * 6, y + ROW_H - 5 - bh, LIST_X + ROW_W - 26 + b * 6, y + ROW_H - 5, b < bars ? alpha(CYAN, 0xFF) : 0x40FFFFFF);
            }
            if (live) {
                String tag = on ? t("cutemod.vpn.tag.on") : t("cutemod.vpn.tag.wait");
                txt(g, tag, LIST_X + ROW_W - 34 - f.width(tag), y + 3, accent);
            }
        }

        // ----- the banner at the bottom: the hidden network -----
        roundRect(g, 6, BANNER_Y, W - 12, BANNER_H, 5, PANEL);
        if (on && Vpn.found()) {
            boolean ov = in(mx, my, W - 86, BANNER_Y + 3, 76, BANNER_H - 6);
            int blink = ticks % 60 < 30 ? MAGENTA : 0xFFFF8AE6;
            g.fill(6, BANNER_Y + 3, 8, BANNER_Y + BANNER_H - 3, MAGENTA);
            txt(g, t("cutemod.vpn.hidden.found"), 14, BANNER_Y + 3, blink);
            txt(g, Vpn.DARK_HOST, 14, BANNER_Y + 12, TEXT);
            roundRect(g, W - 86, BANNER_Y + 3, 76, BANNER_H - 6, 4, ov ? 0xFFFF6FE0 : MAGENTA);
            ctxt(g, t("cutemod.vpn.hidden.open"), W - 48, BANNER_Y + 7, 0xFFFFFFFF);
        } else {
            g.fill(6, BANNER_Y + 3, 8, BANNER_Y + BANNER_H - 3, LINE);
            fitText(g, f, t(on ? "cutemod.vpn.hidden.none" : "cutemod.vpn.hidden.teaser"), 14, BANNER_Y + 7, W - 30, MUTED, false);
        }
    }

    private static String uptime(int s) {
        return String.format("%02d:%02d", s / 60 % 100, s % 60);
    }

    // ---------- input ----------
    @Override
    public boolean click(int x, int y, int button) {
        if (button != 0) return false;
        boolean on = Vpn.on(), busy = Vpn.connecting();
        // the power button
        if ((x - PX) * (x - PX) + (y - PY) * (y - PY) <= PR * PR) {
            Sfx.click();
            if (on || busy) Vpn.disconnect();
            else if (!Vpn.connect(Math.max(0, sel))) Progress.toast("cutemod.toast.net_none");
            return true;
        }
        // a server
        for (int i = 0; i < Vpn.SERVERS.size(); i++) {
            int ry = LIST_Y + 4 + i * (ROW_H + 1);
            if (in(x, y, LIST_X - 4, ry, ROW_W + 8, ROW_H)) {
                Sfx.click();
                sel = i;
                if ((on || busy) && Vpn.server() != i) Vpn.connect(i);          // the tunnel moves to the new server
                return true;
            }
        }
        // the hidden network
        if (on && Vpn.found() && in(x, y, W - 86, BANNER_Y + 3, 76, BANNER_H - 6)) {
            Sfx.click();
            shell.open(new DarkMarketApp());
            return true;
        }
        return false;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (keyCode == 32 || keyCode == 257) {                  // space or enter: the power button
            if (Vpn.on() || Vpn.connecting()) Vpn.disconnect();
            else Vpn.connect(Math.max(0, sel));
            return true;
        }
        return false;
    }
}
