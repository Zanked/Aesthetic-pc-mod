package dev.cutemod.client.os;

import net.minecraft.client.Minecraft;
import net.minecraft.core.Holder;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * The sounds of the computer: the power-on chime, system beeps, key clicks
 * and the hum of the fan. Everything is made of vanilla sounds (note blocks, UI clicks, the beacon
 * hum), so no sound files are needed. "Sounds" and "Hum" can be switched off in Settings
 * (remembered in cutemod_sound.txt).
 */
public final class Sfx {
    private Sfx() {}

    public static boolean sounds = true;
    public static boolean hum = true;
    public static boolean music = true;
    /** Volumes in percent, 0..VOL_MAX: the computer's own sounds (clicks, chimes, fan, game effects) and the music (game tracks
     *  and the Music app). 100 is the normal volume, above it the sound is boosted (see playVol). */
    public static final int VOL_MAX = 200;
    public static int volSystem = 100, volMusic = 100;
    private static boolean loaded;

    private static Path file() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("cutemod_sound.txt");
    }

    private static void load() {
        if (loaded) return;
        loaded = true;
        try {
            Path p = file();
            if (Files.exists(p)) {
                String[] v = Files.readString(p).trim().split(",");
                sounds = v[0].equals("1");
                hum = v.length < 2 || v[1].equals("1");
                music = v.length < 3 || v[2].equals("1");
                if (v.length > 3) volSystem = parseVol(v[3]);
                if (v.length > 4) volMusic = parseVol(v[4]);
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Files.writeString(file(), (sounds ? "1" : "0") + "," + (hum ? "1" : "0") + "," + (music ? "1" : "0")
                    + "," + volSystem + "," + volMusic);
        } catch (Exception ignored) {
        }
    }

    private static int parseVol(String s) {
        try { return Math.max(0, Math.min(VOL_MAX, Integer.parseInt(s.trim()))); } catch (Exception e) { return 100; }
    }

    /** System volume, 0..2 (1 is normal). */
    public static float systemVol() { load(); return volSystem / 100F; }

    /** Music volume, 0..2 (1 is normal). */
    public static float musicVol() { load(); return volMusic / 100F; }

    /** A computer or game effect: respects the Sounds switch and the system volume. */
    public static void ui(SoundEvent e, float pitch, float vol) {
        play(e, pitch, vol);
    }

    private static final java.util.List<SoundInstance> GAME_SOUNDS = new java.util.ArrayList<>();

    /** A sound of a mini game (a monster growl, a scream...). Like {@link #ui}, but it is remembered so that closing the game can cut it off. */
    public static void gameSound(SoundEvent e, float pitch, float vol) {
        if (!sounds()) return;
        float v = vol * systemVol();
        if (v <= 0F) return;
        var sm = Minecraft.getInstance().getSoundManager();
        GAME_SOUNDS.removeIf(s -> !sm.isActive(s));
        SimpleSoundInstance a = SimpleSoundInstance.forUI(e, pitch, Math.min(1F, v));
        sm.play(a);
        GAME_SOUNDS.add(a);
        if (v > 1F) {                                                    // louder than 1.0: a second layer (see playVol)
            SimpleSoundInstance b = SimpleSoundInstance.forUI(e, pitch, Math.min(1F, v - 1F));
            sm.play(b);
            GAME_SOUNDS.add(b);
        }
    }

    /** A tune of a mini game (a perk jingle): follows the Music switch and slider (not the Sounds ones) and is cut off when the game closes. */
    public static void gameTune(SoundEvent e, float pitch, float vol) {
        if (!music()) return;
        float v = vol * musicVol();
        if (v <= 0F) return;
        var sm = Minecraft.getInstance().getSoundManager();
        GAME_SOUNDS.removeIf(s -> !sm.isActive(s));
        SimpleSoundInstance a = SimpleSoundInstance.forUI(e, pitch, Math.min(1F, v));
        sm.play(a);
        GAME_SOUNDS.add(a);
    }

    /** A long sound of a mini game that steers itself (a looping tune): remembered, so that closing the game cuts it off. */
    public static void trackGameSound(SoundInstance s) { GAME_SOUNDS.add(s); }

    /** The game was closed: whatever it was still sounding (a long roar) stops at once. */
    public static void stopGameSounds() {
        if (GAME_SOUNDS.isEmpty()) return;
        var sm = Minecraft.getInstance().getSoundManager();
        for (SoundInstance s : GAME_SOUNDS) sm.stop(s);
        GAME_SOUNDS.clear();
    }

    /** A note of the Music app or the videos: only the music volume counts (the player chose to listen). */
    public static void musicNote(SoundEvent e, float pitch, float vol) {
        float v = vol * musicVol();
        if (v <= 0F) return;
        playVol(e, pitch, v);
    }

    public static boolean sounds() { load(); return sounds; }

    public static boolean hum() { load(); return hum; }

    /** The music that plays while a game is open (see GameMusic). */
    public static boolean music() { load(); return music; }

    private static void play(Holder<SoundEvent> e, float pitch, float vol) { play(e.value(), pitch, vol); }

    private static void play(SoundEvent e, float pitch, float vol) {
        if (!sounds()) return;
        float v = vol * systemVol();
        if (v <= 0F) return;
        playVol(e, pitch, v);
    }

    /** The sound engine never plays one sound louder than 1.0. To go beyond it the sound is played twice at once: the second
     *  one adds what is missing (up to 2.0 = twice as loud). */
    private static void playVol(SoundEvent e, float pitch, float v) {
        var sm = Minecraft.getInstance().getSoundManager();
        sm.play(SimpleSoundInstance.forUI(e, pitch, Math.min(1F, v)));
        if (v > 1F) sm.play(SimpleSoundInstance.forUI(e, pitch, Math.min(1F, v - 1F)));
    }

    /** Note-block pitch for a semitone offset from the middle note. */
    private static float semi(int n) { return (float) Math.pow(2, n / 12.0); }

    // ---------- single sounds ----------
    public static void click() {
        if (Theme.hell()) {                                                              // the video 666: a heartbeat thud and a wet squelch
            play(SoundEvents.NOTE_BLOCK_BASEDRUM.value(), 0.55F, 0.7F);
            play(ev(SoundEvents.SLIME_SQUISH_SMALL), 0.5F, 0.4F);
            return;
        }
        if (Theme.pixel()) { play(SoundEvents.NOTE_BLOCK_HAT.value(), 1.9F, 0.35F); play(SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.22F); return; }   // a soft Material "tick"
        if (Theme.sunny()) { play(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.8F, 0.5F); play(SoundEvents.CHICKEN_STEP, 2.0F, 0.35F); return; }   // a tiny chick step
        if (Theme.anime()) { play(SoundEvents.NOTE_BLOCK_CHIME.value(), 1.9F, 0.45F); play(SoundEvents.AMETHYST_BLOCK_CHIME, 2.0F, 0.3F); return; }   // a soft pop with a sparkle
        if (Retro.mechClicks()) { play(SoundEvents.STONE_BUTTON_CLICK_ON, 1.9F, 0.28F); return; }   // a soft mechanical click
        if (Theme.retro()) { play(SoundEvents.NOTE_BLOCK_HAT.value(), 1.5F, 0.6F); return; }                                              // a dry tick
        if (Theme.kawaii()) { play(SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.6F); play(SoundEvents.AMETHYST_BLOCK_CHIME, 1.9F, 0.25F); return; }   // a tiny music box
        if (Theme.aero()) {                                                              // a bubble pop and a drop
            play(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 1.3F, 1.0F);
            play(SoundEvents.AMETHYST_BLOCK_CHIME, 1.8F, 0.6F);
        }
        else play(SoundEvents.UI_BUTTON_CLICK.value(), 1.7F, 0.35F);
    }

    public static void key() {
        if (Theme.hell()) { play(ev(SoundEvents.SLIME_SQUISH_SMALL), 0.6F + (float) Math.random() * 0.3F, 0.3F); return; }   // wet keys
        if (Theme.pixel()) { play(SoundEvents.NOTE_BLOCK_HAT.value(), 2.0F, 0.18F); return; }
        if (Theme.sunny()) { play(SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.2F); return; }
        if (Theme.anime()) { play(SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.22F); return; }
        if (Retro.mechClicks()) { play(SoundEvents.STONE_BUTTON_CLICK_OFF, 1.5F + (float) Math.random() * 0.5F, 0.22F); return; }
        if (Theme.retro()) play(SoundEvents.NOTE_BLOCK_HAT.value(), 1.9F, 0.3F);
        else if (Theme.kawaii()) play(SoundEvents.NOTE_BLOCK_CHIME.value(), 2.0F, 0.3F);
        else if (Theme.aero()) play(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 1.8F, 0.7F);       // a tiny bubble
        else play(SoundEvents.UI_BUTTON_CLICK.value(), 2.0F, 0.18F);
    }

    /** The end of a game: a bright jingle for a win, a heartbeat for the dark games, a soft low bell otherwise. */
    public static void gameOver(boolean win, boolean dark) {
        if (win) {
            play(ev(SoundEvents.PLAYER_LEVELUP), 1.2F, 0.5F);
            play(ev(SoundEvents.AMETHYST_BLOCK_CHIME), 1.6F, 0.8F);
        } else if (dark) {
            play(ev(SoundEvents.WARDEN_HEARTBEAT), 0.9F, 1.0F);
            play(SoundEvents.NOTE_BLOCK_BASS.value(), 0.5F, 0.7F);
        } else {
            play(SoundEvents.NOTE_BLOCK_BELL.value(), 0.75F, 0.5F);
            play(ev(SoundEvents.NOTE_BLOCK_BASEDRUM), 0.9F, 0.35F);
        }
    }

    public static void error() {
        if (Theme.hell()) {                                                              // a heartbeat and a ghost
            play(ev(SoundEvents.WARDEN_HEARTBEAT), 1.0F, 1.0F);
            play(ev(SoundEvents.SOUL_ESCAPE), 0.6F, 0.8F);
            play(SoundEvents.NOTE_BLOCK_BASS.value(), 0.5F, 0.7F);
            return;
        }
        if (Theme.pixel()) { play(SoundEvents.NOTE_BLOCK_BASS.value(), 0.9F, 0.5F); play(SoundEvents.NOTE_BLOCK_CHIME.value(), 0.8F, 0.4F); return; }   // a low double "bip"
        if (Theme.sunny()) { play(SoundEvents.CHICKEN_HURT, 1.4F, 0.5F); play(SoundEvents.NOTE_BLOCK_BELL.value(), 0.6F, 0.5F); return; }   // an "oops" cheep
        if (Theme.anime()) { play(SoundEvents.NOTE_BLOCK_COW_BELL.value(), 0.7F, 0.6F); play(SoundEvents.NOTE_BLOCK_BASS.value(), 0.6F, 0.5F); return; }   // a comic "bonk"
        if (Theme.retro()) {                                                             // the old system "ding": a flat square beep
            play(SoundEvents.NOTE_BLOCK_BIT.value(), 0.5F, 0.9F);
            play(SoundEvents.NOTE_BLOCK_BIT.value(), 0.4F, 0.6F);
            return;
        }
        if (Theme.kawaii()) {                                                            // a soft "oops": two low bells
            play(SoundEvents.NOTE_BLOCK_BELL.value(), 0.7F, 0.7F);
            play(SoundEvents.NOTE_BLOCK_BELL.value(), 0.53F, 0.6F);
            return;
        }
        if (Theme.aero()) {                                                              // two bells, like an old "ding"
            play(SoundEvents.GENERIC_SPLASH, 0.8F, 1.0F);                                // a blurp and a low glass note
            play(SoundEvents.AMETHYST_BLOCK_CHIME, 0.6F, 1.0F);
            return;
        }
        play(SoundEvents.NOTE_BLOCK_BASS.value(), 0.6F, 0.8F);
        play(SoundEvents.NOTE_BLOCK_BIT.value(), 0.5F, 0.4F);
    }

    public static void powerOn() {
        if (Theme.hell()) {
            play(ev(SoundEvents.WARDEN_HEARTBEAT), 0.9F, 1.0F);
            play(ev(SoundEvents.WITHER_AMBIENT), 0.6F, 0.5F);
            play(ev(SoundEvents.BELL_BLOCK), 0.5F, 0.6F);
            return;
        }
        if (Theme.pixel()) { play(SoundEvents.NOTE_BLOCK_HARP.value(), 1.4F, 0.7F); play(SoundEvents.AMETHYST_BLOCK_CHIME, 1.7F, 0.6F); return; }
        if (Theme.sunny()) { play(SoundEvents.CHICKEN_AMBIENT, 1.8F, 0.6F); play(SoundEvents.NOTE_BLOCK_BELL.value(), 1.6F, 0.7F); play(SoundEvents.AMETHYST_BLOCK_CHIME, 1.8F, 0.6F); return; }
        if (Theme.anime()) { play(SoundEvents.NOTE_BLOCK_HARP.value(), 1.5F, 0.8F); play(SoundEvents.AMETHYST_BLOCK_CHIME, 1.8F, 1.0F); play(ev(SoundEvents.PLAYER_LEVELUP), 1.6F, 0.3F); return; }
        if (Theme.retro()) {
            play(SoundEvents.NOTE_BLOCK_BIT.value(), 1.0F, 0.7F);
            play(SoundEvents.NOTE_BLOCK_BIT.value(), 1.5F, 0.6F);
            play(SoundEvents.UI_BUTTON_CLICK.value(), 0.6F, 0.5F);
            return;
        }
        if (Theme.kawaii()) {
            play(SoundEvents.NOTE_BLOCK_BELL.value(), 1.5F, 0.7F);
            play(SoundEvents.AMETHYST_BLOCK_CHIME, 1.8F, 0.8F);
            return;
        }
        if (Theme.aero()) {
            play(SoundEvents.GENERIC_SPLASH, 1.5F, 0.9F);                                 // a splash, glass and a shimmer
            play(SoundEvents.AMETHYST_BLOCK_CHIME, 1.4F, 1.0F);
            play(SoundEvents.BEACON_ACTIVATE, 2.0F, 0.5F);
            return;
        }
        play(SoundEvents.UI_BUTTON_CLICK.value(), 0.6F, 0.6F);
        play(SoundEvents.BEACON_ACTIVATE, 1.6F, 0.25F);
    }

    /** Notes of the sounds that need a few steps. {delay in ticks, semitone, instrument (0 chime, 1 bell, 2 bit)}. */
    public static final int[][] STARTUP = {{0, -5, 0}, {5, 0, 0}, {10, 4, 0}, {15, 7, 1}, {22, 12, 1}};
    public static final int[][] LOGIN = {{0, 4, 1}, {4, 9, 1}};
    public static final int[][] LOCK = {{0, 7, 1}, {4, 0, 1}};
    public static final int[][] SHUTDOWN = {{0, 7, 0}, {5, 0, 0}, {10, -5, 0}};

    // the Frutiger Aero set: water drops, glass chimes and bubbles (instrument 4 = glass chime, 5 = bubble pop, 3 = harp)
    private static final int[][] AERO_STARTUP = {{0, -5, 5}, {3, -3, 4}, {7, 0, 5}, {10, 4, 4}, {14, 7, 5}, {17, 12, 4}, {24, 7, 4}, {30, 12, 3}};
    private static final int[][] AERO_LOGIN = {{0, 4, 5}, {3, 7, 4}, {7, 12, 4}};
    private static final int[][] AERO_LOCK = {{0, 12, 4}, {4, 7, 5}, {8, 0, 4}};
    private static final int[][] AERO_SHUTDOWN = {{0, 12, 4}, {5, 7, 5}, {10, 0, 4}, {15, -5, 5}};

    // the Kawaii set: a music box (bell 1 and harp 3)
    private static final int[][] KAWAII_STARTUP = {{0, 7, 1}, {3, 12, 1}, {6, 16, 1}, {9, 19, 3}, {13, 24, 1}, {18, 19, 3}, {22, 24, 1}};
    private static final int[][] KAWAII_LOGIN = {{0, 12, 1}, {3, 19, 1}};
    private static final int[][] KAWAII_LOCK = {{0, 19, 1}, {4, 12, 1}};
    private static final int[][] KAWAII_SHUTDOWN = {{0, 19, 1}, {5, 12, 1}, {10, 7, 1}, {15, 0, 1}};

    // the Retro 98 set: square-wave beeps (instrument 2 = bit)
    private static final int[][] RETRO_STARTUP = {{0, -5, 2}, {4, 0, 2}, {8, 4, 2}, {12, 7, 2}, {18, 12, 2}, {22, 9, 2}, {26, 12, 2}, {32, 16, 2}};
    private static final int[][] RETRO_LOGIN = {{0, 7, 2}, {3, 12, 2}, {6, 16, 2}};
    private static final int[][] RETRO_LOCK = {{0, 12, 2}, {4, 7, 2}};
    private static final int[][] RETRO_SHUTDOWN = {{0, 12, 2}, {5, 7, 2}, {10, 4, 2}, {15, -5, 2}};

    // the Sunny Chick set: a bright bell tune that ends with a cheep (instrument 6 = chicken, 1 = bell, 3 = harp)
    private static final int[][] SUNNY_STARTUP = {{0, 0, 1}, {3, 4, 1}, {6, 7, 1}, {9, 12, 3}, {13, 7, 3}, {16, 12, 1}, {21, 16, 6}, {26, 19, 6}};
    private static final int[][] SUNNY_LOGIN = {{0, 7, 1}, {3, 12, 1}, {7, 16, 6}};
    private static final int[][] SUNNY_LOCK = {{0, 12, 1}, {4, 7, 1}, {8, 4, 6}};
    private static final int[][] SUNNY_SHUTDOWN = {{0, 12, 1}, {5, 7, 1}, {10, 4, 1}, {15, 0, 6}};

    // the Pixel set: a calm, airy rise of harp and glass chimes, like the boot tune of a phone (instrument 3 = harp, 4 = glass chime)
    private static final int[][] PIXEL_STARTUP = {{0, -5, 3}, {4, 0, 3}, {8, 4, 3}, {12, 7, 4}, {17, 12, 4}, {23, 16, 4}};
    private static final int[][] PIXEL_LOGIN = {{0, 7, 4}, {4, 12, 4}};
    private static final int[][] PIXEL_LOCK = {{0, 12, 4}, {4, 7, 4}};
    private static final int[][] PIXEL_SHUTDOWN = {{0, 12, 3}, {5, 7, 3}, {10, 0, 3}};

    // the Anime set: a bright harp run and glass chimes (instrument 3 = harp, 4 = glass chime, 1 = bell)
    private static final int[][] ANIME_STARTUP = {{0, 0, 3}, {3, 4, 3}, {6, 7, 3}, {9, 9, 3}, {12, 12, 4}, {16, 9, 4}, {20, 12, 4}, {26, 12, 1}};
    private static final int[][] ANIME_LOGIN = {{0, 4, 4}, {3, 9, 4}, {6, 12, 3}};
    private static final int[][] ANIME_LOCK = {{0, 12, 4}, {4, 9, 3}, {8, 4, 4}};
    private static final int[][] ANIME_SHUTDOWN = {{0, 12, 3}, {5, 9, 3}, {10, 4, 3}, {15, 0, 1}};

    // the 666 set: low bells with a tritone (the devil's interval) and a flat square beep at the end
    private static final int[][] HELL_STARTUP = {{0, -12, 1}, {8, -6, 1}, {16, -12, 1}, {24, -7, 1}, {34, -12, 2}};
    private static final int[][] HELL_LOGIN = {{0, -12, 1}, {6, -6, 1}};
    private static final int[][] HELL_LOCK = {{0, -6, 1}, {6, -12, 1}};
    private static final int[][] HELL_SHUTDOWN = {{0, -6, 1}, {7, -12, 1}, {14, -12, 2}};

    public static int[][] startup() { return Theme.hell() ? HELL_STARTUP : Theme.pixel() ? PIXEL_STARTUP : Theme.sunny() ? SUNNY_STARTUP : Theme.anime() ? ANIME_STARTUP : Theme.retro() ? RETRO_STARTUP : Theme.kawaii() ? KAWAII_STARTUP : Theme.aero() ? AERO_STARTUP : STARTUP; }

    public static int[][] login() { return Theme.hell() ? HELL_LOGIN : Theme.pixel() ? PIXEL_LOGIN : Theme.sunny() ? SUNNY_LOGIN : Theme.anime() ? ANIME_LOGIN : Theme.retro() ? RETRO_LOGIN : Theme.kawaii() ? KAWAII_LOGIN : Theme.aero() ? AERO_LOGIN : LOGIN; }

    public static int[][] lock() { return Theme.hell() ? HELL_LOCK : Theme.pixel() ? PIXEL_LOCK : Theme.sunny() ? SUNNY_LOCK : Theme.anime() ? ANIME_LOCK : Theme.retro() ? RETRO_LOCK : Theme.kawaii() ? KAWAII_LOCK : Theme.aero() ? AERO_LOCK : LOCK; }

    public static int[][] shutdown() { return Theme.hell() ? HELL_SHUTDOWN : Theme.pixel() ? PIXEL_SHUTDOWN : Theme.sunny() ? SUNNY_SHUTDOWN : Theme.anime() ? ANIME_SHUTDOWN : Theme.retro() ? RETRO_SHUTDOWN : Theme.kawaii() ? KAWAII_SHUTDOWN : Theme.aero() ? AERO_SHUTDOWN : SHUTDOWN; }

    private static SoundEvent ev(Object o) { return o instanceof Holder<?> h ? (SoundEvent) h.value() : (SoundEvent) o; }

    public static void note(int[] n) {
        SoundEvent e = switch (n[2]) {
            case 3 -> SoundEvents.NOTE_BLOCK_HARP.value();
            case 4 -> ev(SoundEvents.AMETHYST_BLOCK_CHIME);
            case 5 -> ev(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP);
            case 1 -> SoundEvents.NOTE_BLOCK_BELL.value();
            case 6 -> ev(SoundEvents.CHICKEN_AMBIENT);
            case 2 -> SoundEvents.NOTE_BLOCK_BIT.value();
            default -> SoundEvents.NOTE_BLOCK_CHIME.value();
        };
        play(e, semi(n[1]), n[2] >= 3 && (Theme.aero() || Theme.anime() || Theme.pixel()) ? 1.0F : 0.5F);   // the Aero water notes are quiet by nature
    }

    /** Plays a jingle right now (the delays are ignored). Used for the shutdown, when no tick follows. */
    public static void jingleNow(int[][] j) {
        for (int[] n : j) note(n);
    }

    // ---------- the fan ----------
    private static Hum fan;

    /** A quiet looping drone (the beacon hum) that follows the player, so it is heard evenly. */
    private static final class Hum extends AbstractTickableSoundInstance {
        private boolean off;

        Hum() {
            super(SoundEvents.BEACON_AMBIENT, SoundSource.BLOCKS, RandomSource.create());
            this.looping = true;
            this.delay = 0;
            this.volume = 0.12F;
            this.pitch = 1.5F;
            this.relative = true;
            this.attenuation = SoundInstance.Attenuation.NONE;
        }

        void turnOff() { off = true; stop(); }

        @Override
        public void tick() {
            if (off || !Sfx.hum() || Sfx.systemVol() <= 0F) { stop(); return; }
            this.volume = (Hell.active() ? 0.2F : 0.12F) * Sfx.systemVol();
            this.pitch = Hell.active() ? 0.5F : 1.5F;
        }
    }

    public static void startFan() {
        stopFan();
        if (!hum() || systemVol() <= 0F) return;
        fan = new Hum();
        Minecraft.getInstance().getSoundManager().play(fan);
    }

    /** Called every frame: starts the fan again if it was switched on in Settings (or off). */
    public static void keepFan() {
        if (fan == null || fan.isStopped()) {
            if (hum() && systemVol() > 0F) startFan();
        } else if (!hum()) {
            stopFan();
        }
    }

    public static void stopFan() {
        if (fan != null) fan.turnOff();
        fan = null;
    }
}
