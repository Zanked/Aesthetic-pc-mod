package dev.cutemod.client.os;

import dev.cutemod.market.BlackGoods;
import dev.cutemod.market.Catalog;
import dev.cutemod.market.TaczBridge;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * NOIR: the dark market behind noir.onion. It can only be reached through the VPN (see {@link Vpn}): the page is opened from the
 * VPN app or by typing its address into the browser, and when the tunnel drops the window goes dark. It sells real guns and
 * ammo of the gun mod TACZ ({@link BlackGoods}) for coins. The order is paid and delivered like every CuteMarket order: a
 * parcel is kept by the server and collected at the computer (a gun comes with a full magazine).
 */
public class DarkMarketApp extends App {

    @Override
    public boolean needsNet() { return true; }

    // ---------- the look: black, violet and two neons ----------
    private static final int BG1 = 0xFF05040C, BG2 = 0xFF170B2E;
    private static final int MAGENTA = 0xFFFF3DC8, CYAN = 0xFF38E8FF, GOLD = 0xFFFFC94D, GREEN = 0xFF3DF2A0, RED = 0xFFFF5470, AMBER = 0xFFF0B820;
    private static final int TEXT = 0xFFEDE8FF, MUTED = 0xFF8C84B8, CARD = 0xDD0C0A1F, CARD_HI = 0xDD1A1236, LINE = 0xFF2B2250;

    private static final int HEAD = 24, TAB_Y = 26, TAB_H = 14, GRID_Y = 44;
    private static final int COLS = 3, CARD_W = 92, CARD_H = 54, GAP_X = 4, GAP_Y = 4, PAGE = 6;
    private static final int TABS = 7, TAB_ORDERS = 6;

    private int tab, page, ticks, mx = -1, my = -1, boot;
    private boolean cartOpen, express;
    private final Map<String, Integer> cart = new LinkedHashMap<>();
    private final Map<String, ItemStack> stacks = new HashMap<>();

    @Override
    public Component title() { return Component.translatable("cutemod.os.dark"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.dark"); }

    @Override
    public Component status() {
        int a = darkOrders().size();
        return a > 0 ? Component.translatable("cutemod.market.status", a) : Component.empty();
    }

    @Override
    public void mouse(int x, int y) { mx = x; my = y; }

    @Override
    public void tick() {
        ticks++;
        if (boot < 120) boot++;
        Market.tick();
        if (!Vpn.on()) cartOpen = false;
    }

    @Override
    public boolean canBack() { return cartOpen; }

    @Override
    public void back() { cartOpen = false; }

    private static SoundEvent sv(SoundEvent e) { return e; }

    private static SoundEvent sv(Holder<SoundEvent> h) { return h.value(); }

    // ---------- helpers ----------
    private static void txt(GuiGraphics g, String s, int x, int y, int argb) { Skin.str(g, font(), s, x, y, argb, false); }

    private static void ctxt(GuiGraphics g, String s, int cx, int y, int argb) { Skin.str(g, font(), s, cx - font().width(s) / 2, y, argb, false); }

    private static void rtxt(GuiGraphics g, String s, int rx, int y, int argb) { Skin.str(g, font(), s, rx - font().width(s), y, argb, false); }

    private static int alpha(int rgb, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF); }

    private static int hash(int n) {
        n ^= n >>> 15; n *= 0x2C1B3C6D; n ^= n >>> 12; n *= 0x297A2D39; n ^= n >>> 15;
        return n & 0x7FFFFFFF;
    }

    /** A thin neon frame. */
    private static void frame(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + 1, argb);
        g.fill(x, y + h - 1, x + w, y + h, argb);
        g.fill(x, y, x + 1, y + h, argb);
        g.fill(x + w - 1, y, x + w, y + h, argb);
    }

    private static void coin(GuiGraphics g, int cx, int cy) {
        disc(g, cx, cy, 4, 0xFFB98A10);
        disc(g, cx, cy, 3, GOLD);
        g.fill(cx - 1, cy - 2, cx + 1, cy + 2, 0xFFB98A10);
    }

    private ItemStack stack(String id) {
        ItemStack st = stacks.get(id);
        if (st != null) return st;
        var level = Minecraft.getInstance().level;
        if (level == null) return ItemStack.EMPTY;
        st = Catalog.create(id, level.registryAccess());
        stacks.put(id, st);
        return st;
    }

    private static String name(String id) { return MarketApp.name(id); }

    private static String mmss(int secs) { return String.format("%d:%02d", secs / 60, secs % 60); }

    private int cartCount() {
        int n = 0;
        for (int v : cart.values()) n += v;
        return n;
    }

    private List<Market.Order> darkOrders() {
        List<Market.Order> out = new ArrayList<>();
        for (Market.Order o : Market.orders()) {
            Catalog.Entry e = Catalog.get(o.id);
            if (e != null && e.kind() == Catalog.BLACK) out.add(o);
        }
        return out;
    }

    /** The things on the shelf of this tab, as catalog ids. */
    private List<String> shelf() {
        List<String> out = new ArrayList<>();
        if (tab < BlackGoods.AMMO) for (BlackGoods.Gun gn : BlackGoods.guns(tab)) out.add(gn.id());
        else if (tab == BlackGoods.AMMO) for (BlackGoods.Round r : BlackGoods.ROUNDS) out.add(r.id());
        return out;
    }

    private int pages() { return Math.max(1, (shelf().size() + PAGE - 1) / PAGE); }

    // ---------- drawing ----------
    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        if (!Vpn.on()) { renderDropped(g); return; }
        if (boot < 100) { renderBoot(g); return; }

        float fade = Math.min(1f, (boot - 100) / 20f);
        paintBackground(g);
        renderHead(g, mx, my);
        renderTabs(g, mx, my);
        if (tab == TAB_ORDERS) renderOrders(g, mx, my);
        else renderGrid(g, mx, my);
        if (!TaczBridge.loaded()) renderNoStock(g);
        if (cartOpen) renderCart(g, mx, my);
        if (fade < 1f) g.fill(0, 0, W, H, alpha(0x000000, (int) ((1f - fade) * 255)));
    }

    private void paintBackground(GuiGraphics g) {
        g.fillGradient(0, 0, W, H, BG1, BG2);
        // the code rain: dim columns with a bright head that fall at their own speed
        for (int c = 0; c < 26; c++) {
            int hh = hash(c * 977 + 13);
            int x = 4 + c * 11 + hh % 4;
            int speed = 2 + hh % 4;
            int span = H + 60;
            int head = (ticks * speed / 3 + hh % span) % span - 20;
            for (int k = 0; k < 9; k++) {
                int y = head - k * 5;
                if (y < 0 || y >= H) continue;
                int a = k == 0 ? 0x70 : Math.max(4, 0x34 - k * 5);
                g.fill(x, y, x + 3, y + 4, alpha(k == 0 ? CYAN : MAGENTA, a));
            }
        }
        // scanlines and a vignette
        for (int y = 0; y < H; y += 3) g.fill(0, y, W, y + 1, 0x14000000);
        g.fillGradient(0, 0, W, 10, 0x66000000, 0x00000000);
        g.fillGradient(0, H - 10, W, H, 0x00000000, 0x77000000);
    }

    private void renderHead(GuiGraphics g, int mx, int my) {
        Font f = font();
        g.fillGradient(0, 0, W, HEAD, 0xEE0A0618, 0xEE130A2A);
        g.fill(0, HEAD - 1, W, HEAD, alpha(MAGENTA, 0xB0));
        g.fill(0, HEAD, W, HEAD + 1, alpha(MAGENTA, 0x30));
        // the logo with a glitch: three copies that slide apart now and then
        boolean glitch = ticks % 190 < 7;
        int off = glitch ? 1 + (ticks % 3) : 0;
        for (int pass = 0; pass < 3; pass++) {
            int col = pass == 0 ? alpha(CYAN, 0xC0) : pass == 1 ? alpha(MAGENTA, 0xC0) : 0xFFFFFFFF;
            int dx = pass == 0 ? -off : pass == 1 ? off : 0;
            g.pose().pushPose();
            g.pose().translate(8 + dx, 4, 0);
            g.pose().scale(1.7f, 1.7f, 1f);
            Skin.str(g, f, "NOIR", 0, 0, col, false);
            g.pose().popPose();
        }
        txt(g, t("cutemod.dark.tag"), 52, 5, MUTED);
        txt(g, Vpn.DARK_HOST, 52, 14, alpha(CYAN, 0xC0));
        // the cart (the balance is shown only in the bank)
        int cartX = W - 30;
        boolean ov = in(mx, my, cartX, 3, 26, 17);
        roundRect(g, cartX, 3, 26, 17, 4, cartOpen ? MAGENTA : ov ? 0xFF2A1B54 : 0xFF1B1238);
        frame(g, cartX, 3, 26, 17, alpha(MAGENTA, ov || cartOpen ? 0xFF : 0x90));
        // a little cart: a basket and two wheels
        g.fill(cartX + 6, 8, cartX + 16, 9, TEXT);
        g.fill(cartX + 7, 9, cartX + 15, 13, TEXT);
        disc(g, cartX + 8, 15, 1, TEXT);
        disc(g, cartX + 14, 15, 1, TEXT);
        int n = cartCount();
        if (n > 0) {
            disc(g, cartX + 22, 6, 5, RED);
            ctxt(g, n > 99 ? "99" : String.valueOf(n), cartX + 22, 3, 0xFFFFFFFF);
        }
    }

    private void renderTabs(GuiGraphics g, int mx, int my) {
        Font f = font();
        for (int i = 0; i < TABS; i++) {
            int x = i * W / TABS, w = (i + 1) * W / TABS - x;
            boolean sel = i == tab, ov = in(mx, my, x, TAB_Y, w, TAB_H);
            g.fill(x, TAB_Y, x + w, TAB_Y + TAB_H, sel ? 0xCC1E1240 : ov ? 0xAA140C2C : 0x88080614);
            if (sel) {
                g.fill(x, TAB_Y + TAB_H - 2, x + w, TAB_Y + TAB_H, MAGENTA);
                g.fillGradient(x, TAB_Y + TAB_H - 8, x + w, TAB_Y + TAB_H - 2, 0x00FF3DC8, 0x40FF3DC8);
            }
            String label = t("cutemod.dark.tab." + i);
            fitText(g, f, label, x + w / 2, TAB_Y + 3, w - 4, sel ? 0xFFFFFFFF : ov ? TEXT : MUTED, true);
            if (i == TAB_ORDERS) {
                int ready = Market.readyCount();
                if (ready > 0) { disc(g, x + w - 6, TAB_Y + 4, 4, GREEN); ctxt(g, String.valueOf(Math.min(9, ready)), x + w - 6, TAB_Y + 0, 0xFF06140E); }
            }
        }
    }

    // ----- the shelves -----
    private int cardX(int col) { return 6 + col * (CARD_W + GAP_X); }

    private int cardY(int row) { return GRID_Y + row * (CARD_H + GAP_Y); }

    private void renderGrid(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<String> shelf = shelf();
        int from = page * PAGE;
        for (int i = 0; i < PAGE && from + i < shelf.size(); i++) {
            String id = shelf.get(from + i);
            int x = cardX(i % COLS), y = cardY(i / COLS);
            boolean ov = in(mx, my, x, y, CARD_W, CARD_H);
            boolean inCart = cart.containsKey(id);
            roundRect(g, x, y, CARD_W, CARD_H, 4, ov ? CARD_HI : CARD);
            frame(g, x, y, CARD_W, CARD_H, alpha(inCart ? GREEN : MAGENTA, inCart ? 0xE0 : ov ? 0xC0 : 0x50));
            // the picture
            roundRect(g, x + 4, y + 4, 34, 30, 3, 0xFF0A0818);
            for (int k = 0; k < 4; k++) g.fill(x + 4, y + 4 + k * 8, x + 38, y + 5 + k * 8, 0x12FFFFFF);
            drawGoods(g, id, x + 21, y + 19);
            // the text
            fitText(g, f, name(id), x + 42, y + 5, CARD_W - 46, TEXT, false);
            txt(g, subline(id), x + 42, y + 15, MUTED);
            int price = Market.item(id).price();
            coin(g, x + 45, y + 29);
            txt(g, String.valueOf(price), x + 52, y + 25, GOLD);
            // the button
            boolean bo = in(mx, my, x + 4, y + 38, CARD_W - 8, 12);
            boolean ammo = id.startsWith(BlackGoods.AMMO_PREFIX);
            int have = cart.getOrDefault(id, 0);
            int bc = !TaczBridge.loaded() ? 0xFF3A3452 : inCart ? (bo ? 0xFF55FFB8 : GREEN) : bo ? 0xFFFF6FD8 : MAGENTA;
            roundRect(g, x + 4, y + 38, CARD_W - 8, 12, 3, bc);
            String label = ammo ? (have > 0 ? have + " " + t("cutemod.dark.rounds") + "  +16" : "+16 " + t("cutemod.dark.rounds"))
                    : inCart ? t("cutemod.dark.incart") : t("cutemod.dark.add");
            ctxt(g, label, x + CARD_W / 2, y + 40, inCart ? 0xFF06140E : 0xFFFFFFFF);
        }
        // the page switcher
        if (pages() > 1) {
            int px = W - 44;
            boolean lo = in(mx, my, px - 12, H - 11, 11, 10), hi = in(mx, my, px + 36, H - 11, 11, 10);
            txt(g, "<", px - 9, H - 10, page > 0 ? (lo ? 0xFFFFFFFF : CYAN) : LINE);
            ctxt(g, (page + 1) + " / " + pages(), px + 17, H - 10, MUTED);
            txt(g, ">", px + 39, H - 10, page < pages() - 1 ? (hi ? 0xFFFFFFFF : CYAN) : LINE);
        }
        txt(g, t("cutemod.dark.delivery"), 6, H - 10, alpha(MUTED, 0xB0));
    }

    private String subline(String id) {
        BlackGoods.Gun gn = BlackGoods.gun(id);
        if (gn != null) return t("cutemod.dark.cal." + gn.ammo()) + " · " + gn.mag();
        BlackGoods.Round r = BlackGoods.round(id);
        return r == null ? "" : t("cutemod.dark.cal." + r.ammo());
    }

    /** The real TACZ item (big), or a plain silhouette while TACZ is missing. cx / cy = the middle of the picture. */
    private void drawGoods(GuiGraphics g, String id, int cx, int cy) {
        ItemStack st = TaczBridge.loaded() ? stack(id) : ItemStack.EMPTY;
        if (!st.isEmpty()) {
            float s = 1.75f;
            g.pose().pushPose();
            g.pose().translate(cx - 8 * s, cy - 8 * s, 0);
            g.pose().scale(s, s, 1f);
            g.renderItem(st, 0, 0);
            g.pose().popPose();
            return;
        }
        int c = 0xFF4A4272;                                    // out of stock: a dim shape
        g.fill(cx - 12, cy - 2, cx + 8, cy + 2, c);
        g.fill(cx - 4, cy + 2, cx + 1, cy + 9, c);
        g.fill(cx + 8, cy - 1, cx + 13, cy + 1, c);
        g.fill(cx - 14, cy - 3, cx - 10, cy + 5, c);
    }

    private void renderNoStock(GuiGraphics g) {
        roundRect(g, 20, 66, W - 40, 36, 6, 0xEE10061C);
        frame(g, 20, 66, W - 40, 36, RED);
        ctxt(g, t("cutemod.dark.nostock"), W / 2, 73, RED);
        fitText(g, font(), t("cutemod.dark.nostock.hint"), W / 2, 86, W - 52, TEXT, true);
    }

    // ----- the parcels -----
    private int ordersY(int i) { return GRID_Y + 14 + i * 16; }

    private void renderOrders(GuiGraphics g, int mx, int my) {
        Font f = font();
        List<Market.Order> list = darkOrders();
        txt(g, t("cutemod.dark.orders"), 8, GRID_Y + 2, CYAN);
        boolean any = false;
        for (Market.Order o : list) if (Market.arrived(o)) any = true;
        if (any) {
            boolean ov = in(mx, my, W - 92, GRID_Y, 86, 12);
            roundRect(g, W - 92, GRID_Y, 86, 12, 3, ov ? 0xFF55FFB8 : GREEN);
            ctxt(g, t("cutemod.dark.collect"), W - 49, GRID_Y + 2, 0xFF06140E);
        }
        if (list.isEmpty()) {
            ctxt(g, t("cutemod.dark.noorders"), W / 2, 90, MUTED);
            return;
        }
        for (int i = 0; i < Math.min(list.size(), 7); i++) {
            Market.Order o = list.get(i);
            int y = ordersY(i);
            roundRect(g, 6, y, W - 12, 14, 3, CARD);
            boolean done = Market.arrived(o);
            g.fill(6, y + 2, 8, y + 12, done ? GREEN : AMBER);
            fitText(g, f, name(o.id) + (o.qty > 1 ? "  x" + o.qty : ""), 14, y + 3, 170, TEXT, false);
            String st = done ? t("cutemod.dark.arrived") : t("cutemod.dark.eta", mmss(Market.secondsLeft(o)));
            rtxt(g, st, W - 12, y + 3, done ? GREEN : AMBER);
        }
    }

    // ----- the cart -----
    private static final int CX = 34, CY = 30, CW = 232, CH = 130;

    private int total() { return Market.total(cart, express); }

    private int etaSecs() {
        int best = 0;
        for (String id : cart.keySet()) best = Math.max(best, Market.item(id).secs());
        return express ? best / Market.EXPRESS_SPEED : best;
    }

    private void renderCart(GuiGraphics g, int mx, int my) {
        Font f = font();
        g.fill(0, 0, W, H, 0xAA000000);
        roundRect(g, CX, CY, CW, CH, 6, 0xF00A0618);
        frame(g, CX, CY, CW, CH, MAGENTA);
        txt(g, t("cutemod.dark.cart"), CX + 8, CY + 6, CYAN);
        boolean xo = in(mx, my, CX + CW - 16, CY + 4, 12, 12);
        ctxt(g, "x", CX + CW - 10, CY + 6, xo ? 0xFFFFFFFF : MUTED);
        g.fill(CX + 6, CY + 17, CX + CW - 6, CY + 18, LINE);
        if (cart.isEmpty()) {
            ctxt(g, t("cutemod.dark.empty"), CX + CW / 2, CY + 52, MUTED);
            return;
        }
        int i = 0;
        for (Map.Entry<String, Integer> e : cart.entrySet()) {
            int y = CY + 21 + i * 12;
            boolean ro = in(mx, my, CX + 6, y, CW - 12, 11);
            if (ro) g.fill(CX + 6, y, CX + CW - 6, y + 11, 0x40FF3DC8);
            fitText(g, f, name(e.getKey()) + (e.getValue() > 1 ? "  x" + e.getValue() : ""), CX + 10, y + 2, 150, TEXT, false);
            rtxt(g, String.valueOf(Market.item(e.getKey()).price() * e.getValue()), CX + CW - 22, y + 2, GOLD);
            ctxt(g, "x", CX + CW - 12, y + 2, ro ? RED : MUTED);
            i++;
        }
        int by = CY + CH - 40;
        g.fill(CX + 6, by - 3, CX + CW - 6, by - 2, LINE);
        // express delivery
        boolean eo = in(mx, my, CX + 8, by, 100, 11);
        frame(g, CX + 8, by + 1, 9, 9, express ? GREEN : MUTED);
        if (express) g.fill(CX + 10, by + 3, CX + 15, by + 8, GREEN);
        txt(g, t("cutemod.dark.express"), CX + 21, by + 2, eo ? 0xFFFFFFFF : TEXT);
        rtxt(g, t("cutemod.dark.eta", mmss(etaSecs())), CX + CW - 8, by + 2, MUTED);
        // the total and the button
        int total = total();
        boolean poor = Progress.coins() < total;
        txt(g, t("cutemod.dark.total"), CX + 8, by + 17, MUTED);
        coin(g, CX + 52, by + 20);
        txt(g, String.valueOf(total), CX + 59, by + 17, poor ? RED : GOLD);
        boolean bo = in(mx, my, CX + CW - 92, by + 14, 84, 14);
        boolean can = TaczBridge.loaded() && !poor;
        roundRect(g, CX + CW - 92, by + 14, 84, 14, 4, !can ? 0xFF3A3452 : bo ? 0xFFFF6FD8 : MAGENTA);
        ctxt(g, t(!TaczBridge.loaded() ? "cutemod.dark.nostock" : poor ? "cutemod.dark.poor" : "cutemod.dark.order"), CX + CW - 50, by + 17, can ? 0xFFFFFFFF : 0xFF9A93B8);
    }

    // ----- the screens that replace the shop -----
    private void renderBoot(GuiGraphics g) {
        Font f = font();
        g.fillGradient(0, 0, W, H, 0xFF020208, 0xFF0C0420);
        for (int y = 0; y < H; y += 3) g.fill(0, y, W, y + 1, 0x18000000);
        String[] lines = {t("cutemod.dark.boot.0"), t("cutemod.dark.boot.1"), t("cutemod.dark.boot.2"), t("cutemod.dark.boot.3")};
        int shown = Math.min(lines.length, boot / 18 + 1);
        for (int i = 0; i < shown; i++) {
            boolean last = i == shown - 1 && boot < 76;
            String s = lines[i];
            if (last) s = s.substring(0, Math.min(s.length(), (boot % 18) * s.length() / 14 + 1));
            txt(g, "> " + s, 14, 30 + i * 13, i == lines.length - 1 ? GREEN : CYAN);
            if (last && ticks % 20 < 12) g.fill(14 + f.width("> " + s) + 1, 30 + i * 13, 14 + f.width("> " + s) + 5, 38 + i * 13, CYAN);
        }
        int pw = W - 60, prog = Math.min(pw, boot * pw / 90);
        frame(g, 30, 110, pw, 8, alpha(MAGENTA, 0xA0));
        g.fill(32, 112, 30 + prog - 2, 116, MAGENTA);
        if (boot >= 76) {
            int sh = (boot / 4) % 2;
            ctxt(g, t("cutemod.dark.granted"), W / 2 + sh, 130, GREEN);
        }
    }

    private void renderDropped(GuiGraphics g) {
        Font f = font();
        g.fillGradient(0, 0, W, H, 0xFF050208, 0xFF1E0610);
        for (int y = 0; y < H; y += 3) g.fill(0, y, W, y + 1, 0x18000000);
        int gl = ticks % 70 < 5 ? 2 : 0;
        ctxt(g, t("cutemod.dark.dropped"), W / 2 - gl, 56, alpha(CYAN, 0xA0));
        ctxt(g, t("cutemod.dark.dropped"), W / 2 + gl, 56, alpha(RED, 0xFF));
        fitText(g, f, t("cutemod.dark.dropped.hint"), W / 2, 74, W - 40, MUTED, true);
        boolean ov = in(mx, my, W / 2 - 50, 98, 100, 15);
        roundRect(g, W / 2 - 50, 98, 100, 15, 4, ov ? 0xFFFF6FD8 : MAGENTA);
        ctxt(g, t("cutemod.dark.openvpn"), W / 2, 102, 0xFFFFFFFF);
    }

    // ---------- input ----------
    private void add(String id, int amount) {
        Catalog.Entry e = Catalog.get(id);
        if (e == null) return;
        int have = cart.getOrDefault(id, 0);
        if (have == 0 && cart.size() >= dev.cutemod.market.MarketServer.MAX_LINES) { Sfx.error(); return; }
        int now = Math.max(0, Math.min(e.maxQty(), have + amount));
        if (now == 0) cart.remove(id); else cart.put(id, now);
    }

    @Override
    public boolean click(int x, int y, int button) {
        if (!Vpn.on()) {
            if (in(x, y, W / 2 - 50, 98, 100, 15)) { Sfx.click(); shell.launch(Desktop.VPN_ICON); return true; }
            return false;
        }
        if (boot < 100) { if (boot > 40) boot = 100; return true; }        // a click skips the boot
        if (cartOpen) return clickCart(x, y);
        // the cart button
        if (in(x, y, W - 30, 3, 26, 17)) { Sfx.click(); cartOpen = !cartOpen; return true; }
        // the tabs
        if (y >= TAB_Y && y < TAB_Y + TAB_H) {
            int i = Math.max(0, Math.min(TABS - 1, x * TABS / W));
            if (i != tab) { Sfx.click(); tab = i; page = 0; }
            return true;
        }
        if (tab == TAB_ORDERS) {
            if (in(x, y, W - 92, GRID_Y, 86, 12)) { Sfx.click(); Market.collect(shell.pos()); return true; }
            return false;
        }
        // the page switcher
        if (pages() > 1) {
            int px = W - 44;
            if (in(x, y, px - 12, H - 11, 11, 10) && page > 0) { Sfx.click(); page--; return true; }
            if (in(x, y, px + 36, H - 11, 11, 10) && page < pages() - 1) { Sfx.click(); page++; return true; }
        }
        // the cards
        List<String> shelf = shelf();
        for (int i = 0; i < PAGE && page * PAGE + i < shelf.size(); i++) {
            int cx = cardX(i % COLS), cy = cardY(i / COLS);
            if (!in(x, y, cx, cy, CARD_W, CARD_H)) continue;
            String id = shelf.get(page * PAGE + i);
            if (!TaczBridge.loaded()) { Sfx.error(); return true; }
            Sfx.click();
            if (id.startsWith(BlackGoods.AMMO_PREFIX)) add(id, button == 1 ? -16 : 16);
            else if (cart.containsKey(id)) cart.remove(id);
            else add(id, 1);
            return true;
        }
        return false;
    }

    private boolean clickCart(int x, int y) {
        if (!in(x, y, CX, CY, CW, CH)) { cartOpen = false; return true; }
        if (in(x, y, CX + CW - 16, CY + 4, 12, 12)) { Sfx.click(); cartOpen = false; return true; }
        int i = 0;
        for (String id : new ArrayList<>(cart.keySet())) {
            int ry = CY + 21 + i * 12;
            if (in(x, y, CX + 6, ry, CW - 12, 11)) { Sfx.click(); cart.remove(id); return true; }
            i++;
        }
        int by = CY + CH - 40;
        if (in(x, y, CX + 8, by, 100, 11)) { Sfx.click(); express = !express; return true; }
        if (in(x, y, CX + CW - 92, by + 14, 84, 14)) {
            int total = total();
            if (cart.isEmpty() || !TaczBridge.loaded()) { Sfx.error(); return true; }
            if (Progress.coins() < total) { Sfx.error(); return true; }
            if (Market.checkout(cart, express, shell.pos())) {
                Sfx.ui(sv(SoundEvents.NOTE_BLOCK_BIT), 1.4f, 0.5f);
                Progress.toast("cutemod.dark.toast.ordered", mmss(etaSecs()));
                cart.clear();
                cartOpen = false;
                tab = TAB_ORDERS;
            }
            return true;
        }
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        if (keyCode == 256 && cartOpen) { cartOpen = false; return true; }          // escape closes the cart
        return false;
    }
}
