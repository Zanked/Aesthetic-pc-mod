package dev.cutemod.client;

import dev.cutemod.ComputerColor;
import dev.cutemod.client.os.Store;
import dev.cutemod.net.RequestDataPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;

/** Kept in a separate class so the dedicated server never loads client-only code. */
public class ClientHooks {
    /** Called once on the client: forget the server's data when we disconnect. */
    public static void init(net.neoforged.bus.api.IEventBus modBus) {
        // the albums of the player: the folder cutemod_music next to the game becomes a resource pack at every reload
        modBus.addListener((net.neoforged.neoforge.event.AddPackFindersEvent e) -> {
            if (e.getPackType() == net.minecraft.server.packs.PackType.CLIENT_RESOURCES)
                e.addRepositorySource(dev.cutemod.client.player.UserMusic::loadPack);
        });
        // after a reload (start, F3+T, the Rescan button) the albums are read again
        modBus.addListener((net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent e) ->
                e.registerReloadListener((net.minecraft.server.packs.resources.ResourceManagerReloadListener) rm -> {
                    dev.cutemod.client.os.Albums.reload();
                    dev.cutemod.client.player.HeadphonesModel.reset();   // the 3D model of the headphones is baked again
                }));
        // one baked model for all the states of the PC case and the monitor (see SharedMultipart: it saves gigabytes of RAM)
        modBus.addListener((net.neoforged.neoforge.client.event.ModelEvent.RegisterGeometryLoaders e) ->
                e.register(SharedMultipart.ID, SharedMultipart.LOADER));
        // the cooler of the PC case is drawn by the case renderer (only when a cooler is really put in), its models are loaded on their own
        modBus.addListener((net.neoforged.neoforge.client.event.ModelEvent.RegisterAdditional e) -> {
            for (var loc : PcCaseRgbRenderer.EXTRA_MODELS) e.register(loc);
        });
        // the RGB light behind the glass of the PC cases
        modBus.addListener((net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterRenderers e) ->
                e.registerBlockEntityRenderer(dev.cutemod.block.ModBlockEntities.PC_CASE.get(), dev.cutemod.client.PcCaseRgbRenderer::new));
        // the headphones on the head: a real 3D model (band + two cups) instead of the flat helmet texture
        modBus.addListener((net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterLayerDefinitions e) ->
                e.registerLayerDefinition(dev.cutemod.client.player.HeadphonesModel.LAYER, dev.cutemod.client.player.HeadphonesModel::createLayer));
        modBus.addListener((net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent e) ->
                {
                    var ext = new dev.cutemod.client.player.HeadphonesModel.Ext();
                    e.registerItem(ext, dev.cutemod.item.ModItems.HEADPHONES.get());
                    for (var h : dev.cutemod.item.ModItems.COLOR_HEADPHONES.values()) e.registerItem(ext, h.get());
                });
        NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingOut e) -> { dev.cutemod.client.game.BomberNet.clear(); dev.cutemod.client.game.BedwarsNet.clear(); dev.cutemod.client.game.MayhemNet.clear(); dev.cutemod.client.game.SkribblNet.clear(); dev.cutemod.client.os.StreamNet.clear(); dev.cutemod.client.os.TubeNet.clear(); });
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.client.event.ClientTickEvent.Post e) -> dev.cutemod.client.os.Behind.tick());
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.client.event.ClientTickEvent.Post e) -> dev.cutemod.client.player.PlayerEngine.tick());
        NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingOut e) -> dev.cutemod.client.player.PlayerEngine.stop());
        NeoForge.EVENT_BUS.addListener(dev.cutemod.client.player.Headphones::onPlaySound);
        NeoForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingOut e) -> { Store.clear(); dev.cutemod.client.os.Net.clear(); dev.cutemod.client.os.Post.clear(); dev.cutemod.client.os.Show.clear(); dev.cutemod.client.os.Park.clear(); dev.cutemod.client.game.CheckersNet.clear(); dev.cutemod.client.game.BilliardsNet.clear(); dev.cutemod.client.game.DashNet.clear(); dev.cutemod.client.game.DurakNet.clear(); });
    }

    /** The server sent what it has saved for us. */
    public static void onSync(Map<String, String> data) {
        Store.apply(data);
    }

    /** Kept for the old network message: the builds now live in the computer blocks, so there is nothing to do. */
    public static void onHardware(String hw) { }

    /** The build screen of a PC case: open it (the first message) or update the one that is open. */
    public static void onPcBuild(dev.cutemod.net.PcBuildStatePayload p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof PcBuildScreen s && s.isFor(p.pos())) s.apply(p);
        else if (p.open()) mc.setScreen(new PcBuildScreen(p));
    }

    /** The server told us which parcels are on their way (and maybe gave coins back). */
    public static void onMarketSync(dev.cutemod.net.MarketSyncPayload p) {
        dev.cutemod.client.os.Market.applyServer(p);
    }

    /** An operator changed our coins (/cutecoins). */
    public static void onAdminCoins(dev.cutemod.net.AdminCoinsPayload p) {
        dev.cutemod.client.os.Progress.admin(p.set(), p.amount());
    }

    /** An operator opened all our jobs (/cutejobs unlock). */
    public static void onAdminJobs() {
        dev.cutemod.client.os.Jobs.adminUnlock();
    }

    /** The LIVE stream of CuteTube: new chat messages and the number of viewers. */
    public static void onStreamSync(dev.cutemod.net.StreamSyncPayload p) {
        dev.cutemod.client.os.StreamNet.apply(p);
    }

    /** The videos of the other players on CuteTube. */
    public static void onTubeSync(dev.cutemod.net.TubeSyncPayload p) {
        dev.cutemod.client.os.TubeNet.apply(p);
    }

    /** Player mail: the mailbox, the players we can write to and the answer to our last letter. */
    public static void onPostSync(dev.cutemod.net.PostSyncPayload p) {
        dev.cutemod.client.os.Post.apply(p);
    }

    /** CuteNet: the top of a game and who is online. */
    public static void onNetSync(dev.cutemod.net.NetSyncPayload p) {
        dev.cutemod.client.os.Net.apply(p);
    }

    /** Online checkers: who is free to play, invitations and our game. */
    public static void onCheckersSync(dev.cutemod.net.CheckersSyncPayload p) {
        dev.cutemod.client.game.CheckersNet.apply(p);
    }

    /** Online billiards: who is free to play, invitations and our game. */
    public static void onBilliardsSync(dev.cutemod.net.BilliardsSyncPayload p) {
        dev.cutemod.client.game.BilliardsNet.apply(p);
    }

    /** Online Kitty Dash: who is free to race, invitations and our race. */
    public static void onDashSync(dev.cutemod.net.DashSyncPayload p) {
        dev.cutemod.client.game.DashNet.apply(p);
    }

    /** Online Bombers: the open rooms and our room. */
    public static void onBomberLobby(dev.cutemod.net.BomberLobbyPayload p) {
        dev.cutemod.client.game.BomberNet.apply(p);
    }

    /** Online Bombers: the running round. */
    public static void onBomberState(dev.cutemod.net.BomberStatePayload p) {
        dev.cutemod.client.game.BomberNet.applyState(p);
    }

    /** Online Bed Wars: the open rooms and our room. */
    public static void onBedwarsLobby(dev.cutemod.net.BedwarsLobbyPayload p) {
        dev.cutemod.client.game.BedwarsNet.apply(p);
    }

    /** Online Bed Wars: the running round. */
    public static void onBedwarsState(dev.cutemod.net.BedwarsStatePayload p) {
        dev.cutemod.client.game.BedwarsNet.applyState(p);
    }

    /** Online Dangerous Weapons: the open rooms and our room. */
    public static void onMayhemLobby(dev.cutemod.net.MayhemLobbyPayload p) {
        dev.cutemod.client.game.MayhemNet.apply(p);
    }

    /** Online Dangerous Weapons: a snapshot of the running round. */
    public static void onMayhemState(dev.cutemod.net.MayhemStatePayload p) {
        dev.cutemod.client.game.MayhemNet.applyState(p);
    }

    /** Online Scribble Pals: the open rooms and our room. */
    public static void onSkribblLobby(dev.cutemod.net.SkribblLobbyPayload p) {
        dev.cutemod.client.game.SkribblNet.apply(p);
    }

    /** Online Scribble Pals: the picture of the running game. */
    public static void onSkribblState(dev.cutemod.net.SkribblStatePayload p) {
        dev.cutemod.client.game.SkribblNet.applyState(p);
    }

    /** Online Scribble Pals: the drawing changed. */
    public static void onSkribblDraw(dev.cutemod.net.SkribblDrawPayload p) {
        dev.cutemod.client.game.SkribblNet.applyDraw(p);
    }

    /** Online Scribble Pals, telephone game: a picture to describe or an item of a finished chain. */
    public static void onSkribblTele(dev.cutemod.net.SkribblTelePayload p) {
        dev.cutemod.client.game.SkribblNet.applyTele(p);
    }

    /** Online Scribble Pals: a chat line. */
    public static void onSkribblChat(dev.cutemod.net.SkribblChatPayload p) {
        dev.cutemod.client.game.SkribblNet.applyChat(p);
    }

    /** Online Durak: the lobby and the game. */
    public static void onDurakSync(dev.cutemod.net.DurakSyncPayload p) {
        dev.cutemod.client.game.DurakNet.apply(p);
    }

    /** The pet show: a page of the list and the answer to our last action. */
    /** The Pet Park: the other pets and what happened to us. */
    public static void onParkSync(dev.cutemod.net.ParkSyncPayload p) {
        dev.cutemod.client.os.Park.apply(p);
    }

    public static void onShowSync(dev.cutemod.net.ShowSyncPayload p) {
        dev.cutemod.client.os.Show.apply(p);
    }

    /** The talent show is coming. */
    public static void onShowAlert(dev.cutemod.net.ShowAlertPayload p) {
        dev.cutemod.client.os.Show.alert(p.opensInSec(), p.theme());
    }

    /** The talent show paid us for our place. */
    public static void onShowPrize(dev.cutemod.net.ShowPrizePayload p) {
        dev.cutemod.client.os.Show.prize(p.coins(), p.rank());
    }

    public static void openComputer(ComputerColor color, BlockPos pos) { openComputer(color, pos, false); }

    /** A laptop held in the hand: its build (sold as it is, plus the memory and the drive put in) comes from the item. */
    public static void openLaptopInHand(ComputerColor color, String buildText) {
        Minecraft mc = Minecraft.getInstance();
        if (!Store.ready()) {
            PacketDistributor.sendToServer(new RequestDataPayload());
            if (mc.player != null) mc.player.displayClientMessage(Component.translatable("cutemod.sync.wait"), true);
            return;
        }
        dev.cutemod.client.os.PcSpecs.use(buildText, 0L);
        mc.setScreen(new ComputerScreen(color, BlockPos.ZERO, true));
    }

    /** laptop = true: the same OS on a smaller screen (no zoom), BlockPos.ZERO = a laptop held in the hand. */
    public static void openComputer(ComputerColor color, BlockPos pos, boolean laptop) {
        Minecraft mc = Minecraft.getInstance();
        if (!Store.ready()) {                       // the server's copy of our data has not arrived yet
            PacketDistributor.sendToServer(new RequestDataPayload());
            if (mc.player != null) mc.player.displayClientMessage(Component.translatable("cutemod.sync.wait"), true);
            return;
        }
        long seed = pos.asLong();
        var be = mc.level == null ? null : mc.level.getBlockEntity(pos);                // a computer or a laptop put down: the build is in the block
        dev.cutemod.client.os.PcSpecs.use(be instanceof dev.cutemod.block.ComputerBlockEntity cbe ? cbe.build().write() : null, seed);
        mc.setScreen(new ComputerScreen(color, pos, laptop));
    }

    private ClientHooks() {}
}
