package dev.cutemod.client.os;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** A tiny command line. Type "help". Some commands are part of the story quest. */
public class TerminalApp extends App {
    private record Line(String text, int color) {}

    private static final int GREEN = 0xFFB6F59A, WHITE = 0xFFFFFFFF, RED = 0xFFFF8A80, CYAN = 0xFF8FD3FF;
    private static final int ROWS = (H - 16) / 9;
    private static final String[] BEE = {"    \\ | /", "  =( o.o )=   bzz!", "     /'-'\\"};
    private static final String[] CREEPER = {
            "  ##########", "  #  ####  #", "  #  ####  #", "  ####  ####", "  ###    ###", "  ###    ###", "  ####  ####"};
    private static final String[] MEOW = {"  /\\_/\\", " ( o.o )   meow", "  > ^ <"};
    private static final String[] PANDA = {" (o)---(o)", "  ( ^ . ^ )   nom nom", "   \\_____/"};

    private final List<Line> lines = new ArrayList<>();
    private final StringBuilder input = new StringBuilder();
    private final List<String> history = new ArrayList<>();
    private final Random rnd = new Random();
    private int histPos = -1, scroll, ticks, matrix;
    private boolean started;

    @Override
    public void attach(Shell shell) {
        super.attach(shell);
        if (!started) {
            started = true;
            print(t("cutemod.term.banner"), CYAN);
        }
    }

    @Override
    public Component title() { return Component.translatable("cutemod.os.terminal"); }

    @Override
    public Component hint() { return Component.translatable("cutemod.os.hint.terminal"); }

    @Override
    public void tick() {
        ticks++;
        if (matrix > 0) matrix--;
    }

    // ---------- output ----------
    private void print(String text, int color) {
        for (String part : text.split("\n", -1)) lines.add(new Line(part, color));
        while (lines.size() > 200) lines.remove(0);
        scroll = 0;
    }

    private void printKey(String key, int color, Object... args) { print(t(key, args), color); }

    /** The random hardware of this computer (see {@link PcSpecs}). */
    private void sysinfo() {
        PcSpecs.Spec s = PcSpecs.get();
        printKey("cutemod.term.sysinfo.pc", CYAN, s.pcName());
        printKey("cutemod.term.sysinfo.cpu", GREEN, s.cpu(), s.cores(), s.ghz());
        printKey("cutemod.term.sysinfo.ram", GREEN, PcSpecs.gb(s.ramGb()));
        printKey("cutemod.term.sysinfo.gpu", GREEN, s.vramGb() > 0 ? s.gpu() + " (" + s.vramGb() + " GB)" : s.gpu());
        printKey("cutemod.term.sysinfo.disk", GREEN, PcSpecs.gb(s.diskC()) + (s.diskD() > 0 ? " + " + PcSpecs.gb(s.diskD()) : ""));
        {
            Wifi.Net wn = Wifi.current();
            printKey("cutemod.term.sysinfo.modem", GREEN, wn != null ? wn.name() + " (" + wn.mbps() + " Mbit/s, " + wn.bars() + "/4)"
                    : s.modemIdx() >= 1 ? dev.cutemod.data.PcHardware.MODEM_NAMES[s.modemIdx()] + " (" + dev.cutemod.data.PcHardware.MODEM_MBPS[s.modemIdx()] + " Mbit/s)" : t("cutemod.net.nomodem"));
        }
        printKey("cutemod.term.sysinfo.gfx", GREEN, t(GfxQuality.key(dev.cutemod.data.PcHardware.gpuLevel(s.gpuTier()))));
        printKey("cutemod.term.sysinfo.score", GREEN, PcSpecs.score(s));
    }

    private void art(String[] rows) { print(String.join("\n", rows), GREEN); }

    @Override
    public void render(GuiGraphics g, int mx, int my) {
        Font f = font();
        rect(g, 0, 0, W, H, 0xFF0B140E);

        List<FormattedCharSequence> seqs = new ArrayList<>();
        List<Integer> cols = new ArrayList<>();
        for (Line l : lines) {
            for (FormattedCharSequence s : f.split(FormattedText.of(l.text().isEmpty() ? " " : l.text()), W - 12)) {
                seqs.add(s);
                cols.add(l.color());
            }
        }
        int end = seqs.size() - Math.min(scroll, Math.max(0, seqs.size() - ROWS));
        int start = Math.max(0, end - ROWS);
        for (int i = start; i < end; i++) CuteFont.draw(g, f, seqs.get(i), 6, 4 + (i - start) * 9, cols.get(i), false);

        // input line
        rect(g, 0, H - 14, W, 1, 0xFF2A4A32);
        String prompt = "bee@cute:~$ ";
        String typed = input.toString();
        while (typed.length() > 1 && f.width(prompt + typed) > W - 20) typed = typed.substring(1);
        String shownLine = prompt + typed + ((ticks / 30) % 2 == 0 ? "_" : "");
        CuteFont.draw(g, f, shownLine, 6, H - 11, GREEN, false);

        if (matrix > 0) renderMatrix(g);
    }

    private void renderMatrix(GuiGraphics g) {
        Font f = font();
        rect(g, 0, 0, W, H, 0xBB000000);
        for (int c = 0; c < W / 8; c++) {
            int head = (ticks * (2 + c % 3) + c * 37) % (H + 60) - 20;
            for (int k = 0; k < 8; k++) {
                int y = head - k * 9;
                if (y < -9 || y > H) continue;
                int a = Math.max(20, 255 - k * 32);
                String s = ((c + k + ticks / 5) % 2 == 0) ? "1" : "0";
                CuteFont.draw(g, f, s, c * 8 + 2, y, (a << 24) | (k == 0 ? 0xFFFFFF : 0x2BD65A), false);
            }
        }
    }

    // ---------- commands ----------
    private void run(String raw) {
        raw = raw.trim();
        print("$ " + raw, WHITE);
        if (raw.isEmpty()) return;
        if (history.isEmpty() || !history.get(history.size() - 1).equals(raw)) history.add(raw);
        histPos = -1;

        String[] parts = raw.split("\\s+", 2);
        String cmd = parts[0].toLowerCase(Locale.ROOT);
        String arg = parts.length > 1 ? parts[1].trim() : "";
        boolean known = true;

        switch (cmd) {
            case "help", "?" -> printKey("cutemod.term.help", GREEN);
            case "clear", "cls" -> { lines.clear(); scroll = 0; }
            case "echo" -> print(arg, GREEN);
            case "exit", "quit" -> exit();
            case "666", "blood" -> { Hell.start(Hell.SECONDS); print("666", RED); }   // the crimson look for two minutes (also after the video 666)
            case "date", "time" -> print(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")), GREEN);
            case "coins" -> printKey("cutemod.term.coins", GREEN, Progress.streak());
            case "whoami" -> whoami();
            case "sysinfo", "specs", "neofetch" -> sysinfo();
            case "scan" -> scan();
            case "unlock" -> unlock(arg);
            case "crash" -> { printKey("cutemod.term.crash", RED); shell.crash(); }
            case "saver" -> { printKey("cutemod.term.saver", GREEN); shell.saver(); }
            case "repair" -> {
                if (Retro.safe()) { printKey("cutemod.term.repair", GREEN); shell.open(new RepairApp()); }
                else printKey("cutemod.term.repair.none", GREEN);
            }
            case "update" -> update();
            case "archive" -> archive(arg);
            case "listen" -> { if (Progress.step() >= 12) listen(); else { known = false; printKey("cutemod.term.unknown", RED, cmd); } }
            case "say" -> known = say(arg);
            case "status" -> cmdStatus();
            case "hint" -> cmdHint();
            case "ls", "dir" -> print("readme.txt   honey.txt" + (Progress.step() >= 4 ? "   log.txt" : "") + (Progress.step() >= 9 ? "   archive.txt" : "") + (himOpen() ? "   him.txt" : ""), GREEN);
            case "cat", "type" -> file(arg.toLowerCase(Locale.ROOT));
            case "bee" -> art(BEE);
            case "creeper" -> art(CREEPER);
            case "meow" -> art(MEOW);
            case "panda" -> art(PANDA);
            case "matrix" -> { matrix = 360; printKey("cutemod.term.matrix", GREEN); }
            case "fortune" -> printKey("cutemod.term.fortune." + rnd.nextInt(6), CYAN);
            case "sudo" -> printKey("cutemod.term.sudo", RED);
            case "hello", "hi" -> printKey("cutemod.term.hello", GREEN);
            case "42" -> printKey("cutemod.term.42", CYAN);
            case "halloween" -> printKey(Halloween.toggleForce() ? "cutemod.term.halloween.on" : "cutemod.term.halloween.off", RED);
            case "ghost" -> printKey(Haunt.scary ? "cutemod.term.ghost" : "cutemod.term.ghost.off", RED);
            case "walk" -> { if (himOpen()) walk(); else { known = false; printKey("cutemod.term.unknown", RED, cmd); } }
            default -> { known = false; printKey("cutemod.term.unknown", RED, cmd); }
        }
        if (known) { Progress.onCommand(cmd); AppSfx.jobs("good", 1.3F, 0.3F); }      // a command was understood: a tiny "ok"
        else Sfx.error();
    }

    private void whoami() {
        printKey("cutemod.term.whoami", GREEN);
        int step = Progress.step();
        if (step == 2) {
            printKey("cutemod.term.whoami.found", RED);
            Progress.advanceIf(2);
        } else if (step >= 3) {
            printKey("cutemod.term.whoami.again", CYAN);
        }
    }

    private void scan() {
        printKey("cutemod.term.scan", GREEN);
        if (Progress.step() >= 2) printKey("cutemod.term.scan.bad", RED);
    }

    private void unlock(String arg) {
        int step = Progress.step();
        if (arg.isEmpty()) { printKey("cutemod.term.unlock.usage", GREEN); return; }
        if (step < 3) { printKey("cutemod.term.unlock.nothing", RED); return; }
        if (step > 3) { printKey("cutemod.term.unlock.done", CYAN); return; }
        if (arg.replace(":", "").equals("0333")) {
            printKey("cutemod.term.unlock.ok", GREEN);
            Progress.advanceIf(3);
        } else {
            printKey("cutemod.term.unlock.wrong", RED);
        }
    }

    /** Part 2, chapter "The Window": the code from the picture in the hidden article. */
    private void archive(String arg) {
        int step = Progress.step();
        if (arg.isEmpty()) { printKey("cutemod.term.archive.usage", GREEN); return; }
        if (step < 8) { printKey("cutemod.term.archive.nothing", RED); return; }
        if (step > 8) { printKey("cutemod.term.archive.done", CYAN); return; }
        if (arg.equals("1307")) {
            printKey("cutemod.term.archive.ok", GREEN);
            Progress.advanceIf(8);
        } else {
            printKey("cutemod.term.archive.wrong", RED);
        }
    }

    /** Part 2, the last chapter: "listen". There is one ending, so nothing is asked: he only repeats you. */
    private void listen() {
        int step = Progress.step();
        String me = net.minecraft.client.Minecraft.getInstance().getUser().getName();
        for (int i = 0; i < 4; i++) printKey("cutemod.term.listen." + i, i == 3 ? RED : CYAN, me);
        if (step == 12) {
            Progress.setEnding(1);
            Progress.advanceIf(12);
        }
    }

    /** "exit" closes the Terminal. In the last chapter of part 1 it answers first, and the Terminal stays open once. */
    private void exit() {
        if (Progress.step() == 6) {
            printKey("cutemod.term.exit.0", GREEN);
            printKey("cutemod.term.exit.1", RED);
            printKey("cutemod.term.exit.2", RED);
            Progress.advanceIf(6);
            return;
        }
        shell.home();
    }

    /** The end of the big easter egg: the phrase of the Stranger (see {@link Traces}). Without it the command looks unknown. */
    private boolean say(String arg) {
        if (!Traces.started()) { printKey("cutemod.term.unknown", RED, "say"); return false; }
        if (arg.isEmpty()) { printKey("cutemod.term.say.usage", GREEN); return true; }
        switch (Traces.say(arg)) {
            case Traces.SAY_LOCKED -> printKey("cutemod.term.say.locked", RED);
            case Traces.SAY_WRONG -> printKey("cutemod.term.say.wrong", RED);
            case Traces.SAY_DONE -> printKey("cutemod.term.say.done", CYAN);
            case Traces.SAY_ALONE -> {                                    // the second ending: one word was taken out
                for (int i = 0; i < 5; i++) printKey("cutemod.term.say.alone." + i, i >= 3 ? CYAN : GREEN);
                Sfx.ui(net.minecraft.sounds.SoundEvents.AMBIENT_CAVE.value(), 0.6F, 0.6F);
            }
            default -> {
                for (int i = 0; i < 6; i++) printKey("cutemod.term.say.ok." + i, i >= 4 ? CYAN : GREEN);
                Sfx.ui(net.minecraft.sounds.SoundEvents.AMETHYST_BLOCK_RESONATE, 0.8F, 1.0F);
            }
        }
        return true;
    }

    /** "update": the installed version, and what is waiting (or when the next one comes). */
    private void update() {
        printKey("cutemod.term.update.ver", GREEN, Updates.versionLabel());
        int a = Updates.available();
        if (a >= 0) printKey("cutemod.term.update.ready", CYAN, t("cutemod.update." + Updates.ALL.get(a).id() + ".name"));
        else if (Updates.upcoming() != null) printKey("cutemod.term.update.next", GREEN, Updates.upcoming().date().toString());
        else printKey("cutemod.term.update.none", GREEN);
    }

    private void cmdStatus() {
        int step = Progress.step();
        if (Progress.questDone() && Progress.step3() < Progress.Q3_STEPS) {      // part 3
            int s3 = Progress.step3();
            printKey("cutemod.q3.chapter", CYAN, s3 + 1, Progress.Q3_STEPS, t("cutemod.q3." + s3 + ".title"));
            printKey("cutemod.q3." + s3 + ".goal", GREEN);
            return;
        }
        if (Progress.questDone()) { printKey("cutemod.quest.done", GREEN); return; }
        printKey("cutemod.quest.chapter", CYAN, step + 1, Progress.QUEST_STEPS, t("cutemod.quest." + step + ".title"));
        printKey("cutemod.quest." + step + ".goal", GREEN);
    }

    private void cmdHint() {
        if (Progress.questDone() && Progress.step3() < Progress.Q3_STEPS) { printKey("cutemod.q3." + Progress.step3() + ".hint", CYAN); return; }
        if (Progress.questDone()) { printKey("cutemod.quest.done", GREEN); return; }
        printKey("cutemod.quest." + Progress.step() + ".hint", CYAN);
    }

    // ---------- part 3, chapter 5: three steps ----------
    private long walkAt;

    /** him.txt and "walk" exist once part 2 is done, Spooky is on and the player has reached chapter 5 of part 3. */
    private static boolean himOpen() { return Haunt.scary && Progress.questDone() && Progress.step3() >= 4; }

    private void walk() {
        if (Progress.step3() > 4) { printKey("cutemod.term.walk.done", RED); return; }
        long now = System.currentTimeMillis();
        if (now - walkAt < 15_000L) { printKey("cutemod.term.walk.wait", RED); return; }   // he walks slowly
        walkAt = now;
        int n = Progress.count("q3_walk") + 1;
        Progress.setCount("q3_walk", n);
        printKey("cutemod.term.walk." + Math.min(3, n), RED);
        if (n >= 3) Progress.advance3(4);
    }

    /** Part 1, chapter 5: his notes about you. The times follow your real clock, the last line is a minute ahead. */
    private void log() {
        String me = net.minecraft.client.Minecraft.getInstance().getUser().getName();
        int[] ago = {52, 41, 33, 12, 3, 0, -1};
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm");
        for (int i = 0; i < ago.length; i++) {
            printKey("cutemod.term.log." + i, i >= 5 ? RED : GREEN, now.minusMinutes(ago[i]).format(fmt), me);
        }
        Progress.advanceIf(4);
    }

    private void file(String name) {
        switch (name) {
            case "" -> printKey("cutemod.term.cat.usage", GREEN);
            case "readme.txt" -> printKey("cutemod.term.file.readme", GREEN);
            case "honey.txt" -> printKey("cutemod.term.file.honey", GREEN);
            case "archive.txt" -> {
                if (Progress.step() >= 9) printKey("cutemod.term.file.archive", CYAN);
                else printKey("cutemod.term.file.denied", RED);
            }
            case "him.txt" -> {
                if (himOpen()) printKey("cutemod.term.file.him", RED);
                else printKey("cutemod.term.file.none", RED, name);
            }
            case "log.txt" -> {
                if (Progress.step() >= 4) log();
                else printKey("cutemod.term.file.denied", RED);
            }
            default -> printKey("cutemod.term.file.none", RED, name);
        }
    }

    // ---------- input ----------
    @Override
    public boolean charTyped(char c) {
        if (c < 32 || c == 127) return false;
        input.append(c);
        return true;
    }

    @Override
    public boolean key(int keyCode, int modifiers) {
        switch (keyCode) {
            case 257, 335 -> { String s = input.toString(); input.setLength(0); run(s); }       // enter
            case 259 -> { if (input.length() > 0) input.setLength(input.length() - 1); }          // backspace
            case 265 -> {                                                                         // up: older command
                if (!history.isEmpty()) {
                    histPos = histPos < 0 ? history.size() - 1 : Math.max(0, histPos - 1);
                    input.setLength(0);
                    input.append(history.get(histPos));
                }
            }
            case 264 -> {                                                                         // down: newer command
                if (histPos >= 0) {
                    histPos++;
                    input.setLength(0);
                    if (histPos < history.size()) input.append(history.get(histPos)); else histPos = -1;
                }
            }
            case 266 -> scroll += 8;                                                              // page up
            case 267 -> scroll = Math.max(0, scroll - 8);                                         // page down
            default -> { return false; }
        }
        return true;
    }

    @Override
    public boolean scroll(double amount) {
        scroll = Math.max(0, scroll + (amount > 0 ? 3 : -3));
        return true;
    }
}
