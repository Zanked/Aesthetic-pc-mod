package dev.cutemod.market;

import dev.cutemod.data.PcHardware;
import dev.cutemod.data.PlayerData;
import dev.cutemod.item.ModItems;
import dev.cutemod.net.SaveDataPayload;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

import java.util.UUID;

/**
 * Old saves kept ONE set of parts for the whole player ("ram,gpu,disk,modem" under "hw"). Now every computer block has its own build,
 * so the first time such a player logs in, the parts they paid for are paid back in coins at the OLD prices (the old ladders are
 * copied below, they no longer exist anywhere else) and the modem comes back as an item to put into a computer. The old text is
 * replaced by a marker, so this happens once. Server side.
 */
public final class LegacyParts {
    private LegacyParts() {}

    private static final String DONE = "v2";
    private static final int[] RAM_PRICE = {0, 30, 70, 140, 260, 480};
    private static final int[] GPU_PRICE = {0, 50, 120, 240, 420, 700, 1100, 1600};
    private static final int[] DISK_PRICE = {0, 25, 50, 100, 170, 260, 380, 580, 950, 1500};

    /** Pays back an old save. Returns the coins owed (0 if nothing, or it was done before). */
    public static int migrate(ServerPlayer sp) {
        var server = sp.getServer();
        if (server == null) return 0;
        PlayerData data = PlayerData.get(server);
        UUID id = sp.getUUID();
        String hw = data.copyOf(id).get(SaveDataPayload.HARDWARE);
        if (hw == null || hw.isBlank() || hw.equals(DONE)) return 0;
        int[] v = {-1, -1, -1, -1};
        String[] p = hw.trim().split(",");
        for (int i = 0; i < 4 && i < p.length; i++) {
            try { v[i] = Integer.parseInt(p[i].trim()); } catch (NumberFormatException ignored) { }
        }
        int coins = price(RAM_PRICE, v[0]) + price(GPU_PRICE, v[1]) + price(DISK_PRICE, v[2]);
        if (v[3] >= PcHardware.MODEM_FIRST && v[3] <= PcHardware.MODEM_LAST) {
            ItemStack modem = ModItems.partStack(PcHardware.Kind.MODEM, v[3]);
            if (!modem.isEmpty() && !sp.getInventory().add(modem)) sp.drop(modem, false);
        }
        data.put(id, SaveDataPayload.HARDWARE, DONE);
        if (coins > 0 || v[3] > 0)
            sp.displayClientMessage(Component.translatable("cutemod.part.migrated", coins), false);
        return coins;
    }

    private static int price(int[] ladder, int level) { return level > 0 && level < ladder.length ? ladder[level] : 0; }
}
