package dev.cutemod.market;

import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.ModList;

import java.lang.reflect.Method;

/**
 * The link to the gun mod TACZ (Timeless and Classics Guns: Zero). It is only ever used through reflection, so the mod
 * does not need TACZ to compile or to start: without TACZ the dark market simply shows its goods as "out of stock".
 * Guns and ammo are made with TACZ's own item builders, so they are real, working TACZ items.
 */
public final class TaczBridge {
    private TaczBridge() {}

    public static final String MOD_ID = "tacz";

    private static final String GUN_BUILDER = "com.tacz.guns.api.item.builder.GunItemBuilder";
    private static final String AMMO_BUILDER = "com.tacz.guns.api.item.builder.AmmoItemBuilder";

    private static Boolean present;
    private static boolean broken;

    /** True when TACZ is installed (and its builders could be found). */
    public static boolean loaded() {
        if (broken) return false;
        if (present == null) {
            try {
                present = ModList.get() != null && ModList.get().isLoaded(MOD_ID);
            } catch (Throwable t) {
                present = false;
            }
        }
        return present;
    }

    private static Method find(Class<?> c, String name, int args) {
        for (Method m : c.getMethods()) if (m.getName().equals(name) && m.getParameterCount() == args) return m;
        return null;
    }

    /** A TACZ gun of the pack (gun id like "ak47"), full magazine and a bullet in the barrel. Empty when TACZ is missing. */
    public static ItemStack gun(String gunId, int magazine, RegistryAccess access) {
        if (!loaded()) return ItemStack.EMPTY;
        try {
            Class<?> bc = Class.forName(GUN_BUILDER);
            Object b = find(bc, "create", 0).invoke(null);
            b = find(bc, "setId", 1).invoke(b, ResourceLocation.fromNamespaceAndPath(MOD_ID, gunId));
            b = find(bc, "setCount", 1).invoke(b, 1);
            b = find(bc, "setAmmoCount", 1).invoke(b, Math.max(0, magazine));
            Method barrel = find(bc, "setAmmoInBarrel", 1);
            if (barrel != null) b = barrel.invoke(b, magazine > 0);
            Object out = find(bc, "build", 1).invoke(b, access);
            return out instanceof ItemStack s ? s : ItemStack.EMPTY;
        } catch (Throwable t) {
            broken = true;                       // a different TACZ version: stop trying, the shelves show "out of stock"
            return ItemStack.EMPTY;
        }
    }

    /** TACZ ammunition (ammo id like "762x39"). Counts are set by the caller. */
    public static ItemStack ammo(String ammoId) {
        if (!loaded()) return ItemStack.EMPTY;
        try {
            Class<?> bc = Class.forName(AMMO_BUILDER);
            Object b = find(bc, "create", 0).invoke(null);
            b = find(bc, "setId", 1).invoke(b, ResourceLocation.fromNamespaceAndPath(MOD_ID, ammoId));
            b = find(bc, "setCount", 1).invoke(b, 1);
            Object out = find(bc, "build", 0).invoke(b);
            return out instanceof ItemStack s ? s : ItemStack.EMPTY;
        } catch (Throwable t) {
            broken = true;
            return ItemStack.EMPTY;
        }
    }
}
