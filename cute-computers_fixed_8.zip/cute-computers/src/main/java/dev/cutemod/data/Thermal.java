package dev.cutemod.data;

/**
 * The heat of a PC that was built in a case: how hot the processor and the video card get under full load, from the cooler, the
 * tidiness of the cables (air flows better through a tidy case) and the watts the two parts burn. Pure numbers, no Minecraft
 * classes, so the server (which decides whether the PC may start) and the client (which draws the numbers) share it.
 *
 * <p>The rule of thumb: {@code temperature = 28 + 62 * watts / cooling}, so a part whose watts equal its cooling sits at 90 degrees,
 * where it starts to throttle (the games get slower); at {@link #CRIT} degrees the PC does not start at all (thermal protection).
 * A cooler is optional for the weak processors (a boxed heatsink is enough for the first ones), the strong ones need a real cooler.
 */
public final class Thermal {
    private Thermal() {}

    public static final int AMBIENT = 28;
    /** From this temperature a part throttles (one step; two steps from {@link #HOT}). */
    public static final int THROTTLE = 90, HOT = 96;
    /** From this temperature the PC refuses to start. */
    public static final int CRIT = 100;

    // ---------- coolers (level 0 = none; the items are level 1..3) ----------
    public static final String[] COOLER_NAMES = {"No cooler", "Cute Air 92", "Cute Tower 120", "Cute Liquid 240"};
    /** The watts of the processor each cooler can carry away at 90 degrees. */
    public static final int[] COOLER_CAP = {80, 140, 240, 400};
    /** How much each cooler helps the airflow of the whole case (added to 1.0). */
    public static final double[] COOLER_AIR = {0.0, 0.0, 0.05, 0.10};
    public static final int[] COOLER_PRICE = {0, 45, 110, 260};
    public static final int COOLER_FIRST = 1, COOLER_LAST = 3;
    /** A case built before the coolers existed keeps working: it counts as a good tower cooler until a real one is put in. */
    public static final int LEGACY_CAP = 240;
    /** A cooler without thermal paste on the processor carries away only this part of its watts. */
    public static final double NO_PASTE = 0.85;

    /** The watts of the video card each level can carry away at 90 degrees with the airflow of 1.0 (its own fans). */
    public static final int[] GPU_CAP = {1, 45, 105, 185, 330};

    /** What a freshly plugged-in set of cables gives: not neat, not a mess. The cable puzzle replaces it. */
    public static final int TIDY_DEFAULT = 40, TIDY_LEGACY = 50;

    public static String coolerName(int level) { return COOLER_NAMES[Math.max(0, Math.min(COOLER_NAMES.length - 1, level))]; }

    /** The airflow of the case: 1.0 +- 0.15 from the cables (tidy 0..100) and a little from the cooler. */
    public static double air(int cooler, int tidy) {
        int t = Math.max(0, Math.min(100, tidy));
        int c = Math.max(0, Math.min(COOLER_AIR.length - 1, cooler));
        return 1.0 + 0.15 * (t - 50) / 50.0 + COOLER_AIR[c];
    }

    /**
     * Full-load temperature of the processor. {@code cooler} is 0 for none (or the level 1..3), {@code legacy} says the case has
     * the old factory cooling and no cooler was ever put in; {@code paste} says the processor has thermal paste (a cooler needs it).
     */
    public static int cpuTemp(int cpuWatts, int cooler, boolean legacy, int tidy, boolean paste) {
        double cap = cooler > 0 ? COOLER_CAP[Math.min(cooler, COOLER_CAP.length - 1)] * (paste ? 1.0 : NO_PASTE)
                : legacy ? LEGACY_CAP : COOLER_CAP[0];
        return (int) Math.round(AMBIENT + 62.0 * cpuWatts / (cap * air(cooler, tidy)));
    }

    /** Full-load temperature of the video card; 0 if there is none. */
    public static int gpuTemp(int gpuLevel, int gpuWatts, int cooler, int tidy) {
        if (gpuLevel <= 0) return 0;
        int cap = GPU_CAP[Math.min(gpuLevel, GPU_CAP.length - 1)];
        return (int) Math.round(AMBIENT + 62.0 * gpuWatts / (cap * air(cooler, tidy)));
    }

    /** How many steps a part with this temperature throttles: 0, 1 or 2. */
    public static int steps(int temp) { return temp >= HOT ? 2 : temp >= THROTTLE ? 1 : 0; }

    public static boolean critical(int temp) { return temp >= CRIT; }
}
