package dev.cutemod.data;

/**
 * The three kinds of laptop. In a laptop the processor, the video card, the motherboard and the power supply are soldered on and
 * cannot be changed; only the memory (two slots, up to 2 x 16 GB) and the drive can be upgraded. Pure data, no Minecraft classes.
 * <ul>
 *   <li><b>OFFICE</b>: thick bezels, black / white / silver. Modest: Bee 5, GT 710, 8 GB, a 64 GB SSD.</li>
 *   <li><b>NEO</b>: the slim one (the colourful laptops). Good: Bee 7, Radish 5500, 16 GB, a 128 GB NVMe drive.</li>
 *   <li><b>GAMING</b>: thin, black or white with RGB lighting. The best that exists: Panda Ultra X, RTX 4080, 2 x 16 GB, a 1 TB NVMe drive,
 *       Fiber Max, and a 550 W supply so that it never browns out under full load.</li>
 * </ul>
 */
public enum LaptopLine {
    OFFICE("office", 420, 180),
    NEO("neo", 900, 240),
    GAMING("gaming", 3900, 420);

    public final String id;
    /** The price in the shop in coins and the delivery time in seconds. */
    public final int price, secs;

    LaptopLine(String id, int price, int secs) {
        this.id = id;
        this.price = price;
        this.secs = secs;
    }

    /**
     * The build a laptop of this kind is sold with. The board stays the stock one (it takes any processor and has the two slots of a
     * laptop). The office and Neo laptops keep the stock 250 W supply (their load is at most 245 W); the gaming one has a 550 W supply:
     * a Panda Ultra X and an RTX 4080 draw 525 W with the rest of the machine, so the stock supply would make it restart and crash.
     */
    public Build build() {
        Build b = new Build();
        switch (this) {
            case OFFICE -> { b.cpu = 1; b.gpu = 1; b.disk = 3; b.modem = 3; b.sticks[0] = 8; }                       // Bee 5, GT 710, 8 GB, 64 GB
            case NEO -> { b.cpu = 2; b.gpu = 2; b.disk = 5; b.modem = 4; b.sticks[0] = 16; }                         // Bee 7, Radish 5500, 16 GB, 128 GB
            case GAMING -> { b.cpu = 4; b.gpu = 4; b.disk = 9; b.modem = 5; b.psu = 2; b.sticks[0] = 16; b.sticks[1] = 16; }   // the best of everything, 32 GB, 1 TB
        }
        return b;
    }

    /** Only the memory and the drive of a laptop can be changed. */
    public static boolean upgradable(PcHardware.Kind kind) {
        return kind == PcHardware.Kind.RAM || kind == PcHardware.Kind.DISK;
    }
}
