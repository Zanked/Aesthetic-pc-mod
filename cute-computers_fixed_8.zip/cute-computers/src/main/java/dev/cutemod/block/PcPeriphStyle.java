package dev.cutemod.block;

import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.block.state.properties.EnumProperty;

/**
 * The look of a keyboard or a mouse. It is its OWN look: it does not depend on the colour of the monitor it is connected to.
 * The ids are the same as in tools/make_pc_peripherals.py (textures, models, recipes and the names are made there).
 */
public enum PcPeriphStyle implements StringRepresentable {
    WHITE("white"), PINK("pink"), BLUE("blue"), MINT("mint"), PURPLE("purple"), YELLOW("yellow"), RED("red"), BLACK("black"),
    BLACK_RGB("black_rgb"), WHITE_RGB("white_rgb"), SAKURA("sakura");

    /** The look of the keyboard connected to a monitor / of the mouse connected to a monitor (block state of {@link PcMonitorBlock}). */
    public static final EnumProperty<PcPeriphStyle> KEYBOARD_PROPERTY = EnumProperty.create("kb_style", PcPeriphStyle.class);
    public static final EnumProperty<PcPeriphStyle> MOUSE_PROPERTY = EnumProperty.create("ms_style", PcPeriphStyle.class);

    public final String id;

    PcPeriphStyle(String id) { this.id = id; }

    @Override
    public String getSerializedName() { return id; }
}
