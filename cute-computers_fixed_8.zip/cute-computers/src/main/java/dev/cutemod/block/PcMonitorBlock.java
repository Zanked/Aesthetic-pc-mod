package dev.cutemod.block;

import com.mojang.serialization.MapCodec;
import dev.cutemod.ComputerColor;
import dev.cutemod.client.ClientHooks;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The monitor. Its screen is dark until a desk is complete around it (see {@link PcLink}: a PC case that is switched on, a keyboard
 * and a mouse); then the screen lights up with the desktop and a right-click opens the OS of that case. It looks again every second,
 * so it goes dark by itself when the PC is switched off or a part of the desk is taken away.
 * <ul>
 *   <li>The keyboard and the mouse are CONNECTED to the monitor: right-click it with a keyboard or a mouse in the hand and the item
 *       appears in front of the monitor (see {@link #attach}). Sneak + right-click with an empty hand takes the last one off again;
 *       a monitor that is broken drops them.</li>
 *   <li>It has a colour ({@link PcColor}): right-click with a dye to paint it. The keyboard and the mouse have their OWN look ({@link PcPeriphStyle}) and do not take the colour of the monitor.</li>
 * </ul>
 */
public class PcMonitorBlock extends Block {
    public static final MapCodec<PcMonitorBlock> CODEC = simpleCodec(PcMonitorBlock::new);
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final BooleanProperty ON = BooleanProperty.create("on");
    /** A keyboard / a mouse is connected to this monitor (drawn in front of it). */
    public static final BooleanProperty KEYBOARD = BooleanProperty.create("keyboard");
    public static final BooleanProperty MOUSE = BooleanProperty.create("mouse");
    /** The look of the connected keyboard / mouse (only used while KEYBOARD / MOUSE is true; see {@link PcPeriphStyle}). */
    public static final net.minecraft.world.level.block.state.properties.EnumProperty<PcPeriphStyle> KB_STYLE = PcPeriphStyle.KEYBOARD_PROPERTY;
    public static final net.minecraft.world.level.block.state.properties.EnumProperty<PcPeriphStyle> MS_STYLE = PcPeriphStyle.MOUSE_PROPERTY;

    /** [turn][keyboard ? 1 : 0 | mouse ? 2 : 0] */
    private static final VoxelShape[][] SHAPES = new VoxelShape[4][4];
    static {
        for (int turn = 0; turn < 4; turn++) {
            VoxelShape base = Shapes.or(
                    ComputerBlock.rotated(3.0, 0, 6.7, 13.0, 0.6, 12.5, turn),           // the legs
                    ComputerBlock.rotated(7.3, 0.5, 7.0, 8.7, 3.6, 8.0, turn),           // the neck
                    ComputerBlock.rotated(0.5, 3.4, 6.4, 15.5, 13.2, 8.8, turn));        // the screen
            VoxelShape keyboard = ComputerBlock.rotated(3.5, 0, 12.2, 12.5, 0.7, 15.4, turn);
            VoxelShape mouse = ComputerBlock.rotated(13.2, 0, 12.6, 14.7, 0.7, 14.8, turn);
            SHAPES[turn][0] = base;
            SHAPES[turn][1] = Shapes.or(base, keyboard);
            SHAPES[turn][2] = Shapes.or(base, mouse);
            SHAPES[turn][3] = Shapes.or(base, keyboard, mouse);
        }
    }

    public PcMonitorBlock(BlockBehaviour.Properties props) {
        super(props);
        // a boolean property starts as TRUE unless it is set, so everything is set here: a white monitor with nothing connected
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.SOUTH).setValue(ON, false)
                .setValue(PcColor.PROPERTY, PcColor.WHITE).setValue(KEYBOARD, false).setValue(MOUSE, false)
                .setValue(KB_STYLE, PcPeriphStyle.WHITE).setValue(MS_STYLE, PcPeriphStyle.WHITE));
    }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) { builder.add(FACING, ON, PcColor.PROPERTY, KEYBOARD, MOUSE, KB_STYLE, MS_STYLE); }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite()).setValue(ON, false)
                .setValue(KEYBOARD, false).setValue(MOUSE, false);
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rot) { return state.setValue(FACING, rot.rotate(state.getValue(FACING))); }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) { return state.rotate(mirror.getRotation(state.getValue(FACING))); }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPES[ComputerBlock.turnsOf(state.getValue(FACING))][(state.getValue(KEYBOARD) ? 1 : 0) | (state.getValue(MOUSE) ? 2 : 0)];
    }

    // ---------- the screen lights up by itself ----------
    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (!level.isClientSide && !oldState.is(state.getBlock())) level.scheduleTick(pos, this, 20);
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        refresh(level, pos, state);
        level.scheduleTick(pos, this, 20);
    }

    /** Server side: light the screen if a full desk is around it, darken it if not. */
    public static void refresh(Level level, BlockPos pos, BlockState state) {
        if (level.isClientSide || !(state.getBlock() instanceof PcMonitorBlock)) return;
        boolean ok = PcLink.find(level, pos).ok();
        if (state.getValue(ON) != ok) level.setBlock(pos, state.setValue(ON, ok), 3);
    }

    // ---------- connecting a keyboard and a mouse, painting ----------
    /**
     * A keyboard or a mouse is connected to the monitor: it appears in front of it and one item is used up (not in creative mode).
     * Server side only does the work; the caller answers the click.
     */
    public static void attach(ItemStack stack, PcPeripheralBlock.Kind kind, PcPeriphStyle style, BlockState state, Level level, BlockPos pos, Player player) {
        if (level.isClientSide || !(state.getBlock() instanceof PcMonitorBlock)) return;
        boolean keyboard = kind == PcPeripheralBlock.Kind.KEYBOARD;
        BooleanProperty prop = keyboard ? KEYBOARD : MOUSE;
        if (state.getValue(prop)) {
            if (player instanceof ServerPlayer sp)
                sp.displayClientMessage(Component.translatable(keyboard ? "cutemod.monitor.has_keyboard" : "cutemod.monitor.has_mouse").withStyle(ChatFormatting.GOLD), true);
            level.playSound(null, pos, SoundEvents.VILLAGER_NO, SoundSource.BLOCKS, 0.5F, 1.4F);
            return;
        }
        Component name = stack.getHoverName();
        BlockState next = state.setValue(prop, true).setValue(keyboard ? KB_STYLE : MS_STYLE, style);
        level.setBlock(pos, next, 3);
        if (player == null || !player.getAbilities().instabuild) stack.shrink(1);
        level.playSound(null, pos, SoundEvents.ITEM_FRAME_ADD_ITEM, SoundSource.BLOCKS, 0.8F, 1.3F);
        if (player instanceof ServerPlayer sp)
            sp.displayClientMessage(Component.translatable("cutemod.monitor.attached", name).withStyle(ChatFormatting.GREEN), true);
        refresh(level, pos, next);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player,
                                              InteractionHand hand, BlockHitResult hit) {
        if (stack.getItem() instanceof dev.cutemod.item.PcPeripheralItem item) {
            attach(stack, item.kind(), item.style(), state, level, pos, player);
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        ItemInteractionResult painted = PcColor.recolor(stack, state, level, pos, player);
        if (painted != null) return painted;
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    /** A monitor that is broken gives back the keyboard and the mouse that were connected to it (the monitor itself comes from the loot table). */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide) {
            if (state.getValue(KEYBOARD)) Block.popResource(level, pos, new ItemStack(dev.cutemod.block.ModBlocks.keyboardItem(state.getValue(KB_STYLE))));
            if (state.getValue(MOUSE)) Block.popResource(level, pos, new ItemStack(dev.cutemod.block.ModBlocks.mouseItem(state.getValue(MS_STYLE))));
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    // ---------- use ----------
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (player.isShiftKeyDown()) {                       // sneak + an empty hand: the mouse (then the keyboard) is taken off
            if (!level.isClientSide) detach(state, level, pos, player);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        PcLink.Result link = PcLink.find(level, pos);
        if (level.isClientSide) {
            if (link.ok()) ClientHooks.openComputer(ComputerColor.WHITE, link.casePos());
            return InteractionResult.sidedSuccess(true);
        }
        refresh(level, pos, state);
        if (!link.ok() && player instanceof ServerPlayer sp) {
            String key = !link.caseExists() ? "cutemod.monitor.no_case"
                    : link.casePos() == null ? "cutemod.monitor.case_off"
                    : !link.keyboard() && !link.mouse() ? "cutemod.monitor.no_desk"
                    : !link.keyboard() ? "cutemod.monitor.no_keyboard" : "cutemod.monitor.no_mouse";
            sp.displayClientMessage(Component.translatable(key).withStyle(ChatFormatting.GOLD), true);
            level.playSound(null, pos, SoundEvents.VILLAGER_NO, SoundSource.BLOCKS, 0.5F, 1.4F);
        }
        return InteractionResult.sidedSuccess(false);
    }

    /** The mouse comes off first, then the keyboard; the item goes to the player's hands (or to the floor when the bag is full). */
    private static void detach(BlockState state, Level level, BlockPos pos, Player player) {
        boolean mouse = state.getValue(MOUSE);
        if (!mouse && !state.getValue(KEYBOARD)) {
            if (player instanceof ServerPlayer sp)
                sp.displayClientMessage(Component.translatable("cutemod.monitor.bare").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        ItemStack out = new ItemStack(mouse ? dev.cutemod.block.ModBlocks.mouseItem(state.getValue(MS_STYLE)) : dev.cutemod.block.ModBlocks.keyboardItem(state.getValue(KB_STYLE)));
        BlockState next = state.setValue(mouse ? MOUSE : KEYBOARD, false);
        level.setBlock(pos, next, 3);
        level.playSound(null, pos, SoundEvents.ITEM_FRAME_REMOVE_ITEM, SoundSource.BLOCKS, 0.8F, 1.3F);
        if (player instanceof ServerPlayer sp) {
            sp.displayClientMessage(Component.translatable("cutemod.monitor.detached", out.getHoverName()).withStyle(ChatFormatting.YELLOW), true);
            if (!sp.getInventory().add(out)) sp.drop(out, false);
        }
        refresh(level, pos, next);
    }
}
