package dev.cutemod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * What makes a desk: a monitor works with a PC case that is switched on within {@link #CASE_RANGE} blocks, a keyboard and a mouse
 * that are connected to the monitor (right-click the monitor with them: see {@link PcMonitorBlock#attach}; keyboard and mouse blocks
 * that were put on the table in older worlds still count too). Nothing is stored: the answer is worked out from the blocks around (the same on the server and
 * the client, so the client can open the OS and the server can say what is missing).
 */
public final class PcLink {
    private PcLink() {}

    /** A case farther than this from the monitor is not its case (the shop and the records want the player within 10 blocks of the case). */
    public static final int CASE_RANGE = 5;
    public static final int DESK_RANGE = 4;

    /** casePos = the nearest case that is ON (null if none); caseExists = there is a case but it is off. */
    public record Result(BlockPos casePos, boolean caseExists, boolean keyboard, boolean mouse) {
        public boolean ok() { return casePos != null && keyboard && mouse; }
    }

    public static Result find(Level level, BlockPos monitor) {
        BlockPos on = null;
        double onDist = Double.MAX_VALUE;
        boolean anyCase = false, kb = false, ms = false;
        BlockState self = level.getBlockState(monitor);
        if (self.getBlock() instanceof PcMonitorBlock) {   // the keyboard and the mouse that are connected to the monitor
            kb = self.getValue(PcMonitorBlock.KEYBOARD);
            ms = self.getValue(PcMonitorBlock.MOUSE);
        }
        int r = Math.max(CASE_RANGE, DESK_RANGE);
        for (BlockPos p : BlockPos.betweenClosed(monitor.offset(-r, -r, -r), monitor.offset(r, r, r))) {
            BlockState st = level.getBlockState(p);
            Block b = st.getBlock();
            if (b instanceof PcCaseBlock) {
                double d = p.distSqr(monitor);
                if (d > CASE_RANGE * CASE_RANGE) continue;
                anyCase = true;
                if (st.getValue(PcCaseBlock.LIT) && d < onDist) { onDist = d; on = p.immutable(); }
            } else if (b instanceof PcPeripheralBlock pb && p.distSqr(monitor) <= DESK_RANGE * DESK_RANGE) {
                if (pb.kind() == PcPeripheralBlock.Kind.KEYBOARD) kb = true; else ms = true;
            }
        }
        return new Result(on, anyCase, kb, ms);
    }

    /** The case was switched on or off or changed: the monitors around it look again right now (they also look by themselves every second). */
    public static void refreshMonitors(Level level, BlockPos casePos) {
        if (level.isClientSide) return;
        int r = CASE_RANGE;
        for (BlockPos p : BlockPos.betweenClosed(casePos.offset(-r, -r, -r), casePos.offset(r, r, r))) {
            BlockState st = level.getBlockState(p);
            if (st.getBlock() instanceof PcMonitorBlock) PcMonitorBlock.refresh(level, p.immutable(), st);
        }
    }
}
