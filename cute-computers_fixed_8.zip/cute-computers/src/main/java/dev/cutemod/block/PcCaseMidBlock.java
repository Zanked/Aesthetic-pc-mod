package dev.cutemod.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.shapes.VoxelShape;

/** The middle-sized case (a normal mid tower): works exactly like the big {@link PcCaseBlock}, only smaller (its models are the big ones squeezed by tools/make_pc_case_sizes.py). */
public class PcCaseMidBlock extends PcCaseBlock {
    public static final MapCodec<PcCaseMidBlock> CODEC = simpleCodec(PcCaseMidBlock::new);
    private static final VoxelShape[] SHAPES = shapes(0.74, 0.8, 0.82);

    public PcCaseMidBlock(BlockBehaviour.Properties props) { super(props, SHAPES); }

    @Override
    protected MapCodec<? extends net.minecraft.world.level.block.Block> codec() { return CODEC; }
}
