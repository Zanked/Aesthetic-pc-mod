package dev.cutemod.block;

import dev.cutemod.ComputerColor;
import dev.cutemod.data.LaptopLine;

/**
 * Every laptop that exists: its line (office / Neo / gaming), the name of its block ("<id>_laptop") and the computer it is
 * (the colour of the OS and of the record, see ComputerColor). A laptop is repainted with a dye only inside the Neo line.
 */
public enum LaptopModel {
    NEO_PINK("pink", LaptopLine.NEO, ComputerColor.PINK),
    NEO_BLUE("blue", LaptopLine.NEO, ComputerColor.BLUE),
    NEO_YELLOW("yellow", LaptopLine.NEO, ComputerColor.YELLOW),
    NEO_WHITE("white", LaptopLine.NEO, ComputerColor.WHITE),
    OFFICE_BLACK("office_black", LaptopLine.OFFICE, ComputerColor.PURPLE),
    OFFICE_WHITE("office_white", LaptopLine.OFFICE, ComputerColor.WHITE),
    OFFICE_SILVER("office_silver", LaptopLine.OFFICE, ComputerColor.BLUE),
    GAMING_BLACK("gaming_black", LaptopLine.GAMING, ComputerColor.PURPLE),
    GAMING_WHITE("gaming_white", LaptopLine.GAMING, ComputerColor.WHITE);

    public final String id;
    public final LaptopLine line;
    public final ComputerColor os;

    LaptopModel(String id, LaptopLine line, ComputerColor os) {
        this.id = id;
        this.line = line;
        this.os = os;
    }

    public String blockName() { return id + "_laptop"; }

    /** The Neo laptop of this colour, or null (only pink, blue, yellow and white exist). */
    public static LaptopModel neo(ComputerColor color) {
        for (LaptopModel m : values()) if (m.line == LaptopLine.NEO && m.os == color) return m;
        return null;
    }

    public static LaptopModel byId(String id) {
        for (LaptopModel m : values()) if (m.id.equals(id)) return m;
        return null;
    }
}
