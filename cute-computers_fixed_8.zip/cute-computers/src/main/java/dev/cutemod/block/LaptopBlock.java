package dev.cutemod.block;

import com.mojang.serialization.MapCodec;
import dev.cutemod.ComputerColor;
import dev.cutemod.client.ClientHooks;
import dev.cutemod.data.LaptopLine;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The laptop (office, Neo or gaming, see {@link LaptopModel}): the same OS as the computer of its colour (and the same record), but with a lid.
 * Its processor, card, board and power supply are soldered on; only the memory and the drive can be upgraded (see {@link LaptopLine}).
 * Closed: right-click opens the lid. Open: right-click opens the OS, sneak + right-click with an empty hand closes the lid.
 * The item ({@link dev.cutemod.item.LaptopItem}) opens the OS right in the hand, so a laptop can be carried around.
 */
public class LaptopBlock extends ComputerBlock {
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;
    public static final MapCodec<LaptopBlock> CODEC = simpleCodec(p -> new LaptopBlock(p, LaptopModel.NEO_PINK));

    // [line][turn]: the three lines have different bodies (the slim Neo, the thicker office one, the big but thin RGB gaming one)
    private static final VoxelShape[][] OPEN_SHAPES = new VoxelShape[LaptopLine.values().length][4];
    private static final VoxelShape[][] CLOSED_SHAPES = new VoxelShape[LaptopLine.values().length][4];
    /** What the player sees as the frame round the laptop (and clicks on): ONE plain box. The stepped shape above is only for walking into it. */
    private static final VoxelShape[][] OPEN_OUTLINE = new VoxelShape[LaptopLine.values().length][4];
    /** The lid of every model leans back by this angle (see "lid" in the laptop models). */
    private static final double LID_ANGLE = Math.toRadians(22.5);
    private static final int LID_STEPS = 10;

    /**
     * The hit box of a leaning lid: a thin slab, so it is made of a few small steps that follow it instead of one big box
     * (a big box showed up as a loose frame floating around and behind the screen when the laptop was looked at).
     * The lid turns about the x axis at (yPivot, zPivot); it is {@code length} long, from {@code dBack} to {@code dFront} thick around the pivot.
     */
    private static VoxelShape lid(double x0, double x1, double yPivot, double zPivot, double length, double dBack, double dFront, int turn) {
        double sin = Math.sin(LID_ANGLE), cos = Math.cos(LID_ANGLE);
        VoxelShape out = Shapes.empty();
        for (int i = 0; i < LID_STEPS; i++) {
            double s0 = length * i / LID_STEPS, s1 = length * (i + 1) / LID_STEPS;
            double yLo = Double.MAX_VALUE, yHi = -Double.MAX_VALUE, zLo = Double.MAX_VALUE, zHi = -Double.MAX_VALUE;
            for (double sv : new double[]{s0, s1}) for (double d : new double[]{dBack, dFront}) {
                double y = yPivot + sv * cos + d * sin, z = zPivot - sv * sin + d * cos;
                yLo = Math.min(yLo, y); yHi = Math.max(yHi, y); zLo = Math.min(zLo, z); zHi = Math.max(zHi, z);
            }
            out = Shapes.or(out, rotated(x0, yLo, zLo, x1, yHi, zHi, turn));
        }
        return out;
    }

    static {
        for (int turn = 0; turn < 4; turn++) {
            int neo = LaptopLine.NEO.ordinal(), office = LaptopLine.OFFICE.ordinal(), gaming = LaptopLine.GAMING.ordinal();
            OPEN_SHAPES[neo][turn] = Shapes.or(rotated(1.75, 0, 4.6, 14.25, 0.6, 13.3, turn), lid(1.75, 14.25, 0.6, 4.8, 8.4, -0.2, 0.2, turn));   // the slim Neo body + the tilted lid
            CLOSED_SHAPES[neo][turn] = rotated(1.75, 0, 4.6, 14.25, 1.0, 13.3, turn);
            OPEN_SHAPES[office][turn] = Shapes.or(rotated(1.25, 0, 4.4, 14.75, 1.1, 13.9, turn), lid(1.25, 14.75, 1.1, 4.7, 8.9, -0.3, 0.3, turn));
            CLOSED_SHAPES[office][turn] = rotated(1.25, 0, 4.4, 14.75, 1.8, 13.9, turn);
            OPEN_SHAPES[gaming][turn] = Shapes.or(rotated(1.0, 0, 3.8, 15.0, 0.95, 14.2, turn), lid(1.0, 15.0, 0.62, 4.36, 8.68, -0.16, 0.16, turn));   // the thin gaming body + its tilted lid
            CLOSED_SHAPES[gaming][turn] = rotated(1.0, 0, 3.8, 15.0, 1.0, 14.2, turn);
            for (int line = 0; line < OPEN_OUTLINE.length; line++) OPEN_OUTLINE[line][turn] = Shapes.create(OPEN_SHAPES[line][turn].bounds());
        }
    }

    private final LaptopModel model;

    public LaptopBlock(BlockBehaviour.Properties props, LaptopModel model) {
        super(props, model.os);
        this.model = model;
        registerDefaultState(defaultBlockState().setValue(OPEN, true));
    }

    public LaptopModel model() { return model; }

    public LaptopLine line() { return model.line; }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(OPEN);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        BlockState s = super.getStateForPlacement(ctx);
        return s == null ? null : s.setValue(OPEN, true);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        int turns = turnsOf(state.getValue(FACING));
        int line = model.line.ordinal();
        return state.getValue(OPEN) ? OPEN_OUTLINE[line][turns] : CLOSED_SHAPES[line][turns];
    }

    /** Walking into it: the body and the leaning lid made of small steps, so nobody bumps into the empty air behind the screen. */
    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        int turns = turnsOf(state.getValue(FACING));
        int line = model.line.ordinal();
        return state.getValue(OPEN) ? OPEN_SHAPES[line][turns] : CLOSED_SHAPES[line][turns];
    }

    private static void setOpen(Level level, BlockPos pos, BlockState state, boolean open, Player player) {
        level.setBlock(pos, state.setValue(OPEN, open), 3);
        level.playSound(null, pos, open ? SoundEvents.IRON_TRAPDOOR_OPEN : SoundEvents.IRON_TRAPDOOR_CLOSE,
                SoundSource.BLOCKS, 0.7F, open ? 1.5F : 1.3F);
        level.gameEvent(player, open ? GameEvent.BLOCK_OPEN : GameEvent.BLOCK_CLOSE, pos);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!state.getValue(OPEN)) {                                   // closed: lift the lid
            if (!level.isClientSide) setOpen(level, pos, state, true, player);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (player.isShiftKeyDown()) {                                 // open + sneak: close it
            if (!level.isClientSide) setOpen(level, pos, state, false, player);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (level.isClientSide) ClientHooks.openComputer(getColor(), pos, true);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** A dye paints the laptop in the colour of the dye (direction, lid and record stay). */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player,
                                              InteractionHand hand, BlockHitResult hit) {
        if (stack.getItem() instanceof dev.cutemod.item.PcPartItem part) {        // only a memory stick or a drive goes inside; the rest is soldered on
            if (!level.isClientSide && player instanceof net.minecraft.server.level.ServerPlayer sp) {
                if (!LaptopLine.upgradable(part.kind())) dev.cutemod.item.PcPartItem.laptopFixed(sp);
                else if (level.getBlockEntity(pos) instanceof ComputerBlockEntity be) part.install(sp, stack, be);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        if (stack.getItem() instanceof DyeItem dye) {
            ComputerColor target = ComputerColor.fromDye(dye.getDyeColor());
            LaptopModel painted_ = model.line == LaptopLine.NEO ? LaptopModel.neo(target) : null;     // only the slim Neo is repainted (pink, blue, yellow, white)
            if (painted_ != null && painted_ != model) {
                if (!level.isClientSide) {
                    BlockEntity old = level.getBlockEntity(pos);
                    CompoundTag data = old == null ? null : old.saveWithoutMetadata(level.registryAccess());
                    BlockState painted = ModBlocks.getLaptop(painted_).get().defaultBlockState()
                            .setValue(FACING, state.getValue(FACING)).setValue(OPEN, state.getValue(OPEN));
                    level.setBlock(pos, painted, 3);
                    BlockEntity fresh = level.getBlockEntity(pos);
                    if (data != null && fresh != null) {
                        fresh.loadWithComponents(data, level.registryAccess());
                        fresh.setChanged();
                        level.sendBlockUpdated(pos, painted, painted, 3);
                    }
                    if (!player.getAbilities().instabuild) stack.shrink(1);
                    level.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 1F, 1F);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }
}
