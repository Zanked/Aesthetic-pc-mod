package dev.cutemod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.EnumProperty;

/**
 * The colours of the PC case and of the monitor (the keyboard and the mouse that are connected to a monitor take its colour).
 * The block state property {@link #PROPERTY} picks the textures (see tools/make_pc_colors.py, which paints them: keep both lists in step).
 * A dye in the hand paints a case or a monitor ({@link #recolor}); the coloured items in the creative tab place a block of that colour.
 */
public enum PcColor implements StringRepresentable {
    WHITE("white"), PINK("pink"), BLUE("blue"), MINT("mint"), PURPLE("purple"), YELLOW("yellow"), RED("red"), BLACK("black");

    public static final EnumProperty<PcColor> PROPERTY = EnumProperty.create("color", PcColor.class);

    public final String id;

    PcColor(String id) { this.id = id; }

    @Override
    public String getSerializedName() { return id; }

    /** The colour a dye gives (null: that dye does nothing). */
    public static PcColor fromDye(DyeColor dye) {
        return switch (dye) {
            case WHITE, LIGHT_GRAY -> WHITE;
            case PINK -> PINK;
            case BLUE, LIGHT_BLUE, CYAN -> BLUE;
            case GREEN, LIME -> MINT;
            case PURPLE, MAGENTA -> PURPLE;
            case YELLOW, ORANGE -> YELLOW;
            case RED -> RED;
            case BLACK, GRAY -> BLACK;
            default -> null;
        };
    }

    /**
     * Right-click with a dye: the block gets the colour of the dye (one dye is used up, except in creative mode).
     * Returns null when the item is not a dye that changes anything, so the caller goes on with its own use.
     */
    public static ItemInteractionResult recolor(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player) {
        if (!(stack.getItem() instanceof DyeItem dye)) return null;
        PcColor target = fromDye(dye.getDyeColor());
        if (target == null || target == state.getValue(PROPERTY)) return null;
        if (!level.isClientSide) {
            level.setBlock(pos, state.setValue(PROPERTY, target), 3);
            level.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }
}
