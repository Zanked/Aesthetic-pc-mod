package dev.cutemod.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** The keyboard and the mouse: small blocks that go on the table in front of a monitor (see {@link PcLink}). They have no use of their own. */
public class PcPeripheralBlock extends Block {
    public enum Kind { KEYBOARD, MOUSE }

    public static final MapCodec<PcPeripheralBlock> CODEC = simpleCodec(p -> new PcPeripheralBlock(p, Kind.KEYBOARD));
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    private static final VoxelShape[][] SHAPES = new VoxelShape[Kind.values().length][4];
    static {
        for (int turn = 0; turn < 4; turn++) {
            SHAPES[Kind.KEYBOARD.ordinal()][turn] = ComputerBlock.rotated(1.5, 0, 5.5, 14.5, 1.2, 10.5, turn);
            SHAPES[Kind.MOUSE.ordinal()][turn] = ComputerBlock.rotated(6.6, 0, 5.6, 9.4, 1.6, 9.8, turn);
        }
    }

    private final Kind kind;

    public PcPeripheralBlock(BlockBehaviour.Properties props, Kind kind) {
        super(props);
        this.kind = kind;
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.SOUTH));
    }

    public Kind kind() { return kind; }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) { builder.add(FACING); }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rot) { return state.setValue(FACING, rot.rotate(state.getValue(FACING))); }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) { return state.rotate(mirror.getRotation(state.getValue(FACING))); }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPES[kind.ordinal()][ComputerBlock.turnsOf(state.getValue(FACING))];
    }
}
