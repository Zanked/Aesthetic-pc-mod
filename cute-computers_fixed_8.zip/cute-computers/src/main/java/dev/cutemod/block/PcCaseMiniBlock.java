package dev.cutemod.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.shapes.VoxelShape;

/** The compact case (a small cube with a carry handle): works exactly like the big {@link PcCaseBlock}; its own models are drawn by tools/make_pc_case_mini.py. */
public class PcCaseMiniBlock extends PcCaseBlock {
    public static final MapCodec<PcCaseMiniBlock> CODEC = simpleCodec(PcCaseMiniBlock::new);
    /** The same box as SHAPE in tools/make_pc_case_mini.py: the shell, the handle on top and the glass knobs in front. */
    private static final VoxelShape[] SHAPES = turnedBox(3.4, 0.0, 4.8, 12.6, 13.7, 11.7);

    public PcCaseMiniBlock(BlockBehaviour.Properties props) { super(props, SHAPES); }

    @Override
    protected MapCodec<? extends net.minecraft.world.level.block.Block> codec() { return CODEC; }
}
