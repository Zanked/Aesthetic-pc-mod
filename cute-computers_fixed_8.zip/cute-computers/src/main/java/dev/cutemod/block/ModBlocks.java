package dev.cutemod.block;

import dev.cutemod.ComputerColor;
import dev.cutemod.CuteMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.Map;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(CuteMod.MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CuteMod.MOD_ID);

    private static final Map<ComputerColor, DeferredBlock<ComputerBlock>> COMPUTERS = new EnumMap<>(ComputerColor.class);
    private static final Map<ComputerColor, DeferredItem<BlockItem>> COMPUTER_ITEMS = new EnumMap<>(ComputerColor.class);

    static {
        for (ComputerColor color : ComputerColor.values()) {
            DeferredBlock<ComputerBlock> block = BLOCKS.registerBlock(
                    color.blockName(),
                    props -> new ComputerBlock(props, color),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_PINK)
                            .strength(1.0F)
                            .sound(SoundType.METAL)
                            .noOcclusion());
            COMPUTERS.put(color, block);
            COMPUTER_ITEMS.put(color, ITEMS.registerSimpleBlockItem(block));
        }
    }

    private static final Map<LaptopModel, DeferredBlock<LaptopBlock>> LAPTOPS = new EnumMap<>(LaptopModel.class);

    static {
        for (LaptopModel model : LaptopModel.values()) {
            String name = model.blockName();
            DeferredBlock<LaptopBlock> block = BLOCKS.registerBlock(
                    name,
                    props -> new LaptopBlock(props, model),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_PINK)
                            .strength(1.0F)
                            .sound(SoundType.METAL)
                            .noOcclusion());
            LAPTOPS.put(model, block);
            ITEMS.registerItem(name, props -> new dev.cutemod.item.LaptopItem(block.get(), props), new net.minecraft.world.item.Item.Properties().stacksTo(1));
        }
    }

    private static final Map<Integer, DeferredBlock<RouterBlock>> ROUTERS = new java.util.LinkedHashMap<>();
    private static final Map<Integer, DeferredItem<BlockItem>> ROUTER_ITEMS = new java.util.LinkedHashMap<>();

    static {
        for (int lv = dev.cutemod.data.WifiNet.FIRST; lv <= dev.cutemod.data.WifiNet.LAST; lv++) {
            final int level = lv;
            DeferredBlock<RouterBlock> block = BLOCKS.registerBlock(
                    dev.cutemod.data.WifiNet.id(lv),
                    props -> new RouterBlock(props, level),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_PINK)
                            .strength(0.8F)
                            .sound(SoundType.METAL)
                            .noOcclusion());
            ROUTERS.put(lv, block);
            ROUTER_ITEMS.put(lv, ITEMS.registerSimpleBlockItem(block));
        }
    }

    /** The Wi-Fi router block of this level (1..5). */
    public static DeferredBlock<RouterBlock> getRouter(int level) { return ROUTERS.get(dev.cutemod.data.WifiNet.level(level)); }

    public static Iterable<DeferredBlock<RouterBlock>> allRouters() { return ROUTERS.values(); }

    /** One router item of this level (1..5). */
    public static net.minecraft.world.item.ItemStack routerStack(int level) {
        DeferredItem<BlockItem> it = ROUTER_ITEMS.get(level);
        return it == null ? net.minecraft.world.item.ItemStack.EMPTY : new net.minecraft.world.item.ItemStack(it.get());
    }

    // ---------- the build-it-yourself PC: a case (the parts go inside), a monitor, a keyboard and a mouse ----------
    // The case and the monitor have a colour (the block state property "color", see PcColor). Each colour has its own item (own picture,
    // own name, placed with its colour set). IMPORTANT: the coloured items are registered BEFORE the white one of the same block, because the
    // last item registered for a block is the one that Block.asItem() returns: that must be the white item.

    /** The normal PC case: a white glass mid tower. Empty when crafted: the parts are put in by hand (see {@link PcCaseBlock}). It glows a little when switched on. */
    public static final DeferredBlock<PcCaseMidBlock> PC_CASE_MID = BLOCKS.registerBlock("pc_case_mid", PcCaseMidBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(1.5F).sound(SoundType.METAL).noOcclusion()
                    .lightLevel(s -> s.getValue(PcCaseBlock.LIT) ? 6 : 0));

    /** The compact case: a slim little box (a mini-ITX style case). */
    public static final DeferredBlock<PcCaseMiniBlock> PC_CASE_MINI = BLOCKS.registerBlock("pc_case_mini", PcCaseMiniBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(1.5F).sound(SoundType.METAL).noOcclusion()
                    .lightLevel(s -> s.getValue(PcCaseBlock.LIT) ? 5 : 0));

    /** The monitor: its screen lights up when a full desk is around it (see {@link PcLink}). The keyboard and the mouse are connected to it by right-click. */
    public static final DeferredBlock<PcMonitorBlock> PC_MONITOR = BLOCKS.registerBlock("pc_monitor", PcMonitorBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(0.8F).sound(SoundType.METAL).noOcclusion()
                    .lightLevel(s -> s.getValue(PcMonitorBlock.ON) ? 5 : 0));

    /** The coloured cases and monitors (everything but white), in the order of the creative tab. */
    public static final java.util.List<java.util.function.Supplier<? extends net.minecraft.world.item.Item>> PC_COLORED_ITEMS = new java.util.ArrayList<>();

    private static void coloredItems(String name, DeferredBlock<? extends net.minecraft.world.level.block.Block> block) {
        for (PcColor color : PcColor.values()) {
            if (color == PcColor.WHITE) continue;
            String itemName = name + "_" + color.id;
            var item = ITEMS.registerItem(itemName,
                    props -> new dev.cutemod.item.PcColoredItem(block.get(), props, color, "item." + CuteMod.MOD_ID + "." + itemName),
                    new net.minecraft.world.item.Item.Properties());
            PC_COLORED_ITEMS.add(item);
        }
    }

    static {
        coloredItems("pc_case_mid", PC_CASE_MID);
        coloredItems("pc_case_mini", PC_CASE_MINI);
        coloredItems("pc_monitor", PC_MONITOR);
    }

    public static final DeferredItem<BlockItem> PC_CASE_MID_ITEM = ITEMS.registerSimpleBlockItem(PC_CASE_MID);
    public static final DeferredItem<BlockItem> PC_CASE_MINI_ITEM = ITEMS.registerSimpleBlockItem(PC_CASE_MINI);
    public static final DeferredItem<BlockItem> PC_MONITOR_ITEM = ITEMS.registerSimpleBlockItem(PC_MONITOR);

    // The keyboard and the mouse blocks are only kept for the desks of older worlds (they still work there). They have no item that places them any more:
    // the items below are connected to a monitor with a right-click (see PcMonitorBlock#attach).
    public static final DeferredBlock<PcPeripheralBlock> PC_KEYBOARD = BLOCKS.registerBlock("pc_keyboard",
            props -> new PcPeripheralBlock(props, PcPeripheralBlock.Kind.KEYBOARD),
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(0.3F).sound(SoundType.METAL).noOcclusion());
    public static final DeferredItem<dev.cutemod.item.PcPeripheralItem> PC_KEYBOARD_ITEM = ITEMS.registerItem("pc_keyboard",
            props -> new dev.cutemod.item.PcPeripheralItem(props, PcPeripheralBlock.Kind.KEYBOARD, PcPeriphStyle.WHITE), new net.minecraft.world.item.Item.Properties());

    public static final DeferredBlock<PcPeripheralBlock> PC_MOUSE = BLOCKS.registerBlock("pc_mouse",
            props -> new PcPeripheralBlock(props, PcPeripheralBlock.Kind.MOUSE),
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(0.3F).sound(SoundType.METAL).noOcclusion());
    public static final DeferredItem<dev.cutemod.item.PcPeripheralItem> PC_MOUSE_ITEM = ITEMS.registerItem("pc_mouse",
            props -> new dev.cutemod.item.PcPeripheralItem(props, PcPeripheralBlock.Kind.MOUSE, PcPeriphStyle.WHITE), new net.minecraft.world.item.Item.Properties());

    /**
     * Every look of the keyboard and of the mouse has its own item (own picture, own name): the plain colours, the black and the white RGB
     * ones and the Sakura Edition. The white one is the old "pc_keyboard" / "pc_mouse" item (so old recipes and old items still work).
     * The monitor remembers which look is connected to it (see PcMonitorBlock#attach), whatever its own colour is.
     */
    public static final java.util.Map<PcPeriphStyle, DeferredItem<dev.cutemod.item.PcPeripheralItem>> KEYBOARD_ITEMS = new java.util.EnumMap<>(PcPeriphStyle.class);
    public static final java.util.Map<PcPeriphStyle, DeferredItem<dev.cutemod.item.PcPeripheralItem>> MOUSE_ITEMS = new java.util.EnumMap<>(PcPeriphStyle.class);

    static {
        KEYBOARD_ITEMS.put(PcPeriphStyle.WHITE, PC_KEYBOARD_ITEM);
        MOUSE_ITEMS.put(PcPeriphStyle.WHITE, PC_MOUSE_ITEM);
        for (PcPeriphStyle style : PcPeriphStyle.values()) {
            if (style == PcPeriphStyle.WHITE) continue;
            KEYBOARD_ITEMS.put(style, ITEMS.registerItem("pc_keyboard_" + style.id,
                    props -> new dev.cutemod.item.PcPeripheralItem(props, PcPeripheralBlock.Kind.KEYBOARD, style), new net.minecraft.world.item.Item.Properties()));
            MOUSE_ITEMS.put(style, ITEMS.registerItem("pc_mouse_" + style.id,
                    props -> new dev.cutemod.item.PcPeripheralItem(props, PcPeripheralBlock.Kind.MOUSE, style), new net.minecraft.world.item.Item.Properties()));
        }
    }

    public static net.minecraft.world.item.Item keyboardItem(PcPeriphStyle style) { return KEYBOARD_ITEMS.get(style).get(); }

    public static net.minecraft.world.item.Item mouseItem(PcPeriphStyle style) { return MOUSE_ITEMS.get(style).get(); }

    public static DeferredBlock<LaptopBlock> getLaptop(LaptopModel model) {
        return LAPTOPS.get(model);
    }

    public static Iterable<DeferredBlock<LaptopBlock>> allLaptops() {
        return LAPTOPS.values();
    }

    public static DeferredBlock<ComputerBlock> get(ComputerColor color) {
        return COMPUTERS.get(color);
    }

    public static Iterable<DeferredBlock<ComputerBlock>> all() {
        return COMPUTERS.values();
    }

    private ModBlocks() {}
}
