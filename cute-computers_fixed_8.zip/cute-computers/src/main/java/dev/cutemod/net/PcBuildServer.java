package dev.cutemod.net;

import dev.cutemod.block.PcCaseBlockEntity;
import dev.cutemod.block.PcColor;
import dev.cutemod.block.PcLink;
import dev.cutemod.item.PcCablesItem;
import dev.cutemod.item.PcPartItem;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/**
 * The server side of the PC build screen. The screen only asks ("put the part from this inventory slot in", "take this out",
 * "press the power button"); everything is checked and done here with the same rules as a right-click on the case,
 * and the new state of the case is sent back, so the screen can never show something that is not true.
 */
public final class PcBuildServer {
    private PcBuildServer() {}

    /** The player right-clicked a case with an empty hand: open the screen. */
    public static void open(ServerPlayer sp, PcCaseBlockEntity be) {
        send(sp, be, true, PcBuildStatePayload.EV_NONE, 0);
    }

    public static void handle(ServerPlayer sp, PcBuildActionPayload p) {
        Level level = sp.level();
        BlockPos pos = p.pos();
        if (!level.isLoaded(pos)) return;
        if (sp.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 64.0) return;        // within 8 blocks of the case
        if (!(level.getBlockEntity(pos) instanceof PcCaseBlockEntity be)) return;

        int event = PcBuildStatePayload.EV_NONE, detail = 0;
        switch (p.action()) {
            case PcBuildActionPayload.ACT_INSTALL -> {
                Inventory inv = sp.getInventory();
                int idx = p.arg();
                ItemStack stack = idx >= 0 && idx < inv.getContainerSize() ? inv.getItem(idx) : ItemStack.EMPTY;
                boolean known = true;
                if (stack.getItem() instanceof PcCablesItem wires) wires.installInCase(sp, stack, be);
                else if (stack.getItem() instanceof dev.cutemod.item.PcPasteItem paste) paste.installInCase(sp, stack, be);
                else if (stack.getItem() instanceof dev.cutemod.item.PcCoolerItem cooler) cooler.installInCase(sp, stack, be);
                else if (stack.getItem() instanceof PcPartItem part) part.installInCase(sp, stack, be);
                else known = false;
                PcCaseBlockEntity.Result r = known ? be.lastResult() : PcCaseBlockEntity.Result.SAME;
                if (r == PcCaseBlockEntity.Result.OK) event = PcBuildStatePayload.EV_INSTALLED;
                else { event = PcBuildStatePayload.EV_ERROR; detail = r.ordinal(); }
            }
            case PcBuildActionPayload.ACT_REMOVE -> {
                ItemStack[] out = {ItemStack.EMPTY};
                PcCaseBlockEntity.Result r = be.remove(p.arg(), out);
                if (r == PcCaseBlockEntity.Result.OK && !out[0].isEmpty()) {
                    if (!sp.getInventory().add(out[0])) sp.drop(out[0], false);
                    level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 0.8F, 0.8F);
                    event = PcBuildStatePayload.EV_REMOVED;
                    detail = p.arg();
                } else {
                    event = PcBuildStatePayload.EV_ERROR;
                    detail = r.ordinal();
                }
            }
            case PcBuildActionPayload.ACT_POWER -> {
                if (be.isOn()) {
                    be.setOn(false);
                    level.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 0.7F, 1.3F);
                    event = PcBuildStatePayload.EV_OFF;
                } else if (!be.isComplete()) {
                    level.playSound(null, pos, SoundEvents.VILLAGER_NO, SoundSource.BLOCKS, 0.6F, 1.3F);
                    event = PcBuildStatePayload.EV_INCOMPLETE;
                } else if (be.thermalFault() != 0) {                         // thermal protection: too hot to start
                    level.playSound(null, pos, SoundEvents.VILLAGER_NO, SoundSource.BLOCKS, 0.8F, 0.8F);
                    level.playSound(null, pos, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.7F, 1.0F);
                    event = PcBuildStatePayload.EV_THERMAL;
                    detail = be.thermalFault();
                } else {
                    boolean fresh = be.needsPost();                             // a build that never started: show the start-up check
                    be.setOn(true);
                    level.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.BLOCKS, 0.7F, 1.5F);
                    level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 0.8F, 1.6F);
                    if (fresh) be.markPosted();
                    event = fresh ? PcBuildStatePayload.EV_POST : PcBuildStatePayload.EV_ON;
                }
            }
            case PcBuildActionPayload.ACT_TIDY -> {
                if (be.setTidy(p.arg())) {
                    level.playSound(null, pos, SoundEvents.WOOL_PLACE, SoundSource.BLOCKS, 0.8F, 1.4F);
                    level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 0.6F, 1.7F);
                }
            }
            case PcBuildActionPayload.ACT_RGB -> be.setRgb(p.arg() / 8, p.arg() % 8);
            default -> { }
        }
        PcLink.refreshMonitors(level, pos);
        send(sp, be, false, event, detail);
    }

    private static void send(ServerPlayer sp, PcCaseBlockEntity be, boolean open, int event, int detail) {
        BlockState state = be.getBlockState();
        int color = state.hasProperty(PcColor.PROPERTY) ? state.getValue(PcColor.PROPERTY).ordinal() : 0;
        List<Integer> st = new ArrayList<>();
        for (int v : be.snapshot()) st.add(v);
        PacketDistributor.sendToPlayer(sp, new PcBuildStatePayload(be.getBlockPos(), open, event, detail, color, st));
    }
}
