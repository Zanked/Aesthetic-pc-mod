"""
The build-it-yourself PC: the case (a white glass tower with three glowing fans), the monitor, the keyboard and the mouse.

  python tools/make_pc_case.py [--preview]

writes
  textures/block/pc_case_atlas.png                    one atlas for the whole case (every part inside is a small model of its own)
  models/block/pc_case_<group>.json                   body, glass, board, cpu, ram0..3, gpu1..4, disk, net, psu, cable, glow_*
  models/block/pc_case_item.json                      the empty case, for the inventory
  blockstates/pc_case.json                            a MULTIPART blockstate: a part model is drawn when its property is set,
                                                       so the player watches the PC being assembled behind the glass
  textures/block/pc_monitor_{on,off}.png, pc_keyboard.png, pc_mouse.png + their models, blockstates and item models
  models/item/pc_{case,monitor,keyboard,mouse}.json
--preview also writes /tmp/pc_case_preview.png (the case in stages, only for looking at the result).

The look is the one of the other parts: pastel pixel art with a dark purple outline (see make_pc_parts.py, which this reuses).
Coordinates: the front (the glass) is SOUTH (+z); the blockstate turns it with "y" for the other directions.
"""
import os, sys, json, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_pc_parts as P
from PIL import Image, ImageDraw

RES = P.RES
ATLAS = 1024
P.ATLAS = ATLAS                      # make_pc_parts reads these module globals while it draws
P.SCALE = 1
P.D = 12                             # texels per model unit: the case is looked at from close by

# ------------------------------------------------------------------ palette
WHT, WHT_D, WHT_L = (248, 246, 253), (222, 218, 238), (255, 255, 255)
LIL, LIL_D = (200, 188, 232), (150, 132, 196)
DARK, DARK_L = (50, 44, 74), (84, 76, 112)
OUT = P.OUT
PURP, PINK, CYAN, MINT, GOLD = (170, 118, 250), (255, 150, 196), (110, 226, 240), (130, 226, 180), P.GOLD
GPU_ACC = {1: (170, 178, 200), 2: (120, 214, 140), 3: (248, 128, 176), 4: (64, 212, 220)}
GPU_TAG = {1: 'GT 710', 2: '5500', 3: 'RTX 3060', 4: 'RTX 4080'}
GPU_LEN = {1: 5.6, 2: 6.4, 3: 7.2, 4: 7.8}
GPU_THK = {1: 1.2, 2: 1.6, 3: 2.0, 4: 2.4}

mix, lighter, darker = P.mix, P.lighter, P.darker
panel, compose, text = P.panel, P.compose, P.text

# ------------------------------------------------------------------ painters
def rgba(c, a=255): return tuple(c[:3]) + (a,)

def glass(w_alpha=34):
    """Clear tempered glass: almost see-through, a thin bright edge and two soft diagonal reflections."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        d.rectangle([0, 0, w - 1, h - 1], fill=(206, 218, 250, w_alpha))
        d.rectangle([0, 0, w - 1, h - 1], outline=(236, 240, 255, 150))
        d.rectangle([1, 1, w - 2, h - 2], outline=(255, 255, 255, 56))
        for off, wd, a in ((.16, .07, 54), (.30, .02, 46), (.56, .10, 34), (.70, .02, 40)):
            for t in range(h):
                x0 = w * off + t * .55
                d.line([(x0, h - 1 - t), (x0 + w * wd, h - 1 - t)], fill=(255, 255, 255, a))
    return p

def mesh(c=WHT, hole=(196, 190, 218), pitch=7, r=1.6, border=5):
    """A perforated white panel (staggered round holes), like the back and the top of the real case."""
    def p(img, w, h):
        panel(c)(img, w, h)
        d = ImageDraw.Draw(img)
        row = 0
        for y in range(border + 3, h - border - 2, pitch):
            off = pitch // 2 if row % 2 else 0
            for x in range(border + 3 + off, w - border - 2, pitch):
                d.ellipse([x - r, y - r, x + r, y + r], fill=rgba(hole))
                d.point((int(x - r + 1), int(y - r + 1)), fill=rgba(darker(hole, .25)))
            row += 1
    return p

def side_panel(c=WHT):
    """The solid right side: a few long vent slots near the top, a pastel stripe at the bottom."""
    def p(img, w, h):
        panel(c)(img, w, h)
        d = ImageDraw.Draw(img)
        for i in range(7):
            y = 12 + i * 9
            d.rounded_rectangle([w // 2 - 28, y, w // 2 + 28, y + 3], radius=1, fill=rgba(mix(WHT_D, DARK, .15)))
        d.rectangle([6, h - 14, w - 7, h - 11], fill=rgba(LIL))
        d.rectangle([6, h - 10, w - 7, h - 9], fill=rgba(PINK))
    return p

def tray(c=WHT):
    """The motherboard tray seen behind the parts: cable cut-outs, a big round hole behind the processor, screw dots."""
    def p(img, w, h):
        panel(c)(img, w, h)
        d = ImageDraw.Draw(img)
        sh = mix(WHT_D, DARK, .25)
        u = P.D
        d.ellipse([int(2.8 * u), int(3.0 * u), int(6.0 * u), int(6.2 * u)], fill=rgba(sh), outline=rgba(LIL_D))      # behind the CPU socket
        for (x0, y0, x1, y1) in ((.5, 1.0, 1.1, 4.0), (.5, 5.0, 1.1, 8.0), (9.3, 1.0, 9.9, 5.0), (9.3, 6.0, 9.9, 9.0)):   # cable cut-outs
            d.rounded_rectangle([int(x0 * u), int(y0 * u), int(x1 * u), int(y1 * u)], radius=3, fill=rgba(DARK_L))
        for (x, y) in ((1.7, .8), (9.0, .8), (1.7, 9.2), (9.0, 9.2), (5.6, 9.2), (5.6, .8)):
            d.ellipse([int(x * u) - 2, int(y * u) - 2, int(x * u) + 2, int(y * u) + 2], fill=rgba(WHT_D), outline=rgba(LIL_D))
    return p

def shroud_top(c=WHT):
    """The plate between the two chambers: three long slots for the cables."""
    def p(img, w, h):
        panel(c)(img, w, h)
        d = ImageDraw.Draw(img)
        for i, x0 in enumerate((.12, .42, .72)):
            d.rounded_rectangle([int(w * x0), int(h * .30), int(w * (x0 + .16)), int(h * .46)], radius=2, fill=rgba(DARK_L))
        text('CUTE', int(w * .5), int(h * .76), LIL_D, 9)(img, w, h)
    return p

def led_off(led): return mix(led, WHT, .45)

def fan_at(cx, cy, r, led, lit_only=False, blades=9):
    """One RGB fan: a dark round opening, a glowing ring, curved pastel blades and a hub with a shine.
    lit_only draws just the glowing part (a bright, wider ring with a soft halo) on a see-through face: the overlay of a PC that is on."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        if lit_only:
            for k, a in ((4, 36), (3, 70), (2, 120)):                          # the soft halo outside the ring
                d.ellipse([cx - r - k, cy - r - k, cx + r + k, cy + r + k], outline=rgba(led, a), width=1)
            d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=rgba(lighter(led, .35)), width=2)
            d.ellipse([cx - r + 2, cy - r + 2, cx + r - 2, cy + r - 2], outline=rgba(led, 150), width=1)
            d.ellipse([cx - 2, cy - 2, cx + 2, cy + 2], fill=rgba(lighter(led, .6)))
            return
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=rgba(DARK))
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=rgba(led_off(led)), width=2)
        rh = max(2, r // 4)
        for i in range(blades):
            a0 = i * 2 * math.pi / blades
            for t in range(rh, r - 3):
                a = a0 + (t - rh) * 0.045
                x, y = cx + math.cos(a) * t, cy + math.sin(a) * t
                d.rectangle([x - 1, y - 1, x + 1, y + 1], fill=rgba(mix(WHT, led, .12 + .1 * (t - rh) / r)))
        d.ellipse([cx - rh - 1, cy - rh - 1, cx + rh + 1, cy + rh + 1], fill=rgba(WHT), outline=rgba(LIL_D))
        d.point((cx - 1, cy - 1), fill=rgba(WHT_L))
    return p

def fan_column(n, cell, led, lit_only=False):
    """n fans stacked in a column; cell = the height of one fan in pixels."""
    def p(img, w, h):
        if not lit_only:
            panel(WHT)(img, w, h)
        for i in range(n):
            cy = int(cell * (i + .5))
            if not lit_only:
                d = ImageDraw.Draw(img)
                d.rectangle([2, i * cell + 1, w - 3, (i + 1) * cell - 2], outline=rgba(mix(WHT_D, DARK, .1)))
            fan_at(w // 2, cy, int(min(w, cell) * .40), led, lit_only)(img, w, h)
    return p

def io_panel(lit_only=False):
    """The front I/O: two USB-A, one USB-C, an audio jack and the round power button."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        if lit_only:
            bx, by = int(w * .86), h // 2
            d.ellipse([bx - 6, by - 6, bx + 6, by + 6], outline=rgba(CYAN, 90))
            d.ellipse([bx - 4, by - 4, bx + 4, by + 4], outline=rgba(lighter(CYAN, .4)), width=2)
            return
        panel(WHT)(img, w, h)
        for i, x in enumerate((int(w * .08), int(w * .24))):
            d.rectangle([x, h // 2 - 3, x + 9, h // 2 + 3], fill=rgba(DARK), outline=rgba(LIL_D))
            d.rectangle([x + 1, h // 2 - 1, x + 8, h // 2], fill=rgba((90, 150, 240)))
        x = int(w * .44); d.rounded_rectangle([x, h // 2 - 2, x + 8, h // 2 + 2], radius=2, fill=rgba(DARK), outline=rgba(LIL_D))
        x = int(w * .60); d.ellipse([x, h // 2 - 3, x + 6, h // 2 + 3], fill=rgba(DARK), outline=rgba(LIL_D))
        bx, by = int(w * .86), h // 2
        d.ellipse([bx - 5, by - 5, bx + 5, by + 5], fill=rgba(WHT_D), outline=rgba(LIL_D))
        d.ellipse([bx - 3, by - 3, bx + 3, by + 3], outline=rgba(led_off(CYAN)), width=1)
    return p

def lip_front():
    """The bottom front bar: the name of the case, small and quiet."""
    def p(img, w, h):
        panel(WHT)(img, w, h)
        text('C U T E   F L O W', int(w * .30), h // 2, LIL_D, 9)(img, w, h)
        d = ImageDraw.Draw(img)
        d.line([(4, h - 3), (w - 5, h - 3)], fill=rgba(LIL))
    return p

def lip_glow():
    def p(img, w, h):
        text('C U T E   F L O W', int(w * .30), h // 2, lighter(PURP, .4), 9)(img, w, h)
    return p

def pcb_face(acc=(236, 232, 250)):
    """The front of the motherboard: a pale PCB with traces, capacitors, a name and a little heart."""
    def p(img, w, h):
        panel(acc, True, False)(img, w, h)
        d = ImageDraw.Draw(img)
        tr = mix(acc, LIL_D, .35)
        u = P.D
        for y in (int(.9 * u), int(1.3 * u), int(7.6 * u), int(8.0 * u)):
            d.line([(int(.5 * u), y), (int(7.5 * u), y)], fill=rgba(tr))
        for x in (int(.6 * u), int(7.4 * u)):
            d.line([(x, int(.4 * u)), (x, int(9.2 * u))], fill=rgba(tr))
        for i in range(6):                                                          # capacitors in a row (gold tops)
            x = int((3.2 + i * .55) * u); y = int(4.4 * u)
            d.ellipse([x - 3, y - 3, x + 3, y + 3], fill=rgba(P.GOLD_D), outline=rgba(OUT))
            d.ellipse([x - 1, y - 1, x + 1, y + 1], fill=rgba(P.GOLD_L))
        for (x, y) in ((.5, .5), (7.5, .5), (.5, 9.1), (7.5, 9.1), (4.0, 9.1)):    # screw holes
            d.ellipse([int(x * u) - 2, int(y * u) - 2, int(x * u) + 2, int(y * u) + 2], fill=rgba(WHT), outline=rgba(LIL_D))
        text('CUTE', int(5.4 * u), int(6.6 * u), LIL_D, 10)(img, w, h)
        P.heart(int(2.0 * u), int(6.4 * u), 1, PINK)(img, w, h)
    return p

def socket_face():
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        d.rectangle([0, 0, w - 1, h - 1], fill=rgba(DARK), outline=rgba(P.METAL_D))
        d.rectangle([3, 3, w - 4, h - 4], outline=rgba(GOLD))
        P.dots(P.GOLD_L, 4, 6)(img, w, h)
        d.polygon([(3, 3), (9, 3), (3, 9)], fill=rgba(GOLD))
    return p

def slot_face(c=DARK):
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        d.rectangle([0, 0, w - 1, h - 1], fill=rgba(c))
        d.line([(0, 0), (w, 0)], fill=rgba(DARK_L))
    return p

def fins(c=P.METAL, n=7, vertical=True):
    def p(img, w, h):
        panel(c, True, False)(img, w, h)
        P.stripes(darker(c, .32), n, vertical)(img, w, h)
    return p

def rgb_bar(vertical=True, lit=False, alpha=255):
    """A strip of light: pink, violet and cyan melting into each other (dim when the PC is off)."""
    stops = [PINK, PURP, CYAN, MINT]
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        n = h if vertical else w
        for i in range(n):
            t = i / max(1, n - 1) * (len(stops) - 1)
            k = min(int(t), len(stops) - 2)
            c = mix(stops[k], stops[k + 1], t - k)
            c = lighter(c, .25) if lit else led_off(c)
            if vertical: d.line([(0, i), (w, i)], fill=rgba(c, alpha))
            else: d.line([(i, 0), (i, h)], fill=rgba(c, alpha))
    return p

def dimm_side(acc=(226, 218, 246)):
    def p(img, w, h):
        panel(acc, True, False)(img, w, h)
        d = ImageDraw.Draw(img)
        d.rectangle([2, 2, w - 3, int(h * .30)], fill=rgba(P.METAL_D))
        for i in range(3):
            P.chip(2, int(h * (.40 + i * .18)), w - 4, max(3, int(h * .12)), DARK, False)(img, w, h)
    return p

def gpu_front(t, lit=False):
    acc = GPU_ACC[t]
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        if lit:
            bar = Image.new('RGBA', (max(1, w - 10), max(2, int(h * .22))), (0, 0, 0, 0))
            rgb_bar(False, True)(bar, bar.size[0], bar.size[1])
            img.paste(bar, (5, int(h * .62)))
            return
        panel(mix(DARK, acc, .12))(img, w, h)
        d.rectangle([3, 3, w - 4, int(h * .30)], fill=rgba(acc))
        d.line([(3, int(h * .30) + 1), (w - 4, int(h * .30) + 1)], fill=rgba(lighter(acc, .5)))
        text(GPU_TAG[t], int(w * .30), int(h * .30 / 2) + 2, DARK, 8)(img, w, h)
        bar = Image.new('RGBA', (max(1, w - 10), max(2, int(h * .22))), (0, 0, 0, 0))
        rgb_bar(False, False)(bar, bar.size[0], bar.size[1])
        img.paste(bar, (5, int(h * .62)))
    return p

def gpu_top(t):
    acc = GPU_ACC[t]
    def p(img, w, h):
        panel(mix(DARK, acc, .15))(img, w, h)
        n = 2 if t < 4 else 3
        for i in range(n): fan_at(int(w * (i + .5) / n), h // 2, int(min(w / n, h) * .40), acc)(img, w, h)
    return p

def bracket_end():
    def p(img, w, h):
        panel(P.METAL, True, False)(img, w, h)
        d = ImageDraw.Draw(img)
        for i in range(3):
            y = 4 + i * (h - 8) // 3
            d.rectangle([w // 2 - 7, y, w // 2 + 7, y + max(3, h // 7)], fill=rgba(DARK))
    return p

def psu_front():
    """The power supply seen from the front: a round fan grill and a pastel label."""
    def p(img, w, h):
        panel((200, 196, 224))(img, w, h)
        d = ImageDraw.Draw(img)
        cx, cy, r = int(w * .30), h // 2, int(h * .40)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=rgba(DARK))
        for k in range(1, 4):
            d.ellipse([cx - r + k * r // 3 - 0, cy - r + k * r // 3, cx + r - k * r // 3, cy + r - k * r // 3], outline=rgba(DARK_L))
        d.line([(cx - r, cy), (cx + r, cy)], fill=rgba(DARK_L)); d.line([(cx, cy - r), (cx, cy + r)], fill=rgba(DARK_L))
        d.rounded_rectangle([int(w * .52), int(h * .22), int(w * .94), int(h * .78)], radius=3, fill=rgba(WHT), outline=rgba(LIL_D))
        text('CUTE', int(w * .73), int(h * .42), LIL_D, 9)(img, w, h)
        text('PSU', int(w * .73), int(h * .64), PINK, 9)(img, w, h)
    return p

def ribbon():
    """The thick 24-pin cable: sleeved wires in pastel colours."""
    cols = [(60, 54, 84), (255, 214, 120), (255, 150, 150), (120, 170, 250), (60, 54, 84), (130, 226, 180)]
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        n = len(cols)
        for i, c in enumerate(cols):
            d.rectangle([int(w * i / n), 0, int(w * (i + 1) / n) - 1, h], fill=rgba(c))
        for y in range(2, h, 7): d.line([(0, y), (w, y)], fill=rgba(darker(WHT, .25), 70))
    return p

def m2_label():
    def p(img, w, h):
        panel(LIL, True, False)(img, w, h)
        d = ImageDraw.Draw(img)
        d.rectangle([2, 2, w - 3, h - 3], outline=rgba(lighter(LIL, .5)))
        text('SSD', w // 2, h // 2, DARK, 8)(img, w, h)
    return p

def net_card():
    def p(img, w, h):
        panel((120, 190, 170))(img, w, h)
        d = ImageDraw.Draw(img)
        P.chip(w // 2 - 6, 3, 12, max(4, h - 7), DARK, False)(img, w, h)
        d.rectangle([2, h - 4, 6, h - 3], fill=rgba(CYAN))
    return p

# ------------------------------------------------------------------ the case
GROUPS = {}                                   # group name -> list of elements (they share the one atlas)

def build_case():
    M = P.Model()
    P.Model.img = None
    def add(group, name, frm, to, **faces):
        n0 = len(M.els)
        M.box(name, frm, to, **faces)
        for e in M.els[n0:]: e['group'] = group
    solid = lambda c: c
    BZ = 8.8                                  # the front of the board (every part on it starts here)

    # ---- the body: the shell, the back, the right side, the top, the feet, the tray, the shroud plate, the fans, the I/O
    add('body', 'back', (1.0, 0.6, 1.5), (15.0, 15.6, 2.1), north=mesh(), south=WHT_D, east=WHT, west=WHT, up=WHT, down=WHT_D)
    add('body', 'right', (14.6, 0.6, 2.1), (15.0, 15.6, 15.0), east=side_panel(), west=WHT_D, south=WHT, north=WHT, up=WHT, down=WHT_D)
    add('body', 'top', (1.0, 15.2, 2.1), (14.6, 15.6, 15.0), up=mesh(), down=WHT_D, south=WHT, north=WHT, east=WHT, west=WHT)
    add('body', 'topfront', (1.0, 15.2, 14.6), (14.6, 15.6, 15.0), south=panel(WHT), up=WHT, down=WHT_D, east=WHT, west=WHT, north=WHT)
    add('body', 'floor', (1.0, 0.6, 2.1), (14.6, 1.0, 14.6), up=(236, 232, 248), down=DARK, south=WHT, north=WHT, east=WHT, west=WHT)
    add('body', 'lip', (1.0, 0.6, 14.6), (10.6, 1.6, 15.0), south=lip_front(), up=WHT, down=DARK, east=WHT, west=WHT, north=WHT)
    add('body', 'io', (10.6, 0.6, 14.6), (14.6, 2.0, 15.3), south=io_panel(), up=WHT_L, down=DARK, east=WHT, west=WHT, north=WHT)
    for k, (x0, z0) in enumerate(((1.6, 1.9), (12.6, 1.9), (1.6, 13.0), (12.6, 13.0))):
        add('body', 'foot%d' % k, (x0, 0.0, z0), (x0 + 1.8, 0.6, z0 + 1.8), all=(70, 64, 92), down=(40, 34, 60))
    add('body', 'shroud', (1.4, 4.2, 2.1), (14.6, 4.6, 14.6), up=shroud_top(), south=panel(WHT), down=WHT_D, north=WHT, east=WHT, west=WHT)
    add('body', 'tray', (1.4, 4.6, 7.6), (14.6, 15.2, 8.2), south=tray(), north=WHT_D, up=WHT, down=WHT_D, east=WHT, west=WHT)
    add('body', 'fans', (11.0, 5.2, 12.4), (14.4, 13.6, 13.2),
        south=fan_column(3, int(2.8 * P.D), PURP), north=WHT_D, up=WHT, down=WHT_D, east=WHT, west=WHT)
    add('body', 'rail_l', (11.0, 5.2, 8.2), (11.3, 13.6, 12.4), all=WHT, south=panel(WHT, True, False))
    add('body', 'rail_r', (14.1, 5.2, 8.2), (14.4, 13.6, 12.4), all=WHT, south=panel(WHT, True, False))

    # ---- the glass: the front and the left side meet at the corner with no pillar
    P.D = 4
    add('glass', 'front', (1.0, 1.6, 14.6), (14.6, 15.2, 15.0), south=glass(), north=glass(), up=(214, 224, 246), down=(214, 224, 246), east=(214, 224, 246), west=(214, 224, 246))
    add('glass', 'left', (1.0, 1.0, 2.1), (1.4, 15.2, 14.6), west=glass(), east=glass(), up=(214, 224, 246), down=(214, 224, 246), south=(214, 224, 246), north=(214, 224, 246))
    P.D = 12

    # ---- the motherboard and its sockets
    add('board', 'pcb', (2.2, 5.2, BZ - 0.6), (10.2, 14.8, BZ), south=pcb_face(), north=WHT_D, up=LIL, down=LIL, east=LIL, west=LIL)
    add('board', 'socket', (4.2, 10.8, BZ), (6.4, 13.0, BZ + 0.3), south=DARK, up=DARK, east=DARK, west=DARK, down=DARK, north=DARK)
    add('board', 'socketface', (4.2, 10.8, BZ + 0.3), (6.4, 13.0, BZ + 0.32), south=socket_face(), up=DARK, down=DARK, east=DARK, west=DARK, north=DARK)
    for i in range(4):
        x = 7.2 + i * 0.6
        add('board', 'slot%d' % i, (x, 9.7, BZ), (x + 0.4, 14.1, BZ + 0.4), all=DARK, south=slot_face(), up=DARK_L)
    add('board', 'pcie16', (2.6, 6.9, BZ), (8.8, 7.3, BZ + 0.5), all=DARK, south=slot_face(), up=DARK_L)
    add('board', 'pcie1', (2.6, 8.0, BZ), (4.6, 8.3, BZ + 0.4), all=DARK, south=slot_face(), up=DARK_L)
    add('board', 'vrm', (2.5, 10.4, BZ), (3.7, 14.4, BZ + 1.4), south=fins(P.METAL, 8, False), up=P.METAL_L, east=fins(P.METAL, 4), west=fins(P.METAL, 4), down=P.METAL_D, north=P.METAL_D)
    add('board', 'iosink', (3.7, 14.0, BZ), (7.0, 14.6, BZ + 1.0), south=fins(P.METAL, 9, True), up=P.METAL_L, east=P.METAL_D, west=P.METAL_D, down=P.METAL_D, north=P.METAL_D)

    # ---- the processor (with its cooler: a tower with a glowing fan)
    add('cpu', 'cooler', (3.8, 10.0, BZ + 0.3), (6.8, 13.6, BZ + 3.4),
        south=compose(panel(WHT), fan_at(int(1.5 * P.D), int(1.8 * P.D), int(1.1 * P.D), PURP)), north=P.METAL_D,
        up=fins(P.METAL, 8), down=P.METAL_D, east=fins(P.METAL, 6), west=fins(P.METAL, 6))
    add('cpu', 'chip', (4.6, 11.2, BZ + 0.3), (6.0, 12.6, BZ + 0.36), all=P.METAL)

    # ---- the memory: four sticks with a light bar along their edge
    for i in range(4):
        x = 7.2 + i * 0.6
        add('ram%d' % i, 'stick', (x, 9.8, BZ + 0.1), (x + 0.4, 14.0, BZ + 1.6),
            south=rgb_bar(True, False), east=dimm_side(), west=dimm_side(), up=P.METAL_L, down=DARK, north=DARK)

    # ---- the video cards: one model for each level (the longer and thicker, the better)
    for t in (1, 2, 3, 4):
        L, T = GPU_LEN[t], GPU_THK[t]
        add('gpu%d' % t, 'shroud', (2.8, 7.3 - T, BZ + 0.2), (2.8 + L, 7.2, BZ + 4.4),
            south=gpu_front(t), up=gpu_top(t), north=DARK, down=DARK, east=panel(mix(DARK, GPU_ACC[t], .2)), west=panel(mix(DARK, GPU_ACC[t], .2)))
        add('gpu%d' % t, 'bracket', (2.4, 6.0, BZ + 0.2), (2.8, 7.6, BZ + 4.6), west=bracket_end(), east=P.METAL_D, south=P.METAL, north=P.METAL_D, up=P.METAL_L, down=P.METAL_D)
        add('gpu%d' % t, 'power', (2.8 + L - 1.6, 7.2, BZ + 3.0), (2.8 + L - 0.2, 7.7, BZ + 4.2), all=(70, 64, 92))

    # ---- the drive (an M.2 stick with a label), the network card
    add('disk', 'm2', (3.2, 9.1, BZ), (6.0, 9.7, BZ + 0.2), all=(120, 190, 170))
    add('disk', 'sink', (3.3, 9.15, BZ + 0.2), (5.9, 9.65, BZ + 0.5), south=m2_label(), up=LIL, down=LIL_D, east=LIL_D, west=LIL_D, north=LIL_D)
    add('net', 'card', (2.6, 8.0, BZ), (5.0, 8.4, BZ + 1.8), south=net_card(), up=(120, 190, 170), down=(120, 190, 170), east=(120, 190, 170), west=(120, 190, 170), north=(120, 190, 170))
    add('net', 'bracket', (2.3, 7.8, BZ), (2.6, 8.7, BZ + 2.0), west=P.METAL, east=P.METAL_D, south=P.METAL, north=P.METAL_D, up=P.METAL_L, down=P.METAL_D)

    # ---- the power supply (down in the second chamber) and its thick cable up to the board
    add('psu', 'box', (7.0, 1.1, 3.0), (14.0, 3.9, 12.0), south=psu_front(), up=(180, 176, 206), down=DARK, east=(180, 176, 206), west=(180, 176, 206), north=(170, 166, 196))
    add('cable', 'ribbon', (10.45, 3.9, 8.5), (11.05, 12.6, 9.3), south=ribbon(), east=DARK, west=DARK, up=DARK, north=DARK, down=DARK)
    add('cable', 'ribbon_low', (10.45, 3.9, 11.4), (11.05, 4.7, 12.0), all=DARK)

    # ---- the glow of a PC that is on: overlays right in front of the lights (lit = true)
    G = 0.02
    add('glow_base', 'fans', (11.0, 5.2, 13.2), (14.4, 13.6, 13.2 + G), south=fan_column(3, int(2.8 * P.D), PURP, True), all=(0, 0, 0))
    add('glow_base', 'io', (10.6, 0.6, 15.3), (14.6, 2.0, 15.3 + G), south=io_panel(True), all=(0, 0, 0))
    add('glow_base', 'lip', (1.0, 0.6, 15.0), (10.6, 1.6, 15.0 + G), south=lip_glow(), all=(0, 0, 0))
    add('glow_cpu', 'fan', (3.8, 10.0, BZ + 3.4), (6.8, 13.6, BZ + 3.4 + G), south=fan_at(int(1.5 * P.D), int(1.8 * P.D), int(1.1 * P.D), PURP, True), all=(0, 0, 0))
    for i in range(4):
        x = 7.2 + i * 0.6
        add('glow_ram%d' % i, 'bar', (x, 9.8, BZ + 1.6), (x + 0.4, 14.0, BZ + 1.6 + G), south=rgb_bar(True, True), all=(0, 0, 0))
    for t in (1, 2, 3, 4):
        L, T = GPU_LEN[t], GPU_THK[t]
        add('glow_gpu%d' % t, 'bar', (2.8, 7.3 - T, BZ + 4.4), (2.8 + L, 7.2, BZ + 4.4 + G), south=gpu_front(t, True), all=(0, 0, 0))
    add('glow_net', 'led', (2.6, 8.0, BZ + 1.8), (5.0, 8.4, BZ + 1.8 + G), south=lambda img, w, h: ImageDraw.Draw(img).rectangle([2, h - 4, 6, h - 3], fill=rgba(lighter(CYAN, .4))), all=(0, 0, 0))
    return M

# ------------------------------------------------------------------ the monitor, the keyboard and the mouse
def screen_off(img, w, h):
    d = ImageDraw.Draw(img)
    panel(WHT, True, False)(img, w, h)
    bz = int(.55 * P.D); bt = int(.55 * P.D); bb = int(1.0 * P.D)
    d.rectangle([bz, bt, w - bz - 1, h - bb - 1], fill=rgba((34, 30, 52)))
    d.rectangle([bz, bt, w - bz - 1, h - bb - 1], outline=rgba(OUT))
    for k, a in ((.18, 40), (.50, 30)):                                  # a faint reflection across the dark glass
        for t in range(h - bb - bt - 2):
            x0 = bz + (w - 2 * bz) * k + t * .5
            d.line([(x0, h - bb - 2 - t), (x0 + 10, h - bb - 2 - t)], fill=(255, 255, 255, a))
    d.ellipse([w // 2 - 2, h - bb // 2 - 2, w // 2 + 2, h - bb // 2 + 2], fill=rgba((255, 120, 120)))      # the standby light

def screen_on(img, w, h):
    d = ImageDraw.Draw(img)
    panel(WHT, True, False)(img, w, h)
    bz = int(.55 * P.D); bt = int(.55 * P.D); bb = int(1.0 * P.D)
    x0, y0, x1, y1 = bz, bt, w - bz - 1, h - bb - 1
    sw, sh = x1 - x0, y1 - y0
    for y in range(sh):                                                  # a sunset wallpaper
        t = y / max(1, sh - 1)
        c = mix(mix((255, 205, 226), (255, 226, 200), t * 1.2), (176, 196, 255), max(0, t - .45) * 1.8)
        d.line([(x0, y0 + y), (x1, y0 + y)], fill=rgba(c))
    for (cx, cy, r, col) in ((.78, .30, .13, (255, 244, 214)), (.22, .72, .22, (255, 200, 224)), (.60, .85, .30, (190, 170, 240))):
        d.ellipse([x0 + sw * cx - sw * r, y0 + sh * cy - sw * r, x0 + sw * cx + sw * r, y0 + sh * cy + sw * r], fill=rgba(col, 120))
    for i, col in enumerate((PINK, MINT, (255, 214, 120), CYAN)):        # desktop icons
        ix, iy = x0 + 8, y0 + 8 + i * 24
        d.rounded_rectangle([ix, iy, ix + 16, iy + 16], radius=4, fill=rgba(col), outline=rgba(OUT))
        d.rectangle([ix + 3, iy + 20, ix + 13, iy + 21], fill=rgba(WHT, 200))
    wx0, wy0, wx1, wy1 = x0 + int(sw * .30), y0 + int(sh * .18), x0 + int(sw * .78), y0 + int(sh * .66)        # a window
    d.rounded_rectangle([wx0, wy0, wx1, wy1], radius=5, fill=rgba(WHT_L, 235), outline=rgba(OUT))
    d.rounded_rectangle([wx0, wy0, wx1, wy0 + 11], radius=5, fill=rgba(PINK), outline=rgba(OUT))
    for k, c in enumerate(((255, 214, 120), MINT, CYAN)):
        d.ellipse([wx1 - 30 + k * 9, wy0 + 3, wx1 - 24 + k * 9, wy0 + 8], fill=rgba(c))
    text('Cute OS', (wx0 + wx1) // 2, (wy0 + wy1) // 2 + 4, LIL_D, 12)(img, w, h)
    d.rectangle([x0, y1 - 12, x1, y1], fill=rgba((255, 255, 255), 190))                                          # the taskbar
    d.ellipse([x0 + 4, y1 - 10, x0 + 14, y1 - 2], fill=rgba(PINK), outline=rgba(OUT))
    for k in range(4): d.rounded_rectangle([x0 + 22 + k * 14, y1 - 10, x0 + 32 + k * 14, y1 - 2], radius=2, fill=rgba(LIL))
    d.rectangle([x1 - 22, y1 - 9, x1 - 4, y1 - 3], fill=rgba(WHT_D))
    d.ellipse([w // 2 - 2, h - bb // 2 - 2, w // 2 + 2, h - bb // 2 + 2], fill=rgba(MINT))

def build_monitor(on):
    M = P.Model()
    def back(img, w, h):
        panel(WHT)(img, w, h)
        text('CUTE', w // 2, h // 2, LIL_D, 11)(img, w, h)
        ImageDraw.Draw(img).ellipse([w // 2 - 3, h // 2 + 8, w // 2 + 3, h // 2 + 14], outline=rgba(LIL))
    scr = screen_on if on else screen_off
    M.box('panel', (0.5, 3.4, 7.6), (15.5, 13.2, 8.8), south=scr, north=WHT_D, up=WHT_L, down=WHT_D, east=WHT, west=WHT)
    M.box('bulge', (4.5, 4.4, 6.4), (11.5, 11.4, 7.6), north=back, south=WHT_D, up=WHT, down=WHT_D, east=WHT_D, west=WHT_D)
    M.box('neck', (7.0, 0.8, 6.8), (9.0, 3.4, 8.2), all=WHT_D, south=panel(WHT, True, False), up=WHT)
    M.box('foot', (4.5, 0.0, 5.5), (11.5, 0.8, 10.5), up=compose(panel(WHT), lambda img, w, h: ImageDraw.Draw(img).line([(6, 6), (w - 7, 6)], fill=rgba(LIL))),
          south=panel(WHT), north=WHT_D, east=WHT, west=WHT, down=DARK)
    return M

def keys_top(img, w, h):
    d = ImageDraw.Draw(img)
    panel(WHT, True, False)(img, w, h)
    u = P.D / 12.0
    pad = 8
    rows = [(14, 1.0), (13, 1.0), (13, 1.0), (12, 1.0)]
    y = pad
    accents = {0: PINK, 12: LIL, 25: MINT}
    kw = (w - 2 * pad)
    n_idx = 0
    # function row (small keys), three rows of letters, then the space bar row
    def key(x0, y0, x1, y1, c):
        d.rounded_rectangle([x0, y0 + 1, x1, y1 + 1], radius=2, fill=rgba(mix(c, DARK, .3)))
        d.rounded_rectangle([x0, y0, x1, y1], radius=2, fill=rgba(c), outline=rgba(mix(c, OUT, .35)))
        d.line([(x0 + 2, y0 + 1), (x1 - 2, y0 + 1)], fill=rgba(lighter(c, .6)))
    row_h = int((h - 2 * pad) / 5.0)
    colors = [WHT, (250, 232, 242), (240, 236, 252)]
    for r in range(5):
        y0 = pad + r * row_h; y1 = y0 + row_h - 3
        if r == 4:                                                         # bottom row: a long space bar between small keys
            key(pad, y0, pad + int(kw * .12), y1, LIL)
            key(pad + int(kw * .15), y0, pad + int(kw * .27), y1, WHT)
            key(pad + int(kw * .30), y0, pad + int(kw * .70), y1, MINT)
            key(pad + int(kw * .73), y0, pad + int(kw * .85), y1, WHT)
            key(pad + int(kw * .88), y0, pad + kw, y1, PINK)
            continue
        n = 14 if r == 0 else 13
        gap = 3
        kwid = (kw - gap * (n - 1)) / n
        for i in range(n):
            x0 = int(pad + i * (kwid + gap)); x1 = int(x0 + kwid)
            c = PINK if (r == 0 and i == 0) else LIL if (r == 2 and i == n - 1) else colors[(i + r) % 3]
            key(x0, y0, x1, y1, c)

def build_keyboard():
    M = P.Model()
    M.box('body', (1.5, 0.0, 5.5), (14.5, 0.9, 10.5), up=keys_top, south=panel(WHT, True, False), north=WHT_D, east=WHT, west=WHT, down=DARK)
    M.box('ridge', (1.5, 0.9, 5.5), (14.5, 1.2, 5.9), all=WHT_D, up=WHT, south=WHT)
    M.box('cable', (7.6, 0.2, 4.4), (8.4, 0.5, 5.5), all=(70, 64, 92))
    return M

def mouse_top(img, w, h):
    d = ImageDraw.Draw(img)
    panel(WHT, True, True)(img, w, h)
    d.line([(w // 2, 3), (w // 2, int(h * .46))], fill=rgba(LIL_D))
    d.line([(3, int(h * .46)), (w - 4, int(h * .46))], fill=rgba(LIL_D))
    d.rounded_rectangle([w // 2 - 2, int(h * .12), w // 2 + 2, int(h * .34)], radius=2, fill=rgba(PINK), outline=rgba(OUT))
    P.heart(w // 2, int(h * .72), 1, PINK)(img, w, h)

def build_mouse():
    M = P.Model()
    M.box('body', (6.8, 0.0, 5.8), (9.2, 0.9, 9.0), south=panel(WHT, True, False), north=WHT, east=WHT, west=WHT, up=WHT, down=DARK)
    M.box('hump', (7.0, 0.9, 6.0), (9.0, 1.4, 8.8), up=mouse_top, south=WHT, north=WHT, east=WHT, west=WHT, down=WHT_D)
    M.box('cable', (7.8, 0.3, 5.0), (8.2, 0.55, 5.8), all=(70, 64, 92))
    return M

# ------------------------------------------------------------------ writing everything
ROT = {'south': 0, 'west': 90, 'north': 180, 'east': 270}
BLOCK_DISPLAY = {
    "gui": {"rotation": [30, 225, 0], "translation": [0, -1, 0], "scale": [0.64, 0.64, 0.64]},
    "fixed": {"rotation": [0, 180, 0], "scale": [0.62, 0.62, 0.62]},
    "ground": {"translation": [0, 3, 0], "scale": [0.4, 0.4, 0.4]},
    "firstperson_righthand": {"rotation": [30, -15, 0], "translation": [0.5, 3.5, 1.5], "scale": [0.45, 0.45, 0.45]},
    "firstperson_lefthand": {"rotation": [30, 15, 0], "translation": [-0.5, 3.5, 1.5], "scale": [0.45, 0.45, 0.45]},
    "thirdperson_righthand": {"rotation": [-20, 0, 0], "translation": [0, 2.5, -0.8], "scale": [0.36, 0.36, 0.36]},
    "thirdperson_lefthand": {"rotation": [-20, 0, 0], "translation": [0, 2.5, -0.8], "scale": [0.36, 0.36, 0.36]},
}

def clean(e, glow=False):
    out = {"name": e['name'], "from": e['from'], "to": e['to'], "faces": e['faces']}
    if glow:                                              # lights that shine in the dark (NeoForge reads neoforge_data; vanilla ignores it)
        out["shade"] = False
        out["neoforge_data"] = {"block_light": 15, "sky_light": 15}
        for f in out["faces"].values(): f["neoforge_data"] = {"block_light": 15, "sky_light": 15}
    return out

def write_model(name, atlas_name, els, size, render, glow=False, display=None, extra=None):
    m = {"credit": "generated by tools/make_pc_case.py", "ambientocclusion": False, "texture_size": [size, size],
         "textures": {"particle": "cutemod:block/" + atlas_name, "t": "cutemod:block/" + atlas_name},
         "elements": [clean(e, glow) for e in els], "render_type": render}
    if display: m["display"] = display
    with open(os.path.join(RES, 'models/block/%s.json' % name), 'w') as f: json.dump(m, f, indent=1)

def item_model(name, parent):
    d = {"parent": "cutemod:block/" + parent, "display": BLOCK_DISPLAY}
    with open(os.path.join(RES, 'models/item/%s.json' % name), 'w') as f: json.dump(d, f, indent=1)

def write_case(M):
    M.img.save(os.path.join(RES, 'textures/block/pc_case_atlas.png'))
    for g in sorted({e['group'] for e in M.els}):
        els = [e for e in M.els if e['group'] == g]
        glow = g.startswith('glow_')
        render = 'minecraft:translucent' if (glow or g == 'glass') else 'minecraft:cutout'
        write_model('pc_case_' + g, 'pc_case_atlas', els, ATLAS, render, glow)
    # the empty case as an item: the shell, the glass and the fans (item models draw translucent glass in one pass)
    els = [e for e in M.els if e['group'] in ('body', 'glass')]
    write_model('pc_case_item', 'pc_case_atlas', els, ATLAS, 'minecraft:translucent')
    item_model('pc_case', 'pc_case_item')

    mp = []
    def part(group, when=None):
        for f, y in ROT.items():
            cond = {"facing": f}
            if when: cond.update(when)
            mp.append({"when": cond, "apply": {"model": "cutemod:block/pc_case_" + group, "y": y}})
    part('body'); part('glass')
    part('board', {"board": "true"})
    part('cpu', {"cpu": "true"})
    for i in range(4):
        part('ram%d' % i, {"ram": "|".join(str(n) for n in range(i + 1, 5))})
    for t in (1, 2, 3, 4): part('gpu%d' % t, {"gpu": str(t)})
    part('disk', {"disk": "true"}); part('net', {"net": "true"})
    part('psu', {"psu": "true"})
    for f, y in ROT.items():                              # the thick cable needs the power supply AND the board
        mp.append({"when": {"facing": f, "psu": "true", "board": "true"}, "apply": {"model": "cutemod:block/pc_case_cable", "y": y}})
    part('glow_base', {"lit": "true"})
    part('glow_cpu', {"lit": "true", "cpu": "true"})
    for i in range(4): part('glow_ram%d' % i, {"lit": "true", "ram": "|".join(str(n) for n in range(i + 1, 5))})
    for t in (1, 2, 3, 4): part('glow_gpu%d' % t, {"lit": "true", "gpu": str(t)})
    part('glow_net', {"lit": "true", "net": "true"})
    with open(os.path.join(RES, 'blockstates/pc_case.json'), 'w') as f: json.dump({"multipart": mp}, f, indent=1)

def write_simple(name, M, atlas_name, size, glow=False, render='minecraft:cutout', states=None):
    M.img.save(os.path.join(RES, 'textures/block/%s.png' % atlas_name))
    write_model(name, atlas_name, M.els, size, render, glow)

def facing_variants(model, extra=None):
    v = {}
    for f, y in ROT.items():
        key = "facing=" + f
        if extra: key += "," + extra
        v[key] = {"model": "cutemod:block/" + model, "y": y}
    return v

def main():
    case = build_case()
    write_case(case)
    off, on = build_monitor(False), build_monitor(True)
    write_simple('pc_monitor_off', off, 'pc_monitor_off', ATLAS)
    write_model('pc_monitor_on', 'pc_monitor_on', on.els, ATLAS, 'minecraft:cutout')
    on.img.save(os.path.join(RES, 'textures/block/pc_monitor_on.png'))
    # the screen of a monitor that is on shines (it is the whole front face, the frame shines a little too: it reads as a screen)
    els = []
    for e in on.els:
        ee = dict(e)
        els.append(ee)
    mon_on = json.load(open(os.path.join(RES, 'models/block/pc_monitor_on.json')))
    for el in mon_on['elements']:
        if el['name'] == 'panel':
            el['neoforge_data'] = {"block_light": 15, "sky_light": 15}
            el['faces']['south']['neoforge_data'] = {"block_light": 15, "sky_light": 15}
    json.dump(mon_on, open(os.path.join(RES, 'models/block/pc_monitor_on.json'), 'w'), indent=1)
    v = {}
    v.update(facing_variants('pc_monitor_off', 'on=false'))
    v.update(facing_variants('pc_monitor_on', 'on=true'))
    json.dump({"variants": v}, open(os.path.join(RES, 'blockstates/pc_monitor.json'), 'w'), indent=1)
    item_model('pc_monitor', 'pc_monitor_on')

    kb = build_keyboard(); write_simple('pc_keyboard', kb, 'pc_keyboard', ATLAS)
    json.dump({"variants": facing_variants('pc_keyboard')}, open(os.path.join(RES, 'blockstates/pc_keyboard.json'), 'w'), indent=1)
    item_model('pc_keyboard', 'pc_keyboard')
    ms = build_mouse(); write_simple('pc_mouse', ms, 'pc_mouse', ATLAS)
    json.dump({"variants": facing_variants('pc_mouse')}, open(os.path.join(RES, 'blockstates/pc_mouse.json'), 'w'), indent=1)
    item_model('pc_mouse', 'pc_mouse')
    print('wrote the case (%d elements in %d groups), the monitor, the keyboard and the mouse' % (len(case.els), len({e['group'] for e in case.els})))
    if '--preview' in sys.argv:
        preview_all(case, off, on, kb, ms)

# ------------------------------------------------------------------ preview (isometric, only for looking at the result)
def render(model_els, img, S=26, ay_deg=30, ax_deg=22, size=(420, 420), bg=(88, 84, 104, 255), scale_to=None, center=(8, 8, 8)):
    import numpy as np
    CW, CH = size
    tile = Image.new('RGBA', size, bg)
    ax, ay = math.radians(ax_deg), math.radians(ay_deg)
    cx, cy_, cz = center
    def rot(p):
        x, y, z = p[0] - cx, p[1] - cy_, p[2] - cz
        x, z = x * math.cos(ay) + z * math.sin(ay), -x * math.sin(ay) + z * math.cos(ay)
        y, z = y * math.cos(ax) - z * math.sin(ax), y * math.sin(ax) + z * math.cos(ax)
        return x, y, z
    def coeffs(dst, src):
        A = []; B = []
        for (X, Y), (x, y) in zip(dst, src):
            A.append([X, Y, 1, 0, 0, 0, -x * X, -x * Y]); A.append([0, 0, 0, X, Y, 1, -y * X, -y * Y]); B += [x, y]
        return list(np.linalg.solve(np.array(A, float), np.array(B, float)))
    quads = []
    for e in model_els:
        x1, y1, z1 = e['from']; x2, y2, z2 = e['to']
        F = {'south': [(x1, y2, z2), (x2, y2, z2), (x2, y1, z2), (x1, y1, z2)], 'north': [(x2, y2, z1), (x1, y2, z1), (x1, y1, z1), (x2, y1, z1)],
             'east': [(x2, y2, z2), (x2, y2, z1), (x2, y1, z1), (x2, y1, z2)], 'west': [(x1, y2, z1), (x1, y2, z2), (x1, y1, z2), (x1, y1, z1)],
             'up': [(x1, y2, z1), (x2, y2, z1), (x2, y2, z2), (x1, y2, z2)], 'down': [(x1, y1, z2), (x2, y1, z2), (x2, y1, z1), (x1, y1, z1)]}
        for f, pts in F.items():
            r = [rot(p) for p in pts]
            ux, uy = r[1][0] - r[0][0], r[1][1] - r[0][1]; vx, vy = r[3][0] - r[0][0], r[3][1] - r[0][1]
            if ux * vy - uy * vx > 0: continue
            quads.append((sum(p[2] for p in r) / 4 + (0.001 if e.get('group', '').startswith('glow') else 0), r, e['faces'][f]['uv'], e.get('group', '')))
    quads.sort(key=lambda q: q[0])
    for _, r, uv, g in quads:
        dst = [(CW / 2 + p[0] * S, CH / 2 - p[1] * S) for p in r]
        u1, v1, u2, v2 = [c * ATLAS / 16 for c in uv]
        src = [(u1, v1), (u2, v1), (u2, v2), (u1, v2)]
        try: c = coeffs(dst, src)
        except Exception: continue
        sub = img.transform((CW, CH), Image.PERSPECTIVE, c, Image.BILINEAR)
        mask = Image.new('L', (CW, CH), 0); ImageDraw.Draw(mask).polygon(dst, fill=255)
        a = sub.split()[3]
        tile.paste(sub, (0, 0), Image.composite(a, Image.new('L', (CW, CH), 0), mask))
    return tile

def preview_all(case, off, on, kb, ms):
    def pick(groups):
        return [e for e in case.els if e['group'] in groups]
    base = ['body', 'glass']
    stages = [
        ('empty', base),
        ('board', base + ['board']),
        ('cpu', base + ['board', 'cpu']),
        ('ram', base + ['board', 'cpu', 'ram0', 'ram1']),
        ('gpu+disk+psu', base + ['board', 'cpu', 'ram0', 'ram1', 'gpu3', 'disk', 'psu', 'cable', 'net']),
        ('ON', base + ['board', 'cpu', 'ram0', 'ram1', 'gpu3', 'disk', 'psu', 'cable', 'net', 'glow_base', 'glow_cpu', 'glow_ram0', 'glow_ram1', 'glow_gpu3', 'glow_net']),
    ]
    tiles = []
    for _, gs in stages:
        tiles.append(render(pick(gs), case.img, 17, 32, 18))
    W, H = tiles[0].size
    sheet = Image.new('RGBA', (W * 3, H * 2), (88, 84, 104, 255))
    for i, t in enumerate(tiles): sheet.paste(t, ((i % 3) * W, (i // 3) * H))
    sheet.save('/tmp/pc_case_preview.png')
    # the desk
    desk = Image.new('RGBA', (W * 3, H), (88, 84, 104, 255))
    for i, (m, c) in enumerate(((on, (8, 4, 8)), (kb, (8, 1, 8)), (ms, (8, 1, 8)))):
        desk.paste(render(m.els, m.img, 20, 28, 24, center=c), (i * W, 0))
    desk.save('/tmp/pc_desk_preview.png')
    print('previews: /tmp/pc_case_preview.png /tmp/pc_desk_preview.png')

if __name__ == '__main__':
    main()
