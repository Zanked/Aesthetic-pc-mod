#!/usr/bin/env python3
"""Makes the screen of every laptop really rounded.

The *_screen.png textures had their four outer corners painted in the colour of the body (a fake rounded lid), and that paint glowed
next to the black frame because the screen face is drawn at full brightness. Here those corner pixels are made TRANSPARENT instead
(the laptop models use "render_type": "minecraft:cutout"), in the screen and in the matching *_back.png (the other side of the lid,
mirrored, and for the animated gaming back every frame), so the corner is simply cut away.
Run from the repo root: python3 tools/round_laptop_corners.py   (safe to run twice)
"""
import glob, json, os
from collections import deque
from PIL import Image

TEX = "src/main/resources/assets/cutemod/textures/block/"
MODELS = "src/main/resources/assets/cutemod/models/block/"
R, GAP = 12, 6          # how far from a corner we look; how much lighter than the frame a painted corner pixel is

def lum(p): return 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]

for path in sorted(glob.glob(TEX + "*_screen.png")):
    im = Image.open(path).convert("RGBA"); w, h = im.size; px = im.load()
    mask = set()
    for cx, cy, dx, dy in ((0, 0, 1, 1), (w - 1, 0, -1, 1), (0, h - 1, 1, -1), (w - 1, h - 1, -1, -1)):
        if px[cx, cy][3] == 0: continue                                # already cut
        a, b = px[cx + dx * R, cy], px[cx, cy + dy * R]
        frame = a if lum(a) <= lum(b) else b                           # the frame on the edge of the texture
        if lum(px[cx, cy]) <= lum(frame) + GAP: continue
        seen = {(cx, cy)}; q = deque([(cx, cy)])
        while q:
            x, y = q.popleft()
            if lum(px[x, y]) > lum(frame) + GAP:
                mask.add((x, y))
                for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                    if 0 <= nx < w and 0 <= ny < h and (nx, ny) not in seen and abs(nx - cx) < R and abs(ny - cy) < R:
                        seen.add((nx, ny)); q.append((nx, ny))
        for x, y in mask: px[x, y] = (*frame[:3], 0)                    # transparent, but the colour of the frame (no light fringe)
    im.save(path)
    back = path.replace("_screen.png", "_back.png")
    if mask and os.path.exists(back):
        bi = Image.open(back).convert("RGBA"); bw, bh = bi.size; bp = bi.load()
        assert bw == w and bh % h == 0, back
        for frame_no in range(bh // h):                                # the gaming backs are animated: frames one under another
            for x, y in mask:
                u = w - 1 - x                                          # the back is seen from behind: left and right swap
                c = bp[u, frame_no * h + y]; bp[u, frame_no * h + y] = (c[0], c[1], c[2], 0)
        bi.save(back)
    print(os.path.basename(path), len(mask))

for path in glob.glob(MODELS + "*_laptop.json") + glob.glob(MODELS + "*_laptop_closed.json"):
    d = json.load(open(path))
    if d.get("render_type") != "minecraft:cutout":
        d["render_type"] = "minecraft:cutout"
        json.dump(d, open(path, "w"), indent=1)
