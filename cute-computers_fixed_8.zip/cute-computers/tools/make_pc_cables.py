"""
The cables of the PC: the required part that connects the power supply to the board, the drive and the card.

  python tools/make_pc_cables.py [--preview]

writes
  textures/item/pc_cables_3d.png     one atlas for the item (128x128, like the other parts)
  models/item/pc_cables.json         the 3D model: a coil of pastel sleeved wires, a white 24-pin plug, a SATA plug,
                                     a PCIe plug and a pink strap with a heart tag
--preview also writes /tmp/pc_cables_preview.png (only for looking at the result).

Same look as the other parts (make_pc_parts.py, which this reuses): pastel pixel art with a dark purple outline.
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_pc_parts as P
from PIL import ImageDraw

P.ATLAS = 128                              # the same size as every other part of the PC (see make_pc_parts.py)
P.SCALE = 2                                # the faces are drawn 2x larger and shrunk, like the other parts
P.D = 8

mix, lighter, darker = P.mix, P.lighter, P.darker
panel, compose, dots = P.panel, P.compose, P.dots
OUT, BLACK, WHITE, METAL, METAL_D, GOLD = P.OUT, P.BLACK, P.WHITE, P.METAL, P.METAL_D, P.GOLD

PINK, GOLDW, MINT, SKY, LILAC = (255, 150, 176), (255, 214, 120), (130, 226, 180), (120, 170, 250), (186, 160, 240)
LAYERS = [PINK, GOLDW, MINT, SKY, LILAC]    # the wires of the coil, bottom to top


def rgba(c, a=255): return tuple(c[:3]) + (a,)


class CachedModel(P.Model):
    """The model of make_pc_parts, but a painted face that is drawn again (the same painter, the same size) reuses its place in the atlas."""
    def __init__(self):
        super().__init__()
        self.cache = {}
        self.used = [[False] * P.ATLAS for _ in range(P.ATLAS)]      # which texels are taken: faces are packed tightly (first fit)

    def _alloc(self, w, h):
        w += 2; h += 2                                  # 1 px of space around, so nothing bleeds
        for y in range(8, P.ATLAS - h + 1):
            for x in range(0, P.ATLAS - w + 1):
                if all(not self.used[yy][xx] for yy in range(y, y + h) for xx in range(x, x + w)):
                    for yy in range(y, y + h):
                        for xx in range(x, x + w): self.used[yy][xx] = True
                    return (x + 1, y + 1)
        raise RuntimeError('atlas full')

    def box(self, name, frm, to, **faces):
        x1, y1, z1 = frm; x2, y2, z2 = to
        dims = {'south': (x2 - x1, y2 - y1), 'north': (x2 - x1, y2 - y1), 'east': (z2 - z1, y2 - y1),
                'west': (z2 - z1, y2 - y1), 'up': (x2 - x1, z2 - z1), 'down': (x2 - x1, z2 - z1)}
        out = {}
        for f, (wu, hu) in dims.items():
            spec = faces.get(f, faces.get('all', METAL))
            if callable(spec):
                w, h = max(2, round(wu * P.D)), max(2, round(hu * P.D))
                key = (spec, w, h)
                if key not in self.cache:
                    fi = P.Image.new('RGBA', (w, h), (0, 0, 0, 0))
                    del P.PENDING[:]
                    spec(fi, w, h)
                    w, h = max(1, w // P.SCALE), max(1, h // P.SCALE)
                    fi = fi.resize((w, h), P.Image.BOX)
                    for (t, cx, cy, c, size) in P.PENDING: P.write_text(fi, t, cx // P.SCALE, cy // P.SCALE, c, size)
                    del P.PENDING[:]
                    px, py = self._alloc(w, h)
                    self.img.paste(fi, (px, py))
                    self.cache[key] = [px, py, px + w, py + h]
                uv = self.cache[key]
            else:
                uv = self._solid(spec)
            out[f] = {"uv": [round(v * 16 / P.ATLAS, 4) for v in uv], "texture": "#t"}
        self.els.append({"name": name, "from": [round(v, 3) for v in frm], "to": [round(v, 3) for v in to], "faces": out})


def sleeve(c, vertical=False):
    """A braided sleeve: the pastel colour with fine diagonal threads, a bright top edge and a dark outline."""
    def p(img, w, h):
        panel(c, True, False)(img, w, h)
        d = ImageDraw.Draw(img)
        step = 5
        span = h if not vertical else w
        for k in range(-span, max(w, h) + span, step):
            d.line([(k, 1), (k + span // 2, h - 2)] if not vertical else [(1, k), (w - 2, k + span // 2)],
                   fill=rgba(darker(c, .22), 70))
    return p


def plug_front(c, rows=2, cols=6, pin=BLACK):
    """The face of a plug: a pastel body with a grid of dark pin holes and a small latch notch."""
    def p(img, w, h):
        panel(c)(img, w, h)
        d = ImageDraw.Draw(img)
        mx, my = max(3, w // 8), max(3, h // 4)
        for r in range(rows):
            for k in range(cols):
                x = mx + (w - 2 * mx) * (k + .5) / cols
                y = my + (h - 2 * my) * (r + .5) / rows
                rr = max(1, int(min((w - 2 * mx) / cols, (h - 2 * my) / rows) / 3))
                d.rectangle([x - rr, y - rr, x + rr, y + rr], fill=rgba(pin))
                d.point((int(x - rr), int(y - rr)), fill=rgba(lighter(pin, .5)))
        d.rectangle([w // 2 - 3, 1, w // 2 + 2, 3], fill=rgba(darker(c, .35)))
    return p


def tag(img, w, h):
    """The strap's little tag: pink, with a white heart."""
    panel(PINK)(img, w, h)
    P.heart(w // 2, h // 2, max(1, w // 9), (255, 255, 255))(img, w, h)


SLEEVES = {}


def sleeve_of(c, vertical=False):
    if (c, vertical) not in SLEEVES: SLEEVES[(c, vertical)] = sleeve(c, vertical)
    return SLEEVES[(c, vertical)]


def loop(m, name, x0, z0, x1, z1, y0, y1, t, c):
    """One turn of the coil: four boxes laid as a ring. Only the faces that can be seen are painted (the atlas is small, like the other parts)."""
    s, v, hid = sleeve_of(c), sleeve_of(c, True), darker(c, .3)
    m.box(name + '_n', (x0, y0, z0), (x1, y1, z0 + t), all=hid, south=s, up=s)
    m.box(name + '_s', (x0, y0, z1 - t), (x1, y1, z1), all=hid, south=s, up=s, north=s)
    m.box(name + '_w', (x0, y0, z0 + t), (x0 + t, y1, z1 - t), all=hid, up=v, west=v)
    m.box(name + '_e', (x1 - t, y0, z0 + t), (x1, y1, z1 - t), all=hid, up=v, east=v)


def cables():
    m = CachedModel()
    # the coil: five turns of wire, one on top of another, every one its own pastel colour
    y = 3.6
    for i, c in enumerate(LAYERS):
        o = .3 if i % 2 else 0                                   # every second turn lies a little aside, like a coil wound by hand
        loop(m, 'turn%d' % i, 2.2 + o, 2.6 - o, 13.8 + o, 11.4 - o, y, y + 1.2, 1.2, c)
        y += 1.2
    # the 24-pin plug, white, sticking out of the front (only its face is painted, the rest is a flat colour: the atlas is small)
    m.box('pin24', (8.6, 4.2, 11.4), (13.0, 8.4, 14.6), all=darker(WHITE, .12), south=plug_front(WHITE, 2, 6), up=lighter(WHITE, .2), down=darker(WHITE, .25))
    m.box('pin24_lock', (10.2, 8.4, 11.8), (11.4, 9.0, 14.0), all=darker(WHITE, .25))
    # the SATA plug (a flat L-shaped one, dark), left of it
    m.box('sata', (3.0, 4.2, 11.4), (5.6, 6.2, 13.6), all=(64, 56, 88), south=plug_front((82, 72, 108), 1, 4, (30, 24, 44)), up=(82, 72, 108), down=(44, 38, 62))
    m.box('sata_l', (3.0, 6.2, 11.4), (4.2, 7.4, 13.6), all=(82, 72, 108), up=(98, 88, 126))
    # the PCIe plug (a lilac one with a gold tip)
    m.box('pcie', (6.0, 4.2, 11.4), (8.2, 7.2, 13.8), all=darker(LILAC, .15), south=plug_front(LILAC, 2, 4), up=lighter(LILAC, .25), down=darker(LILAC, .3))
    m.box('pcie_tip', (6.6, 6.0, 13.8), (7.6, 6.9, 14.2), all=GOLD)
    # the strap that ties the coil: a pink band round the left side, with a tag
    m.box('strap', (1.9, 3.4, 5.0), (4.3, 10.4, 8.0), all=PINK, up=lighter(PINK, .15), west=darker(PINK, .12), east=darker(PINK, .12), down=darker(PINK, .3))
    m.box('strap_tag', (1.5, 5.0, 8.0), (2.1, 8.0, 9.6), all=darker(PINK, .1), west=tag, up=lighter(PINK, .2), down=darker(PINK, .3))
    # two free wire ends hanging from the back of the coil, as in a real tangle
    m.box('end0', (4.0, 3.6, 1.2), (4.9, 4.5, 2.6), all=PINK, up=lighter(PINK, .15))
    m.box('end1', (11.0, 3.6, 1.2), (11.9, 4.5, 2.6), all=MINT, up=lighter(MINT, .15))
    m.box('end0_tip', (4.1, 3.7, 0.7), (4.8, 4.4, 1.2), all=METAL)
    m.box('end1_tip', (11.1, 3.7, 0.7), (11.8, 4.4, 1.2), all=METAL)
    return m


if __name__ == '__main__':
    m = cables()
    m.save('pc_cables')
    print('wrote pc_cables (%d elements)' % len(m.els))
    if '--preview' in sys.argv:
        P.preview([('pc_cables', m)], os.environ.get('PREVIEW_OUT', '/tmp/pc_cables_preview.png'))
        print('preview: /tmp/pc_cables_preview.png')
