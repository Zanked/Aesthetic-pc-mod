#!/usr/bin/env python3
"""
The keyboard and the mouse have their OWN styles now (they do not take the colour of the monitor any more).

  python3 tools/make_pc_peripherals.py       (run from the repo root, AFTER make_pc_colors.py; it can be run again and again)

Styles (must be the same as dev.cutemod.block.PcPeriphStyle):
  white pink blue mint purple yellow red black      the plain colours (textures pc_keyboard_<c> / pc_mouse_<c> come from make_pc_colors.py)
  black_rgb white_rgb sakura                        drawn here: animated RGB glow (12 frames, smooth), and the Sakura Edition keyboard / mouse

What it writes:
  textures/block/pc_kb_<style>.png (+ .mcmeta)  and  pc_ms_<style>.png (+ .mcmeta)     the animated atlases (320x80 / 64x48 per frame)
  models/block/pc_monitor_keyboard_<style>.json, pc_monitor_mouse_<style>.json           the part that is drawn in front of the monitor
  models/block/pc_monitor_mouse.json, pc_mouse.json     the mouse is made rounder (3 stacked layers with cut corners) before the other styles are cut out of them
  models/block/pc_keyboard_<style>.json, pc_mouse_<style>.json, models/item/...          the item pictures
  blockstates/pc_monitor.json     the keyboard / mouse parts now follow the block state "kb_style" / "ms_style" (NOT the monitor colour)
  data/cutemod/recipe/..., data/cutemod/tags/item/pc_keyboards.json, pc_mice.json
  lang: item names (en_us / ru_ru)
"""
import os, json, math, colorsys, copy
from PIL import Image, ImageDraw

RES = "src/main/resources/assets/cutemod"
DATA = "src/main/resources/data/cutemod"
TEX = f"{RES}/textures/block"
MOD = f"{RES}/models/block"
ITM = f"{RES}/models/item"

PLAIN = ["white", "pink", "blue", "mint", "purple", "yellow", "red", "black"]
SPECIAL = ["black_rgb", "white_rgb", "sakura"]
STYLES = PLAIN + SPECIAL
FACINGS = (("south", 0), ("west", 90), ("north", 180), ("east", 270))

EN = {"white": "White", "pink": "Pink", "blue": "Blue", "mint": "Mint", "purple": "Purple", "yellow": "Yellow", "red": "Red", "black": "Black"}
RU_F = {"white": "Белая", "pink": "Розовая", "blue": "Голубая", "mint": "Мятная", "purple": "Фиолетовая", "yellow": "Жёлтая", "red": "Красная", "black": "Чёрная"}
NAMES = {
    "en_us": {"keyboard": {"black_rgb": "Black RGB Keyboard", "white_rgb": "White RGB Keyboard", "sakura": "Sakura Edition Keyboard"},
              "mouse": {"black_rgb": "Black RGB Mouse", "white_rgb": "White RGB Mouse", "sakura": "Sakura Edition Mouse"}},
    "ru_ru": {"keyboard": {"black_rgb": "Чёрная RGB клавиатура", "white_rgb": "Белая RGB клавиатура", "sakura": "Клавиатура «Сакура»"},
              "mouse": {"black_rgb": "Чёрная RGB мышь", "white_rgb": "Белая RGB мышь", "sakura": "Мышь «Сакура»"}},
}
DYE = {"white": "white_dye", "pink": "pink_dye", "blue": "light_blue_dye", "mint": "lime_dye", "purple": "purple_dye",
       "yellow": "yellow_dye", "red": "red_dye", "black": "black_dye"}

FRAMES = 12            # animation frames of the RGB wave
FRAMETIME = 4          # ticks per frame (the frames are blended: interpolate)
S = 4                  # supersampling of the drawing

KB_FRAME = (320, 80)   # old atlas content lives in (0,0)-(316,70)
MS_FRAME = (64, 48)    # old atlas content lives in (0,0)-(57,44)
KB_TOP = (159, 9, 315, 69)     # 156 x 60
KB_FRONT = (1, 9, 157, 20)     # 156 x 11
MS_TOP = (32, 9, 56, 43)       # 24 x 34
MS_FRONT = (1, 9, 30, 20)      # 29 x 11


# ------------------------------------------------------------------------------------------------ small helpers
def hsv(h, s, v, a=255):
    r, g, b = colorsys.hsv_to_rgb(h % 1.0, max(0, min(1, s)), max(0, min(1, v)))
    return (round(r * 255), round(g * 255), round(b * 255), a)


def mix(c1, c2, t):
    return tuple(round(c1[i] + (c2[i] - c1[i]) * t) for i in range(4))


def canvas(w, h, fill=(0, 0, 0, 255)):
    return Image.new("RGBA", (w * S, h * S), fill)


def rr(img, box, r, fill, outline=None, width=1.0):
    d = ImageDraw.Draw(img)
    x0, y0, x1, y1 = box
    d.rounded_rectangle([x0 * S, y0 * S, x1 * S - 1, y1 * S - 1], radius=max(0, r) * S, fill=fill,
                        outline=outline, width=max(1, round(width * S)) if outline else 0)


def over(img, box, r, color):
    """Draw with alpha ON TOP of what is there (PIL's draw would replace the pixels)."""
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    rr(layer, box, r, color)
    img.alpha_composite(layer)


def ell(img, cx, cy, rx, ry, fill):
    d = ImageDraw.Draw(img)
    d.ellipse([(cx - rx) * S, (cy - ry) * S, (cx + rx) * S - 1, (cy + ry) * S - 1], fill=fill)


def poly(img, pts, fill):
    d = ImageDraw.Draw(img)
    d.polygon([(x * S, y * S) for x, y in pts], fill=fill)


def line_h(img, x0, x1, y, h, fill):
    d = ImageDraw.Draw(img)
    d.rectangle([x0 * S, y * S, x1 * S - 1, (y + h) * S - 1], fill=fill)


def down(img, w, h):
    return img.resize((w, h), Image.BOX)


def flower(img, cx, cy, r, petal, center=(255, 224, 120, 255)):
    for k in range(5):
        a = k * 2 * math.pi / 5 - math.pi / 2
        ell(img, cx + math.cos(a) * r * 0.62, cy + math.sin(a) * r * 0.62, r * 0.5, r * 0.5, petal)
    ell(img, cx, cy, r * 0.28, r * 0.28, center)


def torii(img, cx, cy, w, h, col):
    line_h(img, cx - w / 2, cx + w / 2, cy - h / 2, h * 0.2, col)                       # top beam
    line_h(img, cx - w * 0.38, cx + w * 0.38, cy - h / 2 + h * 0.36, h * 0.14, col)     # lower beam
    for sx in (-1, 1):                                                                     # posts
        px = cx + sx * w * 0.27
        d = ImageDraw.Draw(img)
        d.rectangle([(px - w * 0.06) * S, (cy - h / 2 + h * 0.2) * S, (px + w * 0.06) * S, (cy + h / 2) * S], fill=col)


# ------------------------------------------------------------------------------------------------ the keyboard top
def kb_layout(style):
    """Keys as (x0, y0, x1, y1, kind) in the pixels of the 156 x 60 top picture."""
    X0, Y0, W, H = 4.5, 4.5, 147.0, 51.0
    cols, rows = 14, 5
    pw, ph, gap = W / cols, H / rows, 1.35
    keys = []

    def key(c0, c1, r, kind):
        keys.append((X0 + c0 * pw + gap / 2, Y0 + r * ph + gap / 2, X0 + c1 * pw - gap / 2, Y0 + (r + 1) * ph - gap / 2, kind))

    sak = style == "sakura"
    def sp(kind, plain="key"):
        return kind if sak else plain

    key(0, 1, 0, sp("hana", "mod"))
    for c in range(1, 13): key(c, c + 1, 0, "key")
    key(13, 14, 0, sp("torii", "mod"))
    key(0, 1, 1, sp("koi", "mod"))
    for c in range(1, 14): key(c, c + 1, 1, "key")
    key(0, 1, 2, sp("pagoda", "mod"))
    for c in range(1, 12): key(c, c + 1, 2, "key")
    key(12, 14, 2, sp("koi_wide", "mod"))
    key(0, 2, 3, sp("matsuri", "mod"))
    for c in range(2, 12): key(c, c + 1, 3, "key")
    key(12, 14, 3, sp("metro", "mod"))
    key(0, 1, 4, sp("pink", "mod")); key(1, 2, 4, sp("pink_flower", "mod")); key(2, 3, 4, sp("pink", "mod"))
    key(3, 11, 4, sp("space", "space"))
    key(11, 12, 4, sp("pink", "mod")); key(12, 13, 4, sp("pink_flower", "mod")); key(13, 14, 4, sp("pink", "mod"))
    return keys


def glow_at(x, t, sat=0.95, val=1.0, width=156.0):
    return hsv(x / width * 1.0 - t, sat, val)


def draw_kb_top(style, t):
    W, H = 156, 60
    sak, white = style == "sakura", style == "white_rgb"
    if style == "black_rgb":
        frame, frame2, plate = (34, 34, 44, 255), (66, 66, 84, 255), (12, 12, 18, 255)
        cap, cap_hi, cap_lo, mod, leg = (40, 40, 54, 255), (74, 74, 94, 255), (22, 22, 30, 255), (30, 30, 42, 255), None
    elif white:
        frame, frame2, plate = (226, 226, 238, 255), (250, 250, 255, 255), (186, 186, 206, 255)
        cap, cap_hi, cap_lo, mod, leg = (252, 252, 255, 255), (255, 255, 255, 255), (204, 204, 224, 255), (238, 238, 248, 255), (96, 96, 120, 255)
    else:
        frame, frame2, plate = (244, 168, 198, 255), (252, 206, 224, 255), (255, 226, 238, 255)
        cap, cap_hi, cap_lo, mod, leg = (254, 250, 251, 255), (255, 255, 255, 255), (238, 206, 222, 255), (248, 178, 202, 255), (86, 182, 194, 255)
    img = canvas(W, H, frame)
    rr(img, (0.4, 0.4, W - 0.4, H - 0.4), 2.6, frame2, outline=mix(frame, (0, 0, 0, 255), 0.35), width=0.8)
    rr(img, (2.2, 2.2, W - 2.2, H - 2.2), 1.8, plate)

    # glow line around the frame (RGB wave); the sakura one has a soft pastel one
    for x in range(1, W - 1):
        col = hsv(x / W - t, 0.55 if sak else 0.95, 1.0, 150 if sak else 230)
        over(img, (x, 0.9, x + 1, 1.7), 0, col)
        over(img, (x, H - 1.7, x + 1, H - 0.9), 0, col)
    for y in range(1, H - 1):
        over(img, (0.9, y, 1.7, y + 1), 0, hsv(0.0 - t, 0.55 if sak else 0.95, 1.0, 150 if sak else 230))
        over(img, (W - 1.7, y, W - 0.9, y + 1), 0, hsv(1.0 - t - 0.0, 0.55 if sak else 0.95, 1.0, 150 if sak else 230))

    keys = kb_layout(style)
    # under-glow: the light that comes out between the keys
    for (x0, y0, x1, y1, kind) in keys:
        col = glow_at((x0 + x1) / 2, t, 0.5 if sak else (0.5 if white else 0.95), 1.0)
        over(img, (x0 - 2.3, y0 - 2.3, x1 + 2.3, y1 + 2.3), 3, col[:3] + (70 if (sak or white) else 85,))
    for (x0, y0, x1, y1, kind) in keys:
        col = glow_at((x0 + x1) / 2, t, 0.55 if sak else (0.6 if white else 0.97), 1.0)
        over(img, (x0 - 1.15, y0 - 1.15, x1 + 1.15, y1 + 1.15), 2.4, col[:3] + (205,))

    for (x0, y0, x1, y1, kind) in keys:
        cx = (x0 + x1) / 2
        base = mod if kind in ("mod",) else cap
        if sak and kind in ("pink", "pink_flower", "hana"):
            base = (248, 168, 196, 255)
        if sak and kind == "matsuri":
            base = (96, 196, 208, 255)
        lo = mix(base, (0, 0, 0, 255), 0.13 if not style == "black_rgb" else 0.45)
        rr(img, (x0, y0 + 0.7, x1, y1 + 0.2), 1.3, lo)             # the lower edge of the cap
        rr(img, (x0, y0, x1, y1 - 0.5), 1.3, base)
        hi = mix(base, (255, 255, 255, 255), 0.45 if style != "black_rgb" else 0.22)
        line_h(img, x0 + 1.0, x1 - 1.0, y0 + 0.25, 0.45, hi)       # the light on the top edge

        mid = (y0 + y1) / 2 - 0.3
        if kind == "key":
            if style == "black_rgb":
                lc = glow_at(cx, t, 0.55, 1.0)
                over(img, (cx - 1.5, mid - 0.7, cx + 1.5, mid + 0.7), 0.6, lc[:3] + (235,))
            elif white:
                over(img, (cx - 1.4, mid - 0.7, cx + 1.4, mid + 0.7), 0.6, leg[:3] + (200,))
            else:
                lc = (230, 110, 156, 255) if int(cx / 10.5) % 2 else (86, 182, 194, 255)
                over(img, (cx - 1.4, mid - 0.7, cx + 1.4, mid + 0.7), 0.6, lc[:3] + (215,))
        elif kind == "mod" and style == "black_rgb":
            lc = glow_at(cx, t, 0.55, 1.0)
            over(img, (cx - 1.0, mid - 0.5, cx + 1.0, mid + 0.5), 0.5, lc[:3] + (200,))
        elif kind == "mod" and white:
            over(img, (cx - 1.0, mid - 0.5, cx + 1.0, mid + 0.5), 0.5, leg[:3] + (170,))
        elif kind == "space" and style == "black_rgb":
            lc = glow_at(cx, t, 0.6, 1.0)
            over(img, (cx - 12, mid - 0.5, cx + 12, mid + 0.5), 0.5, lc[:3] + (190,))
        elif kind == "space" and white:
            over(img, (cx - 12, mid - 0.5, cx + 12, mid + 0.5), 0.5, leg[:3] + (150,))
        elif sak:
            draw_sakura_key(img, kind, x0, y0, x1, y1, t)
    return down(img, W, H)


def draw_sakura_key(img, kind, x0, y0, x1, y1, t):
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2 - 0.3
    red, pink, white = (226, 70, 96, 255), (244, 150, 184, 255), (255, 255, 255, 255)
    if kind == "hana":                                  # the "sakura" key: red with a white flower
        rr(img, (x0, y0, x1, y1 - 0.5), 1.3, (232, 84, 118, 255))
        flower(img, cx, cy, 3.3, white, (255, 214, 120, 255))
    elif kind == "torii":
        torii(img, cx, cy, 8.2, 6.4, red)
    elif kind == "koi":
        ell(img, cx - 0.6, cy, 3.3, 1.9, white)
        ell(img, cx - 1.2, cy - 0.5, 1.7, 1.0, red)
        poly(img, [(cx + 2.4, cy), (cx + 4.4, cy - 1.7), (cx + 4.4, cy + 1.7)], red)
        ell(img, cx - 2.6, cy - 0.3, 0.45, 0.45, (40, 40, 60, 255))
    elif kind == "koi_wide":
        wave = (150, 214, 226, 255)
        for k in range(4):
            line_h(img, x0 + 1.5 + k * 3.2, x0 + 3.6 + k * 3.2, y1 - 2.3, 0.5, wave)
        ell(img, cx - 1.0, cy - 0.2, 4.6, 2.1, white)
        ell(img, cx - 2.4, cy - 0.7, 2.3, 1.1, red)
        poly(img, [(cx + 3.3, cy - 0.2), (cx + 6.4, cy - 2.2), (cx + 6.4, cy + 1.9)], red)
        ell(img, cx - 4.0, cy - 0.5, 0.5, 0.5, (40, 40, 60, 255))
    elif kind == "pagoda":
        for k, (w, yy) in enumerate(((6.4, 2.2), (5.0, 0.4), (3.6, -1.4))):
            poly(img, [(cx - w / 2 - 0.8, cy + yy + 1.0), (cx + w / 2 + 0.8, cy + yy + 1.0), (cx + w / 2, cy + yy - 0.4), (cx - w / 2, cy + yy - 0.4)], red)
        line_h(img, cx - 1.9, cx + 1.9, cy - 0.8, 0.5, (150, 70, 80, 255))
    elif kind == "matsuri":                             # the teal key with the festival sign
        for k in range(3):
            line_h(img, cx - 5 + k * 3.6, cx - 3.2 + k * 3.6, cy - 1.8, 1.9, white)
            line_h(img, cx - 5.2 + k * 3.6, cx - 2.8 + k * 3.6, cy + 0.9, 0.6, white)
        ell(img, cx, cy + 2.2, 0.5, 0.5, white)
    elif kind == "metro":
        rr(img, (x0, y0, x1, y1 - 0.5), 1.3, (250, 160, 190, 255))
        ell(img, x0 + 4.2, cy, 2.2, 2.2, white)
        for dx, dy in ((-0.9, -0.9), (0.9, -0.9), (-1.35, 0.1), (1.35, 0.1)):
            ell(img, x0 + 4.2 + dx, cy + dy - 0.2, 0.42, 0.42, (240, 110, 150, 255))
        ell(img, x0 + 4.2, cy + 0.7, 0.9, 0.7, (240, 110, 150, 255))
        for k in range(3):
            line_h(img, x0 + 8.0 + k * 3.0, x0 + 9.8 + k * 3.0, cy - 0.5, 1.0, (255, 240, 246, 255))
        poly(img, [(x1 - 4.5, cy - 1.8), (x1 - 1.6, cy), (x1 - 4.5, cy + 1.8)], (255, 244, 248, 255))
    elif kind == "pink":
        ell(img, cx, cy, 1.2, 1.2, (255, 240, 246, 255))
    elif kind == "pink_flower":
        flower(img, cx, cy, 3.0, (255, 244, 248, 255), (250, 170, 196, 255))
    elif kind == "space":                               # Mount Fuji, the sun, a torii and a sakura branch
        w, h = x1 - x0, y1 - y0
        for k in range(8):                              # the sky
            line_h(img, x0 + 0.3, x1 - 0.3, y0 + 0.3 + k * (h - 1.2) / 8, (h - 1.2) / 8 + 0.1,
                   mix((255, 250, 250, 255), (252, 222, 232, 255), k / 7))
        sx = x0 + w * 0.56
        ell(img, sx - 9.0, y0 + 2.6, 2.0, 2.0, (232, 58, 58, 255))                                        # the sun
        poly(img, [(sx - 17, y1 - 1.0), (sx, y0 + 1.5), (sx + 17, y1 - 1.0)], (44, 104, 156, 255))        # Fuji
        poly(img, [(sx - 4.4, y0 + 4.2), (sx, y0 + 1.5), (sx + 4.4, y0 + 4.2), (sx + 2.2, y0 + 3.6), (sx, y0 + 4.5), (sx - 2.2, y0 + 3.6)], white)
        poly(img, [(sx - 17, y1 - 1.0), (sx - 8, y0 + 5.8), (sx - 3, y1 - 1.0)], (66, 128, 178, 255))
        line_h(img, x0 + 0.3, x1 - 0.3, y1 - 1.5, 0.9, (214, 232, 240, 255))                              # the mist / the water
        torii(img, x1 - 9.0, y1 - 3.9, 7.0, 5.6, red)
        for px, py in ((x0 + 5, y0 + 2.2), (x0 + 8.6, y0 + 1.4), (x0 + 11.6, y0 + 3.2), (x1 - 6, y0 + 2.0)):  # petals
            ell(img, px, py, 0.9, 0.9, pink)
        flower(img, x0 + 5.6, y1 - 3.3, 2.3, pink, (255, 220, 120, 255))


def draw_kb_front(style, t):
    W, H = 156, 11
    if style == "black_rgb": a, b = (60, 60, 78, 255), (20, 20, 28, 255)
    elif style == "white_rgb": a, b = (252, 252, 255, 255), (206, 206, 224, 255)
    else: a, b = (252, 206, 224, 255), (240, 150, 186, 255)
    img = canvas(W, H, a)
    for y in range(H):
        line_h(img, 0, W, y, 1, mix(a, b, y / (H - 1)))
    for x in range(W):                                   # the light line of the RGB
        col = hsv(x / W - t, 0.55 if style == "sakura" else 0.95, 1.0, 235)
        over(img, (x, 4.2, x + 1, 6.2), 0, col)
        over(img, (x, 3.2, x + 1, 7.2), 0, col[:3] + (70,))
    if style == "sakura":
        for px in (12, 31, 58, 77, 104, 128, 143):
            ell(img, px, 8.3, 0.9, 0.9, (255, 244, 248, 255))
    return down(img, W, H)


# ------------------------------------------------------------------------------------------------ the mouse
def draw_ms_top(style, t):
    W, H = 24, 34
    sak, white = style == "sakura", style == "white_rgb"
    if style == "black_rgb":
        edge, body, body2, line = (56, 56, 74, 255), (36, 36, 48, 255), (24, 24, 34, 255), (14, 14, 20, 255)
    elif white:
        edge, body, body2, line = (214, 214, 232, 255), (252, 252, 255, 255), (230, 230, 244, 255), (176, 176, 200, 255)
    else:
        edge, body, body2, line = (244, 160, 192, 255), (255, 246, 249, 255), (252, 214, 230, 255), (226, 150, 182, 255)
    img = canvas(W, H, edge)
    rr(img, (0.5, 0.5, W - 0.5, H - 0.5), 8.5, edge)
    for y in range(2, 33):                                   # the glowing rim, a wave that runs down
        col = hsv(y / H - t, 0.5 if sak else 0.95, 1.0, 190 if sak else 235)
        over(img, (0.9, y, 1.9, y + 1), 0, col)
        over(img, (W - 1.9, y, W - 0.9, y + 1), 0, col)
    for x in range(4, 20):
        col = hsv(x / W - t, 0.5 if sak else 0.95, 1.0, 190 if sak else 235)
        over(img, (x, 0.9, x + 1, 1.9), 0, col)
        over(img, (x, H - 1.9, x + 1, H - 0.9), 0, col)
    rr(img, (2.2, 2.2, W - 2.2, H - 2.2), 7.0, body)
    for k in range(14):                                       # the palm is a little darker at the bottom
        over(img, (2.4, 19 + k, W - 2.4, 20 + k), 0, body2[:3] + (round(110 * k / 13),))
    line_h(img, 3, W - 3, 15.5, 0.6, line)                    # the buttons
    line_h(img, W / 2 - 0.3, W / 2 + 0.3, 2.5, 13, line)
    # the wheel
    wc = hsv(0.0 - t + 0.3, 0.55 if sak else 0.95, 1.0)
    rr(img, (W / 2 - 2.2, 5.2, W / 2 + 2.2, 12.8), 2.1, (30, 30, 40, 255) if style == "black_rgb" else (150, 150, 175, 255))
    rr(img, (W / 2 - 1.4, 5.9, W / 2 + 1.4, 12.1), 1.4, wc)
    if sak:                                                    # a sakura flower and petals
        flower(img, W / 2, 24.5, 4.6, (248, 150, 186, 255), (255, 220, 120, 255))
        for px, py in ((5.5, 21), (18, 28.5), (6.5, 29), (17.5, 20.5)):
            ell(img, px, py, 1.0, 1.0, (248, 176, 202, 255))
    else:
        lc = hsv(0.5 - t, 0.9, 1.0)                           # the logo: a little glowing arrow
        poly(img, [(W / 2 - 3, 21.5), (W / 2 + 3, 21.5), (W / 2, 27.5)], lc)
        if style == "black_rgb":
            poly(img, [(W / 2 - 1.5, 22.3), (W / 2 + 1.5, 22.3), (W / 2, 25)], (20, 20, 28, 255))
        else:
            poly(img, [(W / 2 - 1.5, 22.3), (W / 2 + 1.5, 22.3), (W / 2, 25)], (255, 255, 255, 255))
    return down(img, W, H)


def draw_ms_front(style, t):
    W, H = 29, 11
    if style == "black_rgb": a, b = (60, 60, 78, 255), (20, 20, 28, 255)
    elif style == "white_rgb": a, b = (252, 252, 255, 255), (206, 206, 224, 255)
    else: a, b = (252, 206, 224, 255), (240, 150, 186, 255)
    img = canvas(W, H, a)
    for y in range(H):
        line_h(img, 0, W, y, 1, mix(a, b, y / (H - 1)))
    for x in range(W):
        col = hsv(x / W - t, 0.55 if style == "sakura" else 0.95, 1.0, 235)
        over(img, (x, 4.2, x + 1, 6.2), 0, col)
        over(img, (x, 3.2, x + 1, 7.2), 0, col[:3] + (70,))
    return down(img, W, H)


# ------------------------------------------------------------------------------------------------ atlases
SWATCH = {   # the one-pixel colours at the top-left of the atlas: [pixels 0-1: shade, 3-4: light side, 6-7: dark, 9-10: cable]
    "black_rgb": [(46, 46, 60, 255), (62, 62, 80, 255), (20, 20, 28, 255), (34, 34, 46, 255)],
    "white_rgb": [(222, 222, 238, 255), (250, 250, 255, 255), (150, 150, 176, 255), (120, 120, 148, 255)],
    "sakura": [(240, 172, 200, 255), (252, 214, 230, 255), (214, 110, 150, 255), (150, 90, 120, 255)],
}
BASE = {"kb": {"black_rgb": "pc_keyboard_black", "white_rgb": "pc_keyboard", "sakura": "pc_keyboard_pink"},
        "ms": {"black_rgb": "pc_mouse_black", "white_rgb": "pc_mouse", "sakura": "pc_mouse_pink"}}


def build_atlas(kind, style):
    frame = KB_FRAME if kind == "kb" else MS_FRAME
    base = Image.open(f"{TEX}/{BASE[kind][style]}.png").convert("RGBA").crop((0, 0, frame[0], frame[1]))
    sw = SWATCH[style]
    px = base.load()
    for i, c in enumerate(sw):
        for x in (i * 3, i * 3 + 1):
            for y in (0, 1):
                px[x, y] = c
    strip = Image.new("RGBA", (frame[0], frame[1] * FRAMES), (0, 0, 0, 0))
    for f in range(FRAMES):
        t = f / FRAMES
        im = base.copy()
        if kind == "kb":
            im.paste(draw_kb_top(style, t), KB_TOP[:2])
            im.paste(draw_kb_front(style, t), KB_FRONT[:2])
        else:
            im.paste(draw_ms_top(style, t), MS_TOP[:2])
            im.paste(draw_ms_front(style, t), MS_FRONT[:2])
        strip.paste(im, (0, f * frame[1]))
    name = f"pc_{kind}_{style}"
    strip.save(f"{TEX}/{name}.png")
    json.dump({"animation": {"frametime": FRAMETIME, "interpolate": True, "width": frame[0], "height": frame[1]}},
              open(f"{TEX}/{name}.png.mcmeta", "w"), indent=1)
    return name


# ------------------------------------------------------------------------------------------------ models
def jload(path): return json.load(open(path))
def jsave(path, d): json.dump(d, open(path, "w"), indent=1)


def remap(src_model, tex_name, frame):
    """The model with the same boxes, but its pictures cut out of the small atlas (the old UV is in 1024 px units)."""
    m = copy.deepcopy(jload(src_model))
    su, sv = 1024.0 / frame[0], 1024.0 / frame[1]
    key = [k for k in m["textures"] if k != "particle"][0]
    for e in m["elements"]:
        for face in e["faces"].values():
            u0, v0, u1, v1 = face["uv"]
            face["uv"] = [round(u0 * su, 4), round(v0 * sv, 4), round(u1 * su, 4), round(v1 * sv, 4)]
    m["textures"] = {"particle": f"cutemod:block/{tex_name}", key: f"cutemod:block/{tex_name}"}
    m["texture_size"] = list(frame)
    return m


def child(parent, key, tex):
    return {"parent": parent, "textures": {"particle": tex, key: tex}}



def round_mouse(path):
    """The mouse was two plain boxes (square). It becomes three stacked layers with cut corners (a rounder, mouse-like shape).
    Works on the white parent models (their pictures are in 1024 px units); the other styles are cut out of them. Safe to run again."""
    m = jload(path)
    els = m["elements"]
    if any(e["name"].startswith("r_") for e in els):
        return
    body = next(e for e in els if e["name"].endswith("body"))
    hump = next(e for e in els if e["name"].endswith("hump"))
    cable = next(e for e in els if e["name"].endswith("cable"))
    key = body["faces"]["south"]["texture"]
    strip, swatch, bottom, top = body["faces"]["south"]["uv"], body["faces"]["north"]["uv"], body["faces"]["down"]["uv"], hump["faces"]["up"]["uv"]
    bx0, _, bz0 = body["from"]; bx1, bh, bz1 = body["to"]
    hx0, _, hz0 = hump["from"]; hx1, hy, hz1 = hump["to"]
    w = bx1 - bx0
    ya, yb = round(hy * 0.45, 3), round(hy * 0.75, 3)
    layers = [  # (footprint x0, z0, x1, z1, chamfer, y0, y1, textured top)
        (bx0, bz0, bx1, bz1, 0.15 * w, 0.0, ya, False),
        (bx0 + 0.06 * w, bz0 + 0.06 * w, bx1 - 0.06 * w, bz1 - 0.06 * w, 0.17 * w, ya, yb, False),
        (hx0 + 0.04 * w, hz0 + 0.04 * w, hx1 - 0.04 * w, hz1 - 0.04 * w, 0.19 * w, yb, hy, True),
    ]
    tx0, tz0, tx1, tz1 = layers[2][:4]

    def top_uv(x0, z0, x1, z1, textured):
        if not textured:
            return list(swatch)
        u0, v0, u1, v1 = top
        f = lambda a, lo, hi, p0, p1: p0 + (a - lo) / (hi - lo) * (p1 - p0)
        return [round(f(x0, tx0, tx1, u0, u1), 4), round(f(z0, tz0, tz1, v0, v1), 4), round(f(x1, tx0, tx1, u0, u1), 4), round(f(z1, tz0, tz1, v0, v1), 4)]

    out = []
    for i, (x0, z0, x1, z1, c, y0, y1, tex) in enumerate(layers):
        boxes = [("mid", x0 + c, z0, x1 - c, z1), ("left", x0, z0 + c, x0 + c, z1 - c), ("right", x1 - c, z0 + c, x1, z1 - c)]
        for nm, a0, c0, a1, c1 in boxes:
            faces = {"north": {"uv": strip, "texture": key}, "south": {"uv": strip, "texture": key},
                     "up": {"uv": top_uv(a0, c0, a1, c1, tex), "texture": key}}
            if nm != "mid":
                faces["west" if nm == "left" else "east"] = {"uv": strip, "texture": key}
            else:
                faces["west"] = {"uv": strip, "texture": key} if False else None
            if nm == "left": faces["east"] = None
            if nm == "right": faces["west"] = faces.get("west")
            if i == 0: faces["down"] = {"uv": bottom, "texture": key}
            faces = {k: v for k, v in faces.items() if v}
            # the sides of the middle box that touch the two strips are inside the shape: only its front and back are kept
            out.append({"name": f"r_{i}_{nm}", "from": [round(a0, 4), y0, round(c0, 4)], "to": [round(a1, 4), y1, round(c1, 4)], "faces": faces})
    m["elements"] = out + [cable]
    jsave(path, m)


def main():
    round_mouse(f"{MOD}/pc_monitor_mouse.json")
    round_mouse(f"{MOD}/pc_mouse.json")
    # ---- 1) the animated atlases of the three special styles
    atlas = {}
    for kind in ("kb", "ms"):
        for s in SPECIAL:
            atlas[(kind, s)] = build_atlas(kind, s)

    # ---- 2) models: the part in front of the monitor, the item picture
    kb_part_src = f"{MOD}/pc_monitor_keyboard.json"
    ms_part_src = f"{MOD}/pc_monitor_mouse.json"
    kb_solo_src, ms_solo_src = f"{MOD}/pc_keyboard.json", f"{MOD}/pc_mouse.json"
    for s in SPECIAL:
        jsave(f"{MOD}/pc_monitor_keyboard_{s}.json", remap(kb_part_src, atlas[("kb", s)], KB_FRAME))
        jsave(f"{MOD}/pc_monitor_mouse_{s}.json", remap(ms_part_src, atlas[("ms", s)], MS_FRAME))
        jsave(f"{MOD}/pc_keyboard_{s}.json", remap(kb_solo_src, atlas[("kb", s)], KB_FRAME))
        jsave(f"{MOD}/pc_mouse_{s}.json", remap(ms_solo_src, atlas[("ms", s)], MS_FRAME))
    for c in PLAIN:
        if c == "white":
            continue
        jsave(f"{MOD}/pc_keyboard_{c}.json", child("cutemod:block/pc_keyboard", "t", f"cutemod:block/pc_keyboard_{c}"))
        jsave(f"{MOD}/pc_mouse_{c}.json", child("cutemod:block/pc_mouse", "t", f"cutemod:block/pc_mouse_{c}"))
    for what in ("keyboard", "mouse"):
        base = jload(f"{ITM}/pc_{what}.json")
        for s in STYLES:
            if s == "white":
                continue
            d = copy.deepcopy(base)
            d["parent"] = f"cutemod:block/pc_{what}_{s}"
            jsave(f"{ITM}/pc_{what}_{s}.json", d)

    # ---- 3) the monitor blockstate: the parts follow kb_style / ms_style, NOT the colour of the monitor
    path = f"{RES}/blockstates/pc_monitor.json"
    bs = jload(path)
    mp = [p for p in bs["multipart"] if "keyboard" not in p["when"] and "mouse" not in p["when"]]
    for facing, y in FACINGS:
        for s in STYLES:
            sfx = "" if s == "white" else f"_{s}"
            mp.append({"when": {"facing": facing, "keyboard": "true", "kb_style": s},
                       "apply": {"model": f"cutemod:block/pc_monitor_keyboard{sfx}", "y": y}})
            mp.append({"when": {"facing": facing, "mouse": "true", "ms_style": s},
                       "apply": {"model": f"cutemod:block/pc_monitor_mouse{sfx}", "y": y}})
    bs["multipart"] = mp
    jsave(path, bs)

    # ---- 4) recipes and tags
    os.makedirs(f"{DATA}/recipe", exist_ok=True)
    os.makedirs(f"{DATA}/tags/item", exist_ok=True)
    for what, tag in (("keyboard", "pc_keyboards"), ("mouse", "pc_mice")):
        jsave(f"{DATA}/tags/item/{tag}.json", {"values": [f"cutemod:pc_{what}" if c == "white" else f"cutemod:pc_{what}_{c}" for c in PLAIN]})
        for c in PLAIN:
            res = f"cutemod:pc_{what}" if c == "white" else f"cutemod:pc_{what}_{c}"
            jsave(f"{DATA}/recipe/pc_{what}_{c}_dye.json", {
                "type": "minecraft:crafting_shapeless", "category": "misc",
                "ingredients": [{"tag": f"cutemod:{tag}"}, {"item": f"minecraft:{DYE[c]}"}],
                "result": {"id": res, "count": 1}})
        extra = {"black_rgb": [f"cutemod:pc_{what}_black"], "white_rgb": [f"cutemod:pc_{what}"],
                 "sakura": [f"cutemod:pc_{what}_pink", "minecraft:pink_petals"]}
        for s, ings in extra.items():
            jsave(f"{DATA}/recipe/pc_{what}_{s}.json", {
                "type": "minecraft:crafting_shapeless", "category": "misc",
                "ingredients": [{"item": i} for i in ings] + [{"item": "minecraft:glowstone_dust"}, {"item": "minecraft:amethyst_shard"}],
                "result": {"id": f"cutemod:pc_{what}_{s}", "count": 1}})

    # ---- 5) lang
    for code in ("en_us", "ru_ru"):
        lines = {}
        for what, en_word, ru_word in (("keyboard", "Keyboard", "клавиатура"), ("mouse", "Mouse", "мышь")):
            for c in PLAIN:
                if c == "white":
                    continue
                lines[f"item.cutemod.pc_{what}_{c}"] = f"{EN[c]} {en_word}" if code == "en_us" else f"{RU_F[c]} {ru_word}"
            for s in SPECIAL:
                lines[f"item.cutemod.pc_{what}_{s}"] = NAMES[code][what][s]
        add_lang(code, lines)
    print("ok")


def add_lang(code, lines):
    path = f"{RES}/lang/{code}.json"
    text = open(path, encoding="utf-8").read()
    data = json.loads(text)
    lines = {k: v for k, v in lines.items() if k not in data}
    if lines:
        body = ",\n".join(f"  {json.dumps(k)}: {json.dumps(v, ensure_ascii=False)}" for k, v in lines.items())
        idx = text.rstrip().rfind("\n}")
        text = text[:idx] + ",\n" + body + text[idx:]
    json.loads(text)
    open(path, "w", encoding="utf-8").write(text)


if __name__ == "__main__":
    main()
