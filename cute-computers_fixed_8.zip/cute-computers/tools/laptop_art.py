"""Small painting toolkit shared by tools/make_neo_laptop.py and tools/make_laptops.py.

Everything is painted on a canvas that is SS times bigger than the texture and shrunk with a smooth filter at the end, so edges,
rounded corners, glows and soft gradients come out clean. All coordinates are given in FINAL texture pixels (floats are fine).
"""
import colorsys, math, random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops

SS = 4
WHITE, BLACK = (255, 255, 255), (0, 0, 0)


def rgb(h): return ((h >> 16) & 255, (h >> 8) & 255, h & 255)
def mix(a, b, t): return tuple(int(round(a[i] * (1 - t) + b[i] * t)) for i in range(3))
def hsv(h, s=1.0, v=1.0): return tuple(int(c * 255) for c in colorsys.hsv_to_rgb(h % 1.0, s, v))
def rgba(c, a=255): return (int(c[0]), int(c[1]), int(c[2]), int(a))


def heart_pts(cx, cy, s, n=40):
    """A heart that is about 2*s wide and 2*s high, the tip points down."""
    pts = []
    for i in range(n):
        t = 2 * math.pi * i / n
        x = 16 * math.sin(t) ** 3
        y = 13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t)
        pts.append((cx + x * s / 16.0, cy - y * s / 16.0 + s * 0.05))
    return pts


def star_pts(cx, cy, R, r, n=5, rot=-90):
    pts = []
    for i in range(n * 2):
        a = math.radians(rot + i * 180.0 / n)
        k = R if i % 2 == 0 else r
        pts.append((cx + k * math.cos(a), cy + k * math.sin(a)))
    return pts


def sparkle_pts(cx, cy, R, waist=0.22):
    """A four-pointed twinkle."""
    pts = []
    for i in range(8):
        a = math.radians(-90 + i * 45)
        k = R if i % 2 == 0 else R * waist
        pts.append((cx + k * math.cos(a), cy + k * math.sin(a)))
    return pts


class Canvas:
    def __init__(self, w, h, fill=(0, 0, 0, 0), ss=SS):
        self.w, self.h, self.ss = w, h, ss
        f = tuple(fill) if len(fill) == 4 else tuple(fill) + (255,)
        self.im = Image.new('RGBA', (w * ss, h * ss), f)
        self.d = ImageDraw.Draw(self.im)

    def copy(self):
        c = Canvas.__new__(Canvas)
        c.w, c.h, c.ss = self.w, self.h, self.ss
        c.im = self.im.copy(); c.d = ImageDraw.Draw(c.im)
        return c

    # ------------------------------------------------------------------------------------------ primitives
    def _s(self, v): return v * self.ss

    def _paint(self, bbox, fn, color):
        """fn(draw, dx, dy, fill) draws one shape; the shape is blended with the colour's alpha."""
        ss = self.ss
        x0 = max(0, int(math.floor(bbox[0] * ss)) - 2); y0 = max(0, int(math.floor(bbox[1] * ss)) - 2)
        x1 = min(self.im.width, int(math.ceil(bbox[2] * ss)) + 3); y1 = min(self.im.height, int(math.ceil(bbox[3] * ss)) + 3)
        if x1 <= x0 or y1 <= y0: return
        col = rgba(color) if len(color) == 3 else tuple(int(v) for v in color)
        if col[3] >= 255:
            fn(self.d, 0, 0, col)
            return
        m = Image.new('L', (x1 - x0, y1 - y0), 0)
        fn(ImageDraw.Draw(m), -x0, -y0, 255)
        if col[3] < 255: m = m.point(lambda v, a=col[3] / 255.0: int(v * a))
        layer = Image.new('RGBA', m.size, col[:3] + (0,)); layer.putalpha(m)
        self.im.alpha_composite(layer, (x0, y0))

    def rect(self, x0, y0, x1, y1, fill):
        ss = self.ss
        self._paint((x0, y0, x1, y1), lambda d, dx, dy, c: d.rectangle((x0 * ss + dx, y0 * ss + dy, x1 * ss - 1 + dx, y1 * ss - 1 + dy), fill=c), fill)

    def rrect(self, x0, y0, x1, y1, r, fill, outline=None, width=1):
        ss = self.ss
        def fn(d, dx, dy, c):
            d.rounded_rectangle((x0 * ss + dx, y0 * ss + dy, x1 * ss - 1 + dx, y1 * ss - 1 + dy), radius=r * ss, fill=c)
        if fill is not None: self._paint((x0, y0, x1, y1), fn, fill)
        if outline is not None:
            def fo(d, dx, dy, c):
                d.rounded_rectangle((x0 * ss + dx, y0 * ss + dy, x1 * ss - 1 + dx, y1 * ss - 1 + dy), radius=r * ss, outline=c, width=max(1, int(width * ss)))
            self._paint((x0, y0, x1, y1), fo, outline)

    def ell(self, x0, y0, x1, y1, fill, outline=None, width=1):
        ss = self.ss
        if fill is not None:
            self._paint((x0, y0, x1, y1), lambda d, dx, dy, c: d.ellipse((x0 * ss + dx, y0 * ss + dy, x1 * ss - 1 + dx, y1 * ss - 1 + dy), fill=c), fill)
        if outline is not None:
            self._paint((x0, y0, x1, y1), lambda d, dx, dy, c: d.ellipse((x0 * ss + dx, y0 * ss + dy, x1 * ss - 1 + dx, y1 * ss - 1 + dy), outline=c, width=max(1, int(width * ss))), outline)

    def circle(self, cx, cy, r, fill, outline=None, width=1): self.ell(cx - r, cy - r, cx + r, cy + r, fill, outline, width)

    def line(self, pts, fill, width=1.0):
        ss = self.ss
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        pad = width + 1
        self._paint((min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad),
                    lambda d, dx, dy, c: d.line([(p[0] * ss + dx, p[1] * ss + dy) for p in pts], fill=c, width=max(1, int(width * ss)), joint='curve'), fill)

    def poly(self, pts, fill):
        ss = self.ss
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        self._paint((min(xs), min(ys), max(xs), max(ys)), lambda d, dx, dy, c: d.polygon([(p[0] * ss + dx, p[1] * ss + dy) for p in pts], fill=c), fill)

    def arc(self, box, a0, a1, fill, width=1.0):
        ss = self.ss
        self._paint(box, lambda d, dx, dy, c: d.arc((box[0] * ss + dx, box[1] * ss + dy, box[2] * ss - 1 + dx, box[3] * ss - 1 + dy), a0, a1, fill=c, width=max(1, int(width * ss))), fill)

    # ------------------------------------------------------------------------------------------ gradients and masks
    def mask(self):
        m = Image.new('L', self.im.size, 0)
        return m, ImageDraw.Draw(m)

    def rr_mask(self, x0, y0, x1, y1, r):
        m, d = self.mask()
        ss = self.ss
        d.rounded_rectangle((x0 * ss, y0 * ss, x1 * ss - 1, y1 * ss - 1), radius=r * ss, fill=255)
        return m

    def fill_mask(self, m, color):
        col = rgba(color) if len(color) == 3 else tuple(color)
        if col[3] < 255: m = m.point(lambda v, a=col[3] / 255.0: int(v * a))
        layer = Image.new('RGBA', self.im.size, col[:3] + (0,)); layer.putalpha(m)
        self.im.alpha_composite(layer)

    def gradient(self, x0, y0, x1, y1, fn, r=0, alpha=255):
        """fn(u, v) -> (R, G, B) arrays for u, v in 0..1 over the box; r rounds its corners."""
        ss = self.ss
        X0, Y0, X1, Y1 = int(x0 * ss), int(y0 * ss), int(x1 * ss), int(y1 * ss)
        w, h = X1 - X0, Y1 - Y0
        u = (np.arange(w)[None, :] + 0.5) / w * np.ones((h, 1)); v = (np.arange(h)[:, None] + 0.5) / h * np.ones((1, w))
        c = np.stack(fn(u, v), axis=-1)
        img = Image.fromarray(np.clip(c, 0, 255).astype(np.uint8), 'RGB').convert('RGBA')
        m = Image.new('L', (w, h), alpha)
        if r > 0:
            m = Image.new('L', (w, h), 0)
            ImageDraw.Draw(m).rounded_rectangle((0, 0, w - 1, h - 1), radius=r * ss, fill=alpha)
        img.putalpha(m)
        self.im.alpha_composite(img, (X0, Y0))

    def vgrad(self, x0, y0, x1, y1, c0, c1, r=0, alpha=255, power=1.0):
        a, b = np.array(c0, float), np.array(c1, float)
        self.gradient(x0, y0, x1, y1, lambda u, v: tuple(a[i] + (b[i] - a[i]) * v ** power for i in range(3)), r, alpha)

    def hgrad(self, x0, y0, x1, y1, c0, c1, r=0, alpha=255):
        a, b = np.array(c0, float), np.array(c1, float)
        self.gradient(x0, y0, x1, y1, lambda u, v: tuple(a[i] + (b[i] - a[i]) * u for i in range(3)), r, alpha)

    def dgrad(self, x0, y0, x1, y1, c0, c1, r=0, alpha=255):
        """Diagonal, c0 in the top left corner and c1 in the bottom right one."""
        a, b = np.array(c0, float), np.array(c1, float)
        self.gradient(x0, y0, x1, y1, lambda u, v: tuple(a[i] + (b[i] - a[i]) * (u * 0.5 + v * 0.5) for i in range(3)), r, alpha)

    # ------------------------------------------------------------------------------------------ effects
    def bloom(self, layer, radius, strength=1.0, crisp=True):
        """Adds a blurred copy of `layer` (a Canvas with the glowing things on transparent) on top, then the sharp layer itself
        (crisp=False: only the soft glow, the layer itself is not drawn)."""
        ss = self.ss
        base = np.asarray(self.im, np.float32)
        lay = layer.im
        blur = np.asarray(lay.filter(ImageFilter.GaussianBlur(radius * ss)), np.float32)
        add = blur[..., :3] * (blur[..., 3:4] / 255.0) * strength
        base[..., :3] = np.clip(base[..., :3] + add, 0, 255)
        base[..., 3] = np.maximum(base[..., 3], np.clip(blur[..., 3] * strength, 0, 255))
        self.im = Image.fromarray(base.astype(np.uint8), 'RGBA')
        if crisp: self.im.alpha_composite(lay)
        self.d = ImageDraw.Draw(self.im)

    def emboss(self, m, depth=0.8, light=0.55, dark=0.4):
        """Makes the shape of mask `m` look pressed into / raised from the surface (light from the top left)."""
        ss = self.ss
        k = int(depth * ss)
        sh1 = ImageChops.offset(m, k, k); sh2 = ImageChops.offset(m, -k, -k)
        hi = ImageChops.subtract(m, sh1)          # the top left rim of the shape
        lo = ImageChops.subtract(m, sh2)          # the bottom right rim
        self.fill_mask(hi, rgba(WHITE, int(255 * light)))
        self.fill_mask(lo, rgba(BLACK, int(255 * dark)))

    def paste(self, other, x, y, mask=None):
        self.im.alpha_composite(other.im if mask is None else other.im, (int(x * self.ss), int(y * self.ss)))

    def clip_to(self, m):
        """Keep only what is inside mask `m`."""
        a = ImageChops.multiply(self.im.getchannel('A'), m)
        self.im.putalpha(a)

    # ------------------------------------------------------------------------------------------ output
    def finish(self, grain=0.0, seed=1, brushed=0.0):
        im = self.im.resize((self.w, self.h), Image.LANCZOS)
        if grain or brushed:
            rnd = np.random.RandomState(seed)
            a = np.asarray(im, np.float32)
            n = rnd.normal(0, 1, (self.h, self.w, 1)) * grain * 255
            if brushed:
                n = n + rnd.normal(0, 1, (self.h, 1, 1)) * brushed * 255 * np.ones((1, self.w, 1))
            m = (a[..., 3:4] > 0)
            a[..., :3] = np.clip(a[..., :3] + n * m, 0, 255)
            im = Image.fromarray(a.astype(np.uint8), 'RGBA')
        return im


# ---------------------------------------------------------------------------------------------- tiny 3x5 pixel font (key legends, HUD numbers)
GLYPHS = {
    '0': ('111', '101', '101', '101', '111'), '1': ('010', '110', '010', '010', '111'), '2': ('111', '001', '111', '100', '111'),
    '3': ('111', '001', '111', '001', '111'), '4': ('101', '101', '111', '001', '001'), '5': ('111', '100', '111', '001', '111'),
    '6': ('111', '100', '111', '101', '111'), '7': ('111', '001', '010', '010', '010'), '8': ('111', '101', '111', '101', '111'),
    '9': ('111', '101', '111', '001', '111'),
    'A': ('010', '101', '111', '101', '101'), 'B': ('110', '101', '110', '101', '110'), 'C': ('011', '100', '100', '100', '011'),
    'D': ('110', '101', '101', '101', '110'), 'E': ('111', '100', '110', '100', '111'), 'F': ('111', '100', '110', '100', '100'),
    'G': ('011', '100', '101', '101', '011'), 'H': ('101', '101', '111', '101', '101'), 'I': ('111', '010', '010', '010', '111'),
    'J': ('001', '001', '001', '101', '010'), 'K': ('101', '101', '110', '101', '101'), 'L': ('100', '100', '100', '100', '111'),
    'M': ('101', '111', '111', '101', '101'), 'N': ('110', '101', '101', '101', '101'), 'O': ('010', '101', '101', '101', '010'),
    'P': ('110', '101', '110', '100', '100'), 'Q': ('010', '101', '101', '111', '011'), 'R': ('110', '101', '110', '101', '101'),
    'S': ('011', '100', '010', '001', '110'), 'T': ('111', '010', '010', '010', '010'), 'U': ('101', '101', '101', '101', '111'),
    'V': ('101', '101', '101', '101', '010'), 'W': ('101', '101', '111', '111', '101'), 'X': ('101', '101', '010', '101', '101'),
    'Y': ('101', '101', '010', '010', '010'), 'Z': ('111', '001', '010', '100', '111'),
    '+': ('000', '010', '111', '010', '000'), '-': ('000', '000', '111', '000', '000'), '*': ('101', '010', '111', '010', '101'),
    '/': ('001', '001', '010', '100', '100'), '.': ('000', '000', '000', '000', '010'), ':': ('000', '010', '000', '010', '000'),
    ',': ('000', '000', '000', '010', '100'), ';': ('000', '010', '000', '010', '100'), '=': ('000', '111', '000', '111', '000'),
    '[': ('110', '100', '100', '100', '110'), ']': ('011', '001', '001', '001', '011'), "'": ('010', '010', '000', '000', '000'),
    '`': ('100', '010', '000', '000', '000'), '\\': ('100', '100', '010', '001', '001'), '%': ('101', '001', '010', '100', '101'),
}


def text_width(s, px=1.0, gap=0.8): return sum((3 + gap) * px for _ in s) - gap * px


def text(cv, x, y, s, color, px=1.0, gap=0.8):
    """Draws a string in the 3x5 pixel font (px = the size of one font pixel in texture pixels); returns the x after it."""
    for ch in s:
        g = GLYPHS.get(ch.upper())
        if g is not None:
            for ry, row in enumerate(g):
                for rx, bit in enumerate(row):
                    if bit == '1': cv.rect(x + rx * px, y + ry * px, x + (rx + 1) * px, y + (ry + 1) * px, color)
        x += (3 + gap) * px
    return x


digits = text


# ---------------------------------------------------------------------------------------------- small shared drawings
def cat_head(cv, cx, cy, r, fill, ear=0.9):
    """A round cat head with two ears (just the silhouette)."""
    cv.circle(cx, cy, r, fill)
    for sx in (-1, 1):
        cv.poly([(cx + sx * r * 0.95, cy - r * 0.15), (cx + sx * r * 0.88, cy - r * (0.9 + ear * 0.55)), (cx + sx * r * 0.25, cy - r * 0.9)], fill)


def cloud(cv, x, y, s, color):
    """A soft cloud made of circles (s = its width); the circles are merged first, so a see-through cloud has no seams."""
    m, d = cv.mask()
    ss = cv.ss
    def e(x0, y0, x1, y1, r=None):
        if r is None: d.ellipse((x0 * ss, y0 * ss, x1 * ss, y1 * ss), fill=255)
        else: d.rounded_rectangle((x0 * ss, y0 * ss, x1 * ss, y1 * ss), radius=r * ss, fill=255)
    e(x, y + s * 0.22, x + s, y + s * 0.46, s * 0.12)
    for cx, cy, r in ((0.32, 0.26, 0.17), (0.55, 0.2, 0.22), (0.76, 0.28, 0.14)):
        e(x + s * (cx - r), y + s * (cy - r), x + s * (cx + r), y + s * (cy + r))
    cv.fill_mask(m, color if len(color) == 4 else rgba(color))


def hills(cv, x0, x1, base, amp, freq, phase, bottom, fill, rim=None, rim_w=0.8, step=1.0):
    """A rolling hill silhouette from x0 to x1 down to `bottom`; the ridge gets a thin light rim when `rim` is given."""
    pts = []
    x = x0
    while x <= x1 + 1e-6:
        t = (x - x0) / max(1.0, (x1 - x0))
        pts.append((x, base - amp * (0.6 * math.sin(freq * t * math.pi * 2 + phase) + 0.4 * math.sin(freq * 2.3 * t * math.pi * 2 + phase * 1.7))))
        x += step
    cv.poly(pts + [(x1, bottom), (x0, bottom)], fill)
    if rim is not None: cv.line(pts, rim, rim_w)
    return pts


def rrect_path(x0, y0, x1, y1, r, step=1.2):
    """Points going round a rounded rectangle (clockwise from the top left), about `step` pixels apart."""
    pts = []
    def seg(a, b):
        n = max(1, int(math.dist(a, b) / step))
        for i in range(n): pts.append((a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n))
    def arc(cx, cy, a0):
        n = max(2, int(r * 1.5708 / step))
        for i in range(n): t = math.radians(a0 + 90 * i / n); pts.append((cx + r * math.cos(t), cy + r * math.sin(t)))
    seg((x0 + r, y0), (x1 - r, y0)); arc(x1 - r, y0 + r, 270)
    seg((x1, y0 + r), (x1, y1 - r)); arc(x1 - r, y1 - r, 0)
    seg((x1 - r, y1), (x0 + r, y1)); arc(x0 + r, y1 - r, 90)
    seg((x0, y1 - r), (x0, y0 + r)); arc(x0 + r, y0 + r, 180)
    return pts


def rainbow_path(cv, pts, phase, width=1.0, sat=1.0, val=1.0, loops=1.0, alpha=255):
    """Draws a closed path with a rainbow running round it."""
    n = len(pts)
    for i in range(n):
        c = hsv(phase + loops * i / n, sat, val)
        cv.line([pts[i], pts[(i + 1) % n]], rgba(c, alpha), width)
