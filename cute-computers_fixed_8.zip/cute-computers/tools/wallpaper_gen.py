import numpy as np, math, random
from PIL import Image, ImageDraw, ImageFilter
W,H=1392,824
random.seed(11)
def lerp(a,b,t): return tuple(int(a[i]+(b[i]-a[i])*t) for i in range(3))
# sky/water gradient
g=np.zeros((H,W,3),np.float32)
stops=[(0,(252,246,214)),(0.38,(204,232,236)),(0.7,(172,208,238)),(1,(150,184,226))]
for y in range(H):
    t=y/H
    for i in range(len(stops)-1):
        if stops[i][0]<=t<=stops[i+1][0]:
            u=(t-stops[i][0])/(stops[i+1][0]-stops[i][0]); c=lerp(stops[i][1],stops[i+1][1],u); break
    g[y,:]=c
im=Image.fromarray(g.astype(np.uint8),'RGB').convert('RGBA')
def layer(): return Image.new('RGBA',(W,H),(0,0,0,0))
def comp(l,blur=0):
    global im
    if blur: l=l.filter(ImageFilter.GaussianBlur(blur))
    im=Image.alpha_composite(im,l)

# big glass arch (ring) behind
l=layer(); d=ImageDraw.Draw(l)
d.ellipse([360,-380,1500,760],outline=(236,214,226,200),width=46)
d.ellipse([410,-330,1450,710],outline=(255,250,250,150),width=10)
d.ellipse([470,-270,1390,650],fill=(255,255,240,60))
comp(l,3)
# far fish shadows inside arch
def fish(d,cx,cy,L,ang,col,alpha=255,tailcol=None):
    t=Image.new('RGBA',(int(L*2.4),int(L*1.4)),(0,0,0,0)); td=ImageDraw.Draw(t)
    ox,oy=t.width/2,t.height/2
    td.ellipse([ox-L/2,oy-L*0.22,ox+L/2,oy+L*0.22],fill=col+(alpha,))
    td.polygon([(ox-L*0.42,oy),(ox-L*0.74,oy-L*0.22),(ox-L*0.66,oy),(ox-L*0.74,oy+L*0.22)],fill=(tailcol or col)+(alpha,))
    td.polygon([(ox-L*0.08,oy-L*0.2),(ox+L*0.06,oy-L*0.33),(ox+L*0.2,oy-L*0.19)],fill=(tailcol or col)+(alpha,))
    td.ellipse([ox+L*0.3,oy-L*0.07,ox+L*0.38,oy+L*0.01],fill=(255,255,255,min(alpha,230)))
    body=Image.new('L',t.size,0); ImageDraw.Draw(body).ellipse([ox-L/2,oy-L*0.22,ox+L/2,oy+L*0.22],fill=255)
    bel=Image.new('L',t.size,0); ImageDraw.Draw(bel).ellipse([ox-L*0.5,oy+L*0.02,ox+L*0.5,oy+L*0.5],fill=255)
    from PIL import ImageChops
    bm=ImageChops.multiply(body,bel).point(lambda v:int(v*0.35*alpha/255))
    t.paste(Image.new('RGBA',t.size,(255,255,255,255)),(0,0),bm)
    stripe=Image.new('L',t.size,0); ImageDraw.Draw(stripe).ellipse([ox-L*0.4,oy-L*0.2,ox+L*0.4,oy-L*0.02],fill=255)
    sm=ImageChops.multiply(body,stripe).point(lambda v:int(v*0.12*alpha/255))
    t.paste(Image.new('RGBA',t.size,(0,0,0,255)),(0,0),sm)
    t=t.rotate(ang,resample=Image.BICUBIC,expand=False)
    im.alpha_composite(t,(int(cx-t.width/2),int(cy-t.height/2))) if 0<=cx-t.width/2 and cx+t.width/2<=W and 0<=cy-t.height/2 and cy+t.height/2<=H else im.paste(t,(int(cx-t.width/2),int(cy-t.height/2)),t)

# light rays
l=layer(); d=ImageDraw.Draw(l)
for x0,wd,a in [(120,160,46),(380,110,36),(640,190,40),(960,120,30)]:
    d.polygon([(x0,0),(x0+wd,0),(x0+wd+420,H),(x0+120,H)],fill=(255,255,245,a))
comp(l,18)
# distant school of fish
for i in range(26):
    x=random.uniform(420,1250); y=random.uniform(120,470)
    fish(ImageDraw.Draw(layer()),x,y,random.uniform(34,64),random.uniform(-25,20)+ (180 if random.random()<0.0 else 0),
         random.choice([(110,156,200),(96,142,190),(132,176,214),(84,130,176)]),150)
# pillars
l=layer(); d=ImageDraw.Draw(l)
for x0,x1 in [(0,150),(1250,1392)]:
    for i in range(x1-x0):
        t=i/(x1-x0); c=lerp((176,140,168),(222,196,214),abs(t-0.35)*1.4)
        d.line([(x0+i,0),(x0+i,H)],fill=c+(255,))
comp(l,1.2)
# pillar left second (smaller, further)
l=layer(); d=ImageDraw.Draw(l)
d.rounded_rectangle([210,60,290,H],20,fill=(214,196,226,150)); d.rounded_rectangle([1130,90,1190,H],18,fill=(206,190,224,130))
comp(l,3)
# walkway & railing
l=layer(); d=ImageDraw.Draw(l)
d.polygon([(0,610),(W,570),(W,H),(0,H)],fill=(212,214,240,255))
d.polygon([(0,640),(W,600),(W,624),(0,664)],fill=(240,240,252,255))
for x in range(160,1300,70):
    d.rectangle([x,520+ (x*-0.03),x+10,640+(x*-0.03)],fill=(200,206,232,255))
d.line([(150,516),(1300,478)],fill=(226,228,248,255),width=14)
d.line([(150,536),(1300,498)],fill=(196,200,230,255),width=6)
comp(l,1.5)
# foreground big fish
fish(None,360,700,300,-12,(96,126,170),255,(80,108,150))
fish(None,1170,620,220,12,(244,142,112),255,(255,190,150))
# fish in mid
for (x,y,L,a,c) in [(640,300,110,8,(118,170,212)),(520,420,90,-18,(104,152,200)),(900,260,100,18,(120,176,214)),(780,470,80,6,(96,144,196)),(1010,380,84,-10,(124,168,208))]:
    fish(None,x,y,L,a,c,235)
# bubbles
l=layer(); d=ImageDraw.Draw(l)
for _ in range(34):
    r=random.choice([8,10,12,16,22,30,44]); x=random.uniform(60,W-60); y=random.uniform(40,H-120)
    d.ellipse([x-r,y-r,x+r,y+r],fill=(255,255,255,40),outline=(255,255,255,190),width=max(2,r//8))
    d.ellipse([x-r*0.55,y-r*0.6,x-r*0.15,y-r*0.2],fill=(255,255,255,200))
    d.arc([x-r*0.8,y-r*0.8,x+r*0.8,y+r*0.8],20,100,fill=(255,190,230,150),width=max(2,r//9))
    d.arc([x-r*0.8,y-r*0.8,x+r*0.8,y+r*0.8],200,280,fill=(170,230,255,150),width=max(2,r//9))
comp(l,0.8)
# sparkles
l=layer(); d=ImageDraw.Draw(l)
for x,y,s in [(250,170,46),(470,110,30),(1190,310,40),(900,150,26),(150,330,26),(1060,520,30)]:
    d.polygon([(x,y-s),(x+s*0.12,y-s*0.12),(x+s,y),(x+s*0.12,y+s*0.12),(x,y+s),(x-s*0.12,y+s*0.12),(x-s,y),(x-s*0.12,y-s*0.12)],fill=(255,255,255,235))
comp(l,1.2)
# paper grain / watercolour softness
a=np.array(im.convert('RGB')).astype(np.float32)
n=np.random.default_rng(3).normal(0,1,(H,W)).astype(np.float32)
from scipy import ndimage as ndi
n=ndi.gaussian_filter(n,1.4)*5
a+=n[...,None]
Image.fromarray(np.clip(a,0,255).astype(np.uint8),'RGB').save('wallpaper_aquarium.png')
