"""Generates the OFFICE and GAMING laptops (textures, block models, blockstates, item models, loot tables).
Run from the project root: python3 tools/make_laptops.py

  office  - thicker plain body, a full keyboard with a numpad, a fingerprint reader, lots of ports; black / white / silver
  gaming  - THIN body, an RGB keyboard whose light rolls like a wave, RGB light strips round the body (under-glow and the rear vent), a blue anime-sky wallpaper (our own painting) and a glowing cat-eared hexagon on the lid; black / white
            (the RGB textures are animated: 16 frames + .mcmeta; the lit faces also get neoforge_data light so they glow in the dark)

(The slim Neo laptops, the medium ones, are made by tools/make_neo_laptop.py.) Our own look: no brand names or logos.
Every model uses small textures with uv 0..16, so each texture has the aspect of its face.
"""
import json, math, os, random, sys
from PIL import Image, ImageDraw

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from laptop_art import *   # noqa
from make_neo_laptop import keycap, box, face, faces_all, with_   # noqa

ASSETS = 'src/main/resources/assets/cutemod/'
TEX = ASSETS + 'textures/block/'
MOD = ASSETS + 'models/block/'
ITEM = ASSETS + 'models/item/'
STATE = ASSETS + 'blockstates/'
LOOT = 'src/main/resources/data/cutemod/loot_table/blocks/'
FRAMES = 16

OFFICE = {
    'office_black':  dict(body=0x2B2D33, key=0x3B3E48, legend=0xDADCE2, bed=0x14151A, accent=0xA582FF),
    'office_white':  dict(body=0xE8EAEE, key=0xFBFBFD, legend=0x4A4D57, bed=0xB4B9C3, accent=0x4DA3FF),
    'office_silver': dict(body=0xB9BEC7, key=0xDFE2E8, legend=0x3C3F48, bed=0x868C97, accent=0x4DA3FF),
}
GAMING = {
    'gaming_black': dict(body=0x1B1C22, key=0x23252D, bed=0x07080B, white=False),
    'gaming_white': dict(body=0xECEEF2, key=0xFAFBFD, bed=0x484C59, white=True),
}


def save_anim(img_list, name, w, h, frametime=2):
    sheet = Image.new('RGBA', (w, h * len(img_list)))
    for i, im in enumerate(img_list): sheet.paste(im, (0, h * i))
    sheet.save(TEX + name + '.png')
    json.dump({'animation': {'frametime': frametime, 'interpolate': True, 'width': w, 'height': h}}, open(TEX + name + '.png.mcmeta', 'w'), indent=1)


def clear_anim(name):
    p = TEX + name + '.png.mcmeta'
    if os.path.exists(p): os.remove(p)


# ----------------------------------------------------------------------------------------------- a full keyboard (main block + numpad)
MAIN = [
    [1.5] + [1] * 12 + [1.5],
    [1] * 13 + [2],
    [1.5] + [1] * 12 + [1.5],
    [1.75] + [1] * 11 + [2.25],
    [2.25] + [1] * 10 + [2.75],
    [1.25, 1.25, 1.25, 6.25, 1.25, 1.25, 1.25, 1.25],
]
PAD = [[1, 1, 1, 1]] * 6
LET = {1: '`1234567890-=', 2: '\tQWERTYUIOP[]\\', 3: '\tASDFGHJKL;\'', 4: '\tZXCVBNM,./'}


def keys_layout(mx0, mx1, px0, px1, y0, y1, gap=1.05):
    """Returns the keys of a full keyboard: dicts with x0,y0,x1,y1, `ch` (the legend), `kind` and `wasd`."""
    from make_neo_laptop import layout
    main = layout(mx0, mx1, y0, y1, gap, 0.62, MAIN)
    pad = layout(px0, px1, y0, y1, gap, 0.62, PAD)
    out = []
    for row in main:
        for k in row:
            ch = None
            if k['units'] == 1 and k['row'] in LET: ch = LET[k['row']][k['col']]
            k['ch'] = ch; k['kind'] = 'main'; out.append(k)
    padch = [['', '', '', ''], ['N', '/', '*', '-'], ['7', '8', '9', '+'], ['4', '5', '6', ''], ['1', '2', '3', ''], ['0', '', '.', '']]
    for ri, row in enumerate(pad):
        for k in row:
            k['ch'] = padch[ri][k['col']] or None; k['kind'] = 'pad'
            out.append(k)
    # the tall keys of the numpad: + (rows 2-3) and enter (rows 4-5), and the wide 0
    byrc = {(k['row'], k['col']): k for k in out if k['kind'] == 'pad'}
    byrc[(2, 3)]['y1'] = byrc[(3, 3)]['y1']; byrc[(2, 3)]['ch'] = '+'; out.remove(byrc[(3, 3)])
    byrc[(4, 3)]['y1'] = byrc[(5, 3)]['y1']; byrc[(4, 3)]['ch'] = None; out.remove(byrc[(5, 3)])
    byrc[(5, 0)]['x1'] = byrc[(5, 1)]['x1']; byrc[(5, 0)]['ch'] = '0'; out.remove(byrc[(5, 1)])
    for k in out:
        k['wasd'] = k['kind'] == 'main' and k['ch'] in ('W', 'A', 'S', 'D')
    return out


def legend_at(cv, k, ch, color, px=0.78, dy=-0.4):
    cx, cy = (k['x0'] + k['x1']) / 2, (k['y0'] + k['y1']) / 2 + dy
    text(cv, cx - 1.5 * px, cy - 2.5 * px, ch, color, px)


# =============================================================================================== OFFICE
def office_body(v):
    cv = Canvas(16, 16)
    b = rgb(v['body'])
    cv.vgrad(0, 0, 16, 16, mix(b, WHITE, .12), mix(b, BLACK, .14))
    return cv.finish(grain=0.006, seed=2)


def office_deck(v):
    W, H = 184, 130
    b, key, leg, bed, acc = rgb(v['body']), rgb(v['key']), rgb(v['legend']), rgb(v['bed']), rgb(v['accent'])
    dark = v['body'] == 0x2B2D33
    cv = Canvas(W, H)
    cv.dgrad(0, 0, W, H, mix(b, WHITE, .10), mix(b, BLACK, .12))
    cv.poly([(120, 0), (160, 0), (84, H), (44, H)], rgba(WHITE, 8 if dark else 16))
    cv.rrect(7.4, 4.4, W - 7.4, 70.6, 3.4, rgba(mix(b, WHITE, .35), 150))
    cv.rrect(8, 5, W - 8, 70, 3, rgba(bed))
    keys = keys_layout(11, 134, 137.5, 171.5, 7.6, 66.6)
    edge = mix(bed, BLACK, .3) if dark else mix(bed, BLACK, .35)
    for k in keys:
        face_c = key
        if k['kind'] == 'main' and k['units'] > 1: face_c = mix(key, b, .35 if not dark else .0) if not dark else mix(key, BLACK, .15)
        if k['row'] == 0 and k['kind'] == 'main': pass
        if k['kind'] == 'pad' and k['col'] == 3 and k['ch'] is None: face_c = mix(key, acc, .55)     # the numpad enter
        keycap(cv, k['x0'], k['y0'], k['x1'], k['y1'], face_c, edge, 1.15)
        if k['ch']: legend_at(cv, k, k['ch'], rgba(leg, 225), 0.72)
        elif k['row'] == 0:
            cx, cy = (k['x0'] + k['x1']) / 2, (k['y0'] + k['y1']) / 2 - 0.25
            cv.circle(cx, cy, 0.7, rgba(leg, 190))
        elif k['units'] > 1 and k['kind'] == 'main':
            cv.line([(k['x0'] + 2, (k['y0'] + k['y1']) / 2 - 0.3), (k['x0'] + 2 + min(3.5, k['units'] * 1.6), (k['y0'] + k['y1']) / 2 - 0.3)], rgba(leg, 190), 0.6)
    # the palm rest: speaker grill, trackpad with two buttons, a fingerprint reader
    for i in range(7): cv.rrect(13 + i * 3.0, 90, 14.2 + i * 3.0, 112, 0.5, rgba(mix(b, BLACK, .45 if not dark else .7)))
    cv.rrect(68, 79, 116, 121, 3.5, rgba(mix(b, BLACK, .3)))
    cv.vgrad(68.6, 79.6, 115.4, 111, mix(b, WHITE, .10), mix(b, BLACK, .05), r=3.0)
    cv.rect(68.6, 111, 115.4, 111.6, rgba(mix(b, BLACK, .35)))
    cv.rect(91.8, 111.4, 92.2, 120.4, rgba(mix(b, BLACK, .35)))
    cv.rrect(68.6, 111.4, 115.4, 120.4, 2.6, rgba(mix(b, WHITE, .06 if dark else .14)))
    cv.rect(91.8, 111.4, 92.2, 120.4, rgba(mix(b, BLACK, .4)))
    cv.rrect(150, 92, 166, 108, 3, rgba(mix(b, BLACK, .3)))                                   # the fingerprint reader
    cv.rrect(150.6, 92.6, 165.4, 107.4, 2.6, rgba(mix(b, WHITE, .08)))
    for r_ in (2, 3.6, 5.2): cv.arc((158 - r_, 100 - r_, 158 + r_, 100 + r_), 195, 345, rgba(mix(b, BLACK, .5), 200), 0.5)
    cv.circle(158, 100, 0.6, rgba(acc, 230))
    cv.circle(156.5, 85, 0.8, rgba((90, 230, 140), 220)); cv.circle(160.5, 85, 0.8, rgba(acc, 220))             # two status lights
    cv.line([(6, H - 2.4), (W - 6, H - 2.4)], rgba(WHITE, 60 if dark else 120), 0.7)
    return cv.finish(grain=0.010, seed=21, brushed=0.005)


def office_desktop(v, w, h):
    acc = rgb(v['accent'])
    cv = Canvas(w, h)
    cv.vgrad(0, 0, w, h * .66, rgb(0x2F7FDB), rgb(0xBFE6FF))
    sun = Canvas(w, h); sun.circle(w * .78, h * .26, 7, rgba(WHITE, 220)); cv.bloom(sun, 6, .7)
    cloud(cv, w * .08, h * .10, w * .30, rgba(WHITE, 235)); cloud(cv, w * .50, h * .19, w * .26, rgba(WHITE, 225)); cloud(cv, w * .76, h * .06, w * .2, rgba(WHITE, 215))
    hills(cv, 0, w, h * .66, h * .06, 1.0, 1.4, h, rgba(rgb(0x7FD06F)), rgba(rgb(0xC9F5A8), 200), 0.7)
    hills(cv, 0, w, h * .76, h * .07, 0.8, 3.4, h, rgba(rgb(0x4DB04A)), rgba(rgb(0xA6EA86), 210), 0.8)
    hills(cv, 0, w, h * .88, h * .05, 1.1, 0.2, h, rgba(rgb(0x2E8E3C)), rgba(rgb(0x8AD672), 200), 0.7)
    cv.poly([(w * .58, h * .78), (w * .66, h * .78), (w * .78, h), (w * .50, h)], rgba(rgb(0xE8D8A0), 110))       # a path
    for i, (fx, fy) in enumerate(((w * .16, h * .80), (w * .32, h * .84), (w * .88, h * .82), (w * .70, h * .9))):   # flowers
        c = rgb((0xFFE066, 0xFF8AB8, 0xFFFFFF, 0xFFB066)[i])
        cv.circle(fx, fy, 0.9, rgba(c)); cv.circle(fx, fy, 0.35, rgba((255, 200, 60)))
    for bx, by in ((w * .60, h * .13), (w * .64, h * .10)): cv.line([(bx - 1.6, by - .7), (bx, by + .4), (bx + 1.6, by - .7)], rgba((40, 50, 80), 220), 0.5)
    # desktop icons: folder, document, bin
    ics = [(0xFFD35C, 'folder'), (0xFFFFFF, 'doc'), (0xB9C4D8, 'bin')]
    for i, (c, kind) in enumerate(ics):
        ix, iy = 4, 5 + i * 14
        if kind == 'folder':
            cv.rrect(ix, iy + 1.2, ix + 8.5, iy + 7.6, 1.0, rgba(rgb(0xF0B53A))); cv.rrect(ix, iy, ix + 4.2, iy + 2.0, 0.8, rgba(rgb(0xF0B53A)))
            cv.rrect(ix, iy + 2.4, ix + 8.5, iy + 7.6, 1.0, rgba(rgb(c))); cv.line([(ix + .8, iy + 2.7), (ix + 7.7, iy + 2.7)], rgba(WHITE, 200), 0.4)
        elif kind == 'doc':
            cv.poly([(ix + 1.2, iy), (ix + 6.2, iy), (ix + 8, iy + 1.8), (ix + 8, iy + 7.8), (ix + 1.2, iy + 7.8)], rgba(WHITE))
            cv.poly([(ix + 6.2, iy), (ix + 6.2, iy + 1.8), (ix + 8, iy + 1.8)], rgba(rgb(0xC9D3E6)))
            for j in range(3): cv.line([(ix + 2.4, iy + 3 + j * 1.6), (ix + 6.6, iy + 3 + j * 1.6)], rgba(rgb(0x8AA0C8)), 0.45)
        else:
            cv.poly([(ix + 1.2, iy + 2.2), (ix + 7.3, iy + 2.2), (ix + 6.6, iy + 7.8), (ix + 1.9, iy + 7.8)], rgba(rgb(c)))
            cv.rect(ix + .6, iy + 1.2, ix + 7.9, iy + 2.2, rgba(rgb(0x9AA6BC))); cv.rect(ix + 3, iy + .4, ix + 5.5, iy + 1.2, rgba(rgb(0x9AA6BC)))
        cv.rrect(ix - .4, iy + 8.8, ix + 8.9, iy + 10.2, 0.6, rgba(WHITE, 210))
    # a little file-manager window
    wx0, wy0, wx1, wy1 = 36, 7, w - 7, h - 21
    cv.rrect(wx0 + 1, wy0 + 1.3, wx1 + 1, wy1 + 1.3, 2.6, rgba(BLACK, 70))
    cv.rrect(wx0, wy0, wx1, wy1, 2.4, rgba(rgb(0xF6F8FC)))
    cv.rrect(wx0, wy0, wx1, wy0 + 6.4, 2.4, rgba(mix(acc, BLACK, .05))); cv.rect(wx0, wy0 + 4, wx1, wy0 + 6.4, rgba(mix(acc, BLACK, .05)))
    cv.rect(wx0, wy0 + 6.4, wx1, wy0 + 7.0, rgba(mix(acc, BLACK, .3), 180))
    text(cv, wx0 + 3, wy0 + 0.7, 'FILES', rgba(WHITE, 250), 0.9)
    for j, c in enumerate((0x5CD67A, 0xFFD35C, 0xFF6B6B)): cv.circle(wx1 - 4 - j * 4.2, wy0 + 3.2, 1.25, rgba(rgb(c)))
    cv.rect(wx0, wy0 + 7, wx0 + 17, wy1, rgba(rgb(0xE4E9F3)))
    for j in range(5):
        cv.circle(wx0 + 4, wy0 + 12 + j * 5.2, 1.0, rgba(mix(acc, WHITE, .1 * j)))
        cv.rrect(wx0 + 7, wy0 + 11.2 + j * 5.2, wx0 + 7 + 6 + (j * 3) % 5, wy0 + 12.8 + j * 5.2, 0.5, rgba(rgb(0x7C88A8)))
    gx0 = wx0 + 21
    for r_ in range(2):
        for c_ in range(4):
            x = gx0 + c_ * 9.6; y = wy0 + 11 + r_ * 12.5
            if x + 8 > wx1 - 2: continue
            col = ((0xFFD35C), (0x8AB4FF), (0xFF9EC0), (0x8EE0A8), (0xC9A8FF), (0xFFB36B), (0x7CE0E0), (0xFF8A8A))[r_ * 4 + c_]
            cv.rrect(x, y + 1, x + 7.4, y + 6.8, 1.0, rgba(rgb(col))); cv.rrect(x, y, x + 3.6, y + 1.8, .6, rgba(mix(rgb(col), BLACK, .1)))
            cv.rrect(x, y + 8, x + 7.4, y + 9, 0.4, rgba(rgb(0x9AA6BC)))
    # the task bar
    cv.vgrad(0, h - 7, w, h, rgb(0x2A3552), rgb(0x161C2E)); cv.rect(0, h - 7, w, h - 6.4, rgba(WHITE, 60))
    cv.rrect(1.4, h - 6.1, 12, h - 1.0, 2.0, rgba(mix(acc, BLACK, .05)))
    for dx, dy in ((0, 0), (1.7, 0), (0, 1.7), (1.7, 1.7)): cv.rect(4.3 + dx, h - 5.0 + dy, 5.7 + dx, h - 3.7 + dy, rgba(WHITE, 240))
    for j, c in enumerate((0xFFD35C, 0x8AB4FF, 0xFF9EC0)):
        x = 15 + j * 13
        cv.rrect(x, h - 6.1, x + 11, h - 1.0, 1.4, rgba(WHITE, 40 if j else 70), rgba(WHITE, 70 if j == 0 else 0), 0.4)
        cv.rrect(x + 1.2, h - 5, x + 4.4, h - 2.2, 0.8, rgba(rgb(c)))
        cv.rrect(x + 5.4, h - 4.1, x + 9.4, h - 3.2, 0.4, rgba(WHITE, 190))
    cv.circle(w - 28, h - 3.5, 0.55, rgba(WHITE, 240))
    for r_ in (1.5, 2.5): cv.arc((w - 28 - r_, h - 3.5 - r_, w - 28 + r_, h - 3.5 + r_), 225, 315, rgba(WHITE, 240), 0.5)
    text(cv, w - 22, h - 5.6, '12:00', rgba(WHITE, 240), 0.8, 0.9)
    return cv


def office_screen(v):
    W, H = 184, 120
    b = rgb(v['body'])
    cv = Canvas(W, H, rgba(b))
    cv.rrect(0, 0, W, H, 3.0, rgba((20, 21, 26)))
    cv.vgrad(0, 0, W, H, (30, 31, 38), (14, 15, 19), r=3.0)
    cv.rrect(0.5, 0.5, W - 0.5, H - 0.5, 2.7, None, rgba((80, 84, 100), 80), 0.5)
    x0, y0, x1, y1 = 9, 9.5, W - 9, H - 13
    sw, sh = int(x1 - x0), int(y1 - y0)
    sc = office_desktop(v, sw, sh)
    mask = Image.new('L', (sw * SS, sh * SS), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, sw * SS - 1, sh * SS - 1), radius=int(1.4 * SS), fill=255)
    cv.rrect(x0 - 0.8, y0 - 0.8, x0 + sw + 0.8, y0 + sh + 0.8, 1.8, rgba((6, 6, 8)))
    cv.im.paste(sc.im, (int(x0 * SS), int(y0 * SS)), mask)
    cv.circle(W / 2, 4.4, 1.2, rgba((24, 26, 40)), rgba((78, 84, 120)), 0.4); cv.circle(W / 2 - 0.25, 4.1, 0.4, rgba((120, 150, 255), 220))
    led = Canvas(W, H); led.circle(W / 2 + 5.5, 4.4, 0.5, rgba((90, 255, 150))); cv.bloom(led, 1.2, .8)
    cv.circle(W / 2, H - 6.5, 2.3, None, rgba((90, 94, 110), 200), 0.5); cv.circle(W / 2, H - 6.5, 0.6, rgba((90, 94, 110), 200))    # a round mark on the chin
    text(cv, 10, H - 8.2, 'OFFICE', rgba((92, 96, 112), 220), 0.9)
    cv.poly([(110, 0), (150, 0), (96, H), (56, H)], rgba(WHITE, 10))
    return cv.finish(grain=0.003, seed=4)


def office_back(v):
    W, H = 184, 120
    b, acc = rgb(v['body']), rgb(v['accent'])
    dark = v['body'] == 0x2B2D33
    cv = Canvas(W, H)
    cv.dgrad(0, 0, W, H, mix(b, WHITE, .12), mix(b, BLACK, .14))
    cv.poly([(110, 0), (160, 0), (80, H), (30, H)], rgba(WHITE, 10 if dark else 18))
    ss = SS
    mk, d = cv.mask()
    cx, cy = W / 2, H / 2 - 2
    d.ellipse(((cx - 11) * ss, (cy - 11) * ss, (cx + 11) * ss, (cy + 11) * ss), fill=255)
    d.ellipse(((cx - 7.6) * ss, (cy - 7.6) * ss, (cx + 7.6) * ss, (cy + 7.6) * ss), fill=0)
    for sx in (-1, 1): d.polygon([((cx + sx * 4.2) * ss, (cy - 10.2) * ss), ((cx + sx * 8.6) * ss, (cy - 17) * ss), ((cx + sx * 11.4) * ss, (cy - 6) * ss)], fill=255)
    d.ellipse(((cx - 2.6) * ss, (cy - 2.6) * ss, (cx + 2.6) * ss, (cy + 2.6) * ss), fill=255)
    ink = mix(b, WHITE, .34) if dark else mix(b, BLACK, .16)
    cv.fill_mask(mk, rgba(ink))
    cv.emboss(mk, .8, .5 if dark else .7, .45 if dark else .3)
    tw = text_width('CUTE OFFICE', 1.0)
    text(cv, (W - tw) / 2, cy + 18, 'CUTE OFFICE', rgba(mix(b, WHITE, .38) if dark else mix(b, BLACK, .22), 230), 1.0)
    for sx, sy in ((7, 7), (W - 8, 7), (7, H - 8), (W - 8, H - 8)):                           # four screws
        cv.circle(sx, sy, 1.5, rgba(mix(b, BLACK, .3))); cv.circle(sx, sy, 1.1, rgba(mix(b, WHITE, .3))); cv.line([(sx - .8, sy), (sx + .8, sy)], rgba(mix(b, BLACK, .5)), 0.4)
    cv.rrect(1.2, 1.2, W - 1.2, H - 1.2, 2.8, None, rgba(WHITE, 50 if dark else 110), 0.6)
    cv.rect(W - 36, H - 12, W - 8, H - 11, rgba(acc, 200))                                   # a thin colour line
    return cv.finish(grain=0.010, seed=8, brushed=0.012)


def office_side(v, left):
    W, H = 200, 15
    b, bed = rgb(v['body']), rgb(v['bed'])
    dark = v['body'] == 0x2B2D33
    cv = Canvas(W, H)
    cv.vgrad(0, 0, W, H, mix(b, WHITE, .18), mix(b, BLACK, .2))
    port = (10, 11, 14); inner = mix(b, BLACK, .5 if dark else .45)
    def usba(x): cv.rrect(x, 4.5, x + 13, 10.8, 0.8, rgba(port)); cv.rect(x + 1.4, 7, x + 11.6, 8.4, rgba((60, 120, 220) if not dark else (70, 80, 110)))
    if left:
        cv.circle(22, 7.5, 3.3, rgba(port)); cv.circle(22, 7.5, 1.3, rgba(inner))                          # the power jack
        cv.poly([(34, 5), (49, 5), (47.5, 10.4), (35.5, 10.4)], rgba(port)); cv.line([(37, 8.4), (46, 8.4)], rgba(inner), 0.6)  # HDMI
        usba(58); usba(76)
        cv.rrect(96, 3.8, 116, 11.6, 0.8, rgba(port))                                                       # the network jack
        for i in range(7): cv.rect(98 + i * 2.6, 5.2, 99.0 + i * 2.6, 7.0, rgba((210, 170, 70)))
    else:
        cv.rrect(16, 5.4, 36, 9.6, 0.8, rgba(port)); cv.line([(18, 7.5), (34, 7.5)], rgba(inner), 0.5)    # a card reader
        usba(48)
        cv.circle(76, 7.5, 2.0, rgba(port)); cv.circle(76, 7.5, 0.9, rgba(inner))                          # the audio jack
        cv.rrect(90, 5.4, 97, 9.4, 1.8, rgba(port)); cv.circle(93.5, 7.4, .9, rgba(inner))                # a lock slot
        cv.circle(112, 7.5, 0.8, rgba((90, 230, 140), 240))
    for i in range(16): cv.rrect(132 + i * 4.0, 3.6, 133.3 + i * 4.0, 11.8, 0.5, rgba(mix(b, BLACK, .55)))
    return cv.finish(grain=0.008, seed=6)


# =============================================================================================== GAMING
def gaming_body(v):
    cv = Canvas(16, 16); b = rgb(v['body'])
    cv.vgrad(0, 0, 16, 16, mix(b, WHITE, .10 if not v['white'] else .25), mix(b, BLACK, .22))
    return cv.finish(grain=0.006, seed=12)


def gaming_hinge(v):
    cv = Canvas(16, 8); b = rgb(v['body'])
    cv.vgrad(0, 0, 16, 8, mix(b, WHITE, .2), mix(b, BLACK, .55 if not v['white'] else .3))
    cv.line([(0, 1.8), (16, 1.8)], rgba(WHITE, 90), 0.5)
    return cv.finish()


def gaming_rgb(phase):
    W, H = 64, 4
    im = Image.new('RGBA', (W, H))
    for x in range(W):
        c = hsv(phase + x / W, 0.95, 1.0)
        for y in range(H): im.putpixel((x, y), mix(c, WHITE, .35 if y in (1, 2) else 0) + (255,))
    return im


def carbon(im, strength=5):
    """A fine woven pattern for the black body."""
    a = np.asarray(im, np.float32)
    h, w = a.shape[:2]
    y, x = np.mgrid[0:h, 0:w]
    pat = (((x + y) % 4) < 2).astype(np.float32) * ((((x - y) // 2) % 2) * 2 - 1) * strength * 0.5
    a[..., :3] = np.clip(a[..., :3] + pat[..., None] * (a[..., 3:4] > 0), 0, 255)
    return Image.fromarray(a.astype(np.uint8), 'RGBA')


def gaming_deck_static(v):
    W, H = 184, 130
    b, key, bed = rgb(v['body']), rgb(v['key']), rgb(v['bed'])
    white = v['white']
    base = Canvas(W, H)
    base.dgrad(0, 0, W, H, mix(b, WHITE, .06 if not white else .10), mix(b, BLACK, .12))
    base.poly([(118, 0), (158, 0), (82, H), (42, H)], rgba(WHITE, 8 if not white else 14))
    hole = mix(b, BLACK, .75 if not white else .45)
    for gx in (9, W - 37):                                                                 # the speaker grills sit on the palm rest, so the keyboard can use the whole width
        for ri in range(7):
            for k in range(9): base.circle(gx + k * 3.1 + (1.5 if ri % 2 else 0), 86 + ri * 3.0, 0.62, rgba(hole))
    base.rrect(3.0, 4.6, W - 3.0, 72.4, 3.4, rgba(mix(b, WHITE, .25), 120))
    base.rrect(3.4, 5, W - 3.4, 72, 3, rgba(bed))
    for i in range(5):                                                                     # slanted air slats in the palm corners
        base.line([(14 + i * 4, 122), (20 + i * 4, 110)], rgba(mix(b, BLACK, .6), 220), 0.9)
        base.line([(W - 20 - i * 4, 122), (W - 14 - i * 4, 110)], rgba(mix(b, BLACK, .6), 220), 0.9)
    keys = keys_layout(6.2, 141, 144, 177.8, 8.6, 68.6)
    kcv = Canvas(W, H)
    edge = mix(bed, BLACK, .4)
    for k in keys:
        fc = key if not k['wasd'] else mix(key, (70, 200, 255), .12 if not white else .18)
        keycap(kcv, k['x0'], k['y0'], k['x1'], k['y1'], fc, edge, 1.1)
    return base, kcv, keys


def gaming_deck_frame(v, st, phase):
    base, kcv, keys = st
    W, H = base.w, base.h
    white = v['white']
    f = base.copy()
    halo = Canvas(W, H)
    for k in keys:
        c = hsv(phase + (k['x0'] + k['x1']) / 2 / W * 0.9 + k['row'] * 0.035, 0.9, 1.0)
        halo.rrect(k['x0'] - .5, k['y0'] - .4, k['x1'] + .5, k['y1'] + .6, 1.4, rgba(c, 190))
    f.bloom(halo, 1.5, 0.75 if not white else 0.45, crisp=False)
    f.im.alpha_composite(kcv.im)
    lit = Canvas(W, H)
    for k in keys:
        c = hsv(phase + (k['x0'] + k['x1']) / 2 / W * 0.9 + k['row'] * 0.035, 0.9, 1.0)
        lit.line([(k['x0'] + 1.0, k['y1'] - 0.5), (k['x1'] - 1.0, k['y1'] - 0.5)], rgba(c), 0.55)
        if k['ch']: legend_at(lit, k, k['ch'], rgba(mix(c, WHITE, .35 if not white else 0.0)), 0.72)
        elif k['kind'] == 'main' and k['row'] == 0:
            cx, cy = (k['x0'] + k['x1']) / 2, (k['y0'] + k['y1']) / 2 - 0.3
            lit.circle(cx, cy, 0.7, rgba(c))
        elif k['kind'] == 'main' and k['units'] > 1:
            lit.line([(k['x0'] + 2, (k['y0'] + k['y1']) / 2 - 0.3), (k['x0'] + 2 + min(3.5, k['units'] * 1.6), (k['y0'] + k['y1']) / 2 - 0.3)], rgba(c), 0.6)
        if k['wasd']: lit.rrect(k['x0'] + .2, k['y0'] + .2, k['x1'] - .2, k['y1'] - .4, 1.0, None, rgba((200, 245, 255), 190), 0.4)
    rainbow_path(lit, rrect_path(3.0, 4.6, W - 3.0, 72.4, 3.4), phase, 0.9, val=1.0, loops=1.5)       # the rim of the key well
    tp = (66, 80, 118, 119)
    f.rrect(tp[0], tp[1], tp[2], tp[3], 4, rgba(mix(rgb(v['body']), BLACK, .55 if not white else .35)))
    f.vgrad(tp[0] + .7, tp[1] + .7, tp[2] - .7, tp[3] - .7, mix(rgb(v['body']), BLACK, .35 if not white else .15), mix(rgb(v['body']), BLACK, .6 if not white else .3), r=3.4)
    rainbow_path(lit, rrect_path(tp[0] - 0.4, tp[1] - 0.4, tp[2] + 0.4, tp[3] + 0.4, 4.4), phase + .3, 0.8, loops=1.0)
    for i in range(0, 120, 2):                                                             # the light bar along the hinge edge
        lit.rect(24 + i * (W - 48) / 120, 0.4, 24 + (i + 2.2) * (W - 48) / 120, 1.7, rgba(hsv(phase + i / 120, 1, 1)))
    px, py = 50, 100                                                                       # the power button (left of the trackpad) and three lights (right)
    lit.circle(px, py, 3.6, None, rgba(hsv(phase, 1, 1)), 0.9); lit.line([(px, py - 4.4), (px, py - 1.4)], rgba(hsv(phase, 1, 1)), 0.9)
    for j in range(3): lit.circle(132 + j * 4.5, 100, 0.8, rgba(hsv(phase + j * .12, 1, 1)))
    f.bloom(lit, 1.3, 0.85 if not white else 0.5)
    im = f.finish(grain=0.006, seed=14)
    return carbon(im, 5) if not white else im


def sky_wallpaper(sw, sh):
    """The gaming wallpaper: a big blue sky torn into bright streaks of cloud, dark clouds on the horizon and a girl on the shore."""
    rnd = random.Random(11)
    sc = Canvas(sw, sh)
    top_l, top_r, low = np.array(rgb(0x3F86FF), float), np.array(rgb(0x14308F), float), np.array(rgb(0xBFE8FF), float)
    def sky(u, v):
        t = np.clip(v / 0.82, 0, 1)[..., None]
        top = top_l + (top_r - top_l) * np.clip(u[..., None] * 1.15 - 0.1, 0, 1)
        c = top + (low - top) * (t ** 2.6) * (1.15 - 0.55 * u[..., None])
        return np.clip(c[..., 0], 0, 255), np.clip(c[..., 1], 0, 255), np.clip(c[..., 2], 0, 255)
    sc.gradient(0, 0, sw, sh, sky)
    hz = sh * .80
    fx, fy = sw * .44, sh * .55                                                            # the sky tears open round this point
    streaks = Canvas(sw, sh)
    for i in range(110):
        ang = math.radians(rnd.triangular(-178, -4, -120))
        r0 = rnd.uniform(8, 70); ln = rnd.uniform(40, 150); wd = rnd.uniform(.5, 2.4)
        sx_, sy_ = fx + r0 * math.cos(ang), fy + r0 * math.sin(ang) * .8
        bend = rnd.uniform(-.3, .3)
        ex, ey = sx_ + ln * math.cos(ang + bend), sy_ + ln * math.sin(ang + bend) * .85
        nx, ny = -math.sin(ang), math.cos(ang)
        col = mix(rgb(0xA9D2FF), WHITE, rnd.uniform(0, .75))
        al = rnd.randint(35, 130)
        for k, f in ((1.0, 1.0), (0.55, 1.5)):                                              # a soft core inside a wider haze
            streaks.poly([(sx_ + nx * wd * f, sy_ + ny * wd * f), (ex, ey), (sx_ - nx * wd * f, sy_ - ny * wd * f)], rgba(col, int(al * (1 if k == 1.0 else .5))))
    sc.bloom(streaks, 2.2, .55)
    glint = Canvas(sw, sh)
    for i in range(90):                                                                    # tiny bright flecks scattered along the clouds
        a = math.radians(rnd.uniform(-175, -5)); r = rnd.uniform(15, 130)
        glint.circle(fx + r * math.cos(a), fy + r * math.sin(a) * .72, rnd.choice((.4, .5, .7)), rgba(WHITE, rnd.randint(120, 240)))
    sc.bloom(glint, 1.0, .8)
    def dark_cloud(cx, cy, w, h, dark=0x1C3A8E, rim=0x78A8FF):
        for off, col in ((-0.9, rim), (0, dark)):
            sc.ell(cx - w * .5, cy - h * .3 + off, cx + w * .5, cy + h * .3 + off, rgba(rgb(col)))
            sc.ell(cx - w * .3, cy - h * .5 + off, cx + w * .2, cy + h * .2 + off, rgba(rgb(col)))
            sc.ell(cx - w * .05, cy - h * .38 + off, cx + w * .38, cy + h * .26 + off, rgba(rgb(col)))
    for i in range(16):                                                                    # dark ragged banks of cloud: flat, a bit slanted, with lit tops
        x_, y_ = rnd.uniform(sw * .06, sw * .92), rnd.uniform(sh * .16, sh * .62)
        tilt = rnd.uniform(-.12, .05); L = rnd.uniform(14, 34)
        for j in range(4):
            px_ = x_ + j * L * .24; py_ = y_ + j * L * .24 * tilt + rnd.uniform(-.8, .8)
            w_ = L * rnd.uniform(.28, .5); h_ = rnd.uniform(.9, 1.9)
            sc.ell(px_ - w_ / 2, py_ - h_ / 2 - .7, px_ + w_ / 2, py_ + h_ / 2 - .7, rgba(rgb(0x7FB0FF), 150))
            sc.ell(px_ - w_ / 2, py_ - h_ / 2, px_ + w_ / 2, py_ + h_ / 2, rgba(rgb(0x142C78), rnd.randint(170, 235)))
    for cx, cy, w in ((sw * .30, sh * .47, 12), (sw * .52, sh * .36, 14), (sw * .76, sh * .30, 13)):   # a few small dark clumps
        for dx, dy, r in ((-.3, .1, .22), (0, -.1, .3), (.3, .05, .24), (.05, .12, .26)):
            sc.circle(cx + dx * w - .5, cy + dy * w - .8, r * w, rgba(rgb(0x78A8FF)))
        for dx, dy, r in ((-.3, .1, .22), (0, -.1, .3), (.3, .05, .24), (.05, .12, .26)):
            sc.circle(cx + dx * w, cy + dy * w, r * w, rgba(rgb(0x1C3A8E)))
    for cx, cy, w in ((sw * .66, hz - 7, 24), (sw * .73, hz - 8, 30), (sw * .58, hz - 5, 18)):   # the dark towers of cloud on the horizon
        dark_cloud(cx, cy, w, w * .8, 0x17327F, 0x6F9CF5)
        sc.ell(cx - w * .3, cy - w * .6, cx + w * .2, cy - w * .1, rgba(rgb(0x1A3685)))
    for cx, cy, w in ((sw * .93, hz - 8, 26), (sw * .86, hz - 5, 20)):                       # the bright cumulus at the right edge
        sc.ell(cx - w * .5, cy - w * .3, cx + w * .5, cy + w * .3, rgba(rgb(0xBFD8FF)))
        sc.ell(cx - w * .3, cy - w * .55, cx + w * .25, cy + w * .1, rgba(rgb(0xEAF3FF)))
        sc.ell(cx - w * .1, cy - w * .1, cx + w * .5, cy + w * .35, rgba(rgb(0x7FA5F0)))
    haze = Canvas(sw, sh); haze.ell(sw * .02, hz - 4, sw * .5, hz + 3, rgba(WHITE, 200))
    sc.bloom(haze, 5, 1.0)
    g0, g1 = np.array(rgb(0xBFE6FF), float), np.array(rgb(0x142D80), float)                   # the wet shore
    sc.gradient(0, hz, sw, sh, lambda u, v: tuple(np.clip(g0[i] + (g1[i] - g0[i]) * np.clip(v ** .55 + u * .35 * (1 - v), 0, 1), 0, 255) for i in range(3)))
    for i in range(26):                                                                    # light reflected in the wet sand
        y = hz + 1 + rnd.random() ** 1.5 * (sh - hz - 3)
        x0_ = rnd.uniform(0, sw * .5); sc.line([(x0_, y), (x0_ + rnd.uniform(6, 46), y)], rgba(WHITE, rnd.randint(40, 120)), rnd.choice((.5, .7, 1.0)))
    for bx, by, ln in ((sw * .60, sh * .965, 40), (sw * .72, sh * .94, 34)):                  # driftwood
        sc.line([(bx, by), (bx + ln * .6, by - ln * .22), (bx + ln, by - ln * .1)], rgba(rgb(0x0F1F58)), 1.4)
        sc.line([(bx + ln * .55, by - ln * .2), (bx + ln * .6, by - ln * .34)], rgba(rgb(0x0F1F58)), 0.9)
        sc.line([(bx + ln * .8, by - ln * .14), (bx + ln * .9, by - ln * .3)], rgba(rgb(0x0F1F58)), 0.8)
    gx, gy = sw * .24, sh * .90                                                            # the girl
    refl = Canvas(sw, sh)
    refl.rrect(gx - 3, gy, gx + 3, gy + 12, 2, rgba(rgb(0xBFD6FF), 70)); sc.bloom(refl, 1.4, .8)
    skin, hair = rgb(0xEBD6CB), rgb(0x141E4A)
    for dx in (-1.3, 1.3): sc.line([(gx + dx, gy), (gx + dx * .8, gy - 9)], rgba(skin), 1.3)
    sc.poly([(gx - 3.6, gy - 9), (gx + 3.6, gy - 9), (gx + 2.3, gy - 15), (gx - 2.3, gy - 15)], rgba(rgb(0xE6ECFA)))
    sc.poly([(gx + .6, gy - 9), (gx + 3.6, gy - 9), (gx + 2.3, gy - 15), (gx + .6, gy - 15)], rgba(rgb(0xAEBFE4)))
    sc.rrect(gx - 2.4, gy - 20.5, gx + 2.4, gy - 14.5, 1.2, rgba(rgb(0xB9C9EA)))
    sc.line([(gx - 2.2, gy - 19.5), (gx - 3.4, gy - 14.5)], rgba(skin), 1.1)
    sc.line([(gx + 2.2, gy - 19.5), (gx + 4.8, gy - 16.8)], rgba(skin), 1.1)
    sc.circle(gx, gy - 23.4, 2.4, rgba(skin))
    sc.poly([(gx - 2.7, gy - 24.5), (gx + 2.5, gy - 25), (gx + 3.0, gy - 22), (gx - 3.6, gy - 12.5), (gx - 4.6, gy - 17)], rgba(hair))
    sc.circle(gx - .2, gy - 25, 2.5, rgba(hair)); sc.ell(gx - 2.8, gy - 25.4, gx + 2.8, gy - 23.2, rgba(hair))
    sc.line([(gx - 3.4, gy - 24.6), (gx - 3.8, gy - 18)], rgba(rgb(0x6F95F0), 200), 0.5)
    for i in range(6): sc.circle(rnd.uniform(0, sw), rnd.uniform(sh * .05, sh * .45), .4, rgba(WHITE, 150))
    return sc


def gaming_screen(v):
    W, H = 192, 120
    b = rgb(v['body'])
    cv = Canvas(W, H, rgba(b))
    cv.rrect(0, 0, W, H, 4.5, rgba((7, 7, 11)))
    x0, y0, x1, y1 = 3, 3, W - 3, H - 3.6
    sw, sh = int(x1 - x0), int(y1 - y0)
    sc = sky_wallpaper(sw, sh)
    cv.rrect(x0 - .5, y0 - .5, x1 + .5, y1 + .5, 2.2, rgba((0, 0, 0)))
    mask = Image.new('L', (sw * SS, sh * SS), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, sw * SS - 1, sh * SS - 1), radius=int(2.0 * SS), fill=255)
    cv.im.paste(sc.im, (int(x0 * SS), int(y0 * SS)), mask)
    cv.circle(W / 2, 1.5, 0.8, rgba((30, 32, 50)), rgba((70, 76, 110)), 0.3)
    cv.poly([(112, 0), (156, 0), (98, H), (54, H)], rgba(WHITE, 11))
    return cv.finish(grain=0.004, seed=9)


def hexagon_pts(cx, cy, r): return [(cx + r * math.cos(math.radians(60 * i - 30)), cy + r * math.sin(math.radians(60 * i - 30))) for i in range(6)]


def gaming_back_static(v):
    W, H = 192, 120
    b = rgb(v['body']); white = v['white']
    cv = Canvas(W, H)
    cv.dgrad(0, 0, W, H, mix(b, WHITE, .10 if not white else .18), mix(b, BLACK, .14))
    cv.poly([(0, 0), (60, 0), (0, 44)], rgba(mix(b, BLACK, .18 if not white else .06), 180))          # angled plates
    cv.poly([(W, H), (W - 70, H), (W, H - 52)], rgba(mix(b, BLACK, .18 if not white else .06), 180))
    cv.poly([(110, 0), (170, 0), (92, H), (32, H)], rgba(WHITE, 9 if not white else 18))
    for i in range(7):                                                                                # air slats top right / bottom left
        cv.line([(W - 52 + i * 5, 6), (W - 36 + i * 5, 26)], rgba(mix(b, BLACK, .6 if not white else .35), 230), 1.2)
        cv.line([(12 + i * 5, H - 26), (28 + i * 5, H - 7)], rgba(mix(b, BLACK, .6 if not white else .35), 230), 1.2)
    ss = SS
    mk, d = cv.mask()
    cx, cy, r = W / 2, H / 2 + 3, 19
    d.polygon([(x * ss, y * ss) for x, y in hexagon_pts(cx, cy, r)], fill=255)
    for sx in (-1, 1): d.polygon([((cx + sx * 4) * ss, (cy - r + 1) * ss), ((cx + sx * 13) * ss, (cy - r - 12) * ss), ((cx + sx * 15.5) * ss, (cy - r + 5) * ss)], fill=255)
    cv.fill_mask(mk, rgba(mix(b, BLACK, .5 if not white else .22)))
    cv.emboss(mk, .8, .35, .5)
    return cv, (cx, cy, r)


def gaming_back_frame(v, st, phase):
    cv0, (cx, cy, r) = st
    W, H = cv0.w, cv0.h
    white = v['white']
    f = cv0.copy()
    lit = Canvas(W, H)
    hexp = hexagon_pts(cx, cy, r)
    for i in range(6):
        a, b2 = hexp[i], hexp[(i + 1) % 6]
        for t in range(0, 12):
            p0 = (a[0] + (b2[0] - a[0]) * t / 12, a[1] + (b2[1] - a[1]) * t / 12); p1 = (a[0] + (b2[0] - a[0]) * (t + 1) / 12, a[1] + (b2[1] - a[1]) * (t + 1) / 12)
            lit.line([p0, p1], rgba(hsv(phase + (i + t / 12) / 6, 1, 1)), 1.5)
    for sx in (-1, 1):
        ear = [(cx + sx * 4, cy - r + 1), (cx + sx * 13, cy - r - 12), (cx + sx * 15.5, cy - r + 5)]
        for i in range(2): lit.line([ear[i], ear[i + 1]], rgba(hsv(phase + .08 * i + (.0 if sx < 0 else .5), 1, 1)), 1.3)
    pc = hsv(phase + .55, .9, 1)
    lit.circle(cx, cy + 3.5, 4.8, None, rgba(pc), 0.9)                                    # a paw: a pad and three toes
    for dx, dy in ((-5.2, -3.2), (0, -5.2), (5.2, -3.2)): lit.circle(cx + dx, cy + dy + .5, 1.5, rgba(pc))
    for sx in (-1, 1):
        for k in range(2): lit.circle(cx + sx * 8.5, cy - 2 + k * 4.2, 0.9, rgba(hsv(phase + .3 * k, 1, 1)))      # four dots round the hexagon
    for i in range(7):                                                                    # the slats glow a little too
        lit.line([(W - 52 + i * 5, 6), (W - 36 + i * 5, 26)], rgba(hsv(phase + i / 12, 1, 1), 55), 0.5)
        lit.line([(12 + i * 5, H - 26), (28 + i * 5, H - 7)], rgba(hsv(phase + .5 + i / 12, 1, 1), 55), 0.5)
    rainbow_path(lit, rrect_path(1.6, 1.6, W - 1.6, H - 1.6, 4), phase, 0.9, loops=1.0)           # a light line round the lid
    for xx, k in ((7, 1), (W - 9, -1)): lit.line([(xx, 7), (xx + 7 * k, 15)], rgba(hsv(phase + xx / W, 1, 1)), 0.9)
    tw = text_width('GAMING', 1.0)
    text(lit, (W - tw) / 2, cy + r + 8, 'GAMING', rgba(hsv(phase + .2, .8, 1), 230), 1.0)
    f.bloom(lit, 2.4, 0.9 if not white else 0.5)
    im = f.finish(grain=0.006, seed=15, brushed=0.003)
    return carbon(im, 4) if not white else im


def gaming_vent(v, phase):
    W, H = 160, 9
    b = rgb(v['body'])
    cv = Canvas(W, H)
    cv.vgrad(0, 0, W, H, mix(b, BLACK, .5), mix(b, BLACK, .75))
    lit = Canvas(W, H)
    for x in range(4, W - 3, 5):
        lit.rrect(x, 1.6, x + 2.2, H - 1.4, 0.6, rgba(hsv(phase + x / W * 1.0, 1, 1)))
    cv.bloom(lit, 1.4, 0.8)
    return cv.finish(grain=0.004, seed=17)


def gaming_side(v, left):
    W, H = 240, 8
    b = rgb(v['body']); white = v['white']
    cv = Canvas(W, H)
    cv.vgrad(0, 0, W, H, mix(b, WHITE, .12 if not white else .3), mix(b, BLACK, .3))
    port = (6, 7, 9)
    def usba(x): cv.rrect(x, 2, x + 9, 6.4, 0.6, rgba(port)); cv.rect(x + 1, 3.9, x + 8, 4.7, rgba((50, 120, 220)))
    if left:
        cv.circle(18, 4, 2, rgba(port)); cv.circle(18, 4, .8, rgba(mix(b, BLACK, .5)))
        cv.poly([(30, 2.2), (42, 2.2), (41, 5.9), (31, 5.9)], rgba(port))
        usba(52); usba(66); cv.rrect(84, 2.2, 98, 5.8, 0.6, rgba(port))
    else:
        cv.rrect(16, 2.6, 32, 5.4, 0.6, rgba(port)); usba(40); usba(54)
        cv.circle(76, 4, 1.4, rgba(port)); cv.circle(88, 4, 1.4, rgba(port))
    for i in range(22): cv.line([(120 + i * 5, 6.4), (123 + i * 5, 1.6)], rgba(mix(b, BLACK, .75 if not white else .45)), 0.9)
    return cv.finish(grain=0.006, seed=19)


# =============================================================================================== models
def office_model(open_):
    X0, X1, Z0, Z1 = 1.25, 14.75, 4.4, 13.9
    els = [box('base', [X0, 0, Z0], [X1, 0.65, Z1], with_(faces_all('#body'), west=face('#side_l'), east=face('#side_r')))]
    els.append(box('deck', [X0 + .1, 0.65, Z0 + .1], [X1 - .1, 1.1, Z1 - .1], with_(faces_all('#body'), up=face('#deck'))))
    els.append(box('hinge_l', [2.4, 0.7, Z0 - .2], [4.6, 1.3, Z0 + .32], faces_all('#feet')))
    els.append(box('hinge_r', [11.4, 0.7, Z0 - .2], [13.6, 1.3, Z0 + .32], faces_all('#feet')))
    els.append(box('hinge_c', [4.6, 0.8, Z0 - .1], [11.4, 1.15, Z0 + .3], faces_all('#body')))
    if open_:
        els.append(box('lid', [X0, 1.1, Z0], [X1, 10.0, Z0 + .6], with_(faces_all('#body'), south=face('#screen', 13), north=face('#back')),
                       {'origin': [8, 1.1, Z0 + .3], 'axis': 'x', 'angle': -22.5}))
    else:
        els.append(box('lid_closed', [X0, 1.1, Z0], [X1, 1.8, Z1], with_(faces_all('#body'), up=face('#back'))))
    return els


# the gaming geometry: THIN (the whole body is 0.62 of a pixel-block high; the old one was 1.5)
GX0, GX1, GZ0, GZ1 = 1.0, 15.0, 4.2, 14.2


def gaming_model(open_):
    els = [box('underglow', [GX0 + .3, 0, GZ0 + .4], [GX1 - .3, 0.10, GZ1 - .3], faces_all('#rgb') and {k: face('#rgb', 15) for k in ('north', 'south', 'east', 'west', 'up', 'down')})]
    els.append(box('base', [GX0, 0.10, GZ0], [GX1, 0.40, GZ1], with_(faces_all('#body'), west=face('#side_l'), east=face('#side_r'))))
    els.append(box('deck', [GX0 + .1, 0.40, GZ0 + .1], [GX1 - .1, 0.62, GZ1 - .1], with_(faces_all('#body'), up=face('#deck', 12))))
    els.append(box('hinge_l', [GX0 + .9, 0.5, GZ0 - .22], [GX0 + 2.7, 0.9, GZ0 + .3], faces_all('#hinge')))
    els.append(box('hinge_r', [GX1 - 2.7, 0.5, GZ0 - .22], [GX1 - .9, 0.9, GZ0 + .3], faces_all('#hinge')))
    els.append(box('vent', [4.2, 0.45, GZ0 - .45], [11.8, 0.88, GZ0 + .02], with_(faces_all('#body'), up=face('#vent', 15), north=face('#rgb', 15))))
    if open_:
        lid = with_(faces_all('#body'), south=face('#screen', 15), north=face('#back', 12))
        els.append(box('lid', [GX0, 0.62, GZ0], [GX1, 9.3, GZ0 + .32], lid, {'origin': [8, 0.62, GZ0 + .16], 'axis': 'x', 'angle': -22.5}))
    else:
        lid = with_(faces_all('#body'), up=face('#back', 12))
        els.append(box('lid_closed', [GX0, 0.62, GZ0], [GX1, 0.94, GZ1], lid))
    return els


DISPLAY = None   # copied from the slim laptop's item model, so every laptop is held the same way


def write_variant(name, textures, elements_fn, credit):
    tex = {'particle': 'cutemod:block/%s_body' % name}
    tex.update({k: 'cutemod:block/%s_%s' % (name, k) for k in textures})
    for open_, suffix in ((True, ''), (False, '_closed')):
        json.dump({'credit': credit, 'ambientocclusion': False, 'textures': tex, 'elements': elements_fn(open_)},
                  open(MOD + '%s_laptop%s.json' % (name, suffix), 'w'), indent=1)
    states = {}
    for facing, y in (('south', 0), ('west', 90), ('north', 180), ('east', 270)):
        states['facing=%s,open=true' % facing] = {'model': 'cutemod:block/%s_laptop' % name, 'y': y}
        states['facing=%s,open=false' % facing] = {'model': 'cutemod:block/%s_laptop_closed' % name, 'y': y}
    json.dump({'variants': states}, open(STATE + '%s_laptop.json' % name, 'w'), indent=2)
    json.dump({'parent': 'cutemod:block/%s_laptop' % name, 'display': DISPLAY}, open(ITEM + '%s_laptop.json' % name, 'w'), indent=1)
    write_loot('%s_laptop' % name)


def write_loot(block):
    """The drop keeps the custom_data of the laptop (its upgraded memory and drive)."""
    json.dump({
        'type': 'minecraft:block',
        'pools': [{'rolls': 1.0, 'bonus_rolls': 0.0,
                   'entries': [{'type': 'minecraft:item', 'name': 'cutemod:%s' % block,
                                'functions': [{'function': 'minecraft:copy_components', 'source': 'block_entity', 'include': ['minecraft:custom_data']}]}],
                   'conditions': [{'condition': 'minecraft:survives_explosion'}]}],
        'random_sequence': 'cutemod:blocks/%s' % block}, open(LOOT + '%s.json' % block, 'w'), indent=2)


def main():
    global DISPLAY
    DISPLAY = json.load(open(ITEM + 'pink_laptop.json'))['display']
    only = set(sys.argv[1:])
    for name, v in OFFICE.items():
        if only and name not in only: continue
        office_body(v).save(TEX + '%s_body.png' % name)
        Image.new('RGBA', (4, 4), mix(rgb(v['body']), BLACK, .5) + (255,)).save(TEX + '%s_feet.png' % name)
        office_deck(v).save(TEX + '%s_deck.png' % name)
        office_screen(v).save(TEX + '%s_screen.png' % name)
        office_back(v).save(TEX + '%s_back.png' % name)
        office_side(v, True).save(TEX + '%s_side_l.png' % name)
        office_side(v, False).save(TEX + '%s_side_r.png' % name)
        write_variant(name, ('body', 'feet', 'deck', 'screen', 'back', 'side_l', 'side_r'), office_model, 'office laptop with thick bezels (generated by tools/make_laptops.py)')
        print(name, 'ok')
    for name, v in GAMING.items():
        if only and name not in only: continue
        gaming_body(v).save(TEX + '%s_body.png' % name)
        gaming_hinge(v).save(TEX + '%s_hinge.png' % name)
        gaming_screen(v).save(TEX + '%s_screen.png' % name)
        gaming_side(v, True).save(TEX + '%s_side_l.png' % name)
        gaming_side(v, False).save(TEX + '%s_side_r.png' % name)
        phases = [i / FRAMES for i in range(FRAMES)]
        save_anim([gaming_rgb(p) for p in phases], '%s_rgb' % name, 64, 4)
        save_anim([gaming_vent(v, p) for p in phases], '%s_vent' % name, 160, 9)
        st = gaming_deck_static(v)
        save_anim([gaming_deck_frame(v, st, p) for p in phases], '%s_deck' % name, 184, 130, 3)
        sb = gaming_back_static(v)
        save_anim([gaming_back_frame(v, sb, p) for p in phases], '%s_back' % name, 192, 120, 3)
        write_variant(name, ('body', 'hinge', 'rgb', 'vent', 'deck', 'screen', 'back', 'side_l', 'side_r'), gaming_model, 'thin gaming laptop with RGB lighting (generated by tools/make_laptops.py)')
        print(name, 'ok')


if __name__ == '__main__':
    main()
