import json, shutil, os, numpy as np
from PIL import Image, ImageDraw, ImageFilter
R='mod/cute-computers/src/main/resources/assets/cutemod/'
W2='work/'
if os.path.exists(W2): shutil.rmtree(W2)
shutil.copytree(R, W2, ignore=shutil.ignore_patterns('sounds'))

SS=4
def rr(d,box,r,fill):
    d.rounded_rectangle([v*SS for v in box], r*SS, fill=fill)

def panel(on, orig):
    w,h=180,118
    im=Image.new('RGBA',(w*SS,h*SS),(0,0,0,0)); d=ImageDraw.Draw(im)
    # body shell: soft pearl white with subtle vertical gradient
    shell=Image.new('RGBA',im.size)
    px=np.zeros((h*SS,w*SS,4),np.uint8)
    t=np.linspace(0,1,h*SS)[:,None]
    px[...,0]=(250-10*t); px[...,1]=(249-11*t); px[...,2]=(253-8*t); px[...,3]=255
    shell=Image.fromarray(px,'RGBA')
    mask=Image.new('L',im.size,0); ImageDraw.Draw(mask).rounded_rectangle([0,0,w*SS-1,h*SS-1],4*SS,fill=255)
    im.paste(shell,(0,0),mask)
    # thin dark inner bezel line, then screen
    sx0,sy0,sx1,sy1=3,3,177,106
    rr(d,(sx0-1,sy0-1,sx1+1,sy1+1),1.5,(40,34,60,255))
    sw,sh=sx1-sx0,sy1-sy0
    if on:
        scr=Image.open('wallpaper_aquarium.png').convert('RGBA').resize((sw*SS,sh*SS),Image.LANCZOS)
    else:
        a=np.zeros((sh*SS,sw*SS,4),np.uint8)
        yy=np.linspace(0,1,sh*SS)[:,None]; xx=np.linspace(0,1,sw*SS)[None,:]
        a[...,0]=22+16*yy+0*xx; a[...,1]=19+14*yy; a[...,2]=36+26*yy; a[...,3]=255
        scr=Image.fromarray(a,'RGBA')
    sm=Image.new('L',scr.size,0); ImageDraw.Draw(sm).rounded_rectangle([0,0,scr.width-1,scr.height-1],1.2*SS,fill=255)
    im.paste(scr,(sx0*SS,sy0*SS),sm)
    # glass glare (soft diagonal bands)
    gl=Image.new('RGBA',im.size,(0,0,0,0)); gd=ImageDraw.Draw(gl)
    S=SS
    gd.polygon([((sx0+10)*S,sy0*S),((sx0+48)*S,sy0*S),((sx0+22)*S,sy1*S),((sx0-16)*S,sy1*S)],fill=(255,255,255,26 if on else 34))
    gd.polygon([((sx0+56)*S,sy0*S),((sx0+66)*S,sy0*S),((sx0+40)*S,sy1*S),((sx0+30)*S,sy1*S)],fill=(255,255,255,16 if on else 22))
    gl=gl.filter(ImageFilter.GaussianBlur(1.2*SS))
    clip=Image.new('L',im.size,0); ImageDraw.Draw(clip).rectangle([sx0*S,sy0*S,sx1*S,sy1*S],fill=255)
    im.paste(Image.alpha_composite(im.crop((0,0,*im.size)),gl),(0,0),clip)
    d=ImageDraw.Draw(im)
    # chin: thin brand line + power LED
    cy=(sy1+118)/2+0.5
    rr(d,(82,cy-1.2,98,cy+0.3),0.6,(190,184,214,255))
    rr(d,(160,cy-1.5,163,cy+1.5),1.5,(120,226,176,255) if on else (150,146,170,255))
    return im.resize((w,h),Image.LANCZOS)

def metal(w,h,horizontal=False):
    a=np.zeros((h,w,4),np.uint8)
    t=(np.linspace(0,1,w)[None,:] if horizontal else np.linspace(0,1,h)[:,None])
    a[...,0]=(246-22*t); a[...,1]=(244-22*t); a[...,2]=(252-14*t); a[...,3]=255
    return Image.fromarray(a,'RGBA')

for on in (True,False):
    n='pc_monitor_%s.png'%('on' if on else 'off')
    base=Image.open(R+'textures/block/'+n).convert('RGBA')
    orig=Image.open(R+'textures/block/pc_monitor_on.png').convert('RGBA').crop((1,9,181,127))
    base.paste(panel(on,orig),(1,9))
    # neck / foot regions: clean satin metal
    base.paste(metal(24,31),(269,9)); base.paste(metal(84,10),(295,9)); base.paste(metal(84,60,False),(381,9))
    base.save(W2+'textures/block/'+n)
    # model
    p=R+'models/block/pc_monitor_%s.json'%('on' if on else 'off')
    d=json.load(open(p)); els={e['name']:e for e in d['elements']}
    els['panel']['from']=[0.5,3.4,7.6]; els['panel']['to']=[15.5,13.2,8.6]
    neck=els['neck']; neck['from']=[7.3,0.5,7.0]; neck['to']=[8.7,3.4,8.0]
    foot=els['foot']; foot['from']=[6.6,0.0,6.7]; foot['to']=[9.4,0.6,8.3]
    sw={'uv':[0.0547,0.0078,0.0703,0.0234],'texture':'#t'}
    def leg(name,x0,x1,ang):
        return {'name':name,'from':[x0,0.0,7.05],'to':[x1,0.5,7.95],
          'rotation':{'angle':ang,'axis':'y','origin':[8,0,7.5]},
          'faces':{'south':{'uv':[4.6094,0.1406,5.9219,0.2969],'texture':'#t'},
                   'north':{'uv':[4.6094,0.1406,5.9219,0.2969],'texture':'#t'},
                   'east':sw,'west':sw,
                   'up':{'uv':[6.0,0.35,7.2,0.45],'texture':'#t'},
                   'down':{'uv':[0.1484,0.0078,0.1641,0.0234],'texture':'#t'}}}
    d['elements']=[els['panel'],els['bulge'],neck,foot,leg('leg_r',8,15,-45),leg('leg_l',1,8,45)]
    json.dump(d,open(W2+'models/block/pc_monitor_%s.json'%('on' if on else 'off'),'w'),indent=1)
print('done')
