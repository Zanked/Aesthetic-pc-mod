#!/usr/bin/env python3
"""
The "orange" look of the yellow PC items: a compact console-style case and a peach / orange keyboard.

  python3 tools/make_pc_orange.py        (run from the repo root, AFTER make_pc_colors.py and make_pc_peripherals.py: it paints over their yellow files)

  textures/block/pc_case_mini_atlas_yellow.png   the mini case: a white body, an orange frame round the glass, and on its right side a little
                                                 console face (a screen with a paw, a D-pad, two round buttons, ports) and vents
  textures/block/pc_keyboard_yellow.png          a white-orange keyboard with peach keys and orange modifier keys

Everything is original pixel art (a paw print, a plus, two dots): nothing here copies a brand or a character.
"""
import os, sys, json, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image, ImageDraw
import make_pc_peripherals as P

RES = "src/main/resources/assets/cutemod"
TEX = f"{RES}/textures/block"
MOD = f"{RES}/models/block"
S = 4

WHITE = (252, 248, 242, 255)
WHITE_D = (226, 216, 206, 255)
OUTLINE = (196, 168, 146, 255)
OR = (255, 156, 48, 255)
OR_D = (214, 100, 22, 255)
OR_L = (255, 196, 112, 255)
CREAM = (255, 238, 204, 255)
INK = (120, 62, 38, 255)


def mix(a, b, t): return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(4))


def face_rects(name, faces=None):
    """The pixels of the faces of one element of the mini body model: {face: (x0, y0, x1, y1)}."""
    d = json.load(open(f"{MOD}/pc_case_mini_body.json"))
    for e in d["elements"]:
        if e["name"] == name:
            return {f: (round(v["uv"][0] * 1024 / 16), round(v["uv"][1] * 752 / 16), round(v["uv"][2] * 1024 / 16), round(v["uv"][3] * 752 / 16))
                    for f, v in e["faces"].items() if faces is None or f in faces}
    raise KeyError(name)


def canvas(w, h, c=(0, 0, 0, 0)): return Image.new("RGBA", (w * S, h * S), c)


def rrect(im, box, r, fill, outline=None, width=1):
    d = ImageDraw.Draw(im)
    x0, y0, x1, y1 = box
    d.rounded_rectangle([x0 * S, y0 * S, x1 * S - 1, y1 * S - 1], radius=r * S, fill=fill, outline=outline, width=round(width * S) if outline else 0)


def circle(im, cx, cy, r, fill, outline=None):
    d = ImageDraw.Draw(im)
    d.ellipse([(cx - r) * S, (cy - r) * S, (cx + r) * S - 1, (cy + r) * S - 1], fill=fill, outline=outline, width=S if outline else 0)


def gradient(im, box, c0, c1):
    d = ImageDraw.Draw(im)
    x0, y0, x1, y1 = [round(v * S) for v in box]
    for y in range(y0, y1):
        t = (y - y0) / max(1, y1 - y0 - 1)
        d.line([(x0, y), (x1, y)], fill=mix(c0, c1, t))


def paw(im, cx, cy, s, col):
    circle(im, cx, cy + 2.2 * s, 2.5 * s, col)
    for dx, dy, r in ((-4.2, -0.4, 1.2), (-1.5, -3.6, 1.3), (1.5, -3.6, 1.3), (4.2, -0.4, 1.2)):
        circle(im, cx + dx * s, cy + dy * s + 1.2 * s, r * s, col)


def finish(im, w, h): return im.resize((w, h), Image.BOX)


# ------------------------------------------------------------------ the case
def cat_face(im, cx, cy, k):
    """An original little tabby cat head (ears, stripes, happy closed eyes, pink nose, whiskers)."""
    FUR, FUR_D, FUR_L = (255, 160, 60, 255), (214, 100, 22, 255), (255, 214, 150, 255)
    d = ImageDraw.Draw(im)
    for sx in (-1, 1):                                                       # ears
        pts = [(cx + sx * 2.0 * k, cy - 3.2 * k), (cx + sx * 6.2 * k, cy - 9.2 * k), (cx + sx * 8.0 * k, cy - 2.2 * k)]
        d.polygon([(x * S, y * S) for x, y in pts], fill=FUR_D)
        pts = [(cx + sx * 3.4 * k, cy - 3.6 * k), (cx + sx * 6.0 * k, cy - 7.4 * k), (cx + sx * 6.9 * k, cy - 3.0 * k)]
        d.polygon([(x * S, y * S) for x, y in pts], fill=(255, 176, 160, 255))
    d.ellipse([(cx - 8.4 * k) * S, (cy - 6.4 * k) * S, (cx + 8.4 * k) * S, (cy + 6.8 * k) * S], fill=FUR, outline=FUR_D, width=S)
    d.ellipse([(cx - 4.2 * k) * S, (cy + 0.6 * k) * S, (cx + 4.2 * k) * S, (cy + 6.0 * k) * S], fill=FUR_L)
    for dx in (-2.2, 0, 2.2):                                                # forehead stripes
        d.line([((cx + dx * k) * S, (cy - 6.0 * k) * S), ((cx + dx * k) * S, (cy - 3.4 * k) * S)], fill=FUR_D, width=max(1, round(0.7 * k * S)))
    for sx in (-1, 1):                                                       # cheek stripes, eyes, whiskers
        for dy in (0.4, 2.0):
            d.line([((cx + sx * 8.2 * k) * S, (cy + dy * k) * S), ((cx + sx * 5.8 * k) * S, (cy + (dy + 0.3) * k) * S)], fill=FUR_D, width=max(1, round(0.5 * k * S)))
        d.arc([(cx + sx * 4.0 * k - 1.5 * k) * S, (cy - 1.6 * k) * S, (cx + sx * 4.0 * k + 1.5 * k) * S, (cy + 0.9 * k) * S], 200, 340, fill=INK, width=max(1, round(0.6 * k * S)))
        circle(im, cx + sx * 6.2 * k, cy + 2.6 * k, 1.0 * k, (255, 172, 140, 255))
    d.polygon([((cx - 1.0 * k) * S, (cy + 1.6 * k) * S), ((cx + 1.0 * k) * S, (cy + 1.6 * k) * S), (cx * S, (cy + 2.7 * k) * S)], fill=(236, 96, 120, 255))
    d.arc([(cx - 1.6 * k) * S, (cy + 2.2 * k) * S, cx * S, (cy + 4.2 * k) * S], 20, 160, fill=INK, width=max(1, round(0.4 * k * S)))
    d.arc([cx * S, (cy + 2.2 * k) * S, (cx + 1.6 * k) * S, (cy + 4.2 * k) * S], 20, 160, fill=INK, width=max(1, round(0.4 * k * S)))


def glossy_button(im, bx, by, r):
    circle(im, bx, by + 1.2, r + 0.4, (176, 92, 40, 255))                  # the shadow under the button
    circle(im, bx, by, r, OR, OR_D)
    gradient_circle(im, bx, by, r - 0.8, (255, 190, 96, 255), (255, 140, 40, 255))
    circle(im, bx - r * 0.32, by - r * 0.38, r * 0.3, (255, 236, 190, 255))


def gradient_circle(im, cx, cy, r, c0, c1):
    d = ImageDraw.Draw(im)
    n = max(2, int(r * S))
    for k in range(n):
        t = k / (n - 1)
        rr = r * (1 - t * 0.55)
        d.ellipse([(cx - rr) * S, (cy - rr * 0.9 + t * r * 0.3) * S, (cx + rr) * S, (cy + rr * 0.9 + t * r * 0.3) * S], fill=mix(c0, c1, t))


def console_side(w=67, h=144):
    """The right side of the compact case, a cream hand-held console: vents, an orange lit screen with a cat, a D-pad, two round buttons,
    start / select, a speaker and the ports at the bottom (like the white-orange console cases)."""
    im = canvas(w, h, WHITE)
    rrect(im, (0.5, 0.5, w - 0.5, h - 0.5), 4, WHITE, WHITE_D, 1)
    gradient(im, (2, 2, w - 2, h - 2), (255, 253, 248, 255), (240, 230, 216, 255))
    rrect(im, (1.5, 1.5, w - 1.5, 3), 1, (255, 255, 255, 255))              # the light edge on top
    for i in range(20):                                                    # the vent slits at the glass edge
        y = 10 + i * 4.6
        rrect(im, (3.4, y + 0.5, 8.6, y + 2.0), 0.7, (170, 70, 40, 255))
        rrect(im, (3.4, y, 8.6, y + 1.5), 0.7, (232, 96, 66, 255))
    # the screen: a thick orange bezel, a dark lip, a glowing cream display with the cat
    rrect(im, (12, 7, 64, 60), 6, (190, 96, 30, 255))
    rrect(im, (12, 6, 64, 58.6), 6, OR, OR_D, 1)
    gradient(im, (14, 8, 62, 12), OR_L, OR)
    for i in range(6): rrect(im, (16 + i * 4, 8.4, 18.4 + i * 4, 9.4), 0.5, (255, 214, 140, 255))
    rrect(im, (16, 13, 60, 53), 3.4, (120, 62, 30, 255))
    rrect(im, (17, 14, 59, 52), 2.6, CREAM)
    gradient(im, (17.5, 14.5, 58.5, 51.5), (255, 250, 226, 255), (255, 214, 150, 255))
    circle(im, 38, 33, 17, (255, 240, 204, 255))                           # the glow of the screen
    for px, py in ((22, 20), (54, 20), (22, 46), (54, 46)): circle(im, px, py, 0.9, (255, 255, 255, 230))
    cat_face(im, 38, 31, 1.45)
    rrect(im, (24, 45.5, 52, 47.5), 1, (238, 176, 112, 255))                # a cushion under the cat
    circle(im, 15, 63, 1.3, (130, 236, 160, 255), OR_D)                    # the little power light
    for k in range(3): rrect(im, (21 + k * 4, 62, 23.4 + k * 4, 64), 0.6, (230, 205, 175, 255))
    # the sticker under the screen
    rrect(im, (36, 63.6, 62, 70.6), 2, (40, 36, 44, 255)); rrect(im, (36.6, 64.2, 61.4, 70), 1.6, (255, 250, 240, 255))
    for k in range(5): rrect(im, (39 + k * 4, 66, 41.4 + k * 4, 68), 0.5, (60, 56, 64, 255) if k != 2 else OR_D)
    # the D-pad
    cx, cy = 22, 94
    circle(im, cx, cy + 0.8, 13.6, (226, 214, 200, 255))
    rrect(im, (cx - 12.4, cy - 4.4 + 1, cx + 12.4, cy + 4.4 + 1), 2.2, (170, 84, 30, 255)); rrect(im, (cx - 4.4, cy - 12.4 + 1, cx + 4.4, cy + 12.4 + 1), 2.2, (170, 84, 30, 255))
    rrect(im, (cx - 12, cy - 4, cx + 12, cy + 4), 2, OR_D); rrect(im, (cx - 4, cy - 12, cx + 4, cy + 12), 2, OR_D)
    rrect(im, (cx - 11, cy - 3.2, cx + 11, cy + 3.2), 1.8, OR); rrect(im, (cx - 3.2, cy - 11, cx + 3.2, cy + 11), 1.8, OR)
    rrect(im, (cx - 10, cy - 2.7, cx + 10, cy - 1.3), 0.6, OR_L); rrect(im, (cx - 2.7, cy - 10, cx - 1.3, cy + 10), 0.6, OR_L)
    circle(im, cx, cy, 2.4, OR_D); circle(im, cx, cy, 1.6, (255, 176, 80, 255))
    for ax, ay, dx, dy in ((cx, cy - 9, 0, -1), (cx, cy + 9, 0, 1), (cx - 9, cy, -1, 0), (cx + 9, cy, 1, 0)):
        d = ImageDraw.Draw(im); d.polygon([((ax + dx * 1.2 + dy * 1.1) * S, (ay + dy * 1.2 + dx * 1.1) * S), ((ax + dx * 1.2 - dy * 1.1) * S, (ay + dy * 1.2 - dx * 1.1) * S), ((ax - dx * 0.8) * S, (ay - dy * 0.8) * S)], fill=(214, 100, 22, 255))
    # the two round buttons on a tilted pill, like the A / B buttons
    d = ImageDraw.Draw(im)
    d.line([(40 * S, 99 * S), (54 * S, 85 * S)], fill=(228, 214, 198, 255), width=15 * S)
    d.line([(40 * S, 98.4 * S), (54 * S, 84.4 * S)], fill=(246, 238, 226, 255), width=13 * S)
    glossy_button(im, 42, 97, 5.4); glossy_button(im, 53, 86, 5.4)
    # start / select and the speaker
    for k in range(2):
        d.line([((20 + k * 11) * S, 120 * S), ((27 + k * 11) * S, 117.6 * S)], fill=(190, 160, 140, 255), width=int(2.6 * S))
        d.line([((20 + k * 11) * S, 119.6 * S), ((27 + k * 11) * S, 117.2 * S)], fill=(238, 224, 208, 255), width=int(1.8 * S))
    for k in range(5):
        d.line([((46 + k * 3.2) * S, 124 * S), ((52 + k * 3.2) * S, 112 * S)], fill=(206, 130, 80, 255), width=int(1.3 * S))
    # the ports at the bottom: a jack and two USB
    circle(im, 12, 133, 2.5, (240, 226, 210, 255), (170, 130, 100, 255)); circle(im, 12, 133, 1.3, (50, 40, 44, 255))
    for px in (23, 40):
        rrect(im, (px, 130, px + 13, 137), 1.4, (190, 190, 200, 255), (130, 130, 150, 255), 0.8)
        rrect(im, (px + 1.4, 131.4, px + 11.6, 135.6), 0.8, (30, 30, 40, 255))
        rrect(im, (px + 2.6, 134, px + 10.4, 135.2), 0.4, (80, 150, 230, 255))
    rrect(im, (6, 139.4, w - 6, 141), 0.8, OR)                              # an orange line along the bottom edge
    return finish(im, w, h)


def plain_side(w=67, h=144):
    """The left side: white, with rows of vents and an orange stripe."""
    im = canvas(w, h, WHITE)
    rrect(im, (0.5, 0.5, w - 0.5, h - 0.5), 4, WHITE, WHITE_D, 1)
    gradient(im, (2, 2, w - 2, h - 2), (255, 252, 247, 255), (244, 234, 222, 255))
    for r in range(8):
        for c in range(3): rrect(im, (12 + c * 16, 14 + r * 6.5, 24 + c * 16, 16.4 + r * 6.5), 1, (214, 120, 70, 255))
    rrect(im, (0, h - 24, w, h - 18), 0, OR)
    for k in range(5): paw(im, 8 + k * 13, h - 10, 0.8, OR_L)
    return finish(im, w, h)


def top_panel(w=98, h=67):
    im = canvas(w, h, WHITE)
    rrect(im, (0.5, 0.5, w - 0.5, h - 0.5), 4, WHITE, WHITE_D, 1)
    gradient(im, (2, 2, w - 2, h - 2), (255, 252, 247, 255), (246, 236, 224, 255))
    rrect(im, (6, h - 12, w - 6, h - 8), 1.5, OR)
    for k in range(6): paw(im, 10 + k * 15.5, 22, 1.0, (255, 214, 160, 255))
    return finish(im, w, h)


def back_panel(w=108, h=144):
    im = canvas(w, h, WHITE)
    rrect(im, (0.5, 0.5, w - 0.5, h - 0.5), 4, WHITE, WHITE_D, 1)
    gradient(im, (2, 2, w - 2, h - 2), (255, 252, 247, 255), (244, 234, 222, 255))
    for r in range(10):
        for c in range(5): rrect(im, (10 + c * 18, 14 + r * 12, 22 + c * 18, 17 + r * 12), 1, (232, 196, 170, 255))
    return finish(im, w, h)


def frame_panel(w, h):
    """The orange frame of the glass: a warm orange with a light top line, a darker bottom line and little cream stripes / paws."""
    im = canvas(w, h, OR)
    gradient(im, (0, 0, w, h), OR_L if h > 3 else OR, OR)
    if h > 3 and w > 3:
        rrect(im, (0, h - 1, w, h), 0, OR_D)
        if w > 20 and h >= 8:
            for k in range(0, int(w), 14): paw(im, 7 + k, h / 2, 0.55, mix(OR, CREAM, 0.6))
        elif h > 20:
            for k in range(6, int(h) - 6, 16): paw(im, w / 2, k, 0.35, mix(OR, CREAM, 0.6))
        else:
            for k in range(0, w, 11): rrect(im, (k, 1, k + 4, max(2, h - 1)), 0, mix(OR, OR_L, 0.55))
    return finish(im, w, h)


def glass_panel(w, h):
    """The front glass of the orange case: a clear pane with a printed orange border (stripes and paws) and a soft shine."""
    im = canvas(w, h, (0, 0, 0, 0))
    bx, by = 3.0, 3.4
    d = ImageDraw.Draw(im)
    band = (255, 150, 44, 235)
    d.rectangle([0, 0, w * S, by * S], fill=band); d.rectangle([0, (h - by) * S, w * S, h * S], fill=band)
    d.rectangle([0, 0, bx * S, h * S], fill=band); d.rectangle([(w - bx) * S, 0, w * S, h * S], fill=band)
    for k in range(0, int(w), 9): rrect(im, (k + 3, 0.6, k + 6, by - 0.6), 0, (255, 196, 112, 235))
    for k in range(0, int(w), 9): rrect(im, (k + 3, h - by + 0.6, k + 6, h - 0.6), 0, (255, 196, 112, 235))
    for k in range(8, int(h) - 8, 14):
        paw(im, bx / 2, k, 0.3, (255, 226, 170, 235)); paw(im, w - bx / 2, k, 0.3, (255, 226, 170, 235))
    rrect(im, (bx, by, w - bx, by + 0.7), 0, (190, 96, 30, 200)); rrect(im, (bx, h - by - 0.7, w - bx, h - by), 0, (190, 96, 30, 200))
    d.polygon([((w * 0.18) * S, (h - by - 2) * S), ((w * 0.30) * S, (h - by - 2) * S), ((w * 0.62) * S, (by + 2) * S), ((w * 0.50) * S, (by + 2) * S)], fill=(255, 255, 255, 34))
    d.polygon([((w * 0.34) * S, (h - by - 2) * S), ((w * 0.38) * S, (h - by - 2) * S), ((w * 0.70) * S, (by + 2) * S), ((w * 0.66) * S, (by + 2) * S)], fill=(255, 255, 255, 26))
    return finish(im, w, h)


def paint_case():
    base = Image.open(f"{TEX}/pc_case_mini_atlas.png").convert("RGBA")           # the white case: the body and the parts inside
    def put(box, img): base.paste(img, box[:2])
    rect = face_rects("right")["east"]; put(rect, console_side(rect[2] - rect[0], rect[3] - rect[1]))
    rect = face_rects("left")["west"]; put(rect, plain_side(rect[2] - rect[0], rect[3] - rect[1]))
    rect = face_rects("top")["up"]; put(rect, top_panel(rect[2] - rect[0], rect[3] - rect[1]))
    rect = face_rects("back")["north"]; put(rect, back_panel(rect[2] - rect[0], rect[3] - rect[1]))
    for name in ("topfront", "lip", "post_l", "post_r"):                         # the frame round the glass
        for f, rect in face_rects(name).items(): put(rect, frame_panel(rect[2] - rect[0], rect[3] - rect[1]))
    for i in range(4):                                                              # the feet
        for f, rect in face_rects("foot%d" % i).items(): put(rect, frame_panel(rect[2] - rect[0], rect[3] - rect[1]))
    rect = (919, 458, 985, 544)                                                     # the south face of the glass (see pc_case_mini_glass)
    base.paste(glass_panel(rect[2] - rect[0], rect[3] - rect[1]), rect[:2])
    base.save(f"{TEX}/pc_case_mini_atlas_yellow.png")
    make_models()


YEL = "cutemod:block/pc_case_mini_atlas_yellow"


def make_models():
    """The orange case has its own models: no front panel (io) on the side, its own glass with the printed border."""
    def load(n): return json.load(open(f"{MOD}/{n}.json"))
    def save(n, d): json.dump(d, open(f"{MOD}/{n}.json", "w"), indent=1)
    for src, dst in (("pc_case_mini_body", "pc_case_mini_body_yellow"), ("pc_case_mini_item", "pc_case_mini_item_yellow"),
                     ("pc_case_mini_glow_base", "pc_case_mini_glow_base_yellow"), ("pc_case_mini_glass", "pc_case_mini_glass_yellow")):
        d = load(src)
        d["elements"] = [e for e in d["elements"] if e["name"] != "io"]
        d["textures"] = {"particle": YEL, "t": YEL}
        if dst.endswith("glow_base_yellow"): d["textures"] = {"particle": "cutemod:block/pc_case_mini_atlas", "t": "cutemod:block/pc_case_mini_atlas"}
        save(dst, d)
    path = f"{MOD}/pc_case_mini_shared.json"
    sh = json.load(open(path))
    others = "white|pink|blue|mint|purple|red|black"
    if any(pt["apply"]["model"].endswith("glass_yellow") for pt in sh["parts"]): return    # (re-run) already patched
    parts = []
    for pt in sh["parts"]:
        m = pt["apply"]["model"].split("/")[-1]
        if m in ("pc_case_mini_glass", "pc_case_mini_glow_base") and "color" not in pt["when"]:
            y = {"when": dict(pt["when"], color="yellow"), "apply": dict(pt["apply"], model=pt["apply"]["model"] + "_yellow")}
            pt["when"] = dict(pt["when"], color=others)
            parts.append(pt); parts.append(y)
        else: parts.append(pt)
    sh["parts"] = parts
    json.dump(sh, open(path, "w"))


# ------------------------------------------------------------------ the keyboard
def kb_top():
    W, H = 156, 60
    frame, frame2, plate = (255, 170, 84, 255), (255, 214, 164, 255), (255, 240, 222, 255)
    peach, peach2, cream, mod, space = (255, 208, 168, 255), (255, 226, 196, 255), (255, 240, 222, 255), (255, 150, 66, 255), (255, 238, 214, 255)
    im = P.canvas(W, H, frame)
    P.rr(im, (0.4, 0.4, W - 0.4, H - 0.4), 2.6, frame2, outline=P.mix(frame, (0, 0, 0, 255), 0.30), width=0.8)
    P.rr(im, (2.2, 2.2, W - 2.2, H - 2.2), 1.8, plate)
    for (x0, y0, x1, y1, kind) in P.kb_layout("yellow"):
        col = int((x0 + y0 / 6) / 10.5) % 3
        base = mod if kind == "mod" else space if kind == "space" else (peach, peach2, mix(peach, mod, 0.25))[col]
        lo = P.mix(base, (60, 20, 0, 255), 0.22)
        P.rr(im, (x0, y0 + 0.7, x1, y1 + 0.2), 1.3, lo)
        P.rr(im, (x0, y0, x1, y1 - 0.5), 1.3, base)
        P.line_h(im, x0 + 1.0, x1 - 1.0, y0 + 0.25, 0.45, P.mix(base, (255, 255, 255, 255), 0.55))
        cx, mid = (x0 + x1) / 2, (y0 + y1) / 2 - 0.3
        leg = (214, 96, 40, 255)
        if kind == "key": P.over(im, (cx - 1.4, mid - 0.7, cx + 1.4, mid + 0.7), 0.6, leg[:3] + (200,))
        elif kind == "mod": P.over(im, (cx - 1.0, mid - 0.5, cx + 1.0, mid + 0.5), 0.5, (255, 255, 255, 190))
        elif kind == "space": P.over(im, (cx - 12, mid - 0.5, cx + 12, mid + 0.5), 0.5, leg[:3] + (170,))
    return P.down(im, W, H)


def kb_front():
    W, H = 156, 11
    im = Image.new("RGBA", (W, H))
    d = ImageDraw.Draw(im)
    for y in range(H):
        d.line([(0, y), (W, y)], fill=mix((255, 214, 164, 255), (240, 136, 56, 255), y / (H - 1)))
    d.line([(0, 0), (W, 0)], fill=(255, 238, 214, 255))
    return im


def paint_keyboard():
    path = f"{TEX}/pc_keyboard_yellow.png"
    im = Image.open(path).convert("RGBA")
    im.paste(kb_top(), P.KB_TOP[:2])
    im.paste(kb_front(), P.KB_FRONT[:2])
    im.save(path)


if __name__ == "__main__":
    paint_case()
    paint_keyboard()
    print("orange case + keyboard painted")
