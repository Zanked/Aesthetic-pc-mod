import sys, os, glob
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

def epx(a):
    """a: HxWx4 uint8 -> 2x EPX upscale (smooths stair-steps, keeps flat colours)."""
    h, w, _ = a.shape
    p = np.pad(a, ((1, 1), (1, 1), (0, 0)), mode='edge')
    P = a
    A = p[0:h, 1:w+1]; D = p[2:h+2, 1:w+1]; C = p[1:h+1, 0:w]; B = p[1:h+1, 2:w+2]
    eq = lambda x, y: np.all(x == y, axis=-1)
    o = np.repeat(np.repeat(a, 2, 0), 2, 1).copy()
    c1 = eq(C, A) & ~eq(C, D) & ~eq(A, B)
    c2 = eq(A, B) & ~eq(A, C) & ~eq(B, D)
    c3 = eq(D, C) & ~eq(D, B) & ~eq(C, A)
    c4 = eq(B, D) & ~eq(B, A) & ~eq(D, C)
    o[0::2, 0::2][c1] = A[c1]
    o[0::2, 1::2][c2] = B[c2]
    o[1::2, 0::2][c3] = C[c3]
    o[1::2, 1::2][c4] = D[c4]
    return o

def enhance(src, dst, scale, keep_rows=8, strength=1.0, glare=None):
    im = np.array(Image.open(src).convert('RGBA'))
    H, W = im.shape[:2]
    swatch = im[:keep_rows].copy()
    a = im
    k = 1
    while k < scale:
        a = epx(a); k *= 2
    # premultiplied float
    f = a.astype(np.float32) / 255.0
    al = f[..., 3:4]
    pm = f[..., :3] * al
    sig = 0.55 * (scale / 2) ** 0.5
    pm = np.stack([ndi.gaussian_filter(pm[..., i], sig) for i in range(3)], -1)
    al2 = ndi.gaussian_filter(al[..., 0], sig)[..., None]
    rgb = np.where(al2 > 1e-4, pm / np.maximum(al2, 1e-4), 0)
    rgb = np.clip(rgb, 0, 1)
    lum = rgb @ np.array([0.299, 0.587, 0.114], np.float32)
    opaque = al2[..., 0] > 0.5
    solid = (al2[..., 0] > 0.97)

    # ---- bevel / emboss from blurred luminance + alpha edge (light from top-left)
    hgt = ndi.gaussian_filter(lum, 0.9 * scale) * 1.0 + ndi.gaussian_filter(al2[..., 0], 1.2 * scale) * 0.35
    gy, gx = np.gradient(hgt)
    emb = (-(gx + gy)) * scale * 3.2 * strength
    emb = np.clip(emb, -0.07, 0.07)
    # fine detail emboss (frames, keys, blade edges)
    hgt2 = ndi.gaussian_filter(lum, 0.45 * scale)
    gy2, gx2 = np.gradient(hgt2)
    emb2 = np.clip(-(gx2 + gy2) * scale * 1.2 * strength, -0.06, 0.06)
    shade = emb + emb2

    # ---- inner edge falloff (ambient occlusion) + rim highlight per region
    dist = ndi.distance_transform_edt(al2[..., 0] > 0.5)
    ao = 1.0 - 0.10 * np.exp(-dist / (2.2 * scale))
    rim = 0.05 * np.exp(-((dist - 1.6 * scale) ** 2) / (2 * (0.7 * scale) ** 2))

    # ---- soft vertical sheen and gentle large-scale gradient
    yy = np.linspace(0, 1, rgb.shape[0], dtype=np.float32)[:, None]
    # use local (per-region) vertical gradient via label of connected components
    lab, n = ndi.label(al2[..., 0] > 0.5)
    sheen = np.zeros_like(lum)
    if n:
        objs = ndi.find_objects(lab)
        for i, sl in enumerate(objs, 1):
            if sl is None: continue
            hh = sl[0].stop - sl[0].start
            ww = sl[1].stop - sl[1].start
            if hh < 6 * scale or ww < 6 * scale: continue
            m = lab[sl] == i
            ty = np.linspace(0, 1, hh, dtype=np.float32)[:, None]
            tx = np.linspace(0, 1, ww, dtype=np.float32)[None, :]
            g = (0.5 - ty) * 0.07 + (0.5 - tx) * 0.025
            # glossy upper highlight band
            band = 0.05 * np.exp(-((ty - 0.12) ** 2) / 0.012)
            sheen[sl] += np.where(m, g + band, 0)

    # ---- fine material grain
    rng = np.random.default_rng(7)
    grain = rng.normal(0, 1, lum.shape).astype(np.float32)
    grain = ndi.gaussian_filter(grain, 0.6) * 0.007
    # brushed streaks (subtle) horizontal
    streak = ndi.gaussian_filter(rng.normal(0, 1, lum.shape).astype(np.float32), (0.4 * scale, 6 * scale)) * 0.35
    streak = np.clip(streak, -1, 1) * 0.005
    mid = (lum > 0.3).astype(np.float32)  # less grain in very dark flat bits

    out = rgb + (shade + sheen + rim + grain * 1.2 + streak) [..., None] * (0.6 + 0.6 * mid[..., None])
    out = out * ao[..., None]
    # slight colour richness: push saturation a touch
    l2 = (out @ np.array([0.299, 0.587, 0.114], np.float32))[..., None]
    out = l2 + (out - l2) * 1.07
    out = np.clip(out, 0, 1)

    if glare:
        for (x0, y0, x1, y1) in glare:
            x0, y0, x1, y1 = [int(v * scale) for v in (x0, y0, x1, y1)]
            hh, ww = y1 - y0, x1 - x0
            ty = np.linspace(0, 1, hh, dtype=np.float32)[:, None]
            tx = np.linspace(0, 1, ww, dtype=np.float32)[None, :]
            d = (tx * 0.9 + ty * 0.6) - 0.55
            g = 0.10 * np.exp(-(d ** 2) / 0.006) + 0.05 * np.exp(-((d - 0.22) ** 2) / 0.003)
            g *= (1 - 0.6 * ty)
            out[y0:y1, x0:x1] = np.clip(out[y0:y1, x0:x1] + g[..., None], 0, 1)

    res = np.zeros((rgb.shape[0], rgb.shape[1], 4), np.float32)
    res[..., :3] = out
    res[..., 3] = al2[..., 0]
    # tiny alpha pixels -> 0 so cutout stays clean
    res[..., 3] = np.where(res[..., 3] < 0.04, 0, res[..., 3])
    import cv2
    pmr = res.copy(); pmr[..., :3] *= pmr[..., 3:4]
    pmr = cv2.resize(pmr, (W, H), interpolation=cv2.INTER_AREA)
    a_ = pmr[..., 3:4]
    res = np.concatenate([np.where(a_ > 1e-4, pmr[..., :3] / np.maximum(a_, 1e-4), 0), a_], -1)
    res[..., 3] = np.where(res[..., 3] < 0.04, 0, res[..., 3])
    res8 = np.round(np.clip(res, 0, 1) * 255).astype(np.uint8)
    res8[:keep_rows] = swatch
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    Image.fromarray(res8, 'RGBA').save(dst, optimize=True)

if __name__ == '__main__':
    src_root, dst_root = sys.argv[1], sys.argv[2]
    tb = 'textures/block/'; ti = 'textures/item/'
    jobs = []
    for n in ['pc_case_atlas', 'pc_keyboard', 'pc_mouse']:
        jobs.append((tb + n + '.png', 4, None))
    for n in ['pc_monitor_on', 'pc_monitor_off']:
        jobs.append((tb + n + '.png', 4, [(8, 18, 170, 118)]))
    for f in sorted(glob.glob(src_root + ti + 'pc_*_3d.png')):
        jobs.append((ti + os.path.basename(f), 4, None))
    only = sys.argv[3:]
    for rel, sc, gl in jobs:
        if only and not any(o in rel for o in only): continue
        enhance(src_root + rel, dst_root + rel, sc, keep_rows=8 if 'block' in rel else 4, glare=gl)
        print('ok', rel)
