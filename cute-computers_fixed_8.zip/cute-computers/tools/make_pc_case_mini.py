#!/usr/bin/env python3
"""The compact PC case, drawn on its own (it is NOT the big tower squeezed any more).

  python3 tools/make_pc_case_mini.py [--preview]        (run from the repo root; after make_pc_case.py and make_pc_case_sizes.py,
                                                         BEFORE make_pc_colors.py, which only adds the lang / loot / item parts)

The design follows a small white "cube" case: a silver carry handle on top, a perforated top and back, one big glass
front, the power supply down in its own chamber under a vent plate, a huge tower cooler with a pink ring fan, the memory on the
right with a light bar, and the front panel (USB, audio, power button) on the right side next to the glass.

It keeps the same groups as the big case (body, glass, board, cpu, ram0..3, gpu1..4, disk, net, psu, cable, glow_*), so the
blockstate (blockstates/pc_case_mini.json + models/block/pc_case_mini_shared.json) does not change. It writes:
  textures/block/pc_case_mini_atlas.png (+ _<color> for the dyed bodies, painted by make_pc_colors.paint_pixel)
  models/block/pc_case_mini_<group>.json, pc_case_mini_item.json, pc_case_mini_{body,item}_<color>.json
Coordinates: the glass front is SOUTH (+z); the blockstate turns it with "y" for the other directions.
"""
import os, sys, json, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_pc_case as C
import make_pc_parts as P
import make_pc_colors as K
from PIL import Image, ImageDraw

RES, ATLAS = C.RES, C.ATLAS
WHT, WHT_D, WHT_L, LIL, LIL_D, DARK, DARK_L = C.WHT, C.WHT_D, C.WHT_L, C.LIL, C.LIL_D, C.DARK, C.DARK_L
PINK, PURP, CYAN, rgba, mix = C.PINK, C.PURP, C.CYAN, C.rgba, C.mix
panel, compose = C.panel, C.compose

# ------------------------------------------------------------------ the size of the case (block units, 16 = one block)
X0, X1 = 3.5, 12.5          # width
Y0, Y1 = 0.6, 12.6          # height of the shell (the handle goes above)
ZB, ZF = 4.8, 11.4          # back and front
BZ = 6.8                    # the front of the motherboard: every part on it starts here
GPU_LEN = {1: 3.6, 2: 4.4, 3: 5.2, 4: 6.0}
GPU_THK = {1: 0.9, 2: 1.2, 3: 1.6, 4: 2.0}
SHAPE = (3.4, 0.0, 4.8, 12.6, 13.7, 11.7)       # the hit box (PcCaseMiniBlock uses the same numbers)

SILVER = mix(WHT_D, LIL, .35)        # the handle posts: the same soft lilac plastic as the rest


# ------------------------------------------------------------------ the kawaii painters of this case
import random
OUT = P.OUT
GOLD, GOLD_D, GOLD_L = P.GOLD, P.GOLD_D, P.GOLD_L
lighter, darker = P.lighter, P.darker


def _cl(v): return 0 if v < 0 else 255 if v > 255 else v


def speckle(img, seed, p=.10, amt=5):
    """A little pixel grain over the light plastic (not over dark parts, holes or see-through glass), like the marbling of the monitors."""
    rnd = random.Random(seed)
    px = img.load()
    w, h = img.size
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if a < 200 or r + g + b < 330: continue
            if rnd.random() < p:
                k = rnd.randint(-amt, amt)
                px[x, y] = (_cl(r + k), _cl(g + k), _cl(b + k), a)


def soft(c, seed=1, grain=False):
    """Pastel plastic: a soft gradient, the dark purple outline, a bevel (light top-left, shade bottom-right) and a little grain."""
    def f(img, w, h):
        panel(c)(img, w, h)
        d = ImageDraw.Draw(img)
        if w > 7 and h > 7:
            d.line([(2, 2), (w - 3, 2)], fill=rgba(lighter(c, .8)))
            d.line([(2, 2), (2, h - 3)], fill=rgba(lighter(c, .6)))
            d.line([(w - 3, 3), (w - 3, h - 3)], fill=rgba(darker(c, .09)))
            d.line([(3, h - 3), (w - 3, h - 3)], fill=rgba(darker(c, .12)))
        if grain: speckle(img, seed * 977 + w * 7 + h)
    return f


def sparkle(cx, cy, r=3, c=(255, 255, 255), a=255):
    """A four-point twinkle."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        for k in range(1, r + 1):
            al = int(a * (1 - (k - 1) / (r + .5)))
            for q in ((cx + k, cy), (cx - k, cy), (cx, cy + k), (cx, cy - k)): d.point(q, fill=rgba(c, al))
        d.point((cx, cy), fill=rgba(c, a))
        for q in ((cx + 1, cy + 1), (cx - 1, cy - 1), (cx + 1, cy - 1), (cx - 1, cy + 1)): d.point(q, fill=rgba(c, a // 3))
    return p


def tiny_heart(cx, cy, c=PINK):
    """A 5x4 pixel heart for the thin bars."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        for (dx, dy) in ((-1, -1), (1, -1), (-2, 0), (-1, 0), (0, 0), (1, 0), (2, 0), (-1, 1), (0, 1), (1, 1), (0, 2)):
            d.point((cx + dx, cy + dy), fill=rgba(c))
        d.point((cx - 1, cy - 1), fill=rgba(lighter(c, .55)))
    return p


def heart_o(cx, cy, s=1, c=PINK):
    """A heart with a dark purple outline (a sticker heart)."""
    def p(img, w, h):
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (1, 1), (-1, 1)):
            P.heart(cx + dx, cy + dy, s, mix(c, OUT, .6))(img, w, h)
        P.heart(cx, cy, s, c)(img, w, h)
    return p


def paw(cx, cy, c=LIL, s=1):
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        d.ellipse([cx - 2 * s, cy, cx + 2 * s, cy + 2 * s + 1], fill=rgba(c))
        for dx, dy in ((-3, -2), (-1, -4), (1, -4), (3, -2)):
            d.ellipse([cx + dx * s - 1, cy + dy * s - 1, cx + dx * s + 1, cy + dy * s + 1], fill=rgba(c))
    return p


def sticker(cx, cy, hw, hh, inner, bg=WHT_L):
    """A rounded white sticker with a dark purple outline; `inner` is drawn on it."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([cx - hw, cy - hh + 1, cx + hw, cy + hh + 1], radius=7, fill=rgba(mix(LIL_D, OUT, .3), 120))
        d.rounded_rectangle([cx - hw, cy - hh, cx + hw, cy + hh], radius=7, fill=rgba(bg), outline=rgba(mix(LIL_D, OUT, .45)))
        d.line([(cx - hw + 4, cy - hh + 2), (cx + hw - 6, cy - hh + 2)], fill=rgba(WHT_L))
        inner(img, w, h)
    return p


def screw(cx, cy):
    """A tiny round screw head with a slot."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        d.ellipse([cx - 2, cy - 2, cx + 2, cy + 2], fill=rgba(WHT_D), outline=rgba(LIL_D))
        d.point((cx - 1, cy - 1), fill=rgba(WHT_L))
        d.line([(cx - 1, cy + 1), (cx + 1, cy - 1)], fill=rgba(mix(LIL_D, OUT, .4)))
    return p


def corner_screws(m=6):
    def p(img, w, h):
        for (x, y) in ((m, m), (w - m - 1, m), (m, h - m - 1), (w - m - 1, h - m - 1)):
            screw(x, y)(img, w, h)
    return p


def seam(y, x0=5, x1=None, c=None):
    """A thin panel seam: a dark line with a light line under it."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        xe = (w - 6) if x1 is None else x1
        d.line([(x0, y), (xe, y)], fill=rgba(c or mix(WHT_D, LIL_D, .45)))
        d.line([(x0, y + 1), (xe, y + 1)], fill=rgba(WHT_L))
    return p


def vent_slots(n, y0, step, half, hh=3):
    """Long rounded vent slots, each with a dark inside, a shadow on top and a light lip below."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        for i in range(n):
            y = y0 + i * step
            d.rounded_rectangle([w // 2 - half, y, w // 2 + half, y + hh], radius=1, fill=rgba(mix(WHT_D, DARK, .32)), outline=rgba(mix(LIL_D, OUT, .35)))
            d.line([(w // 2 - half + 1, y + 1), (w // 2 + half - 1, y + 1)], fill=rgba(mix(DARK, DARK_L, .5)))
            d.line([(w // 2 - half + 1, y + hh + 1), (w // 2 + half - 1, y + hh + 1)], fill=rgba(WHT_L))
    return p


def stripes(h_):
    """The pastel stripe at the bottom of a side: lilac, pink and a thin cyan line."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        d.rectangle([6, h - 17, w - 7, h - 14], fill=rgba(LIL))
        d.line([(6, h - 17), (w - 7, h - 17)], fill=rgba(lighter(LIL, .5)))
        d.rectangle([6, h - 13, w - 7, h - 11], fill=rgba(PINK))
        d.line([(6, h - 10), (w - 7, h - 10)], fill=rgba(C.led_off(CYAN)))
    return p


def mesh_cute(heart=False, pitch=7, r=1.7, border=5, heart_at=(.5, .8), heart_r=11):
    """The perforated panel (like the big case, with the same fine holes): a little depth in every hole, some of them pink (a heart)."""
    def p(img, w, h):
        soft(WHT, 3)(img, w, h)
        d = ImageDraw.Draw(img)
        cx0, cy0 = w * heart_at[0], h * heart_at[1]
        row = 0
        for y in range(border + 3, h - border - 2, pitch):
            off = pitch // 2 if row % 2 else 0
            for x in range(border + 3 + off, w - border - 2, pitch):
                hx, hy = (x - cx0) / heart_r, -(y - cy0) / heart_r + .15
                inside = heart and ((hx * hx + hy * hy - 1) ** 3 - hx * hx * hy ** 3) <= 0
                col = (252, 168, 206) if inside else (190, 182, 216)
                d.ellipse([x - r, y - r, x + r, y + r], fill=rgba(col))
                d.arc([x - r, y - r, x + r, y + r], 180, 270, fill=rgba(darker(col, .45)))
                d.point((int(x + r - 1), int(y + r - 1)), fill=rgba(WHT_L))
                if inside: d.point((x - 1, y - 1), fill=rgba(lighter(col, .6)))
            row += 1
        corner_screws(4)(img, w, h)
    return p


def side_cute():
    """The left side: seven vent slots, a small heart badge, a quiet name, a pastel stripe, screws."""
    def p(img, w, h):
        soft(WHT, 5)(img, w, h)
        vent_slots(7, 12, 8, w // 2 - 14)(img, w, h)
        seam(72)(img, w, h)
        sticker(w // 2, 94, 13, 13, compose(heart_o(w // 2, 91, 2, PINK), sparkle(w // 2 + 8, 84, 2, (255, 230, 150))))(img, w, h)
        C.text('CUTE', w // 2, 118, LIL_D, 8)(img, w, h)
        tiny_heart(w // 2 - 14, 118)(img, w, h)
        tiny_heart(w // 2 + 14, 118)(img, w, h)
        seam(h - 22)(img, w, h)
        stripes(h)(img, w, h)
        corner_screws(6)(img, w, h)
    return p


def east_cute():
    """The right side: a round badge with small cat ears and a heart, the name, a pastel stripe, screws."""
    def p(img, w, h):
        soft(WHT, 9)(img, w, h)
        d = ImageDraw.Draw(img)
        vent_slots(3, 12, 8, w // 2 - 20, 2)(img, w, h)
        seam(40)(img, w, h)
        cx, cy = w // 2, 78
        for sx in (-1, 1):                                                       # the ears
            d.polygon([(cx + sx * 13, cy - 8), (cx + sx * 7, cy - 19), (cx + sx * 2, cy - 13)], fill=rgba(WHT_L), outline=rgba(mix(LIL_D, OUT, .45)))
            d.polygon([(cx + sx * 10, cy - 11), (cx + sx * 7, cy - 16), (cx + sx * 5, cy - 12)], fill=rgba(PINK))
        d.ellipse([cx - 15, cy - 15, cx + 15, cy + 15], fill=rgba(WHT_L), outline=rgba(mix(LIL_D, OUT, .45)))
        d.ellipse([cx - 12, cy - 12, cx + 12, cy + 12], outline=rgba(LIL))
        heart_o(cx, cy - 3, 2, PINK)(img, w, h)
        sparkle(cx + 10, cy - 10, 2, (255, 230, 150))(img, w, h)
        C.text('CUTE FLOW', w // 2, 106, LIL_D, 8)(img, w, h)
        seam(h - 22)(img, w, h)
        stripes(h)(img, w, h)
        corner_screws(6)(img, w, h)
    return p


def glass_cute():
    """Clear glass with two soft reflections, a pink haze at the bottom and a few twinkles."""
    base = C.glass()
    def p(img, w, h):
        base(img, w, h)
        d = ImageDraw.Draw(img)
        for y in range(int(h * .84), h - 1):
            t = (y - h * .84) / (h * .16)
            d.line([(1, y), (w - 2, y)], fill=(255, 208, 232, int(34 + 44 * t)))
        for fx, fy, r, c, a in ((.16, .12, 3, (255, 255, 255), 240), (.82, .26, 2, (255, 214, 232), 230), (.60, .80, 2, (206, 224, 255), 230), (.28, .58, 2, (255, 255, 255), 210)):
            sparkle(int(w * fx), int(h * fy), r, c, a)(img, w, h)
    return p


def lip_cute():
    """The bottom bar: the name between two tiny hearts and a strip of light that melts from pink to violet to cyan."""
    def p(img, w, h):
        soft(WHT, 11)(img, w, h)
        d = ImageDraw.Draw(img)
        stops = [PINK, PURP, CYAN]
        for x in range(3, w - 3):
            t = (x - 3) / max(1, w - 7) * (len(stops) - 1)
            k = min(int(t), len(stops) - 2)
            d.line([(x, h - 4), (x, h - 3)], fill=rgba(C.led_off(mix(stops[k], stops[k + 1], t - k))))
        tiny_heart(int(w * .10), h // 2 - 1)(img, w, h)
        tiny_heart(int(w * .90), h // 2 - 1)(img, w, h)
        C.text('C U T E   F L O W', w // 2, h // 2 - 1, LIL_D, 9)(img, w, h)
    return p


def lip_glow():
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        stops = [PINK, PURP, CYAN]
        for x in range(3, w - 3):
            t = (x - 3) / max(1, w - 7) * (len(stops) - 1)
            k = min(int(t), len(stops) - 2)
            d.line([(x, h - 4), (x, h - 3)], fill=rgba(lighter(mix(stops[k], stops[k + 1], t - k), .3)))
        C.text('C U T E   F L O W', w // 2, h // 2 - 1, lighter(PURP, .4), 9)(img, w, h)
    return p


def post_cute():
    def p(img, w, h):
        soft(WHT, 13)(img, w, h)
        d = ImageDraw.Draw(img)
        if w >= 4:
            for y in range(12, h - 8, 26):
                d.ellipse([w // 2 - 1, y - 1, w // 2 + 1, y + 1], fill=rgba(WHT_D), outline=rgba(LIL_D))
    return p


def vent_plate():
    """The plate over the power supply chamber: rounded slots with a pink glow inside, twinkles, the name and a heart."""
    def p(img, w, h):
        soft(WHT, 15)(img, w, h)
        d = ImageDraw.Draw(img)
        for i in range(5):
            x0 = int(w * (.08 + i * .18)); x1 = x0 + int(w * .13)
            d.rounded_rectangle([x0, int(h * .16), x1, int(h * .42)], radius=3, fill=rgba(DARK_L), outline=rgba(mix(LIL_D, OUT, .4)))
            d.line([(x0 + 2, int(h * .38)), (x1 - 2, int(h * .38))], fill=rgba(PINK, 170))
            d.line([(x0 + 2, int(h * .19)), (x1 - 2, int(h * .19))], fill=rgba(DARK, 255))
        for fx, fy in ((.17, .62), (.60, .58), (.88, .64)):
            sparkle(int(w * fx), int(h * fy), 2, (255, 214, 232) if fx < .5 else (206, 224, 255), 220)(img, w, h)
        tiny_heart(int(w * .38), int(h * .80))(img, w, h)
        C.text('CUTE', int(w * .5), int(h * .80), LIL_D, 9)(img, w, h)
        tiny_heart(int(w * .62), int(h * .80))(img, w, h)
    return p


def tray_cute():
    """The tray behind the board: a big round cut-out behind the processor, rounded cable holes, screws and a few twinkles."""
    def p(img, w, h):
        soft(mix(WHT, WHT_D, .35), 17)(img, w, h)
        d = ImageDraw.Draw(img)
        u = P.D
        cx, cy, r = int(2.2 * u), int(2.9 * u), int(1.7 * u)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=rgba(mix(WHT_D, DARK, .3)), outline=rgba(LIL_D))
        d.arc([cx - r + 2, cy - r + 2, cx + r - 2, cy + r - 2], 200, 330, fill=rgba(DARK_L))
        for (x0, y0, x1, y1) in ((7.1, 1.0, 7.7, 4.0), (7.1, 5.0, 7.7, 7.6), (.35, 1.0, .9, 3.5)):
            d.rounded_rectangle([int(x0 * u), int(y0 * u), int(x1 * u), int(y1 * u)], radius=3, fill=rgba(DARK_L), outline=rgba(LIL_D))
        for (x, y) in ((1.0, .6), (7.0, .6), (1.0, 7.6), (7.0, 7.6), (4.4, 7.6)):
            d.ellipse([int(x * u) - 2, int(y * u) - 2, int(x * u) + 2, int(y * u) + 2], fill=rgba(WHT_D), outline=rgba(LIL_D))
        sparkle(int(4.6 * u), int(2.2 * u), 2, (255, 255, 255), 160)(img, w, h)
        sparkle(int(5.6 * u), int(5.6 * u), 2, (255, 214, 232), 160)(img, w, h)
    return p


def handle_front():
    """The carry handle seen from the front: soft lilac-white plastic with fine grip ribs, a pastel line and a tiny pink heart."""
    def p(img, w, h):
        base = mix(WHT_D, LIL, .35)
        panel(base, True, False)(img, w, h)
        d = ImageDraw.Draw(img)
        for x in range(3, w - 3, 3):
            d.line([(x, 2), (x, h - 3)], fill=rgba(darker(base, .10), 150))
            d.line([(x + 1, 2), (x + 1, h - 3)], fill=rgba(WHT_L, 170))
        d.line([(1, 1), (w - 2, 1)], fill=rgba(WHT_L))
        d.line([(1, h - 2), (w - 2, h - 2)], fill=rgba(LIL_D))
        if h >= 6: tiny_heart(w // 2, h // 2 - 1)(img, w, h)
    return p


def handle_top():
    def p(img, w, h):
        panel(mix(WHT, LIL, .2), True, False)(img, w, h)
        d = ImageDraw.Draw(img)
        for y in range(2, h - 1, 3):
            d.line([(1, y), (w - 2, y)], fill=rgba(mix(WHT_D, LIL_D, .3), 150))
        d.line([(3, h // 2), (w - 4, h // 2)], fill=rgba(PINK, 150))
        sparkle(int(w * .2), h // 2, 2, (255, 255, 255), 230)(img, w, h)
    return p


def power_button():
    """The round power button on the top: a white ring with a cyan light and a little pink dot."""
    def p(img, w, h):
        soft(WHT_D, 21, False)(img, w, h)
        d = ImageDraw.Draw(img)
        d.ellipse([1, 1, w - 2, h - 2], fill=rgba(WHT), outline=rgba(LIL_D))
        d.ellipse([w // 2 - 2, h // 2 - 2, w // 2 + 2, h // 2 + 2], outline=rgba(C.led_off(CYAN)), width=1)
        d.point((w // 2 - 1, h // 2 - 1), fill=rgba(PINK))
    return p


def io_cute():
    def p(img, w, h):
        C.io_panel()(img, w, h)
        sparkle(int(w * .72), h // 2, 1, (255, 214, 232), 230)(img, w, h)
    return p


def standoff():
    """A round white knob that holds a corner of the glass."""
    def p(img, w, h):
        panel(WHT_L)(img, w, h)
        d = ImageDraw.Draw(img)
        d.ellipse([1, 1, w - 2, h - 2], fill=rgba(WHT), outline=rgba(LIL_D))
        d.point((w // 3, h // 3), fill=rgba(WHT_L))
        d.point((w // 2, h // 2), fill=rgba(PINK))
    return p


def ring_fan(cx, cy, r, led, blades=7):
    """The big cooler fan: wide white blades that shade to lilac on a pale disc, inside a thick ring of light, a heart on the hub, twinkles."""
    def p(img, w, h):
        d = ImageDraw.Draw(img)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=rgba(mix(DARK, LIL, .35)))
        d.ellipse([cx - r + 3, cy - r + 3, cx + r - 3, cy + r - 3], fill=rgba(mix(DARK_L, LIL, .45)))
        rh = max(4, r // 4)
        for i in range(blades):
            a0 = i * 2 * math.pi / blades
            for t in range(rh, r - 4):
                a = a0 + (t - rh) * 0.055
                x, y = cx + math.cos(a) * t, cy + math.sin(a) * t
                k = (t - rh) / r
                wd = 1.8 + 2.6 * k
                d.ellipse([x - wd, y - wd, x + wd, y + wd], fill=rgba(mix(WHT_L, LIL, .05 + .35 * k)))
            for t in range(rh, r - 4, 2):                                          # the dark trailing edge of the blade
                a = a0 + (t - rh) * 0.055 + 0.20
                d.point((int(cx + math.cos(a) * t), int(cy + math.sin(a) * t)), fill=rgba(LIL_D))
            for t in range(rh + 2, r - 6, 3):                                      # and a bright leading edge
                a = a0 + (t - rh) * 0.055 - 0.16
                d.point((int(cx + math.cos(a) * t), int(cy + math.sin(a) * t)), fill=rgba(WHT_L))
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=rgba(led), width=3)            # the ring of light
        d.ellipse([cx - r + 3, cy - r + 3, cx + r - 3, cy + r - 3], outline=rgba(lighter(led, .55)), width=1)
        d.ellipse([cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1], outline=rgba(mix(led, OUT, .55)), width=1)
        d.ellipse([cx - rh, cy - rh, cx + rh, cy + rh], fill=rgba(WHT), outline=rgba(LIL_D))
        tiny_heart(cx, cy - 1, led)(img, w, h)
        d.point((cx - rh + 2, cy - rh + 2), fill=rgba(WHT_L))
    return p


def ring_glow(cx, cy, r, led):
    """The ring of the cooler fan shining (a PC that is on): a bright ring, a soft halo and four twinkles."""
    def p(img, w, h):
        C.fan_at(cx, cy, r, led, True)(img, w, h)
        for sx, sy in ((1, -1), (-1, 1), (1, 1), (-1, -1)):
            sparkle(int(cx + sx * r * .72), int(cy + sy * r * .72), 2, lighter(led, .6), 230)(img, w, h)
    return p


ROSE, ROSE_D, ROSE_L = (238, 188, 214), (186, 126, 164), (255, 226, 240)     # the heat pipes: soft rose metal instead of loud gold


def cooler_front():
    """The front of the cooler: a white frame with a seam, four screws and the big fan (white blades, a lilac ring like the fans of the big case)."""
    def p(img, w, h):
        soft(WHT, 23)(img, w, h)
        d = ImageDraw.Draw(img)
        r = int(min(w, h) * .42)
        d.rounded_rectangle([5, 5, w - 6, h - 6], radius=5, outline=rgba(mix(WHT_D, LIL_D, .4)))
        ring_fan(w // 2, h // 2, r, PURP)(img, w, h)
        for (x, y) in ((8, 8), (w - 9, 8), (8, h - 9), (w - 9, h - 9)):
            screw(x, y)(img, w, h)
    return p


def cooler_top():
    """The top of the cooler: thin fins and three rose heat pipes."""
    def p(img, w, h):
        panel(P.METAL, True, False)(img, w, h)
        d = ImageDraw.Draw(img)
        for x in range(2, w - 1, 3):
            d.line([(x, 1), (x, h - 2)], fill=rgba(darker(P.METAL, .22)))
            d.line([(x + 1, 1), (x + 1, h - 2)], fill=rgba(P.METAL_L))
        for fx in (.25, .5, .75):
            cx, cy, r = int(w * fx), h // 2, max(3, min(w, h) // 6)
            d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=rgba(ROSE), outline=rgba(ROSE_D))
            d.point((cx - 1, cy - 1), fill=rgba(ROSE_L))
    return p


def cooler_side():
    """The side of the cooler: fins in rows, rose heat pipes running through them and a lilac clamp at the bottom."""
    def p(img, w, h):
        panel(P.METAL, True, False)(img, w, h)
        d = ImageDraw.Draw(img)
        for y in range(2, h - 1, 3):
            d.line([(1, y), (w - 2, y)], fill=rgba(darker(P.METAL, .25)))
            d.line([(1, y + 1), (w - 2, y + 1)], fill=rgba(P.METAL_L))
        for fx in (.3, .7):
            x = int(w * fx)
            d.rectangle([x - 1, 2, x + 1, h - 3], fill=rgba(ROSE), outline=rgba(ROSE_D))
            d.line([(x - 1, 2), (x - 1, h - 3)], fill=rgba(ROSE_L))
        d.rectangle([1, h - 7, w - 2, h - 3], fill=rgba(LIL), outline=rgba(LIL_D))
        d.line([(2, h - 6), (w - 3, h - 6)], fill=rgba(WHT_L))
    return p


def psu_front():
    """The power supply: a round grill fan, a pastel label with the name and two tiny hearts."""
    def p(img, w, h):
        C.psu_front()(img, w, h)
        tiny_heart(int(w * .575), int(h * .32))(img, w, h)
        tiny_heart(int(w * .885), int(h * .32))(img, w, h)
        sparkle(int(w * .965), int(h * .16), 2, (255, 255, 255), 230)(img, w, h)
    return p


def build_case():
    M = P.Model()
    P.Model.img = None

    def solid_to_panel(spec):
        return panel(spec, False, False) if isinstance(spec, tuple) else spec

    def add(group, name, frm, to, **faces):
        if group == 'body':
            faces = {k: solid_to_panel(v) for k, v in faces.items()}     # every body face is a painted panel, so the dyed variants take the colour
        n0 = len(M.els)
        M.box(name, frm, to, **faces)
        for e in M.els[n0:]: e['group'] = group

    # ---- the shell
    add('body', 'back', (X0, Y0, ZB), (X1, Y1, 5.4), north=mesh_cute(), south=WHT_D, east=WHT, west=WHT, up=WHT, down=WHT_D)
    add('body', 'left', (X0, Y0, 5.4), (3.9, Y1, 11.0), west=side_cute(), east=WHT_D, south=WHT, north=WHT, up=WHT, down=WHT_D)
    add('body', 'right', (12.1, Y0, 5.4), (X1, Y1, 11.0), east=east_cute(), west=WHT_D, south=WHT, north=WHT, up=WHT, down=WHT_D)
    add('body', 'top', (3.9, 12.2, 5.4), (12.1, Y1, 11.0), up=mesh_cute(heart=True), down=WHT_D, south=WHT, north=WHT, east=WHT, west=WHT)
    add('body', 'floor', (3.9, Y0, 5.4), (12.1, 0.9, 11.0), up=mesh_cute(), down=DARK, south=WHT, north=WHT, east=WHT, west=WHT)
    # the frame of the glass: the top bar, the bottom bar with the name, two posts
    add('body', 'topfront', (3.9, 12.2, 11.0), (12.1, Y1, ZF), south=soft(WHT, 12), up=WHT, down=WHT_D, east=WHT, west=WHT, north=WHT)
    add('body', 'lip', (X0, Y0, 11.0), (X1, 1.5, ZF), south=lip_cute(), up=WHT, down=DARK, east=WHT, west=WHT, north=WHT)
    add('body', 'post_l', (X0, 1.5, 11.0), (3.9, Y1, ZF), south=post_cute(), up=WHT, down=WHT_D, east=WHT, west=WHT, north=WHT)
    add('body', 'post_r', (12.1, 1.5, 11.0), (X1, Y1, ZF), south=post_cute(), up=WHT, down=WHT_D, east=WHT, west=WHT, north=WHT)
    for k, (x, z) in enumerate(((4.1, 5.7), (11.0, 5.7), (4.1, 10.0), (11.0, 10.0))):            # the little round feet
        add('body', 'foot%d' % k, (x, 0.0, z), (x + 0.9, 0.6, z + 0.9), all=(70, 64, 92), down=(40, 34, 60))
    # the two chambers: a vent plate between them, the tray behind the board
    add('body', 'shroud', (3.9, 3.7, 5.4), (12.1, 4.1, 11.0), up=vent_plate(), south=soft(WHT, 14), down=WHT_D, north=WHT, east=WHT, west=WHT)
    add('body', 'tray', (3.9, 4.1, 5.6), (12.1, 12.2, 6.2), south=tray_cute(), north=WHT_D, up=WHT, down=WHT_D, east=WHT, west=WHT)
    # the front panel on the right side (the USB, the audio and the power button), the button on the top
    add('body', 'io', (X1, 10.6, 7.6), (12.62, 11.8, 11.0), east=io_cute(), up=WHT_L, down=DARK, south=WHT, north=WHT, west=WHT)
    add('body', 'button', (11.3, Y1, 9.9), (12.0, 12.72, 10.6), up=power_button(), south=WHT_D, north=WHT_D, east=WHT_D, west=WHT_D, down=WHT_D)
    # the carry handle: a silver bar on two posts (not dyed: it keeps its metal)
    add('body', 'handle_bar', (4.6, 13.1, 7.5), (11.4, 13.7, 8.7), south=handle_front(), north=handle_front(), up=handle_top(), down=LIL_D, east=LIL, west=LIL)
    add('body', 'handle_post_l', (4.6, Y1, 7.5), (5.2, 13.1, 8.7), all=LIL_D, south=SILVER, north=SILVER)
    add('body', 'handle_post_r', (10.8, Y1, 7.5), (11.4, 13.1, 8.7), all=LIL_D, south=SILVER, north=SILVER)
    # the knobs that hold the glass in the four corners (not dyed either)
    for k, (x, y) in enumerate(((3.55, 1.45), (12.0, 1.45), (3.55, 11.9), (12.0, 11.9))):
        add('body', 'knob%d' % k, (x, y, ZF), (x + 0.45, y + 0.45, ZF + 0.22), south=standoff(), up=WHT_L, down=WHT_D, east=WHT, west=WHT, north=WHT)

    # ---- the glass: the whole front
    P.D = 8
    glass_c = (214, 224, 246)
    add('glass', 'front', (3.9, 1.5, 11.0), (12.1, 12.2, ZF), south=glass_cute(), north=C.glass(), up=glass_c, down=glass_c, east=glass_c, west=glass_c)
    P.D = 12

    # ---- the motherboard (a square little ITX board) and its sockets
    add('board', 'pcb', (4.1, 5.0, BZ - 0.6), (11.2, 11.8, BZ), south=C.pcb_face(), north=WHT_D, up=LIL, down=LIL, east=LIL, west=LIL)
    add('board', 'socket', (5.1, 8.3, BZ), (7.1, 10.3, BZ + 0.3), all=DARK)
    add('board', 'socketface', (5.1, 8.3, BZ + 0.3), (7.1, 10.3, BZ + 0.32), south=C.socket_face(), all=DARK)
    for i in range(4):
        x = 8.3 + i * 0.55
        add('board', 'slot%d' % i, (x, 7.2, BZ), (x + 0.4, 11.6, BZ + 0.4), all=DARK, south=C.slot_face(), up=DARK_L)
    add('board', 'pcie16', (4.4, 6.9, BZ), (9.6, 7.2, BZ + 0.5), all=DARK, south=C.slot_face(), up=DARK_L)

    # ---- the processor with its big tower cooler (one pink ring fan, as wide as the cooler)
    add('cpu', 'cooler', (4.1, 7.3, BZ + 0.3), (8.1, 11.3, BZ + 3.3),
        south=cooler_front(), north=P.METAL_D,
        up=cooler_top(), down=P.METAL_D, east=cooler_side(), west=cooler_side())

    # ---- the memory: four sticks with a light bar along their edge
    for i in range(4):
        x = 8.3 + i * 0.55
        add('ram%d' % i, 'stick', (x, 7.4, BZ + 0.1), (x + 0.4, 11.4, BZ + 1.5),
            south=C.rgb_bar(True, False), east=C.dimm_side(), west=C.dimm_side(), up=P.METAL_L, down=DARK, north=DARK)

    # ---- the video cards, one model for each level (the longer and thicker, the better); they hang under the cooler
    for t in (1, 2, 3, 4):
        L, T = GPU_LEN[t], GPU_THK[t]
        add('gpu%d' % t, 'shroud', (4.3, 7.2 - T, BZ + 0.2), (4.3 + L, 7.2, BZ + 3.8),
            south=C.gpu_front(t), up=C.gpu_top(t), north=DARK, down=DARK, east=panel(mix(DARK, C.GPU_ACC[t], .2)), west=panel(mix(DARK, C.GPU_ACC[t], .2)))
        add('gpu%d' % t, 'bracket', (3.95, 7.2 - T - 0.1, BZ + 0.2), (4.3, 7.25, BZ + 3.9), west=C.bracket_end(), east=P.METAL_D, south=P.METAL, north=P.METAL_D, up=P.METAL_L, down=P.METAL_D)

    # ---- the drive (an M.2 stick standing next to the memory), the network card
    add('disk', 'm2', (10.45, 7.4, BZ), (10.95, 10.4, BZ + 0.2), all=(120, 190, 170))
    add('disk', 'sink', (10.5, 7.45, BZ + 0.2), (10.9, 10.35, BZ + 0.45), south=C.m2_label(), up=LIL, down=LIL_D, east=LIL_D, west=LIL_D, north=LIL_D)
    add('net', 'card', (10.45, 5.3, BZ), (11.05, 6.3, BZ + 1.6), south=C.net_card(), all=(120, 190, 170))

    # ---- the power supply (down in its own chamber) and its thick cable up to the board
    add('psu', 'box', (4.6, 0.9, 5.8), (11.8, 3.7, 10.6), south=psu_front(), up=(180, 176, 206), down=DARK, east=(180, 176, 206), west=(180, 176, 206), north=(170, 166, 196))
    add('cable', 'ribbon', (11.4, 4.1, BZ + 0.1), (11.9, 10.6, BZ + 0.7), south=C.ribbon(), all=DARK)
    add('cable', 'ribbon_low', (11.4, 3.7, BZ + 0.1), (11.9, 4.1, BZ + 0.7), all=DARK)

    # ---- the glow of a PC that is on: overlays right in front of the lights (lit = true)
    G = 0.02
    add('glow_base', 'io', (X1 + 0.12, 10.6, 7.6), (X1 + 0.12 + G, 11.8, 11.0), east=C.io_panel(True), all=(0, 0, 0))
    add('glow_base', 'lip', (X0, Y0, ZF), (X1, 1.5, ZF + G), south=lip_glow(), all=(0, 0, 0))
    add('glow_cpu', 'fan', (4.1, 7.3, BZ + 3.3), (8.1, 11.3, BZ + 3.3 + G),
        south=ring_glow(int(2.0 * P.D), int(2.0 * P.D), int(min(4.0, 4.0) * P.D * .42), PURP), all=(0, 0, 0))
    for i in range(4):
        x = 8.3 + i * 0.55
        add('glow_ram%d' % i, 'bar', (x, 7.4, BZ + 1.5), (x + 0.4, 11.4, BZ + 1.5 + G), south=C.rgb_bar(True, True), all=(0, 0, 0))
    for t in (1, 2, 3, 4):
        L, T = GPU_LEN[t], GPU_THK[t]
        add('glow_gpu%d' % t, 'bar', (4.3, 7.2 - T, BZ + 3.8), (4.3 + L, 7.2, BZ + 3.8 + G), south=C.gpu_front(t, True), all=(0, 0, 0))
    add('glow_net', 'led', (10.45, 5.3, BZ + 1.6), (11.05, 6.3, BZ + 1.6 + G),
        south=lambda img, w, h: ImageDraw.Draw(img).rectangle([1, h - 4, w - 2, h - 3], fill=rgba(C.lighter(CYAN, .4))), all=(0, 0, 0))
    return M


# ------------------------------------------------------------------ writing
def body_rects(M):
    """The atlas rectangles that hold the dyeable body (everything of the body except the silver handle and the knobs)."""
    rects = []
    for e in M.els:
        if e['group'] != 'body' or e['name'].startswith(('handle', 'knob')):
            continue
        for f in e['faces'].values():
            u1, v1, u2, v2 = [c * ATLAS / 16 for c in f['uv']]
            if u2 - u1 < 1.2 and v2 - v1 < 1.2:
                continue                                    # a shared one-colour swatch: never dyed
            rects.append((int(u1), int(v1), int(math.ceil(u2)) - 1, int(math.ceil(v2)) - 1))
    return rects


def write(M):
    used = int(M.y + M.rowh + 2)
    H = min(ATLAS, (used + 15) // 16 * 16)               # as short as the pictures allow
    img = M.img.crop((0, 0, ATLAS, H))
    img.save(os.path.join(RES, 'textures/block/pc_case_mini_atlas.png'))
    k = ATLAS / H                                           # v coordinates are 0..16 over the (shorter) atlas now

    def els_for(group):
        out = []
        for e in M.els:
            if e['group'] != group: continue
            ee = json.loads(json.dumps(C.clean(e, group.startswith('glow_'))))        # a copy: the shared faces must not be scaled twice
            for f in ee['faces'].values():
                f['uv'] = [f['uv'][0], round(f['uv'][1] * k, 6), f['uv'][2], round(f['uv'][3] * k, 6)]
            out.append(ee)
        return out

    def model(name, els, render, glow=False):
        m = {"credit": "generated by tools/make_pc_case_mini.py", "ambientocclusion": False, "texture_size": [ATLAS, H],
             "textures": {"particle": "cutemod:block/pc_case_mini_atlas", "t": "cutemod:block/pc_case_mini_atlas"},
             "elements": els, "render_type": render}
        if glow:
            for e in m["elements"]:
                e["shade"] = False
        json.dump(m, open(os.path.join(RES, 'models/block/%s.json' % name), 'w'), indent=1)

    groups = sorted({e['group'] for e in M.els})
    for g in groups:
        glow = g.startswith('glow_')
        render = 'minecraft:translucent' if (glow or g == 'glass') else 'minecraft:cutout'
        model('pc_case_mini_' + g, els_for(g), render, glow)
    model('pc_case_mini_item', els_for('body') + els_for('glass'), 'minecraft:translucent')

    # the dyed bodies: the same models with the painted atlas
    rects = body_rects(M)
    for c in K.COLORS:
        K.paint('pc_case_mini_atlas', 'pc_case_mini_atlas_' + c, c, rects=rects)
        tex = 'cutemod:block/pc_case_mini_atlas_' + c
        for kind in ('body', 'item'):
            json.dump({"parent": 'cutemod:block/pc_case_mini_' + kind, "textures": {"particle": tex, "t": tex}},
                      open(os.path.join(RES, 'models/block/pc_case_mini_%s_%s.json' % (kind, c)), 'w'), indent=1)
    print('mini case: %d elements in %d groups, atlas %dx%d' % (len(M.els), len(groups), ATLAS, H))


def preview(M):
    def pick(gs): return [e for e in M.els if e['group'] in gs]
    base = ['body', 'glass']
    full = base + ['board', 'cpu', 'ram0', 'ram1', 'gpu3', 'disk', 'psu', 'cable', 'net']
    on = full + ['glow_base', 'glow_cpu', 'glow_ram0', 'glow_ram1', 'glow_gpu3', 'glow_net']
    views = [(base, 32, 18), (full, 32, 18), (on, 32, 18), (base, -38, 22), (on, 0, 6), (on, 72, 18)]
    tiles = [C.render(pick(g), M.img, 24, ay, ax, center=(8, 7, 8)) for g, ay, ax in views]
    W, H = tiles[0].size
    sheet = Image.new('RGBA', (W * 3, H * 2), (88, 84, 104, 255))
    for i, t in enumerate(tiles): sheet.paste(t, ((i % 3) * W, (i // 3) * H))
    sheet.save('/tmp/pc_case_mini_preview.png')
    print('preview: /tmp/pc_case_mini_preview.png')


if __name__ == '__main__':
    M = build_case()
    if '--preview' in sys.argv: preview(M)
    write(M)
