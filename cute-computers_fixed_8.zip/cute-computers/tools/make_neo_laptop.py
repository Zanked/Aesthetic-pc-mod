"""Generates the slim "Neo" laptops (textures + block models). Run from the project root: python3 tools/make_neo_laptop.py

Per colour, in assets/cutemod/textures/block (every texture has the aspect of the face it is mapped onto, uv 0..16):
  <c>_neo_deck    the keyboard deck: perforated speaker grills, island keys with their own icons, a glass trackpad, a glowing power key
  <c>_neo_screen  the lid, front: a thin glossy bezel with a camera and a little night landscape wallpaper (moon, hills, a cat, dock, widget)
  <c>_neo_back    the lid, back: pearly metal with a raised cat-eared heart and tiny sparkles
  <c>_neo_side_l / _neo_side_r  the left / right edge with the ports      <c>_neo_hinge  the hinge barrel      <c>_neo_body  the plain metal
The screen glows in the dark (neoforge_data light on that face). Our own look: no brand names or logos.
"""
import json, math, os, random, sys
from PIL import Image, ImageDraw

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from laptop_art import *   # noqa

TEX = 'src/main/resources/assets/cutemod/textures/block/'
MOD = 'src/main/resources/assets/cutemod/models/block/'

# colour -> metal, accent (keys / glow), night sky (top, middle, horizon), moon
COLORS = {
    'pink':   dict(metal=0xF3CDD2, accent=0xFF6FA0, sky=(0x3B2262, 0xB4508C, 0xFFB9C6), moon=0xFFF0C8),
    'green':  dict(metal=0xBFE3C9, accent=0x2FBF8A, sky=(0x0F3A40, 0x2E9C86, 0xAEF5CF), moon=0xF4FFD0),
    'white':  dict(metal=0xE4E7ED, accent=0x7C8CD8, sky=(0x262E58, 0x6F7DBE, 0xD2DCFA), moon=0xFFFFFF),
    'blue':   dict(metal=0x7F8BD6, accent=0x9FB4FF, sky=(0x121552, 0x3A44B2, 0x9AB6FF), moon=0xFFF3C4),
    'orange': dict(metal=0xF8C8A2, accent=0xFF8A3D, sky=(0x4A1B34, 0xD85F3C, 0xFFD08A), moon=0xFFF4D0),
    'purple': dict(metal=0xC9B6EC, accent=0xA46BFF, sky=(0x261658, 0x7A4CC8, 0xE0B8FF), moon=0xFFF2FF),
    'yellow': dict(metal=0xF5E58F, accent=0xFFA62B, sky=(0x5E2A5C, 0xEE8A3C, 0xFFE08A), moon=0xFFF9DA),
    'red':    dict(metal=0xF3988F, accent=0xE8445E, sky=(0x35102C, 0xC02E4A, 0xFFB09C), moon=0xFFE9C8),
}

# ------------------------------------------------------------------------------------------------ the keyboard
ROWS = [
    [1.5] + [1] * 12 + [1.5],                      # esc, F1..F12, power
    [1] * 13 + [2],                                 # ` 1..0 - =  backspace
    [1.5] + [1] * 12 + [1.5],
    [1.75] + [1] * 11 + [2.25],
    [2.25] + [1] * 10 + [2.75],
    [1.25, 1.25, 1.25, 5.75, 1.25, 1.25, 1, 1, 1],  # modifiers, space bar, arrows (the middle arrow is two half keys)
]


def layout(x0, x1, y0, y1, gap=1.15, fn_scale=0.62, rows=ROWS):
    hu = ((y1 - y0) - gap * (len(rows) - 1)) / (len(rows) - 1 + fn_scale)
    y = y0
    out = []
    for ri, units in enumerate(rows):
        h = hu * (fn_scale if ri == 0 else 1.0)
        n = len(units)
        free = (x1 - x0) - gap * (n - 1)
        x = x0
        row = []
        for ci, u in enumerate(units):
            w = free * u / sum(units)
            row.append(dict(x0=x, x1=x + w, y0=y, y1=y + h, units=u, row=ri, col=ci))
            x += w + gap
        out.append(row)
        y += h + gap
    return out


def keycap(cv, x0, y0, x1, y1, face, edge, r=1.3):
    cv.rrect(x0, y0 + 0.55, x1, y1 + 0.3, r, rgba(edge, 235))              # the dark underside / drop shadow
    cv.rrect(x0, y0, x1, y1 - 0.15, r, rgba(mix(edge, face, .45)))
    cv.vgrad(x0 + 0.3, y0 + 0.25, x1 - 0.3, y1 - 0.85, mix(face, WHITE, .35), mix(face, BLACK, .04), r=r * 0.85)
    cv.line([(x0 + r, y0 + 0.5), (x1 - r, y0 + 0.5)], rgba(WHITE, 190), 0.45)   # the lit top edge


LEGENDS = {1: '`1234567890-=', 2: '\tQWERTYUIOP[]\\', 3: '\tASDFGHJKL;\'', 4: '\tZXCVBNM,./'}


def legend(cv, k, col, ch, px=0.78):
    """One letter of the 3x5 pixel font, centred on the key cap."""
    cx, cy = (k['x0'] + k['x1']) / 2, (k['y0'] + k['y1']) / 2 - 0.4
    text(cv, cx - 1.5 * px, cy - 2.5 * px, ch, rgba(col, 225), px)


def fn_icon(cv, k, col):
    """The little pictures on the top row of keys."""
    c = k['col']
    cx, cy = (k['x0'] + k['x1']) / 2, (k['y0'] + k['y1']) / 2 - 0.25
    a = rgba(col, 230)
    if c == 0: cv.circle(cx, cy, 1.4, None, a, 0.7)
    elif c == 1: cv.circle(cx, cy, 0.8, a)
    elif c == 2:
        cv.circle(cx, cy, 0.9, a)
        for i in range(8):
            t = i * math.pi / 4; cv.line([(cx + 1.7 * math.cos(t), cy + 1.7 * math.sin(t)), (cx + 2.2 * math.cos(t), cy + 2.2 * math.sin(t))], a, 0.4)
    elif c == 3:
        for dx in (-1.1, 0.1):
            for dy in (-1.1, 0.1): cv.rect(cx + dx, cy + dy, cx + dx + 1.0, cy + dy + 1.0, a)
    elif c == 4: cv.circle(cx - 0.4, cy - 0.4, 1.2, None, a, 0.6); cv.line([(cx + 0.5, cy + 0.5), (cx + 1.6, cy + 1.6)], a, 0.7)
    elif c == 5: cv.rrect(cx - 0.7, cy - 1.7, cx + 0.7, cy + 0.4, 0.7, a); cv.line([(cx, cy + 0.9), (cx, cy + 1.8)], a, 0.5)
    elif c == 6: cv.circle(cx, cy, 1.5, a); cv.circle(cx + 0.8, cy - 0.5, 1.3, rgba(mix(col, WHITE, .8)))
    elif c == 7: cv.poly([(cx - 0.1, cy - 1.2), (cx - 0.1, cy + 1.2), (cx - 1.9, cy)], a); cv.poly([(cx + 1.7, cy - 1.2), (cx + 1.7, cy + 1.2), (cx - 0.1, cy)], a)
    elif c == 8: cv.poly([(cx - 1.3, cy - 1.4), (cx - 1.3, cy + 1.4), (cx + 1.5, cy)], a)
    elif c == 9: cv.poly([(cx + 0.1, cy - 1.2), (cx + 0.1, cy + 1.2), (cx + 1.9, cy)], a); cv.poly([(cx - 1.7, cy - 1.2), (cx - 1.7, cy + 1.2), (cx + 0.1, cy)], a)
    elif c in (10, 11, 12):
        cv.rect(cx - 1.6, cy - 0.6, cx - 0.5, cy + 0.6, a); cv.poly([(cx - 0.5, cy - 0.6), (cx + 0.7, cy - 1.5), (cx + 0.7, cy + 1.5), (cx - 0.5, cy + 0.6)], a)
        if c >= 11: cv.arc((cx - 0.2, cy - 1.2, cx + 1.8, cy + 1.2), -50, 50, a, 0.5)
        if c == 12: cv.arc((cx - 0.2, cy - 1.9, cx + 2.6, cy + 1.9), -50, 50, a, 0.5)


def neo_deck(p):
    W, H = 176, 122
    m = rgb(p['metal']); acc = rgb(p['accent'])
    cv = Canvas(W, H)
    cv.dgrad(0, 0, W, H, mix(m, WHITE, .24), mix(m, BLACK, .10))
    cv.poly([(112, 0), (158, 0), (72, H), (26, H)], rgba(WHITE, 15))        # soft light across the metal
    cv.poly([(150, 0), (170, 0), (110, H), (90, H)], rgba(WHITE, 9))
    hole, glint = mix(m, BLACK, .55), mix(m, WHITE, .75)
    for gx in (3.2, 164.6):                                                    # the speaker grills (two staggered columns of holes)
        for ri, gy in enumerate([7 + i * 3.2 for i in range(18)]):
            for k in range(3):
                x = gx + k * 2.7 + (1.35 if ri % 2 else 0)
                cv.circle(x + 0.25, gy + 0.55, 0.62, rgba(glint, 150)); cv.circle(x, gy, 0.62, rgba(hole))
    cv.rrect(11.4, 4.4, 164.6, 70.6, 3.4, rgba(mix(m, WHITE, .7), 170))           # a thin lit rim round the key well
    cv.rrect(12, 5, 164, 70, 3, rgba(mix(m, BLACK, .42)))                       # the key well
    cv.rrect(12.6, 5.6, 163.4, 69, 2.6, rgba(mix(m, BLACK, .55), 120))             # its inner shadow
    face_a, face_m = mix(m, WHITE, .66), mix(m, WHITE, .5)
    edge = mix(m, BLACK, .5); lg = mix(m, BLACK, .6)
    keys = layout(14, 162, 8, 67.4)
    for row in keys:
        for k in row:
            stack = k['row'] == 5 and k['col'] == 7
            face = face_a if k['units'] == 1 else face_m
            if k['row'] == 0 and k['col'] == 0: face = mix(acc, WHITE, .45)        # esc
            if k['row'] == 3 and k['col'] == 11: face = mix(acc, WHITE, .5)        # enter
            if stack:
                hh = (k['y1'] - k['y0'] - 0.5) / 2
                for j in range(2):
                    y0 = k['y0'] + j * (hh + 0.5)
                    keycap(cv, k['x0'], y0, k['x1'], y0 + hh, face, edge, 1.0)
                    cx = (k['x0'] + k['x1']) / 2; cy = y0 + hh / 2 - 0.2
                    s = 1 if j == 0 else -1
                    cv.poly([(cx - 1.1, cy + 0.7 * s), (cx + 1.1, cy + 0.7 * s), (cx, cy - 0.8 * s)], rgba(lg, 220))
                continue
            keycap(cv, k['x0'], k['y0'], k['x1'], k['y1'], face, edge)
            if k['row'] == 0: fn_icon(cv, k, lg)
            elif k['units'] == 1 and k['row'] in (1, 2, 3, 4): legend(cv, k, lg, LEGENDS[k['row']][k['col']])
            elif k['row'] == 5 and k['col'] == 6: cv.poly([(k['x0'] + 2.6, (k['y0'] + k['y1']) / 2 - 0.2), (k['x1'] - 2.2, k['y0'] + 2.0), (k['x1'] - 2.2, k['y1'] - 2.4)], rgba(lg, 220))
            elif k['row'] == 5 and k['col'] == 8: cv.poly([(k['x1'] - 2.6, (k['y0'] + k['y1']) / 2 - 0.2), (k['x0'] + 2.2, k['y0'] + 2.0), (k['x0'] + 2.2, k['y1'] - 2.4)], rgba(lg, 220))
            elif k['units'] > 1: cv.line([(k['x0'] + 2, (k['y0'] + k['y1']) / 2 - 0.3), (k['x0'] + 2 + min(3.5, k['units'] * 1.6), (k['y0'] + k['y1']) / 2 - 0.3)], rgba(lg, 190), 0.6)
    pk = keys[0][-1]                                                             # the power key glows
    lay = Canvas(W, H); px, py = (pk['x0'] + pk['x1']) / 2, (pk['y0'] + pk['y1']) / 2 - 0.25
    lay.circle(px, py, 1.6, None, rgba(acc), 0.9); lay.line([(px, py - 2.1), (px, py - 0.6)], rgba(acc), 0.9)
    cv.bloom(lay, 2.2, 0.9)
    tp = (58, 78, 118, 116)                                                    # the glass trackpad
    cv.rrect(tp[0] - 0.9, tp[1] - 0.9, tp[2] + 0.9, tp[3] + 1.3, 4.9, rgba(mix(m, WHITE, .6), 200))
    cv.rrect(tp[0], tp[1], tp[2], tp[3], 4.2, rgba(mix(m, BLACK, .3)))
    a_, b_ = np.array(mix(m, WHITE, .28), float), np.array(mix(m, BLACK, .04), float)
    cv.gradient(tp[0] + 0.7, tp[1] + 0.7, tp[2] - 0.7, tp[3] - 0.7, lambda u, v: tuple(a_[i] * (1 - (u * .35 + v * .65)) + b_[i] * (u * .35 + v * .65) for i in range(3)), r=3.6)
    cv.line([(tp[0] + 4, tp[1] + 1.8), (tp[0] + 15, tp[1] + 1.8)], rgba(WHITE, 130), 0.6)       # a glint in the corner
    cv.line([(tp[0] + 1.8, tp[1] + 4), (tp[0] + 1.8, tp[1] + 9)], rgba(WHITE, 90), 0.6)
    cv.line([(8, H - 2.3), (W - 8, H - 2.3)], rgba(WHITE, 95), 0.7)                          # the polished front edge
    return cv.finish(grain=0.010, seed=p['metal'] % 1000, brushed=0.004)


# ------------------------------------------------------------------------------------------------ the screen
def wallpaper(p, w, h):
    s0, s1, s2 = (np.array(rgb(c), float) for c in p['sky'])
    i0, i1, i2 = (tuple(int(v) for v in s) for s in (s0, s1, s2))
    moon = rgb(p['moon'])
    cv = Canvas(w, h)
    def sky(u, v):
        t = np.clip(v / 0.78, 0, 1)[..., None]
        lo = s0 + (s1 - s0) * np.clip(t * 2, 0, 1); hi = s1 + (s2 - s1) * np.clip(t * 2 - 1, 0, 1)
        c = np.where(t < .5, lo, hi)
        return c[..., 0], c[..., 1], c[..., 2]
    cv.gradient(0, 0, w, h, sky)
    rnd = random.Random(p['metal'])
    for i in range(46):                                                         # stars
        x, y = rnd.uniform(2, w - 2), rnd.uniform(8, h * 0.42)
        cv.circle(x, y, rnd.choice((0.35, 0.45, 0.6)), rgba(WHITE, int(rnd.uniform(110, 230))))
    for sx, sy, sr in ((w * .12, h * .2, 2.4), (w * .46, h * .12, 1.9), (w * .9, h * .38, 2.0)):
        cv.poly(sparkle_pts(sx, sy, sr), rgba(WHITE, 235))
    mx, my, mr = w * .72, h * .30, h * .115                                     # the moon with a halo
    halo = Canvas(w, h); halo.circle(mx, my, mr * 1.25, rgba(moon, 120))
    cv.bloom(halo, mr * 0.9, 0.85)
    cv.circle(mx, my, mr, rgba(moon))
    for cx, cy, cr in ((-0.35, -0.2, .22), (.25, .3, .3), (.35, -.35, .14)):    # craters
        cv.circle(mx + cx * mr, my + cy * mr, cr * mr, rgba(mix(moon, i1, .25), 90))
    cv.circle(mx - mr * .3, my - mr * .3, mr * .55, rgba(WHITE, 45))
    cloud(cv, w * .50, h * .22, w * .22, rgba(mix(i2, WHITE, .55), 70))
    cloud(cv, w * .05, h * .40, w * .20, rgba(mix(i2, WHITE, .5), 60))
    far = mix(i1, i2, .30); mid = mix(i1, BLACK, .25); near = mix(i0, i1, .18); front = mix(i0, BLACK, .38)
    rim = mix(moon, WHITE, .3)
    hills(cv, 0, w, h * .62, h * .06, 1.0, 0.6, h, rgba(far), rgba(rim, 80), 0.6)
    pm = hills(cv, 0, w, h * .70, h * .06, 1.3, 2.1, h, rgba(mid), rgba(rim, 90), 0.7)
    for tx in (w * .55, w * .60, w * .64, w * .82, w * .87):                    # little pine trees on the middle hill
        ty = min(pm, key=lambda q: abs(q[0] - tx))[1]
        sz = rnd.uniform(3.2, 5.0)
        for k in range(3):
            cv.poly([(tx, ty - sz * (0.9 + k * 0.55)), (tx - sz * (0.55 - k * 0.1), ty - sz * (0.25 + k * 0.55)), (tx + sz * (0.55 - k * 0.1), ty - sz * (0.25 + k * 0.55))], rgba(mix(mid, BLACK, .35)))
    pn = hills(cv, 0, w, h * .79, h * .055, 0.8, 4.0, h, rgba(near), rgba(rim, 110), 0.8)
    cx = w * .25; cy = min(pn, key=lambda q: abs(q[0] - cx))[1]                   # a cat sitting on the near hill, watching the moon
    cc = mix(front, BLACK, .2)
    cv.ell(cx - 3.4, cy - 7.4, cx + 3.4, cy + 1.0, rgba(cc))
    cat_head(cv, cx, cy - 8.6, 3.0, rgba(cc), ear=0.8)
    cv.line([(cx + 3, cy - 0.6), (cx + 6.6, cy - 1.6), (cx + 7.8, cy - 5.4), (cx + 6.6, cy - 7.2)], rgba(cc), 1.5)       # the tail
    for ex in (-1.1, 1.1): cv.circle(cx + ex + 0.5, cy - 8.8, 0.55, rgba(moon))
    hills(cv, 0, w, h * .90, h * .035, 1.6, 0.3, h, rgba(front), rgba(rim, 70), 0.6)
    fl = Canvas(w, h)
    for i in range(9):                                                          # fireflies
        fl.circle(rnd.uniform(w * .05, w * .95), rnd.uniform(h * .64, h * .9), 0.55, rgba(mix(moon, (255, 255, 160), .5), 235))
    cv.bloom(fl, 1.8, 1.1)
    return cv


def ui_overlay(cv, w, h, p):
    """The menu bar, a clock widget and the dock, drawn over the wallpaper."""
    acc = rgb(p['accent'])
    cv.rect(0, 0, w, 6.6, rgba(WHITE, 52)); cv.rect(0, 6.6, w, 7.2, rgba(WHITE, 36))
    cv.poly(heart_pts(5.2, 3.3, 2.0), rgba(WHITE, 250))
    for x, ww in ((10.5, 8), (21, 6.5), (30, 9)): cv.rrect(x, 2.5, x + ww, 4.1, 0.8, rgba(WHITE, 215))
    cv.circle(w - 26, 4.6, 0.55, rgba(WHITE, 240))                              # wifi
    for r_ in (1.7, 2.8): cv.arc((w - 26 - r_, 4.6 - r_, w - 26 + r_, 4.6 + r_), 225, 315, rgba(WHITE, 240), 0.55)
    cv.rrect(w - 20, 2.1, w - 11.5, 4.7, 0.8, None, rgba(WHITE, 240), 0.5); cv.rrect(w - 19.4, 2.7, w - 14.5, 4.1, 0.4, rgba(WHITE, 240))
    for x, ww in ((w - 9, 2), (w - 6.2, 3.8)): cv.rrect(x, 2.5, x + ww, 4.1, 0.6, rgba(WHITE, 225))
    wx, wy, ww_, wh = 7, 12, 31, 21                                             # a clock widget
    cv.rrect(wx, wy, wx + ww_, wy + wh, 4, rgba(WHITE, 44), rgba(WHITE, 90), 0.5)
    cx, cy = wx + 10.5, wy + wh / 2
    cv.circle(cx, cy, 6.6, rgba(WHITE, 38), rgba(WHITE, 235), 0.9)
    for i in range(12):
        t = i * math.pi / 6; r0 = 5.3 if i % 3 == 0 else 5.8
        cv.line([(cx + r0 * math.sin(t), cy - r0 * math.cos(t)), (cx + 6.0 * math.sin(t), cy - 6.0 * math.cos(t))], rgba(WHITE, 220), 0.4)
    cv.line([(cx, cy), (cx + 3.4 * math.sin(2.1), cy - 3.4 * math.cos(2.1))], rgba(WHITE, 250), 0.9)
    cv.line([(cx, cy), (cx + 5 * math.sin(0.4), cy - 5 * math.cos(0.4))], rgba(WHITE, 250), 0.7)
    cv.circle(cx, cy, 0.7, rgba(mix(acc, WHITE, .3)))
    for j, ln in enumerate((11, 8, 10)): cv.rrect(wx + 19, wy + 5 + j * 4.3, wx + 19 + ln, wy + 6.6 + j * 4.3, 0.8, rgba(WHITE, 215 - j * 40))
    n, sz, gap = 7, 7.4, 2.0                                                     # the dock
    dw = n * sz + (n - 1) * gap + 7
    dx0 = (w - dw) / 2; dy0 = h - 13.2
    cv.rrect(dx0, dy0, dx0 + dw, dy0 + 11.2, 4.4, rgba(WHITE, 62), rgba(WHITE, 110), 0.5)
    ic = [(0xFF7A9C, 0xFF3F72), (0xFFD36B, 0xFFA23A), (0xB68CFF, 0x7A4CE0), (0x6FE0A0, 0x2FB878), (0x6FC7FF, 0x3A8CF0), (0xFFA8D8, 0xFF6FB4), (0xFFE88A, 0xFFB84D)]
    for i, (c0, c1) in enumerate(ic):
        x = dx0 + 3.5 + i * (sz + gap); y = dy0 + 1.9
        cv.rrect(x, y + 0.5, x + sz, y + sz + 0.5, 2.1, rgba(BLACK, 70))
        cv.vgrad(x, y, x + sz, y + sz, rgb(c0), rgb(c1), r=2.1)
        cv.line([(x + 1.2, y + 0.45), (x + sz - 1.2, y + 0.45)], rgba(WHITE, 170), 0.45)
        gx, gy = x + sz / 2, y + sz / 2
        w_ = rgba(WHITE, 245)
        if i == 0: cv.poly(heart_pts(gx, gy - 0.1, 2.3), w_)
        elif i == 1: cv.rrect(gx - 2.4, gy - 1.5, gx + 2.4, gy + 1.9, 0.6, w_); cv.rect(gx - 2.4, gy - 2.1, gx - 0.4, gy - 1.4, w_)
        elif i == 2: cv.ell(gx - 2.1, gy + 0.3, gx - 0.3, gy + 1.9, w_); cv.line([(gx - 0.5, gy + 1), (gx - 0.5, gy - 2.2), (gx + 2, gy - 1.5)], w_, 0.7)
        elif i == 3: cv.rrect(gx - 2.6, gy - 2.1, gx + 2.6, gy + 1.4, 1.2, w_); cv.poly([(gx - 1.2, gy + 1.2), (gx - 1.8, gy + 2.7), (gx + 0.2, gy + 1.2)], w_)
        elif i == 4: cv.circle(gx, gy, 2.4, None, w_, 0.7); cv.line([(gx, gy), (gx, gy - 1.6)], w_, 0.6); cv.line([(gx, gy), (gx + 1.2, gy + 0.4)], w_, 0.6)
        elif i == 5: cat_head(cv, gx, gy + 0.6, 2.0, w_, 0.7)
        else: cv.poly(star_pts(gx, gy + 0.1, 2.6, 1.1), w_)
    cv.circle(dx0 + 3.5 + 0.5 * sz, dy0 + 10.3, 0.5, rgba(WHITE, 230))        # the "open" dot under the first icon


def neo_screen(p):
    W, H = 176, 118
    m = rgb(p['metal'])
    cv = Canvas(W, H, rgba(m))
    cv.vgrad(0, 0, W, H, mix(m, WHITE, .12), mix(m, BLACK, .08))
    cv.rrect(0, 0, W, H, 5.2, rgba((11, 11, 16)))
    cv.rrect(0.5, 0.5, W - 0.5, H - 0.5, 4.8, None, rgba((60, 62, 80), 90), 0.5)                # a faint glassy rim
    x0, y0, x1, y1 = 4.2, 4.2, W - 4.2, H - 4.6
    sw, sh = int(x1 - x0), int(y1 - y0)
    sc = wallpaper(p, sw, sh); ui_overlay(sc, sw, sh, p)
    mask = Image.new('L', (sw * SS, sh * SS), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, sw * SS - 1, sh * SS - 1), radius=int(3.4 * SS), fill=255)
    cv.im.paste(sc.im, (int(x0 * SS), int(y0 * SS)), mask)
    cv.circle(W / 2, 2.1, 1.15, rgba((26, 28, 44)), rgba((70, 76, 110)), 0.4); cv.circle(W / 2 - 0.2, 1.8, 0.35, rgba((120, 150, 255), 220))   # the camera
    led = Canvas(W, H); led.circle(W / 2 + 4.8, 2.1, 0.45, rgba((90, 255, 150))); cv.bloom(led, 1.2, 0.8)
    cv.poly([(104, 0), (150, 0), (96, H), (50, H)], rgba(WHITE, 12))                         # the glare of the glass
    cv.poly([(150, 0), (176, 0), (176, 36), (118, H), (96, H)], rgba(WHITE, 7))
    return cv.finish(grain=0.004, seed=3)


# ------------------------------------------------------------------------------------------------ the lid, the sides, the hinge
def neo_back(p):
    W, H = 176, 118
    m = rgb(p['metal']); acc = rgb(p['accent'])
    cv = Canvas(W, H)
    cv.dgrad(0, 0, W, H, mix(m, WHITE, .34), mix(m, BLACK, .12))
    cv.poly([(112, 0), (170, 0), (76, H), (18, H)], rgba(WHITE, 20))                         # a pearly sweep
    cv.poly([(24, 0), (46, 0), (6, 70), (0, 70), (0, 40)], rgba(mix(acc, WHITE, .5), 20))
    for i in range(3): cv.circle(W * .5, H * .47, 34 - i * 7, None, rgba(WHITE, 14), 0.8)          # soft rings behind the emblem
    ss = SS
    mk, d = cv.mask()
    cx, cy = W / 2, H / 2 + 2
    d.polygon([(x * ss, y * ss) for x, y in heart_pts(cx, cy, 17)], fill=255)
    for sx in (-1, 1):                                                                         # round cat ears sitting on the two lobes
        d.polygon([((cx + sx * 5.0) * ss, (cy - 12.5) * ss), ((cx + sx * 11.8) * ss, (cy - 19.5) * ss), ((cx + sx * 15.6) * ss, (cy - 9.5) * ss)], fill=255)
    cv.fill_mask(mk, rgba(mix(m, WHITE, .72)))
    cv.emboss(mk, 0.9, .6, .38)
    inner, d2 = cv.mask()
    d2.polygon([(x * ss, y * ss) for x, y in heart_pts(cx, cy + 0.8, 12.2)], fill=255)
    cv.fill_mask(inner, rgba(mix(m, acc, .22), 120))
    cv.poly(sparkle_pts(cx - 5.2, cy - 3.4, 3.4), rgba(WHITE, 235))
    for sx, sy, r in ((26, 28, 4.5), (150, 90, 5.5), (140, 22, 3.2), (34, 92, 3.0), (118, 100, 2.2)):
        cv.poly(sparkle_pts(sx, sy, r), rgba(WHITE, 215))
    for sx, sy in ((56, 20), (122, 36), (60, 98), (100, 14), (16, 56), (160, 62)): cv.circle(sx, sy, 0.7, rgba(WHITE, 190))
    cv.rrect(1.2, 1.2, W - 1.2, H - 1.2, 4.6, None, rgba(WHITE, 90), 0.6)
    cv.rrect(0.4, 0.4, W - 0.4, H - 0.4, 5, None, rgba(BLACK, 40), 0.5)
    return cv.finish(grain=0.008, seed=7, brushed=0.003)


def neo_side(p, left):
    W, H = 200, 8
    m = rgb(p['metal'])
    cv = Canvas(W, H)
    cv.vgrad(0, 0, W, H, mix(m, WHITE, .35), mix(m, BLACK, .22))
    port = mix(m, BLACK, .78)
    def usbc(x): cv.rrect(x, 2.3, x + 9, 5.5, 1.6, rgba(port)); cv.rrect(x + 1.4, 3.5, x + 7.6, 4.3, 0.4, rgba(mix(m, BLACK, .45)))
    if left:
        usbc(32); usbc(52)
        cv.circle(80, 4, 0.6, rgba((255, 190, 90), 240))
    else:
        cv.circle(40, 4, 1.5, rgba(port)); cv.circle(40, 4, 0.7, rgba(mix(m, BLACK, .4)))
        usbc(66)
        cv.rrect(98, 2.8, 112, 5.2, 0.8, rgba(mix(m, BLACK, .55)))
    for i in range(14): cv.rrect(128 + i * 4.2, 2.3, 129.3 + i * 4.2, 5.7, 0.5, rgba(mix(m, BLACK, .6)))   # the air vents
    return cv.finish(grain=0.008, seed=5)


def neo_hinge(p):
    m = rgb(p['metal'])
    cv = Canvas(16, 8)
    cv.vgrad(0, 0, 16, 8, mix(m, WHITE, .4), mix(m, BLACK, .38), power=0.9)
    cv.line([(0, 2), (16, 2)], rgba(WHITE, 120), 0.6)
    return cv.finish()


def neo_body(p):
    m = rgb(p['metal'])
    cv = Canvas(16, 16)
    cv.vgrad(0, 0, 16, 16, mix(m, WHITE, .22), mix(m, BLACK, .12))
    return cv.finish(grain=0.006, seed=11)


# ------------------------------------------------------------------------------------------------ the models
def box(name, f, t, faces, rot=None):
    e = {'name': name, 'from': [round(x, 3) for x in f], 'to': [round(x, 3) for x in t], 'faces': faces}
    if rot: e['rotation'] = rot
    return e


def face(tex, glow=None, rot=None):
    f = {'uv': [0, 0, 16, 16], 'texture': tex}
    if rot: f['rotation'] = rot
    if glow: f['neoforge_data'] = {'block_light': glow, 'sky_light': glow}
    return f


def faces_all(tex): return {k: face(tex) for k in ('north', 'south', 'east', 'west', 'up', 'down')}


def with_(faces, **kw):
    f = dict(faces)
    f.update(kw)
    return f


# the geometry (1/16 block): 12.5 wide, 8.7 deep, the hinge at the back (z = 4.6)
X0, X1, Z0, Z1 = 1.75, 14.25, 4.6, 13.3


def model(open_):
    els = [box('base', [X0, 0, Z0], [X1, 0.35, Z1], with_(faces_all('#body'), west=face('#side_l'), east=face('#side_r')))]
    els.append(box('deck', [X0 + 0.12, 0.35, Z0 + 0.12], [X1 - 0.12, 0.6, Z1 - 0.12], with_(faces_all('#body'), up=face('#deck'))))
    els.append(box('hinge_a', [3.2, 0.42, Z0 - 0.14], [12.8, 0.84, Z0 + 0.28], faces_all('#hinge')))
    els.append(box('hinge_b', [3.2, 0.42, Z0 - 0.14], [12.8, 0.84, Z0 + 0.28], faces_all('#hinge'), {'origin': [8, 0.63, Z0 + 0.07], 'axis': 'x', 'angle': 45}))
    if open_:
        lid = with_(faces_all('#body'), south=face('#screen', 15), north=face('#back'))
        els.append(box('lid', [X0, 0.6, Z0], [X1, 9.0, Z0 + 0.4], lid, {'origin': [8, 0.6, Z0 + 0.2], 'axis': 'x', 'angle': -22.5}))
    else:
        lid = with_(faces_all('#body'), up=face('#back'))
        els.append(box('lid_closed', [X0, 0.6, Z0], [X1, 1.0, Z1], lid))
    return els


def main():
    for name, p in COLORS.items():
        neo_body(p).save(TEX + f'{name}_neo_body.png')
        neo_hinge(p).save(TEX + f'{name}_neo_hinge.png')
        neo_deck(p).save(TEX + f'{name}_neo_deck.png')
        neo_screen(p).save(TEX + f'{name}_neo_screen.png')
        neo_back(p).save(TEX + f'{name}_neo_back.png')
        neo_side(p, True).save(TEX + f'{name}_neo_side_l.png')
        neo_side(p, False).save(TEX + f'{name}_neo_side_r.png')
        tex = {k: f'cutemod:block/{name}_neo_{k}' for k in ('body', 'hinge', 'deck', 'screen', 'back', 'side_l', 'side_r')}
        tex['particle'] = f'cutemod:block/{name}_neo_body'
        for open_, suffix in ((True, ''), (False, '_closed')):
            data = {'credit': 'slim Neo-style laptop (generated by tools/make_neo_laptop.py)', 'ambientocclusion': False, 'textures': tex, 'elements': model(open_)}
            json.dump(data, open(MOD + f'{name}_laptop{suffix}.json', 'w'), indent=1)
    print('done')


if __name__ == '__main__':
    main()
