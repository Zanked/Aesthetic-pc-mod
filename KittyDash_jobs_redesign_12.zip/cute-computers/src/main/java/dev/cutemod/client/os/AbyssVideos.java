package dev.cutemod.client.os;

import net.minecraft.client.gui.GuiGraphics;

/**
 * The abyss of the haunted site (address 666): 666 more videos, every one made from its number alone, so nothing
 * is stored. A video is a crimson, psychedelic picture (a plasma, a spiral, rings, a moire ... with eyes, a mouth,
 * a sigil, dripping blood, a shaking "666" and glitches laid over it), a title and a channel made of 666 and of
 * strange symbols, and three comments nobody can read.
 *
 * The brightness never flashes faster than the heartbeat (about 0.85 Hz): the glitches come once in a few seconds.
 */
final class AbyssVideos {
    private AbyssVideos() {}

    static final int COUNT = 666;
    private static final int PW = 146, PH = 82;

    // ---------- numbers made from the number of the video ----------
    private static long mix(long z) {
        z += 0x9E3779B97F4A7C15L;
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    /** A stable non-negative number for (video, salt). */
    private static int h(int n, int salt) {
        return (int) (mix(n * 1_000_003L + salt * 7919L + 666L) >>> 34);
    }

    // ---------- the picture ----------
    private static final int[][] PALS = {
            {0xFF050003, 0xFF3A0510, 0xFF8A0A1C, 0xFFD0102E, 0xFFFF4A3A},    // blood
            {0xFF08000E, 0xFF3A0A4A, 0xFF8A0A3A, 0xFFD0102E, 0xFFFF5A6A},    // crimson and violet
            {0xFF000000, 0xFF2A0204, 0xFF9A0E14, 0xFFE02A2A, 0xFFF0D0C0},    // black, red, bone
            {0xFF0A0000, 0xFF5A0A0A, 0xFFC01020, 0xFFFF6A1A, 0xFFFFC060},    // embers
            {0xFF0A0008, 0xFF50082A, 0xFFB0102E, 0xFFFF2A6A, 0xFFFFA0C0},    // magenta in the red
    };
    private static final String[] SIX = {"111", "100", "111", "101", "111"};

    static int len(int n) { return 1200 + (h(n, 7) % 6) * 240; }

    /** Which tick of the video is its thumbnail when the card is not hovered. */
    static int preview(int n) { return 200 + h(n, 8) % 700; }

    /** The colour of the channel's round avatar. */
    static int avatar(int n) { return PALS[h(n, 1) % PALS.length][3]; }

    /** A beat of the heart under this video, in ticks. */
    static int heart(int n) { return 50 + h(n, 9) % 40; }

    static int likes(int n) { return h(n, 11) % 3 == 0 ? 666 : 6 + h(n, 12) % 6660; }

    private static int mixc(int a, int b, float p) {
        p = Math.max(0F, Math.min(1F, p));
        int r = 0xFF000000;
        for (int sh = 0; sh <= 16; sh += 8) r |= (int) (((a >> sh) & 255) * (1F - p) + ((b >> sh) & 255) * p) << sh;
        return r;
    }

    private static int withAlpha(int rgb, float a) {
        return ((int) (Math.max(0F, Math.min(1F, a)) * 255) << 24) | (rgb & 0xFFFFFF);
    }

    /** A colour of the palette: v runs up and down through it (dark - blood - bright - blood - dark). */
    private static int ramp(int[] pal, float v, float bright) {
        v -= (float) Math.floor(v);
        float tri = Math.abs(2F * v - 1F) * (pal.length - 1);
        int i = Math.min(pal.length - 2, (int) tri);
        return mixc(0xFF000000, mixc(pal[i], pal[i + 1], tri - i), bright);
    }

    private static void oval(GuiGraphics g, int cx, int cy, int rx, int ry, int argb) {
        if (rx <= 0 || ry <= 0) return;
        for (int dy = -ry; dy <= ry; dy++) {
            int dx = (int) Math.round(rx * Math.sqrt(Math.max(0.0, 1.0 - dy * (double) dy / (ry * (double) ry))));
            Skin.rect(g, cx - dx, cy + dy, 2 * dx + 1, 1, argb);
        }
    }

    private static void six(GuiGraphics g, int x, int y, int sc, int col) {
        for (int r = 0; r < 5; r++) {
            for (int c = 0; c < 3; c++) if (SIX[r].charAt(c) == '1') Skin.rect(g, x + c * sc, y + r * sc, sc, sc, col);
        }
    }

    private static int overlays(int n) {
        int ov = h(n, 3) & 127;
        if (Integer.bitCount(ov) < 2) ov |= 1 << (h(n, 13) % 7) | 1 << (h(n, 14) % 7);
        return ov;
    }

    /** The value (0..1) of the moving background at one spot. */
    private static float field(int base, float dx, float dy, float ph, float f1, float f2, int arms) {
        double r = Math.sqrt(dx * dx + dy * dy);
        double v;
        switch (base) {
            case 0 -> v = (Math.sin(dx * f1 + ph * 3) + Math.sin(dy * f2 - ph * 2.3) + Math.sin((dx + dy) * 0.05 + ph * 1.7)
                    + Math.sin(r * 0.13 - ph * 4)) * 0.25;                                          // a plasma
            case 1 -> v = Math.sin(Math.atan2(dy, dx) * arms + r * f1 * 2.2 - ph * 3.4);            // a spiral
            case 2 -> v = Math.sin(dx * f1 * 1.5 + Math.sin(dy * f2 * 2 + ph * 2) * 2.2 + ph) * Math.cos(dy * f2 - ph);   // a warped weave
            case 3 -> v = Math.sin(r * (f1 + 0.08) - ph * 5) + Math.sin(r * 0.03 + ph) * 0.4;       // rings that fall inward
            case 4 -> {                                                                              // two centres, a moire
                double r2 = Math.sqrt((dx - 40 * Math.sin(ph)) * (dx - 40 * Math.sin(ph)) + (dy + 20 * Math.cos(ph * 1.3)) * (dy + 20 * Math.cos(ph * 1.3)));
                v = Math.sin(r * 0.5) * Math.sin(r2 * 0.5) * 1.2;
            }
            default -> v = Math.sin(dx * f1 * 1.6 + Math.sin(dy * 0.08 + ph * 1.5) * 3 + ph * 2);   // melting stripes
        }
        return (float) (Math.max(-1.0, Math.min(1.0, v)) * 0.5 + 0.5);
    }

    /** One frame of the abyss video n (0..665) at tick tm, drawn on the 146 x 82 screen. */
    static void draw(GuiGraphics g, int n, int tm, boolean thumb) {
        int total = len(n);
        int[] pal = PALS[h(n, 1) % PALS.length];
        int base = h(n, 2) % 6, ov = overlays(n);
        float spd = 0.7F + (h(n, 4) % 100) / 100F;
        float ph = tm * 0.012F * spd + (h(n, 15) % 628) / 100F;
        float pulse = Math.max(0F, 1F - (tm % heart(n)) / 22F);
        float f1 = 0.05F + (h(n, 5) % 60) / 1000F, f2 = 0.06F + (h(n, 6) % 70) / 1000F;
        int arms = 2 + h(n, 16) % 5;
        float inten = Math.min(1F, 0.45F + tm / 600F);
        int cell = thumb ? 8 : 6;
        int cx = 73 + (int) Math.round(Math.sin(tm / 50.0 + n) * 10), cy = 41 + (int) Math.round(Math.cos(tm / 43.0 + n) * 6);

        // 1. the moving background
        for (int y = 0; y < PH; y += cell) {
            for (int x = 0; x < PW; x += cell) {
                float q = field(base, x - cx, y - cy, ph, f1, f2, arms);
                Skin.rect(g, x, y, cell, cell, ramp(pal, q * 0.8F + ph * 0.08F, Math.min(1F, inten * (0.5F + 0.5F * q) + pulse * 0.12F)));
            }
        }

        // 2. rings rushing at you
        if ((ov & 8) != 0) {
            int rn = thumb ? 5 : 9, step = thumb ? 3 : 1;
            for (int k = 0; k < rn; k++) {
                float r = (k * (90F / rn) + tm * 0.5F * spd) % 90F;
                int th = Math.min((int) r, 1 + (int) (r / 22F));
                int col = withAlpha(pal[2 + k % 3], 0.3F + r / 160F);
                for (int dy = (int) Math.max(-r, -cy); dy <= (int) Math.min(r, PH - cy); dy += step) {
                    int a = Math.round((float) Math.sqrt(Math.max(0F, r * r - dy * dy)));
                    int b = Math.round((float) Math.sqrt(Math.max(0F, (r - th) * (r - th) - dy * dy)));
                    if (a - b < 1) a = b + 1;
                    Skin.rect(g, cx - a, cy + dy, a - b, step, col);
                    Skin.rect(g, cx + b, cy + dy, a - b, step, col);
                }
            }
        }

        // 3. dripping blood
        if ((ov & 16) != 0) {
            float grow = Math.min(1F, 0.3F + tm / 700F);
            for (int x = 0; x < PW; x += 4) {
                float w = (float) (Math.sin(x * 0.9 + n) * 0.5 + 0.5);
                int len = Math.round((4 + 26 * w + 5 * (float) Math.sin(tm / 40.0 + x)) * grow);
                if (len < 1) continue;
                Skin.rect(g, x, 0, 3, len, pal[2]);
                Skin.rect(g, x + 1, 0, 1, len, pal[3]);
                Skin.disc(g, x + 1, len, 2, pal[3]);
            }
        }

        // 4. eyes in the walls
        if ((ov & 1) != 0) {
            int ne = thumb ? 3 : 3 + h(n, 17) % 5;
            for (int i = 0; i < ne; i++) {
                int ex = 14 + h(n, 20 + i) % 118, ey = 8 + h(n, 40 + i) % 62;
                float open = Math.max(0F, Math.min(1F, (float) Math.sin(tm / 70.0 + i * 1.7 + n) * 1.6F));
                int ry = Math.round(5 * open);
                if (ry < 1) continue;
                oval(g, ex, ey, 10, ry + 1, 0xFF100004);
                oval(g, ex, ey, 9, ry, 0xFFE8D0C0);
                int ix = (int) Math.round(Math.max(-4.0, Math.min(4.0, (73 - ex) / 12.0 + Math.sin(tm / 40.0 + i) * 2)));
                Skin.disc(g, ex + ix, ey, Math.max(1, ry - 1), 0xFFB0101A);
                Skin.rect(g, ex + ix, ey - ry + 1, 1, Math.max(1, 2 * ry - 1), 0xFF000000);
            }
        }

        // 5. a mouth that opens in the middle
        if ((ov & 64) != 0) {
            float open = (float) (Math.sin(tm / 45.0 + n) * 0.5 + 0.5);
            int ry = 3 + Math.round(open * 15), rx = 22 + (h(n, 18) % 10);
            int my = 44 + (int) Math.round(Math.sin(tm / 31.0) * 2);
            oval(g, 73, my, rx + 2, ry + 2, pal[3]);
            oval(g, 73, my, rx, ry, 0xFF000000);
            for (int i = -rx + 4; i < rx - 3; i += 5) {
                int th = Math.max(1, Math.min(5, ry / 2));
                int edge = (int) Math.round(ry * Math.sqrt(Math.max(0.0, 1.0 - (i * (double) i) / (rx * (double) rx))));
                Skin.rect(g, 73 + i, my - edge, 3, th, 0xFFE8D0C0);
                Skin.rect(g, 73 + i, my + edge - th, 3, th, 0xFFE8D0C0);
            }
        }

        // 6. a sigil that turns
        if ((ov & 4) != 0) {
            int pts = 5 + 2 * (h(n, 19) % 3);                  // 5, 7 or 9 points
            int skip = pts == 5 ? 2 : pts == 7 ? 3 : 4;
            double rad = 28 + pulse * 3, a0 = Math.PI / 2 + tm / (240.0 + h(n, 21) % 200) * ((n & 1) == 0 ? 1 : -1);
            int glow = withAlpha(pal[3], 0.4F), core = pal[4], sk = thumb ? 2 : 1;
            int[] px = new int[pts], py = new int[pts];
            for (int k = 0; k < pts; k++) {
                px[k] = (int) Math.round(73 + rad * Math.cos(a0 + k * 2 * Math.PI / pts));
                py[k] = (int) Math.round(41 + rad * Math.sin(a0 + k * 2 * Math.PI / pts));
            }
            for (int k = 0; k < pts; k++) {
                int x0 = px[k], y0 = py[k], x1 = px[(k + skip) % pts], y1 = py[(k + skip) % pts];
                int steps = Math.max(1, Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)));
                for (int s = 0; s <= steps; s += sk) {
                    int x = x0 + (x1 - x0) * s / steps, y = y0 + (y1 - y0) * s / steps;
                    Skin.rect(g, x - 1, y - 1, 3, 3, glow);
                    Skin.rect(g, x, y, 1, 1, core);
                }
            }
            for (int s = 0; s < 96; s += sk) {
                double a = s * Math.PI * 2 / 96;
                int x = (int) Math.round(73 + (rad + 4) * Math.cos(a)), y = (int) Math.round(41 + (rad + 4) * Math.sin(a));
                Skin.rect(g, x - 1, y - 1, 3, 3, glow);
                Skin.rect(g, x, y, 1, 1, core);
            }
        }

        // 7. a shaking 666 and its upside-down reflection
        if ((ov & 2) != 0) {
            int sc = thumb ? 2 : 3;
            int sx = 20 + (int) ((Math.sin(tm / 90.0 + n) * 0.5 + 0.5) * 70) + (tm % 7 == 0 ? 1 : 0);
            int sy = 6 + (int) ((Math.cos(tm / 120.0 + n) * 0.5 + 0.5) * 14);
            for (int k = 0; k < 3; k++) {
                six(g, sx + k * (3 * sc + 2) + 1, sy + 1, sc, 0xFF000000);
                six(g, sx + k * (3 * sc + 2), sy, sc, pal[4]);
                for (int r = 0; r < 5; r++) {                                                       // the reflection, under it
                    for (int c = 0; c < 3; c++) {
                        if (SIX[4 - r].charAt(c) == '1') Skin.rect(g, sx + k * (3 * sc + 2) + c * sc, sy + 6 * sc + 4 + r * sc, sc, sc, withAlpha(pal[3], 0.45F));
                    }
                }
            }
        }

        // 8. a glitch: once in a few seconds, for a moment (never a strobe)
        if ((ov & 32) != 0) {
            int per = 170 + h(n, 22) % 90, f = tm % per;
            if (f < 10) {
                for (int k = 0; k < 6; k++) {
                    int gy = h(n, 60 + k + (tm / per) * 6) % PH, gh = 1 + h(n, 70 + k) % 4, gx = h(n, 80 + k + tm / per) % 40;
                    Skin.rect(g, 0, gy, PW, gh, withAlpha(pal[3], 0.45F));
                    Skin.rect(g, gx, gy + gh, PW - gx, 1, withAlpha(pal[1], 0.8F));
                }
            }
        }

        // the heartbeat flush, the dark edges, a slow flicker, the fade in and the fade out
        if (pulse > 0.5F) Skin.rect(g, 0, 0, PW, PH, withAlpha(pal[2], (pulse - 0.5F) * 0.18F));
        Skin.rect(g, 0, 0, PW, 5, 0x66000000);
        Skin.rect(g, 0, PH - 5, PW, 5, 0x66000000);
        Skin.rect(g, 0, 0, 6, PH, 0x44000000);
        Skin.rect(g, PW - 6, 0, 6, PH, 0x44000000);
        int ff = tm % 300;
        if (tm > 300 && ff >= 150 && ff < 156) Skin.rect(g, 0, 0, PW, PH, 0x90000000);
        if (tm < 30) Skin.rect(g, 0, 0, PW, PH, ((int) (255 * (1F - tm / 30F))) << 24);
        if (tm > total - 120) Skin.rect(g, 0, 0, PW, PH, ((int) (255 * Math.min(1F, (tm - (total - 120)) / 120F))) << 24);
    }

    // ---------- the words: titles, channels and comments nobody can read ----------
    private static final String[] G = ("▓ ▒ ░ █ ▌ ▐ ▀ ▄ ■ □ ◆ ◇ ● ○ ◉ ▲ ▼ ☠ ☥ ☦ ☧ ☨ ☩ ☪ ☫ ☬ ♆ ♅ ✝ ✞ ✟ ✠ ҉ ҈ Ѫ Ѧ Ѭ Ѯ Ѿ Ѽ ꙮ Ө Ӧ Ж Я "
            + "Ψ Ω Ξ Σ ∴ ∵ ∷ ⊗ ⊕ ⊘ ⊙ ᚠ ᚦ ᚨ ᚱ ᚲ ᛉ ᛊ ᛏ ᛒ ᛟ ᛞ ¶ § ‡ † ∞ ≠ ≈ ∆ ∇ ⌬ ☉ ☽ ☾").split(" ");
    private static final String[] WORDS = {"смотри", "вниз", "кровь", "глаза", "тише", "дверь", "внутри", "нет", "сон", "оно",
            "look", "down", "blood", "eyes", "quiet", "door", "inside", "no", "dream", "it", "below", "stay"};

    private static String glyphs(int n, int salt, int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) sb.append(G[h(n, salt + i * 3) % G.length]);
        return sb.toString();
    }

    private static String rev(String s) { return new StringBuilder(s).reverse().toString(); }

    private static String word(int n, int salt) { return WORDS[h(n, salt) % WORDS.length]; }

    private static String bits(int n, int salt, int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) sb.append(h(n, salt + i) % 2);
        return sb.toString();
    }

    private static String hex(int n, int salt, int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) sb.append(Integer.toHexString(h(n, salt + i) % 16));
        return sb.toString().toUpperCase(java.util.Locale.ROOT);
    }

    /** The title: at most 28 characters. */
    static String title(int n) {
        String s = switch (h(n, 100) % 9) {
            case 0 -> "666 " + glyphs(n, 101, 4);
            case 1 -> glyphs(n, 102, 3) + " " + hex(n, 103, 6);
            case 2 -> rev(word(n, 104)) + " " + (h(n, 105) % 9) + ":" + (10 + h(n, 106) % 50);
            case 3 -> "6666666 " + glyphs(n, 107, 2) + " 666";
            case 4 -> bits(n, 108, 10) + " " + glyphs(n, 109, 2);
            case 5 -> glyphs(n, 110, 1) + " " + (666 - n % 666) + " " + glyphs(n, 111, 1);
            case 6 -> glyphs(n, 112, 6 + h(n, 113) % 5);
            case 7 -> rev(word(n, 114)) + " " + rev(word(n, 115)) + " 666";
            default -> "#" + (n + 1) + " " + glyphs(n, 116, 3) + " " + "6".repeat(3 + h(n, 117) % 5);
        };
        return s.length() > 28 ? s.substring(0, 28) : s;
    }

    /** The channel: 666, or symbols. */
    static String channel(int n) {
        return switch (h(n, 120) % 7) {
            case 0, 1 -> "666";
            case 2 -> "666" + glyphs(n, 121, 1);
            case 3 -> "6" + glyphs(n, 122, 1) + "6";
            case 4 -> glyphs(n, 123, 5);
            case 5 -> glyphs(n, 124, 2) + "666" + glyphs(n, 125, 2);
            default -> "6".repeat(3 + h(n, 126) % 6);
        };
    }

    /** Comment k (0..2) of the video; the player's own name comes back to him, upside down. */
    static String comment(int n, int k, String player) {
        int s = 130 + k * 40;
        String who = switch (h(n, s) % 5) {
            case 0 -> "@666";
            case 1 -> "@" + glyphs(n, s + 1, 3);
            case 2 -> "@" + hex(n, s + 2, 5);
            case 3 -> "@???";
            default -> "@" + glyphs(n, s + 3, 1) + "666" + glyphs(n, s + 4, 1);
        };
        String text = switch (h(n, s + 5) % 8) {
            case 0 -> glyphs(n, s + 6, 8 + h(n, s + 7) % 8);
            case 1 -> "6 6 6 6 6 6 6";
            case 2 -> rev(word(n, s + 8)) + " " + rev(word(n, s + 9));
            case 3 -> "0:" + (10 + h(n, s + 10) % 50) + " " + glyphs(n, s + 11, 3);
            case 4 -> bits(n, s + 12, 14);
            case 5 -> "666".repeat(1 + h(n, s + 13) % 4);
            case 6 -> rev(player) + " " + glyphs(n, s + 14, 3);
            default -> "0x" + hex(n, s + 15, 8) + " " + glyphs(n, s + 16, 2);
        };
        return who + ": " + text;
    }
}
