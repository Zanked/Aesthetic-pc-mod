package dev.cutemod.client.game;

import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/** Pink computer: tap to flap, fly between the pipes. */
public class FlappyCat extends MiniGame {
    private static final double BX = 50, GRAVITY = 0.16, FLAP = -3.0, SPEED = 1.3;
    private static final int PIPE_W = 24, GAP = 52, SPACING = 100;

    private double y, vy;
    private boolean started;
    private int t;
    private final List<double[]> pipes = new ArrayList<>(); // x, gapCenterY, scored(0/1)

    @Override
    public void reset() {
        score = 0; over = false; started = false; t = 0;
        y = H / 2.0; vy = 0;
        pipes.clear();
    }

    private void flap() {
        started = true;
        vy = FLAP;
        pling(1.6F);
    }

    @Override
    public boolean click(int x, int yy, int button) { flap(); return true; }

    @Override
    public boolean key(int k) {
        if (k == KEY_SPACE || k == KEY_UP) { flap(); return true; }
        return false;
    }

    @Override
    public void tick() {
        t++;
        if (!started) { y = H / 2.0 + Math.sin(t * 0.06) * 4; return; }
        vy += GRAVITY;
        y += vy;
        if (pipes.isEmpty() || pipes.get(pipes.size() - 1)[0] < W - SPACING) {
            pipes.add(new double[]{W + 4, 34 + rnd.nextInt(H - 68), 0});
        }
        for (double[] p : pipes) {
            p[0] -= SPEED;
            if (p[2] == 0 && p[0] + PIPE_W < BX - 6) { p[2] = 1; score++; pling(1.2F + Math.min(score, 20) * 0.03F); }
            boolean overlapX = BX + 6 > p[0] && BX - 6 < p[0] + PIPE_W;
            if (overlapX && (y - 5 < p[1] - GAP / 2.0 || y + 5 > p[1] + GAP / 2.0)) over = true;
        }
        pipes.removeIf(p -> p[0] < -PIPE_W - 2);
        if (y < 2 || y > H - 11) over = true;
    }

    @Override
    public void render(GuiGraphics g) {
        // sky, sun and layered hills
        g.fillGradient(0, 0, W, H, 0xFFFFD9EC, 0xFFFFA9CF);
        Gfx.glow(g, 168, 30, 30, 0xFFFFF2C8, 150);
        Gfx.disc(g, 168, 30, 11, 0xFFFFF6D8);
        double sc = t * SPEED;
        for (int layer = 0; layer < 2; layer++) {
            double k = layer == 0 ? 0.25 : 0.5;
            int base = H - 16 - layer * 8, amp = 10 - layer * 2;
            int col = layer == 0 ? 0xFFF7A8CC : 0xFFEE8DB9;
            for (int x = 0; x < W; x++) {
                double wv = Math.sin((x + sc * k) * 0.035 + layer * 2.0) * amp + Math.sin((x + sc * k) * 0.09) * 3;
                int top = (int) (base - 14 - wv);
                g.fill(x, top, x + 1, H - 8, col);
            }
        }
        for (int i = 0; i < 4; i++) { // clouds drift slowly
            int cx = (int) (((i * 75 - t * 0.25) % 300 + 300) % 300) - 40;
            Gfx.cloud(g, cx, 14 + (i * 23) % 50, 30 + (i % 2) * 8, 0xCCFFFFFF);
        }
        // pipes: rounded caps, light edge, shade on the right
        for (double[] p : pipes) {
            int x = (int) p[0], top = (int) (p[1] - GAP / 2.0), bot = (int) (p[1] + GAP / 2.0);
            pipe(g, x, 0, PIPE_W, top);
            pipe(g, x, bot, PIPE_W, H - 8 - bot);
            cap(g, x - 2, top - 8);
            cap(g, x - 2, bot);
        }
        // ground: grass strip + scrolling stripes
        g.fillGradient(0, H - 8, W, H, 0xFFFFC2DC, 0xFFE58AAE);
        g.fill(0, H - 9, W, H - 7, 0xFF6FCF7E);
        g.fill(0, H - 9, W, H - 8, 0xFFA6EDB0);
        int off = (int) (sc % 12);
        for (int x = -12; x < W + 12; x += 12) g.fill(x - off + 4, H - 6, x - off + 8, H - 4, 0x33FFFFFF);
        // the cat
        cat(g, (int) BX, (int) y);
        if (!started) {
            Gfx.rrect(g, W / 2 - 40, H - 36, 80, 13, 4, 0x88FFFFFF);
            ctext(g, "click / space", W / 2, H - 34, 0xFF7A3A5A);
        }
    }

    private static void pipe(GuiGraphics g, int x, int y, int w, int h) {
        if (h <= 0) return;
        g.fillGradient(x, y, x + w, y + h, 0xFF58B56B, 0xFF3F9453);
        g.fill(x + 2, y, x + 6, y + h, 0x55FFFFFF);
        g.fill(x + w - 5, y, x + w, y + h, 0x33000000);
        g.fill(x, y, x + 1, y + h, 0xFF2F7A42);
        g.fill(x + w - 1, y, x + w, y + h, 0xFF2F7A42);
    }

    private static void cap(GuiGraphics g, int x, int y) {
        Gfx.rrect(g, x, y, PIPE_W + 4, 8, 2, 0xFF2F7A42);
        Gfx.rrect(g, x + 1, y + 1, PIPE_W + 2, 6, 2, 0xFF4CA760);
        g.fill(x + 3, y + 1, x + 8, y + 7, 0x66FFFFFF);
        g.fill(x + PIPE_W - 3, y + 1, x + PIPE_W + 1, y + 7, 0x33000000);
    }

    private void cat(GuiGraphics g, int cx, int cy) {
        // soft shadow, tail, body, ears, face, flapping wing
        double flapK = started ? Math.sin(t * 0.5) : Math.sin(t * 0.15);
        int tilt = (int) Math.max(-3, Math.min(3, vy * 1.2));       // nose up/down: the face slides a little
        Gfx.glow(g, cx, cy, 13, 0xFFFFFFFF, 40);
        // tail
        Gfx.line(g, cx - 8, cy + 2, cx - 12, cy - 1 + (int) (flapK * 2), 0xFFD0709A);
        Gfx.line(g, cx - 8, cy + 3, cx - 12, cy + (int) (flapK * 2), 0xFFD0709A);
        Gfx.line(g, cx - 12, cy - 1 + (int) (flapK * 2), cx - 13, cy - 4 + (int) (flapK * 2), 0xFFD0709A);
        // body
        Gfx.ellipse(g, cx, cy + 1, 9, 7, 0xFFC95A86);
        Gfx.ellipse(g, cx, cy, 8, 6, 0xFFF58FB8);
        Gfx.ellipse(g, cx + 1, cy + 3, 5, 3, 0xFFFFD0E2);          // belly
        // ears
        for (int s = -1; s <= 1; s += 2) {
            int ex = cx + s * 5;
            g.fill(ex - 2, cy - 8, ex + 2, cy - 5, 0xFFF58FB8);
            g.fill(ex - 1, cy - 9, ex + 1, cy - 8, 0xFFF58FB8);
            g.fill(ex - 1, cy - 7, ex + 1, cy - 5, 0xFFFFC2D8);
        }
        // wing
        int wy = cy + 1 + (int) (flapK * 3);
        Gfx.ellipse(g, cx - 3, wy, 4, 3, 0xFFFFFFFF);
        Gfx.ellipse(g, cx - 3, wy + 1, 3, 2, 0xFFFFE0EE);
        // face
        int fy = cy - 1 + tilt / 2;
        g.fill(cx + 1, fy - 1, cx + 4, fy + 2, 0xFF3A2A3A);
        g.fill(cx + 5, fy - 1, cx + 8, fy + 2, 0xFF3A2A3A);
        g.fill(cx + 1, fy - 1, cx + 2, fy, 0xFFFFFFFF);
        g.fill(cx + 5, fy - 1, cx + 6, fy, 0xFFFFFFFF);
        g.fill(cx + 3, fy + 3, cx + 5, fy + 4, 0xFFC04A7A);          // nose/mouth
        g.fill(cx, fy + 3, cx + 2, fy + 4, 0x66FF6A9A);              // blush
        g.fill(cx + 7, fy + 3, cx + 9, fy + 4, 0x66FF6A9A);
        // whiskers
        g.fill(cx + 9, fy + 2, cx + 13, fy + 3, 0xFFFFFFFF);
        g.fill(cx + 9, fy + 4, cx + 12, fy + 5, 0xFFFFFFFF);
        if (started && (t / 4) % 2 == 0) Gfx.sparkle(g, cx - 14, cy + 4, 2, t, 0xAAFFFFFF);
    }

    @Override
    public String hintKey() { return "cutemod.hint.flappy"; }
}
