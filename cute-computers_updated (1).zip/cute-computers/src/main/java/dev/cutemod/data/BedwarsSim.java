package dev.cutemod.data;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Random;

/**
 * Bed Wars (a top-down mini version of the server game, for four teams of one player: people and / or computer players).
 * <p>
 * The whole game lives here and has no Minecraft classes in it, so the same code runs on the server (online rooms) and on
 * the client (a game against the computer players) and can be tested alone. It ticks {@link #TPS} times a second.
 * <ul>
 *   <li>Four islands in the corners and one in the middle float in the void. Every island team has a bed, a generator (iron and
 *       gold pile up on its tile, anybody who steps on the tile takes them) and a shop. The middle has diamonds and emeralds.</li>
 *   <li>While the bed is whole a player that dies comes back after {@link #RESPAWN} ticks; when the bed is gone the next death is the
 *       last one. The last team standing wins. Falling into the void (or being knocked into it) is a death.</li>
 *   <li>Blocks: a bridge goes over the void (hold the bridge key and walk), a wall goes on the ground (it blocks the way and
 *       hides the bed). A hit breaks the walls of anybody and the bridges and beds of the others.</li>
 *   <li>After {@link #BEDS_GONE_AT} ticks all the beds break (sudden death); after {@link #TIME_UP} ticks the best team wins.</li>
 * </ul>
 * Directions: 0 down, 1 left, 2 right, 3 up (the opposite of d is 3 - d); -1 means nothing.
 * Resources: 0 iron, 1 gold, 2 diamond, 3 emerald.
 */
public final class BedwarsSim {
    public static final int COLS = 25, ROWS = 15, N = COLS * ROWS, CELL = 16;
    public static final int TPS = 20;
    public static final int COUNTDOWN = 60, END_DELAY = 40, RESPAWN = 80, SPAWN_SHIELD = 40;
    public static final int BEDS_GONE_AT = 4800, TIME_UP = 8400;
    /** VOID: nothing (a fall). FLOOR: an island. BRIDGE: a block that was put over the void. WALL_F / WALL_B: a wall on the ground / on a bridge. */
    public static final byte VOID = 0, FLOOR = 1, BRIDGE = 2, WALL_F = 3, WALL_B = 4;
    public static final int MAX_HP = 20, BED_HP = 8, WALL_HP = 3, BRIDGE_HP = 2;
    public static final int SPEED = 3, KB_SPEED = 5, KB_TICKS = 4, ATK_CD = 10, PLACE_CD = 3, FALL_TICKS = 3;
    public static final int[] SWORD_DMG = {3, 4, 6, 8};
    public static final int[] ARMOR_PCT = {0, 20, 35, 50};
    public static final int MAX_BLOCKS = 99, BLOCKS_PER_BUY = 12;
    public static final int IRON = 0, GOLD = 1, DIA = 2, EM = 3;
    /** The shop: 1 blocks, 2 sword (next level), 3 armor (next level), 4 golden apple (heals). */
    public static final int SHOP_BLOCKS = 1, SHOP_SWORD = 2, SHOP_ARMOR = 3, SHOP_APPLE = 4;
    private static final int[] SWORD_RES = {IRON, GOLD, DIA}, SWORD_COST = {10, 7, 4};
    private static final int[] ARMOR_RES = {IRON, GOLD, EM}, ARMOR_COST = {20, 12, 4};
    public static final int BLOCKS_RES = IRON, BLOCKS_COST = 4, APPLE_RES = GOLD, APPLE_COST = 3, APPLE_HEAL = 10;
    public static final int SHOP_RANGE = 40, PICK_RANGE = 13, REACH = 26;
    public static final int START_IRON = 8;
    public static final int IRON_EVERY = 16, GOLD_EVERY = 140, DIA_EVERY = 480, EM_EVERY = 960;
    public static final int IRON_CAP = 32, GOLD_CAP = 8, DIA_CAP = 4, EM_CAP = 3;
    public static final int ST_COUNT = 0, ST_PLAY = 1, ST_OVER = 2;
    /** winner: a team number, or DRAW or HUMANS_OUT (only computer players were left). */
    public static final int NONE = -1, DRAW = -1, HUMANS_OUT = -2;
    public static final int MAPS = 1;

    static final int[] DX = {0, -1, 1, 0}, DY = {1, 0, 0, -1};
    private static final int INF = 99999;

    // ------------------------------------------------------------------ the map

    /** The island of team t starts at this cell (the island is 5 x 5). */
    public static int islandX(int t) { return (t & 1) == 0 ? 1 : COLS - 6; }

    public static int islandY(int t) { return t < 2 ? 1 : ROWS - 6; }

    /** The map cell of the local cell (lx, ly) of the island of team t; the local cell (0, 0) is the corner that is the farthest from the middle. */
    public static int gx(int t, int lx) { return (t & 1) == 0 ? islandX(t) + lx : islandX(t) + 4 - lx; }

    public static int gy(int t, int ly) { return t < 2 ? islandY(t) + ly : islandY(t) + 4 - ly; }

    public static int bedCell(int t) { return gy(t, 2) * COLS + gx(t, 0); }

    public static int spawnCell(int t) { return gy(t, 2) * COLS + gx(t, 2); }

    public static int genCell(int t) { return gy(t, 1) * COLS + gx(t, 2); }

    public static int shopCell(int t) { return gy(t, 3) * COLS + gx(t, 2); }

    /** The middle: two diamond piles and the emerald pile between them. */
    public static final int[] MID_DIA = {7 * COLS + 11, 7 * COLS + 13};
    public static final int MID_EM = 7 * COLS + 12;

    /** The direction that points from the island of team t to the outside (the way the bed is). */
    public static int outward(int t) { return (t & 1) == 0 ? 1 : 2; }

    private static boolean isIsland(int x, int y) {
        for (int t = 0; t < 4; t++) {
            int ox = islandX(t), oy = islandY(t);
            if (x >= ox && x < ox + 5 && y >= oy && y < oy + 5) return true;
        }
        return x >= 10 && x <= 14 && y >= 5 && y <= 9;
    }

    private static boolean special(int c) {
        for (int t = 0; t < 4; t++) if (c == bedCell(t) || c == spawnCell(t) || c == genCell(t) || c == shopCell(t)) return true;
        return c == MID_DIA[0] || c == MID_DIA[1] || c == MID_EM;
    }

    // ------------------------------------------------------------------ the state

    public static final class Player {
        public int idx;
        public boolean active, ai, alive, out;
        public int level;                          // the skill of a computer player: 0 easy, 1 normal, 2 hard
        public int x, y;                           // the middle of the player, in units
        public int facing, moving = -1;
        public int hp = MAX_HP, iron, gold, dia, em, blocks, sword, armor;
        public int kills, beds, place, respawn, cd, hurt, swing, invuln;
        int kbx, kby, kbT, lastHit = -1, lastHitT, fall, regen, placeCd;
        // what a person (or the thinking of a computer player) wants right now
        int want = -1;
        boolean atkHeld, bridgeHeld, wallReq;
        int buyReq;
        // the thinking of a computer player
        int goal, goalCell = -1, thinkIn, trip, wallStep, lastMid, stuck, lastCell = -1;

        public int cx() { return x / CELL; }

        public int cy() { return y / CELL; }

        public int cell() { return cy() * COLS + cx(); }

        public int res(int r) { return r == IRON ? iron : r == GOLD ? gold : r == DIA ? dia : em; }

        void add(int r, int n) {
            if (r == IRON) iron += n; else if (r == GOLD) gold += n; else if (r == DIA) dia += n; else em += n;
        }
    }

    public final byte[] tile = new byte[N], owner = new byte[N], hp = new byte[N];
    public final Player[] pl = new Player[4];
    public final int[] bedHp = new int[4];
    public final int[] ironPile = new int[4], goldPile = new int[4];
    public final int[] diaPile = new int[2];
    public int emPile;
    public int state = ST_COUNT, countdown = COUNTDOWN, play, tick, winner = NONE, overTicks;
    public boolean sudden, done;
    public int map;

    private final Random rnd;
    private final int[] dist = new int[N], queue = new int[N + 1];
    private final boolean[] inq = new boolean[N];

    public BedwarsSim() { this(new Random()); }

    public BedwarsSim(Random rnd) {
        this.rnd = rnd;
        for (int i = 0; i < 4; i++) { pl[i] = new Player(); pl[i].idx = i; }
    }

    // ------------------------------------------------------------------ set up

    /** Puts a player (or a computer player) into the island number slot. Call before {@link #start()}. */
    public void setup(int slot, boolean ai, int level) {
        Player p = pl[slot];
        p.active = true; p.ai = ai; p.level = Math.max(0, Math.min(2, level));
    }

    public void setMap(int m) { map = 0; }

    public boolean isWinner(int slot) { return winner >= 0 && pl[slot].active && winner == slot; }

    /** Builds the map and puts the players on their islands. The round begins after the countdown. */
    public void start() {
        Arrays.fill(tile, VOID);
        Arrays.fill(owner, (byte) 0);
        Arrays.fill(hp, (byte) 0);
        for (int y = 0; y < ROWS; y++) for (int x = 0; x < COLS; x++) if (isIsland(x, y)) tile[y * COLS + x] = FLOOR;
        for (int t = 0; t < 4; t++) {
            Player p = pl[t];
            bedHp[t] = p.active ? BED_HP : 0;
            ironPile[t] = 0; goldPile[t] = 0;
            p.alive = p.active; p.out = false;
            p.hp = MAX_HP; p.iron = p.active ? START_IRON : 0; p.gold = 0; p.dia = 0; p.em = 0; p.blocks = 0; p.sword = 0; p.armor = 0;
            p.kills = 0; p.beds = 0; p.place = 0; p.respawn = 0; p.cd = 0; p.hurt = 0; p.swing = 0; p.invuln = 0;
            p.kbx = p.kby = p.kbT = 0; p.lastHit = -1; p.lastHitT = 0; p.fall = 0; p.regen = 0; p.placeCd = 0;
            p.want = -1; p.atkHeld = p.bridgeHeld = p.wallReq = false; p.buyReq = 0; p.moving = -1;
            p.goal = 0; p.goalCell = -1; p.thinkIn = rnd.nextInt(8); p.trip = 0; p.wallStep = 0; p.lastMid = 0; p.stuck = 0; p.lastCell = -1;
            toSpawn(p);
        }
        diaPile[0] = diaPile[1] = 0; emPile = 0;
        state = ST_COUNT; countdown = COUNTDOWN; play = 0; tick = 0; winner = NONE; overTicks = 0;
        sudden = false; done = false;
    }

    private void toSpawn(Player p) {
        int c = spawnCell(p.idx);
        p.x = (c % COLS) * CELL + CELL / 2;
        p.y = (c / COLS) * CELL + CELL / 2;
        p.facing = (p.idx & 1) == 0 ? 2 : 1;
        p.kbT = 0; p.fall = 0; p.moving = -1;
    }

    /**
     * What a person wants right now: a direction (or -1), whether he holds the attack and the bridge keys, a wall request
     * (counts once) and what he wants to buy (counts once, 0 is nothing).
     */
    public void input(int slot, int dir, boolean attack, boolean bridge, boolean wall, int buy) {
        Player p = pl[slot];
        if (p.ai) return;
        p.want = dir < 0 || dir > 3 ? -1 : dir;
        p.atkHeld = attack;
        p.bridgeHeld = bridge;
        if (wall) p.wallReq = true;
        if (buy > 0 && buy <= 4) p.buyReq = buy;
    }

    /** A person leaves the round and a computer player takes his place (he goes on from where he stands, with the same things). */
    public void takeOver(int slot, int level) {
        Player p = pl[slot];
        if (!p.active || p.ai || state == ST_OVER) return;
        p.ai = true;
        p.level = Math.max(0, Math.min(2, level));
        p.want = -1; p.atkHeld = p.bridgeHeld = p.wallReq = false; p.buyReq = 0;
        p.goal = 0; p.goalCell = -1; p.thinkIn = 0;
    }

    // ------------------------------------------------------------------ prices

    /** The price of the shop item for this player: {resource, amount}, or null if there is nothing to buy (the best level is reached). */
    public static int[] price(int item, Player p) {
        switch (item) {
            case SHOP_BLOCKS: return new int[]{BLOCKS_RES, BLOCKS_COST};
            case SHOP_SWORD: return p.sword >= 3 ? null : new int[]{SWORD_RES[p.sword], SWORD_COST[p.sword]};
            case SHOP_ARMOR: return p.armor >= 3 ? null : new int[]{ARMOR_RES[p.armor], ARMOR_COST[p.armor]};
            case SHOP_APPLE: return new int[]{APPLE_RES, APPLE_COST};
            default: return null;
        }
    }

    public boolean canBuy(Player p, int item) {
        int[] pr = price(item, p);
        if (pr == null || p.res(pr[0]) < pr[1]) return false;
        if (item == SHOP_BLOCKS) return p.blocks < MAX_BLOCKS;
        if (item == SHOP_APPLE) return p.hp < MAX_HP;
        return true;
    }

    private boolean nearShop(Player p) {
        int c = shopCell(p.idx);
        return near(p, c, SHOP_RANGE);
    }

    private static boolean near(Player p, int cell, int range) {
        int dx = p.x - ((cell % COLS) * CELL + CELL / 2), dy = p.y - ((cell / COLS) * CELL + CELL / 2);
        return dx * dx + dy * dy <= range * range;
    }

    private void buy(Player p, int item) {
        if (!nearShop(p) || !canBuy(p, item)) return;
        int[] pr = price(item, p);
        p.add(pr[0], -pr[1]);
        switch (item) {
            case SHOP_BLOCKS -> p.blocks = Math.min(MAX_BLOCKS, p.blocks + BLOCKS_PER_BUY);
            case SHOP_SWORD -> p.sword++;
            case SHOP_ARMOR -> p.armor++;
            default -> p.hp = Math.min(MAX_HP, p.hp + APPLE_HEAL);
        }
    }

    // ------------------------------------------------------------------ the round

    public int aliveCount() {
        int n = 0;
        for (Player p : pl) if (p.active && !p.out) n++;
        return n;
    }

    private boolean solid(int c) { return tile[c] == WALL_F || tile[c] == WALL_B; }

    private static boolean inBoard(int cx, int cy) { return cx >= 0 && cy >= 0 && cx < COLS && cy < ROWS; }

    public void tick() {
        tick++;
        if (state == ST_COUNT) {
            if (--countdown <= 0) state = ST_PLAY;
            return;
        }
        if (state == ST_OVER) {
            if (++overTicks >= END_DELAY) done = true;
            return;
        }
        play++;
        if (play >= BEDS_GONE_AT && !sudden) {                               // sudden death: all the beds break
            sudden = true;
            for (int t = 0; t < 4; t++) bedHp[t] = 0;
        }
        generators();
        for (int k = 0; k < 4; k++) {                                              // the order changes every tick, so nobody strikes first all the time
            Player p = pl[(k + play) & 3];
            if (!p.active || p.out) continue;
            if (!p.alive) {
                if (p.respawn > 0 && --p.respawn == 0) respawn(p);
                continue;
            }
            if (p.cd > 0) p.cd--;
            if (p.swing > 0) p.swing--;
            if (p.hurt > 0) p.hurt--;
            if (p.invuln > 0) p.invuln--;
            if (p.placeCd > 0) p.placeCd--;
            if (p.lastHitT > 0 && --p.lastHitT == 0) p.lastHit = -1;
            if (p.hp < MAX_HP && ++p.regen >= 60) { p.hp++; p.regen = 0; }
            if (p.ai) think(p);
            act(p);
            move(p);
            pickup(p);
        }
        for (Player p : pl) if (p.active && p.alive && !p.out) checkFall(p);
        end();
    }

    private void generators() {
        for (int t = 0; t < 4; t++) {
            if (!pl[t].active || pl[t].out) continue;
            if (play % IRON_EVERY == 0 && ironPile[t] < IRON_CAP) ironPile[t]++;
            if (play % GOLD_EVERY == 0 && goldPile[t] < GOLD_CAP) goldPile[t]++;
        }
        if (play % DIA_EVERY == 0) for (int i = 0; i < 2; i++) if (diaPile[i] < DIA_CAP) diaPile[i]++;
        if (play % EM_EVERY == 0 && emPile < EM_CAP) emPile++;
    }

    private void pickup(Player p) {
        for (int t = 0; t < 4; t++) {
            if (!pl[t].active) continue;
            if ((ironPile[t] > 0 || goldPile[t] > 0) && near(p, genCell(t), PICK_RANGE)) {
                p.iron += ironPile[t]; p.gold += goldPile[t];
                ironPile[t] = 0; goldPile[t] = 0;
            }
        }
        for (int i = 0; i < 2; i++) if (diaPile[i] > 0 && near(p, MID_DIA[i], PICK_RANGE)) { p.dia += diaPile[i]; diaPile[i] = 0; p.lastMid = play; }
        if (emPile > 0 && near(p, MID_EM, PICK_RANGE)) { p.em += emPile; emPile = 0; p.lastMid = play; }
    }

    private void respawn(Player p) {
        p.alive = true;
        p.hp = MAX_HP; p.invuln = SPAWN_SHIELD; p.cd = 0; p.hurt = 0; p.regen = 0;
        p.want = -1;
        toSpawn(p);
    }

    // ------------------------------------------------------------------ what a player does

    private void act(Player p) {
        if (p.buyReq > 0) { buy(p, p.buyReq); p.buyReq = 0; }
        if (p.wallReq) { p.wallReq = false; placeWall(p); }
        if (p.bridgeHeld && p.placeCd == 0) placeBridge(p);
        if (p.atkHeld && p.cd == 0) attack(p);
    }

    private int ahead(Player p) {
        int cx = p.cx() + DX[p.facing], cy = p.cy() + DY[p.facing];
        return inBoard(cx, cy) ? cy * COLS + cx : -1;
    }

    private void placeBridge(Player p) {
        int c = ahead(p);
        if (c < 0 || tile[c] != VOID || p.blocks <= 0) return;
        p.blocks--;
        tile[c] = BRIDGE; owner[c] = (byte) p.idx; hp[c] = BRIDGE_HP;
        p.placeCd = PLACE_CD;
    }

    private void placeWall(Player p) {
        int c = ahead(p);
        if (c < 0 || p.blocks <= 0 || special(c)) return;
        if (tile[c] != FLOOR && tile[c] != BRIDGE) return;
        for (Player q : pl) if (q.active && q.alive && q.cell() == c) return;        // somebody stands there
        p.blocks--;
        tile[c] = tile[c] == FLOOR ? WALL_F : WALL_B;
        owner[c] = (byte) p.idx; hp[c] = WALL_HP;
    }

    private void attack(Player p) {
        p.cd = ATK_CD;
        p.swing = 5;
        // 1. a player in front of us
        Player best = null;
        int bestD = INF;
        int fx = DX[p.facing], fy = DY[p.facing];
        for (Player q : pl) {
            if (q == p || !q.active || !q.alive || q.out) continue;
            int dx = q.x - p.x, dy = q.y - p.y;
            int fwd = dx * fx + dy * fy, lat = Math.abs(dx * fy - dy * fx);
            if (fwd < -2 || fwd > REACH || lat > 13) continue;
            int d = dx * dx + dy * dy;
            if (d < bestD) { bestD = d; best = q; }
        }
        if (best != null) { hitPlayer(p, best); return; }
        // 2. the bed or a block on the tile in front of us
        int c = ahead(p);
        if (c < 0) return;
        for (int t = 0; t < 4; t++) {
            if (t != p.idx && bedHp[t] > 0 && bedCell(t) == c) {
                if (--bedHp[t] == 0) p.beds++;
                return;
            }
        }
        if (tile[c] == WALL_F || tile[c] == WALL_B) hitBlock(c);
        else if (tile[c] == BRIDGE && owner[c] != p.idx) hitBlock(c);
    }

    private void hitBlock(int c) {
        if (--hp[c] > 0) return;
        if (tile[c] == WALL_F) { tile[c] = FLOOR; hp[c] = 0; }
        else if (tile[c] == WALL_B) { tile[c] = BRIDGE; hp[c] = BRIDGE_HP; }
        else { tile[c] = VOID; hp[c] = 0; }
    }

    private void hitPlayer(Player a, Player b) {
        if (b.invuln > 0) return;
        int raw = SWORD_DMG[a.sword];
        int dmg = Math.max(1, (raw * (100 - ARMOR_PCT[b.armor]) + 50) / 100);
        b.hp -= dmg;
        b.hurt = 6;
        b.lastHit = a.idx; b.lastHitT = 100;
        b.kbx = DX[a.facing]; b.kby = DY[a.facing]; b.kbT = KB_TICKS;
        if (b.hp <= 0) die(b, a.idx);
    }

    private void die(Player p, int killer) {
        if (!p.alive) return;
        p.alive = false;
        p.moving = -1; p.kbT = 0; p.hurt = 0; p.hp = 0;
        int k = killer >= 0 ? killer : p.lastHit;
        if (k >= 0 && k != p.idx && pl[k].active) pl[k].kills++;
        p.iron = p.gold = p.dia = p.em = 0;
        p.blocks = 0;
        p.sword = Math.max(0, p.sword - 1);
        p.lastHit = -1; p.lastHitT = 0;
        if (bedHp[p.idx] > 0) p.respawn = RESPAWN;
        else {
            int remaining = 0;
            for (Player q : pl) if (q.active && !q.out) remaining++;
            p.place = Math.max(1, remaining);
            p.out = true;
        }
    }

    // ------------------------------------------------------------------ moving

    private void move(Player p) {
        p.moving = -1;
        if (p.kbT > 0) { step(p, p.kbx, p.kby, KB_SPEED); p.kbT--; }
        if (p.want >= 0 && p.want < 4) {
            p.facing = p.want;
            p.moving = p.want;
            step(p, DX[p.want], DY[p.want], SPEED);
        }
    }

    private void step(Player p, int dx, int dy, int len) {
        int nx = Math.max(0, Math.min(COLS * CELL - 1, p.x + dx * len));
        int ny = Math.max(0, Math.min(ROWS * CELL - 1, p.y + dy * len));
        int c = (ny / CELL) * COLS + nx / CELL;
        if (solid(c)) return;
        p.x = nx; p.y = ny;
    }

    private void checkFall(Player p) {
        if (tile[p.cell()] == VOID) {
            if (++p.fall >= FALL_TICKS) die(p, -1);
        } else p.fall = 0;
    }

    // ------------------------------------------------------------------ the end

    private void end() {
        int teams = 0, last = -1, humans = 0, humansIn = 0;
        for (Player p : pl) {
            if (!p.active) continue;
            if (!p.ai) { humans++; if (!p.out) humansIn++; }
            if (!p.out) { teams++; last = p.idx; }
        }
        boolean timeUp = play >= TIME_UP;
        if (teams <= 1 || (humans > 0 && humansIn == 0) || timeUp) {
            state = ST_OVER;
            overTicks = 0;
            if (teams == 1) {
                winner = last;
                pl[last].place = 1;
            } else if (teams == 0) winner = DRAW;
            else if (timeUp) {
                int best = -1, bestScore = -1, tied = 0;
                for (Player p : pl) {
                    if (!p.active || p.out) continue;
                    int s = p.kills + p.beds * 2;
                    if (s > bestScore) { bestScore = s; best = p.idx; tied = 1; } else if (s == bestScore) tied++;
                }
                winner = tied == 1 ? best : DRAW;
                if (winner >= 0) pl[winner].place = 1;
            } else winner = HUMANS_OUT;
        }
    }

    // ------------------------------------------------------------------ the computer players

    /** The cost of walking into a cell: used to find the way (a void cell needs a block, a wall has to be broken). */
    private int enter(Player p, int c, boolean bridging) {
        switch (tile[c]) {
            case FLOOR: case BRIDGE: return 1;
            case VOID: return bridging ? 4 : 60;
            default: return 7;
        }
    }

    /** Finds the distance of every cell to goalCell (dist[]), walls and bridges included. */
    private void field(Player p, int goalCell) {
        Arrays.fill(dist, INF);
        Arrays.fill(inq, false);
        boolean bridging = p.blocks > 0;
        int head = 0, tail = 0, size = queue.length;
        dist[goalCell] = 0;
        queue[tail] = goalCell; tail = (tail + 1) % size; inq[goalCell] = true;
        while (head != tail) {
            int c = queue[head];
            head = (head + 1) % size;
            inq[c] = false;
            int cx = c % COLS, cy = c / COLS;
            int cost = enter(p, c, bridging);
            for (int d = 0; d < 4; d++) {
                int nx = cx + DX[d], ny = cy + DY[d];
                if (!inBoard(nx, ny)) continue;
                int n = ny * COLS + nx;
                int nd = dist[c] + cost;
                if (nd < dist[n]) {
                    dist[n] = nd;
                    if (!inq[n]) { queue[tail] = n; tail = (tail + 1) % size; inq[n] = true; }
                }
            }
        }
    }

    /** One step towards the goal: the direction (or -1), the field must have been made for that goal. */
    private int bestStep(Player p) {
        int cx = p.cx(), cy = p.cy();
        int here = cy * COLS + cx, bestD = -1, best = INF;
        for (int k = 0; k < 4; k++) {
            int d = (k + tick / 7) % 4;                                    // the order changes a little, so a bot does not walk in lines
            int nx = cx + DX[d], ny = cy + DY[d];
            if (!inBoard(nx, ny)) continue;
            int n = ny * COLS + nx;
            if (dist[n] < best) { best = dist[n]; bestD = d; }
        }
        return best >= dist[here] ? -1 : bestD;
    }

    private int voidsOnTheWay(Player p, int goalCell) {
        int c = p.cell(), n = 0, guard = 0;
        while (c != goalCell && guard++ < 80) {
            int cx = c % COLS, cy = c / COLS, best = INF, bn = -1;
            for (int d = 0; d < 4; d++) {
                int nx = cx + DX[d], ny = cy + DY[d];
                if (!inBoard(nx, ny)) continue;
                int q = ny * COLS + nx;
                if (dist[q] < best) { best = dist[q]; bn = q; }
            }
            if (bn < 0 || best >= dist[c]) break;
            c = bn;
            if (tile[c] == VOID) n++;
        }
        return n;
    }

    private Player nearestEnemy(Player p, int maxDist) {
        Player best = null;
        int bd = maxDist * maxDist;
        for (Player q : pl) {
            if (q == p || !q.active || !q.alive || q.out) continue;
            int dx = q.x - p.x, dy = q.y - p.y, d = dx * dx + dy * dy;
            if (d < bd) { bd = d; best = q; }
        }
        return best;
    }

    private void think(Player p) {
        // the controls are read afresh every tick
        p.want = -1; p.atkHeld = false; p.bridgeHeld = false;
        if (p.thinkIn > 0) { p.thinkIn--; if (p.goal != 3) { follow(p); return; } }
        p.thinkIn = p.level == 0 ? 9 : p.level == 1 ? 4 : 2;
        shop(p);
        int home = genCell(p.idx);
        Player foe = nearestEnemy(p, 4 * CELL);
        // 1. fight: somebody is close
        if (foe != null && (p.hp > 6 || p.level == 0 || foe.hp < p.hp)) {
            p.goal = 3;
            p.goalCell = foe.cell();
            fight(p, foe);
            return;
        }
        if (p.goal == 3) { p.goal = 0; p.goalCell = -1; }
        // 2. somebody is near the bed: go and get him
        Player thief = null;
        for (Player q : pl) {
            if (q == p || !q.active || !q.alive || q.out) continue;
            int b = bedCell(p.idx);
            int dx = q.x - ((b % COLS) * CELL + 8), dy = q.y - ((b / COLS) * CELL + 8);
            if (dx * dx + dy * dy < 5 * CELL * 5 * CELL && bedHp[p.idx] > 0) { thief = q; break; }
        }
        if (thief != null && p.hp > 5) { p.goal = 3; p.goalCell = thief.cell(); fight(p, thief); return; }
        // 3. walls round the bed (once, the first thing)
        if (p.level >= 1 && p.wallStep < 3 && p.blocks >= 3 && bedHp[p.idx] > 0) { wallBed(p); return; }
        // 4. go somewhere
        p.goalCell = chooseGoal(p, home);
        follow(p);
    }

    private int chooseGoal(Player p, int home) {
        int blocksNeeded = 10;
        int rushAt = p.level == 0 ? 900 : p.level == 1 ? 600 : 400;                // the easy ones take their time
        boolean ready = p.blocks >= blocksNeeded && p.sword >= 1 && play > rushAt;
        if (p.hp < 8 && !(p.gold >= APPLE_COST)) ready = false;
        // a trip to the middle for the diamonds and emeralds (the hard ones)
        if (p.level >= 1 && p.blocks >= 8 && p.hp > 12 && play - p.lastMid > 900 && play > 500) {
            int best = -1, bd = INF;
            int[] cells = {MID_DIA[0], MID_DIA[1], MID_EM};
            int[] have = {diaPile[0], diaPile[1], emPile};
            for (int i = 0; i < 3; i++) {
                if (have[i] <= 0) continue;
                field(p, cells[i]);
                int d = dist[p.cell()];
                if (d < bd) { bd = d; best = cells[i]; }
            }
            if (best >= 0) {
                p.goal = 4;
                return best;
            }
        }
        if (ready) {
            // the nearest bed that is still there; when none is, the nearest player
            int best = -1, bd = INF;
            for (int t = 0; t < 4; t++) {
                if (t == p.idx || !pl[t].active || pl[t].out || bedHp[t] <= 0) continue;
                field(p, bedCell(t));
                int d = dist[p.cell()];
                if (d < bd) { bd = d; best = bedCell(t); }
            }
            if (best < 0) {
                for (Player q : pl) {
                    if (q == p || !q.active || !q.alive || q.out) continue;
                    field(p, q.cell());
                    int d = dist[p.cell()];
                    if (d < bd) { bd = d; best = q.cell(); }
                }
            }
            if (best >= 0) {
                field(p, best);
                int voids = voidsOnTheWay(p, best);
                if (voids + 2 <= p.blocks) { p.goal = 2; return best; }
            }
        }
        p.goal = 0;
        return home;
    }

    /** Buys what the player can afford (only near his shop): the thing he needs most first. */
    private void shop(Player p) {
        if (!nearShop(p)) return;
        if (p.hp < 9 && canBuy(p, SHOP_APPLE)) { buy(p, SHOP_APPLE); return; }
        if (p.blocks < 8 && canBuy(p, SHOP_BLOCKS)) { buy(p, SHOP_BLOCKS); return; }
        if (p.level == 2 && canBuy(p, SHOP_ARMOR) && p.armor <= p.sword) { buy(p, SHOP_ARMOR); return; }
        if (canBuy(p, SHOP_SWORD)) { buy(p, SHOP_SWORD); return; }
        if (canBuy(p, SHOP_ARMOR) && p.level >= 1) { buy(p, SHOP_ARMOR); return; }
        if (p.blocks < 30 && p.iron >= 12 && canBuy(p, SHOP_BLOCKS)) { buy(p, SHOP_BLOCKS); return; }
        if (p.hp < 15 && canBuy(p, SHOP_APPLE)) buy(p, SHOP_APPLE);
    }

    /** The three walls round the bed: stand next to the tile and face the outside. */
    private void wallBed(Player p) {
        int t = p.idx;
        int[][] stand = {{2, 2}, {1, 1}, {1, 3}};
        int[][] target = {{1, 2}, {0, 1}, {0, 3}};
        while (p.wallStep < 3) {
            int tc = gy(t, target[p.wallStep][1]) * COLS + gx(t, target[p.wallStep][0]);
            if (tile[tc] == WALL_F || tile[tc] == WALL_B) p.wallStep++; else break;
        }
        if (p.wallStep >= 3) return;
        int sc = gy(t, stand[p.wallStep][1]) * COLS + gx(t, stand[p.wallStep][0]);
        p.goal = 1;
        if (p.cell() != sc) {
            p.goalCell = sc;
            field(p, sc);
            int d = bestStep(p);
            p.want = d;
            return;
        }
        p.facing = outward(t);
        p.wallReq = true;
    }

    /** Hit the player: turn to him, walk up to him and swing. */
    private void fight(Player p, Player foe) {
        int dx = foe.x - p.x, dy = foe.y - p.y;
        int d = Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 1 : 2) : (dy < 0 ? 3 : 0);
        int dist2 = dx * dx + dy * dy;
        int fwd = dx * DX[p.facing] + dy * DY[p.facing], lat = Math.abs(dx * DY[p.facing] - dy * DX[p.facing]);
        if (fwd < 0 || lat > 10) p.facing = d;                                      // turns to him (a computer player can turn without a step)
        boolean inReach = fwd >= 0 && fwd <= REACH && lat <= 13;
        boolean swing = p.level == 0 ? rnd.nextInt(10) < 5 : true;
        if (inReach && swing) p.atkHeld = true;
        if (dist2 > 18 * 18 || !inReach) {
            int nx = p.cx() + DX[d], ny = p.cy() + DY[d];
            if (inBoard(nx, ny)) {
                int n = ny * COLS + nx;
                if (tile[n] == VOID) { p.bridgeHeld = true; p.facing = d; }         // do not walk into the void: put a block
                else if (solid(n)) { p.facing = d; p.atkHeld = true; }
                else { p.want = d; }
            }
        }
    }

    /** Walks one step along the way to p.goalCell; breaks what is in the way; builds a bridge over the void. */
    private void follow(Player p) {
        int goal = p.goalCell;
        if (goal < 0) goal = genCell(p.idx);
        int here = p.cell();
        if (here == goal && p.goal != 2) return;
        field(p, goal);
        int d = bestStep(p);
        if (d < 0) { if (p.goal == 2 || p.goal == 4) { p.goal = 0; p.goalCell = genCell(p.idx); } return; }
        int nx = p.cx() + DX[d], ny = p.cy() + DY[d];
        int n = ny * COLS + nx;
        boolean bed = false;
        for (int t = 0; t < 4; t++) if (t != p.idx && bedHp[t] > 0 && bedCell(t) == n) bed = true;
        p.facing = d;
        if (bed || solid(n)) {
            p.atkHeld = true;                                                      // the bed or a wall is in the way: hit it
            return;
        }
        if (tile[n] == VOID) {
            if (p.blocks > 0) p.bridgeHeld = true;                                 // no step until the bridge is there
            else { p.goal = 0; p.goalCell = genCell(p.idx); }
            return;
        }
        p.want = d;
        // do not stand still on a wall that keeps changing: if we are stuck for long, give up the goal
        if (p.cell() == p.lastCell) { if (++p.stuck > 80) { p.stuck = 0; p.goal = 0; p.goalCell = genCell(p.idx); } } else { p.stuck = 0; p.lastCell = p.cell(); }
    }

    // ------------------------------------------------------------------ the network form

    /** The whole state as bytes (it is sent to the players 20 times a second). */
    public byte[] pack() {
        ByteBuffer b = ByteBuffer.allocate(64 + N + 4 * 32);
        b.put((byte) state).putShort((short) countdown).putShort((short) play).put((byte) (winner + 2));
        b.put((byte) ((sudden ? 1 : 0) | (done ? 2 : 0)));
        for (int i = 0; i < N; i++) b.put((byte) (tile[i] | (owner[i] << 3) | (hp[i] << 5)));
        for (int t = 0; t < 4; t++) b.put((byte) bedHp[t]);
        for (int t = 0; t < 4; t++) b.put((byte) ironPile[t]).put((byte) goldPile[t]);
        b.put((byte) diaPile[0]).put((byte) diaPile[1]).put((byte) emPile);
        for (Player p : pl) {
            b.put((byte) ((p.active ? 1 : 0) | (p.alive ? 2 : 0) | (p.ai ? 4 : 0) | (p.out ? 8 : 0) | (p.hurt > 0 ? 16 : 0) | (p.swing > 0 ? 32 : 0) | (p.moving >= 0 ? 64 : 0)));
            b.putShort((short) p.x).putShort((short) p.y);
            b.put((byte) p.facing).put((byte) p.hp);
            b.putShort((short) p.iron).putShort((short) p.gold);
            b.put((byte) p.dia).put((byte) p.em).put((byte) p.blocks).put((byte) p.sword).put((byte) p.armor);
            b.put((byte) p.kills).put((byte) p.beds).put((byte) p.place).putShort((short) p.respawn).put((byte) (p.invuln > 0 ? 1 : 0));
        }
        return Arrays.copyOf(b.array(), b.position());
    }

    /** The other way: makes this object look like the state that was sent. Returns false if the bytes make no sense. */
    public boolean unpack(byte[] data) {
        try {
            ByteBuffer b = ByteBuffer.wrap(data);
            state = b.get();
            countdown = b.getShort();
            play = b.getShort();
            winner = b.get() - 2;
            int fl = b.get();
            sudden = (fl & 1) != 0;
            done = (fl & 2) != 0;
            for (int i = 0; i < N; i++) {
                int v = b.get() & 255;
                tile[i] = (byte) (v & 7);
                owner[i] = (byte) ((v >> 3) & 3);
                hp[i] = (byte) ((v >> 5) & 3);
                if (tile[i] > WALL_B) return false;
            }
            for (int t = 0; t < 4; t++) bedHp[t] = b.get();
            for (int t = 0; t < 4; t++) { ironPile[t] = b.get() & 255; goldPile[t] = b.get() & 255; }
            diaPile[0] = b.get(); diaPile[1] = b.get(); emPile = b.get();
            for (Player p : pl) {
                int f = b.get();
                p.active = (f & 1) != 0; p.alive = (f & 2) != 0; p.ai = (f & 4) != 0; p.out = (f & 8) != 0;
                p.hurt = (f & 16) != 0 ? 1 : 0; p.swing = (f & 32) != 0 ? 1 : 0;
                p.x = b.getShort(); p.y = b.getShort();
                p.facing = b.get(); p.hp = b.get();
                p.moving = (f & 64) != 0 ? p.facing : -1;
                p.iron = b.getShort(); p.gold = b.getShort();
                p.dia = b.get(); p.em = b.get(); p.blocks = b.get(); p.sword = b.get(); p.armor = b.get();
                p.kills = b.get(); p.beds = b.get(); p.place = b.get(); p.respawn = b.getShort(); p.invuln = b.get();
                if (p.facing < 0 || p.facing > 3 || p.sword < 0 || p.sword > 3 || p.armor < 0 || p.armor > 3) return false;
            }
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** How the round went for a player, for the score: 60 for the win (20 for second place), 15 per player put out, 30 per bed broken. */
    public int scoreOf(int slot) {
        Player p = pl[slot];
        int s = p.kills * 15 + p.beds * 30;
        if (isWinner(slot)) s += 60;
        else if (p.place == 2) s += 20;
        return s;
    }
}
