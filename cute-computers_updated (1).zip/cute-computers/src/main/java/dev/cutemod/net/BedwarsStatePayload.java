package dev.cutemod.net;

import dev.cutemod.CuteMod;
import dev.cutemod.client.ClientHooks;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Server -> client, 20 times a second during a round: your island (0..3) and the whole round ({@link dev.cutemod.data.BedwarsSim#pack()}). */
public record BedwarsStatePayload(int slot, byte[] data) implements CustomPacketPayload {
    public static final Type<BedwarsStatePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CuteMod.MOD_ID, "bedwars_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BedwarsStatePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, BedwarsStatePayload::slot,
            ByteBufCodecs.byteArray(1024), BedwarsStatePayload::data,
            BedwarsStatePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(BedwarsStatePayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHooks.onBedwarsState(p));
    }
}
