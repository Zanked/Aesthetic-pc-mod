package dev.cutemod.market;

import dev.cutemod.item.ModItems;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Instrument;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Everything CuteMarket sells, in one place shared by the app and the server (prices and delivery times can
 * never disagree): the mod's own foods, the music discs of the game, real gear and materials (ingots, gems, dusts).
 * Ids are short and fit a network string: "cupcake", "disc_cat", "iron_pickaxe".
 */
public final class Catalog {
    public static final int FOOD = 0, DISC = 1, TOOL = 2, WEAPON = 3, ARMOR = 4, MATERIAL = 5, PLAYER = 6, PART = 7;

    /**
     * How many "items" an entry counts for in the daily limit (so a day brings only a few pieces of gear, or of the
     * really precious materials: diamonds and netherite). Common materials count one by one, like food.
     */
    public static int weight(Entry e) {
        if (e.kind() == MATERIAL) return e.price() >= 150 ? 8 : 1;
        if (e.kind() == PART) return 8;                        // a computer part is a big purchase: six of them fill a day's limit
        if (e.kind() == PLAYER) return 4;                      // a player is a small gadget: 12 of them fill a day's limit
        return e.kind() >= TOOL ? 8 : 1;
    }

    /** One thing for sale. maxQty = the most you can order in one line. */
    public record Entry(String id, int kind, int price, int secs, int maxQty) {}

    /** Id of the lavender portable player in the shop; the coloured ones are "music_player_<color>". */
    public static final String PLAYER_BASE = "music_player";
    /** Id of the headphones (they are sold next to the players). */
    public static final String HEADPHONES = "headphones";
    /** The cases of the portable player are "player_case_<name>". */
    public static final String CASE_BASE = "player_case";

    private static final Map<String, Entry> ENTRIES = new LinkedHashMap<>();
    /** Cheap foods of the game itself (bread, apples...): sold as food, but they are the game's own items. */
    private static final java.util.Set<String> VANILLA_FOOD = new java.util.HashSet<>();

    /** True for a food that is the game's own item (not one of the mod's foods). */
    public static boolean vanillaFood(String id) { return VANILLA_FOOD.contains(id); }

    private static void add(String id, int kind, int price, int secs, int maxQty) {
        ENTRIES.put(id, new Entry(id, kind, price, secs, maxQty));
    }

    static {
        for (String id : ModItems.ids()) add(id, FOOD, ModItems.price(id), ModItems.deliverySecs(id), 16);
        // cheap everyday food of the game itself (1-5 coins, comes in half a minute)
        String[] cheapFood = {"bread", "apple", "carrot", "baked_potato", "cookie", "sweet_berries", "melon_slice", "pumpkin_pie"};
        int[] cheapFoodPrice = {3, 2, 2, 3, 2, 2, 1, 5};
        for (int i = 0; i < cheapFood.length; i++) {
            if (ENTRIES.containsKey(cheapFood[i])) continue;
            add(cheapFood[i], FOOD, cheapFoodPrice[i], 30, 16);
            VANILLA_FOOD.add(cheapFood[i]);
        }
        // music discs: the common ones are cheap, the rare ones cost more (name = the game's music_disc_<name>)
        for (String d : new String[]{"13", "cat", "blocks", "chirp", "far", "mall", "mellohi", "stal", "strad", "ward", "11", "wait"})
            add("disc_" + d, DISC, 30, 60, 4);
        for (String d : new String[]{"5", "otherside", "pigstep", "relic", "creator", "creator_music_box", "precipice"})
            add("disc_" + d, DISC, 60, 90, 4);
        // real gear from the game: the ids are the game's own item names (iron_pickaxe, diamond_sword...)
        String[] tiers = {"wooden", "stone", "iron", "golden", "diamond", "netherite"};
        int[] base = {12, 20, 45, 35, 600, 1800};   // diamond ~1.5-2 days of coins, netherite ~6 (the real progression must stay worth it)
        int[] secs = {60, 75, 90, 90, 180, 300};
        for (int i = 0; i < tiers.length; i++) {
            add(tiers[i] + "_pickaxe", TOOL, base[i], secs[i], 1);
            add(tiers[i] + "_axe", TOOL, base[i], secs[i], 1);
            add(tiers[i] + "_shovel", TOOL, Math.max(1, base[i] / 2), secs[i], 1);
            add(tiers[i] + "_hoe", TOOL, Math.max(1, base[i] / 2), secs[i], 1);
        }
        add("fishing_rod", TOOL, 20, 60, 1);
        add("shears", TOOL, 18, 60, 1);
        add("flint_and_steel", TOOL, 15, 60, 1);
        for (int i = 0; i < tiers.length; i++) add(tiers[i] + "_sword", WEAPON, Math.max(1, base[i] * 9 / 10), secs[i], 1);
        add("bow", WEAPON, 40, 75, 1);
        add("crossbow", WEAPON, 60, 90, 1);
        add("shield", WEAPON, 30, 75, 1);
        String[] armorTiers = {"leather", "chainmail", "iron", "golden", "diamond", "netherite"};
        String[] pieces = {"helmet", "chestplate", "leggings", "boots"};
        int[][] armorPrice = {{10, 16, 14, 8}, {40, 64, 56, 32}, {50, 80, 70, 40}, {40, 64, 56, 32}, {600, 960, 840, 480}, {1800, 2880, 2520, 1440}};
        int[] armorSecs = {60, 90, 90, 90, 180, 300};
        for (int i = 0; i < armorTiers.length; i++) {
            for (int k = 0; k < pieces.length; k++) add(armorTiers[i] + "_" + pieces[k], ARMOR, armorPrice[i][k], armorSecs[i], 1);
        }
        // materials: the game's own items, the useful ones first. A diamond costs a bit more than a third of a diamond
        // pickaxe and an ingot of netherite more than the upgrade of a tool, so buying gear stays the better deal.
        // Diamond and netherite never go on sale (see Deals) and count 8 items in the daily limit, like gear.
        String[] mats = {"diamond", "netherite_ingot", "iron_ingot", "gold_ingot", "emerald", "copper_ingot", "coal", "redstone",
                "lapis_lazuli", "quartz", "amethyst_shard", "obsidian", "ender_pearl", "blaze_rod", "glowstone_dust", "slime_ball",
                "gunpowder", "string", "leather", "feather", "bone_meal"};
        int[] matPrice = {250, 1500, 12, 15, 50, 6, 3, 4, 5, 6, 8, 30, 80, 60, 8, 12, 10, 4, 6, 3, 3};
        int[] matSecs = {180, 300, 75, 75, 120, 75, 60, 60, 60, 60, 90, 120, 120, 120, 90, 90, 90, 60, 60, 60, 60};
        int[] matMax = {4, 2, 16, 16, 8, 16, 16, 16, 16, 16, 8, 8, 4, 4, 8, 8, 16, 16, 16, 16, 16};
        for (int i = 0; i < mats.length; i++) add(mats[i], MATERIAL, matPrice[i], matSecs[i], matMax[i]);
        // cheap supplies: sticks, torches and the like (1-2 coins each)
        String[] supplies = {"stick", "torch", "flint", "paper", "arrow", "sugar"};
        int[] supplyPrice = {1, 2, 2, 1, 2, 1};
        for (int i = 0; i < supplies.length; i++) add(supplies[i], MATERIAL, supplyPrice[i], 45, 16);
        // the portable music players of the mod (the lavender one and one in each colour of the computers)
        add(PLAYER_BASE, PLAYER, 60, 90, 2);
        add(HEADPHONES, PLAYER, 40, 75, 2);
        for (String c : ModItems.COLOR_HEADPHONES.keySet()) add(HEADPHONES + "_" + c, PLAYER, 45, 75, 2);
        for (String c : ModItems.PLAYER_COLORS) add(PLAYER_BASE + "_" + c, PLAYER, 70, 90, 2);
        for (String c : ModItems.CASE_IDS) add(CASE_BASE + "_" + c, PLAYER, 15, 60, 8);   // the cases of the player
        // parts of the computer: memory, video cards and drives (the better, the dearer and the slower the courier)
        for (var kind : dev.cutemod.data.PcHardware.Kind.values()) {
            if (kind == dev.cutemod.data.PcHardware.Kind.MODEM) continue;      // the modem part is gone from the shop: the Wi-Fi routers below replace it
            for (int lv = dev.cutemod.data.PcHardware.first(kind); lv <= dev.cutemod.data.PcHardware.last(kind); lv++)
                add(dev.cutemod.data.PcHardware.partId(kind, lv), PART, dev.cutemod.data.PcHardware.price(kind, lv), dev.cutemod.data.PcHardware.secs(kind, lv), 1);
        }
        // Wi-Fi routers (blocks): level 1 is crafted, 2..5 are sold here
        for (int lv = dev.cutemod.data.WifiNet.FIRST_SHOP; lv <= dev.cutemod.data.WifiNet.LAST; lv++)
            add(dev.cutemod.data.WifiNet.id(lv), PART, dev.cutemod.data.WifiNet.price(lv), dev.cutemod.data.WifiNet.secs(lv), 2);
    }

    private Catalog() {}

    public static Entry get(String id) { return ENTRIES.get(id); }

    public static List<Entry> entries(int kind) {
        List<Entry> out = new ArrayList<>();
        for (Entry e : ENTRIES.values()) if (e.kind() == kind) out.add(e);
        return out;
    }

    /** One real item for this id (stack size 1), or an empty stack if the id is unknown. */
    public static ItemStack create(String id, RegistryAccess access) {
        Entry e = ENTRIES.get(id);
        if (e == null) return ItemStack.EMPTY;
        switch (e.kind()) {
            case FOOD -> {
                Item food = VANILLA_FOOD.contains(id) ? BuiltInRegistries.ITEM.get(ResourceLocation.withDefaultNamespace(id)) : ModItems.food(id);
                return food == null || food == Items.AIR ? ItemStack.EMPTY : new ItemStack(food);
            }
            case DISC -> {
                Item disc = BuiltInRegistries.ITEM.get(ResourceLocation.withDefaultNamespace("music_disc_" + id.substring(5)));
                return disc == Items.AIR ? ItemStack.EMPTY : new ItemStack(disc);
            }
            case PLAYER -> {
                if (id.equals(HEADPHONES)) return new ItemStack(ModItems.HEADPHONES.get());
                if (id.startsWith(CASE_BASE + "_")) {
                    var cs = ModItems.CASES.get(id.substring(CASE_BASE.length() + 1));
                    return cs == null ? ItemStack.EMPTY : new ItemStack(cs.get());
                }
                if (id.startsWith(HEADPHONES + "_")) {
                    var ph = ModItems.COLOR_HEADPHONES.get(id.substring(HEADPHONES.length() + 1));
                    return ph == null ? ItemStack.EMPTY : new ItemStack(ph.get());
                }
                Item pl = id.equals(PLAYER_BASE) ? ModItems.MUSIC_PLAYER.get()
                        : ModItems.COLOR_PLAYERS.get(id.substring(PLAYER_BASE.length() + 1)).get();
                return new ItemStack(pl);
            }
            case PART -> { return ModItems.partStack(id); }
            default -> {                                   // tools, weapons, armor, materials: the game's own item with this name
                Item gear = BuiltInRegistries.ITEM.get(ResourceLocation.withDefaultNamespace(id));
                return gear == Items.AIR ? ItemStack.EMPTY : new ItemStack(gear);
            }
        }
    }
}
