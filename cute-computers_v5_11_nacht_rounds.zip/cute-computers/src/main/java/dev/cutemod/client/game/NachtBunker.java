package dev.cutemod.client.game;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Night of the Dead: a top-down zombie bunker in the spirit of Call of Duty Zombies (the old "Nacht der Untoten" map).
 * Four concrete rooms, boarded windows the zombies tear down plank by plank, doors you open with points, guns on the walls,
 * a Mystery Box, Juggernog, Speed Cola, Pack-a-Punch and power-ups. Round after round, until you go down.
 *
 * Controls: WASD walk, mouse aims, hold the left button to shoot, R reload, E use (hold it at a window to repair), 1 / 2 weapon.
 * The score is the round you reached. Everything is hitscan, drawn with rectangles and discs like the other games.
 */
public class NachtBunker extends MiniGame {
    // ---------------------------------------------------------------- the map (world 328 x 154, the view is a zoomed part of it)
    // zones: 0 = start room (bottom left), 1 = bottom middle, 2 = bottom right, 3 = top left, 4 = top middle, 5 = top right
    private static final int WW = 328, WH = 154, ZN = 6;

    private static void hLine(List<int[]> l, int y, int x0, int x1, int[][] gaps) {
        int cur = x0;
        for (int[] g : gaps) { if (g[0] > cur) l.add(new int[]{cur, y, g[0] - cur, 3}); cur = g[1]; }
        if (x1 > cur) l.add(new int[]{cur, y, x1 - cur, 3});
    }

    private static void vLine(List<int[]> l, int x, int y0, int y1, int[][] gaps) {
        int cur = y0;
        for (int[] g : gaps) { if (g[0] > cur) l.add(new int[]{x, cur, 3, g[0] - cur}); cur = g[1]; }
        if (y1 > cur) l.add(new int[]{x, cur, 3, y1 - cur});
    }

    /** The outer walls and the dividers of the 3 x 2 rooms; the gaps are filled by the window gates and the doors. */
    private static final int[][] WALLS = buildWalls();

    private static int[][] buildWalls() {
        List<int[]> l = new ArrayList<>();
        hLine(l, 8, 8, 320, new int[][]{{50, 66}, {150, 166}, {250, 266}});
        hLine(l, 142, 8, 320, new int[][]{{40, 56}, {150, 166}, {250, 266}});
        hLine(l, 75, 8, 320, new int[][]{{40, 56}, {150, 166}, {250, 266}});
        for (int x : new int[]{8, 111, 214, 317}) vLine(l, x, 8, 145, new int[][]{{30, 46}, {100, 116}});
        return l.toArray(new int[0][]);
    }

    /** Crates and pillars inside the rooms: they stop walking and bullets, so rooms have cover, corners and loops to run around. */
    private static final int[][] OBST = {
            {62, 98, 10, 10}, {26, 118, 12, 7},
            {150, 98, 6, 16}, {128, 124, 14, 7}, {184, 95, 14, 7},
            {250, 98, 14, 8}, {232, 122, 12, 7}, {280, 96, 8, 8},
            {50, 40, 16, 6}, {70, 52, 10, 8}, {26, 56, 12, 6},
            {150, 36, 16, 8}, {126, 30, 8, 8}, {166, 56, 10, 8},
            {250, 36, 14, 10}, {282, 56, 12, 7}, {228, 56, 8, 8}};

    /** The windows: gate x, y, w, h | outside point x, y | inside point x, y | zone. */
    private static final int[][] WIN = {
            {8, 100, 3, 16, 4, 108, 17, 108, 0}, {40, 142, 16, 3, 48, 150, 48, 136, 0},
            {150, 142, 16, 3, 158, 150, 158, 136, 1},
            {250, 142, 16, 3, 258, 150, 258, 136, 2}, {317, 100, 3, 16, 324, 108, 310, 108, 2},
            {8, 30, 3, 16, 4, 38, 17, 38, 3}, {50, 8, 16, 3, 58, 4, 58, 17, 3},
            {150, 8, 16, 3, 158, 4, 158, 17, 4},
            {250, 8, 16, 3, 258, 4, 258, 17, 5}, {317, 30, 3, 16, 324, 38, 310, 38, 5}};

    /** The doors: x, y, w, h | zone a, zone b | cost | centre x, y. They make loops: you can run round through the rooms. */
    private static final int[][] DOORS = {
            {111, 100, 3, 16, 0, 1, 750, 112, 108}, {214, 100, 3, 16, 1, 2, 1000, 215, 108},
            {40, 75, 16, 3, 0, 3, 500, 48, 76}, {150, 75, 16, 3, 1, 4, 1250, 158, 76}, {250, 75, 16, 3, 2, 5, 1500, 258, 76},
            {111, 30, 3, 16, 3, 4, 1000, 112, 38}, {214, 30, 3, 16, 4, 5, 1750, 215, 38}};

    private static final int[][] ZONE_RECT = {{11, 78, 100, 64}, {114, 78, 100, 64}, {217, 78, 100, 64},
            {11, 11, 100, 64}, {114, 11, 100, 64}, {217, 11, 100, 64}};

    private static final int OBJ_WALL = 0, OBJ_BOX = 1, OBJ_JUGG = 2, OBJ_SPEED = 3, OBJ_PAP = 4;
    /** Things to use: kind | x, y | weapon (for a wall gun) | cost | zone. */
    private static final int[][] OBJ = {
            {OBJ_WALL, 30, 83, 1, 200, 0}, {OBJ_WALL, 130, 83, 3, 1200, 1},
            {OBJ_WALL, 25, 16, 2, 1000, 3}, {OBJ_WALL, 290, 16, 4, 1800, 5},
            {OBJ_BOX, 95, 69, 0, 950, 3}, {OBJ_JUGG, 190, 85, 0, 2500, 1}, {OBJ_SPEED, 300, 85, 0, 3000, 2}, {OBJ_PAP, 300, 68, 0, 5000, 5}};

    /** The places the Mystery Box can stand: x, y | zone. It starts at one of the first rooms and moves when the teddy bear shows up. */
    private static final int[][] BOX_SPOTS = {
            {62, 84, 0}, {90, 135, 0}, {175, 84, 1}, {200, 135, 1}, {275, 84, 2}, {290, 135, 2},
            {95, 69, 3}, {80, 16, 3}, {190, 67, 4}, {130, 16, 4}, {235, 16, 5}, {272, 69, 5}};

    // ---------------------------------------------------------------- weapons
    private record Wp(String name, int dmg, int mag, int res, int delay, int pellets, double spread, boolean auto, int reload,
                      int pierce, int range, int color, int wall, int ammo) {}

    private static final Wp[] WP = {
            new Wp("M1911", 34, 8, 80, 8, 1, 0.03, false, 96, 1, 190, 0xFFFFE9A0, 0, 0),
            new Wp("Kar98k", 160, 5, 50, 30, 1, 0.01, false, 130, 1, 240, 0xFFFFE9A0, 200, 100),
            new Wp("MP40", 30, 32, 192, 5, 1, 0.07, true, 130, 1, 200, 0xFFFFE9A0, 1000, 500),
            new Wp("Double Barrel", 58, 2, 38, 26, 8, 0.2, false, 100, 1, 80, 0xFFFFC080, 1200, 600),
            new Wp("BAR", 62, 20, 160, 7, 1, 0.04, true, 150, 1, 230, 0xFFFFE9A0, 1800, 900),
            new Wp("M1 Garand", 90, 8, 96, 11, 1, 0.02, false, 120, 1, 240, 0xFFFFE9A0, 0, 0),
            new Wp("Ray Gun", 520, 20, 160, 10, 1, 0.02, false, 110, 3, 230, 0xFF7CFFB0, 0, 0),
            // pistols: the bright yellow tracer
            // SMGs (fast, weak, wide): PPSh-41 with its drum, Thompson
            new Wp("PPSh-41", 24, 71, 284, 3, 1, 0.11, true, 190, 1, 170, 0xFFFFE9A0, 0, 0),
            new Wp("Thompson", 34, 30, 180, 5, 1, 0.06, true, 120, 1, 190, 0xFFFFE9A0, 0, 0),
            // shotguns: Trench Gun (pump), Auto-12 (automatic, box only)
            new Wp("Trench Gun", 50, 6, 36, 22, 7, 0.17, false, 140, 1, 85, 0xFFFFC080, 0, 0),
            new Wp("Auto-12", 34, 8, 48, 12, 6, 0.2, true, 150, 1, 75, 0xFFFFC080, 0, 0),
            // a revolver (box only), a light machine gun (box only, goes through two), an assault rifle
            new Wp("Python", 120, 6, 42, 18, 1, 0.015, false, 110, 1, 210, 0xFFFFE9A0, 0, 0),
            new Wp("DP-28", 55, 47, 235, 6, 1, 0.07, true, 240, 2, 220, 0xFFFFB0B0, 0, 0),
            new Wp("STG-44", 48, 30, 150, 6, 1, 0.04, true, 130, 1, 230, 0xFFBFD8FF, 0, 0),
            // marksman and sniper rifles: slow, precise, they go through several zombies (a red dotted line shows where a sniper aims)
            new Wp("Gewehr 43", 100, 10, 70, 12, 1, 0.015, false, 130, 1, 260, 0xFFBFD8FF, 0, 0),
            new Wp("Springfield", 260, 5, 35, 38, 1, 0.004, false, 140, 2, 320, 0xFFFF8080, 0, 0),
            new Wp("Mosin Sniper", 340, 5, 30, 42, 1, 0.003, false, 150, 3, 340, 0xFFFF8080, 0, 0),
            new Wp("SVT-40", 130, 10, 60, 14, 1, 0.012, false, 125, 2, 290, 0xFFBFD8FF, 0, 0),
            new Wp("Barrett .50", 700, 5, 25, 55, 1, 0.002, false, 220, 6, 400, 0xFFFF6060, 0, 0),
            // the weak ones (a bad pull of the box): a nail gun, a squirt gun, a crossbow, a sawed-off
            new Wp("Nail Gun", 10, 40, 200, 5, 1, 0.09, true, 100, 1, 120, 0xFFC0C0C0, 0, 0),
            new Wp("Squirt Gun", 5, 60, 300, 3, 1, 0.06, true, 90, 1, 70, 0xFF7CD0FF, 0, 0),
            new Wp("Crossbow", 120, 1, 24, 20, 1, 0.01, false, 70, 2, 200, 0xFFC0A070, 0, 0),
            new Wp("Sawed-Off", 40, 2, 24, 20, 6, 0.3, false, 90, 1, 55, 0xFFFFC080, 0, 0),
            // the middle: lever rifle, Uzi, SPAS-12, Desert Eagle, AK-47
            new Wp("Winchester", 85, 8, 56, 16, 1, 0.02, false, 110, 1, 230, 0xFFFFE9A0, 0, 0),
            new Wp("Uzi", 22, 40, 240, 3, 1, 0.1, true, 100, 1, 170, 0xFFFFE9A0, 0, 0),
            new Wp("SPAS-12", 46, 8, 48, 20, 8, 0.16, false, 140, 1, 90, 0xFFFFC080, 0, 0),
            new Wp("Desert Eagle", 150, 7, 49, 14, 1, 0.02, false, 100, 1, 200, 0xFFFFE9A0, 0, 0),
            new Wp("AK-47", 52, 30, 180, 6, 1, 0.06, true, 120, 1, 220, 0xFFFFE9A0, 0, 0),
            // the overpowered ones: Minigun, Railgun (goes through everything), Plasma Rifle
            new Wp("Minigun", 45, 200, 600, 3, 1, 0.1, true, 300, 2, 200, 0xFFFFE070, 0, 0),
            new Wp("Railgun", 900, 3, 21, 50, 1, 0.002, false, 180, 10, 450, 0xFF40E0FF, 0, 0),
            new Wp("Plasma Rifle", 120, 40, 240, 4, 1, 0.03, true, 130, 3, 260, 0xFFC080FF, 0, 0),
            // explosive (the blast hurts every zombie around the hit): Bazooka, Grenade Launcher; and the Flamethrower
            new Wp("Bazooka", 500, 1, 14, 10, 1, 0.01, false, 130, 1, 260, 0xFFFFA040, 0, 0),
            new Wp("Grenade Launcher", 250, 6, 30, 24, 1, 0.02, false, 150, 1, 180, 0xFFB0FF70, 0, 0),
            new Wp("Flamethrower", 12, 120, 360, 2, 3, 0.18, true, 220, 3, 55, 0xFFFF8030, 0, 0)};

    /** The blast radius of the explosive guns (the Bazooka and the Grenade Launcher), 0 for the others. */
    private static int blast(int weapon) { return weapon == 31 ? 30 : weapon == 32 ? 22 : 0; }

    /** The guns with a red dotted line of sight. */
    private static boolean scoped(int weapon) { return weapon == 15 || weapon == 16 || weapon == 18 || weapon == 29; }

    /** What the Mystery Box can give: a bad pull (20 %), a normal gun (65 %) or a very strong one (15 %). The starting pistol never. */
    private static final int[] BOX_JUNK = {19, 20, 21, 22};
    private static final int[] BOX_MID = {1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 23, 24, 25, 26, 27, 32, 33};
    private static final int[] BOX_BIG = {6, 18, 28, 29, 30, 31};

    private void placeBox(int spot) {
        boxSpot = spot;
        obj[boxIdx][1] = BOX_SPOTS[spot][0];
        obj[boxIdx][2] = BOX_SPOTS[spot][1];
        obj[boxIdx][5] = BOX_SPOTS[spot][2];
    }

    /** The box goes to another place, if it can to one of the rooms that are open (otherwise to any other). */
    private void moveBox() {
        List<Integer> open = new ArrayList<>(), any = new ArrayList<>();
        for (int i = 0; i < BOX_SPOTS.length; i++) {
            if (i == boxSpot) continue;
            any.add(i);
            if (zoneOpen[BOX_SPOTS[i][2]]) open.add(i);
        }
        List<Integer> pool = open.isEmpty() ? any : open;
        placeBox(pool.get(rnd.nextInt(pool.size())));
        boxState = 0; boxUses = 0;
        say("cutemod.nacht.box.moved");
        sound(SoundEvents.ENDERMAN_TELEPORT, 0.8F, 0.5F);
    }

    private int rollBox() {
        int r = rnd.nextInt(100);
        int[] pool = r < 20 ? BOX_JUNK : r < 85 ? BOX_MID : BOX_BIG;
        return pool[rnd.nextInt(pool.length)];
    }

    private static final int PU_MAX = 0, PU_INSTA = 1, PU_DOUBLE = 2, PU_NUKE = 3;

    // ---------------------------------------------------------------- state
    private static final class Z {
        double x, y, hp, sp;
        int st, win, t, cd, anim, flash;     // st: 0 tears the boards, 1 climbs in, 2 hunts the player
        boolean dead, seen;
    }

    private final List<Z> zs = new ArrayList<>();
    private final List<double[]> picks = new ArrayList<>();      // x, y, type, life
    private final List<double[]> tracers = new ArrayList<>();    // x1, y1, x2, y2, life, colour
    private final List<int[]> blood = new ArrayList<>();
    private final List<double[]> booms = new ArrayList<>();      // x, y, radius, life, full life         // x, y, size

    /** The camera: the view is zoomed in and follows the player (the whole bunker is 220 x 140, the view is 110 x 70). */
    private static final float ZOOM = 2F;
    private static final double VW = W / ZOOM, VH = H / ZOOM;
    private double camX, camY, wmx, wmy;

    // the way to the player: a grid over the whole bunker, a flood from the player's cell tells every zombie where to step
    private static final int GS = 2, GX = WW / GS, GY = WH / GS;
    private final boolean[] pass = new boolean[GX * GY];
    private final int[] fdist = new int[GX * GY], fqueue = new int[GX * GY];

    private double px, py, aim, hp, hurtFlash;
    private int maxHp, points, round, toSpawn, spawnT, breakT, introT, t, regen;
    private final int[] slotW = new int[2], mag = new int[2], res = new int[2];
    private final boolean[] pap = new boolean[2];
    private int cur, cool, reloadT, reloadMax, flashT, msgT, repairT, instaT, dblT, boxState, boxT, boxW;
    private boolean jugg, speedCola, prevMouse;
    private final boolean[] prevKey = new boolean[4];
    private final boolean[] zoneOpen = new boolean[ZN];
    private int[][] obj;                      // the things to use; a copy of OBJ, the Mystery Box in it moves
    private int boxIdx, boxSpot, boxUses;
    private final boolean[] doorOpen = new boolean[DOORS.length];
    private final int[] boards = new int[WIN.length];
    private Component msg = Component.empty();
    private String prompt = "";

    @Override
    public void reset() {
        score = 0; over = false; t = 0;
        px = 40; py = 104; aim = 0; maxHp = 100; hp = maxHp; hurtFlash = 0; regen = 0;
        points = 500; round = 0; toSpawn = 0; spawnT = 0; breakT = 120; introT = 0;
        slotW[0] = 0; slotW[1] = -1; pap[0] = false; pap[1] = false; cur = 0; setFull(0);
        cool = 0; reloadT = 0; reloadMax = 1; flashT = 0; msgT = 0; repairT = 0; instaT = 0; dblT = 0;
        boxState = 0; boxT = 0; boxW = 1; jugg = false; speedCola = false; prevMouse = false; prompt = "";
        Arrays.fill(prevKey, false); Arrays.fill(zoneOpen, false); zoneOpen[0] = true;
        Arrays.fill(doorOpen, false); Arrays.fill(boards, 3);
        obj = new int[OBJ.length][];
        for (int i = 0; i < OBJ.length; i++) { obj[i] = OBJ[i].clone(); if (OBJ[i][0] == OBJ_BOX) boxIdx = i; }
        boxUses = 0; boxSpot = -1;
        int first;
        do first = rnd.nextInt(BOX_SPOTS.length); while (BOX_SPOTS[first][2] != 0 && BOX_SPOTS[first][2] != 1 && BOX_SPOTS[first][2] != 3);
        placeBox(first);
        zs.clear(); picks.clear(); tracers.clear(); blood.clear(); booms.clear();
        rebuildGrid();
        flow();
        updateCam(true);
    }

    /** The camera glides after the player and stays inside the bunker; it moves in half pixels so the picture stays sharp. */
    private void updateCam(boolean snap) {
        double tx = Math.max(0, Math.min(WW - VW, px - VW / 2)), ty = Math.max(0, Math.min(WH - VH, py - VH / 2));
        if (snap) { camX = tx; camY = ty; }
        else { camX += (tx - camX) * 0.14; camY += (ty - camY) * 0.14; }
        camX = Math.round(camX * 2) / 2.0;
        camY = Math.round(camY * 2) / 2.0;
    }

    // ---------------------------------------------------------------- input helpers
    private static boolean down(int key) {
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
    }

    private static boolean leftDown() {
        return GLFW.glfwGetMouseButton(Minecraft.getInstance().getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    private boolean pressed(int i, int key) {
        boolean d = down(key);
        boolean r = d && !prevKey[i];
        prevKey[i] = d;
        return r;
    }

    @Override
    public boolean key(int keyCode) {
        return keyCode == 87 || keyCode == 65 || keyCode == 83 || keyCode == 68 || keyCode == 69 || keyCode == 82 || keyCode == 49 || keyCode == 50;
    }

    // ---------------------------------------------------------------- weapon helpers
    private int magMax(int s) { Wp w = WP[slotW[s]]; return pap[s] ? w.mag() * 3 / 2 : w.mag(); }

    private int resMax(int s) { Wp w = WP[slotW[s]]; return pap[s] ? w.res() * 3 / 2 : w.res(); }

    private double dmgOf(int s) { return WP[slotW[s]].dmg() * (pap[s] ? 2.5 : 1.0); }

    private void setFull(int s) { mag[s] = magMax(s); res[s] = resMax(s); }

    private String wname(int s) { return WP[slotW[s]].name() + (pap[s] ? " PaP" : ""); }

    private int slotOf(int weapon) {
        for (int s = 0; s < 2; s++) if (slotW[s] == weapon) return s;
        return -1;
    }

    private void give(int weapon) {
        int slot = slotOf(weapon);
        if (slot < 0) slot = slotW[1] < 0 ? 1 : cur;
        slotW[slot] = weapon; pap[slot] = false; setFull(slot);
        cur = slot; reloadT = 0; cool = 10;
        sound(SoundEvents.LEVER_CLICK, 1.2F, 0.6F);
    }

    private void say(String key, Object... a) { msg = Component.translatable(key, a); msgT = 130; }

    private void addPts(int n) { points += dblT > 0 ? n * 2 : n; }

    // ---------------------------------------------------------------- geometry
    private static int zoneAt(double x, double y) { return (y < 76.5 ? 3 : 0) + (x < 112.5 ? 0 : x < 215.5 ? 1 : 2); }

    private static boolean overlaps(int[] r, double x, double y, double rad) {
        return x + rad > r[0] && x - rad < r[0] + r[2] && y + rad > r[1] && y - rad < r[1] + r[3];
    }

    /** Walls, closed doors and the window gates stop walking. */
    private boolean blocked(double x, double y, double rad) {
        for (int[] w : WALLS) if (overlaps(w, x, y, rad)) return true;
        for (int[] w : OBST) if (overlaps(w, x, y, rad)) return true;
        for (int i = 0; i < DOORS.length; i++) if (!doorOpen[i] && overlaps(DOORS[i], x, y, rad)) return true;
        for (int[] w : WIN) if (overlaps(w, x, y, rad)) return true;
        return false;
    }

    /** Walls and closed doors stop bullets (windows do not). */
    private boolean stopsBullet(double x, double y) {
        for (int[] w : WALLS) if (x >= w[0] && x < w[0] + w[2] && y >= w[1] && y < w[1] + w[3]) return true;
        for (int[] w : OBST) if (x >= w[0] && x < w[0] + w[2] && y >= w[1] && y < w[1] + w[3]) return true;
        for (int i = 0; i < DOORS.length; i++) {
            int[] d = DOORS[i];
            if (!doorOpen[i] && x >= d[0] && x < d[0] + d[2] && y >= d[1] && y < d[1] + d[3]) return true;
        }
        return false;
    }

    /** Which grid cells a zombie can stand in (walls, crates, closed doors and window gates are out). Redone when a door opens. */
    private void rebuildGrid() {
        for (int gy = 0; gy < GY; gy++)
            for (int gx = 0; gx < GX; gx++) pass[gy * GX + gx] = !blocked(gx * GS + GS / 2.0, gy * GS + GS / 2.0, 3.5);
    }

    private static int cellOf(double x, double y) {
        int gx = Math.max(0, Math.min(GX - 1, (int) (x / GS))), gy = Math.max(0, Math.min(GY - 1, (int) (y / GS)));
        return gy * GX + gx;
    }

    private static final int[] NX = {1, -1, 0, 0, 1, 1, -1, -1}, NY = {0, 0, 1, -1, 1, -1, 1, -1};

    /** A flood from the player over the free cells: fdist is the number of steps to the player, -1 when there is no way. */
    private void flow() {
        Arrays.fill(fdist, -1);
        int start = cellOf(px, py);
        if (!pass[start]) {
            int sx = start % GX, sy = start / GX;
            start = -1;
            for (int r = 1; r <= 3 && start < 0; r++)
                for (int dy = -r; dy <= r && start < 0; dy++)
                    for (int dx = -r; dx <= r; dx++) {
                        int nx = sx + dx, ny = sy + dy;
                        if (nx >= 0 && ny >= 0 && nx < GX && ny < GY && pass[ny * GX + nx]) { start = ny * GX + nx; break; }
                    }
            if (start < 0) return;
        }
        int head = 0, tail = 0;
        fqueue[tail++] = start;
        fdist[start] = 0;
        while (head < tail) {
            int c = fqueue[head++], cx = c % GX, cy = c / GX;
            for (int k = 0; k < 8; k++) {
                int nx = cx + NX[k], ny = cy + NY[k];
                if (nx < 0 || ny < 0 || nx >= GX || ny >= GY) continue;
                int n = ny * GX + nx;
                if (!pass[n] || fdist[n] >= 0) continue;
                if (k >= 4 && (!pass[cy * GX + nx] || !pass[ny * GX + cx])) continue;   // no cutting round a corner
                fdist[n] = fdist[c] + 1;
                fqueue[tail++] = n;
            }
        }
    }

    // ---------------------------------------------------------------- the tick
    @Override
    public void tick() {
        t++;
        boolean ePressed = pressed(0, 69), rPressed = pressed(1, 82);
        if (pressed(2, 49) && cur != 0 && slotW[0] >= 0) switchTo(0);
        if (pressed(3, 50) && cur != 1 && slotW[1] >= 0) switchTo(1);

        movePlayer();
        updateCam(false);
        wmx = camX + mx / ZOOM; wmy = camY + my / ZOOM;
        aim = Math.atan2(wmy - py, wmx - px);
        weapons(rPressed);
        interact(ePressed);
        waves();
        if (t % 5 == 0) flow();
        if (t % 3 == 0) visEpoch++;
        zombies();
        pickups();

        for (int i = tracers.size() - 1; i >= 0; i--) if (--tracers.get(i)[4] <= 0) tracers.remove(i);
        for (int i = booms.size() - 1; i >= 0; i--) if (--booms.get(i)[3] <= 0) booms.remove(i);
        if (cool > 0) cool--;
        if (flashT > 0) flashT--;
        if (msgT > 0) msgT--;
        if (introT > 0) introT--;
        if (instaT > 0) instaT--;
        if (dblT > 0) dblT--;
        if (hurtFlash > 0) hurtFlash = Math.max(0, hurtFlash - 0.04);
        if (regen > 0) regen--; else if (hp < maxHp) hp = Math.min(maxHp, hp + 0.6);
        if (!zs.isEmpty() && rnd.nextInt(170) == 0) growl(G_ZOMBIE);

        score = round;
        if (hp <= 0) { over = true; beep(); growl(G_SCREAM); }
    }

    private void movePlayer() {
        double dx = 0, dy = 0;
        if (down(87)) dy -= 1;
        if (down(83)) dy += 1;
        if (down(65)) dx -= 1;
        if (down(68)) dx += 1;
        if (dx == 0 && dy == 0) return;
        double l = Math.hypot(dx, dy), s = 0.85;
        dx = dx / l * s; dy = dy / l * s;
        if (!blocked(px + dx, py, 3)) px += dx;
        if (!blocked(px, py + dy, 3)) py += dy;
        px = Math.max(12, Math.min(WW - 12, px));
        py = Math.max(12, Math.min(WH - 14, py));
    }

    private void switchTo(int s) {
        cur = s; reloadT = 0; cool = 8;
        sound(SoundEvents.LEVER_CLICK, 1.4F, 0.5F);
    }

    // ---------------------------------------------------------------- shooting
    private void weapons(boolean rPressed) {
        int s = cur;
        Wp w = WP[slotW[s]];
        boolean left = leftDown() && mx >= 0 && my >= 0 && mx < W && my < H;
        boolean fresh = left && !prevMouse;
        prevMouse = left;
        if (reloadT > 0) {
            if (--reloadT == 0) {
                int need = Math.min(magMax(s) - mag[s], res[s]);
                mag[s] += need; res[s] -= need;
                sound(SoundEvents.LEVER_CLICK, 0.8F, 0.5F);
            }
            return;
        }
        if (rPressed && mag[s] < magMax(s) && res[s] > 0) { startReload(w); return; }
        if (left && cool <= 0 && (w.auto() || fresh)) {
            if (mag[s] > 0) {
                mag[s]--;
                cool = w.delay();
                shoot(w, s);
                if (mag[s] == 0 && res[s] > 0) startReload(w);
            } else if (res[s] > 0) {
                startReload(w);
            } else if (fresh) {
                beep();
                say("cutemod.nacht.empty");
            }
        }
    }

    private void startReload(Wp w) {
        reloadMax = Math.max(10, (int) (w.reload() * (speedCola ? 0.5 : 1.0)));
        reloadT = reloadMax;
        sound(SoundEvents.LEVER_CLICK, 1.2F, 0.5F);
    }

    private void shoot(Wp w, int s) {
        double dmg = dmgOf(s);
        int col = pap[s] ? 0xFFFFD84A : w.color();
        if (blast(slotW[s]) > 0) traceBlast(aim + (rnd.nextDouble() - 0.5) * 2 * w.spread(), dmg, w.range(), blast(slotW[s]), col);
        else for (int i = 0; i < w.pellets(); i++) trace(aim + (rnd.nextDouble() - 0.5) * 2 * w.spread(), dmg, w.range(), w.pierce(), col, w.pellets());
        flashT = 3;
        if (w.delay() <= 3 && (t & 1) == 1) return;      // the very fast guns make a sound every second shot
        switch (slotW[s]) {
            case 0 -> sound(SoundEvents.CROSSBOW_SHOOT, 1.5F, 0.6F);
            case 1, 5, 14, 17 -> sound(SoundEvents.FIREWORK_ROCKET_BLAST, 0.9F, 0.7F);
            case 15, 16 -> sound(SoundEvents.FIREWORK_ROCKET_BLAST, 0.6F, 0.85F);
            case 18 -> sound(SoundEvents.GENERIC_EXPLODE, 1.3F, 0.5F);
            case 2, 7, 8 -> sound(SoundEvents.CROSSBOW_SHOOT, slotW[s] == 7 ? 2.1F : 1.9F, 0.5F);
            case 3, 9, 10 -> sound(SoundEvents.GENERIC_EXPLODE, slotW[s] == 10 ? 1.9F : 1.7F, 0.35F);
            case 4, 12, 13 -> sound(SoundEvents.FIREWORK_ROCKET_BLAST, slotW[s] == 12 ? 1.0F : 1.3F, 0.6F);
            case 11, 23, 26 -> sound(SoundEvents.FIREWORK_ROCKET_BLAST, 0.75F, 0.8F);
            case 19, 24 -> sound(SoundEvents.CROSSBOW_SHOOT, 2.0F, 0.4F);
            case 20 -> sound(SoundEvents.BUBBLE_COLUMN_BUBBLE_POP, 1.6F, 0.5F);
            case 21 -> sound(SoundEvents.CROSSBOW_SHOOT, 1.0F, 0.7F);
            case 22, 25 -> sound(SoundEvents.GENERIC_EXPLODE, slotW[s] == 22 ? 1.9F : 1.6F, 0.35F);
            case 27 -> sound(SoundEvents.FIREWORK_ROCKET_BLAST, 1.2F, 0.6F);
            case 28 -> sound(SoundEvents.CROSSBOW_SHOOT, 2.2F, 0.35F);
            case 29 -> sound(SoundEvents.LIGHTNING_BOLT_THUNDER, 2.0F, 0.4F);
            case 31, 32 -> sound(SoundEvents.GENERIC_EXPLODE, slotW[s] == 31 ? 0.8F : 1.0F, 0.4F);
            case 33 -> sound(SoundEvents.FIRECHARGE_USE, 1.2F, 0.5F);
            default -> sound(SoundEvents.BLAZE_SHOOT, 1.6F, 0.6F);
        }
    }

    private void trace(double a, double dmg, int range, int pierce, int colour, int pellets) {
        double dx = Math.cos(a), dy = Math.sin(a);
        double x = px + dx * 5, y = py + dy * 5;
        List<Z> hit = new ArrayList<>();
        for (int step = 5; step < range; step += 2) {
            x = px + dx * step; y = py + dy * step;
            if (x < 0 || y < 0 || x > WW || y > WH || stopsBullet(x, y)) break;
            boolean stop = false;
            for (Z z : zs) {
                if (z.dead || hit.contains(z)) continue;
                double ex = z.x - x, ey = z.y - y;
                if (ex * ex + ey * ey < 20) {
                    hitZombie(z, dmg, pellets);
                    hit.add(z);
                    if (hit.size() >= pierce) { stop = true; break; }
                }
            }
            if (stop) break;
        }
        tracers.add(new double[]{px + dx * 6, py + dy * 6, x, y, 4, colour});
    }

    /** A shell: flies to the first zombie or wall and blows up there, hurting everything round it (less the farther it is). */
    private void traceBlast(double a, double dmg, int range, int radius, int colour) {
        double dx = Math.cos(a), dy = Math.sin(a), x = px + dx * 5, y = py + dy * 5;
        for (int step = 5; step < range; step += 2) {
            x = px + dx * step; y = py + dy * step;
            if (x < 0 || y < 0 || x > WW || y > WH || stopsBullet(x, y)) { x -= dx * 3; y -= dy * 3; break; }
            boolean hit = false;
            for (Z z : zs) {
                if (z.dead) continue;
                double ex = z.x - x, ey = z.y - y;
                if (ex * ex + ey * ey < 20) { hit = true; break; }
            }
            if (hit) break;
        }
        tracers.add(new double[]{px + dx * 6, py + dy * 6, x, y, 4, colour});
        booms.add(new double[]{x, y, radius, 18, 18});
        sound(SoundEvents.GENERIC_EXPLODE, 0.9F, 0.6F);
        for (Z z : zs) {
            if (z.dead) continue;
            double d = Math.hypot(z.x - x, z.y - y);
            if (d < radius) hitZombie(z, dmg * (1 - 0.5 * d / radius), 1);
        }
    }

    private void hitZombie(Z z, double dmg, int pellets) {
        if (z.dead) return;
        z.hp -= instaT > 0 ? 100000 : dmg;
        z.flash = 3;
        addPts(pellets > 1 ? 4 : (int) Math.max(2, Math.min(10, dmg / 4)));
        blood.add(new int[]{(int) z.x + rnd.nextInt(5) - 2, (int) z.y + rnd.nextInt(5) - 2, 1 + rnd.nextInt(2)});
        if (blood.size() > 150) blood.remove(0);
        if (rnd.nextInt(3) == 0) sound(SoundEvents.ZOMBIE_HURT, 0.55F + rnd.nextFloat() * 0.2F, 0.4F);
        if (z.hp <= 0) {
            z.dead = true;
            addPts(60);
            sound(SoundEvents.ZOMBIE_DEATH, 0.6F + rnd.nextFloat() * 0.2F, 0.5F);
            if (rnd.nextInt(25) == 0 && picks.size() < 3) picks.add(new double[]{z.x, z.y, rnd.nextInt(4), 1800});
        }
    }

    // ---------------------------------------------------------------- using things
    private void interact(boolean ePressed) {
        prompt = "";
        double best = 14 * 14;
        int kind = -1, idx = -1;
        for (int i = 0; i < obj.length; i++) {
            if (!zoneOpen[obj[i][5]]) continue;
            double d = dist2(obj[i][1], obj[i][2]);
            if (d < best) { best = d; kind = 0; idx = i; }
        }
        for (int i = 0; i < DOORS.length; i++) {
            if (doorOpen[i]) continue;
            double d = dist2(DOORS[i][7], DOORS[i][8]);
            if (d < best) { best = d; kind = 1; idx = i; }
        }
        for (int i = 0; i < WIN.length; i++) {
            if (boards[i] >= 3 || !zoneOpen[WIN[i][8]]) continue;
            double d = dist2(WIN[i][6], WIN[i][7]);
            if (d < best) { best = d; kind = 2; idx = i; }
        }
        if (kind != 2) repairT = 0;
        if (kind == 1) {
            int cost = DOORS[idx][6];
            prompt = Component.translatable("cutemod.nacht.use.door", cost).getString();
            if (ePressed) {
                if (points < cost) { poor(); return; }
                points -= cost;
                doorOpen[idx] = true; zoneOpen[DOORS[idx][4]] = true; zoneOpen[DOORS[idx][5]] = true;
                rebuildGrid(); flow();
                sound(SoundEvents.IRON_DOOR_OPEN, 0.7F, 0.6F);
            }
        } else if (kind == 2) {
            if (windowBusy(idx)) return;
            prompt = Component.translatable("cutemod.nacht.use.repair").getString();
            if (down(69) && ++repairT >= 22) {
                repairT = 0;
                boards[idx]++;
                addPts(10);
                sound(SoundEvents.WOOD_PLACE, 1.0F, 0.6F);
            }
        } else if (kind == 0) {
            useObject(obj[idx], ePressed);
        }
    }

    private double dist2(double x, double y) { double dx = x - px, dy = y - py; return dx * dx + dy * dy; }

    private boolean windowBusy(int i) {
        for (Z z : zs) if (!z.dead && z.win == i && z.st <= 1) return true;
        return false;
    }

    private void poor() { beep(); say("cutemod.nacht.poor"); }

    private void useObject(int[] o, boolean ePressed) {
        int cost = o[4];
        switch (o[0]) {
            case OBJ_WALL -> {
                Wp w = WP[o[3]];
                int owned = slotOf(o[3]);
                if (owned >= 0) {
                    cost = w.ammo();
                    prompt = Component.translatable("cutemod.nacht.use.ammo", wname(owned), cost).getString();
                } else {
                    prompt = Component.translatable("cutemod.nacht.use.buy", w.name(), cost).getString();
                }
                if (ePressed) {
                    if (points < cost) { poor(); return; }
                    points -= cost;
                    if (owned >= 0) { setFull(owned); sound(SoundEvents.LEVER_CLICK, 1.0F, 0.6F); }
                    else give(o[3]);
                }
            }
            case OBJ_BOX -> {
                if (boxState == 0) {
                    prompt = Component.translatable("cutemod.nacht.use.box", cost).getString();
                    if (ePressed) {
                        if (points < cost) { poor(); return; }
                        points -= cost; boxState = 1; boxT = 110; boxUses++;
                        sound(SoundEvents.NOTE_BLOCK_CHIME.value(), 0.7F, 0.7F);
                    }
                } else if (boxState == 2) {
                    prompt = Component.translatable("cutemod.nacht.use.take", WP[boxW].name()).getString();
                    if (ePressed) { give(boxW); boxState = 0; }
                }
            }
            case OBJ_JUGG, OBJ_SPEED -> {
                boolean has = o[0] == OBJ_JUGG ? jugg : speedCola;
                if (has) return;
                String name = o[0] == OBJ_JUGG ? "Juggernog" : "Speed Cola";
                prompt = Component.translatable("cutemod.nacht.use.perk", name, cost).getString();
                if (ePressed) {
                    if (points < cost) { poor(); return; }
                    points -= cost;
                    if (o[0] == OBJ_JUGG) { jugg = true; maxHp = 200; hp = maxHp; } else speedCola = true;
                    sound(SoundEvents.GENERIC_DRINK, 1.0F, 0.7F);
                }
            }
            default -> {
                if (pap[cur]) return;
                prompt = Component.translatable("cutemod.nacht.use.perk", "Pack-a-Punch", cost).getString();
                if (ePressed) {
                    if (points < cost) { poor(); return; }
                    points -= cost;
                    pap[cur] = true; setFull(cur); reloadT = 0;
                    sound(SoundEvents.ANVIL_USE, 1.4F, 0.5F);
                    say("cutemod.nacht.upgraded", wname(cur));
                }
            }
        }
    }

    // ---------------------------------------------------------------- rounds and zombies
    private void waves() {
        if (boxState == 1 && --boxT <= 0) {
            if (boxUses >= 2 && rnd.nextDouble() < Math.min(0.55, 0.12 * boxUses)) {
                // the teddy bear: the points come back and the box moves away
                boxState = 3; boxT = 170;
                points += obj[boxIdx][4];
                say("cutemod.nacht.box.teddy");
                sound(SoundEvents.NOTE_BLOCK_BELL, 0.5F, 0.8F);
            } else {
                boxState = 2; boxT = 420;
                for (int tries = 0; tries < 30; tries++) {
                    boxW = rollBox();
                    if (slotOf(boxW) < 0) break;
                }
                pling(1.5F);
            }
        } else if (boxState == 2 && --boxT <= 0) boxState = 0;
        else if (boxState == 3 && --boxT <= 0) moveBox();

        if (breakT > 0) {
            if (--breakT == 0) startRound();
            return;
        }
        if (toSpawn > 0) {
            if (--spawnT <= 0 && zs.size() < aliveCap(round)) {
                spawnZombie();
                toSpawn--;
                spawnT = Math.max(12, 100 - round * 7);
            }
        } else if (zs.isEmpty()) {
            breakT = 330;
            sound(SoundEvents.BELL_BLOCK, 0.6F, 0.8F);
        }
    }

    /** How many zombies a round brings, like in Call of Duty: a handful at first, then more and more. */
    private static int roundTotal(int r) {
        final int[] first = {0, 5, 7, 10, 14, 18, 22, 26, 30, 34, 38};
        return r <= 10 ? first[r] : Math.min(120, 38 + (r - 10) * 5);
    }

    /** How many can be alive and walking at once (the rest wait to spawn): this keeps the game light in the late rounds. */
    private static int aliveCap(int r) { return Math.min(24, 4 + r * 2); }

    private void startRound() {
        round++;
        toSpawn = roundTotal(round);
        spawnT = 30; introT = 170;
        blood.clear();
        sound(SoundEvents.ENDERMAN_STARE, 0.5F, 0.7F);
    }

    private double zombieHp(int r) {
        return r <= 9 ? 90 + (r - 1) * 45 : Math.floor(450 * Math.pow(1.1, r - 9));
    }

    private void spawnZombie() {
        int pz = zoneAt(px, py);
        List<Integer> mine = new ArrayList<>(), all = new ArrayList<>();
        for (int i = 0; i < WIN.length; i++) {
            if (!zoneOpen[WIN[i][8]]) continue;
            all.add(i);
            if (WIN[i][8] == pz) mine.add(i);
        }
        List<Integer> pool = !mine.isEmpty() && rnd.nextInt(10) < 6 ? mine : all;
        int wi = pool.get(rnd.nextInt(pool.size()));
        int[] w = WIN[wi];
        double off = (rnd.nextDouble() - 0.5) * 10;
        Z z = new Z();
        z.win = wi;
        z.x = w[4] + (w[2] == 3 ? 0 : off);
        z.y = w[5] + (w[2] == 3 ? off : 0);
        z.hp = zombieHp(round);
        double sp = (round <= 2 ? 0.17 : 0.2) + rnd.nextDouble() * 0.08;
        if (round >= 5 && rnd.nextDouble() < Math.min(0.8, (round - 4) * 0.13)) sp = 0.4 + rnd.nextDouble() * 0.08;
        if (round >= 9 && rnd.nextDouble() < Math.min(0.6, (round - 8) * 0.1)) sp = 0.58 + rnd.nextDouble() * 0.1;
        z.sp = Math.min(0.8, sp);
        zs.add(z);
    }

    private void zombies() {
        for (int i = zs.size() - 1; i >= 0; i--) {
            Z z = zs.get(i);
            if (z.dead) { zs.remove(i); continue; }
            z.anim++;
            if (((t + i) % 3) == 0) z.seen = dist2(z.x, z.y) < 150 || los(px, py, z.x, z.y);
            if (z.flash > 0) z.flash--;
            if (z.cd > 0) z.cd--;
            int[] w = WIN[z.win];
            if (z.st == 0) {
                if (boards[z.win] <= 0) z.st = 1;
                else if (++z.t >= 70) {
                    z.t = 0; boards[z.win]--;
                    sound(SoundEvents.WOOD_BREAK, 0.7F + rnd.nextFloat() * 0.2F, 0.5F);
                }
            } else if (z.st == 1) {
                step(z, w[6], w[7], z.sp, false);
                if (Math.abs(z.x - w[6]) < 2 && Math.abs(z.y - w[7]) < 2) z.st = 2;
            } else {
                chase(z);
            }
        }
        // zombies in the rooms do not stand inside each other
        for (int a = 0; a < zs.size(); a++) {
            Z za = zs.get(a);
            if (za.st != 2) continue;
            for (int b = a + 1; b < zs.size(); b++) {
                Z zb = zs.get(b);
                if (zb.st != 2) continue;
                double dx = zb.x - za.x, dy = zb.y - za.y, d2 = dx * dx + dy * dy;
                if (d2 < 25 && d2 > 0.01) {
                    double d = Math.sqrt(d2), push = (5 - d) * 0.25;
                    dx = dx / d * push; dy = dy / d * push;
                    if (!blocked(zb.x + dx, zb.y + dy, 3.5)) { zb.x += dx; zb.y += dy; }
                    if (!blocked(za.x - dx, za.y - dy, 3.5)) { za.x -= dx; za.y -= dy; }
                }
            }
        }
    }

    private void chase(Z z) {
        double dp = Math.hypot(px - z.x, py - z.y);
        if (dp > 5.5) {
            if (dp < 16 && los(z.x, z.y, px, py)) {
                step(z, px, py, z.sp, true);
            } else {
                // go to the neighbour cell that is closer to the player; round crates, through doors, along the loops
                int c = cellOf(z.x, z.y), cx = c % GX, cy = c / GX, d0 = fdist[c], best = -1, bd = d0 < 0 ? Integer.MAX_VALUE : d0;
                for (int k = 0; k < 8; k++) {
                    int nx = cx + NX[k], ny = cy + NY[k];
                    if (nx < 0 || ny < 0 || nx >= GX || ny >= GY) continue;
                    int n = ny * GX + nx;
                    if (fdist[n] < 0 || fdist[n] >= bd) continue;
                    if (k >= 4 && (!pass[cy * GX + nx] || !pass[ny * GX + cx])) continue;
                    bd = fdist[n]; best = n;
                }
                if (best >= 0) step(z, (best % GX) * GS + GS / 2.0, (best / GX) * GS + GS / 2.0, z.sp, true);
                else step(z, px, py, z.sp, true);
            }
        }
        if (dp < 8 && z.cd <= 0) {
            z.cd = 55;
            hp -= 25;
            hurtFlash = 1; regen = 240;
            sound(SoundEvents.PLAYER_HURT, 0.8F, 0.6F);
        }
    }

    private void step(Z z, double tx, double ty, double sp, boolean collide) {
        double dx = tx - z.x, dy = ty - z.y, d = Math.hypot(dx, dy);
        if (d < 0.01) return;
        dx = dx / d * sp; dy = dy / d * sp;
        if (!collide) { z.x += dx; z.y += dy; return; }
        if (!blocked(z.x + dx, z.y, 3.5)) z.x += dx;
        if (!blocked(z.x, z.y + dy, 3.5)) z.y += dy;
    }

    private void pickups() {
        for (int i = picks.size() - 1; i >= 0; i--) {
            double[] p = picks.get(i);
            if (--p[3] <= 0) { picks.remove(i); continue; }
            if (dist2(p[0], p[1]) > 49) continue;
            picks.remove(i);
            pling(1.8F);
            switch ((int) p[2]) {
                case PU_MAX -> {
                    for (int s = 0; s < 2; s++) if (slotW[s] >= 0) setFull(s);
                    say("cutemod.nacht.pu.max");
                }
                case PU_INSTA -> { instaT = 1800; say("cutemod.nacht.pu.insta"); }
                case PU_DOUBLE -> { dblT = 1800; say("cutemod.nacht.pu.double"); }
                default -> {
                    for (Z z : zs) z.dead = true;
                    addPts(400);
                    sound(SoundEvents.GENERIC_EXPLODE, 0.8F, 0.6F);
                    say("cutemod.nacht.pu.nuke");
                }
            }
        }
    }

    @Override
    public Component status() { return Component.translatable("cutemod.nacht.status", round, points); }

    @Override
    public Component endTitle() { return Component.translatable("cutemod.nacht.down", round); }

    @Override
    public String hintKey() { return "cutemod.hint.nacht"; }

    // ---------------------------------------------------------------- drawing
    @Override
    public void render(GuiGraphics g) {
        rect(g, 0, 0, W, H, 0xFF0C0D0E);
        g.pose().pushPose();
        g.pose().scale(ZOOM, ZOOM, 1F);
        g.pose().translate((float) -camX, (float) -camY, 0F);
        int[] floor = {0xFF4B4136, 0xFF3F4439, 0xFF4A4236, 0xFF42393B, 0xFF39414C, 0xFF3C4540};
        for (int z = 0; z < ZN; z++) {
            int[] r = ZONE_RECT[z];
            rect(g, r[0], r[1], r[2], r[3], floor[z]);
            for (int x = r[0] + 14; x < r[0] + r[2]; x += 14) rect(g, x, r[1], 1, r[3], 0x22000000);
            for (int y = r[1] + 14; y < r[1] + r[3]; y += 14) rect(g, r[0], y, r[2], 1, 0x22000000);
        }
        for (int[] b : blood) rect(g, b[0], b[1], b[2], b[2], 0x99801010);
        for (int i = 0; i < DOORS.length; i++) {
            int[] d = DOORS[i];
            if (doorOpen[i]) rect(g, d[0], d[1], d[2], d[3], 0xFF2E2E2C);
            else { rect(g, d[0], d[1], d[2], d[3], 0xFF7A5A34); rect(g, d[0], d[1], d[2], 1, 0xFFA07C4C); }
        }
        for (int[] o : obj) if (zoneOpen[o[5]]) drawObject(g, o);
        for (int[] o : OBST) {
            rect(g, o[0], o[1], o[2], o[3], 0xFF1E1408);
            rect(g, o[0] + 1, o[1] + 1, o[2] - 2, o[3] - 2, 0xFF7A5230);
            rect(g, o[0] + 1, o[1] + 1, o[2] - 2, 1, 0xFFA07A4C);
        }
        for (int[] w : WALLS) { rect(g, w[0], w[1], w[2], w[3], 0xFF77756F); rect(g, w[0], w[1], w[2], 1, 0xFF9A988F); }
        for (int i = 0; i < WIN.length; i++) drawWindow(g, i);
        for (double[] p : picks) drawPickup(g, p);
        for (Z z : zs) if (canSee(z)) drawZombie(g, z);
        drawPlayer(g);
        if (scoped(slotW[cur])) drawScope(g);
        for (double[] a : tracers) drawTracer(g, a);
        for (double[] b : booms) {
            double f = b[3] / b[4];
            disc(g, (int) b[0], (int) b[1], (int) Math.max(2, b[2] * (1.15 - f * 0.6)), ((int) (f * 170) << 24) | 0xFFA030);
        }
        for (int z = 0; z < ZN; z++) if (!zoneOpen[z]) { int[] r = ZONE_RECT[z]; rect(g, r[0], r[1], r[2], r[3], 0xE6000000); }
        darkness(g);
        for (Z z : zs) if (!z.dead && canSee(z)) drawEyes(g, z);
        g.pose().popPose();
        hud(g);
    }

    /** Fog of war: a zombie shows only while the player has a clear line to it (worked out in the tick, every third tick, not every frame). */
    private boolean canSee(Z z) { return !z.dead && z.seen; }

    /** True when no wall or closed door is in the way (a wall that is itself the target counts as seen). */
    private boolean los(double x0, double y0, double x1, double y1) {
        double dx = x1 - x0, dy = y1 - y0, d = Math.hypot(dx, dy);
        int n = (int) (d / 2);
        for (int i = 1; i < n; i++) {
            double f = i / (double) n;
            if (stopsBullet(x0 + dx * f, y0 + dy * f)) return d * (1 - f) < 3.5;
        }
        return true;
    }

    private void drawObject(GuiGraphics g, int[] o) {
        int x = o[1], y = o[2];
        switch (o[0]) {
            case OBJ_WALL -> {
                rect(g, x - 8, y - 4, 16, 8, 0xFF1E1E1E);
                rect(g, x - 7, y - 3, 14, 6, 0xFF3A3A36);
                rect(g, x - 5, y - 1, 10, 2, WP[o[3]].color() | 0xFF000000);
                rect(g, x - 6, y, 3, 2, 0xFFA88A5A);
            }
            case OBJ_BOX -> {
                rect(g, x - 7, y - 5, 14, 10, 0xFF1E1408);
                rect(g, x - 6, y - 4, 12, 8, boxState == 0 ? 0xFF8A5E2E : 0xFFB07A38);
                rect(g, x - 6, y - 4, 12, 1, 0xFFC89A5A);
                ctext(g, "?", x, y - 4, 0xFFFFE070);
                if (boxState == 3) {
                    // the teddy bear sits on the box
                    int by = y - 11 - (int) (Math.sin(t * 0.2) * 1.5);
                    disc(g, x - 3, by - 3, 1, 0xFF5A3A1E); disc(g, x + 3, by - 3, 1, 0xFF5A3A1E);
                    disc(g, x, by, 4, 0xFF8A5A2E);
                    rect(g, x - 2, by, 4, 2, 0xFFD9B27A);
                    rect(g, x - 2, by - 2, 1, 1, 0xFF101010); rect(g, x + 1, by - 2, 1, 1, 0xFF101010);
                    rect(g, x - 1, by, 2, 1, 0xFF101010);
                } else if (boxState == 1) ctext(g, WP[(t / 5) % WP.length].name(), x, y - 15, 0xFFFFFFFF);
                else if (boxState == 2) ctext(g, WP[boxW].name(), x, y - 15, 0xFF7CFFB0);
            }
            case OBJ_JUGG, OBJ_SPEED, OBJ_PAP -> {
                int c = o[0] == OBJ_JUGG ? 0xFFC0392B : o[0] == OBJ_SPEED ? 0xFF3FA34D : 0xFF3B6FD0;
                rect(g, x - 5, y - 6, 10, 12, 0xFF14141A);
                rect(g, x - 4, y - 5, 8, 10, c);
                rect(g, x - 3, y - 3, 6, 3, 0xFFFFFFFF);
                if (o[0] == OBJ_PAP) rect(g, x - 4, y + 2, 8, 2, 0xFFFFD84A);
            }
            default -> { }
        }
    }

    private void drawWindow(GuiGraphics g, int i) {
        int[] w = WIN[i];
        rect(g, w[0], w[1], w[2], w[3], 0xFF050608);
        for (int k = 0; k < boards[i]; k++) {
            if (w[2] == 3) rect(g, w[0] - 1, w[1] + 2 + k * 5, 5, 2, 0xFF8A5E2E);
            else rect(g, w[0] + 2 + k * 5, w[1] - 1, 2, 5, 0xFF8A5E2E);
        }
    }

    private void drawPickup(GuiGraphics g, double[] p) {
        if (p[3] < 300 && (t / 6) % 2 == 0) return;
        int x = (int) p[0], y = (int) p[1], type = (int) p[2];
        int[] col = {0xFF4AA3FF, 0xFFFF5A5A, 0xFFFFD84A, 0xFFFFA040};
        String[] ch = {"M", "I", "2", "N"};
        rect(g, x - 5, y - 5, 10, 10, 0xFF101010);
        rect(g, x - 4, y - 4, 8, 8, col[type]);
        ctext(g, ch[type], x, y - 4, 0xFFFFFFFF);
    }

    private void drawZombie(GuiGraphics g, Z z) {
        if (z.dead) return;
        int zx = (int) Math.round(z.x), zy = (int) Math.round(z.y);
        double a = Math.atan2(py - z.y, px - z.x);
        if (z.st == 1) a = Math.atan2(WIN[z.win][7] - z.y, WIN[z.win][6] - z.x);
        int body = z.flash > 0 ? 0xFFFFFFFF : z.sp > 0.55 ? 0xFF8A6A4A : z.sp > 0.35 ? 0xFF7A8A52 : 0xFF5E7A52;
        disc(g, zx, zy, 4, 0xFF1C1F1A);
        disc(g, zx, zy, 3, body);
        double sway = Math.sin(z.anim * 0.3) * 1.2;
        for (int side = -1; side <= 1; side += 2) {
            double ax = Math.cos(a) * (5 + sway * side) - Math.sin(a) * 2.5 * side;
            double ay = Math.sin(a) * (5 + sway * side) + Math.cos(a) * 2.5 * side;
            rect(g, zx + (int) Math.round(ax) - 1, zy + (int) Math.round(ay) - 1, 2, 2, body);
        }
    }

    private void drawEyes(GuiGraphics g, Z z) {
        double a = Math.atan2(py - z.y, px - z.x);
        for (int side = -1; side <= 1; side += 2) {
            int ex = (int) Math.round(z.x + Math.cos(a) * 1.8 - Math.sin(a) * 1.4 * side);
            int ey = (int) Math.round(z.y + Math.sin(a) * 1.8 + Math.cos(a) * 1.4 * side);
            rect(g, ex, ey, 1, 1, 0xFFFF2A2A);
        }
    }

    private void drawPlayer(GuiGraphics g) {
        int x = (int) Math.round(px), y = (int) Math.round(py);
        disc(g, x, y, 4, 0xFF101010);
        disc(g, x, y, 3, 0xFF5B6E3C);
        disc(g, x, y, 2, 0xFF4C5E32);
        double dx = Math.cos(aim), dy = Math.sin(aim);
        for (int k = 3; k <= 9; k++) rect(g, x + (int) Math.round(dx * k) - 1, y + (int) Math.round(dy * k) - 1, 2, 2, 0xFF222222);
        if (flashT > 0) disc(g, x + (int) Math.round(dx * 11), y + (int) Math.round(dy * 11), 2, 0xFFFFE070);
    }

    /** The sniper's sight: a dotted red line along the aim, up to the first wall or crate. */
    private void drawScope(GuiGraphics g) {
        if (reloadT > 0) return;
        int range = WP[slotW[cur]].range();
        double dx = Math.cos(aim), dy = Math.sin(aim);
        for (int d = 12; d < range; d += 4) {
            double x = px + dx * d, y = py + dy * d;
            if (x < 0 || y < 0 || x > WW || y > WH || stopsBullet(x, y)) break;
            rect(g, (int) x, (int) y, 1, 1, (d / 4) % 2 == 0 ? 0x66FF3030 : 0x33FF3030);
        }
    }

    private void drawTracer(GuiGraphics g, double[] a) {
        double dx = a[2] - a[0], dy = a[3] - a[1], len = Math.hypot(dx, dy);
        int col = ((int) (a[4] * 60) << 24) | ((int) a[5] & 0xFFFFFF);
        for (double s = 0; s < len; s += 3) rect(g, (int) (a[0] + dx / len * s), (int) (a[1] + dy / len * s), 1, 1, col);
    }

    // what the player sees of the map is worked out once per three ticks and kept per 3 x 3 cell
    private static final int VX = (WW + 2) / 3 + 1, VY = (WH + 2) / 3 + 1;
    private final int[] visStamp = new int[VX * VY];
    private final boolean[] visVal = new boolean[VX * VY];
    private int visEpoch = 1;

    private boolean seenCell(int tx, int ty, double cx, double cy) {
        int i = (ty / 3) * VX + (tx / 3);
        if (i < 0 || i >= visVal.length) return true;
        if (visStamp[i] != visEpoch) { visStamp[i] = visEpoch; visVal[i] = los(px, py, cx, cy); }
        return visVal[i];
    }

    /** The bunker is dark: only the area around the player is lit, and what is behind a wall stays in the dark (fog of war). */
    private void darkness(GuiGraphics g) {
        int x0 = (int) Math.floor(camX / 3) * 3, y0 = (int) Math.floor(camY / 3) * 3;
        for (int ty = y0; ty < camY + VH + 3; ty += 3) {
            for (int tx = x0; tx < camX + VW + 3; tx += 3) {
                double cx = tx + 1.5, cy = ty + 1.5, dx = cx - px, dy = cy - py, d2 = dx * dx + dy * dy;
                int al = d2 <= 676 ? 0 : (int) (Math.min(1, (Math.sqrt(d2) - 26) / 52.0) * 190);
                if (d2 > 64 && !seenCell(tx, ty, cx, cy)) al = Math.max(al, 215);
                if (al > 3) g.fill(tx, ty, tx + 3, ty + 3, al << 24);
            }
        }
    }

    private void outlined(GuiGraphics g, String s, int x, int y, int colour) {
        text(g, s, x + 1, y + 1, 0xFF000000);
        text(g, s, x, y, colour);
    }

    private void hud(GuiGraphics g) {
        // a red edge when hurt
        float f = (float) Math.max(hurtFlash * 0.5, 1 - hp / maxHp);
        int al = (int) (Math.min(1, f) * 150);
        if (al > 4) {
            for (int i = 0; i < 4; i++) {
                int a = (al * (4 - i) / 4) << 24 | 0xA01010, in = i * 3;
                g.fill(0, in, W, in + 3, a); g.fill(0, H - in - 3, W, H - in, a);
                g.fill(in, 0, in + 3, H, a); g.fill(W - in - 3, 0, W - in, H, a);
            }
        }
        // points and the health bar
        outlined(g, String.valueOf(points), 4, H - 14, 0xFFFFE070);
        rect(g, 4, H - 4, 42, 2, 0xAA000000);
        rect(g, 4, H - 4, (int) (42 * Math.max(0, hp) / maxHp), 2, hp / maxHp > 0.4 ? 0xFF6FCF6F : 0xFFE05050);
        if (jugg) rect(g, 50, H - 5, 4, 4, 0xFFC0392B);
        if (speedCola) rect(g, 56, H - 5, 4, 4, 0xFF3FA34D);
        // the round
        g.pose().pushPose();
        g.pose().translate(4, 4, 0);
        g.pose().scale(1.6F, 1.6F, 1F);
        text(g, String.valueOf(round), 1, 1, 0xFF000000);
        text(g, String.valueOf(round), 0, 0, 0xFFC01818);
        g.pose().popPose();
        // the zombies of the round that are left
        if (round > 0) outlined(g, String.valueOf(toSpawn + zs.size()), 4, 22, 0xFFCFCFC8);
        // the gun
        String ammo = mag[cur] + " / " + res[cur];
        outlined(g, ammo, W - 4 - tw(ammo), H - 14, 0xFFFFFFFF);
        String name = wname(cur);
        outlined(g, name, W - 4 - tw(name), H - 24, pap[cur] ? 0xFFFFD84A : 0xFFCFCFC8);
        if (reloadT > 0) rect(g, W - 46, H - 4, (int) (42 * (1 - reloadT / (float) reloadMax)), 2, 0xFFFFFFFF);
        if (instaT > 0) outlined(g, "INSTA " + (instaT / 60 + 1), W - 4 - tw("INSTA 30"), 26, 0xFFFF6A6A);
        if (dblT > 0) outlined(g, "2x " + (dblT / 60 + 1), W - 4 - tw("2x 30"), instaT > 0 ? 36 : 26, 0xFFFFD84A);
        // texts in the middle
        if (!prompt.isEmpty()) {
            int pw = tw(prompt) + 8;
            rect(g, (W - pw) / 2, H - 38, pw, 11, 0xAA000000);
            ctext(g, prompt, W / 2, H - 36, 0xFFFFFFFF);
        }
        if (msgT > 0) ctext(g, msg.getString(), W / 2, 24, 0xFFFFD84A);
        if (breakT > 0 && round > 0 && !over) ctext(g, Component.translatable("cutemod.nacht.next", breakT / 60 + 1).getString(), W / 2, 14, 0xFFCFCFC8);
        if (introT > 0) {
            int a = Math.min(255, introT * 4);
            g.pose().pushPose();
            g.pose().translate(W / 2F, 52, 0);
            g.pose().scale(2F, 2F, 1F);
            ctext(g, Component.translatable("cutemod.nacht.round", round).getString(), 0, 0, (a << 24) | 0xD01818);
            g.pose().popPose();
        }
        // the little map: the rooms that are open, and you
        int mmx = W - 45, mmy = 3;
        rect(g, mmx - 1, mmy - 1, 43, 21, 0xAA000000);
        for (int z = 0; z < ZN; z++) {
            int[] r = ZONE_RECT[z];
            rect(g, mmx + r[0] / 8, mmy + r[1] / 8, r[2] / 8, r[3] / 8, zoneOpen[z] ? 0xFF5A6068 : 0xFF24262A);
        }
        for (int i = 0; i < DOORS.length; i++) {
            int[] d = DOORS[i];
            rect(g, mmx + d[0] / 8, mmy + d[1] / 8, Math.max(1, d[2] / 8), Math.max(1, d[3] / 8), doorOpen[i] ? 0xFF9AA0A8 : 0xFFB07A38);
        }
        if (zoneOpen[obj[boxIdx][5]]) rect(g, mmx + obj[boxIdx][1] / 8 - 1, mmy + obj[boxIdx][2] / 8 - 1, 2, 2, 0xFFFFA040);
        if ((t / 15) % 2 == 0) rect(g, mmx + (int) (px / 8) - 1, mmy + (int) (py / 8) - 1, 2, 2, 0xFFFFE070);
        // the cross-hair
        if (mx >= 0 && my >= 0 && mx < W && my < H) {
            rect(g, mx - 5, my, 3, 1, 0xFFFFFFFF); rect(g, mx + 3, my, 3, 1, 0xFFFFFFFF);
            rect(g, mx, my - 5, 1, 3, 0xFFFFFFFF); rect(g, mx, my + 3, 1, 3, 0xFFFFFFFF);
        }
    }
}
